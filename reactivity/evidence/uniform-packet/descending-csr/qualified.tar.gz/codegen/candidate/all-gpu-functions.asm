
FUNCTION core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>> bytes=105 frame=8

/tmp/gpui-descending-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000816670 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>:
  816670:	push   %rbx
  816671:	test   %rdi,%rdi
  816674:	je     8166d7 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x67>
  816676:	mov    %rdi,%rbx
  816679:	mov    (%rdi),%rsi
  81667c:	test   %rsi,%rsi
  81667f:	je     816694 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x24>
  816681:	mov    0x8(%rbx),%rdi
  816685:	shl    $0x3,%rsi
  816689:	mov    $0x8,%edx
  81668e:	call   *0x6691cc(%rip)        # e7f860 <_DYNAMIC+0x248>
  816694:	mov    0x20(%rbx),%rsi
  816698:	test   %rsi,%rsi
  81669b:	je     8166c3 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  81669d:	mov    %rsi,%rax
  8166a0:	shl    $0x4,%rax
  8166a4:	add    %rax,%rsi
  8166a7:	add    $0x21,%rsi
  8166ab:	je     8166c3 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  8166ad:	mov    0x18(%rbx),%rdi
  8166b1:	sub    %rax,%rdi
  8166b4:	add    $0xfffffffffffffff0,%rdi
  8166b8:	mov    $0x10,%edx
  8166bd:	call   *0x66919d(%rip)        # e7f860 <_DYNAMIC+0x248>
  8166c3:	mov    $0x80,%esi
  8166c8:	mov    $0x8,%edx
  8166cd:	mov    %rbx,%rdi
  8166d0:	pop    %rbx
  8166d1:	jmp    *0x669189(%rip)        # e7f860 <_DYNAMIC+0x248>
  8166d7:	pop    %rbx
  8166d8:	ret

FUNCTION core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}> bytes=71 frame=8

/tmp/gpui-descending-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000816ce0 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>>:
  816ce0:	push   %rbx
  816ce1:	cmpb   $0x3,0x19c(%rdi)
  816ce8:	jne    816d17 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x37>
  816cea:	movzbl 0x28(%rdi),%eax
  816cee:	cmp    $0x4,%eax
  816cf1:	je     816d05 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x25>
  816cf3:	cmp    $0x3,%eax
  816cf6:	jne    816d17 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x37>
  816cf8:	add    $0x168,%rdi
  816cff:	pop    %rbx
  816d00:	jmp    816c50 <core::ptr::drop_glue::<<wgpu::api::adapter::Adapter>::request_device::{closure#0}>>
  816d05:	mov    %rdi,%rbx
  816d08:	add    $0x30,%rdi
  816d0c:	call   816d30 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>>
  816d11:	movw   $0x0,0x29(%rbx)
  816d17:	pop    %rbx
  816d18:	ret
  816d19:	movw   $0x0,0x29(%rbx)
  816d1f:	mov    %rax,%rdi
  816d22:	call   e2c400 <_Unwind_Resume@plt>

FUNCTION core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}> bytes=540 frame=40

/tmp/gpui-descending-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000816d30 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>>:
  816d30:	push   %r15
  816d32:	push   %r14
  816d34:	push   %r12
  816d36:	push   %rbx
  816d37:	push   %rax
  816d38:	mov    %rdi,%rbx
  816d3b:	movzbl 0x9e(%rdi),%eax
  816d42:	test   %eax,%eax
  816d44:	je     816e0b <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xdb>
  816d4a:	cmp    $0x3,%eax
  816d4d:	jne    816e41 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x111>
  816d53:	mov    0x20(%rbx),%r15
  816d57:	mov    0x28(%rbx),%r12
  816d5b:	mov    (%r12),%rax
  816d5f:	test   %rax,%rax
  816d62:	je     816d69 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x39>
  816d64:	mov    %r15,%rdi
  816d67:	call   *%rax
  816d69:	mov    0x8(%r12),%rsi
  816d6e:	test   %rsi,%rsi
  816d71:	je     816d81 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x51>
  816d73:	mov    0x10(%r12),%rdx
  816d78:	mov    %r15,%rdi
  816d7b:	call   *0x668adf(%rip)        # e7f860 <_DYNAMIC+0x248>
  816d81:	mov    0x68(%rbx),%rax
  816d85:	lock decq (%rax)
  816d89:	jne    816d95 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x65>
  816d8b:	lea    0x68(%rbx),%rdi
  816d8f:	call   *0x668ceb(%rip)        # e7fa80 <_DYNAMIC+0x468>
  816d95:	movb   $0x0,0x98(%rbx)
  816d9c:	mov    0x60(%rbx),%rax
  816da0:	lock decq (%rax)
  816da4:	jne    816daf <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x7f>
  816da6:	lea    0x60(%rbx),%rdi
  816daa:	call   812eb0 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  816daf:	movw   $0x0,0x99(%rbx)
  816db8:	mov    0x40(%rbx),%rax
  816dbc:	lock decq (%rax)
  816dc0:	jne    816dcc <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x9c>
  816dc2:	lea    0x40(%rbx),%rdi
  816dc6:	call   *0x668cbc(%rip)        # e7fa88 <_DYNAMIC+0x470>
  816dcc:	movb   $0x0,0x9b(%rbx)
  816dd3:	mov    0x38(%rbx),%rax
  816dd7:	lock decq (%rax)
  816ddb:	jne    816de7 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xb7>
  816ddd:	lea    0x38(%rbx),%rdi
  816de1:	call   *0x668ca9(%rip)        # e7fa90 <_DYNAMIC+0x478>
  816de7:	movb   $0x0,0x9c(%rbx)
  816dee:	mov    0x30(%rbx),%rax
  816df2:	lock decq (%rax)
  816df6:	jne    816e02 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xd2>
  816df8:	lea    0x30(%rbx),%rdi
  816dfc:	call   *0x668c96(%rip)        # e7fa98 <_DYNAMIC+0x480>
  816e02:	movb   $0x0,0x9d(%rbx)
  816e09:	jmp    816e41 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x111>
  816e0b:	mov    0x70(%rbx),%rax
  816e0f:	lock decq (%rax)
  816e13:	jne    816e1f <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xef>
  816e15:	lea    0x70(%rbx),%rdi
  816e19:	call   *0x668c79(%rip)        # e7fa98 <_DYNAMIC+0x480>
  816e1f:	mov    0x78(%rbx),%rax
  816e23:	lock decq (%rax)
  816e27:	jne    816e41 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x111>
  816e29:	add    $0x78,%rbx
  816e2d:	mov    %rbx,%rdi
  816e30:	add    $0x8,%rsp
  816e34:	pop    %rbx
  816e35:	pop    %r12
  816e37:	pop    %r14
  816e39:	pop    %r15
  816e3b:	jmp    *0x668c4f(%rip)        # e7fa90 <_DYNAMIC+0x478>
  816e41:	add    $0x8,%rsp
  816e45:	pop    %rbx
  816e46:	pop    %r12
  816e48:	pop    %r14
  816e4a:	pop    %r15
  816e4c:	ret
  816e4d:	mov    %rax,%r14
  816e50:	movb   $0x0,0x9d(%rbx)
  816e57:	mov    %r14,%rdi
  816e5a:	call   e2c400 <_Unwind_Resume@plt>
  816e5f:	mov    %rax,%r14
  816e62:	jmp    816f1c <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1ec>
  816e67:	mov    %rax,%r14
  816e6a:	jmp    816f01 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1d1>
  816e6f:	mov    %rax,%r14
  816e72:	jmp    816ee4 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1b4>
  816e74:	mov    %rax,%r14
  816e77:	jmp    816eca <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x19a>
  816e79:	mov    %rax,%r14
  816e7c:	mov    0x78(%rbx),%rax
  816e80:	lock decq (%rax)
  816e84:	jne    816e93 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x163>
  816e86:	add    $0x78,%rbx
  816e8a:	mov    %rbx,%rdi
  816e8d:	call   *0x668bfd(%rip)        # e7fa90 <_DYNAMIC+0x478>
  816e93:	mov    %r14,%rdi
  816e96:	call   e2c400 <_Unwind_Resume@plt>
  816e9b:	mov    %rax,%r14
  816e9e:	mov    0x8(%r12),%rsi
  816ea3:	test   %rsi,%rsi
  816ea6:	je     816eb6 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x186>
  816ea8:	mov    0x10(%r12),%rdx
  816ead:	mov    %r15,%rdi
  816eb0:	call   *0x6689aa(%rip)        # e7f860 <_DYNAMIC+0x248>
  816eb6:	mov    0x68(%rbx),%rax
  816eba:	lock decq (%rax)
  816ebe:	jne    816eca <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x19a>
  816ec0:	lea    0x68(%rbx),%rdi
  816ec4:	call   *0x668bb6(%rip)        # e7fa80 <_DYNAMIC+0x468>
  816eca:	movb   $0x0,0x98(%rbx)
  816ed1:	mov    0x60(%rbx),%rax
  816ed5:	lock decq (%rax)
  816ed9:	jne    816ee4 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1b4>
  816edb:	lea    0x60(%rbx),%rdi
  816edf:	call   812eb0 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  816ee4:	movw   $0x0,0x99(%rbx)
  816eed:	mov    0x40(%rbx),%rax
  816ef1:	lock decq (%rax)
  816ef5:	jne    816f01 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1d1>
  816ef7:	lea    0x40(%rbx),%rdi
  816efb:	call   *0x668b87(%rip)        # e7fa88 <_DYNAMIC+0x470>
  816f01:	movb   $0x0,0x9b(%rbx)
  816f08:	mov    0x38(%rbx),%rax
  816f0c:	lock decq (%rax)
  816f10:	jne    816f1c <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1ec>
  816f12:	lea    0x38(%rbx),%rdi
  816f16:	call   *0x668b74(%rip)        # e7fa90 <_DYNAMIC+0x478>
  816f1c:	movb   $0x0,0x9c(%rbx)
  816f23:	mov    0x30(%rbx),%rax
  816f27:	lock decq (%rax)
  816f2b:	jne    816f37 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x207>
  816f2d:	lea    0x30(%rbx),%rdi
  816f31:	call   *0x668b61(%rip)        # e7fa98 <_DYNAMIC+0x480>
  816f37:	movb   $0x0,0x9d(%rbx)
  816f3e:	mov    %r14,%rdi
  816f41:	call   e2c400 <_Unwind_Resume@plt>
  816f46:	call   *0x66891c(%rip)        # e7f868 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}> bytes=64 frame=8

/tmp/gpui-descending-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000816f50 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}>>:
  816f50:	push   %rbx
  816f51:	movzbl 0x20(%rdi),%eax
  816f55:	cmp    $0x3,%eax
  816f58:	je     816f73 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}>+0x23>
  816f5a:	cmp    $0x4,%eax
  816f5d:	jne    816f80 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}>+0x30>
  816f5f:	mov    %rdi,%rbx
  816f62:	add    $0x28,%rdi
  816f66:	call   816d30 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>>
  816f6b:	movw   $0x0,0x21(%rbx)
  816f71:	pop    %rbx
  816f72:	ret
  816f73:	add    $0x160,%rdi
  816f7a:	pop    %rbx
  816f7b:	jmp    816c50 <core::ptr::drop_glue::<<wgpu::api::adapter::Adapter>::request_device::{closure#0}>>
  816f80:	pop    %rbx
  816f81:	ret
  816f82:	movw   $0x0,0x21(%rbx)
  816f88:	mov    %rax,%rdi
  816f8b:	call   e2c400 <_Unwind_Resume@plt>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext> bytes=191 frame=24

/tmp/gpui-descending-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000817470 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>>:
  817470:	push   %r14
  817472:	push   %rbx
  817473:	push   %rax
  817474:	mov    %rdi,%rbx
  817477:	mov    (%rdi),%rax
  81747a:	lock decq (%rax)
  81747e:	jne    817489 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x19>
  817480:	mov    %rbx,%rdi
  817483:	call   *0x66860f(%rip)        # e7fa98 <_DYNAMIC+0x480>
  817489:	mov    0x8(%rbx),%rax
  81748d:	lock decq (%rax)
  817491:	jne    81749d <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x2d>
  817493:	lea    0x8(%rbx),%rdi
  817497:	call   *0x6685f3(%rip)        # e7fa90 <_DYNAMIC+0x478>
  81749d:	mov    0x10(%rbx),%rax
  8174a1:	lock decq (%rax)
  8174a5:	jne    8174b0 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x40>
  8174a7:	lea    0x10(%rbx),%rdi
  8174ab:	call   812eb0 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  8174b0:	mov    0x18(%rbx),%rax
  8174b4:	lock decq (%rax)
  8174b8:	jne    8174ce <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x5e>
  8174ba:	add    $0x18,%rbx
  8174be:	mov    %rbx,%rdi
  8174c1:	add    $0x8,%rsp
  8174c5:	pop    %rbx
  8174c6:	pop    %r14
  8174c8:	jmp    *0x6685b2(%rip)        # e7fa80 <_DYNAMIC+0x468>
  8174ce:	add    $0x8,%rsp
  8174d2:	pop    %rbx
  8174d3:	pop    %r14
  8174d5:	ret
  8174d6:	mov    %rax,%r14
  8174d9:	jmp    81750a <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x9a>
  8174db:	mov    %rax,%r14
  8174de:	jmp    8174f7 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x87>
  8174e0:	mov    %rax,%r14
  8174e3:	mov    0x8(%rbx),%rax
  8174e7:	lock decq (%rax)
  8174eb:	jne    8174f7 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x87>
  8174ed:	lea    0x8(%rbx),%rdi
  8174f1:	call   *0x668599(%rip)        # e7fa90 <_DYNAMIC+0x478>
  8174f7:	mov    0x10(%rbx),%rax
  8174fb:	lock decq (%rax)
  8174ff:	jne    81750a <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x9a>
  817501:	lea    0x10(%rbx),%rdi
  817505:	call   812eb0 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  81750a:	mov    0x18(%rbx),%rax
  81750e:	lock decq (%rax)
  817512:	jne    817521 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0xb1>
  817514:	add    $0x18,%rbx
  817518:	mov    %rbx,%rdi
  81751b:	call   *0x66855f(%rip)        # e7fa80 <_DYNAMIC+0x468>
  817521:	mov    %r14,%rdi
  817524:	call   e2c400 <_Unwind_Resume@plt>
  817529:	call   *0x668339(%rip)        # e7f868 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::RendererState> bytes=1172 frame=24

/tmp/gpui-descending-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000817530 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>>:
  817530:	push   %r14
  817532:	push   %rbx
  817533:	push   %rax
  817534:	mov    %rdi,%rbx
  817537:	mov    0x210(%rdi),%rax
  81753e:	lock decq (%rax)
  817542:	jne    817551 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x21>
  817544:	lea    0x210(%rbx),%rdi
  81754b:	call   *0x66852f(%rip)        # e7fa80 <_DYNAMIC+0x468>
  817551:	mov    0x218(%rbx),%rax
  817558:	lock decq (%rax)
  81755c:	jne    81756b <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3b>
  81755e:	lea    0x218(%rbx),%rdi
  817565:	call   *0x6685b5(%rip)        # e7fb20 <_DYNAMIC+0x508>
  81756b:	mov    0x220(%rbx),%rax
  817572:	lock decq (%rax)
  817576:	jne    817585 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x55>
  817578:	lea    0x220(%rbx),%rdi
  81757f:	call   *0x6685a3(%rip)        # e7fb28 <_DYNAMIC+0x510>
  817585:	mov    0x240(%rbx),%rax
  81758c:	lock decq (%rax)
  817590:	jne    81759f <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x6f>
  817592:	lea    0x240(%rbx),%rdi
  817599:	call   *0x668581(%rip)        # e7fb20 <_DYNAMIC+0x508>
  81759f:	mov    0x248(%rbx),%rax
  8175a6:	lock decq (%rax)
  8175aa:	jne    8175b9 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x89>
  8175ac:	lea    0x248(%rbx),%rdi
  8175b3:	call   *0x66856f(%rip)        # e7fb28 <_DYNAMIC+0x510>
  8175b9:	mov    0x268(%rbx),%rax
  8175c0:	lock decq (%rax)
  8175c4:	jne    8175d3 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xa3>
  8175c6:	lea    0x268(%rbx),%rdi
  8175cd:	call   *0x66854d(%rip)        # e7fb20 <_DYNAMIC+0x508>
  8175d3:	mov    0x270(%rbx),%rax
  8175da:	lock decq (%rax)
  8175de:	jne    8175ed <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xbd>
  8175e0:	lea    0x270(%rbx),%rdi
  8175e7:	call   *0x66853b(%rip)        # e7fb28 <_DYNAMIC+0x510>
  8175ed:	mov    0x290(%rbx),%rax
  8175f4:	lock decq (%rax)
  8175f8:	jne    817607 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xd7>
  8175fa:	lea    0x290(%rbx),%rdi
  817601:	call   *0x668519(%rip)        # e7fb20 <_DYNAMIC+0x508>
  817607:	mov    0x298(%rbx),%rax
  81760e:	lock decq (%rax)
  817612:	jne    817621 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xf1>
  817614:	lea    0x298(%rbx),%rdi
  81761b:	call   *0x668507(%rip)        # e7fb28 <_DYNAMIC+0x510>
  817621:	mov    0x2b8(%rbx),%rax
  817628:	lock decq (%rax)
  81762c:	jne    81763b <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x10b>
  81762e:	lea    0x2b8(%rbx),%rdi
  817635:	call   *0x6684e5(%rip)        # e7fb20 <_DYNAMIC+0x508>
  81763b:	mov    0x2c0(%rbx),%rax
  817642:	lock decq (%rax)
  817646:	jne    817655 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x125>
  817648:	lea    0x2c0(%rbx),%rdi
  81764f:	call   *0x6684d3(%rip)        # e7fb28 <_DYNAMIC+0x510>
  817655:	lea    0x60(%rbx),%rdi
  817659:	call   8179d0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81765e:	mov    0x310(%rbx),%r14
  817665:	test   %r14,%r14
  817668:	je     8176c7 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x197>
  81766a:	mov    (%r14),%rsi
  81766d:	test   %rsi,%rsi
  817670:	je     817685 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x155>
  817672:	mov    0x8(%r14),%rdi
  817676:	shl    $0x3,%rsi
  81767a:	mov    $0x8,%edx
  81767f:	call   *0x6681db(%rip)        # e7f860 <_DYNAMIC+0x248>
  817685:	mov    0x20(%r14),%rsi
  817689:	test   %rsi,%rsi
  81768c:	je     8176b4 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x184>
  81768e:	mov    %rsi,%rax
  817691:	shl    $0x4,%rax
  817695:	add    %rax,%rsi
  817698:	add    $0x21,%rsi
  81769c:	je     8176b4 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x184>
  81769e:	mov    0x18(%r14),%rdi
  8176a2:	sub    %rax,%rdi
  8176a5:	add    $0xfffffffffffffff0,%rdi
  8176a9:	mov    $0x10,%edx
  8176ae:	call   *0x6681ac(%rip)        # e7f860 <_DYNAMIC+0x248>
  8176b4:	mov    $0x80,%esi
  8176b9:	mov    $0x8,%edx
  8176be:	mov    %r14,%rdi
  8176c1:	call   *0x668199(%rip)        # e7f860 <_DYNAMIC+0x248>
  8176c7:	mov    (%rbx),%rsi
  8176ca:	test   %rsi,%rsi
  8176cd:	je     8176e2 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x1b2>
  8176cf:	mov    0x8(%rbx),%rdi
  8176d3:	shl    $0x4,%rsi
  8176d7:	mov    $0x4,%edx
  8176dc:	call   *0x66817e(%rip)        # e7f860 <_DYNAMIC+0x248>
  8176e2:	mov    0x18(%rbx),%rsi
  8176e6:	test   %rsi,%rsi
  8176e9:	je     8176fe <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x1ce>
  8176eb:	mov    0x20(%rbx),%rdi
  8176ef:	shl    $0x3,%rsi
  8176f3:	mov    $0x4,%edx
  8176f8:	call   *0x668162(%rip)        # e7f860 <_DYNAMIC+0x248>
  8176fe:	mov    0x30(%rbx),%rsi
  817702:	test   %rsi,%rsi
  817705:	je     81771a <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x1ea>
  817707:	mov    0x38(%rbx),%rdi
  81770b:	shl    $0x2,%rsi
  81770f:	mov    $0x4,%edx
  817714:	call   *0x668146(%rip)        # e7f860 <_DYNAMIC+0x248>
  81771a:	mov    0x48(%rbx),%rsi
  81771e:	test   %rsi,%rsi
  817721:	je     817736 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x206>
  817723:	mov    0x50(%rbx),%rdi
  817727:	shl    $0x5,%rsi
  81772b:	mov    $0x4,%edx
  817730:	call   *0x66812a(%rip)        # e7f860 <_DYNAMIC+0x248>
  817736:	mov    0x2e8(%rbx),%rsi
  81773d:	test   %rsi,%rsi
  817740:	je     817770 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x240>
  817742:	lea    (%rsi,%rsi,8),%rax
  817746:	lea    0x33(,%rax,4),%rax
  81774e:	and    $0xfffffffffffffff0,%rax
  817752:	add    %rax,%rsi
  817755:	add    $0x11,%rsi
  817759:	je     817770 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x240>
  81775b:	mov    0x2e0(%rbx),%rdi
  817762:	sub    %rax,%rdi
  817765:	mov    $0x10,%edx
  81776a:	call   *0x6680f0(%rip)        # e7f860 <_DYNAMIC+0x248>
  817770:	mov    0x318(%rbx),%rax
  817777:	test   %rax,%rax
  81777a:	je     817799 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x269>
  81777c:	lock decq (%rax)
  817780:	jne    817799 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x269>
  817782:	add    $0x318,%rbx
  817789:	mov    %rbx,%rdi
  81778c:	add    $0x8,%rsp
  817790:	pop    %rbx
  817791:	pop    %r14
  817793:	jmp    *0x668397(%rip)        # e7fb30 <_DYNAMIC+0x518>
  817799:	add    $0x8,%rsp
  81779d:	pop    %rbx
  81779e:	pop    %r14
  8177a0:	ret
  8177a1:	mov    %rax,%r14
  8177a4:	jmp    8178d0 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3a0>
  8177a9:	mov    %rax,%r14
  8177ac:	mov    0x2c0(%rbx),%rax
  8177b3:	lock decq (%rax)
  8177b7:	jne    8178d0 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3a0>
  8177bd:	lea    0x2c0(%rbx),%rdi
  8177c4:	call   *0x66835e(%rip)        # e7fb28 <_DYNAMIC+0x510>
  8177ca:	jmp    8178d0 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3a0>
  8177cf:	call   *0x668093(%rip)        # e7f868 <_DYNAMIC+0x250>
  8177d5:	mov    %rax,%r14
  8177d8:	jmp    8178c4 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x394>
  8177dd:	mov    %rax,%r14
  8177e0:	mov    0x298(%rbx),%rax
  8177e7:	lock decq (%rax)
  8177eb:	jne    8178c4 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x394>
  8177f1:	lea    0x298(%rbx),%rdi
  8177f8:	call   *0x66832a(%rip)        # e7fb28 <_DYNAMIC+0x510>
  8177fe:	jmp    8178c4 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x394>
  817803:	call   *0x66805f(%rip)        # e7f868 <_DYNAMIC+0x250>
  817809:	mov    %rax,%r14
  81780c:	jmp    8178b8 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x388>
  817811:	mov    %rax,%r14
  817814:	mov    0x270(%rbx),%rax
  81781b:	lock decq (%rax)
  81781f:	jne    8178b8 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x388>
  817825:	lea    0x270(%rbx),%rdi
  81782c:	call   *0x6682f6(%rip)        # e7fb28 <_DYNAMIC+0x510>
  817832:	jmp    8178b8 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x388>
  817837:	call   *0x66802b(%rip)        # e7f868 <_DYNAMIC+0x250>
  81783d:	mov    %rax,%r14
  817840:	jmp    8178ac <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x37c>
  817842:	mov    %rax,%r14
  817845:	mov    0x248(%rbx),%rax
  81784c:	lock decq (%rax)
  817850:	jne    8178ac <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x37c>
  817852:	lea    0x248(%rbx),%rdi
  817859:	call   *0x6682c9(%rip)        # e7fb28 <_DYNAMIC+0x510>
  81785f:	jmp    8178ac <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x37c>
  817861:	call   *0x668001(%rip)        # e7f868 <_DYNAMIC+0x250>
  817867:	mov    %rax,%r14
  81786a:	jmp    8178a0 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x370>
  81786c:	mov    %rax,%r14
  81786f:	mov    0x220(%rbx),%rax
  817876:	lock decq (%rax)
  81787a:	jne    8178a0 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x370>
  81787c:	lea    0x220(%rbx),%rdi
  817883:	call   *0x66829f(%rip)        # e7fb28 <_DYNAMIC+0x510>
  817889:	jmp    8178a0 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x370>
  81788b:	call   *0x667fd7(%rip)        # e7f868 <_DYNAMIC+0x250>
  817891:	mov    %rax,%r14
  817894:	lea    0x218(%rbx),%rdi
  81789b:	call   817ad0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  8178a0:	lea    0x240(%rbx),%rdi
  8178a7:	call   817ad0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  8178ac:	lea    0x268(%rbx),%rdi
  8178b3:	call   817ad0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  8178b8:	lea    0x290(%rbx),%rdi
  8178bf:	call   817ad0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  8178c4:	lea    0x2b8(%rbx),%rdi
  8178cb:	call   817ad0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  8178d0:	lea    0x60(%rbx),%rdi
  8178d4:	call   8179d0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  8178d9:	mov    0x310(%rbx),%rdi
  8178e0:	call   816670 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>
  8178e5:	mov    (%rbx),%rsi
  8178e8:	test   %rsi,%rsi
  8178eb:	jne    817955 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x425>
  8178ed:	mov    0x18(%rbx),%rsi
  8178f1:	test   %rsi,%rsi
  8178f4:	jne    817971 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x441>
  8178f6:	mov    0x30(%rbx),%rsi
  8178fa:	test   %rsi,%rsi
  8178fd:	jne    817991 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x461>
  817903:	mov    0x48(%rbx),%rsi
  817907:	test   %rsi,%rsi
  81790a:	je     81791f <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3ef>
  81790c:	mov    0x50(%rbx),%rdi
  817910:	shl    $0x5,%rsi
  817914:	mov    $0x4,%edx
  817919:	call   *0x667f41(%rip)        # e7f860 <_DYNAMIC+0x248>
  81791f:	lea    0x2e0(%rbx),%rdi
  817926:	call   819de0 <<hashbrown::raw::RawTable<([u32; 8], u32)> as core::ops::drop::Drop>::drop>
  81792b:	mov    0x318(%rbx),%rax
  817932:	test   %rax,%rax
  817935:	je     81794d <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x41d>
  817937:	lock decq (%rax)
  81793b:	jne    81794d <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x41d>
  81793d:	add    $0x318,%rbx
  817944:	mov    %rbx,%rdi
  817947:	call   *0x6681e3(%rip)        # e7fb30 <_DYNAMIC+0x518>
  81794d:	mov    %r14,%rdi
  817950:	call   e2c400 <_Unwind_Resume@plt>
  817955:	mov    0x8(%rbx),%rdi
  817959:	shl    $0x4,%rsi
  81795d:	mov    $0x4,%edx
  817962:	call   *0x667ef8(%rip)        # e7f860 <_DYNAMIC+0x248>
  817968:	mov    0x18(%rbx),%rsi
  81796c:	test   %rsi,%rsi
  81796f:	je     8178f6 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3c6>
  817971:	mov    0x20(%rbx),%rdi
  817975:	shl    $0x3,%rsi
  817979:	mov    $0x4,%edx
  81797e:	call   *0x667edc(%rip)        # e7f860 <_DYNAMIC+0x248>
  817984:	mov    0x30(%rbx),%rsi
  817988:	test   %rsi,%rsi
  81798b:	je     817903 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3d3>
  817991:	mov    0x38(%rbx),%rdi
  817995:	shl    $0x2,%rsi
  817999:	mov    $0x4,%edx
  81799e:	call   *0x667ebc(%rip)        # e7f860 <_DYNAMIC+0x248>
  8179a4:	mov    0x48(%rbx),%rsi
  8179a8:	test   %rsi,%rsi
  8179ab:	jne    81790c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3dc>
  8179b1:	jmp    81791f <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3ef>
  8179b6:	call   *0x667eac(%rip)        # e7f868 <_DYNAMIC+0x250>
  8179bc:	mov    %rax,%r14
  8179bf:	jmp    8178d9 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3a9>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Atlas> bytes=210 frame=24

/tmp/gpui-descending-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008179d0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>:
  8179d0:	push   %r14
  8179d2:	push   %rbx
  8179d3:	push   %rax
  8179d4:	mov    %rdi,%rbx
  8179d7:	mov    (%rdi),%rax
  8179da:	lock decq (%rax)
  8179de:	jne    8179e9 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x19>
  8179e0:	mov    %rbx,%rdi
  8179e3:	call   *0x668117(%rip)        # e7fb00 <_DYNAMIC+0x4e8>
  8179e9:	mov    0x50(%rbx),%rax
  8179ed:	lock decq (%rax)
  8179f1:	jne    8179fd <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x2d>
  8179f3:	lea    0x50(%rbx),%rdi
  8179f7:	call   *0x6680fb(%rip)        # e7faf8 <_DYNAMIC+0x4e0>
  8179fd:	mov    0x58(%rbx),%rax
  817a01:	lock decq (%rax)
  817a05:	jne    817a11 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x41>
  817a07:	lea    0x58(%rbx),%rdi
  817a0b:	call   *0x6680ef(%rip)        # e7fb00 <_DYNAMIC+0x4e8>
  817a11:	mov    0xb0(%rbx),%rsi
  817a18:	test   %rsi,%rsi
  817a1b:	je     817a4d <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  817a1d:	mov    %rsi,%rax
  817a20:	shl    $0x5,%rax
  817a24:	add    %rax,%rsi
  817a27:	add    $0x31,%rsi
  817a2b:	je     817a4d <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  817a2d:	mov    0xa8(%rbx),%rdi
  817a34:	sub    %rax,%rdi
  817a37:	add    $0xffffffffffffffe0,%rdi
  817a3b:	mov    $0x10,%edx
  817a40:	add    $0x8,%rsp
  817a44:	pop    %rbx
  817a45:	pop    %r14
  817a47:	jmp    *0x667e13(%rip)        # e7f860 <_DYNAMIC+0x248>
  817a4d:	add    $0x8,%rsp
  817a51:	pop    %rbx
  817a52:	pop    %r14
  817a54:	ret
  817a55:	mov    %rax,%r14
  817a58:	jmp    817a85 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  817a5a:	mov    %rax,%r14
  817a5d:	mov    0x58(%rbx),%rax
  817a61:	lock decq (%rax)
  817a65:	jne    817a85 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  817a67:	lea    0x58(%rbx),%rdi
  817a6b:	call   *0x66808f(%rip)        # e7fb00 <_DYNAMIC+0x4e8>
  817a71:	jmp    817a85 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  817a73:	call   *0x667def(%rip)        # e7f868 <_DYNAMIC+0x250>
  817a79:	mov    %rax,%r14
  817a7c:	lea    0x50(%rbx),%rdi
  817a80:	call   817bd0 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  817a85:	add    $0xa8,%rbx
  817a8c:	mov    %rbx,%rdi
  817a8f:	call   819e20 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>
  817a94:	mov    %r14,%rdi
  817a97:	call   e2c400 <_Unwind_Resume@plt>
  817a9c:	call   *0x667dc6(%rip)        # e7f868 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Error> bytes=30 frame=0

/tmp/gpui-descending-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000817ab0 <core::ptr::drop_glue::<gpui_gpu::renderer::Error>>:
  817ab0:	cmpl   $0x1,(%rdi)
  817ab3:	ja     817acd <core::ptr::drop_glue::<gpui_gpu::renderer::Error>+0x1d>
  817ab5:	mov    0x8(%rdi),%rsi
  817ab9:	test   %rsi,%rsi
  817abc:	je     817acd <core::ptr::drop_glue::<gpui_gpu::renderer::Error>+0x1d>
  817abe:	mov    0x10(%rdi),%rdi
  817ac2:	mov    $0x1,%edx
  817ac7:	jmp    *0x667d93(%rip)        # e7f860 <_DYNAMIC+0x248>
  817acd:	ret

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Buffer> bytes=103 frame=24

/tmp/gpui-descending-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000817ad0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>:
  817ad0:	push   %r14
  817ad2:	push   %rbx
  817ad3:	push   %rax
  817ad4:	mov    %rdi,%rbx
  817ad7:	mov    (%rdi),%rax
  817ada:	lock decq (%rax)
  817ade:	jne    817ae9 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x19>
  817ae0:	mov    %rbx,%rdi
  817ae3:	call   *0x668037(%rip)        # e7fb20 <_DYNAMIC+0x508>
  817ae9:	mov    0x8(%rbx),%rax
  817aed:	lock decq (%rax)
  817af1:	jne    817b07 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x37>
  817af3:	add    $0x8,%rbx
  817af7:	mov    %rbx,%rdi
  817afa:	add    $0x8,%rsp
  817afe:	pop    %rbx
  817aff:	pop    %r14
  817b01:	jmp    *0x668021(%rip)        # e7fb28 <_DYNAMIC+0x510>
  817b07:	add    $0x8,%rsp
  817b0b:	pop    %rbx
  817b0c:	pop    %r14
  817b0e:	ret
  817b0f:	mov    %rax,%r14
  817b12:	mov    0x8(%rbx),%rax
  817b16:	lock decq (%rax)
  817b1a:	jne    817b29 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x59>
  817b1c:	add    $0x8,%rbx
  817b20:	mov    %rbx,%rdi
  817b23:	call   *0x667fff(%rip)        # e7fb28 <_DYNAMIC+0x510>
  817b29:	mov    %r14,%rdi
  817b2c:	call   e2c400 <_Unwind_Resume@plt>
  817b31:	call   *0x667d31(%rip)        # e7f868 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::Error as core::fmt::Debug>::fmt bytes=304 frame=24

/tmp/gpui-descending-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008184a0 <<gpui_gpu::renderer::Error as core::fmt::Debug>::fmt>:
  8184a0:	sub    $0x18,%rsp
  8184a4:	mov    %rsi,%rax
  8184a7:	mov    (%rdi),%ecx
  8184a9:	lea    -0x7476b0(%rip),%rdx        # d0e00 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0xbb8>
  8184b0:	movslq (%rdx,%rcx,4),%rcx
  8184b4:	add    %rdx,%rcx
  8184b7:	jmp    *%rcx
  8184b9:	add    $0x8,%rdi
  8184bd:	mov    %rdi,0x10(%rsp)
  8184c2:	lea    -0x743a30(%rip),%rsi        # d4a99 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x4851>
  8184c9:	jmp    818558 <<gpui_gpu::renderer::Error as core::fmt::Debug>::fmt+0xb8>
  8184ce:	lea    -0x743a13(%rip),%rsi        # d4ac2 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x487a>
  8184d5:	mov    $0x13,%edx
  8184da:	mov    %rax,%rdi
  8184dd:	add    $0x18,%rsp
  8184e1:	jmp    *0x667469(%rip)        # e7f950 <_DYNAMIC+0x338>
  8184e7:	add    $0x4,%rdi
  8184eb:	mov    %rdi,0x10(%rsp)
  8184f0:	lea    -0x743a52(%rip),%rsi        # d4aa5 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x485d>
  8184f7:	lea    0x61580a(%rip),%r8        # e2dd08 <__frame_dummy_init_array_entry+0x8c8>
  8184fe:	lea    0x10(%rsp),%rcx
  818503:	mov    $0x11,%edx
  818508:	mov    %rax,%rdi
  81850b:	call   *0x667447(%rip)        # e7f958 <_DYNAMIC+0x340>
  818511:	add    $0x18,%rsp
  818515:	ret
  818516:	lea    -0x743a67(%rip),%rsi        # d4ab6 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x486e>
  81851d:	mov    $0xc,%edx
  818522:	mov    %rax,%rdi
  818525:	add    $0x18,%rsp
  818529:	jmp    *0x667421(%rip)        # e7f950 <_DYNAMIC+0x338>
  81852f:	lea    -0x743a4b(%rip),%rsi        # d4aeb <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x48a3>
  818536:	mov    $0x9,%edx
  81853b:	mov    %rax,%rdi
  81853e:	add    $0x18,%rsp
  818542:	jmp    *0x667408(%rip)        # e7f950 <_DYNAMIC+0x338>
  818548:	add    $0x8,%rdi
  81854c:	mov    %rdi,0x10(%rsp)
  818551:	lea    -0x743ab9(%rip),%rsi        # d4a9f <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x4857>
  818558:	lea    0x615789(%rip),%r8        # e2dce8 <__frame_dummy_init_array_entry+0x8a8>
  81855f:	lea    0x10(%rsp),%rcx
  818564:	mov    $0x6,%edx
  818569:	mov    %rax,%rdi
  81856c:	call   *0x6673e6(%rip)        # e7f958 <_DYNAMIC+0x340>
  818572:	add    $0x18,%rsp
  818576:	ret
  818577:	add    $0x8,%rdi
  81857b:	mov    %rdi,0x10(%rsp)
  818580:	lea    0x6157a1(%rip),%rcx        # e2dd28 <__frame_dummy_init_array_entry+0x8e8>
  818587:	mov    %rcx,(%rsp)
  81858b:	lea    -0x743abd(%rip),%rsi        # d4ad5 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x488d>
  818592:	lea    -0x76978d(%rip),%rcx        # aee0c <anon.a16d5d421a76dfd8c37a17b53540311d.67.llvm.14190004212411149437+0x20>
  818599:	lea    0x10(%rsp),%r9
  81859e:	mov    $0x9,%edx
  8185a3:	mov    $0x4,%r8d
  8185a9:	mov    %rax,%rdi
  8185ac:	call   *0x66758e(%rip)        # e7fb40 <_DYNAMIC+0x528>
  8185b2:	add    $0x18,%rsp
  8185b6:	ret
  8185b7:	lea    -0x743ae0(%rip),%rsi        # d4ade <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x4896>
  8185be:	mov    $0xd,%edx
  8185c3:	mov    %rax,%rdi
  8185c6:	add    $0x18,%rsp
  8185ca:	jmp    *0x667380(%rip)        # e7f950 <_DYNAMIC+0x338>

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop bytes=47 frame=0

/tmp/gpui-descending-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000819e20 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>:
  819e20:	mov    0x8(%rdi),%rsi
  819e24:	test   %rsi,%rsi
  819e27:	je     819e4e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  819e29:	mov    %rsi,%rax
  819e2c:	shl    $0x5,%rax
  819e30:	add    %rax,%rsi
  819e33:	add    $0x31,%rsi
  819e37:	je     819e4e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  819e39:	mov    (%rdi),%rdi
  819e3c:	sub    %rax,%rdi
  819e3f:	add    $0xffffffffffffffe0,%rdi
  819e43:	mov    $0x10,%edx
  819e48:	jmp    *0x665a12(%rip)        # e7f860 <_DYNAMIC+0x248>
  819e4e:	ret

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop bytes=47 frame=0

/tmp/gpui-descending-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000819e50 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop>:
  819e50:	mov    0x8(%rdi),%rsi
  819e54:	test   %rsi,%rsi
  819e57:	je     819e7e <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop+0x2e>
  819e59:	mov    %rsi,%rax
  819e5c:	shl    $0x4,%rax
  819e60:	add    %rax,%rsi
  819e63:	add    $0x21,%rsi
  819e67:	je     819e7e <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop+0x2e>
  819e69:	mov    (%rdi),%rdi
  819e6c:	sub    %rax,%rdi
  819e6f:	add    $0xfffffffffffffff0,%rdi
  819e73:	mov    $0x10,%edx
  819e78:	jmp    *0x6659e2(%rip)        # e7f860 <_DYNAMIC+0x248>
  819e7e:	ret

FUNCTION <core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3: usize], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}> bytes=325 frame=72

/tmp/gpui-descending-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081b710 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>>:
  81b710:	push   %r14
  81b712:	push   %rbx
  81b713:	sub    $0x38,%rsp
  81b717:	mov    %rdi,%rbx
  81b71a:	cmpq   $0x0,(%rsi)
  81b71e:	je     81b828 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x118>
  81b724:	movdqu (%rsi),%xmm0
  81b728:	movdqu 0x10(%rsi),%xmm1
  81b72d:	movdqu 0x20(%rsi),%xmm2
  81b732:	movdqa %xmm2,0x20(%rsp)
  81b738:	movdqa %xmm1,0x10(%rsp)
  81b73e:	movdqa %xmm0,(%rsp)
  81b743:	cmpq   $0x0,0x18(%rcx)
  81b748:	je     81b83c <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x12c>
  81b74e:	lea    0x10(%rsp),%rsi
  81b753:	lea    0x20(%rcx),%rdi
  81b757:	mov    %rcx,%r14
  81b75a:	call   821dd0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  81b75f:	mov    %rax,%rsi
  81b762:	shr    $0x39,%rsi
  81b766:	mov    (%r14),%rcx
  81b769:	mov    0x8(%r14),%rdx
  81b76d:	movd   %esi,%xmm0
  81b771:	punpcklbw %xmm0,%xmm0
  81b775:	pshuflw $0x0,%xmm0,%xmm0
  81b77a:	pshufd $0x44,%xmm0,%xmm0
  81b77f:	mov    0x10(%rsp),%rsi
  81b784:	movzwl 0x1c(%rsp),%edi
  81b789:	xor    %r8d,%r8d
  81b78c:	mov    0x18(%rsp),%r9d
  81b791:	pcmpeqd %xmm1,%xmm1
  81b795:	and    %rdx,%rax
  81b798:	movdqu (%rcx,%rax,1),%xmm2
  81b79d:	movdqa %xmm2,%xmm3
  81b7a1:	pcmpeqb %xmm0,%xmm3
  81b7a5:	pmovmskb %xmm3,%r10d
  81b7aa:	test   %r10d,%r10d
  81b7ad:	je     81b7f0 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xe0>
  81b7af:	tzcnt  %r10d,%r14d
  81b7b4:	add    %rax,%r14
  81b7b7:	and    %rdx,%r14
  81b7ba:	shl    $0x5,%r14
  81b7be:	mov    %rcx,%r11
  81b7c1:	sub    %r14,%r11
  81b7c4:	cmp    -0x20(%r11),%rsi
  81b7c8:	jne    81b7d7 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xc7>
  81b7ca:	cmp    -0x14(%r11),%di
  81b7cf:	jne    81b7d7 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xc7>
  81b7d1:	cmp    -0x18(%r11),%r9d
  81b7d5:	je     81b80b <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xfb>
  81b7d7:	lea    -0x1(%r10),%r11d
  81b7db:	and    %r10w,%r11w
  81b7df:	mov    %r11d,%r10d
  81b7e2:	jne    81b7af <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x9f>
  81b7e4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  81b7f0:	pcmpeqb %xmm1,%xmm2
  81b7f4:	pmovmskb %xmm2,%r10d
  81b7f9:	test   %r10d,%r10d
  81b7fc:	jne    81b83c <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x12c>
  81b7fe:	add    %r8,%rax
  81b801:	add    $0x10,%rax
  81b805:	add    $0x10,%r8
  81b809:	jmp    81b795 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x85>
  81b80b:	mov    -0x4(%r11),%eax
  81b80f:	shl    $0x10,%eax
  81b812:	or     -0x8(%r11),%eax
  81b816:	mov    -0x10(%r11),%rcx
  81b81a:	mov    %rcx,(%rbx)
  81b81d:	mov    %eax,0x8(%rbx)
  81b820:	add    $0x38,%rsp
  81b824:	pop    %rbx
  81b825:	pop    %r14
  81b827:	ret
  81b828:	mov    0x8(%rdx),%eax
  81b82b:	mov    %eax,0x8(%rbx)
  81b82e:	mov    (%rdx),%rax
  81b831:	mov    %rax,(%rbx)
  81b834:	add    $0x38,%rsp
  81b838:	pop    %rbx
  81b839:	pop    %r14
  81b83b:	ret
  81b83c:	lea    -0x746956(%rip),%rdi        # d4eed <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x147>
  81b843:	lea    0x612916(%rip),%rdx        # e2e160 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x68>
  81b84a:	mov    $0x16,%esi
  81b84f:	call   *0x664363(%rip)        # e7fbb8 <_DYNAMIC+0x5a0>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Atlas> bytes=210 frame=24

/tmp/gpui-descending-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081bb50 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>:
  81bb50:	push   %r14
  81bb52:	push   %rbx
  81bb53:	push   %rax
  81bb54:	mov    %rdi,%rbx
  81bb57:	mov    (%rdi),%rax
  81bb5a:	lock decq (%rax)
  81bb5e:	jne    81bb69 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x19>
  81bb60:	mov    %rbx,%rdi
  81bb63:	call   *0x663f97(%rip)        # e7fb00 <_DYNAMIC+0x4e8>
  81bb69:	mov    0x50(%rbx),%rax
  81bb6d:	lock decq (%rax)
  81bb71:	jne    81bb7d <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x2d>
  81bb73:	lea    0x50(%rbx),%rdi
  81bb77:	call   *0x663f7b(%rip)        # e7faf8 <_DYNAMIC+0x4e0>
  81bb7d:	mov    0x58(%rbx),%rax
  81bb81:	lock decq (%rax)
  81bb85:	jne    81bb91 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x41>
  81bb87:	lea    0x58(%rbx),%rdi
  81bb8b:	call   *0x663f6f(%rip)        # e7fb00 <_DYNAMIC+0x4e8>
  81bb91:	mov    0xb0(%rbx),%rsi
  81bb98:	test   %rsi,%rsi
  81bb9b:	je     81bbcd <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  81bb9d:	mov    %rsi,%rax
  81bba0:	shl    $0x5,%rax
  81bba4:	add    %rax,%rsi
  81bba7:	add    $0x31,%rsi
  81bbab:	je     81bbcd <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  81bbad:	mov    0xa8(%rbx),%rdi
  81bbb4:	sub    %rax,%rdi
  81bbb7:	add    $0xffffffffffffffe0,%rdi
  81bbbb:	mov    $0x10,%edx
  81bbc0:	add    $0x8,%rsp
  81bbc4:	pop    %rbx
  81bbc5:	pop    %r14
  81bbc7:	jmp    *0x663c93(%rip)        # e7f860 <_DYNAMIC+0x248>
  81bbcd:	add    $0x8,%rsp
  81bbd1:	pop    %rbx
  81bbd2:	pop    %r14
  81bbd4:	ret
  81bbd5:	mov    %rax,%r14
  81bbd8:	jmp    81bc05 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  81bbda:	mov    %rax,%r14
  81bbdd:	mov    0x58(%rbx),%rax
  81bbe1:	lock decq (%rax)
  81bbe5:	jne    81bc05 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  81bbe7:	lea    0x58(%rbx),%rdi
  81bbeb:	call   *0x663f0f(%rip)        # e7fb00 <_DYNAMIC+0x4e8>
  81bbf1:	jmp    81bc05 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  81bbf3:	call   *0x663c6f(%rip)        # e7f868 <_DYNAMIC+0x250>
  81bbf9:	mov    %rax,%r14
  81bbfc:	lea    0x50(%rbx),%rdi
  81bc00:	call   81c4a0 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  81bc05:	add    $0xa8,%rbx
  81bc0c:	mov    %rbx,%rdi
  81bc0f:	call   825500 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>
  81bc14:	mov    %r14,%rdi
  81bc17:	call   e2c400 <_Unwind_Resume@plt>
  81bc1c:	call   *0x663c46(%rip)        # e7f868 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Buffer> bytes=103 frame=24

/tmp/gpui-descending-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081bc30 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>:
  81bc30:	push   %r14
  81bc32:	push   %rbx
  81bc33:	push   %rax
  81bc34:	mov    %rdi,%rbx
  81bc37:	mov    (%rdi),%rax
  81bc3a:	lock decq (%rax)
  81bc3e:	jne    81bc49 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x19>
  81bc40:	mov    %rbx,%rdi
  81bc43:	call   *0x663ed7(%rip)        # e7fb20 <_DYNAMIC+0x508>
  81bc49:	mov    0x8(%rbx),%rax
  81bc4d:	lock decq (%rax)
  81bc51:	jne    81bc67 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x37>
  81bc53:	add    $0x8,%rbx
  81bc57:	mov    %rbx,%rdi
  81bc5a:	add    $0x8,%rsp
  81bc5e:	pop    %rbx
  81bc5f:	pop    %r14
  81bc61:	jmp    *0x663ec1(%rip)        # e7fb28 <_DYNAMIC+0x510>
  81bc67:	add    $0x8,%rsp
  81bc6b:	pop    %rbx
  81bc6c:	pop    %r14
  81bc6e:	ret
  81bc6f:	mov    %rax,%r14
  81bc72:	mov    0x8(%rbx),%rax
  81bc76:	lock decq (%rax)
  81bc7a:	jne    81bc89 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x59>
  81bc7c:	add    $0x8,%rbx
  81bc80:	mov    %rbx,%rdi
  81bc83:	call   *0x663e9f(%rip)        # e7fb28 <_DYNAMIC+0x510>
  81bc89:	mov    %r14,%rdi
  81bc8c:	call   e2c400 <_Unwind_Resume@plt>
  81bc91:	call   *0x663bd1(%rip)        # e7f868 <_DYNAMIC+0x250>

FUNCTION gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}> bytes=590 frame=72

/tmp/gpui-descending-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081c5d0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>>:
  81c5d0:	push   %rbp
  81c5d1:	push   %r15
  81c5d3:	push   %r14
  81c5d5:	push   %r13
  81c5d7:	push   %r12
  81c5d9:	push   %rbx
  81c5da:	sub    $0x18,%rsp
  81c5de:	movss  0x8c(%rdi),%xmm3
  81c5e6:	movss  -0x76d632(%rip),%xmm0        # aefbc <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  81c5ee:	movaps %xmm3,%xmm1
  81c5f1:	subss  %xmm0,%xmm1
  81c5f5:	cvttss2si %xmm1,%rax
  81c5fa:	cvttss2si %xmm3,%r8
  81c5ff:	mov    %r8,%rcx
  81c602:	sar    $0x3f,%rcx
  81c606:	and    %rax,%rcx
  81c609:	or     %r8,%rcx
  81c60c:	xor    %r9d,%r9d
  81c60f:	xorps  %xmm1,%xmm1
  81c612:	ucomiss %xmm1,%xmm3
  81c615:	cmovb  %r9,%rcx
  81c619:	movss  -0x76d661(%rip),%xmm2        # aefc0 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  81c621:	ucomiss %xmm2,%xmm3
  81c624:	mov    $0xffffffffffffffff,%rax
  81c62b:	cmova  %rax,%rcx
  81c62f:	movss  0x94(%rdi),%xmm3
  81c637:	mov    %rcx,%r8
  81c63a:	shr    $0x4,%r8
  81c63e:	movaps %xmm3,%xmm4
  81c641:	subss  %xmm0,%xmm4
  81c645:	cvttss2si %xmm4,%r10
  81c64a:	cvttss2si %xmm3,%r11
  81c64f:	mov    %r11,%rbx
  81c652:	sar    $0x3f,%rbx
  81c656:	and    %r10,%rbx
  81c659:	or     %r11,%rbx
  81c65c:	ucomiss %xmm1,%xmm3
  81c65f:	cmovb  %r9,%rbx
  81c663:	ucomiss %xmm2,%xmm3
  81c666:	cmova  %rax,%rbx
  81c66a:	mov    %rsi,0x10(%rsp)
  81c66f:	lea    (%rcx,%rbx,1),%r9
  81c673:	dec    %r9
  81c676:	shr    $0x4,%r9
  81c67a:	cmp    %r9,%r8
  81c67d:	jbe    81c68e <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xbe>
  81c67f:	add    $0x18,%rsp
  81c683:	pop    %rbx
  81c684:	pop    %r12
  81c686:	pop    %r13
  81c688:	pop    %r14
  81c68a:	pop    %r15
  81c68c:	pop    %rbp
  81c68d:	ret
  81c68e:	movss  0x88(%rdi),%xmm3
  81c696:	movaps %xmm3,%xmm4
  81c699:	subss  %xmm0,%xmm4
  81c69d:	cvttss2si %xmm4,%rsi
  81c6a2:	cvttss2si %xmm3,%r10
  81c6a7:	mov    %r10,%rcx
  81c6aa:	sar    $0x3f,%rcx
  81c6ae:	and    %rsi,%rcx
  81c6b1:	or     %r10,%rcx
  81c6b4:	xor    %r10d,%r10d
  81c6b7:	ucomiss %xmm1,%xmm3
  81c6ba:	cmovb  %r10,%rcx
  81c6be:	ucomiss %xmm2,%xmm3
  81c6c1:	cmova  %rax,%rcx
  81c6c5:	movss  0x90(%rdi),%xmm3
  81c6cd:	mov    %rcx,%rsi
  81c6d0:	shr    $0x4,%rsi
  81c6d4:	movaps %xmm3,%xmm4
  81c6d7:	subss  %xmm0,%xmm4
  81c6db:	cvttss2si %xmm4,%rdi
  81c6e0:	cvttss2si %xmm3,%r11
  81c6e5:	mov    %r11,%rbx
  81c6e8:	sar    $0x3f,%rbx
  81c6ec:	and    %rdi,%rbx
  81c6ef:	or     %r11,%rbx
  81c6f2:	ucomiss %xmm1,%xmm3
  81c6f5:	cmovb  %r10,%rbx
  81c6f9:	ucomiss %xmm2,%xmm3
  81c6fc:	cmova  %rax,%rbx
  81c700:	lea    (%rbx,%rcx,1),%r11
  81c704:	dec    %r11
  81c707:	shr    $0x4,%r11
  81c70b:	mov    %rsi,0x8(%rsp)
  81c710:	cmp    %r11,%rsi
  81c713:	jbe    81c73d <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x16d>
  81c715:	data16 cs nopw 0x0(%rax,%rax,1)
  81c720:	mov    %r8,%rax
  81c723:	cmp    %r9,%r8
  81c726:	adc    $0x0,%r8
  81c72a:	cmp    %r9,%rax
  81c72d:	jae    81c67f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c733:	cmp    %r9,%r8
  81c736:	jbe    81c720 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x150>
  81c738:	jmp    81c67f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c73d:	mov    (%rdx),%rbx
  81c740:	mov    0x8(%rdx),%r14
  81c744:	mov    0x10(%rdx),%rdx
  81c748:	nopl   0x0(%rax,%rax,1)
  81c750:	mov    %r8,%r15
  81c753:	cmp    %r9,%r8
  81c756:	adc    $0x0,%r8
  81c75a:	mov    %r15,%r12
  81c75d:	imul   0x10(%rsp),%r12
  81c763:	mov    0x8(%rsp),%rbp
  81c768:	mov    %rbp,%r13
  81c76b:	nopl   0x0(%rax,%rax,1)
  81c770:	cmp    %r11,%rbp
  81c773:	adc    $0x0,%r13
  81c777:	lea    (%r12,%rbp,1),%rdi
  81c77b:	mov    0x10(%rbx),%rax
  81c77f:	cmp    %rax,%rdi
  81c782:	jae    81c7fb <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x22b>
  81c784:	mov    0x8(%rbx),%rcx
  81c788:	mov    0x4(%rcx,%rdi,8),%r10d
  81c78d:	test   %r10d,%r10d
  81c790:	js     81c7d7 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x207>
  81c792:	mov    (%rcx,%rdi,8),%eax
  81c795:	mov    %eax,%esi
  81c797:	or     %r10d,%esi
  81c79a:	cmp    $0x800000,%esi
  81c7a0:	jb     81c7d7 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x207>
  81c7a2:	xor    %esi,%esi
  81c7a4:	sub    $0x800001,%eax
  81c7a9:	mov    %eax,(%rcx,%rdi,8)
  81c7ac:	setae  %sil
  81c7b0:	shl    $0x17,%esi
  81c7b3:	add    %r10d,%esi
  81c7b6:	add    $0xff800000,%esi
  81c7bc:	mov    %esi,0x4(%rcx,%rdi,8)
  81c7c0:	and    $0x7fffff,%eax
  81c7c5:	mov    0x10(%r14),%rcx
  81c7c9:	cmp    %rax,%rcx
  81c7cc:	jbe    81c80b <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x23b>
  81c7ce:	mov    0x8(%r14),%rcx
  81c7d2:	mov    (%rdx),%esi
  81c7d4:	mov    %esi,(%rcx,%rax,4)
  81c7d7:	cmp    %r11,%rbp
  81c7da:	jae    81c7e4 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x214>
  81c7dc:	mov    %r13,%rbp
  81c7df:	cmp    %r11,%r13
  81c7e2:	jbe    81c770 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x1a0>
  81c7e4:	cmp    %r9,%r15
  81c7e7:	jae    81c67f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c7ed:	cmp    %r9,%r8
  81c7f0:	jbe    81c750 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x180>
  81c7f6:	jmp    81c67f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c7fb:	lea    0x611976(%rip),%rdx        # e2e178 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x80>
  81c802:	mov    %rax,%rsi
  81c805:	call   *0x663305(%rip)        # e7fb10 <_DYNAMIC+0x4f8>
  81c80b:	lea    0x61197e(%rip),%rdx        # e2e190 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x98>
  81c812:	mov    %rax,%rdi
  81c815:	mov    %rcx,%rsi
  81c818:	call   *0x6632f2(%rip)        # e7fb10 <_DYNAMIC+0x4f8>

FUNCTION <gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>> bytes=321 frame=248

/tmp/gpui-descending-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081c820 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>>:
  81c820:	push   %rbp
  81c821:	push   %r15
  81c823:	push   %r14
  81c825:	push   %r13
  81c827:	push   %r12
  81c829:	push   %rbx
  81c82a:	sub    $0xc8,%rsp
  81c831:	mov    %edx,%ebp
  81c833:	mov    %rsi,%r14
  81c836:	mov    %rdi,(%rsp)
  81c83a:	lea    0x8(%rsp),%rdi
  81c83f:	call   *0x66338b(%rip)        # e7fbd0 <_DYNAMIC+0x5b8>
  81c845:	mov    0x8(%rsp),%rsi
  81c84a:	xor    %r13d,%r13d
  81c84d:	test   $0x1,%bpl
  81c851:	je     81c8f0 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0xd0>
  81c857:	test   %rsi,%rsi
  81c85a:	je     81c935 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x115>
  81c860:	lea    0x70(%rsp),%r15
  81c865:	lea    0x8(%rsp),%r12
  81c86a:	mov    0x66335f(%rip),%rbp        # e7fbd0 <_DYNAMIC+0x5b8>
  81c871:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  81c880:	mov    0x18(%rsp),%rbx
  81c885:	cmp    $0x1,%rbx
  81c889:	jbe    81c8d0 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0xb0>
  81c88b:	mov    0x10(%rsp),%rax
  81c890:	mov    (%rax),%edx
  81c892:	mov    %r15,%rdi
  81c895:	call   81c970 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81c89a:	movss  0x74(%rsp),%xmm0
  81c8a0:	xorps  %xmm1,%xmm1
  81c8a3:	ucomiss %xmm1,%xmm0
  81c8a6:	lea    (%rbx,%rbx,1),%rax
  81c8aa:	lea    0x5(%rbx,%rbx,1),%rcx
  81c8af:	lea    (%rax,%rax,2),%rdx
  81c8b3:	mov    %rcx,%rax
  81c8b6:	cmovne %rdx,%rax
  81c8ba:	cmovp  %rdx,%rax
  81c8be:	cmpb   $0x3,0x70(%rsp)
  81c8c3:	cmovne %rcx,%rax
  81c8c7:	jmp    81c8d7 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0xb7>
  81c8c9:	nopl   0x0(%rax)
  81c8d0:	add    %rbx,%rbx
  81c8d3:	lea    (%rbx,%rbx,2),%rax
  81c8d7:	add    %rax,%r13
  81c8da:	jb     81c955 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x135>
  81c8dc:	mov    %r12,%rdi
  81c8df:	mov    %r14,%rsi
  81c8e2:	call   *%rbp
  81c8e4:	mov    0x8(%rsp),%rsi
  81c8e9:	test   %rsi,%rsi
  81c8ec:	jne    81c880 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x60>
  81c8ee:	jmp    81c935 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x115>
  81c8f0:	test   %rsi,%rsi
  81c8f3:	je     81c935 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x115>
  81c8f5:	lea    0x8(%rsp),%r15
  81c8fa:	mov    0x6632cf(%rip),%r12        # e7fbd0 <_DYNAMIC+0x5b8>
  81c901:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  81c910:	mov    %r13,%rax
  81c913:	mov    0x18(%rsp),%rcx
  81c918:	add    %rcx,%rcx
  81c91b:	lea    (%rcx,%rcx,2),%r13
  81c91f:	add    %rax,%r13
  81c922:	jb     81c955 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x135>
  81c924:	mov    %r15,%rdi
  81c927:	mov    %r14,%rsi
  81c92a:	call   *%r12
  81c92d:	cmpq   $0x0,0x8(%rsp)
  81c933:	jne    81c910 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0xf0>
  81c935:	mov    (%rsp),%rax
  81c939:	mov    %r13,0x8(%rax)
  81c93d:	movl   $0xffffffff,(%rax)
  81c943:	add    $0xc8,%rsp
  81c94a:	pop    %rbx
  81c94b:	pop    %r12
  81c94d:	pop    %r13
  81c94f:	pop    %r14
  81c951:	pop    %r15
  81c953:	pop    %rbp
  81c954:	ret
  81c955:	mov    (%rsp),%rax
  81c959:	movl   $0x6,(%rax)
  81c95f:	jmp    81c943 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x123>

FUNCTION <gpui_gpu::renderer::Renderer>::set_grouped_records bytes=95 frame=24

/tmp/gpui-descending-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081cbb0 <<gpui_gpu::renderer::Renderer>::set_grouped_records>:
  81cbb0:	push   %rbp
  81cbb1:	push   %r14
  81cbb3:	push   %rbx
  81cbb4:	cmp    0x329(%rdi),%sil
  81cbbb:	je     81cbfb <<gpui_gpu::renderer::Renderer>::set_grouped_records+0x4b>
  81cbbd:	mov    0x318(%rdi),%rax
  81cbc4:	test   %rax,%rax
  81cbc7:	je     81cbe9 <<gpui_gpu::renderer::Renderer>::set_grouped_records+0x39>
  81cbc9:	lock decq (%rax)
  81cbcd:	jne    81cbe9 <<gpui_gpu::renderer::Renderer>::set_grouped_records+0x39>
  81cbcf:	lea    0x318(%rdi),%rbx
  81cbd6:	mov    %rdi,%r14
  81cbd9:	mov    %rbx,%rdi
  81cbdc:	mov    %esi,%ebp
  81cbde:	call   *0x662f4c(%rip)        # e7fb30 <_DYNAMIC+0x518>
  81cbe4:	mov    %r14,%rdi
  81cbe7:	mov    %ebp,%esi
  81cbe9:	movq   $0x0,0x318(%rdi)
  81cbf4:	mov    %sil,0x329(%rdi)
  81cbfb:	pop    %rbx
  81cbfc:	pop    %r14
  81cbfe:	pop    %rbp
  81cbff:	ret
  81cc00:	movq   $0x0,(%rbx)
  81cc07:	mov    %rax,%rdi
  81cc0a:	call   e2c400 <_Unwind_Resume@plt>

FUNCTION <gpui_gpu::renderer::Buffer>::write bytes=303 frame=120

/tmp/gpui-descending-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081cc10 <<gpui_gpu::renderer::Buffer>::write>:
  81cc10:	push   %r15
  81cc12:	push   %r14
  81cc14:	push   %r13
  81cc16:	push   %r12
  81cc18:	push   %rbx
  81cc19:	sub    $0x50,%rsp
  81cc1d:	mov    %rdx,%r14
  81cc20:	mov    %rdi,%rbx
  81cc23:	cmp    0x20(%rdi),%r8
  81cc27:	jbe    81ccda <<gpui_gpu::renderer::Buffer>::write+0xca>
  81cc2d:	mov    %rcx,%r15
  81cc30:	mov    $0x1,%r13d
  81cc36:	cmp    $0x2,%r8
  81cc3a:	jb     81cc53 <<gpui_gpu::renderer::Buffer>::write+0x43>
  81cc3c:	lea    -0x1(%r8),%rax
  81cc40:	bsr    %rax,%rcx
  81cc44:	not    %ecx
  81cc46:	mov    $0xffffffffffffffff,%r13
  81cc4d:	shr    %cl,%r13
  81cc50:	inc    %r13
  81cc53:	mov    %r8,%r12
  81cc56:	lea    -0x747d5a(%rip),%rax        # d4f03 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x15d>
  81cc5d:	mov    %rax,0x30(%rsp)
  81cc62:	movq   $0xa,0x38(%rsp)
  81cc6b:	mov    %r13,0x40(%rsp)
  81cc70:	movl   $0x88,0x48(%rsp)
  81cc78:	movb   $0x0,0x4c(%rsp)
  81cc7d:	lea    0x8(%rsp),%rdi
  81cc82:	lea    0x30(%rsp),%rdx
  81cc87:	call   *0x662fa3(%rip)        # e7fc30 <_DYNAMIC+0x618>
  81cc8d:	mov    %r13,0x28(%rsp)
  81cc92:	mov    (%rbx),%rax
  81cc95:	lock decq (%rax)
  81cc99:	jne    81cca4 <<gpui_gpu::renderer::Buffer>::write+0x94>
  81cc9b:	mov    %rbx,%rdi
  81cc9e:	call   *0x662e7c(%rip)        # e7fb20 <_DYNAMIC+0x508>
  81cca4:	mov    0x8(%rbx),%rax
  81cca8:	lock decq (%rax)
  81ccac:	jne    81ccb8 <<gpui_gpu::renderer::Buffer>::write+0xa8>
  81ccae:	lea    0x8(%rbx),%rdi
  81ccb2:	call   *0x662e70(%rip)        # e7fb28 <_DYNAMIC+0x510>
  81ccb8:	mov    0x28(%rsp),%rax
  81ccbd:	mov    %rax,0x20(%rbx)
  81ccc1:	movups 0x8(%rsp),%xmm0
  81ccc6:	movups 0x18(%rsp),%xmm1
  81cccb:	movups %xmm1,0x10(%rbx)
  81cccf:	movups %xmm0,(%rbx)
  81ccd2:	mov    %r12,%r8
  81ccd5:	mov    %r15,%rcx
  81ccd8:	jmp    81ccdf <<gpui_gpu::renderer::Buffer>::write+0xcf>
  81ccda:	test   %r8,%r8
  81ccdd:	je     81cced <<gpui_gpu::renderer::Buffer>::write+0xdd>
  81ccdf:	mov    %r14,%rdi
  81cce2:	mov    %rbx,%rsi
  81cce5:	xor    %edx,%edx
  81cce7:	call   *0x662efb(%rip)        # e7fbe8 <_DYNAMIC+0x5d0>
  81cced:	add    $0x50,%rsp
  81ccf1:	pop    %rbx
  81ccf2:	pop    %r12
  81ccf4:	pop    %r13
  81ccf6:	pop    %r14
  81ccf8:	pop    %r15
  81ccfa:	ret
  81ccfb:	mov    %rax,%r14
  81ccfe:	jmp    81cd17 <<gpui_gpu::renderer::Buffer>::write+0x107>
  81cd00:	mov    %rax,%r14
  81cd03:	mov    0x8(%rbx),%rax
  81cd07:	lock decq (%rax)
  81cd0b:	jne    81cd17 <<gpui_gpu::renderer::Buffer>::write+0x107>
  81cd0d:	lea    0x8(%rbx),%rdi
  81cd11:	call   *0x662e11(%rip)        # e7fb28 <_DYNAMIC+0x510>
  81cd17:	mov    0x28(%rsp),%rax
  81cd1c:	mov    %rax,0x20(%rbx)
  81cd20:	movups 0x8(%rsp),%xmm0
  81cd25:	movups 0x18(%rsp),%xmm1
  81cd2a:	movups %xmm1,0x10(%rbx)
  81cd2e:	movups %xmm0,(%rbx)
  81cd31:	mov    %r14,%rdi
  81cd34:	call   e2c400 <_Unwind_Resume@plt>
  81cd39:	call   *0x662b29(%rip)        # e7f868 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::Atlas>::new bytes=706 frame=376

/tmp/gpui-descending-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081cd40 <<gpui_gpu::renderer::Atlas>::new>:
  81cd40:	push   %rbp
  81cd41:	push   %r14
  81cd43:	push   %rbx
  81cd44:	sub    $0x160,%rsp
  81cd4b:	mov    %edx,%ebp
  81cd4d:	mov    %rdi,%rbx
  81cd50:	lea    -0x747e4a(%rip),%rax        # d4f0d <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x167>
  81cd57:	mov    %rax,(%rsp)
  81cd5b:	movq   $0xe,0x8(%rsp)
  81cd64:	mov    %edx,0x10(%rsp)
  81cd68:	mov    %edx,0x14(%rsp)
  81cd6c:	movaps -0x770883(%rip),%xmm0        # ac4f0 <anon.531a4b6c7f642b9eba5e0e986955623b.109.llvm.14547199655466482296+0x2c0>
  81cd73:	movups %xmm0,0x18(%rsp)
  81cd78:	movl   $0x0,0x28(%rsp)
  81cd80:	movl   $0x6,0x34(%rsp)
  81cd88:	movq   $0x4,0x38(%rsp)
  81cd91:	movq   $0x0,0x40(%rsp)
  81cd9a:	lea    0x110(%rsp),%r14
  81cda2:	mov    %rsp,%rdx
  81cda5:	mov    %r14,%rdi
  81cda8:	call   *0x662d0a(%rip)        # e7fab8 <_DYNAMIC+0x4a0>
  81cdae:	movq   $0x0,0x18(%rsp)
  81cdb7:	movl   $0xffffffff,0x30(%rsp)
  81cdbf:	movl   $0x0,(%rsp)
  81cdc6:	movabs $0xffffffff00000000,%rax
  81cdd0:	mov    %rax,0x28(%rsp)
  81cdd5:	movq   $0x0,0x3c(%rsp)
  81cdde:	movl   $0x0,0x8(%rsp)
  81cde6:	movl   $0x0,0x10(%rsp)
  81cdee:	lea    0xb8(%rsp),%rdi
  81cdf6:	mov    %rsp,%rdx
  81cdf9:	mov    %r14,%rsi
  81cdfc:	call   *0x662cbe(%rip)        # e7fac0 <_DYNAMIC+0x4a8>
  81ce02:	movups 0x150(%rsp),%xmm0
  81ce0a:	movaps %xmm0,0xa0(%rsp)
  81ce12:	movups 0x110(%rsp),%xmm0
  81ce1a:	movups 0x120(%rsp),%xmm1
  81ce22:	movups 0x130(%rsp),%xmm2
  81ce2a:	movups 0x140(%rsp),%xmm3
  81ce32:	movaps %xmm3,0x90(%rsp)
  81ce3a:	movaps %xmm2,0x80(%rsp)
  81ce42:	movaps %xmm1,0x70(%rsp)
  81ce47:	movaps %xmm0,0x60(%rsp)
  81ce4c:	mov    0x108(%rsp),%rax
  81ce54:	mov    %rax,0x50(%rsp)
  81ce59:	movups 0xf8(%rsp),%xmm0
  81ce61:	movaps %xmm0,0x40(%rsp)
  81ce66:	movups 0xb8(%rsp),%xmm0
  81ce6e:	movups 0xc8(%rsp),%xmm1
  81ce76:	movups 0xd8(%rsp),%xmm2
  81ce7e:	movups 0xe8(%rsp),%xmm3
  81ce86:	movaps %xmm3,0x30(%rsp)
  81ce8b:	movaps %xmm2,0x20(%rsp)
  81ce90:	movaps %xmm1,0x10(%rsp)
  81ce95:	movaps %xmm0,(%rsp)
  81ce99:	mov    %fs:0x0,%rax
  81cea2:	lea    -0x28(%rax),%rax
  81cea9:	mov    %rax,%r14
  81ceac:	cmpb   $0x1,0x10(%rax)
  81ceb0:	jne    81cf9b <<gpui_gpu::renderer::Atlas>::new+0x25b>
  81ceb6:	mov    (%r14),%rax
  81ceb9:	mov    0x8(%r14),%rdx
  81cebd:	lea    0x1(%rax),%rcx
  81cec1:	mov    %rcx,(%r14)
  81cec4:	movaps 0xa0(%rsp),%xmm0
  81cecc:	movups %xmm0,0x40(%rbx)
  81ced0:	movaps 0x60(%rsp),%xmm0
  81ced5:	movaps 0x70(%rsp),%xmm1
  81ceda:	movaps 0x80(%rsp),%xmm2
  81cee2:	movaps 0x90(%rsp),%xmm3
  81ceea:	movups %xmm3,0x30(%rbx)
  81ceee:	movups %xmm2,0x20(%rbx)
  81cef2:	movups %xmm1,0x10(%rbx)
  81cef6:	movups %xmm0,(%rbx)
  81cef9:	movups 0xb8(%rsp),%xmm0
  81cf01:	movups 0xc8(%rsp),%xmm1
  81cf09:	movups 0xd8(%rsp),%xmm2
  81cf11:	movups 0xe8(%rsp),%xmm3
  81cf19:	movups %xmm0,0x50(%rbx)
  81cf1d:	movups %xmm1,0x60(%rbx)
  81cf21:	movups %xmm2,0x70(%rbx)
  81cf25:	movups %xmm3,0x80(%rbx)
  81cf2c:	movups 0xf8(%rsp),%xmm0
  81cf34:	movups %xmm0,0x90(%rbx)
  81cf3b:	mov    0x108(%rsp),%rcx
  81cf43:	mov    %rcx,0xa0(%rbx)
  81cf4a:	mov    %ebp,0xd8(%rbx)
  81cf50:	movq   $0x0,0xdc(%rbx)
  81cf5b:	movl   $0x0,0xe4(%rbx)
  81cf65:	movups 0x61126c(%rip),%xmm0        # e2e1d8 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xe0>
  81cf6c:	movups %xmm0,0xa8(%rbx)
  81cf73:	movups 0x61126e(%rip),%xmm0        # e2e1e8 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xf0>
  81cf7a:	movups %xmm0,0xb8(%rbx)
  81cf81:	mov    %rax,0xc8(%rbx)
  81cf88:	mov    %rdx,0xd0(%rbx)
  81cf8f:	add    $0x160,%rsp
  81cf96:	pop    %rbx
  81cf97:	pop    %r14
  81cf99:	pop    %rbp
  81cf9a:	ret
  81cf9b:	call   *0x662c97(%rip)        # e7fc38 <_DYNAMIC+0x620>
  81cfa1:	mov    %rax,(%r14)
  81cfa4:	mov    %rdx,0x8(%r14)
  81cfa8:	movb   $0x1,0x10(%r14)
  81cfad:	jmp    81cebd <<gpui_gpu::renderer::Atlas>::new+0x17d>
  81cfb2:	mov    %rax,%rbx
  81cfb5:	mov    %rsp,%rdi
  81cfb8:	call   81c4a0 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  81cfbd:	mov    0x60(%rsp),%rax
  81cfc2:	lock decq (%rax)
  81cfc6:	jne    81cff4 <<gpui_gpu::renderer::Atlas>::new+0x2b4>
  81cfc8:	lea    0x60(%rsp),%rdi
  81cfcd:	call   *0x662b2d(%rip)        # e7fb00 <_DYNAMIC+0x4e8>
  81cfd3:	jmp    81cff4 <<gpui_gpu::renderer::Atlas>::new+0x2b4>
  81cfd5:	mov    %rax,%rbx
  81cfd8:	mov    0x110(%rsp),%rax
  81cfe0:	lock decq (%rax)
  81cfe4:	jne    81cff4 <<gpui_gpu::renderer::Atlas>::new+0x2b4>
  81cfe6:	lea    0x110(%rsp),%rdi
  81cfee:	call   *0x662b0c(%rip)        # e7fb00 <_DYNAMIC+0x4e8>
  81cff4:	mov    %rbx,%rdi
  81cff7:	call   e2c400 <_Unwind_Resume@plt>
  81cffc:	call   *0x662866(%rip)        # e7f868 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::Atlas>::insert bytes=608 frame=152

/tmp/gpui-descending-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081d010 <<gpui_gpu::renderer::Atlas>::insert>:
  81d010:	push   %rbp
  81d011:	push   %r15
  81d013:	push   %r14
  81d015:	push   %r13
  81d017:	push   %r12
  81d019:	push   %rbx
  81d01a:	sub    $0x68,%rsp
  81d01e:	mov    %rdx,%r12
  81d021:	mov    %rsi,%r15
  81d024:	mov    %rdi,%r14
  81d027:	lea    0x10(%rdx),%r13
  81d02b:	cmpq   $0x0,0xc0(%rdi)
  81d033:	je     81d0fb <<gpui_gpu::renderer::Atlas>::insert+0xeb>
  81d039:	lea    0xc8(%r14),%rdi
  81d040:	mov    %r13,%rsi
  81d043:	call   821dd0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  81d048:	mov    %rax,%rsi
  81d04b:	shr    $0x39,%rsi
  81d04f:	mov    0xa8(%r14),%rcx
  81d056:	mov    0xb0(%r14),%rdx
  81d05d:	movd   %esi,%xmm0
  81d061:	punpcklbw %xmm0,%xmm0
  81d065:	pshuflw $0x0,%xmm0,%xmm0
  81d06a:	pshufd $0x44,%xmm0,%xmm0
  81d06f:	mov    0x10(%r12),%rsi
  81d074:	movzwl 0x1c(%r12),%edi
  81d07a:	mov    0x18(%r12),%r8d
  81d07f:	pcmpeqd %xmm1,%xmm1
  81d083:	xor    %r9d,%r9d
  81d086:	and    %rdx,%rax
  81d089:	movdqu (%rcx,%rax,1),%xmm2
  81d08e:	movdqa %xmm2,%xmm3
  81d092:	pcmpeqb %xmm0,%xmm3
  81d096:	pmovmskb %xmm3,%r10d
  81d09b:	test   %r10d,%r10d
  81d09e:	je     81d0e0 <<gpui_gpu::renderer::Atlas>::insert+0xd0>
  81d0a0:	tzcnt  %r10d,%ebx
  81d0a5:	add    %rax,%rbx
  81d0a8:	and    %rdx,%rbx
  81d0ab:	shl    $0x5,%rbx
  81d0af:	mov    %rcx,%r11
  81d0b2:	sub    %rbx,%r11
  81d0b5:	cmp    -0x20(%r11),%rsi
  81d0b9:	jne    81d0cc <<gpui_gpu::renderer::Atlas>::insert+0xbc>
  81d0bb:	cmp    -0x14(%r11),%di
  81d0c0:	jne    81d0cc <<gpui_gpu::renderer::Atlas>::insert+0xbc>
  81d0c2:	cmp    -0x18(%r11),%r8d
  81d0c6:	je     81d163 <<gpui_gpu::renderer::Atlas>::insert+0x153>
  81d0cc:	lea    -0x1(%r10),%r11d
  81d0d0:	and    %r10w,%r11w
  81d0d4:	mov    %r11d,%r10d
  81d0d7:	jne    81d0a0 <<gpui_gpu::renderer::Atlas>::insert+0x90>
  81d0d9:	nopl   0x0(%rax)
  81d0e0:	pcmpeqb %xmm1,%xmm2
  81d0e4:	pmovmskb %xmm2,%r10d
  81d0e9:	test   %r10d,%r10d
  81d0ec:	jne    81d0fb <<gpui_gpu::renderer::Atlas>::insert+0xeb>
  81d0ee:	add    %r9,%rax
  81d0f1:	add    $0x10,%rax
  81d0f5:	add    $0x10,%r9
  81d0f9:	jmp    81d086 <<gpui_gpu::renderer::Atlas>::insert+0x76>
  81d0fb:	mov    0x20(%r12),%ebp
  81d100:	xor    %eax,%eax
  81d102:	test   %ebp,%ebp
  81d104:	je     81d15e <<gpui_gpu::renderer::Atlas>::insert+0x14e>
  81d106:	mov    %r15,%rdi
  81d109:	mov    0x28(%r12),%r15d
  81d10e:	test   %r15d,%r15d
  81d111:	je     81d15e <<gpui_gpu::renderer::Atlas>::insert+0x14e>
  81d113:	mov    0xd8(%r14),%ecx
  81d11a:	cmp    %ebp,%ecx
  81d11c:	jb     81d261 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81d122:	cmp    %r15d,%ecx
  81d125:	jb     81d261 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81d12b:	mov    %r13,0x40(%rsp)
  81d130:	mov    0xdc(%r14),%r8d
  81d137:	mov    0xe4(%r14),%r13d
  81d13e:	lea    (%r8,%rbp,1),%edx
  81d142:	xor    %eax,%eax
  81d144:	cmp    %ecx,%edx
  81d146:	mov    $0x0,%ebx
  81d14b:	cmova  %r13d,%ebx
  81d14f:	add    0xe0(%r14),%ebx
  81d156:	lea    (%rbx,%r15,1),%esi
  81d15a:	cmp    %ecx,%esi
  81d15c:	jbe    81d16f <<gpui_gpu::renderer::Atlas>::insert+0x15f>
  81d15e:	jmp    81d261 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81d163:	mov    $0x1,%eax
  81d168:	xor    %edx,%edx
  81d16a:	jmp    81d261 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81d16f:	cmp    %r13d,%r15d
  81d172:	cmova  %r15d,%r13d
  81d176:	cmp    %ecx,%edx
  81d178:	cmova  %eax,%r8d
  81d17c:	lea    0xa8(%r14),%rax
  81d183:	mov    %rax,0x38(%rsp)
  81d188:	mov    %r14,0x48(%rsp)
  81d18d:	movl   $0x0,0x50(%rsp)
  81d195:	mov    %r8d,0x54(%rsp)
  81d19a:	mov    %ebx,0x58(%rsp)
  81d19e:	movq   $0x0,0x5c(%rsp)
  81d1a7:	mov    (%r12),%rdx
  81d1ab:	mov    0x8(%r12),%rcx
  81d1b0:	mov    %rcx,0x30(%rsp)
  81d1b5:	movq   $0x0,0x8(%rsp)
  81d1be:	movl   $0x1,0x10(%rsp)
  81d1c6:	mov    %ebp,0x14(%rsp)
  81d1ca:	movl   $0x1,0x18(%rsp)
  81d1d2:	mov    %r15d,0x1c(%rsp)
  81d1d7:	mov    %ebp,0x20(%rsp)
  81d1db:	mov    %r15d,0x24(%rsp)
  81d1e0:	movl   $0x1,0x28(%rsp)
  81d1e8:	cmova  %r15d,%r13d
  81d1ec:	lea    0x48(%rsp),%rsi
  81d1f1:	mov    %r8,%r12
  81d1f4:	lea    0x8(%rsp),%r8
  81d1f9:	lea    0x20(%rsp),%r9
  81d1fe:	call   *0x662a3c(%rip)        # e7fc40 <_DYNAMIC+0x628>
  81d204:	lea    (%r12,%rbp,1),%eax
  81d208:	mov    %eax,0xdc(%r14)
  81d20f:	mov    %ebx,0xe0(%r14)
  81d216:	mov    %r13d,0xe4(%r14)
  81d21d:	mov    0x40(%rsp),%rax
  81d222:	movdqu (%rax),%xmm0
  81d226:	movdqa %xmm0,0x20(%rsp)
  81d22c:	mov    %r12d,0x8(%rsp)
  81d231:	mov    %ebx,0xc(%rsp)
  81d235:	mov    %ebp,0x10(%rsp)
  81d239:	mov    %r15d,0x14(%rsp)
  81d23e:	lea    0x48(%rsp),%rdi
  81d243:	lea    0x20(%rsp),%rdx
  81d248:	lea    0x8(%rsp),%rcx
  81d24d:	mov    0x38(%rsp),%rsi
  81d252:	call   823600 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert>
  81d257:	mov    0x30(%rsp),%rdx
  81d25c:	mov    $0x1,%eax
  81d261:	add    $0x68,%rsp
  81d265:	pop    %rbx
  81d266:	pop    %r12
  81d268:	pop    %r13
  81d26a:	pop    %r14
  81d26c:	pop    %r15
  81d26e:	pop    %rbp
  81d26f:	ret

FUNCTION <gpui_gpu::renderer::GpuContext>::submit bytes=469 frame=1384

/tmp/gpui-descending-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081d270 <<gpui_gpu::renderer::GpuContext>::submit>:
  81d270:	push   %r15
  81d272:	push   %r14
  81d274:	push   %r12
  81d276:	push   %rbx
  81d277:	sub    $0x548,%rsp
  81d27e:	mov    %rdx,%r14
  81d281:	mov    %rsi,%r12
  81d284:	mov    %rdi,%rbx
  81d287:	lea    0x610ffa(%rip),%rdx        # e2e288 <anon.e7af5e0dba0d7261d22cb76253955a85.28.llvm.5458571228094894073>
  81d28e:	lea    0x30(%rsp),%r15
  81d293:	mov    %r15,%rdi
  81d296:	mov    %rbx,%rsi
  81d299:	call   *0x6629a9(%rip)        # e7fc48 <_DYNAMIC+0x630>
  81d29f:	xorps  %xmm0,%xmm0
  81d2a2:	movups %xmm0,0x10(%rsp)
  81d2a7:	movups %xmm0,0x20(%rsp)
  81d2ac:	movl   $0x0,0x50(%rsp)
  81d2b4:	movb   $0x0,0x58(%rsp)
  81d2b9:	movups 0x9(%rsp),%xmm0
  81d2be:	movups %xmm0,0x59(%rsp)
  81d2c3:	movups 0x19(%rsp),%xmm0
  81d2c8:	movups %xmm0,0x69(%rsp)
  81d2cd:	mov    0x28(%rsp),%rax
  81d2d2:	mov    %rax,0x78(%rsp)
  81d2d7:	movl   $0x0,0x80(%rsp)
  81d2e2:	mov    %r12,0x88(%rsp)
  81d2ea:	movq   $0x0,0x90(%rsp)
  81d2f6:	lea    -0x7483e2(%rip),%rax        # d4f1b <anon.e7af5e0dba0d7261d22cb76253955a85.27.llvm.5458571228094894073>
  81d2fd:	mov    %rax,0xe0(%rsp)
  81d305:	movq   $0xa,0xe8(%rsp)
  81d311:	lea    0x50(%rsp),%rax
  81d316:	mov    %rax,0xd0(%rsp)
  81d31e:	movq   $0x1,0xd8(%rsp)
  81d32a:	movl   $0xffffffff,0xb8(%rsp)
  81d335:	movl   $0x2,0x98(%rsp)
  81d340:	movq   $0x0,0xf0(%rsp)
  81d34c:	movl   $0x0,0xf8(%rsp)
  81d357:	lea    0x100(%rsp),%rdi
  81d35f:	lea    0x98(%rsp),%rdx
  81d367:	mov    %r15,%rsi
  81d36a:	call   *0x6628e0(%rip)        # e7fc50 <_DYNAMIC+0x638>
  81d370:	lea    0x10(%rbx),%rsi
  81d374:	lea    0x100(%rsp),%rdi
  81d37c:	call   *0x6628d6(%rip)        # e7fc58 <_DYNAMIC+0x640>
  81d382:	lea    0x100(%rsp),%rdi
  81d38a:	mov    $0x4,%ecx
  81d38f:	xor    %esi,%esi
  81d391:	mov    %r14,%rdx
  81d394:	xor    %r8d,%r8d
  81d397:	call   *0x6628c3(%rip)        # e7fc60 <_DYNAMIC+0x648>
  81d39d:	lea    0x100(%rsp),%rdi
  81d3a5:	xor    %esi,%esi
  81d3a7:	mov    $0x3,%edx
  81d3ac:	xor    %ecx,%ecx
  81d3ae:	mov    $0x1,%r8d
  81d3b4:	call   *0x6628ae(%rip)        # e7fc68 <_DYNAMIC+0x650>
  81d3ba:	lea    0x100(%rsp),%rdi
  81d3c2:	call   81c3a0 <core::ptr::drop_glue::<wgpu::api::render_pass::RenderPass>>
  81d3c7:	movups 0x30(%rsp),%xmm0
  81d3cc:	movups 0x40(%rsp),%xmm1
  81d3d1:	movaps %xmm1,0x110(%rsp)
  81d3d9:	movaps %xmm0,0x100(%rsp)
  81d3e1:	lea    0x98(%rsp),%r14
  81d3e9:	lea    0x100(%rsp),%rsi
  81d3f1:	mov    %r14,%rdi
  81d3f4:	call   *0x662876(%rip)        # e7fc70 <_DYNAMIC+0x658>
  81d3fa:	add    $0x8,%rbx
  81d3fe:	mov    %rbx,%rdi
  81d401:	mov    %r14,%rsi
  81d404:	call   825530 <<wgpu::api::queue::Queue>::submit::<[wgpu::api::command_buffer::CommandBuffer; 1]>>
  81d409:	add    $0x548,%rsp
  81d410:	pop    %rbx
  81d411:	pop    %r12
  81d413:	pop    %r14
  81d415:	pop    %r15
  81d417:	ret
  81d418:	mov    %rax,%rbx
  81d41b:	jmp    81d42d <<gpui_gpu::renderer::GpuContext>::submit+0x1bd>
  81d41d:	mov    %rax,%rbx
  81d420:	lea    0x100(%rsp),%rdi
  81d428:	call   81c3a0 <core::ptr::drop_glue::<wgpu::api::render_pass::RenderPass>>
  81d42d:	lea    0x30(%rsp),%rdi
  81d432:	call   81c510 <core::ptr::drop_glue::<wgpu::api::command_encoder::CommandEncoder>>
  81d437:	mov    %rbx,%rdi
  81d43a:	call   e2c400 <_Unwind_Resume@plt>
  81d43f:	call   *0x662423(%rip)        # e7f868 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::RendererState>::correction bytes=981 frame=184

/tmp/gpui-descending-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081d450 <<gpui_gpu::renderer::RendererState>::correction>:
  81d450:	push   %r15
  81d452:	push   %r14
  81d454:	push   %r13
  81d456:	push   %r12
  81d458:	push   %rbx
  81d459:	sub    $0x90,%rsp
  81d460:	mov    %rdi,%rbx
  81d463:	movss  (%rdx),%xmm1
  81d467:	movss  0x8(%rdx),%xmm2
  81d46c:	movaps %xmm1,%xmm0
  81d46f:	addss  %xmm2,%xmm0
  81d473:	movd   %xmm0,%eax
  81d477:	and    $0x7fffffff,%eax
  81d47c:	xorps  %xmm8,%xmm8
  81d480:	xorps  %xmm9,%xmm9
  81d484:	cmp    $0x7f7fffff,%eax
  81d489:	jg     81d4a8 <<gpui_gpu::renderer::RendererState>::correction+0x58>
  81d48b:	cvtss2sd %xmm1,%xmm1
  81d48f:	cvtss2sd %xmm2,%xmm2
  81d493:	cvtss2sd %xmm0,%xmm0
  81d497:	addsd  %xmm1,%xmm2
  81d49b:	subsd  %xmm0,%xmm2
  81d49f:	xorps  %xmm9,%xmm9
  81d4a3:	cvtsd2ss %xmm2,%xmm9
  81d4a8:	movupd (%rsi),%xmm0
  81d4ac:	movupd 0x8(%rsi),%xmm1
  81d4b1:	movsd  0x10(%rsi),%xmm2
  81d4b6:	movsd  0x18(%rsi),%xmm3
  81d4bb:	movupd 0x20(%rsi),%xmm4
  81d4c0:	movss  0x4(%rdx),%xmm6
  81d4c5:	movss  0xc(%rdx),%xmm7
  81d4ca:	movaps %xmm6,%xmm5
  81d4cd:	addss  %xmm7,%xmm5
  81d4d1:	movd   %xmm5,%eax
  81d4d5:	and    $0x7fffffff,%eax
  81d4da:	cmp    $0x7f7fffff,%eax
  81d4df:	jg     81d4fe <<gpui_gpu::renderer::RendererState>::correction+0xae>
  81d4e1:	cvtss2sd %xmm6,%xmm6
  81d4e5:	cvtss2sd %xmm7,%xmm7
  81d4e9:	cvtss2sd %xmm5,%xmm5
  81d4ed:	addsd  %xmm6,%xmm7
  81d4f1:	subsd  %xmm5,%xmm7
  81d4f5:	xorps  %xmm8,%xmm8
  81d4f9:	cvtsd2ss %xmm7,%xmm8
  81d4fe:	cvtpd2ps %xmm4,%xmm5
  81d502:	cvtps2pd %xmm5,%xmm5
  81d505:	subpd  %xmm5,%xmm4
  81d509:	cvtpd2ps %xmm4,%xmm4
  81d50d:	unpcklpd %xmm3,%xmm1
  81d511:	cvtpd2ps %xmm1,%xmm3
  81d515:	unpcklpd %xmm2,%xmm0
  81d519:	cvtpd2ps %xmm0,%xmm2
  81d51d:	cvtps2pd %xmm3,%xmm3
  81d520:	subpd  %xmm3,%xmm1
  81d524:	cvtpd2ps %xmm1,%xmm5
  81d528:	cvtps2pd %xmm2,%xmm1
  81d52b:	subpd  %xmm1,%xmm0
  81d52f:	cvtpd2ps %xmm0,%xmm6
  81d533:	movapd %xmm6,%xmm0
  81d537:	unpcklps %xmm5,%xmm0
  81d53a:	movaps %xmm8,%xmm1
  81d53e:	movlhps %xmm9,%xmm1
  81d542:	movapd %xmm4,%xmm2
  81d546:	shufps $0x24,%xmm1,%xmm2
  81d54a:	xorps  %xmm1,%xmm1
  81d54d:	movapd %xmm0,%xmm3
  81d551:	cmpneqps %xmm1,%xmm3
  81d555:	cmpneqps %xmm1,%xmm2
  81d559:	packssdw %xmm2,%xmm3
  81d55d:	pmovmskb %xmm3,%eax
  81d561:	test   %eax,%eax
  81d563:	je     81d687 <<gpui_gpu::renderer::RendererState>::correction+0x237>
  81d569:	movapd %xmm6,0x60(%rsp)
  81d56f:	movapd %xmm5,0x70(%rsp)
  81d575:	lea    0x8(%rsp),%r12
  81d57a:	movapd %xmm0,(%rsp)
  81d57f:	movapd %xmm4,0x80(%rsp)
  81d588:	movlpd %xmm4,0x10(%rsp)
  81d58e:	movss  %xmm9,0x18(%rsp)
  81d595:	movss  %xmm8,0x1c(%rsp)
  81d59c:	lea    0x300(%rbx),%r14
  81d5a3:	mov    %rsp,%rsi
  81d5a6:	mov    %r14,%rdi
  81d5a9:	movaps %xmm8,0x30(%rsp)
  81d5af:	movaps %xmm9,0x20(%rsp)
  81d5b5:	call   821c50 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&[u32; 8]>>
  81d5ba:	movapd 0x20(%rsp),%xmm6
  81d5c0:	movapd 0x30(%rsp),%xmm5
  81d5c6:	mov    %rax,%r15
  81d5c9:	shr    $0x39,%r15
  81d5cd:	mov    0x2e0(%rbx),%rcx
  81d5d4:	mov    0x2e8(%rbx),%rdx
  81d5db:	movd   %r15d,%xmm0
  81d5e0:	punpcklbw %xmm0,%xmm0
  81d5e4:	pshuflw $0x0,%xmm0,%xmm0
  81d5e9:	pshufd $0x44,%xmm0,%xmm0
  81d5ee:	xor    %esi,%esi
  81d5f0:	pcmpeqd %xmm1,%xmm1
  81d5f4:	mov    %rax,%rdi
  81d5f7:	and    %rdx,%rdi
  81d5fa:	movdqu (%rcx,%rdi,1),%xmm2
  81d5ff:	movdqa %xmm2,%xmm3
  81d603:	pcmpeqb %xmm0,%xmm3
  81d607:	pmovmskb %xmm3,%r8d
  81d60c:	test   %r8d,%r8d
  81d60f:	je     81d660 <<gpui_gpu::renderer::RendererState>::correction+0x210>
  81d611:	tzcnt  %r8d,%r9d
  81d616:	add    %rdi,%r9
  81d619:	and    %rdx,%r9
  81d61c:	neg    %r9
  81d61f:	lea    (%r9,%r9,8),%r9
  81d623:	movdqu -0x24(%rcx,%r9,4),%xmm3
  81d62a:	movdqu -0x14(%rcx,%r9,4),%xmm4
  81d631:	pcmpeqb 0x10(%rsp),%xmm4
  81d637:	pcmpeqb (%rsp),%xmm3
  81d63c:	pand   %xmm4,%xmm3
  81d640:	pmovmskb %xmm3,%r10d
  81d645:	cmp    $0xffff,%r10d
  81d64c:	je     81d67e <<gpui_gpu::renderer::RendererState>::correction+0x22e>
  81d64e:	lea    -0x1(%r8),%r9d
  81d652:	and    %r8w,%r9w
  81d656:	mov    %r9d,%r8d
  81d659:	jne    81d611 <<gpui_gpu::renderer::RendererState>::correction+0x1c1>
  81d65b:	nopl   0x0(%rax,%rax,1)
  81d660:	pcmpeqb %xmm1,%xmm2
  81d664:	pmovmskb %xmm2,%r8d
  81d669:	test   %r8d,%r8d
  81d66c:	jne    81d68e <<gpui_gpu::renderer::RendererState>::correction+0x23e>
  81d66e:	add    %rsi,%rdi
  81d671:	add    $0x10,%rdi
  81d675:	add    $0x10,%rsi
  81d679:	jmp    81d5f7 <<gpui_gpu::renderer::RendererState>::correction+0x1a7>
  81d67e:	lea    (%rcx,%r9,4),%rdx
  81d682:	jmp    81d7a9 <<gpui_gpu::renderer::RendererState>::correction+0x359>
  81d687:	xor    %eax,%eax
  81d689:	jmp    81d7ac <<gpui_gpu::renderer::RendererState>::correction+0x35c>
  81d68e:	cmpq   $0x0,0x2f0(%rbx)
  81d696:	je     81d7df <<gpui_gpu::renderer::RendererState>::correction+0x38f>
  81d69c:	mov    (%rsp),%r14
  81d6a0:	mov    0x10(%r12),%rcx
  81d6a5:	mov    %rcx,0x50(%rsp)
  81d6aa:	movups (%r12),%xmm0
  81d6af:	movaps %xmm0,0x40(%rsp)
  81d6b4:	mov    0x58(%rbx),%r12
  81d6b8:	cmp    0x48(%rbx),%r12
  81d6bc:	jne    81d6da <<gpui_gpu::renderer::RendererState>::correction+0x28a>
  81d6be:	lea    0x48(%rbx),%rdi
  81d6c2:	mov    %rax,%r13
  81d6c5:	call   *0x6624fd(%rip)        # e7fbc8 <_DYNAMIC+0x5b0>
  81d6cb:	movapd 0x20(%rsp),%xmm6
  81d6d1:	movapd 0x30(%rsp),%xmm5
  81d6d7:	mov    %r13,%rax
  81d6da:	mov    0x50(%rbx),%rcx
  81d6de:	mov    %r12,%rdx
  81d6e1:	shl    $0x5,%rdx
  81d6e5:	movaps 0x60(%rsp),%xmm0
  81d6ea:	movlps %xmm0,(%rcx,%rdx,1)
  81d6ee:	movaps 0x80(%rsp),%xmm0
  81d6f6:	movss  %xmm0,0x8(%rcx,%rdx,1)
  81d6fc:	movss  %xmm6,0xc(%rcx,%rdx,1)
  81d702:	movdqa 0x70(%rsp),%xmm1
  81d708:	movq   %xmm1,0x10(%rcx,%rdx,1)
  81d70e:	shufps $0x55,%xmm0,%xmm0
  81d712:	movss  %xmm0,0x18(%rcx,%rdx,1)
  81d718:	movss  %xmm5,0x1c(%rcx,%rdx,1)
  81d71e:	lea    0x1(%r12),%rcx
  81d723:	mov    %rcx,0x58(%rbx)
  81d727:	mov    0x2e0(%rbx),%rcx
  81d72e:	mov    0x2e8(%rbx),%rdx
  81d735:	and    %rdx,%rax
  81d738:	movdqu (%rcx,%rax,1),%xmm0
  81d73d:	pmovmskb %xmm0,%esi
  81d741:	test   %esi,%esi
  81d743:	je     81d7bd <<gpui_gpu::renderer::RendererState>::correction+0x36d>
  81d745:	tzcnt  %esi,%esi
  81d749:	add    %rax,%rsi
  81d74c:	and    %rdx,%rsi
  81d74f:	movzbl (%rcx,%rsi,1),%eax
  81d753:	test   %al,%al
  81d755:	jns    81d810 <<gpui_gpu::renderer::RendererState>::correction+0x3c0>
  81d75b:	lea    -0x10(%rsi),%rdi
  81d75f:	and    %rdx,%rdi
  81d762:	mov    %r15b,(%rcx,%rsi,1)
  81d766:	mov    %r15b,0x10(%rcx,%rdi,1)
  81d76b:	neg    %rsi
  81d76e:	lea    (%rsi,%rsi,8),%rsi
  81d772:	lea    (%rcx,%rsi,4),%rdx
  81d776:	and    $0x1,%al
  81d778:	movzbl %al,%eax
  81d77b:	sub    %rax,0x2f0(%rbx)
  81d782:	mov    %r14,-0x24(%rcx,%rsi,4)
  81d787:	movdqa 0x40(%rsp),%xmm0
  81d78d:	movdqu %xmm0,-0x1c(%rcx,%rsi,4)
  81d793:	mov    0x50(%rsp),%rax
  81d798:	mov    %rax,-0xc(%rcx,%rsi,4)
  81d79d:	mov    %r12d,-0x4(%rcx,%rsi,4)
  81d7a2:	incq   0x2f8(%rbx)
  81d7a9:	mov    -0x4(%rdx),%eax
  81d7ac:	add    $0x90,%rsp
  81d7b3:	pop    %rbx
  81d7b4:	pop    %r12
  81d7b6:	pop    %r13
  81d7b8:	pop    %r14
  81d7ba:	pop    %r15
  81d7bc:	ret
  81d7bd:	mov    $0x10,%edi
  81d7c2:	add    %rdi,%rax
  81d7c5:	and    %rdx,%rax
  81d7c8:	movdqu (%rcx,%rax,1),%xmm0
  81d7cd:	pmovmskb %xmm0,%esi
  81d7d1:	add    $0x10,%rdi
  81d7d5:	test   %esi,%esi
  81d7d7:	jne    81d745 <<gpui_gpu::renderer::RendererState>::correction+0x2f5>
  81d7dd:	jmp    81d7c2 <<gpui_gpu::renderer::RendererState>::correction+0x372>
  81d7df:	lea    0x2e0(%rbx),%rdi
  81d7e6:	mov    $0x1,%esi
  81d7eb:	mov    %r14,%rdx
  81d7ee:	mov    $0x1,%ecx
  81d7f3:	mov    %rax,%r14
  81d7f6:	call   *0x66247c(%rip)        # e7fc78 <_DYNAMIC+0x660>
  81d7fc:	movapd 0x20(%rsp),%xmm6
  81d802:	movapd 0x30(%rsp),%xmm5
  81d808:	mov    %r14,%rax
  81d80b:	jmp    81d69c <<gpui_gpu::renderer::RendererState>::correction+0x24c>
  81d810:	movdqa (%rcx),%xmm0
  81d814:	pmovmskb %xmm0,%eax
  81d818:	tzcnt  %eax,%esi
  81d81c:	movzbl (%rcx,%rsi,1),%eax
  81d820:	jmp    81d75b <<gpui_gpu::renderer::RendererState>::correction+0x30b>

FUNCTION <gpui_gpu::renderer::RendererState>::prepare_atlas bytes=663 frame=600

/tmp/gpui-descending-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081d830 <<gpui_gpu::renderer::RendererState>::prepare_atlas>:
  81d830:	push   %rbp
  81d831:	push   %r15
  81d833:	push   %r14
  81d835:	push   %r13
  81d837:	push   %r12
  81d839:	push   %rbx
  81d83a:	sub    $0x228,%rsp
  81d841:	mov    %rsi,%r14
  81d844:	test   %r8d,%r8d
  81d847:	je     81d8db <<gpui_gpu::renderer::RendererState>::prepare_atlas+0xab>
  81d84d:	mov    %rdi,0x10(%rsp)
  81d852:	mov    0x110(%rcx),%rbp
  81d859:	test   %rbp,%rbp
  81d85c:	je     81d93f <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x10f>
  81d862:	mov    0x108(%rcx),%r13
  81d869:	shl    $0x3,%rbp
  81d86d:	mov    %r14,0x8(%rsp)
  81d872:	lea    0x60(%r14),%rdi
  81d876:	mov    %rdx,0x18(%rsp)
  81d87b:	lea    0x8(%rdx),%rax
  81d87f:	mov    %rax,0x20(%rsp)
  81d884:	xor    %ebx,%ebx
  81d886:	lea    0x28(%rsp),%r15
  81d88b:	xor    %r12d,%r12d
  81d88e:	xchg   %ax,%ax
  81d890:	mov    0x0(%r13,%r12,1),%rax
  81d895:	movups 0x28(%rax),%xmm0
  81d899:	lea    0x38(%rsp),%rcx
  81d89e:	movups %xmm0,(%rcx)
  81d8a1:	movups 0x18(%rax),%xmm0
  81d8a5:	movups %xmm0,0x28(%rsp)
  81d8aa:	movups 0x38(%rax),%xmm0
  81d8ae:	movups %xmm0,0x48(%rsp)
  81d8b3:	mov    %rdi,%r14
  81d8b6:	mov    0x20(%rsp),%rsi
  81d8bb:	mov    %r15,%rdx
  81d8be:	call   81d010 <<gpui_gpu::renderer::Atlas>::insert>
  81d8c3:	test   $0x1,%al
  81d8c5:	je     81d946 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x116>
  81d8c7:	add    %rdx,%rbx
  81d8ca:	add    $0x8,%r12
  81d8ce:	cmp    %r12,%rbp
  81d8d1:	mov    %r14,%rdi
  81d8d4:	jne    81d890 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x60>
  81d8d6:	jmp    81da4e <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x21e>
  81d8db:	cmpl   $0x1,0x138(%r14)
  81d8e3:	jne    81d8f5 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0xc5>
  81d8e5:	mov    0x120(%r14),%rax
  81d8ec:	add    0x118(%r14),%rax
  81d8f3:	je     81d92c <<gpui_gpu::renderer::RendererState>::prepare_atlas+0xfc>
  81d8f5:	mov    %rdi,%rbx
  81d8f8:	add    $0x60,%r14
  81d8fc:	lea    0x58(%rsp),%rdi
  81d901:	mov    %rdx,%rsi
  81d904:	mov    $0x1,%edx
  81d909:	call   81cd40 <<gpui_gpu::renderer::Atlas>::new>
  81d90e:	mov    %r14,%rdi
  81d911:	call   81bb50 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81d916:	lea    0x58(%rsp),%rsi
  81d91b:	mov    $0xe8,%edx
  81d920:	mov    %r14,%rdi
  81d923:	call   *0x661f8f(%rip)        # e7f8b8 <memcpy@GLIBC_2.14>
  81d929:	mov    %rbx,%rdi
  81d92c:	movq   $0x0,0x8(%rdi)
  81d934:	movl   $0xffffffff,(%rdi)
  81d93a:	jmp    81da5d <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x22d>
  81d93f:	xor    %ebx,%ebx
  81d941:	jmp    81da4e <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x21e>
  81d946:	mov    0x8(%rsp),%rax
  81d94b:	mov    0x138(%rax),%eax
  81d951:	cmp    $0x81,%eax
  81d956:	mov    $0x80,%edx
  81d95b:	cmovae %eax,%edx
  81d95e:	add    %edx,%edx
  81d960:	cmp    $0x800,%edx
  81d966:	mov    $0x800,%eax
  81d96b:	cmovae %eax,%edx
  81d96e:	lea    0x140(%rsp),%r12
  81d976:	mov    %r12,%rdi
  81d979:	mov    0x18(%rsp),%rsi
  81d97e:	mov    %edx,0x8(%rsp)
  81d982:	call   81cd40 <<gpui_gpu::renderer::Atlas>::new>
  81d987:	xor    %r15d,%r15d
  81d98a:	nopw   0x0(%rax,%rax,1)
  81d990:	mov    0x0(%r13,%r15,1),%rax
  81d995:	movups 0x28(%rax),%xmm0
  81d999:	lea    0x68(%rsp),%rcx
  81d99e:	movups %xmm0,(%rcx)
  81d9a1:	movups 0x18(%rax),%xmm0
  81d9a5:	movups %xmm0,0x58(%rsp)
  81d9aa:	movups 0x38(%rax),%xmm0
  81d9ae:	movups %xmm0,0x78(%rsp)
  81d9b3:	mov    %r12,%rdi
  81d9b6:	mov    0x20(%rsp),%rsi
  81d9bb:	lea    0x58(%rsp),%rdx
  81d9c0:	call   81d010 <<gpui_gpu::renderer::Atlas>::insert>
  81d9c5:	cmp    $0x1,%rax
  81d9c9:	jne    81d9d9 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x1a9>
  81d9cb:	add    %rdx,%rbx
  81d9ce:	add    $0x8,%r15
  81d9d2:	cmp    %r15,%rbp
  81d9d5:	jne    81d990 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x160>
  81d9d7:	jmp    81da1b <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x1eb>
  81d9d9:	mov    0x8(%rsp),%r15d
  81d9de:	cmp    $0x800,%r15d
  81d9e5:	je     81da6f <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x23f>
  81d9eb:	mov    %r12,%rdi
  81d9ee:	call   81bb50 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81d9f3:	add    %r15d,%r15d
  81d9f6:	cmp    $0x800,%r15d
  81d9fd:	mov    $0x800,%eax
  81da02:	cmovae %eax,%r15d
  81da06:	mov    %r12,%rdi
  81da09:	mov    0x18(%rsp),%rsi
  81da0e:	mov    %r15d,0x8(%rsp)
  81da13:	mov    %r15d,%edx
  81da16:	jmp    81d982 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x152>
  81da1b:	lea    0x58(%rsp),%rdi
  81da20:	lea    0x140(%rsp),%rsi
  81da28:	mov    $0xe8,%edx
  81da2d:	call   *0x661e85(%rip)        # e7f8b8 <memcpy@GLIBC_2.14>
  81da33:	mov    %r14,%rdi
  81da36:	call   81bb50 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81da3b:	lea    0x58(%rsp),%rsi
  81da40:	mov    $0xe8,%edx
  81da45:	mov    %r14,%rdi
  81da48:	call   *0x661e6a(%rip)        # e7f8b8 <memcpy@GLIBC_2.14>
  81da4e:	mov    0x10(%rsp),%rax
  81da53:	mov    %rbx,0x8(%rax)
  81da57:	movl   $0xffffffff,(%rax)
  81da5d:	add    $0x228,%rsp
  81da64:	pop    %rbx
  81da65:	pop    %r12
  81da67:	pop    %r13
  81da69:	pop    %r14
  81da6b:	pop    %r15
  81da6d:	pop    %rbp
  81da6e:	ret
  81da6f:	mov    0x10(%rsp),%rax
  81da74:	movl   $0x7,(%rax)
  81da7a:	lea    0x140(%rsp),%rdi
  81da82:	call   81bb50 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81da87:	jmp    81da5d <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x22d>
  81da89:	jmp    81da8b <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x25b>
  81da8b:	mov    %rax,%rbx
  81da8e:	lea    0x58(%rsp),%rsi
  81da93:	mov    $0xe8,%edx
  81da98:	mov    %r14,%rdi
  81da9b:	call   *0x661e17(%rip)        # e7f8b8 <memcpy@GLIBC_2.14>
  81daa1:	mov    %rbx,%rdi
  81daa4:	call   e2c400 <_Unwind_Resume@plt>
  81daa9:	mov    %rax,%rbx
  81daac:	lea    0x140(%rsp),%rdi
  81dab4:	call   81bb50 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81dab9:	mov    %rbx,%rdi
  81dabc:	call   e2c400 <_Unwind_Resume@plt>
  81dac1:	call   *0x661da1(%rip)        # e7f868 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::RendererState>::new bytes=1500 frame=952

/tmp/gpui-descending-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081dad0 <<gpui_gpu::renderer::RendererState>::new>:
  81dad0:	push   %r15
  81dad2:	push   %r14
  81dad4:	push   %r13
  81dad6:	push   %r12
  81dad8:	push   %rbx
  81dad9:	sub    $0x390,%rsp
  81dae0:	mov    %rsi,%r14
  81dae3:	mov    %rdi,%rbx
  81dae6:	lea    -0x748bc8(%rip),%rax        # d4f25 <anon.e7af5e0dba0d7261d22cb76253955a85.27.llvm.5458571228094894073+0xa>
  81daed:	mov    %rax,0xd8(%rsp)
  81daf5:	movq   $0x7,0xe0(%rsp)
  81db01:	movq   $0x30,0xe8(%rsp)
  81db0d:	movl   $0x48,0xf0(%rsp)
  81db18:	movb   $0x0,0xf4(%rsp)
  81db20:	mov    0x662109(%rip),%r15        # e7fc30 <_DYNAMIC+0x618>
  81db27:	lea    0x10(%rsp),%rdi
  81db2c:	lea    0xd8(%rsp),%rdx
  81db34:	call   *%r15
  81db37:	movq   $0x30,0x30(%rsp)
  81db40:	lea    -0x748c1b(%rip),%rax        # d4f2c <anon.e7af5e0dba0d7261d22cb76253955a85.27.llvm.5458571228094894073+0x11>
  81db47:	mov    %rax,0xd8(%rsp)
  81db4f:	movq   $0x5,0xe0(%rsp)
  81db5b:	movq   $0x10,0xe8(%rsp)
  81db67:	movl   $0x88,0xf0(%rsp)
  81db72:	movb   $0x0,0xf4(%rsp)
  81db7a:	lea    0x38(%rsp),%rdi
  81db7f:	lea    0xd8(%rsp),%rdx
  81db87:	mov    %r14,%rsi
  81db8a:	call   *%r15
  81db8d:	movq   $0x10,0x58(%rsp)
  81db96:	lea    -0x748c6c(%rip),%rax        # d4f31 <anon.e7af5e0dba0d7261d22cb76253955a85.27.llvm.5458571228094894073+0x16>
  81db9d:	mov    %rax,0xd8(%rsp)
  81dba5:	movq   $0x5,0xe0(%rsp)
  81dbb1:	movq   $0x8,0xe8(%rsp)
  81dbbd:	movl   $0x88,0xf0(%rsp)
  81dbc8:	movb   $0x0,0xf4(%rsp)
  81dbd0:	lea    0x60(%rsp),%rdi
  81dbd5:	lea    0xd8(%rsp),%rdx
  81dbdd:	mov    %r14,%rsi
  81dbe0:	call   *0x66204a(%rip)        # e7fc30 <_DYNAMIC+0x618>
  81dbe6:	movq   $0x8,0x80(%rsp)
  81dbf2:	lea    -0x748cc3(%rip),%rax        # d4f36 <anon.e7af5e0dba0d7261d22cb76253955a85.27.llvm.5458571228094894073+0x1b>
  81dbf9:	mov    %rax,0xd8(%rsp)
  81dc01:	movq   $0x7,0xe0(%rsp)
  81dc0d:	movq   $0x4,0xe8(%rsp)
  81dc19:	movl   $0x88,0xf0(%rsp)
  81dc24:	movb   $0x0,0xf4(%rsp)
  81dc2c:	lea    0x88(%rsp),%rdi
  81dc34:	lea    0xd8(%rsp),%rdx
  81dc3c:	mov    %r14,%rsi
  81dc3f:	call   *0x661feb(%rip)        # e7fc30 <_DYNAMIC+0x618>
  81dc45:	movq   $0x4,0xa8(%rsp)
  81dc51:	lea    -0x748d1b(%rip),%rax        # d4f3d <anon.e7af5e0dba0d7261d22cb76253955a85.27.llvm.5458571228094894073+0x22>
  81dc58:	mov    %rax,0xd8(%rsp)
  81dc60:	movq   $0x11,0xe0(%rsp)
  81dc6c:	movq   $0x20,0xe8(%rsp)
  81dc78:	movl   $0x88,0xf0(%rsp)
  81dc83:	movb   $0x0,0xf4(%rsp)
  81dc8b:	lea    0xb0(%rsp),%rdi
  81dc93:	lea    0xd8(%rsp),%rdx
  81dc9b:	mov    %r14,%rsi
  81dc9e:	call   *0x661f8c(%rip)        # e7fc30 <_DYNAMIC+0x618>
  81dca4:	movq   $0x20,0xd0(%rsp)
  81dcb0:	lea    0x2a8(%rsp),%rdi
  81dcb8:	mov    %r14,%rsi
  81dcbb:	mov    $0x1,%edx
  81dcc0:	call   81cd40 <<gpui_gpu::renderer::Atlas>::new>
  81dcc5:	mov    0x18(%r14),%r13
  81dcc9:	lock incq 0x0(%r13)
  81dcce:	jle    81dfe8 <<gpui_gpu::renderer::RendererState>::new+0x518>
  81dcd4:	mov    %r13,0x8(%rsp)
  81dcd9:	mov    0x30(%rsp),%rax
  81dcde:	mov    %rax,0x1e0(%rsp)
  81dce6:	movups 0x10(%rsp),%xmm0
  81dceb:	movups 0x20(%rsp),%xmm1
  81dcf0:	movaps %xmm1,0x1d0(%rsp)
  81dcf8:	movaps %xmm0,0x1c0(%rsp)
  81dd00:	mov    0x58(%rsp),%rax
  81dd05:	mov    %rax,0x210(%rsp)
  81dd0d:	movups 0x38(%rsp),%xmm0
  81dd12:	movups 0x48(%rsp),%xmm1
  81dd17:	movaps %xmm1,0x200(%rsp)
  81dd1f:	movaps %xmm0,0x1f0(%rsp)
  81dd27:	mov    0x80(%rsp),%rax
  81dd2f:	mov    %rax,0x240(%rsp)
  81dd37:	movups 0x60(%rsp),%xmm0
  81dd3c:	movups 0x70(%rsp),%xmm1
  81dd41:	movaps %xmm1,0x230(%rsp)
  81dd49:	movaps %xmm0,0x220(%rsp)
  81dd51:	mov    0xa8(%rsp),%rax
  81dd59:	mov    %rax,0x270(%rsp)
  81dd61:	movups 0x88(%rsp),%xmm0
  81dd69:	movups 0x98(%rsp),%xmm1
  81dd71:	movaps %xmm1,0x260(%rsp)
  81dd79:	movaps %xmm0,0x250(%rsp)
  81dd81:	mov    0xd0(%rsp),%rax
  81dd89:	mov    %rax,0x2a0(%rsp)
  81dd91:	movups 0xb0(%rsp),%xmm0
  81dd99:	movups 0xc0(%rsp),%xmm1
  81dda1:	movaps %xmm1,0x290(%rsp)
  81dda9:	movaps %xmm0,0x280(%rsp)
  81ddb1:	lea    0xd8(%rsp),%rdi
  81ddb9:	lea    0x2a8(%rsp),%rsi
  81ddc1:	mov    $0xe8,%edx
  81ddc6:	call   *0x661aec(%rip)        # e7f8b8 <memcpy@GLIBC_2.14>
  81ddcc:	mov    %fs:0x0,%rax
  81ddd5:	lea    -0x28(%rax),%rax
  81dddc:	mov    %rax,%r12
  81dddf:	cmpb   $0x1,0x10(%rax)
  81dde3:	jne    81dfc8 <<gpui_gpu::renderer::RendererState>::new+0x4f8>
  81dde9:	mov    (%r12),%r14
  81dded:	mov    0x8(%r12),%r15
  81ddf2:	lea    0x1(%r14),%rax
  81ddf6:	mov    %rax,(%r12)
  81ddfa:	mov    %r13,0x210(%rbx)
  81de01:	mov    0x30(%rsp),%rax
  81de06:	mov    %rax,0x238(%rbx)
  81de0d:	movups 0x10(%rsp),%xmm0
  81de12:	movups 0x20(%rsp),%xmm1
  81de17:	movups %xmm1,0x228(%rbx)
  81de1e:	movups %xmm0,0x218(%rbx)
  81de25:	mov    0x58(%rsp),%rax
  81de2a:	mov    %rax,0x260(%rbx)
  81de31:	movups 0x38(%rsp),%xmm0
  81de36:	movups 0x48(%rsp),%xmm1
  81de3b:	movups %xmm1,0x250(%rbx)
  81de42:	movups %xmm0,0x240(%rbx)
  81de49:	mov    0x80(%rsp),%rax
  81de51:	mov    %rax,0x288(%rbx)
  81de58:	movups 0x60(%rsp),%xmm0
  81de5d:	movups 0x70(%rsp),%xmm1
  81de62:	movups %xmm1,0x278(%rbx)
  81de69:	movups %xmm0,0x268(%rbx)
  81de70:	movups 0x88(%rsp),%xmm0
  81de78:	movups 0x98(%rsp),%xmm1
  81de80:	movups %xmm0,0x290(%rbx)
  81de87:	movups %xmm1,0x2a0(%rbx)
  81de8e:	mov    0xa8(%rsp),%rax
  81de96:	mov    %rax,0x2b0(%rbx)
  81de9d:	movups 0xb0(%rsp),%xmm0
  81dea5:	movups 0xc0(%rsp),%xmm1
  81dead:	movups %xmm0,0x2b8(%rbx)
  81deb4:	movups %xmm1,0x2c8(%rbx)
  81debb:	mov    0xd0(%rsp),%rax
  81dec3:	mov    %rax,0x2d8(%rbx)
  81deca:	lea    0x60(%rbx),%rdi
  81dece:	lea    0x2a8(%rsp),%rsi
  81ded6:	mov    $0xe8,%edx
  81dedb:	call   *0x6619d7(%rip)        # e7f8b8 <memcpy@GLIBC_2.14>
  81dee1:	xorps  %xmm0,%xmm0
  81dee4:	movups %xmm0,0x310(%rbx)
  81deeb:	movq   $0x0,(%rbx)
  81def2:	movq   $0x4,0x8(%rbx)
  81defa:	movups %xmm0,0x10(%rbx)
  81defe:	movq   $0x4,0x20(%rbx)
  81df06:	movups %xmm0,0x28(%rbx)
  81df0a:	movq   $0x4,0x38(%rbx)
  81df12:	movups %xmm0,0x40(%rbx)
  81df16:	movq   $0x4,0x50(%rbx)
  81df1e:	movq   $0x0,0x58(%rbx)
  81df26:	movups 0x6102ab(%rip),%xmm1        # e2e1d8 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xe0>
  81df2d:	movups %xmm1,0x2e0(%rbx)
  81df34:	movups 0x6102ad(%rip),%xmm1        # e2e1e8 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xf0>
  81df3b:	movups %xmm1,0x2f0(%rbx)
  81df42:	mov    %r14,0x300(%rbx)
  81df49:	mov    %r15,0x308(%rbx)
  81df50:	movw   $0x101,0x328(%rbx)
  81df59:	movups %xmm0,0x1f8(%rbx)
  81df60:	movups %xmm0,0x1e8(%rbx)
  81df67:	movups %xmm0,0x1d8(%rbx)
  81df6e:	movups %xmm0,0x1c8(%rbx)
  81df75:	movups %xmm0,0x1b8(%rbx)
  81df7c:	movups %xmm0,0x1a8(%rbx)
  81df83:	movups %xmm0,0x198(%rbx)
  81df8a:	movups %xmm0,0x188(%rbx)
  81df91:	movups %xmm0,0x178(%rbx)
  81df98:	movups %xmm0,0x168(%rbx)
  81df9f:	movups %xmm0,0x158(%rbx)
  81dfa6:	movups %xmm0,0x148(%rbx)
  81dfad:	movb   $0x0,0x208(%rbx)
  81dfb4:	mov    %rbx,%rax
  81dfb7:	add    $0x390,%rsp
  81dfbe:	pop    %rbx
  81dfbf:	pop    %r12
  81dfc1:	pop    %r13
  81dfc3:	pop    %r14
  81dfc5:	pop    %r15
  81dfc7:	ret
  81dfc8:	call   *0x661c6a(%rip)        # e7fc38 <_DYNAMIC+0x620>
  81dfce:	mov    %rax,%r14
  81dfd1:	mov    %rdx,%r15
  81dfd4:	mov    %rax,(%r12)
  81dfd8:	mov    %rdx,0x8(%r12)
  81dfdd:	movb   $0x1,0x10(%r12)
  81dfe3:	jmp    81ddf2 <<gpui_gpu::renderer::RendererState>::new+0x322>
  81dfe8:	ud2
  81dfea:	mov    %rax,%rbx
  81dfed:	lea    0xd8(%rsp),%rdi
  81dff5:	call   81bb50 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81dffa:	lea    0x280(%rsp),%rdi
  81e002:	call   81bc30 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e007:	lea    0x250(%rsp),%rdi
  81e00f:	call   81bc30 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e014:	lea    0x220(%rsp),%rdi
  81e01c:	call   81bc30 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e021:	lea    0x1f0(%rsp),%rdi
  81e029:	call   81bc30 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e02e:	lea    0x1c0(%rsp),%rdi
  81e036:	call   81bc30 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e03b:	lock decq 0x0(%r13)
  81e040:	jne    81e09e <<gpui_gpu::renderer::RendererState>::new+0x5ce>
  81e042:	lea    0x8(%rsp),%rdi
  81e047:	call   *0x661a33(%rip)        # e7fa80 <_DYNAMIC+0x468>
  81e04d:	jmp    81e09e <<gpui_gpu::renderer::RendererState>::new+0x5ce>
  81e04f:	mov    %rax,%rbx
  81e052:	lea    0xb0(%rsp),%rdi
  81e05a:	call   81bc30 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e05f:	jmp    81e064 <<gpui_gpu::renderer::RendererState>::new+0x594>
  81e061:	mov    %rax,%rbx
  81e064:	lea    0x88(%rsp),%rdi
  81e06c:	call   81bc30 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e071:	jmp    81e076 <<gpui_gpu::renderer::RendererState>::new+0x5a6>
  81e073:	mov    %rax,%rbx
  81e076:	lea    0x60(%rsp),%rdi
  81e07b:	call   81bc30 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e080:	jmp    81e085 <<gpui_gpu::renderer::RendererState>::new+0x5b5>
  81e082:	mov    %rax,%rbx
  81e085:	lea    0x38(%rsp),%rdi
  81e08a:	call   81bc30 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e08f:	jmp    81e094 <<gpui_gpu::renderer::RendererState>::new+0x5c4>
  81e091:	mov    %rax,%rbx
  81e094:	lea    0x10(%rsp),%rdi
  81e099:	call   81bc30 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e09e:	mov    %rbx,%rdi
  81e0a1:	call   e2c400 <_Unwind_Resume@plt>
  81e0a6:	call   *0x6617bc(%rip)        # e7f868 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::RendererState>::render bytes=9376 frame=1400

/tmp/gpui-descending-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081e0b0 <<gpui_gpu::renderer::RendererState>::render>:
  81e0b0:	push   %rbp
  81e0b1:	push   %r15
  81e0b3:	push   %r14
  81e0b5:	push   %r13
  81e0b7:	push   %r12
  81e0b9:	push   %rbx
  81e0ba:	sub    $0x548,%rsp
  81e0c1:	mov    0x210(%rsi),%rax
  81e0c8:	mov    0x18(%rdx),%r9
  81e0cc:	cmp    %r9,%rax
  81e0cf:	je     81e0ed <<gpui_gpu::renderer::RendererState>::render+0x3d>
  81e0d1:	mov    0x10(%rax),%r10
  81e0d5:	cmp    0x10(%r9),%r10
  81e0d9:	jne    81e1bb <<gpui_gpu::renderer::RendererState>::render+0x10b>
  81e0df:	mov    0x18(%rax),%rax
  81e0e3:	cmp    0x18(%r9),%rax
  81e0e7:	jne    81e1bb <<gpui_gpu::renderer::RendererState>::render+0x10b>
  81e0ed:	lea    0x318(%rsi),%rbx
  81e0f4:	mov    0x318(%rsi),%rax
  81e0fb:	test   %rax,%rax
  81e0fe:	je     81e12d <<gpui_gpu::renderer::RendererState>::render+0x7d>
  81e100:	lock decq (%rax)
  81e104:	jne    81e12d <<gpui_gpu::renderer::RendererState>::render+0x7d>
  81e106:	mov    %rdi,%r14
  81e109:	mov    %rbx,%rdi
  81e10c:	mov    %rsi,%r12
  81e10f:	mov    %r8,%r13
  81e112:	mov    %rdx,%r15
  81e115:	mov    %rcx,%rbp
  81e118:	call   *0x661a12(%rip)        # e7fb30 <_DYNAMIC+0x518>
  81e11e:	mov    %rbp,%rcx
  81e121:	mov    %r15,%rdx
  81e124:	mov    %r13,%r8
  81e127:	mov    %r12,%rsi
  81e12a:	mov    %r14,%rdi
  81e12d:	movq   $0x0,0x318(%rsi)
  81e138:	mov    (%rcx),%r12d
  81e13b:	mov    0x8(%rcx),%r9d
  81e13f:	movzbl 0xd(%rcx),%eax
  81e143:	test   %r9d,%r9d
  81e146:	sets   %r10b
  81e14a:	and    $0x7fffffff,%r9d
  81e151:	lea    -0x800000(%r9),%r11d
  81e158:	cmp    $0x7f000000,%r11d
  81e15f:	setb   %r11b
  81e163:	and    %r10b,%r11b
  81e166:	lea    -0x1(%r9),%ebp
  81e16a:	cmp    $0x7fffff,%ebp
  81e170:	setb   %bpl
  81e174:	and    %r10b,%bpl
  81e177:	test   %r9d,%r9d
  81e17a:	sete   %r10b
  81e17e:	cmp    $0x7f800000,%r9d
  81e185:	sete   %r14b
  81e189:	or     %r10b,%r14b
  81e18c:	cmp    $0x7f800001,%r9d
  81e193:	setge  %r9b
  81e197:	or     %r14b,%r9b
  81e19a:	or     %bpl,%r9b
  81e19d:	test   %r12d,%r12d
  81e1a0:	setne  %r10b
  81e1a4:	and    %al,%r10b
  81e1a7:	or     %r11b,%r10b
  81e1aa:	or     %r9b,%r10b
  81e1ad:	test   $0x1,%r10b
  81e1b1:	je     81e1d6 <<gpui_gpu::renderer::RendererState>::render+0x126>
  81e1b3:	movl   $0x3,(%rdi)
  81e1b9:	jmp    81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81e1bb:	movl   $0x4,(%rdi)
  81e1c1:	mov    %rdi,%rax
  81e1c4:	add    $0x548,%rsp
  81e1cb:	pop    %rbx
  81e1cc:	pop    %r12
  81e1ce:	pop    %r13
  81e1d0:	pop    %r14
  81e1d2:	pop    %r15
  81e1d4:	pop    %rbp
  81e1d5:	ret
  81e1d6:	movd   0x4(%rcx),%xmm2
  81e1db:	movzbl 0xc(%rcx),%ebp
  81e1df:	test   $0x1,%r12b
  81e1e3:	je     81e25b <<gpui_gpu::renderer::RendererState>::render+0x1ab>
  81e1e5:	movd   %xmm2,%r9d
  81e1ea:	test   %r9d,%r9d
  81e1ed:	sets   %r10b
  81e1f1:	and    $0x7fffffff,%r9d
  81e1f8:	lea    -0x800000(%r9),%r11d
  81e1ff:	cmp    $0x7f000000,%r11d
  81e206:	setb   %r11b
  81e20a:	and    %r10b,%r11b
  81e20d:	lea    -0x1(%r9),%r14d
  81e211:	cmp    $0x7fffff,%r14d
  81e218:	setb   %r14b
  81e21c:	and    %r10b,%r14b
  81e21f:	test   %r9d,%r9d
  81e222:	sete   %r10b
  81e226:	cmp    $0x7f800000,%r9d
  81e22d:	sete   %r15b
  81e231:	or     %r10b,%r15b
  81e234:	cmp    $0x7f800001,%r9d
  81e23b:	setge  %r9b
  81e23f:	or     %r15b,%r9b
  81e242:	or     %r14b,%r9b
  81e245:	or     %r11b,%r9b
  81e248:	jne    81e1b3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e24e:	ucomiss -0x76f3a9(%rip),%xmm2        # aeeac <anon.630a3fff68f6bca64b568be97512ab45.57.llvm.826976926275214120+0x1c>
  81e255:	ja     81e1b3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e25b:	mov    0x28(%rcx),%r14d
  81e25f:	cmp    %r14d,0x20(%r8)
  81e263:	jne    81e1b3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e269:	mov    0x2c(%rcx),%r15d
  81e26d:	cmp    %r15d,0x24(%r8)
  81e271:	jne    81e1b3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e277:	mov    0x38(%r8),%r13d
  81e27b:	cmp    0x20(%rdx),%r13d
  81e27f:	jne    81e1b3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e285:	cmp    $0x4c,%r13d
  81e289:	jne    81e2ae <<gpui_gpu::renderer::RendererState>::render+0x1fe>
  81e28b:	movq   0x3c(%r8),%xmm0
  81e291:	movq   0x24(%rdx),%xmm1
  81e296:	pcmpeqd %xmm0,%xmm1
  81e29a:	pshufd $0x50,%xmm1,%xmm0
  81e29f:	movmskpd %xmm0,%r9d
  81e2a4:	cmp    $0x3,%r9d
  81e2a8:	jne    81e1b3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e2ae:	cmp    $0x4000,%r15d
  81e2b5:	ja     81e2eb <<gpui_gpu::renderer::RendererState>::render+0x23b>
  81e2b7:	cmp    $0x4000,%r14d
  81e2be:	ja     81e2eb <<gpui_gpu::renderer::RendererState>::render+0x23b>
  81e2c0:	mov    %r15,%r9
  81e2c3:	imul   %r14,%r9
  81e2c7:	add    $0xfffffffffeffffff,%r9
  81e2ce:	cmp    $0xffffffffff000000,%r9
  81e2d5:	jb     81e2eb <<gpui_gpu::renderer::RendererState>::render+0x23b>
  81e2d7:	mov    0x10(%rcx),%r11
  81e2db:	mov    0x80(%r11),%r10
  81e2e2:	cmp    $0x10000,%r10
  81e2e9:	jbe    81e2f6 <<gpui_gpu::renderer::RendererState>::render+0x246>
  81e2eb:	movl   $0x6,(%rdi)
  81e2f1:	jmp    81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81e2f6:	movd   0x18(%rcx),%xmm0
  81e2fb:	movd   %xmm0,%r9d
  81e300:	and    $0x7fffffff,%r9d
  81e307:	cmp    $0x7f7fffff,%r9d
  81e30e:	jg     81e1b3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e314:	pand   -0x770b9c(%rip),%xmm0        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e31c:	ucomiss -0x76f21f(%rip),%xmm0        # af104 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e323:	ja     81e1b3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e329:	movd   0x1c(%rcx),%xmm0
  81e32e:	movd   %xmm0,%r9d
  81e333:	and    $0x7fffffff,%r9d
  81e33a:	cmp    $0x7f7fffff,%r9d
  81e341:	jg     81e1b3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e347:	pand   -0x770bcf(%rip),%xmm0        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e34f:	ucomiss -0x76f252(%rip),%xmm0        # af104 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e356:	ja     81e1b3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e35c:	movd   0x20(%rcx),%xmm0
  81e361:	movd   %xmm0,%r9d
  81e366:	and    $0x7fffffff,%r9d
  81e36d:	cmp    $0x7f7fffff,%r9d
  81e374:	jg     81e1b3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e37a:	pand   -0x770c02(%rip),%xmm0        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e382:	ucomiss -0x76f285(%rip),%xmm0        # af104 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e389:	ja     81e1b3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e38f:	movd   0x24(%rcx),%xmm0
  81e394:	movd   %xmm0,%r9d
  81e399:	and    $0x7fffffff,%r9d
  81e3a0:	cmp    $0x7f7fffff,%r9d
  81e3a7:	jg     81e1b3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e3ad:	movdqa -0x770c35(%rip),%xmm1        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e3b5:	pand   %xmm0,%xmm1
  81e3b9:	ucomiss -0x76f2bc(%rip),%xmm1        # af104 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e3c0:	ja     81e1b3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e3c6:	xorps  %xmm1,%xmm1
  81e3c9:	ucomiss %xmm1,%xmm0
  81e3cc:	jb     81e1b3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e3d2:	movss  -0x76f65a(%rip),%xmm1        # aed80 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  81e3da:	ucomiss %xmm0,%xmm1
  81e3dd:	jb     81e1b3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e3e3:	movzwl 0x30(%rcx),%r9d
  81e3e8:	mov    %r9w,0x10(%rsp)
  81e3ee:	movzwl 0x32(%rcx),%r9d
  81e3f3:	mov    %r9w,0x18(%rsp)
  81e3f9:	cmp    $0x28,%r13d
  81e3fd:	jne    81e409 <<gpui_gpu::renderer::RendererState>::render+0x359>
  81e3ff:	test   $0x1,%al
  81e401:	je     81e1b3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e407:	jmp    81e424 <<gpui_gpu::renderer::RendererState>::render+0x374>
  81e409:	test   $0x1,%al
  81e40b:	jne    81e1b3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e411:	ucomiss -0x76f698(%rip),%xmm0        # aed80 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  81e418:	jne    81e1b3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e41e:	jp     81e1b3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e424:	mov    %r11,0xc8(%rsp)
  81e42c:	mov    %r10,0xc0(%rsp)
  81e434:	movss  %xmm1,0x104(%rsp)
  81e43d:	movd   %xmm2,0x244(%rsp)
  81e446:	mov    %rdx,0x108(%rsp)
  81e44e:	mov    %r8,0x3e8(%rsp)
  81e456:	mov    %rdi,0x30(%rsp)
  81e45b:	lea    0xf(%r14),%rdx
  81e45f:	shr    $0x4,%rdx
  81e463:	lea    0xf(%r15),%eax
  81e467:	shr    $0x4,%eax
  81e46a:	lea    0x18(%rsi),%rdi
  81e46e:	movq   $0x0,0x28(%rsi)
  81e476:	mov    %rdx,0x58(%rsp)
  81e47b:	imul   %edx,%eax
  81e47e:	mov    %rdi,0x218(%rsp)
  81e486:	mov    %rsi,0x8(%rsp)
  81e48b:	mov    %rax,%rsi
  81e48e:	xor    %edx,%edx
  81e490:	mov    %rcx,0xe8(%rsp)
  81e498:	call   8227d0 <<alloc::vec::Vec<[u32; 2]>>::resize>
  81e49d:	mov    0x8(%rsp),%rax
  81e4a2:	movq   $0x0,0x10(%rax)
  81e4aa:	mov    0xe8(%rsp),%rdi
  81e4b2:	call   *0x661708(%rip)        # e7fbc0 <_DYNAMIC+0x5a8>
  81e4b8:	mov    %rdx,%rcx
  81e4bb:	sub    %rax,%rcx
  81e4be:	cmp    $0x300000,%rcx
  81e4c5:	jbe    81e4d7 <<gpui_gpu::renderer::RendererState>::render+0x427>
  81e4c7:	mov    0x30(%rsp),%rdi
  81e4cc:	movl   $0x6,(%rdi)
  81e4d2:	jmp    81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81e4d7:	mov    %rcx,%rsi
  81e4da:	shr    $0x3,%rcx
  81e4de:	movabs $0xaaaaaaaaaaaaaaab,%rdi
  81e4e8:	imul   %rcx,%rdi
  81e4ec:	mov    %rdi,0x38(%rsp)
  81e4f1:	mov    %rax,0x380(%rsp)
  81e4f9:	mov    %rdx,0x378(%rsp)
  81e501:	cmp    %rax,%rdx
  81e504:	je     81e532 <<gpui_gpu::renderer::RendererState>::render+0x482>
  81e506:	mov    $0xaaaaaaab,%eax
  81e50b:	imul   %rax,%rsi
  81e50f:	shr    $0x2a,%rsi
  81e513:	mov    0x38(%rsp),%rcx
  81e518:	mov    %ecx,%eax
  81e51a:	and    $0x3f,%eax
  81e51d:	add    %rcx,%rsi
  81e520:	cmp    $0x1,%rax
  81e524:	sbb    $0xffffffffffffffff,%rsi
  81e528:	inc    %rsi
  81e52b:	mov    %rsi,0x50(%rsp)
  81e530:	jmp    81e53b <<gpui_gpu::renderer::RendererState>::render+0x48b>
  81e532:	movq   $0x0,0x50(%rsp)
  81e53b:	mov    0xc8(%rsp),%rax
  81e543:	mov    0x98(%rax),%rcx
  81e54a:	add    0xb0(%rax),%rcx
  81e551:	mov    %rax,0x110(%rsp)
  81e559:	movzwl 0x10(%rsp),%eax
  81e55e:	mov    %ax,0x130(%rsp)
  81e566:	movzwl 0x18(%rsp),%eax
  81e56b:	mov    %ax,0x132(%rsp)
  81e573:	movq   $0x0,0x118(%rsp)
  81e57f:	mov    0xc0(%rsp),%rax
  81e587:	mov    %rax,0x120(%rsp)
  81e58f:	mov    %rcx,0x210(%rsp)
  81e597:	mov    %rcx,0x128(%rsp)
  81e59f:	mov    0x8(%rsp),%rax
  81e5a4:	movzbl 0x329(%rax),%edx
  81e5ab:	lea    0x428(%rsp),%rdi
  81e5b3:	lea    0x110(%rsp),%rsi
  81e5bb:	call   81c820 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>>
  81e5c0:	mov    0x428(%rsp),%eax
  81e5c7:	cmp    $0xffffffff,%eax
  81e5ca:	je     81e5fa <<gpui_gpu::renderer::RendererState>::render+0x54a>
  81e5cc:	mov    0x42c(%rsp),%ecx
  81e5d3:	mov    0x430(%rsp),%rdx
  81e5db:	movups 0x438(%rsp),%xmm0
  81e5e3:	mov    0x30(%rsp),%rdi
  81e5e8:	movups %xmm0,0x10(%rdi)
  81e5ec:	mov    %eax,(%rdi)
  81e5ee:	mov    %ecx,0x4(%rdi)
  81e5f1:	mov    %rdx,0x8(%rdi)
  81e5f5:	jmp    81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81e5fa:	mov    0x430(%rsp),%rdx
  81e602:	add    0x50(%rsp),%rdx
  81e607:	mov    0x8(%rsp),%rdi
  81e60c:	mov    0x10(%rdi),%rsi
  81e610:	mov    $0x4,%ecx
  81e615:	mov    $0x10,%r8d
  81e61b:	call   823b90 <<alloc::raw_vec::RawVecInner>::try_reserve_exact>
  81e620:	cmp    $0xffffffffffffffff,%rax
  81e624:	jne    81e4c7 <<gpui_gpu::renderer::RendererState>::render+0x417>
  81e62a:	movzwl 0x10(%rsp),%eax
  81e62f:	mov    %eax,0x10(%rsp)
  81e633:	movzwl 0x18(%rsp),%eax
  81e638:	mov    %eax,0x78(%rsp)
  81e63c:	mov    0x8(%rsp),%rdi
  81e641:	mov    0xe8(%rsp),%rsi
  81e649:	mov    0x38(%rsp),%rdx
  81e64e:	call   825af0 <gpui_gpu::renderer::slots::write_prefix>
  81e653:	mov    0x8(%rsp),%rax
  81e658:	movq   $0x0,0x58(%rax)
  81e660:	cmpq   $0x0,0x48(%rax)
  81e665:	jne    81e676 <<gpui_gpu::renderer::RendererState>::render+0x5c6>
  81e667:	mov    0x8(%rsp),%rax
  81e66c:	lea    0x48(%rax),%rdi
  81e670:	call   *0x661552(%rip)        # e7fbc8 <_DYNAMIC+0x5b0>
  81e676:	mov    0x8(%rsp),%rax
  81e67b:	mov    0x50(%rax),%rcx
  81e67f:	xorps  %xmm0,%xmm0
  81e682:	movups %xmm0,0x10(%rcx)
  81e686:	movups %xmm0,(%rcx)
  81e689:	movq   $0x1,0x58(%rax)
  81e691:	lea    0x2e0(%rax),%rdi
  81e698:	call   8254a0 <<hashbrown::raw::RawTable<([u32; 8], u32)>>::clear>
  81e69d:	mov    0x78(%rsp),%ecx
  81e6a1:	shl    $0x10,%ecx
  81e6a4:	add    0x10(%rsp),%ecx
  81e6a8:	mov    0xc8(%rsp),%rax
  81e6b0:	mov    %rax,0x388(%rsp)
  81e6b8:	movq   $0x0,0x390(%rsp)
  81e6c4:	mov    0xc0(%rsp),%rax
  81e6cc:	mov    %rax,0x398(%rsp)
  81e6d4:	mov    0x210(%rsp),%rax
  81e6dc:	mov    %rax,0x3a0(%rsp)
  81e6e4:	mov    %ecx,0x78(%rsp)
  81e6e8:	mov    %ecx,0x3a8(%rsp)
  81e6ef:	lea    0x248(%rsp),%rdi
  81e6f7:	lea    0x388(%rsp),%rsi
  81e6ff:	call   *0x6614cb(%rip)        # e7fbd0 <_DYNAMIC+0x5b8>
  81e705:	mov    0x248(%rsp),%rax
  81e70d:	mov    %rax,0x18(%rsp)
  81e712:	test   %rax,%rax
  81e715:	je     81f479 <<gpui_gpu::renderer::RendererState>::render+0x13c9>
  81e71b:	movq   $0x0,0xe0(%rsp)
  81e727:	movq   $0x0,0x10(%rsp)
  81e730:	movq   $0x0,0xb8(%rsp)
  81e73c:	movq   $0x0,0x200(%rsp)
  81e748:	movq   $0x0,0x208(%rsp)
  81e754:	mov    0x250(%rsp),%rcx
  81e75c:	mov    0x258(%rsp),%rdx
  81e764:	mov    %rdx,0xa0(%rsp)
  81e76c:	lea    0x260(%rsp),%rdi
  81e774:	movups (%rdi),%xmm0
  81e777:	movups 0x10(%rdi),%xmm1
  81e77b:	movups 0x20(%rdi),%xmm2
  81e77f:	movaps %xmm2,0x2f0(%rsp)
  81e787:	movaps %xmm1,0x2e0(%rsp)
  81e78f:	movaps %xmm0,0x2d0(%rsp)
  81e797:	lea    0x290(%rsp),%r8
  81e79f:	movups (%r8),%xmm0
  81e7a3:	movaps %xmm0,0x4f0(%rsp)
  81e7ab:	movups 0x40(%rdi),%xmm0
  81e7af:	movaps %xmm0,0x3f0(%rsp)
  81e7b7:	mov    0x8(%rsp),%rax
  81e7bc:	movzbl 0x329(%rax),%esi
  81e7c3:	mov    0x18(%rsp),%rax
  81e7c8:	mov    %rax,0x110(%rsp)
  81e7d0:	mov    %rcx,0x28(%rsp)
  81e7d5:	mov    %rcx,0x118(%rsp)
  81e7dd:	mov    %rdx,0x120(%rsp)
  81e7e5:	movups (%rdi),%xmm0
  81e7e8:	movups 0x10(%rdi),%xmm1
  81e7ec:	movups 0x20(%rdi),%xmm2
  81e7f0:	lea    0x128(%rsp),%rax
  81e7f8:	movups %xmm2,0x20(%rax)
  81e7fc:	movups %xmm1,0x10(%rax)
  81e800:	movups %xmm0,(%rax)
  81e803:	movups (%r8),%xmm0
  81e807:	movups %xmm0,0x30(%rax)
  81e80b:	movups 0x40(%rdi),%xmm0
  81e80f:	movups %xmm0,0x40(%rax)
  81e813:	lea    0x110(%rsp),%rdi
  81e81b:	call   821530 <gpui_gpu::renderer::compact_group>
  81e820:	mov    %al,0x40(%rsp)
  81e824:	lea    0x260(%rsp),%rsi
  81e82c:	movups (%rsi),%xmm0
  81e82f:	movups 0x10(%rsi),%xmm1
  81e833:	movups 0x20(%rsi),%xmm2
  81e837:	movaps %xmm0,0x500(%rsp)
  81e83f:	movaps %xmm1,0x510(%rsp)
  81e847:	movaps %xmm2,0x520(%rsp)
  81e84f:	lea    0x290(%rsp),%rdx
  81e857:	movups (%rdx),%xmm0
  81e85a:	movaps %xmm0,0x530(%rsp)
  81e862:	mov    0x8(%rsp),%rdi
  81e867:	call   81d450 <<gpui_gpu::renderer::RendererState>::correction>
  81e86c:	mov    %eax,0x7c(%rsp)
  81e870:	mov    0xa0(%rsp),%rax
  81e878:	lea    0x0(,%rax,4),%rax
  81e880:	mov    %rax,0x370(%rsp)
  81e888:	cmpb   $0x0,0x40(%rsp)
  81e88d:	je     81ea6b <<gpui_gpu::renderer::RendererState>::render+0x9bb>
  81e893:	mov    0x28(%rsp),%rcx
  81e898:	mov    0xa0(%rsp),%rax
  81e8a0:	lea    (%rcx,%rax,4),%rax
  81e8a4:	mov    %rcx,0x408(%rsp)
  81e8ac:	mov    %rax,0x410(%rsp)
  81e8b4:	mov    0x18(%rsp),%rax
  81e8b9:	mov    %rax,0x418(%rsp)
  81e8c1:	movq   $0x0,0x420(%rsp)
  81e8cd:	lea    0x300(%rsp),%rdi
  81e8d5:	lea    0x408(%rsp),%rsi
  81e8dd:	call   821bc0 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81e8e2:	cmpb   $0xff,0x308(%rsp)
  81e8ea:	je     81efaa <<gpui_gpu::renderer::RendererState>::render+0xefa>
  81e8f0:	xorps  %xmm0,%xmm0
  81e8f3:	movaps %xmm0,0x80(%rsp)
  81e8fb:	movaps %xmm0,0x60(%rsp)
  81e900:	mov    0x300(%rsp),%rdx
  81e908:	add    0xb8(%rsp),%rdx
  81e910:	lea    0x308(%rsp),%rsi
  81e918:	movups 0x38(%rsi),%xmm0
  81e91c:	lea    0x128(%rsp),%rcx
  81e924:	movups %xmm0,0x20(%rcx)
  81e928:	movups 0x48(%rsi),%xmm0
  81e92c:	movups %xmm0,0x70(%rcx)
  81e930:	mov    0x30(%rsi),%rax
  81e934:	mov    %rax,0x140(%rsp)
  81e93c:	movups (%rsi),%xmm0
  81e93f:	movups 0x10(%rsi),%xmm1
  81e943:	movups 0x20(%rsi),%xmm2
  81e947:	movaps %xmm2,0x130(%rsp)
  81e94f:	movaps %xmm1,0x120(%rsp)
  81e957:	movaps %xmm0,0x110(%rsp)
  81e95f:	lea    0x260(%rsp),%rax
  81e967:	movups 0x40(%rax),%xmm0
  81e96b:	movups %xmm0,0x80(%rcx)
  81e972:	movups (%rax),%xmm0
  81e975:	movups 0x10(%rax),%xmm1
  81e979:	movups 0x20(%rax),%xmm2
  81e97d:	movups %xmm2,0x50(%rcx)
  81e981:	movups %xmm1,0x40(%rcx)
  81e985:	movups %xmm0,0x30(%rcx)
  81e989:	lea    0x290(%rsp),%rax
  81e991:	movups (%rax),%xmm0
  81e994:	movups %xmm0,0x60(%rcx)
  81e998:	lea    0x220(%rsp),%rdi
  81e9a0:	lea    0x110(%rsp),%rsi
  81e9a8:	mov    %r14d,%ecx
  81e9ab:	mov    %r15d,%r8d
  81e9ae:	call   821580 <gpui_gpu::renderer::validate_draw>
  81e9b3:	mov    0x220(%rsp),%ecx
  81e9ba:	mov    0x224(%rsp),%rax
  81e9c2:	cmp    $0xffffffff,%ecx
  81e9c5:	jne    81f534 <<gpui_gpu::renderer::RendererState>::render+0x1484>
  81e9cb:	mov    %eax,%ecx
  81e9cd:	shr    $0x20,%rax
  81e9d1:	movd   %ecx,%xmm0
  81e9d5:	movaps 0x80(%rsp),%xmm2
  81e9dd:	movaps %xmm2,%xmm1
  81e9e0:	maxss  %xmm0,%xmm1
  81e9e4:	movaps %xmm1,%xmm3
  81e9e7:	cmpunordss %xmm1,%xmm3
  81e9ec:	movaps %xmm3,%xmm0
  81e9ef:	andnps %xmm1,%xmm0
  81e9f2:	andps  %xmm2,%xmm3
  81e9f5:	orps   %xmm0,%xmm3
  81e9f8:	movaps %xmm3,0x40(%rsp)
  81e9fd:	movd   %eax,%xmm0
  81ea01:	movaps 0x60(%rsp),%xmm2
  81ea06:	movaps %xmm2,%xmm1
  81ea09:	maxss  %xmm0,%xmm1
  81ea0d:	movaps %xmm1,%xmm3
  81ea10:	cmpunordss %xmm1,%xmm3
  81ea15:	movaps %xmm3,%xmm0
  81ea18:	andnps %xmm1,%xmm0
  81ea1b:	andps  %xmm2,%xmm3
  81ea1e:	orps   %xmm0,%xmm3
  81ea21:	movaps %xmm3,0x90(%rsp)
  81ea29:	lea    0x300(%rsp),%rdi
  81ea31:	lea    0x408(%rsp),%rsi
  81ea39:	call   821bc0 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81ea3e:	cmpb   $0xff,0x308(%rsp)
  81ea46:	movaps 0x40(%rsp),%xmm0
  81ea4b:	movaps %xmm0,0x80(%rsp)
  81ea53:	movaps 0x90(%rsp),%xmm0
  81ea5b:	movaps %xmm0,0x60(%rsp)
  81ea60:	jne    81e900 <<gpui_gpu::renderer::RendererState>::render+0x850>
  81ea66:	jmp    81efba <<gpui_gpu::renderer::RendererState>::render+0xf0a>
  81ea6b:	cmpq   $0x0,0xa0(%rsp)
  81ea74:	je     81f423 <<gpui_gpu::renderer::RendererState>::render+0x1373>
  81ea7a:	mov    0x7c(%rsp),%eax
  81ea7e:	or     $0x80000000,%eax
  81ea83:	mov    %eax,0x240(%rsp)
  81ea8a:	movq   $0x0,0x90(%rsp)
  81ea96:	mov    0x28(%rsp),%rax
  81ea9b:	mov    0x90(%rsp),%rcx
  81eaa3:	mov    (%rax,%rcx,1),%edx
  81eaa6:	lea    0x110(%rsp),%rdi
  81eaae:	mov    0x18(%rsp),%rsi
  81eab3:	call   81c970 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81eab8:	movzbl 0x110(%rsp),%edi
  81eac0:	lea    0x111(%rsp),%rdx
  81eac8:	mov    (%rdx),%eax
  81eaca:	mov    0x3(%rdx),%ecx
  81eacd:	lea    0x460(%rsp),%rsi
  81ead5:	mov    %ecx,-0x34(%rsi)
  81ead8:	mov    %eax,-0x37(%rsi)
  81eadb:	mov    0x118(%rsp),%rcx
  81eae3:	mov    0x2f(%rdx),%rax
  81eae7:	mov    %rax,-0x8(%rsi)
  81eaeb:	movups 0xf(%rdx),%xmm0
  81eaef:	movups 0x1f(%rdx),%xmm1
  81eaf3:	movups %xmm1,-0x18(%rsi)
  81eaf7:	movups %xmm0,-0x28(%rsi)
  81eafb:	lea    0x128(%rsp),%rax
  81eb03:	movups 0x20(%rax),%xmm0
  81eb07:	movups %xmm0,(%rsi)
  81eb0a:	movups 0x30(%rax),%xmm0
  81eb0e:	movups %xmm0,0x50(%rsi)
  81eb12:	lea    0x260(%rsp),%rax
  81eb1a:	movups 0x40(%rax),%xmm0
  81eb1e:	movups %xmm0,0x60(%rsi)
  81eb22:	movups (%rax),%xmm0
  81eb25:	movups 0x10(%rax),%xmm1
  81eb29:	movups 0x20(%rax),%xmm2
  81eb2d:	movups %xmm2,0x30(%rsi)
  81eb31:	movups %xmm1,0x20(%rsi)
  81eb35:	movups %xmm0,0x10(%rsi)
  81eb39:	lea    0x290(%rsp),%rax
  81eb41:	movups (%rax),%xmm0
  81eb44:	movups %xmm0,0x40(%rsi)
  81eb48:	mov    %dil,0x60(%rsp)
  81eb4d:	mov    %dil,0x428(%rsp)
  81eb55:	mov    %rcx,0x80(%rsp)
  81eb5d:	mov    %rcx,0x430(%rsp)
  81eb65:	lea    0x110(%rsp),%rdi
  81eb6d:	lea    0x428(%rsp),%rsi
  81eb75:	mov    0xb8(%rsp),%rdx
  81eb7d:	mov    %r14d,%ecx
  81eb80:	mov    %r15d,%r8d
  81eb83:	call   821580 <gpui_gpu::renderer::validate_draw>
  81eb88:	mov    0x110(%rsp),%eax
  81eb8f:	mov    0x114(%rsp),%rcx
  81eb97:	mov    %rcx,0x40(%rsp)
  81eb9c:	cmp    $0xffffffff,%eax
  81eb9f:	jne    81f5ca <<gpui_gpu::renderer::RendererState>::render+0x151a>
  81eba5:	movzbl 0x60(%rsp),%eax
  81ebaa:	cmp    $0x2,%al
  81ebac:	sete   0x27(%rsp)
  81ebb1:	cmpq   $0x0,0x80(%rsp)
  81ebba:	setne  0x26(%rsp)
  81ebbf:	movups 0x460(%rsp),%xmm0
  81ebc7:	movaps %xmm0,0x2c0(%rsp)
  81ebcf:	cmp    $0x3,%al
  81ebd1:	jne    81ec63 <<gpui_gpu::renderer::RendererState>::render+0xbb3>
  81ebd7:	movss  0x42c(%rsp),%xmm0
  81ebe0:	xorps  %xmm1,%xmm1
  81ebe3:	ucomiss %xmm1,%xmm0
  81ebe6:	jne    81ebea <<gpui_gpu::renderer::RendererState>::render+0xb3a>
  81ebe8:	jnp    81ec63 <<gpui_gpu::renderer::RendererState>::render+0xbb3>
  81ebea:	movaps 0x2c0(%rsp),%xmm5
  81ebf2:	movaps %xmm5,%xmm1
  81ebf5:	unpckhpd %xmm5,%xmm1
  81ebf9:	movss  -0x76fc95(%rip),%xmm4        # aef6c <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  81ec01:	mulss  %xmm4,%xmm1
  81ec05:	movaps %xmm0,%xmm2
  81ec08:	minss  %xmm1,%xmm2
  81ec0c:	movaps %xmm2,%xmm1
  81ec0f:	cmpunordss %xmm2,%xmm1
  81ec14:	movaps %xmm1,%xmm3
  81ec17:	andnps %xmm2,%xmm3
  81ec1a:	andps  %xmm0,%xmm1
  81ec1d:	orps   %xmm3,%xmm1
  81ec20:	movaps %xmm5,%xmm0
  81ec23:	shufps $0xff,%xmm5,%xmm0
  81ec27:	mulss  %xmm4,%xmm0
  81ec2b:	movaps %xmm1,%xmm2
  81ec2e:	minss  %xmm0,%xmm2
  81ec32:	movaps %xmm2,%xmm0
  81ec35:	cmpunordss %xmm2,%xmm0
  81ec3a:	andps  %xmm0,%xmm1
  81ec3d:	andnps %xmm2,%xmm0
  81ec40:	orps   %xmm1,%xmm0
  81ec43:	movd   %xmm0,%eax
  81ec47:	mov    %eax,0x60(%rsp)
  81ec4b:	and    $0xff800000,%eax
  81ec50:	mov    $0x7f000000,%ecx
  81ec55:	sub    %eax,%ecx
  81ec57:	mov    %ecx,0x80(%rsp)
  81ec5e:	xorps  %xmm0,%xmm0
  81ec61:	jmp    81ec85 <<gpui_gpu::renderer::RendererState>::render+0xbd5>
  81ec63:	mov    0x4c0(%rsp),%eax
  81ec6a:	mov    %eax,0x60(%rsp)
  81ec6e:	mov    0x4c4(%rsp),%eax
  81ec75:	mov    %eax,0x80(%rsp)
  81ec7c:	movsd  0x4c8(%rsp),%xmm0
  81ec85:	movaps %xmm0,0xd0(%rsp)
  81ec8d:	mov    0x8(%rsp),%rax
  81ec92:	mov    0x10(%rax),%ecx
  81ec95:	mov    $0x80000000,%eax
  81ec9a:	or     %eax,%ecx
  81ec9c:	mov    %ecx,0x360(%rsp)
  81eca3:	movups 0x470(%rsp),%xmm0
  81ecab:	movaps %xmm0,0x3c0(%rsp)
  81ecb3:	movups 0x478(%rsp),%xmm0
  81ecbb:	movaps %xmm0,0x4e0(%rsp)
  81ecc3:	movsd  0x480(%rsp),%xmm0
  81eccc:	movaps %xmm0,0x3b0(%rsp)
  81ecd4:	movsd  0x488(%rsp),%xmm0
  81ecdd:	movaps %xmm0,0x4d0(%rsp)
  81ece5:	movsd  0x490(%rsp),%xmm0
  81ecee:	movsd  %xmm0,0x3e0(%rsp)
  81ecf7:	movsd  0x498(%rsp),%xmm0
  81ed00:	movsd  %xmm0,0x3d8(%rsp)
  81ed09:	movups 0x4a0(%rsp),%xmm0
  81ed11:	movaps %xmm0,0x2b0(%rsp)
  81ed19:	mov    0x18(%rsp),%rax
  81ed1e:	mov    %rax,0x110(%rsp)
  81ed26:	mov    0x28(%rsp),%rax
  81ed2b:	mov    %rax,0x118(%rsp)
  81ed33:	mov    0xa0(%rsp),%rax
  81ed3b:	mov    %rax,0x120(%rsp)
  81ed43:	movaps 0x2d0(%rsp),%xmm0
  81ed4b:	movaps 0x2e0(%rsp),%xmm1
  81ed53:	movaps 0x2f0(%rsp),%xmm2
  81ed5b:	lea    0x128(%rsp),%rax
  81ed63:	movups %xmm2,0x20(%rax)
  81ed67:	movups %xmm1,0x10(%rax)
  81ed6b:	movups %xmm0,(%rax)
  81ed6e:	movaps 0x4f0(%rsp),%xmm0
  81ed76:	movups %xmm0,0x30(%rax)
  81ed7a:	movaps 0x3f0(%rsp),%xmm0
  81ed82:	movups %xmm0,0x40(%rax)
  81ed86:	lea    0x110(%rsp),%rdi
  81ed8e:	call   *0x660e44(%rip)        # e7fbd8 <_DYNAMIC+0x5c0>
  81ed94:	mov    0x7c(%rsp),%ecx
  81ed98:	mov    %ecx,0xf0(%rsp)
  81ed9f:	test   %eax,%eax
  81eda1:	je     81edd7 <<gpui_gpu::renderer::RendererState>::render+0xd27>
  81eda3:	mov    0x38(%rsp),%rdi
  81eda8:	mov    %eax,%esi
  81edaa:	call   825ab0 <gpui_gpu::renderer::slots::color_word>
  81edaf:	mov    %eax,0x60(%rsp)
  81edb3:	xorps  %xmm0,%xmm0
  81edb6:	movaps %xmm0,0xd0(%rsp)
  81edbe:	movl   $0x0,0x80(%rsp)
  81edc9:	mov    0x240(%rsp),%eax
  81edd0:	mov    %eax,0xf0(%rsp)
  81edd7:	mov    0x40(%rsp),%rax
  81eddc:	shr    $0x20,%rax
  81ede0:	mov    %rax,0x3d0(%rsp)
  81ede8:	mov    0x8(%rsp),%rax
  81eded:	mov    (%rax),%rcx
  81edf0:	mov    0x10(%rax),%rsi
  81edf4:	sub    %rsi,%rcx
  81edf7:	cmp    $0x5,%rcx
  81edfb:	jbe    81ef82 <<gpui_gpu::renderer::RendererState>::render+0xed2>
  81ee01:	movsd  0x3d8(%rsp),%xmm0
  81ee0a:	cvtsd2ss %xmm0,%xmm0
  81ee0e:	movsd  0x3e0(%rsp),%xmm1
  81ee17:	cvtsd2ss %xmm1,%xmm1
  81ee1b:	movapd 0x4e0(%rsp),%xmm2
  81ee24:	unpcklpd 0x4d0(%rsp),%xmm2
  81ee2d:	cvtpd2ps %xmm2,%xmm2
  81ee31:	movapd 0x3c0(%rsp),%xmm3
  81ee3a:	unpcklpd 0x3b0(%rsp),%xmm3
  81ee43:	cvtpd2ps %xmm3,%xmm3
  81ee47:	mov    0x8(%rsp),%rax
  81ee4c:	mov    0x8(%rax),%rdx
  81ee50:	shl    $0x4,%rsi
  81ee54:	movaps 0x2c0(%rsp),%xmm4
  81ee5c:	movups %xmm4,(%rdx,%rsi,1)
  81ee60:	movlpd %xmm3,0x10(%rdx,%rsi,1)
  81ee66:	movss  %xmm1,0x18(%rdx,%rsi,1)
  81ee6c:	mov    0x40(%rsp),%rcx
  81ee71:	mov    %ecx,0x1c(%rdx,%rsi,1)
  81ee75:	movlpd %xmm2,0x20(%rdx,%rsi,1)
  81ee7b:	movss  %xmm0,0x28(%rdx,%rsi,1)
  81ee81:	mov    0x3d0(%rsp),%rdi
  81ee89:	mov    %edi,0x2c(%rdx,%rsi,1)
  81ee8d:	movaps 0x2b0(%rsp),%xmm0
  81ee95:	movups %xmm0,0x30(%rdx,%rsi,1)
  81ee9a:	mov    0x60(%rsp),%edi
  81ee9e:	mov    %edi,0x40(%rdx,%rsi,1)
  81eea2:	mov    0x80(%rsp),%edi
  81eea9:	mov    %edi,0x44(%rdx,%rsi,1)
  81eead:	movaps 0xd0(%rsp),%xmm0
  81eeb5:	movlps %xmm0,0x48(%rdx,%rsi,1)
  81eeba:	movq   $0x0,0x50(%rdx,%rsi,1)
  81eec3:	movl   $0x0,0x58(%rdx,%rsi,1)
  81eecb:	mov    0xf0(%rsp),%edi
  81eed2:	mov    %edi,0x5c(%rdx,%rsi,1)
  81eed6:	addq   $0x6,0x10(%rax)
  81eedb:	sub    $0x8,%rsp
  81eedf:	lea    0x118(%rsp),%rdi
  81eee7:	mov    %rax,%rsi
  81eeea:	lea    0x430(%rsp),%rdx
  81eef2:	mov    0x368(%rsp),%r8d
  81eefa:	mov    0x60(%rsp),%r9
  81eeff:	push   0xe8(%rsp)
  81ef06:	push   %r15
  81ef08:	push   %r14
  81ef0a:	call   820550 <<gpui_gpu::renderer::RendererState>::bin_draw>
  81ef0f:	add    $0x20,%rsp
  81ef13:	mov    0x110(%rsp),%eax
  81ef1a:	cmp    $0xffffffff,%eax
  81ef1d:	jne    81f592 <<gpui_gpu::renderer::RendererState>::render+0x14e2>
  81ef23:	movzbl 0x27(%rsp),%ecx
  81ef28:	and    0x26(%rsp),%cl
  81ef2c:	mov    0x10(%rsp),%rax
  81ef31:	or     %cl,%al
  81ef33:	mov    %rax,0x10(%rsp)
  81ef38:	mov    0x118(%rsp),%rax
  81ef40:	mov    %rax,0xe0(%rsp)
  81ef48:	incq   0xb8(%rsp)
  81ef50:	mov    0x90(%rsp),%rdx
  81ef58:	add    $0x4,%rdx
  81ef5c:	mov    0xa0(%rsp),%rax
  81ef64:	lea    0x0(,%rax,4),%rax
  81ef6c:	mov    %rdx,0x90(%rsp)
  81ef74:	cmp    %rdx,%rax
  81ef77:	jne    81ea96 <<gpui_gpu::renderer::RendererState>::render+0x9e6>
  81ef7d:	jmp    81f417 <<gpui_gpu::renderer::RendererState>::render+0x1367>
  81ef82:	mov    $0x6,%edx
  81ef87:	mov    $0x4,%ecx
  81ef8c:	mov    $0x10,%r8d
  81ef92:	mov    0x8(%rsp),%rdi
  81ef97:	call   823b00 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  81ef9c:	mov    0x8(%rsp),%rax
  81efa1:	mov    0x10(%rax),%rsi
  81efa5:	jmp    81ee01 <<gpui_gpu::renderer::RendererState>::render+0xd51>
  81efaa:	xorps  %xmm0,%xmm0
  81efad:	movaps %xmm0,0x90(%rsp)
  81efb5:	movaps %xmm0,0x40(%rsp)
  81efba:	mov    0x8(%rsp),%rax
  81efbf:	mov    0x10(%rax),%eax
  81efc2:	mov    %eax,0xd0(%rsp)
  81efc9:	movups 0x260(%rsp),%xmm1
  81efd1:	movups 0x268(%rsp),%xmm2
  81efd9:	movsd  0x280(%rsp),%xmm0
  81efe2:	movsd  %xmm0,0xf0(%rsp)
  81efeb:	movsd  0x288(%rsp),%xmm0
  81eff4:	movsd  %xmm0,0x2c0(%rsp)
  81effd:	movups 0x290(%rsp),%xmm0
  81f005:	movaps %xmm0,0x80(%rsp)
  81f00d:	movhps 0x270(%rsp),%xmm1
  81f015:	movaps %xmm1,0x360(%rsp)
  81f01d:	movups 0x2a0(%rsp),%xmm0
  81f025:	movaps %xmm0,0x60(%rsp)
  81f02a:	movhps 0x278(%rsp),%xmm2
  81f032:	movaps %xmm2,0x2b0(%rsp)
  81f03a:	mov    0x18(%rsp),%rax
  81f03f:	mov    %rax,0x110(%rsp)
  81f047:	mov    0x28(%rsp),%rax
  81f04c:	mov    %rax,0x118(%rsp)
  81f054:	mov    0xa0(%rsp),%rax
  81f05c:	mov    %rax,0x120(%rsp)
  81f064:	lea    0x260(%rsp),%rax
  81f06c:	movups (%rax),%xmm0
  81f06f:	movups 0x10(%rax),%xmm1
  81f073:	movups 0x20(%rax),%xmm2
  81f077:	lea    0x128(%rsp),%rdx
  81f07f:	movups %xmm2,0x20(%rdx)
  81f083:	movups %xmm1,0x10(%rdx)
  81f087:	movups %xmm0,(%rdx)
  81f08a:	lea    0x290(%rsp),%rcx
  81f092:	movups (%rcx),%xmm0
  81f095:	movups %xmm0,0x30(%rdx)
  81f099:	movdqu 0x40(%rax),%xmm0
  81f09e:	movdqu %xmm0,0x40(%rdx)
  81f0a3:	lea    0x110(%rsp),%rdi
  81f0ab:	call   *0x660b27(%rip)        # e7fbd8 <_DYNAMIC+0x5c0>
  81f0b1:	test   %eax,%eax
  81f0b3:	je     81f0d3 <<gpui_gpu::renderer::RendererState>::render+0x1023>
  81f0b5:	mov    0x38(%rsp),%rdi
  81f0ba:	mov    %eax,%esi
  81f0bc:	call   825ab0 <gpui_gpu::renderer::slots::color_word>
  81f0c1:	orl    $0x80000000,0x7c(%rsp)
  81f0c9:	movd   %eax,%xmm0
  81f0cd:	movdqa %xmm0,0x60(%rsp)
  81f0d3:	mov    0x8(%rsp),%rax
  81f0d8:	mov    (%rax),%rcx
  81f0db:	mov    0x10(%rax),%rsi
  81f0df:	sub    %rsi,%rcx
  81f0e2:	cmp    $0x4,%rcx
  81f0e6:	jbe    81f451 <<gpui_gpu::renderer::RendererState>::render+0x13a1>
  81f0ec:	cvtpd2ps 0x360(%rsp),%xmm0
  81f0f5:	cvtpd2ps 0x2b0(%rsp),%xmm1
  81f0fe:	movsd  0xf0(%rsp),%xmm2
  81f107:	cvtsd2ss %xmm2,%xmm2
  81f10b:	movsd  0x2c0(%rsp),%xmm3
  81f114:	cvtsd2ss %xmm3,%xmm3
  81f118:	mov    0x8(%rsp),%rax
  81f11d:	mov    0x8(%rax),%rcx
  81f121:	shl    $0x4,%rsi
  81f125:	movlpd %xmm0,(%rcx,%rsi,1)
  81f12a:	movss  %xmm2,0x8(%rcx,%rsi,1)
  81f130:	movaps 0x40(%rsp),%xmm0
  81f135:	movss  %xmm0,0xc(%rcx,%rsi,1)
  81f13b:	movlpd %xmm1,0x10(%rcx,%rsi,1)
  81f141:	movss  %xmm3,0x18(%rcx,%rsi,1)
  81f147:	movaps 0x90(%rsp),%xmm0
  81f14f:	movss  %xmm0,0x1c(%rcx,%rsi,1)
  81f155:	movaps 0x80(%rsp),%xmm0
  81f15d:	movups %xmm0,0x20(%rcx,%rsi,1)
  81f162:	movaps 0x60(%rsp),%xmm0
  81f167:	movups %xmm0,0x30(%rcx,%rsi,1)
  81f16c:	mov    0x7c(%rsp),%edx
  81f170:	mov    %edx,0x40(%rcx,%rsi,1)
  81f174:	movq   $0x0,0x44(%rcx,%rsi,1)
  81f17d:	movl   $0x0,0x4c(%rcx,%rsi,1)
  81f185:	addq   $0x5,0x10(%rax)
  81f18a:	incq   0x200(%rsp)
  81f192:	mov    0xa0(%rsp),%rax
  81f19a:	add    %rax,0x208(%rsp)
  81f1a2:	test   %rax,%rax
  81f1a5:	je     81f423 <<gpui_gpu::renderer::RendererState>::render+0x1373>
  81f1ab:	movdqa 0x40(%rsp),%xmm0
  81f1b1:	movd   %xmm0,%ecx
  81f1b5:	movdqa 0x90(%rsp),%xmm0
  81f1be:	movd   %xmm0,%eax
  81f1c2:	shl    $0x20,%rax
  81f1c6:	or     %rax,%rcx
  81f1c9:	mov    %rcx,0xf0(%rsp)
  81f1d1:	mov    0x370(%rsp),%rax
  81f1d9:	add    $0xfffffffffffffffc,%rax
  81f1dd:	shr    $0x2,%rax
  81f1e1:	mov    0xb8(%rsp),%rcx
  81f1e9:	add    %rax,%rcx
  81f1ec:	inc    %rcx
  81f1ef:	mov    %rcx,0xb8(%rsp)
  81f1f7:	movq   $0x0,0x40(%rsp)
  81f200:	mov    0x28(%rsp),%rax
  81f205:	mov    0x40(%rsp),%rcx
  81f20a:	mov    (%rax,%rcx,1),%edx
  81f20d:	lea    0x300(%rsp),%rdi
  81f215:	mov    0x18(%rsp),%rsi
  81f21a:	call   81c970 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81f21f:	movzbl 0x300(%rsp),%edi
  81f227:	lea    0x308(%rsp),%rsi
  81f22f:	mov    -0x7(%rsi),%eax
  81f232:	mov    -0x4(%rsi),%ecx
  81f235:	lea    0x111(%rsp),%rdx
  81f23d:	mov    %ecx,0x3(%rdx)
  81f240:	mov    %eax,(%rdx)
  81f242:	mov    0x308(%rsp),%rcx
  81f24a:	mov    0x28(%rsi),%rax
  81f24e:	mov    %rax,0x2f(%rdx)
  81f252:	movups 0x8(%rsi),%xmm0
  81f256:	movups 0x18(%rsi),%xmm1
  81f25a:	movups %xmm1,0x1f(%rdx)
  81f25e:	movups %xmm0,0xf(%rdx)
  81f262:	movups 0x338(%rsp),%xmm1
  81f26a:	lea    0x348(%rsp),%rax
  81f272:	movups (%rax),%xmm0
  81f275:	lea    0x128(%rsp),%rax
  81f27d:	movups %xmm0,0x70(%rax)
  81f281:	movaps 0x3f0(%rsp),%xmm0
  81f289:	movups %xmm0,0x80(%rax)
  81f290:	movaps %xmm1,0xa0(%rsp)
  81f298:	movups %xmm1,0x148(%rsp)
  81f2a0:	movaps 0x500(%rsp),%xmm0
  81f2a8:	movaps 0x510(%rsp),%xmm1
  81f2b0:	movapd 0x520(%rsp),%xmm2
  81f2b9:	movupd %xmm2,0x50(%rax)
  81f2be:	movups %xmm1,0x40(%rax)
  81f2c2:	movups %xmm0,0x30(%rax)
  81f2c6:	movaps 0x530(%rsp),%xmm0
  81f2ce:	movups %xmm0,0x60(%rax)
  81f2d2:	mov    %dil,0x60(%rsp)
  81f2d7:	mov    %dil,0x110(%rsp)
  81f2df:	mov    %rcx,0x80(%rsp)
  81f2e7:	mov    %rcx,0x118(%rsp)
  81f2ef:	mov    0x8(%rsp),%rax
  81f2f4:	mov    (%rax),%rcx
  81f2f7:	mov    0x10(%rax),%rax
  81f2fb:	sub    %rax,%rcx
  81f2fe:	mov    %rax,0x90(%rsp)
  81f306:	cmp    $0x1,%rcx
  81f30a:	jbe    81f3e7 <<gpui_gpu::renderer::RendererState>::render+0x1337>
  81f310:	mov    0x8(%rsp),%rsi
  81f315:	mov    0x8(%rsi),%rcx
  81f319:	shl    $0x4,%rax
  81f31d:	movaps 0xa0(%rsp),%xmm0
  81f325:	movups %xmm0,(%rcx,%rax,1)
  81f329:	movq   $0x0,0x10(%rcx,%rax,1)
  81f332:	movl   $0x0,0x18(%rcx,%rax,1)
  81f33a:	mov    0xd0(%rsp),%edx
  81f341:	mov    %edx,0x1c(%rcx,%rax,1)
  81f345:	addq   $0x2,0x10(%rsi)
  81f34a:	sub    $0x8,%rsp
  81f34e:	lea    0x308(%rsp),%rdi
  81f356:	lea    0x118(%rsp),%rdx
  81f35e:	mov    0xf8(%rsp),%rcx
  81f366:	mov    0x98(%rsp),%r8
  81f36e:	mov    0x60(%rsp),%r9
  81f373:	push   0xe8(%rsp)
  81f37a:	push   %r15
  81f37c:	push   %r14
  81f37e:	call   820550 <<gpui_gpu::renderer::RendererState>::bin_draw>
  81f383:	add    $0x20,%rsp
  81f387:	mov    0x300(%rsp),%eax
  81f38e:	cmp    $0xffffffff,%eax
  81f391:	jne    81f5ae <<gpui_gpu::renderer::RendererState>::render+0x14fe>
  81f397:	cmpb   $0x2,0x60(%rsp)
  81f39c:	sete   %al
  81f39f:	cmpq   $0x0,0x80(%rsp)
  81f3a8:	setne  %cl
  81f3ab:	and    %al,%cl
  81f3ad:	mov    0x10(%rsp),%rax
  81f3b2:	or     %cl,%al
  81f3b4:	mov    %rax,0x10(%rsp)
  81f3b9:	mov    0x308(%rsp),%rax
  81f3c1:	mov    %rax,0xe0(%rsp)
  81f3c9:	mov    0x40(%rsp),%rcx
  81f3ce:	add    $0x4,%rcx
  81f3d2:	mov    %rcx,0x40(%rsp)
  81f3d7:	cmp    %rcx,0x370(%rsp)
  81f3df:	jne    81f200 <<gpui_gpu::renderer::RendererState>::render+0x1150>
  81f3e5:	jmp    81f417 <<gpui_gpu::renderer::RendererState>::render+0x1367>
  81f3e7:	mov    $0x2,%edx
  81f3ec:	mov    $0x4,%ecx
  81f3f1:	mov    $0x10,%r8d
  81f3f7:	mov    0x8(%rsp),%rdi
  81f3fc:	mov    0x90(%rsp),%rsi
  81f404:	call   823b00 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  81f409:	mov    0x8(%rsp),%rax
  81f40e:	mov    0x10(%rax),%rax
  81f412:	jmp    81f310 <<gpui_gpu::renderer::RendererState>::render+0x1260>
  81f417:	mov    0x10(%rsp),%rax
  81f41c:	and    $0x1,%al
  81f41e:	mov    %rax,0x10(%rsp)
  81f423:	lea    0x248(%rsp),%rdi
  81f42b:	lea    0x388(%rsp),%rsi
  81f433:	call   *0x660797(%rip)        # e7fbd0 <_DYNAMIC+0x5b8>
  81f439:	mov    0x248(%rsp),%rax
  81f441:	mov    %rax,0x18(%rsp)
  81f446:	test   %rax,%rax
  81f449:	jne    81e754 <<gpui_gpu::renderer::RendererState>::render+0x6a4>
  81f44f:	jmp    81f4b2 <<gpui_gpu::renderer::RendererState>::render+0x1402>
  81f451:	mov    $0x5,%edx
  81f456:	mov    $0x4,%ecx
  81f45b:	mov    $0x10,%r8d
  81f461:	mov    0x8(%rsp),%rdi
  81f466:	call   823b00 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  81f46b:	mov    0x8(%rsp),%rax
  81f470:	mov    0x10(%rax),%rsi
  81f474:	jmp    81f0ec <<gpui_gpu::renderer::RendererState>::render+0x103c>
  81f479:	movq   $0x0,0x208(%rsp)
  81f485:	movq   $0x0,0x200(%rsp)
  81f491:	movq   $0x0,0xb8(%rsp)
  81f49d:	movq   $0x0,0x10(%rsp)
  81f4a6:	movq   $0x0,0xe0(%rsp)
  81f4b2:	mov    0x108(%rsp),%rsi
  81f4ba:	lea    0x8(%rsi),%rdx
  81f4be:	mov    0x8(%rsp),%rax
  81f4c3:	lea    0x240(%rax),%rcx
  81f4ca:	lea    0x310(%rax),%r8
  81f4d1:	mov    0x10(%rax),%r9
  81f4d5:	sub    $0x8,%rsp
  81f4d9:	lea    0x118(%rsp),%rdi
  81f4e1:	mov    %rdx,0x3c8(%rsp)
  81f4e9:	mov    %rcx,0x2b8(%rsp)
  81f4f1:	mov    %r8,0x2c8(%rsp)
  81f4f9:	push   0xf0(%rsp)
  81f500:	call   822a40 <gpui_gpu::renderer::images::prepare>
  81f505:	add    $0x10,%rsp
  81f509:	cmpl   $0xffffffff,0x110(%rsp)
  81f511:	je     81f55a <<gpui_gpu::renderer::RendererState>::render+0x14aa>
  81f513:	movups 0x110(%rsp),%xmm0
  81f51b:	movups 0x120(%rsp),%xmm1
  81f523:	mov    0x30(%rsp),%rdi
  81f528:	movups %xmm1,0x10(%rdi)
  81f52c:	movups %xmm0,(%rdi)
  81f52f:	jmp    81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81f534:	mov    0x23c(%rsp),%edx
  81f53b:	mov    0x30(%rsp),%rdi
  81f540:	mov    %edx,0x1c(%rdi)
  81f543:	movups 0x22c(%rsp),%xmm0
  81f54b:	movups %xmm0,0xc(%rdi)
  81f54f:	mov    %ecx,(%rdi)
  81f551:	mov    %rax,0x4(%rdi)
  81f555:	jmp    81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81f55a:	movzbl 0x10(%rsp),%r8d
  81f560:	and    $0x1,%r8d
  81f564:	lea    0x110(%rsp),%rdi
  81f56c:	mov    0x8(%rsp),%rsi
  81f571:	mov    0x108(%rsp),%rdx
  81f579:	mov    0xc8(%rsp),%rcx
  81f581:	call   81d830 <<gpui_gpu::renderer::RendererState>::prepare_atlas>
  81f586:	mov    0x110(%rsp),%eax
  81f58d:	cmp    $0xffffffff,%eax
  81f590:	je     81f5f5 <<gpui_gpu::renderer::RendererState>::render+0x1545>
  81f592:	mov    0x114(%rsp),%ecx
  81f599:	mov    0x118(%rsp),%rdx
  81f5a1:	movups 0x120(%rsp),%xmm0
  81f5a9:	jmp    81e5e3 <<gpui_gpu::renderer::RendererState>::render+0x533>
  81f5ae:	mov    0x304(%rsp),%ecx
  81f5b5:	mov    0x308(%rsp),%rdx
  81f5bd:	movups 0x310(%rsp),%xmm0
  81f5c5:	jmp    81e5e3 <<gpui_gpu::renderer::RendererState>::render+0x533>
  81f5ca:	mov    0x12c(%rsp),%ecx
  81f5d1:	mov    0x30(%rsp),%rdi
  81f5d6:	mov    %ecx,0x1c(%rdi)
  81f5d9:	movups 0x11c(%rsp),%xmm0
  81f5e1:	movups %xmm0,0xc(%rdi)
  81f5e5:	mov    %eax,(%rdi)
  81f5e7:	mov    0x40(%rsp),%rax
  81f5ec:	mov    %rax,0x4(%rdi)
  81f5f0:	jmp    81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81f5f5:	mov    0x118(%rsp),%rax
  81f5fd:	mov    %rax,0x3b0(%rsp)
  81f605:	mov    0xc8(%rsp),%rax
  81f60d:	mov    %rax,0x300(%rsp)
  81f615:	movq   $0x0,0x308(%rsp)
  81f621:	mov    0xc0(%rsp),%rax
  81f629:	mov    %rax,0x310(%rsp)
  81f631:	mov    0x210(%rsp),%rax
  81f639:	mov    %rax,0x318(%rsp)
  81f641:	mov    0x78(%rsp),%eax
  81f645:	mov    %eax,0x320(%rsp)
  81f64c:	lea    0x248(%rsp),%rdi
  81f654:	lea    0x300(%rsp),%rsi
  81f65c:	call   *0x66056e(%rip)        # e7fbd0 <_DYNAMIC+0x5b8>
  81f662:	mov    0x248(%rsp),%rax
  81f66a:	mov    %rax,0xa0(%rsp)
  81f672:	test   %rax,%rax
  81f675:	je     81fa46 <<gpui_gpu::renderer::RendererState>::render+0x1996>
  81f67b:	mov    0x8(%rsp),%rax
  81f680:	add    $0x108,%rax
  81f686:	mov    %rax,0x360(%rsp)
  81f68e:	jmp    81f6c9 <<gpui_gpu::renderer::RendererState>::render+0x1619>
  81f690:	lea    0x248(%rsp),%rdi
  81f698:	lea    0x300(%rsp),%rsi
  81f6a0:	call   *0x66052a(%rip)        # e7fbd0 <_DYNAMIC+0x5b8>
  81f6a6:	mov    0x248(%rsp),%rax
  81f6ae:	mov    0x10(%rsp),%rcx
  81f6b3:	mov    %rcx,0x50(%rsp)
  81f6b8:	mov    %rax,0xa0(%rsp)
  81f6c0:	test   %rax,%rax
  81f6c3:	je     81fa46 <<gpui_gpu::renderer::RendererState>::render+0x1996>
  81f6c9:	mov    0x250(%rsp),%rdx
  81f6d1:	mov    0x258(%rsp),%rdi
  81f6d9:	mov    %rdi,0x90(%rsp)
  81f6e1:	lea    0x260(%rsp),%rax
  81f6e9:	movups 0x40(%rax),%xmm0
  81f6ed:	lea    0x128(%rsp),%rcx
  81f6f5:	movups %xmm0,0x40(%rcx)
  81f6f9:	movups (%rax),%xmm0
  81f6fc:	movups 0x10(%rax),%xmm1
  81f700:	movups 0x20(%rax),%xmm2
  81f704:	movups 0x30(%rax),%xmm3
  81f708:	movups %xmm3,0x30(%rcx)
  81f70c:	movups %xmm2,0x20(%rcx)
  81f710:	movups %xmm1,0x10(%rcx)
  81f714:	movups %xmm0,(%rcx)
  81f717:	mov    0x8(%rsp),%rax
  81f71c:	movzbl 0x329(%rax),%esi
  81f723:	mov    0xa0(%rsp),%rax
  81f72b:	mov    %rax,0x110(%rsp)
  81f733:	mov    %rdx,0x60(%rsp)
  81f738:	mov    %rdx,0x118(%rsp)
  81f740:	mov    %rdi,0x120(%rsp)
  81f748:	lea    0x110(%rsp),%rdi
  81f750:	call   821530 <gpui_gpu::renderer::compact_group>
  81f755:	mov    0x50(%rsp),%rcx
  81f75a:	lea    0x5(%rcx),%rdx
  81f75e:	test   %al,%al
  81f760:	cmove  %rcx,%rdx
  81f764:	mov    %rdx,0x10(%rsp)
  81f769:	cmpq   $0x0,0x90(%rsp)
  81f772:	je     81f690 <<gpui_gpu::renderer::RendererState>::render+0x15e0>
  81f778:	shlq   $0x2,0x90(%rsp)
  81f781:	xor    $0x1,%al
  81f783:	movzbl %al,%ecx
  81f786:	shl    $0x2,%ecx
  81f789:	lea    0x1(%rcx),%rax
  81f78d:	mov    %rax,0x80(%rsp)
  81f795:	mov    0x10(%rsp),%rax
  81f79a:	lea    (%rax,%rcx,1),%r8
  81f79e:	inc    %r8
  81f7a1:	or     $0x2,%rcx
  81f7a5:	shl    $0x4,%r8
  81f7a9:	mov    %rcx,0x50(%rsp)
  81f7ae:	shl    $0x4,%ecx
  81f7b1:	mov    %rcx,0xd0(%rsp)
  81f7b9:	xor    %ecx,%ecx
  81f7bb:	mov    %r8,0x18(%rsp)
  81f7c0:	mov    0x60(%rsp),%rax
  81f7c5:	mov    %rcx,0x38(%rsp)
  81f7ca:	mov    (%rax,%rcx,1),%edx
  81f7cd:	lea    0x110(%rsp),%rdi
  81f7d5:	mov    0xa0(%rsp),%rsi
  81f7dd:	call   81c970 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81f7e2:	movzbl 0x110(%rsp),%ecx
  81f7ea:	movzbl 0x111(%rsp),%eax
  81f7f2:	movss  0x114(%rsp),%xmm4
  81f7fb:	lea    0x118(%rsp),%rsi
  81f803:	mov    0x10(%rsi),%rdx
  81f807:	mov    %rdx,0x2e0(%rsp)
  81f80f:	movups (%rsi),%xmm0
  81f812:	movaps %xmm0,0x2d0(%rsp)
  81f81a:	cmp    $0x1,%ecx
  81f81d:	je     81f8b2 <<gpui_gpu::renderer::RendererState>::render+0x1802>
  81f823:	movaps %xmm4,0xf0(%rsp)
  81f82b:	mov    0x130(%rsp),%rsi
  81f833:	mov    0x138(%rsp),%edx
  81f83a:	mov    %edx,0x40(%rsp)
  81f83e:	mov    0x13c(%rsp),%edx
  81f845:	mov    %edx,0x28(%rsp)
  81f849:	cmp    $0x3,%ecx
  81f84c:	jne    81f937 <<gpui_gpu::renderer::RendererState>::render+0x1887>
  81f852:	mov    0x2c0(%rsp),%rcx
  81f85a:	mov    (%rcx),%rdi
  81f85d:	test   %rdi,%rdi
  81f860:	je     8204cd <<gpui_gpu::renderer::RendererState>::render+0x241d>
  81f866:	movzbl %al,%edx
  81f869:	call   8226d0 <<gpui_gpu::renderer::images::Images>::metadata>
  81f86e:	mov    %eax,%ecx
  81f870:	shr    $0x20,%rax
  81f874:	mov    %eax,%edx
  81f876:	or     $0x10,%edx
  81f879:	xorps  %xmm0,%xmm0
  81f87c:	movaps 0xf0(%rsp),%xmm1
  81f884:	ucomiss %xmm0,%xmm1
  81f887:	cmovne %edx,%eax
  81f88a:	cmovp  %edx,%eax
  81f88d:	mov    0x28(%rsp),%edx
  81f891:	shl    $0x10,%edx
  81f894:	or     0x40(%rsp),%edx
  81f898:	mov    %ecx,0x220(%rsp)
  81f89f:	mov    %eax,0x224(%rsp)
  81f8a6:	mov    %edx,0x228(%rsp)
  81f8ad:	jmp    81f9d4 <<gpui_gpu::renderer::RendererState>::render+0x1924>
  81f8b2:	movss  0x150(%rsp),%xmm0
  81f8bb:	movss  -0x770957(%rip),%xmm3        # aef6c <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  81f8c3:	mulss  %xmm3,%xmm0
  81f8c7:	movaps %xmm4,%xmm1
  81f8ca:	minss  %xmm0,%xmm1
  81f8ce:	movaps %xmm1,%xmm0
  81f8d1:	cmpunordss %xmm1,%xmm0
  81f8d6:	movaps %xmm0,%xmm2
  81f8d9:	andnps %xmm1,%xmm2
  81f8dc:	andps  %xmm4,%xmm0
  81f8df:	orps   %xmm2,%xmm0
  81f8e2:	movss  0x154(%rsp),%xmm1
  81f8eb:	mulss  %xmm3,%xmm1
  81f8ef:	movaps %xmm0,%xmm2
  81f8f2:	minss  %xmm1,%xmm2
  81f8f6:	movaps %xmm2,%xmm1
  81f8f9:	cmpunordss %xmm2,%xmm1
  81f8fe:	andps  %xmm1,%xmm0
  81f901:	andnps %xmm2,%xmm1
  81f904:	orps   %xmm0,%xmm1
  81f907:	movd   %xmm1,%eax
  81f90b:	and    $0xff800000,%eax
  81f910:	mov    $0x7f000000,%ecx
  81f915:	sub    %eax,%ecx
  81f917:	movl   $0x40000000,0x220(%rsp)
  81f922:	movss  %xmm1,0x224(%rsp)
  81f92b:	mov    %ecx,0x228(%rsp)
  81f932:	jmp    81f9d4 <<gpui_gpu::renderer::RendererState>::render+0x1924>
  81f937:	cmp    $0x2,%cl
  81f93a:	jne    81f98c <<gpui_gpu::renderer::RendererState>::render+0x18dc>
  81f93c:	mov    0x140(%rsp),%rax
  81f944:	mov    0x2e0(%rsp),%rcx
  81f94c:	mov    %rcx,0x120(%rsp)
  81f954:	movaps 0x2d0(%rsp),%xmm0
  81f95c:	movaps %xmm0,0x110(%rsp)
  81f964:	mov    %rsi,0x128(%rsp)
  81f96c:	mov    0x40(%rsp),%ecx
  81f970:	mov    %ecx,0x130(%rsp)
  81f977:	mov    0x28(%rsp),%ecx
  81f97b:	mov    %ecx,0x134(%rsp)
  81f982:	mov    %rax,0x138(%rsp)
  81f98a:	jmp    81f998 <<gpui_gpu::renderer::RendererState>::render+0x18e8>
  81f98c:	movq   $0x0,0x110(%rsp)
  81f998:	movl   $0x0,0x390(%rsp)
  81f9a3:	movq   $0x0,0x388(%rsp)
  81f9af:	lea    0x220(%rsp),%rdi
  81f9b7:	lea    0x110(%rsp),%rsi
  81f9bf:	lea    0x388(%rsp),%rdx
  81f9c7:	mov    0x360(%rsp),%rcx
  81f9cf:	call   81b710 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>>
  81f9d4:	mov    0x10(%rsp),%rdx
  81f9d9:	mov    0x80(%rsp),%rax
  81f9e1:	lea    (%rax,%rdx,1),%rdi
  81f9e5:	mov    0x8(%rsp),%rax
  81f9ea:	mov    0x10(%rax),%rsi
  81f9ee:	cmp    %rsi,%rdi
  81f9f1:	mov    0x18(%rsp),%r8
  81f9f6:	jae    8204f3 <<gpui_gpu::renderer::RendererState>::render+0x2443>
  81f9fc:	mov    0x8(%rax),%rax
  81fa00:	mov    0x228(%rsp),%ecx
  81fa07:	mov    %ecx,0x8(%rax,%r8,1)
  81fa0c:	mov    0x220(%rsp),%rcx
  81fa14:	mov    %rcx,(%rax,%r8,1)
  81fa18:	add    0x50(%rsp),%rdx
  81fa1d:	mov    %rdx,0x10(%rsp)
  81fa22:	add    0xd0(%rsp),%r8
  81fa2a:	mov    0x38(%rsp),%rcx
  81fa2f:	add    $0x4,%rcx
  81fa33:	cmp    %rcx,0x90(%rsp)
  81fa3b:	jne    81f7bb <<gpui_gpu::renderer::RendererState>::render+0x170b>
  81fa41:	jmp    81f690 <<gpui_gpu::renderer::RendererState>::render+0x15e0>
  81fa46:	cmpl   $0x0,0x58(%rsp)
  81fa4b:	je     8204da <<gpui_gpu::renderer::RendererState>::render+0x242a>
  81fa51:	mov    0x8(%rsp),%rax
  81fa56:	mov    0x28(%rax),%rax
  81fa5a:	movq   $0x0,0xd0(%rsp)
  81fa66:	mov    %rax,0x10(%rsp)
  81fa6b:	test   %rax,%rax
  81fa6e:	je     81fb9a <<gpui_gpu::renderer::RendererState>::render+0x1aea>
  81fa74:	mov    0x8(%rsp),%rcx
  81fa79:	mov    0x20(%rcx),%rcx
  81fa7d:	movq   $0x0,0x80(%rsp)
  81fa89:	movq   $0x0,0x50(%rsp)
  81fa92:	movq   $0x0,0x60(%rsp)
  81fa9b:	xor    %esi,%esi
  81fa9d:	jmp    81fac5 <<gpui_gpu::renderer::RendererState>::render+0x1a15>
  81fa9f:	mov    0x18(%rsp),%rdx
  81faa4:	lea    (%rcx,%rdx,8),%rcx
  81faa8:	mov    0xd0(%rsp),%rax
  81fab0:	inc    %eax
  81fab2:	mov    %rax,0xd0(%rsp)
  81faba:	sub    %rdx,0x10(%rsp)
  81fabf:	je     81fb8e <<gpui_gpu::renderer::RendererState>::render+0x1ade>
  81fac5:	mov    0x58(%rsp),%rax
  81faca:	mov    0x10(%rsp),%rdi
  81facf:	cmp    %rdi,%rax
  81fad2:	cmovb  %rax,%rdi
  81fad6:	mov    0xd0(%rsp),%rax
  81fade:	mov    %eax,%edx
  81fae0:	shl    $0x4,%edx
  81fae3:	mov    %r15d,%r8d
  81fae6:	sub    %edx,%r8d
  81fae9:	cmp    $0x10,%r8d
  81faed:	mov    $0x10,%eax
  81faf2:	cmovae %eax,%r8d
  81faf6:	mov    %rdi,0x18(%rsp)
  81fafb:	lea    0x0(,%rdi,8),%r9d
  81fb03:	shl    $0x4,%r8d
  81fb07:	xor    %r10d,%r10d
  81fb0a:	mov    %r14d,%r11d
  81fb0d:	jmp    81fb2e <<gpui_gpu::renderer::RendererState>::render+0x1a7e>
  81fb0f:	movl   $0x80000000,0x4(%rcx,%r10,1)
  81fb18:	incq   0x60(%rsp)
  81fb1d:	add    $0xfffffff0,%r11d
  81fb21:	add    $0x8,%r10
  81fb25:	cmp    %r10,%r9
  81fb28:	je     81fa9f <<gpui_gpu::renderer::RendererState>::render+0x19ef>
  81fb2e:	mov    0x4(%rcx,%r10,1),%edx
  81fb33:	mov    %edx,%edi
  81fb35:	and    $0x8001ffff,%edi
  81fb3b:	cmp    $0x80000001,%edi
  81fb41:	je     81fb0f <<gpui_gpu::renderer::RendererState>::render+0x1a5f>
  81fb43:	mov    %edx,%eax
  81fb45:	and    $0x1ffff,%eax
  81fb4a:	add    %eax,%esi
  81fb4c:	shl    $0x17,%edx
  81fb4f:	or     %esi,%edx
  81fb51:	mov    %eax,%edi
  81fb53:	shl    $0xe,%edi
  81fb56:	and    $0x7f800000,%edi
  81fb5c:	or     %esi,%edi
  81fb5e:	mov    %edx,(%rcx,%r10,1)
  81fb62:	mov    %edi,0x4(%rcx,%r10,1)
  81fb67:	test   %eax,%eax
  81fb69:	je     81fb1d <<gpui_gpu::renderer::RendererState>::render+0x1a6d>
  81fb6b:	cmp    $0x10,%r11d
  81fb6f:	mov    $0x10,%edx
  81fb74:	cmovb  %r11d,%edx
  81fb78:	imul   %r8d,%edx
  81fb7c:	add    %rdx,0x50(%rsp)
  81fb81:	imul   %eax,%edx
  81fb84:	add    %rdx,0x80(%rsp)
  81fb8c:	jmp    81fb1d <<gpui_gpu::renderer::RendererState>::render+0x1a6d>
  81fb8e:	mov    %esi,%eax
  81fb90:	mov    %rax,0xd0(%rsp)
  81fb98:	jmp    81fbb8 <<gpui_gpu::renderer::RendererState>::render+0x1b08>
  81fb9a:	movq   $0x0,0x60(%rsp)
  81fba3:	movq   $0x0,0x50(%rsp)
  81fbac:	movq   $0x0,0x80(%rsp)
  81fbb8:	mov    0x8(%rsp),%rax
  81fbbd:	lea    0x30(%rax),%rdi
  81fbc1:	movq   $0x0,0x40(%rax)
  81fbc9:	movl   $0x0,0xf0(%rsp)
  81fbd4:	mov    %rdi,0xa0(%rsp)
  81fbdc:	mov    0xd0(%rsp),%rsi
  81fbe4:	xor    %edx,%edx
  81fbe6:	call   8228f0 <<alloc::vec::Vec<u32>>::resize>
  81fbeb:	mov    0x8(%rsp),%rax
  81fbf0:	mov    0x10(%rax),%rax
  81fbf4:	mov    %rax,0x28(%rsp)
  81fbf9:	mov    0xc8(%rsp),%rax
  81fc01:	mov    %rax,0x2d0(%rsp)
  81fc09:	movq   $0x0,0x2d8(%rsp)
  81fc15:	mov    0xc0(%rsp),%rax
  81fc1d:	mov    %rax,0x2e0(%rsp)
  81fc25:	mov    0x210(%rsp),%rax
  81fc2d:	mov    %rax,0x2e8(%rsp)
  81fc35:	mov    0x78(%rsp),%eax
  81fc39:	mov    %eax,0x2f0(%rsp)
  81fc40:	jmp    81fc5c <<gpui_gpu::renderer::RendererState>::render+0x1bac>
  81fc42:	mov    0x28(%rsp),%rcx
  81fc47:	lea    -0x5(%rcx),%rax
  81fc4b:	cmpb   $0x0,0xc0(%rsp)
  81fc53:	cmovne %rax,%rcx
  81fc57:	mov    %rcx,0x28(%rsp)
  81fc5c:	lea    0x248(%rsp),%rdi
  81fc64:	lea    0x2d0(%rsp),%rsi
  81fc6c:	call   *0x65ff6e(%rip)        # e7fbe0 <_DYNAMIC+0x5c8>
  81fc72:	mov    0x248(%rsp),%rax
  81fc7a:	mov    %rax,0x40(%rsp)
  81fc7f:	test   %rax,%rax
  81fc82:	je     81feb5 <<gpui_gpu::renderer::RendererState>::render+0x1e05>
  81fc88:	mov    0x250(%rsp),%rcx
  81fc90:	mov    0x258(%rsp),%rdx
  81fc98:	mov    %rdx,0x18(%rsp)
  81fc9d:	mov    0x8(%rsp),%rax
  81fca2:	movzbl 0x329(%rax),%esi
  81fca9:	mov    0x40(%rsp),%rax
  81fcae:	mov    %rax,0x110(%rsp)
  81fcb6:	mov    %rcx,0x90(%rsp)
  81fcbe:	mov    %rcx,0x118(%rsp)
  81fcc6:	mov    %rdx,0x120(%rsp)
  81fcce:	lea    0x260(%rsp),%rax
  81fcd6:	movups (%rax),%xmm0
  81fcd9:	movups 0x10(%rax),%xmm1
  81fcdd:	movdqu 0x20(%rax),%xmm2
  81fce2:	lea    0x128(%rsp),%rdx
  81fcea:	movdqu %xmm2,0x20(%rdx)
  81fcef:	movups %xmm1,0x10(%rdx)
  81fcf3:	movups %xmm0,(%rdx)
  81fcf6:	lea    0x290(%rsp),%rcx
  81fcfe:	movups (%rcx),%xmm0
  81fd01:	movups %xmm0,0x30(%rdx)
  81fd05:	movups 0x40(%rax),%xmm0
  81fd09:	movups %xmm0,0x40(%rdx)
  81fd0d:	lea    0x110(%rsp),%rdi
  81fd15:	call   821530 <gpui_gpu::renderer::compact_group>
  81fd1a:	mov    %al,0xc0(%rsp)
  81fd21:	mov    0x18(%rsp),%rax
  81fd26:	test   %rax,%rax
  81fd29:	je     81fc42 <<gpui_gpu::renderer::RendererState>::render+0x1b92>
  81fd2f:	mov    %rax,%rcx
  81fd32:	shl    $0x2,%rcx
  81fd36:	movzbl 0xc0(%rsp),%eax
  81fd3e:	lea    0x0(,%rax,4),%edx
  81fd45:	or     $0xfffffffffffffffa,%rdx
  81fd49:	xor    %esi,%esi
  81fd4b:	test   %al,%al
  81fd4d:	sete   %sil
  81fd51:	shl    $0x1f,%esi
  81fd54:	mov    %esi,0xc8(%rsp)
  81fd5b:	mov    %rdx,0x38(%rsp)
  81fd60:	mov    0x28(%rsp),%rax
  81fd65:	add    %edx,%eax
  81fd67:	mov    %eax,0x10(%rsp)
  81fd6b:	mov    %rcx,0x18(%rsp)
  81fd70:	mov    0x90(%rsp),%rax
  81fd78:	mov    -0x4(%rax,%rcx,1),%edx
  81fd7c:	lea    0x300(%rsp),%rdi
  81fd84:	mov    0x40(%rsp),%rsi
  81fd89:	call   81c970 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81fd8e:	mov    0x38(%rsp),%rax
  81fd93:	add    %rax,0x28(%rsp)
  81fd98:	mov    0xc8(%rsp),%eax
  81fd9f:	or     0x10(%rsp),%eax
  81fda3:	mov    %eax,0x220(%rsp)
  81fdaa:	lea    0x260(%rsp),%rdx
  81fdb2:	movups (%rdx),%xmm0
  81fdb5:	movups 0x10(%rdx),%xmm1
  81fdb9:	movups 0x20(%rdx),%xmm2
  81fdbd:	lea    0x128(%rsp),%rcx
  81fdc5:	movups %xmm2,0x50(%rcx)
  81fdc9:	movups %xmm1,0x40(%rcx)
  81fdcd:	movups %xmm0,0x30(%rcx)
  81fdd1:	lea    0x290(%rsp),%rax
  81fdd9:	movups (%rax),%xmm0
  81fddc:	movups %xmm0,0x60(%rcx)
  81fde0:	movups 0x40(%rdx),%xmm0
  81fde4:	movups %xmm0,0x80(%rcx)
  81fdeb:	lea    0x338(%rsp),%rax
  81fdf3:	movups (%rax),%xmm0
  81fdf6:	movups %xmm0,0x20(%rcx)
  81fdfa:	lea    0x348(%rsp),%rax
  81fe02:	movups (%rax),%xmm0
  81fe05:	movups %xmm0,0x70(%rcx)
  81fe09:	mov    0x330(%rsp),%rax
  81fe11:	mov    %rax,0x140(%rsp)
  81fe19:	movups 0x300(%rsp),%xmm0
  81fe21:	movups 0x310(%rsp),%xmm1
  81fe29:	movdqu 0x320(%rsp),%xmm2
  81fe32:	movdqa %xmm2,0x130(%rsp)
  81fe3b:	movaps %xmm1,0x120(%rsp)
  81fe43:	movaps %xmm0,0x110(%rsp)
  81fe4b:	mov    0x218(%rsp),%rax
  81fe53:	mov    %rax,0x388(%rsp)
  81fe5b:	mov    0xa0(%rsp),%rax
  81fe63:	mov    %rax,0x390(%rsp)
  81fe6b:	lea    0x220(%rsp),%rax
  81fe73:	mov    %rax,0x398(%rsp)
  81fe7b:	lea    0x110(%rsp),%rdi
  81fe83:	mov    0x58(%rsp),%rsi
  81fe88:	lea    0x388(%rsp),%rdx
  81fe90:	call   81c5d0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>>
  81fe95:	mov    0x10(%rsp),%eax
  81fe99:	add    0x38(%rsp),%eax
  81fe9d:	mov    %eax,0x10(%rsp)
  81fea1:	mov    0x18(%rsp),%rcx
  81fea6:	add    $0xfffffffffffffffc,%rcx
  81feaa:	jne    81fd6b <<gpui_gpu::renderer::RendererState>::render+0x1cbb>
  81feb0:	jmp    81fc42 <<gpui_gpu::renderer::RendererState>::render+0x1b92>
  81feb5:	test   $0x1,%r12b
  81feb9:	je     81ff0c <<gpui_gpu::renderer::RendererState>::render+0x1e5c>
  81febb:	movd   0x244(%rsp),%xmm0
  81fec4:	movd   %xmm0,%eax
  81fec8:	test   %eax,%eax
  81feca:	setns  %cl
  81fecd:	mov    %eax,%edx
  81fecf:	and    $0x7fffffff,%edx
  81fed5:	add    $0xff800000,%edx
  81fedb:	cmp    $0x7f000000,%edx
  81fee1:	setb   %dl
  81fee4:	and    %cl,%dl
  81fee6:	dec    %eax
  81fee8:	cmp    $0x7fffff,%eax
  81feed:	setb   %al
  81fef0:	or     %dl,%al
  81fef2:	movl   $0x2,0xf0(%rsp)
  81fefd:	movd   %xmm0,0x104(%rsp)
  81ff06:	je     8204c3 <<gpui_gpu::renderer::RendererState>::render+0x2413>
  81ff0c:	mov    0x108(%rsp),%r12
  81ff14:	lea    0x18(%r12),%rax
  81ff19:	mov    %rax,0x18(%rsp)
  81ff1e:	mov    0xe8(%rsp),%rax
  81ff26:	add    $0x18,%rax
  81ff2a:	xor    %ecx,%ecx
  81ff2c:	mov    0x378(%rsp),%rdx
  81ff34:	cmp    0x380(%rsp),%rdx
  81ff3c:	setne  %cl
  81ff3f:	xor    %edx,%edx
  81ff41:	cmp    $0x28,%r13d
  81ff45:	sete   %dl
  81ff48:	and    $0x1,%ebp
  81ff4b:	lea    0x0(%rbp,%rdx,4),%edx
  81ff4f:	lea    (%rdx,%rcx,8),%ecx
  81ff52:	or     0xf0(%rsp),%ecx
  81ff59:	movups (%rax),%xmm0
  81ff5c:	movups %xmm0,0x258(%rsp)
  81ff64:	mov    %r14d,0x248(%rsp)
  81ff6c:	mov    %r15d,0x24c(%rsp)
  81ff74:	mov    0x58(%rsp),%rax
  81ff79:	mov    %eax,0x250(%rsp)
  81ff80:	mov    %ecx,0x254(%rsp)
  81ff87:	movss  0x104(%rsp),%xmm0
  81ff90:	movss  %xmm0,0x268(%rsp)
  81ff99:	movq   $0x0,0x26c(%rsp)
  81ffa5:	movl   $0x0,0x274(%rsp)
  81ffb0:	mov    0x8(%rsp),%rbp
  81ffb5:	lea    0x218(%rbp),%rsi
  81ffbc:	movq   $0x0,0x10(%rsp)
  81ffc5:	lea    0x248(%rsp),%rcx
  81ffcd:	mov    $0x30,%r8d
  81ffd3:	mov    0x3c0(%rsp),%r13
  81ffdb:	mov    %r13,%rdi
  81ffde:	mov    %rsi,0x58(%rsp)
  81ffe3:	xor    %edx,%edx
  81ffe5:	call   *0x65fbfd(%rip)        # e7fbe8 <_DYNAMIC+0x5d0>
  81ffeb:	mov    0x8(%rbp),%rcx
  81ffef:	mov    0x10(%rbp),%r8
  81fff3:	shl    $0x4,%r8
  81fff7:	mov    0x2b0(%rsp),%rdi
  81ffff:	mov    %r12,%rsi
  820002:	mov    %r13,%rdx
  820005:	call   81cc10 <<gpui_gpu::renderer::Buffer>::write>
  82000a:	lea    0x268(%rbp),%rdi
  820011:	mov    0x20(%rbp),%rcx
  820015:	mov    0x28(%rbp),%r8
  820019:	shl    $0x3,%r8
  82001d:	mov    %rdi,0x38(%rsp)
  820022:	mov    %r12,%rsi
  820025:	mov    %r13,%rdx
  820028:	call   81cc10 <<gpui_gpu::renderer::Buffer>::write>
  82002d:	lea    0x290(%rbp),%rdi
  820034:	mov    0x38(%rbp),%rcx
  820038:	mov    0x40(%rbp),%r8
  82003c:	shl    $0x2,%r8
  820040:	mov    %rdi,0x218(%rsp)
  820048:	mov    %r12,%rsi
  82004b:	mov    %r13,%rdx
  82004e:	call   81cc10 <<gpui_gpu::renderer::Buffer>::write>
  820053:	lea    0x2b8(%rbp),%rdi
  82005a:	mov    0x50(%rbp),%rcx
  82005e:	mov    0x58(%rbp),%r8
  820062:	shl    $0x5,%r8
  820066:	mov    %rdi,0xe8(%rsp)
  82006e:	mov    %r12,%rsi
  820071:	mov    %r13,%rdx
  820074:	call   81cc10 <<gpui_gpu::renderer::Buffer>::write>
  820079:	cmpq   $0x0,0x310(%rbp)
  820081:	jne    82009d <<gpui_gpu::renderer::RendererState>::render+0x1fed>
  820083:	mov    0x8(%rsp),%rax
  820088:	mov    0x10(%rax),%rax
  82008c:	cmp    $0x1,%rax
  820090:	adc    $0x0,%rax
  820094:	shl    $0x4,%rax
  820098:	mov    %rax,0x10(%rsp)
  82009d:	mov    0x8(%rsp),%rsi
  8200a2:	mov    0x28(%rsi),%rdx
  8200a6:	mov    0x40(%rsi),%rax
  8200aa:	cmp    $0x1,%rdx
  8200ae:	adc    $0x0,%rdx
  8200b2:	shl    $0x3,%rdx
  8200b6:	cmp    $0x1,%rax
  8200ba:	adc    $0x0,%rax
  8200be:	mov    0x58(%rsi),%rcx
  8200c2:	cmp    $0x1,%rcx
  8200c6:	adc    $0x0,%rcx
  8200ca:	add    $0xb0,%rsi
  8200d1:	shl    $0x2,%rax
  8200d5:	shl    $0x5,%rcx
  8200d9:	movq   $0x0,0x110(%rsp)
  8200e5:	mov    0x58(%rsp),%rdi
  8200ea:	mov    %rdi,0x118(%rsp)
  8200f2:	movq   $0x0,0x138(%rsp)
  8200fe:	xorps  %xmm0,%xmm0
  820101:	movups %xmm0,0x120(%rsp)
  820109:	movl   $0x0,0x130(%rsp)
  820114:	mov    0x2b0(%rsp),%rdi
  82011c:	mov    %rdi,0x140(%rsp)
  820124:	movq   $0x0,0x148(%rsp)
  820130:	mov    0x10(%rsp),%rdi
  820135:	mov    %rdi,0x150(%rsp)
  82013d:	movl   $0x1,0x158(%rsp)
  820148:	movq   $0x0,0x160(%rsp)
  820154:	mov    0x38(%rsp),%rdi
  820159:	mov    %rdi,0x168(%rsp)
  820161:	movq   $0x0,0x170(%rsp)
  82016d:	mov    %rdx,0x178(%rsp)
  820175:	movl   $0x2,0x180(%rsp)
  820180:	movq   $0x0,0x188(%rsp)
  82018c:	mov    0x218(%rsp),%rdx
  820194:	mov    %rdx,0x190(%rsp)
  82019c:	movq   $0x0,0x198(%rsp)
  8201a8:	mov    %rax,0x1a0(%rsp)
  8201b0:	movl   $0x3,0x1a8(%rsp)
  8201bb:	movq   $0x4,0x1b0(%rsp)
  8201c7:	mov    %rsi,0x1b8(%rsp)
  8201cf:	movl   $0x4,0x1d0(%rsp)
  8201da:	movq   $0x0,0x1d8(%rsp)
  8201e6:	mov    0xe8(%rsp),%rax
  8201ee:	mov    %rax,0x1e0(%rsp)
  8201f6:	movq   $0x0,0x1e8(%rsp)
  820202:	mov    %rcx,0x1f0(%rsp)
  82020a:	movl   $0x5,0x1f8(%rsp)
  820215:	lea    -0x74b339(%rip),%rax        # d4ee3 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x13d>
  82021c:	mov    %rax,0x318(%rsp)
  820224:	movq   $0xa,0x320(%rsp)
  820230:	mov    0x18(%rsp),%rax
  820235:	mov    %rax,0x300(%rsp)
  82023d:	lea    0x110(%rsp),%rax
  820245:	mov    %rax,0x308(%rsp)
  82024d:	movq   $0x6,0x310(%rsp)
  820259:	lea    0x300(%rsp),%rsi
  820261:	mov    0x108(%rsp),%r12
  820269:	mov    %r12,%rdi
  82026c:	call   *0x65f97e(%rip)        # e7fbf0 <_DYNAMIC+0x5d8>
  820272:	mov    %rax,%r13
  820275:	mov    %rax,0x2d0(%rsp)
  82027d:	lea    0x2d0(%rsp),%rdx
  820285:	mov    %r12,%rdi
  820288:	mov    0x3e8(%rsp),%rsi
  820290:	call   81d270 <<gpui_gpu::renderer::GpuContext>::submit>
  820295:	mov    %rax,0x10(%rsp)
  82029a:	xor    %ebp,%ebp
  82029c:	mov    0x378(%rsp),%rax
  8202a4:	cmp    0x380(%rsp),%rax
  8202ac:	setne  %bpl
  8202b0:	shl    $0x1f,%ebp
  8202b3:	or     %r14d,%ebp
  8202b6:	shl    $0x20,%r15
  8202ba:	or     %r15,%rbp
  8202bd:	mov    (%rbx),%rax
  8202c0:	test   %rax,%rax
  8202c3:	je     8202d4 <<gpui_gpu::renderer::RendererState>::render+0x2224>
  8202c5:	lock decq (%rax)
  8202c9:	jne    8202d4 <<gpui_gpu::renderer::RendererState>::render+0x2224>
  8202cb:	mov    %rbx,%rdi
  8202ce:	call   *0x65f85c(%rip)        # e7fb30 <_DYNAMIC+0x518>
  8202d4:	mov    0x8(%rsp),%rax
  8202d9:	mov    %r13,0x318(%rax)
  8202e0:	mov    %rbp,0x320(%rax)
  8202e7:	mov    0x10(%rax),%r9
  8202eb:	mov    0x28(%rax),%rsi
  8202ef:	mov    0x58(%rax),%rcx
  8202f3:	mov    %rcx,0x18(%rsp)
  8202f8:	shl    $0x4,%r9
  8202fc:	mov    0xd0(%rsp),%rdx
  820304:	lea    (%r9,%rdx,4),%rdi
  820308:	lea    (%rdi,%rsi,8),%rsi
  82030c:	mov    %rcx,%rdi
  82030f:	shl    $0x5,%rdi
  820313:	lea    (%rdi,%rsi,1),%rcx
  820317:	add    $0x30,%rcx
  82031b:	mov    %rcx,0x58(%rsp)
  820320:	mov    0x138(%rax),%esi
  820326:	imul   %rsi,%rsi
  82032a:	mov    0x260(%rax),%r8
  820331:	add    0x238(%rax),%r8
  820338:	add    0x288(%rax),%r8
  82033f:	add    0x2b0(%rax),%r8
  820346:	add    0x2d8(%rax),%r8
  82034d:	mov    0x2f0(%rax),%rdi
  820354:	add    0x2f8(%rax),%rdi
  82035b:	mov    0xe0(%rsp),%r11
  820363:	mov    %r11,%rcx
  820366:	sub    %rdx,%rcx
  820369:	mov    0xb8(%rsp),%r10
  820371:	mov    %r10,%r12
  820374:	mov    0x208(%rsp),%rbp
  82037c:	sub    %rbp,%r12
  82037f:	mov    0x148(%rax),%rbx
  820386:	inc    %rbx
  820389:	mov    $0xffffffffffffffff,%r14
  820390:	cmovne %rbx,%r14
  820394:	mov    (%rax),%rbx
  820397:	shl    $0x4,%rbx
  82039b:	mov    0x18(%rax),%r15
  82039f:	lea    (%rbx,%r15,8),%rbx
  8203a3:	mov    0x30(%rax),%r15
  8203a7:	lea    (%rbx,%r15,4),%rbx
  8203ab:	mov    0x48(%rax),%r15
  8203af:	shl    $0x5,%r15
  8203b3:	add    %rbx,%r15
  8203b6:	mov    0x120(%rax),%rbx
  8203bd:	mov    0x118(%rax),%r13
  8203c4:	mov    %r14,0x148(%rax)
  8203cb:	mov    %r10,0x150(%rax)
  8203d2:	lea    (%r11,%r11,1),%r14
  8203d6:	mov    %r14,0x158(%rax)
  8203dd:	movq   $0x1,0x160(%rax)
  8203e8:	mov    %r10,0x168(%rax)
  8203ef:	mov    %rdx,0x170(%rax)
  8203f6:	mov    %r11,0x178(%rax)
  8203fd:	mov    %rcx,0x180(%rax)
  820404:	mov    0x60(%rsp),%rcx
  820409:	mov    %rcx,0x188(%rax)
  820410:	mov    0x50(%rsp),%rcx
  820415:	mov    %rcx,0x190(%rax)
  82041c:	mov    0x80(%rsp),%rcx
  820424:	mov    %rcx,0x198(%rax)
  82042b:	mov    0x58(%rsp),%rcx
  820430:	mov    %rcx,0x1a0(%rax)
  820437:	mov    %r9,0x1a8(%rax)
  82043e:	mov    0x200(%rsp),%rdx
  820446:	mov    %rdx,0x1b0(%rax)
  82044d:	mov    %rbp,0x1b8(%rax)
  820454:	mov    %r12,0x1c0(%rax)
  82045b:	mov    0x3b0(%rsp),%rcx
  820463:	mov    %rcx,0x1c8(%rax)
  82046a:	mov    %r8,0x1d0(%rax)
  820471:	mov    %rsi,0x1d8(%rax)
  820478:	add    %rbx,%r13
  82047b:	mov    %rbx,0x1e0(%rax)
  820482:	mov    %r13,0x1e8(%rax)
  820489:	mov    %r15,0x1f0(%rax)
  820490:	mov    0x18(%rsp),%rcx
  820495:	mov    %rcx,0x1f8(%rax)
  82049c:	mov    %rdi,0x200(%rax)
  8204a3:	movb   $0x0,0x208(%rax)
  8204aa:	mov    0x30(%rsp),%rdi
  8204af:	mov    0x10(%rsp),%rax
  8204b4:	mov    %rax,0x8(%rdi)
  8204b8:	movl   $0xffffffff,(%rdi)
  8204be:	jmp    81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x111>
  8204c3:	mov    0x30(%rsp),%rdi
  8204c8:	jmp    81e1b3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  8204cd:	lea    0x60dc5c(%rip),%rdi        # e2e130 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x38>
  8204d4:	call   *0x65f71e(%rip)        # e7fbf8 <_DYNAMIC+0x5e0>
  8204da:	lea    -0x74b619(%rip),%rdi        # d4ec8 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x122>
  8204e1:	lea    0x60dc30(%rip),%rdx        # e2e118 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x20>
  8204e8:	mov    $0x37,%esi
  8204ed:	call   *0x65f43d(%rip)        # e7f930 <_DYNAMIC+0x318>
  8204f3:	lea    0x60dc4e(%rip),%rdx        # e2e148 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x50>
  8204fa:	call   *0x65f610(%rip)        # e7fb10 <_DYNAMIC+0x4f8>
  820500:	mov    %rax,%r14
  820503:	mov    0x8(%rsp),%rax
  820508:	mov    %r13,0x318(%rax)
  82050f:	mov    %rbp,0x320(%rax)
  820516:	mov    %r14,%rdi
  820519:	call   e2c400 <_Unwind_Resume@plt>
  82051e:	mov    %rax,%r14
  820521:	lock decq 0x0(%r13)
  820526:	jne    820548 <<gpui_gpu::renderer::RendererState>::render+0x2498>
  820528:	lea    0x2d0(%rsp),%rdi
  820530:	call   *0x65f5fa(%rip)        # e7fb30 <_DYNAMIC+0x518>
  820536:	jmp    820548 <<gpui_gpu::renderer::RendererState>::render+0x2498>
  820538:	call   *0x65f32a(%rip)        # e7f868 <_DYNAMIC+0x250>
  82053e:	mov    %rax,%r14
  820541:	movq   $0x0,(%rbx)
  820548:	mov    %r14,%rdi
  82054b:	call   e2c400 <_Unwind_Resume@plt>

FUNCTION <gpui_gpu::renderer::RendererState>::bin_draw bytes=4056 frame=792

/tmp/gpui-descending-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000820550 <<gpui_gpu::renderer::RendererState>::bin_draw>:
  820550:	push   %rbp
  820551:	push   %r15
  820553:	push   %r14
  820555:	push   %r13
  820557:	push   %r12
  820559:	push   %rbx
  82055a:	sub    $0x2e8,%rsp
  820561:	movss  0x88(%rdx),%xmm3
  820569:	movss  -0x7715b5(%rip),%xmm0        # aefbc <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  820571:	movaps %xmm3,%xmm1
  820574:	subss  %xmm0,%xmm1
  820578:	cvttss2si %xmm1,%rax
  82057d:	cvttss2si %xmm3,%r10
  820582:	mov    %r10,%r13
  820585:	sar    $0x3f,%r13
  820589:	and    %rax,%r13
  82058c:	or     %r10,%r13
  82058f:	xor    %eax,%eax
  820591:	xorps  %xmm1,%xmm1
  820594:	ucomiss %xmm1,%xmm3
  820597:	cmovb  %rax,%r13
  82059b:	movss  0x90(%rdx),%xmm4
  8205a3:	movss  -0x7715eb(%rip),%xmm2        # aefc0 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  8205ab:	ucomiss %xmm2,%xmm3
  8205ae:	mov    $0xffffffffffffffff,%r14
  8205b5:	cmova  %r14,%r13
  8205b9:	movaps %xmm4,%xmm3
  8205bc:	subss  %xmm0,%xmm3
  8205c0:	cvttss2si %xmm3,%r10
  8205c5:	cvttss2si %xmm4,%r11
  8205ca:	mov    %r11,%rbx
  8205cd:	sar    $0x3f,%rbx
  8205d1:	and    %r10,%rbx
  8205d4:	or     %r11,%rbx
  8205d7:	ucomiss %xmm1,%xmm4
  8205da:	cmovb  %rax,%rbx
  8205de:	ucomiss %xmm2,%xmm4
  8205e1:	cmova  %r14,%rbx
  8205e5:	movss  0x8c(%rdx),%xmm3
  8205ed:	lea    (%rbx,%r13,1),%r11
  8205f1:	dec    %r11
  8205f4:	shr    $0x4,%r11
  8205f8:	shr    $0x4,%r13
  8205fc:	mov    %r11,%rbp
  8205ff:	sub    %r13,%rbp
  820602:	inc    %rbp
  820605:	movaps %xmm3,%xmm4
  820608:	subss  %xmm0,%xmm4
  82060c:	cvttss2si %xmm4,%r10
  820611:	cvttss2si %xmm3,%r15
  820616:	mov    %r15,%rbx
  820619:	sar    $0x3f,%rbx
  82061d:	and    %r10,%rbx
  820620:	or     %r15,%rbx
  820623:	ucomiss %xmm1,%xmm3
  820626:	cmovb  %rax,%rbx
  82062a:	ucomiss %xmm2,%xmm3
  82062d:	movss  0x94(%rdx),%xmm3
  820635:	cmova  %r14,%rbx
  820639:	movaps %xmm3,%xmm4
  82063c:	subss  %xmm0,%xmm4
  820640:	cvttss2si %xmm4,%r10
  820645:	cvttss2si %xmm3,%r15
  82064a:	mov    %r15,%r12
  82064d:	sar    $0x3f,%r12
  820651:	and    %r10,%r12
  820654:	or     %r15,%r12
  820657:	ucomiss %xmm1,%xmm3
  82065a:	cmovb  %rax,%r12
  82065e:	ucomiss %xmm2,%xmm3
  820661:	cmova  %r14,%r12
  820665:	lea    (%rbx,%r12,1),%r10
  820669:	dec    %r10
  82066c:	shr    $0x4,%r10
  820670:	shr    $0x4,%rbx
  820674:	mov    %r10,%r14
  820677:	sub    %rbx,%r14
  82067a:	inc    %r14
  82067d:	imul   %rbp,%r14
  820681:	add    0x330(%rsp),%r14
  820689:	setb   %al
  82068c:	cmp    $0x400001,%r14
  820693:	setae  %bpl
  820697:	or     %al,%bpl
  82069a:	mov    $0x6,%eax
  82069f:	jne    8206df <<gpui_gpu::renderer::RendererState>::bin_draw+0x18f>
  8206a1:	mov    %r8d,0xac(%rsp)
  8206a9:	mov    %r14,0x170(%rsp)
  8206b1:	mov    %rdi,0x178(%rsp)
  8206b9:	mov    %r13,0xa0(%rsp)
  8206c1:	cmp    %rbx,%r10
  8206c4:	jae    8206f3 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1a3>
  8206c6:	mov    0x178(%rsp),%rdi
  8206ce:	mov    0x170(%rsp),%rax
  8206d6:	mov    %rax,0x8(%rdi)
  8206da:	mov    $0xffffffff,%eax
  8206df:	mov    %eax,(%rdi)
  8206e1:	add    $0x2e8,%rsp
  8206e8:	pop    %rbx
  8206e9:	pop    %r12
  8206eb:	pop    %r13
  8206ed:	pop    %r14
  8206ef:	pop    %r15
  8206f1:	pop    %rbp
  8206f2:	ret
  8206f3:	cmp    0xa0(%rsp),%r11
  8206fb:	jae    820716 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1c6>
  8206fd:	nopl   (%rax)
  820700:	mov    %rbx,%rax
  820703:	cmp    %r10,%rbx
  820706:	adc    $0x0,%rbx
  82070a:	cmp    %r10,%rax
  82070d:	jae    8206c6 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  82070f:	cmp    %r10,%rbx
  820712:	jbe    820700 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1b0>
  820714:	jmp    8206c6 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  820716:	movd   0xa4(%rdx),%xmm0
  82071e:	mov    0x20(%rsi),%r12
  820722:	movdqu 0x98(%rdx),%xmm1
  82072a:	movd   0xa0(%rdx),%xmm2
  820732:	punpckldq %xmm0,%xmm2
  820736:	punpcklqdq %xmm2,%xmm1
  82073a:	movdqa -0x773e32(%rip),%xmm2        # ac910 <anon.fd4379edd0b71335c3c29b3337cd5ea0.320.llvm.353578272256937679+0x110>
  820742:	pand   %xmm1,%xmm2
  820746:	paddd  -0x773bde(%rip),%xmm2        # acb70 <anon.fd4379edd0b71335c3c29b3337cd5ea0.320.llvm.353578272256937679+0x370>
  82074e:	pxor   -0x772426(%rip),%xmm2        # ae330 <anon.630a3fff68f6bca64b568be97512ab45.101.llvm.826976926275214120+0x80>
  820756:	pcmpgtd -0x772fce(%rip),%xmm2        # ad790 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x420>
  82075e:	mov    %rsi,%rax
  820761:	mov    0x28(%rsi),%rsi
  820765:	pandn  %xmm1,%xmm2
  820769:	movmskps %xmm2,%edi
  82076c:	test   %edi,%edi
  82076e:	jne    821494 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf44>
  820774:	ucomiss -0x7719fb(%rip),%xmm0        # aed80 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  82077b:	jne    821494 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf44>
  820781:	jp     821494 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf44>
  820787:	cmpb   $0x0,0x328(%rax)
  82078e:	je     821494 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf44>
  820794:	cmpb   $0x0,(%rdx)
  820797:	jne    821494 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf44>
  82079d:	test   %r9,%r9
  8207a0:	je     82150b <<gpui_gpu::renderer::RendererState>::bin_draw+0xfbb>
  8207a6:	mov    0x328(%rsp),%ebp
  8207ad:	mov    0x320(%rsp),%r13d
  8207b5:	movd   %ecx,%xmm2
  8207b9:	shr    $0x20,%rcx
  8207bd:	movss  0x78(%rdx),%xmm0
  8207c2:	movss  0x80(%rdx),%xmm3
  8207ca:	movss  0x84(%rdx),%xmm4
  8207d2:	cvtss2sd %xmm0,%xmm0
  8207d6:	movss  0x7c(%rdx),%xmm1
  8207db:	cvtss2sd %xmm1,%xmm1
  8207df:	cvtss2sd %xmm3,%xmm14
  8207e4:	addsd  %xmm0,%xmm14
  8207e9:	xorps  %xmm3,%xmm3
  8207ec:	cvtss2sd %xmm4,%xmm3
  8207f0:	addsd  %xmm1,%xmm3
  8207f4:	movsd  %xmm3,0x1a8(%rsp)
  8207fd:	movsd  0x48(%rdx),%xmm6
  820802:	movsd  0x58(%rdx),%xmm7
  820807:	movsd  0x68(%rdx),%xmm8
  82080d:	movss  0x38(%rdx),%xmm3
  820812:	movss  0x3c(%rdx),%xmm4
  820817:	movss  0x40(%rdx),%xmm5
  82081c:	cvtss2sd %xmm3,%xmm3
  820820:	cvtss2sd %xmm5,%xmm5
  820824:	movaps -0x775a7c(%rip),%xmm9        # aadb0 <GCC_except_table0+0xb8>
  82082c:	movaps %xmm3,0x80(%rsp)
  820834:	andps  %xmm9,%xmm3
  820838:	movaps %xmm3,0x70(%rsp)
  82083d:	movaps %xmm5,0x50(%rsp)
  820842:	cvtss2sd %xmm2,%xmm2
  820846:	movsd  %xmm2,0x8(%rsp)
  82084c:	andps  %xmm9,%xmm5
  820850:	movaps %xmm5,0x60(%rsp)
  820855:	movaps %xmm6,%xmm2
  820858:	andps  %xmm9,%xmm2
  82085c:	movaps %xmm2,0x250(%rsp)
  820864:	movaps %xmm7,%xmm2
  820867:	andps  %xmm9,%xmm2
  82086b:	movaps %xmm2,0x230(%rsp)
  820873:	xorps  %xmm3,%xmm3
  820876:	cvtss2sd %xmm4,%xmm3
  82087a:	movaps %xmm8,%xmm2
  82087e:	andps  %xmm9,%xmm2
  820882:	movaps %xmm2,0xf0(%rsp)
  82088a:	movss  0x44(%rdx),%xmm2
  82088f:	cvtss2sd %xmm2,%xmm2
  820893:	movaps %xmm3,0x40(%rsp)
  820898:	andps  %xmm9,%xmm3
  82089c:	movaps %xmm3,0x30(%rsp)
  8208a1:	movaps %xmm2,0x10(%rsp)
  8208a6:	andps  %xmm9,%xmm2
  8208aa:	movaps %xmm2,0x20(%rsp)
  8208af:	movd   %ecx,%xmm2
  8208b3:	cvtss2sd %xmm2,%xmm2
  8208b7:	movsd  %xmm2,(%rsp)
  8208bc:	movsd  0x50(%rdx),%xmm2
  8208c1:	movaps %xmm2,%xmm3
  8208c4:	andps  %xmm9,%xmm3
  8208c8:	movaps %xmm3,0x1d0(%rsp)
  8208d0:	movsd  0x60(%rdx),%xmm3
  8208d5:	movaps %xmm3,%xmm4
  8208d8:	andps  %xmm9,%xmm4
  8208dc:	movaps %xmm4,0x1b0(%rsp)
  8208e4:	movsd  0x70(%rdx),%xmm4
  8208e9:	movaps %xmm4,%xmm5
  8208ec:	andps  %xmm9,%xmm5
  8208f0:	movaps %xmm5,0xb0(%rsp)
  8208f8:	movaps %xmm2,0x1e0(%rsp)
  820900:	cvtsd2ss %xmm2,%xmm2
  820904:	xorps  %xmm5,%xmm5
  820907:	cvtss2sd %xmm2,%xmm5
  82090b:	movaps %xmm6,0x260(%rsp)
  820913:	movaps %xmm6,%xmm2
  820916:	movaps %xmm7,0x240(%rsp)
  82091e:	movlhps %xmm7,%xmm2
  820921:	cvtpd2ps %xmm2,%xmm2
  820925:	cvtps2pd %xmm2,%xmm6
  820928:	movaps %xmm3,0x1c0(%rsp)
  820930:	xorps  %xmm2,%xmm2
  820933:	cvtsd2ss %xmm3,%xmm2
  820937:	xorps  %xmm3,%xmm3
  82093a:	cvtss2sd %xmm2,%xmm3
  82093e:	movaps %xmm8,0x100(%rsp)
  820947:	xorps  %xmm2,%xmm2
  82094a:	cvtsd2ss %xmm8,%xmm2
  82094f:	xorps  %xmm7,%xmm7
  820952:	cvtss2sd %xmm2,%xmm7
  820956:	movaps %xmm4,0xc0(%rsp)
  82095e:	xorps  %xmm2,%xmm2
  820961:	cvtsd2ss %xmm4,%xmm2
  820965:	cvtss2sd %xmm2,%xmm2
  820969:	movaps %xmm6,%xmm4
  82096c:	andps  %xmm9,%xmm4
  820970:	movaps %xmm7,0x120(%rsp)
  820978:	andps  %xmm9,%xmm7
  82097c:	movaps %xmm7,0x110(%rsp)
  820984:	movaps %xmm5,0x220(%rsp)
  82098c:	andps  %xmm9,%xmm5
  820990:	movaps %xmm5,0x210(%rsp)
  820998:	movaps %xmm3,0x200(%rsp)
  8209a0:	andps  %xmm9,%xmm3
  8209a4:	movaps %xmm3,0x1f0(%rsp)
  8209ac:	movaps %xmm2,0xd0(%rsp)
  8209b4:	andps  %xmm2,%xmm9
  8209b8:	movaps %xmm9,0xe0(%rsp)
  8209c1:	movaps %xmm6,0x280(%rsp)
  8209c9:	movhlps %xmm6,%xmm6
  8209cc:	movaps %xmm6,0x2b0(%rsp)
  8209d4:	movaps %xmm4,0x270(%rsp)
  8209dc:	movhlps %xmm4,%xmm4
  8209df:	movaps %xmm4,0x2a0(%rsp)
  8209e7:	mov    %r10,0x198(%rsp)
  8209ef:	movsd  %xmm14,0x98(%rsp)
  8209f9:	nopl   0x0(%rax)
  820a00:	mov    %rbx,%r15
  820a03:	cmp    %r10,%rbx
  820a06:	adc    $0x0,%rbx
  820a0a:	mov    %r15,0x1a0(%rsp)
  820a12:	imul   %r9,%r15
  820a16:	mov    0xa0(%rsp),%rdi
  820a1e:	mov    %rdi,%r8
  820a21:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  820a30:	cmp    %r11,%rdi
  820a33:	adc    $0x0,%r8
  820a37:	lea    (%rdi,%r15,1),%rcx
  820a3b:	mov    %rcx,%rax
  820a3e:	shr    $0x20,%rax
  820a42:	je     820a50 <<gpui_gpu::renderer::RendererState>::bin_draw+0x500>
  820a44:	mov    %rcx,%rax
  820a47:	xor    %edx,%edx
  820a49:	div    %r9
  820a4c:	jmp    820a57 <<gpui_gpu::renderer::RendererState>::bin_draw+0x507>
  820a4e:	xchg   %ax,%ax
  820a50:	mov    %ecx,%eax
  820a52:	xor    %edx,%edx
  820a54:	div    %r9d
  820a57:	shl    $0x4,%edx
  820a5a:	shl    $0x4,%eax
  820a5d:	lea    0x10(%rdx),%r10d
  820a61:	cmp    %r10d,%r13d
  820a64:	cmovb  %r13d,%r10d
  820a68:	lea    0x10(%rax),%r14d
  820a6c:	cmp    %r14d,%ebp
  820a6f:	cmovb  %ebp,%r14d
  820a73:	xorps  %xmm12,%xmm12
  820a77:	cvtsi2sd %edx,%xmm12
  820a7c:	ucomisd %xmm12,%xmm0
  820a81:	ja     820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820a83:	mov    %eax,%eax
  820a85:	xorps  %xmm2,%xmm2
  820a88:	cvtsi2sd %rax,%xmm2
  820a8d:	ucomisd %xmm2,%xmm1
  820a91:	ja     820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820a93:	xorps  %xmm6,%xmm6
  820a96:	cvtsi2sd %r10d,%xmm6
  820a9b:	ucomisd %xmm14,%xmm6
  820aa0:	ja     820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820aa2:	xorps  %xmm13,%xmm13
  820aa6:	cvtsi2sd %r14d,%xmm13
  820aab:	ucomisd 0x1a8(%rsp),%xmm13
  820ab5:	jbe    820ae8 <<gpui_gpu::renderer::RendererState>::bin_draw+0x598>
  820ab7:	nopw   0x0(%rax,%rax,1)
  820ac0:	cmp    %rsi,%rcx
  820ac3:	jae    8214fb <<gpui_gpu::renderer::RendererState>::bin_draw+0xfab>
  820ac9:	incl   0x4(%r12,%rcx,8)
  820ace:	cmp    %r11,%rdi
  820ad1:	jae    821470 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf20>
  820ad7:	mov    %r8,%rdi
  820ada:	cmp    %r11,%r8
  820add:	jbe    820a30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x4e0>
  820ae3:	jmp    821470 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf20>
  820ae8:	unpcklpd %xmm2,%xmm12
  820aed:	addpd  -0x773a26(%rip),%xmm12        # ad0d0 <anon.a16d5d421a76dfd8c37a17b53540311d.58.llvm.14190004212411149437+0x270>
  820af6:	movapd %xmm12,%xmm10
  820afb:	mulpd  0x280(%rsp),%xmm10
  820b05:	movapd %xmm10,%xmm15
  820b0a:	unpckhpd %xmm10,%xmm15
  820b0f:	movapd %xmm10,%xmm2
  820b14:	addsd  %xmm15,%xmm2
  820b19:	addsd  0x120(%rsp),%xmm2
  820b22:	subsd  0x80(%rsp),%xmm2
  820b2b:	movapd 0x270(%rsp),%xmm8
  820b35:	mulpd  %xmm12,%xmm8
  820b3a:	movapd %xmm8,%xmm9
  820b3f:	unpckhpd %xmm8,%xmm9
  820b44:	movapd %xmm8,%xmm3
  820b49:	addsd  %xmm9,%xmm3
  820b4e:	addsd  0x110(%rsp),%xmm3
  820b57:	addsd  0x70(%rsp),%xmm3
  820b5d:	addsd  0x60(%rsp),%xmm3
  820b63:	addsd  -0x7712f3(%rip),%xmm3        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820b6b:	mulsd  -0x771373(%rip),%xmm3        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820b73:	addsd  0x8(%rsp),%xmm3
  820b79:	ucomisd %xmm2,%xmm3
  820b7d:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820b83:	movapd 0x50(%rsp),%xmm4
  820b89:	subsd  %xmm2,%xmm4
  820b8d:	ucomisd %xmm4,%xmm3
  820b91:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820b97:	movapd %xmm12,%xmm7
  820b9c:	unpckhpd %xmm12,%xmm7
  820ba1:	movapd 0x240(%rsp),%xmm11
  820bab:	mulsd  %xmm7,%xmm11
  820bb0:	movapd 0x230(%rsp),%xmm3
  820bb9:	mulsd  %xmm7,%xmm3
  820bbd:	movapd 0x260(%rsp),%xmm2
  820bc6:	mulsd  %xmm12,%xmm2
  820bcb:	movapd %xmm2,0x140(%rsp)
  820bd4:	addsd  %xmm11,%xmm2
  820bd9:	addsd  0x100(%rsp),%xmm2
  820be2:	subsd  0x80(%rsp),%xmm2
  820beb:	movapd 0x250(%rsp),%xmm4
  820bf4:	mulsd  %xmm12,%xmm4
  820bf9:	movsd  %xmm4,0x190(%rsp)
  820c02:	addsd  %xmm3,%xmm4
  820c06:	addsd  0xf0(%rsp),%xmm4
  820c0f:	addsd  0x70(%rsp),%xmm4
  820c15:	addsd  0x60(%rsp),%xmm4
  820c1b:	addsd  -0x7713ab(%rip),%xmm4        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820c23:	mulsd  -0x770e53(%rip),%xmm4        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820c2b:	ucomisd %xmm2,%xmm4
  820c2f:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820c35:	movapd 0x50(%rsp),%xmm5
  820c3b:	subsd  %xmm2,%xmm5
  820c3f:	ucomisd %xmm5,%xmm4
  820c43:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820c49:	movapd %xmm7,%xmm4
  820c4d:	mulsd  0x200(%rsp),%xmm4
  820c56:	movapd %xmm7,%xmm2
  820c5a:	mulsd  0x1f0(%rsp),%xmm2
  820c63:	movapd %xmm12,%xmm5
  820c68:	mulsd  0x220(%rsp),%xmm5
  820c71:	movsd  %xmm5,0x188(%rsp)
  820c7a:	movapd %xmm4,0x130(%rsp)
  820c83:	addsd  %xmm4,%xmm5
  820c87:	addsd  0xd0(%rsp),%xmm5
  820c90:	subsd  0x40(%rsp),%xmm5
  820c96:	movapd %xmm12,%xmm4
  820c9b:	mulsd  0x210(%rsp),%xmm4
  820ca4:	movsd  %xmm4,0x180(%rsp)
  820cad:	addsd  %xmm2,%xmm4
  820cb1:	addsd  0xe0(%rsp),%xmm4
  820cba:	addsd  0x30(%rsp),%xmm4
  820cc0:	addsd  0x20(%rsp),%xmm4
  820cc6:	addsd  -0x771456(%rip),%xmm4        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820cce:	mulsd  -0x7714d6(%rip),%xmm4        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820cd6:	addsd  (%rsp),%xmm4
  820cdb:	ucomisd %xmm5,%xmm4
  820cdf:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820ce5:	movapd 0x10(%rsp),%xmm14
  820cec:	subsd  %xmm5,%xmm14
  820cf1:	ucomisd %xmm14,%xmm4
  820cf6:	movsd  0x98(%rsp),%xmm14
  820d00:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820d06:	movapd 0x1c0(%rsp),%xmm4
  820d0f:	mulsd  %xmm7,%xmm4
  820d13:	mulsd  0x1b0(%rsp),%xmm7
  820d1c:	movapd 0x1e0(%rsp),%xmm5
  820d25:	mulsd  %xmm12,%xmm5
  820d2a:	movapd %xmm5,0x2c0(%rsp)
  820d33:	movapd %xmm4,0x2d0(%rsp)
  820d3c:	addsd  %xmm4,%xmm5
  820d40:	addsd  0xc0(%rsp),%xmm5
  820d49:	subsd  0x40(%rsp),%xmm5
  820d4f:	mulsd  0x1d0(%rsp),%xmm12
  820d59:	movapd %xmm12,%xmm4
  820d5e:	addsd  %xmm7,%xmm4
  820d62:	addsd  0xb0(%rsp),%xmm4
  820d6b:	addsd  0x30(%rsp),%xmm4
  820d71:	addsd  0x20(%rsp),%xmm4
  820d77:	addsd  -0x771507(%rip),%xmm4        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820d7f:	mulsd  -0x770faf(%rip),%xmm4        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820d87:	ucomisd %xmm5,%xmm4
  820d8b:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820d91:	movapd 0x10(%rsp),%xmm14
  820d98:	subsd  %xmm5,%xmm14
  820d9d:	ucomisd %xmm14,%xmm4
  820da2:	movsd  0x98(%rsp),%xmm14
  820dac:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820db2:	addsd  -0x771832(%rip),%xmm6        # af588 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  820dba:	movapd %xmm6,%xmm4
  820dbe:	mulsd  0x280(%rsp),%xmm4
  820dc7:	movsd  %xmm4,0x168(%rsp)
  820dd0:	addsd  %xmm4,%xmm15
  820dd5:	addsd  0x120(%rsp),%xmm15
  820ddf:	subsd  0x80(%rsp),%xmm15
  820de9:	movapd 0x270(%rsp),%xmm4
  820df2:	mulsd  %xmm6,%xmm4
  820df6:	movsd  %xmm4,0x160(%rsp)
  820dff:	addsd  %xmm4,%xmm9
  820e04:	addsd  0x110(%rsp),%xmm9
  820e0e:	addsd  0x70(%rsp),%xmm9
  820e15:	addsd  0x60(%rsp),%xmm9
  820e1c:	addsd  -0x7715ad(%rip),%xmm9        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820e25:	mulsd  -0x77162e(%rip),%xmm9        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820e2e:	addsd  0x8(%rsp),%xmm9
  820e35:	ucomisd %xmm15,%xmm9
  820e3a:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820e40:	movapd 0x50(%rsp),%xmm4
  820e46:	subsd  %xmm15,%xmm4
  820e4b:	ucomisd %xmm4,%xmm9
  820e50:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820e56:	movapd 0x260(%rsp),%xmm15
  820e60:	mulsd  %xmm6,%xmm15
  820e65:	addsd  %xmm15,%xmm11
  820e6a:	addsd  0x100(%rsp),%xmm11
  820e74:	subsd  0x80(%rsp),%xmm11
  820e7e:	movapd 0x250(%rsp),%xmm4
  820e87:	mulsd  %xmm6,%xmm4
  820e8b:	movsd  %xmm4,0x158(%rsp)
  820e94:	addsd  %xmm4,%xmm3
  820e98:	addsd  0xf0(%rsp),%xmm3
  820ea1:	addsd  0x70(%rsp),%xmm3
  820ea7:	addsd  0x60(%rsp),%xmm3
  820ead:	addsd  -0x77163d(%rip),%xmm3        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820eb5:	mulsd  -0x7710e5(%rip),%xmm3        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820ebd:	ucomisd %xmm11,%xmm3
  820ec2:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820ec8:	movapd 0x50(%rsp),%xmm4
  820ece:	subsd  %xmm11,%xmm4
  820ed3:	ucomisd %xmm4,%xmm3
  820ed7:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820edd:	movapd %xmm6,%xmm3
  820ee1:	mulsd  0x220(%rsp),%xmm3
  820eea:	movsd  %xmm3,0x150(%rsp)
  820ef3:	movapd 0x130(%rsp),%xmm5
  820efc:	addsd  %xmm3,%xmm5
  820f00:	addsd  0xd0(%rsp),%xmm5
  820f09:	subsd  0x40(%rsp),%xmm5
  820f0f:	movapd %xmm6,%xmm3
  820f13:	mulsd  0x210(%rsp),%xmm3
  820f1c:	movsd  %xmm3,0x130(%rsp)
  820f25:	addsd  %xmm3,%xmm2
  820f29:	addsd  0xe0(%rsp),%xmm2
  820f32:	addsd  0x30(%rsp),%xmm2
  820f38:	addsd  0x20(%rsp),%xmm2
  820f3e:	addsd  -0x7716ce(%rip),%xmm2        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820f46:	mulsd  -0x77174e(%rip),%xmm2        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820f4e:	addsd  (%rsp),%xmm2
  820f53:	ucomisd %xmm5,%xmm2
  820f57:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820f5d:	movapd 0x10(%rsp),%xmm3
  820f63:	subsd  %xmm5,%xmm3
  820f67:	ucomisd %xmm3,%xmm2
  820f6b:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820f71:	movapd 0x1e0(%rsp),%xmm2
  820f7a:	mulsd  %xmm6,%xmm2
  820f7e:	movapd %xmm2,0x290(%rsp)
  820f87:	movapd 0x2d0(%rsp),%xmm4
  820f90:	addsd  %xmm2,%xmm4
  820f94:	addsd  0xc0(%rsp),%xmm4
  820f9d:	subsd  0x40(%rsp),%xmm4
  820fa3:	mulsd  0x1d0(%rsp),%xmm6
  820fac:	addsd  %xmm6,%xmm7
  820fb0:	addsd  0xb0(%rsp),%xmm7
  820fb9:	addsd  0x30(%rsp),%xmm7
  820fbf:	addsd  0x20(%rsp),%xmm7
  820fc5:	addsd  -0x771755(%rip),%xmm7        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820fcd:	mulsd  -0x7711fd(%rip),%xmm7        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820fd5:	ucomisd %xmm4,%xmm7
  820fd9:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820fdf:	movapd 0x10(%rsp),%xmm2
  820fe5:	subsd  %xmm4,%xmm2
  820fe9:	ucomisd %xmm2,%xmm7
  820fed:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820ff3:	addsd  -0x771a74(%rip),%xmm13        # af588 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  820ffc:	movapd %xmm13,%xmm3
  821001:	mulsd  0x2b0(%rsp),%xmm3
  82100a:	movapd %xmm13,%xmm2
  82100f:	mulsd  0x2a0(%rsp),%xmm2
  821018:	addsd  %xmm3,%xmm10
  82101d:	addsd  0x120(%rsp),%xmm10
  821027:	subsd  0x80(%rsp),%xmm10
  821031:	addsd  %xmm2,%xmm8
  821036:	addsd  0x110(%rsp),%xmm8
  821040:	addsd  0x70(%rsp),%xmm8
  821047:	addsd  0x60(%rsp),%xmm8
  82104e:	addsd  -0x7717df(%rip),%xmm8        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821057:	mulsd  -0x771860(%rip),%xmm8        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  821060:	addsd  0x8(%rsp),%xmm8
  821067:	ucomisd %xmm10,%xmm8
  82106c:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821072:	movapd 0x50(%rsp),%xmm4
  821078:	subsd  %xmm10,%xmm4
  82107d:	ucomisd %xmm4,%xmm8
  821082:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821088:	movapd 0x240(%rsp),%xmm7
  821091:	mulsd  %xmm13,%xmm7
  821096:	movapd 0x230(%rsp),%xmm5
  82109f:	mulsd  %xmm13,%xmm5
  8210a4:	movapd 0x140(%rsp),%xmm4
  8210ad:	addsd  %xmm7,%xmm4
  8210b1:	addsd  0x100(%rsp),%xmm4
  8210ba:	subsd  0x80(%rsp),%xmm4
  8210c3:	movsd  0x190(%rsp),%xmm10
  8210cd:	addsd  %xmm5,%xmm10
  8210d2:	addsd  0xf0(%rsp),%xmm10
  8210dc:	addsd  0x70(%rsp),%xmm10
  8210e3:	addsd  0x60(%rsp),%xmm10
  8210ea:	addsd  -0x77187b(%rip),%xmm10        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8210f3:	mulsd  -0x771324(%rip),%xmm10        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  8210fc:	ucomisd %xmm4,%xmm10
  821101:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821107:	movapd %xmm4,%xmm8
  82110c:	movapd 0x50(%rsp),%xmm4
  821112:	subsd  %xmm8,%xmm4
  821117:	ucomisd %xmm4,%xmm10
  82111c:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821122:	movapd %xmm13,%xmm8
  821127:	mulsd  0x200(%rsp),%xmm8
  821131:	movapd %xmm13,%xmm10
  821136:	mulsd  0x1f0(%rsp),%xmm10
  821140:	movsd  0x188(%rsp),%xmm9
  82114a:	addsd  %xmm8,%xmm9
  82114f:	addsd  0xd0(%rsp),%xmm9
  821159:	subsd  0x40(%rsp),%xmm9
  821160:	movapd %xmm15,%xmm4
  821165:	movsd  0x180(%rsp),%xmm15
  82116f:	movsd  %xmm10,0x140(%rsp)
  821179:	addsd  %xmm10,%xmm15
  82117e:	addsd  0xe0(%rsp),%xmm15
  821188:	addsd  0x30(%rsp),%xmm15
  82118f:	addsd  0x20(%rsp),%xmm15
  821196:	addsd  -0x771927(%rip),%xmm15        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  82119f:	mulsd  -0x7719a8(%rip),%xmm15        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  8211a8:	addsd  (%rsp),%xmm15
  8211ae:	ucomisd %xmm9,%xmm15
  8211b3:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  8211b9:	movapd %xmm9,%xmm10
  8211be:	movapd 0x10(%rsp),%xmm9
  8211c5:	subsd  %xmm10,%xmm9
  8211ca:	ucomisd %xmm9,%xmm15
  8211cf:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  8211d5:	movapd 0x1c0(%rsp),%xmm9
  8211df:	mulsd  %xmm13,%xmm9
  8211e4:	mulsd  0x1b0(%rsp),%xmm13
  8211ee:	movapd 0x2c0(%rsp),%xmm10
  8211f8:	addsd  %xmm9,%xmm10
  8211fd:	addsd  0xc0(%rsp),%xmm10
  821207:	subsd  0x40(%rsp),%xmm10
  82120e:	addsd  %xmm13,%xmm12
  821213:	addsd  0xb0(%rsp),%xmm12
  82121d:	addsd  0x30(%rsp),%xmm12
  821224:	addsd  0x20(%rsp),%xmm12
  82122b:	addsd  -0x7719bc(%rip),%xmm12        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821234:	mulsd  -0x771465(%rip),%xmm12        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  82123d:	ucomisd %xmm10,%xmm12
  821242:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821248:	movapd %xmm10,%xmm11
  82124d:	movapd 0x10(%rsp),%xmm10
  821254:	subsd  %xmm11,%xmm10
  821259:	ucomisd %xmm10,%xmm12
  82125e:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821264:	movsd  0x168(%rsp),%xmm10
  82126e:	addsd  %xmm3,%xmm10
  821273:	addsd  0x120(%rsp),%xmm10
  82127d:	subsd  0x80(%rsp),%xmm10
  821287:	movsd  0x160(%rsp),%xmm11
  821291:	addsd  %xmm2,%xmm11
  821296:	addsd  0x110(%rsp),%xmm11
  8212a0:	addsd  0x70(%rsp),%xmm11
  8212a7:	addsd  0x60(%rsp),%xmm11
  8212ae:	addsd  -0x771a3f(%rip),%xmm11        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8212b7:	mulsd  -0x771ac0(%rip),%xmm11        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  8212c0:	addsd  0x8(%rsp),%xmm11
  8212c7:	ucomisd %xmm10,%xmm11
  8212cc:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  8212d2:	movapd %xmm4,%xmm15
  8212d7:	movapd 0x50(%rsp),%xmm2
  8212dd:	subsd  %xmm10,%xmm2
  8212e2:	ucomisd %xmm2,%xmm11
  8212e7:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  8212ed:	addsd  %xmm7,%xmm15
  8212f2:	addsd  0x100(%rsp),%xmm15
  8212fc:	subsd  0x80(%rsp),%xmm15
  821306:	movsd  0x158(%rsp),%xmm2
  82130f:	addsd  %xmm5,%xmm2
  821313:	addsd  0xf0(%rsp),%xmm2
  82131c:	addsd  0x70(%rsp),%xmm2
  821322:	addsd  0x60(%rsp),%xmm2
  821328:	addsd  -0x771ab8(%rip),%xmm2        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821330:	mulsd  -0x771560(%rip),%xmm2        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  821338:	ucomisd %xmm15,%xmm2
  82133d:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821343:	movapd %xmm2,%xmm3
  821347:	movapd 0x50(%rsp),%xmm2
  82134d:	subsd  %xmm15,%xmm2
  821352:	ucomisd %xmm2,%xmm3
  821356:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  82135c:	movsd  0x150(%rsp),%xmm2
  821365:	addsd  %xmm8,%xmm2
  82136a:	addsd  0xd0(%rsp),%xmm2
  821373:	subsd  0x40(%rsp),%xmm2
  821379:	movsd  0x130(%rsp),%xmm5
  821382:	addsd  0x140(%rsp),%xmm5
  82138b:	addsd  0xe0(%rsp),%xmm5
  821394:	addsd  0x30(%rsp),%xmm5
  82139a:	addsd  0x20(%rsp),%xmm5
  8213a0:	addsd  -0x771b30(%rip),%xmm5        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8213a8:	mulsd  -0x771bb0(%rip),%xmm5        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  8213b0:	addsd  (%rsp),%xmm5
  8213b5:	ucomisd %xmm2,%xmm5
  8213b9:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  8213bf:	movapd %xmm2,%xmm3
  8213c3:	movapd 0x10(%rsp),%xmm2
  8213c9:	subsd  %xmm3,%xmm2
  8213cd:	ucomisd %xmm2,%xmm5
  8213d1:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  8213d7:	movapd 0x290(%rsp),%xmm2
  8213e0:	addsd  %xmm9,%xmm2
  8213e5:	addsd  0xc0(%rsp),%xmm2
  8213ee:	subsd  0x40(%rsp),%xmm2
  8213f4:	addsd  %xmm13,%xmm6
  8213f9:	addsd  0xb0(%rsp),%xmm6
  821402:	addsd  0x30(%rsp),%xmm6
  821408:	addsd  0x20(%rsp),%xmm6
  82140e:	addsd  -0x771b9e(%rip),%xmm6        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821416:	mulsd  -0x771646(%rip),%xmm6        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  82141e:	ucomisd %xmm2,%xmm6
  821422:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821428:	movapd %xmm2,%xmm3
  82142c:	movapd 0x10(%rsp),%xmm2
  821432:	subsd  %xmm3,%xmm2
  821436:	ucomisd %xmm2,%xmm6
  82143a:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821440:	cmp    %rsi,%rcx
  821443:	jae    821518 <<gpui_gpu::renderer::RendererState>::bin_draw+0xfc8>
  821449:	mov    0xac(%rsp),%eax
  821450:	mov    %eax,(%r12,%rcx,8)
  821454:	movl   $0x80000001,0x4(%r12,%rcx,8)
  82145d:	movsd  0x98(%rsp),%xmm14
  821467:	cmp    %r11,%rdi
  82146a:	jb     820ad7 <<gpui_gpu::renderer::RendererState>::bin_draw+0x587>
  821470:	mov    0x198(%rsp),%r10
  821478:	cmp    %r10,0x1a0(%rsp)
  821480:	jae    8206c6 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  821486:	cmp    %r10,%rbx
  821489:	jbe    820a00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x4b0>
  82148f:	jmp    8206c6 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  821494:	mov    %rbx,%rax
  821497:	nopw   0x0(%rax,%rax,1)
  8214a0:	cmp    %r10,%rbx
  8214a3:	adc    $0x0,%rax
  8214a7:	mov    %rbx,%rdx
  8214aa:	imul   %r9,%rdx
  8214ae:	mov    0xa0(%rsp),%rdi
  8214b6:	cs nopw 0x0(%rax,%rax,1)
  8214c0:	lea    (%rdi,%rdx,1),%rcx
  8214c4:	cmp    %rsi,%rcx
  8214c7:	jae    8214fb <<gpui_gpu::renderer::RendererState>::bin_draw+0xfab>
  8214c9:	cmp    %r11,%rdi
  8214cc:	mov    %rdi,%r8
  8214cf:	adc    $0x0,%r8
  8214d3:	incl   0x4(%r12,%rcx,8)
  8214d8:	cmp    %r11,%rdi
  8214db:	jae    8214e5 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf95>
  8214dd:	mov    %r8,%rdi
  8214e0:	cmp    %r11,%r8
  8214e3:	jbe    8214c0 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf70>
  8214e5:	cmp    %r10,%rbx
  8214e8:	jae    8206c6 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  8214ee:	mov    %rax,%rbx
  8214f1:	cmp    %r10,%rax
  8214f4:	jbe    8214a0 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf50>
  8214f6:	jmp    8206c6 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  8214fb:	lea    0x60cca6(%rip),%rdx        # e2e1a8 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xb0>
  821502:	mov    %rcx,%rdi
  821505:	call   *0x65e605(%rip)        # e7fb10 <_DYNAMIC+0x4f8>
  82150b:	lea    0x60cd86(%rip),%rdi        # e2e298 <anon.e7af5e0dba0d7261d22cb76253955a85.28.llvm.5458571228094894073+0x10>
  821512:	call   *0x65e768(%rip)        # e7fc80 <_DYNAMIC+0x668>
  821518:	lea    0x60cca1(%rip),%rdx        # e2e1c0 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xc8>
  82151f:	mov    %rcx,%rdi
  821522:	call   *0x65e5e8(%rip)        # e7fb10 <_DYNAMIC+0x4f8>

FUNCTION gpui_gpu::renderer::compact_group bytes=68 frame=88

/tmp/gpui-descending-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000821530 <gpui_gpu::renderer::compact_group>:
  821530:	xor    %eax,%eax
  821532:	test   %esi,%esi
  821534:	je     821573 <gpui_gpu::renderer::compact_group+0x43>
  821536:	cmpq   $0x2,0x10(%rdi)
  82153b:	jb     821573 <gpui_gpu::renderer::compact_group+0x43>
  82153d:	sub    $0x58,%rsp
  821541:	mov    (%rdi),%rsi
  821544:	mov    0x8(%rdi),%rax
  821548:	mov    (%rax),%edx
  82154a:	mov    %rsp,%rdi
  82154d:	call   81c970 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  821552:	movss  0x4(%rsp),%xmm0
  821558:	cmpb   $0x3,(%rsp)
  82155c:	setne  %cl
  82155f:	xorps  %xmm1,%xmm1
  821562:	ucomiss %xmm1,%xmm0
  821565:	setnp  %dl
  821568:	sete   %al
  82156b:	and    %dl,%al
  82156d:	or     %cl,%al
  82156f:	add    $0x58,%rsp
  821573:	ret

FUNCTION gpui_gpu::renderer::validate_draw bytes=1600 frame=168

/tmp/gpui-descending-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000821580 <gpui_gpu::renderer::validate_draw>:
  821580:	push   %rbp
  821581:	push   %r15
  821583:	push   %r14
  821585:	push   %r12
  821587:	push   %rbx
  821588:	sub    $0x80,%rsp
  82158f:	mov    %r8d,%ebp
  821592:	mov    %ecx,%r12d
  821595:	mov    %rdx,%r14
  821598:	mov    %rsi,%r15
  82159b:	mov    %rdi,%rbx
  82159e:	movups 0x88(%rsi),%xmm0
  8215a5:	movaps %xmm0,0x20(%rsp)
  8215aa:	movaps %xmm0,0x70(%rsp)
  8215af:	lea    0x70(%rsp),%rdi
  8215b4:	call   *0x65e6ce(%rip)        # e7fc88 <_DYNAMIC+0x670>
  8215ba:	movaps 0x20(%rsp),%xmm4
  8215bf:	test   %al,%al
  8215c1:	je     821617 <gpui_gpu::renderer::validate_draw+0x97>
  8215c3:	movaps %xmm4,%xmm0
  8215c6:	unpckhpd %xmm4,%xmm0
  8215ca:	xorps  %xmm2,%xmm2
  8215cd:	ucomiss %xmm2,%xmm0
  8215d0:	jne    8215d4 <gpui_gpu::renderer::validate_draw+0x54>
  8215d2:	jnp    821617 <gpui_gpu::renderer::validate_draw+0x97>
  8215d4:	movaps %xmm4,%xmm1
  8215d7:	shufps $0xff,%xmm4,%xmm1
  8215db:	ucomiss %xmm2,%xmm1
  8215de:	jne    8215e2 <gpui_gpu::renderer::validate_draw+0x62>
  8215e0:	jnp    821617 <gpui_gpu::renderer::validate_draw+0x97>
  8215e2:	xorps  %xmm3,%xmm3
  8215e5:	ucomiss %xmm4,%xmm3
  8215e8:	ja     821617 <gpui_gpu::renderer::validate_draw+0x97>
  8215ea:	movaps %xmm4,%xmm2
  8215ed:	shufps $0x55,%xmm4,%xmm2
  8215f1:	ucomiss %xmm2,%xmm3
  8215f4:	ja     821617 <gpui_gpu::renderer::validate_draw+0x97>
  8215f6:	xorps  %xmm3,%xmm3
  8215f9:	cvtsi2ss %r12d,%xmm3
  8215fe:	addss  %xmm4,%xmm0
  821602:	ucomiss %xmm3,%xmm0
  821605:	ja     821617 <gpui_gpu::renderer::validate_draw+0x97>
  821607:	xorps  %xmm0,%xmm0
  82160a:	cvtsi2ss %ebp,%xmm0
  82160e:	addss  %xmm1,%xmm2
  821612:	ucomiss %xmm0,%xmm2
  821615:	jbe    82162d <gpui_gpu::renderer::validate_draw+0xad>
  821617:	movl   $0x3,(%rbx)
  82161d:	add    $0x80,%rsp
  821624:	pop    %rbx
  821625:	pop    %r12
  821627:	pop    %r14
  821629:	pop    %r15
  82162b:	pop    %rbp
  82162c:	ret
  82162d:	movsd  0x48(%r15),%xmm9
  821633:	movsd  0x60(%r15),%xmm1
  821639:	movupd 0x50(%r15),%xmm2
  82163f:	movapd %xmm2,%xmm5
  821643:	shufpd $0x1,%xmm2,%xmm5
  821648:	movupd 0x68(%r15),%xmm0
  82164e:	cvtpd2ps %xmm5,%xmm8
  821653:	movapd %xmm9,%xmm4
  821658:	unpcklpd %xmm1,%xmm4
  82165c:	cvtpd2ps %xmm4,%xmm7
  821660:	cvtpd2ps %xmm0,%xmm6
  821664:	movapd %xmm6,%xmm3
  821668:	shufps $0x55,%xmm6,%xmm3
  82166c:	movd   %xmm3,%ecx
  821670:	movd   %xmm6,%eax
  821674:	movapd %xmm7,%xmm3
  821678:	shufps $0x14,%xmm8,%xmm3
  82167d:	shufps $0x78,%xmm3,%xmm3
  821681:	andps  -0x773f08(%rip),%xmm3        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  821688:	and    $0x7fffffff,%eax
  82168d:	cmp    $0x7f800000,%eax
  821692:	setge  %al
  821695:	and    $0x7fffffff,%ecx
  82169b:	cmp    $0x7f800000,%ecx
  8216a1:	setge  %cl
  8216a4:	pcmpgtd -0x775ffc(%rip),%xmm3        # ab6b0 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x70>
  8216ac:	movmskps %xmm3,%edx
  8216af:	test   %edx,%edx
  8216b1:	jne    821702 <gpui_gpu::renderer::validate_draw+0x182>
  8216b3:	test   %al,%al
  8216b5:	jne    821702 <gpui_gpu::renderer::validate_draw+0x182>
  8216b7:	test   %cl,%cl
  8216b9:	jne    821702 <gpui_gpu::renderer::validate_draw+0x182>
  8216bb:	movapd %xmm9,%xmm3
  8216c0:	mulsd  %xmm1,%xmm3
  8216c4:	movapd %xmm2,%xmm10
  8216c9:	mulsd  %xmm5,%xmm10
  8216ce:	subsd  %xmm10,%xmm3
  8216d3:	xorpd  %xmm10,%xmm10
  8216d8:	ucomisd %xmm10,%xmm3
  8216dd:	jne    8216e1 <gpui_gpu::renderer::validate_draw+0x161>
  8216df:	jnp    821702 <gpui_gpu::renderer::validate_draw+0x182>
  8216e1:	movq   %xmm3,%rcx
  8216e6:	movabs $0x7fffffffffffffff,%rax
  8216f0:	and    %rax,%rcx
  8216f3:	movabs $0x7ff0000000000000,%rdx
  8216fd:	cmp    %rdx,%rcx
  821700:	jl     821711 <gpui_gpu::renderer::validate_draw+0x191>
  821702:	movl   $0x5,(%rbx)
  821708:	mov    %r14,0x8(%rbx)
  82170c:	jmp    82161d <gpui_gpu::renderer::validate_draw+0x9d>
  821711:	xorps  %xmm10,%xmm10
  821715:	cvtsi2sd %r12d,%xmm10
  82171a:	cvtsi2sd %ebp,%xmm12
  82171f:	movsd  %xmm9,%xmm2
  821724:	movapd -0x77697d(%rip),%xmm13        # aadb0 <GCC_except_table0+0xb8>
  82172d:	andpd  %xmm13,%xmm2
  821732:	movapd %xmm10,%xmm11
  821737:	unpcklpd %xmm12,%xmm11
  82173c:	movapd %xmm2,%xmm9
  821741:	movapd %xmm11,0x50(%rsp)
  821748:	mulpd  %xmm11,%xmm9
  82174d:	movapd %xmm9,%xmm11
  821752:	unpckhpd %xmm9,%xmm11
  821757:	addsd  %xmm9,%xmm11
  82175c:	movapd %xmm0,%xmm9
  821761:	andpd  %xmm13,%xmm9
  821766:	addsd  %xmm11,%xmm9
  82176b:	shufpd $0x2,%xmm5,%xmm1
  821770:	andpd  %xmm13,%xmm1
  821775:	unpcklpd %xmm10,%xmm12
  82177a:	movapd %xmm1,%xmm10
  82177f:	movapd %xmm12,0x40(%rsp)
  821786:	mulpd  %xmm12,%xmm10
  82178b:	movapd %xmm10,%xmm11
  821790:	unpckhpd %xmm10,%xmm11
  821795:	addsd  %xmm9,%xmm11
  82179a:	addsd  %xmm10,%xmm11
  82179f:	movapd %xmm0,%xmm10
  8217a4:	unpckhpd %xmm0,%xmm10
  8217a9:	andpd  %xmm13,%xmm10
  8217ae:	addsd  %xmm11,%xmm10
  8217b3:	movsd  0x38(%r15),%xmm9
  8217b9:	movsd  0x40(%r15),%xmm12
  8217bf:	andps  -0x774047(%rip),%xmm9        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  8217c7:	cvtps2pd %xmm9,%xmm15
  8217cb:	movapd %xmm10,%xmm9
  8217d0:	addsd  %xmm15,%xmm9
  8217d5:	movapd %xmm15,0x60(%rsp)
  8217dc:	unpckhpd %xmm15,%xmm15
  8217e1:	addsd  %xmm15,%xmm9
  8217e6:	cvtps2pd %xmm12,%xmm11
  8217ea:	movapd %xmm11,0x20(%rsp)
  8217f1:	andpd  %xmm13,%xmm11
  8217f6:	addsd  %xmm11,%xmm9
  8217fb:	pshufd $0xee,%xmm11,%xmm14
  821801:	movdqa %xmm14,0x30(%rsp)
  821808:	addsd  %xmm14,%xmm9
  82180d:	movq   %xmm9,%rsi
  821812:	and    %rax,%rsi
  821815:	movabs $0x7fefffffffffffff,%rcx
  82181f:	cmp    %rcx,%rsi
  821822:	jg     821702 <gpui_gpu::renderer::validate_draw+0x182>
  821828:	ucomisd -0x772219(%rip),%xmm9        # af618 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  821831:	ja     821702 <gpui_gpu::renderer::validate_draw+0x182>
  821837:	movzbl (%r15),%esi
  82183b:	cmp    $0x3,%esi
  82183e:	je     821856 <gpui_gpu::renderer::validate_draw+0x2d6>
  821840:	xorpd  %xmm14,%xmm14
  821845:	cmp    $0x1,%esi
  821848:	jne    821982 <gpui_gpu::renderer::validate_draw+0x402>
  82184e:	movss  0x4(%r15),%xmm14
  821854:	jmp    82186d <gpui_gpu::renderer::validate_draw+0x2ed>
  821856:	movss  0x4(%r15),%xmm14
  82185c:	xorpd  %xmm13,%xmm13
  821861:	ucomiss %xmm13,%xmm14
  821865:	jne    82186d <gpui_gpu::renderer::validate_draw+0x2ed>
  821867:	jnp    821aa7 <gpui_gpu::renderer::validate_draw+0x527>
  82186d:	movd   %xmm14,%edi
  821872:	test   %edi,%edi
  821874:	sets   %r8b
  821878:	and    $0x7fffffff,%edi
  82187e:	lea    -0x800000(%rdi),%r9d
  821885:	cmp    $0x7f000000,%r9d
  82188c:	setb   %r9b
  821890:	and    %r8b,%r9b
  821893:	lea    -0x1(%rdi),%r10d
  821897:	cmp    $0x7fffff,%r10d
  82189e:	setb   %r10b
  8218a2:	and    %r8b,%r10b
  8218a5:	cmp    $0x7f800000,%edi
  8218ab:	sete   %dil
  8218af:	setg   %r8b
  8218b3:	or     %dil,%r8b
  8218b6:	or     %r10b,%r8b
  8218b9:	or     %r9b,%r8b
  8218bc:	cmp    $0x1,%r8b
  8218c0:	je     821617 <gpui_gpu::renderer::validate_draw+0x97>
  8218c6:	movaps %xmm11,(%rsp)
  8218cb:	movaps %xmm14,%xmm11
  8218cf:	movaps %xmm14,0x10(%rsp)
  8218d5:	movaps %xmm12,%xmm14
  8218d9:	mulss  -0x772976(%rip),%xmm14        # aef6c <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  8218e2:	minss  %xmm14,%xmm11
  8218e7:	movaps %xmm11,%xmm14
  8218eb:	cmpunordss %xmm11,%xmm14
  8218f1:	movaps %xmm14,%xmm13
  8218f5:	andnps %xmm11,%xmm13
  8218f9:	andps  0x10(%rsp),%xmm14
  8218ff:	orps   %xmm13,%xmm14
  821903:	shufps $0x55,%xmm12,%xmm12
  821908:	mulss  -0x7729a5(%rip),%xmm12        # aef6c <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  821911:	movaps %xmm14,%xmm11
  821915:	minss  %xmm12,%xmm11
  82191a:	movaps %xmm11,%xmm12
  82191e:	cmpunordss %xmm11,%xmm12
  821924:	andps  %xmm12,%xmm14
  821928:	andnps %xmm11,%xmm12
  82192c:	orps   %xmm14,%xmm12
  821930:	movss  -0x7726e9(%rip),%xmm11        # af250 <anon.4109cdd7ddb1990ee57d5626700ecb68.286.llvm.4479275319843201559+0xc>
  821939:	ucomiss %xmm12,%xmm11
  82193d:	ja     821702 <gpui_gpu::renderer::validate_draw+0x182>
  821943:	xorps  %xmm14,%xmm14
  821947:	cvtss2sd %xmm12,%xmm14
  82194c:	movapd %xmm9,%xmm11
  821951:	divsd  %xmm14,%xmm11
  821956:	ucomisd -0x7720df(%rip),%xmm11        # af880 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x10>
  82195f:	ja     821702 <gpui_gpu::renderer::validate_draw+0x182>
  821965:	addsd  %xmm9,%xmm14
  82196a:	mulsd  -0x77224b(%rip),%xmm14        # af728 <anon.4109cdd7ddb1990ee57d5626700ecb68.92.llvm.4479275319843201559+0x10>
  821973:	movapd (%rsp),%xmm11
  821979:	movapd -0x776bd2(%rip),%xmm13        # aadb0 <GCC_except_table0+0xb8>
  821982:	cmp    $0x2,%esi
  821985:	movaps %xmm11,(%rsp)
  82198a:	jae    821a9b <gpui_gpu::renderer::validate_draw+0x51b>
  821990:	cvtps2pd %xmm8,%xmm8
  821994:	subpd  %xmm8,%xmm5
  821999:	cvtps2pd %xmm7,%xmm7
  82199c:	andpd  %xmm13,%xmm5
  8219a1:	mulpd  0x40(%rsp),%xmm5
  8219a7:	subpd  %xmm7,%xmm4
  8219ab:	andpd  %xmm13,%xmm4
  8219b0:	mulpd  0x50(%rsp),%xmm4
  8219b6:	addpd  %xmm5,%xmm4
  8219ba:	cvtps2pd %xmm6,%xmm5
  8219bd:	subpd  %xmm5,%xmm0
  8219c1:	addsd  -0x772152(%rip),%xmm10        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8219ca:	mulsd  -0x771f8b(%rip),%xmm10        # afa48 <anon.4109cdd7ddb1990ee57d5626700ecb68.350.llvm.4479275319843201559+0x18>
  8219d3:	andpd  %xmm13,%xmm0
  8219d8:	addpd  %xmm4,%xmm0
  8219dc:	movapd 0x60(%rsp),%xmm7
  8219e2:	addsd  %xmm7,%xmm15
  8219e7:	movapd (%rsp),%xmm6
  8219ec:	addsd  %xmm6,%xmm15
  8219f1:	addsd  0x30(%rsp),%xmm15
  8219f8:	movapd %xmm0,%xmm4
  8219fc:	unpckhpd %xmm0,%xmm4
  821a00:	addpd  %xmm0,%xmm4
  821a04:	movapd %xmm1,%xmm5
  821a08:	shufpd $0x1,%xmm4,%xmm5
  821a0d:	movapd %xmm2,%xmm4
  821a11:	unpcklpd %xmm10,%xmm4
  821a16:	addpd  %xmm4,%xmm5
  821a1a:	mulsd  -0x7723cb(%rip),%xmm15        # af658 <anon.a16d5d421a76dfd8c37a17b53540311d.77.llvm.14190004212411149437+0x10>
  821a23:	shufpd $0x1,%xmm15,%xmm2
  821a29:	addpd  %xmm5,%xmm2
  821a2d:	unpcklpd %xmm14,%xmm1
  821a32:	addpd  %xmm2,%xmm1
  821a36:	movapd %xmm1,%xmm2
  821a3a:	unpckhpd %xmm1,%xmm2
  821a3e:	mulsd  %xmm1,%xmm2
  821a42:	andpd  -0x776c9a(%rip),%xmm3        # aadb0 <GCC_except_table0+0xb8>
  821a4a:	divsd  %xmm3,%xmm2
  821a4e:	movq   %xmm2,%rdx
  821a53:	and    %rax,%rdx
  821a56:	cmp    %rcx,%rdx
  821a59:	jg     821702 <gpui_gpu::renderer::validate_draw+0x182>
  821a5f:	ucomisd -0x771bbf(%rip),%xmm2        # afea8 <anon.a16d5d421a76dfd8c37a17b53540311d.26.llvm.14190004212411149437+0x10>
  821a67:	ja     821702 <gpui_gpu::renderer::validate_draw+0x182>
  821a6d:	unpcklpd %xmm10,%xmm10
  821a72:	addpd  %xmm10,%xmm0
  821a77:	addpd  %xmm7,%xmm6
  821a7b:	mulpd  -0x776af3(%rip),%xmm6        # aaf90 <anon.068260129a360d3c14a88deb110120c9.101.llvm.7357624670875813013+0x1d0>
  821a83:	addpd  %xmm0,%xmm6
  821a87:	cvtpd2ps %xmm6,%xmm0
  821a8b:	movlpd %xmm0,0x4(%rbx)
  821a90:	movl   $0xffffffff,(%rbx)
  821a96:	jmp    82161d <gpui_gpu::renderer::validate_draw+0x9d>
  821a9b:	jne    821ab0 <gpui_gpu::renderer::validate_draw+0x530>
  821a9d:	mov    0x28(%r15),%rsi
  821aa1:	mov    0x30(%r15),%rdi
  821aa5:	jmp    821ab8 <gpui_gpu::renderer::validate_draw+0x538>
  821aa7:	movaps %xmm11,(%rsp)
  821aac:	xorps  %xmm14,%xmm14
  821ab0:	mov    0x28(%r15),%esi
  821ab4:	mov    0x2c(%r15),%edi
  821ab8:	movq   %rsi,%xmm11
  821abd:	punpckldq -0x7761f6(%rip),%xmm11        # ab8d0 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x290>
  821ac6:	subpd  -0x776d2f(%rip),%xmm11        # aada0 <GCC_except_table0+0xa8>
  821acf:	movapd %xmm11,%xmm12
  821ad4:	unpckhpd %xmm11,%xmm12
  821ad9:	addsd  %xmm11,%xmm12
  821ade:	movapd 0x20(%rsp),%xmm11
  821ae5:	divsd  %xmm11,%xmm12
  821aea:	movq   %xmm12,%r8
  821aef:	and    %rax,%r8
  821af2:	cmp    %rdx,%r8
  821af5:	jge    821702 <gpui_gpu::renderer::validate_draw+0x182>
  821afb:	movaps %xmm14,0x10(%rsp)
  821b01:	movapd %xmm11,%xmm14
  821b06:	movq   %rdi,%xmm11
  821b0b:	punpckldq -0x776244(%rip),%xmm11        # ab8d0 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x290>
  821b14:	subpd  -0x776d7d(%rip),%xmm11        # aada0 <GCC_except_table0+0xa8>
  821b1d:	movapd %xmm11,%xmm13
  821b22:	unpckhpd %xmm11,%xmm13
  821b27:	addsd  %xmm11,%xmm13
  821b2c:	unpckhpd %xmm14,%xmm14
  821b31:	divsd  %xmm14,%xmm13
  821b36:	movapd 0x10(%rsp),%xmm14
  821b3d:	movq   %xmm13,%rdx
  821b42:	and    %rax,%rdx
  821b45:	cmp    %rcx,%rdx
  821b48:	setg   %dl
  821b4b:	ucomisd -0x77253c(%rip),%xmm13        # af618 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  821b54:	movapd -0x776dad(%rip),%xmm13        # aadb0 <GCC_except_table0+0xb8>
  821b5d:	ja     821702 <gpui_gpu::renderer::validate_draw+0x182>
  821b63:	ucomisd -0x772554(%rip),%xmm12        # af618 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  821b6c:	ja     821702 <gpui_gpu::renderer::validate_draw+0x182>
  821b72:	test   %dl,%dl
  821b74:	jne    821702 <gpui_gpu::renderer::validate_draw+0x182>
  821b7a:	cmp    %rsi,%rdi
  821b7d:	cmova  %rdi,%rsi
  821b81:	movq   %rsi,%xmm11
  821b86:	punpckldq -0x7762bf(%rip),%xmm11        # ab8d0 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x290>
  821b8f:	subpd  -0x776df8(%rip),%xmm11        # aada0 <GCC_except_table0+0xa8>
  821b98:	movapd %xmm11,%xmm12
  821b9d:	unpckhpd %xmm11,%xmm12
  821ba2:	addsd  %xmm11,%xmm12
  821ba7:	mulsd  %xmm12,%xmm9
  821bac:	ucomisd -0x77259d(%rip),%xmm9        # af618 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  821bb5:	ja     821702 <gpui_gpu::renderer::validate_draw+0x182>
  821bbb:	jmp    821990 <gpui_gpu::renderer::validate_draw+0x410>

FUNCTION core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>> bytes=105 frame=8

/tmp/gpui-descending-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008222b0 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>:
  8222b0:	push   %rbx
  8222b1:	test   %rdi,%rdi
  8222b4:	je     822317 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x67>
  8222b6:	mov    %rdi,%rbx
  8222b9:	mov    (%rdi),%rsi
  8222bc:	test   %rsi,%rsi
  8222bf:	je     8222d4 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x24>
  8222c1:	mov    0x8(%rbx),%rdi
  8222c5:	shl    $0x3,%rsi
  8222c9:	mov    $0x8,%edx
  8222ce:	call   *0x65d58c(%rip)        # e7f860 <_DYNAMIC+0x248>
  8222d4:	mov    0x20(%rbx),%rsi
  8222d8:	test   %rsi,%rsi
  8222db:	je     822303 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  8222dd:	mov    %rsi,%rax
  8222e0:	shl    $0x4,%rax
  8222e4:	add    %rax,%rsi
  8222e7:	add    $0x21,%rsi
  8222eb:	je     822303 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  8222ed:	mov    0x18(%rbx),%rdi
  8222f1:	sub    %rax,%rdi
  8222f4:	add    $0xfffffffffffffff0,%rdi
  8222f8:	mov    $0x10,%edx
  8222fd:	call   *0x65d55d(%rip)        # e7f860 <_DYNAMIC+0x248>
  822303:	mov    $0x80,%esi
  822308:	mov    $0x8,%edx
  82230d:	mov    %rbx,%rdi
  822310:	pop    %rbx
  822311:	jmp    *0x65d549(%rip)        # e7f860 <_DYNAMIC+0x248>
  822317:	pop    %rbx
  822318:	ret

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Buffer> bytes=103 frame=24

/tmp/gpui-descending-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000822540 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>:
  822540:	push   %r14
  822542:	push   %rbx
  822543:	push   %rax
  822544:	mov    %rdi,%rbx
  822547:	mov    (%rdi),%rax
  82254a:	lock decq (%rax)
  82254e:	jne    822559 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x19>
  822550:	mov    %rbx,%rdi
  822553:	call   *0x65d5c7(%rip)        # e7fb20 <_DYNAMIC+0x508>
  822559:	mov    0x8(%rbx),%rax
  82255d:	lock decq (%rax)
  822561:	jne    822577 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x37>
  822563:	add    $0x8,%rbx
  822567:	mov    %rbx,%rdi
  82256a:	add    $0x8,%rsp
  82256e:	pop    %rbx
  82256f:	pop    %r14
  822571:	jmp    *0x65d5b1(%rip)        # e7fb28 <_DYNAMIC+0x510>
  822577:	add    $0x8,%rsp
  82257b:	pop    %rbx
  82257c:	pop    %r14
  82257e:	ret
  82257f:	mov    %rax,%r14
  822582:	mov    0x8(%rbx),%rax
  822586:	lock decq (%rax)
  82258a:	jne    822599 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x59>
  82258c:	add    $0x8,%rbx
  822590:	mov    %rbx,%rdi
  822593:	call   *0x65d58f(%rip)        # e7fb28 <_DYNAMIC+0x510>
  822599:	mov    %r14,%rdi
  82259c:	call   e2c400 <_Unwind_Resume@plt>
  8225a1:	call   *0x65d2c1(%rip)        # e7f868 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::images::Images> bytes=81 frame=8

/tmp/gpui-descending-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000822670 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>:
  822670:	push   %rbx
  822671:	mov    %rdi,%rbx
  822674:	mov    (%rdi),%rsi
  822677:	test   %rsi,%rsi
  82267a:	je     82268f <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>+0x1f>
  82267c:	mov    0x8(%rbx),%rdi
  822680:	shl    $0x3,%rsi
  822684:	mov    $0x8,%edx
  822689:	call   *0x65d1d1(%rip)        # e7f860 <_DYNAMIC+0x248>
  82268f:	mov    0x20(%rbx),%rsi
  822693:	test   %rsi,%rsi
  822696:	je     8226bf <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>+0x4f>
  822698:	mov    %rsi,%rax
  82269b:	shl    $0x4,%rax
  82269f:	add    %rax,%rsi
  8226a2:	add    $0x21,%rsi
  8226a6:	je     8226bf <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>+0x4f>
  8226a8:	mov    0x18(%rbx),%rdi
  8226ac:	sub    %rax,%rdi
  8226af:	add    $0xfffffffffffffff0,%rdi
  8226b3:	mov    $0x10,%edx
  8226b8:	pop    %rbx
  8226b9:	jmp    *0x65d1a1(%rip)        # e7f860 <_DYNAMIC+0x248>
  8226bf:	pop    %rbx
  8226c0:	ret

FUNCTION <gpui_gpu::renderer::images::Images>::metadata bytes=246 frame=40

/tmp/gpui-descending-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008226d0 <<gpui_gpu::renderer::images::Images>::metadata>:
  8226d0:	push   %r15
  8226d2:	push   %r14
  8226d4:	push   %rbx
  8226d5:	sub    $0x10,%rsp
  8226d9:	mov    %rsi,0x8(%rsp)
  8226de:	cmpq   $0x0,0x30(%rdi)
  8226e3:	je     8227ad <<gpui_gpu::renderer::images::Images>::metadata+0xdd>
  8226e9:	mov    %edx,%ebx
  8226eb:	mov    %rsi,%r14
  8226ee:	mov    %rdi,%r15
  8226f1:	add    $0x38,%rdi
  8226f5:	lea    0x8(%rsp),%rsi
  8226fa:	call   821f70 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  8226ff:	mov    %rax,%rsi
  822702:	shr    $0x39,%rsi
  822706:	mov    0x18(%r15),%rcx
  82270a:	mov    0x20(%r15),%rdx
  82270e:	movd   %esi,%xmm0
  822712:	punpcklbw %xmm0,%xmm0
  822716:	pshuflw $0x0,%xmm0,%xmm0
  82271b:	pshufd $0x44,%xmm0,%xmm0
  822720:	xor    %esi,%esi
  822722:	pcmpeqd %xmm1,%xmm1
  822726:	and    %rdx,%rax
  822729:	movdqu (%rcx,%rax,1),%xmm2
  82272e:	movdqa %xmm2,%xmm3
  822732:	pcmpeqb %xmm0,%xmm3
  822736:	pmovmskb %xmm3,%edi
  82273a:	test   %edi,%edi
  82273c:	je     822770 <<gpui_gpu::renderer::images::Images>::metadata+0xa0>
  82273e:	tzcnt  %edi,%r9d
  822743:	add    %rax,%r9
  822746:	and    %rdx,%r9
  822749:	shl    $0x4,%r9
  82274d:	mov    %rcx,%r8
  822750:	sub    %r9,%r8
  822753:	cmp    -0x10(%r8),%r14
  822757:	je     822789 <<gpui_gpu::renderer::images::Images>::metadata+0xb9>
  822759:	lea    -0x1(%rdi),%r8d
  82275d:	and    %di,%r8w
  822761:	mov    %r8d,%edi
  822764:	jne    82273e <<gpui_gpu::renderer::images::Images>::metadata+0x6e>
  822766:	cs nopw 0x0(%rax,%rax,1)
  822770:	pcmpeqb %xmm1,%xmm2
  822774:	pmovmskb %xmm2,%edi
  822778:	test   %edi,%edi
  82277a:	jne    8227ad <<gpui_gpu::renderer::images::Images>::metadata+0xdd>
  82277c:	add    %rsi,%rax
  82277f:	add    $0x10,%rax
  822783:	add    $0x10,%rsi
  822787:	jmp    822726 <<gpui_gpu::renderer::images::Images>::metadata+0x56>
  822789:	mov    -0x8(%r8),%eax
  82278d:	movzbl %bl,%ecx
  822790:	or     -0x4(%r8),%ecx
  822794:	shl    $0x20,%rcx
  822798:	or     %rax,%rcx
  82279b:	mov    $0x80000000,%eax
  8227a0:	or     %rcx,%rax
  8227a3:	add    $0x10,%rsp
  8227a7:	pop    %rbx
  8227a8:	pop    %r14
  8227aa:	pop    %r15
  8227ac:	ret
  8227ad:	lea    -0x74d80c(%rip),%rdi        # d4fa8 <anon.0e6fcc70e21e3189c77400f0a226742f.0.llvm.548032719764101456>
  8227b4:	lea    0x60baf5(%rip),%rdx        # e2e2b0 <anon.0e6fcc70e21e3189c77400f0a226742f.2.llvm.548032719764101456>
  8227bb:	mov    $0x16,%esi
  8227c0:	call   *0x65d3f2(%rip)        # e7fbb8 <_DYNAMIC+0x5a0>

FUNCTION gpui_gpu::renderer::images::prepare bytes=2648 frame=536

/tmp/gpui-descending-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000822a40 <gpui_gpu::renderer::images::prepare>:
  822a40:	push   %rbp
  822a41:	push   %r15
  822a43:	push   %r14
  822a45:	push   %r13
  822a47:	push   %r12
  822a49:	push   %rbx
  822a4a:	sub    $0x1e8,%rsp
  822a51:	mov    %r9,%r12
  822a54:	mov    %rcx,%r13
  822a57:	mov    %rdx,0xb0(%rsp)
  822a5f:	mov    %rsi,(%rsp)
  822a63:	mov    %rdi,%r15
  822a66:	mov    0x220(%rsp),%rax
  822a6e:	mov    0x10(%rax),%r14
  822a72:	mov    0x118(%r14),%rax
  822a79:	add    $0x118,%r14
  822a80:	test   %rax,%rax
  822a83:	mov    %r14,%rcx
  822a86:	cmove  %rax,%rcx
  822a8a:	je     822b1c <gpui_gpu::renderer::images::prepare+0xdc>
  822a90:	mov    0x10(%rax),%rax
  822a94:	mov    (%r8),%rbp
  822a97:	mov    %rax,0x10(%rsp)
  822a9c:	test   %rax,%rax
  822a9f:	je     822b1f <gpui_gpu::renderer::images::prepare+0xdf>
  822aa1:	mov    %rcx,0xa0(%rsp)
  822aa9:	test   %rbp,%rbp
  822aac:	je     822c68 <gpui_gpu::renderer::images::prepare+0x228>
  822ab2:	cmp    0x48(%rbp),%r12
  822ab6:	ja     822c68 <gpui_gpu::renderer::images::prepare+0x228>
  822abc:	mov    0x8(%rbp),%rdi
  822ac0:	mov    0x10(%rbp),%rax
  822ac4:	lea    (%rdi,%rax,8),%rsi
  822ac8:	movq   $0x1,0xd0(%rsp)
  822ad4:	mov    %r14,0xd8(%rsp)
  822adc:	movq   $0x0,0xe0(%rsp)
  822ae8:	movq   $0x0,0xf0(%rsp)
  822af4:	lea    0xd0(%rsp),%rdx
  822afc:	mov    %r8,%rbx
  822aff:	call   825980 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>>
  822b04:	mov    %rbx,%r8
  822b07:	test   %al,%al
  822b09:	je     822c68 <gpui_gpu::renderer::images::prepare+0x228>
  822b0f:	movq   $0x0,0x60(%rbp)
  822b17:	jmp    822c4c <gpui_gpu::renderer::images::prepare+0x20c>
  822b1c:	mov    (%r8),%rbp
  822b1f:	movq   $0x0,(%r8)
  822b26:	test   %rbp,%rbp
  822b29:	je     822c4c <gpui_gpu::renderer::images::prepare+0x20c>
  822b2f:	mov    0x0(%rbp),%rsi
  822b33:	test   %rsi,%rsi
  822b36:	je     822b4b <gpui_gpu::renderer::images::prepare+0x10b>
  822b38:	mov    0x8(%rbp),%rdi
  822b3c:	shl    $0x3,%rsi
  822b40:	mov    $0x8,%edx
  822b45:	call   *0x65cd15(%rip)        # e7f860 <_DYNAMIC+0x248>
  822b4b:	mov    0x20(%rbp),%rsi
  822b4f:	test   %rsi,%rsi
  822b52:	je     822b7a <gpui_gpu::renderer::images::prepare+0x13a>
  822b54:	mov    %rsi,%rax
  822b57:	shl    $0x4,%rax
  822b5b:	add    %rax,%rsi
  822b5e:	add    $0x21,%rsi
  822b62:	je     822b7a <gpui_gpu::renderer::images::prepare+0x13a>
  822b64:	mov    0x18(%rbp),%rdi
  822b68:	sub    %rax,%rdi
  822b6b:	add    $0xfffffffffffffff0,%rdi
  822b6f:	mov    $0x10,%edx
  822b74:	call   *0x65cce6(%rip)        # e7f860 <_DYNAMIC+0x248>
  822b7a:	mov    $0x80,%esi
  822b7f:	mov    $0x8,%edx
  822b84:	mov    %rbp,%rdi
  822b87:	call   *0x65ccd3(%rip)        # e7f860 <_DYNAMIC+0x248>
  822b8d:	shl    $0x4,%r12
  822b91:	cmp    $0x101,%r12
  822b98:	mov    $0x100,%eax
  822b9d:	cmovae %r12,%rax
  822ba1:	dec    %rax
  822ba4:	bsr    %rax,%rcx
  822ba8:	not    %ecx
  822baa:	mov    $0xffffffffffffffff,%rbx
  822bb1:	shr    %cl,%rbx
  822bb4:	inc    %rbx
  822bb7:	lea    -0x74dc00(%rip),%rax        # d4fbe <anon.0e6fcc70e21e3189c77400f0a226742f.0.llvm.548032719764101456+0x16>
  822bbe:	mov    %rax,0x18(%rsp)
  822bc3:	movq   $0xa,0x20(%rsp)
  822bcc:	mov    %rbx,0x28(%rsp)
  822bd1:	movl   $0x88,0x30(%rsp)
  822bd9:	movb   $0x0,0x34(%rsp)
  822bde:	lea    0xd0(%rsp),%rdi
  822be6:	lea    0x18(%rsp),%rdx
  822beb:	mov    (%rsp),%rsi
  822bef:	call   *0x65d03b(%rip)        # e7fc30 <_DYNAMIC+0x618>
  822bf5:	mov    %rbx,0xf0(%rsp)
  822bfd:	mov    0x0(%r13),%rax
  822c01:	lock decq (%rax)
  822c05:	jne    822c10 <gpui_gpu::renderer::images::prepare+0x1d0>
  822c07:	mov    %r13,%rdi
  822c0a:	call   *0x65cf10(%rip)        # e7fb20 <_DYNAMIC+0x508>
  822c10:	mov    0x8(%r13),%rax
  822c14:	lock decq (%rax)
  822c18:	jne    822c24 <gpui_gpu::renderer::images::prepare+0x1e4>
  822c1a:	lea    0x8(%r13),%rdi
  822c1e:	call   *0x65cf04(%rip)        # e7fb28 <_DYNAMIC+0x510>
  822c24:	mov    0xf0(%rsp),%rax
  822c2c:	mov    %rax,0x20(%r13)
  822c30:	movdqu 0xd0(%rsp),%xmm0
  822c39:	movups 0xe0(%rsp),%xmm1
  822c41:	movups %xmm1,0x10(%r13)
  822c46:	movdqu %xmm0,0x0(%r13)
  822c4c:	movl   $0xffffffff,(%r15)
  822c53:	mov    %r15,%rax
  822c56:	add    $0x1e8,%rsp
  822c5d:	pop    %rbx
  822c5e:	pop    %r12
  822c60:	pop    %r13
  822c62:	pop    %r14
  822c64:	pop    %r15
  822c66:	pop    %rbp
  822c67:	ret
  822c68:	cmp    $0x1,%r12
  822c6c:	mov    %r12,%rax
  822c6f:	adc    $0xffffffffffffffff,%rax
  822c73:	bsr    %rax,%rcx
  822c77:	not    %ecx
  822c79:	mov    $0xffffffffffffffff,%rax
  822c80:	shr    %cl,%rax
  822c83:	cmp    $0x2,%r12
  822c87:	mov    $0x0,%r12d
  822c8d:	cmovae %rax,%r12
  822c91:	inc    %r12
  822c94:	je     823388 <gpui_gpu::renderer::images::prepare+0x948>
  822c9a:	mov    %r8,0xc8(%rsp)
  822ca2:	mov    %fs:0x0,%rax
  822cab:	lea    -0x28(%rax),%rax
  822cb2:	mov    %rax,%rcx
  822cb5:	cmpb   $0x1,0x10(%rax)
  822cb9:	mov    %r15,0xa8(%rsp)
  822cc1:	mov    %r13,0x8(%rsp)
  822cc6:	jne    823394 <gpui_gpu::renderer::images::prepare+0x954>
  822ccc:	mov    (%rcx),%rax
  822ccf:	mov    0x8(%rcx),%rdx
  822cd3:	mov    0x10(%rsp),%rbx
  822cd8:	lea    0x1(%rax),%rsi
  822cdc:	mov    %rsi,(%rcx)
  822cdf:	movq   $0x0,0x18(%rsp)
  822ce8:	movq   $0x8,0x20(%rsp)
  822cf1:	movq   $0x0,0x28(%rsp)
  822cfa:	movups 0x60b5c7(%rip),%xmm0        # e2e2c8 <anon.0e6fcc70e21e3189c77400f0a226742f.2.llvm.548032719764101456+0x18>
  822d01:	movups %xmm0,0x30(%rsp)
  822d06:	movdqu 0x60b5ca(%rip),%xmm0        # e2e2d8 <anon.0e6fcc70e21e3189c77400f0a226742f.2.llvm.548032719764101456+0x28>
  822d0e:	movdqu %xmm0,0x40(%rsp)
  822d14:	mov    %rax,0x50(%rsp)
  822d19:	mov    %rdx,0x58(%rsp)
  822d1e:	mov    %r12,0x60(%rsp)
  822d23:	pxor   %xmm0,%xmm0
  822d27:	movdqu %xmm0,0x68(%rsp)
  822d2d:	movdqu %xmm0,0x78(%rsp)
  822d33:	movdqu %xmm0,0x88(%rsp)
  822d3c:	lea    0xd0(%rsp),%rdi
  822d44:	mov    $0x8,%edx
  822d49:	mov    $0x8,%r8d
  822d4f:	mov    $0x8,%r9d
  822d55:	xor    %esi,%esi
  822d57:	mov    %rbx,%rcx
  822d5a:	call   823d70 <<alloc::raw_vec::RawVecInner>::finish_grow>
  822d5f:	cmpl   $0x1,0xd0(%rsp)
  822d67:	jne    822dd4 <gpui_gpu::renderer::images::prepare+0x394>
  822d69:	mov    0xa8(%rsp),%r15
  822d71:	movl   $0x6,(%r15)
  822d78:	mov    0x18(%rsp),%rsi
  822d7d:	test   %rsi,%rsi
  822d80:	je     822d96 <gpui_gpu::renderer::images::prepare+0x356>
  822d82:	mov    0x20(%rsp),%rdi
  822d87:	shl    $0x3,%rsi
  822d8b:	mov    $0x8,%edx
  822d90:	call   *0x65caca(%rip)        # e7f860 <_DYNAMIC+0x248>
  822d96:	mov    0x38(%rsp),%rsi
  822d9b:	test   %rsi,%rsi
  822d9e:	je     822c53 <gpui_gpu::renderer::images::prepare+0x213>
  822da4:	mov    %rsi,%rax
  822da7:	shl    $0x4,%rax
  822dab:	add    %rax,%rsi
  822dae:	add    $0x21,%rsi
  822db2:	je     822c53 <gpui_gpu::renderer::images::prepare+0x213>
  822db8:	mov    0x30(%rsp),%rdi
  822dbd:	sub    %rax,%rdi
  822dc0:	add    $0xfffffffffffffff0,%rdi
  822dc4:	mov    $0x10,%edx
  822dc9:	call   *0x65ca91(%rip)        # e7f860 <_DYNAMIC+0x248>
  822dcf:	jmp    822c53 <gpui_gpu::renderer::images::prepare+0x213>
  822dd4:	mov    %r12,0x98(%rsp)
  822ddc:	mov    %rbp,0xc0(%rsp)
  822de4:	mov    0xd8(%rsp),%rax
  822dec:	mov    %rax,0x20(%rsp)
  822df1:	mov    %rbx,0x18(%rsp)
  822df6:	cmp    0x40(%rsp),%rbx
  822dfb:	ja     8233b0 <gpui_gpu::renderer::images::prepare+0x970>
  822e01:	xor    %r12d,%r12d
  822e04:	mov    0x98(%rsp),%r15
  822e0c:	jmp    822e28 <gpui_gpu::renderer::images::prepare+0x3e8>
  822e0e:	xchg   %ax,%ax
  822e10:	add    $0x8,%r12
  822e14:	mov    0x20(%rsp),%rax
  822e19:	mov    %rbx,(%rax,%r15,8)
  822e1d:	inc    %r15
  822e20:	mov    %r15,0x28(%rsp)
  822e25:	mov    %r13,%r15
  822e28:	test   %r12,%r12
  822e2b:	je     822e50 <gpui_gpu::renderer::images::prepare+0x410>
  822e2d:	cmp    %rbp,%r12
  822e30:	je     822e50 <gpui_gpu::renderer::images::prepare+0x410>
  822e32:	mov    (%r12),%rcx
  822e36:	cmpb   $0x0,0x10(%rcx)
  822e3a:	je     822e7e <gpui_gpu::renderer::images::prepare+0x43e>
  822e3c:	mov    0x20(%rcx),%rax
  822e40:	shl    $0x4,%rax
  822e44:	mov    $0x8,%r8d
  822e4a:	jmp    822e91 <gpui_gpu::renderer::images::prepare+0x451>
  822e4c:	nopl   0x0(%rax)
  822e50:	test   %r14,%r14
  822e53:	je     822f18 <gpui_gpu::renderer::images::prepare+0x4d8>
  822e59:	mov    (%r14),%rax
  822e5c:	mov    0x10(%rax),%rcx
  822e60:	test   %rcx,%rcx
  822e63:	je     822f18 <gpui_gpu::renderer::images::prepare+0x4d8>
  822e69:	mov    0x8(%rax),%r12
  822e6d:	lea    (%r12,%rcx,8),%rbp
  822e71:	xor    %r14d,%r14d
  822e74:	mov    (%r12),%rcx
  822e78:	cmpb   $0x0,0x10(%rcx)
  822e7c:	jne    822e3c <gpui_gpu::renderer::images::prepare+0x3fc>
  822e7e:	movzbl 0x11(%rcx),%edx
  822e82:	movzbl 0x12(%rcx),%esi
  822e86:	mov    0x20(%rcx),%rax
  822e8a:	shl    $0x2,%edx
  822e8d:	lea    (%rdx,%rsi,2),%r8d
  822e91:	mov    0x70(%rsp),%rdx
  822e96:	add    %rax,%rdx
  822e99:	jb     822d69 <gpui_gpu::renderer::images::prepare+0x329>
  822e9f:	mov    0x28(%rcx),%rbx
  822ea3:	mov    %rdx,0x70(%rsp)
  822ea8:	cmp    $0x4000000,%rdx
  822eaf:	ja     822d69 <gpui_gpu::renderer::images::prepare+0x329>
  822eb5:	mov    %r15,%rcx
  822eb8:	shr    $0x20,%rcx
  822ebc:	jne    822d69 <gpui_gpu::renderer::images::prepare+0x329>
  822ec2:	test   %r15d,%r15d
  822ec5:	js     822d69 <gpui_gpu::renderer::images::prepare+0x329>
  822ecb:	mov    %rax,%r13
  822ece:	shr    $0x4,%r13
  822ed2:	and    $0xf,%eax
  822ed5:	add    %r15,%r13
  822ed8:	cmp    $0x1,%rax
  822edc:	sbb    $0xffffffffffffffff,%r13
  822ee0:	lea    0xd0(%rsp),%rdi
  822ee8:	lea    0x30(%rsp),%rsi
  822eed:	mov    %rbx,%rdx
  822ef0:	mov    %r15d,%ecx
  822ef3:	call   8237f0 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert>
  822ef8:	mov    0x28(%rsp),%r15
  822efd:	cmp    0x18(%rsp),%r15
  822f02:	jne    822e10 <gpui_gpu::renderer::images::prepare+0x3d0>
  822f08:	lea    0x18(%rsp),%rdi
  822f0d:	call   *0x65cd9d(%rip)        # e7fcb0 <_DYNAMIC+0x698>
  822f13:	jmp    822e10 <gpui_gpu::renderer::images::prepare+0x3d0>
  822f18:	movabs $0xffffffffffffff0,%rax
  822f22:	cmp    %rax,%r15
  822f25:	ja     822d69 <gpui_gpu::renderer::images::prepare+0x329>
  822f2b:	lea    0xd0(%rsp),%rdi
  822f33:	mov    (%rsp),%rsi
  822f37:	call   *0x65cd7b(%rip)        # e7fcb8 <_DYNAMIC+0x6a0>
  822f3d:	mov    %r15,%rbx
  822f40:	shl    $0x4,%rbx
  822f44:	add    $0xff,%rbx
  822f4b:	and    $0xffffffffffffff00,%rbx
  822f52:	cmp    0x120(%rsp),%rbx
  822f5a:	ja     822d69 <gpui_gpu::renderer::images::prepare+0x329>
  822f60:	lea    0xd0(%rsp),%rdi
  822f68:	mov    (%rsp),%rsi
  822f6c:	call   *0x65cd46(%rip)        # e7fcb8 <_DYNAMIC+0x6a0>
  822f72:	cmp    0x130(%rsp),%rbx
  822f7a:	ja     822d69 <gpui_gpu::renderer::images::prepare+0x329>
  822f80:	mov    0x8(%rsp),%rax
  822f85:	mov    0x20(%rax),%rax
  822f89:	cmp    %rbx,%rax
  822f8c:	jb     822fb4 <gpui_gpu::renderer::images::prepare+0x574>
  822f8e:	lea    0x0(,%rbx,4),%rcx
  822f96:	movabs $0x3fffffffffffff1,%rdx
  822fa0:	cmp    %rdx,%r15
  822fa3:	setb   %dl
  822fa6:	cmp    %rcx,%rax
  822fa9:	seta   %al
  822fac:	test   %al,%dl
  822fae:	je     823042 <gpui_gpu::renderer::images::prepare+0x602>
  822fb4:	lea    -0x74dff3(%rip),%rax        # d4fc8 <anon.0e6fcc70e21e3189c77400f0a226742f.0.llvm.548032719764101456+0x20>
  822fbb:	mov    %rax,0x1c8(%rsp)
  822fc3:	movq   $0x1d,0x1d0(%rsp)
  822fcf:	mov    %rbx,0x1d8(%rsp)
  822fd7:	movl   $0x88,0x1e0(%rsp)
  822fe2:	movb   $0x0,0x1e4(%rsp)
  822fea:	lea    0xd0(%rsp),%rdi
  822ff2:	lea    0x1c8(%rsp),%rdx
  822ffa:	mov    (%rsp),%rsi
  822ffe:	call   *0x65cc2c(%rip)        # e7fc30 <_DYNAMIC+0x618>
  823004:	mov    %rbx,0xf0(%rsp)
  82300c:	mov    0x8(%rsp),%r14
  823011:	mov    %r14,%rdi
  823014:	call   822540 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  823019:	mov    0xf0(%rsp),%rax
  823021:	mov    %rax,0x20(%r14)
  823025:	movdqu 0xd0(%rsp),%xmm0
  82302e:	movdqu 0xe0(%rsp),%xmm1
  823037:	movdqu %xmm1,0x10(%r14)
  82303d:	movdqu %xmm0,(%r14)
  823042:	movq   $0x0,(%rsp)
  82304a:	mov    0x65cb97(%rip),%r14        # e7fbe8 <_DYNAMIC+0x5d0>
  823051:	mov    (%rsp),%rdx
  823055:	test   %rdx,%rdx
  823058:	je     823064 <gpui_gpu::renderer::images::prepare+0x624>
  82305a:	cmp    0xb8(%rsp),%rdx
  823062:	jne    8230a1 <gpui_gpu::renderer::images::prepare+0x661>
  823064:	mov    0xa0(%rsp),%rax
  82306c:	test   %rax,%rax
  82306f:	je     823224 <gpui_gpu::renderer::images::prepare+0x7e4>
  823075:	mov    (%rax),%rax
  823078:	mov    0x10(%rax),%rcx
  82307c:	test   %rcx,%rcx
  82307f:	je     823224 <gpui_gpu::renderer::images::prepare+0x7e4>
  823085:	mov    0x8(%rax),%rdx
  823089:	lea    (%rdx,%rcx,8),%rax
  82308d:	mov    %rax,0xb8(%rsp)
  823095:	movq   $0x0,0xa0(%rsp)
  8230a1:	mov    (%rdx),%rax
  8230a4:	mov    0x28(%rax),%r12
  8230a8:	movzbl 0x10(%rax),%ebx
  8230ac:	mov    0x18(%rax),%rbp
  8230b0:	mov    0x20(%rax),%r13
  8230b4:	mov    %r12,0xd0(%rsp)
  8230bc:	cmpq   $0x0,0x48(%rsp)
  8230c2:	je     823209 <gpui_gpu::renderer::images::prepare+0x7c9>
  8230c8:	add    $0x8,%rdx
  8230cc:	mov    %rdx,(%rsp)
  8230d0:	lea    0x50(%rsp),%rdi
  8230d5:	lea    0xd0(%rsp),%rsi
  8230dd:	call   821f70 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  8230e2:	mov    %rax,%rsi
  8230e5:	shr    $0x39,%rsi
  8230e9:	mov    0x30(%rsp),%rcx
  8230ee:	mov    0x38(%rsp),%rdx
  8230f3:	movd   %esi,%xmm0
  8230f7:	punpcklbw %xmm0,%xmm0
  8230fb:	pshuflw $0x0,%xmm0,%xmm0
  823100:	pshufd $0x44,%xmm0,%xmm0
  823105:	xor    %esi,%esi
  823107:	and    %rdx,%rax
  82310a:	movdqu (%rcx,%rax,1),%xmm1
  82310f:	movdqa %xmm1,%xmm2
  823113:	pcmpeqb %xmm0,%xmm2
  823117:	pmovmskb %xmm2,%edi
  82311b:	test   %edi,%edi
  82311d:	je     823147 <gpui_gpu::renderer::images::prepare+0x707>
  82311f:	tzcnt  %edi,%r9d
  823124:	add    %rax,%r9
  823127:	and    %rdx,%r9
  82312a:	shl    $0x4,%r9
  82312e:	mov    %rcx,%r8
  823131:	sub    %r9,%r8
  823134:	cmp    -0x10(%r8),%r12
  823138:	je     823168 <gpui_gpu::renderer::images::prepare+0x728>
  82313a:	lea    -0x1(%rdi),%r8d
  82313e:	and    %di,%r8w
  823142:	mov    %r8d,%edi
  823145:	jne    82311f <gpui_gpu::renderer::images::prepare+0x6df>
  823147:	pcmpeqd %xmm2,%xmm2
  82314b:	pcmpeqb %xmm2,%xmm1
  82314f:	pmovmskb %xmm1,%edi
  823153:	test   %edi,%edi
  823155:	jne    823209 <gpui_gpu::renderer::images::prepare+0x7c9>
  82315b:	add    %rsi,%rax
  82315e:	add    $0x10,%rax
  823162:	add    $0x10,%rsi
  823166:	jmp    823107 <gpui_gpu::renderer::images::prepare+0x6c7>
  823168:	mov    -0x8(%r8),%r12d
  82316c:	shl    $0x4,%r12
  823170:	test   %bl,%bl
  823172:	je     8231c7 <gpui_gpu::renderer::images::prepare+0x787>
  823174:	test   %r13,%r13
  823177:	je     823051 <gpui_gpu::renderer::images::prepare+0x611>
  82317d:	nopl   (%rax)
  823180:	cmp    $0x1000,%r13
  823187:	mov    $0x1000,%r15d
  82318d:	cmovb  %r13,%r15
  823191:	mov    %r15d,%ebx
  823194:	shl    $0x4,%ebx
  823197:	mov    0xb0(%rsp),%rdi
  82319f:	mov    0x8(%rsp),%rsi
  8231a4:	mov    %r12,%rdx
  8231a7:	mov    %rbp,%rcx
  8231aa:	mov    %rbx,%r8
  8231ad:	call   *%r14
  8231b0:	mov    %r15,%rax
  8231b3:	shl    $0x4,%rax
  8231b7:	add    %rax,%rbp
  8231ba:	add    %rbx,%r12
  8231bd:	sub    %r15,%r13
  8231c0:	jne    823180 <gpui_gpu::renderer::images::prepare+0x740>
  8231c2:	jmp    823051 <gpui_gpu::renderer::images::prepare+0x611>
  8231c7:	test   %r13,%r13
  8231ca:	je     823051 <gpui_gpu::renderer::images::prepare+0x611>
  8231d0:	cmp    $0x10000,%r13
  8231d7:	mov    $0x10000,%ebx
  8231dc:	cmovb  %r13,%rbx
  8231e0:	mov    0xb0(%rsp),%rdi
  8231e8:	mov    0x8(%rsp),%rsi
  8231ed:	mov    %r12,%rdx
  8231f0:	mov    %rbp,%rcx
  8231f3:	mov    %rbx,%r8
  8231f6:	call   *%r14
  8231f9:	add    %rbx,%rbp
  8231fc:	add    %rbx,%r12
  8231ff:	sub    %rbx,%r13
  823202:	jne    8231d0 <gpui_gpu::renderer::images::prepare+0x790>
  823204:	jmp    823051 <gpui_gpu::renderer::images::prepare+0x611>
  823209:	lea    -0x74e268(%rip),%rdi        # d4fa8 <anon.0e6fcc70e21e3189c77400f0a226742f.0.llvm.548032719764101456>
  823210:	lea    0x60b0d1(%rip),%rdx        # e2e2e8 <anon.0e6fcc70e21e3189c77400f0a226742f.2.llvm.548032719764101456+0x38>
  823217:	mov    $0x16,%esi
  82321c:	call   *0x65c996(%rip)        # e7fbb8 <_DYNAMIC+0x5a0>
  823222:	ud2
  823224:	mov    0x10(%rsp),%rax
  823229:	mov    %rax,0x68(%rsp)
  82322e:	mov    0x70(%rsp),%rax
  823233:	mov    %rax,0x78(%rsp)
  823238:	mov    0x98(%rsp),%rax
  823240:	shl    $0x4,%rax
  823244:	mov    %rax,0x80(%rsp)
  82324c:	mov    0x8(%rsp),%rax
  823251:	mov    0x20(%rax),%rax
  823255:	mov    %rax,0x88(%rsp)
  82325d:	mov    0x40(%rsp),%rax
  823262:	add    0x48(%rsp),%rax
  823267:	mov    %rax,0x90(%rsp)
  82326f:	mov    0x88(%rsp),%rax
  823277:	mov    %rax,0x140(%rsp)
  82327f:	mov    0x90(%rsp),%rax
  823287:	mov    %rax,0x148(%rsp)
  82328f:	mov    0x78(%rsp),%rax
  823294:	mov    %rax,0x130(%rsp)
  82329c:	mov    0x80(%rsp),%rax
  8232a4:	mov    %rax,0x138(%rsp)
  8232ac:	movups 0x68(%rsp),%xmm0
  8232b1:	movaps %xmm0,0x120(%rsp)
  8232b9:	movups 0x58(%rsp),%xmm0
  8232be:	movaps %xmm0,0x110(%rsp)
  8232c6:	movups 0x48(%rsp),%xmm0
  8232cb:	movaps %xmm0,0x100(%rsp)
  8232d3:	movups 0x18(%rsp),%xmm0
  8232d8:	movups 0x28(%rsp),%xmm1
  8232dd:	movups 0x38(%rsp),%xmm2
  8232e2:	movaps %xmm2,0xf0(%rsp)
  8232ea:	movaps %xmm1,0xe0(%rsp)
  8232f2:	movaps %xmm0,0xd0(%rsp)
  8232fa:	call   822a10 <alloc::boxed::box_new_uninit>
  8232ff:	mov    %rax,%rbx
  823302:	movaps 0x140(%rsp),%xmm0
  82330a:	movups %xmm0,0x70(%rax)
  82330e:	movaps 0x130(%rsp),%xmm0
  823316:	movups %xmm0,0x60(%rax)
  82331a:	movaps 0x120(%rsp),%xmm0
  823322:	movups %xmm0,0x50(%rax)
  823326:	movaps 0x110(%rsp),%xmm0
  82332e:	movups %xmm0,0x40(%rax)
  823332:	movdqa 0xd0(%rsp),%xmm0
  82333b:	movaps 0xe0(%rsp),%xmm1
  823343:	movaps 0xf0(%rsp),%xmm2
  82334b:	movaps 0x100(%rsp),%xmm3
  823353:	movups %xmm3,0x30(%rax)
  823357:	movups %xmm2,0x20(%rax)
  82335b:	movups %xmm1,0x10(%rax)
  82335f:	movdqu %xmm0,(%rax)
  823363:	mov    0xc0(%rsp),%rdi
  82336b:	call   8222b0 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>
  823370:	mov    0xc8(%rsp),%rax
  823378:	mov    %rbx,(%rax)
  82337b:	mov    0xa8(%rsp),%r15
  823383:	jmp    822c4c <gpui_gpu::renderer::images::prepare+0x20c>
  823388:	movl   $0x6,(%r15)
  82338f:	jmp    822c53 <gpui_gpu::renderer::images::prepare+0x213>
  823394:	mov    %rcx,%rbx
  823397:	call   *0x65c89b(%rip)        # e7fc38 <_DYNAMIC+0x620>
  82339d:	mov    %rbx,%rcx
  8233a0:	mov    %rax,(%rbx)
  8233a3:	mov    %rdx,0x8(%rbx)
  8233a7:	movb   $0x1,0x10(%rbx)
  8233ab:	jmp    822cd3 <gpui_gpu::renderer::images::prepare+0x293>
  8233b0:	lea    0x30(%rsp),%rdi
  8233b5:	mov    0x10(%rsp),%rsi
  8233ba:	lea    0x50(%rsp),%rdx
  8233bf:	xor    %ecx,%ecx
  8233c1:	call   *0x65c8f9(%rip)        # e7fcc0 <_DYNAMIC+0x6a8>
  8233c7:	cmp    $0xffffffffffffffff,%rax
  8233cb:	jne    822d69 <gpui_gpu::renderer::images::prepare+0x329>
  8233d1:	jmp    822e01 <gpui_gpu::renderer::images::prepare+0x3c1>
  8233d6:	mov    %rax,%rbx
  8233d9:	lea    0xd0(%rsp),%rdi
  8233e1:	call   822670 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>
  8233e6:	mov    %rbx,%rdi
  8233e9:	call   e2c400 <_Unwind_Resume@plt>
  8233ee:	mov    %rax,%rbx
  8233f1:	mov    0xf0(%rsp),%rax
  8233f9:	mov    %rax,0x20(%r14)
  8233fd:	movups 0xd0(%rsp),%xmm0
  823405:	movups 0xe0(%rsp),%xmm1
  82340d:	movups %xmm1,0x10(%r14)
  823412:	movups %xmm0,(%r14)
  823416:	lea    0x18(%rsp),%rdi
  82341b:	call   822670 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>
  823420:	mov    %rbx,%rdi
  823423:	call   e2c400 <_Unwind_Resume@plt>
  823428:	mov    %r13,%r14
  82342b:	mov    %rax,%rbx
  82342e:	jmp    82344a <gpui_gpu::renderer::images::prepare+0xa0a>
  823430:	mov    %rax,%rbx
  823433:	mov    %r13,%r14
  823436:	mov    0x8(%r13),%rax
  82343a:	lock decq (%rax)
  82343e:	jne    82344a <gpui_gpu::renderer::images::prepare+0xa0a>
  823440:	lea    0x8(%r14),%rdi
  823444:	call   *0x65c6de(%rip)        # e7fb28 <_DYNAMIC+0x510>
  82344a:	mov    0xf0(%rsp),%rax
  823452:	mov    %rax,0x20(%r14)
  823456:	movups 0xd0(%rsp),%xmm0
  82345e:	movups 0xe0(%rsp),%xmm1
  823466:	movups %xmm1,0x10(%r14)
  82346b:	movups %xmm0,(%r14)
  82346f:	mov    %rbx,%rdi
  823472:	call   e2c400 <_Unwind_Resume@plt>
  823477:	call   *0x65c3eb(%rip)        # e7f868 <_DYNAMIC+0x250>
  82347d:	jmp    823483 <gpui_gpu::renderer::images::prepare+0xa43>
  82347f:	jmp    823483 <gpui_gpu::renderer::images::prepare+0xa43>
  823481:	jmp    823483 <gpui_gpu::renderer::images::prepare+0xa43>
  823483:	mov    %rax,%rbx
  823486:	lea    0x18(%rsp),%rdi
  82348b:	call   822670 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>
  823490:	mov    %rbx,%rdi
  823493:	call   e2c400 <_Unwind_Resume@plt>

FUNCTION <hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert bytes=489 frame=104

/tmp/gpui-descending-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000823600 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert>:
  823600:	push   %rbp
  823601:	push   %r15
  823603:	push   %r14
  823605:	push   %r13
  823607:	push   %r12
  823609:	push   %rbx
  82360a:	sub    $0x38,%rsp
  82360e:	mov    %rcx,%r15
  823611:	mov    %rdx,%r12
  823614:	mov    %rsi,%r14
  823617:	mov    %rdi,%rbx
  82361a:	lea    0x20(%rsi),%r13
  82361e:	mov    %r13,%rdi
  823621:	mov    %rdx,%rsi
  823624:	call   821dd0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  823629:	cmpq   $0x0,0x10(%r14)
  82362e:	je     8237b1 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x1b1>
  823634:	mov    (%r14),%r11
  823637:	mov    0x8(%r14),%rsi
  82363b:	mov    %rax,%rdx
  82363e:	shr    $0x39,%rdx
  823642:	movd   %edx,%xmm0
  823646:	punpcklbw %xmm0,%xmm0
  82364a:	pshuflw $0x0,%xmm0,%xmm0
  82364f:	pshufd $0x44,%xmm0,%xmm0
  823654:	mov    (%r12),%rcx
  823658:	mov    %rcx,0x8(%rsp)
  82365d:	movzwl 0xc(%r12),%r9d
  823663:	mov    0x8(%r12),%r10d
  823668:	xor    %r13d,%r13d
  82366b:	pcmpeqd %xmm1,%xmm1
  82366f:	xor    %r8d,%r8d
  823672:	and    %rsi,%rax
  823675:	movdqu (%r11,%rax,1),%xmm2
  82367b:	movdqa %xmm2,%xmm3
  82367f:	pcmpeqb %xmm0,%xmm3
  823683:	pmovmskb %xmm3,%ebp
  823687:	test   %ebp,%ebp
  823689:	je     8236d0 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xd0>
  82368b:	mov    %r8,(%rsp)
  82368f:	mov    %r15,%r8
  823692:	tzcnt  %ebp,%r15d
  823697:	add    %rax,%r15
  82369a:	and    %rsi,%r15
  82369d:	shl    $0x5,%r15
  8236a1:	mov    %r11,%rcx
  8236a4:	sub    %r15,%rcx
  8236a7:	mov    0x8(%rsp),%r15
  8236ac:	cmp    -0x20(%rcx),%r15
  8236b0:	jne    8236bf <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xbf>
  8236b2:	cmp    -0x14(%rcx),%r9w
  8236b7:	jne    8236bf <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xbf>
  8236b9:	cmp    -0x18(%rcx),%r10d
  8236bd:	je     82370f <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x10f>
  8236bf:	lea    -0x1(%rbp),%ecx
  8236c2:	and    %bp,%cx
  8236c5:	mov    %ecx,%ebp
  8236c7:	mov    %r8,%r15
  8236ca:	mov    (%rsp),%r8
  8236ce:	jne    82368f <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x8f>
  8236d0:	cmp    $0x1,%r13
  8236d4:	je     8236e8 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xe8>
  8236d6:	pmovmskb %xmm2,%ecx
  8236da:	test   %ecx,%ecx
  8236dc:	je     8236fc <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xfc>
  8236de:	tzcnt  %ecx,%edi
  8236e2:	add    %rax,%rdi
  8236e5:	and    %rsi,%rdi
  8236e8:	pcmpeqb %xmm1,%xmm2
  8236ec:	pmovmskb %xmm2,%ecx
  8236f0:	test   %ecx,%ecx
  8236f2:	jne    823726 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x126>
  8236f4:	mov    $0x1,%r13d
  8236fa:	jmp    8236ff <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xff>
  8236fc:	xor    %r13d,%r13d
  8236ff:	add    %r8,%rax
  823702:	add    $0x10,%rax
  823706:	add    $0x10,%r8
  82370a:	jmp    823672 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x72>
  82370f:	movups -0x10(%rcx),%xmm0
  823713:	movups %xmm0,0x4(%rbx)
  823717:	movups (%r8),%xmm0
  82371b:	movups %xmm0,-0x10(%rcx)
  82371f:	mov    $0x1,%eax
  823724:	jmp    82379d <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x19d>
  823726:	movzbl (%r11,%rdi,1),%eax
  82372b:	test   %al,%al
  82372d:	jns    8237d2 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x1d2>
  823733:	movups (%r12),%xmm0
  823738:	movaps %xmm0,0x10(%rsp)
  82373d:	movups (%r15),%xmm0
  823741:	movaps %xmm0,0x20(%rsp)
  823746:	and    $0x1,%al
  823748:	lea    -0x10(%rdi),%rcx
  82374c:	and    %rsi,%rcx
  82374f:	mov    %dl,(%r11,%rdi,1)
  823753:	mov    %dl,0x10(%r11,%rcx,1)
  823758:	movzbl %al,%eax
  82375b:	movd   %eax,%xmm0
  82375f:	shufpd $0x2,-0x778588(%rip),%xmm0        # ab1e0 <anon.a16d5d421a76dfd8c37a17b53540311d.51.llvm.14190004212411149437+0xe0>
  823768:	movdqu 0x10(%r14),%xmm1
  82376e:	psubq  %xmm0,%xmm1
  823772:	movdqu %xmm1,0x10(%r14)
  823778:	shl    $0x5,%rdi
  82377c:	mov    %r11,%rax
  82377f:	sub    %rdi,%rax
  823782:	neg    %rdi
  823785:	movaps 0x10(%rsp),%xmm0
  82378a:	movdqa 0x20(%rsp),%xmm1
  823790:	movups %xmm0,-0x20(%r11,%rdi,1)
  823796:	movdqu %xmm1,-0x10(%rax)
  82379b:	xor    %eax,%eax
  82379d:	mov    %eax,(%rbx)
  82379f:	mov    %rbx,%rax
  8237a2:	add    $0x38,%rsp
  8237a6:	pop    %rbx
  8237a7:	pop    %r12
  8237a9:	pop    %r13
  8237ab:	pop    %r14
  8237ad:	pop    %r15
  8237af:	pop    %rbp
  8237b0:	ret
  8237b1:	mov    $0x1,%esi
  8237b6:	mov    %r14,%rdi
  8237b9:	mov    %r13,%rdx
  8237bc:	mov    $0x1,%ecx
  8237c1:	mov    %rax,%r13
  8237c4:	call   *0x65c52e(%rip)        # e7fcf8 <_DYNAMIC+0x6e0>
  8237ca:	mov    %r13,%rax
  8237cd:	jmp    823634 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x34>
  8237d2:	movdqa (%r11),%xmm0
  8237d7:	pmovmskb %xmm0,%eax
  8237db:	tzcnt  %eax,%edi
  8237df:	movzbl (%r11,%rdi,1),%eax
  8237e4:	jmp    823733 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x133>

FUNCTION <hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert bytes=428 frame=56

/tmp/gpui-descending-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008237f0 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert>:
  8237f0:	push   %rbp
  8237f1:	push   %r15
  8237f3:	push   %r14
  8237f5:	push   %r13
  8237f7:	push   %r12
  8237f9:	push   %rbx
  8237fa:	push   %rax
  8237fb:	mov    %r8d,%ebp
  8237fe:	mov    %ecx,%r14d
  823801:	mov    %rdx,%r15
  823804:	mov    %rsi,%r12
  823807:	mov    %rdi,%rbx
  82380a:	mov    %rdx,(%rsp)
  82380e:	lea    0x20(%rsi),%r13
  823812:	mov    %rsp,%rsi
  823815:	mov    %r13,%rdi
  823818:	call   821f70 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  82381d:	cmpq   $0x0,0x10(%r12)
  823823:	je     823966 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x176>
  823829:	mov    (%r12),%rcx
  82382d:	mov    0x8(%r12),%rsi
  823832:	mov    %rax,%rdx
  823835:	shr    $0x39,%rdx
  823839:	movd   %edx,%xmm0
  82383d:	punpcklbw %xmm0,%xmm0
  823841:	pshuflw $0x0,%xmm0,%xmm0
  823846:	pshufd $0x44,%xmm0,%xmm0
  82384b:	xor    %r9d,%r9d
  82384e:	pcmpeqd %xmm1,%xmm1
  823852:	xor    %r8d,%r8d
  823855:	and    %rsi,%rax
  823858:	movdqu (%rcx,%rax,1),%xmm2
  82385d:	movdqa %xmm2,%xmm3
  823861:	pcmpeqb %xmm0,%xmm3
  823865:	pmovmskb %xmm3,%r10d
  82386a:	test   %r10d,%r10d
  82386d:	je     8238a0 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xb0>
  82386f:	tzcnt  %r10d,%r13d
  823874:	add    %rax,%r13
  823877:	and    %rsi,%r13
  82387a:	shl    $0x4,%r13
  82387e:	mov    %rcx,%r11
  823881:	sub    %r13,%r11
  823884:	cmp    -0x10(%r11),%r15
  823888:	je     8238e1 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xf1>
  82388a:	lea    -0x1(%r10),%r11d
  82388e:	and    %r10w,%r11w
  823892:	mov    %r11d,%r10d
  823895:	jne    82386f <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x7f>
  823897:	nopw   0x0(%rax,%rax,1)
  8238a0:	cmp    $0x1,%r9
  8238a4:	je     8238b8 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xc8>
  8238a6:	pmovmskb %xmm2,%edi
  8238aa:	test   %edi,%edi
  8238ac:	je     8238ce <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xde>
  8238ae:	tzcnt  %edi,%edi
  8238b2:	add    %rax,%rdi
  8238b5:	and    %rsi,%rdi
  8238b8:	pcmpeqb %xmm1,%xmm2
  8238bc:	pmovmskb %xmm2,%r9d
  8238c1:	test   %r9d,%r9d
  8238c4:	jne    8238f8 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x108>
  8238c6:	mov    $0x1,%r9d
  8238cc:	jmp    8238d1 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xe1>
  8238ce:	xor    %r9d,%r9d
  8238d1:	add    %r8,%rax
  8238d4:	add    $0x10,%rax
  8238d8:	add    $0x10,%r8
  8238dc:	jmp    823855 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x65>
  8238e1:	mov    -0x8(%r11),%rax
  8238e5:	mov    %r14d,-0x8(%r11)
  8238e9:	mov    %ebp,-0x4(%r11)
  8238ed:	mov    %rax,0x4(%rbx)
  8238f1:	mov    $0x1,%eax
  8238f6:	jmp    823952 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x162>
  8238f8:	movzbl (%rcx,%rdi,1),%eax
  8238fc:	test   %al,%al
  8238fe:	jns    823987 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x197>
  823904:	and    $0x1,%al
  823906:	lea    -0x10(%rdi),%r8
  82390a:	and    %rsi,%r8
  82390d:	mov    %dl,(%rcx,%rdi,1)
  823910:	mov    %dl,0x10(%rcx,%r8,1)
  823915:	movdqu 0x10(%r12),%xmm0
  82391c:	movzbl %al,%eax
  82391f:	movd   %eax,%xmm1
  823923:	shufpd $0x2,-0x77874c(%rip),%xmm1        # ab1e0 <anon.a16d5d421a76dfd8c37a17b53540311d.51.llvm.14190004212411149437+0xe0>
  82392c:	psubq  %xmm1,%xmm0
  823930:	movdqu %xmm0,0x10(%r12)
  823937:	shl    $0x4,%rdi
  82393b:	mov    %rcx,%rax
  82393e:	sub    %rdi,%rax
  823941:	neg    %rdi
  823944:	mov    %r15,-0x10(%rcx,%rdi,1)
  823949:	mov    %r14d,-0x8(%rax)
  82394d:	mov    %ebp,-0x4(%rax)
  823950:	xor    %eax,%eax
  823952:	mov    %eax,(%rbx)
  823954:	mov    %rbx,%rax
  823957:	add    $0x8,%rsp
  82395b:	pop    %rbx
  82395c:	pop    %r12
  82395e:	pop    %r13
  823960:	pop    %r14
  823962:	pop    %r15
  823964:	pop    %rbp
  823965:	ret
  823966:	mov    $0x1,%esi
  82396b:	mov    %r12,%rdi
  82396e:	mov    %r13,%rdx
  823971:	mov    $0x1,%ecx
  823976:	mov    %rax,%r13
  823979:	call   *0x65c341(%rip)        # e7fcc0 <_DYNAMIC+0x6a8>
  82397f:	mov    %r13,%rax
  823982:	jmp    823829 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x39>
  823987:	movdqa (%rcx),%xmm0
  82398b:	pmovmskb %xmm0,%eax
  82398f:	tzcnt  %eax,%edi
  823993:	movzbl (%rcx,%rdi,1),%eax
  823997:	jmp    823904 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x114>

FUNCTION <alloc::raw_vec::RawVec<gpui_gpu::renderer::Correction>>::grow_one bytes=100 frame=40

/tmp/gpui-descending-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000823d00 <<alloc::raw_vec::RawVec<gpui_gpu::renderer::Correction>>::grow_one>:
  823d00:	push   %r14
  823d02:	push   %rbx
  823d03:	sub    $0x18,%rsp
  823d07:	mov    %rdi,%rbx
  823d0a:	mov    (%rdi),%rsi
  823d0d:	lea    (%rsi,%rsi,1),%rax
  823d11:	cmp    $0x5,%rax
  823d15:	mov    $0x4,%r14d
  823d1b:	cmovae %rax,%r14
  823d1f:	mov    0x8(%rdi),%rdx
  823d23:	mov    %rsp,%rdi
  823d26:	mov    $0x4,%r8d
  823d2c:	mov    $0x20,%r9d
  823d32:	mov    %r14,%rcx
  823d35:	call   823d70 <<alloc::raw_vec::RawVecInner>::finish_grow>
  823d3a:	cmpl   $0x1,(%rsp)
  823d3e:	je     823d54 <<alloc::raw_vec::RawVec<gpui_gpu::renderer::Correction>>::grow_one+0x54>
  823d40:	mov    0x8(%rsp),%rax
  823d45:	mov    %rax,0x8(%rbx)
  823d49:	mov    %r14,(%rbx)
  823d4c:	add    $0x18,%rsp
  823d50:	pop    %rbx
  823d51:	pop    %r14
  823d53:	ret
  823d54:	mov    0x8(%rsp),%rdi
  823d59:	mov    0x10(%rsp),%rsi
  823d5e:	call   *0x65bb3c(%rip)        # e7f8a0 <_DYNAMIC+0x288>

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}> bytes=1602 frame=136

/tmp/gpui-descending-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000824760 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>>:
  824760:	push   %rbp
  824761:	push   %r15
  824763:	push   %r14
  824765:	push   %r13
  824767:	push   %r12
  824769:	push   %rbx
  82476a:	sub    $0x58,%rsp
  82476e:	mov    %ecx,%ebp
  824770:	mov    %rdx,0x8(%rsp)
  824775:	mov    0x18(%rdi),%rax
  824779:	add    %rax,%rsi
  82477c:	jb     824891 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x131>
  824782:	mov    %rdi,%rbx
  824785:	mov    0x8(%rdi),%r15
  824789:	lea    0x1(%r15),%rdx
  82478d:	mov    %rdx,%rdi
  824790:	shr    $0x3,%rdi
  824794:	mov    %rdx,%rcx
  824797:	and    $0xfffffffffffffff8,%rcx
  82479b:	sub    %rdi,%rcx
  82479e:	cmp    $0x8,%r15
  8247a2:	cmovb  %r15,%rcx
  8247a6:	mov    %rcx,%rdi
  8247a9:	shr    $1,%rdi
  8247ac:	cmp    %rdi,%rsi
  8247af:	jbe    8247e0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x80>
  8247b1:	inc    %rcx
  8247b4:	cmp    %rsi,%rcx
  8247b7:	cmovbe %rsi,%rcx
  8247bb:	cmp    $0xf,%rcx
  8247bf:	mov    %rbx,(%rsp)
  8247c3:	jae    824811 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0xb1>
  8247c5:	mov    %ecx,%eax
  8247c7:	and    $0x8,%eax
  8247ca:	add    $0x8,%rax
  8247ce:	cmp    $0x4,%rcx
  8247d2:	mov    $0x4,%ebx
  8247d7:	cmovae %rax,%rbx
  8247db:	jmp    824869 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x109>
  8247e0:	test   %rdx,%rdx
  8247e3:	je     824a6a <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x30a>
  8247e9:	mov    (%rbx),%rsi
  8247ec:	mov    %rdx,%rax
  8247ef:	shr    $0x4,%rax
  8247f3:	mov    %edx,%ecx
  8247f5:	and    $0xf,%ecx
  8247f8:	cmp    $0x1,%rcx
  8247fc:	sbb    $0xffffffffffffffff,%rax
  824800:	cmp    $0x1,%rax
  824804:	jne    824a71 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x311>
  82480a:	xor    %ecx,%ecx
  82480c:	jmp    824ac4 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x364>
  824811:	movabs $0x1ffffffffffffffe,%rax
  82481b:	inc    %rax
  82481e:	cmp    %rax,%rcx
  824821:	ja     824891 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x131>
  824823:	shl    $0x3,%rcx
  824827:	movabs $0x2492492492492493,%rdx
  824831:	mov    %rcx,%rax
  824834:	mul    %rdx
  824837:	sub    %rdx,%rcx
  82483a:	shr    $1,%rcx
  82483d:	add    %rdx,%rcx
  824840:	shr    $0x2,%rcx
  824844:	dec    %rcx
  824847:	bsr    %rcx,%rcx
  82484b:	not    %ecx
  82484d:	mov    $0xffffffffffffffff,%rbx
  824854:	shr    %cl,%rbx
  824857:	movabs $0x7fffffffffffffe,%rax
  824861:	cmp    %rax,%rbx
  824864:	ja     824891 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x131>
  824866:	inc    %rbx
  824869:	mov    %rbx,%r14
  82486c:	shl    $0x5,%r14
  824870:	lea    0x10(%rbx),%r12
  824874:	mov    %r12,%r13
  824877:	add    %r14,%r13
  82487a:	setb   %al
  82487d:	movabs $0x7ffffffffffffff0,%rcx
  824887:	cmp    %rcx,%r13
  82488a:	seta   %cl
  82488d:	or     %al,%cl
  82488f:	je     8248a0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x140>
  824891:	movzbl %bpl,%edi
  824895:	call   *0x65b49d(%rip)        # e7fd38 <_DYNAMIC+0x720>
  82489b:	jmp    824ce5 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x585>
  8248a0:	call   *0x65b002(%rip)        # e7f8a8 <_DYNAMIC+0x290>
  8248a6:	mov    $0x10,%esi
  8248ab:	mov    %r13,%rdi
  8248ae:	call   *0x65affc(%rip)        # e7f8b0 <_DYNAMIC+0x298>
  8248b4:	test   %rax,%rax
  8248b7:	je     824d03 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x5a3>
  8248bd:	mov    %rax,%r15
  8248c0:	mov    (%rsp),%rcx
  8248c4:	lea    0x20(%rcx),%r13
  8248c8:	add    %r14,%r15
  8248cb:	lea    -0x1(%rbx),%r14
  8248cf:	mov    %rbx,%rax
  8248d2:	shr    $0x3,%rax
  8248d6:	mov    %rbx,%rbp
  8248d9:	and    $0xfffffffffffffff8,%rbp
  8248dd:	sub    %rax,%rbp
  8248e0:	cmp    $0x9,%rbx
  8248e4:	mov    %rcx,%rbx
  8248e7:	cmovb  %r14,%rbp
  8248eb:	mov    %r15,%rdi
  8248ee:	mov    $0xff,%esi
  8248f3:	mov    %r12,%rdx
  8248f6:	call   *0x65b444(%rip)        # e7fd40 <memset@GLIBC_2.2.5>
  8248fc:	mov    %r14,%rdi
  8248ff:	mov    %r13,0x20(%rsp)
  824904:	movq   $0x20,0x28(%rsp)
  82490d:	movq   $0x10,0x30(%rsp)
  824916:	mov    %r15,0x38(%rsp)
  82491b:	mov    %r14,0x40(%rsp)
  824920:	mov    %rbp,0x48(%rsp)
  824925:	movq   $0x0,0x50(%rsp)
  82492e:	mov    0x18(%rbx),%r12
  824932:	test   %r12,%r12
  824935:	je     824d17 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x5b7>
  82493b:	mov    %rbp,0x10(%rsp)
  824940:	mov    (%rbx),%rsi
  824943:	movdqa (%rsi),%xmm0
  824947:	pmovmskb %xmm0,%r13d
  82494c:	not    %r13d
  82494f:	xor    %ebp,%ebp
  824951:	mov    %rsi,%r14
  824954:	mov    %rdi,0x18(%rsp)
  824959:	nopl   0x0(%rax)
  824960:	test   %r13w,%r13w
  824964:	jne    82498f <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x22f>
  824966:	cs nopw 0x0(%rax,%rax,1)
  824970:	movdqa 0x10(%r14),%xmm0
  824976:	add    $0x10,%r14
  82497a:	pmovmskb %xmm0,%r13d
  82497f:	xor    $0xffff,%r13d
  824986:	add    $0x10,%rbp
  82498a:	test   %r13d,%r13d
  82498d:	je     824970 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x210>
  82498f:	tzcnt  %r13d,%ebx
  824994:	add    %rbp,%rbx
  824997:	mov    %rbx,%rax
  82499a:	shl    $0x5,%rax
  82499e:	sub    %rax,%rsi
  8249a1:	add    $0xffffffffffffffe0,%rsi
  8249a5:	mov    0x8(%rsp),%rdi
  8249aa:	call   821dd0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  8249af:	mov    %rax,%rdx
  8249b2:	mov    0x18(%rsp),%rdi
  8249b7:	and    %rdi,%rdx
  8249ba:	movdqu (%r15,%rdx,1),%xmm0
  8249c0:	pmovmskb %xmm0,%ecx
  8249c4:	test   %ecx,%ecx
  8249c6:	je     824a35 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x2d5>
  8249c8:	tzcnt  %ecx,%ecx
  8249cc:	add    %rdx,%rcx
  8249cf:	and    %rdi,%rcx
  8249d2:	cmpb   $0x0,(%r15,%rcx,1)
  8249d7:	jns    824a58 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x2f8>
  8249d9:	lea    -0x1(%r13),%edx
  8249dd:	and    %r13d,%edx
  8249e0:	dec    %r12
  8249e3:	shr    $0x39,%rax
  8249e7:	lea    -0x10(%rcx),%rsi
  8249eb:	and    %rdi,%rsi
  8249ee:	mov    %al,(%r15,%rcx,1)
  8249f2:	mov    %al,0x10(%r15,%rsi,1)
  8249f7:	mov    (%rsp),%rax
  8249fb:	mov    (%rax),%rsi
  8249fe:	not    %rbx
  824a01:	shl    $0x5,%rbx
  824a05:	not    %rcx
  824a08:	shl    $0x5,%rcx
  824a0c:	movdqu (%rsi,%rbx,1),%xmm0
  824a11:	movdqu 0x10(%rsi,%rbx,1),%xmm1
  824a17:	movdqu %xmm1,0x10(%r15,%rcx,1)
  824a1e:	movdqu %xmm0,(%r15,%rcx,1)
  824a24:	mov    %edx,%r13d
  824a27:	test   %r12,%r12
  824a2a:	jne    824960 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x200>
  824a30:	jmp    824cf4 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x594>
  824a35:	mov    $0x10,%esi
  824a3a:	add    %rsi,%rdx
  824a3d:	and    %rdi,%rdx
  824a40:	movdqu (%r15,%rdx,1),%xmm0
  824a46:	pmovmskb %xmm0,%ecx
  824a4a:	add    $0x10,%rsi
  824a4e:	test   %ecx,%ecx
  824a50:	jne    8249c8 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x268>
  824a56:	jmp    824a3a <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x2da>
  824a58:	movdqa (%r15),%xmm0
  824a5d:	pmovmskb %xmm0,%ecx
  824a61:	tzcnt  %ecx,%ecx
  824a65:	jmp    8249d9 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x279>
  824a6a:	xor    %ecx,%ecx
  824a6c:	jmp    824cd7 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x577>
  824a71:	movabs $0x1ffffffffffffffe,%rdi
  824a7b:	and    %rax,%rdi
  824a7e:	xor    %ecx,%ecx
  824a80:	movdqa -0x776ee8(%rip),%xmm0        # adba0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x830>
  824a88:	nopl   0x0(%rax,%rax,1)
  824a90:	pxor   %xmm1,%xmm1
  824a94:	pcmpgtb (%rsi,%rcx,1),%xmm1
  824a99:	por    %xmm0,%xmm1
  824a9d:	movdqa %xmm1,(%rsi,%rcx,1)
  824aa2:	pxor   %xmm1,%xmm1
  824aa6:	pcmpgtb 0x10(%rsi,%rcx,1),%xmm1
  824aac:	por    %xmm0,%xmm1
  824ab0:	movdqa %xmm1,0x10(%rsi,%rcx,1)
  824ab6:	add    $0x20,%rcx
  824aba:	add    $0xfffffffffffffffe,%rdi
  824abe:	jne    824a90 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x330>
  824ac0:	test   $0x1,%al
  824ac2:	je     824ada <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x37a>
  824ac4:	pxor   %xmm0,%xmm0
  824ac8:	pcmpgtb (%rsi,%rcx,1),%xmm0
  824acd:	por    -0x776f35(%rip),%xmm0        # adba0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x830>
  824ad5:	movdqa %xmm0,(%rsi,%rcx,1)
  824ada:	cmp    $0x10,%rdx
  824ade:	jb     824d68 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x608>
  824ae4:	mov    %rdx,%rdi
  824ae7:	mov    $0x10,%edx
  824aec:	add    %rsi,%rdi
  824aef:	call   *0x65b253(%rip)        # e7fd48 <memmove@GLIBC_2.2.5>
  824af5:	movq   $0x0,0x28(%rsp)
  824afe:	movq   $0x20,0x30(%rsp)
  824b07:	mov    %rbx,0x20(%rsp)
  824b0c:	xor    %r12d,%r12d
  824b0f:	xor    %r13d,%r13d
  824b12:	jmp    824c61 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x501>
  824b17:	nopw   0x0(%rax,%rax,1)
  824b20:	lea    (%rax,%rbp,1),%rsi
  824b24:	add    $0xffffffffffffffe0,%rsi
  824b28:	mov    0x8(%rsp),%rdi
  824b2d:	call   821dd0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  824b32:	mov    (%rbx),%rcx
  824b35:	mov    0x8(%rbx),%rdx
  824b39:	mov    %rdx,%rsi
  824b3c:	and    %rax,%rsi
  824b3f:	movdqu (%rcx,%rsi,1),%xmm0
  824b44:	pmovmskb %xmm0,%edi
  824b48:	mov    %rsi,%r8
  824b4b:	test   %edi,%edi
  824b4d:	je     824bf9 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x499>
  824b53:	tzcnt  %edi,%edi
  824b57:	add    %r8,%rdi
  824b5a:	and    %rdx,%rdi
  824b5d:	cmpb   $0x0,(%rcx,%rdi,1)
  824b61:	jns    824c20 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4c0>
  824b67:	mov    %r12,%r8
  824b6a:	sub    %rsi,%r8
  824b6d:	mov    %rdi,%r9
  824b70:	sub    %rsi,%r9
  824b73:	xor    %r8,%r9
  824b76:	and    %rdx,%r9
  824b79:	cmp    $0x10,%r9
  824b7d:	jb     824c40 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4e0>
  824b83:	mov    %rdi,%rsi
  824b86:	not    %rsi
  824b89:	shl    $0x5,%rsi
  824b8d:	add    %rcx,%rsi
  824b90:	movzbl (%rcx,%rdi,1),%r8d
  824b95:	shr    $0x39,%rax
  824b99:	lea    -0x10(%rdi),%r9
  824b9d:	and    %rdx,%r9
  824ba0:	mov    %al,(%rcx,%rdi,1)
  824ba3:	mov    (%rbx),%rcx
  824ba6:	mov    %al,0x10(%rcx,%r9,1)
  824bab:	cmp    $0xff,%r8b
  824baf:	je     824c86 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x526>
  824bb5:	mov    (%r14),%rax
  824bb8:	mov    (%rsi),%rcx
  824bbb:	mov    %rcx,(%r14)
  824bbe:	mov    %rax,(%rsi)
  824bc1:	mov    0x8(%r14),%rax
  824bc5:	mov    0x8(%rsi),%rcx
  824bc9:	mov    %rcx,0x8(%r14)
  824bcd:	mov    %rax,0x8(%rsi)
  824bd1:	mov    0x10(%r14),%rax
  824bd5:	mov    0x10(%rsi),%rcx
  824bd9:	mov    %rcx,0x10(%r14)
  824bdd:	mov    %rax,0x10(%rsi)
  824be1:	mov    0x18(%r14),%rax
  824be5:	mov    0x18(%rsi),%rcx
  824be9:	mov    %rcx,0x18(%r14)
  824bed:	mov    %rax,0x18(%rsi)
  824bf1:	mov    (%rbx),%rax
  824bf4:	jmp    824b20 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x3c0>
  824bf9:	mov    $0x10,%r9d
  824bff:	mov    %rsi,%r8
  824c02:	add    %r9,%r8
  824c05:	and    %rdx,%r8
  824c08:	movdqu (%rcx,%r8,1),%xmm0
  824c0e:	pmovmskb %xmm0,%edi
  824c12:	add    $0x10,%r9
  824c16:	test   %edi,%edi
  824c18:	jne    824b53 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x3f3>
  824c1e:	jmp    824c02 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4a2>
  824c20:	movdqa (%rcx),%xmm0
  824c24:	pmovmskb %xmm0,%edi
  824c28:	tzcnt  %edi,%edi
  824c2c:	jmp    824b67 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x407>
  824c31:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  824c40:	shr    $0x39,%rax
  824c44:	lea    -0x10(%r12),%rsi
  824c49:	and    %rsi,%rdx
  824c4c:	mov    %al,(%rcx,%r12,1)
  824c50:	mov    (%rbx),%rcx
  824c53:	mov    %al,0x10(%rcx,%rdx,1)
  824c57:	cmp    %r15,%r12
  824c5a:	lea    0x1(%r12),%r12
  824c5f:	je     824cb5 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x555>
  824c61:	mov    (%rbx),%rax
  824c64:	cmp    (%rax,%r12,1),%r13b
  824c68:	jno    824c57 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4f7>
  824c6a:	mov    %r12,%r14
  824c6d:	not    %r14
  824c70:	shl    $0x5,%r14
  824c74:	add    %rax,%r14
  824c77:	mov    %r12,%rbp
  824c7a:	neg    %rbp
  824c7d:	shl    $0x5,%rbp
  824c81:	jmp    824b20 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x3c0>
  824c86:	lea    -0x10(%r12),%rax
  824c8b:	and    0x8(%rbx),%rax
  824c8f:	mov    (%rbx),%rcx
  824c92:	movb   $0xff,(%rcx,%r12,1)
  824c97:	mov    (%rbx),%rcx
  824c9a:	movb   $0xff,0x10(%rcx,%rax,1)
  824c9f:	movdqu (%r14),%xmm0
  824ca4:	movdqu 0x10(%r14),%xmm1
  824caa:	movdqu %xmm1,0x10(%rsi)
  824caf:	movdqu %xmm0,(%rsi)
  824cb3:	jmp    824c57 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4f7>
  824cb5:	mov    0x8(%rbx),%rdx
  824cb9:	mov    0x18(%rbx),%rax
  824cbd:	lea    0x1(%rdx),%rcx
  824cc1:	mov    %rcx,%rsi
  824cc4:	shr    $0x3,%rsi
  824cc8:	and    $0xfffffffffffffff8,%rcx
  824ccc:	sub    %rsi,%rcx
  824ccf:	cmp    $0x8,%rdx
  824cd3:	cmovb  %rdx,%rcx
  824cd7:	sub    %rax,%rcx
  824cda:	mov    %rcx,0x10(%rbx)
  824cde:	mov    $0xffffffffffffffff,%rax
  824ce5:	add    $0x58,%rsp
  824ce9:	pop    %rbx
  824cea:	pop    %r12
  824cec:	pop    %r13
  824cee:	pop    %r14
  824cf0:	pop    %r15
  824cf2:	pop    %rbp
  824cf3:	ret
  824cf4:	mov    (%rsp),%rbx
  824cf8:	mov    0x18(%rbx),%rcx
  824cfc:	mov    0x10(%rsp),%rbp
  824d01:	jmp    824d1c <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x5bc>
  824d03:	movzbl %bpl,%edi
  824d07:	mov    $0x10,%esi
  824d0c:	mov    %r13,%rdx
  824d0f:	call   *0x65b03b(%rip)        # e7fd50 <_DYNAMIC+0x738>
  824d15:	jmp    824ce5 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x585>
  824d17:	mov    (%rbx),%rsi
  824d1a:	xor    %ecx,%ecx
  824d1c:	sub    %rcx,%rbp
  824d1f:	mov    %r15,(%rbx)
  824d22:	mov    0x8(%rbx),%rax
  824d26:	mov    %rdi,0x8(%rbx)
  824d2a:	mov    %rbp,0x10(%rbx)
  824d2e:	mov    %rcx,0x18(%rbx)
  824d32:	test   %rax,%rax
  824d35:	je     824cde <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x57e>
  824d37:	mov    %rax,%rcx
  824d3a:	shl    $0x5,%rcx
  824d3e:	add    $0x2f,%rcx
  824d42:	and    $0xffffffffffffffe0,%rcx
  824d46:	add    %rcx,%rax
  824d49:	add    $0x11,%rax
  824d4d:	je     824cde <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x57e>
  824d4f:	sub    %rcx,%rsi
  824d52:	mov    $0x10,%edx
  824d57:	mov    %rsi,%rdi
  824d5a:	mov    %rax,%rsi
  824d5d:	call   *0x65aafd(%rip)        # e7f860 <_DYNAMIC+0x248>
  824d63:	jmp    824cde <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x57e>
  824d68:	mov    $0x10,%edi
  824d6d:	jmp    824aec <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x38c>
  824d72:	mov    %rax,%rbx
  824d75:	lea    0x20(%rsp),%rdi
  824d7a:	call   825350 <core::ptr::drop_glue::<hashbrown::scopeguard::ScopeGuard<hashbrown::raw::RawTableInner, <hashbrown::raw::RawTableInner>::prepare_resize<alloc::alloc::Global>::{closure#0}>>>
  824d7f:	mov    %rbx,%rdi
  824d82:	call   e2c400 <_Unwind_Resume@plt>
  824d87:	mov    %rax,%rbx
  824d8a:	lea    0x20(%rsp),%rdi
  824d8f:	call   825390 <core::ptr::drop_glue::<hashbrown::scopeguard::ScopeGuard<&mut hashbrown::raw::RawTableInner, <hashbrown::raw::RawTableInner>::rehash_in_place::{closure#0}>>>
  824d94:	mov    %rbx,%rdi
  824d97:	call   e2c400 <_Unwind_Resume@plt>
  824d9c:	call   *0x65aac6(%rip)        # e7f868 <_DYNAMIC+0x250>

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}> bytes=1437 frame=104

/tmp/gpui-descending-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000824db0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>>:
  824db0:	push   %rbp
  824db1:	push   %r15
  824db3:	push   %r14
  824db5:	push   %r13
  824db7:	push   %r12
  824db9:	push   %rbx
  824dba:	sub    $0x38,%rsp
  824dbe:	mov    %ecx,%r15d
  824dc1:	mov    %rdx,0x20(%rsp)
  824dc6:	mov    %rdi,%rbp
  824dc9:	mov    0x18(%rdi),%rdi
  824dcd:	add    %rdi,%rsi
  824dd0:	jb     824ee8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x138>
  824dd6:	mov    0x8(%rbp),%rbx
  824dda:	lea    0x1(%rbx),%rdx
  824dde:	mov    %rdx,%rax
  824de1:	shr    $0x3,%rax
  824de5:	mov    %rdx,%rcx
  824de8:	and    $0xfffffffffffffff8,%rcx
  824dec:	sub    %rax,%rcx
  824def:	cmp    $0x8,%rbx
  824df3:	cmovb  %rbx,%rcx
  824df7:	mov    %rcx,%rax
  824dfa:	shr    $1,%rax
  824dfd:	cmp    %rax,%rsi
  824e00:	jbe    824e36 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x86>
  824e02:	inc    %rcx
  824e05:	cmp    %rsi,%rcx
  824e08:	cmovbe %rsi,%rcx
  824e0c:	cmp    $0xf,%rcx
  824e10:	mov    %rbp,(%rsp)
  824e14:	mov    %rbx,0x30(%rsp)
  824e19:	jae    824e68 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0xb8>
  824e1b:	mov    %ecx,%eax
  824e1d:	and    $0x8,%eax
  824e20:	add    $0x8,%rax
  824e24:	cmp    $0x4,%rcx
  824e28:	mov    $0x4,%ebx
  824e2d:	cmovae %rax,%rbx
  824e31:	jmp    824ec0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x110>
  824e36:	test   %rdx,%rdx
  824e39:	je     82507e <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2ce>
  824e3f:	mov    0x0(%rbp),%r12
  824e43:	mov    %rdx,%rax
  824e46:	shr    $0x4,%rax
  824e4a:	mov    %edx,%ecx
  824e4c:	and    $0xf,%ecx
  824e4f:	cmp    $0x1,%rcx
  824e53:	sbb    $0xffffffffffffffff,%rax
  824e57:	cmp    $0x1,%rax
  824e5b:	jne    825085 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2d5>
  824e61:	xor    %ecx,%ecx
  824e63:	jmp    8250d8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x328>
  824e68:	movabs $0x1ffffffffffffffe,%rax
  824e72:	inc    %rax
  824e75:	cmp    %rax,%rcx
  824e78:	ja     824ee8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x138>
  824e7a:	shl    $0x3,%rcx
  824e7e:	movabs $0x2492492492492493,%rdx
  824e88:	mov    %rcx,%rax
  824e8b:	mul    %rdx
  824e8e:	sub    %rdx,%rcx
  824e91:	shr    $1,%rcx
  824e94:	add    %rdx,%rcx
  824e97:	shr    $0x2,%rcx
  824e9b:	dec    %rcx
  824e9e:	bsr    %rcx,%rcx
  824ea2:	not    %ecx
  824ea4:	mov    $0xffffffffffffffff,%rbx
  824eab:	shr    %cl,%rbx
  824eae:	movabs $0xffffffffffffffe,%rax
  824eb8:	cmp    %rax,%rbx
  824ebb:	ja     824ee8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x138>
  824ebd:	inc    %rbx
  824ec0:	mov    %rbx,%r14
  824ec3:	shl    $0x4,%r14
  824ec7:	lea    0x10(%rbx),%rbp
  824ecb:	mov    %rbp,%r13
  824ece:	add    %r14,%r13
  824ed1:	setb   %al
  824ed4:	movabs $0x7ffffffffffffff0,%rcx
  824ede:	cmp    %rcx,%r13
  824ee1:	seta   %cl
  824ee4:	or     %al,%cl
  824ee6:	je     824ef7 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x147>
  824ee8:	movzbl %r15b,%edi
  824eec:	call   *0x65ae46(%rip)        # e7fd38 <_DYNAMIC+0x720>
  824ef2:	jmp    8252b8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  824ef7:	mov    %rdi,0x8(%rsp)
  824efc:	call   *0x65a9a6(%rip)        # e7f8a8 <_DYNAMIC+0x290>
  824f02:	mov    $0x10,%esi
  824f07:	mov    %r13,%rdi
  824f0a:	call   *0x65a9a0(%rip)        # e7f8b0 <_DYNAMIC+0x298>
  824f10:	test   %rax,%rax
  824f13:	je     8252d2 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x522>
  824f19:	mov    %rax,%rdi
  824f1c:	add    %r14,%rdi
  824f1f:	lea    -0x1(%rbx),%rcx
  824f23:	mov    %rbx,%rax
  824f26:	shr    $0x3,%rax
  824f2a:	mov    %rbx,%r14
  824f2d:	and    $0xfffffffffffffff8,%r14
  824f31:	sub    %rax,%r14
  824f34:	cmp    $0x9,%rbx
  824f38:	mov    %rcx,0x10(%rsp)
  824f3d:	cmovb  %rcx,%r14
  824f41:	mov    %rdi,0x18(%rsp)
  824f46:	mov    $0xff,%esi
  824f4b:	mov    %rbp,%rdx
  824f4e:	call   *0x65adec(%rip)        # e7fd40 <memset@GLIBC_2.2.5>
  824f54:	mov    0x8(%rsp),%rbx
  824f59:	test   %rbx,%rbx
  824f5c:	je     8252e6 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x536>
  824f62:	mov    %r14,0x28(%rsp)
  824f67:	mov    (%rsp),%rax
  824f6b:	mov    (%rax),%rdi
  824f6e:	movdqa (%rdi),%xmm0
  824f72:	pmovmskb %xmm0,%r14d
  824f77:	not    %r14d
  824f7a:	xor    %ebp,%ebp
  824f7c:	mov    %rdi,%r13
  824f7f:	nop
  824f80:	test   %r14w,%r14w
  824f84:	jne    824faf <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x1ff>
  824f86:	cs nopw 0x0(%rax,%rax,1)
  824f90:	movdqa 0x10(%r13),%xmm0
  824f96:	add    $0x10,%r13
  824f9a:	pmovmskb %xmm0,%r14d
  824f9f:	xor    $0xffff,%r14d
  824fa6:	add    $0x10,%rbp
  824faa:	test   %r14d,%r14d
  824fad:	je     824f90 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x1e0>
  824faf:	tzcnt  %r14d,%r15d
  824fb4:	add    %rbp,%r15
  824fb7:	mov    %r15,%rax
  824fba:	shl    $0x4,%rax
  824fbe:	mov    %rdi,%r12
  824fc1:	mov    %rdi,%rsi
  824fc4:	sub    %rax,%rsi
  824fc7:	add    $0xfffffffffffffff0,%rsi
  824fcb:	mov    0x20(%rsp),%rdi
  824fd0:	call   821f70 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  824fd5:	mov    %rax,%rcx
  824fd8:	mov    0x10(%rsp),%r9
  824fdd:	and    %r9,%rcx
  824fe0:	mov    0x18(%rsp),%r8
  824fe5:	movdqu (%r8,%rcx,1),%xmm0
  824feb:	pmovmskb %xmm0,%edx
  824fef:	test   %edx,%edx
  824ff1:	je     825050 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2a0>
  824ff3:	tzcnt  %edx,%edx
  824ff7:	add    %rcx,%rdx
  824ffa:	and    %r9,%rdx
  824ffd:	cmpb   $0x0,(%r8,%rdx,1)
  825002:	mov    %r12,%rdi
  825005:	jns    82506f <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2bf>
  825007:	lea    -0x1(%r14),%ecx
  82500b:	and    %r14d,%ecx
  82500e:	dec    %rbx
  825011:	shr    $0x39,%rax
  825015:	lea    -0x10(%rdx),%rsi
  825019:	and    %r9,%rsi
  82501c:	mov    %al,(%r8,%rdx,1)
  825020:	mov    %al,0x10(%r8,%rsi,1)
  825025:	not    %r15
  825028:	shl    $0x4,%r15
  82502c:	not    %rdx
  82502f:	shl    $0x4,%rdx
  825033:	movdqu (%rdi,%r15,1),%xmm0
  825039:	movdqu %xmm0,(%r8,%rdx,1)
  82503f:	mov    %ecx,%r14d
  825042:	test   %rbx,%rbx
  825045:	jne    824f80 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x1d0>
  82504b:	jmp    8252c7 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x517>
  825050:	mov    $0x10,%esi
  825055:	add    %rsi,%rcx
  825058:	and    %r9,%rcx
  82505b:	movdqu (%r8,%rcx,1),%xmm0
  825061:	pmovmskb %xmm0,%edx
  825065:	add    $0x10,%rsi
  825069:	test   %edx,%edx
  82506b:	jne    824ff3 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x243>
  82506d:	jmp    825055 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2a5>
  82506f:	movdqa (%r8),%xmm0
  825074:	pmovmskb %xmm0,%ecx
  825078:	tzcnt  %ecx,%edx
  82507c:	jmp    825007 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x257>
  82507e:	xor    %eax,%eax
  825080:	jmp    8252aa <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x4fa>
  825085:	movabs $0x1ffffffffffffffe,%rsi
  82508f:	and    %rax,%rsi
  825092:	xor    %ecx,%ecx
  825094:	movdqa -0x7774fc(%rip),%xmm0        # adba0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x830>
  82509c:	nopl   0x0(%rax)
  8250a0:	pxor   %xmm1,%xmm1
  8250a4:	pcmpgtb (%r12,%rcx,1),%xmm1
  8250aa:	por    %xmm0,%xmm1
  8250ae:	movdqa %xmm1,(%r12,%rcx,1)
  8250b4:	pxor   %xmm1,%xmm1
  8250b8:	pcmpgtb 0x10(%r12,%rcx,1),%xmm1
  8250bf:	por    %xmm0,%xmm1
  8250c3:	movdqa %xmm1,0x10(%r12,%rcx,1)
  8250ca:	add    $0x20,%rcx
  8250ce:	add    $0xfffffffffffffffe,%rsi
  8250d2:	jne    8250a0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2f0>
  8250d4:	test   $0x1,%al
  8250d6:	je     8250f0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x340>
  8250d8:	pxor   %xmm0,%xmm0
  8250dc:	pcmpgtb (%r12,%rcx,1),%xmm0
  8250e2:	por    -0x77754a(%rip),%xmm0        # adba0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x830>
  8250ea:	movdqa %xmm0,(%r12,%rcx,1)
  8250f0:	cmp    $0x10,%rdx
  8250f4:	jb     825343 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x593>
  8250fa:	mov    %rdx,%rdi
  8250fd:	mov    $0x10,%edx
  825102:	add    %r12,%rdi
  825105:	mov    %r12,%rsi
  825108:	call   *0x65ac3a(%rip)        # e7fd48 <memmove@GLIBC_2.2.5>
  82510e:	xor    %r13d,%r13d
  825111:	xor    %eax,%eax
  825113:	jmp    825246 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x496>
  825118:	nopl   0x0(%rax,%rax,1)
  825120:	lea    (%r12,%r14,1),%rsi
  825124:	add    $0xfffffffffffffff0,%rsi
  825128:	mov    0x20(%rsp),%rdi
  82512d:	call   821f70 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  825132:	mov    0x8(%rbp),%rcx
  825136:	mov    %rcx,%rdx
  825139:	and    %rax,%rdx
  82513c:	movdqu (%r12,%rdx,1),%xmm0
  825142:	pmovmskb %xmm0,%esi
  825146:	mov    %rdx,%rdi
  825149:	test   %esi,%esi
  82514b:	je     8251db <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x42b>
  825151:	tzcnt  %esi,%esi
  825155:	add    %rdi,%rsi
  825158:	and    %rcx,%rsi
  82515b:	cmpb   $0x0,(%r12,%rsi,1)
  825160:	jns    825202 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x452>
  825166:	mov    %r13,%rdi
  825169:	sub    %rdx,%rdi
  82516c:	mov    %rsi,%r8
  82516f:	sub    %rdx,%r8
  825172:	xor    %rdi,%r8
  825175:	and    %rcx,%r8
  825178:	cmp    $0x10,%r8
  82517c:	jb     825220 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x470>
  825182:	mov    %rsi,%rdx
  825185:	not    %rdx
  825188:	shl    $0x4,%rdx
  82518c:	add    %r12,%rdx
  82518f:	movzbl (%r12,%rsi,1),%edi
  825194:	shr    $0x39,%rax
  825198:	lea    -0x10(%rsi),%r8
  82519c:	and    %rcx,%r8
  82519f:	mov    %al,(%r12,%rsi,1)
  8251a3:	mov    0x0(%rbp),%r12
  8251a7:	mov    %al,0x10(%r12,%r8,1)
  8251ac:	cmp    $0xff,%dil
  8251b0:	je     82526b <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x4bb>
  8251b6:	mov    (%rbx),%rax
  8251b9:	mov    (%rdx),%rcx
  8251bc:	mov    %rcx,(%rbx)
  8251bf:	mov    %rax,(%rdx)
  8251c2:	mov    0x8(%rbx),%rax
  8251c6:	mov    0x8(%rdx),%rcx
  8251ca:	mov    %rcx,0x8(%rbx)
  8251ce:	mov    %rax,0x8(%rdx)
  8251d2:	mov    0x0(%rbp),%r12
  8251d6:	jmp    825120 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x370>
  8251db:	mov    $0x10,%r8d
  8251e1:	mov    %rdx,%rdi
  8251e4:	add    %r8,%rdi
  8251e7:	and    %rcx,%rdi
  8251ea:	movdqu (%r12,%rdi,1),%xmm0
  8251f0:	pmovmskb %xmm0,%esi
  8251f4:	add    $0x10,%r8
  8251f8:	test   %esi,%esi
  8251fa:	jne    825151 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x3a1>
  825200:	jmp    8251e4 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x434>
  825202:	movdqa (%r12),%xmm0
  825208:	pmovmskb %xmm0,%esi
  82520c:	tzcnt  %esi,%esi
  825210:	jmp    825166 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x3b6>
  825215:	data16 cs nopw 0x0(%rax,%rax,1)
  825220:	shr    $0x39,%rax
  825224:	lea    -0x10(%r13),%rdx
  825228:	and    %rdx,%rcx
  82522b:	mov    %al,(%r12,%r13,1)
  82522f:	mov    0x0(%rbp),%r12
  825233:	mov    %al,0x10(%r12,%rcx,1)
  825238:	mov    %r15,%rbx
  82523b:	xor    %eax,%eax
  82523d:	cmp    %rbx,%r13
  825240:	lea    0x1(%r13),%r13
  825244:	je     825288 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x4d8>
  825246:	cmp    (%r12,%r13,1),%al
  82524a:	jno    82523d <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x48d>
  82524c:	mov    %rbx,%r15
  82524f:	mov    %r13,%rbx
  825252:	not    %rbx
  825255:	shl    $0x4,%rbx
  825259:	add    %r12,%rbx
  82525c:	mov    %r13,%r14
  82525f:	neg    %r14
  825262:	shl    $0x4,%r14
  825266:	jmp    825120 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x370>
  82526b:	lea    -0x10(%r13),%rax
  82526f:	and    0x8(%rbp),%rax
  825273:	movb   $0xff,(%r12,%r13,1)
  825278:	movb   $0xff,0x10(%r12,%rax,1)
  82527e:	movdqu (%rbx),%xmm0
  825282:	movdqu %xmm0,(%rdx)
  825286:	jmp    825238 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x488>
  825288:	mov    0x8(%rbp),%rcx
  82528c:	mov    0x18(%rbp),%rdi
  825290:	lea    0x1(%rcx),%rax
  825294:	mov    %rax,%rdx
  825297:	shr    $0x3,%rdx
  82529b:	and    $0xfffffffffffffff8,%rax
  82529f:	sub    %rdx,%rax
  8252a2:	cmp    $0x8,%rcx
  8252a6:	cmovb  %rcx,%rax
  8252aa:	sub    %rdi,%rax
  8252ad:	mov    %rax,0x10(%rbp)
  8252b1:	mov    $0xffffffffffffffff,%rax
  8252b8:	add    $0x38,%rsp
  8252bc:	pop    %rbx
  8252bd:	pop    %r12
  8252bf:	pop    %r13
  8252c1:	pop    %r14
  8252c3:	pop    %r15
  8252c5:	pop    %rbp
  8252c6:	ret
  8252c7:	mov    (%rsp),%rax
  8252cb:	mov    0x28(%rsp),%r14
  8252d0:	jmp    8252f7 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x547>
  8252d2:	movzbl %r15b,%edi
  8252d6:	mov    $0x10,%esi
  8252db:	mov    %r13,%rdx
  8252de:	call   *0x65aa6c(%rip)        # e7fd50 <_DYNAMIC+0x738>
  8252e4:	jmp    8252b8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  8252e6:	mov    (%rsp),%rax
  8252ea:	mov    (%rax),%rdi
  8252ed:	mov    0x18(%rsp),%r8
  8252f2:	mov    0x10(%rsp),%r9
  8252f7:	sub    0x8(%rsp),%r14
  8252fc:	mov    %r8,(%rax)
  8252ff:	mov    %r9,0x8(%rax)
  825303:	mov    %r14,0x10(%rax)
  825307:	mov    $0xffffffffffffffff,%rax
  82530e:	mov    0x30(%rsp),%rsi
  825313:	test   %rsi,%rsi
  825316:	je     8252b8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  825318:	mov    %rsi,%rcx
  82531b:	shl    $0x4,%rcx
  82531f:	add    $0x1f,%rcx
  825323:	and    $0xfffffffffffffff0,%rcx
  825327:	add    %rcx,%rsi
  82532a:	add    $0x11,%rsi
  82532e:	je     8252b8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  825330:	sub    %rcx,%rdi
  825333:	mov    $0x10,%edx
  825338:	call   *0x65a522(%rip)        # e7f860 <_DYNAMIC+0x248>
  82533e:	jmp    8252b1 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x501>
  825343:	mov    $0x10,%edi
  825348:	jmp    825102 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x352>

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop bytes=47 frame=0

/tmp/gpui-descending-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000825500 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>:
  825500:	mov    0x8(%rdi),%rsi
  825504:	test   %rsi,%rsi
  825507:	je     82552e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  825509:	mov    %rsi,%rax
  82550c:	shl    $0x5,%rax
  825510:	add    %rax,%rsi
  825513:	add    $0x31,%rsi
  825517:	je     82552e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  825519:	mov    (%rdi),%rdi
  82551c:	sub    %rax,%rdi
  82551f:	add    $0xffffffffffffffe0,%rdi
  825523:	mov    $0x10,%edx
  825528:	jmp    *0x65a332(%rip)        # e7f860 <_DYNAMIC+0x248>
  82552e:	ret

FUNCTION <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}> bytes=303 frame=24

/tmp/gpui-descending-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000825980 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>>:
  825980:	push   %r15
  825982:	push   %r14
  825984:	push   %rbx
  825985:	mov    (%rdx),%r9
  825988:	mov    0x8(%rdx),%r11
  82598c:	mov    0x10(%rdx),%rbx
  825990:	mov    0x18(%rdx),%r10
  825994:	mov    0x20(%rdx),%r8
  825998:	mov    0x28(%rdx),%rcx
  82599c:	test   $0x1,%r9b
  8259a0:	jne    825a3a <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xba>
  8259a6:	mov    %rbx,%rax
  8259a9:	jmp    8259cb <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x4b>
  8259ab:	nopl   0x0(%rax,%rax,1)
  8259b0:	lea    0x8(%rax),%rbx
  8259b4:	mov    %rbx,%r14
  8259b7:	add    $0x8,%rdi
  8259bb:	mov    (%rax),%r15
  8259be:	mov    %r14,%rax
  8259c1:	cmp    0x28(%r15),%rdx
  8259c5:	jne    825a8f <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  8259cb:	cmp    %rsi,%rdi
  8259ce:	je     825a68 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xe8>
  8259d4:	mov    (%rdi),%rdx
  8259d7:	test   %rax,%rax
  8259da:	je     8259e3 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x63>
  8259dc:	cmp    %r10,%rax
  8259df:	jne    8259b0 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x30>
  8259e1:	xor    %ebx,%ebx
  8259e3:	xor    %eax,%eax
  8259e5:	test   %r8,%r8
  8259e8:	je     825a91 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  8259ee:	cmp    %rcx,%r8
  8259f1:	je     825a91 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  8259f7:	mov    %r8,%rax
  8259fa:	add    $0x8,%r8
  8259fe:	xor    %r14d,%r14d
  825a01:	jmp    8259b7 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x37>
  825a03:	mov    (%r11),%rax
  825a06:	mov    0x8(%rax),%rbx
  825a0a:	mov    0x10(%rax),%rax
  825a0e:	lea    (%rbx,%rax,8),%r10
  825a12:	test   %rax,%rax
  825a15:	je     825a51 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xd1>
  825a17:	xor    %r11d,%r11d
  825a1a:	nopw   0x0(%rax,%rax,1)
  825a20:	mov    %r8,%rax
  825a23:	mov    %rbx,%r8
  825a26:	add    $0x8,%rbx
  825a2a:	add    $0x8,%rdi
  825a2e:	mov    (%r8),%r14
  825a31:	mov    %rax,%r8
  825a34:	cmp    0x28(%r14),%rdx
  825a38:	jne    825a8f <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  825a3a:	cmp    %rsi,%rdi
  825a3d:	je     825a68 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xe8>
  825a3f:	mov    (%rdi),%rdx
  825a42:	test   %rbx,%rbx
  825a45:	je     825a4c <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xcc>
  825a47:	cmp    %r10,%rbx
  825a4a:	jne    825a20 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xa0>
  825a4c:	test   %r11,%r11
  825a4f:	jne    825a03 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x83>
  825a51:	xor    %eax,%eax
  825a53:	test   %r8,%r8
  825a56:	je     825a91 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  825a58:	cmp    %rcx,%r8
  825a5b:	je     825a91 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  825a5d:	lea    0x8(%r8),%rax
  825a61:	xor    %ebx,%ebx
  825a63:	xor    %r11d,%r11d
  825a66:	jmp    825a2a <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xaa>
  825a68:	test   %rbx,%rbx
  825a6b:	sete   %dl
  825a6e:	cmp    %r10,%rbx
  825a71:	sete   %al
  825a74:	or     %dl,%al
  825a76:	test   $0x1,%r9b
  825a7a:	je     825a97 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x117>
  825a7c:	test   %al,%al
  825a7e:	je     825a8f <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  825a80:	test   %r11,%r11
  825a83:	je     825a9b <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x11b>
  825a85:	mov    (%r11),%rax
  825a88:	cmpq   $0x0,0x10(%rax)
  825a8d:	je     825a9b <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x11b>
  825a8f:	xor    %eax,%eax
  825a91:	pop    %rbx
  825a92:	pop    %r14
  825a94:	pop    %r15
  825a96:	ret
  825a97:	test   %al,%al
  825a99:	je     825a8f <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  825a9b:	test   %r8,%r8
  825a9e:	sete   %dl
  825aa1:	cmp    %rcx,%r8
  825aa4:	sete   %al
  825aa7:	or     %dl,%al
  825aa9:	pop    %rbx
  825aaa:	pop    %r14
  825aac:	pop    %r15
  825aae:	ret

FUNCTION gpui_gpu::renderer::slots::color_word bytes=57 frame=8

/tmp/gpui-descending-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000825ab0 <gpui_gpu::renderer::slots::color_word>:
  825ab0:	lea    -0x3(%rsi),%eax
  825ab3:	cmp    %rax,%rdi
  825ab6:	jbe    825acf <gpui_gpu::renderer::slots::color_word+0x1f>
  825ab8:	mov    %rdi,%rax
  825abb:	shr    $0x6,%rax
  825abf:	and    $0x3f,%edi
  825ac2:	cmp    $0x1,%rdi
  825ac6:	sbb    $0xffffffff,%eax
  825ac9:	add    %esi,%eax
  825acb:	add    $0xfffffffe,%eax
  825ace:	ret
  825acf:	push   %rax
  825ad0:	lea    -0x750af2(%rip),%rdi        # d4fe5 <anon.4f92784177f891c02fc0a44bfee03ec4.9.llvm.1533866460487341161>
  825ad7:	lea    0x60885a(%rip),%rdx        # e2e338 <anon.4f92784177f891c02fc0a44bfee03ec4.10.llvm.1533866460487341161>
  825ade:	mov    $0x1e,%esi
  825ae3:	call   *0x65a097(%rip)        # e7fb80 <_DYNAMIC+0x568>

FUNCTION gpui_gpu::renderer::slots::write_prefix bytes=517 frame=72

/tmp/gpui-descending-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000825af0 <gpui_gpu::renderer::slots::write_prefix>:
  825af0:	push   %rbp
  825af1:	push   %r15
  825af3:	push   %r14
  825af5:	push   %r13
  825af7:	push   %r12
  825af9:	push   %rbx
  825afa:	sub    $0x18,%rsp
  825afe:	test   %rdx,%rdx
  825b01:	je     825c9c <gpui_gpu::renderer::slots::write_prefix+0x1ac>
  825b07:	mov    %rdi,%rbx
  825b0a:	mov    %rdx,%rax
  825b0d:	shr    $0x6,%rax
  825b11:	xor    %ecx,%ecx
  825b13:	test   $0x3f,%dl
  825b16:	setne  %cl
  825b19:	lea    (%rax,%rcx,1),%rbp
  825b1d:	lea    (%rax,%rcx,1),%r8
  825b21:	inc    %r8
  825b24:	mov    0x10(%rdi),%r12
  825b28:	mov    %rbp,%r13
  825b2b:	sub    %r12,%r13
  825b2e:	jae    825b3c <gpui_gpu::renderer::slots::write_prefix+0x4c>
  825b30:	mov    0x8(%rbx),%rax
  825b34:	mov    %r8,%r14
  825b37:	jmp    825bdb <gpui_gpu::renderer::slots::write_prefix+0xeb>
  825b3c:	mov    %r8,%r15
  825b3f:	sub    %r12,%r15
  825b42:	mov    (%rbx),%rax
  825b45:	sub    %r12,%rax
  825b48:	mov    %r12,%r14
  825b4b:	cmp    %rax,%r15
  825b4e:	ja     825cab <gpui_gpu::renderer::slots::write_prefix+0x1bb>
  825b54:	mov    0x8(%rbx),%rax
  825b58:	mov    %r14,%rcx
  825b5b:	shl    $0x4,%rcx
  825b5f:	add    %rax,%rcx
  825b62:	cmp    $0x2,%r15
  825b66:	jb     825bd2 <gpui_gpu::renderer::slots::write_prefix+0xe2>
  825b68:	mov    %r13d,%edi
  825b6b:	and    $0x7,%edi
  825b6e:	sub    %rbp,%r12
  825b71:	cmp    $0xfffffffffffffff8,%r12
  825b75:	ja     825bae <gpui_gpu::renderer::slots::write_prefix+0xbe>
  825b77:	and    $0xfffffffffffffff8,%r13
  825b7b:	xorps  %xmm0,%xmm0
  825b7e:	xchg   %ax,%ax
  825b80:	movups %xmm0,(%rcx)
  825b83:	movups %xmm0,0x10(%rcx)
  825b87:	movups %xmm0,0x20(%rcx)
  825b8b:	movups %xmm0,0x30(%rcx)
  825b8f:	movups %xmm0,0x40(%rcx)
  825b93:	movups %xmm0,0x50(%rcx)
  825b97:	movups %xmm0,0x60(%rcx)
  825b9b:	movups %xmm0,0x70(%rcx)
  825b9f:	sub    $0xffffffffffffff80,%rcx
  825ba3:	add    $0xfffffffffffffff8,%r13
  825ba7:	jne    825b80 <gpui_gpu::renderer::slots::write_prefix+0x90>
  825ba9:	test   %rdi,%rdi
  825bac:	je     825bcc <gpui_gpu::renderer::slots::write_prefix+0xdc>
  825bae:	xorps  %xmm0,%xmm0
  825bb1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  825bc0:	movups %xmm0,(%rcx)
  825bc3:	add    $0x10,%rcx
  825bc7:	dec    %rdi
  825bca:	jne    825bc0 <gpui_gpu::renderer::slots::write_prefix+0xd0>
  825bcc:	add    %r15,%r14
  825bcf:	dec    %r14
  825bd2:	xorps  %xmm0,%xmm0
  825bd5:	movups %xmm0,(%rcx)
  825bd8:	inc    %r14
  825bdb:	mov    %r14,0x10(%rbx)
  825bdf:	mov    %edx,(%rax)
  825be1:	mov    %ebp,0x4(%rax)
  825be4:	mov    %r8d,0x8(%rax)
  825be8:	movl   $0x0,0xc(%rax)
  825bef:	mov    %rsi,%rdi
  825bf2:	call   *0x659fc8(%rip)        # e7fbc0 <_DYNAMIC+0x5a8>
  825bf8:	cmp    %rdx,%rax
  825bfb:	je     825c9c <gpui_gpu::renderer::slots::write_prefix+0x1ac>
  825c01:	mov    %rax,%r15
  825c04:	mov    %rdx,%r12
  825c07:	xor    %r13d,%r13d
  825c0a:	xor    %ebp,%ebp
  825c0c:	jmp    825c36 <gpui_gpu::renderer::slots::write_prefix+0x146>
  825c0e:	xchg   %ax,%ax
  825c10:	mov    0x8(%rbx),%rax
  825c14:	mov    %r14,%rcx
  825c17:	shl    $0x4,%rcx
  825c1b:	movups %xmm0,(%rax,%rcx,1)
  825c1f:	inc    %r14
  825c22:	mov    %r14,0x10(%rbx)
  825c26:	add    $0x2,%r13d
  825c2a:	add    $0x18,%r15
  825c2e:	inc    %rbp
  825c31:	cmp    %r12,%r15
  825c34:	je     825c9c <gpui_gpu::renderer::slots::write_prefix+0x1ac>
  825c36:	mov    %rbp,%rdi
  825c39:	shr    $0x6,%rdi
  825c3d:	inc    %rdi
  825c40:	cmp    %r14,%rdi
  825c43:	jae    825ce5 <gpui_gpu::renderer::slots::write_prefix+0x1f5>
  825c49:	movups (%r15),%xmm0
  825c4d:	movzwl 0x12(%r15),%eax
  825c52:	movzwl 0x10(%r15),%edx
  825c57:	shr    $0xe,%eax
  825c5a:	and    $0x2,%eax
  825c5d:	shr    $0xf,%edx
  825c60:	or     %eax,%edx
  825c62:	mov    %r13d,%ecx
  825c65:	and    $0x1e,%cl
  825c68:	shl    %cl,%edx
  825c6a:	shl    $0x4,%rdi
  825c6e:	add    0x8(%rbx),%rdi
  825c72:	mov    %ebp,%eax
  825c74:	shr    $0x2,%eax
  825c77:	and    $0xc,%eax
  825c7a:	or     %edx,(%rax,%rdi,1)
  825c7d:	mov    0x10(%rbx),%r14
  825c81:	cmp    (%rbx),%r14
  825c84:	jne    825c10 <gpui_gpu::renderer::slots::write_prefix+0x120>
  825c86:	mov    %rbx,%rdi
  825c89:	movaps %xmm0,(%rsp)
  825c8d:	call   *0x65a08d(%rip)        # e7fd20 <_DYNAMIC+0x708>
  825c93:	movaps (%rsp),%xmm0
  825c97:	jmp    825c10 <gpui_gpu::renderer::slots::write_prefix+0x120>
  825c9c:	add    $0x18,%rsp
  825ca0:	pop    %rbx
  825ca1:	pop    %r12
  825ca3:	pop    %r13
  825ca5:	pop    %r14
  825ca7:	pop    %r15
  825ca9:	pop    %rbp
  825caa:	ret
  825cab:	mov    $0x4,%ecx
  825cb0:	mov    %r8,0x10(%rsp)
  825cb5:	mov    $0x10,%r8d
  825cbb:	mov    %rbx,%rdi
  825cbe:	mov    %rsi,(%rsp)
  825cc2:	mov    %r12,%rsi
  825cc5:	mov    %rdx,%r14
  825cc8:	mov    %r15,%rdx
  825ccb:	call   823b00 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  825cd0:	mov    0x10(%rsp),%r8
  825cd5:	mov    %r14,%rdx
  825cd8:	mov    (%rsp),%rsi
  825cdc:	mov    0x10(%rbx),%r14
  825ce0:	jmp    825b54 <gpui_gpu::renderer::slots::write_prefix+0x64>
  825ce5:	lea    0x608664(%rip),%rdx        # e2e350 <anon.4f92784177f891c02fc0a44bfee03ec4.12.llvm.1533866460487341161>
  825cec:	mov    %r14,%rsi
  825cef:	call   *0x659e1b(%rip)        # e7fb10 <_DYNAMIC+0x4f8>
