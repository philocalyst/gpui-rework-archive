from pathlib import Path
import csv,json,re
OUT=Path('/tmp/gpui-descending-csr-evidence')
old=Path('/tmp/gpui-gpu-frontier-evidence/calibration/pair-00-A')
def rows(p):return {(r['case'],r['hdr'],r['motion'],r['frame']):r for r in csv.DictReader((p/'frames.csv').open())}
def fields(text):return dict(re.findall(r'(\w+): ([^,}]+)',text))
a=rows(old);b=rows(OUT/'public-calibration');assert a.keys()==b.keys()
result=[]
for key,new in b.items():
    before=fields(a[key]['stats']);after=fields(new['stats'])
    assert before.keys()==after.keys()
    for name in before:
        if name=='cpu_index_capacity_bytes':assert int(before[name])-int(after[name])==2048
        else:assert before[name]==after[name],(key,name)
    result.append({'case':key[0],'hdr':key[1],'motion':key[2],'frame':key[3],
        'shipping_stats':before,'candidate_stats':after,
        'shipping_image_stats':fields(a[key]['image_stats']),'candidate_image_stats':fields(new['image_stats'])})
assert len(result)==52
report={'source':'1c97566cf0a7140d4f258deab136342a609d5755','frames':result,
    'scope':'All actual calibration frames including repeated preparation. Full warm validation, record streaming, resource walk and uploads remain; all work/payload fields exact, capacity separately charged. Calibration clocks unqualified.'}
(OUT/'public-work-payload-ledger.json').write_text(json.dumps(report,indent=2)+'\n')
print('52 actual frame work/upload payload bills PASS')
