# Descending-cursor independent qualification, frozen before capture

Source 1c97566cf0a7140d4f258deab136342a609d5755 in a new isolated tree.
No timing campaign is authorized. All calibration clocks are unqualified.
The original fixture 8773146b44150adb0150323d51f241c946fb5cda26328f004562dcd9dee39cc0
must match all 52 shipping captures and all work counters. Capacity inequality
is the intended deleted cursor allocation and is recorded separately.

Both full named captures have fixed 360-second process watchdogs, no retries,
no case drops and no adaptive timeout. Both use the exact same 47 committed
integration tests plus identical nonshipping 1×1 HDR/P3 maximum-count probe.
Compare by name/within-test ordinal/size/format, plus actual eligible CPU packets;
no-packet scratch frames stay labelled and every pixel/work counter still checks.
Public functional/fault processes retain fixed 180-second watchdogs.

The discrete proof is x=k+q*B, y=end+h*B, k=start+r, r=q+512*h.
Uniform tag is checked first. For r>0, k>=r>=1. If q>0, x>=B+1 and no
borrow occurs when subtracting B+1. If q=0, x=k<B, wraps q to 511 and
borrow decrements a live h>0; k decrements without borrowing into q because
k>=1. End remains immutable. Exhaustion yields exact original [start,end].
The high-bit union zero test is equivalent to r==0 only after the tag guard.
The maximum inclusive endpoint 2^22 is below B=2^23; remaining 65536 fits17.
No full-count decode/index add is needed. These statements inherit the suffix
selection, per-draw visit injectivity, original admission and publication proofs.

Audit all tile upload, redraw, slot/paint patches and failed preparation paths.
No new fields/heap/deps/unsafe/source exception/SIMD fork or GPU operation.
No zero-reference reverse skip or global per-reference countdown is combined.
The inherited GPU floating/opaque predicate contract is not a new strict-IEEE
geometry claim. Software Vulkan llvmpipe readbacks; other platforms compile only.

Qualify default/fallback/offline strict, independent suffix/address oracle,
511/512/513/65535/65536/end4M field endpoints and max-count production packet.
Actual wrong-order/count source controls must fail, restoration must pass.
Matched opt3/locked/root-v0/tokio/Rust1.97.1 builds use the same physical source
path, fresh:false artifacts and emit-stack-sizes once for static costs.
Charge shipping and 6bf code/frame/core comparisons and full allocation/upload
payloads, all unfavorable costs included. Entire shader/WGSL/8 SPIR-V artifacts
must remain shipping-byte-identical. Static frames are not peak stack/RSS.
