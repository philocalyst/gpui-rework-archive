from pathlib import Path
import collections,hashlib,json,re
OUT=Path('/tmp/gpui-descending-csr-evidence');CG=Path('/tmp/gpui-descending-csr-codegen')
metadata=json.loads((CG/'metadata.json').read_text());ledgers={};flags={};functions={};assembly={}
for label,lane in metadata['lanes'].items():
    lines=(CG/label/'cargo.log').read_text().splitlines()
    commands=[line.split('rustc --crate-name gpui_gpu ',1)[1] for line in lines if 'rustc --crate-name gpui_gpu ' in line and '--crate-type lib' in line]
    assert len(commands)==1
    command=commands[0]
    flags[label]={'opt3':'-C opt-level=3' in command,'root_v0_tokio':'-C symbol-mangling-version=v0' in command and '--cfg tokio_unstable' in command,
                  'emit_stack_sizes_count':command.count('-Zemit-stack-sizes'),'library_fresh':lane['library_artifact']['fresh'],'groups_fresh':lane['groups_artifact']['fresh'],'features':lane['library_artifact']['features']}
    assert flags[label]['opt3'] and flags[label]['root_v0_tokio'] and flags[label]['emit_stack_sizes_count']==1
    assert not flags[label]['library_fresh'] and not flags[label]['groups_fresh']
    assert hashlib.sha256(Path(lane['binary']).read_bytes()).hexdigest()==lane['binary_sha256']
    ledgers[label]=json.loads((CG/label/'groups-elf.json').read_text())
    text=(CG/label/'all-gpu-functions.asm').read_text();selected={}
    for suffix in ['render','bin_draw']:
        name='<gpui_gpu::renderer::RendererState>::'+suffix
        marker='\nFUNCTION '+name+' bytes='
        block=marker+text.split(marker,1)[1].split('\nFUNCTION ',1)[0]
        assert 'Disassembly of section' in block
        (OUT/(label+'-'+suffix+'.asm')).write_text(block)
        selected[suffix]={'integer_division_instructions':[line.strip() for line in block.splitlines() if re.search(r'\bdiv[ql]?\s',line)]}
    assembly[label]=selected
for name in ['<gpui_gpu::renderer::RendererState>::render','<gpui_gpu::renderer::RendererState>::bin_draw']:
    functions[name]={}
    for label,ledger in ledgers.items():
        fs=[f for f in ledger['all_gpu_frames'] if f['normalized_name']==name];assert len(fs)==1
        functions[name][label]={'code_bytes':fs[0]['code_bytes'],'static_frame_bytes':fs[0]['stack_bytes']}
counts={label:json.loads((OUT/('core-lines-'+label+'.json')).read_text())['core_non_test_code_lines'] for label in ['baseline','candidate']}
summary=json.loads((CG/'summary.json').read_text())
result={'baseline':metadata['baseline'],'candidate':metadata['candidate'],'source_path':metadata['same_physical_source_path'],'sections':{k:v['sections'] for k,v in ledgers.items()},
        'section_deltas':summary['section_deltas'],'functions':functions,'core_non_test_noncomment_lines':counts,'core_delta':counts['candidate']-counts['baseline'],
        'flag_verification':flags,'assembly_review':assembly,'removed_retained_fields':['Vec<u32> cursors'],'new_retained_fields':0,'new_heap_allocations':0,'public_work_payload_and_upload_diagnostics_exact':True,'capacity_ledger':'/tmp/gpui-descending-csr-codegen/capacity-ledger.json',
        'scope':'Actual same-path locked/features/root flags/opt3 fresh linked binaries and all GPU aliases. Compiler frames are not dynamic peak, call-chain totals, or RSS. No timed campaign.'}
(OUT/'cost-ledger.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
print('Changed unique-name functions')
for pair in summary['unique_name_pairs']:
    if pair['code_delta'] or pair['frame_delta']:print(pair['name'],pair['code_delta'],pair['frame_delta'])
