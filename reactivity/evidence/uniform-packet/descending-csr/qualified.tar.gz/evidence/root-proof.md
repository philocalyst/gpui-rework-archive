# Descending cursor and remaining count in one subtraction

Successor to frozen 6bf679e2b2fe175d87eddeea7e4f7362f042bf17. Only the
private transient CPU tile words change. All existing shaders, packet ABI,
forward admission, retained-suffix proof, work statistics, full reverse visits,
uploads, submission, replay and error behavior remain inherited.

Let B=2^23. A nonuniform tile has original [start,end], count=end-start <=65536.
At any reverse-fill step let r be remaining and k=start+r be the descending
write cursor. Store x=k+(r mod512)*B, y=end+floor(r/512)*B. Uniform tiles remain
their existing tagged address pair and are checked before interpreting x.
The inclusive endpoint bound is 4194304<B; r's high part is at most128, keeping
y's uniform bit clear. Thus r=0 iff ((x|y)&!(B-1))=0.

For r>0, k>=r>=1. Compute (next,borrow)=x.overflowing_sub(B+1).

* If r mod512>0, x>=B+1. No u32 borrow occurs. The result is
  (k-1)+((r mod512)-1)*B: cursor and low count both decrement exactly once.
* If r mod512=0, x=k<B. The subtraction wraps to (k-1)+511*B and reports
  borrow=true. r>0 implies floor(r/512)>0, so y-B safely decrements only the
  high count. Its end field and uniform bit remain unchanged.

The next reference slot is simply next&(B-1), equal to start+r-1. There is
no need to reconstruct r, add it to start, or subtract from that sum. At
exhaustion x=start and y=end, with all spare bits zero: exactly shipping words.
The old immutable-low-start induction becomes a descending-cursor induction;
the final ABI is unchanged. Bounds/zero/511/512/513/65535/65536/end4194304 tests
must check this new intermediate invariant explicitly.

No speed claim follows from the algebra. The matched whole linked code, helper
assembly, static frames and real packets still need qualification. A helper
could grow or take more cycles despite source simplification. Source must be
frozen before each capture; old 6bf/555/b312 archives remain immutable.

Root's initial functional gate is cargo test -p gpui_gpu --lib with default
features on Rust1.97.1, locked/offline, one job, target
/tmp/gpui-descending-csr-root-target,600s. No timing is registered. Full Sol
qualification must reuse the unchanged52 readbacks and all47 integration
fixtures/maxcount probe, actual packet oracle, wrong-order/count controls,
default/fallback/offline strict checks and Apple/Windows compilation. New
named process watchdogs remain360s on both lanes before any new capture.
