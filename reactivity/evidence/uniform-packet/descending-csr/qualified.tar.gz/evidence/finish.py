from pathlib import Path
import hashlib,json,re,subprocess
ROOT=Path('/tmp/gpui-descending-csr-sol');OUT=Path('/tmp/gpui-descending-csr-evidence');CG=Path('/tmp/gpui-descending-csr-codegen')
BASE='7a5e1619a27010ec63f6c27506a6d1fcd113f67c';PIN='1c97566cf0a7140d4f258deab136342a609d5755'
def git(*args):return subprocess.check_output(['git','-c','safe.directory='+str(ROOT),'-C',str(ROOT),*args])
def sha(data):return hashlib.sha256(data).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==PIN and not git('status','--porcelain')
gates=json.loads((OUT/'gates-summary.json').read_text());cross=json.loads((OUT/'cross-summary.json').read_text());metadata=json.loads((CG/'metadata.json').read_text())
assert metadata['restored_status']=='' and gates['all_source_guards_restored']
assert all(sha((ROOT/p).read_bytes())==h for p,h in gates['qualified_source_sha256'].items())
assert all(v['returncode']==0 for v in gates['gates'].values()) and all(v['returncode']==0 for v in cross.values())
counts={name:list(map(int,re.findall(r'test result: ok\. (\d+) passed',(OUT/(name+'.log')).read_text()))) for name in ['default','fallback','offline']}
assert counts=={'default':[11,4,47,1],'fallback':[11,4,47,1],'offline':[12,4,48,1]},counts
functional=json.loads((OUT/'functional-summary.json').read_text());negative_count=json.loads((OUT/'negative-count/summary.json').read_text());negative_selection=json.loads((OUT/'negative-selection/summary.json').read_text())
assert functional['all_work_stats_and_image_stats_exact'] and functional['exact_readback_bytes']==35651584
assert len(functional['readbacks'])==52
assert negative_count['independent_wrong_count_detected'] and negative_count['recovery']['returncode']==0
assert negative_selection['fault_oracle']['returncode']==101 and negative_selection['recovery_oracle']['returncode']==0
assert len(negative_selection['mismatched_public_readbacks'])==28
named=json.loads((CG/'named-readback-comparison.json').read_text());capacity=json.loads((CG/'capacity-ledger.json').read_text());cost=json.loads((OUT/'cost-ledger.json').read_text());shader=json.loads((OUT/'shader-cost-ledger.json').read_text())
assert named['matched_named_readbacks']==584 and named['complete_work_stats_image_stats_exact']
assert all(c['last_successful_reported_capacity_delta']==c['current_removed_cursor_bytes'] for c in capacity['captures'])
assert capacity['object_layout']=={'shipping':{'Renderer':888,'RendererState':840,'Stats':200},'candidate':{'Renderer':864,'RendererState':816,'Stats':200}}
for name in ['functional','negative-count','negative-selection','codegen','cost-ledger','shader-ledger','packet-oracle']:(OUT/(name+'.exit')).write_text('0\n')
# Preserve complete source overlays/probes used by the actual named executables.
ns={};exec(compile((OUT/'named_capture.py').read_text(),str(OUT/'named_capture.py'),'exec'),ns)
hook=next(c for c in ns['capture'].__code__.co_consts if isinstance(c,bytes) and b'Nonshipping readback observer' in c)
tests=git('show',PIN+':reactivity/crates/gpu/tests/render.rs');needle=b'    buffer.unmap();\n    output\n';probe=(OUT/'max-count-probe.rs').read_bytes()
for label,ref in [('baseline',BASE),('candidate',PIN)]:
 manifest=json.loads((CG/label/'named-readbacks/manifest.json').read_text())
 observed=tests.replace(needle,b'    buffer.unmap();\n'+hook+b'    output\n')+probe
 assert sha(observed)==manifest['observer_test_source_sha256']
 private=git('show',ref+':reactivity/crates/gpu/src/renderer/owned.rs')
 cursor=b'self.state.cursors.capacity() * 4' if label=='baseline' else b'0'
 private_hook=b'\nimpl Renderer { pub fn qualification_capacities(&self) -> [usize; 5] { [self.state.records.capacity() * 16, self.state.ranges.capacity() * 8, self.state.references.capacity() * 4, '+cursor+b', self.state.residuals.capacity() * 32] } pub fn qualification_packet(&self) -> Option<(&[[u32; 2]], &[u32])> { self.state.packet.as_ref().map(|_| (self.state.ranges.as_slice(), self.state.references.as_slice())) } }\n'
 assert sha(private+private_hook)==manifest['observer_private_source_sha256']
 (CG/label/'named-readbacks/observed-render.rs').write_bytes(observed)
 (CG/label/'named-readbacks/observed-owned.rs').write_bytes(private+private_hook)
# Exact pinned GPU sources/config/lock independently reconstruct the production slice.
snapshots=OUT/'source-snapshots';snapshots.mkdir()
for label,ref in [('shipping',BASE),('candidate',PIN)]:
 lane=snapshots/label;lane.mkdir();records=[]
 paths=git('ls-tree','-r','--name-only',ref,'--','reactivity/crates/gpu','.cargo/config.toml','reactivity/Cargo.toml','reactivity/Cargo.lock').decode().splitlines()
 for p in paths:
  data=git('show',ref+':'+p);file=lane/p;file.parent.mkdir(parents=True,exist_ok=True);file.write_bytes(data)
  records.append({'path':p,'bytes':len(data),'sha256':sha(data)})
 (lane/'source-manifest.json').write_text(json.dumps({'commit':ref,'files':records},indent=2)+'\n')
(snapshots/'candidate.patch').write_bytes(git('diff',BASE,PIN,'--','reactivity/crates/gpu'))
(OUT/'qualified-public-fixture.rs').write_bytes(Path('/tmp/gpui-gpu-frontier-evidence/source/qualification.rs').read_bytes())
# Charge secondary offline linked artifacts, all flags, and the reverse caller.
cost['offline_sections']={label:json.loads((CG/label/'offline-groups-elf.json').read_text())['sections'] for label in ['baseline','candidate']}
cost['offline_section_deltas']={k:cost['offline_sections']['candidate'][k]-cost['offline_sections']['baseline'][k] for k in cost['offline_sections']['baseline']}
cost['offline_flag_verification']={}
for label in ['baseline','candidate']:
 logs=(CG/label/'offline-cargo.log').read_text().splitlines()
 args=[x.split('rustc --crate-name gpui_gpu ',1)[1] for x in logs if 'rustc --crate-name gpui_gpu ' in x and '--crate-type lib' in x]
 assert len(args)==1
 assert args[0].count('-Zemit-stack-sizes')==1 and '-C opt-level=3' in args[0] and '--cfg tokio_unstable' in args[0] and '-C symbol-mangling-version=v0' in args[0]
 artifacts=[json.loads(x) for x in (CG/label/'offline-cargo.jsonl').read_text().splitlines() if x.startswith('{')]
 lib=next(a for a in artifacts if a.get('reason')=='compiler-artifact' and a.get('target',{}).get('name')=='gpui_gpu' and a.get('target',{}).get('kind')==['lib'])
 assert not lib['fresh'] and lib['profile']['opt_level']=='3'
 cost['offline_flag_verification'][label]={'library_fresh':lib['fresh'],'features':lib['features'],'emit_stack_sizes_count':1,'opt3_root_v0_tokio':True}
cost['all_current_capacity_and_reported_deltas_exact_removed_cursor_bytes']=True
cost['object_layout']=capacity['object_layout']
summary=json.loads((CG/'summary.json').read_text())
cost['changed_unique_name_functions']=[p for p in summary['unique_name_pairs'] if p['code_delta'] or p['frame_delta']]
(OUT/'cost-ledger.json').write_text(json.dumps(cost,indent=2)+'\n')
report={'source':PIN,'baseline':BASE,'tree':str(ROOT),'status':'correctness/static qualified, unadopted; no timed campaign',
        'gates':counts,'strict_default_offline':True,'cross_compile_only':cross,'source_guard_count':len(gates['qualified_source_sha256']),
        'public_readbacks':{'files':52,'bytes':35651584,'frozen_shipping_pixels_exact':True,'all_work_stats_image_stats_exact':True,'capacity_removed_per_frame':2048},
        'named_readbacks':{k:v for k,v in named.items() if k!='comparisons'},'packet_oracle':json.loads((OUT/'packet-oracle.json').read_text()),'object_layout':capacity['object_layout'],
        'capacity_range_observed_bytes':sorted(set(c['current_removed_cursor_bytes'] for c in capacity['captures'])),
        'negative_controls':{'counter_fault_exit':101,'counter_recovery_exit':0,'reverse_selection_fault_exit':101,'public_mismatches':28,'retained_fault_readbacks':52,'reverse_recovery_exit':0},
        'costs':cost,'shader_static_costs':{'wgsl_bytes':{k:v['default_wgsl_bytes'] for k,v in shader['lanes'].items()},'spirv_deltas':shader['spirv_deltas']},
        'scope':'Discrete equivalence with inherited shipping opaque-proof contract. Software Vulkan llvmpipe readbacks, compilation elsewhere. Static code/frame/capacity observations are not timing, peak stack, RSS or native GPU ISA.'}
(OUT/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['costs','shader_static_costs','cross_compile_only']},indent=2))
