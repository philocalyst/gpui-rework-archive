from pathlib import Path
import hashlib,json
out=Path('/tmp/gpui-descending-csr-evidence')
rows=json.loads(Path('/tmp/gpui-endpoint-csr-evidence/prior-archives-unchanged.json').read_text())
rows.append({'path':'/tmp/gpui-endpoint-csr-qualified.tar.gz','bytes':8865356,'sha256':'65fb1e18f0f0d76dc00d241d80fb156fa3dc83e1e98babf3b003996f1dbffbb9'})
for r in rows:
 p=Path(r['path']);h=hashlib.sha256()
 with p.open('rb') as stream:
  while b:=stream.read(1024*1024):h.update(b)
 assert p.stat().st_size==r['bytes'] and h.hexdigest()==r['sha256'],r['path']
 r['unchanged']=True
(out/'prior-archives-unchanged.json').write_text(json.dumps(rows,indent=2)+'\n')
print('all seven prior archives unchanged')
