from pathlib import Path
import hashlib,json,subprocess
OUT=Path('/tmp/gpui-descending-csr-evidence')
B=1<<23; M=B-1; MAX=1<<22; WORD=(1<<32)-1
checked=0; borrows=0
# Exhaust every possible live remaining count, with smallest, adjacent, middle
# and largest legal write cursors, and both smallest/largest immutable ends.
# Expected state is reconstructed independently using integer quotient/remainder.
for remaining in range(1,65537):
    for cursor in sorted({remaining,remaining+1,(MAX+remaining)//2,MAX}):
        for end in sorted({cursor,MAX}):
            x=cursor+(remaining%512)*B
            y=end+(remaining//512)*B
            assert y&(1<<31)==0 and ((x|y)&~M)!=0
            next_x=(x-B-1)&WORD; borrow=x<B+1
            next_y=y-(int(borrow)<<23)
            expected=remaining-1
            assert next_x==(cursor-1)+(expected%512)*B
            assert next_y==end+(expected//512)*B
            assert (next_x&M)==cursor-1 and (next_y&M)==end
            assert (((next_x|next_y)&~M)==0)==(expected==0)
            checked+=1;borrows+=borrow
for endpoint in range(MAX+1):
    assert ((endpoint|endpoint)&~M)==0
# Compiler and analysis executable identity are checked against the previously
# qualified controls; the actual current executable version is checked too.
for guard in json.loads((OUT/'compiler-guards.json').read_text()).values():
    p=Path(guard['executable'])
    assert hashlib.sha256(p.read_bytes()).hexdigest()==guard['sha256']
    assert subprocess.check_output(guard['version_args'],text=True)==guard['version']
for guard in json.loads((OUT/'analysis-tool-guards.json').read_text()):
    assert hashlib.sha256(Path(guard['path']).read_bytes()).hexdigest()==guard['sha256']
report={'all_live_remaining_counts':[1,65536],'checked_live_endpoint_combinations':checked,
        'mixed_radix_borrows_checked':borrows,'all_empty_endpoint_values_checked':MAX+1,
        'compiler_and_analysis_guards_match':True,
        'scope':'Independent integer state model; complements actual production helper, address oracle and packet/readback controls. No time claim.'}
(OUT/'arithmetic-oracle.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
