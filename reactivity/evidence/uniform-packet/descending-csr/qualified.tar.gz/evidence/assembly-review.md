# Matched three-lane CPU and shader bill

All three primary library rustc argument vectors are exactly equal: same physical
source path, lock/features, qualified Rust/Cargo 1.97.1, opt3, root v0/tokio and
emit-stack-sizes exactly once. Actual fresh:false groups/library artifacts remain.
Default .text is shipping 6403991, endpoint 6403623, descending 6403591: -400
versus shipping and -32 versus endpoint. Offline .text also falls 400/32 bytes.
The unfavorable default .rodata +128 versus shipping remains charged; it is equal
to 6bf. Offline .rodata is unchanged versus shipping. Default/offline .data.rel.ro
fall 48 versus shipping, equal to 6bf. Full aliases/unpaired functions remain;
individual helper/frame sizes are not additive whole-code or dynamic stack bills.

Render code/frame is 9493/1416 -> 9376/1400 (-117/-16) and bin_draw is
4184/824 -> 4056/792 (-128/-32), both equal to 6bf's sizes. Reverse visit is
shipping 611/88, endpoint 622/72, descending 590/72: -21/-16 versus shipping,
-32/0 versus 6bf. Constructor falls 27 and state drop glue falls 81 versus
shipping. Actual core count is 30692 -> 30702 (+10), down 2 from frozen 6bf.
No native cycle/time claim follows from any static body, frame or opcode count.

In actual descending reverse assembly, 81c788 loads y and 81c78d..81c790 tests
its sign and branches on uniform BEFORE cursor interpretation. 81c792..81c7a0
loads x, ORs x/y and compares the union with 0x800000 to skip exhausted ranges.
The compiler lowers the source high-bit zero test to an unsigned comparison.
81c7a4 subtracts 0x800001 from x; 81c7a9 stores its next value. The borrow is
materialized as inverted setae at 81c7ac, shifted by 23, added to old y and then
adjusted by -0x800000; 81c7bc stores the updated y. 81c7c0 masks next x by
0x7fffff to obtain the exact selected slot, followed by the ordinary reference
bounds check and address store. Both 32-bit tile-word stores and the conditional
high-field decrement remain charged. The previous 6bf full remaining-count
right shifts/mask/OR and start+remaining-1 computation are gone from this block.
The uniform/empty guards, endpoint index mask and ordinary visits remain.
Full baseline/endpoint/candidate reverse, render and bin_draw assembly is retained.
Render's old final-statistics integer divisions are absent; bin_draw's existing
divisions remain. No source, cap, partial-edge or original admission exception is
introduced. Complete reverse traversal still runs even if references is zero.

The entire shipping shader source, generated 15180-byte WGSL and all eight
validated SPIR-V modules are byte-identical, including every vertex/fragment
variant. Size/hash/opcode dictionaries are compared exactly. No GPU decoder,
integer mask/shift/add, branch, layout or floating operation is added. This
preserves the inherited GPU predicate contract without asserting a stronger
strict-IEEE geometry theorem. Cross-platform checks are compilation only;
actual readbacks use software llvmpipe. No timing, RSS, dynamic stack peak,
register-pressure, native GPU ISA or universal-win claim is made.
