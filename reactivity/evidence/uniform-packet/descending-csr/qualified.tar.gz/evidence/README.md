# Descending-cursor CSR: correctness/static qualified, unadopted

Source `1c97566cf0a7140d4f258deab136342a609d5755` is isolated at
`/tmp/gpui-descending-csr-sol`, succeeding sealed 6bf without modifying it.
Against shipping 7a5e, it deletes the cursor vector, reverse ordinal cutoff and
final statistics walk. Compared with 6bf, it replaces full remaining-count decode
and index addition with one descending-cursor/low-count subtraction.

Let B=2^23, r=q+512*h and k=start+r. Temporary x=k+q*B, y=end+h*B.
The uniform tag is checked first. For r>0, k>=r>=1. Subtracting B+1 from x
lowers k and q together; if q was zero, its wrap borrows only from live h>0
in y. Immutable end survives and each selected slot is next_x&(B-1).
Exhaustion yields EXACT shipping [start,end] words without a final conversion.
The entire shader, generated WGSL and all eight validated SPIR-V modules are
shipping byte-identical. No GPU decode, new retained field/heap/dependency/unsafe
code, source exception, SIMD fork or zero-reference traversal skip is added.

All original forward admission, logical caps, validation/record streaming,
resource walks, painter/source-over order, original full-tile proof, public API,
uploads, replay/paint/slot semantics and last-successful Stats remain inherited.
The only tile upload follows complete reverse exhaustion and tone admission.
Failed preparation revokes packet eligibility without publishing scratch/Stats.
No mutable borrowed PreparedScene header is trusted as identity.
The proof is discrete equivalence to the inherited accepted GPU predicate;
it does not strengthen that predicate into a universal strict-IEEE theorem.

All gates pass: default/fallback 11 library, 4 presentation, 47 render, 1 doc;
offline 12/4/48/1 with qualified spirv-val; strict default/offline all-target
Clippy; Apple ARM64/Windows MSVC all-feature library compilation; format and
all 1380 source/config guards. Other platforms are compile-only. Actual Vulkan
readbacks use software llvmpipe, not hardware measurements.

Independent integer checks cover every live remaining count 1..65536 with
458752 legal cursor/end combinations, including 896 borrows, and every one of
4194305 empty endpoints. Production tests cover 511/512/513/65535/65536,
end 4M, every intermediate cursor/end, final words and uniform inline overlap.
The actual binning oracle compares 32768 independent painter streams; its
normalization is manual, complemented by actual production captures below.

Original fixture 8773146... matches all 52 frozen shipping images/35651584 bytes
and all work/ImageStats/upload fields, including repeated preparation and both
32k workloads. Intended cursor-capacity deletion is 2048 bytes per frame.
The unchanged 47 integration tests plus identical 1x1 HDR/P3 max-count probe
run in both lanes under preregistered fixed 360s functional watchdogs, no retries.
All 584 named images/13484384 bytes and work counters match. All 574 eligible
current CPU tile/reference packets/401440 bytes per lane are byte-exact shipping;
ten no-packet scratch frames stay labelled and all their pixels/work still check.
Current CPU packet and queued older target readbacks are explicitly distinct.
The independent max-count packet oracle requires [0,65536] and all 65536 exact
INLINE|6*ordinal references, plus empty [0,0]; local endpoint/reference corruption
controls fail the analyzer. Exact nonshipping observer/probe sources are retained
and production sources restored. Capture clocks are unqualified.

Actual counter-only c+1 fault fails 21280 vs 10640 (101); restoration passes (0).
Actual ascending-slot fault fails the independent address oracle (101) and changes
28/52 public captures including SDR/HDR layers; restoration passes (0). Every
fault source, binary hash, raw capture and failure log remains. Other four scratch
capacities are exact; all capacity deltas equal the actual deleted cursor charge.
Linux Renderer 888->864, RendererState 840->816 and Stats 200 unchanged.
No allocator overhead, RSS or dynamic peak claim follows.

| Actual static cost | Shipping | Frozen 6bf | Descending 1c | Delta vs shipping / 6bf |
|---|---:|---:|---:|---:|
| Default .text | 6403991 | 6403623 | 6403591 | -400 / -32 |
| Default .rodata | 7012024 | 7012152 | 7012152 | +128 / +0 |
| Default .data.rel.ro | 336384 | 336336 | 336336 | -48 / +0 |
| Default .stack_sizes | 97857 | 97857 | 97857 | +0 / +0 |
| render code/frame | 9493/1416 | 9376/1400 | 9376/1400 | See full ledger |
| bin_draw code/frame | 4184/824 | 4056/792 | 4056/792 | See full ledger |
| Reverse visit code/frame | 611/88 | 622/72 | 590/72 | -21/-16 vs shipping; -32/0 vs 6bf |
| Core LOC | 30692 | 30704 | 30702 | +10 / -2 |

All three primary library argument vectors are exactly equal: same physical
source path, Rust/Cargo 1.97.1, lock/features, opt3, root v0/tokio and emit-stack-sizes
exactly once. Real fresh:false groups/library artifacts remain. Whole default and
offline sections, all symbol aliases/unpaired functions, complete assembly and
helper/frame costs are charged in three-lane-cost-ledger.json, including every
unfavorable result. Compiler frames are not additive call chains or peak stack.
Full warm validation and uploads remain; no harness/API witness skips them.

No timing campaign, speed, adoption or universal-win claim is made. All seven
prior archives rehash unchanged. The sealed archive preserves raw images/packets,
source/config/patch snapshots, proofs, guards, controls and cost/upload bills.
ELFs stay external with exact paths/sizes/hashes. Every archive member is reopened
and individually verified. Follow-on work remains separate.
