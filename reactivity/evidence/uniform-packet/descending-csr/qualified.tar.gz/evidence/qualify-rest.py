from pathlib import Path
import json,os,subprocess,sys
OUT=Path('/tmp/gpui-descending-csr-evidence')
for file in ['gates-summary.json','cross-summary.json']:
    d=json.loads((OUT/file).read_text())
    rows=d['gates'].values() if file.startswith('gates') else d.values()
    assert all(r['returncode']==0 for r in rows)
assert json.loads((OUT/'gates-summary.json').read_text())['all_source_guards_restored']
for name,script in [('functional','functional.py'),('public-payload','public-payload.py'),('negative-count','negative-control.py'),('negative-selection','negative-selection.py'),('codegen','codegen.py'),('cost-ledger','cost-ledger.py'),('three-lane-costs','three-lane-costs.py'),('shader-ledger','shader-ledger.py'),('packet-oracle','packet-oracle.py'),('finish','finish.py')]:
    print(name+' START',flush=True)
    with (OUT/(name+'-runner.log')).open('w') as log:
        p=subprocess.run([sys.executable,str(OUT/script)],stdout=log,stderr=subprocess.STDOUT)
    (OUT/(name+'.exit')).write_text(str(p.returncode)+'\n')
    assert p.returncode==0,(name,p.returncode)
    print(name+' PASS',flush=True)
