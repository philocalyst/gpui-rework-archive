
FUNCTION <gpui_gpu::renderer::RendererState>::render bytes=9376 frame=1400

/tmp/gpui-descending-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081e0b0 <<gpui_gpu::renderer::RendererState>::render>:
  81e0b0:	push   %rbp
  81e0b1:	push   %r15
  81e0b3:	push   %r14
  81e0b5:	push   %r13
  81e0b7:	push   %r12
  81e0b9:	push   %rbx
  81e0ba:	sub    $0x548,%rsp
  81e0c1:	mov    0x210(%rsi),%rax
  81e0c8:	mov    0x18(%rdx),%r9
  81e0cc:	cmp    %r9,%rax
  81e0cf:	je     81e0ed <<gpui_gpu::renderer::RendererState>::render+0x3d>
  81e0d1:	mov    0x10(%rax),%r10
  81e0d5:	cmp    0x10(%r9),%r10
  81e0d9:	jne    81e1bb <<gpui_gpu::renderer::RendererState>::render+0x10b>
  81e0df:	mov    0x18(%rax),%rax
  81e0e3:	cmp    0x18(%r9),%rax
  81e0e7:	jne    81e1bb <<gpui_gpu::renderer::RendererState>::render+0x10b>
  81e0ed:	lea    0x318(%rsi),%rbx
  81e0f4:	mov    0x318(%rsi),%rax
  81e0fb:	test   %rax,%rax
  81e0fe:	je     81e12d <<gpui_gpu::renderer::RendererState>::render+0x7d>
  81e100:	lock decq (%rax)
  81e104:	jne    81e12d <<gpui_gpu::renderer::RendererState>::render+0x7d>
  81e106:	mov    %rdi,%r14
  81e109:	mov    %rbx,%rdi
  81e10c:	mov    %rsi,%r12
  81e10f:	mov    %r8,%r13
  81e112:	mov    %rdx,%r15
  81e115:	mov    %rcx,%rbp
  81e118:	call   *0x661a12(%rip)        # e7fb30 <_DYNAMIC+0x518>
  81e11e:	mov    %rbp,%rcx
  81e121:	mov    %r15,%rdx
  81e124:	mov    %r13,%r8
  81e127:	mov    %r12,%rsi
  81e12a:	mov    %r14,%rdi
  81e12d:	movq   $0x0,0x318(%rsi)
  81e138:	mov    (%rcx),%r12d
  81e13b:	mov    0x8(%rcx),%r9d
  81e13f:	movzbl 0xd(%rcx),%eax
  81e143:	test   %r9d,%r9d
  81e146:	sets   %r10b
  81e14a:	and    $0x7fffffff,%r9d
  81e151:	lea    -0x800000(%r9),%r11d
  81e158:	cmp    $0x7f000000,%r11d
  81e15f:	setb   %r11b
  81e163:	and    %r10b,%r11b
  81e166:	lea    -0x1(%r9),%ebp
  81e16a:	cmp    $0x7fffff,%ebp
  81e170:	setb   %bpl
  81e174:	and    %r10b,%bpl
  81e177:	test   %r9d,%r9d
  81e17a:	sete   %r10b
  81e17e:	cmp    $0x7f800000,%r9d
  81e185:	sete   %r14b
  81e189:	or     %r10b,%r14b
  81e18c:	cmp    $0x7f800001,%r9d
  81e193:	setge  %r9b
  81e197:	or     %r14b,%r9b
  81e19a:	or     %bpl,%r9b
  81e19d:	test   %r12d,%r12d
  81e1a0:	setne  %r10b
  81e1a4:	and    %al,%r10b
  81e1a7:	or     %r11b,%r10b
  81e1aa:	or     %r9b,%r10b
  81e1ad:	test   $0x1,%r10b
  81e1b1:	je     81e1d6 <<gpui_gpu::renderer::RendererState>::render+0x126>
  81e1b3:	movl   $0x3,(%rdi)
  81e1b9:	jmp    81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81e1bb:	movl   $0x4,(%rdi)
  81e1c1:	mov    %rdi,%rax
  81e1c4:	add    $0x548,%rsp
  81e1cb:	pop    %rbx
  81e1cc:	pop    %r12
  81e1ce:	pop    %r13
  81e1d0:	pop    %r14
  81e1d2:	pop    %r15
  81e1d4:	pop    %rbp
  81e1d5:	ret
  81e1d6:	movd   0x4(%rcx),%xmm2
  81e1db:	movzbl 0xc(%rcx),%ebp
  81e1df:	test   $0x1,%r12b
  81e1e3:	je     81e25b <<gpui_gpu::renderer::RendererState>::render+0x1ab>
  81e1e5:	movd   %xmm2,%r9d
  81e1ea:	test   %r9d,%r9d
  81e1ed:	sets   %r10b
  81e1f1:	and    $0x7fffffff,%r9d
  81e1f8:	lea    -0x800000(%r9),%r11d
  81e1ff:	cmp    $0x7f000000,%r11d
  81e206:	setb   %r11b
  81e20a:	and    %r10b,%r11b
  81e20d:	lea    -0x1(%r9),%r14d
  81e211:	cmp    $0x7fffff,%r14d
  81e218:	setb   %r14b
  81e21c:	and    %r10b,%r14b
  81e21f:	test   %r9d,%r9d
  81e222:	sete   %r10b
  81e226:	cmp    $0x7f800000,%r9d
  81e22d:	sete   %r15b
  81e231:	or     %r10b,%r15b
  81e234:	cmp    $0x7f800001,%r9d
  81e23b:	setge  %r9b
  81e23f:	or     %r15b,%r9b
  81e242:	or     %r14b,%r9b
  81e245:	or     %r11b,%r9b
  81e248:	jne    81e1b3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e24e:	ucomiss -0x76f3a9(%rip),%xmm2        # aeeac <anon.630a3fff68f6bca64b568be97512ab45.57.llvm.826976926275214120+0x1c>
  81e255:	ja     81e1b3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e25b:	mov    0x28(%rcx),%r14d
  81e25f:	cmp    %r14d,0x20(%r8)
  81e263:	jne    81e1b3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e269:	mov    0x2c(%rcx),%r15d
  81e26d:	cmp    %r15d,0x24(%r8)
  81e271:	jne    81e1b3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e277:	mov    0x38(%r8),%r13d
  81e27b:	cmp    0x20(%rdx),%r13d
  81e27f:	jne    81e1b3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e285:	cmp    $0x4c,%r13d
  81e289:	jne    81e2ae <<gpui_gpu::renderer::RendererState>::render+0x1fe>
  81e28b:	movq   0x3c(%r8),%xmm0
  81e291:	movq   0x24(%rdx),%xmm1
  81e296:	pcmpeqd %xmm0,%xmm1
  81e29a:	pshufd $0x50,%xmm1,%xmm0
  81e29f:	movmskpd %xmm0,%r9d
  81e2a4:	cmp    $0x3,%r9d
  81e2a8:	jne    81e1b3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e2ae:	cmp    $0x4000,%r15d
  81e2b5:	ja     81e2eb <<gpui_gpu::renderer::RendererState>::render+0x23b>
  81e2b7:	cmp    $0x4000,%r14d
  81e2be:	ja     81e2eb <<gpui_gpu::renderer::RendererState>::render+0x23b>
  81e2c0:	mov    %r15,%r9
  81e2c3:	imul   %r14,%r9
  81e2c7:	add    $0xfffffffffeffffff,%r9
  81e2ce:	cmp    $0xffffffffff000000,%r9
  81e2d5:	jb     81e2eb <<gpui_gpu::renderer::RendererState>::render+0x23b>
  81e2d7:	mov    0x10(%rcx),%r11
  81e2db:	mov    0x80(%r11),%r10
  81e2e2:	cmp    $0x10000,%r10
  81e2e9:	jbe    81e2f6 <<gpui_gpu::renderer::RendererState>::render+0x246>
  81e2eb:	movl   $0x6,(%rdi)
  81e2f1:	jmp    81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81e2f6:	movd   0x18(%rcx),%xmm0
  81e2fb:	movd   %xmm0,%r9d
  81e300:	and    $0x7fffffff,%r9d
  81e307:	cmp    $0x7f7fffff,%r9d
  81e30e:	jg     81e1b3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e314:	pand   -0x770b9c(%rip),%xmm0        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e31c:	ucomiss -0x76f21f(%rip),%xmm0        # af104 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e323:	ja     81e1b3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e329:	movd   0x1c(%rcx),%xmm0
  81e32e:	movd   %xmm0,%r9d
  81e333:	and    $0x7fffffff,%r9d
  81e33a:	cmp    $0x7f7fffff,%r9d
  81e341:	jg     81e1b3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e347:	pand   -0x770bcf(%rip),%xmm0        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e34f:	ucomiss -0x76f252(%rip),%xmm0        # af104 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e356:	ja     81e1b3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e35c:	movd   0x20(%rcx),%xmm0
  81e361:	movd   %xmm0,%r9d
  81e366:	and    $0x7fffffff,%r9d
  81e36d:	cmp    $0x7f7fffff,%r9d
  81e374:	jg     81e1b3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e37a:	pand   -0x770c02(%rip),%xmm0        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e382:	ucomiss -0x76f285(%rip),%xmm0        # af104 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e389:	ja     81e1b3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e38f:	movd   0x24(%rcx),%xmm0
  81e394:	movd   %xmm0,%r9d
  81e399:	and    $0x7fffffff,%r9d
  81e3a0:	cmp    $0x7f7fffff,%r9d
  81e3a7:	jg     81e1b3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e3ad:	movdqa -0x770c35(%rip),%xmm1        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e3b5:	pand   %xmm0,%xmm1
  81e3b9:	ucomiss -0x76f2bc(%rip),%xmm1        # af104 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e3c0:	ja     81e1b3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e3c6:	xorps  %xmm1,%xmm1
  81e3c9:	ucomiss %xmm1,%xmm0
  81e3cc:	jb     81e1b3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e3d2:	movss  -0x76f65a(%rip),%xmm1        # aed80 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  81e3da:	ucomiss %xmm0,%xmm1
  81e3dd:	jb     81e1b3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e3e3:	movzwl 0x30(%rcx),%r9d
  81e3e8:	mov    %r9w,0x10(%rsp)
  81e3ee:	movzwl 0x32(%rcx),%r9d
  81e3f3:	mov    %r9w,0x18(%rsp)
  81e3f9:	cmp    $0x28,%r13d
  81e3fd:	jne    81e409 <<gpui_gpu::renderer::RendererState>::render+0x359>
  81e3ff:	test   $0x1,%al
  81e401:	je     81e1b3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e407:	jmp    81e424 <<gpui_gpu::renderer::RendererState>::render+0x374>
  81e409:	test   $0x1,%al
  81e40b:	jne    81e1b3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e411:	ucomiss -0x76f698(%rip),%xmm0        # aed80 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  81e418:	jne    81e1b3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e41e:	jp     81e1b3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e424:	mov    %r11,0xc8(%rsp)
  81e42c:	mov    %r10,0xc0(%rsp)
  81e434:	movss  %xmm1,0x104(%rsp)
  81e43d:	movd   %xmm2,0x244(%rsp)
  81e446:	mov    %rdx,0x108(%rsp)
  81e44e:	mov    %r8,0x3e8(%rsp)
  81e456:	mov    %rdi,0x30(%rsp)
  81e45b:	lea    0xf(%r14),%rdx
  81e45f:	shr    $0x4,%rdx
  81e463:	lea    0xf(%r15),%eax
  81e467:	shr    $0x4,%eax
  81e46a:	lea    0x18(%rsi),%rdi
  81e46e:	movq   $0x0,0x28(%rsi)
  81e476:	mov    %rdx,0x58(%rsp)
  81e47b:	imul   %edx,%eax
  81e47e:	mov    %rdi,0x218(%rsp)
  81e486:	mov    %rsi,0x8(%rsp)
  81e48b:	mov    %rax,%rsi
  81e48e:	xor    %edx,%edx
  81e490:	mov    %rcx,0xe8(%rsp)
  81e498:	call   8227d0 <<alloc::vec::Vec<[u32; 2]>>::resize>
  81e49d:	mov    0x8(%rsp),%rax
  81e4a2:	movq   $0x0,0x10(%rax)
  81e4aa:	mov    0xe8(%rsp),%rdi
  81e4b2:	call   *0x661708(%rip)        # e7fbc0 <_DYNAMIC+0x5a8>
  81e4b8:	mov    %rdx,%rcx
  81e4bb:	sub    %rax,%rcx
  81e4be:	cmp    $0x300000,%rcx
  81e4c5:	jbe    81e4d7 <<gpui_gpu::renderer::RendererState>::render+0x427>
  81e4c7:	mov    0x30(%rsp),%rdi
  81e4cc:	movl   $0x6,(%rdi)
  81e4d2:	jmp    81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81e4d7:	mov    %rcx,%rsi
  81e4da:	shr    $0x3,%rcx
  81e4de:	movabs $0xaaaaaaaaaaaaaaab,%rdi
  81e4e8:	imul   %rcx,%rdi
  81e4ec:	mov    %rdi,0x38(%rsp)
  81e4f1:	mov    %rax,0x380(%rsp)
  81e4f9:	mov    %rdx,0x378(%rsp)
  81e501:	cmp    %rax,%rdx
  81e504:	je     81e532 <<gpui_gpu::renderer::RendererState>::render+0x482>
  81e506:	mov    $0xaaaaaaab,%eax
  81e50b:	imul   %rax,%rsi
  81e50f:	shr    $0x2a,%rsi
  81e513:	mov    0x38(%rsp),%rcx
  81e518:	mov    %ecx,%eax
  81e51a:	and    $0x3f,%eax
  81e51d:	add    %rcx,%rsi
  81e520:	cmp    $0x1,%rax
  81e524:	sbb    $0xffffffffffffffff,%rsi
  81e528:	inc    %rsi
  81e52b:	mov    %rsi,0x50(%rsp)
  81e530:	jmp    81e53b <<gpui_gpu::renderer::RendererState>::render+0x48b>
  81e532:	movq   $0x0,0x50(%rsp)
  81e53b:	mov    0xc8(%rsp),%rax
  81e543:	mov    0x98(%rax),%rcx
  81e54a:	add    0xb0(%rax),%rcx
  81e551:	mov    %rax,0x110(%rsp)
  81e559:	movzwl 0x10(%rsp),%eax
  81e55e:	mov    %ax,0x130(%rsp)
  81e566:	movzwl 0x18(%rsp),%eax
  81e56b:	mov    %ax,0x132(%rsp)
  81e573:	movq   $0x0,0x118(%rsp)
  81e57f:	mov    0xc0(%rsp),%rax
  81e587:	mov    %rax,0x120(%rsp)
  81e58f:	mov    %rcx,0x210(%rsp)
  81e597:	mov    %rcx,0x128(%rsp)
  81e59f:	mov    0x8(%rsp),%rax
  81e5a4:	movzbl 0x329(%rax),%edx
  81e5ab:	lea    0x428(%rsp),%rdi
  81e5b3:	lea    0x110(%rsp),%rsi
  81e5bb:	call   81c820 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>>
  81e5c0:	mov    0x428(%rsp),%eax
  81e5c7:	cmp    $0xffffffff,%eax
  81e5ca:	je     81e5fa <<gpui_gpu::renderer::RendererState>::render+0x54a>
  81e5cc:	mov    0x42c(%rsp),%ecx
  81e5d3:	mov    0x430(%rsp),%rdx
  81e5db:	movups 0x438(%rsp),%xmm0
  81e5e3:	mov    0x30(%rsp),%rdi
  81e5e8:	movups %xmm0,0x10(%rdi)
  81e5ec:	mov    %eax,(%rdi)
  81e5ee:	mov    %ecx,0x4(%rdi)
  81e5f1:	mov    %rdx,0x8(%rdi)
  81e5f5:	jmp    81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81e5fa:	mov    0x430(%rsp),%rdx
  81e602:	add    0x50(%rsp),%rdx
  81e607:	mov    0x8(%rsp),%rdi
  81e60c:	mov    0x10(%rdi),%rsi
  81e610:	mov    $0x4,%ecx
  81e615:	mov    $0x10,%r8d
  81e61b:	call   823b90 <<alloc::raw_vec::RawVecInner>::try_reserve_exact>
  81e620:	cmp    $0xffffffffffffffff,%rax
  81e624:	jne    81e4c7 <<gpui_gpu::renderer::RendererState>::render+0x417>
  81e62a:	movzwl 0x10(%rsp),%eax
  81e62f:	mov    %eax,0x10(%rsp)
  81e633:	movzwl 0x18(%rsp),%eax
  81e638:	mov    %eax,0x78(%rsp)
  81e63c:	mov    0x8(%rsp),%rdi
  81e641:	mov    0xe8(%rsp),%rsi
  81e649:	mov    0x38(%rsp),%rdx
  81e64e:	call   825af0 <gpui_gpu::renderer::slots::write_prefix>
  81e653:	mov    0x8(%rsp),%rax
  81e658:	movq   $0x0,0x58(%rax)
  81e660:	cmpq   $0x0,0x48(%rax)
  81e665:	jne    81e676 <<gpui_gpu::renderer::RendererState>::render+0x5c6>
  81e667:	mov    0x8(%rsp),%rax
  81e66c:	lea    0x48(%rax),%rdi
  81e670:	call   *0x661552(%rip)        # e7fbc8 <_DYNAMIC+0x5b0>
  81e676:	mov    0x8(%rsp),%rax
  81e67b:	mov    0x50(%rax),%rcx
  81e67f:	xorps  %xmm0,%xmm0
  81e682:	movups %xmm0,0x10(%rcx)
  81e686:	movups %xmm0,(%rcx)
  81e689:	movq   $0x1,0x58(%rax)
  81e691:	lea    0x2e0(%rax),%rdi
  81e698:	call   8254a0 <<hashbrown::raw::RawTable<([u32; 8], u32)>>::clear>
  81e69d:	mov    0x78(%rsp),%ecx
  81e6a1:	shl    $0x10,%ecx
  81e6a4:	add    0x10(%rsp),%ecx
  81e6a8:	mov    0xc8(%rsp),%rax
  81e6b0:	mov    %rax,0x388(%rsp)
  81e6b8:	movq   $0x0,0x390(%rsp)
  81e6c4:	mov    0xc0(%rsp),%rax
  81e6cc:	mov    %rax,0x398(%rsp)
  81e6d4:	mov    0x210(%rsp),%rax
  81e6dc:	mov    %rax,0x3a0(%rsp)
  81e6e4:	mov    %ecx,0x78(%rsp)
  81e6e8:	mov    %ecx,0x3a8(%rsp)
  81e6ef:	lea    0x248(%rsp),%rdi
  81e6f7:	lea    0x388(%rsp),%rsi
  81e6ff:	call   *0x6614cb(%rip)        # e7fbd0 <_DYNAMIC+0x5b8>
  81e705:	mov    0x248(%rsp),%rax
  81e70d:	mov    %rax,0x18(%rsp)
  81e712:	test   %rax,%rax
  81e715:	je     81f479 <<gpui_gpu::renderer::RendererState>::render+0x13c9>
  81e71b:	movq   $0x0,0xe0(%rsp)
  81e727:	movq   $0x0,0x10(%rsp)
  81e730:	movq   $0x0,0xb8(%rsp)
  81e73c:	movq   $0x0,0x200(%rsp)
  81e748:	movq   $0x0,0x208(%rsp)
  81e754:	mov    0x250(%rsp),%rcx
  81e75c:	mov    0x258(%rsp),%rdx
  81e764:	mov    %rdx,0xa0(%rsp)
  81e76c:	lea    0x260(%rsp),%rdi
  81e774:	movups (%rdi),%xmm0
  81e777:	movups 0x10(%rdi),%xmm1
  81e77b:	movups 0x20(%rdi),%xmm2
  81e77f:	movaps %xmm2,0x2f0(%rsp)
  81e787:	movaps %xmm1,0x2e0(%rsp)
  81e78f:	movaps %xmm0,0x2d0(%rsp)
  81e797:	lea    0x290(%rsp),%r8
  81e79f:	movups (%r8),%xmm0
  81e7a3:	movaps %xmm0,0x4f0(%rsp)
  81e7ab:	movups 0x40(%rdi),%xmm0
  81e7af:	movaps %xmm0,0x3f0(%rsp)
  81e7b7:	mov    0x8(%rsp),%rax
  81e7bc:	movzbl 0x329(%rax),%esi
  81e7c3:	mov    0x18(%rsp),%rax
  81e7c8:	mov    %rax,0x110(%rsp)
  81e7d0:	mov    %rcx,0x28(%rsp)
  81e7d5:	mov    %rcx,0x118(%rsp)
  81e7dd:	mov    %rdx,0x120(%rsp)
  81e7e5:	movups (%rdi),%xmm0
  81e7e8:	movups 0x10(%rdi),%xmm1
  81e7ec:	movups 0x20(%rdi),%xmm2
  81e7f0:	lea    0x128(%rsp),%rax
  81e7f8:	movups %xmm2,0x20(%rax)
  81e7fc:	movups %xmm1,0x10(%rax)
  81e800:	movups %xmm0,(%rax)
  81e803:	movups (%r8),%xmm0
  81e807:	movups %xmm0,0x30(%rax)
  81e80b:	movups 0x40(%rdi),%xmm0
  81e80f:	movups %xmm0,0x40(%rax)
  81e813:	lea    0x110(%rsp),%rdi
  81e81b:	call   821530 <gpui_gpu::renderer::compact_group>
  81e820:	mov    %al,0x40(%rsp)
  81e824:	lea    0x260(%rsp),%rsi
  81e82c:	movups (%rsi),%xmm0
  81e82f:	movups 0x10(%rsi),%xmm1
  81e833:	movups 0x20(%rsi),%xmm2
  81e837:	movaps %xmm0,0x500(%rsp)
  81e83f:	movaps %xmm1,0x510(%rsp)
  81e847:	movaps %xmm2,0x520(%rsp)
  81e84f:	lea    0x290(%rsp),%rdx
  81e857:	movups (%rdx),%xmm0
  81e85a:	movaps %xmm0,0x530(%rsp)
  81e862:	mov    0x8(%rsp),%rdi
  81e867:	call   81d450 <<gpui_gpu::renderer::RendererState>::correction>
  81e86c:	mov    %eax,0x7c(%rsp)
  81e870:	mov    0xa0(%rsp),%rax
  81e878:	lea    0x0(,%rax,4),%rax
  81e880:	mov    %rax,0x370(%rsp)
  81e888:	cmpb   $0x0,0x40(%rsp)
  81e88d:	je     81ea6b <<gpui_gpu::renderer::RendererState>::render+0x9bb>
  81e893:	mov    0x28(%rsp),%rcx
  81e898:	mov    0xa0(%rsp),%rax
  81e8a0:	lea    (%rcx,%rax,4),%rax
  81e8a4:	mov    %rcx,0x408(%rsp)
  81e8ac:	mov    %rax,0x410(%rsp)
  81e8b4:	mov    0x18(%rsp),%rax
  81e8b9:	mov    %rax,0x418(%rsp)
  81e8c1:	movq   $0x0,0x420(%rsp)
  81e8cd:	lea    0x300(%rsp),%rdi
  81e8d5:	lea    0x408(%rsp),%rsi
  81e8dd:	call   821bc0 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81e8e2:	cmpb   $0xff,0x308(%rsp)
  81e8ea:	je     81efaa <<gpui_gpu::renderer::RendererState>::render+0xefa>
  81e8f0:	xorps  %xmm0,%xmm0
  81e8f3:	movaps %xmm0,0x80(%rsp)
  81e8fb:	movaps %xmm0,0x60(%rsp)
  81e900:	mov    0x300(%rsp),%rdx
  81e908:	add    0xb8(%rsp),%rdx
  81e910:	lea    0x308(%rsp),%rsi
  81e918:	movups 0x38(%rsi),%xmm0
  81e91c:	lea    0x128(%rsp),%rcx
  81e924:	movups %xmm0,0x20(%rcx)
  81e928:	movups 0x48(%rsi),%xmm0
  81e92c:	movups %xmm0,0x70(%rcx)
  81e930:	mov    0x30(%rsi),%rax
  81e934:	mov    %rax,0x140(%rsp)
  81e93c:	movups (%rsi),%xmm0
  81e93f:	movups 0x10(%rsi),%xmm1
  81e943:	movups 0x20(%rsi),%xmm2
  81e947:	movaps %xmm2,0x130(%rsp)
  81e94f:	movaps %xmm1,0x120(%rsp)
  81e957:	movaps %xmm0,0x110(%rsp)
  81e95f:	lea    0x260(%rsp),%rax
  81e967:	movups 0x40(%rax),%xmm0
  81e96b:	movups %xmm0,0x80(%rcx)
  81e972:	movups (%rax),%xmm0
  81e975:	movups 0x10(%rax),%xmm1
  81e979:	movups 0x20(%rax),%xmm2
  81e97d:	movups %xmm2,0x50(%rcx)
  81e981:	movups %xmm1,0x40(%rcx)
  81e985:	movups %xmm0,0x30(%rcx)
  81e989:	lea    0x290(%rsp),%rax
  81e991:	movups (%rax),%xmm0
  81e994:	movups %xmm0,0x60(%rcx)
  81e998:	lea    0x220(%rsp),%rdi
  81e9a0:	lea    0x110(%rsp),%rsi
  81e9a8:	mov    %r14d,%ecx
  81e9ab:	mov    %r15d,%r8d
  81e9ae:	call   821580 <gpui_gpu::renderer::validate_draw>
  81e9b3:	mov    0x220(%rsp),%ecx
  81e9ba:	mov    0x224(%rsp),%rax
  81e9c2:	cmp    $0xffffffff,%ecx
  81e9c5:	jne    81f534 <<gpui_gpu::renderer::RendererState>::render+0x1484>
  81e9cb:	mov    %eax,%ecx
  81e9cd:	shr    $0x20,%rax
  81e9d1:	movd   %ecx,%xmm0
  81e9d5:	movaps 0x80(%rsp),%xmm2
  81e9dd:	movaps %xmm2,%xmm1
  81e9e0:	maxss  %xmm0,%xmm1
  81e9e4:	movaps %xmm1,%xmm3
  81e9e7:	cmpunordss %xmm1,%xmm3
  81e9ec:	movaps %xmm3,%xmm0
  81e9ef:	andnps %xmm1,%xmm0
  81e9f2:	andps  %xmm2,%xmm3
  81e9f5:	orps   %xmm0,%xmm3
  81e9f8:	movaps %xmm3,0x40(%rsp)
  81e9fd:	movd   %eax,%xmm0
  81ea01:	movaps 0x60(%rsp),%xmm2
  81ea06:	movaps %xmm2,%xmm1
  81ea09:	maxss  %xmm0,%xmm1
  81ea0d:	movaps %xmm1,%xmm3
  81ea10:	cmpunordss %xmm1,%xmm3
  81ea15:	movaps %xmm3,%xmm0
  81ea18:	andnps %xmm1,%xmm0
  81ea1b:	andps  %xmm2,%xmm3
  81ea1e:	orps   %xmm0,%xmm3
  81ea21:	movaps %xmm3,0x90(%rsp)
  81ea29:	lea    0x300(%rsp),%rdi
  81ea31:	lea    0x408(%rsp),%rsi
  81ea39:	call   821bc0 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81ea3e:	cmpb   $0xff,0x308(%rsp)
  81ea46:	movaps 0x40(%rsp),%xmm0
  81ea4b:	movaps %xmm0,0x80(%rsp)
  81ea53:	movaps 0x90(%rsp),%xmm0
  81ea5b:	movaps %xmm0,0x60(%rsp)
  81ea60:	jne    81e900 <<gpui_gpu::renderer::RendererState>::render+0x850>
  81ea66:	jmp    81efba <<gpui_gpu::renderer::RendererState>::render+0xf0a>
  81ea6b:	cmpq   $0x0,0xa0(%rsp)
  81ea74:	je     81f423 <<gpui_gpu::renderer::RendererState>::render+0x1373>
  81ea7a:	mov    0x7c(%rsp),%eax
  81ea7e:	or     $0x80000000,%eax
  81ea83:	mov    %eax,0x240(%rsp)
  81ea8a:	movq   $0x0,0x90(%rsp)
  81ea96:	mov    0x28(%rsp),%rax
  81ea9b:	mov    0x90(%rsp),%rcx
  81eaa3:	mov    (%rax,%rcx,1),%edx
  81eaa6:	lea    0x110(%rsp),%rdi
  81eaae:	mov    0x18(%rsp),%rsi
  81eab3:	call   81c970 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81eab8:	movzbl 0x110(%rsp),%edi
  81eac0:	lea    0x111(%rsp),%rdx
  81eac8:	mov    (%rdx),%eax
  81eaca:	mov    0x3(%rdx),%ecx
  81eacd:	lea    0x460(%rsp),%rsi
  81ead5:	mov    %ecx,-0x34(%rsi)
  81ead8:	mov    %eax,-0x37(%rsi)
  81eadb:	mov    0x118(%rsp),%rcx
  81eae3:	mov    0x2f(%rdx),%rax
  81eae7:	mov    %rax,-0x8(%rsi)
  81eaeb:	movups 0xf(%rdx),%xmm0
  81eaef:	movups 0x1f(%rdx),%xmm1
  81eaf3:	movups %xmm1,-0x18(%rsi)
  81eaf7:	movups %xmm0,-0x28(%rsi)
  81eafb:	lea    0x128(%rsp),%rax
  81eb03:	movups 0x20(%rax),%xmm0
  81eb07:	movups %xmm0,(%rsi)
  81eb0a:	movups 0x30(%rax),%xmm0
  81eb0e:	movups %xmm0,0x50(%rsi)
  81eb12:	lea    0x260(%rsp),%rax
  81eb1a:	movups 0x40(%rax),%xmm0
  81eb1e:	movups %xmm0,0x60(%rsi)
  81eb22:	movups (%rax),%xmm0
  81eb25:	movups 0x10(%rax),%xmm1
  81eb29:	movups 0x20(%rax),%xmm2
  81eb2d:	movups %xmm2,0x30(%rsi)
  81eb31:	movups %xmm1,0x20(%rsi)
  81eb35:	movups %xmm0,0x10(%rsi)
  81eb39:	lea    0x290(%rsp),%rax
  81eb41:	movups (%rax),%xmm0
  81eb44:	movups %xmm0,0x40(%rsi)
  81eb48:	mov    %dil,0x60(%rsp)
  81eb4d:	mov    %dil,0x428(%rsp)
  81eb55:	mov    %rcx,0x80(%rsp)
  81eb5d:	mov    %rcx,0x430(%rsp)
  81eb65:	lea    0x110(%rsp),%rdi
  81eb6d:	lea    0x428(%rsp),%rsi
  81eb75:	mov    0xb8(%rsp),%rdx
  81eb7d:	mov    %r14d,%ecx
  81eb80:	mov    %r15d,%r8d
  81eb83:	call   821580 <gpui_gpu::renderer::validate_draw>
  81eb88:	mov    0x110(%rsp),%eax
  81eb8f:	mov    0x114(%rsp),%rcx
  81eb97:	mov    %rcx,0x40(%rsp)
  81eb9c:	cmp    $0xffffffff,%eax
  81eb9f:	jne    81f5ca <<gpui_gpu::renderer::RendererState>::render+0x151a>
  81eba5:	movzbl 0x60(%rsp),%eax
  81ebaa:	cmp    $0x2,%al
  81ebac:	sete   0x27(%rsp)
  81ebb1:	cmpq   $0x0,0x80(%rsp)
  81ebba:	setne  0x26(%rsp)
  81ebbf:	movups 0x460(%rsp),%xmm0
  81ebc7:	movaps %xmm0,0x2c0(%rsp)
  81ebcf:	cmp    $0x3,%al
  81ebd1:	jne    81ec63 <<gpui_gpu::renderer::RendererState>::render+0xbb3>
  81ebd7:	movss  0x42c(%rsp),%xmm0
  81ebe0:	xorps  %xmm1,%xmm1
  81ebe3:	ucomiss %xmm1,%xmm0
  81ebe6:	jne    81ebea <<gpui_gpu::renderer::RendererState>::render+0xb3a>
  81ebe8:	jnp    81ec63 <<gpui_gpu::renderer::RendererState>::render+0xbb3>
  81ebea:	movaps 0x2c0(%rsp),%xmm5
  81ebf2:	movaps %xmm5,%xmm1
  81ebf5:	unpckhpd %xmm5,%xmm1
  81ebf9:	movss  -0x76fc95(%rip),%xmm4        # aef6c <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  81ec01:	mulss  %xmm4,%xmm1
  81ec05:	movaps %xmm0,%xmm2
  81ec08:	minss  %xmm1,%xmm2
  81ec0c:	movaps %xmm2,%xmm1
  81ec0f:	cmpunordss %xmm2,%xmm1
  81ec14:	movaps %xmm1,%xmm3
  81ec17:	andnps %xmm2,%xmm3
  81ec1a:	andps  %xmm0,%xmm1
  81ec1d:	orps   %xmm3,%xmm1
  81ec20:	movaps %xmm5,%xmm0
  81ec23:	shufps $0xff,%xmm5,%xmm0
  81ec27:	mulss  %xmm4,%xmm0
  81ec2b:	movaps %xmm1,%xmm2
  81ec2e:	minss  %xmm0,%xmm2
  81ec32:	movaps %xmm2,%xmm0
  81ec35:	cmpunordss %xmm2,%xmm0
  81ec3a:	andps  %xmm0,%xmm1
  81ec3d:	andnps %xmm2,%xmm0
  81ec40:	orps   %xmm1,%xmm0
  81ec43:	movd   %xmm0,%eax
  81ec47:	mov    %eax,0x60(%rsp)
  81ec4b:	and    $0xff800000,%eax
  81ec50:	mov    $0x7f000000,%ecx
  81ec55:	sub    %eax,%ecx
  81ec57:	mov    %ecx,0x80(%rsp)
  81ec5e:	xorps  %xmm0,%xmm0
  81ec61:	jmp    81ec85 <<gpui_gpu::renderer::RendererState>::render+0xbd5>
  81ec63:	mov    0x4c0(%rsp),%eax
  81ec6a:	mov    %eax,0x60(%rsp)
  81ec6e:	mov    0x4c4(%rsp),%eax
  81ec75:	mov    %eax,0x80(%rsp)
  81ec7c:	movsd  0x4c8(%rsp),%xmm0
  81ec85:	movaps %xmm0,0xd0(%rsp)
  81ec8d:	mov    0x8(%rsp),%rax
  81ec92:	mov    0x10(%rax),%ecx
  81ec95:	mov    $0x80000000,%eax
  81ec9a:	or     %eax,%ecx
  81ec9c:	mov    %ecx,0x360(%rsp)
  81eca3:	movups 0x470(%rsp),%xmm0
  81ecab:	movaps %xmm0,0x3c0(%rsp)
  81ecb3:	movups 0x478(%rsp),%xmm0
  81ecbb:	movaps %xmm0,0x4e0(%rsp)
  81ecc3:	movsd  0x480(%rsp),%xmm0
  81eccc:	movaps %xmm0,0x3b0(%rsp)
  81ecd4:	movsd  0x488(%rsp),%xmm0
  81ecdd:	movaps %xmm0,0x4d0(%rsp)
  81ece5:	movsd  0x490(%rsp),%xmm0
  81ecee:	movsd  %xmm0,0x3e0(%rsp)
  81ecf7:	movsd  0x498(%rsp),%xmm0
  81ed00:	movsd  %xmm0,0x3d8(%rsp)
  81ed09:	movups 0x4a0(%rsp),%xmm0
  81ed11:	movaps %xmm0,0x2b0(%rsp)
  81ed19:	mov    0x18(%rsp),%rax
  81ed1e:	mov    %rax,0x110(%rsp)
  81ed26:	mov    0x28(%rsp),%rax
  81ed2b:	mov    %rax,0x118(%rsp)
  81ed33:	mov    0xa0(%rsp),%rax
  81ed3b:	mov    %rax,0x120(%rsp)
  81ed43:	movaps 0x2d0(%rsp),%xmm0
  81ed4b:	movaps 0x2e0(%rsp),%xmm1
  81ed53:	movaps 0x2f0(%rsp),%xmm2
  81ed5b:	lea    0x128(%rsp),%rax
  81ed63:	movups %xmm2,0x20(%rax)
  81ed67:	movups %xmm1,0x10(%rax)
  81ed6b:	movups %xmm0,(%rax)
  81ed6e:	movaps 0x4f0(%rsp),%xmm0
  81ed76:	movups %xmm0,0x30(%rax)
  81ed7a:	movaps 0x3f0(%rsp),%xmm0
  81ed82:	movups %xmm0,0x40(%rax)
  81ed86:	lea    0x110(%rsp),%rdi
  81ed8e:	call   *0x660e44(%rip)        # e7fbd8 <_DYNAMIC+0x5c0>
  81ed94:	mov    0x7c(%rsp),%ecx
  81ed98:	mov    %ecx,0xf0(%rsp)
  81ed9f:	test   %eax,%eax
  81eda1:	je     81edd7 <<gpui_gpu::renderer::RendererState>::render+0xd27>
  81eda3:	mov    0x38(%rsp),%rdi
  81eda8:	mov    %eax,%esi
  81edaa:	call   825ab0 <gpui_gpu::renderer::slots::color_word>
  81edaf:	mov    %eax,0x60(%rsp)
  81edb3:	xorps  %xmm0,%xmm0
  81edb6:	movaps %xmm0,0xd0(%rsp)
  81edbe:	movl   $0x0,0x80(%rsp)
  81edc9:	mov    0x240(%rsp),%eax
  81edd0:	mov    %eax,0xf0(%rsp)
  81edd7:	mov    0x40(%rsp),%rax
  81eddc:	shr    $0x20,%rax
  81ede0:	mov    %rax,0x3d0(%rsp)
  81ede8:	mov    0x8(%rsp),%rax
  81eded:	mov    (%rax),%rcx
  81edf0:	mov    0x10(%rax),%rsi
  81edf4:	sub    %rsi,%rcx
  81edf7:	cmp    $0x5,%rcx
  81edfb:	jbe    81ef82 <<gpui_gpu::renderer::RendererState>::render+0xed2>
  81ee01:	movsd  0x3d8(%rsp),%xmm0
  81ee0a:	cvtsd2ss %xmm0,%xmm0
  81ee0e:	movsd  0x3e0(%rsp),%xmm1
  81ee17:	cvtsd2ss %xmm1,%xmm1
  81ee1b:	movapd 0x4e0(%rsp),%xmm2
  81ee24:	unpcklpd 0x4d0(%rsp),%xmm2
  81ee2d:	cvtpd2ps %xmm2,%xmm2
  81ee31:	movapd 0x3c0(%rsp),%xmm3
  81ee3a:	unpcklpd 0x3b0(%rsp),%xmm3
  81ee43:	cvtpd2ps %xmm3,%xmm3
  81ee47:	mov    0x8(%rsp),%rax
  81ee4c:	mov    0x8(%rax),%rdx
  81ee50:	shl    $0x4,%rsi
  81ee54:	movaps 0x2c0(%rsp),%xmm4
  81ee5c:	movups %xmm4,(%rdx,%rsi,1)
  81ee60:	movlpd %xmm3,0x10(%rdx,%rsi,1)
  81ee66:	movss  %xmm1,0x18(%rdx,%rsi,1)
  81ee6c:	mov    0x40(%rsp),%rcx
  81ee71:	mov    %ecx,0x1c(%rdx,%rsi,1)
  81ee75:	movlpd %xmm2,0x20(%rdx,%rsi,1)
  81ee7b:	movss  %xmm0,0x28(%rdx,%rsi,1)
  81ee81:	mov    0x3d0(%rsp),%rdi
  81ee89:	mov    %edi,0x2c(%rdx,%rsi,1)
  81ee8d:	movaps 0x2b0(%rsp),%xmm0
  81ee95:	movups %xmm0,0x30(%rdx,%rsi,1)
  81ee9a:	mov    0x60(%rsp),%edi
  81ee9e:	mov    %edi,0x40(%rdx,%rsi,1)
  81eea2:	mov    0x80(%rsp),%edi
  81eea9:	mov    %edi,0x44(%rdx,%rsi,1)
  81eead:	movaps 0xd0(%rsp),%xmm0
  81eeb5:	movlps %xmm0,0x48(%rdx,%rsi,1)
  81eeba:	movq   $0x0,0x50(%rdx,%rsi,1)
  81eec3:	movl   $0x0,0x58(%rdx,%rsi,1)
  81eecb:	mov    0xf0(%rsp),%edi
  81eed2:	mov    %edi,0x5c(%rdx,%rsi,1)
  81eed6:	addq   $0x6,0x10(%rax)
  81eedb:	sub    $0x8,%rsp
  81eedf:	lea    0x118(%rsp),%rdi
  81eee7:	mov    %rax,%rsi
  81eeea:	lea    0x430(%rsp),%rdx
  81eef2:	mov    0x368(%rsp),%r8d
  81eefa:	mov    0x60(%rsp),%r9
  81eeff:	push   0xe8(%rsp)
  81ef06:	push   %r15
  81ef08:	push   %r14
  81ef0a:	call   820550 <<gpui_gpu::renderer::RendererState>::bin_draw>
  81ef0f:	add    $0x20,%rsp
  81ef13:	mov    0x110(%rsp),%eax
  81ef1a:	cmp    $0xffffffff,%eax
  81ef1d:	jne    81f592 <<gpui_gpu::renderer::RendererState>::render+0x14e2>
  81ef23:	movzbl 0x27(%rsp),%ecx
  81ef28:	and    0x26(%rsp),%cl
  81ef2c:	mov    0x10(%rsp),%rax
  81ef31:	or     %cl,%al
  81ef33:	mov    %rax,0x10(%rsp)
  81ef38:	mov    0x118(%rsp),%rax
  81ef40:	mov    %rax,0xe0(%rsp)
  81ef48:	incq   0xb8(%rsp)
  81ef50:	mov    0x90(%rsp),%rdx
  81ef58:	add    $0x4,%rdx
  81ef5c:	mov    0xa0(%rsp),%rax
  81ef64:	lea    0x0(,%rax,4),%rax
  81ef6c:	mov    %rdx,0x90(%rsp)
  81ef74:	cmp    %rdx,%rax
  81ef77:	jne    81ea96 <<gpui_gpu::renderer::RendererState>::render+0x9e6>
  81ef7d:	jmp    81f417 <<gpui_gpu::renderer::RendererState>::render+0x1367>
  81ef82:	mov    $0x6,%edx
  81ef87:	mov    $0x4,%ecx
  81ef8c:	mov    $0x10,%r8d
  81ef92:	mov    0x8(%rsp),%rdi
  81ef97:	call   823b00 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  81ef9c:	mov    0x8(%rsp),%rax
  81efa1:	mov    0x10(%rax),%rsi
  81efa5:	jmp    81ee01 <<gpui_gpu::renderer::RendererState>::render+0xd51>
  81efaa:	xorps  %xmm0,%xmm0
  81efad:	movaps %xmm0,0x90(%rsp)
  81efb5:	movaps %xmm0,0x40(%rsp)
  81efba:	mov    0x8(%rsp),%rax
  81efbf:	mov    0x10(%rax),%eax
  81efc2:	mov    %eax,0xd0(%rsp)
  81efc9:	movups 0x260(%rsp),%xmm1
  81efd1:	movups 0x268(%rsp),%xmm2
  81efd9:	movsd  0x280(%rsp),%xmm0
  81efe2:	movsd  %xmm0,0xf0(%rsp)
  81efeb:	movsd  0x288(%rsp),%xmm0
  81eff4:	movsd  %xmm0,0x2c0(%rsp)
  81effd:	movups 0x290(%rsp),%xmm0
  81f005:	movaps %xmm0,0x80(%rsp)
  81f00d:	movhps 0x270(%rsp),%xmm1
  81f015:	movaps %xmm1,0x360(%rsp)
  81f01d:	movups 0x2a0(%rsp),%xmm0
  81f025:	movaps %xmm0,0x60(%rsp)
  81f02a:	movhps 0x278(%rsp),%xmm2
  81f032:	movaps %xmm2,0x2b0(%rsp)
  81f03a:	mov    0x18(%rsp),%rax
  81f03f:	mov    %rax,0x110(%rsp)
  81f047:	mov    0x28(%rsp),%rax
  81f04c:	mov    %rax,0x118(%rsp)
  81f054:	mov    0xa0(%rsp),%rax
  81f05c:	mov    %rax,0x120(%rsp)
  81f064:	lea    0x260(%rsp),%rax
  81f06c:	movups (%rax),%xmm0
  81f06f:	movups 0x10(%rax),%xmm1
  81f073:	movups 0x20(%rax),%xmm2
  81f077:	lea    0x128(%rsp),%rdx
  81f07f:	movups %xmm2,0x20(%rdx)
  81f083:	movups %xmm1,0x10(%rdx)
  81f087:	movups %xmm0,(%rdx)
  81f08a:	lea    0x290(%rsp),%rcx
  81f092:	movups (%rcx),%xmm0
  81f095:	movups %xmm0,0x30(%rdx)
  81f099:	movdqu 0x40(%rax),%xmm0
  81f09e:	movdqu %xmm0,0x40(%rdx)
  81f0a3:	lea    0x110(%rsp),%rdi
  81f0ab:	call   *0x660b27(%rip)        # e7fbd8 <_DYNAMIC+0x5c0>
  81f0b1:	test   %eax,%eax
  81f0b3:	je     81f0d3 <<gpui_gpu::renderer::RendererState>::render+0x1023>
  81f0b5:	mov    0x38(%rsp),%rdi
  81f0ba:	mov    %eax,%esi
  81f0bc:	call   825ab0 <gpui_gpu::renderer::slots::color_word>
  81f0c1:	orl    $0x80000000,0x7c(%rsp)
  81f0c9:	movd   %eax,%xmm0
  81f0cd:	movdqa %xmm0,0x60(%rsp)
  81f0d3:	mov    0x8(%rsp),%rax
  81f0d8:	mov    (%rax),%rcx
  81f0db:	mov    0x10(%rax),%rsi
  81f0df:	sub    %rsi,%rcx
  81f0e2:	cmp    $0x4,%rcx
  81f0e6:	jbe    81f451 <<gpui_gpu::renderer::RendererState>::render+0x13a1>
  81f0ec:	cvtpd2ps 0x360(%rsp),%xmm0
  81f0f5:	cvtpd2ps 0x2b0(%rsp),%xmm1
  81f0fe:	movsd  0xf0(%rsp),%xmm2
  81f107:	cvtsd2ss %xmm2,%xmm2
  81f10b:	movsd  0x2c0(%rsp),%xmm3
  81f114:	cvtsd2ss %xmm3,%xmm3
  81f118:	mov    0x8(%rsp),%rax
  81f11d:	mov    0x8(%rax),%rcx
  81f121:	shl    $0x4,%rsi
  81f125:	movlpd %xmm0,(%rcx,%rsi,1)
  81f12a:	movss  %xmm2,0x8(%rcx,%rsi,1)
  81f130:	movaps 0x40(%rsp),%xmm0
  81f135:	movss  %xmm0,0xc(%rcx,%rsi,1)
  81f13b:	movlpd %xmm1,0x10(%rcx,%rsi,1)
  81f141:	movss  %xmm3,0x18(%rcx,%rsi,1)
  81f147:	movaps 0x90(%rsp),%xmm0
  81f14f:	movss  %xmm0,0x1c(%rcx,%rsi,1)
  81f155:	movaps 0x80(%rsp),%xmm0
  81f15d:	movups %xmm0,0x20(%rcx,%rsi,1)
  81f162:	movaps 0x60(%rsp),%xmm0
  81f167:	movups %xmm0,0x30(%rcx,%rsi,1)
  81f16c:	mov    0x7c(%rsp),%edx
  81f170:	mov    %edx,0x40(%rcx,%rsi,1)
  81f174:	movq   $0x0,0x44(%rcx,%rsi,1)
  81f17d:	movl   $0x0,0x4c(%rcx,%rsi,1)
  81f185:	addq   $0x5,0x10(%rax)
  81f18a:	incq   0x200(%rsp)
  81f192:	mov    0xa0(%rsp),%rax
  81f19a:	add    %rax,0x208(%rsp)
  81f1a2:	test   %rax,%rax
  81f1a5:	je     81f423 <<gpui_gpu::renderer::RendererState>::render+0x1373>
  81f1ab:	movdqa 0x40(%rsp),%xmm0
  81f1b1:	movd   %xmm0,%ecx
  81f1b5:	movdqa 0x90(%rsp),%xmm0
  81f1be:	movd   %xmm0,%eax
  81f1c2:	shl    $0x20,%rax
  81f1c6:	or     %rax,%rcx
  81f1c9:	mov    %rcx,0xf0(%rsp)
  81f1d1:	mov    0x370(%rsp),%rax
  81f1d9:	add    $0xfffffffffffffffc,%rax
  81f1dd:	shr    $0x2,%rax
  81f1e1:	mov    0xb8(%rsp),%rcx
  81f1e9:	add    %rax,%rcx
  81f1ec:	inc    %rcx
  81f1ef:	mov    %rcx,0xb8(%rsp)
  81f1f7:	movq   $0x0,0x40(%rsp)
  81f200:	mov    0x28(%rsp),%rax
  81f205:	mov    0x40(%rsp),%rcx
  81f20a:	mov    (%rax,%rcx,1),%edx
  81f20d:	lea    0x300(%rsp),%rdi
  81f215:	mov    0x18(%rsp),%rsi
  81f21a:	call   81c970 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81f21f:	movzbl 0x300(%rsp),%edi
  81f227:	lea    0x308(%rsp),%rsi
  81f22f:	mov    -0x7(%rsi),%eax
  81f232:	mov    -0x4(%rsi),%ecx
  81f235:	lea    0x111(%rsp),%rdx
  81f23d:	mov    %ecx,0x3(%rdx)
  81f240:	mov    %eax,(%rdx)
  81f242:	mov    0x308(%rsp),%rcx
  81f24a:	mov    0x28(%rsi),%rax
  81f24e:	mov    %rax,0x2f(%rdx)
  81f252:	movups 0x8(%rsi),%xmm0
  81f256:	movups 0x18(%rsi),%xmm1
  81f25a:	movups %xmm1,0x1f(%rdx)
  81f25e:	movups %xmm0,0xf(%rdx)
  81f262:	movups 0x338(%rsp),%xmm1
  81f26a:	lea    0x348(%rsp),%rax
  81f272:	movups (%rax),%xmm0
  81f275:	lea    0x128(%rsp),%rax
  81f27d:	movups %xmm0,0x70(%rax)
  81f281:	movaps 0x3f0(%rsp),%xmm0
  81f289:	movups %xmm0,0x80(%rax)
  81f290:	movaps %xmm1,0xa0(%rsp)
  81f298:	movups %xmm1,0x148(%rsp)
  81f2a0:	movaps 0x500(%rsp),%xmm0
  81f2a8:	movaps 0x510(%rsp),%xmm1
  81f2b0:	movapd 0x520(%rsp),%xmm2
  81f2b9:	movupd %xmm2,0x50(%rax)
  81f2be:	movups %xmm1,0x40(%rax)
  81f2c2:	movups %xmm0,0x30(%rax)
  81f2c6:	movaps 0x530(%rsp),%xmm0
  81f2ce:	movups %xmm0,0x60(%rax)
  81f2d2:	mov    %dil,0x60(%rsp)
  81f2d7:	mov    %dil,0x110(%rsp)
  81f2df:	mov    %rcx,0x80(%rsp)
  81f2e7:	mov    %rcx,0x118(%rsp)
  81f2ef:	mov    0x8(%rsp),%rax
  81f2f4:	mov    (%rax),%rcx
  81f2f7:	mov    0x10(%rax),%rax
  81f2fb:	sub    %rax,%rcx
  81f2fe:	mov    %rax,0x90(%rsp)
  81f306:	cmp    $0x1,%rcx
  81f30a:	jbe    81f3e7 <<gpui_gpu::renderer::RendererState>::render+0x1337>
  81f310:	mov    0x8(%rsp),%rsi
  81f315:	mov    0x8(%rsi),%rcx
  81f319:	shl    $0x4,%rax
  81f31d:	movaps 0xa0(%rsp),%xmm0
  81f325:	movups %xmm0,(%rcx,%rax,1)
  81f329:	movq   $0x0,0x10(%rcx,%rax,1)
  81f332:	movl   $0x0,0x18(%rcx,%rax,1)
  81f33a:	mov    0xd0(%rsp),%edx
  81f341:	mov    %edx,0x1c(%rcx,%rax,1)
  81f345:	addq   $0x2,0x10(%rsi)
  81f34a:	sub    $0x8,%rsp
  81f34e:	lea    0x308(%rsp),%rdi
  81f356:	lea    0x118(%rsp),%rdx
  81f35e:	mov    0xf8(%rsp),%rcx
  81f366:	mov    0x98(%rsp),%r8
  81f36e:	mov    0x60(%rsp),%r9
  81f373:	push   0xe8(%rsp)
  81f37a:	push   %r15
  81f37c:	push   %r14
  81f37e:	call   820550 <<gpui_gpu::renderer::RendererState>::bin_draw>
  81f383:	add    $0x20,%rsp
  81f387:	mov    0x300(%rsp),%eax
  81f38e:	cmp    $0xffffffff,%eax
  81f391:	jne    81f5ae <<gpui_gpu::renderer::RendererState>::render+0x14fe>
  81f397:	cmpb   $0x2,0x60(%rsp)
  81f39c:	sete   %al
  81f39f:	cmpq   $0x0,0x80(%rsp)
  81f3a8:	setne  %cl
  81f3ab:	and    %al,%cl
  81f3ad:	mov    0x10(%rsp),%rax
  81f3b2:	or     %cl,%al
  81f3b4:	mov    %rax,0x10(%rsp)
  81f3b9:	mov    0x308(%rsp),%rax
  81f3c1:	mov    %rax,0xe0(%rsp)
  81f3c9:	mov    0x40(%rsp),%rcx
  81f3ce:	add    $0x4,%rcx
  81f3d2:	mov    %rcx,0x40(%rsp)
  81f3d7:	cmp    %rcx,0x370(%rsp)
  81f3df:	jne    81f200 <<gpui_gpu::renderer::RendererState>::render+0x1150>
  81f3e5:	jmp    81f417 <<gpui_gpu::renderer::RendererState>::render+0x1367>
  81f3e7:	mov    $0x2,%edx
  81f3ec:	mov    $0x4,%ecx
  81f3f1:	mov    $0x10,%r8d
  81f3f7:	mov    0x8(%rsp),%rdi
  81f3fc:	mov    0x90(%rsp),%rsi
  81f404:	call   823b00 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  81f409:	mov    0x8(%rsp),%rax
  81f40e:	mov    0x10(%rax),%rax
  81f412:	jmp    81f310 <<gpui_gpu::renderer::RendererState>::render+0x1260>
  81f417:	mov    0x10(%rsp),%rax
  81f41c:	and    $0x1,%al
  81f41e:	mov    %rax,0x10(%rsp)
  81f423:	lea    0x248(%rsp),%rdi
  81f42b:	lea    0x388(%rsp),%rsi
  81f433:	call   *0x660797(%rip)        # e7fbd0 <_DYNAMIC+0x5b8>
  81f439:	mov    0x248(%rsp),%rax
  81f441:	mov    %rax,0x18(%rsp)
  81f446:	test   %rax,%rax
  81f449:	jne    81e754 <<gpui_gpu::renderer::RendererState>::render+0x6a4>
  81f44f:	jmp    81f4b2 <<gpui_gpu::renderer::RendererState>::render+0x1402>
  81f451:	mov    $0x5,%edx
  81f456:	mov    $0x4,%ecx
  81f45b:	mov    $0x10,%r8d
  81f461:	mov    0x8(%rsp),%rdi
  81f466:	call   823b00 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  81f46b:	mov    0x8(%rsp),%rax
  81f470:	mov    0x10(%rax),%rsi
  81f474:	jmp    81f0ec <<gpui_gpu::renderer::RendererState>::render+0x103c>
  81f479:	movq   $0x0,0x208(%rsp)
  81f485:	movq   $0x0,0x200(%rsp)
  81f491:	movq   $0x0,0xb8(%rsp)
  81f49d:	movq   $0x0,0x10(%rsp)
  81f4a6:	movq   $0x0,0xe0(%rsp)
  81f4b2:	mov    0x108(%rsp),%rsi
  81f4ba:	lea    0x8(%rsi),%rdx
  81f4be:	mov    0x8(%rsp),%rax
  81f4c3:	lea    0x240(%rax),%rcx
  81f4ca:	lea    0x310(%rax),%r8
  81f4d1:	mov    0x10(%rax),%r9
  81f4d5:	sub    $0x8,%rsp
  81f4d9:	lea    0x118(%rsp),%rdi
  81f4e1:	mov    %rdx,0x3c8(%rsp)
  81f4e9:	mov    %rcx,0x2b8(%rsp)
  81f4f1:	mov    %r8,0x2c8(%rsp)
  81f4f9:	push   0xf0(%rsp)
  81f500:	call   822a40 <gpui_gpu::renderer::images::prepare>
  81f505:	add    $0x10,%rsp
  81f509:	cmpl   $0xffffffff,0x110(%rsp)
  81f511:	je     81f55a <<gpui_gpu::renderer::RendererState>::render+0x14aa>
  81f513:	movups 0x110(%rsp),%xmm0
  81f51b:	movups 0x120(%rsp),%xmm1
  81f523:	mov    0x30(%rsp),%rdi
  81f528:	movups %xmm1,0x10(%rdi)
  81f52c:	movups %xmm0,(%rdi)
  81f52f:	jmp    81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81f534:	mov    0x23c(%rsp),%edx
  81f53b:	mov    0x30(%rsp),%rdi
  81f540:	mov    %edx,0x1c(%rdi)
  81f543:	movups 0x22c(%rsp),%xmm0
  81f54b:	movups %xmm0,0xc(%rdi)
  81f54f:	mov    %ecx,(%rdi)
  81f551:	mov    %rax,0x4(%rdi)
  81f555:	jmp    81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81f55a:	movzbl 0x10(%rsp),%r8d
  81f560:	and    $0x1,%r8d
  81f564:	lea    0x110(%rsp),%rdi
  81f56c:	mov    0x8(%rsp),%rsi
  81f571:	mov    0x108(%rsp),%rdx
  81f579:	mov    0xc8(%rsp),%rcx
  81f581:	call   81d830 <<gpui_gpu::renderer::RendererState>::prepare_atlas>
  81f586:	mov    0x110(%rsp),%eax
  81f58d:	cmp    $0xffffffff,%eax
  81f590:	je     81f5f5 <<gpui_gpu::renderer::RendererState>::render+0x1545>
  81f592:	mov    0x114(%rsp),%ecx
  81f599:	mov    0x118(%rsp),%rdx
  81f5a1:	movups 0x120(%rsp),%xmm0
  81f5a9:	jmp    81e5e3 <<gpui_gpu::renderer::RendererState>::render+0x533>
  81f5ae:	mov    0x304(%rsp),%ecx
  81f5b5:	mov    0x308(%rsp),%rdx
  81f5bd:	movups 0x310(%rsp),%xmm0
  81f5c5:	jmp    81e5e3 <<gpui_gpu::renderer::RendererState>::render+0x533>
  81f5ca:	mov    0x12c(%rsp),%ecx
  81f5d1:	mov    0x30(%rsp),%rdi
  81f5d6:	mov    %ecx,0x1c(%rdi)
  81f5d9:	movups 0x11c(%rsp),%xmm0
  81f5e1:	movups %xmm0,0xc(%rdi)
  81f5e5:	mov    %eax,(%rdi)
  81f5e7:	mov    0x40(%rsp),%rax
  81f5ec:	mov    %rax,0x4(%rdi)
  81f5f0:	jmp    81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81f5f5:	mov    0x118(%rsp),%rax
  81f5fd:	mov    %rax,0x3b0(%rsp)
  81f605:	mov    0xc8(%rsp),%rax
  81f60d:	mov    %rax,0x300(%rsp)
  81f615:	movq   $0x0,0x308(%rsp)
  81f621:	mov    0xc0(%rsp),%rax
  81f629:	mov    %rax,0x310(%rsp)
  81f631:	mov    0x210(%rsp),%rax
  81f639:	mov    %rax,0x318(%rsp)
  81f641:	mov    0x78(%rsp),%eax
  81f645:	mov    %eax,0x320(%rsp)
  81f64c:	lea    0x248(%rsp),%rdi
  81f654:	lea    0x300(%rsp),%rsi
  81f65c:	call   *0x66056e(%rip)        # e7fbd0 <_DYNAMIC+0x5b8>
  81f662:	mov    0x248(%rsp),%rax
  81f66a:	mov    %rax,0xa0(%rsp)
  81f672:	test   %rax,%rax
  81f675:	je     81fa46 <<gpui_gpu::renderer::RendererState>::render+0x1996>
  81f67b:	mov    0x8(%rsp),%rax
  81f680:	add    $0x108,%rax
  81f686:	mov    %rax,0x360(%rsp)
  81f68e:	jmp    81f6c9 <<gpui_gpu::renderer::RendererState>::render+0x1619>
  81f690:	lea    0x248(%rsp),%rdi
  81f698:	lea    0x300(%rsp),%rsi
  81f6a0:	call   *0x66052a(%rip)        # e7fbd0 <_DYNAMIC+0x5b8>
  81f6a6:	mov    0x248(%rsp),%rax
  81f6ae:	mov    0x10(%rsp),%rcx
  81f6b3:	mov    %rcx,0x50(%rsp)
  81f6b8:	mov    %rax,0xa0(%rsp)
  81f6c0:	test   %rax,%rax
  81f6c3:	je     81fa46 <<gpui_gpu::renderer::RendererState>::render+0x1996>
  81f6c9:	mov    0x250(%rsp),%rdx
  81f6d1:	mov    0x258(%rsp),%rdi
  81f6d9:	mov    %rdi,0x90(%rsp)
  81f6e1:	lea    0x260(%rsp),%rax
  81f6e9:	movups 0x40(%rax),%xmm0
  81f6ed:	lea    0x128(%rsp),%rcx
  81f6f5:	movups %xmm0,0x40(%rcx)
  81f6f9:	movups (%rax),%xmm0
  81f6fc:	movups 0x10(%rax),%xmm1
  81f700:	movups 0x20(%rax),%xmm2
  81f704:	movups 0x30(%rax),%xmm3
  81f708:	movups %xmm3,0x30(%rcx)
  81f70c:	movups %xmm2,0x20(%rcx)
  81f710:	movups %xmm1,0x10(%rcx)
  81f714:	movups %xmm0,(%rcx)
  81f717:	mov    0x8(%rsp),%rax
  81f71c:	movzbl 0x329(%rax),%esi
  81f723:	mov    0xa0(%rsp),%rax
  81f72b:	mov    %rax,0x110(%rsp)
  81f733:	mov    %rdx,0x60(%rsp)
  81f738:	mov    %rdx,0x118(%rsp)
  81f740:	mov    %rdi,0x120(%rsp)
  81f748:	lea    0x110(%rsp),%rdi
  81f750:	call   821530 <gpui_gpu::renderer::compact_group>
  81f755:	mov    0x50(%rsp),%rcx
  81f75a:	lea    0x5(%rcx),%rdx
  81f75e:	test   %al,%al
  81f760:	cmove  %rcx,%rdx
  81f764:	mov    %rdx,0x10(%rsp)
  81f769:	cmpq   $0x0,0x90(%rsp)
  81f772:	je     81f690 <<gpui_gpu::renderer::RendererState>::render+0x15e0>
  81f778:	shlq   $0x2,0x90(%rsp)
  81f781:	xor    $0x1,%al
  81f783:	movzbl %al,%ecx
  81f786:	shl    $0x2,%ecx
  81f789:	lea    0x1(%rcx),%rax
  81f78d:	mov    %rax,0x80(%rsp)
  81f795:	mov    0x10(%rsp),%rax
  81f79a:	lea    (%rax,%rcx,1),%r8
  81f79e:	inc    %r8
  81f7a1:	or     $0x2,%rcx
  81f7a5:	shl    $0x4,%r8
  81f7a9:	mov    %rcx,0x50(%rsp)
  81f7ae:	shl    $0x4,%ecx
  81f7b1:	mov    %rcx,0xd0(%rsp)
  81f7b9:	xor    %ecx,%ecx
  81f7bb:	mov    %r8,0x18(%rsp)
  81f7c0:	mov    0x60(%rsp),%rax
  81f7c5:	mov    %rcx,0x38(%rsp)
  81f7ca:	mov    (%rax,%rcx,1),%edx
  81f7cd:	lea    0x110(%rsp),%rdi
  81f7d5:	mov    0xa0(%rsp),%rsi
  81f7dd:	call   81c970 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81f7e2:	movzbl 0x110(%rsp),%ecx
  81f7ea:	movzbl 0x111(%rsp),%eax
  81f7f2:	movss  0x114(%rsp),%xmm4
  81f7fb:	lea    0x118(%rsp),%rsi
  81f803:	mov    0x10(%rsi),%rdx
  81f807:	mov    %rdx,0x2e0(%rsp)
  81f80f:	movups (%rsi),%xmm0
  81f812:	movaps %xmm0,0x2d0(%rsp)
  81f81a:	cmp    $0x1,%ecx
  81f81d:	je     81f8b2 <<gpui_gpu::renderer::RendererState>::render+0x1802>
  81f823:	movaps %xmm4,0xf0(%rsp)
  81f82b:	mov    0x130(%rsp),%rsi
  81f833:	mov    0x138(%rsp),%edx
  81f83a:	mov    %edx,0x40(%rsp)
  81f83e:	mov    0x13c(%rsp),%edx
  81f845:	mov    %edx,0x28(%rsp)
  81f849:	cmp    $0x3,%ecx
  81f84c:	jne    81f937 <<gpui_gpu::renderer::RendererState>::render+0x1887>
  81f852:	mov    0x2c0(%rsp),%rcx
  81f85a:	mov    (%rcx),%rdi
  81f85d:	test   %rdi,%rdi
  81f860:	je     8204cd <<gpui_gpu::renderer::RendererState>::render+0x241d>
  81f866:	movzbl %al,%edx
  81f869:	call   8226d0 <<gpui_gpu::renderer::images::Images>::metadata>
  81f86e:	mov    %eax,%ecx
  81f870:	shr    $0x20,%rax
  81f874:	mov    %eax,%edx
  81f876:	or     $0x10,%edx
  81f879:	xorps  %xmm0,%xmm0
  81f87c:	movaps 0xf0(%rsp),%xmm1
  81f884:	ucomiss %xmm0,%xmm1
  81f887:	cmovne %edx,%eax
  81f88a:	cmovp  %edx,%eax
  81f88d:	mov    0x28(%rsp),%edx
  81f891:	shl    $0x10,%edx
  81f894:	or     0x40(%rsp),%edx
  81f898:	mov    %ecx,0x220(%rsp)
  81f89f:	mov    %eax,0x224(%rsp)
  81f8a6:	mov    %edx,0x228(%rsp)
  81f8ad:	jmp    81f9d4 <<gpui_gpu::renderer::RendererState>::render+0x1924>
  81f8b2:	movss  0x150(%rsp),%xmm0
  81f8bb:	movss  -0x770957(%rip),%xmm3        # aef6c <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  81f8c3:	mulss  %xmm3,%xmm0
  81f8c7:	movaps %xmm4,%xmm1
  81f8ca:	minss  %xmm0,%xmm1
  81f8ce:	movaps %xmm1,%xmm0
  81f8d1:	cmpunordss %xmm1,%xmm0
  81f8d6:	movaps %xmm0,%xmm2
  81f8d9:	andnps %xmm1,%xmm2
  81f8dc:	andps  %xmm4,%xmm0
  81f8df:	orps   %xmm2,%xmm0
  81f8e2:	movss  0x154(%rsp),%xmm1
  81f8eb:	mulss  %xmm3,%xmm1
  81f8ef:	movaps %xmm0,%xmm2
  81f8f2:	minss  %xmm1,%xmm2
  81f8f6:	movaps %xmm2,%xmm1
  81f8f9:	cmpunordss %xmm2,%xmm1
  81f8fe:	andps  %xmm1,%xmm0
  81f901:	andnps %xmm2,%xmm1
  81f904:	orps   %xmm0,%xmm1
  81f907:	movd   %xmm1,%eax
  81f90b:	and    $0xff800000,%eax
  81f910:	mov    $0x7f000000,%ecx
  81f915:	sub    %eax,%ecx
  81f917:	movl   $0x40000000,0x220(%rsp)
  81f922:	movss  %xmm1,0x224(%rsp)
  81f92b:	mov    %ecx,0x228(%rsp)
  81f932:	jmp    81f9d4 <<gpui_gpu::renderer::RendererState>::render+0x1924>
  81f937:	cmp    $0x2,%cl
  81f93a:	jne    81f98c <<gpui_gpu::renderer::RendererState>::render+0x18dc>
  81f93c:	mov    0x140(%rsp),%rax
  81f944:	mov    0x2e0(%rsp),%rcx
  81f94c:	mov    %rcx,0x120(%rsp)
  81f954:	movaps 0x2d0(%rsp),%xmm0
  81f95c:	movaps %xmm0,0x110(%rsp)
  81f964:	mov    %rsi,0x128(%rsp)
  81f96c:	mov    0x40(%rsp),%ecx
  81f970:	mov    %ecx,0x130(%rsp)
  81f977:	mov    0x28(%rsp),%ecx
  81f97b:	mov    %ecx,0x134(%rsp)
  81f982:	mov    %rax,0x138(%rsp)
  81f98a:	jmp    81f998 <<gpui_gpu::renderer::RendererState>::render+0x18e8>
  81f98c:	movq   $0x0,0x110(%rsp)
  81f998:	movl   $0x0,0x390(%rsp)
  81f9a3:	movq   $0x0,0x388(%rsp)
  81f9af:	lea    0x220(%rsp),%rdi
  81f9b7:	lea    0x110(%rsp),%rsi
  81f9bf:	lea    0x388(%rsp),%rdx
  81f9c7:	mov    0x360(%rsp),%rcx
  81f9cf:	call   81b710 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>>
  81f9d4:	mov    0x10(%rsp),%rdx
  81f9d9:	mov    0x80(%rsp),%rax
  81f9e1:	lea    (%rax,%rdx,1),%rdi
  81f9e5:	mov    0x8(%rsp),%rax
  81f9ea:	mov    0x10(%rax),%rsi
  81f9ee:	cmp    %rsi,%rdi
  81f9f1:	mov    0x18(%rsp),%r8
  81f9f6:	jae    8204f3 <<gpui_gpu::renderer::RendererState>::render+0x2443>
  81f9fc:	mov    0x8(%rax),%rax
  81fa00:	mov    0x228(%rsp),%ecx
  81fa07:	mov    %ecx,0x8(%rax,%r8,1)
  81fa0c:	mov    0x220(%rsp),%rcx
  81fa14:	mov    %rcx,(%rax,%r8,1)
  81fa18:	add    0x50(%rsp),%rdx
  81fa1d:	mov    %rdx,0x10(%rsp)
  81fa22:	add    0xd0(%rsp),%r8
  81fa2a:	mov    0x38(%rsp),%rcx
  81fa2f:	add    $0x4,%rcx
  81fa33:	cmp    %rcx,0x90(%rsp)
  81fa3b:	jne    81f7bb <<gpui_gpu::renderer::RendererState>::render+0x170b>
  81fa41:	jmp    81f690 <<gpui_gpu::renderer::RendererState>::render+0x15e0>
  81fa46:	cmpl   $0x0,0x58(%rsp)
  81fa4b:	je     8204da <<gpui_gpu::renderer::RendererState>::render+0x242a>
  81fa51:	mov    0x8(%rsp),%rax
  81fa56:	mov    0x28(%rax),%rax
  81fa5a:	movq   $0x0,0xd0(%rsp)
  81fa66:	mov    %rax,0x10(%rsp)
  81fa6b:	test   %rax,%rax
  81fa6e:	je     81fb9a <<gpui_gpu::renderer::RendererState>::render+0x1aea>
  81fa74:	mov    0x8(%rsp),%rcx
  81fa79:	mov    0x20(%rcx),%rcx
  81fa7d:	movq   $0x0,0x80(%rsp)
  81fa89:	movq   $0x0,0x50(%rsp)
  81fa92:	movq   $0x0,0x60(%rsp)
  81fa9b:	xor    %esi,%esi
  81fa9d:	jmp    81fac5 <<gpui_gpu::renderer::RendererState>::render+0x1a15>
  81fa9f:	mov    0x18(%rsp),%rdx
  81faa4:	lea    (%rcx,%rdx,8),%rcx
  81faa8:	mov    0xd0(%rsp),%rax
  81fab0:	inc    %eax
  81fab2:	mov    %rax,0xd0(%rsp)
  81faba:	sub    %rdx,0x10(%rsp)
  81fabf:	je     81fb8e <<gpui_gpu::renderer::RendererState>::render+0x1ade>
  81fac5:	mov    0x58(%rsp),%rax
  81faca:	mov    0x10(%rsp),%rdi
  81facf:	cmp    %rdi,%rax
  81fad2:	cmovb  %rax,%rdi
  81fad6:	mov    0xd0(%rsp),%rax
  81fade:	mov    %eax,%edx
  81fae0:	shl    $0x4,%edx
  81fae3:	mov    %r15d,%r8d
  81fae6:	sub    %edx,%r8d
  81fae9:	cmp    $0x10,%r8d
  81faed:	mov    $0x10,%eax
  81faf2:	cmovae %eax,%r8d
  81faf6:	mov    %rdi,0x18(%rsp)
  81fafb:	lea    0x0(,%rdi,8),%r9d
  81fb03:	shl    $0x4,%r8d
  81fb07:	xor    %r10d,%r10d
  81fb0a:	mov    %r14d,%r11d
  81fb0d:	jmp    81fb2e <<gpui_gpu::renderer::RendererState>::render+0x1a7e>
  81fb0f:	movl   $0x80000000,0x4(%rcx,%r10,1)
  81fb18:	incq   0x60(%rsp)
  81fb1d:	add    $0xfffffff0,%r11d
  81fb21:	add    $0x8,%r10
  81fb25:	cmp    %r10,%r9
  81fb28:	je     81fa9f <<gpui_gpu::renderer::RendererState>::render+0x19ef>
  81fb2e:	mov    0x4(%rcx,%r10,1),%edx
  81fb33:	mov    %edx,%edi
  81fb35:	and    $0x8001ffff,%edi
  81fb3b:	cmp    $0x80000001,%edi
  81fb41:	je     81fb0f <<gpui_gpu::renderer::RendererState>::render+0x1a5f>
  81fb43:	mov    %edx,%eax
  81fb45:	and    $0x1ffff,%eax
  81fb4a:	add    %eax,%esi
  81fb4c:	shl    $0x17,%edx
  81fb4f:	or     %esi,%edx
  81fb51:	mov    %eax,%edi
  81fb53:	shl    $0xe,%edi
  81fb56:	and    $0x7f800000,%edi
  81fb5c:	or     %esi,%edi
  81fb5e:	mov    %edx,(%rcx,%r10,1)
  81fb62:	mov    %edi,0x4(%rcx,%r10,1)
  81fb67:	test   %eax,%eax
  81fb69:	je     81fb1d <<gpui_gpu::renderer::RendererState>::render+0x1a6d>
  81fb6b:	cmp    $0x10,%r11d
  81fb6f:	mov    $0x10,%edx
  81fb74:	cmovb  %r11d,%edx
  81fb78:	imul   %r8d,%edx
  81fb7c:	add    %rdx,0x50(%rsp)
  81fb81:	imul   %eax,%edx
  81fb84:	add    %rdx,0x80(%rsp)
  81fb8c:	jmp    81fb1d <<gpui_gpu::renderer::RendererState>::render+0x1a6d>
  81fb8e:	mov    %esi,%eax
  81fb90:	mov    %rax,0xd0(%rsp)
  81fb98:	jmp    81fbb8 <<gpui_gpu::renderer::RendererState>::render+0x1b08>
  81fb9a:	movq   $0x0,0x60(%rsp)
  81fba3:	movq   $0x0,0x50(%rsp)
  81fbac:	movq   $0x0,0x80(%rsp)
  81fbb8:	mov    0x8(%rsp),%rax
  81fbbd:	lea    0x30(%rax),%rdi
  81fbc1:	movq   $0x0,0x40(%rax)
  81fbc9:	movl   $0x0,0xf0(%rsp)
  81fbd4:	mov    %rdi,0xa0(%rsp)
  81fbdc:	mov    0xd0(%rsp),%rsi
  81fbe4:	xor    %edx,%edx
  81fbe6:	call   8228f0 <<alloc::vec::Vec<u32>>::resize>
  81fbeb:	mov    0x8(%rsp),%rax
  81fbf0:	mov    0x10(%rax),%rax
  81fbf4:	mov    %rax,0x28(%rsp)
  81fbf9:	mov    0xc8(%rsp),%rax
  81fc01:	mov    %rax,0x2d0(%rsp)
  81fc09:	movq   $0x0,0x2d8(%rsp)
  81fc15:	mov    0xc0(%rsp),%rax
  81fc1d:	mov    %rax,0x2e0(%rsp)
  81fc25:	mov    0x210(%rsp),%rax
  81fc2d:	mov    %rax,0x2e8(%rsp)
  81fc35:	mov    0x78(%rsp),%eax
  81fc39:	mov    %eax,0x2f0(%rsp)
  81fc40:	jmp    81fc5c <<gpui_gpu::renderer::RendererState>::render+0x1bac>
  81fc42:	mov    0x28(%rsp),%rcx
  81fc47:	lea    -0x5(%rcx),%rax
  81fc4b:	cmpb   $0x0,0xc0(%rsp)
  81fc53:	cmovne %rax,%rcx
  81fc57:	mov    %rcx,0x28(%rsp)
  81fc5c:	lea    0x248(%rsp),%rdi
  81fc64:	lea    0x2d0(%rsp),%rsi
  81fc6c:	call   *0x65ff6e(%rip)        # e7fbe0 <_DYNAMIC+0x5c8>
  81fc72:	mov    0x248(%rsp),%rax
  81fc7a:	mov    %rax,0x40(%rsp)
  81fc7f:	test   %rax,%rax
  81fc82:	je     81feb5 <<gpui_gpu::renderer::RendererState>::render+0x1e05>
  81fc88:	mov    0x250(%rsp),%rcx
  81fc90:	mov    0x258(%rsp),%rdx
  81fc98:	mov    %rdx,0x18(%rsp)
  81fc9d:	mov    0x8(%rsp),%rax
  81fca2:	movzbl 0x329(%rax),%esi
  81fca9:	mov    0x40(%rsp),%rax
  81fcae:	mov    %rax,0x110(%rsp)
  81fcb6:	mov    %rcx,0x90(%rsp)
  81fcbe:	mov    %rcx,0x118(%rsp)
  81fcc6:	mov    %rdx,0x120(%rsp)
  81fcce:	lea    0x260(%rsp),%rax
  81fcd6:	movups (%rax),%xmm0
  81fcd9:	movups 0x10(%rax),%xmm1
  81fcdd:	movdqu 0x20(%rax),%xmm2
  81fce2:	lea    0x128(%rsp),%rdx
  81fcea:	movdqu %xmm2,0x20(%rdx)
  81fcef:	movups %xmm1,0x10(%rdx)
  81fcf3:	movups %xmm0,(%rdx)
  81fcf6:	lea    0x290(%rsp),%rcx
  81fcfe:	movups (%rcx),%xmm0
  81fd01:	movups %xmm0,0x30(%rdx)
  81fd05:	movups 0x40(%rax),%xmm0
  81fd09:	movups %xmm0,0x40(%rdx)
  81fd0d:	lea    0x110(%rsp),%rdi
  81fd15:	call   821530 <gpui_gpu::renderer::compact_group>
  81fd1a:	mov    %al,0xc0(%rsp)
  81fd21:	mov    0x18(%rsp),%rax
  81fd26:	test   %rax,%rax
  81fd29:	je     81fc42 <<gpui_gpu::renderer::RendererState>::render+0x1b92>
  81fd2f:	mov    %rax,%rcx
  81fd32:	shl    $0x2,%rcx
  81fd36:	movzbl 0xc0(%rsp),%eax
  81fd3e:	lea    0x0(,%rax,4),%edx
  81fd45:	or     $0xfffffffffffffffa,%rdx
  81fd49:	xor    %esi,%esi
  81fd4b:	test   %al,%al
  81fd4d:	sete   %sil
  81fd51:	shl    $0x1f,%esi
  81fd54:	mov    %esi,0xc8(%rsp)
  81fd5b:	mov    %rdx,0x38(%rsp)
  81fd60:	mov    0x28(%rsp),%rax
  81fd65:	add    %edx,%eax
  81fd67:	mov    %eax,0x10(%rsp)
  81fd6b:	mov    %rcx,0x18(%rsp)
  81fd70:	mov    0x90(%rsp),%rax
  81fd78:	mov    -0x4(%rax,%rcx,1),%edx
  81fd7c:	lea    0x300(%rsp),%rdi
  81fd84:	mov    0x40(%rsp),%rsi
  81fd89:	call   81c970 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81fd8e:	mov    0x38(%rsp),%rax
  81fd93:	add    %rax,0x28(%rsp)
  81fd98:	mov    0xc8(%rsp),%eax
  81fd9f:	or     0x10(%rsp),%eax
  81fda3:	mov    %eax,0x220(%rsp)
  81fdaa:	lea    0x260(%rsp),%rdx
  81fdb2:	movups (%rdx),%xmm0
  81fdb5:	movups 0x10(%rdx),%xmm1
  81fdb9:	movups 0x20(%rdx),%xmm2
  81fdbd:	lea    0x128(%rsp),%rcx
  81fdc5:	movups %xmm2,0x50(%rcx)
  81fdc9:	movups %xmm1,0x40(%rcx)
  81fdcd:	movups %xmm0,0x30(%rcx)
  81fdd1:	lea    0x290(%rsp),%rax
  81fdd9:	movups (%rax),%xmm0
  81fddc:	movups %xmm0,0x60(%rcx)
  81fde0:	movups 0x40(%rdx),%xmm0
  81fde4:	movups %xmm0,0x80(%rcx)
  81fdeb:	lea    0x338(%rsp),%rax
  81fdf3:	movups (%rax),%xmm0
  81fdf6:	movups %xmm0,0x20(%rcx)
  81fdfa:	lea    0x348(%rsp),%rax
  81fe02:	movups (%rax),%xmm0
  81fe05:	movups %xmm0,0x70(%rcx)
  81fe09:	mov    0x330(%rsp),%rax
  81fe11:	mov    %rax,0x140(%rsp)
  81fe19:	movups 0x300(%rsp),%xmm0
  81fe21:	movups 0x310(%rsp),%xmm1
  81fe29:	movdqu 0x320(%rsp),%xmm2
  81fe32:	movdqa %xmm2,0x130(%rsp)
  81fe3b:	movaps %xmm1,0x120(%rsp)
  81fe43:	movaps %xmm0,0x110(%rsp)
  81fe4b:	mov    0x218(%rsp),%rax
  81fe53:	mov    %rax,0x388(%rsp)
  81fe5b:	mov    0xa0(%rsp),%rax
  81fe63:	mov    %rax,0x390(%rsp)
  81fe6b:	lea    0x220(%rsp),%rax
  81fe73:	mov    %rax,0x398(%rsp)
  81fe7b:	lea    0x110(%rsp),%rdi
  81fe83:	mov    0x58(%rsp),%rsi
  81fe88:	lea    0x388(%rsp),%rdx
  81fe90:	call   81c5d0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>>
  81fe95:	mov    0x10(%rsp),%eax
  81fe99:	add    0x38(%rsp),%eax
  81fe9d:	mov    %eax,0x10(%rsp)
  81fea1:	mov    0x18(%rsp),%rcx
  81fea6:	add    $0xfffffffffffffffc,%rcx
  81feaa:	jne    81fd6b <<gpui_gpu::renderer::RendererState>::render+0x1cbb>
  81feb0:	jmp    81fc42 <<gpui_gpu::renderer::RendererState>::render+0x1b92>
  81feb5:	test   $0x1,%r12b
  81feb9:	je     81ff0c <<gpui_gpu::renderer::RendererState>::render+0x1e5c>
  81febb:	movd   0x244(%rsp),%xmm0
  81fec4:	movd   %xmm0,%eax
  81fec8:	test   %eax,%eax
  81feca:	setns  %cl
  81fecd:	mov    %eax,%edx
  81fecf:	and    $0x7fffffff,%edx
  81fed5:	add    $0xff800000,%edx
  81fedb:	cmp    $0x7f000000,%edx
  81fee1:	setb   %dl
  81fee4:	and    %cl,%dl
  81fee6:	dec    %eax
  81fee8:	cmp    $0x7fffff,%eax
  81feed:	setb   %al
  81fef0:	or     %dl,%al
  81fef2:	movl   $0x2,0xf0(%rsp)
  81fefd:	movd   %xmm0,0x104(%rsp)
  81ff06:	je     8204c3 <<gpui_gpu::renderer::RendererState>::render+0x2413>
  81ff0c:	mov    0x108(%rsp),%r12
  81ff14:	lea    0x18(%r12),%rax
  81ff19:	mov    %rax,0x18(%rsp)
  81ff1e:	mov    0xe8(%rsp),%rax
  81ff26:	add    $0x18,%rax
  81ff2a:	xor    %ecx,%ecx
  81ff2c:	mov    0x378(%rsp),%rdx
  81ff34:	cmp    0x380(%rsp),%rdx
  81ff3c:	setne  %cl
  81ff3f:	xor    %edx,%edx
  81ff41:	cmp    $0x28,%r13d
  81ff45:	sete   %dl
  81ff48:	and    $0x1,%ebp
  81ff4b:	lea    0x0(%rbp,%rdx,4),%edx
  81ff4f:	lea    (%rdx,%rcx,8),%ecx
  81ff52:	or     0xf0(%rsp),%ecx
  81ff59:	movups (%rax),%xmm0
  81ff5c:	movups %xmm0,0x258(%rsp)
  81ff64:	mov    %r14d,0x248(%rsp)
  81ff6c:	mov    %r15d,0x24c(%rsp)
  81ff74:	mov    0x58(%rsp),%rax
  81ff79:	mov    %eax,0x250(%rsp)
  81ff80:	mov    %ecx,0x254(%rsp)
  81ff87:	movss  0x104(%rsp),%xmm0
  81ff90:	movss  %xmm0,0x268(%rsp)
  81ff99:	movq   $0x0,0x26c(%rsp)
  81ffa5:	movl   $0x0,0x274(%rsp)
  81ffb0:	mov    0x8(%rsp),%rbp
  81ffb5:	lea    0x218(%rbp),%rsi
  81ffbc:	movq   $0x0,0x10(%rsp)
  81ffc5:	lea    0x248(%rsp),%rcx
  81ffcd:	mov    $0x30,%r8d
  81ffd3:	mov    0x3c0(%rsp),%r13
  81ffdb:	mov    %r13,%rdi
  81ffde:	mov    %rsi,0x58(%rsp)
  81ffe3:	xor    %edx,%edx
  81ffe5:	call   *0x65fbfd(%rip)        # e7fbe8 <_DYNAMIC+0x5d0>
  81ffeb:	mov    0x8(%rbp),%rcx
  81ffef:	mov    0x10(%rbp),%r8
  81fff3:	shl    $0x4,%r8
  81fff7:	mov    0x2b0(%rsp),%rdi
  81ffff:	mov    %r12,%rsi
  820002:	mov    %r13,%rdx
  820005:	call   81cc10 <<gpui_gpu::renderer::Buffer>::write>
  82000a:	lea    0x268(%rbp),%rdi
  820011:	mov    0x20(%rbp),%rcx
  820015:	mov    0x28(%rbp),%r8
  820019:	shl    $0x3,%r8
  82001d:	mov    %rdi,0x38(%rsp)
  820022:	mov    %r12,%rsi
  820025:	mov    %r13,%rdx
  820028:	call   81cc10 <<gpui_gpu::renderer::Buffer>::write>
  82002d:	lea    0x290(%rbp),%rdi
  820034:	mov    0x38(%rbp),%rcx
  820038:	mov    0x40(%rbp),%r8
  82003c:	shl    $0x2,%r8
  820040:	mov    %rdi,0x218(%rsp)
  820048:	mov    %r12,%rsi
  82004b:	mov    %r13,%rdx
  82004e:	call   81cc10 <<gpui_gpu::renderer::Buffer>::write>
  820053:	lea    0x2b8(%rbp),%rdi
  82005a:	mov    0x50(%rbp),%rcx
  82005e:	mov    0x58(%rbp),%r8
  820062:	shl    $0x5,%r8
  820066:	mov    %rdi,0xe8(%rsp)
  82006e:	mov    %r12,%rsi
  820071:	mov    %r13,%rdx
  820074:	call   81cc10 <<gpui_gpu::renderer::Buffer>::write>
  820079:	cmpq   $0x0,0x310(%rbp)
  820081:	jne    82009d <<gpui_gpu::renderer::RendererState>::render+0x1fed>
  820083:	mov    0x8(%rsp),%rax
  820088:	mov    0x10(%rax),%rax
  82008c:	cmp    $0x1,%rax
  820090:	adc    $0x0,%rax
  820094:	shl    $0x4,%rax
  820098:	mov    %rax,0x10(%rsp)
  82009d:	mov    0x8(%rsp),%rsi
  8200a2:	mov    0x28(%rsi),%rdx
  8200a6:	mov    0x40(%rsi),%rax
  8200aa:	cmp    $0x1,%rdx
  8200ae:	adc    $0x0,%rdx
  8200b2:	shl    $0x3,%rdx
  8200b6:	cmp    $0x1,%rax
  8200ba:	adc    $0x0,%rax
  8200be:	mov    0x58(%rsi),%rcx
  8200c2:	cmp    $0x1,%rcx
  8200c6:	adc    $0x0,%rcx
  8200ca:	add    $0xb0,%rsi
  8200d1:	shl    $0x2,%rax
  8200d5:	shl    $0x5,%rcx
  8200d9:	movq   $0x0,0x110(%rsp)
  8200e5:	mov    0x58(%rsp),%rdi
  8200ea:	mov    %rdi,0x118(%rsp)
  8200f2:	movq   $0x0,0x138(%rsp)
  8200fe:	xorps  %xmm0,%xmm0
  820101:	movups %xmm0,0x120(%rsp)
  820109:	movl   $0x0,0x130(%rsp)
  820114:	mov    0x2b0(%rsp),%rdi
  82011c:	mov    %rdi,0x140(%rsp)
  820124:	movq   $0x0,0x148(%rsp)
  820130:	mov    0x10(%rsp),%rdi
  820135:	mov    %rdi,0x150(%rsp)
  82013d:	movl   $0x1,0x158(%rsp)
  820148:	movq   $0x0,0x160(%rsp)
  820154:	mov    0x38(%rsp),%rdi
  820159:	mov    %rdi,0x168(%rsp)
  820161:	movq   $0x0,0x170(%rsp)
  82016d:	mov    %rdx,0x178(%rsp)
  820175:	movl   $0x2,0x180(%rsp)
  820180:	movq   $0x0,0x188(%rsp)
  82018c:	mov    0x218(%rsp),%rdx
  820194:	mov    %rdx,0x190(%rsp)
  82019c:	movq   $0x0,0x198(%rsp)
  8201a8:	mov    %rax,0x1a0(%rsp)
  8201b0:	movl   $0x3,0x1a8(%rsp)
  8201bb:	movq   $0x4,0x1b0(%rsp)
  8201c7:	mov    %rsi,0x1b8(%rsp)
  8201cf:	movl   $0x4,0x1d0(%rsp)
  8201da:	movq   $0x0,0x1d8(%rsp)
  8201e6:	mov    0xe8(%rsp),%rax
  8201ee:	mov    %rax,0x1e0(%rsp)
  8201f6:	movq   $0x0,0x1e8(%rsp)
  820202:	mov    %rcx,0x1f0(%rsp)
  82020a:	movl   $0x5,0x1f8(%rsp)
  820215:	lea    -0x74b339(%rip),%rax        # d4ee3 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x13d>
  82021c:	mov    %rax,0x318(%rsp)
  820224:	movq   $0xa,0x320(%rsp)
  820230:	mov    0x18(%rsp),%rax
  820235:	mov    %rax,0x300(%rsp)
  82023d:	lea    0x110(%rsp),%rax
  820245:	mov    %rax,0x308(%rsp)
  82024d:	movq   $0x6,0x310(%rsp)
  820259:	lea    0x300(%rsp),%rsi
  820261:	mov    0x108(%rsp),%r12
  820269:	mov    %r12,%rdi
  82026c:	call   *0x65f97e(%rip)        # e7fbf0 <_DYNAMIC+0x5d8>
  820272:	mov    %rax,%r13
  820275:	mov    %rax,0x2d0(%rsp)
  82027d:	lea    0x2d0(%rsp),%rdx
  820285:	mov    %r12,%rdi
  820288:	mov    0x3e8(%rsp),%rsi
  820290:	call   81d270 <<gpui_gpu::renderer::GpuContext>::submit>
  820295:	mov    %rax,0x10(%rsp)
  82029a:	xor    %ebp,%ebp
  82029c:	mov    0x378(%rsp),%rax
  8202a4:	cmp    0x380(%rsp),%rax
  8202ac:	setne  %bpl
  8202b0:	shl    $0x1f,%ebp
  8202b3:	or     %r14d,%ebp
  8202b6:	shl    $0x20,%r15
  8202ba:	or     %r15,%rbp
  8202bd:	mov    (%rbx),%rax
  8202c0:	test   %rax,%rax
  8202c3:	je     8202d4 <<gpui_gpu::renderer::RendererState>::render+0x2224>
  8202c5:	lock decq (%rax)
  8202c9:	jne    8202d4 <<gpui_gpu::renderer::RendererState>::render+0x2224>
  8202cb:	mov    %rbx,%rdi
  8202ce:	call   *0x65f85c(%rip)        # e7fb30 <_DYNAMIC+0x518>
  8202d4:	mov    0x8(%rsp),%rax
  8202d9:	mov    %r13,0x318(%rax)
  8202e0:	mov    %rbp,0x320(%rax)
  8202e7:	mov    0x10(%rax),%r9
  8202eb:	mov    0x28(%rax),%rsi
  8202ef:	mov    0x58(%rax),%rcx
  8202f3:	mov    %rcx,0x18(%rsp)
  8202f8:	shl    $0x4,%r9
  8202fc:	mov    0xd0(%rsp),%rdx
  820304:	lea    (%r9,%rdx,4),%rdi
  820308:	lea    (%rdi,%rsi,8),%rsi
  82030c:	mov    %rcx,%rdi
  82030f:	shl    $0x5,%rdi
  820313:	lea    (%rdi,%rsi,1),%rcx
  820317:	add    $0x30,%rcx
  82031b:	mov    %rcx,0x58(%rsp)
  820320:	mov    0x138(%rax),%esi
  820326:	imul   %rsi,%rsi
  82032a:	mov    0x260(%rax),%r8
  820331:	add    0x238(%rax),%r8
  820338:	add    0x288(%rax),%r8
  82033f:	add    0x2b0(%rax),%r8
  820346:	add    0x2d8(%rax),%r8
  82034d:	mov    0x2f0(%rax),%rdi
  820354:	add    0x2f8(%rax),%rdi
  82035b:	mov    0xe0(%rsp),%r11
  820363:	mov    %r11,%rcx
  820366:	sub    %rdx,%rcx
  820369:	mov    0xb8(%rsp),%r10
  820371:	mov    %r10,%r12
  820374:	mov    0x208(%rsp),%rbp
  82037c:	sub    %rbp,%r12
  82037f:	mov    0x148(%rax),%rbx
  820386:	inc    %rbx
  820389:	mov    $0xffffffffffffffff,%r14
  820390:	cmovne %rbx,%r14
  820394:	mov    (%rax),%rbx
  820397:	shl    $0x4,%rbx
  82039b:	mov    0x18(%rax),%r15
  82039f:	lea    (%rbx,%r15,8),%rbx
  8203a3:	mov    0x30(%rax),%r15
  8203a7:	lea    (%rbx,%r15,4),%rbx
  8203ab:	mov    0x48(%rax),%r15
  8203af:	shl    $0x5,%r15
  8203b3:	add    %rbx,%r15
  8203b6:	mov    0x120(%rax),%rbx
  8203bd:	mov    0x118(%rax),%r13
  8203c4:	mov    %r14,0x148(%rax)
  8203cb:	mov    %r10,0x150(%rax)
  8203d2:	lea    (%r11,%r11,1),%r14
  8203d6:	mov    %r14,0x158(%rax)
  8203dd:	movq   $0x1,0x160(%rax)
  8203e8:	mov    %r10,0x168(%rax)
  8203ef:	mov    %rdx,0x170(%rax)
  8203f6:	mov    %r11,0x178(%rax)
  8203fd:	mov    %rcx,0x180(%rax)
  820404:	mov    0x60(%rsp),%rcx
  820409:	mov    %rcx,0x188(%rax)
  820410:	mov    0x50(%rsp),%rcx
  820415:	mov    %rcx,0x190(%rax)
  82041c:	mov    0x80(%rsp),%rcx
  820424:	mov    %rcx,0x198(%rax)
  82042b:	mov    0x58(%rsp),%rcx
  820430:	mov    %rcx,0x1a0(%rax)
  820437:	mov    %r9,0x1a8(%rax)
  82043e:	mov    0x200(%rsp),%rdx
  820446:	mov    %rdx,0x1b0(%rax)
  82044d:	mov    %rbp,0x1b8(%rax)
  820454:	mov    %r12,0x1c0(%rax)
  82045b:	mov    0x3b0(%rsp),%rcx
  820463:	mov    %rcx,0x1c8(%rax)
  82046a:	mov    %r8,0x1d0(%rax)
  820471:	mov    %rsi,0x1d8(%rax)
  820478:	add    %rbx,%r13
  82047b:	mov    %rbx,0x1e0(%rax)
  820482:	mov    %r13,0x1e8(%rax)
  820489:	mov    %r15,0x1f0(%rax)
  820490:	mov    0x18(%rsp),%rcx
  820495:	mov    %rcx,0x1f8(%rax)
  82049c:	mov    %rdi,0x200(%rax)
  8204a3:	movb   $0x0,0x208(%rax)
  8204aa:	mov    0x30(%rsp),%rdi
  8204af:	mov    0x10(%rsp),%rax
  8204b4:	mov    %rax,0x8(%rdi)
  8204b8:	movl   $0xffffffff,(%rdi)
  8204be:	jmp    81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x111>
  8204c3:	mov    0x30(%rsp),%rdi
  8204c8:	jmp    81e1b3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  8204cd:	lea    0x60dc5c(%rip),%rdi        # e2e130 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x38>
  8204d4:	call   *0x65f71e(%rip)        # e7fbf8 <_DYNAMIC+0x5e0>
  8204da:	lea    -0x74b619(%rip),%rdi        # d4ec8 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x122>
  8204e1:	lea    0x60dc30(%rip),%rdx        # e2e118 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x20>
  8204e8:	mov    $0x37,%esi
  8204ed:	call   *0x65f43d(%rip)        # e7f930 <_DYNAMIC+0x318>
  8204f3:	lea    0x60dc4e(%rip),%rdx        # e2e148 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x50>
  8204fa:	call   *0x65f610(%rip)        # e7fb10 <_DYNAMIC+0x4f8>
  820500:	mov    %rax,%r14
  820503:	mov    0x8(%rsp),%rax
  820508:	mov    %r13,0x318(%rax)
  82050f:	mov    %rbp,0x320(%rax)
  820516:	mov    %r14,%rdi
  820519:	call   e2c400 <_Unwind_Resume@plt>
  82051e:	mov    %rax,%r14
  820521:	lock decq 0x0(%r13)
  820526:	jne    820548 <<gpui_gpu::renderer::RendererState>::render+0x2498>
  820528:	lea    0x2d0(%rsp),%rdi
  820530:	call   *0x65f5fa(%rip)        # e7fb30 <_DYNAMIC+0x518>
  820536:	jmp    820548 <<gpui_gpu::renderer::RendererState>::render+0x2498>
  820538:	call   *0x65f32a(%rip)        # e7f868 <_DYNAMIC+0x250>
  82053e:	mov    %rax,%r14
  820541:	movq   $0x0,(%rbx)
  820548:	mov    %r14,%rdi
  82054b:	call   e2c400 <_Unwind_Resume@plt>
