
FUNCTION <gpui_gpu::renderer::RendererState>::bin_draw bytes=4056 frame=792

/tmp/gpui-descending-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000820550 <<gpui_gpu::renderer::RendererState>::bin_draw>:
  820550:	push   %rbp
  820551:	push   %r15
  820553:	push   %r14
  820555:	push   %r13
  820557:	push   %r12
  820559:	push   %rbx
  82055a:	sub    $0x2e8,%rsp
  820561:	movss  0x88(%rdx),%xmm3
  820569:	movss  -0x7715b5(%rip),%xmm0        # aefbc <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  820571:	movaps %xmm3,%xmm1
  820574:	subss  %xmm0,%xmm1
  820578:	cvttss2si %xmm1,%rax
  82057d:	cvttss2si %xmm3,%r10
  820582:	mov    %r10,%r13
  820585:	sar    $0x3f,%r13
  820589:	and    %rax,%r13
  82058c:	or     %r10,%r13
  82058f:	xor    %eax,%eax
  820591:	xorps  %xmm1,%xmm1
  820594:	ucomiss %xmm1,%xmm3
  820597:	cmovb  %rax,%r13
  82059b:	movss  0x90(%rdx),%xmm4
  8205a3:	movss  -0x7715eb(%rip),%xmm2        # aefc0 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  8205ab:	ucomiss %xmm2,%xmm3
  8205ae:	mov    $0xffffffffffffffff,%r14
  8205b5:	cmova  %r14,%r13
  8205b9:	movaps %xmm4,%xmm3
  8205bc:	subss  %xmm0,%xmm3
  8205c0:	cvttss2si %xmm3,%r10
  8205c5:	cvttss2si %xmm4,%r11
  8205ca:	mov    %r11,%rbx
  8205cd:	sar    $0x3f,%rbx
  8205d1:	and    %r10,%rbx
  8205d4:	or     %r11,%rbx
  8205d7:	ucomiss %xmm1,%xmm4
  8205da:	cmovb  %rax,%rbx
  8205de:	ucomiss %xmm2,%xmm4
  8205e1:	cmova  %r14,%rbx
  8205e5:	movss  0x8c(%rdx),%xmm3
  8205ed:	lea    (%rbx,%r13,1),%r11
  8205f1:	dec    %r11
  8205f4:	shr    $0x4,%r11
  8205f8:	shr    $0x4,%r13
  8205fc:	mov    %r11,%rbp
  8205ff:	sub    %r13,%rbp
  820602:	inc    %rbp
  820605:	movaps %xmm3,%xmm4
  820608:	subss  %xmm0,%xmm4
  82060c:	cvttss2si %xmm4,%r10
  820611:	cvttss2si %xmm3,%r15
  820616:	mov    %r15,%rbx
  820619:	sar    $0x3f,%rbx
  82061d:	and    %r10,%rbx
  820620:	or     %r15,%rbx
  820623:	ucomiss %xmm1,%xmm3
  820626:	cmovb  %rax,%rbx
  82062a:	ucomiss %xmm2,%xmm3
  82062d:	movss  0x94(%rdx),%xmm3
  820635:	cmova  %r14,%rbx
  820639:	movaps %xmm3,%xmm4
  82063c:	subss  %xmm0,%xmm4
  820640:	cvttss2si %xmm4,%r10
  820645:	cvttss2si %xmm3,%r15
  82064a:	mov    %r15,%r12
  82064d:	sar    $0x3f,%r12
  820651:	and    %r10,%r12
  820654:	or     %r15,%r12
  820657:	ucomiss %xmm1,%xmm3
  82065a:	cmovb  %rax,%r12
  82065e:	ucomiss %xmm2,%xmm3
  820661:	cmova  %r14,%r12
  820665:	lea    (%rbx,%r12,1),%r10
  820669:	dec    %r10
  82066c:	shr    $0x4,%r10
  820670:	shr    $0x4,%rbx
  820674:	mov    %r10,%r14
  820677:	sub    %rbx,%r14
  82067a:	inc    %r14
  82067d:	imul   %rbp,%r14
  820681:	add    0x330(%rsp),%r14
  820689:	setb   %al
  82068c:	cmp    $0x400001,%r14
  820693:	setae  %bpl
  820697:	or     %al,%bpl
  82069a:	mov    $0x6,%eax
  82069f:	jne    8206df <<gpui_gpu::renderer::RendererState>::bin_draw+0x18f>
  8206a1:	mov    %r8d,0xac(%rsp)
  8206a9:	mov    %r14,0x170(%rsp)
  8206b1:	mov    %rdi,0x178(%rsp)
  8206b9:	mov    %r13,0xa0(%rsp)
  8206c1:	cmp    %rbx,%r10
  8206c4:	jae    8206f3 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1a3>
  8206c6:	mov    0x178(%rsp),%rdi
  8206ce:	mov    0x170(%rsp),%rax
  8206d6:	mov    %rax,0x8(%rdi)
  8206da:	mov    $0xffffffff,%eax
  8206df:	mov    %eax,(%rdi)
  8206e1:	add    $0x2e8,%rsp
  8206e8:	pop    %rbx
  8206e9:	pop    %r12
  8206eb:	pop    %r13
  8206ed:	pop    %r14
  8206ef:	pop    %r15
  8206f1:	pop    %rbp
  8206f2:	ret
  8206f3:	cmp    0xa0(%rsp),%r11
  8206fb:	jae    820716 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1c6>
  8206fd:	nopl   (%rax)
  820700:	mov    %rbx,%rax
  820703:	cmp    %r10,%rbx
  820706:	adc    $0x0,%rbx
  82070a:	cmp    %r10,%rax
  82070d:	jae    8206c6 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  82070f:	cmp    %r10,%rbx
  820712:	jbe    820700 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1b0>
  820714:	jmp    8206c6 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  820716:	movd   0xa4(%rdx),%xmm0
  82071e:	mov    0x20(%rsi),%r12
  820722:	movdqu 0x98(%rdx),%xmm1
  82072a:	movd   0xa0(%rdx),%xmm2
  820732:	punpckldq %xmm0,%xmm2
  820736:	punpcklqdq %xmm2,%xmm1
  82073a:	movdqa -0x773e32(%rip),%xmm2        # ac910 <anon.fd4379edd0b71335c3c29b3337cd5ea0.320.llvm.353578272256937679+0x110>
  820742:	pand   %xmm1,%xmm2
  820746:	paddd  -0x773bde(%rip),%xmm2        # acb70 <anon.fd4379edd0b71335c3c29b3337cd5ea0.320.llvm.353578272256937679+0x370>
  82074e:	pxor   -0x772426(%rip),%xmm2        # ae330 <anon.630a3fff68f6bca64b568be97512ab45.101.llvm.826976926275214120+0x80>
  820756:	pcmpgtd -0x772fce(%rip),%xmm2        # ad790 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x420>
  82075e:	mov    %rsi,%rax
  820761:	mov    0x28(%rsi),%rsi
  820765:	pandn  %xmm1,%xmm2
  820769:	movmskps %xmm2,%edi
  82076c:	test   %edi,%edi
  82076e:	jne    821494 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf44>
  820774:	ucomiss -0x7719fb(%rip),%xmm0        # aed80 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  82077b:	jne    821494 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf44>
  820781:	jp     821494 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf44>
  820787:	cmpb   $0x0,0x328(%rax)
  82078e:	je     821494 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf44>
  820794:	cmpb   $0x0,(%rdx)
  820797:	jne    821494 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf44>
  82079d:	test   %r9,%r9
  8207a0:	je     82150b <<gpui_gpu::renderer::RendererState>::bin_draw+0xfbb>
  8207a6:	mov    0x328(%rsp),%ebp
  8207ad:	mov    0x320(%rsp),%r13d
  8207b5:	movd   %ecx,%xmm2
  8207b9:	shr    $0x20,%rcx
  8207bd:	movss  0x78(%rdx),%xmm0
  8207c2:	movss  0x80(%rdx),%xmm3
  8207ca:	movss  0x84(%rdx),%xmm4
  8207d2:	cvtss2sd %xmm0,%xmm0
  8207d6:	movss  0x7c(%rdx),%xmm1
  8207db:	cvtss2sd %xmm1,%xmm1
  8207df:	cvtss2sd %xmm3,%xmm14
  8207e4:	addsd  %xmm0,%xmm14
  8207e9:	xorps  %xmm3,%xmm3
  8207ec:	cvtss2sd %xmm4,%xmm3
  8207f0:	addsd  %xmm1,%xmm3
  8207f4:	movsd  %xmm3,0x1a8(%rsp)
  8207fd:	movsd  0x48(%rdx),%xmm6
  820802:	movsd  0x58(%rdx),%xmm7
  820807:	movsd  0x68(%rdx),%xmm8
  82080d:	movss  0x38(%rdx),%xmm3
  820812:	movss  0x3c(%rdx),%xmm4
  820817:	movss  0x40(%rdx),%xmm5
  82081c:	cvtss2sd %xmm3,%xmm3
  820820:	cvtss2sd %xmm5,%xmm5
  820824:	movaps -0x775a7c(%rip),%xmm9        # aadb0 <GCC_except_table0+0xb8>
  82082c:	movaps %xmm3,0x80(%rsp)
  820834:	andps  %xmm9,%xmm3
  820838:	movaps %xmm3,0x70(%rsp)
  82083d:	movaps %xmm5,0x50(%rsp)
  820842:	cvtss2sd %xmm2,%xmm2
  820846:	movsd  %xmm2,0x8(%rsp)
  82084c:	andps  %xmm9,%xmm5
  820850:	movaps %xmm5,0x60(%rsp)
  820855:	movaps %xmm6,%xmm2
  820858:	andps  %xmm9,%xmm2
  82085c:	movaps %xmm2,0x250(%rsp)
  820864:	movaps %xmm7,%xmm2
  820867:	andps  %xmm9,%xmm2
  82086b:	movaps %xmm2,0x230(%rsp)
  820873:	xorps  %xmm3,%xmm3
  820876:	cvtss2sd %xmm4,%xmm3
  82087a:	movaps %xmm8,%xmm2
  82087e:	andps  %xmm9,%xmm2
  820882:	movaps %xmm2,0xf0(%rsp)
  82088a:	movss  0x44(%rdx),%xmm2
  82088f:	cvtss2sd %xmm2,%xmm2
  820893:	movaps %xmm3,0x40(%rsp)
  820898:	andps  %xmm9,%xmm3
  82089c:	movaps %xmm3,0x30(%rsp)
  8208a1:	movaps %xmm2,0x10(%rsp)
  8208a6:	andps  %xmm9,%xmm2
  8208aa:	movaps %xmm2,0x20(%rsp)
  8208af:	movd   %ecx,%xmm2
  8208b3:	cvtss2sd %xmm2,%xmm2
  8208b7:	movsd  %xmm2,(%rsp)
  8208bc:	movsd  0x50(%rdx),%xmm2
  8208c1:	movaps %xmm2,%xmm3
  8208c4:	andps  %xmm9,%xmm3
  8208c8:	movaps %xmm3,0x1d0(%rsp)
  8208d0:	movsd  0x60(%rdx),%xmm3
  8208d5:	movaps %xmm3,%xmm4
  8208d8:	andps  %xmm9,%xmm4
  8208dc:	movaps %xmm4,0x1b0(%rsp)
  8208e4:	movsd  0x70(%rdx),%xmm4
  8208e9:	movaps %xmm4,%xmm5
  8208ec:	andps  %xmm9,%xmm5
  8208f0:	movaps %xmm5,0xb0(%rsp)
  8208f8:	movaps %xmm2,0x1e0(%rsp)
  820900:	cvtsd2ss %xmm2,%xmm2
  820904:	xorps  %xmm5,%xmm5
  820907:	cvtss2sd %xmm2,%xmm5
  82090b:	movaps %xmm6,0x260(%rsp)
  820913:	movaps %xmm6,%xmm2
  820916:	movaps %xmm7,0x240(%rsp)
  82091e:	movlhps %xmm7,%xmm2
  820921:	cvtpd2ps %xmm2,%xmm2
  820925:	cvtps2pd %xmm2,%xmm6
  820928:	movaps %xmm3,0x1c0(%rsp)
  820930:	xorps  %xmm2,%xmm2
  820933:	cvtsd2ss %xmm3,%xmm2
  820937:	xorps  %xmm3,%xmm3
  82093a:	cvtss2sd %xmm2,%xmm3
  82093e:	movaps %xmm8,0x100(%rsp)
  820947:	xorps  %xmm2,%xmm2
  82094a:	cvtsd2ss %xmm8,%xmm2
  82094f:	xorps  %xmm7,%xmm7
  820952:	cvtss2sd %xmm2,%xmm7
  820956:	movaps %xmm4,0xc0(%rsp)
  82095e:	xorps  %xmm2,%xmm2
  820961:	cvtsd2ss %xmm4,%xmm2
  820965:	cvtss2sd %xmm2,%xmm2
  820969:	movaps %xmm6,%xmm4
  82096c:	andps  %xmm9,%xmm4
  820970:	movaps %xmm7,0x120(%rsp)
  820978:	andps  %xmm9,%xmm7
  82097c:	movaps %xmm7,0x110(%rsp)
  820984:	movaps %xmm5,0x220(%rsp)
  82098c:	andps  %xmm9,%xmm5
  820990:	movaps %xmm5,0x210(%rsp)
  820998:	movaps %xmm3,0x200(%rsp)
  8209a0:	andps  %xmm9,%xmm3
  8209a4:	movaps %xmm3,0x1f0(%rsp)
  8209ac:	movaps %xmm2,0xd0(%rsp)
  8209b4:	andps  %xmm2,%xmm9
  8209b8:	movaps %xmm9,0xe0(%rsp)
  8209c1:	movaps %xmm6,0x280(%rsp)
  8209c9:	movhlps %xmm6,%xmm6
  8209cc:	movaps %xmm6,0x2b0(%rsp)
  8209d4:	movaps %xmm4,0x270(%rsp)
  8209dc:	movhlps %xmm4,%xmm4
  8209df:	movaps %xmm4,0x2a0(%rsp)
  8209e7:	mov    %r10,0x198(%rsp)
  8209ef:	movsd  %xmm14,0x98(%rsp)
  8209f9:	nopl   0x0(%rax)
  820a00:	mov    %rbx,%r15
  820a03:	cmp    %r10,%rbx
  820a06:	adc    $0x0,%rbx
  820a0a:	mov    %r15,0x1a0(%rsp)
  820a12:	imul   %r9,%r15
  820a16:	mov    0xa0(%rsp),%rdi
  820a1e:	mov    %rdi,%r8
  820a21:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  820a30:	cmp    %r11,%rdi
  820a33:	adc    $0x0,%r8
  820a37:	lea    (%rdi,%r15,1),%rcx
  820a3b:	mov    %rcx,%rax
  820a3e:	shr    $0x20,%rax
  820a42:	je     820a50 <<gpui_gpu::renderer::RendererState>::bin_draw+0x500>
  820a44:	mov    %rcx,%rax
  820a47:	xor    %edx,%edx
  820a49:	div    %r9
  820a4c:	jmp    820a57 <<gpui_gpu::renderer::RendererState>::bin_draw+0x507>
  820a4e:	xchg   %ax,%ax
  820a50:	mov    %ecx,%eax
  820a52:	xor    %edx,%edx
  820a54:	div    %r9d
  820a57:	shl    $0x4,%edx
  820a5a:	shl    $0x4,%eax
  820a5d:	lea    0x10(%rdx),%r10d
  820a61:	cmp    %r10d,%r13d
  820a64:	cmovb  %r13d,%r10d
  820a68:	lea    0x10(%rax),%r14d
  820a6c:	cmp    %r14d,%ebp
  820a6f:	cmovb  %ebp,%r14d
  820a73:	xorps  %xmm12,%xmm12
  820a77:	cvtsi2sd %edx,%xmm12
  820a7c:	ucomisd %xmm12,%xmm0
  820a81:	ja     820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820a83:	mov    %eax,%eax
  820a85:	xorps  %xmm2,%xmm2
  820a88:	cvtsi2sd %rax,%xmm2
  820a8d:	ucomisd %xmm2,%xmm1
  820a91:	ja     820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820a93:	xorps  %xmm6,%xmm6
  820a96:	cvtsi2sd %r10d,%xmm6
  820a9b:	ucomisd %xmm14,%xmm6
  820aa0:	ja     820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820aa2:	xorps  %xmm13,%xmm13
  820aa6:	cvtsi2sd %r14d,%xmm13
  820aab:	ucomisd 0x1a8(%rsp),%xmm13
  820ab5:	jbe    820ae8 <<gpui_gpu::renderer::RendererState>::bin_draw+0x598>
  820ab7:	nopw   0x0(%rax,%rax,1)
  820ac0:	cmp    %rsi,%rcx
  820ac3:	jae    8214fb <<gpui_gpu::renderer::RendererState>::bin_draw+0xfab>
  820ac9:	incl   0x4(%r12,%rcx,8)
  820ace:	cmp    %r11,%rdi
  820ad1:	jae    821470 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf20>
  820ad7:	mov    %r8,%rdi
  820ada:	cmp    %r11,%r8
  820add:	jbe    820a30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x4e0>
  820ae3:	jmp    821470 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf20>
  820ae8:	unpcklpd %xmm2,%xmm12
  820aed:	addpd  -0x773a26(%rip),%xmm12        # ad0d0 <anon.a16d5d421a76dfd8c37a17b53540311d.58.llvm.14190004212411149437+0x270>
  820af6:	movapd %xmm12,%xmm10
  820afb:	mulpd  0x280(%rsp),%xmm10
  820b05:	movapd %xmm10,%xmm15
  820b0a:	unpckhpd %xmm10,%xmm15
  820b0f:	movapd %xmm10,%xmm2
  820b14:	addsd  %xmm15,%xmm2
  820b19:	addsd  0x120(%rsp),%xmm2
  820b22:	subsd  0x80(%rsp),%xmm2
  820b2b:	movapd 0x270(%rsp),%xmm8
  820b35:	mulpd  %xmm12,%xmm8
  820b3a:	movapd %xmm8,%xmm9
  820b3f:	unpckhpd %xmm8,%xmm9
  820b44:	movapd %xmm8,%xmm3
  820b49:	addsd  %xmm9,%xmm3
  820b4e:	addsd  0x110(%rsp),%xmm3
  820b57:	addsd  0x70(%rsp),%xmm3
  820b5d:	addsd  0x60(%rsp),%xmm3
  820b63:	addsd  -0x7712f3(%rip),%xmm3        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820b6b:	mulsd  -0x771373(%rip),%xmm3        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820b73:	addsd  0x8(%rsp),%xmm3
  820b79:	ucomisd %xmm2,%xmm3
  820b7d:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820b83:	movapd 0x50(%rsp),%xmm4
  820b89:	subsd  %xmm2,%xmm4
  820b8d:	ucomisd %xmm4,%xmm3
  820b91:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820b97:	movapd %xmm12,%xmm7
  820b9c:	unpckhpd %xmm12,%xmm7
  820ba1:	movapd 0x240(%rsp),%xmm11
  820bab:	mulsd  %xmm7,%xmm11
  820bb0:	movapd 0x230(%rsp),%xmm3
  820bb9:	mulsd  %xmm7,%xmm3
  820bbd:	movapd 0x260(%rsp),%xmm2
  820bc6:	mulsd  %xmm12,%xmm2
  820bcb:	movapd %xmm2,0x140(%rsp)
  820bd4:	addsd  %xmm11,%xmm2
  820bd9:	addsd  0x100(%rsp),%xmm2
  820be2:	subsd  0x80(%rsp),%xmm2
  820beb:	movapd 0x250(%rsp),%xmm4
  820bf4:	mulsd  %xmm12,%xmm4
  820bf9:	movsd  %xmm4,0x190(%rsp)
  820c02:	addsd  %xmm3,%xmm4
  820c06:	addsd  0xf0(%rsp),%xmm4
  820c0f:	addsd  0x70(%rsp),%xmm4
  820c15:	addsd  0x60(%rsp),%xmm4
  820c1b:	addsd  -0x7713ab(%rip),%xmm4        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820c23:	mulsd  -0x770e53(%rip),%xmm4        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820c2b:	ucomisd %xmm2,%xmm4
  820c2f:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820c35:	movapd 0x50(%rsp),%xmm5
  820c3b:	subsd  %xmm2,%xmm5
  820c3f:	ucomisd %xmm5,%xmm4
  820c43:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820c49:	movapd %xmm7,%xmm4
  820c4d:	mulsd  0x200(%rsp),%xmm4
  820c56:	movapd %xmm7,%xmm2
  820c5a:	mulsd  0x1f0(%rsp),%xmm2
  820c63:	movapd %xmm12,%xmm5
  820c68:	mulsd  0x220(%rsp),%xmm5
  820c71:	movsd  %xmm5,0x188(%rsp)
  820c7a:	movapd %xmm4,0x130(%rsp)
  820c83:	addsd  %xmm4,%xmm5
  820c87:	addsd  0xd0(%rsp),%xmm5
  820c90:	subsd  0x40(%rsp),%xmm5
  820c96:	movapd %xmm12,%xmm4
  820c9b:	mulsd  0x210(%rsp),%xmm4
  820ca4:	movsd  %xmm4,0x180(%rsp)
  820cad:	addsd  %xmm2,%xmm4
  820cb1:	addsd  0xe0(%rsp),%xmm4
  820cba:	addsd  0x30(%rsp),%xmm4
  820cc0:	addsd  0x20(%rsp),%xmm4
  820cc6:	addsd  -0x771456(%rip),%xmm4        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820cce:	mulsd  -0x7714d6(%rip),%xmm4        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820cd6:	addsd  (%rsp),%xmm4
  820cdb:	ucomisd %xmm5,%xmm4
  820cdf:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820ce5:	movapd 0x10(%rsp),%xmm14
  820cec:	subsd  %xmm5,%xmm14
  820cf1:	ucomisd %xmm14,%xmm4
  820cf6:	movsd  0x98(%rsp),%xmm14
  820d00:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820d06:	movapd 0x1c0(%rsp),%xmm4
  820d0f:	mulsd  %xmm7,%xmm4
  820d13:	mulsd  0x1b0(%rsp),%xmm7
  820d1c:	movapd 0x1e0(%rsp),%xmm5
  820d25:	mulsd  %xmm12,%xmm5
  820d2a:	movapd %xmm5,0x2c0(%rsp)
  820d33:	movapd %xmm4,0x2d0(%rsp)
  820d3c:	addsd  %xmm4,%xmm5
  820d40:	addsd  0xc0(%rsp),%xmm5
  820d49:	subsd  0x40(%rsp),%xmm5
  820d4f:	mulsd  0x1d0(%rsp),%xmm12
  820d59:	movapd %xmm12,%xmm4
  820d5e:	addsd  %xmm7,%xmm4
  820d62:	addsd  0xb0(%rsp),%xmm4
  820d6b:	addsd  0x30(%rsp),%xmm4
  820d71:	addsd  0x20(%rsp),%xmm4
  820d77:	addsd  -0x771507(%rip),%xmm4        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820d7f:	mulsd  -0x770faf(%rip),%xmm4        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820d87:	ucomisd %xmm5,%xmm4
  820d8b:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820d91:	movapd 0x10(%rsp),%xmm14
  820d98:	subsd  %xmm5,%xmm14
  820d9d:	ucomisd %xmm14,%xmm4
  820da2:	movsd  0x98(%rsp),%xmm14
  820dac:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820db2:	addsd  -0x771832(%rip),%xmm6        # af588 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  820dba:	movapd %xmm6,%xmm4
  820dbe:	mulsd  0x280(%rsp),%xmm4
  820dc7:	movsd  %xmm4,0x168(%rsp)
  820dd0:	addsd  %xmm4,%xmm15
  820dd5:	addsd  0x120(%rsp),%xmm15
  820ddf:	subsd  0x80(%rsp),%xmm15
  820de9:	movapd 0x270(%rsp),%xmm4
  820df2:	mulsd  %xmm6,%xmm4
  820df6:	movsd  %xmm4,0x160(%rsp)
  820dff:	addsd  %xmm4,%xmm9
  820e04:	addsd  0x110(%rsp),%xmm9
  820e0e:	addsd  0x70(%rsp),%xmm9
  820e15:	addsd  0x60(%rsp),%xmm9
  820e1c:	addsd  -0x7715ad(%rip),%xmm9        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820e25:	mulsd  -0x77162e(%rip),%xmm9        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820e2e:	addsd  0x8(%rsp),%xmm9
  820e35:	ucomisd %xmm15,%xmm9
  820e3a:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820e40:	movapd 0x50(%rsp),%xmm4
  820e46:	subsd  %xmm15,%xmm4
  820e4b:	ucomisd %xmm4,%xmm9
  820e50:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820e56:	movapd 0x260(%rsp),%xmm15
  820e60:	mulsd  %xmm6,%xmm15
  820e65:	addsd  %xmm15,%xmm11
  820e6a:	addsd  0x100(%rsp),%xmm11
  820e74:	subsd  0x80(%rsp),%xmm11
  820e7e:	movapd 0x250(%rsp),%xmm4
  820e87:	mulsd  %xmm6,%xmm4
  820e8b:	movsd  %xmm4,0x158(%rsp)
  820e94:	addsd  %xmm4,%xmm3
  820e98:	addsd  0xf0(%rsp),%xmm3
  820ea1:	addsd  0x70(%rsp),%xmm3
  820ea7:	addsd  0x60(%rsp),%xmm3
  820ead:	addsd  -0x77163d(%rip),%xmm3        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820eb5:	mulsd  -0x7710e5(%rip),%xmm3        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820ebd:	ucomisd %xmm11,%xmm3
  820ec2:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820ec8:	movapd 0x50(%rsp),%xmm4
  820ece:	subsd  %xmm11,%xmm4
  820ed3:	ucomisd %xmm4,%xmm3
  820ed7:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820edd:	movapd %xmm6,%xmm3
  820ee1:	mulsd  0x220(%rsp),%xmm3
  820eea:	movsd  %xmm3,0x150(%rsp)
  820ef3:	movapd 0x130(%rsp),%xmm5
  820efc:	addsd  %xmm3,%xmm5
  820f00:	addsd  0xd0(%rsp),%xmm5
  820f09:	subsd  0x40(%rsp),%xmm5
  820f0f:	movapd %xmm6,%xmm3
  820f13:	mulsd  0x210(%rsp),%xmm3
  820f1c:	movsd  %xmm3,0x130(%rsp)
  820f25:	addsd  %xmm3,%xmm2
  820f29:	addsd  0xe0(%rsp),%xmm2
  820f32:	addsd  0x30(%rsp),%xmm2
  820f38:	addsd  0x20(%rsp),%xmm2
  820f3e:	addsd  -0x7716ce(%rip),%xmm2        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820f46:	mulsd  -0x77174e(%rip),%xmm2        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820f4e:	addsd  (%rsp),%xmm2
  820f53:	ucomisd %xmm5,%xmm2
  820f57:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820f5d:	movapd 0x10(%rsp),%xmm3
  820f63:	subsd  %xmm5,%xmm3
  820f67:	ucomisd %xmm3,%xmm2
  820f6b:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820f71:	movapd 0x1e0(%rsp),%xmm2
  820f7a:	mulsd  %xmm6,%xmm2
  820f7e:	movapd %xmm2,0x290(%rsp)
  820f87:	movapd 0x2d0(%rsp),%xmm4
  820f90:	addsd  %xmm2,%xmm4
  820f94:	addsd  0xc0(%rsp),%xmm4
  820f9d:	subsd  0x40(%rsp),%xmm4
  820fa3:	mulsd  0x1d0(%rsp),%xmm6
  820fac:	addsd  %xmm6,%xmm7
  820fb0:	addsd  0xb0(%rsp),%xmm7
  820fb9:	addsd  0x30(%rsp),%xmm7
  820fbf:	addsd  0x20(%rsp),%xmm7
  820fc5:	addsd  -0x771755(%rip),%xmm7        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820fcd:	mulsd  -0x7711fd(%rip),%xmm7        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820fd5:	ucomisd %xmm4,%xmm7
  820fd9:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820fdf:	movapd 0x10(%rsp),%xmm2
  820fe5:	subsd  %xmm4,%xmm2
  820fe9:	ucomisd %xmm2,%xmm7
  820fed:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820ff3:	addsd  -0x771a74(%rip),%xmm13        # af588 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  820ffc:	movapd %xmm13,%xmm3
  821001:	mulsd  0x2b0(%rsp),%xmm3
  82100a:	movapd %xmm13,%xmm2
  82100f:	mulsd  0x2a0(%rsp),%xmm2
  821018:	addsd  %xmm3,%xmm10
  82101d:	addsd  0x120(%rsp),%xmm10
  821027:	subsd  0x80(%rsp),%xmm10
  821031:	addsd  %xmm2,%xmm8
  821036:	addsd  0x110(%rsp),%xmm8
  821040:	addsd  0x70(%rsp),%xmm8
  821047:	addsd  0x60(%rsp),%xmm8
  82104e:	addsd  -0x7717df(%rip),%xmm8        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821057:	mulsd  -0x771860(%rip),%xmm8        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  821060:	addsd  0x8(%rsp),%xmm8
  821067:	ucomisd %xmm10,%xmm8
  82106c:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821072:	movapd 0x50(%rsp),%xmm4
  821078:	subsd  %xmm10,%xmm4
  82107d:	ucomisd %xmm4,%xmm8
  821082:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821088:	movapd 0x240(%rsp),%xmm7
  821091:	mulsd  %xmm13,%xmm7
  821096:	movapd 0x230(%rsp),%xmm5
  82109f:	mulsd  %xmm13,%xmm5
  8210a4:	movapd 0x140(%rsp),%xmm4
  8210ad:	addsd  %xmm7,%xmm4
  8210b1:	addsd  0x100(%rsp),%xmm4
  8210ba:	subsd  0x80(%rsp),%xmm4
  8210c3:	movsd  0x190(%rsp),%xmm10
  8210cd:	addsd  %xmm5,%xmm10
  8210d2:	addsd  0xf0(%rsp),%xmm10
  8210dc:	addsd  0x70(%rsp),%xmm10
  8210e3:	addsd  0x60(%rsp),%xmm10
  8210ea:	addsd  -0x77187b(%rip),%xmm10        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8210f3:	mulsd  -0x771324(%rip),%xmm10        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  8210fc:	ucomisd %xmm4,%xmm10
  821101:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821107:	movapd %xmm4,%xmm8
  82110c:	movapd 0x50(%rsp),%xmm4
  821112:	subsd  %xmm8,%xmm4
  821117:	ucomisd %xmm4,%xmm10
  82111c:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821122:	movapd %xmm13,%xmm8
  821127:	mulsd  0x200(%rsp),%xmm8
  821131:	movapd %xmm13,%xmm10
  821136:	mulsd  0x1f0(%rsp),%xmm10
  821140:	movsd  0x188(%rsp),%xmm9
  82114a:	addsd  %xmm8,%xmm9
  82114f:	addsd  0xd0(%rsp),%xmm9
  821159:	subsd  0x40(%rsp),%xmm9
  821160:	movapd %xmm15,%xmm4
  821165:	movsd  0x180(%rsp),%xmm15
  82116f:	movsd  %xmm10,0x140(%rsp)
  821179:	addsd  %xmm10,%xmm15
  82117e:	addsd  0xe0(%rsp),%xmm15
  821188:	addsd  0x30(%rsp),%xmm15
  82118f:	addsd  0x20(%rsp),%xmm15
  821196:	addsd  -0x771927(%rip),%xmm15        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  82119f:	mulsd  -0x7719a8(%rip),%xmm15        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  8211a8:	addsd  (%rsp),%xmm15
  8211ae:	ucomisd %xmm9,%xmm15
  8211b3:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  8211b9:	movapd %xmm9,%xmm10
  8211be:	movapd 0x10(%rsp),%xmm9
  8211c5:	subsd  %xmm10,%xmm9
  8211ca:	ucomisd %xmm9,%xmm15
  8211cf:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  8211d5:	movapd 0x1c0(%rsp),%xmm9
  8211df:	mulsd  %xmm13,%xmm9
  8211e4:	mulsd  0x1b0(%rsp),%xmm13
  8211ee:	movapd 0x2c0(%rsp),%xmm10
  8211f8:	addsd  %xmm9,%xmm10
  8211fd:	addsd  0xc0(%rsp),%xmm10
  821207:	subsd  0x40(%rsp),%xmm10
  82120e:	addsd  %xmm13,%xmm12
  821213:	addsd  0xb0(%rsp),%xmm12
  82121d:	addsd  0x30(%rsp),%xmm12
  821224:	addsd  0x20(%rsp),%xmm12
  82122b:	addsd  -0x7719bc(%rip),%xmm12        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821234:	mulsd  -0x771465(%rip),%xmm12        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  82123d:	ucomisd %xmm10,%xmm12
  821242:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821248:	movapd %xmm10,%xmm11
  82124d:	movapd 0x10(%rsp),%xmm10
  821254:	subsd  %xmm11,%xmm10
  821259:	ucomisd %xmm10,%xmm12
  82125e:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821264:	movsd  0x168(%rsp),%xmm10
  82126e:	addsd  %xmm3,%xmm10
  821273:	addsd  0x120(%rsp),%xmm10
  82127d:	subsd  0x80(%rsp),%xmm10
  821287:	movsd  0x160(%rsp),%xmm11
  821291:	addsd  %xmm2,%xmm11
  821296:	addsd  0x110(%rsp),%xmm11
  8212a0:	addsd  0x70(%rsp),%xmm11
  8212a7:	addsd  0x60(%rsp),%xmm11
  8212ae:	addsd  -0x771a3f(%rip),%xmm11        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8212b7:	mulsd  -0x771ac0(%rip),%xmm11        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  8212c0:	addsd  0x8(%rsp),%xmm11
  8212c7:	ucomisd %xmm10,%xmm11
  8212cc:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  8212d2:	movapd %xmm4,%xmm15
  8212d7:	movapd 0x50(%rsp),%xmm2
  8212dd:	subsd  %xmm10,%xmm2
  8212e2:	ucomisd %xmm2,%xmm11
  8212e7:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  8212ed:	addsd  %xmm7,%xmm15
  8212f2:	addsd  0x100(%rsp),%xmm15
  8212fc:	subsd  0x80(%rsp),%xmm15
  821306:	movsd  0x158(%rsp),%xmm2
  82130f:	addsd  %xmm5,%xmm2
  821313:	addsd  0xf0(%rsp),%xmm2
  82131c:	addsd  0x70(%rsp),%xmm2
  821322:	addsd  0x60(%rsp),%xmm2
  821328:	addsd  -0x771ab8(%rip),%xmm2        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821330:	mulsd  -0x771560(%rip),%xmm2        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  821338:	ucomisd %xmm15,%xmm2
  82133d:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821343:	movapd %xmm2,%xmm3
  821347:	movapd 0x50(%rsp),%xmm2
  82134d:	subsd  %xmm15,%xmm2
  821352:	ucomisd %xmm2,%xmm3
  821356:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  82135c:	movsd  0x150(%rsp),%xmm2
  821365:	addsd  %xmm8,%xmm2
  82136a:	addsd  0xd0(%rsp),%xmm2
  821373:	subsd  0x40(%rsp),%xmm2
  821379:	movsd  0x130(%rsp),%xmm5
  821382:	addsd  0x140(%rsp),%xmm5
  82138b:	addsd  0xe0(%rsp),%xmm5
  821394:	addsd  0x30(%rsp),%xmm5
  82139a:	addsd  0x20(%rsp),%xmm5
  8213a0:	addsd  -0x771b30(%rip),%xmm5        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8213a8:	mulsd  -0x771bb0(%rip),%xmm5        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  8213b0:	addsd  (%rsp),%xmm5
  8213b5:	ucomisd %xmm2,%xmm5
  8213b9:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  8213bf:	movapd %xmm2,%xmm3
  8213c3:	movapd 0x10(%rsp),%xmm2
  8213c9:	subsd  %xmm3,%xmm2
  8213cd:	ucomisd %xmm2,%xmm5
  8213d1:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  8213d7:	movapd 0x290(%rsp),%xmm2
  8213e0:	addsd  %xmm9,%xmm2
  8213e5:	addsd  0xc0(%rsp),%xmm2
  8213ee:	subsd  0x40(%rsp),%xmm2
  8213f4:	addsd  %xmm13,%xmm6
  8213f9:	addsd  0xb0(%rsp),%xmm6
  821402:	addsd  0x30(%rsp),%xmm6
  821408:	addsd  0x20(%rsp),%xmm6
  82140e:	addsd  -0x771b9e(%rip),%xmm6        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821416:	mulsd  -0x771646(%rip),%xmm6        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  82141e:	ucomisd %xmm2,%xmm6
  821422:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821428:	movapd %xmm2,%xmm3
  82142c:	movapd 0x10(%rsp),%xmm2
  821432:	subsd  %xmm3,%xmm2
  821436:	ucomisd %xmm2,%xmm6
  82143a:	jae    820ac0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821440:	cmp    %rsi,%rcx
  821443:	jae    821518 <<gpui_gpu::renderer::RendererState>::bin_draw+0xfc8>
  821449:	mov    0xac(%rsp),%eax
  821450:	mov    %eax,(%r12,%rcx,8)
  821454:	movl   $0x80000001,0x4(%r12,%rcx,8)
  82145d:	movsd  0x98(%rsp),%xmm14
  821467:	cmp    %r11,%rdi
  82146a:	jb     820ad7 <<gpui_gpu::renderer::RendererState>::bin_draw+0x587>
  821470:	mov    0x198(%rsp),%r10
  821478:	cmp    %r10,0x1a0(%rsp)
  821480:	jae    8206c6 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  821486:	cmp    %r10,%rbx
  821489:	jbe    820a00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x4b0>
  82148f:	jmp    8206c6 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  821494:	mov    %rbx,%rax
  821497:	nopw   0x0(%rax,%rax,1)
  8214a0:	cmp    %r10,%rbx
  8214a3:	adc    $0x0,%rax
  8214a7:	mov    %rbx,%rdx
  8214aa:	imul   %r9,%rdx
  8214ae:	mov    0xa0(%rsp),%rdi
  8214b6:	cs nopw 0x0(%rax,%rax,1)
  8214c0:	lea    (%rdi,%rdx,1),%rcx
  8214c4:	cmp    %rsi,%rcx
  8214c7:	jae    8214fb <<gpui_gpu::renderer::RendererState>::bin_draw+0xfab>
  8214c9:	cmp    %r11,%rdi
  8214cc:	mov    %rdi,%r8
  8214cf:	adc    $0x0,%r8
  8214d3:	incl   0x4(%r12,%rcx,8)
  8214d8:	cmp    %r11,%rdi
  8214db:	jae    8214e5 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf95>
  8214dd:	mov    %r8,%rdi
  8214e0:	cmp    %r11,%r8
  8214e3:	jbe    8214c0 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf70>
  8214e5:	cmp    %r10,%rbx
  8214e8:	jae    8206c6 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  8214ee:	mov    %rax,%rbx
  8214f1:	cmp    %r10,%rax
  8214f4:	jbe    8214a0 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf50>
  8214f6:	jmp    8206c6 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  8214fb:	lea    0x60cca6(%rip),%rdx        # e2e1a8 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xb0>
  821502:	mov    %rcx,%rdi
  821505:	call   *0x65e605(%rip)        # e7fb10 <_DYNAMIC+0x4f8>
  82150b:	lea    0x60cd86(%rip),%rdi        # e2e298 <anon.e7af5e0dba0d7261d22cb76253955a85.28.llvm.5458571228094894073+0x10>
  821512:	call   *0x65e768(%rip)        # e7fc80 <_DYNAMIC+0x668>
  821518:	lea    0x60cca1(%rip),%rdx        # e2e1c0 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xc8>
  82151f:	mov    %rcx,%rdi
  821522:	call   *0x65e5e8(%rip)        # e7fb10 <_DYNAMIC+0x4f8>
