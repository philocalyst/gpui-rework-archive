# Descending-cursor publication audit

The complete production diff from sealed 6bf changes only sampled_tile,
take_reference, their comments and intermediate-invariant test assertions.
All constants, forward admission, counters, reverse traversal and publication
regions remain byte-identical. source-audit.json checks unchanged source regions.
The descending-cursor proof and qualification-intent.md cover the new private
intermediate words. The following route audit is inherited unchanged because
those routes have no source delta.

## Every publication/replay/patch route

RendererState::render delegates to private render_observed. Its context check and
entry packet revocation precede scratch preparation. Forward validation, packing,
original visit cap and existing full_tile proofs are unchanged. Normalization
builds transient words; the complete reverse group/placement/visit traversal stays
and consumes exactly c visits per nonuniform tile. No hidden early exit is added.
The suffix theorem from the sealed 555 proof establishes full exhaustion.

The only self.tiles.write is after this completed reverse pass and tone/profile
admission, alongside records/references/corrections uploads. Binding creation and
context.submit follow; only then is packet Some and the full Stats published.
Errors before this point cannot publish partially transient endpoints or replace
last-successful Stats. A later render clears/resizes the entire ranges array.
Queued earlier GPU submissions retain ordinary queue ordering/leases; CPU scratch
mutation alone does not change the previously uploaded tile buffer.

redraw reads the retained successful Packet/bindings and makes no tile/reference
write. Wrong-target rejection preserves the valid packet; invalid diagnostic mode
changes revoke it. prepare_slots only checks a banked admitted packet and paint
edits. GpuSlotCommit takes that packet, writes only draw-bank colors, submits and
restores it; no ranges/references change. PaintRenderer full render uses the same
render_observed; its paint commit similarly takes the admitted packet, writes only
draw color words, submits and restores it. Proof-invalidating alpha/exceptional
opaque RGB edits retain the existing rejection behavior. Owned convenience API
only delegates to these paths. No public entry writes a caller-supplied tile packet.

Therefore every successful upload sees exhausted original words; replay and all
paint routes retain those words. No mutable PreparedScene header is trusted as
an identity; all existing target/header/per-draw checks remain. No new retained
field, allocation, dependency, unsafe code, source exception or SIMD policy fork.
The shipping float predicate/kernel contract is inherited, not strengthened.

