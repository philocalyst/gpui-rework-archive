from pathlib import Path
import hashlib,json,subprocess
ROOT=Path('/tmp/gpui-descending-csr-sol');OUT=Path('/tmp/gpui-descending-csr-evidence')
BASE='7a5e1619a27010ec63f6c27506a6d1fcd113f67c';CAND='1c97566cf0a7140d4f258deab136342a609d5755'
def git(*args):return subprocess.check_output(['git','-c','safe.directory='+str(ROOT),'-C',str(ROOT),*args])
def source(ref,path):return git('show',ref+':reactivity/crates/gpu/'+path).decode()
a=source(BASE,'src/renderer.rs');b=source(CAND,'src/renderer.rs')
sa=source(BASE,'src/shader.rs');sb=source(CAND,'src/shader.rs')
def region(s,start,end):return s[s.index(start):s.index(end,s.index(start))]
checks={}
for name in ['tile_count','clip_residual','tile_bounds','full_tile','visit','validate_draw']:
 def f(s):
  start=s.index('fn '+name+'(');return s[start:s.index('\n}',start)+2]
 checks[name+'_byte_identical']=f(a)==f(b)
checks['record_writers_byte_identical']=region(a,'fn float_word(','struct Buffer {')==region(b,'fn float_word(','struct Buffer {')
checks['context_pipeline_byte_identical']=region(a,'impl GpuContext {','impl RendererState {')==region(b,'impl GpuContext {','impl RendererState {')
checks['resource_patch_walk_byte_identical']=region(a,'        images::prepare(','        let mut offset = 0;')==region(b,'        images::prepare(','        let mut offset = 0;')
checks['redraw_correction_and_atlas_byte_identical']=region(a,'    pub fn redraw(','    #[allow(clippy::too_many_arguments)]')==region(b,'    pub fn redraw(','    #[allow(clippy::too_many_arguments)]') and region(a,'    fn prepare_atlas(','fn tile_count(')==region(b,'    fn prepare_atlas(','// Endpoint spare bits')
checks['no_cursor_vector_or_reverse_ordinal']='cursors' not in b and 'reverse_ordinal' not in b
checks['single_normalization_counter_path']=b.count('sample_draw_evaluations +=')==1 and 'for (tile, range) in self.ranges.iter().enumerate()' not in b
checks['shader_all_float_helpers_byte_identical']=region(sa,'#[wgsl_rs::wgsl]','    #[fragment]')==region(sb,'#[wgsl_rs::wgsl]','    #[fragment]')
checks['shader_sample_loops_byte_identical']=sa[sa.index('        if (globals.viewport.w & 8) != 0 {\n            return banked_fragment'):]==sb[sb.index('        if (globals.viewport.w & 8) != 0 {\n            return banked_fragment'):]
changed=git('diff','--name-only',BASE,CAND,'--','reactivity/crates/gpu').decode().splitlines()
checks['only_renderer_production_changed']=set(changed)=={'reactivity/crates/gpu/src/renderer.rs','reactivity/crates/gpu/tests/render.rs'}
checks['entire_shader_source_byte_identical']=sa==sb
prior=source('5559828a4f6d093401cc374654f634b4d8fb9ddb','src/renderer.rs')
checks['normalization_reverse_unchanged_from555']=region(prior,'        let mut offset = 0;','        let (tone, exposure)')==region(b,'        let mut offset = 0;','        let (tone, exposure)')
checks['upload_submission_stats_and_replay_unchanged_from555']=region(prior,'        let (tone, exposure)','    fn correction(')==region(b,'        let (tone, exposure)','    fn correction(')
checks['working_tree_clean']=not git('status','--porcelain')
assert all(checks.values()),checks
report={'baseline':BASE,'candidate':CAND,'checks':checks,'shader_decode_source_operations':[],
        'scope':'Transient CPU spare bits exhaust into the original shipping8B [start,end] words; shader byte-identical. Draw/common/inline/color/correction ABI and every floating shader helper/sample loop remain byte-identical. No timing implication.'}
(OUT/'source-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
