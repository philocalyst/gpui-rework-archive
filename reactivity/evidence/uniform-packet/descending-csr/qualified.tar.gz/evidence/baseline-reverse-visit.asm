
FUNCTION gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}> bytes=611 frame=88

/tmp/gpui-descending-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081c5b0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>>:
  81c5b0:	push   %rbp
  81c5b1:	push   %r15
  81c5b3:	push   %r14
  81c5b5:	push   %r13
  81c5b7:	push   %r12
  81c5b9:	push   %rbx
  81c5ba:	sub    $0x28,%rsp
  81c5be:	movss  0x8c(%rdi),%xmm3
  81c5c6:	movss  -0x76d612(%rip),%xmm0        # aefbc <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  81c5ce:	movaps %xmm3,%xmm1
  81c5d1:	subss  %xmm0,%xmm1
  81c5d5:	cvttss2si %xmm1,%rax
  81c5da:	cvttss2si %xmm3,%r8
  81c5df:	mov    %r8,%rcx
  81c5e2:	sar    $0x3f,%rcx
  81c5e6:	and    %rax,%rcx
  81c5e9:	or     %r8,%rcx
  81c5ec:	xor    %r9d,%r9d
  81c5ef:	xorps  %xmm1,%xmm1
  81c5f2:	ucomiss %xmm1,%xmm3
  81c5f5:	cmovb  %r9,%rcx
  81c5f9:	movss  -0x76d641(%rip),%xmm2        # aefc0 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  81c601:	ucomiss %xmm2,%xmm3
  81c604:	mov    $0xffffffffffffffff,%rax
  81c60b:	cmova  %rax,%rcx
  81c60f:	movss  0x94(%rdi),%xmm3
  81c617:	mov    %rcx,%r8
  81c61a:	shr    $0x4,%r8
  81c61e:	movaps %xmm3,%xmm4
  81c621:	subss  %xmm0,%xmm4
  81c625:	cvttss2si %xmm4,%r10
  81c62a:	cvttss2si %xmm3,%r11
  81c62f:	mov    %r11,%rbx
  81c632:	sar    $0x3f,%rbx
  81c636:	and    %r10,%rbx
  81c639:	or     %r11,%rbx
  81c63c:	ucomiss %xmm1,%xmm3
  81c63f:	cmovb  %r9,%rbx
  81c643:	ucomiss %xmm2,%xmm3
  81c646:	cmova  %rax,%rbx
  81c64a:	mov    %rsi,0x18(%rsp)
  81c64f:	lea    (%rcx,%rbx,1),%r11
  81c653:	dec    %r11
  81c656:	shr    $0x4,%r11
  81c65a:	cmp    %r11,%r8
  81c65d:	jbe    81c66e <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xbe>
  81c65f:	add    $0x28,%rsp
  81c663:	pop    %rbx
  81c664:	pop    %r12
  81c666:	pop    %r13
  81c668:	pop    %r14
  81c66a:	pop    %r15
  81c66c:	pop    %rbp
  81c66d:	ret
  81c66e:	movss  0x88(%rdi),%xmm3
  81c676:	movaps %xmm3,%xmm4
  81c679:	subss  %xmm0,%xmm4
  81c67d:	cvttss2si %xmm4,%rsi
  81c682:	cvttss2si %xmm3,%r9
  81c687:	mov    %r9,%rcx
  81c68a:	sar    $0x3f,%rcx
  81c68e:	and    %rsi,%rcx
  81c691:	or     %r9,%rcx
  81c694:	xor    %r10d,%r10d
  81c697:	ucomiss %xmm1,%xmm3
  81c69a:	cmovb  %r10,%rcx
  81c69e:	ucomiss %xmm2,%xmm3
  81c6a1:	cmova  %rax,%rcx
  81c6a5:	movss  0x90(%rdi),%xmm3
  81c6ad:	mov    %rcx,%r14
  81c6b0:	shr    $0x4,%r14
  81c6b4:	movaps %xmm3,%xmm4
  81c6b7:	subss  %xmm0,%xmm4
  81c6bb:	cvttss2si %xmm4,%rsi
  81c6c0:	cvttss2si %xmm3,%rdi
  81c6c5:	mov    %rdi,%r9
  81c6c8:	sar    $0x3f,%r9
  81c6cc:	and    %rsi,%r9
  81c6cf:	or     %rdi,%r9
  81c6d2:	ucomiss %xmm1,%xmm3
  81c6d5:	cmovb  %r10,%r9
  81c6d9:	ucomiss %xmm2,%xmm3
  81c6dc:	cmova  %rax,%r9
  81c6e0:	lea    (%r9,%rcx,1),%rbx
  81c6e4:	dec    %rbx
  81c6e7:	shr    $0x4,%rbx
  81c6eb:	mov    %r14,0x10(%rsp)
  81c6f0:	cmp    %rbx,%r14
  81c6f3:	jbe    81c71d <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x16d>
  81c6f5:	data16 cs nopw 0x0(%rax,%rax,1)
  81c700:	mov    %r8,%rax
  81c703:	cmp    %r11,%r8
  81c706:	adc    $0x0,%r8
  81c70a:	cmp    %r11,%rax
  81c70d:	jae    81c65f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c713:	cmp    %r11,%r8
  81c716:	jbe    81c700 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x150>
  81c718:	jmp    81c65f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c71d:	mov    (%rdx),%r14
  81c720:	mov    0x8(%rdx),%r15
  81c724:	mov    0x10(%rdx),%r12
  81c728:	mov    0x18(%rdx),%r13
  81c72c:	mov    0x20(%rdx),%rdx
  81c730:	mov    %r11,0x8(%rsp)
  81c735:	data16 cs nopw 0x0(%rax,%rax,1)
  81c740:	mov    %r8,%rbp
  81c743:	cmp    %r11,%r8
  81c746:	adc    $0x0,%r8
  81c74a:	mov    %rbp,0x20(%rsp)
  81c74f:	imul   0x18(%rsp),%rbp
  81c755:	mov    0x10(%rsp),%r9
  81c75a:	mov    %r9,%rsi
  81c75d:	nopl   (%rax)
  81c760:	cmp    %rbx,%r9
  81c763:	adc    $0x0,%rsi
  81c767:	lea    (%r9,%rbp,1),%rdi
  81c76b:	mov    0x10(%r14),%rax
  81c76f:	cmp    %rax,%rdi
  81c772:	jae    81c7e0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x230>
  81c774:	mov    0x8(%r14),%rcx
  81c778:	cmp    0x4(%rcx,%rdi,8),%r10d
  81c77d:	jo     81c7b5 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x205>
  81c77f:	mov    0x10(%r12),%rax
  81c784:	cmp    %rax,%rdi
  81c787:	jae    81c7f0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x240>
  81c789:	mov    0x8(%r12),%rax
  81c78e:	mov    0x0(%r13),%r11d
  81c792:	inc    %r11d
  81c795:	cmp    (%rax,%rdi,4),%r11d
  81c799:	jb     81c7b5 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x205>
  81c79b:	mov    (%rcx,%rdi,8),%eax
  81c79e:	dec    %eax
  81c7a0:	mov    %eax,(%rcx,%rdi,8)
  81c7a3:	mov    0x10(%r15),%rcx
  81c7a7:	cmp    %rax,%rcx
  81c7aa:	jbe    81c800 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x250>
  81c7ac:	mov    0x8(%r15),%rcx
  81c7b0:	mov    (%rdx),%edi
  81c7b2:	mov    %edi,(%rcx,%rax,4)
  81c7b5:	cmp    %rbx,%r9
  81c7b8:	jae    81c7c2 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x212>
  81c7ba:	mov    %rsi,%r9
  81c7bd:	cmp    %rbx,%rsi
  81c7c0:	jbe    81c760 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x1b0>
  81c7c2:	mov    0x8(%rsp),%r11
  81c7c7:	cmp    %r11,0x20(%rsp)
  81c7cc:	jae    81c65f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c7d2:	cmp    %r11,%r8
  81c7d5:	jbe    81c740 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x190>
  81c7db:	jmp    81c65f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c7e0:	lea    0x611ab1(%rip),%rdx        # e2e298 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x80>
  81c7e7:	mov    %rax,%rsi
  81c7ea:	call   *0x663470(%rip)        # e7fc60 <_DYNAMIC+0x4f8>
  81c7f0:	lea    0x611ab9(%rip),%rdx        # e2e2b0 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x98>
  81c7f7:	mov    %rax,%rsi
  81c7fa:	call   *0x663460(%rip)        # e7fc60 <_DYNAMIC+0x4f8>
  81c800:	lea    0x611ac1(%rip),%rdx        # e2e2c8 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xb0>
  81c807:	mov    %rax,%rdi
  81c80a:	mov    %rcx,%rsi
  81c80d:	call   *0x66344d(%rip)        # e7fc60 <_DYNAMIC+0x4f8>
