from pathlib import Path
import collections,hashlib,json,re
OUT=Path('/tmp/gpui-descending-csr-evidence');CG=Path('/tmp/gpui-descending-csr-codegen')
labels=['baseline','endpoint','candidate'];sections={};bodies={};commands={};core={};flags={}
for label in labels:
    ledger=json.loads((CG/label/'groups-elf.json').read_text())
    sections[label]={'default':ledger['sections'],'offline':json.loads((CG/label/'offline-groups-elf.json').read_text())['sections']}
    groups=collections.defaultdict(list)
    for f in ledger['all_gpu_frames']:groups[f['normalized_name']].append(f)
    bodies[label]=groups
    rows=(CG/label/'cargo.log').read_text().splitlines()
    args=[x.split('rustc --crate-name gpui_gpu ',1)[1] for x in rows if 'rustc --crate-name gpui_gpu ' in x and '--crate-type lib' in x]
    assert len(args)==1 and args[0].count('-Zemit-stack-sizes')==1
    commands[label]=args[0]
    core[label]=json.loads((OUT/('core-lines-'+label+'.json')).read_text())['core_non_test_code_lines']
assert len(set(commands.values()))==1,'all three library argument vectors must match exactly'
(OUT/'exact-matched-rustc-argv.json').write_text(json.dumps({'all_three_argument_vectors_exact':True,'commands':commands},indent=2)+'\n')
comparisons={}
for baseline in ['baseline','endpoint']:
    pairs=[];ambiguous=[]
    for name in sorted(set(bodies[baseline])|set(bodies['candidate'])):
        old=bodies[baseline].get(name,[]);new=bodies['candidate'].get(name,[])
        if len(old)==len(new)==1:
            pairs.append({'name':name,'before':old[0],'after':new[0],
                'code_delta':new[0]['code_bytes']-old[0]['code_bytes'],
                'frame_delta':new[0]['stack_bytes']-old[0]['stack_bytes']})
        else:ambiguous.append({'name':name,'before':old,'after':new})
    comparisons[baseline]={'section_deltas':{mode:{k:sections['candidate'][mode][k]-sections[baseline][mode][k] for k in sections[baseline][mode]} for mode in ['default','offline']},
       'core_delta':core['candidate']-core[baseline],'unique_pairs':pairs,'ambiguous_or_unpaired':ambiguous}
for label in labels:
    text=(CG/label/'all-gpu-functions.asm').read_text()
    matches=[(name,entries[0]) for name,entries in bodies[label].items() if len(entries)==1 and '::visit::' in name and '{closure#5}' in name]
    assert len(matches)==1,matches
    name,entry=matches[0];marker='\nFUNCTION '+name+' bytes='
    block=marker+text.split(marker,1)[1].split('\nFUNCTION ',1)[0]
    (OUT/(label+'-reverse-visit.asm')).write_text(block)
report={'labels':{'baseline':'shipping7a5e','endpoint':'frozen6bf','candidate':'descending1c'},'sections':sections,'core':core,'comparisons':comparisons,
 'scope':'Actual matched same-physical-path opt3/locked/root flags/fresh artifacts. Aliases and unpaired functions retained; no timing, peak stack, or additive frames claim.'}
(OUT/'three-lane-cost-ledger.json').write_text(json.dumps(report,indent=2)+'\n')
for label,c in comparisons.items():
 print(label,'section_deltas',c['section_deltas'],'core_delta',c['core_delta'])
 for p in c['unique_pairs']:
  if p['code_delta'] or p['frame_delta']:print(p['name'],p['code_delta'],p['frame_delta'])
