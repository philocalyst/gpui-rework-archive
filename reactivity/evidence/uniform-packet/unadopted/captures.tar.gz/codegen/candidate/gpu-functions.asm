
/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000815ff0 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>:
  815ff0:	push   %rbx
  815ff1:	test   %rdi,%rdi
  815ff4:	je     816057 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x67>
  815ff6:	mov    %rdi,%rbx
  815ff9:	mov    (%rdi),%rsi
  815ffc:	test   %rsi,%rsi
  815fff:	je     816014 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x24>
  816001:	mov    0x8(%rbx),%rdi
  816005:	shl    $0x3,%rsi
  816009:	mov    $0x8,%edx
  81600e:	call   *0x6697d4(%rip)        # e7f7e8 <_DYNAMIC+0x248>
  816014:	mov    0x20(%rbx),%rsi
  816018:	test   %rsi,%rsi
  81601b:	je     816043 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  81601d:	mov    %rsi,%rax
  816020:	shl    $0x4,%rax
  816024:	add    %rax,%rsi
  816027:	add    $0x21,%rsi
  81602b:	je     816043 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  81602d:	mov    0x18(%rbx),%rdi
  816031:	sub    %rax,%rdi
  816034:	add    $0xfffffffffffffff0,%rdi
  816038:	mov    $0x10,%edx
  81603d:	call   *0x6697a5(%rip)        # e7f7e8 <_DYNAMIC+0x248>
  816043:	mov    $0x80,%esi
  816048:	mov    $0x8,%edx
  81604d:	mov    %rbx,%rdi
  816050:	pop    %rbx
  816051:	jmp    *0x669791(%rip)        # e7f7e8 <_DYNAMIC+0x248>
  816057:	pop    %rbx
  816058:	ret

/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000816660 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>>:
  816660:	push   %rbx
  816661:	cmpb   $0x3,0x19c(%rdi)
  816668:	jne    816697 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x37>
  81666a:	movzbl 0x28(%rdi),%eax
  81666e:	cmp    $0x4,%eax
  816671:	je     816685 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x25>
  816673:	cmp    $0x3,%eax
  816676:	jne    816697 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x37>
  816678:	add    $0x168,%rdi
  81667f:	pop    %rbx
  816680:	jmp    8165d0 <core::ptr::drop_glue::<<wgpu::api::adapter::Adapter>::request_device::{closure#0}>>
  816685:	mov    %rdi,%rbx
  816688:	add    $0x30,%rdi
  81668c:	call   8166b0 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>>
  816691:	movw   $0x0,0x29(%rbx)
  816697:	pop    %rbx
  816698:	ret
  816699:	movw   $0x0,0x29(%rbx)
  81669f:	mov    %rax,%rdi
  8166a2:	call   e2c310 <_Unwind_Resume@plt>

/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008166b0 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>>:
  8166b0:	push   %r15
  8166b2:	push   %r14
  8166b4:	push   %r12
  8166b6:	push   %rbx
  8166b7:	push   %rax
  8166b8:	mov    %rdi,%rbx
  8166bb:	movzbl 0x9e(%rdi),%eax
  8166c2:	test   %eax,%eax
  8166c4:	je     81678b <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xdb>
  8166ca:	cmp    $0x3,%eax
  8166cd:	jne    8167c1 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x111>
  8166d3:	mov    0x20(%rbx),%r15
  8166d7:	mov    0x28(%rbx),%r12
  8166db:	mov    (%r12),%rax
  8166df:	test   %rax,%rax
  8166e2:	je     8166e9 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x39>
  8166e4:	mov    %r15,%rdi
  8166e7:	call   *%rax
  8166e9:	mov    0x8(%r12),%rsi
  8166ee:	test   %rsi,%rsi
  8166f1:	je     816701 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x51>
  8166f3:	mov    0x10(%r12),%rdx
  8166f8:	mov    %r15,%rdi
  8166fb:	call   *0x6690e7(%rip)        # e7f7e8 <_DYNAMIC+0x248>
  816701:	mov    0x68(%rbx),%rax
  816705:	lock decq (%rax)
  816709:	jne    816715 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x65>
  81670b:	lea    0x68(%rbx),%rdi
  81670f:	call   *0x6692f3(%rip)        # e7fa08 <_DYNAMIC+0x468>
  816715:	movb   $0x0,0x98(%rbx)
  81671c:	mov    0x60(%rbx),%rax
  816720:	lock decq (%rax)
  816724:	jne    81672f <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x7f>
  816726:	lea    0x60(%rbx),%rdi
  81672a:	call   812830 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  81672f:	movw   $0x0,0x99(%rbx)
  816738:	mov    0x40(%rbx),%rax
  81673c:	lock decq (%rax)
  816740:	jne    81674c <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x9c>
  816742:	lea    0x40(%rbx),%rdi
  816746:	call   *0x6692c4(%rip)        # e7fa10 <_DYNAMIC+0x470>
  81674c:	movb   $0x0,0x9b(%rbx)
  816753:	mov    0x38(%rbx),%rax
  816757:	lock decq (%rax)
  81675b:	jne    816767 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xb7>
  81675d:	lea    0x38(%rbx),%rdi
  816761:	call   *0x6692b1(%rip)        # e7fa18 <_DYNAMIC+0x478>
  816767:	movb   $0x0,0x9c(%rbx)
  81676e:	mov    0x30(%rbx),%rax
  816772:	lock decq (%rax)
  816776:	jne    816782 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xd2>
  816778:	lea    0x30(%rbx),%rdi
  81677c:	call   *0x66929e(%rip)        # e7fa20 <_DYNAMIC+0x480>
  816782:	movb   $0x0,0x9d(%rbx)
  816789:	jmp    8167c1 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x111>
  81678b:	mov    0x70(%rbx),%rax
  81678f:	lock decq (%rax)
  816793:	jne    81679f <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xef>
  816795:	lea    0x70(%rbx),%rdi
  816799:	call   *0x669281(%rip)        # e7fa20 <_DYNAMIC+0x480>
  81679f:	mov    0x78(%rbx),%rax
  8167a3:	lock decq (%rax)
  8167a7:	jne    8167c1 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x111>
  8167a9:	add    $0x78,%rbx
  8167ad:	mov    %rbx,%rdi
  8167b0:	add    $0x8,%rsp
  8167b4:	pop    %rbx
  8167b5:	pop    %r12
  8167b7:	pop    %r14
  8167b9:	pop    %r15
  8167bb:	jmp    *0x669257(%rip)        # e7fa18 <_DYNAMIC+0x478>
  8167c1:	add    $0x8,%rsp
  8167c5:	pop    %rbx
  8167c6:	pop    %r12
  8167c8:	pop    %r14
  8167ca:	pop    %r15
  8167cc:	ret
  8167cd:	mov    %rax,%r14
  8167d0:	movb   $0x0,0x9d(%rbx)
  8167d7:	mov    %r14,%rdi
  8167da:	call   e2c310 <_Unwind_Resume@plt>
  8167df:	mov    %rax,%r14
  8167e2:	jmp    81689c <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1ec>
  8167e7:	mov    %rax,%r14
  8167ea:	jmp    816881 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1d1>
  8167ef:	mov    %rax,%r14
  8167f2:	jmp    816864 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1b4>
  8167f4:	mov    %rax,%r14
  8167f7:	jmp    81684a <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x19a>
  8167f9:	mov    %rax,%r14
  8167fc:	mov    0x78(%rbx),%rax
  816800:	lock decq (%rax)
  816804:	jne    816813 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x163>
  816806:	add    $0x78,%rbx
  81680a:	mov    %rbx,%rdi
  81680d:	call   *0x669205(%rip)        # e7fa18 <_DYNAMIC+0x478>
  816813:	mov    %r14,%rdi
  816816:	call   e2c310 <_Unwind_Resume@plt>
  81681b:	mov    %rax,%r14
  81681e:	mov    0x8(%r12),%rsi
  816823:	test   %rsi,%rsi
  816826:	je     816836 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x186>
  816828:	mov    0x10(%r12),%rdx
  81682d:	mov    %r15,%rdi
  816830:	call   *0x668fb2(%rip)        # e7f7e8 <_DYNAMIC+0x248>
  816836:	mov    0x68(%rbx),%rax
  81683a:	lock decq (%rax)
  81683e:	jne    81684a <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x19a>
  816840:	lea    0x68(%rbx),%rdi
  816844:	call   *0x6691be(%rip)        # e7fa08 <_DYNAMIC+0x468>
  81684a:	movb   $0x0,0x98(%rbx)
  816851:	mov    0x60(%rbx),%rax
  816855:	lock decq (%rax)
  816859:	jne    816864 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1b4>
  81685b:	lea    0x60(%rbx),%rdi
  81685f:	call   812830 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  816864:	movw   $0x0,0x99(%rbx)
  81686d:	mov    0x40(%rbx),%rax
  816871:	lock decq (%rax)
  816875:	jne    816881 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1d1>
  816877:	lea    0x40(%rbx),%rdi
  81687b:	call   *0x66918f(%rip)        # e7fa10 <_DYNAMIC+0x470>
  816881:	movb   $0x0,0x9b(%rbx)
  816888:	mov    0x38(%rbx),%rax
  81688c:	lock decq (%rax)
  816890:	jne    81689c <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1ec>
  816892:	lea    0x38(%rbx),%rdi
  816896:	call   *0x66917c(%rip)        # e7fa18 <_DYNAMIC+0x478>
  81689c:	movb   $0x0,0x9c(%rbx)
  8168a3:	mov    0x30(%rbx),%rax
  8168a7:	lock decq (%rax)
  8168ab:	jne    8168b7 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x207>
  8168ad:	lea    0x30(%rbx),%rdi
  8168b1:	call   *0x669169(%rip)        # e7fa20 <_DYNAMIC+0x480>
  8168b7:	movb   $0x0,0x9d(%rbx)
  8168be:	mov    %r14,%rdi
  8168c1:	call   e2c310 <_Unwind_Resume@plt>
  8168c6:	call   *0x668f24(%rip)        # e7f7f0 <_DYNAMIC+0x250>

/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008168d0 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}>>:
  8168d0:	push   %rbx
  8168d1:	movzbl 0x20(%rdi),%eax
  8168d5:	cmp    $0x3,%eax
  8168d8:	je     8168f3 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}>+0x23>
  8168da:	cmp    $0x4,%eax
  8168dd:	jne    816900 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}>+0x30>
  8168df:	mov    %rdi,%rbx
  8168e2:	add    $0x28,%rdi
  8168e6:	call   8166b0 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>>
  8168eb:	movw   $0x0,0x21(%rbx)
  8168f1:	pop    %rbx
  8168f2:	ret
  8168f3:	add    $0x160,%rdi
  8168fa:	pop    %rbx
  8168fb:	jmp    8165d0 <core::ptr::drop_glue::<<wgpu::api::adapter::Adapter>::request_device::{closure#0}>>
  816900:	pop    %rbx
  816901:	ret
  816902:	movw   $0x0,0x21(%rbx)
  816908:	mov    %rax,%rdi
  81690b:	call   e2c310 <_Unwind_Resume@plt>

/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000816df0 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>>:
  816df0:	push   %r14
  816df2:	push   %rbx
  816df3:	push   %rax
  816df4:	mov    %rdi,%rbx
  816df7:	mov    (%rdi),%rax
  816dfa:	lock decq (%rax)
  816dfe:	jne    816e09 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x19>
  816e00:	mov    %rbx,%rdi
  816e03:	call   *0x668c17(%rip)        # e7fa20 <_DYNAMIC+0x480>
  816e09:	mov    0x8(%rbx),%rax
  816e0d:	lock decq (%rax)
  816e11:	jne    816e1d <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x2d>
  816e13:	lea    0x8(%rbx),%rdi
  816e17:	call   *0x668bfb(%rip)        # e7fa18 <_DYNAMIC+0x478>
  816e1d:	mov    0x10(%rbx),%rax
  816e21:	lock decq (%rax)
  816e25:	jne    816e30 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x40>
  816e27:	lea    0x10(%rbx),%rdi
  816e2b:	call   812830 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  816e30:	mov    0x18(%rbx),%rax
  816e34:	lock decq (%rax)
  816e38:	jne    816e4e <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x5e>
  816e3a:	add    $0x18,%rbx
  816e3e:	mov    %rbx,%rdi
  816e41:	add    $0x8,%rsp
  816e45:	pop    %rbx
  816e46:	pop    %r14
  816e48:	jmp    *0x668bba(%rip)        # e7fa08 <_DYNAMIC+0x468>
  816e4e:	add    $0x8,%rsp
  816e52:	pop    %rbx
  816e53:	pop    %r14
  816e55:	ret
  816e56:	mov    %rax,%r14
  816e59:	jmp    816e8a <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x9a>
  816e5b:	mov    %rax,%r14
  816e5e:	jmp    816e77 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x87>
  816e60:	mov    %rax,%r14
  816e63:	mov    0x8(%rbx),%rax
  816e67:	lock decq (%rax)
  816e6b:	jne    816e77 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x87>
  816e6d:	lea    0x8(%rbx),%rdi
  816e71:	call   *0x668ba1(%rip)        # e7fa18 <_DYNAMIC+0x478>
  816e77:	mov    0x10(%rbx),%rax
  816e7b:	lock decq (%rax)
  816e7f:	jne    816e8a <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x9a>
  816e81:	lea    0x10(%rbx),%rdi
  816e85:	call   812830 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  816e8a:	mov    0x18(%rbx),%rax
  816e8e:	lock decq (%rax)
  816e92:	jne    816ea1 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0xb1>
  816e94:	add    $0x18,%rbx
  816e98:	mov    %rbx,%rdi
  816e9b:	call   *0x668b67(%rip)        # e7fa08 <_DYNAMIC+0x468>
  816ea1:	mov    %r14,%rdi
  816ea4:	call   e2c310 <_Unwind_Resume@plt>
  816ea9:	call   *0x668941(%rip)        # e7f7f0 <_DYNAMIC+0x250>

/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000816eb0 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>>:
  816eb0:	push   %r14
  816eb2:	push   %rbx
  816eb3:	push   %rax
  816eb4:	mov    %rdi,%rbx
  816eb7:	mov    0x228(%rdi),%rax
  816ebe:	lock decq (%rax)
  816ec2:	jne    816ed1 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x21>
  816ec4:	lea    0x228(%rbx),%rdi
  816ecb:	call   *0x668b37(%rip)        # e7fa08 <_DYNAMIC+0x468>
  816ed1:	mov    0x230(%rbx),%rax
  816ed8:	lock decq (%rax)
  816edc:	jne    816eeb <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3b>
  816ede:	lea    0x230(%rbx),%rdi
  816ee5:	call   *0x668bbd(%rip)        # e7faa8 <_DYNAMIC+0x508>
  816eeb:	mov    0x238(%rbx),%rax
  816ef2:	lock decq (%rax)
  816ef6:	jne    816f05 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x55>
  816ef8:	lea    0x238(%rbx),%rdi
  816eff:	call   *0x668bab(%rip)        # e7fab0 <_DYNAMIC+0x510>
  816f05:	mov    0x258(%rbx),%rax
  816f0c:	lock decq (%rax)
  816f10:	jne    816f1f <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x6f>
  816f12:	lea    0x258(%rbx),%rdi
  816f19:	call   *0x668b89(%rip)        # e7faa8 <_DYNAMIC+0x508>
  816f1f:	mov    0x260(%rbx),%rax
  816f26:	lock decq (%rax)
  816f2a:	jne    816f39 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x89>
  816f2c:	lea    0x260(%rbx),%rdi
  816f33:	call   *0x668b77(%rip)        # e7fab0 <_DYNAMIC+0x510>
  816f39:	mov    0x280(%rbx),%rax
  816f40:	lock decq (%rax)
  816f44:	jne    816f53 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xa3>
  816f46:	lea    0x280(%rbx),%rdi
  816f4d:	call   *0x668b55(%rip)        # e7faa8 <_DYNAMIC+0x508>
  816f53:	mov    0x288(%rbx),%rax
  816f5a:	lock decq (%rax)
  816f5e:	jne    816f6d <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xbd>
  816f60:	lea    0x288(%rbx),%rdi
  816f67:	call   *0x668b43(%rip)        # e7fab0 <_DYNAMIC+0x510>
  816f6d:	mov    0x2a8(%rbx),%rax
  816f74:	lock decq (%rax)
  816f78:	jne    816f87 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xd7>
  816f7a:	lea    0x2a8(%rbx),%rdi
  816f81:	call   *0x668b21(%rip)        # e7faa8 <_DYNAMIC+0x508>
  816f87:	mov    0x2b0(%rbx),%rax
  816f8e:	lock decq (%rax)
  816f92:	jne    816fa1 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xf1>
  816f94:	lea    0x2b0(%rbx),%rdi
  816f9b:	call   *0x668b0f(%rip)        # e7fab0 <_DYNAMIC+0x510>
  816fa1:	mov    0x2d0(%rbx),%rax
  816fa8:	lock decq (%rax)
  816fac:	jne    816fbb <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x10b>
  816fae:	lea    0x2d0(%rbx),%rdi
  816fb5:	call   *0x668aed(%rip)        # e7faa8 <_DYNAMIC+0x508>
  816fbb:	mov    0x2d8(%rbx),%rax
  816fc2:	lock decq (%rax)
  816fc6:	jne    816fd5 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x125>
  816fc8:	lea    0x2d8(%rbx),%rdi
  816fcf:	call   *0x668adb(%rip)        # e7fab0 <_DYNAMIC+0x510>
  816fd5:	lea    0x78(%rbx),%rdi
  816fd9:	call   8173a0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  816fde:	mov    0x328(%rbx),%r14
  816fe5:	test   %r14,%r14
  816fe8:	je     817047 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x197>
  816fea:	mov    (%r14),%rsi
  816fed:	test   %rsi,%rsi
  816ff0:	je     817005 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x155>
  816ff2:	mov    0x8(%r14),%rdi
  816ff6:	shl    $0x3,%rsi
  816ffa:	mov    $0x8,%edx
  816fff:	call   *0x6687e3(%rip)        # e7f7e8 <_DYNAMIC+0x248>
  817005:	mov    0x20(%r14),%rsi
  817009:	test   %rsi,%rsi
  81700c:	je     817034 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x184>
  81700e:	mov    %rsi,%rax
  817011:	shl    $0x4,%rax
  817015:	add    %rax,%rsi
  817018:	add    $0x21,%rsi
  81701c:	je     817034 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x184>
  81701e:	mov    0x18(%r14),%rdi
  817022:	sub    %rax,%rdi
  817025:	add    $0xfffffffffffffff0,%rdi
  817029:	mov    $0x10,%edx
  81702e:	call   *0x6687b4(%rip)        # e7f7e8 <_DYNAMIC+0x248>
  817034:	mov    $0x80,%esi
  817039:	mov    $0x8,%edx
  81703e:	mov    %r14,%rdi
  817041:	call   *0x6687a1(%rip)        # e7f7e8 <_DYNAMIC+0x248>
  817047:	mov    (%rbx),%rsi
  81704a:	test   %rsi,%rsi
  81704d:	je     817062 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x1b2>
  81704f:	mov    0x8(%rbx),%rdi
  817053:	shl    $0x4,%rsi
  817057:	mov    $0x4,%edx
  81705c:	call   *0x668786(%rip)        # e7f7e8 <_DYNAMIC+0x248>
  817062:	mov    0x18(%rbx),%rsi
  817066:	test   %rsi,%rsi
  817069:	je     81707e <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x1ce>
  81706b:	mov    0x20(%rbx),%rdi
  81706f:	shl    $0x3,%rsi
  817073:	mov    $0x4,%edx
  817078:	call   *0x66876a(%rip)        # e7f7e8 <_DYNAMIC+0x248>
  81707e:	mov    0x30(%rbx),%rsi
  817082:	test   %rsi,%rsi
  817085:	je     81709a <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x1ea>
  817087:	mov    0x38(%rbx),%rdi
  81708b:	shl    $0x2,%rsi
  81708f:	mov    $0x4,%edx
  817094:	call   *0x66874e(%rip)        # e7f7e8 <_DYNAMIC+0x248>
  81709a:	mov    0x48(%rbx),%rsi
  81709e:	test   %rsi,%rsi
  8170a1:	je     8170b6 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x206>
  8170a3:	mov    0x50(%rbx),%rdi
  8170a7:	shl    $0x2,%rsi
  8170ab:	mov    $0x4,%edx
  8170b0:	call   *0x668732(%rip)        # e7f7e8 <_DYNAMIC+0x248>
  8170b6:	mov    0x60(%rbx),%rsi
  8170ba:	test   %rsi,%rsi
  8170bd:	je     8170d2 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x222>
  8170bf:	mov    0x68(%rbx),%rdi
  8170c3:	shl    $0x5,%rsi
  8170c7:	mov    $0x4,%edx
  8170cc:	call   *0x668716(%rip)        # e7f7e8 <_DYNAMIC+0x248>
  8170d2:	mov    0x300(%rbx),%rsi
  8170d9:	test   %rsi,%rsi
  8170dc:	je     81710c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x25c>
  8170de:	lea    (%rsi,%rsi,8),%rax
  8170e2:	lea    0x33(,%rax,4),%rax
  8170ea:	and    $0xfffffffffffffff0,%rax
  8170ee:	add    %rax,%rsi
  8170f1:	add    $0x11,%rsi
  8170f5:	je     81710c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x25c>
  8170f7:	mov    0x2f8(%rbx),%rdi
  8170fe:	sub    %rax,%rdi
  817101:	mov    $0x10,%edx
  817106:	call   *0x6686dc(%rip)        # e7f7e8 <_DYNAMIC+0x248>
  81710c:	mov    0x330(%rbx),%rax
  817113:	test   %rax,%rax
  817116:	je     817135 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x285>
  817118:	lock decq (%rax)
  81711c:	jne    817135 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x285>
  81711e:	add    $0x330,%rbx
  817125:	mov    %rbx,%rdi
  817128:	add    $0x8,%rsp
  81712c:	pop    %rbx
  81712d:	pop    %r14
  81712f:	jmp    *0x668983(%rip)        # e7fab8 <_DYNAMIC+0x518>
  817135:	add    $0x8,%rsp
  817139:	pop    %rbx
  81713a:	pop    %r14
  81713c:	ret
  81713d:	mov    %rax,%r14
  817140:	jmp    81726c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3bc>
  817145:	mov    %rax,%r14
  817148:	mov    0x2d8(%rbx),%rax
  81714f:	lock decq (%rax)
  817153:	jne    81726c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3bc>
  817159:	lea    0x2d8(%rbx),%rdi
  817160:	call   *0x66894a(%rip)        # e7fab0 <_DYNAMIC+0x510>
  817166:	jmp    81726c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3bc>
  81716b:	call   *0x66867f(%rip)        # e7f7f0 <_DYNAMIC+0x250>
  817171:	mov    %rax,%r14
  817174:	jmp    817260 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3b0>
  817179:	mov    %rax,%r14
  81717c:	mov    0x2b0(%rbx),%rax
  817183:	lock decq (%rax)
  817187:	jne    817260 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3b0>
  81718d:	lea    0x2b0(%rbx),%rdi
  817194:	call   *0x668916(%rip)        # e7fab0 <_DYNAMIC+0x510>
  81719a:	jmp    817260 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3b0>
  81719f:	call   *0x66864b(%rip)        # e7f7f0 <_DYNAMIC+0x250>
  8171a5:	mov    %rax,%r14
  8171a8:	jmp    817254 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3a4>
  8171ad:	mov    %rax,%r14
  8171b0:	mov    0x288(%rbx),%rax
  8171b7:	lock decq (%rax)
  8171bb:	jne    817254 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3a4>
  8171c1:	lea    0x288(%rbx),%rdi
  8171c8:	call   *0x6688e2(%rip)        # e7fab0 <_DYNAMIC+0x510>
  8171ce:	jmp    817254 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3a4>
  8171d3:	call   *0x668617(%rip)        # e7f7f0 <_DYNAMIC+0x250>
  8171d9:	mov    %rax,%r14
  8171dc:	jmp    817248 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x398>
  8171de:	mov    %rax,%r14
  8171e1:	mov    0x260(%rbx),%rax
  8171e8:	lock decq (%rax)
  8171ec:	jne    817248 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x398>
  8171ee:	lea    0x260(%rbx),%rdi
  8171f5:	call   *0x6688b5(%rip)        # e7fab0 <_DYNAMIC+0x510>
  8171fb:	jmp    817248 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x398>
  8171fd:	call   *0x6685ed(%rip)        # e7f7f0 <_DYNAMIC+0x250>
  817203:	mov    %rax,%r14
  817206:	jmp    81723c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x38c>
  817208:	mov    %rax,%r14
  81720b:	mov    0x238(%rbx),%rax
  817212:	lock decq (%rax)
  817216:	jne    81723c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x38c>
  817218:	lea    0x238(%rbx),%rdi
  81721f:	call   *0x66888b(%rip)        # e7fab0 <_DYNAMIC+0x510>
  817225:	jmp    81723c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x38c>
  817227:	call   *0x6685c3(%rip)        # e7f7f0 <_DYNAMIC+0x250>
  81722d:	mov    %rax,%r14
  817230:	lea    0x230(%rbx),%rdi
  817237:	call   8174a0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81723c:	lea    0x258(%rbx),%rdi
  817243:	call   8174a0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  817248:	lea    0x280(%rbx),%rdi
  81724f:	call   8174a0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  817254:	lea    0x2a8(%rbx),%rdi
  81725b:	call   8174a0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  817260:	lea    0x2d0(%rbx),%rdi
  817267:	call   8174a0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81726c:	lea    0x78(%rbx),%rdi
  817270:	call   8173a0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  817275:	mov    0x328(%rbx),%rdi
  81727c:	call   815ff0 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>
  817281:	mov    (%rbx),%rsi
  817284:	test   %rsi,%rsi
  817287:	jne    817302 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x452>
  817289:	mov    0x18(%rbx),%rsi
  81728d:	test   %rsi,%rsi
  817290:	jne    817322 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x472>
  817296:	mov    0x30(%rbx),%rsi
  81729a:	test   %rsi,%rsi
  81729d:	jne    817342 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x492>
  8172a3:	mov    0x48(%rbx),%rsi
  8172a7:	test   %rsi,%rsi
  8172aa:	jne    817362 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x4b2>
  8172b0:	mov    0x60(%rbx),%rsi
  8172b4:	test   %rsi,%rsi
  8172b7:	je     8172cc <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x41c>
  8172b9:	mov    0x68(%rbx),%rdi
  8172bd:	shl    $0x5,%rsi
  8172c1:	mov    $0x4,%edx
  8172c6:	call   *0x66851c(%rip)        # e7f7e8 <_DYNAMIC+0x248>
  8172cc:	lea    0x2f8(%rbx),%rdi
  8172d3:	call   8197b0 <<hashbrown::raw::RawTable<([u32; 8], u32)> as core::ops::drop::Drop>::drop>
  8172d8:	mov    0x330(%rbx),%rax
  8172df:	test   %rax,%rax
  8172e2:	je     8172fa <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x44a>
  8172e4:	lock decq (%rax)
  8172e8:	jne    8172fa <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x44a>
  8172ea:	add    $0x330,%rbx
  8172f1:	mov    %rbx,%rdi
  8172f4:	call   *0x6687be(%rip)        # e7fab8 <_DYNAMIC+0x518>
  8172fa:	mov    %r14,%rdi
  8172fd:	call   e2c310 <_Unwind_Resume@plt>
  817302:	mov    0x8(%rbx),%rdi
  817306:	shl    $0x4,%rsi
  81730a:	mov    $0x4,%edx
  81730f:	call   *0x6684d3(%rip)        # e7f7e8 <_DYNAMIC+0x248>
  817315:	mov    0x18(%rbx),%rsi
  817319:	test   %rsi,%rsi
  81731c:	je     817296 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3e6>
  817322:	mov    0x20(%rbx),%rdi
  817326:	shl    $0x3,%rsi
  81732a:	mov    $0x4,%edx
  81732f:	call   *0x6684b3(%rip)        # e7f7e8 <_DYNAMIC+0x248>
  817335:	mov    0x30(%rbx),%rsi
  817339:	test   %rsi,%rsi
  81733c:	je     8172a3 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3f3>
  817342:	mov    0x38(%rbx),%rdi
  817346:	shl    $0x2,%rsi
  81734a:	mov    $0x4,%edx
  81734f:	call   *0x668493(%rip)        # e7f7e8 <_DYNAMIC+0x248>
  817355:	mov    0x48(%rbx),%rsi
  817359:	test   %rsi,%rsi
  81735c:	je     8172b0 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x400>
  817362:	mov    0x50(%rbx),%rdi
  817366:	shl    $0x2,%rsi
  81736a:	mov    $0x4,%edx
  81736f:	call   *0x668473(%rip)        # e7f7e8 <_DYNAMIC+0x248>
  817375:	mov    0x60(%rbx),%rsi
  817379:	test   %rsi,%rsi
  81737c:	jne    8172b9 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x409>
  817382:	jmp    8172cc <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x41c>
  817387:	call   *0x668463(%rip)        # e7f7f0 <_DYNAMIC+0x250>
  81738d:	mov    %rax,%r14
  817390:	jmp    817275 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3c5>

/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008173a0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>:
  8173a0:	push   %r14
  8173a2:	push   %rbx
  8173a3:	push   %rax
  8173a4:	mov    %rdi,%rbx
  8173a7:	mov    (%rdi),%rax
  8173aa:	lock decq (%rax)
  8173ae:	jne    8173b9 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x19>
  8173b0:	mov    %rbx,%rdi
  8173b3:	call   *0x6686cf(%rip)        # e7fa88 <_DYNAMIC+0x4e8>
  8173b9:	mov    0x50(%rbx),%rax
  8173bd:	lock decq (%rax)
  8173c1:	jne    8173cd <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x2d>
  8173c3:	lea    0x50(%rbx),%rdi
  8173c7:	call   *0x6686b3(%rip)        # e7fa80 <_DYNAMIC+0x4e0>
  8173cd:	mov    0x58(%rbx),%rax
  8173d1:	lock decq (%rax)
  8173d5:	jne    8173e1 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x41>
  8173d7:	lea    0x58(%rbx),%rdi
  8173db:	call   *0x6686a7(%rip)        # e7fa88 <_DYNAMIC+0x4e8>
  8173e1:	mov    0xb0(%rbx),%rsi
  8173e8:	test   %rsi,%rsi
  8173eb:	je     81741d <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  8173ed:	mov    %rsi,%rax
  8173f0:	shl    $0x5,%rax
  8173f4:	add    %rax,%rsi
  8173f7:	add    $0x31,%rsi
  8173fb:	je     81741d <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  8173fd:	mov    0xa8(%rbx),%rdi
  817404:	sub    %rax,%rdi
  817407:	add    $0xffffffffffffffe0,%rdi
  81740b:	mov    $0x10,%edx
  817410:	add    $0x8,%rsp
  817414:	pop    %rbx
  817415:	pop    %r14
  817417:	jmp    *0x6683cb(%rip)        # e7f7e8 <_DYNAMIC+0x248>
  81741d:	add    $0x8,%rsp
  817421:	pop    %rbx
  817422:	pop    %r14
  817424:	ret
  817425:	mov    %rax,%r14
  817428:	jmp    817455 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  81742a:	mov    %rax,%r14
  81742d:	mov    0x58(%rbx),%rax
  817431:	lock decq (%rax)
  817435:	jne    817455 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  817437:	lea    0x58(%rbx),%rdi
  81743b:	call   *0x668647(%rip)        # e7fa88 <_DYNAMIC+0x4e8>
  817441:	jmp    817455 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  817443:	call   *0x6683a7(%rip)        # e7f7f0 <_DYNAMIC+0x250>
  817449:	mov    %rax,%r14
  81744c:	lea    0x50(%rbx),%rdi
  817450:	call   8175a0 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  817455:	add    $0xa8,%rbx
  81745c:	mov    %rbx,%rdi
  81745f:	call   8197f0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>
  817464:	mov    %r14,%rdi
  817467:	call   e2c310 <_Unwind_Resume@plt>
  81746c:	call   *0x66837e(%rip)        # e7f7f0 <_DYNAMIC+0x250>

/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000817480 <core::ptr::drop_glue::<gpui_gpu::renderer::Error>>:
  817480:	cmpl   $0x1,(%rdi)
  817483:	ja     81749d <core::ptr::drop_glue::<gpui_gpu::renderer::Error>+0x1d>
  817485:	mov    0x8(%rdi),%rsi
  817489:	test   %rsi,%rsi
  81748c:	je     81749d <core::ptr::drop_glue::<gpui_gpu::renderer::Error>+0x1d>
  81748e:	mov    0x10(%rdi),%rdi
  817492:	mov    $0x1,%edx
  817497:	jmp    *0x66834b(%rip)        # e7f7e8 <_DYNAMIC+0x248>
  81749d:	ret

/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008174a0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>:
  8174a0:	push   %r14
  8174a2:	push   %rbx
  8174a3:	push   %rax
  8174a4:	mov    %rdi,%rbx
  8174a7:	mov    (%rdi),%rax
  8174aa:	lock decq (%rax)
  8174ae:	jne    8174b9 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x19>
  8174b0:	mov    %rbx,%rdi
  8174b3:	call   *0x6685ef(%rip)        # e7faa8 <_DYNAMIC+0x508>
  8174b9:	mov    0x8(%rbx),%rax
  8174bd:	lock decq (%rax)
  8174c1:	jne    8174d7 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x37>
  8174c3:	add    $0x8,%rbx
  8174c7:	mov    %rbx,%rdi
  8174ca:	add    $0x8,%rsp
  8174ce:	pop    %rbx
  8174cf:	pop    %r14
  8174d1:	jmp    *0x6685d9(%rip)        # e7fab0 <_DYNAMIC+0x510>
  8174d7:	add    $0x8,%rsp
  8174db:	pop    %rbx
  8174dc:	pop    %r14
  8174de:	ret
  8174df:	mov    %rax,%r14
  8174e2:	mov    0x8(%rbx),%rax
  8174e6:	lock decq (%rax)
  8174ea:	jne    8174f9 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x59>
  8174ec:	add    $0x8,%rbx
  8174f0:	mov    %rbx,%rdi
  8174f3:	call   *0x6685b7(%rip)        # e7fab0 <_DYNAMIC+0x510>
  8174f9:	mov    %r14,%rdi
  8174fc:	call   e2c310 <_Unwind_Resume@plt>
  817501:	call   *0x6682e9(%rip)        # e7f7f0 <_DYNAMIC+0x250>

/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000817e70 <<gpui_gpu::renderer::Error as core::fmt::Debug>::fmt>:
  817e70:	sub    $0x18,%rsp
  817e74:	mov    %rsi,%rax
  817e77:	mov    (%rdi),%ecx
  817e79:	lea    -0x747000(%rip),%rdx        # d0e80 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0xbb8>
  817e80:	movslq (%rdx,%rcx,4),%rcx
  817e84:	add    %rdx,%rcx
  817e87:	jmp    *%rcx
  817e89:	add    $0x8,%rdi
  817e8d:	mov    %rdi,0x10(%rsp)
  817e92:	lea    -0x743aff(%rip),%rsi        # d439a <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x40d2>
  817e99:	jmp    817f28 <<gpui_gpu::renderer::Error as core::fmt::Debug>::fmt+0xb8>
  817e9e:	lea    -0x743ae2(%rip),%rsi        # d43c3 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x40fb>
  817ea5:	mov    $0x13,%edx
  817eaa:	mov    %rax,%rdi
  817ead:	add    $0x18,%rsp
  817eb1:	jmp    *0x667a21(%rip)        # e7f8d8 <_DYNAMIC+0x338>
  817eb7:	add    $0x4,%rdi
  817ebb:	mov    %rdi,0x10(%rsp)
  817ec0:	lea    -0x743b21(%rip),%rsi        # d43a6 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x40de>
  817ec7:	lea    0x615d4a(%rip),%r8        # e2dc18 <__frame_dummy_init_array_entry+0x8c8>
  817ece:	lea    0x10(%rsp),%rcx
  817ed3:	mov    $0x11,%edx
  817ed8:	mov    %rax,%rdi
  817edb:	call   *0x6679ff(%rip)        # e7f8e0 <_DYNAMIC+0x340>
  817ee1:	add    $0x18,%rsp
  817ee5:	ret
  817ee6:	lea    -0x743b36(%rip),%rsi        # d43b7 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x40ef>
  817eed:	mov    $0xc,%edx
  817ef2:	mov    %rax,%rdi
  817ef5:	add    $0x18,%rsp
  817ef9:	jmp    *0x6679d9(%rip)        # e7f8d8 <_DYNAMIC+0x338>
  817eff:	lea    -0x743b1a(%rip),%rsi        # d43ec <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x4124>
  817f06:	mov    $0x9,%edx
  817f0b:	mov    %rax,%rdi
  817f0e:	add    $0x18,%rsp
  817f12:	jmp    *0x6679c0(%rip)        # e7f8d8 <_DYNAMIC+0x338>
  817f18:	add    $0x8,%rdi
  817f1c:	mov    %rdi,0x10(%rsp)
  817f21:	lea    -0x743b88(%rip),%rsi        # d43a0 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x40d8>
  817f28:	lea    0x615cc9(%rip),%r8        # e2dbf8 <__frame_dummy_init_array_entry+0x8a8>
  817f2f:	lea    0x10(%rsp),%rcx
  817f34:	mov    $0x6,%edx
  817f39:	mov    %rax,%rdi
  817f3c:	call   *0x66799e(%rip)        # e7f8e0 <_DYNAMIC+0x340>
  817f42:	add    $0x18,%rsp
  817f46:	ret
  817f47:	add    $0x8,%rdi
  817f4b:	mov    %rdi,0x10(%rsp)
  817f50:	lea    0x615ce1(%rip),%rcx        # e2dc38 <__frame_dummy_init_array_entry+0x8e8>
  817f57:	mov    %rcx,(%rsp)
  817f5b:	lea    -0x743b8c(%rip),%rsi        # d43d6 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x410e>
  817f62:	lea    -0x7690dd(%rip),%rcx        # aee8c <anon.a16d5d421a76dfd8c37a17b53540311d.67.llvm.14190004212411149437+0x20>
  817f69:	lea    0x10(%rsp),%r9
  817f6e:	mov    $0x9,%edx
  817f73:	mov    $0x4,%r8d
  817f79:	mov    %rax,%rdi
  817f7c:	call   *0x667b46(%rip)        # e7fac8 <_DYNAMIC+0x528>
  817f82:	add    $0x18,%rsp
  817f86:	ret
  817f87:	lea    -0x743baf(%rip),%rsi        # d43df <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x4117>
  817f8e:	mov    $0xd,%edx
  817f93:	mov    %rax,%rdi
  817f96:	add    $0x18,%rsp
  817f9a:	jmp    *0x667938(%rip)        # e7f8d8 <_DYNAMIC+0x338>

/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008197f0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>:
  8197f0:	mov    0x8(%rdi),%rsi
  8197f4:	test   %rsi,%rsi
  8197f7:	je     81981e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  8197f9:	mov    %rsi,%rax
  8197fc:	shl    $0x5,%rax
  819800:	add    %rax,%rsi
  819803:	add    $0x31,%rsi
  819807:	je     81981e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  819809:	mov    (%rdi),%rdi
  81980c:	sub    %rax,%rdi
  81980f:	add    $0xffffffffffffffe0,%rdi
  819813:	mov    $0x10,%edx
  819818:	jmp    *0x665fca(%rip)        # e7f7e8 <_DYNAMIC+0x248>
  81981e:	ret

/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000819820 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop>:
  819820:	mov    0x8(%rdi),%rsi
  819824:	test   %rsi,%rsi
  819827:	je     81984e <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop+0x2e>
  819829:	mov    %rsi,%rax
  81982c:	shl    $0x4,%rax
  819830:	add    %rax,%rsi
  819833:	add    $0x21,%rsi
  819837:	je     81984e <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop+0x2e>
  819839:	mov    (%rdi),%rdi
  81983c:	sub    %rax,%rdi
  81983f:	add    $0xfffffffffffffff0,%rdi
  819843:	mov    $0x10,%edx
  819848:	jmp    *0x665f9a(%rip)        # e7f7e8 <_DYNAMIC+0x248>
  81984e:	ret

/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081b0e0 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>>:
  81b0e0:	push   %r14
  81b0e2:	push   %rbx
  81b0e3:	sub    $0x38,%rsp
  81b0e7:	mov    %rdi,%rbx
  81b0ea:	cmpq   $0x0,(%rsi)
  81b0ee:	je     81b1f8 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x118>
  81b0f4:	movdqu (%rsi),%xmm0
  81b0f8:	movdqu 0x10(%rsi),%xmm1
  81b0fd:	movdqu 0x20(%rsi),%xmm2
  81b102:	movdqa %xmm2,0x20(%rsp)
  81b108:	movdqa %xmm1,0x10(%rsp)
  81b10e:	movdqa %xmm0,(%rsp)
  81b113:	cmpq   $0x0,0x18(%rcx)
  81b118:	je     81b20c <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x12c>
  81b11e:	lea    0x10(%rsp),%rsi
  81b123:	lea    0x20(%rcx),%rdi
  81b127:	mov    %rcx,%r14
  81b12a:	call   824230 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  81b12f:	mov    %rax,%rsi
  81b132:	shr    $0x39,%rsi
  81b136:	mov    (%r14),%rcx
  81b139:	mov    0x8(%r14),%rdx
  81b13d:	movd   %esi,%xmm0
  81b141:	punpcklbw %xmm0,%xmm0
  81b145:	pshuflw $0x0,%xmm0,%xmm0
  81b14a:	pshufd $0x44,%xmm0,%xmm0
  81b14f:	mov    0x10(%rsp),%rsi
  81b154:	movzwl 0x1c(%rsp),%edi
  81b159:	xor    %r8d,%r8d
  81b15c:	mov    0x18(%rsp),%r9d
  81b161:	pcmpeqd %xmm1,%xmm1
  81b165:	and    %rdx,%rax
  81b168:	movdqu (%rcx,%rax,1),%xmm2
  81b16d:	movdqa %xmm2,%xmm3
  81b171:	pcmpeqb %xmm0,%xmm3
  81b175:	pmovmskb %xmm3,%r10d
  81b17a:	test   %r10d,%r10d
  81b17d:	je     81b1c0 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xe0>
  81b17f:	tzcnt  %r10d,%r14d
  81b184:	add    %rax,%r14
  81b187:	and    %rdx,%r14
  81b18a:	shl    $0x5,%r14
  81b18e:	mov    %rcx,%r11
  81b191:	sub    %r14,%r11
  81b194:	cmp    -0x20(%r11),%rsi
  81b198:	jne    81b1a7 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xc7>
  81b19a:	cmp    -0x14(%r11),%di
  81b19f:	jne    81b1a7 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xc7>
  81b1a1:	cmp    -0x18(%r11),%r9d
  81b1a5:	je     81b1db <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xfb>
  81b1a7:	lea    -0x1(%r10),%r11d
  81b1ab:	and    %r10w,%r11w
  81b1af:	mov    %r11d,%r10d
  81b1b2:	jne    81b17f <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x9f>
  81b1b4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  81b1c0:	pcmpeqb %xmm1,%xmm2
  81b1c4:	pmovmskb %xmm2,%r10d
  81b1c9:	test   %r10d,%r10d
  81b1cc:	jne    81b20c <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x12c>
  81b1ce:	add    %r8,%rax
  81b1d1:	add    $0x10,%rax
  81b1d5:	add    $0x10,%r8
  81b1d9:	jmp    81b165 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x85>
  81b1db:	mov    -0x4(%r11),%eax
  81b1df:	shl    $0x10,%eax
  81b1e2:	or     -0x8(%r11),%eax
  81b1e6:	mov    -0x10(%r11),%rcx
  81b1ea:	mov    %rcx,(%rbx)
  81b1ed:	mov    %eax,0x8(%rbx)
  81b1f0:	add    $0x38,%rsp
  81b1f4:	pop    %rbx
  81b1f5:	pop    %r14
  81b1f7:	ret
  81b1f8:	mov    0x8(%rdx),%eax
  81b1fb:	mov    %eax,0x8(%rbx)
  81b1fe:	mov    (%rdx),%rax
  81b201:	mov    %rax,(%rbx)
  81b204:	add    $0x38,%rsp
  81b208:	pop    %rbx
  81b209:	pop    %r14
  81b20b:	ret
  81b20c:	lea    -0x746a41(%rip),%rdi        # d47d2 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x12c>
  81b213:	lea    0x612e9e(%rip),%rdx        # e2e0b8 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.1466513483089798867+0x90>
  81b21a:	mov    $0x16,%esi
  81b21f:	call   *0x66491b(%rip)        # e7fb40 <_DYNAMIC+0x5a0>

/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081b230 <<gpui_gpu::renderer::Changes>::replace::<2>>:
  81b230:	push   %r14
  81b232:	push   %rbx
  81b233:	push   %rax
  81b234:	cmp    %rdx,%rcx
  81b237:	jae    81b2da <<gpui_gpu::renderer::Changes>::replace::<2>+0xaa>
  81b23d:	mov    (%rdi),%rax
  81b240:	mov    0x8(%rdi),%r10
  81b244:	mov    %rcx,%r11
  81b247:	shl    $0x4,%r11
  81b24b:	mov    0x8(%rsi,%r11,1),%rbx
  81b250:	xor    %r9,%rbx
  81b253:	mov    (%rsi,%r11,1),%r14
  81b257:	xor    %r8,%r14
  81b25a:	or     %rbx,%r14
  81b25d:	jne    81b264 <<gpui_gpu::renderer::Changes>::replace::<2>+0x34>
  81b25f:	inc    %rcx
  81b262:	jmp    81b286 <<gpui_gpu::renderer::Changes>::replace::<2>+0x56>
  81b264:	add    %rsi,%r11
  81b267:	cmp    %rax,%rcx
  81b26a:	cmovb  %rcx,%rax
  81b26e:	inc    %rcx
  81b271:	cmp    %r10,%rcx
  81b274:	cmova  %rcx,%r10
  81b278:	mov    %rax,(%rdi)
  81b27b:	mov    %r10,0x8(%rdi)
  81b27f:	mov    %r9,0x8(%r11)
  81b283:	mov    %r8,(%r11)
  81b286:	cmp    %rdx,%rcx
  81b289:	jae    81b2da <<gpui_gpu::renderer::Changes>::replace::<2>+0xaa>
  81b28b:	mov    0x28(%rsp),%r8
  81b290:	mov    0x20(%rsp),%rdx
  81b295:	mov    %rcx,%r9
  81b298:	shl    $0x4,%r9
  81b29c:	mov    0x8(%rsi,%r9,1),%r11
  81b2a1:	xor    %r8,%r11
  81b2a4:	mov    (%rsi,%r9,1),%rbx
  81b2a8:	xor    %rdx,%rbx
  81b2ab:	or     %r11,%rbx
  81b2ae:	je     81b2d2 <<gpui_gpu::renderer::Changes>::replace::<2>+0xa2>
  81b2b0:	add    %r9,%rsi
  81b2b3:	cmp    %rax,%rcx
  81b2b6:	cmovb  %rcx,%rax
  81b2ba:	inc    %rcx
  81b2bd:	cmp    %r10,%rcx
  81b2c0:	cmovbe %r10,%rcx
  81b2c4:	mov    %rax,(%rdi)
  81b2c7:	mov    %rcx,0x8(%rdi)
  81b2cb:	mov    %r8,0x8(%rsi)
  81b2cf:	mov    %rdx,(%rsi)
  81b2d2:	add    $0x8,%rsp
  81b2d6:	pop    %rbx
  81b2d7:	pop    %r14
  81b2d9:	ret
  81b2da:	lea    0x612d47(%rip),%rax        # e2e028 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.1466513483089798867>
  81b2e1:	mov    %rcx,%rdi
  81b2e4:	mov    %rdx,%rsi
  81b2e7:	mov    %rax,%rdx
  81b2ea:	call   *0x6647a8(%rip)        # e7fa98 <_DYNAMIC+0x4f8>

/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081b5e0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>:
  81b5e0:	push   %r14
  81b5e2:	push   %rbx
  81b5e3:	push   %rax
  81b5e4:	mov    %rdi,%rbx
  81b5e7:	mov    (%rdi),%rax
  81b5ea:	lock decq (%rax)
  81b5ee:	jne    81b5f9 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x19>
  81b5f0:	mov    %rbx,%rdi
  81b5f3:	call   *0x66448f(%rip)        # e7fa88 <_DYNAMIC+0x4e8>
  81b5f9:	mov    0x50(%rbx),%rax
  81b5fd:	lock decq (%rax)
  81b601:	jne    81b60d <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x2d>
  81b603:	lea    0x50(%rbx),%rdi
  81b607:	call   *0x664473(%rip)        # e7fa80 <_DYNAMIC+0x4e0>
  81b60d:	mov    0x58(%rbx),%rax
  81b611:	lock decq (%rax)
  81b615:	jne    81b621 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x41>
  81b617:	lea    0x58(%rbx),%rdi
  81b61b:	call   *0x664467(%rip)        # e7fa88 <_DYNAMIC+0x4e8>
  81b621:	mov    0xb0(%rbx),%rsi
  81b628:	test   %rsi,%rsi
  81b62b:	je     81b65d <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  81b62d:	mov    %rsi,%rax
  81b630:	shl    $0x5,%rax
  81b634:	add    %rax,%rsi
  81b637:	add    $0x31,%rsi
  81b63b:	je     81b65d <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  81b63d:	mov    0xa8(%rbx),%rdi
  81b644:	sub    %rax,%rdi
  81b647:	add    $0xffffffffffffffe0,%rdi
  81b64b:	mov    $0x10,%edx
  81b650:	add    $0x8,%rsp
  81b654:	pop    %rbx
  81b655:	pop    %r14
  81b657:	jmp    *0x66418b(%rip)        # e7f7e8 <_DYNAMIC+0x248>
  81b65d:	add    $0x8,%rsp
  81b661:	pop    %rbx
  81b662:	pop    %r14
  81b664:	ret
  81b665:	mov    %rax,%r14
  81b668:	jmp    81b695 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  81b66a:	mov    %rax,%r14
  81b66d:	mov    0x58(%rbx),%rax
  81b671:	lock decq (%rax)
  81b675:	jne    81b695 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  81b677:	lea    0x58(%rbx),%rdi
  81b67b:	call   *0x664407(%rip)        # e7fa88 <_DYNAMIC+0x4e8>
  81b681:	jmp    81b695 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  81b683:	call   *0x664167(%rip)        # e7f7f0 <_DYNAMIC+0x250>
  81b689:	mov    %rax,%r14
  81b68c:	lea    0x50(%rbx),%rdi
  81b690:	call   81bf30 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  81b695:	add    $0xa8,%rbx
  81b69c:	mov    %rbx,%rdi
  81b69f:	call   822bf0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>
  81b6a4:	mov    %r14,%rdi
  81b6a7:	call   e2c310 <_Unwind_Resume@plt>
  81b6ac:	call   *0x66413e(%rip)        # e7f7f0 <_DYNAMIC+0x250>

/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081b6c0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>:
  81b6c0:	push   %r14
  81b6c2:	push   %rbx
  81b6c3:	push   %rax
  81b6c4:	mov    %rdi,%rbx
  81b6c7:	mov    (%rdi),%rax
  81b6ca:	lock decq (%rax)
  81b6ce:	jne    81b6d9 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x19>
  81b6d0:	mov    %rbx,%rdi
  81b6d3:	call   *0x6643cf(%rip)        # e7faa8 <_DYNAMIC+0x508>
  81b6d9:	mov    0x8(%rbx),%rax
  81b6dd:	lock decq (%rax)
  81b6e1:	jne    81b6f7 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x37>
  81b6e3:	add    $0x8,%rbx
  81b6e7:	mov    %rbx,%rdi
  81b6ea:	add    $0x8,%rsp
  81b6ee:	pop    %rbx
  81b6ef:	pop    %r14
  81b6f1:	jmp    *0x6643b9(%rip)        # e7fab0 <_DYNAMIC+0x510>
  81b6f7:	add    $0x8,%rsp
  81b6fb:	pop    %rbx
  81b6fc:	pop    %r14
  81b6fe:	ret
  81b6ff:	mov    %rax,%r14
  81b702:	mov    0x8(%rbx),%rax
  81b706:	lock decq (%rax)
  81b70a:	jne    81b719 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x59>
  81b70c:	add    $0x8,%rbx
  81b710:	mov    %rbx,%rdi
  81b713:	call   *0x664397(%rip)        # e7fab0 <_DYNAMIC+0x510>
  81b719:	mov    %r14,%rdi
  81b71c:	call   e2c310 <_Unwind_Resume@plt>
  81b721:	call   *0x6640c9(%rip)        # e7f7f0 <_DYNAMIC+0x250>

/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081c060 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>>:
  81c060:	push   %rbp
  81c061:	push   %r15
  81c063:	push   %r14
  81c065:	push   %r13
  81c067:	push   %r12
  81c069:	push   %rbx
  81c06a:	sub    $0x28,%rsp
  81c06e:	movss  0x8c(%rdi),%xmm3
  81c076:	movss  -0x76d042(%rip),%xmm0        # af03c <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  81c07e:	movaps %xmm3,%xmm1
  81c081:	subss  %xmm0,%xmm1
  81c085:	cvttss2si %xmm1,%rax
  81c08a:	cvttss2si %xmm3,%r8
  81c08f:	mov    %r8,%rcx
  81c092:	sar    $0x3f,%rcx
  81c096:	and    %rax,%rcx
  81c099:	or     %r8,%rcx
  81c09c:	xor    %r9d,%r9d
  81c09f:	xorps  %xmm1,%xmm1
  81c0a2:	ucomiss %xmm1,%xmm3
  81c0a5:	cmovb  %r9,%rcx
  81c0a9:	movss  -0x76d071(%rip),%xmm2        # af040 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  81c0b1:	ucomiss %xmm2,%xmm3
  81c0b4:	mov    $0xffffffffffffffff,%rax
  81c0bb:	cmova  %rax,%rcx
  81c0bf:	movss  0x94(%rdi),%xmm3
  81c0c7:	mov    %rcx,%r8
  81c0ca:	shr    $0x4,%r8
  81c0ce:	movaps %xmm3,%xmm4
  81c0d1:	subss  %xmm0,%xmm4
  81c0d5:	cvttss2si %xmm4,%r10
  81c0da:	cvttss2si %xmm3,%r11
  81c0df:	mov    %r11,%rbx
  81c0e2:	sar    $0x3f,%rbx
  81c0e6:	and    %r10,%rbx
  81c0e9:	or     %r11,%rbx
  81c0ec:	ucomiss %xmm1,%xmm3
  81c0ef:	cmovb  %r9,%rbx
  81c0f3:	ucomiss %xmm2,%xmm3
  81c0f6:	cmova  %rax,%rbx
  81c0fa:	mov    %rsi,0x18(%rsp)
  81c0ff:	lea    (%rcx,%rbx,1),%r11
  81c103:	dec    %r11
  81c106:	shr    $0x4,%r11
  81c10a:	cmp    %r11,%r8
  81c10d:	jbe    81c11e <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xbe>
  81c10f:	add    $0x28,%rsp
  81c113:	pop    %rbx
  81c114:	pop    %r12
  81c116:	pop    %r13
  81c118:	pop    %r14
  81c11a:	pop    %r15
  81c11c:	pop    %rbp
  81c11d:	ret
  81c11e:	movss  0x88(%rdi),%xmm3
  81c126:	movaps %xmm3,%xmm4
  81c129:	subss  %xmm0,%xmm4
  81c12d:	cvttss2si %xmm4,%rsi
  81c132:	cvttss2si %xmm3,%r9
  81c137:	mov    %r9,%rcx
  81c13a:	sar    $0x3f,%rcx
  81c13e:	and    %rsi,%rcx
  81c141:	or     %r9,%rcx
  81c144:	xor    %r10d,%r10d
  81c147:	ucomiss %xmm1,%xmm3
  81c14a:	cmovb  %r10,%rcx
  81c14e:	ucomiss %xmm2,%xmm3
  81c151:	cmova  %rax,%rcx
  81c155:	movss  0x90(%rdi),%xmm3
  81c15d:	mov    %rcx,%r14
  81c160:	shr    $0x4,%r14
  81c164:	movaps %xmm3,%xmm4
  81c167:	subss  %xmm0,%xmm4
  81c16b:	cvttss2si %xmm4,%rsi
  81c170:	cvttss2si %xmm3,%rdi
  81c175:	mov    %rdi,%r9
  81c178:	sar    $0x3f,%r9
  81c17c:	and    %rsi,%r9
  81c17f:	or     %rdi,%r9
  81c182:	ucomiss %xmm1,%xmm3
  81c185:	cmovb  %r10,%r9
  81c189:	ucomiss %xmm2,%xmm3
  81c18c:	cmova  %rax,%r9
  81c190:	lea    (%r9,%rcx,1),%rbx
  81c194:	dec    %rbx
  81c197:	shr    $0x4,%rbx
  81c19b:	mov    %r14,0x10(%rsp)
  81c1a0:	cmp    %rbx,%r14
  81c1a3:	jbe    81c1cd <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x16d>
  81c1a5:	data16 cs nopw 0x0(%rax,%rax,1)
  81c1b0:	mov    %r8,%rax
  81c1b3:	cmp    %r11,%r8
  81c1b6:	adc    $0x0,%r8
  81c1ba:	cmp    %r11,%rax
  81c1bd:	jae    81c10f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c1c3:	cmp    %r11,%r8
  81c1c6:	jbe    81c1b0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x150>
  81c1c8:	jmp    81c10f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c1cd:	mov    (%rdx),%r14
  81c1d0:	mov    0x8(%rdx),%r15
  81c1d4:	mov    0x10(%rdx),%r12
  81c1d8:	mov    0x18(%rdx),%r13
  81c1dc:	mov    0x20(%rdx),%rdx
  81c1e0:	mov    %r11,0x8(%rsp)
  81c1e5:	data16 cs nopw 0x0(%rax,%rax,1)
  81c1f0:	mov    %r8,%rbp
  81c1f3:	cmp    %r11,%r8
  81c1f6:	adc    $0x0,%r8
  81c1fa:	mov    %rbp,0x20(%rsp)
  81c1ff:	imul   0x18(%rsp),%rbp
  81c205:	mov    0x10(%rsp),%r9
  81c20a:	mov    %r9,%rsi
  81c20d:	nopl   (%rax)
  81c210:	cmp    %rbx,%r9
  81c213:	adc    $0x0,%rsi
  81c217:	lea    (%r9,%rbp,1),%rdi
  81c21b:	mov    0x10(%r14),%rax
  81c21f:	cmp    %rax,%rdi
  81c222:	jae    81c290 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x230>
  81c224:	mov    0x8(%r14),%rcx
  81c228:	cmp    0x4(%rcx,%rdi,8),%r10d
  81c22d:	jo     81c265 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x205>
  81c22f:	mov    0x10(%r12),%rax
  81c234:	cmp    %rax,%rdi
  81c237:	jae    81c2a0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x240>
  81c239:	mov    0x8(%r12),%rax
  81c23e:	mov    0x0(%r13),%r11d
  81c242:	inc    %r11d
  81c245:	cmp    (%rax,%rdi,4),%r11d
  81c249:	jb     81c265 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x205>
  81c24b:	mov    (%rcx,%rdi,8),%eax
  81c24e:	dec    %eax
  81c250:	mov    %eax,(%rcx,%rdi,8)
  81c253:	mov    0x10(%r15),%rcx
  81c257:	cmp    %rax,%rcx
  81c25a:	jbe    81c2b0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x250>
  81c25c:	mov    0x8(%r15),%rcx
  81c260:	mov    (%rdx),%edi
  81c262:	mov    %edi,(%rcx,%rax,4)
  81c265:	cmp    %rbx,%r9
  81c268:	jae    81c272 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x212>
  81c26a:	mov    %rsi,%r9
  81c26d:	cmp    %rbx,%rsi
  81c270:	jbe    81c210 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x1b0>
  81c272:	mov    0x8(%rsp),%r11
  81c277:	cmp    %r11,0x20(%rsp)
  81c27c:	jae    81c10f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c282:	cmp    %r11,%r8
  81c285:	jbe    81c1f0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x190>
  81c28b:	jmp    81c10f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c290:	lea    0x611e39(%rip),%rdx        # e2e0d0 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.1466513483089798867+0xa8>
  81c297:	mov    %rax,%rsi
  81c29a:	call   *0x6637f8(%rip)        # e7fa98 <_DYNAMIC+0x4f8>
  81c2a0:	lea    0x611e41(%rip),%rdx        # e2e0e8 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.1466513483089798867+0xc0>
  81c2a7:	mov    %rax,%rsi
  81c2aa:	call   *0x6637e8(%rip)        # e7fa98 <_DYNAMIC+0x4f8>
  81c2b0:	lea    0x611e49(%rip),%rdx        # e2e100 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.1466513483089798867+0xd8>
  81c2b7:	mov    %rax,%rdi
  81c2ba:	mov    %rcx,%rsi
  81c2bd:	call   *0x6637d5(%rip)        # e7fa98 <_DYNAMIC+0x4f8>

/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081c2d0 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>>:
  81c2d0:	push   %rbp
  81c2d1:	push   %r15
  81c2d3:	push   %r14
  81c2d5:	push   %r13
  81c2d7:	push   %r12
  81c2d9:	push   %rbx
  81c2da:	sub    $0xc8,%rsp
  81c2e1:	mov    %esi,%ebp
  81c2e3:	mov    %rdi,%rbx
  81c2e6:	lea    0x8(%rsp),%rdi
  81c2eb:	mov    %rbx,%rsi
  81c2ee:	call   *0x663864(%rip)        # e7fb58 <_DYNAMIC+0x5b8>
  81c2f4:	mov    0x8(%rsp),%rsi
  81c2f9:	xor    %r14d,%r14d
  81c2fc:	test   $0x1,%bpl
  81c300:	je     81c378 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0xa8>
  81c302:	test   %rsi,%rsi
  81c305:	je     81c3a6 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0xd6>
  81c30b:	mov    $0x1,%r13d
  81c311:	lea    0x8(%rsp),%r12
  81c316:	mov    0x66383b(%rip),%rbp        # e7fb58 <_DYNAMIC+0x5b8>
  81c31d:	jmp    81c335 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0x65>
  81c31f:	nop
  81c320:	add    %r15,%r14
  81c323:	mov    %r12,%rdi
  81c326:	mov    %rbx,%rsi
  81c329:	call   *%rbp
  81c32b:	mov    0x8(%rsp),%rsi
  81c330:	test   %rsi,%rsi
  81c333:	je     81c3a6 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0xd6>
  81c335:	mov    0x18(%rsp),%r15
  81c33a:	cmp    $0x2,%r15
  81c33e:	jb     81c320 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0x50>
  81c340:	mov    0x10(%rsp),%rax
  81c345:	mov    (%rax),%edx
  81c347:	lea    0x70(%rsp),%rdi
  81c34c:	call   81c3c0 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81c351:	movss  0x74(%rsp),%xmm0
  81c357:	xorps  %xmm1,%xmm1
  81c35a:	ucomiss %xmm1,%xmm0
  81c35d:	mov    $0x1,%eax
  81c362:	cmovne %r15,%rax
  81c366:	cmovp  %r15,%rax
  81c36a:	cmpb   $0x3,0x70(%rsp)
  81c36f:	cmovne %r13,%rax
  81c373:	mov    %rax,%r15
  81c376:	jmp    81c320 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0x50>
  81c378:	test   %rsi,%rsi
  81c37b:	je     81c3a6 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0xd6>
  81c37d:	lea    0x8(%rsp),%r15
  81c382:	mov    0x6637cf(%rip),%r12        # e7fb58 <_DYNAMIC+0x5b8>
  81c389:	nopl   0x0(%rax)
  81c390:	add    0x18(%rsp),%r14
  81c395:	mov    %r15,%rdi
  81c398:	mov    %rbx,%rsi
  81c39b:	call   *%r12
  81c39e:	cmpq   $0x0,0x8(%rsp)
  81c3a4:	jne    81c390 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0xc0>
  81c3a6:	mov    %r14,%rax
  81c3a9:	add    $0xc8,%rsp
  81c3b0:	pop    %rbx
  81c3b1:	pop    %r12
  81c3b3:	pop    %r13
  81c3b5:	pop    %r14
  81c3b7:	pop    %r15
  81c3b9:	pop    %rbp
  81c3ba:	ret

/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081c600 <<gpui_gpu::renderer::Renderer>::set_grouped_records>:
  81c600:	push   %rbp
  81c601:	push   %r14
  81c603:	push   %rbx
  81c604:	cmp    0x341(%rdi),%sil
  81c60b:	je     81c64b <<gpui_gpu::renderer::Renderer>::set_grouped_records+0x4b>
  81c60d:	mov    0x330(%rdi),%rax
  81c614:	test   %rax,%rax
  81c617:	je     81c639 <<gpui_gpu::renderer::Renderer>::set_grouped_records+0x39>
  81c619:	lock decq (%rax)
  81c61d:	jne    81c639 <<gpui_gpu::renderer::Renderer>::set_grouped_records+0x39>
  81c61f:	lea    0x330(%rdi),%rbx
  81c626:	mov    %rdi,%r14
  81c629:	mov    %rbx,%rdi
  81c62c:	mov    %esi,%ebp
  81c62e:	call   *0x663484(%rip)        # e7fab8 <_DYNAMIC+0x518>
  81c634:	mov    %r14,%rdi
  81c637:	mov    %ebp,%esi
  81c639:	movq   $0x0,0x330(%rdi)
  81c644:	mov    %sil,0x341(%rdi)
  81c64b:	pop    %rbx
  81c64c:	pop    %r14
  81c64e:	pop    %rbp
  81c64f:	ret
  81c650:	movq   $0x0,(%rbx)
  81c657:	mov    %rax,%rdi
  81c65a:	call   e2c310 <_Unwind_Resume@plt>

/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081c660 <<gpui_gpu::renderer::Changes>::upload>:
  81c660:	push   %rbx
  81c661:	mov    %rsi,%rbx
  81c664:	sub    %rdi,%rbx
  81c667:	jbe    81c696 <<gpui_gpu::renderer::Changes>::upload+0x36>
  81c669:	mov    %rdx,%rax
  81c66c:	mov    %rdi,%rdx
  81c66f:	cmp    %rcx,%rsi
  81c672:	ja     81c69d <<gpui_gpu::renderer::Changes>::upload+0x3d>
  81c674:	shl    $0x4,%rdx
  81c678:	add    %rdx,%rax
  81c67b:	shl    $0x4,%rbx
  81c67f:	mov    %r9,%rdi
  81c682:	mov    %r8,%rsi
  81c685:	mov    %rax,%rcx
  81c688:	mov    %rbx,%r8
  81c68b:	call   *0x6634df(%rip)        # e7fb70 <_DYNAMIC+0x5d0>
  81c691:	mov    %rbx,%rax
  81c694:	pop    %rbx
  81c695:	ret
  81c696:	xor    %ebx,%ebx
  81c698:	mov    %rbx,%rax
  81c69b:	pop    %rbx
  81c69c:	ret
  81c69d:	lea    0x611abc(%rip),%rax        # e2e160 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.1466513483089798867+0x138>
  81c6a4:	mov    %rdx,%rdi
  81c6a7:	mov    %rcx,%rdx
  81c6aa:	mov    %rax,%rcx
  81c6ad:	call   *0x663435(%rip)        # e7fae8 <_DYNAMIC+0x548>

/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081c6c0 <<gpui_gpu::renderer::Buffer>::write>:
  81c6c0:	push   %r15
  81c6c2:	push   %r14
  81c6c4:	push   %r12
  81c6c6:	push   %rbx
  81c6c7:	push   %rax
  81c6c8:	mov    %r8,%r12
  81c6cb:	mov    %rcx,%rbx
  81c6ce:	mov    %rdx,%r14
  81c6d1:	mov    %rdi,%r15
  81c6d4:	mov    %r8,%rdx
  81c6d7:	call   81c710 <<gpui_gpu::renderer::Buffer>::reserve>
  81c6dc:	test   %r12,%r12
  81c6df:	je     81c700 <<gpui_gpu::renderer::Buffer>::write+0x40>
  81c6e1:	mov    %r14,%rdi
  81c6e4:	mov    %r15,%rsi
  81c6e7:	xor    %edx,%edx
  81c6e9:	mov    %rbx,%rcx
  81c6ec:	mov    %r12,%r8
  81c6ef:	add    $0x8,%rsp
  81c6f3:	pop    %rbx
  81c6f4:	pop    %r12
  81c6f6:	pop    %r14
  81c6f8:	pop    %r15
  81c6fa:	jmp    *0x663470(%rip)        # e7fb70 <_DYNAMIC+0x5d0>
  81c700:	add    $0x8,%rsp
  81c704:	pop    %rbx
  81c705:	pop    %r12
  81c707:	pop    %r14
  81c709:	pop    %r15
  81c70b:	ret

/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081c710 <<gpui_gpu::renderer::Buffer>::reserve>:
  81c710:	push   %r15
  81c712:	push   %r14
  81c714:	push   %r12
  81c716:	push   %rbx
  81c717:	sub    $0x48,%rsp
  81c71b:	mov    %rdx,%r14
  81c71e:	mov    0x20(%rdi),%r15
  81c722:	cmp    %r15,%rdx
  81c725:	jbe    81c7ca <<gpui_gpu::renderer::Buffer>::reserve+0xba>
  81c72b:	mov    %rdi,%rbx
  81c72e:	mov    $0x1,%r12d
  81c734:	cmp    $0x2,%r14
  81c738:	jb     81c751 <<gpui_gpu::renderer::Buffer>::reserve+0x41>
  81c73a:	lea    -0x1(%r14),%rax
  81c73e:	bsr    %rax,%rcx
  81c742:	not    %ecx
  81c744:	mov    $0xffffffffffffffff,%r12
  81c74b:	shr    %cl,%r12
  81c74e:	inc    %r12
  81c751:	lea    -0x747f70(%rip),%rax        # d47e8 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x142>
  81c758:	mov    %rax,0x28(%rsp)
  81c75d:	movq   $0xa,0x30(%rsp)
  81c766:	mov    %r12,0x38(%rsp)
  81c76b:	movl   $0x88,0x40(%rsp)
  81c773:	movb   $0x0,0x44(%rsp)
  81c778:	mov    %rsp,%rdi
  81c77b:	lea    0x28(%rsp),%rdx
  81c780:	call   *0x66343a(%rip)        # e7fbc0 <_DYNAMIC+0x620>
  81c786:	mov    %r12,0x20(%rsp)
  81c78b:	mov    (%rbx),%rax
  81c78e:	lock decq (%rax)
  81c792:	jne    81c79d <<gpui_gpu::renderer::Buffer>::reserve+0x8d>
  81c794:	mov    %rbx,%rdi
  81c797:	call   *0x66330b(%rip)        # e7faa8 <_DYNAMIC+0x508>
  81c79d:	mov    0x8(%rbx),%rax
  81c7a1:	lock decq (%rax)
  81c7a5:	jne    81c7b1 <<gpui_gpu::renderer::Buffer>::reserve+0xa1>
  81c7a7:	lea    0x8(%rbx),%rdi
  81c7ab:	call   *0x6632ff(%rip)        # e7fab0 <_DYNAMIC+0x510>
  81c7b1:	mov    0x20(%rsp),%rax
  81c7b6:	mov    %rax,0x20(%rbx)
  81c7ba:	movups (%rsp),%xmm0
  81c7be:	movups 0x10(%rsp),%xmm1
  81c7c3:	movups %xmm1,0x10(%rbx)
  81c7c7:	movups %xmm0,(%rbx)
  81c7ca:	cmp    %r15,%r14
  81c7cd:	seta   %al
  81c7d0:	add    $0x48,%rsp
  81c7d4:	pop    %rbx
  81c7d5:	pop    %r12
  81c7d7:	pop    %r14
  81c7d9:	pop    %r15
  81c7db:	ret
  81c7dc:	mov    %rax,%r14
  81c7df:	jmp    81c7f8 <<gpui_gpu::renderer::Buffer>::reserve+0xe8>
  81c7e1:	mov    %rax,%r14
  81c7e4:	mov    0x8(%rbx),%rax
  81c7e8:	lock decq (%rax)
  81c7ec:	jne    81c7f8 <<gpui_gpu::renderer::Buffer>::reserve+0xe8>
  81c7ee:	lea    0x8(%rbx),%rdi
  81c7f2:	call   *0x6632b8(%rip)        # e7fab0 <_DYNAMIC+0x510>
  81c7f8:	mov    0x20(%rsp),%rax
  81c7fd:	mov    %rax,0x20(%rbx)
  81c801:	movups (%rsp),%xmm0
  81c805:	movups 0x10(%rsp),%xmm1
  81c80a:	movups %xmm1,0x10(%rbx)
  81c80e:	movups %xmm0,(%rbx)
  81c811:	mov    %r14,%rdi
  81c814:	call   e2c310 <_Unwind_Resume@plt>
  81c819:	call   *0x662fd1(%rip)        # e7f7f0 <_DYNAMIC+0x250>

/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081c820 <<gpui_gpu::renderer::Atlas>::new>:
  81c820:	push   %rbp
  81c821:	push   %r14
  81c823:	push   %rbx
  81c824:	sub    $0x160,%rsp
  81c82b:	mov    %edx,%ebp
  81c82d:	mov    %rdi,%rbx
  81c830:	lea    -0x748045(%rip),%rax        # d47f2 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x14c>
  81c837:	mov    %rax,(%rsp)
  81c83b:	movq   $0xe,0x8(%rsp)
  81c844:	mov    %edx,0x10(%rsp)
  81c848:	mov    %edx,0x14(%rsp)
  81c84c:	movaps -0x7702e3(%rip),%xmm0        # ac570 <anon.531a4b6c7f642b9eba5e0e986955623b.109.llvm.14547199655466482296+0x2c0>
  81c853:	movups %xmm0,0x18(%rsp)
  81c858:	movl   $0x0,0x28(%rsp)
  81c860:	movl   $0x6,0x34(%rsp)
  81c868:	movq   $0x4,0x38(%rsp)
  81c871:	movq   $0x0,0x40(%rsp)
  81c87a:	lea    0x110(%rsp),%r14
  81c882:	mov    %rsp,%rdx
  81c885:	mov    %r14,%rdi
  81c888:	call   *0x6631b2(%rip)        # e7fa40 <_DYNAMIC+0x4a0>
  81c88e:	movq   $0x0,0x18(%rsp)
  81c897:	movl   $0xffffffff,0x30(%rsp)
  81c89f:	movl   $0x0,(%rsp)
  81c8a6:	movabs $0xffffffff00000000,%rax
  81c8b0:	mov    %rax,0x28(%rsp)
  81c8b5:	movq   $0x0,0x3c(%rsp)
  81c8be:	movl   $0x0,0x8(%rsp)
  81c8c6:	movl   $0x0,0x10(%rsp)
  81c8ce:	lea    0xb8(%rsp),%rdi
  81c8d6:	mov    %rsp,%rdx
  81c8d9:	mov    %r14,%rsi
  81c8dc:	call   *0x663166(%rip)        # e7fa48 <_DYNAMIC+0x4a8>
  81c8e2:	movups 0x150(%rsp),%xmm0
  81c8ea:	movaps %xmm0,0xa0(%rsp)
  81c8f2:	movups 0x110(%rsp),%xmm0
  81c8fa:	movups 0x120(%rsp),%xmm1
  81c902:	movups 0x130(%rsp),%xmm2
  81c90a:	movups 0x140(%rsp),%xmm3
  81c912:	movaps %xmm3,0x90(%rsp)
  81c91a:	movaps %xmm2,0x80(%rsp)
  81c922:	movaps %xmm1,0x70(%rsp)
  81c927:	movaps %xmm0,0x60(%rsp)
  81c92c:	mov    0x108(%rsp),%rax
  81c934:	mov    %rax,0x50(%rsp)
  81c939:	movups 0xf8(%rsp),%xmm0
  81c941:	movaps %xmm0,0x40(%rsp)
  81c946:	movups 0xb8(%rsp),%xmm0
  81c94e:	movups 0xc8(%rsp),%xmm1
  81c956:	movups 0xd8(%rsp),%xmm2
  81c95e:	movups 0xe8(%rsp),%xmm3
  81c966:	movaps %xmm3,0x30(%rsp)
  81c96b:	movaps %xmm2,0x20(%rsp)
  81c970:	movaps %xmm1,0x10(%rsp)
  81c975:	movaps %xmm0,(%rsp)
  81c979:	mov    %fs:0x0,%rax
  81c982:	lea    -0x28(%rax),%rax
  81c989:	mov    %rax,%r14
  81c98c:	cmpb   $0x1,0x10(%rax)
  81c990:	jne    81ca7b <<gpui_gpu::renderer::Atlas>::new+0x25b>
  81c996:	mov    (%r14),%rax
  81c999:	mov    0x8(%r14),%rdx
  81c99d:	lea    0x1(%rax),%rcx
  81c9a1:	mov    %rcx,(%r14)
  81c9a4:	movaps 0xa0(%rsp),%xmm0
  81c9ac:	movups %xmm0,0x40(%rbx)
  81c9b0:	movaps 0x60(%rsp),%xmm0
  81c9b5:	movaps 0x70(%rsp),%xmm1
  81c9ba:	movaps 0x80(%rsp),%xmm2
  81c9c2:	movaps 0x90(%rsp),%xmm3
  81c9ca:	movups %xmm3,0x30(%rbx)
  81c9ce:	movups %xmm2,0x20(%rbx)
  81c9d2:	movups %xmm1,0x10(%rbx)
  81c9d6:	movups %xmm0,(%rbx)
  81c9d9:	movups 0xb8(%rsp),%xmm0
  81c9e1:	movups 0xc8(%rsp),%xmm1
  81c9e9:	movups 0xd8(%rsp),%xmm2
  81c9f1:	movups 0xe8(%rsp),%xmm3
  81c9f9:	movups %xmm0,0x50(%rbx)
  81c9fd:	movups %xmm1,0x60(%rbx)
  81ca01:	movups %xmm2,0x70(%rbx)
  81ca05:	movups %xmm3,0x80(%rbx)
  81ca0c:	movups 0xf8(%rsp),%xmm0
  81ca14:	movups %xmm0,0x90(%rbx)
  81ca1b:	mov    0x108(%rsp),%rcx
  81ca23:	mov    %rcx,0xa0(%rbx)
  81ca2a:	mov    %ebp,0xd8(%rbx)
  81ca30:	movq   $0x0,0xdc(%rbx)
  81ca3b:	movl   $0x0,0xe4(%rbx)
  81ca45:	movups 0x6117bc(%rip),%xmm0        # e2e208 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.1466513483089798867+0x1e0>
  81ca4c:	movups %xmm0,0xa8(%rbx)
  81ca53:	movups 0x6117be(%rip),%xmm0        # e2e218 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.1466513483089798867+0x1f0>
  81ca5a:	movups %xmm0,0xb8(%rbx)
  81ca61:	mov    %rax,0xc8(%rbx)
  81ca68:	mov    %rdx,0xd0(%rbx)
  81ca6f:	add    $0x160,%rsp
  81ca76:	pop    %rbx
  81ca77:	pop    %r14
  81ca79:	pop    %rbp
  81ca7a:	ret
  81ca7b:	call   *0x663147(%rip)        # e7fbc8 <_DYNAMIC+0x628>
  81ca81:	mov    %rax,(%r14)
  81ca84:	mov    %rdx,0x8(%r14)
  81ca88:	movb   $0x1,0x10(%r14)
  81ca8d:	jmp    81c99d <<gpui_gpu::renderer::Atlas>::new+0x17d>
  81ca92:	mov    %rax,%rbx
  81ca95:	mov    %rsp,%rdi
  81ca98:	call   81bf30 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  81ca9d:	mov    0x60(%rsp),%rax
  81caa2:	lock decq (%rax)
  81caa6:	jne    81cad4 <<gpui_gpu::renderer::Atlas>::new+0x2b4>
  81caa8:	lea    0x60(%rsp),%rdi
  81caad:	call   *0x662fd5(%rip)        # e7fa88 <_DYNAMIC+0x4e8>
  81cab3:	jmp    81cad4 <<gpui_gpu::renderer::Atlas>::new+0x2b4>
  81cab5:	mov    %rax,%rbx
  81cab8:	mov    0x110(%rsp),%rax
  81cac0:	lock decq (%rax)
  81cac4:	jne    81cad4 <<gpui_gpu::renderer::Atlas>::new+0x2b4>
  81cac6:	lea    0x110(%rsp),%rdi
  81cace:	call   *0x662fb4(%rip)        # e7fa88 <_DYNAMIC+0x4e8>
  81cad4:	mov    %rbx,%rdi
  81cad7:	call   e2c310 <_Unwind_Resume@plt>
  81cadc:	call   *0x662d0e(%rip)        # e7f7f0 <_DYNAMIC+0x250>

/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081caf0 <<gpui_gpu::renderer::Atlas>::insert>:
  81caf0:	push   %rbp
  81caf1:	push   %r15
  81caf3:	push   %r14
  81caf5:	push   %r13
  81caf7:	push   %r12
  81caf9:	push   %rbx
  81cafa:	sub    $0x68,%rsp
  81cafe:	mov    %rdx,%r12
  81cb01:	mov    %rsi,%r15
  81cb04:	mov    %rdi,%r14
  81cb07:	lea    0x10(%rdx),%r13
  81cb0b:	cmpq   $0x0,0xc0(%rdi)
  81cb13:	je     81cbdb <<gpui_gpu::renderer::Atlas>::insert+0xeb>
  81cb19:	lea    0xc8(%r14),%rdi
  81cb20:	mov    %r13,%rsi
  81cb23:	call   824230 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  81cb28:	mov    %rax,%rsi
  81cb2b:	shr    $0x39,%rsi
  81cb2f:	mov    0xa8(%r14),%rcx
  81cb36:	mov    0xb0(%r14),%rdx
  81cb3d:	movd   %esi,%xmm0
  81cb41:	punpcklbw %xmm0,%xmm0
  81cb45:	pshuflw $0x0,%xmm0,%xmm0
  81cb4a:	pshufd $0x44,%xmm0,%xmm0
  81cb4f:	mov    0x10(%r12),%rsi
  81cb54:	movzwl 0x1c(%r12),%edi
  81cb5a:	mov    0x18(%r12),%r8d
  81cb5f:	pcmpeqd %xmm1,%xmm1
  81cb63:	xor    %r9d,%r9d
  81cb66:	and    %rdx,%rax
  81cb69:	movdqu (%rcx,%rax,1),%xmm2
  81cb6e:	movdqa %xmm2,%xmm3
  81cb72:	pcmpeqb %xmm0,%xmm3
  81cb76:	pmovmskb %xmm3,%r10d
  81cb7b:	test   %r10d,%r10d
  81cb7e:	je     81cbc0 <<gpui_gpu::renderer::Atlas>::insert+0xd0>
  81cb80:	tzcnt  %r10d,%ebx
  81cb85:	add    %rax,%rbx
  81cb88:	and    %rdx,%rbx
  81cb8b:	shl    $0x5,%rbx
  81cb8f:	mov    %rcx,%r11
  81cb92:	sub    %rbx,%r11
  81cb95:	cmp    -0x20(%r11),%rsi
  81cb99:	jne    81cbac <<gpui_gpu::renderer::Atlas>::insert+0xbc>
  81cb9b:	cmp    -0x14(%r11),%di
  81cba0:	jne    81cbac <<gpui_gpu::renderer::Atlas>::insert+0xbc>
  81cba2:	cmp    -0x18(%r11),%r8d
  81cba6:	je     81cc43 <<gpui_gpu::renderer::Atlas>::insert+0x153>
  81cbac:	lea    -0x1(%r10),%r11d
  81cbb0:	and    %r10w,%r11w
  81cbb4:	mov    %r11d,%r10d
  81cbb7:	jne    81cb80 <<gpui_gpu::renderer::Atlas>::insert+0x90>
  81cbb9:	nopl   0x0(%rax)
  81cbc0:	pcmpeqb %xmm1,%xmm2
  81cbc4:	pmovmskb %xmm2,%r10d
  81cbc9:	test   %r10d,%r10d
  81cbcc:	jne    81cbdb <<gpui_gpu::renderer::Atlas>::insert+0xeb>
  81cbce:	add    %r9,%rax
  81cbd1:	add    $0x10,%rax
  81cbd5:	add    $0x10,%r9
  81cbd9:	jmp    81cb66 <<gpui_gpu::renderer::Atlas>::insert+0x76>
  81cbdb:	mov    0x20(%r12),%ebp
  81cbe0:	xor    %eax,%eax
  81cbe2:	test   %ebp,%ebp
  81cbe4:	je     81cc3e <<gpui_gpu::renderer::Atlas>::insert+0x14e>
  81cbe6:	mov    %r15,%rdi
  81cbe9:	mov    0x28(%r12),%r15d
  81cbee:	test   %r15d,%r15d
  81cbf1:	je     81cc3e <<gpui_gpu::renderer::Atlas>::insert+0x14e>
  81cbf3:	mov    0xd8(%r14),%ecx
  81cbfa:	cmp    %ebp,%ecx
  81cbfc:	jb     81cd41 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81cc02:	cmp    %r15d,%ecx
  81cc05:	jb     81cd41 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81cc0b:	mov    %r13,0x40(%rsp)
  81cc10:	mov    0xdc(%r14),%r8d
  81cc17:	mov    0xe4(%r14),%r13d
  81cc1e:	lea    (%r8,%rbp,1),%edx
  81cc22:	xor    %eax,%eax
  81cc24:	cmp    %ecx,%edx
  81cc26:	mov    $0x0,%ebx
  81cc2b:	cmova  %r13d,%ebx
  81cc2f:	add    0xe0(%r14),%ebx
  81cc36:	lea    (%rbx,%r15,1),%esi
  81cc3a:	cmp    %ecx,%esi
  81cc3c:	jbe    81cc4f <<gpui_gpu::renderer::Atlas>::insert+0x15f>
  81cc3e:	jmp    81cd41 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81cc43:	mov    $0x1,%eax
  81cc48:	xor    %edx,%edx
  81cc4a:	jmp    81cd41 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81cc4f:	cmp    %r13d,%r15d
  81cc52:	cmova  %r15d,%r13d
  81cc56:	cmp    %ecx,%edx
  81cc58:	cmova  %eax,%r8d
  81cc5c:	lea    0xa8(%r14),%rax
  81cc63:	mov    %rax,0x38(%rsp)
  81cc68:	mov    %r14,0x48(%rsp)
  81cc6d:	movl   $0x0,0x50(%rsp)
  81cc75:	mov    %r8d,0x54(%rsp)
  81cc7a:	mov    %ebx,0x58(%rsp)
  81cc7e:	movq   $0x0,0x5c(%rsp)
  81cc87:	mov    (%r12),%rdx
  81cc8b:	mov    0x8(%r12),%rcx
  81cc90:	mov    %rcx,0x30(%rsp)
  81cc95:	movq   $0x0,0x8(%rsp)
  81cc9e:	movl   $0x1,0x10(%rsp)
  81cca6:	mov    %ebp,0x14(%rsp)
  81ccaa:	movl   $0x1,0x18(%rsp)
  81ccb2:	mov    %r15d,0x1c(%rsp)
  81ccb7:	mov    %ebp,0x20(%rsp)
  81ccbb:	mov    %r15d,0x24(%rsp)
  81ccc0:	movl   $0x1,0x28(%rsp)
  81ccc8:	cmova  %r15d,%r13d
  81cccc:	lea    0x48(%rsp),%rsi
  81ccd1:	mov    %r8,%r12
  81ccd4:	lea    0x8(%rsp),%r8
  81ccd9:	lea    0x20(%rsp),%r9
  81ccde:	call   *0x662eec(%rip)        # e7fbd0 <_DYNAMIC+0x630>
  81cce4:	lea    (%r12,%rbp,1),%eax
  81cce8:	mov    %eax,0xdc(%r14)
  81ccef:	mov    %ebx,0xe0(%r14)
  81ccf6:	mov    %r13d,0xe4(%r14)
  81ccfd:	mov    0x40(%rsp),%rax
  81cd02:	movdqu (%rax),%xmm0
  81cd06:	movdqa %xmm0,0x20(%rsp)
  81cd0c:	mov    %r12d,0x8(%rsp)
  81cd11:	mov    %ebx,0xc(%rsp)
  81cd15:	mov    %ebp,0x10(%rsp)
  81cd19:	mov    %r15d,0x14(%rsp)
  81cd1e:	lea    0x48(%rsp),%rdi
  81cd23:	lea    0x20(%rsp),%rdx
  81cd28:	lea    0x8(%rsp),%rcx
  81cd2d:	mov    0x38(%rsp),%rsi
  81cd32:	call   8257d0 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert>
  81cd37:	mov    0x30(%rsp),%rdx
  81cd3c:	mov    $0x1,%eax
  81cd41:	add    $0x68,%rsp
  81cd45:	pop    %rbx
  81cd46:	pop    %r12
  81cd48:	pop    %r13
  81cd4a:	pop    %r14
  81cd4c:	pop    %r15
  81cd4e:	pop    %rbp
  81cd4f:	ret

/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081cd50 <<gpui_gpu::renderer::GpuContext>::submit>:
  81cd50:	push   %r15
  81cd52:	push   %r14
  81cd54:	push   %r12
  81cd56:	push   %rbx
  81cd57:	sub    $0x548,%rsp
  81cd5e:	mov    %rdx,%r14
  81cd61:	mov    %rsi,%r12
  81cd64:	mov    %rdi,%rbx
  81cd67:	lea    0x6114ba(%rip),%rdx        # e2e228 <anon.36d49f465d299f05a84fba3771e6457e.32.llvm.1466513483089798867>
  81cd6e:	lea    0x30(%rsp),%r15
  81cd73:	mov    %r15,%rdi
  81cd76:	mov    %rbx,%rsi
  81cd79:	call   *0x662e59(%rip)        # e7fbd8 <_DYNAMIC+0x638>
  81cd7f:	xorps  %xmm0,%xmm0
  81cd82:	movups %xmm0,0x10(%rsp)
  81cd87:	movups %xmm0,0x20(%rsp)
  81cd8c:	movl   $0x0,0x50(%rsp)
  81cd94:	movb   $0x0,0x58(%rsp)
  81cd99:	movups 0x9(%rsp),%xmm0
  81cd9e:	movups %xmm0,0x59(%rsp)
  81cda3:	movups 0x19(%rsp),%xmm0
  81cda8:	movups %xmm0,0x69(%rsp)
  81cdad:	mov    0x28(%rsp),%rax
  81cdb2:	mov    %rax,0x78(%rsp)
  81cdb7:	movl   $0x0,0x80(%rsp)
  81cdc2:	mov    %r12,0x88(%rsp)
  81cdca:	movq   $0x0,0x90(%rsp)
  81cdd6:	lea    -0x7485dd(%rip),%rax        # d4800 <anon.36d49f465d299f05a84fba3771e6457e.31.llvm.1466513483089798867>
  81cddd:	mov    %rax,0xe0(%rsp)
  81cde5:	movq   $0xa,0xe8(%rsp)
  81cdf1:	lea    0x50(%rsp),%rax
  81cdf6:	mov    %rax,0xd0(%rsp)
  81cdfe:	movq   $0x1,0xd8(%rsp)
  81ce0a:	movl   $0xffffffff,0xb8(%rsp)
  81ce15:	movl   $0x2,0x98(%rsp)
  81ce20:	movq   $0x0,0xf0(%rsp)
  81ce2c:	movl   $0x0,0xf8(%rsp)
  81ce37:	lea    0x100(%rsp),%rdi
  81ce3f:	lea    0x98(%rsp),%rdx
  81ce47:	mov    %r15,%rsi
  81ce4a:	call   *0x662d90(%rip)        # e7fbe0 <_DYNAMIC+0x640>
  81ce50:	lea    0x10(%rbx),%rsi
  81ce54:	lea    0x100(%rsp),%rdi
  81ce5c:	call   *0x662d86(%rip)        # e7fbe8 <_DYNAMIC+0x648>
  81ce62:	lea    0x100(%rsp),%rdi
  81ce6a:	mov    $0x4,%ecx
  81ce6f:	xor    %esi,%esi
  81ce71:	mov    %r14,%rdx
  81ce74:	xor    %r8d,%r8d
  81ce77:	call   *0x662d73(%rip)        # e7fbf0 <_DYNAMIC+0x650>
  81ce7d:	lea    0x100(%rsp),%rdi
  81ce85:	xor    %esi,%esi
  81ce87:	mov    $0x3,%edx
  81ce8c:	xor    %ecx,%ecx
  81ce8e:	mov    $0x1,%r8d
  81ce94:	call   *0x662d5e(%rip)        # e7fbf8 <_DYNAMIC+0x658>
  81ce9a:	lea    0x100(%rsp),%rdi
  81cea2:	call   81be30 <core::ptr::drop_glue::<wgpu::api::render_pass::RenderPass>>
  81cea7:	movups 0x30(%rsp),%xmm0
  81ceac:	movups 0x40(%rsp),%xmm1
  81ceb1:	movaps %xmm1,0x110(%rsp)
  81ceb9:	movaps %xmm0,0x100(%rsp)
  81cec1:	lea    0x98(%rsp),%r14
  81cec9:	lea    0x100(%rsp),%rsi
  81ced1:	mov    %r14,%rdi
  81ced4:	call   *0x662d26(%rip)        # e7fc00 <_DYNAMIC+0x660>
  81ceda:	add    $0x8,%rbx
  81cede:	mov    %rbx,%rdi
  81cee1:	mov    %r14,%rsi
  81cee4:	call   824710 <<wgpu::api::queue::Queue>::submit::<[wgpu::api::command_buffer::CommandBuffer; 1]>>
  81cee9:	add    $0x548,%rsp
  81cef0:	pop    %rbx
  81cef1:	pop    %r12
  81cef3:	pop    %r14
  81cef5:	pop    %r15
  81cef7:	ret
  81cef8:	mov    %rax,%rbx
  81cefb:	jmp    81cf0d <<gpui_gpu::renderer::GpuContext>::submit+0x1bd>
  81cefd:	mov    %rax,%rbx
  81cf00:	lea    0x100(%rsp),%rdi
  81cf08:	call   81be30 <core::ptr::drop_glue::<wgpu::api::render_pass::RenderPass>>
  81cf0d:	lea    0x30(%rsp),%rdi
  81cf12:	call   81bfa0 <core::ptr::drop_glue::<wgpu::api::command_encoder::CommandEncoder>>
  81cf17:	mov    %rbx,%rdi
  81cf1a:	call   e2c310 <_Unwind_Resume@plt>
  81cf1f:	call   *0x6628cb(%rip)        # e7f7f0 <_DYNAMIC+0x250>

/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081cf30 <<gpui_gpu::renderer::RendererState>::correction>:
  81cf30:	push   %r15
  81cf32:	push   %r14
  81cf34:	push   %r13
  81cf36:	push   %r12
  81cf38:	push   %rbx
  81cf39:	sub    $0x90,%rsp
  81cf40:	mov    %rdi,%rbx
  81cf43:	movss  (%rdx),%xmm1
  81cf47:	movss  0x8(%rdx),%xmm2
  81cf4c:	movaps %xmm1,%xmm0
  81cf4f:	addss  %xmm2,%xmm0
  81cf53:	movd   %xmm0,%eax
  81cf57:	and    $0x7fffffff,%eax
  81cf5c:	xorps  %xmm8,%xmm8
  81cf60:	xorps  %xmm9,%xmm9
  81cf64:	cmp    $0x7f7fffff,%eax
  81cf69:	jg     81cf88 <<gpui_gpu::renderer::RendererState>::correction+0x58>
  81cf6b:	cvtss2sd %xmm1,%xmm1
  81cf6f:	cvtss2sd %xmm2,%xmm2
  81cf73:	cvtss2sd %xmm0,%xmm0
  81cf77:	addsd  %xmm1,%xmm2
  81cf7b:	subsd  %xmm0,%xmm2
  81cf7f:	xorps  %xmm9,%xmm9
  81cf83:	cvtsd2ss %xmm2,%xmm9
  81cf88:	movupd (%rsi),%xmm0
  81cf8c:	movupd 0x8(%rsi),%xmm1
  81cf91:	movsd  0x10(%rsi),%xmm2
  81cf96:	movsd  0x18(%rsi),%xmm3
  81cf9b:	movupd 0x20(%rsi),%xmm4
  81cfa0:	movss  0x4(%rdx),%xmm6
  81cfa5:	movss  0xc(%rdx),%xmm7
  81cfaa:	movaps %xmm6,%xmm5
  81cfad:	addss  %xmm7,%xmm5
  81cfb1:	movd   %xmm5,%eax
  81cfb5:	and    $0x7fffffff,%eax
  81cfba:	cmp    $0x7f7fffff,%eax
  81cfbf:	jg     81cfde <<gpui_gpu::renderer::RendererState>::correction+0xae>
  81cfc1:	cvtss2sd %xmm6,%xmm6
  81cfc5:	cvtss2sd %xmm7,%xmm7
  81cfc9:	cvtss2sd %xmm5,%xmm5
  81cfcd:	addsd  %xmm6,%xmm7
  81cfd1:	subsd  %xmm5,%xmm7
  81cfd5:	xorps  %xmm8,%xmm8
  81cfd9:	cvtsd2ss %xmm7,%xmm8
  81cfde:	cvtpd2ps %xmm4,%xmm5
  81cfe2:	cvtps2pd %xmm5,%xmm5
  81cfe5:	subpd  %xmm5,%xmm4
  81cfe9:	cvtpd2ps %xmm4,%xmm4
  81cfed:	unpcklpd %xmm3,%xmm1
  81cff1:	cvtpd2ps %xmm1,%xmm3
  81cff5:	unpcklpd %xmm2,%xmm0
  81cff9:	cvtpd2ps %xmm0,%xmm2
  81cffd:	cvtps2pd %xmm3,%xmm3
  81d000:	subpd  %xmm3,%xmm1
  81d004:	cvtpd2ps %xmm1,%xmm5
  81d008:	cvtps2pd %xmm2,%xmm1
  81d00b:	subpd  %xmm1,%xmm0
  81d00f:	cvtpd2ps %xmm0,%xmm6
  81d013:	movapd %xmm6,%xmm0
  81d017:	unpcklps %xmm5,%xmm0
  81d01a:	movaps %xmm8,%xmm1
  81d01e:	movlhps %xmm9,%xmm1
  81d022:	movapd %xmm4,%xmm2
  81d026:	shufps $0x24,%xmm1,%xmm2
  81d02a:	xorps  %xmm1,%xmm1
  81d02d:	movapd %xmm0,%xmm3
  81d031:	cmpneqps %xmm1,%xmm3
  81d035:	cmpneqps %xmm1,%xmm2
  81d039:	packssdw %xmm2,%xmm3
  81d03d:	pmovmskb %xmm3,%eax
  81d041:	test   %eax,%eax
  81d043:	je     81d167 <<gpui_gpu::renderer::RendererState>::correction+0x237>
  81d049:	movapd %xmm6,0x60(%rsp)
  81d04f:	movapd %xmm5,0x70(%rsp)
  81d055:	lea    0x8(%rsp),%r12
  81d05a:	movapd %xmm0,(%rsp)
  81d05f:	movapd %xmm4,0x80(%rsp)
  81d068:	movlpd %xmm4,0x10(%rsp)
  81d06e:	movss  %xmm9,0x18(%rsp)
  81d075:	movss  %xmm8,0x1c(%rsp)
  81d07c:	lea    0x318(%rbx),%r14
  81d083:	mov    %rsp,%rsi
  81d086:	mov    %r14,%rdi
  81d089:	movaps %xmm8,0x30(%rsp)
  81d08f:	movaps %xmm9,0x20(%rsp)
  81d095:	call   8240b0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&[u32; 8]>>
  81d09a:	movapd 0x20(%rsp),%xmm6
  81d0a0:	movapd 0x30(%rsp),%xmm5
  81d0a6:	mov    %rax,%r15
  81d0a9:	shr    $0x39,%r15
  81d0ad:	mov    0x2f8(%rbx),%rcx
  81d0b4:	mov    0x300(%rbx),%rdx
  81d0bb:	movd   %r15d,%xmm0
  81d0c0:	punpcklbw %xmm0,%xmm0
  81d0c4:	pshuflw $0x0,%xmm0,%xmm0
  81d0c9:	pshufd $0x44,%xmm0,%xmm0
  81d0ce:	xor    %esi,%esi
  81d0d0:	pcmpeqd %xmm1,%xmm1
  81d0d4:	mov    %rax,%rdi
  81d0d7:	and    %rdx,%rdi
  81d0da:	movdqu (%rcx,%rdi,1),%xmm2
  81d0df:	movdqa %xmm2,%xmm3
  81d0e3:	pcmpeqb %xmm0,%xmm3
  81d0e7:	pmovmskb %xmm3,%r8d
  81d0ec:	test   %r8d,%r8d
  81d0ef:	je     81d140 <<gpui_gpu::renderer::RendererState>::correction+0x210>
  81d0f1:	tzcnt  %r8d,%r9d
  81d0f6:	add    %rdi,%r9
  81d0f9:	and    %rdx,%r9
  81d0fc:	neg    %r9
  81d0ff:	lea    (%r9,%r9,8),%r9
  81d103:	movdqu -0x24(%rcx,%r9,4),%xmm3
  81d10a:	movdqu -0x14(%rcx,%r9,4),%xmm4
  81d111:	pcmpeqb 0x10(%rsp),%xmm4
  81d117:	pcmpeqb (%rsp),%xmm3
  81d11c:	pand   %xmm4,%xmm3
  81d120:	pmovmskb %xmm3,%r10d
  81d125:	cmp    $0xffff,%r10d
  81d12c:	je     81d15e <<gpui_gpu::renderer::RendererState>::correction+0x22e>
  81d12e:	lea    -0x1(%r8),%r9d
  81d132:	and    %r8w,%r9w
  81d136:	mov    %r9d,%r8d
  81d139:	jne    81d0f1 <<gpui_gpu::renderer::RendererState>::correction+0x1c1>
  81d13b:	nopl   0x0(%rax,%rax,1)
  81d140:	pcmpeqb %xmm1,%xmm2
  81d144:	pmovmskb %xmm2,%r8d
  81d149:	test   %r8d,%r8d
  81d14c:	jne    81d16e <<gpui_gpu::renderer::RendererState>::correction+0x23e>
  81d14e:	add    %rsi,%rdi
  81d151:	add    $0x10,%rdi
  81d155:	add    $0x10,%rsi
  81d159:	jmp    81d0d7 <<gpui_gpu::renderer::RendererState>::correction+0x1a7>
  81d15e:	lea    (%rcx,%r9,4),%rdx
  81d162:	jmp    81d289 <<gpui_gpu::renderer::RendererState>::correction+0x359>
  81d167:	xor    %eax,%eax
  81d169:	jmp    81d28c <<gpui_gpu::renderer::RendererState>::correction+0x35c>
  81d16e:	cmpq   $0x0,0x308(%rbx)
  81d176:	je     81d2bf <<gpui_gpu::renderer::RendererState>::correction+0x38f>
  81d17c:	mov    (%rsp),%r14
  81d180:	mov    0x10(%r12),%rcx
  81d185:	mov    %rcx,0x50(%rsp)
  81d18a:	movups (%r12),%xmm0
  81d18f:	movaps %xmm0,0x40(%rsp)
  81d194:	mov    0x70(%rbx),%r12
  81d198:	cmp    0x60(%rbx),%r12
  81d19c:	jne    81d1ba <<gpui_gpu::renderer::RendererState>::correction+0x28a>
  81d19e:	lea    0x60(%rbx),%rdi
  81d1a2:	mov    %rax,%r13
  81d1a5:	call   *0x6629a5(%rip)        # e7fb50 <_DYNAMIC+0x5b0>
  81d1ab:	movapd 0x20(%rsp),%xmm6
  81d1b1:	movapd 0x30(%rsp),%xmm5
  81d1b7:	mov    %r13,%rax
  81d1ba:	mov    0x68(%rbx),%rcx
  81d1be:	mov    %r12,%rdx
  81d1c1:	shl    $0x5,%rdx
  81d1c5:	movaps 0x60(%rsp),%xmm0
  81d1ca:	movlps %xmm0,(%rcx,%rdx,1)
  81d1ce:	movaps 0x80(%rsp),%xmm0
  81d1d6:	movss  %xmm0,0x8(%rcx,%rdx,1)
  81d1dc:	movss  %xmm6,0xc(%rcx,%rdx,1)
  81d1e2:	movdqa 0x70(%rsp),%xmm1
  81d1e8:	movq   %xmm1,0x10(%rcx,%rdx,1)
  81d1ee:	shufps $0x55,%xmm0,%xmm0
  81d1f2:	movss  %xmm0,0x18(%rcx,%rdx,1)
  81d1f8:	movss  %xmm5,0x1c(%rcx,%rdx,1)
  81d1fe:	lea    0x1(%r12),%rcx
  81d203:	mov    %rcx,0x70(%rbx)
  81d207:	mov    0x2f8(%rbx),%rcx
  81d20e:	mov    0x300(%rbx),%rdx
  81d215:	and    %rdx,%rax
  81d218:	movdqu (%rcx,%rax,1),%xmm0
  81d21d:	pmovmskb %xmm0,%esi
  81d221:	test   %esi,%esi
  81d223:	je     81d29d <<gpui_gpu::renderer::RendererState>::correction+0x36d>
  81d225:	tzcnt  %esi,%esi
  81d229:	add    %rax,%rsi
  81d22c:	and    %rdx,%rsi
  81d22f:	movzbl (%rcx,%rsi,1),%eax
  81d233:	test   %al,%al
  81d235:	jns    81d2f0 <<gpui_gpu::renderer::RendererState>::correction+0x3c0>
  81d23b:	lea    -0x10(%rsi),%rdi
  81d23f:	and    %rdx,%rdi
  81d242:	mov    %r15b,(%rcx,%rsi,1)
  81d246:	mov    %r15b,0x10(%rcx,%rdi,1)
  81d24b:	neg    %rsi
  81d24e:	lea    (%rsi,%rsi,8),%rsi
  81d252:	lea    (%rcx,%rsi,4),%rdx
  81d256:	and    $0x1,%al
  81d258:	movzbl %al,%eax
  81d25b:	sub    %rax,0x308(%rbx)
  81d262:	mov    %r14,-0x24(%rcx,%rsi,4)
  81d267:	movdqa 0x40(%rsp),%xmm0
  81d26d:	movdqu %xmm0,-0x1c(%rcx,%rsi,4)
  81d273:	mov    0x50(%rsp),%rax
  81d278:	mov    %rax,-0xc(%rcx,%rsi,4)
  81d27d:	mov    %r12d,-0x4(%rcx,%rsi,4)
  81d282:	incq   0x310(%rbx)
  81d289:	mov    -0x4(%rdx),%eax
  81d28c:	add    $0x90,%rsp
  81d293:	pop    %rbx
  81d294:	pop    %r12
  81d296:	pop    %r13
  81d298:	pop    %r14
  81d29a:	pop    %r15
  81d29c:	ret
  81d29d:	mov    $0x10,%edi
  81d2a2:	add    %rdi,%rax
  81d2a5:	and    %rdx,%rax
  81d2a8:	movdqu (%rcx,%rax,1),%xmm0
  81d2ad:	pmovmskb %xmm0,%esi
  81d2b1:	add    $0x10,%rdi
  81d2b5:	test   %esi,%esi
  81d2b7:	jne    81d225 <<gpui_gpu::renderer::RendererState>::correction+0x2f5>
  81d2bd:	jmp    81d2a2 <<gpui_gpu::renderer::RendererState>::correction+0x372>
  81d2bf:	lea    0x2f8(%rbx),%rdi
  81d2c6:	mov    $0x1,%esi
  81d2cb:	mov    %r14,%rdx
  81d2ce:	mov    $0x1,%ecx
  81d2d3:	mov    %rax,%r14
  81d2d6:	call   *0x66292c(%rip)        # e7fc08 <_DYNAMIC+0x668>
  81d2dc:	movapd 0x20(%rsp),%xmm6
  81d2e2:	movapd 0x30(%rsp),%xmm5
  81d2e8:	mov    %r14,%rax
  81d2eb:	jmp    81d17c <<gpui_gpu::renderer::RendererState>::correction+0x24c>
  81d2f0:	movdqa (%rcx),%xmm0
  81d2f4:	pmovmskb %xmm0,%eax
  81d2f8:	tzcnt  %eax,%esi
  81d2fc:	movzbl (%rcx,%rsi,1),%eax
  81d300:	jmp    81d23b <<gpui_gpu::renderer::RendererState>::correction+0x30b>

/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081d310 <<gpui_gpu::renderer::RendererState>::prepare_atlas>:
  81d310:	push   %rbp
  81d311:	push   %r15
  81d313:	push   %r14
  81d315:	push   %r13
  81d317:	push   %r12
  81d319:	push   %rbx
  81d31a:	sub    $0x228,%rsp
  81d321:	mov    %rsi,%r14
  81d324:	test   %r8d,%r8d
  81d327:	je     81d3bb <<gpui_gpu::renderer::RendererState>::prepare_atlas+0xab>
  81d32d:	mov    %rdi,0x10(%rsp)
  81d332:	mov    0x110(%rcx),%rbp
  81d339:	test   %rbp,%rbp
  81d33c:	je     81d41f <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x10f>
  81d342:	mov    0x108(%rcx),%r13
  81d349:	shl    $0x3,%rbp
  81d34d:	mov    %r14,0x8(%rsp)
  81d352:	lea    0x78(%r14),%rdi
  81d356:	mov    %rdx,0x18(%rsp)
  81d35b:	lea    0x8(%rdx),%rax
  81d35f:	mov    %rax,0x20(%rsp)
  81d364:	xor    %ebx,%ebx
  81d366:	lea    0x28(%rsp),%r15
  81d36b:	xor    %r12d,%r12d
  81d36e:	xchg   %ax,%ax
  81d370:	mov    0x0(%r13,%r12,1),%rax
  81d375:	movups 0x28(%rax),%xmm0
  81d379:	lea    0x38(%rsp),%rcx
  81d37e:	movups %xmm0,(%rcx)
  81d381:	movups 0x18(%rax),%xmm0
  81d385:	movups %xmm0,0x28(%rsp)
  81d38a:	movups 0x38(%rax),%xmm0
  81d38e:	movups %xmm0,0x48(%rsp)
  81d393:	mov    %rdi,%r14
  81d396:	mov    0x20(%rsp),%rsi
  81d39b:	mov    %r15,%rdx
  81d39e:	call   81caf0 <<gpui_gpu::renderer::Atlas>::insert>
  81d3a3:	test   $0x1,%al
  81d3a5:	je     81d426 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x116>
  81d3a7:	add    %rdx,%rbx
  81d3aa:	add    $0x8,%r12
  81d3ae:	cmp    %r12,%rbp
  81d3b1:	mov    %r14,%rdi
  81d3b4:	jne    81d370 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x60>
  81d3b6:	jmp    81d52e <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x21e>
  81d3bb:	cmpl   $0x1,0x150(%r14)
  81d3c3:	jne    81d3d5 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0xc5>
  81d3c5:	mov    0x138(%r14),%rax
  81d3cc:	add    0x130(%r14),%rax
  81d3d3:	je     81d40c <<gpui_gpu::renderer::RendererState>::prepare_atlas+0xfc>
  81d3d5:	mov    %rdi,%rbx
  81d3d8:	add    $0x78,%r14
  81d3dc:	lea    0x58(%rsp),%rdi
  81d3e1:	mov    %rdx,%rsi
  81d3e4:	mov    $0x1,%edx
  81d3e9:	call   81c820 <<gpui_gpu::renderer::Atlas>::new>
  81d3ee:	mov    %r14,%rdi
  81d3f1:	call   81b5e0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81d3f6:	lea    0x58(%rsp),%rsi
  81d3fb:	mov    $0xe8,%edx
  81d400:	mov    %r14,%rdi
  81d403:	call   *0x662437(%rip)        # e7f840 <memcpy@GLIBC_2.14>
  81d409:	mov    %rbx,%rdi
  81d40c:	movq   $0x0,0x8(%rdi)
  81d414:	movl   $0xffffffff,(%rdi)
  81d41a:	jmp    81d53d <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x22d>
  81d41f:	xor    %ebx,%ebx
  81d421:	jmp    81d52e <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x21e>
  81d426:	mov    0x8(%rsp),%rax
  81d42b:	mov    0x150(%rax),%eax
  81d431:	cmp    $0x81,%eax
  81d436:	mov    $0x80,%edx
  81d43b:	cmovae %eax,%edx
  81d43e:	add    %edx,%edx
  81d440:	cmp    $0x800,%edx
  81d446:	mov    $0x800,%eax
  81d44b:	cmovae %eax,%edx
  81d44e:	lea    0x140(%rsp),%r12
  81d456:	mov    %r12,%rdi
  81d459:	mov    0x18(%rsp),%rsi
  81d45e:	mov    %edx,0x8(%rsp)
  81d462:	call   81c820 <<gpui_gpu::renderer::Atlas>::new>
  81d467:	xor    %r15d,%r15d
  81d46a:	nopw   0x0(%rax,%rax,1)
  81d470:	mov    0x0(%r13,%r15,1),%rax
  81d475:	movups 0x28(%rax),%xmm0
  81d479:	lea    0x68(%rsp),%rcx
  81d47e:	movups %xmm0,(%rcx)
  81d481:	movups 0x18(%rax),%xmm0
  81d485:	movups %xmm0,0x58(%rsp)
  81d48a:	movups 0x38(%rax),%xmm0
  81d48e:	movups %xmm0,0x78(%rsp)
  81d493:	mov    %r12,%rdi
  81d496:	mov    0x20(%rsp),%rsi
  81d49b:	lea    0x58(%rsp),%rdx
  81d4a0:	call   81caf0 <<gpui_gpu::renderer::Atlas>::insert>
  81d4a5:	cmp    $0x1,%rax
  81d4a9:	jne    81d4b9 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x1a9>
  81d4ab:	add    %rdx,%rbx
  81d4ae:	add    $0x8,%r15
  81d4b2:	cmp    %r15,%rbp
  81d4b5:	jne    81d470 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x160>
  81d4b7:	jmp    81d4fb <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x1eb>
  81d4b9:	mov    0x8(%rsp),%r15d
  81d4be:	cmp    $0x800,%r15d
  81d4c5:	je     81d54f <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x23f>
  81d4cb:	mov    %r12,%rdi
  81d4ce:	call   81b5e0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81d4d3:	add    %r15d,%r15d
  81d4d6:	cmp    $0x800,%r15d
  81d4dd:	mov    $0x800,%eax
  81d4e2:	cmovae %eax,%r15d
  81d4e6:	mov    %r12,%rdi
  81d4e9:	mov    0x18(%rsp),%rsi
  81d4ee:	mov    %r15d,0x8(%rsp)
  81d4f3:	mov    %r15d,%edx
  81d4f6:	jmp    81d462 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x152>
  81d4fb:	lea    0x58(%rsp),%rdi
  81d500:	lea    0x140(%rsp),%rsi
  81d508:	mov    $0xe8,%edx
  81d50d:	call   *0x66232d(%rip)        # e7f840 <memcpy@GLIBC_2.14>
  81d513:	mov    %r14,%rdi
  81d516:	call   81b5e0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81d51b:	lea    0x58(%rsp),%rsi
  81d520:	mov    $0xe8,%edx
  81d525:	mov    %r14,%rdi
  81d528:	call   *0x662312(%rip)        # e7f840 <memcpy@GLIBC_2.14>
  81d52e:	mov    0x10(%rsp),%rax
  81d533:	mov    %rbx,0x8(%rax)
  81d537:	movl   $0xffffffff,(%rax)
  81d53d:	add    $0x228,%rsp
  81d544:	pop    %rbx
  81d545:	pop    %r12
  81d547:	pop    %r13
  81d549:	pop    %r14
  81d54b:	pop    %r15
  81d54d:	pop    %rbp
  81d54e:	ret
  81d54f:	mov    0x10(%rsp),%rax
  81d554:	movl   $0x7,(%rax)
  81d55a:	lea    0x140(%rsp),%rdi
  81d562:	call   81b5e0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81d567:	jmp    81d53d <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x22d>
  81d569:	jmp    81d56b <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x25b>
  81d56b:	mov    %rax,%rbx
  81d56e:	lea    0x58(%rsp),%rsi
  81d573:	mov    $0xe8,%edx
  81d578:	mov    %r14,%rdi
  81d57b:	call   *0x6622bf(%rip)        # e7f840 <memcpy@GLIBC_2.14>
  81d581:	mov    %rbx,%rdi
  81d584:	call   e2c310 <_Unwind_Resume@plt>
  81d589:	mov    %rax,%rbx
  81d58c:	lea    0x140(%rsp),%rdi
  81d594:	call   81b5e0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81d599:	mov    %rbx,%rdi
  81d59c:	call   e2c310 <_Unwind_Resume@plt>
  81d5a1:	call   *0x662249(%rip)        # e7f7f0 <_DYNAMIC+0x250>

/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081d5b0 <<gpui_gpu::renderer::RendererState>::new>:
  81d5b0:	push   %r15
  81d5b2:	push   %r14
  81d5b4:	push   %r13
  81d5b6:	push   %r12
  81d5b8:	push   %rbx
  81d5b9:	sub    $0x390,%rsp
  81d5c0:	mov    %rsi,%r14
  81d5c3:	mov    %rdi,%rbx
  81d5c6:	lea    -0x748dc3(%rip),%rax        # d480a <anon.36d49f465d299f05a84fba3771e6457e.31.llvm.1466513483089798867+0xa>
  81d5cd:	mov    %rax,0xd8(%rsp)
  81d5d5:	movq   $0x7,0xe0(%rsp)
  81d5e1:	movq   $0x30,0xe8(%rsp)
  81d5ed:	movl   $0x48,0xf0(%rsp)
  81d5f8:	movb   $0x0,0xf4(%rsp)
  81d600:	mov    0x6625b9(%rip),%r15        # e7fbc0 <_DYNAMIC+0x620>
  81d607:	lea    0x10(%rsp),%rdi
  81d60c:	lea    0xd8(%rsp),%rdx
  81d614:	call   *%r15
  81d617:	movq   $0x30,0x30(%rsp)
  81d620:	lea    -0x748e16(%rip),%rax        # d4811 <anon.36d49f465d299f05a84fba3771e6457e.31.llvm.1466513483089798867+0x11>
  81d627:	mov    %rax,0xd8(%rsp)
  81d62f:	movq   $0x5,0xe0(%rsp)
  81d63b:	movq   $0x10,0xe8(%rsp)
  81d647:	movl   $0x88,0xf0(%rsp)
  81d652:	movb   $0x0,0xf4(%rsp)
  81d65a:	lea    0x38(%rsp),%rdi
  81d65f:	lea    0xd8(%rsp),%rdx
  81d667:	mov    %r14,%rsi
  81d66a:	call   *%r15
  81d66d:	movq   $0x10,0x58(%rsp)
  81d676:	lea    -0x748e67(%rip),%rax        # d4816 <anon.36d49f465d299f05a84fba3771e6457e.31.llvm.1466513483089798867+0x16>
  81d67d:	mov    %rax,0xd8(%rsp)
  81d685:	movq   $0x5,0xe0(%rsp)
  81d691:	movq   $0x8,0xe8(%rsp)
  81d69d:	movl   $0x88,0xf0(%rsp)
  81d6a8:	movb   $0x0,0xf4(%rsp)
  81d6b0:	lea    0x60(%rsp),%rdi
  81d6b5:	lea    0xd8(%rsp),%rdx
  81d6bd:	mov    %r14,%rsi
  81d6c0:	call   *0x6624fa(%rip)        # e7fbc0 <_DYNAMIC+0x620>
  81d6c6:	movq   $0x8,0x80(%rsp)
  81d6d2:	lea    -0x748ebe(%rip),%rax        # d481b <anon.36d49f465d299f05a84fba3771e6457e.31.llvm.1466513483089798867+0x1b>
  81d6d9:	mov    %rax,0xd8(%rsp)
  81d6e1:	movq   $0x7,0xe0(%rsp)
  81d6ed:	movq   $0x4,0xe8(%rsp)
  81d6f9:	movl   $0x88,0xf0(%rsp)
  81d704:	movb   $0x0,0xf4(%rsp)
  81d70c:	lea    0x88(%rsp),%rdi
  81d714:	lea    0xd8(%rsp),%rdx
  81d71c:	mov    %r14,%rsi
  81d71f:	call   *0x66249b(%rip)        # e7fbc0 <_DYNAMIC+0x620>
  81d725:	movq   $0x4,0xa8(%rsp)
  81d731:	lea    -0x748f16(%rip),%rax        # d4822 <anon.36d49f465d299f05a84fba3771e6457e.31.llvm.1466513483089798867+0x22>
  81d738:	mov    %rax,0xd8(%rsp)
  81d740:	movq   $0x11,0xe0(%rsp)
  81d74c:	movq   $0x20,0xe8(%rsp)
  81d758:	movl   $0x88,0xf0(%rsp)
  81d763:	movb   $0x0,0xf4(%rsp)
  81d76b:	lea    0xb0(%rsp),%rdi
  81d773:	lea    0xd8(%rsp),%rdx
  81d77b:	mov    %r14,%rsi
  81d77e:	call   *0x66243c(%rip)        # e7fbc0 <_DYNAMIC+0x620>
  81d784:	movq   $0x20,0xd0(%rsp)
  81d790:	lea    0x2a8(%rsp),%rdi
  81d798:	mov    %r14,%rsi
  81d79b:	mov    $0x1,%edx
  81d7a0:	call   81c820 <<gpui_gpu::renderer::Atlas>::new>
  81d7a5:	mov    0x18(%r14),%r13
  81d7a9:	lock incq 0x0(%r13)
  81d7ae:	jle    81dae3 <<gpui_gpu::renderer::RendererState>::new+0x533>
  81d7b4:	mov    %r13,0x8(%rsp)
  81d7b9:	mov    0x30(%rsp),%rax
  81d7be:	mov    %rax,0x1e0(%rsp)
  81d7c6:	movups 0x10(%rsp),%xmm0
  81d7cb:	movups 0x20(%rsp),%xmm1
  81d7d0:	movaps %xmm1,0x1d0(%rsp)
  81d7d8:	movaps %xmm0,0x1c0(%rsp)
  81d7e0:	mov    0x58(%rsp),%rax
  81d7e5:	mov    %rax,0x210(%rsp)
  81d7ed:	movups 0x38(%rsp),%xmm0
  81d7f2:	movups 0x48(%rsp),%xmm1
  81d7f7:	movaps %xmm1,0x200(%rsp)
  81d7ff:	movaps %xmm0,0x1f0(%rsp)
  81d807:	mov    0x80(%rsp),%rax
  81d80f:	mov    %rax,0x240(%rsp)
  81d817:	movups 0x60(%rsp),%xmm0
  81d81c:	movups 0x70(%rsp),%xmm1
  81d821:	movaps %xmm1,0x230(%rsp)
  81d829:	movaps %xmm0,0x220(%rsp)
  81d831:	mov    0xa8(%rsp),%rax
  81d839:	mov    %rax,0x270(%rsp)
  81d841:	movups 0x88(%rsp),%xmm0
  81d849:	movups 0x98(%rsp),%xmm1
  81d851:	movaps %xmm1,0x260(%rsp)
  81d859:	movaps %xmm0,0x250(%rsp)
  81d861:	mov    0xd0(%rsp),%rax
  81d869:	mov    %rax,0x2a0(%rsp)
  81d871:	movups 0xb0(%rsp),%xmm0
  81d879:	movups 0xc0(%rsp),%xmm1
  81d881:	movaps %xmm1,0x290(%rsp)
  81d889:	movaps %xmm0,0x280(%rsp)
  81d891:	lea    0xd8(%rsp),%rdi
  81d899:	lea    0x2a8(%rsp),%rsi
  81d8a1:	mov    $0xe8,%edx
  81d8a6:	call   *0x661f94(%rip)        # e7f840 <memcpy@GLIBC_2.14>
  81d8ac:	mov    %fs:0x0,%rax
  81d8b5:	lea    -0x28(%rax),%rax
  81d8bc:	mov    %rax,%r12
  81d8bf:	cmpb   $0x1,0x10(%rax)
  81d8c3:	jne    81dac3 <<gpui_gpu::renderer::RendererState>::new+0x513>
  81d8c9:	mov    (%r12),%r14
  81d8cd:	mov    0x8(%r12),%r15
  81d8d2:	lea    0x1(%r14),%rax
  81d8d6:	mov    %rax,(%r12)
  81d8da:	mov    %r13,0x228(%rbx)
  81d8e1:	mov    0x30(%rsp),%rax
  81d8e6:	mov    %rax,0x250(%rbx)
  81d8ed:	movups 0x10(%rsp),%xmm0
  81d8f2:	movups 0x20(%rsp),%xmm1
  81d8f7:	movups %xmm1,0x240(%rbx)
  81d8fe:	movups %xmm0,0x230(%rbx)
  81d905:	mov    0x58(%rsp),%rax
  81d90a:	mov    %rax,0x278(%rbx)
  81d911:	movups 0x38(%rsp),%xmm0
  81d916:	movups 0x48(%rsp),%xmm1
  81d91b:	movups %xmm1,0x268(%rbx)
  81d922:	movups %xmm0,0x258(%rbx)
  81d929:	mov    0x80(%rsp),%rax
  81d931:	mov    %rax,0x2a0(%rbx)
  81d938:	movups 0x60(%rsp),%xmm0
  81d93d:	movups 0x70(%rsp),%xmm1
  81d942:	movups %xmm1,0x290(%rbx)
  81d949:	movups %xmm0,0x280(%rbx)
  81d950:	movups 0x88(%rsp),%xmm0
  81d958:	movups 0x98(%rsp),%xmm1
  81d960:	movups %xmm0,0x2a8(%rbx)
  81d967:	movups %xmm1,0x2b8(%rbx)
  81d96e:	mov    0xa8(%rsp),%rax
  81d976:	mov    %rax,0x2c8(%rbx)
  81d97d:	movups 0xb0(%rsp),%xmm0
  81d985:	movups 0xc0(%rsp),%xmm1
  81d98d:	movups %xmm0,0x2d0(%rbx)
  81d994:	movups %xmm1,0x2e0(%rbx)
  81d99b:	mov    0xd0(%rsp),%rax
  81d9a3:	mov    %rax,0x2f0(%rbx)
  81d9aa:	lea    0x78(%rbx),%rdi
  81d9ae:	lea    0x2a8(%rsp),%rsi
  81d9b6:	mov    $0xe8,%edx
  81d9bb:	call   *0x661e7f(%rip)        # e7f840 <memcpy@GLIBC_2.14>
  81d9c1:	movq   $0x0,0x328(%rbx)
  81d9cc:	movq   $0x0,(%rbx)
  81d9d3:	movq   $0x4,0x8(%rbx)
  81d9db:	xorps  %xmm0,%xmm0
  81d9de:	movups %xmm0,0x10(%rbx)
  81d9e2:	movq   $0x4,0x20(%rbx)
  81d9ea:	movups %xmm0,0x28(%rbx)
  81d9ee:	movq   $0x4,0x38(%rbx)
  81d9f6:	movups %xmm0,0x40(%rbx)
  81d9fa:	movq   $0x4,0x50(%rbx)
  81da02:	movups %xmm0,0x58(%rbx)
  81da06:	movq   $0x4,0x68(%rbx)
  81da0e:	movq   $0x0,0x70(%rbx)
  81da16:	movups 0x6107eb(%rip),%xmm1        # e2e208 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.1466513483089798867+0x1e0>
  81da1d:	movups %xmm1,0x2f8(%rbx)
  81da24:	movups 0x6107ed(%rip),%xmm1        # e2e218 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.1466513483089798867+0x1f0>
  81da2b:	movups %xmm1,0x308(%rbx)
  81da32:	mov    %r14,0x318(%rbx)
  81da39:	mov    %r15,0x320(%rbx)
  81da40:	movw   $0x101,0x340(%rbx)
  81da49:	movq   $0x0,0x330(%rbx)
  81da54:	movups %xmm0,0x210(%rbx)
  81da5b:	movups %xmm0,0x200(%rbx)
  81da62:	movups %xmm0,0x1f0(%rbx)
  81da69:	movups %xmm0,0x1e0(%rbx)
  81da70:	movups %xmm0,0x1d0(%rbx)
  81da77:	movups %xmm0,0x1c0(%rbx)
  81da7e:	movups %xmm0,0x1b0(%rbx)
  81da85:	movups %xmm0,0x1a0(%rbx)
  81da8c:	movups %xmm0,0x190(%rbx)
  81da93:	movups %xmm0,0x180(%rbx)
  81da9a:	movups %xmm0,0x170(%rbx)
  81daa1:	movups %xmm0,0x160(%rbx)
  81daa8:	movb   $0x0,0x220(%rbx)
  81daaf:	mov    %rbx,%rax
  81dab2:	add    $0x390,%rsp
  81dab9:	pop    %rbx
  81daba:	pop    %r12
  81dabc:	pop    %r13
  81dabe:	pop    %r14
  81dac0:	pop    %r15
  81dac2:	ret
  81dac3:	call   *0x6620ff(%rip)        # e7fbc8 <_DYNAMIC+0x628>
  81dac9:	mov    %rax,%r14
  81dacc:	mov    %rdx,%r15
  81dacf:	mov    %rax,(%r12)
  81dad3:	mov    %rdx,0x8(%r12)
  81dad8:	movb   $0x1,0x10(%r12)
  81dade:	jmp    81d8d2 <<gpui_gpu::renderer::RendererState>::new+0x322>
  81dae3:	ud2
  81dae5:	mov    %rax,%rbx
  81dae8:	lea    0xd8(%rsp),%rdi
  81daf0:	call   81b5e0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81daf5:	lea    0x280(%rsp),%rdi
  81dafd:	call   81b6c0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81db02:	lea    0x250(%rsp),%rdi
  81db0a:	call   81b6c0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81db0f:	lea    0x220(%rsp),%rdi
  81db17:	call   81b6c0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81db1c:	lea    0x1f0(%rsp),%rdi
  81db24:	call   81b6c0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81db29:	lea    0x1c0(%rsp),%rdi
  81db31:	call   81b6c0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81db36:	lock decq 0x0(%r13)
  81db3b:	jne    81db99 <<gpui_gpu::renderer::RendererState>::new+0x5e9>
  81db3d:	lea    0x8(%rsp),%rdi
  81db42:	call   *0x661ec0(%rip)        # e7fa08 <_DYNAMIC+0x468>
  81db48:	jmp    81db99 <<gpui_gpu::renderer::RendererState>::new+0x5e9>
  81db4a:	mov    %rax,%rbx
  81db4d:	lea    0xb0(%rsp),%rdi
  81db55:	call   81b6c0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81db5a:	jmp    81db5f <<gpui_gpu::renderer::RendererState>::new+0x5af>
  81db5c:	mov    %rax,%rbx
  81db5f:	lea    0x88(%rsp),%rdi
  81db67:	call   81b6c0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81db6c:	jmp    81db71 <<gpui_gpu::renderer::RendererState>::new+0x5c1>
  81db6e:	mov    %rax,%rbx
  81db71:	lea    0x60(%rsp),%rdi
  81db76:	call   81b6c0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81db7b:	jmp    81db80 <<gpui_gpu::renderer::RendererState>::new+0x5d0>
  81db7d:	mov    %rax,%rbx
  81db80:	lea    0x38(%rsp),%rdi
  81db85:	call   81b6c0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81db8a:	jmp    81db8f <<gpui_gpu::renderer::RendererState>::new+0x5df>
  81db8c:	mov    %rax,%rbx
  81db8f:	lea    0x10(%rsp),%rdi
  81db94:	call   81b6c0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81db99:	mov    %rbx,%rdi
  81db9c:	call   e2c310 <_Unwind_Resume@plt>
  81dba1:	call   *0x661c49(%rip)        # e7f7f0 <_DYNAMIC+0x250>

/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081dbb0 <<gpui_gpu::renderer::RendererState>::render>:
  81dbb0:	push   %rbp
  81dbb1:	push   %r15
  81dbb3:	push   %r14
  81dbb5:	push   %r13
  81dbb7:	push   %r12
  81dbb9:	push   %rbx
  81dbba:	sub    $0x578,%rsp
  81dbc1:	mov    0x228(%rsi),%rax
  81dbc8:	mov    0x18(%rdx),%rbx
  81dbcc:	cmp    %rbx,%rax
  81dbcf:	je     81dbed <<gpui_gpu::renderer::RendererState>::render+0x3d>
  81dbd1:	mov    0x10(%rax),%r9
  81dbd5:	cmp    0x10(%rbx),%r9
  81dbd9:	jne    81dd59 <<gpui_gpu::renderer::RendererState>::render+0x1a9>
  81dbdf:	mov    0x18(%rax),%rax
  81dbe3:	cmp    0x18(%rbx),%rax
  81dbe7:	jne    81dd59 <<gpui_gpu::renderer::RendererState>::render+0x1a9>
  81dbed:	movupd 0x330(%rsi),%xmm0
  81dbf5:	movapd %xmm0,0x180(%rsp)
  81dbfe:	movq   $0x0,0x330(%rsi)
  81dc09:	mov    0x180(%rsp),%r15
  81dc11:	test   %r15,%r15
  81dc14:	je     81dc55 <<gpui_gpu::renderer::RendererState>::render+0xa5>
  81dc16:	lock decq (%r15)
  81dc1a:	jne    81dc55 <<gpui_gpu::renderer::RendererState>::render+0xa5>
  81dc1c:	lea    0x180(%rsp),%rax
  81dc24:	mov    %rdi,0x28(%rsp)
  81dc29:	mov    %rax,%rdi
  81dc2c:	mov    %rsi,%r12
  81dc2f:	mov    %r8,%r13
  81dc32:	mov    %r15,%r14
  81dc35:	mov    %rdx,%r15
  81dc38:	mov    %rcx,%rbp
  81dc3b:	call   *0x661e77(%rip)        # e7fab8 <_DYNAMIC+0x518>
  81dc41:	mov    %rbp,%rcx
  81dc44:	mov    %r15,%rdx
  81dc47:	mov    %r14,%r15
  81dc4a:	mov    %r13,%r8
  81dc4d:	mov    %r12,%rsi
  81dc50:	mov    0x28(%rsp),%rdi
  81dc55:	mov    0x228(%rsi),%rax
  81dc5c:	cmp    %rbx,%rax
  81dc5f:	je     81dc7d <<gpui_gpu::renderer::RendererState>::render+0xcd>
  81dc61:	mov    0x10(%rax),%r9
  81dc65:	cmp    0x10(%rbx),%r9
  81dc69:	jne    81dd59 <<gpui_gpu::renderer::RendererState>::render+0x1a9>
  81dc6f:	mov    0x18(%rax),%rax
  81dc73:	cmp    0x18(%rbx),%rax
  81dc77:	jne    81dd59 <<gpui_gpu::renderer::RendererState>::render+0x1a9>
  81dc7d:	lea    0x330(%rsi),%rax
  81dc84:	mov    %rax,0xf0(%rsp)
  81dc8c:	mov    (%rax),%rax
  81dc8f:	test   %rax,%rax
  81dc92:	je     81dccb <<gpui_gpu::renderer::RendererState>::render+0x11b>
  81dc94:	lock decq (%rax)
  81dc98:	jne    81dccb <<gpui_gpu::renderer::RendererState>::render+0x11b>
  81dc9a:	mov    %rdi,%r14
  81dc9d:	lea    0x330(%rsi),%rdi
  81dca4:	mov    %rsi,%r12
  81dca7:	mov    %r8,%r13
  81dcaa:	mov    %r15,%rbx
  81dcad:	mov    %rdx,%r15
  81dcb0:	mov    %rcx,%rbp
  81dcb3:	call   *0x661dff(%rip)        # e7fab8 <_DYNAMIC+0x518>
  81dcb9:	mov    %rbp,%rcx
  81dcbc:	mov    %r15,%rdx
  81dcbf:	mov    %rbx,%r15
  81dcc2:	mov    %r13,%r8
  81dcc5:	mov    %r12,%rsi
  81dcc8:	mov    %r14,%rdi
  81dccb:	movq   $0x0,0x330(%rsi)
  81dcd6:	mov    (%rcx),%r13d
  81dcd9:	mov    0x8(%rcx),%r9d
  81dcdd:	movzbl 0xd(%rcx),%eax
  81dce1:	test   %r9d,%r9d
  81dce4:	sets   %r10b
  81dce8:	and    $0x7fffffff,%r9d
  81dcef:	lea    -0x800000(%r9),%r11d
  81dcf6:	cmp    $0x7f000000,%r11d
  81dcfd:	setb   %r11b
  81dd01:	and    %r10b,%r11b
  81dd04:	lea    -0x1(%r9),%ebp
  81dd08:	cmp    $0x7fffff,%ebp
  81dd0e:	setb   %bpl
  81dd12:	and    %r10b,%bpl
  81dd15:	test   %r9d,%r9d
  81dd18:	sete   %r10b
  81dd1c:	cmp    $0x7f800000,%r9d
  81dd23:	sete   %r14b
  81dd27:	or     %r10b,%r14b
  81dd2a:	cmp    $0x7f800001,%r9d
  81dd31:	setge  %r9b
  81dd35:	or     %r14b,%r9b
  81dd38:	or     %bpl,%r9b
  81dd3b:	test   %r13d,%r13d
  81dd3e:	setne  %r10b
  81dd42:	and    %al,%r10b
  81dd45:	or     %r11b,%r10b
  81dd48:	or     %r9b,%r10b
  81dd4b:	test   $0x1,%r10b
  81dd4f:	je     81dd74 <<gpui_gpu::renderer::RendererState>::render+0x1c4>
  81dd51:	movl   $0x3,(%rdi)
  81dd57:	jmp    81dd5f <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81dd59:	movl   $0x4,(%rdi)
  81dd5f:	mov    %rdi,%rax
  81dd62:	add    $0x578,%rsp
  81dd69:	pop    %rbx
  81dd6a:	pop    %r12
  81dd6c:	pop    %r13
  81dd6e:	pop    %r14
  81dd70:	pop    %r15
  81dd72:	pop    %rbp
  81dd73:	ret
  81dd74:	movd   0x4(%rcx),%xmm2
  81dd79:	movzbl 0xc(%rcx),%r12d
  81dd7e:	test   $0x1,%r13b
  81dd82:	je     81ddf9 <<gpui_gpu::renderer::RendererState>::render+0x249>
  81dd84:	movd   %xmm2,%r9d
  81dd89:	test   %r9d,%r9d
  81dd8c:	sets   %r10b
  81dd90:	and    $0x7fffffff,%r9d
  81dd97:	lea    -0x800000(%r9),%r11d
  81dd9e:	cmp    $0x7f000000,%r11d
  81dda5:	setb   %r11b
  81dda9:	and    %r10b,%r11b
  81ddac:	lea    -0x1(%r9),%ebp
  81ddb0:	cmp    $0x7fffff,%ebp
  81ddb6:	setb   %bpl
  81ddba:	and    %r10b,%bpl
  81ddbd:	test   %r9d,%r9d
  81ddc0:	sete   %r10b
  81ddc4:	cmp    $0x7f800000,%r9d
  81ddcb:	sete   %r14b
  81ddcf:	or     %r10b,%r14b
  81ddd2:	cmp    $0x7f800001,%r9d
  81ddd9:	setge  %r9b
  81dddd:	or     %r14b,%r9b
  81dde0:	or     %bpl,%r9b
  81dde3:	or     %r11b,%r9b
  81dde6:	jne    81dd51 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81ddec:	ucomiss -0x76eec7(%rip),%xmm2        # aef2c <anon.630a3fff68f6bca64b568be97512ab45.57.llvm.826976926275214120+0x1c>
  81ddf3:	ja     81dd51 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81ddf9:	mov    0x28(%rcx),%r14d
  81ddfd:	cmp    %r14d,0x20(%r8)
  81de01:	jne    81dd51 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81de07:	mov    %r15,%rbp
  81de0a:	mov    0x2c(%rcx),%r15d
  81de0e:	cmp    %r15d,0x24(%r8)
  81de12:	jne    81dd51 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81de18:	mov    0x38(%r8),%r10d
  81de1c:	cmp    0x20(%rdx),%r10d
  81de20:	jne    81dd51 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81de26:	cmp    $0x4c,%r10d
  81de2a:	jne    81de4f <<gpui_gpu::renderer::RendererState>::render+0x29f>
  81de2c:	movq   0x3c(%r8),%xmm0
  81de32:	movq   0x24(%rdx),%xmm1
  81de37:	pcmpeqd %xmm0,%xmm1
  81de3b:	pshufd $0x50,%xmm1,%xmm0
  81de40:	movmskpd %xmm0,%r9d
  81de45:	cmp    $0x3,%r9d
  81de49:	jne    81dd51 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81de4f:	cmp    $0x4000,%r15d
  81de56:	ja     81de8c <<gpui_gpu::renderer::RendererState>::render+0x2dc>
  81de58:	cmp    $0x4000,%r14d
  81de5f:	ja     81de8c <<gpui_gpu::renderer::RendererState>::render+0x2dc>
  81de61:	mov    %r15,%r9
  81de64:	imul   %r14,%r9
  81de68:	add    $0xfffffffffeffffff,%r9
  81de6f:	cmp    $0xffffffffff000000,%r9
  81de76:	jb     81de8c <<gpui_gpu::renderer::RendererState>::render+0x2dc>
  81de78:	mov    0x10(%rcx),%rbx
  81de7c:	mov    0x80(%rbx),%r11
  81de83:	cmp    $0x10000,%r11
  81de8a:	jbe    81de97 <<gpui_gpu::renderer::RendererState>::render+0x2e7>
  81de8c:	movl   $0x6,(%rdi)
  81de92:	jmp    81dd5f <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81de97:	movd   0x18(%rcx),%xmm0
  81de9c:	movd   %xmm0,%r9d
  81dea1:	and    $0x7fffffff,%r9d
  81dea8:	cmp    $0x7f7fffff,%r9d
  81deaf:	jg     81dd51 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81deb5:	pand   -0x7706bd(%rip),%xmm0        # ad800 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81debd:	ucomiss -0x76ed40(%rip),%xmm0        # af184 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81dec4:	ja     81dd51 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81deca:	movd   0x1c(%rcx),%xmm0
  81decf:	movd   %xmm0,%r9d
  81ded4:	and    $0x7fffffff,%r9d
  81dedb:	cmp    $0x7f7fffff,%r9d
  81dee2:	jg     81dd51 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81dee8:	pand   -0x7706f0(%rip),%xmm0        # ad800 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81def0:	ucomiss -0x76ed73(%rip),%xmm0        # af184 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81def7:	ja     81dd51 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81defd:	movd   0x20(%rcx),%xmm0
  81df02:	movd   %xmm0,%r9d
  81df07:	and    $0x7fffffff,%r9d
  81df0e:	cmp    $0x7f7fffff,%r9d
  81df15:	jg     81dd51 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81df1b:	pand   -0x770723(%rip),%xmm0        # ad800 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81df23:	ucomiss -0x76eda6(%rip),%xmm0        # af184 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81df2a:	ja     81dd51 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81df30:	movd   0x24(%rcx),%xmm0
  81df35:	movd   %xmm0,%r9d
  81df3a:	and    $0x7fffffff,%r9d
  81df41:	cmp    $0x7f7fffff,%r9d
  81df48:	jg     81dd51 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81df4e:	movdqa -0x770756(%rip),%xmm1        # ad800 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81df56:	pand   %xmm0,%xmm1
  81df5a:	ucomiss -0x76eddd(%rip),%xmm1        # af184 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81df61:	ja     81dd51 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81df67:	xorps  %xmm1,%xmm1
  81df6a:	ucomiss %xmm1,%xmm0
  81df6d:	jb     81dd51 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81df73:	movss  -0x76f17b(%rip),%xmm1        # aee00 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  81df7b:	ucomiss %xmm0,%xmm1
  81df7e:	jb     81dd51 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81df84:	movzwl 0x30(%rcx),%r9d
  81df89:	mov    %r9d,0x8(%rsp)
  81df8e:	movzwl 0x32(%rcx),%r9d
  81df93:	mov    %r9d,0x20(%rsp)
  81df98:	cmp    $0x28,%r10d
  81df9c:	mov    %r8,0x478(%rsp)
  81dfa4:	mov    %rcx,0x148(%rsp)
  81dfac:	mov    %rdx,0xc0(%rsp)
  81dfb4:	movd   %xmm2,0x2ac(%rsp)
  81dfbd:	movss  %xmm1,0xfc(%rsp)
  81dfc6:	jne    81dfd2 <<gpui_gpu::renderer::RendererState>::render+0x422>
  81dfc8:	test   $0x1,%al
  81dfca:	je     81dd51 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81dfd0:	jmp    81dfed <<gpui_gpu::renderer::RendererState>::render+0x43d>
  81dfd2:	test   $0x1,%al
  81dfd4:	jne    81dd51 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81dfda:	ucomiss -0x76f1e1(%rip),%xmm0        # aee00 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  81dfe1:	jne    81dd51 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81dfe7:	jp     81dd51 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81dfed:	mov    %rbx,0x120(%rsp)
  81dff5:	mov    %r11,0x128(%rsp)
  81dffd:	mov    %r10d,0x2a8(%rsp)
  81e005:	mov    %rdi,0x28(%rsp)
  81e00a:	lea    0xf(%r14),%rax
  81e00e:	shr    $0x4,%rax
  81e012:	lea    0xf(%r15),%ecx
  81e016:	shr    $0x4,%ecx
  81e019:	lea    0x18(%rsi),%rdi
  81e01d:	movq   $0x0,0x28(%rsi)
  81e025:	mov    %rax,0x80(%rsp)
  81e02d:	imul   %eax,%ecx
  81e030:	mov    %rdi,0x488(%rsp)
  81e038:	mov    %rsi,%rbx
  81e03b:	mov    %rcx,0x40(%rsp)
  81e040:	mov    %rcx,%rsi
  81e043:	xor    %edx,%edx
  81e045:	call   823140 <<alloc::vec::Vec<[u32; 2]>>::resize>
  81e04a:	mov    %rbx,(%rsp)
  81e04e:	mov    0x10(%rbx),%rax
  81e052:	mov    %rax,0x348(%rsp)
  81e05a:	mov    0x148(%rsp),%rdi
  81e062:	call   *0x661ae0(%rip)        # e7fb48 <_DYNAMIC+0x5a8>
  81e068:	mov    %rdx,0x350(%rsp)
  81e070:	mov    %rax,0x358(%rsp)
  81e078:	sub    %rax,%rdx
  81e07b:	cmp    $0x300000,%rdx
  81e082:	ja     81e1b8 <<gpui_gpu::renderer::RendererState>::render+0x608>
  81e088:	mov    %rdx,%rcx
  81e08b:	mov    %rdx,%rax
  81e08e:	shr    $0x3,%rax
  81e092:	movabs $0xaaaaaaaaaaaaaaab,%rdx
  81e09c:	imul   %rax,%rdx
  81e0a0:	mov    %rdx,0x288(%rsp)
  81e0a8:	mov    0x350(%rsp),%rax
  81e0b0:	cmp    0x358(%rsp),%rax
  81e0b8:	je     81e0e9 <<gpui_gpu::renderer::RendererState>::render+0x539>
  81e0ba:	mov    $0xaaaaaaab,%eax
  81e0bf:	imul   %rax,%rcx
  81e0c3:	shr    $0x2a,%rcx
  81e0c7:	mov    0x288(%rsp),%rdx
  81e0cf:	mov    %edx,%eax
  81e0d1:	and    $0x3f,%eax
  81e0d4:	add    %rdx,%rcx
  81e0d7:	cmp    $0x1,%rax
  81e0db:	sbb    $0xffffffffffffffff,%rcx
  81e0df:	inc    %rcx
  81e0e2:	mov    %rcx,0x10(%rsp)
  81e0e7:	jmp    81e0f2 <<gpui_gpu::renderer::RendererState>::render+0x542>
  81e0e9:	movq   $0x0,0x10(%rsp)
  81e0f2:	mov    0x120(%rsp),%rax
  81e0fa:	mov    0x98(%rax),%rdx
  81e101:	add    0xb0(%rax),%rdx
  81e108:	mov    0x20(%rsp),%ecx
  81e10c:	shl    $0x10,%ecx
  81e10f:	add    0x8(%rsp),%ecx
  81e113:	mov    %rax,0x180(%rsp)
  81e11b:	movq   $0x0,0x188(%rsp)
  81e127:	mov    0x128(%rsp),%rbx
  81e12f:	mov    %rbx,0x190(%rsp)
  81e137:	mov    %rdx,0x340(%rsp)
  81e13f:	mov    %rdx,0x198(%rsp)
  81e147:	mov    %ecx,0x20(%rsp)
  81e14b:	mov    %ecx,0x1a0(%rsp)
  81e152:	mov    (%rsp),%rax
  81e156:	movzbl 0x341(%rax),%esi
  81e15d:	lea    0x180(%rsp),%rdi
  81e165:	call   81c2d0 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>>
  81e16a:	mov    %rax,0x130(%rsp)
  81e172:	mov    0x10(%rsp),%rcx
  81e177:	lea    (%rcx,%rax,4),%rax
  81e17b:	mov    %rax,0x8(%rsp)
  81e180:	lea    (%rax,%rbx,2),%rax
  81e184:	xor    %edx,%edx
  81e186:	mov    %rax,0x280(%rsp)
  81e18e:	sub    0x348(%rsp),%rax
  81e196:	cmovae %rax,%rdx
  81e19a:	mov    (%rsp),%rdi
  81e19e:	mov    0x10(%rdi),%rsi
  81e1a2:	mov    $0x4,%ecx
  81e1a7:	mov    $0x10,%r8d
  81e1ad:	call   825200 <<alloc::raw_vec::RawVecInner>::try_reserve_exact>
  81e1b2:	cmp    $0xffffffffffffffff,%rax
  81e1b6:	je     81e1c8 <<gpui_gpu::renderer::RendererState>::render+0x618>
  81e1b8:	mov    0x28(%rsp),%rdi
  81e1bd:	movl   $0x6,(%rdi)
  81e1c3:	jmp    81dd5f <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81e1c8:	pxor   %xmm0,%xmm0
  81e1cc:	movdqa %xmm0,0x180(%rsp)
  81e1d5:	lea    0x180(%rsp),%rdx
  81e1dd:	mov    (%rsp),%rbx
  81e1e1:	mov    %rbx,%rdi
  81e1e4:	mov    0x128(%rsp),%rax
  81e1ec:	mov    0x8(%rsp),%rcx
  81e1f1:	lea    (%rcx,%rax,2),%rsi
  81e1f5:	call   823260 <<alloc::vec::Vec<[u32; 4]>>::resize>
  81e1fa:	movq   $0xffffffffffffffff,0x298(%rsp)
  81e206:	movq   $0x0,0x2a0(%rsp)
  81e212:	mov    0x10(%rbx),%rdx
  81e216:	cmp    %rdx,0x10(%rsp)
  81e21b:	ja     81ffaa <<gpui_gpu::renderer::RendererState>::render+0x23fa>
  81e221:	mov    (%rsp),%rbx
  81e225:	mov    0x8(%rbx),%rdi
  81e229:	lea    0x298(%rsp),%r8
  81e231:	mov    0x10(%rsp),%rsi
  81e236:	mov    0x148(%rsp),%rdx
  81e23e:	mov    0x288(%rsp),%rcx
  81e246:	call   824ba0 <gpui_gpu::renderer::slots::write_prefix>
  81e24b:	lea    0x48(%rbx),%rdi
  81e24f:	movq   $0x0,0x58(%rbx)
  81e257:	mov    %rdi,0x480(%rsp)
  81e25f:	mov    0x40(%rsp),%rsi
  81e264:	xor    %edx,%edx
  81e266:	call   823350 <<alloc::vec::Vec<u32>>::resize>
  81e26b:	movq   $0x0,0x70(%rbx)
  81e273:	cmpq   $0x0,0x60(%rbx)
  81e278:	jne    81e288 <<gpui_gpu::renderer::RendererState>::render+0x6d8>
  81e27a:	mov    (%rsp),%rax
  81e27e:	lea    0x60(%rax),%rdi
  81e282:	call   *0x6618c8(%rip)        # e7fb50 <_DYNAMIC+0x5b0>
  81e288:	mov    0x130(%rsp),%rax
  81e290:	add    %rax,%rax
  81e293:	mov    %rax,0x130(%rsp)
  81e29b:	mov    (%rsp),%rax
  81e29f:	mov    0x68(%rax),%rcx
  81e2a3:	pxor   %xmm0,%xmm0
  81e2a7:	movdqu %xmm0,0x10(%rcx)
  81e2ac:	movdqu %xmm0,(%rcx)
  81e2b0:	movq   $0x1,0x70(%rax)
  81e2b8:	lea    0x2f8(%rax),%rdi
  81e2bf:	call   822b90 <<hashbrown::raw::RawTable<([u32; 8], u32)>>::clear>
  81e2c4:	mov    0x120(%rsp),%rax
  81e2cc:	mov    %rax,0x360(%rsp)
  81e2d4:	movq   $0x0,0x368(%rsp)
  81e2e0:	mov    0x128(%rsp),%rax
  81e2e8:	mov    %rax,0x370(%rsp)
  81e2f0:	mov    0x340(%rsp),%rax
  81e2f8:	mov    %rax,0x378(%rsp)
  81e300:	mov    0x20(%rsp),%eax
  81e304:	mov    %eax,0x380(%rsp)
  81e30b:	lea    0x408(%rsp),%rdi
  81e313:	lea    0x360(%rsp),%rsi
  81e31b:	call   *0x661837(%rip)        # e7fb58 <_DYNAMIC+0x5b8>
  81e321:	mov    0x408(%rsp),%rax
  81e329:	mov    %rax,0x170(%rsp)
  81e331:	test   %rax,%rax
  81e334:	je     81eed2 <<gpui_gpu::renderer::RendererState>::render+0x1322>
  81e33a:	movq   $0xffffffffffffffff,0x38(%rsp)
  81e343:	movq   $0x0,0x140(%rsp)
  81e34f:	movq   $0x0,0x58(%rsp)
  81e358:	movq   $0x0,0x78(%rsp)
  81e361:	movq   $0x0,0x270(%rsp)
  81e36d:	movq   $0x0,0x278(%rsp)
  81e379:	movq   $0x0,0x30(%rsp)
  81e382:	mov    0x410(%rsp),%rdi
  81e38a:	mov    %rdi,0x70(%rsp)
  81e38f:	mov    0x418(%rsp),%rbx
  81e397:	lea    0x420(%rsp),%rcx
  81e39f:	movups (%rcx),%xmm0
  81e3a2:	movups 0x10(%rcx),%xmm1
  81e3a6:	movups 0x20(%rcx),%xmm2
  81e3aa:	movaps %xmm2,0x2d0(%rsp)
  81e3b2:	movaps %xmm1,0x2c0(%rsp)
  81e3ba:	movaps %xmm0,0x2b0(%rsp)
  81e3c2:	lea    0x450(%rsp),%rdx
  81e3ca:	movups (%rdx),%xmm0
  81e3cd:	movaps %xmm0,0x300(%rsp)
  81e3d5:	movups 0x40(%rcx),%xmm0
  81e3d9:	movaps %xmm0,0x330(%rsp)
  81e3e1:	mov    (%rsp),%rax
  81e3e5:	movzbl 0x341(%rax),%esi
  81e3ec:	mov    0x170(%rsp),%rax
  81e3f4:	mov    %rax,0x180(%rsp)
  81e3fc:	mov    %rdi,0x188(%rsp)
  81e404:	mov    %rbx,0x190(%rsp)
  81e40c:	movups (%rcx),%xmm0
  81e40f:	movdqu 0x10(%rcx),%xmm1
  81e414:	movdqu 0x20(%rcx),%xmm2
  81e419:	lea    0x198(%rsp),%rdi
  81e421:	movdqu %xmm2,0x20(%rdi)
  81e426:	movdqu %xmm1,0x10(%rdi)
  81e42b:	movups %xmm0,(%rdi)
  81e42e:	movups (%rdx),%xmm0
  81e431:	lea    0x1c8(%rsp),%rax
  81e439:	movups %xmm0,(%rax)
  81e43c:	movdqu 0x40(%rcx),%xmm0
  81e441:	movdqu %xmm0,0x40(%rdi)
  81e446:	lea    0x180(%rsp),%rdi
  81e44e:	call   8210b0 <gpui_gpu::renderer::compact_group>
  81e453:	mov    %rbx,0xe8(%rsp)
  81e45b:	mov    0x70(%rsp),%rcx
  81e460:	lea    (%rcx,%rbx,4),%rbx
  81e464:	mov    %al,0x1f(%rsp)
  81e468:	test   %al,%al
  81e46a:	je     81e65c <<gpui_gpu::renderer::RendererState>::render+0xaac>
  81e470:	mov    0x70(%rsp),%rax
  81e475:	mov    %rax,0x150(%rsp)
  81e47d:	mov    %rbx,0x158(%rsp)
  81e485:	mov    0x170(%rsp),%rax
  81e48d:	mov    %rax,0x160(%rsp)
  81e495:	movq   $0x0,0x168(%rsp)
  81e4a1:	lea    0x3a8(%rsp),%rdi
  81e4a9:	lea    0x150(%rsp),%rsi
  81e4b1:	call   821740 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81e4b6:	cmpb   $0xff,0x3b0(%rsp)
  81e4be:	je     81e66a <<gpui_gpu::renderer::RendererState>::render+0xaba>
  81e4c4:	pxor   %xmm0,%xmm0
  81e4c8:	movdqa %xmm0,0x60(%rsp)
  81e4ce:	movdqa %xmm0,0x40(%rsp)
  81e4d4:	mov    0x3a8(%rsp),%rdx
  81e4dc:	add    0x78(%rsp),%rdx
  81e4e1:	lea    0x3b0(%rsp),%rcx
  81e4e9:	movups 0x38(%rcx),%xmm0
  81e4ed:	lea    0x198(%rsp),%rax
  81e4f5:	movups %xmm0,0x20(%rax)
  81e4f9:	movups 0x48(%rcx),%xmm0
  81e4fd:	lea    0x1c8(%rsp),%rsi
  81e505:	movups %xmm0,0x40(%rsi)
  81e509:	mov    0x30(%rcx),%rax
  81e50d:	mov    %rax,0x1b0(%rsp)
  81e515:	movups (%rcx),%xmm0
  81e518:	movups 0x10(%rcx),%xmm1
  81e51c:	movups 0x20(%rcx),%xmm2
  81e520:	movaps %xmm2,0x1a0(%rsp)
  81e528:	movaps %xmm1,0x190(%rsp)
  81e530:	movaps %xmm0,0x180(%rsp)
  81e538:	lea    0x420(%rsp),%rax
  81e540:	movups (%rax),%xmm0
  81e543:	movups 0x10(%rax),%xmm1
  81e547:	movups 0x20(%rax),%xmm2
  81e54b:	movups %xmm2,0x20(%rsi)
  81e54f:	movups %xmm1,0x10(%rsi)
  81e553:	movups %xmm0,(%rsi)
  81e556:	lea    0x450(%rsp),%rcx
  81e55e:	movups (%rcx),%xmm0
  81e561:	movups %xmm0,0x30(%rsi)
  81e565:	movups 0x40(%rax),%xmm0
  81e569:	movups %xmm0,0x50(%rsi)
  81e56d:	lea    0x310(%rsp),%rdi
  81e575:	lea    0x180(%rsp),%rsi
  81e57d:	mov    %r14d,%ecx
  81e580:	mov    %r15d,%r8d
  81e583:	call   821100 <gpui_gpu::renderer::validate_draw>
  81e588:	mov    0x310(%rsp),%ecx
  81e58f:	mov    0x314(%rsp),%rax
  81e597:	cmp    $0xffffffff,%ecx
  81e59a:	jne    81efbc <<gpui_gpu::renderer::RendererState>::render+0x140c>
  81e5a0:	mov    %eax,%ecx
  81e5a2:	shr    $0x20,%rax
  81e5a6:	movd   %ecx,%xmm0
  81e5aa:	movaps 0x60(%rsp),%xmm2
  81e5af:	movaps %xmm2,%xmm1
  81e5b2:	maxss  %xmm0,%xmm1
  81e5b6:	movaps %xmm1,%xmm3
  81e5b9:	cmpunordss %xmm1,%xmm3
  81e5be:	movaps %xmm3,%xmm0
  81e5c1:	andnps %xmm1,%xmm0
  81e5c4:	andps  %xmm2,%xmm3
  81e5c7:	orps   %xmm0,%xmm3
  81e5ca:	movaps %xmm3,0x90(%rsp)
  81e5d2:	movd   %eax,%xmm0
  81e5d6:	movaps 0x40(%rsp),%xmm2
  81e5db:	movaps %xmm2,%xmm1
  81e5de:	maxss  %xmm0,%xmm1
  81e5e2:	movaps %xmm1,%xmm3
  81e5e5:	cmpunordss %xmm1,%xmm3
  81e5ea:	movaps %xmm3,%xmm0
  81e5ed:	andnps %xmm1,%xmm0
  81e5f0:	andps  %xmm2,%xmm3
  81e5f3:	orps   %xmm0,%xmm3
  81e5f6:	movaps %xmm3,0x100(%rsp)
  81e5fe:	lea    0x3a8(%rsp),%rdi
  81e606:	lea    0x150(%rsp),%rsi
  81e60e:	call   821740 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81e613:	cmpb   $0xff,0x3b0(%rsp)
  81e61b:	movdqa 0x90(%rsp),%xmm1
  81e624:	movdqa %xmm1,0x60(%rsp)
  81e62a:	movdqa 0x100(%rsp),%xmm2
  81e633:	movdqa %xmm2,0x40(%rsp)
  81e639:	jne    81e4d4 <<gpui_gpu::renderer::RendererState>::render+0x924>
  81e63f:	movdqa %xmm1,%xmm0
  81e643:	movd   %xmm0,%ecx
  81e647:	movd   %xmm2,%eax
  81e64b:	shl    $0x20,%rax
  81e64f:	or     %rax,%rcx
  81e652:	mov    %rcx,0x118(%rsp)
  81e65a:	jmp    81e676 <<gpui_gpu::renderer::RendererState>::render+0xac6>
  81e65c:	movq   $0x0,0x118(%rsp)
  81e668:	jmp    81e68e <<gpui_gpu::renderer::RendererState>::render+0xade>
  81e66a:	movq   $0x0,0x118(%rsp)
  81e676:	incq   0x270(%rsp)
  81e67e:	mov    0xe8(%rsp),%rax
  81e686:	add    %rax,0x278(%rsp)
  81e68e:	mov    0x70(%rsp),%rax
  81e693:	mov    %rax,0x310(%rsp)
  81e69b:	mov    %rbx,0x318(%rsp)
  81e6a3:	mov    0x170(%rsp),%rax
  81e6ab:	mov    %rax,0x320(%rsp)
  81e6b3:	movq   $0x0,0x328(%rsp)
  81e6bf:	lea    0x3a8(%rsp),%rdi
  81e6c7:	lea    0x310(%rsp),%rsi
  81e6cf:	call   821740 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81e6d4:	movzbl 0x3b0(%rsp),%eax
  81e6dc:	cmp    $0xff,%al
  81e6de:	je     81eea1 <<gpui_gpu::renderer::RendererState>::render+0x12f1>
  81e6e4:	mov    %eax,%r8d
  81e6e7:	mov    0x8(%rsp),%rax
  81e6ec:	shl    $0x4,%rax
  81e6f0:	mov    %rax,0x40(%rsp)
  81e6f5:	mov    0x10(%rsp),%rax
  81e6fa:	mov    %rax,0xc8(%rsp)
  81e702:	mov    0x3a8(%rsp),%rax
  81e70a:	lea    0x3b0(%rsp),%rsi
  81e712:	movups 0x48(%rsi),%xmm0
  81e716:	lea    0x518(%rsp),%rdi
  81e71e:	movups %xmm0,0x40(%rdi)
  81e722:	mov    0x1(%rsi),%ecx
  81e725:	mov    0x4(%rsi),%edx
  81e728:	mov    %edx,-0x44(%rdi)
  81e72b:	mov    %ecx,-0x47(%rdi)
  81e72e:	mov    0x3b8(%rsp),%rdx
  81e736:	mov    0x30(%rsi),%rcx
  81e73a:	mov    %rcx,-0x18(%rdi)
  81e73e:	movups 0x10(%rsi),%xmm0
  81e742:	movups 0x20(%rsi),%xmm1
  81e746:	movups %xmm1,-0x28(%rdi)
  81e74a:	movups %xmm0,-0x38(%rdi)
  81e74e:	movaps 0x2b0(%rsp),%xmm0
  81e756:	movaps 0x2c0(%rsp),%xmm1
  81e75e:	movaps 0x2d0(%rsp),%xmm2
  81e766:	movups %xmm2,0x20(%rdi)
  81e76a:	movups %xmm1,0x10(%rdi)
  81e76e:	movups %xmm0,(%rdi)
  81e771:	movaps 0x300(%rsp),%xmm0
  81e779:	movups %xmm0,0x30(%rdi)
  81e77d:	movaps 0x330(%rsp),%xmm0
  81e785:	movups %xmm0,0x50(%rdi)
  81e789:	movups 0x3e8(%rsp),%xmm0
  81e791:	movups %xmm0,0x508(%rsp)
  81e799:	mov    %r8b,0x90(%rsp)
  81e7a1:	mov    %r8b,0x4d0(%rsp)
  81e7a9:	mov    %rdx,0x2e0(%rsp)
  81e7b1:	mov    %rdx,0x4d8(%rsp)
  81e7b9:	movaps %xmm0,%xmm1
  81e7bc:	unpckhpd %xmm0,%xmm1
  81e7c0:	movaps %xmm1,0x100(%rsp)
  81e7c8:	movaps %xmm0,0x390(%rsp)
  81e7d0:	shufps $0xff,%xmm0,%xmm0
  81e7d4:	movaps %xmm0,0x2f0(%rsp)
  81e7dc:	cmpb   $0x0,0x1f(%rsp)
  81e7e1:	je     81e821 <<gpui_gpu::renderer::RendererState>::render+0xc71>
  81e7e3:	mov    0x118(%rsp),%rcx
  81e7eb:	mov    %rcx,0x60(%rsp)
  81e7f0:	mov    0x10(%rsp),%rcx
  81e7f5:	mov    %rcx,0x88(%rsp)
  81e7fd:	test   %rax,%rax
  81e800:	je     81e86e <<gpui_gpu::renderer::RendererState>::render+0xcbe>
  81e802:	mov    0x118(%rsp),%rax
  81e80a:	mov    %rax,0x60(%rsp)
  81e80f:	mov    0x10(%rsp),%rax
  81e814:	mov    %rax,0x88(%rsp)
  81e81c:	jmp    81ebee <<gpui_gpu::renderer::RendererState>::render+0x103e>
  81e821:	lea    0x180(%rsp),%rdi
  81e829:	lea    0x4d0(%rsp),%rsi
  81e831:	mov    0x78(%rsp),%rdx
  81e836:	mov    %r14d,%ecx
  81e839:	mov    %r15d,%r8d
  81e83c:	call   821100 <gpui_gpu::renderer::validate_draw>
  81e841:	mov    0x180(%rsp),%eax
  81e848:	mov    0x184(%rsp),%rcx
  81e850:	mov    %rcx,0x60(%rsp)
  81e855:	cmp    $0xffffffff,%eax
  81e858:	jne    81f049 <<gpui_gpu::renderer::RendererState>::render+0x1499>
  81e85e:	mov    0xc8(%rsp),%rax
  81e866:	mov    %rax,0x88(%rsp)
  81e86e:	cmpb   $0x3,0x90(%rsp)
  81e876:	jne    81e91e <<gpui_gpu::renderer::RendererState>::render+0xd6e>
  81e87c:	movss  0x4d4(%rsp),%xmm0
  81e885:	xorps  %xmm1,%xmm1
  81e888:	ucomiss %xmm1,%xmm0
  81e88b:	jne    81e893 <<gpui_gpu::renderer::RendererState>::render+0xce3>
  81e88d:	jnp    81e91e <<gpui_gpu::renderer::RendererState>::render+0xd6e>
  81e893:	movaps 0x100(%rsp),%xmm1
  81e89b:	movss  -0x76f8b7(%rip),%xmm4        # aefec <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  81e8a3:	mulss  %xmm4,%xmm1
  81e8a7:	movaps %xmm0,%xmm2
  81e8aa:	minss  %xmm1,%xmm2
  81e8ae:	movaps %xmm2,%xmm1
  81e8b1:	cmpunordss %xmm2,%xmm1
  81e8b6:	movaps %xmm1,%xmm3
  81e8b9:	andnps %xmm2,%xmm3
  81e8bc:	andps  %xmm0,%xmm1
  81e8bf:	orps   %xmm3,%xmm1
  81e8c2:	movaps 0x2f0(%rsp),%xmm0
  81e8ca:	mulss  %xmm4,%xmm0
  81e8ce:	movaps %xmm1,%xmm2
  81e8d1:	minss  %xmm0,%xmm2
  81e8d5:	movaps %xmm2,%xmm0
  81e8d8:	cmpunordss %xmm2,%xmm0
  81e8dd:	andps  %xmm0,%xmm1
  81e8e0:	andnps %xmm2,%xmm0
  81e8e3:	orps   %xmm1,%xmm0
  81e8e6:	movd   %xmm0,%eax
  81e8ea:	mov    %eax,0xd8(%rsp)
  81e8f1:	and    $0xff800000,%eax
  81e8f6:	mov    $0x7f000000,%ecx
  81e8fb:	sub    %eax,%ecx
  81e8fd:	mov    %rcx,0xb8(%rsp)
  81e905:	movl   $0x0,0xd0(%rsp)
  81e910:	movq   $0x0,0xe0(%rsp)
  81e91c:	jmp    81e958 <<gpui_gpu::renderer::RendererState>::render+0xda8>
  81e91e:	mov    0x568(%rsp),%eax
  81e925:	mov    %eax,0xd8(%rsp)
  81e92c:	mov    0x56c(%rsp),%eax
  81e933:	mov    %rax,0xb8(%rsp)
  81e93b:	mov    0x570(%rsp),%eax
  81e942:	mov    %eax,0xd0(%rsp)
  81e949:	mov    0x574(%rsp),%eax
  81e950:	mov    %rax,0xe0(%rsp)
  81e958:	movsd  0x518(%rsp),%xmm0
  81e961:	movsd  %xmm0,0x290(%rsp)
  81e96a:	movsd  0x520(%rsp),%xmm0
  81e973:	movsd  %xmm0,0x470(%rsp)
  81e97c:	movsd  0x528(%rsp),%xmm0
  81e985:	movaps %xmm0,0x4c0(%rsp)
  81e98d:	movsd  0x530(%rsp),%xmm0
  81e996:	movaps %xmm0,0x4a0(%rsp)
  81e99e:	movups 0x538(%rsp),%xmm0
  81e9a6:	movaps %xmm0,0x4b0(%rsp)
  81e9ae:	movups 0x540(%rsp),%xmm0
  81e9b6:	movaps %xmm0,0x490(%rsp)
  81e9be:	mov    0x548(%rsp),%rax
  81e9c6:	mov    %rax,0x138(%rsp)
  81e9ce:	mov    0x550(%rsp),%eax
  81e9d5:	mov    %eax,0xa8(%rsp)
  81e9dc:	mov    0x554(%rsp),%eax
  81e9e3:	mov    %rax,0xb0(%rsp)
  81e9eb:	mov    0x60(%rsp),%rbx
  81e9f0:	shr    $0x20,%rbx
  81e9f4:	mov    0x170(%rsp),%rax
  81e9fc:	mov    %rax,0x180(%rsp)
  81ea04:	mov    0x70(%rsp),%rax
  81ea09:	mov    %rax,0x188(%rsp)
  81ea11:	mov    0xe8(%rsp),%rax
  81ea19:	mov    %rax,0x190(%rsp)
  81ea21:	movaps 0x2b0(%rsp),%xmm0
  81ea29:	movaps 0x2c0(%rsp),%xmm1
  81ea31:	movaps 0x2d0(%rsp),%xmm2
  81ea39:	lea    0x198(%rsp),%rcx
  81ea41:	movups %xmm2,0x20(%rcx)
  81ea45:	movups %xmm1,0x10(%rcx)
  81ea49:	movups %xmm0,(%rcx)
  81ea4c:	movaps 0x300(%rsp),%xmm0
  81ea54:	lea    0x1c8(%rsp),%rax
  81ea5c:	movups %xmm0,(%rax)
  81ea5f:	movaps 0x330(%rsp),%xmm0
  81ea67:	movups %xmm0,0x40(%rcx)
  81ea6b:	lea    0x180(%rsp),%rdi
  81ea73:	call   *0x6610e7(%rip)        # e7fb60 <_DYNAMIC+0x5c0>
  81ea79:	test   %eax,%eax
  81ea7b:	je     81eab6 <<gpui_gpu::renderer::RendererState>::render+0xf06>
  81ea7d:	mov    0x288(%rsp),%rdi
  81ea85:	mov    %eax,%esi
  81ea87:	call   824b60 <gpui_gpu::renderer::slots::color_word>
  81ea8c:	mov    %eax,0xd8(%rsp)
  81ea93:	movq   $0x0,0xb8(%rsp)
  81ea9f:	movl   $0x0,0xd0(%rsp)
  81eaaa:	movq   $0x0,0xe0(%rsp)
  81eab6:	movapd 0x490(%rsp),%xmm0
  81eabf:	unpcklpd 0x4a0(%rsp),%xmm0
  81eac8:	cvtpd2ps %xmm0,%xmm0
  81eacc:	movsd  0x470(%rsp),%xmm1
  81ead5:	cvtsd2ss %xmm1,%xmm1
  81ead9:	movapd 0x4b0(%rsp),%xmm2
  81eae2:	unpcklpd 0x4c0(%rsp),%xmm2
  81eaeb:	cvtpd2ps %xmm2,%xmm2
  81eaef:	movsd  0x290(%rsp),%xmm3
  81eaf8:	cvtsd2ss %xmm3,%xmm3
  81eafc:	mov    (%rsp),%rax
  81eb00:	mov    0x8(%rax),%rsi
  81eb04:	mov    0x10(%rax),%rdx
  81eb08:	movd   %xmm3,%r8d
  81eb0d:	mov    0x60(%rsp),%rax
  81eb12:	shl    $0x20,%rax
  81eb16:	movd   %xmm2,%r9d
  81eb1b:	shufps $0x55,%xmm2,%xmm2
  81eb1f:	movd   %xmm2,%ecx
  81eb23:	shl    $0x20,%rcx
  81eb27:	or     %rax,%r9
  81eb2a:	or     %rcx,%r8
  81eb2d:	movd   %xmm1,%eax
  81eb31:	shl    $0x20,%rbx
  81eb35:	movd   %xmm0,%r10d
  81eb3a:	shufps $0x55,%xmm0,%xmm0
  81eb3e:	movd   %xmm0,%ecx
  81eb42:	shl    $0x20,%rcx
  81eb46:	or     %rbx,%r10
  81eb49:	or     %rcx,%rax
  81eb4c:	lea    0x298(%rsp),%rdi
  81eb54:	mov    0xc8(%rsp),%rbx
  81eb5c:	mov    %rbx,%rcx
  81eb5f:	push   %r10
  81eb61:	push   %rax
  81eb62:	call   81b230 <<gpui_gpu::renderer::Changes>::replace::<2>>
  81eb67:	add    $0x10,%rsp
  81eb6b:	mov    (%rsp),%rax
  81eb6f:	mov    0x8(%rax),%rsi
  81eb73:	mov    0x10(%rax),%rdx
  81eb77:	mov    0x130(%rsp),%rax
  81eb7f:	lea    (%rbx,%rax,1),%rcx
  81eb83:	mov    0xa8(%rsp),%eax
  81eb8a:	mov    0xb0(%rsp),%r9
  81eb92:	shl    $0x20,%r9
  81eb96:	or     %rax,%r9
  81eb99:	mov    0xd8(%rsp),%eax
  81eba0:	mov    0xb8(%rsp),%r10
  81eba8:	shl    $0x20,%r10
  81ebac:	or     %rax,%r10
  81ebaf:	mov    0xd0(%rsp),%eax
  81ebb6:	mov    0xe0(%rsp),%r11
  81ebbe:	shl    $0x20,%r11
  81ebc2:	or     %rax,%r11
  81ebc5:	lea    0x298(%rsp),%rdi
  81ebcd:	mov    0x138(%rsp),%r8
  81ebd5:	push   %r11
  81ebd7:	push   %r10
  81ebd9:	call   81b230 <<gpui_gpu::renderer::Changes>::replace::<2>>
  81ebde:	add    $0x10,%rsp
  81ebe2:	add    $0x2,%rbx
  81ebe6:	mov    %rbx,0xc8(%rsp)
  81ebee:	cmpb   $0x2,0x90(%rsp)
  81ebf6:	sete   0x90(%rsp)
  81ebfe:	cmpq   $0x0,0x2e0(%rsp)
  81ec07:	setne  0x2e0(%rsp)
  81ec0f:	mov    0x170(%rsp),%rax
  81ec17:	mov    %rax,0x180(%rsp)
  81ec1f:	mov    0x70(%rsp),%rax
  81ec24:	mov    %rax,0x188(%rsp)
  81ec2c:	mov    0xe8(%rsp),%rax
  81ec34:	mov    %rax,0x190(%rsp)
  81ec3c:	movaps 0x2b0(%rsp),%xmm0
  81ec44:	movdqa 0x2c0(%rsp),%xmm1
  81ec4d:	movdqa 0x2d0(%rsp),%xmm2
  81ec56:	lea    0x198(%rsp),%rcx
  81ec5e:	movdqu %xmm2,0x20(%rcx)
  81ec63:	movdqu %xmm1,0x10(%rcx)
  81ec68:	movups %xmm0,(%rcx)
  81ec6b:	movaps 0x300(%rsp),%xmm0
  81ec73:	lea    0x1c8(%rsp),%rax
  81ec7b:	movups %xmm0,(%rax)
  81ec7e:	movaps 0x330(%rsp),%xmm0
  81ec86:	movups %xmm0,0x40(%rcx)
  81ec8a:	lea    0x180(%rsp),%rdi
  81ec92:	call   *0x660ec8(%rip)        # e7fb60 <_DYNAMIC+0x5c0>
  81ec98:	mov    0x88(%rsp),%rdx
  81eca0:	mov    %edx,%ecx
  81eca2:	or     $0x80000000,%ecx
  81eca8:	test   %eax,%eax
  81ecaa:	cmove  %edx,%ecx
  81ecad:	mov    (%rsp),%rax
  81ecb1:	mov    0x10(%rax),%rsi
  81ecb5:	cmp    %rsi,0x8(%rsp)
  81ecba:	jae    81ffd8 <<gpui_gpu::renderer::RendererState>::render+0x2428>
  81ecc0:	mov    0x8(%rax),%rax
  81ecc4:	movdqa 0x390(%rsp),%xmm0
  81eccd:	movd   %xmm0,%edx
  81ecd1:	shufps $0x55,%xmm0,%xmm0
  81ecd5:	movd   %xmm0,%r8d
  81ecda:	movdqa 0x100(%rsp),%xmm0
  81ece3:	movd   %xmm0,%edi
  81ece7:	movdqa 0x2f0(%rsp),%xmm0
  81ecf0:	movd   %xmm0,%r9d
  81ecf5:	shl    $0x20,%r9
  81ecf9:	or     %r9,%rdi
  81ecfc:	shl    $0x20,%r8
  81ed00:	or     %r8,%rdx
  81ed03:	mov    0x40(%rsp),%r9
  81ed08:	mov    (%rax,%r9,1),%r8
  81ed0c:	xor    %rdx,%r8
  81ed0f:	mov    0x8(%rax,%r9,1),%r9
  81ed14:	xor    %rdi,%r9
  81ed17:	or     %r8,%r9
  81ed1a:	je     81ed5d <<gpui_gpu::renderer::RendererState>::render+0x11ad>
  81ed1c:	mov    0x38(%rsp),%rsi
  81ed21:	mov    0x8(%rsp),%r8
  81ed26:	cmp    %rsi,%r8
  81ed29:	cmovb  %r8,%rsi
  81ed2d:	mov    %rsi,0x38(%rsp)
  81ed32:	lea    0x1(%r8),%rsi
  81ed36:	mov    0x30(%rsp),%r8
  81ed3b:	cmp    %r8,%rsi
  81ed3e:	cmova  %rsi,%r8
  81ed42:	mov    %r8,0x30(%rsp)
  81ed47:	mov    0x40(%rsp),%rsi
  81ed4c:	mov    %rdx,(%rax,%rsi,1)
  81ed50:	mov    %rdi,0x8(%rax,%rsi,1)
  81ed55:	mov    (%rsp),%rax
  81ed59:	mov    0x10(%rax),%rsi
  81ed5d:	mov    0x8(%rsp),%rax
  81ed62:	lea    0x1(%rax),%rdi
  81ed66:	cmp    %rsi,%rdi
  81ed69:	jae    81ffcb <<gpui_gpu::renderer::RendererState>::render+0x241b>
  81ed6f:	mov    (%rsp),%rax
  81ed73:	mov    0x8(%rax),%rax
  81ed77:	mov    0x40(%rsp),%rsi
  81ed7c:	mov    0x18(%rax,%rsi,1),%edx
  81ed80:	shl    $0x20,%rcx
  81ed84:	or     %rdx,%rcx
  81ed87:	mov    0x18(%rax,%rsi,1),%rdx
  81ed8c:	xor    %rcx,%rdx
  81ed8f:	je     81edd0 <<gpui_gpu::renderer::RendererState>::render+0x1220>
  81ed91:	mov    0x38(%rsp),%rdx
  81ed96:	cmp    %rdx,%rdi
  81ed99:	cmovb  %rdi,%rdx
  81ed9d:	mov    %rdx,0x38(%rsp)
  81eda2:	mov    0x8(%rsp),%rdx
  81eda7:	add    $0x2,%rdx
  81edab:	mov    0x30(%rsp),%rsi
  81edb0:	cmp    %rsi,%rdx
  81edb3:	cmova  %rdx,%rsi
  81edb7:	mov    %rsi,0x30(%rsp)
  81edbc:	mov    0x40(%rsp),%rsi
  81edc1:	mov    0x10(%rax,%rsi,1),%rdx
  81edc6:	mov    %rdx,0x10(%rax,%rsi,1)
  81edcb:	mov    %rcx,0x18(%rax,%rsi,1)
  81edd0:	lea    0x180(%rsp),%rdi
  81edd8:	mov    (%rsp),%rsi
  81eddc:	lea    0x4d0(%rsp),%rdx
  81ede4:	mov    0x60(%rsp),%rcx
  81ede9:	mov    0x8(%rsp),%r8
  81edee:	mov    0x78(%rsp),%rbx
  81edf3:	mov    %rbx,%r9
  81edf6:	push   0x140(%rsp)
  81edfd:	push   %r15
  81edff:	push   %r14
  81ee01:	push   0x98(%rsp)
  81ee08:	call   820050 <<gpui_gpu::renderer::RendererState>::bin_draw>
  81ee0d:	add    $0x20,%rsp
  81ee11:	mov    0x180(%rsp),%eax
  81ee18:	cmp    $0xffffffff,%eax
  81ee1b:	jne    81f019 <<gpui_gpu::renderer::RendererState>::render+0x1469>
  81ee21:	movzbl 0x90(%rsp),%ecx
  81ee29:	and    0x2e0(%rsp),%cl
  81ee30:	mov    0x58(%rsp),%rax
  81ee35:	or     %cl,%al
  81ee37:	mov    %rax,0x58(%rsp)
  81ee3c:	addq   $0x2,0x8(%rsp)
  81ee42:	mov    0x188(%rsp),%rax
  81ee4a:	mov    %rax,0x140(%rsp)
  81ee52:	inc    %rbx
  81ee55:	mov    %rbx,0x78(%rsp)
  81ee5a:	lea    0x3a8(%rsp),%rdi
  81ee62:	lea    0x310(%rsp),%rsi
  81ee6a:	call   821740 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81ee6f:	movzbl 0x3b0(%rsp),%r8d
  81ee78:	addq   $0x20,0x40(%rsp)
  81ee7e:	cmp    $0xff,%r8b
  81ee82:	jne    81e702 <<gpui_gpu::renderer::RendererState>::render+0xb52>
  81ee88:	mov    0x58(%rsp),%rax
  81ee8d:	and    $0x1,%al
  81ee8f:	mov    %rax,0x58(%rsp)
  81ee94:	mov    0xc8(%rsp),%rax
  81ee9c:	mov    %rax,0x10(%rsp)
  81eea1:	lea    0x408(%rsp),%rdi
  81eea9:	lea    0x360(%rsp),%rsi
  81eeb1:	call   *0x660ca1(%rip)        # e7fb58 <_DYNAMIC+0x5b8>
  81eeb7:	mov    0x408(%rsp),%rax
  81eebf:	mov    %rax,0x170(%rsp)
  81eec7:	test   %rax,%rax
  81eeca:	jne    81e382 <<gpui_gpu::renderer::RendererState>::render+0x7d2>
  81eed0:	jmp    81ef1a <<gpui_gpu::renderer::RendererState>::render+0x136a>
  81eed2:	movq   $0xffffffffffffffff,0x38(%rsp)
  81eedb:	movq   $0x0,0x30(%rsp)
  81eee4:	movq   $0x0,0x278(%rsp)
  81eef0:	movq   $0x0,0x270(%rsp)
  81eefc:	movq   $0x0,0x78(%rsp)
  81ef05:	movq   $0x0,0x58(%rsp)
  81ef0e:	movq   $0x0,0x140(%rsp)
  81ef1a:	mov    0xc0(%rsp),%rsi
  81ef22:	lea    0x8(%rsi),%rdx
  81ef26:	mov    (%rsp),%rax
  81ef2a:	lea    0x258(%rax),%rcx
  81ef31:	lea    0x328(%rax),%r8
  81ef38:	mov    0x10(%rax),%r9
  81ef3c:	sub    $0x8,%rsp
  81ef40:	lea    0x188(%rsp),%rdi
  81ef48:	mov    %rdx,0xb0(%rsp)
  81ef50:	mov    %rcx,0xb8(%rsp)
  81ef58:	mov    %r8,0xe0(%rsp)
  81ef60:	push   0x150(%rsp)
  81ef67:	call   8234a0 <gpui_gpu::renderer::images::prepare>
  81ef6c:	add    $0x10,%rsp
  81ef70:	mov    0x180(%rsp),%eax
  81ef77:	movzbl 0x184(%rsp),%ecx
  81ef7f:	mov    %cl,0x138(%rsp)
  81ef86:	cmp    $0xffffffff,%eax
  81ef89:	je     81efe2 <<gpui_gpu::renderer::RendererState>::render+0x1432>
  81ef8b:	movupd 0x185(%rsp),%xmm0
  81ef94:	movups 0x190(%rsp),%xmm1
  81ef9c:	mov    0x28(%rsp),%rdi
  81efa1:	movups %xmm1,0x10(%rdi)
  81efa5:	movupd %xmm0,0x5(%rdi)
  81efaa:	mov    %eax,(%rdi)
  81efac:	movzbl 0x138(%rsp),%eax
  81efb4:	mov    %al,0x4(%rdi)
  81efb7:	jmp    81dd5f <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81efbc:	mov    0x32c(%rsp),%edx
  81efc3:	mov    0x28(%rsp),%rdi
  81efc8:	mov    %edx,0x1c(%rdi)
  81efcb:	movups 0x31c(%rsp),%xmm0
  81efd3:	movups %xmm0,0xc(%rdi)
  81efd7:	mov    %ecx,(%rdi)
  81efd9:	mov    %rax,0x4(%rdi)
  81efdd:	jmp    81dd5f <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81efe2:	movzbl 0x58(%rsp),%r8d
  81efe8:	and    $0x1,%r8d
  81efec:	lea    0x180(%rsp),%rdi
  81eff4:	mov    (%rsp),%rsi
  81eff8:	mov    0xc0(%rsp),%rdx
  81f000:	mov    0x120(%rsp),%rcx
  81f008:	call   81d310 <<gpui_gpu::renderer::RendererState>::prepare_atlas>
  81f00d:	mov    0x180(%rsp),%eax
  81f014:	cmp    $0xffffffff,%eax
  81f017:	je     81f074 <<gpui_gpu::renderer::RendererState>::render+0x14c4>
  81f019:	mov    0x184(%rsp),%ecx
  81f020:	mov    0x188(%rsp),%rdx
  81f028:	movupd 0x190(%rsp),%xmm0
  81f031:	mov    0x28(%rsp),%rdi
  81f036:	movupd %xmm0,0x10(%rdi)
  81f03b:	mov    %eax,(%rdi)
  81f03d:	mov    %ecx,0x4(%rdi)
  81f040:	mov    %rdx,0x8(%rdi)
  81f044:	jmp    81dd5f <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81f049:	mov    0x19c(%rsp),%ecx
  81f050:	mov    0x28(%rsp),%rdi
  81f055:	mov    %ecx,0x1c(%rdi)
  81f058:	movups 0x18c(%rsp),%xmm0
  81f060:	movups %xmm0,0xc(%rdi)
  81f064:	mov    %eax,(%rdi)
  81f066:	mov    0x60(%rsp),%rax
  81f06b:	mov    %rax,0x4(%rdi)
  81f06f:	jmp    81dd5f <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81f074:	mov    0x188(%rsp),%rax
  81f07c:	mov    %rax,0x290(%rsp)
  81f084:	mov    (%rsp),%rax
  81f088:	mov    0x28(%rax),%rax
  81f08c:	movq   $0x0,0x10(%rsp)
  81f095:	test   %rax,%rax
  81f098:	je     81f102 <<gpui_gpu::renderer::RendererState>::render+0x1552>
  81f09a:	mov    (%rsp),%rcx
  81f09e:	mov    0x20(%rcx),%rcx
  81f0a2:	shl    $0x3,%rax
  81f0a6:	xor    %edi,%edi
  81f0a8:	jmp    81f0c6 <<gpui_gpu::renderer::RendererState>::render+0x1516>
  81f0aa:	mov    0x10(%rsp),%rdx
  81f0af:	add    %esi,%edx
  81f0b1:	mov    %edx,(%rcx,%rdi,8)
  81f0b4:	mov    %rdx,0x10(%rsp)
  81f0b9:	mov    %edx,0x4(%rcx,%rdi,8)
  81f0bd:	inc    %rdi
  81f0c0:	add    $0xfffffffffffffff8,%rax
  81f0c4:	je     81f0f6 <<gpui_gpu::renderer::RendererState>::render+0x1546>
  81f0c6:	mov    (%rsp),%rdx
  81f0ca:	mov    0x58(%rdx),%rsi
  81f0ce:	cmp    %rsi,%rdi
  81f0d1:	jae    81ffea <<gpui_gpu::renderer::RendererState>::render+0x243a>
  81f0d7:	mov    0x4(%rcx,%rdi,8),%esi
  81f0db:	cmp    $0x1,%esi
  81f0de:	jne    81f0aa <<gpui_gpu::renderer::RendererState>::render+0x14fa>
  81f0e0:	mov    (%rsp),%rdx
  81f0e4:	mov    0x50(%rdx),%r8
  81f0e8:	mov    $0x80000000,%edx
  81f0ed:	cmpl   $0x0,(%r8,%rdi,4)
  81f0f2:	jne    81f0b9 <<gpui_gpu::renderer::RendererState>::render+0x1509>
  81f0f4:	jmp    81f0aa <<gpui_gpu::renderer::RendererState>::render+0x14fa>
  81f0f6:	mov    0x10(%rsp),%rax
  81f0fb:	mov    %eax,%eax
  81f0fd:	mov    %rax,0x10(%rsp)
  81f102:	mov    (%rsp),%rax
  81f106:	lea    0x30(%rax),%rdi
  81f10a:	movq   $0x0,0x40(%rax)
  81f112:	mov    %rdi,0xe8(%rsp)
  81f11a:	mov    0x10(%rsp),%rsi
  81f11f:	xor    %edx,%edx
  81f121:	call   823350 <<alloc::vec::Vec<u32>>::resize>
  81f126:	mov    0x78(%rsp),%rax
  81f12b:	mov    %rax,0x300(%rsp)
  81f133:	mov    0x120(%rsp),%rax
  81f13b:	mov    %rax,0x2b0(%rsp)
  81f143:	movq   $0x0,0x2b8(%rsp)
  81f14f:	mov    0x128(%rsp),%rax
  81f157:	mov    %rax,0x2c0(%rsp)
  81f15f:	mov    0x340(%rsp),%rax
  81f167:	mov    %rax,0x2c8(%rsp)
  81f16f:	mov    0x20(%rsp),%eax
  81f173:	mov    %eax,0x2d0(%rsp)
  81f17a:	lea    0x408(%rsp),%rdi
  81f182:	lea    0x2b0(%rsp),%rsi
  81f18a:	call   *0x6609d8(%rip)        # e7fb68 <_DYNAMIC+0x5c8>
  81f190:	mov    0x408(%rsp),%rax
  81f198:	mov    %rax,0x390(%rsp)
  81f1a0:	test   %rax,%rax
  81f1a3:	je     81f74a <<gpui_gpu::renderer::RendererState>::render+0x1b9a>
  81f1a9:	mov    (%rsp),%rax
  81f1ad:	add    $0x120,%rax
  81f1b3:	mov    %rax,0xd0(%rsp)
  81f1bb:	mov    0x280(%rsp),%rax
  81f1c3:	mov    %rax,0x100(%rsp)
  81f1cb:	jmp    81f1fc <<gpui_gpu::renderer::RendererState>::render+0x164c>
  81f1cd:	lea    0x408(%rsp),%rdi
  81f1d5:	lea    0x2b0(%rsp),%rsi
  81f1dd:	call   *0x660985(%rip)        # e7fb68 <_DYNAMIC+0x5c8>
  81f1e3:	mov    0x408(%rsp),%rax
  81f1eb:	mov    %rax,0x390(%rsp)
  81f1f3:	test   %rax,%rax
  81f1f6:	je     81f74a <<gpui_gpu::renderer::RendererState>::render+0x1b9a>
  81f1fc:	mov    0x410(%rsp),%rax
  81f204:	mov    %rax,0xc8(%rsp)
  81f20c:	mov    0x418(%rsp),%rbx
  81f214:	mov    (%rsp),%rdi
  81f218:	lea    0x420(%rsp),%rsi
  81f220:	lea    0x450(%rsp),%rdx
  81f228:	call   81cf30 <<gpui_gpu::renderer::RendererState>::correction>
  81f22d:	mov    %eax,0xb8(%rsp)
  81f234:	test   %rbx,%rbx
  81f237:	je     81f1cd <<gpui_gpu::renderer::RendererState>::render+0x161d>
  81f239:	mov    %rbx,%rcx
  81f23c:	shl    $0x2,%rcx
  81f240:	mov    0xb8(%rsp),%eax
  81f247:	shl    $0xf,%eax
  81f24a:	mov    %eax,0xe0(%rsp)
  81f251:	mov    0x100(%rsp),%rax
  81f259:	shl    $0x4,%rax
  81f25d:	mov    %rax,0x8(%rsp)
  81f262:	lea    0x180(%rsp),%rbx
  81f26a:	jmp    81f3d5 <<gpui_gpu::renderer::RendererState>::render+0x1825>
  81f26f:	lea    0x188(%rsp),%rdi
  81f277:	mov    0x70(%rsp),%edx
  81f27b:	movzwl 0x58(%rsp),%esi
  81f280:	movlps %xmm0,0x1c0(%rsp)
  81f288:	lea    0x420(%rsp),%rax
  81f290:	movups (%rax),%xmm0
  81f293:	movups 0x10(%rax),%xmm1
  81f297:	movdqu 0x20(%rax),%xmm2
  81f29c:	movdqu %xmm2,0x20(%rbx)
  81f2a1:	movups %xmm1,0x10(%rbx)
  81f2a5:	movups %xmm0,(%rbx)
  81f2a8:	lea    0x450(%rsp),%rcx
  81f2b0:	movups (%rcx),%xmm0
  81f2b3:	movups %xmm0,0x30(%rbx)
  81f2b7:	movaps 0x310(%rsp),%xmm0
  81f2bf:	movups %xmm0,0x40(%rbx)
  81f2c3:	movups 0x40(%rax),%xmm0
  81f2c7:	movups %xmm0,0x50(%rbx)
  81f2cb:	mov    %dl,0x180(%rsp)
  81f2d2:	movzbl 0x20(%rsp),%eax
  81f2d7:	mov    %al,0x181(%rsp)
  81f2de:	mov    %si,0x182(%rsp)
  81f2e6:	movss  %xmm4,0x184(%rsp)
  81f2ef:	mov    0x370(%rsp),%rax
  81f2f7:	mov    %rax,0x10(%rdi)
  81f2fb:	movaps 0x360(%rsp),%xmm0
  81f303:	movups %xmm0,(%rdi)
  81f306:	mov    0x40(%rsp),%rax
  81f30b:	mov    %rax,0x1a0(%rsp)
  81f313:	mov    0x60(%rsp),%eax
  81f317:	mov    %eax,0x1a8(%rsp)
  81f31e:	mov    0x90(%rsp),%eax
  81f325:	mov    %eax,0x1ac(%rsp)
  81f32c:	add    $0xfffffffffffffffe,%r10
  81f330:	mov    %r10,0x100(%rsp)
  81f338:	mov    %r10d,0x330(%rsp)
  81f340:	movdqa 0x170(%rsp),%xmm0
  81f349:	movdqu %xmm0,0x1b0(%rsp)
  81f352:	mov    0x488(%rsp),%rax
  81f35a:	mov    %rax,0x3a8(%rsp)
  81f362:	mov    0xe8(%rsp),%rax
  81f36a:	mov    %rax,0x3b0(%rsp)
  81f372:	mov    0x480(%rsp),%rax
  81f37a:	mov    %rax,0x3b8(%rsp)
  81f382:	lea    0x300(%rsp),%rax
  81f38a:	mov    %rax,0x3c0(%rsp)
  81f392:	lea    0x330(%rsp),%rax
  81f39a:	mov    %rax,0x3c8(%rsp)
  81f3a2:	mov    %r9,%rdi
  81f3a5:	mov    0x80(%rsp),%rsi
  81f3ad:	lea    0x3a8(%rsp),%rdx
  81f3b5:	mov    %r9,%rbx
  81f3b8:	call   81c060 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>>
  81f3bd:	addq   $0xffffffffffffffe0,0x8(%rsp)
  81f3c3:	mov    0x88(%rsp),%rcx
  81f3cb:	add    $0xfffffffffffffffc,%rcx
  81f3cf:	je     81f1cd <<gpui_gpu::renderer::RendererState>::render+0x161d>
  81f3d5:	mov    0xc8(%rsp),%rax
  81f3dd:	mov    %rcx,0x88(%rsp)
  81f3e5:	mov    -0x4(%rax,%rcx,1),%edx
  81f3e9:	mov    %rbx,%rdi
  81f3ec:	mov    0x390(%rsp),%rsi
  81f3f4:	call   81c3c0 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81f3f9:	movzbl 0x180(%rsp),%ecx
  81f401:	movzbl 0x181(%rsp),%eax
  81f409:	mov    %al,0x20(%rsp)
  81f40d:	movzwl 0x182(%rsp),%edx
  81f415:	movss  0x184(%rsp),%xmm4
  81f41e:	lea    0x188(%rsp),%rsi
  81f426:	mov    0x10(%rsi),%rax
  81f42a:	mov    %rax,0x370(%rsp)
  81f432:	movups (%rsi),%xmm0
  81f435:	movaps %xmm0,0x360(%rsp)
  81f43d:	mov    0x1a0(%rsp),%rax
  81f445:	mov    %rax,0x40(%rsp)
  81f44a:	mov    0x1a8(%rsp),%eax
  81f451:	mov    %eax,0x60(%rsp)
  81f455:	mov    0x1ac(%rsp),%eax
  81f45c:	mov    %eax,0x90(%rsp)
  81f463:	movups 0x1b0(%rsp),%xmm0
  81f46b:	movaps %xmm0,0x170(%rsp)
  81f473:	mov    0x1b0(%rsp),%rax
  81f47b:	movsd  0x1c0(%rsp),%xmm5
  81f484:	lea    0x1c8(%rsp),%rbx
  81f48c:	movups (%rbx),%xmm0
  81f48f:	movaps %xmm0,0x310(%rsp)
  81f497:	decq   0x300(%rsp)
  81f49f:	cmp    $0x1,%ecx
  81f4a2:	mov    %ecx,0x70(%rsp)
  81f4a6:	mov    %dx,0x58(%rsp)
  81f4ab:	movaps %xmm5,0x2f0(%rsp)
  81f4b3:	je     81f53c <<gpui_gpu::renderer::RendererState>::render+0x198c>
  81f4b9:	movaps %xmm4,0x2e0(%rsp)
  81f4c1:	cmp    $0x3,%ecx
  81f4c4:	jne    81f5b9 <<gpui_gpu::renderer::RendererState>::render+0x1a09>
  81f4ca:	mov    0xd8(%rsp),%rax
  81f4d2:	mov    (%rax),%rdi
  81f4d5:	test   %rdi,%rdi
  81f4d8:	je     81ff9d <<gpui_gpu::renderer::RendererState>::render+0x23ed>
  81f4de:	movzbl 0x20(%rsp),%edx
  81f4e3:	mov    0x40(%rsp),%rsi
  81f4e8:	call   823040 <<gpui_gpu::renderer::images::Images>::metadata>
  81f4ed:	mov    %eax,%ecx
  81f4ef:	shr    $0x20,%rax
  81f4f3:	mov    %eax,%edx
  81f4f5:	or     $0x10,%edx
  81f4f8:	xorps  %xmm0,%xmm0
  81f4fb:	movaps 0x2e0(%rsp),%xmm4
  81f503:	ucomiss %xmm0,%xmm4
  81f506:	cmovne %edx,%eax
  81f509:	cmovp  %edx,%eax
  81f50c:	mov    0x90(%rsp),%edx
  81f513:	shl    $0x10,%edx
  81f516:	or     0x60(%rsp),%edx
  81f51a:	mov    %ecx,0x150(%rsp)
  81f521:	mov    %eax,0x154(%rsp)
  81f528:	mov    %edx,0x158(%rsp)
  81f52f:	lea    0x1c8(%rsp),%rbx
  81f537:	jmp    81f666 <<gpui_gpu::renderer::RendererState>::render+0x1ab6>
  81f53c:	movaps %xmm5,%xmm0
  81f53f:	movss  -0x77055b(%rip),%xmm3        # aefec <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  81f547:	mulss  %xmm3,%xmm0
  81f54b:	movaps %xmm4,%xmm1
  81f54e:	minss  %xmm0,%xmm1
  81f552:	movaps %xmm1,%xmm0
  81f555:	cmpunordss %xmm1,%xmm0
  81f55a:	movaps %xmm0,%xmm2
  81f55d:	andnps %xmm1,%xmm2
  81f560:	andps  %xmm4,%xmm0
  81f563:	orps   %xmm2,%xmm0
  81f566:	movaps %xmm5,%xmm1
  81f569:	shufps $0x55,%xmm5,%xmm1
  81f56d:	mulss  %xmm3,%xmm1
  81f571:	movaps %xmm0,%xmm2
  81f574:	minss  %xmm1,%xmm2
  81f578:	movaps %xmm2,%xmm1
  81f57b:	cmpunordss %xmm2,%xmm1
  81f580:	andps  %xmm1,%xmm0
  81f583:	andnps %xmm2,%xmm1
  81f586:	orps   %xmm0,%xmm1
  81f589:	movd   %xmm1,%eax
  81f58d:	and    $0xff800000,%eax
  81f592:	mov    $0x7f000000,%ecx
  81f597:	sub    %eax,%ecx
  81f599:	movl   $0x40000000,0x150(%rsp)
  81f5a4:	movss  %xmm1,0x154(%rsp)
  81f5ad:	mov    %ecx,0x158(%rsp)
  81f5b4:	jmp    81f666 <<gpui_gpu::renderer::RendererState>::render+0x1ab6>
  81f5b9:	cmp    $0x2,%cl
  81f5bc:	jne    81f60e <<gpui_gpu::renderer::RendererState>::render+0x1a5e>
  81f5be:	mov    0x370(%rsp),%rcx
  81f5c6:	mov    %rcx,0x190(%rsp)
  81f5ce:	movaps 0x360(%rsp),%xmm0
  81f5d6:	movaps %xmm0,0x180(%rsp)
  81f5de:	mov    0x40(%rsp),%rcx
  81f5e3:	mov    %rcx,0x198(%rsp)
  81f5eb:	mov    0x60(%rsp),%ecx
  81f5ef:	mov    %ecx,0x1a0(%rsp)
  81f5f6:	mov    0x90(%rsp),%ecx
  81f5fd:	mov    %ecx,0x1a4(%rsp)
  81f604:	mov    %rax,0x1a8(%rsp)
  81f60c:	jmp    81f61a <<gpui_gpu::renderer::RendererState>::render+0x1a6a>
  81f60e:	movq   $0x0,0x180(%rsp)
  81f61a:	movl   $0x0,0x3b0(%rsp)
  81f625:	movq   $0x0,0x3a8(%rsp)
  81f631:	lea    0x150(%rsp),%rdi
  81f639:	lea    0x180(%rsp),%rsi
  81f641:	lea    0x3a8(%rsp),%rdx
  81f649:	mov    0xd0(%rsp),%rcx
  81f651:	call   81b0e0 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>>
  81f656:	lea    0x1c8(%rsp),%rbx
  81f65e:	movaps 0x2e0(%rsp),%xmm4
  81f666:	mov    0x100(%rsp),%r10
  81f66e:	lea    -0x1(%r10),%rdi
  81f672:	mov    (%rsp),%rcx
  81f676:	mov    0x10(%rcx),%rsi
  81f67a:	cmp    %rsi,%rdi
  81f67d:	lea    0x180(%rsp),%r9
  81f685:	movaps 0x2f0(%rsp),%xmm0
  81f68d:	jae    81ffbe <<gpui_gpu::renderer::RendererState>::render+0x240e>
  81f693:	mov    0x150(%rsp),%eax
  81f69a:	cmp    $0x40000000,%eax
  81f69f:	jne    81f6bf <<gpui_gpu::renderer::RendererState>::render+0x1b0f>
  81f6a1:	mov    0x158(%rsp),%esi
  81f6a8:	or     0xb8(%rsp),%esi
  81f6af:	mov    %esi,0x158(%rsp)
  81f6b6:	mov    0x154(%rsp),%edx
  81f6bd:	jmp    81f6db <<gpui_gpu::renderer::RendererState>::render+0x1b2b>
  81f6bf:	mov    0x154(%rsp),%edx
  81f6c6:	or     0xe0(%rsp),%edx
  81f6cd:	mov    %edx,0x154(%rsp)
  81f6d4:	mov    0x158(%rsp),%esi
  81f6db:	mov    0x8(%rcx),%rcx
  81f6df:	mov    0x8(%rsp),%r11
  81f6e4:	mov    -0x4(%rcx,%r11,1),%r8d
  81f6e9:	shl    $0x20,%r8
  81f6ed:	mov    %esi,%esi
  81f6ef:	or     %r8,%rsi
  81f6f2:	shl    $0x20,%rdx
  81f6f6:	mov    %eax,%eax
  81f6f8:	or     %rdx,%rax
  81f6fb:	mov    -0x8(%rcx,%r11,1),%rdx
  81f700:	xor    %rsi,%rdx
  81f703:	mov    -0x10(%rcx,%r11,1),%r8
  81f708:	xor    %rax,%r8
  81f70b:	or     %rdx,%r8
  81f70e:	je     81f26f <<gpui_gpu::renderer::RendererState>::render+0x16bf>
  81f714:	mov    0x38(%rsp),%rdx
  81f719:	cmp    %rdx,%rdi
  81f71c:	cmovb  %rdi,%rdx
  81f720:	mov    %rdx,0x38(%rsp)
  81f725:	mov    0x30(%rsp),%rdx
  81f72a:	cmp    %rdx,%r10
  81f72d:	cmova  %r10,%rdx
  81f731:	mov    %rdx,0x30(%rsp)
  81f736:	mov    0x8(%rsp),%rdx
  81f73b:	mov    %rax,-0x10(%rcx,%rdx,1)
  81f740:	mov    %rsi,-0x8(%rcx,%rdx,1)
  81f745:	jmp    81f26f <<gpui_gpu::renderer::RendererState>::render+0x16bf>
  81f74a:	mov    (%rsp),%rax
  81f74e:	mov    0x28(%rax),%rdi
  81f752:	xor    %esi,%esi
  81f754:	test   %rdi,%rdi
  81f757:	je     81f832 <<gpui_gpu::renderer::RendererState>::render+0x1c82>
  81f75d:	mov    (%rsp),%rax
  81f761:	mov    0x20(%rax),%r8
  81f765:	shl    $0x3,%rdi
  81f769:	cmpl   $0x0,0x80(%rsp)
  81f771:	je     81ff57 <<gpui_gpu::renderer::RendererState>::render+0x23a7>
  81f777:	movq   $0x0,0x60(%rsp)
  81f780:	movq   $0x0,0x40(%rsp)
  81f789:	movq   $0x0,0x8(%rsp)
  81f792:	xor    %r9d,%r9d
  81f795:	xor    %ecx,%ecx
  81f797:	jmp    81f7bf <<gpui_gpu::renderer::RendererState>::render+0x1c0f>
  81f799:	incq   0x8(%rsp)
  81f79e:	inc    %r9
  81f7a1:	cmp    0x80(%rsp),%r9
  81f7a9:	mov    $0x0,%eax
  81f7ae:	cmove  %rax,%r9
  81f7b2:	inc    %rcx
  81f7b5:	add    $0xfffffffffffffff8,%rdi
  81f7b9:	je     81f84d <<gpui_gpu::renderer::RendererState>::render+0x1c9d>
  81f7bf:	mov    0x4(%r8,%rcx,8),%r10d
  81f7c4:	mov    %r10d,%eax
  81f7c7:	neg    %eax
  81f7c9:	jo     81f799 <<gpui_gpu::renderer::RendererState>::render+0x1be9>
  81f7cb:	sub    (%r8,%rcx,8),%r10d
  81f7cf:	je     81f79e <<gpui_gpu::renderer::RendererState>::render+0x1bee>
  81f7d1:	mov    %rcx,%rax
  81f7d4:	shr    $0x20,%rax
  81f7d8:	je     81f7ec <<gpui_gpu::renderer::RendererState>::render+0x1c3c>
  81f7da:	mov    %rcx,%rax
  81f7dd:	xor    %edx,%edx
  81f7df:	divq   0x80(%rsp)
  81f7e7:	mov    %r9,%rdx
  81f7ea:	jmp    81f7f7 <<gpui_gpu::renderer::RendererState>::render+0x1c47>
  81f7ec:	mov    %ecx,%eax
  81f7ee:	xor    %edx,%edx
  81f7f0:	divl   0x80(%rsp)
  81f7f7:	shl    $0x4,%edx
  81f7fa:	shl    $0x4,%eax
  81f7fd:	lea    0x10(%rdx),%r11d
  81f801:	cmp    %r11d,%r14d
  81f804:	cmovb  %r14d,%r11d
  81f808:	lea    0x10(%rax),%ebx
  81f80b:	cmp    %ebx,%r15d
  81f80e:	cmovb  %r15d,%ebx
  81f812:	sub    %edx,%r11d
  81f815:	sub    %eax,%ebx
  81f817:	imul   %r11d,%ebx
  81f81b:	shl    $0x4,%rbx
  81f81f:	add    %rbx,0x40(%rsp)
  81f824:	imul   %rbx,%r10
  81f828:	add    %r10,0x60(%rsp)
  81f82d:	jmp    81f79e <<gpui_gpu::renderer::RendererState>::render+0x1bee>
  81f832:	movq   $0x0,0x8(%rsp)
  81f83b:	movq   $0x0,0x40(%rsp)
  81f844:	movq   $0x0,0x60(%rsp)
  81f84d:	test   $0x1,%r13b
  81f851:	je     81f89e <<gpui_gpu::renderer::RendererState>::render+0x1cee>
  81f853:	movd   0x2ac(%rsp),%xmm0
  81f85c:	movd   %xmm0,%eax
  81f860:	test   %eax,%eax
  81f862:	setns  %cl
  81f865:	mov    %eax,%edx
  81f867:	and    $0x7fffffff,%edx
  81f86d:	add    $0xff800000,%edx
  81f873:	cmp    $0x7f000000,%edx
  81f879:	setb   %dl
  81f87c:	and    %cl,%dl
  81f87e:	dec    %eax
  81f880:	cmp    $0x7fffff,%eax
  81f885:	setb   %al
  81f888:	or     %dl,%al
  81f88a:	mov    $0x2,%esi
  81f88f:	movd   %xmm0,0xfc(%rsp)
  81f898:	je     81ff4d <<gpui_gpu::renderer::RendererState>::render+0x239d>
  81f89e:	mov    0x148(%rsp),%rax
  81f8a6:	add    $0x18,%rax
  81f8aa:	xor    %ecx,%ecx
  81f8ac:	cmpl   $0x28,0x2a8(%rsp)
  81f8b4:	sete   %cl
  81f8b7:	and    $0x1,%r12d
  81f8bb:	lea    (%r12,%rcx,4),%ecx
  81f8bf:	or     %esi,%ecx
  81f8c1:	movups (%rax),%xmm0
  81f8c4:	movups %xmm0,0x418(%rsp)
  81f8cc:	mov    %r14d,0x408(%rsp)
  81f8d4:	mov    %r15d,0x40c(%rsp)
  81f8dc:	mov    0x80(%rsp),%rax
  81f8e4:	mov    %eax,0x410(%rsp)
  81f8eb:	mov    %ecx,0x414(%rsp)
  81f8f2:	movss  0xfc(%rsp),%xmm0
  81f8fb:	movss  %xmm0,0x428(%rsp)
  81f904:	mov    0x130(%rsp),%rax
  81f90c:	mov    %eax,0x42c(%rsp)
  81f913:	movq   $0x0,0x430(%rsp)
  81f91f:	mov    (%rsp),%rax
  81f923:	lea    0x230(%rax),%rsi
  81f92a:	lea    0x408(%rsp),%rcx
  81f932:	mov    $0x30,%r8d
  81f938:	mov    0xa8(%rsp),%rdi
  81f940:	mov    %rsi,0x90(%rsp)
  81f948:	xor    %edx,%edx
  81f94a:	call   *0x660220(%rip)        # e7fb70 <_DYNAMIC+0x5d0>
  81f950:	mov    0x280(%rsp),%r12
  81f958:	shl    $0x4,%r12
  81f95c:	mov    0xb0(%rsp),%rdi
  81f964:	mov    0xc0(%rsp),%rsi
  81f96c:	mov    %r12,%rdx
  81f96f:	call   81c710 <<gpui_gpu::renderer::Buffer>::reserve>
  81f974:	test   %rbp,%rbp
  81f977:	je     81fa32 <<gpui_gpu::renderer::RendererState>::render+0x1e82>
  81f97d:	mov    0x280(%rsp),%rcx
  81f985:	cmp    %rcx,0x348(%rsp)
  81f98d:	jne    81fa32 <<gpui_gpu::renderer::RendererState>::render+0x1e82>
  81f993:	test   %al,%al
  81f995:	jne    81fa32 <<gpui_gpu::renderer::RendererState>::render+0x1e82>
  81f99b:	testb  $0x1,0x138(%rsp)
  81f9a3:	jne    81fa32 <<gpui_gpu::renderer::RendererState>::render+0x1e82>
  81f9a9:	mov    0x2a0(%rsp),%rsi
  81f9b1:	cmp    0x38(%rsp),%rsi
  81f9b6:	jne    81f9d7 <<gpui_gpu::renderer::RendererState>::render+0x1e27>
  81f9b8:	mov    0x30(%rsp),%rsi
  81f9bd:	mov    %rsi,0x2a0(%rsp)
  81f9c5:	movq   $0xffffffffffffffff,0x38(%rsp)
  81f9ce:	movq   $0x0,0x30(%rsp)
  81f9d7:	mov    (%rsp),%r12
  81f9db:	mov    0x8(%r12),%rdx
  81f9e0:	mov    0x10(%r12),%rcx
  81f9e5:	mov    0x298(%rsp),%rdi
  81f9ed:	mov    0xb0(%rsp),%rbx
  81f9f5:	mov    %rbx,%r8
  81f9f8:	mov    0xa8(%rsp),%rbp
  81fa00:	mov    %rbp,%r9
  81fa03:	call   81c660 <<gpui_gpu::renderer::Changes>::upload>
  81fa08:	mov    %rax,%r13
  81fa0b:	mov    0x8(%r12),%rdx
  81fa10:	mov    0x10(%r12),%rcx
  81fa15:	mov    0x38(%rsp),%rdi
  81fa1a:	mov    0x30(%rsp),%rsi
  81fa1f:	mov    %rbx,%r8
  81fa22:	mov    %rbp,%r9
  81fa25:	call   81c660 <<gpui_gpu::renderer::Changes>::upload>
  81fa2a:	mov    %rax,%r12
  81fa2d:	add    %r13,%r12
  81fa30:	jmp    81fa5f <<gpui_gpu::renderer::RendererState>::render+0x1eaf>
  81fa32:	mov    (%rsp),%rax
  81fa36:	mov    0x8(%rax),%rcx
  81fa3a:	mov    0x10(%rax),%r8
  81fa3e:	shl    $0x4,%r8
  81fa42:	mov    0xb0(%rsp),%rdi
  81fa4a:	mov    0xc0(%rsp),%rsi
  81fa52:	mov    0xa8(%rsp),%rdx
  81fa5a:	call   81c6c0 <<gpui_gpu::renderer::Buffer>::write>
  81fa5f:	mov    0xc0(%rsp),%r13
  81fa67:	lea    0x18(%r13),%rax
  81fa6b:	mov    %rax,0x20(%rsp)
  81fa70:	mov    (%rsp),%rbp
  81fa74:	lea    0x280(%rbp),%rdi
  81fa7b:	mov    0x20(%rbp),%rcx
  81fa7f:	mov    0x28(%rbp),%r8
  81fa83:	shl    $0x3,%r8
  81fa87:	mov    %rdi,0x100(%rsp)
  81fa8f:	mov    %r13,%rsi
  81fa92:	mov    0xa8(%rsp),%rbx
  81fa9a:	mov    %rbx,%rdx
  81fa9d:	call   81c6c0 <<gpui_gpu::renderer::Buffer>::write>
  81faa2:	lea    0x2a8(%rbp),%rdi
  81faa9:	mov    0x38(%rbp),%rcx
  81faad:	mov    0x40(%rbp),%r8
  81fab1:	shl    $0x2,%r8
  81fab5:	mov    %rdi,0x2f0(%rsp)
  81fabd:	mov    %r13,%rsi
  81fac0:	mov    %rbx,%rdx
  81fac3:	call   81c6c0 <<gpui_gpu::renderer::Buffer>::write>
  81fac8:	lea    0x2d0(%rbp),%rdi
  81facf:	mov    0x68(%rbp),%rcx
  81fad3:	mov    0x70(%rbp),%r8
  81fad7:	shl    $0x5,%r8
  81fadb:	mov    %rdi,0x88(%rsp)
  81fae3:	mov    %r13,%rsi
  81fae6:	mov    %rbx,%rdx
  81fae9:	call   81c6c0 <<gpui_gpu::renderer::Buffer>::write>
  81faee:	cmpq   $0x0,0x328(%rbp)
  81faf6:	je     81fafc <<gpui_gpu::renderer::RendererState>::render+0x1f4c>
  81faf8:	xor    %eax,%eax
  81fafa:	jmp    81fb10 <<gpui_gpu::renderer::RendererState>::render+0x1f60>
  81fafc:	mov    (%rsp),%rax
  81fb00:	mov    0x10(%rax),%rax
  81fb04:	cmp    $0x1,%rax
  81fb08:	adc    $0x0,%rax
  81fb0c:	shl    $0x4,%rax
  81fb10:	mov    (%rsp),%rdi
  81fb14:	mov    0x28(%rdi),%rsi
  81fb18:	mov    0x40(%rdi),%rcx
  81fb1c:	cmp    $0x1,%rsi
  81fb20:	adc    $0x0,%rsi
  81fb24:	shl    $0x3,%rsi
  81fb28:	cmp    $0x1,%rcx
  81fb2c:	adc    $0x0,%rcx
  81fb30:	mov    0x70(%rdi),%rdx
  81fb34:	cmp    $0x1,%rdx
  81fb38:	adc    $0x0,%rdx
  81fb3c:	add    $0xc8,%rdi
  81fb43:	shl    $0x2,%rcx
  81fb47:	shl    $0x5,%rdx
  81fb4b:	movq   $0x0,0x180(%rsp)
  81fb57:	mov    0x90(%rsp),%r8
  81fb5f:	mov    %r8,0x188(%rsp)
  81fb67:	movq   $0x0,0x1a8(%rsp)
  81fb73:	xorpd  %xmm0,%xmm0
  81fb77:	movupd %xmm0,0x190(%rsp)
  81fb80:	movl   $0x0,0x1a0(%rsp)
  81fb8b:	mov    0xb0(%rsp),%r8
  81fb93:	mov    %r8,0x1b0(%rsp)
  81fb9b:	movq   $0x0,0x1b8(%rsp)
  81fba7:	mov    %rax,0x1c0(%rsp)
  81fbaf:	movl   $0x1,0x1c8(%rsp)
  81fbba:	movq   $0x0,0x1d0(%rsp)
  81fbc6:	mov    0x100(%rsp),%rax
  81fbce:	mov    %rax,0x1d8(%rsp)
  81fbd6:	movq   $0x0,0x1e0(%rsp)
  81fbe2:	mov    %rsi,0x1e8(%rsp)
  81fbea:	movl   $0x2,0x1f0(%rsp)
  81fbf5:	movq   $0x0,0x1f8(%rsp)
  81fc01:	mov    0x2f0(%rsp),%rax
  81fc09:	mov    %rax,0x200(%rsp)
  81fc11:	movq   $0x0,0x208(%rsp)
  81fc1d:	mov    %rcx,0x210(%rsp)
  81fc25:	movl   $0x3,0x218(%rsp)
  81fc30:	movq   $0x4,0x220(%rsp)
  81fc3c:	mov    %rdi,0x228(%rsp)
  81fc44:	movl   $0x4,0x240(%rsp)
  81fc4f:	movq   $0x0,0x248(%rsp)
  81fc5b:	mov    0x88(%rsp),%rax
  81fc63:	mov    %rax,0x250(%rsp)
  81fc6b:	movq   $0x0,0x258(%rsp)
  81fc77:	mov    %rdx,0x260(%rsp)
  81fc7f:	movl   $0x5,0x268(%rsp)
  81fc8a:	lea    -0x74b4c9(%rip),%rax        # d47c8 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x122>
  81fc91:	mov    %rax,0x3c0(%rsp)
  81fc99:	movq   $0xa,0x3c8(%rsp)
  81fca5:	mov    0x20(%rsp),%rax
  81fcaa:	mov    %rax,0x3a8(%rsp)
  81fcb2:	lea    0x180(%rsp),%rax
  81fcba:	mov    %rax,0x3b0(%rsp)
  81fcc2:	movq   $0x6,0x3b8(%rsp)
  81fcce:	lea    0x3a8(%rsp),%rsi
  81fcd6:	mov    0xc0(%rsp),%r13
  81fcde:	mov    %r13,%rdi
  81fce1:	call   *0x65fe91(%rip)        # e7fb78 <_DYNAMIC+0x5d8>
  81fce7:	mov    %rax,%rbp
  81fcea:	mov    %rax,0x2b0(%rsp)
  81fcf2:	lea    0x2b0(%rsp),%rdx
  81fcfa:	mov    %r13,%rdi
  81fcfd:	mov    0x478(%rsp),%rsi
  81fd05:	call   81cd50 <<gpui_gpu::renderer::GpuContext>::submit>
  81fd0a:	mov    %rax,0x90(%rsp)
  81fd12:	xor    %r13d,%r13d
  81fd15:	mov    0x350(%rsp),%rax
  81fd1d:	cmp    0x358(%rsp),%rax
  81fd25:	setne  %r13b
  81fd29:	shl    $0x1f,%r13d
  81fd2d:	or     %r14d,%r13d
  81fd30:	shl    $0x20,%r15
  81fd34:	or     %r15,%r13
  81fd37:	mov    0xf0(%rsp),%rax
  81fd3f:	mov    (%rax),%rax
  81fd42:	test   %rax,%rax
  81fd45:	je     81fd5b <<gpui_gpu::renderer::RendererState>::render+0x21ab>
  81fd47:	lock decq (%rax)
  81fd4b:	jne    81fd5b <<gpui_gpu::renderer::RendererState>::render+0x21ab>
  81fd4d:	mov    0xf0(%rsp),%rdi
  81fd55:	call   *0x65fd5d(%rip)        # e7fab8 <_DYNAMIC+0x518>
  81fd5b:	mov    (%rsp),%rax
  81fd5f:	mov    %rbp,0x330(%rax)
  81fd66:	mov    %r13,0x338(%rax)
  81fd6d:	mov    0x28(%rax),%rsi
  81fd71:	mov    0x70(%rax),%rcx
  81fd75:	mov    %rcx,0xf0(%rsp)
  81fd7d:	mov    0x278(%rax),%rdx
  81fd84:	mov    0x10(%rsp),%r8
  81fd89:	lea    (%r12,%r8,4),%rdi
  81fd8d:	lea    (%rdi,%rsi,8),%rsi
  81fd91:	mov    %rcx,%rdi
  81fd94:	shl    $0x5,%rdi
  81fd98:	lea    (%rdi,%rsi,1),%rcx
  81fd9c:	add    $0x30,%rcx
  81fda0:	mov    %rcx,0x20(%rsp)
  81fda5:	mov    0x150(%rax),%esi
  81fdab:	imul   %rsi,%rsi
  81fdaf:	add    0x250(%rax),%rdx
  81fdb6:	add    0x2a0(%rax),%rdx
  81fdbd:	add    0x2c8(%rax),%rdx
  81fdc4:	add    0x2f0(%rax),%rdx
  81fdcb:	mov    0x308(%rax),%rdi
  81fdd2:	add    0x310(%rax),%rdi
  81fdd9:	mov    0x140(%rsp),%r11
  81fde1:	mov    %r11,%rcx
  81fde4:	sub    %r8,%rcx
  81fde7:	mov    0x78(%rsp),%rbp
  81fdec:	mov    %rbp,%r9
  81fdef:	mov    0x278(%rsp),%r13
  81fdf7:	sub    %r13,%r9
  81fdfa:	mov    0x10(%rax),%r10
  81fdfe:	shl    $0x4,%r10
  81fe02:	mov    0x160(%rax),%rbx
  81fe09:	inc    %rbx
  81fe0c:	mov    $0xffffffffffffffff,%r14
  81fe13:	cmovne %rbx,%r14
  81fe17:	mov    (%rax),%rbx
  81fe1a:	shl    $0x4,%rbx
  81fe1e:	mov    0x48(%rax),%r15
  81fe22:	add    0x30(%rax),%r15
  81fe26:	mov    0x18(%rax),%r12
  81fe2a:	lea    (%rbx,%r12,8),%rbx
  81fe2e:	lea    (%rbx,%r15,4),%rbx
  81fe32:	mov    0x60(%rax),%r15
  81fe36:	shl    $0x5,%r15
  81fe3a:	add    %rbx,%r15
  81fe3d:	mov    0x138(%rax),%rbx
  81fe44:	mov    0x130(%rax),%r12
  81fe4b:	mov    %r14,0x160(%rax)
  81fe52:	mov    %rbp,0x168(%rax)
  81fe59:	lea    (%r11,%r11,1),%r14
  81fe5d:	mov    %r14,0x170(%rax)
  81fe64:	movq   $0x1,0x178(%rax)
  81fe6f:	mov    %rbp,0x180(%rax)
  81fe76:	mov    %r8,0x188(%rax)
  81fe7d:	mov    %r11,0x190(%rax)
  81fe84:	mov    %rcx,0x198(%rax)
  81fe8b:	mov    0x8(%rsp),%rcx
  81fe90:	mov    %rcx,0x1a0(%rax)
  81fe97:	mov    0x40(%rsp),%rcx
  81fe9c:	mov    %rcx,0x1a8(%rax)
  81fea3:	mov    0x60(%rsp),%rcx
  81fea8:	mov    %rcx,0x1b0(%rax)
  81feaf:	mov    0x20(%rsp),%rcx
  81feb4:	mov    %rcx,0x1b8(%rax)
  81febb:	mov    %r10,0x1c0(%rax)
  81fec2:	mov    0x270(%rsp),%r8
  81feca:	mov    %r8,0x1c8(%rax)
  81fed1:	mov    %r13,0x1d0(%rax)
  81fed8:	mov    %r9,0x1d8(%rax)
  81fedf:	mov    0x290(%rsp),%rcx
  81fee7:	mov    %rcx,0x1e0(%rax)
  81feee:	mov    %rdx,0x1e8(%rax)
  81fef5:	mov    %rsi,0x1f0(%rax)
  81fefc:	add    %rbx,%r12
  81feff:	mov    %rbx,0x1f8(%rax)
  81ff06:	mov    %r12,0x200(%rax)
  81ff0d:	mov    %r15,0x208(%rax)
  81ff14:	mov    0xf0(%rsp),%rcx
  81ff1c:	mov    %rcx,0x210(%rax)
  81ff23:	mov    %rdi,0x218(%rax)
  81ff2a:	movb   $0x0,0x220(%rax)
  81ff31:	mov    0x28(%rsp),%rdi
  81ff36:	mov    0x90(%rsp),%rax
  81ff3e:	mov    %rax,0x8(%rdi)
  81ff42:	movl   $0xffffffff,(%rdi)
  81ff48:	jmp    81dd5f <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81ff4d:	mov    0x28(%rsp),%rdi
  81ff52:	jmp    81dd51 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81ff57:	movq   $0x0,0x40(%rsp)
  81ff60:	xor    %eax,%eax
  81ff62:	movq   $0x0,0x8(%rsp)
  81ff6b:	jmp    81ff7f <<gpui_gpu::renderer::RendererState>::render+0x23cf>
  81ff6d:	incq   0x8(%rsp)
  81ff72:	add    $0x8,%rax
  81ff76:	cmp    %rax,%rdi
  81ff79:	je     81f844 <<gpui_gpu::renderer::RendererState>::render+0x1c94>
  81ff7f:	mov    0x4(%r8,%rax,1),%ecx
  81ff84:	mov    %ecx,%edx
  81ff86:	neg    %edx
  81ff88:	jo     81ff6d <<gpui_gpu::renderer::RendererState>::render+0x23bd>
  81ff8a:	cmp    %ecx,(%r8,%rax,1)
  81ff8e:	je     81ff72 <<gpui_gpu::renderer::RendererState>::render+0x23c2>
  81ff90:	lea    0x60e2a1(%rip),%rdi        # e2e238 <anon.36d49f465d299f05a84fba3771e6457e.32.llvm.1466513483089798867+0x10>
  81ff97:	call   *0x65fbe3(%rip)        # e7fb80 <_DYNAMIC+0x5e0>
  81ff9d:	lea    0x60e09c(%rip),%rdi        # e2e040 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.1466513483089798867+0x18>
  81ffa4:	call   *0x65fbde(%rip)        # e7fb88 <_DYNAMIC+0x5e8>
  81ffaa:	lea    0x60e0ef(%rip),%rcx        # e2e0a0 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.1466513483089798867+0x78>
  81ffb1:	xor    %edi,%edi
  81ffb3:	mov    0x10(%rsp),%rsi
  81ffb8:	call   *0x65fb2a(%rip)        # e7fae8 <_DYNAMIC+0x548>
  81ffbe:	lea    0x60e093(%rip),%rdx        # e2e058 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.1466513483089798867+0x30>
  81ffc5:	call   *0x65facd(%rip)        # e7fa98 <_DYNAMIC+0x4f8>
  81ffcb:	lea    0x60e0b6(%rip),%rdx        # e2e088 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.1466513483089798867+0x60>
  81ffd2:	call   *0x65fac0(%rip)        # e7fa98 <_DYNAMIC+0x4f8>
  81ffd8:	lea    0x60e049(%rip),%rdx        # e2e028 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.1466513483089798867>
  81ffdf:	mov    0x8(%rsp),%rdi
  81ffe4:	call   *0x65faae(%rip)        # e7fa98 <_DYNAMIC+0x4f8>
  81ffea:	lea    0x60e07f(%rip),%rdx        # e2e070 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.1466513483089798867+0x48>
  81fff1:	call   *0x65faa1(%rip)        # e7fa98 <_DYNAMIC+0x4f8>
  81fff7:	mov    %rax,%r14
  81fffa:	mov    (%rsp),%rax
  81fffe:	mov    %rbp,0x330(%rax)
  820005:	mov    %r13,0x338(%rax)
  82000c:	mov    %r14,%rdi
  82000f:	call   e2c310 <_Unwind_Resume@plt>
  820014:	mov    %rax,%r14
  820017:	lock decq 0x0(%rbp)
  82001c:	jne    820046 <<gpui_gpu::renderer::RendererState>::render+0x2496>
  82001e:	lea    0x2b0(%rsp),%rdi
  820026:	call   *0x65fa8c(%rip)        # e7fab8 <_DYNAMIC+0x518>
  82002c:	jmp    820046 <<gpui_gpu::renderer::RendererState>::render+0x2496>
  82002e:	call   *0x65f7bc(%rip)        # e7f7f0 <_DYNAMIC+0x250>
  820034:	mov    %rax,%r14
  820037:	mov    0xf0(%rsp),%rax
  82003f:	movq   $0x0,(%rax)
  820046:	mov    %r14,%rdi
  820049:	call   e2c310 <_Unwind_Resume@plt>

/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000820050 <<gpui_gpu::renderer::RendererState>::bin_draw>:
  820050:	push   %rbp
  820051:	push   %r15
  820053:	push   %r14
  820055:	push   %r13
  820057:	push   %r12
  820059:	push   %rbx
  82005a:	sub    $0x308,%rsp
  820061:	movss  0x88(%rdx),%xmm3
  820069:	movss  -0x771035(%rip),%xmm0        # af03c <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  820071:	movaps %xmm3,%xmm1
  820074:	subss  %xmm0,%xmm1
  820078:	cvttss2si %xmm1,%rax
  82007d:	cvttss2si %xmm3,%r10
  820082:	mov    %r10,%r12
  820085:	sar    $0x3f,%r12
  820089:	and    %rax,%r12
  82008c:	or     %r10,%r12
  82008f:	xor    %eax,%eax
  820091:	xorps  %xmm1,%xmm1
  820094:	ucomiss %xmm1,%xmm3
  820097:	cmovb  %rax,%r12
  82009b:	movss  0x90(%rdx),%xmm4
  8200a3:	movss  -0x77106b(%rip),%xmm2        # af040 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  8200ab:	ucomiss %xmm2,%xmm3
  8200ae:	mov    $0xffffffffffffffff,%r10
  8200b5:	cmova  %r10,%r12
  8200b9:	movaps %xmm4,%xmm3
  8200bc:	subss  %xmm0,%xmm3
  8200c0:	cvttss2si %xmm3,%r11
  8200c5:	cvttss2si %xmm4,%rbx
  8200ca:	mov    %rbx,%r14
  8200cd:	sar    $0x3f,%r14
  8200d1:	and    %r11,%r14
  8200d4:	or     %rbx,%r14
  8200d7:	ucomiss %xmm1,%xmm4
  8200da:	cmovb  %rax,%r14
  8200de:	ucomiss %xmm2,%xmm4
  8200e1:	cmova  %r10,%r14
  8200e5:	movss  0x8c(%rdx),%xmm3
  8200ed:	lea    (%r12,%r14,1),%rbx
  8200f1:	dec    %rbx
  8200f4:	shr    $0x4,%rbx
  8200f8:	shr    $0x4,%r12
  8200fc:	mov    %rbx,%rbp
  8200ff:	sub    %r12,%rbp
  820102:	inc    %rbp
  820105:	movaps %xmm3,%xmm4
  820108:	subss  %xmm0,%xmm4
  82010c:	cvttss2si %xmm4,%r15
  820111:	cvttss2si %xmm3,%r11
  820116:	mov    %r11,%r14
  820119:	sar    $0x3f,%r14
  82011d:	and    %r15,%r14
  820120:	or     %r11,%r14
  820123:	ucomiss %xmm1,%xmm3
  820126:	cmovb  %rax,%r14
  82012a:	ucomiss %xmm2,%xmm3
  82012d:	movss  0x94(%rdx),%xmm3
  820135:	cmova  %r10,%r14
  820139:	movaps %xmm3,%xmm4
  82013c:	subss  %xmm0,%xmm4
  820140:	cvttss2si %xmm4,%r13
  820145:	cvttss2si %xmm3,%r11
  82014a:	mov    %r11,%r15
  82014d:	sar    $0x3f,%r15
  820151:	and    %r13,%r15
  820154:	or     %r11,%r15
  820157:	ucomiss %xmm1,%xmm3
  82015a:	cmovb  %rax,%r15
  82015e:	ucomiss %xmm2,%xmm3
  820161:	cmova  %r10,%r15
  820165:	lea    (%r14,%r15,1),%r10
  820169:	dec    %r10
  82016c:	shr    $0x4,%r10
  820170:	shr    $0x4,%r14
  820174:	mov    %r10,%r11
  820177:	sub    %r14,%r11
  82017a:	inc    %r11
  82017d:	imul   %rbp,%r11
  820181:	add    0x358(%rsp),%r11
  820189:	setb   %al
  82018c:	cmp    $0x400001,%r11
  820193:	setae  %bpl
  820197:	or     %al,%bpl
  82019a:	mov    $0x6,%eax
  82019f:	jne    8201df <<gpui_gpu::renderer::RendererState>::bin_draw+0x18f>
  8201a1:	mov    %r8d,0xac(%rsp)
  8201a9:	mov    %r9,0x98(%rsp)
  8201b1:	mov    %r11,0x190(%rsp)
  8201b9:	mov    %rdi,0x198(%rsp)
  8201c1:	cmp    %r14,%r10
  8201c4:	jae    8201f3 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1a3>
  8201c6:	mov    0x198(%rsp),%rdi
  8201ce:	mov    0x190(%rsp),%rax
  8201d6:	mov    %rax,0x8(%rdi)
  8201da:	mov    $0xffffffff,%eax
  8201df:	mov    %eax,(%rdi)
  8201e1:	add    $0x308,%rsp
  8201e8:	pop    %rbx
  8201e9:	pop    %r12
  8201eb:	pop    %r13
  8201ed:	pop    %r14
  8201ef:	pop    %r15
  8201f1:	pop    %rbp
  8201f2:	ret
  8201f3:	mov    %r12,%r9
  8201f6:	cmp    %r12,%rbx
  8201f9:	jae    820216 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1c6>
  8201fb:	nopl   0x0(%rax,%rax,1)
  820200:	mov    %r14,%rax
  820203:	cmp    %r10,%r14
  820206:	adc    $0x0,%r14
  82020a:	cmp    %r10,%rax
  82020d:	jae    8201c6 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  82020f:	cmp    %r10,%r14
  820212:	jbe    820200 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1b0>
  820214:	jmp    8201c6 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  820216:	mov    0x340(%rsp),%r13
  82021e:	movd   0xa4(%rdx),%xmm0
  820226:	mov    0x20(%rsi),%rbp
  82022a:	movdqu 0x98(%rdx),%xmm1
  820232:	movd   0xa0(%rdx),%xmm2
  82023a:	punpckldq %xmm0,%xmm2
  82023e:	punpcklqdq %xmm2,%xmm1
  820242:	movdqa -0x7738ba(%rip),%xmm2        # ac990 <anon.fd4379edd0b71335c3c29b3337cd5ea0.320.llvm.353578272256937679+0x110>
  82024a:	pand   %xmm1,%xmm2
  82024e:	paddd  -0x773666(%rip),%xmm2        # acbf0 <anon.fd4379edd0b71335c3c29b3337cd5ea0.320.llvm.353578272256937679+0x370>
  820256:	pxor   -0x771eae(%rip),%xmm2        # ae3b0 <anon.630a3fff68f6bca64b568be97512ab45.101.llvm.826976926275214120+0x80>
  82025e:	pcmpgtd -0x772a56(%rip),%xmm2        # ad810 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x420>
  820266:	mov    %rsi,%rax
  820269:	mov    0x28(%rsi),%rsi
  82026d:	pandn  %xmm1,%xmm2
  820271:	movmskps %xmm2,%edi
  820274:	test   %edi,%edi
  820276:	mov    %r10,0xb8(%rsp)
  82027e:	jne    820ffc <<gpui_gpu::renderer::RendererState>::bin_draw+0xfac>
  820284:	ucomiss -0x77148b(%rip),%xmm0        # aee00 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  82028b:	jne    820ffc <<gpui_gpu::renderer::RendererState>::bin_draw+0xfac>
  820291:	jp     820ffc <<gpui_gpu::renderer::RendererState>::bin_draw+0xfac>
  820297:	cmpb   $0x0,0x340(%rax)
  82029e:	je     820ffc <<gpui_gpu::renderer::RendererState>::bin_draw+0xfac>
  8202a4:	cmpb   $0x0,(%rdx)
  8202a7:	jne    820ffc <<gpui_gpu::renderer::RendererState>::bin_draw+0xfac>
  8202ad:	test   %r13,%r13
  8202b0:	je     821073 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1023>
  8202b6:	mov    0x350(%rsp),%r12d
  8202be:	mov    0x348(%rsp),%r8d
  8202c6:	movd   %ecx,%xmm2
  8202ca:	shr    $0x20,%rcx
  8202ce:	movss  0x78(%rdx),%xmm0
  8202d3:	movss  0x80(%rdx),%xmm3
  8202db:	cvtss2sd %xmm0,%xmm0
  8202df:	movss  0x7c(%rdx),%xmm1
  8202e4:	cvtss2sd %xmm1,%xmm1
  8202e8:	cvtss2sd %xmm3,%xmm13
  8202ed:	movss  0x84(%rdx),%xmm3
  8202f5:	addsd  %xmm0,%xmm13
  8202fa:	cvtss2sd %xmm3,%xmm3
  8202fe:	addsd  %xmm1,%xmm3
  820302:	movsd  %xmm3,0x1c8(%rsp)
  82030b:	movsd  0x48(%rdx),%xmm6
  820310:	movsd  0x58(%rdx),%xmm7
  820315:	movss  0x38(%rdx),%xmm3
  82031a:	movss  0x3c(%rdx),%xmm4
  82031f:	movss  0x40(%rdx),%xmm5
  820324:	cvtss2sd %xmm3,%xmm8
  820329:	movss  0x44(%rdx),%xmm3
  82032e:	cvtss2sd %xmm5,%xmm5
  820332:	movaps -0x77550a(%rip),%xmm9        # aae30 <GCC_except_table0+0xa0>
  82033a:	movaps %xmm8,0x80(%rsp)
  820343:	andps  %xmm9,%xmm8
  820347:	movaps %xmm8,0x70(%rsp)
  82034d:	movaps %xmm5,0x50(%rsp)
  820352:	andps  %xmm9,%xmm5
  820356:	movaps %xmm5,0x60(%rsp)
  82035b:	cvtss2sd %xmm2,%xmm2
  82035f:	movsd  %xmm2,0x8(%rsp)
  820365:	movaps %xmm6,%xmm2
  820368:	andps  %xmm9,%xmm2
  82036c:	movaps %xmm2,0x270(%rsp)
  820374:	movaps %xmm7,%xmm2
  820377:	andps  %xmm9,%xmm2
  82037b:	movaps %xmm2,0x250(%rsp)
  820383:	xorps  %xmm2,%xmm2
  820386:	cvtss2sd %xmm4,%xmm2
  82038a:	cvtss2sd %xmm3,%xmm3
  82038e:	movsd  0x68(%rdx),%xmm4
  820393:	movaps %xmm4,%xmm5
  820396:	andps  %xmm9,%xmm5
  82039a:	movaps %xmm5,0x100(%rsp)
  8203a2:	movaps %xmm2,0x40(%rsp)
  8203a7:	andps  %xmm9,%xmm2
  8203ab:	movaps %xmm2,0x30(%rsp)
  8203b0:	movaps %xmm3,0x10(%rsp)
  8203b5:	andps  %xmm9,%xmm3
  8203b9:	movaps %xmm3,0x20(%rsp)
  8203be:	movd   %ecx,%xmm2
  8203c2:	cvtss2sd %xmm2,%xmm2
  8203c6:	movsd  %xmm2,(%rsp)
  8203cb:	movsd  0x50(%rdx),%xmm2
  8203d0:	movaps %xmm2,%xmm3
  8203d3:	andps  %xmm9,%xmm3
  8203d7:	movaps %xmm3,0x1f0(%rsp)
  8203df:	movsd  0x60(%rdx),%xmm3
  8203e4:	movaps %xmm3,%xmm5
  8203e7:	andps  %xmm9,%xmm5
  8203eb:	movaps %xmm5,0x1d0(%rsp)
  8203f3:	movsd  0x70(%rdx),%xmm5
  8203f8:	movaps %xmm5,%xmm8
  8203fc:	andps  %xmm9,%xmm8
  820400:	movaps %xmm8,0xc0(%rsp)
  820409:	mov    0x58(%rax),%rcx
  82040d:	mov    %rcx,0xb0(%rsp)
  820415:	mov    0x50(%rax),%rax
  820419:	mov    %rax,0x168(%rsp)
  820421:	mov    0x98(%rsp),%rax
  820429:	inc    %eax
  82042b:	mov    %rax,0x98(%rsp)
  820433:	movaps %xmm2,0x200(%rsp)
  82043b:	cvtsd2ss %xmm2,%xmm2
  82043f:	xorps  %xmm8,%xmm8
  820443:	cvtss2sd %xmm2,%xmm8
  820448:	movaps %xmm6,0x280(%rsp)
  820450:	movaps %xmm6,%xmm2
  820453:	movaps %xmm7,0x260(%rsp)
  82045b:	movlhps %xmm7,%xmm2
  82045e:	cvtpd2ps %xmm2,%xmm2
  820462:	cvtps2pd %xmm2,%xmm6
  820465:	movaps %xmm3,0x1e0(%rsp)
  82046d:	xorps  %xmm2,%xmm2
  820470:	cvtsd2ss %xmm3,%xmm2
  820474:	xorps  %xmm3,%xmm3
  820477:	cvtss2sd %xmm2,%xmm3
  82047b:	movaps %xmm4,0x110(%rsp)
  820483:	xorps  %xmm2,%xmm2
  820486:	cvtsd2ss %xmm4,%xmm2
  82048a:	xorps  %xmm4,%xmm4
  82048d:	cvtss2sd %xmm2,%xmm4
  820491:	movaps %xmm5,0xd0(%rsp)
  820499:	xorps  %xmm2,%xmm2
  82049c:	cvtsd2ss %xmm5,%xmm2
  8204a0:	cvtss2sd %xmm2,%xmm2
  8204a4:	movaps %xmm6,%xmm5
  8204a7:	andps  %xmm9,%xmm5
  8204ab:	movaps %xmm4,0x130(%rsp)
  8204b3:	andps  %xmm9,%xmm4
  8204b7:	movaps %xmm4,0x120(%rsp)
  8204bf:	movaps %xmm8,0x240(%rsp)
  8204c8:	andps  %xmm9,%xmm8
  8204cc:	movaps %xmm8,0x230(%rsp)
  8204d5:	movaps %xmm3,0x220(%rsp)
  8204dd:	andps  %xmm9,%xmm3
  8204e1:	movaps %xmm3,0x210(%rsp)
  8204e9:	movaps %xmm2,0xe0(%rsp)
  8204f1:	andps  %xmm2,%xmm9
  8204f5:	movaps %xmm9,0xf0(%rsp)
  8204fe:	movaps %xmm6,0x2a0(%rsp)
  820506:	movhlps %xmm6,%xmm6
  820509:	movaps %xmm6,0x2d0(%rsp)
  820511:	movaps %xmm5,0x290(%rsp)
  820519:	movhlps %xmm5,%xmm5
  82051c:	movaps %xmm5,0x2c0(%rsp)
  820524:	mov    %r9,0x1b8(%rsp)
  82052c:	movsd  %xmm13,0xa0(%rsp)
  820536:	cs nopw 0x0(%rax,%rax,1)
  820540:	mov    %r14,%rcx
  820543:	cmp    %r10,%r14
  820546:	adc    $0x0,%r14
  82054a:	mov    %rcx,0x1c0(%rsp)
  820552:	imul   %r13,%rcx
  820556:	mov    %r9,%rdi
  820559:	nopl   0x0(%rax)
  820560:	cmp    %rbx,%rdi
  820563:	adc    $0x0,%r9
  820567:	lea    (%rdi,%rcx,1),%r10
  82056b:	mov    %r10,%rax
  82056e:	shr    $0x20,%rax
  820572:	je     820580 <<gpui_gpu::renderer::RendererState>::bin_draw+0x530>
  820574:	mov    %r10,%rax
  820577:	xor    %edx,%edx
  820579:	div    %r13
  82057c:	jmp    820588 <<gpui_gpu::renderer::RendererState>::bin_draw+0x538>
  82057e:	xchg   %ax,%ax
  820580:	mov    %r10d,%eax
  820583:	xor    %edx,%edx
  820585:	div    %r13d
  820588:	shl    $0x4,%edx
  82058b:	shl    $0x4,%eax
  82058e:	lea    0x10(%rdx),%r11d
  820592:	cmp    %r11d,%r8d
  820595:	cmovb  %r8d,%r11d
  820599:	lea    0x10(%rax),%r15d
  82059d:	cmp    %r15d,%r12d
  8205a0:	cmovb  %r12d,%r15d
  8205a4:	xorps  %xmm11,%xmm11
  8205a8:	cvtsi2sd %edx,%xmm11
  8205ad:	ucomisd %xmm11,%xmm0
  8205b2:	ja     8205f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  8205b4:	mov    %eax,%eax
  8205b6:	xorps  %xmm2,%xmm2
  8205b9:	cvtsi2sd %rax,%xmm2
  8205be:	ucomisd %xmm2,%xmm1
  8205c2:	ja     8205f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  8205c4:	xorps  %xmm15,%xmm15
  8205c8:	cvtsi2sd %r11d,%xmm15
  8205cd:	ucomisd %xmm13,%xmm15
  8205d2:	ja     8205f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  8205d4:	xorps  %xmm14,%xmm14
  8205d8:	cvtsi2sd %r15d,%xmm14
  8205dd:	ucomisd 0x1c8(%rsp),%xmm14
  8205e7:	jbe    820618 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5c8>
  8205e9:	nopl   0x0(%rax)
  8205f0:	cmp    %rsi,%r10
  8205f3:	jae    821063 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1013>
  8205f9:	incl   0x4(%rbp,%r10,8)
  8205fe:	cmp    %rbx,%rdi
  820601:	jae    820fd0 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf80>
  820607:	mov    %r9,%rdi
  82060a:	cmp    %rbx,%r9
  82060d:	jbe    820560 <<gpui_gpu::renderer::RendererState>::bin_draw+0x510>
  820613:	jmp    820fd0 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf80>
  820618:	unpcklpd %xmm2,%xmm11
  82061d:	addpd  -0x7734d6(%rip),%xmm11        # ad150 <anon.a16d5d421a76dfd8c37a17b53540311d.58.llvm.14190004212411149437+0x270>
  820626:	movapd %xmm11,%xmm9
  82062b:	mulpd  0x2a0(%rsp),%xmm9
  820635:	movapd %xmm9,%xmm12
  82063a:	unpckhpd %xmm9,%xmm12
  82063f:	movapd %xmm9,%xmm2
  820644:	addsd  %xmm12,%xmm2
  820649:	addsd  0x130(%rsp),%xmm2
  820652:	subsd  0x80(%rsp),%xmm2
  82065b:	movapd 0x290(%rsp),%xmm7
  820664:	mulpd  %xmm11,%xmm7
  820669:	movapd %xmm7,%xmm8
  82066e:	unpckhpd %xmm7,%xmm8
  820673:	movapd %xmm7,%xmm3
  820677:	addsd  %xmm8,%xmm3
  82067c:	addsd  0x120(%rsp),%xmm3
  820685:	addsd  0x70(%rsp),%xmm3
  82068b:	addsd  0x60(%rsp),%xmm3
  820691:	addsd  -0x770da1(%rip),%xmm3        # af8f8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820699:	mulsd  -0x770e21(%rip),%xmm3        # af880 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  8206a1:	addsd  0x8(%rsp),%xmm3
  8206a7:	ucomisd %xmm2,%xmm3
  8206ab:	jae    8205f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  8206b1:	movapd 0x50(%rsp),%xmm4
  8206b7:	subsd  %xmm2,%xmm4
  8206bb:	ucomisd %xmm4,%xmm3
  8206bf:	jae    8205f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  8206c5:	movapd %xmm11,%xmm6
  8206ca:	unpckhpd %xmm11,%xmm6
  8206cf:	movapd 0x260(%rsp),%xmm10
  8206d9:	mulsd  %xmm6,%xmm10
  8206de:	movapd 0x250(%rsp),%xmm3
  8206e7:	mulsd  %xmm6,%xmm3
  8206eb:	movapd 0x280(%rsp),%xmm2
  8206f4:	mulsd  %xmm11,%xmm2
  8206f9:	movapd %xmm2,0x150(%rsp)
  820702:	addsd  %xmm10,%xmm2
  820707:	addsd  0x110(%rsp),%xmm2
  820710:	subsd  0x80(%rsp),%xmm2
  820719:	movapd 0x270(%rsp),%xmm4
  820722:	mulsd  %xmm11,%xmm4
  820727:	movsd  %xmm4,0x1b0(%rsp)
  820730:	addsd  %xmm3,%xmm4
  820734:	addsd  0x100(%rsp),%xmm4
  82073d:	addsd  0x70(%rsp),%xmm4
  820743:	addsd  0x60(%rsp),%xmm4
  820749:	addsd  -0x770e59(%rip),%xmm4        # af8f8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820751:	mulsd  -0x770901(%rip),%xmm4        # afe58 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820759:	ucomisd %xmm2,%xmm4
  82075d:	jae    8205f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820763:	movapd 0x50(%rsp),%xmm5
  820769:	subsd  %xmm2,%xmm5
  82076d:	ucomisd %xmm5,%xmm4
  820771:	jae    8205f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820777:	movapd %xmm6,%xmm4
  82077b:	mulsd  0x220(%rsp),%xmm4
  820784:	movapd %xmm6,%xmm2
  820788:	mulsd  0x210(%rsp),%xmm2
  820791:	movapd %xmm11,%xmm5
  820796:	mulsd  0x240(%rsp),%xmm5
  82079f:	movsd  %xmm5,0x1a8(%rsp)
  8207a8:	movapd %xmm4,0x140(%rsp)
  8207b1:	addsd  %xmm4,%xmm5
  8207b5:	addsd  0xe0(%rsp),%xmm5
  8207be:	subsd  0x40(%rsp),%xmm5
  8207c4:	movapd %xmm11,%xmm4
  8207c9:	mulsd  0x230(%rsp),%xmm4
  8207d2:	movsd  %xmm4,0x1a0(%rsp)
  8207db:	addsd  %xmm2,%xmm4
  8207df:	addsd  0xf0(%rsp),%xmm4
  8207e8:	addsd  0x30(%rsp),%xmm4
  8207ee:	addsd  0x20(%rsp),%xmm4
  8207f4:	addsd  -0x770f04(%rip),%xmm4        # af8f8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8207fc:	mulsd  -0x770f84(%rip),%xmm4        # af880 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820804:	addsd  (%rsp),%xmm4
  820809:	ucomisd %xmm5,%xmm4
  82080d:	jae    8205f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820813:	movapd 0x10(%rsp),%xmm13
  82081a:	subsd  %xmm5,%xmm13
  82081f:	ucomisd %xmm13,%xmm4
  820824:	movsd  0xa0(%rsp),%xmm13
  82082e:	jae    8205f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820834:	movapd 0x1e0(%rsp),%xmm4
  82083d:	mulsd  %xmm6,%xmm4
  820841:	mulsd  0x1d0(%rsp),%xmm6
  82084a:	movapd 0x200(%rsp),%xmm5
  820853:	mulsd  %xmm11,%xmm5
  820858:	movapd %xmm5,0x2e0(%rsp)
  820861:	movapd %xmm4,0x2f0(%rsp)
  82086a:	addsd  %xmm4,%xmm5
  82086e:	addsd  0xd0(%rsp),%xmm5
  820877:	subsd  0x40(%rsp),%xmm5
  82087d:	mulsd  0x1f0(%rsp),%xmm11
  820887:	movapd %xmm11,%xmm4
  82088c:	addsd  %xmm6,%xmm4
  820890:	addsd  0xc0(%rsp),%xmm4
  820899:	addsd  0x30(%rsp),%xmm4
  82089f:	addsd  0x20(%rsp),%xmm4
  8208a5:	addsd  -0x770fb5(%rip),%xmm4        # af8f8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8208ad:	mulsd  -0x770a5d(%rip),%xmm4        # afe58 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  8208b5:	ucomisd %xmm5,%xmm4
  8208b9:	jae    8205f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  8208bf:	movapd 0x10(%rsp),%xmm13
  8208c6:	subsd  %xmm5,%xmm13
  8208cb:	ucomisd %xmm13,%xmm4
  8208d0:	movsd  0xa0(%rsp),%xmm13
  8208da:	jae    8205f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  8208e0:	addsd  -0x7712e1(%rip),%xmm15        # af608 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  8208e9:	movapd %xmm15,%xmm4
  8208ee:	mulsd  0x2a0(%rsp),%xmm4
  8208f7:	movsd  %xmm4,0x188(%rsp)
  820900:	addsd  %xmm4,%xmm12
  820905:	addsd  0x130(%rsp),%xmm12
  82090f:	subsd  0x80(%rsp),%xmm12
  820919:	movapd 0x290(%rsp),%xmm4
  820922:	mulsd  %xmm15,%xmm4
  820927:	movsd  %xmm4,0x180(%rsp)
  820930:	addsd  %xmm4,%xmm8
  820935:	addsd  0x120(%rsp),%xmm8
  82093f:	addsd  0x70(%rsp),%xmm8
  820946:	addsd  0x60(%rsp),%xmm8
  82094d:	addsd  -0x77105e(%rip),%xmm8        # af8f8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820956:	mulsd  -0x7710df(%rip),%xmm8        # af880 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  82095f:	addsd  0x8(%rsp),%xmm8
  820966:	ucomisd %xmm12,%xmm8
  82096b:	jae    8205f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820971:	movapd 0x50(%rsp),%xmm4
  820977:	subsd  %xmm12,%xmm4
  82097c:	ucomisd %xmm4,%xmm8
  820981:	jae    8205f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820987:	movapd 0x280(%rsp),%xmm12
  820991:	mulsd  %xmm15,%xmm12
  820996:	addsd  %xmm12,%xmm10
  82099b:	addsd  0x110(%rsp),%xmm10
  8209a5:	subsd  0x80(%rsp),%xmm10
  8209af:	movapd 0x270(%rsp),%xmm4
  8209b8:	mulsd  %xmm15,%xmm4
  8209bd:	movsd  %xmm4,0x178(%rsp)
  8209c6:	addsd  %xmm4,%xmm3
  8209ca:	addsd  0x100(%rsp),%xmm3
  8209d3:	addsd  0x70(%rsp),%xmm3
  8209d9:	addsd  0x60(%rsp),%xmm3
  8209df:	addsd  -0x7710ef(%rip),%xmm3        # af8f8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8209e7:	mulsd  -0x770b97(%rip),%xmm3        # afe58 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  8209ef:	ucomisd %xmm10,%xmm3
  8209f4:	jae    8205f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  8209fa:	movapd 0x50(%rsp),%xmm4
  820a00:	subsd  %xmm10,%xmm4
  820a05:	ucomisd %xmm4,%xmm3
  820a09:	jae    8205f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820a0f:	movapd %xmm15,%xmm3
  820a14:	mulsd  0x240(%rsp),%xmm3
  820a1d:	movsd  %xmm3,0x170(%rsp)
  820a26:	movapd 0x140(%rsp),%xmm5
  820a2f:	addsd  %xmm3,%xmm5
  820a33:	addsd  0xe0(%rsp),%xmm5
  820a3c:	subsd  0x40(%rsp),%xmm5
  820a42:	movapd %xmm15,%xmm3
  820a47:	mulsd  0x230(%rsp),%xmm3
  820a50:	movsd  %xmm3,0x140(%rsp)
  820a59:	addsd  %xmm3,%xmm2
  820a5d:	addsd  0xf0(%rsp),%xmm2
  820a66:	addsd  0x30(%rsp),%xmm2
  820a6c:	addsd  0x20(%rsp),%xmm2
  820a72:	addsd  -0x771182(%rip),%xmm2        # af8f8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820a7a:	mulsd  -0x771202(%rip),%xmm2        # af880 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820a82:	addsd  (%rsp),%xmm2
  820a87:	ucomisd %xmm5,%xmm2
  820a8b:	jae    8205f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820a91:	movapd 0x10(%rsp),%xmm3
  820a97:	subsd  %xmm5,%xmm3
  820a9b:	ucomisd %xmm3,%xmm2
  820a9f:	jae    8205f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820aa5:	movapd 0x200(%rsp),%xmm2
  820aae:	mulsd  %xmm15,%xmm2
  820ab3:	movapd %xmm2,0x2b0(%rsp)
  820abc:	movapd 0x2f0(%rsp),%xmm4
  820ac5:	addsd  %xmm2,%xmm4
  820ac9:	addsd  0xd0(%rsp),%xmm4
  820ad2:	subsd  0x40(%rsp),%xmm4
  820ad8:	mulsd  0x1f0(%rsp),%xmm15
  820ae2:	addsd  %xmm15,%xmm6
  820ae7:	addsd  0xc0(%rsp),%xmm6
  820af0:	addsd  0x30(%rsp),%xmm6
  820af6:	addsd  0x20(%rsp),%xmm6
  820afc:	addsd  -0x77120c(%rip),%xmm6        # af8f8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820b04:	mulsd  -0x770cb4(%rip),%xmm6        # afe58 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820b0c:	ucomisd %xmm4,%xmm6
  820b10:	jae    8205f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820b16:	movapd 0x10(%rsp),%xmm2
  820b1c:	subsd  %xmm4,%xmm2
  820b20:	ucomisd %xmm2,%xmm6
  820b24:	jae    8205f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820b2a:	addsd  -0x77152b(%rip),%xmm14        # af608 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  820b33:	movapd %xmm14,%xmm3
  820b38:	mulsd  0x2d0(%rsp),%xmm3
  820b41:	movapd %xmm14,%xmm2
  820b46:	mulsd  0x2c0(%rsp),%xmm2
  820b4f:	addsd  %xmm3,%xmm9
  820b54:	addsd  0x130(%rsp),%xmm9
  820b5e:	subsd  0x80(%rsp),%xmm9
  820b68:	addsd  %xmm2,%xmm7
  820b6c:	addsd  0x120(%rsp),%xmm7
  820b75:	addsd  0x70(%rsp),%xmm7
  820b7b:	addsd  0x60(%rsp),%xmm7
  820b81:	addsd  -0x771291(%rip),%xmm7        # af8f8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820b89:	mulsd  -0x771311(%rip),%xmm7        # af880 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820b91:	addsd  0x8(%rsp),%xmm7
  820b97:	ucomisd %xmm9,%xmm7
  820b9c:	jae    8205f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820ba2:	movapd 0x50(%rsp),%xmm4
  820ba8:	subsd  %xmm9,%xmm4
  820bad:	ucomisd %xmm4,%xmm7
  820bb1:	jae    8205f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820bb7:	movapd 0x260(%rsp),%xmm6
  820bc0:	mulsd  %xmm14,%xmm6
  820bc5:	movapd 0x250(%rsp),%xmm5
  820bce:	mulsd  %xmm14,%xmm5
  820bd3:	movapd 0x150(%rsp),%xmm4
  820bdc:	addsd  %xmm6,%xmm4
  820be0:	addsd  0x110(%rsp),%xmm4
  820be9:	subsd  0x80(%rsp),%xmm4
  820bf2:	movsd  0x1b0(%rsp),%xmm9
  820bfc:	addsd  %xmm5,%xmm9
  820c01:	addsd  0x100(%rsp),%xmm9
  820c0b:	addsd  0x70(%rsp),%xmm9
  820c12:	addsd  0x60(%rsp),%xmm9
  820c19:	addsd  -0x77132a(%rip),%xmm9        # af8f8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820c22:	mulsd  -0x770dd3(%rip),%xmm9        # afe58 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820c2b:	ucomisd %xmm4,%xmm9
  820c30:	jae    8205f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820c36:	movapd %xmm4,%xmm7
  820c3a:	movapd 0x50(%rsp),%xmm4
  820c40:	subsd  %xmm7,%xmm4
  820c44:	ucomisd %xmm4,%xmm9
  820c49:	jae    8205f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820c4f:	movapd %xmm14,%xmm7
  820c54:	mulsd  0x220(%rsp),%xmm7
  820c5d:	movapd %xmm14,%xmm9
  820c62:	mulsd  0x210(%rsp),%xmm9
  820c6c:	movsd  0x1a8(%rsp),%xmm8
  820c76:	addsd  %xmm7,%xmm8
  820c7b:	addsd  0xe0(%rsp),%xmm8
  820c85:	subsd  0x40(%rsp),%xmm8
  820c8c:	movapd %xmm12,%xmm4
  820c91:	movsd  0x1a0(%rsp),%xmm12
  820c9b:	movsd  %xmm9,0x150(%rsp)
  820ca5:	addsd  %xmm9,%xmm12
  820caa:	addsd  0xf0(%rsp),%xmm12
  820cb4:	addsd  0x30(%rsp),%xmm12
  820cbb:	addsd  0x20(%rsp),%xmm12
  820cc2:	addsd  -0x7713d3(%rip),%xmm12        # af8f8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820ccb:	mulsd  -0x771454(%rip),%xmm12        # af880 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820cd4:	addsd  (%rsp),%xmm12
  820cda:	ucomisd %xmm8,%xmm12
  820cdf:	jae    8205f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820ce5:	movapd %xmm8,%xmm9
  820cea:	movapd 0x10(%rsp),%xmm8
  820cf1:	subsd  %xmm9,%xmm8
  820cf6:	ucomisd %xmm8,%xmm12
  820cfb:	jae    8205f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820d01:	movapd 0x1e0(%rsp),%xmm8
  820d0b:	mulsd  %xmm14,%xmm8
  820d10:	mulsd  0x1d0(%rsp),%xmm14
  820d1a:	movapd 0x2e0(%rsp),%xmm9
  820d24:	addsd  %xmm8,%xmm9
  820d29:	addsd  0xd0(%rsp),%xmm9
  820d33:	subsd  0x40(%rsp),%xmm9
  820d3a:	addsd  %xmm14,%xmm11
  820d3f:	addsd  0xc0(%rsp),%xmm11
  820d49:	addsd  0x30(%rsp),%xmm11
  820d50:	addsd  0x20(%rsp),%xmm11
  820d57:	addsd  -0x771468(%rip),%xmm11        # af8f8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820d60:	mulsd  -0x770f11(%rip),%xmm11        # afe58 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820d69:	ucomisd %xmm9,%xmm11
  820d6e:	jae    8205f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820d74:	movapd %xmm9,%xmm10
  820d79:	movapd 0x10(%rsp),%xmm9
  820d80:	subsd  %xmm10,%xmm9
  820d85:	ucomisd %xmm9,%xmm11
  820d8a:	jae    8205f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820d90:	movsd  0x188(%rsp),%xmm9
  820d9a:	addsd  %xmm3,%xmm9
  820d9f:	addsd  0x130(%rsp),%xmm9
  820da9:	subsd  0x80(%rsp),%xmm9
  820db3:	movsd  0x180(%rsp),%xmm10
  820dbd:	addsd  %xmm2,%xmm10
  820dc2:	addsd  0x120(%rsp),%xmm10
  820dcc:	addsd  0x70(%rsp),%xmm10
  820dd3:	addsd  0x60(%rsp),%xmm10
  820dda:	addsd  -0x7714eb(%rip),%xmm10        # af8f8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820de3:	mulsd  -0x77156c(%rip),%xmm10        # af880 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820dec:	addsd  0x8(%rsp),%xmm10
  820df3:	ucomisd %xmm9,%xmm10
  820df8:	jae    8205f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820dfe:	movapd %xmm4,%xmm12
  820e03:	movapd 0x50(%rsp),%xmm2
  820e09:	subsd  %xmm9,%xmm2
  820e0e:	ucomisd %xmm2,%xmm10
  820e13:	jae    8205f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820e19:	addsd  %xmm6,%xmm12
  820e1e:	addsd  0x110(%rsp),%xmm12
  820e28:	subsd  0x80(%rsp),%xmm12
  820e32:	movsd  0x178(%rsp),%xmm2
  820e3b:	addsd  %xmm5,%xmm2
  820e3f:	addsd  0x100(%rsp),%xmm2
  820e48:	addsd  0x70(%rsp),%xmm2
  820e4e:	addsd  0x60(%rsp),%xmm2
  820e54:	addsd  -0x771564(%rip),%xmm2        # af8f8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820e5c:	mulsd  -0x77100c(%rip),%xmm2        # afe58 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820e64:	ucomisd %xmm12,%xmm2
  820e69:	jae    8205f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820e6f:	movapd %xmm2,%xmm3
  820e73:	movapd 0x50(%rsp),%xmm2
  820e79:	subsd  %xmm12,%xmm2
  820e7e:	ucomisd %xmm2,%xmm3
  820e82:	jae    8205f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820e88:	movsd  0x170(%rsp),%xmm2
  820e91:	addsd  %xmm7,%xmm2
  820e95:	addsd  0xe0(%rsp),%xmm2
  820e9e:	subsd  0x40(%rsp),%xmm2
  820ea4:	movsd  0x140(%rsp),%xmm5
  820ead:	addsd  0x150(%rsp),%xmm5
  820eb6:	addsd  0xf0(%rsp),%xmm5
  820ebf:	addsd  0x30(%rsp),%xmm5
  820ec5:	addsd  0x20(%rsp),%xmm5
  820ecb:	addsd  -0x7715db(%rip),%xmm5        # af8f8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820ed3:	mulsd  -0x77165b(%rip),%xmm5        # af880 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820edb:	addsd  (%rsp),%xmm5
  820ee0:	ucomisd %xmm2,%xmm5
  820ee4:	jae    8205f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820eea:	movapd %xmm2,%xmm3
  820eee:	movapd 0x10(%rsp),%xmm2
  820ef4:	subsd  %xmm3,%xmm2
  820ef8:	ucomisd %xmm2,%xmm5
  820efc:	jae    8205f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820f02:	movapd 0x2b0(%rsp),%xmm2
  820f0b:	addsd  %xmm8,%xmm2
  820f10:	addsd  0xd0(%rsp),%xmm2
  820f19:	subsd  0x40(%rsp),%xmm2
  820f1f:	addsd  %xmm14,%xmm15
  820f24:	addsd  0xc0(%rsp),%xmm15
  820f2e:	addsd  0x30(%rsp),%xmm15
  820f35:	addsd  0x20(%rsp),%xmm15
  820f3c:	addsd  -0x77164d(%rip),%xmm15        # af8f8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820f45:	mulsd  -0x7710f6(%rip),%xmm15        # afe58 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820f4e:	ucomisd %xmm2,%xmm15
  820f53:	jae    8205f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820f59:	movapd %xmm2,%xmm3
  820f5d:	movapd 0x10(%rsp),%xmm2
  820f63:	subsd  %xmm3,%xmm2
  820f67:	ucomisd %xmm2,%xmm15
  820f6c:	jae    8205f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820f72:	cmp    %rsi,%r10
  820f75:	jae    821080 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1030>
  820f7b:	mov    0xac(%rsp),%eax
  820f82:	mov    %eax,0x0(%rbp,%r10,8)
  820f87:	movl   $0x1,0x4(%rbp,%r10,8)
  820f90:	cmp    0xb0(%rsp),%r10
  820f98:	jae    821090 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1040>
  820f9e:	mov    0x98(%rsp),%rax
  820fa6:	mov    0x168(%rsp),%rdx
  820fae:	mov    %eax,(%rdx,%r10,4)
  820fb2:	movsd  0xa0(%rsp),%xmm13
  820fbc:	cmp    %rbx,%rdi
  820fbf:	jb     820607 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5b7>
  820fc5:	data16 cs nopw 0x0(%rax,%rax,1)
  820fd0:	mov    0xb8(%rsp),%r10
  820fd8:	cmp    %r10,0x1c0(%rsp)
  820fe0:	mov    0x1b8(%rsp),%r9
  820fe8:	jae    8201c6 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  820fee:	cmp    %r10,%r14
  820ff1:	jbe    820540 <<gpui_gpu::renderer::RendererState>::bin_draw+0x4f0>
  820ff7:	jmp    8201c6 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  820ffc:	mov    %r14,%rax
  820fff:	nop
  821000:	cmp    %r10,%r14
  821003:	adc    $0x0,%rax
  821007:	mov    %r14,%rcx
  82100a:	imul   %r13,%rcx
  82100e:	mov    %r9,%rdx
  821011:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  821020:	lea    (%rdx,%rcx,1),%r10
  821024:	cmp    %rsi,%r10
  821027:	jae    821063 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1013>
  821029:	cmp    %rbx,%rdx
  82102c:	mov    %rdx,%rdi
  82102f:	adc    $0x0,%rdi
  821033:	incl   0x4(%rbp,%r10,8)
  821038:	cmp    %rbx,%rdx
  82103b:	jae    821045 <<gpui_gpu::renderer::RendererState>::bin_draw+0xff5>
  82103d:	mov    %rdi,%rdx
  821040:	cmp    %rbx,%rdi
  821043:	jbe    821020 <<gpui_gpu::renderer::RendererState>::bin_draw+0xfd0>
  821045:	mov    0xb8(%rsp),%r10
  82104d:	cmp    %r10,%r14
  821050:	jae    8201c6 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  821056:	mov    %rax,%r14
  821059:	cmp    %r10,%rax
  82105c:	jbe    821000 <<gpui_gpu::renderer::RendererState>::bin_draw+0xfb0>
  82105e:	jmp    8201c6 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  821063:	lea    0x60d0ae(%rip),%rdx        # e2e118 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.1466513483089798867+0xf0>
  82106a:	mov    %r10,%rdi
  82106d:	call   *0x65ea25(%rip)        # e7fa98 <_DYNAMIC+0x4f8>
  821073:	lea    0x60d1be(%rip),%rdi        # e2e238 <anon.36d49f465d299f05a84fba3771e6457e.32.llvm.1466513483089798867+0x10>
  82107a:	call   *0x65eb00(%rip)        # e7fb80 <_DYNAMIC+0x5e0>
  821080:	lea    0x60d0a9(%rip),%rdx        # e2e130 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.1466513483089798867+0x108>
  821087:	mov    %r10,%rdi
  82108a:	call   *0x65ea08(%rip)        # e7fa98 <_DYNAMIC+0x4f8>
  821090:	lea    0x60d0b1(%rip),%rdx        # e2e148 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.1466513483089798867+0x120>
  821097:	mov    %r10,%rdi
  82109a:	mov    0xb0(%rsp),%rsi
  8210a2:	call   *0x65e9f0(%rip)        # e7fa98 <_DYNAMIC+0x4f8>

/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008210b0 <gpui_gpu::renderer::compact_group>:
  8210b0:	xor    %eax,%eax
  8210b2:	test   %esi,%esi
  8210b4:	je     8210f3 <gpui_gpu::renderer::compact_group+0x43>
  8210b6:	cmpq   $0x2,0x10(%rdi)
  8210bb:	jb     8210f3 <gpui_gpu::renderer::compact_group+0x43>
  8210bd:	sub    $0x58,%rsp
  8210c1:	mov    (%rdi),%rsi
  8210c4:	mov    0x8(%rdi),%rax
  8210c8:	mov    (%rax),%edx
  8210ca:	mov    %rsp,%rdi
  8210cd:	call   81c3c0 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  8210d2:	movss  0x4(%rsp),%xmm0
  8210d8:	cmpb   $0x3,(%rsp)
  8210dc:	setne  %cl
  8210df:	xorps  %xmm1,%xmm1
  8210e2:	ucomiss %xmm1,%xmm0
  8210e5:	setnp  %dl
  8210e8:	sete   %al
  8210eb:	and    %dl,%al
  8210ed:	or     %cl,%al
  8210ef:	add    $0x58,%rsp
  8210f3:	ret

/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000821100 <gpui_gpu::renderer::validate_draw>:
  821100:	push   %rbp
  821101:	push   %r15
  821103:	push   %r14
  821105:	push   %r12
  821107:	push   %rbx
  821108:	sub    $0x80,%rsp
  82110f:	mov    %r8d,%ebp
  821112:	mov    %ecx,%r12d
  821115:	mov    %rdx,%r14
  821118:	mov    %rsi,%r15
  82111b:	mov    %rdi,%rbx
  82111e:	movups 0x88(%rsi),%xmm0
  821125:	movaps %xmm0,0x20(%rsp)
  82112a:	movaps %xmm0,0x70(%rsp)
  82112f:	lea    0x70(%rsp),%rdi
  821134:	call   *0x65ead6(%rip)        # e7fc10 <_DYNAMIC+0x670>
  82113a:	movaps 0x20(%rsp),%xmm4
  82113f:	test   %al,%al
  821141:	je     821197 <gpui_gpu::renderer::validate_draw+0x97>
  821143:	movaps %xmm4,%xmm0
  821146:	unpckhpd %xmm4,%xmm0
  82114a:	xorps  %xmm2,%xmm2
  82114d:	ucomiss %xmm2,%xmm0
  821150:	jne    821154 <gpui_gpu::renderer::validate_draw+0x54>
  821152:	jnp    821197 <gpui_gpu::renderer::validate_draw+0x97>
  821154:	movaps %xmm4,%xmm1
  821157:	shufps $0xff,%xmm4,%xmm1
  82115b:	ucomiss %xmm2,%xmm1
  82115e:	jne    821162 <gpui_gpu::renderer::validate_draw+0x62>
  821160:	jnp    821197 <gpui_gpu::renderer::validate_draw+0x97>
  821162:	xorps  %xmm3,%xmm3
  821165:	ucomiss %xmm4,%xmm3
  821168:	ja     821197 <gpui_gpu::renderer::validate_draw+0x97>
  82116a:	movaps %xmm4,%xmm2
  82116d:	shufps $0x55,%xmm4,%xmm2
  821171:	ucomiss %xmm2,%xmm3
  821174:	ja     821197 <gpui_gpu::renderer::validate_draw+0x97>
  821176:	xorps  %xmm3,%xmm3
  821179:	cvtsi2ss %r12d,%xmm3
  82117e:	addss  %xmm4,%xmm0
  821182:	ucomiss %xmm3,%xmm0
  821185:	ja     821197 <gpui_gpu::renderer::validate_draw+0x97>
  821187:	xorps  %xmm0,%xmm0
  82118a:	cvtsi2ss %ebp,%xmm0
  82118e:	addss  %xmm1,%xmm2
  821192:	ucomiss %xmm0,%xmm2
  821195:	jbe    8211ad <gpui_gpu::renderer::validate_draw+0xad>
  821197:	movl   $0x3,(%rbx)
  82119d:	add    $0x80,%rsp
  8211a4:	pop    %rbx
  8211a5:	pop    %r12
  8211a7:	pop    %r14
  8211a9:	pop    %r15
  8211ab:	pop    %rbp
  8211ac:	ret
  8211ad:	movsd  0x48(%r15),%xmm9
  8211b3:	movsd  0x60(%r15),%xmm1
  8211b9:	movupd 0x50(%r15),%xmm2
  8211bf:	movapd %xmm2,%xmm5
  8211c3:	shufpd $0x1,%xmm2,%xmm5
  8211c8:	movupd 0x68(%r15),%xmm0
  8211ce:	cvtpd2ps %xmm5,%xmm8
  8211d3:	movapd %xmm9,%xmm4
  8211d8:	unpcklpd %xmm1,%xmm4
  8211dc:	cvtpd2ps %xmm4,%xmm7
  8211e0:	cvtpd2ps %xmm0,%xmm6
  8211e4:	movapd %xmm6,%xmm3
  8211e8:	shufps $0x55,%xmm6,%xmm3
  8211ec:	movd   %xmm3,%ecx
  8211f0:	movd   %xmm6,%eax
  8211f4:	movapd %xmm7,%xmm3
  8211f8:	shufps $0x14,%xmm8,%xmm3
  8211fd:	shufps $0x78,%xmm3,%xmm3
  821201:	andps  -0x773a08(%rip),%xmm3        # ad800 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  821208:	and    $0x7fffffff,%eax
  82120d:	cmp    $0x7f800000,%eax
  821212:	setge  %al
  821215:	and    $0x7fffffff,%ecx
  82121b:	cmp    $0x7f800000,%ecx
  821221:	setge  %cl
  821224:	pcmpgtd -0x775afc(%rip),%xmm3        # ab730 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x70>
  82122c:	movmskps %xmm3,%edx
  82122f:	test   %edx,%edx
  821231:	jne    821282 <gpui_gpu::renderer::validate_draw+0x182>
  821233:	test   %al,%al
  821235:	jne    821282 <gpui_gpu::renderer::validate_draw+0x182>
  821237:	test   %cl,%cl
  821239:	jne    821282 <gpui_gpu::renderer::validate_draw+0x182>
  82123b:	movapd %xmm9,%xmm3
  821240:	mulsd  %xmm1,%xmm3
  821244:	movapd %xmm2,%xmm10
  821249:	mulsd  %xmm5,%xmm10
  82124e:	subsd  %xmm10,%xmm3
  821253:	xorpd  %xmm10,%xmm10
  821258:	ucomisd %xmm10,%xmm3
  82125d:	jne    821261 <gpui_gpu::renderer::validate_draw+0x161>
  82125f:	jnp    821282 <gpui_gpu::renderer::validate_draw+0x182>
  821261:	movq   %xmm3,%rcx
  821266:	movabs $0x7fffffffffffffff,%rax
  821270:	and    %rax,%rcx
  821273:	movabs $0x7ff0000000000000,%rdx
  82127d:	cmp    %rdx,%rcx
  821280:	jl     821291 <gpui_gpu::renderer::validate_draw+0x191>
  821282:	movl   $0x5,(%rbx)
  821288:	mov    %r14,0x8(%rbx)
  82128c:	jmp    82119d <gpui_gpu::renderer::validate_draw+0x9d>
  821291:	xorps  %xmm10,%xmm10
  821295:	cvtsi2sd %r12d,%xmm10
  82129a:	cvtsi2sd %ebp,%xmm12
  82129f:	movsd  %xmm9,%xmm2
  8212a4:	movapd -0x77647d(%rip),%xmm13        # aae30 <GCC_except_table0+0xa0>
  8212ad:	andpd  %xmm13,%xmm2
  8212b2:	movapd %xmm10,%xmm11
  8212b7:	unpcklpd %xmm12,%xmm11
  8212bc:	movapd %xmm2,%xmm9
  8212c1:	movapd %xmm11,0x50(%rsp)
  8212c8:	mulpd  %xmm11,%xmm9
  8212cd:	movapd %xmm9,%xmm11
  8212d2:	unpckhpd %xmm9,%xmm11
  8212d7:	addsd  %xmm9,%xmm11
  8212dc:	movapd %xmm0,%xmm9
  8212e1:	andpd  %xmm13,%xmm9
  8212e6:	addsd  %xmm11,%xmm9
  8212eb:	shufpd $0x2,%xmm5,%xmm1
  8212f0:	andpd  %xmm13,%xmm1
  8212f5:	unpcklpd %xmm10,%xmm12
  8212fa:	movapd %xmm1,%xmm10
  8212ff:	movapd %xmm12,0x40(%rsp)
  821306:	mulpd  %xmm12,%xmm10
  82130b:	movapd %xmm10,%xmm11
  821310:	unpckhpd %xmm10,%xmm11
  821315:	addsd  %xmm9,%xmm11
  82131a:	addsd  %xmm10,%xmm11
  82131f:	movapd %xmm0,%xmm10
  821324:	unpckhpd %xmm0,%xmm10
  821329:	andpd  %xmm13,%xmm10
  82132e:	addsd  %xmm11,%xmm10
  821333:	movsd  0x38(%r15),%xmm9
  821339:	movsd  0x40(%r15),%xmm12
  82133f:	andps  -0x773b47(%rip),%xmm9        # ad800 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  821347:	cvtps2pd %xmm9,%xmm15
  82134b:	movapd %xmm10,%xmm9
  821350:	addsd  %xmm15,%xmm9
  821355:	movapd %xmm15,0x60(%rsp)
  82135c:	unpckhpd %xmm15,%xmm15
  821361:	addsd  %xmm15,%xmm9
  821366:	cvtps2pd %xmm12,%xmm11
  82136a:	movapd %xmm11,0x20(%rsp)
  821371:	andpd  %xmm13,%xmm11
  821376:	addsd  %xmm11,%xmm9
  82137b:	pshufd $0xee,%xmm11,%xmm14
  821381:	movdqa %xmm14,0x30(%rsp)
  821388:	addsd  %xmm14,%xmm9
  82138d:	movq   %xmm9,%rsi
  821392:	and    %rax,%rsi
  821395:	movabs $0x7fefffffffffffff,%rcx
  82139f:	cmp    %rcx,%rsi
  8213a2:	jg     821282 <gpui_gpu::renderer::validate_draw+0x182>
  8213a8:	ucomisd -0x771d19(%rip),%xmm9        # af698 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  8213b1:	ja     821282 <gpui_gpu::renderer::validate_draw+0x182>
  8213b7:	movzbl (%r15),%esi
  8213bb:	cmp    $0x3,%esi
  8213be:	je     8213d6 <gpui_gpu::renderer::validate_draw+0x2d6>
  8213c0:	xorpd  %xmm14,%xmm14
  8213c5:	cmp    $0x1,%esi
  8213c8:	jne    821502 <gpui_gpu::renderer::validate_draw+0x402>
  8213ce:	movss  0x4(%r15),%xmm14
  8213d4:	jmp    8213ed <gpui_gpu::renderer::validate_draw+0x2ed>
  8213d6:	movss  0x4(%r15),%xmm14
  8213dc:	xorpd  %xmm13,%xmm13
  8213e1:	ucomiss %xmm13,%xmm14
  8213e5:	jne    8213ed <gpui_gpu::renderer::validate_draw+0x2ed>
  8213e7:	jnp    821627 <gpui_gpu::renderer::validate_draw+0x527>
  8213ed:	movd   %xmm14,%edi
  8213f2:	test   %edi,%edi
  8213f4:	sets   %r8b
  8213f8:	and    $0x7fffffff,%edi
  8213fe:	lea    -0x800000(%rdi),%r9d
  821405:	cmp    $0x7f000000,%r9d
  82140c:	setb   %r9b
  821410:	and    %r8b,%r9b
  821413:	lea    -0x1(%rdi),%r10d
  821417:	cmp    $0x7fffff,%r10d
  82141e:	setb   %r10b
  821422:	and    %r8b,%r10b
  821425:	cmp    $0x7f800000,%edi
  82142b:	sete   %dil
  82142f:	setg   %r8b
  821433:	or     %dil,%r8b
  821436:	or     %r10b,%r8b
  821439:	or     %r9b,%r8b
  82143c:	cmp    $0x1,%r8b
  821440:	je     821197 <gpui_gpu::renderer::validate_draw+0x97>
  821446:	movaps %xmm11,(%rsp)
  82144b:	movaps %xmm14,%xmm11
  82144f:	movaps %xmm14,0x10(%rsp)
  821455:	movaps %xmm12,%xmm14
  821459:	mulss  -0x772476(%rip),%xmm14        # aefec <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  821462:	minss  %xmm14,%xmm11
  821467:	movaps %xmm11,%xmm14
  82146b:	cmpunordss %xmm11,%xmm14
  821471:	movaps %xmm14,%xmm13
  821475:	andnps %xmm11,%xmm13
  821479:	andps  0x10(%rsp),%xmm14
  82147f:	orps   %xmm13,%xmm14
  821483:	shufps $0x55,%xmm12,%xmm12
  821488:	mulss  -0x7724a5(%rip),%xmm12        # aefec <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  821491:	movaps %xmm14,%xmm11
  821495:	minss  %xmm12,%xmm11
  82149a:	movaps %xmm11,%xmm12
  82149e:	cmpunordss %xmm11,%xmm12
  8214a4:	andps  %xmm12,%xmm14
  8214a8:	andnps %xmm11,%xmm12
  8214ac:	orps   %xmm14,%xmm12
  8214b0:	movss  -0x7721e9(%rip),%xmm11        # af2d0 <anon.4109cdd7ddb1990ee57d5626700ecb68.286.llvm.4479275319843201559+0xc>
  8214b9:	ucomiss %xmm12,%xmm11
  8214bd:	ja     821282 <gpui_gpu::renderer::validate_draw+0x182>
  8214c3:	xorps  %xmm14,%xmm14
  8214c7:	cvtss2sd %xmm12,%xmm14
  8214cc:	movapd %xmm9,%xmm11
  8214d1:	divsd  %xmm14,%xmm11
  8214d6:	ucomisd -0x771bdf(%rip),%xmm11        # af900 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x10>
  8214df:	ja     821282 <gpui_gpu::renderer::validate_draw+0x182>
  8214e5:	addsd  %xmm9,%xmm14
  8214ea:	mulsd  -0x771d4b(%rip),%xmm14        # af7a8 <anon.4109cdd7ddb1990ee57d5626700ecb68.92.llvm.4479275319843201559+0x10>
  8214f3:	movapd (%rsp),%xmm11
  8214f9:	movapd -0x7766d2(%rip),%xmm13        # aae30 <GCC_except_table0+0xa0>
  821502:	cmp    $0x2,%esi
  821505:	movaps %xmm11,(%rsp)
  82150a:	jae    82161b <gpui_gpu::renderer::validate_draw+0x51b>
  821510:	cvtps2pd %xmm8,%xmm8
  821514:	subpd  %xmm8,%xmm5
  821519:	cvtps2pd %xmm7,%xmm7
  82151c:	andpd  %xmm13,%xmm5
  821521:	mulpd  0x40(%rsp),%xmm5
  821527:	subpd  %xmm7,%xmm4
  82152b:	andpd  %xmm13,%xmm4
  821530:	mulpd  0x50(%rsp),%xmm4
  821536:	addpd  %xmm5,%xmm4
  82153a:	cvtps2pd %xmm6,%xmm5
  82153d:	subpd  %xmm5,%xmm0
  821541:	addsd  -0x771c52(%rip),%xmm10        # af8f8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  82154a:	mulsd  -0x771a8b(%rip),%xmm10        # afac8 <anon.4109cdd7ddb1990ee57d5626700ecb68.350.llvm.4479275319843201559+0x18>
  821553:	andpd  %xmm13,%xmm0
  821558:	addpd  %xmm4,%xmm0
  82155c:	movapd 0x60(%rsp),%xmm7
  821562:	addsd  %xmm7,%xmm15
  821567:	movapd (%rsp),%xmm6
  82156c:	addsd  %xmm6,%xmm15
  821571:	addsd  0x30(%rsp),%xmm15
  821578:	movapd %xmm0,%xmm4
  82157c:	unpckhpd %xmm0,%xmm4
  821580:	addpd  %xmm0,%xmm4
  821584:	movapd %xmm1,%xmm5
  821588:	shufpd $0x1,%xmm4,%xmm5
  82158d:	movapd %xmm2,%xmm4
  821591:	unpcklpd %xmm10,%xmm4
  821596:	addpd  %xmm4,%xmm5
  82159a:	mulsd  -0x771ecb(%rip),%xmm15        # af6d8 <anon.a16d5d421a76dfd8c37a17b53540311d.77.llvm.14190004212411149437+0x10>
  8215a3:	shufpd $0x1,%xmm15,%xmm2
  8215a9:	addpd  %xmm5,%xmm2
  8215ad:	unpcklpd %xmm14,%xmm1
  8215b2:	addpd  %xmm2,%xmm1
  8215b6:	movapd %xmm1,%xmm2
  8215ba:	unpckhpd %xmm1,%xmm2
  8215be:	mulsd  %xmm1,%xmm2
  8215c2:	andpd  -0x77679a(%rip),%xmm3        # aae30 <GCC_except_table0+0xa0>
  8215ca:	divsd  %xmm3,%xmm2
  8215ce:	movq   %xmm2,%rdx
  8215d3:	and    %rax,%rdx
  8215d6:	cmp    %rcx,%rdx
  8215d9:	jg     821282 <gpui_gpu::renderer::validate_draw+0x182>
  8215df:	ucomisd -0x7716bf(%rip),%xmm2        # aff28 <anon.a16d5d421a76dfd8c37a17b53540311d.26.llvm.14190004212411149437+0x10>
  8215e7:	ja     821282 <gpui_gpu::renderer::validate_draw+0x182>
  8215ed:	unpcklpd %xmm10,%xmm10
  8215f2:	addpd  %xmm10,%xmm0
  8215f7:	addpd  %xmm7,%xmm6
  8215fb:	mulpd  -0x7765f3(%rip),%xmm6        # ab010 <anon.068260129a360d3c14a88deb110120c9.101.llvm.7357624670875813013+0x1d0>
  821603:	addpd  %xmm0,%xmm6
  821607:	cvtpd2ps %xmm6,%xmm0
  82160b:	movlpd %xmm0,0x4(%rbx)
  821610:	movl   $0xffffffff,(%rbx)
  821616:	jmp    82119d <gpui_gpu::renderer::validate_draw+0x9d>
  82161b:	jne    821630 <gpui_gpu::renderer::validate_draw+0x530>
  82161d:	mov    0x28(%r15),%rsi
  821621:	mov    0x30(%r15),%rdi
  821625:	jmp    821638 <gpui_gpu::renderer::validate_draw+0x538>
  821627:	movaps %xmm11,(%rsp)
  82162c:	xorps  %xmm14,%xmm14
  821630:	mov    0x28(%r15),%esi
  821634:	mov    0x2c(%r15),%edi
  821638:	movq   %rsi,%xmm11
  82163d:	punpckldq -0x775cf6(%rip),%xmm11        # ab950 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x290>
  821646:	subpd  -0x77682f(%rip),%xmm11        # aae20 <GCC_except_table0+0x90>
  82164f:	movapd %xmm11,%xmm12
  821654:	unpckhpd %xmm11,%xmm12
  821659:	addsd  %xmm11,%xmm12
  82165e:	movapd 0x20(%rsp),%xmm11
  821665:	divsd  %xmm11,%xmm12
  82166a:	movq   %xmm12,%r8
  82166f:	and    %rax,%r8
  821672:	cmp    %rdx,%r8
  821675:	jge    821282 <gpui_gpu::renderer::validate_draw+0x182>
  82167b:	movaps %xmm14,0x10(%rsp)
  821681:	movapd %xmm11,%xmm14
  821686:	movq   %rdi,%xmm11
  82168b:	punpckldq -0x775d44(%rip),%xmm11        # ab950 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x290>
  821694:	subpd  -0x77687d(%rip),%xmm11        # aae20 <GCC_except_table0+0x90>
  82169d:	movapd %xmm11,%xmm13
  8216a2:	unpckhpd %xmm11,%xmm13
  8216a7:	addsd  %xmm11,%xmm13
  8216ac:	unpckhpd %xmm14,%xmm14
  8216b1:	divsd  %xmm14,%xmm13
  8216b6:	movapd 0x10(%rsp),%xmm14
  8216bd:	movq   %xmm13,%rdx
  8216c2:	and    %rax,%rdx
  8216c5:	cmp    %rcx,%rdx
  8216c8:	setg   %dl
  8216cb:	ucomisd -0x77203c(%rip),%xmm13        # af698 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  8216d4:	movapd -0x7768ad(%rip),%xmm13        # aae30 <GCC_except_table0+0xa0>
  8216dd:	ja     821282 <gpui_gpu::renderer::validate_draw+0x182>
  8216e3:	ucomisd -0x772054(%rip),%xmm12        # af698 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  8216ec:	ja     821282 <gpui_gpu::renderer::validate_draw+0x182>
  8216f2:	test   %dl,%dl
  8216f4:	jne    821282 <gpui_gpu::renderer::validate_draw+0x182>
  8216fa:	cmp    %rsi,%rdi
  8216fd:	cmova  %rdi,%rsi
  821701:	movq   %rsi,%xmm11
  821706:	punpckldq -0x775dbf(%rip),%xmm11        # ab950 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x290>
  82170f:	subpd  -0x7768f8(%rip),%xmm11        # aae20 <GCC_except_table0+0x90>
  821718:	movapd %xmm11,%xmm12
  82171d:	unpckhpd %xmm11,%xmm12
  821722:	addsd  %xmm11,%xmm12
  821727:	mulsd  %xmm12,%xmm9
  82172c:	ucomisd -0x77209d(%rip),%xmm9        # af698 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  821735:	ja     821282 <gpui_gpu::renderer::validate_draw+0x182>
  82173b:	jmp    821510 <gpui_gpu::renderer::validate_draw+0x410>

/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000821e50 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>>:
  821e50:	push   %rbp
  821e51:	push   %r15
  821e53:	push   %r14
  821e55:	push   %r13
  821e57:	push   %r12
  821e59:	push   %rbx
  821e5a:	sub    $0x58,%rsp
  821e5e:	mov    %ecx,%ebp
  821e60:	mov    %rdx,0x8(%rsp)
  821e65:	mov    0x18(%rdi),%rax
  821e69:	add    %rax,%rsi
  821e6c:	jb     821f81 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x131>
  821e72:	mov    %rdi,%rbx
  821e75:	mov    0x8(%rdi),%r15
  821e79:	lea    0x1(%r15),%rdx
  821e7d:	mov    %rdx,%rdi
  821e80:	shr    $0x3,%rdi
  821e84:	mov    %rdx,%rcx
  821e87:	and    $0xfffffffffffffff8,%rcx
  821e8b:	sub    %rdi,%rcx
  821e8e:	cmp    $0x8,%r15
  821e92:	cmovb  %r15,%rcx
  821e96:	mov    %rcx,%rdi
  821e99:	shr    $1,%rdi
  821e9c:	cmp    %rdi,%rsi
  821e9f:	jbe    821ed0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x80>
  821ea1:	inc    %rcx
  821ea4:	cmp    %rsi,%rcx
  821ea7:	cmovbe %rsi,%rcx
  821eab:	cmp    $0xf,%rcx
  821eaf:	mov    %rbx,(%rsp)
  821eb3:	jae    821f01 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0xb1>
  821eb5:	mov    %ecx,%eax
  821eb7:	and    $0x8,%eax
  821eba:	add    $0x8,%rax
  821ebe:	cmp    $0x4,%rcx
  821ec2:	mov    $0x4,%ebx
  821ec7:	cmovae %rax,%rbx
  821ecb:	jmp    821f59 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x109>
  821ed0:	test   %rdx,%rdx
  821ed3:	je     82215a <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x30a>
  821ed9:	mov    (%rbx),%rsi
  821edc:	mov    %rdx,%rax
  821edf:	shr    $0x4,%rax
  821ee3:	mov    %edx,%ecx
  821ee5:	and    $0xf,%ecx
  821ee8:	cmp    $0x1,%rcx
  821eec:	sbb    $0xffffffffffffffff,%rax
  821ef0:	cmp    $0x1,%rax
  821ef4:	jne    822161 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x311>
  821efa:	xor    %ecx,%ecx
  821efc:	jmp    8221b4 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x364>
  821f01:	movabs $0x1ffffffffffffffe,%rax
  821f0b:	inc    %rax
  821f0e:	cmp    %rax,%rcx
  821f11:	ja     821f81 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x131>
  821f13:	shl    $0x3,%rcx
  821f17:	movabs $0x2492492492492493,%rdx
  821f21:	mov    %rcx,%rax
  821f24:	mul    %rdx
  821f27:	sub    %rdx,%rcx
  821f2a:	shr    $1,%rcx
  821f2d:	add    %rdx,%rcx
  821f30:	shr    $0x2,%rcx
  821f34:	dec    %rcx
  821f37:	bsr    %rcx,%rcx
  821f3b:	not    %ecx
  821f3d:	mov    $0xffffffffffffffff,%rbx
  821f44:	shr    %cl,%rbx
  821f47:	movabs $0x7fffffffffffffe,%rax
  821f51:	cmp    %rax,%rbx
  821f54:	ja     821f81 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x131>
  821f56:	inc    %rbx
  821f59:	mov    %rbx,%r14
  821f5c:	shl    $0x5,%r14
  821f60:	lea    0x10(%rbx),%r12
  821f64:	mov    %r12,%r13
  821f67:	add    %r14,%r13
  821f6a:	setb   %al
  821f6d:	movabs $0x7ffffffffffffff0,%rcx
  821f77:	cmp    %rcx,%r13
  821f7a:	seta   %cl
  821f7d:	or     %al,%cl
  821f7f:	je     821f90 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x140>
  821f81:	movzbl %bpl,%edi
  821f85:	call   *0x65dc8d(%rip)        # e7fc18 <_DYNAMIC+0x678>
  821f8b:	jmp    8223d5 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x585>
  821f90:	call   *0x65d89a(%rip)        # e7f830 <_DYNAMIC+0x290>
  821f96:	mov    $0x10,%esi
  821f9b:	mov    %r13,%rdi
  821f9e:	call   *0x65d894(%rip)        # e7f838 <_DYNAMIC+0x298>
  821fa4:	test   %rax,%rax
  821fa7:	je     8223f3 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x5a3>
  821fad:	mov    %rax,%r15
  821fb0:	mov    (%rsp),%rcx
  821fb4:	lea    0x20(%rcx),%r13
  821fb8:	add    %r14,%r15
  821fbb:	lea    -0x1(%rbx),%r14
  821fbf:	mov    %rbx,%rax
  821fc2:	shr    $0x3,%rax
  821fc6:	mov    %rbx,%rbp
  821fc9:	and    $0xfffffffffffffff8,%rbp
  821fcd:	sub    %rax,%rbp
  821fd0:	cmp    $0x9,%rbx
  821fd4:	mov    %rcx,%rbx
  821fd7:	cmovb  %r14,%rbp
  821fdb:	mov    %r15,%rdi
  821fde:	mov    $0xff,%esi
  821fe3:	mov    %r12,%rdx
  821fe6:	call   *0x65dc34(%rip)        # e7fc20 <memset@GLIBC_2.2.5>
  821fec:	mov    %r14,%rdi
  821fef:	mov    %r13,0x20(%rsp)
  821ff4:	movq   $0x20,0x28(%rsp)
  821ffd:	movq   $0x10,0x30(%rsp)
  822006:	mov    %r15,0x38(%rsp)
  82200b:	mov    %r14,0x40(%rsp)
  822010:	mov    %rbp,0x48(%rsp)
  822015:	movq   $0x0,0x50(%rsp)
  82201e:	mov    0x18(%rbx),%r12
  822022:	test   %r12,%r12
  822025:	je     822407 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x5b7>
  82202b:	mov    %rbp,0x10(%rsp)
  822030:	mov    (%rbx),%rsi
  822033:	movdqa (%rsi),%xmm0
  822037:	pmovmskb %xmm0,%r13d
  82203c:	not    %r13d
  82203f:	xor    %ebp,%ebp
  822041:	mov    %rsi,%r14
  822044:	mov    %rdi,0x18(%rsp)
  822049:	nopl   0x0(%rax)
  822050:	test   %r13w,%r13w
  822054:	jne    82207f <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x22f>
  822056:	cs nopw 0x0(%rax,%rax,1)
  822060:	movdqa 0x10(%r14),%xmm0
  822066:	add    $0x10,%r14
  82206a:	pmovmskb %xmm0,%r13d
  82206f:	xor    $0xffff,%r13d
  822076:	add    $0x10,%rbp
  82207a:	test   %r13d,%r13d
  82207d:	je     822060 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x210>
  82207f:	tzcnt  %r13d,%ebx
  822084:	add    %rbp,%rbx
  822087:	mov    %rbx,%rax
  82208a:	shl    $0x5,%rax
  82208e:	sub    %rax,%rsi
  822091:	add    $0xffffffffffffffe0,%rsi
  822095:	mov    0x8(%rsp),%rdi
  82209a:	call   824230 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  82209f:	mov    %rax,%rdx
  8220a2:	mov    0x18(%rsp),%rdi
  8220a7:	and    %rdi,%rdx
  8220aa:	movdqu (%r15,%rdx,1),%xmm0
  8220b0:	pmovmskb %xmm0,%ecx
  8220b4:	test   %ecx,%ecx
  8220b6:	je     822125 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x2d5>
  8220b8:	tzcnt  %ecx,%ecx
  8220bc:	add    %rdx,%rcx
  8220bf:	and    %rdi,%rcx
  8220c2:	cmpb   $0x0,(%r15,%rcx,1)
  8220c7:	jns    822148 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x2f8>
  8220c9:	lea    -0x1(%r13),%edx
  8220cd:	and    %r13d,%edx
  8220d0:	dec    %r12
  8220d3:	shr    $0x39,%rax
  8220d7:	lea    -0x10(%rcx),%rsi
  8220db:	and    %rdi,%rsi
  8220de:	mov    %al,(%r15,%rcx,1)
  8220e2:	mov    %al,0x10(%r15,%rsi,1)
  8220e7:	mov    (%rsp),%rax
  8220eb:	mov    (%rax),%rsi
  8220ee:	not    %rbx
  8220f1:	shl    $0x5,%rbx
  8220f5:	not    %rcx
  8220f8:	shl    $0x5,%rcx
  8220fc:	movdqu (%rsi,%rbx,1),%xmm0
  822101:	movdqu 0x10(%rsi,%rbx,1),%xmm1
  822107:	movdqu %xmm1,0x10(%r15,%rcx,1)
  82210e:	movdqu %xmm0,(%r15,%rcx,1)
  822114:	mov    %edx,%r13d
  822117:	test   %r12,%r12
  82211a:	jne    822050 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x200>
  822120:	jmp    8223e4 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x594>
  822125:	mov    $0x10,%esi
  82212a:	add    %rsi,%rdx
  82212d:	and    %rdi,%rdx
  822130:	movdqu (%r15,%rdx,1),%xmm0
  822136:	pmovmskb %xmm0,%ecx
  82213a:	add    $0x10,%rsi
  82213e:	test   %ecx,%ecx
  822140:	jne    8220b8 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x268>
  822146:	jmp    82212a <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x2da>
  822148:	movdqa (%r15),%xmm0
  82214d:	pmovmskb %xmm0,%ecx
  822151:	tzcnt  %ecx,%ecx
  822155:	jmp    8220c9 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x279>
  82215a:	xor    %ecx,%ecx
  82215c:	jmp    8223c7 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x577>
  822161:	movabs $0x1ffffffffffffffe,%rdi
  82216b:	and    %rax,%rdi
  82216e:	xor    %ecx,%ecx
  822170:	movdqa -0x774558(%rip),%xmm0        # adc20 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x830>
  822178:	nopl   0x0(%rax,%rax,1)
  822180:	pxor   %xmm1,%xmm1
  822184:	pcmpgtb (%rsi,%rcx,1),%xmm1
  822189:	por    %xmm0,%xmm1
  82218d:	movdqa %xmm1,(%rsi,%rcx,1)
  822192:	pxor   %xmm1,%xmm1
  822196:	pcmpgtb 0x10(%rsi,%rcx,1),%xmm1
  82219c:	por    %xmm0,%xmm1
  8221a0:	movdqa %xmm1,0x10(%rsi,%rcx,1)
  8221a6:	add    $0x20,%rcx
  8221aa:	add    $0xfffffffffffffffe,%rdi
  8221ae:	jne    822180 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x330>
  8221b0:	test   $0x1,%al
  8221b2:	je     8221ca <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x37a>
  8221b4:	pxor   %xmm0,%xmm0
  8221b8:	pcmpgtb (%rsi,%rcx,1),%xmm0
  8221bd:	por    -0x7745a5(%rip),%xmm0        # adc20 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x830>
  8221c5:	movdqa %xmm0,(%rsi,%rcx,1)
  8221ca:	cmp    $0x10,%rdx
  8221ce:	jb     822458 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x608>
  8221d4:	mov    %rdx,%rdi
  8221d7:	mov    $0x10,%edx
  8221dc:	add    %rsi,%rdi
  8221df:	call   *0x65da43(%rip)        # e7fc28 <memmove@GLIBC_2.2.5>
  8221e5:	movq   $0x0,0x28(%rsp)
  8221ee:	movq   $0x20,0x30(%rsp)
  8221f7:	mov    %rbx,0x20(%rsp)
  8221fc:	xor    %r12d,%r12d
  8221ff:	xor    %r13d,%r13d
  822202:	jmp    822351 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x501>
  822207:	nopw   0x0(%rax,%rax,1)
  822210:	lea    (%rax,%rbp,1),%rsi
  822214:	add    $0xffffffffffffffe0,%rsi
  822218:	mov    0x8(%rsp),%rdi
  82221d:	call   824230 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  822222:	mov    (%rbx),%rcx
  822225:	mov    0x8(%rbx),%rdx
  822229:	mov    %rdx,%rsi
  82222c:	and    %rax,%rsi
  82222f:	movdqu (%rcx,%rsi,1),%xmm0
  822234:	pmovmskb %xmm0,%edi
  822238:	mov    %rsi,%r8
  82223b:	test   %edi,%edi
  82223d:	je     8222e9 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x499>
  822243:	tzcnt  %edi,%edi
  822247:	add    %r8,%rdi
  82224a:	and    %rdx,%rdi
  82224d:	cmpb   $0x0,(%rcx,%rdi,1)
  822251:	jns    822310 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4c0>
  822257:	mov    %r12,%r8
  82225a:	sub    %rsi,%r8
  82225d:	mov    %rdi,%r9
  822260:	sub    %rsi,%r9
  822263:	xor    %r8,%r9
  822266:	and    %rdx,%r9
  822269:	cmp    $0x10,%r9
  82226d:	jb     822330 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4e0>
  822273:	mov    %rdi,%rsi
  822276:	not    %rsi
  822279:	shl    $0x5,%rsi
  82227d:	add    %rcx,%rsi
  822280:	movzbl (%rcx,%rdi,1),%r8d
  822285:	shr    $0x39,%rax
  822289:	lea    -0x10(%rdi),%r9
  82228d:	and    %rdx,%r9
  822290:	mov    %al,(%rcx,%rdi,1)
  822293:	mov    (%rbx),%rcx
  822296:	mov    %al,0x10(%rcx,%r9,1)
  82229b:	cmp    $0xff,%r8b
  82229f:	je     822376 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x526>
  8222a5:	mov    (%r14),%rax
  8222a8:	mov    (%rsi),%rcx
  8222ab:	mov    %rcx,(%r14)
  8222ae:	mov    %rax,(%rsi)
  8222b1:	mov    0x8(%r14),%rax
  8222b5:	mov    0x8(%rsi),%rcx
  8222b9:	mov    %rcx,0x8(%r14)
  8222bd:	mov    %rax,0x8(%rsi)
  8222c1:	mov    0x10(%r14),%rax
  8222c5:	mov    0x10(%rsi),%rcx
  8222c9:	mov    %rcx,0x10(%r14)
  8222cd:	mov    %rax,0x10(%rsi)
  8222d1:	mov    0x18(%r14),%rax
  8222d5:	mov    0x18(%rsi),%rcx
  8222d9:	mov    %rcx,0x18(%r14)
  8222dd:	mov    %rax,0x18(%rsi)
  8222e1:	mov    (%rbx),%rax
  8222e4:	jmp    822210 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x3c0>
  8222e9:	mov    $0x10,%r9d
  8222ef:	mov    %rsi,%r8
  8222f2:	add    %r9,%r8
  8222f5:	and    %rdx,%r8
  8222f8:	movdqu (%rcx,%r8,1),%xmm0
  8222fe:	pmovmskb %xmm0,%edi
  822302:	add    $0x10,%r9
  822306:	test   %edi,%edi
  822308:	jne    822243 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x3f3>
  82230e:	jmp    8222f2 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4a2>
  822310:	movdqa (%rcx),%xmm0
  822314:	pmovmskb %xmm0,%edi
  822318:	tzcnt  %edi,%edi
  82231c:	jmp    822257 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x407>
  822321:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  822330:	shr    $0x39,%rax
  822334:	lea    -0x10(%r12),%rsi
  822339:	and    %rsi,%rdx
  82233c:	mov    %al,(%rcx,%r12,1)
  822340:	mov    (%rbx),%rcx
  822343:	mov    %al,0x10(%rcx,%rdx,1)
  822347:	cmp    %r15,%r12
  82234a:	lea    0x1(%r12),%r12
  82234f:	je     8223a5 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x555>
  822351:	mov    (%rbx),%rax
  822354:	cmp    (%rax,%r12,1),%r13b
  822358:	jno    822347 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4f7>
  82235a:	mov    %r12,%r14
  82235d:	not    %r14
  822360:	shl    $0x5,%r14
  822364:	add    %rax,%r14
  822367:	mov    %r12,%rbp
  82236a:	neg    %rbp
  82236d:	shl    $0x5,%rbp
  822371:	jmp    822210 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x3c0>
  822376:	lea    -0x10(%r12),%rax
  82237b:	and    0x8(%rbx),%rax
  82237f:	mov    (%rbx),%rcx
  822382:	movb   $0xff,(%rcx,%r12,1)
  822387:	mov    (%rbx),%rcx
  82238a:	movb   $0xff,0x10(%rcx,%rax,1)
  82238f:	movdqu (%r14),%xmm0
  822394:	movdqu 0x10(%r14),%xmm1
  82239a:	movdqu %xmm1,0x10(%rsi)
  82239f:	movdqu %xmm0,(%rsi)
  8223a3:	jmp    822347 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4f7>
  8223a5:	mov    0x8(%rbx),%rdx
  8223a9:	mov    0x18(%rbx),%rax
  8223ad:	lea    0x1(%rdx),%rcx
  8223b1:	mov    %rcx,%rsi
  8223b4:	shr    $0x3,%rsi
  8223b8:	and    $0xfffffffffffffff8,%rcx
  8223bc:	sub    %rsi,%rcx
  8223bf:	cmp    $0x8,%rdx
  8223c3:	cmovb  %rdx,%rcx
  8223c7:	sub    %rax,%rcx
  8223ca:	mov    %rcx,0x10(%rbx)
  8223ce:	mov    $0xffffffffffffffff,%rax
  8223d5:	add    $0x58,%rsp
  8223d9:	pop    %rbx
  8223da:	pop    %r12
  8223dc:	pop    %r13
  8223de:	pop    %r14
  8223e0:	pop    %r15
  8223e2:	pop    %rbp
  8223e3:	ret
  8223e4:	mov    (%rsp),%rbx
  8223e8:	mov    0x18(%rbx),%rcx
  8223ec:	mov    0x10(%rsp),%rbp
  8223f1:	jmp    82240c <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x5bc>
  8223f3:	movzbl %bpl,%edi
  8223f7:	mov    $0x10,%esi
  8223fc:	mov    %r13,%rdx
  8223ff:	call   *0x65d82b(%rip)        # e7fc30 <_DYNAMIC+0x690>
  822405:	jmp    8223d5 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x585>
  822407:	mov    (%rbx),%rsi
  82240a:	xor    %ecx,%ecx
  82240c:	sub    %rcx,%rbp
  82240f:	mov    %r15,(%rbx)
  822412:	mov    0x8(%rbx),%rax
  822416:	mov    %rdi,0x8(%rbx)
  82241a:	mov    %rbp,0x10(%rbx)
  82241e:	mov    %rcx,0x18(%rbx)
  822422:	test   %rax,%rax
  822425:	je     8223ce <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x57e>
  822427:	mov    %rax,%rcx
  82242a:	shl    $0x5,%rcx
  82242e:	add    $0x2f,%rcx
  822432:	and    $0xffffffffffffffe0,%rcx
  822436:	add    %rcx,%rax
  822439:	add    $0x11,%rax
  82243d:	je     8223ce <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x57e>
  82243f:	sub    %rcx,%rsi
  822442:	mov    $0x10,%edx
  822447:	mov    %rsi,%rdi
  82244a:	mov    %rax,%rsi
  82244d:	call   *0x65d395(%rip)        # e7f7e8 <_DYNAMIC+0x248>
  822453:	jmp    8223ce <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x57e>
  822458:	mov    $0x10,%edi
  82245d:	jmp    8221dc <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x38c>
  822462:	mov    %rax,%rbx
  822465:	lea    0x20(%rsp),%rdi
  82246a:	call   822a40 <core::ptr::drop_glue::<hashbrown::scopeguard::ScopeGuard<hashbrown::raw::RawTableInner, <hashbrown::raw::RawTableInner>::prepare_resize<alloc::alloc::Global>::{closure#0}>>>
  82246f:	mov    %rbx,%rdi
  822472:	call   e2c310 <_Unwind_Resume@plt>
  822477:	mov    %rax,%rbx
  82247a:	lea    0x20(%rsp),%rdi
  82247f:	call   822a80 <core::ptr::drop_glue::<hashbrown::scopeguard::ScopeGuard<&mut hashbrown::raw::RawTableInner, <hashbrown::raw::RawTableInner>::rehash_in_place::{closure#0}>>>
  822484:	mov    %rbx,%rdi
  822487:	call   e2c310 <_Unwind_Resume@plt>
  82248c:	call   *0x65d35e(%rip)        # e7f7f0 <_DYNAMIC+0x250>

/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008224a0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>>:
  8224a0:	push   %rbp
  8224a1:	push   %r15
  8224a3:	push   %r14
  8224a5:	push   %r13
  8224a7:	push   %r12
  8224a9:	push   %rbx
  8224aa:	sub    $0x38,%rsp
  8224ae:	mov    %ecx,%r15d
  8224b1:	mov    %rdx,0x20(%rsp)
  8224b6:	mov    %rdi,%rbp
  8224b9:	mov    0x18(%rdi),%rdi
  8224bd:	add    %rdi,%rsi
  8224c0:	jb     8225d8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x138>
  8224c6:	mov    0x8(%rbp),%rbx
  8224ca:	lea    0x1(%rbx),%rdx
  8224ce:	mov    %rdx,%rax
  8224d1:	shr    $0x3,%rax
  8224d5:	mov    %rdx,%rcx
  8224d8:	and    $0xfffffffffffffff8,%rcx
  8224dc:	sub    %rax,%rcx
  8224df:	cmp    $0x8,%rbx
  8224e3:	cmovb  %rbx,%rcx
  8224e7:	mov    %rcx,%rax
  8224ea:	shr    $1,%rax
  8224ed:	cmp    %rax,%rsi
  8224f0:	jbe    822526 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x86>
  8224f2:	inc    %rcx
  8224f5:	cmp    %rsi,%rcx
  8224f8:	cmovbe %rsi,%rcx
  8224fc:	cmp    $0xf,%rcx
  822500:	mov    %rbp,(%rsp)
  822504:	mov    %rbx,0x30(%rsp)
  822509:	jae    822558 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0xb8>
  82250b:	mov    %ecx,%eax
  82250d:	and    $0x8,%eax
  822510:	add    $0x8,%rax
  822514:	cmp    $0x4,%rcx
  822518:	mov    $0x4,%ebx
  82251d:	cmovae %rax,%rbx
  822521:	jmp    8225b0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x110>
  822526:	test   %rdx,%rdx
  822529:	je     82276e <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2ce>
  82252f:	mov    0x0(%rbp),%r12
  822533:	mov    %rdx,%rax
  822536:	shr    $0x4,%rax
  82253a:	mov    %edx,%ecx
  82253c:	and    $0xf,%ecx
  82253f:	cmp    $0x1,%rcx
  822543:	sbb    $0xffffffffffffffff,%rax
  822547:	cmp    $0x1,%rax
  82254b:	jne    822775 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2d5>
  822551:	xor    %ecx,%ecx
  822553:	jmp    8227c8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x328>
  822558:	movabs $0x1ffffffffffffffe,%rax
  822562:	inc    %rax
  822565:	cmp    %rax,%rcx
  822568:	ja     8225d8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x138>
  82256a:	shl    $0x3,%rcx
  82256e:	movabs $0x2492492492492493,%rdx
  822578:	mov    %rcx,%rax
  82257b:	mul    %rdx
  82257e:	sub    %rdx,%rcx
  822581:	shr    $1,%rcx
  822584:	add    %rdx,%rcx
  822587:	shr    $0x2,%rcx
  82258b:	dec    %rcx
  82258e:	bsr    %rcx,%rcx
  822592:	not    %ecx
  822594:	mov    $0xffffffffffffffff,%rbx
  82259b:	shr    %cl,%rbx
  82259e:	movabs $0xffffffffffffffe,%rax
  8225a8:	cmp    %rax,%rbx
  8225ab:	ja     8225d8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x138>
  8225ad:	inc    %rbx
  8225b0:	mov    %rbx,%r14
  8225b3:	shl    $0x4,%r14
  8225b7:	lea    0x10(%rbx),%rbp
  8225bb:	mov    %rbp,%r13
  8225be:	add    %r14,%r13
  8225c1:	setb   %al
  8225c4:	movabs $0x7ffffffffffffff0,%rcx
  8225ce:	cmp    %rcx,%r13
  8225d1:	seta   %cl
  8225d4:	or     %al,%cl
  8225d6:	je     8225e7 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x147>
  8225d8:	movzbl %r15b,%edi
  8225dc:	call   *0x65d636(%rip)        # e7fc18 <_DYNAMIC+0x678>
  8225e2:	jmp    8229a8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  8225e7:	mov    %rdi,0x8(%rsp)
  8225ec:	call   *0x65d23e(%rip)        # e7f830 <_DYNAMIC+0x290>
  8225f2:	mov    $0x10,%esi
  8225f7:	mov    %r13,%rdi
  8225fa:	call   *0x65d238(%rip)        # e7f838 <_DYNAMIC+0x298>
  822600:	test   %rax,%rax
  822603:	je     8229c2 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x522>
  822609:	mov    %rax,%rdi
  82260c:	add    %r14,%rdi
  82260f:	lea    -0x1(%rbx),%rcx
  822613:	mov    %rbx,%rax
  822616:	shr    $0x3,%rax
  82261a:	mov    %rbx,%r14
  82261d:	and    $0xfffffffffffffff8,%r14
  822621:	sub    %rax,%r14
  822624:	cmp    $0x9,%rbx
  822628:	mov    %rcx,0x10(%rsp)
  82262d:	cmovb  %rcx,%r14
  822631:	mov    %rdi,0x18(%rsp)
  822636:	mov    $0xff,%esi
  82263b:	mov    %rbp,%rdx
  82263e:	call   *0x65d5dc(%rip)        # e7fc20 <memset@GLIBC_2.2.5>
  822644:	mov    0x8(%rsp),%rbx
  822649:	test   %rbx,%rbx
  82264c:	je     8229d6 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x536>
  822652:	mov    %r14,0x28(%rsp)
  822657:	mov    (%rsp),%rax
  82265b:	mov    (%rax),%rdi
  82265e:	movdqa (%rdi),%xmm0
  822662:	pmovmskb %xmm0,%r14d
  822667:	not    %r14d
  82266a:	xor    %ebp,%ebp
  82266c:	mov    %rdi,%r13
  82266f:	nop
  822670:	test   %r14w,%r14w
  822674:	jne    82269f <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x1ff>
  822676:	cs nopw 0x0(%rax,%rax,1)
  822680:	movdqa 0x10(%r13),%xmm0
  822686:	add    $0x10,%r13
  82268a:	pmovmskb %xmm0,%r14d
  82268f:	xor    $0xffff,%r14d
  822696:	add    $0x10,%rbp
  82269a:	test   %r14d,%r14d
  82269d:	je     822680 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x1e0>
  82269f:	tzcnt  %r14d,%r15d
  8226a4:	add    %rbp,%r15
  8226a7:	mov    %r15,%rax
  8226aa:	shl    $0x4,%rax
  8226ae:	mov    %rdi,%r12
  8226b1:	mov    %rdi,%rsi
  8226b4:	sub    %rax,%rsi
  8226b7:	add    $0xfffffffffffffff0,%rsi
  8226bb:	mov    0x20(%rsp),%rdi
  8226c0:	call   8243d0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  8226c5:	mov    %rax,%rcx
  8226c8:	mov    0x10(%rsp),%r9
  8226cd:	and    %r9,%rcx
  8226d0:	mov    0x18(%rsp),%r8
  8226d5:	movdqu (%r8,%rcx,1),%xmm0
  8226db:	pmovmskb %xmm0,%edx
  8226df:	test   %edx,%edx
  8226e1:	je     822740 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2a0>
  8226e3:	tzcnt  %edx,%edx
  8226e7:	add    %rcx,%rdx
  8226ea:	and    %r9,%rdx
  8226ed:	cmpb   $0x0,(%r8,%rdx,1)
  8226f2:	mov    %r12,%rdi
  8226f5:	jns    82275f <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2bf>
  8226f7:	lea    -0x1(%r14),%ecx
  8226fb:	and    %r14d,%ecx
  8226fe:	dec    %rbx
  822701:	shr    $0x39,%rax
  822705:	lea    -0x10(%rdx),%rsi
  822709:	and    %r9,%rsi
  82270c:	mov    %al,(%r8,%rdx,1)
  822710:	mov    %al,0x10(%r8,%rsi,1)
  822715:	not    %r15
  822718:	shl    $0x4,%r15
  82271c:	not    %rdx
  82271f:	shl    $0x4,%rdx
  822723:	movdqu (%rdi,%r15,1),%xmm0
  822729:	movdqu %xmm0,(%r8,%rdx,1)
  82272f:	mov    %ecx,%r14d
  822732:	test   %rbx,%rbx
  822735:	jne    822670 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x1d0>
  82273b:	jmp    8229b7 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x517>
  822740:	mov    $0x10,%esi
  822745:	add    %rsi,%rcx
  822748:	and    %r9,%rcx
  82274b:	movdqu (%r8,%rcx,1),%xmm0
  822751:	pmovmskb %xmm0,%edx
  822755:	add    $0x10,%rsi
  822759:	test   %edx,%edx
  82275b:	jne    8226e3 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x243>
  82275d:	jmp    822745 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2a5>
  82275f:	movdqa (%r8),%xmm0
  822764:	pmovmskb %xmm0,%ecx
  822768:	tzcnt  %ecx,%edx
  82276c:	jmp    8226f7 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x257>
  82276e:	xor    %eax,%eax
  822770:	jmp    82299a <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x4fa>
  822775:	movabs $0x1ffffffffffffffe,%rsi
  82277f:	and    %rax,%rsi
  822782:	xor    %ecx,%ecx
  822784:	movdqa -0x774b6c(%rip),%xmm0        # adc20 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x830>
  82278c:	nopl   0x0(%rax)
  822790:	pxor   %xmm1,%xmm1
  822794:	pcmpgtb (%r12,%rcx,1),%xmm1
  82279a:	por    %xmm0,%xmm1
  82279e:	movdqa %xmm1,(%r12,%rcx,1)
  8227a4:	pxor   %xmm1,%xmm1
  8227a8:	pcmpgtb 0x10(%r12,%rcx,1),%xmm1
  8227af:	por    %xmm0,%xmm1
  8227b3:	movdqa %xmm1,0x10(%r12,%rcx,1)
  8227ba:	add    $0x20,%rcx
  8227be:	add    $0xfffffffffffffffe,%rsi
  8227c2:	jne    822790 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2f0>
  8227c4:	test   $0x1,%al
  8227c6:	je     8227e0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x340>
  8227c8:	pxor   %xmm0,%xmm0
  8227cc:	pcmpgtb (%r12,%rcx,1),%xmm0
  8227d2:	por    -0x774bba(%rip),%xmm0        # adc20 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x830>
  8227da:	movdqa %xmm0,(%r12,%rcx,1)
  8227e0:	cmp    $0x10,%rdx
  8227e4:	jb     822a33 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x593>
  8227ea:	mov    %rdx,%rdi
  8227ed:	mov    $0x10,%edx
  8227f2:	add    %r12,%rdi
  8227f5:	mov    %r12,%rsi
  8227f8:	call   *0x65d42a(%rip)        # e7fc28 <memmove@GLIBC_2.2.5>
  8227fe:	xor    %r13d,%r13d
  822801:	xor    %eax,%eax
  822803:	jmp    822936 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x496>
  822808:	nopl   0x0(%rax,%rax,1)
  822810:	lea    (%r12,%r14,1),%rsi
  822814:	add    $0xfffffffffffffff0,%rsi
  822818:	mov    0x20(%rsp),%rdi
  82281d:	call   8243d0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  822822:	mov    0x8(%rbp),%rcx
  822826:	mov    %rcx,%rdx
  822829:	and    %rax,%rdx
  82282c:	movdqu (%r12,%rdx,1),%xmm0
  822832:	pmovmskb %xmm0,%esi
  822836:	mov    %rdx,%rdi
  822839:	test   %esi,%esi
  82283b:	je     8228cb <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x42b>
  822841:	tzcnt  %esi,%esi
  822845:	add    %rdi,%rsi
  822848:	and    %rcx,%rsi
  82284b:	cmpb   $0x0,(%r12,%rsi,1)
  822850:	jns    8228f2 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x452>
  822856:	mov    %r13,%rdi
  822859:	sub    %rdx,%rdi
  82285c:	mov    %rsi,%r8
  82285f:	sub    %rdx,%r8
  822862:	xor    %rdi,%r8
  822865:	and    %rcx,%r8
  822868:	cmp    $0x10,%r8
  82286c:	jb     822910 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x470>
  822872:	mov    %rsi,%rdx
  822875:	not    %rdx
  822878:	shl    $0x4,%rdx
  82287c:	add    %r12,%rdx
  82287f:	movzbl (%r12,%rsi,1),%edi
  822884:	shr    $0x39,%rax
  822888:	lea    -0x10(%rsi),%r8
  82288c:	and    %rcx,%r8
  82288f:	mov    %al,(%r12,%rsi,1)
  822893:	mov    0x0(%rbp),%r12
  822897:	mov    %al,0x10(%r12,%r8,1)
  82289c:	cmp    $0xff,%dil
  8228a0:	je     82295b <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x4bb>
  8228a6:	mov    (%rbx),%rax
  8228a9:	mov    (%rdx),%rcx
  8228ac:	mov    %rcx,(%rbx)
  8228af:	mov    %rax,(%rdx)
  8228b2:	mov    0x8(%rbx),%rax
  8228b6:	mov    0x8(%rdx),%rcx
  8228ba:	mov    %rcx,0x8(%rbx)
  8228be:	mov    %rax,0x8(%rdx)
  8228c2:	mov    0x0(%rbp),%r12
  8228c6:	jmp    822810 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x370>
  8228cb:	mov    $0x10,%r8d
  8228d1:	mov    %rdx,%rdi
  8228d4:	add    %r8,%rdi
  8228d7:	and    %rcx,%rdi
  8228da:	movdqu (%r12,%rdi,1),%xmm0
  8228e0:	pmovmskb %xmm0,%esi
  8228e4:	add    $0x10,%r8
  8228e8:	test   %esi,%esi
  8228ea:	jne    822841 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x3a1>
  8228f0:	jmp    8228d4 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x434>
  8228f2:	movdqa (%r12),%xmm0
  8228f8:	pmovmskb %xmm0,%esi
  8228fc:	tzcnt  %esi,%esi
  822900:	jmp    822856 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x3b6>
  822905:	data16 cs nopw 0x0(%rax,%rax,1)
  822910:	shr    $0x39,%rax
  822914:	lea    -0x10(%r13),%rdx
  822918:	and    %rdx,%rcx
  82291b:	mov    %al,(%r12,%r13,1)
  82291f:	mov    0x0(%rbp),%r12
  822923:	mov    %al,0x10(%r12,%rcx,1)
  822928:	mov    %r15,%rbx
  82292b:	xor    %eax,%eax
  82292d:	cmp    %rbx,%r13
  822930:	lea    0x1(%r13),%r13
  822934:	je     822978 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x4d8>
  822936:	cmp    (%r12,%r13,1),%al
  82293a:	jno    82292d <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x48d>
  82293c:	mov    %rbx,%r15
  82293f:	mov    %r13,%rbx
  822942:	not    %rbx
  822945:	shl    $0x4,%rbx
  822949:	add    %r12,%rbx
  82294c:	mov    %r13,%r14
  82294f:	neg    %r14
  822952:	shl    $0x4,%r14
  822956:	jmp    822810 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x370>
  82295b:	lea    -0x10(%r13),%rax
  82295f:	and    0x8(%rbp),%rax
  822963:	movb   $0xff,(%r12,%r13,1)
  822968:	movb   $0xff,0x10(%r12,%rax,1)
  82296e:	movdqu (%rbx),%xmm0
  822972:	movdqu %xmm0,(%rdx)
  822976:	jmp    822928 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x488>
  822978:	mov    0x8(%rbp),%rcx
  82297c:	mov    0x18(%rbp),%rdi
  822980:	lea    0x1(%rcx),%rax
  822984:	mov    %rax,%rdx
  822987:	shr    $0x3,%rdx
  82298b:	and    $0xfffffffffffffff8,%rax
  82298f:	sub    %rdx,%rax
  822992:	cmp    $0x8,%rcx
  822996:	cmovb  %rcx,%rax
  82299a:	sub    %rdi,%rax
  82299d:	mov    %rax,0x10(%rbp)
  8229a1:	mov    $0xffffffffffffffff,%rax
  8229a8:	add    $0x38,%rsp
  8229ac:	pop    %rbx
  8229ad:	pop    %r12
  8229af:	pop    %r13
  8229b1:	pop    %r14
  8229b3:	pop    %r15
  8229b5:	pop    %rbp
  8229b6:	ret
  8229b7:	mov    (%rsp),%rax
  8229bb:	mov    0x28(%rsp),%r14
  8229c0:	jmp    8229e7 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x547>
  8229c2:	movzbl %r15b,%edi
  8229c6:	mov    $0x10,%esi
  8229cb:	mov    %r13,%rdx
  8229ce:	call   *0x65d25c(%rip)        # e7fc30 <_DYNAMIC+0x690>
  8229d4:	jmp    8229a8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  8229d6:	mov    (%rsp),%rax
  8229da:	mov    (%rax),%rdi
  8229dd:	mov    0x18(%rsp),%r8
  8229e2:	mov    0x10(%rsp),%r9
  8229e7:	sub    0x8(%rsp),%r14
  8229ec:	mov    %r8,(%rax)
  8229ef:	mov    %r9,0x8(%rax)
  8229f3:	mov    %r14,0x10(%rax)
  8229f7:	mov    $0xffffffffffffffff,%rax
  8229fe:	mov    0x30(%rsp),%rsi
  822a03:	test   %rsi,%rsi
  822a06:	je     8229a8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  822a08:	mov    %rsi,%rcx
  822a0b:	shl    $0x4,%rcx
  822a0f:	add    $0x1f,%rcx
  822a13:	and    $0xfffffffffffffff0,%rcx
  822a17:	add    %rcx,%rsi
  822a1a:	add    $0x11,%rsi
  822a1e:	je     8229a8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  822a20:	sub    %rcx,%rdi
  822a23:	mov    $0x10,%edx
  822a28:	call   *0x65cdba(%rip)        # e7f7e8 <_DYNAMIC+0x248>
  822a2e:	jmp    8229a1 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x501>
  822a33:	mov    $0x10,%edi
  822a38:	jmp    8227f2 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x352>

/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000822bf0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>:
  822bf0:	mov    0x8(%rdi),%rsi
  822bf4:	test   %rsi,%rsi
  822bf7:	je     822c1e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  822bf9:	mov    %rsi,%rax
  822bfc:	shl    $0x5,%rax
  822c00:	add    %rax,%rsi
  822c03:	add    $0x31,%rsi
  822c07:	je     822c1e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  822c09:	mov    (%rdi),%rdi
  822c0c:	sub    %rax,%rdi
  822c0f:	add    $0xffffffffffffffe0,%rdi
  822c13:	mov    $0x10,%edx
  822c18:	jmp    *0x65cbca(%rip)        # e7f7e8 <_DYNAMIC+0x248>
  822c1e:	ret

/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000822c20 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>:
  822c20:	push   %rbx
  822c21:	test   %rdi,%rdi
  822c24:	je     822c87 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x67>
  822c26:	mov    %rdi,%rbx
  822c29:	mov    (%rdi),%rsi
  822c2c:	test   %rsi,%rsi
  822c2f:	je     822c44 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x24>
  822c31:	mov    0x8(%rbx),%rdi
  822c35:	shl    $0x3,%rsi
  822c39:	mov    $0x8,%edx
  822c3e:	call   *0x65cba4(%rip)        # e7f7e8 <_DYNAMIC+0x248>
  822c44:	mov    0x20(%rbx),%rsi
  822c48:	test   %rsi,%rsi
  822c4b:	je     822c73 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  822c4d:	mov    %rsi,%rax
  822c50:	shl    $0x4,%rax
  822c54:	add    %rax,%rsi
  822c57:	add    $0x21,%rsi
  822c5b:	je     822c73 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  822c5d:	mov    0x18(%rbx),%rdi
  822c61:	sub    %rax,%rdi
  822c64:	add    $0xfffffffffffffff0,%rdi
  822c68:	mov    $0x10,%edx
  822c6d:	call   *0x65cb75(%rip)        # e7f7e8 <_DYNAMIC+0x248>
  822c73:	mov    $0x80,%esi
  822c78:	mov    $0x8,%edx
  822c7d:	mov    %rbx,%rdi
  822c80:	pop    %rbx
  822c81:	jmp    *0x65cb61(%rip)        # e7f7e8 <_DYNAMIC+0x248>
  822c87:	pop    %rbx
  822c88:	ret

/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000822eb0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>:
  822eb0:	push   %r14
  822eb2:	push   %rbx
  822eb3:	push   %rax
  822eb4:	mov    %rdi,%rbx
  822eb7:	mov    (%rdi),%rax
  822eba:	lock decq (%rax)
  822ebe:	jne    822ec9 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x19>
  822ec0:	mov    %rbx,%rdi
  822ec3:	call   *0x65cbdf(%rip)        # e7faa8 <_DYNAMIC+0x508>
  822ec9:	mov    0x8(%rbx),%rax
  822ecd:	lock decq (%rax)
  822ed1:	jne    822ee7 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x37>
  822ed3:	add    $0x8,%rbx
  822ed7:	mov    %rbx,%rdi
  822eda:	add    $0x8,%rsp
  822ede:	pop    %rbx
  822edf:	pop    %r14
  822ee1:	jmp    *0x65cbc9(%rip)        # e7fab0 <_DYNAMIC+0x510>
  822ee7:	add    $0x8,%rsp
  822eeb:	pop    %rbx
  822eec:	pop    %r14
  822eee:	ret
  822eef:	mov    %rax,%r14
  822ef2:	mov    0x8(%rbx),%rax
  822ef6:	lock decq (%rax)
  822efa:	jne    822f09 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x59>
  822efc:	add    $0x8,%rbx
  822f00:	mov    %rbx,%rdi
  822f03:	call   *0x65cba7(%rip)        # e7fab0 <_DYNAMIC+0x510>
  822f09:	mov    %r14,%rdi
  822f0c:	call   e2c310 <_Unwind_Resume@plt>
  822f11:	call   *0x65c8d9(%rip)        # e7f7f0 <_DYNAMIC+0x250>

/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000822fe0 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>:
  822fe0:	push   %rbx
  822fe1:	mov    %rdi,%rbx
  822fe4:	mov    (%rdi),%rsi
  822fe7:	test   %rsi,%rsi
  822fea:	je     822fff <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>+0x1f>
  822fec:	mov    0x8(%rbx),%rdi
  822ff0:	shl    $0x3,%rsi
  822ff4:	mov    $0x8,%edx
  822ff9:	call   *0x65c7e9(%rip)        # e7f7e8 <_DYNAMIC+0x248>
  822fff:	mov    0x20(%rbx),%rsi
  823003:	test   %rsi,%rsi
  823006:	je     82302f <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>+0x4f>
  823008:	mov    %rsi,%rax
  82300b:	shl    $0x4,%rax
  82300f:	add    %rax,%rsi
  823012:	add    $0x21,%rsi
  823016:	je     82302f <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>+0x4f>
  823018:	mov    0x18(%rbx),%rdi
  82301c:	sub    %rax,%rdi
  82301f:	add    $0xfffffffffffffff0,%rdi
  823023:	mov    $0x10,%edx
  823028:	pop    %rbx
  823029:	jmp    *0x65c7b9(%rip)        # e7f7e8 <_DYNAMIC+0x248>
  82302f:	pop    %rbx
  823030:	ret

/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000823040 <<gpui_gpu::renderer::images::Images>::metadata>:
  823040:	push   %r15
  823042:	push   %r14
  823044:	push   %rbx
  823045:	sub    $0x10,%rsp
  823049:	mov    %rsi,0x8(%rsp)
  82304e:	cmpq   $0x0,0x30(%rdi)
  823053:	je     82311d <<gpui_gpu::renderer::images::Images>::metadata+0xdd>
  823059:	mov    %edx,%ebx
  82305b:	mov    %rsi,%r14
  82305e:	mov    %rdi,%r15
  823061:	add    $0x38,%rdi
  823065:	lea    0x8(%rsp),%rsi
  82306a:	call   8243d0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  82306f:	mov    %rax,%rsi
  823072:	shr    $0x39,%rsi
  823076:	mov    0x18(%r15),%rcx
  82307a:	mov    0x20(%r15),%rdx
  82307e:	movd   %esi,%xmm0
  823082:	punpcklbw %xmm0,%xmm0
  823086:	pshuflw $0x0,%xmm0,%xmm0
  82308b:	pshufd $0x44,%xmm0,%xmm0
  823090:	xor    %esi,%esi
  823092:	pcmpeqd %xmm1,%xmm1
  823096:	and    %rdx,%rax
  823099:	movdqu (%rcx,%rax,1),%xmm2
  82309e:	movdqa %xmm2,%xmm3
  8230a2:	pcmpeqb %xmm0,%xmm3
  8230a6:	pmovmskb %xmm3,%edi
  8230aa:	test   %edi,%edi
  8230ac:	je     8230e0 <<gpui_gpu::renderer::images::Images>::metadata+0xa0>
  8230ae:	tzcnt  %edi,%r9d
  8230b3:	add    %rax,%r9
  8230b6:	and    %rdx,%r9
  8230b9:	shl    $0x4,%r9
  8230bd:	mov    %rcx,%r8
  8230c0:	sub    %r9,%r8
  8230c3:	cmp    -0x10(%r8),%r14
  8230c7:	je     8230f9 <<gpui_gpu::renderer::images::Images>::metadata+0xb9>
  8230c9:	lea    -0x1(%rdi),%r8d
  8230cd:	and    %di,%r8w
  8230d1:	mov    %r8d,%edi
  8230d4:	jne    8230ae <<gpui_gpu::renderer::images::Images>::metadata+0x6e>
  8230d6:	cs nopw 0x0(%rax,%rax,1)
  8230e0:	pcmpeqb %xmm1,%xmm2
  8230e4:	pmovmskb %xmm2,%edi
  8230e8:	test   %edi,%edi
  8230ea:	jne    82311d <<gpui_gpu::renderer::images::Images>::metadata+0xdd>
  8230ec:	add    %rsi,%rax
  8230ef:	add    $0x10,%rax
  8230f3:	add    $0x10,%rsi
  8230f7:	jmp    823096 <<gpui_gpu::renderer::images::Images>::metadata+0x56>
  8230f9:	mov    -0x8(%r8),%eax
  8230fd:	movzbl %bl,%ecx
  823100:	or     -0x4(%r8),%ecx
  823104:	shl    $0x20,%rcx
  823108:	or     %rax,%rcx
  82310b:	mov    $0x80000000,%eax
  823110:	or     %rcx,%rax
  823113:	add    $0x10,%rsp
  823117:	pop    %rbx
  823118:	pop    %r14
  82311a:	pop    %r15
  82311c:	ret
  82311d:	lea    -0x74e898(%rip),%rdi        # d488c <anon.81378166eea1c96e15e7851dcdc35f4e.0.llvm.4385859340901971677>
  823124:	lea    0x60b125(%rip),%rdx        # e2e250 <anon.81378166eea1c96e15e7851dcdc35f4e.2.llvm.4385859340901971677>
  82312b:	mov    $0x16,%esi
  823130:	call   *0x65ca0a(%rip)        # e7fb40 <_DYNAMIC+0x5a0>

/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008234a0 <gpui_gpu::renderer::images::prepare>:
  8234a0:	push   %rbp
  8234a1:	push   %r15
  8234a3:	push   %r14
  8234a5:	push   %r13
  8234a7:	push   %r12
  8234a9:	push   %rbx
  8234aa:	sub    $0x1f8,%rsp
  8234b1:	mov    %r9,%r12
  8234b4:	mov    %rcx,%r13
  8234b7:	mov    %rdx,0xb8(%rsp)
  8234bf:	mov    %rsi,0x8(%rsp)
  8234c4:	mov    %rdi,%r15
  8234c7:	mov    0x230(%rsp),%rax
  8234cf:	mov    0x10(%rax),%r14
  8234d3:	mov    0x118(%r14),%rax
  8234da:	add    $0x118,%r14
  8234e1:	test   %rax,%rax
  8234e4:	mov    %r14,%rcx
  8234e7:	cmove  %rax,%rcx
  8234eb:	je     823586 <gpui_gpu::renderer::images::prepare+0xe6>
  8234f1:	mov    0x10(%rax),%rax
  8234f5:	mov    (%r8),%rbp
  8234f8:	mov    %rax,0x18(%rsp)
  8234fd:	test   %rax,%rax
  823500:	je     823589 <gpui_gpu::renderer::images::prepare+0xe9>
  823506:	mov    %rcx,0xa8(%rsp)
  82350e:	test   %rbp,%rbp
  823511:	je     8236db <gpui_gpu::renderer::images::prepare+0x23b>
  823517:	cmp    0x48(%rbp),%r12
  82351b:	ja     8236db <gpui_gpu::renderer::images::prepare+0x23b>
  823521:	mov    0x8(%rbp),%rdi
  823525:	mov    0x10(%rbp),%rax
  823529:	lea    (%rdi,%rax,8),%rsi
  82352d:	movq   $0x1,0xe0(%rsp)
  823539:	mov    %r14,0xe8(%rsp)
  823541:	movq   $0x0,0xf0(%rsp)
  82354d:	movq   $0x0,0x100(%rsp)
  823559:	lea    0xe0(%rsp),%rdx
  823561:	mov    %r8,%rbx
  823564:	call   824fc0 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>>
  823569:	mov    %rbx,%r8
  82356c:	test   %al,%al
  82356e:	je     8236db <gpui_gpu::renderer::images::prepare+0x23b>
  823574:	movq   $0x0,0x60(%rbp)
  82357c:	movb   $0x0,0x4(%r15)
  823581:	jmp    8236bf <gpui_gpu::renderer::images::prepare+0x21f>
  823586:	mov    (%r8),%rbp
  823589:	movq   $0x0,(%r8)
  823590:	test   %rbp,%rbp
  823593:	je     8236b7 <gpui_gpu::renderer::images::prepare+0x217>
  823599:	mov    0x0(%rbp),%rsi
  82359d:	test   %rsi,%rsi
  8235a0:	je     8235b5 <gpui_gpu::renderer::images::prepare+0x115>
  8235a2:	mov    0x8(%rbp),%rdi
  8235a6:	shl    $0x3,%rsi
  8235aa:	mov    $0x8,%edx
  8235af:	call   *0x65c233(%rip)        # e7f7e8 <_DYNAMIC+0x248>
  8235b5:	mov    0x20(%rbp),%rsi
  8235b9:	test   %rsi,%rsi
  8235bc:	je     8235e4 <gpui_gpu::renderer::images::prepare+0x144>
  8235be:	mov    %rsi,%rax
  8235c1:	shl    $0x4,%rax
  8235c5:	add    %rax,%rsi
  8235c8:	add    $0x21,%rsi
  8235cc:	je     8235e4 <gpui_gpu::renderer::images::prepare+0x144>
  8235ce:	mov    0x18(%rbp),%rdi
  8235d2:	sub    %rax,%rdi
  8235d5:	add    $0xfffffffffffffff0,%rdi
  8235d9:	mov    $0x10,%edx
  8235de:	call   *0x65c204(%rip)        # e7f7e8 <_DYNAMIC+0x248>
  8235e4:	mov    $0x80,%esi
  8235e9:	mov    $0x8,%edx
  8235ee:	mov    %rbp,%rdi
  8235f1:	call   *0x65c1f1(%rip)        # e7f7e8 <_DYNAMIC+0x248>
  8235f7:	shl    $0x4,%r12
  8235fb:	cmp    $0x101,%r12
  823602:	mov    $0x100,%eax
  823607:	cmovae %r12,%rax
  82360b:	dec    %rax
  82360e:	bsr    %rax,%rcx
  823612:	not    %ecx
  823614:	mov    $0xffffffffffffffff,%rbx
  82361b:	shr    %cl,%rbx
  82361e:	inc    %rbx
  823621:	lea    -0x74ed86(%rip),%rax        # d48a2 <anon.81378166eea1c96e15e7851dcdc35f4e.0.llvm.4385859340901971677+0x16>
  823628:	mov    %rax,0x20(%rsp)
  82362d:	movq   $0xa,0x28(%rsp)
  823636:	mov    %rbx,0x30(%rsp)
  82363b:	movl   $0x88,0x38(%rsp)
  823643:	movb   $0x0,0x3c(%rsp)
  823648:	lea    0xe0(%rsp),%rdi
  823650:	lea    0x20(%rsp),%rdx
  823655:	mov    0x8(%rsp),%rsi
  82365a:	call   *0x65c560(%rip)        # e7fbc0 <_DYNAMIC+0x620>
  823660:	mov    %rbx,0x100(%rsp)
  823668:	mov    0x0(%r13),%rax
  82366c:	lock decq (%rax)
  823670:	jne    82367b <gpui_gpu::renderer::images::prepare+0x1db>
  823672:	mov    %r13,%rdi
  823675:	call   *0x65c42d(%rip)        # e7faa8 <_DYNAMIC+0x508>
  82367b:	mov    0x8(%r13),%rax
  82367f:	lock decq (%rax)
  823683:	jne    82368f <gpui_gpu::renderer::images::prepare+0x1ef>
  823685:	lea    0x8(%r13),%rdi
  823689:	call   *0x65c421(%rip)        # e7fab0 <_DYNAMIC+0x510>
  82368f:	mov    0x100(%rsp),%rax
  823697:	mov    %rax,0x20(%r13)
  82369b:	movdqu 0xe0(%rsp),%xmm0
  8236a4:	movups 0xf0(%rsp),%xmm1
  8236ac:	movups %xmm1,0x10(%r13)
  8236b1:	movdqu %xmm0,0x0(%r13)
  8236b7:	test   %rbp,%rbp
  8236ba:	setne  0x4(%r15)
  8236bf:	movl   $0xffffffff,(%r15)
  8236c6:	mov    %r15,%rax
  8236c9:	add    $0x1f8,%rsp
  8236d0:	pop    %rbx
  8236d1:	pop    %r12
  8236d3:	pop    %r13
  8236d5:	pop    %r14
  8236d7:	pop    %r15
  8236d9:	pop    %rbp
  8236da:	ret
  8236db:	cmp    $0x1,%r12
  8236df:	mov    %r12,%rax
  8236e2:	adc    $0xffffffffffffffff,%rax
  8236e6:	bsr    %rax,%rcx
  8236ea:	not    %ecx
  8236ec:	mov    $0xffffffffffffffff,%rax
  8236f3:	shr    %cl,%rax
  8236f6:	cmp    $0x2,%r12
  8236fa:	mov    $0x0,%r12d
  823700:	cmovae %rax,%r12
  823704:	inc    %r12
  823707:	je     823e32 <gpui_gpu::renderer::images::prepare+0x992>
  82370d:	mov    %r8,0xd0(%rsp)
  823715:	mov    %fs:0x0,%rax
  82371e:	lea    -0x28(%rax),%rax
  823725:	mov    %rax,%rcx
  823728:	cmpb   $0x1,0x10(%rax)
  82372c:	mov    %r15,0xb0(%rsp)
  823734:	mov    %r13,0xd8(%rsp)
  82373c:	jne    823e3e <gpui_gpu::renderer::images::prepare+0x99e>
  823742:	mov    (%rcx),%rax
  823745:	mov    0x8(%rcx),%rdx
  823749:	mov    0x18(%rsp),%rbx
  82374e:	lea    0x1(%rax),%rsi
  823752:	mov    %rsi,(%rcx)
  823755:	movq   $0x0,0x20(%rsp)
  82375e:	movq   $0x8,0x28(%rsp)
  823767:	movq   $0x0,0x30(%rsp)
  823770:	movups 0x60aaf1(%rip),%xmm0        # e2e268 <anon.81378166eea1c96e15e7851dcdc35f4e.2.llvm.4385859340901971677+0x18>
  823777:	movups %xmm0,0x38(%rsp)
  82377c:	movdqu 0x60aaf4(%rip),%xmm0        # e2e278 <anon.81378166eea1c96e15e7851dcdc35f4e.2.llvm.4385859340901971677+0x28>
  823784:	movdqu %xmm0,0x48(%rsp)
  82378a:	mov    %rax,0x58(%rsp)
  82378f:	mov    %rdx,0x60(%rsp)
  823794:	mov    %r12,0x68(%rsp)
  823799:	pxor   %xmm0,%xmm0
  82379d:	movdqu %xmm0,0x70(%rsp)
  8237a3:	movdqu %xmm0,0x80(%rsp)
  8237ac:	movdqu %xmm0,0x90(%rsp)
  8237b5:	lea    0xe0(%rsp),%rdi
  8237bd:	mov    $0x8,%edx
  8237c2:	mov    $0x8,%r8d
  8237c8:	mov    $0x8,%r9d
  8237ce:	xor    %esi,%esi
  8237d0:	mov    %rbx,%rcx
  8237d3:	call   825370 <<alloc::raw_vec::RawVecInner>::finish_grow>
  8237d8:	cmpl   $0x1,0xe0(%rsp)
  8237e0:	jne    82384d <gpui_gpu::renderer::images::prepare+0x3ad>
  8237e2:	mov    0xb0(%rsp),%r15
  8237ea:	movl   $0x6,(%r15)
  8237f1:	mov    0x20(%rsp),%rsi
  8237f6:	test   %rsi,%rsi
  8237f9:	je     82380f <gpui_gpu::renderer::images::prepare+0x36f>
  8237fb:	mov    0x28(%rsp),%rdi
  823800:	shl    $0x3,%rsi
  823804:	mov    $0x8,%edx
  823809:	call   *0x65bfd9(%rip)        # e7f7e8 <_DYNAMIC+0x248>
  82380f:	mov    0x40(%rsp),%rsi
  823814:	test   %rsi,%rsi
  823817:	je     8236c6 <gpui_gpu::renderer::images::prepare+0x226>
  82381d:	mov    %rsi,%rax
  823820:	shl    $0x4,%rax
  823824:	add    %rax,%rsi
  823827:	add    $0x21,%rsi
  82382b:	je     8236c6 <gpui_gpu::renderer::images::prepare+0x226>
  823831:	mov    0x38(%rsp),%rdi
  823836:	sub    %rax,%rdi
  823839:	add    $0xfffffffffffffff0,%rdi
  82383d:	mov    $0x10,%edx
  823842:	call   *0x65bfa0(%rip)        # e7f7e8 <_DYNAMIC+0x248>
  823848:	jmp    8236c6 <gpui_gpu::renderer::images::prepare+0x226>
  82384d:	mov    %r12,0xa0(%rsp)
  823855:	mov    %rbp,0xc8(%rsp)
  82385d:	mov    0xe8(%rsp),%rax
  823865:	mov    %rax,0x28(%rsp)
  82386a:	mov    %rbx,0x20(%rsp)
  82386f:	cmp    0x48(%rsp),%rbx
  823874:	ja     823e5a <gpui_gpu::renderer::images::prepare+0x9ba>
  82387a:	xor    %r12d,%r12d
  82387d:	mov    0xa0(%rsp),%r15
  823885:	jmp    8238a8 <gpui_gpu::renderer::images::prepare+0x408>
  823887:	nopw   0x0(%rax,%rax,1)
  823890:	add    $0x8,%r12
  823894:	mov    0x28(%rsp),%rax
  823899:	mov    %rbx,(%rax,%r15,8)
  82389d:	inc    %r15
  8238a0:	mov    %r15,0x30(%rsp)
  8238a5:	mov    %r13,%r15
  8238a8:	test   %r12,%r12
  8238ab:	je     8238d0 <gpui_gpu::renderer::images::prepare+0x430>
  8238ad:	cmp    %rbp,%r12
  8238b0:	je     8238d0 <gpui_gpu::renderer::images::prepare+0x430>
  8238b2:	mov    (%r12),%rcx
  8238b6:	cmpb   $0x0,0x10(%rcx)
  8238ba:	je     8238fe <gpui_gpu::renderer::images::prepare+0x45e>
  8238bc:	mov    0x20(%rcx),%rax
  8238c0:	shl    $0x4,%rax
  8238c4:	mov    $0x8,%r8d
  8238ca:	jmp    823911 <gpui_gpu::renderer::images::prepare+0x471>
  8238cc:	nopl   0x0(%rax)
  8238d0:	test   %r14,%r14
  8238d3:	je     823998 <gpui_gpu::renderer::images::prepare+0x4f8>
  8238d9:	mov    (%r14),%rax
  8238dc:	mov    0x10(%rax),%rcx
  8238e0:	test   %rcx,%rcx
  8238e3:	je     823998 <gpui_gpu::renderer::images::prepare+0x4f8>
  8238e9:	mov    0x8(%rax),%r12
  8238ed:	lea    (%r12,%rcx,8),%rbp
  8238f1:	xor    %r14d,%r14d
  8238f4:	mov    (%r12),%rcx
  8238f8:	cmpb   $0x0,0x10(%rcx)
  8238fc:	jne    8238bc <gpui_gpu::renderer::images::prepare+0x41c>
  8238fe:	movzbl 0x11(%rcx),%edx
  823902:	movzbl 0x12(%rcx),%esi
  823906:	mov    0x20(%rcx),%rax
  82390a:	shl    $0x2,%edx
  82390d:	lea    (%rdx,%rsi,2),%r8d
  823911:	mov    0x78(%rsp),%rdx
  823916:	add    %rax,%rdx
  823919:	jb     8237e2 <gpui_gpu::renderer::images::prepare+0x342>
  82391f:	mov    0x28(%rcx),%rbx
  823923:	mov    %rdx,0x78(%rsp)
  823928:	cmp    $0x4000000,%rdx
  82392f:	ja     8237e2 <gpui_gpu::renderer::images::prepare+0x342>
  823935:	mov    %r15,%rcx
  823938:	shr    $0x20,%rcx
  82393c:	jne    8237e2 <gpui_gpu::renderer::images::prepare+0x342>
  823942:	test   %r15d,%r15d
  823945:	js     8237e2 <gpui_gpu::renderer::images::prepare+0x342>
  82394b:	mov    %rax,%r13
  82394e:	shr    $0x4,%r13
  823952:	and    $0xf,%eax
  823955:	add    %r15,%r13
  823958:	cmp    $0x1,%rax
  82395c:	sbb    $0xffffffffffffffff,%r13
  823960:	lea    0xe0(%rsp),%rdi
  823968:	lea    0x38(%rsp),%rsi
  82396d:	mov    %rbx,%rdx
  823970:	mov    %r15d,%ecx
  823973:	call   8259c0 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert>
  823978:	mov    0x30(%rsp),%r15
  82397d:	cmp    0x20(%rsp),%r15
  823982:	jne    823890 <gpui_gpu::renderer::images::prepare+0x3f0>
  823988:	lea    0x20(%rsp),%rdi
  82398d:	call   *0x65c2d5(%rip)        # e7fc68 <_DYNAMIC+0x6c8>
  823993:	jmp    823890 <gpui_gpu::renderer::images::prepare+0x3f0>
  823998:	movabs $0xffffffffffffff0,%rax
  8239a2:	cmp    %rax,%r15
  8239a5:	ja     8237e2 <gpui_gpu::renderer::images::prepare+0x342>
  8239ab:	lea    0xe0(%rsp),%rdi
  8239b3:	mov    0x8(%rsp),%rsi
  8239b8:	call   *0x65c2b2(%rip)        # e7fc70 <_DYNAMIC+0x6d0>
  8239be:	mov    %r15,%rbx
  8239c1:	shl    $0x4,%rbx
  8239c5:	add    $0xff,%rbx
  8239cc:	and    $0xffffffffffffff00,%rbx
  8239d3:	cmp    0x130(%rsp),%rbx
  8239db:	ja     8237e2 <gpui_gpu::renderer::images::prepare+0x342>
  8239e1:	lea    0xe0(%rsp),%rdi
  8239e9:	mov    0x8(%rsp),%rsi
  8239ee:	call   *0x65c27c(%rip)        # e7fc70 <_DYNAMIC+0x6d0>
  8239f4:	cmp    0x140(%rsp),%rbx
  8239fc:	ja     8237e2 <gpui_gpu::renderer::images::prepare+0x342>
  823a02:	mov    0xd8(%rsp),%r14
  823a0a:	mov    0x20(%r14),%rax
  823a0e:	cmp    %rbx,%rax
  823a11:	jb     823a42 <gpui_gpu::renderer::images::prepare+0x5a2>
  823a13:	lea    0x0(,%rbx,4),%rcx
  823a1b:	movabs $0x3fffffffffffff1,%rdx
  823a25:	cmp    %rdx,%r15
  823a28:	setb   %dl
  823a2b:	cmp    %rcx,%rax
  823a2e:	seta   %al
  823a31:	test   %al,%dl
  823a33:	jne    823a42 <gpui_gpu::renderer::images::prepare+0x5a2>
  823a35:	movl   $0x0,0x14(%rsp)
  823a3d:	jmp    823ad5 <gpui_gpu::renderer::images::prepare+0x635>
  823a42:	lea    -0x74f19d(%rip),%rax        # d48ac <anon.81378166eea1c96e15e7851dcdc35f4e.0.llvm.4385859340901971677+0x20>
  823a49:	mov    %rax,0x1d8(%rsp)
  823a51:	movq   $0x1d,0x1e0(%rsp)
  823a5d:	mov    %rbx,0x1e8(%rsp)
  823a65:	movl   $0x88,0x1f0(%rsp)
  823a70:	movb   $0x0,0x1f4(%rsp)
  823a78:	lea    0xe0(%rsp),%rdi
  823a80:	lea    0x1d8(%rsp),%rdx
  823a88:	mov    0x8(%rsp),%rsi
  823a8d:	call   *0x65c12d(%rip)        # e7fbc0 <_DYNAMIC+0x620>
  823a93:	mov    %rbx,0x100(%rsp)
  823a9b:	mov    %r14,%r15
  823a9e:	mov    %r14,%rdi
  823aa1:	call   822eb0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  823aa6:	mov    0x100(%rsp),%rax
  823aae:	mov    %rax,0x20(%r15)
  823ab2:	movdqu 0xe0(%rsp),%xmm0
  823abb:	movdqu 0xf0(%rsp),%xmm1
  823ac4:	movdqu %xmm1,0x10(%r15)
  823aca:	movdqu %xmm0,(%r15)
  823acf:	mov    $0x1,%al
  823ad1:	mov    %eax,0x14(%rsp)
  823ad5:	movq   $0x0,0x8(%rsp)
  823ade:	mov    0x8(%rsp),%rdx
  823ae3:	test   %rdx,%rdx
  823ae6:	je     823af2 <gpui_gpu::renderer::images::prepare+0x652>
  823ae8:	cmp    0xc0(%rsp),%rdx
  823af0:	jne    823b2f <gpui_gpu::renderer::images::prepare+0x68f>
  823af2:	mov    0xa8(%rsp),%rax
  823afa:	test   %rax,%rax
  823afd:	je     823cc5 <gpui_gpu::renderer::images::prepare+0x825>
  823b03:	mov    (%rax),%rax
  823b06:	mov    0x10(%rax),%rcx
  823b0a:	test   %rcx,%rcx
  823b0d:	je     823cc5 <gpui_gpu::renderer::images::prepare+0x825>
  823b13:	mov    0x8(%rax),%rdx
  823b17:	lea    (%rdx,%rcx,8),%rax
  823b1b:	mov    %rax,0xc0(%rsp)
  823b23:	movq   $0x0,0xa8(%rsp)
  823b2f:	mov    (%rdx),%rax
  823b32:	mov    0x28(%rax),%r12
  823b36:	movzbl 0x10(%rax),%ebx
  823b3a:	mov    0x18(%rax),%rbp
  823b3e:	mov    0x20(%rax),%r13
  823b42:	mov    %r12,0xe0(%rsp)
  823b4a:	cmpq   $0x0,0x50(%rsp)
  823b50:	je     823caa <gpui_gpu::renderer::images::prepare+0x80a>
  823b56:	add    $0x8,%rdx
  823b5a:	mov    %rdx,0x8(%rsp)
  823b5f:	lea    0x58(%rsp),%rdi
  823b64:	lea    0xe0(%rsp),%rsi
  823b6c:	call   8243d0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  823b71:	mov    %rax,%rsi
  823b74:	shr    $0x39,%rsi
  823b78:	mov    0x38(%rsp),%rcx
  823b7d:	mov    0x40(%rsp),%rdx
  823b82:	movd   %esi,%xmm0
  823b86:	punpcklbw %xmm0,%xmm0
  823b8a:	pshuflw $0x0,%xmm0,%xmm0
  823b8f:	pshufd $0x44,%xmm0,%xmm0
  823b94:	xor    %esi,%esi
  823b96:	and    %rdx,%rax
  823b99:	movdqu (%rcx,%rax,1),%xmm1
  823b9e:	movdqa %xmm1,%xmm2
  823ba2:	pcmpeqb %xmm0,%xmm2
  823ba6:	pmovmskb %xmm2,%edi
  823baa:	test   %edi,%edi
  823bac:	je     823bd6 <gpui_gpu::renderer::images::prepare+0x736>
  823bae:	tzcnt  %edi,%r9d
  823bb3:	add    %rax,%r9
  823bb6:	and    %rdx,%r9
  823bb9:	shl    $0x4,%r9
  823bbd:	mov    %rcx,%r8
  823bc0:	sub    %r9,%r8
  823bc3:	cmp    -0x10(%r8),%r12
  823bc7:	je     823bf7 <gpui_gpu::renderer::images::prepare+0x757>
  823bc9:	lea    -0x1(%rdi),%r8d
  823bcd:	and    %di,%r8w
  823bd1:	mov    %r8d,%edi
  823bd4:	jne    823bae <gpui_gpu::renderer::images::prepare+0x70e>
  823bd6:	pcmpeqd %xmm2,%xmm2
  823bda:	pcmpeqb %xmm2,%xmm1
  823bde:	pmovmskb %xmm1,%edi
  823be2:	test   %edi,%edi
  823be4:	jne    823caa <gpui_gpu::renderer::images::prepare+0x80a>
  823bea:	add    %rsi,%rax
  823bed:	add    $0x10,%rax
  823bf1:	add    $0x10,%rsi
  823bf5:	jmp    823b96 <gpui_gpu::renderer::images::prepare+0x6f6>
  823bf7:	mov    -0x8(%r8),%r12d
  823bfb:	shl    $0x4,%r12
  823bff:	test   %bl,%bl
  823c01:	je     823c58 <gpui_gpu::renderer::images::prepare+0x7b8>
  823c03:	test   %r13,%r13
  823c06:	je     823ade <gpui_gpu::renderer::images::prepare+0x63e>
  823c0c:	nopl   0x0(%rax)
  823c10:	cmp    $0x1000,%r13
  823c17:	mov    $0x1000,%r15d
  823c1d:	cmovb  %r13,%r15
  823c21:	mov    %r15d,%ebx
  823c24:	shl    $0x4,%ebx
  823c27:	mov    0xb8(%rsp),%rdi
  823c2f:	mov    %r14,%rsi
  823c32:	mov    %r12,%rdx
  823c35:	mov    %rbp,%rcx
  823c38:	mov    %rbx,%r8
  823c3b:	call   *0x65bf2f(%rip)        # e7fb70 <_DYNAMIC+0x5d0>
  823c41:	mov    %r15,%rax
  823c44:	shl    $0x4,%rax
  823c48:	add    %rax,%rbp
  823c4b:	add    %rbx,%r12
  823c4e:	sub    %r15,%r13
  823c51:	jne    823c10 <gpui_gpu::renderer::images::prepare+0x770>
  823c53:	jmp    823ade <gpui_gpu::renderer::images::prepare+0x63e>
  823c58:	test   %r13,%r13
  823c5b:	je     823ade <gpui_gpu::renderer::images::prepare+0x63e>
  823c61:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  823c70:	cmp    $0x10000,%r13
  823c77:	mov    $0x10000,%ebx
  823c7c:	cmovb  %r13,%rbx
  823c80:	mov    0xb8(%rsp),%rdi
  823c88:	mov    %r14,%rsi
  823c8b:	mov    %r12,%rdx
  823c8e:	mov    %rbp,%rcx
  823c91:	mov    %rbx,%r8
  823c94:	call   *0x65bed6(%rip)        # e7fb70 <_DYNAMIC+0x5d0>
  823c9a:	add    %rbx,%rbp
  823c9d:	add    %rbx,%r12
  823ca0:	sub    %rbx,%r13
  823ca3:	jne    823c70 <gpui_gpu::renderer::images::prepare+0x7d0>
  823ca5:	jmp    823ade <gpui_gpu::renderer::images::prepare+0x63e>
  823caa:	lea    -0x74f425(%rip),%rdi        # d488c <anon.81378166eea1c96e15e7851dcdc35f4e.0.llvm.4385859340901971677>
  823cb1:	lea    0x60a5d0(%rip),%rdx        # e2e288 <anon.81378166eea1c96e15e7851dcdc35f4e.2.llvm.4385859340901971677+0x38>
  823cb8:	mov    $0x16,%esi
  823cbd:	call   *0x65be7d(%rip)        # e7fb40 <_DYNAMIC+0x5a0>
  823cc3:	ud2
  823cc5:	mov    0x18(%rsp),%rax
  823cca:	mov    %rax,0x70(%rsp)
  823ccf:	mov    0x78(%rsp),%rax
  823cd4:	mov    %rax,0x80(%rsp)
  823cdc:	mov    0xa0(%rsp),%rax
  823ce4:	shl    $0x4,%rax
  823ce8:	mov    %rax,0x88(%rsp)
  823cf0:	mov    0x20(%r14),%rax
  823cf4:	mov    %rax,0x90(%rsp)
  823cfc:	mov    0x48(%rsp),%rax
  823d01:	add    0x50(%rsp),%rax
  823d06:	mov    %rax,0x98(%rsp)
  823d0e:	mov    0x90(%rsp),%rax
  823d16:	mov    %rax,0x150(%rsp)
  823d1e:	mov    0x98(%rsp),%rax
  823d26:	mov    %rax,0x158(%rsp)
  823d2e:	mov    0x80(%rsp),%rax
  823d36:	mov    %rax,0x140(%rsp)
  823d3e:	mov    0x88(%rsp),%rax
  823d46:	mov    %rax,0x148(%rsp)
  823d4e:	movups 0x70(%rsp),%xmm0
  823d53:	movaps %xmm0,0x130(%rsp)
  823d5b:	movups 0x60(%rsp),%xmm0
  823d60:	movaps %xmm0,0x120(%rsp)
  823d68:	movups 0x50(%rsp),%xmm0
  823d6d:	movaps %xmm0,0x110(%rsp)
  823d75:	movups 0x20(%rsp),%xmm0
  823d7a:	movups 0x30(%rsp),%xmm1
  823d7f:	movups 0x40(%rsp),%xmm2
  823d84:	movaps %xmm2,0x100(%rsp)
  823d8c:	movaps %xmm1,0xf0(%rsp)
  823d94:	movaps %xmm0,0xe0(%rsp)
  823d9c:	call   823470 <alloc::boxed::box_new_uninit>
  823da1:	mov    %rax,%rbx
  823da4:	movaps 0x150(%rsp),%xmm0
  823dac:	movups %xmm0,0x70(%rax)
  823db0:	movaps 0x140(%rsp),%xmm0
  823db8:	movups %xmm0,0x60(%rax)
  823dbc:	movaps 0x130(%rsp),%xmm0
  823dc4:	movups %xmm0,0x50(%rax)
  823dc8:	movaps 0x120(%rsp),%xmm0
  823dd0:	movups %xmm0,0x40(%rax)
  823dd4:	movdqa 0xe0(%rsp),%xmm0
  823ddd:	movaps 0xf0(%rsp),%xmm1
  823de5:	movaps 0x100(%rsp),%xmm2
  823ded:	movaps 0x110(%rsp),%xmm3
  823df5:	movups %xmm3,0x30(%rax)
  823df9:	movups %xmm2,0x20(%rax)
  823dfd:	movups %xmm1,0x10(%rax)
  823e01:	movdqu %xmm0,(%rax)
  823e05:	mov    0xc8(%rsp),%rdi
  823e0d:	call   822c20 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>
  823e12:	mov    0xd0(%rsp),%rax
  823e1a:	mov    %rbx,(%rax)
  823e1d:	mov    0xb0(%rsp),%r15
  823e25:	mov    0x14(%rsp),%eax
  823e29:	mov    %al,0x4(%r15)
  823e2d:	jmp    8236bf <gpui_gpu::renderer::images::prepare+0x21f>
  823e32:	movl   $0x6,(%r15)
  823e39:	jmp    8236c6 <gpui_gpu::renderer::images::prepare+0x226>
  823e3e:	mov    %rcx,%rbx
  823e41:	call   *0x65bd81(%rip)        # e7fbc8 <_DYNAMIC+0x628>
  823e47:	mov    %rbx,%rcx
  823e4a:	mov    %rax,(%rbx)
  823e4d:	mov    %rdx,0x8(%rbx)
  823e51:	movb   $0x1,0x10(%rbx)
  823e55:	jmp    823749 <gpui_gpu::renderer::images::prepare+0x2a9>
  823e5a:	lea    0x38(%rsp),%rdi
  823e5f:	mov    0x18(%rsp),%rsi
  823e64:	lea    0x58(%rsp),%rdx
  823e69:	xor    %ecx,%ecx
  823e6b:	call   *0x65bdcf(%rip)        # e7fc40 <_DYNAMIC+0x6a0>
  823e71:	cmp    $0xffffffffffffffff,%rax
  823e75:	jne    8237e2 <gpui_gpu::renderer::images::prepare+0x342>
  823e7b:	jmp    82387a <gpui_gpu::renderer::images::prepare+0x3da>
  823e80:	mov    %rax,%rbx
  823e83:	lea    0xe0(%rsp),%rdi
  823e8b:	call   822fe0 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>
  823e90:	mov    %rbx,%rdi
  823e93:	call   e2c310 <_Unwind_Resume@plt>
  823e98:	mov    %rax,%rbx
  823e9b:	mov    0x100(%rsp),%rax
  823ea3:	mov    %rax,0x20(%r15)
  823ea7:	movups 0xe0(%rsp),%xmm0
  823eaf:	movups 0xf0(%rsp),%xmm1
  823eb7:	movups %xmm1,0x10(%r15)
  823ebc:	movups %xmm0,(%r15)
  823ec0:	lea    0x20(%rsp),%rdi
  823ec5:	call   822fe0 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>
  823eca:	mov    %rbx,%rdi
  823ecd:	call   e2c310 <_Unwind_Resume@plt>
  823ed2:	mov    %r13,%r14
  823ed5:	mov    %rax,%rbx
  823ed8:	jmp    823ef4 <gpui_gpu::renderer::images::prepare+0xa54>
  823eda:	mov    %rax,%rbx
  823edd:	mov    %r13,%r14
  823ee0:	mov    0x8(%r13),%rax
  823ee4:	lock decq (%rax)
  823ee8:	jne    823ef4 <gpui_gpu::renderer::images::prepare+0xa54>
  823eea:	lea    0x8(%r14),%rdi
  823eee:	call   *0x65bbbc(%rip)        # e7fab0 <_DYNAMIC+0x510>
  823ef4:	mov    0x100(%rsp),%rax
  823efc:	mov    %rax,0x20(%r14)
  823f00:	movups 0xe0(%rsp),%xmm0
  823f08:	movups 0xf0(%rsp),%xmm1
  823f10:	movups %xmm1,0x10(%r14)
  823f15:	movups %xmm0,(%r14)
  823f19:	mov    %rbx,%rdi
  823f1c:	call   e2c310 <_Unwind_Resume@plt>
  823f21:	call   *0x65b8c9(%rip)        # e7f7f0 <_DYNAMIC+0x250>
  823f27:	jmp    823f2d <gpui_gpu::renderer::images::prepare+0xa8d>
  823f29:	jmp    823f2d <gpui_gpu::renderer::images::prepare+0xa8d>
  823f2b:	jmp    823f2d <gpui_gpu::renderer::images::prepare+0xa8d>
  823f2d:	mov    %rax,%rbx
  823f30:	lea    0x20(%rsp),%rdi
  823f35:	call   822fe0 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>
  823f3a:	mov    %rbx,%rdi
  823f3d:	call   e2c310 <_Unwind_Resume@plt>

/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000824b60 <gpui_gpu::renderer::slots::color_word>:
  824b60:	lea    -0x3(%rsi),%eax
  824b63:	cmp    %rax,%rdi
  824b66:	jbe    824b7f <gpui_gpu::renderer::slots::color_word+0x1f>
  824b68:	mov    %rdi,%rax
  824b6b:	shr    $0x6,%rax
  824b6f:	and    $0x3f,%edi
  824b72:	cmp    $0x1,%rdi
  824b76:	sbb    $0xffffffff,%eax
  824b79:	add    %esi,%eax
  824b7b:	add    $0xfffffffe,%eax
  824b7e:	ret
  824b7f:	push   %rax
  824b80:	lea    -0x7502be(%rip),%rdi        # d48c9 <anon.13aa504c895bbdabfa4c7600bbc56189.10.llvm.13360435204432610515>
  824b87:	lea    0x60974a(%rip),%rdx        # e2e2d8 <anon.13aa504c895bbdabfa4c7600bbc56189.11.llvm.13360435204432610515>
  824b8e:	mov    $0x1e,%esi
  824b93:	call   *0x65af6f(%rip)        # e7fb08 <_DYNAMIC+0x568>

/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000824ba0 <gpui_gpu::renderer::slots::write_prefix>:
  824ba0:	push   %rbp
  824ba1:	push   %r15
  824ba3:	push   %r14
  824ba5:	push   %r13
  824ba7:	push   %r12
  824ba9:	push   %rbx
  824baa:	sub    $0x38,%rsp
  824bae:	mov    %rdi,0x18(%rsp)
  824bb3:	test   %rcx,%rcx
  824bb6:	je     824dd1 <gpui_gpu::renderer::slots::write_prefix+0x231>
  824bbc:	mov    %rsi,%rbx
  824bbf:	xor    %r12d,%r12d
  824bc2:	test   $0x3f,%cl
  824bc5:	setne  %al
  824bc8:	test   %rsi,%rsi
  824bcb:	je     824e07 <gpui_gpu::renderer::slots::write_prefix+0x267>
  824bd1:	mov    %r8,%r14
  824bd4:	mov    %rcx,%rsi
  824bd7:	shr    $0x6,%rsi
  824bdb:	mov    %al,%r12b
  824bde:	mov    %rsi,0x8(%rsp)
  824be3:	add    %r12,%rsi
  824be6:	lea    0x1(%rsi),%eax
  824be9:	mov    %rsi,0x10(%rsp)
  824bee:	shl    $0x20,%rsi
  824bf2:	mov    %ecx,%ecx
  824bf4:	or     %rsi,%rcx
  824bf7:	mov    0x8(%r8),%r13
  824bfb:	mov    0x18(%rsp),%r8
  824c00:	mov    (%r8),%rsi
  824c03:	xor    %rcx,%rsi
  824c06:	mov    0x8(%r8),%rdi
  824c0a:	xor    %rax,%rdi
  824c0d:	or     %rsi,%rdi
  824c10:	jne    824c17 <gpui_gpu::renderer::slots::write_prefix+0x77>
  824c12:	mov    (%r14),%rbp
  824c15:	jmp    824c33 <gpui_gpu::renderer::slots::write_prefix+0x93>
  824c17:	movq   $0x0,(%r14)
  824c1e:	cmp    $0x1,%r13
  824c22:	adc    $0x0,%r13
  824c26:	mov    %r13,0x8(%r14)
  824c2a:	mov    %rax,0x8(%r8)
  824c2e:	mov    %rcx,(%r8)
  824c31:	xor    %ebp,%ebp
  824c33:	mov    %r8,%r15
  824c36:	mov    %rdx,%rdi
  824c39:	call   *0x65af09(%rip)        # e7fb48 <_DYNAMIC+0x5a8>
  824c3f:	mov    0x8(%rsp),%rcx
  824c44:	shl    $0x4,%rcx
  824c48:	shl    $0x4,%r12d
  824c4c:	add    %rcx,%r12
  824c4f:	lea    (%r15,%r12,1),%r8
  824c53:	add    $0x10,%r8
  824c57:	xor    %r10d,%r10d
  824c5a:	xorps  %xmm0,%xmm0
  824c5d:	mov    0x10(%rsp),%r9
  824c62:	jmp    824c86 <gpui_gpu::renderer::slots::write_prefix+0xe6>
  824c64:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  824c70:	add    $0x40,%r9
  824c74:	add    $0x400,%r8
  824c7b:	cmp    0x10(%rsp),%r10
  824c80:	je     824dd1 <gpui_gpu::renderer::slots::write_prefix+0x231>
  824c86:	mov    %r10,0x8(%rsp)
  824c8b:	lea    0x1(%r10),%rcx
  824c8f:	mov    %rcx,(%rsp)
  824c93:	movaps %xmm0,0x20(%rsp)
  824c98:	mov    $0xffffffffffffffc0,%r11
  824c9f:	xor    %esi,%esi
  824ca1:	jmp    824cc1 <gpui_gpu::renderer::slots::write_prefix+0x121>
  824ca3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  824cb0:	add    $0x18,%rax
  824cb4:	add    $0x2,%rsi
  824cb8:	inc    %r11
  824cbb:	je     824d50 <gpui_gpu::renderer::slots::write_prefix+0x1b0>
  824cc1:	cmp    %rdx,%rax
  824cc4:	je     824d50 <gpui_gpu::renderer::slots::write_prefix+0x1b0>
  824cca:	lea    0x40(%r11),%r10
  824cce:	movzwl 0x10(%rax),%edi
  824cd2:	movzwl 0x12(%rax),%ecx
  824cd6:	mov    (%rax),%r12
  824cd9:	mov    0x8(%rax),%r15
  824cdd:	shr    $0xe,%ecx
  824ce0:	and    $0x2,%ecx
  824ce3:	shr    $0xf,%edi
  824ce6:	or     %ecx,%edi
  824ce8:	mov    %esi,%ecx
  824cea:	and    $0x1e,%cl
  824ced:	shl    %cl,%edi
  824cef:	shr    $0x4,%r10
  824cf3:	or     %edi,0x20(%rsp,%r10,4)
  824cf8:	lea    (%r9,%r11,1),%rcx
  824cfc:	add    $0x41,%rcx
  824d00:	cmp    %rbx,%rcx
  824d03:	jae    824de0 <gpui_gpu::renderer::slots::write_prefix+0x240>
  824d09:	mov    (%r8,%rsi,8),%rdi
  824d0d:	xor    %r12,%rdi
  824d10:	mov    0x8(%r8,%rsi,8),%r10
  824d15:	xor    %r15,%r10
  824d18:	or     %rdi,%r10
  824d1b:	je     824cb0 <gpui_gpu::renderer::slots::write_prefix+0x110>
  824d1d:	cmp    %rbp,%rcx
  824d20:	cmovb  %rcx,%rbp
  824d24:	lea    (%r9,%r11,1),%rcx
  824d28:	add    $0x42,%rcx
  824d2c:	cmp    %r13,%rcx
  824d2f:	cmova  %rcx,%r13
  824d33:	mov    %rbp,(%r14)
  824d36:	mov    %r13,0x8(%r14)
  824d3a:	mov    %r15,0x8(%r8,%rsi,8)
  824d3f:	mov    %r12,(%r8,%rsi,8)
  824d43:	jmp    824cb0 <gpui_gpu::renderer::slots::write_prefix+0x110>
  824d48:	nopl   0x0(%rax,%rax,1)
  824d50:	lea    -0x1(%rbx),%rcx
  824d54:	mov    0x8(%rsp),%rdi
  824d59:	cmp    %rcx,%rdi
  824d5c:	je     824df3 <gpui_gpu::renderer::slots::write_prefix+0x253>
  824d62:	mov    0x20(%rsp),%rsi
  824d67:	mov    0x28(%rsp),%r12
  824d6c:	lea    0x1(%rdi),%r10
  824d70:	mov    %rdi,%rcx
  824d73:	mov    %r10,%r11
  824d76:	shl    $0x4,%r11
  824d7a:	mov    0x18(%rsp),%rdi
  824d7f:	mov    0x8(%rdi,%r11,1),%r15
  824d84:	mov    %r12,0x30(%rsp)
  824d89:	xor    %r12,%r15
  824d8c:	mov    (%rdi,%r11,1),%r12
  824d90:	mov    %rsi,(%rsp)
  824d94:	xor    %rsi,%r12
  824d97:	or     %r15,%r12
  824d9a:	je     824c70 <gpui_gpu::renderer::slots::write_prefix+0xd0>
  824da0:	add    %rdi,%r11
  824da3:	cmp    %rbp,%r10
  824da6:	cmovb  %r10,%rbp
  824daa:	add    $0x2,%rcx
  824dae:	cmp    %r13,%rcx
  824db1:	cmova  %rcx,%r13
  824db5:	mov    %rbp,(%r14)
  824db8:	mov    %r13,0x8(%r14)
  824dbc:	mov    0x30(%rsp),%rcx
  824dc1:	mov    %rcx,0x8(%r11)
  824dc5:	mov    (%rsp),%rcx
  824dc9:	mov    %rcx,(%r11)
  824dcc:	jmp    824c70 <gpui_gpu::renderer::slots::write_prefix+0xd0>
  824dd1:	add    $0x38,%rsp
  824dd5:	pop    %rbx
  824dd6:	pop    %r12
  824dd8:	pop    %r13
  824dda:	pop    %r14
  824ddc:	pop    %r15
  824dde:	pop    %rbp
  824ddf:	ret
  824de0:	lea    0x609241(%rip),%rdx        # e2e028 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.1466513483089798867>
  824de7:	mov    %rcx,%rdi
  824dea:	mov    %rbx,%rsi
  824ded:	call   *0x65aca5(%rip)        # e7fa98 <_DYNAMIC+0x4f8>
  824df3:	lea    0x60922e(%rip),%rdx        # e2e028 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.1466513483089798867>
  824dfa:	mov    (%rsp),%rdi
  824dfe:	mov    %rbx,%rsi
  824e01:	call   *0x65ac91(%rip)        # e7fa98 <_DYNAMIC+0x4f8>
  824e07:	lea    0x60921a(%rip),%rdx        # e2e028 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.1466513483089798867>
  824e0e:	xor    %edi,%edi
  824e10:	xor    %esi,%esi
  824e12:	call   *0x65ac80(%rip)        # e7fa98 <_DYNAMIC+0x4f8>

/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000824fc0 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>>:
  824fc0:	push   %r15
  824fc2:	push   %r14
  824fc4:	push   %rbx
  824fc5:	mov    (%rdx),%r9
  824fc8:	mov    0x8(%rdx),%r11
  824fcc:	mov    0x10(%rdx),%rbx
  824fd0:	mov    0x18(%rdx),%r10
  824fd4:	mov    0x20(%rdx),%r8
  824fd8:	mov    0x28(%rdx),%rcx
  824fdc:	test   $0x1,%r9b
  824fe0:	jne    82507a <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xba>
  824fe6:	mov    %rbx,%rax
  824fe9:	jmp    82500b <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x4b>
  824feb:	nopl   0x0(%rax,%rax,1)
  824ff0:	lea    0x8(%rax),%rbx
  824ff4:	mov    %rbx,%r14
  824ff7:	add    $0x8,%rdi
  824ffb:	mov    (%rax),%r15
  824ffe:	mov    %r14,%rax
  825001:	cmp    0x28(%r15),%rdx
  825005:	jne    8250cf <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  82500b:	cmp    %rsi,%rdi
  82500e:	je     8250a8 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xe8>
  825014:	mov    (%rdi),%rdx
  825017:	test   %rax,%rax
  82501a:	je     825023 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x63>
  82501c:	cmp    %r10,%rax
  82501f:	jne    824ff0 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x30>
  825021:	xor    %ebx,%ebx
  825023:	xor    %eax,%eax
  825025:	test   %r8,%r8
  825028:	je     8250d1 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  82502e:	cmp    %rcx,%r8
  825031:	je     8250d1 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  825037:	mov    %r8,%rax
  82503a:	add    $0x8,%r8
  82503e:	xor    %r14d,%r14d
  825041:	jmp    824ff7 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x37>
  825043:	mov    (%r11),%rax
  825046:	mov    0x8(%rax),%rbx
  82504a:	mov    0x10(%rax),%rax
  82504e:	lea    (%rbx,%rax,8),%r10
  825052:	test   %rax,%rax
  825055:	je     825091 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xd1>
  825057:	xor    %r11d,%r11d
  82505a:	nopw   0x0(%rax,%rax,1)
  825060:	mov    %r8,%rax
  825063:	mov    %rbx,%r8
  825066:	add    $0x8,%rbx
  82506a:	add    $0x8,%rdi
  82506e:	mov    (%r8),%r14
  825071:	mov    %rax,%r8
  825074:	cmp    0x28(%r14),%rdx
  825078:	jne    8250cf <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  82507a:	cmp    %rsi,%rdi
  82507d:	je     8250a8 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xe8>
  82507f:	mov    (%rdi),%rdx
  825082:	test   %rbx,%rbx
  825085:	je     82508c <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xcc>
  825087:	cmp    %r10,%rbx
  82508a:	jne    825060 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xa0>
  82508c:	test   %r11,%r11
  82508f:	jne    825043 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x83>
  825091:	xor    %eax,%eax
  825093:	test   %r8,%r8
  825096:	je     8250d1 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  825098:	cmp    %rcx,%r8
  82509b:	je     8250d1 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  82509d:	lea    0x8(%r8),%rax
  8250a1:	xor    %ebx,%ebx
  8250a3:	xor    %r11d,%r11d
  8250a6:	jmp    82506a <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xaa>
  8250a8:	test   %rbx,%rbx
  8250ab:	sete   %dl
  8250ae:	cmp    %r10,%rbx
  8250b1:	sete   %al
  8250b4:	or     %dl,%al
  8250b6:	test   $0x1,%r9b
  8250ba:	je     8250d7 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x117>
  8250bc:	test   %al,%al
  8250be:	je     8250cf <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  8250c0:	test   %r11,%r11
  8250c3:	je     8250db <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x11b>
  8250c5:	mov    (%r11),%rax
  8250c8:	cmpq   $0x0,0x10(%rax)
  8250cd:	je     8250db <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x11b>
  8250cf:	xor    %eax,%eax
  8250d1:	pop    %rbx
  8250d2:	pop    %r14
  8250d4:	pop    %r15
  8250d6:	ret
  8250d7:	test   %al,%al
  8250d9:	je     8250cf <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  8250db:	test   %r8,%r8
  8250de:	sete   %dl
  8250e1:	cmp    %rcx,%r8
  8250e4:	sete   %al
  8250e7:	or     %dl,%al
  8250e9:	pop    %rbx
  8250ea:	pop    %r14
  8250ec:	pop    %r15
  8250ee:	ret

/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000825300 <<alloc::raw_vec::RawVec<gpui_gpu::renderer::Correction>>::grow_one>:
  825300:	push   %r14
  825302:	push   %rbx
  825303:	sub    $0x18,%rsp
  825307:	mov    %rdi,%rbx
  82530a:	mov    (%rdi),%rsi
  82530d:	lea    (%rsi,%rsi,1),%rax
  825311:	cmp    $0x5,%rax
  825315:	mov    $0x4,%r14d
  82531b:	cmovae %rax,%r14
  82531f:	mov    0x8(%rdi),%rdx
  825323:	mov    %rsp,%rdi
  825326:	mov    $0x4,%r8d
  82532c:	mov    $0x20,%r9d
  825332:	mov    %r14,%rcx
  825335:	call   825370 <<alloc::raw_vec::RawVecInner>::finish_grow>
  82533a:	cmpl   $0x1,(%rsp)
  82533e:	je     825354 <<alloc::raw_vec::RawVec<gpui_gpu::renderer::Correction>>::grow_one+0x54>
  825340:	mov    0x8(%rsp),%rax
  825345:	mov    %rax,0x8(%rbx)
  825349:	mov    %r14,(%rbx)
  82534c:	add    $0x18,%rsp
  825350:	pop    %rbx
  825351:	pop    %r14
  825353:	ret
  825354:	mov    0x8(%rsp),%rdi
  825359:	mov    0x10(%rsp),%rsi
  82535e:	call   *0x65a4c4(%rip)        # e7f828 <_DYNAMIC+0x288>

/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008257d0 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert>:
  8257d0:	push   %rbp
  8257d1:	push   %r15
  8257d3:	push   %r14
  8257d5:	push   %r13
  8257d7:	push   %r12
  8257d9:	push   %rbx
  8257da:	sub    $0x38,%rsp
  8257de:	mov    %rcx,%r15
  8257e1:	mov    %rdx,%r12
  8257e4:	mov    %rsi,%r14
  8257e7:	mov    %rdi,%rbx
  8257ea:	lea    0x20(%rsi),%r13
  8257ee:	mov    %r13,%rdi
  8257f1:	mov    %rdx,%rsi
  8257f4:	call   824230 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  8257f9:	cmpq   $0x0,0x10(%r14)
  8257fe:	je     825981 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x1b1>
  825804:	mov    (%r14),%r11
  825807:	mov    0x8(%r14),%rsi
  82580b:	mov    %rax,%rdx
  82580e:	shr    $0x39,%rdx
  825812:	movd   %edx,%xmm0
  825816:	punpcklbw %xmm0,%xmm0
  82581a:	pshuflw $0x0,%xmm0,%xmm0
  82581f:	pshufd $0x44,%xmm0,%xmm0
  825824:	mov    (%r12),%rcx
  825828:	mov    %rcx,0x8(%rsp)
  82582d:	movzwl 0xc(%r12),%r9d
  825833:	mov    0x8(%r12),%r10d
  825838:	xor    %r13d,%r13d
  82583b:	pcmpeqd %xmm1,%xmm1
  82583f:	xor    %r8d,%r8d
  825842:	and    %rsi,%rax
  825845:	movdqu (%r11,%rax,1),%xmm2
  82584b:	movdqa %xmm2,%xmm3
  82584f:	pcmpeqb %xmm0,%xmm3
  825853:	pmovmskb %xmm3,%ebp
  825857:	test   %ebp,%ebp
  825859:	je     8258a0 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xd0>
  82585b:	mov    %r8,(%rsp)
  82585f:	mov    %r15,%r8
  825862:	tzcnt  %ebp,%r15d
  825867:	add    %rax,%r15
  82586a:	and    %rsi,%r15
  82586d:	shl    $0x5,%r15
  825871:	mov    %r11,%rcx
  825874:	sub    %r15,%rcx
  825877:	mov    0x8(%rsp),%r15
  82587c:	cmp    -0x20(%rcx),%r15
  825880:	jne    82588f <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xbf>
  825882:	cmp    -0x14(%rcx),%r9w
  825887:	jne    82588f <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xbf>
  825889:	cmp    -0x18(%rcx),%r10d
  82588d:	je     8258df <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x10f>
  82588f:	lea    -0x1(%rbp),%ecx
  825892:	and    %bp,%cx
  825895:	mov    %ecx,%ebp
  825897:	mov    %r8,%r15
  82589a:	mov    (%rsp),%r8
  82589e:	jne    82585f <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x8f>
  8258a0:	cmp    $0x1,%r13
  8258a4:	je     8258b8 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xe8>
  8258a6:	pmovmskb %xmm2,%ecx
  8258aa:	test   %ecx,%ecx
  8258ac:	je     8258cc <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xfc>
  8258ae:	tzcnt  %ecx,%edi
  8258b2:	add    %rax,%rdi
  8258b5:	and    %rsi,%rdi
  8258b8:	pcmpeqb %xmm1,%xmm2
  8258bc:	pmovmskb %xmm2,%ecx
  8258c0:	test   %ecx,%ecx
  8258c2:	jne    8258f6 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x126>
  8258c4:	mov    $0x1,%r13d
  8258ca:	jmp    8258cf <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xff>
  8258cc:	xor    %r13d,%r13d
  8258cf:	add    %r8,%rax
  8258d2:	add    $0x10,%rax
  8258d6:	add    $0x10,%r8
  8258da:	jmp    825842 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x72>
  8258df:	movups -0x10(%rcx),%xmm0
  8258e3:	movups %xmm0,0x4(%rbx)
  8258e7:	movups (%r8),%xmm0
  8258eb:	movups %xmm0,-0x10(%rcx)
  8258ef:	mov    $0x1,%eax
  8258f4:	jmp    82596d <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x19d>
  8258f6:	movzbl (%r11,%rdi,1),%eax
  8258fb:	test   %al,%al
  8258fd:	jns    8259a2 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x1d2>
  825903:	movups (%r12),%xmm0
  825908:	movaps %xmm0,0x10(%rsp)
  82590d:	movups (%r15),%xmm0
  825911:	movaps %xmm0,0x20(%rsp)
  825916:	and    $0x1,%al
  825918:	lea    -0x10(%rdi),%rcx
  82591c:	and    %rsi,%rcx
  82591f:	mov    %dl,(%r11,%rdi,1)
  825923:	mov    %dl,0x10(%r11,%rcx,1)
  825928:	movzbl %al,%eax
  82592b:	movd   %eax,%xmm0
  82592f:	shufpd $0x2,-0x77a6d8(%rip),%xmm0        # ab260 <anon.a16d5d421a76dfd8c37a17b53540311d.51.llvm.14190004212411149437+0xe0>
  825938:	movdqu 0x10(%r14),%xmm1
  82593e:	psubq  %xmm0,%xmm1
  825942:	movdqu %xmm1,0x10(%r14)
  825948:	shl    $0x5,%rdi
  82594c:	mov    %r11,%rax
  82594f:	sub    %rdi,%rax
  825952:	neg    %rdi
  825955:	movaps 0x10(%rsp),%xmm0
  82595a:	movdqa 0x20(%rsp),%xmm1
  825960:	movups %xmm0,-0x20(%r11,%rdi,1)
  825966:	movdqu %xmm1,-0x10(%rax)
  82596b:	xor    %eax,%eax
  82596d:	mov    %eax,(%rbx)
  82596f:	mov    %rbx,%rax
  825972:	add    $0x38,%rsp
  825976:	pop    %rbx
  825977:	pop    %r12
  825979:	pop    %r13
  82597b:	pop    %r14
  82597d:	pop    %r15
  82597f:	pop    %rbp
  825980:	ret
  825981:	mov    $0x1,%esi
  825986:	mov    %r14,%rdi
  825989:	mov    %r13,%rdx
  82598c:	mov    $0x1,%ecx
  825991:	mov    %rax,%r13
  825994:	call   *0x65a29e(%rip)        # e7fc38 <_DYNAMIC+0x698>
  82599a:	mov    %r13,%rax
  82599d:	jmp    825804 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x34>
  8259a2:	movdqa (%r11),%xmm0
  8259a7:	pmovmskb %xmm0,%eax
  8259ab:	tzcnt  %eax,%edi
  8259af:	movzbl (%r11,%rdi,1),%eax
  8259b4:	jmp    825903 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x133>

/tmp/gpui-uniform-codegen/candidate/bin/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008259c0 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert>:
  8259c0:	push   %rbp
  8259c1:	push   %r15
  8259c3:	push   %r14
  8259c5:	push   %r13
  8259c7:	push   %r12
  8259c9:	push   %rbx
  8259ca:	push   %rax
  8259cb:	mov    %r8d,%ebp
  8259ce:	mov    %ecx,%r14d
  8259d1:	mov    %rdx,%r15
  8259d4:	mov    %rsi,%r12
  8259d7:	mov    %rdi,%rbx
  8259da:	mov    %rdx,(%rsp)
  8259de:	lea    0x20(%rsi),%r13
  8259e2:	mov    %rsp,%rsi
  8259e5:	mov    %r13,%rdi
  8259e8:	call   8243d0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  8259ed:	cmpq   $0x0,0x10(%r12)
  8259f3:	je     825b36 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x176>
  8259f9:	mov    (%r12),%rcx
  8259fd:	mov    0x8(%r12),%rsi
  825a02:	mov    %rax,%rdx
  825a05:	shr    $0x39,%rdx
  825a09:	movd   %edx,%xmm0
  825a0d:	punpcklbw %xmm0,%xmm0
  825a11:	pshuflw $0x0,%xmm0,%xmm0
  825a16:	pshufd $0x44,%xmm0,%xmm0
  825a1b:	xor    %r9d,%r9d
  825a1e:	pcmpeqd %xmm1,%xmm1
  825a22:	xor    %r8d,%r8d
  825a25:	and    %rsi,%rax
  825a28:	movdqu (%rcx,%rax,1),%xmm2
  825a2d:	movdqa %xmm2,%xmm3
  825a31:	pcmpeqb %xmm0,%xmm3
  825a35:	pmovmskb %xmm3,%r10d
  825a3a:	test   %r10d,%r10d
  825a3d:	je     825a70 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xb0>
  825a3f:	tzcnt  %r10d,%r13d
  825a44:	add    %rax,%r13
  825a47:	and    %rsi,%r13
  825a4a:	shl    $0x4,%r13
  825a4e:	mov    %rcx,%r11
  825a51:	sub    %r13,%r11
  825a54:	cmp    -0x10(%r11),%r15
  825a58:	je     825ab1 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xf1>
  825a5a:	lea    -0x1(%r10),%r11d
  825a5e:	and    %r10w,%r11w
  825a62:	mov    %r11d,%r10d
  825a65:	jne    825a3f <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x7f>
  825a67:	nopw   0x0(%rax,%rax,1)
  825a70:	cmp    $0x1,%r9
  825a74:	je     825a88 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xc8>
  825a76:	pmovmskb %xmm2,%edi
  825a7a:	test   %edi,%edi
  825a7c:	je     825a9e <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xde>
  825a7e:	tzcnt  %edi,%edi
  825a82:	add    %rax,%rdi
  825a85:	and    %rsi,%rdi
  825a88:	pcmpeqb %xmm1,%xmm2
  825a8c:	pmovmskb %xmm2,%r9d
  825a91:	test   %r9d,%r9d
  825a94:	jne    825ac8 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x108>
  825a96:	mov    $0x1,%r9d
  825a9c:	jmp    825aa1 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xe1>
  825a9e:	xor    %r9d,%r9d
  825aa1:	add    %r8,%rax
  825aa4:	add    $0x10,%rax
  825aa8:	add    $0x10,%r8
  825aac:	jmp    825a25 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x65>
  825ab1:	mov    -0x8(%r11),%rax
  825ab5:	mov    %r14d,-0x8(%r11)
  825ab9:	mov    %ebp,-0x4(%r11)
  825abd:	mov    %rax,0x4(%rbx)
  825ac1:	mov    $0x1,%eax
  825ac6:	jmp    825b22 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x162>
  825ac8:	movzbl (%rcx,%rdi,1),%eax
  825acc:	test   %al,%al
  825ace:	jns    825b57 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x197>
  825ad4:	and    $0x1,%al
  825ad6:	lea    -0x10(%rdi),%r8
  825ada:	and    %rsi,%r8
  825add:	mov    %dl,(%rcx,%rdi,1)
  825ae0:	mov    %dl,0x10(%rcx,%r8,1)
  825ae5:	movdqu 0x10(%r12),%xmm0
  825aec:	movzbl %al,%eax
  825aef:	movd   %eax,%xmm1
  825af3:	shufpd $0x2,-0x77a89c(%rip),%xmm1        # ab260 <anon.a16d5d421a76dfd8c37a17b53540311d.51.llvm.14190004212411149437+0xe0>
  825afc:	psubq  %xmm1,%xmm0
  825b00:	movdqu %xmm0,0x10(%r12)
  825b07:	shl    $0x4,%rdi
  825b0b:	mov    %rcx,%rax
  825b0e:	sub    %rdi,%rax
  825b11:	neg    %rdi
  825b14:	mov    %r15,-0x10(%rcx,%rdi,1)
  825b19:	mov    %r14d,-0x8(%rax)
  825b1d:	mov    %ebp,-0x4(%rax)
  825b20:	xor    %eax,%eax
  825b22:	mov    %eax,(%rbx)
  825b24:	mov    %rbx,%rax
  825b27:	add    $0x8,%rsp
  825b2b:	pop    %rbx
  825b2c:	pop    %r12
  825b2e:	pop    %r13
  825b30:	pop    %r14
  825b32:	pop    %r15
  825b34:	pop    %rbp
  825b35:	ret
  825b36:	mov    $0x1,%esi
  825b3b:	mov    %r12,%rdi
  825b3e:	mov    %r13,%rdx
  825b41:	mov    $0x1,%ecx
  825b46:	mov    %rax,%r13
  825b49:	call   *0x65a0f1(%rip)        # e7fc40 <_DYNAMIC+0x6a0>
  825b4f:	mov    %r13,%rax
  825b52:	jmp    8259f9 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x39>
  825b57:	movdqa (%rcx),%xmm0
  825b5b:	pmovmskb %xmm0,%eax
  825b5f:	tzcnt  %eax,%edi
  825b63:	movzbl (%rcx,%rdi,1),%eax
  825b67:	jmp    825ad4 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x114>

FUNCTION core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>> bytes=105 frame=8

FUNCTION core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}> bytes=71 frame=8

FUNCTION core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}> bytes=540 frame=40

FUNCTION core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}> bytes=64 frame=8

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext> bytes=191 frame=24

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::RendererState> bytes=1253 frame=24

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Atlas> bytes=210 frame=24

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Error> bytes=30 frame=0

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Buffer> bytes=103 frame=24

FUNCTION <gpui_gpu::renderer::Error as core::fmt::Debug>::fmt bytes=304 frame=24

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop bytes=47 frame=0

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop bytes=47 frame=0

FUNCTION <core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3: usize], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}> bytes=325 frame=72

FUNCTION <gpui_gpu::renderer::Changes>::replace::<2: usize> bytes=192 frame=24

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Atlas> bytes=210 frame=24

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Buffer> bytes=103 frame=24

FUNCTION gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}> bytes=611 frame=88

FUNCTION <gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}> bytes=235 frame=248

FUNCTION <gpui_gpu::renderer::Renderer>::set_grouped_records bytes=95 frame=24

FUNCTION <gpui_gpu::renderer::Changes>::upload bytes=83 frame=8

FUNCTION <gpui_gpu::renderer::Buffer>::write bytes=76 frame=40

FUNCTION <gpui_gpu::renderer::Buffer>::reserve bytes=271 frame=104

FUNCTION <gpui_gpu::renderer::Atlas>::new bytes=706 frame=376

FUNCTION <gpui_gpu::renderer::Atlas>::insert bytes=608 frame=152

FUNCTION <gpui_gpu::renderer::GpuContext>::submit bytes=469 frame=1384

FUNCTION <gpui_gpu::renderer::RendererState>::correction bytes=981 frame=184

FUNCTION <gpui_gpu::renderer::RendererState>::prepare_atlas bytes=663 frame=600

FUNCTION <gpui_gpu::renderer::RendererState>::new bytes=1527 frame=952

FUNCTION <gpui_gpu::renderer::RendererState>::render bytes=9374 frame=1448

FUNCTION <gpui_gpu::renderer::RendererState>::bin_draw bytes=4184 frame=824

FUNCTION gpui_gpu::renderer::compact_group bytes=68 frame=88

FUNCTION gpui_gpu::renderer::validate_draw bytes=1600 frame=168

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}> bytes=1602 frame=136

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}> bytes=1437 frame=104

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop bytes=47 frame=0

FUNCTION core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>> bytes=105 frame=8

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Buffer> bytes=103 frame=24

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::images::Images> bytes=81 frame=8

FUNCTION <gpui_gpu::renderer::images::Images>::metadata bytes=246 frame=40

FUNCTION gpui_gpu::renderer::images::prepare bytes=2722 frame=552

FUNCTION gpui_gpu::renderer::slots::color_word bytes=57 frame=8

FUNCTION gpui_gpu::renderer::slots::write_prefix bytes=632 frame=104

FUNCTION <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}> bytes=303 frame=24

FUNCTION <alloc::raw_vec::RawVec<gpui_gpu::renderer::Correction>>::grow_one bytes=100 frame=40

FUNCTION <hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert bytes=489 frame=104

FUNCTION <hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert bytes=428 frame=56
