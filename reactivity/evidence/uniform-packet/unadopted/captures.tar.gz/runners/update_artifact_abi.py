from pathlib import Path
p=Path('/tmp/gpui-uniform-packet-root/reactivity/crates/gpu/src/shader_build.rs');s=p.read_text();start=s.index('fn vector(\n');end=s.index('/// Recheck source',start)
s=s[:start]+'''fn vector_type(width: naga::VectorSize, kind: naga::ScalarKind) -> TypeInner {
    TypeInner::Vector {
        size: width,
        scalar: naga::Scalar { kind, width: 4 },
    }
}
fn vector(module: &Module, ty: naga::Handle<naga::Type>, width: naga::VectorSize, kind: naga::ScalarKind) {
    assert_eq!(module.types[ty].inner, vector_type(width, kind));
}
fn structure(module: &Module, ty: naga::Handle<naga::Type>, bytes: u32, fields: &[(u32, TypeInner)]) {
    let TypeInner::Struct { members, span } = &module.types[unwrap_struct(module, ty)].inner else {
        panic!("ABI struct")
    };
    assert_eq!(*span, bytes);
    assert_eq!(members.len(), fields.len());
    for (member, (offset, ty)) in members.iter().zip(fields) {
        assert_eq!(member.offset, *offset);
        assert_eq!(module.types[member.ty].inner, *ty);
    }
}
'''+s[end:]
s=s.replace('''                structure(module, global.ty, &[K::Uint, K::Float, K::Float]);''','''                structure(module, global.ty, 48, &[
                    (0, vector_type(V::Quad, K::Uint)),
                    (16, vector_type(V::Quad, K::Float)),
                    (32, TypeInner::Scalar(naga::Scalar::F32)),
                    (36, TypeInner::Scalar(naga::Scalar::U32)),
                ]);''')
s=s.replace('''                        structure(module, base, &[K::Float, K::Float]);''','''                        structure(module, base, 32, &[
                            (0, vector_type(V::Quad, K::Float)),
                            (16, vector_type(V::Quad, K::Float)),
                        ]);''');p.write_text(s)
