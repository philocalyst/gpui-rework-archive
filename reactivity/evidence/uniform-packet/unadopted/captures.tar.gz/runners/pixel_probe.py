import hashlib,json,os,pathlib,subprocess,sys
root=pathlib.Path(sys.argv[1]);out=pathlib.Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
source=root/'reactivity/crates/gpu/tests/render.rs';original=source.read_bytes();needle=b'    buffer.unmap();\n    output\n'
assert original.count(needle)==1
hook=b'''    // NONSHIPPING readback observer, removed by its runner.
    if let Some(directory) = std::env::var_os("GPUI_PIXEL_PROBE") {
        static NEXT: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);
        let index = NEXT.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
        let directory = std::path::PathBuf::from(directory);
        std::fs::create_dir_all(&directory).unwrap();
        std::fs::write(directory.join(format!("{index:04}-{width}x{height}-{:?}.bin", renderer.format())), &output).unwrap();
    }
'''
env=os.environ.copy();env['GPUI_PIXEL_PROBE']=str(out/'pixels')
try:
 source.write_bytes(original.replace(needle,b'    buffer.unmap();\n'+hook+b'    output\n'))
 (out/'observer.patch').write_bytes(subprocess.check_output(['git','-c','safe.directory='+str(root),'-C',str(root),'diff','--','reactivity/crates/gpu/tests/render.rs']))
 with (out/'cargo.jsonl').open('w') as stdout,(out/'cargo.log').open('w') as stderr:
  subprocess.run(['cargo','test','--release','--offline','--locked','-p','gpui_gpu','--test','render','--features','vulkan-tests','--no-run','--message-format=json'],cwd=root/'reactivity',env=env,stdout=stdout,stderr=stderr,check=True)
 artifacts=[json.loads(x) for x in (out/'cargo.jsonl').read_text().splitlines() if x.startswith('{')]
 artifact=next(x for x in artifacts if x.get('reason')=='compiler-artifact' and x.get('target',{}).get('name')=='render');assert not artifact['fresh']
 executable=pathlib.Path(artifact['executable']);artifact['sha256']=hashlib.sha256(executable.read_bytes()).hexdigest();(out/'executable.json').write_text(json.dumps(artifact,indent=2)+'\n')
 with (out/'stdout.log').open('w') as stdout,(out/'stderr.log').open('w') as stderr:
  subprocess.run([str(executable),'--test-threads=1','--nocapture','--skip','resident_words_match_forced_uploads_across_transforms_growth_and_failed_prepare','--skip','same_word_count_with_different_bank_and_material_planes_stays_coherent'],cwd=root/'reactivity',env=env,stdout=stdout,stderr=stderr,check=True)
 assert hashlib.sha256(executable.read_bytes()).hexdigest()==artifact['sha256']
 files={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted((out/'pixels').glob('*.bin'))}
 (out/'pixels.json').write_text(json.dumps(files,indent=2)+'\n');print('readbacks',len(files),'bytes',sum(v['bytes'] for v in files.values()))
finally:
 source.write_bytes(original);assert source.read_bytes()==original
