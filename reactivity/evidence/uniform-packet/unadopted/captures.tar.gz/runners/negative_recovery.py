from pathlib import Path
import hashlib,json,os,subprocess
root=Path('/tmp/gpui-uniform-packet-root');out=Path('/tmp/gpui-uniform-negative-recovery');out.mkdir(exist_ok=False)
source=root/'reactivity/crates/gpu/src/renderer.rs';original=source.read_bytes()
test=root/'reactivity/crates/gpu/tests/render.rs'
expected_line=next(i for i,line in enumerate(test.read_text().splitlines(),1) if 'assert_eq!(readback(&mut reused, &repaired), expected)' in line)
needle=b'let resident = self.packet.take().is_some();';assert original.count(needle)==1
args=['cargo','test','--release','--locked','--offline','-p','gpui_gpu','--features','vulkan-tests','--test','render','resident_words_match_forced_uploads_across_transforms_growth_and_failed_prepare','--','--exact','--nocapture','--test-threads=1']
info={'head':subprocess.check_output(['git','-c','safe.directory='+str(root),'-C',str(root),'rev-parse','HEAD'],text=True).strip(),'source_sha256':hashlib.sha256(original).hexdigest(),'test_sha256':hashlib.sha256(test.read_bytes()).hexdigest(),'args':args,'expected_pixel_assertion_line':expected_line,'fault':'force residency true after packet revocation, preserving packet.take side effect'}
try:
 source.write_bytes(original.replace(needle,b'let resident = { let _ = self.packet.take(); true };'))
 info['mutant_sha256']=hashlib.sha256(source.read_bytes()).hexdigest()
 with (out/'mutant.log').open('w') as log:
  result=subprocess.run(args,cwd=root/'reactivity',stdout=log,stderr=subprocess.STDOUT)
 info['mutant_exit']=result.returncode
 text=(out/'mutant.log').read_text();info['pixel_failure_caught']=result.returncode!=0 and 'running 1 test' in text and f'tests/render.rs:{expected_line}:' in text and 'assertion `left == right` failed' in text
finally:
 source.write_bytes(original);assert source.read_bytes()==original
 (out/'result.json').write_text(json.dumps(info,indent=2)+'\n')
assert info['pixel_failure_caught'],info
with (out/'restored.log').open('w') as log:
 result=subprocess.run(args,cwd=root/'reactivity',stdout=log,stderr=subprocess.STDOUT)
info['restored_exit']=result.returncode
info['restored_source_sha256']=hashlib.sha256(source.read_bytes()).hexdigest()
info['restored_test_sha256']=hashlib.sha256(test.read_bytes()).hexdigest()
info['restored_status']=subprocess.check_output(['git','-c','safe.directory='+str(root),'-C',str(root),'status','--porcelain'],text=True)
(out/'result.json').write_text(json.dumps(info,indent=2)+'\n')
assert result.returncode==0 and not info['restored_status']
print(json.dumps(info,indent=2))
