from pathlib import Path
import hashlib,importlib.util,json,os,shutil,subprocess
root=Path('/tmp/gpui-uniform-packet-root');out=Path('/tmp/gpui-uniform-codegen');out.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('elf_inspect','/tmp/gpui-uniform-support/elf_inspect.py');elf=importlib.util.module_from_spec(spec);spec.loader.exec_module(elf)
def git(*args):return subprocess.check_output(['git','-c','safe.directory='+str(root),'-C',str(root),*args])
def sha(data):return hashlib.sha256(data).hexdigest()
assert not git('status','--porcelain')
head=git('rev-parse','HEAD').decode().strip();assert head==Path('/tmp/gpui-uniform-support/candidate.pin').read_text().strip()
paths=git('ls-files','reactivity/crates/gpu/src','reactivity/crates/gpu/build.rs').decode().splitlines()
original={name:(root/name).read_bytes() for name in paths}
config=root/'.cargo/config.toml'
meta={'candidate':head,'baseline':'277473219bcf4add23d36126e70be1d72ceec1f6','same_physical_source_path':str(root),'source_paths':paths,'root_config_sha256':sha(config.read_bytes()),'codegen_config_sha256':sha(Path('/tmp/gpui-uniform-support/codegen.toml').read_bytes()),'rustc':subprocess.check_output(['rustc','-vV'],text=True),'cargo':subprocess.check_output(['cargo','-V'],text=True),'lanes':{},'scope':'same-path metadata codegen, not timing or dynamic stack; all bodies/aliases retained'}
env=dict(os.environ);env['CARGO_BUILD_JOBS']='1';env['CARGO_TARGET_DIR']='/tmp/gpui-uniform-codegen-target';env['RUSTC_BOOTSTRAP']='1';env.pop('RUSTFLAGS',None);env.pop('CARGO_ENCODED_RUSTFLAGS',None)
try:
 for label,ref in [('baseline',meta['baseline']),('candidate',head)]:
  directory=out/label;directory.mkdir();wanted={name:git('show',f'{ref}:{name}') for name in paths}
  for name,data in wanted.items():(root/name).write_bytes(data)
  assert {name:(root/name).read_bytes() for name in paths}==wanted
  args=['cargo','--config','/tmp/gpui-uniform-support/codegen.toml','build','--release','--offline','--locked','-p','gpui_gpu','--examples','--features','vulkan-tests','--message-format=json','-vv']
  with (directory/'clean.log').open('w') as log:subprocess.run(['cargo','clean','--release','-p','gpui_gpu'],cwd=root/'reactivity',env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
  with (directory/'cargo.jsonl').open('w') as stdout,(directory/'cargo.log').open('w') as stderr:subprocess.run(args,cwd=root/'reactivity',env=env,stdout=stdout,stderr=stderr,check=True)
  assert {name:(root/name).read_bytes() for name in paths}==wanted
  artifacts=[json.loads(line) for line in (directory/'cargo.jsonl').read_text().splitlines() if line.startswith('{')]
  relevant=[a for a in artifacts if a.get('reason')=='compiler-artifact' and a.get('target',{}).get('name')=='gpui_gpu' and a.get('target',{}).get('kind')==['lib']];assert len(relevant)==1 and not relevant[0]['fresh']
  lane={'ref':ref,'source_sha256':{name:sha(data) for name,data in wanted.items()},'args':args,'library_artifact':relevant[0],'binaries':{}}
  (directory/'bin').mkdir()
  for name in ['groups','images','tiles']:
   a=next(a for a in artifacts if a.get('reason')=='compiler-artifact' and a.get('target',{}).get('name')==name and 'example' in a.get('target',{}).get('kind',[]));assert not a['fresh'];binary=directory/'bin'/name;shutil.copy2(a['executable'],binary);binary.chmod(0o555)
   info=elf.inspect(binary);(directory/(name+'-elf.json')).write_text(json.dumps(info,indent=2)+'\n');lane['binaries'][name]={'path':str(binary),'sha256':sha(binary.read_bytes()),'sections':info['sections'],'artifact':a}
   if name=='groups':
    seen=set()
    with (directory/'gpu-functions.asm').open('w') as log:
     for f in sorted(info['all_gpu_frames'],key=lambda f:f['address']):
      if f['address'] in seen:continue
      seen.add(f['address']);log.write(f"\nFUNCTION {f['normalized_name']} bytes={f['code_bytes']} frame={f['stack_bytes']}\n")
      subprocess.run(['/nix/store/ddk8rvjihg4vhh1k6x9rc65y1zb1kx34-binutils-2.46/bin/objdump','-d','--demangle=rust','--no-show-raw-insn',f"--start-address={f['address']}",f"--stop-address={f['address']+f['code_bytes']}",str(binary)],stdout=log,check=True)
  fpdir=Path(env['CARGO_TARGET_DIR'])/'release/.fingerprint';(directory/'fingerprints').mkdir()
  for fp in fpdir.glob('gpui_gpu-*'):
   for source in fp.glob('*.json'):
    dest=directory/'fingerprints'/fp.name;dest.mkdir(exist_ok=True);shutil.copy2(source,dest/source.name)
  meta['lanes'][label]=lane;(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n');print(label,'DONE',flush=True)
finally:
 for name,data in original.items():(root/name).write_bytes(data)
 assert {name:(root/name).read_bytes() for name in paths}==original
 meta['restored_status']=git('status','--porcelain').decode();(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
assert not meta['restored_status'];print('ALL DONE and original source restored',flush=True)
