
/tmp/gpui-uniform-borrowed-span-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081b020 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>>:
  81b020:	push   %r14
  81b022:	push   %rbx
  81b023:	sub    $0x38,%rsp
  81b027:	mov    %rdi,%rbx
  81b02a:	cmpq   $0x0,(%rsi)
  81b02e:	je     81b138 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x118>
  81b034:	movdqu (%rsi),%xmm0
  81b038:	movdqu 0x10(%rsi),%xmm1
  81b03d:	movdqu 0x20(%rsi),%xmm2
  81b042:	movdqa %xmm2,0x20(%rsp)
  81b048:	movdqa %xmm1,0x10(%rsp)
  81b04e:	movdqa %xmm0,(%rsp)
  81b053:	cmpq   $0x0,0x18(%rcx)
  81b058:	je     81b14c <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x12c>
  81b05e:	lea    0x10(%rsp),%rsi
  81b063:	lea    0x20(%rcx),%rdi
  81b067:	mov    %rcx,%r14
  81b06a:	call   8218b0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  81b06f:	mov    %rax,%rsi
  81b072:	shr    $0x39,%rsi
  81b076:	mov    (%r14),%rcx
  81b079:	mov    0x8(%r14),%rdx
  81b07d:	movd   %esi,%xmm0
  81b081:	punpcklbw %xmm0,%xmm0
  81b085:	pshuflw $0x0,%xmm0,%xmm0
  81b08a:	pshufd $0x44,%xmm0,%xmm0
  81b08f:	mov    0x10(%rsp),%rsi
  81b094:	movzwl 0x1c(%rsp),%edi
  81b099:	xor    %r8d,%r8d
  81b09c:	mov    0x18(%rsp),%r9d
  81b0a1:	pcmpeqd %xmm1,%xmm1
  81b0a5:	and    %rdx,%rax
  81b0a8:	movdqu (%rcx,%rax,1),%xmm2
  81b0ad:	movdqa %xmm2,%xmm3
  81b0b1:	pcmpeqb %xmm0,%xmm3
  81b0b5:	pmovmskb %xmm3,%r10d
  81b0ba:	test   %r10d,%r10d
  81b0bd:	je     81b100 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xe0>
  81b0bf:	tzcnt  %r10d,%r14d
  81b0c4:	add    %rax,%r14
  81b0c7:	and    %rdx,%r14
  81b0ca:	shl    $0x5,%r14
  81b0ce:	mov    %rcx,%r11
  81b0d1:	sub    %r14,%r11
  81b0d4:	cmp    -0x20(%r11),%rsi
  81b0d8:	jne    81b0e7 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xc7>
  81b0da:	cmp    -0x14(%r11),%di
  81b0df:	jne    81b0e7 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xc7>
  81b0e1:	cmp    -0x18(%r11),%r9d
  81b0e5:	je     81b11b <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xfb>
  81b0e7:	lea    -0x1(%r10),%r11d
  81b0eb:	and    %r10w,%r11w
  81b0ef:	mov    %r11d,%r10d
  81b0f2:	jne    81b0bf <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x9f>
  81b0f4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  81b100:	pcmpeqb %xmm1,%xmm2
  81b104:	pmovmskb %xmm2,%r10d
  81b109:	test   %r10d,%r10d
  81b10c:	jne    81b14c <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x12c>
  81b10e:	add    %r8,%rax
  81b111:	add    $0x10,%rax
  81b115:	add    $0x10,%r8
  81b119:	jmp    81b0a5 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x85>
  81b11b:	mov    -0x4(%r11),%eax
  81b11f:	shl    $0x10,%eax
  81b122:	or     -0x8(%r11),%eax
  81b126:	mov    -0x10(%r11),%rcx
  81b12a:	mov    %rcx,(%rbx)
  81b12d:	mov    %eax,0x8(%rbx)
  81b130:	add    $0x38,%rsp
  81b134:	pop    %rbx
  81b135:	pop    %r14
  81b137:	ret
  81b138:	mov    0x8(%rdx),%eax
  81b13b:	mov    %eax,0x8(%rbx)
  81b13e:	mov    (%rdx),%rax
  81b141:	mov    %rax,(%rbx)
  81b144:	add    $0x38,%rsp
  81b148:	pop    %rbx
  81b149:	pop    %r14
  81b14b:	ret
  81b14c:	lea    -0x746a01(%rip),%rdi        # d4752 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x12c>
  81b153:	lea    0x612c2e(%rip),%rdx        # e2dd88 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4925703984657133240+0x90>
  81b15a:	mov    $0x16,%esi
  81b15f:	call   *0x6646ab(%rip)        # e7f810 <_DYNAMIC+0x5a0>

/tmp/gpui-uniform-borrowed-span-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081b170 <<gpui_gpu::renderer::Changes>::replace::<1>>:
  81b170:	cmp    %rdx,%rcx
  81b173:	jae    81b1c1 <<gpui_gpu::renderer::Changes>::replace::<1>+0x51>
  81b175:	mov    %rcx,%rax
  81b178:	shl    $0x4,%rax
  81b17c:	movdqu (%rsi,%rax,1),%xmm0
  81b181:	movdqu (%r8),%xmm1
  81b186:	pcmpeqb %xmm0,%xmm1
  81b18a:	pmovmskb %xmm1,%edx
  81b18e:	cmp    $0xffff,%edx
  81b194:	jne    81b197 <<gpui_gpu::renderer::Changes>::replace::<1>+0x27>
  81b196:	ret
  81b197:	add    %rax,%rsi
  81b19a:	mov    (%rdi),%rax
  81b19d:	mov    0x8(%rdi),%rdx
  81b1a1:	cmp    %rax,%rcx
  81b1a4:	cmovb  %rcx,%rax
  81b1a8:	inc    %rcx
  81b1ab:	cmp    %rdx,%rcx
  81b1ae:	cmovbe %rdx,%rcx
  81b1b2:	mov    %rax,(%rdi)
  81b1b5:	mov    %rcx,0x8(%rdi)
  81b1b9:	movups (%r8),%xmm0
  81b1bd:	movups %xmm0,(%rsi)
  81b1c0:	ret
  81b1c1:	push   %rax
  81b1c2:	lea    0x1(%rcx),%rsi
  81b1c6:	lea    0x612b2b(%rip),%rax        # e2dcf8 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4925703984657133240>
  81b1cd:	mov    %rcx,%rdi
  81b1d0:	mov    %rax,%rcx
  81b1d3:	call   *0x6645df(%rip)        # e7f7b8 <_DYNAMIC+0x548>

/tmp/gpui-uniform-borrowed-span-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081b1e0 <<gpui_gpu::renderer::Changes>::replace::<2>>:
  81b1e0:	mov    %rsi,%rax
  81b1e3:	lea    0x2(%rcx),%rsi
  81b1e7:	cmp    $0xfffffffffffffffd,%rcx
  81b1eb:	ja     81b28c <<gpui_gpu::renderer::Changes>::replace::<2>+0xac>
  81b1f1:	cmp    %rdx,%rsi
  81b1f4:	ja     81b28c <<gpui_gpu::renderer::Changes>::replace::<2>+0xac>
  81b1fa:	mov    %rcx,%r11
  81b1fd:	shl    $0x4,%r11
  81b201:	lea    (%rax,%r11,1),%rdx
  81b205:	mov    (%rdi),%r10
  81b208:	mov    0x8(%rdi),%r9
  81b20c:	movdqu (%rax,%r11,1),%xmm0
  81b212:	movdqu (%r8),%xmm1
  81b217:	pcmpeqb %xmm0,%xmm1
  81b21b:	pmovmskb %xmm1,%eax
  81b21f:	cmp    $0xffff,%eax
  81b224:	je     81b248 <<gpui_gpu::renderer::Changes>::replace::<2>+0x68>
  81b226:	cmp    %r10,%rcx
  81b229:	cmovb  %rcx,%r10
  81b22d:	lea    0x1(%rcx),%rax
  81b231:	cmp    %r9,%rax
  81b234:	cmova  %rax,%r9
  81b238:	mov    %r10,(%rdi)
  81b23b:	mov    %r9,0x8(%rdi)
  81b23f:	movdqu (%r8),%xmm0
  81b244:	movdqu %xmm0,(%rdx)
  81b248:	movdqu 0x10(%rdx),%xmm0
  81b24d:	movdqu 0x10(%r8),%xmm1
  81b253:	pcmpeqb %xmm0,%xmm1
  81b257:	pmovmskb %xmm1,%eax
  81b25b:	cmp    $0xffff,%eax
  81b260:	je     81b28b <<gpui_gpu::renderer::Changes>::replace::<2>+0xab>
  81b262:	add    $0x10,%rdx
  81b266:	add    $0x10,%r8
  81b26a:	inc    %rcx
  81b26d:	cmp    %r10,%rcx
  81b270:	cmovae %r10,%rcx
  81b274:	cmp    %r9,%rsi
  81b277:	cmova  %rsi,%r9
  81b27b:	mov    %rcx,(%rdi)
  81b27e:	mov    %r9,0x8(%rdi)
  81b282:	movdqu (%r8),%xmm0
  81b287:	movdqu %xmm0,(%rdx)
  81b28b:	ret
  81b28c:	push   %rax
  81b28d:	lea    0x612a64(%rip),%rax        # e2dcf8 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4925703984657133240>
  81b294:	mov    %rcx,%rdi
  81b297:	mov    %rax,%rcx
  81b29a:	call   *0x664518(%rip)        # e7f7b8 <_DYNAMIC+0x548>

/tmp/gpui-uniform-borrowed-span-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081c010 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>>:
  81c010:	push   %rbp
  81c011:	push   %r15
  81c013:	push   %r14
  81c015:	push   %r13
  81c017:	push   %r12
  81c019:	push   %rbx
  81c01a:	sub    $0x28,%rsp
  81c01e:	movss  0x8c(%rdi),%xmm3
  81c026:	movss  -0x76d072(%rip),%xmm0        # aefbc <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  81c02e:	movaps %xmm3,%xmm1
  81c031:	subss  %xmm0,%xmm1
  81c035:	cvttss2si %xmm1,%rax
  81c03a:	cvttss2si %xmm3,%r8
  81c03f:	mov    %r8,%rcx
  81c042:	sar    $0x3f,%rcx
  81c046:	and    %rax,%rcx
  81c049:	or     %r8,%rcx
  81c04c:	xor    %r9d,%r9d
  81c04f:	xorps  %xmm1,%xmm1
  81c052:	ucomiss %xmm1,%xmm3
  81c055:	cmovb  %r9,%rcx
  81c059:	movss  -0x76d0a1(%rip),%xmm2        # aefc0 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  81c061:	ucomiss %xmm2,%xmm3
  81c064:	mov    $0xffffffffffffffff,%rax
  81c06b:	cmova  %rax,%rcx
  81c06f:	movss  0x94(%rdi),%xmm3
  81c077:	mov    %rcx,%r8
  81c07a:	shr    $0x4,%r8
  81c07e:	movaps %xmm3,%xmm4
  81c081:	subss  %xmm0,%xmm4
  81c085:	cvttss2si %xmm4,%r10
  81c08a:	cvttss2si %xmm3,%r11
  81c08f:	mov    %r11,%rbx
  81c092:	sar    $0x3f,%rbx
  81c096:	and    %r10,%rbx
  81c099:	or     %r11,%rbx
  81c09c:	ucomiss %xmm1,%xmm3
  81c09f:	cmovb  %r9,%rbx
  81c0a3:	ucomiss %xmm2,%xmm3
  81c0a6:	cmova  %rax,%rbx
  81c0aa:	mov    %rsi,0x18(%rsp)
  81c0af:	lea    (%rcx,%rbx,1),%r11
  81c0b3:	dec    %r11
  81c0b6:	shr    $0x4,%r11
  81c0ba:	cmp    %r11,%r8
  81c0bd:	jbe    81c0ce <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xbe>
  81c0bf:	add    $0x28,%rsp
  81c0c3:	pop    %rbx
  81c0c4:	pop    %r12
  81c0c6:	pop    %r13
  81c0c8:	pop    %r14
  81c0ca:	pop    %r15
  81c0cc:	pop    %rbp
  81c0cd:	ret
  81c0ce:	movss  0x88(%rdi),%xmm3
  81c0d6:	movaps %xmm3,%xmm4
  81c0d9:	subss  %xmm0,%xmm4
  81c0dd:	cvttss2si %xmm4,%rsi
  81c0e2:	cvttss2si %xmm3,%r9
  81c0e7:	mov    %r9,%rcx
  81c0ea:	sar    $0x3f,%rcx
  81c0ee:	and    %rsi,%rcx
  81c0f1:	or     %r9,%rcx
  81c0f4:	xor    %r10d,%r10d
  81c0f7:	ucomiss %xmm1,%xmm3
  81c0fa:	cmovb  %r10,%rcx
  81c0fe:	ucomiss %xmm2,%xmm3
  81c101:	cmova  %rax,%rcx
  81c105:	movss  0x90(%rdi),%xmm3
  81c10d:	mov    %rcx,%r14
  81c110:	shr    $0x4,%r14
  81c114:	movaps %xmm3,%xmm4
  81c117:	subss  %xmm0,%xmm4
  81c11b:	cvttss2si %xmm4,%rsi
  81c120:	cvttss2si %xmm3,%rdi
  81c125:	mov    %rdi,%r9
  81c128:	sar    $0x3f,%r9
  81c12c:	and    %rsi,%r9
  81c12f:	or     %rdi,%r9
  81c132:	ucomiss %xmm1,%xmm3
  81c135:	cmovb  %r10,%r9
  81c139:	ucomiss %xmm2,%xmm3
  81c13c:	cmova  %rax,%r9
  81c140:	lea    (%r9,%rcx,1),%rbx
  81c144:	dec    %rbx
  81c147:	shr    $0x4,%rbx
  81c14b:	mov    %r14,0x10(%rsp)
  81c150:	cmp    %rbx,%r14
  81c153:	jbe    81c17d <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x16d>
  81c155:	data16 cs nopw 0x0(%rax,%rax,1)
  81c160:	mov    %r8,%rax
  81c163:	cmp    %r11,%r8
  81c166:	adc    $0x0,%r8
  81c16a:	cmp    %r11,%rax
  81c16d:	jae    81c0bf <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c173:	cmp    %r11,%r8
  81c176:	jbe    81c160 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x150>
  81c178:	jmp    81c0bf <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c17d:	mov    (%rdx),%r14
  81c180:	mov    0x8(%rdx),%r15
  81c184:	mov    0x10(%rdx),%r12
  81c188:	mov    0x18(%rdx),%r13
  81c18c:	mov    0x20(%rdx),%rdx
  81c190:	mov    %r11,0x8(%rsp)
  81c195:	data16 cs nopw 0x0(%rax,%rax,1)
  81c1a0:	mov    %r8,%rbp
  81c1a3:	cmp    %r11,%r8
  81c1a6:	adc    $0x0,%r8
  81c1aa:	mov    %rbp,0x20(%rsp)
  81c1af:	imul   0x18(%rsp),%rbp
  81c1b5:	mov    0x10(%rsp),%r9
  81c1ba:	mov    %r9,%rsi
  81c1bd:	nopl   (%rax)
  81c1c0:	cmp    %rbx,%r9
  81c1c3:	adc    $0x0,%rsi
  81c1c7:	lea    (%r9,%rbp,1),%rdi
  81c1cb:	mov    0x10(%r14),%rax
  81c1cf:	cmp    %rax,%rdi
  81c1d2:	jae    81c240 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x230>
  81c1d4:	mov    0x8(%r14),%rcx
  81c1d8:	cmp    0x4(%rcx,%rdi,8),%r10d
  81c1dd:	jo     81c215 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x205>
  81c1df:	mov    0x10(%r12),%rax
  81c1e4:	cmp    %rax,%rdi
  81c1e7:	jae    81c250 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x240>
  81c1e9:	mov    0x8(%r12),%rax
  81c1ee:	mov    0x0(%r13),%r11d
  81c1f2:	inc    %r11d
  81c1f5:	cmp    (%rax,%rdi,4),%r11d
  81c1f9:	jb     81c215 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x205>
  81c1fb:	mov    (%rcx,%rdi,8),%eax
  81c1fe:	dec    %eax
  81c200:	mov    %eax,(%rcx,%rdi,8)
  81c203:	mov    0x10(%r15),%rcx
  81c207:	cmp    %rax,%rcx
  81c20a:	jbe    81c260 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x250>
  81c20c:	mov    0x8(%r15),%rcx
  81c210:	mov    (%rdx),%edi
  81c212:	mov    %edi,(%rcx,%rax,4)
  81c215:	cmp    %rbx,%r9
  81c218:	jae    81c222 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x212>
  81c21a:	mov    %rsi,%r9
  81c21d:	cmp    %rbx,%rsi
  81c220:	jbe    81c1c0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x1b0>
  81c222:	mov    0x8(%rsp),%r11
  81c227:	cmp    %r11,0x20(%rsp)
  81c22c:	jae    81c0bf <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c232:	cmp    %r11,%r8
  81c235:	jbe    81c1a0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x190>
  81c23b:	jmp    81c0bf <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c240:	lea    0x611b59(%rip),%rdx        # e2dda0 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4925703984657133240+0xa8>
  81c247:	mov    %rax,%rsi
  81c24a:	call   *0x663518(%rip)        # e7f768 <_DYNAMIC+0x4f8>
  81c250:	lea    0x611b61(%rip),%rdx        # e2ddb8 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4925703984657133240+0xc0>
  81c257:	mov    %rax,%rsi
  81c25a:	call   *0x663508(%rip)        # e7f768 <_DYNAMIC+0x4f8>
  81c260:	lea    0x611b69(%rip),%rdx        # e2ddd0 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4925703984657133240+0xd8>
  81c267:	mov    %rax,%rdi
  81c26a:	mov    %rcx,%rsi
  81c26d:	call   *0x6634f5(%rip)        # e7f768 <_DYNAMIC+0x4f8>

/tmp/gpui-uniform-borrowed-span-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081c280 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>>:
  81c280:	push   %rbp
  81c281:	push   %r15
  81c283:	push   %r14
  81c285:	push   %r13
  81c287:	push   %r12
  81c289:	push   %rbx
  81c28a:	sub    $0xc8,%rsp
  81c291:	mov    %esi,%ebp
  81c293:	mov    %rdi,%rbx
  81c296:	lea    0x8(%rsp),%rdi
  81c29b:	mov    %rbx,%rsi
  81c29e:	call   *0x663584(%rip)        # e7f828 <_DYNAMIC+0x5b8>
  81c2a4:	mov    0x8(%rsp),%rsi
  81c2a9:	xor    %r14d,%r14d
  81c2ac:	test   $0x1,%bpl
  81c2b0:	je     81c328 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0xa8>
  81c2b2:	test   %rsi,%rsi
  81c2b5:	je     81c356 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0xd6>
  81c2bb:	mov    $0x1,%r13d
  81c2c1:	lea    0x8(%rsp),%r12
  81c2c6:	mov    0x66355b(%rip),%rbp        # e7f828 <_DYNAMIC+0x5b8>
  81c2cd:	jmp    81c2e5 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0x65>
  81c2cf:	nop
  81c2d0:	add    %r15,%r14
  81c2d3:	mov    %r12,%rdi
  81c2d6:	mov    %rbx,%rsi
  81c2d9:	call   *%rbp
  81c2db:	mov    0x8(%rsp),%rsi
  81c2e0:	test   %rsi,%rsi
  81c2e3:	je     81c356 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0xd6>
  81c2e5:	mov    0x18(%rsp),%r15
  81c2ea:	cmp    $0x2,%r15
  81c2ee:	jb     81c2d0 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0x50>
  81c2f0:	mov    0x10(%rsp),%rax
  81c2f5:	mov    (%rax),%edx
  81c2f7:	lea    0x70(%rsp),%rdi
  81c2fc:	call   81c370 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81c301:	movss  0x74(%rsp),%xmm0
  81c307:	xorps  %xmm1,%xmm1
  81c30a:	ucomiss %xmm1,%xmm0
  81c30d:	mov    $0x1,%eax
  81c312:	cmovne %r15,%rax
  81c316:	cmovp  %r15,%rax
  81c31a:	cmpb   $0x3,0x70(%rsp)
  81c31f:	cmovne %r13,%rax
  81c323:	mov    %rax,%r15
  81c326:	jmp    81c2d0 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0x50>
  81c328:	test   %rsi,%rsi
  81c32b:	je     81c356 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0xd6>
  81c32d:	lea    0x8(%rsp),%r15
  81c332:	mov    0x6634ef(%rip),%r12        # e7f828 <_DYNAMIC+0x5b8>
  81c339:	nopl   0x0(%rax)
  81c340:	add    0x18(%rsp),%r14
  81c345:	mov    %r15,%rdi
  81c348:	mov    %rbx,%rsi
  81c34b:	call   *%r12
  81c34e:	cmpq   $0x0,0x8(%rsp)
  81c354:	jne    81c340 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0xc0>
  81c356:	mov    %r14,%rax
  81c359:	add    $0xc8,%rsp
  81c360:	pop    %rbx
  81c361:	pop    %r12
  81c363:	pop    %r13
  81c365:	pop    %r14
  81c367:	pop    %r15
  81c369:	pop    %rbp
  81c36a:	ret

/tmp/gpui-uniform-borrowed-span-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081db60 <<gpui_gpu::renderer::RendererState>::render>:
  81db60:	push   %rbp
  81db61:	push   %r15
  81db63:	push   %r14
  81db65:	push   %r13
  81db67:	push   %r12
  81db69:	push   %rbx
  81db6a:	sub    $0x578,%rsp
  81db71:	mov    0x228(%rsi),%rax
  81db78:	mov    0x18(%rdx),%rbx
  81db7c:	cmp    %rbx,%rax
  81db7f:	je     81db9d <<gpui_gpu::renderer::RendererState>::render+0x3d>
  81db81:	mov    0x10(%rax),%r9
  81db85:	cmp    0x10(%rbx),%r9
  81db89:	jne    81dd09 <<gpui_gpu::renderer::RendererState>::render+0x1a9>
  81db8f:	mov    0x18(%rax),%rax
  81db93:	cmp    0x18(%rbx),%rax
  81db97:	jne    81dd09 <<gpui_gpu::renderer::RendererState>::render+0x1a9>
  81db9d:	movupd 0x330(%rsi),%xmm0
  81dba5:	movapd %xmm0,0x130(%rsp)
  81dbae:	movq   $0x0,0x330(%rsi)
  81dbb9:	mov    0x130(%rsp),%r13
  81dbc1:	test   %r13,%r13
  81dbc4:	je     81dc06 <<gpui_gpu::renderer::RendererState>::render+0xa6>
  81dbc6:	lock decq 0x0(%r13)
  81dbcb:	jne    81dc06 <<gpui_gpu::renderer::RendererState>::render+0xa6>
  81dbcd:	lea    0x130(%rsp),%rax
  81dbd5:	mov    %rdi,%r14
  81dbd8:	mov    %rax,%rdi
  81dbdb:	mov    %rsi,%r12
  81dbde:	mov    %r8,%rbp
  81dbe1:	mov    %rdx,%r15
  81dbe4:	mov    %r13,0x38(%rsp)
  81dbe9:	mov    %rcx,%r13
  81dbec:	call   *0x661b96(%rip)        # e7f788 <_DYNAMIC+0x518>
  81dbf2:	mov    %r13,%rcx
  81dbf5:	mov    0x38(%rsp),%r13
  81dbfa:	mov    %r15,%rdx
  81dbfd:	mov    %rbp,%r8
  81dc00:	mov    %r12,%rsi
  81dc03:	mov    %r14,%rdi
  81dc06:	mov    0x228(%rsi),%rax
  81dc0d:	cmp    %rbx,%rax
  81dc10:	je     81dc2e <<gpui_gpu::renderer::RendererState>::render+0xce>
  81dc12:	mov    0x10(%rax),%r9
  81dc16:	cmp    0x10(%rbx),%r9
  81dc1a:	jne    81dd09 <<gpui_gpu::renderer::RendererState>::render+0x1a9>
  81dc20:	mov    0x18(%rax),%rax
  81dc24:	cmp    0x18(%rbx),%rax
  81dc28:	jne    81dd09 <<gpui_gpu::renderer::RendererState>::render+0x1a9>
  81dc2e:	lea    0x330(%rsi),%rax
  81dc35:	mov    %rax,0xe8(%rsp)
  81dc3d:	mov    (%rax),%rax
  81dc40:	test   %rax,%rax
  81dc43:	je     81dc7c <<gpui_gpu::renderer::RendererState>::render+0x11c>
  81dc45:	lock decq (%rax)
  81dc49:	jne    81dc7c <<gpui_gpu::renderer::RendererState>::render+0x11c>
  81dc4b:	mov    %rdi,%r14
  81dc4e:	lea    0x330(%rsi),%rdi
  81dc55:	mov    %rsi,%r12
  81dc58:	mov    %r8,%rbp
  81dc5b:	mov    %rdx,%r15
  81dc5e:	mov    %r13,%rbx
  81dc61:	mov    %rcx,%r13
  81dc64:	call   *0x661b1e(%rip)        # e7f788 <_DYNAMIC+0x518>
  81dc6a:	mov    %r13,%rcx
  81dc6d:	mov    %rbx,%r13
  81dc70:	mov    %r15,%rdx
  81dc73:	mov    %rbp,%r8
  81dc76:	mov    %r12,%rsi
  81dc79:	mov    %r14,%rdi
  81dc7c:	movq   $0x0,0x330(%rsi)
  81dc87:	mov    (%rcx),%ebp
  81dc89:	mov    0x8(%rcx),%r9d
  81dc8d:	movzbl 0xd(%rcx),%eax
  81dc91:	test   %r9d,%r9d
  81dc94:	sets   %r10b
  81dc98:	and    $0x7fffffff,%r9d
  81dc9f:	lea    -0x800000(%r9),%r11d
  81dca6:	cmp    $0x7f000000,%r11d
  81dcad:	setb   %r11b
  81dcb1:	and    %r10b,%r11b
  81dcb4:	lea    -0x1(%r9),%r14d
  81dcb8:	cmp    $0x7fffff,%r14d
  81dcbf:	setb   %r14b
  81dcc3:	and    %r10b,%r14b
  81dcc6:	test   %r9d,%r9d
  81dcc9:	sete   %r10b
  81dccd:	cmp    $0x7f800000,%r9d
  81dcd4:	sete   %r15b
  81dcd8:	or     %r10b,%r15b
  81dcdb:	cmp    $0x7f800001,%r9d
  81dce2:	setge  %r9b
  81dce6:	or     %r15b,%r9b
  81dce9:	or     %r14b,%r9b
  81dcec:	test   %ebp,%ebp
  81dcee:	setne  %r10b
  81dcf2:	and    %al,%r10b
  81dcf5:	or     %r11b,%r10b
  81dcf8:	or     %r9b,%r10b
  81dcfb:	test   $0x1,%r10b
  81dcff:	je     81dd24 <<gpui_gpu::renderer::RendererState>::render+0x1c4>
  81dd01:	movl   $0x3,(%rdi)
  81dd07:	jmp    81dd0f <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81dd09:	movl   $0x4,(%rdi)
  81dd0f:	mov    %rdi,%rax
  81dd12:	add    $0x578,%rsp
  81dd19:	pop    %rbx
  81dd1a:	pop    %r12
  81dd1c:	pop    %r13
  81dd1e:	pop    %r14
  81dd20:	pop    %r15
  81dd22:	pop    %rbp
  81dd23:	ret
  81dd24:	movd   0x4(%rcx),%xmm2
  81dd29:	movzbl 0xc(%rcx),%r12d
  81dd2e:	test   $0x1,%bpl
  81dd32:	je     81ddaa <<gpui_gpu::renderer::RendererState>::render+0x24a>
  81dd34:	movd   %xmm2,%r9d
  81dd39:	test   %r9d,%r9d
  81dd3c:	sets   %r10b
  81dd40:	and    $0x7fffffff,%r9d
  81dd47:	lea    -0x800000(%r9),%r11d
  81dd4e:	cmp    $0x7f000000,%r11d
  81dd55:	setb   %r11b
  81dd59:	and    %r10b,%r11b
  81dd5c:	lea    -0x1(%r9),%r14d
  81dd60:	cmp    $0x7fffff,%r14d
  81dd67:	setb   %r14b
  81dd6b:	and    %r10b,%r14b
  81dd6e:	test   %r9d,%r9d
  81dd71:	sete   %r10b
  81dd75:	cmp    $0x7f800000,%r9d
  81dd7c:	sete   %r15b
  81dd80:	or     %r10b,%r15b
  81dd83:	cmp    $0x7f800001,%r9d
  81dd8a:	setge  %r9b
  81dd8e:	or     %r15b,%r9b
  81dd91:	or     %r14b,%r9b
  81dd94:	or     %r11b,%r9b
  81dd97:	jne    81dd01 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81dd9d:	ucomiss -0x76eef8(%rip),%xmm2        # aeeac <anon.630a3fff68f6bca64b568be97512ab45.57.llvm.826976926275214120+0x1c>
  81dda4:	ja     81dd01 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81ddaa:	mov    0x28(%rcx),%r14d
  81ddae:	cmp    %r14d,0x20(%r8)
  81ddb2:	jne    81dd01 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81ddb8:	mov    0x2c(%rcx),%r15d
  81ddbc:	cmp    %r15d,0x24(%r8)
  81ddc0:	jne    81dd01 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81ddc6:	mov    0x38(%r8),%r10d
  81ddca:	cmp    0x20(%rdx),%r10d
  81ddce:	jne    81dd01 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81ddd4:	cmp    $0x4c,%r10d
  81ddd8:	jne    81ddfd <<gpui_gpu::renderer::RendererState>::render+0x29d>
  81ddda:	movq   0x3c(%r8),%xmm0
  81dde0:	movq   0x24(%rdx),%xmm1
  81dde5:	pcmpeqd %xmm0,%xmm1
  81dde9:	pshufd $0x50,%xmm1,%xmm0
  81ddee:	movmskpd %xmm0,%r9d
  81ddf3:	cmp    $0x3,%r9d
  81ddf7:	jne    81dd01 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81ddfd:	cmp    $0x4000,%r15d
  81de04:	ja     81de3a <<gpui_gpu::renderer::RendererState>::render+0x2da>
  81de06:	cmp    $0x4000,%r14d
  81de0d:	ja     81de3a <<gpui_gpu::renderer::RendererState>::render+0x2da>
  81de0f:	mov    %r15,%r9
  81de12:	imul   %r14,%r9
  81de16:	add    $0xfffffffffeffffff,%r9
  81de1d:	cmp    $0xffffffffff000000,%r9
  81de24:	jb     81de3a <<gpui_gpu::renderer::RendererState>::render+0x2da>
  81de26:	mov    0x10(%rcx),%rbx
  81de2a:	mov    0x80(%rbx),%r11
  81de31:	cmp    $0x10000,%r11
  81de38:	jbe    81de45 <<gpui_gpu::renderer::RendererState>::render+0x2e5>
  81de3a:	movl   $0x6,(%rdi)
  81de40:	jmp    81dd0f <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81de45:	movd   0x18(%rcx),%xmm0
  81de4a:	movd   %xmm0,%r9d
  81de4f:	and    $0x7fffffff,%r9d
  81de56:	cmp    $0x7f7fffff,%r9d
  81de5d:	jg     81dd01 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81de63:	pand   -0x7706eb(%rip),%xmm0        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81de6b:	ucomiss -0x76ed6e(%rip),%xmm0        # af104 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81de72:	ja     81dd01 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81de78:	movd   0x1c(%rcx),%xmm0
  81de7d:	movd   %xmm0,%r9d
  81de82:	and    $0x7fffffff,%r9d
  81de89:	cmp    $0x7f7fffff,%r9d
  81de90:	jg     81dd01 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81de96:	pand   -0x77071e(%rip),%xmm0        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81de9e:	ucomiss -0x76eda1(%rip),%xmm0        # af104 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81dea5:	ja     81dd01 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81deab:	movd   0x20(%rcx),%xmm0
  81deb0:	movd   %xmm0,%r9d
  81deb5:	and    $0x7fffffff,%r9d
  81debc:	cmp    $0x7f7fffff,%r9d
  81dec3:	jg     81dd01 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81dec9:	pand   -0x770751(%rip),%xmm0        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81ded1:	ucomiss -0x76edd4(%rip),%xmm0        # af104 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81ded8:	ja     81dd01 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81dede:	movd   0x24(%rcx),%xmm0
  81dee3:	movd   %xmm0,%r9d
  81dee8:	and    $0x7fffffff,%r9d
  81deef:	cmp    $0x7f7fffff,%r9d
  81def6:	jg     81dd01 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81defc:	movdqa -0x770784(%rip),%xmm1        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81df04:	pand   %xmm0,%xmm1
  81df08:	ucomiss -0x76ee0b(%rip),%xmm1        # af104 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81df0f:	ja     81dd01 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81df15:	xorps  %xmm1,%xmm1
  81df18:	ucomiss %xmm1,%xmm0
  81df1b:	jb     81dd01 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81df21:	movss  -0x76f1a9(%rip),%xmm1        # aed80 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  81df29:	ucomiss %xmm0,%xmm1
  81df2c:	jb     81dd01 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81df32:	movzwl 0x30(%rcx),%r9d
  81df37:	mov    %r9d,0x10(%rsp)
  81df3c:	movzwl 0x32(%rcx),%r9d
  81df41:	mov    %r9d,0x30(%rsp)
  81df46:	cmp    $0x28,%r10d
  81df4a:	mov    %r8,0x4b8(%rsp)
  81df52:	mov    %rcx,0x120(%rsp)
  81df5a:	mov    %rdx,0xa0(%rsp)
  81df62:	mov    %r13,0x38(%rsp)
  81df67:	movd   %xmm2,0x2e8(%rsp)
  81df70:	movss  %xmm1,0xf4(%rsp)
  81df79:	jne    81df85 <<gpui_gpu::renderer::RendererState>::render+0x425>
  81df7b:	test   $0x1,%al
  81df7d:	je     81dd01 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81df83:	jmp    81dfa0 <<gpui_gpu::renderer::RendererState>::render+0x440>
  81df85:	test   $0x1,%al
  81df87:	jne    81dd01 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81df8d:	ucomiss -0x76f214(%rip),%xmm0        # aed80 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  81df94:	jne    81dd01 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81df9a:	jp     81dd01 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81dfa0:	mov    %rbx,0x100(%rsp)
  81dfa8:	mov    %r11,0x108(%rsp)
  81dfb0:	mov    %r10d,0x2e4(%rsp)
  81dfb8:	mov    %rdi,0x50(%rsp)
  81dfbd:	lea    0xf(%r14),%rax
  81dfc1:	shr    $0x4,%rax
  81dfc5:	lea    0xf(%r15),%ecx
  81dfc9:	shr    $0x4,%ecx
  81dfcc:	lea    0x18(%rsi),%rdi
  81dfd0:	movq   $0x0,0x28(%rsi)
  81dfd8:	mov    %rax,0x90(%rsp)
  81dfe0:	imul   %eax,%ecx
  81dfe3:	mov    %rdi,0x4c8(%rsp)
  81dfeb:	mov    %rsi,%r13
  81dfee:	mov    %rcx,0x40(%rsp)
  81dff3:	mov    %rcx,%rsi
  81dff6:	xor    %edx,%edx
  81dff8:	call   8223a0 <<alloc::vec::Vec<[u32; 2]>>::resize>
  81dffd:	mov    %r13,0x8(%rsp)
  81e002:	mov    0x10(%r13),%rax
  81e006:	mov    %rax,0x348(%rsp)
  81e00e:	mov    0x120(%rsp),%rdi
  81e016:	call   *0x6617fc(%rip)        # e7f818 <_DYNAMIC+0x5a8>
  81e01c:	mov    %rdx,0x358(%rsp)
  81e024:	mov    %rax,0x350(%rsp)
  81e02c:	sub    %rax,%rdx
  81e02f:	cmp    $0x300000,%rdx
  81e036:	ja     81e16d <<gpui_gpu::renderer::RendererState>::render+0x60d>
  81e03c:	mov    %rdx,%rcx
  81e03f:	mov    %rdx,%rax
  81e042:	shr    $0x3,%rax
  81e046:	movabs $0xaaaaaaaaaaaaaaab,%rdx
  81e050:	imul   %rax,%rdx
  81e054:	mov    %rdx,0x2c0(%rsp)
  81e05c:	mov    0x350(%rsp),%rax
  81e064:	cmp    %rax,0x358(%rsp)
  81e06c:	je     81e09d <<gpui_gpu::renderer::RendererState>::render+0x53d>
  81e06e:	mov    $0xaaaaaaab,%eax
  81e073:	imul   %rax,%rcx
  81e077:	shr    $0x2a,%rcx
  81e07b:	mov    0x2c0(%rsp),%rdx
  81e083:	mov    %edx,%eax
  81e085:	and    $0x3f,%eax
  81e088:	add    %rdx,%rcx
  81e08b:	cmp    $0x1,%rax
  81e08f:	sbb    $0xffffffffffffffff,%rcx
  81e093:	inc    %rcx
  81e096:	mov    %rcx,0x20(%rsp)
  81e09b:	jmp    81e0a6 <<gpui_gpu::renderer::RendererState>::render+0x546>
  81e09d:	movq   $0x0,0x20(%rsp)
  81e0a6:	mov    0x100(%rsp),%rax
  81e0ae:	mov    0x98(%rax),%rdx
  81e0b5:	add    0xb0(%rax),%rdx
  81e0bc:	mov    0x30(%rsp),%ecx
  81e0c0:	shl    $0x10,%ecx
  81e0c3:	add    0x10(%rsp),%ecx
  81e0c7:	mov    %rax,0x130(%rsp)
  81e0cf:	movq   $0x0,0x138(%rsp)
  81e0db:	mov    0x108(%rsp),%rbx
  81e0e3:	mov    %rbx,0x140(%rsp)
  81e0eb:	mov    %rdx,0x340(%rsp)
  81e0f3:	mov    %rdx,0x148(%rsp)
  81e0fb:	mov    %ecx,0x30(%rsp)
  81e0ff:	mov    %ecx,0x150(%rsp)
  81e106:	mov    0x8(%rsp),%r13
  81e10b:	movzbl 0x341(%r13),%esi
  81e113:	lea    0x130(%rsp),%rdi
  81e11b:	call   81c280 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>>
  81e120:	mov    %rax,0x110(%rsp)
  81e128:	mov    0x20(%rsp),%rcx
  81e12d:	lea    (%rcx,%rax,4),%rcx
  81e131:	mov    %rcx,0x10(%rsp)
  81e136:	lea    (%rcx,%rbx,2),%rax
  81e13a:	xor    %edx,%edx
  81e13c:	mov    %rax,0x2b8(%rsp)
  81e144:	sub    0x348(%rsp),%rax
  81e14c:	cmovae %rax,%rdx
  81e150:	mov    0x10(%r13),%rsi
  81e154:	mov    $0x4,%ecx
  81e159:	mov    $0x10,%r8d
  81e15f:	mov    %r13,%rdi
  81e162:	call   824480 <<alloc::raw_vec::RawVecInner>::try_reserve_exact>
  81e167:	cmp    $0xffffffffffffffff,%rax
  81e16b:	je     81e17d <<gpui_gpu::renderer::RendererState>::render+0x61d>
  81e16d:	mov    0x50(%rsp),%rdi
  81e172:	movl   $0x6,(%rdi)
  81e178:	jmp    81dd0f <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81e17d:	pxor   %xmm0,%xmm0
  81e181:	movdqa %xmm0,0x130(%rsp)
  81e18a:	lea    0x130(%rsp),%rdx
  81e192:	mov    0x8(%rsp),%rbx
  81e197:	mov    %rbx,%rdi
  81e19a:	mov    0x108(%rsp),%rax
  81e1a2:	mov    0x10(%rsp),%rcx
  81e1a7:	lea    (%rcx,%rax,2),%rsi
  81e1ab:	call   8224c0 <<alloc::vec::Vec<[u32; 4]>>::resize>
  81e1b0:	movq   $0xffffffffffffffff,0x2d0(%rsp)
  81e1bc:	movq   $0x0,0x2d8(%rsp)
  81e1c8:	movq   $0xffffffffffffffff,0x230(%rsp)
  81e1d4:	movq   $0x0,0x238(%rsp)
  81e1e0:	mov    0x10(%rbx),%rdx
  81e1e4:	cmp    %rdx,0x20(%rsp)
  81e1e9:	ja     81fe7d <<gpui_gpu::renderer::RendererState>::render+0x231d>
  81e1ef:	mov    0x8(%rsp),%r13
  81e1f4:	mov    0x8(%r13),%rdi
  81e1f8:	lea    0x2d0(%rsp),%r8
  81e200:	mov    0x20(%rsp),%rsi
  81e205:	mov    0x120(%rsp),%rdx
  81e20d:	mov    0x2c0(%rsp),%rcx
  81e215:	call   823e60 <gpui_gpu::renderer::slots::write_prefix>
  81e21a:	lea    0x48(%r13),%rdi
  81e21e:	movq   $0x0,0x58(%r13)
  81e226:	mov    %rdi,0x4c0(%rsp)
  81e22e:	mov    0x40(%rsp),%rsi
  81e233:	xor    %edx,%edx
  81e235:	call   8225b0 <<alloc::vec::Vec<u32>>::resize>
  81e23a:	movq   $0x0,0x70(%r13)
  81e242:	cmpq   $0x0,0x60(%r13)
  81e247:	jne    81e258 <<gpui_gpu::renderer::RendererState>::render+0x6f8>
  81e249:	mov    0x8(%rsp),%rax
  81e24e:	lea    0x60(%rax),%rdi
  81e252:	call   *0x6615c8(%rip)        # e7f820 <_DYNAMIC+0x5b0>
  81e258:	mov    0x110(%rsp),%rax
  81e260:	add    %rax,%rax
  81e263:	mov    %rax,0x110(%rsp)
  81e26b:	mov    0x8(%rsp),%rax
  81e270:	mov    0x68(%rax),%rcx
  81e274:	pxor   %xmm0,%xmm0
  81e278:	movdqu %xmm0,0x10(%rcx)
  81e27d:	movdqu %xmm0,(%rcx)
  81e281:	movq   $0x1,0x70(%rax)
  81e289:	lea    0x2f8(%rax),%rdi
  81e290:	call   8259f0 <<hashbrown::raw::RawTable<([u32; 8], u32)>>::clear>
  81e295:	mov    0x100(%rsp),%rax
  81e29d:	mov    %rax,0x368(%rsp)
  81e2a5:	movq   $0x0,0x370(%rsp)
  81e2b1:	mov    0x108(%rsp),%rax
  81e2b9:	mov    %rax,0x378(%rsp)
  81e2c1:	mov    0x340(%rsp),%rax
  81e2c9:	mov    %rax,0x380(%rsp)
  81e2d1:	mov    0x30(%rsp),%eax
  81e2d5:	mov    %eax,0x388(%rsp)
  81e2dc:	lea    0x408(%rsp),%rdi
  81e2e4:	lea    0x368(%rsp),%rsi
  81e2ec:	call   *0x661536(%rip)        # e7f828 <_DYNAMIC+0x5b8>
  81e2f2:	mov    0x408(%rsp),%rax
  81e2fa:	mov    %rax,0x28(%rsp)
  81e2ff:	test   %rax,%rax
  81e302:	je     81ed8e <<gpui_gpu::renderer::RendererState>::render+0x122e>
  81e308:	movq   $0x0,0x118(%rsp)
  81e314:	movq   $0x0,0x68(%rsp)
  81e31d:	movq   $0x0,0x88(%rsp)
  81e329:	movq   $0x0,0x2a8(%rsp)
  81e335:	movq   $0x0,0x2b0(%rsp)
  81e341:	mov    0x410(%rsp),%rbx
  81e349:	mov    0x418(%rsp),%r13
  81e351:	lea    0x420(%rsp),%rcx
  81e359:	movups (%rcx),%xmm0
  81e35c:	movups 0x10(%rcx),%xmm1
  81e360:	movups 0x20(%rcx),%xmm2
  81e364:	movaps %xmm2,0x290(%rsp)
  81e36c:	movaps %xmm1,0x280(%rsp)
  81e374:	movaps %xmm0,0x270(%rsp)
  81e37c:	lea    0x450(%rsp),%rdx
  81e384:	movups (%rdx),%xmm0
  81e387:	movaps %xmm0,0x330(%rsp)
  81e38f:	movups 0x40(%rcx),%xmm0
  81e393:	movaps %xmm0,0x320(%rsp)
  81e39b:	mov    0x8(%rsp),%rax
  81e3a0:	movzbl 0x341(%rax),%esi
  81e3a7:	mov    0x28(%rsp),%rax
  81e3ac:	mov    %rax,0x130(%rsp)
  81e3b4:	mov    %rbx,0x138(%rsp)
  81e3bc:	mov    %r13,0x140(%rsp)
  81e3c4:	movups (%rcx),%xmm0
  81e3c7:	movdqu 0x10(%rcx),%xmm1
  81e3cc:	movdqu 0x20(%rcx),%xmm2
  81e3d1:	lea    0x148(%rsp),%rdi
  81e3d9:	movdqu %xmm2,0x20(%rdi)
  81e3de:	movdqu %xmm1,0x10(%rdi)
  81e3e3:	movups %xmm0,(%rdi)
  81e3e6:	movups (%rdx),%xmm0
  81e3e9:	lea    0x178(%rsp),%rax
  81e3f1:	movups %xmm0,(%rax)
  81e3f4:	movdqu 0x40(%rcx),%xmm0
  81e3f9:	movdqu %xmm0,0x40(%rdi)
  81e3fe:	lea    0x130(%rsp),%rdi
  81e406:	call   820f90 <gpui_gpu::renderer::compact_group>
  81e40b:	mov    %rbx,0xa8(%rsp)
  81e413:	mov    %r13,0xe0(%rsp)
  81e41b:	lea    (%rbx,%r13,4),%rbx
  81e41f:	mov    %al,0x1f(%rsp)
  81e423:	test   %al,%al
  81e425:	je     81e61a <<gpui_gpu::renderer::RendererState>::render+0xaba>
  81e42b:	mov    0xa8(%rsp),%rax
  81e433:	mov    %rax,0x490(%rsp)
  81e43b:	mov    %rbx,0x498(%rsp)
  81e443:	mov    0x28(%rsp),%rax
  81e448:	mov    %rax,0x4a0(%rsp)
  81e450:	movq   $0x0,0x4a8(%rsp)
  81e45c:	lea    0x3a0(%rsp),%rdi
  81e464:	lea    0x490(%rsp),%rsi
  81e46c:	call   821620 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81e471:	cmpb   $0xff,0x3a8(%rsp)
  81e479:	je     81e628 <<gpui_gpu::renderer::RendererState>::render+0xac8>
  81e47f:	pxor   %xmm0,%xmm0
  81e483:	movdqa %xmm0,0x70(%rsp)
  81e489:	movdqa %xmm0,0x40(%rsp)
  81e48f:	mov    0x3a0(%rsp),%rdx
  81e497:	add    0x88(%rsp),%rdx
  81e49f:	lea    0x3a8(%rsp),%rcx
  81e4a7:	movups 0x38(%rcx),%xmm0
  81e4ab:	lea    0x148(%rsp),%rax
  81e4b3:	movups %xmm0,0x20(%rax)
  81e4b7:	movups 0x48(%rcx),%xmm0
  81e4bb:	lea    0x178(%rsp),%rsi
  81e4c3:	movups %xmm0,0x40(%rsi)
  81e4c7:	mov    0x30(%rcx),%rax
  81e4cb:	mov    %rax,0x160(%rsp)
  81e4d3:	movups (%rcx),%xmm0
  81e4d6:	movups 0x10(%rcx),%xmm1
  81e4da:	movups 0x20(%rcx),%xmm2
  81e4de:	movaps %xmm2,0x150(%rsp)
  81e4e6:	movaps %xmm1,0x140(%rsp)
  81e4ee:	movaps %xmm0,0x130(%rsp)
  81e4f6:	lea    0x420(%rsp),%rax
  81e4fe:	movups (%rax),%xmm0
  81e501:	movups 0x10(%rax),%xmm1
  81e505:	movups 0x20(%rax),%xmm2
  81e509:	movups %xmm2,0x20(%rsi)
  81e50d:	movups %xmm1,0x10(%rsi)
  81e511:	movups %xmm0,(%rsi)
  81e514:	lea    0x450(%rsp),%rcx
  81e51c:	movups (%rcx),%xmm0
  81e51f:	movups %xmm0,0x30(%rsi)
  81e523:	movups 0x40(%rax),%xmm0
  81e527:	movups %xmm0,0x50(%rsi)
  81e52b:	lea    0x240(%rsp),%rdi
  81e533:	lea    0x130(%rsp),%rsi
  81e53b:	mov    %r14d,%ecx
  81e53e:	mov    %r15d,%r8d
  81e541:	call   820fe0 <gpui_gpu::renderer::validate_draw>
  81e546:	mov    0x240(%rsp),%ecx
  81e54d:	mov    0x244(%rsp),%rax
  81e555:	cmp    $0xffffffff,%ecx
  81e558:	jne    81ee6a <<gpui_gpu::renderer::RendererState>::render+0x130a>
  81e55e:	mov    %eax,%ecx
  81e560:	shr    $0x20,%rax
  81e564:	movd   %ecx,%xmm0
  81e568:	movaps 0x70(%rsp),%xmm2
  81e56d:	movaps %xmm2,%xmm1
  81e570:	maxss  %xmm0,%xmm1
  81e574:	movaps %xmm1,%xmm3
  81e577:	cmpunordss %xmm1,%xmm3
  81e57c:	movaps %xmm3,%xmm0
  81e57f:	andnps %xmm1,%xmm0
  81e582:	andps  %xmm2,%xmm3
  81e585:	orps   %xmm0,%xmm3
  81e588:	movaps %xmm3,0xc0(%rsp)
  81e590:	movd   %eax,%xmm0
  81e594:	movaps 0x40(%rsp),%xmm2
  81e599:	movaps %xmm2,%xmm1
  81e59c:	maxss  %xmm0,%xmm1
  81e5a0:	movaps %xmm1,%xmm3
  81e5a3:	cmpunordss %xmm1,%xmm3
  81e5a8:	movaps %xmm3,%xmm0
  81e5ab:	andnps %xmm1,%xmm0
  81e5ae:	andps  %xmm2,%xmm3
  81e5b1:	orps   %xmm0,%xmm3
  81e5b4:	movaps %xmm3,0xb0(%rsp)
  81e5bc:	lea    0x3a0(%rsp),%rdi
  81e5c4:	lea    0x490(%rsp),%rsi
  81e5cc:	call   821620 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81e5d1:	cmpb   $0xff,0x3a8(%rsp)
  81e5d9:	movdqa 0xc0(%rsp),%xmm1
  81e5e2:	movdqa %xmm1,0x70(%rsp)
  81e5e8:	movdqa 0xb0(%rsp),%xmm2
  81e5f1:	movdqa %xmm2,0x40(%rsp)
  81e5f7:	jne    81e48f <<gpui_gpu::renderer::RendererState>::render+0x92f>
  81e5fd:	movdqa %xmm1,%xmm0
  81e601:	movd   %xmm0,%ecx
  81e605:	movd   %xmm2,%eax
  81e609:	shl    $0x20,%rax
  81e60d:	or     %rax,%rcx
  81e610:	mov    %rcx,0xf8(%rsp)
  81e618:	jmp    81e634 <<gpui_gpu::renderer::RendererState>::render+0xad4>
  81e61a:	movq   $0x0,0xf8(%rsp)
  81e626:	jmp    81e64c <<gpui_gpu::renderer::RendererState>::render+0xaec>
  81e628:	movq   $0x0,0xf8(%rsp)
  81e634:	incq   0x2a8(%rsp)
  81e63c:	mov    0xe0(%rsp),%rax
  81e644:	add    %rax,0x2b0(%rsp)
  81e64c:	mov    0xa8(%rsp),%rax
  81e654:	mov    %rax,0x240(%rsp)
  81e65c:	mov    %rbx,0x248(%rsp)
  81e664:	mov    0x28(%rsp),%rax
  81e669:	mov    %rax,0x250(%rsp)
  81e671:	movq   $0x0,0x258(%rsp)
  81e67d:	lea    0x3a0(%rsp),%rdi
  81e685:	lea    0x240(%rsp),%rsi
  81e68d:	call   821620 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81e692:	movzbl 0x3a8(%rsp),%eax
  81e69a:	cmp    $0xff,%al
  81e69c:	je     81ed60 <<gpui_gpu::renderer::RendererState>::render+0x1200>
  81e6a2:	mov    %eax,%r8d
  81e6a5:	mov    0x10(%rsp),%rax
  81e6aa:	lea    0x8(,%rax,8),%rax
  81e6b2:	mov    %rax,0x128(%rsp)
  81e6ba:	mov    0x20(%rsp),%rax
  81e6bf:	mov    %rax,0x80(%rsp)
  81e6c7:	mov    0x3a0(%rsp),%rax
  81e6cf:	movups 0x3e0(%rsp),%xmm3
  81e6d7:	lea    0x3a8(%rsp),%rsi
  81e6df:	movups 0x48(%rsi),%xmm0
  81e6e3:	lea    0x518(%rsp),%rdi
  81e6eb:	movups %xmm0,0x40(%rdi)
  81e6ef:	mov    0x1(%rsi),%ecx
  81e6f2:	mov    0x4(%rsi),%edx
  81e6f5:	mov    %edx,-0x44(%rdi)
  81e6f8:	mov    %ecx,-0x47(%rdi)
  81e6fb:	mov    0x3b0(%rsp),%rdx
  81e703:	mov    0x30(%rsi),%rcx
  81e707:	mov    %rcx,-0x18(%rdi)
  81e70b:	movups 0x10(%rsi),%xmm0
  81e70f:	movups 0x20(%rsi),%xmm1
  81e713:	movups %xmm1,-0x28(%rdi)
  81e717:	movups %xmm0,-0x38(%rdi)
  81e71b:	movaps 0x270(%rsp),%xmm0
  81e723:	movaps 0x280(%rsp),%xmm1
  81e72b:	movaps 0x290(%rsp),%xmm2
  81e733:	movups %xmm2,0x20(%rdi)
  81e737:	movups %xmm1,0x10(%rdi)
  81e73b:	movups %xmm0,(%rdi)
  81e73e:	movaps 0x330(%rsp),%xmm0
  81e746:	movups %xmm0,0x30(%rdi)
  81e74a:	movaps 0x320(%rsp),%xmm0
  81e752:	movups %xmm0,0x50(%rdi)
  81e756:	movaps %xmm3,0xc0(%rsp)
  81e75e:	movups %xmm3,0x508(%rsp)
  81e766:	mov    %r8b,0x70(%rsp)
  81e76b:	mov    %r8b,0x4d0(%rsp)
  81e773:	mov    %rdx,0x310(%rsp)
  81e77b:	mov    %rdx,0x4d8(%rsp)
  81e783:	cmpb   $0x0,0x1f(%rsp)
  81e788:	je     81e7d0 <<gpui_gpu::renderer::RendererState>::render+0xc70>
  81e78a:	mov    0xf8(%rsp),%rcx
  81e792:	mov    %rcx,0x40(%rsp)
  81e797:	mov    0x20(%rsp),%rcx
  81e79c:	mov    %rcx,0xb0(%rsp)
  81e7a4:	test   %rax,%rax
  81e7a7:	je     81e820 <<gpui_gpu::renderer::RendererState>::render+0xcc0>
  81e7a9:	mov    0xf8(%rsp),%rax
  81e7b1:	mov    %rax,0x40(%rsp)
  81e7b6:	mov    0x20(%rsp),%rax
  81e7bb:	mov    %rax,0xb0(%rsp)
  81e7c3:	lea    0x130(%rsp),%rbx
  81e7cb:	jmp    81eb38 <<gpui_gpu::renderer::RendererState>::render+0xfd8>
  81e7d0:	lea    0x130(%rsp),%rdi
  81e7d8:	lea    0x4d0(%rsp),%rsi
  81e7e0:	mov    0x88(%rsp),%rdx
  81e7e8:	mov    %r14d,%ecx
  81e7eb:	mov    %r15d,%r8d
  81e7ee:	call   820fe0 <gpui_gpu::renderer::validate_draw>
  81e7f3:	mov    0x130(%rsp),%eax
  81e7fa:	mov    0x134(%rsp),%rcx
  81e802:	mov    %rcx,0x40(%rsp)
  81e807:	cmp    $0xffffffff,%eax
  81e80a:	jne    81eef8 <<gpui_gpu::renderer::RendererState>::render+0x1398>
  81e810:	mov    0x80(%rsp),%rax
  81e818:	mov    %rax,0xb0(%rsp)
  81e820:	cmpb   $0x3,0x70(%rsp)
  81e825:	jne    81e8ba <<gpui_gpu::renderer::RendererState>::render+0xd5a>
  81e82b:	movss  0x4d4(%rsp),%xmm0
  81e834:	xorps  %xmm1,%xmm1
  81e837:	ucomiss %xmm1,%xmm0
  81e83a:	jne    81e83e <<gpui_gpu::renderer::RendererState>::render+0xcde>
  81e83c:	jnp    81e8ba <<gpui_gpu::renderer::RendererState>::render+0xd5a>
  81e83e:	movaps 0xc0(%rsp),%xmm5
  81e846:	movaps %xmm5,%xmm1
  81e849:	unpckhpd %xmm5,%xmm1
  81e84d:	movss  -0x76f8e9(%rip),%xmm4        # aef6c <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  81e855:	mulss  %xmm4,%xmm1
  81e859:	movaps %xmm0,%xmm2
  81e85c:	minss  %xmm1,%xmm2
  81e860:	movaps %xmm2,%xmm1
  81e863:	cmpunordss %xmm2,%xmm1
  81e868:	movaps %xmm1,%xmm3
  81e86b:	andnps %xmm2,%xmm3
  81e86e:	andps  %xmm0,%xmm1
  81e871:	orps   %xmm3,%xmm1
  81e874:	movaps %xmm5,%xmm0
  81e877:	shufps $0xff,%xmm5,%xmm0
  81e87b:	mulss  %xmm4,%xmm0
  81e87f:	movaps %xmm1,%xmm2
  81e882:	minss  %xmm0,%xmm2
  81e886:	movaps %xmm2,%xmm0
  81e889:	cmpunordss %xmm2,%xmm0
  81e88e:	andps  %xmm0,%xmm1
  81e891:	andnps %xmm2,%xmm0
  81e894:	orps   %xmm1,%xmm0
  81e897:	movd   %xmm0,%eax
  81e89b:	mov    %eax,0x260(%rsp)
  81e8a2:	and    $0xff800000,%eax
  81e8a7:	mov    $0x7f000000,%ecx
  81e8ac:	sub    %eax,%ecx
  81e8ae:	mov    %ecx,0xd8(%rsp)
  81e8b5:	xorps  %xmm0,%xmm0
  81e8b8:	jmp    81e8df <<gpui_gpu::renderer::RendererState>::render+0xd7f>
  81e8ba:	mov    0x568(%rsp),%eax
  81e8c1:	mov    %eax,0x260(%rsp)
  81e8c8:	mov    0x56c(%rsp),%eax
  81e8cf:	mov    %eax,0xd8(%rsp)
  81e8d6:	movsd  0x570(%rsp),%xmm0
  81e8df:	movaps %xmm0,0x300(%rsp)
  81e8e7:	movups 0x518(%rsp),%xmm0
  81e8ef:	movaps %xmm0,0x470(%rsp)
  81e8f7:	movups 0x520(%rsp),%xmm0
  81e8ff:	movaps %xmm0,0x390(%rsp)
  81e907:	movsd  0x528(%rsp),%xmm0
  81e910:	movaps %xmm0,0x220(%rsp)
  81e918:	movsd  0x530(%rsp),%xmm0
  81e921:	movaps %xmm0,0x2f0(%rsp)
  81e929:	movsd  0x538(%rsp),%xmm0
  81e932:	movsd  %xmm0,0x98(%rsp)
  81e93b:	movsd  0x540(%rsp),%xmm0
  81e944:	movsd  %xmm0,0x2c8(%rsp)
  81e94d:	movups 0x548(%rsp),%xmm0
  81e955:	movaps %xmm0,0x480(%rsp)
  81e95d:	mov    0x28(%rsp),%rax
  81e962:	mov    %rax,0x130(%rsp)
  81e96a:	mov    0xa8(%rsp),%rax
  81e972:	mov    %rax,0x138(%rsp)
  81e97a:	mov    0xe0(%rsp),%rax
  81e982:	mov    %rax,0x140(%rsp)
  81e98a:	movaps 0x270(%rsp),%xmm0
  81e992:	movaps 0x280(%rsp),%xmm1
  81e99a:	movaps 0x290(%rsp),%xmm2
  81e9a2:	lea    0x148(%rsp),%rcx
  81e9aa:	movups %xmm2,0x20(%rcx)
  81e9ae:	movups %xmm1,0x10(%rcx)
  81e9b2:	movups %xmm0,(%rcx)
  81e9b5:	movaps 0x330(%rsp),%xmm0
  81e9bd:	lea    0x178(%rsp),%rax
  81e9c5:	movups %xmm0,(%rax)
  81e9c8:	movaps 0x320(%rsp),%xmm0
  81e9d0:	movups %xmm0,0x40(%rcx)
  81e9d4:	lea    0x130(%rsp),%rdi
  81e9dc:	call   *0x660e4e(%rip)        # e7f830 <_DYNAMIC+0x5c0>
  81e9e2:	test   %eax,%eax
  81e9e4:	je     81ea12 <<gpui_gpu::renderer::RendererState>::render+0xeb2>
  81e9e6:	mov    0x2c0(%rsp),%rdi
  81e9ee:	mov    %eax,%esi
  81e9f0:	call   823e20 <gpui_gpu::renderer::slots::color_word>
  81e9f5:	mov    %eax,0x260(%rsp)
  81e9fc:	xorps  %xmm0,%xmm0
  81e9ff:	movaps %xmm0,0x300(%rsp)
  81ea07:	movl   $0x0,0xd8(%rsp)
  81ea12:	movsd  0x2c8(%rsp),%xmm0
  81ea1b:	cvtsd2ss %xmm0,%xmm0
  81ea1f:	movapd 0x390(%rsp),%xmm1
  81ea28:	unpcklpd 0x2f0(%rsp),%xmm1
  81ea31:	cvtpd2ps %xmm1,%xmm1
  81ea35:	movsd  0x98(%rsp),%xmm2
  81ea3e:	cvtsd2ss %xmm2,%xmm2
  81ea42:	movapd 0x470(%rsp),%xmm3
  81ea4b:	unpcklpd 0x220(%rsp),%xmm3
  81ea54:	cvtpd2ps %xmm3,%xmm3
  81ea58:	mov    0x40(%rsp),%rcx
  81ea5d:	mov    %rcx,%rax
  81ea60:	shr    $0x20,%rax
  81ea64:	mov    0x8(%rsp),%rdx
  81ea69:	mov    0x8(%rdx),%rsi
  81ea6d:	mov    0x10(%rdx),%rdx
  81ea71:	movlpd %xmm3,0x130(%rsp)
  81ea7a:	movss  %xmm2,0x138(%rsp)
  81ea83:	mov    %ecx,0x13c(%rsp)
  81ea8a:	movlpd %xmm1,0x140(%rsp)
  81ea93:	movss  %xmm0,0x148(%rsp)
  81ea9c:	mov    %eax,0x14c(%rsp)
  81eaa3:	lea    0x2d0(%rsp),%rdi
  81eaab:	mov    0x80(%rsp),%r13
  81eab3:	mov    %r13,%rcx
  81eab6:	lea    0x130(%rsp),%rbx
  81eabe:	mov    %rbx,%r8
  81eac1:	call   81b1e0 <<gpui_gpu::renderer::Changes>::replace::<2>>
  81eac6:	mov    0x8(%rsp),%rax
  81eacb:	mov    0x8(%rax),%rsi
  81eacf:	mov    0x10(%rax),%rdx
  81ead3:	mov    0x110(%rsp),%rax
  81eadb:	lea    0x0(%r13,%rax,1),%rcx
  81eae0:	movaps 0x480(%rsp),%xmm0
  81eae8:	movaps %xmm0,0x130(%rsp)
  81eaf0:	mov    0x260(%rsp),%eax
  81eaf7:	mov    %eax,0x140(%rsp)
  81eafe:	mov    0xd8(%rsp),%eax
  81eb05:	mov    %eax,0x144(%rsp)
  81eb0c:	movaps 0x300(%rsp),%xmm0
  81eb14:	movlps %xmm0,0x148(%rsp)
  81eb1c:	lea    0x2d0(%rsp),%rdi
  81eb24:	mov    %rbx,%r8
  81eb27:	call   81b1e0 <<gpui_gpu::renderer::Changes>::replace::<2>>
  81eb2c:	add    $0x2,%r13
  81eb30:	mov    %r13,0x80(%rsp)
  81eb38:	cmpb   $0x2,0x70(%rsp)
  81eb3d:	sete   0x260(%rsp)
  81eb45:	cmpq   $0x0,0x310(%rsp)
  81eb4e:	setne  0x310(%rsp)
  81eb56:	mov    0x28(%rsp),%rax
  81eb5b:	mov    %rax,0x130(%rsp)
  81eb63:	mov    0xa8(%rsp),%rax
  81eb6b:	mov    %rax,0x138(%rsp)
  81eb73:	mov    0xe0(%rsp),%rax
  81eb7b:	mov    %rax,0x140(%rsp)
  81eb83:	movaps 0x270(%rsp),%xmm0
  81eb8b:	movdqa 0x280(%rsp),%xmm1
  81eb94:	movdqa 0x290(%rsp),%xmm2
  81eb9d:	lea    0x148(%rsp),%rcx
  81eba5:	movdqu %xmm2,0x20(%rcx)
  81ebaa:	movdqu %xmm1,0x10(%rcx)
  81ebaf:	movups %xmm0,(%rcx)
  81ebb2:	movaps 0x330(%rsp),%xmm0
  81ebba:	lea    0x178(%rsp),%rax
  81ebc2:	movups %xmm0,(%rax)
  81ebc5:	movaps 0x320(%rsp),%xmm0
  81ebcd:	movups %xmm0,0x40(%rcx)
  81ebd1:	mov    %rbx,%rdi
  81ebd4:	call   *0x660c56(%rip)        # e7f830 <_DYNAMIC+0x5c0>
  81ebda:	mov    %eax,0x70(%rsp)
  81ebde:	mov    0x8(%rsp),%r13
  81ebe3:	mov    0x8(%r13),%rsi
  81ebe7:	mov    0x10(%r13),%rdx
  81ebeb:	movdqa 0xc0(%rsp),%xmm0
  81ebf4:	movdqa %xmm0,0x130(%rsp)
  81ebfd:	lea    0x230(%rsp),%rdi
  81ec05:	mov    %rbx,%r8
  81ec08:	mov    0x10(%rsp),%rbx
  81ec0d:	mov    %rbx,%rcx
  81ec10:	call   81b170 <<gpui_gpu::renderer::Changes>::replace::<1>>
  81ec15:	lea    0x1(%rbx),%rcx
  81ec19:	mov    0x10(%r13),%rdx
  81ec1d:	cmp    %rdx,%rcx
  81ec20:	jae    81fea7 <<gpui_gpu::renderer::RendererState>::render+0x2347>
  81ec26:	mov    0xb0(%rsp),%rsi
  81ec2e:	mov    %esi,%edi
  81ec30:	or     $0x80000000,%edi
  81ec36:	cmpl   $0x0,0x70(%rsp)
  81ec3b:	cmove  %esi,%edi
  81ec3e:	mov    0x8(%r13),%rsi
  81ec42:	mov    0x128(%rsp),%r13
  81ec4a:	mov    0x8(%rsi,%r13,2),%r8d
  81ec4f:	mov    %r8d,0x138(%rsp)
  81ec57:	mov    (%rsi,%r13,2),%r8
  81ec5b:	mov    %r8,0x130(%rsp)
  81ec63:	mov    %edi,0x13c(%rsp)
  81ec6a:	lea    0x230(%rsp),%rdi
  81ec72:	lea    0x130(%rsp),%r8
  81ec7a:	call   81b170 <<gpui_gpu::renderer::Changes>::replace::<1>>
  81ec7f:	lea    0x130(%rsp),%rdi
  81ec87:	mov    0x8(%rsp),%rsi
  81ec8c:	lea    0x4d0(%rsp),%rdx
  81ec94:	mov    0x40(%rsp),%rcx
  81ec99:	mov    %rbx,0x10(%rsp)
  81ec9e:	mov    %ebx,%r8d
  81eca1:	mov    0x88(%rsp),%rbx
  81eca9:	mov    %rbx,%r9
  81ecac:	push   0x118(%rsp)
  81ecb3:	push   %r15
  81ecb5:	push   %r14
  81ecb7:	push   0xa8(%rsp)
  81ecbe:	call   81ff30 <<gpui_gpu::renderer::RendererState>::bin_draw>
  81ecc3:	add    $0x20,%rsp
  81ecc7:	mov    0x130(%rsp),%eax
  81ecce:	cmp    $0xffffffff,%eax
  81ecd1:	jne    81eec8 <<gpui_gpu::renderer::RendererState>::render+0x1368>
  81ecd7:	movzbl 0x260(%rsp),%ecx
  81ecdf:	and    0x310(%rsp),%cl
  81ece6:	mov    0x68(%rsp),%rax
  81eceb:	or     %cl,%al
  81eced:	mov    %rax,0x68(%rsp)
  81ecf2:	addq   $0x2,0x10(%rsp)
  81ecf8:	mov    0x138(%rsp),%rax
  81ed00:	mov    %rax,0x118(%rsp)
  81ed08:	inc    %rbx
  81ed0b:	mov    %rbx,0x88(%rsp)
  81ed13:	lea    0x3a0(%rsp),%rdi
  81ed1b:	lea    0x240(%rsp),%rsi
  81ed23:	call   821620 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81ed28:	movzbl 0x3a8(%rsp),%r8d
  81ed31:	add    $0x10,%r13
  81ed35:	mov    %r13,0x128(%rsp)
  81ed3d:	cmp    $0xff,%r8b
  81ed41:	jne    81e6c7 <<gpui_gpu::renderer::RendererState>::render+0xb67>
  81ed47:	mov    0x68(%rsp),%rax
  81ed4c:	and    $0x1,%al
  81ed4e:	mov    %rax,0x68(%rsp)
  81ed53:	mov    0x80(%rsp),%rax
  81ed5b:	mov    %rax,0x20(%rsp)
  81ed60:	lea    0x408(%rsp),%rdi
  81ed68:	lea    0x368(%rsp),%rsi
  81ed70:	call   *0x660ab2(%rip)        # e7f828 <_DYNAMIC+0x5b8>
  81ed76:	mov    0x408(%rsp),%rax
  81ed7e:	mov    %rax,0x28(%rsp)
  81ed83:	test   %rax,%rax
  81ed86:	jne    81e341 <<gpui_gpu::renderer::RendererState>::render+0x7e1>
  81ed8c:	jmp    81edc7 <<gpui_gpu::renderer::RendererState>::render+0x1267>
  81ed8e:	movq   $0x0,0x2b0(%rsp)
  81ed9a:	movq   $0x0,0x2a8(%rsp)
  81eda6:	movq   $0x0,0x88(%rsp)
  81edb2:	movq   $0x0,0x68(%rsp)
  81edbb:	movq   $0x0,0x118(%rsp)
  81edc7:	mov    0xa0(%rsp),%rsi
  81edcf:	lea    0x8(%rsi),%rdx
  81edd3:	mov    0x8(%rsp),%rax
  81edd8:	lea    0x258(%rax),%rcx
  81eddf:	lea    0x328(%rax),%r8
  81ede6:	mov    0x10(%rax),%r9
  81edea:	sub    $0x8,%rsp
  81edee:	lea    0x138(%rsp),%rdi
  81edf6:	mov    %rdx,0x2f8(%rsp)
  81edfe:	mov    %rcx,0xa0(%rsp)
  81ee06:	mov    %r8,0x488(%rsp)
  81ee0e:	push   0x128(%rsp)
  81ee15:	call   822700 <gpui_gpu::renderer::images::prepare>
  81ee1a:	add    $0x10,%rsp
  81ee1e:	mov    0x130(%rsp),%eax
  81ee25:	movzbl 0x134(%rsp),%ecx
  81ee2d:	mov    %cl,0x390(%rsp)
  81ee34:	cmp    $0xffffffff,%eax
  81ee37:	je     81ee90 <<gpui_gpu::renderer::RendererState>::render+0x1330>
  81ee39:	movupd 0x135(%rsp),%xmm0
  81ee42:	movups 0x140(%rsp),%xmm1
  81ee4a:	mov    0x50(%rsp),%rdi
  81ee4f:	movups %xmm1,0x10(%rdi)
  81ee53:	movupd %xmm0,0x5(%rdi)
  81ee58:	mov    %eax,(%rdi)
  81ee5a:	movzbl 0x390(%rsp),%eax
  81ee62:	mov    %al,0x4(%rdi)
  81ee65:	jmp    81dd0f <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81ee6a:	mov    0x25c(%rsp),%edx
  81ee71:	mov    0x50(%rsp),%rdi
  81ee76:	mov    %edx,0x1c(%rdi)
  81ee79:	movups 0x24c(%rsp),%xmm0
  81ee81:	movups %xmm0,0xc(%rdi)
  81ee85:	mov    %ecx,(%rdi)
  81ee87:	mov    %rax,0x4(%rdi)
  81ee8b:	jmp    81dd0f <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81ee90:	movzbl 0x68(%rsp),%r8d
  81ee96:	and    $0x1,%r8d
  81ee9a:	lea    0x130(%rsp),%rdi
  81eea2:	mov    0x8(%rsp),%rsi
  81eea7:	mov    0xa0(%rsp),%rdx
  81eeaf:	mov    0x100(%rsp),%rcx
  81eeb7:	call   81d2c0 <<gpui_gpu::renderer::RendererState>::prepare_atlas>
  81eebc:	mov    0x130(%rsp),%eax
  81eec3:	cmp    $0xffffffff,%eax
  81eec6:	je     81ef23 <<gpui_gpu::renderer::RendererState>::render+0x13c3>
  81eec8:	mov    0x134(%rsp),%ecx
  81eecf:	mov    0x138(%rsp),%rdx
  81eed7:	movupd 0x140(%rsp),%xmm0
  81eee0:	mov    0x50(%rsp),%rdi
  81eee5:	movupd %xmm0,0x10(%rdi)
  81eeea:	mov    %eax,(%rdi)
  81eeec:	mov    %ecx,0x4(%rdi)
  81eeef:	mov    %rdx,0x8(%rdi)
  81eef3:	jmp    81dd0f <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81eef8:	mov    0x14c(%rsp),%ecx
  81eeff:	mov    0x50(%rsp),%rdi
  81ef04:	mov    %ecx,0x1c(%rdi)
  81ef07:	movups 0x13c(%rsp),%xmm0
  81ef0f:	movups %xmm0,0xc(%rdi)
  81ef13:	mov    %eax,(%rdi)
  81ef15:	mov    0x40(%rsp),%rax
  81ef1a:	mov    %rax,0x4(%rdi)
  81ef1e:	jmp    81dd0f <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81ef23:	mov    0x138(%rsp),%rax
  81ef2b:	mov    %rax,0x2c8(%rsp)
  81ef33:	mov    0x8(%rsp),%rax
  81ef38:	mov    0x28(%rax),%rax
  81ef3c:	movq   $0x0,0x220(%rsp)
  81ef48:	test   %rax,%rax
  81ef4b:	je     81efc4 <<gpui_gpu::renderer::RendererState>::render+0x1464>
  81ef4d:	mov    0x8(%rsp),%rcx
  81ef52:	mov    0x20(%rcx),%rcx
  81ef56:	shl    $0x3,%rax
  81ef5a:	xor    %edi,%edi
  81ef5c:	jmp    81ef80 <<gpui_gpu::renderer::RendererState>::render+0x1420>
  81ef5e:	mov    0x220(%rsp),%rdx
  81ef66:	add    %esi,%edx
  81ef68:	mov    %edx,(%rcx,%rdi,8)
  81ef6b:	mov    %rdx,0x220(%rsp)
  81ef73:	mov    %edx,0x4(%rcx,%rdi,8)
  81ef77:	inc    %rdi
  81ef7a:	add    $0xfffffffffffffff8,%rax
  81ef7e:	je     81efb2 <<gpui_gpu::renderer::RendererState>::render+0x1452>
  81ef80:	mov    0x8(%rsp),%rdx
  81ef85:	mov    0x58(%rdx),%rsi
  81ef89:	cmp    %rsi,%rdi
  81ef8c:	jae    81febd <<gpui_gpu::renderer::RendererState>::render+0x235d>
  81ef92:	mov    0x4(%rcx,%rdi,8),%esi
  81ef96:	cmp    $0x1,%esi
  81ef99:	jne    81ef5e <<gpui_gpu::renderer::RendererState>::render+0x13fe>
  81ef9b:	mov    0x8(%rsp),%rdx
  81efa0:	mov    0x50(%rdx),%r8
  81efa4:	mov    $0x80000000,%edx
  81efa9:	cmpl   $0x0,(%r8,%rdi,4)
  81efae:	jne    81ef73 <<gpui_gpu::renderer::RendererState>::render+0x1413>
  81efb0:	jmp    81ef5e <<gpui_gpu::renderer::RendererState>::render+0x13fe>
  81efb2:	mov    0x220(%rsp),%rax
  81efba:	mov    %eax,%eax
  81efbc:	mov    %rax,0x220(%rsp)
  81efc4:	mov    0x8(%rsp),%rax
  81efc9:	lea    0x30(%rax),%rdi
  81efcd:	movq   $0x0,0x40(%rax)
  81efd5:	mov    %rdi,0xd8(%rsp)
  81efdd:	mov    0x220(%rsp),%rsi
  81efe5:	xor    %edx,%edx
  81efe7:	call   8225b0 <<alloc::vec::Vec<u32>>::resize>
  81efec:	mov    0x88(%rsp),%rax
  81eff4:	mov    %rax,0x360(%rsp)
  81effc:	mov    0x100(%rsp),%rax
  81f004:	mov    %rax,0x368(%rsp)
  81f00c:	movq   $0x0,0x370(%rsp)
  81f018:	mov    0x108(%rsp),%rax
  81f020:	mov    %rax,0x378(%rsp)
  81f028:	mov    0x340(%rsp),%rax
  81f030:	mov    %rax,0x380(%rsp)
  81f038:	mov    0x30(%rsp),%eax
  81f03c:	mov    %eax,0x388(%rsp)
  81f043:	lea    0x408(%rsp),%rdi
  81f04b:	lea    0x368(%rsp),%rsi
  81f053:	call   *0x6607df(%rip)        # e7f838 <_DYNAMIC+0x5c8>
  81f059:	mov    0x408(%rsp),%rax
  81f061:	mov    %rax,0x80(%rsp)
  81f069:	test   %rax,%rax
  81f06c:	je     81f5f4 <<gpui_gpu::renderer::RendererState>::render+0x1a94>
  81f072:	mov    0x8(%rsp),%rax
  81f077:	add    $0x120,%rax
  81f07d:	mov    %rax,0x470(%rsp)
  81f085:	mov    0x2b8(%rsp),%rax
  81f08d:	mov    %rax,0xb0(%rsp)
  81f095:	jmp    81f0c6 <<gpui_gpu::renderer::RendererState>::render+0x1566>
  81f097:	lea    0x408(%rsp),%rdi
  81f09f:	lea    0x368(%rsp),%rsi
  81f0a7:	call   *0x66078b(%rip)        # e7f838 <_DYNAMIC+0x5c8>
  81f0ad:	mov    0x408(%rsp),%rax
  81f0b5:	mov    %rax,0x80(%rsp)
  81f0bd:	test   %rax,%rax
  81f0c0:	je     81f5f4 <<gpui_gpu::renderer::RendererState>::render+0x1a94>
  81f0c6:	lea    0x420(%rsp),%rsi
  81f0ce:	movups (%rsi),%xmm0
  81f0d1:	movups 0x10(%rsi),%xmm1
  81f0d5:	movups 0x20(%rsi),%xmm2
  81f0d9:	movaps %xmm2,0x3c0(%rsp)
  81f0e1:	movaps %xmm1,0x3b0(%rsp)
  81f0e9:	movaps %xmm0,0x3a0(%rsp)
  81f0f1:	lea    0x450(%rsp),%rdx
  81f0f9:	movups (%rdx),%xmm0
  81f0fc:	movaps %xmm0,0x320(%rsp)
  81f104:	movdqu 0x40(%rsi),%xmm0
  81f109:	movdqa %xmm0,0x330(%rsp)
  81f112:	mov    0x410(%rsp),%rax
  81f11a:	mov    %rax,0xe0(%rsp)
  81f122:	mov    0x418(%rsp),%rbx
  81f12a:	mov    0x8(%rsp),%rdi
  81f12f:	call   81cee0 <<gpui_gpu::renderer::RendererState>::correction>
  81f134:	mov    %eax,0x300(%rsp)
  81f13b:	test   %rbx,%rbx
  81f13e:	je     81f097 <<gpui_gpu::renderer::RendererState>::render+0x1537>
  81f144:	mov    %rbx,%rcx
  81f147:	shl    $0x2,%rcx
  81f14b:	mov    0x300(%rsp),%eax
  81f152:	shl    $0xf,%eax
  81f155:	mov    %eax,0x20(%rsp)
  81f159:	mov    0xb0(%rsp),%rax
  81f161:	shl    $0x4,%rax
  81f165:	mov    %rax,0x28(%rsp)
  81f16a:	lea    0x138(%rsp),%rbx
  81f172:	lea    0x130(%rsp),%r13
  81f17a:	jmp    81f343 <<gpui_gpu::renderer::RendererState>::render+0x17e3>
  81f17f:	mov    0x60(%rsp),%r9d
  81f184:	or     0x20(%rsp),%r9d
  81f189:	mov    %r9d,0x60(%rsp)
  81f18e:	mov    0x64(%rsp),%r8d
  81f193:	mov    %edi,0x130(%rsp)
  81f19a:	mov    %r9d,0x134(%rsp)
  81f1a2:	mov    %r8d,0x138(%rsp)
  81f1aa:	mov    %eax,0x13c(%rsp)
  81f1b1:	lea    0x230(%rsp),%rdi
  81f1b9:	mov    %rbx,%r8
  81f1bc:	call   81b170 <<gpui_gpu::renderer::Changes>::replace::<1>>
  81f1c1:	add    $0xfffffffffffffffe,%r13
  81f1c5:	mov    %r13,0xb0(%rsp)
  81f1cd:	mov    %r13d,0x2ec(%rsp)
  81f1d5:	movaps 0x260(%rsp),%xmm0
  81f1dd:	movlps %xmm0,0x170(%rsp)
  81f1e5:	movaps 0x3a0(%rsp),%xmm0
  81f1ed:	movaps 0x3b0(%rsp),%xmm1
  81f1f5:	movaps 0x3c0(%rsp),%xmm2
  81f1fd:	lea    0x178(%rsp),%rax
  81f205:	movups %xmm2,0x20(%rax)
  81f209:	movups %xmm1,0x10(%rax)
  81f20d:	movups %xmm0,(%rax)
  81f210:	movaps 0x320(%rsp),%xmm0
  81f218:	movups %xmm0,0x30(%rax)
  81f21c:	movaps 0x490(%rsp),%xmm0
  81f224:	movups %xmm0,0x40(%rax)
  81f228:	movaps 0x330(%rsp),%xmm0
  81f230:	movups %xmm0,0x50(%rax)
  81f234:	mov    0x128(%rsp),%eax
  81f23b:	mov    %al,0x130(%rsp)
  81f242:	movzbl 0x30(%rsp),%eax
  81f247:	mov    %al,0x131(%rsp)
  81f24e:	movzwl 0xa8(%rsp),%eax
  81f256:	mov    %ax,0x132(%rsp)
  81f25e:	movaps 0xc0(%rsp),%xmm0
  81f266:	movss  %xmm0,0x134(%rsp)
  81f26f:	mov    0x250(%rsp),%rax
  81f277:	mov    %rbx,%r13
  81f27a:	lea    0x138(%rsp),%rbx
  81f282:	mov    %rax,0x10(%rbx)
  81f286:	movaps 0x240(%rsp),%xmm0
  81f28e:	movups %xmm0,(%rbx)
  81f291:	mov    0x10(%rsp),%rax
  81f296:	mov    %rax,0x150(%rsp)
  81f29e:	mov    0x40(%rsp),%eax
  81f2a2:	mov    %eax,0x158(%rsp)
  81f2a9:	mov    0x70(%rsp),%eax
  81f2ad:	mov    %eax,0x15c(%rsp)
  81f2b4:	movdqa 0x310(%rsp),%xmm0
  81f2bd:	movdqu %xmm0,0x160(%rsp)
  81f2c6:	mov    0x4c8(%rsp),%rax
  81f2ce:	mov    %rax,0x270(%rsp)
  81f2d6:	mov    0xd8(%rsp),%rax
  81f2de:	mov    %rax,0x278(%rsp)
  81f2e6:	mov    0x4c0(%rsp),%rax
  81f2ee:	mov    %rax,0x280(%rsp)
  81f2f6:	lea    0x360(%rsp),%rax
  81f2fe:	mov    %rax,0x288(%rsp)
  81f306:	lea    0x2ec(%rsp),%rax
  81f30e:	mov    %rax,0x290(%rsp)
  81f316:	mov    %r13,%rdi
  81f319:	mov    0x90(%rsp),%rsi
  81f321:	lea    0x270(%rsp),%rdx
  81f329:	call   81c010 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>>
  81f32e:	addq   $0xffffffffffffffe0,0x28(%rsp)
  81f334:	mov    0x68(%rsp),%rcx
  81f339:	add    $0xfffffffffffffffc,%rcx
  81f33d:	je     81f097 <<gpui_gpu::renderer::RendererState>::render+0x1537>
  81f343:	mov    0xe0(%rsp),%rax
  81f34b:	mov    %rcx,0x68(%rsp)
  81f350:	mov    -0x4(%rax,%rcx,1),%edx
  81f354:	mov    %r13,%rdi
  81f357:	mov    0x80(%rsp),%rsi
  81f35f:	call   81c370 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81f364:	movzbl 0x130(%rsp),%ecx
  81f36c:	movzbl 0x131(%rsp),%eax
  81f374:	mov    %al,0x30(%rsp)
  81f378:	movzwl 0x132(%rsp),%eax
  81f380:	mov    %ax,0xa8(%rsp)
  81f388:	movss  0x134(%rsp),%xmm4
  81f391:	mov    0x10(%rbx),%rax
  81f395:	mov    %rax,0x250(%rsp)
  81f39d:	movups (%rbx),%xmm0
  81f3a0:	movaps %xmm0,0x240(%rsp)
  81f3a8:	mov    0x150(%rsp),%rax
  81f3b0:	mov    %rax,0x10(%rsp)
  81f3b5:	mov    0x158(%rsp),%eax
  81f3bc:	mov    %eax,0x40(%rsp)
  81f3c0:	mov    0x15c(%rsp),%eax
  81f3c7:	mov    %eax,0x70(%rsp)
  81f3cb:	movups 0x160(%rsp),%xmm0
  81f3d3:	movaps %xmm0,0x310(%rsp)
  81f3db:	mov    0x160(%rsp),%rax
  81f3e3:	movsd  0x170(%rsp),%xmm5
  81f3ec:	lea    0x178(%rsp),%rdx
  81f3f4:	movups (%rdx),%xmm0
  81f3f7:	movaps %xmm0,0x490(%rsp)
  81f3ff:	decq   0x360(%rsp)
  81f407:	cmp    $0x1,%ecx
  81f40a:	mov    %ecx,0x128(%rsp)
  81f411:	movaps %xmm4,0xc0(%rsp)
  81f419:	movaps %xmm5,0x260(%rsp)
  81f421:	je     81f487 <<gpui_gpu::renderer::RendererState>::render+0x1927>
  81f423:	cmp    $0x3,%ecx
  81f426:	jne    81f503 <<gpui_gpu::renderer::RendererState>::render+0x19a3>
  81f42c:	mov    0x480(%rsp),%rax
  81f434:	mov    (%rax),%rdi
  81f437:	test   %rdi,%rdi
  81f43a:	je     81fe70 <<gpui_gpu::renderer::RendererState>::render+0x2310>
  81f440:	movzbl 0x30(%rsp),%edx
  81f445:	mov    0x10(%rsp),%rsi
  81f44a:	call   8222a0 <<gpui_gpu::renderer::images::Images>::metadata>
  81f44f:	mov    %eax,%ecx
  81f451:	shr    $0x20,%rax
  81f455:	mov    %eax,%edx
  81f457:	or     $0x10,%edx
  81f45a:	xorps  %xmm0,%xmm0
  81f45d:	movaps 0xc0(%rsp),%xmm1
  81f465:	ucomiss %xmm0,%xmm1
  81f468:	cmovne %edx,%eax
  81f46b:	cmovp  %edx,%eax
  81f46e:	mov    0x70(%rsp),%edx
  81f472:	shl    $0x10,%edx
  81f475:	or     0x40(%rsp),%edx
  81f479:	mov    %ecx,0x5c(%rsp)
  81f47d:	mov    %eax,0x60(%rsp)
  81f481:	mov    %edx,0x64(%rsp)
  81f485:	jmp    81f4f6 <<gpui_gpu::renderer::RendererState>::render+0x1996>
  81f487:	movaps %xmm5,%xmm0
  81f48a:	movss  -0x770526(%rip),%xmm3        # aef6c <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  81f492:	mulss  %xmm3,%xmm0
  81f496:	movaps %xmm4,%xmm1
  81f499:	minss  %xmm0,%xmm1
  81f49d:	movaps %xmm1,%xmm0
  81f4a0:	cmpunordss %xmm1,%xmm0
  81f4a5:	movaps %xmm0,%xmm2
  81f4a8:	andnps %xmm1,%xmm2
  81f4ab:	andps  %xmm4,%xmm0
  81f4ae:	orps   %xmm2,%xmm0
  81f4b1:	movaps %xmm5,%xmm1
  81f4b4:	shufps $0x55,%xmm5,%xmm1
  81f4b8:	mulss  %xmm3,%xmm1
  81f4bc:	movaps %xmm0,%xmm2
  81f4bf:	minss  %xmm1,%xmm2
  81f4c3:	movaps %xmm2,%xmm1
  81f4c6:	cmpunordss %xmm2,%xmm1
  81f4cb:	andps  %xmm1,%xmm0
  81f4ce:	andnps %xmm2,%xmm1
  81f4d1:	orps   %xmm0,%xmm1
  81f4d4:	movd   %xmm1,%eax
  81f4d8:	and    $0xff800000,%eax
  81f4dd:	mov    $0x7f000000,%ecx
  81f4e2:	sub    %eax,%ecx
  81f4e4:	movl   $0x40000000,0x5c(%rsp)
  81f4ec:	movss  %xmm1,0x60(%rsp)
  81f4f2:	mov    %ecx,0x64(%rsp)
  81f4f6:	lea    0x130(%rsp),%rbx
  81f4fe:	jmp    81f59d <<gpui_gpu::renderer::RendererState>::render+0x1a3d>
  81f503:	cmp    $0x2,%cl
  81f506:	jne    81f555 <<gpui_gpu::renderer::RendererState>::render+0x19f5>
  81f508:	mov    0x250(%rsp),%rcx
  81f510:	mov    %rcx,0x140(%rsp)
  81f518:	movaps 0x240(%rsp),%xmm0
  81f520:	movaps %xmm0,0x130(%rsp)
  81f528:	mov    0x10(%rsp),%rcx
  81f52d:	mov    %rcx,0x148(%rsp)
  81f535:	mov    0x40(%rsp),%ecx
  81f539:	mov    %ecx,0x150(%rsp)
  81f540:	mov    0x70(%rsp),%ecx
  81f544:	mov    %ecx,0x154(%rsp)
  81f54b:	mov    %rax,0x158(%rsp)
  81f553:	jmp    81f561 <<gpui_gpu::renderer::RendererState>::render+0x1a01>
  81f555:	movq   $0x0,0x130(%rsp)
  81f561:	movl   $0x0,0x278(%rsp)
  81f56c:	movq   $0x0,0x270(%rsp)
  81f578:	lea    0x5c(%rsp),%rdi
  81f57d:	lea    0x130(%rsp),%rbx
  81f585:	mov    %rbx,%rsi
  81f588:	lea    0x270(%rsp),%rdx
  81f590:	mov    0x470(%rsp),%rcx
  81f598:	call   81b020 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>>
  81f59d:	mov    0xb0(%rsp),%r13
  81f5a5:	lea    -0x1(%r13),%rcx
  81f5a9:	mov    0x8(%rsp),%rax
  81f5ae:	mov    0x10(%rax),%rdx
  81f5b2:	cmp    %rdx,%rcx
  81f5b5:	jae    81fe91 <<gpui_gpu::renderer::RendererState>::render+0x2331>
  81f5bb:	mov    0x8(%rax),%rsi
  81f5bf:	mov    0x28(%rsp),%rax
  81f5c4:	mov    -0x4(%rsi,%rax,1),%eax
  81f5c8:	mov    0x5c(%rsp),%edi
  81f5cc:	cmp    $0x40000000,%edi
  81f5d2:	jne    81f17f <<gpui_gpu::renderer::RendererState>::render+0x161f>
  81f5d8:	mov    0x64(%rsp),%r8d
  81f5dd:	or     0x300(%rsp),%r8d
  81f5e5:	mov    %r8d,0x64(%rsp)
  81f5ea:	mov    0x60(%rsp),%r9d
  81f5ef:	jmp    81f193 <<gpui_gpu::renderer::RendererState>::render+0x1633>
  81f5f4:	mov    0x8(%rsp),%rax
  81f5f9:	mov    0x28(%rax),%rdi
  81f5fd:	xor    %esi,%esi
  81f5ff:	test   %rdi,%rdi
  81f602:	je     81f6e0 <<gpui_gpu::renderer::RendererState>::render+0x1b80>
  81f608:	mov    0x8(%rsp),%rax
  81f60d:	mov    0x20(%rax),%r8
  81f611:	shl    $0x3,%rdi
  81f615:	cmpl   $0x0,0x90(%rsp)
  81f61d:	je     81f8db <<gpui_gpu::renderer::RendererState>::render+0x1d7b>
  81f623:	movq   $0x0,0x70(%rsp)
  81f62c:	movq   $0x0,0x40(%rsp)
  81f635:	movq   $0x0,0x10(%rsp)
  81f63e:	xor    %r9d,%r9d
  81f641:	xor    %ecx,%ecx
  81f643:	jmp    81f66b <<gpui_gpu::renderer::RendererState>::render+0x1b0b>
  81f645:	incq   0x10(%rsp)
  81f64a:	inc    %r9
  81f64d:	cmp    0x90(%rsp),%r9
  81f655:	mov    $0x0,%eax
  81f65a:	cmove  %rax,%r9
  81f65e:	inc    %rcx
  81f661:	add    $0xfffffffffffffff8,%rdi
  81f665:	je     81f6fb <<gpui_gpu::renderer::RendererState>::render+0x1b9b>
  81f66b:	mov    0x4(%r8,%rcx,8),%r10d
  81f670:	mov    %r10d,%eax
  81f673:	neg    %eax
  81f675:	jo     81f645 <<gpui_gpu::renderer::RendererState>::render+0x1ae5>
  81f677:	sub    (%r8,%rcx,8),%r10d
  81f67b:	je     81f64a <<gpui_gpu::renderer::RendererState>::render+0x1aea>
  81f67d:	mov    %rcx,%rax
  81f680:	shr    $0x20,%rax
  81f684:	je     81f698 <<gpui_gpu::renderer::RendererState>::render+0x1b38>
  81f686:	mov    %rcx,%rax
  81f689:	xor    %edx,%edx
  81f68b:	divq   0x90(%rsp)
  81f693:	mov    %r9,%rdx
  81f696:	jmp    81f6a3 <<gpui_gpu::renderer::RendererState>::render+0x1b43>
  81f698:	mov    %ecx,%eax
  81f69a:	xor    %edx,%edx
  81f69c:	divl   0x90(%rsp)
  81f6a3:	shl    $0x4,%edx
  81f6a6:	shl    $0x4,%eax
  81f6a9:	lea    0x10(%rdx),%r11d
  81f6ad:	cmp    %r11d,%r14d
  81f6b0:	cmovb  %r14d,%r11d
  81f6b4:	lea    0x10(%rax),%r13d
  81f6b8:	cmp    %r13d,%r15d
  81f6bb:	cmovb  %r15d,%r13d
  81f6bf:	sub    %edx,%r11d
  81f6c2:	sub    %eax,%r13d
  81f6c5:	imul   %r11d,%r13d
  81f6c9:	shl    $0x4,%r13
  81f6cd:	add    %r13,0x40(%rsp)
  81f6d2:	imul   %r13,%r10
  81f6d6:	add    %r10,0x70(%rsp)
  81f6db:	jmp    81f64a <<gpui_gpu::renderer::RendererState>::render+0x1aea>
  81f6e0:	movq   $0x0,0x10(%rsp)
  81f6e9:	movq   $0x0,0x40(%rsp)
  81f6f2:	movq   $0x0,0x70(%rsp)
  81f6fb:	test   $0x1,%bpl
  81f6ff:	je     81f74c <<gpui_gpu::renderer::RendererState>::render+0x1bec>
  81f701:	movd   0x2e8(%rsp),%xmm0
  81f70a:	movd   %xmm0,%eax
  81f70e:	test   %eax,%eax
  81f710:	setns  %cl
  81f713:	mov    %eax,%edx
  81f715:	and    $0x7fffffff,%edx
  81f71b:	add    $0xff800000,%edx
  81f721:	cmp    $0x7f000000,%edx
  81f727:	setb   %dl
  81f72a:	and    %cl,%dl
  81f72c:	dec    %eax
  81f72e:	cmp    $0x7fffff,%eax
  81f733:	setb   %al
  81f736:	or     %dl,%al
  81f738:	mov    $0x2,%esi
  81f73d:	movd   %xmm0,0xf4(%rsp)
  81f746:	je     81f8d1 <<gpui_gpu::renderer::RendererState>::render+0x1d71>
  81f74c:	mov    0x120(%rsp),%rax
  81f754:	add    $0x18,%rax
  81f758:	xor    %ecx,%ecx
  81f75a:	cmpl   $0x28,0x2e4(%rsp)
  81f762:	sete   %cl
  81f765:	and    $0x1,%r12d
  81f769:	lea    (%r12,%rcx,4),%ecx
  81f76d:	or     %esi,%ecx
  81f76f:	movups (%rax),%xmm0
  81f772:	movups %xmm0,0x418(%rsp)
  81f77a:	mov    %r14d,0x408(%rsp)
  81f782:	mov    %r15d,0x40c(%rsp)
  81f78a:	mov    0x90(%rsp),%rax
  81f792:	mov    %eax,0x410(%rsp)
  81f799:	mov    %ecx,0x414(%rsp)
  81f7a0:	movss  0xf4(%rsp),%xmm0
  81f7a9:	movss  %xmm0,0x428(%rsp)
  81f7b2:	mov    0x110(%rsp),%rax
  81f7ba:	mov    %eax,0x42c(%rsp)
  81f7c1:	movq   $0x0,0x430(%rsp)
  81f7cd:	mov    0x8(%rsp),%rax
  81f7d2:	lea    0x230(%rax),%rsi
  81f7d9:	lea    0x408(%rsp),%rcx
  81f7e1:	mov    $0x30,%r8d
  81f7e7:	mov    0x2f0(%rsp),%rdi
  81f7ef:	mov    %rsi,0x30(%rsp)
  81f7f4:	xor    %edx,%edx
  81f7f6:	call   *0x660044(%rip)        # e7f840 <_DYNAMIC+0x5d0>
  81f7fc:	mov    0x2b8(%rsp),%rbx
  81f804:	shl    $0x4,%rbx
  81f808:	mov    0x98(%rsp),%rdi
  81f810:	mov    0xa0(%rsp),%rsi
  81f818:	mov    %rbx,%rdx
  81f81b:	call   81c6c0 <<gpui_gpu::renderer::Buffer>::reserve>
  81f820:	cmpq   $0x0,0x38(%rsp)
  81f826:	je     81f89e <<gpui_gpu::renderer::RendererState>::render+0x1d3e>
  81f828:	mov    0x2b8(%rsp),%rcx
  81f830:	cmp    %rcx,0x348(%rsp)
  81f838:	jne    81f89e <<gpui_gpu::renderer::RendererState>::render+0x1d3e>
  81f83a:	test   %al,%al
  81f83c:	jne    81f89e <<gpui_gpu::renderer::RendererState>::render+0x1d3e>
  81f83e:	testb  $0x1,0x390(%rsp)
  81f846:	jne    81f89e <<gpui_gpu::renderer::RendererState>::render+0x1d3e>
  81f848:	mov    0x2d8(%rsp),%rax
  81f850:	mov    0x230(%rsp),%rbx
  81f858:	mov    0x238(%rsp),%rsi
  81f860:	cmp    %rbx,%rax
  81f863:	jne    81f921 <<gpui_gpu::renderer::RendererState>::render+0x1dc1>
  81f869:	mov    %rsi,0x2d8(%rsp)
  81f871:	movq   $0xffffffffffffffff,0x230(%rsp)
  81f87d:	movq   $0x0,0x238(%rsp)
  81f889:	mov    $0xffffffffffffffff,%rbx
  81f890:	movq   $0x0,0x38(%rsp)
  81f899:	jmp    81f929 <<gpui_gpu::renderer::RendererState>::render+0x1dc9>
  81f89e:	mov    0x8(%rsp),%rax
  81f8a3:	mov    0x8(%rax),%rcx
  81f8a7:	mov    0x10(%rax),%r8
  81f8ab:	shl    $0x4,%r8
  81f8af:	mov    0x98(%rsp),%rdi
  81f8b7:	mov    0xa0(%rsp),%rsi
  81f8bf:	mov    0x2f0(%rsp),%rdx
  81f8c7:	call   81c670 <<gpui_gpu::renderer::Buffer>::write>
  81f8cc:	jmp    81f987 <<gpui_gpu::renderer::RendererState>::render+0x1e27>
  81f8d1:	mov    0x50(%rsp),%rdi
  81f8d6:	jmp    81dd01 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81f8db:	movq   $0x0,0x40(%rsp)
  81f8e4:	xor    %eax,%eax
  81f8e6:	movq   $0x0,0x10(%rsp)
  81f8ef:	jmp    81f903 <<gpui_gpu::renderer::RendererState>::render+0x1da3>
  81f8f1:	incq   0x10(%rsp)
  81f8f6:	add    $0x8,%rax
  81f8fa:	cmp    %rax,%rdi
  81f8fd:	je     81f6f2 <<gpui_gpu::renderer::RendererState>::render+0x1b92>
  81f903:	mov    0x4(%r8,%rax,1),%ecx
  81f908:	mov    %ecx,%edx
  81f90a:	neg    %edx
  81f90c:	jo     81f8f1 <<gpui_gpu::renderer::RendererState>::render+0x1d91>
  81f90e:	cmp    %ecx,(%r8,%rax,1)
  81f912:	je     81f8f6 <<gpui_gpu::renderer::RendererState>::render+0x1d96>
  81f914:	lea    0x60e5ed(%rip),%rdi        # e2df08 <anon.36d49f465d299f05a84fba3771e6457e.32.llvm.4925703984657133240+0x10>
  81f91b:	call   *0x65ff27(%rip)        # e7f848 <_DYNAMIC+0x5d8>
  81f921:	mov    %rsi,0x38(%rsp)
  81f926:	mov    %rax,%rsi
  81f929:	mov    0x8(%rsp),%r13
  81f92e:	mov    0x8(%r13),%rdx
  81f932:	mov    0x10(%r13),%rcx
  81f936:	mov    0x2d0(%rsp),%rdi
  81f93e:	mov    0x98(%rsp),%rbp
  81f946:	mov    %rbp,%r8
  81f949:	mov    0x2f0(%rsp),%r12
  81f951:	mov    %r12,%r9
  81f954:	call   81c610 <<gpui_gpu::renderer::Changes>::upload>
  81f959:	mov    %rax,0xc0(%rsp)
  81f961:	mov    0x8(%r13),%rdx
  81f965:	mov    0x10(%r13),%rcx
  81f969:	mov    %rbx,%rdi
  81f96c:	mov    0x38(%rsp),%rsi
  81f971:	mov    %rbp,%r8
  81f974:	mov    %r12,%r9
  81f977:	call   81c610 <<gpui_gpu::renderer::Changes>::upload>
  81f97c:	mov    %rax,%rbx
  81f97f:	add    0xc0(%rsp),%rbx
  81f987:	mov    0xa0(%rsp),%r13
  81f98f:	lea    0x18(%r13),%rax
  81f993:	mov    %rax,0x38(%rsp)
  81f998:	mov    0x8(%rsp),%rbp
  81f99d:	lea    0x280(%rbp),%rdi
  81f9a4:	mov    0x20(%rbp),%rcx
  81f9a8:	mov    0x28(%rbp),%r8
  81f9ac:	shl    $0x3,%r8
  81f9b0:	mov    %rdi,0xc0(%rsp)
  81f9b8:	mov    %r13,%rsi
  81f9bb:	mov    0x2f0(%rsp),%r12
  81f9c3:	mov    %r12,%rdx
  81f9c6:	call   81c670 <<gpui_gpu::renderer::Buffer>::write>
  81f9cb:	lea    0x2a8(%rbp),%rdi
  81f9d2:	mov    0x38(%rbp),%rcx
  81f9d6:	mov    0x40(%rbp),%r8
  81f9da:	shl    $0x2,%r8
  81f9de:	mov    %rdi,0xb0(%rsp)
  81f9e6:	mov    %r13,%rsi
  81f9e9:	mov    %r12,%rdx
  81f9ec:	call   81c670 <<gpui_gpu::renderer::Buffer>::write>
  81f9f1:	lea    0x2d0(%rbp),%rdi
  81f9f8:	mov    0x68(%rbp),%rcx
  81f9fc:	mov    0x70(%rbp),%r8
  81fa00:	shl    $0x5,%r8
  81fa04:	mov    %rdi,0x28(%rsp)
  81fa09:	mov    %r13,%rsi
  81fa0c:	mov    %r12,%rdx
  81fa0f:	call   81c670 <<gpui_gpu::renderer::Buffer>::write>
  81fa14:	cmpq   $0x0,0x328(%rbp)
  81fa1c:	je     81fa22 <<gpui_gpu::renderer::RendererState>::render+0x1ec2>
  81fa1e:	xor    %eax,%eax
  81fa20:	jmp    81fa37 <<gpui_gpu::renderer::RendererState>::render+0x1ed7>
  81fa22:	mov    0x8(%rsp),%rax
  81fa27:	mov    0x10(%rax),%rax
  81fa2b:	cmp    $0x1,%rax
  81fa2f:	adc    $0x0,%rax
  81fa33:	shl    $0x4,%rax
  81fa37:	mov    0x8(%rsp),%rdi
  81fa3c:	mov    0x28(%rdi),%rsi
  81fa40:	mov    0x40(%rdi),%rcx
  81fa44:	cmp    $0x1,%rsi
  81fa48:	adc    $0x0,%rsi
  81fa4c:	shl    $0x3,%rsi
  81fa50:	cmp    $0x1,%rcx
  81fa54:	adc    $0x0,%rcx
  81fa58:	mov    0x70(%rdi),%rdx
  81fa5c:	cmp    $0x1,%rdx
  81fa60:	adc    $0x0,%rdx
  81fa64:	add    $0xc8,%rdi
  81fa6b:	shl    $0x2,%rcx
  81fa6f:	shl    $0x5,%rdx
  81fa73:	movq   $0x0,0x130(%rsp)
  81fa7f:	mov    0x30(%rsp),%r8
  81fa84:	mov    %r8,0x138(%rsp)
  81fa8c:	movq   $0x0,0x158(%rsp)
  81fa98:	xorpd  %xmm0,%xmm0
  81fa9c:	movupd %xmm0,0x140(%rsp)
  81faa5:	movl   $0x0,0x150(%rsp)
  81fab0:	mov    0x98(%rsp),%r8
  81fab8:	mov    %r8,0x160(%rsp)
  81fac0:	movq   $0x0,0x168(%rsp)
  81facc:	mov    %rax,0x170(%rsp)
  81fad4:	movl   $0x1,0x178(%rsp)
  81fadf:	movq   $0x0,0x180(%rsp)
  81faeb:	mov    0xc0(%rsp),%rax
  81faf3:	mov    %rax,0x188(%rsp)
  81fafb:	movq   $0x0,0x190(%rsp)
  81fb07:	mov    %rsi,0x198(%rsp)
  81fb0f:	movl   $0x2,0x1a0(%rsp)
  81fb1a:	movq   $0x0,0x1a8(%rsp)
  81fb26:	mov    0xb0(%rsp),%rax
  81fb2e:	mov    %rax,0x1b0(%rsp)
  81fb36:	movq   $0x0,0x1b8(%rsp)
  81fb42:	mov    %rcx,0x1c0(%rsp)
  81fb4a:	movl   $0x3,0x1c8(%rsp)
  81fb55:	movq   $0x4,0x1d0(%rsp)
  81fb61:	mov    %rdi,0x1d8(%rsp)
  81fb69:	movl   $0x4,0x1f0(%rsp)
  81fb74:	movq   $0x0,0x1f8(%rsp)
  81fb80:	mov    0x28(%rsp),%rax
  81fb85:	mov    %rax,0x200(%rsp)
  81fb8d:	movq   $0x0,0x208(%rsp)
  81fb99:	mov    %rdx,0x210(%rsp)
  81fba1:	movl   $0x5,0x218(%rsp)
  81fbac:	lea    -0x74b46b(%rip),%rax        # d4748 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x122>
  81fbb3:	mov    %rax,0x3b8(%rsp)
  81fbbb:	movq   $0xa,0x3c0(%rsp)
  81fbc7:	mov    0x38(%rsp),%rax
  81fbcc:	mov    %rax,0x3a0(%rsp)
  81fbd4:	lea    0x130(%rsp),%rax
  81fbdc:	mov    %rax,0x3a8(%rsp)
  81fbe4:	movq   $0x6,0x3b0(%rsp)
  81fbf0:	lea    0x3a0(%rsp),%rsi
  81fbf8:	mov    0xa0(%rsp),%r13
  81fc00:	mov    %r13,%rdi
  81fc03:	call   *0x65fc47(%rip)        # e7f850 <_DYNAMIC+0x5e0>
  81fc09:	mov    %rax,%rbp
  81fc0c:	mov    %rax,0x270(%rsp)
  81fc14:	lea    0x270(%rsp),%rdx
  81fc1c:	mov    %r13,%rdi
  81fc1f:	mov    0x4b8(%rsp),%rsi
  81fc27:	call   81cd00 <<gpui_gpu::renderer::GpuContext>::submit>
  81fc2c:	mov    %rax,0x38(%rsp)
  81fc31:	xor    %r13d,%r13d
  81fc34:	mov    0x350(%rsp),%rax
  81fc3c:	cmp    %rax,0x358(%rsp)
  81fc44:	setne  %r13b
  81fc48:	shl    $0x1f,%r13d
  81fc4c:	or     %r14d,%r13d
  81fc4f:	shl    $0x20,%r15
  81fc53:	or     %r15,%r13
  81fc56:	mov    0xe8(%rsp),%rax
  81fc5e:	mov    (%rax),%rax
  81fc61:	test   %rax,%rax
  81fc64:	je     81fc7a <<gpui_gpu::renderer::RendererState>::render+0x211a>
  81fc66:	lock decq (%rax)
  81fc6a:	jne    81fc7a <<gpui_gpu::renderer::RendererState>::render+0x211a>
  81fc6c:	mov    0xe8(%rsp),%rdi
  81fc74:	call   *0x65fb0e(%rip)        # e7f788 <_DYNAMIC+0x518>
  81fc7a:	mov    0x8(%rsp),%rax
  81fc7f:	mov    %rbp,0x330(%rax)
  81fc86:	mov    %r13,0x338(%rax)
  81fc8d:	mov    0x28(%rax),%rsi
  81fc91:	mov    0x70(%rax),%rcx
  81fc95:	mov    %rcx,0xe8(%rsp)
  81fc9d:	mov    0x278(%rax),%rdx
  81fca4:	mov    0x220(%rsp),%r8
  81fcac:	lea    (%rbx,%r8,4),%rdi
  81fcb0:	lea    (%rdi,%rsi,8),%rsi
  81fcb4:	mov    %rcx,%rdi
  81fcb7:	shl    $0x5,%rdi
  81fcbb:	lea    (%rdi,%rsi,1),%rcx
  81fcbf:	add    $0x30,%rcx
  81fcc3:	mov    %rcx,0x30(%rsp)
  81fcc8:	mov    0x150(%rax),%esi
  81fcce:	imul   %rsi,%rsi
  81fcd2:	add    0x250(%rax),%rdx
  81fcd9:	add    0x2a0(%rax),%rdx
  81fce0:	add    0x2c8(%rax),%rdx
  81fce7:	add    0x2f0(%rax),%rdx
  81fcee:	mov    0x308(%rax),%rdi
  81fcf5:	add    0x310(%rax),%rdi
  81fcfc:	mov    0x118(%rsp),%r11
  81fd04:	mov    %r11,%rcx
  81fd07:	sub    %r8,%rcx
  81fd0a:	mov    0x88(%rsp),%rbp
  81fd12:	mov    %rbp,%r9
  81fd15:	mov    0x2b0(%rsp),%r13
  81fd1d:	sub    %r13,%r9
  81fd20:	mov    0x10(%rax),%r10
  81fd24:	shl    $0x4,%r10
  81fd28:	mov    0x160(%rax),%rbx
  81fd2f:	inc    %rbx
  81fd32:	mov    $0xffffffffffffffff,%r14
  81fd39:	cmovne %rbx,%r14
  81fd3d:	mov    (%rax),%rbx
  81fd40:	shl    $0x4,%rbx
  81fd44:	mov    0x48(%rax),%r15
  81fd48:	add    0x30(%rax),%r15
  81fd4c:	mov    0x18(%rax),%r12
  81fd50:	lea    (%rbx,%r12,8),%rbx
  81fd54:	lea    (%rbx,%r15,4),%rbx
  81fd58:	mov    0x60(%rax),%r15
  81fd5c:	shl    $0x5,%r15
  81fd60:	add    %rbx,%r15
  81fd63:	mov    0x138(%rax),%rbx
  81fd6a:	mov    0x130(%rax),%r12
  81fd71:	mov    %r14,0x160(%rax)
  81fd78:	mov    %rbp,0x168(%rax)
  81fd7f:	lea    (%r11,%r11,1),%r14
  81fd83:	mov    %r14,0x170(%rax)
  81fd8a:	movq   $0x1,0x178(%rax)
  81fd95:	mov    %rbp,0x180(%rax)
  81fd9c:	mov    %r8,0x188(%rax)
  81fda3:	mov    %r11,0x190(%rax)
  81fdaa:	mov    %rcx,0x198(%rax)
  81fdb1:	mov    0x10(%rsp),%rcx
  81fdb6:	mov    %rcx,0x1a0(%rax)
  81fdbd:	mov    0x40(%rsp),%rcx
  81fdc2:	mov    %rcx,0x1a8(%rax)
  81fdc9:	mov    0x70(%rsp),%rcx
  81fdce:	mov    %rcx,0x1b0(%rax)
  81fdd5:	mov    0x30(%rsp),%rcx
  81fdda:	mov    %rcx,0x1b8(%rax)
  81fde1:	mov    %r10,0x1c0(%rax)
  81fde8:	mov    0x2a8(%rsp),%r8
  81fdf0:	mov    %r8,0x1c8(%rax)
  81fdf7:	mov    %r13,0x1d0(%rax)
  81fdfe:	mov    %r9,0x1d8(%rax)
  81fe05:	mov    0x2c8(%rsp),%rcx
  81fe0d:	mov    %rcx,0x1e0(%rax)
  81fe14:	mov    %rdx,0x1e8(%rax)
  81fe1b:	mov    %rsi,0x1f0(%rax)
  81fe22:	add    %rbx,%r12
  81fe25:	mov    %rbx,0x1f8(%rax)
  81fe2c:	mov    %r12,0x200(%rax)
  81fe33:	mov    %r15,0x208(%rax)
  81fe3a:	mov    0xe8(%rsp),%rcx
  81fe42:	mov    %rcx,0x210(%rax)
  81fe49:	mov    %rdi,0x218(%rax)
  81fe50:	movb   $0x0,0x220(%rax)
  81fe57:	mov    0x50(%rsp),%rdi
  81fe5c:	mov    0x38(%rsp),%rax
  81fe61:	mov    %rax,0x8(%rdi)
  81fe65:	movl   $0xffffffff,(%rdi)
  81fe6b:	jmp    81dd0f <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81fe70:	lea    0x60de99(%rip),%rdi        # e2dd10 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4925703984657133240+0x18>
  81fe77:	call   *0x65f9db(%rip)        # e7f858 <_DYNAMIC+0x5e8>
  81fe7d:	lea    0x60deec(%rip),%rcx        # e2dd70 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4925703984657133240+0x78>
  81fe84:	xor    %edi,%edi
  81fe86:	mov    0x20(%rsp),%rsi
  81fe8b:	call   *0x65f927(%rip)        # e7f7b8 <_DYNAMIC+0x548>
  81fe91:	lea    0x60de90(%rip),%rax        # e2dd28 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4925703984657133240+0x30>
  81fe98:	mov    %rcx,%rdi
  81fe9b:	mov    %rdx,%rsi
  81fe9e:	mov    %rax,%rdx
  81fea1:	call   *0x65f8c1(%rip)        # e7f768 <_DYNAMIC+0x4f8>
  81fea7:	lea    0x60deaa(%rip),%rax        # e2dd58 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4925703984657133240+0x60>
  81feae:	mov    %rcx,%rdi
  81feb1:	mov    %rdx,%rsi
  81feb4:	mov    %rax,%rdx
  81feb7:	call   *0x65f8ab(%rip)        # e7f768 <_DYNAMIC+0x4f8>
  81febd:	lea    0x60de7c(%rip),%rdx        # e2dd40 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4925703984657133240+0x48>
  81fec4:	call   *0x65f89e(%rip)        # e7f768 <_DYNAMIC+0x4f8>
  81feca:	mov    %rax,%r14
  81fecd:	mov    0x8(%rsp),%rax
  81fed2:	mov    %rbp,0x330(%rax)
  81fed9:	mov    %r13,0x338(%rax)
  81fee0:	mov    %r14,%rdi
  81fee3:	call   e2bfe0 <_Unwind_Resume@plt>
  81fee8:	mov    %rax,%r14
  81feeb:	lock decq 0x0(%rbp)
  81fef0:	jne    81ff1a <<gpui_gpu::renderer::RendererState>::render+0x23ba>
  81fef2:	lea    0x270(%rsp),%rdi
  81fefa:	call   *0x65f888(%rip)        # e7f788 <_DYNAMIC+0x518>
  81ff00:	jmp    81ff1a <<gpui_gpu::renderer::RendererState>::render+0x23ba>
  81ff02:	call   *0x65f5b8(%rip)        # e7f4c0 <_DYNAMIC+0x250>
  81ff08:	mov    %rax,%r14
  81ff0b:	mov    0xe8(%rsp),%rax
  81ff13:	movq   $0x0,(%rax)
  81ff1a:	mov    %r14,%rdi
  81ff1d:	call   e2bfe0 <_Unwind_Resume@plt>

/tmp/gpui-uniform-borrowed-span-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000823e60 <gpui_gpu::renderer::slots::write_prefix>:
  823e60:	push   %rbp
  823e61:	push   %r15
  823e63:	push   %r14
  823e65:	push   %r13
  823e67:	push   %r12
  823e69:	push   %rbx
  823e6a:	sub    $0x48,%rsp
  823e6e:	mov    %rsi,0x8(%rsp)
  823e73:	test   %rcx,%rcx
  823e76:	je     8240ba <gpui_gpu::renderer::slots::write_prefix+0x25a>
  823e7c:	mov    %rdi,0x18(%rsp)
  823e81:	xor    %r12d,%r12d
  823e84:	test   $0x3f,%cl
  823e87:	setne  %al
  823e8a:	cmpq   $0x0,0x8(%rsp)
  823e90:	je     824100 <gpui_gpu::renderer::slots::write_prefix+0x2a0>
  823e96:	mov    %r8,%r14
  823e99:	mov    %rcx,%r10
  823e9c:	shr    $0x6,%r10
  823ea0:	mov    %al,%r12b
  823ea3:	lea    (%r10,%r12,1),%r9
  823ea7:	lea    (%r10,%r12,1),%rax
  823eab:	inc    %rax
  823eae:	mov    %eax,%esi
  823eb0:	mov    %r9,%rdi
  823eb3:	shl    $0x20,%rdi
  823eb7:	mov    %ecx,%r8d
  823eba:	mov    0x18(%rsp),%rbx
  823ebf:	xor    0x8(%rbx),%rsi
  823ec3:	or     %rdi,%r8
  823ec6:	xor    (%rbx),%r8
  823ec9:	or     %rsi,%r8
  823ecc:	mov    %r10,0x10(%rsp)
  823ed1:	jne    823edc <gpui_gpu::renderer::slots::write_prefix+0x7c>
  823ed3:	mov    (%r14),%rbp
  823ed6:	mov    0x8(%r14),%r13
  823eda:	jmp    823f05 <gpui_gpu::renderer::slots::write_prefix+0xa5>
  823edc:	mov    0x8(%r14),%r13
  823ee0:	movq   $0x0,(%r14)
  823ee7:	cmp    $0x1,%r13
  823eeb:	adc    $0x0,%r13
  823eef:	mov    %r13,0x8(%r14)
  823ef3:	mov    %ecx,(%rbx)
  823ef5:	mov    %r9d,0x4(%rbx)
  823ef9:	mov    %eax,0x8(%rbx)
  823efc:	movl   $0x0,0xc(%rbx)
  823f03:	xor    %ebp,%ebp
  823f05:	mov    %r9,%r15
  823f08:	mov    %rdx,%rdi
  823f0b:	call   *0x65b907(%rip)        # e7f818 <_DYNAMIC+0x5a8>
  823f11:	mov    0x8(%rsp),%rcx
  823f16:	dec    %rcx
  823f19:	mov    %rcx,0x40(%rsp)
  823f1e:	mov    0x10(%rsp),%rcx
  823f23:	shl    $0x4,%rcx
  823f27:	shl    $0x4,%r12d
  823f2b:	add    %rcx,%r12
  823f2e:	lea    (%rbx,%r12,1),%r9
  823f32:	add    $0x10,%r9
  823f36:	xor    %r12d,%r12d
  823f39:	xorps  %xmm0,%xmm0
  823f3c:	mov    %r15,0x38(%rsp)
  823f41:	mov    %r15,%r10
  823f44:	jmp    823f66 <gpui_gpu::renderer::slots::write_prefix+0x106>
  823f46:	cs nopw 0x0(%rax,%rax,1)
  823f50:	add    $0x40,%r10
  823f54:	add    $0x400,%r9
  823f5b:	cmp    0x38(%rsp),%r12
  823f60:	je     8240ba <gpui_gpu::renderer::slots::write_prefix+0x25a>
  823f66:	mov    %r12,0x10(%rsp)
  823f6b:	lea    0x1(%r12),%rcx
  823f70:	mov    %rcx,0x30(%rsp)
  823f75:	movaps %xmm0,0x20(%rsp)
  823f7a:	mov    $0xffffffffffffffc0,%rsi
  823f81:	xor    %r12d,%r12d
  823f84:	jmp    823fa1 <gpui_gpu::renderer::slots::write_prefix+0x141>
  823f86:	cs nopw 0x0(%rax,%rax,1)
  823f90:	add    $0x18,%rax
  823f94:	add    $0x2,%r12
  823f98:	inc    %rsi
  823f9b:	je     824050 <gpui_gpu::renderer::slots::write_prefix+0x1f0>
  823fa1:	cmp    %rdx,%rax
  823fa4:	je     824050 <gpui_gpu::renderer::slots::write_prefix+0x1f0>
  823faa:	lea    0x40(%rsi),%r8
  823fae:	movzwl 0x10(%rax),%ebx
  823fb2:	movzwl 0x12(%rax),%ecx
  823fb6:	mov    (%rax),%r11d
  823fb9:	mov    0x4(%rax),%edi
  823fbc:	mov    0x8(%rax),%r15
  823fc0:	shr    $0xe,%ecx
  823fc3:	and    $0x2,%ecx
  823fc6:	shr    $0xf,%ebx
  823fc9:	or     %ecx,%ebx
  823fcb:	mov    %r12d,%ecx
  823fce:	and    $0x1e,%cl
  823fd1:	shl    %cl,%ebx
  823fd3:	shr    $0x4,%r8
  823fd7:	or     %ebx,0x20(%rsp,%r8,4)
  823fdc:	lea    (%r10,%rsi,1),%r8
  823fe0:	add    $0x41,%r8
  823fe4:	cmp    0x8(%rsp),%r8
  823fe9:	jae    8240c9 <gpui_gpu::renderer::slots::write_prefix+0x269>
  823fef:	mov    %rdi,%rcx
  823ff2:	shl    $0x20,%rcx
  823ff6:	mov    %r11d,%ebx
  823ff9:	or     %rcx,%rbx
  823ffc:	mov    0x8(%r9,%r12,8),%rcx
  824001:	xor    %r15,%rcx
  824004:	xor    (%r9,%r12,8),%rbx
  824008:	or     %rcx,%rbx
  82400b:	je     823f90 <gpui_gpu::renderer::slots::write_prefix+0x130>
  82400d:	mov    %r15d,%ecx
  824010:	shr    $0x20,%r15
  824014:	cmp    %rbp,%r8
  824017:	cmovb  %r8,%rbp
  82401b:	mov    %rbp,(%r14)
  82401e:	lea    (%r10,%rsi,1),%r8
  824022:	add    $0x42,%r8
  824026:	cmp    %r13,%r8
  824029:	cmova  %r8,%r13
  82402d:	mov    %r13,0x8(%r14)
  824031:	mov    %r11d,(%r9,%r12,8)
  824035:	mov    %edi,0x4(%r9,%r12,8)
  82403a:	mov    %ecx,0x8(%r9,%r12,8)
  82403f:	mov    %r15d,0xc(%r9,%r12,8)
  824044:	jmp    823f90 <gpui_gpu::renderer::slots::write_prefix+0x130>
  824049:	nopl   0x0(%rax)
  824050:	mov    0x10(%rsp),%r15
  824055:	cmp    0x40(%rsp),%r15
  82405a:	je     8240e5 <gpui_gpu::renderer::slots::write_prefix+0x285>
  824060:	mov    0x20(%rsp),%rcx
  824065:	mov    0x28(%rsp),%rsi
  82406a:	lea    0x1(%r15),%r12
  82406e:	mov    %r12,%rdi
  824071:	shl    $0x4,%rdi
  824075:	mov    0x18(%rsp),%rbx
  82407a:	mov    0x8(%rbx,%rdi,1),%r8
  82407f:	xor    %rsi,%r8
  824082:	mov    (%rbx,%rdi,1),%r11
  824086:	xor    %rcx,%r11
  824089:	or     %r8,%r11
  82408c:	je     823f50 <gpui_gpu::renderer::slots::write_prefix+0xf0>
  824092:	add    %rbx,%rdi
  824095:	cmp    %rbp,%r12
  824098:	cmovb  %r12,%rbp
  82409c:	add    $0x2,%r15
  8240a0:	cmp    %r13,%r15
  8240a3:	cmova  %r15,%r13
  8240a7:	mov    %rbp,(%r14)
  8240aa:	mov    %r13,0x8(%r14)
  8240ae:	mov    %rsi,0x8(%rdi)
  8240b2:	mov    %rcx,(%rdi)
  8240b5:	jmp    823f50 <gpui_gpu::renderer::slots::write_prefix+0xf0>
  8240ba:	add    $0x48,%rsp
  8240be:	pop    %rbx
  8240bf:	pop    %r12
  8240c1:	pop    %r13
  8240c3:	pop    %r14
  8240c5:	pop    %r15
  8240c7:	pop    %rbp
  8240c8:	ret
  8240c9:	add    %r10,%rsi
  8240cc:	add    $0x42,%rsi
  8240d0:	lea    0x609c21(%rip),%rcx        # e2dcf8 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4925703984657133240>
  8240d7:	mov    %r8,%rdi
  8240da:	mov    0x8(%rsp),%rdx
  8240df:	call   *0x65b6d3(%rip)        # e7f7b8 <_DYNAMIC+0x548>
  8240e5:	mov    0x8(%rsp),%rdx
  8240ea:	lea    0x1(%rdx),%rsi
  8240ee:	lea    0x609c03(%rip),%rcx        # e2dcf8 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4925703984657133240>
  8240f5:	mov    0x30(%rsp),%rdi
  8240fa:	call   *0x65b6b8(%rip)        # e7f7b8 <_DYNAMIC+0x548>
  824100:	lea    0x609bf1(%rip),%rcx        # e2dcf8 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4925703984657133240>
  824107:	mov    $0x1,%esi
  82410c:	xor    %edi,%edi
  82410e:	xor    %edx,%edx
  824110:	call   *0x65b6a2(%rip)        # e7f7b8 <_DYNAMIC+0x548>
{'address': 8499232, 'code_bytes': 325, 'mangled': '_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionNtNtCs11piCSwEYBC_11gpui_canvas6canvas9GlyphMaskE6map_orAmj3_NCINvMs5_NtCshVcpkSEwkOU_8gpui_gpu8rendererNtB1Q_13RendererState15render_observedNCNvB1M_6render0Es2_0EB1S_', 'name': '<core[37f591cfbe66b0b1]::option::Option<gpui_canvas[be9825febc5538e]::canvas::GlyphMask>>::map_or::<[u32; 3: usize], <gpui_gpu[d0c1626f4f4ed1e6]::renderer::RendererState>::render_observed<<gpui_gpu[d0c1626f4f4ed1e6]::renderer::RendererState>::render::{closure#0}>::{closure#4}>', 'normalized_name': '<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3: usize], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>', 'stack_bytes': 72}
{'address': 8499568, 'code_bytes': 105, 'mangled': '_RINvMs0_NtCshVcpkSEwkOU_8gpui_gpu8rendererNtB6_7Changes7replaceKj1_EB8_', 'name': '<gpui_gpu[d0c1626f4f4ed1e6]::renderer::Changes>::replace::<1: usize>', 'normalized_name': '<gpui_gpu::renderer::Changes>::replace::<1: usize>', 'stack_bytes': 8}
{'address': 8499680, 'code_bytes': 192, 'mangled': '_RINvMs0_NtCshVcpkSEwkOU_8gpui_gpu8rendererNtB6_7Changes7replaceKj2_EB8_', 'name': '<gpui_gpu[d0c1626f4f4ed1e6]::renderer::Changes>::replace::<2: usize>', 'normalized_name': '<gpui_gpu::renderer::Changes>::replace::<2: usize>', 'stack_bytes': 8}
{'address': 8503312, 'code_bytes': 611, 'mangled': '_RINvNtCshVcpkSEwkOU_8gpui_gpu8renderer5visitNCINvMs5_B2_NtB2_13RendererState15render_observedNCNvBL_6render0Es3_0EB4_', 'name': 'gpui_gpu[d0c1626f4f4ed1e6]::renderer::visit::<<gpui_gpu[d0c1626f4f4ed1e6]::renderer::RendererState>::render_observed<<gpui_gpu[d0c1626f4f4ed1e6]::renderer::RendererState>::render::{closure#0}>::{closure#5}>', 'normalized_name': 'gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>', 'stack_bytes': 88}
{'address': 8503936, 'code_bytes': 235, 'mangled': '_RINvYNtNtCs11piCSwEYBC_11gpui_canvas6canvas6GroupsNtNtNtNtCs4NRVxsYgnAr_4core4iter6traits8iterator8Iterator4foldjNCINvNtNtBS_8adapters3map8map_foldNtB5_13PreparedGroupjjNCINvMs5_NtCshVcpkSEwkOU_8gpui_gpu8rendererNtB2Q_13RendererState15render_observedNCNvB2M_6render0Es0_0NCINvXsK_NtBQ_5accumjNtB4u_3Sum3sumINtB1S_3MapB3_B2H_EE0E0EB2S_', 'name': '<gpui_canvas[be9825febc5538e]::canvas::Groups as core[37f591cfbe66b0b1]::iter::traits::iterator::Iterator>::fold::<usize, core[37f591cfbe66b0b1]::iter::adapters::map::map_fold<gpui_canvas[be9825febc5538e]::canvas::PreparedGroup, usize, usize, <gpui_gpu[d0c1626f4f4ed1e6]::renderer::RendererState>::render_observed<<gpui_gpu[d0c1626f4f4ed1e6]::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core[37f591cfbe66b0b1]::iter::traits::accum::Sum>::sum<core[37f591cfbe66b0b1]::iter::adapters::map::Map<gpui_canvas[be9825febc5538e]::canvas::Groups, <gpui_gpu[d0c1626f4f4ed1e6]::renderer::RendererState>::render_observed<<gpui_gpu[d0c1626f4f4ed1e6]::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>', 'normalized_name': '<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>', 'stack_bytes': 248}
{'address': 8510304, 'code_bytes': 9154, 'mangled': '_RNvMs5_NtCshVcpkSEwkOU_8gpui_gpu8rendererNtB5_13RendererState6render', 'name': '<gpui_gpu[d0c1626f4f4ed1e6]::renderer::RendererState>::render', 'normalized_name': '<gpui_gpu::renderer::RendererState>::render', 'stack_bytes': 1448}
{'address': 8535648, 'code_bytes': 694, 'mangled': '_RNvNtNtCshVcpkSEwkOU_8gpui_gpu8renderer5slots12write_prefix', 'name': 'gpui_gpu[d0c1626f4f4ed1e6]::renderer::slots::write_prefix', 'normalized_name': 'gpui_gpu::renderer::slots::write_prefix', 'stack_bytes': 120}
