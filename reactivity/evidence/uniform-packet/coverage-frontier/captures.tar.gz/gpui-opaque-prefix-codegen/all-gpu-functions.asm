
/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008163f0 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>:
  8163f0:	push   %rbx
  8163f1:	test   %rdi,%rdi
  8163f4:	je     816457 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x67>
  8163f6:	mov    %rdi,%rbx
  8163f9:	mov    (%rdi),%rsi
  8163fc:	test   %rsi,%rsi
  8163ff:	je     816414 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x24>
  816401:	mov    0x8(%rbx),%rdi
  816405:	shl    $0x3,%rsi
  816409:	mov    $0x8,%edx
  81640e:	call   *0x6698f4(%rip)        # e7fd08 <_DYNAMIC+0x248>
  816414:	mov    0x20(%rbx),%rsi
  816418:	test   %rsi,%rsi
  81641b:	je     816443 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  81641d:	mov    %rsi,%rax
  816420:	shl    $0x4,%rax
  816424:	add    %rax,%rsi
  816427:	add    $0x21,%rsi
  81642b:	je     816443 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  81642d:	mov    0x18(%rbx),%rdi
  816431:	sub    %rax,%rdi
  816434:	add    $0xfffffffffffffff0,%rdi
  816438:	mov    $0x10,%edx
  81643d:	call   *0x6698c5(%rip)        # e7fd08 <_DYNAMIC+0x248>
  816443:	mov    $0x80,%esi
  816448:	mov    $0x8,%edx
  81644d:	mov    %rbx,%rdi
  816450:	pop    %rbx
  816451:	jmp    *0x6698b1(%rip)        # e7fd08 <_DYNAMIC+0x248>
  816457:	pop    %rbx
  816458:	ret

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000816a60 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>>:
  816a60:	push   %rbx
  816a61:	cmpb   $0x3,0x19c(%rdi)
  816a68:	jne    816a97 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x37>
  816a6a:	movzbl 0x28(%rdi),%eax
  816a6e:	cmp    $0x4,%eax
  816a71:	je     816a85 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x25>
  816a73:	cmp    $0x3,%eax
  816a76:	jne    816a97 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x37>
  816a78:	add    $0x168,%rdi
  816a7f:	pop    %rbx
  816a80:	jmp    8169d0 <core::ptr::drop_glue::<<wgpu::api::adapter::Adapter>::request_device::{closure#0}>>
  816a85:	mov    %rdi,%rbx
  816a88:	add    $0x30,%rdi
  816a8c:	call   816ab0 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>>
  816a91:	movw   $0x0,0x29(%rbx)
  816a97:	pop    %rbx
  816a98:	ret
  816a99:	movw   $0x0,0x29(%rbx)
  816a9f:	mov    %rax,%rdi
  816aa2:	call   e2c830 <_Unwind_Resume@plt>

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000816ab0 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>>:
  816ab0:	push   %r15
  816ab2:	push   %r14
  816ab4:	push   %r12
  816ab6:	push   %rbx
  816ab7:	push   %rax
  816ab8:	mov    %rdi,%rbx
  816abb:	movzbl 0x9e(%rdi),%eax
  816ac2:	test   %eax,%eax
  816ac4:	je     816b8b <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xdb>
  816aca:	cmp    $0x3,%eax
  816acd:	jne    816bc1 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x111>
  816ad3:	mov    0x20(%rbx),%r15
  816ad7:	mov    0x28(%rbx),%r12
  816adb:	mov    (%r12),%rax
  816adf:	test   %rax,%rax
  816ae2:	je     816ae9 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x39>
  816ae4:	mov    %r15,%rdi
  816ae7:	call   *%rax
  816ae9:	mov    0x8(%r12),%rsi
  816aee:	test   %rsi,%rsi
  816af1:	je     816b01 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x51>
  816af3:	mov    0x10(%r12),%rdx
  816af8:	mov    %r15,%rdi
  816afb:	call   *0x669207(%rip)        # e7fd08 <_DYNAMIC+0x248>
  816b01:	mov    0x68(%rbx),%rax
  816b05:	lock decq (%rax)
  816b09:	jne    816b15 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x65>
  816b0b:	lea    0x68(%rbx),%rdi
  816b0f:	call   *0x669413(%rip)        # e7ff28 <_DYNAMIC+0x468>
  816b15:	movb   $0x0,0x98(%rbx)
  816b1c:	mov    0x60(%rbx),%rax
  816b20:	lock decq (%rax)
  816b24:	jne    816b2f <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x7f>
  816b26:	lea    0x60(%rbx),%rdi
  816b2a:	call   812c30 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  816b2f:	movw   $0x0,0x99(%rbx)
  816b38:	mov    0x40(%rbx),%rax
  816b3c:	lock decq (%rax)
  816b40:	jne    816b4c <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x9c>
  816b42:	lea    0x40(%rbx),%rdi
  816b46:	call   *0x6693e4(%rip)        # e7ff30 <_DYNAMIC+0x470>
  816b4c:	movb   $0x0,0x9b(%rbx)
  816b53:	mov    0x38(%rbx),%rax
  816b57:	lock decq (%rax)
  816b5b:	jne    816b67 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xb7>
  816b5d:	lea    0x38(%rbx),%rdi
  816b61:	call   *0x6693d1(%rip)        # e7ff38 <_DYNAMIC+0x478>
  816b67:	movb   $0x0,0x9c(%rbx)
  816b6e:	mov    0x30(%rbx),%rax
  816b72:	lock decq (%rax)
  816b76:	jne    816b82 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xd2>
  816b78:	lea    0x30(%rbx),%rdi
  816b7c:	call   *0x6693be(%rip)        # e7ff40 <_DYNAMIC+0x480>
  816b82:	movb   $0x0,0x9d(%rbx)
  816b89:	jmp    816bc1 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x111>
  816b8b:	mov    0x70(%rbx),%rax
  816b8f:	lock decq (%rax)
  816b93:	jne    816b9f <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xef>
  816b95:	lea    0x70(%rbx),%rdi
  816b99:	call   *0x6693a1(%rip)        # e7ff40 <_DYNAMIC+0x480>
  816b9f:	mov    0x78(%rbx),%rax
  816ba3:	lock decq (%rax)
  816ba7:	jne    816bc1 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x111>
  816ba9:	add    $0x78,%rbx
  816bad:	mov    %rbx,%rdi
  816bb0:	add    $0x8,%rsp
  816bb4:	pop    %rbx
  816bb5:	pop    %r12
  816bb7:	pop    %r14
  816bb9:	pop    %r15
  816bbb:	jmp    *0x669377(%rip)        # e7ff38 <_DYNAMIC+0x478>
  816bc1:	add    $0x8,%rsp
  816bc5:	pop    %rbx
  816bc6:	pop    %r12
  816bc8:	pop    %r14
  816bca:	pop    %r15
  816bcc:	ret
  816bcd:	mov    %rax,%r14
  816bd0:	movb   $0x0,0x9d(%rbx)
  816bd7:	mov    %r14,%rdi
  816bda:	call   e2c830 <_Unwind_Resume@plt>
  816bdf:	mov    %rax,%r14
  816be2:	jmp    816c9c <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1ec>
  816be7:	mov    %rax,%r14
  816bea:	jmp    816c81 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1d1>
  816bef:	mov    %rax,%r14
  816bf2:	jmp    816c64 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1b4>
  816bf4:	mov    %rax,%r14
  816bf7:	jmp    816c4a <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x19a>
  816bf9:	mov    %rax,%r14
  816bfc:	mov    0x78(%rbx),%rax
  816c00:	lock decq (%rax)
  816c04:	jne    816c13 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x163>
  816c06:	add    $0x78,%rbx
  816c0a:	mov    %rbx,%rdi
  816c0d:	call   *0x669325(%rip)        # e7ff38 <_DYNAMIC+0x478>
  816c13:	mov    %r14,%rdi
  816c16:	call   e2c830 <_Unwind_Resume@plt>
  816c1b:	mov    %rax,%r14
  816c1e:	mov    0x8(%r12),%rsi
  816c23:	test   %rsi,%rsi
  816c26:	je     816c36 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x186>
  816c28:	mov    0x10(%r12),%rdx
  816c2d:	mov    %r15,%rdi
  816c30:	call   *0x6690d2(%rip)        # e7fd08 <_DYNAMIC+0x248>
  816c36:	mov    0x68(%rbx),%rax
  816c3a:	lock decq (%rax)
  816c3e:	jne    816c4a <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x19a>
  816c40:	lea    0x68(%rbx),%rdi
  816c44:	call   *0x6692de(%rip)        # e7ff28 <_DYNAMIC+0x468>
  816c4a:	movb   $0x0,0x98(%rbx)
  816c51:	mov    0x60(%rbx),%rax
  816c55:	lock decq (%rax)
  816c59:	jne    816c64 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1b4>
  816c5b:	lea    0x60(%rbx),%rdi
  816c5f:	call   812c30 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  816c64:	movw   $0x0,0x99(%rbx)
  816c6d:	mov    0x40(%rbx),%rax
  816c71:	lock decq (%rax)
  816c75:	jne    816c81 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1d1>
  816c77:	lea    0x40(%rbx),%rdi
  816c7b:	call   *0x6692af(%rip)        # e7ff30 <_DYNAMIC+0x470>
  816c81:	movb   $0x0,0x9b(%rbx)
  816c88:	mov    0x38(%rbx),%rax
  816c8c:	lock decq (%rax)
  816c90:	jne    816c9c <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1ec>
  816c92:	lea    0x38(%rbx),%rdi
  816c96:	call   *0x66929c(%rip)        # e7ff38 <_DYNAMIC+0x478>
  816c9c:	movb   $0x0,0x9c(%rbx)
  816ca3:	mov    0x30(%rbx),%rax
  816ca7:	lock decq (%rax)
  816cab:	jne    816cb7 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x207>
  816cad:	lea    0x30(%rbx),%rdi
  816cb1:	call   *0x669289(%rip)        # e7ff40 <_DYNAMIC+0x480>
  816cb7:	movb   $0x0,0x9d(%rbx)
  816cbe:	mov    %r14,%rdi
  816cc1:	call   e2c830 <_Unwind_Resume@plt>
  816cc6:	call   *0x669044(%rip)        # e7fd10 <_DYNAMIC+0x250>

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000816cd0 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}>>:
  816cd0:	push   %rbx
  816cd1:	movzbl 0x20(%rdi),%eax
  816cd5:	cmp    $0x3,%eax
  816cd8:	je     816cf3 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}>+0x23>
  816cda:	cmp    $0x4,%eax
  816cdd:	jne    816d00 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}>+0x30>
  816cdf:	mov    %rdi,%rbx
  816ce2:	add    $0x28,%rdi
  816ce6:	call   816ab0 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>>
  816ceb:	movw   $0x0,0x21(%rbx)
  816cf1:	pop    %rbx
  816cf2:	ret
  816cf3:	add    $0x160,%rdi
  816cfa:	pop    %rbx
  816cfb:	jmp    8169d0 <core::ptr::drop_glue::<<wgpu::api::adapter::Adapter>::request_device::{closure#0}>>
  816d00:	pop    %rbx
  816d01:	ret
  816d02:	movw   $0x0,0x21(%rbx)
  816d08:	mov    %rax,%rdi
  816d0b:	call   e2c830 <_Unwind_Resume@plt>

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008171f0 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>>:
  8171f0:	push   %r14
  8171f2:	push   %rbx
  8171f3:	push   %rax
  8171f4:	mov    %rdi,%rbx
  8171f7:	mov    (%rdi),%rax
  8171fa:	lock decq (%rax)
  8171fe:	jne    817209 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x19>
  817200:	mov    %rbx,%rdi
  817203:	call   *0x668d37(%rip)        # e7ff40 <_DYNAMIC+0x480>
  817209:	mov    0x8(%rbx),%rax
  81720d:	lock decq (%rax)
  817211:	jne    81721d <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x2d>
  817213:	lea    0x8(%rbx),%rdi
  817217:	call   *0x668d1b(%rip)        # e7ff38 <_DYNAMIC+0x478>
  81721d:	mov    0x10(%rbx),%rax
  817221:	lock decq (%rax)
  817225:	jne    817230 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x40>
  817227:	lea    0x10(%rbx),%rdi
  81722b:	call   812c30 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  817230:	mov    0x18(%rbx),%rax
  817234:	lock decq (%rax)
  817238:	jne    81724e <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x5e>
  81723a:	add    $0x18,%rbx
  81723e:	mov    %rbx,%rdi
  817241:	add    $0x8,%rsp
  817245:	pop    %rbx
  817246:	pop    %r14
  817248:	jmp    *0x668cda(%rip)        # e7ff28 <_DYNAMIC+0x468>
  81724e:	add    $0x8,%rsp
  817252:	pop    %rbx
  817253:	pop    %r14
  817255:	ret
  817256:	mov    %rax,%r14
  817259:	jmp    81728a <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x9a>
  81725b:	mov    %rax,%r14
  81725e:	jmp    817277 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x87>
  817260:	mov    %rax,%r14
  817263:	mov    0x8(%rbx),%rax
  817267:	lock decq (%rax)
  81726b:	jne    817277 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x87>
  81726d:	lea    0x8(%rbx),%rdi
  817271:	call   *0x668cc1(%rip)        # e7ff38 <_DYNAMIC+0x478>
  817277:	mov    0x10(%rbx),%rax
  81727b:	lock decq (%rax)
  81727f:	jne    81728a <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x9a>
  817281:	lea    0x10(%rbx),%rdi
  817285:	call   812c30 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  81728a:	mov    0x18(%rbx),%rax
  81728e:	lock decq (%rax)
  817292:	jne    8172a1 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0xb1>
  817294:	add    $0x18,%rbx
  817298:	mov    %rbx,%rdi
  81729b:	call   *0x668c87(%rip)        # e7ff28 <_DYNAMIC+0x468>
  8172a1:	mov    %r14,%rdi
  8172a4:	call   e2c830 <_Unwind_Resume@plt>
  8172a9:	call   *0x668a61(%rip)        # e7fd10 <_DYNAMIC+0x250>

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008172b0 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>>:
  8172b0:	push   %r14
  8172b2:	push   %rbx
  8172b3:	push   %rax
  8172b4:	mov    %rdi,%rbx
  8172b7:	mov    0x228(%rdi),%rax
  8172be:	lock decq (%rax)
  8172c2:	jne    8172d1 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x21>
  8172c4:	lea    0x228(%rbx),%rdi
  8172cb:	call   *0x668c57(%rip)        # e7ff28 <_DYNAMIC+0x468>
  8172d1:	mov    0x230(%rbx),%rax
  8172d8:	lock decq (%rax)
  8172dc:	jne    8172eb <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3b>
  8172de:	lea    0x230(%rbx),%rdi
  8172e5:	call   *0x668cdd(%rip)        # e7ffc8 <_DYNAMIC+0x508>
  8172eb:	mov    0x238(%rbx),%rax
  8172f2:	lock decq (%rax)
  8172f6:	jne    817305 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x55>
  8172f8:	lea    0x238(%rbx),%rdi
  8172ff:	call   *0x668ccb(%rip)        # e7ffd0 <_DYNAMIC+0x510>
  817305:	mov    0x258(%rbx),%rax
  81730c:	lock decq (%rax)
  817310:	jne    81731f <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x6f>
  817312:	lea    0x258(%rbx),%rdi
  817319:	call   *0x668ca9(%rip)        # e7ffc8 <_DYNAMIC+0x508>
  81731f:	mov    0x260(%rbx),%rax
  817326:	lock decq (%rax)
  81732a:	jne    817339 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x89>
  81732c:	lea    0x260(%rbx),%rdi
  817333:	call   *0x668c97(%rip)        # e7ffd0 <_DYNAMIC+0x510>
  817339:	mov    0x280(%rbx),%rax
  817340:	lock decq (%rax)
  817344:	jne    817353 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xa3>
  817346:	lea    0x280(%rbx),%rdi
  81734d:	call   *0x668c75(%rip)        # e7ffc8 <_DYNAMIC+0x508>
  817353:	mov    0x288(%rbx),%rax
  81735a:	lock decq (%rax)
  81735e:	jne    81736d <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xbd>
  817360:	lea    0x288(%rbx),%rdi
  817367:	call   *0x668c63(%rip)        # e7ffd0 <_DYNAMIC+0x510>
  81736d:	mov    0x2a8(%rbx),%rax
  817374:	lock decq (%rax)
  817378:	jne    817387 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xd7>
  81737a:	lea    0x2a8(%rbx),%rdi
  817381:	call   *0x668c41(%rip)        # e7ffc8 <_DYNAMIC+0x508>
  817387:	mov    0x2b0(%rbx),%rax
  81738e:	lock decq (%rax)
  817392:	jne    8173a1 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xf1>
  817394:	lea    0x2b0(%rbx),%rdi
  81739b:	call   *0x668c2f(%rip)        # e7ffd0 <_DYNAMIC+0x510>
  8173a1:	mov    0x2d0(%rbx),%rax
  8173a8:	lock decq (%rax)
  8173ac:	jne    8173bb <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x10b>
  8173ae:	lea    0x2d0(%rbx),%rdi
  8173b5:	call   *0x668c0d(%rip)        # e7ffc8 <_DYNAMIC+0x508>
  8173bb:	mov    0x2d8(%rbx),%rax
  8173c2:	lock decq (%rax)
  8173c6:	jne    8173d5 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x125>
  8173c8:	lea    0x2d8(%rbx),%rdi
  8173cf:	call   *0x668bfb(%rip)        # e7ffd0 <_DYNAMIC+0x510>
  8173d5:	lea    0x78(%rbx),%rdi
  8173d9:	call   8177a0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  8173de:	mov    0x328(%rbx),%r14
  8173e5:	test   %r14,%r14
  8173e8:	je     817447 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x197>
  8173ea:	mov    (%r14),%rsi
  8173ed:	test   %rsi,%rsi
  8173f0:	je     817405 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x155>
  8173f2:	mov    0x8(%r14),%rdi
  8173f6:	shl    $0x3,%rsi
  8173fa:	mov    $0x8,%edx
  8173ff:	call   *0x668903(%rip)        # e7fd08 <_DYNAMIC+0x248>
  817405:	mov    0x20(%r14),%rsi
  817409:	test   %rsi,%rsi
  81740c:	je     817434 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x184>
  81740e:	mov    %rsi,%rax
  817411:	shl    $0x4,%rax
  817415:	add    %rax,%rsi
  817418:	add    $0x21,%rsi
  81741c:	je     817434 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x184>
  81741e:	mov    0x18(%r14),%rdi
  817422:	sub    %rax,%rdi
  817425:	add    $0xfffffffffffffff0,%rdi
  817429:	mov    $0x10,%edx
  81742e:	call   *0x6688d4(%rip)        # e7fd08 <_DYNAMIC+0x248>
  817434:	mov    $0x80,%esi
  817439:	mov    $0x8,%edx
  81743e:	mov    %r14,%rdi
  817441:	call   *0x6688c1(%rip)        # e7fd08 <_DYNAMIC+0x248>
  817447:	mov    (%rbx),%rsi
  81744a:	test   %rsi,%rsi
  81744d:	je     817462 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x1b2>
  81744f:	mov    0x8(%rbx),%rdi
  817453:	shl    $0x4,%rsi
  817457:	mov    $0x4,%edx
  81745c:	call   *0x6688a6(%rip)        # e7fd08 <_DYNAMIC+0x248>
  817462:	mov    0x18(%rbx),%rsi
  817466:	test   %rsi,%rsi
  817469:	je     81747e <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x1ce>
  81746b:	mov    0x20(%rbx),%rdi
  81746f:	shl    $0x3,%rsi
  817473:	mov    $0x4,%edx
  817478:	call   *0x66888a(%rip)        # e7fd08 <_DYNAMIC+0x248>
  81747e:	mov    0x30(%rbx),%rsi
  817482:	test   %rsi,%rsi
  817485:	je     81749a <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x1ea>
  817487:	mov    0x38(%rbx),%rdi
  81748b:	shl    $0x2,%rsi
  81748f:	mov    $0x4,%edx
  817494:	call   *0x66886e(%rip)        # e7fd08 <_DYNAMIC+0x248>
  81749a:	mov    0x48(%rbx),%rsi
  81749e:	test   %rsi,%rsi
  8174a1:	je     8174b6 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x206>
  8174a3:	mov    0x50(%rbx),%rdi
  8174a7:	shl    $0x2,%rsi
  8174ab:	mov    $0x4,%edx
  8174b0:	call   *0x668852(%rip)        # e7fd08 <_DYNAMIC+0x248>
  8174b6:	mov    0x60(%rbx),%rsi
  8174ba:	test   %rsi,%rsi
  8174bd:	je     8174d2 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x222>
  8174bf:	mov    0x68(%rbx),%rdi
  8174c3:	shl    $0x5,%rsi
  8174c7:	mov    $0x4,%edx
  8174cc:	call   *0x668836(%rip)        # e7fd08 <_DYNAMIC+0x248>
  8174d2:	mov    0x300(%rbx),%rsi
  8174d9:	test   %rsi,%rsi
  8174dc:	je     81750c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x25c>
  8174de:	lea    (%rsi,%rsi,8),%rax
  8174e2:	lea    0x33(,%rax,4),%rax
  8174ea:	and    $0xfffffffffffffff0,%rax
  8174ee:	add    %rax,%rsi
  8174f1:	add    $0x11,%rsi
  8174f5:	je     81750c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x25c>
  8174f7:	mov    0x2f8(%rbx),%rdi
  8174fe:	sub    %rax,%rdi
  817501:	mov    $0x10,%edx
  817506:	call   *0x6687fc(%rip)        # e7fd08 <_DYNAMIC+0x248>
  81750c:	mov    0x330(%rbx),%rax
  817513:	test   %rax,%rax
  817516:	je     817535 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x285>
  817518:	lock decq (%rax)
  81751c:	jne    817535 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x285>
  81751e:	add    $0x330,%rbx
  817525:	mov    %rbx,%rdi
  817528:	add    $0x8,%rsp
  81752c:	pop    %rbx
  81752d:	pop    %r14
  81752f:	jmp    *0x668aa3(%rip)        # e7ffd8 <_DYNAMIC+0x518>
  817535:	add    $0x8,%rsp
  817539:	pop    %rbx
  81753a:	pop    %r14
  81753c:	ret
  81753d:	mov    %rax,%r14
  817540:	jmp    81766c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3bc>
  817545:	mov    %rax,%r14
  817548:	mov    0x2d8(%rbx),%rax
  81754f:	lock decq (%rax)
  817553:	jne    81766c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3bc>
  817559:	lea    0x2d8(%rbx),%rdi
  817560:	call   *0x668a6a(%rip)        # e7ffd0 <_DYNAMIC+0x510>
  817566:	jmp    81766c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3bc>
  81756b:	call   *0x66879f(%rip)        # e7fd10 <_DYNAMIC+0x250>
  817571:	mov    %rax,%r14
  817574:	jmp    817660 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3b0>
  817579:	mov    %rax,%r14
  81757c:	mov    0x2b0(%rbx),%rax
  817583:	lock decq (%rax)
  817587:	jne    817660 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3b0>
  81758d:	lea    0x2b0(%rbx),%rdi
  817594:	call   *0x668a36(%rip)        # e7ffd0 <_DYNAMIC+0x510>
  81759a:	jmp    817660 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3b0>
  81759f:	call   *0x66876b(%rip)        # e7fd10 <_DYNAMIC+0x250>
  8175a5:	mov    %rax,%r14
  8175a8:	jmp    817654 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3a4>
  8175ad:	mov    %rax,%r14
  8175b0:	mov    0x288(%rbx),%rax
  8175b7:	lock decq (%rax)
  8175bb:	jne    817654 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3a4>
  8175c1:	lea    0x288(%rbx),%rdi
  8175c8:	call   *0x668a02(%rip)        # e7ffd0 <_DYNAMIC+0x510>
  8175ce:	jmp    817654 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3a4>
  8175d3:	call   *0x668737(%rip)        # e7fd10 <_DYNAMIC+0x250>
  8175d9:	mov    %rax,%r14
  8175dc:	jmp    817648 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x398>
  8175de:	mov    %rax,%r14
  8175e1:	mov    0x260(%rbx),%rax
  8175e8:	lock decq (%rax)
  8175ec:	jne    817648 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x398>
  8175ee:	lea    0x260(%rbx),%rdi
  8175f5:	call   *0x6689d5(%rip)        # e7ffd0 <_DYNAMIC+0x510>
  8175fb:	jmp    817648 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x398>
  8175fd:	call   *0x66870d(%rip)        # e7fd10 <_DYNAMIC+0x250>
  817603:	mov    %rax,%r14
  817606:	jmp    81763c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x38c>
  817608:	mov    %rax,%r14
  81760b:	mov    0x238(%rbx),%rax
  817612:	lock decq (%rax)
  817616:	jne    81763c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x38c>
  817618:	lea    0x238(%rbx),%rdi
  81761f:	call   *0x6689ab(%rip)        # e7ffd0 <_DYNAMIC+0x510>
  817625:	jmp    81763c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x38c>
  817627:	call   *0x6686e3(%rip)        # e7fd10 <_DYNAMIC+0x250>
  81762d:	mov    %rax,%r14
  817630:	lea    0x230(%rbx),%rdi
  817637:	call   8178a0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81763c:	lea    0x258(%rbx),%rdi
  817643:	call   8178a0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  817648:	lea    0x280(%rbx),%rdi
  81764f:	call   8178a0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  817654:	lea    0x2a8(%rbx),%rdi
  81765b:	call   8178a0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  817660:	lea    0x2d0(%rbx),%rdi
  817667:	call   8178a0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81766c:	lea    0x78(%rbx),%rdi
  817670:	call   8177a0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  817675:	mov    0x328(%rbx),%rdi
  81767c:	call   8163f0 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>
  817681:	mov    (%rbx),%rsi
  817684:	test   %rsi,%rsi
  817687:	jne    817702 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x452>
  817689:	mov    0x18(%rbx),%rsi
  81768d:	test   %rsi,%rsi
  817690:	jne    817722 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x472>
  817696:	mov    0x30(%rbx),%rsi
  81769a:	test   %rsi,%rsi
  81769d:	jne    817742 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x492>
  8176a3:	mov    0x48(%rbx),%rsi
  8176a7:	test   %rsi,%rsi
  8176aa:	jne    817762 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x4b2>
  8176b0:	mov    0x60(%rbx),%rsi
  8176b4:	test   %rsi,%rsi
  8176b7:	je     8176cc <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x41c>
  8176b9:	mov    0x68(%rbx),%rdi
  8176bd:	shl    $0x5,%rsi
  8176c1:	mov    $0x4,%edx
  8176c6:	call   *0x66863c(%rip)        # e7fd08 <_DYNAMIC+0x248>
  8176cc:	lea    0x2f8(%rbx),%rdi
  8176d3:	call   819bb0 <<hashbrown::raw::RawTable<([u32; 8], u32)> as core::ops::drop::Drop>::drop>
  8176d8:	mov    0x330(%rbx),%rax
  8176df:	test   %rax,%rax
  8176e2:	je     8176fa <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x44a>
  8176e4:	lock decq (%rax)
  8176e8:	jne    8176fa <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x44a>
  8176ea:	add    $0x330,%rbx
  8176f1:	mov    %rbx,%rdi
  8176f4:	call   *0x6688de(%rip)        # e7ffd8 <_DYNAMIC+0x518>
  8176fa:	mov    %r14,%rdi
  8176fd:	call   e2c830 <_Unwind_Resume@plt>
  817702:	mov    0x8(%rbx),%rdi
  817706:	shl    $0x4,%rsi
  81770a:	mov    $0x4,%edx
  81770f:	call   *0x6685f3(%rip)        # e7fd08 <_DYNAMIC+0x248>
  817715:	mov    0x18(%rbx),%rsi
  817719:	test   %rsi,%rsi
  81771c:	je     817696 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3e6>
  817722:	mov    0x20(%rbx),%rdi
  817726:	shl    $0x3,%rsi
  81772a:	mov    $0x4,%edx
  81772f:	call   *0x6685d3(%rip)        # e7fd08 <_DYNAMIC+0x248>
  817735:	mov    0x30(%rbx),%rsi
  817739:	test   %rsi,%rsi
  81773c:	je     8176a3 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3f3>
  817742:	mov    0x38(%rbx),%rdi
  817746:	shl    $0x2,%rsi
  81774a:	mov    $0x4,%edx
  81774f:	call   *0x6685b3(%rip)        # e7fd08 <_DYNAMIC+0x248>
  817755:	mov    0x48(%rbx),%rsi
  817759:	test   %rsi,%rsi
  81775c:	je     8176b0 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x400>
  817762:	mov    0x50(%rbx),%rdi
  817766:	shl    $0x2,%rsi
  81776a:	mov    $0x4,%edx
  81776f:	call   *0x668593(%rip)        # e7fd08 <_DYNAMIC+0x248>
  817775:	mov    0x60(%rbx),%rsi
  817779:	test   %rsi,%rsi
  81777c:	jne    8176b9 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x409>
  817782:	jmp    8176cc <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x41c>
  817787:	call   *0x668583(%rip)        # e7fd10 <_DYNAMIC+0x250>
  81778d:	mov    %rax,%r14
  817790:	jmp    817675 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3c5>

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008177a0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>:
  8177a0:	push   %r14
  8177a2:	push   %rbx
  8177a3:	push   %rax
  8177a4:	mov    %rdi,%rbx
  8177a7:	mov    (%rdi),%rax
  8177aa:	lock decq (%rax)
  8177ae:	jne    8177b9 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x19>
  8177b0:	mov    %rbx,%rdi
  8177b3:	call   *0x6687ef(%rip)        # e7ffa8 <_DYNAMIC+0x4e8>
  8177b9:	mov    0x50(%rbx),%rax
  8177bd:	lock decq (%rax)
  8177c1:	jne    8177cd <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x2d>
  8177c3:	lea    0x50(%rbx),%rdi
  8177c7:	call   *0x6687d3(%rip)        # e7ffa0 <_DYNAMIC+0x4e0>
  8177cd:	mov    0x58(%rbx),%rax
  8177d1:	lock decq (%rax)
  8177d5:	jne    8177e1 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x41>
  8177d7:	lea    0x58(%rbx),%rdi
  8177db:	call   *0x6687c7(%rip)        # e7ffa8 <_DYNAMIC+0x4e8>
  8177e1:	mov    0xb0(%rbx),%rsi
  8177e8:	test   %rsi,%rsi
  8177eb:	je     81781d <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  8177ed:	mov    %rsi,%rax
  8177f0:	shl    $0x5,%rax
  8177f4:	add    %rax,%rsi
  8177f7:	add    $0x31,%rsi
  8177fb:	je     81781d <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  8177fd:	mov    0xa8(%rbx),%rdi
  817804:	sub    %rax,%rdi
  817807:	add    $0xffffffffffffffe0,%rdi
  81780b:	mov    $0x10,%edx
  817810:	add    $0x8,%rsp
  817814:	pop    %rbx
  817815:	pop    %r14
  817817:	jmp    *0x6684eb(%rip)        # e7fd08 <_DYNAMIC+0x248>
  81781d:	add    $0x8,%rsp
  817821:	pop    %rbx
  817822:	pop    %r14
  817824:	ret
  817825:	mov    %rax,%r14
  817828:	jmp    817855 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  81782a:	mov    %rax,%r14
  81782d:	mov    0x58(%rbx),%rax
  817831:	lock decq (%rax)
  817835:	jne    817855 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  817837:	lea    0x58(%rbx),%rdi
  81783b:	call   *0x668767(%rip)        # e7ffa8 <_DYNAMIC+0x4e8>
  817841:	jmp    817855 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  817843:	call   *0x6684c7(%rip)        # e7fd10 <_DYNAMIC+0x250>
  817849:	mov    %rax,%r14
  81784c:	lea    0x50(%rbx),%rdi
  817850:	call   8179a0 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  817855:	add    $0xa8,%rbx
  81785c:	mov    %rbx,%rdi
  81785f:	call   819bf0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>
  817864:	mov    %r14,%rdi
  817867:	call   e2c830 <_Unwind_Resume@plt>
  81786c:	call   *0x66849e(%rip)        # e7fd10 <_DYNAMIC+0x250>

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000817880 <core::ptr::drop_glue::<gpui_gpu::renderer::Error>>:
  817880:	cmpl   $0x1,(%rdi)
  817883:	ja     81789d <core::ptr::drop_glue::<gpui_gpu::renderer::Error>+0x1d>
  817885:	mov    0x8(%rdi),%rsi
  817889:	test   %rsi,%rsi
  81788c:	je     81789d <core::ptr::drop_glue::<gpui_gpu::renderer::Error>+0x1d>
  81788e:	mov    0x10(%rdi),%rdi
  817892:	mov    $0x1,%edx
  817897:	jmp    *0x66846b(%rip)        # e7fd08 <_DYNAMIC+0x248>
  81789d:	ret

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008178a0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>:
  8178a0:	push   %r14
  8178a2:	push   %rbx
  8178a3:	push   %rax
  8178a4:	mov    %rdi,%rbx
  8178a7:	mov    (%rdi),%rax
  8178aa:	lock decq (%rax)
  8178ae:	jne    8178b9 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x19>
  8178b0:	mov    %rbx,%rdi
  8178b3:	call   *0x66870f(%rip)        # e7ffc8 <_DYNAMIC+0x508>
  8178b9:	mov    0x8(%rbx),%rax
  8178bd:	lock decq (%rax)
  8178c1:	jne    8178d7 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x37>
  8178c3:	add    $0x8,%rbx
  8178c7:	mov    %rbx,%rdi
  8178ca:	add    $0x8,%rsp
  8178ce:	pop    %rbx
  8178cf:	pop    %r14
  8178d1:	jmp    *0x6686f9(%rip)        # e7ffd0 <_DYNAMIC+0x510>
  8178d7:	add    $0x8,%rsp
  8178db:	pop    %rbx
  8178dc:	pop    %r14
  8178de:	ret
  8178df:	mov    %rax,%r14
  8178e2:	mov    0x8(%rbx),%rax
  8178e6:	lock decq (%rax)
  8178ea:	jne    8178f9 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x59>
  8178ec:	add    $0x8,%rbx
  8178f0:	mov    %rbx,%rdi
  8178f3:	call   *0x6686d7(%rip)        # e7ffd0 <_DYNAMIC+0x510>
  8178f9:	mov    %r14,%rdi
  8178fc:	call   e2c830 <_Unwind_Resume@plt>
  817901:	call   *0x668409(%rip)        # e7fd10 <_DYNAMIC+0x250>

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000818270 <<gpui_gpu::renderer::Error as core::fmt::Debug>::fmt>:
  818270:	sub    $0x18,%rsp
  818274:	mov    %rsi,%rax
  818277:	mov    (%rdi),%ecx
  818279:	lea    -0x747420(%rip),%rdx        # d0e60 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0xbb8>
  818280:	movslq (%rdx,%rcx,4),%rcx
  818284:	add    %rdx,%rcx
  818287:	jmp    *%rcx
  818289:	add    $0x8,%rdi
  81828d:	mov    %rdi,0x10(%rsp)
  818292:	lea    -0x743b35(%rip),%rsi        # d4764 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x44bc>
  818299:	jmp    818328 <<gpui_gpu::renderer::Error as core::fmt::Debug>::fmt+0xb8>
  81829e:	lea    -0x743b18(%rip),%rsi        # d478d <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x44e5>
  8182a5:	mov    $0x13,%edx
  8182aa:	mov    %rax,%rdi
  8182ad:	add    $0x18,%rsp
  8182b1:	jmp    *0x667b41(%rip)        # e7fdf8 <_DYNAMIC+0x338>
  8182b7:	add    $0x4,%rdi
  8182bb:	mov    %rdi,0x10(%rsp)
  8182c0:	lea    -0x743b57(%rip),%rsi        # d4770 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x44c8>
  8182c7:	lea    0x615e6a(%rip),%r8        # e2e138 <__frame_dummy_init_array_entry+0x8c8>
  8182ce:	lea    0x10(%rsp),%rcx
  8182d3:	mov    $0x11,%edx
  8182d8:	mov    %rax,%rdi
  8182db:	call   *0x667b1f(%rip)        # e7fe00 <_DYNAMIC+0x340>
  8182e1:	add    $0x18,%rsp
  8182e5:	ret
  8182e6:	lea    -0x743b6c(%rip),%rsi        # d4781 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x44d9>
  8182ed:	mov    $0xc,%edx
  8182f2:	mov    %rax,%rdi
  8182f5:	add    $0x18,%rsp
  8182f9:	jmp    *0x667af9(%rip)        # e7fdf8 <_DYNAMIC+0x338>
  8182ff:	lea    -0x743b50(%rip),%rsi        # d47b6 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x450e>
  818306:	mov    $0x9,%edx
  81830b:	mov    %rax,%rdi
  81830e:	add    $0x18,%rsp
  818312:	jmp    *0x667ae0(%rip)        # e7fdf8 <_DYNAMIC+0x338>
  818318:	add    $0x8,%rdi
  81831c:	mov    %rdi,0x10(%rsp)
  818321:	lea    -0x743bbe(%rip),%rsi        # d476a <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x44c2>
  818328:	lea    0x615de9(%rip),%r8        # e2e118 <__frame_dummy_init_array_entry+0x8a8>
  81832f:	lea    0x10(%rsp),%rcx
  818334:	mov    $0x6,%edx
  818339:	mov    %rax,%rdi
  81833c:	call   *0x667abe(%rip)        # e7fe00 <_DYNAMIC+0x340>
  818342:	add    $0x18,%rsp
  818346:	ret
  818347:	add    $0x8,%rdi
  81834b:	mov    %rdi,0x10(%rsp)
  818350:	lea    0x615e01(%rip),%rcx        # e2e158 <__frame_dummy_init_array_entry+0x8e8>
  818357:	mov    %rcx,(%rsp)
  81835b:	lea    -0x743bc2(%rip),%rsi        # d47a0 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x44f8>
  818362:	lea    -0x7694fd(%rip),%rcx        # aee6c <anon.a16d5d421a76dfd8c37a17b53540311d.67.llvm.14190004212411149437+0x20>
  818369:	lea    0x10(%rsp),%r9
  81836e:	mov    $0x9,%edx
  818373:	mov    $0x4,%r8d
  818379:	mov    %rax,%rdi
  81837c:	call   *0x667c66(%rip)        # e7ffe8 <_DYNAMIC+0x528>
  818382:	add    $0x18,%rsp
  818386:	ret
  818387:	lea    -0x743be5(%rip),%rsi        # d47a9 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x4501>
  81838e:	mov    $0xd,%edx
  818393:	mov    %rax,%rdi
  818396:	add    $0x18,%rsp
  81839a:	jmp    *0x667a58(%rip)        # e7fdf8 <_DYNAMIC+0x338>

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000819bf0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>:
  819bf0:	mov    0x8(%rdi),%rsi
  819bf4:	test   %rsi,%rsi
  819bf7:	je     819c1e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  819bf9:	mov    %rsi,%rax
  819bfc:	shl    $0x5,%rax
  819c00:	add    %rax,%rsi
  819c03:	add    $0x31,%rsi
  819c07:	je     819c1e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  819c09:	mov    (%rdi),%rdi
  819c0c:	sub    %rax,%rdi
  819c0f:	add    $0xffffffffffffffe0,%rdi
  819c13:	mov    $0x10,%edx
  819c18:	jmp    *0x6660ea(%rip)        # e7fd08 <_DYNAMIC+0x248>
  819c1e:	ret

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000819c20 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop>:
  819c20:	mov    0x8(%rdi),%rsi
  819c24:	test   %rsi,%rsi
  819c27:	je     819c4e <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop+0x2e>
  819c29:	mov    %rsi,%rax
  819c2c:	shl    $0x4,%rax
  819c30:	add    %rax,%rsi
  819c33:	add    $0x21,%rsi
  819c37:	je     819c4e <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop+0x2e>
  819c39:	mov    (%rdi),%rdi
  819c3c:	sub    %rax,%rdi
  819c3f:	add    $0xfffffffffffffff0,%rdi
  819c43:	mov    $0x10,%edx
  819c48:	jmp    *0x6660ba(%rip)        # e7fd08 <_DYNAMIC+0x248>
  819c4e:	ret

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081b4e0 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>>:
  81b4e0:	push   %r14
  81b4e2:	push   %rbx
  81b4e3:	sub    $0x38,%rsp
  81b4e7:	mov    %rdi,%rbx
  81b4ea:	cmpq   $0x0,(%rsi)
  81b4ee:	je     81b5f8 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x118>
  81b4f4:	movdqu (%rsi),%xmm0
  81b4f8:	movdqu 0x10(%rsi),%xmm1
  81b4fd:	movdqu 0x20(%rsi),%xmm2
  81b502:	movdqa %xmm2,0x20(%rsp)
  81b508:	movdqa %xmm1,0x10(%rsp)
  81b50e:	movdqa %xmm0,(%rsp)
  81b513:	cmpq   $0x0,0x18(%rcx)
  81b518:	je     81b60c <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x12c>
  81b51e:	lea    0x10(%rsp),%rsi
  81b523:	lea    0x20(%rcx),%rdi
  81b527:	mov    %rcx,%r14
  81b52a:	call   824b60 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  81b52f:	mov    %rax,%rsi
  81b532:	shr    $0x39,%rsi
  81b536:	mov    (%r14),%rcx
  81b539:	mov    0x8(%r14),%rdx
  81b53d:	movd   %esi,%xmm0
  81b541:	punpcklbw %xmm0,%xmm0
  81b545:	pshuflw $0x0,%xmm0,%xmm0
  81b54a:	pshufd $0x44,%xmm0,%xmm0
  81b54f:	mov    0x10(%rsp),%rsi
  81b554:	movzwl 0x1c(%rsp),%edi
  81b559:	xor    %r8d,%r8d
  81b55c:	mov    0x18(%rsp),%r9d
  81b561:	pcmpeqd %xmm1,%xmm1
  81b565:	and    %rdx,%rax
  81b568:	movdqu (%rcx,%rax,1),%xmm2
  81b56d:	movdqa %xmm2,%xmm3
  81b571:	pcmpeqb %xmm0,%xmm3
  81b575:	pmovmskb %xmm3,%r10d
  81b57a:	test   %r10d,%r10d
  81b57d:	je     81b5c0 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xe0>
  81b57f:	tzcnt  %r10d,%r14d
  81b584:	add    %rax,%r14
  81b587:	and    %rdx,%r14
  81b58a:	shl    $0x5,%r14
  81b58e:	mov    %rcx,%r11
  81b591:	sub    %r14,%r11
  81b594:	cmp    -0x20(%r11),%rsi
  81b598:	jne    81b5a7 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xc7>
  81b59a:	cmp    -0x14(%r11),%di
  81b59f:	jne    81b5a7 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xc7>
  81b5a1:	cmp    -0x18(%r11),%r9d
  81b5a5:	je     81b5db <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xfb>
  81b5a7:	lea    -0x1(%r10),%r11d
  81b5ab:	and    %r10w,%r11w
  81b5af:	mov    %r11d,%r10d
  81b5b2:	jne    81b57f <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x9f>
  81b5b4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  81b5c0:	pcmpeqb %xmm1,%xmm2
  81b5c4:	pmovmskb %xmm2,%r10d
  81b5c9:	test   %r10d,%r10d
  81b5cc:	jne    81b60c <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x12c>
  81b5ce:	add    %r8,%rax
  81b5d1:	add    $0x10,%rax
  81b5d5:	add    $0x10,%r8
  81b5d9:	jmp    81b565 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x85>
  81b5db:	mov    -0x4(%r11),%eax
  81b5df:	shl    $0x10,%eax
  81b5e2:	or     -0x8(%r11),%eax
  81b5e6:	mov    -0x10(%r11),%rcx
  81b5ea:	mov    %rcx,(%rbx)
  81b5ed:	mov    %eax,0x8(%rbx)
  81b5f0:	add    $0x38,%rsp
  81b5f4:	pop    %rbx
  81b5f5:	pop    %r14
  81b5f7:	ret
  81b5f8:	mov    0x8(%rdx),%eax
  81b5fb:	mov    %eax,0x8(%rbx)
  81b5fe:	mov    (%rdx),%rax
  81b601:	mov    %rax,(%rbx)
  81b604:	add    $0x38,%rsp
  81b608:	pop    %rbx
  81b609:	pop    %r14
  81b60b:	ret
  81b60c:	lea    -0x746a71(%rip),%rdi        # d4ba2 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x12c>
  81b613:	lea    0x612fbe(%rip),%rdx        # e2e5d8 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.13987519659127932268+0x90>
  81b61a:	mov    $0x16,%esi
  81b61f:	call   *0x664a3b(%rip)        # e80060 <_DYNAMIC+0x5a0>

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081b630 <<gpui_gpu::renderer::Changes>::replace::<1>>:
  81b630:	cmp    %rdx,%rcx
  81b633:	jae    81b681 <<gpui_gpu::renderer::Changes>::replace::<1>+0x51>
  81b635:	mov    %rcx,%rax
  81b638:	shl    $0x4,%rax
  81b63c:	movdqu (%rsi,%rax,1),%xmm0
  81b641:	movdqu (%r8),%xmm1
  81b646:	pcmpeqb %xmm0,%xmm1
  81b64a:	pmovmskb %xmm1,%edx
  81b64e:	cmp    $0xffff,%edx
  81b654:	jne    81b657 <<gpui_gpu::renderer::Changes>::replace::<1>+0x27>
  81b656:	ret
  81b657:	add    %rax,%rsi
  81b65a:	mov    (%rdi),%rax
  81b65d:	mov    0x8(%rdi),%rdx
  81b661:	cmp    %rax,%rcx
  81b664:	cmovb  %rcx,%rax
  81b668:	inc    %rcx
  81b66b:	cmp    %rdx,%rcx
  81b66e:	cmovbe %rdx,%rcx
  81b672:	mov    %rax,(%rdi)
  81b675:	mov    %rcx,0x8(%rdi)
  81b679:	movups (%r8),%xmm0
  81b67d:	movups %xmm0,(%rsi)
  81b680:	ret
  81b681:	push   %rax
  81b682:	lea    0x1(%rcx),%rsi
  81b686:	lea    0x612ebb(%rip),%rax        # e2e548 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.13987519659127932268>
  81b68d:	mov    %rcx,%rdi
  81b690:	mov    %rax,%rcx
  81b693:	call   *0x66496f(%rip)        # e80008 <_DYNAMIC+0x548>

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081b6a0 <<gpui_gpu::renderer::Changes>::replace::<2>>:
  81b6a0:	mov    %rsi,%rax
  81b6a3:	lea    0x2(%rcx),%rsi
  81b6a7:	cmp    $0xfffffffffffffffd,%rcx
  81b6ab:	ja     81b74c <<gpui_gpu::renderer::Changes>::replace::<2>+0xac>
  81b6b1:	cmp    %rdx,%rsi
  81b6b4:	ja     81b74c <<gpui_gpu::renderer::Changes>::replace::<2>+0xac>
  81b6ba:	mov    %rcx,%r11
  81b6bd:	shl    $0x4,%r11
  81b6c1:	lea    (%rax,%r11,1),%rdx
  81b6c5:	mov    (%rdi),%r10
  81b6c8:	mov    0x8(%rdi),%r9
  81b6cc:	movdqu (%rax,%r11,1),%xmm0
  81b6d2:	movdqu (%r8),%xmm1
  81b6d7:	pcmpeqb %xmm0,%xmm1
  81b6db:	pmovmskb %xmm1,%eax
  81b6df:	cmp    $0xffff,%eax
  81b6e4:	je     81b708 <<gpui_gpu::renderer::Changes>::replace::<2>+0x68>
  81b6e6:	cmp    %r10,%rcx
  81b6e9:	cmovb  %rcx,%r10
  81b6ed:	lea    0x1(%rcx),%rax
  81b6f1:	cmp    %r9,%rax
  81b6f4:	cmova  %rax,%r9
  81b6f8:	mov    %r10,(%rdi)
  81b6fb:	mov    %r9,0x8(%rdi)
  81b6ff:	movdqu (%r8),%xmm0
  81b704:	movdqu %xmm0,(%rdx)
  81b708:	movdqu 0x10(%rdx),%xmm0
  81b70d:	movdqu 0x10(%r8),%xmm1
  81b713:	pcmpeqb %xmm0,%xmm1
  81b717:	pmovmskb %xmm1,%eax
  81b71b:	cmp    $0xffff,%eax
  81b720:	je     81b74b <<gpui_gpu::renderer::Changes>::replace::<2>+0xab>
  81b722:	add    $0x10,%rdx
  81b726:	add    $0x10,%r8
  81b72a:	inc    %rcx
  81b72d:	cmp    %r10,%rcx
  81b730:	cmovae %r10,%rcx
  81b734:	cmp    %r9,%rsi
  81b737:	cmova  %rsi,%r9
  81b73b:	mov    %rcx,(%rdi)
  81b73e:	mov    %r9,0x8(%rdi)
  81b742:	movdqu (%r8),%xmm0
  81b747:	movdqu %xmm0,(%rdx)
  81b74b:	ret
  81b74c:	push   %rax
  81b74d:	lea    0x612df4(%rip),%rax        # e2e548 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.13987519659127932268>
  81b754:	mov    %rcx,%rdi
  81b757:	mov    %rax,%rcx
  81b75a:	call   *0x6648a8(%rip)        # e80008 <_DYNAMIC+0x548>

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081ba50 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>:
  81ba50:	push   %r14
  81ba52:	push   %rbx
  81ba53:	push   %rax
  81ba54:	mov    %rdi,%rbx
  81ba57:	mov    (%rdi),%rax
  81ba5a:	lock decq (%rax)
  81ba5e:	jne    81ba69 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x19>
  81ba60:	mov    %rbx,%rdi
  81ba63:	call   *0x66453f(%rip)        # e7ffa8 <_DYNAMIC+0x4e8>
  81ba69:	mov    0x50(%rbx),%rax
  81ba6d:	lock decq (%rax)
  81ba71:	jne    81ba7d <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x2d>
  81ba73:	lea    0x50(%rbx),%rdi
  81ba77:	call   *0x664523(%rip)        # e7ffa0 <_DYNAMIC+0x4e0>
  81ba7d:	mov    0x58(%rbx),%rax
  81ba81:	lock decq (%rax)
  81ba85:	jne    81ba91 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x41>
  81ba87:	lea    0x58(%rbx),%rdi
  81ba8b:	call   *0x664517(%rip)        # e7ffa8 <_DYNAMIC+0x4e8>
  81ba91:	mov    0xb0(%rbx),%rsi
  81ba98:	test   %rsi,%rsi
  81ba9b:	je     81bacd <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  81ba9d:	mov    %rsi,%rax
  81baa0:	shl    $0x5,%rax
  81baa4:	add    %rax,%rsi
  81baa7:	add    $0x31,%rsi
  81baab:	je     81bacd <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  81baad:	mov    0xa8(%rbx),%rdi
  81bab4:	sub    %rax,%rdi
  81bab7:	add    $0xffffffffffffffe0,%rdi
  81babb:	mov    $0x10,%edx
  81bac0:	add    $0x8,%rsp
  81bac4:	pop    %rbx
  81bac5:	pop    %r14
  81bac7:	jmp    *0x66423b(%rip)        # e7fd08 <_DYNAMIC+0x248>
  81bacd:	add    $0x8,%rsp
  81bad1:	pop    %rbx
  81bad2:	pop    %r14
  81bad4:	ret
  81bad5:	mov    %rax,%r14
  81bad8:	jmp    81bb05 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  81bada:	mov    %rax,%r14
  81badd:	mov    0x58(%rbx),%rax
  81bae1:	lock decq (%rax)
  81bae5:	jne    81bb05 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  81bae7:	lea    0x58(%rbx),%rdi
  81baeb:	call   *0x6644b7(%rip)        # e7ffa8 <_DYNAMIC+0x4e8>
  81baf1:	jmp    81bb05 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  81baf3:	call   *0x664217(%rip)        # e7fd10 <_DYNAMIC+0x250>
  81baf9:	mov    %rax,%r14
  81bafc:	lea    0x50(%rbx),%rdi
  81bb00:	call   81c3a0 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  81bb05:	add    $0xa8,%rbx
  81bb0c:	mov    %rbx,%rdi
  81bb0f:	call   8230d0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>
  81bb14:	mov    %r14,%rdi
  81bb17:	call   e2c830 <_Unwind_Resume@plt>
  81bb1c:	call   *0x6641ee(%rip)        # e7fd10 <_DYNAMIC+0x250>

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081bb30 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>:
  81bb30:	push   %r14
  81bb32:	push   %rbx
  81bb33:	push   %rax
  81bb34:	mov    %rdi,%rbx
  81bb37:	mov    (%rdi),%rax
  81bb3a:	lock decq (%rax)
  81bb3e:	jne    81bb49 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x19>
  81bb40:	mov    %rbx,%rdi
  81bb43:	call   *0x66447f(%rip)        # e7ffc8 <_DYNAMIC+0x508>
  81bb49:	mov    0x8(%rbx),%rax
  81bb4d:	lock decq (%rax)
  81bb51:	jne    81bb67 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x37>
  81bb53:	add    $0x8,%rbx
  81bb57:	mov    %rbx,%rdi
  81bb5a:	add    $0x8,%rsp
  81bb5e:	pop    %rbx
  81bb5f:	pop    %r14
  81bb61:	jmp    *0x664469(%rip)        # e7ffd0 <_DYNAMIC+0x510>
  81bb67:	add    $0x8,%rsp
  81bb6b:	pop    %rbx
  81bb6c:	pop    %r14
  81bb6e:	ret
  81bb6f:	mov    %rax,%r14
  81bb72:	mov    0x8(%rbx),%rax
  81bb76:	lock decq (%rax)
  81bb7a:	jne    81bb89 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x59>
  81bb7c:	add    $0x8,%rbx
  81bb80:	mov    %rbx,%rdi
  81bb83:	call   *0x664447(%rip)        # e7ffd0 <_DYNAMIC+0x510>
  81bb89:	mov    %r14,%rdi
  81bb8c:	call   e2c830 <_Unwind_Resume@plt>
  81bb91:	call   *0x664179(%rip)        # e7fd10 <_DYNAMIC+0x250>

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081c4d0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>>:
  81c4d0:	push   %rbp
  81c4d1:	push   %r15
  81c4d3:	push   %r14
  81c4d5:	push   %r13
  81c4d7:	push   %r12
  81c4d9:	push   %rbx
  81c4da:	sub    $0x28,%rsp
  81c4de:	movss  0x8c(%rdi),%xmm3
  81c4e6:	movss  -0x76d4d2(%rip),%xmm0        # af01c <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  81c4ee:	movaps %xmm3,%xmm1
  81c4f1:	subss  %xmm0,%xmm1
  81c4f5:	cvttss2si %xmm1,%rax
  81c4fa:	cvttss2si %xmm3,%r8
  81c4ff:	mov    %r8,%rcx
  81c502:	sar    $0x3f,%rcx
  81c506:	and    %rax,%rcx
  81c509:	or     %r8,%rcx
  81c50c:	xor    %r9d,%r9d
  81c50f:	xorps  %xmm1,%xmm1
  81c512:	ucomiss %xmm1,%xmm3
  81c515:	cmovb  %r9,%rcx
  81c519:	movss  -0x76d501(%rip),%xmm2        # af020 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  81c521:	ucomiss %xmm2,%xmm3
  81c524:	mov    $0xffffffffffffffff,%rax
  81c52b:	cmova  %rax,%rcx
  81c52f:	movss  0x94(%rdi),%xmm3
  81c537:	mov    %rcx,%r8
  81c53a:	shr    $0x4,%r8
  81c53e:	movaps %xmm3,%xmm4
  81c541:	subss  %xmm0,%xmm4
  81c545:	cvttss2si %xmm4,%r10
  81c54a:	cvttss2si %xmm3,%r11
  81c54f:	mov    %r11,%rbx
  81c552:	sar    $0x3f,%rbx
  81c556:	and    %r10,%rbx
  81c559:	or     %r11,%rbx
  81c55c:	ucomiss %xmm1,%xmm3
  81c55f:	cmovb  %r9,%rbx
  81c563:	ucomiss %xmm2,%xmm3
  81c566:	cmova  %rax,%rbx
  81c56a:	mov    %rsi,0x18(%rsp)
  81c56f:	lea    (%rcx,%rbx,1),%r11
  81c573:	dec    %r11
  81c576:	shr    $0x4,%r11
  81c57a:	cmp    %r11,%r8
  81c57d:	jbe    81c58e <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xbe>
  81c57f:	add    $0x28,%rsp
  81c583:	pop    %rbx
  81c584:	pop    %r12
  81c586:	pop    %r13
  81c588:	pop    %r14
  81c58a:	pop    %r15
  81c58c:	pop    %rbp
  81c58d:	ret
  81c58e:	movss  0x88(%rdi),%xmm3
  81c596:	movaps %xmm3,%xmm4
  81c599:	subss  %xmm0,%xmm4
  81c59d:	cvttss2si %xmm4,%rsi
  81c5a2:	cvttss2si %xmm3,%r9
  81c5a7:	mov    %r9,%rcx
  81c5aa:	sar    $0x3f,%rcx
  81c5ae:	and    %rsi,%rcx
  81c5b1:	or     %r9,%rcx
  81c5b4:	xor    %r10d,%r10d
  81c5b7:	ucomiss %xmm1,%xmm3
  81c5ba:	cmovb  %r10,%rcx
  81c5be:	ucomiss %xmm2,%xmm3
  81c5c1:	cmova  %rax,%rcx
  81c5c5:	movss  0x90(%rdi),%xmm3
  81c5cd:	mov    %rcx,%r14
  81c5d0:	shr    $0x4,%r14
  81c5d4:	movaps %xmm3,%xmm4
  81c5d7:	subss  %xmm0,%xmm4
  81c5db:	cvttss2si %xmm4,%rsi
  81c5e0:	cvttss2si %xmm3,%rdi
  81c5e5:	mov    %rdi,%r9
  81c5e8:	sar    $0x3f,%r9
  81c5ec:	and    %rsi,%r9
  81c5ef:	or     %rdi,%r9
  81c5f2:	ucomiss %xmm1,%xmm3
  81c5f5:	cmovb  %r10,%r9
  81c5f9:	ucomiss %xmm2,%xmm3
  81c5fc:	cmova  %rax,%r9
  81c600:	lea    (%r9,%rcx,1),%rbx
  81c604:	dec    %rbx
  81c607:	shr    $0x4,%rbx
  81c60b:	mov    %r14,0x10(%rsp)
  81c610:	cmp    %rbx,%r14
  81c613:	jbe    81c63d <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x16d>
  81c615:	data16 cs nopw 0x0(%rax,%rax,1)
  81c620:	mov    %r8,%rax
  81c623:	cmp    %r11,%r8
  81c626:	adc    $0x0,%r8
  81c62a:	cmp    %r11,%rax
  81c62d:	jae    81c57f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c633:	cmp    %r11,%r8
  81c636:	jbe    81c620 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x150>
  81c638:	jmp    81c57f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c63d:	mov    (%rdx),%r14
  81c640:	mov    0x8(%rdx),%r15
  81c644:	mov    0x10(%rdx),%r12
  81c648:	mov    0x18(%rdx),%r13
  81c64c:	mov    0x20(%rdx),%rdx
  81c650:	mov    %r11,0x8(%rsp)
  81c655:	data16 cs nopw 0x0(%rax,%rax,1)
  81c660:	mov    %r8,%rbp
  81c663:	cmp    %r11,%r8
  81c666:	adc    $0x0,%r8
  81c66a:	mov    %rbp,0x20(%rsp)
  81c66f:	imul   0x18(%rsp),%rbp
  81c675:	mov    0x10(%rsp),%r9
  81c67a:	mov    %r9,%rsi
  81c67d:	nopl   (%rax)
  81c680:	cmp    %rbx,%r9
  81c683:	adc    $0x0,%rsi
  81c687:	lea    (%r9,%rbp,1),%rdi
  81c68b:	mov    0x10(%r14),%rax
  81c68f:	cmp    %rax,%rdi
  81c692:	jae    81c700 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x230>
  81c694:	mov    0x8(%r14),%rcx
  81c698:	cmp    0x4(%rcx,%rdi,8),%r10d
  81c69d:	jo     81c6d5 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x205>
  81c69f:	mov    0x10(%r12),%rax
  81c6a4:	cmp    %rax,%rdi
  81c6a7:	jae    81c710 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x240>
  81c6a9:	mov    0x8(%r12),%rax
  81c6ae:	mov    0x0(%r13),%r11d
  81c6b2:	inc    %r11d
  81c6b5:	cmp    (%rax,%rdi,4),%r11d
  81c6b9:	jb     81c6d5 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x205>
  81c6bb:	mov    (%rcx,%rdi,8),%eax
  81c6be:	dec    %eax
  81c6c0:	mov    %eax,(%rcx,%rdi,8)
  81c6c3:	mov    0x10(%r15),%rcx
  81c6c7:	cmp    %rax,%rcx
  81c6ca:	jbe    81c720 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x250>
  81c6cc:	mov    0x8(%r15),%rcx
  81c6d0:	mov    (%rdx),%edi
  81c6d2:	mov    %edi,(%rcx,%rax,4)
  81c6d5:	cmp    %rbx,%r9
  81c6d8:	jae    81c6e2 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x212>
  81c6da:	mov    %rsi,%r9
  81c6dd:	cmp    %rbx,%rsi
  81c6e0:	jbe    81c680 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x1b0>
  81c6e2:	mov    0x8(%rsp),%r11
  81c6e7:	cmp    %r11,0x20(%rsp)
  81c6ec:	jae    81c57f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c6f2:	cmp    %r11,%r8
  81c6f5:	jbe    81c660 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x190>
  81c6fb:	jmp    81c57f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c700:	lea    0x611ee9(%rip),%rdx        # e2e5f0 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.13987519659127932268+0xa8>
  81c707:	mov    %rax,%rsi
  81c70a:	call   *0x6638a8(%rip)        # e7ffb8 <_DYNAMIC+0x4f8>
  81c710:	lea    0x611ef1(%rip),%rdx        # e2e608 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.13987519659127932268+0xc0>
  81c717:	mov    %rax,%rsi
  81c71a:	call   *0x663898(%rip)        # e7ffb8 <_DYNAMIC+0x4f8>
  81c720:	lea    0x611ef9(%rip),%rdx        # e2e620 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.13987519659127932268+0xd8>
  81c727:	mov    %rax,%rdi
  81c72a:	mov    %rcx,%rsi
  81c72d:	call   *0x663885(%rip)        # e7ffb8 <_DYNAMIC+0x4f8>
{"address": 8479728, "code_bytes": 105, "mangled": "_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionINtNtCscdodAO9FK5_5alloc5boxed3BoxNtNtNtCshVcpkSEwkOU_8gpui_gpu8renderer6images6ImagesEEECsXOAeNtkFea_6groups", "name": "core[37f591cfbe66b0b1]::ptr::drop_glue::<core[37f591cfbe66b0b1]::option::Option<alloc[24b8200b0946867]::boxed::Box<gpui_gpu[d0c1626f4f4ed1e6]::renderer::images::Images>>>", "normalized_name": "core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>", "stack_bytes": 8}
{"address": 8481376, "code_bytes": 71, "mangled": "_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNCNvMNtNtCshVcpkSEwkOU_8gpui_gpu8renderer5ownedNtBI_8Renderer7request0ECsXOAeNtkFea_6groups", "name": "core[37f591cfbe66b0b1]::ptr::drop_glue::<<gpui_gpu[d0c1626f4f4ed1e6]::renderer::Renderer>::request::{closure#0}>", "normalized_name": "core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>", "stack_bytes": 8}
{"address": 8481456, "code_bytes": 540, "mangled": "_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNCNvMs4_NtCshVcpkSEwkOU_8gpui_gpu8rendererNtBJ_10GpuContext3new0ECsXOAeNtkFea_6groups", "name": "core[37f591cfbe66b0b1]::ptr::drop_glue::<<gpui_gpu[d0c1626f4f4ed1e6]::renderer::GpuContext>::new::{closure#0}>", "normalized_name": "core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>", "stack_bytes": 40}
{"address": 8482000, "code_bytes": 64, "mangled": "_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNCNvMs4_NtCshVcpkSEwkOU_8gpui_gpu8rendererNtBJ_10GpuContext7request0ECsXOAeNtkFea_6groups", "name": "core[37f591cfbe66b0b1]::ptr::drop_glue::<<gpui_gpu[d0c1626f4f4ed1e6]::renderer::GpuContext>::request::{closure#0}>", "normalized_name": "core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}>", "stack_bytes": 8}
{"address": 8483312, "code_bytes": 191, "mangled": "_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCshVcpkSEwkOU_8gpui_gpu8renderer10GpuContextECsXOAeNtkFea_6groups", "name": "core[37f591cfbe66b0b1]::ptr::drop_glue::<gpui_gpu[d0c1626f4f4ed1e6]::renderer::GpuContext>", "normalized_name": "core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>", "stack_bytes": 24}
{"address": 8483504, "code_bytes": 1253, "mangled": "_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCshVcpkSEwkOU_8gpui_gpu8renderer13RendererStateECsXOAeNtkFea_6groups", "name": "core[37f591cfbe66b0b1]::ptr::drop_glue::<gpui_gpu[d0c1626f4f4ed1e6]::renderer::RendererState>", "normalized_name": "core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>", "stack_bytes": 24}
{"address": 8484768, "code_bytes": 210, "mangled": "_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCshVcpkSEwkOU_8gpui_gpu8renderer5AtlasECsXOAeNtkFea_6groups", "name": "core[37f591cfbe66b0b1]::ptr::drop_glue::<gpui_gpu[d0c1626f4f4ed1e6]::renderer::Atlas>", "normalized_name": "core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>", "stack_bytes": 24}
{"address": 8484992, "code_bytes": 30, "mangled": "_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCshVcpkSEwkOU_8gpui_gpu8renderer5ErrorECsXOAeNtkFea_6groups", "name": "core[37f591cfbe66b0b1]::ptr::drop_glue::<gpui_gpu[d0c1626f4f4ed1e6]::renderer::Error>", "normalized_name": "core::ptr::drop_glue::<gpui_gpu::renderer::Error>", "stack_bytes": 0}
{"address": 8485024, "code_bytes": 103, "mangled": "_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCshVcpkSEwkOU_8gpui_gpu8renderer6BufferECsXOAeNtkFea_6groups", "name": "core[37f591cfbe66b0b1]::ptr::drop_glue::<gpui_gpu[d0c1626f4f4ed1e6]::renderer::Buffer>", "normalized_name": "core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>", "stack_bytes": 24}
{"address": 8487536, "code_bytes": 304, "mangled": "_RNvXs6_NtCshVcpkSEwkOU_8gpui_gpu8rendererNtB5_5ErrorNtNtCs4NRVxsYgnAr_4core3fmt5Debug3fmt", "name": "<gpui_gpu[d0c1626f4f4ed1e6]::renderer::Error as core[37f591cfbe66b0b1]::fmt::Debug>::fmt", "normalized_name": "<gpui_gpu::renderer::Error as core::fmt::Debug>::fmt", "stack_bytes": 24}
{"address": 8494064, "code_bytes": 47, "mangled": "_RNvXsg_NtCsgQfI1edjipl_9hashbrown3rawINtB5_8RawTableTNtNtCs11piCSwEYBC_11gpui_canvas4text8GlyphKeyNtNtCshVcpkSEwkOU_8gpui_gpu8renderer4TileEENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCsXOAeNtkFea_6groups", "name": "<hashbrown[c42db024a0c43d25]::raw::RawTable<(gpui_canvas[be9825febc5538e]::text::GlyphKey, gpui_gpu[d0c1626f4f4ed1e6]::renderer::Tile)> as core[37f591cfbe66b0b1]::ops::drop::Drop>::drop", "normalized_name": "<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop", "stack_bytes": 0}
{"address": 8494112, "code_bytes": 47, "mangled": "_RNvXsg_NtCsgQfI1edjipl_9hashbrown3rawINtB5_8RawTableTNtNtCs11piCSwEYBC_11gpui_canvas5image8ImageKeyNtNtNtCshVcpkSEwkOU_8gpui_gpu8renderer6images5EntryEENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCsXOAeNtkFea_6groups", "name": "<hashbrown[c42db024a0c43d25]::raw::RawTable<(gpui_canvas[be9825febc5538e]::image::ImageKey, gpui_gpu[d0c1626f4f4ed1e6]::renderer::images::Entry)> as core[37f591cfbe66b0b1]::ops::drop::Drop>::drop", "normalized_name": "<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop", "stack_bytes": 0}
{"address": 8500448, "code_bytes": 325, "mangled": "_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionNtNtCs11piCSwEYBC_11gpui_canvas6canvas9GlyphMaskE6map_orAmj3_NCINvMs5_NtCshVcpkSEwkOU_8gpui_gpu8rendererNtB1Q_13RendererState15render_observedNCNvB1M_6render0Es2_0EB1S_", "name": "<core[37f591cfbe66b0b1]::option::Option<gpui_canvas[be9825febc5538e]::canvas::GlyphMask>>::map_or::<[u32; 3: usize], <gpui_gpu[d0c1626f4f4ed1e6]::renderer::RendererState>::render_observed<<gpui_gpu[d0c1626f4f4ed1e6]::renderer::RendererState>::render::{closure#0}>::{closure#4}>", "normalized_name": "<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3: usize], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>", "stack_bytes": 72}
{"address": 8500784, "code_bytes": 105, "mangled": "_RINvMs0_NtCshVcpkSEwkOU_8gpui_gpu8rendererNtB6_7Changes7replaceKj1_EB8_", "name": "<gpui_gpu[d0c1626f4f4ed1e6]::renderer::Changes>::replace::<1: usize>", "normalized_name": "<gpui_gpu::renderer::Changes>::replace::<1: usize>", "stack_bytes": 8}
{"address": 8500896, "code_bytes": 192, "mangled": "_RINvMs0_NtCshVcpkSEwkOU_8gpui_gpu8rendererNtB6_7Changes7replaceKj2_EB8_", "name": "<gpui_gpu[d0c1626f4f4ed1e6]::renderer::Changes>::replace::<2: usize>", "normalized_name": "<gpui_gpu::renderer::Changes>::replace::<2: usize>", "stack_bytes": 8}
{"address": 8501840, "code_bytes": 210, "mangled": "_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCshVcpkSEwkOU_8gpui_gpu8renderer5AtlasEBF_", "name": "core[37f591cfbe66b0b1]::ptr::drop_glue::<gpui_gpu[d0c1626f4f4ed1e6]::renderer::Atlas>", "normalized_name": "core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>", "stack_bytes": 24}
{"address": 8502064, "code_bytes": 103, "mangled": "_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCshVcpkSEwkOU_8gpui_gpu8renderer6BufferEBF_", "name": "core[37f591cfbe66b0b1]::ptr::drop_glue::<gpui_gpu[d0c1626f4f4ed1e6]::renderer::Buffer>", "normalized_name": "core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>", "stack_bytes": 24}
{"address": 8504528, "code_bytes": 611, "mangled": "_RINvNtCshVcpkSEwkOU_8gpui_gpu8renderer5visitNCINvMs5_B2_NtB2_13RendererState15render_observedNCNvBL_6render0Es3_0EB4_", "name": "gpui_gpu[d0c1626f4f4ed1e6]::renderer::visit::<<gpui_gpu[d0c1626f4f4ed1e6]::renderer::RendererState>::render_observed<<gpui_gpu[d0c1626f4f4ed1e6]::renderer::RendererState>::render::{closure#0}>::{closure#5}>", "normalized_name": "gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>", "stack_bytes": 88}
{"address": 8505152, "code_bytes": 235, "mangled": "_RINvYNtNtCs11piCSwEYBC_11gpui_canvas6canvas6GroupsNtNtNtNtCs4NRVxsYgnAr_4core4iter6traits8iterator8Iterator4foldjNCINvNtNtBS_8adapters3map8map_foldNtB5_13PreparedGroupjjNCINvMs5_NtCshVcpkSEwkOU_8gpui_gpu8rendererNtB2Q_13RendererState15render_observedNCNvB2M_6render0Es0_0NCINvXsK_NtBQ_5accumjNtB4u_3Sum3sumINtB1S_3MapB3_B2H_EE0E0EB2S_", "name": "<gpui_canvas[be9825febc5538e]::canvas::Groups as core[37f591cfbe66b0b1]::iter::traits::iterator::Iterator>::fold::<usize, core[37f591cfbe66b0b1]::iter::adapters::map::map_fold<gpui_canvas[be9825febc5538e]::canvas::PreparedGroup, usize, usize, <gpui_gpu[d0c1626f4f4ed1e6]::renderer::RendererState>::render_observed<<gpui_gpu[d0c1626f4f4ed1e6]::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core[37f591cfbe66b0b1]::iter::traits::accum::Sum>::sum<core[37f591cfbe66b0b1]::iter::adapters::map::Map<gpui_canvas[be9825febc5538e]::canvas::Groups, <gpui_gpu[d0c1626f4f4ed1e6]::renderer::RendererState>::render_observed<<gpui_gpu[d0c1626f4f4ed1e6]::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>", "normalized_name": "<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>", "stack_bytes": 248}

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081c740 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>>:
  81c740:	push   %rbp
  81c741:	push   %r15
  81c743:	push   %r14
  81c745:	push   %r13
  81c747:	push   %r12
  81c749:	push   %rbx
  81c74a:	sub    $0xc8,%rsp
  81c751:	mov    %esi,%ebp
  81c753:	mov    %rdi,%rbx
  81c756:	lea    0x8(%rsp),%rdi
  81c75b:	mov    %rbx,%rsi
  81c75e:	call   *0x663914(%rip)        # e80078 <_DYNAMIC+0x5b8>
  81c764:	mov    0x8(%rsp),%rsi
  81c769:	xor    %r14d,%r14d
  81c76c:	test   $0x1,%bpl
  81c770:	je     81c7e8 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0xa8>
  81c772:	test   %rsi,%rsi
  81c775:	je     81c816 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0xd6>
  81c77b:	mov    $0x1,%r13d
  81c781:	lea    0x8(%rsp),%r12
  81c786:	mov    0x6638eb(%rip),%rbp        # e80078 <_DYNAMIC+0x5b8>
  81c78d:	jmp    81c7a5 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0x65>
  81c78f:	nop
  81c790:	add    %r15,%r14
  81c793:	mov    %r12,%rdi
  81c796:	mov    %rbx,%rsi
  81c799:	call   *%rbp
  81c79b:	mov    0x8(%rsp),%rsi
  81c7a0:	test   %rsi,%rsi
  81c7a3:	je     81c816 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0xd6>
  81c7a5:	mov    0x18(%rsp),%r15
  81c7aa:	cmp    $0x2,%r15
  81c7ae:	jb     81c790 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0x50>
  81c7b0:	mov    0x10(%rsp),%rax
  81c7b5:	mov    (%rax),%edx
  81c7b7:	lea    0x70(%rsp),%rdi
  81c7bc:	call   81c830 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81c7c1:	movss  0x74(%rsp),%xmm0
  81c7c7:	xorps  %xmm1,%xmm1
  81c7ca:	ucomiss %xmm1,%xmm0
  81c7cd:	mov    $0x1,%eax
  81c7d2:	cmovne %r15,%rax
  81c7d6:	cmovp  %r15,%rax
  81c7da:	cmpb   $0x3,0x70(%rsp)
  81c7df:	cmovne %r13,%rax
  81c7e3:	mov    %rax,%r15
  81c7e6:	jmp    81c790 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0x50>
  81c7e8:	test   %rsi,%rsi
  81c7eb:	je     81c816 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0xd6>
  81c7ed:	lea    0x8(%rsp),%r15
  81c7f2:	mov    0x66387f(%rip),%r12        # e80078 <_DYNAMIC+0x5b8>
  81c7f9:	nopl   0x0(%rax)
  81c800:	add    0x18(%rsp),%r14
  81c805:	mov    %r15,%rdi
  81c808:	mov    %rbx,%rsi
  81c80b:	call   *%r12
  81c80e:	cmpq   $0x0,0x8(%rsp)
  81c814:	jne    81c800 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0xc0>
  81c816:	mov    %r14,%rax
  81c819:	add    $0xc8,%rsp
  81c820:	pop    %rbx
  81c821:	pop    %r12
  81c823:	pop    %r13
  81c825:	pop    %r14
  81c827:	pop    %r15
  81c829:	pop    %rbp
  81c82a:	ret

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081ca70 <<gpui_gpu::renderer::Renderer>::set_grouped_records>:
  81ca70:	push   %rbp
  81ca71:	push   %r14
  81ca73:	push   %rbx
  81ca74:	cmp    0x341(%rdi),%sil
  81ca7b:	je     81cabb <<gpui_gpu::renderer::Renderer>::set_grouped_records+0x4b>
  81ca7d:	mov    0x330(%rdi),%rax
  81ca84:	test   %rax,%rax
  81ca87:	je     81caa9 <<gpui_gpu::renderer::Renderer>::set_grouped_records+0x39>
  81ca89:	lock decq (%rax)
  81ca8d:	jne    81caa9 <<gpui_gpu::renderer::Renderer>::set_grouped_records+0x39>
  81ca8f:	lea    0x330(%rdi),%rbx
  81ca96:	mov    %rdi,%r14
  81ca99:	mov    %rbx,%rdi
  81ca9c:	mov    %esi,%ebp
  81ca9e:	call   *0x663534(%rip)        # e7ffd8 <_DYNAMIC+0x518>
  81caa4:	mov    %r14,%rdi
  81caa7:	mov    %ebp,%esi
  81caa9:	movq   $0x0,0x330(%rdi)
  81cab4:	mov    %sil,0x341(%rdi)
  81cabb:	pop    %rbx
  81cabc:	pop    %r14
  81cabe:	pop    %rbp
  81cabf:	ret
  81cac0:	movq   $0x0,(%rbx)
  81cac7:	mov    %rax,%rdi
  81caca:	call   e2c830 <_Unwind_Resume@plt>

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081cad0 <<gpui_gpu::renderer::Changes>::upload>:
  81cad0:	push   %rbx
  81cad1:	mov    %rsi,%rbx
  81cad4:	sub    %rdi,%rbx
  81cad7:	jbe    81cb06 <<gpui_gpu::renderer::Changes>::upload+0x36>
  81cad9:	mov    %rdx,%rax
  81cadc:	mov    %rdi,%rdx
  81cadf:	cmp    %rcx,%rsi
  81cae2:	ja     81cb0d <<gpui_gpu::renderer::Changes>::upload+0x3d>
  81cae4:	shl    $0x4,%rdx
  81cae8:	add    %rdx,%rax
  81caeb:	shl    $0x4,%rbx
  81caef:	mov    %r9,%rdi
  81caf2:	mov    %r8,%rsi
  81caf5:	mov    %rax,%rcx
  81caf8:	mov    %rbx,%r8
  81cafb:	call   *0x66358f(%rip)        # e80090 <_DYNAMIC+0x5d0>
  81cb01:	mov    %rbx,%rax
  81cb04:	pop    %rbx
  81cb05:	ret
  81cb06:	xor    %ebx,%ebx
  81cb08:	mov    %rbx,%rax
  81cb0b:	pop    %rbx
  81cb0c:	ret
  81cb0d:	lea    0x611b6c(%rip),%rax        # e2e680 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.13987519659127932268+0x138>
  81cb14:	mov    %rdx,%rdi
  81cb17:	mov    %rcx,%rdx
  81cb1a:	mov    %rax,%rcx
  81cb1d:	call   *0x6634e5(%rip)        # e80008 <_DYNAMIC+0x548>

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081cb30 <<gpui_gpu::renderer::Buffer>::write>:
  81cb30:	push   %r15
  81cb32:	push   %r14
  81cb34:	push   %r12
  81cb36:	push   %rbx
  81cb37:	push   %rax
  81cb38:	mov    %r8,%r12
  81cb3b:	mov    %rcx,%rbx
  81cb3e:	mov    %rdx,%r14
  81cb41:	mov    %rdi,%r15
  81cb44:	mov    %r8,%rdx
  81cb47:	call   81cb80 <<gpui_gpu::renderer::Buffer>::reserve>
  81cb4c:	test   %r12,%r12
  81cb4f:	je     81cb70 <<gpui_gpu::renderer::Buffer>::write+0x40>
  81cb51:	mov    %r14,%rdi
  81cb54:	mov    %r15,%rsi
  81cb57:	xor    %edx,%edx
  81cb59:	mov    %rbx,%rcx
  81cb5c:	mov    %r12,%r8
  81cb5f:	add    $0x8,%rsp
  81cb63:	pop    %rbx
  81cb64:	pop    %r12
  81cb66:	pop    %r14
  81cb68:	pop    %r15
  81cb6a:	jmp    *0x663520(%rip)        # e80090 <_DYNAMIC+0x5d0>
  81cb70:	add    $0x8,%rsp
  81cb74:	pop    %rbx
  81cb75:	pop    %r12
  81cb77:	pop    %r14
  81cb79:	pop    %r15
  81cb7b:	ret

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081cb80 <<gpui_gpu::renderer::Buffer>::reserve>:
  81cb80:	push   %r15
  81cb82:	push   %r14
  81cb84:	push   %r12
  81cb86:	push   %rbx
  81cb87:	sub    $0x48,%rsp
  81cb8b:	mov    %rdx,%r14
  81cb8e:	mov    0x20(%rdi),%r15
  81cb92:	cmp    %r15,%rdx
  81cb95:	jbe    81cc3a <<gpui_gpu::renderer::Buffer>::reserve+0xba>
  81cb9b:	mov    %rdi,%rbx
  81cb9e:	mov    $0x1,%r12d
  81cba4:	cmp    $0x2,%r14
  81cba8:	jb     81cbc1 <<gpui_gpu::renderer::Buffer>::reserve+0x41>
  81cbaa:	lea    -0x1(%r14),%rax
  81cbae:	bsr    %rax,%rcx
  81cbb2:	not    %ecx
  81cbb4:	mov    $0xffffffffffffffff,%r12
  81cbbb:	shr    %cl,%r12
  81cbbe:	inc    %r12
  81cbc1:	lea    -0x748010(%rip),%rax        # d4bb8 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x142>
  81cbc8:	mov    %rax,0x28(%rsp)
  81cbcd:	movq   $0xa,0x30(%rsp)
  81cbd6:	mov    %r12,0x38(%rsp)
  81cbdb:	movl   $0x88,0x40(%rsp)
  81cbe3:	movb   $0x0,0x44(%rsp)
  81cbe8:	mov    %rsp,%rdi
  81cbeb:	lea    0x28(%rsp),%rdx
  81cbf0:	call   *0x6634ea(%rip)        # e800e0 <_DYNAMIC+0x620>
  81cbf6:	mov    %r12,0x20(%rsp)
  81cbfb:	mov    (%rbx),%rax
  81cbfe:	lock decq (%rax)
  81cc02:	jne    81cc0d <<gpui_gpu::renderer::Buffer>::reserve+0x8d>
  81cc04:	mov    %rbx,%rdi
  81cc07:	call   *0x6633bb(%rip)        # e7ffc8 <_DYNAMIC+0x508>
  81cc0d:	mov    0x8(%rbx),%rax
  81cc11:	lock decq (%rax)
  81cc15:	jne    81cc21 <<gpui_gpu::renderer::Buffer>::reserve+0xa1>
  81cc17:	lea    0x8(%rbx),%rdi
  81cc1b:	call   *0x6633af(%rip)        # e7ffd0 <_DYNAMIC+0x510>
  81cc21:	mov    0x20(%rsp),%rax
  81cc26:	mov    %rax,0x20(%rbx)
  81cc2a:	movups (%rsp),%xmm0
  81cc2e:	movups 0x10(%rsp),%xmm1
  81cc33:	movups %xmm1,0x10(%rbx)
  81cc37:	movups %xmm0,(%rbx)
  81cc3a:	cmp    %r15,%r14
  81cc3d:	seta   %al
  81cc40:	add    $0x48,%rsp
  81cc44:	pop    %rbx
  81cc45:	pop    %r12
  81cc47:	pop    %r14
  81cc49:	pop    %r15
  81cc4b:	ret
  81cc4c:	mov    %rax,%r14
  81cc4f:	jmp    81cc68 <<gpui_gpu::renderer::Buffer>::reserve+0xe8>
  81cc51:	mov    %rax,%r14
  81cc54:	mov    0x8(%rbx),%rax
  81cc58:	lock decq (%rax)
  81cc5c:	jne    81cc68 <<gpui_gpu::renderer::Buffer>::reserve+0xe8>
  81cc5e:	lea    0x8(%rbx),%rdi
  81cc62:	call   *0x663368(%rip)        # e7ffd0 <_DYNAMIC+0x510>
  81cc68:	mov    0x20(%rsp),%rax
  81cc6d:	mov    %rax,0x20(%rbx)
  81cc71:	movups (%rsp),%xmm0
  81cc75:	movups 0x10(%rsp),%xmm1
  81cc7a:	movups %xmm1,0x10(%rbx)
  81cc7e:	movups %xmm0,(%rbx)
  81cc81:	mov    %r14,%rdi
  81cc84:	call   e2c830 <_Unwind_Resume@plt>
  81cc89:	call   *0x663081(%rip)        # e7fd10 <_DYNAMIC+0x250>

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081cc90 <<gpui_gpu::renderer::Atlas>::new>:
  81cc90:	push   %rbp
  81cc91:	push   %r14
  81cc93:	push   %rbx
  81cc94:	sub    $0x160,%rsp
  81cc9b:	mov    %edx,%ebp
  81cc9d:	mov    %rdi,%rbx
  81cca0:	lea    -0x7480e5(%rip),%rax        # d4bc2 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x14c>
  81cca7:	mov    %rax,(%rsp)
  81ccab:	movq   $0xe,0x8(%rsp)
  81ccb4:	mov    %edx,0x10(%rsp)
  81ccb8:	mov    %edx,0x14(%rsp)
  81ccbc:	movaps -0x770753(%rip),%xmm0        # ac570 <anon.531a4b6c7f642b9eba5e0e986955623b.109.llvm.14547199655466482296+0x2c0>
  81ccc3:	movups %xmm0,0x18(%rsp)
  81ccc8:	movl   $0x0,0x28(%rsp)
  81ccd0:	movl   $0x6,0x34(%rsp)
  81ccd8:	movq   $0x4,0x38(%rsp)
  81cce1:	movq   $0x0,0x40(%rsp)
  81ccea:	lea    0x110(%rsp),%r14
  81ccf2:	mov    %rsp,%rdx
  81ccf5:	mov    %r14,%rdi
  81ccf8:	call   *0x663262(%rip)        # e7ff60 <_DYNAMIC+0x4a0>
  81ccfe:	movq   $0x0,0x18(%rsp)
  81cd07:	movl   $0xffffffff,0x30(%rsp)
  81cd0f:	movl   $0x0,(%rsp)
  81cd16:	movabs $0xffffffff00000000,%rax
  81cd20:	mov    %rax,0x28(%rsp)
  81cd25:	movq   $0x0,0x3c(%rsp)
  81cd2e:	movl   $0x0,0x8(%rsp)
  81cd36:	movl   $0x0,0x10(%rsp)
  81cd3e:	lea    0xb8(%rsp),%rdi
  81cd46:	mov    %rsp,%rdx
  81cd49:	mov    %r14,%rsi
  81cd4c:	call   *0x663216(%rip)        # e7ff68 <_DYNAMIC+0x4a8>
  81cd52:	movups 0x150(%rsp),%xmm0
  81cd5a:	movaps %xmm0,0xa0(%rsp)
  81cd62:	movups 0x110(%rsp),%xmm0
  81cd6a:	movups 0x120(%rsp),%xmm1
  81cd72:	movups 0x130(%rsp),%xmm2
  81cd7a:	movups 0x140(%rsp),%xmm3
  81cd82:	movaps %xmm3,0x90(%rsp)
  81cd8a:	movaps %xmm2,0x80(%rsp)
  81cd92:	movaps %xmm1,0x70(%rsp)
  81cd97:	movaps %xmm0,0x60(%rsp)
  81cd9c:	mov    0x108(%rsp),%rax
  81cda4:	mov    %rax,0x50(%rsp)
  81cda9:	movups 0xf8(%rsp),%xmm0
  81cdb1:	movaps %xmm0,0x40(%rsp)
  81cdb6:	movups 0xb8(%rsp),%xmm0
  81cdbe:	movups 0xc8(%rsp),%xmm1
  81cdc6:	movups 0xd8(%rsp),%xmm2
  81cdce:	movups 0xe8(%rsp),%xmm3
  81cdd6:	movaps %xmm3,0x30(%rsp)
  81cddb:	movaps %xmm2,0x20(%rsp)
  81cde0:	movaps %xmm1,0x10(%rsp)
  81cde5:	movaps %xmm0,(%rsp)
  81cde9:	mov    %fs:0x0,%rax
  81cdf2:	lea    -0x28(%rax),%rax
  81cdf9:	mov    %rax,%r14
  81cdfc:	cmpb   $0x1,0x10(%rax)
  81ce00:	jne    81ceeb <<gpui_gpu::renderer::Atlas>::new+0x25b>
  81ce06:	mov    (%r14),%rax
  81ce09:	mov    0x8(%r14),%rdx
  81ce0d:	lea    0x1(%rax),%rcx
  81ce11:	mov    %rcx,(%r14)
  81ce14:	movaps 0xa0(%rsp),%xmm0
  81ce1c:	movups %xmm0,0x40(%rbx)
  81ce20:	movaps 0x60(%rsp),%xmm0
  81ce25:	movaps 0x70(%rsp),%xmm1
  81ce2a:	movaps 0x80(%rsp),%xmm2
  81ce32:	movaps 0x90(%rsp),%xmm3
  81ce3a:	movups %xmm3,0x30(%rbx)
  81ce3e:	movups %xmm2,0x20(%rbx)
  81ce42:	movups %xmm1,0x10(%rbx)
  81ce46:	movups %xmm0,(%rbx)
  81ce49:	movups 0xb8(%rsp),%xmm0
  81ce51:	movups 0xc8(%rsp),%xmm1
  81ce59:	movups 0xd8(%rsp),%xmm2
  81ce61:	movups 0xe8(%rsp),%xmm3
  81ce69:	movups %xmm0,0x50(%rbx)
  81ce6d:	movups %xmm1,0x60(%rbx)
  81ce71:	movups %xmm2,0x70(%rbx)
  81ce75:	movups %xmm3,0x80(%rbx)
  81ce7c:	movups 0xf8(%rsp),%xmm0
  81ce84:	movups %xmm0,0x90(%rbx)
  81ce8b:	mov    0x108(%rsp),%rcx
  81ce93:	mov    %rcx,0xa0(%rbx)
  81ce9a:	mov    %ebp,0xd8(%rbx)
  81cea0:	movq   $0x0,0xdc(%rbx)
  81ceab:	movl   $0x0,0xe4(%rbx)
  81ceb5:	movups 0x61186c(%rip),%xmm0        # e2e728 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.13987519659127932268+0x1e0>
  81cebc:	movups %xmm0,0xa8(%rbx)
  81cec3:	movups 0x61186e(%rip),%xmm0        # e2e738 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.13987519659127932268+0x1f0>
  81ceca:	movups %xmm0,0xb8(%rbx)
  81ced1:	mov    %rax,0xc8(%rbx)
  81ced8:	mov    %rdx,0xd0(%rbx)
  81cedf:	add    $0x160,%rsp
  81cee6:	pop    %rbx
  81cee7:	pop    %r14
  81cee9:	pop    %rbp
  81ceea:	ret
  81ceeb:	call   *0x6631f7(%rip)        # e800e8 <_DYNAMIC+0x628>
  81cef1:	mov    %rax,(%r14)
  81cef4:	mov    %rdx,0x8(%r14)
  81cef8:	movb   $0x1,0x10(%r14)
  81cefd:	jmp    81ce0d <<gpui_gpu::renderer::Atlas>::new+0x17d>
  81cf02:	mov    %rax,%rbx
  81cf05:	mov    %rsp,%rdi
  81cf08:	call   81c3a0 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  81cf0d:	mov    0x60(%rsp),%rax
  81cf12:	lock decq (%rax)
  81cf16:	jne    81cf44 <<gpui_gpu::renderer::Atlas>::new+0x2b4>
  81cf18:	lea    0x60(%rsp),%rdi
  81cf1d:	call   *0x663085(%rip)        # e7ffa8 <_DYNAMIC+0x4e8>
  81cf23:	jmp    81cf44 <<gpui_gpu::renderer::Atlas>::new+0x2b4>
  81cf25:	mov    %rax,%rbx
  81cf28:	mov    0x110(%rsp),%rax
  81cf30:	lock decq (%rax)
  81cf34:	jne    81cf44 <<gpui_gpu::renderer::Atlas>::new+0x2b4>
  81cf36:	lea    0x110(%rsp),%rdi
  81cf3e:	call   *0x663064(%rip)        # e7ffa8 <_DYNAMIC+0x4e8>
  81cf44:	mov    %rbx,%rdi
  81cf47:	call   e2c830 <_Unwind_Resume@plt>
  81cf4c:	call   *0x662dbe(%rip)        # e7fd10 <_DYNAMIC+0x250>

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081cf60 <<gpui_gpu::renderer::Atlas>::insert>:
  81cf60:	push   %rbp
  81cf61:	push   %r15
  81cf63:	push   %r14
  81cf65:	push   %r13
  81cf67:	push   %r12
  81cf69:	push   %rbx
  81cf6a:	sub    $0x68,%rsp
  81cf6e:	mov    %rdx,%r12
  81cf71:	mov    %rsi,%r15
  81cf74:	mov    %rdi,%r14
  81cf77:	lea    0x10(%rdx),%r13
  81cf7b:	cmpq   $0x0,0xc0(%rdi)
  81cf83:	je     81d04b <<gpui_gpu::renderer::Atlas>::insert+0xeb>
  81cf89:	lea    0xc8(%r14),%rdi
  81cf90:	mov    %r13,%rsi
  81cf93:	call   824b60 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  81cf98:	mov    %rax,%rsi
  81cf9b:	shr    $0x39,%rsi
  81cf9f:	mov    0xa8(%r14),%rcx
  81cfa6:	mov    0xb0(%r14),%rdx
  81cfad:	movd   %esi,%xmm0
  81cfb1:	punpcklbw %xmm0,%xmm0
  81cfb5:	pshuflw $0x0,%xmm0,%xmm0
  81cfba:	pshufd $0x44,%xmm0,%xmm0
  81cfbf:	mov    0x10(%r12),%rsi
  81cfc4:	movzwl 0x1c(%r12),%edi
  81cfca:	mov    0x18(%r12),%r8d
  81cfcf:	pcmpeqd %xmm1,%xmm1
  81cfd3:	xor    %r9d,%r9d
  81cfd6:	and    %rdx,%rax
  81cfd9:	movdqu (%rcx,%rax,1),%xmm2
  81cfde:	movdqa %xmm2,%xmm3
  81cfe2:	pcmpeqb %xmm0,%xmm3
  81cfe6:	pmovmskb %xmm3,%r10d
  81cfeb:	test   %r10d,%r10d
  81cfee:	je     81d030 <<gpui_gpu::renderer::Atlas>::insert+0xd0>
  81cff0:	tzcnt  %r10d,%ebx
  81cff5:	add    %rax,%rbx
  81cff8:	and    %rdx,%rbx
  81cffb:	shl    $0x5,%rbx
  81cfff:	mov    %rcx,%r11
  81d002:	sub    %rbx,%r11
  81d005:	cmp    -0x20(%r11),%rsi
  81d009:	jne    81d01c <<gpui_gpu::renderer::Atlas>::insert+0xbc>
  81d00b:	cmp    -0x14(%r11),%di
  81d010:	jne    81d01c <<gpui_gpu::renderer::Atlas>::insert+0xbc>
  81d012:	cmp    -0x18(%r11),%r8d
  81d016:	je     81d0b3 <<gpui_gpu::renderer::Atlas>::insert+0x153>
  81d01c:	lea    -0x1(%r10),%r11d
  81d020:	and    %r10w,%r11w
  81d024:	mov    %r11d,%r10d
  81d027:	jne    81cff0 <<gpui_gpu::renderer::Atlas>::insert+0x90>
  81d029:	nopl   0x0(%rax)
  81d030:	pcmpeqb %xmm1,%xmm2
  81d034:	pmovmskb %xmm2,%r10d
  81d039:	test   %r10d,%r10d
  81d03c:	jne    81d04b <<gpui_gpu::renderer::Atlas>::insert+0xeb>
  81d03e:	add    %r9,%rax
  81d041:	add    $0x10,%rax
  81d045:	add    $0x10,%r9
  81d049:	jmp    81cfd6 <<gpui_gpu::renderer::Atlas>::insert+0x76>
  81d04b:	mov    0x20(%r12),%ebp
  81d050:	xor    %eax,%eax
  81d052:	test   %ebp,%ebp
  81d054:	je     81d0ae <<gpui_gpu::renderer::Atlas>::insert+0x14e>
  81d056:	mov    %r15,%rdi
  81d059:	mov    0x28(%r12),%r15d
  81d05e:	test   %r15d,%r15d
  81d061:	je     81d0ae <<gpui_gpu::renderer::Atlas>::insert+0x14e>
  81d063:	mov    0xd8(%r14),%ecx
  81d06a:	cmp    %ebp,%ecx
  81d06c:	jb     81d1b1 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81d072:	cmp    %r15d,%ecx
  81d075:	jb     81d1b1 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81d07b:	mov    %r13,0x40(%rsp)
  81d080:	mov    0xdc(%r14),%r8d
  81d087:	mov    0xe4(%r14),%r13d
  81d08e:	lea    (%r8,%rbp,1),%edx
  81d092:	xor    %eax,%eax
  81d094:	cmp    %ecx,%edx
  81d096:	mov    $0x0,%ebx
  81d09b:	cmova  %r13d,%ebx
  81d09f:	add    0xe0(%r14),%ebx
  81d0a6:	lea    (%rbx,%r15,1),%esi
  81d0aa:	cmp    %ecx,%esi
  81d0ac:	jbe    81d0bf <<gpui_gpu::renderer::Atlas>::insert+0x15f>
  81d0ae:	jmp    81d1b1 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81d0b3:	mov    $0x1,%eax
  81d0b8:	xor    %edx,%edx
  81d0ba:	jmp    81d1b1 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81d0bf:	cmp    %r13d,%r15d
  81d0c2:	cmova  %r15d,%r13d
  81d0c6:	cmp    %ecx,%edx
  81d0c8:	cmova  %eax,%r8d
  81d0cc:	lea    0xa8(%r14),%rax
  81d0d3:	mov    %rax,0x38(%rsp)
  81d0d8:	mov    %r14,0x48(%rsp)
  81d0dd:	movl   $0x0,0x50(%rsp)
  81d0e5:	mov    %r8d,0x54(%rsp)
  81d0ea:	mov    %ebx,0x58(%rsp)
  81d0ee:	movq   $0x0,0x5c(%rsp)
  81d0f7:	mov    (%r12),%rdx
  81d0fb:	mov    0x8(%r12),%rcx
  81d100:	mov    %rcx,0x30(%rsp)
  81d105:	movq   $0x0,0x8(%rsp)
  81d10e:	movl   $0x1,0x10(%rsp)
  81d116:	mov    %ebp,0x14(%rsp)
  81d11a:	movl   $0x1,0x18(%rsp)
  81d122:	mov    %r15d,0x1c(%rsp)
  81d127:	mov    %ebp,0x20(%rsp)
  81d12b:	mov    %r15d,0x24(%rsp)
  81d130:	movl   $0x1,0x28(%rsp)
  81d138:	cmova  %r15d,%r13d
  81d13c:	lea    0x48(%rsp),%rsi
  81d141:	mov    %r8,%r12
  81d144:	lea    0x8(%rsp),%r8
  81d149:	lea    0x20(%rsp),%r9
  81d14e:	call   *0x662f9c(%rip)        # e800f0 <_DYNAMIC+0x630>
  81d154:	lea    (%r12,%rbp,1),%eax
  81d158:	mov    %eax,0xdc(%r14)
  81d15f:	mov    %ebx,0xe0(%r14)
  81d166:	mov    %r13d,0xe4(%r14)
  81d16d:	mov    0x40(%rsp),%rax
  81d172:	movdqu (%rax),%xmm0
  81d176:	movdqa %xmm0,0x20(%rsp)
  81d17c:	mov    %r12d,0x8(%rsp)
  81d181:	mov    %ebx,0xc(%rsp)
  81d185:	mov    %ebp,0x10(%rsp)
  81d189:	mov    %r15d,0x14(%rsp)
  81d18e:	lea    0x48(%rsp),%rdi
  81d193:	lea    0x20(%rsp),%rdx
  81d198:	lea    0x8(%rsp),%rcx
  81d19d:	mov    0x38(%rsp),%rsi
  81d1a2:	call   825490 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert>
  81d1a7:	mov    0x30(%rsp),%rdx
  81d1ac:	mov    $0x1,%eax
  81d1b1:	add    $0x68,%rsp
  81d1b5:	pop    %rbx
  81d1b6:	pop    %r12
  81d1b8:	pop    %r13
  81d1ba:	pop    %r14
  81d1bc:	pop    %r15
  81d1be:	pop    %rbp
  81d1bf:	ret

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081d1c0 <<gpui_gpu::renderer::GpuContext>::submit>:
  81d1c0:	push   %r15
  81d1c2:	push   %r14
  81d1c4:	push   %r12
  81d1c6:	push   %rbx
  81d1c7:	sub    $0x548,%rsp
  81d1ce:	mov    %rdx,%r14
  81d1d1:	mov    %rsi,%r12
  81d1d4:	mov    %rdi,%rbx
  81d1d7:	lea    0x61156a(%rip),%rdx        # e2e748 <anon.36d49f465d299f05a84fba3771e6457e.32.llvm.13987519659127932268>
  81d1de:	lea    0x30(%rsp),%r15
  81d1e3:	mov    %r15,%rdi
  81d1e6:	mov    %rbx,%rsi
  81d1e9:	call   *0x662f09(%rip)        # e800f8 <_DYNAMIC+0x638>
  81d1ef:	xorps  %xmm0,%xmm0
  81d1f2:	movups %xmm0,0x10(%rsp)
  81d1f7:	movups %xmm0,0x20(%rsp)
  81d1fc:	movl   $0x0,0x50(%rsp)
  81d204:	movb   $0x0,0x58(%rsp)
  81d209:	movups 0x9(%rsp),%xmm0
  81d20e:	movups %xmm0,0x59(%rsp)
  81d213:	movups 0x19(%rsp),%xmm0
  81d218:	movups %xmm0,0x69(%rsp)
  81d21d:	mov    0x28(%rsp),%rax
  81d222:	mov    %rax,0x78(%rsp)
  81d227:	movl   $0x0,0x80(%rsp)
  81d232:	mov    %r12,0x88(%rsp)
  81d23a:	movq   $0x0,0x90(%rsp)
  81d246:	lea    -0x74867d(%rip),%rax        # d4bd0 <anon.36d49f465d299f05a84fba3771e6457e.31.llvm.13987519659127932268>
  81d24d:	mov    %rax,0xe0(%rsp)
  81d255:	movq   $0xa,0xe8(%rsp)
  81d261:	lea    0x50(%rsp),%rax
  81d266:	mov    %rax,0xd0(%rsp)
  81d26e:	movq   $0x1,0xd8(%rsp)
  81d27a:	movl   $0xffffffff,0xb8(%rsp)
  81d285:	movl   $0x2,0x98(%rsp)
  81d290:	movq   $0x0,0xf0(%rsp)
  81d29c:	movl   $0x0,0xf8(%rsp)
  81d2a7:	lea    0x100(%rsp),%rdi
  81d2af:	lea    0x98(%rsp),%rdx
  81d2b7:	mov    %r15,%rsi
  81d2ba:	call   *0x662e40(%rip)        # e80100 <_DYNAMIC+0x640>
  81d2c0:	lea    0x10(%rbx),%rsi
  81d2c4:	lea    0x100(%rsp),%rdi
  81d2cc:	call   *0x662e36(%rip)        # e80108 <_DYNAMIC+0x648>
  81d2d2:	lea    0x100(%rsp),%rdi
  81d2da:	mov    $0x4,%ecx
  81d2df:	xor    %esi,%esi
  81d2e1:	mov    %r14,%rdx
  81d2e4:	xor    %r8d,%r8d
  81d2e7:	call   *0x662e23(%rip)        # e80110 <_DYNAMIC+0x650>
  81d2ed:	lea    0x100(%rsp),%rdi
  81d2f5:	xor    %esi,%esi
  81d2f7:	mov    $0x3,%edx
  81d2fc:	xor    %ecx,%ecx
  81d2fe:	mov    $0x1,%r8d
  81d304:	call   *0x662e0e(%rip)        # e80118 <_DYNAMIC+0x658>
  81d30a:	lea    0x100(%rsp),%rdi
  81d312:	call   81c2a0 <core::ptr::drop_glue::<wgpu::api::render_pass::RenderPass>>
  81d317:	movups 0x30(%rsp),%xmm0
  81d31c:	movups 0x40(%rsp),%xmm1
  81d321:	movaps %xmm1,0x110(%rsp)
  81d329:	movaps %xmm0,0x100(%rsp)
  81d331:	lea    0x98(%rsp),%r14
  81d339:	lea    0x100(%rsp),%rsi
  81d341:	mov    %r14,%rdi
  81d344:	call   *0x662dd6(%rip)        # e80120 <_DYNAMIC+0x660>
  81d34a:	add    $0x8,%rbx
  81d34e:	mov    %rbx,%rdi
  81d351:	mov    %r14,%rsi
  81d354:	call   825040 <<wgpu::api::queue::Queue>::submit::<[wgpu::api::command_buffer::CommandBuffer; 1]>>
  81d359:	add    $0x548,%rsp
  81d360:	pop    %rbx
  81d361:	pop    %r12
  81d363:	pop    %r14
  81d365:	pop    %r15
  81d367:	ret
  81d368:	mov    %rax,%rbx
  81d36b:	jmp    81d37d <<gpui_gpu::renderer::GpuContext>::submit+0x1bd>
  81d36d:	mov    %rax,%rbx
  81d370:	lea    0x100(%rsp),%rdi
  81d378:	call   81c2a0 <core::ptr::drop_glue::<wgpu::api::render_pass::RenderPass>>
  81d37d:	lea    0x30(%rsp),%rdi
  81d382:	call   81c410 <core::ptr::drop_glue::<wgpu::api::command_encoder::CommandEncoder>>
  81d387:	mov    %rbx,%rdi
  81d38a:	call   e2c830 <_Unwind_Resume@plt>
  81d38f:	call   *0x66297b(%rip)        # e7fd10 <_DYNAMIC+0x250>

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081d3a0 <<gpui_gpu::renderer::RendererState>::correction>:
  81d3a0:	push   %r15
  81d3a2:	push   %r14
  81d3a4:	push   %r13
  81d3a6:	push   %r12
  81d3a8:	push   %rbx
  81d3a9:	sub    $0x90,%rsp
  81d3b0:	mov    %rdi,%rbx
  81d3b3:	movss  (%rdx),%xmm1
  81d3b7:	movss  0x8(%rdx),%xmm2
  81d3bc:	movaps %xmm1,%xmm0
  81d3bf:	addss  %xmm2,%xmm0
  81d3c3:	movd   %xmm0,%eax
  81d3c7:	and    $0x7fffffff,%eax
  81d3cc:	xorps  %xmm8,%xmm8
  81d3d0:	xorps  %xmm9,%xmm9
  81d3d4:	cmp    $0x7f7fffff,%eax
  81d3d9:	jg     81d3f8 <<gpui_gpu::renderer::RendererState>::correction+0x58>
  81d3db:	cvtss2sd %xmm1,%xmm1
  81d3df:	cvtss2sd %xmm2,%xmm2
  81d3e3:	cvtss2sd %xmm0,%xmm0
  81d3e7:	addsd  %xmm1,%xmm2
  81d3eb:	subsd  %xmm0,%xmm2
  81d3ef:	xorps  %xmm9,%xmm9
  81d3f3:	cvtsd2ss %xmm2,%xmm9
  81d3f8:	movupd (%rsi),%xmm0
  81d3fc:	movupd 0x8(%rsi),%xmm1
  81d401:	movsd  0x10(%rsi),%xmm2
  81d406:	movsd  0x18(%rsi),%xmm3
  81d40b:	movupd 0x20(%rsi),%xmm4
  81d410:	movss  0x4(%rdx),%xmm6
  81d415:	movss  0xc(%rdx),%xmm7
  81d41a:	movaps %xmm6,%xmm5
  81d41d:	addss  %xmm7,%xmm5
  81d421:	movd   %xmm5,%eax
  81d425:	and    $0x7fffffff,%eax
  81d42a:	cmp    $0x7f7fffff,%eax
  81d42f:	jg     81d44e <<gpui_gpu::renderer::RendererState>::correction+0xae>
  81d431:	cvtss2sd %xmm6,%xmm6
  81d435:	cvtss2sd %xmm7,%xmm7
  81d439:	cvtss2sd %xmm5,%xmm5
  81d43d:	addsd  %xmm6,%xmm7
  81d441:	subsd  %xmm5,%xmm7
  81d445:	xorps  %xmm8,%xmm8
  81d449:	cvtsd2ss %xmm7,%xmm8
  81d44e:	cvtpd2ps %xmm4,%xmm5
  81d452:	cvtps2pd %xmm5,%xmm5
  81d455:	subpd  %xmm5,%xmm4
  81d459:	cvtpd2ps %xmm4,%xmm4
  81d45d:	unpcklpd %xmm3,%xmm1
  81d461:	cvtpd2ps %xmm1,%xmm3
  81d465:	unpcklpd %xmm2,%xmm0
  81d469:	cvtpd2ps %xmm0,%xmm2
  81d46d:	cvtps2pd %xmm3,%xmm3
  81d470:	subpd  %xmm3,%xmm1
  81d474:	cvtpd2ps %xmm1,%xmm5
  81d478:	cvtps2pd %xmm2,%xmm1
  81d47b:	subpd  %xmm1,%xmm0
  81d47f:	cvtpd2ps %xmm0,%xmm6
  81d483:	movapd %xmm6,%xmm0
  81d487:	unpcklps %xmm5,%xmm0
  81d48a:	movaps %xmm8,%xmm1
  81d48e:	movlhps %xmm9,%xmm1
  81d492:	movapd %xmm4,%xmm2
  81d496:	shufps $0x24,%xmm1,%xmm2
  81d49a:	xorps  %xmm1,%xmm1
  81d49d:	movapd %xmm0,%xmm3
  81d4a1:	cmpneqps %xmm1,%xmm3
  81d4a5:	cmpneqps %xmm1,%xmm2
  81d4a9:	packssdw %xmm2,%xmm3
  81d4ad:	pmovmskb %xmm3,%eax
  81d4b1:	test   %eax,%eax
  81d4b3:	je     81d5d7 <<gpui_gpu::renderer::RendererState>::correction+0x237>
  81d4b9:	movapd %xmm6,0x60(%rsp)
  81d4bf:	movapd %xmm5,0x70(%rsp)
  81d4c5:	lea    0x8(%rsp),%r12
  81d4ca:	movapd %xmm0,(%rsp)
  81d4cf:	movapd %xmm4,0x80(%rsp)
  81d4d8:	movlpd %xmm4,0x10(%rsp)
  81d4de:	movss  %xmm9,0x18(%rsp)
  81d4e5:	movss  %xmm8,0x1c(%rsp)
  81d4ec:	lea    0x318(%rbx),%r14
  81d4f3:	mov    %rsp,%rsi
  81d4f6:	mov    %r14,%rdi
  81d4f9:	movaps %xmm8,0x30(%rsp)
  81d4ff:	movaps %xmm9,0x20(%rsp)
  81d505:	call   8249e0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&[u32; 8]>>
  81d50a:	movapd 0x20(%rsp),%xmm6
  81d510:	movapd 0x30(%rsp),%xmm5
  81d516:	mov    %rax,%r15
  81d519:	shr    $0x39,%r15
  81d51d:	mov    0x2f8(%rbx),%rcx
  81d524:	mov    0x300(%rbx),%rdx
  81d52b:	movd   %r15d,%xmm0
  81d530:	punpcklbw %xmm0,%xmm0
  81d534:	pshuflw $0x0,%xmm0,%xmm0
  81d539:	pshufd $0x44,%xmm0,%xmm0
  81d53e:	xor    %esi,%esi
  81d540:	pcmpeqd %xmm1,%xmm1
  81d544:	mov    %rax,%rdi
  81d547:	and    %rdx,%rdi
  81d54a:	movdqu (%rcx,%rdi,1),%xmm2
  81d54f:	movdqa %xmm2,%xmm3
  81d553:	pcmpeqb %xmm0,%xmm3
  81d557:	pmovmskb %xmm3,%r8d
  81d55c:	test   %r8d,%r8d
  81d55f:	je     81d5b0 <<gpui_gpu::renderer::RendererState>::correction+0x210>
  81d561:	tzcnt  %r8d,%r9d
  81d566:	add    %rdi,%r9
  81d569:	and    %rdx,%r9
  81d56c:	neg    %r9
  81d56f:	lea    (%r9,%r9,8),%r9
  81d573:	movdqu -0x24(%rcx,%r9,4),%xmm3
  81d57a:	movdqu -0x14(%rcx,%r9,4),%xmm4
  81d581:	pcmpeqb 0x10(%rsp),%xmm4
  81d587:	pcmpeqb (%rsp),%xmm3
  81d58c:	pand   %xmm4,%xmm3
  81d590:	pmovmskb %xmm3,%r10d
  81d595:	cmp    $0xffff,%r10d
  81d59c:	je     81d5ce <<gpui_gpu::renderer::RendererState>::correction+0x22e>
  81d59e:	lea    -0x1(%r8),%r9d
  81d5a2:	and    %r8w,%r9w
  81d5a6:	mov    %r9d,%r8d
  81d5a9:	jne    81d561 <<gpui_gpu::renderer::RendererState>::correction+0x1c1>
  81d5ab:	nopl   0x0(%rax,%rax,1)
  81d5b0:	pcmpeqb %xmm1,%xmm2
  81d5b4:	pmovmskb %xmm2,%r8d
  81d5b9:	test   %r8d,%r8d
  81d5bc:	jne    81d5de <<gpui_gpu::renderer::RendererState>::correction+0x23e>
  81d5be:	add    %rsi,%rdi
  81d5c1:	add    $0x10,%rdi
  81d5c5:	add    $0x10,%rsi
  81d5c9:	jmp    81d547 <<gpui_gpu::renderer::RendererState>::correction+0x1a7>
  81d5ce:	lea    (%rcx,%r9,4),%rdx
  81d5d2:	jmp    81d6f9 <<gpui_gpu::renderer::RendererState>::correction+0x359>
  81d5d7:	xor    %eax,%eax
  81d5d9:	jmp    81d6fc <<gpui_gpu::renderer::RendererState>::correction+0x35c>
  81d5de:	cmpq   $0x0,0x308(%rbx)
  81d5e6:	je     81d72f <<gpui_gpu::renderer::RendererState>::correction+0x38f>
  81d5ec:	mov    (%rsp),%r14
  81d5f0:	mov    0x10(%r12),%rcx
  81d5f5:	mov    %rcx,0x50(%rsp)
  81d5fa:	movups (%r12),%xmm0
  81d5ff:	movaps %xmm0,0x40(%rsp)
  81d604:	mov    0x70(%rbx),%r12
  81d608:	cmp    0x60(%rbx),%r12
  81d60c:	jne    81d62a <<gpui_gpu::renderer::RendererState>::correction+0x28a>
  81d60e:	lea    0x60(%rbx),%rdi
  81d612:	mov    %rax,%r13
  81d615:	call   *0x662a55(%rip)        # e80070 <_DYNAMIC+0x5b0>
  81d61b:	movapd 0x20(%rsp),%xmm6
  81d621:	movapd 0x30(%rsp),%xmm5
  81d627:	mov    %r13,%rax
  81d62a:	mov    0x68(%rbx),%rcx
  81d62e:	mov    %r12,%rdx
  81d631:	shl    $0x5,%rdx
  81d635:	movaps 0x60(%rsp),%xmm0
  81d63a:	movlps %xmm0,(%rcx,%rdx,1)
  81d63e:	movaps 0x80(%rsp),%xmm0
  81d646:	movss  %xmm0,0x8(%rcx,%rdx,1)
  81d64c:	movss  %xmm6,0xc(%rcx,%rdx,1)
  81d652:	movdqa 0x70(%rsp),%xmm1
  81d658:	movq   %xmm1,0x10(%rcx,%rdx,1)
  81d65e:	shufps $0x55,%xmm0,%xmm0
  81d662:	movss  %xmm0,0x18(%rcx,%rdx,1)
  81d668:	movss  %xmm5,0x1c(%rcx,%rdx,1)
  81d66e:	lea    0x1(%r12),%rcx
  81d673:	mov    %rcx,0x70(%rbx)
  81d677:	mov    0x2f8(%rbx),%rcx
  81d67e:	mov    0x300(%rbx),%rdx
  81d685:	and    %rdx,%rax
  81d688:	movdqu (%rcx,%rax,1),%xmm0
  81d68d:	pmovmskb %xmm0,%esi
  81d691:	test   %esi,%esi
  81d693:	je     81d70d <<gpui_gpu::renderer::RendererState>::correction+0x36d>
  81d695:	tzcnt  %esi,%esi
  81d699:	add    %rax,%rsi
  81d69c:	and    %rdx,%rsi
  81d69f:	movzbl (%rcx,%rsi,1),%eax
  81d6a3:	test   %al,%al
  81d6a5:	jns    81d760 <<gpui_gpu::renderer::RendererState>::correction+0x3c0>
  81d6ab:	lea    -0x10(%rsi),%rdi
  81d6af:	and    %rdx,%rdi
  81d6b2:	mov    %r15b,(%rcx,%rsi,1)
  81d6b6:	mov    %r15b,0x10(%rcx,%rdi,1)
  81d6bb:	neg    %rsi
  81d6be:	lea    (%rsi,%rsi,8),%rsi
  81d6c2:	lea    (%rcx,%rsi,4),%rdx
  81d6c6:	and    $0x1,%al
  81d6c8:	movzbl %al,%eax
  81d6cb:	sub    %rax,0x308(%rbx)
  81d6d2:	mov    %r14,-0x24(%rcx,%rsi,4)
  81d6d7:	movdqa 0x40(%rsp),%xmm0
  81d6dd:	movdqu %xmm0,-0x1c(%rcx,%rsi,4)
  81d6e3:	mov    0x50(%rsp),%rax
  81d6e8:	mov    %rax,-0xc(%rcx,%rsi,4)
  81d6ed:	mov    %r12d,-0x4(%rcx,%rsi,4)
  81d6f2:	incq   0x310(%rbx)
  81d6f9:	mov    -0x4(%rdx),%eax
  81d6fc:	add    $0x90,%rsp
  81d703:	pop    %rbx
  81d704:	pop    %r12
  81d706:	pop    %r13
  81d708:	pop    %r14
  81d70a:	pop    %r15
  81d70c:	ret
  81d70d:	mov    $0x10,%edi
  81d712:	add    %rdi,%rax
  81d715:	and    %rdx,%rax
  81d718:	movdqu (%rcx,%rax,1),%xmm0
  81d71d:	pmovmskb %xmm0,%esi
  81d721:	add    $0x10,%rdi
  81d725:	test   %esi,%esi
  81d727:	jne    81d695 <<gpui_gpu::renderer::RendererState>::correction+0x2f5>
  81d72d:	jmp    81d712 <<gpui_gpu::renderer::RendererState>::correction+0x372>
  81d72f:	lea    0x2f8(%rbx),%rdi
  81d736:	mov    $0x1,%esi
  81d73b:	mov    %r14,%rdx
  81d73e:	mov    $0x1,%ecx
  81d743:	mov    %rax,%r14
  81d746:	call   *0x6629dc(%rip)        # e80128 <_DYNAMIC+0x668>
  81d74c:	movapd 0x20(%rsp),%xmm6
  81d752:	movapd 0x30(%rsp),%xmm5
  81d758:	mov    %r14,%rax
  81d75b:	jmp    81d5ec <<gpui_gpu::renderer::RendererState>::correction+0x24c>
  81d760:	movdqa (%rcx),%xmm0
  81d764:	pmovmskb %xmm0,%eax
  81d768:	tzcnt  %eax,%esi
  81d76c:	movzbl (%rcx,%rsi,1),%eax
  81d770:	jmp    81d6ab <<gpui_gpu::renderer::RendererState>::correction+0x30b>

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081d780 <<gpui_gpu::renderer::RendererState>::prepare_atlas>:
  81d780:	push   %rbp
  81d781:	push   %r15
  81d783:	push   %r14
  81d785:	push   %r13
  81d787:	push   %r12
  81d789:	push   %rbx
  81d78a:	sub    $0x228,%rsp
  81d791:	mov    %rsi,%r14
  81d794:	test   %r8d,%r8d
  81d797:	je     81d82b <<gpui_gpu::renderer::RendererState>::prepare_atlas+0xab>
  81d79d:	mov    %rdi,0x10(%rsp)
  81d7a2:	mov    0x110(%rcx),%rbp
  81d7a9:	test   %rbp,%rbp
  81d7ac:	je     81d88f <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x10f>
  81d7b2:	mov    0x108(%rcx),%r13
  81d7b9:	shl    $0x3,%rbp
  81d7bd:	mov    %r14,0x8(%rsp)
  81d7c2:	lea    0x78(%r14),%rdi
  81d7c6:	mov    %rdx,0x18(%rsp)
  81d7cb:	lea    0x8(%rdx),%rax
  81d7cf:	mov    %rax,0x20(%rsp)
  81d7d4:	xor    %ebx,%ebx
  81d7d6:	lea    0x28(%rsp),%r15
  81d7db:	xor    %r12d,%r12d
  81d7de:	xchg   %ax,%ax
  81d7e0:	mov    0x0(%r13,%r12,1),%rax
  81d7e5:	movups 0x28(%rax),%xmm0
  81d7e9:	lea    0x38(%rsp),%rcx
  81d7ee:	movups %xmm0,(%rcx)
  81d7f1:	movups 0x18(%rax),%xmm0
  81d7f5:	movups %xmm0,0x28(%rsp)
  81d7fa:	movups 0x38(%rax),%xmm0
  81d7fe:	movups %xmm0,0x48(%rsp)
  81d803:	mov    %rdi,%r14
  81d806:	mov    0x20(%rsp),%rsi
  81d80b:	mov    %r15,%rdx
  81d80e:	call   81cf60 <<gpui_gpu::renderer::Atlas>::insert>
  81d813:	test   $0x1,%al
  81d815:	je     81d896 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x116>
  81d817:	add    %rdx,%rbx
  81d81a:	add    $0x8,%r12
  81d81e:	cmp    %r12,%rbp
  81d821:	mov    %r14,%rdi
  81d824:	jne    81d7e0 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x60>
  81d826:	jmp    81d99e <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x21e>
  81d82b:	cmpl   $0x1,0x150(%r14)
  81d833:	jne    81d845 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0xc5>
  81d835:	mov    0x138(%r14),%rax
  81d83c:	add    0x130(%r14),%rax
  81d843:	je     81d87c <<gpui_gpu::renderer::RendererState>::prepare_atlas+0xfc>
  81d845:	mov    %rdi,%rbx
  81d848:	add    $0x78,%r14
  81d84c:	lea    0x58(%rsp),%rdi
  81d851:	mov    %rdx,%rsi
  81d854:	mov    $0x1,%edx
  81d859:	call   81cc90 <<gpui_gpu::renderer::Atlas>::new>
  81d85e:	mov    %r14,%rdi
  81d861:	call   81ba50 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81d866:	lea    0x58(%rsp),%rsi
  81d86b:	mov    $0xe8,%edx
  81d870:	mov    %r14,%rdi
  81d873:	call   *0x6624e7(%rip)        # e7fd60 <memcpy@GLIBC_2.14>
  81d879:	mov    %rbx,%rdi
  81d87c:	movq   $0x0,0x8(%rdi)
  81d884:	movl   $0xffffffff,(%rdi)
  81d88a:	jmp    81d9ad <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x22d>
  81d88f:	xor    %ebx,%ebx
  81d891:	jmp    81d99e <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x21e>
  81d896:	mov    0x8(%rsp),%rax
  81d89b:	mov    0x150(%rax),%eax
  81d8a1:	cmp    $0x81,%eax
  81d8a6:	mov    $0x80,%edx
  81d8ab:	cmovae %eax,%edx
  81d8ae:	add    %edx,%edx
  81d8b0:	cmp    $0x800,%edx
  81d8b6:	mov    $0x800,%eax
  81d8bb:	cmovae %eax,%edx
  81d8be:	lea    0x140(%rsp),%r12
  81d8c6:	mov    %r12,%rdi
  81d8c9:	mov    0x18(%rsp),%rsi
  81d8ce:	mov    %edx,0x8(%rsp)
  81d8d2:	call   81cc90 <<gpui_gpu::renderer::Atlas>::new>
  81d8d7:	xor    %r15d,%r15d
  81d8da:	nopw   0x0(%rax,%rax,1)
  81d8e0:	mov    0x0(%r13,%r15,1),%rax
  81d8e5:	movups 0x28(%rax),%xmm0
  81d8e9:	lea    0x68(%rsp),%rcx
  81d8ee:	movups %xmm0,(%rcx)
  81d8f1:	movups 0x18(%rax),%xmm0
  81d8f5:	movups %xmm0,0x58(%rsp)
  81d8fa:	movups 0x38(%rax),%xmm0
  81d8fe:	movups %xmm0,0x78(%rsp)
  81d903:	mov    %r12,%rdi
  81d906:	mov    0x20(%rsp),%rsi
  81d90b:	lea    0x58(%rsp),%rdx
  81d910:	call   81cf60 <<gpui_gpu::renderer::Atlas>::insert>
  81d915:	cmp    $0x1,%rax
  81d919:	jne    81d929 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x1a9>
  81d91b:	add    %rdx,%rbx
  81d91e:	add    $0x8,%r15
  81d922:	cmp    %r15,%rbp
  81d925:	jne    81d8e0 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x160>
  81d927:	jmp    81d96b <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x1eb>
  81d929:	mov    0x8(%rsp),%r15d
  81d92e:	cmp    $0x800,%r15d
  81d935:	je     81d9bf <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x23f>
  81d93b:	mov    %r12,%rdi
  81d93e:	call   81ba50 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81d943:	add    %r15d,%r15d
  81d946:	cmp    $0x800,%r15d
  81d94d:	mov    $0x800,%eax
  81d952:	cmovae %eax,%r15d
  81d956:	mov    %r12,%rdi
  81d959:	mov    0x18(%rsp),%rsi
  81d95e:	mov    %r15d,0x8(%rsp)
  81d963:	mov    %r15d,%edx
  81d966:	jmp    81d8d2 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x152>
  81d96b:	lea    0x58(%rsp),%rdi
  81d970:	lea    0x140(%rsp),%rsi
  81d978:	mov    $0xe8,%edx
  81d97d:	call   *0x6623dd(%rip)        # e7fd60 <memcpy@GLIBC_2.14>
  81d983:	mov    %r14,%rdi
  81d986:	call   81ba50 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81d98b:	lea    0x58(%rsp),%rsi
  81d990:	mov    $0xe8,%edx
  81d995:	mov    %r14,%rdi
  81d998:	call   *0x6623c2(%rip)        # e7fd60 <memcpy@GLIBC_2.14>
  81d99e:	mov    0x10(%rsp),%rax
  81d9a3:	mov    %rbx,0x8(%rax)
  81d9a7:	movl   $0xffffffff,(%rax)
  81d9ad:	add    $0x228,%rsp
  81d9b4:	pop    %rbx
  81d9b5:	pop    %r12
  81d9b7:	pop    %r13
  81d9b9:	pop    %r14
  81d9bb:	pop    %r15
  81d9bd:	pop    %rbp
  81d9be:	ret
  81d9bf:	mov    0x10(%rsp),%rax
  81d9c4:	movl   $0x7,(%rax)
  81d9ca:	lea    0x140(%rsp),%rdi
  81d9d2:	call   81ba50 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81d9d7:	jmp    81d9ad <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x22d>
  81d9d9:	jmp    81d9db <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x25b>
  81d9db:	mov    %rax,%rbx
  81d9de:	lea    0x58(%rsp),%rsi
  81d9e3:	mov    $0xe8,%edx
  81d9e8:	mov    %r14,%rdi
  81d9eb:	call   *0x66236f(%rip)        # e7fd60 <memcpy@GLIBC_2.14>
  81d9f1:	mov    %rbx,%rdi
  81d9f4:	call   e2c830 <_Unwind_Resume@plt>
  81d9f9:	mov    %rax,%rbx
  81d9fc:	lea    0x140(%rsp),%rdi
  81da04:	call   81ba50 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81da09:	mov    %rbx,%rdi
  81da0c:	call   e2c830 <_Unwind_Resume@plt>
  81da11:	call   *0x6622f9(%rip)        # e7fd10 <_DYNAMIC+0x250>

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081da20 <<gpui_gpu::renderer::RendererState>::new>:
  81da20:	push   %r15
  81da22:	push   %r14
  81da24:	push   %r13
  81da26:	push   %r12
  81da28:	push   %rbx
  81da29:	sub    $0x390,%rsp
  81da30:	mov    %rsi,%r14
  81da33:	mov    %rdi,%rbx
  81da36:	lea    -0x748e63(%rip),%rax        # d4bda <anon.36d49f465d299f05a84fba3771e6457e.31.llvm.13987519659127932268+0xa>
  81da3d:	mov    %rax,0xd8(%rsp)
  81da45:	movq   $0x7,0xe0(%rsp)
  81da51:	movq   $0x30,0xe8(%rsp)
  81da5d:	movl   $0x48,0xf0(%rsp)
  81da68:	movb   $0x0,0xf4(%rsp)
  81da70:	mov    0x662669(%rip),%r15        # e800e0 <_DYNAMIC+0x620>
  81da77:	lea    0x10(%rsp),%rdi
  81da7c:	lea    0xd8(%rsp),%rdx
  81da84:	call   *%r15
  81da87:	movq   $0x30,0x30(%rsp)
  81da90:	lea    -0x748eb6(%rip),%rax        # d4be1 <anon.36d49f465d299f05a84fba3771e6457e.31.llvm.13987519659127932268+0x11>
  81da97:	mov    %rax,0xd8(%rsp)
  81da9f:	movq   $0x5,0xe0(%rsp)
  81daab:	movq   $0x10,0xe8(%rsp)
  81dab7:	movl   $0x88,0xf0(%rsp)
  81dac2:	movb   $0x0,0xf4(%rsp)
  81daca:	lea    0x38(%rsp),%rdi
  81dacf:	lea    0xd8(%rsp),%rdx
  81dad7:	mov    %r14,%rsi
  81dada:	call   *%r15
  81dadd:	movq   $0x10,0x58(%rsp)
  81dae6:	lea    -0x748f07(%rip),%rax        # d4be6 <anon.36d49f465d299f05a84fba3771e6457e.31.llvm.13987519659127932268+0x16>
  81daed:	mov    %rax,0xd8(%rsp)
  81daf5:	movq   $0x5,0xe0(%rsp)
  81db01:	movq   $0x8,0xe8(%rsp)
  81db0d:	movl   $0x88,0xf0(%rsp)
  81db18:	movb   $0x0,0xf4(%rsp)
  81db20:	lea    0x60(%rsp),%rdi
  81db25:	lea    0xd8(%rsp),%rdx
  81db2d:	mov    %r14,%rsi
  81db30:	call   *0x6625aa(%rip)        # e800e0 <_DYNAMIC+0x620>
  81db36:	movq   $0x8,0x80(%rsp)
  81db42:	lea    -0x748f5e(%rip),%rax        # d4beb <anon.36d49f465d299f05a84fba3771e6457e.31.llvm.13987519659127932268+0x1b>
  81db49:	mov    %rax,0xd8(%rsp)
  81db51:	movq   $0x7,0xe0(%rsp)
  81db5d:	movq   $0x4,0xe8(%rsp)
  81db69:	movl   $0x88,0xf0(%rsp)
  81db74:	movb   $0x0,0xf4(%rsp)
  81db7c:	lea    0x88(%rsp),%rdi
  81db84:	lea    0xd8(%rsp),%rdx
  81db8c:	mov    %r14,%rsi
  81db8f:	call   *0x66254b(%rip)        # e800e0 <_DYNAMIC+0x620>
  81db95:	movq   $0x4,0xa8(%rsp)
  81dba1:	lea    -0x748fb6(%rip),%rax        # d4bf2 <anon.36d49f465d299f05a84fba3771e6457e.31.llvm.13987519659127932268+0x22>
  81dba8:	mov    %rax,0xd8(%rsp)
  81dbb0:	movq   $0x11,0xe0(%rsp)
  81dbbc:	movq   $0x20,0xe8(%rsp)
  81dbc8:	movl   $0x88,0xf0(%rsp)
  81dbd3:	movb   $0x0,0xf4(%rsp)
  81dbdb:	lea    0xb0(%rsp),%rdi
  81dbe3:	lea    0xd8(%rsp),%rdx
  81dbeb:	mov    %r14,%rsi
  81dbee:	call   *0x6624ec(%rip)        # e800e0 <_DYNAMIC+0x620>
  81dbf4:	movq   $0x20,0xd0(%rsp)
  81dc00:	lea    0x2a8(%rsp),%rdi
  81dc08:	mov    %r14,%rsi
  81dc0b:	mov    $0x1,%edx
  81dc10:	call   81cc90 <<gpui_gpu::renderer::Atlas>::new>
  81dc15:	mov    0x18(%r14),%r13
  81dc19:	lock incq 0x0(%r13)
  81dc1e:	jle    81df53 <<gpui_gpu::renderer::RendererState>::new+0x533>
  81dc24:	mov    %r13,0x8(%rsp)
  81dc29:	mov    0x30(%rsp),%rax
  81dc2e:	mov    %rax,0x1e0(%rsp)
  81dc36:	movups 0x10(%rsp),%xmm0
  81dc3b:	movups 0x20(%rsp),%xmm1
  81dc40:	movaps %xmm1,0x1d0(%rsp)
  81dc48:	movaps %xmm0,0x1c0(%rsp)
  81dc50:	mov    0x58(%rsp),%rax
  81dc55:	mov    %rax,0x210(%rsp)
  81dc5d:	movups 0x38(%rsp),%xmm0
  81dc62:	movups 0x48(%rsp),%xmm1
  81dc67:	movaps %xmm1,0x200(%rsp)
  81dc6f:	movaps %xmm0,0x1f0(%rsp)
  81dc77:	mov    0x80(%rsp),%rax
  81dc7f:	mov    %rax,0x240(%rsp)
  81dc87:	movups 0x60(%rsp),%xmm0
  81dc8c:	movups 0x70(%rsp),%xmm1
  81dc91:	movaps %xmm1,0x230(%rsp)
  81dc99:	movaps %xmm0,0x220(%rsp)
  81dca1:	mov    0xa8(%rsp),%rax
  81dca9:	mov    %rax,0x270(%rsp)
  81dcb1:	movups 0x88(%rsp),%xmm0
  81dcb9:	movups 0x98(%rsp),%xmm1
  81dcc1:	movaps %xmm1,0x260(%rsp)
  81dcc9:	movaps %xmm0,0x250(%rsp)
  81dcd1:	mov    0xd0(%rsp),%rax
  81dcd9:	mov    %rax,0x2a0(%rsp)
  81dce1:	movups 0xb0(%rsp),%xmm0
  81dce9:	movups 0xc0(%rsp),%xmm1
  81dcf1:	movaps %xmm1,0x290(%rsp)
  81dcf9:	movaps %xmm0,0x280(%rsp)
  81dd01:	lea    0xd8(%rsp),%rdi
  81dd09:	lea    0x2a8(%rsp),%rsi
  81dd11:	mov    $0xe8,%edx
  81dd16:	call   *0x662044(%rip)        # e7fd60 <memcpy@GLIBC_2.14>
  81dd1c:	mov    %fs:0x0,%rax
  81dd25:	lea    -0x28(%rax),%rax
  81dd2c:	mov    %rax,%r12
  81dd2f:	cmpb   $0x1,0x10(%rax)
  81dd33:	jne    81df33 <<gpui_gpu::renderer::RendererState>::new+0x513>
  81dd39:	mov    (%r12),%r14
  81dd3d:	mov    0x8(%r12),%r15
  81dd42:	lea    0x1(%r14),%rax
  81dd46:	mov    %rax,(%r12)
  81dd4a:	mov    %r13,0x228(%rbx)
  81dd51:	mov    0x30(%rsp),%rax
  81dd56:	mov    %rax,0x250(%rbx)
  81dd5d:	movups 0x10(%rsp),%xmm0
  81dd62:	movups 0x20(%rsp),%xmm1
  81dd67:	movups %xmm1,0x240(%rbx)
  81dd6e:	movups %xmm0,0x230(%rbx)
  81dd75:	mov    0x58(%rsp),%rax
  81dd7a:	mov    %rax,0x278(%rbx)
  81dd81:	movups 0x38(%rsp),%xmm0
  81dd86:	movups 0x48(%rsp),%xmm1
  81dd8b:	movups %xmm1,0x268(%rbx)
  81dd92:	movups %xmm0,0x258(%rbx)
  81dd99:	mov    0x80(%rsp),%rax
  81dda1:	mov    %rax,0x2a0(%rbx)
  81dda8:	movups 0x60(%rsp),%xmm0
  81ddad:	movups 0x70(%rsp),%xmm1
  81ddb2:	movups %xmm1,0x290(%rbx)
  81ddb9:	movups %xmm0,0x280(%rbx)
  81ddc0:	movups 0x88(%rsp),%xmm0
  81ddc8:	movups 0x98(%rsp),%xmm1
  81ddd0:	movups %xmm0,0x2a8(%rbx)
  81ddd7:	movups %xmm1,0x2b8(%rbx)
  81ddde:	mov    0xa8(%rsp),%rax
  81dde6:	mov    %rax,0x2c8(%rbx)
  81dded:	movups 0xb0(%rsp),%xmm0
  81ddf5:	movups 0xc0(%rsp),%xmm1
  81ddfd:	movups %xmm0,0x2d0(%rbx)
  81de04:	movups %xmm1,0x2e0(%rbx)
  81de0b:	mov    0xd0(%rsp),%rax
  81de13:	mov    %rax,0x2f0(%rbx)
  81de1a:	lea    0x78(%rbx),%rdi
  81de1e:	lea    0x2a8(%rsp),%rsi
  81de26:	mov    $0xe8,%edx
  81de2b:	call   *0x661f2f(%rip)        # e7fd60 <memcpy@GLIBC_2.14>
  81de31:	movq   $0x0,0x328(%rbx)
  81de3c:	movq   $0x0,(%rbx)
  81de43:	movq   $0x4,0x8(%rbx)
  81de4b:	xorps  %xmm0,%xmm0
  81de4e:	movups %xmm0,0x10(%rbx)
  81de52:	movq   $0x4,0x20(%rbx)
  81de5a:	movups %xmm0,0x28(%rbx)
  81de5e:	movq   $0x4,0x38(%rbx)
  81de66:	movups %xmm0,0x40(%rbx)
  81de6a:	movq   $0x4,0x50(%rbx)
  81de72:	movups %xmm0,0x58(%rbx)
  81de76:	movq   $0x4,0x68(%rbx)
  81de7e:	movq   $0x0,0x70(%rbx)
  81de86:	movups 0x61089b(%rip),%xmm1        # e2e728 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.13987519659127932268+0x1e0>
  81de8d:	movups %xmm1,0x2f8(%rbx)
  81de94:	movups 0x61089d(%rip),%xmm1        # e2e738 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.13987519659127932268+0x1f0>
  81de9b:	movups %xmm1,0x308(%rbx)
  81dea2:	mov    %r14,0x318(%rbx)
  81dea9:	mov    %r15,0x320(%rbx)
  81deb0:	movw   $0x101,0x340(%rbx)
  81deb9:	movq   $0x0,0x330(%rbx)
  81dec4:	movups %xmm0,0x210(%rbx)
  81decb:	movups %xmm0,0x200(%rbx)
  81ded2:	movups %xmm0,0x1f0(%rbx)
  81ded9:	movups %xmm0,0x1e0(%rbx)
  81dee0:	movups %xmm0,0x1d0(%rbx)
  81dee7:	movups %xmm0,0x1c0(%rbx)
  81deee:	movups %xmm0,0x1b0(%rbx)
  81def5:	movups %xmm0,0x1a0(%rbx)
  81defc:	movups %xmm0,0x190(%rbx)
  81df03:	movups %xmm0,0x180(%rbx)
  81df0a:	movups %xmm0,0x170(%rbx)
  81df11:	movups %xmm0,0x160(%rbx)
  81df18:	movb   $0x0,0x220(%rbx)
  81df1f:	mov    %rbx,%rax
  81df22:	add    $0x390,%rsp
  81df29:	pop    %rbx
  81df2a:	pop    %r12
  81df2c:	pop    %r13
  81df2e:	pop    %r14
  81df30:	pop    %r15
  81df32:	ret
  81df33:	call   *0x6621af(%rip)        # e800e8 <_DYNAMIC+0x628>
  81df39:	mov    %rax,%r14
  81df3c:	mov    %rdx,%r15
  81df3f:	mov    %rax,(%r12)
  81df43:	mov    %rdx,0x8(%r12)
  81df48:	movb   $0x1,0x10(%r12)
  81df4e:	jmp    81dd42 <<gpui_gpu::renderer::RendererState>::new+0x322>
  81df53:	ud2
  81df55:	mov    %rax,%rbx
  81df58:	lea    0xd8(%rsp),%rdi
  81df60:	call   81ba50 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81df65:	lea    0x280(%rsp),%rdi
  81df6d:	call   81bb30 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81df72:	lea    0x250(%rsp),%rdi
  81df7a:	call   81bb30 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81df7f:	lea    0x220(%rsp),%rdi
  81df87:	call   81bb30 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81df8c:	lea    0x1f0(%rsp),%rdi
  81df94:	call   81bb30 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81df99:	lea    0x1c0(%rsp),%rdi
  81dfa1:	call   81bb30 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81dfa6:	lock decq 0x0(%r13)
  81dfab:	jne    81e009 <<gpui_gpu::renderer::RendererState>::new+0x5e9>
  81dfad:	lea    0x8(%rsp),%rdi
  81dfb2:	call   *0x661f70(%rip)        # e7ff28 <_DYNAMIC+0x468>
  81dfb8:	jmp    81e009 <<gpui_gpu::renderer::RendererState>::new+0x5e9>
  81dfba:	mov    %rax,%rbx
  81dfbd:	lea    0xb0(%rsp),%rdi
  81dfc5:	call   81bb30 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81dfca:	jmp    81dfcf <<gpui_gpu::renderer::RendererState>::new+0x5af>
  81dfcc:	mov    %rax,%rbx
  81dfcf:	lea    0x88(%rsp),%rdi
  81dfd7:	call   81bb30 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81dfdc:	jmp    81dfe1 <<gpui_gpu::renderer::RendererState>::new+0x5c1>
  81dfde:	mov    %rax,%rbx
  81dfe1:	lea    0x60(%rsp),%rdi
  81dfe6:	call   81bb30 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81dfeb:	jmp    81dff0 <<gpui_gpu::renderer::RendererState>::new+0x5d0>
  81dfed:	mov    %rax,%rbx
  81dff0:	lea    0x38(%rsp),%rdi
  81dff5:	call   81bb30 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81dffa:	jmp    81dfff <<gpui_gpu::renderer::RendererState>::new+0x5df>
  81dffc:	mov    %rax,%rbx
  81dfff:	lea    0x10(%rsp),%rdi
  81e004:	call   81bb30 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e009:	mov    %rbx,%rdi
  81e00c:	call   e2c830 <_Unwind_Resume@plt>
  81e011:	call   *0x661cf9(%rip)        # e7fd10 <_DYNAMIC+0x250>

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081e020 <<gpui_gpu::renderer::RendererState>::render>:
  81e020:	push   %rbp
  81e021:	push   %r15
  81e023:	push   %r14
  81e025:	push   %r13
  81e027:	push   %r12
  81e029:	push   %rbx
  81e02a:	sub    $0x578,%rsp
  81e031:	mov    0x228(%rsi),%rax
  81e038:	mov    0x18(%rdx),%rbx
  81e03c:	cmp    %rbx,%rax
  81e03f:	je     81e05d <<gpui_gpu::renderer::RendererState>::render+0x3d>
  81e041:	mov    0x10(%rax),%r9
  81e045:	cmp    0x10(%rbx),%r9
  81e049:	jne    81e1c9 <<gpui_gpu::renderer::RendererState>::render+0x1a9>
  81e04f:	mov    0x18(%rax),%rax
  81e053:	cmp    0x18(%rbx),%rax
  81e057:	jne    81e1c9 <<gpui_gpu::renderer::RendererState>::render+0x1a9>
  81e05d:	movupd 0x330(%rsi),%xmm0
  81e065:	movapd %xmm0,0x130(%rsp)
  81e06e:	movq   $0x0,0x330(%rsi)
  81e079:	mov    0x130(%rsp),%r13
  81e081:	test   %r13,%r13
  81e084:	je     81e0c6 <<gpui_gpu::renderer::RendererState>::render+0xa6>
  81e086:	lock decq 0x0(%r13)
  81e08b:	jne    81e0c6 <<gpui_gpu::renderer::RendererState>::render+0xa6>
  81e08d:	lea    0x130(%rsp),%rax
  81e095:	mov    %rdi,%r14
  81e098:	mov    %rax,%rdi
  81e09b:	mov    %rsi,%r12
  81e09e:	mov    %r8,%rbp
  81e0a1:	mov    %rdx,%r15
  81e0a4:	mov    %r13,0x38(%rsp)
  81e0a9:	mov    %rcx,%r13
  81e0ac:	call   *0x661f26(%rip)        # e7ffd8 <_DYNAMIC+0x518>
  81e0b2:	mov    %r13,%rcx
  81e0b5:	mov    0x38(%rsp),%r13
  81e0ba:	mov    %r15,%rdx
  81e0bd:	mov    %rbp,%r8
  81e0c0:	mov    %r12,%rsi
  81e0c3:	mov    %r14,%rdi
  81e0c6:	mov    0x228(%rsi),%rax
  81e0cd:	cmp    %rbx,%rax
  81e0d0:	je     81e0ee <<gpui_gpu::renderer::RendererState>::render+0xce>
  81e0d2:	mov    0x10(%rax),%r9
  81e0d6:	cmp    0x10(%rbx),%r9
  81e0da:	jne    81e1c9 <<gpui_gpu::renderer::RendererState>::render+0x1a9>
  81e0e0:	mov    0x18(%rax),%rax
  81e0e4:	cmp    0x18(%rbx),%rax
  81e0e8:	jne    81e1c9 <<gpui_gpu::renderer::RendererState>::render+0x1a9>
  81e0ee:	lea    0x330(%rsi),%rax
  81e0f5:	mov    %rax,0xe8(%rsp)
  81e0fd:	mov    (%rax),%rax
  81e100:	test   %rax,%rax
  81e103:	je     81e13c <<gpui_gpu::renderer::RendererState>::render+0x11c>
  81e105:	lock decq (%rax)
  81e109:	jne    81e13c <<gpui_gpu::renderer::RendererState>::render+0x11c>
  81e10b:	mov    %rdi,%r14
  81e10e:	lea    0x330(%rsi),%rdi
  81e115:	mov    %rsi,%r12
  81e118:	mov    %r8,%rbp
  81e11b:	mov    %rdx,%r15
  81e11e:	mov    %r13,%rbx
  81e121:	mov    %rcx,%r13
  81e124:	call   *0x661eae(%rip)        # e7ffd8 <_DYNAMIC+0x518>
  81e12a:	mov    %r13,%rcx
  81e12d:	mov    %rbx,%r13
  81e130:	mov    %r15,%rdx
  81e133:	mov    %rbp,%r8
  81e136:	mov    %r12,%rsi
  81e139:	mov    %r14,%rdi
  81e13c:	movq   $0x0,0x330(%rsi)
  81e147:	mov    (%rcx),%ebp
  81e149:	mov    0x8(%rcx),%r9d
  81e14d:	movzbl 0xd(%rcx),%eax
  81e151:	test   %r9d,%r9d
  81e154:	sets   %r10b
  81e158:	and    $0x7fffffff,%r9d
  81e15f:	lea    -0x800000(%r9),%r11d
  81e166:	cmp    $0x7f000000,%r11d
  81e16d:	setb   %r11b
  81e171:	and    %r10b,%r11b
  81e174:	lea    -0x1(%r9),%r14d
  81e178:	cmp    $0x7fffff,%r14d
  81e17f:	setb   %r14b
  81e183:	and    %r10b,%r14b
  81e186:	test   %r9d,%r9d
  81e189:	sete   %r10b
  81e18d:	cmp    $0x7f800000,%r9d
  81e194:	sete   %r15b
  81e198:	or     %r10b,%r15b
  81e19b:	cmp    $0x7f800001,%r9d
  81e1a2:	setge  %r9b
  81e1a6:	or     %r15b,%r9b
  81e1a9:	or     %r14b,%r9b
  81e1ac:	test   %ebp,%ebp
  81e1ae:	setne  %r10b
  81e1b2:	and    %al,%r10b
  81e1b5:	or     %r11b,%r10b
  81e1b8:	or     %r9b,%r10b
  81e1bb:	test   $0x1,%r10b
  81e1bf:	je     81e1e4 <<gpui_gpu::renderer::RendererState>::render+0x1c4>
  81e1c1:	movl   $0x3,(%rdi)
  81e1c7:	jmp    81e1cf <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81e1c9:	movl   $0x4,(%rdi)
  81e1cf:	mov    %rdi,%rax
  81e1d2:	add    $0x578,%rsp
  81e1d9:	pop    %rbx
  81e1da:	pop    %r12
  81e1dc:	pop    %r13
  81e1de:	pop    %r14
  81e1e0:	pop    %r15
  81e1e2:	pop    %rbp
  81e1e3:	ret
  81e1e4:	movd   0x4(%rcx),%xmm2
  81e1e9:	movzbl 0xc(%rcx),%r12d
  81e1ee:	test   $0x1,%bpl
  81e1f2:	je     81e26a <<gpui_gpu::renderer::RendererState>::render+0x24a>
  81e1f4:	movd   %xmm2,%r9d
  81e1f9:	test   %r9d,%r9d
  81e1fc:	sets   %r10b
  81e200:	and    $0x7fffffff,%r9d
  81e207:	lea    -0x800000(%r9),%r11d
  81e20e:	cmp    $0x7f000000,%r11d
  81e215:	setb   %r11b
  81e219:	and    %r10b,%r11b
  81e21c:	lea    -0x1(%r9),%r14d
  81e220:	cmp    $0x7fffff,%r14d
  81e227:	setb   %r14b
  81e22b:	and    %r10b,%r14b
  81e22e:	test   %r9d,%r9d
  81e231:	sete   %r10b
  81e235:	cmp    $0x7f800000,%r9d
  81e23c:	sete   %r15b
  81e240:	or     %r10b,%r15b
  81e243:	cmp    $0x7f800001,%r9d
  81e24a:	setge  %r9b
  81e24e:	or     %r15b,%r9b
  81e251:	or     %r14b,%r9b
  81e254:	or     %r11b,%r9b
  81e257:	jne    81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e25d:	ucomiss -0x76f358(%rip),%xmm2        # aef0c <anon.630a3fff68f6bca64b568be97512ab45.57.llvm.826976926275214120+0x1c>
  81e264:	ja     81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e26a:	mov    0x28(%rcx),%r14d
  81e26e:	cmp    %r14d,0x20(%r8)
  81e272:	jne    81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e278:	mov    0x2c(%rcx),%r15d
  81e27c:	cmp    %r15d,0x24(%r8)
  81e280:	jne    81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e286:	mov    0x38(%r8),%r10d
  81e28a:	cmp    0x20(%rdx),%r10d
  81e28e:	jne    81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e294:	cmp    $0x4c,%r10d
  81e298:	jne    81e2bd <<gpui_gpu::renderer::RendererState>::render+0x29d>
  81e29a:	movq   0x3c(%r8),%xmm0
  81e2a0:	movq   0x24(%rdx),%xmm1
  81e2a5:	pcmpeqd %xmm0,%xmm1
  81e2a9:	pshufd $0x50,%xmm1,%xmm0
  81e2ae:	movmskpd %xmm0,%r9d
  81e2b3:	cmp    $0x3,%r9d
  81e2b7:	jne    81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e2bd:	cmp    $0x4000,%r15d
  81e2c4:	ja     81e2fa <<gpui_gpu::renderer::RendererState>::render+0x2da>
  81e2c6:	cmp    $0x4000,%r14d
  81e2cd:	ja     81e2fa <<gpui_gpu::renderer::RendererState>::render+0x2da>
  81e2cf:	mov    %r15,%r9
  81e2d2:	imul   %r14,%r9
  81e2d6:	add    $0xfffffffffeffffff,%r9
  81e2dd:	cmp    $0xffffffffff000000,%r9
  81e2e4:	jb     81e2fa <<gpui_gpu::renderer::RendererState>::render+0x2da>
  81e2e6:	mov    0x10(%rcx),%rbx
  81e2ea:	mov    0x80(%rbx),%r11
  81e2f1:	cmp    $0x10000,%r11
  81e2f8:	jbe    81e305 <<gpui_gpu::renderer::RendererState>::render+0x2e5>
  81e2fa:	movl   $0x6,(%rdi)
  81e300:	jmp    81e1cf <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81e305:	movd   0x18(%rcx),%xmm0
  81e30a:	movd   %xmm0,%r9d
  81e30f:	and    $0x7fffffff,%r9d
  81e316:	cmp    $0x7f7fffff,%r9d
  81e31d:	jg     81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e323:	pand   -0x770b3b(%rip),%xmm0        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e32b:	ucomiss -0x76f1ce(%rip),%xmm0        # af164 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e332:	ja     81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e338:	movd   0x1c(%rcx),%xmm0
  81e33d:	movd   %xmm0,%r9d
  81e342:	and    $0x7fffffff,%r9d
  81e349:	cmp    $0x7f7fffff,%r9d
  81e350:	jg     81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e356:	pand   -0x770b6e(%rip),%xmm0        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e35e:	ucomiss -0x76f201(%rip),%xmm0        # af164 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e365:	ja     81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e36b:	movd   0x20(%rcx),%xmm0
  81e370:	movd   %xmm0,%r9d
  81e375:	and    $0x7fffffff,%r9d
  81e37c:	cmp    $0x7f7fffff,%r9d
  81e383:	jg     81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e389:	pand   -0x770ba1(%rip),%xmm0        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e391:	ucomiss -0x76f234(%rip),%xmm0        # af164 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e398:	ja     81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e39e:	movd   0x24(%rcx),%xmm0
  81e3a3:	movd   %xmm0,%r9d
  81e3a8:	and    $0x7fffffff,%r9d
  81e3af:	cmp    $0x7f7fffff,%r9d
  81e3b6:	jg     81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e3bc:	movdqa -0x770bd4(%rip),%xmm1        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e3c4:	pand   %xmm0,%xmm1
  81e3c8:	ucomiss -0x76f26b(%rip),%xmm1        # af164 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e3cf:	ja     81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e3d5:	xorps  %xmm1,%xmm1
  81e3d8:	ucomiss %xmm1,%xmm0
  81e3db:	jb     81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e3e1:	movss  -0x76f609(%rip),%xmm1        # aede0 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  81e3e9:	ucomiss %xmm0,%xmm1
  81e3ec:	jb     81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e3f2:	movzwl 0x30(%rcx),%r9d
  81e3f7:	mov    %r9d,0x10(%rsp)
  81e3fc:	movzwl 0x32(%rcx),%r9d
  81e401:	mov    %r9d,0x30(%rsp)
  81e406:	cmp    $0x28,%r10d
  81e40a:	mov    %r8,0x4b8(%rsp)
  81e412:	mov    %rcx,0x120(%rsp)
  81e41a:	mov    %rdx,0xa0(%rsp)
  81e422:	mov    %r13,0x38(%rsp)
  81e427:	movd   %xmm2,0x2e8(%rsp)
  81e430:	movss  %xmm1,0xf4(%rsp)
  81e439:	jne    81e445 <<gpui_gpu::renderer::RendererState>::render+0x425>
  81e43b:	test   $0x1,%al
  81e43d:	je     81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e443:	jmp    81e460 <<gpui_gpu::renderer::RendererState>::render+0x440>
  81e445:	test   $0x1,%al
  81e447:	jne    81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e44d:	ucomiss -0x76f674(%rip),%xmm0        # aede0 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  81e454:	jne    81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e45a:	jp     81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e460:	mov    %rbx,0x100(%rsp)
  81e468:	mov    %r11,0x108(%rsp)
  81e470:	mov    %r10d,0x2e4(%rsp)
  81e478:	mov    %rdi,0x50(%rsp)
  81e47d:	lea    0xf(%r14),%rax
  81e481:	shr    $0x4,%rax
  81e485:	lea    0xf(%r15),%ecx
  81e489:	shr    $0x4,%ecx
  81e48c:	lea    0x18(%rsi),%rdi
  81e490:	movq   $0x0,0x28(%rsi)
  81e498:	mov    %rax,0x90(%rsp)
  81e4a0:	imul   %eax,%ecx
  81e4a3:	movabs $0x4000000000000000,%rdx
  81e4ad:	mov    %rdi,0x4c8(%rsp)
  81e4b5:	mov    %rsi,%r13
  81e4b8:	mov    %rcx,0x40(%rsp)
  81e4bd:	mov    %rcx,%rsi
  81e4c0:	call   823620 <<alloc::vec::Vec<[u32; 2]>>::resize>
  81e4c5:	mov    %r13,0x8(%rsp)
  81e4ca:	mov    0x10(%r13),%rax
  81e4ce:	mov    %rax,0x348(%rsp)
  81e4d6:	mov    0x120(%rsp),%rdi
  81e4de:	call   *0x661b84(%rip)        # e80068 <_DYNAMIC+0x5a8>
  81e4e4:	mov    %rdx,0x358(%rsp)
  81e4ec:	mov    %rax,0x350(%rsp)
  81e4f4:	sub    %rax,%rdx
  81e4f7:	cmp    $0x300000,%rdx
  81e4fe:	ja     81e635 <<gpui_gpu::renderer::RendererState>::render+0x615>
  81e504:	mov    %rdx,%rcx
  81e507:	mov    %rdx,%rax
  81e50a:	shr    $0x3,%rax
  81e50e:	movabs $0xaaaaaaaaaaaaaaab,%rdx
  81e518:	imul   %rax,%rdx
  81e51c:	mov    %rdx,0x2c0(%rsp)
  81e524:	mov    0x350(%rsp),%rax
  81e52c:	cmp    %rax,0x358(%rsp)
  81e534:	je     81e565 <<gpui_gpu::renderer::RendererState>::render+0x545>
  81e536:	mov    $0xaaaaaaab,%eax
  81e53b:	imul   %rax,%rcx
  81e53f:	shr    $0x2a,%rcx
  81e543:	mov    0x2c0(%rsp),%rdx
  81e54b:	mov    %edx,%eax
  81e54d:	and    $0x3f,%eax
  81e550:	add    %rdx,%rcx
  81e553:	cmp    $0x1,%rax
  81e557:	sbb    $0xffffffffffffffff,%rcx
  81e55b:	inc    %rcx
  81e55e:	mov    %rcx,0x20(%rsp)
  81e563:	jmp    81e56e <<gpui_gpu::renderer::RendererState>::render+0x54e>
  81e565:	movq   $0x0,0x20(%rsp)
  81e56e:	mov    0x100(%rsp),%rax
  81e576:	mov    0x98(%rax),%rdx
  81e57d:	add    0xb0(%rax),%rdx
  81e584:	mov    0x30(%rsp),%ecx
  81e588:	shl    $0x10,%ecx
  81e58b:	add    0x10(%rsp),%ecx
  81e58f:	mov    %rax,0x130(%rsp)
  81e597:	movq   $0x0,0x138(%rsp)
  81e5a3:	mov    0x108(%rsp),%rbx
  81e5ab:	mov    %rbx,0x140(%rsp)
  81e5b3:	mov    %rdx,0x340(%rsp)
  81e5bb:	mov    %rdx,0x148(%rsp)
  81e5c3:	mov    %ecx,0x30(%rsp)
  81e5c7:	mov    %ecx,0x150(%rsp)
  81e5ce:	mov    0x8(%rsp),%r13
  81e5d3:	movzbl 0x341(%r13),%esi
  81e5db:	lea    0x130(%rsp),%rdi
  81e5e3:	call   81c740 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>>
  81e5e8:	mov    %rax,0x110(%rsp)
  81e5f0:	mov    0x20(%rsp),%rcx
  81e5f5:	lea    (%rcx,%rax,4),%rcx
  81e5f9:	mov    %rcx,0x10(%rsp)
  81e5fe:	lea    (%rcx,%rbx,2),%rax
  81e602:	xor    %edx,%edx
  81e604:	mov    %rax,0x2b8(%rsp)
  81e60c:	sub    0x348(%rsp),%rax
  81e614:	cmovae %rax,%rdx
  81e618:	mov    0x10(%r13),%rsi
  81e61c:	mov    $0x4,%ecx
  81e621:	mov    $0x10,%r8d
  81e627:	mov    %r13,%rdi
  81e62a:	call   825de0 <<alloc::raw_vec::RawVecInner>::try_reserve_exact>
  81e62f:	cmp    $0xffffffffffffffff,%rax
  81e633:	je     81e645 <<gpui_gpu::renderer::RendererState>::render+0x625>
  81e635:	mov    0x50(%rsp),%rdi
  81e63a:	movl   $0x6,(%rdi)
  81e640:	jmp    81e1cf <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81e645:	pxor   %xmm0,%xmm0
  81e649:	movdqa %xmm0,0x130(%rsp)
  81e652:	lea    0x130(%rsp),%rdx
  81e65a:	mov    0x8(%rsp),%rbx
  81e65f:	mov    %rbx,%rdi
  81e662:	mov    0x108(%rsp),%rax
  81e66a:	mov    0x10(%rsp),%rcx
  81e66f:	lea    (%rcx,%rax,2),%rsi
  81e673:	call   823740 <<alloc::vec::Vec<[u32; 4]>>::resize>
  81e678:	movq   $0xffffffffffffffff,0x2d0(%rsp)
  81e684:	movq   $0x0,0x2d8(%rsp)
  81e690:	movq   $0xffffffffffffffff,0x230(%rsp)
  81e69c:	movq   $0x0,0x238(%rsp)
  81e6a8:	mov    0x10(%rbx),%rdx
  81e6ac:	cmp    %rdx,0x20(%rsp)
  81e6b1:	ja     8203a8 <<gpui_gpu::renderer::RendererState>::render+0x2388>
  81e6b7:	mov    0x8(%rsp),%r13
  81e6bc:	mov    0x8(%r13),%rdi
  81e6c0:	lea    0x2d0(%rsp),%r8
  81e6c8:	mov    0x20(%rsp),%rsi
  81e6cd:	mov    0x120(%rsp),%rdx
  81e6d5:	mov    0x2c0(%rsp),%rcx
  81e6dd:	call   825870 <gpui_gpu::renderer::slots::write_prefix>
  81e6e2:	lea    0x48(%r13),%rdi
  81e6e6:	movq   $0x0,0x58(%r13)
  81e6ee:	mov    %rdi,0x4c0(%rsp)
  81e6f6:	mov    0x40(%rsp),%rsi
  81e6fb:	xor    %edx,%edx
  81e6fd:	call   823830 <<alloc::vec::Vec<u32>>::resize>
  81e702:	movq   $0x0,0x70(%r13)
  81e70a:	cmpq   $0x0,0x60(%r13)
  81e70f:	jne    81e720 <<gpui_gpu::renderer::RendererState>::render+0x700>
  81e711:	mov    0x8(%rsp),%rax
  81e716:	lea    0x60(%rax),%rdi
  81e71a:	call   *0x661950(%rip)        # e80070 <_DYNAMIC+0x5b0>
  81e720:	mov    0x110(%rsp),%rax
  81e728:	add    %rax,%rax
  81e72b:	mov    %rax,0x110(%rsp)
  81e733:	mov    0x8(%rsp),%rax
  81e738:	mov    0x68(%rax),%rcx
  81e73c:	pxor   %xmm0,%xmm0
  81e740:	movdqu %xmm0,0x10(%rcx)
  81e745:	movdqu %xmm0,(%rcx)
  81e749:	movq   $0x1,0x70(%rax)
  81e751:	lea    0x2f8(%rax),%rdi
  81e758:	call   823070 <<hashbrown::raw::RawTable<([u32; 8], u32)>>::clear>
  81e75d:	mov    0x100(%rsp),%rax
  81e765:	mov    %rax,0x368(%rsp)
  81e76d:	movq   $0x0,0x370(%rsp)
  81e779:	mov    0x108(%rsp),%rax
  81e781:	mov    %rax,0x378(%rsp)
  81e789:	mov    0x340(%rsp),%rax
  81e791:	mov    %rax,0x380(%rsp)
  81e799:	mov    0x30(%rsp),%eax
  81e79d:	mov    %eax,0x388(%rsp)
  81e7a4:	lea    0x408(%rsp),%rdi
  81e7ac:	lea    0x368(%rsp),%rsi
  81e7b4:	call   *0x6618be(%rip)        # e80078 <_DYNAMIC+0x5b8>
  81e7ba:	mov    0x408(%rsp),%rax
  81e7c2:	mov    %rax,0x28(%rsp)
  81e7c7:	test   %rax,%rax
  81e7ca:	je     81f256 <<gpui_gpu::renderer::RendererState>::render+0x1236>
  81e7d0:	movq   $0x0,0x118(%rsp)
  81e7dc:	movq   $0x0,0x68(%rsp)
  81e7e5:	movq   $0x0,0x88(%rsp)
  81e7f1:	movq   $0x0,0x2a8(%rsp)
  81e7fd:	movq   $0x0,0x2b0(%rsp)
  81e809:	mov    0x410(%rsp),%rbx
  81e811:	mov    0x418(%rsp),%r13
  81e819:	lea    0x420(%rsp),%rcx
  81e821:	movups (%rcx),%xmm0
  81e824:	movups 0x10(%rcx),%xmm1
  81e828:	movups 0x20(%rcx),%xmm2
  81e82c:	movaps %xmm2,0x290(%rsp)
  81e834:	movaps %xmm1,0x280(%rsp)
  81e83c:	movaps %xmm0,0x270(%rsp)
  81e844:	lea    0x450(%rsp),%rdx
  81e84c:	movups (%rdx),%xmm0
  81e84f:	movaps %xmm0,0x330(%rsp)
  81e857:	movups 0x40(%rcx),%xmm0
  81e85b:	movaps %xmm0,0x320(%rsp)
  81e863:	mov    0x8(%rsp),%rax
  81e868:	movzbl 0x341(%rax),%esi
  81e86f:	mov    0x28(%rsp),%rax
  81e874:	mov    %rax,0x130(%rsp)
  81e87c:	mov    %rbx,0x138(%rsp)
  81e884:	mov    %r13,0x140(%rsp)
  81e88c:	movups (%rcx),%xmm0
  81e88f:	movdqu 0x10(%rcx),%xmm1
  81e894:	movdqu 0x20(%rcx),%xmm2
  81e899:	lea    0x148(%rsp),%rdi
  81e8a1:	movdqu %xmm2,0x20(%rdi)
  81e8a6:	movdqu %xmm1,0x10(%rdi)
  81e8ab:	movups %xmm0,(%rdi)
  81e8ae:	movups (%rdx),%xmm0
  81e8b1:	lea    0x178(%rsp),%rax
  81e8b9:	movups %xmm0,(%rax)
  81e8bc:	movdqu 0x40(%rcx),%xmm0
  81e8c1:	movdqu %xmm0,0x40(%rdi)
  81e8c6:	lea    0x130(%rsp),%rdi
  81e8ce:	call   821590 <gpui_gpu::renderer::compact_group>
  81e8d3:	mov    %rbx,0xa8(%rsp)
  81e8db:	mov    %r13,0xe0(%rsp)
  81e8e3:	lea    (%rbx,%r13,4),%rbx
  81e8e7:	mov    %al,0x1f(%rsp)
  81e8eb:	test   %al,%al
  81e8ed:	je     81eae2 <<gpui_gpu::renderer::RendererState>::render+0xac2>
  81e8f3:	mov    0xa8(%rsp),%rax
  81e8fb:	mov    %rax,0x490(%rsp)
  81e903:	mov    %rbx,0x498(%rsp)
  81e90b:	mov    0x28(%rsp),%rax
  81e910:	mov    %rax,0x4a0(%rsp)
  81e918:	movq   $0x0,0x4a8(%rsp)
  81e924:	lea    0x3a0(%rsp),%rdi
  81e92c:	lea    0x490(%rsp),%rsi
  81e934:	call   821c20 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81e939:	cmpb   $0xff,0x3a8(%rsp)
  81e941:	je     81eaf0 <<gpui_gpu::renderer::RendererState>::render+0xad0>
  81e947:	pxor   %xmm0,%xmm0
  81e94b:	movdqa %xmm0,0x70(%rsp)
  81e951:	movdqa %xmm0,0x40(%rsp)
  81e957:	mov    0x3a0(%rsp),%rdx
  81e95f:	add    0x88(%rsp),%rdx
  81e967:	lea    0x3a8(%rsp),%rcx
  81e96f:	movups 0x38(%rcx),%xmm0
  81e973:	lea    0x148(%rsp),%rax
  81e97b:	movups %xmm0,0x20(%rax)
  81e97f:	movups 0x48(%rcx),%xmm0
  81e983:	lea    0x178(%rsp),%rsi
  81e98b:	movups %xmm0,0x40(%rsi)
  81e98f:	mov    0x30(%rcx),%rax
  81e993:	mov    %rax,0x160(%rsp)
  81e99b:	movups (%rcx),%xmm0
  81e99e:	movups 0x10(%rcx),%xmm1
  81e9a2:	movups 0x20(%rcx),%xmm2
  81e9a6:	movaps %xmm2,0x150(%rsp)
  81e9ae:	movaps %xmm1,0x140(%rsp)
  81e9b6:	movaps %xmm0,0x130(%rsp)
  81e9be:	lea    0x420(%rsp),%rax
  81e9c6:	movups (%rax),%xmm0
  81e9c9:	movups 0x10(%rax),%xmm1
  81e9cd:	movups 0x20(%rax),%xmm2
  81e9d1:	movups %xmm2,0x20(%rsi)
  81e9d5:	movups %xmm1,0x10(%rsi)
  81e9d9:	movups %xmm0,(%rsi)
  81e9dc:	lea    0x450(%rsp),%rcx
  81e9e4:	movups (%rcx),%xmm0
  81e9e7:	movups %xmm0,0x30(%rsi)
  81e9eb:	movups 0x40(%rax),%xmm0
  81e9ef:	movups %xmm0,0x50(%rsi)
  81e9f3:	lea    0x240(%rsp),%rdi
  81e9fb:	lea    0x130(%rsp),%rsi
  81ea03:	mov    %r14d,%ecx
  81ea06:	mov    %r15d,%r8d
  81ea09:	call   8215e0 <gpui_gpu::renderer::validate_draw>
  81ea0e:	mov    0x240(%rsp),%ecx
  81ea15:	mov    0x244(%rsp),%rax
  81ea1d:	cmp    $0xffffffff,%ecx
  81ea20:	jne    81f332 <<gpui_gpu::renderer::RendererState>::render+0x1312>
  81ea26:	mov    %eax,%ecx
  81ea28:	shr    $0x20,%rax
  81ea2c:	movd   %ecx,%xmm0
  81ea30:	movaps 0x70(%rsp),%xmm2
  81ea35:	movaps %xmm2,%xmm1
  81ea38:	maxss  %xmm0,%xmm1
  81ea3c:	movaps %xmm1,%xmm3
  81ea3f:	cmpunordss %xmm1,%xmm3
  81ea44:	movaps %xmm3,%xmm0
  81ea47:	andnps %xmm1,%xmm0
  81ea4a:	andps  %xmm2,%xmm3
  81ea4d:	orps   %xmm0,%xmm3
  81ea50:	movaps %xmm3,0xc0(%rsp)
  81ea58:	movd   %eax,%xmm0
  81ea5c:	movaps 0x40(%rsp),%xmm2
  81ea61:	movaps %xmm2,%xmm1
  81ea64:	maxss  %xmm0,%xmm1
  81ea68:	movaps %xmm1,%xmm3
  81ea6b:	cmpunordss %xmm1,%xmm3
  81ea70:	movaps %xmm3,%xmm0
  81ea73:	andnps %xmm1,%xmm0
  81ea76:	andps  %xmm2,%xmm3
  81ea79:	orps   %xmm0,%xmm3
  81ea7c:	movaps %xmm3,0xb0(%rsp)
  81ea84:	lea    0x3a0(%rsp),%rdi
  81ea8c:	lea    0x490(%rsp),%rsi
  81ea94:	call   821c20 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81ea99:	cmpb   $0xff,0x3a8(%rsp)
  81eaa1:	movdqa 0xc0(%rsp),%xmm1
  81eaaa:	movdqa %xmm1,0x70(%rsp)
  81eab0:	movdqa 0xb0(%rsp),%xmm2
  81eab9:	movdqa %xmm2,0x40(%rsp)
  81eabf:	jne    81e957 <<gpui_gpu::renderer::RendererState>::render+0x937>
  81eac5:	movdqa %xmm1,%xmm0
  81eac9:	movd   %xmm0,%ecx
  81eacd:	movd   %xmm2,%eax
  81ead1:	shl    $0x20,%rax
  81ead5:	or     %rax,%rcx
  81ead8:	mov    %rcx,0xf8(%rsp)
  81eae0:	jmp    81eafc <<gpui_gpu::renderer::RendererState>::render+0xadc>
  81eae2:	movq   $0x0,0xf8(%rsp)
  81eaee:	jmp    81eb14 <<gpui_gpu::renderer::RendererState>::render+0xaf4>
  81eaf0:	movq   $0x0,0xf8(%rsp)
  81eafc:	incq   0x2a8(%rsp)
  81eb04:	mov    0xe0(%rsp),%rax
  81eb0c:	add    %rax,0x2b0(%rsp)
  81eb14:	mov    0xa8(%rsp),%rax
  81eb1c:	mov    %rax,0x240(%rsp)
  81eb24:	mov    %rbx,0x248(%rsp)
  81eb2c:	mov    0x28(%rsp),%rax
  81eb31:	mov    %rax,0x250(%rsp)
  81eb39:	movq   $0x0,0x258(%rsp)
  81eb45:	lea    0x3a0(%rsp),%rdi
  81eb4d:	lea    0x240(%rsp),%rsi
  81eb55:	call   821c20 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81eb5a:	movzbl 0x3a8(%rsp),%eax
  81eb62:	cmp    $0xff,%al
  81eb64:	je     81f228 <<gpui_gpu::renderer::RendererState>::render+0x1208>
  81eb6a:	mov    %eax,%r8d
  81eb6d:	mov    0x10(%rsp),%rax
  81eb72:	lea    0x8(,%rax,8),%rax
  81eb7a:	mov    %rax,0x128(%rsp)
  81eb82:	mov    0x20(%rsp),%rax
  81eb87:	mov    %rax,0x80(%rsp)
  81eb8f:	mov    0x3a0(%rsp),%rax
  81eb97:	movups 0x3e0(%rsp),%xmm3
  81eb9f:	lea    0x3a8(%rsp),%rsi
  81eba7:	movups 0x48(%rsi),%xmm0
  81ebab:	lea    0x518(%rsp),%rdi
  81ebb3:	movups %xmm0,0x40(%rdi)
  81ebb7:	mov    0x1(%rsi),%ecx
  81ebba:	mov    0x4(%rsi),%edx
  81ebbd:	mov    %edx,-0x44(%rdi)
  81ebc0:	mov    %ecx,-0x47(%rdi)
  81ebc3:	mov    0x3b0(%rsp),%rdx
  81ebcb:	mov    0x30(%rsi),%rcx
  81ebcf:	mov    %rcx,-0x18(%rdi)
  81ebd3:	movups 0x10(%rsi),%xmm0
  81ebd7:	movups 0x20(%rsi),%xmm1
  81ebdb:	movups %xmm1,-0x28(%rdi)
  81ebdf:	movups %xmm0,-0x38(%rdi)
  81ebe3:	movaps 0x270(%rsp),%xmm0
  81ebeb:	movaps 0x280(%rsp),%xmm1
  81ebf3:	movaps 0x290(%rsp),%xmm2
  81ebfb:	movups %xmm2,0x20(%rdi)
  81ebff:	movups %xmm1,0x10(%rdi)
  81ec03:	movups %xmm0,(%rdi)
  81ec06:	movaps 0x330(%rsp),%xmm0
  81ec0e:	movups %xmm0,0x30(%rdi)
  81ec12:	movaps 0x320(%rsp),%xmm0
  81ec1a:	movups %xmm0,0x50(%rdi)
  81ec1e:	movaps %xmm3,0xc0(%rsp)
  81ec26:	movups %xmm3,0x508(%rsp)
  81ec2e:	mov    %r8b,0x70(%rsp)
  81ec33:	mov    %r8b,0x4d0(%rsp)
  81ec3b:	mov    %rdx,0x310(%rsp)
  81ec43:	mov    %rdx,0x4d8(%rsp)
  81ec4b:	cmpb   $0x0,0x1f(%rsp)
  81ec50:	je     81ec98 <<gpui_gpu::renderer::RendererState>::render+0xc78>
  81ec52:	mov    0xf8(%rsp),%rcx
  81ec5a:	mov    %rcx,0x40(%rsp)
  81ec5f:	mov    0x20(%rsp),%rcx
  81ec64:	mov    %rcx,0xb0(%rsp)
  81ec6c:	test   %rax,%rax
  81ec6f:	je     81ece8 <<gpui_gpu::renderer::RendererState>::render+0xcc8>
  81ec71:	mov    0xf8(%rsp),%rax
  81ec79:	mov    %rax,0x40(%rsp)
  81ec7e:	mov    0x20(%rsp),%rax
  81ec83:	mov    %rax,0xb0(%rsp)
  81ec8b:	lea    0x130(%rsp),%rbx
  81ec93:	jmp    81f000 <<gpui_gpu::renderer::RendererState>::render+0xfe0>
  81ec98:	lea    0x130(%rsp),%rdi
  81eca0:	lea    0x4d0(%rsp),%rsi
  81eca8:	mov    0x88(%rsp),%rdx
  81ecb0:	mov    %r14d,%ecx
  81ecb3:	mov    %r15d,%r8d
  81ecb6:	call   8215e0 <gpui_gpu::renderer::validate_draw>
  81ecbb:	mov    0x130(%rsp),%eax
  81ecc2:	mov    0x134(%rsp),%rcx
  81ecca:	mov    %rcx,0x40(%rsp)
  81eccf:	cmp    $0xffffffff,%eax
  81ecd2:	jne    81f3c0 <<gpui_gpu::renderer::RendererState>::render+0x13a0>
  81ecd8:	mov    0x80(%rsp),%rax
  81ece0:	mov    %rax,0xb0(%rsp)
  81ece8:	cmpb   $0x3,0x70(%rsp)
  81eced:	jne    81ed82 <<gpui_gpu::renderer::RendererState>::render+0xd62>
  81ecf3:	movss  0x4d4(%rsp),%xmm0
  81ecfc:	xorps  %xmm1,%xmm1
  81ecff:	ucomiss %xmm1,%xmm0
  81ed02:	jne    81ed06 <<gpui_gpu::renderer::RendererState>::render+0xce6>
  81ed04:	jnp    81ed82 <<gpui_gpu::renderer::RendererState>::render+0xd62>
  81ed06:	movaps 0xc0(%rsp),%xmm5
  81ed0e:	movaps %xmm5,%xmm1
  81ed11:	unpckhpd %xmm5,%xmm1
  81ed15:	movss  -0x76fd51(%rip),%xmm4        # aefcc <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  81ed1d:	mulss  %xmm4,%xmm1
  81ed21:	movaps %xmm0,%xmm2
  81ed24:	minss  %xmm1,%xmm2
  81ed28:	movaps %xmm2,%xmm1
  81ed2b:	cmpunordss %xmm2,%xmm1
  81ed30:	movaps %xmm1,%xmm3
  81ed33:	andnps %xmm2,%xmm3
  81ed36:	andps  %xmm0,%xmm1
  81ed39:	orps   %xmm3,%xmm1
  81ed3c:	movaps %xmm5,%xmm0
  81ed3f:	shufps $0xff,%xmm5,%xmm0
  81ed43:	mulss  %xmm4,%xmm0
  81ed47:	movaps %xmm1,%xmm2
  81ed4a:	minss  %xmm0,%xmm2
  81ed4e:	movaps %xmm2,%xmm0
  81ed51:	cmpunordss %xmm2,%xmm0
  81ed56:	andps  %xmm0,%xmm1
  81ed59:	andnps %xmm2,%xmm0
  81ed5c:	orps   %xmm1,%xmm0
  81ed5f:	movd   %xmm0,%eax
  81ed63:	mov    %eax,0x260(%rsp)
  81ed6a:	and    $0xff800000,%eax
  81ed6f:	mov    $0x7f000000,%ecx
  81ed74:	sub    %eax,%ecx
  81ed76:	mov    %ecx,0xd8(%rsp)
  81ed7d:	xorps  %xmm0,%xmm0
  81ed80:	jmp    81eda7 <<gpui_gpu::renderer::RendererState>::render+0xd87>
  81ed82:	mov    0x568(%rsp),%eax
  81ed89:	mov    %eax,0x260(%rsp)
  81ed90:	mov    0x56c(%rsp),%eax
  81ed97:	mov    %eax,0xd8(%rsp)
  81ed9e:	movsd  0x570(%rsp),%xmm0
  81eda7:	movaps %xmm0,0x300(%rsp)
  81edaf:	movups 0x518(%rsp),%xmm0
  81edb7:	movaps %xmm0,0x470(%rsp)
  81edbf:	movups 0x520(%rsp),%xmm0
  81edc7:	movaps %xmm0,0x390(%rsp)
  81edcf:	movsd  0x528(%rsp),%xmm0
  81edd8:	movaps %xmm0,0x220(%rsp)
  81ede0:	movsd  0x530(%rsp),%xmm0
  81ede9:	movaps %xmm0,0x2f0(%rsp)
  81edf1:	movsd  0x538(%rsp),%xmm0
  81edfa:	movsd  %xmm0,0x98(%rsp)
  81ee03:	movsd  0x540(%rsp),%xmm0
  81ee0c:	movsd  %xmm0,0x2c8(%rsp)
  81ee15:	movups 0x548(%rsp),%xmm0
  81ee1d:	movaps %xmm0,0x480(%rsp)
  81ee25:	mov    0x28(%rsp),%rax
  81ee2a:	mov    %rax,0x130(%rsp)
  81ee32:	mov    0xa8(%rsp),%rax
  81ee3a:	mov    %rax,0x138(%rsp)
  81ee42:	mov    0xe0(%rsp),%rax
  81ee4a:	mov    %rax,0x140(%rsp)
  81ee52:	movaps 0x270(%rsp),%xmm0
  81ee5a:	movaps 0x280(%rsp),%xmm1
  81ee62:	movaps 0x290(%rsp),%xmm2
  81ee6a:	lea    0x148(%rsp),%rcx
  81ee72:	movups %xmm2,0x20(%rcx)
  81ee76:	movups %xmm1,0x10(%rcx)
  81ee7a:	movups %xmm0,(%rcx)
  81ee7d:	movaps 0x330(%rsp),%xmm0
  81ee85:	lea    0x178(%rsp),%rax
  81ee8d:	movups %xmm0,(%rax)
  81ee90:	movaps 0x320(%rsp),%xmm0
  81ee98:	movups %xmm0,0x40(%rcx)
  81ee9c:	lea    0x130(%rsp),%rdi
  81eea4:	call   *0x6611d6(%rip)        # e80080 <_DYNAMIC+0x5c0>
  81eeaa:	test   %eax,%eax
  81eeac:	je     81eeda <<gpui_gpu::renderer::RendererState>::render+0xeba>
  81eeae:	mov    0x2c0(%rsp),%rdi
  81eeb6:	mov    %eax,%esi
  81eeb8:	call   825830 <gpui_gpu::renderer::slots::color_word>
  81eebd:	mov    %eax,0x260(%rsp)
  81eec4:	xorps  %xmm0,%xmm0
  81eec7:	movaps %xmm0,0x300(%rsp)
  81eecf:	movl   $0x0,0xd8(%rsp)
  81eeda:	movsd  0x2c8(%rsp),%xmm0
  81eee3:	cvtsd2ss %xmm0,%xmm0
  81eee7:	movapd 0x390(%rsp),%xmm1
  81eef0:	unpcklpd 0x2f0(%rsp),%xmm1
  81eef9:	cvtpd2ps %xmm1,%xmm1
  81eefd:	movsd  0x98(%rsp),%xmm2
  81ef06:	cvtsd2ss %xmm2,%xmm2
  81ef0a:	movapd 0x470(%rsp),%xmm3
  81ef13:	unpcklpd 0x220(%rsp),%xmm3
  81ef1c:	cvtpd2ps %xmm3,%xmm3
  81ef20:	mov    0x40(%rsp),%rcx
  81ef25:	mov    %rcx,%rax
  81ef28:	shr    $0x20,%rax
  81ef2c:	mov    0x8(%rsp),%rdx
  81ef31:	mov    0x8(%rdx),%rsi
  81ef35:	mov    0x10(%rdx),%rdx
  81ef39:	movlpd %xmm3,0x130(%rsp)
  81ef42:	movss  %xmm2,0x138(%rsp)
  81ef4b:	mov    %ecx,0x13c(%rsp)
  81ef52:	movlpd %xmm1,0x140(%rsp)
  81ef5b:	movss  %xmm0,0x148(%rsp)
  81ef64:	mov    %eax,0x14c(%rsp)
  81ef6b:	lea    0x2d0(%rsp),%rdi
  81ef73:	mov    0x80(%rsp),%r13
  81ef7b:	mov    %r13,%rcx
  81ef7e:	lea    0x130(%rsp),%rbx
  81ef86:	mov    %rbx,%r8
  81ef89:	call   81b6a0 <<gpui_gpu::renderer::Changes>::replace::<2>>
  81ef8e:	mov    0x8(%rsp),%rax
  81ef93:	mov    0x8(%rax),%rsi
  81ef97:	mov    0x10(%rax),%rdx
  81ef9b:	mov    0x110(%rsp),%rax
  81efa3:	lea    0x0(%r13,%rax,1),%rcx
  81efa8:	movaps 0x480(%rsp),%xmm0
  81efb0:	movaps %xmm0,0x130(%rsp)
  81efb8:	mov    0x260(%rsp),%eax
  81efbf:	mov    %eax,0x140(%rsp)
  81efc6:	mov    0xd8(%rsp),%eax
  81efcd:	mov    %eax,0x144(%rsp)
  81efd4:	movaps 0x300(%rsp),%xmm0
  81efdc:	movlps %xmm0,0x148(%rsp)
  81efe4:	lea    0x2d0(%rsp),%rdi
  81efec:	mov    %rbx,%r8
  81efef:	call   81b6a0 <<gpui_gpu::renderer::Changes>::replace::<2>>
  81eff4:	add    $0x2,%r13
  81eff8:	mov    %r13,0x80(%rsp)
  81f000:	cmpb   $0x2,0x70(%rsp)
  81f005:	sete   0x260(%rsp)
  81f00d:	cmpq   $0x0,0x310(%rsp)
  81f016:	setne  0x310(%rsp)
  81f01e:	mov    0x28(%rsp),%rax
  81f023:	mov    %rax,0x130(%rsp)
  81f02b:	mov    0xa8(%rsp),%rax
  81f033:	mov    %rax,0x138(%rsp)
  81f03b:	mov    0xe0(%rsp),%rax
  81f043:	mov    %rax,0x140(%rsp)
  81f04b:	movaps 0x270(%rsp),%xmm0
  81f053:	movdqa 0x280(%rsp),%xmm1
  81f05c:	movdqa 0x290(%rsp),%xmm2
  81f065:	lea    0x148(%rsp),%rcx
  81f06d:	movdqu %xmm2,0x20(%rcx)
  81f072:	movdqu %xmm1,0x10(%rcx)
  81f077:	movups %xmm0,(%rcx)
  81f07a:	movaps 0x330(%rsp),%xmm0
  81f082:	lea    0x178(%rsp),%rax
  81f08a:	movups %xmm0,(%rax)
  81f08d:	movaps 0x320(%rsp),%xmm0
  81f095:	movups %xmm0,0x40(%rcx)
  81f099:	mov    %rbx,%rdi
  81f09c:	call   *0x660fde(%rip)        # e80080 <_DYNAMIC+0x5c0>
  81f0a2:	mov    %eax,0x70(%rsp)
  81f0a6:	mov    0x8(%rsp),%r13
  81f0ab:	mov    0x8(%r13),%rsi
  81f0af:	mov    0x10(%r13),%rdx
  81f0b3:	movdqa 0xc0(%rsp),%xmm0
  81f0bc:	movdqa %xmm0,0x130(%rsp)
  81f0c5:	lea    0x230(%rsp),%rdi
  81f0cd:	mov    %rbx,%r8
  81f0d0:	mov    0x10(%rsp),%rbx
  81f0d5:	mov    %rbx,%rcx
  81f0d8:	call   81b630 <<gpui_gpu::renderer::Changes>::replace::<1>>
  81f0dd:	lea    0x1(%rbx),%rcx
  81f0e1:	mov    0x10(%r13),%rdx
  81f0e5:	cmp    %rdx,%rcx
  81f0e8:	jae    8203d2 <<gpui_gpu::renderer::RendererState>::render+0x23b2>
  81f0ee:	mov    0xb0(%rsp),%rsi
  81f0f6:	mov    %esi,%edi
  81f0f8:	or     $0x80000000,%edi
  81f0fe:	cmpl   $0x0,0x70(%rsp)
  81f103:	cmove  %esi,%edi
  81f106:	mov    0x8(%r13),%rsi
  81f10a:	mov    0x128(%rsp),%r13
  81f112:	mov    0x8(%rsi,%r13,2),%r8d
  81f117:	mov    %r8d,0x138(%rsp)
  81f11f:	mov    (%rsi,%r13,2),%r8
  81f123:	mov    %r8,0x130(%rsp)
  81f12b:	mov    %edi,0x13c(%rsp)
  81f132:	lea    0x230(%rsp),%rdi
  81f13a:	lea    0x130(%rsp),%r8
  81f142:	call   81b630 <<gpui_gpu::renderer::Changes>::replace::<1>>
  81f147:	lea    0x130(%rsp),%rdi
  81f14f:	mov    0x8(%rsp),%rsi
  81f154:	lea    0x4d0(%rsp),%rdx
  81f15c:	mov    0x40(%rsp),%rcx
  81f161:	mov    %rbx,0x10(%rsp)
  81f166:	mov    %ebx,%r8d
  81f169:	mov    0x88(%rsp),%rbx
  81f171:	mov    %rbx,%r9
  81f174:	push   0x118(%rsp)
  81f17b:	push   %r15
  81f17d:	push   %r14
  81f17f:	push   0xa8(%rsp)
  81f186:	call   820450 <<gpui_gpu::renderer::RendererState>::bin_draw>
  81f18b:	add    $0x20,%rsp
  81f18f:	mov    0x130(%rsp),%eax
  81f196:	cmp    $0xffffffff,%eax
  81f199:	jne    81f390 <<gpui_gpu::renderer::RendererState>::render+0x1370>
  81f19f:	movzbl 0x260(%rsp),%ecx
  81f1a7:	and    0x310(%rsp),%cl
  81f1ae:	mov    0x68(%rsp),%rax
  81f1b3:	or     %cl,%al
  81f1b5:	mov    %rax,0x68(%rsp)
  81f1ba:	addq   $0x2,0x10(%rsp)
  81f1c0:	mov    0x138(%rsp),%rax
  81f1c8:	mov    %rax,0x118(%rsp)
  81f1d0:	inc    %rbx
  81f1d3:	mov    %rbx,0x88(%rsp)
  81f1db:	lea    0x3a0(%rsp),%rdi
  81f1e3:	lea    0x240(%rsp),%rsi
  81f1eb:	call   821c20 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81f1f0:	movzbl 0x3a8(%rsp),%r8d
  81f1f9:	add    $0x10,%r13
  81f1fd:	mov    %r13,0x128(%rsp)
  81f205:	cmp    $0xff,%r8b
  81f209:	jne    81eb8f <<gpui_gpu::renderer::RendererState>::render+0xb6f>
  81f20f:	mov    0x68(%rsp),%rax
  81f214:	and    $0x1,%al
  81f216:	mov    %rax,0x68(%rsp)
  81f21b:	mov    0x80(%rsp),%rax
  81f223:	mov    %rax,0x20(%rsp)
  81f228:	lea    0x408(%rsp),%rdi
  81f230:	lea    0x368(%rsp),%rsi
  81f238:	call   *0x660e3a(%rip)        # e80078 <_DYNAMIC+0x5b8>
  81f23e:	mov    0x408(%rsp),%rax
  81f246:	mov    %rax,0x28(%rsp)
  81f24b:	test   %rax,%rax
  81f24e:	jne    81e809 <<gpui_gpu::renderer::RendererState>::render+0x7e9>
  81f254:	jmp    81f28f <<gpui_gpu::renderer::RendererState>::render+0x126f>
  81f256:	movq   $0x0,0x2b0(%rsp)
  81f262:	movq   $0x0,0x2a8(%rsp)
  81f26e:	movq   $0x0,0x88(%rsp)
  81f27a:	movq   $0x0,0x68(%rsp)
  81f283:	movq   $0x0,0x118(%rsp)
  81f28f:	mov    0xa0(%rsp),%rsi
  81f297:	lea    0x8(%rsi),%rdx
  81f29b:	mov    0x8(%rsp),%rax
  81f2a0:	lea    0x258(%rax),%rcx
  81f2a7:	lea    0x328(%rax),%r8
  81f2ae:	mov    0x10(%rax),%r9
  81f2b2:	sub    $0x8,%rsp
  81f2b6:	lea    0x138(%rsp),%rdi
  81f2be:	mov    %rdx,0x2f8(%rsp)
  81f2c6:	mov    %rcx,0xa0(%rsp)
  81f2ce:	mov    %r8,0x488(%rsp)
  81f2d6:	push   0x128(%rsp)
  81f2dd:	call   823980 <gpui_gpu::renderer::images::prepare>
  81f2e2:	add    $0x10,%rsp
  81f2e6:	mov    0x130(%rsp),%eax
  81f2ed:	movzbl 0x134(%rsp),%ecx
  81f2f5:	mov    %cl,0x390(%rsp)
  81f2fc:	cmp    $0xffffffff,%eax
  81f2ff:	je     81f358 <<gpui_gpu::renderer::RendererState>::render+0x1338>
  81f301:	movupd 0x135(%rsp),%xmm0
  81f30a:	movups 0x140(%rsp),%xmm1
  81f312:	mov    0x50(%rsp),%rdi
  81f317:	movups %xmm1,0x10(%rdi)
  81f31b:	movupd %xmm0,0x5(%rdi)
  81f320:	mov    %eax,(%rdi)
  81f322:	movzbl 0x390(%rsp),%eax
  81f32a:	mov    %al,0x4(%rdi)
  81f32d:	jmp    81e1cf <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81f332:	mov    0x25c(%rsp),%edx
  81f339:	mov    0x50(%rsp),%rdi
  81f33e:	mov    %edx,0x1c(%rdi)
  81f341:	movups 0x24c(%rsp),%xmm0
  81f349:	movups %xmm0,0xc(%rdi)
  81f34d:	mov    %ecx,(%rdi)
  81f34f:	mov    %rax,0x4(%rdi)
  81f353:	jmp    81e1cf <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81f358:	movzbl 0x68(%rsp),%r8d
  81f35e:	and    $0x1,%r8d
  81f362:	lea    0x130(%rsp),%rdi
  81f36a:	mov    0x8(%rsp),%rsi
  81f36f:	mov    0xa0(%rsp),%rdx
  81f377:	mov    0x100(%rsp),%rcx
  81f37f:	call   81d780 <<gpui_gpu::renderer::RendererState>::prepare_atlas>
  81f384:	mov    0x130(%rsp),%eax
  81f38b:	cmp    $0xffffffff,%eax
  81f38e:	je     81f3eb <<gpui_gpu::renderer::RendererState>::render+0x13cb>
  81f390:	mov    0x134(%rsp),%ecx
  81f397:	mov    0x138(%rsp),%rdx
  81f39f:	movupd 0x140(%rsp),%xmm0
  81f3a8:	mov    0x50(%rsp),%rdi
  81f3ad:	movupd %xmm0,0x10(%rdi)
  81f3b2:	mov    %eax,(%rdi)
  81f3b4:	mov    %ecx,0x4(%rdi)
  81f3b7:	mov    %rdx,0x8(%rdi)
  81f3bb:	jmp    81e1cf <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81f3c0:	mov    0x14c(%rsp),%ecx
  81f3c7:	mov    0x50(%rsp),%rdi
  81f3cc:	mov    %ecx,0x1c(%rdi)
  81f3cf:	movups 0x13c(%rsp),%xmm0
  81f3d7:	movups %xmm0,0xc(%rdi)
  81f3db:	mov    %eax,(%rdi)
  81f3dd:	mov    0x40(%rsp),%rax
  81f3e2:	mov    %rax,0x4(%rdi)
  81f3e6:	jmp    81e1cf <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81f3eb:	mov    0x138(%rsp),%rax
  81f3f3:	mov    %rax,0x2c8(%rsp)
  81f3fb:	mov    0x8(%rsp),%rax
  81f400:	mov    0x28(%rax),%rax
  81f404:	movq   $0x0,0x220(%rsp)
  81f410:	test   %rax,%rax
  81f413:	je     81f4b8 <<gpui_gpu::renderer::RendererState>::render+0x1498>
  81f419:	mov    0x8(%rsp),%rcx
  81f41e:	mov    0x20(%rcx),%rcx
  81f422:	shl    $0x3,%rax
  81f426:	xor    %edi,%edi
  81f428:	jmp    81f469 <<gpui_gpu::renderer::RendererState>::render+0x1449>
  81f42a:	and    $0x40000000,%edx
  81f430:	mov    0x220(%rsp),%r9
  81f438:	add    %esi,%r9d
  81f43b:	xor    %esi,%esi
  81f43d:	test   %r8d,%r8d
  81f440:	setne  %sil
  81f444:	shl    $0x1d,%esi
  81f447:	or     %r9d,%edx
  81f44a:	or     %esi,%edx
  81f44c:	mov    %r9,0x220(%rsp)
  81f454:	mov    %r9d,(%rcx,%rdi,8)
  81f458:	mov    %edx,%r9d
  81f45b:	mov    %r9d,0x4(%rcx,%rdi,8)
  81f460:	inc    %rdi
  81f463:	add    $0xfffffffffffffff8,%rax
  81f467:	je     81f4a6 <<gpui_gpu::renderer::RendererState>::render+0x1486>
  81f469:	mov    0x8(%rsp),%rdx
  81f46e:	mov    0x58(%rdx),%rsi
  81f472:	cmp    %rsi,%rdi
  81f475:	jae    8203e8 <<gpui_gpu::renderer::RendererState>::render+0x23c8>
  81f47b:	mov    0x4(%rcx,%rdi,8),%edx
  81f47f:	mov    %edx,%esi
  81f481:	and    $0xbfffffff,%esi
  81f487:	mov    0x8(%rsp),%r8
  81f48c:	mov    0x50(%r8),%r8
  81f490:	mov    (%r8,%rdi,4),%r8d
  81f494:	cmp    $0x1,%esi
  81f497:	jne    81f42a <<gpui_gpu::renderer::RendererState>::render+0x140a>
  81f499:	mov    $0x80000000,%r9d
  81f49f:	test   %r8d,%r8d
  81f4a2:	jne    81f45b <<gpui_gpu::renderer::RendererState>::render+0x143b>
  81f4a4:	jmp    81f42a <<gpui_gpu::renderer::RendererState>::render+0x140a>
  81f4a6:	mov    0x220(%rsp),%rax
  81f4ae:	mov    %eax,%eax
  81f4b0:	mov    %rax,0x220(%rsp)
  81f4b8:	mov    0x8(%rsp),%rax
  81f4bd:	lea    0x30(%rax),%rdi
  81f4c1:	movq   $0x0,0x40(%rax)
  81f4c9:	mov    %rdi,0xd8(%rsp)
  81f4d1:	mov    0x220(%rsp),%rsi
  81f4d9:	xor    %edx,%edx
  81f4db:	call   823830 <<alloc::vec::Vec<u32>>::resize>
  81f4e0:	mov    0x88(%rsp),%rax
  81f4e8:	mov    %rax,0x360(%rsp)
  81f4f0:	mov    0x100(%rsp),%rax
  81f4f8:	mov    %rax,0x368(%rsp)
  81f500:	movq   $0x0,0x370(%rsp)
  81f50c:	mov    0x108(%rsp),%rax
  81f514:	mov    %rax,0x378(%rsp)
  81f51c:	mov    0x340(%rsp),%rax
  81f524:	mov    %rax,0x380(%rsp)
  81f52c:	mov    0x30(%rsp),%eax
  81f530:	mov    %eax,0x388(%rsp)
  81f537:	lea    0x408(%rsp),%rdi
  81f53f:	lea    0x368(%rsp),%rsi
  81f547:	call   *0x660b3b(%rip)        # e80088 <_DYNAMIC+0x5c8>
  81f54d:	mov    0x408(%rsp),%rax
  81f555:	mov    %rax,0x80(%rsp)
  81f55d:	test   %rax,%rax
  81f560:	je     81fae8 <<gpui_gpu::renderer::RendererState>::render+0x1ac8>
  81f566:	mov    0x8(%rsp),%rax
  81f56b:	add    $0x120,%rax
  81f571:	mov    %rax,0x470(%rsp)
  81f579:	mov    0x2b8(%rsp),%rax
  81f581:	mov    %rax,0xb0(%rsp)
  81f589:	jmp    81f5ba <<gpui_gpu::renderer::RendererState>::render+0x159a>
  81f58b:	lea    0x408(%rsp),%rdi
  81f593:	lea    0x368(%rsp),%rsi
  81f59b:	call   *0x660ae7(%rip)        # e80088 <_DYNAMIC+0x5c8>
  81f5a1:	mov    0x408(%rsp),%rax
  81f5a9:	mov    %rax,0x80(%rsp)
  81f5b1:	test   %rax,%rax
  81f5b4:	je     81fae8 <<gpui_gpu::renderer::RendererState>::render+0x1ac8>
  81f5ba:	lea    0x420(%rsp),%rsi
  81f5c2:	movups (%rsi),%xmm0
  81f5c5:	movups 0x10(%rsi),%xmm1
  81f5c9:	movups 0x20(%rsi),%xmm2
  81f5cd:	movaps %xmm2,0x3c0(%rsp)
  81f5d5:	movaps %xmm1,0x3b0(%rsp)
  81f5dd:	movaps %xmm0,0x3a0(%rsp)
  81f5e5:	lea    0x450(%rsp),%rdx
  81f5ed:	movups (%rdx),%xmm0
  81f5f0:	movaps %xmm0,0x320(%rsp)
  81f5f8:	movdqu 0x40(%rsi),%xmm0
  81f5fd:	movdqa %xmm0,0x330(%rsp)
  81f606:	mov    0x410(%rsp),%rax
  81f60e:	mov    %rax,0xe0(%rsp)
  81f616:	mov    0x418(%rsp),%rbx
  81f61e:	mov    0x8(%rsp),%rdi
  81f623:	call   81d3a0 <<gpui_gpu::renderer::RendererState>::correction>
  81f628:	mov    %eax,0x300(%rsp)
  81f62f:	test   %rbx,%rbx
  81f632:	je     81f58b <<gpui_gpu::renderer::RendererState>::render+0x156b>
  81f638:	mov    %rbx,%rcx
  81f63b:	shl    $0x2,%rcx
  81f63f:	mov    0x300(%rsp),%eax
  81f646:	shl    $0xf,%eax
  81f649:	mov    %eax,0x20(%rsp)
  81f64d:	mov    0xb0(%rsp),%rax
  81f655:	shl    $0x4,%rax
  81f659:	mov    %rax,0x28(%rsp)
  81f65e:	lea    0x138(%rsp),%rbx
  81f666:	lea    0x130(%rsp),%r13
  81f66e:	jmp    81f837 <<gpui_gpu::renderer::RendererState>::render+0x1817>
  81f673:	mov    0x60(%rsp),%r9d
  81f678:	or     0x20(%rsp),%r9d
  81f67d:	mov    %r9d,0x60(%rsp)
  81f682:	mov    0x64(%rsp),%r8d
  81f687:	mov    %edi,0x130(%rsp)
  81f68e:	mov    %r9d,0x134(%rsp)
  81f696:	mov    %r8d,0x138(%rsp)
  81f69e:	mov    %eax,0x13c(%rsp)
  81f6a5:	lea    0x230(%rsp),%rdi
  81f6ad:	mov    %rbx,%r8
  81f6b0:	call   81b630 <<gpui_gpu::renderer::Changes>::replace::<1>>
  81f6b5:	add    $0xfffffffffffffffe,%r13
  81f6b9:	mov    %r13,0xb0(%rsp)
  81f6c1:	mov    %r13d,0x2ec(%rsp)
  81f6c9:	movaps 0x260(%rsp),%xmm0
  81f6d1:	movlps %xmm0,0x170(%rsp)
  81f6d9:	movaps 0x3a0(%rsp),%xmm0
  81f6e1:	movaps 0x3b0(%rsp),%xmm1
  81f6e9:	movaps 0x3c0(%rsp),%xmm2
  81f6f1:	lea    0x178(%rsp),%rax
  81f6f9:	movups %xmm2,0x20(%rax)
  81f6fd:	movups %xmm1,0x10(%rax)
  81f701:	movups %xmm0,(%rax)
  81f704:	movaps 0x320(%rsp),%xmm0
  81f70c:	movups %xmm0,0x30(%rax)
  81f710:	movaps 0x490(%rsp),%xmm0
  81f718:	movups %xmm0,0x40(%rax)
  81f71c:	movaps 0x330(%rsp),%xmm0
  81f724:	movups %xmm0,0x50(%rax)
  81f728:	mov    0x128(%rsp),%eax
  81f72f:	mov    %al,0x130(%rsp)
  81f736:	movzbl 0x30(%rsp),%eax
  81f73b:	mov    %al,0x131(%rsp)
  81f742:	movzwl 0xa8(%rsp),%eax
  81f74a:	mov    %ax,0x132(%rsp)
  81f752:	movaps 0xc0(%rsp),%xmm0
  81f75a:	movss  %xmm0,0x134(%rsp)
  81f763:	mov    0x250(%rsp),%rax
  81f76b:	mov    %rbx,%r13
  81f76e:	lea    0x138(%rsp),%rbx
  81f776:	mov    %rax,0x10(%rbx)
  81f77a:	movaps 0x240(%rsp),%xmm0
  81f782:	movups %xmm0,(%rbx)
  81f785:	mov    0x10(%rsp),%rax
  81f78a:	mov    %rax,0x150(%rsp)
  81f792:	mov    0x40(%rsp),%eax
  81f796:	mov    %eax,0x158(%rsp)
  81f79d:	mov    0x70(%rsp),%eax
  81f7a1:	mov    %eax,0x15c(%rsp)
  81f7a8:	movdqa 0x310(%rsp),%xmm0
  81f7b1:	movdqu %xmm0,0x160(%rsp)
  81f7ba:	mov    0x4c8(%rsp),%rax
  81f7c2:	mov    %rax,0x270(%rsp)
  81f7ca:	mov    0xd8(%rsp),%rax
  81f7d2:	mov    %rax,0x278(%rsp)
  81f7da:	mov    0x4c0(%rsp),%rax
  81f7e2:	mov    %rax,0x280(%rsp)
  81f7ea:	lea    0x360(%rsp),%rax
  81f7f2:	mov    %rax,0x288(%rsp)
  81f7fa:	lea    0x2ec(%rsp),%rax
  81f802:	mov    %rax,0x290(%rsp)
  81f80a:	mov    %r13,%rdi
  81f80d:	mov    0x90(%rsp),%rsi
  81f815:	lea    0x270(%rsp),%rdx
  81f81d:	call   81c4d0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>>
  81f822:	addq   $0xffffffffffffffe0,0x28(%rsp)
  81f828:	mov    0x68(%rsp),%rcx
  81f82d:	add    $0xfffffffffffffffc,%rcx
  81f831:	je     81f58b <<gpui_gpu::renderer::RendererState>::render+0x156b>
  81f837:	mov    0xe0(%rsp),%rax
  81f83f:	mov    %rcx,0x68(%rsp)
  81f844:	mov    -0x4(%rax,%rcx,1),%edx
  81f848:	mov    %r13,%rdi
  81f84b:	mov    0x80(%rsp),%rsi
  81f853:	call   81c830 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81f858:	movzbl 0x130(%rsp),%ecx
  81f860:	movzbl 0x131(%rsp),%eax
  81f868:	mov    %al,0x30(%rsp)
  81f86c:	movzwl 0x132(%rsp),%eax
  81f874:	mov    %ax,0xa8(%rsp)
  81f87c:	movss  0x134(%rsp),%xmm4
  81f885:	mov    0x10(%rbx),%rax
  81f889:	mov    %rax,0x250(%rsp)
  81f891:	movups (%rbx),%xmm0
  81f894:	movaps %xmm0,0x240(%rsp)
  81f89c:	mov    0x150(%rsp),%rax
  81f8a4:	mov    %rax,0x10(%rsp)
  81f8a9:	mov    0x158(%rsp),%eax
  81f8b0:	mov    %eax,0x40(%rsp)
  81f8b4:	mov    0x15c(%rsp),%eax
  81f8bb:	mov    %eax,0x70(%rsp)
  81f8bf:	movups 0x160(%rsp),%xmm0
  81f8c7:	movaps %xmm0,0x310(%rsp)
  81f8cf:	mov    0x160(%rsp),%rax
  81f8d7:	movsd  0x170(%rsp),%xmm5
  81f8e0:	lea    0x178(%rsp),%rdx
  81f8e8:	movups (%rdx),%xmm0
  81f8eb:	movaps %xmm0,0x490(%rsp)
  81f8f3:	decq   0x360(%rsp)
  81f8fb:	cmp    $0x1,%ecx
  81f8fe:	mov    %ecx,0x128(%rsp)
  81f905:	movaps %xmm4,0xc0(%rsp)
  81f90d:	movaps %xmm5,0x260(%rsp)
  81f915:	je     81f97b <<gpui_gpu::renderer::RendererState>::render+0x195b>
  81f917:	cmp    $0x3,%ecx
  81f91a:	jne    81f9f7 <<gpui_gpu::renderer::RendererState>::render+0x19d7>
  81f920:	mov    0x480(%rsp),%rax
  81f928:	mov    (%rax),%rdi
  81f92b:	test   %rdi,%rdi
  81f92e:	je     82039b <<gpui_gpu::renderer::RendererState>::render+0x237b>
  81f934:	movzbl 0x30(%rsp),%edx
  81f939:	mov    0x10(%rsp),%rsi
  81f93e:	call   823520 <<gpui_gpu::renderer::images::Images>::metadata>
  81f943:	mov    %eax,%ecx
  81f945:	shr    $0x20,%rax
  81f949:	mov    %eax,%edx
  81f94b:	or     $0x10,%edx
  81f94e:	xorps  %xmm0,%xmm0
  81f951:	movaps 0xc0(%rsp),%xmm1
  81f959:	ucomiss %xmm0,%xmm1
  81f95c:	cmovne %edx,%eax
  81f95f:	cmovp  %edx,%eax
  81f962:	mov    0x70(%rsp),%edx
  81f966:	shl    $0x10,%edx
  81f969:	or     0x40(%rsp),%edx
  81f96d:	mov    %ecx,0x5c(%rsp)
  81f971:	mov    %eax,0x60(%rsp)
  81f975:	mov    %edx,0x64(%rsp)
  81f979:	jmp    81f9ea <<gpui_gpu::renderer::RendererState>::render+0x19ca>
  81f97b:	movaps %xmm5,%xmm0
  81f97e:	movss  -0x7709ba(%rip),%xmm3        # aefcc <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  81f986:	mulss  %xmm3,%xmm0
  81f98a:	movaps %xmm4,%xmm1
  81f98d:	minss  %xmm0,%xmm1
  81f991:	movaps %xmm1,%xmm0
  81f994:	cmpunordss %xmm1,%xmm0
  81f999:	movaps %xmm0,%xmm2
  81f99c:	andnps %xmm1,%xmm2
  81f99f:	andps  %xmm4,%xmm0
  81f9a2:	orps   %xmm2,%xmm0
  81f9a5:	movaps %xmm5,%xmm1
  81f9a8:	shufps $0x55,%xmm5,%xmm1
  81f9ac:	mulss  %xmm3,%xmm1
  81f9b0:	movaps %xmm0,%xmm2
  81f9b3:	minss  %xmm1,%xmm2
  81f9b7:	movaps %xmm2,%xmm1
  81f9ba:	cmpunordss %xmm2,%xmm1
  81f9bf:	andps  %xmm1,%xmm0
  81f9c2:	andnps %xmm2,%xmm1
  81f9c5:	orps   %xmm0,%xmm1
  81f9c8:	movd   %xmm1,%eax
  81f9cc:	and    $0xff800000,%eax
  81f9d1:	mov    $0x7f000000,%ecx
  81f9d6:	sub    %eax,%ecx
  81f9d8:	movl   $0x40000000,0x5c(%rsp)
  81f9e0:	movss  %xmm1,0x60(%rsp)
  81f9e6:	mov    %ecx,0x64(%rsp)
  81f9ea:	lea    0x130(%rsp),%rbx
  81f9f2:	jmp    81fa91 <<gpui_gpu::renderer::RendererState>::render+0x1a71>
  81f9f7:	cmp    $0x2,%cl
  81f9fa:	jne    81fa49 <<gpui_gpu::renderer::RendererState>::render+0x1a29>
  81f9fc:	mov    0x250(%rsp),%rcx
  81fa04:	mov    %rcx,0x140(%rsp)
  81fa0c:	movaps 0x240(%rsp),%xmm0
  81fa14:	movaps %xmm0,0x130(%rsp)
  81fa1c:	mov    0x10(%rsp),%rcx
  81fa21:	mov    %rcx,0x148(%rsp)
  81fa29:	mov    0x40(%rsp),%ecx
  81fa2d:	mov    %ecx,0x150(%rsp)
  81fa34:	mov    0x70(%rsp),%ecx
  81fa38:	mov    %ecx,0x154(%rsp)
  81fa3f:	mov    %rax,0x158(%rsp)
  81fa47:	jmp    81fa55 <<gpui_gpu::renderer::RendererState>::render+0x1a35>
  81fa49:	movq   $0x0,0x130(%rsp)
  81fa55:	movl   $0x0,0x278(%rsp)
  81fa60:	movq   $0x0,0x270(%rsp)
  81fa6c:	lea    0x5c(%rsp),%rdi
  81fa71:	lea    0x130(%rsp),%rbx
  81fa79:	mov    %rbx,%rsi
  81fa7c:	lea    0x270(%rsp),%rdx
  81fa84:	mov    0x470(%rsp),%rcx
  81fa8c:	call   81b4e0 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>>
  81fa91:	mov    0xb0(%rsp),%r13
  81fa99:	lea    -0x1(%r13),%rcx
  81fa9d:	mov    0x8(%rsp),%rax
  81faa2:	mov    0x10(%rax),%rdx
  81faa6:	cmp    %rdx,%rcx
  81faa9:	jae    8203bc <<gpui_gpu::renderer::RendererState>::render+0x239c>
  81faaf:	mov    0x8(%rax),%rsi
  81fab3:	mov    0x28(%rsp),%rax
  81fab8:	mov    -0x4(%rsi,%rax,1),%eax
  81fabc:	mov    0x5c(%rsp),%edi
  81fac0:	cmp    $0x40000000,%edi
  81fac6:	jne    81f673 <<gpui_gpu::renderer::RendererState>::render+0x1653>
  81facc:	mov    0x64(%rsp),%r8d
  81fad1:	or     0x300(%rsp),%r8d
  81fad9:	mov    %r8d,0x64(%rsp)
  81fade:	mov    0x60(%rsp),%r9d
  81fae3:	jmp    81f687 <<gpui_gpu::renderer::RendererState>::render+0x1667>
  81fae8:	mov    0x8(%rsp),%rax
  81faed:	mov    0x28(%rax),%rdi
  81faf1:	xor    %ebx,%ebx
  81faf3:	test   %rdi,%rdi
  81faf6:	je     81fc05 <<gpui_gpu::renderer::RendererState>::render+0x1be5>
  81fafc:	mov    0x8(%rsp),%rax
  81fb01:	mov    0x20(%rax),%r8
  81fb05:	shl    $0x3,%rdi
  81fb09:	cmpl   $0x0,0x90(%rsp)
  81fb11:	je     81fe00 <<gpui_gpu::renderer::RendererState>::render+0x1de0>
  81fb17:	movq   $0x0,0x40(%rsp)
  81fb20:	movq   $0x0,0x70(%rsp)
  81fb29:	movq   $0x0,0x10(%rsp)
  81fb32:	xor    %r10d,%r10d
  81fb35:	xor    %ecx,%ecx
  81fb37:	jmp    81fb5f <<gpui_gpu::renderer::RendererState>::render+0x1b3f>
  81fb39:	incq   0x10(%rsp)
  81fb3e:	inc    %r10
  81fb41:	cmp    0x90(%rsp),%r10
  81fb49:	mov    $0x0,%eax
  81fb4e:	cmove  %rax,%r10
  81fb52:	inc    %rcx
  81fb55:	add    $0xfffffffffffffff8,%rdi
  81fb59:	je     81fc20 <<gpui_gpu::renderer::RendererState>::render+0x1c00>
  81fb5f:	mov    0x4(%r8,%rcx,8),%r11d
  81fb64:	mov    $0x80000000,%eax
  81fb69:	cmp    %rax,%r11
  81fb6c:	je     81fb39 <<gpui_gpu::renderer::RendererState>::render+0x1b19>
  81fb6e:	mov    %r11d,%esi
  81fb71:	and    $0x1fffffff,%esi
  81fb77:	sub    (%r8,%rcx,8),%esi
  81fb7b:	je     81fb3e <<gpui_gpu::renderer::RendererState>::render+0x1b1e>
  81fb7d:	mov    %rcx,%rax
  81fb80:	shr    $0x20,%rax
  81fb84:	je     81fb98 <<gpui_gpu::renderer::RendererState>::render+0x1b78>
  81fb86:	mov    %rcx,%rax
  81fb89:	xor    %edx,%edx
  81fb8b:	divq   0x90(%rsp)
  81fb93:	mov    %r10,%rdx
  81fb96:	jmp    81fba3 <<gpui_gpu::renderer::RendererState>::render+0x1b83>
  81fb98:	mov    %ecx,%eax
  81fb9a:	xor    %edx,%edx
  81fb9c:	divl   0x90(%rsp)
  81fba3:	shl    $0x4,%edx
  81fba6:	shl    $0x4,%eax
  81fba9:	lea    0x10(%rdx),%r13d
  81fbad:	cmp    %r13d,%r14d
  81fbb0:	cmovb  %r14d,%r13d
  81fbb4:	lea    0x10(%rax),%r9d
  81fbb8:	cmp    %r9d,%r15d
  81fbbb:	cmovb  %r15d,%r9d
  81fbbf:	sub    %edx,%r13d
  81fbc2:	sub    %eax,%r9d
  81fbc5:	imul   %r13d,%r9d
  81fbc9:	mov    %r9,%rax
  81fbcc:	shl    $0x4,%rax
  81fbd0:	test   $0x40000000,%r11d
  81fbd7:	cmovne %r9,%rax
  81fbdb:	shr    $0x1d,%r11d
  81fbdf:	and    $0x1,%r11d
  81fbe3:	add    %rax,0x70(%rsp)
  81fbe8:	imul   %r11,%r9
  81fbec:	sub    %r11,%rsi
  81fbef:	imul   %rax,%rsi
  81fbf3:	add    0x40(%rsp),%r9
  81fbf8:	add    %rsi,%r9
  81fbfb:	mov    %r9,0x40(%rsp)
  81fc00:	jmp    81fb3e <<gpui_gpu::renderer::RendererState>::render+0x1b1e>
  81fc05:	movq   $0x0,0x10(%rsp)
  81fc0e:	movq   $0x0,0x70(%rsp)
  81fc17:	movq   $0x0,0x40(%rsp)
  81fc20:	test   $0x1,%bpl
  81fc24:	je     81fc71 <<gpui_gpu::renderer::RendererState>::render+0x1c51>
  81fc26:	movd   0x2e8(%rsp),%xmm0
  81fc2f:	movd   %xmm0,%eax
  81fc33:	test   %eax,%eax
  81fc35:	setns  %cl
  81fc38:	mov    %eax,%edx
  81fc3a:	and    $0x7fffffff,%edx
  81fc40:	add    $0xff800000,%edx
  81fc46:	cmp    $0x7f000000,%edx
  81fc4c:	setb   %dl
  81fc4f:	and    %cl,%dl
  81fc51:	dec    %eax
  81fc53:	cmp    $0x7fffff,%eax
  81fc58:	setb   %al
  81fc5b:	or     %dl,%al
  81fc5d:	mov    $0x2,%ebx
  81fc62:	movd   %xmm0,0xf4(%rsp)
  81fc6b:	je     81fdf6 <<gpui_gpu::renderer::RendererState>::render+0x1dd6>
  81fc71:	mov    0x120(%rsp),%rax
  81fc79:	add    $0x18,%rax
  81fc7d:	xor    %ecx,%ecx
  81fc7f:	cmpl   $0x28,0x2e4(%rsp)
  81fc87:	sete   %cl
  81fc8a:	and    $0x1,%r12d
  81fc8e:	lea    (%r12,%rcx,4),%ecx
  81fc92:	or     %ebx,%ecx
  81fc94:	movups (%rax),%xmm0
  81fc97:	movups %xmm0,0x418(%rsp)
  81fc9f:	mov    %r14d,0x408(%rsp)
  81fca7:	mov    %r15d,0x40c(%rsp)
  81fcaf:	mov    0x90(%rsp),%rax
  81fcb7:	mov    %eax,0x410(%rsp)
  81fcbe:	mov    %ecx,0x414(%rsp)
  81fcc5:	movss  0xf4(%rsp),%xmm0
  81fcce:	movss  %xmm0,0x428(%rsp)
  81fcd7:	mov    0x110(%rsp),%rax
  81fcdf:	mov    %eax,0x42c(%rsp)
  81fce6:	movq   $0x0,0x430(%rsp)
  81fcf2:	mov    0x8(%rsp),%rax
  81fcf7:	lea    0x230(%rax),%rsi
  81fcfe:	lea    0x408(%rsp),%rcx
  81fd06:	mov    $0x30,%r8d
  81fd0c:	mov    0x2f0(%rsp),%rdi
  81fd14:	mov    %rsi,0x30(%rsp)
  81fd19:	xor    %edx,%edx
  81fd1b:	call   *0x66036f(%rip)        # e80090 <_DYNAMIC+0x5d0>
  81fd21:	mov    0x2b8(%rsp),%rbx
  81fd29:	shl    $0x4,%rbx
  81fd2d:	mov    0x98(%rsp),%rdi
  81fd35:	mov    0xa0(%rsp),%rsi
  81fd3d:	mov    %rbx,%rdx
  81fd40:	call   81cb80 <<gpui_gpu::renderer::Buffer>::reserve>
  81fd45:	cmpq   $0x0,0x38(%rsp)
  81fd4b:	je     81fdc3 <<gpui_gpu::renderer::RendererState>::render+0x1da3>
  81fd4d:	mov    0x2b8(%rsp),%rcx
  81fd55:	cmp    %rcx,0x348(%rsp)
  81fd5d:	jne    81fdc3 <<gpui_gpu::renderer::RendererState>::render+0x1da3>
  81fd5f:	test   %al,%al
  81fd61:	jne    81fdc3 <<gpui_gpu::renderer::RendererState>::render+0x1da3>
  81fd63:	testb  $0x1,0x390(%rsp)
  81fd6b:	jne    81fdc3 <<gpui_gpu::renderer::RendererState>::render+0x1da3>
  81fd6d:	mov    0x2d8(%rsp),%rax
  81fd75:	mov    0x230(%rsp),%rbx
  81fd7d:	mov    0x238(%rsp),%rsi
  81fd85:	cmp    %rbx,%rax
  81fd88:	jne    81fe4c <<gpui_gpu::renderer::RendererState>::render+0x1e2c>
  81fd8e:	mov    %rsi,0x2d8(%rsp)
  81fd96:	movq   $0xffffffffffffffff,0x230(%rsp)
  81fda2:	movq   $0x0,0x238(%rsp)
  81fdae:	mov    $0xffffffffffffffff,%rbx
  81fdb5:	movq   $0x0,0x38(%rsp)
  81fdbe:	jmp    81fe54 <<gpui_gpu::renderer::RendererState>::render+0x1e34>
  81fdc3:	mov    0x8(%rsp),%rax
  81fdc8:	mov    0x8(%rax),%rcx
  81fdcc:	mov    0x10(%rax),%r8
  81fdd0:	shl    $0x4,%r8
  81fdd4:	mov    0x98(%rsp),%rdi
  81fddc:	mov    0xa0(%rsp),%rsi
  81fde4:	mov    0x2f0(%rsp),%rdx
  81fdec:	call   81cb30 <<gpui_gpu::renderer::Buffer>::write>
  81fdf1:	jmp    81feb2 <<gpui_gpu::renderer::RendererState>::render+0x1e92>
  81fdf6:	mov    0x50(%rsp),%rdi
  81fdfb:	jmp    81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81fe00:	movq   $0x0,0x70(%rsp)
  81fe09:	xor    %eax,%eax
  81fe0b:	movq   $0x0,0x10(%rsp)
  81fe14:	jmp    81fe28 <<gpui_gpu::renderer::RendererState>::render+0x1e08>
  81fe16:	incq   0x10(%rsp)
  81fe1b:	add    $0x8,%rax
  81fe1f:	cmp    %rax,%rdi
  81fe22:	je     81fc17 <<gpui_gpu::renderer::RendererState>::render+0x1bf7>
  81fe28:	mov    0x4(%r8,%rax,1),%ecx
  81fe2d:	mov    %ecx,%edx
  81fe2f:	neg    %edx
  81fe31:	jo     81fe16 <<gpui_gpu::renderer::RendererState>::render+0x1df6>
  81fe33:	and    $0x1fffffff,%ecx
  81fe39:	cmp    %ecx,(%r8,%rax,1)
  81fe3d:	je     81fe1b <<gpui_gpu::renderer::RendererState>::render+0x1dfb>
  81fe3f:	lea    0x60e912(%rip),%rdi        # e2e758 <anon.36d49f465d299f05a84fba3771e6457e.32.llvm.13987519659127932268+0x10>
  81fe46:	call   *0x66024c(%rip)        # e80098 <_DYNAMIC+0x5d8>
  81fe4c:	mov    %rsi,0x38(%rsp)
  81fe51:	mov    %rax,%rsi
  81fe54:	mov    0x8(%rsp),%r13
  81fe59:	mov    0x8(%r13),%rdx
  81fe5d:	mov    0x10(%r13),%rcx
  81fe61:	mov    0x2d0(%rsp),%rdi
  81fe69:	mov    0x98(%rsp),%rbp
  81fe71:	mov    %rbp,%r8
  81fe74:	mov    0x2f0(%rsp),%r12
  81fe7c:	mov    %r12,%r9
  81fe7f:	call   81cad0 <<gpui_gpu::renderer::Changes>::upload>
  81fe84:	mov    %rax,0xc0(%rsp)
  81fe8c:	mov    0x8(%r13),%rdx
  81fe90:	mov    0x10(%r13),%rcx
  81fe94:	mov    %rbx,%rdi
  81fe97:	mov    0x38(%rsp),%rsi
  81fe9c:	mov    %rbp,%r8
  81fe9f:	mov    %r12,%r9
  81fea2:	call   81cad0 <<gpui_gpu::renderer::Changes>::upload>
  81fea7:	mov    %rax,%rbx
  81feaa:	add    0xc0(%rsp),%rbx
  81feb2:	mov    0xa0(%rsp),%r13
  81feba:	lea    0x18(%r13),%rax
  81febe:	mov    %rax,0x38(%rsp)
  81fec3:	mov    0x8(%rsp),%rbp
  81fec8:	lea    0x280(%rbp),%rdi
  81fecf:	mov    0x20(%rbp),%rcx
  81fed3:	mov    0x28(%rbp),%r8
  81fed7:	shl    $0x3,%r8
  81fedb:	mov    %rdi,0xc0(%rsp)
  81fee3:	mov    %r13,%rsi
  81fee6:	mov    0x2f0(%rsp),%r12
  81feee:	mov    %r12,%rdx
  81fef1:	call   81cb30 <<gpui_gpu::renderer::Buffer>::write>
  81fef6:	lea    0x2a8(%rbp),%rdi
  81fefd:	mov    0x38(%rbp),%rcx
  81ff01:	mov    0x40(%rbp),%r8
  81ff05:	shl    $0x2,%r8
  81ff09:	mov    %rdi,0xb0(%rsp)
  81ff11:	mov    %r13,%rsi
  81ff14:	mov    %r12,%rdx
  81ff17:	call   81cb30 <<gpui_gpu::renderer::Buffer>::write>
  81ff1c:	lea    0x2d0(%rbp),%rdi
  81ff23:	mov    0x68(%rbp),%rcx
  81ff27:	mov    0x70(%rbp),%r8
  81ff2b:	shl    $0x5,%r8
  81ff2f:	mov    %rdi,0x28(%rsp)
  81ff34:	mov    %r13,%rsi
  81ff37:	mov    %r12,%rdx
  81ff3a:	call   81cb30 <<gpui_gpu::renderer::Buffer>::write>
  81ff3f:	cmpq   $0x0,0x328(%rbp)
  81ff47:	je     81ff4d <<gpui_gpu::renderer::RendererState>::render+0x1f2d>
  81ff49:	xor    %eax,%eax
  81ff4b:	jmp    81ff62 <<gpui_gpu::renderer::RendererState>::render+0x1f42>
  81ff4d:	mov    0x8(%rsp),%rax
  81ff52:	mov    0x10(%rax),%rax
  81ff56:	cmp    $0x1,%rax
  81ff5a:	adc    $0x0,%rax
  81ff5e:	shl    $0x4,%rax
  81ff62:	mov    0x8(%rsp),%rdi
  81ff67:	mov    0x28(%rdi),%rsi
  81ff6b:	mov    0x40(%rdi),%rcx
  81ff6f:	cmp    $0x1,%rsi
  81ff73:	adc    $0x0,%rsi
  81ff77:	shl    $0x3,%rsi
  81ff7b:	cmp    $0x1,%rcx
  81ff7f:	adc    $0x0,%rcx
  81ff83:	mov    0x70(%rdi),%rdx
  81ff87:	cmp    $0x1,%rdx
  81ff8b:	adc    $0x0,%rdx
  81ff8f:	add    $0xc8,%rdi
  81ff96:	shl    $0x2,%rcx
  81ff9a:	shl    $0x5,%rdx
  81ff9e:	movq   $0x0,0x130(%rsp)
  81ffaa:	mov    0x30(%rsp),%r8
  81ffaf:	mov    %r8,0x138(%rsp)
  81ffb7:	movq   $0x0,0x158(%rsp)
  81ffc3:	xorpd  %xmm0,%xmm0
  81ffc7:	movupd %xmm0,0x140(%rsp)
  81ffd0:	movl   $0x0,0x150(%rsp)
  81ffdb:	mov    0x98(%rsp),%r8
  81ffe3:	mov    %r8,0x160(%rsp)
  81ffeb:	movq   $0x0,0x168(%rsp)
  81fff7:	mov    %rax,0x170(%rsp)
  81ffff:	movl   $0x1,0x178(%rsp)
  82000a:	movq   $0x0,0x180(%rsp)
  820016:	mov    0xc0(%rsp),%rax
  82001e:	mov    %rax,0x188(%rsp)
  820026:	movq   $0x0,0x190(%rsp)
  820032:	mov    %rsi,0x198(%rsp)
  82003a:	movl   $0x2,0x1a0(%rsp)
  820045:	movq   $0x0,0x1a8(%rsp)
  820051:	mov    0xb0(%rsp),%rax
  820059:	mov    %rax,0x1b0(%rsp)
  820061:	movq   $0x0,0x1b8(%rsp)
  82006d:	mov    %rcx,0x1c0(%rsp)
  820075:	movl   $0x3,0x1c8(%rsp)
  820080:	movq   $0x4,0x1d0(%rsp)
  82008c:	mov    %rdi,0x1d8(%rsp)
  820094:	movl   $0x4,0x1f0(%rsp)
  82009f:	movq   $0x0,0x1f8(%rsp)
  8200ab:	mov    0x28(%rsp),%rax
  8200b0:	mov    %rax,0x200(%rsp)
  8200b8:	movq   $0x0,0x208(%rsp)
  8200c4:	mov    %rdx,0x210(%rsp)
  8200cc:	movl   $0x5,0x218(%rsp)
  8200d7:	lea    -0x74b546(%rip),%rax        # d4b98 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x122>
  8200de:	mov    %rax,0x3b8(%rsp)
  8200e6:	movq   $0xa,0x3c0(%rsp)
  8200f2:	mov    0x38(%rsp),%rax
  8200f7:	mov    %rax,0x3a0(%rsp)
  8200ff:	lea    0x130(%rsp),%rax
  820107:	mov    %rax,0x3a8(%rsp)
  82010f:	movq   $0x6,0x3b0(%rsp)
  82011b:	lea    0x3a0(%rsp),%rsi
  820123:	mov    0xa0(%rsp),%r13
  82012b:	mov    %r13,%rdi
  82012e:	call   *0x65ff6c(%rip)        # e800a0 <_DYNAMIC+0x5e0>
  820134:	mov    %rax,%rbp
  820137:	mov    %rax,0x270(%rsp)
  82013f:	lea    0x270(%rsp),%rdx
  820147:	mov    %r13,%rdi
  82014a:	mov    0x4b8(%rsp),%rsi
  820152:	call   81d1c0 <<gpui_gpu::renderer::GpuContext>::submit>
  820157:	mov    %rax,0x38(%rsp)
  82015c:	xor    %r13d,%r13d
  82015f:	mov    0x350(%rsp),%rax
  820167:	cmp    %rax,0x358(%rsp)
  82016f:	setne  %r13b
  820173:	shl    $0x1f,%r13d
  820177:	or     %r14d,%r13d
  82017a:	shl    $0x20,%r15
  82017e:	or     %r15,%r13
  820181:	mov    0xe8(%rsp),%rax
  820189:	mov    (%rax),%rax
  82018c:	test   %rax,%rax
  82018f:	je     8201a5 <<gpui_gpu::renderer::RendererState>::render+0x2185>
  820191:	lock decq (%rax)
  820195:	jne    8201a5 <<gpui_gpu::renderer::RendererState>::render+0x2185>
  820197:	mov    0xe8(%rsp),%rdi
  82019f:	call   *0x65fe33(%rip)        # e7ffd8 <_DYNAMIC+0x518>
  8201a5:	mov    0x8(%rsp),%rax
  8201aa:	mov    %rbp,0x330(%rax)
  8201b1:	mov    %r13,0x338(%rax)
  8201b8:	mov    0x28(%rax),%rsi
  8201bc:	mov    0x70(%rax),%rcx
  8201c0:	mov    %rcx,0xe8(%rsp)
  8201c8:	mov    0x278(%rax),%rdx
  8201cf:	mov    0x220(%rsp),%r8
  8201d7:	lea    (%rbx,%r8,4),%rdi
  8201db:	lea    (%rdi,%rsi,8),%rsi
  8201df:	mov    %rcx,%rdi
  8201e2:	shl    $0x5,%rdi
  8201e6:	lea    (%rdi,%rsi,1),%rcx
  8201ea:	add    $0x30,%rcx
  8201ee:	mov    %rcx,0x30(%rsp)
  8201f3:	mov    0x150(%rax),%esi
  8201f9:	imul   %rsi,%rsi
  8201fd:	add    0x250(%rax),%rdx
  820204:	add    0x2a0(%rax),%rdx
  82020b:	add    0x2c8(%rax),%rdx
  820212:	add    0x2f0(%rax),%rdx
  820219:	mov    0x308(%rax),%rdi
  820220:	add    0x310(%rax),%rdi
  820227:	mov    0x118(%rsp),%r11
  82022f:	mov    %r11,%rcx
  820232:	sub    %r8,%rcx
  820235:	mov    0x88(%rsp),%rbp
  82023d:	mov    %rbp,%r9
  820240:	mov    0x2b0(%rsp),%r13
  820248:	sub    %r13,%r9
  82024b:	mov    0x10(%rax),%r10
  82024f:	shl    $0x4,%r10
  820253:	mov    0x160(%rax),%rbx
  82025a:	inc    %rbx
  82025d:	mov    $0xffffffffffffffff,%r14
  820264:	cmovne %rbx,%r14
  820268:	mov    (%rax),%rbx
  82026b:	shl    $0x4,%rbx
  82026f:	mov    0x48(%rax),%r15
  820273:	add    0x30(%rax),%r15
  820277:	mov    0x18(%rax),%r12
  82027b:	lea    (%rbx,%r12,8),%rbx
  82027f:	lea    (%rbx,%r15,4),%rbx
  820283:	mov    0x60(%rax),%r15
  820287:	shl    $0x5,%r15
  82028b:	add    %rbx,%r15
  82028e:	mov    0x138(%rax),%rbx
  820295:	mov    0x130(%rax),%r12
  82029c:	mov    %r14,0x160(%rax)
  8202a3:	mov    %rbp,0x168(%rax)
  8202aa:	lea    (%r11,%r11,1),%r14
  8202ae:	mov    %r14,0x170(%rax)
  8202b5:	movq   $0x1,0x178(%rax)
  8202c0:	mov    %rbp,0x180(%rax)
  8202c7:	mov    %r8,0x188(%rax)
  8202ce:	mov    %r11,0x190(%rax)
  8202d5:	mov    %rcx,0x198(%rax)
  8202dc:	mov    0x10(%rsp),%rcx
  8202e1:	mov    %rcx,0x1a0(%rax)
  8202e8:	mov    0x70(%rsp),%rcx
  8202ed:	mov    %rcx,0x1a8(%rax)
  8202f4:	mov    0x40(%rsp),%rcx
  8202f9:	mov    %rcx,0x1b0(%rax)
  820300:	mov    0x30(%rsp),%rcx
  820305:	mov    %rcx,0x1b8(%rax)
  82030c:	mov    %r10,0x1c0(%rax)
  820313:	mov    0x2a8(%rsp),%r8
  82031b:	mov    %r8,0x1c8(%rax)
  820322:	mov    %r13,0x1d0(%rax)
  820329:	mov    %r9,0x1d8(%rax)
  820330:	mov    0x2c8(%rsp),%rcx
  820338:	mov    %rcx,0x1e0(%rax)
  82033f:	mov    %rdx,0x1e8(%rax)
  820346:	mov    %rsi,0x1f0(%rax)
  82034d:	add    %rbx,%r12
  820350:	mov    %rbx,0x1f8(%rax)
  820357:	mov    %r12,0x200(%rax)
  82035e:	mov    %r15,0x208(%rax)
  820365:	mov    0xe8(%rsp),%rcx
  82036d:	mov    %rcx,0x210(%rax)
  820374:	mov    %rdi,0x218(%rax)
  82037b:	movb   $0x0,0x220(%rax)
  820382:	mov    0x50(%rsp),%rdi
  820387:	mov    0x38(%rsp),%rax
  82038c:	mov    %rax,0x8(%rdi)
  820390:	movl   $0xffffffff,(%rdi)
  820396:	jmp    81e1cf <<gpui_gpu::renderer::RendererState>::render+0x1af>
  82039b:	lea    0x60e1be(%rip),%rdi        # e2e560 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.13987519659127932268+0x18>
  8203a2:	call   *0x65fd00(%rip)        # e800a8 <_DYNAMIC+0x5e8>
  8203a8:	lea    0x60e211(%rip),%rcx        # e2e5c0 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.13987519659127932268+0x78>
  8203af:	xor    %edi,%edi
  8203b1:	mov    0x20(%rsp),%rsi
  8203b6:	call   *0x65fc4c(%rip)        # e80008 <_DYNAMIC+0x548>
  8203bc:	lea    0x60e1b5(%rip),%rax        # e2e578 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.13987519659127932268+0x30>
  8203c3:	mov    %rcx,%rdi
  8203c6:	mov    %rdx,%rsi
  8203c9:	mov    %rax,%rdx
  8203cc:	call   *0x65fbe6(%rip)        # e7ffb8 <_DYNAMIC+0x4f8>
  8203d2:	lea    0x60e1cf(%rip),%rax        # e2e5a8 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.13987519659127932268+0x60>
  8203d9:	mov    %rcx,%rdi
  8203dc:	mov    %rdx,%rsi
  8203df:	mov    %rax,%rdx
  8203e2:	call   *0x65fbd0(%rip)        # e7ffb8 <_DYNAMIC+0x4f8>
  8203e8:	lea    0x60e1a1(%rip),%rdx        # e2e590 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.13987519659127932268+0x48>
  8203ef:	call   *0x65fbc3(%rip)        # e7ffb8 <_DYNAMIC+0x4f8>
  8203f5:	mov    %rax,%r14
  8203f8:	mov    0x8(%rsp),%rax
  8203fd:	mov    %rbp,0x330(%rax)
  820404:	mov    %r13,0x338(%rax)
  82040b:	mov    %r14,%rdi
  82040e:	call   e2c830 <_Unwind_Resume@plt>
  820413:	mov    %rax,%r14
  820416:	lock decq 0x0(%rbp)
  82041b:	jne    820445 <<gpui_gpu::renderer::RendererState>::render+0x2425>
  82041d:	lea    0x270(%rsp),%rdi
  820425:	call   *0x65fbad(%rip)        # e7ffd8 <_DYNAMIC+0x518>
  82042b:	jmp    820445 <<gpui_gpu::renderer::RendererState>::render+0x2425>
  82042d:	call   *0x65f8dd(%rip)        # e7fd10 <_DYNAMIC+0x250>
  820433:	mov    %rax,%r14
  820436:	mov    0xe8(%rsp),%rax
  82043e:	movq   $0x0,(%rax)
  820445:	mov    %r14,%rdi
  820448:	call   e2c830 <_Unwind_Resume@plt>

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000820450 <<gpui_gpu::renderer::RendererState>::bin_draw>:
  820450:	push   %rbp
  820451:	push   %r15
  820453:	push   %r14
  820455:	push   %r13
  820457:	push   %r12
  820459:	push   %rbx
  82045a:	sub    $0x308,%rsp
  820461:	movss  0x88(%rdx),%xmm3
  820469:	movss  -0x771455(%rip),%xmm0        # af01c <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  820471:	movaps %xmm3,%xmm1
  820474:	subss  %xmm0,%xmm1
  820478:	cvttss2si %xmm1,%rax
  82047d:	cvttss2si %xmm3,%r10
  820482:	mov    %r10,%r12
  820485:	sar    $0x3f,%r12
  820489:	and    %rax,%r12
  82048c:	or     %r10,%r12
  82048f:	xor    %eax,%eax
  820491:	xorps  %xmm1,%xmm1
  820494:	ucomiss %xmm1,%xmm3
  820497:	cmovb  %rax,%r12
  82049b:	movss  0x90(%rdx),%xmm4
  8204a3:	movss  -0x77148b(%rip),%xmm2        # af020 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  8204ab:	ucomiss %xmm2,%xmm3
  8204ae:	mov    $0xffffffffffffffff,%r10
  8204b5:	cmova  %r10,%r12
  8204b9:	movaps %xmm4,%xmm3
  8204bc:	subss  %xmm0,%xmm3
  8204c0:	cvttss2si %xmm3,%r11
  8204c5:	cvttss2si %xmm4,%rbx
  8204ca:	mov    %rbx,%r14
  8204cd:	sar    $0x3f,%r14
  8204d1:	and    %r11,%r14
  8204d4:	or     %rbx,%r14
  8204d7:	ucomiss %xmm1,%xmm4
  8204da:	cmovb  %rax,%r14
  8204de:	ucomiss %xmm2,%xmm4
  8204e1:	cmova  %r10,%r14
  8204e5:	movss  0x8c(%rdx),%xmm3
  8204ed:	lea    (%r12,%r14,1),%rbx
  8204f1:	dec    %rbx
  8204f4:	shr    $0x4,%rbx
  8204f8:	shr    $0x4,%r12
  8204fc:	mov    %rbx,%rbp
  8204ff:	sub    %r12,%rbp
  820502:	inc    %rbp
  820505:	movaps %xmm3,%xmm4
  820508:	subss  %xmm0,%xmm4
  82050c:	cvttss2si %xmm4,%r11
  820511:	cvttss2si %xmm3,%r14
  820516:	mov    %r14,%r13
  820519:	sar    $0x3f,%r13
  82051d:	and    %r11,%r13
  820520:	or     %r14,%r13
  820523:	ucomiss %xmm1,%xmm3
  820526:	cmovb  %rax,%r13
  82052a:	ucomiss %xmm2,%xmm3
  82052d:	movss  0x94(%rdx),%xmm3
  820535:	cmova  %r10,%r13
  820539:	movaps %xmm3,%xmm4
  82053c:	subss  %xmm0,%xmm4
  820540:	cvttss2si %xmm4,%r11
  820545:	cvttss2si %xmm3,%r14
  82054a:	mov    %r14,%r15
  82054d:	sar    $0x3f,%r15
  820551:	and    %r11,%r15
  820554:	or     %r14,%r15
  820557:	ucomiss %xmm1,%xmm3
  82055a:	cmovb  %rax,%r15
  82055e:	ucomiss %xmm2,%xmm3
  820561:	cmova  %r10,%r15
  820565:	lea    (%r15,%r13,1),%r10
  820569:	dec    %r10
  82056c:	shr    $0x4,%r10
  820570:	shr    $0x4,%r13
  820574:	mov    %r10,%r11
  820577:	sub    %r13,%r11
  82057a:	inc    %r11
  82057d:	imul   %rbp,%r11
  820581:	add    0x358(%rsp),%r11
  820589:	setb   %al
  82058c:	cmp    $0x400001,%r11
  820593:	setae  %bpl
  820597:	or     %al,%bpl
  82059a:	mov    $0x6,%eax
  82059f:	jne    8205e7 <<gpui_gpu::renderer::RendererState>::bin_draw+0x197>
  8205a1:	mov    %r8d,0xbc(%rsp)
  8205a9:	mov    %r9,0xa0(%rsp)
  8205b1:	mov    %r11,0x1a8(%rsp)
  8205b9:	mov    %rdi,0x1b0(%rsp)
  8205c1:	mov    %r12,0xb0(%rsp)
  8205c9:	cmp    %r13,%r10
  8205cc:	jae    8205fb <<gpui_gpu::renderer::RendererState>::bin_draw+0x1ab>
  8205ce:	mov    0x1b0(%rsp),%rdi
  8205d6:	mov    0x1a8(%rsp),%rax
  8205de:	mov    %rax,0x8(%rdi)
  8205e2:	mov    $0xffffffff,%eax
  8205e7:	mov    %eax,(%rdi)
  8205e9:	add    $0x308,%rsp
  8205f0:	pop    %rbx
  8205f1:	pop    %r12
  8205f3:	pop    %r13
  8205f5:	pop    %r14
  8205f7:	pop    %r15
  8205f9:	pop    %rbp
  8205fa:	ret
  8205fb:	cmp    0xb0(%rsp),%rbx
  820603:	jae    820626 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1d6>
  820605:	data16 cs nopw 0x0(%rax,%rax,1)
  820610:	mov    %r13,%rax
  820613:	cmp    %r10,%r13
  820616:	adc    $0x0,%r13
  82061a:	cmp    %r10,%rax
  82061d:	jae    8205ce <<gpui_gpu::renderer::RendererState>::bin_draw+0x17e>
  82061f:	cmp    %r10,%r13
  820622:	jbe    820610 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1c0>
  820624:	jmp    8205ce <<gpui_gpu::renderer::RendererState>::bin_draw+0x17e>
  820626:	mov    %r10,0x10(%rsp)
  82062b:	movss  0xa4(%rdx),%xmm0
  820633:	ucomiss -0x77185a(%rip),%xmm0        # aede0 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  82063a:	mov    0x340(%rsp),%r9
  820642:	setnp  %r15b
  820646:	sete   %al
  820649:	movd   %xmm0,%r8d
  82064e:	mov    0x98(%rdx),%r10d
  820655:	test   %r10d,%r10d
  820658:	setns  %dil
  82065c:	and    $0x7f800000,%r10d
  820663:	dec    %r10d
  820666:	cmp    $0x7f7fffff,%r10d
  82066d:	setb   %r12b
  820671:	mov    0x9c(%rdx),%r11d
  820678:	test   %r11d,%r11d
  82067b:	setns  %r10b
  82067f:	and    $0x7f800000,%r11d
  820686:	dec    %r11d
  820689:	cmp    $0x7f7fffff,%r11d
  820690:	setb   0xc0(%rsp)
  820698:	mov    0xa0(%rdx),%r11d
  82069f:	test   %r11d,%r11d
  8206a2:	setns  %r14b
  8206a6:	and    $0x7f800000,%r11d
  8206ad:	dec    %r11d
  8206b0:	cmp    $0x7f7fffff,%r11d
  8206b7:	setb   0x160(%rsp)
  8206bf:	test   %r8d,%r8d
  8206c2:	setns  %r11b
  8206c6:	and    $0x7f800000,%r8d
  8206cd:	dec    %r8d
  8206d0:	cmp    $0x7f7fffff,%r8d
  8206d7:	setb   0x150(%rsp)
  8206df:	mov    0x20(%rsi),%rbp
  8206e3:	mov    %rsi,%r8
  8206e6:	mov    0x28(%rsi),%rsi
  8206ea:	mov    %r8,0xd0(%rsp)
  8206f2:	cmpb   $0x1,0x340(%r8)
  8206fa:	jne    8214ce <<gpui_gpu::renderer::RendererState>::bin_draw+0x107e>
  820700:	cmpb   $0x0,(%rdx)
  820703:	jne    8214c7 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1077>
  820709:	mov    %r12b,0xa8(%rsp)
  820711:	test   %r9,%r9
  820714:	je     82155a <<gpui_gpu::renderer::RendererState>::bin_draw+0x110a>
  82071a:	mov    0x350(%rsp),%r12d
  820722:	mov    0x348(%rsp),%r8d
  82072a:	movd   %ecx,%xmm2
  82072e:	shr    $0x20,%rcx
  820732:	movss  0x78(%rdx),%xmm0
  820737:	cvtss2sd %xmm0,%xmm0
  82073b:	movss  0x80(%rdx),%xmm3
  820743:	movss  0x7c(%rdx),%xmm1
  820748:	cvtss2sd %xmm1,%xmm1
  82074c:	movss  0x84(%rdx),%xmm4
  820754:	cvtss2sd %xmm3,%xmm3
  820758:	addsd  %xmm0,%xmm3
  82075c:	movsd  %xmm3,0x1d8(%rsp)
  820765:	xorps  %xmm3,%xmm3
  820768:	cvtss2sd %xmm4,%xmm3
  82076c:	addsd  %xmm1,%xmm3
  820770:	movsd  %xmm3,0x1d0(%rsp)
  820779:	movsd  0x48(%rdx),%xmm5
  82077e:	movsd  0x58(%rdx),%xmm6
  820783:	movsd  0x68(%rdx),%xmm7
  820788:	movss  0x38(%rdx),%xmm3
  82078d:	movss  0x40(%rdx),%xmm4
  820792:	cvtss2sd %xmm3,%xmm3
  820796:	cvtss2sd %xmm4,%xmm4
  82079a:	movaps -0x775972(%rip),%xmm8        # aae30 <GCC_except_table0+0xa8>
  8207a2:	movaps %xmm3,0x90(%rsp)
  8207aa:	andps  %xmm8,%xmm3
  8207ae:	movaps %xmm3,0x80(%rsp)
  8207b6:	movaps %xmm4,0x60(%rsp)
  8207bb:	andps  %xmm8,%xmm4
  8207bf:	movaps %xmm4,0x70(%rsp)
  8207c4:	cvtss2sd %xmm2,%xmm2
  8207c8:	movsd  %xmm2,0x18(%rsp)
  8207ce:	movaps %xmm5,%xmm2
  8207d1:	andps  %xmm8,%xmm2
  8207d5:	movaps %xmm2,0x280(%rsp)
  8207dd:	movaps %xmm6,%xmm2
  8207e0:	andps  %xmm8,%xmm2
  8207e4:	movaps %xmm2,0x260(%rsp)
  8207ec:	movaps %xmm7,%xmm2
  8207ef:	andps  %xmm8,%xmm2
  8207f3:	movaps %xmm2,0x130(%rsp)
  8207fb:	movss  0x3c(%rdx),%xmm2
  820800:	xorps  %xmm3,%xmm3
  820803:	cvtss2sd %xmm2,%xmm3
  820807:	movss  0x44(%rdx),%xmm2
  82080c:	cvtss2sd %xmm2,%xmm2
  820810:	movaps %xmm3,0x50(%rsp)
  820815:	andps  %xmm8,%xmm3
  820819:	movaps %xmm3,0x40(%rsp)
  82081e:	movaps %xmm2,0x20(%rsp)
  820823:	andps  %xmm8,%xmm2
  820827:	movaps %xmm2,0x30(%rsp)
  82082c:	movd   %ecx,%xmm2
  820830:	cvtss2sd %xmm2,%xmm2
  820834:	movsd  %xmm2,0x8(%rsp)
  82083a:	movsd  0x50(%rdx),%xmm2
  82083f:	movaps %xmm2,%xmm3
  820842:	andps  %xmm8,%xmm3
  820846:	movaps %xmm3,0x200(%rsp)
  82084e:	movsd  0x60(%rdx),%xmm3
  820853:	movaps %xmm3,%xmm4
  820856:	andps  %xmm8,%xmm4
  82085a:	movaps %xmm4,0x1e0(%rsp)
  820862:	movsd  0x70(%rdx),%xmm4
  820867:	movaps %xmm4,%xmm9
  82086b:	andps  %xmm8,%xmm9
  82086f:	movaps %xmm9,0xf0(%rsp)
  820878:	and    %r15b,%al
  82087b:	mov    0xd0(%rsp),%rcx
  820883:	mov    0x58(%rcx),%rdx
  820887:	mov    %rdx,0xe8(%rsp)
  82088f:	mov    0x50(%rcx),%rcx
  820893:	mov    %rcx,0x190(%rsp)
  82089b:	mov    0xa0(%rsp),%rcx
  8208a3:	inc    %ecx
  8208a5:	mov    %rcx,0xa0(%rsp)
  8208ad:	or     0xa8(%rsp),%dil
  8208b5:	or     0xc0(%rsp),%r10b
  8208bd:	and    %dil,%r10b
  8208c0:	or     0x160(%rsp),%r14b
  8208c8:	and    %r10b,%r14b
  8208cb:	or     0x150(%rsp),%r11b
  8208d3:	and    %r14b,%r11b
  8208d6:	movaps %xmm2,0x210(%rsp)
  8208de:	cvtsd2ss %xmm2,%xmm2
  8208e2:	xorps  %xmm9,%xmm9
  8208e6:	cvtss2sd %xmm2,%xmm9
  8208eb:	movaps %xmm5,0x290(%rsp)
  8208f3:	movaps %xmm5,%xmm2
  8208f6:	movaps %xmm6,0x270(%rsp)
  8208fe:	movlhps %xmm6,%xmm2
  820901:	cvtpd2ps %xmm2,%xmm2
  820905:	cvtps2pd %xmm2,%xmm5
  820908:	movaps %xmm3,0x1f0(%rsp)
  820910:	xorps  %xmm2,%xmm2
  820913:	cvtsd2ss %xmm3,%xmm2
  820917:	xorps  %xmm3,%xmm3
  82091a:	cvtss2sd %xmm2,%xmm3
  82091e:	movaps %xmm7,0x140(%rsp)
  820926:	xorps  %xmm2,%xmm2
  820929:	cvtsd2ss %xmm7,%xmm2
  82092d:	cvtss2sd %xmm2,%xmm6
  820931:	movaps %xmm4,0x100(%rsp)
  820939:	xorps  %xmm2,%xmm2
  82093c:	cvtsd2ss %xmm4,%xmm2
  820940:	cvtss2sd %xmm2,%xmm2
  820944:	and    %al,%r11b
  820947:	mov    %r11b,0x7(%rsp)
  82094c:	movaps %xmm5,%xmm4
  82094f:	andps  %xmm8,%xmm4
  820953:	movaps %xmm6,0xd0(%rsp)
  82095b:	andps  %xmm8,%xmm6
  82095f:	movaps %xmm6,0xc0(%rsp)
  820967:	movaps %xmm9,0x250(%rsp)
  820970:	andps  %xmm8,%xmm9
  820974:	movaps %xmm9,0x240(%rsp)
  82097d:	movaps %xmm3,0x230(%rsp)
  820985:	andps  %xmm8,%xmm3
  820989:	movaps %xmm3,0x220(%rsp)
  820991:	movaps %xmm2,0x110(%rsp)
  820999:	andps  %xmm2,%xmm8
  82099d:	movaps %xmm8,0x120(%rsp)
  8209a6:	movaps %xmm5,0x160(%rsp)
  8209ae:	movhlps %xmm5,%xmm5
  8209b1:	movaps %xmm5,0x2c0(%rsp)
  8209b9:	movaps %xmm4,0x150(%rsp)
  8209c1:	movhlps %xmm4,%xmm4
  8209c4:	movaps %xmm4,0x2b0(%rsp)
  8209cc:	mov    %r13,%rcx
  8209cf:	mov    0x10(%rsp),%rax
  8209d4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  8209e0:	cmp    %rax,%r13
  8209e3:	adc    $0x0,%rcx
  8209e7:	mov    %rcx,0xa8(%rsp)
  8209ef:	mov    %r13,%r14
  8209f2:	imul   %r9,%r14
  8209f6:	mov    0xb0(%rsp),%rdi
  8209fe:	mov    %rdi,%rcx
  820a01:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  820a10:	cmp    %rbx,%rdi
  820a13:	adc    $0x0,%rcx
  820a17:	lea    (%rdi,%r14,1),%r10
  820a1b:	mov    %r10,%rax
  820a1e:	shr    $0x20,%rax
  820a22:	je     820a30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5e0>
  820a24:	mov    %r10,%rax
  820a27:	xor    %edx,%edx
  820a29:	div    %r9
  820a2c:	jmp    820a38 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5e8>
  820a2e:	xchg   %ax,%ax
  820a30:	mov    %r10d,%eax
  820a33:	xor    %edx,%edx
  820a35:	div    %r9d
  820a38:	shl    $0x4,%edx
  820a3b:	shl    $0x4,%eax
  820a3e:	lea    0x10(%rdx),%r11d
  820a42:	cmp    %r11d,%r8d
  820a45:	cmovb  %r8d,%r11d
  820a49:	lea    0x10(%rax),%r15d
  820a4d:	cmp    %r15d,%r12d
  820a50:	cmovb  %r12d,%r15d
  820a54:	xorps  %xmm12,%xmm12
  820a58:	cvtsi2sd %edx,%xmm12
  820a5d:	ucomisd %xmm12,%xmm0
  820a62:	ja     820aa0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x650>
  820a64:	mov    %eax,%eax
  820a66:	xorps  %xmm2,%xmm2
  820a69:	cvtsi2sd %rax,%xmm2
  820a6e:	ucomisd %xmm2,%xmm1
  820a72:	ja     820aa0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x650>
  820a74:	xorps  %xmm15,%xmm15
  820a78:	cvtsi2sd %r11d,%xmm15
  820a7d:	ucomisd 0x1d8(%rsp),%xmm15
  820a87:	ja     820aa0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x650>
  820a89:	xorps  %xmm13,%xmm13
  820a8d:	cvtsi2sd %r15d,%xmm13
  820a92:	ucomisd 0x1d0(%rsp),%xmm13
  820a9c:	jbe    820ad4 <<gpui_gpu::renderer::RendererState>::bin_draw+0x684>
  820a9e:	xchg   %ax,%ax
  820aa0:	cmp    %rsi,%r10
  820aa3:	jae    82154a <<gpui_gpu::renderer::RendererState>::bin_draw+0x10fa>
  820aa9:	mov    0x4(%rbp,%r10,8),%eax
  820aae:	inc    %eax
  820ab0:	and    $0xbfffffff,%eax
  820ab5:	mov    %eax,0x4(%rbp,%r10,8)
  820aba:	cmp    %rbx,%rdi
  820abd:	jae    8214a0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1050>
  820ac3:	mov    %rcx,%rdi
  820ac6:	cmp    %rbx,%rcx
  820ac9:	jbe    820a10 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5c0>
  820acf:	jmp    8214a0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1050>
  820ad4:	unpcklpd %xmm2,%xmm12
  820ad9:	addpd  -0x7739a2(%rip),%xmm12        # ad140 <anon.a16d5d421a76dfd8c37a17b53540311d.58.llvm.14190004212411149437+0x270>
  820ae2:	movapd %xmm12,%xmm10
  820ae7:	mulpd  0x160(%rsp),%xmm10
  820af1:	movapd %xmm10,%xmm6
  820af6:	unpckhpd %xmm10,%xmm6
  820afb:	movapd %xmm10,%xmm2
  820b00:	addsd  %xmm6,%xmm2
  820b04:	addsd  0xd0(%rsp),%xmm2
  820b0d:	subsd  0x90(%rsp),%xmm2
  820b16:	movapd 0x150(%rsp),%xmm14
  820b20:	mulpd  %xmm12,%xmm14
  820b25:	movapd %xmm14,%xmm9
  820b2a:	unpckhpd %xmm14,%xmm9
  820b2f:	movapd %xmm14,%xmm3
  820b34:	addsd  %xmm9,%xmm3
  820b39:	addsd  0xc0(%rsp),%xmm3
  820b42:	addsd  0x80(%rsp),%xmm3
  820b4b:	addsd  0x70(%rsp),%xmm3
  820b51:	addsd  -0x771281(%rip),%xmm3        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820b59:	mulsd  -0x771301(%rip),%xmm3        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820b61:	addsd  0x18(%rsp),%xmm3
  820b67:	ucomisd %xmm2,%xmm3
  820b6b:	jae    820aa0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x650>
  820b71:	movapd 0x60(%rsp),%xmm4
  820b77:	subsd  %xmm2,%xmm4
  820b7b:	ucomisd %xmm4,%xmm3
  820b7f:	jae    820aa0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x650>
  820b85:	movapd %xmm12,%xmm7
  820b8a:	unpckhpd %xmm12,%xmm7
  820b8f:	movapd 0x270(%rsp),%xmm11
  820b99:	mulsd  %xmm7,%xmm11
  820b9e:	movapd 0x260(%rsp),%xmm3
  820ba7:	mulsd  %xmm7,%xmm3
  820bab:	movapd 0x290(%rsp),%xmm2
  820bb4:	mulsd  %xmm12,%xmm2
  820bb9:	movapd %xmm2,0x180(%rsp)
  820bc2:	addsd  %xmm11,%xmm2
  820bc7:	addsd  0x140(%rsp),%xmm2
  820bd0:	subsd  0x90(%rsp),%xmm2
  820bd9:	movapd 0x280(%rsp),%xmm4
  820be2:	mulsd  %xmm12,%xmm4
  820be7:	movsd  %xmm4,0x1c8(%rsp)
  820bf0:	addsd  %xmm3,%xmm4
  820bf4:	addsd  0x130(%rsp),%xmm4
  820bfd:	addsd  0x80(%rsp),%xmm4
  820c06:	addsd  0x70(%rsp),%xmm4
  820c0c:	addsd  -0x77133c(%rip),%xmm4        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820c14:	mulsd  -0x770de4(%rip),%xmm4        # afe38 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820c1c:	ucomisd %xmm2,%xmm4
  820c20:	jae    820aa0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x650>
  820c26:	movapd 0x60(%rsp),%xmm8
  820c2d:	subsd  %xmm2,%xmm8
  820c32:	ucomisd %xmm8,%xmm4
  820c37:	jae    820aa0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x650>
  820c3d:	movapd %xmm7,%xmm4
  820c41:	mulsd  0x230(%rsp),%xmm4
  820c4a:	movapd %xmm7,%xmm2
  820c4e:	mulsd  0x220(%rsp),%xmm2
  820c57:	movapd %xmm12,%xmm8
  820c5c:	mulsd  0x250(%rsp),%xmm8
  820c66:	movsd  %xmm8,0x1c0(%rsp)
  820c70:	movapd %xmm4,0x170(%rsp)
  820c79:	addsd  %xmm4,%xmm8
  820c7e:	addsd  0x110(%rsp),%xmm8
  820c88:	subsd  0x50(%rsp),%xmm8
  820c8f:	movapd %xmm12,%xmm4
  820c94:	mulsd  0x240(%rsp),%xmm4
  820c9d:	movsd  %xmm4,0x1b8(%rsp)
  820ca6:	addsd  %xmm2,%xmm4
  820caa:	addsd  0x120(%rsp),%xmm4
  820cb3:	addsd  0x40(%rsp),%xmm4
  820cb9:	addsd  0x30(%rsp),%xmm4
  820cbf:	addsd  -0x7713ef(%rip),%xmm4        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820cc7:	mulsd  -0x77146f(%rip),%xmm4        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820ccf:	addsd  0x8(%rsp),%xmm4
  820cd5:	ucomisd %xmm8,%xmm4
  820cda:	jae    820aa0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x650>
  820ce0:	movapd 0x20(%rsp),%xmm5
  820ce6:	subsd  %xmm8,%xmm5
  820ceb:	ucomisd %xmm5,%xmm4
  820cef:	jae    820aa0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x650>
  820cf5:	movapd 0x1f0(%rsp),%xmm4
  820cfe:	mulsd  %xmm7,%xmm4
  820d02:	mulsd  0x1e0(%rsp),%xmm7
  820d0b:	movapd 0x210(%rsp),%xmm8
  820d15:	mulsd  %xmm12,%xmm8
  820d1a:	movapd %xmm8,0x2e0(%rsp)
  820d24:	movapd %xmm4,0x2f0(%rsp)
  820d2d:	addsd  %xmm4,%xmm8
  820d32:	addsd  0x100(%rsp),%xmm8
  820d3c:	subsd  0x50(%rsp),%xmm8
  820d43:	mulsd  0x200(%rsp),%xmm12
  820d4d:	movapd %xmm12,%xmm4
  820d52:	addsd  %xmm7,%xmm4
  820d56:	addsd  0xf0(%rsp),%xmm4
  820d5f:	addsd  0x40(%rsp),%xmm4
  820d65:	addsd  0x30(%rsp),%xmm4
  820d6b:	addsd  -0x77149b(%rip),%xmm4        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820d73:	mulsd  -0x770f43(%rip),%xmm4        # afe38 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820d7b:	ucomisd %xmm8,%xmm4
  820d80:	jae    820aa0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x650>
  820d86:	movapd 0x20(%rsp),%xmm5
  820d8c:	subsd  %xmm8,%xmm5
  820d91:	ucomisd %xmm5,%xmm4
  820d95:	jae    820aa0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x650>
  820d9b:	addsd  -0x7717bc(%rip),%xmm15        # af5e8 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  820da4:	movapd %xmm15,%xmm4
  820da9:	mulsd  0x160(%rsp),%xmm4
  820db2:	movsd  %xmm4,0x1a0(%rsp)
  820dbb:	addsd  %xmm4,%xmm6
  820dbf:	addsd  0xd0(%rsp),%xmm6
  820dc8:	subsd  0x90(%rsp),%xmm6
  820dd1:	movapd 0x150(%rsp),%xmm4
  820dda:	mulsd  %xmm15,%xmm4
  820ddf:	addsd  %xmm4,%xmm9
  820de4:	addsd  0xc0(%rsp),%xmm9
  820dee:	addsd  0x80(%rsp),%xmm9
  820df8:	addsd  0x70(%rsp),%xmm9
  820dff:	addsd  -0x771530(%rip),%xmm9        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820e08:	mulsd  -0x7715b1(%rip),%xmm9        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820e11:	addsd  0x18(%rsp),%xmm9
  820e18:	ucomisd %xmm6,%xmm9
  820e1d:	jae    820aa0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x650>
  820e23:	movapd %xmm4,%xmm5
  820e27:	movapd 0x60(%rsp),%xmm4
  820e2d:	subsd  %xmm6,%xmm4
  820e31:	ucomisd %xmm4,%xmm9
  820e36:	jae    820aa0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x650>
  820e3c:	movapd 0x290(%rsp),%xmm4
  820e45:	mulsd  %xmm15,%xmm4
  820e4a:	movapd %xmm4,0x2d0(%rsp)
  820e53:	addsd  %xmm4,%xmm11
  820e58:	addsd  0x140(%rsp),%xmm11
  820e62:	subsd  0x90(%rsp),%xmm11
  820e6c:	movapd 0x280(%rsp),%xmm4
  820e75:	mulsd  %xmm15,%xmm4
  820e7a:	movsd  %xmm4,0x198(%rsp)
  820e83:	addsd  %xmm4,%xmm3
  820e87:	addsd  0x130(%rsp),%xmm3
  820e90:	addsd  0x80(%rsp),%xmm3
  820e99:	addsd  0x70(%rsp),%xmm3
  820e9f:	addsd  -0x7715cf(%rip),%xmm3        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820ea7:	mulsd  -0x771077(%rip),%xmm3        # afe38 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820eaf:	ucomisd %xmm11,%xmm3
  820eb4:	jae    820aa0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x650>
  820eba:	movapd 0x60(%rsp),%xmm4
  820ec0:	subsd  %xmm11,%xmm4
  820ec5:	ucomisd %xmm4,%xmm3
  820ec9:	jae    820aa0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x650>
  820ecf:	movapd %xmm15,%xmm11
  820ed4:	mulsd  0x250(%rsp),%xmm11
  820ede:	movapd 0x170(%rsp),%xmm6
  820ee7:	addsd  %xmm11,%xmm6
  820eec:	addsd  0x110(%rsp),%xmm6
  820ef5:	subsd  0x50(%rsp),%xmm6
  820efb:	movapd %xmm15,%xmm3
  820f00:	mulsd  0x240(%rsp),%xmm3
  820f09:	movsd  %xmm3,0x170(%rsp)
  820f12:	addsd  %xmm3,%xmm2
  820f16:	addsd  0x120(%rsp),%xmm2
  820f1f:	addsd  0x40(%rsp),%xmm2
  820f25:	addsd  0x30(%rsp),%xmm2
  820f2b:	addsd  -0x77165b(%rip),%xmm2        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820f33:	mulsd  -0x7716db(%rip),%xmm2        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820f3b:	addsd  0x8(%rsp),%xmm2
  820f41:	ucomisd %xmm6,%xmm2
  820f45:	jae    820aa0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x650>
  820f4b:	movapd 0x20(%rsp),%xmm3
  820f51:	subsd  %xmm6,%xmm3
  820f55:	ucomisd %xmm3,%xmm2
  820f59:	jae    820aa0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x650>
  820f5f:	movapd 0x210(%rsp),%xmm2
  820f68:	mulsd  %xmm15,%xmm2
  820f6d:	movapd %xmm2,0x2a0(%rsp)
  820f76:	movapd 0x2f0(%rsp),%xmm4
  820f7f:	addsd  %xmm2,%xmm4
  820f83:	addsd  0x100(%rsp),%xmm4
  820f8c:	subsd  0x50(%rsp),%xmm4
  820f92:	mulsd  0x200(%rsp),%xmm15
  820f9c:	addsd  %xmm15,%xmm7
  820fa1:	addsd  0xf0(%rsp),%xmm7
  820faa:	addsd  0x40(%rsp),%xmm7
  820fb0:	addsd  0x30(%rsp),%xmm7
  820fb6:	addsd  -0x7716e6(%rip),%xmm7        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820fbe:	mulsd  -0x77118e(%rip),%xmm7        # afe38 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820fc6:	ucomisd %xmm4,%xmm7
  820fca:	jae    820aa0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x650>
  820fd0:	movapd 0x20(%rsp),%xmm2
  820fd6:	subsd  %xmm4,%xmm2
  820fda:	ucomisd %xmm2,%xmm7
  820fde:	jae    820aa0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x650>
  820fe4:	addsd  -0x771a05(%rip),%xmm13        # af5e8 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  820fed:	movapd %xmm13,%xmm3
  820ff2:	mulsd  0x2c0(%rsp),%xmm3
  820ffb:	movapd %xmm13,%xmm2
  821000:	mulsd  0x2b0(%rsp),%xmm2
  821009:	addsd  %xmm3,%xmm10
  82100e:	addsd  0xd0(%rsp),%xmm10
  821018:	subsd  0x90(%rsp),%xmm10
  821022:	addsd  %xmm2,%xmm14
  821027:	addsd  0xc0(%rsp),%xmm14
  821031:	addsd  0x80(%rsp),%xmm14
  82103b:	addsd  0x70(%rsp),%xmm14
  821042:	addsd  -0x771773(%rip),%xmm14        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  82104b:	mulsd  -0x7717f4(%rip),%xmm14        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  821054:	addsd  0x18(%rsp),%xmm14
  82105b:	ucomisd %xmm10,%xmm14
  821060:	jae    820aa0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x650>
  821066:	movapd 0x60(%rsp),%xmm4
  82106c:	subsd  %xmm10,%xmm4
  821071:	ucomisd %xmm4,%xmm14
  821076:	jae    820aa0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x650>
  82107c:	movapd 0x270(%rsp),%xmm7
  821085:	mulsd  %xmm13,%xmm7
  82108a:	movapd 0x260(%rsp),%xmm6
  821093:	mulsd  %xmm13,%xmm6
  821098:	movapd 0x180(%rsp),%xmm4
  8210a1:	addsd  %xmm7,%xmm4
  8210a5:	addsd  0x140(%rsp),%xmm4
  8210ae:	subsd  0x90(%rsp),%xmm4
  8210b7:	movsd  0x1c8(%rsp),%xmm9
  8210c1:	addsd  %xmm6,%xmm9
  8210c6:	addsd  0x130(%rsp),%xmm9
  8210d0:	addsd  0x80(%rsp),%xmm9
  8210da:	addsd  0x70(%rsp),%xmm9
  8210e1:	addsd  -0x771812(%rip),%xmm9        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8210ea:	mulsd  -0x7712bb(%rip),%xmm9        # afe38 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  8210f3:	ucomisd %xmm4,%xmm9
  8210f8:	jae    820aa0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x650>
  8210fe:	movapd %xmm4,%xmm10
  821103:	movapd 0x60(%rsp),%xmm4
  821109:	subsd  %xmm10,%xmm4
  82110e:	ucomisd %xmm4,%xmm9
  821113:	jae    820aa0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x650>
  821119:	movapd %xmm13,%xmm14
  82111e:	mulsd  0x230(%rsp),%xmm14
  821128:	movapd %xmm13,%xmm9
  82112d:	mulsd  0x220(%rsp),%xmm9
  821137:	movsd  0x1c0(%rsp),%xmm8
  821141:	addsd  %xmm14,%xmm8
  821146:	addsd  0x110(%rsp),%xmm8
  821150:	subsd  0x50(%rsp),%xmm8
  821157:	movapd %xmm11,%xmm4
  82115c:	movsd  0x1b8(%rsp),%xmm11
  821166:	movsd  %xmm9,0x180(%rsp)
  821170:	addsd  %xmm9,%xmm11
  821175:	addsd  0x120(%rsp),%xmm11
  82117f:	addsd  0x40(%rsp),%xmm11
  821186:	addsd  0x30(%rsp),%xmm11
  82118d:	addsd  -0x7718be(%rip),%xmm11        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821196:	mulsd  -0x77193f(%rip),%xmm11        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  82119f:	addsd  0x8(%rsp),%xmm11
  8211a6:	ucomisd %xmm8,%xmm11
  8211ab:	jae    820aa0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x650>
  8211b1:	movapd %xmm8,%xmm9
  8211b6:	movapd 0x20(%rsp),%xmm8
  8211bd:	subsd  %xmm9,%xmm8
  8211c2:	ucomisd %xmm8,%xmm11
  8211c7:	jae    820aa0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x650>
  8211cd:	movapd 0x1f0(%rsp),%xmm8
  8211d7:	mulsd  %xmm13,%xmm8
  8211dc:	mulsd  0x1e0(%rsp),%xmm13
  8211e6:	movapd 0x2e0(%rsp),%xmm9
  8211f0:	addsd  %xmm8,%xmm9
  8211f5:	addsd  0x100(%rsp),%xmm9
  8211ff:	subsd  0x50(%rsp),%xmm9
  821206:	addsd  %xmm13,%xmm12
  82120b:	addsd  0xf0(%rsp),%xmm12
  821215:	addsd  0x40(%rsp),%xmm12
  82121c:	addsd  0x30(%rsp),%xmm12
  821223:	addsd  -0x771954(%rip),%xmm12        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  82122c:	mulsd  -0x7713fd(%rip),%xmm12        # afe38 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  821235:	ucomisd %xmm9,%xmm12
  82123a:	jae    820aa0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x650>
  821240:	movapd %xmm9,%xmm10
  821245:	movapd 0x20(%rsp),%xmm9
  82124c:	subsd  %xmm10,%xmm9
  821251:	ucomisd %xmm9,%xmm12
  821256:	jae    820aa0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x650>
  82125c:	movsd  0x1a0(%rsp),%xmm9
  821266:	addsd  %xmm3,%xmm9
  82126b:	addsd  0xd0(%rsp),%xmm9
  821275:	subsd  0x90(%rsp),%xmm9
  82127f:	movapd %xmm5,%xmm10
  821284:	addsd  %xmm2,%xmm10
  821289:	addsd  0xc0(%rsp),%xmm10
  821293:	addsd  0x80(%rsp),%xmm10
  82129d:	addsd  0x70(%rsp),%xmm10
  8212a4:	addsd  -0x7719d5(%rip),%xmm10        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8212ad:	mulsd  -0x771a56(%rip),%xmm10        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  8212b6:	addsd  0x18(%rsp),%xmm10
  8212bd:	ucomisd %xmm9,%xmm10
  8212c2:	jae    820aa0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x650>
  8212c8:	movapd 0x60(%rsp),%xmm2
  8212ce:	subsd  %xmm9,%xmm2
  8212d3:	ucomisd %xmm2,%xmm10
  8212d8:	jae    820aa0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x650>
  8212de:	movapd 0x2d0(%rsp),%xmm2
  8212e7:	addsd  %xmm7,%xmm2
  8212eb:	addsd  0x140(%rsp),%xmm2
  8212f4:	subsd  0x90(%rsp),%xmm2
  8212fd:	movsd  0x198(%rsp),%xmm5
  821306:	addsd  %xmm6,%xmm5
  82130a:	addsd  0x130(%rsp),%xmm5
  821313:	addsd  0x80(%rsp),%xmm5
  82131c:	addsd  0x70(%rsp),%xmm5
  821322:	addsd  -0x771a52(%rip),%xmm5        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  82132a:	mulsd  -0x7714fa(%rip),%xmm5        # afe38 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  821332:	ucomisd %xmm2,%xmm5
  821336:	jae    820aa0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x650>
  82133c:	movapd %xmm4,%xmm11
  821341:	movapd %xmm2,%xmm3
  821345:	movapd 0x60(%rsp),%xmm2
  82134b:	subsd  %xmm3,%xmm2
  82134f:	ucomisd %xmm2,%xmm5
  821353:	jae    820aa0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x650>
  821359:	addsd  %xmm14,%xmm11
  82135e:	addsd  0x110(%rsp),%xmm11
  821368:	subsd  0x50(%rsp),%xmm11
  82136f:	movsd  0x170(%rsp),%xmm2
  821378:	addsd  0x180(%rsp),%xmm2
  821381:	addsd  0x120(%rsp),%xmm2
  82138a:	addsd  0x40(%rsp),%xmm2
  821390:	addsd  0x30(%rsp),%xmm2
  821396:	addsd  -0x771ac6(%rip),%xmm2        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  82139e:	mulsd  -0x771b46(%rip),%xmm2        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  8213a6:	addsd  0x8(%rsp),%xmm2
  8213ac:	ucomisd %xmm11,%xmm2
  8213b1:	jae    820aa0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x650>
  8213b7:	movapd %xmm2,%xmm3
  8213bb:	movapd 0x20(%rsp),%xmm2
  8213c1:	subsd  %xmm11,%xmm2
  8213c6:	ucomisd %xmm2,%xmm3
  8213ca:	jae    820aa0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x650>
  8213d0:	movapd 0x2a0(%rsp),%xmm2
  8213d9:	addsd  %xmm8,%xmm2
  8213de:	addsd  0x100(%rsp),%xmm2
  8213e7:	subsd  0x50(%rsp),%xmm2
  8213ed:	addsd  %xmm13,%xmm15
  8213f2:	addsd  0xf0(%rsp),%xmm15
  8213fc:	addsd  0x40(%rsp),%xmm15
  821403:	addsd  0x30(%rsp),%xmm15
  82140a:	addsd  -0x771b3b(%rip),%xmm15        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821413:	mulsd  -0x7715e4(%rip),%xmm15        # afe38 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  82141c:	ucomisd %xmm2,%xmm15
  821421:	jae    820aa0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x650>
  821427:	movapd %xmm2,%xmm3
  82142b:	movapd 0x20(%rsp),%xmm2
  821431:	subsd  %xmm3,%xmm2
  821435:	ucomisd %xmm2,%xmm15
  82143a:	jae    820aa0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x650>
  821440:	cmpb   $0x0,0x7(%rsp)
  821445:	je     82148c <<gpui_gpu::renderer::RendererState>::bin_draw+0x103c>
  821447:	cmp    %rsi,%r10
  82144a:	jae    821567 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1117>
  821450:	mov    0xbc(%rsp),%eax
  821457:	mov    %eax,0x0(%rbp,%r10,8)
  82145c:	movl   $0x40000001,0x4(%rbp,%r10,8)
  821465:	cmp    0xe8(%rsp),%r10
  82146d:	jae    821577 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1127>
  821473:	mov    0xa0(%rsp),%rax
  82147b:	mov    0x190(%rsp),%rdx
  821483:	mov    %eax,(%rdx,%r10,4)
  821487:	jmp    820aba <<gpui_gpu::renderer::RendererState>::bin_draw+0x66a>
  82148c:	cmp    %rsi,%r10
  82148f:	jae    82154a <<gpui_gpu::renderer::RendererState>::bin_draw+0x10fa>
  821495:	incl   0x4(%rbp,%r10,8)
  82149a:	jmp    820aba <<gpui_gpu::renderer::RendererState>::bin_draw+0x66a>
  82149f:	nop
  8214a0:	mov    0x10(%rsp),%rax
  8214a5:	cmp    %rax,%r13
  8214a8:	mov    0xa8(%rsp),%rcx
  8214b0:	jae    8205ce <<gpui_gpu::renderer::RendererState>::bin_draw+0x17e>
  8214b6:	mov    %rcx,%r13
  8214b9:	cmp    %rax,%rcx
  8214bc:	jbe    8209e0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x590>
  8214c2:	jmp    8205ce <<gpui_gpu::renderer::RendererState>::bin_draw+0x17e>
  8214c7:	mov    0x10(%rsp),%r11
  8214cc:	jmp    8214e0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1090>
  8214ce:	mov    0x10(%rsp),%r11
  8214d3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  8214e0:	cmp    %r11,%r13
  8214e3:	mov    %r13,%rax
  8214e6:	adc    $0x0,%rax
  8214ea:	mov    %r13,%rcx
  8214ed:	imul   %r9,%rcx
  8214f1:	mov    0xb0(%rsp),%rdx
  8214f9:	nopl   0x0(%rax)
  821500:	lea    (%rdx,%rcx,1),%r10
  821504:	cmp    %rsi,%r10
  821507:	jae    82154a <<gpui_gpu::renderer::RendererState>::bin_draw+0x10fa>
  821509:	cmp    %rbx,%rdx
  82150c:	mov    %rdx,%rdi
  82150f:	adc    $0x0,%rdi
  821513:	mov    0x4(%rbp,%r10,8),%r8d
  821518:	inc    %r8d
  82151b:	and    $0xbfffffff,%r8d
  821522:	mov    %r8d,0x4(%rbp,%r10,8)
  821527:	cmp    %rbx,%rdx
  82152a:	jae    821534 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10e4>
  82152c:	mov    %rdi,%rdx
  82152f:	cmp    %rbx,%rdi
  821532:	jbe    821500 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10b0>
  821534:	cmp    %r11,%r13
  821537:	jae    8205ce <<gpui_gpu::renderer::RendererState>::bin_draw+0x17e>
  82153d:	mov    %rax,%r13
  821540:	cmp    %r11,%rax
  821543:	jbe    8214e0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1090>
  821545:	jmp    8205ce <<gpui_gpu::renderer::RendererState>::bin_draw+0x17e>
  82154a:	lea    0x60d117(%rip),%rdx        # e2e668 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.13987519659127932268+0x120>
  821551:	mov    %r10,%rdi
  821554:	call   *0x65ea5e(%rip)        # e7ffb8 <_DYNAMIC+0x4f8>
  82155a:	lea    0x60d1f7(%rip),%rdi        # e2e758 <anon.36d49f465d299f05a84fba3771e6457e.32.llvm.13987519659127932268+0x10>
  821561:	call   *0x65eb31(%rip)        # e80098 <_DYNAMIC+0x5d8>
  821567:	lea    0x60d0ca(%rip),%rdx        # e2e638 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.13987519659127932268+0xf0>
  82156e:	mov    %r10,%rdi
  821571:	call   *0x65ea41(%rip)        # e7ffb8 <_DYNAMIC+0x4f8>
  821577:	lea    0x60d0d2(%rip),%rdx        # e2e650 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.13987519659127932268+0x108>
  82157e:	mov    %r10,%rdi
  821581:	mov    0xe8(%rsp),%rsi
  821589:	call   *0x65ea29(%rip)        # e7ffb8 <_DYNAMIC+0x4f8>

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000821590 <gpui_gpu::renderer::compact_group>:
  821590:	xor    %eax,%eax
  821592:	test   %esi,%esi
  821594:	je     8215d3 <gpui_gpu::renderer::compact_group+0x43>
  821596:	cmpq   $0x2,0x10(%rdi)
  82159b:	jb     8215d3 <gpui_gpu::renderer::compact_group+0x43>
  82159d:	sub    $0x58,%rsp
  8215a1:	mov    (%rdi),%rsi
  8215a4:	mov    0x8(%rdi),%rax
  8215a8:	mov    (%rax),%edx
  8215aa:	mov    %rsp,%rdi
  8215ad:	call   81c830 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  8215b2:	movss  0x4(%rsp),%xmm0
  8215b8:	cmpb   $0x3,(%rsp)
  8215bc:	setne  %cl
  8215bf:	xorps  %xmm1,%xmm1
  8215c2:	ucomiss %xmm1,%xmm0
  8215c5:	setnp  %dl
  8215c8:	sete   %al
  8215cb:	and    %dl,%al
  8215cd:	or     %cl,%al
  8215cf:	add    $0x58,%rsp
  8215d3:	ret

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008215e0 <gpui_gpu::renderer::validate_draw>:
  8215e0:	push   %rbp
  8215e1:	push   %r15
  8215e3:	push   %r14
  8215e5:	push   %r12
  8215e7:	push   %rbx
  8215e8:	sub    $0x80,%rsp
  8215ef:	mov    %r8d,%ebp
  8215f2:	mov    %ecx,%r12d
  8215f5:	mov    %rdx,%r14
  8215f8:	mov    %rsi,%r15
  8215fb:	mov    %rdi,%rbx
  8215fe:	movups 0x88(%rsi),%xmm0
  821605:	movaps %xmm0,0x20(%rsp)
  82160a:	movaps %xmm0,0x70(%rsp)
  82160f:	lea    0x70(%rsp),%rdi
  821614:	call   *0x65eb16(%rip)        # e80130 <_DYNAMIC+0x670>
  82161a:	movaps 0x20(%rsp),%xmm4
  82161f:	test   %al,%al
  821621:	je     821677 <gpui_gpu::renderer::validate_draw+0x97>
  821623:	movaps %xmm4,%xmm0
  821626:	unpckhpd %xmm4,%xmm0
  82162a:	xorps  %xmm2,%xmm2
  82162d:	ucomiss %xmm2,%xmm0
  821630:	jne    821634 <gpui_gpu::renderer::validate_draw+0x54>
  821632:	jnp    821677 <gpui_gpu::renderer::validate_draw+0x97>
  821634:	movaps %xmm4,%xmm1
  821637:	shufps $0xff,%xmm4,%xmm1
  82163b:	ucomiss %xmm2,%xmm1
  82163e:	jne    821642 <gpui_gpu::renderer::validate_draw+0x62>
  821640:	jnp    821677 <gpui_gpu::renderer::validate_draw+0x97>
  821642:	xorps  %xmm3,%xmm3
  821645:	ucomiss %xmm4,%xmm3
  821648:	ja     821677 <gpui_gpu::renderer::validate_draw+0x97>
  82164a:	movaps %xmm4,%xmm2
  82164d:	shufps $0x55,%xmm4,%xmm2
  821651:	ucomiss %xmm2,%xmm3
  821654:	ja     821677 <gpui_gpu::renderer::validate_draw+0x97>
  821656:	xorps  %xmm3,%xmm3
  821659:	cvtsi2ss %r12d,%xmm3
  82165e:	addss  %xmm4,%xmm0
  821662:	ucomiss %xmm3,%xmm0
  821665:	ja     821677 <gpui_gpu::renderer::validate_draw+0x97>
  821667:	xorps  %xmm0,%xmm0
  82166a:	cvtsi2ss %ebp,%xmm0
  82166e:	addss  %xmm1,%xmm2
  821672:	ucomiss %xmm0,%xmm2
  821675:	jbe    82168d <gpui_gpu::renderer::validate_draw+0xad>
  821677:	movl   $0x3,(%rbx)
  82167d:	add    $0x80,%rsp
  821684:	pop    %rbx
  821685:	pop    %r12
  821687:	pop    %r14
  821689:	pop    %r15
  82168b:	pop    %rbp
  82168c:	ret
  82168d:	movsd  0x48(%r15),%xmm9
  821693:	movsd  0x60(%r15),%xmm1
  821699:	movupd 0x50(%r15),%xmm2
  82169f:	movapd %xmm2,%xmm5
  8216a3:	shufpd $0x1,%xmm2,%xmm5
  8216a8:	movupd 0x68(%r15),%xmm0
  8216ae:	cvtpd2ps %xmm5,%xmm8
  8216b3:	movapd %xmm9,%xmm4
  8216b8:	unpcklpd %xmm1,%xmm4
  8216bc:	cvtpd2ps %xmm4,%xmm7
  8216c0:	cvtpd2ps %xmm0,%xmm6
  8216c4:	movapd %xmm6,%xmm3
  8216c8:	shufps $0x55,%xmm6,%xmm3
  8216cc:	movd   %xmm3,%ecx
  8216d0:	movd   %xmm6,%eax
  8216d4:	movapd %xmm7,%xmm3
  8216d8:	shufps $0x14,%xmm8,%xmm3
  8216dd:	shufps $0x78,%xmm3,%xmm3
  8216e1:	andps  -0x773ef8(%rip),%xmm3        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  8216e8:	and    $0x7fffffff,%eax
  8216ed:	cmp    $0x7f800000,%eax
  8216f2:	setge  %al
  8216f5:	and    $0x7fffffff,%ecx
  8216fb:	cmp    $0x7f800000,%ecx
  821701:	setge  %cl
  821704:	pcmpgtd -0x775fdc(%rip),%xmm3        # ab730 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x70>
  82170c:	movmskps %xmm3,%edx
  82170f:	test   %edx,%edx
  821711:	jne    821762 <gpui_gpu::renderer::validate_draw+0x182>
  821713:	test   %al,%al
  821715:	jne    821762 <gpui_gpu::renderer::validate_draw+0x182>
  821717:	test   %cl,%cl
  821719:	jne    821762 <gpui_gpu::renderer::validate_draw+0x182>
  82171b:	movapd %xmm9,%xmm3
  821720:	mulsd  %xmm1,%xmm3
  821724:	movapd %xmm2,%xmm10
  821729:	mulsd  %xmm5,%xmm10
  82172e:	subsd  %xmm10,%xmm3
  821733:	xorpd  %xmm10,%xmm10
  821738:	ucomisd %xmm10,%xmm3
  82173d:	jne    821741 <gpui_gpu::renderer::validate_draw+0x161>
  82173f:	jnp    821762 <gpui_gpu::renderer::validate_draw+0x182>
  821741:	movq   %xmm3,%rcx
  821746:	movabs $0x7fffffffffffffff,%rax
  821750:	and    %rax,%rcx
  821753:	movabs $0x7ff0000000000000,%rdx
  82175d:	cmp    %rdx,%rcx
  821760:	jl     821771 <gpui_gpu::renderer::validate_draw+0x191>
  821762:	movl   $0x5,(%rbx)
  821768:	mov    %r14,0x8(%rbx)
  82176c:	jmp    82167d <gpui_gpu::renderer::validate_draw+0x9d>
  821771:	xorps  %xmm10,%xmm10
  821775:	cvtsi2sd %r12d,%xmm10
  82177a:	cvtsi2sd %ebp,%xmm12
  82177f:	movsd  %xmm9,%xmm2
  821784:	movapd -0x77695d(%rip),%xmm13        # aae30 <GCC_except_table0+0xa8>
  82178d:	andpd  %xmm13,%xmm2
  821792:	movapd %xmm10,%xmm11
  821797:	unpcklpd %xmm12,%xmm11
  82179c:	movapd %xmm2,%xmm9
  8217a1:	movapd %xmm11,0x50(%rsp)
  8217a8:	mulpd  %xmm11,%xmm9
  8217ad:	movapd %xmm9,%xmm11
  8217b2:	unpckhpd %xmm9,%xmm11
  8217b7:	addsd  %xmm9,%xmm11
  8217bc:	movapd %xmm0,%xmm9
  8217c1:	andpd  %xmm13,%xmm9
  8217c6:	addsd  %xmm11,%xmm9
  8217cb:	shufpd $0x2,%xmm5,%xmm1
  8217d0:	andpd  %xmm13,%xmm1
  8217d5:	unpcklpd %xmm10,%xmm12
  8217da:	movapd %xmm1,%xmm10
  8217df:	movapd %xmm12,0x40(%rsp)
  8217e6:	mulpd  %xmm12,%xmm10
  8217eb:	movapd %xmm10,%xmm11
  8217f0:	unpckhpd %xmm10,%xmm11
  8217f5:	addsd  %xmm9,%xmm11
  8217fa:	addsd  %xmm10,%xmm11
  8217ff:	movapd %xmm0,%xmm10
  821804:	unpckhpd %xmm0,%xmm10
  821809:	andpd  %xmm13,%xmm10
  82180e:	addsd  %xmm11,%xmm10
  821813:	movsd  0x38(%r15),%xmm9
  821819:	movsd  0x40(%r15),%xmm12
  82181f:	andps  -0x774037(%rip),%xmm9        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  821827:	cvtps2pd %xmm9,%xmm15
  82182b:	movapd %xmm10,%xmm9
  821830:	addsd  %xmm15,%xmm9
  821835:	movapd %xmm15,0x60(%rsp)
  82183c:	unpckhpd %xmm15,%xmm15
  821841:	addsd  %xmm15,%xmm9
  821846:	cvtps2pd %xmm12,%xmm11
  82184a:	movapd %xmm11,0x20(%rsp)
  821851:	andpd  %xmm13,%xmm11
  821856:	addsd  %xmm11,%xmm9
  82185b:	pshufd $0xee,%xmm11,%xmm14
  821861:	movdqa %xmm14,0x30(%rsp)
  821868:	addsd  %xmm14,%xmm9
  82186d:	movq   %xmm9,%rsi
  821872:	and    %rax,%rsi
  821875:	movabs $0x7fefffffffffffff,%rcx
  82187f:	cmp    %rcx,%rsi
  821882:	jg     821762 <gpui_gpu::renderer::validate_draw+0x182>
  821888:	ucomisd -0x772219(%rip),%xmm9        # af678 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  821891:	ja     821762 <gpui_gpu::renderer::validate_draw+0x182>
  821897:	movzbl (%r15),%esi
  82189b:	cmp    $0x3,%esi
  82189e:	je     8218b6 <gpui_gpu::renderer::validate_draw+0x2d6>
  8218a0:	xorpd  %xmm14,%xmm14
  8218a5:	cmp    $0x1,%esi
  8218a8:	jne    8219e2 <gpui_gpu::renderer::validate_draw+0x402>
  8218ae:	movss  0x4(%r15),%xmm14
  8218b4:	jmp    8218cd <gpui_gpu::renderer::validate_draw+0x2ed>
  8218b6:	movss  0x4(%r15),%xmm14
  8218bc:	xorpd  %xmm13,%xmm13
  8218c1:	ucomiss %xmm13,%xmm14
  8218c5:	jne    8218cd <gpui_gpu::renderer::validate_draw+0x2ed>
  8218c7:	jnp    821b07 <gpui_gpu::renderer::validate_draw+0x527>
  8218cd:	movd   %xmm14,%edi
  8218d2:	test   %edi,%edi
  8218d4:	sets   %r8b
  8218d8:	and    $0x7fffffff,%edi
  8218de:	lea    -0x800000(%rdi),%r9d
  8218e5:	cmp    $0x7f000000,%r9d
  8218ec:	setb   %r9b
  8218f0:	and    %r8b,%r9b
  8218f3:	lea    -0x1(%rdi),%r10d
  8218f7:	cmp    $0x7fffff,%r10d
  8218fe:	setb   %r10b
  821902:	and    %r8b,%r10b
  821905:	cmp    $0x7f800000,%edi
  82190b:	sete   %dil
  82190f:	setg   %r8b
  821913:	or     %dil,%r8b
  821916:	or     %r10b,%r8b
  821919:	or     %r9b,%r8b
  82191c:	cmp    $0x1,%r8b
  821920:	je     821677 <gpui_gpu::renderer::validate_draw+0x97>
  821926:	movaps %xmm11,(%rsp)
  82192b:	movaps %xmm14,%xmm11
  82192f:	movaps %xmm14,0x10(%rsp)
  821935:	movaps %xmm12,%xmm14
  821939:	mulss  -0x772976(%rip),%xmm14        # aefcc <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  821942:	minss  %xmm14,%xmm11
  821947:	movaps %xmm11,%xmm14
  82194b:	cmpunordss %xmm11,%xmm14
  821951:	movaps %xmm14,%xmm13
  821955:	andnps %xmm11,%xmm13
  821959:	andps  0x10(%rsp),%xmm14
  82195f:	orps   %xmm13,%xmm14
  821963:	shufps $0x55,%xmm12,%xmm12
  821968:	mulss  -0x7729a5(%rip),%xmm12        # aefcc <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  821971:	movaps %xmm14,%xmm11
  821975:	minss  %xmm12,%xmm11
  82197a:	movaps %xmm11,%xmm12
  82197e:	cmpunordss %xmm11,%xmm12
  821984:	andps  %xmm12,%xmm14
  821988:	andnps %xmm11,%xmm12
  82198c:	orps   %xmm14,%xmm12
  821990:	movss  -0x7726e9(%rip),%xmm11        # af2b0 <anon.4109cdd7ddb1990ee57d5626700ecb68.286.llvm.4479275319843201559+0xc>
  821999:	ucomiss %xmm12,%xmm11
  82199d:	ja     821762 <gpui_gpu::renderer::validate_draw+0x182>
  8219a3:	xorps  %xmm14,%xmm14
  8219a7:	cvtss2sd %xmm12,%xmm14
  8219ac:	movapd %xmm9,%xmm11
  8219b1:	divsd  %xmm14,%xmm11
  8219b6:	ucomisd -0x7720df(%rip),%xmm11        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x10>
  8219bf:	ja     821762 <gpui_gpu::renderer::validate_draw+0x182>
  8219c5:	addsd  %xmm9,%xmm14
  8219ca:	mulsd  -0x77224b(%rip),%xmm14        # af788 <anon.4109cdd7ddb1990ee57d5626700ecb68.92.llvm.4479275319843201559+0x10>
  8219d3:	movapd (%rsp),%xmm11
  8219d9:	movapd -0x776bb2(%rip),%xmm13        # aae30 <GCC_except_table0+0xa8>
  8219e2:	cmp    $0x2,%esi
  8219e5:	movaps %xmm11,(%rsp)
  8219ea:	jae    821afb <gpui_gpu::renderer::validate_draw+0x51b>
  8219f0:	cvtps2pd %xmm8,%xmm8
  8219f4:	subpd  %xmm8,%xmm5
  8219f9:	cvtps2pd %xmm7,%xmm7
  8219fc:	andpd  %xmm13,%xmm5
  821a01:	mulpd  0x40(%rsp),%xmm5
  821a07:	subpd  %xmm7,%xmm4
  821a0b:	andpd  %xmm13,%xmm4
  821a10:	mulpd  0x50(%rsp),%xmm4
  821a16:	addpd  %xmm5,%xmm4
  821a1a:	cvtps2pd %xmm6,%xmm5
  821a1d:	subpd  %xmm5,%xmm0
  821a21:	addsd  -0x772152(%rip),%xmm10        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821a2a:	mulsd  -0x771f8b(%rip),%xmm10        # afaa8 <anon.4109cdd7ddb1990ee57d5626700ecb68.350.llvm.4479275319843201559+0x18>
  821a33:	andpd  %xmm13,%xmm0
  821a38:	addpd  %xmm4,%xmm0
  821a3c:	movapd 0x60(%rsp),%xmm7
  821a42:	addsd  %xmm7,%xmm15
  821a47:	movapd (%rsp),%xmm6
  821a4c:	addsd  %xmm6,%xmm15
  821a51:	addsd  0x30(%rsp),%xmm15
  821a58:	movapd %xmm0,%xmm4
  821a5c:	unpckhpd %xmm0,%xmm4
  821a60:	addpd  %xmm0,%xmm4
  821a64:	movapd %xmm1,%xmm5
  821a68:	shufpd $0x1,%xmm4,%xmm5
  821a6d:	movapd %xmm2,%xmm4
  821a71:	unpcklpd %xmm10,%xmm4
  821a76:	addpd  %xmm4,%xmm5
  821a7a:	mulsd  -0x7723cb(%rip),%xmm15        # af6b8 <anon.a16d5d421a76dfd8c37a17b53540311d.77.llvm.14190004212411149437+0x10>
  821a83:	shufpd $0x1,%xmm15,%xmm2
  821a89:	addpd  %xmm5,%xmm2
  821a8d:	unpcklpd %xmm14,%xmm1
  821a92:	addpd  %xmm2,%xmm1
  821a96:	movapd %xmm1,%xmm2
  821a9a:	unpckhpd %xmm1,%xmm2
  821a9e:	mulsd  %xmm1,%xmm2
  821aa2:	andpd  -0x776c7a(%rip),%xmm3        # aae30 <GCC_except_table0+0xa8>
  821aaa:	divsd  %xmm3,%xmm2
  821aae:	movq   %xmm2,%rdx
  821ab3:	and    %rax,%rdx
  821ab6:	cmp    %rcx,%rdx
  821ab9:	jg     821762 <gpui_gpu::renderer::validate_draw+0x182>
  821abf:	ucomisd -0x771bbf(%rip),%xmm2        # aff08 <anon.a16d5d421a76dfd8c37a17b53540311d.26.llvm.14190004212411149437+0x10>
  821ac7:	ja     821762 <gpui_gpu::renderer::validate_draw+0x182>
  821acd:	unpcklpd %xmm10,%xmm10
  821ad2:	addpd  %xmm10,%xmm0
  821ad7:	addpd  %xmm7,%xmm6
  821adb:	mulpd  -0x776ad3(%rip),%xmm6        # ab010 <anon.068260129a360d3c14a88deb110120c9.101.llvm.7357624670875813013+0x1d0>
  821ae3:	addpd  %xmm0,%xmm6
  821ae7:	cvtpd2ps %xmm6,%xmm0
  821aeb:	movlpd %xmm0,0x4(%rbx)
  821af0:	movl   $0xffffffff,(%rbx)
  821af6:	jmp    82167d <gpui_gpu::renderer::validate_draw+0x9d>
  821afb:	jne    821b10 <gpui_gpu::renderer::validate_draw+0x530>
  821afd:	mov    0x28(%r15),%rsi
  821b01:	mov    0x30(%r15),%rdi
  821b05:	jmp    821b18 <gpui_gpu::renderer::validate_draw+0x538>
  821b07:	movaps %xmm11,(%rsp)
  821b0c:	xorps  %xmm14,%xmm14
  821b10:	mov    0x28(%r15),%esi
  821b14:	mov    0x2c(%r15),%edi
  821b18:	movq   %rsi,%xmm11
  821b1d:	punpckldq -0x7761d6(%rip),%xmm11        # ab950 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x290>
  821b26:	subpd  -0x776d0f(%rip),%xmm11        # aae20 <GCC_except_table0+0x98>
  821b2f:	movapd %xmm11,%xmm12
  821b34:	unpckhpd %xmm11,%xmm12
  821b39:	addsd  %xmm11,%xmm12
  821b3e:	movapd 0x20(%rsp),%xmm11
  821b45:	divsd  %xmm11,%xmm12
  821b4a:	movq   %xmm12,%r8
  821b4f:	and    %rax,%r8
  821b52:	cmp    %rdx,%r8
  821b55:	jge    821762 <gpui_gpu::renderer::validate_draw+0x182>
  821b5b:	movaps %xmm14,0x10(%rsp)
  821b61:	movapd %xmm11,%xmm14
  821b66:	movq   %rdi,%xmm11
  821b6b:	punpckldq -0x776224(%rip),%xmm11        # ab950 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x290>
  821b74:	subpd  -0x776d5d(%rip),%xmm11        # aae20 <GCC_except_table0+0x98>
  821b7d:	movapd %xmm11,%xmm13
  821b82:	unpckhpd %xmm11,%xmm13
  821b87:	addsd  %xmm11,%xmm13
  821b8c:	unpckhpd %xmm14,%xmm14
  821b91:	divsd  %xmm14,%xmm13
  821b96:	movapd 0x10(%rsp),%xmm14
  821b9d:	movq   %xmm13,%rdx
  821ba2:	and    %rax,%rdx
  821ba5:	cmp    %rcx,%rdx
  821ba8:	setg   %dl
  821bab:	ucomisd -0x77253c(%rip),%xmm13        # af678 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  821bb4:	movapd -0x776d8d(%rip),%xmm13        # aae30 <GCC_except_table0+0xa8>
  821bbd:	ja     821762 <gpui_gpu::renderer::validate_draw+0x182>
  821bc3:	ucomisd -0x772554(%rip),%xmm12        # af678 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  821bcc:	ja     821762 <gpui_gpu::renderer::validate_draw+0x182>
  821bd2:	test   %dl,%dl
  821bd4:	jne    821762 <gpui_gpu::renderer::validate_draw+0x182>
  821bda:	cmp    %rsi,%rdi
  821bdd:	cmova  %rdi,%rsi
  821be1:	movq   %rsi,%xmm11
  821be6:	punpckldq -0x77629f(%rip),%xmm11        # ab950 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x290>
  821bef:	subpd  -0x776dd8(%rip),%xmm11        # aae20 <GCC_except_table0+0x98>
  821bf8:	movapd %xmm11,%xmm12
  821bfd:	unpckhpd %xmm11,%xmm12
  821c02:	addsd  %xmm11,%xmm12
  821c07:	mulsd  %xmm12,%xmm9
  821c0c:	ucomisd -0x77259d(%rip),%xmm9        # af678 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  821c15:	ja     821762 <gpui_gpu::renderer::validate_draw+0x182>
  821c1b:	jmp    8219f0 <gpui_gpu::renderer::validate_draw+0x410>

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000822330 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>>:
  822330:	push   %rbp
  822331:	push   %r15
  822333:	push   %r14
  822335:	push   %r13
  822337:	push   %r12
  822339:	push   %rbx
  82233a:	sub    $0x58,%rsp
  82233e:	mov    %ecx,%ebp
  822340:	mov    %rdx,0x8(%rsp)
  822345:	mov    0x18(%rdi),%rax
  822349:	add    %rax,%rsi
  82234c:	jb     822461 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x131>
  822352:	mov    %rdi,%rbx
  822355:	mov    0x8(%rdi),%r15
  822359:	lea    0x1(%r15),%rdx
  82235d:	mov    %rdx,%rdi
  822360:	shr    $0x3,%rdi
  822364:	mov    %rdx,%rcx
  822367:	and    $0xfffffffffffffff8,%rcx
  82236b:	sub    %rdi,%rcx
  82236e:	cmp    $0x8,%r15
  822372:	cmovb  %r15,%rcx
  822376:	mov    %rcx,%rdi
  822379:	shr    $1,%rdi
  82237c:	cmp    %rdi,%rsi
  82237f:	jbe    8223b0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x80>
  822381:	inc    %rcx
  822384:	cmp    %rsi,%rcx
  822387:	cmovbe %rsi,%rcx
  82238b:	cmp    $0xf,%rcx
  82238f:	mov    %rbx,(%rsp)
  822393:	jae    8223e1 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0xb1>
  822395:	mov    %ecx,%eax
  822397:	and    $0x8,%eax
  82239a:	add    $0x8,%rax
  82239e:	cmp    $0x4,%rcx
  8223a2:	mov    $0x4,%ebx
  8223a7:	cmovae %rax,%rbx
  8223ab:	jmp    822439 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x109>
  8223b0:	test   %rdx,%rdx
  8223b3:	je     82263a <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x30a>
  8223b9:	mov    (%rbx),%rsi
  8223bc:	mov    %rdx,%rax
  8223bf:	shr    $0x4,%rax
  8223c3:	mov    %edx,%ecx
  8223c5:	and    $0xf,%ecx
  8223c8:	cmp    $0x1,%rcx
  8223cc:	sbb    $0xffffffffffffffff,%rax
  8223d0:	cmp    $0x1,%rax
  8223d4:	jne    822641 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x311>
  8223da:	xor    %ecx,%ecx
  8223dc:	jmp    822694 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x364>
  8223e1:	movabs $0x1ffffffffffffffe,%rax
  8223eb:	inc    %rax
  8223ee:	cmp    %rax,%rcx
  8223f1:	ja     822461 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x131>
  8223f3:	shl    $0x3,%rcx
  8223f7:	movabs $0x2492492492492493,%rdx
  822401:	mov    %rcx,%rax
  822404:	mul    %rdx
  822407:	sub    %rdx,%rcx
  82240a:	shr    $1,%rcx
  82240d:	add    %rdx,%rcx
  822410:	shr    $0x2,%rcx
  822414:	dec    %rcx
  822417:	bsr    %rcx,%rcx
  82241b:	not    %ecx
  82241d:	mov    $0xffffffffffffffff,%rbx
  822424:	shr    %cl,%rbx
  822427:	movabs $0x7fffffffffffffe,%rax
  822431:	cmp    %rax,%rbx
  822434:	ja     822461 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x131>
  822436:	inc    %rbx
  822439:	mov    %rbx,%r14
  82243c:	shl    $0x5,%r14
  822440:	lea    0x10(%rbx),%r12
  822444:	mov    %r12,%r13
  822447:	add    %r14,%r13
  82244a:	setb   %al
  82244d:	movabs $0x7ffffffffffffff0,%rcx
  822457:	cmp    %rcx,%r13
  82245a:	seta   %cl
  82245d:	or     %al,%cl
  82245f:	je     822470 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x140>
  822461:	movzbl %bpl,%edi
  822465:	call   *0x65dccd(%rip)        # e80138 <_DYNAMIC+0x678>
  82246b:	jmp    8228b5 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x585>
  822470:	call   *0x65d8da(%rip)        # e7fd50 <_DYNAMIC+0x290>
  822476:	mov    $0x10,%esi
  82247b:	mov    %r13,%rdi
  82247e:	call   *0x65d8d4(%rip)        # e7fd58 <_DYNAMIC+0x298>
  822484:	test   %rax,%rax
  822487:	je     8228d3 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x5a3>
  82248d:	mov    %rax,%r15
  822490:	mov    (%rsp),%rcx
  822494:	lea    0x20(%rcx),%r13
  822498:	add    %r14,%r15
  82249b:	lea    -0x1(%rbx),%r14
  82249f:	mov    %rbx,%rax
  8224a2:	shr    $0x3,%rax
  8224a6:	mov    %rbx,%rbp
  8224a9:	and    $0xfffffffffffffff8,%rbp
  8224ad:	sub    %rax,%rbp
  8224b0:	cmp    $0x9,%rbx
  8224b4:	mov    %rcx,%rbx
  8224b7:	cmovb  %r14,%rbp
  8224bb:	mov    %r15,%rdi
  8224be:	mov    $0xff,%esi
  8224c3:	mov    %r12,%rdx
  8224c6:	call   *0x65dc74(%rip)        # e80140 <memset@GLIBC_2.2.5>
  8224cc:	mov    %r14,%rdi
  8224cf:	mov    %r13,0x20(%rsp)
  8224d4:	movq   $0x20,0x28(%rsp)
  8224dd:	movq   $0x10,0x30(%rsp)
  8224e6:	mov    %r15,0x38(%rsp)
  8224eb:	mov    %r14,0x40(%rsp)
  8224f0:	mov    %rbp,0x48(%rsp)
  8224f5:	movq   $0x0,0x50(%rsp)
  8224fe:	mov    0x18(%rbx),%r12
  822502:	test   %r12,%r12
  822505:	je     8228e7 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x5b7>
  82250b:	mov    %rbp,0x10(%rsp)
  822510:	mov    (%rbx),%rsi
  822513:	movdqa (%rsi),%xmm0
  822517:	pmovmskb %xmm0,%r13d
  82251c:	not    %r13d
  82251f:	xor    %ebp,%ebp
  822521:	mov    %rsi,%r14
  822524:	mov    %rdi,0x18(%rsp)
  822529:	nopl   0x0(%rax)
  822530:	test   %r13w,%r13w
  822534:	jne    82255f <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x22f>
  822536:	cs nopw 0x0(%rax,%rax,1)
  822540:	movdqa 0x10(%r14),%xmm0
  822546:	add    $0x10,%r14
  82254a:	pmovmskb %xmm0,%r13d
  82254f:	xor    $0xffff,%r13d
  822556:	add    $0x10,%rbp
  82255a:	test   %r13d,%r13d
  82255d:	je     822540 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x210>
  82255f:	tzcnt  %r13d,%ebx
  822564:	add    %rbp,%rbx
  822567:	mov    %rbx,%rax
  82256a:	shl    $0x5,%rax
  82256e:	sub    %rax,%rsi
  822571:	add    $0xffffffffffffffe0,%rsi
  822575:	mov    0x8(%rsp),%rdi
  82257a:	call   824b60 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  82257f:	mov    %rax,%rdx
  822582:	mov    0x18(%rsp),%rdi
  822587:	and    %rdi,%rdx
  82258a:	movdqu (%r15,%rdx,1),%xmm0
  822590:	pmovmskb %xmm0,%ecx
  822594:	test   %ecx,%ecx
  822596:	je     822605 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x2d5>
  822598:	tzcnt  %ecx,%ecx
  82259c:	add    %rdx,%rcx
  82259f:	and    %rdi,%rcx
  8225a2:	cmpb   $0x0,(%r15,%rcx,1)
  8225a7:	jns    822628 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x2f8>
  8225a9:	lea    -0x1(%r13),%edx
  8225ad:	and    %r13d,%edx
  8225b0:	dec    %r12
  8225b3:	shr    $0x39,%rax
  8225b7:	lea    -0x10(%rcx),%rsi
  8225bb:	and    %rdi,%rsi
  8225be:	mov    %al,(%r15,%rcx,1)
  8225c2:	mov    %al,0x10(%r15,%rsi,1)
  8225c7:	mov    (%rsp),%rax
  8225cb:	mov    (%rax),%rsi
  8225ce:	not    %rbx
  8225d1:	shl    $0x5,%rbx
  8225d5:	not    %rcx
  8225d8:	shl    $0x5,%rcx
  8225dc:	movdqu (%rsi,%rbx,1),%xmm0
  8225e1:	movdqu 0x10(%rsi,%rbx,1),%xmm1
  8225e7:	movdqu %xmm1,0x10(%r15,%rcx,1)
  8225ee:	movdqu %xmm0,(%r15,%rcx,1)
  8225f4:	mov    %edx,%r13d
  8225f7:	test   %r12,%r12
  8225fa:	jne    822530 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x200>
  822600:	jmp    8228c4 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x594>
  822605:	mov    $0x10,%esi
  82260a:	add    %rsi,%rdx
  82260d:	and    %rdi,%rdx
  822610:	movdqu (%r15,%rdx,1),%xmm0
  822616:	pmovmskb %xmm0,%ecx
  82261a:	add    $0x10,%rsi
  82261e:	test   %ecx,%ecx
  822620:	jne    822598 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x268>
  822626:	jmp    82260a <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x2da>
  822628:	movdqa (%r15),%xmm0
  82262d:	pmovmskb %xmm0,%ecx
  822631:	tzcnt  %ecx,%ecx
  822635:	jmp    8225a9 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x279>
  82263a:	xor    %ecx,%ecx
  82263c:	jmp    8228a7 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x577>
  822641:	movabs $0x1ffffffffffffffe,%rdi
  82264b:	and    %rax,%rdi
  82264e:	xor    %ecx,%ecx
  822650:	movdqa -0x774a58(%rip),%xmm0        # adc00 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x820>
  822658:	nopl   0x0(%rax,%rax,1)
  822660:	pxor   %xmm1,%xmm1
  822664:	pcmpgtb (%rsi,%rcx,1),%xmm1
  822669:	por    %xmm0,%xmm1
  82266d:	movdqa %xmm1,(%rsi,%rcx,1)
  822672:	pxor   %xmm1,%xmm1
  822676:	pcmpgtb 0x10(%rsi,%rcx,1),%xmm1
  82267c:	por    %xmm0,%xmm1
  822680:	movdqa %xmm1,0x10(%rsi,%rcx,1)
  822686:	add    $0x20,%rcx
  82268a:	add    $0xfffffffffffffffe,%rdi
  82268e:	jne    822660 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x330>
  822690:	test   $0x1,%al
  822692:	je     8226aa <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x37a>
  822694:	pxor   %xmm0,%xmm0
  822698:	pcmpgtb (%rsi,%rcx,1),%xmm0
  82269d:	por    -0x774aa5(%rip),%xmm0        # adc00 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x820>
  8226a5:	movdqa %xmm0,(%rsi,%rcx,1)
  8226aa:	cmp    $0x10,%rdx
  8226ae:	jb     822938 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x608>
  8226b4:	mov    %rdx,%rdi
  8226b7:	mov    $0x10,%edx
  8226bc:	add    %rsi,%rdi
  8226bf:	call   *0x65da83(%rip)        # e80148 <memmove@GLIBC_2.2.5>
  8226c5:	movq   $0x0,0x28(%rsp)
  8226ce:	movq   $0x20,0x30(%rsp)
  8226d7:	mov    %rbx,0x20(%rsp)
  8226dc:	xor    %r12d,%r12d
  8226df:	xor    %r13d,%r13d
  8226e2:	jmp    822831 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x501>
  8226e7:	nopw   0x0(%rax,%rax,1)
  8226f0:	lea    (%rax,%rbp,1),%rsi
  8226f4:	add    $0xffffffffffffffe0,%rsi
  8226f8:	mov    0x8(%rsp),%rdi
  8226fd:	call   824b60 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  822702:	mov    (%rbx),%rcx
  822705:	mov    0x8(%rbx),%rdx
  822709:	mov    %rdx,%rsi
  82270c:	and    %rax,%rsi
  82270f:	movdqu (%rcx,%rsi,1),%xmm0
  822714:	pmovmskb %xmm0,%edi
  822718:	mov    %rsi,%r8
  82271b:	test   %edi,%edi
  82271d:	je     8227c9 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x499>
  822723:	tzcnt  %edi,%edi
  822727:	add    %r8,%rdi
  82272a:	and    %rdx,%rdi
  82272d:	cmpb   $0x0,(%rcx,%rdi,1)
  822731:	jns    8227f0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4c0>
  822737:	mov    %r12,%r8
  82273a:	sub    %rsi,%r8
  82273d:	mov    %rdi,%r9
  822740:	sub    %rsi,%r9
  822743:	xor    %r8,%r9
  822746:	and    %rdx,%r9
  822749:	cmp    $0x10,%r9
  82274d:	jb     822810 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4e0>
  822753:	mov    %rdi,%rsi
  822756:	not    %rsi
  822759:	shl    $0x5,%rsi
  82275d:	add    %rcx,%rsi
  822760:	movzbl (%rcx,%rdi,1),%r8d
  822765:	shr    $0x39,%rax
  822769:	lea    -0x10(%rdi),%r9
  82276d:	and    %rdx,%r9
  822770:	mov    %al,(%rcx,%rdi,1)
  822773:	mov    (%rbx),%rcx
  822776:	mov    %al,0x10(%rcx,%r9,1)
  82277b:	cmp    $0xff,%r8b
  82277f:	je     822856 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x526>
  822785:	mov    (%r14),%rax
  822788:	mov    (%rsi),%rcx
  82278b:	mov    %rcx,(%r14)
  82278e:	mov    %rax,(%rsi)
  822791:	mov    0x8(%r14),%rax
  822795:	mov    0x8(%rsi),%rcx
  822799:	mov    %rcx,0x8(%r14)
  82279d:	mov    %rax,0x8(%rsi)
  8227a1:	mov    0x10(%r14),%rax
  8227a5:	mov    0x10(%rsi),%rcx
  8227a9:	mov    %rcx,0x10(%r14)
  8227ad:	mov    %rax,0x10(%rsi)
  8227b1:	mov    0x18(%r14),%rax
  8227b5:	mov    0x18(%rsi),%rcx
  8227b9:	mov    %rcx,0x18(%r14)
  8227bd:	mov    %rax,0x18(%rsi)
  8227c1:	mov    (%rbx),%rax
  8227c4:	jmp    8226f0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x3c0>
  8227c9:	mov    $0x10,%r9d
  8227cf:	mov    %rsi,%r8
  8227d2:	add    %r9,%r8
  8227d5:	and    %rdx,%r8
  8227d8:	movdqu (%rcx,%r8,1),%xmm0
  8227de:	pmovmskb %xmm0,%edi
  8227e2:	add    $0x10,%r9
  8227e6:	test   %edi,%edi
  8227e8:	jne    822723 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x3f3>
  8227ee:	jmp    8227d2 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4a2>
  8227f0:	movdqa (%rcx),%xmm0
  8227f4:	pmovmskb %xmm0,%edi
  8227f8:	tzcnt  %edi,%edi
  8227fc:	jmp    822737 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x407>
  822801:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  822810:	shr    $0x39,%rax
  822814:	lea    -0x10(%r12),%rsi
  822819:	and    %rsi,%rdx
  82281c:	mov    %al,(%rcx,%r12,1)
  822820:	mov    (%rbx),%rcx
  822823:	mov    %al,0x10(%rcx,%rdx,1)
  822827:	cmp    %r15,%r12
  82282a:	lea    0x1(%r12),%r12
  82282f:	je     822885 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x555>
  822831:	mov    (%rbx),%rax
  822834:	cmp    (%rax,%r12,1),%r13b
  822838:	jno    822827 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4f7>
  82283a:	mov    %r12,%r14
  82283d:	not    %r14
  822840:	shl    $0x5,%r14
  822844:	add    %rax,%r14
  822847:	mov    %r12,%rbp
  82284a:	neg    %rbp
  82284d:	shl    $0x5,%rbp
  822851:	jmp    8226f0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x3c0>
  822856:	lea    -0x10(%r12),%rax
  82285b:	and    0x8(%rbx),%rax
  82285f:	mov    (%rbx),%rcx
  822862:	movb   $0xff,(%rcx,%r12,1)
  822867:	mov    (%rbx),%rcx
  82286a:	movb   $0xff,0x10(%rcx,%rax,1)
  82286f:	movdqu (%r14),%xmm0
  822874:	movdqu 0x10(%r14),%xmm1
  82287a:	movdqu %xmm1,0x10(%rsi)
  82287f:	movdqu %xmm0,(%rsi)
  822883:	jmp    822827 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4f7>
  822885:	mov    0x8(%rbx),%rdx
  822889:	mov    0x18(%rbx),%rax
  82288d:	lea    0x1(%rdx),%rcx
  822891:	mov    %rcx,%rsi
  822894:	shr    $0x3,%rsi
  822898:	and    $0xfffffffffffffff8,%rcx
  82289c:	sub    %rsi,%rcx
  82289f:	cmp    $0x8,%rdx
  8228a3:	cmovb  %rdx,%rcx
  8228a7:	sub    %rax,%rcx
  8228aa:	mov    %rcx,0x10(%rbx)
  8228ae:	mov    $0xffffffffffffffff,%rax
  8228b5:	add    $0x58,%rsp
  8228b9:	pop    %rbx
  8228ba:	pop    %r12
  8228bc:	pop    %r13
  8228be:	pop    %r14
  8228c0:	pop    %r15
  8228c2:	pop    %rbp
  8228c3:	ret
  8228c4:	mov    (%rsp),%rbx
  8228c8:	mov    0x18(%rbx),%rcx
  8228cc:	mov    0x10(%rsp),%rbp
  8228d1:	jmp    8228ec <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x5bc>
  8228d3:	movzbl %bpl,%edi
  8228d7:	mov    $0x10,%esi
  8228dc:	mov    %r13,%rdx
  8228df:	call   *0x65d86b(%rip)        # e80150 <_DYNAMIC+0x690>
  8228e5:	jmp    8228b5 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x585>
  8228e7:	mov    (%rbx),%rsi
  8228ea:	xor    %ecx,%ecx
  8228ec:	sub    %rcx,%rbp
  8228ef:	mov    %r15,(%rbx)
  8228f2:	mov    0x8(%rbx),%rax
  8228f6:	mov    %rdi,0x8(%rbx)
  8228fa:	mov    %rbp,0x10(%rbx)
  8228fe:	mov    %rcx,0x18(%rbx)
  822902:	test   %rax,%rax
  822905:	je     8228ae <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x57e>
  822907:	mov    %rax,%rcx
  82290a:	shl    $0x5,%rcx
  82290e:	add    $0x2f,%rcx
  822912:	and    $0xffffffffffffffe0,%rcx
  822916:	add    %rcx,%rax
  822919:	add    $0x11,%rax
  82291d:	je     8228ae <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x57e>
  82291f:	sub    %rcx,%rsi
  822922:	mov    $0x10,%edx
  822927:	mov    %rsi,%rdi
  82292a:	mov    %rax,%rsi
  82292d:	call   *0x65d3d5(%rip)        # e7fd08 <_DYNAMIC+0x248>
  822933:	jmp    8228ae <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x57e>
  822938:	mov    $0x10,%edi
  82293d:	jmp    8226bc <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x38c>
  822942:	mov    %rax,%rbx
  822945:	lea    0x20(%rsp),%rdi
  82294a:	call   822f20 <core::ptr::drop_glue::<hashbrown::scopeguard::ScopeGuard<hashbrown::raw::RawTableInner, <hashbrown::raw::RawTableInner>::prepare_resize<alloc::alloc::Global>::{closure#0}>>>
  82294f:	mov    %rbx,%rdi
  822952:	call   e2c830 <_Unwind_Resume@plt>
  822957:	mov    %rax,%rbx
  82295a:	lea    0x20(%rsp),%rdi
  82295f:	call   822f60 <core::ptr::drop_glue::<hashbrown::scopeguard::ScopeGuard<&mut hashbrown::raw::RawTableInner, <hashbrown::raw::RawTableInner>::rehash_in_place::{closure#0}>>>
  822964:	mov    %rbx,%rdi
  822967:	call   e2c830 <_Unwind_Resume@plt>
  82296c:	call   *0x65d39e(%rip)        # e7fd10 <_DYNAMIC+0x250>

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000822980 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>>:
  822980:	push   %rbp
  822981:	push   %r15
  822983:	push   %r14
  822985:	push   %r13
  822987:	push   %r12
  822989:	push   %rbx
  82298a:	sub    $0x38,%rsp
  82298e:	mov    %ecx,%r15d
  822991:	mov    %rdx,0x20(%rsp)
  822996:	mov    %rdi,%rbp
  822999:	mov    0x18(%rdi),%rdi
  82299d:	add    %rdi,%rsi
  8229a0:	jb     822ab8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x138>
  8229a6:	mov    0x8(%rbp),%rbx
  8229aa:	lea    0x1(%rbx),%rdx
  8229ae:	mov    %rdx,%rax
  8229b1:	shr    $0x3,%rax
  8229b5:	mov    %rdx,%rcx
  8229b8:	and    $0xfffffffffffffff8,%rcx
  8229bc:	sub    %rax,%rcx
  8229bf:	cmp    $0x8,%rbx
  8229c3:	cmovb  %rbx,%rcx
  8229c7:	mov    %rcx,%rax
  8229ca:	shr    $1,%rax
  8229cd:	cmp    %rax,%rsi
  8229d0:	jbe    822a06 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x86>
  8229d2:	inc    %rcx
  8229d5:	cmp    %rsi,%rcx
  8229d8:	cmovbe %rsi,%rcx
  8229dc:	cmp    $0xf,%rcx
  8229e0:	mov    %rbp,(%rsp)
  8229e4:	mov    %rbx,0x30(%rsp)
  8229e9:	jae    822a38 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0xb8>
  8229eb:	mov    %ecx,%eax
  8229ed:	and    $0x8,%eax
  8229f0:	add    $0x8,%rax
  8229f4:	cmp    $0x4,%rcx
  8229f8:	mov    $0x4,%ebx
  8229fd:	cmovae %rax,%rbx
  822a01:	jmp    822a90 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x110>
  822a06:	test   %rdx,%rdx
  822a09:	je     822c4e <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2ce>
  822a0f:	mov    0x0(%rbp),%r12
  822a13:	mov    %rdx,%rax
  822a16:	shr    $0x4,%rax
  822a1a:	mov    %edx,%ecx
  822a1c:	and    $0xf,%ecx
  822a1f:	cmp    $0x1,%rcx
  822a23:	sbb    $0xffffffffffffffff,%rax
  822a27:	cmp    $0x1,%rax
  822a2b:	jne    822c55 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2d5>
  822a31:	xor    %ecx,%ecx
  822a33:	jmp    822ca8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x328>
  822a38:	movabs $0x1ffffffffffffffe,%rax
  822a42:	inc    %rax
  822a45:	cmp    %rax,%rcx
  822a48:	ja     822ab8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x138>
  822a4a:	shl    $0x3,%rcx
  822a4e:	movabs $0x2492492492492493,%rdx
  822a58:	mov    %rcx,%rax
  822a5b:	mul    %rdx
  822a5e:	sub    %rdx,%rcx
  822a61:	shr    $1,%rcx
  822a64:	add    %rdx,%rcx
  822a67:	shr    $0x2,%rcx
  822a6b:	dec    %rcx
  822a6e:	bsr    %rcx,%rcx
  822a72:	not    %ecx
  822a74:	mov    $0xffffffffffffffff,%rbx
  822a7b:	shr    %cl,%rbx
  822a7e:	movabs $0xffffffffffffffe,%rax
  822a88:	cmp    %rax,%rbx
  822a8b:	ja     822ab8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x138>
  822a8d:	inc    %rbx
  822a90:	mov    %rbx,%r14
  822a93:	shl    $0x4,%r14
  822a97:	lea    0x10(%rbx),%rbp
  822a9b:	mov    %rbp,%r13
  822a9e:	add    %r14,%r13
  822aa1:	setb   %al
  822aa4:	movabs $0x7ffffffffffffff0,%rcx
  822aae:	cmp    %rcx,%r13
  822ab1:	seta   %cl
  822ab4:	or     %al,%cl
  822ab6:	je     822ac7 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x147>
  822ab8:	movzbl %r15b,%edi
  822abc:	call   *0x65d676(%rip)        # e80138 <_DYNAMIC+0x678>
  822ac2:	jmp    822e88 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  822ac7:	mov    %rdi,0x8(%rsp)
  822acc:	call   *0x65d27e(%rip)        # e7fd50 <_DYNAMIC+0x290>
  822ad2:	mov    $0x10,%esi
  822ad7:	mov    %r13,%rdi
  822ada:	call   *0x65d278(%rip)        # e7fd58 <_DYNAMIC+0x298>
  822ae0:	test   %rax,%rax
  822ae3:	je     822ea2 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x522>
  822ae9:	mov    %rax,%rdi
  822aec:	add    %r14,%rdi
  822aef:	lea    -0x1(%rbx),%rcx
  822af3:	mov    %rbx,%rax
  822af6:	shr    $0x3,%rax
  822afa:	mov    %rbx,%r14
  822afd:	and    $0xfffffffffffffff8,%r14
  822b01:	sub    %rax,%r14
  822b04:	cmp    $0x9,%rbx
  822b08:	mov    %rcx,0x10(%rsp)
  822b0d:	cmovb  %rcx,%r14
  822b11:	mov    %rdi,0x18(%rsp)
  822b16:	mov    $0xff,%esi
  822b1b:	mov    %rbp,%rdx
  822b1e:	call   *0x65d61c(%rip)        # e80140 <memset@GLIBC_2.2.5>
  822b24:	mov    0x8(%rsp),%rbx
  822b29:	test   %rbx,%rbx
  822b2c:	je     822eb6 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x536>
  822b32:	mov    %r14,0x28(%rsp)
  822b37:	mov    (%rsp),%rax
  822b3b:	mov    (%rax),%rdi
  822b3e:	movdqa (%rdi),%xmm0
  822b42:	pmovmskb %xmm0,%r14d
  822b47:	not    %r14d
  822b4a:	xor    %ebp,%ebp
  822b4c:	mov    %rdi,%r13
  822b4f:	nop
  822b50:	test   %r14w,%r14w
  822b54:	jne    822b7f <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x1ff>
  822b56:	cs nopw 0x0(%rax,%rax,1)
  822b60:	movdqa 0x10(%r13),%xmm0
  822b66:	add    $0x10,%r13
  822b6a:	pmovmskb %xmm0,%r14d
  822b6f:	xor    $0xffff,%r14d
  822b76:	add    $0x10,%rbp
  822b7a:	test   %r14d,%r14d
  822b7d:	je     822b60 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x1e0>
  822b7f:	tzcnt  %r14d,%r15d
  822b84:	add    %rbp,%r15
  822b87:	mov    %r15,%rax
  822b8a:	shl    $0x4,%rax
  822b8e:	mov    %rdi,%r12
  822b91:	mov    %rdi,%rsi
  822b94:	sub    %rax,%rsi
  822b97:	add    $0xfffffffffffffff0,%rsi
  822b9b:	mov    0x20(%rsp),%rdi
  822ba0:	call   824d00 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  822ba5:	mov    %rax,%rcx
  822ba8:	mov    0x10(%rsp),%r9
  822bad:	and    %r9,%rcx
  822bb0:	mov    0x18(%rsp),%r8
  822bb5:	movdqu (%r8,%rcx,1),%xmm0
  822bbb:	pmovmskb %xmm0,%edx
  822bbf:	test   %edx,%edx
  822bc1:	je     822c20 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2a0>
  822bc3:	tzcnt  %edx,%edx
  822bc7:	add    %rcx,%rdx
  822bca:	and    %r9,%rdx
  822bcd:	cmpb   $0x0,(%r8,%rdx,1)
  822bd2:	mov    %r12,%rdi
  822bd5:	jns    822c3f <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2bf>
  822bd7:	lea    -0x1(%r14),%ecx
  822bdb:	and    %r14d,%ecx
  822bde:	dec    %rbx
  822be1:	shr    $0x39,%rax
  822be5:	lea    -0x10(%rdx),%rsi
  822be9:	and    %r9,%rsi
  822bec:	mov    %al,(%r8,%rdx,1)
  822bf0:	mov    %al,0x10(%r8,%rsi,1)
  822bf5:	not    %r15
  822bf8:	shl    $0x4,%r15
  822bfc:	not    %rdx
  822bff:	shl    $0x4,%rdx
  822c03:	movdqu (%rdi,%r15,1),%xmm0
  822c09:	movdqu %xmm0,(%r8,%rdx,1)
  822c0f:	mov    %ecx,%r14d
  822c12:	test   %rbx,%rbx
  822c15:	jne    822b50 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x1d0>
  822c1b:	jmp    822e97 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x517>
  822c20:	mov    $0x10,%esi
  822c25:	add    %rsi,%rcx
  822c28:	and    %r9,%rcx
  822c2b:	movdqu (%r8,%rcx,1),%xmm0
  822c31:	pmovmskb %xmm0,%edx
  822c35:	add    $0x10,%rsi
  822c39:	test   %edx,%edx
  822c3b:	jne    822bc3 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x243>
  822c3d:	jmp    822c25 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2a5>
  822c3f:	movdqa (%r8),%xmm0
  822c44:	pmovmskb %xmm0,%ecx
  822c48:	tzcnt  %ecx,%edx
  822c4c:	jmp    822bd7 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x257>
  822c4e:	xor    %eax,%eax
  822c50:	jmp    822e7a <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x4fa>
  822c55:	movabs $0x1ffffffffffffffe,%rsi
  822c5f:	and    %rax,%rsi
  822c62:	xor    %ecx,%ecx
  822c64:	movdqa -0x77506c(%rip),%xmm0        # adc00 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x820>
  822c6c:	nopl   0x0(%rax)
  822c70:	pxor   %xmm1,%xmm1
  822c74:	pcmpgtb (%r12,%rcx,1),%xmm1
  822c7a:	por    %xmm0,%xmm1
  822c7e:	movdqa %xmm1,(%r12,%rcx,1)
  822c84:	pxor   %xmm1,%xmm1
  822c88:	pcmpgtb 0x10(%r12,%rcx,1),%xmm1
  822c8f:	por    %xmm0,%xmm1
  822c93:	movdqa %xmm1,0x10(%r12,%rcx,1)
  822c9a:	add    $0x20,%rcx
  822c9e:	add    $0xfffffffffffffffe,%rsi
  822ca2:	jne    822c70 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2f0>
  822ca4:	test   $0x1,%al
  822ca6:	je     822cc0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x340>
  822ca8:	pxor   %xmm0,%xmm0
  822cac:	pcmpgtb (%r12,%rcx,1),%xmm0
  822cb2:	por    -0x7750ba(%rip),%xmm0        # adc00 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x820>
  822cba:	movdqa %xmm0,(%r12,%rcx,1)
  822cc0:	cmp    $0x10,%rdx
  822cc4:	jb     822f13 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x593>
  822cca:	mov    %rdx,%rdi
  822ccd:	mov    $0x10,%edx
  822cd2:	add    %r12,%rdi
  822cd5:	mov    %r12,%rsi
  822cd8:	call   *0x65d46a(%rip)        # e80148 <memmove@GLIBC_2.2.5>
  822cde:	xor    %r13d,%r13d
  822ce1:	xor    %eax,%eax
  822ce3:	jmp    822e16 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x496>
  822ce8:	nopl   0x0(%rax,%rax,1)
  822cf0:	lea    (%r12,%r14,1),%rsi
  822cf4:	add    $0xfffffffffffffff0,%rsi
  822cf8:	mov    0x20(%rsp),%rdi
  822cfd:	call   824d00 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  822d02:	mov    0x8(%rbp),%rcx
  822d06:	mov    %rcx,%rdx
  822d09:	and    %rax,%rdx
  822d0c:	movdqu (%r12,%rdx,1),%xmm0
  822d12:	pmovmskb %xmm0,%esi
  822d16:	mov    %rdx,%rdi
  822d19:	test   %esi,%esi
  822d1b:	je     822dab <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x42b>
  822d21:	tzcnt  %esi,%esi
  822d25:	add    %rdi,%rsi
  822d28:	and    %rcx,%rsi
  822d2b:	cmpb   $0x0,(%r12,%rsi,1)
  822d30:	jns    822dd2 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x452>
  822d36:	mov    %r13,%rdi
  822d39:	sub    %rdx,%rdi
  822d3c:	mov    %rsi,%r8
  822d3f:	sub    %rdx,%r8
  822d42:	xor    %rdi,%r8
  822d45:	and    %rcx,%r8
  822d48:	cmp    $0x10,%r8
  822d4c:	jb     822df0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x470>
  822d52:	mov    %rsi,%rdx
  822d55:	not    %rdx
  822d58:	shl    $0x4,%rdx
  822d5c:	add    %r12,%rdx
  822d5f:	movzbl (%r12,%rsi,1),%edi
  822d64:	shr    $0x39,%rax
  822d68:	lea    -0x10(%rsi),%r8
  822d6c:	and    %rcx,%r8
  822d6f:	mov    %al,(%r12,%rsi,1)
  822d73:	mov    0x0(%rbp),%r12
  822d77:	mov    %al,0x10(%r12,%r8,1)
  822d7c:	cmp    $0xff,%dil
  822d80:	je     822e3b <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x4bb>
  822d86:	mov    (%rbx),%rax
  822d89:	mov    (%rdx),%rcx
  822d8c:	mov    %rcx,(%rbx)
  822d8f:	mov    %rax,(%rdx)
  822d92:	mov    0x8(%rbx),%rax
  822d96:	mov    0x8(%rdx),%rcx
  822d9a:	mov    %rcx,0x8(%rbx)
  822d9e:	mov    %rax,0x8(%rdx)
  822da2:	mov    0x0(%rbp),%r12
  822da6:	jmp    822cf0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x370>
  822dab:	mov    $0x10,%r8d
  822db1:	mov    %rdx,%rdi
  822db4:	add    %r8,%rdi
  822db7:	and    %rcx,%rdi
  822dba:	movdqu (%r12,%rdi,1),%xmm0
  822dc0:	pmovmskb %xmm0,%esi
  822dc4:	add    $0x10,%r8
  822dc8:	test   %esi,%esi
  822dca:	jne    822d21 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x3a1>
  822dd0:	jmp    822db4 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x434>
  822dd2:	movdqa (%r12),%xmm0
  822dd8:	pmovmskb %xmm0,%esi
  822ddc:	tzcnt  %esi,%esi
  822de0:	jmp    822d36 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x3b6>
  822de5:	data16 cs nopw 0x0(%rax,%rax,1)
  822df0:	shr    $0x39,%rax
  822df4:	lea    -0x10(%r13),%rdx
  822df8:	and    %rdx,%rcx
  822dfb:	mov    %al,(%r12,%r13,1)
  822dff:	mov    0x0(%rbp),%r12
  822e03:	mov    %al,0x10(%r12,%rcx,1)
  822e08:	mov    %r15,%rbx
  822e0b:	xor    %eax,%eax
  822e0d:	cmp    %rbx,%r13
  822e10:	lea    0x1(%r13),%r13
  822e14:	je     822e58 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x4d8>
  822e16:	cmp    (%r12,%r13,1),%al
  822e1a:	jno    822e0d <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x48d>
  822e1c:	mov    %rbx,%r15
  822e1f:	mov    %r13,%rbx
  822e22:	not    %rbx
  822e25:	shl    $0x4,%rbx
  822e29:	add    %r12,%rbx
  822e2c:	mov    %r13,%r14
  822e2f:	neg    %r14
  822e32:	shl    $0x4,%r14
  822e36:	jmp    822cf0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x370>
  822e3b:	lea    -0x10(%r13),%rax
  822e3f:	and    0x8(%rbp),%rax
  822e43:	movb   $0xff,(%r12,%r13,1)
  822e48:	movb   $0xff,0x10(%r12,%rax,1)
  822e4e:	movdqu (%rbx),%xmm0
  822e52:	movdqu %xmm0,(%rdx)
  822e56:	jmp    822e08 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x488>
  822e58:	mov    0x8(%rbp),%rcx
  822e5c:	mov    0x18(%rbp),%rdi
  822e60:	lea    0x1(%rcx),%rax
  822e64:	mov    %rax,%rdx
  822e67:	shr    $0x3,%rdx
  822e6b:	and    $0xfffffffffffffff8,%rax
  822e6f:	sub    %rdx,%rax
  822e72:	cmp    $0x8,%rcx
  822e76:	cmovb  %rcx,%rax
  822e7a:	sub    %rdi,%rax
  822e7d:	mov    %rax,0x10(%rbp)
  822e81:	mov    $0xffffffffffffffff,%rax
  822e88:	add    $0x38,%rsp
  822e8c:	pop    %rbx
  822e8d:	pop    %r12
  822e8f:	pop    %r13
  822e91:	pop    %r14
  822e93:	pop    %r15
  822e95:	pop    %rbp
  822e96:	ret
  822e97:	mov    (%rsp),%rax
  822e9b:	mov    0x28(%rsp),%r14
  822ea0:	jmp    822ec7 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x547>
  822ea2:	movzbl %r15b,%edi
  822ea6:	mov    $0x10,%esi
  822eab:	mov    %r13,%rdx
  822eae:	call   *0x65d29c(%rip)        # e80150 <_DYNAMIC+0x690>
  822eb4:	jmp    822e88 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  822eb6:	mov    (%rsp),%rax
  822eba:	mov    (%rax),%rdi
  822ebd:	mov    0x18(%rsp),%r8
  822ec2:	mov    0x10(%rsp),%r9
  822ec7:	sub    0x8(%rsp),%r14
  822ecc:	mov    %r8,(%rax)
  822ecf:	mov    %r9,0x8(%rax)
  822ed3:	mov    %r14,0x10(%rax)
  822ed7:	mov    $0xffffffffffffffff,%rax
  822ede:	mov    0x30(%rsp),%rsi
  822ee3:	test   %rsi,%rsi
  822ee6:	je     822e88 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  822ee8:	mov    %rsi,%rcx
  822eeb:	shl    $0x4,%rcx
  822eef:	add    $0x1f,%rcx
  822ef3:	and    $0xfffffffffffffff0,%rcx
  822ef7:	add    %rcx,%rsi
  822efa:	add    $0x11,%rsi
  822efe:	je     822e88 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  822f00:	sub    %rcx,%rdi
  822f03:	mov    $0x10,%edx
  822f08:	call   *0x65cdfa(%rip)        # e7fd08 <_DYNAMIC+0x248>
  822f0e:	jmp    822e81 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x501>
  822f13:	mov    $0x10,%edi
  822f18:	jmp    822cd2 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x352>

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008230d0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>:
  8230d0:	mov    0x8(%rdi),%rsi
  8230d4:	test   %rsi,%rsi
  8230d7:	je     8230fe <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  8230d9:	mov    %rsi,%rax
  8230dc:	shl    $0x5,%rax
  8230e0:	add    %rax,%rsi
  8230e3:	add    $0x31,%rsi
  8230e7:	je     8230fe <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  8230e9:	mov    (%rdi),%rdi
  8230ec:	sub    %rax,%rdi
  8230ef:	add    $0xffffffffffffffe0,%rdi
  8230f3:	mov    $0x10,%edx
  8230f8:	jmp    *0x65cc0a(%rip)        # e7fd08 <_DYNAMIC+0x248>
  8230fe:	ret

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000823100 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>:
  823100:	push   %rbx
  823101:	test   %rdi,%rdi
  823104:	je     823167 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x67>
  823106:	mov    %rdi,%rbx
  823109:	mov    (%rdi),%rsi
  82310c:	test   %rsi,%rsi
  82310f:	je     823124 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x24>
  823111:	mov    0x8(%rbx),%rdi
  823115:	shl    $0x3,%rsi
  823119:	mov    $0x8,%edx
  82311e:	call   *0x65cbe4(%rip)        # e7fd08 <_DYNAMIC+0x248>
  823124:	mov    0x20(%rbx),%rsi
  823128:	test   %rsi,%rsi
  82312b:	je     823153 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  82312d:	mov    %rsi,%rax
  823130:	shl    $0x4,%rax
  823134:	add    %rax,%rsi
  823137:	add    $0x21,%rsi
  82313b:	je     823153 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  82313d:	mov    0x18(%rbx),%rdi
  823141:	sub    %rax,%rdi
  823144:	add    $0xfffffffffffffff0,%rdi
  823148:	mov    $0x10,%edx
  82314d:	call   *0x65cbb5(%rip)        # e7fd08 <_DYNAMIC+0x248>
  823153:	mov    $0x80,%esi
  823158:	mov    $0x8,%edx
  82315d:	mov    %rbx,%rdi
  823160:	pop    %rbx
  823161:	jmp    *0x65cba1(%rip)        # e7fd08 <_DYNAMIC+0x248>
  823167:	pop    %rbx
  823168:	ret

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000823390 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>:
  823390:	push   %r14
  823392:	push   %rbx
  823393:	push   %rax
  823394:	mov    %rdi,%rbx
  823397:	mov    (%rdi),%rax
  82339a:	lock decq (%rax)
  82339e:	jne    8233a9 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x19>
  8233a0:	mov    %rbx,%rdi
  8233a3:	call   *0x65cc1f(%rip)        # e7ffc8 <_DYNAMIC+0x508>
  8233a9:	mov    0x8(%rbx),%rax
  8233ad:	lock decq (%rax)
  8233b1:	jne    8233c7 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x37>
  8233b3:	add    $0x8,%rbx
  8233b7:	mov    %rbx,%rdi
  8233ba:	add    $0x8,%rsp
  8233be:	pop    %rbx
  8233bf:	pop    %r14
  8233c1:	jmp    *0x65cc09(%rip)        # e7ffd0 <_DYNAMIC+0x510>
  8233c7:	add    $0x8,%rsp
  8233cb:	pop    %rbx
  8233cc:	pop    %r14
  8233ce:	ret
  8233cf:	mov    %rax,%r14
  8233d2:	mov    0x8(%rbx),%rax
  8233d6:	lock decq (%rax)
  8233da:	jne    8233e9 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x59>
  8233dc:	add    $0x8,%rbx
  8233e0:	mov    %rbx,%rdi
  8233e3:	call   *0x65cbe7(%rip)        # e7ffd0 <_DYNAMIC+0x510>
  8233e9:	mov    %r14,%rdi
  8233ec:	call   e2c830 <_Unwind_Resume@plt>
  8233f1:	call   *0x65c919(%rip)        # e7fd10 <_DYNAMIC+0x250>

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008234c0 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>:
  8234c0:	push   %rbx
  8234c1:	mov    %rdi,%rbx
  8234c4:	mov    (%rdi),%rsi
  8234c7:	test   %rsi,%rsi
  8234ca:	je     8234df <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>+0x1f>
  8234cc:	mov    0x8(%rbx),%rdi
  8234d0:	shl    $0x3,%rsi
  8234d4:	mov    $0x8,%edx
  8234d9:	call   *0x65c829(%rip)        # e7fd08 <_DYNAMIC+0x248>
  8234df:	mov    0x20(%rbx),%rsi
  8234e3:	test   %rsi,%rsi
  8234e6:	je     82350f <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>+0x4f>
  8234e8:	mov    %rsi,%rax
  8234eb:	shl    $0x4,%rax
  8234ef:	add    %rax,%rsi
  8234f2:	add    $0x21,%rsi
  8234f6:	je     82350f <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>+0x4f>
  8234f8:	mov    0x18(%rbx),%rdi
  8234fc:	sub    %rax,%rdi
  8234ff:	add    $0xfffffffffffffff0,%rdi
  823503:	mov    $0x10,%edx
  823508:	pop    %rbx
  823509:	jmp    *0x65c7f9(%rip)        # e7fd08 <_DYNAMIC+0x248>
  82350f:	pop    %rbx
  823510:	ret

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000823520 <<gpui_gpu::renderer::images::Images>::metadata>:
  823520:	push   %r15
  823522:	push   %r14
  823524:	push   %rbx
  823525:	sub    $0x10,%rsp
  823529:	mov    %rsi,0x8(%rsp)
  82352e:	cmpq   $0x0,0x30(%rdi)
  823533:	je     8235fd <<gpui_gpu::renderer::images::Images>::metadata+0xdd>
  823539:	mov    %edx,%ebx
  82353b:	mov    %rsi,%r14
  82353e:	mov    %rdi,%r15
  823541:	add    $0x38,%rdi
  823545:	lea    0x8(%rsp),%rsi
  82354a:	call   824d00 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  82354f:	mov    %rax,%rsi
  823552:	shr    $0x39,%rsi
  823556:	mov    0x18(%r15),%rcx
  82355a:	mov    0x20(%r15),%rdx
  82355e:	movd   %esi,%xmm0
  823562:	punpcklbw %xmm0,%xmm0
  823566:	pshuflw $0x0,%xmm0,%xmm0
  82356b:	pshufd $0x44,%xmm0,%xmm0
  823570:	xor    %esi,%esi
  823572:	pcmpeqd %xmm1,%xmm1
  823576:	and    %rdx,%rax
  823579:	movdqu (%rcx,%rax,1),%xmm2
  82357e:	movdqa %xmm2,%xmm3
  823582:	pcmpeqb %xmm0,%xmm3
  823586:	pmovmskb %xmm3,%edi
  82358a:	test   %edi,%edi
  82358c:	je     8235c0 <<gpui_gpu::renderer::images::Images>::metadata+0xa0>
  82358e:	tzcnt  %edi,%r9d
  823593:	add    %rax,%r9
  823596:	and    %rdx,%r9
  823599:	shl    $0x4,%r9
  82359d:	mov    %rcx,%r8
  8235a0:	sub    %r9,%r8
  8235a3:	cmp    -0x10(%r8),%r14
  8235a7:	je     8235d9 <<gpui_gpu::renderer::images::Images>::metadata+0xb9>
  8235a9:	lea    -0x1(%rdi),%r8d
  8235ad:	and    %di,%r8w
  8235b1:	mov    %r8d,%edi
  8235b4:	jne    82358e <<gpui_gpu::renderer::images::Images>::metadata+0x6e>
  8235b6:	cs nopw 0x0(%rax,%rax,1)
  8235c0:	pcmpeqb %xmm1,%xmm2
  8235c4:	pmovmskb %xmm2,%edi
  8235c8:	test   %edi,%edi
  8235ca:	jne    8235fd <<gpui_gpu::renderer::images::Images>::metadata+0xdd>
  8235cc:	add    %rsi,%rax
  8235cf:	add    $0x10,%rax
  8235d3:	add    $0x10,%rsi
  8235d7:	jmp    823576 <<gpui_gpu::renderer::images::Images>::metadata+0x56>
  8235d9:	mov    -0x8(%r8),%eax
  8235dd:	movzbl %bl,%ecx
  8235e0:	or     -0x4(%r8),%ecx
  8235e4:	shl    $0x20,%rcx
  8235e8:	or     %rax,%rcx
  8235eb:	mov    $0x80000000,%eax
  8235f0:	or     %rcx,%rax
  8235f3:	add    $0x10,%rsp
  8235f7:	pop    %rbx
  8235f8:	pop    %r14
  8235fa:	pop    %r15
  8235fc:	ret
  8235fd:	lea    -0x74e9a8(%rip),%rdi        # d4c5c <anon.81378166eea1c96e15e7851dcdc35f4e.0.llvm.4385859340901971677>
  823604:	lea    0x60b165(%rip),%rdx        # e2e770 <anon.81378166eea1c96e15e7851dcdc35f4e.2.llvm.4385859340901971677>
  82360b:	mov    $0x16,%esi
  823610:	call   *0x65ca4a(%rip)        # e80060 <_DYNAMIC+0x5a0>

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000823980 <gpui_gpu::renderer::images::prepare>:
  823980:	push   %rbp
  823981:	push   %r15
  823983:	push   %r14
  823985:	push   %r13
  823987:	push   %r12
  823989:	push   %rbx
  82398a:	sub    $0x1f8,%rsp
  823991:	mov    %r9,%r12
  823994:	mov    %rcx,%r13
  823997:	mov    %rdx,0xb8(%rsp)
  82399f:	mov    %rsi,0x8(%rsp)
  8239a4:	mov    %rdi,%r15
  8239a7:	mov    0x230(%rsp),%rax
  8239af:	mov    0x10(%rax),%r14
  8239b3:	mov    0x118(%r14),%rax
  8239ba:	add    $0x118,%r14
  8239c1:	test   %rax,%rax
  8239c4:	mov    %r14,%rcx
  8239c7:	cmove  %rax,%rcx
  8239cb:	je     823a66 <gpui_gpu::renderer::images::prepare+0xe6>
  8239d1:	mov    0x10(%rax),%rax
  8239d5:	mov    (%r8),%rbp
  8239d8:	mov    %rax,0x18(%rsp)
  8239dd:	test   %rax,%rax
  8239e0:	je     823a69 <gpui_gpu::renderer::images::prepare+0xe9>
  8239e6:	mov    %rcx,0xa8(%rsp)
  8239ee:	test   %rbp,%rbp
  8239f1:	je     823bbb <gpui_gpu::renderer::images::prepare+0x23b>
  8239f7:	cmp    0x48(%rbp),%r12
  8239fb:	ja     823bbb <gpui_gpu::renderer::images::prepare+0x23b>
  823a01:	mov    0x8(%rbp),%rdi
  823a05:	mov    0x10(%rbp),%rax
  823a09:	lea    (%rdi,%rax,8),%rsi
  823a0d:	movq   $0x1,0xe0(%rsp)
  823a19:	mov    %r14,0xe8(%rsp)
  823a21:	movq   $0x0,0xf0(%rsp)
  823a2d:	movq   $0x0,0x100(%rsp)
  823a39:	lea    0xe0(%rsp),%rdx
  823a41:	mov    %r8,%rbx
  823a44:	call   8248b0 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>>
  823a49:	mov    %rbx,%r8
  823a4c:	test   %al,%al
  823a4e:	je     823bbb <gpui_gpu::renderer::images::prepare+0x23b>
  823a54:	movq   $0x0,0x60(%rbp)
  823a5c:	movb   $0x0,0x4(%r15)
  823a61:	jmp    823b9f <gpui_gpu::renderer::images::prepare+0x21f>
  823a66:	mov    (%r8),%rbp
  823a69:	movq   $0x0,(%r8)
  823a70:	test   %rbp,%rbp
  823a73:	je     823b97 <gpui_gpu::renderer::images::prepare+0x217>
  823a79:	mov    0x0(%rbp),%rsi
  823a7d:	test   %rsi,%rsi
  823a80:	je     823a95 <gpui_gpu::renderer::images::prepare+0x115>
  823a82:	mov    0x8(%rbp),%rdi
  823a86:	shl    $0x3,%rsi
  823a8a:	mov    $0x8,%edx
  823a8f:	call   *0x65c273(%rip)        # e7fd08 <_DYNAMIC+0x248>
  823a95:	mov    0x20(%rbp),%rsi
  823a99:	test   %rsi,%rsi
  823a9c:	je     823ac4 <gpui_gpu::renderer::images::prepare+0x144>
  823a9e:	mov    %rsi,%rax
  823aa1:	shl    $0x4,%rax
  823aa5:	add    %rax,%rsi
  823aa8:	add    $0x21,%rsi
  823aac:	je     823ac4 <gpui_gpu::renderer::images::prepare+0x144>
  823aae:	mov    0x18(%rbp),%rdi
  823ab2:	sub    %rax,%rdi
  823ab5:	add    $0xfffffffffffffff0,%rdi
  823ab9:	mov    $0x10,%edx
  823abe:	call   *0x65c244(%rip)        # e7fd08 <_DYNAMIC+0x248>
  823ac4:	mov    $0x80,%esi
  823ac9:	mov    $0x8,%edx
  823ace:	mov    %rbp,%rdi
  823ad1:	call   *0x65c231(%rip)        # e7fd08 <_DYNAMIC+0x248>
  823ad7:	shl    $0x4,%r12
  823adb:	cmp    $0x101,%r12
  823ae2:	mov    $0x100,%eax
  823ae7:	cmovae %r12,%rax
  823aeb:	dec    %rax
  823aee:	bsr    %rax,%rcx
  823af2:	not    %ecx
  823af4:	mov    $0xffffffffffffffff,%rbx
  823afb:	shr    %cl,%rbx
  823afe:	inc    %rbx
  823b01:	lea    -0x74ee96(%rip),%rax        # d4c72 <anon.81378166eea1c96e15e7851dcdc35f4e.0.llvm.4385859340901971677+0x16>
  823b08:	mov    %rax,0x20(%rsp)
  823b0d:	movq   $0xa,0x28(%rsp)
  823b16:	mov    %rbx,0x30(%rsp)
  823b1b:	movl   $0x88,0x38(%rsp)
  823b23:	movb   $0x0,0x3c(%rsp)
  823b28:	lea    0xe0(%rsp),%rdi
  823b30:	lea    0x20(%rsp),%rdx
  823b35:	mov    0x8(%rsp),%rsi
  823b3a:	call   *0x65c5a0(%rip)        # e800e0 <_DYNAMIC+0x620>
  823b40:	mov    %rbx,0x100(%rsp)
  823b48:	mov    0x0(%r13),%rax
  823b4c:	lock decq (%rax)
  823b50:	jne    823b5b <gpui_gpu::renderer::images::prepare+0x1db>
  823b52:	mov    %r13,%rdi
  823b55:	call   *0x65c46d(%rip)        # e7ffc8 <_DYNAMIC+0x508>
  823b5b:	mov    0x8(%r13),%rax
  823b5f:	lock decq (%rax)
  823b63:	jne    823b6f <gpui_gpu::renderer::images::prepare+0x1ef>
  823b65:	lea    0x8(%r13),%rdi
  823b69:	call   *0x65c461(%rip)        # e7ffd0 <_DYNAMIC+0x510>
  823b6f:	mov    0x100(%rsp),%rax
  823b77:	mov    %rax,0x20(%r13)
  823b7b:	movdqu 0xe0(%rsp),%xmm0
  823b84:	movups 0xf0(%rsp),%xmm1
  823b8c:	movups %xmm1,0x10(%r13)
  823b91:	movdqu %xmm0,0x0(%r13)
  823b97:	test   %rbp,%rbp
  823b9a:	setne  0x4(%r15)
  823b9f:	movl   $0xffffffff,(%r15)
  823ba6:	mov    %r15,%rax
  823ba9:	add    $0x1f8,%rsp
  823bb0:	pop    %rbx
  823bb1:	pop    %r12
  823bb3:	pop    %r13
  823bb5:	pop    %r14
  823bb7:	pop    %r15
  823bb9:	pop    %rbp
  823bba:	ret
  823bbb:	cmp    $0x1,%r12
  823bbf:	mov    %r12,%rax
  823bc2:	adc    $0xffffffffffffffff,%rax
  823bc6:	bsr    %rax,%rcx
  823bca:	not    %ecx
  823bcc:	mov    $0xffffffffffffffff,%rax
  823bd3:	shr    %cl,%rax
  823bd6:	cmp    $0x2,%r12
  823bda:	mov    $0x0,%r12d
  823be0:	cmovae %rax,%r12
  823be4:	inc    %r12
  823be7:	je     824312 <gpui_gpu::renderer::images::prepare+0x992>
  823bed:	mov    %r8,0xd0(%rsp)
  823bf5:	mov    %fs:0x0,%rax
  823bfe:	lea    -0x28(%rax),%rax
  823c05:	mov    %rax,%rcx
  823c08:	cmpb   $0x1,0x10(%rax)
  823c0c:	mov    %r15,0xb0(%rsp)
  823c14:	mov    %r13,0xd8(%rsp)
  823c1c:	jne    82431e <gpui_gpu::renderer::images::prepare+0x99e>
  823c22:	mov    (%rcx),%rax
  823c25:	mov    0x8(%rcx),%rdx
  823c29:	mov    0x18(%rsp),%rbx
  823c2e:	lea    0x1(%rax),%rsi
  823c32:	mov    %rsi,(%rcx)
  823c35:	movq   $0x0,0x20(%rsp)
  823c3e:	movq   $0x8,0x28(%rsp)
  823c47:	movq   $0x0,0x30(%rsp)
  823c50:	movups 0x60ab31(%rip),%xmm0        # e2e788 <anon.81378166eea1c96e15e7851dcdc35f4e.2.llvm.4385859340901971677+0x18>
  823c57:	movups %xmm0,0x38(%rsp)
  823c5c:	movdqu 0x60ab34(%rip),%xmm0        # e2e798 <anon.81378166eea1c96e15e7851dcdc35f4e.2.llvm.4385859340901971677+0x28>
  823c64:	movdqu %xmm0,0x48(%rsp)
  823c6a:	mov    %rax,0x58(%rsp)
  823c6f:	mov    %rdx,0x60(%rsp)
  823c74:	mov    %r12,0x68(%rsp)
  823c79:	pxor   %xmm0,%xmm0
  823c7d:	movdqu %xmm0,0x70(%rsp)
  823c83:	movdqu %xmm0,0x80(%rsp)
  823c8c:	movdqu %xmm0,0x90(%rsp)
  823c95:	lea    0xe0(%rsp),%rdi
  823c9d:	mov    $0x8,%edx
  823ca2:	mov    $0x8,%r8d
  823ca8:	mov    $0x8,%r9d
  823cae:	xor    %esi,%esi
  823cb0:	mov    %rbx,%rcx
  823cb3:	call   825f50 <<alloc::raw_vec::RawVecInner>::finish_grow>
  823cb8:	cmpl   $0x1,0xe0(%rsp)
  823cc0:	jne    823d2d <gpui_gpu::renderer::images::prepare+0x3ad>
  823cc2:	mov    0xb0(%rsp),%r15
  823cca:	movl   $0x6,(%r15)
  823cd1:	mov    0x20(%rsp),%rsi
  823cd6:	test   %rsi,%rsi
  823cd9:	je     823cef <gpui_gpu::renderer::images::prepare+0x36f>
  823cdb:	mov    0x28(%rsp),%rdi
  823ce0:	shl    $0x3,%rsi
  823ce4:	mov    $0x8,%edx
  823ce9:	call   *0x65c019(%rip)        # e7fd08 <_DYNAMIC+0x248>
  823cef:	mov    0x40(%rsp),%rsi
  823cf4:	test   %rsi,%rsi
  823cf7:	je     823ba6 <gpui_gpu::renderer::images::prepare+0x226>
  823cfd:	mov    %rsi,%rax
  823d00:	shl    $0x4,%rax
  823d04:	add    %rax,%rsi
  823d07:	add    $0x21,%rsi
  823d0b:	je     823ba6 <gpui_gpu::renderer::images::prepare+0x226>
  823d11:	mov    0x38(%rsp),%rdi
  823d16:	sub    %rax,%rdi
  823d19:	add    $0xfffffffffffffff0,%rdi
  823d1d:	mov    $0x10,%edx
  823d22:	call   *0x65bfe0(%rip)        # e7fd08 <_DYNAMIC+0x248>
  823d28:	jmp    823ba6 <gpui_gpu::renderer::images::prepare+0x226>
  823d2d:	mov    %r12,0xa0(%rsp)
  823d35:	mov    %rbp,0xc8(%rsp)
  823d3d:	mov    0xe8(%rsp),%rax
  823d45:	mov    %rax,0x28(%rsp)
  823d4a:	mov    %rbx,0x20(%rsp)
  823d4f:	cmp    0x48(%rsp),%rbx
  823d54:	ja     82433a <gpui_gpu::renderer::images::prepare+0x9ba>
  823d5a:	xor    %r12d,%r12d
  823d5d:	mov    0xa0(%rsp),%r15
  823d65:	jmp    823d88 <gpui_gpu::renderer::images::prepare+0x408>
  823d67:	nopw   0x0(%rax,%rax,1)
  823d70:	add    $0x8,%r12
  823d74:	mov    0x28(%rsp),%rax
  823d79:	mov    %rbx,(%rax,%r15,8)
  823d7d:	inc    %r15
  823d80:	mov    %r15,0x30(%rsp)
  823d85:	mov    %r13,%r15
  823d88:	test   %r12,%r12
  823d8b:	je     823db0 <gpui_gpu::renderer::images::prepare+0x430>
  823d8d:	cmp    %rbp,%r12
  823d90:	je     823db0 <gpui_gpu::renderer::images::prepare+0x430>
  823d92:	mov    (%r12),%rcx
  823d96:	cmpb   $0x0,0x10(%rcx)
  823d9a:	je     823dde <gpui_gpu::renderer::images::prepare+0x45e>
  823d9c:	mov    0x20(%rcx),%rax
  823da0:	shl    $0x4,%rax
  823da4:	mov    $0x8,%r8d
  823daa:	jmp    823df1 <gpui_gpu::renderer::images::prepare+0x471>
  823dac:	nopl   0x0(%rax)
  823db0:	test   %r14,%r14
  823db3:	je     823e78 <gpui_gpu::renderer::images::prepare+0x4f8>
  823db9:	mov    (%r14),%rax
  823dbc:	mov    0x10(%rax),%rcx
  823dc0:	test   %rcx,%rcx
  823dc3:	je     823e78 <gpui_gpu::renderer::images::prepare+0x4f8>
  823dc9:	mov    0x8(%rax),%r12
  823dcd:	lea    (%r12,%rcx,8),%rbp
  823dd1:	xor    %r14d,%r14d
  823dd4:	mov    (%r12),%rcx
  823dd8:	cmpb   $0x0,0x10(%rcx)
  823ddc:	jne    823d9c <gpui_gpu::renderer::images::prepare+0x41c>
  823dde:	movzbl 0x11(%rcx),%edx
  823de2:	movzbl 0x12(%rcx),%esi
  823de6:	mov    0x20(%rcx),%rax
  823dea:	shl    $0x2,%edx
  823ded:	lea    (%rdx,%rsi,2),%r8d
  823df1:	mov    0x78(%rsp),%rdx
  823df6:	add    %rax,%rdx
  823df9:	jb     823cc2 <gpui_gpu::renderer::images::prepare+0x342>
  823dff:	mov    0x28(%rcx),%rbx
  823e03:	mov    %rdx,0x78(%rsp)
  823e08:	cmp    $0x4000000,%rdx
  823e0f:	ja     823cc2 <gpui_gpu::renderer::images::prepare+0x342>
  823e15:	mov    %r15,%rcx
  823e18:	shr    $0x20,%rcx
  823e1c:	jne    823cc2 <gpui_gpu::renderer::images::prepare+0x342>
  823e22:	test   %r15d,%r15d
  823e25:	js     823cc2 <gpui_gpu::renderer::images::prepare+0x342>
  823e2b:	mov    %rax,%r13
  823e2e:	shr    $0x4,%r13
  823e32:	and    $0xf,%eax
  823e35:	add    %r15,%r13
  823e38:	cmp    $0x1,%rax
  823e3c:	sbb    $0xffffffffffffffff,%r13
  823e40:	lea    0xe0(%rsp),%rdi
  823e48:	lea    0x38(%rsp),%rsi
  823e4d:	mov    %rbx,%rdx
  823e50:	mov    %r15d,%ecx
  823e53:	call   825680 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert>
  823e58:	mov    0x30(%rsp),%r15
  823e5d:	cmp    0x20(%rsp),%r15
  823e62:	jne    823d70 <gpui_gpu::renderer::images::prepare+0x3f0>
  823e68:	lea    0x20(%rsp),%rdi
  823e6d:	call   *0x65c315(%rip)        # e80188 <_DYNAMIC+0x6c8>
  823e73:	jmp    823d70 <gpui_gpu::renderer::images::prepare+0x3f0>
  823e78:	movabs $0xffffffffffffff0,%rax
  823e82:	cmp    %rax,%r15
  823e85:	ja     823cc2 <gpui_gpu::renderer::images::prepare+0x342>
  823e8b:	lea    0xe0(%rsp),%rdi
  823e93:	mov    0x8(%rsp),%rsi
  823e98:	call   *0x65c2f2(%rip)        # e80190 <_DYNAMIC+0x6d0>
  823e9e:	mov    %r15,%rbx
  823ea1:	shl    $0x4,%rbx
  823ea5:	add    $0xff,%rbx
  823eac:	and    $0xffffffffffffff00,%rbx
  823eb3:	cmp    0x130(%rsp),%rbx
  823ebb:	ja     823cc2 <gpui_gpu::renderer::images::prepare+0x342>
  823ec1:	lea    0xe0(%rsp),%rdi
  823ec9:	mov    0x8(%rsp),%rsi
  823ece:	call   *0x65c2bc(%rip)        # e80190 <_DYNAMIC+0x6d0>
  823ed4:	cmp    0x140(%rsp),%rbx
  823edc:	ja     823cc2 <gpui_gpu::renderer::images::prepare+0x342>
  823ee2:	mov    0xd8(%rsp),%r14
  823eea:	mov    0x20(%r14),%rax
  823eee:	cmp    %rbx,%rax
  823ef1:	jb     823f22 <gpui_gpu::renderer::images::prepare+0x5a2>
  823ef3:	lea    0x0(,%rbx,4),%rcx
  823efb:	movabs $0x3fffffffffffff1,%rdx
  823f05:	cmp    %rdx,%r15
  823f08:	setb   %dl
  823f0b:	cmp    %rcx,%rax
  823f0e:	seta   %al
  823f11:	test   %al,%dl
  823f13:	jne    823f22 <gpui_gpu::renderer::images::prepare+0x5a2>
  823f15:	movl   $0x0,0x14(%rsp)
  823f1d:	jmp    823fb5 <gpui_gpu::renderer::images::prepare+0x635>
  823f22:	lea    -0x74f2ad(%rip),%rax        # d4c7c <anon.81378166eea1c96e15e7851dcdc35f4e.0.llvm.4385859340901971677+0x20>
  823f29:	mov    %rax,0x1d8(%rsp)
  823f31:	movq   $0x1d,0x1e0(%rsp)
  823f3d:	mov    %rbx,0x1e8(%rsp)
  823f45:	movl   $0x88,0x1f0(%rsp)
  823f50:	movb   $0x0,0x1f4(%rsp)
  823f58:	lea    0xe0(%rsp),%rdi
  823f60:	lea    0x1d8(%rsp),%rdx
  823f68:	mov    0x8(%rsp),%rsi
  823f6d:	call   *0x65c16d(%rip)        # e800e0 <_DYNAMIC+0x620>
  823f73:	mov    %rbx,0x100(%rsp)
  823f7b:	mov    %r14,%r15
  823f7e:	mov    %r14,%rdi
  823f81:	call   823390 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  823f86:	mov    0x100(%rsp),%rax
  823f8e:	mov    %rax,0x20(%r15)
  823f92:	movdqu 0xe0(%rsp),%xmm0
  823f9b:	movdqu 0xf0(%rsp),%xmm1
  823fa4:	movdqu %xmm1,0x10(%r15)
  823faa:	movdqu %xmm0,(%r15)
  823faf:	mov    $0x1,%al
  823fb1:	mov    %eax,0x14(%rsp)
  823fb5:	movq   $0x0,0x8(%rsp)
  823fbe:	mov    0x8(%rsp),%rdx
  823fc3:	test   %rdx,%rdx
  823fc6:	je     823fd2 <gpui_gpu::renderer::images::prepare+0x652>
  823fc8:	cmp    0xc0(%rsp),%rdx
  823fd0:	jne    82400f <gpui_gpu::renderer::images::prepare+0x68f>
  823fd2:	mov    0xa8(%rsp),%rax
  823fda:	test   %rax,%rax
  823fdd:	je     8241a5 <gpui_gpu::renderer::images::prepare+0x825>
  823fe3:	mov    (%rax),%rax
  823fe6:	mov    0x10(%rax),%rcx
  823fea:	test   %rcx,%rcx
  823fed:	je     8241a5 <gpui_gpu::renderer::images::prepare+0x825>
  823ff3:	mov    0x8(%rax),%rdx
  823ff7:	lea    (%rdx,%rcx,8),%rax
  823ffb:	mov    %rax,0xc0(%rsp)
  824003:	movq   $0x0,0xa8(%rsp)
  82400f:	mov    (%rdx),%rax
  824012:	mov    0x28(%rax),%r12
  824016:	movzbl 0x10(%rax),%ebx
  82401a:	mov    0x18(%rax),%rbp
  82401e:	mov    0x20(%rax),%r13
  824022:	mov    %r12,0xe0(%rsp)
  82402a:	cmpq   $0x0,0x50(%rsp)
  824030:	je     82418a <gpui_gpu::renderer::images::prepare+0x80a>
  824036:	add    $0x8,%rdx
  82403a:	mov    %rdx,0x8(%rsp)
  82403f:	lea    0x58(%rsp),%rdi
  824044:	lea    0xe0(%rsp),%rsi
  82404c:	call   824d00 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  824051:	mov    %rax,%rsi
  824054:	shr    $0x39,%rsi
  824058:	mov    0x38(%rsp),%rcx
  82405d:	mov    0x40(%rsp),%rdx
  824062:	movd   %esi,%xmm0
  824066:	punpcklbw %xmm0,%xmm0
  82406a:	pshuflw $0x0,%xmm0,%xmm0
  82406f:	pshufd $0x44,%xmm0,%xmm0
  824074:	xor    %esi,%esi
  824076:	and    %rdx,%rax
  824079:	movdqu (%rcx,%rax,1),%xmm1
  82407e:	movdqa %xmm1,%xmm2
  824082:	pcmpeqb %xmm0,%xmm2
  824086:	pmovmskb %xmm2,%edi
  82408a:	test   %edi,%edi
  82408c:	je     8240b6 <gpui_gpu::renderer::images::prepare+0x736>
  82408e:	tzcnt  %edi,%r9d
  824093:	add    %rax,%r9
  824096:	and    %rdx,%r9
  824099:	shl    $0x4,%r9
  82409d:	mov    %rcx,%r8
  8240a0:	sub    %r9,%r8
  8240a3:	cmp    -0x10(%r8),%r12
  8240a7:	je     8240d7 <gpui_gpu::renderer::images::prepare+0x757>
  8240a9:	lea    -0x1(%rdi),%r8d
  8240ad:	and    %di,%r8w
  8240b1:	mov    %r8d,%edi
  8240b4:	jne    82408e <gpui_gpu::renderer::images::prepare+0x70e>
  8240b6:	pcmpeqd %xmm2,%xmm2
  8240ba:	pcmpeqb %xmm2,%xmm1
  8240be:	pmovmskb %xmm1,%edi
  8240c2:	test   %edi,%edi
  8240c4:	jne    82418a <gpui_gpu::renderer::images::prepare+0x80a>
  8240ca:	add    %rsi,%rax
  8240cd:	add    $0x10,%rax
  8240d1:	add    $0x10,%rsi
  8240d5:	jmp    824076 <gpui_gpu::renderer::images::prepare+0x6f6>
  8240d7:	mov    -0x8(%r8),%r12d
  8240db:	shl    $0x4,%r12
  8240df:	test   %bl,%bl
  8240e1:	je     824138 <gpui_gpu::renderer::images::prepare+0x7b8>
  8240e3:	test   %r13,%r13
  8240e6:	je     823fbe <gpui_gpu::renderer::images::prepare+0x63e>
  8240ec:	nopl   0x0(%rax)
  8240f0:	cmp    $0x1000,%r13
  8240f7:	mov    $0x1000,%r15d
  8240fd:	cmovb  %r13,%r15
  824101:	mov    %r15d,%ebx
  824104:	shl    $0x4,%ebx
  824107:	mov    0xb8(%rsp),%rdi
  82410f:	mov    %r14,%rsi
  824112:	mov    %r12,%rdx
  824115:	mov    %rbp,%rcx
  824118:	mov    %rbx,%r8
  82411b:	call   *0x65bf6f(%rip)        # e80090 <_DYNAMIC+0x5d0>
  824121:	mov    %r15,%rax
  824124:	shl    $0x4,%rax
  824128:	add    %rax,%rbp
  82412b:	add    %rbx,%r12
  82412e:	sub    %r15,%r13
  824131:	jne    8240f0 <gpui_gpu::renderer::images::prepare+0x770>
  824133:	jmp    823fbe <gpui_gpu::renderer::images::prepare+0x63e>
  824138:	test   %r13,%r13
  82413b:	je     823fbe <gpui_gpu::renderer::images::prepare+0x63e>
  824141:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  824150:	cmp    $0x10000,%r13
  824157:	mov    $0x10000,%ebx
  82415c:	cmovb  %r13,%rbx
  824160:	mov    0xb8(%rsp),%rdi
  824168:	mov    %r14,%rsi
  82416b:	mov    %r12,%rdx
  82416e:	mov    %rbp,%rcx
  824171:	mov    %rbx,%r8
  824174:	call   *0x65bf16(%rip)        # e80090 <_DYNAMIC+0x5d0>
  82417a:	add    %rbx,%rbp
  82417d:	add    %rbx,%r12
  824180:	sub    %rbx,%r13
  824183:	jne    824150 <gpui_gpu::renderer::images::prepare+0x7d0>
  824185:	jmp    823fbe <gpui_gpu::renderer::images::prepare+0x63e>
  82418a:	lea    -0x74f535(%rip),%rdi        # d4c5c <anon.81378166eea1c96e15e7851dcdc35f4e.0.llvm.4385859340901971677>
  824191:	lea    0x60a610(%rip),%rdx        # e2e7a8 <anon.81378166eea1c96e15e7851dcdc35f4e.2.llvm.4385859340901971677+0x38>
  824198:	mov    $0x16,%esi
  82419d:	call   *0x65bebd(%rip)        # e80060 <_DYNAMIC+0x5a0>
  8241a3:	ud2
  8241a5:	mov    0x18(%rsp),%rax
  8241aa:	mov    %rax,0x70(%rsp)
  8241af:	mov    0x78(%rsp),%rax
  8241b4:	mov    %rax,0x80(%rsp)
  8241bc:	mov    0xa0(%rsp),%rax
  8241c4:	shl    $0x4,%rax
  8241c8:	mov    %rax,0x88(%rsp)
  8241d0:	mov    0x20(%r14),%rax
  8241d4:	mov    %rax,0x90(%rsp)
  8241dc:	mov    0x48(%rsp),%rax
  8241e1:	add    0x50(%rsp),%rax
  8241e6:	mov    %rax,0x98(%rsp)
  8241ee:	mov    0x90(%rsp),%rax
  8241f6:	mov    %rax,0x150(%rsp)
  8241fe:	mov    0x98(%rsp),%rax
  824206:	mov    %rax,0x158(%rsp)
  82420e:	mov    0x80(%rsp),%rax
  824216:	mov    %rax,0x140(%rsp)
  82421e:	mov    0x88(%rsp),%rax
  824226:	mov    %rax,0x148(%rsp)
  82422e:	movups 0x70(%rsp),%xmm0
  824233:	movaps %xmm0,0x130(%rsp)
  82423b:	movups 0x60(%rsp),%xmm0
  824240:	movaps %xmm0,0x120(%rsp)
  824248:	movups 0x50(%rsp),%xmm0
  82424d:	movaps %xmm0,0x110(%rsp)
  824255:	movups 0x20(%rsp),%xmm0
  82425a:	movups 0x30(%rsp),%xmm1
  82425f:	movups 0x40(%rsp),%xmm2
  824264:	movaps %xmm2,0x100(%rsp)
  82426c:	movaps %xmm1,0xf0(%rsp)
  824274:	movaps %xmm0,0xe0(%rsp)
  82427c:	call   823950 <alloc::boxed::box_new_uninit>
  824281:	mov    %rax,%rbx
  824284:	movaps 0x150(%rsp),%xmm0
  82428c:	movups %xmm0,0x70(%rax)
  824290:	movaps 0x140(%rsp),%xmm0
  824298:	movups %xmm0,0x60(%rax)
  82429c:	movaps 0x130(%rsp),%xmm0
  8242a4:	movups %xmm0,0x50(%rax)
  8242a8:	movaps 0x120(%rsp),%xmm0
  8242b0:	movups %xmm0,0x40(%rax)
  8242b4:	movdqa 0xe0(%rsp),%xmm0
  8242bd:	movaps 0xf0(%rsp),%xmm1
  8242c5:	movaps 0x100(%rsp),%xmm2
  8242cd:	movaps 0x110(%rsp),%xmm3
  8242d5:	movups %xmm3,0x30(%rax)
  8242d9:	movups %xmm2,0x20(%rax)
  8242dd:	movups %xmm1,0x10(%rax)
  8242e1:	movdqu %xmm0,(%rax)
  8242e5:	mov    0xc8(%rsp),%rdi
  8242ed:	call   823100 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>
  8242f2:	mov    0xd0(%rsp),%rax
  8242fa:	mov    %rbx,(%rax)
  8242fd:	mov    0xb0(%rsp),%r15
  824305:	mov    0x14(%rsp),%eax
  824309:	mov    %al,0x4(%r15)
  82430d:	jmp    823b9f <gpui_gpu::renderer::images::prepare+0x21f>
  824312:	movl   $0x6,(%r15)
  824319:	jmp    823ba6 <gpui_gpu::renderer::images::prepare+0x226>
  82431e:	mov    %rcx,%rbx
  824321:	call   *0x65bdc1(%rip)        # e800e8 <_DYNAMIC+0x628>
  824327:	mov    %rbx,%rcx
  82432a:	mov    %rax,(%rbx)
  82432d:	mov    %rdx,0x8(%rbx)
  824331:	movb   $0x1,0x10(%rbx)
  824335:	jmp    823c29 <gpui_gpu::renderer::images::prepare+0x2a9>
  82433a:	lea    0x38(%rsp),%rdi
  82433f:	mov    0x18(%rsp),%rsi
  824344:	lea    0x58(%rsp),%rdx
  824349:	xor    %ecx,%ecx
  82434b:	call   *0x65be0f(%rip)        # e80160 <_DYNAMIC+0x6a0>
  824351:	cmp    $0xffffffffffffffff,%rax
  824355:	jne    823cc2 <gpui_gpu::renderer::images::prepare+0x342>
  82435b:	jmp    823d5a <gpui_gpu::renderer::images::prepare+0x3da>
  824360:	mov    %rax,%rbx
  824363:	lea    0xe0(%rsp),%rdi
  82436b:	call   8234c0 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>
  824370:	mov    %rbx,%rdi
  824373:	call   e2c830 <_Unwind_Resume@plt>
  824378:	mov    %rax,%rbx
  82437b:	mov    0x100(%rsp),%rax
  824383:	mov    %rax,0x20(%r15)
  824387:	movups 0xe0(%rsp),%xmm0
  82438f:	movups 0xf0(%rsp),%xmm1
  824397:	movups %xmm1,0x10(%r15)
  82439c:	movups %xmm0,(%r15)
  8243a0:	lea    0x20(%rsp),%rdi
  8243a5:	call   8234c0 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>
  8243aa:	mov    %rbx,%rdi
  8243ad:	call   e2c830 <_Unwind_Resume@plt>
  8243b2:	mov    %r13,%r14
  8243b5:	mov    %rax,%rbx
  8243b8:	jmp    8243d4 <gpui_gpu::renderer::images::prepare+0xa54>
  8243ba:	mov    %rax,%rbx
  8243bd:	mov    %r13,%r14
  8243c0:	mov    0x8(%r13),%rax
  8243c4:	lock decq (%rax)
  8243c8:	jne    8243d4 <gpui_gpu::renderer::images::prepare+0xa54>
  8243ca:	lea    0x8(%r14),%rdi
  8243ce:	call   *0x65bbfc(%rip)        # e7ffd0 <_DYNAMIC+0x510>
  8243d4:	mov    0x100(%rsp),%rax
  8243dc:	mov    %rax,0x20(%r14)
  8243e0:	movups 0xe0(%rsp),%xmm0
  8243e8:	movups 0xf0(%rsp),%xmm1
  8243f0:	movups %xmm1,0x10(%r14)
  8243f5:	movups %xmm0,(%r14)
  8243f9:	mov    %rbx,%rdi
  8243fc:	call   e2c830 <_Unwind_Resume@plt>
  824401:	call   *0x65b909(%rip)        # e7fd10 <_DYNAMIC+0x250>
  824407:	jmp    82440d <gpui_gpu::renderer::images::prepare+0xa8d>
  824409:	jmp    82440d <gpui_gpu::renderer::images::prepare+0xa8d>
  82440b:	jmp    82440d <gpui_gpu::renderer::images::prepare+0xa8d>
  82440d:	mov    %rax,%rbx
  824410:	lea    0x20(%rsp),%rdi
  824415:	call   8234c0 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>
  82441a:	mov    %rbx,%rdi
  82441d:	call   e2c830 <_Unwind_Resume@plt>
{"address": 8505968, "code_bytes": 95, "mangled": "_RNvMNtNtCshVcpkSEwkOU_8gpui_gpu8renderer5ownedNtB4_8Renderer19set_grouped_records", "name": "<gpui_gpu[d0c1626f4f4ed1e6]::renderer::Renderer>::set_grouped_records", "normalized_name": "<gpui_gpu::renderer::Renderer>::set_grouped_records", "stack_bytes": 24}
{"address": 8506064, "code_bytes": 83, "mangled": "_RNvMs0_NtCshVcpkSEwkOU_8gpui_gpu8rendererNtB5_7Changes6upload", "name": "<gpui_gpu[d0c1626f4f4ed1e6]::renderer::Changes>::upload", "normalized_name": "<gpui_gpu::renderer::Changes>::upload", "stack_bytes": 8}
{"address": 8506160, "code_bytes": 76, "mangled": "_RNvMs1_NtCshVcpkSEwkOU_8gpui_gpu8rendererNtB5_6Buffer5write", "name": "<gpui_gpu[d0c1626f4f4ed1e6]::renderer::Buffer>::write", "normalized_name": "<gpui_gpu::renderer::Buffer>::write", "stack_bytes": 40}
{"address": 8506240, "code_bytes": 271, "mangled": "_RNvMs1_NtCshVcpkSEwkOU_8gpui_gpu8rendererNtB5_6Buffer7reserve", "name": "<gpui_gpu[d0c1626f4f4ed1e6]::renderer::Buffer>::reserve", "normalized_name": "<gpui_gpu::renderer::Buffer>::reserve", "stack_bytes": 104}
{"address": 8506512, "code_bytes": 706, "mangled": "_RNvMs2_NtCshVcpkSEwkOU_8gpui_gpu8rendererNtB5_5Atlas3new", "name": "<gpui_gpu[d0c1626f4f4ed1e6]::renderer::Atlas>::new", "normalized_name": "<gpui_gpu::renderer::Atlas>::new", "stack_bytes": 376}
{"address": 8507232, "code_bytes": 608, "mangled": "_RNvMs2_NtCshVcpkSEwkOU_8gpui_gpu8rendererNtB5_5Atlas6insert", "name": "<gpui_gpu[d0c1626f4f4ed1e6]::renderer::Atlas>::insert", "normalized_name": "<gpui_gpu::renderer::Atlas>::insert", "stack_bytes": 152}
{"address": 8507840, "code_bytes": 469, "mangled": "_RNvMs4_NtCshVcpkSEwkOU_8gpui_gpu8rendererNtB5_10GpuContext6submit", "name": "<gpui_gpu[d0c1626f4f4ed1e6]::renderer::GpuContext>::submit", "normalized_name": "<gpui_gpu::renderer::GpuContext>::submit", "stack_bytes": 1384}
{"address": 8508320, "code_bytes": 981, "mangled": "_RNvMs5_NtCshVcpkSEwkOU_8gpui_gpu8rendererNtB5_13RendererState10correction", "name": "<gpui_gpu[d0c1626f4f4ed1e6]::renderer::RendererState>::correction", "normalized_name": "<gpui_gpu::renderer::RendererState>::correction", "stack_bytes": 184}
{"address": 8509312, "code_bytes": 663, "mangled": "_RNvMs5_NtCshVcpkSEwkOU_8gpui_gpu8rendererNtB5_13RendererState13prepare_atlas", "name": "<gpui_gpu[d0c1626f4f4ed1e6]::renderer::RendererState>::prepare_atlas", "normalized_name": "<gpui_gpu::renderer::RendererState>::prepare_atlas", "stack_bytes": 600}
{"address": 8509984, "code_bytes": 1527, "mangled": "_RNvMs5_NtCshVcpkSEwkOU_8gpui_gpu8rendererNtB5_13RendererState3new", "name": "<gpui_gpu[d0c1626f4f4ed1e6]::renderer::RendererState>::new", "normalized_name": "<gpui_gpu::renderer::RendererState>::new", "stack_bytes": 952}
{"address": 8511520, "code_bytes": 9261, "mangled": "_RNvMs5_NtCshVcpkSEwkOU_8gpui_gpu8rendererNtB5_13RendererState6render", "name": "<gpui_gpu[d0c1626f4f4ed1e6]::renderer::RendererState>::render", "normalized_name": "<gpui_gpu::renderer::RendererState>::render", "stack_bytes": 1448}
{"address": 8520784, "code_bytes": 4415, "mangled": "_RNvMs5_NtCshVcpkSEwkOU_8gpui_gpu8rendererNtB5_13RendererState8bin_draw", "name": "<gpui_gpu[d0c1626f4f4ed1e6]::renderer::RendererState>::bin_draw", "normalized_name": "<gpui_gpu::renderer::RendererState>::bin_draw", "stack_bytes": 824}
{"address": 8525200, "code_bytes": 68, "mangled": "_RNvNtCshVcpkSEwkOU_8gpui_gpu8renderer13compact_group", "name": "gpui_gpu[d0c1626f4f4ed1e6]::renderer::compact_group", "normalized_name": "gpui_gpu::renderer::compact_group", "stack_bytes": 88}
{"address": 8525280, "code_bytes": 1600, "mangled": "_RNvNtCshVcpkSEwkOU_8gpui_gpu8renderer13validate_draw", "name": "gpui_gpu[d0c1626f4f4ed1e6]::renderer::validate_draw", "normalized_name": "gpui_gpu::renderer::validate_draw", "stack_bytes": 168}
{"address": 8528688, "code_bytes": 1602, "mangled": "_RINvMs6_NtCsgQfI1edjipl_9hashbrown3rawINtB6_8RawTableTNtNtCs11piCSwEYBC_11gpui_canvas4text8GlyphKeyNtNtCshVcpkSEwkOU_8gpui_gpu8renderer4TileEE14reserve_rehashNCINvNtB8_3map11make_hasherBQ_B1z_NtNtNtCs2AWtUsOyxgP_3std4hash6random11RandomStateE0EB1D_", "name": "<hashbrown[c42db024a0c43d25]::raw::RawTable<(gpui_canvas[be9825febc5538e]::text::GlyphKey, gpui_gpu[d0c1626f4f4ed1e6]::renderer::Tile)>>::reserve_rehash::<hashbrown[c42db024a0c43d25]::map::make_hasher<gpui_canvas[be9825febc5538e]::text::GlyphKey, gpui_gpu[d0c1626f4f4ed1e6]::renderer::Tile, std[1e3c4ec04c5261a9]::hash::random::RandomState>::{closure#0}>", "normalized_name": "<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>", "stack_bytes": 136}
{"address": 8530304, "code_bytes": 1437, "mangled": "_RINvMs6_NtCsgQfI1edjipl_9hashbrown3rawINtB6_8RawTableTNtNtCs11piCSwEYBC_11gpui_canvas5image8ImageKeyNtNtNtCshVcpkSEwkOU_8gpui_gpu8renderer6images5EntryEE14reserve_rehashNCINvNtB8_3map11make_hasherBQ_B1A_NtNtNtCs2AWtUsOyxgP_3std4hash6random11RandomStateE0EB1G_", "name": "<hashbrown[c42db024a0c43d25]::raw::RawTable<(gpui_canvas[be9825febc5538e]::image::ImageKey, gpui_gpu[d0c1626f4f4ed1e6]::renderer::images::Entry)>>::reserve_rehash::<hashbrown[c42db024a0c43d25]::map::make_hasher<gpui_canvas[be9825febc5538e]::image::ImageKey, gpui_gpu[d0c1626f4f4ed1e6]::renderer::images::Entry, std[1e3c4ec04c5261a9]::hash::random::RandomState>::{closure#0}>", "normalized_name": "<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>", "stack_bytes": 104}
{"address": 8532176, "code_bytes": 47, "mangled": "_RNvXsg_NtCsgQfI1edjipl_9hashbrown3rawINtB5_8RawTableTNtNtCs11piCSwEYBC_11gpui_canvas4text8GlyphKeyNtNtCshVcpkSEwkOU_8gpui_gpu8renderer4TileEENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropB1C_", "name": "<hashbrown[c42db024a0c43d25]::raw::RawTable<(gpui_canvas[be9825febc5538e]::text::GlyphKey, gpui_gpu[d0c1626f4f4ed1e6]::renderer::Tile)> as core[37f591cfbe66b0b1]::ops::drop::Drop>::drop", "normalized_name": "<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop", "stack_bytes": 0}
{"address": 8532224, "code_bytes": 105, "mangled": "_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionINtNtCscdodAO9FK5_5alloc5boxed3BoxNtNtNtCshVcpkSEwkOU_8gpui_gpu8renderer6images6ImagesEEEB1B_", "name": "core[37f591cfbe66b0b1]::ptr::drop_glue::<core[37f591cfbe66b0b1]::option::Option<alloc[24b8200b0946867]::boxed::Box<gpui_gpu[d0c1626f4f4ed1e6]::renderer::images::Images>>>", "normalized_name": "core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>", "stack_bytes": 8}
{"address": 8532880, "code_bytes": 103, "mangled": "_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCshVcpkSEwkOU_8gpui_gpu8renderer6BufferEBF_", "name": "core[37f591cfbe66b0b1]::ptr::drop_glue::<gpui_gpu[d0c1626f4f4ed1e6]::renderer::Buffer>", "normalized_name": "core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>", "stack_bytes": 24}
{"address": 8533184, "code_bytes": 81, "mangled": "_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCshVcpkSEwkOU_8gpui_gpu8renderer6images6ImagesEBH_", "name": "core[37f591cfbe66b0b1]::ptr::drop_glue::<gpui_gpu[d0c1626f4f4ed1e6]::renderer::images::Images>", "normalized_name": "core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>", "stack_bytes": 8}
{"address": 8533280, "code_bytes": 246, "mangled": "_RNvMNtNtCshVcpkSEwkOU_8gpui_gpu8renderer6imagesNtB2_6Images8metadata", "name": "<gpui_gpu[d0c1626f4f4ed1e6]::renderer::images::Images>::metadata", "normalized_name": "<gpui_gpu::renderer::images::Images>::metadata", "stack_bytes": 40}
{"address": 8534400, "code_bytes": 2722, "mangled": "_RNvNtNtCshVcpkSEwkOU_8gpui_gpu8renderer6images7prepare", "name": "gpui_gpu[d0c1626f4f4ed1e6]::renderer::images::prepare", "normalized_name": "gpui_gpu::renderer::images::prepare", "stack_bytes": 552}
{"address": 8538288, "code_bytes": 303, "mangled": "_RINvYINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters6copied6CopiedINtNtNtBc_5slice4iter4IterNtNtCs11piCSwEYBC_11gpui_canvas5image8ImageKeyEENtNtNtBa_6traits8iterator8Iterator5eq_byINtNtB8_3map3MapINtNtB8_7flatten7FlatMapINtNtBc_6option4IterINtNtCscdodAO9FK5_5alloc5boxed3BoxNtNtB1r_6canvas14ImageResourcesEEIB2O_IBY_NtB1p_5ImageENvMs2_B1p_B4Z_4viewENCNvMsa_B4l_NtB4l_13PreparedScene6images0ENCNvNtNtCshVcpkSEwkOU_8gpui_gpu8renderer6images7prepare0ENCINvYB3_B29_2eqB2N_E0EB6k_", "name": "<core[37f591cfbe66b0b1]::iter::adapters::copied::Copied<core[37f591cfbe66b0b1]::slice::iter::Iter<gpui_canvas[be9825febc5538e]::image::ImageKey>> as core[37f591cfbe66b0b1]::iter::traits::iterator::Iterator>::eq_by::<core[37f591cfbe66b0b1]::iter::adapters::map::Map<core[37f591cfbe66b0b1]::iter::adapters::flatten::FlatMap<core[37f591cfbe66b0b1]::option::Iter<alloc[24b8200b0946867]::boxed::Box<gpui_canvas[be9825febc5538e]::canvas::ImageResources>>, core[37f591cfbe66b0b1]::iter::adapters::map::Map<core[37f591cfbe66b0b1]::slice::iter::Iter<gpui_canvas[be9825febc5538e]::image::Image>, <gpui_canvas[be9825febc5538e]::image::Image>::view>, <gpui_canvas[be9825febc5538e]::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu[d0c1626f4f4ed1e6]::renderer::images::prepare::{closure#0}>, <core[37f591cfbe66b0b1]::iter::adapters::copied::Copied<core[37f591cfbe66b0b1]::slice::iter::Iter<gpui_canvas[be9825febc5538e]::image::ImageKey>> as core[37f591cfbe66b0b1]::iter::traits::iterator::Iterator>::eq<core[37f591cfbe66b0b1]::iter::adapters::map::Map<core[37f591cfbe66b0b1]::iter::adapters::flatten::FlatMap<core[37f591cfbe66b0b1]::option::Iter<alloc[24b8200b0946867]::boxed::Box<gpui_canvas[be9825febc5538e]::canvas::ImageResources>>, core[37f591cfbe66b0b1]::iter::adapters::map::Map<core[37f591cfbe66b0b1]::slice::iter::Iter<gpui_canvas[be9825febc5538e]::image::Image>, <gpui_canvas[be9825febc5538e]::image::Image>::view>, <gpui_canvas[be9825febc5538e]::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu[d0c1626f4f4ed1e6]::renderer::images::prepare::{closure#0}>>::{closure#0}>", "normalized_name": "<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>", "stack_bytes": 24}

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008248b0 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>>:
  8248b0:	push   %r15
  8248b2:	push   %r14
  8248b4:	push   %rbx
  8248b5:	mov    (%rdx),%r9
  8248b8:	mov    0x8(%rdx),%r11
  8248bc:	mov    0x10(%rdx),%rbx
  8248c0:	mov    0x18(%rdx),%r10
  8248c4:	mov    0x20(%rdx),%r8
  8248c8:	mov    0x28(%rdx),%rcx
  8248cc:	test   $0x1,%r9b
  8248d0:	jne    82496a <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xba>
  8248d6:	mov    %rbx,%rax
  8248d9:	jmp    8248fb <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x4b>
  8248db:	nopl   0x0(%rax,%rax,1)
  8248e0:	lea    0x8(%rax),%rbx
  8248e4:	mov    %rbx,%r14
  8248e7:	add    $0x8,%rdi
  8248eb:	mov    (%rax),%r15
  8248ee:	mov    %r14,%rax
  8248f1:	cmp    0x28(%r15),%rdx
  8248f5:	jne    8249bf <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  8248fb:	cmp    %rsi,%rdi
  8248fe:	je     824998 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xe8>
  824904:	mov    (%rdi),%rdx
  824907:	test   %rax,%rax
  82490a:	je     824913 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x63>
  82490c:	cmp    %r10,%rax
  82490f:	jne    8248e0 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x30>
  824911:	xor    %ebx,%ebx
  824913:	xor    %eax,%eax
  824915:	test   %r8,%r8
  824918:	je     8249c1 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  82491e:	cmp    %rcx,%r8
  824921:	je     8249c1 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  824927:	mov    %r8,%rax
  82492a:	add    $0x8,%r8
  82492e:	xor    %r14d,%r14d
  824931:	jmp    8248e7 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x37>
  824933:	mov    (%r11),%rax
  824936:	mov    0x8(%rax),%rbx
  82493a:	mov    0x10(%rax),%rax
  82493e:	lea    (%rbx,%rax,8),%r10
  824942:	test   %rax,%rax
  824945:	je     824981 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xd1>
  824947:	xor    %r11d,%r11d
  82494a:	nopw   0x0(%rax,%rax,1)
  824950:	mov    %r8,%rax
  824953:	mov    %rbx,%r8
  824956:	add    $0x8,%rbx
  82495a:	add    $0x8,%rdi
  82495e:	mov    (%r8),%r14
  824961:	mov    %rax,%r8
  824964:	cmp    0x28(%r14),%rdx
  824968:	jne    8249bf <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  82496a:	cmp    %rsi,%rdi
  82496d:	je     824998 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xe8>
  82496f:	mov    (%rdi),%rdx
  824972:	test   %rbx,%rbx
  824975:	je     82497c <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xcc>
  824977:	cmp    %r10,%rbx
  82497a:	jne    824950 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xa0>
  82497c:	test   %r11,%r11
  82497f:	jne    824933 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x83>
  824981:	xor    %eax,%eax
  824983:	test   %r8,%r8
  824986:	je     8249c1 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  824988:	cmp    %rcx,%r8
  82498b:	je     8249c1 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  82498d:	lea    0x8(%r8),%rax
  824991:	xor    %ebx,%ebx
  824993:	xor    %r11d,%r11d
  824996:	jmp    82495a <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xaa>
  824998:	test   %rbx,%rbx
  82499b:	sete   %dl
  82499e:	cmp    %r10,%rbx
  8249a1:	sete   %al
  8249a4:	or     %dl,%al
  8249a6:	test   $0x1,%r9b
  8249aa:	je     8249c7 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x117>
  8249ac:	test   %al,%al
  8249ae:	je     8249bf <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  8249b0:	test   %r11,%r11
  8249b3:	je     8249cb <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x11b>
  8249b5:	mov    (%r11),%rax
  8249b8:	cmpq   $0x0,0x10(%rax)
  8249bd:	je     8249cb <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x11b>
  8249bf:	xor    %eax,%eax
  8249c1:	pop    %rbx
  8249c2:	pop    %r14
  8249c4:	pop    %r15
  8249c6:	ret
  8249c7:	test   %al,%al
  8249c9:	je     8249bf <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  8249cb:	test   %r8,%r8
  8249ce:	sete   %dl
  8249d1:	cmp    %rcx,%r8
  8249d4:	sete   %al
  8249d7:	or     %dl,%al
  8249d9:	pop    %rbx
  8249da:	pop    %r14
  8249dc:	pop    %r15
  8249de:	ret

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000825490 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert>:
  825490:	push   %rbp
  825491:	push   %r15
  825493:	push   %r14
  825495:	push   %r13
  825497:	push   %r12
  825499:	push   %rbx
  82549a:	sub    $0x38,%rsp
  82549e:	mov    %rcx,%r15
  8254a1:	mov    %rdx,%r12
  8254a4:	mov    %rsi,%r14
  8254a7:	mov    %rdi,%rbx
  8254aa:	lea    0x20(%rsi),%r13
  8254ae:	mov    %r13,%rdi
  8254b1:	mov    %rdx,%rsi
  8254b4:	call   824b60 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  8254b9:	cmpq   $0x0,0x10(%r14)
  8254be:	je     825641 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x1b1>
  8254c4:	mov    (%r14),%r11
  8254c7:	mov    0x8(%r14),%rsi
  8254cb:	mov    %rax,%rdx
  8254ce:	shr    $0x39,%rdx
  8254d2:	movd   %edx,%xmm0
  8254d6:	punpcklbw %xmm0,%xmm0
  8254da:	pshuflw $0x0,%xmm0,%xmm0
  8254df:	pshufd $0x44,%xmm0,%xmm0
  8254e4:	mov    (%r12),%rcx
  8254e8:	mov    %rcx,0x8(%rsp)
  8254ed:	movzwl 0xc(%r12),%r9d
  8254f3:	mov    0x8(%r12),%r10d
  8254f8:	xor    %r13d,%r13d
  8254fb:	pcmpeqd %xmm1,%xmm1
  8254ff:	xor    %r8d,%r8d
  825502:	and    %rsi,%rax
  825505:	movdqu (%r11,%rax,1),%xmm2
  82550b:	movdqa %xmm2,%xmm3
  82550f:	pcmpeqb %xmm0,%xmm3
  825513:	pmovmskb %xmm3,%ebp
  825517:	test   %ebp,%ebp
  825519:	je     825560 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xd0>
  82551b:	mov    %r8,(%rsp)
  82551f:	mov    %r15,%r8
  825522:	tzcnt  %ebp,%r15d
  825527:	add    %rax,%r15
  82552a:	and    %rsi,%r15
  82552d:	shl    $0x5,%r15
  825531:	mov    %r11,%rcx
  825534:	sub    %r15,%rcx
  825537:	mov    0x8(%rsp),%r15
  82553c:	cmp    -0x20(%rcx),%r15
  825540:	jne    82554f <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xbf>
  825542:	cmp    -0x14(%rcx),%r9w
  825547:	jne    82554f <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xbf>
  825549:	cmp    -0x18(%rcx),%r10d
  82554d:	je     82559f <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x10f>
  82554f:	lea    -0x1(%rbp),%ecx
  825552:	and    %bp,%cx
  825555:	mov    %ecx,%ebp
  825557:	mov    %r8,%r15
  82555a:	mov    (%rsp),%r8
  82555e:	jne    82551f <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x8f>
  825560:	cmp    $0x1,%r13
  825564:	je     825578 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xe8>
  825566:	pmovmskb %xmm2,%ecx
  82556a:	test   %ecx,%ecx
  82556c:	je     82558c <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xfc>
  82556e:	tzcnt  %ecx,%edi
  825572:	add    %rax,%rdi
  825575:	and    %rsi,%rdi
  825578:	pcmpeqb %xmm1,%xmm2
  82557c:	pmovmskb %xmm2,%ecx
  825580:	test   %ecx,%ecx
  825582:	jne    8255b6 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x126>
  825584:	mov    $0x1,%r13d
  82558a:	jmp    82558f <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xff>
  82558c:	xor    %r13d,%r13d
  82558f:	add    %r8,%rax
  825592:	add    $0x10,%rax
  825596:	add    $0x10,%r8
  82559a:	jmp    825502 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x72>
  82559f:	movups -0x10(%rcx),%xmm0
  8255a3:	movups %xmm0,0x4(%rbx)
  8255a7:	movups (%r8),%xmm0
  8255ab:	movups %xmm0,-0x10(%rcx)
  8255af:	mov    $0x1,%eax
  8255b4:	jmp    82562d <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x19d>
  8255b6:	movzbl (%r11,%rdi,1),%eax
  8255bb:	test   %al,%al
  8255bd:	jns    825662 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x1d2>
  8255c3:	movups (%r12),%xmm0
  8255c8:	movaps %xmm0,0x10(%rsp)
  8255cd:	movups (%r15),%xmm0
  8255d1:	movaps %xmm0,0x20(%rsp)
  8255d6:	and    $0x1,%al
  8255d8:	lea    -0x10(%rdi),%rcx
  8255dc:	and    %rsi,%rcx
  8255df:	mov    %dl,(%r11,%rdi,1)
  8255e3:	mov    %dl,0x10(%r11,%rcx,1)
  8255e8:	movzbl %al,%eax
  8255eb:	movd   %eax,%xmm0
  8255ef:	shufpd $0x2,-0x77a398(%rip),%xmm0        # ab260 <anon.a16d5d421a76dfd8c37a17b53540311d.51.llvm.14190004212411149437+0xe0>
  8255f8:	movdqu 0x10(%r14),%xmm1
  8255fe:	psubq  %xmm0,%xmm1
  825602:	movdqu %xmm1,0x10(%r14)
  825608:	shl    $0x5,%rdi
  82560c:	mov    %r11,%rax
  82560f:	sub    %rdi,%rax
  825612:	neg    %rdi
  825615:	movaps 0x10(%rsp),%xmm0
  82561a:	movdqa 0x20(%rsp),%xmm1
  825620:	movups %xmm0,-0x20(%r11,%rdi,1)
  825626:	movdqu %xmm1,-0x10(%rax)
  82562b:	xor    %eax,%eax
  82562d:	mov    %eax,(%rbx)
  82562f:	mov    %rbx,%rax
  825632:	add    $0x38,%rsp
  825636:	pop    %rbx
  825637:	pop    %r12
  825639:	pop    %r13
  82563b:	pop    %r14
  82563d:	pop    %r15
  82563f:	pop    %rbp
  825640:	ret
  825641:	mov    $0x1,%esi
  825646:	mov    %r14,%rdi
  825649:	mov    %r13,%rdx
  82564c:	mov    $0x1,%ecx
  825651:	mov    %rax,%r13
  825654:	call   *0x65aafe(%rip)        # e80158 <_DYNAMIC+0x698>
  82565a:	mov    %r13,%rax
  82565d:	jmp    8254c4 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x34>
  825662:	movdqa (%r11),%xmm0
  825667:	pmovmskb %xmm0,%eax
  82566b:	tzcnt  %eax,%edi
  82566f:	movzbl (%r11,%rdi,1),%eax
  825674:	jmp    8255c3 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x133>

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000825680 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert>:
  825680:	push   %rbp
  825681:	push   %r15
  825683:	push   %r14
  825685:	push   %r13
  825687:	push   %r12
  825689:	push   %rbx
  82568a:	push   %rax
  82568b:	mov    %r8d,%ebp
  82568e:	mov    %ecx,%r14d
  825691:	mov    %rdx,%r15
  825694:	mov    %rsi,%r12
  825697:	mov    %rdi,%rbx
  82569a:	mov    %rdx,(%rsp)
  82569e:	lea    0x20(%rsi),%r13
  8256a2:	mov    %rsp,%rsi
  8256a5:	mov    %r13,%rdi
  8256a8:	call   824d00 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  8256ad:	cmpq   $0x0,0x10(%r12)
  8256b3:	je     8257f6 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x176>
  8256b9:	mov    (%r12),%rcx
  8256bd:	mov    0x8(%r12),%rsi
  8256c2:	mov    %rax,%rdx
  8256c5:	shr    $0x39,%rdx
  8256c9:	movd   %edx,%xmm0
  8256cd:	punpcklbw %xmm0,%xmm0
  8256d1:	pshuflw $0x0,%xmm0,%xmm0
  8256d6:	pshufd $0x44,%xmm0,%xmm0
  8256db:	xor    %r9d,%r9d
  8256de:	pcmpeqd %xmm1,%xmm1
  8256e2:	xor    %r8d,%r8d
  8256e5:	and    %rsi,%rax
  8256e8:	movdqu (%rcx,%rax,1),%xmm2
  8256ed:	movdqa %xmm2,%xmm3
  8256f1:	pcmpeqb %xmm0,%xmm3
  8256f5:	pmovmskb %xmm3,%r10d
  8256fa:	test   %r10d,%r10d
  8256fd:	je     825730 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xb0>
  8256ff:	tzcnt  %r10d,%r13d
  825704:	add    %rax,%r13
  825707:	and    %rsi,%r13
  82570a:	shl    $0x4,%r13
  82570e:	mov    %rcx,%r11
  825711:	sub    %r13,%r11
  825714:	cmp    -0x10(%r11),%r15
  825718:	je     825771 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xf1>
  82571a:	lea    -0x1(%r10),%r11d
  82571e:	and    %r10w,%r11w
  825722:	mov    %r11d,%r10d
  825725:	jne    8256ff <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x7f>
  825727:	nopw   0x0(%rax,%rax,1)
  825730:	cmp    $0x1,%r9
  825734:	je     825748 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xc8>
  825736:	pmovmskb %xmm2,%edi
  82573a:	test   %edi,%edi
  82573c:	je     82575e <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xde>
  82573e:	tzcnt  %edi,%edi
  825742:	add    %rax,%rdi
  825745:	and    %rsi,%rdi
  825748:	pcmpeqb %xmm1,%xmm2
  82574c:	pmovmskb %xmm2,%r9d
  825751:	test   %r9d,%r9d
  825754:	jne    825788 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x108>
  825756:	mov    $0x1,%r9d
  82575c:	jmp    825761 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xe1>
  82575e:	xor    %r9d,%r9d
  825761:	add    %r8,%rax
  825764:	add    $0x10,%rax
  825768:	add    $0x10,%r8
  82576c:	jmp    8256e5 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x65>
  825771:	mov    -0x8(%r11),%rax
  825775:	mov    %r14d,-0x8(%r11)
  825779:	mov    %ebp,-0x4(%r11)
  82577d:	mov    %rax,0x4(%rbx)
  825781:	mov    $0x1,%eax
  825786:	jmp    8257e2 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x162>
  825788:	movzbl (%rcx,%rdi,1),%eax
  82578c:	test   %al,%al
  82578e:	jns    825817 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x197>
  825794:	and    $0x1,%al
  825796:	lea    -0x10(%rdi),%r8
  82579a:	and    %rsi,%r8
  82579d:	mov    %dl,(%rcx,%rdi,1)
  8257a0:	mov    %dl,0x10(%rcx,%r8,1)
  8257a5:	movdqu 0x10(%r12),%xmm0
  8257ac:	movzbl %al,%eax
  8257af:	movd   %eax,%xmm1
  8257b3:	shufpd $0x2,-0x77a55c(%rip),%xmm1        # ab260 <anon.a16d5d421a76dfd8c37a17b53540311d.51.llvm.14190004212411149437+0xe0>
  8257bc:	psubq  %xmm1,%xmm0
  8257c0:	movdqu %xmm0,0x10(%r12)
  8257c7:	shl    $0x4,%rdi
  8257cb:	mov    %rcx,%rax
  8257ce:	sub    %rdi,%rax
  8257d1:	neg    %rdi
  8257d4:	mov    %r15,-0x10(%rcx,%rdi,1)
  8257d9:	mov    %r14d,-0x8(%rax)
  8257dd:	mov    %ebp,-0x4(%rax)
  8257e0:	xor    %eax,%eax
  8257e2:	mov    %eax,(%rbx)
  8257e4:	mov    %rbx,%rax
  8257e7:	add    $0x8,%rsp
  8257eb:	pop    %rbx
  8257ec:	pop    %r12
  8257ee:	pop    %r13
  8257f0:	pop    %r14
  8257f2:	pop    %r15
  8257f4:	pop    %rbp
  8257f5:	ret
  8257f6:	mov    $0x1,%esi
  8257fb:	mov    %r12,%rdi
  8257fe:	mov    %r13,%rdx
  825801:	mov    $0x1,%ecx
  825806:	mov    %rax,%r13
  825809:	call   *0x65a951(%rip)        # e80160 <_DYNAMIC+0x6a0>
  82580f:	mov    %r13,%rax
  825812:	jmp    8256b9 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x39>
  825817:	movdqa (%rcx),%xmm0
  82581b:	pmovmskb %xmm0,%eax
  82581f:	tzcnt  %eax,%edi
  825823:	movzbl (%rcx,%rdi,1),%eax
  825827:	jmp    825794 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x114>

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000825830 <gpui_gpu::renderer::slots::color_word>:
  825830:	lea    -0x3(%rsi),%eax
  825833:	cmp    %rax,%rdi
  825836:	jbe    82584f <gpui_gpu::renderer::slots::color_word+0x1f>
  825838:	mov    %rdi,%rax
  82583b:	shr    $0x6,%rax
  82583f:	and    $0x3f,%edi
  825842:	cmp    $0x1,%rdi
  825846:	sbb    $0xffffffff,%eax
  825849:	add    %esi,%eax
  82584b:	add    $0xfffffffe,%eax
  82584e:	ret
  82584f:	push   %rax
  825850:	lea    -0x750bbe(%rip),%rdi        # d4c99 <anon.37a6bc0c9ddf42ae57934ce69d5ecb61.7.llvm.1051716552078069610>
  825857:	lea    0x608f9a(%rip),%rdx        # e2e7f8 <anon.37a6bc0c9ddf42ae57934ce69d5ecb61.8.llvm.1051716552078069610>
  82585e:	mov    $0x1e,%esi
  825863:	call   *0x65a7bf(%rip)        # e80028 <_DYNAMIC+0x568>

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000825870 <gpui_gpu::renderer::slots::write_prefix>:
  825870:	push   %rbp
  825871:	push   %r15
  825873:	push   %r14
  825875:	push   %r13
  825877:	push   %r12
  825879:	push   %rbx
  82587a:	sub    $0x48,%rsp
  82587e:	mov    %rsi,0x8(%rsp)
  825883:	test   %rcx,%rcx
  825886:	je     825aca <gpui_gpu::renderer::slots::write_prefix+0x25a>
  82588c:	mov    %rdi,0x18(%rsp)
  825891:	xor    %r12d,%r12d
  825894:	test   $0x3f,%cl
  825897:	setne  %al
  82589a:	cmpq   $0x0,0x8(%rsp)
  8258a0:	je     825b10 <gpui_gpu::renderer::slots::write_prefix+0x2a0>
  8258a6:	mov    %r8,%r14
  8258a9:	mov    %rcx,%r10
  8258ac:	shr    $0x6,%r10
  8258b0:	mov    %al,%r12b
  8258b3:	lea    (%r10,%r12,1),%r9
  8258b7:	lea    (%r10,%r12,1),%rax
  8258bb:	inc    %rax
  8258be:	mov    %eax,%esi
  8258c0:	mov    %r9,%rdi
  8258c3:	shl    $0x20,%rdi
  8258c7:	mov    %ecx,%r8d
  8258ca:	mov    0x18(%rsp),%rbx
  8258cf:	xor    0x8(%rbx),%rsi
  8258d3:	or     %rdi,%r8
  8258d6:	xor    (%rbx),%r8
  8258d9:	or     %rsi,%r8
  8258dc:	mov    %r10,0x10(%rsp)
  8258e1:	jne    8258ec <gpui_gpu::renderer::slots::write_prefix+0x7c>
  8258e3:	mov    (%r14),%rbp
  8258e6:	mov    0x8(%r14),%r13
  8258ea:	jmp    825915 <gpui_gpu::renderer::slots::write_prefix+0xa5>
  8258ec:	mov    0x8(%r14),%r13
  8258f0:	movq   $0x0,(%r14)
  8258f7:	cmp    $0x1,%r13
  8258fb:	adc    $0x0,%r13
  8258ff:	mov    %r13,0x8(%r14)
  825903:	mov    %ecx,(%rbx)
  825905:	mov    %r9d,0x4(%rbx)
  825909:	mov    %eax,0x8(%rbx)
  82590c:	movl   $0x0,0xc(%rbx)
  825913:	xor    %ebp,%ebp
  825915:	mov    %r9,%r15
  825918:	mov    %rdx,%rdi
  82591b:	call   *0x65a747(%rip)        # e80068 <_DYNAMIC+0x5a8>
  825921:	mov    0x8(%rsp),%rcx
  825926:	dec    %rcx
  825929:	mov    %rcx,0x40(%rsp)
  82592e:	mov    0x10(%rsp),%rcx
  825933:	shl    $0x4,%rcx
  825937:	shl    $0x4,%r12d
  82593b:	add    %rcx,%r12
  82593e:	lea    (%rbx,%r12,1),%r9
  825942:	add    $0x10,%r9
  825946:	xor    %r12d,%r12d
  825949:	xorps  %xmm0,%xmm0
  82594c:	mov    %r15,0x38(%rsp)
  825951:	mov    %r15,%r10
  825954:	jmp    825976 <gpui_gpu::renderer::slots::write_prefix+0x106>
  825956:	cs nopw 0x0(%rax,%rax,1)
  825960:	add    $0x40,%r10
  825964:	add    $0x400,%r9
  82596b:	cmp    0x38(%rsp),%r12
  825970:	je     825aca <gpui_gpu::renderer::slots::write_prefix+0x25a>
  825976:	mov    %r12,0x10(%rsp)
  82597b:	lea    0x1(%r12),%rcx
  825980:	mov    %rcx,0x30(%rsp)
  825985:	movaps %xmm0,0x20(%rsp)
  82598a:	mov    $0xffffffffffffffc0,%rsi
  825991:	xor    %r12d,%r12d
  825994:	jmp    8259b1 <gpui_gpu::renderer::slots::write_prefix+0x141>
  825996:	cs nopw 0x0(%rax,%rax,1)
  8259a0:	add    $0x18,%rax
  8259a4:	add    $0x2,%r12
  8259a8:	inc    %rsi
  8259ab:	je     825a60 <gpui_gpu::renderer::slots::write_prefix+0x1f0>
  8259b1:	cmp    %rdx,%rax
  8259b4:	je     825a60 <gpui_gpu::renderer::slots::write_prefix+0x1f0>
  8259ba:	lea    0x40(%rsi),%r8
  8259be:	movzwl 0x10(%rax),%ebx
  8259c2:	movzwl 0x12(%rax),%ecx
  8259c6:	mov    (%rax),%r11d
  8259c9:	mov    0x4(%rax),%edi
  8259cc:	mov    0x8(%rax),%r15
  8259d0:	shr    $0xe,%ecx
  8259d3:	and    $0x2,%ecx
  8259d6:	shr    $0xf,%ebx
  8259d9:	or     %ecx,%ebx
  8259db:	mov    %r12d,%ecx
  8259de:	and    $0x1e,%cl
  8259e1:	shl    %cl,%ebx
  8259e3:	shr    $0x4,%r8
  8259e7:	or     %ebx,0x20(%rsp,%r8,4)
  8259ec:	lea    (%r10,%rsi,1),%r8
  8259f0:	add    $0x41,%r8
  8259f4:	cmp    0x8(%rsp),%r8
  8259f9:	jae    825ad9 <gpui_gpu::renderer::slots::write_prefix+0x269>
  8259ff:	mov    %rdi,%rcx
  825a02:	shl    $0x20,%rcx
  825a06:	mov    %r11d,%ebx
  825a09:	or     %rcx,%rbx
  825a0c:	mov    0x8(%r9,%r12,8),%rcx
  825a11:	xor    %r15,%rcx
  825a14:	xor    (%r9,%r12,8),%rbx
  825a18:	or     %rcx,%rbx
  825a1b:	je     8259a0 <gpui_gpu::renderer::slots::write_prefix+0x130>
  825a1d:	mov    %r15d,%ecx
  825a20:	shr    $0x20,%r15
  825a24:	cmp    %rbp,%r8
  825a27:	cmovb  %r8,%rbp
  825a2b:	mov    %rbp,(%r14)
  825a2e:	lea    (%r10,%rsi,1),%r8
  825a32:	add    $0x42,%r8
  825a36:	cmp    %r13,%r8
  825a39:	cmova  %r8,%r13
  825a3d:	mov    %r13,0x8(%r14)
  825a41:	mov    %r11d,(%r9,%r12,8)
  825a45:	mov    %edi,0x4(%r9,%r12,8)
  825a4a:	mov    %ecx,0x8(%r9,%r12,8)
  825a4f:	mov    %r15d,0xc(%r9,%r12,8)
  825a54:	jmp    8259a0 <gpui_gpu::renderer::slots::write_prefix+0x130>
  825a59:	nopl   0x0(%rax)
  825a60:	mov    0x10(%rsp),%r15
  825a65:	cmp    0x40(%rsp),%r15
  825a6a:	je     825af5 <gpui_gpu::renderer::slots::write_prefix+0x285>
  825a70:	mov    0x20(%rsp),%rcx
  825a75:	mov    0x28(%rsp),%rsi
  825a7a:	lea    0x1(%r15),%r12
  825a7e:	mov    %r12,%rdi
  825a81:	shl    $0x4,%rdi
  825a85:	mov    0x18(%rsp),%rbx
  825a8a:	mov    0x8(%rbx,%rdi,1),%r8
  825a8f:	xor    %rsi,%r8
  825a92:	mov    (%rbx,%rdi,1),%r11
  825a96:	xor    %rcx,%r11
  825a99:	or     %r8,%r11
  825a9c:	je     825960 <gpui_gpu::renderer::slots::write_prefix+0xf0>
  825aa2:	add    %rbx,%rdi
  825aa5:	cmp    %rbp,%r12
  825aa8:	cmovb  %r12,%rbp
  825aac:	add    $0x2,%r15
  825ab0:	cmp    %r13,%r15
  825ab3:	cmova  %r15,%r13
  825ab7:	mov    %rbp,(%r14)
  825aba:	mov    %r13,0x8(%r14)
  825abe:	mov    %rsi,0x8(%rdi)
  825ac2:	mov    %rcx,(%rdi)
  825ac5:	jmp    825960 <gpui_gpu::renderer::slots::write_prefix+0xf0>
  825aca:	add    $0x48,%rsp
  825ace:	pop    %rbx
  825acf:	pop    %r12
  825ad1:	pop    %r13
  825ad3:	pop    %r14
  825ad5:	pop    %r15
  825ad7:	pop    %rbp
  825ad8:	ret
  825ad9:	add    %r10,%rsi
  825adc:	add    $0x42,%rsi
  825ae0:	lea    0x608a61(%rip),%rcx        # e2e548 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.13987519659127932268>
  825ae7:	mov    %r8,%rdi
  825aea:	mov    0x8(%rsp),%rdx
  825aef:	call   *0x65a513(%rip)        # e80008 <_DYNAMIC+0x548>
  825af5:	mov    0x8(%rsp),%rdx
  825afa:	lea    0x1(%rdx),%rsi
  825afe:	lea    0x608a43(%rip),%rcx        # e2e548 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.13987519659127932268>
  825b05:	mov    0x30(%rsp),%rdi
  825b0a:	call   *0x65a4f8(%rip)        # e80008 <_DYNAMIC+0x548>
  825b10:	lea    0x608a31(%rip),%rcx        # e2e548 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.13987519659127932268>
  825b17:	mov    $0x1,%esi
  825b1c:	xor    %edi,%edi
  825b1e:	xor    %edx,%edx
  825b20:	call   *0x65a4e2(%rip)        # e80008 <_DYNAMIC+0x548>

/tmp/gpui-opaque-prefix-codegen/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000825ee0 <<alloc::raw_vec::RawVec<gpui_gpu::renderer::Correction>>::grow_one>:
  825ee0:	push   %r14
  825ee2:	push   %rbx
  825ee3:	sub    $0x18,%rsp
  825ee7:	mov    %rdi,%rbx
  825eea:	mov    (%rdi),%rsi
  825eed:	lea    (%rsi,%rsi,1),%rax
  825ef1:	cmp    $0x5,%rax
  825ef5:	mov    $0x4,%r14d
  825efb:	cmovae %rax,%r14
  825eff:	mov    0x8(%rdi),%rdx
  825f03:	mov    %rsp,%rdi
  825f06:	mov    $0x4,%r8d
  825f0c:	mov    $0x20,%r9d
  825f12:	mov    %r14,%rcx
  825f15:	call   825f50 <<alloc::raw_vec::RawVecInner>::finish_grow>
  825f1a:	cmpl   $0x1,(%rsp)
  825f1e:	je     825f34 <<alloc::raw_vec::RawVec<gpui_gpu::renderer::Correction>>::grow_one+0x54>
  825f20:	mov    0x8(%rsp),%rax
  825f25:	mov    %rax,0x8(%rbx)
  825f29:	mov    %r14,(%rbx)
  825f2c:	add    $0x18,%rsp
  825f30:	pop    %rbx
  825f31:	pop    %r14
  825f33:	ret
  825f34:	mov    0x8(%rsp),%rdi
  825f39:	mov    0x10(%rsp),%rsi
  825f3e:	call   *0x659e04(%rip)        # e7fd48 <_DYNAMIC+0x288>
{"address": 8541328, "code_bytes": 489, "mangled": "_RNvMs1_NtCsgQfI1edjipl_9hashbrown3mapINtB5_7HashMapNtNtCs11piCSwEYBC_11gpui_canvas4text8GlyphKeyNtNtCshVcpkSEwkOU_8gpui_gpu8renderer4TileNtNtNtCs2AWtUsOyxgP_3std4hash6random11RandomStateE6insertB1A_", "name": "<hashbrown[c42db024a0c43d25]::map::HashMap<gpui_canvas[be9825febc5538e]::text::GlyphKey, gpui_gpu[d0c1626f4f4ed1e6]::renderer::Tile, std[1e3c4ec04c5261a9]::hash::random::RandomState>>::insert", "normalized_name": "<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert", "stack_bytes": 104}
{"address": 8541824, "code_bytes": 428, "mangled": "_RNvMs1_NtCsgQfI1edjipl_9hashbrown3mapINtB5_7HashMapNtNtCs11piCSwEYBC_11gpui_canvas5image8ImageKeyNtNtNtCshVcpkSEwkOU_8gpui_gpu8renderer6images5EntryNtNtNtCs2AWtUsOyxgP_3std4hash6random11RandomStateE6insertB1D_", "name": "<hashbrown[c42db024a0c43d25]::map::HashMap<gpui_canvas[be9825febc5538e]::image::ImageKey, gpui_gpu[d0c1626f4f4ed1e6]::renderer::images::Entry, std[1e3c4ec04c5261a9]::hash::random::RandomState>>::insert", "normalized_name": "<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert", "stack_bytes": 56}
{"address": 8542256, "code_bytes": 57, "mangled": "_RNvNtNtCshVcpkSEwkOU_8gpui_gpu8renderer5slots10color_word", "name": "gpui_gpu[d0c1626f4f4ed1e6]::renderer::slots::color_word", "normalized_name": "gpui_gpu::renderer::slots::color_word", "stack_bytes": 8}
{"address": 8542320, "code_bytes": 694, "mangled": "_RNvNtNtCshVcpkSEwkOU_8gpui_gpu8renderer5slots12write_prefix", "name": "gpui_gpu[d0c1626f4f4ed1e6]::renderer::slots::write_prefix", "normalized_name": "gpui_gpu::renderer::slots::write_prefix", "stack_bytes": 120}
{"address": 8543968, "code_bytes": 100, "mangled": "_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtCshVcpkSEwkOU_8gpui_gpu8renderer10CorrectionE8grow_oneBP_", "name": "<alloc[24b8200b0946867]::raw_vec::RawVec<gpui_gpu[d0c1626f4f4ed1e6]::renderer::Correction>>::grow_one", "normalized_name": "<alloc::raw_vec::RawVec<gpui_gpu::renderer::Correction>>::grow_one", "stack_bytes": 40}
