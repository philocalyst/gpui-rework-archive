from pathlib import Path
import hashlib,json,os,shutil,subprocess
ROOT=Path('/tmp/gpui-legacy-coverage-sol');OUT=Path('/tmp/gpui-legacy-coverage-evidence/supplemental');OUT.mkdir()
env=dict(os.environ);env.pop('RUSTFLAGS',None);env.pop('CARGO_ENCODED_RUSTFLAGS',None)
env.update(CARGO_BUILD_JOBS='1',CARGO_TARGET_DIR='/tmp/gpui-legacy-coverage-target')
shader=ROOT/'reactivity/crates/gpu/src/shader.rs';tests=ROOT/'reactivity/crates/gpu/tests/render.rs'
original_shader=shader.read_bytes();original_tests=tests.read_bytes()
result={'source':'299c6aca30c1245c15c2da6a5ccabb41dd435d17','shader_sha256':hashlib.sha256(original_shader).hexdigest(),'test_sha256':hashlib.sha256(original_tests).hexdigest()}
def run(label,name):
    dest=OUT/label;dest.mkdir()
    args=['cargo','test','--release','--offline','--locked','-p','gpui_gpu','--features','vulkan-tests','--test','render','--no-run','--message-format=json']
    with (dest/'cargo.jsonl').open('w') as stdout,(dest/'cargo.log').open('w') as stderr:
        subprocess.run(args,cwd=ROOT/'reactivity',env=env,stdout=stdout,stderr=stderr,check=True)
    artifacts=[json.loads(x) for x in (dest/'cargo.jsonl').read_text().splitlines() if x.startswith('{')]
    artifact=next(x for x in artifacts if x.get('reason')=='compiler-artifact' and x.get('target',{}).get('name')=='render')
    assert not artifact['fresh']
    exe=dest/'render-tests';shutil.copy2(artifact['executable'],exe);exe.chmod(0o555)
    args=[str(exe),name,'--exact','--nocapture']
    with (dest/'stdout.log').open('w') as stdout,(dest/'stderr.log').open('w') as stderr:
        p=subprocess.run(args,cwd=ROOT/'reactivity',env=env,stdout=stdout,stderr=stderr,timeout=180)
    return {'test':name,'returncode':p.returncode,'artifact':artifact,'binary_sha256':hashlib.sha256(exe.read_bytes()).hexdigest()}
try:
    ref=Path('/tmp/gpui-coverage-setup-sol/reactivity/crates/gpu/tests/render.rs').read_bytes()
    start=ref.index(b'#[test]\nfn highest_correction_handle_reaches_real_shader_clip_admission()')
    extra=ref[start:];assert extra.count(b'#[test]')==1
    (OUT/'borrowed-highest-correction-test.rs').write_bytes(extra)
    tests.write_bytes(original_tests+b'\n'+extra)
    result['highest_correction']=run('highest-correction','highest_correction_handle_reaches_real_shader_clip_admission')
    assert result['highest_correction']['returncode']==0
finally:
    tests.write_bytes(original_tests)
try:
    needle=b'load_color(get!(WORDS)[base + 4], get!(WORDS)[base + 5].w)'
    assert original_shader.count(needle)==1
    fault=original_shader.replace(needle,b'load_color(get!(WORDS)[base + 4], 0)')
    (OUT/'legacy-paint-fault-shader.rs').write_bytes(fault)
    shader.write_bytes(fault)
    result['ignored_legacy_bank_flag']=run('bank-flag-fault','shared_bank_queues_a_patch_b_patch_c_without_poll_and_matches_full_literal_packets')
    assert result['ignored_legacy_bank_flag']['returncode']!=0
    log=(OUT/'bank-flag-fault/stderr.log').read_text()
    assert 'HDR=false frame=0' in log,log[-300:]
    result['bank_fault_reached_actual_pixel_assertion']=True
finally:
    shader.write_bytes(original_shader)
    tests.write_bytes(original_tests)
    result['exact_sources_restored']=shader.read_bytes()==original_shader and tests.read_bytes()==original_tests
    (OUT/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
result['bank_flag_recovery']=run('bank-flag-recovery','shared_bank_queues_a_patch_b_patch_c_without_poll_and_matches_full_literal_packets')
assert result['bank_flag_recovery']['returncode']==0
(OUT/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v if not isinstance(v,dict) else {x:y for x,y in v.items() if x in ['test','returncode']} for k,v in result.items()},indent=2))
