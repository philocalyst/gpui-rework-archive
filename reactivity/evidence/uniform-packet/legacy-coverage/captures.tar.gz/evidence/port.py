from pathlib import Path
import shutil
root=Path('/tmp/gpui-legacy-coverage-sol/reactivity/crates/gpu')
old=Path('/tmp/gpui-coverage-setup-sol/reactivity/crates/gpu')
p=root/'src/renderer.rs'; s=p.read_text(); ref=(old/'src/renderer.rs').read_text()
s=s.replace('mod artifact;','mod artifact;\nmod coverage;',1)
s=s.replace('const _: () = assert!(MAX_REFERENCES < UNIFORM_TILE as usize);','const CONSTANT_TILE: u32 = 1 << 30;\nconst OPAQUE_PREFIX: u32 = 1 << 29;\nconst TILE_END: u32 = OPAQUE_PREFIX - 1;\nconst _: () = assert!(MAX_REFERENCES < OPAQUE_PREFIX as usize);',1)
a=s.index('    /// Planned lattice samples'); b=s.index('    pub instance_upload_bytes',a)
a2=ref.index('    /// Planned color evaluations'); b2=ref.index('    pub instance_upload_bytes',a2)
s=s[:a]+ref[a2:b2]+s[b:]
s=s.replace('self.ranges.resize(columns * rows, [0, 0]);','self.ranges.resize(columns * rows, [0, CONSTANT_TILE]);',1)
a=s.index('        let mut offset = 0;');b=s.index('        let references = offset as usize;',a)
a2=ref.index('        let mut offset = 0;');b2=ref.index('        let references = offset as usize;',a2)
s=s[:a]+ref[a2:b2]+s[b:]
a=s.index('        let mut uniform_tiles = 0;');b=s.index('        let (tone, exposure)',a)
a2=ref.index('        let mut uniform_tiles = 0;');b2=ref.index('        let (tone, exposure)',a2)
s=s[:a]+ref[a2:b2]+s[b:]
a=s.index('    fn bin_draw(');b=s.index('    fn prepare_atlas(',a)
a2=ref.index('    fn bin_draw(');b2=ref.index('    fn prepare_atlas(',a2)
s=s[:a]+ref[a2:b2]+s[b:]
a=s.index('fn full_tile(');b=s.index('fn visit(',a)
a2=ref.index('fn full_tile(');b2=ref.index('fn visit(',a2)
s=s[:a]+ref[a2:b2]+s[b:]
p.write_text(s)
shutil.copy2(old/'src/renderer/coverage.rs',root/'src/renderer/coverage.rs')
p=root/'src/shader.rs';s=p.read_text();ref=(old/'src/shader.rs').read_text()
a=s.index('    pub fn load_draw(')
s=s[:a]+'''    // Coverage tags certify only solids. Read paint through the legacy bank
    // flag without loading local geometry, inverse transforms or clip words.
    pub fn load_paint(address: u32) -> Vec4f {
        let base = (address & 0x7fffffff) as usize;
        if (address & 0x80000000) != 0 {
            return load_color(get!(WORDS)[base + 4], get!(WORDS)[base + 5].w);
        }
        let state_base = get!(WORDS)[base + 1].w as usize;
        load_color(get!(WORDS)[state_base + 3], get!(WORDS)[state_base + 4].x)
    }
'''+s[a:]
a=s.index('    #[fragment]');b=s.index('\n}\n\n#[cfg(test)]',a)
a2=ref.index('    #[fragment]');b2=ref.index('\n}\n\n#[cfg(test)]',a2)
s=s[:a]+ref[a2:b2]+s[b:];p.write_text(s)
p=root/'tests/render.rs';s=p.read_text();ref=(old/'tests/render.rs').read_text()
a=ref.index('#[test]\nfn whole_coverage_setup');b=ref.index('#[test]\nfn opaque_tile_proofs',a)
assert 'fn whole_coverage_setup' not in s
s+='\n'+ref[a:b];p.write_text(s)
