from pathlib import Path
import hashlib,json
OUT=Path('/tmp/gpui-legacy-coverage-evidence');CG=Path('/tmp/gpui-legacy-coverage-codegen')
metadata=json.loads((CG/'metadata.json').read_text());flags={}
for label,lane in metadata['lanes'].items():
    lines=(CG/label/'cargo.log').read_text().splitlines()
    commands=[line.split('rustc --crate-name gpui_gpu ',1)[1] for line in lines if 'rustc --crate-name gpui_gpu ' in line and '--crate-type lib' in line]
    assert len(commands)==1,(label,len(commands))
    command=commands[0]
    flags[label]={'opt3':'-C opt-level=3' in command,
                  'root_v0_tokio':'-C symbol-mangling-version=v0' in command and '--cfg tokio_unstable' in command,
                  'emit_stack_sizes_count':command.count('-Zemit-stack-sizes'),
                  'library_fresh':lane['library_artifact']['fresh'],'groups_fresh':lane['groups_artifact']['fresh'],
                  'features':lane['library_artifact']['features']}
    assert flags[label]['opt3'] and flags[label]['root_v0_tokio'] and flags[label]['emit_stack_sizes_count']==1
    assert not flags[label]['library_fresh'] and not flags[label]['groups_fresh']
    assert hashlib.sha256(Path(lane['binary']).read_bytes()).hexdigest()==lane['binary_sha256']
assert len({tuple(f['features']) for f in flags.values()})==1
ledgers={label:json.loads((CG/label/'groups-elf.json').read_text()) for label in ['shipping','legacy277','candidate']}
functions={}
for name in ['<gpui_gpu::renderer::RendererState>::render','<gpui_gpu::renderer::RendererState>::bin_draw',
             'gpui_gpu::renderer::coverage::whole','gpui_gpu::renderer::coverage::axis']:
    values={}
    for label,ledger in ledgers.items():
        matches=[f for f in ledger['all_gpu_frames'] if f['normalized_name']==name]
        assert len(matches)<=1
        if matches:values[label]={'code_bytes':matches[0]['code_bytes'],'static_frame_bytes':matches[0]['stack_bytes']}
    functions[name]=values
counts={label:json.loads((OUT/name).read_text())['core_non_test_code_lines'] for label,name in
        [('shipping','core-lines-shipping.json'),('legacy277','core-lines-legacy-277.json'),('candidate','core-lines-candidate.json')]}
summary=json.loads((CG/'summary.json').read_text())
result={'candidate':metadata['candidate'],'shipping':'7a5e1619a27010ec63f6c27506a6d1fcd113f67c',
        'legacy277':'277473219bcf4add23d36126e70be1d72ceec1f6','same_physical_source_path':metadata['same_physical_source_path'],
        'sections':{label:ledger['sections'] for label,ledger in ledgers.items()},
        'section_deltas':{label:summary[label]['section_deltas'] for label in ['shipping','legacy277']},
        'function_costs':functions,'core_non_test_noncomment_lines':counts,
        'core_deltas':{label:counts['candidate']-counts[label] for label in ['shipping','legacy277']},
        'flag_verification':flags,'new_retained_fields':0,'new_proof_heap_allocations':0,
        'scope':'Actual linked groups executable under identical lock/features/config/opt3, fresh library/example in each lane. Compiler frame metadata is not dynamic peak, additive call-depth, or RSS. No timing campaign.'}
(OUT/'cost-ledger.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
