from pathlib import Path
import hashlib,json,subprocess
root=Path('/tmp/gpui-legacy-coverage-sol')
def git(*args):return subprocess.check_output(['git','-c','safe.directory='+str(root),'-C',str(root),*args])
def sha(b):return hashlib.sha256(b).hexdigest()
def source(ref,path):return git('show',ref+':reactivity/crates/gpu/src/'+path).decode()
base='277473219bcf4add23d36126e70be1d72ceec1f6';candidate='299c6aca30c1245c15c2da6a5ccabb41dd435d17';coverage='6158d25e483dea439832399e768ff4fbe1202640'
a=source(base,'renderer.rs');b=source(candidate,'renderer.rs');c=source(coverage,'renderer.rs')
def region(s,a,b):return s[s.index(a):s.index(b,s.index(a))]
checks={
 'borrowed_kernel_byte_identical_to_6158':source(candidate,'renderer/coverage.rs')==source(coverage,'renderer/coverage.rs'),
 'shader_fragment_byte_identical_to_6158':region(source(candidate,'shader.rs'),'    #[fragment]','\n}\n\n#[cfg(test)]')==region(source(coverage,'shader.rs'),'    #[fragment]','\n}\n\n#[cfg(test)]'),
 'bin_draw_byte_identical_to_6158':region(b,'    fn bin_draw(','    fn prepare_atlas(')==region(c,'    fn bin_draw(','    fn prepare_atlas('),
 'legacy_source_over_compositor_body_preserved':region(source(base,'shader.rs'),'                let draw = load_draw','        output(anchor + delta)')==region(source(candidate,'shader.rs'),'                let draw = load_draw','        output(anchor + delta)'),
 'legacy_complete_record_generation_preserved':region(a,'        self.records.clear();','        let mut offset = 0;')==region(b,'        self.records.clear();','        let mut offset = 0;'),
 'legacy_reverse_resource_and_CSR_walk_preserved':region(a,'        // Reverse group traversal','        let mut uniform_tiles = 0;')==region(b,'        // Reverse group traversal','        let mut uniform_tiles = 0;'),
 'legacy_upload_and_stats_paths_preserved':region(a,'        let (tone, exposure)','    /// Submit the last successfully prepared packet')==region(b,'        let (tone, exposure)','    /// Submit the last successfully prepared packet'),
 'legacy_geometry_numeric_predicate_preserved':region(a[a.index('fn full_tile('):],'    let [left, top, right, bottom]','fn visit(')==region(b[b.index('fn full_tile('):],'    let [left, top, right, bottom]','fn visit('),
 'legacy_load_draw_preserved':region(source(base,'shader.rs'),'    pub fn load_draw','    #[vertex]')==region(source(candidate,'shader.rs'),'    pub fn load_draw','    #[vertex]'),
}
paths=git('ls-files','reactivity/crates/gpu/src','reactivity/crates/gpu/build.rs').decode().splitlines()
changed={p for p in paths if git('diff',base,candidate,'--',p)}
checks['only_three_production_files_changed']=changed=={'reactivity/crates/gpu/src/renderer.rs','reactivity/crates/gpu/src/renderer/coverage.rs','reactivity/crates/gpu/src/shader.rs'}
assert all(checks.values()),checks
result={'candidate':candidate,'base':base,'coverage_kernel':coverage,'checks':checks,'production_changed':sorted(changed),'coverage_sha256':sha(source(candidate,'renderer/coverage.rs').encode())}
Path('/tmp/gpui-legacy-coverage-evidence/source-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
