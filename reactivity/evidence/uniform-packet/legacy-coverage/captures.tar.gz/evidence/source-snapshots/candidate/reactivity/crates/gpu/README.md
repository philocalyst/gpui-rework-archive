# GPU compositor

The renderer borrows the canonical prepared canvas scene. It uploads geometry,
tile references and missing glyph masks, then composites the same 4×4 sample
lattice in linear light. Submission never requests a CPU output image.

## Replaying the prepared packet

`Renderer::render(scene, target)` always validates and prepares the borrowed
scene. A repeated borrow, Canvas address, sequence number, or equality of its
public headers does not establish scene identity. Every new render attempt
discards the previous packet's replay eligibility before it can change buffers,
images, or the glyph atlas; a failed attempt cannot replay partially overwritten
resources under the previous scene.

After successful preparation, `Renderer::redraw(target)` explicitly submits that
renderer-owned packet again. It returns `Ok(None)` when no packet is eligible.
An eligible packet retains one bind group and its dimensions, alongside the
existing buffers, vectors and resource caches. Replay skips scene traversal,
admission, CSR construction, image-key checks, uploads and binding creation.
It still clears and draws the entire newly acquired target and submits commands;
it does not acknowledge presentation or depend on preserved swapchain contents.
The source scene and its borrowed image/mask leases may be dropped after prepare.

The target must meet the same device/view contract as `render`, and have the
prepared dimensions and renderer format. A wrong-size/format replay target
returns `InvalidScene` while leaving the eligible packet available for retry.
Changing a diagnostic mode invalidates the packet; setting the same mode does
not. A recreated renderer begins with no packet.

The native GPU adapter binds this seam privately to the window-qualified
`PresentationToken` returned with its untouched complete scene. Different tokens
use full preparation; no public token-plus-scene API trusts caller pairing.
`Stats::packet_reused` and CPU validation/binning/upload/binding counters describe
the last successful submission. Retained draw/sample counts still describe work
submitted to the GPU. These counters are neither GPU timings nor an allocation
claim about wgpu, command encoding, submission or OS presentation.

## Spatial precision

The GPU does not promise universal CPU byte parity. Canonical inverses are f64;
WGSL arithmetic is f32 and its backend arithmetic rules differ from Rust f64.
Admission rejects inverses whose conservative coefficient/arithmetic estimate
maps to more than **1/32 device pixel**. This is a spatial admission ceiling,
not permission to change sample membership: even a much smaller displacement
can cross a half-open edge or an integer glyph texel boundary.

Each draw carries a local uncertainty envelope. Samples within that envelope
use split inverse coefficients and two-float products/sums, retaining the low
lane separately through comparisons. Glyph coordinates are normalized from the
logical rectangle to physical mask dimensions; near integer texel boundaries
the division and floor also retain the low lane. This fixes the tested 1/3
inverse boundary without requiring hardware f64. It remains finite shader
arithmetic; no portable exact-predicate theorem or all-backend parity claim is
made. Nonfinite coefficients, excessive intermediate magnitudes and overflowing
mask-coordinate scales are rejected with `Error::Precision`.

Clips retain their authored start and extent. Only a sample equal to the rounded
clip endpoint loads the host-computed endpoint residual, preserving the CPU's
half-open comparison against the f64 sum. These two residuals use the spare
lanes of the existing correction record; draw and correction strides do not grow.

The Vulkan regressions exercise neighboring representable widths, reflection,
overlapping alpha edges, physical glyph scales 1/1.25/1.5/2, threshold clear
colors and premultiplied float output. They run on Mesa llvmpipe Vulkan here;
other backends require their own validation.

Portable `cargo test -p gpui_gpu` validates generated WGSL and CPU packing. Run
`cargo test -p gpui_gpu --features vulkan-tests --test render` for actual Vulkan
conformance; this command requires an adapter and never silently skips tests.

## Storage and output

The canonical canvas has one grouped scene authority. GPU preparation traverses
its borrowed groups and unique mask leases directly; it does not rebuild an
expanded scene or clone a mask handle per placement. Atlas admission/repacking
also visits unique masks rather than every glyph occurrence.

The draw storage binding is an array of sixteen-byte words. Rectangles and
singleton groups use a 96-byte inline record. A group with at least two visible
placements uses one 80-byte common record (inverse, uncertainty envelope, clip,
paint, correction index) plus 32 bytes per placement (local rectangle and atlas
coordinates/common address). Two placements therefore cost 144 rather than
192 bytes. The shader reconstructs its existing local `Draw` value through
bitcasts and an extra common-record indirection. Bitcasts preserve bits; this is
not a claim that every backend compiles them to zero instructions.

Private word addresses use a high tag for inline records. They are built only
after bounded scene traversal; callers cannot supply addresses or offsets.
Reverse group traversal recovers variable-width addresses while filling the
CSR, retaining no extra per-draw address lane. Tile cutoffs remain painter
ordinals, distinct from addresses. All four existing storage-buffer bindings
are preserved: records, tile headers, reference addresses and corrections.
Each placement is admitted independently; a compact group's shared per-axis
uncertainty is the maximum of its placements. This can increase DD work but
cannot narrow the correction trigger or relax tile certification.

One 32-byte zero correction is shared by exactly
representable inverses and clip endpoints; other residual tuples are deduplicated by complete bit
equality in a reused host hash table. Each distinct tuple costs another 32 bytes
on the host and GPU, plus one host hash entry (32-byte key and 4-byte index,
plus table overhead). The worst case is one tuple per draw. Buffer capacities
grow geometrically and remain retained. `Stats` reports upload bytes, allocated
GPU buffer bytes, host vector capacity bytes and correction hash entry capacity;
the last is not an allocator-byte total. Glyph atlas/table overhead and wgpu's
internal allocations are separate. No low-lane allocation occurs per sample.

After successful scene admission, a scene with no glyph masks releases the
atlas key map and replaces a populated atlas with a minimal 1×1 texture. Repeated
text-free scenes reuse that texture. Submitted frames retain their old texture
leases through wgpu; returning text uploads its masks again. `atlas_keys` and
`atlas_key_capacity` expose the retained key count and table entry capacity.

Constant sample colors use anchor-plus-delta averaging so adding a draw covering
zero samples preserves the clear value. Float output stays premultiplied through
profile conversion and storage, avoiding an unnecessary divide/multiply by
alpha. SDR Reinhard evaluation clamps overflow defensively before division;
the canonical color configuration's exposure admission still applies.
An HDR float render target is independent of native surface color management.
Scene `ColorConfig::format` must match the target's SDR or float storage class;
the renderer rejects mismatches rather than silently overriding scene metadata.
The current native host presents a tagged SDR surface; this float target API
does not imply native HDR swapchain negotiation or display support.

## Opaque tile proofs

The existing eight-byte tile header has two forms: `[start, end]` indexes the
sampled CSR, and `[record_address, 1<<31]` selects one certified final opaque color.
Empty ranges select clear. No per-tile allocation was added. The existing
four-byte-per-tile cursor scratch holds each tile's cutoff while reverse scene
traversal fills the compact CSR in painter order. All canonical and uploaded
draw records remain retained; each frame rebuilds the disposable proof, so
changing alpha, clip or material restores any newly visible background.

A certificate requires a rectangle, alpha exactly one, and no negative-zero
or negative-subnormal channels (source-over can change a zero's sign according
to the backdrop, including a zero produced by flushing a subnormal).
The continuous tile must fit in the clip. Four corners of the actual sample
hull, offset 1/8 pixel inside the tile, must independently satisfy:

* canonical f64 membership with an arithmetic guard;
* packed-high f32 membership with a conservative raw dot/origin/extent rounding
  margin **plus** the shader's local uncertainty envelope.

Affine convexity covers every intervening sample. The second check keeps every
rectangle sample outside the DD branch, so the proof does not assume that DD
and CPU f64 produce identical boundary decisions. Uncertain geometry falls
back. A tile's last certified opaque rectangle hides all preceding references;
every later draw remains. If none follow, the shader converts the final color
once per pixel and bypasses all sixteen samples. Bounds that overlap a tile
conservatively can prevent this last case even when their samples are empty.

`set_tile_proofs(false)` selects the general path for comparisons. `Stats`
distinguishes original references, uploaded sampled references, omitted
references, uniform tiles, planned lattice samples and planned `sample_draw`
calls. The last two count shader work, not hardware performance counters.

## Measured regimes

[tile-benchmark.csv](tile-benchmark.csv) records release-build Mesa 26.1.4
llvmpipe Vulkan on LLVM 21.1.8, 512×256 pixels. Each mode runs in a fresh process,
warms three frames, then records nine serialized frames. Wall time covers host
admission/packing/uploads/submission and completion polling. Host submit time
ends when `render` returns. Neither is a discrete-GPU timestamp measurement.
The text fixture uses the Fontdue canvas dependency at this branch's base;
font-backend changes require a new run.

| Case | Wall time, proofs off → on | Host submit time | Sample draw calls |
| --- | ---: | ---: | ---: |
| One opaque fill | 13.05 → 0.43 ms | 47 → 60 μs | 2,097,152 → 0 |
| 24 labels over fill | 22.84 → 20.56 ms | 105 → 118 μs | 6,045,696 → 5,459,968 |
| 32 opaque fills | 182.17 → 1.18 ms | 178 → 715 μs | 67,108,864 → 0 |
| Thin boundary stripes | 23.44 → 26.12 ms | 53 → 84 μs | 6,160,384 → 6,160,384 |

The boundary case loses: it removes no work or storage and adds proof cost.
The full-overlap case removes sampled work while retaining all 32 draw records.
Its explicit GPU buffer capacity falls from 73,808 to 8,276 bytes, and host
vector capacity from 74,880 to 9,344 bytes. For text, retained GPU buffers stay
45,136 bytes and the atlas stays 65,536 bytes; host vectors fall only 572 bytes.
The 524,288-byte render target remains in every case. Source canvas records,
source masks, driver allocations and hash-table overhead are additional; these
figures are not whole-application memory totals. CSV peak RSS is the actual
Linux process high-water mark, including pipeline compilation, fonts and the
software driver, rather than an attributed renderer allocator peak. In-flight
wgpu leases can also keep replaced resources alive beyond a frame. Atlas bytes
count texel payload; physical texture padding and driver overhead are opaque.

Reproduce after setting the Vulkan loader/ICD environment:

```sh
cargo build -p gpui_gpu --release --features vulkan-tests --example tiles
target/release/examples/tiles > tile-benchmark.csv
for case in flat text overlap32 boundary; do
  for proofs in false true; do
    target/release/examples/tiles "$case" "$proofs" >> tile-benchmark.csv
  done
done
```

The general path still evaluates sixteen samples per pixel and every retained
tile reference. Glyph sampling and translucent overlap remain sampled work.

## Grouped upload measurements

[groups-benchmark.csv](groups-benchmark.csv) records three alternating fresh
process pairs using Mesa 26.1.4 llvmpipe Vulkan, LLVM 21.1.8, release Rust 1.97.1,
512×256 RGBA8. Each process warms three frames and takes the median of nine
serialized frames. The table takes the median of the three process medians.
`set_grouped_records(false)` uses the inline schema with the same shader,
canonical scene and tile proofs. Wall time includes host preparation, upload,
submission and completion polling; it is not a GPU timestamp.

| Fixture | Record bytes, inline → grouped | Explicit GPU buffer capacity | Wall time | Host submit time |
| --- | ---: | ---: | ---: | ---: |
| One opaque fill | 96 → 96 | 4,308 → 4,308 | 440 → 412 μs | 55.6 → 56.9 μs |
| 24 labels, 312 glyphs | 29,952 → 11,904 | 41,040 → 24,656 | 14.04 → 14.14 ms | 84.5 → 86.6 μs |
| 1,000 runs, 32,000 glyphs | 3,072,096 → 1,104,096 | 4,198,484 → 2,101,332 | 4.18 → 4.20 ms | 3.590 → 3.692 ms |
| 32,000 singleton glyphs | 3,072,096 → 3,072,096 | 4,198,484 → 4,198,484 | 5.434 → 5.400 ms | 4.676 → 4.757 ms |

The 32K fixtures end with one full opaque fill: all canonical records are still
prepared/uploaded, while tile proofs remove an otherwise artificial massive
overlap sample loop. They measure packet cost, not visible 32K-glyph throughput.
The real-label fixture retains 3,948,544 planned sample-draw calls in both modes.
Singletons take the same inline path in both modes; their differences and the
flat case illustrate timing noise. Grouped storage improves memory here without
a measured frame-time win. Extra decoding and a shared wider uncertainty
envelope can lose on other backends or transforms.

For the 32K-run fixture, retained host vector capacities fall from 3,078,368 to
1,110,368 bytes and per-frame non-mask uploads from 3,076,272 to 1,108,272 bytes.
Both modes retain the same 65,536-byte atlas and 524,288-byte target. These are
logical buffer capacities and texel payloads, not physical driver residency.
Hash tables, source canvas storage/masks, pipeline allocations and in-flight
resource leases are additional. Buffers retain peak capacity; switching an
already-large renderer to compact mode does not shrink past allocations.

Tests validate sixteen-byte storage stride/four-buffer ABI and float-bit
packing, plus actual Vulkan inline/compact pixel equality for mixed groups,
HDR signed zeros/subnormals, fractional/reflected DPI glyphs, clip residuals,
middle opaque cutoffs, background resurrection and atlas reset. These backend
oracles supplement the finite precision admission policy, not replace it.

```sh
cargo build -p gpui_gpu --release --features vulkan-tests --example groups
target/release/examples/groups text false
target/release/examples/groups text true
```
