from pathlib import Path
import gzip
import hashlib
import json
import tarfile

ROOTS = {
    'evidence': Path('/tmp/gpui-legacy-coverage-evidence'),
    'codegen': Path('/tmp/gpui-legacy-coverage-codegen'),
}
ARCHIVE = Path('/tmp/gpui-legacy-coverage-qualified.tar.gz')
MANIFEST = Path('/tmp/gpui-legacy-coverage-capture-manifest.json')

def sha(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        while block := stream.read(1024 * 1024):
            value.update(block)
    return value.hexdigest()

members = []
external = []
for prefix, root in ROOTS.items():
    for path in sorted(root.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts:
            continue
        with path.open('rb') as stream:
            elf = stream.read(4) == b'\x7fELF'
        entry = {'member': prefix + '/' + str(path.relative_to(root)),
                 'source_path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}
        if elf:
            external.append({**entry, 'reason': 'ELF excluded; preserved externally with exact hash.'})
        else:
            members.append(entry)
manifest = {'source': '299c6aca30c1245c15c2da6a5ccabb41dd435d17',
            'baseline': '277473219bcf4add23d36126e70be1d72ceec1f6',
            'shipping': '7a5e1619a27010ec63f6c27506a6d1fcd113f67c',
            'payload_members': members, 'external_elf': external,
            'manifest_member': 'capture-manifest.json',
            'manifest_integrity': 'Anchored by external archive SHA-256; every other member is individually hashed.',
            'scope': 'Legacy packet coverage correctness/static qualification. No timing campaign or adoption claim.'}
MANIFEST.write_text(json.dumps(manifest, indent=2) + '\n')
assert not ARCHIVE.exists()
with ARCHIVE.open('wb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, compresslevel=6, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w|') as archive:
            for entry in members:
                archive.add(entry['source_path'], arcname=entry['member'], recursive=False)
            archive.add(MANIFEST, arcname='capture-manifest.json', recursive=False)
expected = {entry['member']: entry for entry in members}
seen = set()
with tarfile.open(ARCHIVE, 'r:gz') as archive:
    for member in archive:
        assert member.isfile() and member.name not in seen
        seen.add(member.name)
        stream = archive.extractfile(member)
        value = hashlib.sha256()
        size = 0
        while block := stream.read(1024 * 1024):
            value.update(block)
            size += len(block)
        if member.name == 'capture-manifest.json':
            assert size == MANIFEST.stat().st_size and value.hexdigest() == sha(MANIFEST)
        else:
            assert size == expected[member.name]['bytes']
            assert value.hexdigest() == expected[member.name]['sha256'], member.name
assert seen == set(expected) | {'capture-manifest.json'}
report = {'archive': str(ARCHIVE), 'bytes': ARCHIVE.stat().st_size,
          'sha256': sha(ARCHIVE), 'payload_files': len(members),
          'payload_bytes': sum(entry['bytes'] for entry in members),
          'external_elf_files': len(external), 'manifest_sha256': sha(MANIFEST),
          'every_member_reopened_and_verified': True}
Path('/tmp/gpui-legacy-coverage-archive-verification.json').write_text(json.dumps(report, indent=2) + '\n')
Path('/tmp/gpui-legacy-coverage-qualified.tar.gz.sha256').write_text(report['sha256'] + '  ' + str(ARCHIVE) + '\n')
print(json.dumps(report, indent=2))
