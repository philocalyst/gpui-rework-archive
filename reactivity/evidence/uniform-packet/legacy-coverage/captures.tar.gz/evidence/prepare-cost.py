from pathlib import Path
s=Path('/tmp/gpui-coverage-setup-evidence/codegen.py').read_text()
s=s.replace("ROOT = Path('/tmp/gpui-coverage-setup-sol')","ROOT = Path('/tmp/gpui-legacy-coverage-sol')")
s=s.replace("SUPPORT = Path('/tmp/gpui-coverage-setup-evidence')","SUPPORT = Path('/tmp/gpui-legacy-coverage-evidence')")
s=s.replace("OUT = Path('/tmp/gpui-coverage-setup-codegen')","OUT = Path('/tmp/gpui-legacy-coverage-codegen')")
s=s.replace("TARGET = Path('/tmp/gpui-coverage-setup-codegen-target')","TARGET = Path('/tmp/gpui-legacy-coverage-codegen-target')")
s=s.replace("BASELINE = 'a81bc7536b002b1f81e1b36137c1c4de543e2204'","BASELINE = '7a5e1619a27010ec63f6c27506a6d1fcd113f67c'\nLEGACY = '277473219bcf4add23d36126e70be1d72ceec1f6'")
s=s.replace("CANDIDATE = '0359d674c434c7db8afddda591a403d9cb0cca45'","CANDIDATE = '299c6aca30c1245c15c2da6a5ccabb41dd435d17'")
s=s.replace("for label, ref in [('baseline', BASELINE), ('candidate', CANDIDATE)]:","for label, ref in [('shipping', BASELINE), ('legacy277', LEGACY), ('candidate', CANDIDATE)]:")
s=s.replace("(ROOT / name).unlink()","(ROOT / name).unlink(missing_ok=True)")
s=s[:s.index('ledgers = ')]
s+='''\nledgers = {label: json.loads((OUT / label / 'groups-elf.json').read_text()) for label in ['shipping', 'legacy277', 'candidate']}
summary={}
for baseline in ['shipping','legacy277']:
    by_name={}
    for label in [baseline,'candidate']:
        values=collections.defaultdict(list)
        for f in ledgers[label]['all_gpu_frames']:
            values[f['normalized_name']].append(f)
        by_name[label]=values
    pairs=[];unpaired=[]
    for name in sorted(set(by_name[baseline])|set(by_name['candidate'])):
        old=by_name[baseline].get(name,[]);new=by_name['candidate'].get(name,[])
        if len(old)==len(new)==1:
            pairs.append({'name':name,'baseline':old[0],'candidate':new[0],
                          'code_delta':new[0]['code_bytes']-old[0]['code_bytes'],
                          'frame_delta':new[0]['stack_bytes']-old[0]['stack_bytes']})
        else:
            unpaired.append({'name':name,'baseline':old,'candidate':new})
    summary[baseline]={'section_deltas':{name:ledgers['candidate']['sections'][name]-ledgers[baseline]['sections'][name]
                    for name in ['.text','.rodata','.data.rel.ro','.stack_sizes']},
                    'unique_name_pairs':pairs,'unpaired_or_ambiguous':unpaired}
summary['scope']='All GPU symbol aliases retained. Only unique normalized-name pairs are paired. Static frames are not dynamic peak or additive call chains. No timing.'
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\\n')
print(json.dumps({k:v['section_deltas'] for k,v in summary.items() if isinstance(v,dict)},indent=2),flush=True)
'''
Path('/tmp/gpui-legacy-coverage-evidence/codegen.py').write_text(s)
