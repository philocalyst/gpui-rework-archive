from pathlib import Path
import csv,json,re
OUT=Path('/tmp/gpui-legacy-coverage-evidence')
directories={'shipping':Path('/tmp/gpui-gpu-frontier-evidence/calibration/pair-00-A'),
             'uniform_a81':Path('/tmp/gpui-gpu-frontier-evidence/calibration/pair-00-B'),
             'candidate':OUT/'public-calibration'}
def rows(directory):
    values={}
    for r in csv.DictReader((directory/'frames.csv').open()):
        key='/'.join(r[k] for k in ['case','hdr','motion','frame'])
        stats={k:int(v) if v.isdigit() else v for k,v in re.findall(r'(\w+): ([^,}]+)',r['stats'])}
        values[key]=stats
    return values
lanes={k:rows(v) for k,v in directories.items()}
fields=['draws','draw_record_bytes','shared_groups','compact_draws','inline_draws','instance_upload_bytes',
        'gpu_buffer_bytes','cpu_index_capacity_bytes','tile_references','original_tile_references',
        'sample_evaluations','sample_draw_evaluations','uniform_tiles','validated_draws','binning_tile_visits']
all_cells=[]
for key,stats in lanes['candidate'].items():
    all_cells.append({'cell_frame':key,**{label:{f:data[key][f] for f in fields} for label,data in lanes.items()}})
# A successful certificate implies every old tile predicate; opaque cutoffs are
# consequently identical. The only sampled proof change is added translucency.
for r in all_cells:
    for field in ['draw_record_bytes','shared_groups','compact_draws','inline_draws','instance_upload_bytes',
                  'gpu_buffer_bytes','cpu_index_capacity_bytes','tile_references','original_tile_references',
                  'uniform_tiles','validated_draws','binning_tile_visits']:
        assert r['candidate'][field]==r['shipping'][field],(r['cell_frame'],field)
result={'scope':'Observed public calibration payload/capacity diagnostics; capacity sums exclude allocator/control overhead and are not RSS. No elapsed-time comparison.',
        'legacy277':'Packet writer/upload/resource paths and ABI byte-identical to candidate; source-audit.json checks this. Fresh named pixel controls separately compare its pixels.',
        'retained_production_fields_added':0,'heap_allocations_added_by_coverage_kernel':0,
        'legacy_common_record_bytes':80,'uniform_common_record_bytes':64,'extra_bytes_per_shared_group_vs_uniform':16,
        'full_warm_uploads':True,'all_candidate_shipping_payload_and_capacity_fields_exact':True,
        'cells':all_cells}
(OUT/'payload-ledger.json').write_text(json.dumps(result,indent=2)+'\n')
for r in all_cells:
    if r['cell_frame'] in ['flat/false/false/1','layers8/false/false/1','runs32k/false/false/1','singletons32k/false/false/1']:
        print(r['cell_frame'],json.dumps({k:v for k,v in r.items() if k!='cell_frame'}))
