from pathlib import Path
import hashlib,json,re,subprocess
ROOT=Path('/tmp/gpui-legacy-coverage-sol');OUT=Path('/tmp/gpui-legacy-coverage-evidence');CG=Path('/tmp/gpui-legacy-coverage-codegen')
meta=json.loads((CG/'metadata.json').read_text())
for name,digest in meta['guards_sha256'].items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
assert not subprocess.check_output(['git','-c','safe.directory='+str(ROOT),'-C',str(ROOT),'status','--porcelain'])
for name in ['offline','strict-default','strict-offline','functional','negative','apple','msvc','codegen','supplemental','format-final']:
 assert (OUT/(name+'.exit')).read_text().strip()=='0',name
assert (OUT/'workspace-format-preexisting.exit').read_text().strip()=='1'
gates={}
for name,expected in [('default',[14,4,50,1]),('fallback',[14,4,50,1]),('offline',[15,4,51,1])]:
 counts=[int(x) for x in re.findall(r'test result: ok\. (\d+) passed;', (OUT/(name+'.log')).read_text())]
 assert counts==expected,(name,counts);gates[name]=counts
functional=json.loads((OUT/'functional-summary.json').read_text());named=json.loads((CG/'named-readback-comparison.json').read_text());negative=json.loads((OUT/'sealed-negative-control.json').read_text());extra=json.loads((OUT/'supplemental/summary.json').read_text())
actual_fields={field for row in functional['diagnostic_differences'] for field in row['fields']}
assert actual_fields=={'instance_upload_bytes','draw_record_bytes','cpu_index_capacity_bytes'}
result={'source':'299c6aca30c1245c15c2da6a5ccabb41dd435d17','base':'277473219bcf4add23d36126e70be1d72ceec1f6',
        'shipping':'7a5e1619a27010ec63f6c27506a6d1fcd113f67c','status':'qualified correctness/static costs; unadopted; no timed campaign',
        'gates':{**gates,**{name:True for name in ['strict-default','strict-offline','apple','msvc','package-format']}},
        'workspace_format':{'exit':1,'reason':'unchanged vendored/unrelated formatting in the exact old source base','full_log':'workspace-format-preexisting.log'},
        'public_exact_readbacks':{'files':len(functional['readbacks']),'bytes':functional['exact_readback_bytes'],'adapter_exact':True,'diagnostic_difference_fields':['instance_upload_bytes','draw_record_bytes','cpu_index_capacity_bytes']},
        'named_readbacks':{k:v for k,v in named.items() if k!='comparisons'},
        'false_coverage_negative':negative,'legacy_decoder_and_high_correction':extra,
        'costs':json.loads((OUT/'cost-ledger.json').read_text()),
        'payload':{'full_warm_uploads':True,'new_proof_heap_allocations':0,'new_retained_fields':0,'candidate_shipping_payload_and_capacity_exact_all_52_public_frames':True,'extra_common_bytes_per_group_vs_uniform':16,'runs32k_warm_upload_bytes':1108272,'singleton32k_warm_upload_bytes':3076272},
        'source_guards_verified':len(meta['guards_sha256']),'final_worktree_clean':True,'prior_archives_unchanged':json.loads((OUT/'prior-archives-unchanged.json').read_text())}
(OUT/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'source':result['source'],'gates':result['gates'],'public_readbacks':result['public_exact_readbacks'],'named_readbacks':result['named_readbacks'],'source_guards_verified':result['source_guards_verified']},indent=2))
