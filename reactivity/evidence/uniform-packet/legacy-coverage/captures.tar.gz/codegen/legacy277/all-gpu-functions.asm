
FUNCTION core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>> bytes=105 frame=8

/tmp/gpui-legacy-coverage-codegen/legacy277/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000815ef0 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>:
  815ef0:	push   %rbx
  815ef1:	test   %rdi,%rdi
  815ef4:	je     815f57 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x67>
  815ef6:	mov    %rdi,%rbx
  815ef9:	mov    (%rdi),%rsi
  815efc:	test   %rsi,%rsi
  815eff:	je     815f14 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x24>
  815f01:	mov    0x8(%rbx),%rdi
  815f05:	shl    $0x3,%rsi
  815f09:	mov    $0x8,%edx
  815f0e:	call   *0x6692bc(%rip)        # e7f1d0 <_DYNAMIC+0x248>
  815f14:	mov    0x20(%rbx),%rsi
  815f18:	test   %rsi,%rsi
  815f1b:	je     815f43 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  815f1d:	mov    %rsi,%rax
  815f20:	shl    $0x4,%rax
  815f24:	add    %rax,%rsi
  815f27:	add    $0x21,%rsi
  815f2b:	je     815f43 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  815f2d:	mov    0x18(%rbx),%rdi
  815f31:	sub    %rax,%rdi
  815f34:	add    $0xfffffffffffffff0,%rdi
  815f38:	mov    $0x10,%edx
  815f3d:	call   *0x66928d(%rip)        # e7f1d0 <_DYNAMIC+0x248>
  815f43:	mov    $0x80,%esi
  815f48:	mov    $0x8,%edx
  815f4d:	mov    %rbx,%rdi
  815f50:	pop    %rbx
  815f51:	jmp    *0x669279(%rip)        # e7f1d0 <_DYNAMIC+0x248>
  815f57:	pop    %rbx
  815f58:	ret

FUNCTION core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}> bytes=71 frame=8

/tmp/gpui-legacy-coverage-codegen/legacy277/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000816560 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>>:
  816560:	push   %rbx
  816561:	cmpb   $0x3,0x19c(%rdi)
  816568:	jne    816597 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x37>
  81656a:	movzbl 0x28(%rdi),%eax
  81656e:	cmp    $0x4,%eax
  816571:	je     816585 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x25>
  816573:	cmp    $0x3,%eax
  816576:	jne    816597 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x37>
  816578:	add    $0x168,%rdi
  81657f:	pop    %rbx
  816580:	jmp    8164d0 <core::ptr::drop_glue::<<wgpu::api::adapter::Adapter>::request_device::{closure#0}>>
  816585:	mov    %rdi,%rbx
  816588:	add    $0x30,%rdi
  81658c:	call   8165b0 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>>
  816591:	movw   $0x0,0x29(%rbx)
  816597:	pop    %rbx
  816598:	ret
  816599:	movw   $0x0,0x29(%rbx)
  81659f:	mov    %rax,%rdi
  8165a2:	call   e2bd40 <_Unwind_Resume@plt>

FUNCTION core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}> bytes=540 frame=40

/tmp/gpui-legacy-coverage-codegen/legacy277/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008165b0 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>>:
  8165b0:	push   %r15
  8165b2:	push   %r14
  8165b4:	push   %r12
  8165b6:	push   %rbx
  8165b7:	push   %rax
  8165b8:	mov    %rdi,%rbx
  8165bb:	movzbl 0x9e(%rdi),%eax
  8165c2:	test   %eax,%eax
  8165c4:	je     81668b <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xdb>
  8165ca:	cmp    $0x3,%eax
  8165cd:	jne    8166c1 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x111>
  8165d3:	mov    0x20(%rbx),%r15
  8165d7:	mov    0x28(%rbx),%r12
  8165db:	mov    (%r12),%rax
  8165df:	test   %rax,%rax
  8165e2:	je     8165e9 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x39>
  8165e4:	mov    %r15,%rdi
  8165e7:	call   *%rax
  8165e9:	mov    0x8(%r12),%rsi
  8165ee:	test   %rsi,%rsi
  8165f1:	je     816601 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x51>
  8165f3:	mov    0x10(%r12),%rdx
  8165f8:	mov    %r15,%rdi
  8165fb:	call   *0x668bcf(%rip)        # e7f1d0 <_DYNAMIC+0x248>
  816601:	mov    0x68(%rbx),%rax
  816605:	lock decq (%rax)
  816609:	jne    816615 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x65>
  81660b:	lea    0x68(%rbx),%rdi
  81660f:	call   *0x668ddb(%rip)        # e7f3f0 <_DYNAMIC+0x468>
  816615:	movb   $0x0,0x98(%rbx)
  81661c:	mov    0x60(%rbx),%rax
  816620:	lock decq (%rax)
  816624:	jne    81662f <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x7f>
  816626:	lea    0x60(%rbx),%rdi
  81662a:	call   812730 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  81662f:	movw   $0x0,0x99(%rbx)
  816638:	mov    0x40(%rbx),%rax
  81663c:	lock decq (%rax)
  816640:	jne    81664c <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x9c>
  816642:	lea    0x40(%rbx),%rdi
  816646:	call   *0x668dac(%rip)        # e7f3f8 <_DYNAMIC+0x470>
  81664c:	movb   $0x0,0x9b(%rbx)
  816653:	mov    0x38(%rbx),%rax
  816657:	lock decq (%rax)
  81665b:	jne    816667 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xb7>
  81665d:	lea    0x38(%rbx),%rdi
  816661:	call   *0x668d99(%rip)        # e7f400 <_DYNAMIC+0x478>
  816667:	movb   $0x0,0x9c(%rbx)
  81666e:	mov    0x30(%rbx),%rax
  816672:	lock decq (%rax)
  816676:	jne    816682 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xd2>
  816678:	lea    0x30(%rbx),%rdi
  81667c:	call   *0x668d86(%rip)        # e7f408 <_DYNAMIC+0x480>
  816682:	movb   $0x0,0x9d(%rbx)
  816689:	jmp    8166c1 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x111>
  81668b:	mov    0x70(%rbx),%rax
  81668f:	lock decq (%rax)
  816693:	jne    81669f <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xef>
  816695:	lea    0x70(%rbx),%rdi
  816699:	call   *0x668d69(%rip)        # e7f408 <_DYNAMIC+0x480>
  81669f:	mov    0x78(%rbx),%rax
  8166a3:	lock decq (%rax)
  8166a7:	jne    8166c1 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x111>
  8166a9:	add    $0x78,%rbx
  8166ad:	mov    %rbx,%rdi
  8166b0:	add    $0x8,%rsp
  8166b4:	pop    %rbx
  8166b5:	pop    %r12
  8166b7:	pop    %r14
  8166b9:	pop    %r15
  8166bb:	jmp    *0x668d3f(%rip)        # e7f400 <_DYNAMIC+0x478>
  8166c1:	add    $0x8,%rsp
  8166c5:	pop    %rbx
  8166c6:	pop    %r12
  8166c8:	pop    %r14
  8166ca:	pop    %r15
  8166cc:	ret
  8166cd:	mov    %rax,%r14
  8166d0:	movb   $0x0,0x9d(%rbx)
  8166d7:	mov    %r14,%rdi
  8166da:	call   e2bd40 <_Unwind_Resume@plt>
  8166df:	mov    %rax,%r14
  8166e2:	jmp    81679c <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1ec>
  8166e7:	mov    %rax,%r14
  8166ea:	jmp    816781 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1d1>
  8166ef:	mov    %rax,%r14
  8166f2:	jmp    816764 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1b4>
  8166f4:	mov    %rax,%r14
  8166f7:	jmp    81674a <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x19a>
  8166f9:	mov    %rax,%r14
  8166fc:	mov    0x78(%rbx),%rax
  816700:	lock decq (%rax)
  816704:	jne    816713 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x163>
  816706:	add    $0x78,%rbx
  81670a:	mov    %rbx,%rdi
  81670d:	call   *0x668ced(%rip)        # e7f400 <_DYNAMIC+0x478>
  816713:	mov    %r14,%rdi
  816716:	call   e2bd40 <_Unwind_Resume@plt>
  81671b:	mov    %rax,%r14
  81671e:	mov    0x8(%r12),%rsi
  816723:	test   %rsi,%rsi
  816726:	je     816736 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x186>
  816728:	mov    0x10(%r12),%rdx
  81672d:	mov    %r15,%rdi
  816730:	call   *0x668a9a(%rip)        # e7f1d0 <_DYNAMIC+0x248>
  816736:	mov    0x68(%rbx),%rax
  81673a:	lock decq (%rax)
  81673e:	jne    81674a <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x19a>
  816740:	lea    0x68(%rbx),%rdi
  816744:	call   *0x668ca6(%rip)        # e7f3f0 <_DYNAMIC+0x468>
  81674a:	movb   $0x0,0x98(%rbx)
  816751:	mov    0x60(%rbx),%rax
  816755:	lock decq (%rax)
  816759:	jne    816764 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1b4>
  81675b:	lea    0x60(%rbx),%rdi
  81675f:	call   812730 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  816764:	movw   $0x0,0x99(%rbx)
  81676d:	mov    0x40(%rbx),%rax
  816771:	lock decq (%rax)
  816775:	jne    816781 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1d1>
  816777:	lea    0x40(%rbx),%rdi
  81677b:	call   *0x668c77(%rip)        # e7f3f8 <_DYNAMIC+0x470>
  816781:	movb   $0x0,0x9b(%rbx)
  816788:	mov    0x38(%rbx),%rax
  81678c:	lock decq (%rax)
  816790:	jne    81679c <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1ec>
  816792:	lea    0x38(%rbx),%rdi
  816796:	call   *0x668c64(%rip)        # e7f400 <_DYNAMIC+0x478>
  81679c:	movb   $0x0,0x9c(%rbx)
  8167a3:	mov    0x30(%rbx),%rax
  8167a7:	lock decq (%rax)
  8167ab:	jne    8167b7 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x207>
  8167ad:	lea    0x30(%rbx),%rdi
  8167b1:	call   *0x668c51(%rip)        # e7f408 <_DYNAMIC+0x480>
  8167b7:	movb   $0x0,0x9d(%rbx)
  8167be:	mov    %r14,%rdi
  8167c1:	call   e2bd40 <_Unwind_Resume@plt>
  8167c6:	call   *0x668a0c(%rip)        # e7f1d8 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}> bytes=64 frame=8

/tmp/gpui-legacy-coverage-codegen/legacy277/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008167d0 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}>>:
  8167d0:	push   %rbx
  8167d1:	movzbl 0x20(%rdi),%eax
  8167d5:	cmp    $0x3,%eax
  8167d8:	je     8167f3 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}>+0x23>
  8167da:	cmp    $0x4,%eax
  8167dd:	jne    816800 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}>+0x30>
  8167df:	mov    %rdi,%rbx
  8167e2:	add    $0x28,%rdi
  8167e6:	call   8165b0 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>>
  8167eb:	movw   $0x0,0x21(%rbx)
  8167f1:	pop    %rbx
  8167f2:	ret
  8167f3:	add    $0x160,%rdi
  8167fa:	pop    %rbx
  8167fb:	jmp    8164d0 <core::ptr::drop_glue::<<wgpu::api::adapter::Adapter>::request_device::{closure#0}>>
  816800:	pop    %rbx
  816801:	ret
  816802:	movw   $0x0,0x21(%rbx)
  816808:	mov    %rax,%rdi
  81680b:	call   e2bd40 <_Unwind_Resume@plt>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext> bytes=191 frame=24

/tmp/gpui-legacy-coverage-codegen/legacy277/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000816cf0 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>>:
  816cf0:	push   %r14
  816cf2:	push   %rbx
  816cf3:	push   %rax
  816cf4:	mov    %rdi,%rbx
  816cf7:	mov    (%rdi),%rax
  816cfa:	lock decq (%rax)
  816cfe:	jne    816d09 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x19>
  816d00:	mov    %rbx,%rdi
  816d03:	call   *0x6686ff(%rip)        # e7f408 <_DYNAMIC+0x480>
  816d09:	mov    0x8(%rbx),%rax
  816d0d:	lock decq (%rax)
  816d11:	jne    816d1d <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x2d>
  816d13:	lea    0x8(%rbx),%rdi
  816d17:	call   *0x6686e3(%rip)        # e7f400 <_DYNAMIC+0x478>
  816d1d:	mov    0x10(%rbx),%rax
  816d21:	lock decq (%rax)
  816d25:	jne    816d30 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x40>
  816d27:	lea    0x10(%rbx),%rdi
  816d2b:	call   812730 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  816d30:	mov    0x18(%rbx),%rax
  816d34:	lock decq (%rax)
  816d38:	jne    816d4e <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x5e>
  816d3a:	add    $0x18,%rbx
  816d3e:	mov    %rbx,%rdi
  816d41:	add    $0x8,%rsp
  816d45:	pop    %rbx
  816d46:	pop    %r14
  816d48:	jmp    *0x6686a2(%rip)        # e7f3f0 <_DYNAMIC+0x468>
  816d4e:	add    $0x8,%rsp
  816d52:	pop    %rbx
  816d53:	pop    %r14
  816d55:	ret
  816d56:	mov    %rax,%r14
  816d59:	jmp    816d8a <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x9a>
  816d5b:	mov    %rax,%r14
  816d5e:	jmp    816d77 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x87>
  816d60:	mov    %rax,%r14
  816d63:	mov    0x8(%rbx),%rax
  816d67:	lock decq (%rax)
  816d6b:	jne    816d77 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x87>
  816d6d:	lea    0x8(%rbx),%rdi
  816d71:	call   *0x668689(%rip)        # e7f400 <_DYNAMIC+0x478>
  816d77:	mov    0x10(%rbx),%rax
  816d7b:	lock decq (%rax)
  816d7f:	jne    816d8a <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x9a>
  816d81:	lea    0x10(%rbx),%rdi
  816d85:	call   812730 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  816d8a:	mov    0x18(%rbx),%rax
  816d8e:	lock decq (%rax)
  816d92:	jne    816da1 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0xb1>
  816d94:	add    $0x18,%rbx
  816d98:	mov    %rbx,%rdi
  816d9b:	call   *0x66864f(%rip)        # e7f3f0 <_DYNAMIC+0x468>
  816da1:	mov    %r14,%rdi
  816da4:	call   e2bd40 <_Unwind_Resume@plt>
  816da9:	call   *0x668429(%rip)        # e7f1d8 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::RendererState> bytes=1253 frame=24

/tmp/gpui-legacy-coverage-codegen/legacy277/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000816db0 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>>:
  816db0:	push   %r14
  816db2:	push   %rbx
  816db3:	push   %rax
  816db4:	mov    %rdi,%rbx
  816db7:	mov    0x228(%rdi),%rax
  816dbe:	lock decq (%rax)
  816dc2:	jne    816dd1 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x21>
  816dc4:	lea    0x228(%rbx),%rdi
  816dcb:	call   *0x66861f(%rip)        # e7f3f0 <_DYNAMIC+0x468>
  816dd1:	mov    0x230(%rbx),%rax
  816dd8:	lock decq (%rax)
  816ddc:	jne    816deb <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3b>
  816dde:	lea    0x230(%rbx),%rdi
  816de5:	call   *0x6686a5(%rip)        # e7f490 <_DYNAMIC+0x508>
  816deb:	mov    0x238(%rbx),%rax
  816df2:	lock decq (%rax)
  816df6:	jne    816e05 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x55>
  816df8:	lea    0x238(%rbx),%rdi
  816dff:	call   *0x668693(%rip)        # e7f498 <_DYNAMIC+0x510>
  816e05:	mov    0x258(%rbx),%rax
  816e0c:	lock decq (%rax)
  816e10:	jne    816e1f <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x6f>
  816e12:	lea    0x258(%rbx),%rdi
  816e19:	call   *0x668671(%rip)        # e7f490 <_DYNAMIC+0x508>
  816e1f:	mov    0x260(%rbx),%rax
  816e26:	lock decq (%rax)
  816e2a:	jne    816e39 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x89>
  816e2c:	lea    0x260(%rbx),%rdi
  816e33:	call   *0x66865f(%rip)        # e7f498 <_DYNAMIC+0x510>
  816e39:	mov    0x280(%rbx),%rax
  816e40:	lock decq (%rax)
  816e44:	jne    816e53 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xa3>
  816e46:	lea    0x280(%rbx),%rdi
  816e4d:	call   *0x66863d(%rip)        # e7f490 <_DYNAMIC+0x508>
  816e53:	mov    0x288(%rbx),%rax
  816e5a:	lock decq (%rax)
  816e5e:	jne    816e6d <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xbd>
  816e60:	lea    0x288(%rbx),%rdi
  816e67:	call   *0x66862b(%rip)        # e7f498 <_DYNAMIC+0x510>
  816e6d:	mov    0x2a8(%rbx),%rax
  816e74:	lock decq (%rax)
  816e78:	jne    816e87 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xd7>
  816e7a:	lea    0x2a8(%rbx),%rdi
  816e81:	call   *0x668609(%rip)        # e7f490 <_DYNAMIC+0x508>
  816e87:	mov    0x2b0(%rbx),%rax
  816e8e:	lock decq (%rax)
  816e92:	jne    816ea1 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xf1>
  816e94:	lea    0x2b0(%rbx),%rdi
  816e9b:	call   *0x6685f7(%rip)        # e7f498 <_DYNAMIC+0x510>
  816ea1:	mov    0x2d0(%rbx),%rax
  816ea8:	lock decq (%rax)
  816eac:	jne    816ebb <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x10b>
  816eae:	lea    0x2d0(%rbx),%rdi
  816eb5:	call   *0x6685d5(%rip)        # e7f490 <_DYNAMIC+0x508>
  816ebb:	mov    0x2d8(%rbx),%rax
  816ec2:	lock decq (%rax)
  816ec6:	jne    816ed5 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x125>
  816ec8:	lea    0x2d8(%rbx),%rdi
  816ecf:	call   *0x6685c3(%rip)        # e7f498 <_DYNAMIC+0x510>
  816ed5:	lea    0x78(%rbx),%rdi
  816ed9:	call   8172a0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  816ede:	mov    0x328(%rbx),%r14
  816ee5:	test   %r14,%r14
  816ee8:	je     816f47 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x197>
  816eea:	mov    (%r14),%rsi
  816eed:	test   %rsi,%rsi
  816ef0:	je     816f05 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x155>
  816ef2:	mov    0x8(%r14),%rdi
  816ef6:	shl    $0x3,%rsi
  816efa:	mov    $0x8,%edx
  816eff:	call   *0x6682cb(%rip)        # e7f1d0 <_DYNAMIC+0x248>
  816f05:	mov    0x20(%r14),%rsi
  816f09:	test   %rsi,%rsi
  816f0c:	je     816f34 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x184>
  816f0e:	mov    %rsi,%rax
  816f11:	shl    $0x4,%rax
  816f15:	add    %rax,%rsi
  816f18:	add    $0x21,%rsi
  816f1c:	je     816f34 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x184>
  816f1e:	mov    0x18(%r14),%rdi
  816f22:	sub    %rax,%rdi
  816f25:	add    $0xfffffffffffffff0,%rdi
  816f29:	mov    $0x10,%edx
  816f2e:	call   *0x66829c(%rip)        # e7f1d0 <_DYNAMIC+0x248>
  816f34:	mov    $0x80,%esi
  816f39:	mov    $0x8,%edx
  816f3e:	mov    %r14,%rdi
  816f41:	call   *0x668289(%rip)        # e7f1d0 <_DYNAMIC+0x248>
  816f47:	mov    (%rbx),%rsi
  816f4a:	test   %rsi,%rsi
  816f4d:	je     816f62 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x1b2>
  816f4f:	mov    0x8(%rbx),%rdi
  816f53:	shl    $0x4,%rsi
  816f57:	mov    $0x4,%edx
  816f5c:	call   *0x66826e(%rip)        # e7f1d0 <_DYNAMIC+0x248>
  816f62:	mov    0x18(%rbx),%rsi
  816f66:	test   %rsi,%rsi
  816f69:	je     816f7e <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x1ce>
  816f6b:	mov    0x20(%rbx),%rdi
  816f6f:	shl    $0x3,%rsi
  816f73:	mov    $0x4,%edx
  816f78:	call   *0x668252(%rip)        # e7f1d0 <_DYNAMIC+0x248>
  816f7e:	mov    0x30(%rbx),%rsi
  816f82:	test   %rsi,%rsi
  816f85:	je     816f9a <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x1ea>
  816f87:	mov    0x38(%rbx),%rdi
  816f8b:	shl    $0x2,%rsi
  816f8f:	mov    $0x4,%edx
  816f94:	call   *0x668236(%rip)        # e7f1d0 <_DYNAMIC+0x248>
  816f9a:	mov    0x48(%rbx),%rsi
  816f9e:	test   %rsi,%rsi
  816fa1:	je     816fb6 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x206>
  816fa3:	mov    0x50(%rbx),%rdi
  816fa7:	shl    $0x2,%rsi
  816fab:	mov    $0x4,%edx
  816fb0:	call   *0x66821a(%rip)        # e7f1d0 <_DYNAMIC+0x248>
  816fb6:	mov    0x60(%rbx),%rsi
  816fba:	test   %rsi,%rsi
  816fbd:	je     816fd2 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x222>
  816fbf:	mov    0x68(%rbx),%rdi
  816fc3:	shl    $0x5,%rsi
  816fc7:	mov    $0x4,%edx
  816fcc:	call   *0x6681fe(%rip)        # e7f1d0 <_DYNAMIC+0x248>
  816fd2:	mov    0x300(%rbx),%rsi
  816fd9:	test   %rsi,%rsi
  816fdc:	je     81700c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x25c>
  816fde:	lea    (%rsi,%rsi,8),%rax
  816fe2:	lea    0x33(,%rax,4),%rax
  816fea:	and    $0xfffffffffffffff0,%rax
  816fee:	add    %rax,%rsi
  816ff1:	add    $0x11,%rsi
  816ff5:	je     81700c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x25c>
  816ff7:	mov    0x2f8(%rbx),%rdi
  816ffe:	sub    %rax,%rdi
  817001:	mov    $0x10,%edx
  817006:	call   *0x6681c4(%rip)        # e7f1d0 <_DYNAMIC+0x248>
  81700c:	mov    0x330(%rbx),%rax
  817013:	test   %rax,%rax
  817016:	je     817035 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x285>
  817018:	lock decq (%rax)
  81701c:	jne    817035 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x285>
  81701e:	add    $0x330,%rbx
  817025:	mov    %rbx,%rdi
  817028:	add    $0x8,%rsp
  81702c:	pop    %rbx
  81702d:	pop    %r14
  81702f:	jmp    *0x66846b(%rip)        # e7f4a0 <_DYNAMIC+0x518>
  817035:	add    $0x8,%rsp
  817039:	pop    %rbx
  81703a:	pop    %r14
  81703c:	ret
  81703d:	mov    %rax,%r14
  817040:	jmp    81716c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3bc>
  817045:	mov    %rax,%r14
  817048:	mov    0x2d8(%rbx),%rax
  81704f:	lock decq (%rax)
  817053:	jne    81716c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3bc>
  817059:	lea    0x2d8(%rbx),%rdi
  817060:	call   *0x668432(%rip)        # e7f498 <_DYNAMIC+0x510>
  817066:	jmp    81716c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3bc>
  81706b:	call   *0x668167(%rip)        # e7f1d8 <_DYNAMIC+0x250>
  817071:	mov    %rax,%r14
  817074:	jmp    817160 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3b0>
  817079:	mov    %rax,%r14
  81707c:	mov    0x2b0(%rbx),%rax
  817083:	lock decq (%rax)
  817087:	jne    817160 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3b0>
  81708d:	lea    0x2b0(%rbx),%rdi
  817094:	call   *0x6683fe(%rip)        # e7f498 <_DYNAMIC+0x510>
  81709a:	jmp    817160 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3b0>
  81709f:	call   *0x668133(%rip)        # e7f1d8 <_DYNAMIC+0x250>
  8170a5:	mov    %rax,%r14
  8170a8:	jmp    817154 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3a4>
  8170ad:	mov    %rax,%r14
  8170b0:	mov    0x288(%rbx),%rax
  8170b7:	lock decq (%rax)
  8170bb:	jne    817154 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3a4>
  8170c1:	lea    0x288(%rbx),%rdi
  8170c8:	call   *0x6683ca(%rip)        # e7f498 <_DYNAMIC+0x510>
  8170ce:	jmp    817154 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3a4>
  8170d3:	call   *0x6680ff(%rip)        # e7f1d8 <_DYNAMIC+0x250>
  8170d9:	mov    %rax,%r14
  8170dc:	jmp    817148 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x398>
  8170de:	mov    %rax,%r14
  8170e1:	mov    0x260(%rbx),%rax
  8170e8:	lock decq (%rax)
  8170ec:	jne    817148 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x398>
  8170ee:	lea    0x260(%rbx),%rdi
  8170f5:	call   *0x66839d(%rip)        # e7f498 <_DYNAMIC+0x510>
  8170fb:	jmp    817148 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x398>
  8170fd:	call   *0x6680d5(%rip)        # e7f1d8 <_DYNAMIC+0x250>
  817103:	mov    %rax,%r14
  817106:	jmp    81713c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x38c>
  817108:	mov    %rax,%r14
  81710b:	mov    0x238(%rbx),%rax
  817112:	lock decq (%rax)
  817116:	jne    81713c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x38c>
  817118:	lea    0x238(%rbx),%rdi
  81711f:	call   *0x668373(%rip)        # e7f498 <_DYNAMIC+0x510>
  817125:	jmp    81713c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x38c>
  817127:	call   *0x6680ab(%rip)        # e7f1d8 <_DYNAMIC+0x250>
  81712d:	mov    %rax,%r14
  817130:	lea    0x230(%rbx),%rdi
  817137:	call   8173a0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81713c:	lea    0x258(%rbx),%rdi
  817143:	call   8173a0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  817148:	lea    0x280(%rbx),%rdi
  81714f:	call   8173a0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  817154:	lea    0x2a8(%rbx),%rdi
  81715b:	call   8173a0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  817160:	lea    0x2d0(%rbx),%rdi
  817167:	call   8173a0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81716c:	lea    0x78(%rbx),%rdi
  817170:	call   8172a0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  817175:	mov    0x328(%rbx),%rdi
  81717c:	call   815ef0 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>
  817181:	mov    (%rbx),%rsi
  817184:	test   %rsi,%rsi
  817187:	jne    817202 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x452>
  817189:	mov    0x18(%rbx),%rsi
  81718d:	test   %rsi,%rsi
  817190:	jne    817222 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x472>
  817196:	mov    0x30(%rbx),%rsi
  81719a:	test   %rsi,%rsi
  81719d:	jne    817242 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x492>
  8171a3:	mov    0x48(%rbx),%rsi
  8171a7:	test   %rsi,%rsi
  8171aa:	jne    817262 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x4b2>
  8171b0:	mov    0x60(%rbx),%rsi
  8171b4:	test   %rsi,%rsi
  8171b7:	je     8171cc <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x41c>
  8171b9:	mov    0x68(%rbx),%rdi
  8171bd:	shl    $0x5,%rsi
  8171c1:	mov    $0x4,%edx
  8171c6:	call   *0x668004(%rip)        # e7f1d0 <_DYNAMIC+0x248>
  8171cc:	lea    0x2f8(%rbx),%rdi
  8171d3:	call   8196b0 <<hashbrown::raw::RawTable<([u32; 8], u32)> as core::ops::drop::Drop>::drop>
  8171d8:	mov    0x330(%rbx),%rax
  8171df:	test   %rax,%rax
  8171e2:	je     8171fa <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x44a>
  8171e4:	lock decq (%rax)
  8171e8:	jne    8171fa <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x44a>
  8171ea:	add    $0x330,%rbx
  8171f1:	mov    %rbx,%rdi
  8171f4:	call   *0x6682a6(%rip)        # e7f4a0 <_DYNAMIC+0x518>
  8171fa:	mov    %r14,%rdi
  8171fd:	call   e2bd40 <_Unwind_Resume@plt>
  817202:	mov    0x8(%rbx),%rdi
  817206:	shl    $0x4,%rsi
  81720a:	mov    $0x4,%edx
  81720f:	call   *0x667fbb(%rip)        # e7f1d0 <_DYNAMIC+0x248>
  817215:	mov    0x18(%rbx),%rsi
  817219:	test   %rsi,%rsi
  81721c:	je     817196 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3e6>
  817222:	mov    0x20(%rbx),%rdi
  817226:	shl    $0x3,%rsi
  81722a:	mov    $0x4,%edx
  81722f:	call   *0x667f9b(%rip)        # e7f1d0 <_DYNAMIC+0x248>
  817235:	mov    0x30(%rbx),%rsi
  817239:	test   %rsi,%rsi
  81723c:	je     8171a3 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3f3>
  817242:	mov    0x38(%rbx),%rdi
  817246:	shl    $0x2,%rsi
  81724a:	mov    $0x4,%edx
  81724f:	call   *0x667f7b(%rip)        # e7f1d0 <_DYNAMIC+0x248>
  817255:	mov    0x48(%rbx),%rsi
  817259:	test   %rsi,%rsi
  81725c:	je     8171b0 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x400>
  817262:	mov    0x50(%rbx),%rdi
  817266:	shl    $0x2,%rsi
  81726a:	mov    $0x4,%edx
  81726f:	call   *0x667f5b(%rip)        # e7f1d0 <_DYNAMIC+0x248>
  817275:	mov    0x60(%rbx),%rsi
  817279:	test   %rsi,%rsi
  81727c:	jne    8171b9 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x409>
  817282:	jmp    8171cc <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x41c>
  817287:	call   *0x667f4b(%rip)        # e7f1d8 <_DYNAMIC+0x250>
  81728d:	mov    %rax,%r14
  817290:	jmp    817175 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3c5>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Atlas> bytes=210 frame=24

/tmp/gpui-legacy-coverage-codegen/legacy277/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008172a0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>:
  8172a0:	push   %r14
  8172a2:	push   %rbx
  8172a3:	push   %rax
  8172a4:	mov    %rdi,%rbx
  8172a7:	mov    (%rdi),%rax
  8172aa:	lock decq (%rax)
  8172ae:	jne    8172b9 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x19>
  8172b0:	mov    %rbx,%rdi
  8172b3:	call   *0x6681b7(%rip)        # e7f470 <_DYNAMIC+0x4e8>
  8172b9:	mov    0x50(%rbx),%rax
  8172bd:	lock decq (%rax)
  8172c1:	jne    8172cd <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x2d>
  8172c3:	lea    0x50(%rbx),%rdi
  8172c7:	call   *0x66819b(%rip)        # e7f468 <_DYNAMIC+0x4e0>
  8172cd:	mov    0x58(%rbx),%rax
  8172d1:	lock decq (%rax)
  8172d5:	jne    8172e1 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x41>
  8172d7:	lea    0x58(%rbx),%rdi
  8172db:	call   *0x66818f(%rip)        # e7f470 <_DYNAMIC+0x4e8>
  8172e1:	mov    0xb0(%rbx),%rsi
  8172e8:	test   %rsi,%rsi
  8172eb:	je     81731d <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  8172ed:	mov    %rsi,%rax
  8172f0:	shl    $0x5,%rax
  8172f4:	add    %rax,%rsi
  8172f7:	add    $0x31,%rsi
  8172fb:	je     81731d <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  8172fd:	mov    0xa8(%rbx),%rdi
  817304:	sub    %rax,%rdi
  817307:	add    $0xffffffffffffffe0,%rdi
  81730b:	mov    $0x10,%edx
  817310:	add    $0x8,%rsp
  817314:	pop    %rbx
  817315:	pop    %r14
  817317:	jmp    *0x667eb3(%rip)        # e7f1d0 <_DYNAMIC+0x248>
  81731d:	add    $0x8,%rsp
  817321:	pop    %rbx
  817322:	pop    %r14
  817324:	ret
  817325:	mov    %rax,%r14
  817328:	jmp    817355 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  81732a:	mov    %rax,%r14
  81732d:	mov    0x58(%rbx),%rax
  817331:	lock decq (%rax)
  817335:	jne    817355 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  817337:	lea    0x58(%rbx),%rdi
  81733b:	call   *0x66812f(%rip)        # e7f470 <_DYNAMIC+0x4e8>
  817341:	jmp    817355 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  817343:	call   *0x667e8f(%rip)        # e7f1d8 <_DYNAMIC+0x250>
  817349:	mov    %rax,%r14
  81734c:	lea    0x50(%rbx),%rdi
  817350:	call   8174a0 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  817355:	add    $0xa8,%rbx
  81735c:	mov    %rbx,%rdi
  81735f:	call   8196f0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>
  817364:	mov    %r14,%rdi
  817367:	call   e2bd40 <_Unwind_Resume@plt>
  81736c:	call   *0x667e66(%rip)        # e7f1d8 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Error> bytes=30 frame=0

/tmp/gpui-legacy-coverage-codegen/legacy277/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000817380 <core::ptr::drop_glue::<gpui_gpu::renderer::Error>>:
  817380:	cmpl   $0x1,(%rdi)
  817383:	ja     81739d <core::ptr::drop_glue::<gpui_gpu::renderer::Error>+0x1d>
  817385:	mov    0x8(%rdi),%rsi
  817389:	test   %rsi,%rsi
  81738c:	je     81739d <core::ptr::drop_glue::<gpui_gpu::renderer::Error>+0x1d>
  81738e:	mov    0x10(%rdi),%rdi
  817392:	mov    $0x1,%edx
  817397:	jmp    *0x667e33(%rip)        # e7f1d0 <_DYNAMIC+0x248>
  81739d:	ret

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Buffer> bytes=103 frame=24

/tmp/gpui-legacy-coverage-codegen/legacy277/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008173a0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>:
  8173a0:	push   %r14
  8173a2:	push   %rbx
  8173a3:	push   %rax
  8173a4:	mov    %rdi,%rbx
  8173a7:	mov    (%rdi),%rax
  8173aa:	lock decq (%rax)
  8173ae:	jne    8173b9 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x19>
  8173b0:	mov    %rbx,%rdi
  8173b3:	call   *0x6680d7(%rip)        # e7f490 <_DYNAMIC+0x508>
  8173b9:	mov    0x8(%rbx),%rax
  8173bd:	lock decq (%rax)
  8173c1:	jne    8173d7 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x37>
  8173c3:	add    $0x8,%rbx
  8173c7:	mov    %rbx,%rdi
  8173ca:	add    $0x8,%rsp
  8173ce:	pop    %rbx
  8173cf:	pop    %r14
  8173d1:	jmp    *0x6680c1(%rip)        # e7f498 <_DYNAMIC+0x510>
  8173d7:	add    $0x8,%rsp
  8173db:	pop    %rbx
  8173dc:	pop    %r14
  8173de:	ret
  8173df:	mov    %rax,%r14
  8173e2:	mov    0x8(%rbx),%rax
  8173e6:	lock decq (%rax)
  8173ea:	jne    8173f9 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x59>
  8173ec:	add    $0x8,%rbx
  8173f0:	mov    %rbx,%rdi
  8173f3:	call   *0x66809f(%rip)        # e7f498 <_DYNAMIC+0x510>
  8173f9:	mov    %r14,%rdi
  8173fc:	call   e2bd40 <_Unwind_Resume@plt>
  817401:	call   *0x667dd1(%rip)        # e7f1d8 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::Error as core::fmt::Debug>::fmt bytes=304 frame=24

/tmp/gpui-legacy-coverage-codegen/legacy277/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000817d70 <<gpui_gpu::renderer::Error as core::fmt::Debug>::fmt>:
  817d70:	sub    $0x18,%rsp
  817d74:	mov    %rsi,%rax
  817d77:	mov    (%rdi),%ecx
  817d79:	lea    -0x746f80(%rip),%rdx        # d0e00 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0xbb8>
  817d80:	movslq (%rdx,%rcx,4),%rcx
  817d84:	add    %rdx,%rcx
  817d87:	jmp    *%rcx
  817d89:	add    $0x8,%rdi
  817d8d:	mov    %rdi,0x10(%rsp)
  817d92:	lea    -0x743a0f(%rip),%rsi        # d438a <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x4142>
  817d99:	jmp    817e28 <<gpui_gpu::renderer::Error as core::fmt::Debug>::fmt+0xb8>
  817d9e:	lea    -0x7439f2(%rip),%rsi        # d43b3 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x416b>
  817da5:	mov    $0x13,%edx
  817daa:	mov    %rax,%rdi
  817dad:	add    $0x18,%rsp
  817db1:	jmp    *0x667509(%rip)        # e7f2c0 <_DYNAMIC+0x338>
  817db7:	add    $0x4,%rdi
  817dbb:	mov    %rdi,0x10(%rsp)
  817dc0:	lea    -0x743a31(%rip),%rsi        # d4396 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x414e>
  817dc7:	lea    0x61587a(%rip),%r8        # e2d648 <__frame_dummy_init_array_entry+0x8c8>
  817dce:	lea    0x10(%rsp),%rcx
  817dd3:	mov    $0x11,%edx
  817dd8:	mov    %rax,%rdi
  817ddb:	call   *0x6674e7(%rip)        # e7f2c8 <_DYNAMIC+0x340>
  817de1:	add    $0x18,%rsp
  817de5:	ret
  817de6:	lea    -0x743a46(%rip),%rsi        # d43a7 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x415f>
  817ded:	mov    $0xc,%edx
  817df2:	mov    %rax,%rdi
  817df5:	add    $0x18,%rsp
  817df9:	jmp    *0x6674c1(%rip)        # e7f2c0 <_DYNAMIC+0x338>
  817dff:	lea    -0x743a2a(%rip),%rsi        # d43dc <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x4194>
  817e06:	mov    $0x9,%edx
  817e0b:	mov    %rax,%rdi
  817e0e:	add    $0x18,%rsp
  817e12:	jmp    *0x6674a8(%rip)        # e7f2c0 <_DYNAMIC+0x338>
  817e18:	add    $0x8,%rdi
  817e1c:	mov    %rdi,0x10(%rsp)
  817e21:	lea    -0x743a98(%rip),%rsi        # d4390 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x4148>
  817e28:	lea    0x6157f9(%rip),%r8        # e2d628 <__frame_dummy_init_array_entry+0x8a8>
  817e2f:	lea    0x10(%rsp),%rcx
  817e34:	mov    $0x6,%edx
  817e39:	mov    %rax,%rdi
  817e3c:	call   *0x667486(%rip)        # e7f2c8 <_DYNAMIC+0x340>
  817e42:	add    $0x18,%rsp
  817e46:	ret
  817e47:	add    $0x8,%rdi
  817e4b:	mov    %rdi,0x10(%rsp)
  817e50:	lea    0x615811(%rip),%rcx        # e2d668 <__frame_dummy_init_array_entry+0x8e8>
  817e57:	mov    %rcx,(%rsp)
  817e5b:	lea    -0x743a9c(%rip),%rsi        # d43c6 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x417e>
  817e62:	lea    -0x76905d(%rip),%rcx        # aee0c <anon.a16d5d421a76dfd8c37a17b53540311d.67.llvm.14190004212411149437+0x20>
  817e69:	lea    0x10(%rsp),%r9
  817e6e:	mov    $0x9,%edx
  817e73:	mov    $0x4,%r8d
  817e79:	mov    %rax,%rdi
  817e7c:	call   *0x66762e(%rip)        # e7f4b0 <_DYNAMIC+0x528>
  817e82:	add    $0x18,%rsp
  817e86:	ret
  817e87:	lea    -0x743abf(%rip),%rsi        # d43cf <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x4187>
  817e8e:	mov    $0xd,%edx
  817e93:	mov    %rax,%rdi
  817e96:	add    $0x18,%rsp
  817e9a:	jmp    *0x667420(%rip)        # e7f2c0 <_DYNAMIC+0x338>

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop bytes=47 frame=0

/tmp/gpui-legacy-coverage-codegen/legacy277/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008196f0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>:
  8196f0:	mov    0x8(%rdi),%rsi
  8196f4:	test   %rsi,%rsi
  8196f7:	je     81971e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  8196f9:	mov    %rsi,%rax
  8196fc:	shl    $0x5,%rax
  819700:	add    %rax,%rsi
  819703:	add    $0x31,%rsi
  819707:	je     81971e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  819709:	mov    (%rdi),%rdi
  81970c:	sub    %rax,%rdi
  81970f:	add    $0xffffffffffffffe0,%rdi
  819713:	mov    $0x10,%edx
  819718:	jmp    *0x665ab2(%rip)        # e7f1d0 <_DYNAMIC+0x248>
  81971e:	ret

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop bytes=47 frame=0

/tmp/gpui-legacy-coverage-codegen/legacy277/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000819720 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop>:
  819720:	mov    0x8(%rdi),%rsi
  819724:	test   %rsi,%rsi
  819727:	je     81974e <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop+0x2e>
  819729:	mov    %rsi,%rax
  81972c:	shl    $0x4,%rax
  819730:	add    %rax,%rsi
  819733:	add    $0x21,%rsi
  819737:	je     81974e <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop+0x2e>
  819739:	mov    (%rdi),%rdi
  81973c:	sub    %rax,%rdi
  81973f:	add    $0xfffffffffffffff0,%rdi
  819743:	mov    $0x10,%edx
  819748:	jmp    *0x665a82(%rip)        # e7f1d0 <_DYNAMIC+0x248>
  81974e:	ret

FUNCTION <core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3: usize], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}> bytes=325 frame=72

/tmp/gpui-legacy-coverage-codegen/legacy277/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081afe0 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>>:
  81afe0:	push   %r14
  81afe2:	push   %rbx
  81afe3:	sub    $0x38,%rsp
  81afe7:	mov    %rdi,%rbx
  81afea:	cmpq   $0x0,(%rsi)
  81afee:	je     81b0f8 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x118>
  81aff4:	movdqu (%rsi),%xmm0
  81aff8:	movdqu 0x10(%rsi),%xmm1
  81affd:	movdqu 0x20(%rsi),%xmm2
  81b002:	movdqa %xmm2,0x20(%rsp)
  81b008:	movdqa %xmm1,0x10(%rsp)
  81b00e:	movdqa %xmm0,(%rsp)
  81b013:	cmpq   $0x0,0x18(%rcx)
  81b018:	je     81b10c <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x12c>
  81b01e:	lea    0x10(%rsp),%rsi
  81b023:	lea    0x20(%rcx),%rdi
  81b027:	mov    %rcx,%r14
  81b02a:	call   821710 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  81b02f:	mov    %rax,%rsi
  81b032:	shr    $0x39,%rsi
  81b036:	mov    (%r14),%rcx
  81b039:	mov    0x8(%r14),%rdx
  81b03d:	movd   %esi,%xmm0
  81b041:	punpcklbw %xmm0,%xmm0
  81b045:	pshuflw $0x0,%xmm0,%xmm0
  81b04a:	pshufd $0x44,%xmm0,%xmm0
  81b04f:	mov    0x10(%rsp),%rsi
  81b054:	movzwl 0x1c(%rsp),%edi
  81b059:	xor    %r8d,%r8d
  81b05c:	mov    0x18(%rsp),%r9d
  81b061:	pcmpeqd %xmm1,%xmm1
  81b065:	and    %rdx,%rax
  81b068:	movdqu (%rcx,%rax,1),%xmm2
  81b06d:	movdqa %xmm2,%xmm3
  81b071:	pcmpeqb %xmm0,%xmm3
  81b075:	pmovmskb %xmm3,%r10d
  81b07a:	test   %r10d,%r10d
  81b07d:	je     81b0c0 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xe0>
  81b07f:	tzcnt  %r10d,%r14d
  81b084:	add    %rax,%r14
  81b087:	and    %rdx,%r14
  81b08a:	shl    $0x5,%r14
  81b08e:	mov    %rcx,%r11
  81b091:	sub    %r14,%r11
  81b094:	cmp    -0x20(%r11),%rsi
  81b098:	jne    81b0a7 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xc7>
  81b09a:	cmp    -0x14(%r11),%di
  81b09f:	jne    81b0a7 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xc7>
  81b0a1:	cmp    -0x18(%r11),%r9d
  81b0a5:	je     81b0db <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xfb>
  81b0a7:	lea    -0x1(%r10),%r11d
  81b0ab:	and    %r10w,%r11w
  81b0af:	mov    %r11d,%r10d
  81b0b2:	jne    81b07f <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x9f>
  81b0b4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  81b0c0:	pcmpeqb %xmm1,%xmm2
  81b0c4:	pmovmskb %xmm2,%r10d
  81b0c9:	test   %r10d,%r10d
  81b0cc:	jne    81b10c <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x12c>
  81b0ce:	add    %r8,%rax
  81b0d1:	add    $0x10,%rax
  81b0d5:	add    $0x10,%r8
  81b0d9:	jmp    81b065 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x85>
  81b0db:	mov    -0x4(%r11),%eax
  81b0df:	shl    $0x10,%eax
  81b0e2:	or     -0x8(%r11),%eax
  81b0e6:	mov    -0x10(%r11),%rcx
  81b0ea:	mov    %rcx,(%rbx)
  81b0ed:	mov    %eax,0x8(%rbx)
  81b0f0:	add    $0x38,%rsp
  81b0f4:	pop    %rbx
  81b0f5:	pop    %r14
  81b0f7:	ret
  81b0f8:	mov    0x8(%rdx),%eax
  81b0fb:	mov    %eax,0x8(%rbx)
  81b0fe:	mov    (%rdx),%rax
  81b101:	mov    %rax,(%rbx)
  81b104:	add    $0x38,%rsp
  81b108:	pop    %rbx
  81b109:	pop    %r14
  81b10b:	ret
  81b10c:	lea    -0x746951(%rip),%rdi        # d47c2 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x12c>
  81b113:	lea    0x612986(%rip),%rdx        # e2daa0 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x68>
  81b11a:	mov    $0x16,%esi
  81b11f:	call   *0x664403(%rip)        # e7f528 <_DYNAMIC+0x5a0>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Atlas> bytes=210 frame=24

/tmp/gpui-legacy-coverage-codegen/legacy277/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081b420 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>:
  81b420:	push   %r14
  81b422:	push   %rbx
  81b423:	push   %rax
  81b424:	mov    %rdi,%rbx
  81b427:	mov    (%rdi),%rax
  81b42a:	lock decq (%rax)
  81b42e:	jne    81b439 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x19>
  81b430:	mov    %rbx,%rdi
  81b433:	call   *0x664037(%rip)        # e7f470 <_DYNAMIC+0x4e8>
  81b439:	mov    0x50(%rbx),%rax
  81b43d:	lock decq (%rax)
  81b441:	jne    81b44d <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x2d>
  81b443:	lea    0x50(%rbx),%rdi
  81b447:	call   *0x66401b(%rip)        # e7f468 <_DYNAMIC+0x4e0>
  81b44d:	mov    0x58(%rbx),%rax
  81b451:	lock decq (%rax)
  81b455:	jne    81b461 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x41>
  81b457:	lea    0x58(%rbx),%rdi
  81b45b:	call   *0x66400f(%rip)        # e7f470 <_DYNAMIC+0x4e8>
  81b461:	mov    0xb0(%rbx),%rsi
  81b468:	test   %rsi,%rsi
  81b46b:	je     81b49d <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  81b46d:	mov    %rsi,%rax
  81b470:	shl    $0x5,%rax
  81b474:	add    %rax,%rsi
  81b477:	add    $0x31,%rsi
  81b47b:	je     81b49d <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  81b47d:	mov    0xa8(%rbx),%rdi
  81b484:	sub    %rax,%rdi
  81b487:	add    $0xffffffffffffffe0,%rdi
  81b48b:	mov    $0x10,%edx
  81b490:	add    $0x8,%rsp
  81b494:	pop    %rbx
  81b495:	pop    %r14
  81b497:	jmp    *0x663d33(%rip)        # e7f1d0 <_DYNAMIC+0x248>
  81b49d:	add    $0x8,%rsp
  81b4a1:	pop    %rbx
  81b4a2:	pop    %r14
  81b4a4:	ret
  81b4a5:	mov    %rax,%r14
  81b4a8:	jmp    81b4d5 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  81b4aa:	mov    %rax,%r14
  81b4ad:	mov    0x58(%rbx),%rax
  81b4b1:	lock decq (%rax)
  81b4b5:	jne    81b4d5 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  81b4b7:	lea    0x58(%rbx),%rdi
  81b4bb:	call   *0x663faf(%rip)        # e7f470 <_DYNAMIC+0x4e8>
  81b4c1:	jmp    81b4d5 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  81b4c3:	call   *0x663d0f(%rip)        # e7f1d8 <_DYNAMIC+0x250>
  81b4c9:	mov    %rax,%r14
  81b4cc:	lea    0x50(%rbx),%rdi
  81b4d0:	call   81bd70 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  81b4d5:	add    $0xa8,%rbx
  81b4dc:	mov    %rbx,%rdi
  81b4df:	call   824e40 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>
  81b4e4:	mov    %r14,%rdi
  81b4e7:	call   e2bd40 <_Unwind_Resume@plt>
  81b4ec:	call   *0x663ce6(%rip)        # e7f1d8 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Buffer> bytes=103 frame=24

/tmp/gpui-legacy-coverage-codegen/legacy277/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081b500 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>:
  81b500:	push   %r14
  81b502:	push   %rbx
  81b503:	push   %rax
  81b504:	mov    %rdi,%rbx
  81b507:	mov    (%rdi),%rax
  81b50a:	lock decq (%rax)
  81b50e:	jne    81b519 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x19>
  81b510:	mov    %rbx,%rdi
  81b513:	call   *0x663f77(%rip)        # e7f490 <_DYNAMIC+0x508>
  81b519:	mov    0x8(%rbx),%rax
  81b51d:	lock decq (%rax)
  81b521:	jne    81b537 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x37>
  81b523:	add    $0x8,%rbx
  81b527:	mov    %rbx,%rdi
  81b52a:	add    $0x8,%rsp
  81b52e:	pop    %rbx
  81b52f:	pop    %r14
  81b531:	jmp    *0x663f61(%rip)        # e7f498 <_DYNAMIC+0x510>
  81b537:	add    $0x8,%rsp
  81b53b:	pop    %rbx
  81b53c:	pop    %r14
  81b53e:	ret
  81b53f:	mov    %rax,%r14
  81b542:	mov    0x8(%rbx),%rax
  81b546:	lock decq (%rax)
  81b54a:	jne    81b559 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x59>
  81b54c:	add    $0x8,%rbx
  81b550:	mov    %rbx,%rdi
  81b553:	call   *0x663f3f(%rip)        # e7f498 <_DYNAMIC+0x510>
  81b559:	mov    %r14,%rdi
  81b55c:	call   e2bd40 <_Unwind_Resume@plt>
  81b561:	call   *0x663c71(%rip)        # e7f1d8 <_DYNAMIC+0x250>

FUNCTION gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}> bytes=611 frame=88

/tmp/gpui-legacy-coverage-codegen/legacy277/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081bea0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>>:
  81bea0:	push   %rbp
  81bea1:	push   %r15
  81bea3:	push   %r14
  81bea5:	push   %r13
  81bea7:	push   %r12
  81bea9:	push   %rbx
  81beaa:	sub    $0x28,%rsp
  81beae:	movss  0x8c(%rdi),%xmm3
  81beb6:	movss  -0x76cf02(%rip),%xmm0        # aefbc <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  81bebe:	movaps %xmm3,%xmm1
  81bec1:	subss  %xmm0,%xmm1
  81bec5:	cvttss2si %xmm1,%rax
  81beca:	cvttss2si %xmm3,%r8
  81becf:	mov    %r8,%rcx
  81bed2:	sar    $0x3f,%rcx
  81bed6:	and    %rax,%rcx
  81bed9:	or     %r8,%rcx
  81bedc:	xor    %r9d,%r9d
  81bedf:	xorps  %xmm1,%xmm1
  81bee2:	ucomiss %xmm1,%xmm3
  81bee5:	cmovb  %r9,%rcx
  81bee9:	movss  -0x76cf31(%rip),%xmm2        # aefc0 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  81bef1:	ucomiss %xmm2,%xmm3
  81bef4:	mov    $0xffffffffffffffff,%rax
  81befb:	cmova  %rax,%rcx
  81beff:	movss  0x94(%rdi),%xmm3
  81bf07:	mov    %rcx,%r8
  81bf0a:	shr    $0x4,%r8
  81bf0e:	movaps %xmm3,%xmm4
  81bf11:	subss  %xmm0,%xmm4
  81bf15:	cvttss2si %xmm4,%r10
  81bf1a:	cvttss2si %xmm3,%r11
  81bf1f:	mov    %r11,%rbx
  81bf22:	sar    $0x3f,%rbx
  81bf26:	and    %r10,%rbx
  81bf29:	or     %r11,%rbx
  81bf2c:	ucomiss %xmm1,%xmm3
  81bf2f:	cmovb  %r9,%rbx
  81bf33:	ucomiss %xmm2,%xmm3
  81bf36:	cmova  %rax,%rbx
  81bf3a:	mov    %rsi,0x18(%rsp)
  81bf3f:	lea    (%rcx,%rbx,1),%r11
  81bf43:	dec    %r11
  81bf46:	shr    $0x4,%r11
  81bf4a:	cmp    %r11,%r8
  81bf4d:	jbe    81bf5e <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xbe>
  81bf4f:	add    $0x28,%rsp
  81bf53:	pop    %rbx
  81bf54:	pop    %r12
  81bf56:	pop    %r13
  81bf58:	pop    %r14
  81bf5a:	pop    %r15
  81bf5c:	pop    %rbp
  81bf5d:	ret
  81bf5e:	movss  0x88(%rdi),%xmm3
  81bf66:	movaps %xmm3,%xmm4
  81bf69:	subss  %xmm0,%xmm4
  81bf6d:	cvttss2si %xmm4,%rsi
  81bf72:	cvttss2si %xmm3,%r9
  81bf77:	mov    %r9,%rcx
  81bf7a:	sar    $0x3f,%rcx
  81bf7e:	and    %rsi,%rcx
  81bf81:	or     %r9,%rcx
  81bf84:	xor    %r10d,%r10d
  81bf87:	ucomiss %xmm1,%xmm3
  81bf8a:	cmovb  %r10,%rcx
  81bf8e:	ucomiss %xmm2,%xmm3
  81bf91:	cmova  %rax,%rcx
  81bf95:	movss  0x90(%rdi),%xmm3
  81bf9d:	mov    %rcx,%r14
  81bfa0:	shr    $0x4,%r14
  81bfa4:	movaps %xmm3,%xmm4
  81bfa7:	subss  %xmm0,%xmm4
  81bfab:	cvttss2si %xmm4,%rsi
  81bfb0:	cvttss2si %xmm3,%rdi
  81bfb5:	mov    %rdi,%r9
  81bfb8:	sar    $0x3f,%r9
  81bfbc:	and    %rsi,%r9
  81bfbf:	or     %rdi,%r9
  81bfc2:	ucomiss %xmm1,%xmm3
  81bfc5:	cmovb  %r10,%r9
  81bfc9:	ucomiss %xmm2,%xmm3
  81bfcc:	cmova  %rax,%r9
  81bfd0:	lea    (%r9,%rcx,1),%rbx
  81bfd4:	dec    %rbx
  81bfd7:	shr    $0x4,%rbx
  81bfdb:	mov    %r14,0x10(%rsp)
  81bfe0:	cmp    %rbx,%r14
  81bfe3:	jbe    81c00d <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x16d>
  81bfe5:	data16 cs nopw 0x0(%rax,%rax,1)
  81bff0:	mov    %r8,%rax
  81bff3:	cmp    %r11,%r8
  81bff6:	adc    $0x0,%r8
  81bffa:	cmp    %r11,%rax
  81bffd:	jae    81bf4f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c003:	cmp    %r11,%r8
  81c006:	jbe    81bff0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x150>
  81c008:	jmp    81bf4f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c00d:	mov    (%rdx),%r14
  81c010:	mov    0x8(%rdx),%r15
  81c014:	mov    0x10(%rdx),%r12
  81c018:	mov    0x18(%rdx),%r13
  81c01c:	mov    0x20(%rdx),%rdx
  81c020:	mov    %r11,0x8(%rsp)
  81c025:	data16 cs nopw 0x0(%rax,%rax,1)
  81c030:	mov    %r8,%rbp
  81c033:	cmp    %r11,%r8
  81c036:	adc    $0x0,%r8
  81c03a:	mov    %rbp,0x20(%rsp)
  81c03f:	imul   0x18(%rsp),%rbp
  81c045:	mov    0x10(%rsp),%r9
  81c04a:	mov    %r9,%rsi
  81c04d:	nopl   (%rax)
  81c050:	cmp    %rbx,%r9
  81c053:	adc    $0x0,%rsi
  81c057:	lea    (%r9,%rbp,1),%rdi
  81c05b:	mov    0x10(%r14),%rax
  81c05f:	cmp    %rax,%rdi
  81c062:	jae    81c0d0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x230>
  81c064:	mov    0x8(%r14),%rcx
  81c068:	cmp    0x4(%rcx,%rdi,8),%r10d
  81c06d:	jo     81c0a5 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x205>
  81c06f:	mov    0x10(%r12),%rax
  81c074:	cmp    %rax,%rdi
  81c077:	jae    81c0e0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x240>
  81c079:	mov    0x8(%r12),%rax
  81c07e:	mov    0x0(%r13),%r11d
  81c082:	inc    %r11d
  81c085:	cmp    (%rax,%rdi,4),%r11d
  81c089:	jb     81c0a5 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x205>
  81c08b:	mov    (%rcx,%rdi,8),%eax
  81c08e:	dec    %eax
  81c090:	mov    %eax,(%rcx,%rdi,8)
  81c093:	mov    0x10(%r15),%rcx
  81c097:	cmp    %rax,%rcx
  81c09a:	jbe    81c0f0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x250>
  81c09c:	mov    0x8(%r15),%rcx
  81c0a0:	mov    (%rdx),%edi
  81c0a2:	mov    %edi,(%rcx,%rax,4)
  81c0a5:	cmp    %rbx,%r9
  81c0a8:	jae    81c0b2 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x212>
  81c0aa:	mov    %rsi,%r9
  81c0ad:	cmp    %rbx,%rsi
  81c0b0:	jbe    81c050 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x1b0>
  81c0b2:	mov    0x8(%rsp),%r11
  81c0b7:	cmp    %r11,0x20(%rsp)
  81c0bc:	jae    81bf4f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c0c2:	cmp    %r11,%r8
  81c0c5:	jbe    81c030 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x190>
  81c0cb:	jmp    81bf4f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c0d0:	lea    0x6119e1(%rip),%rdx        # e2dab8 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x80>
  81c0d7:	mov    %rax,%rsi
  81c0da:	call   *0x6633a0(%rip)        # e7f480 <_DYNAMIC+0x4f8>
  81c0e0:	lea    0x6119e9(%rip),%rdx        # e2dad0 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x98>
  81c0e7:	mov    %rax,%rsi
  81c0ea:	call   *0x663390(%rip)        # e7f480 <_DYNAMIC+0x4f8>
  81c0f0:	lea    0x6119f1(%rip),%rdx        # e2dae8 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xb0>
  81c0f7:	mov    %rax,%rdi
  81c0fa:	mov    %rcx,%rsi
  81c0fd:	call   *0x66337d(%rip)        # e7f480 <_DYNAMIC+0x4f8>

FUNCTION <gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>> bytes=321 frame=248

/tmp/gpui-legacy-coverage-codegen/legacy277/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081c110 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>>:
  81c110:	push   %rbp
  81c111:	push   %r15
  81c113:	push   %r14
  81c115:	push   %r13
  81c117:	push   %r12
  81c119:	push   %rbx
  81c11a:	sub    $0xc8,%rsp
  81c121:	mov    %edx,%ebp
  81c123:	mov    %rsi,%r14
  81c126:	mov    %rdi,(%rsp)
  81c12a:	lea    0x8(%rsp),%rdi
  81c12f:	call   *0x66340b(%rip)        # e7f540 <_DYNAMIC+0x5b8>
  81c135:	mov    0x8(%rsp),%rsi
  81c13a:	xor    %r13d,%r13d
  81c13d:	test   $0x1,%bpl
  81c141:	je     81c1e0 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0xd0>
  81c147:	test   %rsi,%rsi
  81c14a:	je     81c225 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x115>
  81c150:	lea    0x70(%rsp),%r15
  81c155:	lea    0x8(%rsp),%r12
  81c15a:	mov    0x6633df(%rip),%rbp        # e7f540 <_DYNAMIC+0x5b8>
  81c161:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  81c170:	mov    0x18(%rsp),%rbx
  81c175:	cmp    $0x1,%rbx
  81c179:	jbe    81c1c0 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0xb0>
  81c17b:	mov    0x10(%rsp),%rax
  81c180:	mov    (%rax),%edx
  81c182:	mov    %r15,%rdi
  81c185:	call   81c260 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81c18a:	movss  0x74(%rsp),%xmm0
  81c190:	xorps  %xmm1,%xmm1
  81c193:	ucomiss %xmm1,%xmm0
  81c196:	lea    (%rbx,%rbx,1),%rax
  81c19a:	lea    0x5(%rbx,%rbx,1),%rcx
  81c19f:	lea    (%rax,%rax,2),%rdx
  81c1a3:	mov    %rcx,%rax
  81c1a6:	cmovne %rdx,%rax
  81c1aa:	cmovp  %rdx,%rax
  81c1ae:	cmpb   $0x3,0x70(%rsp)
  81c1b3:	cmovne %rcx,%rax
  81c1b7:	jmp    81c1c7 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0xb7>
  81c1b9:	nopl   0x0(%rax)
  81c1c0:	add    %rbx,%rbx
  81c1c3:	lea    (%rbx,%rbx,2),%rax
  81c1c7:	add    %rax,%r13
  81c1ca:	jb     81c245 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x135>
  81c1cc:	mov    %r12,%rdi
  81c1cf:	mov    %r14,%rsi
  81c1d2:	call   *%rbp
  81c1d4:	mov    0x8(%rsp),%rsi
  81c1d9:	test   %rsi,%rsi
  81c1dc:	jne    81c170 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x60>
  81c1de:	jmp    81c225 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x115>
  81c1e0:	test   %rsi,%rsi
  81c1e3:	je     81c225 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x115>
  81c1e5:	lea    0x8(%rsp),%r15
  81c1ea:	mov    0x66334f(%rip),%r12        # e7f540 <_DYNAMIC+0x5b8>
  81c1f1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  81c200:	mov    %r13,%rax
  81c203:	mov    0x18(%rsp),%rcx
  81c208:	add    %rcx,%rcx
  81c20b:	lea    (%rcx,%rcx,2),%r13
  81c20f:	add    %rax,%r13
  81c212:	jb     81c245 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x135>
  81c214:	mov    %r15,%rdi
  81c217:	mov    %r14,%rsi
  81c21a:	call   *%r12
  81c21d:	cmpq   $0x0,0x8(%rsp)
  81c223:	jne    81c200 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0xf0>
  81c225:	mov    (%rsp),%rax
  81c229:	mov    %r13,0x8(%rax)
  81c22d:	movl   $0xffffffff,(%rax)
  81c233:	add    $0xc8,%rsp
  81c23a:	pop    %rbx
  81c23b:	pop    %r12
  81c23d:	pop    %r13
  81c23f:	pop    %r14
  81c241:	pop    %r15
  81c243:	pop    %rbp
  81c244:	ret
  81c245:	mov    (%rsp),%rax
  81c249:	movl   $0x6,(%rax)
  81c24f:	jmp    81c233 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x123>

FUNCTION <gpui_gpu::renderer::Renderer>::set_grouped_records bytes=95 frame=24

/tmp/gpui-legacy-coverage-codegen/legacy277/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081c4a0 <<gpui_gpu::renderer::Renderer>::set_grouped_records>:
  81c4a0:	push   %rbp
  81c4a1:	push   %r14
  81c4a3:	push   %rbx
  81c4a4:	cmp    0x341(%rdi),%sil
  81c4ab:	je     81c4eb <<gpui_gpu::renderer::Renderer>::set_grouped_records+0x4b>
  81c4ad:	mov    0x330(%rdi),%rax
  81c4b4:	test   %rax,%rax
  81c4b7:	je     81c4d9 <<gpui_gpu::renderer::Renderer>::set_grouped_records+0x39>
  81c4b9:	lock decq (%rax)
  81c4bd:	jne    81c4d9 <<gpui_gpu::renderer::Renderer>::set_grouped_records+0x39>
  81c4bf:	lea    0x330(%rdi),%rbx
  81c4c6:	mov    %rdi,%r14
  81c4c9:	mov    %rbx,%rdi
  81c4cc:	mov    %esi,%ebp
  81c4ce:	call   *0x662fcc(%rip)        # e7f4a0 <_DYNAMIC+0x518>
  81c4d4:	mov    %r14,%rdi
  81c4d7:	mov    %ebp,%esi
  81c4d9:	movq   $0x0,0x330(%rdi)
  81c4e4:	mov    %sil,0x341(%rdi)
  81c4eb:	pop    %rbx
  81c4ec:	pop    %r14
  81c4ee:	pop    %rbp
  81c4ef:	ret
  81c4f0:	movq   $0x0,(%rbx)
  81c4f7:	mov    %rax,%rdi
  81c4fa:	call   e2bd40 <_Unwind_Resume@plt>

FUNCTION <gpui_gpu::renderer::Buffer>::write bytes=303 frame=120

/tmp/gpui-legacy-coverage-codegen/legacy277/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081c500 <<gpui_gpu::renderer::Buffer>::write>:
  81c500:	push   %r15
  81c502:	push   %r14
  81c504:	push   %r13
  81c506:	push   %r12
  81c508:	push   %rbx
  81c509:	sub    $0x50,%rsp
  81c50d:	mov    %rdx,%r14
  81c510:	mov    %rdi,%rbx
  81c513:	cmp    0x20(%rdi),%r8
  81c517:	jbe    81c5ca <<gpui_gpu::renderer::Buffer>::write+0xca>
  81c51d:	mov    %rcx,%r15
  81c520:	mov    $0x1,%r13d
  81c526:	cmp    $0x2,%r8
  81c52a:	jb     81c543 <<gpui_gpu::renderer::Buffer>::write+0x43>
  81c52c:	lea    -0x1(%r8),%rax
  81c530:	bsr    %rax,%rcx
  81c534:	not    %ecx
  81c536:	mov    $0xffffffffffffffff,%r13
  81c53d:	shr    %cl,%r13
  81c540:	inc    %r13
  81c543:	mov    %r8,%r12
  81c546:	lea    -0x747d75(%rip),%rax        # d47d8 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x142>
  81c54d:	mov    %rax,0x30(%rsp)
  81c552:	movq   $0xa,0x38(%rsp)
  81c55b:	mov    %r13,0x40(%rsp)
  81c560:	movl   $0x88,0x48(%rsp)
  81c568:	movb   $0x0,0x4c(%rsp)
  81c56d:	lea    0x8(%rsp),%rdi
  81c572:	lea    0x30(%rsp),%rdx
  81c577:	call   *0x66302b(%rip)        # e7f5a8 <_DYNAMIC+0x620>
  81c57d:	mov    %r13,0x28(%rsp)
  81c582:	mov    (%rbx),%rax
  81c585:	lock decq (%rax)
  81c589:	jne    81c594 <<gpui_gpu::renderer::Buffer>::write+0x94>
  81c58b:	mov    %rbx,%rdi
  81c58e:	call   *0x662efc(%rip)        # e7f490 <_DYNAMIC+0x508>
  81c594:	mov    0x8(%rbx),%rax
  81c598:	lock decq (%rax)
  81c59c:	jne    81c5a8 <<gpui_gpu::renderer::Buffer>::write+0xa8>
  81c59e:	lea    0x8(%rbx),%rdi
  81c5a2:	call   *0x662ef0(%rip)        # e7f498 <_DYNAMIC+0x510>
  81c5a8:	mov    0x28(%rsp),%rax
  81c5ad:	mov    %rax,0x20(%rbx)
  81c5b1:	movups 0x8(%rsp),%xmm0
  81c5b6:	movups 0x18(%rsp),%xmm1
  81c5bb:	movups %xmm1,0x10(%rbx)
  81c5bf:	movups %xmm0,(%rbx)
  81c5c2:	mov    %r12,%r8
  81c5c5:	mov    %r15,%rcx
  81c5c8:	jmp    81c5cf <<gpui_gpu::renderer::Buffer>::write+0xcf>
  81c5ca:	test   %r8,%r8
  81c5cd:	je     81c5dd <<gpui_gpu::renderer::Buffer>::write+0xdd>
  81c5cf:	mov    %r14,%rdi
  81c5d2:	mov    %rbx,%rsi
  81c5d5:	xor    %edx,%edx
  81c5d7:	call   *0x662f7b(%rip)        # e7f558 <_DYNAMIC+0x5d0>
  81c5dd:	add    $0x50,%rsp
  81c5e1:	pop    %rbx
  81c5e2:	pop    %r12
  81c5e4:	pop    %r13
  81c5e6:	pop    %r14
  81c5e8:	pop    %r15
  81c5ea:	ret
  81c5eb:	mov    %rax,%r14
  81c5ee:	jmp    81c607 <<gpui_gpu::renderer::Buffer>::write+0x107>
  81c5f0:	mov    %rax,%r14
  81c5f3:	mov    0x8(%rbx),%rax
  81c5f7:	lock decq (%rax)
  81c5fb:	jne    81c607 <<gpui_gpu::renderer::Buffer>::write+0x107>
  81c5fd:	lea    0x8(%rbx),%rdi
  81c601:	call   *0x662e91(%rip)        # e7f498 <_DYNAMIC+0x510>
  81c607:	mov    0x28(%rsp),%rax
  81c60c:	mov    %rax,0x20(%rbx)
  81c610:	movups 0x8(%rsp),%xmm0
  81c615:	movups 0x18(%rsp),%xmm1
  81c61a:	movups %xmm1,0x10(%rbx)
  81c61e:	movups %xmm0,(%rbx)
  81c621:	mov    %r14,%rdi
  81c624:	call   e2bd40 <_Unwind_Resume@plt>
  81c629:	call   *0x662ba9(%rip)        # e7f1d8 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::Atlas>::new bytes=706 frame=376

/tmp/gpui-legacy-coverage-codegen/legacy277/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081c630 <<gpui_gpu::renderer::Atlas>::new>:
  81c630:	push   %rbp
  81c631:	push   %r14
  81c633:	push   %rbx
  81c634:	sub    $0x160,%rsp
  81c63b:	mov    %edx,%ebp
  81c63d:	mov    %rdi,%rbx
  81c640:	lea    -0x747e65(%rip),%rax        # d47e2 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x14c>
  81c647:	mov    %rax,(%rsp)
  81c64b:	movq   $0xe,0x8(%rsp)
  81c654:	mov    %edx,0x10(%rsp)
  81c658:	mov    %edx,0x14(%rsp)
  81c65c:	movaps -0x770173(%rip),%xmm0        # ac4f0 <anon.531a4b6c7f642b9eba5e0e986955623b.109.llvm.14547199655466482296+0x2c0>
  81c663:	movups %xmm0,0x18(%rsp)
  81c668:	movl   $0x0,0x28(%rsp)
  81c670:	movl   $0x6,0x34(%rsp)
  81c678:	movq   $0x4,0x38(%rsp)
  81c681:	movq   $0x0,0x40(%rsp)
  81c68a:	lea    0x110(%rsp),%r14
  81c692:	mov    %rsp,%rdx
  81c695:	mov    %r14,%rdi
  81c698:	call   *0x662d8a(%rip)        # e7f428 <_DYNAMIC+0x4a0>
  81c69e:	movq   $0x0,0x18(%rsp)
  81c6a7:	movl   $0xffffffff,0x30(%rsp)
  81c6af:	movl   $0x0,(%rsp)
  81c6b6:	movabs $0xffffffff00000000,%rax
  81c6c0:	mov    %rax,0x28(%rsp)
  81c6c5:	movq   $0x0,0x3c(%rsp)
  81c6ce:	movl   $0x0,0x8(%rsp)
  81c6d6:	movl   $0x0,0x10(%rsp)
  81c6de:	lea    0xb8(%rsp),%rdi
  81c6e6:	mov    %rsp,%rdx
  81c6e9:	mov    %r14,%rsi
  81c6ec:	call   *0x662d3e(%rip)        # e7f430 <_DYNAMIC+0x4a8>
  81c6f2:	movups 0x150(%rsp),%xmm0
  81c6fa:	movaps %xmm0,0xa0(%rsp)
  81c702:	movups 0x110(%rsp),%xmm0
  81c70a:	movups 0x120(%rsp),%xmm1
  81c712:	movups 0x130(%rsp),%xmm2
  81c71a:	movups 0x140(%rsp),%xmm3
  81c722:	movaps %xmm3,0x90(%rsp)
  81c72a:	movaps %xmm2,0x80(%rsp)
  81c732:	movaps %xmm1,0x70(%rsp)
  81c737:	movaps %xmm0,0x60(%rsp)
  81c73c:	mov    0x108(%rsp),%rax
  81c744:	mov    %rax,0x50(%rsp)
  81c749:	movups 0xf8(%rsp),%xmm0
  81c751:	movaps %xmm0,0x40(%rsp)
  81c756:	movups 0xb8(%rsp),%xmm0
  81c75e:	movups 0xc8(%rsp),%xmm1
  81c766:	movups 0xd8(%rsp),%xmm2
  81c76e:	movups 0xe8(%rsp),%xmm3
  81c776:	movaps %xmm3,0x30(%rsp)
  81c77b:	movaps %xmm2,0x20(%rsp)
  81c780:	movaps %xmm1,0x10(%rsp)
  81c785:	movaps %xmm0,(%rsp)
  81c789:	mov    %fs:0x0,%rax
  81c792:	lea    -0x28(%rax),%rax
  81c799:	mov    %rax,%r14
  81c79c:	cmpb   $0x1,0x10(%rax)
  81c7a0:	jne    81c88b <<gpui_gpu::renderer::Atlas>::new+0x25b>
  81c7a6:	mov    (%r14),%rax
  81c7a9:	mov    0x8(%r14),%rdx
  81c7ad:	lea    0x1(%rax),%rcx
  81c7b1:	mov    %rcx,(%r14)
  81c7b4:	movaps 0xa0(%rsp),%xmm0
  81c7bc:	movups %xmm0,0x40(%rbx)
  81c7c0:	movaps 0x60(%rsp),%xmm0
  81c7c5:	movaps 0x70(%rsp),%xmm1
  81c7ca:	movaps 0x80(%rsp),%xmm2
  81c7d2:	movaps 0x90(%rsp),%xmm3
  81c7da:	movups %xmm3,0x30(%rbx)
  81c7de:	movups %xmm2,0x20(%rbx)
  81c7e2:	movups %xmm1,0x10(%rbx)
  81c7e6:	movups %xmm0,(%rbx)
  81c7e9:	movups 0xb8(%rsp),%xmm0
  81c7f1:	movups 0xc8(%rsp),%xmm1
  81c7f9:	movups 0xd8(%rsp),%xmm2
  81c801:	movups 0xe8(%rsp),%xmm3
  81c809:	movups %xmm0,0x50(%rbx)
  81c80d:	movups %xmm1,0x60(%rbx)
  81c811:	movups %xmm2,0x70(%rbx)
  81c815:	movups %xmm3,0x80(%rbx)
  81c81c:	movups 0xf8(%rsp),%xmm0
  81c824:	movups %xmm0,0x90(%rbx)
  81c82b:	mov    0x108(%rsp),%rcx
  81c833:	mov    %rcx,0xa0(%rbx)
  81c83a:	mov    %ebp,0xd8(%rbx)
  81c840:	movq   $0x0,0xdc(%rbx)
  81c84b:	movl   $0x0,0xe4(%rbx)
  81c855:	movups 0x6112ec(%rip),%xmm0        # e2db48 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x110>
  81c85c:	movups %xmm0,0xa8(%rbx)
  81c863:	movups 0x6112ee(%rip),%xmm0        # e2db58 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x120>
  81c86a:	movups %xmm0,0xb8(%rbx)
  81c871:	mov    %rax,0xc8(%rbx)
  81c878:	mov    %rdx,0xd0(%rbx)
  81c87f:	add    $0x160,%rsp
  81c886:	pop    %rbx
  81c887:	pop    %r14
  81c889:	pop    %rbp
  81c88a:	ret
  81c88b:	call   *0x662d1f(%rip)        # e7f5b0 <_DYNAMIC+0x628>
  81c891:	mov    %rax,(%r14)
  81c894:	mov    %rdx,0x8(%r14)
  81c898:	movb   $0x1,0x10(%r14)
  81c89d:	jmp    81c7ad <<gpui_gpu::renderer::Atlas>::new+0x17d>
  81c8a2:	mov    %rax,%rbx
  81c8a5:	mov    %rsp,%rdi
  81c8a8:	call   81bd70 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  81c8ad:	mov    0x60(%rsp),%rax
  81c8b2:	lock decq (%rax)
  81c8b6:	jne    81c8e4 <<gpui_gpu::renderer::Atlas>::new+0x2b4>
  81c8b8:	lea    0x60(%rsp),%rdi
  81c8bd:	call   *0x662bad(%rip)        # e7f470 <_DYNAMIC+0x4e8>
  81c8c3:	jmp    81c8e4 <<gpui_gpu::renderer::Atlas>::new+0x2b4>
  81c8c5:	mov    %rax,%rbx
  81c8c8:	mov    0x110(%rsp),%rax
  81c8d0:	lock decq (%rax)
  81c8d4:	jne    81c8e4 <<gpui_gpu::renderer::Atlas>::new+0x2b4>
  81c8d6:	lea    0x110(%rsp),%rdi
  81c8de:	call   *0x662b8c(%rip)        # e7f470 <_DYNAMIC+0x4e8>
  81c8e4:	mov    %rbx,%rdi
  81c8e7:	call   e2bd40 <_Unwind_Resume@plt>
  81c8ec:	call   *0x6628e6(%rip)        # e7f1d8 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::Atlas>::insert bytes=608 frame=152

/tmp/gpui-legacy-coverage-codegen/legacy277/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081c900 <<gpui_gpu::renderer::Atlas>::insert>:
  81c900:	push   %rbp
  81c901:	push   %r15
  81c903:	push   %r14
  81c905:	push   %r13
  81c907:	push   %r12
  81c909:	push   %rbx
  81c90a:	sub    $0x68,%rsp
  81c90e:	mov    %rdx,%r12
  81c911:	mov    %rsi,%r15
  81c914:	mov    %rdi,%r14
  81c917:	lea    0x10(%rdx),%r13
  81c91b:	cmpq   $0x0,0xc0(%rdi)
  81c923:	je     81c9eb <<gpui_gpu::renderer::Atlas>::insert+0xeb>
  81c929:	lea    0xc8(%r14),%rdi
  81c930:	mov    %r13,%rsi
  81c933:	call   821710 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  81c938:	mov    %rax,%rsi
  81c93b:	shr    $0x39,%rsi
  81c93f:	mov    0xa8(%r14),%rcx
  81c946:	mov    0xb0(%r14),%rdx
  81c94d:	movd   %esi,%xmm0
  81c951:	punpcklbw %xmm0,%xmm0
  81c955:	pshuflw $0x0,%xmm0,%xmm0
  81c95a:	pshufd $0x44,%xmm0,%xmm0
  81c95f:	mov    0x10(%r12),%rsi
  81c964:	movzwl 0x1c(%r12),%edi
  81c96a:	mov    0x18(%r12),%r8d
  81c96f:	pcmpeqd %xmm1,%xmm1
  81c973:	xor    %r9d,%r9d
  81c976:	and    %rdx,%rax
  81c979:	movdqu (%rcx,%rax,1),%xmm2
  81c97e:	movdqa %xmm2,%xmm3
  81c982:	pcmpeqb %xmm0,%xmm3
  81c986:	pmovmskb %xmm3,%r10d
  81c98b:	test   %r10d,%r10d
  81c98e:	je     81c9d0 <<gpui_gpu::renderer::Atlas>::insert+0xd0>
  81c990:	tzcnt  %r10d,%ebx
  81c995:	add    %rax,%rbx
  81c998:	and    %rdx,%rbx
  81c99b:	shl    $0x5,%rbx
  81c99f:	mov    %rcx,%r11
  81c9a2:	sub    %rbx,%r11
  81c9a5:	cmp    -0x20(%r11),%rsi
  81c9a9:	jne    81c9bc <<gpui_gpu::renderer::Atlas>::insert+0xbc>
  81c9ab:	cmp    -0x14(%r11),%di
  81c9b0:	jne    81c9bc <<gpui_gpu::renderer::Atlas>::insert+0xbc>
  81c9b2:	cmp    -0x18(%r11),%r8d
  81c9b6:	je     81ca53 <<gpui_gpu::renderer::Atlas>::insert+0x153>
  81c9bc:	lea    -0x1(%r10),%r11d
  81c9c0:	and    %r10w,%r11w
  81c9c4:	mov    %r11d,%r10d
  81c9c7:	jne    81c990 <<gpui_gpu::renderer::Atlas>::insert+0x90>
  81c9c9:	nopl   0x0(%rax)
  81c9d0:	pcmpeqb %xmm1,%xmm2
  81c9d4:	pmovmskb %xmm2,%r10d
  81c9d9:	test   %r10d,%r10d
  81c9dc:	jne    81c9eb <<gpui_gpu::renderer::Atlas>::insert+0xeb>
  81c9de:	add    %r9,%rax
  81c9e1:	add    $0x10,%rax
  81c9e5:	add    $0x10,%r9
  81c9e9:	jmp    81c976 <<gpui_gpu::renderer::Atlas>::insert+0x76>
  81c9eb:	mov    0x20(%r12),%ebp
  81c9f0:	xor    %eax,%eax
  81c9f2:	test   %ebp,%ebp
  81c9f4:	je     81ca4e <<gpui_gpu::renderer::Atlas>::insert+0x14e>
  81c9f6:	mov    %r15,%rdi
  81c9f9:	mov    0x28(%r12),%r15d
  81c9fe:	test   %r15d,%r15d
  81ca01:	je     81ca4e <<gpui_gpu::renderer::Atlas>::insert+0x14e>
  81ca03:	mov    0xd8(%r14),%ecx
  81ca0a:	cmp    %ebp,%ecx
  81ca0c:	jb     81cb51 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81ca12:	cmp    %r15d,%ecx
  81ca15:	jb     81cb51 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81ca1b:	mov    %r13,0x40(%rsp)
  81ca20:	mov    0xdc(%r14),%r8d
  81ca27:	mov    0xe4(%r14),%r13d
  81ca2e:	lea    (%r8,%rbp,1),%edx
  81ca32:	xor    %eax,%eax
  81ca34:	cmp    %ecx,%edx
  81ca36:	mov    $0x0,%ebx
  81ca3b:	cmova  %r13d,%ebx
  81ca3f:	add    0xe0(%r14),%ebx
  81ca46:	lea    (%rbx,%r15,1),%esi
  81ca4a:	cmp    %ecx,%esi
  81ca4c:	jbe    81ca5f <<gpui_gpu::renderer::Atlas>::insert+0x15f>
  81ca4e:	jmp    81cb51 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81ca53:	mov    $0x1,%eax
  81ca58:	xor    %edx,%edx
  81ca5a:	jmp    81cb51 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81ca5f:	cmp    %r13d,%r15d
  81ca62:	cmova  %r15d,%r13d
  81ca66:	cmp    %ecx,%edx
  81ca68:	cmova  %eax,%r8d
  81ca6c:	lea    0xa8(%r14),%rax
  81ca73:	mov    %rax,0x38(%rsp)
  81ca78:	mov    %r14,0x48(%rsp)
  81ca7d:	movl   $0x0,0x50(%rsp)
  81ca85:	mov    %r8d,0x54(%rsp)
  81ca8a:	mov    %ebx,0x58(%rsp)
  81ca8e:	movq   $0x0,0x5c(%rsp)
  81ca97:	mov    (%r12),%rdx
  81ca9b:	mov    0x8(%r12),%rcx
  81caa0:	mov    %rcx,0x30(%rsp)
  81caa5:	movq   $0x0,0x8(%rsp)
  81caae:	movl   $0x1,0x10(%rsp)
  81cab6:	mov    %ebp,0x14(%rsp)
  81caba:	movl   $0x1,0x18(%rsp)
  81cac2:	mov    %r15d,0x1c(%rsp)
  81cac7:	mov    %ebp,0x20(%rsp)
  81cacb:	mov    %r15d,0x24(%rsp)
  81cad0:	movl   $0x1,0x28(%rsp)
  81cad8:	cmova  %r15d,%r13d
  81cadc:	lea    0x48(%rsp),%rsi
  81cae1:	mov    %r8,%r12
  81cae4:	lea    0x8(%rsp),%r8
  81cae9:	lea    0x20(%rsp),%r9
  81caee:	call   *0x662ac4(%rip)        # e7f5b8 <_DYNAMIC+0x630>
  81caf4:	lea    (%r12,%rbp,1),%eax
  81caf8:	mov    %eax,0xdc(%r14)
  81caff:	mov    %ebx,0xe0(%r14)
  81cb06:	mov    %r13d,0xe4(%r14)
  81cb0d:	mov    0x40(%rsp),%rax
  81cb12:	movdqu (%rax),%xmm0
  81cb16:	movdqa %xmm0,0x20(%rsp)
  81cb1c:	mov    %r12d,0x8(%rsp)
  81cb21:	mov    %ebx,0xc(%rsp)
  81cb25:	mov    %ebp,0x10(%rsp)
  81cb29:	mov    %r15d,0x14(%rsp)
  81cb2e:	lea    0x48(%rsp),%rdi
  81cb33:	lea    0x20(%rsp),%rdx
  81cb38:	lea    0x8(%rsp),%rcx
  81cb3d:	mov    0x38(%rsp),%rsi
  81cb42:	call   822f40 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert>
  81cb47:	mov    0x30(%rsp),%rdx
  81cb4c:	mov    $0x1,%eax
  81cb51:	add    $0x68,%rsp
  81cb55:	pop    %rbx
  81cb56:	pop    %r12
  81cb58:	pop    %r13
  81cb5a:	pop    %r14
  81cb5c:	pop    %r15
  81cb5e:	pop    %rbp
  81cb5f:	ret

FUNCTION <gpui_gpu::renderer::GpuContext>::submit bytes=469 frame=1384

/tmp/gpui-legacy-coverage-codegen/legacy277/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081cb60 <<gpui_gpu::renderer::GpuContext>::submit>:
  81cb60:	push   %r15
  81cb62:	push   %r14
  81cb64:	push   %r12
  81cb66:	push   %rbx
  81cb67:	sub    $0x548,%rsp
  81cb6e:	mov    %rdx,%r14
  81cb71:	mov    %rsi,%r12
  81cb74:	mov    %rdi,%rbx
  81cb77:	lea    0x61107a(%rip),%rdx        # e2dbf8 <anon.e7af5e0dba0d7261d22cb76253955a85.29.llvm.7635581776195589086>
  81cb7e:	lea    0x30(%rsp),%r15
  81cb83:	mov    %r15,%rdi
  81cb86:	mov    %rbx,%rsi
  81cb89:	call   *0x662a31(%rip)        # e7f5c0 <_DYNAMIC+0x638>
  81cb8f:	xorps  %xmm0,%xmm0
  81cb92:	movups %xmm0,0x10(%rsp)
  81cb97:	movups %xmm0,0x20(%rsp)
  81cb9c:	movl   $0x0,0x50(%rsp)
  81cba4:	movb   $0x0,0x58(%rsp)
  81cba9:	movups 0x9(%rsp),%xmm0
  81cbae:	movups %xmm0,0x59(%rsp)
  81cbb3:	movups 0x19(%rsp),%xmm0
  81cbb8:	movups %xmm0,0x69(%rsp)
  81cbbd:	mov    0x28(%rsp),%rax
  81cbc2:	mov    %rax,0x78(%rsp)
  81cbc7:	movl   $0x0,0x80(%rsp)
  81cbd2:	mov    %r12,0x88(%rsp)
  81cbda:	movq   $0x0,0x90(%rsp)
  81cbe6:	lea    -0x7483fd(%rip),%rax        # d47f0 <anon.e7af5e0dba0d7261d22cb76253955a85.28.llvm.7635581776195589086>
  81cbed:	mov    %rax,0xe0(%rsp)
  81cbf5:	movq   $0xa,0xe8(%rsp)
  81cc01:	lea    0x50(%rsp),%rax
  81cc06:	mov    %rax,0xd0(%rsp)
  81cc0e:	movq   $0x1,0xd8(%rsp)
  81cc1a:	movl   $0xffffffff,0xb8(%rsp)
  81cc25:	movl   $0x2,0x98(%rsp)
  81cc30:	movq   $0x0,0xf0(%rsp)
  81cc3c:	movl   $0x0,0xf8(%rsp)
  81cc47:	lea    0x100(%rsp),%rdi
  81cc4f:	lea    0x98(%rsp),%rdx
  81cc57:	mov    %r15,%rsi
  81cc5a:	call   *0x662968(%rip)        # e7f5c8 <_DYNAMIC+0x640>
  81cc60:	lea    0x10(%rbx),%rsi
  81cc64:	lea    0x100(%rsp),%rdi
  81cc6c:	call   *0x66295e(%rip)        # e7f5d0 <_DYNAMIC+0x648>
  81cc72:	lea    0x100(%rsp),%rdi
  81cc7a:	mov    $0x4,%ecx
  81cc7f:	xor    %esi,%esi
  81cc81:	mov    %r14,%rdx
  81cc84:	xor    %r8d,%r8d
  81cc87:	call   *0x66294b(%rip)        # e7f5d8 <_DYNAMIC+0x650>
  81cc8d:	lea    0x100(%rsp),%rdi
  81cc95:	xor    %esi,%esi
  81cc97:	mov    $0x3,%edx
  81cc9c:	xor    %ecx,%ecx
  81cc9e:	mov    $0x1,%r8d
  81cca4:	call   *0x662936(%rip)        # e7f5e0 <_DYNAMIC+0x658>
  81ccaa:	lea    0x100(%rsp),%rdi
  81ccb2:	call   81bc70 <core::ptr::drop_glue::<wgpu::api::render_pass::RenderPass>>
  81ccb7:	movups 0x30(%rsp),%xmm0
  81ccbc:	movups 0x40(%rsp),%xmm1
  81ccc1:	movaps %xmm1,0x110(%rsp)
  81ccc9:	movaps %xmm0,0x100(%rsp)
  81ccd1:	lea    0x98(%rsp),%r14
  81ccd9:	lea    0x100(%rsp),%rsi
  81cce1:	mov    %r14,%rdi
  81cce4:	call   *0x6628fe(%rip)        # e7f5e8 <_DYNAMIC+0x660>
  81ccea:	add    $0x8,%rbx
  81ccee:	mov    %rbx,%rdi
  81ccf1:	mov    %r14,%rsi
  81ccf4:	call   824e70 <<wgpu::api::queue::Queue>::submit::<[wgpu::api::command_buffer::CommandBuffer; 1]>>
  81ccf9:	add    $0x548,%rsp
  81cd00:	pop    %rbx
  81cd01:	pop    %r12
  81cd03:	pop    %r14
  81cd05:	pop    %r15
  81cd07:	ret
  81cd08:	mov    %rax,%rbx
  81cd0b:	jmp    81cd1d <<gpui_gpu::renderer::GpuContext>::submit+0x1bd>
  81cd0d:	mov    %rax,%rbx
  81cd10:	lea    0x100(%rsp),%rdi
  81cd18:	call   81bc70 <core::ptr::drop_glue::<wgpu::api::render_pass::RenderPass>>
  81cd1d:	lea    0x30(%rsp),%rdi
  81cd22:	call   81bde0 <core::ptr::drop_glue::<wgpu::api::command_encoder::CommandEncoder>>
  81cd27:	mov    %rbx,%rdi
  81cd2a:	call   e2bd40 <_Unwind_Resume@plt>
  81cd2f:	call   *0x6624a3(%rip)        # e7f1d8 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::RendererState>::correction bytes=981 frame=184

/tmp/gpui-legacy-coverage-codegen/legacy277/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081cd40 <<gpui_gpu::renderer::RendererState>::correction>:
  81cd40:	push   %r15
  81cd42:	push   %r14
  81cd44:	push   %r13
  81cd46:	push   %r12
  81cd48:	push   %rbx
  81cd49:	sub    $0x90,%rsp
  81cd50:	mov    %rdi,%rbx
  81cd53:	movss  (%rdx),%xmm1
  81cd57:	movss  0x8(%rdx),%xmm2
  81cd5c:	movaps %xmm1,%xmm0
  81cd5f:	addss  %xmm2,%xmm0
  81cd63:	movd   %xmm0,%eax
  81cd67:	and    $0x7fffffff,%eax
  81cd6c:	xorps  %xmm8,%xmm8
  81cd70:	xorps  %xmm9,%xmm9
  81cd74:	cmp    $0x7f7fffff,%eax
  81cd79:	jg     81cd98 <<gpui_gpu::renderer::RendererState>::correction+0x58>
  81cd7b:	cvtss2sd %xmm1,%xmm1
  81cd7f:	cvtss2sd %xmm2,%xmm2
  81cd83:	cvtss2sd %xmm0,%xmm0
  81cd87:	addsd  %xmm1,%xmm2
  81cd8b:	subsd  %xmm0,%xmm2
  81cd8f:	xorps  %xmm9,%xmm9
  81cd93:	cvtsd2ss %xmm2,%xmm9
  81cd98:	movupd (%rsi),%xmm0
  81cd9c:	movupd 0x8(%rsi),%xmm1
  81cda1:	movsd  0x10(%rsi),%xmm2
  81cda6:	movsd  0x18(%rsi),%xmm3
  81cdab:	movupd 0x20(%rsi),%xmm4
  81cdb0:	movss  0x4(%rdx),%xmm6
  81cdb5:	movss  0xc(%rdx),%xmm7
  81cdba:	movaps %xmm6,%xmm5
  81cdbd:	addss  %xmm7,%xmm5
  81cdc1:	movd   %xmm5,%eax
  81cdc5:	and    $0x7fffffff,%eax
  81cdca:	cmp    $0x7f7fffff,%eax
  81cdcf:	jg     81cdee <<gpui_gpu::renderer::RendererState>::correction+0xae>
  81cdd1:	cvtss2sd %xmm6,%xmm6
  81cdd5:	cvtss2sd %xmm7,%xmm7
  81cdd9:	cvtss2sd %xmm5,%xmm5
  81cddd:	addsd  %xmm6,%xmm7
  81cde1:	subsd  %xmm5,%xmm7
  81cde5:	xorps  %xmm8,%xmm8
  81cde9:	cvtsd2ss %xmm7,%xmm8
  81cdee:	cvtpd2ps %xmm4,%xmm5
  81cdf2:	cvtps2pd %xmm5,%xmm5
  81cdf5:	subpd  %xmm5,%xmm4
  81cdf9:	cvtpd2ps %xmm4,%xmm4
  81cdfd:	unpcklpd %xmm3,%xmm1
  81ce01:	cvtpd2ps %xmm1,%xmm3
  81ce05:	unpcklpd %xmm2,%xmm0
  81ce09:	cvtpd2ps %xmm0,%xmm2
  81ce0d:	cvtps2pd %xmm3,%xmm3
  81ce10:	subpd  %xmm3,%xmm1
  81ce14:	cvtpd2ps %xmm1,%xmm5
  81ce18:	cvtps2pd %xmm2,%xmm1
  81ce1b:	subpd  %xmm1,%xmm0
  81ce1f:	cvtpd2ps %xmm0,%xmm6
  81ce23:	movapd %xmm6,%xmm0
  81ce27:	unpcklps %xmm5,%xmm0
  81ce2a:	movaps %xmm8,%xmm1
  81ce2e:	movlhps %xmm9,%xmm1
  81ce32:	movapd %xmm4,%xmm2
  81ce36:	shufps $0x24,%xmm1,%xmm2
  81ce3a:	xorps  %xmm1,%xmm1
  81ce3d:	movapd %xmm0,%xmm3
  81ce41:	cmpneqps %xmm1,%xmm3
  81ce45:	cmpneqps %xmm1,%xmm2
  81ce49:	packssdw %xmm2,%xmm3
  81ce4d:	pmovmskb %xmm3,%eax
  81ce51:	test   %eax,%eax
  81ce53:	je     81cf77 <<gpui_gpu::renderer::RendererState>::correction+0x237>
  81ce59:	movapd %xmm6,0x60(%rsp)
  81ce5f:	movapd %xmm5,0x70(%rsp)
  81ce65:	lea    0x8(%rsp),%r12
  81ce6a:	movapd %xmm0,(%rsp)
  81ce6f:	movapd %xmm4,0x80(%rsp)
  81ce78:	movlpd %xmm4,0x10(%rsp)
  81ce7e:	movss  %xmm9,0x18(%rsp)
  81ce85:	movss  %xmm8,0x1c(%rsp)
  81ce8c:	lea    0x318(%rbx),%r14
  81ce93:	mov    %rsp,%rsi
  81ce96:	mov    %r14,%rdi
  81ce99:	movaps %xmm8,0x30(%rsp)
  81ce9f:	movaps %xmm9,0x20(%rsp)
  81cea5:	call   821590 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&[u32; 8]>>
  81ceaa:	movapd 0x20(%rsp),%xmm6
  81ceb0:	movapd 0x30(%rsp),%xmm5
  81ceb6:	mov    %rax,%r15
  81ceb9:	shr    $0x39,%r15
  81cebd:	mov    0x2f8(%rbx),%rcx
  81cec4:	mov    0x300(%rbx),%rdx
  81cecb:	movd   %r15d,%xmm0
  81ced0:	punpcklbw %xmm0,%xmm0
  81ced4:	pshuflw $0x0,%xmm0,%xmm0
  81ced9:	pshufd $0x44,%xmm0,%xmm0
  81cede:	xor    %esi,%esi
  81cee0:	pcmpeqd %xmm1,%xmm1
  81cee4:	mov    %rax,%rdi
  81cee7:	and    %rdx,%rdi
  81ceea:	movdqu (%rcx,%rdi,1),%xmm2
  81ceef:	movdqa %xmm2,%xmm3
  81cef3:	pcmpeqb %xmm0,%xmm3
  81cef7:	pmovmskb %xmm3,%r8d
  81cefc:	test   %r8d,%r8d
  81ceff:	je     81cf50 <<gpui_gpu::renderer::RendererState>::correction+0x210>
  81cf01:	tzcnt  %r8d,%r9d
  81cf06:	add    %rdi,%r9
  81cf09:	and    %rdx,%r9
  81cf0c:	neg    %r9
  81cf0f:	lea    (%r9,%r9,8),%r9
  81cf13:	movdqu -0x24(%rcx,%r9,4),%xmm3
  81cf1a:	movdqu -0x14(%rcx,%r9,4),%xmm4
  81cf21:	pcmpeqb 0x10(%rsp),%xmm4
  81cf27:	pcmpeqb (%rsp),%xmm3
  81cf2c:	pand   %xmm4,%xmm3
  81cf30:	pmovmskb %xmm3,%r10d
  81cf35:	cmp    $0xffff,%r10d
  81cf3c:	je     81cf6e <<gpui_gpu::renderer::RendererState>::correction+0x22e>
  81cf3e:	lea    -0x1(%r8),%r9d
  81cf42:	and    %r8w,%r9w
  81cf46:	mov    %r9d,%r8d
  81cf49:	jne    81cf01 <<gpui_gpu::renderer::RendererState>::correction+0x1c1>
  81cf4b:	nopl   0x0(%rax,%rax,1)
  81cf50:	pcmpeqb %xmm1,%xmm2
  81cf54:	pmovmskb %xmm2,%r8d
  81cf59:	test   %r8d,%r8d
  81cf5c:	jne    81cf7e <<gpui_gpu::renderer::RendererState>::correction+0x23e>
  81cf5e:	add    %rsi,%rdi
  81cf61:	add    $0x10,%rdi
  81cf65:	add    $0x10,%rsi
  81cf69:	jmp    81cee7 <<gpui_gpu::renderer::RendererState>::correction+0x1a7>
  81cf6e:	lea    (%rcx,%r9,4),%rdx
  81cf72:	jmp    81d099 <<gpui_gpu::renderer::RendererState>::correction+0x359>
  81cf77:	xor    %eax,%eax
  81cf79:	jmp    81d09c <<gpui_gpu::renderer::RendererState>::correction+0x35c>
  81cf7e:	cmpq   $0x0,0x308(%rbx)
  81cf86:	je     81d0cf <<gpui_gpu::renderer::RendererState>::correction+0x38f>
  81cf8c:	mov    (%rsp),%r14
  81cf90:	mov    0x10(%r12),%rcx
  81cf95:	mov    %rcx,0x50(%rsp)
  81cf9a:	movups (%r12),%xmm0
  81cf9f:	movaps %xmm0,0x40(%rsp)
  81cfa4:	mov    0x70(%rbx),%r12
  81cfa8:	cmp    0x60(%rbx),%r12
  81cfac:	jne    81cfca <<gpui_gpu::renderer::RendererState>::correction+0x28a>
  81cfae:	lea    0x60(%rbx),%rdi
  81cfb2:	mov    %rax,%r13
  81cfb5:	call   *0x66257d(%rip)        # e7f538 <_DYNAMIC+0x5b0>
  81cfbb:	movapd 0x20(%rsp),%xmm6
  81cfc1:	movapd 0x30(%rsp),%xmm5
  81cfc7:	mov    %r13,%rax
  81cfca:	mov    0x68(%rbx),%rcx
  81cfce:	mov    %r12,%rdx
  81cfd1:	shl    $0x5,%rdx
  81cfd5:	movaps 0x60(%rsp),%xmm0
  81cfda:	movlps %xmm0,(%rcx,%rdx,1)
  81cfde:	movaps 0x80(%rsp),%xmm0
  81cfe6:	movss  %xmm0,0x8(%rcx,%rdx,1)
  81cfec:	movss  %xmm6,0xc(%rcx,%rdx,1)
  81cff2:	movdqa 0x70(%rsp),%xmm1
  81cff8:	movq   %xmm1,0x10(%rcx,%rdx,1)
  81cffe:	shufps $0x55,%xmm0,%xmm0
  81d002:	movss  %xmm0,0x18(%rcx,%rdx,1)
  81d008:	movss  %xmm5,0x1c(%rcx,%rdx,1)
  81d00e:	lea    0x1(%r12),%rcx
  81d013:	mov    %rcx,0x70(%rbx)
  81d017:	mov    0x2f8(%rbx),%rcx
  81d01e:	mov    0x300(%rbx),%rdx
  81d025:	and    %rdx,%rax
  81d028:	movdqu (%rcx,%rax,1),%xmm0
  81d02d:	pmovmskb %xmm0,%esi
  81d031:	test   %esi,%esi
  81d033:	je     81d0ad <<gpui_gpu::renderer::RendererState>::correction+0x36d>
  81d035:	tzcnt  %esi,%esi
  81d039:	add    %rax,%rsi
  81d03c:	and    %rdx,%rsi
  81d03f:	movzbl (%rcx,%rsi,1),%eax
  81d043:	test   %al,%al
  81d045:	jns    81d100 <<gpui_gpu::renderer::RendererState>::correction+0x3c0>
  81d04b:	lea    -0x10(%rsi),%rdi
  81d04f:	and    %rdx,%rdi
  81d052:	mov    %r15b,(%rcx,%rsi,1)
  81d056:	mov    %r15b,0x10(%rcx,%rdi,1)
  81d05b:	neg    %rsi
  81d05e:	lea    (%rsi,%rsi,8),%rsi
  81d062:	lea    (%rcx,%rsi,4),%rdx
  81d066:	and    $0x1,%al
  81d068:	movzbl %al,%eax
  81d06b:	sub    %rax,0x308(%rbx)
  81d072:	mov    %r14,-0x24(%rcx,%rsi,4)
  81d077:	movdqa 0x40(%rsp),%xmm0
  81d07d:	movdqu %xmm0,-0x1c(%rcx,%rsi,4)
  81d083:	mov    0x50(%rsp),%rax
  81d088:	mov    %rax,-0xc(%rcx,%rsi,4)
  81d08d:	mov    %r12d,-0x4(%rcx,%rsi,4)
  81d092:	incq   0x310(%rbx)
  81d099:	mov    -0x4(%rdx),%eax
  81d09c:	add    $0x90,%rsp
  81d0a3:	pop    %rbx
  81d0a4:	pop    %r12
  81d0a6:	pop    %r13
  81d0a8:	pop    %r14
  81d0aa:	pop    %r15
  81d0ac:	ret
  81d0ad:	mov    $0x10,%edi
  81d0b2:	add    %rdi,%rax
  81d0b5:	and    %rdx,%rax
  81d0b8:	movdqu (%rcx,%rax,1),%xmm0
  81d0bd:	pmovmskb %xmm0,%esi
  81d0c1:	add    $0x10,%rdi
  81d0c5:	test   %esi,%esi
  81d0c7:	jne    81d035 <<gpui_gpu::renderer::RendererState>::correction+0x2f5>
  81d0cd:	jmp    81d0b2 <<gpui_gpu::renderer::RendererState>::correction+0x372>
  81d0cf:	lea    0x2f8(%rbx),%rdi
  81d0d6:	mov    $0x1,%esi
  81d0db:	mov    %r14,%rdx
  81d0de:	mov    $0x1,%ecx
  81d0e3:	mov    %rax,%r14
  81d0e6:	call   *0x662504(%rip)        # e7f5f0 <_DYNAMIC+0x668>
  81d0ec:	movapd 0x20(%rsp),%xmm6
  81d0f2:	movapd 0x30(%rsp),%xmm5
  81d0f8:	mov    %r14,%rax
  81d0fb:	jmp    81cf8c <<gpui_gpu::renderer::RendererState>::correction+0x24c>
  81d100:	movdqa (%rcx),%xmm0
  81d104:	pmovmskb %xmm0,%eax
  81d108:	tzcnt  %eax,%esi
  81d10c:	movzbl (%rcx,%rsi,1),%eax
  81d110:	jmp    81d04b <<gpui_gpu::renderer::RendererState>::correction+0x30b>

FUNCTION <gpui_gpu::renderer::RendererState>::prepare_atlas bytes=663 frame=600

/tmp/gpui-legacy-coverage-codegen/legacy277/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081d120 <<gpui_gpu::renderer::RendererState>::prepare_atlas>:
  81d120:	push   %rbp
  81d121:	push   %r15
  81d123:	push   %r14
  81d125:	push   %r13
  81d127:	push   %r12
  81d129:	push   %rbx
  81d12a:	sub    $0x228,%rsp
  81d131:	mov    %rsi,%r14
  81d134:	test   %r8d,%r8d
  81d137:	je     81d1cb <<gpui_gpu::renderer::RendererState>::prepare_atlas+0xab>
  81d13d:	mov    %rdi,0x10(%rsp)
  81d142:	mov    0x110(%rcx),%rbp
  81d149:	test   %rbp,%rbp
  81d14c:	je     81d22f <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x10f>
  81d152:	mov    0x108(%rcx),%r13
  81d159:	shl    $0x3,%rbp
  81d15d:	mov    %r14,0x8(%rsp)
  81d162:	lea    0x78(%r14),%rdi
  81d166:	mov    %rdx,0x18(%rsp)
  81d16b:	lea    0x8(%rdx),%rax
  81d16f:	mov    %rax,0x20(%rsp)
  81d174:	xor    %ebx,%ebx
  81d176:	lea    0x28(%rsp),%r15
  81d17b:	xor    %r12d,%r12d
  81d17e:	xchg   %ax,%ax
  81d180:	mov    0x0(%r13,%r12,1),%rax
  81d185:	movups 0x28(%rax),%xmm0
  81d189:	lea    0x38(%rsp),%rcx
  81d18e:	movups %xmm0,(%rcx)
  81d191:	movups 0x18(%rax),%xmm0
  81d195:	movups %xmm0,0x28(%rsp)
  81d19a:	movups 0x38(%rax),%xmm0
  81d19e:	movups %xmm0,0x48(%rsp)
  81d1a3:	mov    %rdi,%r14
  81d1a6:	mov    0x20(%rsp),%rsi
  81d1ab:	mov    %r15,%rdx
  81d1ae:	call   81c900 <<gpui_gpu::renderer::Atlas>::insert>
  81d1b3:	test   $0x1,%al
  81d1b5:	je     81d236 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x116>
  81d1b7:	add    %rdx,%rbx
  81d1ba:	add    $0x8,%r12
  81d1be:	cmp    %r12,%rbp
  81d1c1:	mov    %r14,%rdi
  81d1c4:	jne    81d180 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x60>
  81d1c6:	jmp    81d33e <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x21e>
  81d1cb:	cmpl   $0x1,0x150(%r14)
  81d1d3:	jne    81d1e5 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0xc5>
  81d1d5:	mov    0x138(%r14),%rax
  81d1dc:	add    0x130(%r14),%rax
  81d1e3:	je     81d21c <<gpui_gpu::renderer::RendererState>::prepare_atlas+0xfc>
  81d1e5:	mov    %rdi,%rbx
  81d1e8:	add    $0x78,%r14
  81d1ec:	lea    0x58(%rsp),%rdi
  81d1f1:	mov    %rdx,%rsi
  81d1f4:	mov    $0x1,%edx
  81d1f9:	call   81c630 <<gpui_gpu::renderer::Atlas>::new>
  81d1fe:	mov    %r14,%rdi
  81d201:	call   81b420 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81d206:	lea    0x58(%rsp),%rsi
  81d20b:	mov    $0xe8,%edx
  81d210:	mov    %r14,%rdi
  81d213:	call   *0x66200f(%rip)        # e7f228 <memcpy@GLIBC_2.14>
  81d219:	mov    %rbx,%rdi
  81d21c:	movq   $0x0,0x8(%rdi)
  81d224:	movl   $0xffffffff,(%rdi)
  81d22a:	jmp    81d34d <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x22d>
  81d22f:	xor    %ebx,%ebx
  81d231:	jmp    81d33e <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x21e>
  81d236:	mov    0x8(%rsp),%rax
  81d23b:	mov    0x150(%rax),%eax
  81d241:	cmp    $0x81,%eax
  81d246:	mov    $0x80,%edx
  81d24b:	cmovae %eax,%edx
  81d24e:	add    %edx,%edx
  81d250:	cmp    $0x800,%edx
  81d256:	mov    $0x800,%eax
  81d25b:	cmovae %eax,%edx
  81d25e:	lea    0x140(%rsp),%r12
  81d266:	mov    %r12,%rdi
  81d269:	mov    0x18(%rsp),%rsi
  81d26e:	mov    %edx,0x8(%rsp)
  81d272:	call   81c630 <<gpui_gpu::renderer::Atlas>::new>
  81d277:	xor    %r15d,%r15d
  81d27a:	nopw   0x0(%rax,%rax,1)
  81d280:	mov    0x0(%r13,%r15,1),%rax
  81d285:	movups 0x28(%rax),%xmm0
  81d289:	lea    0x68(%rsp),%rcx
  81d28e:	movups %xmm0,(%rcx)
  81d291:	movups 0x18(%rax),%xmm0
  81d295:	movups %xmm0,0x58(%rsp)
  81d29a:	movups 0x38(%rax),%xmm0
  81d29e:	movups %xmm0,0x78(%rsp)
  81d2a3:	mov    %r12,%rdi
  81d2a6:	mov    0x20(%rsp),%rsi
  81d2ab:	lea    0x58(%rsp),%rdx
  81d2b0:	call   81c900 <<gpui_gpu::renderer::Atlas>::insert>
  81d2b5:	cmp    $0x1,%rax
  81d2b9:	jne    81d2c9 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x1a9>
  81d2bb:	add    %rdx,%rbx
  81d2be:	add    $0x8,%r15
  81d2c2:	cmp    %r15,%rbp
  81d2c5:	jne    81d280 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x160>
  81d2c7:	jmp    81d30b <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x1eb>
  81d2c9:	mov    0x8(%rsp),%r15d
  81d2ce:	cmp    $0x800,%r15d
  81d2d5:	je     81d35f <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x23f>
  81d2db:	mov    %r12,%rdi
  81d2de:	call   81b420 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81d2e3:	add    %r15d,%r15d
  81d2e6:	cmp    $0x800,%r15d
  81d2ed:	mov    $0x800,%eax
  81d2f2:	cmovae %eax,%r15d
  81d2f6:	mov    %r12,%rdi
  81d2f9:	mov    0x18(%rsp),%rsi
  81d2fe:	mov    %r15d,0x8(%rsp)
  81d303:	mov    %r15d,%edx
  81d306:	jmp    81d272 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x152>
  81d30b:	lea    0x58(%rsp),%rdi
  81d310:	lea    0x140(%rsp),%rsi
  81d318:	mov    $0xe8,%edx
  81d31d:	call   *0x661f05(%rip)        # e7f228 <memcpy@GLIBC_2.14>
  81d323:	mov    %r14,%rdi
  81d326:	call   81b420 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81d32b:	lea    0x58(%rsp),%rsi
  81d330:	mov    $0xe8,%edx
  81d335:	mov    %r14,%rdi
  81d338:	call   *0x661eea(%rip)        # e7f228 <memcpy@GLIBC_2.14>
  81d33e:	mov    0x10(%rsp),%rax
  81d343:	mov    %rbx,0x8(%rax)
  81d347:	movl   $0xffffffff,(%rax)
  81d34d:	add    $0x228,%rsp
  81d354:	pop    %rbx
  81d355:	pop    %r12
  81d357:	pop    %r13
  81d359:	pop    %r14
  81d35b:	pop    %r15
  81d35d:	pop    %rbp
  81d35e:	ret
  81d35f:	mov    0x10(%rsp),%rax
  81d364:	movl   $0x7,(%rax)
  81d36a:	lea    0x140(%rsp),%rdi
  81d372:	call   81b420 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81d377:	jmp    81d34d <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x22d>
  81d379:	jmp    81d37b <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x25b>
  81d37b:	mov    %rax,%rbx
  81d37e:	lea    0x58(%rsp),%rsi
  81d383:	mov    $0xe8,%edx
  81d388:	mov    %r14,%rdi
  81d38b:	call   *0x661e97(%rip)        # e7f228 <memcpy@GLIBC_2.14>
  81d391:	mov    %rbx,%rdi
  81d394:	call   e2bd40 <_Unwind_Resume@plt>
  81d399:	mov    %rax,%rbx
  81d39c:	lea    0x140(%rsp),%rdi
  81d3a4:	call   81b420 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81d3a9:	mov    %rbx,%rdi
  81d3ac:	call   e2bd40 <_Unwind_Resume@plt>
  81d3b1:	call   *0x661e21(%rip)        # e7f1d8 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::RendererState>::new bytes=1527 frame=952

/tmp/gpui-legacy-coverage-codegen/legacy277/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081d3c0 <<gpui_gpu::renderer::RendererState>::new>:
  81d3c0:	push   %r15
  81d3c2:	push   %r14
  81d3c4:	push   %r13
  81d3c6:	push   %r12
  81d3c8:	push   %rbx
  81d3c9:	sub    $0x390,%rsp
  81d3d0:	mov    %rsi,%r14
  81d3d3:	mov    %rdi,%rbx
  81d3d6:	lea    -0x748be3(%rip),%rax        # d47fa <anon.e7af5e0dba0d7261d22cb76253955a85.28.llvm.7635581776195589086+0xa>
  81d3dd:	mov    %rax,0xd8(%rsp)
  81d3e5:	movq   $0x7,0xe0(%rsp)
  81d3f1:	movq   $0x30,0xe8(%rsp)
  81d3fd:	movl   $0x48,0xf0(%rsp)
  81d408:	movb   $0x0,0xf4(%rsp)
  81d410:	mov    0x662191(%rip),%r15        # e7f5a8 <_DYNAMIC+0x620>
  81d417:	lea    0x10(%rsp),%rdi
  81d41c:	lea    0xd8(%rsp),%rdx
  81d424:	call   *%r15
  81d427:	movq   $0x30,0x30(%rsp)
  81d430:	lea    -0x748c36(%rip),%rax        # d4801 <anon.e7af5e0dba0d7261d22cb76253955a85.28.llvm.7635581776195589086+0x11>
  81d437:	mov    %rax,0xd8(%rsp)
  81d43f:	movq   $0x5,0xe0(%rsp)
  81d44b:	movq   $0x10,0xe8(%rsp)
  81d457:	movl   $0x88,0xf0(%rsp)
  81d462:	movb   $0x0,0xf4(%rsp)
  81d46a:	lea    0x38(%rsp),%rdi
  81d46f:	lea    0xd8(%rsp),%rdx
  81d477:	mov    %r14,%rsi
  81d47a:	call   *%r15
  81d47d:	movq   $0x10,0x58(%rsp)
  81d486:	lea    -0x748c87(%rip),%rax        # d4806 <anon.e7af5e0dba0d7261d22cb76253955a85.28.llvm.7635581776195589086+0x16>
  81d48d:	mov    %rax,0xd8(%rsp)
  81d495:	movq   $0x5,0xe0(%rsp)
  81d4a1:	movq   $0x8,0xe8(%rsp)
  81d4ad:	movl   $0x88,0xf0(%rsp)
  81d4b8:	movb   $0x0,0xf4(%rsp)
  81d4c0:	lea    0x60(%rsp),%rdi
  81d4c5:	lea    0xd8(%rsp),%rdx
  81d4cd:	mov    %r14,%rsi
  81d4d0:	call   *0x6620d2(%rip)        # e7f5a8 <_DYNAMIC+0x620>
  81d4d6:	movq   $0x8,0x80(%rsp)
  81d4e2:	lea    -0x748cde(%rip),%rax        # d480b <anon.e7af5e0dba0d7261d22cb76253955a85.28.llvm.7635581776195589086+0x1b>
  81d4e9:	mov    %rax,0xd8(%rsp)
  81d4f1:	movq   $0x7,0xe0(%rsp)
  81d4fd:	movq   $0x4,0xe8(%rsp)
  81d509:	movl   $0x88,0xf0(%rsp)
  81d514:	movb   $0x0,0xf4(%rsp)
  81d51c:	lea    0x88(%rsp),%rdi
  81d524:	lea    0xd8(%rsp),%rdx
  81d52c:	mov    %r14,%rsi
  81d52f:	call   *0x662073(%rip)        # e7f5a8 <_DYNAMIC+0x620>
  81d535:	movq   $0x4,0xa8(%rsp)
  81d541:	lea    -0x748d36(%rip),%rax        # d4812 <anon.e7af5e0dba0d7261d22cb76253955a85.28.llvm.7635581776195589086+0x22>
  81d548:	mov    %rax,0xd8(%rsp)
  81d550:	movq   $0x11,0xe0(%rsp)
  81d55c:	movq   $0x20,0xe8(%rsp)
  81d568:	movl   $0x88,0xf0(%rsp)
  81d573:	movb   $0x0,0xf4(%rsp)
  81d57b:	lea    0xb0(%rsp),%rdi
  81d583:	lea    0xd8(%rsp),%rdx
  81d58b:	mov    %r14,%rsi
  81d58e:	call   *0x662014(%rip)        # e7f5a8 <_DYNAMIC+0x620>
  81d594:	movq   $0x20,0xd0(%rsp)
  81d5a0:	lea    0x2a8(%rsp),%rdi
  81d5a8:	mov    %r14,%rsi
  81d5ab:	mov    $0x1,%edx
  81d5b0:	call   81c630 <<gpui_gpu::renderer::Atlas>::new>
  81d5b5:	mov    0x18(%r14),%r13
  81d5b9:	lock incq 0x0(%r13)
  81d5be:	jle    81d8f3 <<gpui_gpu::renderer::RendererState>::new+0x533>
  81d5c4:	mov    %r13,0x8(%rsp)
  81d5c9:	mov    0x30(%rsp),%rax
  81d5ce:	mov    %rax,0x1e0(%rsp)
  81d5d6:	movups 0x10(%rsp),%xmm0
  81d5db:	movups 0x20(%rsp),%xmm1
  81d5e0:	movaps %xmm1,0x1d0(%rsp)
  81d5e8:	movaps %xmm0,0x1c0(%rsp)
  81d5f0:	mov    0x58(%rsp),%rax
  81d5f5:	mov    %rax,0x210(%rsp)
  81d5fd:	movups 0x38(%rsp),%xmm0
  81d602:	movups 0x48(%rsp),%xmm1
  81d607:	movaps %xmm1,0x200(%rsp)
  81d60f:	movaps %xmm0,0x1f0(%rsp)
  81d617:	mov    0x80(%rsp),%rax
  81d61f:	mov    %rax,0x240(%rsp)
  81d627:	movups 0x60(%rsp),%xmm0
  81d62c:	movups 0x70(%rsp),%xmm1
  81d631:	movaps %xmm1,0x230(%rsp)
  81d639:	movaps %xmm0,0x220(%rsp)
  81d641:	mov    0xa8(%rsp),%rax
  81d649:	mov    %rax,0x270(%rsp)
  81d651:	movups 0x88(%rsp),%xmm0
  81d659:	movups 0x98(%rsp),%xmm1
  81d661:	movaps %xmm1,0x260(%rsp)
  81d669:	movaps %xmm0,0x250(%rsp)
  81d671:	mov    0xd0(%rsp),%rax
  81d679:	mov    %rax,0x2a0(%rsp)
  81d681:	movups 0xb0(%rsp),%xmm0
  81d689:	movups 0xc0(%rsp),%xmm1
  81d691:	movaps %xmm1,0x290(%rsp)
  81d699:	movaps %xmm0,0x280(%rsp)
  81d6a1:	lea    0xd8(%rsp),%rdi
  81d6a9:	lea    0x2a8(%rsp),%rsi
  81d6b1:	mov    $0xe8,%edx
  81d6b6:	call   *0x661b6c(%rip)        # e7f228 <memcpy@GLIBC_2.14>
  81d6bc:	mov    %fs:0x0,%rax
  81d6c5:	lea    -0x28(%rax),%rax
  81d6cc:	mov    %rax,%r12
  81d6cf:	cmpb   $0x1,0x10(%rax)
  81d6d3:	jne    81d8d3 <<gpui_gpu::renderer::RendererState>::new+0x513>
  81d6d9:	mov    (%r12),%r14
  81d6dd:	mov    0x8(%r12),%r15
  81d6e2:	lea    0x1(%r14),%rax
  81d6e6:	mov    %rax,(%r12)
  81d6ea:	mov    %r13,0x228(%rbx)
  81d6f1:	mov    0x30(%rsp),%rax
  81d6f6:	mov    %rax,0x250(%rbx)
  81d6fd:	movups 0x10(%rsp),%xmm0
  81d702:	movups 0x20(%rsp),%xmm1
  81d707:	movups %xmm1,0x240(%rbx)
  81d70e:	movups %xmm0,0x230(%rbx)
  81d715:	mov    0x58(%rsp),%rax
  81d71a:	mov    %rax,0x278(%rbx)
  81d721:	movups 0x38(%rsp),%xmm0
  81d726:	movups 0x48(%rsp),%xmm1
  81d72b:	movups %xmm1,0x268(%rbx)
  81d732:	movups %xmm0,0x258(%rbx)
  81d739:	mov    0x80(%rsp),%rax
  81d741:	mov    %rax,0x2a0(%rbx)
  81d748:	movups 0x60(%rsp),%xmm0
  81d74d:	movups 0x70(%rsp),%xmm1
  81d752:	movups %xmm1,0x290(%rbx)
  81d759:	movups %xmm0,0x280(%rbx)
  81d760:	movups 0x88(%rsp),%xmm0
  81d768:	movups 0x98(%rsp),%xmm1
  81d770:	movups %xmm0,0x2a8(%rbx)
  81d777:	movups %xmm1,0x2b8(%rbx)
  81d77e:	mov    0xa8(%rsp),%rax
  81d786:	mov    %rax,0x2c8(%rbx)
  81d78d:	movups 0xb0(%rsp),%xmm0
  81d795:	movups 0xc0(%rsp),%xmm1
  81d79d:	movups %xmm0,0x2d0(%rbx)
  81d7a4:	movups %xmm1,0x2e0(%rbx)
  81d7ab:	mov    0xd0(%rsp),%rax
  81d7b3:	mov    %rax,0x2f0(%rbx)
  81d7ba:	lea    0x78(%rbx),%rdi
  81d7be:	lea    0x2a8(%rsp),%rsi
  81d7c6:	mov    $0xe8,%edx
  81d7cb:	call   *0x661a57(%rip)        # e7f228 <memcpy@GLIBC_2.14>
  81d7d1:	movq   $0x0,0x328(%rbx)
  81d7dc:	movq   $0x0,(%rbx)
  81d7e3:	movq   $0x4,0x8(%rbx)
  81d7eb:	xorps  %xmm0,%xmm0
  81d7ee:	movups %xmm0,0x10(%rbx)
  81d7f2:	movq   $0x4,0x20(%rbx)
  81d7fa:	movups %xmm0,0x28(%rbx)
  81d7fe:	movq   $0x4,0x38(%rbx)
  81d806:	movups %xmm0,0x40(%rbx)
  81d80a:	movq   $0x4,0x50(%rbx)
  81d812:	movups %xmm0,0x58(%rbx)
  81d816:	movq   $0x4,0x68(%rbx)
  81d81e:	movq   $0x0,0x70(%rbx)
  81d826:	movups 0x61031b(%rip),%xmm1        # e2db48 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x110>
  81d82d:	movups %xmm1,0x2f8(%rbx)
  81d834:	movups 0x61031d(%rip),%xmm1        # e2db58 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x120>
  81d83b:	movups %xmm1,0x308(%rbx)
  81d842:	mov    %r14,0x318(%rbx)
  81d849:	mov    %r15,0x320(%rbx)
  81d850:	movw   $0x101,0x340(%rbx)
  81d859:	movq   $0x0,0x330(%rbx)
  81d864:	movups %xmm0,0x210(%rbx)
  81d86b:	movups %xmm0,0x200(%rbx)
  81d872:	movups %xmm0,0x1f0(%rbx)
  81d879:	movups %xmm0,0x1e0(%rbx)
  81d880:	movups %xmm0,0x1d0(%rbx)
  81d887:	movups %xmm0,0x1c0(%rbx)
  81d88e:	movups %xmm0,0x1b0(%rbx)
  81d895:	movups %xmm0,0x1a0(%rbx)
  81d89c:	movups %xmm0,0x190(%rbx)
  81d8a3:	movups %xmm0,0x180(%rbx)
  81d8aa:	movups %xmm0,0x170(%rbx)
  81d8b1:	movups %xmm0,0x160(%rbx)
  81d8b8:	movb   $0x0,0x220(%rbx)
  81d8bf:	mov    %rbx,%rax
  81d8c2:	add    $0x390,%rsp
  81d8c9:	pop    %rbx
  81d8ca:	pop    %r12
  81d8cc:	pop    %r13
  81d8ce:	pop    %r14
  81d8d0:	pop    %r15
  81d8d2:	ret
  81d8d3:	call   *0x661cd7(%rip)        # e7f5b0 <_DYNAMIC+0x628>
  81d8d9:	mov    %rax,%r14
  81d8dc:	mov    %rdx,%r15
  81d8df:	mov    %rax,(%r12)
  81d8e3:	mov    %rdx,0x8(%r12)
  81d8e8:	movb   $0x1,0x10(%r12)
  81d8ee:	jmp    81d6e2 <<gpui_gpu::renderer::RendererState>::new+0x322>
  81d8f3:	ud2
  81d8f5:	mov    %rax,%rbx
  81d8f8:	lea    0xd8(%rsp),%rdi
  81d900:	call   81b420 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81d905:	lea    0x280(%rsp),%rdi
  81d90d:	call   81b500 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81d912:	lea    0x250(%rsp),%rdi
  81d91a:	call   81b500 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81d91f:	lea    0x220(%rsp),%rdi
  81d927:	call   81b500 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81d92c:	lea    0x1f0(%rsp),%rdi
  81d934:	call   81b500 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81d939:	lea    0x1c0(%rsp),%rdi
  81d941:	call   81b500 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81d946:	lock decq 0x0(%r13)
  81d94b:	jne    81d9a9 <<gpui_gpu::renderer::RendererState>::new+0x5e9>
  81d94d:	lea    0x8(%rsp),%rdi
  81d952:	call   *0x661a98(%rip)        # e7f3f0 <_DYNAMIC+0x468>
  81d958:	jmp    81d9a9 <<gpui_gpu::renderer::RendererState>::new+0x5e9>
  81d95a:	mov    %rax,%rbx
  81d95d:	lea    0xb0(%rsp),%rdi
  81d965:	call   81b500 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81d96a:	jmp    81d96f <<gpui_gpu::renderer::RendererState>::new+0x5af>
  81d96c:	mov    %rax,%rbx
  81d96f:	lea    0x88(%rsp),%rdi
  81d977:	call   81b500 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81d97c:	jmp    81d981 <<gpui_gpu::renderer::RendererState>::new+0x5c1>
  81d97e:	mov    %rax,%rbx
  81d981:	lea    0x60(%rsp),%rdi
  81d986:	call   81b500 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81d98b:	jmp    81d990 <<gpui_gpu::renderer::RendererState>::new+0x5d0>
  81d98d:	mov    %rax,%rbx
  81d990:	lea    0x38(%rsp),%rdi
  81d995:	call   81b500 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81d99a:	jmp    81d99f <<gpui_gpu::renderer::RendererState>::new+0x5df>
  81d99c:	mov    %rax,%rbx
  81d99f:	lea    0x10(%rsp),%rdi
  81d9a4:	call   81b500 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81d9a9:	mov    %rbx,%rdi
  81d9ac:	call   e2bd40 <_Unwind_Resume@plt>
  81d9b1:	call   *0x661821(%rip)        # e7f1d8 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::RendererState>::render bytes=9296 frame=1432

/tmp/gpui-legacy-coverage-codegen/legacy277/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081d9c0 <<gpui_gpu::renderer::RendererState>::render>:
  81d9c0:	push   %rbp
  81d9c1:	push   %r15
  81d9c3:	push   %r14
  81d9c5:	push   %r13
  81d9c7:	push   %r12
  81d9c9:	push   %rbx
  81d9ca:	sub    $0x568,%rsp
  81d9d1:	mov    0x228(%rsi),%rax
  81d9d8:	mov    0x18(%rdx),%r9
  81d9dc:	cmp    %r9,%rax
  81d9df:	je     81d9fd <<gpui_gpu::renderer::RendererState>::render+0x3d>
  81d9e1:	mov    0x10(%rax),%r10
  81d9e5:	cmp    0x10(%r9),%r10
  81d9e9:	jne    81dacb <<gpui_gpu::renderer::RendererState>::render+0x10b>
  81d9ef:	mov    0x18(%rax),%rax
  81d9f3:	cmp    0x18(%r9),%rax
  81d9f7:	jne    81dacb <<gpui_gpu::renderer::RendererState>::render+0x10b>
  81d9fd:	lea    0x330(%rsi),%rbx
  81da04:	mov    0x330(%rsi),%rax
  81da0b:	test   %rax,%rax
  81da0e:	je     81da3d <<gpui_gpu::renderer::RendererState>::render+0x7d>
  81da10:	lock decq (%rax)
  81da14:	jne    81da3d <<gpui_gpu::renderer::RendererState>::render+0x7d>
  81da16:	mov    %rdi,%r14
  81da19:	mov    %rbx,%rdi
  81da1c:	mov    %rsi,%r12
  81da1f:	mov    %r8,%r13
  81da22:	mov    %rdx,%r15
  81da25:	mov    %rcx,%rbp
  81da28:	call   *0x661a72(%rip)        # e7f4a0 <_DYNAMIC+0x518>
  81da2e:	mov    %rbp,%rcx
  81da31:	mov    %r15,%rdx
  81da34:	mov    %r13,%r8
  81da37:	mov    %r12,%rsi
  81da3a:	mov    %r14,%rdi
  81da3d:	movq   $0x0,0x330(%rsi)
  81da48:	mov    (%rcx),%r13d
  81da4b:	mov    0x8(%rcx),%r9d
  81da4f:	movzbl 0xd(%rcx),%eax
  81da53:	test   %r9d,%r9d
  81da56:	sets   %r10b
  81da5a:	and    $0x7fffffff,%r9d
  81da61:	lea    -0x800000(%r9),%r11d
  81da68:	cmp    $0x7f000000,%r11d
  81da6f:	setb   %r11b
  81da73:	and    %r10b,%r11b
  81da76:	lea    -0x1(%r9),%ebp
  81da7a:	cmp    $0x7fffff,%ebp
  81da80:	setb   %bpl
  81da84:	and    %r10b,%bpl
  81da87:	test   %r9d,%r9d
  81da8a:	sete   %r10b
  81da8e:	cmp    $0x7f800000,%r9d
  81da95:	sete   %r14b
  81da99:	or     %r10b,%r14b
  81da9c:	cmp    $0x7f800001,%r9d
  81daa3:	setge  %r9b
  81daa7:	or     %r14b,%r9b
  81daaa:	or     %bpl,%r9b
  81daad:	test   %r13d,%r13d
  81dab0:	setne  %r10b
  81dab4:	and    %al,%r10b
  81dab7:	or     %r11b,%r10b
  81daba:	or     %r9b,%r10b
  81dabd:	test   $0x1,%r10b
  81dac1:	je     81dae6 <<gpui_gpu::renderer::RendererState>::render+0x126>
  81dac3:	movl   $0x3,(%rdi)
  81dac9:	jmp    81dad1 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81dacb:	movl   $0x4,(%rdi)
  81dad1:	mov    %rdi,%rax
  81dad4:	add    $0x568,%rsp
  81dadb:	pop    %rbx
  81dadc:	pop    %r12
  81dade:	pop    %r13
  81dae0:	pop    %r14
  81dae2:	pop    %r15
  81dae4:	pop    %rbp
  81dae5:	ret
  81dae6:	movd   0x4(%rcx),%xmm2
  81daeb:	movzbl 0xc(%rcx),%ebp
  81daef:	test   $0x1,%r13b
  81daf3:	je     81db6b <<gpui_gpu::renderer::RendererState>::render+0x1ab>
  81daf5:	movd   %xmm2,%r9d
  81dafa:	test   %r9d,%r9d
  81dafd:	sets   %r10b
  81db01:	and    $0x7fffffff,%r9d
  81db08:	lea    -0x800000(%r9),%r11d
  81db0f:	cmp    $0x7f000000,%r11d
  81db16:	setb   %r11b
  81db1a:	and    %r10b,%r11b
  81db1d:	lea    -0x1(%r9),%r14d
  81db21:	cmp    $0x7fffff,%r14d
  81db28:	setb   %r14b
  81db2c:	and    %r10b,%r14b
  81db2f:	test   %r9d,%r9d
  81db32:	sete   %r10b
  81db36:	cmp    $0x7f800000,%r9d
  81db3d:	sete   %r15b
  81db41:	or     %r10b,%r15b
  81db44:	cmp    $0x7f800001,%r9d
  81db4b:	setge  %r9b
  81db4f:	or     %r15b,%r9b
  81db52:	or     %r14b,%r9b
  81db55:	or     %r11b,%r9b
  81db58:	jne    81dac3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81db5e:	ucomiss -0x76ecb9(%rip),%xmm2        # aeeac <anon.630a3fff68f6bca64b568be97512ab45.57.llvm.826976926275214120+0x1c>
  81db65:	ja     81dac3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81db6b:	mov    0x28(%rcx),%r14d
  81db6f:	cmp    %r14d,0x20(%r8)
  81db73:	jne    81dac3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81db79:	mov    0x2c(%rcx),%r15d
  81db7d:	cmp    %r15d,0x24(%r8)
  81db81:	jne    81dac3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81db87:	mov    0x38(%r8),%r12d
  81db8b:	cmp    0x20(%rdx),%r12d
  81db8f:	jne    81dac3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81db95:	cmp    $0x4c,%r12d
  81db99:	jne    81dbbe <<gpui_gpu::renderer::RendererState>::render+0x1fe>
  81db9b:	movq   0x3c(%r8),%xmm0
  81dba1:	movq   0x24(%rdx),%xmm1
  81dba6:	pcmpeqd %xmm0,%xmm1
  81dbaa:	pshufd $0x50,%xmm1,%xmm0
  81dbaf:	movmskpd %xmm0,%r9d
  81dbb4:	cmp    $0x3,%r9d
  81dbb8:	jne    81dac3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81dbbe:	cmp    $0x4000,%r15d
  81dbc5:	ja     81dbfb <<gpui_gpu::renderer::RendererState>::render+0x23b>
  81dbc7:	cmp    $0x4000,%r14d
  81dbce:	ja     81dbfb <<gpui_gpu::renderer::RendererState>::render+0x23b>
  81dbd0:	mov    %r15,%r9
  81dbd3:	imul   %r14,%r9
  81dbd7:	add    $0xfffffffffeffffff,%r9
  81dbde:	cmp    $0xffffffffff000000,%r9
  81dbe5:	jb     81dbfb <<gpui_gpu::renderer::RendererState>::render+0x23b>
  81dbe7:	mov    0x10(%rcx),%r11
  81dbeb:	mov    0x80(%r11),%r10
  81dbf2:	cmp    $0x10000,%r10
  81dbf9:	jbe    81dc06 <<gpui_gpu::renderer::RendererState>::render+0x246>
  81dbfb:	movl   $0x6,(%rdi)
  81dc01:	jmp    81dad1 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81dc06:	movd   0x18(%rcx),%xmm0
  81dc0b:	movd   %xmm0,%r9d
  81dc10:	and    $0x7fffffff,%r9d
  81dc17:	cmp    $0x7f7fffff,%r9d
  81dc1e:	jg     81dac3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81dc24:	pand   -0x7704ac(%rip),%xmm0        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81dc2c:	ucomiss -0x76eb2f(%rip),%xmm0        # af104 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81dc33:	ja     81dac3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81dc39:	movd   0x1c(%rcx),%xmm0
  81dc3e:	movd   %xmm0,%r9d
  81dc43:	and    $0x7fffffff,%r9d
  81dc4a:	cmp    $0x7f7fffff,%r9d
  81dc51:	jg     81dac3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81dc57:	pand   -0x7704df(%rip),%xmm0        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81dc5f:	ucomiss -0x76eb62(%rip),%xmm0        # af104 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81dc66:	ja     81dac3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81dc6c:	movd   0x20(%rcx),%xmm0
  81dc71:	movd   %xmm0,%r9d
  81dc76:	and    $0x7fffffff,%r9d
  81dc7d:	cmp    $0x7f7fffff,%r9d
  81dc84:	jg     81dac3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81dc8a:	pand   -0x770512(%rip),%xmm0        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81dc92:	ucomiss -0x76eb95(%rip),%xmm0        # af104 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81dc99:	ja     81dac3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81dc9f:	movd   0x24(%rcx),%xmm0
  81dca4:	movd   %xmm0,%r9d
  81dca9:	and    $0x7fffffff,%r9d
  81dcb0:	cmp    $0x7f7fffff,%r9d
  81dcb7:	jg     81dac3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81dcbd:	movdqa -0x770545(%rip),%xmm1        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81dcc5:	pand   %xmm0,%xmm1
  81dcc9:	ucomiss -0x76ebcc(%rip),%xmm1        # af104 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81dcd0:	ja     81dac3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81dcd6:	xorps  %xmm1,%xmm1
  81dcd9:	ucomiss %xmm1,%xmm0
  81dcdc:	jb     81dac3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81dce2:	movss  -0x76ef6a(%rip),%xmm1        # aed80 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  81dcea:	ucomiss %xmm0,%xmm1
  81dced:	jb     81dac3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81dcf3:	movzwl 0x30(%rcx),%r9d
  81dcf8:	mov    %r9w,0x8(%rsp)
  81dcfe:	movzwl 0x32(%rcx),%r9d
  81dd03:	mov    %r9w,0x10(%rsp)
  81dd09:	cmp    $0x28,%r12d
  81dd0d:	jne    81dd19 <<gpui_gpu::renderer::RendererState>::render+0x359>
  81dd0f:	test   $0x1,%al
  81dd11:	je     81dac3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81dd17:	jmp    81dd34 <<gpui_gpu::renderer::RendererState>::render+0x374>
  81dd19:	test   $0x1,%al
  81dd1b:	jne    81dac3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81dd21:	ucomiss -0x76efa8(%rip),%xmm0        # aed80 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  81dd28:	jne    81dac3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81dd2e:	jp     81dac3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81dd34:	mov    %r11,0x30(%rsp)
  81dd39:	mov    %r10,0x20(%rsp)
  81dd3e:	movss  %xmm1,0xd0(%rsp)
  81dd47:	movd   %xmm2,0x270(%rsp)
  81dd50:	mov    %rdx,0x100(%rsp)
  81dd58:	mov    %r8,0x460(%rsp)
  81dd60:	mov    %rdi,0x50(%rsp)
  81dd65:	lea    0xf(%r14),%rax
  81dd69:	shr    $0x4,%rax
  81dd6d:	lea    0xf(%r15),%edx
  81dd71:	shr    $0x4,%edx
  81dd74:	lea    0x18(%rsi),%rdi
  81dd78:	movq   $0x0,0x28(%rsi)
  81dd80:	mov    %rax,0x38(%rsp)
  81dd85:	imul   %eax,%edx
  81dd88:	mov    %rdi,0x470(%rsp)
  81dd90:	mov    %rsi,(%rsp)
  81dd94:	mov    %rdx,0x28(%rsp)
  81dd99:	mov    %rdx,%rsi
  81dd9c:	xor    %edx,%edx
  81dd9e:	mov    %rcx,0x108(%rsp)
  81dda6:	call   822110 <<alloc::vec::Vec<[u32; 2]>>::resize>
  81ddab:	mov    (%rsp),%rax
  81ddaf:	movq   $0x0,0x10(%rax)
  81ddb7:	mov    0x108(%rsp),%rdi
  81ddbf:	call   *0x66176b(%rip)        # e7f530 <_DYNAMIC+0x5a8>
  81ddc5:	mov    %rdx,%rcx
  81ddc8:	sub    %rax,%rcx
  81ddcb:	cmp    $0x300000,%rcx
  81ddd2:	jbe    81dde4 <<gpui_gpu::renderer::RendererState>::render+0x424>
  81ddd4:	mov    0x50(%rsp),%rdi
  81ddd9:	movl   $0x6,(%rdi)
  81dddf:	jmp    81dad1 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81dde4:	mov    %rcx,%rdi
  81dde7:	shr    $0x3,%rcx
  81ddeb:	movabs $0xaaaaaaaaaaaaaaab,%rsi
  81ddf5:	imul   %rcx,%rsi
  81ddf9:	mov    %rsi,0x18(%rsp)
  81ddfe:	mov    %rax,0x458(%rsp)
  81de06:	mov    %rdx,0x450(%rsp)
  81de0e:	cmp    %rax,%rdx
  81de11:	je     81de3f <<gpui_gpu::renderer::RendererState>::render+0x47f>
  81de13:	mov    $0xaaaaaaab,%eax
  81de18:	imul   %rax,%rdi
  81de1c:	shr    $0x2a,%rdi
  81de20:	mov    0x18(%rsp),%rcx
  81de25:	mov    %ecx,%eax
  81de27:	and    $0x3f,%eax
  81de2a:	add    %rcx,%rdi
  81de2d:	cmp    $0x1,%rax
  81de31:	sbb    $0xffffffffffffffff,%rdi
  81de35:	inc    %rdi
  81de38:	mov    %rdi,0x40(%rsp)
  81de3d:	jmp    81de48 <<gpui_gpu::renderer::RendererState>::render+0x488>
  81de3f:	movq   $0x0,0x40(%rsp)
  81de48:	mov    0x30(%rsp),%rax
  81de4d:	mov    0x98(%rax),%rcx
  81de54:	add    0xb0(%rax),%rcx
  81de5b:	mov    %rax,0x110(%rsp)
  81de63:	movzwl 0x8(%rsp),%eax
  81de68:	mov    %ax,0x130(%rsp)
  81de70:	movzwl 0x10(%rsp),%eax
  81de75:	mov    %ax,0x132(%rsp)
  81de7d:	movq   $0x0,0x118(%rsp)
  81de89:	mov    0x20(%rsp),%rax
  81de8e:	mov    %rax,0x120(%rsp)
  81de96:	mov    %rcx,0x318(%rsp)
  81de9e:	mov    %rcx,0x128(%rsp)
  81dea6:	mov    (%rsp),%rax
  81deaa:	movzbl 0x341(%rax),%edx
  81deb1:	lea    0x478(%rsp),%rdi
  81deb9:	lea    0x110(%rsp),%rsi
  81dec1:	call   81c110 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>>
  81dec6:	mov    0x478(%rsp),%eax
  81decd:	cmp    $0xffffffff,%eax
  81ded0:	je     81df02 <<gpui_gpu::renderer::RendererState>::render+0x542>
  81ded2:	mov    0x47c(%rsp),%ecx
  81ded9:	mov    0x480(%rsp),%rdx
  81dee1:	movdqu 0x488(%rsp),%xmm0
  81deea:	mov    0x50(%rsp),%rdi
  81deef:	movdqu %xmm0,0x10(%rdi)
  81def4:	mov    %eax,(%rdi)
  81def6:	mov    %ecx,0x4(%rdi)
  81def9:	mov    %rdx,0x8(%rdi)
  81defd:	jmp    81dad1 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81df02:	mov    0x40(%rsp),%rdx
  81df07:	add    0x480(%rsp),%rdx
  81df0f:	mov    (%rsp),%rdi
  81df13:	mov    0x10(%rdi),%rsi
  81df17:	mov    $0x4,%ecx
  81df1c:	mov    $0x10,%r8d
  81df22:	call   8234d0 <<alloc::raw_vec::RawVecInner>::try_reserve_exact>
  81df27:	cmp    $0xffffffffffffffff,%rax
  81df2b:	jne    81ddd4 <<gpui_gpu::renderer::RendererState>::render+0x414>
  81df31:	movzwl 0x8(%rsp),%eax
  81df36:	mov    %eax,0x8(%rsp)
  81df3a:	movzwl 0x10(%rsp),%eax
  81df3f:	mov    %eax,0x9c(%rsp)
  81df46:	mov    (%rsp),%rdi
  81df4a:	mov    0x108(%rsp),%rsi
  81df52:	mov    0x18(%rsp),%rdx
  81df57:	call   825430 <gpui_gpu::renderer::slots::write_prefix>
  81df5c:	mov    (%rsp),%rax
  81df60:	lea    0x48(%rax),%rdi
  81df64:	movq   $0x0,0x58(%rax)
  81df6c:	mov    %rdi,0x468(%rsp)
  81df74:	mov    0x28(%rsp),%rsi
  81df79:	xor    %edx,%edx
  81df7b:	call   822230 <<alloc::vec::Vec<u32>>::resize>
  81df80:	mov    (%rsp),%rax
  81df84:	movq   $0x0,0x70(%rax)
  81df8c:	cmpq   $0x0,0x60(%rax)
  81df91:	jne    81dfa1 <<gpui_gpu::renderer::RendererState>::render+0x5e1>
  81df93:	mov    (%rsp),%rax
  81df97:	lea    0x60(%rax),%rdi
  81df9b:	call   *0x661597(%rip)        # e7f538 <_DYNAMIC+0x5b0>
  81dfa1:	mov    (%rsp),%rax
  81dfa5:	mov    0x68(%rax),%rcx
  81dfa9:	pxor   %xmm0,%xmm0
  81dfad:	movdqu %xmm0,0x10(%rcx)
  81dfb2:	movdqu %xmm0,(%rcx)
  81dfb6:	movq   $0x1,0x70(%rax)
  81dfbe:	lea    0x2f8(%rax),%rdi
  81dfc5:	call   824de0 <<hashbrown::raw::RawTable<([u32; 8], u32)>>::clear>
  81dfca:	mov    0x9c(%rsp),%ecx
  81dfd1:	shl    $0x10,%ecx
  81dfd4:	add    0x8(%rsp),%ecx
  81dfd8:	mov    0x30(%rsp),%rax
  81dfdd:	mov    %rax,0x328(%rsp)
  81dfe5:	movq   $0x0,0x330(%rsp)
  81dff1:	mov    0x20(%rsp),%rax
  81dff6:	mov    %rax,0x338(%rsp)
  81dffe:	mov    0x318(%rsp),%rax
  81e006:	mov    %rax,0x340(%rsp)
  81e00e:	mov    %ecx,0x9c(%rsp)
  81e015:	mov    %ecx,0x348(%rsp)
  81e01c:	lea    0x278(%rsp),%rdi
  81e024:	lea    0x328(%rsp),%rsi
  81e02c:	call   *0x66150e(%rip)        # e7f540 <_DYNAMIC+0x5b8>
  81e032:	mov    0x278(%rsp),%rax
  81e03a:	mov    %rax,0x10(%rsp)
  81e03f:	test   %rax,%rax
  81e042:	je     81ed7a <<gpui_gpu::renderer::RendererState>::render+0x13ba>
  81e048:	movq   $0x0,0xb8(%rsp)
  81e054:	movq   $0x0,0x8(%rsp)
  81e05d:	movq   $0x0,0x60(%rsp)
  81e066:	movq   $0x0,0x238(%rsp)
  81e072:	movq   $0x0,0x240(%rsp)
  81e07e:	mov    0x280(%rsp),%rcx
  81e086:	mov    0x288(%rsp),%rdx
  81e08e:	mov    %rdx,0xc0(%rsp)
  81e096:	lea    0x290(%rsp),%rdi
  81e09e:	movups (%rdi),%xmm0
  81e0a1:	movups 0x10(%rdi),%xmm1
  81e0a5:	movups 0x20(%rdi),%xmm2
  81e0a9:	movaps %xmm2,0x300(%rsp)
  81e0b1:	movaps %xmm1,0x2f0(%rsp)
  81e0b9:	movaps %xmm0,0x2e0(%rsp)
  81e0c1:	lea    0x2c0(%rsp),%r8
  81e0c9:	movups (%r8),%xmm0
  81e0cd:	movaps %xmm0,0x440(%rsp)
  81e0d5:	movups 0x40(%rdi),%xmm0
  81e0d9:	movaps %xmm0,0x370(%rsp)
  81e0e1:	mov    (%rsp),%rax
  81e0e5:	movzbl 0x341(%rax),%esi
  81e0ec:	mov    0x10(%rsp),%rax
  81e0f1:	mov    %rax,0x110(%rsp)
  81e0f9:	mov    %rcx,0x28(%rsp)
  81e0fe:	mov    %rcx,0x118(%rsp)
  81e106:	mov    %rdx,0x120(%rsp)
  81e10e:	movups (%rdi),%xmm0
  81e111:	movups 0x10(%rdi),%xmm1
  81e115:	movups 0x20(%rdi),%xmm2
  81e119:	lea    0x128(%rsp),%rax
  81e121:	movups %xmm2,0x20(%rax)
  81e125:	movups %xmm1,0x10(%rax)
  81e129:	movups %xmm0,(%rax)
  81e12c:	movups (%r8),%xmm0
  81e130:	movups %xmm0,0x30(%rax)
  81e134:	movups 0x40(%rdi),%xmm0
  81e138:	movups %xmm0,0x40(%rax)
  81e13c:	lea    0x110(%rsp),%rdi
  81e144:	call   820e70 <gpui_gpu::renderer::compact_group>
  81e149:	mov    %al,0x40(%rsp)
  81e14d:	lea    0x290(%rsp),%rsi
  81e155:	movups (%rsi),%xmm0
  81e158:	movups 0x10(%rsi),%xmm1
  81e15c:	movups 0x20(%rsi),%xmm2
  81e160:	movaps %xmm0,0x520(%rsp)
  81e168:	movaps %xmm1,0x530(%rsp)
  81e170:	movaps %xmm2,0x540(%rsp)
  81e178:	lea    0x2c0(%rsp),%rdx
  81e180:	movdqu (%rdx),%xmm0
  81e184:	movdqa %xmm0,0x550(%rsp)
  81e18d:	mov    (%rsp),%rdi
  81e191:	call   81cd40 <<gpui_gpu::renderer::RendererState>::correction>
  81e196:	mov    %eax,0xb0(%rsp)
  81e19d:	mov    0xc0(%rsp),%rax
  81e1a5:	lea    0x0(,%rax,4),%rax
  81e1ad:	mov    %rax,0x248(%rsp)
  81e1b5:	cmpb   $0x0,0x40(%rsp)
  81e1ba:	je     81e3a2 <<gpui_gpu::renderer::RendererState>::render+0x9e2>
  81e1c0:	mov    0x28(%rsp),%rcx
  81e1c5:	mov    0xc0(%rsp),%rax
  81e1cd:	lea    (%rcx,%rax,4),%rax
  81e1d1:	mov    %rcx,0x420(%rsp)
  81e1d9:	mov    %rax,0x428(%rsp)
  81e1e1:	mov    0x10(%rsp),%rax
  81e1e6:	mov    %rax,0x430(%rsp)
  81e1ee:	movq   $0x0,0x438(%rsp)
  81e1fa:	lea    0x380(%rsp),%rdi
  81e202:	lea    0x420(%rsp),%rsi
  81e20a:	call   821500 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81e20f:	cmpb   $0xff,0x388(%rsp)
  81e217:	je     81e8db <<gpui_gpu::renderer::RendererState>::render+0xf1b>
  81e21d:	pxor   %xmm0,%xmm0
  81e221:	movdqa %xmm0,0xa0(%rsp)
  81e22a:	movdqa %xmm0,0x70(%rsp)
  81e230:	mov    0x380(%rsp),%rdx
  81e238:	add    0x60(%rsp),%rdx
  81e23d:	lea    0x388(%rsp),%rsi
  81e245:	movups 0x38(%rsi),%xmm0
  81e249:	lea    0x111(%rsp),%rax
  81e251:	movups %xmm0,0x37(%rax)
  81e255:	movups 0x48(%rsi),%xmm0
  81e259:	lea    0x128(%rsp),%rcx
  81e261:	movups %xmm0,0x70(%rcx)
  81e265:	mov    0x30(%rsi),%rax
  81e269:	mov    %rax,0x140(%rsp)
  81e271:	movups (%rsi),%xmm0
  81e274:	movups 0x10(%rsi),%xmm1
  81e278:	movups 0x20(%rsi),%xmm2
  81e27c:	movaps %xmm2,0x130(%rsp)
  81e284:	movaps %xmm1,0x120(%rsp)
  81e28c:	movaps %xmm0,0x110(%rsp)
  81e294:	lea    0x290(%rsp),%rax
  81e29c:	movups 0x40(%rax),%xmm0
  81e2a0:	movups %xmm0,0x80(%rcx)
  81e2a7:	movups (%rax),%xmm0
  81e2aa:	movups 0x10(%rax),%xmm1
  81e2ae:	movups 0x20(%rax),%xmm2
  81e2b2:	movups %xmm2,0x50(%rcx)
  81e2b6:	movups %xmm1,0x40(%rcx)
  81e2ba:	movups %xmm0,0x30(%rcx)
  81e2be:	lea    0x2c0(%rsp),%rax
  81e2c6:	movups (%rax),%xmm0
  81e2c9:	movups %xmm0,0x60(%rcx)
  81e2cd:	lea    0x350(%rsp),%rdi
  81e2d5:	lea    0x110(%rsp),%rsi
  81e2dd:	mov    %r14d,%ecx
  81e2e0:	mov    %r15d,%r8d
  81e2e3:	call   820ec0 <gpui_gpu::renderer::validate_draw>
  81e2e8:	mov    0x350(%rsp),%ecx
  81e2ef:	mov    0x354(%rsp),%rax
  81e2f7:	cmp    $0xffffffff,%ecx
  81e2fa:	jne    81ee31 <<gpui_gpu::renderer::RendererState>::render+0x1471>
  81e300:	mov    %eax,%ecx
  81e302:	shr    $0x20,%rax
  81e306:	movd   %ecx,%xmm0
  81e30a:	movaps 0xa0(%rsp),%xmm2
  81e312:	movaps %xmm2,%xmm1
  81e315:	maxss  %xmm0,%xmm1
  81e319:	movaps %xmm1,%xmm3
  81e31c:	cmpunordss %xmm1,%xmm3
  81e321:	movaps %xmm3,%xmm0
  81e324:	andnps %xmm1,%xmm0
  81e327:	andps  %xmm2,%xmm3
  81e32a:	orps   %xmm0,%xmm3
  81e32d:	movaps %xmm3,0x40(%rsp)
  81e332:	movd   %eax,%xmm0
  81e336:	movaps 0x70(%rsp),%xmm2
  81e33b:	movaps %xmm2,%xmm1
  81e33e:	maxss  %xmm0,%xmm1
  81e342:	movaps %xmm1,%xmm3
  81e345:	cmpunordss %xmm1,%xmm3
  81e34a:	movaps %xmm3,%xmm0
  81e34d:	andnps %xmm1,%xmm0
  81e350:	andps  %xmm2,%xmm3
  81e353:	orps   %xmm0,%xmm3
  81e356:	movaps %xmm3,0x80(%rsp)
  81e35e:	lea    0x380(%rsp),%rdi
  81e366:	lea    0x420(%rsp),%rsi
  81e36e:	call   821500 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81e373:	cmpb   $0xff,0x388(%rsp)
  81e37b:	movaps 0x40(%rsp),%xmm0
  81e380:	movaps %xmm0,0xa0(%rsp)
  81e388:	movdqa 0x80(%rsp),%xmm0
  81e391:	movdqa %xmm0,0x70(%rsp)
  81e397:	jne    81e230 <<gpui_gpu::renderer::RendererState>::render+0x870>
  81e39d:	jmp    81e8ee <<gpui_gpu::renderer::RendererState>::render+0xf2e>
  81e3a2:	cmpq   $0x0,0xc0(%rsp)
  81e3ab:	je     81ed26 <<gpui_gpu::renderer::RendererState>::render+0x1366>
  81e3b1:	mov    0xb0(%rsp),%eax
  81e3b8:	or     $0x80000000,%eax
  81e3bd:	mov    %eax,0x26c(%rsp)
  81e3c4:	movq   $0x0,0x80(%rsp)
  81e3d0:	mov    0x28(%rsp),%rax
  81e3d5:	mov    0x80(%rsp),%rcx
  81e3dd:	mov    (%rax,%rcx,1),%edx
  81e3e0:	lea    0x110(%rsp),%rdi
  81e3e8:	mov    0x10(%rsp),%rsi
  81e3ed:	call   81c260 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81e3f2:	movzbl 0x110(%rsp),%edi
  81e3fa:	lea    0x111(%rsp),%rdx
  81e402:	mov    (%rdx),%eax
  81e404:	mov    0x3(%rdx),%ecx
  81e407:	lea    0x4b0(%rsp),%rsi
  81e40f:	mov    %ecx,-0x34(%rsi)
  81e412:	mov    %eax,-0x37(%rsi)
  81e415:	mov    0x118(%rsp),%rcx
  81e41d:	mov    0x2f(%rdx),%rax
  81e421:	mov    %rax,-0x8(%rsi)
  81e425:	movups 0xf(%rdx),%xmm0
  81e429:	movups 0x1f(%rdx),%xmm1
  81e42d:	movups %xmm1,-0x18(%rsi)
  81e431:	movups %xmm0,-0x28(%rsi)
  81e435:	movups 0x37(%rdx),%xmm0
  81e439:	movups %xmm0,(%rsi)
  81e43c:	lea    0x128(%rsp),%rax
  81e444:	movups 0x30(%rax),%xmm0
  81e448:	movups %xmm0,0x50(%rsi)
  81e44c:	lea    0x290(%rsp),%rax
  81e454:	movups 0x40(%rax),%xmm0
  81e458:	movups %xmm0,0x60(%rsi)
  81e45c:	movups (%rax),%xmm0
  81e45f:	movups 0x10(%rax),%xmm1
  81e463:	movups 0x20(%rax),%xmm2
  81e467:	movups %xmm2,0x30(%rsi)
  81e46b:	movups %xmm1,0x20(%rsi)
  81e46f:	movups %xmm0,0x10(%rsi)
  81e473:	lea    0x2c0(%rsp),%rax
  81e47b:	movups (%rax),%xmm0
  81e47e:	movups %xmm0,0x40(%rsi)
  81e482:	mov    %dil,0x70(%rsp)
  81e487:	mov    %dil,0x478(%rsp)
  81e48f:	mov    %rcx,0xa0(%rsp)
  81e497:	mov    %rcx,0x480(%rsp)
  81e49f:	lea    0x110(%rsp),%rdi
  81e4a7:	lea    0x478(%rsp),%rsi
  81e4af:	mov    0x60(%rsp),%rdx
  81e4b4:	mov    %r14d,%ecx
  81e4b7:	mov    %r15d,%r8d
  81e4ba:	call   820ec0 <gpui_gpu::renderer::validate_draw>
  81e4bf:	mov    0x110(%rsp),%eax
  81e4c6:	mov    0x114(%rsp),%rcx
  81e4ce:	mov    %rcx,0x40(%rsp)
  81e4d3:	cmp    $0xffffffff,%eax
  81e4d6:	jne    81eec4 <<gpui_gpu::renderer::RendererState>::render+0x1504>
  81e4dc:	movzbl 0x70(%rsp),%eax
  81e4e1:	cmp    $0x2,%al
  81e4e3:	sete   0x250(%rsp)
  81e4eb:	cmpq   $0x0,0xa0(%rsp)
  81e4f4:	setne  0xf8(%rsp)
  81e4fc:	movups 0x4b0(%rsp),%xmm0
  81e504:	movaps %xmm0,0x220(%rsp)
  81e50c:	cmp    $0x3,%al
  81e50e:	jne    81e5a0 <<gpui_gpu::renderer::RendererState>::render+0xbe0>
  81e514:	movss  0x47c(%rsp),%xmm0
  81e51d:	xorps  %xmm1,%xmm1
  81e520:	ucomiss %xmm1,%xmm0
  81e523:	jne    81e527 <<gpui_gpu::renderer::RendererState>::render+0xb67>
  81e525:	jnp    81e5a0 <<gpui_gpu::renderer::RendererState>::render+0xbe0>
  81e527:	movaps 0x220(%rsp),%xmm5
  81e52f:	movaps %xmm5,%xmm1
  81e532:	unpckhpd %xmm5,%xmm1
  81e536:	movss  -0x76f5d2(%rip),%xmm4        # aef6c <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  81e53e:	mulss  %xmm4,%xmm1
  81e542:	movaps %xmm0,%xmm2
  81e545:	minss  %xmm1,%xmm2
  81e549:	movaps %xmm2,%xmm1
  81e54c:	cmpunordss %xmm2,%xmm1
  81e551:	movaps %xmm1,%xmm3
  81e554:	andnps %xmm2,%xmm3
  81e557:	andps  %xmm0,%xmm1
  81e55a:	orps   %xmm3,%xmm1
  81e55d:	movaps %xmm5,%xmm0
  81e560:	shufps $0xff,%xmm5,%xmm0
  81e564:	mulss  %xmm4,%xmm0
  81e568:	movaps %xmm1,%xmm2
  81e56b:	minss  %xmm0,%xmm2
  81e56f:	movaps %xmm2,%xmm0
  81e572:	cmpunordss %xmm2,%xmm0
  81e577:	andps  %xmm0,%xmm1
  81e57a:	andnps %xmm2,%xmm0
  81e57d:	orps   %xmm1,%xmm0
  81e580:	movd   %xmm0,%eax
  81e584:	mov    %eax,0x70(%rsp)
  81e588:	and    $0xff800000,%eax
  81e58d:	mov    $0x7f000000,%ecx
  81e592:	sub    %eax,%ecx
  81e594:	mov    %ecx,0xa0(%rsp)
  81e59b:	xorps  %xmm0,%xmm0
  81e59e:	jmp    81e5c2 <<gpui_gpu::renderer::RendererState>::render+0xc02>
  81e5a0:	mov    0x510(%rsp),%eax
  81e5a7:	mov    %eax,0x70(%rsp)
  81e5ab:	mov    0x514(%rsp),%eax
  81e5b2:	mov    %eax,0xa0(%rsp)
  81e5b9:	movsd  0x518(%rsp),%xmm0
  81e5c2:	movaps %xmm0,0xe0(%rsp)
  81e5ca:	mov    (%rsp),%rax
  81e5ce:	mov    0x10(%rax),%ecx
  81e5d1:	mov    $0x80000000,%eax
  81e5d6:	or     %eax,%ecx
  81e5d8:	mov    %ecx,0x210(%rsp)
  81e5df:	movups 0x4c0(%rsp),%xmm0
  81e5e7:	movaps %xmm0,0x410(%rsp)
  81e5ef:	movups 0x4c8(%rsp),%xmm0
  81e5f7:	movaps %xmm0,0x3f0(%rsp)
  81e5ff:	movsd  0x4d0(%rsp),%xmm0
  81e608:	movaps %xmm0,0x400(%rsp)
  81e610:	movsd  0x4d8(%rsp),%xmm0
  81e619:	movaps %xmm0,0x3e0(%rsp)
  81e621:	movsd  0x4e0(%rsp),%xmm0
  81e62a:	movsd  %xmm0,0x260(%rsp)
  81e633:	movsd  0x4e8(%rsp),%xmm0
  81e63c:	movsd  %xmm0,0x258(%rsp)
  81e645:	movups 0x4f0(%rsp),%xmm0
  81e64d:	movaps %xmm0,0x200(%rsp)
  81e655:	mov    0x10(%rsp),%rax
  81e65a:	mov    %rax,0x110(%rsp)
  81e662:	mov    0x28(%rsp),%rax
  81e667:	mov    %rax,0x118(%rsp)
  81e66f:	mov    0xc0(%rsp),%rax
  81e677:	mov    %rax,0x120(%rsp)
  81e67f:	movaps 0x2e0(%rsp),%xmm0
  81e687:	movaps 0x2f0(%rsp),%xmm1
  81e68f:	movaps 0x300(%rsp),%xmm2
  81e697:	lea    0x128(%rsp),%rax
  81e69f:	movups %xmm2,0x20(%rax)
  81e6a3:	movups %xmm1,0x10(%rax)
  81e6a7:	movups %xmm0,(%rax)
  81e6aa:	movaps 0x440(%rsp),%xmm0
  81e6b2:	movups %xmm0,0x30(%rax)
  81e6b6:	movaps 0x370(%rsp),%xmm0
  81e6be:	movups %xmm0,0x40(%rax)
  81e6c2:	lea    0x110(%rsp),%rdi
  81e6ca:	call   *0x660e78(%rip)        # e7f548 <_DYNAMIC+0x5c0>
  81e6d0:	mov    0xb0(%rsp),%ecx
  81e6d7:	mov    %ecx,0x58(%rsp)
  81e6db:	test   %eax,%eax
  81e6dd:	je     81e710 <<gpui_gpu::renderer::RendererState>::render+0xd50>
  81e6df:	mov    0x18(%rsp),%rdi
  81e6e4:	mov    %eax,%esi
  81e6e6:	call   8253f0 <gpui_gpu::renderer::slots::color_word>
  81e6eb:	mov    %eax,0x70(%rsp)
  81e6ef:	xorps  %xmm0,%xmm0
  81e6f2:	movaps %xmm0,0xe0(%rsp)
  81e6fa:	movl   $0x0,0xa0(%rsp)
  81e705:	mov    0x26c(%rsp),%eax
  81e70c:	mov    %eax,0x58(%rsp)
  81e710:	mov    0x40(%rsp),%rax
  81e715:	shr    $0x20,%rax
  81e719:	mov    %rax,0x68(%rsp)
  81e71e:	mov    (%rsp),%rax
  81e722:	mov    (%rax),%rcx
  81e725:	mov    0x10(%rax),%rsi
  81e729:	sub    %rsi,%rcx
  81e72c:	cmp    $0x5,%rcx
  81e730:	jbe    81e8b5 <<gpui_gpu::renderer::RendererState>::render+0xef5>
  81e736:	movsd  0x258(%rsp),%xmm0
  81e73f:	cvtsd2ss %xmm0,%xmm0
  81e743:	movsd  0x260(%rsp),%xmm1
  81e74c:	cvtsd2ss %xmm1,%xmm1
  81e750:	movapd 0x3f0(%rsp),%xmm2
  81e759:	unpcklpd 0x3e0(%rsp),%xmm2
  81e762:	cvtpd2ps %xmm2,%xmm2
  81e766:	movapd 0x410(%rsp),%xmm3
  81e76f:	unpcklpd 0x400(%rsp),%xmm3
  81e778:	cvtpd2ps %xmm3,%xmm3
  81e77c:	mov    (%rsp),%rax
  81e780:	mov    0x8(%rax),%rdx
  81e784:	shl    $0x4,%rsi
  81e788:	movaps 0x220(%rsp),%xmm4
  81e790:	movups %xmm4,(%rdx,%rsi,1)
  81e794:	movlpd %xmm3,0x10(%rdx,%rsi,1)
  81e79a:	movss  %xmm1,0x18(%rdx,%rsi,1)
  81e7a0:	mov    0x40(%rsp),%rcx
  81e7a5:	mov    %ecx,0x1c(%rdx,%rsi,1)
  81e7a9:	movlpd %xmm2,0x20(%rdx,%rsi,1)
  81e7af:	movss  %xmm0,0x28(%rdx,%rsi,1)
  81e7b5:	mov    0x68(%rsp),%rdi
  81e7ba:	mov    %edi,0x2c(%rdx,%rsi,1)
  81e7be:	movaps 0x200(%rsp),%xmm0
  81e7c6:	movups %xmm0,0x30(%rdx,%rsi,1)
  81e7cb:	mov    0x70(%rsp),%edi
  81e7cf:	mov    %edi,0x40(%rdx,%rsi,1)
  81e7d3:	mov    0xa0(%rsp),%edi
  81e7da:	mov    %edi,0x44(%rdx,%rsi,1)
  81e7de:	movdqa 0xe0(%rsp),%xmm0
  81e7e7:	movq   %xmm0,0x48(%rdx,%rsi,1)
  81e7ed:	movq   $0x0,0x50(%rdx,%rsi,1)
  81e7f6:	movl   $0x0,0x58(%rdx,%rsi,1)
  81e7fe:	mov    0x58(%rsp),%edi
  81e802:	mov    %edi,0x5c(%rdx,%rsi,1)
  81e806:	addq   $0x6,0x10(%rax)
  81e80b:	lea    0x110(%rsp),%rdi
  81e813:	mov    %rax,%rsi
  81e816:	lea    0x478(%rsp),%rdx
  81e81e:	mov    0x210(%rsp),%r8d
  81e826:	mov    0x60(%rsp),%r9
  81e82b:	push   0xb8(%rsp)
  81e832:	push   %r15
  81e834:	push   %r14
  81e836:	push   0x50(%rsp)
  81e83a:	call   81fe10 <<gpui_gpu::renderer::RendererState>::bin_draw>
  81e83f:	add    $0x20,%rsp
  81e843:	mov    0x110(%rsp),%eax
  81e84a:	cmp    $0xffffffff,%eax
  81e84d:	jne    81ee8b <<gpui_gpu::renderer::RendererState>::render+0x14cb>
  81e853:	movzbl 0x250(%rsp),%ecx
  81e85b:	and    0xf8(%rsp),%cl
  81e862:	mov    0x8(%rsp),%rax
  81e867:	or     %cl,%al
  81e869:	mov    %rax,0x8(%rsp)
  81e86e:	mov    0x118(%rsp),%rax
  81e876:	mov    %rax,0xb8(%rsp)
  81e87e:	incq   0x60(%rsp)
  81e883:	mov    0x80(%rsp),%rdx
  81e88b:	add    $0x4,%rdx
  81e88f:	mov    0xc0(%rsp),%rax
  81e897:	lea    0x0(,%rax,4),%rax
  81e89f:	mov    %rdx,0x80(%rsp)
  81e8a7:	cmp    %rdx,%rax
  81e8aa:	jne    81e3d0 <<gpui_gpu::renderer::RendererState>::render+0xa10>
  81e8b0:	jmp    81ed1a <<gpui_gpu::renderer::RendererState>::render+0x135a>
  81e8b5:	mov    $0x6,%edx
  81e8ba:	mov    $0x4,%ecx
  81e8bf:	mov    $0x10,%r8d
  81e8c5:	mov    (%rsp),%rdi
  81e8c9:	call   823440 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  81e8ce:	mov    (%rsp),%rax
  81e8d2:	mov    0x10(%rax),%rsi
  81e8d6:	jmp    81e736 <<gpui_gpu::renderer::RendererState>::render+0xd76>
  81e8db:	pxor   %xmm0,%xmm0
  81e8df:	movdqa %xmm0,0x80(%rsp)
  81e8e8:	movdqa %xmm0,0x40(%rsp)
  81e8ee:	mov    (%rsp),%rax
  81e8f2:	mov    0x10(%rax),%eax
  81e8f5:	mov    %eax,0xe0(%rsp)
  81e8fc:	movups 0x290(%rsp),%xmm1
  81e904:	movups 0x298(%rsp),%xmm2
  81e90c:	movsd  0x2b0(%rsp),%xmm0
  81e915:	movsd  %xmm0,0x58(%rsp)
  81e91b:	movsd  0x2b8(%rsp),%xmm0
  81e924:	movsd  %xmm0,0x220(%rsp)
  81e92d:	movups 0x2c0(%rsp),%xmm0
  81e935:	movaps %xmm0,0xa0(%rsp)
  81e93d:	movhps 0x2a0(%rsp),%xmm1
  81e945:	movaps %xmm1,0x210(%rsp)
  81e94d:	movups 0x2d0(%rsp),%xmm0
  81e955:	movaps %xmm0,0x70(%rsp)
  81e95a:	movhps 0x2a8(%rsp),%xmm2
  81e962:	movaps %xmm2,0x200(%rsp)
  81e96a:	mov    0x10(%rsp),%rax
  81e96f:	mov    %rax,0x110(%rsp)
  81e977:	mov    0x28(%rsp),%rax
  81e97c:	mov    %rax,0x118(%rsp)
  81e984:	mov    0xc0(%rsp),%rax
  81e98c:	mov    %rax,0x120(%rsp)
  81e994:	lea    0x290(%rsp),%rax
  81e99c:	movups (%rax),%xmm0
  81e99f:	movups 0x10(%rax),%xmm1
  81e9a3:	movups 0x20(%rax),%xmm2
  81e9a7:	lea    0x128(%rsp),%rdx
  81e9af:	movups %xmm2,0x20(%rdx)
  81e9b3:	movups %xmm1,0x10(%rdx)
  81e9b7:	movups %xmm0,(%rdx)
  81e9ba:	lea    0x2c0(%rsp),%rcx
  81e9c2:	movups (%rcx),%xmm0
  81e9c5:	movups %xmm0,0x30(%rdx)
  81e9c9:	movdqu 0x40(%rax),%xmm0
  81e9ce:	movdqu %xmm0,0x40(%rdx)
  81e9d3:	lea    0x110(%rsp),%rdi
  81e9db:	call   *0x660b67(%rip)        # e7f548 <_DYNAMIC+0x5c0>
  81e9e1:	test   %eax,%eax
  81e9e3:	je     81ea06 <<gpui_gpu::renderer::RendererState>::render+0x1046>
  81e9e5:	mov    0x18(%rsp),%rdi
  81e9ea:	mov    %eax,%esi
  81e9ec:	call   8253f0 <gpui_gpu::renderer::slots::color_word>
  81e9f1:	orl    $0x80000000,0xb0(%rsp)
  81e9fc:	movd   %eax,%xmm0
  81ea00:	movdqa %xmm0,0x70(%rsp)
  81ea06:	mov    (%rsp),%rax
  81ea0a:	mov    (%rax),%rcx
  81ea0d:	mov    0x10(%rax),%rsi
  81ea11:	sub    %rsi,%rcx
  81ea14:	cmp    $0x4,%rcx
  81ea18:	jbe    81ed54 <<gpui_gpu::renderer::RendererState>::render+0x1394>
  81ea1e:	cvtpd2ps 0x210(%rsp),%xmm0
  81ea27:	cvtpd2ps 0x200(%rsp),%xmm1
  81ea30:	movsd  0x58(%rsp),%xmm2
  81ea36:	cvtsd2ss %xmm2,%xmm2
  81ea3a:	movsd  0x220(%rsp),%xmm3
  81ea43:	cvtsd2ss %xmm3,%xmm3
  81ea47:	mov    (%rsp),%rax
  81ea4b:	mov    0x8(%rax),%rcx
  81ea4f:	shl    $0x4,%rsi
  81ea53:	movlpd %xmm0,(%rcx,%rsi,1)
  81ea58:	movss  %xmm2,0x8(%rcx,%rsi,1)
  81ea5e:	movaps 0x40(%rsp),%xmm0
  81ea63:	movss  %xmm0,0xc(%rcx,%rsi,1)
  81ea69:	movlpd %xmm1,0x10(%rcx,%rsi,1)
  81ea6f:	movss  %xmm3,0x18(%rcx,%rsi,1)
  81ea75:	movaps 0x80(%rsp),%xmm0
  81ea7d:	movss  %xmm0,0x1c(%rcx,%rsi,1)
  81ea83:	movaps 0xa0(%rsp),%xmm0
  81ea8b:	movups %xmm0,0x20(%rcx,%rsi,1)
  81ea90:	movdqa 0x70(%rsp),%xmm0
  81ea96:	movdqu %xmm0,0x30(%rcx,%rsi,1)
  81ea9c:	mov    0xb0(%rsp),%edx
  81eaa3:	mov    %edx,0x40(%rcx,%rsi,1)
  81eaa7:	movq   $0x0,0x44(%rcx,%rsi,1)
  81eab0:	movl   $0x0,0x4c(%rcx,%rsi,1)
  81eab8:	addq   $0x5,0x10(%rax)
  81eabd:	incq   0x238(%rsp)
  81eac5:	mov    0xc0(%rsp),%rax
  81eacd:	add    %rax,0x240(%rsp)
  81ead5:	test   %rax,%rax
  81ead8:	je     81ed26 <<gpui_gpu::renderer::RendererState>::render+0x1366>
  81eade:	movdqa 0x40(%rsp),%xmm0
  81eae4:	movd   %xmm0,%ecx
  81eae8:	movdqa 0x80(%rsp),%xmm0
  81eaf1:	movd   %xmm0,%eax
  81eaf5:	shl    $0x20,%rax
  81eaf9:	or     %rax,%rcx
  81eafc:	mov    %rcx,0x58(%rsp)
  81eb01:	movq   $0x0,0x40(%rsp)
  81eb0a:	mov    0x28(%rsp),%rax
  81eb0f:	mov    0x40(%rsp),%rcx
  81eb14:	mov    (%rax,%rcx,1),%edx
  81eb17:	lea    0x380(%rsp),%rdi
  81eb1f:	mov    0x10(%rsp),%rsi
  81eb24:	call   81c260 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81eb29:	movzbl 0x380(%rsp),%edi
  81eb31:	lea    0x388(%rsp),%rsi
  81eb39:	mov    -0x7(%rsi),%eax
  81eb3c:	mov    -0x4(%rsi),%ecx
  81eb3f:	lea    0x111(%rsp),%rdx
  81eb47:	mov    %ecx,0x3(%rdx)
  81eb4a:	mov    %eax,(%rdx)
  81eb4c:	mov    0x388(%rsp),%rcx
  81eb54:	mov    0x28(%rsi),%rax
  81eb58:	mov    %rax,0x2f(%rdx)
  81eb5c:	movups 0x8(%rsi),%xmm0
  81eb60:	movups 0x18(%rsi),%xmm1
  81eb64:	movups %xmm1,0x1f(%rdx)
  81eb68:	movups %xmm0,0xf(%rdx)
  81eb6c:	movups 0x3b8(%rsp),%xmm1
  81eb74:	movups 0x40(%rsi),%xmm0
  81eb78:	lea    0x128(%rsp),%rax
  81eb80:	movups %xmm0,0x70(%rax)
  81eb84:	movaps 0x370(%rsp),%xmm0
  81eb8c:	movups %xmm0,0x80(%rax)
  81eb93:	movaps %xmm1,0xc0(%rsp)
  81eb9b:	movups %xmm1,0x148(%rsp)
  81eba3:	movaps 0x520(%rsp),%xmm0
  81ebab:	movaps 0x530(%rsp),%xmm1
  81ebb3:	movapd 0x540(%rsp),%xmm2
  81ebbc:	movupd %xmm2,0x50(%rax)
  81ebc1:	movups %xmm1,0x40(%rax)
  81ebc5:	movups %xmm0,0x30(%rax)
  81ebc9:	movaps 0x550(%rsp),%xmm0
  81ebd1:	movups %xmm0,0x60(%rax)
  81ebd5:	mov    %dil,0x70(%rsp)
  81ebda:	mov    %dil,0x110(%rsp)
  81ebe2:	mov    %rcx,0xa0(%rsp)
  81ebea:	mov    %rcx,0x118(%rsp)
  81ebf2:	mov    (%rsp),%rax
  81ebf6:	mov    (%rax),%rcx
  81ebf9:	mov    0x10(%rax),%rax
  81ebfd:	sub    %rax,%rcx
  81ec00:	mov    %rax,0x80(%rsp)
  81ec08:	cmp    $0x1,%rcx
  81ec0c:	jbe    81ecec <<gpui_gpu::renderer::RendererState>::render+0x132c>
  81ec12:	mov    (%rsp),%rsi
  81ec16:	mov    0x8(%rsi),%rcx
  81ec1a:	shl    $0x4,%rax
  81ec1e:	movdqa 0xc0(%rsp),%xmm0
  81ec27:	movdqu %xmm0,(%rcx,%rax,1)
  81ec2c:	movq   $0x0,0x10(%rcx,%rax,1)
  81ec35:	movl   $0x0,0x18(%rcx,%rax,1)
  81ec3d:	mov    0xe0(%rsp),%edx
  81ec44:	mov    %edx,0x1c(%rcx,%rax,1)
  81ec48:	addq   $0x2,0x10(%rsi)
  81ec4d:	lea    0x380(%rsp),%rdi
  81ec55:	lea    0x110(%rsp),%rdx
  81ec5d:	mov    0x58(%rsp),%rcx
  81ec62:	mov    0x80(%rsp),%r8
  81ec6a:	mov    0x60(%rsp),%r9
  81ec6f:	push   0xb8(%rsp)
  81ec76:	push   %r15
  81ec78:	push   %r14
  81ec7a:	push   0x50(%rsp)
  81ec7e:	call   81fe10 <<gpui_gpu::renderer::RendererState>::bin_draw>
  81ec83:	add    $0x20,%rsp
  81ec87:	mov    0x380(%rsp),%eax
  81ec8e:	cmp    $0xffffffff,%eax
  81ec91:	jne    81eea8 <<gpui_gpu::renderer::RendererState>::render+0x14e8>
  81ec97:	cmpb   $0x2,0x70(%rsp)
  81ec9c:	sete   %al
  81ec9f:	cmpq   $0x0,0xa0(%rsp)
  81eca8:	setne  %cl
  81ecab:	and    %al,%cl
  81ecad:	mov    0x8(%rsp),%rax
  81ecb2:	or     %cl,%al
  81ecb4:	mov    %rax,0x8(%rsp)
  81ecb9:	mov    0x388(%rsp),%rax
  81ecc1:	mov    %rax,0xb8(%rsp)
  81ecc9:	incq   0x60(%rsp)
  81ecce:	mov    0x40(%rsp),%rcx
  81ecd3:	add    $0x4,%rcx
  81ecd7:	mov    %rcx,0x40(%rsp)
  81ecdc:	cmp    %rcx,0x248(%rsp)
  81ece4:	jne    81eb0a <<gpui_gpu::renderer::RendererState>::render+0x114a>
  81ecea:	jmp    81ed1a <<gpui_gpu::renderer::RendererState>::render+0x135a>
  81ecec:	mov    $0x2,%edx
  81ecf1:	mov    $0x4,%ecx
  81ecf6:	mov    $0x10,%r8d
  81ecfc:	mov    (%rsp),%rdi
  81ed00:	mov    0x80(%rsp),%rsi
  81ed08:	call   823440 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  81ed0d:	mov    (%rsp),%rax
  81ed11:	mov    0x10(%rax),%rax
  81ed15:	jmp    81ec12 <<gpui_gpu::renderer::RendererState>::render+0x1252>
  81ed1a:	mov    0x8(%rsp),%rax
  81ed1f:	and    $0x1,%al
  81ed21:	mov    %rax,0x8(%rsp)
  81ed26:	lea    0x278(%rsp),%rdi
  81ed2e:	lea    0x328(%rsp),%rsi
  81ed36:	call   *0x660804(%rip)        # e7f540 <_DYNAMIC+0x5b8>
  81ed3c:	mov    0x278(%rsp),%rax
  81ed44:	mov    %rax,0x10(%rsp)
  81ed49:	test   %rax,%rax
  81ed4c:	jne    81e07e <<gpui_gpu::renderer::RendererState>::render+0x6be>
  81ed52:	jmp    81edb0 <<gpui_gpu::renderer::RendererState>::render+0x13f0>
  81ed54:	mov    $0x5,%edx
  81ed59:	mov    $0x4,%ecx
  81ed5e:	mov    $0x10,%r8d
  81ed64:	mov    (%rsp),%rdi
  81ed68:	call   823440 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  81ed6d:	mov    (%rsp),%rax
  81ed71:	mov    0x10(%rax),%rsi
  81ed75:	jmp    81ea1e <<gpui_gpu::renderer::RendererState>::render+0x105e>
  81ed7a:	movq   $0x0,0x240(%rsp)
  81ed86:	movq   $0x0,0x238(%rsp)
  81ed92:	movq   $0x0,0x60(%rsp)
  81ed9b:	movq   $0x0,0x8(%rsp)
  81eda4:	movq   $0x0,0xb8(%rsp)
  81edb0:	mov    0x100(%rsp),%rsi
  81edb8:	lea    0x8(%rsi),%rdx
  81edbc:	mov    (%rsp),%rax
  81edc0:	lea    0x258(%rax),%rcx
  81edc7:	lea    0x328(%rax),%r8
  81edce:	mov    0x10(%rax),%r9
  81edd2:	sub    $0x8,%rsp
  81edd6:	lea    0x118(%rsp),%rdi
  81edde:	mov    %rdx,0xb8(%rsp)
  81ede6:	mov    %rcx,0x100(%rsp)
  81edee:	mov    %r8,0x268(%rsp)
  81edf6:	push   0x110(%rsp)
  81edfd:	call   822380 <gpui_gpu::renderer::images::prepare>
  81ee02:	add    $0x10,%rsp
  81ee06:	cmpl   $0xffffffff,0x110(%rsp)
  81ee0e:	je     81ee57 <<gpui_gpu::renderer::RendererState>::render+0x1497>
  81ee10:	movups 0x110(%rsp),%xmm0
  81ee18:	movups 0x120(%rsp),%xmm1
  81ee20:	mov    0x50(%rsp),%rdi
  81ee25:	movups %xmm1,0x10(%rdi)
  81ee29:	movups %xmm0,(%rdi)
  81ee2c:	jmp    81dad1 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81ee31:	mov    0x36c(%rsp),%edx
  81ee38:	mov    0x50(%rsp),%rdi
  81ee3d:	mov    %edx,0x1c(%rdi)
  81ee40:	movups 0x35c(%rsp),%xmm0
  81ee48:	movups %xmm0,0xc(%rdi)
  81ee4c:	mov    %ecx,(%rdi)
  81ee4e:	mov    %rax,0x4(%rdi)
  81ee52:	jmp    81dad1 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81ee57:	movzbl 0x8(%rsp),%r8d
  81ee5d:	and    $0x1,%r8d
  81ee61:	lea    0x110(%rsp),%rdi
  81ee69:	mov    (%rsp),%rsi
  81ee6d:	mov    0x100(%rsp),%rdx
  81ee75:	mov    0x30(%rsp),%rcx
  81ee7a:	call   81d120 <<gpui_gpu::renderer::RendererState>::prepare_atlas>
  81ee7f:	mov    0x110(%rsp),%eax
  81ee86:	cmp    $0xffffffff,%eax
  81ee89:	je     81eeef <<gpui_gpu::renderer::RendererState>::render+0x152f>
  81ee8b:	mov    0x114(%rsp),%ecx
  81ee92:	mov    0x118(%rsp),%rdx
  81ee9a:	movdqu 0x120(%rsp),%xmm0
  81eea3:	jmp    81deea <<gpui_gpu::renderer::RendererState>::render+0x52a>
  81eea8:	mov    0x384(%rsp),%ecx
  81eeaf:	mov    0x388(%rsp),%rdx
  81eeb7:	movups 0x390(%rsp),%xmm0
  81eebf:	jmp    81deea <<gpui_gpu::renderer::RendererState>::render+0x52a>
  81eec4:	mov    0x12c(%rsp),%ecx
  81eecb:	mov    0x50(%rsp),%rdi
  81eed0:	mov    %ecx,0x1c(%rdi)
  81eed3:	movups 0x11c(%rsp),%xmm0
  81eedb:	movups %xmm0,0xc(%rdi)
  81eedf:	mov    %eax,(%rdi)
  81eee1:	mov    0x40(%rsp),%rax
  81eee6:	mov    %rax,0x4(%rdi)
  81eeea:	jmp    81dad1 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81eeef:	mov    0x118(%rsp),%rax
  81eef7:	mov    %rax,0x248(%rsp)
  81eeff:	mov    (%rsp),%rax
  81ef03:	mov    0x28(%rax),%rax
  81ef07:	movq   $0x0,0x68(%rsp)
  81ef10:	test   %rax,%rax
  81ef13:	je     81ef7d <<gpui_gpu::renderer::RendererState>::render+0x15bd>
  81ef15:	mov    (%rsp),%rcx
  81ef19:	mov    0x20(%rcx),%rcx
  81ef1d:	shl    $0x3,%rax
  81ef21:	xor    %edi,%edi
  81ef23:	jmp    81ef41 <<gpui_gpu::renderer::RendererState>::render+0x1581>
  81ef25:	mov    0x68(%rsp),%rdx
  81ef2a:	add    %esi,%edx
  81ef2c:	mov    %edx,(%rcx,%rdi,8)
  81ef2f:	mov    %rdx,0x68(%rsp)
  81ef34:	mov    %edx,0x4(%rcx,%rdi,8)
  81ef38:	inc    %rdi
  81ef3b:	add    $0xfffffffffffffff8,%rax
  81ef3f:	je     81ef71 <<gpui_gpu::renderer::RendererState>::render+0x15b1>
  81ef41:	mov    (%rsp),%rdx
  81ef45:	mov    0x58(%rdx),%rsi
  81ef49:	cmp    %rsi,%rdi
  81ef4c:	jae    81fdb4 <<gpui_gpu::renderer::RendererState>::render+0x23f4>
  81ef52:	mov    0x4(%rcx,%rdi,8),%esi
  81ef56:	cmp    $0x1,%esi
  81ef59:	jne    81ef25 <<gpui_gpu::renderer::RendererState>::render+0x1565>
  81ef5b:	mov    (%rsp),%rdx
  81ef5f:	mov    0x50(%rdx),%r8
  81ef63:	mov    $0x80000000,%edx
  81ef68:	cmpl   $0x0,(%r8,%rdi,4)
  81ef6d:	jne    81ef34 <<gpui_gpu::renderer::RendererState>::render+0x1574>
  81ef6f:	jmp    81ef25 <<gpui_gpu::renderer::RendererState>::render+0x1565>
  81ef71:	mov    0x68(%rsp),%rax
  81ef76:	mov    %eax,%eax
  81ef78:	mov    %rax,0x68(%rsp)
  81ef7d:	mov    (%rsp),%rax
  81ef81:	lea    0x30(%rax),%rdi
  81ef85:	movq   $0x0,0x40(%rax)
  81ef8d:	mov    %rdi,0x3e0(%rsp)
  81ef95:	mov    0x68(%rsp),%rsi
  81ef9a:	xor    %edx,%edx
  81ef9c:	call   822230 <<alloc::vec::Vec<u32>>::resize>
  81efa1:	mov    (%rsp),%rax
  81efa5:	mov    0x10(%rax),%rax
  81efa9:	mov    %rax,0x18(%rsp)
  81efae:	mov    0x60(%rsp),%rax
  81efb3:	mov    %rax,0x320(%rsp)
  81efbb:	mov    0x30(%rsp),%rax
  81efc0:	mov    %rax,0x328(%rsp)
  81efc8:	movq   $0x0,0x330(%rsp)
  81efd4:	mov    0x20(%rsp),%rax
  81efd9:	mov    %rax,0x338(%rsp)
  81efe1:	mov    0x318(%rsp),%rax
  81efe9:	mov    %rax,0x340(%rsp)
  81eff1:	mov    0x9c(%rsp),%eax
  81eff8:	mov    %eax,0x348(%rsp)
  81efff:	lea    0x278(%rsp),%rdi
  81f007:	lea    0x328(%rsp),%rsi
  81f00f:	call   *0x66053b(%rip)        # e7f550 <_DYNAMIC+0x5c8>
  81f015:	mov    0x278(%rsp),%rax
  81f01d:	mov    %rax,0x200(%rsp)
  81f025:	test   %rax,%rax
  81f028:	je     81f659 <<gpui_gpu::renderer::RendererState>::render+0x1c99>
  81f02e:	mov    (%rsp),%rax
  81f032:	add    $0x120,%rax
  81f038:	mov    %rax,0x258(%rsp)
  81f040:	jmp    81f08b <<gpui_gpu::renderer::RendererState>::render+0x16cb>
  81f042:	mov    0x18(%rsp),%rcx
  81f047:	lea    -0x5(%rcx),%rax
  81f04b:	cmpb   $0x0,0x210(%rsp)
  81f053:	cmovne %rax,%rcx
  81f057:	mov    %rcx,0x18(%rsp)
  81f05c:	lea    0x278(%rsp),%rdi
  81f064:	lea    0x328(%rsp),%rsi
  81f06c:	call   *0x6604de(%rip)        # e7f550 <_DYNAMIC+0x5c8>
  81f072:	mov    0x278(%rsp),%rax
  81f07a:	mov    %rax,0x200(%rsp)
  81f082:	test   %rax,%rax
  81f085:	je     81f659 <<gpui_gpu::renderer::RendererState>::render+0x1c99>
  81f08b:	mov    0x280(%rsp),%rdi
  81f093:	mov    0x288(%rsp),%r8
  81f09b:	mov    %r8,0x28(%rsp)
  81f0a0:	lea    0x290(%rsp),%rcx
  81f0a8:	movups (%rcx),%xmm0
  81f0ab:	movups 0x10(%rcx),%xmm1
  81f0af:	movups 0x20(%rcx),%xmm2
  81f0b3:	movaps %xmm2,0x3a0(%rsp)
  81f0bb:	movaps %xmm1,0x390(%rsp)
  81f0c3:	movaps %xmm0,0x380(%rsp)
  81f0cb:	lea    0x2c0(%rsp),%rdx
  81f0d3:	movups (%rdx),%xmm0
  81f0d6:	movaps %xmm0,0x440(%rsp)
  81f0de:	movups 0x40(%rcx),%xmm0
  81f0e2:	movaps %xmm0,0x370(%rsp)
  81f0ea:	mov    (%rsp),%rax
  81f0ee:	movzbl 0x341(%rax),%esi
  81f0f5:	mov    0x200(%rsp),%rax
  81f0fd:	mov    %rax,0x110(%rsp)
  81f105:	mov    %rdi,0x410(%rsp)
  81f10d:	mov    %rdi,0x118(%rsp)
  81f115:	mov    %r8,0x120(%rsp)
  81f11d:	movups (%rcx),%xmm0
  81f120:	movups 0x10(%rcx),%xmm1
  81f124:	movups 0x20(%rcx),%xmm2
  81f128:	lea    0x128(%rsp),%rax
  81f130:	movups %xmm2,0x20(%rax)
  81f134:	movups %xmm1,0x10(%rax)
  81f138:	movups %xmm0,(%rax)
  81f13b:	movups (%rdx),%xmm0
  81f13e:	movups %xmm0,0x30(%rax)
  81f142:	movdqu 0x40(%rcx),%xmm0
  81f147:	movdqu %xmm0,0x40(%rax)
  81f14c:	lea    0x110(%rsp),%rdi
  81f154:	call   820e70 <gpui_gpu::renderer::compact_group>
  81f159:	mov    %al,0x210(%rsp)
  81f160:	mov    0x28(%rsp),%rax
  81f165:	test   %rax,%rax
  81f168:	je     81f042 <<gpui_gpu::renderer::RendererState>::render+0x1682>
  81f16e:	mov    %rax,%rdx
  81f171:	shl    $0x2,%rdx
  81f175:	movzbl 0x210(%rsp),%eax
  81f17d:	lea    0x0(,%rax,4),%esi
  81f184:	or     $0xfffffffffffffffa,%rsi
  81f188:	xor    $0x1,%al
  81f18a:	movzbl %al,%eax
  81f18d:	lea    0x1(,%rax,4),%rcx
  81f195:	mov    %rcx,0x250(%rsp)
  81f19d:	mov    0x18(%rsp),%rcx
  81f1a2:	lea    (%rsi,%rcx,1),%edi
  81f1a5:	lea    (%rsi,%rax,4),%rax
  81f1a9:	inc    %rax
  81f1ac:	mov    %rax,0x400(%rsp)
  81f1b4:	add    %rax,%rcx
  81f1b7:	shl    $0x4,%rcx
  81f1bb:	mov    %rsi,0x40(%rsp)
  81f1c0:	shl    $0x4,%rsi
  81f1c4:	mov    %rsi,0x3f0(%rsp)
  81f1cc:	mov    %rcx,0x10(%rsp)
  81f1d1:	mov    %edi,0x8(%rsp)
  81f1d5:	mov    0x410(%rsp),%rax
  81f1dd:	mov    %rdx,0x28(%rsp)
  81f1e2:	mov    -0x4(%rax,%rdx,1),%edx
  81f1e6:	lea    0x110(%rsp),%rdi
  81f1ee:	mov    0x200(%rsp),%rsi
  81f1f6:	call   81c260 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81f1fb:	movzbl 0x110(%rsp),%ecx
  81f203:	movzbl 0x111(%rsp),%eax
  81f20b:	mov    %al,0x20(%rsp)
  81f20f:	movzwl 0x112(%rsp),%eax
  81f217:	mov    %ax,0x70(%rsp)
  81f21c:	movss  0x114(%rsp),%xmm4
  81f225:	lea    0x118(%rsp),%rdx
  81f22d:	mov    0x10(%rdx),%rax
  81f231:	mov    %rax,0x360(%rsp)
  81f239:	movups (%rdx),%xmm0
  81f23c:	movaps %xmm0,0x350(%rsp)
  81f244:	mov    0x130(%rsp),%rax
  81f24c:	mov    %rax,0x30(%rsp)
  81f251:	mov    0x138(%rsp),%r10d
  81f259:	mov    0x13c(%rsp),%r11d
  81f261:	movups 0x140(%rsp),%xmm0
  81f269:	movaps %xmm0,0xa0(%rsp)
  81f271:	mov    0x140(%rsp),%rax
  81f279:	movsd  0x150(%rsp),%xmm5
  81f282:	lea    0x128(%rsp),%rdx
  81f28a:	movups 0x30(%rdx),%xmm0
  81f28e:	movaps %xmm0,0x420(%rsp)
  81f296:	decq   0x320(%rsp)
  81f29e:	cmp    $0x1,%ecx
  81f2a1:	mov    %ecx,0xc0(%rsp)
  81f2a8:	movaps %xmm5,0x80(%rsp)
  81f2b0:	je     81f346 <<gpui_gpu::renderer::RendererState>::render+0x1986>
  81f2b6:	mov    %r11d,0x58(%rsp)
  81f2bb:	mov    %r10d,0xe0(%rsp)
  81f2c3:	movaps %xmm4,0x220(%rsp)
  81f2cb:	cmp    $0x3,%ecx
  81f2ce:	jne    81f3c3 <<gpui_gpu::renderer::RendererState>::render+0x1a03>
  81f2d4:	mov    0x260(%rsp),%rax
  81f2dc:	mov    (%rax),%rdi
  81f2df:	test   %rdi,%rdi
  81f2e2:	je     81fd8a <<gpui_gpu::renderer::RendererState>::render+0x23ca>
  81f2e8:	movzbl 0x20(%rsp),%edx
  81f2ed:	mov    0x30(%rsp),%rsi
  81f2f2:	call   822010 <<gpui_gpu::renderer::images::Images>::metadata>
  81f2f7:	mov    %eax,%ecx
  81f2f9:	shr    $0x20,%rax
  81f2fd:	mov    %eax,%edx
  81f2ff:	or     $0x10,%edx
  81f302:	xorps  %xmm0,%xmm0
  81f305:	movaps 0x220(%rsp),%xmm4
  81f30d:	ucomiss %xmm0,%xmm4
  81f310:	cmovne %edx,%eax
  81f313:	cmovp  %edx,%eax
  81f316:	mov    0x58(%rsp),%r11d
  81f31b:	mov    %r11d,%edx
  81f31e:	shl    $0x10,%edx
  81f321:	mov    0xe0(%rsp),%r10d
  81f329:	or     %r10d,%edx
  81f32c:	mov    %ecx,0xd4(%rsp)
  81f333:	mov    %eax,0xd8(%rsp)
  81f33a:	mov    %edx,0xdc(%rsp)
  81f341:	jmp    81f475 <<gpui_gpu::renderer::RendererState>::render+0x1ab5>
  81f346:	movaps %xmm5,%xmm0
  81f349:	movss  -0x7703e5(%rip),%xmm3        # aef6c <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  81f351:	mulss  %xmm3,%xmm0
  81f355:	movaps %xmm4,%xmm1
  81f358:	minss  %xmm0,%xmm1
  81f35c:	movaps %xmm1,%xmm0
  81f35f:	cmpunordss %xmm1,%xmm0
  81f364:	movaps %xmm0,%xmm2
  81f367:	andnps %xmm1,%xmm2
  81f36a:	andps  %xmm4,%xmm0
  81f36d:	orps   %xmm2,%xmm0
  81f370:	movaps %xmm5,%xmm1
  81f373:	shufps $0x55,%xmm5,%xmm1
  81f377:	mulss  %xmm3,%xmm1
  81f37b:	movaps %xmm0,%xmm2
  81f37e:	minss  %xmm1,%xmm2
  81f382:	movaps %xmm2,%xmm1
  81f385:	cmpunordss %xmm2,%xmm1
  81f38a:	andps  %xmm1,%xmm0
  81f38d:	andnps %xmm2,%xmm1
  81f390:	orps   %xmm0,%xmm1
  81f393:	movd   %xmm1,%eax
  81f397:	and    $0xff800000,%eax
  81f39c:	mov    $0x7f000000,%ecx
  81f3a1:	sub    %eax,%ecx
  81f3a3:	movl   $0x40000000,0xd4(%rsp)
  81f3ae:	movss  %xmm1,0xd8(%rsp)
  81f3b7:	mov    %ecx,0xdc(%rsp)
  81f3be:	jmp    81f475 <<gpui_gpu::renderer::RendererState>::render+0x1ab5>
  81f3c3:	cmp    $0x2,%cl
  81f3c6:	jne    81f418 <<gpui_gpu::renderer::RendererState>::render+0x1a58>
  81f3c8:	mov    0x360(%rsp),%rcx
  81f3d0:	mov    %rcx,0x120(%rsp)
  81f3d8:	movaps 0x350(%rsp),%xmm0
  81f3e0:	movaps %xmm0,0x110(%rsp)
  81f3e8:	mov    0x30(%rsp),%rcx
  81f3ed:	mov    %rcx,0x128(%rsp)
  81f3f5:	mov    0xe0(%rsp),%ecx
  81f3fc:	mov    %ecx,0x130(%rsp)
  81f403:	mov    0x58(%rsp),%ecx
  81f407:	mov    %ecx,0x134(%rsp)
  81f40e:	mov    %rax,0x138(%rsp)
  81f416:	jmp    81f424 <<gpui_gpu::renderer::RendererState>::render+0x1a64>
  81f418:	movq   $0x0,0x110(%rsp)
  81f424:	movl   $0x0,0x2e8(%rsp)
  81f42f:	movq   $0x0,0x2e0(%rsp)
  81f43b:	lea    0xd4(%rsp),%rdi
  81f443:	lea    0x110(%rsp),%rsi
  81f44b:	lea    0x2e0(%rsp),%rdx
  81f453:	mov    0x258(%rsp),%rcx
  81f45b:	call   81afe0 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>>
  81f460:	movaps 0x220(%rsp),%xmm4
  81f468:	mov    0xe0(%rsp),%r10d
  81f470:	mov    0x58(%rsp),%r11d
  81f475:	mov    0x18(%rsp),%rdx
  81f47a:	mov    0x400(%rsp),%rax
  81f482:	lea    (%rax,%rdx,1),%rcx
  81f486:	mov    (%rsp),%rax
  81f48a:	mov    0x10(%rax),%rsi
  81f48e:	cmp    %rsi,%rcx
  81f491:	lea    0x110(%rsp),%rdi
  81f499:	mov    0x8(%rsp),%r8d
  81f49e:	mov    0x10(%rsp),%r9
  81f4a3:	movapd 0x80(%rsp),%xmm3
  81f4ac:	jae    81fd97 <<gpui_gpu::renderer::RendererState>::render+0x23d7>
  81f4b2:	add    0x40(%rsp),%rdx
  81f4b7:	mov    %rdx,0x18(%rsp)
  81f4bc:	mov    0x8(%rax),%rax
  81f4c0:	mov    0xdc(%rsp),%ecx
  81f4c7:	mov    %ecx,0x8(%rax,%r9,1)
  81f4cc:	mov    0xd4(%rsp),%rcx
  81f4d4:	mov    %r8d,%edx
  81f4d7:	or     $0x80000000,%edx
  81f4dd:	cmpb   $0x0,0x210(%rsp)
  81f4e5:	cmovne %r8d,%edx
  81f4e9:	mov    %rcx,(%rax,%r9,1)
  81f4ed:	mov    %edx,0x274(%rsp)
  81f4f4:	movaps 0x380(%rsp),%xmm0
  81f4fc:	movaps 0x390(%rsp),%xmm1
  81f504:	movaps 0x3a0(%rsp),%xmm2
  81f50c:	lea    0x128(%rsp),%rax
  81f514:	movups %xmm2,0x50(%rax)
  81f518:	movups %xmm1,0x40(%rax)
  81f51c:	movups %xmm0,0x30(%rax)
  81f520:	movaps 0x440(%rsp),%xmm0
  81f528:	movups %xmm0,0x60(%rax)
  81f52c:	movaps 0x370(%rsp),%xmm0
  81f534:	movups %xmm0,0x80(%rax)
  81f53b:	movlpd %xmm3,0x150(%rsp)
  81f544:	movaps 0x420(%rsp),%xmm0
  81f54c:	movups %xmm0,0x70(%rax)
  81f550:	mov    0xc0(%rsp),%eax
  81f557:	mov    %al,0x110(%rsp)
  81f55e:	movzbl 0x20(%rsp),%eax
  81f563:	mov    %al,0x111(%rsp)
  81f56a:	movzwl 0x70(%rsp),%eax
  81f56f:	mov    %ax,0x112(%rsp)
  81f577:	movss  %xmm4,0x114(%rsp)
  81f580:	mov    0x360(%rsp),%rax
  81f588:	lea    0x118(%rsp),%rcx
  81f590:	mov    %rax,0x10(%rcx)
  81f594:	movaps 0x350(%rsp),%xmm0
  81f59c:	movups %xmm0,(%rcx)
  81f59f:	mov    0x30(%rsp),%rax
  81f5a4:	mov    %rax,0x130(%rsp)
  81f5ac:	mov    %r10d,0x138(%rsp)
  81f5b4:	mov    %r11d,0x13c(%rsp)
  81f5bc:	movdqa 0xa0(%rsp),%xmm0
  81f5c5:	movdqu %xmm0,0x140(%rsp)
  81f5ce:	mov    0x470(%rsp),%rax
  81f5d6:	mov    %rax,0x2e0(%rsp)
  81f5de:	mov    0x3e0(%rsp),%rax
  81f5e6:	mov    %rax,0x2e8(%rsp)
  81f5ee:	mov    0x468(%rsp),%rax
  81f5f6:	mov    %rax,0x2f0(%rsp)
  81f5fe:	lea    0x320(%rsp),%rax
  81f606:	mov    %rax,0x2f8(%rsp)
  81f60e:	lea    0x274(%rsp),%rax
  81f616:	mov    %rax,0x300(%rsp)
  81f61e:	mov    0x38(%rsp),%rsi
  81f623:	lea    0x2e0(%rsp),%rdx
  81f62b:	call   81bea0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>>
  81f630:	mov    0x10(%rsp),%rcx
  81f635:	mov    0x8(%rsp),%edi
  81f639:	add    0x40(%rsp),%edi
  81f63d:	add    0x3f0(%rsp),%rcx
  81f645:	mov    0x28(%rsp),%rdx
  81f64a:	add    $0xfffffffffffffffc,%rdx
  81f64e:	jne    81f1cc <<gpui_gpu::renderer::RendererState>::render+0x180c>
  81f654:	jmp    81f042 <<gpui_gpu::renderer::RendererState>::render+0x1682>
  81f659:	mov    (%rsp),%rax
  81f65d:	mov    0x28(%rax),%rdi
  81f661:	movq   $0x0,0x20(%rsp)
  81f66a:	test   %rdi,%rdi
  81f66d:	je     81f73c <<gpui_gpu::renderer::RendererState>::render+0x1d7c>
  81f673:	mov    (%rsp),%rax
  81f677:	mov    0x20(%rax),%r8
  81f67b:	shl    $0x3,%rdi
  81f67f:	cmpl   $0x0,0x38(%rsp)
  81f684:	je     81fd44 <<gpui_gpu::renderer::RendererState>::render+0x2384>
  81f68a:	movq   $0x0,0x30(%rsp)
  81f693:	movq   $0x0,0x10(%rsp)
  81f69c:	movq   $0x0,0x8(%rsp)
  81f6a5:	xor    %r9d,%r9d
  81f6a8:	xor    %ecx,%ecx
  81f6aa:	jmp    81f6cf <<gpui_gpu::renderer::RendererState>::render+0x1d0f>
  81f6ac:	incq   0x8(%rsp)
  81f6b1:	inc    %r9
  81f6b4:	cmp    0x38(%rsp),%r9
  81f6b9:	mov    $0x0,%eax
  81f6be:	cmove  %rax,%r9
  81f6c2:	inc    %rcx
  81f6c5:	add    $0xfffffffffffffff8,%rdi
  81f6c9:	je     81f757 <<gpui_gpu::renderer::RendererState>::render+0x1d97>
  81f6cf:	mov    0x4(%r8,%rcx,8),%r10d
  81f6d4:	mov    %r10d,%eax
  81f6d7:	neg    %eax
  81f6d9:	jo     81f6ac <<gpui_gpu::renderer::RendererState>::render+0x1cec>
  81f6db:	sub    (%r8,%rcx,8),%r10d
  81f6df:	je     81f6b1 <<gpui_gpu::renderer::RendererState>::render+0x1cf1>
  81f6e1:	mov    %rcx,%rax
  81f6e4:	shr    $0x20,%rax
  81f6e8:	je     81f6f9 <<gpui_gpu::renderer::RendererState>::render+0x1d39>
  81f6ea:	mov    %rcx,%rax
  81f6ed:	xor    %edx,%edx
  81f6ef:	divq   0x38(%rsp)
  81f6f4:	mov    %r9,%rdx
  81f6f7:	jmp    81f701 <<gpui_gpu::renderer::RendererState>::render+0x1d41>
  81f6f9:	mov    %ecx,%eax
  81f6fb:	xor    %edx,%edx
  81f6fd:	divl   0x38(%rsp)
  81f701:	shl    $0x4,%edx
  81f704:	shl    $0x4,%eax
  81f707:	lea    0x10(%rdx),%r11d
  81f70b:	cmp    %r11d,%r14d
  81f70e:	cmovb  %r14d,%r11d
  81f712:	lea    0x10(%rax),%esi
  81f715:	cmp    %esi,%r15d
  81f718:	cmovb  %r15d,%esi
  81f71c:	sub    %edx,%r11d
  81f71f:	sub    %eax,%esi
  81f721:	imul   %r11d,%esi
  81f725:	shl    $0x4,%rsi
  81f729:	add    %rsi,0x10(%rsp)
  81f72e:	imul   %rsi,%r10
  81f732:	add    %r10,0x30(%rsp)
  81f737:	jmp    81f6b1 <<gpui_gpu::renderer::RendererState>::render+0x1cf1>
  81f73c:	movq   $0x0,0x8(%rsp)
  81f745:	movq   $0x0,0x10(%rsp)
  81f74e:	movq   $0x0,0x30(%rsp)
  81f757:	test   $0x1,%r13b
  81f75b:	je     81f7ad <<gpui_gpu::renderer::RendererState>::render+0x1ded>
  81f75d:	movd   0x270(%rsp),%xmm0
  81f766:	movd   %xmm0,%eax
  81f76a:	test   %eax,%eax
  81f76c:	setns  %cl
  81f76f:	mov    %eax,%edx
  81f771:	and    $0x7fffffff,%edx
  81f777:	add    $0xff800000,%edx
  81f77d:	cmp    $0x7f000000,%edx
  81f783:	setb   %dl
  81f786:	and    %cl,%dl
  81f788:	dec    %eax
  81f78a:	cmp    $0x7fffff,%eax
  81f78f:	setb   %al
  81f792:	or     %dl,%al
  81f794:	mov    $0x2,%eax
  81f799:	mov    %rax,0x20(%rsp)
  81f79e:	movd   %xmm0,0xd0(%rsp)
  81f7a7:	je     81fd3a <<gpui_gpu::renderer::RendererState>::render+0x237a>
  81f7ad:	mov    0x100(%rsp),%r13
  81f7b5:	lea    0x18(%r13),%rax
  81f7b9:	mov    %rax,0x18(%rsp)
  81f7be:	mov    0x108(%rsp),%rax
  81f7c6:	add    $0x18,%rax
  81f7ca:	xor    %ecx,%ecx
  81f7cc:	cmp    $0x28,%r12d
  81f7d0:	sete   %cl
  81f7d3:	and    $0x1,%ebp
  81f7d6:	lea    0x0(%rbp,%rcx,4),%ecx
  81f7da:	or     0x20(%rsp),%ecx
  81f7de:	movups (%rax),%xmm0
  81f7e1:	movups %xmm0,0x288(%rsp)
  81f7e9:	mov    %r14d,0x278(%rsp)
  81f7f1:	mov    %r15d,0x27c(%rsp)
  81f7f9:	mov    0x38(%rsp),%rax
  81f7fe:	mov    %eax,0x280(%rsp)
  81f805:	mov    %ecx,0x284(%rsp)
  81f80c:	movss  0xd0(%rsp),%xmm0
  81f815:	movss  %xmm0,0x298(%rsp)
  81f81e:	movq   $0x0,0x29c(%rsp)
  81f82a:	movl   $0x0,0x2a4(%rsp)
  81f835:	mov    (%rsp),%rbp
  81f839:	lea    0x230(%rbp),%rsi
  81f840:	movq   $0x0,0x20(%rsp)
  81f849:	lea    0x278(%rsp),%rcx
  81f851:	mov    $0x30,%r8d
  81f857:	mov    0xb0(%rsp),%r12
  81f85f:	mov    %r12,%rdi
  81f862:	mov    %rsi,0x38(%rsp)
  81f867:	xor    %edx,%edx
  81f869:	call   *0x65fce9(%rip)        # e7f558 <_DYNAMIC+0x5d0>
  81f86f:	mov    0x8(%rbp),%rcx
  81f873:	mov    0x10(%rbp),%r8
  81f877:	shl    $0x4,%r8
  81f87b:	mov    0xf8(%rsp),%rdi
  81f883:	mov    %r13,%rsi
  81f886:	mov    %r12,%rdx
  81f889:	call   81c500 <<gpui_gpu::renderer::Buffer>::write>
  81f88e:	lea    0x280(%rbp),%rdi
  81f895:	mov    0x20(%rbp),%rcx
  81f899:	mov    0x28(%rbp),%r8
  81f89d:	shl    $0x3,%r8
  81f8a1:	mov    %rdi,0x28(%rsp)
  81f8a6:	mov    %r13,%rsi
  81f8a9:	mov    %r12,%rdx
  81f8ac:	call   81c500 <<gpui_gpu::renderer::Buffer>::write>
  81f8b1:	lea    0x2a8(%rbp),%rdi
  81f8b8:	mov    0x38(%rbp),%rcx
  81f8bc:	mov    0x40(%rbp),%r8
  81f8c0:	shl    $0x2,%r8
  81f8c4:	mov    %rdi,0x40(%rsp)
  81f8c9:	mov    %r13,%rsi
  81f8cc:	mov    %r12,%rdx
  81f8cf:	call   81c500 <<gpui_gpu::renderer::Buffer>::write>
  81f8d4:	lea    0x2d0(%rbp),%rdi
  81f8db:	mov    0x68(%rbp),%rcx
  81f8df:	mov    0x70(%rbp),%r8
  81f8e3:	shl    $0x5,%r8
  81f8e7:	mov    %rdi,0x80(%rsp)
  81f8ef:	mov    %r13,%rsi
  81f8f2:	mov    %r12,%rdx
  81f8f5:	call   81c500 <<gpui_gpu::renderer::Buffer>::write>
  81f8fa:	cmpq   $0x0,0x328(%rbp)
  81f902:	jne    81f91d <<gpui_gpu::renderer::RendererState>::render+0x1f5d>
  81f904:	mov    (%rsp),%rax
  81f908:	mov    0x10(%rax),%rax
  81f90c:	cmp    $0x1,%rax
  81f910:	adc    $0x0,%rax
  81f914:	shl    $0x4,%rax
  81f918:	mov    %rax,0x20(%rsp)
  81f91d:	mov    (%rsp),%rsi
  81f921:	mov    0x28(%rsi),%rdx
  81f925:	mov    0x40(%rsi),%rax
  81f929:	cmp    $0x1,%rdx
  81f92d:	adc    $0x0,%rdx
  81f931:	shl    $0x3,%rdx
  81f935:	cmp    $0x1,%rax
  81f939:	adc    $0x0,%rax
  81f93d:	mov    0x70(%rsi),%rcx
  81f941:	cmp    $0x1,%rcx
  81f945:	adc    $0x0,%rcx
  81f949:	add    $0xc8,%rsi
  81f950:	shl    $0x2,%rax
  81f954:	shl    $0x5,%rcx
  81f958:	movq   $0x0,0x110(%rsp)
  81f964:	mov    0x38(%rsp),%rdi
  81f969:	mov    %rdi,0x118(%rsp)
  81f971:	movq   $0x0,0x138(%rsp)
  81f97d:	xorps  %xmm0,%xmm0
  81f980:	movups %xmm0,0x120(%rsp)
  81f988:	movl   $0x0,0x130(%rsp)
  81f993:	mov    0xf8(%rsp),%rdi
  81f99b:	mov    %rdi,0x140(%rsp)
  81f9a3:	movq   $0x0,0x148(%rsp)
  81f9af:	mov    0x20(%rsp),%rdi
  81f9b4:	mov    %rdi,0x150(%rsp)
  81f9bc:	movl   $0x1,0x158(%rsp)
  81f9c7:	movq   $0x0,0x160(%rsp)
  81f9d3:	mov    0x28(%rsp),%rdi
  81f9d8:	mov    %rdi,0x168(%rsp)
  81f9e0:	movq   $0x0,0x170(%rsp)
  81f9ec:	mov    %rdx,0x178(%rsp)
  81f9f4:	movl   $0x2,0x180(%rsp)
  81f9ff:	movq   $0x0,0x188(%rsp)
  81fa0b:	mov    0x40(%rsp),%rdx
  81fa10:	mov    %rdx,0x190(%rsp)
  81fa18:	movq   $0x0,0x198(%rsp)
  81fa24:	mov    %rax,0x1a0(%rsp)
  81fa2c:	movl   $0x3,0x1a8(%rsp)
  81fa37:	movq   $0x4,0x1b0(%rsp)
  81fa43:	mov    %rsi,0x1b8(%rsp)
  81fa4b:	movl   $0x4,0x1d0(%rsp)
  81fa56:	movq   $0x0,0x1d8(%rsp)
  81fa62:	mov    0x80(%rsp),%rax
  81fa6a:	mov    %rax,0x1e0(%rsp)
  81fa72:	movq   $0x0,0x1e8(%rsp)
  81fa7e:	mov    %rcx,0x1f0(%rsp)
  81fa86:	movl   $0x5,0x1f8(%rsp)
  81fa91:	lea    -0x74b2e0(%rip),%rax        # d47b8 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x122>
  81fa98:	mov    %rax,0x398(%rsp)
  81faa0:	movq   $0xa,0x3a0(%rsp)
  81faac:	mov    0x18(%rsp),%rax
  81fab1:	mov    %rax,0x380(%rsp)
  81fab9:	lea    0x110(%rsp),%rax
  81fac1:	mov    %rax,0x388(%rsp)
  81fac9:	movq   $0x6,0x390(%rsp)
  81fad5:	lea    0x380(%rsp),%rsi
  81fadd:	mov    0x100(%rsp),%r12
  81fae5:	mov    %r12,%rdi
  81fae8:	call   *0x65fa72(%rip)        # e7f560 <_DYNAMIC+0x5d8>
  81faee:	mov    %rax,%r13
  81faf1:	mov    %rax,0x2e0(%rsp)
  81faf9:	lea    0x2e0(%rsp),%rdx
  81fb01:	mov    %r12,%rdi
  81fb04:	mov    0x460(%rsp),%rsi
  81fb0c:	call   81cb60 <<gpui_gpu::renderer::GpuContext>::submit>
  81fb11:	mov    %rax,0x20(%rsp)
  81fb16:	xor    %ebp,%ebp
  81fb18:	mov    0x450(%rsp),%rax
  81fb20:	cmp    0x458(%rsp),%rax
  81fb28:	setne  %bpl
  81fb2c:	shl    $0x1f,%ebp
  81fb2f:	or     %r14d,%ebp
  81fb32:	shl    $0x20,%r15
  81fb36:	or     %r15,%rbp
  81fb39:	mov    (%rbx),%rax
  81fb3c:	test   %rax,%rax
  81fb3f:	je     81fb50 <<gpui_gpu::renderer::RendererState>::render+0x2190>
  81fb41:	lock decq (%rax)
  81fb45:	jne    81fb50 <<gpui_gpu::renderer::RendererState>::render+0x2190>
  81fb47:	mov    %rbx,%rdi
  81fb4a:	call   *0x65f950(%rip)        # e7f4a0 <_DYNAMIC+0x518>
  81fb50:	mov    (%rsp),%rax
  81fb54:	mov    %r13,0x330(%rax)
  81fb5b:	mov    %rbp,0x338(%rax)
  81fb62:	mov    0x10(%rax),%r8
  81fb66:	mov    0x28(%rax),%rsi
  81fb6a:	mov    0x70(%rax),%rcx
  81fb6e:	mov    %rcx,0x38(%rsp)
  81fb73:	shl    $0x4,%r8
  81fb77:	mov    0x68(%rsp),%rdx
  81fb7c:	lea    (%r8,%rdx,4),%rdi
  81fb80:	lea    (%rdi,%rsi,8),%rsi
  81fb84:	mov    %rcx,%rdi
  81fb87:	shl    $0x5,%rdi
  81fb8b:	lea    (%rdi,%rsi,1),%rcx
  81fb8f:	add    $0x30,%rcx
  81fb93:	mov    %rcx,0x18(%rsp)
  81fb98:	mov    0x278(%rax),%rdi
  81fb9f:	add    0x250(%rax),%rdi
  81fba6:	add    0x2a0(%rax),%rdi
  81fbad:	add    0x2c8(%rax),%rdi
  81fbb4:	add    0x2f0(%rax),%rdi
  81fbbb:	mov    0x308(%rax),%rsi
  81fbc2:	add    0x310(%rax),%rsi
  81fbc9:	mov    0x150(%rax),%r9d
  81fbd0:	imul   %r9,%r9
  81fbd4:	mov    0xb8(%rsp),%r11
  81fbdc:	mov    %r11,%rcx
  81fbdf:	sub    %rdx,%rcx
  81fbe2:	mov    0x60(%rsp),%r10
  81fbe7:	mov    %r10,%r12
  81fbea:	mov    0x240(%rsp),%rbp
  81fbf2:	sub    %rbp,%r12
  81fbf5:	mov    0x160(%rax),%rbx
  81fbfc:	inc    %rbx
  81fbff:	mov    $0xffffffffffffffff,%r14
  81fc06:	cmovne %rbx,%r14
  81fc0a:	mov    (%rax),%rbx
  81fc0d:	shl    $0x4,%rbx
  81fc11:	mov    0x48(%rax),%r15
  81fc15:	add    0x30(%rax),%r15
  81fc19:	mov    0x18(%rax),%r13
  81fc1d:	lea    (%rbx,%r13,8),%rbx
  81fc21:	lea    (%rbx,%r15,4),%rbx
  81fc25:	mov    0x60(%rax),%r15
  81fc29:	shl    $0x5,%r15
  81fc2d:	add    %rbx,%r15
  81fc30:	mov    0x138(%rax),%rbx
  81fc37:	mov    0x130(%rax),%r13
  81fc3e:	mov    %r14,0x160(%rax)
  81fc45:	mov    %r10,0x168(%rax)
  81fc4c:	lea    (%r11,%r11,1),%r14
  81fc50:	mov    %r14,0x170(%rax)
  81fc57:	movq   $0x1,0x178(%rax)
  81fc62:	mov    %r10,0x180(%rax)
  81fc69:	mov    %rdx,0x188(%rax)
  81fc70:	mov    %r11,0x190(%rax)
  81fc77:	mov    %rcx,0x198(%rax)
  81fc7e:	mov    0x8(%rsp),%rcx
  81fc83:	mov    %rcx,0x1a0(%rax)
  81fc8a:	mov    0x10(%rsp),%rcx
  81fc8f:	mov    %rcx,0x1a8(%rax)
  81fc96:	mov    0x30(%rsp),%rcx
  81fc9b:	mov    %rcx,0x1b0(%rax)
  81fca2:	mov    0x18(%rsp),%rcx
  81fca7:	mov    %rcx,0x1b8(%rax)
  81fcae:	mov    %r8,0x1c0(%rax)
  81fcb5:	mov    0x238(%rsp),%rdx
  81fcbd:	mov    %rdx,0x1c8(%rax)
  81fcc4:	mov    %rbp,0x1d0(%rax)
  81fccb:	mov    %r12,0x1d8(%rax)
  81fcd2:	mov    0x248(%rsp),%rcx
  81fcda:	mov    %rcx,0x1e0(%rax)
  81fce1:	mov    %rdi,0x1e8(%rax)
  81fce8:	mov    %r9,0x1f0(%rax)
  81fcef:	add    %rbx,%r13
  81fcf2:	mov    %rbx,0x1f8(%rax)
  81fcf9:	mov    %r13,0x200(%rax)
  81fd00:	mov    %r15,0x208(%rax)
  81fd07:	mov    0x38(%rsp),%rcx
  81fd0c:	mov    %rcx,0x210(%rax)
  81fd13:	mov    %rsi,0x218(%rax)
  81fd1a:	movb   $0x0,0x220(%rax)
  81fd21:	mov    0x50(%rsp),%rdi
  81fd26:	mov    0x20(%rsp),%rax
  81fd2b:	mov    %rax,0x8(%rdi)
  81fd2f:	movl   $0xffffffff,(%rdi)
  81fd35:	jmp    81dad1 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81fd3a:	mov    0x50(%rsp),%rdi
  81fd3f:	jmp    81dac3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81fd44:	movq   $0x0,0x10(%rsp)
  81fd4d:	xor    %eax,%eax
  81fd4f:	movq   $0x0,0x8(%rsp)
  81fd58:	jmp    81fd6c <<gpui_gpu::renderer::RendererState>::render+0x23ac>
  81fd5a:	incq   0x8(%rsp)
  81fd5f:	add    $0x8,%rax
  81fd63:	cmp    %rax,%rdi
  81fd66:	je     81f74e <<gpui_gpu::renderer::RendererState>::render+0x1d8e>
  81fd6c:	mov    0x4(%r8,%rax,1),%ecx
  81fd71:	mov    %ecx,%edx
  81fd73:	neg    %edx
  81fd75:	jo     81fd5a <<gpui_gpu::renderer::RendererState>::render+0x239a>
  81fd77:	cmp    %ecx,(%r8,%rax,1)
  81fd7b:	je     81fd5f <<gpui_gpu::renderer::RendererState>::render+0x239f>
  81fd7d:	lea    0x60de84(%rip),%rdi        # e2dc08 <anon.e7af5e0dba0d7261d22cb76253955a85.29.llvm.7635581776195589086+0x10>
  81fd84:	call   *0x65f7de(%rip)        # e7f568 <_DYNAMIC+0x5e0>
  81fd8a:	lea    0x60dcc7(%rip),%rdi        # e2da58 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x20>
  81fd91:	call   *0x65f7d9(%rip)        # e7f570 <_DYNAMIC+0x5e8>
  81fd97:	mov    0x40(%rsp),%rdi
  81fd9c:	add    0x250(%rsp),%rdi
  81fda4:	add    %rdx,%rdi
  81fda7:	lea    0x60dcc2(%rip),%rdx        # e2da70 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x38>
  81fdae:	call   *0x65f6cc(%rip)        # e7f480 <_DYNAMIC+0x4f8>
  81fdb4:	lea    0x60dccd(%rip),%rdx        # e2da88 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x50>
  81fdbb:	call   *0x65f6bf(%rip)        # e7f480 <_DYNAMIC+0x4f8>
  81fdc1:	mov    %rax,%r14
  81fdc4:	mov    (%rsp),%rax
  81fdc8:	mov    %r13,0x330(%rax)
  81fdcf:	mov    %rbp,0x338(%rax)
  81fdd6:	mov    %r14,%rdi
  81fdd9:	call   e2bd40 <_Unwind_Resume@plt>
  81fdde:	mov    %rax,%r14
  81fde1:	lock decq 0x0(%r13)
  81fde6:	jne    81fe08 <<gpui_gpu::renderer::RendererState>::render+0x2448>
  81fde8:	lea    0x2e0(%rsp),%rdi
  81fdf0:	call   *0x65f6aa(%rip)        # e7f4a0 <_DYNAMIC+0x518>
  81fdf6:	jmp    81fe08 <<gpui_gpu::renderer::RendererState>::render+0x2448>
  81fdf8:	call   *0x65f3da(%rip)        # e7f1d8 <_DYNAMIC+0x250>
  81fdfe:	mov    %rax,%r14
  81fe01:	movq   $0x0,(%rbx)
  81fe08:	mov    %r14,%rdi
  81fe0b:	call   e2bd40 <_Unwind_Resume@plt>

FUNCTION <gpui_gpu::renderer::RendererState>::bin_draw bytes=4184 frame=824

/tmp/gpui-legacy-coverage-codegen/legacy277/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081fe10 <<gpui_gpu::renderer::RendererState>::bin_draw>:
  81fe10:	push   %rbp
  81fe11:	push   %r15
  81fe13:	push   %r14
  81fe15:	push   %r13
  81fe17:	push   %r12
  81fe19:	push   %rbx
  81fe1a:	sub    $0x308,%rsp
  81fe21:	movss  0x88(%rdx),%xmm3
  81fe29:	movss  -0x770e75(%rip),%xmm0        # aefbc <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  81fe31:	movaps %xmm3,%xmm1
  81fe34:	subss  %xmm0,%xmm1
  81fe38:	cvttss2si %xmm1,%rax
  81fe3d:	cvttss2si %xmm3,%r10
  81fe42:	mov    %r10,%r12
  81fe45:	sar    $0x3f,%r12
  81fe49:	and    %rax,%r12
  81fe4c:	or     %r10,%r12
  81fe4f:	xor    %eax,%eax
  81fe51:	xorps  %xmm1,%xmm1
  81fe54:	ucomiss %xmm1,%xmm3
  81fe57:	cmovb  %rax,%r12
  81fe5b:	movss  0x90(%rdx),%xmm4
  81fe63:	movss  -0x770eab(%rip),%xmm2        # aefc0 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  81fe6b:	ucomiss %xmm2,%xmm3
  81fe6e:	mov    $0xffffffffffffffff,%r10
  81fe75:	cmova  %r10,%r12
  81fe79:	movaps %xmm4,%xmm3
  81fe7c:	subss  %xmm0,%xmm3
  81fe80:	cvttss2si %xmm3,%r11
  81fe85:	cvttss2si %xmm4,%rbx
  81fe8a:	mov    %rbx,%r14
  81fe8d:	sar    $0x3f,%r14
  81fe91:	and    %r11,%r14
  81fe94:	or     %rbx,%r14
  81fe97:	ucomiss %xmm1,%xmm4
  81fe9a:	cmovb  %rax,%r14
  81fe9e:	ucomiss %xmm2,%xmm4
  81fea1:	cmova  %r10,%r14
  81fea5:	movss  0x8c(%rdx),%xmm3
  81fead:	lea    (%r12,%r14,1),%rbx
  81feb1:	dec    %rbx
  81feb4:	shr    $0x4,%rbx
  81feb8:	shr    $0x4,%r12
  81febc:	mov    %rbx,%rbp
  81febf:	sub    %r12,%rbp
  81fec2:	inc    %rbp
  81fec5:	movaps %xmm3,%xmm4
  81fec8:	subss  %xmm0,%xmm4
  81fecc:	cvttss2si %xmm4,%r15
  81fed1:	cvttss2si %xmm3,%r11
  81fed6:	mov    %r11,%r14
  81fed9:	sar    $0x3f,%r14
  81fedd:	and    %r15,%r14
  81fee0:	or     %r11,%r14
  81fee3:	ucomiss %xmm1,%xmm3
  81fee6:	cmovb  %rax,%r14
  81feea:	ucomiss %xmm2,%xmm3
  81feed:	movss  0x94(%rdx),%xmm3
  81fef5:	cmova  %r10,%r14
  81fef9:	movaps %xmm3,%xmm4
  81fefc:	subss  %xmm0,%xmm4
  81ff00:	cvttss2si %xmm4,%r13
  81ff05:	cvttss2si %xmm3,%r11
  81ff0a:	mov    %r11,%r15
  81ff0d:	sar    $0x3f,%r15
  81ff11:	and    %r13,%r15
  81ff14:	or     %r11,%r15
  81ff17:	ucomiss %xmm1,%xmm3
  81ff1a:	cmovb  %rax,%r15
  81ff1e:	ucomiss %xmm2,%xmm3
  81ff21:	cmova  %r10,%r15
  81ff25:	lea    (%r14,%r15,1),%r10
  81ff29:	dec    %r10
  81ff2c:	shr    $0x4,%r10
  81ff30:	shr    $0x4,%r14
  81ff34:	mov    %r10,%r11
  81ff37:	sub    %r14,%r11
  81ff3a:	inc    %r11
  81ff3d:	imul   %rbp,%r11
  81ff41:	add    0x358(%rsp),%r11
  81ff49:	setb   %al
  81ff4c:	cmp    $0x400001,%r11
  81ff53:	setae  %bpl
  81ff57:	or     %al,%bpl
  81ff5a:	mov    $0x6,%eax
  81ff5f:	jne    81ff9f <<gpui_gpu::renderer::RendererState>::bin_draw+0x18f>
  81ff61:	mov    %r8d,0xac(%rsp)
  81ff69:	mov    %r9,0x98(%rsp)
  81ff71:	mov    %r11,0x190(%rsp)
  81ff79:	mov    %rdi,0x198(%rsp)
  81ff81:	cmp    %r14,%r10
  81ff84:	jae    81ffb3 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1a3>
  81ff86:	mov    0x198(%rsp),%rdi
  81ff8e:	mov    0x190(%rsp),%rax
  81ff96:	mov    %rax,0x8(%rdi)
  81ff9a:	mov    $0xffffffff,%eax
  81ff9f:	mov    %eax,(%rdi)
  81ffa1:	add    $0x308,%rsp
  81ffa8:	pop    %rbx
  81ffa9:	pop    %r12
  81ffab:	pop    %r13
  81ffad:	pop    %r14
  81ffaf:	pop    %r15
  81ffb1:	pop    %rbp
  81ffb2:	ret
  81ffb3:	mov    %r12,%r9
  81ffb6:	cmp    %r12,%rbx
  81ffb9:	jae    81ffd6 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1c6>
  81ffbb:	nopl   0x0(%rax,%rax,1)
  81ffc0:	mov    %r14,%rax
  81ffc3:	cmp    %r10,%r14
  81ffc6:	adc    $0x0,%r14
  81ffca:	cmp    %r10,%rax
  81ffcd:	jae    81ff86 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  81ffcf:	cmp    %r10,%r14
  81ffd2:	jbe    81ffc0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1b0>
  81ffd4:	jmp    81ff86 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  81ffd6:	mov    0x340(%rsp),%r13
  81ffde:	movd   0xa4(%rdx),%xmm0
  81ffe6:	mov    0x20(%rsi),%rbp
  81ffea:	movdqu 0x98(%rdx),%xmm1
  81fff2:	movd   0xa0(%rdx),%xmm2
  81fffa:	punpckldq %xmm0,%xmm2
  81fffe:	punpcklqdq %xmm2,%xmm1
  820002:	movdqa -0x7736fa(%rip),%xmm2        # ac910 <anon.fd4379edd0b71335c3c29b3337cd5ea0.320.llvm.353578272256937679+0x110>
  82000a:	pand   %xmm1,%xmm2
  82000e:	paddd  -0x7734a6(%rip),%xmm2        # acb70 <anon.fd4379edd0b71335c3c29b3337cd5ea0.320.llvm.353578272256937679+0x370>
  820016:	pxor   -0x771cee(%rip),%xmm2        # ae330 <anon.630a3fff68f6bca64b568be97512ab45.101.llvm.826976926275214120+0x80>
  82001e:	pcmpgtd -0x772896(%rip),%xmm2        # ad790 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x420>
  820026:	mov    %rsi,%rax
  820029:	mov    0x28(%rsi),%rsi
  82002d:	pandn  %xmm1,%xmm2
  820031:	movmskps %xmm2,%edi
  820034:	test   %edi,%edi
  820036:	mov    %r10,0xb8(%rsp)
  82003e:	jne    820dbc <<gpui_gpu::renderer::RendererState>::bin_draw+0xfac>
  820044:	ucomiss -0x7712cb(%rip),%xmm0        # aed80 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  82004b:	jne    820dbc <<gpui_gpu::renderer::RendererState>::bin_draw+0xfac>
  820051:	jp     820dbc <<gpui_gpu::renderer::RendererState>::bin_draw+0xfac>
  820057:	cmpb   $0x0,0x340(%rax)
  82005e:	je     820dbc <<gpui_gpu::renderer::RendererState>::bin_draw+0xfac>
  820064:	cmpb   $0x0,(%rdx)
  820067:	jne    820dbc <<gpui_gpu::renderer::RendererState>::bin_draw+0xfac>
  82006d:	test   %r13,%r13
  820070:	je     820e33 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1023>
  820076:	mov    0x350(%rsp),%r12d
  82007e:	mov    0x348(%rsp),%r8d
  820086:	movd   %ecx,%xmm2
  82008a:	shr    $0x20,%rcx
  82008e:	movss  0x78(%rdx),%xmm0
  820093:	movss  0x80(%rdx),%xmm3
  82009b:	cvtss2sd %xmm0,%xmm0
  82009f:	movss  0x7c(%rdx),%xmm1
  8200a4:	cvtss2sd %xmm1,%xmm1
  8200a8:	cvtss2sd %xmm3,%xmm13
  8200ad:	movss  0x84(%rdx),%xmm3
  8200b5:	addsd  %xmm0,%xmm13
  8200ba:	cvtss2sd %xmm3,%xmm3
  8200be:	addsd  %xmm1,%xmm3
  8200c2:	movsd  %xmm3,0x1c8(%rsp)
  8200cb:	movsd  0x48(%rdx),%xmm6
  8200d0:	movsd  0x58(%rdx),%xmm7
  8200d5:	movss  0x38(%rdx),%xmm3
  8200da:	movss  0x3c(%rdx),%xmm4
  8200df:	movss  0x40(%rdx),%xmm5
  8200e4:	cvtss2sd %xmm3,%xmm8
  8200e9:	movss  0x44(%rdx),%xmm3
  8200ee:	cvtss2sd %xmm5,%xmm5
  8200f2:	movaps -0x77534a(%rip),%xmm9        # aadb0 <GCC_except_table0+0x88>
  8200fa:	movaps %xmm8,0x80(%rsp)
  820103:	andps  %xmm9,%xmm8
  820107:	movaps %xmm8,0x70(%rsp)
  82010d:	movaps %xmm5,0x50(%rsp)
  820112:	andps  %xmm9,%xmm5
  820116:	movaps %xmm5,0x60(%rsp)
  82011b:	cvtss2sd %xmm2,%xmm2
  82011f:	movsd  %xmm2,0x8(%rsp)
  820125:	movaps %xmm6,%xmm2
  820128:	andps  %xmm9,%xmm2
  82012c:	movaps %xmm2,0x270(%rsp)
  820134:	movaps %xmm7,%xmm2
  820137:	andps  %xmm9,%xmm2
  82013b:	movaps %xmm2,0x250(%rsp)
  820143:	xorps  %xmm2,%xmm2
  820146:	cvtss2sd %xmm4,%xmm2
  82014a:	cvtss2sd %xmm3,%xmm3
  82014e:	movsd  0x68(%rdx),%xmm4
  820153:	movaps %xmm4,%xmm5
  820156:	andps  %xmm9,%xmm5
  82015a:	movaps %xmm5,0x100(%rsp)
  820162:	movaps %xmm2,0x40(%rsp)
  820167:	andps  %xmm9,%xmm2
  82016b:	movaps %xmm2,0x30(%rsp)
  820170:	movaps %xmm3,0x10(%rsp)
  820175:	andps  %xmm9,%xmm3
  820179:	movaps %xmm3,0x20(%rsp)
  82017e:	movd   %ecx,%xmm2
  820182:	cvtss2sd %xmm2,%xmm2
  820186:	movsd  %xmm2,(%rsp)
  82018b:	movsd  0x50(%rdx),%xmm2
  820190:	movaps %xmm2,%xmm3
  820193:	andps  %xmm9,%xmm3
  820197:	movaps %xmm3,0x1f0(%rsp)
  82019f:	movsd  0x60(%rdx),%xmm3
  8201a4:	movaps %xmm3,%xmm5
  8201a7:	andps  %xmm9,%xmm5
  8201ab:	movaps %xmm5,0x1d0(%rsp)
  8201b3:	movsd  0x70(%rdx),%xmm5
  8201b8:	movaps %xmm5,%xmm8
  8201bc:	andps  %xmm9,%xmm8
  8201c0:	movaps %xmm8,0xc0(%rsp)
  8201c9:	mov    0x58(%rax),%rcx
  8201cd:	mov    %rcx,0xb0(%rsp)
  8201d5:	mov    0x50(%rax),%rax
  8201d9:	mov    %rax,0x168(%rsp)
  8201e1:	mov    0x98(%rsp),%rax
  8201e9:	inc    %eax
  8201eb:	mov    %rax,0x98(%rsp)
  8201f3:	movaps %xmm2,0x200(%rsp)
  8201fb:	cvtsd2ss %xmm2,%xmm2
  8201ff:	xorps  %xmm8,%xmm8
  820203:	cvtss2sd %xmm2,%xmm8
  820208:	movaps %xmm6,0x280(%rsp)
  820210:	movaps %xmm6,%xmm2
  820213:	movaps %xmm7,0x260(%rsp)
  82021b:	movlhps %xmm7,%xmm2
  82021e:	cvtpd2ps %xmm2,%xmm2
  820222:	cvtps2pd %xmm2,%xmm6
  820225:	movaps %xmm3,0x1e0(%rsp)
  82022d:	xorps  %xmm2,%xmm2
  820230:	cvtsd2ss %xmm3,%xmm2
  820234:	xorps  %xmm3,%xmm3
  820237:	cvtss2sd %xmm2,%xmm3
  82023b:	movaps %xmm4,0x110(%rsp)
  820243:	xorps  %xmm2,%xmm2
  820246:	cvtsd2ss %xmm4,%xmm2
  82024a:	xorps  %xmm4,%xmm4
  82024d:	cvtss2sd %xmm2,%xmm4
  820251:	movaps %xmm5,0xd0(%rsp)
  820259:	xorps  %xmm2,%xmm2
  82025c:	cvtsd2ss %xmm5,%xmm2
  820260:	cvtss2sd %xmm2,%xmm2
  820264:	movaps %xmm6,%xmm5
  820267:	andps  %xmm9,%xmm5
  82026b:	movaps %xmm4,0x130(%rsp)
  820273:	andps  %xmm9,%xmm4
  820277:	movaps %xmm4,0x120(%rsp)
  82027f:	movaps %xmm8,0x240(%rsp)
  820288:	andps  %xmm9,%xmm8
  82028c:	movaps %xmm8,0x230(%rsp)
  820295:	movaps %xmm3,0x220(%rsp)
  82029d:	andps  %xmm9,%xmm3
  8202a1:	movaps %xmm3,0x210(%rsp)
  8202a9:	movaps %xmm2,0xe0(%rsp)
  8202b1:	andps  %xmm2,%xmm9
  8202b5:	movaps %xmm9,0xf0(%rsp)
  8202be:	movaps %xmm6,0x2a0(%rsp)
  8202c6:	movhlps %xmm6,%xmm6
  8202c9:	movaps %xmm6,0x2d0(%rsp)
  8202d1:	movaps %xmm5,0x290(%rsp)
  8202d9:	movhlps %xmm5,%xmm5
  8202dc:	movaps %xmm5,0x2c0(%rsp)
  8202e4:	mov    %r9,0x1b8(%rsp)
  8202ec:	movsd  %xmm13,0xa0(%rsp)
  8202f6:	cs nopw 0x0(%rax,%rax,1)
  820300:	mov    %r14,%rcx
  820303:	cmp    %r10,%r14
  820306:	adc    $0x0,%r14
  82030a:	mov    %rcx,0x1c0(%rsp)
  820312:	imul   %r13,%rcx
  820316:	mov    %r9,%rdi
  820319:	nopl   0x0(%rax)
  820320:	cmp    %rbx,%rdi
  820323:	adc    $0x0,%r9
  820327:	lea    (%rdi,%rcx,1),%r10
  82032b:	mov    %r10,%rax
  82032e:	shr    $0x20,%rax
  820332:	je     820340 <<gpui_gpu::renderer::RendererState>::bin_draw+0x530>
  820334:	mov    %r10,%rax
  820337:	xor    %edx,%edx
  820339:	div    %r13
  82033c:	jmp    820348 <<gpui_gpu::renderer::RendererState>::bin_draw+0x538>
  82033e:	xchg   %ax,%ax
  820340:	mov    %r10d,%eax
  820343:	xor    %edx,%edx
  820345:	div    %r13d
  820348:	shl    $0x4,%edx
  82034b:	shl    $0x4,%eax
  82034e:	lea    0x10(%rdx),%r11d
  820352:	cmp    %r11d,%r8d
  820355:	cmovb  %r8d,%r11d
  820359:	lea    0x10(%rax),%r15d
  82035d:	cmp    %r15d,%r12d
  820360:	cmovb  %r12d,%r15d
  820364:	xorps  %xmm11,%xmm11
  820368:	cvtsi2sd %edx,%xmm11
  82036d:	ucomisd %xmm11,%xmm0
  820372:	ja     8203b0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820374:	mov    %eax,%eax
  820376:	xorps  %xmm2,%xmm2
  820379:	cvtsi2sd %rax,%xmm2
  82037e:	ucomisd %xmm2,%xmm1
  820382:	ja     8203b0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820384:	xorps  %xmm15,%xmm15
  820388:	cvtsi2sd %r11d,%xmm15
  82038d:	ucomisd %xmm13,%xmm15
  820392:	ja     8203b0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820394:	xorps  %xmm14,%xmm14
  820398:	cvtsi2sd %r15d,%xmm14
  82039d:	ucomisd 0x1c8(%rsp),%xmm14
  8203a7:	jbe    8203d8 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5c8>
  8203a9:	nopl   0x0(%rax)
  8203b0:	cmp    %rsi,%r10
  8203b3:	jae    820e23 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1013>
  8203b9:	incl   0x4(%rbp,%r10,8)
  8203be:	cmp    %rbx,%rdi
  8203c1:	jae    820d90 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf80>
  8203c7:	mov    %r9,%rdi
  8203ca:	cmp    %rbx,%r9
  8203cd:	jbe    820320 <<gpui_gpu::renderer::RendererState>::bin_draw+0x510>
  8203d3:	jmp    820d90 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf80>
  8203d8:	unpcklpd %xmm2,%xmm11
  8203dd:	addpd  -0x773316(%rip),%xmm11        # ad0d0 <anon.a16d5d421a76dfd8c37a17b53540311d.58.llvm.14190004212411149437+0x270>
  8203e6:	movapd %xmm11,%xmm9
  8203eb:	mulpd  0x2a0(%rsp),%xmm9
  8203f5:	movapd %xmm9,%xmm12
  8203fa:	unpckhpd %xmm9,%xmm12
  8203ff:	movapd %xmm9,%xmm2
  820404:	addsd  %xmm12,%xmm2
  820409:	addsd  0x130(%rsp),%xmm2
  820412:	subsd  0x80(%rsp),%xmm2
  82041b:	movapd 0x290(%rsp),%xmm7
  820424:	mulpd  %xmm11,%xmm7
  820429:	movapd %xmm7,%xmm8
  82042e:	unpckhpd %xmm7,%xmm8
  820433:	movapd %xmm7,%xmm3
  820437:	addsd  %xmm8,%xmm3
  82043c:	addsd  0x120(%rsp),%xmm3
  820445:	addsd  0x70(%rsp),%xmm3
  82044b:	addsd  0x60(%rsp),%xmm3
  820451:	addsd  -0x770be1(%rip),%xmm3        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820459:	mulsd  -0x770c61(%rip),%xmm3        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820461:	addsd  0x8(%rsp),%xmm3
  820467:	ucomisd %xmm2,%xmm3
  82046b:	jae    8203b0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820471:	movapd 0x50(%rsp),%xmm4
  820477:	subsd  %xmm2,%xmm4
  82047b:	ucomisd %xmm4,%xmm3
  82047f:	jae    8203b0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820485:	movapd %xmm11,%xmm6
  82048a:	unpckhpd %xmm11,%xmm6
  82048f:	movapd 0x260(%rsp),%xmm10
  820499:	mulsd  %xmm6,%xmm10
  82049e:	movapd 0x250(%rsp),%xmm3
  8204a7:	mulsd  %xmm6,%xmm3
  8204ab:	movapd 0x280(%rsp),%xmm2
  8204b4:	mulsd  %xmm11,%xmm2
  8204b9:	movapd %xmm2,0x150(%rsp)
  8204c2:	addsd  %xmm10,%xmm2
  8204c7:	addsd  0x110(%rsp),%xmm2
  8204d0:	subsd  0x80(%rsp),%xmm2
  8204d9:	movapd 0x270(%rsp),%xmm4
  8204e2:	mulsd  %xmm11,%xmm4
  8204e7:	movsd  %xmm4,0x1b0(%rsp)
  8204f0:	addsd  %xmm3,%xmm4
  8204f4:	addsd  0x100(%rsp),%xmm4
  8204fd:	addsd  0x70(%rsp),%xmm4
  820503:	addsd  0x60(%rsp),%xmm4
  820509:	addsd  -0x770c99(%rip),%xmm4        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820511:	mulsd  -0x770741(%rip),%xmm4        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820519:	ucomisd %xmm2,%xmm4
  82051d:	jae    8203b0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820523:	movapd 0x50(%rsp),%xmm5
  820529:	subsd  %xmm2,%xmm5
  82052d:	ucomisd %xmm5,%xmm4
  820531:	jae    8203b0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820537:	movapd %xmm6,%xmm4
  82053b:	mulsd  0x220(%rsp),%xmm4
  820544:	movapd %xmm6,%xmm2
  820548:	mulsd  0x210(%rsp),%xmm2
  820551:	movapd %xmm11,%xmm5
  820556:	mulsd  0x240(%rsp),%xmm5
  82055f:	movsd  %xmm5,0x1a8(%rsp)
  820568:	movapd %xmm4,0x140(%rsp)
  820571:	addsd  %xmm4,%xmm5
  820575:	addsd  0xe0(%rsp),%xmm5
  82057e:	subsd  0x40(%rsp),%xmm5
  820584:	movapd %xmm11,%xmm4
  820589:	mulsd  0x230(%rsp),%xmm4
  820592:	movsd  %xmm4,0x1a0(%rsp)
  82059b:	addsd  %xmm2,%xmm4
  82059f:	addsd  0xf0(%rsp),%xmm4
  8205a8:	addsd  0x30(%rsp),%xmm4
  8205ae:	addsd  0x20(%rsp),%xmm4
  8205b4:	addsd  -0x770d44(%rip),%xmm4        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8205bc:	mulsd  -0x770dc4(%rip),%xmm4        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  8205c4:	addsd  (%rsp),%xmm4
  8205c9:	ucomisd %xmm5,%xmm4
  8205cd:	jae    8203b0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  8205d3:	movapd 0x10(%rsp),%xmm13
  8205da:	subsd  %xmm5,%xmm13
  8205df:	ucomisd %xmm13,%xmm4
  8205e4:	movsd  0xa0(%rsp),%xmm13
  8205ee:	jae    8203b0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  8205f4:	movapd 0x1e0(%rsp),%xmm4
  8205fd:	mulsd  %xmm6,%xmm4
  820601:	mulsd  0x1d0(%rsp),%xmm6
  82060a:	movapd 0x200(%rsp),%xmm5
  820613:	mulsd  %xmm11,%xmm5
  820618:	movapd %xmm5,0x2e0(%rsp)
  820621:	movapd %xmm4,0x2f0(%rsp)
  82062a:	addsd  %xmm4,%xmm5
  82062e:	addsd  0xd0(%rsp),%xmm5
  820637:	subsd  0x40(%rsp),%xmm5
  82063d:	mulsd  0x1f0(%rsp),%xmm11
  820647:	movapd %xmm11,%xmm4
  82064c:	addsd  %xmm6,%xmm4
  820650:	addsd  0xc0(%rsp),%xmm4
  820659:	addsd  0x30(%rsp),%xmm4
  82065f:	addsd  0x20(%rsp),%xmm4
  820665:	addsd  -0x770df5(%rip),%xmm4        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  82066d:	mulsd  -0x77089d(%rip),%xmm4        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820675:	ucomisd %xmm5,%xmm4
  820679:	jae    8203b0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  82067f:	movapd 0x10(%rsp),%xmm13
  820686:	subsd  %xmm5,%xmm13
  82068b:	ucomisd %xmm13,%xmm4
  820690:	movsd  0xa0(%rsp),%xmm13
  82069a:	jae    8203b0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  8206a0:	addsd  -0x771121(%rip),%xmm15        # af588 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  8206a9:	movapd %xmm15,%xmm4
  8206ae:	mulsd  0x2a0(%rsp),%xmm4
  8206b7:	movsd  %xmm4,0x188(%rsp)
  8206c0:	addsd  %xmm4,%xmm12
  8206c5:	addsd  0x130(%rsp),%xmm12
  8206cf:	subsd  0x80(%rsp),%xmm12
  8206d9:	movapd 0x290(%rsp),%xmm4
  8206e2:	mulsd  %xmm15,%xmm4
  8206e7:	movsd  %xmm4,0x180(%rsp)
  8206f0:	addsd  %xmm4,%xmm8
  8206f5:	addsd  0x120(%rsp),%xmm8
  8206ff:	addsd  0x70(%rsp),%xmm8
  820706:	addsd  0x60(%rsp),%xmm8
  82070d:	addsd  -0x770e9e(%rip),%xmm8        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820716:	mulsd  -0x770f1f(%rip),%xmm8        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  82071f:	addsd  0x8(%rsp),%xmm8
  820726:	ucomisd %xmm12,%xmm8
  82072b:	jae    8203b0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820731:	movapd 0x50(%rsp),%xmm4
  820737:	subsd  %xmm12,%xmm4
  82073c:	ucomisd %xmm4,%xmm8
  820741:	jae    8203b0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820747:	movapd 0x280(%rsp),%xmm12
  820751:	mulsd  %xmm15,%xmm12
  820756:	addsd  %xmm12,%xmm10
  82075b:	addsd  0x110(%rsp),%xmm10
  820765:	subsd  0x80(%rsp),%xmm10
  82076f:	movapd 0x270(%rsp),%xmm4
  820778:	mulsd  %xmm15,%xmm4
  82077d:	movsd  %xmm4,0x178(%rsp)
  820786:	addsd  %xmm4,%xmm3
  82078a:	addsd  0x100(%rsp),%xmm3
  820793:	addsd  0x70(%rsp),%xmm3
  820799:	addsd  0x60(%rsp),%xmm3
  82079f:	addsd  -0x770f2f(%rip),%xmm3        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8207a7:	mulsd  -0x7709d7(%rip),%xmm3        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  8207af:	ucomisd %xmm10,%xmm3
  8207b4:	jae    8203b0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  8207ba:	movapd 0x50(%rsp),%xmm4
  8207c0:	subsd  %xmm10,%xmm4
  8207c5:	ucomisd %xmm4,%xmm3
  8207c9:	jae    8203b0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  8207cf:	movapd %xmm15,%xmm3
  8207d4:	mulsd  0x240(%rsp),%xmm3
  8207dd:	movsd  %xmm3,0x170(%rsp)
  8207e6:	movapd 0x140(%rsp),%xmm5
  8207ef:	addsd  %xmm3,%xmm5
  8207f3:	addsd  0xe0(%rsp),%xmm5
  8207fc:	subsd  0x40(%rsp),%xmm5
  820802:	movapd %xmm15,%xmm3
  820807:	mulsd  0x230(%rsp),%xmm3
  820810:	movsd  %xmm3,0x140(%rsp)
  820819:	addsd  %xmm3,%xmm2
  82081d:	addsd  0xf0(%rsp),%xmm2
  820826:	addsd  0x30(%rsp),%xmm2
  82082c:	addsd  0x20(%rsp),%xmm2
  820832:	addsd  -0x770fc2(%rip),%xmm2        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  82083a:	mulsd  -0x771042(%rip),%xmm2        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820842:	addsd  (%rsp),%xmm2
  820847:	ucomisd %xmm5,%xmm2
  82084b:	jae    8203b0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820851:	movapd 0x10(%rsp),%xmm3
  820857:	subsd  %xmm5,%xmm3
  82085b:	ucomisd %xmm3,%xmm2
  82085f:	jae    8203b0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820865:	movapd 0x200(%rsp),%xmm2
  82086e:	mulsd  %xmm15,%xmm2
  820873:	movapd %xmm2,0x2b0(%rsp)
  82087c:	movapd 0x2f0(%rsp),%xmm4
  820885:	addsd  %xmm2,%xmm4
  820889:	addsd  0xd0(%rsp),%xmm4
  820892:	subsd  0x40(%rsp),%xmm4
  820898:	mulsd  0x1f0(%rsp),%xmm15
  8208a2:	addsd  %xmm15,%xmm6
  8208a7:	addsd  0xc0(%rsp),%xmm6
  8208b0:	addsd  0x30(%rsp),%xmm6
  8208b6:	addsd  0x20(%rsp),%xmm6
  8208bc:	addsd  -0x77104c(%rip),%xmm6        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8208c4:	mulsd  -0x770af4(%rip),%xmm6        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  8208cc:	ucomisd %xmm4,%xmm6
  8208d0:	jae    8203b0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  8208d6:	movapd 0x10(%rsp),%xmm2
  8208dc:	subsd  %xmm4,%xmm2
  8208e0:	ucomisd %xmm2,%xmm6
  8208e4:	jae    8203b0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  8208ea:	addsd  -0x77136b(%rip),%xmm14        # af588 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  8208f3:	movapd %xmm14,%xmm3
  8208f8:	mulsd  0x2d0(%rsp),%xmm3
  820901:	movapd %xmm14,%xmm2
  820906:	mulsd  0x2c0(%rsp),%xmm2
  82090f:	addsd  %xmm3,%xmm9
  820914:	addsd  0x130(%rsp),%xmm9
  82091e:	subsd  0x80(%rsp),%xmm9
  820928:	addsd  %xmm2,%xmm7
  82092c:	addsd  0x120(%rsp),%xmm7
  820935:	addsd  0x70(%rsp),%xmm7
  82093b:	addsd  0x60(%rsp),%xmm7
  820941:	addsd  -0x7710d1(%rip),%xmm7        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820949:	mulsd  -0x771151(%rip),%xmm7        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820951:	addsd  0x8(%rsp),%xmm7
  820957:	ucomisd %xmm9,%xmm7
  82095c:	jae    8203b0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820962:	movapd 0x50(%rsp),%xmm4
  820968:	subsd  %xmm9,%xmm4
  82096d:	ucomisd %xmm4,%xmm7
  820971:	jae    8203b0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820977:	movapd 0x260(%rsp),%xmm6
  820980:	mulsd  %xmm14,%xmm6
  820985:	movapd 0x250(%rsp),%xmm5
  82098e:	mulsd  %xmm14,%xmm5
  820993:	movapd 0x150(%rsp),%xmm4
  82099c:	addsd  %xmm6,%xmm4
  8209a0:	addsd  0x110(%rsp),%xmm4
  8209a9:	subsd  0x80(%rsp),%xmm4
  8209b2:	movsd  0x1b0(%rsp),%xmm9
  8209bc:	addsd  %xmm5,%xmm9
  8209c1:	addsd  0x100(%rsp),%xmm9
  8209cb:	addsd  0x70(%rsp),%xmm9
  8209d2:	addsd  0x60(%rsp),%xmm9
  8209d9:	addsd  -0x77116a(%rip),%xmm9        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8209e2:	mulsd  -0x770c13(%rip),%xmm9        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  8209eb:	ucomisd %xmm4,%xmm9
  8209f0:	jae    8203b0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  8209f6:	movapd %xmm4,%xmm7
  8209fa:	movapd 0x50(%rsp),%xmm4
  820a00:	subsd  %xmm7,%xmm4
  820a04:	ucomisd %xmm4,%xmm9
  820a09:	jae    8203b0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820a0f:	movapd %xmm14,%xmm7
  820a14:	mulsd  0x220(%rsp),%xmm7
  820a1d:	movapd %xmm14,%xmm9
  820a22:	mulsd  0x210(%rsp),%xmm9
  820a2c:	movsd  0x1a8(%rsp),%xmm8
  820a36:	addsd  %xmm7,%xmm8
  820a3b:	addsd  0xe0(%rsp),%xmm8
  820a45:	subsd  0x40(%rsp),%xmm8
  820a4c:	movapd %xmm12,%xmm4
  820a51:	movsd  0x1a0(%rsp),%xmm12
  820a5b:	movsd  %xmm9,0x150(%rsp)
  820a65:	addsd  %xmm9,%xmm12
  820a6a:	addsd  0xf0(%rsp),%xmm12
  820a74:	addsd  0x30(%rsp),%xmm12
  820a7b:	addsd  0x20(%rsp),%xmm12
  820a82:	addsd  -0x771213(%rip),%xmm12        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820a8b:	mulsd  -0x771294(%rip),%xmm12        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820a94:	addsd  (%rsp),%xmm12
  820a9a:	ucomisd %xmm8,%xmm12
  820a9f:	jae    8203b0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820aa5:	movapd %xmm8,%xmm9
  820aaa:	movapd 0x10(%rsp),%xmm8
  820ab1:	subsd  %xmm9,%xmm8
  820ab6:	ucomisd %xmm8,%xmm12
  820abb:	jae    8203b0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820ac1:	movapd 0x1e0(%rsp),%xmm8
  820acb:	mulsd  %xmm14,%xmm8
  820ad0:	mulsd  0x1d0(%rsp),%xmm14
  820ada:	movapd 0x2e0(%rsp),%xmm9
  820ae4:	addsd  %xmm8,%xmm9
  820ae9:	addsd  0xd0(%rsp),%xmm9
  820af3:	subsd  0x40(%rsp),%xmm9
  820afa:	addsd  %xmm14,%xmm11
  820aff:	addsd  0xc0(%rsp),%xmm11
  820b09:	addsd  0x30(%rsp),%xmm11
  820b10:	addsd  0x20(%rsp),%xmm11
  820b17:	addsd  -0x7712a8(%rip),%xmm11        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820b20:	mulsd  -0x770d51(%rip),%xmm11        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820b29:	ucomisd %xmm9,%xmm11
  820b2e:	jae    8203b0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820b34:	movapd %xmm9,%xmm10
  820b39:	movapd 0x10(%rsp),%xmm9
  820b40:	subsd  %xmm10,%xmm9
  820b45:	ucomisd %xmm9,%xmm11
  820b4a:	jae    8203b0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820b50:	movsd  0x188(%rsp),%xmm9
  820b5a:	addsd  %xmm3,%xmm9
  820b5f:	addsd  0x130(%rsp),%xmm9
  820b69:	subsd  0x80(%rsp),%xmm9
  820b73:	movsd  0x180(%rsp),%xmm10
  820b7d:	addsd  %xmm2,%xmm10
  820b82:	addsd  0x120(%rsp),%xmm10
  820b8c:	addsd  0x70(%rsp),%xmm10
  820b93:	addsd  0x60(%rsp),%xmm10
  820b9a:	addsd  -0x77132b(%rip),%xmm10        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820ba3:	mulsd  -0x7713ac(%rip),%xmm10        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820bac:	addsd  0x8(%rsp),%xmm10
  820bb3:	ucomisd %xmm9,%xmm10
  820bb8:	jae    8203b0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820bbe:	movapd %xmm4,%xmm12
  820bc3:	movapd 0x50(%rsp),%xmm2
  820bc9:	subsd  %xmm9,%xmm2
  820bce:	ucomisd %xmm2,%xmm10
  820bd3:	jae    8203b0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820bd9:	addsd  %xmm6,%xmm12
  820bde:	addsd  0x110(%rsp),%xmm12
  820be8:	subsd  0x80(%rsp),%xmm12
  820bf2:	movsd  0x178(%rsp),%xmm2
  820bfb:	addsd  %xmm5,%xmm2
  820bff:	addsd  0x100(%rsp),%xmm2
  820c08:	addsd  0x70(%rsp),%xmm2
  820c0e:	addsd  0x60(%rsp),%xmm2
  820c14:	addsd  -0x7713a4(%rip),%xmm2        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820c1c:	mulsd  -0x770e4c(%rip),%xmm2        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820c24:	ucomisd %xmm12,%xmm2
  820c29:	jae    8203b0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820c2f:	movapd %xmm2,%xmm3
  820c33:	movapd 0x50(%rsp),%xmm2
  820c39:	subsd  %xmm12,%xmm2
  820c3e:	ucomisd %xmm2,%xmm3
  820c42:	jae    8203b0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820c48:	movsd  0x170(%rsp),%xmm2
  820c51:	addsd  %xmm7,%xmm2
  820c55:	addsd  0xe0(%rsp),%xmm2
  820c5e:	subsd  0x40(%rsp),%xmm2
  820c64:	movsd  0x140(%rsp),%xmm5
  820c6d:	addsd  0x150(%rsp),%xmm5
  820c76:	addsd  0xf0(%rsp),%xmm5
  820c7f:	addsd  0x30(%rsp),%xmm5
  820c85:	addsd  0x20(%rsp),%xmm5
  820c8b:	addsd  -0x77141b(%rip),%xmm5        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820c93:	mulsd  -0x77149b(%rip),%xmm5        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820c9b:	addsd  (%rsp),%xmm5
  820ca0:	ucomisd %xmm2,%xmm5
  820ca4:	jae    8203b0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820caa:	movapd %xmm2,%xmm3
  820cae:	movapd 0x10(%rsp),%xmm2
  820cb4:	subsd  %xmm3,%xmm2
  820cb8:	ucomisd %xmm2,%xmm5
  820cbc:	jae    8203b0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820cc2:	movapd 0x2b0(%rsp),%xmm2
  820ccb:	addsd  %xmm8,%xmm2
  820cd0:	addsd  0xd0(%rsp),%xmm2
  820cd9:	subsd  0x40(%rsp),%xmm2
  820cdf:	addsd  %xmm14,%xmm15
  820ce4:	addsd  0xc0(%rsp),%xmm15
  820cee:	addsd  0x30(%rsp),%xmm15
  820cf5:	addsd  0x20(%rsp),%xmm15
  820cfc:	addsd  -0x77148d(%rip),%xmm15        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820d05:	mulsd  -0x770f36(%rip),%xmm15        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820d0e:	ucomisd %xmm2,%xmm15
  820d13:	jae    8203b0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820d19:	movapd %xmm2,%xmm3
  820d1d:	movapd 0x10(%rsp),%xmm2
  820d23:	subsd  %xmm3,%xmm2
  820d27:	ucomisd %xmm2,%xmm15
  820d2c:	jae    8203b0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820d32:	cmp    %rsi,%r10
  820d35:	jae    820e40 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1030>
  820d3b:	mov    0xac(%rsp),%eax
  820d42:	mov    %eax,0x0(%rbp,%r10,8)
  820d47:	movl   $0x1,0x4(%rbp,%r10,8)
  820d50:	cmp    0xb0(%rsp),%r10
  820d58:	jae    820e50 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1040>
  820d5e:	mov    0x98(%rsp),%rax
  820d66:	mov    0x168(%rsp),%rdx
  820d6e:	mov    %eax,(%rdx,%r10,4)
  820d72:	movsd  0xa0(%rsp),%xmm13
  820d7c:	cmp    %rbx,%rdi
  820d7f:	jb     8203c7 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5b7>
  820d85:	data16 cs nopw 0x0(%rax,%rax,1)
  820d90:	mov    0xb8(%rsp),%r10
  820d98:	cmp    %r10,0x1c0(%rsp)
  820da0:	mov    0x1b8(%rsp),%r9
  820da8:	jae    81ff86 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  820dae:	cmp    %r10,%r14
  820db1:	jbe    820300 <<gpui_gpu::renderer::RendererState>::bin_draw+0x4f0>
  820db7:	jmp    81ff86 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  820dbc:	mov    %r14,%rax
  820dbf:	nop
  820dc0:	cmp    %r10,%r14
  820dc3:	adc    $0x0,%rax
  820dc7:	mov    %r14,%rcx
  820dca:	imul   %r13,%rcx
  820dce:	mov    %r9,%rdx
  820dd1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  820de0:	lea    (%rdx,%rcx,1),%r10
  820de4:	cmp    %rsi,%r10
  820de7:	jae    820e23 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1013>
  820de9:	cmp    %rbx,%rdx
  820dec:	mov    %rdx,%rdi
  820def:	adc    $0x0,%rdi
  820df3:	incl   0x4(%rbp,%r10,8)
  820df8:	cmp    %rbx,%rdx
  820dfb:	jae    820e05 <<gpui_gpu::renderer::RendererState>::bin_draw+0xff5>
  820dfd:	mov    %rdi,%rdx
  820e00:	cmp    %rbx,%rdi
  820e03:	jbe    820de0 <<gpui_gpu::renderer::RendererState>::bin_draw+0xfd0>
  820e05:	mov    0xb8(%rsp),%r10
  820e0d:	cmp    %r10,%r14
  820e10:	jae    81ff86 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  820e16:	mov    %rax,%r14
  820e19:	cmp    %r10,%rax
  820e1c:	jbe    820dc0 <<gpui_gpu::renderer::RendererState>::bin_draw+0xfb0>
  820e1e:	jmp    81ff86 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  820e23:	lea    0x60ccd6(%rip),%rdx        # e2db00 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xc8>
  820e2a:	mov    %r10,%rdi
  820e2d:	call   *0x65e64d(%rip)        # e7f480 <_DYNAMIC+0x4f8>
  820e33:	lea    0x60cdce(%rip),%rdi        # e2dc08 <anon.e7af5e0dba0d7261d22cb76253955a85.29.llvm.7635581776195589086+0x10>
  820e3a:	call   *0x65e728(%rip)        # e7f568 <_DYNAMIC+0x5e0>
  820e40:	lea    0x60ccd1(%rip),%rdx        # e2db18 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xe0>
  820e47:	mov    %r10,%rdi
  820e4a:	call   *0x65e630(%rip)        # e7f480 <_DYNAMIC+0x4f8>
  820e50:	lea    0x60ccd9(%rip),%rdx        # e2db30 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xf8>
  820e57:	mov    %r10,%rdi
  820e5a:	mov    0xb0(%rsp),%rsi
  820e62:	call   *0x65e618(%rip)        # e7f480 <_DYNAMIC+0x4f8>

FUNCTION gpui_gpu::renderer::compact_group bytes=68 frame=88

/tmp/gpui-legacy-coverage-codegen/legacy277/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000820e70 <gpui_gpu::renderer::compact_group>:
  820e70:	xor    %eax,%eax
  820e72:	test   %esi,%esi
  820e74:	je     820eb3 <gpui_gpu::renderer::compact_group+0x43>
  820e76:	cmpq   $0x2,0x10(%rdi)
  820e7b:	jb     820eb3 <gpui_gpu::renderer::compact_group+0x43>
  820e7d:	sub    $0x58,%rsp
  820e81:	mov    (%rdi),%rsi
  820e84:	mov    0x8(%rdi),%rax
  820e88:	mov    (%rax),%edx
  820e8a:	mov    %rsp,%rdi
  820e8d:	call   81c260 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  820e92:	movss  0x4(%rsp),%xmm0
  820e98:	cmpb   $0x3,(%rsp)
  820e9c:	setne  %cl
  820e9f:	xorps  %xmm1,%xmm1
  820ea2:	ucomiss %xmm1,%xmm0
  820ea5:	setnp  %dl
  820ea8:	sete   %al
  820eab:	and    %dl,%al
  820ead:	or     %cl,%al
  820eaf:	add    $0x58,%rsp
  820eb3:	ret

FUNCTION gpui_gpu::renderer::validate_draw bytes=1600 frame=168

/tmp/gpui-legacy-coverage-codegen/legacy277/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000820ec0 <gpui_gpu::renderer::validate_draw>:
  820ec0:	push   %rbp
  820ec1:	push   %r15
  820ec3:	push   %r14
  820ec5:	push   %r12
  820ec7:	push   %rbx
  820ec8:	sub    $0x80,%rsp
  820ecf:	mov    %r8d,%ebp
  820ed2:	mov    %ecx,%r12d
  820ed5:	mov    %rdx,%r14
  820ed8:	mov    %rsi,%r15
  820edb:	mov    %rdi,%rbx
  820ede:	movups 0x88(%rsi),%xmm0
  820ee5:	movaps %xmm0,0x20(%rsp)
  820eea:	movaps %xmm0,0x70(%rsp)
  820eef:	lea    0x70(%rsp),%rdi
  820ef4:	call   *0x65e6fe(%rip)        # e7f5f8 <_DYNAMIC+0x670>
  820efa:	movaps 0x20(%rsp),%xmm4
  820eff:	test   %al,%al
  820f01:	je     820f57 <gpui_gpu::renderer::validate_draw+0x97>
  820f03:	movaps %xmm4,%xmm0
  820f06:	unpckhpd %xmm4,%xmm0
  820f0a:	xorps  %xmm2,%xmm2
  820f0d:	ucomiss %xmm2,%xmm0
  820f10:	jne    820f14 <gpui_gpu::renderer::validate_draw+0x54>
  820f12:	jnp    820f57 <gpui_gpu::renderer::validate_draw+0x97>
  820f14:	movaps %xmm4,%xmm1
  820f17:	shufps $0xff,%xmm4,%xmm1
  820f1b:	ucomiss %xmm2,%xmm1
  820f1e:	jne    820f22 <gpui_gpu::renderer::validate_draw+0x62>
  820f20:	jnp    820f57 <gpui_gpu::renderer::validate_draw+0x97>
  820f22:	xorps  %xmm3,%xmm3
  820f25:	ucomiss %xmm4,%xmm3
  820f28:	ja     820f57 <gpui_gpu::renderer::validate_draw+0x97>
  820f2a:	movaps %xmm4,%xmm2
  820f2d:	shufps $0x55,%xmm4,%xmm2
  820f31:	ucomiss %xmm2,%xmm3
  820f34:	ja     820f57 <gpui_gpu::renderer::validate_draw+0x97>
  820f36:	xorps  %xmm3,%xmm3
  820f39:	cvtsi2ss %r12d,%xmm3
  820f3e:	addss  %xmm4,%xmm0
  820f42:	ucomiss %xmm3,%xmm0
  820f45:	ja     820f57 <gpui_gpu::renderer::validate_draw+0x97>
  820f47:	xorps  %xmm0,%xmm0
  820f4a:	cvtsi2ss %ebp,%xmm0
  820f4e:	addss  %xmm1,%xmm2
  820f52:	ucomiss %xmm0,%xmm2
  820f55:	jbe    820f6d <gpui_gpu::renderer::validate_draw+0xad>
  820f57:	movl   $0x3,(%rbx)
  820f5d:	add    $0x80,%rsp
  820f64:	pop    %rbx
  820f65:	pop    %r12
  820f67:	pop    %r14
  820f69:	pop    %r15
  820f6b:	pop    %rbp
  820f6c:	ret
  820f6d:	movsd  0x48(%r15),%xmm9
  820f73:	movsd  0x60(%r15),%xmm1
  820f79:	movupd 0x50(%r15),%xmm2
  820f7f:	movapd %xmm2,%xmm5
  820f83:	shufpd $0x1,%xmm2,%xmm5
  820f88:	movupd 0x68(%r15),%xmm0
  820f8e:	cvtpd2ps %xmm5,%xmm8
  820f93:	movapd %xmm9,%xmm4
  820f98:	unpcklpd %xmm1,%xmm4
  820f9c:	cvtpd2ps %xmm4,%xmm7
  820fa0:	cvtpd2ps %xmm0,%xmm6
  820fa4:	movapd %xmm6,%xmm3
  820fa8:	shufps $0x55,%xmm6,%xmm3
  820fac:	movd   %xmm3,%ecx
  820fb0:	movd   %xmm6,%eax
  820fb4:	movapd %xmm7,%xmm3
  820fb8:	shufps $0x14,%xmm8,%xmm3
  820fbd:	shufps $0x78,%xmm3,%xmm3
  820fc1:	andps  -0x773848(%rip),%xmm3        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  820fc8:	and    $0x7fffffff,%eax
  820fcd:	cmp    $0x7f800000,%eax
  820fd2:	setge  %al
  820fd5:	and    $0x7fffffff,%ecx
  820fdb:	cmp    $0x7f800000,%ecx
  820fe1:	setge  %cl
  820fe4:	pcmpgtd -0x77593c(%rip),%xmm3        # ab6b0 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x70>
  820fec:	movmskps %xmm3,%edx
  820fef:	test   %edx,%edx
  820ff1:	jne    821042 <gpui_gpu::renderer::validate_draw+0x182>
  820ff3:	test   %al,%al
  820ff5:	jne    821042 <gpui_gpu::renderer::validate_draw+0x182>
  820ff7:	test   %cl,%cl
  820ff9:	jne    821042 <gpui_gpu::renderer::validate_draw+0x182>
  820ffb:	movapd %xmm9,%xmm3
  821000:	mulsd  %xmm1,%xmm3
  821004:	movapd %xmm2,%xmm10
  821009:	mulsd  %xmm5,%xmm10
  82100e:	subsd  %xmm10,%xmm3
  821013:	xorpd  %xmm10,%xmm10
  821018:	ucomisd %xmm10,%xmm3
  82101d:	jne    821021 <gpui_gpu::renderer::validate_draw+0x161>
  82101f:	jnp    821042 <gpui_gpu::renderer::validate_draw+0x182>
  821021:	movq   %xmm3,%rcx
  821026:	movabs $0x7fffffffffffffff,%rax
  821030:	and    %rax,%rcx
  821033:	movabs $0x7ff0000000000000,%rdx
  82103d:	cmp    %rdx,%rcx
  821040:	jl     821051 <gpui_gpu::renderer::validate_draw+0x191>
  821042:	movl   $0x5,(%rbx)
  821048:	mov    %r14,0x8(%rbx)
  82104c:	jmp    820f5d <gpui_gpu::renderer::validate_draw+0x9d>
  821051:	xorps  %xmm10,%xmm10
  821055:	cvtsi2sd %r12d,%xmm10
  82105a:	cvtsi2sd %ebp,%xmm12
  82105f:	movsd  %xmm9,%xmm2
  821064:	movapd -0x7762bd(%rip),%xmm13        # aadb0 <GCC_except_table0+0x88>
  82106d:	andpd  %xmm13,%xmm2
  821072:	movapd %xmm10,%xmm11
  821077:	unpcklpd %xmm12,%xmm11
  82107c:	movapd %xmm2,%xmm9
  821081:	movapd %xmm11,0x50(%rsp)
  821088:	mulpd  %xmm11,%xmm9
  82108d:	movapd %xmm9,%xmm11
  821092:	unpckhpd %xmm9,%xmm11
  821097:	addsd  %xmm9,%xmm11
  82109c:	movapd %xmm0,%xmm9
  8210a1:	andpd  %xmm13,%xmm9
  8210a6:	addsd  %xmm11,%xmm9
  8210ab:	shufpd $0x2,%xmm5,%xmm1
  8210b0:	andpd  %xmm13,%xmm1
  8210b5:	unpcklpd %xmm10,%xmm12
  8210ba:	movapd %xmm1,%xmm10
  8210bf:	movapd %xmm12,0x40(%rsp)
  8210c6:	mulpd  %xmm12,%xmm10
  8210cb:	movapd %xmm10,%xmm11
  8210d0:	unpckhpd %xmm10,%xmm11
  8210d5:	addsd  %xmm9,%xmm11
  8210da:	addsd  %xmm10,%xmm11
  8210df:	movapd %xmm0,%xmm10
  8210e4:	unpckhpd %xmm0,%xmm10
  8210e9:	andpd  %xmm13,%xmm10
  8210ee:	addsd  %xmm11,%xmm10
  8210f3:	movsd  0x38(%r15),%xmm9
  8210f9:	movsd  0x40(%r15),%xmm12
  8210ff:	andps  -0x773987(%rip),%xmm9        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  821107:	cvtps2pd %xmm9,%xmm15
  82110b:	movapd %xmm10,%xmm9
  821110:	addsd  %xmm15,%xmm9
  821115:	movapd %xmm15,0x60(%rsp)
  82111c:	unpckhpd %xmm15,%xmm15
  821121:	addsd  %xmm15,%xmm9
  821126:	cvtps2pd %xmm12,%xmm11
  82112a:	movapd %xmm11,0x20(%rsp)
  821131:	andpd  %xmm13,%xmm11
  821136:	addsd  %xmm11,%xmm9
  82113b:	pshufd $0xee,%xmm11,%xmm14
  821141:	movdqa %xmm14,0x30(%rsp)
  821148:	addsd  %xmm14,%xmm9
  82114d:	movq   %xmm9,%rsi
  821152:	and    %rax,%rsi
  821155:	movabs $0x7fefffffffffffff,%rcx
  82115f:	cmp    %rcx,%rsi
  821162:	jg     821042 <gpui_gpu::renderer::validate_draw+0x182>
  821168:	ucomisd -0x771b59(%rip),%xmm9        # af618 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  821171:	ja     821042 <gpui_gpu::renderer::validate_draw+0x182>
  821177:	movzbl (%r15),%esi
  82117b:	cmp    $0x3,%esi
  82117e:	je     821196 <gpui_gpu::renderer::validate_draw+0x2d6>
  821180:	xorpd  %xmm14,%xmm14
  821185:	cmp    $0x1,%esi
  821188:	jne    8212c2 <gpui_gpu::renderer::validate_draw+0x402>
  82118e:	movss  0x4(%r15),%xmm14
  821194:	jmp    8211ad <gpui_gpu::renderer::validate_draw+0x2ed>
  821196:	movss  0x4(%r15),%xmm14
  82119c:	xorpd  %xmm13,%xmm13
  8211a1:	ucomiss %xmm13,%xmm14
  8211a5:	jne    8211ad <gpui_gpu::renderer::validate_draw+0x2ed>
  8211a7:	jnp    8213e7 <gpui_gpu::renderer::validate_draw+0x527>
  8211ad:	movd   %xmm14,%edi
  8211b2:	test   %edi,%edi
  8211b4:	sets   %r8b
  8211b8:	and    $0x7fffffff,%edi
  8211be:	lea    -0x800000(%rdi),%r9d
  8211c5:	cmp    $0x7f000000,%r9d
  8211cc:	setb   %r9b
  8211d0:	and    %r8b,%r9b
  8211d3:	lea    -0x1(%rdi),%r10d
  8211d7:	cmp    $0x7fffff,%r10d
  8211de:	setb   %r10b
  8211e2:	and    %r8b,%r10b
  8211e5:	cmp    $0x7f800000,%edi
  8211eb:	sete   %dil
  8211ef:	setg   %r8b
  8211f3:	or     %dil,%r8b
  8211f6:	or     %r10b,%r8b
  8211f9:	or     %r9b,%r8b
  8211fc:	cmp    $0x1,%r8b
  821200:	je     820f57 <gpui_gpu::renderer::validate_draw+0x97>
  821206:	movaps %xmm11,(%rsp)
  82120b:	movaps %xmm14,%xmm11
  82120f:	movaps %xmm14,0x10(%rsp)
  821215:	movaps %xmm12,%xmm14
  821219:	mulss  -0x7722b6(%rip),%xmm14        # aef6c <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  821222:	minss  %xmm14,%xmm11
  821227:	movaps %xmm11,%xmm14
  82122b:	cmpunordss %xmm11,%xmm14
  821231:	movaps %xmm14,%xmm13
  821235:	andnps %xmm11,%xmm13
  821239:	andps  0x10(%rsp),%xmm14
  82123f:	orps   %xmm13,%xmm14
  821243:	shufps $0x55,%xmm12,%xmm12
  821248:	mulss  -0x7722e5(%rip),%xmm12        # aef6c <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  821251:	movaps %xmm14,%xmm11
  821255:	minss  %xmm12,%xmm11
  82125a:	movaps %xmm11,%xmm12
  82125e:	cmpunordss %xmm11,%xmm12
  821264:	andps  %xmm12,%xmm14
  821268:	andnps %xmm11,%xmm12
  82126c:	orps   %xmm14,%xmm12
  821270:	movss  -0x772029(%rip),%xmm11        # af250 <anon.4109cdd7ddb1990ee57d5626700ecb68.286.llvm.4479275319843201559+0xc>
  821279:	ucomiss %xmm12,%xmm11
  82127d:	ja     821042 <gpui_gpu::renderer::validate_draw+0x182>
  821283:	xorps  %xmm14,%xmm14
  821287:	cvtss2sd %xmm12,%xmm14
  82128c:	movapd %xmm9,%xmm11
  821291:	divsd  %xmm14,%xmm11
  821296:	ucomisd -0x771a1f(%rip),%xmm11        # af880 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x10>
  82129f:	ja     821042 <gpui_gpu::renderer::validate_draw+0x182>
  8212a5:	addsd  %xmm9,%xmm14
  8212aa:	mulsd  -0x771b8b(%rip),%xmm14        # af728 <anon.4109cdd7ddb1990ee57d5626700ecb68.92.llvm.4479275319843201559+0x10>
  8212b3:	movapd (%rsp),%xmm11
  8212b9:	movapd -0x776512(%rip),%xmm13        # aadb0 <GCC_except_table0+0x88>
  8212c2:	cmp    $0x2,%esi
  8212c5:	movaps %xmm11,(%rsp)
  8212ca:	jae    8213db <gpui_gpu::renderer::validate_draw+0x51b>
  8212d0:	cvtps2pd %xmm8,%xmm8
  8212d4:	subpd  %xmm8,%xmm5
  8212d9:	cvtps2pd %xmm7,%xmm7
  8212dc:	andpd  %xmm13,%xmm5
  8212e1:	mulpd  0x40(%rsp),%xmm5
  8212e7:	subpd  %xmm7,%xmm4
  8212eb:	andpd  %xmm13,%xmm4
  8212f0:	mulpd  0x50(%rsp),%xmm4
  8212f6:	addpd  %xmm5,%xmm4
  8212fa:	cvtps2pd %xmm6,%xmm5
  8212fd:	subpd  %xmm5,%xmm0
  821301:	addsd  -0x771a92(%rip),%xmm10        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  82130a:	mulsd  -0x7718cb(%rip),%xmm10        # afa48 <anon.4109cdd7ddb1990ee57d5626700ecb68.350.llvm.4479275319843201559+0x18>
  821313:	andpd  %xmm13,%xmm0
  821318:	addpd  %xmm4,%xmm0
  82131c:	movapd 0x60(%rsp),%xmm7
  821322:	addsd  %xmm7,%xmm15
  821327:	movapd (%rsp),%xmm6
  82132c:	addsd  %xmm6,%xmm15
  821331:	addsd  0x30(%rsp),%xmm15
  821338:	movapd %xmm0,%xmm4
  82133c:	unpckhpd %xmm0,%xmm4
  821340:	addpd  %xmm0,%xmm4
  821344:	movapd %xmm1,%xmm5
  821348:	shufpd $0x1,%xmm4,%xmm5
  82134d:	movapd %xmm2,%xmm4
  821351:	unpcklpd %xmm10,%xmm4
  821356:	addpd  %xmm4,%xmm5
  82135a:	mulsd  -0x771d0b(%rip),%xmm15        # af658 <anon.a16d5d421a76dfd8c37a17b53540311d.77.llvm.14190004212411149437+0x10>
  821363:	shufpd $0x1,%xmm15,%xmm2
  821369:	addpd  %xmm5,%xmm2
  82136d:	unpcklpd %xmm14,%xmm1
  821372:	addpd  %xmm2,%xmm1
  821376:	movapd %xmm1,%xmm2
  82137a:	unpckhpd %xmm1,%xmm2
  82137e:	mulsd  %xmm1,%xmm2
  821382:	andpd  -0x7765da(%rip),%xmm3        # aadb0 <GCC_except_table0+0x88>
  82138a:	divsd  %xmm3,%xmm2
  82138e:	movq   %xmm2,%rdx
  821393:	and    %rax,%rdx
  821396:	cmp    %rcx,%rdx
  821399:	jg     821042 <gpui_gpu::renderer::validate_draw+0x182>
  82139f:	ucomisd -0x7714ff(%rip),%xmm2        # afea8 <anon.a16d5d421a76dfd8c37a17b53540311d.26.llvm.14190004212411149437+0x10>
  8213a7:	ja     821042 <gpui_gpu::renderer::validate_draw+0x182>
  8213ad:	unpcklpd %xmm10,%xmm10
  8213b2:	addpd  %xmm10,%xmm0
  8213b7:	addpd  %xmm7,%xmm6
  8213bb:	mulpd  -0x776433(%rip),%xmm6        # aaf90 <anon.068260129a360d3c14a88deb110120c9.101.llvm.7357624670875813013+0x1d0>
  8213c3:	addpd  %xmm0,%xmm6
  8213c7:	cvtpd2ps %xmm6,%xmm0
  8213cb:	movlpd %xmm0,0x4(%rbx)
  8213d0:	movl   $0xffffffff,(%rbx)
  8213d6:	jmp    820f5d <gpui_gpu::renderer::validate_draw+0x9d>
  8213db:	jne    8213f0 <gpui_gpu::renderer::validate_draw+0x530>
  8213dd:	mov    0x28(%r15),%rsi
  8213e1:	mov    0x30(%r15),%rdi
  8213e5:	jmp    8213f8 <gpui_gpu::renderer::validate_draw+0x538>
  8213e7:	movaps %xmm11,(%rsp)
  8213ec:	xorps  %xmm14,%xmm14
  8213f0:	mov    0x28(%r15),%esi
  8213f4:	mov    0x2c(%r15),%edi
  8213f8:	movq   %rsi,%xmm11
  8213fd:	punpckldq -0x775b36(%rip),%xmm11        # ab8d0 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x290>
  821406:	subpd  -0x77666f(%rip),%xmm11        # aada0 <GCC_except_table0+0x78>
  82140f:	movapd %xmm11,%xmm12
  821414:	unpckhpd %xmm11,%xmm12
  821419:	addsd  %xmm11,%xmm12
  82141e:	movapd 0x20(%rsp),%xmm11
  821425:	divsd  %xmm11,%xmm12
  82142a:	movq   %xmm12,%r8
  82142f:	and    %rax,%r8
  821432:	cmp    %rdx,%r8
  821435:	jge    821042 <gpui_gpu::renderer::validate_draw+0x182>
  82143b:	movaps %xmm14,0x10(%rsp)
  821441:	movapd %xmm11,%xmm14
  821446:	movq   %rdi,%xmm11
  82144b:	punpckldq -0x775b84(%rip),%xmm11        # ab8d0 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x290>
  821454:	subpd  -0x7766bd(%rip),%xmm11        # aada0 <GCC_except_table0+0x78>
  82145d:	movapd %xmm11,%xmm13
  821462:	unpckhpd %xmm11,%xmm13
  821467:	addsd  %xmm11,%xmm13
  82146c:	unpckhpd %xmm14,%xmm14
  821471:	divsd  %xmm14,%xmm13
  821476:	movapd 0x10(%rsp),%xmm14
  82147d:	movq   %xmm13,%rdx
  821482:	and    %rax,%rdx
  821485:	cmp    %rcx,%rdx
  821488:	setg   %dl
  82148b:	ucomisd -0x771e7c(%rip),%xmm13        # af618 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  821494:	movapd -0x7766ed(%rip),%xmm13        # aadb0 <GCC_except_table0+0x88>
  82149d:	ja     821042 <gpui_gpu::renderer::validate_draw+0x182>
  8214a3:	ucomisd -0x771e94(%rip),%xmm12        # af618 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  8214ac:	ja     821042 <gpui_gpu::renderer::validate_draw+0x182>
  8214b2:	test   %dl,%dl
  8214b4:	jne    821042 <gpui_gpu::renderer::validate_draw+0x182>
  8214ba:	cmp    %rsi,%rdi
  8214bd:	cmova  %rdi,%rsi
  8214c1:	movq   %rsi,%xmm11
  8214c6:	punpckldq -0x775bff(%rip),%xmm11        # ab8d0 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x290>
  8214cf:	subpd  -0x776738(%rip),%xmm11        # aada0 <GCC_except_table0+0x78>
  8214d8:	movapd %xmm11,%xmm12
  8214dd:	unpckhpd %xmm11,%xmm12
  8214e2:	addsd  %xmm11,%xmm12
  8214e7:	mulsd  %xmm12,%xmm9
  8214ec:	ucomisd -0x771edd(%rip),%xmm9        # af618 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  8214f5:	ja     821042 <gpui_gpu::renderer::validate_draw+0x182>
  8214fb:	jmp    8212d0 <gpui_gpu::renderer::validate_draw+0x410>

FUNCTION core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>> bytes=105 frame=8

/tmp/gpui-legacy-coverage-codegen/legacy277/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000821bf0 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>:
  821bf0:	push   %rbx
  821bf1:	test   %rdi,%rdi
  821bf4:	je     821c57 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x67>
  821bf6:	mov    %rdi,%rbx
  821bf9:	mov    (%rdi),%rsi
  821bfc:	test   %rsi,%rsi
  821bff:	je     821c14 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x24>
  821c01:	mov    0x8(%rbx),%rdi
  821c05:	shl    $0x3,%rsi
  821c09:	mov    $0x8,%edx
  821c0e:	call   *0x65d5bc(%rip)        # e7f1d0 <_DYNAMIC+0x248>
  821c14:	mov    0x20(%rbx),%rsi
  821c18:	test   %rsi,%rsi
  821c1b:	je     821c43 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  821c1d:	mov    %rsi,%rax
  821c20:	shl    $0x4,%rax
  821c24:	add    %rax,%rsi
  821c27:	add    $0x21,%rsi
  821c2b:	je     821c43 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  821c2d:	mov    0x18(%rbx),%rdi
  821c31:	sub    %rax,%rdi
  821c34:	add    $0xfffffffffffffff0,%rdi
  821c38:	mov    $0x10,%edx
  821c3d:	call   *0x65d58d(%rip)        # e7f1d0 <_DYNAMIC+0x248>
  821c43:	mov    $0x80,%esi
  821c48:	mov    $0x8,%edx
  821c4d:	mov    %rbx,%rdi
  821c50:	pop    %rbx
  821c51:	jmp    *0x65d579(%rip)        # e7f1d0 <_DYNAMIC+0x248>
  821c57:	pop    %rbx
  821c58:	ret

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Buffer> bytes=103 frame=24

/tmp/gpui-legacy-coverage-codegen/legacy277/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000821e80 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>:
  821e80:	push   %r14
  821e82:	push   %rbx
  821e83:	push   %rax
  821e84:	mov    %rdi,%rbx
  821e87:	mov    (%rdi),%rax
  821e8a:	lock decq (%rax)
  821e8e:	jne    821e99 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x19>
  821e90:	mov    %rbx,%rdi
  821e93:	call   *0x65d5f7(%rip)        # e7f490 <_DYNAMIC+0x508>
  821e99:	mov    0x8(%rbx),%rax
  821e9d:	lock decq (%rax)
  821ea1:	jne    821eb7 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x37>
  821ea3:	add    $0x8,%rbx
  821ea7:	mov    %rbx,%rdi
  821eaa:	add    $0x8,%rsp
  821eae:	pop    %rbx
  821eaf:	pop    %r14
  821eb1:	jmp    *0x65d5e1(%rip)        # e7f498 <_DYNAMIC+0x510>
  821eb7:	add    $0x8,%rsp
  821ebb:	pop    %rbx
  821ebc:	pop    %r14
  821ebe:	ret
  821ebf:	mov    %rax,%r14
  821ec2:	mov    0x8(%rbx),%rax
  821ec6:	lock decq (%rax)
  821eca:	jne    821ed9 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x59>
  821ecc:	add    $0x8,%rbx
  821ed0:	mov    %rbx,%rdi
  821ed3:	call   *0x65d5bf(%rip)        # e7f498 <_DYNAMIC+0x510>
  821ed9:	mov    %r14,%rdi
  821edc:	call   e2bd40 <_Unwind_Resume@plt>
  821ee1:	call   *0x65d2f1(%rip)        # e7f1d8 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::images::Images> bytes=81 frame=8

/tmp/gpui-legacy-coverage-codegen/legacy277/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000821fb0 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>:
  821fb0:	push   %rbx
  821fb1:	mov    %rdi,%rbx
  821fb4:	mov    (%rdi),%rsi
  821fb7:	test   %rsi,%rsi
  821fba:	je     821fcf <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>+0x1f>
  821fbc:	mov    0x8(%rbx),%rdi
  821fc0:	shl    $0x3,%rsi
  821fc4:	mov    $0x8,%edx
  821fc9:	call   *0x65d201(%rip)        # e7f1d0 <_DYNAMIC+0x248>
  821fcf:	mov    0x20(%rbx),%rsi
  821fd3:	test   %rsi,%rsi
  821fd6:	je     821fff <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>+0x4f>
  821fd8:	mov    %rsi,%rax
  821fdb:	shl    $0x4,%rax
  821fdf:	add    %rax,%rsi
  821fe2:	add    $0x21,%rsi
  821fe6:	je     821fff <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>+0x4f>
  821fe8:	mov    0x18(%rbx),%rdi
  821fec:	sub    %rax,%rdi
  821fef:	add    $0xfffffffffffffff0,%rdi
  821ff3:	mov    $0x10,%edx
  821ff8:	pop    %rbx
  821ff9:	jmp    *0x65d1d1(%rip)        # e7f1d0 <_DYNAMIC+0x248>
  821fff:	pop    %rbx
  822000:	ret

FUNCTION <gpui_gpu::renderer::images::Images>::metadata bytes=246 frame=40

/tmp/gpui-legacy-coverage-codegen/legacy277/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000822010 <<gpui_gpu::renderer::images::Images>::metadata>:
  822010:	push   %r15
  822012:	push   %r14
  822014:	push   %rbx
  822015:	sub    $0x10,%rsp
  822019:	mov    %rsi,0x8(%rsp)
  82201e:	cmpq   $0x0,0x30(%rdi)
  822023:	je     8220ed <<gpui_gpu::renderer::images::Images>::metadata+0xdd>
  822029:	mov    %edx,%ebx
  82202b:	mov    %rsi,%r14
  82202e:	mov    %rdi,%r15
  822031:	add    $0x38,%rdi
  822035:	lea    0x8(%rsp),%rsi
  82203a:	call   8218b0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  82203f:	mov    %rax,%rsi
  822042:	shr    $0x39,%rsi
  822046:	mov    0x18(%r15),%rcx
  82204a:	mov    0x20(%r15),%rdx
  82204e:	movd   %esi,%xmm0
  822052:	punpcklbw %xmm0,%xmm0
  822056:	pshuflw $0x0,%xmm0,%xmm0
  82205b:	pshufd $0x44,%xmm0,%xmm0
  822060:	xor    %esi,%esi
  822062:	pcmpeqd %xmm1,%xmm1
  822066:	and    %rdx,%rax
  822069:	movdqu (%rcx,%rax,1),%xmm2
  82206e:	movdqa %xmm2,%xmm3
  822072:	pcmpeqb %xmm0,%xmm3
  822076:	pmovmskb %xmm3,%edi
  82207a:	test   %edi,%edi
  82207c:	je     8220b0 <<gpui_gpu::renderer::images::Images>::metadata+0xa0>
  82207e:	tzcnt  %edi,%r9d
  822083:	add    %rax,%r9
  822086:	and    %rdx,%r9
  822089:	shl    $0x4,%r9
  82208d:	mov    %rcx,%r8
  822090:	sub    %r9,%r8
  822093:	cmp    -0x10(%r8),%r14
  822097:	je     8220c9 <<gpui_gpu::renderer::images::Images>::metadata+0xb9>
  822099:	lea    -0x1(%rdi),%r8d
  82209d:	and    %di,%r8w
  8220a1:	mov    %r8d,%edi
  8220a4:	jne    82207e <<gpui_gpu::renderer::images::Images>::metadata+0x6e>
  8220a6:	cs nopw 0x0(%rax,%rax,1)
  8220b0:	pcmpeqb %xmm1,%xmm2
  8220b4:	pmovmskb %xmm2,%edi
  8220b8:	test   %edi,%edi
  8220ba:	jne    8220ed <<gpui_gpu::renderer::images::Images>::metadata+0xdd>
  8220bc:	add    %rsi,%rax
  8220bf:	add    $0x10,%rax
  8220c3:	add    $0x10,%rsi
  8220c7:	jmp    822066 <<gpui_gpu::renderer::images::Images>::metadata+0x56>
  8220c9:	mov    -0x8(%r8),%eax
  8220cd:	movzbl %bl,%ecx
  8220d0:	or     -0x4(%r8),%ecx
  8220d4:	shl    $0x20,%rcx
  8220d8:	or     %rax,%rcx
  8220db:	mov    $0x80000000,%eax
  8220e0:	or     %rcx,%rax
  8220e3:	add    $0x10,%rsp
  8220e7:	pop    %rbx
  8220e8:	pop    %r14
  8220ea:	pop    %r15
  8220ec:	ret
  8220ed:	lea    -0x74d878(%rip),%rdi        # d487c <anon.0e6fcc70e21e3189c77400f0a226742f.0.llvm.548032719764101456>
  8220f4:	lea    0x60bb25(%rip),%rdx        # e2dc20 <anon.0e6fcc70e21e3189c77400f0a226742f.2.llvm.548032719764101456>
  8220fb:	mov    $0x16,%esi
  822100:	call   *0x65d422(%rip)        # e7f528 <_DYNAMIC+0x5a0>

FUNCTION gpui_gpu::renderer::images::prepare bytes=2648 frame=536

/tmp/gpui-legacy-coverage-codegen/legacy277/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000822380 <gpui_gpu::renderer::images::prepare>:
  822380:	push   %rbp
  822381:	push   %r15
  822383:	push   %r14
  822385:	push   %r13
  822387:	push   %r12
  822389:	push   %rbx
  82238a:	sub    $0x1e8,%rsp
  822391:	mov    %r9,%r12
  822394:	mov    %rcx,%r13
  822397:	mov    %rdx,0xb0(%rsp)
  82239f:	mov    %rsi,(%rsp)
  8223a3:	mov    %rdi,%r15
  8223a6:	mov    0x220(%rsp),%rax
  8223ae:	mov    0x10(%rax),%r14
  8223b2:	mov    0x118(%r14),%rax
  8223b9:	add    $0x118,%r14
  8223c0:	test   %rax,%rax
  8223c3:	mov    %r14,%rcx
  8223c6:	cmove  %rax,%rcx
  8223ca:	je     82245c <gpui_gpu::renderer::images::prepare+0xdc>
  8223d0:	mov    0x10(%rax),%rax
  8223d4:	mov    (%r8),%rbp
  8223d7:	mov    %rax,0x10(%rsp)
  8223dc:	test   %rax,%rax
  8223df:	je     82245f <gpui_gpu::renderer::images::prepare+0xdf>
  8223e1:	mov    %rcx,0xa0(%rsp)
  8223e9:	test   %rbp,%rbp
  8223ec:	je     8225a8 <gpui_gpu::renderer::images::prepare+0x228>
  8223f2:	cmp    0x48(%rbp),%r12
  8223f6:	ja     8225a8 <gpui_gpu::renderer::images::prepare+0x228>
  8223fc:	mov    0x8(%rbp),%rdi
  822400:	mov    0x10(%rbp),%rax
  822404:	lea    (%rdi,%rax,8),%rsi
  822408:	movq   $0x1,0xd0(%rsp)
  822414:	mov    %r14,0xd8(%rsp)
  82241c:	movq   $0x0,0xe0(%rsp)
  822428:	movq   $0x0,0xf0(%rsp)
  822434:	lea    0xd0(%rsp),%rdx
  82243c:	mov    %r8,%rbx
  82243f:	call   8252c0 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>>
  822444:	mov    %rbx,%r8
  822447:	test   %al,%al
  822449:	je     8225a8 <gpui_gpu::renderer::images::prepare+0x228>
  82244f:	movq   $0x0,0x60(%rbp)
  822457:	jmp    82258c <gpui_gpu::renderer::images::prepare+0x20c>
  82245c:	mov    (%r8),%rbp
  82245f:	movq   $0x0,(%r8)
  822466:	test   %rbp,%rbp
  822469:	je     82258c <gpui_gpu::renderer::images::prepare+0x20c>
  82246f:	mov    0x0(%rbp),%rsi
  822473:	test   %rsi,%rsi
  822476:	je     82248b <gpui_gpu::renderer::images::prepare+0x10b>
  822478:	mov    0x8(%rbp),%rdi
  82247c:	shl    $0x3,%rsi
  822480:	mov    $0x8,%edx
  822485:	call   *0x65cd45(%rip)        # e7f1d0 <_DYNAMIC+0x248>
  82248b:	mov    0x20(%rbp),%rsi
  82248f:	test   %rsi,%rsi
  822492:	je     8224ba <gpui_gpu::renderer::images::prepare+0x13a>
  822494:	mov    %rsi,%rax
  822497:	shl    $0x4,%rax
  82249b:	add    %rax,%rsi
  82249e:	add    $0x21,%rsi
  8224a2:	je     8224ba <gpui_gpu::renderer::images::prepare+0x13a>
  8224a4:	mov    0x18(%rbp),%rdi
  8224a8:	sub    %rax,%rdi
  8224ab:	add    $0xfffffffffffffff0,%rdi
  8224af:	mov    $0x10,%edx
  8224b4:	call   *0x65cd16(%rip)        # e7f1d0 <_DYNAMIC+0x248>
  8224ba:	mov    $0x80,%esi
  8224bf:	mov    $0x8,%edx
  8224c4:	mov    %rbp,%rdi
  8224c7:	call   *0x65cd03(%rip)        # e7f1d0 <_DYNAMIC+0x248>
  8224cd:	shl    $0x4,%r12
  8224d1:	cmp    $0x101,%r12
  8224d8:	mov    $0x100,%eax
  8224dd:	cmovae %r12,%rax
  8224e1:	dec    %rax
  8224e4:	bsr    %rax,%rcx
  8224e8:	not    %ecx
  8224ea:	mov    $0xffffffffffffffff,%rbx
  8224f1:	shr    %cl,%rbx
  8224f4:	inc    %rbx
  8224f7:	lea    -0x74dc6c(%rip),%rax        # d4892 <anon.0e6fcc70e21e3189c77400f0a226742f.0.llvm.548032719764101456+0x16>
  8224fe:	mov    %rax,0x18(%rsp)
  822503:	movq   $0xa,0x20(%rsp)
  82250c:	mov    %rbx,0x28(%rsp)
  822511:	movl   $0x88,0x30(%rsp)
  822519:	movb   $0x0,0x34(%rsp)
  82251e:	lea    0xd0(%rsp),%rdi
  822526:	lea    0x18(%rsp),%rdx
  82252b:	mov    (%rsp),%rsi
  82252f:	call   *0x65d073(%rip)        # e7f5a8 <_DYNAMIC+0x620>
  822535:	mov    %rbx,0xf0(%rsp)
  82253d:	mov    0x0(%r13),%rax
  822541:	lock decq (%rax)
  822545:	jne    822550 <gpui_gpu::renderer::images::prepare+0x1d0>
  822547:	mov    %r13,%rdi
  82254a:	call   *0x65cf40(%rip)        # e7f490 <_DYNAMIC+0x508>
  822550:	mov    0x8(%r13),%rax
  822554:	lock decq (%rax)
  822558:	jne    822564 <gpui_gpu::renderer::images::prepare+0x1e4>
  82255a:	lea    0x8(%r13),%rdi
  82255e:	call   *0x65cf34(%rip)        # e7f498 <_DYNAMIC+0x510>
  822564:	mov    0xf0(%rsp),%rax
  82256c:	mov    %rax,0x20(%r13)
  822570:	movdqu 0xd0(%rsp),%xmm0
  822579:	movups 0xe0(%rsp),%xmm1
  822581:	movups %xmm1,0x10(%r13)
  822586:	movdqu %xmm0,0x0(%r13)
  82258c:	movl   $0xffffffff,(%r15)
  822593:	mov    %r15,%rax
  822596:	add    $0x1e8,%rsp
  82259d:	pop    %rbx
  82259e:	pop    %r12
  8225a0:	pop    %r13
  8225a2:	pop    %r14
  8225a4:	pop    %r15
  8225a6:	pop    %rbp
  8225a7:	ret
  8225a8:	cmp    $0x1,%r12
  8225ac:	mov    %r12,%rax
  8225af:	adc    $0xffffffffffffffff,%rax
  8225b3:	bsr    %rax,%rcx
  8225b7:	not    %ecx
  8225b9:	mov    $0xffffffffffffffff,%rax
  8225c0:	shr    %cl,%rax
  8225c3:	cmp    $0x2,%r12
  8225c7:	mov    $0x0,%r12d
  8225cd:	cmovae %rax,%r12
  8225d1:	inc    %r12
  8225d4:	je     822cc8 <gpui_gpu::renderer::images::prepare+0x948>
  8225da:	mov    %r8,0xc8(%rsp)
  8225e2:	mov    %fs:0x0,%rax
  8225eb:	lea    -0x28(%rax),%rax
  8225f2:	mov    %rax,%rcx
  8225f5:	cmpb   $0x1,0x10(%rax)
  8225f9:	mov    %r15,0xa8(%rsp)
  822601:	mov    %r13,0x8(%rsp)
  822606:	jne    822cd4 <gpui_gpu::renderer::images::prepare+0x954>
  82260c:	mov    (%rcx),%rax
  82260f:	mov    0x8(%rcx),%rdx
  822613:	mov    0x10(%rsp),%rbx
  822618:	lea    0x1(%rax),%rsi
  82261c:	mov    %rsi,(%rcx)
  82261f:	movq   $0x0,0x18(%rsp)
  822628:	movq   $0x8,0x20(%rsp)
  822631:	movq   $0x0,0x28(%rsp)
  82263a:	movups 0x60b5f7(%rip),%xmm0        # e2dc38 <anon.0e6fcc70e21e3189c77400f0a226742f.2.llvm.548032719764101456+0x18>
  822641:	movups %xmm0,0x30(%rsp)
  822646:	movdqu 0x60b5fa(%rip),%xmm0        # e2dc48 <anon.0e6fcc70e21e3189c77400f0a226742f.2.llvm.548032719764101456+0x28>
  82264e:	movdqu %xmm0,0x40(%rsp)
  822654:	mov    %rax,0x50(%rsp)
  822659:	mov    %rdx,0x58(%rsp)
  82265e:	mov    %r12,0x60(%rsp)
  822663:	pxor   %xmm0,%xmm0
  822667:	movdqu %xmm0,0x68(%rsp)
  82266d:	movdqu %xmm0,0x78(%rsp)
  822673:	movdqu %xmm0,0x88(%rsp)
  82267c:	lea    0xd0(%rsp),%rdi
  822684:	mov    $0x8,%edx
  822689:	mov    $0x8,%r8d
  82268f:	mov    $0x8,%r9d
  822695:	xor    %esi,%esi
  822697:	mov    %rbx,%rcx
  82269a:	call   8236b0 <<alloc::raw_vec::RawVecInner>::finish_grow>
  82269f:	cmpl   $0x1,0xd0(%rsp)
  8226a7:	jne    822714 <gpui_gpu::renderer::images::prepare+0x394>
  8226a9:	mov    0xa8(%rsp),%r15
  8226b1:	movl   $0x6,(%r15)
  8226b8:	mov    0x18(%rsp),%rsi
  8226bd:	test   %rsi,%rsi
  8226c0:	je     8226d6 <gpui_gpu::renderer::images::prepare+0x356>
  8226c2:	mov    0x20(%rsp),%rdi
  8226c7:	shl    $0x3,%rsi
  8226cb:	mov    $0x8,%edx
  8226d0:	call   *0x65cafa(%rip)        # e7f1d0 <_DYNAMIC+0x248>
  8226d6:	mov    0x38(%rsp),%rsi
  8226db:	test   %rsi,%rsi
  8226de:	je     822593 <gpui_gpu::renderer::images::prepare+0x213>
  8226e4:	mov    %rsi,%rax
  8226e7:	shl    $0x4,%rax
  8226eb:	add    %rax,%rsi
  8226ee:	add    $0x21,%rsi
  8226f2:	je     822593 <gpui_gpu::renderer::images::prepare+0x213>
  8226f8:	mov    0x30(%rsp),%rdi
  8226fd:	sub    %rax,%rdi
  822700:	add    $0xfffffffffffffff0,%rdi
  822704:	mov    $0x10,%edx
  822709:	call   *0x65cac1(%rip)        # e7f1d0 <_DYNAMIC+0x248>
  82270f:	jmp    822593 <gpui_gpu::renderer::images::prepare+0x213>
  822714:	mov    %r12,0x98(%rsp)
  82271c:	mov    %rbp,0xc0(%rsp)
  822724:	mov    0xd8(%rsp),%rax
  82272c:	mov    %rax,0x20(%rsp)
  822731:	mov    %rbx,0x18(%rsp)
  822736:	cmp    0x40(%rsp),%rbx
  82273b:	ja     822cf0 <gpui_gpu::renderer::images::prepare+0x970>
  822741:	xor    %r12d,%r12d
  822744:	mov    0x98(%rsp),%r15
  82274c:	jmp    822768 <gpui_gpu::renderer::images::prepare+0x3e8>
  82274e:	xchg   %ax,%ax
  822750:	add    $0x8,%r12
  822754:	mov    0x20(%rsp),%rax
  822759:	mov    %rbx,(%rax,%r15,8)
  82275d:	inc    %r15
  822760:	mov    %r15,0x28(%rsp)
  822765:	mov    %r13,%r15
  822768:	test   %r12,%r12
  82276b:	je     822790 <gpui_gpu::renderer::images::prepare+0x410>
  82276d:	cmp    %rbp,%r12
  822770:	je     822790 <gpui_gpu::renderer::images::prepare+0x410>
  822772:	mov    (%r12),%rcx
  822776:	cmpb   $0x0,0x10(%rcx)
  82277a:	je     8227be <gpui_gpu::renderer::images::prepare+0x43e>
  82277c:	mov    0x20(%rcx),%rax
  822780:	shl    $0x4,%rax
  822784:	mov    $0x8,%r8d
  82278a:	jmp    8227d1 <gpui_gpu::renderer::images::prepare+0x451>
  82278c:	nopl   0x0(%rax)
  822790:	test   %r14,%r14
  822793:	je     822858 <gpui_gpu::renderer::images::prepare+0x4d8>
  822799:	mov    (%r14),%rax
  82279c:	mov    0x10(%rax),%rcx
  8227a0:	test   %rcx,%rcx
  8227a3:	je     822858 <gpui_gpu::renderer::images::prepare+0x4d8>
  8227a9:	mov    0x8(%rax),%r12
  8227ad:	lea    (%r12,%rcx,8),%rbp
  8227b1:	xor    %r14d,%r14d
  8227b4:	mov    (%r12),%rcx
  8227b8:	cmpb   $0x0,0x10(%rcx)
  8227bc:	jne    82277c <gpui_gpu::renderer::images::prepare+0x3fc>
  8227be:	movzbl 0x11(%rcx),%edx
  8227c2:	movzbl 0x12(%rcx),%esi
  8227c6:	mov    0x20(%rcx),%rax
  8227ca:	shl    $0x2,%edx
  8227cd:	lea    (%rdx,%rsi,2),%r8d
  8227d1:	mov    0x70(%rsp),%rdx
  8227d6:	add    %rax,%rdx
  8227d9:	jb     8226a9 <gpui_gpu::renderer::images::prepare+0x329>
  8227df:	mov    0x28(%rcx),%rbx
  8227e3:	mov    %rdx,0x70(%rsp)
  8227e8:	cmp    $0x4000000,%rdx
  8227ef:	ja     8226a9 <gpui_gpu::renderer::images::prepare+0x329>
  8227f5:	mov    %r15,%rcx
  8227f8:	shr    $0x20,%rcx
  8227fc:	jne    8226a9 <gpui_gpu::renderer::images::prepare+0x329>
  822802:	test   %r15d,%r15d
  822805:	js     8226a9 <gpui_gpu::renderer::images::prepare+0x329>
  82280b:	mov    %rax,%r13
  82280e:	shr    $0x4,%r13
  822812:	and    $0xf,%eax
  822815:	add    %r15,%r13
  822818:	cmp    $0x1,%rax
  82281c:	sbb    $0xffffffffffffffff,%r13
  822820:	lea    0xd0(%rsp),%rdi
  822828:	lea    0x30(%rsp),%rsi
  82282d:	mov    %rbx,%rdx
  822830:	mov    %r15d,%ecx
  822833:	call   823130 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert>
  822838:	mov    0x28(%rsp),%r15
  82283d:	cmp    0x18(%rsp),%r15
  822842:	jne    822750 <gpui_gpu::renderer::images::prepare+0x3d0>
  822848:	lea    0x18(%rsp),%rdi
  82284d:	call   *0x65cdcd(%rip)        # e7f620 <_DYNAMIC+0x698>
  822853:	jmp    822750 <gpui_gpu::renderer::images::prepare+0x3d0>
  822858:	movabs $0xffffffffffffff0,%rax
  822862:	cmp    %rax,%r15
  822865:	ja     8226a9 <gpui_gpu::renderer::images::prepare+0x329>
  82286b:	lea    0xd0(%rsp),%rdi
  822873:	mov    (%rsp),%rsi
  822877:	call   *0x65cdab(%rip)        # e7f628 <_DYNAMIC+0x6a0>
  82287d:	mov    %r15,%rbx
  822880:	shl    $0x4,%rbx
  822884:	add    $0xff,%rbx
  82288b:	and    $0xffffffffffffff00,%rbx
  822892:	cmp    0x120(%rsp),%rbx
  82289a:	ja     8226a9 <gpui_gpu::renderer::images::prepare+0x329>
  8228a0:	lea    0xd0(%rsp),%rdi
  8228a8:	mov    (%rsp),%rsi
  8228ac:	call   *0x65cd76(%rip)        # e7f628 <_DYNAMIC+0x6a0>
  8228b2:	cmp    0x130(%rsp),%rbx
  8228ba:	ja     8226a9 <gpui_gpu::renderer::images::prepare+0x329>
  8228c0:	mov    0x8(%rsp),%rax
  8228c5:	mov    0x20(%rax),%rax
  8228c9:	cmp    %rbx,%rax
  8228cc:	jb     8228f4 <gpui_gpu::renderer::images::prepare+0x574>
  8228ce:	lea    0x0(,%rbx,4),%rcx
  8228d6:	movabs $0x3fffffffffffff1,%rdx
  8228e0:	cmp    %rdx,%r15
  8228e3:	setb   %dl
  8228e6:	cmp    %rcx,%rax
  8228e9:	seta   %al
  8228ec:	test   %al,%dl
  8228ee:	je     822982 <gpui_gpu::renderer::images::prepare+0x602>
  8228f4:	lea    -0x74e05f(%rip),%rax        # d489c <anon.0e6fcc70e21e3189c77400f0a226742f.0.llvm.548032719764101456+0x20>
  8228fb:	mov    %rax,0x1c8(%rsp)
  822903:	movq   $0x1d,0x1d0(%rsp)
  82290f:	mov    %rbx,0x1d8(%rsp)
  822917:	movl   $0x88,0x1e0(%rsp)
  822922:	movb   $0x0,0x1e4(%rsp)
  82292a:	lea    0xd0(%rsp),%rdi
  822932:	lea    0x1c8(%rsp),%rdx
  82293a:	mov    (%rsp),%rsi
  82293e:	call   *0x65cc64(%rip)        # e7f5a8 <_DYNAMIC+0x620>
  822944:	mov    %rbx,0xf0(%rsp)
  82294c:	mov    0x8(%rsp),%r14
  822951:	mov    %r14,%rdi
  822954:	call   821e80 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  822959:	mov    0xf0(%rsp),%rax
  822961:	mov    %rax,0x20(%r14)
  822965:	movdqu 0xd0(%rsp),%xmm0
  82296e:	movdqu 0xe0(%rsp),%xmm1
  822977:	movdqu %xmm1,0x10(%r14)
  82297d:	movdqu %xmm0,(%r14)
  822982:	movq   $0x0,(%rsp)
  82298a:	mov    0x65cbc7(%rip),%r14        # e7f558 <_DYNAMIC+0x5d0>
  822991:	mov    (%rsp),%rdx
  822995:	test   %rdx,%rdx
  822998:	je     8229a4 <gpui_gpu::renderer::images::prepare+0x624>
  82299a:	cmp    0xb8(%rsp),%rdx
  8229a2:	jne    8229e1 <gpui_gpu::renderer::images::prepare+0x661>
  8229a4:	mov    0xa0(%rsp),%rax
  8229ac:	test   %rax,%rax
  8229af:	je     822b64 <gpui_gpu::renderer::images::prepare+0x7e4>
  8229b5:	mov    (%rax),%rax
  8229b8:	mov    0x10(%rax),%rcx
  8229bc:	test   %rcx,%rcx
  8229bf:	je     822b64 <gpui_gpu::renderer::images::prepare+0x7e4>
  8229c5:	mov    0x8(%rax),%rdx
  8229c9:	lea    (%rdx,%rcx,8),%rax
  8229cd:	mov    %rax,0xb8(%rsp)
  8229d5:	movq   $0x0,0xa0(%rsp)
  8229e1:	mov    (%rdx),%rax
  8229e4:	mov    0x28(%rax),%r12
  8229e8:	movzbl 0x10(%rax),%ebx
  8229ec:	mov    0x18(%rax),%rbp
  8229f0:	mov    0x20(%rax),%r13
  8229f4:	mov    %r12,0xd0(%rsp)
  8229fc:	cmpq   $0x0,0x48(%rsp)
  822a02:	je     822b49 <gpui_gpu::renderer::images::prepare+0x7c9>
  822a08:	add    $0x8,%rdx
  822a0c:	mov    %rdx,(%rsp)
  822a10:	lea    0x50(%rsp),%rdi
  822a15:	lea    0xd0(%rsp),%rsi
  822a1d:	call   8218b0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  822a22:	mov    %rax,%rsi
  822a25:	shr    $0x39,%rsi
  822a29:	mov    0x30(%rsp),%rcx
  822a2e:	mov    0x38(%rsp),%rdx
  822a33:	movd   %esi,%xmm0
  822a37:	punpcklbw %xmm0,%xmm0
  822a3b:	pshuflw $0x0,%xmm0,%xmm0
  822a40:	pshufd $0x44,%xmm0,%xmm0
  822a45:	xor    %esi,%esi
  822a47:	and    %rdx,%rax
  822a4a:	movdqu (%rcx,%rax,1),%xmm1
  822a4f:	movdqa %xmm1,%xmm2
  822a53:	pcmpeqb %xmm0,%xmm2
  822a57:	pmovmskb %xmm2,%edi
  822a5b:	test   %edi,%edi
  822a5d:	je     822a87 <gpui_gpu::renderer::images::prepare+0x707>
  822a5f:	tzcnt  %edi,%r9d
  822a64:	add    %rax,%r9
  822a67:	and    %rdx,%r9
  822a6a:	shl    $0x4,%r9
  822a6e:	mov    %rcx,%r8
  822a71:	sub    %r9,%r8
  822a74:	cmp    -0x10(%r8),%r12
  822a78:	je     822aa8 <gpui_gpu::renderer::images::prepare+0x728>
  822a7a:	lea    -0x1(%rdi),%r8d
  822a7e:	and    %di,%r8w
  822a82:	mov    %r8d,%edi
  822a85:	jne    822a5f <gpui_gpu::renderer::images::prepare+0x6df>
  822a87:	pcmpeqd %xmm2,%xmm2
  822a8b:	pcmpeqb %xmm2,%xmm1
  822a8f:	pmovmskb %xmm1,%edi
  822a93:	test   %edi,%edi
  822a95:	jne    822b49 <gpui_gpu::renderer::images::prepare+0x7c9>
  822a9b:	add    %rsi,%rax
  822a9e:	add    $0x10,%rax
  822aa2:	add    $0x10,%rsi
  822aa6:	jmp    822a47 <gpui_gpu::renderer::images::prepare+0x6c7>
  822aa8:	mov    -0x8(%r8),%r12d
  822aac:	shl    $0x4,%r12
  822ab0:	test   %bl,%bl
  822ab2:	je     822b07 <gpui_gpu::renderer::images::prepare+0x787>
  822ab4:	test   %r13,%r13
  822ab7:	je     822991 <gpui_gpu::renderer::images::prepare+0x611>
  822abd:	nopl   (%rax)
  822ac0:	cmp    $0x1000,%r13
  822ac7:	mov    $0x1000,%r15d
  822acd:	cmovb  %r13,%r15
  822ad1:	mov    %r15d,%ebx
  822ad4:	shl    $0x4,%ebx
  822ad7:	mov    0xb0(%rsp),%rdi
  822adf:	mov    0x8(%rsp),%rsi
  822ae4:	mov    %r12,%rdx
  822ae7:	mov    %rbp,%rcx
  822aea:	mov    %rbx,%r8
  822aed:	call   *%r14
  822af0:	mov    %r15,%rax
  822af3:	shl    $0x4,%rax
  822af7:	add    %rax,%rbp
  822afa:	add    %rbx,%r12
  822afd:	sub    %r15,%r13
  822b00:	jne    822ac0 <gpui_gpu::renderer::images::prepare+0x740>
  822b02:	jmp    822991 <gpui_gpu::renderer::images::prepare+0x611>
  822b07:	test   %r13,%r13
  822b0a:	je     822991 <gpui_gpu::renderer::images::prepare+0x611>
  822b10:	cmp    $0x10000,%r13
  822b17:	mov    $0x10000,%ebx
  822b1c:	cmovb  %r13,%rbx
  822b20:	mov    0xb0(%rsp),%rdi
  822b28:	mov    0x8(%rsp),%rsi
  822b2d:	mov    %r12,%rdx
  822b30:	mov    %rbp,%rcx
  822b33:	mov    %rbx,%r8
  822b36:	call   *%r14
  822b39:	add    %rbx,%rbp
  822b3c:	add    %rbx,%r12
  822b3f:	sub    %rbx,%r13
  822b42:	jne    822b10 <gpui_gpu::renderer::images::prepare+0x790>
  822b44:	jmp    822991 <gpui_gpu::renderer::images::prepare+0x611>
  822b49:	lea    -0x74e2d4(%rip),%rdi        # d487c <anon.0e6fcc70e21e3189c77400f0a226742f.0.llvm.548032719764101456>
  822b50:	lea    0x60b101(%rip),%rdx        # e2dc58 <anon.0e6fcc70e21e3189c77400f0a226742f.2.llvm.548032719764101456+0x38>
  822b57:	mov    $0x16,%esi
  822b5c:	call   *0x65c9c6(%rip)        # e7f528 <_DYNAMIC+0x5a0>
  822b62:	ud2
  822b64:	mov    0x10(%rsp),%rax
  822b69:	mov    %rax,0x68(%rsp)
  822b6e:	mov    0x70(%rsp),%rax
  822b73:	mov    %rax,0x78(%rsp)
  822b78:	mov    0x98(%rsp),%rax
  822b80:	shl    $0x4,%rax
  822b84:	mov    %rax,0x80(%rsp)
  822b8c:	mov    0x8(%rsp),%rax
  822b91:	mov    0x20(%rax),%rax
  822b95:	mov    %rax,0x88(%rsp)
  822b9d:	mov    0x40(%rsp),%rax
  822ba2:	add    0x48(%rsp),%rax
  822ba7:	mov    %rax,0x90(%rsp)
  822baf:	mov    0x88(%rsp),%rax
  822bb7:	mov    %rax,0x140(%rsp)
  822bbf:	mov    0x90(%rsp),%rax
  822bc7:	mov    %rax,0x148(%rsp)
  822bcf:	mov    0x78(%rsp),%rax
  822bd4:	mov    %rax,0x130(%rsp)
  822bdc:	mov    0x80(%rsp),%rax
  822be4:	mov    %rax,0x138(%rsp)
  822bec:	movups 0x68(%rsp),%xmm0
  822bf1:	movaps %xmm0,0x120(%rsp)
  822bf9:	movups 0x58(%rsp),%xmm0
  822bfe:	movaps %xmm0,0x110(%rsp)
  822c06:	movups 0x48(%rsp),%xmm0
  822c0b:	movaps %xmm0,0x100(%rsp)
  822c13:	movups 0x18(%rsp),%xmm0
  822c18:	movups 0x28(%rsp),%xmm1
  822c1d:	movups 0x38(%rsp),%xmm2
  822c22:	movaps %xmm2,0xf0(%rsp)
  822c2a:	movaps %xmm1,0xe0(%rsp)
  822c32:	movaps %xmm0,0xd0(%rsp)
  822c3a:	call   822350 <alloc::boxed::box_new_uninit>
  822c3f:	mov    %rax,%rbx
  822c42:	movaps 0x140(%rsp),%xmm0
  822c4a:	movups %xmm0,0x70(%rax)
  822c4e:	movaps 0x130(%rsp),%xmm0
  822c56:	movups %xmm0,0x60(%rax)
  822c5a:	movaps 0x120(%rsp),%xmm0
  822c62:	movups %xmm0,0x50(%rax)
  822c66:	movaps 0x110(%rsp),%xmm0
  822c6e:	movups %xmm0,0x40(%rax)
  822c72:	movdqa 0xd0(%rsp),%xmm0
  822c7b:	movaps 0xe0(%rsp),%xmm1
  822c83:	movaps 0xf0(%rsp),%xmm2
  822c8b:	movaps 0x100(%rsp),%xmm3
  822c93:	movups %xmm3,0x30(%rax)
  822c97:	movups %xmm2,0x20(%rax)
  822c9b:	movups %xmm1,0x10(%rax)
  822c9f:	movdqu %xmm0,(%rax)
  822ca3:	mov    0xc0(%rsp),%rdi
  822cab:	call   821bf0 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>
  822cb0:	mov    0xc8(%rsp),%rax
  822cb8:	mov    %rbx,(%rax)
  822cbb:	mov    0xa8(%rsp),%r15
  822cc3:	jmp    82258c <gpui_gpu::renderer::images::prepare+0x20c>
  822cc8:	movl   $0x6,(%r15)
  822ccf:	jmp    822593 <gpui_gpu::renderer::images::prepare+0x213>
  822cd4:	mov    %rcx,%rbx
  822cd7:	call   *0x65c8d3(%rip)        # e7f5b0 <_DYNAMIC+0x628>
  822cdd:	mov    %rbx,%rcx
  822ce0:	mov    %rax,(%rbx)
  822ce3:	mov    %rdx,0x8(%rbx)
  822ce7:	movb   $0x1,0x10(%rbx)
  822ceb:	jmp    822613 <gpui_gpu::renderer::images::prepare+0x293>
  822cf0:	lea    0x30(%rsp),%rdi
  822cf5:	mov    0x10(%rsp),%rsi
  822cfa:	lea    0x50(%rsp),%rdx
  822cff:	xor    %ecx,%ecx
  822d01:	call   *0x65c929(%rip)        # e7f630 <_DYNAMIC+0x6a8>
  822d07:	cmp    $0xffffffffffffffff,%rax
  822d0b:	jne    8226a9 <gpui_gpu::renderer::images::prepare+0x329>
  822d11:	jmp    822741 <gpui_gpu::renderer::images::prepare+0x3c1>
  822d16:	mov    %rax,%rbx
  822d19:	lea    0xd0(%rsp),%rdi
  822d21:	call   821fb0 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>
  822d26:	mov    %rbx,%rdi
  822d29:	call   e2bd40 <_Unwind_Resume@plt>
  822d2e:	mov    %rax,%rbx
  822d31:	mov    0xf0(%rsp),%rax
  822d39:	mov    %rax,0x20(%r14)
  822d3d:	movups 0xd0(%rsp),%xmm0
  822d45:	movups 0xe0(%rsp),%xmm1
  822d4d:	movups %xmm1,0x10(%r14)
  822d52:	movups %xmm0,(%r14)
  822d56:	lea    0x18(%rsp),%rdi
  822d5b:	call   821fb0 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>
  822d60:	mov    %rbx,%rdi
  822d63:	call   e2bd40 <_Unwind_Resume@plt>
  822d68:	mov    %r13,%r14
  822d6b:	mov    %rax,%rbx
  822d6e:	jmp    822d8a <gpui_gpu::renderer::images::prepare+0xa0a>
  822d70:	mov    %rax,%rbx
  822d73:	mov    %r13,%r14
  822d76:	mov    0x8(%r13),%rax
  822d7a:	lock decq (%rax)
  822d7e:	jne    822d8a <gpui_gpu::renderer::images::prepare+0xa0a>
  822d80:	lea    0x8(%r14),%rdi
  822d84:	call   *0x65c70e(%rip)        # e7f498 <_DYNAMIC+0x510>
  822d8a:	mov    0xf0(%rsp),%rax
  822d92:	mov    %rax,0x20(%r14)
  822d96:	movups 0xd0(%rsp),%xmm0
  822d9e:	movups 0xe0(%rsp),%xmm1
  822da6:	movups %xmm1,0x10(%r14)
  822dab:	movups %xmm0,(%r14)
  822daf:	mov    %rbx,%rdi
  822db2:	call   e2bd40 <_Unwind_Resume@plt>
  822db7:	call   *0x65c41b(%rip)        # e7f1d8 <_DYNAMIC+0x250>
  822dbd:	jmp    822dc3 <gpui_gpu::renderer::images::prepare+0xa43>
  822dbf:	jmp    822dc3 <gpui_gpu::renderer::images::prepare+0xa43>
  822dc1:	jmp    822dc3 <gpui_gpu::renderer::images::prepare+0xa43>
  822dc3:	mov    %rax,%rbx
  822dc6:	lea    0x18(%rsp),%rdi
  822dcb:	call   821fb0 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>
  822dd0:	mov    %rbx,%rdi
  822dd3:	call   e2bd40 <_Unwind_Resume@plt>

FUNCTION <hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert bytes=489 frame=104

/tmp/gpui-legacy-coverage-codegen/legacy277/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000822f40 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert>:
  822f40:	push   %rbp
  822f41:	push   %r15
  822f43:	push   %r14
  822f45:	push   %r13
  822f47:	push   %r12
  822f49:	push   %rbx
  822f4a:	sub    $0x38,%rsp
  822f4e:	mov    %rcx,%r15
  822f51:	mov    %rdx,%r12
  822f54:	mov    %rsi,%r14
  822f57:	mov    %rdi,%rbx
  822f5a:	lea    0x20(%rsi),%r13
  822f5e:	mov    %r13,%rdi
  822f61:	mov    %rdx,%rsi
  822f64:	call   821710 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  822f69:	cmpq   $0x0,0x10(%r14)
  822f6e:	je     8230f1 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x1b1>
  822f74:	mov    (%r14),%r11
  822f77:	mov    0x8(%r14),%rsi
  822f7b:	mov    %rax,%rdx
  822f7e:	shr    $0x39,%rdx
  822f82:	movd   %edx,%xmm0
  822f86:	punpcklbw %xmm0,%xmm0
  822f8a:	pshuflw $0x0,%xmm0,%xmm0
  822f8f:	pshufd $0x44,%xmm0,%xmm0
  822f94:	mov    (%r12),%rcx
  822f98:	mov    %rcx,0x8(%rsp)
  822f9d:	movzwl 0xc(%r12),%r9d
  822fa3:	mov    0x8(%r12),%r10d
  822fa8:	xor    %r13d,%r13d
  822fab:	pcmpeqd %xmm1,%xmm1
  822faf:	xor    %r8d,%r8d
  822fb2:	and    %rsi,%rax
  822fb5:	movdqu (%r11,%rax,1),%xmm2
  822fbb:	movdqa %xmm2,%xmm3
  822fbf:	pcmpeqb %xmm0,%xmm3
  822fc3:	pmovmskb %xmm3,%ebp
  822fc7:	test   %ebp,%ebp
  822fc9:	je     823010 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xd0>
  822fcb:	mov    %r8,(%rsp)
  822fcf:	mov    %r15,%r8
  822fd2:	tzcnt  %ebp,%r15d
  822fd7:	add    %rax,%r15
  822fda:	and    %rsi,%r15
  822fdd:	shl    $0x5,%r15
  822fe1:	mov    %r11,%rcx
  822fe4:	sub    %r15,%rcx
  822fe7:	mov    0x8(%rsp),%r15
  822fec:	cmp    -0x20(%rcx),%r15
  822ff0:	jne    822fff <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xbf>
  822ff2:	cmp    -0x14(%rcx),%r9w
  822ff7:	jne    822fff <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xbf>
  822ff9:	cmp    -0x18(%rcx),%r10d
  822ffd:	je     82304f <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x10f>
  822fff:	lea    -0x1(%rbp),%ecx
  823002:	and    %bp,%cx
  823005:	mov    %ecx,%ebp
  823007:	mov    %r8,%r15
  82300a:	mov    (%rsp),%r8
  82300e:	jne    822fcf <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x8f>
  823010:	cmp    $0x1,%r13
  823014:	je     823028 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xe8>
  823016:	pmovmskb %xmm2,%ecx
  82301a:	test   %ecx,%ecx
  82301c:	je     82303c <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xfc>
  82301e:	tzcnt  %ecx,%edi
  823022:	add    %rax,%rdi
  823025:	and    %rsi,%rdi
  823028:	pcmpeqb %xmm1,%xmm2
  82302c:	pmovmskb %xmm2,%ecx
  823030:	test   %ecx,%ecx
  823032:	jne    823066 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x126>
  823034:	mov    $0x1,%r13d
  82303a:	jmp    82303f <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xff>
  82303c:	xor    %r13d,%r13d
  82303f:	add    %r8,%rax
  823042:	add    $0x10,%rax
  823046:	add    $0x10,%r8
  82304a:	jmp    822fb2 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x72>
  82304f:	movups -0x10(%rcx),%xmm0
  823053:	movups %xmm0,0x4(%rbx)
  823057:	movups (%r8),%xmm0
  82305b:	movups %xmm0,-0x10(%rcx)
  82305f:	mov    $0x1,%eax
  823064:	jmp    8230dd <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x19d>
  823066:	movzbl (%r11,%rdi,1),%eax
  82306b:	test   %al,%al
  82306d:	jns    823112 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x1d2>
  823073:	movups (%r12),%xmm0
  823078:	movaps %xmm0,0x10(%rsp)
  82307d:	movups (%r15),%xmm0
  823081:	movaps %xmm0,0x20(%rsp)
  823086:	and    $0x1,%al
  823088:	lea    -0x10(%rdi),%rcx
  82308c:	and    %rsi,%rcx
  82308f:	mov    %dl,(%r11,%rdi,1)
  823093:	mov    %dl,0x10(%r11,%rcx,1)
  823098:	movzbl %al,%eax
  82309b:	movd   %eax,%xmm0
  82309f:	shufpd $0x2,-0x777ec8(%rip),%xmm0        # ab1e0 <anon.a16d5d421a76dfd8c37a17b53540311d.51.llvm.14190004212411149437+0xe0>
  8230a8:	movdqu 0x10(%r14),%xmm1
  8230ae:	psubq  %xmm0,%xmm1
  8230b2:	movdqu %xmm1,0x10(%r14)
  8230b8:	shl    $0x5,%rdi
  8230bc:	mov    %r11,%rax
  8230bf:	sub    %rdi,%rax
  8230c2:	neg    %rdi
  8230c5:	movaps 0x10(%rsp),%xmm0
  8230ca:	movdqa 0x20(%rsp),%xmm1
  8230d0:	movups %xmm0,-0x20(%r11,%rdi,1)
  8230d6:	movdqu %xmm1,-0x10(%rax)
  8230db:	xor    %eax,%eax
  8230dd:	mov    %eax,(%rbx)
  8230df:	mov    %rbx,%rax
  8230e2:	add    $0x38,%rsp
  8230e6:	pop    %rbx
  8230e7:	pop    %r12
  8230e9:	pop    %r13
  8230eb:	pop    %r14
  8230ed:	pop    %r15
  8230ef:	pop    %rbp
  8230f0:	ret
  8230f1:	mov    $0x1,%esi
  8230f6:	mov    %r14,%rdi
  8230f9:	mov    %r13,%rdx
  8230fc:	mov    $0x1,%ecx
  823101:	mov    %rax,%r13
  823104:	call   *0x65c55e(%rip)        # e7f668 <_DYNAMIC+0x6e0>
  82310a:	mov    %r13,%rax
  82310d:	jmp    822f74 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x34>
  823112:	movdqa (%r11),%xmm0
  823117:	pmovmskb %xmm0,%eax
  82311b:	tzcnt  %eax,%edi
  82311f:	movzbl (%r11,%rdi,1),%eax
  823124:	jmp    823073 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x133>

FUNCTION <hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert bytes=428 frame=56

/tmp/gpui-legacy-coverage-codegen/legacy277/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000823130 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert>:
  823130:	push   %rbp
  823131:	push   %r15
  823133:	push   %r14
  823135:	push   %r13
  823137:	push   %r12
  823139:	push   %rbx
  82313a:	push   %rax
  82313b:	mov    %r8d,%ebp
  82313e:	mov    %ecx,%r14d
  823141:	mov    %rdx,%r15
  823144:	mov    %rsi,%r12
  823147:	mov    %rdi,%rbx
  82314a:	mov    %rdx,(%rsp)
  82314e:	lea    0x20(%rsi),%r13
  823152:	mov    %rsp,%rsi
  823155:	mov    %r13,%rdi
  823158:	call   8218b0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  82315d:	cmpq   $0x0,0x10(%r12)
  823163:	je     8232a6 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x176>
  823169:	mov    (%r12),%rcx
  82316d:	mov    0x8(%r12),%rsi
  823172:	mov    %rax,%rdx
  823175:	shr    $0x39,%rdx
  823179:	movd   %edx,%xmm0
  82317d:	punpcklbw %xmm0,%xmm0
  823181:	pshuflw $0x0,%xmm0,%xmm0
  823186:	pshufd $0x44,%xmm0,%xmm0
  82318b:	xor    %r9d,%r9d
  82318e:	pcmpeqd %xmm1,%xmm1
  823192:	xor    %r8d,%r8d
  823195:	and    %rsi,%rax
  823198:	movdqu (%rcx,%rax,1),%xmm2
  82319d:	movdqa %xmm2,%xmm3
  8231a1:	pcmpeqb %xmm0,%xmm3
  8231a5:	pmovmskb %xmm3,%r10d
  8231aa:	test   %r10d,%r10d
  8231ad:	je     8231e0 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xb0>
  8231af:	tzcnt  %r10d,%r13d
  8231b4:	add    %rax,%r13
  8231b7:	and    %rsi,%r13
  8231ba:	shl    $0x4,%r13
  8231be:	mov    %rcx,%r11
  8231c1:	sub    %r13,%r11
  8231c4:	cmp    -0x10(%r11),%r15
  8231c8:	je     823221 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xf1>
  8231ca:	lea    -0x1(%r10),%r11d
  8231ce:	and    %r10w,%r11w
  8231d2:	mov    %r11d,%r10d
  8231d5:	jne    8231af <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x7f>
  8231d7:	nopw   0x0(%rax,%rax,1)
  8231e0:	cmp    $0x1,%r9
  8231e4:	je     8231f8 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xc8>
  8231e6:	pmovmskb %xmm2,%edi
  8231ea:	test   %edi,%edi
  8231ec:	je     82320e <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xde>
  8231ee:	tzcnt  %edi,%edi
  8231f2:	add    %rax,%rdi
  8231f5:	and    %rsi,%rdi
  8231f8:	pcmpeqb %xmm1,%xmm2
  8231fc:	pmovmskb %xmm2,%r9d
  823201:	test   %r9d,%r9d
  823204:	jne    823238 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x108>
  823206:	mov    $0x1,%r9d
  82320c:	jmp    823211 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xe1>
  82320e:	xor    %r9d,%r9d
  823211:	add    %r8,%rax
  823214:	add    $0x10,%rax
  823218:	add    $0x10,%r8
  82321c:	jmp    823195 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x65>
  823221:	mov    -0x8(%r11),%rax
  823225:	mov    %r14d,-0x8(%r11)
  823229:	mov    %ebp,-0x4(%r11)
  82322d:	mov    %rax,0x4(%rbx)
  823231:	mov    $0x1,%eax
  823236:	jmp    823292 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x162>
  823238:	movzbl (%rcx,%rdi,1),%eax
  82323c:	test   %al,%al
  82323e:	jns    8232c7 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x197>
  823244:	and    $0x1,%al
  823246:	lea    -0x10(%rdi),%r8
  82324a:	and    %rsi,%r8
  82324d:	mov    %dl,(%rcx,%rdi,1)
  823250:	mov    %dl,0x10(%rcx,%r8,1)
  823255:	movdqu 0x10(%r12),%xmm0
  82325c:	movzbl %al,%eax
  82325f:	movd   %eax,%xmm1
  823263:	shufpd $0x2,-0x77808c(%rip),%xmm1        # ab1e0 <anon.a16d5d421a76dfd8c37a17b53540311d.51.llvm.14190004212411149437+0xe0>
  82326c:	psubq  %xmm1,%xmm0
  823270:	movdqu %xmm0,0x10(%r12)
  823277:	shl    $0x4,%rdi
  82327b:	mov    %rcx,%rax
  82327e:	sub    %rdi,%rax
  823281:	neg    %rdi
  823284:	mov    %r15,-0x10(%rcx,%rdi,1)
  823289:	mov    %r14d,-0x8(%rax)
  82328d:	mov    %ebp,-0x4(%rax)
  823290:	xor    %eax,%eax
  823292:	mov    %eax,(%rbx)
  823294:	mov    %rbx,%rax
  823297:	add    $0x8,%rsp
  82329b:	pop    %rbx
  82329c:	pop    %r12
  82329e:	pop    %r13
  8232a0:	pop    %r14
  8232a2:	pop    %r15
  8232a4:	pop    %rbp
  8232a5:	ret
  8232a6:	mov    $0x1,%esi
  8232ab:	mov    %r12,%rdi
  8232ae:	mov    %r13,%rdx
  8232b1:	mov    $0x1,%ecx
  8232b6:	mov    %rax,%r13
  8232b9:	call   *0x65c371(%rip)        # e7f630 <_DYNAMIC+0x6a8>
  8232bf:	mov    %r13,%rax
  8232c2:	jmp    823169 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x39>
  8232c7:	movdqa (%rcx),%xmm0
  8232cb:	pmovmskb %xmm0,%eax
  8232cf:	tzcnt  %eax,%edi
  8232d3:	movzbl (%rcx,%rdi,1),%eax
  8232d7:	jmp    823244 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x114>

FUNCTION <alloc::raw_vec::RawVec<gpui_gpu::renderer::Correction>>::grow_one bytes=100 frame=40

/tmp/gpui-legacy-coverage-codegen/legacy277/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000823640 <<alloc::raw_vec::RawVec<gpui_gpu::renderer::Correction>>::grow_one>:
  823640:	push   %r14
  823642:	push   %rbx
  823643:	sub    $0x18,%rsp
  823647:	mov    %rdi,%rbx
  82364a:	mov    (%rdi),%rsi
  82364d:	lea    (%rsi,%rsi,1),%rax
  823651:	cmp    $0x5,%rax
  823655:	mov    $0x4,%r14d
  82365b:	cmovae %rax,%r14
  82365f:	mov    0x8(%rdi),%rdx
  823663:	mov    %rsp,%rdi
  823666:	mov    $0x4,%r8d
  82366c:	mov    $0x20,%r9d
  823672:	mov    %r14,%rcx
  823675:	call   8236b0 <<alloc::raw_vec::RawVecInner>::finish_grow>
  82367a:	cmpl   $0x1,(%rsp)
  82367e:	je     823694 <<alloc::raw_vec::RawVec<gpui_gpu::renderer::Correction>>::grow_one+0x54>
  823680:	mov    0x8(%rsp),%rax
  823685:	mov    %rax,0x8(%rbx)
  823689:	mov    %r14,(%rbx)
  82368c:	add    $0x18,%rsp
  823690:	pop    %rbx
  823691:	pop    %r14
  823693:	ret
  823694:	mov    0x8(%rsp),%rdi
  823699:	mov    0x10(%rsp),%rsi
  82369e:	call   *0x65bb6c(%rip)        # e7f210 <_DYNAMIC+0x288>

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}> bytes=1602 frame=136

/tmp/gpui-legacy-coverage-codegen/legacy277/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008240a0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>>:
  8240a0:	push   %rbp
  8240a1:	push   %r15
  8240a3:	push   %r14
  8240a5:	push   %r13
  8240a7:	push   %r12
  8240a9:	push   %rbx
  8240aa:	sub    $0x58,%rsp
  8240ae:	mov    %ecx,%ebp
  8240b0:	mov    %rdx,0x8(%rsp)
  8240b5:	mov    0x18(%rdi),%rax
  8240b9:	add    %rax,%rsi
  8240bc:	jb     8241d1 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x131>
  8240c2:	mov    %rdi,%rbx
  8240c5:	mov    0x8(%rdi),%r15
  8240c9:	lea    0x1(%r15),%rdx
  8240cd:	mov    %rdx,%rdi
  8240d0:	shr    $0x3,%rdi
  8240d4:	mov    %rdx,%rcx
  8240d7:	and    $0xfffffffffffffff8,%rcx
  8240db:	sub    %rdi,%rcx
  8240de:	cmp    $0x8,%r15
  8240e2:	cmovb  %r15,%rcx
  8240e6:	mov    %rcx,%rdi
  8240e9:	shr    $1,%rdi
  8240ec:	cmp    %rdi,%rsi
  8240ef:	jbe    824120 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x80>
  8240f1:	inc    %rcx
  8240f4:	cmp    %rsi,%rcx
  8240f7:	cmovbe %rsi,%rcx
  8240fb:	cmp    $0xf,%rcx
  8240ff:	mov    %rbx,(%rsp)
  824103:	jae    824151 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0xb1>
  824105:	mov    %ecx,%eax
  824107:	and    $0x8,%eax
  82410a:	add    $0x8,%rax
  82410e:	cmp    $0x4,%rcx
  824112:	mov    $0x4,%ebx
  824117:	cmovae %rax,%rbx
  82411b:	jmp    8241a9 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x109>
  824120:	test   %rdx,%rdx
  824123:	je     8243aa <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x30a>
  824129:	mov    (%rbx),%rsi
  82412c:	mov    %rdx,%rax
  82412f:	shr    $0x4,%rax
  824133:	mov    %edx,%ecx
  824135:	and    $0xf,%ecx
  824138:	cmp    $0x1,%rcx
  82413c:	sbb    $0xffffffffffffffff,%rax
  824140:	cmp    $0x1,%rax
  824144:	jne    8243b1 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x311>
  82414a:	xor    %ecx,%ecx
  82414c:	jmp    824404 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x364>
  824151:	movabs $0x1ffffffffffffffe,%rax
  82415b:	inc    %rax
  82415e:	cmp    %rax,%rcx
  824161:	ja     8241d1 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x131>
  824163:	shl    $0x3,%rcx
  824167:	movabs $0x2492492492492493,%rdx
  824171:	mov    %rcx,%rax
  824174:	mul    %rdx
  824177:	sub    %rdx,%rcx
  82417a:	shr    $1,%rcx
  82417d:	add    %rdx,%rcx
  824180:	shr    $0x2,%rcx
  824184:	dec    %rcx
  824187:	bsr    %rcx,%rcx
  82418b:	not    %ecx
  82418d:	mov    $0xffffffffffffffff,%rbx
  824194:	shr    %cl,%rbx
  824197:	movabs $0x7fffffffffffffe,%rax
  8241a1:	cmp    %rax,%rbx
  8241a4:	ja     8241d1 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x131>
  8241a6:	inc    %rbx
  8241a9:	mov    %rbx,%r14
  8241ac:	shl    $0x5,%r14
  8241b0:	lea    0x10(%rbx),%r12
  8241b4:	mov    %r12,%r13
  8241b7:	add    %r14,%r13
  8241ba:	setb   %al
  8241bd:	movabs $0x7ffffffffffffff0,%rcx
  8241c7:	cmp    %rcx,%r13
  8241ca:	seta   %cl
  8241cd:	or     %al,%cl
  8241cf:	je     8241e0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x140>
  8241d1:	movzbl %bpl,%edi
  8241d5:	call   *0x65b4cd(%rip)        # e7f6a8 <_DYNAMIC+0x720>
  8241db:	jmp    824625 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x585>
  8241e0:	call   *0x65b032(%rip)        # e7f218 <_DYNAMIC+0x290>
  8241e6:	mov    $0x10,%esi
  8241eb:	mov    %r13,%rdi
  8241ee:	call   *0x65b02c(%rip)        # e7f220 <_DYNAMIC+0x298>
  8241f4:	test   %rax,%rax
  8241f7:	je     824643 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x5a3>
  8241fd:	mov    %rax,%r15
  824200:	mov    (%rsp),%rcx
  824204:	lea    0x20(%rcx),%r13
  824208:	add    %r14,%r15
  82420b:	lea    -0x1(%rbx),%r14
  82420f:	mov    %rbx,%rax
  824212:	shr    $0x3,%rax
  824216:	mov    %rbx,%rbp
  824219:	and    $0xfffffffffffffff8,%rbp
  82421d:	sub    %rax,%rbp
  824220:	cmp    $0x9,%rbx
  824224:	mov    %rcx,%rbx
  824227:	cmovb  %r14,%rbp
  82422b:	mov    %r15,%rdi
  82422e:	mov    $0xff,%esi
  824233:	mov    %r12,%rdx
  824236:	call   *0x65b474(%rip)        # e7f6b0 <memset@GLIBC_2.2.5>
  82423c:	mov    %r14,%rdi
  82423f:	mov    %r13,0x20(%rsp)
  824244:	movq   $0x20,0x28(%rsp)
  82424d:	movq   $0x10,0x30(%rsp)
  824256:	mov    %r15,0x38(%rsp)
  82425b:	mov    %r14,0x40(%rsp)
  824260:	mov    %rbp,0x48(%rsp)
  824265:	movq   $0x0,0x50(%rsp)
  82426e:	mov    0x18(%rbx),%r12
  824272:	test   %r12,%r12
  824275:	je     824657 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x5b7>
  82427b:	mov    %rbp,0x10(%rsp)
  824280:	mov    (%rbx),%rsi
  824283:	movdqa (%rsi),%xmm0
  824287:	pmovmskb %xmm0,%r13d
  82428c:	not    %r13d
  82428f:	xor    %ebp,%ebp
  824291:	mov    %rsi,%r14
  824294:	mov    %rdi,0x18(%rsp)
  824299:	nopl   0x0(%rax)
  8242a0:	test   %r13w,%r13w
  8242a4:	jne    8242cf <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x22f>
  8242a6:	cs nopw 0x0(%rax,%rax,1)
  8242b0:	movdqa 0x10(%r14),%xmm0
  8242b6:	add    $0x10,%r14
  8242ba:	pmovmskb %xmm0,%r13d
  8242bf:	xor    $0xffff,%r13d
  8242c6:	add    $0x10,%rbp
  8242ca:	test   %r13d,%r13d
  8242cd:	je     8242b0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x210>
  8242cf:	tzcnt  %r13d,%ebx
  8242d4:	add    %rbp,%rbx
  8242d7:	mov    %rbx,%rax
  8242da:	shl    $0x5,%rax
  8242de:	sub    %rax,%rsi
  8242e1:	add    $0xffffffffffffffe0,%rsi
  8242e5:	mov    0x8(%rsp),%rdi
  8242ea:	call   821710 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  8242ef:	mov    %rax,%rdx
  8242f2:	mov    0x18(%rsp),%rdi
  8242f7:	and    %rdi,%rdx
  8242fa:	movdqu (%r15,%rdx,1),%xmm0
  824300:	pmovmskb %xmm0,%ecx
  824304:	test   %ecx,%ecx
  824306:	je     824375 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x2d5>
  824308:	tzcnt  %ecx,%ecx
  82430c:	add    %rdx,%rcx
  82430f:	and    %rdi,%rcx
  824312:	cmpb   $0x0,(%r15,%rcx,1)
  824317:	jns    824398 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x2f8>
  824319:	lea    -0x1(%r13),%edx
  82431d:	and    %r13d,%edx
  824320:	dec    %r12
  824323:	shr    $0x39,%rax
  824327:	lea    -0x10(%rcx),%rsi
  82432b:	and    %rdi,%rsi
  82432e:	mov    %al,(%r15,%rcx,1)
  824332:	mov    %al,0x10(%r15,%rsi,1)
  824337:	mov    (%rsp),%rax
  82433b:	mov    (%rax),%rsi
  82433e:	not    %rbx
  824341:	shl    $0x5,%rbx
  824345:	not    %rcx
  824348:	shl    $0x5,%rcx
  82434c:	movdqu (%rsi,%rbx,1),%xmm0
  824351:	movdqu 0x10(%rsi,%rbx,1),%xmm1
  824357:	movdqu %xmm1,0x10(%r15,%rcx,1)
  82435e:	movdqu %xmm0,(%r15,%rcx,1)
  824364:	mov    %edx,%r13d
  824367:	test   %r12,%r12
  82436a:	jne    8242a0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x200>
  824370:	jmp    824634 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x594>
  824375:	mov    $0x10,%esi
  82437a:	add    %rsi,%rdx
  82437d:	and    %rdi,%rdx
  824380:	movdqu (%r15,%rdx,1),%xmm0
  824386:	pmovmskb %xmm0,%ecx
  82438a:	add    $0x10,%rsi
  82438e:	test   %ecx,%ecx
  824390:	jne    824308 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x268>
  824396:	jmp    82437a <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x2da>
  824398:	movdqa (%r15),%xmm0
  82439d:	pmovmskb %xmm0,%ecx
  8243a1:	tzcnt  %ecx,%ecx
  8243a5:	jmp    824319 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x279>
  8243aa:	xor    %ecx,%ecx
  8243ac:	jmp    824617 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x577>
  8243b1:	movabs $0x1ffffffffffffffe,%rdi
  8243bb:	and    %rax,%rdi
  8243be:	xor    %ecx,%ecx
  8243c0:	movdqa -0x776828(%rip),%xmm0        # adba0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x830>
  8243c8:	nopl   0x0(%rax,%rax,1)
  8243d0:	pxor   %xmm1,%xmm1
  8243d4:	pcmpgtb (%rsi,%rcx,1),%xmm1
  8243d9:	por    %xmm0,%xmm1
  8243dd:	movdqa %xmm1,(%rsi,%rcx,1)
  8243e2:	pxor   %xmm1,%xmm1
  8243e6:	pcmpgtb 0x10(%rsi,%rcx,1),%xmm1
  8243ec:	por    %xmm0,%xmm1
  8243f0:	movdqa %xmm1,0x10(%rsi,%rcx,1)
  8243f6:	add    $0x20,%rcx
  8243fa:	add    $0xfffffffffffffffe,%rdi
  8243fe:	jne    8243d0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x330>
  824400:	test   $0x1,%al
  824402:	je     82441a <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x37a>
  824404:	pxor   %xmm0,%xmm0
  824408:	pcmpgtb (%rsi,%rcx,1),%xmm0
  82440d:	por    -0x776875(%rip),%xmm0        # adba0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x830>
  824415:	movdqa %xmm0,(%rsi,%rcx,1)
  82441a:	cmp    $0x10,%rdx
  82441e:	jb     8246a8 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x608>
  824424:	mov    %rdx,%rdi
  824427:	mov    $0x10,%edx
  82442c:	add    %rsi,%rdi
  82442f:	call   *0x65b283(%rip)        # e7f6b8 <memmove@GLIBC_2.2.5>
  824435:	movq   $0x0,0x28(%rsp)
  82443e:	movq   $0x20,0x30(%rsp)
  824447:	mov    %rbx,0x20(%rsp)
  82444c:	xor    %r12d,%r12d
  82444f:	xor    %r13d,%r13d
  824452:	jmp    8245a1 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x501>
  824457:	nopw   0x0(%rax,%rax,1)
  824460:	lea    (%rax,%rbp,1),%rsi
  824464:	add    $0xffffffffffffffe0,%rsi
  824468:	mov    0x8(%rsp),%rdi
  82446d:	call   821710 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  824472:	mov    (%rbx),%rcx
  824475:	mov    0x8(%rbx),%rdx
  824479:	mov    %rdx,%rsi
  82447c:	and    %rax,%rsi
  82447f:	movdqu (%rcx,%rsi,1),%xmm0
  824484:	pmovmskb %xmm0,%edi
  824488:	mov    %rsi,%r8
  82448b:	test   %edi,%edi
  82448d:	je     824539 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x499>
  824493:	tzcnt  %edi,%edi
  824497:	add    %r8,%rdi
  82449a:	and    %rdx,%rdi
  82449d:	cmpb   $0x0,(%rcx,%rdi,1)
  8244a1:	jns    824560 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4c0>
  8244a7:	mov    %r12,%r8
  8244aa:	sub    %rsi,%r8
  8244ad:	mov    %rdi,%r9
  8244b0:	sub    %rsi,%r9
  8244b3:	xor    %r8,%r9
  8244b6:	and    %rdx,%r9
  8244b9:	cmp    $0x10,%r9
  8244bd:	jb     824580 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4e0>
  8244c3:	mov    %rdi,%rsi
  8244c6:	not    %rsi
  8244c9:	shl    $0x5,%rsi
  8244cd:	add    %rcx,%rsi
  8244d0:	movzbl (%rcx,%rdi,1),%r8d
  8244d5:	shr    $0x39,%rax
  8244d9:	lea    -0x10(%rdi),%r9
  8244dd:	and    %rdx,%r9
  8244e0:	mov    %al,(%rcx,%rdi,1)
  8244e3:	mov    (%rbx),%rcx
  8244e6:	mov    %al,0x10(%rcx,%r9,1)
  8244eb:	cmp    $0xff,%r8b
  8244ef:	je     8245c6 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x526>
  8244f5:	mov    (%r14),%rax
  8244f8:	mov    (%rsi),%rcx
  8244fb:	mov    %rcx,(%r14)
  8244fe:	mov    %rax,(%rsi)
  824501:	mov    0x8(%r14),%rax
  824505:	mov    0x8(%rsi),%rcx
  824509:	mov    %rcx,0x8(%r14)
  82450d:	mov    %rax,0x8(%rsi)
  824511:	mov    0x10(%r14),%rax
  824515:	mov    0x10(%rsi),%rcx
  824519:	mov    %rcx,0x10(%r14)
  82451d:	mov    %rax,0x10(%rsi)
  824521:	mov    0x18(%r14),%rax
  824525:	mov    0x18(%rsi),%rcx
  824529:	mov    %rcx,0x18(%r14)
  82452d:	mov    %rax,0x18(%rsi)
  824531:	mov    (%rbx),%rax
  824534:	jmp    824460 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x3c0>
  824539:	mov    $0x10,%r9d
  82453f:	mov    %rsi,%r8
  824542:	add    %r9,%r8
  824545:	and    %rdx,%r8
  824548:	movdqu (%rcx,%r8,1),%xmm0
  82454e:	pmovmskb %xmm0,%edi
  824552:	add    $0x10,%r9
  824556:	test   %edi,%edi
  824558:	jne    824493 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x3f3>
  82455e:	jmp    824542 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4a2>
  824560:	movdqa (%rcx),%xmm0
  824564:	pmovmskb %xmm0,%edi
  824568:	tzcnt  %edi,%edi
  82456c:	jmp    8244a7 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x407>
  824571:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  824580:	shr    $0x39,%rax
  824584:	lea    -0x10(%r12),%rsi
  824589:	and    %rsi,%rdx
  82458c:	mov    %al,(%rcx,%r12,1)
  824590:	mov    (%rbx),%rcx
  824593:	mov    %al,0x10(%rcx,%rdx,1)
  824597:	cmp    %r15,%r12
  82459a:	lea    0x1(%r12),%r12
  82459f:	je     8245f5 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x555>
  8245a1:	mov    (%rbx),%rax
  8245a4:	cmp    (%rax,%r12,1),%r13b
  8245a8:	jno    824597 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4f7>
  8245aa:	mov    %r12,%r14
  8245ad:	not    %r14
  8245b0:	shl    $0x5,%r14
  8245b4:	add    %rax,%r14
  8245b7:	mov    %r12,%rbp
  8245ba:	neg    %rbp
  8245bd:	shl    $0x5,%rbp
  8245c1:	jmp    824460 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x3c0>
  8245c6:	lea    -0x10(%r12),%rax
  8245cb:	and    0x8(%rbx),%rax
  8245cf:	mov    (%rbx),%rcx
  8245d2:	movb   $0xff,(%rcx,%r12,1)
  8245d7:	mov    (%rbx),%rcx
  8245da:	movb   $0xff,0x10(%rcx,%rax,1)
  8245df:	movdqu (%r14),%xmm0
  8245e4:	movdqu 0x10(%r14),%xmm1
  8245ea:	movdqu %xmm1,0x10(%rsi)
  8245ef:	movdqu %xmm0,(%rsi)
  8245f3:	jmp    824597 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4f7>
  8245f5:	mov    0x8(%rbx),%rdx
  8245f9:	mov    0x18(%rbx),%rax
  8245fd:	lea    0x1(%rdx),%rcx
  824601:	mov    %rcx,%rsi
  824604:	shr    $0x3,%rsi
  824608:	and    $0xfffffffffffffff8,%rcx
  82460c:	sub    %rsi,%rcx
  82460f:	cmp    $0x8,%rdx
  824613:	cmovb  %rdx,%rcx
  824617:	sub    %rax,%rcx
  82461a:	mov    %rcx,0x10(%rbx)
  82461e:	mov    $0xffffffffffffffff,%rax
  824625:	add    $0x58,%rsp
  824629:	pop    %rbx
  82462a:	pop    %r12
  82462c:	pop    %r13
  82462e:	pop    %r14
  824630:	pop    %r15
  824632:	pop    %rbp
  824633:	ret
  824634:	mov    (%rsp),%rbx
  824638:	mov    0x18(%rbx),%rcx
  82463c:	mov    0x10(%rsp),%rbp
  824641:	jmp    82465c <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x5bc>
  824643:	movzbl %bpl,%edi
  824647:	mov    $0x10,%esi
  82464c:	mov    %r13,%rdx
  82464f:	call   *0x65b06b(%rip)        # e7f6c0 <_DYNAMIC+0x738>
  824655:	jmp    824625 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x585>
  824657:	mov    (%rbx),%rsi
  82465a:	xor    %ecx,%ecx
  82465c:	sub    %rcx,%rbp
  82465f:	mov    %r15,(%rbx)
  824662:	mov    0x8(%rbx),%rax
  824666:	mov    %rdi,0x8(%rbx)
  82466a:	mov    %rbp,0x10(%rbx)
  82466e:	mov    %rcx,0x18(%rbx)
  824672:	test   %rax,%rax
  824675:	je     82461e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x57e>
  824677:	mov    %rax,%rcx
  82467a:	shl    $0x5,%rcx
  82467e:	add    $0x2f,%rcx
  824682:	and    $0xffffffffffffffe0,%rcx
  824686:	add    %rcx,%rax
  824689:	add    $0x11,%rax
  82468d:	je     82461e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x57e>
  82468f:	sub    %rcx,%rsi
  824692:	mov    $0x10,%edx
  824697:	mov    %rsi,%rdi
  82469a:	mov    %rax,%rsi
  82469d:	call   *0x65ab2d(%rip)        # e7f1d0 <_DYNAMIC+0x248>
  8246a3:	jmp    82461e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x57e>
  8246a8:	mov    $0x10,%edi
  8246ad:	jmp    82442c <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x38c>
  8246b2:	mov    %rax,%rbx
  8246b5:	lea    0x20(%rsp),%rdi
  8246ba:	call   824c90 <core::ptr::drop_glue::<hashbrown::scopeguard::ScopeGuard<hashbrown::raw::RawTableInner, <hashbrown::raw::RawTableInner>::prepare_resize<alloc::alloc::Global>::{closure#0}>>>
  8246bf:	mov    %rbx,%rdi
  8246c2:	call   e2bd40 <_Unwind_Resume@plt>
  8246c7:	mov    %rax,%rbx
  8246ca:	lea    0x20(%rsp),%rdi
  8246cf:	call   824cd0 <core::ptr::drop_glue::<hashbrown::scopeguard::ScopeGuard<&mut hashbrown::raw::RawTableInner, <hashbrown::raw::RawTableInner>::rehash_in_place::{closure#0}>>>
  8246d4:	mov    %rbx,%rdi
  8246d7:	call   e2bd40 <_Unwind_Resume@plt>
  8246dc:	call   *0x65aaf6(%rip)        # e7f1d8 <_DYNAMIC+0x250>

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}> bytes=1437 frame=104

/tmp/gpui-legacy-coverage-codegen/legacy277/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008246f0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>>:
  8246f0:	push   %rbp
  8246f1:	push   %r15
  8246f3:	push   %r14
  8246f5:	push   %r13
  8246f7:	push   %r12
  8246f9:	push   %rbx
  8246fa:	sub    $0x38,%rsp
  8246fe:	mov    %ecx,%r15d
  824701:	mov    %rdx,0x20(%rsp)
  824706:	mov    %rdi,%rbp
  824709:	mov    0x18(%rdi),%rdi
  82470d:	add    %rdi,%rsi
  824710:	jb     824828 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x138>
  824716:	mov    0x8(%rbp),%rbx
  82471a:	lea    0x1(%rbx),%rdx
  82471e:	mov    %rdx,%rax
  824721:	shr    $0x3,%rax
  824725:	mov    %rdx,%rcx
  824728:	and    $0xfffffffffffffff8,%rcx
  82472c:	sub    %rax,%rcx
  82472f:	cmp    $0x8,%rbx
  824733:	cmovb  %rbx,%rcx
  824737:	mov    %rcx,%rax
  82473a:	shr    $1,%rax
  82473d:	cmp    %rax,%rsi
  824740:	jbe    824776 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x86>
  824742:	inc    %rcx
  824745:	cmp    %rsi,%rcx
  824748:	cmovbe %rsi,%rcx
  82474c:	cmp    $0xf,%rcx
  824750:	mov    %rbp,(%rsp)
  824754:	mov    %rbx,0x30(%rsp)
  824759:	jae    8247a8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0xb8>
  82475b:	mov    %ecx,%eax
  82475d:	and    $0x8,%eax
  824760:	add    $0x8,%rax
  824764:	cmp    $0x4,%rcx
  824768:	mov    $0x4,%ebx
  82476d:	cmovae %rax,%rbx
  824771:	jmp    824800 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x110>
  824776:	test   %rdx,%rdx
  824779:	je     8249be <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2ce>
  82477f:	mov    0x0(%rbp),%r12
  824783:	mov    %rdx,%rax
  824786:	shr    $0x4,%rax
  82478a:	mov    %edx,%ecx
  82478c:	and    $0xf,%ecx
  82478f:	cmp    $0x1,%rcx
  824793:	sbb    $0xffffffffffffffff,%rax
  824797:	cmp    $0x1,%rax
  82479b:	jne    8249c5 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2d5>
  8247a1:	xor    %ecx,%ecx
  8247a3:	jmp    824a18 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x328>
  8247a8:	movabs $0x1ffffffffffffffe,%rax
  8247b2:	inc    %rax
  8247b5:	cmp    %rax,%rcx
  8247b8:	ja     824828 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x138>
  8247ba:	shl    $0x3,%rcx
  8247be:	movabs $0x2492492492492493,%rdx
  8247c8:	mov    %rcx,%rax
  8247cb:	mul    %rdx
  8247ce:	sub    %rdx,%rcx
  8247d1:	shr    $1,%rcx
  8247d4:	add    %rdx,%rcx
  8247d7:	shr    $0x2,%rcx
  8247db:	dec    %rcx
  8247de:	bsr    %rcx,%rcx
  8247e2:	not    %ecx
  8247e4:	mov    $0xffffffffffffffff,%rbx
  8247eb:	shr    %cl,%rbx
  8247ee:	movabs $0xffffffffffffffe,%rax
  8247f8:	cmp    %rax,%rbx
  8247fb:	ja     824828 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x138>
  8247fd:	inc    %rbx
  824800:	mov    %rbx,%r14
  824803:	shl    $0x4,%r14
  824807:	lea    0x10(%rbx),%rbp
  82480b:	mov    %rbp,%r13
  82480e:	add    %r14,%r13
  824811:	setb   %al
  824814:	movabs $0x7ffffffffffffff0,%rcx
  82481e:	cmp    %rcx,%r13
  824821:	seta   %cl
  824824:	or     %al,%cl
  824826:	je     824837 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x147>
  824828:	movzbl %r15b,%edi
  82482c:	call   *0x65ae76(%rip)        # e7f6a8 <_DYNAMIC+0x720>
  824832:	jmp    824bf8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  824837:	mov    %rdi,0x8(%rsp)
  82483c:	call   *0x65a9d6(%rip)        # e7f218 <_DYNAMIC+0x290>
  824842:	mov    $0x10,%esi
  824847:	mov    %r13,%rdi
  82484a:	call   *0x65a9d0(%rip)        # e7f220 <_DYNAMIC+0x298>
  824850:	test   %rax,%rax
  824853:	je     824c12 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x522>
  824859:	mov    %rax,%rdi
  82485c:	add    %r14,%rdi
  82485f:	lea    -0x1(%rbx),%rcx
  824863:	mov    %rbx,%rax
  824866:	shr    $0x3,%rax
  82486a:	mov    %rbx,%r14
  82486d:	and    $0xfffffffffffffff8,%r14
  824871:	sub    %rax,%r14
  824874:	cmp    $0x9,%rbx
  824878:	mov    %rcx,0x10(%rsp)
  82487d:	cmovb  %rcx,%r14
  824881:	mov    %rdi,0x18(%rsp)
  824886:	mov    $0xff,%esi
  82488b:	mov    %rbp,%rdx
  82488e:	call   *0x65ae1c(%rip)        # e7f6b0 <memset@GLIBC_2.2.5>
  824894:	mov    0x8(%rsp),%rbx
  824899:	test   %rbx,%rbx
  82489c:	je     824c26 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x536>
  8248a2:	mov    %r14,0x28(%rsp)
  8248a7:	mov    (%rsp),%rax
  8248ab:	mov    (%rax),%rdi
  8248ae:	movdqa (%rdi),%xmm0
  8248b2:	pmovmskb %xmm0,%r14d
  8248b7:	not    %r14d
  8248ba:	xor    %ebp,%ebp
  8248bc:	mov    %rdi,%r13
  8248bf:	nop
  8248c0:	test   %r14w,%r14w
  8248c4:	jne    8248ef <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x1ff>
  8248c6:	cs nopw 0x0(%rax,%rax,1)
  8248d0:	movdqa 0x10(%r13),%xmm0
  8248d6:	add    $0x10,%r13
  8248da:	pmovmskb %xmm0,%r14d
  8248df:	xor    $0xffff,%r14d
  8248e6:	add    $0x10,%rbp
  8248ea:	test   %r14d,%r14d
  8248ed:	je     8248d0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x1e0>
  8248ef:	tzcnt  %r14d,%r15d
  8248f4:	add    %rbp,%r15
  8248f7:	mov    %r15,%rax
  8248fa:	shl    $0x4,%rax
  8248fe:	mov    %rdi,%r12
  824901:	mov    %rdi,%rsi
  824904:	sub    %rax,%rsi
  824907:	add    $0xfffffffffffffff0,%rsi
  82490b:	mov    0x20(%rsp),%rdi
  824910:	call   8218b0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  824915:	mov    %rax,%rcx
  824918:	mov    0x10(%rsp),%r9
  82491d:	and    %r9,%rcx
  824920:	mov    0x18(%rsp),%r8
  824925:	movdqu (%r8,%rcx,1),%xmm0
  82492b:	pmovmskb %xmm0,%edx
  82492f:	test   %edx,%edx
  824931:	je     824990 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2a0>
  824933:	tzcnt  %edx,%edx
  824937:	add    %rcx,%rdx
  82493a:	and    %r9,%rdx
  82493d:	cmpb   $0x0,(%r8,%rdx,1)
  824942:	mov    %r12,%rdi
  824945:	jns    8249af <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2bf>
  824947:	lea    -0x1(%r14),%ecx
  82494b:	and    %r14d,%ecx
  82494e:	dec    %rbx
  824951:	shr    $0x39,%rax
  824955:	lea    -0x10(%rdx),%rsi
  824959:	and    %r9,%rsi
  82495c:	mov    %al,(%r8,%rdx,1)
  824960:	mov    %al,0x10(%r8,%rsi,1)
  824965:	not    %r15
  824968:	shl    $0x4,%r15
  82496c:	not    %rdx
  82496f:	shl    $0x4,%rdx
  824973:	movdqu (%rdi,%r15,1),%xmm0
  824979:	movdqu %xmm0,(%r8,%rdx,1)
  82497f:	mov    %ecx,%r14d
  824982:	test   %rbx,%rbx
  824985:	jne    8248c0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x1d0>
  82498b:	jmp    824c07 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x517>
  824990:	mov    $0x10,%esi
  824995:	add    %rsi,%rcx
  824998:	and    %r9,%rcx
  82499b:	movdqu (%r8,%rcx,1),%xmm0
  8249a1:	pmovmskb %xmm0,%edx
  8249a5:	add    $0x10,%rsi
  8249a9:	test   %edx,%edx
  8249ab:	jne    824933 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x243>
  8249ad:	jmp    824995 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2a5>
  8249af:	movdqa (%r8),%xmm0
  8249b4:	pmovmskb %xmm0,%ecx
  8249b8:	tzcnt  %ecx,%edx
  8249bc:	jmp    824947 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x257>
  8249be:	xor    %eax,%eax
  8249c0:	jmp    824bea <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x4fa>
  8249c5:	movabs $0x1ffffffffffffffe,%rsi
  8249cf:	and    %rax,%rsi
  8249d2:	xor    %ecx,%ecx
  8249d4:	movdqa -0x776e3c(%rip),%xmm0        # adba0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x830>
  8249dc:	nopl   0x0(%rax)
  8249e0:	pxor   %xmm1,%xmm1
  8249e4:	pcmpgtb (%r12,%rcx,1),%xmm1
  8249ea:	por    %xmm0,%xmm1
  8249ee:	movdqa %xmm1,(%r12,%rcx,1)
  8249f4:	pxor   %xmm1,%xmm1
  8249f8:	pcmpgtb 0x10(%r12,%rcx,1),%xmm1
  8249ff:	por    %xmm0,%xmm1
  824a03:	movdqa %xmm1,0x10(%r12,%rcx,1)
  824a0a:	add    $0x20,%rcx
  824a0e:	add    $0xfffffffffffffffe,%rsi
  824a12:	jne    8249e0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2f0>
  824a14:	test   $0x1,%al
  824a16:	je     824a30 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x340>
  824a18:	pxor   %xmm0,%xmm0
  824a1c:	pcmpgtb (%r12,%rcx,1),%xmm0
  824a22:	por    -0x776e8a(%rip),%xmm0        # adba0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x830>
  824a2a:	movdqa %xmm0,(%r12,%rcx,1)
  824a30:	cmp    $0x10,%rdx
  824a34:	jb     824c83 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x593>
  824a3a:	mov    %rdx,%rdi
  824a3d:	mov    $0x10,%edx
  824a42:	add    %r12,%rdi
  824a45:	mov    %r12,%rsi
  824a48:	call   *0x65ac6a(%rip)        # e7f6b8 <memmove@GLIBC_2.2.5>
  824a4e:	xor    %r13d,%r13d
  824a51:	xor    %eax,%eax
  824a53:	jmp    824b86 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x496>
  824a58:	nopl   0x0(%rax,%rax,1)
  824a60:	lea    (%r12,%r14,1),%rsi
  824a64:	add    $0xfffffffffffffff0,%rsi
  824a68:	mov    0x20(%rsp),%rdi
  824a6d:	call   8218b0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  824a72:	mov    0x8(%rbp),%rcx
  824a76:	mov    %rcx,%rdx
  824a79:	and    %rax,%rdx
  824a7c:	movdqu (%r12,%rdx,1),%xmm0
  824a82:	pmovmskb %xmm0,%esi
  824a86:	mov    %rdx,%rdi
  824a89:	test   %esi,%esi
  824a8b:	je     824b1b <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x42b>
  824a91:	tzcnt  %esi,%esi
  824a95:	add    %rdi,%rsi
  824a98:	and    %rcx,%rsi
  824a9b:	cmpb   $0x0,(%r12,%rsi,1)
  824aa0:	jns    824b42 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x452>
  824aa6:	mov    %r13,%rdi
  824aa9:	sub    %rdx,%rdi
  824aac:	mov    %rsi,%r8
  824aaf:	sub    %rdx,%r8
  824ab2:	xor    %rdi,%r8
  824ab5:	and    %rcx,%r8
  824ab8:	cmp    $0x10,%r8
  824abc:	jb     824b60 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x470>
  824ac2:	mov    %rsi,%rdx
  824ac5:	not    %rdx
  824ac8:	shl    $0x4,%rdx
  824acc:	add    %r12,%rdx
  824acf:	movzbl (%r12,%rsi,1),%edi
  824ad4:	shr    $0x39,%rax
  824ad8:	lea    -0x10(%rsi),%r8
  824adc:	and    %rcx,%r8
  824adf:	mov    %al,(%r12,%rsi,1)
  824ae3:	mov    0x0(%rbp),%r12
  824ae7:	mov    %al,0x10(%r12,%r8,1)
  824aec:	cmp    $0xff,%dil
  824af0:	je     824bab <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x4bb>
  824af6:	mov    (%rbx),%rax
  824af9:	mov    (%rdx),%rcx
  824afc:	mov    %rcx,(%rbx)
  824aff:	mov    %rax,(%rdx)
  824b02:	mov    0x8(%rbx),%rax
  824b06:	mov    0x8(%rdx),%rcx
  824b0a:	mov    %rcx,0x8(%rbx)
  824b0e:	mov    %rax,0x8(%rdx)
  824b12:	mov    0x0(%rbp),%r12
  824b16:	jmp    824a60 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x370>
  824b1b:	mov    $0x10,%r8d
  824b21:	mov    %rdx,%rdi
  824b24:	add    %r8,%rdi
  824b27:	and    %rcx,%rdi
  824b2a:	movdqu (%r12,%rdi,1),%xmm0
  824b30:	pmovmskb %xmm0,%esi
  824b34:	add    $0x10,%r8
  824b38:	test   %esi,%esi
  824b3a:	jne    824a91 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x3a1>
  824b40:	jmp    824b24 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x434>
  824b42:	movdqa (%r12),%xmm0
  824b48:	pmovmskb %xmm0,%esi
  824b4c:	tzcnt  %esi,%esi
  824b50:	jmp    824aa6 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x3b6>
  824b55:	data16 cs nopw 0x0(%rax,%rax,1)
  824b60:	shr    $0x39,%rax
  824b64:	lea    -0x10(%r13),%rdx
  824b68:	and    %rdx,%rcx
  824b6b:	mov    %al,(%r12,%r13,1)
  824b6f:	mov    0x0(%rbp),%r12
  824b73:	mov    %al,0x10(%r12,%rcx,1)
  824b78:	mov    %r15,%rbx
  824b7b:	xor    %eax,%eax
  824b7d:	cmp    %rbx,%r13
  824b80:	lea    0x1(%r13),%r13
  824b84:	je     824bc8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x4d8>
  824b86:	cmp    (%r12,%r13,1),%al
  824b8a:	jno    824b7d <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x48d>
  824b8c:	mov    %rbx,%r15
  824b8f:	mov    %r13,%rbx
  824b92:	not    %rbx
  824b95:	shl    $0x4,%rbx
  824b99:	add    %r12,%rbx
  824b9c:	mov    %r13,%r14
  824b9f:	neg    %r14
  824ba2:	shl    $0x4,%r14
  824ba6:	jmp    824a60 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x370>
  824bab:	lea    -0x10(%r13),%rax
  824baf:	and    0x8(%rbp),%rax
  824bb3:	movb   $0xff,(%r12,%r13,1)
  824bb8:	movb   $0xff,0x10(%r12,%rax,1)
  824bbe:	movdqu (%rbx),%xmm0
  824bc2:	movdqu %xmm0,(%rdx)
  824bc6:	jmp    824b78 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x488>
  824bc8:	mov    0x8(%rbp),%rcx
  824bcc:	mov    0x18(%rbp),%rdi
  824bd0:	lea    0x1(%rcx),%rax
  824bd4:	mov    %rax,%rdx
  824bd7:	shr    $0x3,%rdx
  824bdb:	and    $0xfffffffffffffff8,%rax
  824bdf:	sub    %rdx,%rax
  824be2:	cmp    $0x8,%rcx
  824be6:	cmovb  %rcx,%rax
  824bea:	sub    %rdi,%rax
  824bed:	mov    %rax,0x10(%rbp)
  824bf1:	mov    $0xffffffffffffffff,%rax
  824bf8:	add    $0x38,%rsp
  824bfc:	pop    %rbx
  824bfd:	pop    %r12
  824bff:	pop    %r13
  824c01:	pop    %r14
  824c03:	pop    %r15
  824c05:	pop    %rbp
  824c06:	ret
  824c07:	mov    (%rsp),%rax
  824c0b:	mov    0x28(%rsp),%r14
  824c10:	jmp    824c37 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x547>
  824c12:	movzbl %r15b,%edi
  824c16:	mov    $0x10,%esi
  824c1b:	mov    %r13,%rdx
  824c1e:	call   *0x65aa9c(%rip)        # e7f6c0 <_DYNAMIC+0x738>
  824c24:	jmp    824bf8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  824c26:	mov    (%rsp),%rax
  824c2a:	mov    (%rax),%rdi
  824c2d:	mov    0x18(%rsp),%r8
  824c32:	mov    0x10(%rsp),%r9
  824c37:	sub    0x8(%rsp),%r14
  824c3c:	mov    %r8,(%rax)
  824c3f:	mov    %r9,0x8(%rax)
  824c43:	mov    %r14,0x10(%rax)
  824c47:	mov    $0xffffffffffffffff,%rax
  824c4e:	mov    0x30(%rsp),%rsi
  824c53:	test   %rsi,%rsi
  824c56:	je     824bf8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  824c58:	mov    %rsi,%rcx
  824c5b:	shl    $0x4,%rcx
  824c5f:	add    $0x1f,%rcx
  824c63:	and    $0xfffffffffffffff0,%rcx
  824c67:	add    %rcx,%rsi
  824c6a:	add    $0x11,%rsi
  824c6e:	je     824bf8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  824c70:	sub    %rcx,%rdi
  824c73:	mov    $0x10,%edx
  824c78:	call   *0x65a552(%rip)        # e7f1d0 <_DYNAMIC+0x248>
  824c7e:	jmp    824bf1 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x501>
  824c83:	mov    $0x10,%edi
  824c88:	jmp    824a42 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x352>

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop bytes=47 frame=0

/tmp/gpui-legacy-coverage-codegen/legacy277/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000824e40 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>:
  824e40:	mov    0x8(%rdi),%rsi
  824e44:	test   %rsi,%rsi
  824e47:	je     824e6e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  824e49:	mov    %rsi,%rax
  824e4c:	shl    $0x5,%rax
  824e50:	add    %rax,%rsi
  824e53:	add    $0x31,%rsi
  824e57:	je     824e6e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  824e59:	mov    (%rdi),%rdi
  824e5c:	sub    %rax,%rdi
  824e5f:	add    $0xffffffffffffffe0,%rdi
  824e63:	mov    $0x10,%edx
  824e68:	jmp    *0x65a362(%rip)        # e7f1d0 <_DYNAMIC+0x248>
  824e6e:	ret

FUNCTION <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}> bytes=303 frame=24

/tmp/gpui-legacy-coverage-codegen/legacy277/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008252c0 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>>:
  8252c0:	push   %r15
  8252c2:	push   %r14
  8252c4:	push   %rbx
  8252c5:	mov    (%rdx),%r9
  8252c8:	mov    0x8(%rdx),%r11
  8252cc:	mov    0x10(%rdx),%rbx
  8252d0:	mov    0x18(%rdx),%r10
  8252d4:	mov    0x20(%rdx),%r8
  8252d8:	mov    0x28(%rdx),%rcx
  8252dc:	test   $0x1,%r9b
  8252e0:	jne    82537a <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xba>
  8252e6:	mov    %rbx,%rax
  8252e9:	jmp    82530b <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x4b>
  8252eb:	nopl   0x0(%rax,%rax,1)
  8252f0:	lea    0x8(%rax),%rbx
  8252f4:	mov    %rbx,%r14
  8252f7:	add    $0x8,%rdi
  8252fb:	mov    (%rax),%r15
  8252fe:	mov    %r14,%rax
  825301:	cmp    0x28(%r15),%rdx
  825305:	jne    8253cf <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  82530b:	cmp    %rsi,%rdi
  82530e:	je     8253a8 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xe8>
  825314:	mov    (%rdi),%rdx
  825317:	test   %rax,%rax
  82531a:	je     825323 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x63>
  82531c:	cmp    %r10,%rax
  82531f:	jne    8252f0 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x30>
  825321:	xor    %ebx,%ebx
  825323:	xor    %eax,%eax
  825325:	test   %r8,%r8
  825328:	je     8253d1 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  82532e:	cmp    %rcx,%r8
  825331:	je     8253d1 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  825337:	mov    %r8,%rax
  82533a:	add    $0x8,%r8
  82533e:	xor    %r14d,%r14d
  825341:	jmp    8252f7 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x37>
  825343:	mov    (%r11),%rax
  825346:	mov    0x8(%rax),%rbx
  82534a:	mov    0x10(%rax),%rax
  82534e:	lea    (%rbx,%rax,8),%r10
  825352:	test   %rax,%rax
  825355:	je     825391 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xd1>
  825357:	xor    %r11d,%r11d
  82535a:	nopw   0x0(%rax,%rax,1)
  825360:	mov    %r8,%rax
  825363:	mov    %rbx,%r8
  825366:	add    $0x8,%rbx
  82536a:	add    $0x8,%rdi
  82536e:	mov    (%r8),%r14
  825371:	mov    %rax,%r8
  825374:	cmp    0x28(%r14),%rdx
  825378:	jne    8253cf <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  82537a:	cmp    %rsi,%rdi
  82537d:	je     8253a8 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xe8>
  82537f:	mov    (%rdi),%rdx
  825382:	test   %rbx,%rbx
  825385:	je     82538c <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xcc>
  825387:	cmp    %r10,%rbx
  82538a:	jne    825360 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xa0>
  82538c:	test   %r11,%r11
  82538f:	jne    825343 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x83>
  825391:	xor    %eax,%eax
  825393:	test   %r8,%r8
  825396:	je     8253d1 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  825398:	cmp    %rcx,%r8
  82539b:	je     8253d1 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  82539d:	lea    0x8(%r8),%rax
  8253a1:	xor    %ebx,%ebx
  8253a3:	xor    %r11d,%r11d
  8253a6:	jmp    82536a <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xaa>
  8253a8:	test   %rbx,%rbx
  8253ab:	sete   %dl
  8253ae:	cmp    %r10,%rbx
  8253b1:	sete   %al
  8253b4:	or     %dl,%al
  8253b6:	test   $0x1,%r9b
  8253ba:	je     8253d7 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x117>
  8253bc:	test   %al,%al
  8253be:	je     8253cf <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  8253c0:	test   %r11,%r11
  8253c3:	je     8253db <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x11b>
  8253c5:	mov    (%r11),%rax
  8253c8:	cmpq   $0x0,0x10(%rax)
  8253cd:	je     8253db <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x11b>
  8253cf:	xor    %eax,%eax
  8253d1:	pop    %rbx
  8253d2:	pop    %r14
  8253d4:	pop    %r15
  8253d6:	ret
  8253d7:	test   %al,%al
  8253d9:	je     8253cf <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  8253db:	test   %r8,%r8
  8253de:	sete   %dl
  8253e1:	cmp    %rcx,%r8
  8253e4:	sete   %al
  8253e7:	or     %dl,%al
  8253e9:	pop    %rbx
  8253ea:	pop    %r14
  8253ec:	pop    %r15
  8253ee:	ret

FUNCTION gpui_gpu::renderer::slots::color_word bytes=57 frame=8

/tmp/gpui-legacy-coverage-codegen/legacy277/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008253f0 <gpui_gpu::renderer::slots::color_word>:
  8253f0:	lea    -0x3(%rsi),%eax
  8253f3:	cmp    %rax,%rdi
  8253f6:	jbe    82540f <gpui_gpu::renderer::slots::color_word+0x1f>
  8253f8:	mov    %rdi,%rax
  8253fb:	shr    $0x6,%rax
  8253ff:	and    $0x3f,%edi
  825402:	cmp    $0x1,%rdi
  825406:	sbb    $0xffffffff,%eax
  825409:	add    %esi,%eax
  82540b:	add    $0xfffffffe,%eax
  82540e:	ret
  82540f:	push   %rax
  825410:	lea    -0x750b5e(%rip),%rdi        # d48b9 <anon.4f92784177f891c02fc0a44bfee03ec4.9.llvm.6639503288718533278>
  825417:	lea    0x60888a(%rip),%rdx        # e2dca8 <anon.4f92784177f891c02fc0a44bfee03ec4.10.llvm.6639503288718533278>
  82541e:	mov    $0x1e,%esi
  825423:	call   *0x65a0c7(%rip)        # e7f4f0 <_DYNAMIC+0x568>

FUNCTION gpui_gpu::renderer::slots::write_prefix bytes=517 frame=72

/tmp/gpui-legacy-coverage-codegen/legacy277/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000825430 <gpui_gpu::renderer::slots::write_prefix>:
  825430:	push   %rbp
  825431:	push   %r15
  825433:	push   %r14
  825435:	push   %r13
  825437:	push   %r12
  825439:	push   %rbx
  82543a:	sub    $0x18,%rsp
  82543e:	test   %rdx,%rdx
  825441:	je     8255dc <gpui_gpu::renderer::slots::write_prefix+0x1ac>
  825447:	mov    %rdi,%rbx
  82544a:	mov    %rdx,%rax
  82544d:	shr    $0x6,%rax
  825451:	xor    %ecx,%ecx
  825453:	test   $0x3f,%dl
  825456:	setne  %cl
  825459:	lea    (%rax,%rcx,1),%rbp
  82545d:	lea    (%rax,%rcx,1),%r8
  825461:	inc    %r8
  825464:	mov    0x10(%rdi),%r12
  825468:	mov    %rbp,%r13
  82546b:	sub    %r12,%r13
  82546e:	jae    82547c <gpui_gpu::renderer::slots::write_prefix+0x4c>
  825470:	mov    0x8(%rbx),%rax
  825474:	mov    %r8,%r14
  825477:	jmp    82551b <gpui_gpu::renderer::slots::write_prefix+0xeb>
  82547c:	mov    %r8,%r15
  82547f:	sub    %r12,%r15
  825482:	mov    (%rbx),%rax
  825485:	sub    %r12,%rax
  825488:	mov    %r12,%r14
  82548b:	cmp    %rax,%r15
  82548e:	ja     8255eb <gpui_gpu::renderer::slots::write_prefix+0x1bb>
  825494:	mov    0x8(%rbx),%rax
  825498:	mov    %r14,%rcx
  82549b:	shl    $0x4,%rcx
  82549f:	add    %rax,%rcx
  8254a2:	cmp    $0x2,%r15
  8254a6:	jb     825512 <gpui_gpu::renderer::slots::write_prefix+0xe2>
  8254a8:	mov    %r13d,%edi
  8254ab:	and    $0x7,%edi
  8254ae:	sub    %rbp,%r12
  8254b1:	cmp    $0xfffffffffffffff8,%r12
  8254b5:	ja     8254ee <gpui_gpu::renderer::slots::write_prefix+0xbe>
  8254b7:	and    $0xfffffffffffffff8,%r13
  8254bb:	xorps  %xmm0,%xmm0
  8254be:	xchg   %ax,%ax
  8254c0:	movups %xmm0,(%rcx)
  8254c3:	movups %xmm0,0x10(%rcx)
  8254c7:	movups %xmm0,0x20(%rcx)
  8254cb:	movups %xmm0,0x30(%rcx)
  8254cf:	movups %xmm0,0x40(%rcx)
  8254d3:	movups %xmm0,0x50(%rcx)
  8254d7:	movups %xmm0,0x60(%rcx)
  8254db:	movups %xmm0,0x70(%rcx)
  8254df:	sub    $0xffffffffffffff80,%rcx
  8254e3:	add    $0xfffffffffffffff8,%r13
  8254e7:	jne    8254c0 <gpui_gpu::renderer::slots::write_prefix+0x90>
  8254e9:	test   %rdi,%rdi
  8254ec:	je     82550c <gpui_gpu::renderer::slots::write_prefix+0xdc>
  8254ee:	xorps  %xmm0,%xmm0
  8254f1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  825500:	movups %xmm0,(%rcx)
  825503:	add    $0x10,%rcx
  825507:	dec    %rdi
  82550a:	jne    825500 <gpui_gpu::renderer::slots::write_prefix+0xd0>
  82550c:	add    %r15,%r14
  82550f:	dec    %r14
  825512:	xorps  %xmm0,%xmm0
  825515:	movups %xmm0,(%rcx)
  825518:	inc    %r14
  82551b:	mov    %r14,0x10(%rbx)
  82551f:	mov    %edx,(%rax)
  825521:	mov    %ebp,0x4(%rax)
  825524:	mov    %r8d,0x8(%rax)
  825528:	movl   $0x0,0xc(%rax)
  82552f:	mov    %rsi,%rdi
  825532:	call   *0x659ff8(%rip)        # e7f530 <_DYNAMIC+0x5a8>
  825538:	cmp    %rdx,%rax
  82553b:	je     8255dc <gpui_gpu::renderer::slots::write_prefix+0x1ac>
  825541:	mov    %rax,%r15
  825544:	mov    %rdx,%r12
  825547:	xor    %r13d,%r13d
  82554a:	xor    %ebp,%ebp
  82554c:	jmp    825576 <gpui_gpu::renderer::slots::write_prefix+0x146>
  82554e:	xchg   %ax,%ax
  825550:	mov    0x8(%rbx),%rax
  825554:	mov    %r14,%rcx
  825557:	shl    $0x4,%rcx
  82555b:	movups %xmm0,(%rax,%rcx,1)
  82555f:	inc    %r14
  825562:	mov    %r14,0x10(%rbx)
  825566:	add    $0x2,%r13d
  82556a:	add    $0x18,%r15
  82556e:	inc    %rbp
  825571:	cmp    %r12,%r15
  825574:	je     8255dc <gpui_gpu::renderer::slots::write_prefix+0x1ac>
  825576:	mov    %rbp,%rdi
  825579:	shr    $0x6,%rdi
  82557d:	inc    %rdi
  825580:	cmp    %r14,%rdi
  825583:	jae    825625 <gpui_gpu::renderer::slots::write_prefix+0x1f5>
  825589:	movups (%r15),%xmm0
  82558d:	movzwl 0x12(%r15),%eax
  825592:	movzwl 0x10(%r15),%edx
  825597:	shr    $0xe,%eax
  82559a:	and    $0x2,%eax
  82559d:	shr    $0xf,%edx
  8255a0:	or     %eax,%edx
  8255a2:	mov    %r13d,%ecx
  8255a5:	and    $0x1e,%cl
  8255a8:	shl    %cl,%edx
  8255aa:	shl    $0x4,%rdi
  8255ae:	add    0x8(%rbx),%rdi
  8255b2:	mov    %ebp,%eax
  8255b4:	shr    $0x2,%eax
  8255b7:	and    $0xc,%eax
  8255ba:	or     %edx,(%rax,%rdi,1)
  8255bd:	mov    0x10(%rbx),%r14
  8255c1:	cmp    (%rbx),%r14
  8255c4:	jne    825550 <gpui_gpu::renderer::slots::write_prefix+0x120>
  8255c6:	mov    %rbx,%rdi
  8255c9:	movaps %xmm0,(%rsp)
  8255cd:	call   *0x65a0bd(%rip)        # e7f690 <_DYNAMIC+0x708>
  8255d3:	movaps (%rsp),%xmm0
  8255d7:	jmp    825550 <gpui_gpu::renderer::slots::write_prefix+0x120>
  8255dc:	add    $0x18,%rsp
  8255e0:	pop    %rbx
  8255e1:	pop    %r12
  8255e3:	pop    %r13
  8255e5:	pop    %r14
  8255e7:	pop    %r15
  8255e9:	pop    %rbp
  8255ea:	ret
  8255eb:	mov    $0x4,%ecx
  8255f0:	mov    %r8,0x10(%rsp)
  8255f5:	mov    $0x10,%r8d
  8255fb:	mov    %rbx,%rdi
  8255fe:	mov    %rsi,(%rsp)
  825602:	mov    %r12,%rsi
  825605:	mov    %rdx,%r14
  825608:	mov    %r15,%rdx
  82560b:	call   823440 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  825610:	mov    0x10(%rsp),%r8
  825615:	mov    %r14,%rdx
  825618:	mov    (%rsp),%rsi
  82561c:	mov    0x10(%rbx),%r14
  825620:	jmp    825494 <gpui_gpu::renderer::slots::write_prefix+0x64>
  825625:	lea    0x608694(%rip),%rdx        # e2dcc0 <anon.4f92784177f891c02fc0a44bfee03ec4.12.llvm.6639503288718533278>
  82562c:	mov    %r14,%rsi
  82562f:	call   *0x659e4b(%rip)        # e7f480 <_DYNAMIC+0x4f8>
