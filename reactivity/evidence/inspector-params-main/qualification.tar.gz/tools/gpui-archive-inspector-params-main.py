from pathlib import Path
import hashlib, io, json, shutil, subprocess, tarfile, tempfile, re
root=Path('/root/gpui-ce3'); cwd=root/'reactivity'
capture=Path('/tmp/gpui-main-inspector-params-gates')
destination=cwd/'evidence/inspector-params-main'
assert not destination.exists()
git=['git','-c',f'safe.directory={root}','-C',str(root)]
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
metadata=json.loads((capture/'metadata.json').read_text())
assert metadata['status']=='passed' and metadata['source_unchanged'] and metadata['inspector_inputs_unchanged']
assert subprocess.check_output(git+['rev-parse','HEAD'],text=True).strip()==metadata['source']
guards=json.loads((capture/'source-guard.json').read_text())
assert all(digest(root/name)==h for name,h in guards.items())
assert all(digest(Path(name))==h for name,h in metadata['executables'].items())
for name in ['gpui-rapid-pointer-native-client.py','gpui-rapid-pointer-native-loop-client.py']:
 assert (Path('/tmp')/name).read_bytes()==(cwd/'evidence/pointer-queue-main/clients'/name).read_bytes()
source_patch=cwd/'evidence/inspector-pointer/qualified-d0/source.patch'
runtime='reactivity/crates/gpui/src/runtime.rs'
proof={'source':metadata['source'],'inspector_producer':'d0bd2f4ea541cf3483c71d5e8228aea5a8a1c7cc','prior_qualified_csr_source':'8c17a763ee7a5f1d2d932d375d2c839759d8a28b','exact_producer_files':{}}
for name in ['runtime/geometry.rs','runtime/input.rs','runtime/inspector.rs','runtime/query.rs','../tests/pointer_focus.rs']:
 path='reactivity/crates/gpui/src/'+name
 if name.startswith('../'):path='reactivity/crates/gpui/tests/pointer_focus.rs'
 producer=subprocess.check_output(git+['show','d0bd2f4ea541cf3483c71d5e8228aea5a8a1c7cc:'+path])
 assert producer==(root/path).read_bytes(),path
 proof['exact_producer_files'][path]=digest(root/path)
with tempfile.TemporaryDirectory(prefix='gpui-combined-source-proof-') as folder:
 tmp=Path(folder); target=tmp/runtime;target.parent.mkdir(parents=True)
 target.write_bytes(subprocess.check_output(git+['show','8c17a763ee7a5f1d2d932d375d2c839759d8a28b:'+runtime]))
 subprocess.run(['git','apply','--include='+runtime,str(source_patch)],cwd=tmp,check=True)
 assert target.read_bytes()==(root/runtime).read_bytes()
 proof['runtime_reconstructed_from_prior_csr_plus_exact_inspector_patch']=True
 proof['runtime_sha256']=digest(target)
assert len(proof['exact_producer_files'])==5
displays={str(n):{'socket_exists':Path('/tmp/.X11-unix/X'+str(n)).exists(),'lock_exists':Path('/tmp/.X'+str(n)+'-lock').exists()} for n in range(223,228)}
assert not any(any(v.values()) for v in displays.values()),displays
summary={'source':metadata['source'],'guarded_files':len(guards),'commands':len(json.loads((capture/'results.json').read_text())),'native_executions':5,'owned_displays':displays,'limits':metadata['limits']}
for name in ['gpui-gpu-full','hummingbird-default','hummingbird-native']:
 rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (capture/(name+'.log')).read_text())
 summary[name]={'groups':len(rows),'passed':sum(int(r[0]) for r in rows),'failed':sum(int(r[1]) for r in rows),'ignored':sum(int(r[2]) for r in rows)}
assert summary['gpui-gpu-full']=={'groups':62,'passed':673,'failed':0,'ignored':30}
for name in ['hummingbird-default','hummingbird-native']:assert summary[name]['passed']==35
with tempfile.TemporaryDirectory(prefix='gpui-combined-archive-') as folder:
 stage=Path(folder)
 for file in capture.rglob('*'):
  if file.is_file() and file.name not in ['hummingbird-native-frozen','inspector-native-frozen']:
   target=stage/'qualification'/file.relative_to(capture);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(file,target)
 (stage/'tools').mkdir()
 for file in ['/tmp/gpui-main-inspector-params-gates.py','/tmp/gpui-rapid-pointer-native-client.py','/tmp/gpui-rapid-pointer-native-loop-client.py','/tmp/gpui-native-env.sh',__file__]:shutil.copyfile(file,stage/'tools'/Path(file).name)
 (stage/'source-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
 (stage/'csr-runtime-difference.patch').write_bytes(subprocess.check_output(git+['diff',proof['inspector_producer'],metadata['source'],'--',runtime]))
 (stage/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 shutil.copyfile('/tmp/gpui-main-a50-core-lines.json',stage/'core-lines.json')
 fp=stage/'fingerprints';fp.mkdir()
 for package in ['gpui','gpui_gpu','wgpu-core','wgpu']:
  for directory in (cwd/'target/debug/.fingerprint').glob(package+'-*'):
   for file in directory.glob('*.json'):shutil.copyfile(file,fp/(directory.name+'-'+file.name))
 manifest={str(p.relative_to(stage)):digest(p) for p in sorted(stage.rglob('*')) if p.is_file()}
 (stage/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
 destination.mkdir()
 archive=destination/'qualification.tar.gz'
 with tarfile.open(archive,'w:gz') as tar:
  for p in sorted(stage.rglob('*')):
   if p.is_file():
    info=tar.gettarinfo(str(p),arcname=str(p.relative_to(stage)));info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
    with p.open('rb') as content:tar.addfile(info,content)
 with tarfile.open(archive,'r:gz') as tar:
  sealed=json.load(tar.extractfile('MANIFEST.json'))
  assert len(tar.getmembers())==len(sealed)+1
  for name,h in sealed.items():assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==h,name
 summary.update(archive_sha256=digest(archive),archive_bytes=archive.stat().st_size,verified_archive_files=len(sealed))
 (destination/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 (destination/'qualification.tar.gz.sha256').write_text(digest(archive)+'  qualification.tar.gz\n')
 shutil.copyfile('/tmp/gpui-main-a50-core-lines.json',destination/'core-lines.json')
print(json.dumps(summary,indent=2))
