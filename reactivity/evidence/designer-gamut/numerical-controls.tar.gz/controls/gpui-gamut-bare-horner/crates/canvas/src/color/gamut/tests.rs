use super::*;

fn cases() -> impl Iterator<Item = (OutputProfile, f32, f32, f64)> {
    include_str!("../../../tests/fixtures/gamut_limits.csv")
        .lines()
        .skip(1)
        .map(|line| {
            let mut cells = line.split(',');
            let profile = if cells.next().unwrap() == "srgb" {
                OutputProfile::Srgb
            } else {
                OutputProfile::DisplayP3
            };
            let l = f32::from_bits(cells.next().unwrap().parse().unwrap());
            let h = f32::from_bits(cells.next().unwrap().parse().unwrap());
            (profile, l, h, cells.next().unwrap().parse().unwrap())
        })
}
fn check_limits<S: Simd>(simd: S) {
    let mut worst = 0.0_f64;
    for (profile, l, h, expected) in cases() {
        if l == 0.0 || l == 1.0 {
            continue;
        }
        let cap = limit(simd, profile, l, h).unwrap();
        let ulp = ((expected as f32).next_up() - expected as f32) as f64;
        let error = (cap as f64 - expected).abs();
        assert!(
            error <= 2.0 * ulp + 1e-12 * l as f64,
            "{profile:?} L={l} h={h}: {cap} vs {expected}, error={error}"
        );
        worst = worst.max(error / l as f64);
        assert!(in_gamut(
            Color::pack([l, cap, h, 1.0], ColorSpace::Oklch),
            profile
        ));
        let mut outside = cap;
        for _ in 0..8 {
            outside = outside.next_up();
        }
        assert!(
            !in_gamut(
                Color::pack([l, outside, h, 1.0], ColorSpace::Oklch),
                profile
            ),
            "no nearby outward witness: {profile:?} L={l} h={h} C={cap}"
        );
    }
    println!("worst |f32 cap-reference|/L={worst:e}");
}
#[test]
fn limits_match_independent_high_precision_monotone_interval_oracle() {
    check_limits(fearless_simd::Fallback::new());
    let level = fearless_simd::Level::new();
    #[cfg(target_arch = "x86_64")]
    {
        if let Some(s) = level.as_sse2() {
            check_limits(s)
        }
        if let Some(s) = level.as_sse4_2() {
            check_limits(s)
        }
        if let Some(s) = level.as_avx2() {
            check_limits(s)
        }
        if let Some(s) = level.as_avx512() {
            check_limits(s)
        }
    }
    #[cfg(target_arch = "aarch64")]
    if let Some(s) = level.as_neon() {
        check_limits(s)
    }
}
#[test]
fn author_bits_alpha_validation_and_extended_colors_have_explicit_contracts() {
    for profile in [OutputProfile::Srgb, OutputProfile::DisplayP3] {
        for channels in [
            [0.5, 0.01, 133.5, -0.0],
            [-0.0, -0.0, 270.0, 0.5],
            [1.0, 0.0, 90.0, 1.0],
        ] {
            let c = Color::oklch(channels[0], channels[1], channels[2], channels[3]).unwrap();
            assert!(c.same_authoring(c.fit_chroma(profile).unwrap()));
        }
        let c = Color::oklch(0.5, 1e6, 30.0, -0.0).unwrap();
        let fit = c.fit_chroma(profile).unwrap();
        assert!(fit.channels()[1] < c.channels()[1]);
        for index in [0, 2, 3] {
            assert_eq!(
                fit.channels()[index].to_bits(),
                c.channels()[index].to_bits()
            );
        }
        assert!(in_gamut(fit, profile));
        for c in [
            Color::rgb(255, 0, 0),
            Color::linear_srgb(4.0, -1.0, 2.0, 1.0).unwrap(),
            Color::display_p3(0.2, 0.3, 0.4, 1.0).unwrap(),
            Color::linear_display_p3(3.0, 2.0, 1.0, 1.0).unwrap(),
        ] {
            assert_eq!(c.fit_chroma(profile), Err(Error::InvalidColor));
        }
        for l in [f32::NAN, f32::INFINITY, -0.1, 1.0_f32.next_up()] {
            assert_eq!(profile.max_chroma(l, 30.0), Err(Error::InvalidColor));
        }
        for h in [f32::NAN, f32::INFINITY, f32::NEG_INFINITY] {
            assert_eq!(profile.max_chroma(0.5, h), Err(Error::InvalidColor));
        }
        for h in [0.0, 90.0, 180.0, 270.0, f32::MAX, -f32::MAX] {
            assert_eq!(profile.max_chroma(0.0, h).unwrap(), 0.0);
            assert_eq!(profile.max_chroma(1.0, h).unwrap(), 0.0);
            assert_eq!(
                profile.max_chroma(0.5, h).unwrap(),
                profile.max_chroma(0.5, wrap_hue(h as f64)).unwrap()
            );
        }
    }
    assert_eq!(
        Color::oklch(0.5, f32::MAX, 30.0, 1.0),
        Err(Error::ColorOutOfRange)
    );
}
fn polynomial_cases<S: Simd>(simd: S) {
    let p = Polynomial {
        a: [1.0, 1.0, 0.0, 0.0].simd_into(simd),
        b: [-4.0, -6.0, 0.0, 0.0].simd_into(simd),
        c: [5.0, 11.0, 1.0, 0.0].simd_into(simd),
        d: [-2.0, -6.0, -0.25, -1.0].simd_into(simd),
    };
    let r: [f64; 4] = first_exit(
        simd,
        p,
        critical_points(simd, p),
        f64x4::splat(simd, 10.0),
        96,
    )
    .into();
    assert!((r[0] - 2.0).abs() < 1e-12, "touch then exit {r:?}");
    assert!((r[1] - 1.0).abs() < 1e-12, "first of three {r:?}");
    assert!((r[2] - 0.25).abs() < 1e-12, "linear {r:?}");
    assert_eq!(r[3], f64::INFINITY);
}
#[test]
fn first_outward_root_handles_touches_multiple_roots_and_degenerate_lanes() {
    polynomial_cases(fearless_simd::Fallback::new());
    #[cfg(target_arch = "x86_64")]
    polynomial_cases(fearless_simd::Level::new().as_sse2().unwrap());
}

#[test]
fn nonbinary_rational_tangent_does_not_become_an_outward_crossing() {
    // Exact dyadic coefficients of (15t-11)^2(t-2)/256.
    let s = fearless_simd::Fallback::new();
    let p = Polynomial {
        a: f64x4::splat(s, 225.0 / 256.0),
        b: f64x4::splat(s, -780.0 / 256.0),
        c: f64x4::splat(s, 781.0 / 256.0),
        d: f64x4::splat(s, -242.0 / 256.0),
    };
    let r: [f64; 4] = first_exit(s, p, critical_points(s, p), f64x4::splat(s, 4.0), 96).into();
    assert!(
        (r[0] - 2.0).abs() < 1e-12,
        "a contact at11/15 is not the exit at2: {r:?}"
    );
}
