from pathlib import Path
import math,sys,json,struct
sys.path.insert(0,str(Path(__file__).parent));import formulations as f
rows=json.loads(Path('/tmp/gpui-gamut-reference/positive-maxima.json').read_text())['white_contact_candidates'];relevant=[];closest=None;ambiguous=[];cases=0
for row in rows:
 target=row['target'];h=row['h'];channel=row['channel'];t=row['t'];value=row['value'];lower=row['lower'];coeff=f.coefficients(1,h,target,False)
 other=min([lower]+[f.exit([a,b,c,d-value],64,lower) for i,(a,b,c,d) in enumerate(coeff) if i!=channel])
 if other<t:continue
 L=value**(-1/3);bits=f.oracle.bits(f.oracle.f32(L));r=dict(row,L_contact=L,other_cap=other);relevant.append(r)
 for lb in range(max(1,bits-2),min(f.oracle.bits(1.0),bits+3)):
  lightness=struct.unpack('<f',struct.pack('<I',lb))[0];white=lightness**-3;p=coeff[channel];gap=abs(value-white);magnitude=sum(abs(v)*t**(3-i) for i,v in enumerate(p))+white;error=128*sys.float_info.epsilon*magnitude;ratio=gap/error
  detail=dict(r,L=lightness,L_bits=lb,white=white,gap=gap,error=error,ratio=ratio)
  cases+=1
  if closest is None or ratio<closest['ratio']:closest=detail
  if ratio<=1:ambiguous.append(detail)
out=dict(hue_grid_degrees=.01,maxima_checked=len(rows),relevant_contact_count=len(relevant),neighbor_cases=cases,relevant_contacts=relevant,closest=closest,ambiguous=ambiguous)
Path('/tmp/gpui-gamut-reference/white-contacts.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(out,relevant_contacts=relevant[:3]),indent=2))
