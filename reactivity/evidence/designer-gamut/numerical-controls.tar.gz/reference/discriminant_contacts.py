"""Exact rational Sturm isolation of all lower-face contact directions.

The transform constants are the original f64 values, exactly represented as
rational numbers. For x=tan(h), q_i=u_i+v_i*x; the RGB cubics have coefficients
homogeneous in cos(h). Their discriminants are degree <=6 polynomials in x.
This locates true contacts of the algebraic transform, not floating Horner
zeros at rounded derivative points. atan and adjacent f32 probes are diagnostics,
not an interval proof for a platform's libm implementation.
"""
from fractions import Fraction as Q
from pathlib import Path
import math,json,sys,struct
sys.path.insert(0,str(Path(__file__).parent));import formulations as f

def trim(a):
 while len(a)>1 and not a[-1]:a.pop()
 return a
def add(a,b):return trim([(a[i] if i<len(a) else Q(0))+(b[i] if i<len(b) else Q(0)) for i in range(max(len(a),len(b)))])
def scale(a,b):return trim([x*b for x in a])
def mul(a,b):
 r=[Q(0)]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b):r[i+j]+=x*y
 return trim(r)
def pow(a,n):
 r=[Q(1)]
 for _ in range(n):r=mul(r,a)
 return r
def divrem(a,b):
 a=a[:]
 while len(a)>=len(b) and any(a):
  shift=len(a)-len(b);c=a[-1]/b[-1]
  for i,v in enumerate(b):a[i+shift]-=c*v
  trim(a)
 return a
def evalp(a,x):
 r=Q(0)
 for v in reversed(a):r=r*x+v
 return r
def variation(sturm,x):
 signs=[1 if v>0 else -1 for p in sturm if (v:=evalp(p,x))]
 return sum(a!=b for a,b in zip(signs,signs[1:]))
def isolate(a):
 sturm=[a,[i*a[i] for i in range(1,len(a))]]
 while any(sturm[-1]):
  r=scale(divrem(sturm[-2],sturm[-1]),-1)
  if not any(r):break
  r=scale(r,1/abs(r[-1]));sturm.append(r)
 bound=Q(1)+max(abs(v/a[-1]) for v in a[:-1]);bound=Q(math.ceil(bound))
 queue=[(-bound,bound)];roots=[]
 while queue:
  lo,hi=queue.pop();count=variation(sturm,lo)-variation(sturm,hi)
  if not count:continue
  if count==1 and hi-lo<Q(1,10**40):roots.append((lo,hi));continue
  mid=(lo+hi)/2
  if evalp(a,mid)==0:
   # This diagnostic intentionally refuses rather than assigning an endpoint
   # root twice. None of the actual six discriminants takes this path.
   raise ValueError('exact rational midpoint root requires explicit handling')
  queue.extend([(lo,mid),(mid,hi)])
 return sorted(roots),sturm,bound

def matmul(a,b):return [[sum((a[i][k]*b[k][j] for k in range(3)),Q(0)) for j in range(3)] for i in range(3)]
M={name:[[Q(x) for x in row] for row in rows] for name,rows in f.oracle.matrices.items()}
srgb=matmul(M['XYZ_TO_SRGB'],M['LMS_TO_XYZ'])
p3=matmul(M['XYZ_TO_P3'],matmul(M['SRGB_TO_XYZ'],srgb))
rows=[]
for target,weights in [('srgb',srgb),('p3',p3)]:
 for channel,w in enumerate(weights):
  q=[[M['OKLAB_TO_LMS'][i][1],M['OKLAB_TO_LMS'][i][2]] for i in range(3)]
  a=[Q(0)];b=[Q(0)];c=[Q(0)];d=[sum(w)]
  for wi,qi in zip(w,q):
   a=add(a,scale(pow(qi,3),wi));b=add(b,scale(pow(qi,2),3*wi));c=add(c,scale(qi,3*wi))
  disc=add(add(add(scale(mul(mul(mul(a,b),c),d),18),scale(mul(pow(b,3),d),-4)),mul(pow(b,2),pow(c,2))),add(scale(mul(a,pow(c,3)),-4),scale(mul(pow(a,2),pow(d,2)),-27)))
  roots,sturm,bound=isolate(disc)
  directions=[]
  for lo,hi in roots:
   x=float((lo+hi)/2)
   for h in [math.degrees(math.atan(x))%360,(math.degrees(math.atan(x))+180)%360]:
    bit=f.oracle.bits(f.oracle.f32(h));neighbors=[]
    for hb in range(max(0,bit-2),bit+3):
     hue=struct.unpack('<f',struct.pack('<I',hb))[0]
     if hue>=360:continue
     coeff=f.coefficients(1,hue,target,False);lower=min(f.exit([-aa,-bb,-cc,-dd],96) for aa,bb,cc,dd in coeff)
     p=coeff[channel];critical=[]
     for t in f.critical(p):
      if t<=0:continue
      value=f.poly(p,t);magnitude=sum(abs(v)*t**(3-i) for i,v in enumerate(p));err=128*sys.float_info.epsilon*magnitude
      critical.append(dict(t=t,value=value,error=err,ratio=abs(value)/err if err else math.inf,relevant=t<=lower*(1+1e-10),lower=lower))
     neighbors.append(dict(hue=hue,h_bits=hb,critical=critical))
    directions.append(dict(hue=h,nearest_f32=f.oracle.f32(h),neighbors=neighbors,x_interval=[str(lo),str(hi)]))
  rows.append(dict(target=target,channel=channel,degree=len(disc)-1,real_roots=len(roots),sturm_degrees=[len(p)-1 for p in sturm],cauchy_bound=str(bound),discriminant_coefficients=[str(v) for v in disc],directions=directions))
  print(target,channel,'degree',len(disc)-1,'roots',len(roots),'hues',[round(d['hue'],12) for d in directions],flush=True)
relevant=[dict(target=r['target'],channel=r['channel'],hue=n['hue'],**c) for r in rows for d in r['directions'] for n in d['neighbors'] for c in n['critical'] if c['relevant']]
out=dict(method=__doc__,rows=rows,closest_relevant=min(relevant,key=lambda c:c['ratio'],default=None),relevant_ambiguous=[c for c in relevant if c['ratio']<=1])
Path('/tmp/gpui-gamut-reference/discriminant-contacts.json').write_text(json.dumps(out,indent=2)+'\n');print('closest',out['closest_relevant']);print('ambiguous',out['relevant_ambiguous'])
