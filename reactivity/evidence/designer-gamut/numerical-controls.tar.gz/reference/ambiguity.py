from pathlib import Path
import sys,math,json
sys.path.insert(0,str(Path(__file__).parent));import formulations as f
near=[];best=(math.inf,None);count=0
for target in ['srgb','p3']:
 for hi in range(3600):
  h=f.oracle.f32(hi/10)
  coeff=f.coefficients(1,h,target,False)
  lower=min(f.exit([-a,-b,-c,-d],96) for a,b,c,d in coeff)
  for L in [.1,.5,.9,f.oracle.f32(.99999994)]:
   upper=L**-3
   cap=min([lower]+[f.exit([a,b,c,d-upper],64,lower) for a,b,c,d in coeff])
   for channel,p in enumerate(coeff):
    for t in f.critical(p):
     if not 0<t<=cap*(1+1e-10):continue
     value=f.poly(p,t)
     magnitude=sum(abs(v)*t**(3-i) for i,v in enumerate(p))
     for boundary in [0,upper]:
      gap=abs(value-boundary);error=128*sys.float_info.epsilon*(magnitude+abs(boundary));ratio=gap/error if error else math.inf
      row=dict(target=target,L=L,h=h,channel=channel,t=t,cap=cap,boundary=boundary,value=value,error=error,ratio=ratio)
      if ratio<best[0]:best=(ratio,row)
      if ratio<=1:near.append(row)
   count+=1
out=dict(cases=count,relevant_ambiguous=near,closest=best[1],definition='critical point before first global exit; conservative128eps polynomial magnitude bound')
Path('/tmp/gpui-gamut-reference/ambiguity.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
