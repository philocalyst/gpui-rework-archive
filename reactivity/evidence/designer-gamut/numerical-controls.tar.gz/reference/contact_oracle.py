from pathlib import Path
from decimal import Decimal as D, localcontext
import sys,json,struct,hashlib
sys.path.insert(0,str(Path(__file__).parent));import oracle
contacts=json.loads(Path('/tmp/gpui-gamut-reference/discriminant-contacts.json').read_text())['rows'];rows=[];seen=set()
with localcontext() as ctx:
 ctx.prec=100;oracle.M={k:[[D.from_float(v) for v in row] for row in m] for k,m in oracle.matrices.items()}
 for row in contacts:
  for direction in row['directions']:
   nearest=oracle.bits(direction['nearest_f32'])
   for hb in range(nearest-1,nearest+2):
    h=struct.unpack('<f',struct.pack('<I',hb))[0]
    for L in [oracle.f32(.1),oracle.f32(.5),oracle.f32(.9),oracle.f32(.99999994)]:
     key=(row['target'],oracle.bits(L),hb)
     if key in seen:continue
     seen.add(key);value=oracle.cap(D.from_float(L),D.from_float(h),row['target'])
     rows.append(dict(target=row['target'],L_bits=oracle.bits(L),h_bits=hb,chroma=str(value)))
out=dict(label='Post-prototype independent100-digit Decimal oracle around ALL exact-rational lower-face contact directions; same reference algorithm, not pre-edit evidence',rows=rows)
Path('/tmp/gpui-gamut-reference/contact-oracle.json').write_text(json.dumps(out,indent=2)+'\n')
print('rows',len(rows))
