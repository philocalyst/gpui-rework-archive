from pathlib import Path
import sys,math,json,struct
sys.path.insert(0,str(Path(__file__).parent));import formulations as f

def at(h,target,channel,branch):
 p=f.coefficients(1,h,target,False)[channel];r=sorted(t for t in f.critical(p) if t>0 and math.isfinite(t))
 return (r[branch],f.poly(p,r[branch])) if len(r)>branch else None
contacts=[]
for target in ['srgb','p3']:
 for channel in range(3):
  for branch in range(2):
   for L in [0.1,0.5,0.9,f.oracle.f32(.99999994)]:
    for bound in [0,L**-3]:
     previous=at(0,target,channel,branch)
     for hi in range(1,3601):
      h=hi/10;value=at(h,target,channel,branch)
      if previous and value and (previous[1]-bound)*(value[1]-bound)<0:
       lo=h-.1;high=h;vlow=previous[1]-bound
       for _ in range(48):
        mid=(lo+high)*.5;v=at(mid,target,channel,branch)
        if not v:break
        if (v[1]-bound)*vlow>0:lo=mid
        else:high=mid
       root=(lo+high)*.5;bits=f.oracle.bits(f.oracle.f32(root))
       for b in range(max(0,bits-2),bits+3):
        hue=struct.unpack('<f',struct.pack('<I',b))[0]
        if hue>=360:continue
        coeff=f.coefficients(1,hue,target,False);lower=min(f.exit([-a,-bb,-c,-d],96) for a,bb,c,d in coeff)
        cap=min([lower]+[f.exit([a,bb,c,d-L**-3],64,lower) for a,bb,c,d in coeff])
        v=at(hue,target,channel,branch)
        if not v:continue
        t,y=v;p=coeff[channel];err=128*sys.float_info.epsilon*(sum(abs(a)*t**(3-i) for i,a in enumerate(p))+abs(bound))
        contacts.append(dict(target=target,L=L,hue=hue,h_bits=b,channel=channel,branch=branch,boundary=bound,critical_t=t,global_cap_t=cap,relevant=t<=cap*(1+1e-10),ratio=abs(y-bound)/err if err else math.inf,h_root=root))
      previous=value
out=dict(contacts=contacts,relevant_ambiguous=[c for c in contacts if c['relevant'] and c['ratio']<=1],closest_relevant=min((c for c in contacts if c['relevant']),key=lambda c:c['ratio'],default=None))
Path('/tmp/gpui-gamut-reference/critical-neighbors.json').write_text(json.dumps(out,indent=2)+'\n');print('contacts',len(contacts),'ambiguous',len(out['relevant_ambiguous']));print(out['closest_relevant'])
