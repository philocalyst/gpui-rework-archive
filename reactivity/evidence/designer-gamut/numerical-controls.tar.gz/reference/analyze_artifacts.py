from pathlib import Path
import re,json,hashlib
variants={v:Path('/tmp/gpui-gamut-'+v+'-frozen') for v in ['consumer','consumer-fallback','floor','original','bare','expansion']}
variants.update({v:Path('/tmp/gpui-gamut-'+v+'-frozen') for v in ['final-native','final-fallback','final-floor','original-common','bare-common','expansion-common'] if Path('/tmp/gpui-gamut-'+v+'-frozen').exists()})
rows=[]
for name,binary in variants.items():
 prefix=Path('/tmp/gpui-gamut-'+name)
 sections={}
 for line in prefix.with_suffix('.sections').read_text().splitlines():
  cells=line.split()
  if len(cells)==3 and cells[0].startswith('.') and cells[1].isdigit():sections[cells[0]]=int(cells[1])
 bodies={};current=None
 for line in prefix.with_suffix('.asm').read_text().splitlines():
  if m:=re.fullmatch(r'[0-9a-f]+ <(.*)>:',line):current=m[1];bodies[current]=[]
  elif current:bodies[current].append(line)
 relevant={k:v for k,v in bodies.items() if 'color::gamut::' in k or ('color::OutputProfile' in k and 'max_chroma' in k) or ('color::Color' in k and 'fit_chroma' in k)}
 functions=[]
 for fname,body in relevant.items():
  instructions=[parts[-1].strip() for line in body if len(parts:=line.split('\t'))>=3 and re.match(r'\s*[0-9a-f]+:',line)]
  mnemonics=[i.split()[0] for i in instructions if i.split()]
  packed={m:mnemonics.count(m) for m in set(mnemonics) if m.endswith('pd') or m.startswith(('vfm','vfnm')) or m=='cpuid'}
  prologue=[i for i in instructions[:20] if re.search(r'\b(push|sub|and)\b',i)]
  functions.append(dict(symbol=fname,instruction_count=len(instructions),packed_instructions=packed,prologue=prologue))
 Path('/tmp/gpui-gamut-'+name+'.gamut.asm').write_text(''.join(k+':\n'+'\n'.join(v)+'\n' for k,v in relevant.items()))
 rows.append(dict(variant=name,binary_path=str(binary),sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),file_bytes=binary.stat().st_size,sections=sections,functions=functions))
Path('/tmp/gpui-gamut-artifact-analysis.json').write_text(json.dumps(rows,indent=2)+'\n')
for r in rows:
 print(r['variant'],r['file_bytes'],r['sections']['.text'],r['sections']['.rodata'])
 for f in r['functions']:
  if 'first_exit' in f['symbol'] or 'limit::' in f['symbol'] or 'exact_endpoint' in f['symbol']:print(' ',f['symbol'][:95],f['prologue'])
