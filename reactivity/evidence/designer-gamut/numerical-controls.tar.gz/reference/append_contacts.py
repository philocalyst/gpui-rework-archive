from pathlib import Path
import json
p=Path('/root/gpui-designer-gamut/reactivity/crates/canvas/tests/fixtures/gamut_limits.csv');rows=json.loads(Path('/tmp/gpui-gamut-reference/oracle.json').read_text())['rows']+json.loads(Path('/tmp/gpui-gamut-reference/contact-oracle.json').read_text())['rows'];p.write_text('profile,L_bits,h_bits,chroma\n'+''.join(f"{r['target']},{r['L_bits']},{r['h_bits']},{r['chroma']}\n" for r in rows))
p=Path('/root/gpui-designer-gamut/reactivity/crates/canvas/src/color/gamut/tests.rs');s=p.read_text();needle='''    assert_eq!(
        Color::oklch(0.5, f32::MAX, 30.0, 1.0),''';s=s.replace(needle,'''    // This real sRGB ray leaves red<0 and re-enters before green<0. Fitting
    // preserves a valid author beyond the first connected-neutral boundary.
    let reentry = Color::oklch(0.1, 0.067, 264.2, -0.0).unwrap();
    assert!(reentry.channels()[1] > OutputProfile::Srgb.max_chroma(0.1, 264.2).unwrap());
    assert!(in_gamut(reentry, OutputProfile::Srgb));
    assert!(reentry.same_authoring(reentry.fit_chroma(OutputProfile::Srgb).unwrap()));
    assert_eq!(
        Color::oklch(0.5, f32::MAX, 30.0, 1.0),''');p.write_text(s)
p=Path('/root/gpui-designer-gamut/reactivity/crates/canvas/src/color/gamut.rs');s=p.read_text().replace('the limit is0.','the limit is 0.').replace('ordinary finite f64 values;32eps','ordinary finite f64 values; 32ε');p.write_text(s)
