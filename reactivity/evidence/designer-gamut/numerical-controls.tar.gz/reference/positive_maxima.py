from pathlib import Path
import math,sys,json
sys.path.insert(0,str(Path(__file__).parent));import formulations as f
rows=[];best=None;counts={}
for target in ['srgb','p3']:
 count=0;positive=0;before=0;minimum=math.inf
 for hi in range(36000):
  h=f.oracle.f32(hi/100)
  coeff=f.coefficients(1,h,target,False)
  # First lower-face departure is independent of L.
  lower=min(f.exit([-a,-b,-c,-d],96) for a,b,c,d in coeff)
  for channel,p in enumerate(coeff):
   for t in f.critical(p):
    if not 0<t<=lower:continue
    count+=1
    curvature=6*p[0]*t+2*p[1]
    if curvature<0:
     before+=1;y=f.poly(p,t)
     if y>=1:
      positive+=1
      row=dict(target=target,h=h,channel=channel,t=t,value=y,lower=lower)
      rows.append(row)
     if y<minimum:minimum=y
 counts[target]=dict(critical_points_before_lower_exit=count,local_maxima_before_lower_exit=before,maxima_at_or_above_neutral=positive,min_maximum=minimum)
out=dict(cases=72000,counts=counts,white_contact_candidates=rows)
Path('/tmp/gpui-gamut-reference/positive-maxima.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(out,white_contact_candidates=rows[:3]),indent=2))
