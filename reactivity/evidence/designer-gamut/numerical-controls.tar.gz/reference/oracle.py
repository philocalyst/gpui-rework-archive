from pathlib import Path
from decimal import Decimal as D, localcontext
import struct,re,json,hashlib,math
ROOT=Path('/root/gpui-designer-gamut/reactivity'); SRC=ROOT/'crates/canvas/src/color.rs'; text=SRC.read_text()
NAMES=['OKLAB_TO_LMS','LMS_TO_XYZ','XYZ_TO_SRGB','SRGB_TO_XYZ','XYZ_TO_P3']
matrices={}
for name in NAMES:
 s=text.index('const '+name+':'); s=text.index('= [',s)+2; end=text.index('\n];',s)+2
 matrices[name]=eval(text[s:end].replace('_',''),{'__builtins__':{}})
PI=D('3.14159265358979323846264338327950288419716939937510582097494459230781640628620899862803482534211706798214808651')
def mat(m,v):return [sum((a*b for a,b in zip(row,v)),D(0)) for row in m]
def trig(deg):
 x=deg*PI/180
 if x>PI:x-=2*PI
 ss=x;cc=D(1);s=x;c=D(1)
 for n in range(1,120):
  s*= -x*x/((2*n)*(2*n+1));c*= -x*x/((2*n-1)*(2*n));ss+=s;cc+=c
 return ss,cc
def poly(p,x):
 y=D(0)
 for a in p:y=y*x+a
 return y
def critical(p):
 a,b,c=p[0]*3,p[1]*2,p[2]
 if a==0:return [-c/b] if b else []
 disc=b*b-4*a*c
 if disc<0:return []
 r=disc.sqrt();return [(-b-r)/(2*a),(-b+r)/(2*a)]
def first_exit(p):
 # Allowed side is <=0. Split at all positive derivative roots; pure bisection.
 q=list(p)
 while len(q)>1 and q[0]==0:q.pop(0)
 if len(q)==1:return D(0) if q[0]>0 else D('Infinity')
 bound=1+max(abs(a/q[0]) for a in q[1:])
 edges=[D(0)]+sorted(set(x for x in critical(p) if 0<x<bound))+[bound]
 for lo,hi in zip(edges,edges[1:]):
  if poly(p,lo)>0:return lo
  if poly(p,hi)<=0:continue
  if poly(p,lo)==0:return lo
  for _ in range(300):
   middle=(lo+hi)/2
   if poly(p,middle)>0:hi=middle
   else:lo=middle
  return (lo+hi)/2
 return D('Infinity')
def cap(L,h,target):
 if L==0 or L==1:return D(0)
 si,co=trig(h);q=mat(M['OKLAB_TO_LMS'],[D(0),co,si])
 def rgb(lms):
  v=mat(M['XYZ_TO_SRGB'],mat(M['LMS_TO_XYZ'],lms))
  return mat(M['XYZ_TO_P3'],mat(M['SRGB_TO_XYZ'],v)) if target=='p3' else v
 coeff=list(zip(rgb([v**3 for v in q]),rgb([3*v*v for v in q]),rgb([3*v for v in q]),rgb([D(1)]*3)))
 upper=1/(L**3); exits=[]
 for a,b,c,d in coeff:
  exits.append(first_exit([-a,-b,-c,-d]));exits.append(first_exit([a,b,c,d-upper]))
 return min(exits)*L

def f32(x):return struct.unpack('<f',struct.pack('<f',x))[0]
def bits(x):return struct.unpack('<I',struct.pack('<f',x))[0]
if __name__=='__main__':
 with localcontext() as ctx:
  ctx.prec=100
  M={k:[[D.from_float(v) for v in row] for row in m] for k,m in matrices.items()}
  ls=[0.0,struct.unpack('<f',struct.pack('<I',1))[0],f32(1e-20),f32(.001),f32(.01),f32(.1),f32(.5),f32(.9),f32(.99),struct.unpack('<f',struct.pack('<I',0x3f7fffff))[0],1.0]
  hs=sorted(set([f32(h) for h in range(0,360,10)]+[f32(89.99999),f32(90.00001),f32(179.99998),f32(269.99997),f32(359.99997)]))
  rows=[]
  for target in ['srgb','p3']:
   for L in ls:
    for h in hs:
     value=cap(D.from_float(L),D.from_float(h),target)
     rows.append(dict(target=target,L_bits=bits(L),h_bits=bits(h),chroma=str(value)))
  out={'label':'Independent100-digit Decimal monotone-interval oracle; not old production behavior or a CSS mapper','source_sha256':hashlib.sha256(SRC.read_bytes()).hexdigest(),'matrix_f64_hex':{k:[[v.hex() for v in row] for row in m] for k,m in matrices.items()},'rows':rows}
  Path('/tmp/gpui-gamut-reference/oracle.json').write_text(json.dumps(out,indent=2)+'\n')
  print('oracle fixtures',len(rows))
