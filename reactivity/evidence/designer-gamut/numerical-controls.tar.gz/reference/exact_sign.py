from pathlib import Path
import json,sys,math
sys.path.insert(0,str(Path(__file__).parent));import formulations as f
SPLITTER=134217729.0

def two_sum(a,b):
 total=a+b;part=total-a
 return total,(a-(total-part))+(b-part)
def two_product(a,b):
 product=a*b
 split=a*SPLITTER;ahi=split-(split-a);alo=a-ahi
 split=b*SPLITTER;bhi=split-(split-b);blo=b-bhi
 error=((ahi*bhi-product)+ahi*blo+alo*bhi)+alo*blo
 return product,error

def grow(expansion,value):
 out=[]
 for term in expansion:
  value,error=two_sum(value,term);out.append(error)
 out.append(value)
 return out

def exact_evaluate(p,t):
 expansion=[p[0]]
 for coefficient in p[1:]:
  previous=expansion;expansion=[]
  for term in previous:
   high,low=two_product(term,t)
   expansion=grow(expansion,low)
   expansion=grow(expansion,high)
  expansion=grow(expansion,coefficient)
 for term in reversed(expansion):
  if term:return math.copysign(1,term)
 return 0.0

if __name__=='__main__':
 d=json.loads(Path('/tmp/gpui-gamut-reference/tangent-probe.json').read_text());rows=[]
 for row in d['failures']:
  p=row['coefficients'];tc=min(f.critical(p))
  rows.append(dict(row,ordinary=f.poly(p,tc),exact_sign=exact_evaluate(p,tc)))
 assert all(row['exact_sign']<=0 for row in rows)
 Path('/tmp/gpui-gamut-reference/exact-sign-controls.json').write_text(json.dumps(rows,indent=2)+'\n');print('corrected all',len(rows),'false outward signs')
