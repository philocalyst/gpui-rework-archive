from pathlib import Path
p=Path('/root/gpui-designer-gamut/reactivity/crates/canvas/src/color/gamut/tests.rs');s=p.read_text();s=s.replace('let mut worst = 0.0_f64;', 'let mut worst_ulps = 0.0_f64;\n    let mut worst_normal_scaled = 0.0_f64;');s=s.replace('''        worst = worst.max(error / l as f64);''','''        worst_ulps = worst_ulps.max(error / ulp);
        if l.is_normal() {
            worst_normal_scaled = worst_normal_scaled.max(error / l as f64);
        }
        assert_eq!(cap.to_bits(), limit(fearless_simd::Fallback::new(), profile, l, h).unwrap().to_bits());''');s=s.replace('println!("worst |f32 cap-reference|/L={worst:e}");','println!("worst error in f32ULPs={worst_ulps:e}; normal-L scaled error={worst_normal_scaled:e}");');s=s.replace('''    let r: [f64; 4] = first_exit(''','''    let [r, unresolved] = first_exit(''',1);s=s.replace('''    )
    .into();
    assert!((r[0] - 2.0).abs() < 1e-12, "touch then exit {r:?}");''','''    );
    let r: [f64; 4] = r.into();
    let unresolved: [f64; 4] = unresolved.into();
    assert_eq!(r[0], f64::INFINITY);
    assert!((unresolved[0] - 1.0).abs() < 1e-12, "unresolved touch {unresolved:?}");''');s=s.replace('fn first_outward_root_handles_touches_multiple_roots_and_degenerate_lanes()', 'fn first_outward_roots_and_unresolved_contacts_keep_separate_authority()');s=s.replace('fn nonbinary_rational_tangent_does_not_become_an_outward_crossing()', 'fn nonbinary_rational_tangent_blocks_later_roots_instead_of_guessing_a_sign()');s=s.replace('''    let r: [f64; 4] = first_exit(s, p, critical_points(s, p), f64x4::splat(s, 4.0), 96).into();
    assert!(
        (r[0] - 2.0).abs() < 1e-12,
        "a contact at11/15 is not the exit at2: {r:?}"
    );''','''    let [r, unresolved] = first_exit(s, p, critical_points(s, p), f64x4::splat(s, 4.0), 96);
    let r: [f64; 4] = r.into();
    let unresolved: [f64; 4] = unresolved.into();
    assert_eq!(r[0], f64::INFINITY);
    assert!((unresolved[0] - 11.0 / 15.0).abs() < 1e-12);
''');p.write_text(s)
p=Path('/root/gpui-designer-gamut/reactivity/crates/canvas/src/color/gamut.rs');s=p.read_text().replace('critical_radius(simd, p, turn)', 'critical_radius(simd, p, is_turn.select(turn, infinity))');p.write_text(s)
