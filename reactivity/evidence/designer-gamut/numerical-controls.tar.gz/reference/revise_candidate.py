from pathlib import Path
p=Path('/root/gpui-designer-gamut/reactivity/crates/canvas/src/color/gamut.rs')
s=p.read_text();a=s.index('#[inline(always)]\nfn two_sum');b=s.index('// Allowed is polynomial',a)
s=s[:a]+'''// Enclose each simple positive derivative root by endpoints with separated,
// opposite derivative signs. Coefficients in this fixed profile family are
// ordinary finite f64 values;32eps covers the short non-FMA Horner evaluation.
// Failure to isolate is carried as uncertainty, never guessed into a crossing.
#[simd]
fn critical_radius<S: Simd>(simd: S, p: Polynomial<S>, t: f64x4<S>) -> f64x4<S> {
    let zero = f64x4::splat(simd, 0.0);
    let infinity = f64x4::splat(simd, f64::INFINITY);
    let present = t.simd_lt(f64::INFINITY);
    let t = present.select(t, zero);
    let mut radius = (1.0 + t.abs()) * (32.0 * f64::EPSILON);
    let mut result = infinity;
    for _ in 0..32 {
        let low = (t - radius).max(0.0);
        let high = t + radius;
        let (left, left_error) = derivative(p, low);
        let (right, right_error) = derivative(p, high);
        let separated = (left.simd_lt(-left_error) & right.simd_gt(right_error))
            | (left.simd_gt(left_error) & right.simd_lt(-right_error));
        let found = separated & present & result.simd_eq(f64::INFINITY);
        result = found.select(radius, result);
        if (present & result.simd_eq(f64::INFINITY)).to_bitmask() & 7 == 0 {
            break;
        }
        radius = radius * 2.0;
    }
    present.select(result, zero)
}
#[inline(always)]
fn derivative<S: Simd>(p: Polynomial<S>, t: f64x4<S>) -> (f64x4<S>, f64x4<S>) {
    let value = (p.a * 3.0 * t + p.b * 2.0) * t + p.c;
    let error = ((p.a.abs() * 3.0 * t + p.b.abs() * 2.0) * t + p.c.abs())
        * (32.0 * f64::EPSILON);
    (value, error)
}
#[inline(always)]
fn endpoint_error<S: Simd>(p: Polynomial<S>, t: f64x4<S>, radius: f64x4<S>) -> f64x4<S> {
    let magnitude = ((p.a.abs() * t + p.b.abs()) * t + p.c.abs()) * t + p.d.abs();
    let (slope, slope_error) = derivative(p, t);
    magnitude * (32.0 * f64::EPSILON)
        + (slope.abs() + slope_error) * radius
        + ((p.a.abs() * 3.0 * t + p.b.abs()) + p.a.abs() * radius) * radius * radius
}

''' +s[b:]
s=s.replace('''    iterations: usize,
) -> f64x4<S> {''','''    iterations: usize,
) -> [f64x4<S>; 2] {''')
s=s.replace('''    let mut start = f64x4::splat(simd, 0.0);
    for end in [turns[0].min(bound), turns[1].min(bound), bound] {
        let active = result.simd_eq(f64::INFINITY) & endpoint_value(simd, p, end).simd_gt(0.0);''','''    let zero = f64x4::splat(simd, 0.0);
    let mut unresolved = infinity;
    let mut start = zero;
    for turn in [turns[0], turns[1], infinity] {
        let end = turn.min(bound);
        let is_turn = turn.simd_lt(bound);
        let radius = is_turn.select(critical_radius(simd, p, turn), zero);
        let finite_radius = radius.simd_lt(f64::INFINITY);
        let safe_radius = finite_radius.select(radius, zero);
        let value = p.evaluate(end);
        let error = endpoint_error(p, end, safe_radius);
        let uncertain = !finite_radius | value.abs().simd_le(error);
        let pending = result.simd_eq(f64::INFINITY) & unresolved.simd_eq(f64::INFINITY);
        let earliest = finite_radius.select((end - safe_radius).max(0.0), zero);
        unresolved = (pending & uncertain).select(earliest, unresolved);
        let active = pending & !uncertain & value.simd_gt(error);''')
s=s.replace('''    result
}

#[simd]
fn limit''','''    [result, unresolved]
}

#[simd]
fn limit''')
s=s.replace('''    let lower: [f64; 4] = first_exit(simd, p.lower(), turns, bound, 96).into();
    let lower = lower[..3].iter().copied().fold(f64::INFINITY, f64::min);''','''    let [lower, lower_unresolved] = first_exit(simd, p.lower(), turns, bound, 96);
    let lower: [f64; 4] = lower.into();
    let lower = lower[..3].iter().copied().fold(f64::INFINITY, f64::min);''')
s=s.replace('''    let upper: [f64; 4] = first_exit(''','''    let [upper, upper_unresolved] = first_exit(''')
s=s.replace('''    )
    .into();
    let limit = upper[..3].iter().copied().fold(lower, f64::min) * l;''','''    );
    let upper: [f64; 4] = upper.into();
    let cap = upper[..3].iter().copied().fold(lower, f64::min);
    let unresolved: [f64; 4] = lower_unresolved.min(upper_unresolved).into();
    if unresolved[..3].iter().any(|&t| t < cap) {
        return Err(Error::ColorOutOfRange);
    }
    let limit = cap * l;''')
s=s.replace('''    /// The result is checked through the production conversion and moved inward
''','''    /// Computation uses f64 coefficients and bounded interval solves. Numerically
    /// unresolved contacts or failure of the final membership check return
    /// `Error::ColorOutOfRange`; no later root is substituted as a maximum.
    /// The result is checked through the production conversion and moved inward
''')
s=s.replace('''// outward endpoint brackets the first exit. A contact followed by inward motion
// is skipped, including an exact zero at a critical point. No whole-gamut
// monotonicity is assumed. All RGB lanes share the same bounded bisection.''','''// outward endpoint brackets the first exit. Unresolved contacts block that
// lane's later answers; their earliest possible t is returned separately.
// Admission compares that uncertainty with other independently resolved faces.
// No whole-gamut monotonicity is assumed. All RGB lanes share the same solve.''')
p.write_text(s)
