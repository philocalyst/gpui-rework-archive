import json,struct,math,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent));import oracle

def mat(m,v):return [row[0]*v[0]+row[1]*v[1]+row[2]*v[2] for row in m]
def poly(p,x):return ((p[0]*x+p[1])*x+p[2])*x+p[3]
def critical(p):
 a,b,c=3*p[0],2*p[1],p[2]
 if a==0:return [-c/b] if b else []
 disc=b*b-4*a*c
 if disc<0:return []
 q=-.5*(b+math.copysign(math.sqrt(disc),b))
 return [q/a,c/q] if q else [0.0]
def exit(p,iterations,end=None):
 if p[3]>0:return 0.0
 q=list(p)
 while len(q)>1 and q[0]==0:q.pop(0)
 if len(q)==1:return math.inf
 bound=1+max(abs(v/q[0]) for v in q[1:]) if end is None else end
 edges=[0]+sorted(set(v for v in critical(p) if 0<v<bound))+[bound]
 for low,high in zip(edges,edges[1:]):
  if poly(p,high)<=0:continue
  for _ in range(iterations):
   middle=(low+high)*.5
   if poly(p,middle)>0:high=middle
   else:low=middle
  return low
 return math.inf
def coefficients(L,h,target,direct):
 sn,cs=math.sin(math.radians(h)),math.cos(math.radians(h));q=mat(oracle.matrices['OKLAB_TO_LMS'],[0,cs,sn])
 def rgb(v):
  v=mat(oracle.matrices['XYZ_TO_SRGB'],mat(oracle.matrices['LMS_TO_XYZ'],v))
  return mat(oracle.matrices['XYZ_TO_P3'],mat(oracle.matrices['SRGB_TO_XYZ'],v)) if target=='p3' else v
 coeff=list(zip(rgb([v*v*v for v in q]),rgb([3*v*v for v in q]),rgb([3*v for v in q]),rgb([1]*3)))
 if direct:coeff=[(a,L*b,L*L*c,L*L*L*d) for a,b,c,d in coeff]
 return coeff

def solve(L,h,target,kind):
 if L==0 or L==1:return 0.0
 direct=kind.startswith('direct');coeff=coefficients(L,h,target,direct)
 if direct:
  return min(min(exit([-a,-b,-c,-d],64),exit([a,b,c,d-1],64)) for a,b,c,d in coeff)
 lower=min(exit([-a,-b,-c,-d],96) for a,b,c,d in coeff)
 cap=min([lower]+[exit([a,b,c,d-L**-3],64,lower) for a,b,c,d in coeff])
 return cap*L
if __name__=='__main__':
 data=json.loads(Path('/tmp/gpui-gamut-reference/oracle.json').read_text());rows=[]
 for kind in ['direct-C64','normalized-lower96-upper64']:
  worst=(0,None);failed=0;failed_rows=[]
  for r in data['rows']:
   L,h=[struct.unpack('<f',struct.pack('<I',r[k]))[0] for k in ['L_bits','h_bits']]
   expected=float(r['chroma']);actual=solve(L,h,r['target'],kind)
   tolerance=1e-12*L+2*max(oracle.f32(expected)-oracle.f32(max(0,expected)*(1-2**-23)),struct.unpack('<f',struct.pack('<I',1))[0])
   error=abs(actual-expected)
   if error>tolerance:
    failed+=1;failed_rows.append(dict(r,actual=actual,expected=expected,tolerance=tolerance))
   if error/(L or 1)>worst[0]:worst=(error/(L or 1),dict(r,actual=actual,expected=expected,tolerance=tolerance))
  rows.append(dict(formulation=kind,failures=failed,worst_scaled_error=worst[0],worst=worst[1],failed_rows=failed_rows))
 Path('/tmp/gpui-gamut-reference/formulations.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
