from pathlib import Path
import sys,math,json
sys.path.insert(0,str(Path(__file__).parent));import formulations as f
failures=[];tested=0
for q in range(2,200):
 for p in range(1,q):
  scale=2**math.ceil(math.log2(q*q))
  coeff=[q*q/scale,(-2*p*q-2*q*q)/scale,(p*p+4*p*q)/scale,-2*p*p/scale]
  actual=f.exit(coeff,96,4);tested+=1
  if abs(actual-2)>1e-10:
   failures.append(dict(p=p,q=q,coefficients=coeff,actual=actual,expected=2.0,critical=[(x,f.poly(coeff,x)) for x in f.critical(coeff)]))
   if len(failures)>=12:break
 if len(failures)>=12:break
Path('/tmp/gpui-gamut-reference/tangent-probe.json').write_text(json.dumps(dict(tested=tested,failures=failures),indent=2)+'\n');print('tested',tested,'failures',len(failures));print(failures[:2])
