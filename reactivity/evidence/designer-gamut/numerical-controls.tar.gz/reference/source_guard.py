from pathlib import Path
import hashlib,json,sys
root=Path('/root/gpui-designer-gamut/reactivity')
files=['Cargo.toml','Cargo.lock','crates/canvas/Cargo.toml','crates/canvas/src/color.rs','crates/canvas/src/color/gamut.rs','crates/canvas/src/color/gamut/tests.rs','crates/canvas/tests/fixtures/gamut_limits.csv']
value={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for f in files if (p:=root/f).is_file()}
p=Path(sys.argv[1])
if len(sys.argv)>2:assert value==json.loads(p.read_text()),'SOURCE GUARD FAILED'
else:p.write_text(json.dumps(value,indent=2)+'\n')
