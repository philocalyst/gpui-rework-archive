<gpui_canvas::color::OutputProfile>::max_chroma:
   1f120:	66 0f 7e c1          	movd   %xmm0,%ecx
   1f124:	81 e1 ff ff ff 7f    	and    $0x7fffffff,%ecx
   1f12a:	b8 0d 00 00 00       	mov    $0xd,%eax
   1f12f:	81 f9 ff ff 7f 7f    	cmp    $0x7f7fffff,%ecx
   1f135:	7f 38                	jg     1f16f <<gpui_canvas::color::OutputProfile>::max_chroma+0x4f>
   1f137:	0f 57 e4             	xorps  %xmm4,%xmm4
   1f13a:	0f 57 d2             	xorps  %xmm2,%xmm2
   1f13d:	f3 0f c2 d0 06       	cmpnless %xmm0,%xmm2
   1f142:	0f 28 d8             	movaps %xmm0,%xmm3
   1f145:	f3 0f c2 1d ba 64 fe 	cmpnless -0x19b46(%rip),%xmm3        # 5608 <std::thread::current::id::ID+0x4990>
   1f14c:	ff 06 
   1f14e:	0f 56 da             	orps   %xmm2,%xmm3
   1f151:	66 0f 7e d9          	movd   %xmm3,%ecx
   1f155:	66 0f 7e ca          	movd   %xmm1,%edx
   1f159:	81 e2 ff ff ff 7f    	and    $0x7fffffff,%edx
   1f15f:	81 fa 00 00 80 7f    	cmp    $0x7f800000,%edx
   1f165:	0f 9d c2             	setge  %dl
   1f168:	08 ca                	or     %cl,%dl
   1f16a:	f6 c2 01             	test   $0x1,%dl
   1f16d:	74 01                	je     1f170 <<gpui_canvas::color::OutputProfile>::max_chroma+0x50>
   1f16f:	c3                   	ret
   1f170:	0f 2e c4             	ucomiss %xmm4,%xmm0
   1f173:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   1f178:	75 02                	jne    1f17c <<gpui_canvas::color::OutputProfile>::max_chroma+0x5c>
   1f17a:	7b f3                	jnp    1f16f <<gpui_canvas::color::OutputProfile>::max_chroma+0x4f>
   1f17c:	0f 2e 05 85 64 fe ff 	ucomiss -0x19b7b(%rip),%xmm0        # 5608 <std::thread::current::id::ID+0x4990>
   1f183:	75 02                	jne    1f187 <<gpui_canvas::color::OutputProfile>::max_chroma+0x67>
   1f185:	7b e8                	jnp    1f16f <<gpui_canvas::color::OutputProfile>::max_chroma+0x4f>
   1f187:	53                   	push   %rbx
   1f188:	48 83 ec 10          	sub    $0x10,%rsp
   1f18c:	f3 0f 11 44 24 0c    	movss  %xmm0,0xc(%rsp)
   1f192:	89 fb                	mov    %edi,%ebx
   1f194:	0f 57 c0             	xorps  %xmm0,%xmm0
   1f197:	f3 0f 5a c1          	cvtss2sd %xmm1,%xmm0
   1f19b:	f2 0f 10 0d bd 7e fe 	movsd  -0x18143(%rip),%xmm1        # 7060 <std::thread::current::id::ID+0x63e8>
   1f1a2:	ff 
   1f1a3:	ff 15 47 4c 04 00    	call   *0x44c47(%rip)        # 63df0 <_DYNAMIC+0x368>
   1f1a9:	f2 0f 10 1d af 7e fe 	movsd  -0x18151(%rip),%xmm3        # 7060 <std::thread::current::id::ID+0x63e8>
   1f1b0:	ff 
   1f1b1:	f2 0f 58 d8          	addsd  %xmm0,%xmm3
   1f1b5:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   1f1b9:	66 0f 28 d0          	movapd %xmm0,%xmm2
   1f1bd:	f2 0f c2 d1 01       	cmpltsd %xmm1,%xmm2
   1f1c2:	66 0f 54 da          	andpd  %xmm2,%xmm3
   1f1c6:	66 0f 55 d0          	andnpd %xmm0,%xmm2
   1f1ca:	66 0f 56 d3          	orpd   %xmm3,%xmm2
   1f1ce:	66 0f 2e 15 0a 7e fe 	ucomisd -0x181f6(%rip),%xmm2        # 6fe0 <std::thread::current::id::ID+0x6368>
   1f1d5:	ff 
   1f1d6:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   1f1da:	73 0f                	jae    1f1eb <<gpui_canvas::color::OutputProfile>::max_chroma+0xcb>
   1f1dc:	0f 57 c0             	xorps  %xmm0,%xmm0
   1f1df:	f2 0f 5a c2          	cvtsd2ss %xmm2,%xmm0
   1f1e3:	f3 0f c2 c8 00       	cmpeqss %xmm0,%xmm1
   1f1e8:	0f 55 c8             	andnps %xmm0,%xmm1
   1f1eb:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   1f1f1:	0f b6 fb             	movzbl %bl,%edi
   1f1f4:	48 83 c4 10          	add    $0x10,%rsp
   1f1f8:	5b                   	pop    %rbx
   1f1f9:	e9 52 1a 00 00       	jmp    20c50 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>>
   1f1fe:	cc                   	int3
   1f1ff:	cc                   	int3

<gpui_canvas::color::Color>::fit_chroma:
   1f570:	55                   	push   %rbp
   1f571:	41 57                	push   %r15
   1f573:	41 56                	push   %r14
   1f575:	41 54                	push   %r12
   1f577:	53                   	push   %rbx
   1f578:	48 83 ec 30          	sub    $0x30,%rsp
   1f57c:	48 89 fb             	mov    %rdi,%rbx
   1f57f:	44 8b 66 08          	mov    0x8(%rsi),%r12d
   1f583:	44 8b 7e 0c          	mov    0xc(%rsi),%r15d
   1f587:	41 81 ff 00 00 00 c0 	cmp    $0xc0000000,%r15d
   1f58e:	0f 92 c0             	setb   %al
   1f591:	45 85 e4             	test   %r12d,%r12d
   1f594:	0f 99 c1             	setns  %cl
   1f597:	08 c1                	or     %al,%cl
   1f599:	80 f9 01             	cmp    $0x1,%cl
   1f59c:	75 09                	jne    1f5a7 <<gpui_canvas::color::Color>::fit_chroma+0x37>
   1f59e:	c7 43 04 0d 00 00 00 	movl   $0xd,0x4(%rbx)
   1f5a5:	eb 4a                	jmp    1f5f1 <<gpui_canvas::color::Color>::fit_chroma+0x81>
   1f5a7:	49 89 f6             	mov    %rsi,%r14
   1f5aa:	0f 10 06             	movups (%rsi),%xmm0
   1f5ad:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   1f5b2:	0f b6 ea             	movzbl %dl,%ebp
   1f5b5:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   1f5ba:	89 ee                	mov    %ebp,%esi
   1f5bc:	e8 2f 24 00 00       	call   219f0 <gpui_canvas::color::gamut::in_gamut>
   1f5c1:	84 c0                	test   %al,%al
   1f5c3:	74 0c                	je     1f5d1 <<gpui_canvas::color::Color>::fit_chroma+0x61>
   1f5c5:	41 0f 10 06          	movups (%r14),%xmm0
   1f5c9:	0f 11 43 04          	movups %xmm0,0x4(%rbx)
   1f5cd:	31 c0                	xor    %eax,%eax
   1f5cf:	eb 25                	jmp    1f5f6 <<gpui_canvas::color::Color>::fit_chroma+0x86>
   1f5d1:	41 8b 16             	mov    (%r14),%edx
   1f5d4:	89 d6                	mov    %edx,%esi
   1f5d6:	81 e6 ff ff ff 7f    	and    $0x7fffffff,%esi
   1f5dc:	b8 0d 00 00 00       	mov    $0xd,%eax
   1f5e1:	31 c9                	xor    %ecx,%ecx
   1f5e3:	81 fe ff ff 7f 7f    	cmp    $0x7f7fffff,%esi
   1f5e9:	7e 1d                	jle    1f608 <<gpui_canvas::color::Color>::fit_chroma+0x98>
   1f5eb:	89 43 04             	mov    %eax,0x4(%rbx)
   1f5ee:	89 4b 08             	mov    %ecx,0x8(%rbx)
   1f5f1:	b8 01 00 00 00       	mov    $0x1,%eax
   1f5f6:	89 03                	mov    %eax,(%rbx)
   1f5f8:	48 89 d8             	mov    %rbx,%rax
   1f5fb:	48 83 c4 30          	add    $0x30,%rsp
   1f5ff:	5b                   	pop    %rbx
   1f600:	41 5c                	pop    %r12
   1f602:	41 5e                	pop    %r14
   1f604:	41 5f                	pop    %r15
   1f606:	5d                   	pop    %rbp
   1f607:	c3                   	ret
   1f608:	44 89 e6             	mov    %r12d,%esi
   1f60b:	81 e6 ff ff ff 7f    	and    $0x7fffffff,%esi
   1f611:	66 0f 6e c6          	movd   %esi,%xmm0
   1f615:	0f 2e 05 20 60 fe ff 	ucomiss -0x19fe0(%rip),%xmm0        # 563c <std::thread::current::id::ID+0x49c4>
   1f61c:	74 cd                	je     1f5eb <<gpui_canvas::color::Color>::fit_chroma+0x7b>
   1f61e:	66 0f 6e d2          	movd   %edx,%xmm2
   1f622:	0f 57 c9             	xorps  %xmm1,%xmm1
   1f625:	0f 2e d1             	ucomiss %xmm1,%xmm2
   1f628:	72 c1                	jb     1f5eb <<gpui_canvas::color::Color>::fit_chroma+0x7b>
   1f62a:	f3 0f 10 0d d6 5f fe 	movss  -0x1a02a(%rip),%xmm1        # 5608 <std::thread::current::id::ID+0x4990>
   1f631:	ff 
   1f632:	0f 2e ca             	ucomiss %xmm2,%xmm1
   1f635:	72 b4                	jb     1f5eb <<gpui_canvas::color::Color>::fit_chroma+0x7b>
   1f637:	f3 41 0f 10 5e 04    	movss  0x4(%r14),%xmm3
   1f63d:	31 c9                	xor    %ecx,%ecx
   1f63f:	0f 57 c9             	xorps  %xmm1,%xmm1
   1f642:	0f 2e d1             	ucomiss %xmm1,%xmm2
   1f645:	f3 0f 11 54 24 0c    	movss  %xmm2,0xc(%rsp)
   1f64b:	75 02                	jne    1f64f <<gpui_canvas::color::Color>::fit_chroma+0xdf>
   1f64d:	7b 63                	jnp    1f6b2 <<gpui_canvas::color::Color>::fit_chroma+0x142>
   1f64f:	0f 2e 15 b2 5f fe ff 	ucomiss -0x1a04e(%rip),%xmm2        # 5608 <std::thread::current::id::ID+0x4990>
   1f656:	75 02                	jne    1f65a <<gpui_canvas::color::Color>::fit_chroma+0xea>
   1f658:	7b 58                	jnp    1f6b2 <<gpui_canvas::color::Color>::fit_chroma+0x142>
   1f65a:	0f 29 5c 24 20       	movaps %xmm3,0x20(%rsp)
   1f65f:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   1f663:	f2 0f 10 0d f5 79 fe 	movsd  -0x1860b(%rip),%xmm1        # 7060 <std::thread::current::id::ID+0x63e8>
   1f66a:	ff 
   1f66b:	ff 15 7f 47 04 00    	call   *0x4477f(%rip)        # 63df0 <_DYNAMIC+0x368>
   1f671:	66 0f 2e 05 67 79 fe 	ucomisd -0x18699(%rip),%xmm0        # 6fe0 <std::thread::current::id::ID+0x6368>
   1f678:	ff 
   1f679:	0f 57 c9             	xorps  %xmm1,%xmm1
   1f67c:	73 0c                	jae    1f68a <<gpui_canvas::color::Color>::fit_chroma+0x11a>
   1f67e:	f2 0f 5a c0          	cvtsd2ss %xmm0,%xmm0
   1f682:	f3 0f c2 c8 00       	cmpeqss %xmm0,%xmm1
   1f687:	0f 55 c8             	andnps %xmm0,%xmm1
   1f68a:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   1f690:	89 ef                	mov    %ebp,%edi
   1f692:	e8 b9 15 00 00       	call   20c50 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>>
   1f697:	f3 0f 10 54 24 0c    	movss  0xc(%rsp),%xmm2
   1f69d:	48 89 c1             	mov    %rax,%rcx
   1f6a0:	48 c1 e9 20          	shr    $0x20,%rcx
   1f6a4:	83 f8 ff             	cmp    $0xffffffff,%eax
   1f6a7:	0f 28 5c 24 20       	movaps 0x20(%rsp),%xmm3
   1f6ac:	0f 85 39 ff ff ff    	jne    1f5eb <<gpui_canvas::color::Color>::fit_chroma+0x7b>
   1f6b2:	66 0f 6e c1          	movd   %ecx,%xmm0
   1f6b6:	0f 28 cb             	movaps %xmm3,%xmm1
   1f6b9:	f3 0f 5d c8          	minss  %xmm0,%xmm1
   1f6bd:	0f 28 e1             	movaps %xmm1,%xmm4
   1f6c0:	f3 0f c2 e1 03       	cmpunordss %xmm1,%xmm4
   1f6c5:	0f 28 c4             	movaps %xmm4,%xmm0
   1f6c8:	0f 55 c1             	andnps %xmm1,%xmm0
   1f6cb:	0f 54 e3             	andps  %xmm3,%xmm4
   1f6ce:	0f 56 e0             	orps   %xmm0,%xmm4
   1f6d1:	f3 0f 11 54 24 10    	movss  %xmm2,0x10(%rsp)
   1f6d7:	0f 29 64 24 20       	movaps %xmm4,0x20(%rsp)
   1f6dc:	f3 0f 11 64 24 14    	movss  %xmm4,0x14(%rsp)
   1f6e2:	44 89 64 24 18       	mov    %r12d,0x18(%rsp)
   1f6e7:	44 89 7c 24 1c       	mov    %r15d,0x1c(%rsp)
   1f6ec:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   1f6f1:	89 ee                	mov    %ebp,%esi
   1f6f3:	e8 f8 22 00 00       	call   219f0 <gpui_canvas::color::gamut::in_gamut>
   1f6f8:	84 c0                	test   %al,%al
   1f6fa:	74 24                	je     1f720 <<gpui_canvas::color::Color>::fit_chroma+0x1b0>
   1f6fc:	0f 28 44 24 20       	movaps 0x20(%rsp),%xmm0
   1f701:	f3 0f 11 43 08       	movss  %xmm0,0x8(%rbx)
   1f706:	44 89 63 0c          	mov    %r12d,0xc(%rbx)
   1f70a:	44 89 7b 10          	mov    %r15d,0x10(%rbx)
   1f70e:	31 c0                	xor    %eax,%eax
   1f710:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   1f716:	f3 0f 11 43 04       	movss  %xmm0,0x4(%rbx)
   1f71b:	e9 d6 fe ff ff       	jmp    1f5f6 <<gpui_canvas::color::Color>::fit_chroma+0x86>
   1f720:	b8 01 00 00 00       	mov    $0x1,%eax
   1f725:	f3 0f 10 05 d3 5e fe 	movss  -0x1a12d(%rip),%xmm0        # 5600 <std::thread::current::id::ID+0x4988>
   1f72c:	ff 
   1f72d:	f3 0f 11 43 04       	movss  %xmm0,0x4(%rbx)
   1f732:	e9 bf fe ff ff       	jmp    1f5f6 <<gpui_canvas::color::Color>::fit_chroma+0x86>
   1f737:	cc                   	int3
   1f738:	cc                   	int3
   1f739:	cc                   	int3
   1f73a:	cc                   	int3
   1f73b:	cc                   	int3
   1f73c:	cc                   	int3
   1f73d:	cc                   	int3
   1f73e:	cc                   	int3
   1f73f:	cc                   	int3

<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, usize, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>:
   1fc40:	55                   	push   %rbp
   1fc41:	48 89 e5             	mov    %rsp,%rbp
   1fc44:	48 83 e4 e0          	and    $0xffffffffffffffe0,%rsp
   1fc48:	48 81 ec 60 04 00 00 	sub    $0x460,%rsp
   1fc4f:	0f 28 42 20          	movaps 0x20(%rdx),%xmm0
   1fc53:	66 0f 28 4a 30       	movapd 0x30(%rdx),%xmm1
   1fc58:	0f 29 84 24 60 03 00 	movaps %xmm0,0x360(%rsp)
   1fc5f:	00 
   1fc60:	66 0f 29 8c 24 70 03 	movapd %xmm1,0x370(%rsp)
   1fc67:	00 00 
   1fc69:	0f 28 12             	movaps (%rdx),%xmm2
   1fc6c:	0f 29 94 24 40 03 00 	movaps %xmm2,0x340(%rsp)
   1fc73:	00 
   1fc74:	66 0f 28 5a 10       	movapd 0x10(%rdx),%xmm3
   1fc79:	66 0f 29 9c 24 50 03 	movapd %xmm3,0x350(%rsp)
   1fc80:	00 00 
   1fc82:	0f 29 94 24 10 04 00 	movaps %xmm2,0x410(%rsp)
   1fc89:	00 
   1fc8a:	66 0f 29 9c 24 20 04 	movapd %xmm3,0x420(%rsp)
   1fc91:	00 00 
   1fc93:	0f 29 84 24 30 04 00 	movaps %xmm0,0x430(%rsp)
   1fc9a:	00 
   1fc9b:	66 0f 29 8c 24 40 04 	movapd %xmm1,0x440(%rsp)
   1fca2:	00 00 
   1fca4:	66 0f 29 8c 24 d0 03 	movapd %xmm1,0x3d0(%rsp)
   1fcab:	00 00 
   1fcad:	0f 29 84 24 c0 03 00 	movaps %xmm0,0x3c0(%rsp)
   1fcb4:	00 
   1fcb5:	66 0f 29 9c 24 b0 03 	movapd %xmm3,0x3b0(%rsp)
   1fcbc:	00 00 
   1fcbe:	0f 29 94 24 a0 03 00 	movaps %xmm2,0x3a0(%rsp)
   1fcc5:	00 
   1fcc6:	0f 28 84 24 00 04 00 	movaps 0x400(%rsp),%xmm0
   1fccd:	00 
   1fcce:	0f 29 84 24 90 03 00 	movaps %xmm0,0x390(%rsp)
   1fcd5:	00 
   1fcd6:	66 0f 28 05 22 58 fe 	movapd -0x1a7de(%rip),%xmm0        # 5500 <std::thread::current::id::ID+0x4888>
   1fcdd:	ff 
   1fcde:	66 0f 29 84 24 e0 03 	movapd %xmm0,0x3e0(%rsp)
   1fce5:	00 00 
   1fce7:	66 0f 29 84 24 f0 03 	movapd %xmm0,0x3f0(%rsp)
   1fcee:	00 00 
   1fcf0:	48 8d 84 24 a0 03 00 	lea    0x3a0(%rsp),%rax
   1fcf7:	00 
   1fcf8:	66 44 0f 28 1e       	movapd (%rsi),%xmm11
   1fcfd:	66 44 0f 28 46 10    	movapd 0x10(%rsi),%xmm8
   1fd03:	66 44 0f 28 66 20    	movapd 0x20(%rsi),%xmm12
   1fd09:	66 44 0f 28 6e 60    	movapd 0x60(%rsi),%xmm13
   1fd0f:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   1fd13:	66 41 0f c2 cd 05    	cmpnltpd %xmm13,%xmm1
   1fd19:	66 0f 54 c8          	andpd  %xmm0,%xmm1
   1fd1d:	66 0f 29 4c 24 50    	movapd %xmm1,0x50(%rsp)
   1fd23:	66 0f 28 0d 45 55 fe 	movapd -0x1aabb(%rip),%xmm1        # 5270 <std::thread::current::id::ID+0x45f8>
   1fd2a:	ff 
   1fd2b:	66 41 0f 28 d3       	movapd %xmm11,%xmm2
   1fd30:	66 0f 59 d1          	mulpd  %xmm1,%xmm2
   1fd34:	66 0f 29 94 24 f0 01 	movapd %xmm2,0x1f0(%rsp)
   1fd3b:	00 00 
   1fd3d:	66 41 0f 28 d4       	movapd %xmm12,%xmm2
   1fd42:	66 41 0f 58 d4       	addpd  %xmm12,%xmm2
   1fd47:	66 0f 29 94 24 e0 01 	movapd %xmm2,0x1e0(%rsp)
   1fd4e:	00 00 
   1fd50:	66 44 0f 28 35 a7 53 	movapd -0x1ac59(%rip),%xmm14        # 5100 <std::thread::current::id::ID+0x4488>
   1fd57:	fe ff 
   1fd59:	66 41 0f 28 d3       	movapd %xmm11,%xmm2
   1fd5e:	66 41 0f 54 d6       	andpd  %xmm14,%xmm2
   1fd63:	66 0f 29 94 24 60 01 	movapd %xmm2,0x160(%rsp)
   1fd6a:	00 00 
   1fd6c:	66 0f 59 d1          	mulpd  %xmm1,%xmm2
   1fd70:	66 0f 29 94 24 d0 01 	movapd %xmm2,0x1d0(%rsp)
   1fd77:	00 00 
   1fd79:	66 41 0f 28 d4       	movapd %xmm12,%xmm2
   1fd7e:	66 41 0f 54 d6       	andpd  %xmm14,%xmm2
   1fd83:	66 0f 28 6e 70       	movapd 0x70(%rsi),%xmm5
   1fd88:	66 0f 57 db          	xorpd  %xmm3,%xmm3
   1fd8c:	66 0f c2 dd 05       	cmpnltpd %xmm5,%xmm3
   1fd91:	66 0f 54 d8          	andpd  %xmm0,%xmm3
   1fd95:	66 0f 29 5c 24 40    	movapd %xmm3,0x40(%rsp)
   1fd9b:	66 41 0f 28 d8       	movapd %xmm8,%xmm3
   1fda0:	66 0f 59 d9          	mulpd  %xmm1,%xmm3
   1fda4:	66 0f 28 7e 30       	movapd 0x30(%rsi),%xmm7
   1fda9:	66 0f 28 e7          	movapd %xmm7,%xmm4
   1fdad:	66 0f 58 e7          	addpd  %xmm7,%xmm4
   1fdb1:	66 41 0f 28 f0       	movapd %xmm8,%xmm6
   1fdb6:	66 41 0f 54 f6       	andpd  %xmm14,%xmm6
   1fdbb:	66 0f 29 b4 24 40 01 	movapd %xmm6,0x140(%rsp)
   1fdc2:	00 00 
   1fdc4:	66 0f 59 ce          	mulpd  %xmm6,%xmm1
   1fdc8:	66 0f 28 f7          	movapd %xmm7,%xmm6
   1fdcc:	66 41 0f 54 f6       	andpd  %xmm14,%xmm6
   1fdd1:	66 0f 29 94 24 50 01 	movapd %xmm2,0x150(%rsp)
   1fdd8:	00 00 
   1fdda:	66 0f 58 d2          	addpd  %xmm2,%xmm2
   1fdde:	66 0f 29 94 24 c0 01 	movapd %xmm2,0x1c0(%rsp)
   1fde5:	00 00 
   1fde7:	66 0f 29 b4 24 30 01 	movapd %xmm6,0x130(%rsp)
   1fdee:	00 00 
   1fdf0:	66 0f 58 f6          	addpd  %xmm6,%xmm6
   1fdf4:	66 0f 28 56 40       	movapd 0x40(%rsi),%xmm2
   1fdf9:	66 0f 29 94 24 90 00 	movapd %xmm2,0x90(%rsp)
   1fe00:	00 00 
   1fe02:	66 41 0f 54 d6       	andpd  %xmm14,%xmm2
   1fe07:	66 0f 29 94 24 b0 01 	movapd %xmm2,0x1b0(%rsp)
   1fe0e:	00 00 
   1fe10:	66 0f 28 56 50       	movapd 0x50(%rsi),%xmm2
   1fe15:	66 44 0f 28 ca       	movapd %xmm2,%xmm9
   1fe1a:	66 45 0f 54 ce       	andpd  %xmm14,%xmm9
   1fe1f:	66 45 0f 28 d5       	movapd %xmm13,%xmm10
   1fe24:	66 45 0f 54 d6       	andpd  %xmm14,%xmm10
   1fe29:	66 44 0f 29 94 24 40 	movapd %xmm10,0x240(%rsp)
   1fe30:	02 00 00 
   1fe33:	66 44 0f 28 d5       	movapd %xmm5,%xmm10
   1fe38:	66 45 0f 54 d6       	andpd  %xmm14,%xmm10
   1fe3d:	66 44 0f 29 94 24 30 	movapd %xmm10,0x230(%rsp)
   1fe44:	02 00 00 
   1fe47:	66 44 0f 6f 51 10    	movdqa 0x10(%rcx),%xmm10
   1fe4d:	66 44 0f 7f 94 24 e0 	movdqa %xmm10,0xe0(%rsp)
   1fe54:	00 00 00 
   1fe57:	66 45 0f 6d d2       	punpckhqdq %xmm10,%xmm10
   1fe5c:	66 44 0f 7f 94 24 20 	movdqa %xmm10,0x120(%rsp)
   1fe63:	01 00 00 
   1fe66:	66 0f 29 94 24 70 01 	movapd %xmm2,0x170(%rsp)
   1fe6d:	00 00 
   1fe6f:	66 0f c6 d2 01       	shufpd $0x1,%xmm2,%xmm2
   1fe74:	66 0f 29 94 24 30 03 	movapd %xmm2,0x330(%rsp)
   1fe7b:	00 00 
   1fe7d:	66 0f 29 a4 24 70 02 	movapd %xmm4,0x270(%rsp)
   1fe84:	00 00 
   1fe86:	66 0f c6 e4 01       	shufpd $0x1,%xmm4,%xmm4
   1fe8b:	66 0f 29 a4 24 20 03 	movapd %xmm4,0x320(%rsp)
   1fe92:	00 00 
   1fe94:	66 0f 29 9c 24 90 02 	movapd %xmm3,0x290(%rsp)
   1fe9b:	00 00 
   1fe9d:	66 0f c6 db 01       	shufpd $0x1,%xmm3,%xmm3
   1fea2:	66 0f 29 9c 24 10 03 	movapd %xmm3,0x310(%rsp)
   1fea9:	00 00 
   1feab:	66 41 0f 28 db       	movapd %xmm11,%xmm3
   1feb0:	66 0f 29 b4 24 60 02 	movapd %xmm6,0x260(%rsp)
   1feb7:	00 00 
   1feb9:	66 0f c6 f6 01       	shufpd $0x1,%xmm6,%xmm6
   1febe:	66 0f 29 b4 24 00 03 	movapd %xmm6,0x300(%rsp)
   1fec5:	00 00 
   1fec7:	66 0f 29 8c 24 b0 02 	movapd %xmm1,0x2b0(%rsp)
   1fece:	00 00 
   1fed0:	66 0f c6 c9 01       	shufpd $0x1,%xmm1,%xmm1
   1fed5:	66 0f 29 8c 24 f0 02 	movapd %xmm1,0x2f0(%rsp)
   1fedc:	00 00 
   1fede:	31 d2                	xor    %edx,%edx
   1fee0:	be 01 00 00 00       	mov    $0x1,%esi
   1fee5:	0f 28 09             	movaps (%rcx),%xmm1
   1fee8:	0f 29 8c 24 10 01 00 	movaps %xmm1,0x110(%rsp)
   1feef:	00 
   1fef0:	66 44 0f 29 8c 24 50 	movapd %xmm9,0x250(%rsp)
   1fef7:	02 00 00 
   1fefa:	66 41 0f 70 c9 4e    	pshufd $0x4e,%xmm9,%xmm1
   1ff00:	66 0f 7f 8c 24 e0 02 	movdqa %xmm1,0x2e0(%rsp)
   1ff07:	00 00 
   1ff09:	66 45 0f 57 db       	xorpd  %xmm11,%xmm11
   1ff0e:	66 0f 29 44 24 70    	movapd %xmm0,0x70(%rsp)
   1ff14:	66 0f 57 f6          	xorpd  %xmm6,%xmm6
   1ff18:	66 0f 28 c8          	movapd %xmm0,%xmm1
   1ff1c:	66 0f 29 9c 24 a0 01 	movapd %xmm3,0x1a0(%rsp)
   1ff23:	00 00 
   1ff25:	66 44 0f 29 84 24 f0 	movapd %xmm8,0xf0(%rsp)
   1ff2c:	00 00 00 
   1ff2f:	66 44 0f 29 a4 24 90 	movapd %xmm12,0x190(%rsp)
   1ff36:	01 00 00 
   1ff39:	66 44 0f 29 ac 24 80 	movapd %xmm13,0x180(%rsp)
   1ff40:	01 00 00 
   1ff43:	66 0f 29 ac 24 a0 02 	movapd %xmm5,0x2a0(%rsp)
   1ff4a:	00 00 
   1ff4c:	66 0f 29 bc 24 80 02 	movapd %xmm7,0x280(%rsp)
   1ff53:	00 00 
   1ff55:	e9 94 00 00 00       	jmp    1ffee <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, usize, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>+0x3ae>
   1ff5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   1ff60:	66 0f 6f a4 24 d0 00 	movdqa 0xd0(%rsp),%xmm4
   1ff67:	00 00 
   1ff69:	66 44 0f 28 5c 24 30 	movapd 0x30(%rsp),%xmm11
   1ff70:	66 0f 28 8c 24 b0 00 	movapd 0xb0(%rsp),%xmm1
   1ff77:	00 00 
   1ff79:	66 0f 55 ca          	andnpd %xmm2,%xmm1
   1ff7d:	66 0f 28 84 24 a0 00 	movapd 0xa0(%rsp),%xmm0
   1ff84:	00 00 
   1ff86:	66 0f 54 84 24 00 01 	andpd  0x100(%rsp),%xmm0
   1ff8d:	00 00 
   1ff8f:	66 0f 54 c8          	andpd  %xmm0,%xmm1
   1ff93:	66 0f 55 44 24 70    	andnpd 0x70(%rsp),%xmm0
   1ff99:	66 0f 56 c1          	orpd   %xmm1,%xmm0
   1ff9d:	66 0f 29 44 24 70    	movapd %xmm0,0x70(%rsp)
   1ffa3:	48 ff c2             	inc    %rdx
   1ffa6:	66 0f 28 c6          	movapd %xmm6,%xmm0
   1ffaa:	66 0f 5c 44 24 60    	subpd  0x60(%rsp),%xmm0
   1ffb0:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   1ffb4:	66 0f 5f c1          	maxpd  %xmm1,%xmm0
   1ffb8:	66 44 0f df d0       	pandn  %xmm0,%xmm10
   1ffbd:	66 45 0f 54 cf       	andpd  %xmm15,%xmm9
   1ffc2:	66 41 0f 70 c1 a0    	pshufd $0xa0,%xmm9,%xmm0
   1ffc8:	66 0f 72 f0 1f       	pslld  $0x1f,%xmm0
   1ffcd:	66 0f 72 e0 1f       	psrad  $0x1f,%xmm0
   1ffd2:	66 44 0f db d0       	pand   %xmm0,%xmm10
   1ffd7:	66 0f df c4          	pandn  %xmm4,%xmm0
   1ffdb:	66 0f 6f c8          	movdqa %xmm0,%xmm1
   1ffdf:	66 41 0f eb ca       	por    %xmm10,%xmm1
   1ffe4:	48 83 fa 03          	cmp    $0x3,%rdx
   1ffe8:	0f 84 3a 0c 00 00    	je     20c28 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, usize, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>+0xfe8>
   1ffee:	66 0f 29 8c 24 d0 00 	movapd %xmm1,0xd0(%rsp)
   1fff5:	00 00 
   1fff7:	66 0f 29 b4 24 d0 02 	movapd %xmm6,0x2d0(%rsp)
   1fffe:	00 00 
   20000:	66 44 0f 29 9c 24 c0 	movapd %xmm11,0x2c0(%rsp)
   20007:	02 00 00 
   2000a:	48 89 d1             	mov    %rdx,%rcx
   2000d:	48 c1 e1 05          	shl    $0x5,%rcx
   20011:	66 0f 28 04 08       	movapd (%rax,%rcx,1),%xmm0
   20016:	66 0f 28 54 08 10    	movapd 0x10(%rax,%rcx,1),%xmm2
   2001c:	66 0f 28 da          	movapd %xmm2,%xmm3
   20020:	66 0f 15 da          	unpckhpd %xmm2,%xmm3
   20024:	66 44 0f 28 d0       	movapd %xmm0,%xmm10
   20029:	66 44 0f c2 94 24 10 	cmpnltpd 0x110(%rsp),%xmm10
   20030:	01 00 00 05 
   20034:	66 0f 28 3d c4 54 fe 	movapd -0x1ab3c(%rip),%xmm7        # 5500 <std::thread::current::id::ID+0x4888>
   2003b:	ff 
   2003c:	66 0f 28 cf          	movapd %xmm7,%xmm1
   20040:	66 41 0f 54 ca       	andpd  %xmm10,%xmm1
   20045:	66 0f 29 84 24 b0 00 	movapd %xmm0,0xb0(%rsp)
   2004c:	00 00 
   2004e:	66 44 0f 55 d0       	andnpd %xmm0,%xmm10
   20053:	66 44 0f 56 d1       	orpd   %xmm1,%xmm10
   20058:	66 41 0f 28 ca       	movapd %xmm10,%xmm1
   2005d:	66 0f c2 cf 04       	cmpneqpd %xmm7,%xmm1
   20062:	66 41 0f 28 c2       	movapd %xmm10,%xmm0
   20067:	66 0f c2 c7 07       	cmpordpd %xmm7,%xmm0
   2006c:	66 0f 54 c1          	andpd  %xmm1,%xmm0
   20070:	66 0f 29 44 24 10    	movapd %xmm0,0x10(%rsp)
   20076:	66 44 0f 54 d0       	andpd  %xmm0,%xmm10
   2007b:	66 44 0f 29 54 24 30 	movapd %xmm10,0x30(%rsp)
   20082:	66 45 0f 54 d6       	andpd  %xmm14,%xmm10
   20087:	66 0f 28 05 f1 53 fe 	movapd -0x1ac0f(%rip),%xmm0        # 5480 <std::thread::current::id::ID+0x4808>
   2008e:	ff 
   2008f:	66 44 0f 58 d0       	addpd  %xmm0,%xmm10
   20094:	66 0f 28 ea          	movapd %xmm2,%xmm5
   20098:	f2 0f c2 ac 24 e0 00 	cmpnltsd 0xe0(%rsp),%xmm5
   2009f:	00 00 05 
   200a2:	66 0f 28 cd          	movapd %xmm5,%xmm1
   200a6:	66 0f 29 54 24 60    	movapd %xmm2,0x60(%rsp)
   200ac:	66 0f 55 ca          	andnpd %xmm2,%xmm1
   200b0:	f2 0f 10 15 80 6e fe 	movsd  -0x19180(%rip),%xmm2        # 6f38 <std::thread::current::id::ID+0x62c0>
   200b7:	ff 
   200b8:	66 0f 54 ea          	andpd  %xmm2,%xmm5
   200bc:	66 0f 56 e9          	orpd   %xmm1,%xmm5
   200c0:	66 0f 28 e3          	movapd %xmm3,%xmm4
   200c4:	f2 0f c2 a4 24 20 01 	cmpnltsd 0x120(%rsp),%xmm4
   200cb:	00 00 05 
   200ce:	66 0f 28 cc          	movapd %xmm4,%xmm1
   200d2:	66 0f 29 9c 24 c0 00 	movapd %xmm3,0xc0(%rsp)
   200d9:	00 00 
   200db:	66 0f 55 cb          	andnpd %xmm3,%xmm1
   200df:	66 0f 54 e2          	andpd  %xmm2,%xmm4
   200e3:	66 0f 56 e1          	orpd   %xmm1,%xmm4
   200e7:	31 c9                	xor    %ecx,%ecx
   200e9:	66 0f 2e ea          	ucomisd %xmm2,%xmm5
   200ed:	0f 95 c1             	setne  %cl
   200f0:	45 31 c9             	xor    %r9d,%r9d
   200f3:	66 0f 2e e2          	ucomisd %xmm2,%xmm4
   200f7:	41 0f 94 c1          	sete   %r9b
   200fb:	66 0f 6e c9          	movd   %ecx,%xmm1
   200ff:	66 41 0f c4 c9 04    	pinsrw $0x4,%r9d,%xmm1
   20105:	66 0f 70 d9 a0       	pshufd $0xa0,%xmm1,%xmm3
   2010a:	66 0f 72 f3 1f       	pslld  $0x1f,%xmm3
   2010f:	66 0f 72 e3 1f       	psrad  $0x1f,%xmm3
   20114:	66 0f 29 6c 24 20    	movapd %xmm5,0x20(%rsp)
   2011a:	f3 0f 7e cd          	movq   %xmm5,%xmm1
   2011e:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   20122:	66 0f 29 a4 24 a0 00 	movapd %xmm4,0xa0(%rsp)
   20129:	00 00 
   2012b:	66 0f 14 d4          	unpcklpd %xmm4,%xmm2
   2012f:	66 0f db cb          	pand   %xmm3,%xmm1
   20133:	66 0f df da          	pandn  %xmm2,%xmm3
   20137:	66 0f eb d9          	por    %xmm1,%xmm3
   2013b:	66 0f 7f 9c 24 80 00 	movdqa %xmm3,0x80(%rsp)
   20142:	00 00 
   20144:	66 0f 6f d3          	movdqa %xmm3,%xmm2
   20148:	66 41 0f db d6       	pand   %xmm14,%xmm2
   2014d:	66 0f 58 d0          	addpd  %xmm0,%xmm2
   20151:	66 0f 28 05 f7 51 fe 	movapd -0x1ae09(%rip),%xmm0        # 5350 <std::thread::current::id::ID+0x46d8>
   20158:	ff 
   20159:	66 44 0f 59 d0       	mulpd  %xmm0,%xmm10
   2015e:	66 41 0f 6e c9       	movd   %r9d,%xmm1
   20163:	66 0f c4 c9 04       	pinsrw $0x4,%ecx,%xmm1
   20168:	66 0f 7f 8c 24 00 01 	movdqa %xmm1,0x100(%rsp)
   2016f:	00 00 
   20171:	66 0f 59 d0          	mulpd  %xmm0,%xmm2
   20175:	b9 1f 00 00 00       	mov    $0x1f,%ecx
   2017a:	66 0f 28 cf          	movapd %xmm7,%xmm1
   2017e:	66 90                	xchg   %ax,%ax
   20180:	66 44 0f 28 ca       	movapd %xmm2,%xmm9
   20185:	f2 0f 10 1d ab 6d fe 	movsd  -0x19255(%rip),%xmm3        # 6f38 <std::thread::current::id::ID+0x62c0>
   2018c:	ff 
   2018d:	66 0f 28 44 24 20    	movapd 0x20(%rsp),%xmm0
   20193:	66 0f 2e c3          	ucomisd %xmm3,%xmm0
   20197:	66 45 0f 28 c2       	movapd %xmm10,%xmm8
   2019c:	41 0f 95 c1          	setne  %r9b
   201a0:	66 0f 28 e1          	movapd %xmm1,%xmm4
   201a4:	66 0f 28 ef          	movapd %xmm7,%xmm5
   201a8:	66 0f 15 ef          	unpckhpd %xmm7,%xmm5
   201ac:	45 31 d2             	xor    %r10d,%r10d
   201af:	66 0f 2e eb          	ucomisd %xmm3,%xmm5
   201b3:	66 0f 28 2d 45 53 fe 	movapd -0x1acbb(%rip),%xmm5        # 5500 <std::thread::current::id::ID+0x4888>
   201ba:	ff 
   201bb:	66 0f c2 e5 00       	cmpeqpd %xmm5,%xmm4
   201c0:	66 45 0f 58 d2       	addpd  %xmm10,%xmm10
   201c5:	66 0f 28 44 24 30    	movapd 0x30(%rsp),%xmm0
   201cb:	66 44 0f 28 f8       	movapd %xmm0,%xmm15
   201d0:	66 45 0f 5c f8       	subpd  %xmm8,%xmm15
   201d5:	66 0f 57 db          	xorpd  %xmm3,%xmm3
   201d9:	66 44 0f 5f fb       	maxpd  %xmm3,%xmm15
   201de:	66 44 0f 58 c0       	addpd  %xmm0,%xmm8
   201e3:	66 44 0f 28 9c 24 f0 	movapd 0x1f0(%rsp),%xmm11
   201ea:	01 00 00 
   201ed:	66 41 0f 28 eb       	movapd %xmm11,%xmm5
   201f2:	66 41 0f 59 ef       	mulpd  %xmm15,%xmm5
   201f7:	66 44 0f 28 a4 24 e0 	movapd 0x1e0(%rsp),%xmm12
   201fe:	01 00 00 
   20201:	66 41 0f 58 ec       	addpd  %xmm12,%xmm5
   20206:	66 41 0f 59 ef       	mulpd  %xmm15,%xmm5
   2020b:	66 0f 28 84 24 90 00 	movapd 0x90(%rsp),%xmm0
   20212:	00 00 
   20214:	66 0f 58 e8          	addpd  %xmm0,%xmm5
   20218:	66 44 0f 28 ac 24 d0 	movapd 0x1d0(%rsp),%xmm13
   2021f:	01 00 00 
   20222:	66 45 0f 28 f5       	movapd %xmm13,%xmm14
   20227:	66 45 0f 59 f7       	mulpd  %xmm15,%xmm14
   2022c:	66 0f 28 9c 24 c0 01 	movapd 0x1c0(%rsp),%xmm3
   20233:	00 00 
   20235:	66 44 0f 58 f3       	addpd  %xmm3,%xmm14
   2023a:	66 45 0f 59 f7       	mulpd  %xmm15,%xmm14
   2023f:	66 0f 28 b4 24 b0 01 	movapd 0x1b0(%rsp),%xmm6
   20246:	00 00 
   20248:	66 44 0f 58 f6       	addpd  %xmm6,%xmm14
   2024d:	66 44 0f 28 3d fa 50 	movapd -0x1af06(%rip),%xmm15        # 5350 <std::thread::current::id::ID+0x46d8>
   20254:	fe ff 
   20256:	66 45 0f 59 f7       	mulpd  %xmm15,%xmm14
   2025b:	66 45 0f 28 fb       	movapd %xmm11,%xmm15
   20260:	66 45 0f 59 f8       	mulpd  %xmm8,%xmm15
   20265:	66 45 0f 58 fc       	addpd  %xmm12,%xmm15
   2026a:	66 45 0f 59 f8       	mulpd  %xmm8,%xmm15
   2026f:	66 44 0f 58 f8       	addpd  %xmm0,%xmm15
   20274:	66 45 0f 28 dd       	movapd %xmm13,%xmm11
   20279:	66 45 0f 59 d8       	mulpd  %xmm8,%xmm11
   2027e:	66 44 0f 58 db       	addpd  %xmm3,%xmm11
   20283:	66 45 0f 59 d8       	mulpd  %xmm8,%xmm11
   20288:	66 44 0f 58 de       	addpd  %xmm6,%xmm11
   2028d:	66 44 0f 59 1d ba 50 	mulpd  -0x1af46(%rip),%xmm11        # 5350 <std::thread::current::id::ID+0x46d8>
   20294:	fe ff 
   20296:	66 45 0f 28 c6       	movapd %xmm14,%xmm8
   2029b:	66 44 0f 28 2d 9c 52 	movapd -0x1ad64(%rip),%xmm13        # 5540 <std::thread::current::id::ID+0x48c8>
   202a2:	fe ff 
   202a4:	66 45 0f 57 c5       	xorpd  %xmm13,%xmm8
   202a9:	66 44 0f c2 f5 01    	cmpltpd %xmm5,%xmm14
   202af:	66 41 0f c2 e8 01    	cmpltpd %xmm8,%xmm5
   202b5:	66 45 0f 28 c3       	movapd %xmm11,%xmm8
   202ba:	66 45 0f c2 c7 01    	cmpltpd %xmm15,%xmm8
   202c0:	66 44 0f 54 c5       	andpd  %xmm5,%xmm8
   202c5:	66 45 0f 57 dd       	xorpd  %xmm13,%xmm11
   202ca:	66 45 0f c2 fb 01    	cmpltpd %xmm11,%xmm15
   202d0:	66 45 0f 54 fe       	andpd  %xmm14,%xmm15
   202d5:	66 45 0f 56 f8       	orpd   %xmm8,%xmm15
   202da:	66 44 0f 54 fc       	andpd  %xmm4,%xmm15
   202df:	66 44 0f 54 7c 24 10 	andpd  0x10(%rsp),%xmm15
   202e6:	66 41 0f 28 e2       	movapd %xmm10,%xmm4
   202eb:	66 41 0f 54 e7       	andpd  %xmm15,%xmm4
   202f0:	66 44 0f 55 f9       	andnpd %xmm1,%xmm15
   202f5:	66 41 0f 28 cf       	movapd %xmm15,%xmm1
   202fa:	66 0f 56 cc          	orpd   %xmm4,%xmm1
   202fe:	66 0f 28 84 24 80 00 	movapd 0x80(%rsp),%xmm0
   20305:	00 00 
   20307:	66 0f 28 e0          	movapd %xmm0,%xmm4
   2030b:	66 0f 5c e2          	subpd  %xmm2,%xmm4
   2030f:	66 0f c6 e4 01       	shufpd $0x1,%xmm4,%xmm4
   20314:	66 0f 57 db          	xorpd  %xmm3,%xmm3
   20318:	66 0f 5f e3          	maxpd  %xmm3,%xmm4
   2031c:	66 44 0f 58 c8       	addpd  %xmm0,%xmm9
   20321:	66 45 0f c6 c9 01    	shufpd $0x1,%xmm9,%xmm9
   20327:	66 0f 28 ac 24 10 03 	movapd 0x310(%rsp),%xmm5
   2032e:	00 00 
   20330:	66 44 0f 28 fd       	movapd %xmm5,%xmm15
   20335:	66 44 0f 59 fc       	mulpd  %xmm4,%xmm15
   2033a:	66 0f 28 9c 24 20 03 	movapd 0x320(%rsp),%xmm3
   20341:	00 00 
   20343:	66 44 0f 58 fb       	addpd  %xmm3,%xmm15
   20348:	66 44 0f 59 fc       	mulpd  %xmm4,%xmm15
   2034d:	66 0f 28 84 24 30 03 	movapd 0x330(%rsp),%xmm0
   20354:	00 00 
   20356:	66 44 0f 58 f8       	addpd  %xmm0,%xmm15
   2035b:	66 44 0f 28 9c 24 f0 	movapd 0x2f0(%rsp),%xmm11
   20362:	02 00 00 
   20365:	66 45 0f 28 c3       	movapd %xmm11,%xmm8
   2036a:	66 44 0f 59 c4       	mulpd  %xmm4,%xmm8
   2036f:	66 0f 28 b4 24 00 03 	movapd 0x300(%rsp),%xmm6
   20376:	00 00 
   20378:	66 44 0f 58 c6       	addpd  %xmm6,%xmm8
   2037d:	66 44 0f 59 c4       	mulpd  %xmm4,%xmm8
   20382:	66 44 0f 28 a4 24 e0 	movapd 0x2e0(%rsp),%xmm12
   20389:	02 00 00 
   2038c:	66 45 0f 58 c4       	addpd  %xmm12,%xmm8
   20391:	66 44 0f 28 35 b6 4f 	movapd -0x1b04a(%rip),%xmm14        # 5350 <std::thread::current::id::ID+0x46d8>
   20398:	fe ff 
   2039a:	66 45 0f 59 c6       	mulpd  %xmm14,%xmm8
   2039f:	66 0f 28 e5          	movapd %xmm5,%xmm4
   203a3:	66 41 0f 59 e1       	mulpd  %xmm9,%xmm4
   203a8:	66 0f 58 e3          	addpd  %xmm3,%xmm4
   203ac:	66 41 0f 59 e1       	mulpd  %xmm9,%xmm4
   203b1:	66 0f 58 e0          	addpd  %xmm0,%xmm4
   203b5:	66 41 0f 28 eb       	movapd %xmm11,%xmm5
   203ba:	66 41 0f 59 e9       	mulpd  %xmm9,%xmm5
   203bf:	66 0f 58 ee          	addpd  %xmm6,%xmm5
   203c3:	66 41 0f 59 e9       	mulpd  %xmm9,%xmm5
   203c8:	66 41 0f 58 ec       	addpd  %xmm12,%xmm5
   203cd:	66 41 0f 59 ee       	mulpd  %xmm14,%xmm5
   203d2:	66 45 0f 28 c8       	movapd %xmm8,%xmm9
   203d7:	66 45 0f 57 cd       	xorpd  %xmm13,%xmm9
   203dc:	66 45 0f 28 df       	movapd %xmm15,%xmm11
   203e1:	66 45 0f 28 f0       	movapd %xmm8,%xmm14
   203e6:	66 45 0f c2 f7 05    	cmpnltpd %xmm15,%xmm14
   203ec:	66 45 0f c2 c7 01    	cmpltpd %xmm15,%xmm8
   203f2:	66 45 0f c2 f9 05    	cmpnltpd %xmm9,%xmm15
   203f8:	66 45 0f c2 d9 01    	cmpltpd %xmm9,%xmm11
   203fe:	66 44 0f 28 cd       	movapd %xmm5,%xmm9
   20403:	66 44 0f c2 cc 05    	cmpnltpd %xmm4,%xmm9
   20409:	66 45 0f 56 cf       	orpd   %xmm15,%xmm9
   2040e:	66 44 0f 28 fd       	movapd %xmm5,%xmm15
   20413:	66 44 0f c2 fc 01    	cmpltpd %xmm4,%xmm15
   20419:	66 45 0f 54 fb       	andpd  %xmm11,%xmm15
   2041e:	66 41 0f 57 ed       	xorpd  %xmm13,%xmm5
   20423:	66 44 0f 28 dc       	movapd %xmm4,%xmm11
   20428:	66 44 0f c2 dd 05    	cmpnltpd %xmm5,%xmm11
   2042e:	66 45 0f 56 de       	orpd   %xmm14,%xmm11
   20433:	66 45 0f 54 d9       	andpd  %xmm9,%xmm11
   20438:	66 0f c2 e5 01       	cmpltpd %xmm5,%xmm4
   2043d:	66 41 0f 54 e0       	andpd  %xmm8,%xmm4
   20442:	41 0f 93 c2          	setae  %r10b
   20446:	45 31 db             	xor    %r11d,%r11d
   20449:	f2 0f 10 1d e7 6a fe 	movsd  -0x19519(%rip),%xmm3        # 6f38 <std::thread::current::id::ID+0x62c0>
   20450:	ff 
   20451:	66 0f 2e fb          	ucomisd %xmm3,%xmm7
   20455:	41 0f 92 c3          	setb   %r11b
   20459:	66 41 0f 56 e7       	orpd   %xmm15,%xmm4
   2045e:	66 41 0f 6e eb       	movd   %r11d,%xmm5
   20463:	66 0f 6f 84 24 00 01 	movdqa 0x100(%rsp),%xmm0
   2046a:	00 00 
   2046c:	66 0f eb e8          	por    %xmm0,%xmm5
   20470:	66 41 0f eb eb       	por    %xmm11,%xmm5
   20475:	66 45 0f 6e c2       	movd   %r10d,%xmm8
   2047a:	66 45 0f 70 c0 44    	pshufd $0x44,%xmm8,%xmm8
   20480:	66 44 0f db c0       	pand   %xmm0,%xmm8
   20485:	66 44 0f db c4       	pand   %xmm4,%xmm8
   2048a:	66 0f 58 d2          	addpd  %xmm2,%xmm2
   2048e:	41 0f c6 e8 a0       	shufps $0xa0,%xmm8,%xmm5
   20493:	66 0f 72 f5 1f       	pslld  $0x1f,%xmm5
   20498:	66 0f 72 e5 1f       	psrad  $0x1f,%xmm5
   2049d:	66 0f 28 e2          	movapd %xmm2,%xmm4
   204a1:	66 0f 15 e7          	unpckhpd %xmm7,%xmm4
   204a5:	66 0f 14 fa          	unpcklpd %xmm2,%xmm7
   204a9:	66 44 0f 28 c7       	movapd %xmm7,%xmm8
   204ae:	66 44 0f 54 c5       	andpd  %xmm5,%xmm8
   204b3:	66 0f 55 ec          	andnpd %xmm4,%xmm5
   204b7:	66 0f 28 fd          	movapd %xmm5,%xmm7
   204bb:	66 41 0f 56 f8       	orpd   %xmm8,%xmm7
   204c0:	66 0f 28 e1          	movapd %xmm1,%xmm4
   204c4:	66 0f c2 25 33 50 fe 	cmpeqpd -0x1afcd(%rip),%xmm4        # 5500 <std::thread::current::id::ID+0x4888>
   204cb:	ff 00 
   204cd:	66 0f 54 64 24 10    	andpd  0x10(%rsp),%xmm4
   204d3:	66 44 0f 50 d4       	movmskpd %xmm4,%r10d
   204d8:	66 44 0f 70 cf ee    	pshufd $0xee,%xmm7,%xmm9
   204de:	66 44 0f 2e cb       	ucomisd %xmm3,%xmm9
   204e3:	41 0f 93 c3          	setae  %r11b
   204e7:	45 20 cb             	and    %r9b,%r11b
   204ea:	45 85 d2             	test   %r10d,%r10d
   204ed:	41 0f 95 c2          	setne  %r10b
   204f1:	45 08 da             	or     %r11b,%r10b
   204f4:	83 c1 ff             	add    $0xffffffff,%ecx
   204f7:	41 0f 92 c1          	setb   %r9b
   204fb:	41 80 fa 01          	cmp    $0x1,%r10b
   204ff:	75 09                	jne    2050a <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, usize, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>+0x8ca>
   20501:	45 84 c9             	test   %r9b,%r9b
   20504:	0f 85 76 fc ff ff    	jne    20180 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, usize, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>+0x540>
   2050a:	f2 0f 10 05 26 6a fe 	movsd  -0x195da(%rip),%xmm0        # 6f38 <std::thread::current::id::ID+0x62c0>
   20511:	ff 
   20512:	66 0f 28 54 24 20    	movapd 0x20(%rsp),%xmm2
   20518:	66 0f 2e d0          	ucomisd %xmm0,%xmm2
   2051c:	75 05                	jne    20523 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, usize, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>+0x8e3>
   2051e:	66 45 0f 57 c9       	xorpd  %xmm9,%xmm9
   20523:	66 44 0f 28 84 24 f0 	movapd 0xf0(%rsp),%xmm8
   2052a:	00 00 00 
   2052d:	66 0f 28 84 24 90 00 	movapd 0x90(%rsp),%xmm0
   20534:	00 00 
   20536:	f2 0f 10 1d fa 69 fe 	movsd  -0x19606(%rip),%xmm3        # 6f38 <std::thread::current::id::ID+0x62c0>
   2053d:	ff 
   2053e:	66 0f 28 94 24 a0 00 	movapd 0xa0(%rsp),%xmm2
   20545:	00 00 
   20547:	66 0f 2e d3          	ucomisd %xmm3,%xmm2
   2054b:	66 44 0f 28 9c 24 b0 	movapd 0xb0(%rsp),%xmm11
   20552:	00 00 00 
   20555:	66 41 0f 28 db       	movapd %xmm11,%xmm3
   2055a:	66 0f 28 b4 24 10 01 	movapd 0x110(%rsp),%xmm6
   20561:	00 00 
   20563:	66 0f 5d de          	minpd  %xmm6,%xmm3
   20567:	66 0f 28 d3          	movapd %xmm3,%xmm2
   2056b:	66 0f c2 d3 03       	cmpunordpd %xmm3,%xmm2
   20570:	66 41 0f 28 e3       	movapd %xmm11,%xmm4
   20575:	66 0f 54 e2          	andpd  %xmm2,%xmm4
   20579:	66 0f 55 d3          	andnpd %xmm3,%xmm2
   2057d:	66 0f 56 d4          	orpd   %xmm4,%xmm2
   20581:	66 0f 28 64 24 60    	movapd 0x60(%rsp),%xmm4
   20587:	66 0f 28 dc          	movapd %xmm4,%xmm3
   2058b:	66 0f 5d 9c 24 e0 00 	minpd  0xe0(%rsp),%xmm3
   20592:	00 00 
   20594:	66 44 0f 28 eb       	movapd %xmm3,%xmm13
   20599:	66 44 0f c2 eb 03    	cmpunordpd %xmm3,%xmm13
   2059f:	66 41 0f 54 e5       	andpd  %xmm13,%xmm4
   205a4:	66 44 0f 55 eb       	andnpd %xmm3,%xmm13
   205a9:	66 44 0f 56 ec       	orpd   %xmm4,%xmm13
   205ae:	66 44 0f 28 a4 24 60 	movapd 0x160(%rsp),%xmm12
   205b5:	01 00 00 
   205b8:	66 44 0f 59 e2       	mulpd  %xmm2,%xmm12
   205bd:	66 44 0f 58 a4 24 50 	addpd  0x150(%rsp),%xmm12
   205c4:	01 00 00 
   205c7:	66 44 0f 28 94 24 f0 	movapd 0x1f0(%rsp),%xmm10
   205ce:	01 00 00 
   205d1:	66 44 0f 59 d2       	mulpd  %xmm2,%xmm10
   205d6:	66 44 0f 58 94 24 e0 	addpd  0x1e0(%rsp),%xmm10
   205dd:	01 00 00 
   205e0:	66 0f 28 5c 24 50    	movapd 0x50(%rsp),%xmm3
   205e6:	66 0f 28 25 12 4f fe 	movapd -0x1b0ee(%rip),%xmm4        # 5500 <std::thread::current::id::ID+0x4888>
   205ed:	ff 
   205ee:	66 0f c2 dc 00       	cmpeqpd %xmm4,%xmm3
   205f3:	66 44 0f 28 7c 24 70 	movapd 0x70(%rsp),%xmm15
   205fa:	66 44 0f c2 fc 00    	cmpeqpd %xmm4,%xmm15
   20600:	66 44 0f 54 fb       	andpd  %xmm3,%xmm15
   20605:	66 44 0f c2 de 01    	cmpltpd %xmm6,%xmm11
   2060b:	66 44 0f 54 5c 24 10 	andpd  0x10(%rsp),%xmm11
   20612:	66 44 0f 54 d9       	andpd  %xmm1,%xmm11
   20617:	66 41 0f 28 cb       	movapd %xmm11,%xmm1
   2061c:	66 0f c2 cc 00       	cmpeqpd %xmm4,%xmm1
   20621:	66 45 0f 28 f3       	movapd %xmm11,%xmm14
   20626:	66 44 0f c2 f4 03    	cmpunordpd %xmm4,%xmm14
   2062c:	66 44 0f 56 f1       	orpd   %xmm1,%xmm14
   20631:	66 41 0f 28 ce       	movapd %xmm14,%xmm1
   20636:	66 41 0f 55 cb       	andnpd %xmm11,%xmm1
   2063b:	66 44 0f 59 d2       	mulpd  %xmm2,%xmm10
   20640:	66 44 0f 58 d0       	addpd  %xmm0,%xmm10
   20645:	66 0f 28 a4 24 d0 01 	movapd 0x1d0(%rsp),%xmm4
   2064c:	00 00 
   2064e:	66 0f 59 e2          	mulpd  %xmm2,%xmm4
   20652:	66 0f 28 9c 24 c0 01 	movapd 0x1c0(%rsp),%xmm3
   20659:	00 00 
   2065b:	66 0f 58 dc          	addpd  %xmm4,%xmm3
   2065f:	66 0f 59 da          	mulpd  %xmm2,%xmm3
   20663:	66 0f 28 b4 24 b0 01 	movapd 0x1b0(%rsp),%xmm6
   2066a:	00 00 
   2066c:	66 0f 58 de          	addpd  %xmm6,%xmm3
   20670:	66 0f 28 2d d8 4c fe 	movapd -0x1b328(%rip),%xmm5        # 5350 <std::thread::current::id::ID+0x46d8>
   20677:	ff 
   20678:	66 0f 59 dd          	mulpd  %xmm5,%xmm3
   2067c:	66 44 0f 28 1d 7b 4a 	movapd -0x1b585(%rip),%xmm11        # 5100 <std::thread::current::id::ID+0x4488>
   20683:	fe ff 
   20685:	66 45 0f 54 d3       	andpd  %xmm11,%xmm10
   2068a:	66 44 0f 58 d3       	addpd  %xmm3,%xmm10
   2068f:	66 0f 28 9c 24 40 01 	movapd 0x140(%rsp),%xmm3
   20696:	00 00 
   20698:	66 41 0f 59 dd       	mulpd  %xmm13,%xmm3
   2069d:	66 0f 58 9c 24 30 01 	addpd  0x130(%rsp),%xmm3
   206a4:	00 00 
   206a6:	66 44 0f 59 e2       	mulpd  %xmm2,%xmm12
   206ab:	66 44 0f 58 e6       	addpd  %xmm6,%xmm12
   206b0:	66 44 0f 59 e2       	mulpd  %xmm2,%xmm12
   206b5:	66 44 0f 58 a4 24 40 	addpd  0x240(%rsp),%xmm12
   206bc:	02 00 00 
   206bf:	66 44 0f 59 e5       	mulpd  %xmm5,%xmm12
   206c4:	66 44 0f 59 d1       	mulpd  %xmm1,%xmm10
   206c9:	66 45 0f 58 d4       	addpd  %xmm12,%xmm10
   206ce:	66 0f 58 a4 24 50 01 	addpd  0x150(%rsp),%xmm4
   206d5:	00 00 
   206d7:	66 0f 28 ac 24 60 01 	movapd 0x160(%rsp),%xmm5
   206de:	00 00 
   206e0:	66 0f 59 e9          	mulpd  %xmm1,%xmm5
   206e4:	66 0f 58 ec          	addpd  %xmm4,%xmm5
   206e8:	66 0f 28 a4 24 a0 01 	movapd 0x1a0(%rsp),%xmm4
   206ef:	00 00 
   206f1:	66 0f 59 e2          	mulpd  %xmm2,%xmm4
   206f5:	66 0f 58 a4 24 90 01 	addpd  0x190(%rsp),%xmm4
   206fc:	00 00 
   206fe:	66 0f 59 e2          	mulpd  %xmm2,%xmm4
   20702:	66 0f 58 e0          	addpd  %xmm0,%xmm4
   20706:	66 0f 59 e2          	mulpd  %xmm2,%xmm4
   2070a:	66 0f 58 a4 24 80 01 	addpd  0x180(%rsp),%xmm4
   20711:	00 00 
   20713:	66 0f 59 e9          	mulpd  %xmm1,%xmm5
   20717:	66 0f 59 e9          	mulpd  %xmm1,%xmm5
   2071b:	66 41 0f 58 ea       	addpd  %xmm10,%xmm5
   20720:	66 0f 29 54 24 30    	movapd %xmm2,0x30(%rsp)
   20726:	66 0f 5c d1          	subpd  %xmm1,%xmm2
   2072a:	66 0f 29 54 24 20    	movapd %xmm2,0x20(%rsp)
   20730:	66 0f 28 cc          	movapd %xmm4,%xmm1
   20734:	66 41 0f 54 cb       	andpd  %xmm11,%xmm1
   20739:	66 0f c2 cd 02       	cmplepd %xmm5,%xmm1
   2073e:	66 44 0f 29 b4 24 b0 	movapd %xmm14,0xb0(%rsp)
   20745:	00 00 00 
   20748:	66 41 0f 56 ce       	orpd   %xmm14,%xmm1
   2074d:	66 0f c2 ec 01       	cmpltpd %xmm4,%xmm5
   20752:	66 0f 29 8c 24 a0 00 	movapd %xmm1,0xa0(%rsp)
   20759:	00 00 
   2075b:	66 0f 55 cd          	andnpd %xmm5,%xmm1
   2075f:	66 44 0f 28 a4 24 90 	movapd 0x290(%rsp),%xmm12
   20766:	02 00 00 
   20769:	66 45 0f 59 e5       	mulpd  %xmm13,%xmm12
   2076e:	66 44 0f 58 a4 24 70 	addpd  0x270(%rsp),%xmm12
   20775:	02 00 00 
   20778:	66 44 0f 29 bc 24 00 	movapd %xmm15,0x100(%rsp)
   2077f:	01 00 00 
   20782:	66 41 0f 54 cf       	andpd  %xmm15,%xmm1
   20787:	66 0f 29 8c 24 80 00 	movapd %xmm1,0x80(%rsp)
   2078e:	00 00 
   20790:	66 0f 28 a4 24 c0 00 	movapd 0xc0(%rsp),%xmm4
   20797:	00 00 
   20799:	f2 0f c2 a4 24 20 01 	cmpnltsd 0x120(%rsp),%xmm4
   207a0:	00 00 05 
   207a3:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   207a7:	74 04                	je     207ad <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, usize, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>+0xb6d>
   207a9:	66 0f 28 cf          	movapd %xmm7,%xmm1
   207ad:	66 0f 55 e1          	andnpd %xmm1,%xmm4
   207b1:	66 0f 28 4c 24 40    	movapd 0x40(%rsp),%xmm1
   207b7:	66 0f 28 15 41 4d fe 	movapd -0x1b2bf(%rip),%xmm2        # 5500 <std::thread::current::id::ID+0x4888>
   207be:	ff 
   207bf:	66 0f c2 ca 00       	cmpeqpd %xmm2,%xmm1
   207c4:	66 44 0f 28 bc 24 d0 	movapd 0xd0(%rsp),%xmm15
   207cb:	00 00 00 
   207ce:	66 44 0f c2 fa 00    	cmpeqpd %xmm2,%xmm15
   207d4:	66 44 0f 54 f9       	andpd  %xmm1,%xmm15
   207d9:	66 0f 28 54 24 60    	movapd 0x60(%rsp),%xmm2
   207df:	f2 0f c2 94 24 e0 00 	cmpnltsd 0xe0(%rsp),%xmm2
   207e6:	00 00 05 
   207e9:	66 41 0f 55 d1       	andnpd %xmm9,%xmm2
   207ee:	31 c9                	xor    %ecx,%ecx
   207f0:	f2 0f 10 0d 40 67 fe 	movsd  -0x198c0(%rip),%xmm1        # 6f38 <std::thread::current::id::ID+0x62c0>
   207f7:	ff 
   207f8:	66 0f 2e e1          	ucomisd %xmm1,%xmm4
   207fc:	0f 94 c1             	sete   %cl
   207ff:	45 31 c9             	xor    %r9d,%r9d
   20802:	66 0f 2e d1          	ucomisd %xmm1,%xmm2
   20806:	41 0f 94 c1          	sete   %r9b
   2080a:	66 41 0f 6e c9       	movd   %r9d,%xmm1
   2080f:	66 0f c4 c9 04       	pinsrw $0x4,%ecx,%xmm1
   20814:	66 44 0f 70 d1 a0    	pshufd $0xa0,%xmm1,%xmm10
   2081a:	66 41 0f 72 f2 1f    	pslld  $0x1f,%xmm10
   20820:	66 41 0f 72 e2 1f    	psrad  $0x1f,%xmm10
   20826:	66 0f 14 d4          	unpcklpd %xmm4,%xmm2
   2082a:	66 45 0f 6f ca       	movdqa %xmm10,%xmm9
   2082f:	66 44 0f df ca       	pandn  %xmm2,%xmm9
   20834:	66 45 0f 59 e5       	mulpd  %xmm13,%xmm12
   20839:	66 0f 28 ac 24 70 01 	movapd 0x170(%rsp),%xmm5
   20840:	00 00 
   20842:	66 44 0f 58 e5       	addpd  %xmm5,%xmm12
   20847:	66 0f 28 94 24 b0 02 	movapd 0x2b0(%rsp),%xmm2
   2084e:	00 00 
   20850:	66 41 0f 59 d5       	mulpd  %xmm13,%xmm2
   20855:	66 0f 28 a4 24 60 02 	movapd 0x260(%rsp),%xmm4
   2085c:	00 00 
   2085e:	66 0f 58 e2          	addpd  %xmm2,%xmm4
   20862:	66 41 0f 59 e5       	mulpd  %xmm13,%xmm4
   20867:	66 44 0f 29 6c 24 10 	movapd %xmm13,0x10(%rsp)
   2086e:	66 0f 28 b4 24 50 02 	movapd 0x250(%rsp),%xmm6
   20875:	00 00 
   20877:	66 0f 58 e6          	addpd  %xmm6,%xmm4
   2087b:	66 0f 28 3d cd 4a fe 	movapd -0x1b533(%rip),%xmm7        # 5350 <std::thread::current::id::ID+0x46d8>
   20882:	ff 
   20883:	66 0f 59 e7          	mulpd  %xmm7,%xmm4
   20887:	66 44 0f 28 35 70 48 	movapd -0x1b790(%rip),%xmm14        # 5100 <std::thread::current::id::ID+0x4488>
   2088e:	fe ff 
   20890:	66 45 0f 54 e6       	andpd  %xmm14,%xmm12
   20895:	66 44 0f 58 e4       	addpd  %xmm4,%xmm12
   2089a:	66 0f 59 5c 24 10    	mulpd  0x10(%rsp),%xmm3
   208a0:	66 0f 58 de          	addpd  %xmm6,%xmm3
   208a4:	66 0f 28 74 24 10    	movapd 0x10(%rsp),%xmm6
   208aa:	66 0f 59 de          	mulpd  %xmm6,%xmm3
   208ae:	66 0f 58 9c 24 30 02 	addpd  0x230(%rsp),%xmm3
   208b5:	00 00 
   208b7:	66 0f 59 df          	mulpd  %xmm7,%xmm3
   208bb:	66 45 0f 59 e1       	mulpd  %xmm9,%xmm12
   208c0:	66 44 0f 58 e3       	addpd  %xmm3,%xmm12
   208c5:	66 0f 58 94 24 30 01 	addpd  0x130(%rsp),%xmm2
   208cc:	00 00 
   208ce:	66 0f 28 a4 24 40 01 	movapd 0x140(%rsp),%xmm4
   208d5:	00 00 
   208d7:	66 41 0f 59 e1       	mulpd  %xmm9,%xmm4
   208dc:	66 0f 58 e2          	addpd  %xmm2,%xmm4
   208e0:	66 41 0f 28 d8       	movapd %xmm8,%xmm3
   208e5:	66 0f 59 de          	mulpd  %xmm6,%xmm3
   208e9:	66 0f 28 bc 24 80 02 	movapd 0x280(%rsp),%xmm7
   208f0:	00 00 
   208f2:	66 0f 58 df          	addpd  %xmm7,%xmm3
   208f6:	66 0f 59 de          	mulpd  %xmm6,%xmm3
   208fa:	66 0f 58 dd          	addpd  %xmm5,%xmm3
   208fe:	66 0f 59 de          	mulpd  %xmm6,%xmm3
   20902:	66 0f 28 ac 24 a0 02 	movapd 0x2a0(%rsp),%xmm5
   20909:	00 00 
   2090b:	66 0f 58 dd          	addpd  %xmm5,%xmm3
   2090f:	66 41 0f 59 e1       	mulpd  %xmm9,%xmm4
   20914:	44 0f 29 4c 24 60    	movaps %xmm9,0x60(%rsp)
   2091a:	66 41 0f 59 e1       	mulpd  %xmm9,%xmm4
   2091f:	66 41 0f 58 e4       	addpd  %xmm12,%xmm4
   20924:	66 44 0f 28 cb       	movapd %xmm3,%xmm9
   20929:	66 45 0f 54 ce       	andpd  %xmm14,%xmm9
   2092e:	66 44 0f c2 cc 02    	cmplepd %xmm4,%xmm9
   20934:	66 44 0f 56 c9       	orpd   %xmm1,%xmm9
   20939:	66 0f c2 e3 01       	cmpltpd %xmm3,%xmm4
   2093e:	66 45 0f 28 e1       	movapd %xmm9,%xmm12
   20943:	66 44 0f 55 e4       	andnpd %xmm4,%xmm12
   20948:	66 45 0f 54 e7       	andpd  %xmm15,%xmm12
   2094d:	66 0f 6f 9c 24 80 00 	movdqa 0x80(%rsp),%xmm3
   20954:	00 00 
   20956:	66 0f 70 cb ee       	pshufd $0xee,%xmm3,%xmm1
   2095b:	66 0f eb cb          	por    %xmm3,%xmm1
   2095f:	66 41 0f eb cc       	por    %xmm12,%xmm1
   20964:	66 0f 7e c9          	movd   %xmm1,%ecx
   20968:	66 0f ef c9          	pxor   %xmm1,%xmm1
   2096c:	66 0f 28 54 24 20    	movapd 0x20(%rsp),%xmm2
   20972:	66 0f 5f d1          	maxpd  %xmm1,%xmm2
   20976:	f6 c1 01             	test   $0x1,%cl
   20979:	0f 84 e1 f5 ff ff    	je     1ff60 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, usize, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>+0x320>
   2097f:	66 44 0f 29 8c 24 10 	movapd %xmm9,0x210(%rsp)
   20986:	02 00 00 
   20989:	66 44 0f 7f 94 24 20 	movdqa %xmm10,0x220(%rsp)
   20990:	02 00 00 
   20993:	66 44 0f 29 bc 24 c0 	movapd %xmm15,0xc0(%rsp)
   2099a:	00 00 00 
   2099d:	66 0f 29 54 24 20    	movapd %xmm2,0x20(%rsp)
   209a3:	66 44 0f 6f cb       	movdqa %xmm3,%xmm9
   209a8:	66 0f 6f 0d 10 4c fe 	movdqa -0x1b3f0(%rip),%xmm1        # 55c0 <std::thread::current::id::ID+0x4948>
   209af:	ff 
   209b0:	66 44 0f ef c9       	pxor   %xmm1,%xmm9
   209b5:	66 45 0f 6f ec       	movdqa %xmm12,%xmm13
   209ba:	66 44 0f ef e9       	pxor   %xmm1,%xmm13
   209bf:	66 41 0f 70 cc ee    	pshufd $0xee,%xmm12,%xmm1
   209c5:	66 48 0f 7e c9       	movq   %xmm1,%rcx
   209ca:	66 44 0f 6f f3       	movdqa %xmm3,%xmm14
   209cf:	44 0f 29 a4 24 00 02 	movaps %xmm12,0x200(%rsp)
   209d6:	00 00 
   209d8:	45 0f c6 f4 88       	shufps $0x88,%xmm12,%xmm14
   209dd:	4d 89 c1             	mov    %r8,%r9
   209e0:	66 44 0f 28 5c 24 30 	movapd 0x30(%rsp),%xmm11
   209e7:	66 0f 28 ce          	movapd %xmm6,%xmm1
   209eb:	66 0f 28 d5          	movapd %xmm5,%xmm2
   209ef:	66 0f 28 df          	movapd %xmm7,%xmm3
   209f3:	66 0f 28 35 f5 47 fe 	movapd -0x1b80b(%rip),%xmm6        # 51f0 <std::thread::current::id::ID+0x4578>
   209fa:	ff 
   209fb:	66 44 0f 28 94 24 d0 	movapd 0x2d0(%rsp),%xmm10
   20a02:	02 00 00 
   20a05:	66 44 0f 28 bc 24 c0 	movapd 0x2c0(%rsp),%xmm15
   20a0c:	02 00 00 
   20a0f:	90                   	nop
   20a10:	66 41 0f 28 fb       	movapd %xmm11,%xmm7
   20a15:	66 41 0f 5c ff       	subpd  %xmm15,%xmm7
   20a1a:	66 44 0f 28 e1       	movapd %xmm1,%xmm12
   20a1f:	66 45 0f 5c e2       	subpd  %xmm10,%xmm12
   20a24:	66 0f 59 fe          	mulpd  %xmm6,%xmm7
   20a28:	66 41 0f 58 ff       	addpd  %xmm15,%xmm7
   20a2d:	66 0f 28 a4 24 a0 01 	movapd 0x1a0(%rsp),%xmm4
   20a34:	00 00 
   20a36:	66 0f 59 e7          	mulpd  %xmm7,%xmm4
   20a3a:	66 0f 58 a4 24 90 01 	addpd  0x190(%rsp),%xmm4
   20a41:	00 00 
   20a43:	66 0f 59 e7          	mulpd  %xmm7,%xmm4
   20a47:	66 0f 58 e0          	addpd  %xmm0,%xmm4
   20a4b:	66 0f 59 e7          	mulpd  %xmm7,%xmm4
   20a4f:	66 0f 58 a4 24 80 01 	addpd  0x180(%rsp),%xmm4
   20a56:	00 00 
   20a58:	66 41 0f 28 c2       	movapd %xmm10,%xmm0
   20a5d:	66 45 0f 57 d2       	xorpd  %xmm10,%xmm10
   20a62:	66 44 0f c2 d4 01    	cmpltpd %xmm4,%xmm10
   20a68:	66 41 0f 28 e2       	movapd %xmm10,%xmm4
   20a6d:	66 41 0f 56 e1       	orpd   %xmm9,%xmm4
   20a72:	66 41 0f 28 ef       	movapd %xmm15,%xmm5
   20a77:	66 44 0f 70 fc a0    	pshufd $0xa0,%xmm4,%xmm15
   20a7d:	66 41 0f 72 f7 1f    	pslld  $0x1f,%xmm15
   20a83:	66 41 0f 72 e7 1f    	psrad  $0x1f,%xmm15
   20a89:	66 41 0f 54 ef       	andpd  %xmm15,%xmm5
   20a8e:	66 44 0f 55 ff       	andnpd %xmm7,%xmm15
   20a93:	66 0f 28 35 55 47 fe 	movapd -0x1b8ab(%rip),%xmm6        # 51f0 <std::thread::current::id::ID+0x4578>
   20a9a:	ff 
   20a9b:	66 44 0f 59 e6       	mulpd  %xmm6,%xmm12
   20aa0:	66 44 0f 58 e0       	addpd  %xmm0,%xmm12
   20aa5:	66 41 0f 28 e0       	movapd %xmm8,%xmm4
   20aaa:	66 41 0f 59 e4       	mulpd  %xmm12,%xmm4
   20aaf:	66 0f 58 e3          	addpd  %xmm3,%xmm4
   20ab3:	66 41 0f 59 e4       	mulpd  %xmm12,%xmm4
   20ab8:	66 0f 58 a4 24 70 01 	addpd  0x170(%rsp),%xmm4
   20abf:	00 00 
   20ac1:	66 41 0f 59 e4       	mulpd  %xmm12,%xmm4
   20ac6:	66 0f 58 e2          	addpd  %xmm2,%xmm4
   20aca:	66 45 0f 57 c0       	xorpd  %xmm8,%xmm8
   20acf:	66 44 0f c2 c4 01    	cmpltpd %xmm4,%xmm8
   20ad5:	66 45 0f c5 d0 04    	pextrw $0x4,%xmm8,%r10d
   20adb:	66 44 0f 56 fd       	orpd   %xmm5,%xmm15
   20ae0:	41 20 ca             	and    %cl,%r10b
   20ae3:	45 0f b6 d2          	movzbl %r10b,%r10d
   20ae7:	66 41 0f 6e e2       	movd   %r10d,%xmm4
   20aec:	41 0f c6 e6 e4       	shufps $0xe4,%xmm14,%xmm4
   20af1:	41 0f 28 ee          	movaps %xmm14,%xmm5
   20af5:	0f c6 ec 24          	shufps $0x24,%xmm4,%xmm5
   20af9:	66 0f 6e e6          	movd   %esi,%xmm4
   20afd:	66 41 0f 6c e0       	punpcklqdq %xmm8,%xmm4
   20b02:	44 0f c6 d4 28       	shufps $0x28,%xmm4,%xmm10
   20b07:	44 0f 54 d5          	andps  %xmm5,%xmm10
   20b0b:	66 41 0f 70 e2 fa    	pshufd $0xfa,%xmm10,%xmm4
   20b11:	66 0f 72 f4 1f       	pslld  $0x1f,%xmm4
   20b16:	66 0f 72 e4 1f       	psrad  $0x1f,%xmm4
   20b1b:	66 45 0f eb c5       	por    %xmm13,%xmm8
   20b20:	66 0f 28 e8          	movapd %xmm0,%xmm5
   20b24:	66 41 0f 70 c0 a0    	pshufd $0xa0,%xmm8,%xmm0
   20b2a:	66 44 0f 28 84 24 f0 	movapd 0xf0(%rsp),%xmm8
   20b31:	00 00 00 
   20b34:	66 0f 72 f0 1f       	pslld  $0x1f,%xmm0
   20b39:	66 0f 72 e0 1f       	psrad  $0x1f,%xmm0
   20b3e:	66 0f 54 e8          	andpd  %xmm0,%xmm5
   20b42:	66 41 0f 55 c4       	andnpd %xmm12,%xmm0
   20b47:	66 44 0f 54 e4       	andpd  %xmm4,%xmm12
   20b4c:	66 0f 55 e1          	andnpd %xmm1,%xmm4
   20b50:	66 41 0f 56 e4       	orpd   %xmm12,%xmm4
   20b55:	66 41 0f 70 ca 50    	pshufd $0x50,%xmm10,%xmm1
   20b5b:	66 0f 72 f1 1f       	pslld  $0x1f,%xmm1
   20b60:	66 0f 72 e1 1f       	psrad  $0x1f,%xmm1
   20b65:	66 0f 54 f9          	andpd  %xmm1,%xmm7
   20b69:	66 41 0f 55 cb       	andnpd %xmm11,%xmm1
   20b6e:	66 0f 56 cf          	orpd   %xmm7,%xmm1
   20b72:	66 44 0f 28 d0       	movapd %xmm0,%xmm10
   20b77:	66 0f 28 84 24 90 00 	movapd 0x90(%rsp),%xmm0
   20b7e:	00 00 
   20b80:	66 44 0f 56 d5       	orpd   %xmm5,%xmm10
   20b85:	66 44 0f 28 d9       	movapd %xmm1,%xmm11
   20b8a:	66 0f 28 cc          	movapd %xmm4,%xmm1
   20b8e:	49 ff c9             	dec    %r9
   20b91:	0f 85 79 fe ff ff    	jne    20a10 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, usize, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>+0xdd0>
   20b97:	66 0f 28 84 24 80 00 	movapd 0x80(%rsp),%xmm0
   20b9e:	00 00 
   20ba0:	66 44 0f 54 f8       	andpd  %xmm0,%xmm15
   20ba5:	66 0f 55 44 24 50    	andnpd 0x50(%rsp),%xmm0
   20bab:	66 41 0f 56 c7       	orpd   %xmm15,%xmm0
   20bb0:	66 0f 70 8c 24 00 02 	pshufd $0xa0,0x200(%rsp),%xmm1
   20bb7:	00 00 a0 
   20bba:	66 0f 72 f1 1f       	pslld  $0x1f,%xmm1
   20bbf:	66 0f 72 e1 1f       	psrad  $0x1f,%xmm1
   20bc4:	66 44 0f 54 d1       	andpd  %xmm1,%xmm10
   20bc9:	66 0f 55 4c 24 40    	andnpd 0x40(%rsp),%xmm1
   20bcf:	66 41 0f 56 ca       	orpd   %xmm10,%xmm1
   20bd4:	66 0f 29 44 24 50    	movapd %xmm0,0x50(%rsp)
   20bda:	66 0f 29 4c 24 40    	movapd %xmm1,0x40(%rsp)
   20be0:	66 44 0f 28 35 17 45 	movapd -0x1bae9(%rip),%xmm14        # 5100 <std::thread::current::id::ID+0x4488>
   20be7:	fe ff 
   20be9:	66 0f 6f a4 24 d0 00 	movdqa 0xd0(%rsp),%xmm4
   20bf0:	00 00 
   20bf2:	66 44 0f 28 5c 24 30 	movapd 0x30(%rsp),%xmm11
   20bf9:	66 0f 28 74 24 10    	movapd 0x10(%rsp),%xmm6
   20bff:	66 0f 28 54 24 20    	movapd 0x20(%rsp),%xmm2
   20c05:	66 44 0f 28 bc 24 c0 	movapd 0xc0(%rsp),%xmm15
   20c0c:	00 00 00 
   20c0f:	66 44 0f 6f 94 24 20 	movdqa 0x220(%rsp),%xmm10
   20c16:	02 00 00 
   20c19:	66 44 0f 28 8c 24 10 	movapd 0x210(%rsp),%xmm9
   20c20:	02 00 00 
   20c23:	e9 48 f3 ff ff       	jmp    1ff70 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, usize, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>+0x330>
   20c28:	0f 28 44 24 50       	movaps 0x50(%rsp),%xmm0
   20c2d:	0f 29 07             	movaps %xmm0,(%rdi)
   20c30:	0f 28 44 24 40       	movaps 0x40(%rsp),%xmm0
   20c35:	0f 29 47 10          	movaps %xmm0,0x10(%rdi)
   20c39:	0f 28 44 24 70       	movaps 0x70(%rsp),%xmm0
   20c3e:	0f 29 47 20          	movaps %xmm0,0x20(%rdi)
   20c42:	66 0f 29 4f 30       	movapd %xmm1,0x30(%rdi)
   20c47:	48 89 ec             	mov    %rbp,%rsp
   20c4a:	5d                   	pop    %rbp
   20c4b:	c3                   	ret
   20c4c:	cc                   	int3
   20c4d:	cc                   	int3
   20c4e:	cc                   	int3
   20c4f:	cc                   	int3

gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>:
   20c50:	55                   	push   %rbp
   20c51:	48 89 e5             	mov    %rsp,%rbp
   20c54:	41 57                	push   %r15
   20c56:	41 56                	push   %r14
   20c58:	41 55                	push   %r13
   20c5a:	41 54                	push   %r12
   20c5c:	53                   	push   %rbx
   20c5d:	48 83 e4 e0          	and    $0xffffffffffffffe0,%rsp
   20c61:	48 81 ec 60 02 00 00 	sub    $0x260,%rsp
   20c68:	f3 0f 11 44 24 0c    	movss  %xmm0,0xc(%rsp)
   20c6e:	89 fb                	mov    %edi,%ebx
   20c70:	0f 29 4c 24 40       	movaps %xmm1,0x40(%rsp)
   20c75:	0f 57 c0             	xorps  %xmm0,%xmm0
   20c78:	f3 0f 5a c1          	cvtss2sd %xmm1,%xmm0
   20c7c:	f2 0f 59 05 c4 63 fe 	mulsd  -0x19c3c(%rip),%xmm0        # 7048 <std::thread::current::id::ID+0x63d0>
   20c83:	ff 
   20c84:	48 8d bc 24 98 00 00 	lea    0x98(%rsp),%rdi
   20c8b:	00 
   20c8c:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
   20c93:	00 
   20c94:	ff 15 76 31 04 00    	call   *0x43176(%rip)        # 63e10 <sincos@GLIBC_2.2.5>
   20c9a:	f2 0f 10 84 24 98 00 	movsd  0x98(%rsp),%xmm0
   20ca1:	00 00 
   20ca3:	f2 0f 10 8c 24 90 00 	movsd  0x90(%rsp),%xmm1
   20caa:	00 00 
   20cac:	f2 0f 10 15 8c 63 fe 	movsd  -0x19c74(%rip),%xmm2        # 7040 <std::thread::current::id::ID+0x63c8>
   20cb3:	ff 
   20cb4:	f2 0f 59 d1          	mulsd  %xmm1,%xmm2
   20cb8:	66 0f 57 e4          	xorpd  %xmm4,%xmm4
   20cbc:	f2 0f 58 d4          	addsd  %xmm4,%xmm2
   20cc0:	f2 0f 10 1d f8 62 fe 	movsd  -0x19d08(%rip),%xmm3        # 6fc0 <std::thread::current::id::ID+0x6348>
   20cc7:	ff 
   20cc8:	f2 0f 59 d9          	mulsd  %xmm1,%xmm3
   20ccc:	f2 0f 58 dc          	addsd  %xmm4,%xmm3
   20cd0:	f2 44 0f 10 0d 17 63 	movsd  -0x19ce9(%rip),%xmm9        # 6ff0 <std::thread::current::id::ID+0x6378>
   20cd7:	fe ff 
   20cd9:	f2 44 0f 59 c8       	mulsd  %xmm0,%xmm9
   20cde:	f2 44 0f 58 ca       	addsd  %xmm2,%xmm9
   20ce3:	f2 0f 10 2d 85 63 fe 	movsd  -0x19c7b(%rip),%xmm5        # 7070 <std::thread::current::id::ID+0x63f8>
   20cea:	ff 
   20ceb:	f2 0f 59 e8          	mulsd  %xmm0,%xmm5
   20cef:	f2 0f 58 eb          	addsd  %xmm3,%xmm5
   20cf3:	f2 0f 59 0d 35 63 fe 	mulsd  -0x19ccb(%rip),%xmm1        # 7030 <std::thread::current::id::ID+0x63b8>
   20cfa:	ff 
   20cfb:	f2 0f 58 cc          	addsd  %xmm4,%xmm1
   20cff:	f2 0f 59 05 f1 61 fe 	mulsd  -0x19e0f(%rip),%xmm0        # 6ef8 <std::thread::current::id::ID+0x6280>
   20d06:	ff 
   20d07:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
   20d0b:	85 db                	test   %ebx,%ebx
   20d0d:	74 3f                	je     20d4e <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xfe>
   20d0f:	0f 28 0d 6a 48 fe ff 	movaps -0x1b796(%rip),%xmm1        # 5580 <std::thread::current::id::ID+0x4908>
   20d16:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
   20d1b:	66 0f 28 0d ad 48 fe 	movapd -0x1b753(%rip),%xmm1        # 55d0 <std::thread::current::id::ID+0x4958>
   20d22:	ff 
   20d23:	66 0f 28 25 f5 44 fe 	movapd -0x1bb0b(%rip),%xmm4        # 5220 <std::thread::current::id::ID+0x45a8>
   20d2a:	ff 
   20d2b:	66 0f 28 35 ad 48 fe 	movapd -0x1b753(%rip),%xmm6        # 55e0 <std::thread::current::id::ID+0x4968>
   20d32:	ff 
   20d33:	f3 0f 7e 1d f5 61 fe 	movq   -0x19e0b(%rip),%xmm3        # 6f30 <std::thread::current::id::ID+0x62b8>
   20d3a:	ff 
   20d3b:	f2 44 0f 10 3d 94 62 	movsd  -0x19d6c(%rip),%xmm15        # 6fd8 <std::thread::current::id::ID+0x6360>
   20d42:	fe ff 
   20d44:	f3 0f 7e 15 f4 61 fe 	movq   -0x19e0c(%rip),%xmm2        # 6f40 <std::thread::current::id::ID+0x62c8>
   20d4b:	ff 
   20d4c:	eb 3d                	jmp    20d8b <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0x13b>
   20d4e:	0f 28 0d ab 44 fe ff 	movaps -0x1bb55(%rip),%xmm1        # 5200 <std::thread::current::id::ID+0x4588>
   20d55:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
   20d5a:	66 0f 28 0d fe 45 fe 	movapd -0x1ba02(%rip),%xmm1        # 5360 <std::thread::current::id::ID+0x46e8>
   20d61:	ff 
   20d62:	66 0f 28 25 56 44 fe 	movapd -0x1bbaa(%rip),%xmm4        # 51c0 <std::thread::current::id::ID+0x4548>
   20d69:	ff 
   20d6a:	66 0f 28 35 fe 47 fe 	movapd -0x1b802(%rip),%xmm6        # 5570 <std::thread::current::id::ID+0x48f8>
   20d71:	ff 
   20d72:	f3 0f 7e 1d a6 62 fe 	movq   -0x19d5a(%rip),%xmm3        # 7020 <std::thread::current::id::ID+0x63a8>
   20d79:	ff 
   20d7a:	f2 44 0f 10 3d 8d 62 	movsd  -0x19d73(%rip),%xmm15        # 7010 <std::thread::current::id::ID+0x6398>
   20d81:	fe ff 
   20d83:	f3 0f 7e 15 1d 62 fe 	movq   -0x19de3(%rip),%xmm2        # 6fa8 <std::thread::current::id::ID+0x6330>
   20d8a:	ff 
   20d8b:	66 0f 7f 54 24 20    	movdqa %xmm2,0x20(%rsp)
   20d91:	66 44 0f 14 cd       	unpcklpd %xmm5,%xmm9
   20d96:	66 45 0f 28 d9       	movapd %xmm9,%xmm11
   20d9b:	66 45 0f 59 d9       	mulpd  %xmm9,%xmm11
   20da0:	66 0f 28 e8          	movapd %xmm0,%xmm5
   20da4:	f2 0f 59 e8          	mulsd  %xmm0,%xmm5
   20da8:	f2 0f 59 e8          	mulsd  %xmm0,%xmm5
   20dac:	66 45 0f 59 d9       	mulpd  %xmm9,%xmm11
   20db1:	66 41 0f 28 fb       	movapd %xmm11,%xmm7
   20db6:	66 41 0f c6 fb 01    	shufpd $0x1,%xmm11,%xmm7
   20dbc:	66 0f 59 fc          	mulpd  %xmm4,%xmm7
   20dc0:	66 45 0f 28 c3       	movapd %xmm11,%xmm8
   20dc5:	66 44 0f 59 c6       	mulpd  %xmm6,%xmm8
   20dca:	66 44 0f 58 c7       	addpd  %xmm7,%xmm8
   20dcf:	66 0f 14 ed          	unpcklpd %xmm5,%xmm5
   20dd3:	66 44 0f 28 f5       	movapd %xmm5,%xmm14
   20dd8:	66 44 0f 59 f1       	mulpd  %xmm1,%xmm14
   20ddd:	66 45 0f 58 f0       	addpd  %xmm8,%xmm14
   20de2:	f3 0f 7e fa          	movq   %xmm2,%xmm7
   20de6:	66 0f 59 ef          	mulpd  %xmm7,%xmm5
   20dea:	66 45 0f 57 c0       	xorpd  %xmm8,%xmm8
   20def:	66 45 0f 14 c7       	unpcklpd %xmm15,%xmm8
   20df4:	66 41 0f 28 d3       	movapd %xmm11,%xmm2
   20df9:	66 45 0f 59 d8       	mulpd  %xmm8,%xmm11
   20dfe:	66 45 0f c6 db 01    	shufpd $0x1,%xmm11,%xmm11
   20e04:	f3 44 0f 7e d3       	movq   %xmm3,%xmm10
   20e09:	66 41 0f 59 d2       	mulpd  %xmm10,%xmm2
   20e0e:	66 41 0f 58 d3       	addpd  %xmm11,%xmm2
   20e13:	66 0f 58 d5          	addpd  %xmm5,%xmm2
   20e17:	66 0f 29 54 24 70    	movapd %xmm2,0x70(%rsp)
   20e1d:	66 45 0f 28 d9       	movapd %xmm9,%xmm11
   20e22:	66 44 0f 59 1d 45 44 	mulpd  -0x1bbbb(%rip),%xmm11        # 5270 <std::thread::current::id::ID+0x45f8>
   20e29:	fe ff 
   20e2b:	66 45 0f 59 cb       	mulpd  %xmm11,%xmm9
   20e30:	66 0f 6f eb          	movdqa %xmm3,%xmm5
   20e34:	66 41 0f 28 d9       	movapd %xmm9,%xmm3
   20e39:	66 45 0f 28 e1       	movapd %xmm9,%xmm12
   20e3e:	66 45 0f c6 e1 01    	shufpd $0x1,%xmm9,%xmm12
   20e44:	66 44 0f 59 e4       	mulpd  %xmm4,%xmm12
   20e49:	66 45 0f 28 e9       	movapd %xmm9,%xmm13
   20e4e:	66 44 0f 59 ee       	mulpd  %xmm6,%xmm13
   20e53:	66 45 0f 58 ec       	addpd  %xmm12,%xmm13
   20e58:	f2 0f 10 15 68 61 fe 	movsd  -0x19e98(%rip),%xmm2        # 6fc8 <std::thread::current::id::ID+0x6350>
   20e5f:	ff 
   20e60:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
   20e64:	f2 0f 59 c2          	mulsd  %xmm2,%xmm0
   20e68:	66 0f 14 c0          	unpcklpd %xmm0,%xmm0
   20e6c:	66 44 0f 28 c8       	movapd %xmm0,%xmm9
   20e71:	66 44 0f 59 c9       	mulpd  %xmm1,%xmm9
   20e76:	66 45 0f 58 cd       	addpd  %xmm13,%xmm9
   20e7b:	66 44 0f 28 e3       	movapd %xmm3,%xmm12
   20e80:	66 45 0f 59 e0       	mulpd  %xmm8,%xmm12
   20e85:	66 45 0f c6 e4 01    	shufpd $0x1,%xmm12,%xmm12
   20e8b:	66 41 0f 59 da       	mulpd  %xmm10,%xmm3
   20e90:	66 41 0f 58 dc       	addpd  %xmm12,%xmm3
   20e95:	66 0f 59 c7          	mulpd  %xmm7,%xmm0
   20e99:	66 0f 58 d8          	addpd  %xmm0,%xmm3
   20e9d:	66 0f 29 5c 24 60    	movapd %xmm3,0x60(%rsp)
   20ea3:	66 41 0f 28 c3       	movapd %xmm11,%xmm0
   20ea8:	66 41 0f c6 c3 01    	shufpd $0x1,%xmm11,%xmm0
   20eae:	66 0f 59 c4          	mulpd  %xmm4,%xmm0
   20eb2:	66 41 0f 59 f3       	mulpd  %xmm11,%xmm6
   20eb7:	66 0f 58 f0          	addpd  %xmm0,%xmm6
   20ebb:	66 0f 14 d2          	unpcklpd %xmm2,%xmm2
   20ebf:	66 0f 28 c2          	movapd %xmm2,%xmm0
   20ec3:	66 0f 59 c1          	mulpd  %xmm1,%xmm0
   20ec7:	66 0f 58 c6          	addpd  %xmm6,%xmm0
   20ecb:	66 0f 28 f0          	movapd %xmm0,%xmm6
   20ecf:	66 0f 29 44 24 50    	movapd %xmm0,0x50(%rsp)
   20ed5:	66 45 0f 59 c3       	mulpd  %xmm11,%xmm8
   20eda:	66 45 0f c6 c0 01    	shufpd $0x1,%xmm8,%xmm8
   20ee0:	66 45 0f 59 da       	mulpd  %xmm10,%xmm11
   20ee5:	66 45 0f 58 d8       	addpd  %xmm8,%xmm11
   20eea:	66 0f 59 d7          	mulpd  %xmm7,%xmm2
   20eee:	66 41 0f 58 d3       	addpd  %xmm11,%xmm2
   20ef3:	66 0f 29 94 24 80 01 	movapd %xmm2,0x180(%rsp)
   20efa:	00 00 
   20efc:	f2 44 0f 58 fd       	addsd  %xmm5,%xmm15
   20f01:	66 0f 28 44 24 10    	movapd 0x10(%rsp),%xmm0
   20f07:	66 0f 58 c1          	addpd  %xmm1,%xmm0
   20f0b:	66 0f 29 44 24 10    	movapd %xmm0,0x10(%rsp)
   20f11:	f2 44 0f 58 7c 24 20 	addsd  0x20(%rsp),%xmm15
   20f18:	66 44 0f 29 7c 24 20 	movapd %xmm15,0x20(%rsp)
   20f1f:	66 41 0f 28 de       	movapd %xmm14,%xmm3
   20f24:	66 41 0f 28 d6       	movapd %xmm14,%xmm2
   20f29:	66 44 0f 29 b4 24 90 	movapd %xmm14,0x190(%rsp)
   20f30:	01 00 00 
   20f33:	66 0f 59 1d 35 43 fe 	mulpd  -0x1bccb(%rip),%xmm3        # 5270 <std::thread::current::id::ID+0x45f8>
   20f3a:	ff 
   20f3b:	66 45 0f 28 c1       	movapd %xmm9,%xmm8
   20f40:	66 45 0f 28 f9       	movapd %xmm9,%xmm15
   20f45:	66 44 0f 29 8c 24 70 	movapd %xmm9,0x170(%rsp)
   20f4c:	01 00 00 
   20f4f:	66 45 0f 58 c1       	addpd  %xmm9,%xmm8
   20f54:	66 45 0f 28 d0       	movapd %xmm8,%xmm10
   20f59:	66 45 0f 59 d0       	mulpd  %xmm8,%xmm10
   20f5e:	66 0f 59 f3          	mulpd  %xmm3,%xmm6
   20f62:	66 0f 59 35 46 43 fe 	mulpd  -0x1bcba(%rip),%xmm6        # 52b0 <std::thread::current::id::ID+0x4638>
   20f69:	ff 
   20f6a:	66 41 0f 28 fa       	movapd %xmm10,%xmm7
   20f6f:	66 0f 5c fe          	subpd  %xmm6,%xmm7
   20f73:	66 45 0f 28 c8       	movapd %xmm8,%xmm9
   20f78:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
   20f7c:	66 44 0f c2 c8 05    	cmpnltpd %xmm0,%xmm9
   20f82:	66 0f 28 cf          	movapd %xmm7,%xmm1
   20f86:	66 0f 5f c8          	maxpd  %xmm0,%xmm1
   20f8a:	66 0f 57 ed          	xorpd  %xmm5,%xmm5
   20f8e:	66 0f 51 e1          	sqrtpd %xmm1,%xmm4
   20f92:	66 44 0f 28 dc       	movapd %xmm4,%xmm11
   20f97:	66 44 0f 57 1d a0 45 	xorpd  -0x1ba60(%rip),%xmm11        # 5540 <std::thread::current::id::ID+0x48c8>
   20f9e:	fe ff 
   20fa0:	66 41 0f 54 e1       	andpd  %xmm9,%xmm4
   20fa5:	66 45 0f 55 cb       	andnpd %xmm11,%xmm9
   20faa:	66 44 0f 56 cc       	orpd   %xmm4,%xmm9
   20faf:	66 0f 28 05 49 41 fe 	movapd -0x1beb7(%rip),%xmm0        # 5100 <std::thread::current::id::ID+0x4488>
   20fb6:	ff 
   20fb7:	66 0f 54 f0          	andpd  %xmm0,%xmm6
   20fbb:	66 41 0f 58 f2       	addpd  %xmm10,%xmm6
   20fc0:	66 45 0f 57 db       	xorpd  %xmm11,%xmm11
   20fc5:	66 44 0f c2 df 02    	cmplepd %xmm7,%xmm11
   20fcb:	66 0f 54 f8          	andpd  %xmm0,%xmm7
   20fcf:	66 0f 59 35 79 43 fe 	mulpd  -0x1bc87(%rip),%xmm6        # 5350 <std::thread::current::id::ID+0x46d8>
   20fd6:	ff 
   20fd7:	66 0f c2 fe 02       	cmplepd %xmm6,%xmm7
   20fdc:	66 44 0f 28 d3       	movapd %xmm3,%xmm10
   20fe1:	66 44 0f c2 d5 04    	cmpneqpd %xmm5,%xmm10
   20fe7:	66 41 0f 54 da       	andpd  %xmm10,%xmm3
   20fec:	66 41 0f 28 c0       	movapd %xmm8,%xmm0
   20ff1:	66 0f c2 c5 00       	cmpeqpd %xmm5,%xmm0
   20ff6:	66 0f 28 25 82 44 fe 	movapd -0x1bb7e(%rip),%xmm4        # 5480 <std::thread::current::id::ID+0x4808>
   20ffd:	ff 
   20ffe:	66 44 0f 28 f4       	movapd %xmm4,%xmm14
   21003:	66 44 0f 54 f0       	andpd  %xmm0,%xmm14
   21008:	66 45 0f 54 da       	andpd  %xmm10,%xmm11
   2100d:	66 44 0f 28 e0       	movapd %xmm0,%xmm12
   21012:	66 41 0f 56 c2       	orpd   %xmm10,%xmm0
   21017:	66 41 0f 54 fa       	andpd  %xmm10,%xmm7
   2101c:	66 41 0f 28 ca       	movapd %xmm10,%xmm1
   21021:	66 0f 55 cc          	andnpd %xmm4,%xmm1
   21025:	66 0f 56 cb          	orpd   %xmm3,%xmm1
   21029:	66 45 0f 58 c8       	addpd  %xmm8,%xmm9
   2102e:	66 44 0f 28 15 b9 45 	movapd -0x1ba47(%rip),%xmm10        # 55f0 <std::thread::current::id::ID+0x4978>
   21035:	fe ff 
   21037:	66 45 0f 59 ca       	mulpd  %xmm10,%xmm9
   2103c:	66 41 0f 28 d9       	movapd %xmm9,%xmm3
   21041:	66 0f c2 dd 04       	cmpneqpd %xmm5,%xmm3
   21046:	66 41 0f 28 f1       	movapd %xmm9,%xmm6
   2104b:	66 0f 54 f3          	andpd  %xmm3,%xmm6
   2104f:	66 45 0f 70 eb a0    	pshufd $0xa0,%xmm11,%xmm13
   21055:	66 44 0f 54 db       	andpd  %xmm3,%xmm11
   2105a:	66 0f 55 dc          	andnpd %xmm4,%xmm3
   2105e:	66 0f 56 de          	orpd   %xmm6,%xmm3
   21062:	66 45 0f 55 e0       	andnpd %xmm8,%xmm12
   21067:	66 45 0f 56 f4       	orpd   %xmm12,%xmm14
   2106c:	66 44 0f 5e c9       	divpd  %xmm1,%xmm9
   21071:	66 0f 28 ca          	movapd %xmm2,%xmm1
   21075:	66 0f 28 15 c3 44 fe 	movapd -0x1bb3d(%rip),%xmm2        # 5540 <std::thread::current::id::ID+0x48c8>
   2107c:	ff 
   2107d:	66 0f 57 ca          	xorpd  %xmm2,%xmm1
   21081:	66 0f 29 4c 24 30    	movapd %xmm1,0x30(%rsp)
   21087:	66 0f 29 8c 24 a0 00 	movapd %xmm1,0xa0(%rsp)
   2108e:	00 00 
   21090:	66 0f 28 64 24 70    	movapd 0x70(%rsp),%xmm4
   21096:	66 0f 28 cc          	movapd %xmm4,%xmm1
   2109a:	66 0f 57 ca          	xorpd  %xmm2,%xmm1
   2109e:	66 0f 29 8c 24 b0 00 	movapd %xmm1,0xb0(%rsp)
   210a5:	00 00 
   210a7:	66 41 0f 28 f7       	movapd %xmm15,%xmm6
   210ac:	66 44 0f 28 fa       	movapd %xmm2,%xmm15
   210b1:	66 0f 57 f2          	xorpd  %xmm2,%xmm6
   210b5:	66 0f 29 b4 24 c0 00 	movapd %xmm6,0xc0(%rsp)
   210bc:	00 00 
   210be:	66 0f 28 54 24 60    	movapd 0x60(%rsp),%xmm2
   210c4:	66 44 0f 28 c2       	movapd %xmm2,%xmm8
   210c9:	66 45 0f 57 c7       	xorpd  %xmm15,%xmm8
   210ce:	66 44 0f 29 84 24 d0 	movapd %xmm8,0xd0(%rsp)
   210d5:	00 00 00 
   210d8:	66 0f 28 4c 24 50    	movapd 0x50(%rsp),%xmm1
   210de:	66 44 0f 28 c1       	movapd %xmm1,%xmm8
   210e3:	66 45 0f 57 c7       	xorpd  %xmm15,%xmm8
   210e8:	66 44 0f 29 84 24 e0 	movapd %xmm8,0xe0(%rsp)
   210ef:	00 00 00 
   210f2:	66 45 0f 5e c6       	divpd  %xmm14,%xmm8
   210f7:	66 0f 73 f0 3f       	psllq  $0x3f,%xmm0
   210fc:	66 0f 72 e0 1f       	psrad  $0x1f,%xmm0
   21101:	66 44 0f 70 e0 f5    	pshufd $0xf5,%xmm0,%xmm12
   21107:	66 45 0f df e0       	pandn  %xmm8,%xmm12
   2110c:	66 44 0f 6f 35 eb 43 	movdqa -0x1bc15(%rip),%xmm14        # 5500 <std::thread::current::id::ID+0x4888>
   21113:	fe ff 
   21115:	66 41 0f db c6       	pand   %xmm14,%xmm0
   2111a:	66 41 0f eb c4       	por    %xmm12,%xmm0
   2111f:	66 45 0f 54 cd       	andpd  %xmm13,%xmm9
   21124:	66 44 0f df e8       	pandn  %xmm0,%xmm13
   21129:	66 45 0f eb e9       	por    %xmm9,%xmm13
   2112e:	66 0f 28 c1          	movapd %xmm1,%xmm0
   21132:	66 0f 5e c3          	divpd  %xmm3,%xmm0
   21136:	66 41 0f 70 db a0    	pshufd $0xa0,%xmm11,%xmm3
   2113c:	66 0f 54 c3          	andpd  %xmm3,%xmm0
   21140:	66 41 0f df de       	pandn  %xmm14,%xmm3
   21145:	66 0f eb d8          	por    %xmm0,%xmm3
   21149:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
   2114d:	66 41 0f c2 c5 05    	cmpnltpd %xmm13,%xmm0
   21153:	66 45 0f 6f c6       	movdqa %xmm14,%xmm8
   21158:	66 44 0f db c0       	pand   %xmm0,%xmm8
   2115d:	66 41 0f df c5       	pandn  %xmm13,%xmm0
   21162:	66 41 0f eb c0       	por    %xmm8,%xmm0
   21167:	66 45 0f ef c0       	pxor   %xmm8,%xmm8
   2116c:	66 44 0f c2 c3 05    	cmpnltpd %xmm3,%xmm8
   21172:	66 45 0f 6f ce       	movdqa %xmm14,%xmm9
   21177:	66 45 0f db c8       	pand   %xmm8,%xmm9
   2117c:	66 44 0f df c3       	pandn  %xmm3,%xmm8
   21181:	66 45 0f eb c1       	por    %xmm9,%xmm8
   21186:	66 0f 6f d8          	movdqa %xmm0,%xmm3
   2118a:	66 41 0f 5d d8       	minpd  %xmm8,%xmm3
   2118f:	66 44 0f 28 cb       	movapd %xmm3,%xmm9
   21194:	66 44 0f c2 cb 03    	cmpunordpd %xmm3,%xmm9
   2119a:	66 44 0f 6f d8       	movdqa %xmm0,%xmm11
   2119f:	66 45 0f db d9       	pand   %xmm9,%xmm11
   211a4:	66 44 0f 55 cb       	andnpd %xmm3,%xmm9
   211a9:	66 45 0f 56 cb       	orpd   %xmm11,%xmm9
   211ae:	66 41 0f 55 f9       	andnpd %xmm9,%xmm7
   211b3:	66 0f 29 bc 24 e0 01 	movapd %xmm7,0x1e0(%rsp)
   211ba:	00 00 
   211bc:	66 0f 6f d8          	movdqa %xmm0,%xmm3
   211c0:	66 41 0f 5f d8       	maxpd  %xmm8,%xmm3
   211c5:	66 0f 28 fb          	movapd %xmm3,%xmm7
   211c9:	66 0f c2 fb 03       	cmpunordpd %xmm3,%xmm7
   211ce:	66 0f db c7          	pand   %xmm7,%xmm0
   211d2:	66 0f 55 fb          	andnpd %xmm3,%xmm7
   211d6:	66 0f 56 f8          	orpd   %xmm0,%xmm7
   211da:	66 0f 29 bc 24 00 02 	movapd %xmm7,0x200(%rsp)
   211e1:	00 00 
   211e3:	66 0f 28 0d 85 40 fe 	movapd -0x1bf7b(%rip),%xmm1        # 5270 <std::thread::current::id::ID+0x45f8>
   211ea:	ff 
   211eb:	66 0f 59 cc          	mulpd  %xmm4,%xmm1
   211ef:	66 0f 28 ac 24 80 01 	movapd 0x180(%rsp),%xmm5
   211f6:	00 00 
   211f8:	66 0f 28 c5          	movapd %xmm5,%xmm0
   211fc:	66 0f 59 c1          	mulpd  %xmm1,%xmm0
   21200:	66 0f 28 e1          	movapd %xmm1,%xmm4
   21204:	66 0f 59 05 a4 40 fe 	mulpd  -0x1bf5c(%rip),%xmm0        # 52b0 <std::thread::current::id::ID+0x4638>
   2120b:	ff 
   2120c:	66 44 0f 28 da       	movapd %xmm2,%xmm11
   21211:	66 44 0f 58 da       	addpd  %xmm2,%xmm11
   21216:	66 41 0f 28 db       	movapd %xmm11,%xmm3
   2121b:	66 41 0f 59 db       	mulpd  %xmm11,%xmm3
   21220:	66 0f 28 fb          	movapd %xmm3,%xmm7
   21224:	66 0f 5c f8          	subpd  %xmm0,%xmm7
   21228:	66 44 0f 28 c7       	movapd %xmm7,%xmm8
   2122d:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   21231:	f2 44 0f 5f c1       	maxsd  %xmm1,%xmm8
   21236:	45 0f 57 c9          	xorps  %xmm9,%xmm9
   2123a:	f2 45 0f 51 c8       	sqrtsd %xmm8,%xmm9
   2123f:	66 45 0f 28 c3       	movapd %xmm11,%xmm8
   21244:	f2 44 0f c2 c1 05    	cmpnltsd %xmm1,%xmm8
   2124a:	66 45 0f 28 e0       	movapd %xmm8,%xmm12
   2124f:	66 45 0f 54 e1       	andpd  %xmm9,%xmm12
   21254:	66 45 0f 57 cf       	xorpd  %xmm15,%xmm9
   21259:	66 45 0f 55 c1       	andnpd %xmm9,%xmm8
   2125e:	66 45 0f 56 c4       	orpd   %xmm12,%xmm8
   21263:	66 44 0f 28 cf       	movapd %xmm7,%xmm9
   21268:	66 44 0f 15 cf       	unpckhpd %xmm7,%xmm9
   2126d:	f2 44 0f 5f c9       	maxsd  %xmm1,%xmm9
   21272:	f2 45 0f 51 c9       	sqrtsd %xmm9,%xmm9
   21277:	66 45 0f 14 c1       	unpcklpd %xmm9,%xmm8
   2127c:	66 45 0f 58 c3       	addpd  %xmm11,%xmm8
   21281:	66 45 0f 59 c2       	mulpd  %xmm10,%xmm8
   21286:	66 0f 28 0d 72 3e fe 	movapd -0x1c18e(%rip),%xmm1        # 5100 <std::thread::current::id::ID+0x4488>
   2128d:	ff 
   2128e:	66 0f 54 c1          	andpd  %xmm1,%xmm0
   21292:	66 0f 58 c3          	addpd  %xmm3,%xmm0
   21296:	66 0f 59 05 b2 40 fe 	mulpd  -0x1bf4e(%rip),%xmm0        # 5350 <std::thread::current::id::ID+0x46d8>
   2129d:	ff 
   2129e:	66 45 0f 57 d2       	xorpd  %xmm10,%xmm10
   212a3:	66 44 0f c2 d7 02    	cmplepd %xmm7,%xmm10
   212a9:	66 0f 54 f9          	andpd  %xmm1,%xmm7
   212ad:	66 0f c2 f8 02       	cmplepd %xmm0,%xmm7
   212b2:	66 0f 28 c4          	movapd %xmm4,%xmm0
   212b6:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   212ba:	66 0f c2 c1 04       	cmpneqpd %xmm1,%xmm0
   212bf:	66 0f 54 e0          	andpd  %xmm0,%xmm4
   212c3:	66 45 0f 28 e3       	movapd %xmm11,%xmm12
   212c8:	66 44 0f c2 e1 00    	cmpeqpd %xmm1,%xmm12
   212ce:	66 45 0f 57 ff       	xorpd  %xmm15,%xmm15
   212d3:	66 0f 28 15 a5 41 fe 	movapd -0x1be5b(%rip),%xmm2        # 5480 <std::thread::current::id::ID+0x4808>
   212da:	ff 
   212db:	66 0f 28 da          	movapd %xmm2,%xmm3
   212df:	66 41 0f 54 dc       	andpd  %xmm12,%xmm3
   212e4:	66 44 0f 54 d0       	andpd  %xmm0,%xmm10
   212e9:	66 45 0f 28 cc       	movapd %xmm12,%xmm9
   212ee:	66 44 0f 56 e0       	orpd   %xmm0,%xmm12
   212f3:	66 0f 54 f8          	andpd  %xmm0,%xmm7
   212f7:	66 0f 55 c2          	andnpd %xmm2,%xmm0
   212fb:	66 0f 56 c4          	orpd   %xmm4,%xmm0
   212ff:	66 45 0f 28 e8       	movapd %xmm8,%xmm13
   21304:	66 45 0f c2 ef 04    	cmpneqpd %xmm15,%xmm13
   2130a:	66 0f 57 e4          	xorpd  %xmm4,%xmm4
   2130e:	66 45 0f 28 f8       	movapd %xmm8,%xmm15
   21313:	66 45 0f 54 fd       	andpd  %xmm13,%xmm15
   21318:	66 41 0f 70 ca a0    	pshufd $0xa0,%xmm10,%xmm1
   2131e:	66 45 0f 54 d5       	andpd  %xmm13,%xmm10
   21323:	66 44 0f 55 ea       	andnpd %xmm2,%xmm13
   21328:	66 45 0f 56 ef       	orpd   %xmm15,%xmm13
   2132d:	66 45 0f 55 cb       	andnpd %xmm11,%xmm9
   21332:	66 41 0f 56 d9       	orpd   %xmm9,%xmm3
   21337:	66 44 0f 5e c0       	divpd  %xmm0,%xmm8
   2133c:	66 0f 28 c5          	movapd %xmm5,%xmm0
   21340:	66 44 0f 28 1d f7 41 	movapd -0x1be09(%rip),%xmm11        # 5540 <std::thread::current::id::ID+0x48c8>
   21347:	fe ff 
   21349:	66 41 0f 57 c3       	xorpd  %xmm11,%xmm0
   2134e:	66 0f 29 84 24 f0 00 	movapd %xmm0,0xf0(%rsp)
   21355:	00 00 
   21357:	66 0f 5e c3          	divpd  %xmm3,%xmm0
   2135b:	66 41 0f 73 f4 3f    	psllq  $0x3f,%xmm12
   21361:	66 41 0f 72 e4 1f    	psrad  $0x1f,%xmm12
   21367:	66 41 0f 70 dc f5    	pshufd $0xf5,%xmm12,%xmm3
   2136d:	66 0f df d8          	pandn  %xmm0,%xmm3
   21371:	66 45 0f db e6       	pand   %xmm14,%xmm12
   21376:	66 44 0f eb e3       	por    %xmm3,%xmm12
   2137b:	66 44 0f 54 c1       	andpd  %xmm1,%xmm8
   21380:	66 41 0f df cc       	pandn  %xmm12,%xmm1
   21385:	66 41 0f eb c8       	por    %xmm8,%xmm1
   2138a:	66 0f 28 c5          	movapd %xmm5,%xmm0
   2138e:	66 44 0f 28 cd       	movapd %xmm5,%xmm9
   21393:	66 41 0f 5e c5       	divpd  %xmm13,%xmm0
   21398:	66 41 0f 70 da a0    	pshufd $0xa0,%xmm10,%xmm3
   2139e:	66 0f 54 c3          	andpd  %xmm3,%xmm0
   213a2:	66 41 0f df de       	pandn  %xmm14,%xmm3
   213a7:	66 0f eb d8          	por    %xmm0,%xmm3
   213ab:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
   213af:	66 0f c2 c1 05       	cmpnltpd %xmm1,%xmm0
   213b4:	66 45 0f 6f c6       	movdqa %xmm14,%xmm8
   213b9:	66 44 0f db c0       	pand   %xmm0,%xmm8
   213be:	66 0f df c1          	pandn  %xmm1,%xmm0
   213c2:	66 41 0f eb c0       	por    %xmm8,%xmm0
   213c7:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   213cb:	66 0f c2 d3 05       	cmpnltpd %xmm3,%xmm2
   213d0:	66 44 0f db f2       	pand   %xmm2,%xmm14
   213d5:	66 0f df d3          	pandn  %xmm3,%xmm2
   213d9:	66 41 0f eb d6       	por    %xmm14,%xmm2
   213de:	66 0f 6f c8          	movdqa %xmm0,%xmm1
   213e2:	66 0f 5d ca          	minpd  %xmm2,%xmm1
   213e6:	66 0f 28 d9          	movapd %xmm1,%xmm3
   213ea:	66 0f c2 d9 03       	cmpunordpd %xmm1,%xmm3
   213ef:	66 44 0f 6f c0       	movdqa %xmm0,%xmm8
   213f4:	66 44 0f db c3       	pand   %xmm3,%xmm8
   213f9:	66 0f 55 d9          	andnpd %xmm1,%xmm3
   213fd:	66 41 0f 56 d8       	orpd   %xmm8,%xmm3
   21402:	66 0f 55 fb          	andnpd %xmm3,%xmm7
   21406:	66 0f 29 bc 24 f0 01 	movapd %xmm7,0x1f0(%rsp)
   2140d:	00 00 
   2140f:	66 0f 6f c8          	movdqa %xmm0,%xmm1
   21413:	66 0f 5f ca          	maxpd  %xmm2,%xmm1
   21417:	66 0f 28 d1          	movapd %xmm1,%xmm2
   2141b:	66 0f c2 d1 03       	cmpunordpd %xmm1,%xmm2
   21420:	66 0f db c2          	pand   %xmm2,%xmm0
   21424:	66 0f 55 d1          	andnpd %xmm1,%xmm2
   21428:	66 0f 56 d0          	orpd   %xmm0,%xmm2
   2142c:	66 0f 29 94 24 10 02 	movapd %xmm2,0x210(%rsp)
   21433:	00 00 
   21435:	66 44 0f 28 44 24 70 	movapd 0x70(%rsp),%xmm8
   2143c:	66 41 0f 28 c0       	movapd %xmm8,%xmm0
   21441:	66 0f 28 2d b7 3c fe 	movapd -0x1c349(%rip),%xmm5        # 5100 <std::thread::current::id::ID+0x4488>
   21448:	ff 
   21449:	66 0f 54 c5          	andpd  %xmm5,%xmm0
   2144d:	66 0f 28 5c 24 60    	movapd 0x60(%rsp),%xmm3
   21453:	66 0f 28 cb          	movapd %xmm3,%xmm1
   21457:	66 0f 54 cd          	andpd  %xmm5,%xmm1
   2145b:	66 41 0f 28 d1       	movapd %xmm9,%xmm2
   21460:	66 0f 54 d5          	andpd  %xmm5,%xmm2
   21464:	66 44 0f 28 cd       	movapd %xmm5,%xmm9
   21469:	f2 0f c2 dc 00       	cmpeqsd %xmm4,%xmm3
   2146e:	66 0f 28 fb          	movapd %xmm3,%xmm7
   21472:	66 0f 55 f9          	andnpd %xmm1,%xmm7
   21476:	66 0f 54 da          	andpd  %xmm2,%xmm3
   2147a:	66 0f 56 df          	orpd   %xmm7,%xmm3
   2147e:	f2 41 0f c2 e0 00    	cmpeqsd %xmm8,%xmm4
   21484:	66 0f 28 fc          	movapd %xmm4,%xmm7
   21488:	66 0f 55 f8          	andnpd %xmm0,%xmm7
   2148c:	66 0f 54 e3          	andpd  %xmm3,%xmm4
   21490:	66 0f 56 e7          	orpd   %xmm7,%xmm4
   21494:	f2 0f 5f 25 b4 5a fe 	maxsd  -0x1a54c(%rip),%xmm4        # 6f50 <std::thread::current::id::ID+0x62d8>
   2149b:	ff 
   2149c:	66 0f 28 c1          	movapd %xmm1,%xmm0
   214a0:	f2 0f 5f c2          	maxsd  %xmm2,%xmm0
   214a4:	66 0f 28 d8          	movapd %xmm0,%xmm3
   214a8:	f2 0f c2 d8 03       	cmpunordsd %xmm0,%xmm3
   214ad:	66 0f 54 cb          	andpd  %xmm3,%xmm1
   214b1:	66 0f 55 d8          	andnpd %xmm0,%xmm3
   214b5:	66 0f 56 d9          	orpd   %xmm1,%xmm3
   214b9:	66 0f 28 7c 24 20    	movapd 0x20(%rsp),%xmm7
   214bf:	66 0f 28 c7          	movapd %xmm7,%xmm0
   214c3:	66 0f 54 c5          	andpd  %xmm5,%xmm0
   214c7:	66 0f 28 cb          	movapd %xmm3,%xmm1
   214cb:	f2 0f 5f c8          	maxsd  %xmm0,%xmm1
   214cf:	66 0f 28 d1          	movapd %xmm1,%xmm2
   214d3:	f2 0f c2 d1 03       	cmpunordsd %xmm1,%xmm2
   214d8:	66 0f 54 da          	andpd  %xmm2,%xmm3
   214dc:	66 0f 55 d1          	andnpd %xmm1,%xmm2
   214e0:	66 0f 56 d3          	orpd   %xmm3,%xmm2
   214e4:	f2 0f 5e d4          	divsd  %xmm4,%xmm2
   214e8:	66 0f 28 a4 24 90 01 	movapd 0x190(%rsp),%xmm4
   214ef:	00 00 
   214f1:	66 0f 28 c4          	movapd %xmm4,%xmm0
   214f5:	66 0f c2 44 24 30 00 	cmpeqpd 0x30(%rsp),%xmm0
   214fc:	66 0f 28 9c 24 70 01 	movapd 0x170(%rsp),%xmm3
   21503:	00 00 
   21505:	66 0f 28 cb          	movapd %xmm3,%xmm1
   21509:	66 0f c2 ce 00       	cmpeqpd %xmm6,%xmm1
   2150e:	66 0f 54 dd          	andpd  %xmm5,%xmm3
   21512:	66 0f 28 6c 24 50    	movapd 0x50(%rsp),%xmm5
   21518:	66 41 0f 54 e9       	andpd  %xmm9,%xmm5
   2151d:	66 0f 28 f3          	movapd %xmm3,%xmm6
   21521:	66 0f 5f f5          	maxpd  %xmm5,%xmm6
   21525:	66 0f 54 e9          	andpd  %xmm1,%xmm5
   21529:	66 0f 55 cb          	andnpd %xmm3,%xmm1
   2152d:	66 0f 56 cd          	orpd   %xmm5,%xmm1
   21531:	66 0f 28 ec          	movapd %xmm4,%xmm5
   21535:	66 41 0f 54 e9       	andpd  %xmm9,%xmm5
   2153a:	66 0f 54 c8          	andpd  %xmm0,%xmm1
   2153e:	66 0f 55 c5          	andnpd %xmm5,%xmm0
   21542:	66 0f 56 c1          	orpd   %xmm1,%xmm0
   21546:	66 0f 28 ce          	movapd %xmm6,%xmm1
   2154a:	66 0f c2 ce 03       	cmpunordpd %xmm6,%xmm1
   2154f:	66 0f 54 d9          	andpd  %xmm1,%xmm3
   21553:	66 0f 55 ce          	andnpd %xmm6,%xmm1
   21557:	66 0f 56 cb          	orpd   %xmm3,%xmm1
   2155b:	66 0f 28 6c 24 10    	movapd 0x10(%rsp),%xmm5
   21561:	66 44 0f 54 cd       	andpd  %xmm5,%xmm9
   21566:	66 0f 28 d9          	movapd %xmm1,%xmm3
   2156a:	66 41 0f 5f d9       	maxpd  %xmm9,%xmm3
   2156f:	66 0f 28 e3          	movapd %xmm3,%xmm4
   21573:	66 0f c2 e3 03       	cmpunordpd %xmm3,%xmm4
   21578:	66 0f 54 cc          	andpd  %xmm4,%xmm1
   2157c:	66 0f 55 e3          	andnpd %xmm3,%xmm4
   21580:	66 0f 5f 05 d8 3b fe 	maxpd  -0x1c428(%rip),%xmm0        # 5160 <std::thread::current::id::ID+0x44e8>
   21587:	ff 
   21588:	66 0f 56 e1          	orpd   %xmm1,%xmm4
   2158c:	66 0f 5e e0          	divpd  %xmm0,%xmm4
   21590:	66 0f 58 25 e8 3e fe 	addpd  -0x1c118(%rip),%xmm4        # 5480 <std::thread::current::id::ID+0x4808>
   21597:	ff 
   21598:	66 0f 29 a4 24 a0 01 	movapd %xmm4,0x1a0(%rsp)
   2159f:	00 00 
   215a1:	f2 0f 58 15 d7 59 fe 	addsd  -0x1a629(%rip),%xmm2        # 6f80 <std::thread::current::id::ID+0x6308>
   215a8:	ff 
   215a9:	f2 0f 11 94 24 b0 01 	movsd  %xmm2,0x1b0(%rsp)
   215b0:	00 00 
   215b2:	66 0f 28 c7          	movapd %xmm7,%xmm0
   215b6:	66 41 0f 28 cb       	movapd %xmm11,%xmm1
   215bb:	66 41 0f 57 c3       	xorpd  %xmm11,%xmm0
   215c0:	66 0f 57 cd          	xorpd  %xmm5,%xmm1
   215c4:	66 0f 29 8c 24 00 01 	movapd %xmm1,0x100(%rsp)
   215cb:	00 00 
   215cd:	66 0f 13 84 24 10 01 	movlpd %xmm0,0x110(%rsp)
   215d4:	00 00 
   215d6:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
   215dd:	00 f0 3f 
   215e0:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
   215e7:	00 
   215e8:	48 b8 00 00 00 00 00 	movabs $0xbff0000000000000,%rax
   215ef:	00 f0 bf 
   215f2:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
   215f9:	00 
   215fa:	48 8d bc 24 20 01 00 	lea    0x120(%rsp),%rdi
   21601:	00 
   21602:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
   21609:	00 
   2160a:	48 8d 94 24 e0 01 00 	lea    0x1e0(%rsp),%rdx
   21611:	00 
   21612:	48 8d 8c 24 a0 01 00 	lea    0x1a0(%rsp),%rcx
   21619:	00 
   2161a:	41 b8 60 00 00 00    	mov    $0x60,%r8d
   21620:	e8 1b e6 ff ff       	call   1fc40 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, usize, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>>
   21625:	f2 0f 10 84 24 20 01 	movsd  0x120(%rsp),%xmm0
   2162c:	00 00 
   2162e:	f2 0f 10 8c 24 28 01 	movsd  0x128(%rsp),%xmm1
   21635:	00 00 
   21637:	f2 0f 10 a4 24 30 01 	movsd  0x130(%rsp),%xmm4
   2163e:	00 00 
   21640:	f2 0f 5d 05 f0 58 fe 	minsd  -0x1a710(%rip),%xmm0        # 6f38 <std::thread::current::id::ID+0x62c0>
   21647:	ff 
   21648:	f2 0f 5d c8          	minsd  %xmm0,%xmm1
   2164c:	f2 0f 5d e1          	minsd  %xmm1,%xmm4
   21650:	66 48 0f 7e e0       	movq   %xmm4,%rax
   21655:	49 bf ff ff ff ff ff 	movabs $0x7fffffffffffffff,%r15
   2165c:	ff ff 7f 
   2165f:	4c 21 f8             	and    %r15,%rax
   21662:	41 be 0e 00 00 00    	mov    $0xe,%r14d
   21668:	48 b9 ff ff ff ff ff 	movabs $0x7fefffffffffffff,%rcx
   2166f:	ff ef 7f 
   21672:	48 39 c8             	cmp    %rcx,%rax
   21675:	7e 12                	jle    21689 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xa39>
   21677:	4c 89 f0             	mov    %r14,%rax
   2167a:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
   2167e:	5b                   	pop    %rbx
   2167f:	41 5c                	pop    %r12
   21681:	41 5d                	pop    %r13
   21683:	41 5e                	pop    %r14
   21685:	41 5f                	pop    %r15
   21687:	5d                   	pop    %rbp
   21688:	c3                   	ret
   21689:	f2 0f 10 84 24 40 01 	movsd  0x140(%rsp),%xmm0
   21690:	00 00 
   21692:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
   21697:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   2169d:	0f 57 c9             	xorps  %xmm1,%xmm1
   216a0:	f3 0f 5a c8          	cvtss2sd %xmm0,%xmm1
   216a4:	0f 10 84 24 48 01 00 	movups 0x148(%rsp),%xmm0
   216ab:	00 
   216ac:	0f 29 84 24 d0 01 00 	movaps %xmm0,0x1d0(%rsp)
   216b3:	00 
   216b4:	0f 28 c1             	movaps %xmm1,%xmm0
   216b7:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   216bb:	f2 0f 11 8c 24 88 00 	movsd  %xmm1,0x88(%rsp)
   216c2:	00 00 
   216c4:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   216c8:	f2 0f 10 0d b0 58 fe 	movsd  -0x1a750(%rip),%xmm1        # 6f80 <std::thread::current::id::ID+0x6308>
   216cf:	ff 
   216d0:	66 0f 28 d1          	movapd %xmm1,%xmm2
   216d4:	f2 0f 5e d0          	divsd  %xmm0,%xmm2
   216d8:	66 0f 28 5c 24 20    	movapd 0x20(%rsp),%xmm3
   216de:	f2 0f 5c da          	subsd  %xmm2,%xmm3
   216e2:	f2 0f 5c ca          	subsd  %xmm2,%xmm1
   216e6:	66 0f 14 d2          	unpcklpd %xmm2,%xmm2
   216ea:	66 0f 28 44 24 10    	movapd 0x10(%rsp),%xmm0
   216f0:	66 0f 5c c2          	subpd  %xmm2,%xmm0
   216f4:	66 0f 29 84 24 00 01 	movapd %xmm0,0x100(%rsp)
   216fb:	00 00 
   216fd:	f2 0f 11 9c 24 10 01 	movsd  %xmm3,0x110(%rsp)
   21704:	00 00 
   21706:	f2 0f 11 8c 24 18 01 	movsd  %xmm1,0x118(%rsp)
   2170d:	00 00 
   2170f:	0f 28 84 24 90 01 00 	movaps 0x190(%rsp),%xmm0
   21716:	00 
   21717:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
   2171e:	00 
   2171f:	0f 28 44 24 70       	movaps 0x70(%rsp),%xmm0
   21724:	0f 29 84 24 b0 00 00 	movaps %xmm0,0xb0(%rsp)
   2172b:	00 
   2172c:	0f 28 84 24 70 01 00 	movaps 0x170(%rsp),%xmm0
   21733:	00 
   21734:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
   2173b:	00 
   2173c:	0f 28 44 24 60       	movaps 0x60(%rsp),%xmm0
   21741:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
   21748:	00 
   21749:	0f 28 44 24 50       	movaps 0x50(%rsp),%xmm0
   2174e:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
   21755:	00 
   21756:	0f 28 84 24 80 01 00 	movaps 0x180(%rsp),%xmm0
   2175d:	00 
   2175e:	0f 29 84 24 f0 00 00 	movaps %xmm0,0xf0(%rsp)
   21765:	00 
   21766:	66 0f 28 c4          	movapd %xmm4,%xmm0
   2176a:	66 0f 14 c4          	unpcklpd %xmm4,%xmm0
   2176e:	66 0f 29 84 24 30 02 	movapd %xmm0,0x230(%rsp)
   21775:	00 00 
   21777:	66 0f 29 84 24 20 02 	movapd %xmm0,0x220(%rsp)
   2177e:	00 00 
   21780:	48 8d bc 24 20 01 00 	lea    0x120(%rsp),%rdi
   21787:	00 
   21788:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
   2178f:	00 
   21790:	48 8d 94 24 e0 01 00 	lea    0x1e0(%rsp),%rdx
   21797:	00 
   21798:	48 8d 8c 24 20 02 00 	lea    0x220(%rsp),%rcx
   2179f:	00 
   217a0:	41 b8 40 00 00 00    	mov    $0x40,%r8d
   217a6:	0f 29 64 24 10       	movaps %xmm4,0x10(%rsp)
   217ab:	e8 90 e4 ff ff       	call   1fc40 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, usize, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>>
   217b0:	66 0f 28 54 24 30    	movapd 0x30(%rsp),%xmm2
   217b6:	66 0f 28 c2          	movapd %xmm2,%xmm0
   217ba:	f2 0f 5d 84 24 40 01 	minsd  0x140(%rsp),%xmm0
   217c1:	00 00 
   217c3:	66 0f 28 c8          	movapd %xmm0,%xmm1
   217c7:	f2 0f c2 c8 03       	cmpunordsd %xmm0,%xmm1
   217cc:	66 0f 54 d1          	andpd  %xmm1,%xmm2
   217d0:	66 0f 55 c8          	andnpd %xmm0,%xmm1
   217d4:	66 0f 28 5c 24 10    	movapd 0x10(%rsp),%xmm3
   217da:	66 0f 28 c3          	movapd %xmm3,%xmm0
   217de:	f2 0f 5d 84 24 20 01 	minsd  0x120(%rsp),%xmm0
   217e5:	00 00 
   217e7:	66 0f 56 ca          	orpd   %xmm2,%xmm1
   217eb:	66 0f 28 d0          	movapd %xmm0,%xmm2
   217ef:	f2 0f c2 d0 03       	cmpunordsd %xmm0,%xmm2
   217f4:	66 0f 54 da          	andpd  %xmm2,%xmm3
   217f8:	66 0f 55 d0          	andnpd %xmm0,%xmm2
   217fc:	66 0f 56 d3          	orpd   %xmm3,%xmm2
   21800:	f2 0f 10 84 24 28 01 	movsd  0x128(%rsp),%xmm0
   21807:	00 00 
   21809:	66 0f 28 da          	movapd %xmm2,%xmm3
   2180d:	f2 0f 5d d8          	minsd  %xmm0,%xmm3
   21811:	66 0f 28 e3          	movapd %xmm3,%xmm4
   21815:	f2 0f c2 e3 03       	cmpunordsd %xmm3,%xmm4
   2181a:	66 0f 54 d4          	andpd  %xmm4,%xmm2
   2181e:	66 0f 55 e3          	andnpd %xmm3,%xmm4
   21822:	66 0f 56 e2          	orpd   %xmm2,%xmm4
   21826:	f2 0f 10 84 24 30 01 	movsd  0x130(%rsp),%xmm0
   2182d:	00 00 
   2182f:	66 0f 28 d4          	movapd %xmm4,%xmm2
   21833:	f2 0f 5d d0          	minsd  %xmm0,%xmm2
   21837:	66 0f 28 c2          	movapd %xmm2,%xmm0
   2183b:	f2 0f c2 c2 03       	cmpunordsd %xmm2,%xmm0
   21840:	66 0f 54 e0          	andpd  %xmm0,%xmm4
   21844:	66 0f 55 c2          	andnpd %xmm2,%xmm0
   21848:	66 0f 56 c4          	orpd   %xmm4,%xmm0
   2184c:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
   21850:	0f 87 21 fe ff ff    	ja     21677 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xa27>
   21856:	66 0f 10 8c 24 48 01 	movupd 0x148(%rsp),%xmm1
   2185d:	00 00 
   2185f:	66 0f 28 9c 24 d0 01 	movapd 0x1d0(%rsp),%xmm3
   21866:	00 00 
   21868:	66 0f 28 d3          	movapd %xmm3,%xmm2
   2186c:	66 0f 5d d1          	minpd  %xmm1,%xmm2
   21870:	66 0f 28 ca          	movapd %xmm2,%xmm1
   21874:	66 0f c2 ca 03       	cmpunordpd %xmm2,%xmm1
   21879:	66 0f 54 d9          	andpd  %xmm1,%xmm3
   2187d:	66 0f 55 ca          	andnpd %xmm2,%xmm1
   21881:	66 0f 56 cb          	orpd   %xmm3,%xmm1
   21885:	66 0f 28 d0          	movapd %xmm0,%xmm2
   21889:	66 0f 14 d0          	unpcklpd %xmm0,%xmm2
   2188d:	66 0f c2 ca 01       	cmpltpd %xmm2,%xmm1
   21892:	66 0f 50 c1          	movmskpd %xmm1,%eax
   21896:	a8 01                	test   $0x1,%al
   21898:	0f 85 d9 fd ff ff    	jne    21677 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xa27>
   2189e:	d0 e8                	shr    $1,%al
   218a0:	0f 85 d1 fd ff ff    	jne    21677 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xa27>
   218a6:	f2 0f 59 84 24 88 00 	mulsd  0x88(%rsp),%xmm0
   218ad:	00 00 
   218af:	66 48 0f 7e c0       	movq   %xmm0,%rax
   218b4:	48 85 c0             	test   %rax,%rax
   218b7:	0f 98 c1             	sets   %cl
   218ba:	49 21 c7             	and    %rax,%r15
   218bd:	48 b8 00 00 00 00 00 	movabs $0xfff0000000000000,%rax
   218c4:	00 f0 ff 
   218c7:	4c 01 f8             	add    %r15,%rax
   218ca:	48 c1 e8 35          	shr    $0x35,%rax
   218ce:	3d ff 03 00 00       	cmp    $0x3ff,%eax
   218d3:	0f 92 c0             	setb   %al
   218d6:	20 c8                	and    %cl,%al
   218d8:	49 8d 57 ff          	lea    -0x1(%r15),%rdx
   218dc:	48 be ff ff ff ff ff 	movabs $0xfffffffffffff,%rsi
   218e3:	ff 0f 00 
   218e6:	48 39 f2             	cmp    %rsi,%rdx
   218e9:	0f 92 c2             	setb   %dl
   218ec:	20 ca                	and    %cl,%dl
   218ee:	48 b9 00 00 00 00 00 	movabs $0x7ff0000000000000,%rcx
   218f5:	00 f0 7f 
   218f8:	49 39 cf             	cmp    %rcx,%r15
   218fb:	0f 9f c1             	setg   %cl
   218fe:	40 0f 94 c6          	sete   %sil
   21902:	40 08 ce             	or     %cl,%sil
   21905:	40 08 d6             	or     %dl,%sil
   21908:	40 08 c6             	or     %al,%sil
   2190b:	0f 85 66 fd ff ff    	jne    21677 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xa27>
   21911:	0f 57 c9             	xorps  %xmm1,%xmm1
   21914:	f2 0f 5a c8          	cvtsd2ss %xmm0,%xmm1
   21918:	0f 28 44 24 40       	movaps 0x40(%rsp),%xmm0
   2191d:	0f 56 05 6c 3c fe ff 	orps   -0x1c394(%rip),%xmm0        # 5590 <std::thread::current::id::ID+0x4918>
   21924:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
   21929:	41 bc 40 00 00 00    	mov    $0x40,%r12d
   2192f:	0f b6 db             	movzbl %bl,%ebx
   21932:	4c 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%r15
   21939:	00 
   2193a:	eb 1b                	jmp    21957 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xd07>
   2193c:	41 bd 01 00 00 80    	mov    $0x80000001,%r13d
   21942:	66 41 0f 6e cd       	movd   %r13d,%xmm1
   21947:	0f 57 c0             	xorps  %xmm0,%xmm0
   2194a:	f3 0f 5f c8          	maxss  %xmm0,%xmm1
   2194e:	41 ff cc             	dec    %r12d
   21951:	0f 84 20 fd ff ff    	je     21677 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xa27>
   21957:	66 41 0f 7e cd       	movd   %xmm1,%r13d
   2195c:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   21962:	f3 0f 11 84 24 a0 00 	movss  %xmm0,0xa0(%rsp)
   21969:	00 00 
   2196b:	f3 0f 11 4c 24 10    	movss  %xmm1,0x10(%rsp)
   21971:	f3 0f 11 8c 24 a4 00 	movss  %xmm1,0xa4(%rsp)
   21978:	00 00 
   2197a:	0f 28 44 24 40       	movaps 0x40(%rsp),%xmm0
   2197f:	f3 0f 11 84 24 a8 00 	movss  %xmm0,0xa8(%rsp)
   21986:	00 00 
   21988:	c7 84 24 ac 00 00 00 	movl   $0xff800000,0xac(%rsp)
   2198f:	00 00 80 ff 
   21993:	4c 89 ff             	mov    %r15,%rdi
   21996:	89 de                	mov    %ebx,%esi
   21998:	e8 53 00 00 00       	call   219f0 <gpui_canvas::color::gamut::in_gamut>
   2199d:	84 c0                	test   %al,%al
   2199f:	75 2e                	jne    219cf <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xd7f>
   219a1:	41 81 fd 00 00 80 ff 	cmp    $0xff800000,%r13d
   219a8:	66 0f 6e 4c 24 10    	movd   0x10(%rsp),%xmm1
   219ae:	74 97                	je     21947 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xcf7>
   219b0:	44 89 e8             	mov    %r13d,%eax
   219b3:	25 ff ff ff 7f       	and    $0x7fffffff,%eax
   219b8:	74 82                	je     2193c <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xcec>
   219ba:	41 39 c5             	cmp    %eax,%r13d
   219bd:	75 08                	jne    219c7 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xd77>
   219bf:	41 ff cd             	dec    %r13d
   219c2:	e9 7b ff ff ff       	jmp    21942 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xcf2>
   219c7:	41 ff c5             	inc    %r13d
   219ca:	e9 73 ff ff ff       	jmp    21942 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xcf2>
   219cf:	49 c1 e5 20          	shl    $0x20,%r13
   219d3:	41 be ff ff ff ff    	mov    $0xffffffff,%r14d
   219d9:	4d 09 ee             	or     %r13,%r14
   219dc:	e9 96 fc ff ff       	jmp    21677 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xa27>
   219e1:	cc                   	int3
   219e2:	cc                   	int3
   219e3:	cc                   	int3
   219e4:	cc                   	int3
   219e5:	cc                   	int3
   219e6:	cc                   	int3
   219e7:	cc                   	int3
   219e8:	cc                   	int3
   219e9:	cc                   	int3
   219ea:	cc                   	int3
   219eb:	cc                   	int3
   219ec:	cc                   	int3
   219ed:	cc                   	int3
   219ee:	cc                   	int3
   219ef:	cc                   	int3

gpui_canvas::color::gamut::in_gamut:
   219f0:	55                   	push   %rbp
   219f1:	53                   	push   %rbx
   219f2:	48 83 ec 68          	sub    $0x68,%rsp
   219f6:	89 f3                	mov    %esi,%ebx
   219f8:	f3 0f 7e 0f          	movq   (%rdi),%xmm1
   219fc:	8b 4f 08             	mov    0x8(%rdi),%ecx
   219ff:	8b 57 0c             	mov    0xc(%rdi),%edx
   21a02:	89 c8                	mov    %ecx,%eax
   21a04:	81 fa 00 00 00 c0    	cmp    $0xc0000000,%edx
   21a0a:	0f 82 ea 00 00 00    	jb     21afa <gpui_canvas::color::gamut::in_gamut+0x10a>
   21a10:	89 c8                	mov    %ecx,%eax
   21a12:	85 c9                	test   %ecx,%ecx
   21a14:	0f 88 db 00 00 00    	js     21af5 <gpui_canvas::color::gamut::in_gamut+0x105>
   21a1a:	c1 e8 08             	shr    $0x8,%eax
   21a1d:	89 ce                	mov    %ecx,%esi
   21a1f:	48 69 f6 8f e7 54 52 	imul   $0x5254e78f,%rsi,%rsi
   21a26:	48 c1 ee 2e          	shr    $0x2e,%rsi
   21a2a:	48 69 f8 09 a8 a7 01 	imul   $0x1a7a809,%rax,%rdi
   21a31:	48 c1 ef 20          	shr    $0x20,%rdi
   21a35:	66 41 0f 7e c9       	movd   %xmm1,%r9d
   21a3a:	45 89 ca             	mov    %r9d,%r10d
   21a3d:	41 c1 e2 08          	shl    $0x8,%r10d
   21a41:	66 0f 70 c1 55       	pshufd $0x55,%xmm1,%xmm0
   21a46:	66 41 0f 7e c0       	movd   %xmm0,%r8d
   21a4b:	45 89 c3             	mov    %r8d,%r11d
   21a4e:	45 0f a4 cb 08       	shld   $0x8,%r9d,%r11d
   21a53:	69 ee 55 52 00 00    	imul   $0x5255,%esi,%ebp
   21a59:	c1 ed 16             	shr    $0x16,%ebp
   21a5c:	69 ed c7 00 00 00    	imul   $0xc7,%ebp,%ebp
   21a62:	29 ee                	sub    %ebp,%esi
   21a64:	44 89 dd             	mov    %r11d,%ebp
   21a67:	c1 e5 08             	shl    $0x8,%ebp
   21a6a:	41 81 e3 ff ff 7f 00 	and    $0x7fffff,%r11d
   21a71:	41 81 e2 00 00 00 80 	and    $0x80000000,%r10d
   21a78:	81 e5 00 00 00 80    	and    $0x80000000,%ebp
   21a7e:	44 09 dd             	or     %r11d,%ebp
   21a81:	41 81 e1 ff ff 7f 00 	and    $0x7fffff,%r9d
   21a88:	45 09 d1             	or     %r10d,%r9d
   21a8b:	c1 e6 17             	shl    $0x17,%esi
   21a8e:	09 ee                	or     %ebp,%esi
   21a90:	c1 e7 0f             	shl    $0xf,%edi
   21a93:	81 e7 00 00 80 ff    	and    $0xff800000,%edi
   21a99:	41 0f ac c8 10       	shrd   $0x10,%ecx,%r8d
   21a9e:	44 09 cf             	or     %r9d,%edi
   21aa1:	4c 69 c8 9f 53 49 01 	imul   $0x149539f,%rax,%r9
   21aa8:	49 c1 e9 20          	shr    $0x20,%r9
   21aac:	45 69 c9 c7 00 00 00 	imul   $0xc7,%r9d,%r9d
   21ab3:	44 29 c8             	sub    %r9d,%eax
   21ab6:	45 89 c1             	mov    %r8d,%r9d
   21ab9:	41 81 e1 ff ff 7f 00 	and    $0x7fffff,%r9d
   21ac0:	41 c1 e0 08          	shl    $0x8,%r8d
   21ac4:	41 81 e0 00 00 00 80 	and    $0x80000000,%r8d
   21acb:	45 09 c8             	or     %r9d,%r8d
   21ace:	c1 e0 17             	shl    $0x17,%eax
   21ad1:	44 09 c0             	or     %r8d,%eax
   21ad4:	66 0f 6e c6          	movd   %esi,%xmm0
   21ad8:	66 0f 6e cf          	movd   %edi,%xmm1
   21adc:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
   21ae0:	c1 ea 1e             	shr    $0x1e,%edx
   21ae3:	31 ed                	xor    %ebp,%ebp
   21ae5:	48 8d 35 90 57 fe ff 	lea    -0x1a870(%rip),%rsi        # 727c <std::thread::current::id::ID+0x6604>
   21aec:	48 63 14 96          	movslq (%rsi,%rdx,4),%rdx
   21af0:	48 01 f2             	add    %rsi,%rdx
   21af3:	ff e2                	jmp    *%rdx
   21af5:	25 ff ff ff 7f       	and    $0x7fffffff,%eax
   21afa:	c1 ea 1e             	shr    $0x1e,%edx
   21afd:	31 ed                	xor    %ebp,%ebp
   21aff:	48 8d 35 76 57 fe ff 	lea    -0x1a88a(%rip),%rsi        # 727c <std::thread::current::id::ID+0x6604>
   21b06:	48 63 14 96          	movslq (%rsi,%rdx,4),%rdx
   21b0a:	48 01 f2             	add    %rsi,%rdx
   21b0d:	ff e2                	jmp    *%rdx
   21b0f:	40 b5 01             	mov    $0x1,%bpl
   21b12:	f3 0f 5a e9          	cvtss2sd %xmm1,%xmm5
   21b16:	66 0f 70 f1 55       	pshufd $0x55,%xmm1,%xmm6
   21b1b:	f3 0f 5a e6          	cvtss2sd %xmm6,%xmm4
   21b1f:	66 0f 6e d0          	movd   %eax,%xmm2
   21b23:	0f 28 05 d6 35 fe ff 	movaps -0x1ca2a(%rip),%xmm0        # 5100 <std::thread::current::id::ID+0x4488>
   21b2a:	0f 54 c5             	andps  %xmm5,%xmm0
   21b2d:	f2 0f 10 1d 23 54 fe 	movsd  -0x1abdd(%rip),%xmm3        # 6f58 <std::thread::current::id::ID+0x62e0>
   21b34:	ff 
   21b35:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   21b39:	66 0f 7e 54 24 30    	movd   %xmm2,0x30(%rsp)
   21b3f:	73 53                	jae    21b94 <gpui_canvas::color::gamut::in_gamut+0x1a4>
   21b41:	0f 2e c9             	ucomiss %xmm1,%xmm1
   21b44:	0f 29 64 24 10       	movaps %xmm4,0x10(%rsp)
   21b49:	0f 29 74 24 50       	movaps %xmm6,0x50(%rsp)
   21b4e:	7a 4e                	jp     21b9e <gpui_canvas::color::gamut::in_gamut+0x1ae>
   21b50:	0f 54 2d e9 39 fe ff 	andps  -0x1c617(%rip),%xmm5        # 5540 <std::thread::current::id::ID+0x48c8>
   21b57:	0f 56 2d 22 39 fe ff 	orps   -0x1c6de(%rip),%xmm5        # 5480 <std::thread::current::id::ID+0x4808>
   21b5e:	0f 29 2c 24          	movaps %xmm5,(%rsp)
   21b62:	eb 46                	jmp    21baa <gpui_canvas::color::gamut::in_gamut+0x1ba>
   21b64:	0f 5a e9             	cvtps2pd %xmm1,%xmm5
   21b67:	66 0f 6e c0          	movd   %eax,%xmm0
   21b6b:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   21b6f:	e9 ad 01 00 00       	jmp    21d21 <gpui_canvas::color::gamut::in_gamut+0x331>
   21b74:	85 c9                	test   %ecx,%ecx
   21b76:	0f 88 86 02 00 00    	js     21e02 <gpui_canvas::color::gamut::in_gamut+0x412>
   21b7c:	0f 5a e9             	cvtps2pd %xmm1,%xmm5
   21b7f:	66 0f 6e c0          	movd   %eax,%xmm0
   21b83:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   21b87:	84 db                	test   %bl,%bl
   21b89:	0f 84 5e 02 00 00    	je     21ded <gpui_canvas::color::gamut::in_gamut+0x3fd>
   21b8f:	e9 a7 02 00 00       	jmp    21e3b <gpui_canvas::color::gamut::in_gamut+0x44b>
   21b94:	f2 0f 5e 2d 54 53 fe 	divsd  -0x1acac(%rip),%xmm5        # 6ef0 <std::thread::current::id::ID+0x6278>
   21b9b:	ff 
   21b9c:	eb 4b                	jmp    21be9 <gpui_canvas::color::gamut::in_gamut+0x1f9>
   21b9e:	f2 0f 10 0d 42 54 fe 	movsd  -0x1abbe(%rip),%xmm1        # 6fe8 <std::thread::current::id::ID+0x6370>
   21ba5:	ff 
   21ba6:	0f 29 0c 24          	movaps %xmm1,(%rsp)
   21baa:	f2 0f 58 05 b6 54 fe 	addsd  -0x1ab4a(%rip),%xmm0        # 7068 <std::thread::current::id::ID+0x63f0>
   21bb1:	ff 
   21bb2:	f2 0f 5e 05 4e 54 fe 	divsd  -0x1abb2(%rip),%xmm0        # 7008 <std::thread::current::id::ID+0x6390>
   21bb9:	ff 
   21bba:	f2 0f 10 0d ee 53 fe 	movsd  -0x1ac12(%rip),%xmm1        # 6fb0 <std::thread::current::id::ID+0x6338>
   21bc1:	ff 
   21bc2:	ff 15 30 22 04 00    	call   *0x42230(%rip)        # 63df8 <pow@GLIBC_2.29>
   21bc8:	66 0f 28 e8          	movapd %xmm0,%xmm5
   21bcc:	f2 0f 59 2c 24       	mulsd  (%rsp),%xmm5
   21bd1:	66 0f 6e 54 24 30    	movd   0x30(%rsp),%xmm2
   21bd7:	f2 0f 10 1d 79 53 fe 	movsd  -0x1ac87(%rip),%xmm3        # 6f58 <std::thread::current::id::ID+0x62e0>
   21bde:	ff 
   21bdf:	0f 28 64 24 10       	movaps 0x10(%rsp),%xmm4
   21be4:	0f 28 74 24 50       	movaps 0x50(%rsp),%xmm6
   21be9:	0f 57 c9             	xorps  %xmm1,%xmm1
   21bec:	f3 0f 5a ca          	cvtss2sd %xmm2,%xmm1
   21bf0:	0f 28 05 09 35 fe ff 	movaps -0x1caf7(%rip),%xmm0        # 5100 <std::thread::current::id::ID+0x4488>
   21bf7:	0f 54 c4             	andps  %xmm4,%xmm0
   21bfa:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   21bfe:	66 0f 29 2c 24       	movapd %xmm5,(%rsp)
   21c03:	73 1f                	jae    21c24 <gpui_canvas::color::gamut::in_gamut+0x234>
   21c05:	0f 2e f6             	ucomiss %xmm6,%xmm6
   21c08:	0f 29 4c 24 20       	movaps %xmm1,0x20(%rsp)
   21c0d:	7a 4b                	jp     21c5a <gpui_canvas::color::gamut::in_gamut+0x26a>
   21c0f:	0f 54 25 2a 39 fe ff 	andps  -0x1c6d6(%rip),%xmm4        # 5540 <std::thread::current::id::ID+0x48c8>
   21c16:	0f 56 25 63 38 fe ff 	orps   -0x1c79d(%rip),%xmm4        # 5480 <std::thread::current::id::ID+0x4808>
   21c1d:	0f 29 64 24 10       	movaps %xmm4,0x10(%rsp)
   21c22:	eb 43                	jmp    21c67 <gpui_canvas::color::gamut::in_gamut+0x277>
   21c24:	f2 0f 5e 25 c4 52 fe 	divsd  -0x1ad3c(%rip),%xmm4        # 6ef0 <std::thread::current::id::ID+0x6278>
   21c2b:	ff 
   21c2c:	0f 28 05 cd 34 fe ff 	movaps -0x1cb33(%rip),%xmm0        # 5100 <std::thread::current::id::ID+0x4488>
   21c33:	0f 54 c1             	andps  %xmm1,%xmm0
   21c36:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   21c3a:	72 7e                	jb     21cba <gpui_canvas::color::gamut::in_gamut+0x2ca>
   21c3c:	f2 0f 5e 0d ac 52 fe 	divsd  -0x1ad54(%rip),%xmm1        # 6ef0 <std::thread::current::id::ID+0x6278>
   21c43:	ff 
   21c44:	66 0f 28 c1          	movapd %xmm1,%xmm0
   21c48:	66 0f 14 ec          	unpcklpd %xmm4,%xmm5
   21c4c:	40 84 ed             	test   %bpl,%bpl
   21c4f:	0f 85 cc 00 00 00    	jne    21d21 <gpui_canvas::color::gamut::in_gamut+0x331>
   21c55:	e9 8f 01 00 00       	jmp    21de9 <gpui_canvas::color::gamut::in_gamut+0x3f9>
   21c5a:	f2 0f 10 0d 86 53 fe 	movsd  -0x1ac7a(%rip),%xmm1        # 6fe8 <std::thread::current::id::ID+0x6370>
   21c61:	ff 
   21c62:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
   21c67:	f2 0f 58 05 f9 53 fe 	addsd  -0x1ac07(%rip),%xmm0        # 7068 <std::thread::current::id::ID+0x63f0>
   21c6e:	ff 
   21c6f:	f2 0f 5e 05 91 53 fe 	divsd  -0x1ac6f(%rip),%xmm0        # 7008 <std::thread::current::id::ID+0x6390>
   21c76:	ff 
   21c77:	f2 0f 10 0d 31 53 fe 	movsd  -0x1accf(%rip),%xmm1        # 6fb0 <std::thread::current::id::ID+0x6338>
   21c7e:	ff 
   21c7f:	ff 15 73 21 04 00    	call   *0x42173(%rip)        # 63df8 <pow@GLIBC_2.29>
   21c85:	66 0f 28 e0          	movapd %xmm0,%xmm4
   21c89:	f2 0f 59 64 24 10    	mulsd  0x10(%rsp),%xmm4
   21c8f:	66 0f 28 2c 24       	movapd (%rsp),%xmm5
   21c94:	f3 0f 10 54 24 30    	movss  0x30(%rsp),%xmm2
   21c9a:	f2 0f 10 1d b6 52 fe 	movsd  -0x1ad4a(%rip),%xmm3        # 6f58 <std::thread::current::id::ID+0x62e0>
   21ca1:	ff 
   21ca2:	66 0f 28 4c 24 20    	movapd 0x20(%rsp),%xmm1
   21ca8:	66 0f 28 05 50 34 fe 	movapd -0x1cbb0(%rip),%xmm0        # 5100 <std::thread::current::id::ID+0x4488>
   21caf:	ff 
   21cb0:	66 0f 54 c1          	andpd  %xmm1,%xmm0
   21cb4:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   21cb8:	73 82                	jae    21c3c <gpui_canvas::color::gamut::in_gamut+0x24c>
   21cba:	0f 2e d2             	ucomiss %xmm2,%xmm2
   21cbd:	66 0f 29 64 24 10    	movapd %xmm4,0x10(%rsp)
   21cc3:	7a 12                	jp     21cd7 <gpui_canvas::color::gamut::in_gamut+0x2e7>
   21cc5:	66 0f 54 0d 73 38 fe 	andpd  -0x1c78d(%rip),%xmm1        # 5540 <std::thread::current::id::ID+0x48c8>
   21ccc:	ff 
   21ccd:	66 0f 56 0d ab 37 fe 	orpd   -0x1c855(%rip),%xmm1        # 5480 <std::thread::current::id::ID+0x4808>
   21cd4:	ff 
   21cd5:	eb 08                	jmp    21cdf <gpui_canvas::color::gamut::in_gamut+0x2ef>
   21cd7:	f2 0f 10 0d 09 53 fe 	movsd  -0x1acf7(%rip),%xmm1        # 6fe8 <std::thread::current::id::ID+0x6370>
   21cde:	ff 
   21cdf:	66 0f 29 4c 24 20    	movapd %xmm1,0x20(%rsp)
   21ce5:	f2 0f 58 05 7b 53 fe 	addsd  -0x1ac85(%rip),%xmm0        # 7068 <std::thread::current::id::ID+0x63f0>
   21cec:	ff 
   21ced:	f2 0f 5e 05 13 53 fe 	divsd  -0x1aced(%rip),%xmm0        # 7008 <std::thread::current::id::ID+0x6390>
   21cf4:	ff 
   21cf5:	f2 0f 10 0d b3 52 fe 	movsd  -0x1ad4d(%rip),%xmm1        # 6fb0 <std::thread::current::id::ID+0x6338>
   21cfc:	ff 
   21cfd:	ff 15 f5 20 04 00    	call   *0x420f5(%rip)        # 63df8 <pow@GLIBC_2.29>
   21d03:	f2 0f 59 44 24 20    	mulsd  0x20(%rsp),%xmm0
   21d09:	66 0f 28 2c 24       	movapd (%rsp),%xmm5
   21d0e:	66 0f 28 64 24 10    	movapd 0x10(%rsp),%xmm4
   21d14:	66 0f 14 ec          	unpcklpd %xmm4,%xmm5
   21d18:	40 84 ed             	test   %bpl,%bpl
   21d1b:	0f 84 c8 00 00 00    	je     21de9 <gpui_canvas::color::gamut::in_gamut+0x3f9>
   21d21:	66 0f 28 d5          	movapd %xmm5,%xmm2
   21d25:	66 0f c6 d5 01       	shufpd $0x1,%xmm5,%xmm2
   21d2a:	66 0f 59 15 5e 37 fe 	mulpd  -0x1c8a2(%rip),%xmm2        # 5490 <std::thread::current::id::ID+0x4818>
   21d31:	ff 
   21d32:	66 0f 57 db          	xorpd  %xmm3,%xmm3
   21d36:	66 0f 16 1d 12 53 fe 	movhpd -0x1acee(%rip),%xmm3        # 7050 <std::thread::current::id::ID+0x63d8>
   21d3d:	ff 
   21d3e:	66 0f 59 dd          	mulpd  %xmm5,%xmm3
   21d42:	0f 28 c8             	movaps %xmm0,%xmm1
   21d45:	0f 16 c8             	movlhps %xmm0,%xmm1
   21d48:	66 0f 59 0d c0 33 fe 	mulpd  -0x1cc40(%rip),%xmm1        # 5110 <std::thread::current::id::ID+0x4498>
   21d4f:	ff 
   21d50:	66 0f 58 da          	addpd  %xmm2,%xmm3
   21d54:	66 0f 58 cb          	addpd  %xmm3,%xmm1
   21d58:	f2 0f 10 15 c8 51 fe 	movsd  -0x1ae38(%rip),%xmm2        # 6f28 <std::thread::current::id::ID+0x62b0>
   21d5f:	ff 
   21d60:	f2 0f 59 d5          	mulsd  %xmm5,%xmm2
   21d64:	f2 0f 10 e8          	movsd  %xmm0,%xmm5
   21d68:	66 0f 59 2d b0 33 fe 	mulpd  -0x1cc50(%rip),%xmm5        # 5120 <std::thread::current::id::ID+0x44a8>
   21d6f:	ff 
   21d70:	66 0f 28 c5          	movapd %xmm5,%xmm0
   21d74:	66 0f 15 c5          	unpckhpd %xmm5,%xmm0
   21d78:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   21d7c:	f2 0f 58 c5          	addsd  %xmm5,%xmm0
   21d80:	f2 0f 10 15 78 51 fe 	movsd  -0x1ae88(%rip),%xmm2        # 6f00 <std::thread::current::id::ID+0x6288>
   21d87:	ff 
   21d88:	66 0f 28 d9          	movapd %xmm1,%xmm3
   21d8c:	f2 0f 10 d8          	movsd  %xmm0,%xmm3
   21d90:	66 0f 59 1d 08 36 fe 	mulpd  -0x1c9f8(%rip),%xmm3        # 53a0 <std::thread::current::id::ID+0x4728>
   21d97:	ff 
   21d98:	66 0f 28 e1          	movapd %xmm1,%xmm4
   21d9c:	66 0f c6 e0 01       	shufpd $0x1,%xmm0,%xmm4
   21da1:	66 0f 59 25 57 35 fe 	mulpd  -0x1caa9(%rip),%xmm4        # 5300 <std::thread::current::id::ID+0x4688>
   21da8:	ff 
   21da9:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
   21dad:	66 0f 58 e3          	addpd  %xmm3,%xmm4
   21db1:	66 0f 28 e9          	movapd %xmm1,%xmm5
   21db5:	66 0f 14 e9          	unpcklpd %xmm1,%xmm5
   21db9:	66 0f 59 2d 8f 37 fe 	mulpd  -0x1c871(%rip),%xmm5        # 5550 <std::thread::current::id::ID+0x48d8>
   21dc0:	ff 
   21dc1:	66 0f 28 c4          	movapd %xmm4,%xmm0
   21dc5:	66 0f 5c c5          	subpd  %xmm5,%xmm0
   21dc9:	66 0f 58 ec          	addpd  %xmm4,%xmm5
   21dcd:	f2 0f 10 e8          	movsd  %xmm0,%xmm5
   21dd1:	66 0f 59 0d a7 35 fe 	mulpd  -0x1ca59(%rip),%xmm1        # 5380 <std::thread::current::id::ID+0x4708>
   21dd8:	ff 
   21dd9:	66 0f 28 c1          	movapd %xmm1,%xmm0
   21ddd:	66 0f 15 c1          	unpckhpd %xmm1,%xmm0
   21de1:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   21de5:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
   21de9:	84 db                	test   %bl,%bl
   21deb:	75 4e                	jne    21e3b <gpui_canvas::color::gamut::in_gamut+0x44b>
   21ded:	31 c0                	xor    %eax,%eax
   21def:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   21df3:	66 0f 2e e9          	ucomisd %xmm1,%xmm5
   21df7:	0f 83 08 01 00 00    	jae    21f05 <gpui_canvas::color::gamut::in_gamut+0x515>
   21dfd:	e9 41 01 00 00       	jmp    21f43 <gpui_canvas::color::gamut::in_gamut+0x553>
   21e02:	66 0f 6f d1          	movdqa %xmm1,%xmm2
   21e06:	0f c6 c9 55          	shufps $0x55,%xmm1,%xmm1
   21e0a:	66 0f ef c0          	pxor   %xmm0,%xmm0
   21e0e:	0f 2e c8             	ucomiss %xmm0,%xmm1
   21e11:	0f 85 35 01 00 00    	jne    21f4c <gpui_canvas::color::gamut::in_gamut+0x55c>
   21e17:	0f 8a 2f 01 00 00    	jp     21f4c <gpui_canvas::color::gamut::in_gamut+0x55c>
   21e1d:	0f 57 c9             	xorps  %xmm1,%xmm1
   21e20:	f3 0f 5a ca          	cvtss2sd %xmm2,%xmm1
   21e24:	0f 28 c1             	movaps %xmm1,%xmm0
   21e27:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   21e2b:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   21e2f:	66 0f 28 e8          	movapd %xmm0,%xmm5
   21e33:	66 0f 14 e8          	unpcklpd %xmm0,%xmm5
   21e37:	84 db                	test   %bl,%bl
   21e39:	74 b2                	je     21ded <gpui_canvas::color::gamut::in_gamut+0x3fd>
   21e3b:	66 0f 28 0d 2d 33 fe 	movapd -0x1ccd3(%rip),%xmm1        # 5170 <std::thread::current::id::ID+0x44f8>
   21e42:	ff 
   21e43:	66 0f 59 cd          	mulpd  %xmm5,%xmm1
   21e47:	66 0f 28 d5          	movapd %xmm5,%xmm2
   21e4b:	66 0f c6 d5 01       	shufpd $0x1,%xmm5,%xmm2
   21e50:	66 0f 59 15 88 36 fe 	mulpd  -0x1c978(%rip),%xmm2        # 54e0 <std::thread::current::id::ID+0x4868>
   21e57:	ff 
   21e58:	66 0f 58 d1          	addpd  %xmm1,%xmm2
   21e5c:	66 0f 28 c8          	movapd %xmm0,%xmm1
   21e60:	66 0f 14 c8          	unpcklpd %xmm0,%xmm1
   21e64:	66 0f 59 0d c4 33 fe 	mulpd  -0x1cc3c(%rip),%xmm1        # 5230 <std::thread::current::id::ID+0x45b8>
   21e6b:	ff 
   21e6c:	f2 0f 10 1d f4 50 fe 	movsd  -0x1af0c(%rip),%xmm3        # 6f68 <std::thread::current::id::ID+0x62f0>
   21e73:	ff 
   21e74:	f2 0f 59 dd          	mulsd  %xmm5,%xmm3
   21e78:	f2 0f 10 e8          	movsd  %xmm0,%xmm5
   21e7c:	66 0f 59 2d bc 33 fe 	mulpd  -0x1cc44(%rip),%xmm5        # 5240 <std::thread::current::id::ID+0x45c8>
   21e83:	ff 
   21e84:	66 0f 58 ca          	addpd  %xmm2,%xmm1
   21e88:	66 0f 28 c5          	movapd %xmm5,%xmm0
   21e8c:	66 0f 15 c5          	unpckhpd %xmm5,%xmm0
   21e90:	f2 0f 58 c3          	addsd  %xmm3,%xmm0
   21e94:	66 0f 28 d1          	movapd %xmm1,%xmm2
   21e98:	66 0f c6 d1 01       	shufpd $0x1,%xmm1,%xmm2
   21e9d:	66 0f 59 15 8b 32 fe 	mulpd  -0x1cd75(%rip),%xmm2        # 5130 <std::thread::current::id::ID+0x44b8>
   21ea4:	ff 
   21ea5:	f2 0f 58 c5          	addsd  %xmm5,%xmm0
   21ea9:	66 0f 28 1d cf 32 fe 	movapd -0x1cd31(%rip),%xmm3        # 5180 <std::thread::current::id::ID+0x4508>
   21eb0:	ff 
   21eb1:	66 0f 59 d9          	mulpd  %xmm1,%xmm3
   21eb5:	66 0f 5c da          	subpd  %xmm2,%xmm3
   21eb9:	66 0f 28 e8          	movapd %xmm0,%xmm5
   21ebd:	66 0f 14 e8          	unpcklpd %xmm0,%xmm5
   21ec1:	66 0f 59 2d 47 33 fe 	mulpd  -0x1ccb9(%rip),%xmm5        # 5210 <std::thread::current::id::ID+0x4598>
   21ec8:	ff 
   21ec9:	66 0f 28 d3          	movapd %xmm3,%xmm2
   21ecd:	66 0f 5c d5          	subpd  %xmm5,%xmm2
   21ed1:	66 0f 58 eb          	addpd  %xmm3,%xmm5
   21ed5:	f2 0f 10 ea          	movsd  %xmm2,%xmm5
   21ed9:	66 0f 59 0d 2f 35 fe 	mulpd  -0x1cad1(%rip),%xmm1        # 5410 <std::thread::current::id::ID+0x4798>
   21ee0:	ff 
   21ee1:	66 0f 28 d1          	movapd %xmm1,%xmm2
   21ee5:	66 0f 15 d1          	unpckhpd %xmm1,%xmm2
   21ee9:	f2 0f 5c ca          	subsd  %xmm2,%xmm1
   21eed:	f2 0f 59 05 03 51 fe 	mulsd  -0x1aefd(%rip),%xmm0        # 6ff8 <std::thread::current::id::ID+0x6380>
   21ef4:	ff 
   21ef5:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
   21ef9:	31 c0                	xor    %eax,%eax
   21efb:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   21eff:	66 0f 2e e9          	ucomisd %xmm1,%xmm5
   21f03:	72 3e                	jb     21f43 <gpui_canvas::color::gamut::in_gamut+0x553>
   21f05:	f2 0f 10 0d 73 50 fe 	movsd  -0x1af8d(%rip),%xmm1        # 6f80 <std::thread::current::id::ID+0x6308>
   21f0c:	ff 
   21f0d:	66 0f 2e cd          	ucomisd %xmm5,%xmm1
   21f11:	72 30                	jb     21f43 <gpui_canvas::color::gamut::in_gamut+0x553>
   21f13:	66 0f 15 ed          	unpckhpd %xmm5,%xmm5
   21f17:	31 c0                	xor    %eax,%eax
   21f19:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   21f1d:	66 0f 2e ea          	ucomisd %xmm2,%xmm5
   21f21:	72 20                	jb     21f43 <gpui_canvas::color::gamut::in_gamut+0x553>
   21f23:	66 0f 2e cd          	ucomisd %xmm5,%xmm1
   21f27:	72 1a                	jb     21f43 <gpui_canvas::color::gamut::in_gamut+0x553>
   21f29:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   21f2d:	f2 0f c2 c8 02       	cmplesd %xmm0,%xmm1
   21f32:	f2 0f c2 05 45 50 fe 	cmplesd -0x1afbb(%rip),%xmm0        # 6f80 <std::thread::current::id::ID+0x6308>
   21f39:	ff 02 
   21f3b:	66 0f 54 c1          	andpd  %xmm1,%xmm0
   21f3f:	66 0f 7e c0          	movd   %xmm0,%eax
   21f43:	24 01                	and    $0x1,%al
   21f45:	48 83 c4 68          	add    $0x68,%rsp
   21f49:	5b                   	pop    %rbx
   21f4a:	5d                   	pop    %rbp
   21f4b:	c3                   	ret
   21f4c:	66 0f 6e c0          	movd   %eax,%xmm0
   21f50:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   21f54:	f2 0f 59 05 ec 50 fe 	mulsd  -0x1af14(%rip),%xmm0        # 7048 <std::thread::current::id::ID+0x63d0>
   21f5b:	ff 
   21f5c:	48 8d 7c 24 48       	lea    0x48(%rsp),%rdi
   21f61:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
   21f66:	0f 29 0c 24          	movaps %xmm1,(%rsp)
   21f6a:	66 0f 7f 54 24 30    	movdqa %xmm2,0x30(%rsp)
   21f70:	ff 15 9a 1e 04 00    	call   *0x41e9a(%rip)        # 63e10 <sincos@GLIBC_2.2.5>
   21f76:	0f 28 44 24 30       	movaps 0x30(%rsp),%xmm0
   21f7b:	0f 57 c9             	xorps  %xmm1,%xmm1
   21f7e:	f3 0f 5a c8          	cvtss2sd %xmm0,%xmm1
   21f82:	0f 28 04 24          	movaps (%rsp),%xmm0
   21f86:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   21f8a:	f2 0f 10 54 24 40    	movsd  0x40(%rsp),%xmm2
   21f90:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
   21f94:	f2 0f 59 44 24 48    	mulsd  0x48(%rsp),%xmm0
   21f9a:	f2 0f 10 1d 9e 50 fe 	movsd  -0x1af62(%rip),%xmm3        # 7040 <std::thread::current::id::ID+0x63c8>
   21fa1:	ff 
   21fa2:	f2 0f 59 da          	mulsd  %xmm2,%xmm3
   21fa6:	f2 0f 58 d9          	addsd  %xmm1,%xmm3
   21faa:	f2 0f 10 2d 3e 50 fe 	movsd  -0x1afc2(%rip),%xmm5        # 6ff0 <std::thread::current::id::ID+0x6378>
   21fb1:	ff 
   21fb2:	f2 0f 59 e8          	mulsd  %xmm0,%xmm5
   21fb6:	f2 0f 58 eb          	addsd  %xmm3,%xmm5
   21fba:	f2 0f 10 1d fe 4f fe 	movsd  -0x1b002(%rip),%xmm3        # 6fc0 <std::thread::current::id::ID+0x6348>
   21fc1:	ff 
   21fc2:	f2 0f 59 da          	mulsd  %xmm2,%xmm3
   21fc6:	f2 0f 58 d9          	addsd  %xmm1,%xmm3
   21fca:	f2 0f 10 35 9e 50 fe 	movsd  -0x1af62(%rip),%xmm6        # 7070 <std::thread::current::id::ID+0x63f8>
   21fd1:	ff 
   21fd2:	f2 0f 59 f0          	mulsd  %xmm0,%xmm6
   21fd6:	f2 0f 58 f3          	addsd  %xmm3,%xmm6
   21fda:	f2 0f 59 15 4e 50 fe 	mulsd  -0x1afb2(%rip),%xmm2        # 7030 <std::thread::current::id::ID+0x63b8>
   21fe1:	ff 
   21fe2:	f2 0f 58 d1          	addsd  %xmm1,%xmm2
   21fe6:	f2 0f 59 05 0a 4f fe 	mulsd  -0x1b0f6(%rip),%xmm0        # 6ef8 <std::thread::current::id::ID+0x6280>
   21fed:	ff 
   21fee:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   21ff2:	66 0f 28 e5          	movapd %xmm5,%xmm4
   21ff6:	f2 0f 59 e5          	mulsd  %xmm5,%xmm4
   21ffa:	f2 0f 59 e5          	mulsd  %xmm5,%xmm4
   21ffe:	66 0f 28 de          	movapd %xmm6,%xmm3
   22002:	f2 0f 59 de          	mulsd  %xmm6,%xmm3
   22006:	f2 0f 59 de          	mulsd  %xmm6,%xmm3
   2200a:	66 0f 28 c8          	movapd %xmm0,%xmm1
   2200e:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   22012:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   22016:	f2 0f 10 05 5a 50 fe 	movsd  -0x1afa6(%rip),%xmm0        # 7078 <std::thread::current::id::ID+0x6400>
   2201d:	ff 
   2201e:	f2 0f 59 c4          	mulsd  %xmm4,%xmm0
   22022:	f2 0f 10 15 66 4f fe 	movsd  -0x1b09a(%rip),%xmm2        # 6f90 <std::thread::current::id::ID+0x6318>
   22029:	ff 
   2202a:	f2 0f 59 d3          	mulsd  %xmm3,%xmm2
   2202e:	f2 0f 58 d0          	addsd  %xmm0,%xmm2
   22032:	f2 0f 10 05 5e 4f fe 	movsd  -0x1b0a2(%rip),%xmm0        # 6f98 <std::thread::current::id::ID+0x6320>
   22039:	ff 
   2203a:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   2203e:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   22042:	f2 0f 10 15 b6 4e fe 	movsd  -0x1b14a(%rip),%xmm2        # 6f00 <std::thread::current::id::ID+0x6288>
   22049:	ff 
   2204a:	66 0f 14 e4          	unpcklpd %xmm4,%xmm4
   2204e:	66 0f 59 25 ba 34 fe 	mulpd  -0x1cb46(%rip),%xmm4        # 5510 <std::thread::current::id::ID+0x4898>
   22055:	ff 
   22056:	66 0f 14 db          	unpcklpd %xmm3,%xmm3
   2205a:	66 0f 59 1d be 34 fe 	mulpd  -0x1cb42(%rip),%xmm3        # 5520 <std::thread::current::id::ID+0x48a8>
   22061:	ff 
   22062:	66 0f 58 dc          	addpd  %xmm4,%xmm3
   22066:	66 0f 14 c9          	unpcklpd %xmm1,%xmm1
   2206a:	66 0f 59 0d fe 32 fe 	mulpd  -0x1cd02(%rip),%xmm1        # 5370 <std::thread::current::id::ID+0x46f8>
   22071:	ff 
   22072:	66 0f 58 cb          	addpd  %xmm3,%xmm1
   22076:	e9 0d fd ff ff       	jmp    21d88 <gpui_canvas::color::gamut::in_gamut+0x398>

