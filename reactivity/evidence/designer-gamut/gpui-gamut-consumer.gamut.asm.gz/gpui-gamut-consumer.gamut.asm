<gpui_canvas::color::OutputProfile>::max_chroma:
   1efa0:	66 0f 7e c1          	movd   %xmm0,%ecx
   1efa4:	81 e1 ff ff ff 7f    	and    $0x7fffffff,%ecx
   1efaa:	b8 0d 00 00 00       	mov    $0xd,%eax
   1efaf:	81 f9 ff ff 7f 7f    	cmp    $0x7f7fffff,%ecx
   1efb5:	7f 38                	jg     1efef <<gpui_canvas::color::OutputProfile>::max_chroma+0x4f>
   1efb7:	0f 57 e4             	xorps  %xmm4,%xmm4
   1efba:	0f 57 d2             	xorps  %xmm2,%xmm2
   1efbd:	f3 0f c2 d0 06       	cmpnless %xmm0,%xmm2
   1efc2:	0f 28 d8             	movaps %xmm0,%xmm3
   1efc5:	f3 0f c2 1d 2a 66 fe 	cmpnless -0x199d6(%rip),%xmm3        # 55f8 <std::thread::current::id::ID+0x4980>
   1efcc:	ff 06 
   1efce:	0f 56 da             	orps   %xmm2,%xmm3
   1efd1:	66 0f 7e d9          	movd   %xmm3,%ecx
   1efd5:	66 0f 7e ca          	movd   %xmm1,%edx
   1efd9:	81 e2 ff ff ff 7f    	and    $0x7fffffff,%edx
   1efdf:	81 fa 00 00 80 7f    	cmp    $0x7f800000,%edx
   1efe5:	0f 9d c2             	setge  %dl
   1efe8:	08 ca                	or     %cl,%dl
   1efea:	f6 c2 01             	test   $0x1,%dl
   1efed:	74 01                	je     1eff0 <<gpui_canvas::color::OutputProfile>::max_chroma+0x50>
   1efef:	c3                   	ret
   1eff0:	0f 2e c4             	ucomiss %xmm4,%xmm0
   1eff3:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   1eff8:	75 02                	jne    1effc <<gpui_canvas::color::OutputProfile>::max_chroma+0x5c>
   1effa:	7b f3                	jnp    1efef <<gpui_canvas::color::OutputProfile>::max_chroma+0x4f>
   1effc:	0f 2e 05 f5 65 fe ff 	ucomiss -0x19a0b(%rip),%xmm0        # 55f8 <std::thread::current::id::ID+0x4980>
   1f003:	75 02                	jne    1f007 <<gpui_canvas::color::OutputProfile>::max_chroma+0x67>
   1f005:	7b e8                	jnp    1efef <<gpui_canvas::color::OutputProfile>::max_chroma+0x4f>
   1f007:	53                   	push   %rbx
   1f008:	48 83 ec 10          	sub    $0x10,%rsp
   1f00c:	f3 0f 11 44 24 0c    	movss  %xmm0,0xc(%rsp)
   1f012:	89 fb                	mov    %edi,%ebx
   1f014:	0f 57 c0             	xorps  %xmm0,%xmm0
   1f017:	f3 0f 5a c1          	cvtss2sd %xmm1,%xmm0
   1f01b:	f2 0f 10 0d 25 80 fe 	movsd  -0x17fdb(%rip),%xmm1        # 7048 <std::thread::current::id::ID+0x63d0>
   1f022:	ff 
   1f023:	ff 15 7f 48 04 00    	call   *0x4487f(%rip)        # 638a8 <_DYNAMIC+0x370>
   1f029:	f2 0f 10 1d 17 80 fe 	movsd  -0x17fe9(%rip),%xmm3        # 7048 <std::thread::current::id::ID+0x63d0>
   1f030:	ff 
   1f031:	f2 0f 58 d8          	addsd  %xmm0,%xmm3
   1f035:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   1f039:	66 0f 28 d0          	movapd %xmm0,%xmm2
   1f03d:	f2 0f c2 d1 01       	cmpltsd %xmm1,%xmm2
   1f042:	66 0f 54 da          	andpd  %xmm2,%xmm3
   1f046:	66 0f 55 d0          	andnpd %xmm0,%xmm2
   1f04a:	66 0f 56 d3          	orpd   %xmm3,%xmm2
   1f04e:	66 0f 2e 15 72 7f fe 	ucomisd -0x1808e(%rip),%xmm2        # 6fc8 <std::thread::current::id::ID+0x6350>
   1f055:	ff 
   1f056:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   1f05a:	73 0f                	jae    1f06b <<gpui_canvas::color::OutputProfile>::max_chroma+0xcb>
   1f05c:	0f 57 c0             	xorps  %xmm0,%xmm0
   1f05f:	f2 0f 5a c2          	cvtsd2ss %xmm2,%xmm0
   1f063:	f3 0f c2 c8 00       	cmpeqss %xmm0,%xmm1
   1f068:	0f 55 c8             	andnps %xmm0,%xmm1
   1f06b:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   1f071:	0f b6 fb             	movzbl %bl,%edi
   1f074:	48 83 c4 10          	add    $0x10,%rsp
   1f078:	5b                   	pop    %rbx
   1f079:	e9 32 0a 00 00       	jmp    1fab0 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>>
   1f07e:	cc                   	int3
   1f07f:	cc                   	int3

<gpui_canvas::color::Color>::fit_chroma:
   1f3f0:	55                   	push   %rbp
   1f3f1:	41 57                	push   %r15
   1f3f3:	41 56                	push   %r14
   1f3f5:	41 54                	push   %r12
   1f3f7:	53                   	push   %rbx
   1f3f8:	48 83 ec 30          	sub    $0x30,%rsp
   1f3fc:	48 89 fb             	mov    %rdi,%rbx
   1f3ff:	44 8b 66 08          	mov    0x8(%rsi),%r12d
   1f403:	44 8b 7e 0c          	mov    0xc(%rsi),%r15d
   1f407:	41 81 ff 00 00 00 c0 	cmp    $0xc0000000,%r15d
   1f40e:	0f 92 c0             	setb   %al
   1f411:	45 85 e4             	test   %r12d,%r12d
   1f414:	0f 99 c1             	setns  %cl
   1f417:	08 c1                	or     %al,%cl
   1f419:	74 09                	je     1f424 <<gpui_canvas::color::Color>::fit_chroma+0x34>
   1f41b:	c7 43 04 0d 00 00 00 	movl   $0xd,0x4(%rbx)
   1f422:	eb 4a                	jmp    1f46e <<gpui_canvas::color::Color>::fit_chroma+0x7e>
   1f424:	49 89 f6             	mov    %rsi,%r14
   1f427:	0f 10 06             	movups (%rsi),%xmm0
   1f42a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   1f42f:	0f b6 ea             	movzbl %dl,%ebp
   1f432:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   1f437:	89 ee                	mov    %ebp,%esi
   1f439:	e8 62 20 00 00       	call   214a0 <gpui_canvas::color::gamut::in_gamut>
   1f43e:	84 c0                	test   %al,%al
   1f440:	74 0c                	je     1f44e <<gpui_canvas::color::Color>::fit_chroma+0x5e>
   1f442:	41 0f 10 06          	movups (%r14),%xmm0
   1f446:	0f 11 43 04          	movups %xmm0,0x4(%rbx)
   1f44a:	31 c0                	xor    %eax,%eax
   1f44c:	eb 25                	jmp    1f473 <<gpui_canvas::color::Color>::fit_chroma+0x83>
   1f44e:	41 8b 16             	mov    (%r14),%edx
   1f451:	89 d6                	mov    %edx,%esi
   1f453:	81 e6 ff ff ff 7f    	and    $0x7fffffff,%esi
   1f459:	b8 0d 00 00 00       	mov    $0xd,%eax
   1f45e:	31 c9                	xor    %ecx,%ecx
   1f460:	81 fe ff ff 7f 7f    	cmp    $0x7f7fffff,%esi
   1f466:	7e 1d                	jle    1f485 <<gpui_canvas::color::Color>::fit_chroma+0x95>
   1f468:	89 43 04             	mov    %eax,0x4(%rbx)
   1f46b:	89 4b 08             	mov    %ecx,0x8(%rbx)
   1f46e:	b8 01 00 00 00       	mov    $0x1,%eax
   1f473:	89 03                	mov    %eax,(%rbx)
   1f475:	48 89 d8             	mov    %rbx,%rax
   1f478:	48 83 c4 30          	add    $0x30,%rsp
   1f47c:	5b                   	pop    %rbx
   1f47d:	41 5c                	pop    %r12
   1f47f:	41 5e                	pop    %r14
   1f481:	41 5f                	pop    %r15
   1f483:	5d                   	pop    %rbp
   1f484:	c3                   	ret
   1f485:	44 89 e6             	mov    %r12d,%esi
   1f488:	81 e6 ff ff ff 7f    	and    $0x7fffffff,%esi
   1f48e:	66 0f 6e c6          	movd   %esi,%xmm0
   1f492:	0f 2e 05 93 61 fe ff 	ucomiss -0x19e6d(%rip),%xmm0        # 562c <std::thread::current::id::ID+0x49b4>
   1f499:	74 cd                	je     1f468 <<gpui_canvas::color::Color>::fit_chroma+0x78>
   1f49b:	66 0f 6e d2          	movd   %edx,%xmm2
   1f49f:	0f 57 c9             	xorps  %xmm1,%xmm1
   1f4a2:	0f 2e d1             	ucomiss %xmm1,%xmm2
   1f4a5:	72 c1                	jb     1f468 <<gpui_canvas::color::Color>::fit_chroma+0x78>
   1f4a7:	f3 0f 10 0d 49 61 fe 	movss  -0x19eb7(%rip),%xmm1        # 55f8 <std::thread::current::id::ID+0x4980>
   1f4ae:	ff 
   1f4af:	0f 2e ca             	ucomiss %xmm2,%xmm1
   1f4b2:	72 b4                	jb     1f468 <<gpui_canvas::color::Color>::fit_chroma+0x78>
   1f4b4:	f3 41 0f 10 5e 04    	movss  0x4(%r14),%xmm3
   1f4ba:	31 c9                	xor    %ecx,%ecx
   1f4bc:	0f 57 c9             	xorps  %xmm1,%xmm1
   1f4bf:	0f 2e d1             	ucomiss %xmm1,%xmm2
   1f4c2:	f3 0f 11 54 24 0c    	movss  %xmm2,0xc(%rsp)
   1f4c8:	75 02                	jne    1f4cc <<gpui_canvas::color::Color>::fit_chroma+0xdc>
   1f4ca:	7b 63                	jnp    1f52f <<gpui_canvas::color::Color>::fit_chroma+0x13f>
   1f4cc:	0f 2e 15 25 61 fe ff 	ucomiss -0x19edb(%rip),%xmm2        # 55f8 <std::thread::current::id::ID+0x4980>
   1f4d3:	75 02                	jne    1f4d7 <<gpui_canvas::color::Color>::fit_chroma+0xe7>
   1f4d5:	7b 58                	jnp    1f52f <<gpui_canvas::color::Color>::fit_chroma+0x13f>
   1f4d7:	0f 29 5c 24 20       	movaps %xmm3,0x20(%rsp)
   1f4dc:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   1f4e0:	f2 0f 10 0d 60 7b fe 	movsd  -0x184a0(%rip),%xmm1        # 7048 <std::thread::current::id::ID+0x63d0>
   1f4e7:	ff 
   1f4e8:	ff 15 ba 43 04 00    	call   *0x443ba(%rip)        # 638a8 <_DYNAMIC+0x370>
   1f4ee:	66 0f 2e 05 d2 7a fe 	ucomisd -0x1852e(%rip),%xmm0        # 6fc8 <std::thread::current::id::ID+0x6350>
   1f4f5:	ff 
   1f4f6:	0f 57 c9             	xorps  %xmm1,%xmm1
   1f4f9:	73 0c                	jae    1f507 <<gpui_canvas::color::Color>::fit_chroma+0x117>
   1f4fb:	f2 0f 5a c0          	cvtsd2ss %xmm0,%xmm0
   1f4ff:	f3 0f c2 c8 00       	cmpeqss %xmm0,%xmm1
   1f504:	0f 55 c8             	andnps %xmm0,%xmm1
   1f507:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   1f50d:	89 ef                	mov    %ebp,%edi
   1f50f:	e8 9c 05 00 00       	call   1fab0 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>>
   1f514:	f3 0f 10 54 24 0c    	movss  0xc(%rsp),%xmm2
   1f51a:	48 89 c1             	mov    %rax,%rcx
   1f51d:	48 c1 e9 20          	shr    $0x20,%rcx
   1f521:	83 f8 ff             	cmp    $0xffffffff,%eax
   1f524:	0f 28 5c 24 20       	movaps 0x20(%rsp),%xmm3
   1f529:	0f 85 39 ff ff ff    	jne    1f468 <<gpui_canvas::color::Color>::fit_chroma+0x78>
   1f52f:	66 0f 6e c1          	movd   %ecx,%xmm0
   1f533:	0f 28 cb             	movaps %xmm3,%xmm1
   1f536:	f3 0f 5d c8          	minss  %xmm0,%xmm1
   1f53a:	0f 28 e1             	movaps %xmm1,%xmm4
   1f53d:	f3 0f c2 e1 03       	cmpunordss %xmm1,%xmm4
   1f542:	0f 28 c4             	movaps %xmm4,%xmm0
   1f545:	0f 55 c1             	andnps %xmm1,%xmm0
   1f548:	0f 54 e3             	andps  %xmm3,%xmm4
   1f54b:	0f 56 e0             	orps   %xmm0,%xmm4
   1f54e:	f3 0f 11 54 24 10    	movss  %xmm2,0x10(%rsp)
   1f554:	0f 29 64 24 20       	movaps %xmm4,0x20(%rsp)
   1f559:	f3 0f 11 64 24 14    	movss  %xmm4,0x14(%rsp)
   1f55f:	44 89 64 24 18       	mov    %r12d,0x18(%rsp)
   1f564:	44 89 7c 24 1c       	mov    %r15d,0x1c(%rsp)
   1f569:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   1f56e:	89 ee                	mov    %ebp,%esi
   1f570:	e8 2b 1f 00 00       	call   214a0 <gpui_canvas::color::gamut::in_gamut>
   1f575:	84 c0                	test   %al,%al
   1f577:	74 1c                	je     1f595 <<gpui_canvas::color::Color>::fit_chroma+0x1a5>
   1f579:	0f 28 44 24 20       	movaps 0x20(%rsp),%xmm0
   1f57e:	f3 0f 11 43 08       	movss  %xmm0,0x8(%rbx)
   1f583:	44 89 63 0c          	mov    %r12d,0xc(%rbx)
   1f587:	44 89 7b 10          	mov    %r15d,0x10(%rbx)
   1f58b:	31 c0                	xor    %eax,%eax
   1f58d:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   1f593:	eb 0d                	jmp    1f5a2 <<gpui_canvas::color::Color>::fit_chroma+0x1b2>
   1f595:	b8 01 00 00 00       	mov    $0x1,%eax
   1f59a:	f3 0f 10 05 4e 60 fe 	movss  -0x19fb2(%rip),%xmm0        # 55f0 <std::thread::current::id::ID+0x4978>
   1f5a1:	ff 
   1f5a2:	f3 0f 11 43 04       	movss  %xmm0,0x4(%rbx)
   1f5a7:	e9 c7 fe ff ff       	jmp    1f473 <<gpui_canvas::color::Color>::fit_chroma+0x83>
   1f5ac:	cc                   	int3
   1f5ad:	cc                   	int3
   1f5ae:	cc                   	int3
   1f5af:	cc                   	int3

gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>:
   1fab0:	55                   	push   %rbp
   1fab1:	48 89 e5             	mov    %rsp,%rbp
   1fab4:	41 57                	push   %r15
   1fab6:	41 56                	push   %r14
   1fab8:	41 55                	push   %r13
   1faba:	41 54                	push   %r12
   1fabc:	53                   	push   %rbx
   1fabd:	48 83 e4 e0          	and    $0xffffffffffffffe0,%rsp
   1fac1:	48 81 ec a0 02 00 00 	sub    $0x2a0,%rsp
   1fac8:	f3 0f 11 44 24 0c    	movss  %xmm0,0xc(%rsp)
   1face:	89 fb                	mov    %edi,%ebx
   1fad0:	0f 29 8c 24 d0 00 00 	movaps %xmm1,0xd0(%rsp)
   1fad7:	00 
   1fad8:	0f 57 c0             	xorps  %xmm0,%xmm0
   1fadb:	f3 0f 5a c1          	cvtss2sd %xmm1,%xmm0
   1fadf:	f2 0f 59 05 49 75 fe 	mulsd  -0x18ab7(%rip),%xmm0        # 7030 <std::thread::current::id::ID+0x63b8>
   1fae6:	ff 
   1fae7:	48 8d bc 24 18 01 00 	lea    0x118(%rsp),%rdi
   1faee:	00 
   1faef:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
   1faf6:	00 
   1faf7:	ff 15 c3 3d 04 00    	call   *0x43dc3(%rip)        # 638c0 <sincos@GLIBC_2.2.5>
   1fafd:	f2 0f 10 ac 24 18 01 	movsd  0x118(%rsp),%xmm5
   1fb04:	00 00 
   1fb06:	f2 0f 10 84 24 10 01 	movsd  0x110(%rsp),%xmm0
   1fb0d:	00 00 
   1fb0f:	f2 0f 10 0d 11 75 fe 	movsd  -0x18aef(%rip),%xmm1        # 7028 <std::thread::current::id::ID+0x63b0>
   1fb16:	ff 
   1fb17:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   1fb1b:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   1fb1f:	f2 0f 58 ca          	addsd  %xmm2,%xmm1
   1fb23:	f2 0f 10 1d 7d 74 fe 	movsd  -0x18b83(%rip),%xmm3        # 6fa8 <std::thread::current::id::ID+0x6330>
   1fb2a:	ff 
   1fb2b:	f2 0f 59 d8          	mulsd  %xmm0,%xmm3
   1fb2f:	f2 0f 58 da          	addsd  %xmm2,%xmm3
   1fb33:	f2 0f 10 35 9d 74 fe 	movsd  -0x18b63(%rip),%xmm6        # 6fd8 <std::thread::current::id::ID+0x6360>
   1fb3a:	ff 
   1fb3b:	f2 0f 59 f5          	mulsd  %xmm5,%xmm6
   1fb3f:	f2 0f 58 f1          	addsd  %xmm1,%xmm6
   1fb43:	f2 0f 10 3d 0d 75 fe 	movsd  -0x18af3(%rip),%xmm7        # 7058 <std::thread::current::id::ID+0x63e0>
   1fb4a:	ff 
   1fb4b:	f2 0f 59 fd          	mulsd  %xmm5,%xmm7
   1fb4f:	f2 0f 58 fb          	addsd  %xmm3,%xmm7
   1fb53:	f2 0f 59 05 bd 74 fe 	mulsd  -0x18b43(%rip),%xmm0        # 7018 <std::thread::current::id::ID+0x63a0>
   1fb5a:	ff 
   1fb5b:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   1fb5f:	f2 0f 59 2d 81 73 fe 	mulsd  -0x18c7f(%rip),%xmm5        # 6ee8 <std::thread::current::id::ID+0x6270>
   1fb66:	ff 
   1fb67:	f2 0f 58 e8          	addsd  %xmm0,%xmm5
   1fb6b:	85 db                	test   %ebx,%ebx
   1fb6d:	74 35                	je     1fba4 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xf4>
   1fb6f:	66 44 0f 28 2d e8 55 	movapd -0x1aa18(%rip),%xmm13        # 5160 <std::thread::current::id::ID+0x44e8>
   1fb76:	fe ff 
   1fb78:	66 0f 28 05 e0 59 fe 	movapd -0x1a620(%rip),%xmm0        # 5560 <std::thread::current::id::ID+0x48e8>
   1fb7f:	ff 
   1fb80:	66 44 0f 28 1d 37 5a 	movapd -0x1a5c9(%rip),%xmm11        # 55c0 <std::thread::current::id::ID+0x4948>
   1fb87:	fe ff 
   1fb89:	f3 0f 7e 15 8f 73 fe 	movq   -0x18c71(%rip),%xmm2        # 6f20 <std::thread::current::id::ID+0x62a8>
   1fb90:	ff 
   1fb91:	f3 0f 7e 25 27 74 fe 	movq   -0x18bd9(%rip),%xmm4        # 6fc0 <std::thread::current::id::ID+0x6348>
   1fb98:	ff 
   1fb99:	f3 44 0f 7e 05 86 73 	movq   -0x18c7a(%rip),%xmm8        # 6f28 <std::thread::current::id::ID+0x62b0>
   1fba0:	fe ff 
   1fba2:	eb 33                	jmp    1fbd7 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x127>
   1fba4:	66 44 0f 28 2d f3 57 	movapd -0x1a80d(%rip),%xmm13        # 53a0 <std::thread::current::id::ID+0x4728>
   1fbab:	fe ff 
   1fbad:	66 0f 28 05 bb 58 fe 	movapd -0x1a745(%rip),%xmm0        # 5470 <std::thread::current::id::ID+0x47f8>
   1fbb4:	ff 
   1fbb5:	66 44 0f 28 1d 72 57 	movapd -0x1a88e(%rip),%xmm11        # 5330 <std::thread::current::id::ID+0x46b8>
   1fbbc:	fe ff 
   1fbbe:	f3 0f 7e 15 42 74 fe 	movq   -0x18bbe(%rip),%xmm2        # 7008 <std::thread::current::id::ID+0x6390>
   1fbc5:	ff 
   1fbc6:	f3 0f 7e 25 2a 74 fe 	movq   -0x18bd6(%rip),%xmm4        # 6ff8 <std::thread::current::id::ID+0x6380>
   1fbcd:	ff 
   1fbce:	f3 44 0f 7e 05 b9 73 	movq   -0x18c47(%rip),%xmm8        # 6f90 <std::thread::current::id::ID+0x6318>
   1fbd5:	fe ff 
   1fbd7:	f3 0f 7e da          	movq   %xmm2,%xmm3
   1fbdb:	f3 0f 7e e4          	movq   %xmm4,%xmm4
   1fbdf:	f3 41 0f 7e d0       	movq   %xmm8,%xmm2
   1fbe4:	66 0f 14 f7          	unpcklpd %xmm7,%xmm6
   1fbe8:	66 0f 28 fe          	movapd %xmm6,%xmm7
   1fbec:	66 0f 59 fe          	mulpd  %xmm6,%xmm7
   1fbf0:	66 44 0f 28 c5       	movapd %xmm5,%xmm8
   1fbf5:	f2 44 0f 59 c5       	mulsd  %xmm5,%xmm8
   1fbfa:	f2 44 0f 59 c5       	mulsd  %xmm5,%xmm8
   1fbff:	66 0f 59 fe          	mulpd  %xmm6,%xmm7
   1fc03:	66 0f 29 7c 24 40    	movapd %xmm7,0x40(%rsp)
   1fc09:	f2 44 0f 11 44 24 50 	movsd  %xmm8,0x50(%rsp)
   1fc10:	f2 0f 10 7c 24 40    	movsd  0x40(%rsp),%xmm7
   1fc16:	66 0f 14 ff          	unpcklpd %xmm7,%xmm7
   1fc1a:	66 45 0f 28 c5       	movapd %xmm13,%xmm8
   1fc1f:	66 44 0f 59 c7       	mulpd  %xmm7,%xmm8
   1fc24:	66 0f 59 fb          	mulpd  %xmm3,%xmm7
   1fc28:	66 44 0f 10 64 24 48 	movupd 0x48(%rsp),%xmm12
   1fc2f:	66 45 0f 28 cc       	movapd %xmm12,%xmm9
   1fc34:	66 45 0f 14 cc       	unpcklpd %xmm12,%xmm9
   1fc39:	66 44 0f 28 d0       	movapd %xmm0,%xmm10
   1fc3e:	66 45 0f 59 d1       	mulpd  %xmm9,%xmm10
   1fc43:	66 45 0f 58 d0       	addpd  %xmm8,%xmm10
   1fc48:	66 44 0f 59 cc       	mulpd  %xmm4,%xmm9
   1fc4d:	66 44 0f 58 cf       	addpd  %xmm7,%xmm9
   1fc52:	66 45 0f 15 e4       	unpckhpd %xmm12,%xmm12
   1fc57:	66 45 0f 28 fb       	movapd %xmm11,%xmm15
   1fc5c:	66 45 0f 59 fc       	mulpd  %xmm12,%xmm15
   1fc61:	66 45 0f 58 fa       	addpd  %xmm10,%xmm15
   1fc66:	66 44 0f 29 bc 24 00 	movapd %xmm15,0x100(%rsp)
   1fc6d:	01 00 00 
   1fc70:	66 44 0f 59 e2       	mulpd  %xmm2,%xmm12
   1fc75:	66 45 0f 58 e1       	addpd  %xmm9,%xmm12
   1fc7a:	66 44 0f 29 64 24 20 	movapd %xmm12,0x20(%rsp)
   1fc81:	66 0f 28 fe          	movapd %xmm6,%xmm7
   1fc85:	66 0f 59 3d c3 55 fe 	mulpd  -0x1aa3d(%rip),%xmm7        # 5250 <std::thread::current::id::ID+0x45d8>
   1fc8c:	ff 
   1fc8d:	f2 44 0f 10 05 1a 73 	movsd  -0x18ce6(%rip),%xmm8        # 6fb0 <std::thread::current::id::ID+0x6338>
   1fc94:	fe ff 
   1fc96:	f2 44 0f 59 c5       	mulsd  %xmm5,%xmm8
   1fc9b:	f2 41 0f 59 e8       	mulsd  %xmm8,%xmm5
   1fca0:	66 0f 59 f7          	mulpd  %xmm7,%xmm6
   1fca4:	66 0f 29 74 24 40    	movapd %xmm6,0x40(%rsp)
   1fcaa:	f2 0f 11 6c 24 50    	movsd  %xmm5,0x50(%rsp)
   1fcb0:	f2 0f 10 6c 24 40    	movsd  0x40(%rsp),%xmm5
   1fcb6:	66 0f 14 ed          	unpcklpd %xmm5,%xmm5
   1fcba:	66 41 0f 28 f5       	movapd %xmm13,%xmm6
   1fcbf:	66 0f 59 f5          	mulpd  %xmm5,%xmm6
   1fcc3:	66 0f 59 eb          	mulpd  %xmm3,%xmm5
   1fcc7:	66 44 0f 10 74 24 48 	movupd 0x48(%rsp),%xmm14
   1fcce:	66 45 0f 28 ce       	movapd %xmm14,%xmm9
   1fcd3:	66 45 0f 14 ce       	unpcklpd %xmm14,%xmm9
   1fcd8:	66 44 0f 28 d0       	movapd %xmm0,%xmm10
   1fcdd:	66 45 0f 59 d1       	mulpd  %xmm9,%xmm10
   1fce2:	66 44 0f 58 d6       	addpd  %xmm6,%xmm10
   1fce7:	66 44 0f 59 cc       	mulpd  %xmm4,%xmm9
   1fcec:	66 44 0f 58 cd       	addpd  %xmm5,%xmm9
   1fcf1:	66 45 0f 15 f6       	unpckhpd %xmm14,%xmm14
   1fcf6:	66 41 0f 28 cb       	movapd %xmm11,%xmm1
   1fcfb:	66 41 0f 59 ce       	mulpd  %xmm14,%xmm1
   1fd00:	66 41 0f 58 ca       	addpd  %xmm10,%xmm1
   1fd05:	66 0f 29 8c 24 e0 00 	movapd %xmm1,0xe0(%rsp)
   1fd0c:	00 00 
   1fd0e:	66 44 0f 59 f2       	mulpd  %xmm2,%xmm14
   1fd13:	66 45 0f 58 f1       	addpd  %xmm9,%xmm14
   1fd18:	66 45 0f 28 ce       	movapd %xmm14,%xmm9
   1fd1d:	66 44 0f 29 b4 24 f0 	movapd %xmm14,0xf0(%rsp)
   1fd24:	00 00 00 
   1fd27:	66 0f 29 7c 24 40    	movapd %xmm7,0x40(%rsp)
   1fd2d:	f2 44 0f 11 44 24 50 	movsd  %xmm8,0x50(%rsp)
   1fd34:	f2 0f 10 6c 24 40    	movsd  0x40(%rsp),%xmm5
   1fd3a:	66 0f 14 ed          	unpcklpd %xmm5,%xmm5
   1fd3e:	66 41 0f 28 f5       	movapd %xmm13,%xmm6
   1fd43:	66 0f 59 f5          	mulpd  %xmm5,%xmm6
   1fd47:	66 0f 59 eb          	mulpd  %xmm3,%xmm5
   1fd4b:	66 44 0f 10 54 24 48 	movupd 0x48(%rsp),%xmm10
   1fd52:	66 41 0f 28 fa       	movapd %xmm10,%xmm7
   1fd57:	66 41 0f 14 fa       	unpcklpd %xmm10,%xmm7
   1fd5c:	66 44 0f 28 c0       	movapd %xmm0,%xmm8
   1fd61:	66 44 0f 59 c7       	mulpd  %xmm7,%xmm8
   1fd66:	66 44 0f 58 c6       	addpd  %xmm6,%xmm8
   1fd6b:	66 0f 59 fc          	mulpd  %xmm4,%xmm7
   1fd6f:	66 0f 58 fd          	addpd  %xmm5,%xmm7
   1fd73:	66 45 0f 15 d2       	unpckhpd %xmm10,%xmm10
   1fd78:	66 41 0f 28 eb       	movapd %xmm11,%xmm5
   1fd7d:	66 41 0f 59 ea       	mulpd  %xmm10,%xmm5
   1fd82:	66 41 0f 58 e8       	addpd  %xmm8,%xmm5
   1fd87:	66 44 0f 28 c5       	movapd %xmm5,%xmm8
   1fd8c:	66 0f 29 ac 24 80 01 	movapd %xmm5,0x180(%rsp)
   1fd93:	00 00 
   1fd95:	66 44 0f 59 d2       	mulpd  %xmm2,%xmm10
   1fd9a:	66 44 0f 58 d7       	addpd  %xmm7,%xmm10
   1fd9f:	66 44 0f 29 94 24 90 	movapd %xmm10,0x190(%rsp)
   1fda6:	01 00 00 
   1fda9:	0f 28 2d d0 56 fe ff 	movaps -0x1a930(%rip),%xmm5        # 5480 <std::thread::current::id::ID+0x4808>
   1fdb0:	0f 29 6c 24 40       	movaps %xmm5,0x40(%rsp)
   1fdb5:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
   1fdbc:	00 f0 3f 
   1fdbf:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   1fdc4:	66 0f 10 6c 24 48    	movupd 0x48(%rsp),%xmm5
   1fdca:	66 0f 28 f5          	movapd %xmm5,%xmm6
   1fdce:	66 0f 14 f5          	unpcklpd %xmm5,%xmm6
   1fdd2:	66 0f 59 c6          	mulpd  %xmm6,%xmm0
   1fdd6:	66 0f 59 f4          	mulpd  %xmm4,%xmm6
   1fdda:	66 41 0f 58 c5       	addpd  %xmm13,%xmm0
   1fddf:	66 0f 58 f3          	addpd  %xmm3,%xmm6
   1fde3:	66 0f 15 ed          	unpckhpd %xmm5,%xmm5
   1fde7:	66 44 0f 59 dd       	mulpd  %xmm5,%xmm11
   1fdec:	66 44 0f 58 d8       	addpd  %xmm0,%xmm11
   1fdf1:	66 44 0f 29 9c 24 a0 	movapd %xmm11,0x1a0(%rsp)
   1fdf8:	01 00 00 
   1fdfb:	66 0f 59 ea          	mulpd  %xmm2,%xmm5
   1fdff:	66 0f 58 ee          	addpd  %xmm6,%xmm5
   1fe03:	66 45 0f 57 f6       	xorpd  %xmm14,%xmm14
   1fe08:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
   1fe0c:	66 0f 16 05 54 71 fe 	movhpd -0x18eac(%rip),%xmm0        # 6f68 <std::thread::current::id::ID+0x62f0>
   1fe13:	ff 
   1fe14:	66 0f 58 c5          	addpd  %xmm5,%xmm0
   1fe18:	66 0f 29 84 24 70 01 	movapd %xmm0,0x170(%rsp)
   1fe1f:	00 00 
   1fe21:	66 41 0f 28 c7       	movapd %xmm15,%xmm0
   1fe26:	66 44 0f 28 3d 21 54 	movapd -0x1abdf(%rip),%xmm15        # 5250 <std::thread::current::id::ID+0x45d8>
   1fe2d:	fe ff 
   1fe2f:	66 41 0f 59 c7       	mulpd  %xmm15,%xmm0
   1fe34:	66 45 0f 59 fc       	mulpd  %xmm12,%xmm15
   1fe39:	66 44 0f 29 7c 24 30 	movapd %xmm15,0x30(%rsp)
   1fe40:	66 0f 28 e1          	movapd %xmm1,%xmm4
   1fe44:	66 0f 58 e1          	addpd  %xmm1,%xmm4
   1fe48:	66 0f 28 d8          	movapd %xmm0,%xmm3
   1fe4c:	66 44 0f 28 d8       	movapd %xmm0,%xmm11
   1fe51:	66 41 0f 59 d8       	mulpd  %xmm8,%xmm3
   1fe56:	66 41 0f 28 cf       	movapd %xmm15,%xmm1
   1fe5b:	66 41 0f 59 ca       	mulpd  %xmm10,%xmm1
   1fe60:	66 0f 28 05 28 54 fe 	movapd -0x1abd8(%rip),%xmm0        # 5290 <std::thread::current::id::ID+0x4618>
   1fe67:	ff 
   1fe68:	66 0f 59 d8          	mulpd  %xmm0,%xmm3
   1fe6c:	66 0f 28 f3          	movapd %xmm3,%xmm6
   1fe70:	66 0f 29 9c 24 f0 01 	movapd %xmm3,0x1f0(%rsp)
   1fe77:	00 00 
   1fe79:	66 0f 59 c8          	mulpd  %xmm0,%xmm1
   1fe7d:	66 0f 28 e9          	movapd %xmm1,%xmm5
   1fe81:	66 0f 29 8c 24 d0 01 	movapd %xmm1,0x1d0(%rsp)
   1fe88:	00 00 
   1fe8a:	66 0f 28 c4          	movapd %xmm4,%xmm0
   1fe8e:	66 41 0f c2 c6 01    	cmpltpd %xmm14,%xmm0
   1fe94:	66 0f 28 0d 34 57 fe 	movapd -0x1a8cc(%rip),%xmm1        # 55d0 <std::thread::current::id::ID+0x4958>
   1fe9b:	ff 
   1fe9c:	66 0f 28 d8          	movapd %xmm0,%xmm3
   1fea0:	66 0f 54 d9          	andpd  %xmm1,%xmm3
   1fea4:	66 44 0f 28 15 d3 55 	movapd -0x1aa2d(%rip),%xmm10        # 5480 <std::thread::current::id::ID+0x4808>
   1feab:	fe ff 
   1fead:	66 41 0f 55 c2       	andnpd %xmm10,%xmm0
   1feb2:	66 0f 56 c3          	orpd   %xmm3,%xmm0
   1feb6:	66 45 0f 28 e9       	movapd %xmm9,%xmm13
   1febb:	66 45 0f 58 e9       	addpd  %xmm9,%xmm13
   1fec0:	66 41 0f 28 dd       	movapd %xmm13,%xmm3
   1fec5:	66 41 0f c2 de 01    	cmpltpd %xmm14,%xmm3
   1fecb:	66 0f 54 cb          	andpd  %xmm3,%xmm1
   1fecf:	66 41 0f 55 da       	andnpd %xmm10,%xmm3
   1fed4:	66 0f 56 d9          	orpd   %xmm1,%xmm3
   1fed8:	66 0f 28 fc          	movapd %xmm4,%xmm7
   1fedc:	66 0f 59 fc          	mulpd  %xmm4,%xmm7
   1fee0:	66 0f 29 bc 24 c0 00 	movapd %xmm7,0xc0(%rsp)
   1fee7:	00 00 
   1fee9:	66 0f 5c fe          	subpd  %xmm6,%xmm7
   1feed:	66 0f 28 cf          	movapd %xmm7,%xmm1
   1fef1:	66 41 0f 5f ce       	maxpd  %xmm14,%xmm1
   1fef6:	66 44 0f 51 e1       	sqrtpd %xmm1,%xmm12
   1fefb:	66 44 0f 59 e0       	mulpd  %xmm0,%xmm12
   1ff00:	66 45 0f 28 c5       	movapd %xmm13,%xmm8
   1ff05:	66 45 0f 59 c5       	mulpd  %xmm13,%xmm8
   1ff0a:	66 44 0f 29 84 24 e0 	movapd %xmm8,0x1e0(%rsp)
   1ff11:	01 00 00 
   1ff14:	66 44 0f 5c c5       	subpd  %xmm5,%xmm8
   1ff19:	66 41 0f 28 c0       	movapd %xmm8,%xmm0
   1ff1e:	66 41 0f 5f c6       	maxpd  %xmm14,%xmm0
   1ff23:	66 0f 51 d0          	sqrtpd %xmm0,%xmm2
   1ff27:	66 0f 59 d3          	mulpd  %xmm3,%xmm2
   1ff2b:	66 44 0f 58 e4       	addpd  %xmm4,%xmm12
   1ff30:	66 41 0f 58 d5       	addpd  %xmm13,%xmm2
   1ff35:	66 0f 28 05 a3 56 fe 	movapd -0x1a95d(%rip),%xmm0        # 55e0 <std::thread::current::id::ID+0x4968>
   1ff3c:	ff 
   1ff3d:	66 44 0f 59 e0       	mulpd  %xmm0,%xmm12
   1ff42:	66 0f 59 d0          	mulpd  %xmm0,%xmm2
   1ff46:	66 41 0f 28 cb       	movapd %xmm11,%xmm1
   1ff4b:	66 44 0f 29 5c 24 10 	movapd %xmm11,0x10(%rsp)
   1ff52:	66 41 0f 28 c3       	movapd %xmm11,%xmm0
   1ff57:	66 41 0f c2 c6 00    	cmpeqpd %xmm14,%xmm0
   1ff5d:	66 44 0f 28 cc       	movapd %xmm4,%xmm9
   1ff62:	66 45 0f c2 ce 00    	cmpeqpd %xmm14,%xmm9
   1ff68:	66 45 0f 28 d9       	movapd %xmm9,%xmm11
   1ff6d:	66 44 0f 55 cc       	andnpd %xmm4,%xmm9
   1ff72:	66 41 0f c2 e6 04    	cmpneqpd %xmm14,%xmm4
   1ff78:	66 0f 54 e0          	andpd  %xmm0,%xmm4
   1ff7c:	66 44 0f 28 f8       	movapd %xmm0,%xmm15
   1ff81:	66 41 0f 54 c2       	andpd  %xmm10,%xmm0
   1ff86:	66 44 0f 55 f9       	andnpd %xmm1,%xmm15
   1ff8b:	66 44 0f 56 f8       	orpd   %xmm0,%xmm15
   1ff90:	66 0f 28 74 24 30    	movapd 0x30(%rsp),%xmm6
   1ff96:	66 0f 28 ce          	movapd %xmm6,%xmm1
   1ff9a:	66 41 0f c2 ce 00    	cmpeqpd %xmm14,%xmm1
   1ffa0:	66 41 0f 28 ed       	movapd %xmm13,%xmm5
   1ffa5:	66 41 0f c2 ee 00    	cmpeqpd %xmm14,%xmm5
   1ffab:	66 0f 28 dd          	movapd %xmm5,%xmm3
   1ffaf:	66 41 0f 55 ed       	andnpd %xmm13,%xmm5
   1ffb4:	66 45 0f c2 ee 04    	cmpneqpd %xmm14,%xmm13
   1ffba:	66 44 0f 54 e9       	andpd  %xmm1,%xmm13
   1ffbf:	66 44 0f 29 ac 24 c0 	movapd %xmm13,0x1c0(%rsp)
   1ffc6:	01 00 00 
   1ffc9:	66 0f 28 c1          	movapd %xmm1,%xmm0
   1ffcd:	66 41 0f 54 ca       	andpd  %xmm10,%xmm1
   1ffd2:	66 0f 55 c6          	andnpd %xmm6,%xmm0
   1ffd6:	66 0f 56 c1          	orpd   %xmm1,%xmm0
   1ffda:	66 41 0f 28 f4       	movapd %xmm12,%xmm6
   1ffdf:	66 41 0f c2 f6 00    	cmpeqpd %xmm14,%xmm6
   1ffe5:	66 0f 28 ce          	movapd %xmm6,%xmm1
   1ffe9:	66 41 0f 54 ca       	andpd  %xmm10,%xmm1
   1ffee:	66 41 0f 55 f4       	andnpd %xmm12,%xmm6
   1fff3:	66 0f 56 f1          	orpd   %xmm1,%xmm6
   1fff7:	66 44 0f 28 ea       	movapd %xmm2,%xmm13
   1fffc:	66 45 0f c2 ee 00    	cmpeqpd %xmm14,%xmm13
   20002:	66 41 0f 28 cd       	movapd %xmm13,%xmm1
   20007:	66 41 0f 54 ca       	andpd  %xmm10,%xmm1
   2000c:	66 44 0f 55 ea       	andnpd %xmm2,%xmm13
   20011:	66 44 0f 56 e9       	orpd   %xmm1,%xmm13
   20016:	66 44 0f 29 ac 24 b0 	movapd %xmm13,0x1b0(%rsp)
   2001d:	01 00 00 
   20020:	66 45 0f 54 da       	andpd  %xmm10,%xmm11
   20025:	66 45 0f 56 cb       	orpd   %xmm11,%xmm9
   2002a:	66 41 0f 54 da       	andpd  %xmm10,%xmm3
   2002f:	66 0f 56 eb          	orpd   %xmm3,%xmm5
   20033:	66 45 0f 28 dc       	movapd %xmm12,%xmm11
   20038:	66 45 0f 5e df       	divpd  %xmm15,%xmm11
   2003d:	66 44 0f 28 ea       	movapd %xmm2,%xmm13
   20042:	66 44 0f 5e e8       	divpd  %xmm0,%xmm13
   20047:	66 44 0f 28 3d f0 54 	movapd -0x1ab10(%rip),%xmm15        # 5540 <std::thread::current::id::ID+0x48c8>
   2004e:	fe ff 
   20050:	66 0f 28 84 24 00 01 	movapd 0x100(%rsp),%xmm0
   20057:	00 00 
   20059:	66 41 0f 57 c7       	xorpd  %xmm15,%xmm0
   2005e:	66 0f 29 44 24 40    	movapd %xmm0,0x40(%rsp)
   20064:	66 0f 28 44 24 20    	movapd 0x20(%rsp),%xmm0
   2006a:	66 41 0f 57 c7       	xorpd  %xmm15,%xmm0
   2006f:	66 0f 29 44 24 50    	movapd %xmm0,0x50(%rsp)
   20075:	66 0f 28 84 24 e0 00 	movapd 0xe0(%rsp),%xmm0
   2007c:	00 00 
   2007e:	66 41 0f 57 c7       	xorpd  %xmm15,%xmm0
   20083:	66 0f 29 44 24 60    	movapd %xmm0,0x60(%rsp)
   20089:	66 0f 28 84 24 f0 00 	movapd 0xf0(%rsp),%xmm0
   20090:	00 00 
   20092:	66 41 0f 57 c7       	xorpd  %xmm15,%xmm0
   20097:	66 0f 29 44 24 70    	movapd %xmm0,0x70(%rsp)
   2009d:	66 44 0f 28 94 24 80 	movapd 0x180(%rsp),%xmm10
   200a4:	01 00 00 
   200a7:	66 41 0f 28 c2       	movapd %xmm10,%xmm0
   200ac:	66 41 0f 57 c7       	xorpd  %xmm15,%xmm0
   200b1:	66 0f 29 84 24 80 00 	movapd %xmm0,0x80(%rsp)
   200b8:	00 00 
   200ba:	66 0f 28 c8          	movapd %xmm0,%xmm1
   200be:	66 41 0f 5e c9       	divpd  %xmm9,%xmm1
   200c3:	66 44 0f 28 8c 24 90 	movapd 0x190(%rsp),%xmm9
   200ca:	01 00 00 
   200cd:	66 41 0f 28 c1       	movapd %xmm9,%xmm0
   200d2:	66 41 0f 57 c7       	xorpd  %xmm15,%xmm0
   200d7:	66 0f 29 84 24 90 00 	movapd %xmm0,0x90(%rsp)
   200de:	00 00 
   200e0:	66 0f 28 d8          	movapd %xmm0,%xmm3
   200e4:	66 0f 5e dd          	divpd  %xmm5,%xmm3
   200e8:	66 0f 54 cc          	andpd  %xmm4,%xmm1
   200ec:	66 0f 28 05 0c 54 fe 	movapd -0x1abf4(%rip),%xmm0        # 5500 <std::thread::current::id::ID+0x4888>
   200f3:	ff 
   200f4:	66 0f 55 e0          	andnpd %xmm0,%xmm4
   200f8:	66 0f 56 e1          	orpd   %xmm1,%xmm4
   200fc:	66 0f 28 8c 24 c0 01 	movapd 0x1c0(%rsp),%xmm1
   20103:	00 00 
   20105:	66 0f 54 d9          	andpd  %xmm1,%xmm3
   20109:	66 0f 55 c8          	andnpd %xmm0,%xmm1
   2010d:	66 0f 56 cb          	orpd   %xmm3,%xmm1
   20111:	66 0f 28 e9          	movapd %xmm1,%xmm5
   20115:	66 0f 28 5c 24 10    	movapd 0x10(%rsp),%xmm3
   2011b:	66 41 0f c2 de 04    	cmpneqpd %xmm14,%xmm3
   20121:	66 0f 29 5c 24 10    	movapd %xmm3,0x10(%rsp)
   20127:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   2012b:	66 0f c2 cf 02       	cmplepd %xmm7,%xmm1
   20130:	66 0f 54 cb          	andpd  %xmm3,%xmm1
   20134:	66 44 0f 54 d9       	andpd  %xmm1,%xmm11
   20139:	66 45 0f c2 e6 04    	cmpneqpd %xmm14,%xmm12
   2013f:	66 44 0f 54 e1       	andpd  %xmm1,%xmm12
   20144:	66 0f 28 d9          	movapd %xmm1,%xmm3
   20148:	66 0f 55 dc          	andnpd %xmm4,%xmm3
   2014c:	66 41 0f 56 db       	orpd   %xmm11,%xmm3
   20151:	66 44 0f 28 5c 24 30 	movapd 0x30(%rsp),%xmm11
   20158:	66 45 0f c2 de 04    	cmpneqpd %xmm14,%xmm11
   2015e:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   20162:	66 41 0f c2 c8 02    	cmplepd %xmm8,%xmm1
   20168:	66 41 0f 54 cb       	andpd  %xmm11,%xmm1
   2016d:	66 44 0f 54 e9       	andpd  %xmm1,%xmm13
   20172:	66 41 0f c2 d6 04    	cmpneqpd %xmm14,%xmm2
   20178:	66 0f 54 d1          	andpd  %xmm1,%xmm2
   2017c:	66 0f 28 e1          	movapd %xmm1,%xmm4
   20180:	66 0f 55 e5          	andnpd %xmm5,%xmm4
   20184:	66 41 0f 56 e5       	orpd   %xmm13,%xmm4
   20189:	66 41 0f 28 ca       	movapd %xmm10,%xmm1
   2018e:	66 0f 5e ce          	divpd  %xmm6,%xmm1
   20192:	66 41 0f 28 f1       	movapd %xmm9,%xmm6
   20197:	66 0f 5e b4 24 b0 01 	divpd  0x1b0(%rsp),%xmm6
   2019e:	00 00 
   201a0:	66 41 0f 54 cc       	andpd  %xmm12,%xmm1
   201a5:	66 44 0f 55 e0       	andnpd %xmm0,%xmm12
   201aa:	66 44 0f 56 e1       	orpd   %xmm1,%xmm12
   201af:	66 0f 54 f2          	andpd  %xmm2,%xmm6
   201b3:	66 0f 55 d0          	andnpd %xmm0,%xmm2
   201b7:	66 0f 56 d6          	orpd   %xmm6,%xmm2
   201bb:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   201bf:	66 0f c2 cb 01       	cmpltpd %xmm3,%xmm1
   201c4:	66 0f 54 d9          	andpd  %xmm1,%xmm3
   201c8:	66 0f 55 c8          	andnpd %xmm0,%xmm1
   201cc:	66 0f 56 cb          	orpd   %xmm3,%xmm1
   201d0:	66 0f 57 db          	xorpd  %xmm3,%xmm3
   201d4:	66 0f c2 dc 01       	cmpltpd %xmm4,%xmm3
   201d9:	66 0f 54 e3          	andpd  %xmm3,%xmm4
   201dd:	66 0f 55 d8          	andnpd %xmm0,%xmm3
   201e1:	66 0f 56 dc          	orpd   %xmm4,%xmm3
   201e5:	66 0f 57 e4          	xorpd  %xmm4,%xmm4
   201e9:	66 41 0f c2 e4 01    	cmpltpd %xmm12,%xmm4
   201ef:	66 44 0f 54 e4       	andpd  %xmm4,%xmm12
   201f4:	66 0f 55 e0          	andnpd %xmm0,%xmm4
   201f8:	66 41 0f 56 e4       	orpd   %xmm12,%xmm4
   201fd:	66 0f 57 ed          	xorpd  %xmm5,%xmm5
   20201:	66 0f c2 ea 01       	cmpltpd %xmm2,%xmm5
   20206:	66 0f 54 d5          	andpd  %xmm5,%xmm2
   2020a:	66 0f 55 e8          	andnpd %xmm0,%xmm5
   2020e:	66 0f 56 ea          	orpd   %xmm2,%xmm5
   20212:	66 0f 28 05 e6 4e fe 	movapd -0x1b11a(%rip),%xmm0        # 5100 <std::thread::current::id::ID+0x4488>
   20219:	ff 
   2021a:	66 44 0f 28 ac 24 f0 	movapd 0x1f0(%rsp),%xmm13
   20221:	01 00 00 
   20224:	66 44 0f 54 e8       	andpd  %xmm0,%xmm13
   20229:	66 44 0f 58 ac 24 c0 	addpd  0xc0(%rsp),%xmm13
   20230:	00 00 00 
   20233:	66 44 0f 28 a4 24 d0 	movapd 0x1d0(%rsp),%xmm12
   2023a:	01 00 00 
   2023d:	66 44 0f 54 e0       	andpd  %xmm0,%xmm12
   20242:	66 44 0f 58 a4 24 e0 	addpd  0x1e0(%rsp),%xmm12
   20249:	01 00 00 
   2024c:	66 0f 54 f8          	andpd  %xmm0,%xmm7
   20250:	66 0f 28 35 e8 50 fe 	movapd -0x1af18(%rip),%xmm6        # 5340 <std::thread::current::id::ID+0x46c8>
   20257:	ff 
   20258:	66 44 0f 59 ee       	mulpd  %xmm6,%xmm13
   2025d:	66 41 0f c2 fd 02    	cmplepd %xmm13,%xmm7
   20263:	66 44 0f 59 e6       	mulpd  %xmm6,%xmm12
   20268:	66 44 0f 54 c0       	andpd  %xmm0,%xmm8
   2026d:	66 45 0f c2 c4 02    	cmplepd %xmm12,%xmm8
   20273:	66 0f 54 7c 24 10    	andpd  0x10(%rsp),%xmm7
   20279:	66 45 0f 54 c3       	andpd  %xmm11,%xmm8
   2027e:	66 0f 28 f1          	movapd %xmm1,%xmm6
   20282:	66 0f 5d f4          	minpd  %xmm4,%xmm6
   20286:	66 0f 55 fe          	andnpd %xmm6,%xmm7
   2028a:	66 0f 28 f3          	movapd %xmm3,%xmm6
   2028e:	66 0f 5d f5          	minpd  %xmm5,%xmm6
   20292:	66 44 0f 55 c6       	andnpd %xmm6,%xmm8
   20297:	66 0f 29 bc 24 00 02 	movapd %xmm7,0x200(%rsp)
   2029e:	00 00 
   202a0:	66 0f 5f cc          	maxpd  %xmm4,%xmm1
   202a4:	66 0f 5f dd          	maxpd  %xmm5,%xmm3
   202a8:	66 44 0f 29 84 24 10 	movapd %xmm8,0x210(%rsp)
   202af:	02 00 00 
   202b2:	66 0f 29 8c 24 20 02 	movapd %xmm1,0x220(%rsp)
   202b9:	00 00 
   202bb:	66 0f 29 9c 24 30 02 	movapd %xmm3,0x230(%rsp)
   202c2:	00 00 
   202c4:	66 0f 28 8c 24 e0 00 	movapd 0xe0(%rsp),%xmm1
   202cb:	00 00 
   202cd:	66 0f 28 e1          	movapd %xmm1,%xmm4
   202d1:	66 41 0f c2 e6 04    	cmpneqpd %xmm14,%xmm4
   202d7:	66 0f 54 c8          	andpd  %xmm0,%xmm1
   202db:	66 41 0f 28 ea       	movapd %xmm10,%xmm5
   202e0:	66 0f 54 e8          	andpd  %xmm0,%xmm5
   202e4:	66 0f 28 dc          	movapd %xmm4,%xmm3
   202e8:	66 0f 54 d9          	andpd  %xmm1,%xmm3
   202ec:	66 0f 55 e5          	andnpd %xmm5,%xmm4
   202f0:	66 0f 56 e3          	orpd   %xmm3,%xmm4
   202f4:	66 44 0f 28 9c 24 00 	movapd 0x100(%rsp),%xmm11
   202fb:	01 00 00 
   202fe:	66 41 0f 28 f3       	movapd %xmm11,%xmm6
   20303:	66 41 0f c2 f6 04    	cmpneqpd %xmm14,%xmm6
   20309:	66 44 0f 28 54 24 20 	movapd 0x20(%rsp),%xmm10
   20310:	66 41 0f 28 fa       	movapd %xmm10,%xmm7
   20315:	66 41 0f c2 fe 04    	cmpneqpd %xmm14,%xmm7
   2031b:	66 0f 28 9c 24 f0 00 	movapd 0xf0(%rsp),%xmm3
   20322:	00 00 
   20324:	66 44 0f c2 f3 04    	cmpneqpd %xmm3,%xmm14
   2032a:	66 0f 54 d8          	andpd  %xmm0,%xmm3
   2032e:	66 45 0f 28 c1       	movapd %xmm9,%xmm8
   20333:	66 44 0f 54 c0       	andpd  %xmm0,%xmm8
   20338:	66 45 0f 28 ce       	movapd %xmm14,%xmm9
   2033d:	66 44 0f 54 cb       	andpd  %xmm3,%xmm9
   20342:	66 45 0f 55 f0       	andnpd %xmm8,%xmm14
   20347:	66 45 0f 56 f1       	orpd   %xmm9,%xmm14
   2034c:	66 45 0f 28 cb       	movapd %xmm11,%xmm9
   20351:	66 44 0f 54 c8       	andpd  %xmm0,%xmm9
   20356:	66 44 0f 54 ce       	andpd  %xmm6,%xmm9
   2035b:	66 0f 55 f4          	andnpd %xmm4,%xmm6
   2035f:	66 41 0f 56 f1       	orpd   %xmm9,%xmm6
   20364:	66 41 0f 28 e2       	movapd %xmm10,%xmm4
   20369:	66 0f 54 e0          	andpd  %xmm0,%xmm4
   2036d:	66 0f 54 e7          	andpd  %xmm7,%xmm4
   20371:	66 41 0f 55 fe       	andnpd %xmm14,%xmm7
   20376:	66 0f 56 fc          	orpd   %xmm4,%xmm7
   2037a:	66 0f 28 15 ee 4d fe 	movapd -0x1b212(%rip),%xmm2        # 5170 <std::thread::current::id::ID+0x44f8>
   20381:	ff 
   20382:	66 0f 5f f2          	maxpd  %xmm2,%xmm6
   20386:	66 0f 5f fa          	maxpd  %xmm2,%xmm7
   2038a:	66 0f 5f cd          	maxpd  %xmm5,%xmm1
   2038e:	66 41 0f 5f d8       	maxpd  %xmm8,%xmm3
   20393:	66 0f 28 ac 24 a0 01 	movapd 0x1a0(%rsp),%xmm5
   2039a:	00 00 
   2039c:	66 0f 28 d5          	movapd %xmm5,%xmm2
   203a0:	66 0f 54 d0          	andpd  %xmm0,%xmm2
   203a4:	66 0f 5f ca          	maxpd  %xmm2,%xmm1
   203a8:	66 0f 5e ce          	divpd  %xmm6,%xmm1
   203ac:	66 0f 28 a4 24 70 01 	movapd 0x170(%rsp),%xmm4
   203b3:	00 00 
   203b5:	66 0f 54 c4          	andpd  %xmm4,%xmm0
   203b9:	66 0f 5f d8          	maxpd  %xmm0,%xmm3
   203bd:	66 0f 5e df          	divpd  %xmm7,%xmm3
   203c1:	f2 0f 10 05 9f 6b fe 	movsd  -0x19461(%rip),%xmm0        # 6f68 <std::thread::current::id::ID+0x62f0>
   203c8:	ff 
   203c9:	66 0f 28 15 af 50 fe 	movapd -0x1af51(%rip),%xmm2        # 5480 <std::thread::current::id::ID+0x4808>
   203d0:	ff 
   203d1:	66 0f 58 ca          	addpd  %xmm2,%xmm1
   203d5:	66 0f 58 da          	addpd  %xmm2,%xmm3
   203d9:	66 0f c2 c2 00       	cmpeqpd %xmm2,%xmm0
   203de:	66 0f c2 d2 00       	cmpeqpd %xmm2,%xmm2
   203e3:	66 0f 54 ca          	andpd  %xmm2,%xmm1
   203e7:	66 0f 28 35 91 50 fe 	movapd -0x1af6f(%rip),%xmm6        # 5480 <std::thread::current::id::ID+0x4808>
   203ee:	ff 
   203ef:	66 0f 55 d6          	andnpd %xmm6,%xmm2
   203f3:	66 0f 56 d1          	orpd   %xmm1,%xmm2
   203f7:	66 0f 29 94 24 40 02 	movapd %xmm2,0x240(%rsp)
   203fe:	00 00 
   20400:	66 0f 54 d8          	andpd  %xmm0,%xmm3
   20404:	66 0f 55 c6          	andnpd %xmm6,%xmm0
   20408:	66 0f 56 c3          	orpd   %xmm3,%xmm0
   2040c:	66 0f 29 84 24 50 02 	movapd %xmm0,0x250(%rsp)
   20413:	00 00 
   20415:	66 0f 28 c5          	movapd %xmm5,%xmm0
   20419:	66 41 0f 57 c7       	xorpd  %xmm15,%xmm0
   2041e:	66 0f 29 84 24 a0 00 	movapd %xmm0,0xa0(%rsp)
   20425:	00 00 
   20427:	66 44 0f 57 fc       	xorpd  %xmm4,%xmm15
   2042c:	66 44 0f 29 bc 24 b0 	movapd %xmm15,0xb0(%rsp)
   20433:	00 00 00 
   20436:	48 8d bc 24 20 01 00 	lea    0x120(%rsp),%rdi
   2043d:	00 
   2043e:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
   20443:	48 8d 94 24 00 02 00 	lea    0x200(%rsp),%rdx
   2044a:	00 
   2044b:	48 8d 8c 24 40 02 00 	lea    0x240(%rsp),%rcx
   20452:	00 
   20453:	41 b8 60 00 00 00    	mov    $0x60,%r8d
   20459:	e8 62 03 00 00       	call   207c0 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::entry::<fearless_simd::generated::sse2::Sse2, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::sse2::Sse2>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>, usize, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::sse2::Sse2>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2]>>
   2045e:	f2 0f 10 84 24 20 01 	movsd  0x120(%rsp),%xmm0
   20465:	00 00 
   20467:	f2 0f 10 8c 24 28 01 	movsd  0x128(%rsp),%xmm1
   2046e:	00 00 
   20470:	f2 0f 10 9c 24 30 01 	movsd  0x130(%rsp),%xmm3
   20477:	00 00 
   20479:	f2 0f 5d 05 af 6a fe 	minsd  -0x19551(%rip),%xmm0        # 6f30 <std::thread::current::id::ID+0x62b8>
   20480:	ff 
   20481:	f2 0f 5d c8          	minsd  %xmm0,%xmm1
   20485:	f2 0f 5d d9          	minsd  %xmm1,%xmm3
   20489:	66 48 0f 7e d8       	movq   %xmm3,%rax
   2048e:	49 bf ff ff ff ff ff 	movabs $0x7fffffffffffffff,%r15
   20495:	ff ff 7f 
   20498:	4c 21 f8             	and    %r15,%rax
   2049b:	41 be 0e 00 00 00    	mov    $0xe,%r14d
   204a1:	48 b9 ff ff ff ff ff 	movabs $0x7fefffffffffffff,%rcx
   204a8:	ff ef 7f 
   204ab:	48 39 c8             	cmp    %rcx,%rax
   204ae:	7e 12                	jle    204c2 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xa12>
   204b0:	4c 89 f0             	mov    %r14,%rax
   204b3:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
   204b7:	5b                   	pop    %rbx
   204b8:	41 5c                	pop    %r12
   204ba:	41 5d                	pop    %r13
   204bc:	41 5e                	pop    %r14
   204be:	41 5f                	pop    %r15
   204c0:	5d                   	pop    %rbp
   204c1:	c3                   	ret
   204c2:	0f 28 84 24 40 01 00 	movaps 0x140(%rsp),%xmm0
   204c9:	00 
   204ca:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   204cf:	0f 28 84 24 50 01 00 	movaps 0x150(%rsp),%xmm0
   204d6:	00 
   204d7:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
   204dc:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   204e2:	0f 57 c9             	xorps  %xmm1,%xmm1
   204e5:	f3 0f 5a c8          	cvtss2sd %xmm0,%xmm1
   204e9:	0f 28 c1             	movaps %xmm1,%xmm0
   204ec:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   204f0:	f2 0f 11 8c 24 c0 00 	movsd  %xmm1,0xc0(%rsp)
   204f7:	00 00 
   204f9:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   204fd:	f2 0f 10 0d 63 6a fe 	movsd  -0x1959d(%rip),%xmm1        # 6f68 <std::thread::current::id::ID+0x62f0>
   20504:	ff 
   20505:	f2 0f 5e c8          	divsd  %xmm0,%xmm1
   20509:	66 0f 14 c9          	unpcklpd %xmm1,%xmm1
   2050d:	66 0f 28 84 24 a0 01 	movapd 0x1a0(%rsp),%xmm0
   20514:	00 00 
   20516:	66 0f 5c c1          	subpd  %xmm1,%xmm0
   2051a:	66 0f 29 84 24 a0 00 	movapd %xmm0,0xa0(%rsp)
   20521:	00 00 
   20523:	66 0f 28 94 24 70 01 	movapd 0x170(%rsp),%xmm2
   2052a:	00 00 
   2052c:	66 0f 5c d1          	subpd  %xmm1,%xmm2
   20530:	0f 28 84 24 00 01 00 	movaps 0x100(%rsp),%xmm0
   20537:	00 
   20538:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
   2053d:	0f 28 44 24 20       	movaps 0x20(%rsp),%xmm0
   20542:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
   20547:	0f 28 84 24 e0 00 00 	movaps 0xe0(%rsp),%xmm0
   2054e:	00 
   2054f:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
   20554:	0f 28 84 24 f0 00 00 	movaps 0xf0(%rsp),%xmm0
   2055b:	00 
   2055c:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
   20561:	0f 28 84 24 80 01 00 	movaps 0x180(%rsp),%xmm0
   20568:	00 
   20569:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
   20570:	00 
   20571:	0f 28 84 24 90 01 00 	movaps 0x190(%rsp),%xmm0
   20578:	00 
   20579:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
   20580:	00 
   20581:	66 0f 29 94 24 b0 00 	movapd %xmm2,0xb0(%rsp)
   20588:	00 00 
   2058a:	66 0f 28 c3          	movapd %xmm3,%xmm0
   2058e:	66 0f 14 c3          	unpcklpd %xmm3,%xmm0
   20592:	66 0f 29 84 24 60 02 	movapd %xmm0,0x260(%rsp)
   20599:	00 00 
   2059b:	66 0f 29 84 24 70 02 	movapd %xmm0,0x270(%rsp)
   205a2:	00 00 
   205a4:	48 8d bc 24 20 01 00 	lea    0x120(%rsp),%rdi
   205ab:	00 
   205ac:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
   205b1:	48 8d 94 24 00 02 00 	lea    0x200(%rsp),%rdx
   205b8:	00 
   205b9:	48 8d 8c 24 60 02 00 	lea    0x260(%rsp),%rcx
   205c0:	00 
   205c1:	41 b8 40 00 00 00    	mov    $0x40,%r8d
   205c7:	0f 29 5c 24 20       	movaps %xmm3,0x20(%rsp)
   205cc:	e8 ef 01 00 00       	call   207c0 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::entry::<fearless_simd::generated::sse2::Sse2, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::sse2::Sse2>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>, usize, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::sse2::Sse2>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2]>>
   205d1:	66 0f 28 54 24 20    	movapd 0x20(%rsp),%xmm2
   205d7:	66 0f 28 c2          	movapd %xmm2,%xmm0
   205db:	f2 0f 5d 84 24 20 01 	minsd  0x120(%rsp),%xmm0
   205e2:	00 00 
   205e4:	66 0f 28 c8          	movapd %xmm0,%xmm1
   205e8:	f2 0f c2 c8 03       	cmpunordsd %xmm0,%xmm1
   205ed:	66 0f 54 d1          	andpd  %xmm1,%xmm2
   205f1:	66 0f 55 c8          	andnpd %xmm0,%xmm1
   205f5:	66 0f 56 ca          	orpd   %xmm2,%xmm1
   205f9:	f2 0f 10 84 24 28 01 	movsd  0x128(%rsp),%xmm0
   20600:	00 00 
   20602:	66 0f 28 d1          	movapd %xmm1,%xmm2
   20606:	f2 0f 5d d0          	minsd  %xmm0,%xmm2
   2060a:	66 0f 28 da          	movapd %xmm2,%xmm3
   2060e:	f2 0f c2 da 03       	cmpunordsd %xmm2,%xmm3
   20613:	66 0f 54 cb          	andpd  %xmm3,%xmm1
   20617:	66 0f 55 da          	andnpd %xmm2,%xmm3
   2061b:	66 0f 56 d9          	orpd   %xmm1,%xmm3
   2061f:	f2 0f 10 84 24 30 01 	movsd  0x130(%rsp),%xmm0
   20626:	00 00 
   20628:	66 0f 28 cb          	movapd %xmm3,%xmm1
   2062c:	66 0f 28 54 24 10    	movapd 0x10(%rsp),%xmm2
   20632:	66 0f 5d 94 24 40 01 	minpd  0x140(%rsp),%xmm2
   20639:	00 00 
   2063b:	f2 0f 5d c8          	minsd  %xmm0,%xmm1
   2063f:	66 0f 28 c1          	movapd %xmm1,%xmm0
   20643:	f2 0f c2 c1 03       	cmpunordsd %xmm1,%xmm0
   20648:	66 0f 54 d8          	andpd  %xmm0,%xmm3
   2064c:	66 0f 55 c1          	andnpd %xmm1,%xmm0
   20650:	66 0f 56 c3          	orpd   %xmm3,%xmm0
   20654:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
   20658:	0f 87 52 fe ff ff    	ja     204b0 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xa00>
   2065e:	66 0f 28 ca          	movapd %xmm2,%xmm1
   20662:	66 0f 15 ca          	unpckhpd %xmm2,%xmm1
   20666:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
   2066a:	0f 87 40 fe ff ff    	ja     204b0 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xa00>
   20670:	66 0f 28 4c 24 30    	movapd 0x30(%rsp),%xmm1
   20676:	f2 0f 5d 8c 24 50 01 	minsd  0x150(%rsp),%xmm1
   2067d:	00 00 
   2067f:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
   20683:	0f 87 27 fe ff ff    	ja     204b0 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xa00>
   20689:	f2 0f 59 84 24 c0 00 	mulsd  0xc0(%rsp),%xmm0
   20690:	00 00 
   20692:	66 48 0f 7e c0       	movq   %xmm0,%rax
   20697:	48 85 c0             	test   %rax,%rax
   2069a:	0f 98 c1             	sets   %cl
   2069d:	49 21 c7             	and    %rax,%r15
   206a0:	48 b8 00 00 00 00 00 	movabs $0xfff0000000000000,%rax
   206a7:	00 f0 ff 
   206aa:	4c 01 f8             	add    %r15,%rax
   206ad:	48 c1 e8 35          	shr    $0x35,%rax
   206b1:	3d ff 03 00 00       	cmp    $0x3ff,%eax
   206b6:	0f 92 c0             	setb   %al
   206b9:	20 c8                	and    %cl,%al
   206bb:	49 8d 57 ff          	lea    -0x1(%r15),%rdx
   206bf:	48 be ff ff ff ff ff 	movabs $0xfffffffffffff,%rsi
   206c6:	ff 0f 00 
   206c9:	48 39 f2             	cmp    %rsi,%rdx
   206cc:	0f 92 c2             	setb   %dl
   206cf:	20 ca                	and    %cl,%dl
   206d1:	48 b9 00 00 00 00 00 	movabs $0x7ff0000000000000,%rcx
   206d8:	00 f0 7f 
   206db:	49 39 cf             	cmp    %rcx,%r15
   206de:	0f 9f c1             	setg   %cl
   206e1:	40 0f 94 c6          	sete   %sil
   206e5:	40 08 ce             	or     %cl,%sil
   206e8:	40 08 d6             	or     %dl,%sil
   206eb:	40 08 c6             	or     %al,%sil
   206ee:	0f 85 bc fd ff ff    	jne    204b0 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xa00>
   206f4:	0f 57 c9             	xorps  %xmm1,%xmm1
   206f7:	f2 0f 5a c8          	cvtsd2ss %xmm0,%xmm1
   206fb:	0f 28 84 24 d0 00 00 	movaps 0xd0(%rsp),%xmm0
   20702:	00 
   20703:	0f 56 05 76 4e fe ff 	orps   -0x1b18a(%rip),%xmm0        # 5580 <std::thread::current::id::ID+0x4908>
   2070a:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
   20711:	00 
   20712:	41 bc 40 00 00 00    	mov    $0x40,%r12d
   20718:	0f b6 db             	movzbl %bl,%ebx
   2071b:	4c 8d 7c 24 40       	lea    0x40(%rsp),%r15
   20720:	eb 1b                	jmp    2073d <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xc8d>
   20722:	41 bd 01 00 00 80    	mov    $0x80000001,%r13d
   20728:	66 41 0f 6e cd       	movd   %r13d,%xmm1
   2072d:	0f 57 c0             	xorps  %xmm0,%xmm0
   20730:	f3 0f 5f c8          	maxss  %xmm0,%xmm1
   20734:	41 ff cc             	dec    %r12d
   20737:	0f 84 73 fd ff ff    	je     204b0 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xa00>
   2073d:	66 41 0f 7e cd       	movd   %xmm1,%r13d
   20742:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   20748:	f3 0f 11 44 24 40    	movss  %xmm0,0x40(%rsp)
   2074e:	f3 0f 11 4c 24 10    	movss  %xmm1,0x10(%rsp)
   20754:	f3 0f 11 4c 24 44    	movss  %xmm1,0x44(%rsp)
   2075a:	0f 28 84 24 d0 00 00 	movaps 0xd0(%rsp),%xmm0
   20761:	00 
   20762:	f3 0f 11 44 24 48    	movss  %xmm0,0x48(%rsp)
   20768:	c7 44 24 4c 00 00 80 	movl   $0xff800000,0x4c(%rsp)
   2076f:	ff 
   20770:	4c 89 ff             	mov    %r15,%rdi
   20773:	89 de                	mov    %ebx,%esi
   20775:	e8 26 0d 00 00       	call   214a0 <gpui_canvas::color::gamut::in_gamut>
   2077a:	84 c0                	test   %al,%al
   2077c:	75 28                	jne    207a6 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xcf6>
   2077e:	41 81 fd 00 00 80 ff 	cmp    $0xff800000,%r13d
   20785:	66 0f 6e 4c 24 10    	movd   0x10(%rsp),%xmm1
   2078b:	74 a0                	je     2072d <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xc7d>
   2078d:	44 89 e8             	mov    %r13d,%eax
   20790:	25 ff ff ff 7f       	and    $0x7fffffff,%eax
   20795:	74 8b                	je     20722 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xc72>
   20797:	41 39 c5             	cmp    %eax,%r13d
   2079a:	75 05                	jne    207a1 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xcf1>
   2079c:	41 ff cd             	dec    %r13d
   2079f:	eb 87                	jmp    20728 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xc78>
   207a1:	41 ff c5             	inc    %r13d
   207a4:	eb 82                	jmp    20728 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xc78>
   207a6:	49 c1 e5 20          	shl    $0x20,%r13
   207aa:	41 be ff ff ff ff    	mov    $0xffffffff,%r14d
   207b0:	4d 09 ee             	or     %r13,%r14
   207b3:	e9 f8 fc ff ff       	jmp    204b0 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xa00>
   207b8:	cc                   	int3
   207b9:	cc                   	int3
   207ba:	cc                   	int3
   207bb:	cc                   	int3
   207bc:	cc                   	int3
   207bd:	cc                   	int3
   207be:	cc                   	int3
   207bf:	cc                   	int3

<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::entry::<fearless_simd::generated::sse2::Sse2, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::sse2::Sse2>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>, usize, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::sse2::Sse2>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2]>:
   207c0:	55                   	push   %rbp
   207c1:	48 89 e5             	mov    %rsp,%rbp
   207c4:	48 83 e4 e0          	and    $0xffffffffffffffe0,%rsp
   207c8:	48 81 ec e0 03 00 00 	sub    $0x3e0,%rsp
   207cf:	66 44 0f 28 0e       	movapd (%rsi),%xmm9
   207d4:	66 44 0f 28 66 10    	movapd 0x10(%rsi),%xmm12
   207da:	66 44 0f 28 7e 20    	movapd 0x20(%rsi),%xmm15
   207e0:	66 0f 28 66 30       	movapd 0x30(%rsi),%xmm4
   207e5:	66 0f 28 6e 40       	movapd 0x40(%rsi),%xmm5
   207ea:	66 0f 28 76 60       	movapd 0x60(%rsi),%xmm6
   207ef:	66 0f 28 7e 70       	movapd 0x70(%rsi),%xmm7
   207f4:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   207f8:	66 0f c2 d6 01       	cmpltpd %xmm6,%xmm2
   207fd:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
   20801:	66 0f c2 c7 01       	cmpltpd %xmm7,%xmm0
   20806:	66 0f 28 0d f2 4c fe 	movapd -0x1b30e(%rip),%xmm1        # 5500 <std::thread::current::id::ID+0x4888>
   2080d:	ff 
   2080e:	66 0f 55 d1          	andnpd %xmm1,%xmm2
   20812:	66 0f 29 54 24 50    	movapd %xmm2,0x50(%rsp)
   20818:	66 0f 55 c1          	andnpd %xmm1,%xmm0
   2081c:	66 0f 29 44 24 60    	movapd %xmm0,0x60(%rsp)
   20822:	0f 28 42 20          	movaps 0x20(%rdx),%xmm0
   20826:	0f 28 4a 30          	movaps 0x30(%rdx),%xmm1
   2082a:	0f 29 84 24 60 02 00 	movaps %xmm0,0x260(%rsp)
   20831:	00 
   20832:	0f 29 8c 24 70 02 00 	movaps %xmm1,0x270(%rsp)
   20839:	00 
   2083a:	0f 28 02             	movaps (%rdx),%xmm0
   2083d:	0f 29 84 24 40 02 00 	movaps %xmm0,0x240(%rsp)
   20844:	00 
   20845:	0f 28 42 10          	movaps 0x10(%rdx),%xmm0
   20849:	0f 29 84 24 50 02 00 	movaps %xmm0,0x250(%rsp)
   20850:	00 
   20851:	0f 28 84 24 40 02 00 	movaps 0x240(%rsp),%xmm0
   20858:	00 
   20859:	0f 28 8c 24 50 02 00 	movaps 0x250(%rsp),%xmm1
   20860:	00 
   20861:	0f 28 94 24 60 02 00 	movaps 0x260(%rsp),%xmm2
   20868:	00 
   20869:	0f 28 9c 24 70 02 00 	movaps 0x270(%rsp),%xmm3
   20870:	00 
   20871:	0f 29 9c 24 30 03 00 	movaps %xmm3,0x330(%rsp)
   20878:	00 
   20879:	0f 29 94 24 20 03 00 	movaps %xmm2,0x320(%rsp)
   20880:	00 
   20881:	0f 29 8c 24 10 03 00 	movaps %xmm1,0x310(%rsp)
   20888:	00 
   20889:	0f 29 84 24 00 03 00 	movaps %xmm0,0x300(%rsp)
   20890:	00 
   20891:	0f 28 84 24 30 03 00 	movaps 0x330(%rsp),%xmm0
   20898:	00 
   20899:	0f 29 84 24 90 03 00 	movaps %xmm0,0x390(%rsp)
   208a0:	00 
   208a1:	0f 28 84 24 f0 02 00 	movaps 0x2f0(%rsp),%xmm0
   208a8:	00 
   208a9:	0f 28 8c 24 00 03 00 	movaps 0x300(%rsp),%xmm1
   208b0:	00 
   208b1:	0f 28 94 24 10 03 00 	movaps 0x310(%rsp),%xmm2
   208b8:	00 
   208b9:	0f 28 9c 24 20 03 00 	movaps 0x320(%rsp),%xmm3
   208c0:	00 
   208c1:	0f 29 9c 24 80 03 00 	movaps %xmm3,0x380(%rsp)
   208c8:	00 
   208c9:	0f 29 94 24 70 03 00 	movaps %xmm2,0x370(%rsp)
   208d0:	00 
   208d1:	0f 29 8c 24 60 03 00 	movaps %xmm1,0x360(%rsp)
   208d8:	00 
   208d9:	0f 29 84 24 50 03 00 	movaps %xmm0,0x350(%rsp)
   208e0:	00 
   208e1:	66 0f 28 05 17 4c fe 	movapd -0x1b3e9(%rip),%xmm0        # 5500 <std::thread::current::id::ID+0x4888>
   208e8:	ff 
   208e9:	66 0f 29 84 24 a0 03 	movapd %xmm0,0x3a0(%rsp)
   208f0:	00 00 
   208f2:	66 0f 29 84 24 b0 03 	movapd %xmm0,0x3b0(%rsp)
   208f9:	00 00 
   208fb:	48 8d 84 24 60 03 00 	lea    0x360(%rsp),%rax
   20902:	00 
   20903:	66 0f 28 0d f5 47 fe 	movapd -0x1b80b(%rip),%xmm1        # 5100 <std::thread::current::id::ID+0x4488>
   2090a:	ff 
   2090b:	66 41 0f 28 d1       	movapd %xmm9,%xmm2
   20910:	66 0f 54 d1          	andpd  %xmm1,%xmm2
   20914:	66 41 0f 28 dc       	movapd %xmm12,%xmm3
   20919:	66 0f 54 d9          	andpd  %xmm1,%xmm3
   2091d:	66 45 0f 28 c7       	movapd %xmm15,%xmm8
   20922:	66 44 0f 54 c1       	andpd  %xmm1,%xmm8
   20927:	66 44 0f 28 d4       	movapd %xmm4,%xmm10
   2092c:	66 44 0f 54 d1       	andpd  %xmm1,%xmm10
   20931:	66 0f 29 ac 24 30 02 	movapd %xmm5,0x230(%rsp)
   20938:	00 00 
   2093a:	66 0f 54 e9          	andpd  %xmm1,%xmm5
   2093e:	66 0f 29 ac 24 20 02 	movapd %xmm5,0x220(%rsp)
   20945:	00 00 
   20947:	66 0f 28 6e 50       	movapd 0x50(%rsi),%xmm5
   2094c:	66 0f 29 ac 24 e0 00 	movapd %xmm5,0xe0(%rsp)
   20953:	00 00 
   20955:	66 0f 54 e9          	andpd  %xmm1,%xmm5
   20959:	66 0f 29 ac 24 b0 00 	movapd %xmm5,0xb0(%rsp)
   20960:	00 00 
   20962:	66 0f 28 ee          	movapd %xmm6,%xmm5
   20966:	66 0f 54 e9          	andpd  %xmm1,%xmm5
   2096a:	66 0f 29 ac 24 90 02 	movapd %xmm5,0x290(%rsp)
   20971:	00 00 
   20973:	66 0f 28 ef          	movapd %xmm7,%xmm5
   20977:	66 0f 54 e9          	andpd  %xmm1,%xmm5
   2097b:	66 0f 29 ac 24 80 02 	movapd %xmm5,0x280(%rsp)
   20982:	00 00 
   20984:	66 0f 28 0d c4 48 fe 	movapd -0x1b73c(%rip),%xmm1        # 5250 <std::thread::current::id::ID+0x45d8>
   2098b:	ff 
   2098c:	66 41 0f 28 e9       	movapd %xmm9,%xmm5
   20991:	66 0f 59 e9          	mulpd  %xmm1,%xmm5
   20995:	66 0f 29 ac 24 10 02 	movapd %xmm5,0x210(%rsp)
   2099c:	00 00 
   2099e:	66 41 0f 28 ec       	movapd %xmm12,%xmm5
   209a3:	66 0f 59 e9          	mulpd  %xmm1,%xmm5
   209a7:	66 0f 29 ac 24 00 02 	movapd %xmm5,0x200(%rsp)
   209ae:	00 00 
   209b0:	66 41 0f 28 ef       	movapd %xmm15,%xmm5
   209b5:	66 41 0f 58 ef       	addpd  %xmm15,%xmm5
   209ba:	66 0f 29 ac 24 20 01 	movapd %xmm5,0x120(%rsp)
   209c1:	00 00 
   209c3:	66 0f 28 ec          	movapd %xmm4,%xmm5
   209c7:	66 0f 58 ec          	addpd  %xmm4,%xmm5
   209cb:	66 0f 29 ac 24 f0 01 	movapd %xmm5,0x1f0(%rsp)
   209d2:	00 00 
   209d4:	66 0f 29 94 24 70 01 	movapd %xmm2,0x170(%rsp)
   209db:	00 00 
   209dd:	66 0f 59 d1          	mulpd  %xmm1,%xmm2
   209e1:	66 0f 29 94 24 10 01 	movapd %xmm2,0x110(%rsp)
   209e8:	00 00 
   209ea:	66 0f 29 9c 24 b0 02 	movapd %xmm3,0x2b0(%rsp)
   209f1:	00 00 
   209f3:	66 0f 59 cb          	mulpd  %xmm3,%xmm1
   209f7:	66 0f 29 8c 24 30 01 	movapd %xmm1,0x130(%rsp)
   209fe:	00 00 
   20a00:	66 44 0f 29 84 24 60 	movapd %xmm8,0x160(%rsp)
   20a07:	01 00 00 
   20a0a:	66 45 0f 58 c0       	addpd  %xmm8,%xmm8
   20a0f:	66 44 0f 29 84 24 00 	movapd %xmm8,0x100(%rsp)
   20a16:	01 00 00 
   20a19:	66 44 0f 29 94 24 a0 	movapd %xmm10,0x2a0(%rsp)
   20a20:	02 00 00 
   20a23:	66 45 0f 58 d2       	addpd  %xmm10,%xmm10
   20a28:	66 44 0f 29 94 24 f0 	movapd %xmm10,0xf0(%rsp)
   20a2f:	00 00 00 
   20a32:	31 d2                	xor    %edx,%edx
   20a34:	0f 28 09             	movaps (%rcx),%xmm1
   20a37:	0f 29 8c 24 50 01 00 	movaps %xmm1,0x150(%rsp)
   20a3e:	00 
   20a3f:	0f 28 49 10          	movaps 0x10(%rcx),%xmm1
   20a43:	0f 29 8c 24 40 01 00 	movaps %xmm1,0x140(%rsp)
   20a4a:	00 
   20a4b:	66 0f 57 ed          	xorpd  %xmm5,%xmm5
   20a4f:	66 45 0f 57 c0       	xorpd  %xmm8,%xmm8
   20a54:	66 0f 28 c8          	movapd %xmm0,%xmm1
   20a58:	66 0f 29 44 24 70    	movapd %xmm0,0x70(%rsp)
   20a5e:	66 44 0f 29 8c 24 e0 	movapd %xmm9,0x1e0(%rsp)
   20a65:	01 00 00 
   20a68:	66 44 0f 29 a4 24 d0 	movapd %xmm12,0x1d0(%rsp)
   20a6f:	01 00 00 
   20a72:	66 44 0f 29 bc 24 c0 	movapd %xmm15,0x1c0(%rsp)
   20a79:	01 00 00 
   20a7c:	66 0f 29 a4 24 b0 01 	movapd %xmm4,0x1b0(%rsp)
   20a83:	00 00 
   20a85:	66 0f 29 b4 24 a0 01 	movapd %xmm6,0x1a0(%rsp)
   20a8c:	00 00 
   20a8e:	66 0f 29 bc 24 90 01 	movapd %xmm7,0x190(%rsp)
   20a95:	00 00 
   20a97:	e9 95 00 00 00       	jmp    20b31 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::entry::<fearless_simd::generated::sse2::Sse2, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::sse2::Sse2>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>, usize, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::sse2::Sse2>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2]>+0x371>
   20a9c:	0f 1f 40 00          	nopl   0x0(%rax)
   20aa0:	48 ff c2             	inc    %rdx
   20aa3:	66 44 0f 28 84 24 80 	movapd 0x80(%rsp),%xmm8
   20aaa:	00 00 00 
   20aad:	66 41 0f 28 d0       	movapd %xmm8,%xmm2
   20ab2:	66 0f 5c 54 24 40    	subpd  0x40(%rsp),%xmm2
   20ab8:	66 0f 28 ac 24 90 00 	movapd 0x90(%rsp),%xmm5
   20abf:	00 00 
   20ac1:	66 0f 28 dd          	movapd %xmm5,%xmm3
   20ac5:	66 0f 5c 9c 24 a0 00 	subpd  0xa0(%rsp),%xmm3
   20acc:	00 00 
   20ace:	66 0f 57 e4          	xorpd  %xmm4,%xmm4
   20ad2:	66 0f 5f d4          	maxpd  %xmm4,%xmm2
   20ad6:	66 0f 5f dc          	maxpd  %xmm4,%xmm3
   20ada:	66 0f 54 94 24 d0 00 	andpd  0xd0(%rsp),%xmm2
   20ae1:	00 00 
   20ae3:	66 0f 54 9c 24 c0 00 	andpd  0xc0(%rsp),%xmm3
   20aea:	00 00 
   20aec:	66 0f 54 4c 24 30    	andpd  0x30(%rsp),%xmm1
   20af2:	66 0f 28 44 24 10    	movapd 0x10(%rsp),%xmm0
   20af8:	66 0f 54 44 24 20    	andpd  0x20(%rsp),%xmm0
   20afe:	66 0f 54 d1          	andpd  %xmm1,%xmm2
   20b02:	66 0f 55 4c 24 70    	andnpd 0x70(%rsp),%xmm1
   20b08:	66 0f 56 ca          	orpd   %xmm2,%xmm1
   20b0c:	66 0f 29 4c 24 70    	movapd %xmm1,0x70(%rsp)
   20b12:	66 0f 54 d8          	andpd  %xmm0,%xmm3
   20b16:	66 0f 55 84 24 80 01 	andnpd 0x180(%rsp),%xmm0
   20b1d:	00 00 
   20b1f:	66 0f 28 c8          	movapd %xmm0,%xmm1
   20b23:	66 0f 56 cb          	orpd   %xmm3,%xmm1
   20b27:	48 83 fa 03          	cmp    $0x3,%rdx
   20b2b:	0f 84 3f 09 00 00    	je     21470 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::entry::<fearless_simd::generated::sse2::Sse2, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::sse2::Sse2>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>, usize, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::sse2::Sse2>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2]>+0xcb0>
   20b31:	66 0f 29 8c 24 80 01 	movapd %xmm1,0x180(%rsp)
   20b38:	00 00 
   20b3a:	66 44 0f 29 84 24 d0 	movapd %xmm8,0x2d0(%rsp)
   20b41:	02 00 00 
   20b44:	66 0f 29 ac 24 e0 02 	movapd %xmm5,0x2e0(%rsp)
   20b4b:	00 00 
   20b4d:	48 89 d1             	mov    %rdx,%rcx
   20b50:	48 c1 e1 05          	shl    $0x5,%rcx
   20b54:	66 0f 28 0c 08       	movapd (%rax,%rcx,1),%xmm1
   20b59:	66 0f 28 54 08 10    	movapd 0x10(%rax,%rcx,1),%xmm2
   20b5f:	66 0f 28 e1          	movapd %xmm1,%xmm4
   20b63:	66 0f c2 a4 24 50 01 	cmpltpd 0x150(%rsp),%xmm4
   20b6a:	00 00 01 
   20b6d:	66 0f 28 da          	movapd %xmm2,%xmm3
   20b71:	66 0f c2 9c 24 40 01 	cmpltpd 0x140(%rsp),%xmm3
   20b78:	00 00 01 
   20b7b:	66 0f 28 c4          	movapd %xmm4,%xmm0
   20b7f:	66 0f 29 8c 24 80 00 	movapd %xmm1,0x80(%rsp)
   20b86:	00 00 
   20b88:	66 0f 54 c1          	andpd  %xmm1,%xmm0
   20b8c:	66 0f 29 a4 24 c0 02 	movapd %xmm4,0x2c0(%rsp)
   20b93:	00 00 
   20b95:	66 0f 28 0d 63 49 fe 	movapd -0x1b69d(%rip),%xmm1        # 5500 <std::thread::current::id::ID+0x4888>
   20b9c:	ff 
   20b9d:	66 0f 55 e1          	andnpd %xmm1,%xmm4
   20ba1:	66 0f 56 e0          	orpd   %xmm0,%xmm4
   20ba5:	66 0f 28 c3          	movapd %xmm3,%xmm0
   20ba9:	66 0f 29 94 24 90 00 	movapd %xmm2,0x90(%rsp)
   20bb0:	00 00 
   20bb2:	66 0f 54 c2          	andpd  %xmm2,%xmm0
   20bb6:	66 0f 29 5c 24 10    	movapd %xmm3,0x10(%rsp)
   20bbc:	66 0f 28 d3          	movapd %xmm3,%xmm2
   20bc0:	66 0f 55 d1          	andnpd %xmm1,%xmm2
   20bc4:	66 0f 56 d0          	orpd   %xmm0,%xmm2
   20bc8:	66 0f 28 c4          	movapd %xmm4,%xmm0
   20bcc:	66 0f 28 1d 2c 49 fe 	movapd -0x1b6d4(%rip),%xmm3        # 5500 <std::thread::current::id::ID+0x4888>
   20bd3:	ff 
   20bd4:	66 0f c2 c3 01       	cmpltpd %xmm3,%xmm0
   20bd9:	66 0f 28 ca          	movapd %xmm2,%xmm1
   20bdd:	66 0f c2 cb 01       	cmpltpd %xmm3,%xmm1
   20be2:	66 0f 29 44 24 40    	movapd %xmm0,0x40(%rsp)
   20be8:	66 0f 54 e0          	andpd  %xmm0,%xmm4
   20bec:	66 0f 29 8c 24 a0 00 	movapd %xmm1,0xa0(%rsp)
   20bf3:	00 00 
   20bf5:	66 0f 54 d1          	andpd  %xmm1,%xmm2
   20bf9:	66 0f 29 64 24 30    	movapd %xmm4,0x30(%rsp)
   20bff:	66 0f 28 ec          	movapd %xmm4,%xmm5
   20c03:	66 0f 28 05 f5 44 fe 	movapd -0x1bb0b(%rip),%xmm0        # 5100 <std::thread::current::id::ID+0x4488>
   20c0a:	ff 
   20c0b:	66 0f 54 e8          	andpd  %xmm0,%xmm5
   20c0f:	66 0f 29 54 24 20    	movapd %xmm2,0x20(%rsp)
   20c15:	66 44 0f 28 c2       	movapd %xmm2,%xmm8
   20c1a:	66 44 0f 54 c0       	andpd  %xmm0,%xmm8
   20c1f:	66 0f 28 05 59 48 fe 	movapd -0x1b7a7(%rip),%xmm0        # 5480 <std::thread::current::id::ID+0x4808>
   20c26:	ff 
   20c27:	66 0f 58 e8          	addpd  %xmm0,%xmm5
   20c2b:	66 44 0f 58 c0       	addpd  %xmm0,%xmm8
   20c30:	66 0f 28 05 08 47 fe 	movapd -0x1b8f8(%rip),%xmm0        # 5340 <std::thread::current::id::ID+0x46c8>
   20c37:	ff 
   20c38:	66 0f 59 e8          	mulpd  %xmm0,%xmm5
   20c3c:	66 44 0f 59 c0       	mulpd  %xmm0,%xmm8
   20c41:	b9 1f 00 00 00       	mov    $0x1f,%ecx
   20c46:	66 44 0f 28 db       	movapd %xmm3,%xmm11
   20c4b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   20c50:	66 44 0f 29 84 24 c0 	movapd %xmm8,0xc0(%rsp)
   20c57:	00 00 00 
   20c5a:	66 0f 29 ac 24 d0 00 	movapd %xmm5,0xd0(%rsp)
   20c61:	00 00 
   20c63:	66 0f 28 4c 24 30    	movapd 0x30(%rsp),%xmm1
   20c69:	66 0f 28 d1          	movapd %xmm1,%xmm2
   20c6d:	66 0f 5c d5          	subpd  %xmm5,%xmm2
   20c71:	66 0f 28 64 24 20    	movapd 0x20(%rsp),%xmm4
   20c77:	66 0f 28 ec          	movapd %xmm4,%xmm5
   20c7b:	66 41 0f 5c e8       	subpd  %xmm8,%xmm5
   20c80:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
   20c84:	66 0f 5f d0          	maxpd  %xmm0,%xmm2
   20c88:	66 0f 5f e8          	maxpd  %xmm0,%xmm5
   20c8c:	66 0f 28 84 24 d0 00 	movapd 0xd0(%rsp),%xmm0
   20c93:	00 00 
   20c95:	66 0f 58 c1          	addpd  %xmm1,%xmm0
   20c99:	66 44 0f 28 84 24 c0 	movapd 0xc0(%rsp),%xmm8
   20ca0:	00 00 00 
   20ca3:	66 44 0f 58 c4       	addpd  %xmm4,%xmm8
   20ca8:	66 44 0f 28 a4 24 10 	movapd 0x210(%rsp),%xmm12
   20caf:	02 00 00 
   20cb2:	66 45 0f 28 fc       	movapd %xmm12,%xmm15
   20cb7:	66 44 0f 59 fa       	mulpd  %xmm2,%xmm15
   20cbc:	66 0f 28 8c 24 00 02 	movapd 0x200(%rsp),%xmm1
   20cc3:	00 00 
   20cc5:	66 0f 28 f9          	movapd %xmm1,%xmm7
   20cc9:	66 0f 59 fd          	mulpd  %xmm5,%xmm7
   20ccd:	66 44 0f 58 bc 24 20 	addpd  0x120(%rsp),%xmm15
   20cd4:	01 00 00 
   20cd7:	66 44 0f 28 ac 24 f0 	movapd 0x1f0(%rsp),%xmm13
   20cde:	01 00 00 
   20ce1:	66 41 0f 58 fd       	addpd  %xmm13,%xmm7
   20ce6:	66 44 0f 59 fa       	mulpd  %xmm2,%xmm15
   20ceb:	66 0f 59 fd          	mulpd  %xmm5,%xmm7
   20cef:	66 0f 28 b4 24 30 02 	movapd 0x230(%rsp),%xmm6
   20cf6:	00 00 
   20cf8:	66 44 0f 58 fe       	addpd  %xmm6,%xmm15
   20cfd:	66 44 0f 28 b4 24 e0 	movapd 0xe0(%rsp),%xmm14
   20d04:	00 00 00 
   20d07:	66 41 0f 58 fe       	addpd  %xmm14,%xmm7
   20d0c:	66 0f 28 a4 24 10 01 	movapd 0x110(%rsp),%xmm4
   20d13:	00 00 
   20d15:	66 0f 59 e2          	mulpd  %xmm2,%xmm4
   20d19:	66 44 0f 28 8c 24 30 	movapd 0x130(%rsp),%xmm9
   20d20:	01 00 00 
   20d23:	66 44 0f 59 cd       	mulpd  %xmm5,%xmm9
   20d28:	66 0f 58 a4 24 00 01 	addpd  0x100(%rsp),%xmm4
   20d2f:	00 00 
   20d31:	66 44 0f 58 8c 24 f0 	addpd  0xf0(%rsp),%xmm9
   20d38:	00 00 00 
   20d3b:	66 0f 59 e2          	mulpd  %xmm2,%xmm4
   20d3f:	66 44 0f 59 cd       	mulpd  %xmm5,%xmm9
   20d44:	66 44 0f 28 94 24 20 	movapd 0x220(%rsp),%xmm10
   20d4b:	02 00 00 
   20d4e:	66 41 0f 58 e2       	addpd  %xmm10,%xmm4
   20d53:	66 44 0f 58 8c 24 b0 	addpd  0xb0(%rsp),%xmm9
   20d5a:	00 00 00 
   20d5d:	66 0f 28 15 db 45 fe 	movapd -0x1ba25(%rip),%xmm2        # 5340 <std::thread::current::id::ID+0x46c8>
   20d64:	ff 
   20d65:	66 0f 59 e2          	mulpd  %xmm2,%xmm4
   20d69:	66 44 0f 59 ca       	mulpd  %xmm2,%xmm9
   20d6e:	66 44 0f 59 e0       	mulpd  %xmm0,%xmm12
   20d73:	66 0f 28 e9          	movapd %xmm1,%xmm5
   20d77:	66 41 0f 59 e8       	mulpd  %xmm8,%xmm5
   20d7c:	66 44 0f 58 a4 24 20 	addpd  0x120(%rsp),%xmm12
   20d83:	01 00 00 
   20d86:	66 41 0f 58 ed       	addpd  %xmm13,%xmm5
   20d8b:	66 44 0f 59 e0       	mulpd  %xmm0,%xmm12
   20d90:	66 41 0f 59 e8       	mulpd  %xmm8,%xmm5
   20d95:	66 44 0f 58 e6       	addpd  %xmm6,%xmm12
   20d9a:	66 41 0f 58 ee       	addpd  %xmm14,%xmm5
   20d9f:	66 0f 28 94 24 10 01 	movapd 0x110(%rsp),%xmm2
   20da6:	00 00 
   20da8:	66 0f 59 d0          	mulpd  %xmm0,%xmm2
   20dac:	66 0f 58 94 24 00 01 	addpd  0x100(%rsp),%xmm2
   20db3:	00 00 
   20db5:	66 0f 59 d0          	mulpd  %xmm0,%xmm2
   20db9:	66 0f 28 84 24 30 01 	movapd 0x130(%rsp),%xmm0
   20dc0:	00 00 
   20dc2:	66 41 0f 59 c0       	mulpd  %xmm8,%xmm0
   20dc7:	66 0f 58 84 24 f0 00 	addpd  0xf0(%rsp),%xmm0
   20dce:	00 00 
   20dd0:	66 41 0f 59 c0       	mulpd  %xmm8,%xmm0
   20dd5:	66 41 0f 58 d2       	addpd  %xmm10,%xmm2
   20dda:	66 0f 58 84 24 b0 00 	addpd  0xb0(%rsp),%xmm0
   20de1:	00 00 
   20de3:	66 0f 28 0d 55 45 fe 	movapd -0x1baab(%rip),%xmm1        # 5340 <std::thread::current::id::ID+0x46c8>
   20dea:	ff 
   20deb:	66 0f 59 d1          	mulpd  %xmm1,%xmm2
   20def:	66 0f 59 c1          	mulpd  %xmm1,%xmm0
   20df3:	66 44 0f 28 c4       	movapd %xmm4,%xmm8
   20df8:	66 0f 28 0d 40 47 fe 	movapd -0x1b8c0(%rip),%xmm1        # 5540 <std::thread::current::id::ID+0x48c8>
   20dff:	ff 
   20e00:	66 44 0f 57 c1       	xorpd  %xmm1,%xmm8
   20e05:	66 41 0f c2 e7 01    	cmpltpd %xmm15,%xmm4
   20e0b:	66 45 0f c2 f8 01    	cmpltpd %xmm8,%xmm15
   20e11:	66 45 0f 28 c1       	movapd %xmm9,%xmm8
   20e16:	66 44 0f 57 c1       	xorpd  %xmm1,%xmm8
   20e1b:	66 44 0f c2 cf 01    	cmpltpd %xmm7,%xmm9
   20e21:	66 41 0f c2 f8 01    	cmpltpd %xmm8,%xmm7
   20e27:	66 44 0f 28 c2       	movapd %xmm2,%xmm8
   20e2c:	66 45 0f c2 c4 01    	cmpltpd %xmm12,%xmm8
   20e32:	66 45 0f 54 c7       	andpd  %xmm15,%xmm8
   20e37:	66 44 0f 28 f8       	movapd %xmm0,%xmm15
   20e3c:	66 44 0f c2 fd 01    	cmpltpd %xmm5,%xmm15
   20e42:	66 44 0f 54 ff       	andpd  %xmm7,%xmm15
   20e47:	66 0f 57 d1          	xorpd  %xmm1,%xmm2
   20e4b:	66 44 0f c2 e2 01    	cmpltpd %xmm2,%xmm12
   20e51:	66 44 0f 54 e4       	andpd  %xmm4,%xmm12
   20e56:	66 45 0f 56 e0       	orpd   %xmm8,%xmm12
   20e5b:	66 44 0f 28 84 24 c0 	movapd 0xc0(%rsp),%xmm8
   20e62:	00 00 00 
   20e65:	66 0f 57 c1          	xorpd  %xmm1,%xmm0
   20e69:	66 0f c2 e8 01       	cmpltpd %xmm0,%xmm5
   20e6e:	66 41 0f 54 e9       	andpd  %xmm9,%xmm5
   20e73:	66 41 0f 56 ef       	orpd   %xmm15,%xmm5
   20e78:	66 0f 28 c3          	movapd %xmm3,%xmm0
   20e7c:	66 0f 28 35 7c 46 fe 	movapd -0x1b984(%rip),%xmm6        # 5500 <std::thread::current::id::ID+0x4888>
   20e83:	ff 
   20e84:	66 0f c2 c6 00       	cmpeqpd %xmm6,%xmm0
   20e89:	66 0f 28 4c 24 40    	movapd 0x40(%rsp),%xmm1
   20e8f:	66 0f 54 c1          	andpd  %xmm1,%xmm0
   20e93:	66 41 0f 54 c4       	andpd  %xmm12,%xmm0
   20e98:	66 41 0f 28 d3       	movapd %xmm11,%xmm2
   20e9d:	66 0f c2 d6 00       	cmpeqpd %xmm6,%xmm2
   20ea2:	66 0f 28 bc 24 a0 00 	movapd 0xa0(%rsp),%xmm7
   20ea9:	00 00 
   20eab:	66 0f 54 d7          	andpd  %xmm7,%xmm2
   20eaf:	66 0f 54 d5          	andpd  %xmm5,%xmm2
   20eb3:	66 0f 28 ac 24 d0 00 	movapd 0xd0(%rsp),%xmm5
   20eba:	00 00 
   20ebc:	66 0f 28 e0          	movapd %xmm0,%xmm4
   20ec0:	66 0f 55 c3          	andnpd %xmm3,%xmm0
   20ec4:	66 0f 58 ed          	addpd  %xmm5,%xmm5
   20ec8:	66 0f 54 e5          	andpd  %xmm5,%xmm4
   20ecc:	66 0f 28 d8          	movapd %xmm0,%xmm3
   20ed0:	66 0f 56 dc          	orpd   %xmm4,%xmm3
   20ed4:	66 0f 28 c2          	movapd %xmm2,%xmm0
   20ed8:	66 41 0f 55 d3       	andnpd %xmm11,%xmm2
   20edd:	66 45 0f 58 c0       	addpd  %xmm8,%xmm8
   20ee2:	66 41 0f 54 c0       	andpd  %xmm8,%xmm0
   20ee7:	66 44 0f 28 da       	movapd %xmm2,%xmm11
   20eec:	66 44 0f 56 d8       	orpd   %xmm0,%xmm11
   20ef1:	66 0f 28 c3          	movapd %xmm3,%xmm0
   20ef5:	66 0f c2 c6 00       	cmpeqpd %xmm6,%xmm0
   20efa:	66 0f 54 c1          	andpd  %xmm1,%xmm0
   20efe:	66 44 0f 50 c8       	movmskpd %xmm0,%r9d
   20f03:	66 41 0f 28 c3       	movapd %xmm11,%xmm0
   20f08:	f2 0f c2 c6 00       	cmpeqsd %xmm6,%xmm0
   20f0d:	66 0f 54 c7          	andpd  %xmm7,%xmm0
   20f11:	66 44 0f 50 d0       	movmskpd %xmm0,%r10d
   20f16:	41 c1 e2 02          	shl    $0x2,%r10d
   20f1a:	41 83 e2 04          	and    $0x4,%r10d
   20f1e:	83 e9 01             	sub    $0x1,%ecx
   20f21:	40 0f 92 c6          	setb   %sil
   20f25:	45 09 ca             	or     %r9d,%r10d
   20f28:	74 09                	je     20f33 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::entry::<fearless_simd::generated::sse2::Sse2, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::sse2::Sse2>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>, usize, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::sse2::Sse2>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2]>+0x773>
   20f2a:	40 84 f6             	test   %sil,%sil
   20f2d:	0f 84 1d fd ff ff    	je     20c50 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::entry::<fearless_simd::generated::sse2::Sse2, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::sse2::Sse2>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>, usize, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::sse2::Sse2>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2]>+0x490>
   20f33:	66 0f 28 bc 24 80 00 	movapd 0x80(%rsp),%xmm7
   20f3a:	00 00 
   20f3c:	66 0f 5d bc 24 50 01 	minpd  0x150(%rsp),%xmm7
   20f43:	00 00 
   20f45:	66 0f 28 ac 24 90 00 	movapd 0x90(%rsp),%xmm5
   20f4c:	00 00 
   20f4e:	66 0f 5d ac 24 40 01 	minpd  0x140(%rsp),%xmm5
   20f55:	00 00 
   20f57:	66 0f 28 64 24 40    	movapd 0x40(%rsp),%xmm4
   20f5d:	66 0f 54 a4 24 c0 02 	andpd  0x2c0(%rsp),%xmm4
   20f64:	00 00 
   20f66:	66 0f 54 e3          	andpd  %xmm3,%xmm4
   20f6a:	66 44 0f 28 b4 24 a0 	movapd 0xa0(%rsp),%xmm14
   20f71:	00 00 00 
   20f74:	66 44 0f 54 74 24 10 	andpd  0x10(%rsp),%xmm14
   20f7b:	66 45 0f 54 f3       	andpd  %xmm11,%xmm14
   20f80:	66 0f 28 cc          	movapd %xmm4,%xmm1
   20f84:	66 0f 28 05 74 45 fe 	movapd -0x1ba8c(%rip),%xmm0        # 5500 <std::thread::current::id::ID+0x4888>
   20f8b:	ff 
   20f8c:	66 0f c2 c8 01       	cmpltpd %xmm0,%xmm1
   20f91:	66 41 0f 28 d6       	movapd %xmm14,%xmm2
   20f96:	66 0f c2 d0 01       	cmpltpd %xmm0,%xmm2
   20f9b:	66 0f 54 e1          	andpd  %xmm1,%xmm4
   20f9f:	66 0f 29 64 24 40    	movapd %xmm4,0x40(%rsp)
   20fa5:	66 0f 29 8c 24 d0 00 	movapd %xmm1,0xd0(%rsp)
   20fac:	00 00 
   20fae:	66 0f 76 c0          	pcmpeqd %xmm0,%xmm0
   20fb2:	66 0f 57 c8          	xorpd  %xmm0,%xmm1
   20fb6:	66 0f 29 4c 24 20    	movapd %xmm1,0x20(%rsp)
   20fbc:	66 44 0f 54 f2       	andpd  %xmm2,%xmm14
   20fc1:	66 0f 29 94 24 c0 00 	movapd %xmm2,0xc0(%rsp)
   20fc8:	00 00 
   20fca:	66 0f 57 d0          	xorpd  %xmm0,%xmm2
   20fce:	66 0f 29 54 24 30    	movapd %xmm2,0x30(%rsp)
   20fd4:	66 44 0f 28 8c 24 e0 	movapd 0x1e0(%rsp),%xmm9
   20fdb:	01 00 00 
   20fde:	66 41 0f 28 c9       	movapd %xmm9,%xmm1
   20fe3:	66 0f 59 cf          	mulpd  %xmm7,%xmm1
   20fe7:	66 44 0f 28 84 24 d0 	movapd 0x1d0(%rsp),%xmm8
   20fee:	01 00 00 
   20ff1:	66 44 0f 59 c5       	mulpd  %xmm5,%xmm8
   20ff6:	66 44 0f 28 bc 24 c0 	movapd 0x1c0(%rsp),%xmm15
   20ffd:	01 00 00 
   21000:	66 41 0f 58 cf       	addpd  %xmm15,%xmm1
   21005:	66 44 0f 58 84 24 b0 	addpd  0x1b0(%rsp),%xmm8
   2100c:	01 00 00 
   2100f:	66 0f 59 cf          	mulpd  %xmm7,%xmm1
   21013:	66 44 0f 59 c5       	mulpd  %xmm5,%xmm8
   21018:	66 44 0f 28 ac 24 30 	movapd 0x230(%rsp),%xmm13
   2101f:	02 00 00 
   21022:	66 41 0f 58 cd       	addpd  %xmm13,%xmm1
   21027:	66 0f 28 94 24 e0 00 	movapd 0xe0(%rsp),%xmm2
   2102e:	00 00 
   21030:	66 44 0f 58 c2       	addpd  %xmm2,%xmm8
   21035:	66 0f 59 cf          	mulpd  %xmm7,%xmm1
   21039:	66 44 0f 59 c5       	mulpd  %xmm5,%xmm8
   2103e:	66 0f 28 f5          	movapd %xmm5,%xmm6
   21042:	66 0f 29 ac 24 90 00 	movapd %xmm5,0x90(%rsp)
   21049:	00 00 
   2104b:	66 0f 58 8c 24 a0 01 	addpd  0x1a0(%rsp),%xmm1
   21052:	00 00 
   21054:	66 0f 29 4c 24 10    	movapd %xmm1,0x10(%rsp)
   2105a:	66 44 0f 58 84 24 90 	addpd  0x190(%rsp),%xmm8
   21061:	01 00 00 
   21064:	66 0f 28 8c 24 10 02 	movapd 0x210(%rsp),%xmm1
   2106b:	00 00 
   2106d:	66 0f 59 cf          	mulpd  %xmm7,%xmm1
   21071:	66 0f 28 84 24 00 02 	movapd 0x200(%rsp),%xmm0
   21078:	00 00 
   2107a:	66 0f 59 c5          	mulpd  %xmm5,%xmm0
   2107e:	66 0f 58 8c 24 20 01 	addpd  0x120(%rsp),%xmm1
   21085:	00 00 
   21087:	66 0f 58 84 24 f0 01 	addpd  0x1f0(%rsp),%xmm0
   2108e:	00 00 
   21090:	66 0f 59 cf          	mulpd  %xmm7,%xmm1
   21094:	66 0f 59 c5          	mulpd  %xmm5,%xmm0
   21098:	66 41 0f 58 cd       	addpd  %xmm13,%xmm1
   2109d:	66 0f 58 c2          	addpd  %xmm2,%xmm0
   210a1:	66 0f 28 ac 24 10 01 	movapd 0x110(%rsp),%xmm5
   210a8:	00 00 
   210aa:	66 0f 59 ef          	mulpd  %xmm7,%xmm5
   210ae:	66 0f 28 a4 24 30 01 	movapd 0x130(%rsp),%xmm4
   210b5:	00 00 
   210b7:	66 0f 59 e6          	mulpd  %xmm6,%xmm4
   210bb:	66 0f 28 94 24 00 01 	movapd 0x100(%rsp),%xmm2
   210c2:	00 00 
   210c4:	66 0f 58 d5          	addpd  %xmm5,%xmm2
   210c8:	66 0f 59 d7          	mulpd  %xmm7,%xmm2
   210cc:	66 44 0f 28 94 24 20 	movapd 0x220(%rsp),%xmm10
   210d3:	02 00 00 
   210d6:	66 41 0f 58 d2       	addpd  %xmm10,%xmm2
   210db:	66 0f 28 1d 5d 42 fe 	movapd -0x1bda3(%rip),%xmm3        # 5340 <std::thread::current::id::ID+0x46c8>
   210e2:	ff 
   210e3:	66 0f 59 d3          	mulpd  %xmm3,%xmm2
   210e7:	66 44 0f 28 1d 10 40 	movapd -0x1bff0(%rip),%xmm11        # 5100 <std::thread::current::id::ID+0x4488>
   210ee:	fe ff 
   210f0:	66 41 0f 54 cb       	andpd  %xmm11,%xmm1
   210f5:	66 0f 58 ca          	addpd  %xmm2,%xmm1
   210f9:	66 0f 28 94 24 f0 00 	movapd 0xf0(%rsp),%xmm2
   21100:	00 00 
   21102:	66 0f 58 d4          	addpd  %xmm4,%xmm2
   21106:	66 0f 28 b4 24 90 00 	movapd 0x90(%rsp),%xmm6
   2110d:	00 00 
   2110f:	66 0f 59 d6          	mulpd  %xmm6,%xmm2
   21113:	66 0f 58 94 24 b0 00 	addpd  0xb0(%rsp),%xmm2
   2111a:	00 00 
   2111c:	66 0f 59 d3          	mulpd  %xmm3,%xmm2
   21120:	66 41 0f 54 c3       	andpd  %xmm11,%xmm0
   21125:	66 0f 58 c2          	addpd  %xmm2,%xmm0
   21129:	66 0f 28 94 24 70 01 	movapd 0x170(%rsp),%xmm2
   21130:	00 00 
   21132:	66 0f 29 bc 24 80 00 	movapd %xmm7,0x80(%rsp)
   21139:	00 00 
   2113b:	66 0f 59 d7          	mulpd  %xmm7,%xmm2
   2113f:	66 0f 58 94 24 60 01 	addpd  0x160(%rsp),%xmm2
   21146:	00 00 
   21148:	66 0f 59 d7          	mulpd  %xmm7,%xmm2
   2114c:	66 41 0f 58 d2       	addpd  %xmm10,%xmm2
   21151:	66 0f 59 d7          	mulpd  %xmm7,%xmm2
   21155:	66 0f 58 94 24 90 02 	addpd  0x290(%rsp),%xmm2
   2115c:	00 00 
   2115e:	66 0f 59 d3          	mulpd  %xmm3,%xmm2
   21162:	66 44 0f 28 5c 24 40 	movapd 0x40(%rsp),%xmm11
   21169:	66 41 0f 59 cb       	mulpd  %xmm11,%xmm1
   2116e:	66 0f 58 ca          	addpd  %xmm2,%xmm1
   21172:	66 0f 28 9c 24 b0 02 	movapd 0x2b0(%rsp),%xmm3
   21179:	00 00 
   2117b:	66 0f 28 d3          	movapd %xmm3,%xmm2
   2117f:	66 0f 59 d6          	mulpd  %xmm6,%xmm2
   21183:	66 44 0f 28 94 24 a0 	movapd 0x2a0(%rsp),%xmm10
   2118a:	02 00 00 
   2118d:	66 41 0f 58 d2       	addpd  %xmm10,%xmm2
   21192:	66 0f 59 d6          	mulpd  %xmm6,%xmm2
   21196:	66 0f 58 94 24 b0 00 	addpd  0xb0(%rsp),%xmm2
   2119d:	00 00 
   2119f:	66 0f 59 d6          	mulpd  %xmm6,%xmm2
   211a3:	66 0f 28 fe          	movapd %xmm6,%xmm7
   211a7:	66 0f 58 94 24 80 02 	addpd  0x280(%rsp),%xmm2
   211ae:	00 00 
   211b0:	66 0f 59 15 88 41 fe 	mulpd  -0x1be78(%rip),%xmm2        # 5340 <std::thread::current::id::ID+0x46c8>
   211b7:	ff 
   211b8:	66 41 0f 59 c6       	mulpd  %xmm14,%xmm0
   211bd:	66 0f 58 c2          	addpd  %xmm2,%xmm0
   211c1:	66 0f 58 ac 24 60 01 	addpd  0x160(%rsp),%xmm5
   211c8:	00 00 
   211ca:	66 41 0f 58 e2       	addpd  %xmm10,%xmm4
   211cf:	66 44 0f 28 94 24 e0 	movapd 0xe0(%rsp),%xmm10
   211d6:	00 00 00 
   211d9:	66 0f 28 94 24 70 01 	movapd 0x170(%rsp),%xmm2
   211e0:	00 00 
   211e2:	66 41 0f 59 d3       	mulpd  %xmm11,%xmm2
   211e7:	66 0f 58 d5          	addpd  %xmm5,%xmm2
   211eb:	66 0f 28 eb          	movapd %xmm3,%xmm5
   211ef:	66 41 0f 59 ee       	mulpd  %xmm14,%xmm5
   211f4:	66 0f 58 ec          	addpd  %xmm4,%xmm5
   211f8:	66 41 0f 59 d3       	mulpd  %xmm11,%xmm2
   211fd:	66 41 0f 59 ee       	mulpd  %xmm14,%xmm5
   21202:	66 41 0f 59 d3       	mulpd  %xmm11,%xmm2
   21207:	66 0f 58 d1          	addpd  %xmm1,%xmm2
   2120b:	66 44 0f 29 b4 24 a0 	movapd %xmm14,0xa0(%rsp)
   21212:	00 00 00 
   21215:	66 41 0f 59 ee       	mulpd  %xmm14,%xmm5
   2121a:	66 0f 58 e8          	addpd  %xmm0,%xmm5
   2121e:	66 0f 28 5c 24 10    	movapd 0x10(%rsp),%xmm3
   21224:	66 44 0f 28 db       	movapd %xmm3,%xmm11
   21229:	66 0f 28 05 cf 3e fe 	movapd -0x1c131(%rip),%xmm0        # 5100 <std::thread::current::id::ID+0x4488>
   21230:	ff 
   21231:	66 44 0f 54 d8       	andpd  %xmm0,%xmm11
   21236:	66 45 0f 28 f0       	movapd %xmm8,%xmm14
   2123b:	66 44 0f 54 f0       	andpd  %xmm0,%xmm14
   21240:	66 44 0f c2 da 02    	cmplepd %xmm2,%xmm11
   21246:	66 44 0f 56 5c 24 20 	orpd   0x20(%rsp),%xmm11
   2124d:	66 44 0f c2 f5 02    	cmplepd %xmm5,%xmm14
   21253:	66 44 0f 56 74 24 30 	orpd   0x30(%rsp),%xmm14
   2125a:	66 0f 28 64 24 50    	movapd 0x50(%rsp),%xmm4
   21260:	66 0f 28 05 98 42 fe 	movapd -0x1bd68(%rip),%xmm0        # 5500 <std::thread::current::id::ID+0x4888>
   21267:	ff 
   21268:	66 0f c2 e0 00       	cmpeqpd %xmm0,%xmm4
   2126d:	66 0f 28 74 24 60    	movapd 0x60(%rsp),%xmm6
   21273:	66 0f c2 f0 00       	cmpeqpd %xmm0,%xmm6
   21278:	66 0f 28 4c 24 70    	movapd 0x70(%rsp),%xmm1
   2127e:	66 0f c2 c8 00       	cmpeqpd %xmm0,%xmm1
   21283:	66 0f 54 cc          	andpd  %xmm4,%xmm1
   21287:	66 0f 28 a4 24 80 01 	movapd 0x180(%rsp),%xmm4
   2128e:	00 00 
   21290:	66 0f c2 e0 00       	cmpeqpd %xmm0,%xmm4
   21295:	66 0f 54 e6          	andpd  %xmm6,%xmm4
   21299:	66 0f c2 d3 01       	cmpltpd %xmm3,%xmm2
   2129e:	66 41 0f c2 e8 01    	cmpltpd %xmm8,%xmm5
   212a4:	66 44 0f 29 5c 24 30 	movapd %xmm11,0x30(%rsp)
   212ab:	66 41 0f 28 db       	movapd %xmm11,%xmm3
   212b0:	66 0f 55 da          	andnpd %xmm2,%xmm3
   212b4:	66 0f 54 d9          	andpd  %xmm1,%xmm3
   212b8:	66 44 0f 29 74 24 20 	movapd %xmm14,0x20(%rsp)
   212bf:	66 45 0f 28 c6       	movapd %xmm14,%xmm8
   212c4:	66 44 0f 55 c5       	andnpd %xmm5,%xmm8
   212c9:	66 0f 29 64 24 10    	movapd %xmm4,0x10(%rsp)
   212cf:	66 44 0f 54 c4       	andpd  %xmm4,%xmm8
   212d4:	66 0f 50 cb          	movmskpd %xmm3,%ecx
   212d8:	66 41 0f 50 f0       	movmskpd %xmm8,%esi
   212dd:	c1 e6 02             	shl    $0x2,%esi
   212e0:	83 e6 04             	and    $0x4,%esi
   212e3:	09 ce                	or     %ecx,%esi
   212e5:	4c 89 c1             	mov    %r8,%rcx
   212e8:	66 0f 28 ef          	movapd %xmm7,%xmm5
   212ec:	66 0f 28 94 24 80 00 	movapd 0x80(%rsp),%xmm2
   212f3:	00 00 
   212f5:	66 44 0f 28 1d f2 3e 	movapd -0x1c10e(%rip),%xmm11        # 51f0 <std::thread::current::id::ID+0x4578>
   212fc:	fe ff 
   212fe:	66 44 0f 28 b4 24 e0 	movapd 0x2e0(%rsp),%xmm14
   21305:	02 00 00 
   21308:	66 0f 28 84 24 d0 02 	movapd 0x2d0(%rsp),%xmm0
   2130f:	00 00 
   21311:	0f 84 89 f7 ff ff    	je     20aa0 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::entry::<fearless_simd::generated::sse2::Sse2, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::sse2::Sse2>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>, usize, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::sse2::Sse2>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2]>+0x2e0>
   21317:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   2131e:	00 00 
   21320:	66 0f 28 fa          	movapd %xmm2,%xmm7
   21324:	66 0f 5c f8          	subpd  %xmm0,%xmm7
   21328:	66 0f 28 e5          	movapd %xmm5,%xmm4
   2132c:	66 41 0f 5c e6       	subpd  %xmm14,%xmm4
   21331:	66 41 0f 59 fb       	mulpd  %xmm11,%xmm7
   21336:	66 41 0f 59 e3       	mulpd  %xmm11,%xmm4
   2133b:	66 0f 58 f8          	addpd  %xmm0,%xmm7
   2133f:	66 41 0f 58 e6       	addpd  %xmm14,%xmm4
   21344:	66 41 0f 28 f1       	movapd %xmm9,%xmm6
   21349:	66 0f 59 f7          	mulpd  %xmm7,%xmm6
   2134d:	66 44 0f 28 a4 24 d0 	movapd 0x1d0(%rsp),%xmm12
   21354:	01 00 00 
   21357:	66 44 0f 59 e4       	mulpd  %xmm4,%xmm12
   2135c:	66 41 0f 58 f7       	addpd  %xmm15,%xmm6
   21361:	66 44 0f 58 a4 24 b0 	addpd  0x1b0(%rsp),%xmm12
   21368:	01 00 00 
   2136b:	66 0f 59 f7          	mulpd  %xmm7,%xmm6
   2136f:	66 44 0f 59 e4       	mulpd  %xmm4,%xmm12
   21374:	66 41 0f 58 f5       	addpd  %xmm13,%xmm6
   21379:	66 45 0f 58 e2       	addpd  %xmm10,%xmm12
   2137e:	66 0f 59 f7          	mulpd  %xmm7,%xmm6
   21382:	66 44 0f 59 e4       	mulpd  %xmm4,%xmm12
   21387:	66 0f 58 b4 24 a0 01 	addpd  0x1a0(%rsp),%xmm6
   2138e:	00 00 
   21390:	66 44 0f 58 a4 24 90 	addpd  0x190(%rsp),%xmm12
   21397:	01 00 00 
   2139a:	66 45 0f 57 ff       	xorpd  %xmm15,%xmm15
   2139f:	66 44 0f c2 fe 01    	cmpltpd %xmm6,%xmm15
   213a5:	66 45 0f 57 c9       	xorpd  %xmm9,%xmm9
   213aa:	66 45 0f c2 cc 01    	cmpltpd %xmm12,%xmm9
   213b0:	66 0f 28 f3          	movapd %xmm3,%xmm6
   213b4:	66 41 0f 54 f7       	andpd  %xmm15,%xmm6
   213b9:	66 44 0f 28 e6       	movapd %xmm6,%xmm12
   213be:	66 0f 55 f2          	andnpd %xmm2,%xmm6
   213c2:	66 41 0f 28 d0       	movapd %xmm8,%xmm2
   213c7:	66 41 0f 54 d1       	andpd  %xmm9,%xmm2
   213cc:	66 44 0f 54 e7       	andpd  %xmm7,%xmm12
   213d1:	66 41 0f 56 f4       	orpd   %xmm12,%xmm6
   213d6:	66 44 0f 28 e2       	movapd %xmm2,%xmm12
   213db:	66 0f 55 d5          	andnpd %xmm5,%xmm2
   213df:	66 44 0f 54 e4       	andpd  %xmm4,%xmm12
   213e4:	66 41 0f 56 d4       	orpd   %xmm12,%xmm2
   213e9:	66 44 0f 55 fb       	andnpd %xmm3,%xmm15
   213ee:	66 41 0f 54 ff       	andpd  %xmm15,%xmm7
   213f3:	66 44 0f 55 f8       	andnpd %xmm0,%xmm15
   213f8:	66 41 0f 28 c7       	movapd %xmm15,%xmm0
   213fd:	66 44 0f 28 bc 24 c0 	movapd 0x1c0(%rsp),%xmm15
   21404:	01 00 00 
   21407:	66 0f 56 c7          	orpd   %xmm7,%xmm0
   2140b:	66 45 0f 55 c8       	andnpd %xmm8,%xmm9
   21410:	66 41 0f 54 e1       	andpd  %xmm9,%xmm4
   21415:	66 45 0f 55 ce       	andnpd %xmm14,%xmm9
   2141a:	66 45 0f 28 f1       	movapd %xmm9,%xmm14
   2141f:	66 44 0f 28 8c 24 e0 	movapd 0x1e0(%rsp),%xmm9
   21426:	01 00 00 
   21429:	66 44 0f 56 f4       	orpd   %xmm4,%xmm14
   2142e:	66 0f 28 ea          	movapd %xmm2,%xmm5
   21432:	66 0f 28 d6          	movapd %xmm6,%xmm2
   21436:	48 ff c9             	dec    %rcx
   21439:	0f 85 e1 fe ff ff    	jne    21320 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::entry::<fearless_simd::generated::sse2::Sse2, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::sse2::Sse2>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>, usize, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::sse2::Sse2>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2]>+0xb60>
   2143f:	66 0f 54 c3          	andpd  %xmm3,%xmm0
   21443:	66 0f 55 5c 24 50    	andnpd 0x50(%rsp),%xmm3
   21449:	66 0f 56 d8          	orpd   %xmm0,%xmm3
   2144d:	66 45 0f 54 f0       	andpd  %xmm8,%xmm14
   21452:	66 44 0f 55 44 24 60 	andnpd 0x60(%rsp),%xmm8
   21459:	66 45 0f 56 c6       	orpd   %xmm14,%xmm8
   2145e:	66 44 0f 29 44 24 60 	movapd %xmm8,0x60(%rsp)
   21465:	66 0f 29 5c 24 50    	movapd %xmm3,0x50(%rsp)
   2146b:	e9 30 f6 ff ff       	jmp    20aa0 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::entry::<fearless_simd::generated::sse2::Sse2, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::sse2::Sse2>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>, usize, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::sse2::Sse2>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2]>+0x2e0>
   21470:	0f 28 44 24 50       	movaps 0x50(%rsp),%xmm0
   21475:	0f 29 07             	movaps %xmm0,(%rdi)
   21478:	0f 28 44 24 60       	movaps 0x60(%rsp),%xmm0
   2147d:	0f 29 47 10          	movaps %xmm0,0x10(%rdi)
   21481:	0f 28 44 24 70       	movaps 0x70(%rsp),%xmm0
   21486:	0f 29 47 20          	movaps %xmm0,0x20(%rdi)
   2148a:	66 0f 29 4f 30       	movapd %xmm1,0x30(%rdi)
   2148f:	48 89 ec             	mov    %rbp,%rsp
   21492:	5d                   	pop    %rbp
   21493:	c3                   	ret
   21494:	cc                   	int3
   21495:	cc                   	int3
   21496:	cc                   	int3
   21497:	cc                   	int3
   21498:	cc                   	int3
   21499:	cc                   	int3
   2149a:	cc                   	int3
   2149b:	cc                   	int3
   2149c:	cc                   	int3
   2149d:	cc                   	int3
   2149e:	cc                   	int3
   2149f:	cc                   	int3

gpui_canvas::color::gamut::in_gamut:
   214a0:	55                   	push   %rbp
   214a1:	53                   	push   %rbx
   214a2:	48 83 ec 68          	sub    $0x68,%rsp
   214a6:	89 f3                	mov    %esi,%ebx
   214a8:	f3 0f 7e 0f          	movq   (%rdi),%xmm1
   214ac:	8b 4f 08             	mov    0x8(%rdi),%ecx
   214af:	8b 57 0c             	mov    0xc(%rdi),%edx
   214b2:	89 c8                	mov    %ecx,%eax
   214b4:	81 fa 00 00 00 c0    	cmp    $0xc0000000,%edx
   214ba:	0f 82 ea 00 00 00    	jb     215aa <gpui_canvas::color::gamut::in_gamut+0x10a>
   214c0:	89 c8                	mov    %ecx,%eax
   214c2:	85 c9                	test   %ecx,%ecx
   214c4:	0f 88 db 00 00 00    	js     215a5 <gpui_canvas::color::gamut::in_gamut+0x105>
   214ca:	c1 e8 08             	shr    $0x8,%eax
   214cd:	89 ce                	mov    %ecx,%esi
   214cf:	48 69 f6 8f e7 54 52 	imul   $0x5254e78f,%rsi,%rsi
   214d6:	48 c1 ee 2e          	shr    $0x2e,%rsi
   214da:	48 69 f8 09 a8 a7 01 	imul   $0x1a7a809,%rax,%rdi
   214e1:	48 c1 ef 20          	shr    $0x20,%rdi
   214e5:	66 41 0f 7e c9       	movd   %xmm1,%r9d
   214ea:	45 89 ca             	mov    %r9d,%r10d
   214ed:	41 c1 e2 08          	shl    $0x8,%r10d
   214f1:	66 0f 70 c1 55       	pshufd $0x55,%xmm1,%xmm0
   214f6:	66 41 0f 7e c0       	movd   %xmm0,%r8d
   214fb:	45 89 c3             	mov    %r8d,%r11d
   214fe:	45 0f a4 cb 08       	shld   $0x8,%r9d,%r11d
   21503:	69 ee 55 52 00 00    	imul   $0x5255,%esi,%ebp
   21509:	c1 ed 16             	shr    $0x16,%ebp
   2150c:	69 ed c7 00 00 00    	imul   $0xc7,%ebp,%ebp
   21512:	29 ee                	sub    %ebp,%esi
   21514:	44 89 dd             	mov    %r11d,%ebp
   21517:	c1 e5 08             	shl    $0x8,%ebp
   2151a:	41 81 e3 ff ff 7f 00 	and    $0x7fffff,%r11d
   21521:	41 81 e2 00 00 00 80 	and    $0x80000000,%r10d
   21528:	81 e5 00 00 00 80    	and    $0x80000000,%ebp
   2152e:	44 09 dd             	or     %r11d,%ebp
   21531:	41 81 e1 ff ff 7f 00 	and    $0x7fffff,%r9d
   21538:	45 09 d1             	or     %r10d,%r9d
   2153b:	c1 e6 17             	shl    $0x17,%esi
   2153e:	09 ee                	or     %ebp,%esi
   21540:	c1 e7 0f             	shl    $0xf,%edi
   21543:	81 e7 00 00 80 ff    	and    $0xff800000,%edi
   21549:	41 0f ac c8 10       	shrd   $0x10,%ecx,%r8d
   2154e:	44 09 cf             	or     %r9d,%edi
   21551:	4c 69 c8 9f 53 49 01 	imul   $0x149539f,%rax,%r9
   21558:	49 c1 e9 20          	shr    $0x20,%r9
   2155c:	45 69 c9 c7 00 00 00 	imul   $0xc7,%r9d,%r9d
   21563:	44 29 c8             	sub    %r9d,%eax
   21566:	45 89 c1             	mov    %r8d,%r9d
   21569:	41 81 e1 ff ff 7f 00 	and    $0x7fffff,%r9d
   21570:	41 c1 e0 08          	shl    $0x8,%r8d
   21574:	41 81 e0 00 00 00 80 	and    $0x80000000,%r8d
   2157b:	45 09 c8             	or     %r9d,%r8d
   2157e:	c1 e0 17             	shl    $0x17,%eax
   21581:	44 09 c0             	or     %r8d,%eax
   21584:	66 0f 6e c6          	movd   %esi,%xmm0
   21588:	66 0f 6e cf          	movd   %edi,%xmm1
   2158c:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
   21590:	c1 ea 1e             	shr    $0x1e,%edx
   21593:	31 ed                	xor    %ebp,%ebp
   21595:	48 8d 35 c8 5c fe ff 	lea    -0x1a338(%rip),%rsi        # 7264 <std::thread::current::id::ID+0x65ec>
   2159c:	48 63 14 96          	movslq (%rsi,%rdx,4),%rdx
   215a0:	48 01 f2             	add    %rsi,%rdx
   215a3:	ff e2                	jmp    *%rdx
   215a5:	25 ff ff ff 7f       	and    $0x7fffffff,%eax
   215aa:	c1 ea 1e             	shr    $0x1e,%edx
   215ad:	31 ed                	xor    %ebp,%ebp
   215af:	48 8d 35 ae 5c fe ff 	lea    -0x1a352(%rip),%rsi        # 7264 <std::thread::current::id::ID+0x65ec>
   215b6:	48 63 14 96          	movslq (%rsi,%rdx,4),%rdx
   215ba:	48 01 f2             	add    %rsi,%rdx
   215bd:	ff e2                	jmp    *%rdx
   215bf:	40 b5 01             	mov    $0x1,%bpl
   215c2:	f3 0f 5a e9          	cvtss2sd %xmm1,%xmm5
   215c6:	66 0f 70 f1 55       	pshufd $0x55,%xmm1,%xmm6
   215cb:	f3 0f 5a e6          	cvtss2sd %xmm6,%xmm4
   215cf:	66 0f 6e d0          	movd   %eax,%xmm2
   215d3:	0f 28 05 26 3b fe ff 	movaps -0x1c4da(%rip),%xmm0        # 5100 <std::thread::current::id::ID+0x4488>
   215da:	0f 54 c5             	andps  %xmm5,%xmm0
   215dd:	f2 0f 10 1d 5b 59 fe 	movsd  -0x1a6a5(%rip),%xmm3        # 6f40 <std::thread::current::id::ID+0x62c8>
   215e4:	ff 
   215e5:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   215e9:	66 0f 7e 54 24 30    	movd   %xmm2,0x30(%rsp)
   215ef:	73 53                	jae    21644 <gpui_canvas::color::gamut::in_gamut+0x1a4>
   215f1:	0f 2e c9             	ucomiss %xmm1,%xmm1
   215f4:	0f 29 64 24 10       	movaps %xmm4,0x10(%rsp)
   215f9:	0f 29 74 24 50       	movaps %xmm6,0x50(%rsp)
   215fe:	7a 4e                	jp     2164e <gpui_canvas::color::gamut::in_gamut+0x1ae>
   21600:	0f 54 2d 39 3f fe ff 	andps  -0x1c0c7(%rip),%xmm5        # 5540 <std::thread::current::id::ID+0x48c8>
   21607:	0f 56 2d 72 3e fe ff 	orps   -0x1c18e(%rip),%xmm5        # 5480 <std::thread::current::id::ID+0x4808>
   2160e:	0f 29 2c 24          	movaps %xmm5,(%rsp)
   21612:	eb 46                	jmp    2165a <gpui_canvas::color::gamut::in_gamut+0x1ba>
   21614:	0f 5a e9             	cvtps2pd %xmm1,%xmm5
   21617:	66 0f 6e c0          	movd   %eax,%xmm0
   2161b:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   2161f:	e9 ad 01 00 00       	jmp    217d1 <gpui_canvas::color::gamut::in_gamut+0x331>
   21624:	85 c9                	test   %ecx,%ecx
   21626:	0f 88 86 02 00 00    	js     218b2 <gpui_canvas::color::gamut::in_gamut+0x412>
   2162c:	0f 5a e9             	cvtps2pd %xmm1,%xmm5
   2162f:	66 0f 6e c0          	movd   %eax,%xmm0
   21633:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   21637:	84 db                	test   %bl,%bl
   21639:	0f 84 5e 02 00 00    	je     2189d <gpui_canvas::color::gamut::in_gamut+0x3fd>
   2163f:	e9 a7 02 00 00       	jmp    218eb <gpui_canvas::color::gamut::in_gamut+0x44b>
   21644:	f2 0f 5e 2d 94 58 fe 	divsd  -0x1a76c(%rip),%xmm5        # 6ee0 <std::thread::current::id::ID+0x6268>
   2164b:	ff 
   2164c:	eb 4b                	jmp    21699 <gpui_canvas::color::gamut::in_gamut+0x1f9>
   2164e:	f2 0f 10 0d 7a 59 fe 	movsd  -0x1a686(%rip),%xmm1        # 6fd0 <std::thread::current::id::ID+0x6358>
   21655:	ff 
   21656:	0f 29 0c 24          	movaps %xmm1,(%rsp)
   2165a:	f2 0f 58 05 ee 59 fe 	addsd  -0x1a612(%rip),%xmm0        # 7050 <std::thread::current::id::ID+0x63d8>
   21661:	ff 
   21662:	f2 0f 5e 05 86 59 fe 	divsd  -0x1a67a(%rip),%xmm0        # 6ff0 <std::thread::current::id::ID+0x6378>
   21669:	ff 
   2166a:	f2 0f 10 0d 26 59 fe 	movsd  -0x1a6da(%rip),%xmm1        # 6f98 <std::thread::current::id::ID+0x6320>
   21671:	ff 
   21672:	ff 15 38 22 04 00    	call   *0x42238(%rip)        # 638b0 <pow@GLIBC_2.29>
   21678:	66 0f 28 e8          	movapd %xmm0,%xmm5
   2167c:	f2 0f 59 2c 24       	mulsd  (%rsp),%xmm5
   21681:	66 0f 6e 54 24 30    	movd   0x30(%rsp),%xmm2
   21687:	f2 0f 10 1d b1 58 fe 	movsd  -0x1a74f(%rip),%xmm3        # 6f40 <std::thread::current::id::ID+0x62c8>
   2168e:	ff 
   2168f:	0f 28 64 24 10       	movaps 0x10(%rsp),%xmm4
   21694:	0f 28 74 24 50       	movaps 0x50(%rsp),%xmm6
   21699:	0f 57 c9             	xorps  %xmm1,%xmm1
   2169c:	f3 0f 5a ca          	cvtss2sd %xmm2,%xmm1
   216a0:	0f 28 05 59 3a fe ff 	movaps -0x1c5a7(%rip),%xmm0        # 5100 <std::thread::current::id::ID+0x4488>
   216a7:	0f 54 c4             	andps  %xmm4,%xmm0
   216aa:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   216ae:	66 0f 29 2c 24       	movapd %xmm5,(%rsp)
   216b3:	73 1f                	jae    216d4 <gpui_canvas::color::gamut::in_gamut+0x234>
   216b5:	0f 2e f6             	ucomiss %xmm6,%xmm6
   216b8:	0f 29 4c 24 20       	movaps %xmm1,0x20(%rsp)
   216bd:	7a 4b                	jp     2170a <gpui_canvas::color::gamut::in_gamut+0x26a>
   216bf:	0f 54 25 7a 3e fe ff 	andps  -0x1c186(%rip),%xmm4        # 5540 <std::thread::current::id::ID+0x48c8>
   216c6:	0f 56 25 b3 3d fe ff 	orps   -0x1c24d(%rip),%xmm4        # 5480 <std::thread::current::id::ID+0x4808>
   216cd:	0f 29 64 24 10       	movaps %xmm4,0x10(%rsp)
   216d2:	eb 43                	jmp    21717 <gpui_canvas::color::gamut::in_gamut+0x277>
   216d4:	f2 0f 5e 25 04 58 fe 	divsd  -0x1a7fc(%rip),%xmm4        # 6ee0 <std::thread::current::id::ID+0x6268>
   216db:	ff 
   216dc:	0f 28 05 1d 3a fe ff 	movaps -0x1c5e3(%rip),%xmm0        # 5100 <std::thread::current::id::ID+0x4488>
   216e3:	0f 54 c1             	andps  %xmm1,%xmm0
   216e6:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   216ea:	72 7e                	jb     2176a <gpui_canvas::color::gamut::in_gamut+0x2ca>
   216ec:	f2 0f 5e 0d ec 57 fe 	divsd  -0x1a814(%rip),%xmm1        # 6ee0 <std::thread::current::id::ID+0x6268>
   216f3:	ff 
   216f4:	66 0f 28 c1          	movapd %xmm1,%xmm0
   216f8:	66 0f 14 ec          	unpcklpd %xmm4,%xmm5
   216fc:	40 84 ed             	test   %bpl,%bpl
   216ff:	0f 85 cc 00 00 00    	jne    217d1 <gpui_canvas::color::gamut::in_gamut+0x331>
   21705:	e9 8f 01 00 00       	jmp    21899 <gpui_canvas::color::gamut::in_gamut+0x3f9>
   2170a:	f2 0f 10 0d be 58 fe 	movsd  -0x1a742(%rip),%xmm1        # 6fd0 <std::thread::current::id::ID+0x6358>
   21711:	ff 
   21712:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
   21717:	f2 0f 58 05 31 59 fe 	addsd  -0x1a6cf(%rip),%xmm0        # 7050 <std::thread::current::id::ID+0x63d8>
   2171e:	ff 
   2171f:	f2 0f 5e 05 c9 58 fe 	divsd  -0x1a737(%rip),%xmm0        # 6ff0 <std::thread::current::id::ID+0x6378>
   21726:	ff 
   21727:	f2 0f 10 0d 69 58 fe 	movsd  -0x1a797(%rip),%xmm1        # 6f98 <std::thread::current::id::ID+0x6320>
   2172e:	ff 
   2172f:	ff 15 7b 21 04 00    	call   *0x4217b(%rip)        # 638b0 <pow@GLIBC_2.29>
   21735:	66 0f 28 e0          	movapd %xmm0,%xmm4
   21739:	f2 0f 59 64 24 10    	mulsd  0x10(%rsp),%xmm4
   2173f:	66 0f 28 2c 24       	movapd (%rsp),%xmm5
   21744:	f3 0f 10 54 24 30    	movss  0x30(%rsp),%xmm2
   2174a:	f2 0f 10 1d ee 57 fe 	movsd  -0x1a812(%rip),%xmm3        # 6f40 <std::thread::current::id::ID+0x62c8>
   21751:	ff 
   21752:	66 0f 28 4c 24 20    	movapd 0x20(%rsp),%xmm1
   21758:	66 0f 28 05 a0 39 fe 	movapd -0x1c660(%rip),%xmm0        # 5100 <std::thread::current::id::ID+0x4488>
   2175f:	ff 
   21760:	66 0f 54 c1          	andpd  %xmm1,%xmm0
   21764:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   21768:	73 82                	jae    216ec <gpui_canvas::color::gamut::in_gamut+0x24c>
   2176a:	0f 2e d2             	ucomiss %xmm2,%xmm2
   2176d:	66 0f 29 64 24 10    	movapd %xmm4,0x10(%rsp)
   21773:	7a 12                	jp     21787 <gpui_canvas::color::gamut::in_gamut+0x2e7>
   21775:	66 0f 54 0d c3 3d fe 	andpd  -0x1c23d(%rip),%xmm1        # 5540 <std::thread::current::id::ID+0x48c8>
   2177c:	ff 
   2177d:	66 0f 56 0d fb 3c fe 	orpd   -0x1c305(%rip),%xmm1        # 5480 <std::thread::current::id::ID+0x4808>
   21784:	ff 
   21785:	eb 08                	jmp    2178f <gpui_canvas::color::gamut::in_gamut+0x2ef>
   21787:	f2 0f 10 0d 41 58 fe 	movsd  -0x1a7bf(%rip),%xmm1        # 6fd0 <std::thread::current::id::ID+0x6358>
   2178e:	ff 
   2178f:	66 0f 29 4c 24 20    	movapd %xmm1,0x20(%rsp)
   21795:	f2 0f 58 05 b3 58 fe 	addsd  -0x1a74d(%rip),%xmm0        # 7050 <std::thread::current::id::ID+0x63d8>
   2179c:	ff 
   2179d:	f2 0f 5e 05 4b 58 fe 	divsd  -0x1a7b5(%rip),%xmm0        # 6ff0 <std::thread::current::id::ID+0x6378>
   217a4:	ff 
   217a5:	f2 0f 10 0d eb 57 fe 	movsd  -0x1a815(%rip),%xmm1        # 6f98 <std::thread::current::id::ID+0x6320>
   217ac:	ff 
   217ad:	ff 15 fd 20 04 00    	call   *0x420fd(%rip)        # 638b0 <pow@GLIBC_2.29>
   217b3:	f2 0f 59 44 24 20    	mulsd  0x20(%rsp),%xmm0
   217b9:	66 0f 28 2c 24       	movapd (%rsp),%xmm5
   217be:	66 0f 28 64 24 10    	movapd 0x10(%rsp),%xmm4
   217c4:	66 0f 14 ec          	unpcklpd %xmm4,%xmm5
   217c8:	40 84 ed             	test   %bpl,%bpl
   217cb:	0f 84 c8 00 00 00    	je     21899 <gpui_canvas::color::gamut::in_gamut+0x3f9>
   217d1:	66 0f 28 d5          	movapd %xmm5,%xmm2
   217d5:	66 0f c6 d5 01       	shufpd $0x1,%xmm5,%xmm2
   217da:	66 0f 59 15 ae 3c fe 	mulpd  -0x1c352(%rip),%xmm2        # 5490 <std::thread::current::id::ID+0x4818>
   217e1:	ff 
   217e2:	66 0f 57 db          	xorpd  %xmm3,%xmm3
   217e6:	66 0f 16 1d 4a 58 fe 	movhpd -0x1a7b6(%rip),%xmm3        # 7038 <std::thread::current::id::ID+0x63c0>
   217ed:	ff 
   217ee:	66 0f 59 dd          	mulpd  %xmm5,%xmm3
   217f2:	0f 28 c8             	movaps %xmm0,%xmm1
   217f5:	0f 16 c8             	movlhps %xmm0,%xmm1
   217f8:	66 0f 59 0d 10 39 fe 	mulpd  -0x1c6f0(%rip),%xmm1        # 5110 <std::thread::current::id::ID+0x4498>
   217ff:	ff 
   21800:	66 0f 58 da          	addpd  %xmm2,%xmm3
   21804:	66 0f 58 cb          	addpd  %xmm3,%xmm1
   21808:	f2 0f 10 15 08 57 fe 	movsd  -0x1a8f8(%rip),%xmm2        # 6f18 <std::thread::current::id::ID+0x62a0>
   2180f:	ff 
   21810:	f2 0f 59 d5          	mulsd  %xmm5,%xmm2
   21814:	f2 0f 10 e8          	movsd  %xmm0,%xmm5
   21818:	66 0f 59 2d 00 39 fe 	mulpd  -0x1c700(%rip),%xmm5        # 5120 <std::thread::current::id::ID+0x44a8>
   2181f:	ff 
   21820:	66 0f 28 c5          	movapd %xmm5,%xmm0
   21824:	66 0f 15 c5          	unpckhpd %xmm5,%xmm0
   21828:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   2182c:	f2 0f 58 c5          	addsd  %xmm5,%xmm0
   21830:	f2 0f 10 15 b8 56 fe 	movsd  -0x1a948(%rip),%xmm2        # 6ef0 <std::thread::current::id::ID+0x6278>
   21837:	ff 
   21838:	66 0f 28 d9          	movapd %xmm1,%xmm3
   2183c:	f2 0f 10 d8          	movsd  %xmm0,%xmm3
   21840:	66 0f 59 1d 38 3b fe 	mulpd  -0x1c4c8(%rip),%xmm3        # 5380 <std::thread::current::id::ID+0x4708>
   21847:	ff 
   21848:	66 0f 28 e1          	movapd %xmm1,%xmm4
   2184c:	66 0f c6 e0 01       	shufpd $0x1,%xmm0,%xmm4
   21851:	66 0f 59 25 87 3a fe 	mulpd  -0x1c579(%rip),%xmm4        # 52e0 <std::thread::current::id::ID+0x4668>
   21858:	ff 
   21859:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
   2185d:	66 0f 58 e3          	addpd  %xmm3,%xmm4
   21861:	66 0f 28 e9          	movapd %xmm1,%xmm5
   21865:	66 0f 14 e9          	unpcklpd %xmm1,%xmm5
   21869:	66 0f 59 2d df 3c fe 	mulpd  -0x1c321(%rip),%xmm5        # 5550 <std::thread::current::id::ID+0x48d8>
   21870:	ff 
   21871:	66 0f 28 c4          	movapd %xmm4,%xmm0
   21875:	66 0f 5c c5          	subpd  %xmm5,%xmm0
   21879:	66 0f 58 ec          	addpd  %xmm4,%xmm5
   2187d:	f2 0f 10 e8          	movsd  %xmm0,%xmm5
   21881:	66 0f 59 0d d7 3a fe 	mulpd  -0x1c529(%rip),%xmm1        # 5360 <std::thread::current::id::ID+0x46e8>
   21888:	ff 
   21889:	66 0f 28 c1          	movapd %xmm1,%xmm0
   2188d:	66 0f 15 c1          	unpckhpd %xmm1,%xmm0
   21891:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   21895:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
   21899:	84 db                	test   %bl,%bl
   2189b:	75 4e                	jne    218eb <gpui_canvas::color::gamut::in_gamut+0x44b>
   2189d:	31 c0                	xor    %eax,%eax
   2189f:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   218a3:	66 0f 2e e9          	ucomisd %xmm1,%xmm5
   218a7:	0f 83 08 01 00 00    	jae    219b5 <gpui_canvas::color::gamut::in_gamut+0x515>
   218ad:	e9 41 01 00 00       	jmp    219f3 <gpui_canvas::color::gamut::in_gamut+0x553>
   218b2:	66 0f 6f d1          	movdqa %xmm1,%xmm2
   218b6:	0f c6 c9 55          	shufps $0x55,%xmm1,%xmm1
   218ba:	66 0f ef c0          	pxor   %xmm0,%xmm0
   218be:	0f 2e c8             	ucomiss %xmm0,%xmm1
   218c1:	0f 85 35 01 00 00    	jne    219fc <gpui_canvas::color::gamut::in_gamut+0x55c>
   218c7:	0f 8a 2f 01 00 00    	jp     219fc <gpui_canvas::color::gamut::in_gamut+0x55c>
   218cd:	0f 57 c9             	xorps  %xmm1,%xmm1
   218d0:	f3 0f 5a ca          	cvtss2sd %xmm2,%xmm1
   218d4:	0f 28 c1             	movaps %xmm1,%xmm0
   218d7:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   218db:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   218df:	66 0f 28 e8          	movapd %xmm0,%xmm5
   218e3:	66 0f 14 e8          	unpcklpd %xmm0,%xmm5
   218e7:	84 db                	test   %bl,%bl
   218e9:	74 b2                	je     2189d <gpui_canvas::color::gamut::in_gamut+0x3fd>
   218eb:	66 0f 28 0d 8d 38 fe 	movapd -0x1c773(%rip),%xmm1        # 5180 <std::thread::current::id::ID+0x4508>
   218f2:	ff 
   218f3:	66 0f 59 cd          	mulpd  %xmm5,%xmm1
   218f7:	66 0f 28 d5          	movapd %xmm5,%xmm2
   218fb:	66 0f c6 d5 01       	shufpd $0x1,%xmm5,%xmm2
   21900:	66 0f 59 15 d8 3b fe 	mulpd  -0x1c428(%rip),%xmm2        # 54e0 <std::thread::current::id::ID+0x4868>
   21907:	ff 
   21908:	66 0f 58 d1          	addpd  %xmm1,%xmm2
   2190c:	66 0f 28 c8          	movapd %xmm0,%xmm1
   21910:	66 0f 14 c8          	unpcklpd %xmm0,%xmm1
   21914:	66 0f 59 0d f4 38 fe 	mulpd  -0x1c70c(%rip),%xmm1        # 5210 <std::thread::current::id::ID+0x4598>
   2191b:	ff 
   2191c:	f2 0f 10 1d 2c 56 fe 	movsd  -0x1a9d4(%rip),%xmm3        # 6f50 <std::thread::current::id::ID+0x62d8>
   21923:	ff 
   21924:	f2 0f 59 dd          	mulsd  %xmm5,%xmm3
   21928:	f2 0f 10 e8          	movsd  %xmm0,%xmm5
   2192c:	66 0f 59 2d ec 38 fe 	mulpd  -0x1c714(%rip),%xmm5        # 5220 <std::thread::current::id::ID+0x45a8>
   21933:	ff 
   21934:	66 0f 58 ca          	addpd  %xmm2,%xmm1
   21938:	66 0f 28 c5          	movapd %xmm5,%xmm0
   2193c:	66 0f 15 c5          	unpckhpd %xmm5,%xmm0
   21940:	f2 0f 58 c3          	addsd  %xmm3,%xmm0
   21944:	66 0f 28 d1          	movapd %xmm1,%xmm2
   21948:	66 0f c6 d1 01       	shufpd $0x1,%xmm1,%xmm2
   2194d:	66 0f 59 15 db 37 fe 	mulpd  -0x1c825(%rip),%xmm2        # 5130 <std::thread::current::id::ID+0x44b8>
   21954:	ff 
   21955:	f2 0f 58 c5          	addsd  %xmm5,%xmm0
   21959:	66 0f 28 1d 2f 38 fe 	movapd -0x1c7d1(%rip),%xmm3        # 5190 <std::thread::current::id::ID+0x4518>
   21960:	ff 
   21961:	66 0f 59 d9          	mulpd  %xmm1,%xmm3
   21965:	66 0f 5c da          	subpd  %xmm2,%xmm3
   21969:	66 0f 28 e8          	movapd %xmm0,%xmm5
   2196d:	66 0f 14 e8          	unpcklpd %xmm0,%xmm5
   21971:	66 0f 59 2d 87 38 fe 	mulpd  -0x1c779(%rip),%xmm5        # 5200 <std::thread::current::id::ID+0x4588>
   21978:	ff 
   21979:	66 0f 28 d3          	movapd %xmm3,%xmm2
   2197d:	66 0f 5c d5          	subpd  %xmm5,%xmm2
   21981:	66 0f 58 eb          	addpd  %xmm3,%xmm5
   21985:	f2 0f 10 ea          	movsd  %xmm2,%xmm5
   21989:	66 0f 59 0d 6f 3a fe 	mulpd  -0x1c591(%rip),%xmm1        # 5400 <std::thread::current::id::ID+0x4788>
   21990:	ff 
   21991:	66 0f 28 d1          	movapd %xmm1,%xmm2
   21995:	66 0f 15 d1          	unpckhpd %xmm1,%xmm2
   21999:	f2 0f 5c ca          	subsd  %xmm2,%xmm1
   2199d:	f2 0f 59 05 3b 56 fe 	mulsd  -0x1a9c5(%rip),%xmm0        # 6fe0 <std::thread::current::id::ID+0x6368>
   219a4:	ff 
   219a5:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
   219a9:	31 c0                	xor    %eax,%eax
   219ab:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   219af:	66 0f 2e e9          	ucomisd %xmm1,%xmm5
   219b3:	72 3e                	jb     219f3 <gpui_canvas::color::gamut::in_gamut+0x553>
   219b5:	f2 0f 10 0d ab 55 fe 	movsd  -0x1aa55(%rip),%xmm1        # 6f68 <std::thread::current::id::ID+0x62f0>
   219bc:	ff 
   219bd:	66 0f 2e cd          	ucomisd %xmm5,%xmm1
   219c1:	72 30                	jb     219f3 <gpui_canvas::color::gamut::in_gamut+0x553>
   219c3:	66 0f 15 ed          	unpckhpd %xmm5,%xmm5
   219c7:	31 c0                	xor    %eax,%eax
   219c9:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   219cd:	66 0f 2e ea          	ucomisd %xmm2,%xmm5
   219d1:	72 20                	jb     219f3 <gpui_canvas::color::gamut::in_gamut+0x553>
   219d3:	66 0f 2e cd          	ucomisd %xmm5,%xmm1
   219d7:	72 1a                	jb     219f3 <gpui_canvas::color::gamut::in_gamut+0x553>
   219d9:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   219dd:	f2 0f c2 c8 02       	cmplesd %xmm0,%xmm1
   219e2:	f2 0f c2 05 7d 55 fe 	cmplesd -0x1aa83(%rip),%xmm0        # 6f68 <std::thread::current::id::ID+0x62f0>
   219e9:	ff 02 
   219eb:	66 0f 54 c1          	andpd  %xmm1,%xmm0
   219ef:	66 0f 7e c0          	movd   %xmm0,%eax
   219f3:	24 01                	and    $0x1,%al
   219f5:	48 83 c4 68          	add    $0x68,%rsp
   219f9:	5b                   	pop    %rbx
   219fa:	5d                   	pop    %rbp
   219fb:	c3                   	ret
   219fc:	66 0f 6e c0          	movd   %eax,%xmm0
   21a00:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   21a04:	f2 0f 59 05 24 56 fe 	mulsd  -0x1a9dc(%rip),%xmm0        # 7030 <std::thread::current::id::ID+0x63b8>
   21a0b:	ff 
   21a0c:	48 8d 7c 24 48       	lea    0x48(%rsp),%rdi
   21a11:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
   21a16:	0f 29 0c 24          	movaps %xmm1,(%rsp)
   21a1a:	66 0f 7f 54 24 30    	movdqa %xmm2,0x30(%rsp)
   21a20:	ff 15 9a 1e 04 00    	call   *0x41e9a(%rip)        # 638c0 <sincos@GLIBC_2.2.5>
   21a26:	0f 28 44 24 30       	movaps 0x30(%rsp),%xmm0
   21a2b:	0f 57 c9             	xorps  %xmm1,%xmm1
   21a2e:	f3 0f 5a c8          	cvtss2sd %xmm0,%xmm1
   21a32:	0f 28 04 24          	movaps (%rsp),%xmm0
   21a36:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   21a3a:	f2 0f 10 54 24 40    	movsd  0x40(%rsp),%xmm2
   21a40:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
   21a44:	f2 0f 59 44 24 48    	mulsd  0x48(%rsp),%xmm0
   21a4a:	f2 0f 10 1d d6 55 fe 	movsd  -0x1aa2a(%rip),%xmm3        # 7028 <std::thread::current::id::ID+0x63b0>
   21a51:	ff 
   21a52:	f2 0f 59 da          	mulsd  %xmm2,%xmm3
   21a56:	f2 0f 58 d9          	addsd  %xmm1,%xmm3
   21a5a:	f2 0f 10 2d 76 55 fe 	movsd  -0x1aa8a(%rip),%xmm5        # 6fd8 <std::thread::current::id::ID+0x6360>
   21a61:	ff 
   21a62:	f2 0f 59 e8          	mulsd  %xmm0,%xmm5
   21a66:	f2 0f 58 eb          	addsd  %xmm3,%xmm5
   21a6a:	f2 0f 10 1d 36 55 fe 	movsd  -0x1aaca(%rip),%xmm3        # 6fa8 <std::thread::current::id::ID+0x6330>
   21a71:	ff 
   21a72:	f2 0f 59 da          	mulsd  %xmm2,%xmm3
   21a76:	f2 0f 58 d9          	addsd  %xmm1,%xmm3
   21a7a:	f2 0f 10 35 d6 55 fe 	movsd  -0x1aa2a(%rip),%xmm6        # 7058 <std::thread::current::id::ID+0x63e0>
   21a81:	ff 
   21a82:	f2 0f 59 f0          	mulsd  %xmm0,%xmm6
   21a86:	f2 0f 58 f3          	addsd  %xmm3,%xmm6
   21a8a:	f2 0f 59 15 86 55 fe 	mulsd  -0x1aa7a(%rip),%xmm2        # 7018 <std::thread::current::id::ID+0x63a0>
   21a91:	ff 
   21a92:	f2 0f 58 d1          	addsd  %xmm1,%xmm2
   21a96:	f2 0f 59 05 4a 54 fe 	mulsd  -0x1abb6(%rip),%xmm0        # 6ee8 <std::thread::current::id::ID+0x6270>
   21a9d:	ff 
   21a9e:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   21aa2:	66 0f 28 e5          	movapd %xmm5,%xmm4
   21aa6:	f2 0f 59 e5          	mulsd  %xmm5,%xmm4
   21aaa:	f2 0f 59 e5          	mulsd  %xmm5,%xmm4
   21aae:	66 0f 28 de          	movapd %xmm6,%xmm3
   21ab2:	f2 0f 59 de          	mulsd  %xmm6,%xmm3
   21ab6:	f2 0f 59 de          	mulsd  %xmm6,%xmm3
   21aba:	66 0f 28 c8          	movapd %xmm0,%xmm1
   21abe:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   21ac2:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   21ac6:	f2 0f 10 05 92 55 fe 	movsd  -0x1aa6e(%rip),%xmm0        # 7060 <std::thread::current::id::ID+0x63e8>
   21acd:	ff 
   21ace:	f2 0f 59 c4          	mulsd  %xmm4,%xmm0
   21ad2:	f2 0f 10 15 9e 54 fe 	movsd  -0x1ab62(%rip),%xmm2        # 6f78 <std::thread::current::id::ID+0x6300>
   21ad9:	ff 
   21ada:	f2 0f 59 d3          	mulsd  %xmm3,%xmm2
   21ade:	f2 0f 58 d0          	addsd  %xmm0,%xmm2
   21ae2:	f2 0f 10 05 96 54 fe 	movsd  -0x1ab6a(%rip),%xmm0        # 6f80 <std::thread::current::id::ID+0x6308>
   21ae9:	ff 
   21aea:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   21aee:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   21af2:	f2 0f 10 15 f6 53 fe 	movsd  -0x1ac0a(%rip),%xmm2        # 6ef0 <std::thread::current::id::ID+0x6278>
   21af9:	ff 
   21afa:	66 0f 14 e4          	unpcklpd %xmm4,%xmm4
   21afe:	66 0f 59 25 0a 3a fe 	mulpd  -0x1c5f6(%rip),%xmm4        # 5510 <std::thread::current::id::ID+0x4898>
   21b05:	ff 
   21b06:	66 0f 14 db          	unpcklpd %xmm3,%xmm3
   21b0a:	66 0f 59 1d 0e 3a fe 	mulpd  -0x1c5f2(%rip),%xmm3        # 5520 <std::thread::current::id::ID+0x48a8>
   21b11:	ff 
   21b12:	66 0f 58 dc          	addpd  %xmm4,%xmm3
   21b16:	66 0f 14 c9          	unpcklpd %xmm1,%xmm1
   21b1a:	66 0f 59 0d 2e 38 fe 	mulpd  -0x1c7d2(%rip),%xmm1        # 5350 <std::thread::current::id::ID+0x46d8>
   21b21:	ff 
   21b22:	66 0f 58 cb          	addpd  %xmm3,%xmm1
   21b26:	e9 0d fd ff ff       	jmp    21838 <gpui_canvas::color::gamut::in_gamut+0x398>

