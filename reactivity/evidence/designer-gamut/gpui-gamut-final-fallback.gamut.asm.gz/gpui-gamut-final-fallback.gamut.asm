<gpui_canvas::color::OutputProfile>::max_chroma:
   1f7c0:	66 0f 7e c1          	movd   %xmm0,%ecx
   1f7c4:	81 e1 ff ff ff 7f    	and    $0x7fffffff,%ecx
   1f7ca:	b8 0d 00 00 00       	mov    $0xd,%eax
   1f7cf:	81 f9 ff ff 7f 7f    	cmp    $0x7f7fffff,%ecx
   1f7d5:	7f 38                	jg     1f80f <<gpui_canvas::color::OutputProfile>::max_chroma+0x4f>
   1f7d7:	0f 57 e4             	xorps  %xmm4,%xmm4
   1f7da:	0f 57 d2             	xorps  %xmm2,%xmm2
   1f7dd:	f3 0f c2 d0 06       	cmpnless %xmm0,%xmm2
   1f7e2:	0f 28 d8             	movaps %xmm0,%xmm3
   1f7e5:	f3 0f c2 1d aa 60 fe 	cmpnless -0x19f56(%rip),%xmm3        # 5898 <std::thread::current::id::ID+0x4c20>
   1f7ec:	ff 06 
   1f7ee:	0f 56 da             	orps   %xmm2,%xmm3
   1f7f1:	66 0f 7e d9          	movd   %xmm3,%ecx
   1f7f5:	66 0f 7e ca          	movd   %xmm1,%edx
   1f7f9:	81 e2 ff ff ff 7f    	and    $0x7fffffff,%edx
   1f7ff:	81 fa 00 00 80 7f    	cmp    $0x7f800000,%edx
   1f805:	0f 9d c2             	setge  %dl
   1f808:	08 ca                	or     %cl,%dl
   1f80a:	f6 c2 01             	test   $0x1,%dl
   1f80d:	74 01                	je     1f810 <<gpui_canvas::color::OutputProfile>::max_chroma+0x50>
   1f80f:	c3                   	ret
   1f810:	0f 2e c4             	ucomiss %xmm4,%xmm0
   1f813:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   1f818:	75 02                	jne    1f81c <<gpui_canvas::color::OutputProfile>::max_chroma+0x5c>
   1f81a:	7b f3                	jnp    1f80f <<gpui_canvas::color::OutputProfile>::max_chroma+0x4f>
   1f81c:	0f 2e 05 75 60 fe ff 	ucomiss -0x19f8b(%rip),%xmm0        # 5898 <std::thread::current::id::ID+0x4c20>
   1f823:	75 02                	jne    1f827 <<gpui_canvas::color::OutputProfile>::max_chroma+0x67>
   1f825:	7b e8                	jnp    1f80f <<gpui_canvas::color::OutputProfile>::max_chroma+0x4f>
   1f827:	53                   	push   %rbx
   1f828:	48 83 ec 10          	sub    $0x10,%rsp
   1f82c:	f3 0f 11 44 24 0c    	movss  %xmm0,0xc(%rsp)
   1f832:	89 fb                	mov    %edi,%ebx
   1f834:	0f 57 c0             	xorps  %xmm0,%xmm0
   1f837:	f3 0f 5a c1          	cvtss2sd %xmm1,%xmm0
   1f83b:	f2 0f 10 0d 55 7b fe 	movsd  -0x184ab(%rip),%xmm1        # 7398 <std::thread::current::id::ID+0x6720>
   1f842:	ff 
   1f843:	ff 15 9f 5e 04 00    	call   *0x45e9f(%rip)        # 656e8 <_DYNAMIC+0x370>
   1f849:	f2 0f 10 1d 47 7b fe 	movsd  -0x184b9(%rip),%xmm3        # 7398 <std::thread::current::id::ID+0x6720>
   1f850:	ff 
   1f851:	f2 0f 58 d8          	addsd  %xmm0,%xmm3
   1f855:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   1f859:	66 0f 28 d0          	movapd %xmm0,%xmm2
   1f85d:	f2 0f c2 d1 01       	cmpltsd %xmm1,%xmm2
   1f862:	66 0f 54 da          	andpd  %xmm2,%xmm3
   1f866:	66 0f 55 d0          	andnpd %xmm0,%xmm2
   1f86a:	66 0f 56 d3          	orpd   %xmm3,%xmm2
   1f86e:	66 0f 2e 15 5a 7a fe 	ucomisd -0x185a6(%rip),%xmm2        # 72d0 <std::thread::current::id::ID+0x6658>
   1f875:	ff 
   1f876:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   1f87a:	73 0f                	jae    1f88b <<gpui_canvas::color::OutputProfile>::max_chroma+0xcb>
   1f87c:	0f 57 c0             	xorps  %xmm0,%xmm0
   1f87f:	f2 0f 5a c2          	cvtsd2ss %xmm2,%xmm0
   1f883:	f3 0f c2 c8 00       	cmpeqss %xmm0,%xmm1
   1f888:	0f 55 c8             	andnps %xmm0,%xmm1
   1f88b:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   1f891:	0f b6 fb             	movzbl %bl,%edi
   1f894:	48 83 c4 10          	add    $0x10,%rsp
   1f898:	5b                   	pop    %rbx
   1f899:	e9 02 21 00 00       	jmp    219a0 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>>
   1f89e:	cc                   	int3
   1f89f:	cc                   	int3

<gpui_canvas::color::Color>::fit_chroma:
   203d0:	55                   	push   %rbp
   203d1:	41 57                	push   %r15
   203d3:	41 56                	push   %r14
   203d5:	41 54                	push   %r12
   203d7:	53                   	push   %rbx
   203d8:	48 83 ec 30          	sub    $0x30,%rsp
   203dc:	48 89 fb             	mov    %rdi,%rbx
   203df:	44 8b 66 08          	mov    0x8(%rsi),%r12d
   203e3:	44 8b 7e 0c          	mov    0xc(%rsi),%r15d
   203e7:	41 81 ff 00 00 00 c0 	cmp    $0xc0000000,%r15d
   203ee:	0f 92 c0             	setb   %al
   203f1:	45 85 e4             	test   %r12d,%r12d
   203f4:	0f 99 c1             	setns  %cl
   203f7:	08 c1                	or     %al,%cl
   203f9:	80 f9 01             	cmp    $0x1,%cl
   203fc:	75 09                	jne    20407 <<gpui_canvas::color::Color>::fit_chroma+0x37>
   203fe:	c7 43 04 0d 00 00 00 	movl   $0xd,0x4(%rbx)
   20405:	eb 4a                	jmp    20451 <<gpui_canvas::color::Color>::fit_chroma+0x81>
   20407:	49 89 f6             	mov    %rsi,%r14
   2040a:	0f 10 06             	movups (%rsi),%xmm0
   2040d:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   20412:	0f b6 ea             	movzbl %dl,%ebp
   20415:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   2041a:	89 ee                	mov    %ebp,%esi
   2041c:	e8 1f 23 00 00       	call   22740 <gpui_canvas::color::gamut::in_gamut>
   20421:	84 c0                	test   %al,%al
   20423:	74 0c                	je     20431 <<gpui_canvas::color::Color>::fit_chroma+0x61>
   20425:	41 0f 10 06          	movups (%r14),%xmm0
   20429:	0f 11 43 04          	movups %xmm0,0x4(%rbx)
   2042d:	31 c0                	xor    %eax,%eax
   2042f:	eb 25                	jmp    20456 <<gpui_canvas::color::Color>::fit_chroma+0x86>
   20431:	41 8b 16             	mov    (%r14),%edx
   20434:	89 d6                	mov    %edx,%esi
   20436:	81 e6 ff ff ff 7f    	and    $0x7fffffff,%esi
   2043c:	b8 0d 00 00 00       	mov    $0xd,%eax
   20441:	31 c9                	xor    %ecx,%ecx
   20443:	81 fe ff ff 7f 7f    	cmp    $0x7f7fffff,%esi
   20449:	7e 1d                	jle    20468 <<gpui_canvas::color::Color>::fit_chroma+0x98>
   2044b:	89 43 04             	mov    %eax,0x4(%rbx)
   2044e:	89 4b 08             	mov    %ecx,0x8(%rbx)
   20451:	b8 01 00 00 00       	mov    $0x1,%eax
   20456:	89 03                	mov    %eax,(%rbx)
   20458:	48 89 d8             	mov    %rbx,%rax
   2045b:	48 83 c4 30          	add    $0x30,%rsp
   2045f:	5b                   	pop    %rbx
   20460:	41 5c                	pop    %r12
   20462:	41 5e                	pop    %r14
   20464:	41 5f                	pop    %r15
   20466:	5d                   	pop    %rbp
   20467:	c3                   	ret
   20468:	44 89 e6             	mov    %r12d,%esi
   2046b:	81 e6 ff ff ff 7f    	and    $0x7fffffff,%esi
   20471:	66 0f 6e c6          	movd   %esi,%xmm0
   20475:	0f 2e 05 54 54 fe ff 	ucomiss -0x1abac(%rip),%xmm0        # 58d0 <std::thread::current::id::ID+0x4c58>
   2047c:	74 cd                	je     2044b <<gpui_canvas::color::Color>::fit_chroma+0x7b>
   2047e:	66 0f 6e d2          	movd   %edx,%xmm2
   20482:	0f 57 c9             	xorps  %xmm1,%xmm1
   20485:	0f 2e d1             	ucomiss %xmm1,%xmm2
   20488:	72 c1                	jb     2044b <<gpui_canvas::color::Color>::fit_chroma+0x7b>
   2048a:	f3 0f 10 0d 06 54 fe 	movss  -0x1abfa(%rip),%xmm1        # 5898 <std::thread::current::id::ID+0x4c20>
   20491:	ff 
   20492:	0f 2e ca             	ucomiss %xmm2,%xmm1
   20495:	72 b4                	jb     2044b <<gpui_canvas::color::Color>::fit_chroma+0x7b>
   20497:	f3 41 0f 10 5e 04    	movss  0x4(%r14),%xmm3
   2049d:	31 c9                	xor    %ecx,%ecx
   2049f:	0f 57 c9             	xorps  %xmm1,%xmm1
   204a2:	0f 2e d1             	ucomiss %xmm1,%xmm2
   204a5:	f3 0f 11 54 24 0c    	movss  %xmm2,0xc(%rsp)
   204ab:	75 02                	jne    204af <<gpui_canvas::color::Color>::fit_chroma+0xdf>
   204ad:	7b 63                	jnp    20512 <<gpui_canvas::color::Color>::fit_chroma+0x142>
   204af:	0f 2e 15 e2 53 fe ff 	ucomiss -0x1ac1e(%rip),%xmm2        # 5898 <std::thread::current::id::ID+0x4c20>
   204b6:	75 02                	jne    204ba <<gpui_canvas::color::Color>::fit_chroma+0xea>
   204b8:	7b 58                	jnp    20512 <<gpui_canvas::color::Color>::fit_chroma+0x142>
   204ba:	0f 29 5c 24 20       	movaps %xmm3,0x20(%rsp)
   204bf:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   204c3:	f2 0f 10 0d cd 6e fe 	movsd  -0x19133(%rip),%xmm1        # 7398 <std::thread::current::id::ID+0x6720>
   204ca:	ff 
   204cb:	ff 15 17 52 04 00    	call   *0x45217(%rip)        # 656e8 <_DYNAMIC+0x370>
   204d1:	66 0f 2e 05 f7 6d fe 	ucomisd -0x19209(%rip),%xmm0        # 72d0 <std::thread::current::id::ID+0x6658>
   204d8:	ff 
   204d9:	0f 57 c9             	xorps  %xmm1,%xmm1
   204dc:	73 0c                	jae    204ea <<gpui_canvas::color::Color>::fit_chroma+0x11a>
   204de:	f2 0f 5a c0          	cvtsd2ss %xmm0,%xmm0
   204e2:	f3 0f c2 c8 00       	cmpeqss %xmm0,%xmm1
   204e7:	0f 55 c8             	andnps %xmm0,%xmm1
   204ea:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   204f0:	89 ef                	mov    %ebp,%edi
   204f2:	e8 a9 14 00 00       	call   219a0 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>>
   204f7:	f3 0f 10 54 24 0c    	movss  0xc(%rsp),%xmm2
   204fd:	48 89 c1             	mov    %rax,%rcx
   20500:	48 c1 e9 20          	shr    $0x20,%rcx
   20504:	83 f8 ff             	cmp    $0xffffffff,%eax
   20507:	0f 28 5c 24 20       	movaps 0x20(%rsp),%xmm3
   2050c:	0f 85 39 ff ff ff    	jne    2044b <<gpui_canvas::color::Color>::fit_chroma+0x7b>
   20512:	66 0f 6e c1          	movd   %ecx,%xmm0
   20516:	0f 28 cb             	movaps %xmm3,%xmm1
   20519:	f3 0f 5d c8          	minss  %xmm0,%xmm1
   2051d:	0f 28 e1             	movaps %xmm1,%xmm4
   20520:	f3 0f c2 e1 03       	cmpunordss %xmm1,%xmm4
   20525:	0f 28 c4             	movaps %xmm4,%xmm0
   20528:	0f 55 c1             	andnps %xmm1,%xmm0
   2052b:	0f 54 e3             	andps  %xmm3,%xmm4
   2052e:	0f 56 e0             	orps   %xmm0,%xmm4
   20531:	f3 0f 11 54 24 10    	movss  %xmm2,0x10(%rsp)
   20537:	0f 29 64 24 20       	movaps %xmm4,0x20(%rsp)
   2053c:	f3 0f 11 64 24 14    	movss  %xmm4,0x14(%rsp)
   20542:	44 89 64 24 18       	mov    %r12d,0x18(%rsp)
   20547:	44 89 7c 24 1c       	mov    %r15d,0x1c(%rsp)
   2054c:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   20551:	89 ee                	mov    %ebp,%esi
   20553:	e8 e8 21 00 00       	call   22740 <gpui_canvas::color::gamut::in_gamut>
   20558:	84 c0                	test   %al,%al
   2055a:	74 24                	je     20580 <<gpui_canvas::color::Color>::fit_chroma+0x1b0>
   2055c:	0f 28 44 24 20       	movaps 0x20(%rsp),%xmm0
   20561:	f3 0f 11 43 08       	movss  %xmm0,0x8(%rbx)
   20566:	44 89 63 0c          	mov    %r12d,0xc(%rbx)
   2056a:	44 89 7b 10          	mov    %r15d,0x10(%rbx)
   2056e:	31 c0                	xor    %eax,%eax
   20570:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   20576:	f3 0f 11 43 04       	movss  %xmm0,0x4(%rbx)
   2057b:	e9 d6 fe ff ff       	jmp    20456 <<gpui_canvas::color::Color>::fit_chroma+0x86>
   20580:	b8 01 00 00 00       	mov    $0x1,%eax
   20585:	f3 0f 10 05 03 53 fe 	movss  -0x1acfd(%rip),%xmm0        # 5890 <std::thread::current::id::ID+0x4c18>
   2058c:	ff 
   2058d:	f3 0f 11 43 04       	movss  %xmm0,0x4(%rbx)
   20592:	e9 bf fe ff ff       	jmp    20456 <<gpui_canvas::color::Color>::fit_chroma+0x86>
   20597:	cc                   	int3
   20598:	cc                   	int3
   20599:	cc                   	int3
   2059a:	cc                   	int3
   2059b:	cc                   	int3
   2059c:	cc                   	int3
   2059d:	cc                   	int3
   2059e:	cc                   	int3
   2059f:	cc                   	int3

<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, usize, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>:
   20aa0:	55                   	push   %rbp
   20aa1:	48 89 e5             	mov    %rsp,%rbp
   20aa4:	41 57                	push   %r15
   20aa6:	41 56                	push   %r14
   20aa8:	53                   	push   %rbx
   20aa9:	48 83 e4 e0          	and    $0xffffffffffffffe0,%rsp
   20aad:	48 81 ec 40 04 00 00 	sub    $0x440,%rsp
   20ab4:	0f 28 42 20          	movaps 0x20(%rdx),%xmm0
   20ab8:	66 0f 28 4a 30       	movapd 0x30(%rdx),%xmm1
   20abd:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
   20ac4:	00 
   20ac5:	66 0f 29 8c 24 50 03 	movapd %xmm1,0x350(%rsp)
   20acc:	00 00 
   20ace:	0f 28 12             	movaps (%rdx),%xmm2
   20ad1:	0f 29 94 24 20 03 00 	movaps %xmm2,0x320(%rsp)
   20ad8:	00 
   20ad9:	0f 28 5a 10          	movaps 0x10(%rdx),%xmm3
   20add:	0f 29 9c 24 30 03 00 	movaps %xmm3,0x330(%rsp)
   20ae4:	00 
   20ae5:	0f 29 94 24 f0 03 00 	movaps %xmm2,0x3f0(%rsp)
   20aec:	00 
   20aed:	0f 29 9c 24 00 04 00 	movaps %xmm3,0x400(%rsp)
   20af4:	00 
   20af5:	0f 29 84 24 10 04 00 	movaps %xmm0,0x410(%rsp)
   20afc:	00 
   20afd:	66 0f 29 8c 24 20 04 	movapd %xmm1,0x420(%rsp)
   20b04:	00 00 
   20b06:	66 0f 29 8c 24 b0 03 	movapd %xmm1,0x3b0(%rsp)
   20b0d:	00 00 
   20b0f:	0f 29 84 24 a0 03 00 	movaps %xmm0,0x3a0(%rsp)
   20b16:	00 
   20b17:	0f 29 9c 24 90 03 00 	movaps %xmm3,0x390(%rsp)
   20b1e:	00 
   20b1f:	0f 29 94 24 80 03 00 	movaps %xmm2,0x380(%rsp)
   20b26:	00 
   20b27:	0f 28 84 24 e0 03 00 	movaps 0x3e0(%rsp),%xmm0
   20b2e:	00 
   20b2f:	0f 29 84 24 70 03 00 	movaps %xmm0,0x370(%rsp)
   20b36:	00 
   20b37:	66 0f 28 05 11 4c fe 	movapd -0x1b3ef(%rip),%xmm0        # 5750 <std::thread::current::id::ID+0x4ad8>
   20b3e:	ff 
   20b3f:	66 0f 29 84 24 c0 03 	movapd %xmm0,0x3c0(%rsp)
   20b46:	00 00 
   20b48:	66 0f 29 84 24 d0 03 	movapd %xmm0,0x3d0(%rsp)
   20b4f:	00 00 
   20b51:	48 8d 84 24 80 03 00 	lea    0x380(%rsp),%rax
   20b58:	00 
   20b59:	66 44 0f 28 1e       	movapd (%rsi),%xmm11
   20b5e:	66 44 0f 28 46 10    	movapd 0x10(%rsi),%xmm8
   20b64:	66 44 0f 28 56 20    	movapd 0x20(%rsi),%xmm10
   20b6a:	66 0f 28 66 60       	movapd 0x60(%rsi),%xmm4
   20b6f:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   20b73:	66 0f c2 cc 05       	cmpnltpd %xmm4,%xmm1
   20b78:	66 0f 54 c8          	andpd  %xmm0,%xmm1
   20b7c:	66 0f 29 4c 24 40    	movapd %xmm1,0x40(%rsp)
   20b82:	66 0f 28 0d 66 48 fe 	movapd -0x1b79a(%rip),%xmm1        # 53f0 <std::thread::current::id::ID+0x4778>
   20b89:	ff 
   20b8a:	66 41 0f 28 d3       	movapd %xmm11,%xmm2
   20b8f:	66 0f 59 d1          	mulpd  %xmm1,%xmm2
   20b93:	66 0f 29 94 24 d0 01 	movapd %xmm2,0x1d0(%rsp)
   20b9a:	00 00 
   20b9c:	66 41 0f 28 d2       	movapd %xmm10,%xmm2
   20ba1:	66 41 0f 58 d2       	addpd  %xmm10,%xmm2
   20ba6:	66 0f 29 94 24 c0 01 	movapd %xmm2,0x1c0(%rsp)
   20bad:	00 00 
   20baf:	66 0f 28 15 69 46 fe 	movapd -0x1b997(%rip),%xmm2        # 5220 <std::thread::current::id::ID+0x45a8>
   20bb6:	ff 
   20bb7:	66 41 0f 28 db       	movapd %xmm11,%xmm3
   20bbc:	66 0f 54 da          	andpd  %xmm2,%xmm3
   20bc0:	66 0f 29 9c 24 10 01 	movapd %xmm3,0x110(%rsp)
   20bc7:	00 00 
   20bc9:	66 0f 59 d9          	mulpd  %xmm1,%xmm3
   20bcd:	66 0f 29 9c 24 b0 01 	movapd %xmm3,0x1b0(%rsp)
   20bd4:	00 00 
   20bd6:	66 41 0f 28 da       	movapd %xmm10,%xmm3
   20bdb:	66 0f 54 da          	andpd  %xmm2,%xmm3
   20bdf:	66 44 0f 28 6e 70    	movapd 0x70(%rsi),%xmm13
   20be5:	66 0f 57 ed          	xorpd  %xmm5,%xmm5
   20be9:	66 41 0f c2 ed 05    	cmpnltpd %xmm13,%xmm5
   20bef:	66 0f 54 e8          	andpd  %xmm0,%xmm5
   20bf3:	66 0f 29 6c 24 30    	movapd %xmm5,0x30(%rsp)
   20bf9:	66 41 0f 28 e8       	movapd %xmm8,%xmm5
   20bfe:	66 0f 59 e9          	mulpd  %xmm1,%xmm5
   20c02:	66 44 0f 28 76 30    	movapd 0x30(%rsi),%xmm14
   20c08:	66 41 0f 28 f6       	movapd %xmm14,%xmm6
   20c0d:	66 41 0f 58 f6       	addpd  %xmm14,%xmm6
   20c12:	66 41 0f 28 f8       	movapd %xmm8,%xmm7
   20c17:	66 0f 54 fa          	andpd  %xmm2,%xmm7
   20c1b:	66 0f 29 bc 24 70 02 	movapd %xmm7,0x270(%rsp)
   20c22:	00 00 
   20c24:	66 0f 59 cf          	mulpd  %xmm7,%xmm1
   20c28:	66 41 0f 28 fe       	movapd %xmm14,%xmm7
   20c2d:	66 0f 54 fa          	andpd  %xmm2,%xmm7
   20c31:	66 0f 29 9c 24 a0 02 	movapd %xmm3,0x2a0(%rsp)
   20c38:	00 00 
   20c3a:	66 0f 58 db          	addpd  %xmm3,%xmm3
   20c3e:	66 0f 29 9c 24 a0 01 	movapd %xmm3,0x1a0(%rsp)
   20c45:	00 00 
   20c47:	66 0f 29 bc 24 60 02 	movapd %xmm7,0x260(%rsp)
   20c4e:	00 00 
   20c50:	66 0f 58 ff          	addpd  %xmm7,%xmm7
   20c54:	66 44 0f 28 7e 40    	movapd 0x40(%rsi),%xmm15
   20c5a:	66 41 0f 28 df       	movapd %xmm15,%xmm3
   20c5f:	66 0f 54 da          	andpd  %xmm2,%xmm3
   20c63:	66 0f 29 9c 24 90 01 	movapd %xmm3,0x190(%rsp)
   20c6a:	00 00 
   20c6c:	66 44 0f 28 66 50    	movapd 0x50(%rsi),%xmm12
   20c72:	66 41 0f 28 dc       	movapd %xmm12,%xmm3
   20c77:	66 0f 54 da          	andpd  %xmm2,%xmm3
   20c7b:	66 44 0f 28 cc       	movapd %xmm4,%xmm9
   20c80:	66 44 0f 54 ca       	andpd  %xmm2,%xmm9
   20c85:	66 44 0f 29 8c 24 30 	movapd %xmm9,0x230(%rsp)
   20c8c:	02 00 00 
   20c8f:	66 45 0f 28 cd       	movapd %xmm13,%xmm9
   20c94:	66 44 0f 54 ca       	andpd  %xmm2,%xmm9
   20c99:	66 44 0f 29 8c 24 20 	movapd %xmm9,0x220(%rsp)
   20ca0:	02 00 00 
   20ca3:	66 45 0f 28 cd       	movapd %xmm13,%xmm9
   20ca8:	66 41 0f 28 d4       	movapd %xmm12,%xmm2
   20cad:	66 41 0f c6 d4 01    	shufpd $0x1,%xmm12,%xmm2
   20cb3:	66 0f 29 94 24 10 03 	movapd %xmm2,0x310(%rsp)
   20cba:	00 00 
   20cbc:	66 0f 29 b4 24 80 02 	movapd %xmm6,0x280(%rsp)
   20cc3:	00 00 
   20cc5:	66 0f c6 f6 01       	shufpd $0x1,%xmm6,%xmm6
   20cca:	66 0f 29 b4 24 00 03 	movapd %xmm6,0x300(%rsp)
   20cd1:	00 00 
   20cd3:	66 0f 29 ac 24 90 02 	movapd %xmm5,0x290(%rsp)
   20cda:	00 00 
   20cdc:	66 0f c6 ed 01       	shufpd $0x1,%xmm5,%xmm5
   20ce1:	66 0f 29 ac 24 f0 02 	movapd %xmm5,0x2f0(%rsp)
   20ce8:	00 00 
   20cea:	66 0f 29 bc 24 50 02 	movapd %xmm7,0x250(%rsp)
   20cf1:	00 00 
   20cf3:	66 0f c6 ff 01       	shufpd $0x1,%xmm7,%xmm7
   20cf8:	66 0f 29 bc 24 e0 02 	movapd %xmm7,0x2e0(%rsp)
   20cff:	00 00 
   20d01:	66 0f 29 8c 24 b0 02 	movapd %xmm1,0x2b0(%rsp)
   20d08:	00 00 
   20d0a:	66 0f c6 c9 01       	shufpd $0x1,%xmm1,%xmm1
   20d0f:	66 0f 29 8c 24 d0 02 	movapd %xmm1,0x2d0(%rsp)
   20d16:	00 00 
   20d18:	31 d2                	xor    %edx,%edx
   20d1a:	be 01 00 00 00       	mov    $0x1,%esi
   20d1f:	0f 28 09             	movaps (%rcx),%xmm1
   20d22:	0f 29 8c 24 10 02 00 	movaps %xmm1,0x210(%rsp)
   20d29:	00 
   20d2a:	0f 28 49 10          	movaps 0x10(%rcx),%xmm1
   20d2e:	0f 29 8c 24 00 01 00 	movaps %xmm1,0x100(%rsp)
   20d35:	00 
   20d36:	66 0f 29 9c 24 40 02 	movapd %xmm3,0x240(%rsp)
   20d3d:	00 00 
   20d3f:	66 0f 70 cb 4e       	pshufd $0x4e,%xmm3,%xmm1
   20d44:	66 0f 7f 8c 24 c0 02 	movdqa %xmm1,0x2c0(%rsp)
   20d4b:	00 00 
   20d4d:	66 45 0f 57 ed       	xorpd  %xmm13,%xmm13
   20d52:	66 0f 28 c8          	movapd %xmm0,%xmm1
   20d56:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   20d5a:	66 0f 29 44 24 50    	movapd %xmm0,0x50(%rsp)
   20d60:	66 44 0f 29 9c 24 f0 	movapd %xmm11,0xf0(%rsp)
   20d67:	00 00 00 
   20d6a:	66 44 0f 29 84 24 80 	movapd %xmm8,0x180(%rsp)
   20d71:	01 00 00 
   20d74:	66 44 0f 29 94 24 70 	movapd %xmm10,0x170(%rsp)
   20d7b:	01 00 00 
   20d7e:	66 0f 29 a4 24 e0 00 	movapd %xmm4,0xe0(%rsp)
   20d85:	00 00 
   20d87:	66 44 0f 29 8c 24 60 	movapd %xmm9,0x160(%rsp)
   20d8e:	01 00 00 
   20d91:	66 44 0f 29 b4 24 50 	movapd %xmm14,0x150(%rsp)
   20d98:	01 00 00 
   20d9b:	66 44 0f 29 bc 24 d0 	movapd %xmm15,0xd0(%rsp)
   20da2:	00 00 00 
   20da5:	66 44 0f 29 a4 24 40 	movapd %xmm12,0x140(%rsp)
   20dac:	01 00 00 
   20daf:	eb 7f                	jmp    20e30 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, usize, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>+0x390>
   20db1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   20db8:	0f 1f 84 00 00 00 00 
   20dbf:	00 
   20dc0:	66 0f 28 9c 24 90 00 	movapd 0x90(%rsp),%xmm3
   20dc7:	00 00 
   20dc9:	48 ff c2             	inc    %rdx
   20dcc:	66 0f 28 84 24 c0 00 	movapd 0xc0(%rsp),%xmm0
   20dd3:	00 00 
   20dd5:	66 0f 55 84 24 20 01 	andnpd 0x120(%rsp),%xmm0
   20ddc:	00 00 
   20dde:	66 0f 28 8c 24 b0 00 	movapd 0xb0(%rsp),%xmm1
   20de5:	00 00 
   20de7:	66 0f 54 4c 24 10    	andpd  0x10(%rsp),%xmm1
   20ded:	66 0f 54 c1          	andpd  %xmm1,%xmm0
   20df1:	66 0f 55 cb          	andnpd %xmm3,%xmm1
   20df5:	66 0f 56 c8          	orpd   %xmm0,%xmm1
   20df9:	66 0f 28 5c 24 60    	movapd 0x60(%rsp),%xmm3
   20dff:	66 0f 55 9c 24 30 01 	andnpd 0x130(%rsp),%xmm3
   20e06:	00 00 
   20e08:	66 0f 54 74 24 20    	andpd  0x20(%rsp),%xmm6
   20e0e:	66 0f 54 de          	andpd  %xmm6,%xmm3
   20e12:	66 0f 55 74 24 50    	andnpd 0x50(%rsp),%xmm6
   20e18:	66 0f 28 c6          	movapd %xmm6,%xmm0
   20e1c:	66 0f 56 c3          	orpd   %xmm3,%xmm0
   20e20:	66 0f 29 44 24 50    	movapd %xmm0,0x50(%rsp)
   20e26:	48 83 fa 03          	cmp    $0x3,%rdx
   20e2a:	0f 84 44 0b 00 00    	je     21974 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, usize, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>+0xed4>
   20e30:	66 0f 29 8c 24 90 00 	movapd %xmm1,0x90(%rsp)
   20e37:	00 00 
   20e39:	66 0f 29 94 24 30 01 	movapd %xmm2,0x130(%rsp)
   20e40:	00 00 
   20e42:	66 44 0f 29 ac 24 20 	movapd %xmm13,0x120(%rsp)
   20e49:	01 00 00 
   20e4c:	48 89 d1             	mov    %rdx,%rcx
   20e4f:	48 c1 e1 05          	shl    $0x5,%rcx
   20e53:	66 0f 28 24 08       	movapd (%rax,%rcx,1),%xmm4
   20e58:	66 0f 28 5c 08 10    	movapd 0x10(%rax,%rcx,1),%xmm3
   20e5e:	66 0f 28 c3          	movapd %xmm3,%xmm0
   20e62:	66 0f 15 c3          	unpckhpd %xmm3,%xmm0
   20e66:	66 0f 28 d4          	movapd %xmm4,%xmm2
   20e6a:	66 44 0f 28 05 dd 48 	movapd -0x1b723(%rip),%xmm8        # 5750 <std::thread::current::id::ID+0x4ad8>
   20e71:	fe ff 
   20e73:	66 41 0f c2 d0 04    	cmpneqpd %xmm8,%xmm2
   20e79:	66 0f 28 ec          	movapd %xmm4,%xmm5
   20e7d:	66 41 0f c2 e8 07    	cmpordpd %xmm8,%xmm5
   20e83:	66 0f 54 ea          	andpd  %xmm2,%xmm5
   20e87:	66 0f 28 fd          	movapd %xmm5,%xmm7
   20e8b:	31 c9                	xor    %ecx,%ecx
   20e8d:	f2 0f 10 0d 53 63 fe 	movsd  -0x19cad(%rip),%xmm1        # 71e8 <std::thread::current::id::ID+0x6570>
   20e94:	ff 
   20e95:	66 0f 2e d9          	ucomisd %xmm1,%xmm3
   20e99:	0f 95 c1             	setne  %cl
   20e9c:	45 31 c9             	xor    %r9d,%r9d
   20e9f:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
   20ea3:	41 0f 94 c1          	sete   %r9b
   20ea7:	66 0f 6e c1          	movd   %ecx,%xmm0
   20eab:	66 41 0f c4 c1 04    	pinsrw $0x4,%r9d,%xmm0
   20eb1:	66 0f 29 64 24 70    	movapd %xmm4,0x70(%rsp)
   20eb7:	66 0f 54 fc          	andpd  %xmm4,%xmm7
   20ebb:	66 0f 70 c8 a0       	pshufd $0xa0,%xmm0,%xmm1
   20ec0:	66 0f 72 f1 1f       	pslld  $0x1f,%xmm1
   20ec5:	66 0f 72 e1 1f       	psrad  $0x1f,%xmm1
   20eca:	f3 44 0f 7e cb       	movq   %xmm3,%xmm9
   20ecf:	66 0f ef c0          	pxor   %xmm0,%xmm0
   20ed3:	0f 29 5c 24 60       	movaps %xmm3,0x60(%rsp)
   20ed8:	66 0f c6 c3 02       	shufpd $0x2,%xmm3,%xmm0
   20edd:	66 0f 6f d1          	movdqa %xmm1,%xmm2
   20ee1:	66 0f df d0          	pandn  %xmm0,%xmm2
   20ee5:	66 0f 7f 8c 24 80 00 	movdqa %xmm1,0x80(%rsp)
   20eec:	00 00 
   20eee:	66 44 0f db c9       	pand   %xmm1,%xmm9
   20ef3:	66 44 0f eb ca       	por    %xmm2,%xmm9
   20ef8:	66 44 0f 7f 8c 24 b0 	movdqa %xmm9,0xb0(%rsp)
   20eff:	00 00 00 
   20f02:	66 0f 6f 05 16 43 fe 	movdqa -0x1bcea(%rip),%xmm0        # 5220 <std::thread::current::id::ID+0x45a8>
   20f09:	ff 
   20f0a:	66 44 0f db c8       	pand   %xmm0,%xmm9
   20f0f:	66 0f 28 0d 89 47 fe 	movapd -0x1b877(%rip),%xmm1        # 56a0 <std::thread::current::id::ID+0x4a28>
   20f16:	ff 
   20f17:	66 44 0f 58 c9       	addpd  %xmm1,%xmm9
   20f1c:	66 0f 29 bc 24 c0 00 	movapd %xmm7,0xc0(%rsp)
   20f23:	00 00 
   20f25:	66 0f 54 f8          	andpd  %xmm0,%xmm7
   20f29:	66 0f 58 f9          	addpd  %xmm1,%xmm7
   20f2d:	66 0f 28 05 fb 45 fe 	movapd -0x1ba05(%rip),%xmm0        # 5530 <std::thread::current::id::ID+0x48b8>
   20f34:	ff 
   20f35:	66 0f 59 f8          	mulpd  %xmm0,%xmm7
   20f39:	66 44 0f 59 c8       	mulpd  %xmm0,%xmm9
   20f3e:	66 41 0f 6e c1       	movd   %r9d,%xmm0
   20f43:	66 0f c4 c1 04       	pinsrw $0x4,%ecx,%xmm0
   20f48:	66 0f 7f 84 24 a0 00 	movdqa %xmm0,0xa0(%rsp)
   20f4f:	00 00 
   20f51:	66 0f 29 6c 24 10    	movapd %xmm5,0x10(%rsp)
   20f57:	66 0f 29 ac 24 e0 01 	movapd %xmm5,0x1e0(%rsp)
   20f5e:	00 00 
   20f60:	0f b6 8c 24 e0 01 00 	movzbl 0x1e0(%rsp),%ecx
   20f67:	00 
   20f68:	44 0f b6 8c 24 e8 01 	movzbl 0x1e8(%rsp),%r9d
   20f6f:	00 00 
   20f71:	41 ba 1f 00 00 00    	mov    $0x1f,%r10d
   20f77:	66 45 0f 28 e0       	movapd %xmm8,%xmm12
   20f7c:	0f 1f 40 00          	nopl   0x0(%rax)
   20f80:	66 44 0f 29 4c 24 20 	movapd %xmm9,0x20(%rsp)
   20f87:	66 44 0f 28 5c 24 20 	movapd 0x20(%rsp),%xmm11
   20f8e:	f2 0f 10 0d 52 62 fe 	movsd  -0x19dae(%rip),%xmm1        # 71e8 <std::thread::current::id::ID+0x6570>
   20f95:	ff 
   20f96:	66 0f 28 44 24 60    	movapd 0x60(%rsp),%xmm0
   20f9c:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
   20fa0:	66 0f 28 f7          	movapd %xmm7,%xmm6
   20fa4:	66 0f 28 c7          	movapd %xmm7,%xmm0
   20fa8:	41 0f 95 c3          	setne  %r11b
   20fac:	66 45 0f 28 e8       	movapd %xmm8,%xmm13
   20fb1:	66 41 0f 28 e4       	movapd %xmm12,%xmm4
   20fb6:	66 41 0f 15 e4       	unpckhpd %xmm12,%xmm4
   20fbb:	31 db                	xor    %ebx,%ebx
   20fbd:	66 0f 2e e1          	ucomisd %xmm1,%xmm4
   20fc1:	66 44 0f c2 2d 85 47 	cmpeqpd -0x1b87b(%rip),%xmm13        # 5750 <std::thread::current::id::ID+0x4ad8>
   20fc8:	fe ff 00 
   20fcb:	66 0f 58 f7          	addpd  %xmm7,%xmm6
   20fcf:	66 0f 28 8c 24 c0 00 	movapd 0xc0(%rsp),%xmm1
   20fd6:	00 00 
   20fd8:	66 44 0f 28 f1       	movapd %xmm1,%xmm14
   20fdd:	66 44 0f 5c f7       	subpd  %xmm7,%xmm14
   20fe2:	66 0f ef d2          	pxor   %xmm2,%xmm2
   20fe6:	66 44 0f 5f f2       	maxpd  %xmm2,%xmm14
   20feb:	66 0f 58 c1          	addpd  %xmm1,%xmm0
   20fef:	66 0f 28 ac 24 d0 01 	movapd 0x1d0(%rsp),%xmm5
   20ff6:	00 00 
   20ff8:	66 44 0f 28 d5       	movapd %xmm5,%xmm10
   20ffd:	66 45 0f 59 d6       	mulpd  %xmm14,%xmm10
   21002:	66 0f 28 8c 24 c0 01 	movapd 0x1c0(%rsp),%xmm1
   21009:	00 00 
   2100b:	66 44 0f 58 d1       	addpd  %xmm1,%xmm10
   21010:	66 45 0f 59 d6       	mulpd  %xmm14,%xmm10
   21015:	66 0f 28 9c 24 d0 00 	movapd 0xd0(%rsp),%xmm3
   2101c:	00 00 
   2101e:	66 44 0f 58 d3       	addpd  %xmm3,%xmm10
   21023:	66 44 0f 28 bc 24 b0 	movapd 0x1b0(%rsp),%xmm15
   2102a:	01 00 00 
   2102d:	66 41 0f 28 e7       	movapd %xmm15,%xmm4
   21032:	66 41 0f 59 e6       	mulpd  %xmm14,%xmm4
   21037:	66 0f 28 bc 24 a0 01 	movapd 0x1a0(%rsp),%xmm7
   2103e:	00 00 
   21040:	66 0f 58 e7          	addpd  %xmm7,%xmm4
   21044:	66 41 0f 59 e6       	mulpd  %xmm14,%xmm4
   21049:	66 0f 28 94 24 90 01 	movapd 0x190(%rsp),%xmm2
   21050:	00 00 
   21052:	66 0f 58 e2          	addpd  %xmm2,%xmm4
   21056:	66 44 0f 28 0d d1 44 	movapd -0x1bb2f(%rip),%xmm9        # 5530 <std::thread::current::id::ID+0x48b8>
   2105d:	fe ff 
   2105f:	66 41 0f 59 e1       	mulpd  %xmm9,%xmm4
   21064:	66 44 0f 28 f5       	movapd %xmm5,%xmm14
   21069:	66 44 0f 59 f0       	mulpd  %xmm0,%xmm14
   2106e:	66 44 0f 58 f1       	addpd  %xmm1,%xmm14
   21073:	66 44 0f 59 f0       	mulpd  %xmm0,%xmm14
   21078:	66 44 0f 58 f3       	addpd  %xmm3,%xmm14
   2107d:	66 41 0f 28 ef       	movapd %xmm15,%xmm5
   21082:	66 0f 59 e8          	mulpd  %xmm0,%xmm5
   21086:	66 0f 58 ef          	addpd  %xmm7,%xmm5
   2108a:	66 0f 59 e8          	mulpd  %xmm0,%xmm5
   2108e:	66 0f 58 ea          	addpd  %xmm2,%xmm5
   21092:	66 41 0f 59 e9       	mulpd  %xmm9,%xmm5
   21097:	66 0f 28 c4          	movapd %xmm4,%xmm0
   2109b:	66 44 0f 28 3d ec 46 	movapd -0x1b914(%rip),%xmm15        # 5790 <std::thread::current::id::ID+0x4b18>
   210a2:	fe ff 
   210a4:	66 41 0f 57 c7       	xorpd  %xmm15,%xmm0
   210a9:	66 41 0f c2 e2 01    	cmpltpd %xmm10,%xmm4
   210af:	66 44 0f c2 d0 01    	cmpltpd %xmm0,%xmm10
   210b5:	66 0f 28 c5          	movapd %xmm5,%xmm0
   210b9:	66 41 0f c2 c6 01    	cmpltpd %xmm14,%xmm0
   210bf:	66 41 0f 54 c2       	andpd  %xmm10,%xmm0
   210c4:	66 41 0f 57 ef       	xorpd  %xmm15,%xmm5
   210c9:	66 44 0f c2 f5 01    	cmpltpd %xmm5,%xmm14
   210cf:	66 44 0f 54 f4       	andpd  %xmm4,%xmm14
   210d4:	66 44 0f 56 f0       	orpd   %xmm0,%xmm14
   210d9:	66 45 0f 54 f5       	andpd  %xmm13,%xmm14
   210de:	66 44 0f 54 74 24 10 	andpd  0x10(%rsp),%xmm14
   210e5:	66 0f 28 fe          	movapd %xmm6,%xmm7
   210e9:	66 41 0f 54 f6       	andpd  %xmm14,%xmm6
   210ee:	66 45 0f 55 f0       	andnpd %xmm8,%xmm14
   210f3:	66 45 0f 28 c6       	movapd %xmm14,%xmm8
   210f8:	66 44 0f 56 c6       	orpd   %xmm6,%xmm8
   210fd:	66 0f 28 84 24 b0 00 	movapd 0xb0(%rsp),%xmm0
   21104:	00 00 
   21106:	66 0f 28 e0          	movapd %xmm0,%xmm4
   2110a:	66 41 0f 5c e3       	subpd  %xmm11,%xmm4
   2110f:	66 0f c6 e4 01       	shufpd $0x1,%xmm4,%xmm4
   21114:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   21118:	66 0f 5f e1          	maxpd  %xmm1,%xmm4
   2111c:	66 44 0f 58 d8       	addpd  %xmm0,%xmm11
   21121:	66 45 0f c6 db 01    	shufpd $0x1,%xmm11,%xmm11
   21127:	66 44 0f 28 ac 24 f0 	movapd 0x2f0(%rsp),%xmm13
   2112e:	02 00 00 
   21131:	66 45 0f 28 d5       	movapd %xmm13,%xmm10
   21136:	66 44 0f 59 d4       	mulpd  %xmm4,%xmm10
   2113b:	66 0f 28 94 24 00 03 	movapd 0x300(%rsp),%xmm2
   21142:	00 00 
   21144:	66 44 0f 58 d2       	addpd  %xmm2,%xmm10
   21149:	66 44 0f 59 d4       	mulpd  %xmm4,%xmm10
   2114e:	66 0f 28 8c 24 10 03 	movapd 0x310(%rsp),%xmm1
   21155:	00 00 
   21157:	66 44 0f 58 d1       	addpd  %xmm1,%xmm10
   2115c:	66 44 0f 28 b4 24 d0 	movapd 0x2d0(%rsp),%xmm14
   21163:	02 00 00 
   21166:	66 41 0f 28 c6       	movapd %xmm14,%xmm0
   2116b:	66 0f 59 c4          	mulpd  %xmm4,%xmm0
   2116f:	66 0f 28 9c 24 e0 02 	movapd 0x2e0(%rsp),%xmm3
   21176:	00 00 
   21178:	66 0f 58 c3          	addpd  %xmm3,%xmm0
   2117c:	66 0f 59 c4          	mulpd  %xmm4,%xmm0
   21180:	66 0f 28 a4 24 c0 02 	movapd 0x2c0(%rsp),%xmm4
   21187:	00 00 
   21189:	66 0f 58 c4          	addpd  %xmm4,%xmm0
   2118d:	66 41 0f 59 c1       	mulpd  %xmm9,%xmm0
   21192:	66 45 0f 59 eb       	mulpd  %xmm11,%xmm13
   21197:	66 44 0f 58 ea       	addpd  %xmm2,%xmm13
   2119c:	66 45 0f 59 eb       	mulpd  %xmm11,%xmm13
   211a1:	66 44 0f 58 e9       	addpd  %xmm1,%xmm13
   211a6:	66 45 0f 59 f3       	mulpd  %xmm11,%xmm14
   211ab:	66 44 0f 58 f3       	addpd  %xmm3,%xmm14
   211b0:	66 45 0f 59 f3       	mulpd  %xmm11,%xmm14
   211b5:	66 44 0f 58 f4       	addpd  %xmm4,%xmm14
   211ba:	66 45 0f 59 f1       	mulpd  %xmm9,%xmm14
   211bf:	66 0f 28 e0          	movapd %xmm0,%xmm4
   211c3:	66 41 0f 57 e7       	xorpd  %xmm15,%xmm4
   211c8:	66 41 0f 28 ea       	movapd %xmm10,%xmm5
   211cd:	66 44 0f 28 d8       	movapd %xmm0,%xmm11
   211d2:	66 45 0f c2 da 05    	cmpnltpd %xmm10,%xmm11
   211d8:	66 41 0f c2 c2 01    	cmpltpd %xmm10,%xmm0
   211de:	66 44 0f c2 d4 05    	cmpnltpd %xmm4,%xmm10
   211e4:	66 0f c2 ec 01       	cmpltpd %xmm4,%xmm5
   211e9:	66 41 0f 28 e6       	movapd %xmm14,%xmm4
   211ee:	66 41 0f c2 e5 05    	cmpnltpd %xmm13,%xmm4
   211f4:	66 41 0f 56 e2       	orpd   %xmm10,%xmm4
   211f9:	66 45 0f 28 d6       	movapd %xmm14,%xmm10
   211fe:	66 45 0f c2 d5 01    	cmpltpd %xmm13,%xmm10
   21204:	66 44 0f 54 d5       	andpd  %xmm5,%xmm10
   21209:	66 45 0f 57 f7       	xorpd  %xmm15,%xmm14
   2120e:	66 41 0f 28 ed       	movapd %xmm13,%xmm5
   21213:	66 41 0f c2 ee 05    	cmpnltpd %xmm14,%xmm5
   21219:	66 41 0f 56 eb       	orpd   %xmm11,%xmm5
   2121e:	66 44 0f 28 4c 24 20 	movapd 0x20(%rsp),%xmm9
   21225:	66 0f 54 ec          	andpd  %xmm4,%xmm5
   21229:	66 45 0f c2 ee 01    	cmpltpd %xmm14,%xmm13
   2122f:	66 44 0f 54 e8       	andpd  %xmm0,%xmm13
   21234:	0f 93 c3             	setae  %bl
   21237:	45 31 f6             	xor    %r14d,%r14d
   2123a:	f2 0f 10 15 a6 5f fe 	movsd  -0x1a05a(%rip),%xmm2        # 71e8 <std::thread::current::id::ID+0x6570>
   21241:	ff 
   21242:	66 44 0f 2e e2       	ucomisd %xmm2,%xmm12
   21247:	41 0f 92 c6          	setb   %r14b
   2124b:	66 45 0f 56 ea       	orpd   %xmm10,%xmm13
   21250:	66 41 0f 6e c6       	movd   %r14d,%xmm0
   21255:	66 0f 6f 8c 24 a0 00 	movdqa 0xa0(%rsp),%xmm1
   2125c:	00 00 
   2125e:	66 0f eb c1          	por    %xmm1,%xmm0
   21262:	66 0f eb c5          	por    %xmm5,%xmm0
   21266:	66 0f 6e e3          	movd   %ebx,%xmm4
   2126a:	66 0f 70 e4 44       	pshufd $0x44,%xmm4,%xmm4
   2126f:	66 0f db e1          	pand   %xmm1,%xmm4
   21273:	66 41 0f db e5       	pand   %xmm13,%xmm4
   21278:	66 45 0f 58 c9       	addpd  %xmm9,%xmm9
   2127d:	0f c6 c4 a0          	shufps $0xa0,%xmm4,%xmm0
   21281:	66 0f 72 f0 1f       	pslld  $0x1f,%xmm0
   21286:	66 0f 72 e0 1f       	psrad  $0x1f,%xmm0
   2128b:	66 41 0f 28 e1       	movapd %xmm9,%xmm4
   21290:	66 41 0f 15 e4       	unpckhpd %xmm12,%xmm4
   21295:	66 45 0f 14 e1       	unpcklpd %xmm9,%xmm12
   2129a:	66 41 0f 28 ec       	movapd %xmm12,%xmm5
   2129f:	66 0f 54 e8          	andpd  %xmm0,%xmm5
   212a3:	66 0f 55 c4          	andnpd %xmm4,%xmm0
   212a7:	66 44 0f 28 e0       	movapd %xmm0,%xmm12
   212ac:	66 44 0f 56 e5       	orpd   %xmm5,%xmm12
   212b1:	66 41 0f 70 c0 ee    	pshufd $0xee,%xmm8,%xmm0
   212b7:	66 44 0f 2e c2       	ucomisd %xmm2,%xmm8
   212bc:	0f 93 c3             	setae  %bl
   212bf:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
   212c3:	41 0f 93 c6          	setae  %r14b
   212c7:	66 41 0f 70 c4 ee    	pshufd $0xee,%xmm12,%xmm0
   212cd:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
   212d1:	41 0f 93 c7          	setae  %r15b
   212d5:	20 cb                	and    %cl,%bl
   212d7:	45 20 ce             	and    %r9b,%r14b
   212da:	41 08 de             	or     %bl,%r14b
   212dd:	45 20 df             	and    %r11b,%r15b
   212e0:	45 08 f7             	or     %r14b,%r15b
   212e3:	41 83 c2 ff          	add    $0xffffffff,%r10d
   212e7:	41 0f 92 c3          	setb   %r11b
   212eb:	41 80 ff 01          	cmp    $0x1,%r15b
   212ef:	75 09                	jne    212fa <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, usize, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>+0x85a>
   212f1:	45 84 db             	test   %r11b,%r11b
   212f4:	0f 85 86 fc ff ff    	jne    20f80 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, usize, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>+0x4e0>
   212fa:	66 44 0f 28 7c 24 70 	movapd 0x70(%rsp),%xmm15
   21301:	66 41 0f 28 c7       	movapd %xmm15,%xmm0
   21306:	66 44 0f 28 8c 24 10 	movapd 0x210(%rsp),%xmm9
   2130d:	02 00 00 
   21310:	66 41 0f 5d c1       	minpd  %xmm9,%xmm0
   21315:	66 44 0f 28 e8       	movapd %xmm0,%xmm13
   2131a:	66 44 0f c2 e8 03    	cmpunordpd %xmm0,%xmm13
   21320:	66 41 0f 28 d7       	movapd %xmm15,%xmm2
   21325:	66 41 0f 54 d5       	andpd  %xmm13,%xmm2
   2132a:	66 44 0f 55 e8       	andnpd %xmm0,%xmm13
   2132f:	66 44 0f 56 ea       	orpd   %xmm2,%xmm13
   21334:	66 44 0f 28 74 24 60 	movapd 0x60(%rsp),%xmm14
   2133b:	66 41 0f 28 c6       	movapd %xmm14,%xmm0
   21340:	66 0f 5d 84 24 00 01 	minpd  0x100(%rsp),%xmm0
   21347:	00 00 
   21349:	66 44 0f 28 d8       	movapd %xmm0,%xmm11
   2134e:	66 44 0f c2 d8 03    	cmpunordpd %xmm0,%xmm11
   21354:	66 41 0f 28 d6       	movapd %xmm14,%xmm2
   21359:	66 41 0f 54 d3       	andpd  %xmm11,%xmm2
   2135e:	66 44 0f 55 d8       	andnpd %xmm0,%xmm11
   21363:	66 44 0f 56 da       	orpd   %xmm2,%xmm11
   21368:	66 0f 28 4c 24 10    	movapd 0x10(%rsp),%xmm1
   2136e:	66 41 0f 54 c8       	andpd  %xmm8,%xmm1
   21373:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
   21377:	66 41 0f 14 c4       	unpcklpd %xmm12,%xmm0
   2137c:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   21380:	66 44 0f 15 e2       	unpckhpd %xmm2,%xmm12
   21385:	66 44 0f 28 84 24 80 	movapd 0x80(%rsp),%xmm8
   2138c:	00 00 00 
   2138f:	66 45 0f 54 e0       	andpd  %xmm8,%xmm12
   21394:	66 44 0f 55 c0       	andnpd %xmm0,%xmm8
   21399:	66 45 0f 56 c4       	orpd   %xmm12,%xmm8
   2139e:	66 0f 28 9c 24 10 01 	movapd 0x110(%rsp),%xmm3
   213a5:	00 00 
   213a7:	66 41 0f 59 dd       	mulpd  %xmm13,%xmm3
   213ac:	66 44 0f 28 94 24 a0 	movapd 0x2a0(%rsp),%xmm10
   213b3:	02 00 00 
   213b6:	66 41 0f 58 da       	addpd  %xmm10,%xmm3
   213bb:	66 0f 28 94 24 d0 01 	movapd 0x1d0(%rsp),%xmm2
   213c2:	00 00 
   213c4:	66 41 0f 59 d5       	mulpd  %xmm13,%xmm2
   213c9:	66 0f 58 94 24 c0 01 	addpd  0x1c0(%rsp),%xmm2
   213d0:	00 00 
   213d2:	66 0f 28 44 24 40    	movapd 0x40(%rsp),%xmm0
   213d8:	66 0f 28 2d 70 43 fe 	movapd -0x1bc90(%rip),%xmm5        # 5750 <std::thread::current::id::ID+0x4ad8>
   213df:	ff 
   213e0:	66 0f c2 c5 00       	cmpeqpd %xmm5,%xmm0
   213e5:	66 0f 28 64 24 30    	movapd 0x30(%rsp),%xmm4
   213eb:	66 0f c2 e5 00       	cmpeqpd %xmm5,%xmm4
   213f0:	66 0f 28 b4 24 90 00 	movapd 0x90(%rsp),%xmm6
   213f7:	00 00 
   213f9:	66 0f c2 f5 00       	cmpeqpd %xmm5,%xmm6
   213fe:	66 0f 54 f0          	andpd  %xmm0,%xmm6
   21402:	66 0f 29 74 24 10    	movapd %xmm6,0x10(%rsp)
   21408:	66 0f 28 44 24 50    	movapd 0x50(%rsp),%xmm0
   2140e:	66 0f c2 c5 00       	cmpeqpd %xmm5,%xmm0
   21413:	66 0f 54 c4          	andpd  %xmm4,%xmm0
   21417:	66 0f 29 44 24 20    	movapd %xmm0,0x20(%rsp)
   2141d:	66 41 0f 28 c7       	movapd %xmm15,%xmm0
   21422:	66 0f 5c c1          	subpd  %xmm1,%xmm0
   21426:	66 45 0f 5c fd       	subpd  %xmm13,%xmm15
   2142b:	66 0f 28 3d ed 3d fe 	movapd -0x1c213(%rip),%xmm7        # 5220 <std::thread::current::id::ID+0x45a8>
   21432:	ff 
   21433:	66 44 0f 54 ff       	andpd  %xmm7,%xmm15
   21438:	66 44 0f 58 f9       	addpd  %xmm1,%xmm15
   2143d:	66 41 0f c2 c1 01    	cmpltpd %xmm9,%xmm0
   21443:	66 41 0f 54 c7       	andpd  %xmm15,%xmm0
   21448:	66 0f 28 c8          	movapd %xmm0,%xmm1
   2144c:	66 0f c2 cd 00       	cmpeqpd %xmm5,%xmm1
   21451:	66 0f 28 f0          	movapd %xmm0,%xmm6
   21455:	66 0f c2 f5 03       	cmpunordpd %xmm5,%xmm6
   2145a:	66 0f 56 f1          	orpd   %xmm1,%xmm6
   2145e:	66 0f 28 ee          	movapd %xmm6,%xmm5
   21462:	66 0f 55 e8          	andnpd %xmm0,%xmm5
   21466:	66 41 0f 59 d5       	mulpd  %xmm13,%xmm2
   2146b:	66 44 0f 28 8c 24 d0 	movapd 0xd0(%rsp),%xmm9
   21472:	00 00 00 
   21475:	66 41 0f 58 d1       	addpd  %xmm9,%xmm2
   2147a:	66 0f 28 84 24 b0 01 	movapd 0x1b0(%rsp),%xmm0
   21481:	00 00 
   21483:	66 41 0f 59 c5       	mulpd  %xmm13,%xmm0
   21488:	66 0f 28 8c 24 a0 01 	movapd 0x1a0(%rsp),%xmm1
   2148f:	00 00 
   21491:	66 0f 58 c8          	addpd  %xmm0,%xmm1
   21495:	66 41 0f 59 cd       	mulpd  %xmm13,%xmm1
   2149a:	66 0f 28 a4 24 90 01 	movapd 0x190(%rsp),%xmm4
   214a1:	00 00 
   214a3:	66 0f 58 cc          	addpd  %xmm4,%xmm1
   214a7:	66 44 0f 28 3d 80 40 	movapd -0x1bf80(%rip),%xmm15        # 5530 <std::thread::current::id::ID+0x48b8>
   214ae:	fe ff 
   214b0:	66 41 0f 59 cf       	mulpd  %xmm15,%xmm1
   214b5:	66 0f 54 d7          	andpd  %xmm7,%xmm2
   214b9:	66 0f 58 d1          	addpd  %xmm1,%xmm2
   214bd:	66 0f 28 8c 24 90 02 	movapd 0x290(%rsp),%xmm1
   214c4:	00 00 
   214c6:	66 41 0f 59 cb       	mulpd  %xmm11,%xmm1
   214cb:	66 0f 58 8c 24 80 02 	addpd  0x280(%rsp),%xmm1
   214d2:	00 00 
   214d4:	66 41 0f 59 dd       	mulpd  %xmm13,%xmm3
   214d9:	66 0f 58 dc          	addpd  %xmm4,%xmm3
   214dd:	66 41 0f 59 dd       	mulpd  %xmm13,%xmm3
   214e2:	66 0f 58 9c 24 30 02 	addpd  0x230(%rsp),%xmm3
   214e9:	00 00 
   214eb:	66 41 0f 59 df       	mulpd  %xmm15,%xmm3
   214f0:	66 0f 59 d5          	mulpd  %xmm5,%xmm2
   214f4:	66 0f 58 d3          	addpd  %xmm3,%xmm2
   214f8:	66 41 0f 58 c2       	addpd  %xmm10,%xmm0
   214fd:	66 0f 28 9c 24 10 01 	movapd 0x110(%rsp),%xmm3
   21504:	00 00 
   21506:	66 0f 59 dd          	mulpd  %xmm5,%xmm3
   2150a:	66 0f 58 d8          	addpd  %xmm0,%xmm3
   2150e:	66 0f 28 84 24 f0 00 	movapd 0xf0(%rsp),%xmm0
   21515:	00 00 
   21517:	66 41 0f 59 c5       	mulpd  %xmm13,%xmm0
   2151c:	66 44 0f 28 94 24 70 	movapd 0x170(%rsp),%xmm10
   21523:	01 00 00 
   21526:	66 41 0f 58 c2       	addpd  %xmm10,%xmm0
   2152b:	66 41 0f 59 c5       	mulpd  %xmm13,%xmm0
   21530:	66 41 0f 58 c1       	addpd  %xmm9,%xmm0
   21535:	66 41 0f 59 c5       	mulpd  %xmm13,%xmm0
   2153a:	66 0f 58 84 24 e0 00 	addpd  0xe0(%rsp),%xmm0
   21541:	00 00 
   21543:	66 0f 59 dd          	mulpd  %xmm5,%xmm3
   21547:	66 0f 59 dd          	mulpd  %xmm5,%xmm3
   2154b:	66 0f 58 da          	addpd  %xmm2,%xmm3
   2154f:	66 0f 28 d0          	movapd %xmm0,%xmm2
   21553:	66 0f 28 e7          	movapd %xmm7,%xmm4
   21557:	66 0f 54 d7          	andpd  %xmm7,%xmm2
   2155b:	66 0f c2 d3 02       	cmplepd %xmm3,%xmm2
   21560:	66 0f 29 b4 24 c0 00 	movapd %xmm6,0xc0(%rsp)
   21567:	00 00 
   21569:	66 0f 56 d6          	orpd   %xmm6,%xmm2
   2156d:	66 0f c2 d8 01       	cmpltpd %xmm0,%xmm3
   21572:	66 0f 29 94 24 b0 00 	movapd %xmm2,0xb0(%rsp)
   21579:	00 00 
   2157b:	66 0f 28 fa          	movapd %xmm2,%xmm7
   2157f:	66 0f 55 fb          	andnpd %xmm3,%xmm7
   21583:	66 41 0f 28 d6       	movapd %xmm14,%xmm2
   21588:	66 41 0f 5c d0       	subpd  %xmm8,%xmm2
   2158d:	66 45 0f 5c f3       	subpd  %xmm11,%xmm14
   21592:	66 44 0f 54 f4       	andpd  %xmm4,%xmm14
   21597:	66 0f 28 ec          	movapd %xmm4,%xmm5
   2159b:	66 45 0f 58 f0       	addpd  %xmm8,%xmm14
   215a0:	66 0f c2 94 24 00 01 	cmpltpd 0x100(%rsp),%xmm2
   215a7:	00 00 01 
   215aa:	66 41 0f 54 d6       	andpd  %xmm14,%xmm2
   215af:	66 0f 28 c2          	movapd %xmm2,%xmm0
   215b3:	66 0f 28 1d 95 41 fe 	movapd -0x1be6b(%rip),%xmm3        # 5750 <std::thread::current::id::ID+0x4ad8>
   215ba:	ff 
   215bb:	66 0f c2 c3 00       	cmpeqpd %xmm3,%xmm0
   215c0:	66 0f 28 e2          	movapd %xmm2,%xmm4
   215c4:	66 0f c2 e3 03       	cmpunordpd %xmm3,%xmm4
   215c9:	66 0f 56 e0          	orpd   %xmm0,%xmm4
   215cd:	66 0f 28 c4          	movapd %xmm4,%xmm0
   215d1:	66 0f 55 c2          	andnpd %xmm2,%xmm0
   215d5:	66 41 0f 59 cb       	mulpd  %xmm11,%xmm1
   215da:	66 44 0f 28 a4 24 40 	movapd 0x140(%rsp),%xmm12
   215e1:	01 00 00 
   215e4:	66 41 0f 58 cc       	addpd  %xmm12,%xmm1
   215e9:	66 0f 28 94 24 b0 02 	movapd 0x2b0(%rsp),%xmm2
   215f0:	00 00 
   215f2:	66 41 0f 59 d3       	mulpd  %xmm11,%xmm2
   215f7:	66 0f 28 9c 24 50 02 	movapd 0x250(%rsp),%xmm3
   215fe:	00 00 
   21600:	66 0f 58 da          	addpd  %xmm2,%xmm3
   21604:	66 41 0f 59 db       	mulpd  %xmm11,%xmm3
   21609:	66 44 0f 28 8c 24 40 	movapd 0x240(%rsp),%xmm9
   21610:	02 00 00 
   21613:	66 41 0f 58 d9       	addpd  %xmm9,%xmm3
   21618:	66 41 0f 59 df       	mulpd  %xmm15,%xmm3
   2161d:	66 0f 54 cd          	andpd  %xmm5,%xmm1
   21621:	66 0f 58 cb          	addpd  %xmm3,%xmm1
   21625:	66 0f 28 ac 24 70 02 	movapd 0x270(%rsp),%xmm5
   2162c:	00 00 
   2162e:	66 0f 28 dd          	movapd %xmm5,%xmm3
   21632:	66 41 0f 59 db       	mulpd  %xmm11,%xmm3
   21637:	66 0f 28 b4 24 60 02 	movapd 0x260(%rsp),%xmm6
   2163e:	00 00 
   21640:	66 0f 58 de          	addpd  %xmm6,%xmm3
   21644:	66 41 0f 59 db       	mulpd  %xmm11,%xmm3
   21649:	66 41 0f 58 d9       	addpd  %xmm9,%xmm3
   2164e:	66 41 0f 59 db       	mulpd  %xmm11,%xmm3
   21653:	66 0f 58 9c 24 20 02 	addpd  0x220(%rsp),%xmm3
   2165a:	00 00 
   2165c:	66 41 0f 59 df       	mulpd  %xmm15,%xmm3
   21661:	66 0f 59 c8          	mulpd  %xmm0,%xmm1
   21665:	66 0f 58 cb          	addpd  %xmm3,%xmm1
   21669:	66 0f 58 d6          	addpd  %xmm6,%xmm2
   2166d:	66 0f 28 dd          	movapd %xmm5,%xmm3
   21671:	66 0f 59 d8          	mulpd  %xmm0,%xmm3
   21675:	66 0f 58 da          	addpd  %xmm2,%xmm3
   21679:	66 41 0f 28 d3       	movapd %xmm11,%xmm2
   2167e:	66 0f 54 7c 24 10    	andpd  0x10(%rsp),%xmm7
   21684:	66 0f 59 d8          	mulpd  %xmm0,%xmm3
   21688:	66 0f 59 d8          	mulpd  %xmm0,%xmm3
   2168c:	66 0f 28 84 24 80 01 	movapd 0x180(%rsp),%xmm0
   21693:	00 00 
   21695:	66 41 0f 59 c3       	mulpd  %xmm11,%xmm0
   2169a:	66 44 0f 28 b4 24 50 	movapd 0x150(%rsp),%xmm14
   216a1:	01 00 00 
   216a4:	66 41 0f 58 c6       	addpd  %xmm14,%xmm0
   216a9:	66 41 0f 59 c3       	mulpd  %xmm11,%xmm0
   216ae:	66 41 0f 58 c4       	addpd  %xmm12,%xmm0
   216b3:	66 41 0f 59 c3       	mulpd  %xmm11,%xmm0
   216b8:	66 44 0f 28 8c 24 60 	movapd 0x160(%rsp),%xmm9
   216bf:	01 00 00 
   216c2:	66 41 0f 58 c1       	addpd  %xmm9,%xmm0
   216c7:	66 0f 58 d9          	addpd  %xmm1,%xmm3
   216cb:	66 0f 28 f0          	movapd %xmm0,%xmm6
   216cf:	66 0f 54 35 49 3b fe 	andpd  -0x1c4b7(%rip),%xmm6        # 5220 <std::thread::current::id::ID+0x45a8>
   216d6:	ff 
   216d7:	66 0f c2 f3 02       	cmplepd %xmm3,%xmm6
   216dc:	66 0f 29 64 24 60    	movapd %xmm4,0x60(%rsp)
   216e2:	66 0f 56 f4          	orpd   %xmm4,%xmm6
   216e6:	66 0f c2 d8 01       	cmpltpd %xmm0,%xmm3
   216eb:	66 0f 28 ce          	movapd %xmm6,%xmm1
   216ef:	66 0f 55 cb          	andnpd %xmm3,%xmm1
   216f3:	66 0f 54 4c 24 20    	andpd  0x20(%rsp),%xmm1
   216f9:	66 0f 70 c7 ee       	pshufd $0xee,%xmm7,%xmm0
   216fe:	66 0f eb c7          	por    %xmm7,%xmm0
   21702:	66 0f eb c1          	por    %xmm1,%xmm0
   21706:	66 0f 7e c1          	movd   %xmm0,%ecx
   2170a:	f6 c1 01             	test   $0x1,%cl
   2170d:	0f 84 ad f6 ff ff    	je     20dc0 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, usize, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>+0x320>
   21713:	66 0f 29 b4 24 00 02 	movapd %xmm6,0x200(%rsp)
   2171a:	00 00 
   2171c:	66 44 0f 28 c7       	movapd %xmm7,%xmm8
   21721:	66 0f 28 05 f7 40 fe 	movapd -0x1bf09(%rip),%xmm0        # 5820 <std::thread::current::id::ID+0x4ba8>
   21728:	ff 
   21729:	66 44 0f 57 c0       	xorpd  %xmm0,%xmm8
   2172e:	66 44 0f 28 c9       	movapd %xmm1,%xmm9
   21733:	66 44 0f 57 c8       	xorpd  %xmm0,%xmm9
   21738:	66 0f 70 c1 ee       	pshufd $0xee,%xmm1,%xmm0
   2173d:	66 48 0f 7e c1       	movq   %xmm0,%rcx
   21742:	0f 29 7c 24 70       	movaps %xmm7,0x70(%rsp)
   21747:	66 44 0f 6f df       	movdqa %xmm7,%xmm11
   2174c:	0f 29 8c 24 f0 01 00 	movaps %xmm1,0x1f0(%rsp)
   21753:	00 
   21754:	66 44 0f 6b d9       	packssdw %xmm1,%xmm11
   21759:	4d 89 c1             	mov    %r8,%r9
   2175c:	66 44 0f 28 a4 24 20 	movapd 0x120(%rsp),%xmm12
   21763:	01 00 00 
   21766:	66 0f 28 bc 24 30 01 	movapd 0x130(%rsp),%xmm7
   2176d:	00 00 
   2176f:	66 44 0f 29 ac 24 a0 	movapd %xmm13,0xa0(%rsp)
   21776:	00 00 00 
   21779:	66 41 0f 28 f5       	movapd %xmm13,%xmm6
   2177e:	66 0f 29 94 24 80 00 	movapd %xmm2,0x80(%rsp)
   21785:	00 00 
   21787:	66 44 0f 28 b4 24 e0 	movapd 0xe0(%rsp),%xmm14
   2178e:	00 00 00 
   21791:	66 44 0f 28 3d e6 3b 	movapd -0x1c41a(%rip),%xmm15        # 5380 <std::thread::current::id::ID+0x4708>
   21798:	fe ff 
   2179a:	66 44 0f 28 ac 24 f0 	movapd 0xf0(%rsp),%xmm13
   217a1:	00 00 00 
   217a4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   217ab:	00 00 00 00 00 
   217b0:	66 0f 28 de          	movapd %xmm6,%xmm3
   217b4:	66 41 0f 5c dc       	subpd  %xmm12,%xmm3
   217b9:	66 0f 28 e2          	movapd %xmm2,%xmm4
   217bd:	66 0f 5c e7          	subpd  %xmm7,%xmm4
   217c1:	66 41 0f 59 df       	mulpd  %xmm15,%xmm3
   217c6:	66 41 0f 58 dc       	addpd  %xmm12,%xmm3
   217cb:	66 41 0f 28 c5       	movapd %xmm13,%xmm0
   217d0:	66 0f 59 c3          	mulpd  %xmm3,%xmm0
   217d4:	66 41 0f 58 c2       	addpd  %xmm10,%xmm0
   217d9:	66 0f 59 c3          	mulpd  %xmm3,%xmm0
   217dd:	66 0f 58 84 24 d0 00 	addpd  0xd0(%rsp),%xmm0
   217e4:	00 00 
   217e6:	66 0f 59 c3          	mulpd  %xmm3,%xmm0
   217ea:	66 41 0f 58 c6       	addpd  %xmm14,%xmm0
   217ef:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   217f3:	66 0f c2 c8 01       	cmpltpd %xmm0,%xmm1
   217f8:	66 0f 28 c1          	movapd %xmm1,%xmm0
   217fc:	66 41 0f 56 c0       	orpd   %xmm8,%xmm0
   21801:	66 41 0f 28 ec       	movapd %xmm12,%xmm5
   21806:	66 44 0f 70 e0 a0    	pshufd $0xa0,%xmm0,%xmm12
   2180c:	66 41 0f 72 f4 1f    	pslld  $0x1f,%xmm12
   21812:	66 41 0f 72 e4 1f    	psrad  $0x1f,%xmm12
   21818:	66 41 0f 54 ec       	andpd  %xmm12,%xmm5
   2181d:	66 44 0f 55 e3       	andnpd %xmm3,%xmm12
   21822:	66 41 0f 59 e7       	mulpd  %xmm15,%xmm4
   21827:	66 0f 58 e7          	addpd  %xmm7,%xmm4
   2182b:	66 0f 28 84 24 80 01 	movapd 0x180(%rsp),%xmm0
   21832:	00 00 
   21834:	66 0f 59 c4          	mulpd  %xmm4,%xmm0
   21838:	66 0f 58 84 24 50 01 	addpd  0x150(%rsp),%xmm0
   2183f:	00 00 
   21841:	66 0f 59 c4          	mulpd  %xmm4,%xmm0
   21845:	66 0f 58 84 24 40 01 	addpd  0x140(%rsp),%xmm0
   2184c:	00 00 
   2184e:	66 0f 59 c4          	mulpd  %xmm4,%xmm0
   21852:	66 0f 58 84 24 60 01 	addpd  0x160(%rsp),%xmm0
   21859:	00 00 
   2185b:	66 45 0f 57 d2       	xorpd  %xmm10,%xmm10
   21860:	66 44 0f c2 d0 01    	cmpltpd %xmm0,%xmm10
   21866:	66 45 0f c5 d2 04    	pextrw $0x4,%xmm10,%r10d
   2186c:	66 44 0f 56 e5       	orpd   %xmm5,%xmm12
   21871:	41 20 ca             	and    %cl,%r10b
   21874:	45 0f b6 d2          	movzbl %r10b,%r10d
   21878:	66 41 0f 6e c2       	movd   %r10d,%xmm0
   2187d:	41 0f c6 c3 e4       	shufps $0xe4,%xmm11,%xmm0
   21882:	66 41 0f 6f eb       	movdqa %xmm11,%xmm5
   21887:	0f c6 e8 24          	shufps $0x24,%xmm0,%xmm5
   2188b:	66 0f 6e c6          	movd   %esi,%xmm0
   2188f:	66 41 0f 6c c2       	punpcklqdq %xmm10,%xmm0
   21894:	0f c6 c8 28          	shufps $0x28,%xmm0,%xmm1
   21898:	0f 54 cd             	andps  %xmm5,%xmm1
   2189b:	66 0f 70 c1 fa       	pshufd $0xfa,%xmm1,%xmm0
   218a0:	66 0f 72 f0 1f       	pslld  $0x1f,%xmm0
   218a5:	66 0f 72 e0 1f       	psrad  $0x1f,%xmm0
   218aa:	66 45 0f 56 d1       	orpd   %xmm9,%xmm10
   218af:	66 0f 28 ef          	movapd %xmm7,%xmm5
   218b3:	66 41 0f 70 fa a0    	pshufd $0xa0,%xmm10,%xmm7
   218b9:	66 44 0f 28 94 24 70 	movapd 0x170(%rsp),%xmm10
   218c0:	01 00 00 
   218c3:	66 0f 72 f7 1f       	pslld  $0x1f,%xmm7
   218c8:	66 0f 72 e7 1f       	psrad  $0x1f,%xmm7
   218cd:	66 0f 54 ef          	andpd  %xmm7,%xmm5
   218d1:	66 0f 55 fc          	andnpd %xmm4,%xmm7
   218d5:	66 0f 54 e0          	andpd  %xmm0,%xmm4
   218d9:	66 0f 55 c2          	andnpd %xmm2,%xmm0
   218dd:	66 0f 56 c4          	orpd   %xmm4,%xmm0
   218e1:	66 0f 70 c9 50       	pshufd $0x50,%xmm1,%xmm1
   218e6:	66 0f 72 f1 1f       	pslld  $0x1f,%xmm1
   218eb:	66 0f 72 e1 1f       	psrad  $0x1f,%xmm1
   218f0:	66 0f 54 d9          	andpd  %xmm1,%xmm3
   218f4:	66 0f 55 ce          	andnpd %xmm6,%xmm1
   218f8:	66 0f 56 cb          	orpd   %xmm3,%xmm1
   218fc:	66 0f 56 fd          	orpd   %xmm5,%xmm7
   21900:	66 0f 28 f1          	movapd %xmm1,%xmm6
   21904:	66 0f 28 d0          	movapd %xmm0,%xmm2
   21908:	49 ff c9             	dec    %r9
   2190b:	0f 85 9f fe ff ff    	jne    217b0 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, usize, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>+0xd10>
   21911:	66 0f 28 44 24 70    	movapd 0x70(%rsp),%xmm0
   21917:	66 44 0f 54 e0       	andpd  %xmm0,%xmm12
   2191c:	66 0f 55 44 24 40    	andnpd 0x40(%rsp),%xmm0
   21922:	66 41 0f 56 c4       	orpd   %xmm12,%xmm0
   21927:	66 0f 28 8c 24 f0 01 	movapd 0x1f0(%rsp),%xmm1
   2192e:	00 00 
   21930:	66 0f 54 f9          	andpd  %xmm1,%xmm7
   21934:	66 0f 55 4c 24 30    	andnpd 0x30(%rsp),%xmm1
   2193a:	66 0f 56 cf          	orpd   %xmm7,%xmm1
   2193e:	66 0f 29 44 24 40    	movapd %xmm0,0x40(%rsp)
   21944:	66 0f 29 4c 24 30    	movapd %xmm1,0x30(%rsp)
   2194a:	66 0f 28 9c 24 90 00 	movapd 0x90(%rsp),%xmm3
   21951:	00 00 
   21953:	66 44 0f 28 ac 24 a0 	movapd 0xa0(%rsp),%xmm13
   2195a:	00 00 00 
   2195d:	66 0f 28 94 24 80 00 	movapd 0x80(%rsp),%xmm2
   21964:	00 00 
   21966:	66 0f 28 b4 24 00 02 	movapd 0x200(%rsp),%xmm6
   2196d:	00 00 
   2196f:	e9 55 f4 ff ff       	jmp    20dc9 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, usize, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>+0x329>
   21974:	0f 28 44 24 40       	movaps 0x40(%rsp),%xmm0
   21979:	0f 29 07             	movaps %xmm0,(%rdi)
   2197c:	0f 28 44 24 30       	movaps 0x30(%rsp),%xmm0
   21981:	0f 29 47 10          	movaps %xmm0,0x10(%rdi)
   21985:	66 0f 29 4f 20       	movapd %xmm1,0x20(%rdi)
   2198a:	0f 28 44 24 50       	movaps 0x50(%rsp),%xmm0
   2198f:	0f 29 47 30          	movaps %xmm0,0x30(%rdi)
   21993:	48 8d 65 e8          	lea    -0x18(%rbp),%rsp
   21997:	5b                   	pop    %rbx
   21998:	41 5e                	pop    %r14
   2199a:	41 5f                	pop    %r15
   2199c:	5d                   	pop    %rbp
   2199d:	c3                   	ret
   2199e:	cc                   	int3
   2199f:	cc                   	int3

gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>:
   219a0:	55                   	push   %rbp
   219a1:	48 89 e5             	mov    %rsp,%rbp
   219a4:	41 57                	push   %r15
   219a6:	41 56                	push   %r14
   219a8:	41 55                	push   %r13
   219aa:	41 54                	push   %r12
   219ac:	53                   	push   %rbx
   219ad:	48 83 e4 e0          	and    $0xffffffffffffffe0,%rsp
   219b1:	48 81 ec 60 02 00 00 	sub    $0x260,%rsp
   219b8:	f3 0f 11 44 24 0c    	movss  %xmm0,0xc(%rsp)
   219be:	89 fb                	mov    %edi,%ebx
   219c0:	0f 29 4c 24 40       	movaps %xmm1,0x40(%rsp)
   219c5:	0f 57 c0             	xorps  %xmm0,%xmm0
   219c8:	f3 0f 5a c1          	cvtss2sd %xmm1,%xmm0
   219cc:	f2 0f 59 05 a4 59 fe 	mulsd  -0x1a65c(%rip),%xmm0        # 7378 <std::thread::current::id::ID+0x6700>
   219d3:	ff 
   219d4:	48 8d bc 24 98 00 00 	lea    0x98(%rsp),%rdi
   219db:	00 
   219dc:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
   219e3:	00 
   219e4:	ff 15 36 3d 04 00    	call   *0x43d36(%rip)        # 65720 <sincos@GLIBC_2.2.5>
   219ea:	f2 0f 10 84 24 98 00 	movsd  0x98(%rsp),%xmm0
   219f1:	00 00 
   219f3:	f2 0f 10 8c 24 90 00 	movsd  0x90(%rsp),%xmm1
   219fa:	00 00 
   219fc:	f2 0f 10 15 4c 59 fe 	movsd  -0x1a6b4(%rip),%xmm2        # 7350 <std::thread::current::id::ID+0x66d8>
   21a03:	ff 
   21a04:	f2 0f 59 d1          	mulsd  %xmm1,%xmm2
   21a08:	66 0f 57 e4          	xorpd  %xmm4,%xmm4
   21a0c:	f2 0f 58 d4          	addsd  %xmm4,%xmm2
   21a10:	f2 0f 10 1d 90 58 fe 	movsd  -0x1a770(%rip),%xmm3        # 72a8 <std::thread::current::id::ID+0x6630>
   21a17:	ff 
   21a18:	f2 0f 59 d9          	mulsd  %xmm1,%xmm3
   21a1c:	f2 0f 58 dc          	addsd  %xmm4,%xmm3
   21a20:	f2 44 0f 10 0d bf 58 	movsd  -0x1a741(%rip),%xmm9        # 72e8 <std::thread::current::id::ID+0x6670>
   21a27:	fe ff 
   21a29:	f2 44 0f 59 c8       	mulsd  %xmm0,%xmm9
   21a2e:	f2 44 0f 58 ca       	addsd  %xmm2,%xmm9
   21a33:	f2 0f 10 2d 75 59 fe 	movsd  -0x1a68b(%rip),%xmm5        # 73b0 <std::thread::current::id::ID+0x6738>
   21a3a:	ff 
   21a3b:	f2 0f 59 e8          	mulsd  %xmm0,%xmm5
   21a3f:	f2 0f 58 eb          	addsd  %xmm3,%xmm5
   21a43:	f2 0f 59 0d ed 58 fe 	mulsd  -0x1a713(%rip),%xmm1        # 7338 <std::thread::current::id::ID+0x66c0>
   21a4a:	ff 
   21a4b:	f2 0f 58 cc          	addsd  %xmm4,%xmm1
   21a4f:	f2 0f 59 05 31 57 fe 	mulsd  -0x1a8cf(%rip),%xmm0        # 7188 <std::thread::current::id::ID+0x6510>
   21a56:	ff 
   21a57:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
   21a5b:	85 db                	test   %ebx,%ebx
   21a5d:	74 3f                	je     21a9e <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xfe>
   21a5f:	0f 28 0d 6a 3d fe ff 	movaps -0x1c296(%rip),%xmm1        # 57d0 <std::thread::current::id::ID+0x4b58>
   21a66:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
   21a6b:	66 0f 28 0d ed 3d fe 	movapd -0x1c213(%rip),%xmm1        # 5860 <std::thread::current::id::ID+0x4be8>
   21a72:	ff 
   21a73:	66 0f 28 25 35 39 fe 	movapd -0x1c6cb(%rip),%xmm4        # 53b0 <std::thread::current::id::ID+0x4738>
   21a7a:	ff 
   21a7b:	66 0f 28 35 ed 3d fe 	movapd -0x1c213(%rip),%xmm6        # 5870 <std::thread::current::id::ID+0x4bf8>
   21a82:	ff 
   21a83:	f3 0f 7e 1d 55 57 fe 	movq   -0x1a8ab(%rip),%xmm3        # 71e0 <std::thread::current::id::ID+0x6568>
   21a8a:	ff 
   21a8b:	f2 44 0f 10 3d 34 58 	movsd  -0x1a7cc(%rip),%xmm15        # 72c8 <std::thread::current::id::ID+0x6650>
   21a92:	fe ff 
   21a94:	f3 0f 7e 15 54 57 fe 	movq   -0x1a8ac(%rip),%xmm2        # 71f0 <std::thread::current::id::ID+0x6578>
   21a9b:	ff 
   21a9c:	eb 3d                	jmp    21adb <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0x13b>
   21a9e:	0f 28 0d eb 38 fe ff 	movaps -0x1c715(%rip),%xmm1        # 5390 <std::thread::current::id::ID+0x4718>
   21aa5:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
   21aaa:	66 0f 28 0d 8e 3a fe 	movapd -0x1c572(%rip),%xmm1        # 5540 <std::thread::current::id::ID+0x48c8>
   21ab1:	ff 
   21ab2:	66 0f 28 25 86 38 fe 	movapd -0x1c77a(%rip),%xmm4        # 5340 <std::thread::current::id::ID+0x46c8>
   21ab9:	ff 
   21aba:	66 0f 28 35 fe 3c fe 	movapd -0x1c302(%rip),%xmm6        # 57c0 <std::thread::current::id::ID+0x4b48>
   21ac1:	ff 
   21ac2:	f3 0f 7e 1d 4e 58 fe 	movq   -0x1a7b2(%rip),%xmm3        # 7318 <std::thread::current::id::ID+0x66a0>
   21ac9:	ff 
   21aca:	f2 44 0f 10 3d 35 58 	movsd  -0x1a7cb(%rip),%xmm15        # 7308 <std::thread::current::id::ID+0x6690>
   21ad1:	fe ff 
   21ad3:	f3 0f 7e 15 a5 57 fe 	movq   -0x1a85b(%rip),%xmm2        # 7280 <std::thread::current::id::ID+0x6608>
   21ada:	ff 
   21adb:	66 0f 7f 54 24 20    	movdqa %xmm2,0x20(%rsp)
   21ae1:	66 44 0f 14 cd       	unpcklpd %xmm5,%xmm9
   21ae6:	66 45 0f 28 d9       	movapd %xmm9,%xmm11
   21aeb:	66 45 0f 59 d9       	mulpd  %xmm9,%xmm11
   21af0:	66 0f 28 e8          	movapd %xmm0,%xmm5
   21af4:	f2 0f 59 e8          	mulsd  %xmm0,%xmm5
   21af8:	f2 0f 59 e8          	mulsd  %xmm0,%xmm5
   21afc:	66 45 0f 59 d9       	mulpd  %xmm9,%xmm11
   21b01:	66 41 0f 28 fb       	movapd %xmm11,%xmm7
   21b06:	66 41 0f c6 fb 01    	shufpd $0x1,%xmm11,%xmm7
   21b0c:	66 0f 59 fc          	mulpd  %xmm4,%xmm7
   21b10:	66 45 0f 28 c3       	movapd %xmm11,%xmm8
   21b15:	66 44 0f 59 c6       	mulpd  %xmm6,%xmm8
   21b1a:	66 44 0f 58 c7       	addpd  %xmm7,%xmm8
   21b1f:	66 0f 14 ed          	unpcklpd %xmm5,%xmm5
   21b23:	66 44 0f 28 f5       	movapd %xmm5,%xmm14
   21b28:	66 44 0f 59 f1       	mulpd  %xmm1,%xmm14
   21b2d:	66 45 0f 58 f0       	addpd  %xmm8,%xmm14
   21b32:	f3 0f 7e fa          	movq   %xmm2,%xmm7
   21b36:	66 0f 59 ef          	mulpd  %xmm7,%xmm5
   21b3a:	66 45 0f 57 c0       	xorpd  %xmm8,%xmm8
   21b3f:	66 45 0f 14 c7       	unpcklpd %xmm15,%xmm8
   21b44:	66 41 0f 28 d3       	movapd %xmm11,%xmm2
   21b49:	66 45 0f 59 d8       	mulpd  %xmm8,%xmm11
   21b4e:	66 45 0f c6 db 01    	shufpd $0x1,%xmm11,%xmm11
   21b54:	f3 44 0f 7e d3       	movq   %xmm3,%xmm10
   21b59:	66 41 0f 59 d2       	mulpd  %xmm10,%xmm2
   21b5e:	66 41 0f 58 d3       	addpd  %xmm11,%xmm2
   21b63:	66 0f 58 d5          	addpd  %xmm5,%xmm2
   21b67:	66 0f 29 54 24 70    	movapd %xmm2,0x70(%rsp)
   21b6d:	66 45 0f 28 d9       	movapd %xmm9,%xmm11
   21b72:	66 44 0f 59 1d 75 38 	mulpd  -0x1c78b(%rip),%xmm11        # 53f0 <std::thread::current::id::ID+0x4778>
   21b79:	fe ff 
   21b7b:	66 45 0f 59 cb       	mulpd  %xmm11,%xmm9
   21b80:	66 0f 6f eb          	movdqa %xmm3,%xmm5
   21b84:	66 41 0f 28 d9       	movapd %xmm9,%xmm3
   21b89:	66 45 0f 28 e1       	movapd %xmm9,%xmm12
   21b8e:	66 45 0f c6 e1 01    	shufpd $0x1,%xmm9,%xmm12
   21b94:	66 44 0f 59 e4       	mulpd  %xmm4,%xmm12
   21b99:	66 45 0f 28 e9       	movapd %xmm9,%xmm13
   21b9e:	66 44 0f 59 ee       	mulpd  %xmm6,%xmm13
   21ba3:	66 45 0f 58 ec       	addpd  %xmm12,%xmm13
   21ba8:	f2 0f 10 15 08 57 fe 	movsd  -0x1a8f8(%rip),%xmm2        # 72b8 <std::thread::current::id::ID+0x6640>
   21baf:	ff 
   21bb0:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
   21bb4:	f2 0f 59 c2          	mulsd  %xmm2,%xmm0
   21bb8:	66 0f 14 c0          	unpcklpd %xmm0,%xmm0
   21bbc:	66 44 0f 28 c8       	movapd %xmm0,%xmm9
   21bc1:	66 44 0f 59 c9       	mulpd  %xmm1,%xmm9
   21bc6:	66 45 0f 58 cd       	addpd  %xmm13,%xmm9
   21bcb:	66 44 0f 28 e3       	movapd %xmm3,%xmm12
   21bd0:	66 45 0f 59 e0       	mulpd  %xmm8,%xmm12
   21bd5:	66 45 0f c6 e4 01    	shufpd $0x1,%xmm12,%xmm12
   21bdb:	66 41 0f 59 da       	mulpd  %xmm10,%xmm3
   21be0:	66 41 0f 58 dc       	addpd  %xmm12,%xmm3
   21be5:	66 0f 59 c7          	mulpd  %xmm7,%xmm0
   21be9:	66 0f 58 d8          	addpd  %xmm0,%xmm3
   21bed:	66 0f 29 5c 24 60    	movapd %xmm3,0x60(%rsp)
   21bf3:	66 41 0f 28 c3       	movapd %xmm11,%xmm0
   21bf8:	66 41 0f c6 c3 01    	shufpd $0x1,%xmm11,%xmm0
   21bfe:	66 0f 59 c4          	mulpd  %xmm4,%xmm0
   21c02:	66 41 0f 59 f3       	mulpd  %xmm11,%xmm6
   21c07:	66 0f 58 f0          	addpd  %xmm0,%xmm6
   21c0b:	66 0f 14 d2          	unpcklpd %xmm2,%xmm2
   21c0f:	66 0f 28 c2          	movapd %xmm2,%xmm0
   21c13:	66 0f 59 c1          	mulpd  %xmm1,%xmm0
   21c17:	66 0f 58 c6          	addpd  %xmm6,%xmm0
   21c1b:	66 0f 28 f0          	movapd %xmm0,%xmm6
   21c1f:	66 0f 29 44 24 50    	movapd %xmm0,0x50(%rsp)
   21c25:	66 45 0f 59 c3       	mulpd  %xmm11,%xmm8
   21c2a:	66 45 0f c6 c0 01    	shufpd $0x1,%xmm8,%xmm8
   21c30:	66 45 0f 59 da       	mulpd  %xmm10,%xmm11
   21c35:	66 45 0f 58 d8       	addpd  %xmm8,%xmm11
   21c3a:	66 0f 59 d7          	mulpd  %xmm7,%xmm2
   21c3e:	66 41 0f 58 d3       	addpd  %xmm11,%xmm2
   21c43:	66 0f 29 94 24 80 01 	movapd %xmm2,0x180(%rsp)
   21c4a:	00 00 
   21c4c:	f2 44 0f 58 fd       	addsd  %xmm5,%xmm15
   21c51:	66 0f 28 44 24 10    	movapd 0x10(%rsp),%xmm0
   21c57:	66 0f 58 c1          	addpd  %xmm1,%xmm0
   21c5b:	66 0f 29 44 24 10    	movapd %xmm0,0x10(%rsp)
   21c61:	f2 44 0f 58 7c 24 20 	addsd  0x20(%rsp),%xmm15
   21c68:	66 44 0f 29 7c 24 20 	movapd %xmm15,0x20(%rsp)
   21c6f:	66 41 0f 28 de       	movapd %xmm14,%xmm3
   21c74:	66 41 0f 28 d6       	movapd %xmm14,%xmm2
   21c79:	66 44 0f 29 b4 24 90 	movapd %xmm14,0x190(%rsp)
   21c80:	01 00 00 
   21c83:	66 0f 59 1d 65 37 fe 	mulpd  -0x1c89b(%rip),%xmm3        # 53f0 <std::thread::current::id::ID+0x4778>
   21c8a:	ff 
   21c8b:	66 45 0f 28 c1       	movapd %xmm9,%xmm8
   21c90:	66 45 0f 28 f9       	movapd %xmm9,%xmm15
   21c95:	66 44 0f 29 8c 24 70 	movapd %xmm9,0x170(%rsp)
   21c9c:	01 00 00 
   21c9f:	66 45 0f 58 c1       	addpd  %xmm9,%xmm8
   21ca4:	66 45 0f 28 d0       	movapd %xmm8,%xmm10
   21ca9:	66 45 0f 59 d0       	mulpd  %xmm8,%xmm10
   21cae:	66 0f 59 f3          	mulpd  %xmm3,%xmm6
   21cb2:	66 0f 59 35 a6 37 fe 	mulpd  -0x1c85a(%rip),%xmm6        # 5460 <std::thread::current::id::ID+0x47e8>
   21cb9:	ff 
   21cba:	66 41 0f 28 fa       	movapd %xmm10,%xmm7
   21cbf:	66 0f 5c fe          	subpd  %xmm6,%xmm7
   21cc3:	66 45 0f 28 c8       	movapd %xmm8,%xmm9
   21cc8:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
   21ccc:	66 44 0f c2 c8 05    	cmpnltpd %xmm0,%xmm9
   21cd2:	66 0f 28 cf          	movapd %xmm7,%xmm1
   21cd6:	66 0f 5f c8          	maxpd  %xmm0,%xmm1
   21cda:	66 0f 57 ed          	xorpd  %xmm5,%xmm5
   21cde:	66 0f 51 e1          	sqrtpd %xmm1,%xmm4
   21ce2:	66 44 0f 28 dc       	movapd %xmm4,%xmm11
   21ce7:	66 44 0f 57 1d a0 3a 	xorpd  -0x1c560(%rip),%xmm11        # 5790 <std::thread::current::id::ID+0x4b18>
   21cee:	fe ff 
   21cf0:	66 41 0f 54 e1       	andpd  %xmm9,%xmm4
   21cf5:	66 45 0f 55 cb       	andnpd %xmm11,%xmm9
   21cfa:	66 44 0f 56 cc       	orpd   %xmm4,%xmm9
   21cff:	66 0f 28 05 19 35 fe 	movapd -0x1cae7(%rip),%xmm0        # 5220 <std::thread::current::id::ID+0x45a8>
   21d06:	ff 
   21d07:	66 0f 54 f0          	andpd  %xmm0,%xmm6
   21d0b:	66 41 0f 58 f2       	addpd  %xmm10,%xmm6
   21d10:	66 45 0f 57 db       	xorpd  %xmm11,%xmm11
   21d15:	66 44 0f c2 df 02    	cmplepd %xmm7,%xmm11
   21d1b:	66 0f 54 f8          	andpd  %xmm0,%xmm7
   21d1f:	66 0f 59 35 09 38 fe 	mulpd  -0x1c7f7(%rip),%xmm6        # 5530 <std::thread::current::id::ID+0x48b8>
   21d26:	ff 
   21d27:	66 0f c2 fe 02       	cmplepd %xmm6,%xmm7
   21d2c:	66 44 0f 28 d3       	movapd %xmm3,%xmm10
   21d31:	66 44 0f c2 d5 04    	cmpneqpd %xmm5,%xmm10
   21d37:	66 41 0f 54 da       	andpd  %xmm10,%xmm3
   21d3c:	66 41 0f 28 c0       	movapd %xmm8,%xmm0
   21d41:	66 0f c2 c5 00       	cmpeqpd %xmm5,%xmm0
   21d46:	66 0f 28 25 52 39 fe 	movapd -0x1c6ae(%rip),%xmm4        # 56a0 <std::thread::current::id::ID+0x4a28>
   21d4d:	ff 
   21d4e:	66 44 0f 28 f4       	movapd %xmm4,%xmm14
   21d53:	66 44 0f 54 f0       	andpd  %xmm0,%xmm14
   21d58:	66 45 0f 54 da       	andpd  %xmm10,%xmm11
   21d5d:	66 44 0f 28 e0       	movapd %xmm0,%xmm12
   21d62:	66 41 0f 56 c2       	orpd   %xmm10,%xmm0
   21d67:	66 41 0f 54 fa       	andpd  %xmm10,%xmm7
   21d6c:	66 41 0f 28 ca       	movapd %xmm10,%xmm1
   21d71:	66 0f 55 cc          	andnpd %xmm4,%xmm1
   21d75:	66 0f 56 cb          	orpd   %xmm3,%xmm1
   21d79:	66 45 0f 58 c8       	addpd  %xmm8,%xmm9
   21d7e:	66 44 0f 28 15 f9 3a 	movapd -0x1c507(%rip),%xmm10        # 5880 <std::thread::current::id::ID+0x4c08>
   21d85:	fe ff 
   21d87:	66 45 0f 59 ca       	mulpd  %xmm10,%xmm9
   21d8c:	66 41 0f 28 d9       	movapd %xmm9,%xmm3
   21d91:	66 0f c2 dd 04       	cmpneqpd %xmm5,%xmm3
   21d96:	66 41 0f 28 f1       	movapd %xmm9,%xmm6
   21d9b:	66 0f 54 f3          	andpd  %xmm3,%xmm6
   21d9f:	66 45 0f 70 eb a0    	pshufd $0xa0,%xmm11,%xmm13
   21da5:	66 44 0f 54 db       	andpd  %xmm3,%xmm11
   21daa:	66 0f 55 dc          	andnpd %xmm4,%xmm3
   21dae:	66 0f 56 de          	orpd   %xmm6,%xmm3
   21db2:	66 45 0f 55 e0       	andnpd %xmm8,%xmm12
   21db7:	66 45 0f 56 f4       	orpd   %xmm12,%xmm14
   21dbc:	66 44 0f 5e c9       	divpd  %xmm1,%xmm9
   21dc1:	66 0f 28 ca          	movapd %xmm2,%xmm1
   21dc5:	66 0f 28 15 c3 39 fe 	movapd -0x1c63d(%rip),%xmm2        # 5790 <std::thread::current::id::ID+0x4b18>
   21dcc:	ff 
   21dcd:	66 0f 57 ca          	xorpd  %xmm2,%xmm1
   21dd1:	66 0f 29 4c 24 30    	movapd %xmm1,0x30(%rsp)
   21dd7:	66 0f 29 8c 24 a0 00 	movapd %xmm1,0xa0(%rsp)
   21dde:	00 00 
   21de0:	66 0f 28 64 24 70    	movapd 0x70(%rsp),%xmm4
   21de6:	66 0f 28 cc          	movapd %xmm4,%xmm1
   21dea:	66 0f 57 ca          	xorpd  %xmm2,%xmm1
   21dee:	66 0f 29 8c 24 b0 00 	movapd %xmm1,0xb0(%rsp)
   21df5:	00 00 
   21df7:	66 41 0f 28 f7       	movapd %xmm15,%xmm6
   21dfc:	66 44 0f 28 fa       	movapd %xmm2,%xmm15
   21e01:	66 0f 57 f2          	xorpd  %xmm2,%xmm6
   21e05:	66 0f 29 b4 24 c0 00 	movapd %xmm6,0xc0(%rsp)
   21e0c:	00 00 
   21e0e:	66 0f 28 54 24 60    	movapd 0x60(%rsp),%xmm2
   21e14:	66 44 0f 28 c2       	movapd %xmm2,%xmm8
   21e19:	66 45 0f 57 c7       	xorpd  %xmm15,%xmm8
   21e1e:	66 44 0f 29 84 24 d0 	movapd %xmm8,0xd0(%rsp)
   21e25:	00 00 00 
   21e28:	66 0f 28 4c 24 50    	movapd 0x50(%rsp),%xmm1
   21e2e:	66 44 0f 28 c1       	movapd %xmm1,%xmm8
   21e33:	66 45 0f 57 c7       	xorpd  %xmm15,%xmm8
   21e38:	66 44 0f 29 84 24 e0 	movapd %xmm8,0xe0(%rsp)
   21e3f:	00 00 00 
   21e42:	66 45 0f 5e c6       	divpd  %xmm14,%xmm8
   21e47:	66 0f 73 f0 3f       	psllq  $0x3f,%xmm0
   21e4c:	66 0f 72 e0 1f       	psrad  $0x1f,%xmm0
   21e51:	66 44 0f 70 e0 f5    	pshufd $0xf5,%xmm0,%xmm12
   21e57:	66 45 0f df e0       	pandn  %xmm8,%xmm12
   21e5c:	66 44 0f 6f 35 eb 38 	movdqa -0x1c715(%rip),%xmm14        # 5750 <std::thread::current::id::ID+0x4ad8>
   21e63:	fe ff 
   21e65:	66 41 0f db c6       	pand   %xmm14,%xmm0
   21e6a:	66 41 0f eb c4       	por    %xmm12,%xmm0
   21e6f:	66 45 0f 54 cd       	andpd  %xmm13,%xmm9
   21e74:	66 44 0f df e8       	pandn  %xmm0,%xmm13
   21e79:	66 45 0f eb e9       	por    %xmm9,%xmm13
   21e7e:	66 0f 28 c1          	movapd %xmm1,%xmm0
   21e82:	66 0f 5e c3          	divpd  %xmm3,%xmm0
   21e86:	66 41 0f 70 db a0    	pshufd $0xa0,%xmm11,%xmm3
   21e8c:	66 0f 54 c3          	andpd  %xmm3,%xmm0
   21e90:	66 41 0f df de       	pandn  %xmm14,%xmm3
   21e95:	66 0f eb d8          	por    %xmm0,%xmm3
   21e99:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
   21e9d:	66 41 0f c2 c5 05    	cmpnltpd %xmm13,%xmm0
   21ea3:	66 45 0f 6f c6       	movdqa %xmm14,%xmm8
   21ea8:	66 44 0f db c0       	pand   %xmm0,%xmm8
   21ead:	66 41 0f df c5       	pandn  %xmm13,%xmm0
   21eb2:	66 41 0f eb c0       	por    %xmm8,%xmm0
   21eb7:	66 45 0f ef c0       	pxor   %xmm8,%xmm8
   21ebc:	66 44 0f c2 c3 05    	cmpnltpd %xmm3,%xmm8
   21ec2:	66 45 0f 6f ce       	movdqa %xmm14,%xmm9
   21ec7:	66 45 0f db c8       	pand   %xmm8,%xmm9
   21ecc:	66 44 0f df c3       	pandn  %xmm3,%xmm8
   21ed1:	66 45 0f eb c1       	por    %xmm9,%xmm8
   21ed6:	66 0f 6f d8          	movdqa %xmm0,%xmm3
   21eda:	66 41 0f 5d d8       	minpd  %xmm8,%xmm3
   21edf:	66 44 0f 28 cb       	movapd %xmm3,%xmm9
   21ee4:	66 44 0f c2 cb 03    	cmpunordpd %xmm3,%xmm9
   21eea:	66 44 0f 6f d8       	movdqa %xmm0,%xmm11
   21eef:	66 45 0f db d9       	pand   %xmm9,%xmm11
   21ef4:	66 44 0f 55 cb       	andnpd %xmm3,%xmm9
   21ef9:	66 45 0f 56 cb       	orpd   %xmm11,%xmm9
   21efe:	66 41 0f 55 f9       	andnpd %xmm9,%xmm7
   21f03:	66 0f 29 bc 24 e0 01 	movapd %xmm7,0x1e0(%rsp)
   21f0a:	00 00 
   21f0c:	66 0f 6f d8          	movdqa %xmm0,%xmm3
   21f10:	66 41 0f 5f d8       	maxpd  %xmm8,%xmm3
   21f15:	66 0f 28 fb          	movapd %xmm3,%xmm7
   21f19:	66 0f c2 fb 03       	cmpunordpd %xmm3,%xmm7
   21f1e:	66 0f db c7          	pand   %xmm7,%xmm0
   21f22:	66 0f 55 fb          	andnpd %xmm3,%xmm7
   21f26:	66 0f 56 f8          	orpd   %xmm0,%xmm7
   21f2a:	66 0f 29 bc 24 00 02 	movapd %xmm7,0x200(%rsp)
   21f31:	00 00 
   21f33:	66 0f 28 0d b5 34 fe 	movapd -0x1cb4b(%rip),%xmm1        # 53f0 <std::thread::current::id::ID+0x4778>
   21f3a:	ff 
   21f3b:	66 0f 59 cc          	mulpd  %xmm4,%xmm1
   21f3f:	66 0f 28 ac 24 80 01 	movapd 0x180(%rsp),%xmm5
   21f46:	00 00 
   21f48:	66 0f 28 c5          	movapd %xmm5,%xmm0
   21f4c:	66 0f 59 c1          	mulpd  %xmm1,%xmm0
   21f50:	66 0f 28 e1          	movapd %xmm1,%xmm4
   21f54:	66 0f 59 05 04 35 fe 	mulpd  -0x1cafc(%rip),%xmm0        # 5460 <std::thread::current::id::ID+0x47e8>
   21f5b:	ff 
   21f5c:	66 44 0f 28 da       	movapd %xmm2,%xmm11
   21f61:	66 44 0f 58 da       	addpd  %xmm2,%xmm11
   21f66:	66 41 0f 28 db       	movapd %xmm11,%xmm3
   21f6b:	66 41 0f 59 db       	mulpd  %xmm11,%xmm3
   21f70:	66 0f 28 fb          	movapd %xmm3,%xmm7
   21f74:	66 0f 5c f8          	subpd  %xmm0,%xmm7
   21f78:	66 44 0f 28 c7       	movapd %xmm7,%xmm8
   21f7d:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   21f81:	f2 44 0f 5f c1       	maxsd  %xmm1,%xmm8
   21f86:	45 0f 57 c9          	xorps  %xmm9,%xmm9
   21f8a:	f2 45 0f 51 c8       	sqrtsd %xmm8,%xmm9
   21f8f:	66 45 0f 28 c3       	movapd %xmm11,%xmm8
   21f94:	f2 44 0f c2 c1 05    	cmpnltsd %xmm1,%xmm8
   21f9a:	66 45 0f 28 e0       	movapd %xmm8,%xmm12
   21f9f:	66 45 0f 54 e1       	andpd  %xmm9,%xmm12
   21fa4:	66 45 0f 57 cf       	xorpd  %xmm15,%xmm9
   21fa9:	66 45 0f 55 c1       	andnpd %xmm9,%xmm8
   21fae:	66 45 0f 56 c4       	orpd   %xmm12,%xmm8
   21fb3:	66 44 0f 28 cf       	movapd %xmm7,%xmm9
   21fb8:	66 44 0f 15 cf       	unpckhpd %xmm7,%xmm9
   21fbd:	f2 44 0f 5f c9       	maxsd  %xmm1,%xmm9
   21fc2:	f2 45 0f 51 c9       	sqrtsd %xmm9,%xmm9
   21fc7:	66 45 0f 14 c1       	unpcklpd %xmm9,%xmm8
   21fcc:	66 45 0f 58 c3       	addpd  %xmm11,%xmm8
   21fd1:	66 45 0f 59 c2       	mulpd  %xmm10,%xmm8
   21fd6:	66 0f 28 0d 42 32 fe 	movapd -0x1cdbe(%rip),%xmm1        # 5220 <std::thread::current::id::ID+0x45a8>
   21fdd:	ff 
   21fde:	66 0f 54 c1          	andpd  %xmm1,%xmm0
   21fe2:	66 0f 58 c3          	addpd  %xmm3,%xmm0
   21fe6:	66 0f 59 05 42 35 fe 	mulpd  -0x1cabe(%rip),%xmm0        # 5530 <std::thread::current::id::ID+0x48b8>
   21fed:	ff 
   21fee:	66 45 0f 57 d2       	xorpd  %xmm10,%xmm10
   21ff3:	66 44 0f c2 d7 02    	cmplepd %xmm7,%xmm10
   21ff9:	66 0f 54 f9          	andpd  %xmm1,%xmm7
   21ffd:	66 0f c2 f8 02       	cmplepd %xmm0,%xmm7
   22002:	66 0f 28 c4          	movapd %xmm4,%xmm0
   22006:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   2200a:	66 0f c2 c1 04       	cmpneqpd %xmm1,%xmm0
   2200f:	66 0f 54 e0          	andpd  %xmm0,%xmm4
   22013:	66 45 0f 28 e3       	movapd %xmm11,%xmm12
   22018:	66 44 0f c2 e1 00    	cmpeqpd %xmm1,%xmm12
   2201e:	66 45 0f 57 ff       	xorpd  %xmm15,%xmm15
   22023:	66 0f 28 15 75 36 fe 	movapd -0x1c98b(%rip),%xmm2        # 56a0 <std::thread::current::id::ID+0x4a28>
   2202a:	ff 
   2202b:	66 0f 28 da          	movapd %xmm2,%xmm3
   2202f:	66 41 0f 54 dc       	andpd  %xmm12,%xmm3
   22034:	66 44 0f 54 d0       	andpd  %xmm0,%xmm10
   22039:	66 45 0f 28 cc       	movapd %xmm12,%xmm9
   2203e:	66 44 0f 56 e0       	orpd   %xmm0,%xmm12
   22043:	66 0f 54 f8          	andpd  %xmm0,%xmm7
   22047:	66 0f 55 c2          	andnpd %xmm2,%xmm0
   2204b:	66 0f 56 c4          	orpd   %xmm4,%xmm0
   2204f:	66 45 0f 28 e8       	movapd %xmm8,%xmm13
   22054:	66 45 0f c2 ef 04    	cmpneqpd %xmm15,%xmm13
   2205a:	66 0f 57 e4          	xorpd  %xmm4,%xmm4
   2205e:	66 45 0f 28 f8       	movapd %xmm8,%xmm15
   22063:	66 45 0f 54 fd       	andpd  %xmm13,%xmm15
   22068:	66 41 0f 70 ca a0    	pshufd $0xa0,%xmm10,%xmm1
   2206e:	66 45 0f 54 d5       	andpd  %xmm13,%xmm10
   22073:	66 44 0f 55 ea       	andnpd %xmm2,%xmm13
   22078:	66 45 0f 56 ef       	orpd   %xmm15,%xmm13
   2207d:	66 45 0f 55 cb       	andnpd %xmm11,%xmm9
   22082:	66 41 0f 56 d9       	orpd   %xmm9,%xmm3
   22087:	66 44 0f 5e c0       	divpd  %xmm0,%xmm8
   2208c:	66 0f 28 c5          	movapd %xmm5,%xmm0
   22090:	66 44 0f 28 1d f7 36 	movapd -0x1c909(%rip),%xmm11        # 5790 <std::thread::current::id::ID+0x4b18>
   22097:	fe ff 
   22099:	66 41 0f 57 c3       	xorpd  %xmm11,%xmm0
   2209e:	66 0f 29 84 24 f0 00 	movapd %xmm0,0xf0(%rsp)
   220a5:	00 00 
   220a7:	66 0f 5e c3          	divpd  %xmm3,%xmm0
   220ab:	66 41 0f 73 f4 3f    	psllq  $0x3f,%xmm12
   220b1:	66 41 0f 72 e4 1f    	psrad  $0x1f,%xmm12
   220b7:	66 41 0f 70 dc f5    	pshufd $0xf5,%xmm12,%xmm3
   220bd:	66 0f df d8          	pandn  %xmm0,%xmm3
   220c1:	66 45 0f db e6       	pand   %xmm14,%xmm12
   220c6:	66 44 0f eb e3       	por    %xmm3,%xmm12
   220cb:	66 44 0f 54 c1       	andpd  %xmm1,%xmm8
   220d0:	66 41 0f df cc       	pandn  %xmm12,%xmm1
   220d5:	66 41 0f eb c8       	por    %xmm8,%xmm1
   220da:	66 0f 28 c5          	movapd %xmm5,%xmm0
   220de:	66 44 0f 28 cd       	movapd %xmm5,%xmm9
   220e3:	66 41 0f 5e c5       	divpd  %xmm13,%xmm0
   220e8:	66 41 0f 70 da a0    	pshufd $0xa0,%xmm10,%xmm3
   220ee:	66 0f 54 c3          	andpd  %xmm3,%xmm0
   220f2:	66 41 0f df de       	pandn  %xmm14,%xmm3
   220f7:	66 0f eb d8          	por    %xmm0,%xmm3
   220fb:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
   220ff:	66 0f c2 c1 05       	cmpnltpd %xmm1,%xmm0
   22104:	66 45 0f 6f c6       	movdqa %xmm14,%xmm8
   22109:	66 44 0f db c0       	pand   %xmm0,%xmm8
   2210e:	66 0f df c1          	pandn  %xmm1,%xmm0
   22112:	66 41 0f eb c0       	por    %xmm8,%xmm0
   22117:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   2211b:	66 0f c2 d3 05       	cmpnltpd %xmm3,%xmm2
   22120:	66 44 0f db f2       	pand   %xmm2,%xmm14
   22125:	66 0f df d3          	pandn  %xmm3,%xmm2
   22129:	66 41 0f eb d6       	por    %xmm14,%xmm2
   2212e:	66 0f 6f c8          	movdqa %xmm0,%xmm1
   22132:	66 0f 5d ca          	minpd  %xmm2,%xmm1
   22136:	66 0f 28 d9          	movapd %xmm1,%xmm3
   2213a:	66 0f c2 d9 03       	cmpunordpd %xmm1,%xmm3
   2213f:	66 44 0f 6f c0       	movdqa %xmm0,%xmm8
   22144:	66 44 0f db c3       	pand   %xmm3,%xmm8
   22149:	66 0f 55 d9          	andnpd %xmm1,%xmm3
   2214d:	66 41 0f 56 d8       	orpd   %xmm8,%xmm3
   22152:	66 0f 55 fb          	andnpd %xmm3,%xmm7
   22156:	66 0f 29 bc 24 f0 01 	movapd %xmm7,0x1f0(%rsp)
   2215d:	00 00 
   2215f:	66 0f 6f c8          	movdqa %xmm0,%xmm1
   22163:	66 0f 5f ca          	maxpd  %xmm2,%xmm1
   22167:	66 0f 28 d1          	movapd %xmm1,%xmm2
   2216b:	66 0f c2 d1 03       	cmpunordpd %xmm1,%xmm2
   22170:	66 0f db c2          	pand   %xmm2,%xmm0
   22174:	66 0f 55 d1          	andnpd %xmm1,%xmm2
   22178:	66 0f 56 d0          	orpd   %xmm0,%xmm2
   2217c:	66 0f 29 94 24 10 02 	movapd %xmm2,0x210(%rsp)
   22183:	00 00 
   22185:	66 44 0f 28 44 24 70 	movapd 0x70(%rsp),%xmm8
   2218c:	66 41 0f 28 c0       	movapd %xmm8,%xmm0
   22191:	66 0f 28 2d 87 30 fe 	movapd -0x1cf79(%rip),%xmm5        # 5220 <std::thread::current::id::ID+0x45a8>
   22198:	ff 
   22199:	66 0f 54 c5          	andpd  %xmm5,%xmm0
   2219d:	66 0f 28 5c 24 60    	movapd 0x60(%rsp),%xmm3
   221a3:	66 0f 28 cb          	movapd %xmm3,%xmm1
   221a7:	66 0f 54 cd          	andpd  %xmm5,%xmm1
   221ab:	66 41 0f 28 d1       	movapd %xmm9,%xmm2
   221b0:	66 0f 54 d5          	andpd  %xmm5,%xmm2
   221b4:	66 44 0f 28 cd       	movapd %xmm5,%xmm9
   221b9:	f2 0f c2 dc 00       	cmpeqsd %xmm4,%xmm3
   221be:	66 0f 28 fb          	movapd %xmm3,%xmm7
   221c2:	66 0f 55 f9          	andnpd %xmm1,%xmm7
   221c6:	66 0f 54 da          	andpd  %xmm2,%xmm3
   221ca:	66 0f 56 df          	orpd   %xmm7,%xmm3
   221ce:	f2 41 0f c2 e0 00    	cmpeqsd %xmm8,%xmm4
   221d4:	66 0f 28 fc          	movapd %xmm4,%xmm7
   221d8:	66 0f 55 f8          	andnpd %xmm0,%xmm7
   221dc:	66 0f 54 e3          	andpd  %xmm3,%xmm4
   221e0:	66 0f 56 e7          	orpd   %xmm7,%xmm4
   221e4:	f2 0f 5f 25 24 50 fe 	maxsd  -0x1afdc(%rip),%xmm4        # 7210 <std::thread::current::id::ID+0x6598>
   221eb:	ff 
   221ec:	66 0f 28 c1          	movapd %xmm1,%xmm0
   221f0:	f2 0f 5f c2          	maxsd  %xmm2,%xmm0
   221f4:	66 0f 28 d8          	movapd %xmm0,%xmm3
   221f8:	f2 0f c2 d8 03       	cmpunordsd %xmm0,%xmm3
   221fd:	66 0f 54 cb          	andpd  %xmm3,%xmm1
   22201:	66 0f 55 d8          	andnpd %xmm0,%xmm3
   22205:	66 0f 56 d9          	orpd   %xmm1,%xmm3
   22209:	66 0f 28 7c 24 20    	movapd 0x20(%rsp),%xmm7
   2220f:	66 0f 28 c7          	movapd %xmm7,%xmm0
   22213:	66 0f 54 c5          	andpd  %xmm5,%xmm0
   22217:	66 0f 28 cb          	movapd %xmm3,%xmm1
   2221b:	f2 0f 5f c8          	maxsd  %xmm0,%xmm1
   2221f:	66 0f 28 d1          	movapd %xmm1,%xmm2
   22223:	f2 0f c2 d1 03       	cmpunordsd %xmm1,%xmm2
   22228:	66 0f 54 da          	andpd  %xmm2,%xmm3
   2222c:	66 0f 55 d1          	andnpd %xmm1,%xmm2
   22230:	66 0f 56 d3          	orpd   %xmm3,%xmm2
   22234:	f2 0f 5e d4          	divsd  %xmm4,%xmm2
   22238:	66 0f 28 a4 24 90 01 	movapd 0x190(%rsp),%xmm4
   2223f:	00 00 
   22241:	66 0f 28 c4          	movapd %xmm4,%xmm0
   22245:	66 0f c2 44 24 30 00 	cmpeqpd 0x30(%rsp),%xmm0
   2224c:	66 0f 28 9c 24 70 01 	movapd 0x170(%rsp),%xmm3
   22253:	00 00 
   22255:	66 0f 28 cb          	movapd %xmm3,%xmm1
   22259:	66 0f c2 ce 00       	cmpeqpd %xmm6,%xmm1
   2225e:	66 0f 54 dd          	andpd  %xmm5,%xmm3
   22262:	66 0f 28 6c 24 50    	movapd 0x50(%rsp),%xmm5
   22268:	66 41 0f 54 e9       	andpd  %xmm9,%xmm5
   2226d:	66 0f 28 f3          	movapd %xmm3,%xmm6
   22271:	66 0f 5f f5          	maxpd  %xmm5,%xmm6
   22275:	66 0f 54 e9          	andpd  %xmm1,%xmm5
   22279:	66 0f 55 cb          	andnpd %xmm3,%xmm1
   2227d:	66 0f 56 cd          	orpd   %xmm5,%xmm1
   22281:	66 0f 28 ec          	movapd %xmm4,%xmm5
   22285:	66 41 0f 54 e9       	andpd  %xmm9,%xmm5
   2228a:	66 0f 54 c8          	andpd  %xmm0,%xmm1
   2228e:	66 0f 55 c5          	andnpd %xmm5,%xmm0
   22292:	66 0f 56 c1          	orpd   %xmm1,%xmm0
   22296:	66 0f 28 ce          	movapd %xmm6,%xmm1
   2229a:	66 0f c2 ce 03       	cmpunordpd %xmm6,%xmm1
   2229f:	66 0f 54 d9          	andpd  %xmm1,%xmm3
   222a3:	66 0f 55 ce          	andnpd %xmm6,%xmm1
   222a7:	66 0f 56 cb          	orpd   %xmm3,%xmm1
   222ab:	66 0f 28 6c 24 10    	movapd 0x10(%rsp),%xmm5
   222b1:	66 44 0f 54 cd       	andpd  %xmm5,%xmm9
   222b6:	66 0f 28 d9          	movapd %xmm1,%xmm3
   222ba:	66 41 0f 5f d9       	maxpd  %xmm9,%xmm3
   222bf:	66 0f 28 e3          	movapd %xmm3,%xmm4
   222c3:	66 0f c2 e3 03       	cmpunordpd %xmm3,%xmm4
   222c8:	66 0f 54 cc          	andpd  %xmm4,%xmm1
   222cc:	66 0f 55 e3          	andnpd %xmm3,%xmm4
   222d0:	66 0f 5f 05 e8 2f fe 	maxpd  -0x1d018(%rip),%xmm0        # 52c0 <std::thread::current::id::ID+0x4648>
   222d7:	ff 
   222d8:	66 0f 56 e1          	orpd   %xmm1,%xmm4
   222dc:	66 0f 5e e0          	divpd  %xmm0,%xmm4
   222e0:	66 0f 58 25 b8 33 fe 	addpd  -0x1cc48(%rip),%xmm4        # 56a0 <std::thread::current::id::ID+0x4a28>
   222e7:	ff 
   222e8:	66 0f 29 a4 24 a0 01 	movapd %xmm4,0x1a0(%rsp)
   222ef:	00 00 
   222f1:	f2 0f 58 15 4f 4f fe 	addsd  -0x1b0b1(%rip),%xmm2        # 7248 <std::thread::current::id::ID+0x65d0>
   222f8:	ff 
   222f9:	f2 0f 11 94 24 b0 01 	movsd  %xmm2,0x1b0(%rsp)
   22300:	00 00 
   22302:	66 0f 28 c7          	movapd %xmm7,%xmm0
   22306:	66 41 0f 28 cb       	movapd %xmm11,%xmm1
   2230b:	66 41 0f 57 c3       	xorpd  %xmm11,%xmm0
   22310:	66 0f 57 cd          	xorpd  %xmm5,%xmm1
   22314:	66 0f 29 8c 24 00 01 	movapd %xmm1,0x100(%rsp)
   2231b:	00 00 
   2231d:	66 0f 13 84 24 10 01 	movlpd %xmm0,0x110(%rsp)
   22324:	00 00 
   22326:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
   2232d:	00 f0 3f 
   22330:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
   22337:	00 
   22338:	48 b8 00 00 00 00 00 	movabs $0xbff0000000000000,%rax
   2233f:	00 f0 bf 
   22342:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
   22349:	00 
   2234a:	48 8d bc 24 20 01 00 	lea    0x120(%rsp),%rdi
   22351:	00 
   22352:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
   22359:	00 
   2235a:	48 8d 94 24 e0 01 00 	lea    0x1e0(%rsp),%rdx
   22361:	00 
   22362:	48 8d 8c 24 a0 01 00 	lea    0x1a0(%rsp),%rcx
   22369:	00 
   2236a:	41 b8 60 00 00 00    	mov    $0x60,%r8d
   22370:	e8 2b e7 ff ff       	call   20aa0 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, usize, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>>
   22375:	f2 0f 10 84 24 20 01 	movsd  0x120(%rsp),%xmm0
   2237c:	00 00 
   2237e:	f2 0f 10 8c 24 28 01 	movsd  0x128(%rsp),%xmm1
   22385:	00 00 
   22387:	f2 0f 10 a4 24 30 01 	movsd  0x130(%rsp),%xmm4
   2238e:	00 00 
   22390:	f2 0f 5d 05 50 4e fe 	minsd  -0x1b1b0(%rip),%xmm0        # 71e8 <std::thread::current::id::ID+0x6570>
   22397:	ff 
   22398:	f2 0f 5d c8          	minsd  %xmm0,%xmm1
   2239c:	f2 0f 5d e1          	minsd  %xmm1,%xmm4
   223a0:	66 48 0f 7e e0       	movq   %xmm4,%rax
   223a5:	49 bf ff ff ff ff ff 	movabs $0x7fffffffffffffff,%r15
   223ac:	ff ff 7f 
   223af:	4c 21 f8             	and    %r15,%rax
   223b2:	41 be 0e 00 00 00    	mov    $0xe,%r14d
   223b8:	48 b9 ff ff ff ff ff 	movabs $0x7fefffffffffffff,%rcx
   223bf:	ff ef 7f 
   223c2:	48 39 c8             	cmp    %rcx,%rax
   223c5:	7e 12                	jle    223d9 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xa39>
   223c7:	4c 89 f0             	mov    %r14,%rax
   223ca:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
   223ce:	5b                   	pop    %rbx
   223cf:	41 5c                	pop    %r12
   223d1:	41 5d                	pop    %r13
   223d3:	41 5e                	pop    %r14
   223d5:	41 5f                	pop    %r15
   223d7:	5d                   	pop    %rbp
   223d8:	c3                   	ret
   223d9:	f2 0f 10 84 24 40 01 	movsd  0x140(%rsp),%xmm0
   223e0:	00 00 
   223e2:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
   223e7:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   223ed:	0f 57 c9             	xorps  %xmm1,%xmm1
   223f0:	f3 0f 5a c8          	cvtss2sd %xmm0,%xmm1
   223f4:	0f 10 84 24 48 01 00 	movups 0x148(%rsp),%xmm0
   223fb:	00 
   223fc:	0f 29 84 24 d0 01 00 	movaps %xmm0,0x1d0(%rsp)
   22403:	00 
   22404:	0f 28 c1             	movaps %xmm1,%xmm0
   22407:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   2240b:	f2 0f 11 8c 24 88 00 	movsd  %xmm1,0x88(%rsp)
   22412:	00 00 
   22414:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   22418:	f2 0f 10 0d 28 4e fe 	movsd  -0x1b1d8(%rip),%xmm1        # 7248 <std::thread::current::id::ID+0x65d0>
   2241f:	ff 
   22420:	66 0f 28 d1          	movapd %xmm1,%xmm2
   22424:	f2 0f 5e d0          	divsd  %xmm0,%xmm2
   22428:	66 0f 28 5c 24 20    	movapd 0x20(%rsp),%xmm3
   2242e:	f2 0f 5c da          	subsd  %xmm2,%xmm3
   22432:	f2 0f 5c ca          	subsd  %xmm2,%xmm1
   22436:	66 0f 14 d2          	unpcklpd %xmm2,%xmm2
   2243a:	66 0f 28 44 24 10    	movapd 0x10(%rsp),%xmm0
   22440:	66 0f 5c c2          	subpd  %xmm2,%xmm0
   22444:	66 0f 29 84 24 00 01 	movapd %xmm0,0x100(%rsp)
   2244b:	00 00 
   2244d:	f2 0f 11 9c 24 10 01 	movsd  %xmm3,0x110(%rsp)
   22454:	00 00 
   22456:	f2 0f 11 8c 24 18 01 	movsd  %xmm1,0x118(%rsp)
   2245d:	00 00 
   2245f:	0f 28 84 24 90 01 00 	movaps 0x190(%rsp),%xmm0
   22466:	00 
   22467:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
   2246e:	00 
   2246f:	0f 28 44 24 70       	movaps 0x70(%rsp),%xmm0
   22474:	0f 29 84 24 b0 00 00 	movaps %xmm0,0xb0(%rsp)
   2247b:	00 
   2247c:	0f 28 84 24 70 01 00 	movaps 0x170(%rsp),%xmm0
   22483:	00 
   22484:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
   2248b:	00 
   2248c:	0f 28 44 24 60       	movaps 0x60(%rsp),%xmm0
   22491:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
   22498:	00 
   22499:	0f 28 44 24 50       	movaps 0x50(%rsp),%xmm0
   2249e:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
   224a5:	00 
   224a6:	0f 28 84 24 80 01 00 	movaps 0x180(%rsp),%xmm0
   224ad:	00 
   224ae:	0f 29 84 24 f0 00 00 	movaps %xmm0,0xf0(%rsp)
   224b5:	00 
   224b6:	66 0f 28 c4          	movapd %xmm4,%xmm0
   224ba:	66 0f 14 c4          	unpcklpd %xmm4,%xmm0
   224be:	66 0f 29 84 24 30 02 	movapd %xmm0,0x230(%rsp)
   224c5:	00 00 
   224c7:	66 0f 29 84 24 20 02 	movapd %xmm0,0x220(%rsp)
   224ce:	00 00 
   224d0:	48 8d bc 24 20 01 00 	lea    0x120(%rsp),%rdi
   224d7:	00 
   224d8:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
   224df:	00 
   224e0:	48 8d 94 24 e0 01 00 	lea    0x1e0(%rsp),%rdx
   224e7:	00 
   224e8:	48 8d 8c 24 20 02 00 	lea    0x220(%rsp),%rcx
   224ef:	00 
   224f0:	41 b8 40 00 00 00    	mov    $0x40,%r8d
   224f6:	0f 29 64 24 10       	movaps %xmm4,0x10(%rsp)
   224fb:	e8 a0 e5 ff ff       	call   20aa0 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, usize, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>>
   22500:	66 0f 28 54 24 30    	movapd 0x30(%rsp),%xmm2
   22506:	66 0f 28 c2          	movapd %xmm2,%xmm0
   2250a:	f2 0f 5d 84 24 40 01 	minsd  0x140(%rsp),%xmm0
   22511:	00 00 
   22513:	66 0f 28 c8          	movapd %xmm0,%xmm1
   22517:	f2 0f c2 c8 03       	cmpunordsd %xmm0,%xmm1
   2251c:	66 0f 54 d1          	andpd  %xmm1,%xmm2
   22520:	66 0f 55 c8          	andnpd %xmm0,%xmm1
   22524:	66 0f 28 5c 24 10    	movapd 0x10(%rsp),%xmm3
   2252a:	66 0f 28 c3          	movapd %xmm3,%xmm0
   2252e:	f2 0f 5d 84 24 20 01 	minsd  0x120(%rsp),%xmm0
   22535:	00 00 
   22537:	66 0f 56 ca          	orpd   %xmm2,%xmm1
   2253b:	66 0f 28 d0          	movapd %xmm0,%xmm2
   2253f:	f2 0f c2 d0 03       	cmpunordsd %xmm0,%xmm2
   22544:	66 0f 54 da          	andpd  %xmm2,%xmm3
   22548:	66 0f 55 d0          	andnpd %xmm0,%xmm2
   2254c:	66 0f 56 d3          	orpd   %xmm3,%xmm2
   22550:	f2 0f 10 84 24 28 01 	movsd  0x128(%rsp),%xmm0
   22557:	00 00 
   22559:	66 0f 28 da          	movapd %xmm2,%xmm3
   2255d:	f2 0f 5d d8          	minsd  %xmm0,%xmm3
   22561:	66 0f 28 e3          	movapd %xmm3,%xmm4
   22565:	f2 0f c2 e3 03       	cmpunordsd %xmm3,%xmm4
   2256a:	66 0f 54 d4          	andpd  %xmm4,%xmm2
   2256e:	66 0f 55 e3          	andnpd %xmm3,%xmm4
   22572:	66 0f 56 e2          	orpd   %xmm2,%xmm4
   22576:	f2 0f 10 84 24 30 01 	movsd  0x130(%rsp),%xmm0
   2257d:	00 00 
   2257f:	66 0f 28 d4          	movapd %xmm4,%xmm2
   22583:	f2 0f 5d d0          	minsd  %xmm0,%xmm2
   22587:	66 0f 28 c2          	movapd %xmm2,%xmm0
   2258b:	f2 0f c2 c2 03       	cmpunordsd %xmm2,%xmm0
   22590:	66 0f 54 e0          	andpd  %xmm0,%xmm4
   22594:	66 0f 55 c2          	andnpd %xmm2,%xmm0
   22598:	66 0f 56 c4          	orpd   %xmm4,%xmm0
   2259c:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
   225a0:	0f 87 21 fe ff ff    	ja     223c7 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xa27>
   225a6:	66 0f 10 8c 24 48 01 	movupd 0x148(%rsp),%xmm1
   225ad:	00 00 
   225af:	66 0f 28 9c 24 d0 01 	movapd 0x1d0(%rsp),%xmm3
   225b6:	00 00 
   225b8:	66 0f 28 d3          	movapd %xmm3,%xmm2
   225bc:	66 0f 5d d1          	minpd  %xmm1,%xmm2
   225c0:	66 0f 28 ca          	movapd %xmm2,%xmm1
   225c4:	66 0f c2 ca 03       	cmpunordpd %xmm2,%xmm1
   225c9:	66 0f 54 d9          	andpd  %xmm1,%xmm3
   225cd:	66 0f 55 ca          	andnpd %xmm2,%xmm1
   225d1:	66 0f 56 cb          	orpd   %xmm3,%xmm1
   225d5:	66 0f 28 d0          	movapd %xmm0,%xmm2
   225d9:	66 0f 14 d0          	unpcklpd %xmm0,%xmm2
   225dd:	66 0f c2 ca 01       	cmpltpd %xmm2,%xmm1
   225e2:	66 0f 50 c1          	movmskpd %xmm1,%eax
   225e6:	a8 01                	test   $0x1,%al
   225e8:	0f 85 d9 fd ff ff    	jne    223c7 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xa27>
   225ee:	d0 e8                	shr    $1,%al
   225f0:	0f 85 d1 fd ff ff    	jne    223c7 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xa27>
   225f6:	f2 0f 59 84 24 88 00 	mulsd  0x88(%rsp),%xmm0
   225fd:	00 00 
   225ff:	66 48 0f 7e c0       	movq   %xmm0,%rax
   22604:	48 85 c0             	test   %rax,%rax
   22607:	0f 98 c1             	sets   %cl
   2260a:	49 21 c7             	and    %rax,%r15
   2260d:	48 b8 00 00 00 00 00 	movabs $0xfff0000000000000,%rax
   22614:	00 f0 ff 
   22617:	4c 01 f8             	add    %r15,%rax
   2261a:	48 c1 e8 35          	shr    $0x35,%rax
   2261e:	3d ff 03 00 00       	cmp    $0x3ff,%eax
   22623:	0f 92 c0             	setb   %al
   22626:	20 c8                	and    %cl,%al
   22628:	49 8d 57 ff          	lea    -0x1(%r15),%rdx
   2262c:	48 be ff ff ff ff ff 	movabs $0xfffffffffffff,%rsi
   22633:	ff 0f 00 
   22636:	48 39 f2             	cmp    %rsi,%rdx
   22639:	0f 92 c2             	setb   %dl
   2263c:	20 ca                	and    %cl,%dl
   2263e:	48 b9 00 00 00 00 00 	movabs $0x7ff0000000000000,%rcx
   22645:	00 f0 7f 
   22648:	49 39 cf             	cmp    %rcx,%r15
   2264b:	0f 9f c1             	setg   %cl
   2264e:	40 0f 94 c6          	sete   %sil
   22652:	40 08 ce             	or     %cl,%sil
   22655:	40 08 d6             	or     %dl,%sil
   22658:	40 08 c6             	or     %al,%sil
   2265b:	0f 85 66 fd ff ff    	jne    223c7 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xa27>
   22661:	0f 57 c9             	xorps  %xmm1,%xmm1
   22664:	f2 0f 5a c8          	cvtsd2ss %xmm0,%xmm1
   22668:	0f 28 44 24 40       	movaps 0x40(%rsp),%xmm0
   2266d:	0f 56 05 6c 31 fe ff 	orps   -0x1ce94(%rip),%xmm0        # 57e0 <std::thread::current::id::ID+0x4b68>
   22674:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
   22679:	41 bc 40 00 00 00    	mov    $0x40,%r12d
   2267f:	0f b6 db             	movzbl %bl,%ebx
   22682:	4c 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%r15
   22689:	00 
   2268a:	eb 1b                	jmp    226a7 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xd07>
   2268c:	41 bd 01 00 00 80    	mov    $0x80000001,%r13d
   22692:	66 41 0f 6e cd       	movd   %r13d,%xmm1
   22697:	0f 57 c0             	xorps  %xmm0,%xmm0
   2269a:	f3 0f 5f c8          	maxss  %xmm0,%xmm1
   2269e:	41 ff cc             	dec    %r12d
   226a1:	0f 84 20 fd ff ff    	je     223c7 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xa27>
   226a7:	66 41 0f 7e cd       	movd   %xmm1,%r13d
   226ac:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   226b2:	f3 0f 11 84 24 a0 00 	movss  %xmm0,0xa0(%rsp)
   226b9:	00 00 
   226bb:	f3 0f 11 4c 24 10    	movss  %xmm1,0x10(%rsp)
   226c1:	f3 0f 11 8c 24 a4 00 	movss  %xmm1,0xa4(%rsp)
   226c8:	00 00 
   226ca:	0f 28 44 24 40       	movaps 0x40(%rsp),%xmm0
   226cf:	f3 0f 11 84 24 a8 00 	movss  %xmm0,0xa8(%rsp)
   226d6:	00 00 
   226d8:	c7 84 24 ac 00 00 00 	movl   $0xff800000,0xac(%rsp)
   226df:	00 00 80 ff 
   226e3:	4c 89 ff             	mov    %r15,%rdi
   226e6:	89 de                	mov    %ebx,%esi
   226e8:	e8 53 00 00 00       	call   22740 <gpui_canvas::color::gamut::in_gamut>
   226ed:	84 c0                	test   %al,%al
   226ef:	75 2e                	jne    2271f <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xd7f>
   226f1:	41 81 fd 00 00 80 ff 	cmp    $0xff800000,%r13d
   226f8:	66 0f 6e 4c 24 10    	movd   0x10(%rsp),%xmm1
   226fe:	74 97                	je     22697 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xcf7>
   22700:	44 89 e8             	mov    %r13d,%eax
   22703:	25 ff ff ff 7f       	and    $0x7fffffff,%eax
   22708:	74 82                	je     2268c <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xcec>
   2270a:	41 39 c5             	cmp    %eax,%r13d
   2270d:	75 08                	jne    22717 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xd77>
   2270f:	41 ff cd             	dec    %r13d
   22712:	e9 7b ff ff ff       	jmp    22692 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xcf2>
   22717:	41 ff c5             	inc    %r13d
   2271a:	e9 73 ff ff ff       	jmp    22692 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xcf2>
   2271f:	49 c1 e5 20          	shl    $0x20,%r13
   22723:	41 be ff ff ff ff    	mov    $0xffffffff,%r14d
   22729:	4d 09 ee             	or     %r13,%r14
   2272c:	e9 96 fc ff ff       	jmp    223c7 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xa27>
   22731:	cc                   	int3
   22732:	cc                   	int3
   22733:	cc                   	int3
   22734:	cc                   	int3
   22735:	cc                   	int3
   22736:	cc                   	int3
   22737:	cc                   	int3
   22738:	cc                   	int3
   22739:	cc                   	int3
   2273a:	cc                   	int3
   2273b:	cc                   	int3
   2273c:	cc                   	int3
   2273d:	cc                   	int3
   2273e:	cc                   	int3
   2273f:	cc                   	int3

gpui_canvas::color::gamut::in_gamut:
   22740:	55                   	push   %rbp
   22741:	53                   	push   %rbx
   22742:	48 83 ec 68          	sub    $0x68,%rsp
   22746:	89 f3                	mov    %esi,%ebx
   22748:	f3 0f 7e 0f          	movq   (%rdi),%xmm1
   2274c:	8b 4f 08             	mov    0x8(%rdi),%ecx
   2274f:	8b 57 0c             	mov    0xc(%rdi),%edx
   22752:	89 c8                	mov    %ecx,%eax
   22754:	81 fa 00 00 00 c0    	cmp    $0xc0000000,%edx
   2275a:	0f 82 ea 00 00 00    	jb     2284a <gpui_canvas::color::gamut::in_gamut+0x10a>
   22760:	89 c8                	mov    %ecx,%eax
   22762:	85 c9                	test   %ecx,%ecx
   22764:	0f 88 db 00 00 00    	js     22845 <gpui_canvas::color::gamut::in_gamut+0x105>
   2276a:	c1 e8 08             	shr    $0x8,%eax
   2276d:	89 ce                	mov    %ecx,%esi
   2276f:	48 69 f6 8f e7 54 52 	imul   $0x5254e78f,%rsi,%rsi
   22776:	48 c1 ee 2e          	shr    $0x2e,%rsi
   2277a:	48 69 f8 09 a8 a7 01 	imul   $0x1a7a809,%rax,%rdi
   22781:	48 c1 ef 20          	shr    $0x20,%rdi
   22785:	66 41 0f 7e c9       	movd   %xmm1,%r9d
   2278a:	45 89 ca             	mov    %r9d,%r10d
   2278d:	41 c1 e2 08          	shl    $0x8,%r10d
   22791:	66 0f 70 c1 55       	pshufd $0x55,%xmm1,%xmm0
   22796:	66 41 0f 7e c0       	movd   %xmm0,%r8d
   2279b:	45 89 c3             	mov    %r8d,%r11d
   2279e:	45 0f a4 cb 08       	shld   $0x8,%r9d,%r11d
   227a3:	69 ee 55 52 00 00    	imul   $0x5255,%esi,%ebp
   227a9:	c1 ed 16             	shr    $0x16,%ebp
   227ac:	69 ed c7 00 00 00    	imul   $0xc7,%ebp,%ebp
   227b2:	29 ee                	sub    %ebp,%esi
   227b4:	44 89 dd             	mov    %r11d,%ebp
   227b7:	c1 e5 08             	shl    $0x8,%ebp
   227ba:	41 81 e3 ff ff 7f 00 	and    $0x7fffff,%r11d
   227c1:	41 81 e2 00 00 00 80 	and    $0x80000000,%r10d
   227c8:	81 e5 00 00 00 80    	and    $0x80000000,%ebp
   227ce:	44 09 dd             	or     %r11d,%ebp
   227d1:	41 81 e1 ff ff 7f 00 	and    $0x7fffff,%r9d
   227d8:	45 09 d1             	or     %r10d,%r9d
   227db:	c1 e6 17             	shl    $0x17,%esi
   227de:	09 ee                	or     %ebp,%esi
   227e0:	c1 e7 0f             	shl    $0xf,%edi
   227e3:	81 e7 00 00 80 ff    	and    $0xff800000,%edi
   227e9:	41 0f ac c8 10       	shrd   $0x10,%ecx,%r8d
   227ee:	44 09 cf             	or     %r9d,%edi
   227f1:	4c 69 c8 9f 53 49 01 	imul   $0x149539f,%rax,%r9
   227f8:	49 c1 e9 20          	shr    $0x20,%r9
   227fc:	45 69 c9 c7 00 00 00 	imul   $0xc7,%r9d,%r9d
   22803:	44 29 c8             	sub    %r9d,%eax
   22806:	45 89 c1             	mov    %r8d,%r9d
   22809:	41 81 e1 ff ff 7f 00 	and    $0x7fffff,%r9d
   22810:	41 c1 e0 08          	shl    $0x8,%r8d
   22814:	41 81 e0 00 00 00 80 	and    $0x80000000,%r8d
   2281b:	45 09 c8             	or     %r9d,%r8d
   2281e:	c1 e0 17             	shl    $0x17,%eax
   22821:	44 09 c0             	or     %r8d,%eax
   22824:	66 0f 6e c6          	movd   %esi,%xmm0
   22828:	66 0f 6e cf          	movd   %edi,%xmm1
   2282c:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
   22830:	c1 ea 1e             	shr    $0x1e,%edx
   22833:	31 ed                	xor    %ebp,%ebp
   22835:	48 8d 35 a0 4d fe ff 	lea    -0x1b260(%rip),%rsi        # 75dc <std::thread::current::id::ID+0x6964>
   2283c:	48 63 14 96          	movslq (%rsi,%rdx,4),%rdx
   22840:	48 01 f2             	add    %rsi,%rdx
   22843:	ff e2                	jmp    *%rdx
   22845:	25 ff ff ff 7f       	and    $0x7fffffff,%eax
   2284a:	c1 ea 1e             	shr    $0x1e,%edx
   2284d:	31 ed                	xor    %ebp,%ebp
   2284f:	48 8d 35 86 4d fe ff 	lea    -0x1b27a(%rip),%rsi        # 75dc <std::thread::current::id::ID+0x6964>
   22856:	48 63 14 96          	movslq (%rsi,%rdx,4),%rdx
   2285a:	48 01 f2             	add    %rsi,%rdx
   2285d:	ff e2                	jmp    *%rdx
   2285f:	40 b5 01             	mov    $0x1,%bpl
   22862:	f3 0f 5a e9          	cvtss2sd %xmm1,%xmm5
   22866:	66 0f 70 f1 55       	pshufd $0x55,%xmm1,%xmm6
   2286b:	f3 0f 5a e6          	cvtss2sd %xmm6,%xmm4
   2286f:	66 0f 6e d0          	movd   %eax,%xmm2
   22873:	0f 28 05 a6 29 fe ff 	movaps -0x1d65a(%rip),%xmm0        # 5220 <std::thread::current::id::ID+0x45a8>
   2287a:	0f 54 c5             	andps  %xmm5,%xmm0
   2287d:	f2 0f 10 1d 9b 49 fe 	movsd  -0x1b665(%rip),%xmm3        # 7220 <std::thread::current::id::ID+0x65a8>
   22884:	ff 
   22885:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   22889:	66 0f 7e 54 24 30    	movd   %xmm2,0x30(%rsp)
   2288f:	73 53                	jae    228e4 <gpui_canvas::color::gamut::in_gamut+0x1a4>
   22891:	0f 2e c9             	ucomiss %xmm1,%xmm1
   22894:	0f 29 64 24 10       	movaps %xmm4,0x10(%rsp)
   22899:	0f 29 74 24 50       	movaps %xmm6,0x50(%rsp)
   2289e:	7a 4e                	jp     228ee <gpui_canvas::color::gamut::in_gamut+0x1ae>
   228a0:	0f 54 2d e9 2e fe ff 	andps  -0x1d117(%rip),%xmm5        # 5790 <std::thread::current::id::ID+0x4b18>
   228a7:	0f 56 2d f2 2d fe ff 	orps   -0x1d20e(%rip),%xmm5        # 56a0 <std::thread::current::id::ID+0x4a28>
   228ae:	0f 29 2c 24          	movaps %xmm5,(%rsp)
   228b2:	eb 46                	jmp    228fa <gpui_canvas::color::gamut::in_gamut+0x1ba>
   228b4:	0f 5a e9             	cvtps2pd %xmm1,%xmm5
   228b7:	66 0f 6e c0          	movd   %eax,%xmm0
   228bb:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   228bf:	e9 ad 01 00 00       	jmp    22a71 <gpui_canvas::color::gamut::in_gamut+0x331>
   228c4:	85 c9                	test   %ecx,%ecx
   228c6:	0f 88 86 02 00 00    	js     22b52 <gpui_canvas::color::gamut::in_gamut+0x412>
   228cc:	0f 5a e9             	cvtps2pd %xmm1,%xmm5
   228cf:	66 0f 6e c0          	movd   %eax,%xmm0
   228d3:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   228d7:	84 db                	test   %bl,%bl
   228d9:	0f 84 5e 02 00 00    	je     22b3d <gpui_canvas::color::gamut::in_gamut+0x3fd>
   228df:	e9 a7 02 00 00       	jmp    22b8b <gpui_canvas::color::gamut::in_gamut+0x44b>
   228e4:	f2 0f 5e 2d 94 48 fe 	divsd  -0x1b76c(%rip),%xmm5        # 7180 <std::thread::current::id::ID+0x6508>
   228eb:	ff 
   228ec:	eb 4b                	jmp    22939 <gpui_canvas::color::gamut::in_gamut+0x1f9>
   228ee:	f2 0f 10 0d ea 49 fe 	movsd  -0x1b616(%rip),%xmm1        # 72e0 <std::thread::current::id::ID+0x6668>
   228f5:	ff 
   228f6:	0f 29 0c 24          	movaps %xmm1,(%rsp)
   228fa:	f2 0f 58 05 a6 4a fe 	addsd  -0x1b55a(%rip),%xmm0        # 73a8 <std::thread::current::id::ID+0x6730>
   22901:	ff 
   22902:	f2 0f 5e 05 f6 49 fe 	divsd  -0x1b60a(%rip),%xmm0        # 7300 <std::thread::current::id::ID+0x6688>
   22909:	ff 
   2290a:	f2 0f 10 0d 86 49 fe 	movsd  -0x1b67a(%rip),%xmm1        # 7298 <std::thread::current::id::ID+0x6620>
   22911:	ff 
   22912:	ff 15 d8 2d 04 00    	call   *0x42dd8(%rip)        # 656f0 <pow@GLIBC_2.29>
   22918:	66 0f 28 e8          	movapd %xmm0,%xmm5
   2291c:	f2 0f 59 2c 24       	mulsd  (%rsp),%xmm5
   22921:	66 0f 6e 54 24 30    	movd   0x30(%rsp),%xmm2
   22927:	f2 0f 10 1d f1 48 fe 	movsd  -0x1b70f(%rip),%xmm3        # 7220 <std::thread::current::id::ID+0x65a8>
   2292e:	ff 
   2292f:	0f 28 64 24 10       	movaps 0x10(%rsp),%xmm4
   22934:	0f 28 74 24 50       	movaps 0x50(%rsp),%xmm6
   22939:	0f 57 c9             	xorps  %xmm1,%xmm1
   2293c:	f3 0f 5a ca          	cvtss2sd %xmm2,%xmm1
   22940:	0f 28 05 d9 28 fe ff 	movaps -0x1d727(%rip),%xmm0        # 5220 <std::thread::current::id::ID+0x45a8>
   22947:	0f 54 c4             	andps  %xmm4,%xmm0
   2294a:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   2294e:	66 0f 29 2c 24       	movapd %xmm5,(%rsp)
   22953:	73 1f                	jae    22974 <gpui_canvas::color::gamut::in_gamut+0x234>
   22955:	0f 2e f6             	ucomiss %xmm6,%xmm6
   22958:	0f 29 4c 24 20       	movaps %xmm1,0x20(%rsp)
   2295d:	7a 4b                	jp     229aa <gpui_canvas::color::gamut::in_gamut+0x26a>
   2295f:	0f 54 25 2a 2e fe ff 	andps  -0x1d1d6(%rip),%xmm4        # 5790 <std::thread::current::id::ID+0x4b18>
   22966:	0f 56 25 33 2d fe ff 	orps   -0x1d2cd(%rip),%xmm4        # 56a0 <std::thread::current::id::ID+0x4a28>
   2296d:	0f 29 64 24 10       	movaps %xmm4,0x10(%rsp)
   22972:	eb 43                	jmp    229b7 <gpui_canvas::color::gamut::in_gamut+0x277>
   22974:	f2 0f 5e 25 04 48 fe 	divsd  -0x1b7fc(%rip),%xmm4        # 7180 <std::thread::current::id::ID+0x6508>
   2297b:	ff 
   2297c:	0f 28 05 9d 28 fe ff 	movaps -0x1d763(%rip),%xmm0        # 5220 <std::thread::current::id::ID+0x45a8>
   22983:	0f 54 c1             	andps  %xmm1,%xmm0
   22986:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   2298a:	72 7e                	jb     22a0a <gpui_canvas::color::gamut::in_gamut+0x2ca>
   2298c:	f2 0f 5e 0d ec 47 fe 	divsd  -0x1b814(%rip),%xmm1        # 7180 <std::thread::current::id::ID+0x6508>
   22993:	ff 
   22994:	66 0f 28 c1          	movapd %xmm1,%xmm0
   22998:	66 0f 14 ec          	unpcklpd %xmm4,%xmm5
   2299c:	40 84 ed             	test   %bpl,%bpl
   2299f:	0f 85 cc 00 00 00    	jne    22a71 <gpui_canvas::color::gamut::in_gamut+0x331>
   229a5:	e9 8f 01 00 00       	jmp    22b39 <gpui_canvas::color::gamut::in_gamut+0x3f9>
   229aa:	f2 0f 10 0d 2e 49 fe 	movsd  -0x1b6d2(%rip),%xmm1        # 72e0 <std::thread::current::id::ID+0x6668>
   229b1:	ff 
   229b2:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
   229b7:	f2 0f 58 05 e9 49 fe 	addsd  -0x1b617(%rip),%xmm0        # 73a8 <std::thread::current::id::ID+0x6730>
   229be:	ff 
   229bf:	f2 0f 5e 05 39 49 fe 	divsd  -0x1b6c7(%rip),%xmm0        # 7300 <std::thread::current::id::ID+0x6688>
   229c6:	ff 
   229c7:	f2 0f 10 0d c9 48 fe 	movsd  -0x1b737(%rip),%xmm1        # 7298 <std::thread::current::id::ID+0x6620>
   229ce:	ff 
   229cf:	ff 15 1b 2d 04 00    	call   *0x42d1b(%rip)        # 656f0 <pow@GLIBC_2.29>
   229d5:	66 0f 28 e0          	movapd %xmm0,%xmm4
   229d9:	f2 0f 59 64 24 10    	mulsd  0x10(%rsp),%xmm4
   229df:	66 0f 28 2c 24       	movapd (%rsp),%xmm5
   229e4:	f3 0f 10 54 24 30    	movss  0x30(%rsp),%xmm2
   229ea:	f2 0f 10 1d 2e 48 fe 	movsd  -0x1b7d2(%rip),%xmm3        # 7220 <std::thread::current::id::ID+0x65a8>
   229f1:	ff 
   229f2:	66 0f 28 4c 24 20    	movapd 0x20(%rsp),%xmm1
   229f8:	66 0f 28 05 20 28 fe 	movapd -0x1d7e0(%rip),%xmm0        # 5220 <std::thread::current::id::ID+0x45a8>
   229ff:	ff 
   22a00:	66 0f 54 c1          	andpd  %xmm1,%xmm0
   22a04:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   22a08:	73 82                	jae    2298c <gpui_canvas::color::gamut::in_gamut+0x24c>
   22a0a:	0f 2e d2             	ucomiss %xmm2,%xmm2
   22a0d:	66 0f 29 64 24 10    	movapd %xmm4,0x10(%rsp)
   22a13:	7a 12                	jp     22a27 <gpui_canvas::color::gamut::in_gamut+0x2e7>
   22a15:	66 0f 54 0d 73 2d fe 	andpd  -0x1d28d(%rip),%xmm1        # 5790 <std::thread::current::id::ID+0x4b18>
   22a1c:	ff 
   22a1d:	66 0f 56 0d 7b 2c fe 	orpd   -0x1d385(%rip),%xmm1        # 56a0 <std::thread::current::id::ID+0x4a28>
   22a24:	ff 
   22a25:	eb 08                	jmp    22a2f <gpui_canvas::color::gamut::in_gamut+0x2ef>
   22a27:	f2 0f 10 0d b1 48 fe 	movsd  -0x1b74f(%rip),%xmm1        # 72e0 <std::thread::current::id::ID+0x6668>
   22a2e:	ff 
   22a2f:	66 0f 29 4c 24 20    	movapd %xmm1,0x20(%rsp)
   22a35:	f2 0f 58 05 6b 49 fe 	addsd  -0x1b695(%rip),%xmm0        # 73a8 <std::thread::current::id::ID+0x6730>
   22a3c:	ff 
   22a3d:	f2 0f 5e 05 bb 48 fe 	divsd  -0x1b745(%rip),%xmm0        # 7300 <std::thread::current::id::ID+0x6688>
   22a44:	ff 
   22a45:	f2 0f 10 0d 4b 48 fe 	movsd  -0x1b7b5(%rip),%xmm1        # 7298 <std::thread::current::id::ID+0x6620>
   22a4c:	ff 
   22a4d:	ff 15 9d 2c 04 00    	call   *0x42c9d(%rip)        # 656f0 <pow@GLIBC_2.29>
   22a53:	f2 0f 59 44 24 20    	mulsd  0x20(%rsp),%xmm0
   22a59:	66 0f 28 2c 24       	movapd (%rsp),%xmm5
   22a5e:	66 0f 28 64 24 10    	movapd 0x10(%rsp),%xmm4
   22a64:	66 0f 14 ec          	unpcklpd %xmm4,%xmm5
   22a68:	40 84 ed             	test   %bpl,%bpl
   22a6b:	0f 84 c8 00 00 00    	je     22b39 <gpui_canvas::color::gamut::in_gamut+0x3f9>
   22a71:	66 0f 28 d5          	movapd %xmm5,%xmm2
   22a75:	66 0f c6 d5 01       	shufpd $0x1,%xmm5,%xmm2
   22a7a:	66 0f 59 15 3e 2c fe 	mulpd  -0x1d3c2(%rip),%xmm2        # 56c0 <std::thread::current::id::ID+0x4a48>
   22a81:	ff 
   22a82:	66 0f 57 db          	xorpd  %xmm3,%xmm3
   22a86:	66 0f 16 1d f2 48 fe 	movhpd -0x1b70e(%rip),%xmm3        # 7380 <std::thread::current::id::ID+0x6708>
   22a8d:	ff 
   22a8e:	66 0f 59 dd          	mulpd  %xmm5,%xmm3
   22a92:	0f 28 c8             	movaps %xmm0,%xmm1
   22a95:	0f 16 c8             	movlhps %xmm0,%xmm1
   22a98:	66 0f 59 0d a0 27 fe 	mulpd  -0x1d860(%rip),%xmm1        # 5240 <std::thread::current::id::ID+0x45c8>
   22a9f:	ff 
   22aa0:	66 0f 58 da          	addpd  %xmm2,%xmm3
   22aa4:	66 0f 58 cb          	addpd  %xmm3,%xmm1
   22aa8:	f2 0f 10 15 28 47 fe 	movsd  -0x1b8d8(%rip),%xmm2        # 71d8 <std::thread::current::id::ID+0x6560>
   22aaf:	ff 
   22ab0:	f2 0f 59 d5          	mulsd  %xmm5,%xmm2
   22ab4:	f2 0f 10 e8          	movsd  %xmm0,%xmm5
   22ab8:	66 0f 59 2d a0 27 fe 	mulpd  -0x1d860(%rip),%xmm5        # 5260 <std::thread::current::id::ID+0x45e8>
   22abf:	ff 
   22ac0:	66 0f 28 c5          	movapd %xmm5,%xmm0
   22ac4:	66 0f 15 c5          	unpckhpd %xmm5,%xmm0
   22ac8:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   22acc:	f2 0f 58 c5          	addsd  %xmm5,%xmm0
   22ad0:	f2 0f 10 15 c0 46 fe 	movsd  -0x1b940(%rip),%xmm2        # 7198 <std::thread::current::id::ID+0x6520>
   22ad7:	ff 
   22ad8:	66 0f 28 d9          	movapd %xmm1,%xmm3
   22adc:	f2 0f 10 d8          	movsd  %xmm0,%xmm3
   22ae0:	66 0f 59 1d 98 2a fe 	mulpd  -0x1d568(%rip),%xmm3        # 5580 <std::thread::current::id::ID+0x4908>
   22ae7:	ff 
   22ae8:	66 0f 28 e1          	movapd %xmm1,%xmm4
   22aec:	66 0f c6 e0 01       	shufpd $0x1,%xmm0,%xmm4
   22af1:	66 0f 59 25 b7 29 fe 	mulpd  -0x1d649(%rip),%xmm4        # 54b0 <std::thread::current::id::ID+0x4838>
   22af8:	ff 
   22af9:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
   22afd:	66 0f 58 e3          	addpd  %xmm3,%xmm4
   22b01:	66 0f 28 e9          	movapd %xmm1,%xmm5
   22b05:	66 0f 14 e9          	unpcklpd %xmm1,%xmm5
   22b09:	66 0f 59 2d 8f 2c fe 	mulpd  -0x1d371(%rip),%xmm5        # 57a0 <std::thread::current::id::ID+0x4b28>
   22b10:	ff 
   22b11:	66 0f 28 c4          	movapd %xmm4,%xmm0
   22b15:	66 0f 5c c5          	subpd  %xmm5,%xmm0
   22b19:	66 0f 58 ec          	addpd  %xmm4,%xmm5
   22b1d:	f2 0f 10 e8          	movsd  %xmm0,%xmm5
   22b21:	66 0f 59 0d 37 2a fe 	mulpd  -0x1d5c9(%rip),%xmm1        # 5560 <std::thread::current::id::ID+0x48e8>
   22b28:	ff 
   22b29:	66 0f 28 c1          	movapd %xmm1,%xmm0
   22b2d:	66 0f 15 c1          	unpckhpd %xmm1,%xmm0
   22b31:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   22b35:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
   22b39:	84 db                	test   %bl,%bl
   22b3b:	75 4e                	jne    22b8b <gpui_canvas::color::gamut::in_gamut+0x44b>
   22b3d:	31 c0                	xor    %eax,%eax
   22b3f:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   22b43:	66 0f 2e e9          	ucomisd %xmm1,%xmm5
   22b47:	0f 83 08 01 00 00    	jae    22c55 <gpui_canvas::color::gamut::in_gamut+0x515>
   22b4d:	e9 41 01 00 00       	jmp    22c93 <gpui_canvas::color::gamut::in_gamut+0x553>
   22b52:	66 0f 6f d1          	movdqa %xmm1,%xmm2
   22b56:	0f c6 c9 55          	shufps $0x55,%xmm1,%xmm1
   22b5a:	66 0f ef c0          	pxor   %xmm0,%xmm0
   22b5e:	0f 2e c8             	ucomiss %xmm0,%xmm1
   22b61:	0f 85 35 01 00 00    	jne    22c9c <gpui_canvas::color::gamut::in_gamut+0x55c>
   22b67:	0f 8a 2f 01 00 00    	jp     22c9c <gpui_canvas::color::gamut::in_gamut+0x55c>
   22b6d:	0f 57 c9             	xorps  %xmm1,%xmm1
   22b70:	f3 0f 5a ca          	cvtss2sd %xmm2,%xmm1
   22b74:	0f 28 c1             	movaps %xmm1,%xmm0
   22b77:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   22b7b:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   22b7f:	66 0f 28 e8          	movapd %xmm0,%xmm5
   22b83:	66 0f 14 e8          	unpcklpd %xmm0,%xmm5
   22b87:	84 db                	test   %bl,%bl
   22b89:	74 b2                	je     22b3d <gpui_canvas::color::gamut::in_gamut+0x3fd>
   22b8b:	66 0f 28 0d 3d 27 fe 	movapd -0x1d8c3(%rip),%xmm1        # 52d0 <std::thread::current::id::ID+0x4658>
   22b92:	ff 
   22b93:	66 0f 59 cd          	mulpd  %xmm5,%xmm1
   22b97:	66 0f 28 d5          	movapd %xmm5,%xmm2
   22b9b:	66 0f c6 d5 01       	shufpd $0x1,%xmm5,%xmm2
   22ba0:	66 0f 59 15 78 2b fe 	mulpd  -0x1d488(%rip),%xmm2        # 5720 <std::thread::current::id::ID+0x4aa8>
   22ba7:	ff 
   22ba8:	66 0f 58 d1          	addpd  %xmm1,%xmm2
   22bac:	66 0f 28 c8          	movapd %xmm0,%xmm1
   22bb0:	66 0f 14 c8          	unpcklpd %xmm0,%xmm1
   22bb4:	66 0f 59 0d e4 27 fe 	mulpd  -0x1d81c(%rip),%xmm1        # 53a0 <std::thread::current::id::ID+0x4728>
   22bbb:	ff 
   22bbc:	f2 0f 10 1d 6c 46 fe 	movsd  -0x1b994(%rip),%xmm3        # 7230 <std::thread::current::id::ID+0x65b8>
   22bc3:	ff 
   22bc4:	f2 0f 59 dd          	mulsd  %xmm5,%xmm3
   22bc8:	f2 0f 10 e8          	movsd  %xmm0,%xmm5
   22bcc:	66 0f 59 2d ec 27 fe 	mulpd  -0x1d814(%rip),%xmm5        # 53c0 <std::thread::current::id::ID+0x4748>
   22bd3:	ff 
   22bd4:	66 0f 58 ca          	addpd  %xmm2,%xmm1
   22bd8:	66 0f 28 c5          	movapd %xmm5,%xmm0
   22bdc:	66 0f 15 c5          	unpckhpd %xmm5,%xmm0
   22be0:	f2 0f 58 c3          	addsd  %xmm3,%xmm0
   22be4:	66 0f 28 d1          	movapd %xmm1,%xmm2
   22be8:	66 0f c6 d1 01       	shufpd $0x1,%xmm1,%xmm2
   22bed:	66 0f 59 15 5b 26 fe 	mulpd  -0x1d9a5(%rip),%xmm2        # 5250 <std::thread::current::id::ID+0x45d8>
   22bf4:	ff 
   22bf5:	f2 0f 58 c5          	addsd  %xmm5,%xmm0
   22bf9:	66 0f 28 1d af 26 fe 	movapd -0x1d951(%rip),%xmm3        # 52b0 <std::thread::current::id::ID+0x4638>
   22c00:	ff 
   22c01:	66 0f 59 d9          	mulpd  %xmm1,%xmm3
   22c05:	66 0f 5c da          	subpd  %xmm2,%xmm3
   22c09:	66 0f 28 e8          	movapd %xmm0,%xmm5
   22c0d:	66 0f 14 e8          	unpcklpd %xmm0,%xmm5
   22c11:	66 0f 59 2d 57 27 fe 	mulpd  -0x1d8a9(%rip),%xmm5        # 5370 <std::thread::current::id::ID+0x46f8>
   22c18:	ff 
   22c19:	66 0f 28 d3          	movapd %xmm3,%xmm2
   22c1d:	66 0f 5c d5          	subpd  %xmm5,%xmm2
   22c21:	66 0f 58 eb          	addpd  %xmm3,%xmm5
   22c25:	f2 0f 10 ea          	movsd  %xmm2,%xmm5
   22c29:	66 0f 59 0d df 29 fe 	mulpd  -0x1d621(%rip),%xmm1        # 5610 <std::thread::current::id::ID+0x4998>
   22c30:	ff 
   22c31:	66 0f 28 d1          	movapd %xmm1,%xmm2
   22c35:	66 0f 15 d1          	unpckhpd %xmm1,%xmm2
   22c39:	f2 0f 5c ca          	subsd  %xmm2,%xmm1
   22c3d:	f2 0f 59 05 93 46 fe 	mulsd  -0x1b96d(%rip),%xmm0        # 72d8 <std::thread::current::id::ID+0x6660>
   22c44:	ff 
   22c45:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
   22c49:	31 c0                	xor    %eax,%eax
   22c4b:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   22c4f:	66 0f 2e e9          	ucomisd %xmm1,%xmm5
   22c53:	72 3e                	jb     22c93 <gpui_canvas::color::gamut::in_gamut+0x553>
   22c55:	f2 0f 10 0d eb 45 fe 	movsd  -0x1ba15(%rip),%xmm1        # 7248 <std::thread::current::id::ID+0x65d0>
   22c5c:	ff 
   22c5d:	66 0f 2e cd          	ucomisd %xmm5,%xmm1
   22c61:	72 30                	jb     22c93 <gpui_canvas::color::gamut::in_gamut+0x553>
   22c63:	66 0f 15 ed          	unpckhpd %xmm5,%xmm5
   22c67:	31 c0                	xor    %eax,%eax
   22c69:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   22c6d:	66 0f 2e ea          	ucomisd %xmm2,%xmm5
   22c71:	72 20                	jb     22c93 <gpui_canvas::color::gamut::in_gamut+0x553>
   22c73:	66 0f 2e cd          	ucomisd %xmm5,%xmm1
   22c77:	72 1a                	jb     22c93 <gpui_canvas::color::gamut::in_gamut+0x553>
   22c79:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   22c7d:	f2 0f c2 c8 02       	cmplesd %xmm0,%xmm1
   22c82:	f2 0f c2 05 bd 45 fe 	cmplesd -0x1ba43(%rip),%xmm0        # 7248 <std::thread::current::id::ID+0x65d0>
   22c89:	ff 02 
   22c8b:	66 0f 54 c1          	andpd  %xmm1,%xmm0
   22c8f:	66 0f 7e c0          	movd   %xmm0,%eax
   22c93:	24 01                	and    $0x1,%al
   22c95:	48 83 c4 68          	add    $0x68,%rsp
   22c99:	5b                   	pop    %rbx
   22c9a:	5d                   	pop    %rbp
   22c9b:	c3                   	ret
   22c9c:	66 0f 6e c0          	movd   %eax,%xmm0
   22ca0:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   22ca4:	f2 0f 59 05 cc 46 fe 	mulsd  -0x1b934(%rip),%xmm0        # 7378 <std::thread::current::id::ID+0x6700>
   22cab:	ff 
   22cac:	48 8d 7c 24 48       	lea    0x48(%rsp),%rdi
   22cb1:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
   22cb6:	0f 29 0c 24          	movaps %xmm1,(%rsp)
   22cba:	66 0f 7f 54 24 30    	movdqa %xmm2,0x30(%rsp)
   22cc0:	ff 15 5a 2a 04 00    	call   *0x42a5a(%rip)        # 65720 <sincos@GLIBC_2.2.5>
   22cc6:	0f 28 44 24 30       	movaps 0x30(%rsp),%xmm0
   22ccb:	0f 57 c9             	xorps  %xmm1,%xmm1
   22cce:	f3 0f 5a c8          	cvtss2sd %xmm0,%xmm1
   22cd2:	0f 28 04 24          	movaps (%rsp),%xmm0
   22cd6:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   22cda:	f2 0f 10 54 24 40    	movsd  0x40(%rsp),%xmm2
   22ce0:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
   22ce4:	f2 0f 59 44 24 48    	mulsd  0x48(%rsp),%xmm0
   22cea:	f2 0f 10 1d 5e 46 fe 	movsd  -0x1b9a2(%rip),%xmm3        # 7350 <std::thread::current::id::ID+0x66d8>
   22cf1:	ff 
   22cf2:	f2 0f 59 da          	mulsd  %xmm2,%xmm3
   22cf6:	f2 0f 58 d9          	addsd  %xmm1,%xmm3
   22cfa:	f2 0f 10 2d e6 45 fe 	movsd  -0x1ba1a(%rip),%xmm5        # 72e8 <std::thread::current::id::ID+0x6670>
   22d01:	ff 
   22d02:	f2 0f 59 e8          	mulsd  %xmm0,%xmm5
   22d06:	f2 0f 58 eb          	addsd  %xmm3,%xmm5
   22d0a:	f2 0f 10 1d 96 45 fe 	movsd  -0x1ba6a(%rip),%xmm3        # 72a8 <std::thread::current::id::ID+0x6630>
   22d11:	ff 
   22d12:	f2 0f 59 da          	mulsd  %xmm2,%xmm3
   22d16:	f2 0f 58 d9          	addsd  %xmm1,%xmm3
   22d1a:	f2 0f 10 35 8e 46 fe 	movsd  -0x1b972(%rip),%xmm6        # 73b0 <std::thread::current::id::ID+0x6738>
   22d21:	ff 
   22d22:	f2 0f 59 f0          	mulsd  %xmm0,%xmm6
   22d26:	f2 0f 58 f3          	addsd  %xmm3,%xmm6
   22d2a:	f2 0f 59 15 06 46 fe 	mulsd  -0x1b9fa(%rip),%xmm2        # 7338 <std::thread::current::id::ID+0x66c0>
   22d31:	ff 
   22d32:	f2 0f 58 d1          	addsd  %xmm1,%xmm2
   22d36:	f2 0f 59 05 4a 44 fe 	mulsd  -0x1bbb6(%rip),%xmm0        # 7188 <std::thread::current::id::ID+0x6510>
   22d3d:	ff 
   22d3e:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   22d42:	66 0f 28 e5          	movapd %xmm5,%xmm4
   22d46:	f2 0f 59 e5          	mulsd  %xmm5,%xmm4
   22d4a:	f2 0f 59 e5          	mulsd  %xmm5,%xmm4
   22d4e:	66 0f 28 de          	movapd %xmm6,%xmm3
   22d52:	f2 0f 59 de          	mulsd  %xmm6,%xmm3
   22d56:	f2 0f 59 de          	mulsd  %xmm6,%xmm3
   22d5a:	66 0f 28 c8          	movapd %xmm0,%xmm1
   22d5e:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   22d62:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   22d66:	f2 0f 10 05 4a 46 fe 	movsd  -0x1b9b6(%rip),%xmm0        # 73b8 <std::thread::current::id::ID+0x6740>
   22d6d:	ff 
   22d6e:	f2 0f 59 c4          	mulsd  %xmm4,%xmm0
   22d72:	f2 0f 10 15 e6 44 fe 	movsd  -0x1bb1a(%rip),%xmm2        # 7260 <std::thread::current::id::ID+0x65e8>
   22d79:	ff 
   22d7a:	f2 0f 59 d3          	mulsd  %xmm3,%xmm2
   22d7e:	f2 0f 58 d0          	addsd  %xmm0,%xmm2
   22d82:	f2 0f 10 05 de 44 fe 	movsd  -0x1bb22(%rip),%xmm0        # 7268 <std::thread::current::id::ID+0x65f0>
   22d89:	ff 
   22d8a:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   22d8e:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   22d92:	f2 0f 10 15 fe 43 fe 	movsd  -0x1bc02(%rip),%xmm2        # 7198 <std::thread::current::id::ID+0x6520>
   22d99:	ff 
   22d9a:	66 0f 14 e4          	unpcklpd %xmm4,%xmm4
   22d9e:	66 0f 59 25 ba 29 fe 	mulpd  -0x1d646(%rip),%xmm4        # 5760 <std::thread::current::id::ID+0x4ae8>
   22da5:	ff 
   22da6:	66 0f 14 db          	unpcklpd %xmm3,%xmm3
   22daa:	66 0f 59 1d be 29 fe 	mulpd  -0x1d642(%rip),%xmm3        # 5770 <std::thread::current::id::ID+0x4af8>
   22db1:	ff 
   22db2:	66 0f 58 dc          	addpd  %xmm4,%xmm3
   22db6:	66 0f 14 c9          	unpcklpd %xmm1,%xmm1
   22dba:	66 0f 59 0d 8e 27 fe 	mulpd  -0x1d872(%rip),%xmm1        # 5550 <std::thread::current::id::ID+0x48d8>
   22dc1:	ff 
   22dc2:	66 0f 58 cb          	addpd  %xmm3,%xmm1
   22dc6:	e9 0d fd ff ff       	jmp    22ad8 <gpui_canvas::color::gamut::in_gamut+0x398>

