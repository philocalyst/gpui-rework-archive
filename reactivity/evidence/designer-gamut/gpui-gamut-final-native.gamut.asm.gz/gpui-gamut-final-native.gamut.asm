<gpui_canvas::color::OutputProfile>::max_chroma:
   1f640:	66 0f 7e c1          	movd   %xmm0,%ecx
   1f644:	81 e1 ff ff ff 7f    	and    $0x7fffffff,%ecx
   1f64a:	b8 0d 00 00 00       	mov    $0xd,%eax
   1f64f:	81 f9 ff ff 7f 7f    	cmp    $0x7f7fffff,%ecx
   1f655:	7f 38                	jg     1f68f <<gpui_canvas::color::OutputProfile>::max_chroma+0x4f>
   1f657:	0f 57 e4             	xorps  %xmm4,%xmm4
   1f65a:	0f 57 d2             	xorps  %xmm2,%xmm2
   1f65d:	f3 0f c2 d0 06       	cmpnless %xmm0,%xmm2
   1f662:	0f 28 d8             	movaps %xmm0,%xmm3
   1f665:	f3 0f c2 1d 1a 62 fe 	cmpnless -0x19de6(%rip),%xmm3        # 5888 <std::thread::current::id::ID+0x4c10>
   1f66c:	ff 06 
   1f66e:	0f 56 da             	orps   %xmm2,%xmm3
   1f671:	66 0f 7e d9          	movd   %xmm3,%ecx
   1f675:	66 0f 7e ca          	movd   %xmm1,%edx
   1f679:	81 e2 ff ff ff 7f    	and    $0x7fffffff,%edx
   1f67f:	81 fa 00 00 80 7f    	cmp    $0x7f800000,%edx
   1f685:	0f 9d c2             	setge  %dl
   1f688:	08 ca                	or     %cl,%dl
   1f68a:	f6 c2 01             	test   $0x1,%dl
   1f68d:	74 01                	je     1f690 <<gpui_canvas::color::OutputProfile>::max_chroma+0x50>
   1f68f:	c3                   	ret
   1f690:	0f 2e c4             	ucomiss %xmm4,%xmm0
   1f693:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   1f698:	75 02                	jne    1f69c <<gpui_canvas::color::OutputProfile>::max_chroma+0x5c>
   1f69a:	7b f3                	jnp    1f68f <<gpui_canvas::color::OutputProfile>::max_chroma+0x4f>
   1f69c:	0f 2e 05 e5 61 fe ff 	ucomiss -0x19e1b(%rip),%xmm0        # 5888 <std::thread::current::id::ID+0x4c10>
   1f6a3:	75 02                	jne    1f6a7 <<gpui_canvas::color::OutputProfile>::max_chroma+0x67>
   1f6a5:	7b e8                	jnp    1f68f <<gpui_canvas::color::OutputProfile>::max_chroma+0x4f>
   1f6a7:	53                   	push   %rbx
   1f6a8:	48 83 ec 10          	sub    $0x10,%rsp
   1f6ac:	f3 0f 11 44 24 0c    	movss  %xmm0,0xc(%rsp)
   1f6b2:	89 fb                	mov    %edi,%ebx
   1f6b4:	0f 57 c0             	xorps  %xmm0,%xmm0
   1f6b7:	f3 0f 5a c1          	cvtss2sd %xmm1,%xmm0
   1f6bb:	f2 0f 10 0d bd 7c fe 	movsd  -0x18343(%rip),%xmm1        # 7380 <std::thread::current::id::ID+0x6708>
   1f6c2:	ff 
   1f6c3:	ff 15 97 5b 04 00    	call   *0x45b97(%rip)        # 65260 <_DYNAMIC+0x378>
   1f6c9:	f2 0f 10 1d af 7c fe 	movsd  -0x18351(%rip),%xmm3        # 7380 <std::thread::current::id::ID+0x6708>
   1f6d0:	ff 
   1f6d1:	f2 0f 58 d8          	addsd  %xmm0,%xmm3
   1f6d5:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   1f6d9:	66 0f 28 d0          	movapd %xmm0,%xmm2
   1f6dd:	f2 0f c2 d1 01       	cmpltsd %xmm1,%xmm2
   1f6e2:	66 0f 54 da          	andpd  %xmm2,%xmm3
   1f6e6:	66 0f 55 d0          	andnpd %xmm0,%xmm2
   1f6ea:	66 0f 56 d3          	orpd   %xmm3,%xmm2
   1f6ee:	66 0f 2e 15 c2 7b fe 	ucomisd -0x1843e(%rip),%xmm2        # 72b8 <std::thread::current::id::ID+0x6640>
   1f6f5:	ff 
   1f6f6:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   1f6fa:	73 0f                	jae    1f70b <<gpui_canvas::color::OutputProfile>::max_chroma+0xcb>
   1f6fc:	0f 57 c0             	xorps  %xmm0,%xmm0
   1f6ff:	f2 0f 5a c2          	cvtsd2ss %xmm2,%xmm0
   1f703:	f3 0f c2 c8 00       	cmpeqss %xmm0,%xmm1
   1f708:	0f 55 c8             	andnps %xmm0,%xmm1
   1f70b:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   1f711:	0f b6 fb             	movzbl %bl,%edi
   1f714:	48 83 c4 10          	add    $0x10,%rsp
   1f718:	5b                   	pop    %rbx
   1f719:	e9 f2 11 00 00       	jmp    20910 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>>
   1f71e:	cc                   	int3
   1f71f:	cc                   	int3

<gpui_canvas::color::Color>::fit_chroma:
   20250:	55                   	push   %rbp
   20251:	41 57                	push   %r15
   20253:	41 56                	push   %r14
   20255:	41 54                	push   %r12
   20257:	53                   	push   %rbx
   20258:	48 83 ec 30          	sub    $0x30,%rsp
   2025c:	48 89 fb             	mov    %rdi,%rbx
   2025f:	44 8b 66 08          	mov    0x8(%rsi),%r12d
   20263:	44 8b 7e 0c          	mov    0xc(%rsi),%r15d
   20267:	41 81 ff 00 00 00 c0 	cmp    $0xc0000000,%r15d
   2026e:	0f 92 c0             	setb   %al
   20271:	45 85 e4             	test   %r12d,%r12d
   20274:	0f 99 c1             	setns  %cl
   20277:	08 c1                	or     %al,%cl
   20279:	74 09                	je     20284 <<gpui_canvas::color::Color>::fit_chroma+0x34>
   2027b:	c7 43 04 0d 00 00 00 	movl   $0xd,0x4(%rbx)
   20282:	eb 4a                	jmp    202ce <<gpui_canvas::color::Color>::fit_chroma+0x7e>
   20284:	49 89 f6             	mov    %rsi,%r14
   20287:	0f 10 06             	movups (%rsi),%xmm0
   2028a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   2028f:	0f b6 ea             	movzbl %dl,%ebp
   20292:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   20297:	89 ee                	mov    %ebp,%esi
   20299:	e8 12 20 00 00       	call   222b0 <gpui_canvas::color::gamut::in_gamut>
   2029e:	84 c0                	test   %al,%al
   202a0:	74 0c                	je     202ae <<gpui_canvas::color::Color>::fit_chroma+0x5e>
   202a2:	41 0f 10 06          	movups (%r14),%xmm0
   202a6:	0f 11 43 04          	movups %xmm0,0x4(%rbx)
   202aa:	31 c0                	xor    %eax,%eax
   202ac:	eb 25                	jmp    202d3 <<gpui_canvas::color::Color>::fit_chroma+0x83>
   202ae:	41 8b 16             	mov    (%r14),%edx
   202b1:	89 d6                	mov    %edx,%esi
   202b3:	81 e6 ff ff ff 7f    	and    $0x7fffffff,%esi
   202b9:	b8 0d 00 00 00       	mov    $0xd,%eax
   202be:	31 c9                	xor    %ecx,%ecx
   202c0:	81 fe ff ff 7f 7f    	cmp    $0x7f7fffff,%esi
   202c6:	7e 1d                	jle    202e5 <<gpui_canvas::color::Color>::fit_chroma+0x95>
   202c8:	89 43 04             	mov    %eax,0x4(%rbx)
   202cb:	89 4b 08             	mov    %ecx,0x8(%rbx)
   202ce:	b8 01 00 00 00       	mov    $0x1,%eax
   202d3:	89 03                	mov    %eax,(%rbx)
   202d5:	48 89 d8             	mov    %rbx,%rax
   202d8:	48 83 c4 30          	add    $0x30,%rsp
   202dc:	5b                   	pop    %rbx
   202dd:	41 5c                	pop    %r12
   202df:	41 5e                	pop    %r14
   202e1:	41 5f                	pop    %r15
   202e3:	5d                   	pop    %rbp
   202e4:	c3                   	ret
   202e5:	44 89 e6             	mov    %r12d,%esi
   202e8:	81 e6 ff ff ff 7f    	and    $0x7fffffff,%esi
   202ee:	66 0f 6e c6          	movd   %esi,%xmm0
   202f2:	0f 2e 05 c7 55 fe ff 	ucomiss -0x1aa39(%rip),%xmm0        # 58c0 <std::thread::current::id::ID+0x4c48>
   202f9:	74 cd                	je     202c8 <<gpui_canvas::color::Color>::fit_chroma+0x78>
   202fb:	66 0f 6e d2          	movd   %edx,%xmm2
   202ff:	0f 57 c9             	xorps  %xmm1,%xmm1
   20302:	0f 2e d1             	ucomiss %xmm1,%xmm2
   20305:	72 c1                	jb     202c8 <<gpui_canvas::color::Color>::fit_chroma+0x78>
   20307:	f3 0f 10 0d 79 55 fe 	movss  -0x1aa87(%rip),%xmm1        # 5888 <std::thread::current::id::ID+0x4c10>
   2030e:	ff 
   2030f:	0f 2e ca             	ucomiss %xmm2,%xmm1
   20312:	72 b4                	jb     202c8 <<gpui_canvas::color::Color>::fit_chroma+0x78>
   20314:	f3 41 0f 10 5e 04    	movss  0x4(%r14),%xmm3
   2031a:	31 c9                	xor    %ecx,%ecx
   2031c:	0f 57 c9             	xorps  %xmm1,%xmm1
   2031f:	0f 2e d1             	ucomiss %xmm1,%xmm2
   20322:	f3 0f 11 54 24 0c    	movss  %xmm2,0xc(%rsp)
   20328:	75 02                	jne    2032c <<gpui_canvas::color::Color>::fit_chroma+0xdc>
   2032a:	7b 63                	jnp    2038f <<gpui_canvas::color::Color>::fit_chroma+0x13f>
   2032c:	0f 2e 15 55 55 fe ff 	ucomiss -0x1aaab(%rip),%xmm2        # 5888 <std::thread::current::id::ID+0x4c10>
   20333:	75 02                	jne    20337 <<gpui_canvas::color::Color>::fit_chroma+0xe7>
   20335:	7b 58                	jnp    2038f <<gpui_canvas::color::Color>::fit_chroma+0x13f>
   20337:	0f 29 5c 24 20       	movaps %xmm3,0x20(%rsp)
   2033c:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   20340:	f2 0f 10 0d 38 70 fe 	movsd  -0x18fc8(%rip),%xmm1        # 7380 <std::thread::current::id::ID+0x6708>
   20347:	ff 
   20348:	ff 15 12 4f 04 00    	call   *0x44f12(%rip)        # 65260 <_DYNAMIC+0x378>
   2034e:	66 0f 2e 05 62 6f fe 	ucomisd -0x1909e(%rip),%xmm0        # 72b8 <std::thread::current::id::ID+0x6640>
   20355:	ff 
   20356:	0f 57 c9             	xorps  %xmm1,%xmm1
   20359:	73 0c                	jae    20367 <<gpui_canvas::color::Color>::fit_chroma+0x117>
   2035b:	f2 0f 5a c0          	cvtsd2ss %xmm0,%xmm0
   2035f:	f3 0f c2 c8 00       	cmpeqss %xmm0,%xmm1
   20364:	0f 55 c8             	andnps %xmm0,%xmm1
   20367:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   2036d:	89 ef                	mov    %ebp,%edi
   2036f:	e8 9c 05 00 00       	call   20910 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>>
   20374:	f3 0f 10 54 24 0c    	movss  0xc(%rsp),%xmm2
   2037a:	48 89 c1             	mov    %rax,%rcx
   2037d:	48 c1 e9 20          	shr    $0x20,%rcx
   20381:	83 f8 ff             	cmp    $0xffffffff,%eax
   20384:	0f 28 5c 24 20       	movaps 0x20(%rsp),%xmm3
   20389:	0f 85 39 ff ff ff    	jne    202c8 <<gpui_canvas::color::Color>::fit_chroma+0x78>
   2038f:	66 0f 6e c1          	movd   %ecx,%xmm0
   20393:	0f 28 cb             	movaps %xmm3,%xmm1
   20396:	f3 0f 5d c8          	minss  %xmm0,%xmm1
   2039a:	0f 28 e1             	movaps %xmm1,%xmm4
   2039d:	f3 0f c2 e1 03       	cmpunordss %xmm1,%xmm4
   203a2:	0f 28 c4             	movaps %xmm4,%xmm0
   203a5:	0f 55 c1             	andnps %xmm1,%xmm0
   203a8:	0f 54 e3             	andps  %xmm3,%xmm4
   203ab:	0f 56 e0             	orps   %xmm0,%xmm4
   203ae:	f3 0f 11 54 24 10    	movss  %xmm2,0x10(%rsp)
   203b4:	0f 29 64 24 20       	movaps %xmm4,0x20(%rsp)
   203b9:	f3 0f 11 64 24 14    	movss  %xmm4,0x14(%rsp)
   203bf:	44 89 64 24 18       	mov    %r12d,0x18(%rsp)
   203c4:	44 89 7c 24 1c       	mov    %r15d,0x1c(%rsp)
   203c9:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   203ce:	89 ee                	mov    %ebp,%esi
   203d0:	e8 db 1e 00 00       	call   222b0 <gpui_canvas::color::gamut::in_gamut>
   203d5:	84 c0                	test   %al,%al
   203d7:	74 1c                	je     203f5 <<gpui_canvas::color::Color>::fit_chroma+0x1a5>
   203d9:	0f 28 44 24 20       	movaps 0x20(%rsp),%xmm0
   203de:	f3 0f 11 43 08       	movss  %xmm0,0x8(%rbx)
   203e3:	44 89 63 0c          	mov    %r12d,0xc(%rbx)
   203e7:	44 89 7b 10          	mov    %r15d,0x10(%rbx)
   203eb:	31 c0                	xor    %eax,%eax
   203ed:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   203f3:	eb 0d                	jmp    20402 <<gpui_canvas::color::Color>::fit_chroma+0x1b2>
   203f5:	b8 01 00 00 00       	mov    $0x1,%eax
   203fa:	f3 0f 10 05 7e 54 fe 	movss  -0x1ab82(%rip),%xmm0        # 5880 <std::thread::current::id::ID+0x4c08>
   20401:	ff 
   20402:	f3 0f 11 43 04       	movss  %xmm0,0x4(%rbx)
   20407:	e9 c7 fe ff ff       	jmp    202d3 <<gpui_canvas::color::Color>::fit_chroma+0x83>
   2040c:	cc                   	int3
   2040d:	cc                   	int3
   2040e:	cc                   	int3
   2040f:	cc                   	int3

gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>:
   20910:	55                   	push   %rbp
   20911:	48 89 e5             	mov    %rsp,%rbp
   20914:	41 57                	push   %r15
   20916:	41 56                	push   %r14
   20918:	41 55                	push   %r13
   2091a:	41 54                	push   %r12
   2091c:	53                   	push   %rbx
   2091d:	48 83 e4 e0          	and    $0xffffffffffffffe0,%rsp
   20921:	48 81 ec a0 02 00 00 	sub    $0x2a0,%rsp
   20928:	f3 0f 11 44 24 0c    	movss  %xmm0,0xc(%rsp)
   2092e:	89 fb                	mov    %edi,%ebx
   20930:	0f 29 8c 24 d0 00 00 	movaps %xmm1,0xd0(%rsp)
   20937:	00 
   20938:	0f 57 c0             	xorps  %xmm0,%xmm0
   2093b:	f3 0f 5a c1          	cvtss2sd %xmm1,%xmm0
   2093f:	f2 0f 59 05 19 6a fe 	mulsd  -0x195e7(%rip),%xmm0        # 7360 <std::thread::current::id::ID+0x66e8>
   20946:	ff 
   20947:	48 8d bc 24 18 01 00 	lea    0x118(%rsp),%rdi
   2094e:	00 
   2094f:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
   20956:	00 
   20957:	ff 15 33 49 04 00    	call   *0x44933(%rip)        # 65290 <sincos@GLIBC_2.2.5>
   2095d:	f2 0f 10 ac 24 18 01 	movsd  0x118(%rsp),%xmm5
   20964:	00 00 
   20966:	f2 0f 10 84 24 10 01 	movsd  0x110(%rsp),%xmm0
   2096d:	00 00 
   2096f:	f2 0f 10 0d c1 69 fe 	movsd  -0x1963f(%rip),%xmm1        # 7338 <std::thread::current::id::ID+0x66c0>
   20976:	ff 
   20977:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   2097b:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   2097f:	f2 0f 58 ca          	addsd  %xmm2,%xmm1
   20983:	f2 0f 10 1d 05 69 fe 	movsd  -0x196fb(%rip),%xmm3        # 7290 <std::thread::current::id::ID+0x6618>
   2098a:	ff 
   2098b:	f2 0f 59 d8          	mulsd  %xmm0,%xmm3
   2098f:	f2 0f 58 da          	addsd  %xmm2,%xmm3
   20993:	f2 0f 10 35 35 69 fe 	movsd  -0x196cb(%rip),%xmm6        # 72d0 <std::thread::current::id::ID+0x6658>
   2099a:	ff 
   2099b:	f2 0f 59 f5          	mulsd  %xmm5,%xmm6
   2099f:	f2 0f 58 f1          	addsd  %xmm1,%xmm6
   209a3:	f2 0f 10 3d ed 69 fe 	movsd  -0x19613(%rip),%xmm7        # 7398 <std::thread::current::id::ID+0x6720>
   209aa:	ff 
   209ab:	f2 0f 59 fd          	mulsd  %xmm5,%xmm7
   209af:	f2 0f 58 fb          	addsd  %xmm3,%xmm7
   209b3:	f2 0f 59 05 65 69 fe 	mulsd  -0x1969b(%rip),%xmm0        # 7320 <std::thread::current::id::ID+0x66a8>
   209ba:	ff 
   209bb:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   209bf:	f2 0f 59 2d b1 67 fe 	mulsd  -0x1984f(%rip),%xmm5        # 7178 <std::thread::current::id::ID+0x6500>
   209c6:	ff 
   209c7:	f2 0f 58 e8          	addsd  %xmm0,%xmm5
   209cb:	85 db                	test   %ebx,%ebx
   209cd:	74 35                	je     20a04 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xf4>
   209cf:	66 44 0f 28 2d d8 48 	movapd -0x1b728(%rip),%xmm13        # 52b0 <std::thread::current::id::ID+0x4638>
   209d6:	fe ff 
   209d8:	66 0f 28 05 d0 4d fe 	movapd -0x1b230(%rip),%xmm0        # 57b0 <std::thread::current::id::ID+0x4b38>
   209df:	ff 
   209e0:	66 44 0f 28 1d 67 4e 	movapd -0x1b199(%rip),%xmm11        # 5850 <std::thread::current::id::ID+0x4bd8>
   209e7:	fe ff 
   209e9:	f3 0f 7e 15 df 67 fe 	movq   -0x19821(%rip),%xmm2        # 71d0 <std::thread::current::id::ID+0x6558>
   209f0:	ff 
   209f1:	f3 0f 7e 25 b7 68 fe 	movq   -0x19749(%rip),%xmm4        # 72b0 <std::thread::current::id::ID+0x6638>
   209f8:	ff 
   209f9:	f3 44 0f 7e 05 d6 67 	movq   -0x1982a(%rip),%xmm8        # 71d8 <std::thread::current::id::ID+0x6560>
   20a00:	fe ff 
   20a02:	eb 33                	jmp    20a37 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x127>
   20a04:	66 44 0f 28 2d 93 4b 	movapd -0x1b46d(%rip),%xmm13        # 55a0 <std::thread::current::id::ID+0x4928>
   20a0b:	fe ff 
   20a0d:	66 0f 28 05 6b 4c fe 	movapd -0x1b395(%rip),%xmm0        # 5680 <std::thread::current::id::ID+0x4a08>
   20a14:	ff 
   20a15:	66 44 0f 28 1d f2 4a 	movapd -0x1b50e(%rip),%xmm11        # 5510 <std::thread::current::id::ID+0x4898>
   20a1c:	fe ff 
   20a1e:	f3 0f 7e 15 da 68 fe 	movq   -0x19726(%rip),%xmm2        # 7300 <std::thread::current::id::ID+0x6688>
   20a25:	ff 
   20a26:	f3 0f 7e 25 c2 68 fe 	movq   -0x1973e(%rip),%xmm4        # 72f0 <std::thread::current::id::ID+0x6678>
   20a2d:	ff 
   20a2e:	f3 44 0f 7e 05 31 68 	movq   -0x197cf(%rip),%xmm8        # 7268 <std::thread::current::id::ID+0x65f0>
   20a35:	fe ff 
   20a37:	f3 0f 7e da          	movq   %xmm2,%xmm3
   20a3b:	f3 0f 7e e4          	movq   %xmm4,%xmm4
   20a3f:	f3 41 0f 7e d0       	movq   %xmm8,%xmm2
   20a44:	66 0f 14 f7          	unpcklpd %xmm7,%xmm6
   20a48:	66 0f 28 fe          	movapd %xmm6,%xmm7
   20a4c:	66 0f 59 fe          	mulpd  %xmm6,%xmm7
   20a50:	66 44 0f 28 c5       	movapd %xmm5,%xmm8
   20a55:	f2 44 0f 59 c5       	mulsd  %xmm5,%xmm8
   20a5a:	f2 44 0f 59 c5       	mulsd  %xmm5,%xmm8
   20a5f:	66 0f 59 fe          	mulpd  %xmm6,%xmm7
   20a63:	66 0f 29 7c 24 40    	movapd %xmm7,0x40(%rsp)
   20a69:	f2 44 0f 11 44 24 50 	movsd  %xmm8,0x50(%rsp)
   20a70:	f2 0f 10 7c 24 40    	movsd  0x40(%rsp),%xmm7
   20a76:	66 0f 14 ff          	unpcklpd %xmm7,%xmm7
   20a7a:	66 45 0f 28 c5       	movapd %xmm13,%xmm8
   20a7f:	66 44 0f 59 c7       	mulpd  %xmm7,%xmm8
   20a84:	66 0f 59 fb          	mulpd  %xmm3,%xmm7
   20a88:	66 44 0f 10 64 24 48 	movupd 0x48(%rsp),%xmm12
   20a8f:	66 45 0f 28 cc       	movapd %xmm12,%xmm9
   20a94:	66 45 0f 14 cc       	unpcklpd %xmm12,%xmm9
   20a99:	66 44 0f 28 d0       	movapd %xmm0,%xmm10
   20a9e:	66 45 0f 59 d1       	mulpd  %xmm9,%xmm10
   20aa3:	66 45 0f 58 d0       	addpd  %xmm8,%xmm10
   20aa8:	66 44 0f 59 cc       	mulpd  %xmm4,%xmm9
   20aad:	66 44 0f 58 cf       	addpd  %xmm7,%xmm9
   20ab2:	66 45 0f 15 e4       	unpckhpd %xmm12,%xmm12
   20ab7:	66 45 0f 28 fb       	movapd %xmm11,%xmm15
   20abc:	66 45 0f 59 fc       	mulpd  %xmm12,%xmm15
   20ac1:	66 45 0f 58 fa       	addpd  %xmm10,%xmm15
   20ac6:	66 44 0f 29 bc 24 00 	movapd %xmm15,0x100(%rsp)
   20acd:	01 00 00 
   20ad0:	66 44 0f 59 e2       	mulpd  %xmm2,%xmm12
   20ad5:	66 45 0f 58 e1       	addpd  %xmm9,%xmm12
   20ada:	66 44 0f 29 64 24 20 	movapd %xmm12,0x20(%rsp)
   20ae1:	66 0f 28 fe          	movapd %xmm6,%xmm7
   20ae5:	66 0f 59 3d e3 48 fe 	mulpd  -0x1b71d(%rip),%xmm7        # 53d0 <std::thread::current::id::ID+0x4758>
   20aec:	ff 
   20aed:	f2 44 0f 10 05 aa 67 	movsd  -0x19856(%rip),%xmm8        # 72a0 <std::thread::current::id::ID+0x6628>
   20af4:	fe ff 
   20af6:	f2 44 0f 59 c5       	mulsd  %xmm5,%xmm8
   20afb:	f2 41 0f 59 e8       	mulsd  %xmm8,%xmm5
   20b00:	66 0f 59 f7          	mulpd  %xmm7,%xmm6
   20b04:	66 0f 29 74 24 40    	movapd %xmm6,0x40(%rsp)
   20b0a:	f2 0f 11 6c 24 50    	movsd  %xmm5,0x50(%rsp)
   20b10:	f2 0f 10 6c 24 40    	movsd  0x40(%rsp),%xmm5
   20b16:	66 0f 14 ed          	unpcklpd %xmm5,%xmm5
   20b1a:	66 41 0f 28 f5       	movapd %xmm13,%xmm6
   20b1f:	66 0f 59 f5          	mulpd  %xmm5,%xmm6
   20b23:	66 0f 59 eb          	mulpd  %xmm3,%xmm5
   20b27:	66 44 0f 10 74 24 48 	movupd 0x48(%rsp),%xmm14
   20b2e:	66 45 0f 28 ce       	movapd %xmm14,%xmm9
   20b33:	66 45 0f 14 ce       	unpcklpd %xmm14,%xmm9
   20b38:	66 44 0f 28 d0       	movapd %xmm0,%xmm10
   20b3d:	66 45 0f 59 d1       	mulpd  %xmm9,%xmm10
   20b42:	66 44 0f 58 d6       	addpd  %xmm6,%xmm10
   20b47:	66 44 0f 59 cc       	mulpd  %xmm4,%xmm9
   20b4c:	66 44 0f 58 cd       	addpd  %xmm5,%xmm9
   20b51:	66 45 0f 15 f6       	unpckhpd %xmm14,%xmm14
   20b56:	66 41 0f 28 cb       	movapd %xmm11,%xmm1
   20b5b:	66 41 0f 59 ce       	mulpd  %xmm14,%xmm1
   20b60:	66 41 0f 58 ca       	addpd  %xmm10,%xmm1
   20b65:	66 0f 29 8c 24 e0 00 	movapd %xmm1,0xe0(%rsp)
   20b6c:	00 00 
   20b6e:	66 44 0f 59 f2       	mulpd  %xmm2,%xmm14
   20b73:	66 45 0f 58 f1       	addpd  %xmm9,%xmm14
   20b78:	66 45 0f 28 ce       	movapd %xmm14,%xmm9
   20b7d:	66 44 0f 29 b4 24 f0 	movapd %xmm14,0xf0(%rsp)
   20b84:	00 00 00 
   20b87:	66 0f 29 7c 24 40    	movapd %xmm7,0x40(%rsp)
   20b8d:	f2 44 0f 11 44 24 50 	movsd  %xmm8,0x50(%rsp)
   20b94:	f2 0f 10 6c 24 40    	movsd  0x40(%rsp),%xmm5
   20b9a:	66 0f 14 ed          	unpcklpd %xmm5,%xmm5
   20b9e:	66 41 0f 28 f5       	movapd %xmm13,%xmm6
   20ba3:	66 0f 59 f5          	mulpd  %xmm5,%xmm6
   20ba7:	66 0f 59 eb          	mulpd  %xmm3,%xmm5
   20bab:	66 44 0f 10 54 24 48 	movupd 0x48(%rsp),%xmm10
   20bb2:	66 41 0f 28 fa       	movapd %xmm10,%xmm7
   20bb7:	66 41 0f 14 fa       	unpcklpd %xmm10,%xmm7
   20bbc:	66 44 0f 28 c0       	movapd %xmm0,%xmm8
   20bc1:	66 44 0f 59 c7       	mulpd  %xmm7,%xmm8
   20bc6:	66 44 0f 58 c6       	addpd  %xmm6,%xmm8
   20bcb:	66 0f 59 fc          	mulpd  %xmm4,%xmm7
   20bcf:	66 0f 58 fd          	addpd  %xmm5,%xmm7
   20bd3:	66 45 0f 15 d2       	unpckhpd %xmm10,%xmm10
   20bd8:	66 41 0f 28 eb       	movapd %xmm11,%xmm5
   20bdd:	66 41 0f 59 ea       	mulpd  %xmm10,%xmm5
   20be2:	66 41 0f 58 e8       	addpd  %xmm8,%xmm5
   20be7:	66 44 0f 28 c5       	movapd %xmm5,%xmm8
   20bec:	66 0f 29 ac 24 80 01 	movapd %xmm5,0x180(%rsp)
   20bf3:	00 00 
   20bf5:	66 44 0f 59 d2       	mulpd  %xmm2,%xmm10
   20bfa:	66 44 0f 58 d7       	addpd  %xmm7,%xmm10
   20bff:	66 44 0f 29 94 24 90 	movapd %xmm10,0x190(%rsp)
   20c06:	01 00 00 
   20c09:	0f 28 2d 90 4a fe ff 	movaps -0x1b570(%rip),%xmm5        # 56a0 <std::thread::current::id::ID+0x4a28>
   20c10:	0f 29 6c 24 40       	movaps %xmm5,0x40(%rsp)
   20c15:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
   20c1c:	00 f0 3f 
   20c1f:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   20c24:	66 0f 10 6c 24 48    	movupd 0x48(%rsp),%xmm5
   20c2a:	66 0f 28 f5          	movapd %xmm5,%xmm6
   20c2e:	66 0f 14 f5          	unpcklpd %xmm5,%xmm6
   20c32:	66 0f 59 c6          	mulpd  %xmm6,%xmm0
   20c36:	66 0f 59 f4          	mulpd  %xmm4,%xmm6
   20c3a:	66 41 0f 58 c5       	addpd  %xmm13,%xmm0
   20c3f:	66 0f 58 f3          	addpd  %xmm3,%xmm6
   20c43:	66 0f 15 ed          	unpckhpd %xmm5,%xmm5
   20c47:	66 44 0f 59 dd       	mulpd  %xmm5,%xmm11
   20c4c:	66 44 0f 58 d8       	addpd  %xmm0,%xmm11
   20c51:	66 44 0f 29 9c 24 a0 	movapd %xmm11,0x1a0(%rsp)
   20c58:	01 00 00 
   20c5b:	66 0f 59 ea          	mulpd  %xmm2,%xmm5
   20c5f:	66 0f 58 ee          	addpd  %xmm6,%xmm5
   20c63:	66 45 0f 57 f6       	xorpd  %xmm14,%xmm14
   20c68:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
   20c6c:	66 0f 16 05 bc 65 fe 	movhpd -0x19a44(%rip),%xmm0        # 7230 <std::thread::current::id::ID+0x65b8>
   20c73:	ff 
   20c74:	66 0f 58 c5          	addpd  %xmm5,%xmm0
   20c78:	66 0f 29 84 24 70 01 	movapd %xmm0,0x170(%rsp)
   20c7f:	00 00 
   20c81:	66 41 0f 28 c7       	movapd %xmm15,%xmm0
   20c86:	66 44 0f 28 3d 41 47 	movapd -0x1b8bf(%rip),%xmm15        # 53d0 <std::thread::current::id::ID+0x4758>
   20c8d:	fe ff 
   20c8f:	66 41 0f 59 c7       	mulpd  %xmm15,%xmm0
   20c94:	66 45 0f 59 fc       	mulpd  %xmm12,%xmm15
   20c99:	66 44 0f 29 7c 24 30 	movapd %xmm15,0x30(%rsp)
   20ca0:	66 0f 28 e1          	movapd %xmm1,%xmm4
   20ca4:	66 0f 58 e1          	addpd  %xmm1,%xmm4
   20ca8:	66 0f 28 d8          	movapd %xmm0,%xmm3
   20cac:	66 44 0f 28 d8       	movapd %xmm0,%xmm11
   20cb1:	66 41 0f 59 d8       	mulpd  %xmm8,%xmm3
   20cb6:	66 41 0f 28 cf       	movapd %xmm15,%xmm1
   20cbb:	66 41 0f 59 ca       	mulpd  %xmm10,%xmm1
   20cc0:	66 0f 28 05 78 47 fe 	movapd -0x1b888(%rip),%xmm0        # 5440 <std::thread::current::id::ID+0x47c8>
   20cc7:	ff 
   20cc8:	66 0f 59 d8          	mulpd  %xmm0,%xmm3
   20ccc:	66 0f 28 f3          	movapd %xmm3,%xmm6
   20cd0:	66 0f 29 9c 24 f0 01 	movapd %xmm3,0x1f0(%rsp)
   20cd7:	00 00 
   20cd9:	66 0f 59 c8          	mulpd  %xmm0,%xmm1
   20cdd:	66 0f 28 e9          	movapd %xmm1,%xmm5
   20ce1:	66 0f 29 8c 24 d0 01 	movapd %xmm1,0x1d0(%rsp)
   20ce8:	00 00 
   20cea:	66 0f 28 c4          	movapd %xmm4,%xmm0
   20cee:	66 41 0f c2 c6 01    	cmpltpd %xmm14,%xmm0
   20cf4:	66 0f 28 0d 64 4b fe 	movapd -0x1b49c(%rip),%xmm1        # 5860 <std::thread::current::id::ID+0x4be8>
   20cfb:	ff 
   20cfc:	66 0f 28 d8          	movapd %xmm0,%xmm3
   20d00:	66 0f 54 d9          	andpd  %xmm1,%xmm3
   20d04:	66 44 0f 28 15 93 49 	movapd -0x1b66d(%rip),%xmm10        # 56a0 <std::thread::current::id::ID+0x4a28>
   20d0b:	fe ff 
   20d0d:	66 41 0f 55 c2       	andnpd %xmm10,%xmm0
   20d12:	66 0f 56 c3          	orpd   %xmm3,%xmm0
   20d16:	66 45 0f 28 e9       	movapd %xmm9,%xmm13
   20d1b:	66 45 0f 58 e9       	addpd  %xmm9,%xmm13
   20d20:	66 41 0f 28 dd       	movapd %xmm13,%xmm3
   20d25:	66 41 0f c2 de 01    	cmpltpd %xmm14,%xmm3
   20d2b:	66 0f 54 cb          	andpd  %xmm3,%xmm1
   20d2f:	66 41 0f 55 da       	andnpd %xmm10,%xmm3
   20d34:	66 0f 56 d9          	orpd   %xmm1,%xmm3
   20d38:	66 0f 28 fc          	movapd %xmm4,%xmm7
   20d3c:	66 0f 59 fc          	mulpd  %xmm4,%xmm7
   20d40:	66 0f 29 bc 24 c0 00 	movapd %xmm7,0xc0(%rsp)
   20d47:	00 00 
   20d49:	66 0f 5c fe          	subpd  %xmm6,%xmm7
   20d4d:	66 0f 28 cf          	movapd %xmm7,%xmm1
   20d51:	66 41 0f 5f ce       	maxpd  %xmm14,%xmm1
   20d56:	66 44 0f 51 e1       	sqrtpd %xmm1,%xmm12
   20d5b:	66 44 0f 59 e0       	mulpd  %xmm0,%xmm12
   20d60:	66 45 0f 28 c5       	movapd %xmm13,%xmm8
   20d65:	66 45 0f 59 c5       	mulpd  %xmm13,%xmm8
   20d6a:	66 44 0f 29 84 24 e0 	movapd %xmm8,0x1e0(%rsp)
   20d71:	01 00 00 
   20d74:	66 44 0f 5c c5       	subpd  %xmm5,%xmm8
   20d79:	66 41 0f 28 c0       	movapd %xmm8,%xmm0
   20d7e:	66 41 0f 5f c6       	maxpd  %xmm14,%xmm0
   20d83:	66 0f 51 d0          	sqrtpd %xmm0,%xmm2
   20d87:	66 0f 59 d3          	mulpd  %xmm3,%xmm2
   20d8b:	66 44 0f 58 e4       	addpd  %xmm4,%xmm12
   20d90:	66 41 0f 58 d5       	addpd  %xmm13,%xmm2
   20d95:	66 0f 28 05 d3 4a fe 	movapd -0x1b52d(%rip),%xmm0        # 5870 <std::thread::current::id::ID+0x4bf8>
   20d9c:	ff 
   20d9d:	66 44 0f 59 e0       	mulpd  %xmm0,%xmm12
   20da2:	66 0f 59 d0          	mulpd  %xmm0,%xmm2
   20da6:	66 41 0f 28 cb       	movapd %xmm11,%xmm1
   20dab:	66 44 0f 29 5c 24 10 	movapd %xmm11,0x10(%rsp)
   20db2:	66 41 0f 28 c3       	movapd %xmm11,%xmm0
   20db7:	66 41 0f c2 c6 00    	cmpeqpd %xmm14,%xmm0
   20dbd:	66 44 0f 28 cc       	movapd %xmm4,%xmm9
   20dc2:	66 45 0f c2 ce 00    	cmpeqpd %xmm14,%xmm9
   20dc8:	66 45 0f 28 d9       	movapd %xmm9,%xmm11
   20dcd:	66 44 0f 55 cc       	andnpd %xmm4,%xmm9
   20dd2:	66 41 0f c2 e6 04    	cmpneqpd %xmm14,%xmm4
   20dd8:	66 0f 54 e0          	andpd  %xmm0,%xmm4
   20ddc:	66 44 0f 28 f8       	movapd %xmm0,%xmm15
   20de1:	66 41 0f 54 c2       	andpd  %xmm10,%xmm0
   20de6:	66 44 0f 55 f9       	andnpd %xmm1,%xmm15
   20deb:	66 44 0f 56 f8       	orpd   %xmm0,%xmm15
   20df0:	66 0f 28 74 24 30    	movapd 0x30(%rsp),%xmm6
   20df6:	66 0f 28 ce          	movapd %xmm6,%xmm1
   20dfa:	66 41 0f c2 ce 00    	cmpeqpd %xmm14,%xmm1
   20e00:	66 41 0f 28 ed       	movapd %xmm13,%xmm5
   20e05:	66 41 0f c2 ee 00    	cmpeqpd %xmm14,%xmm5
   20e0b:	66 0f 28 dd          	movapd %xmm5,%xmm3
   20e0f:	66 41 0f 55 ed       	andnpd %xmm13,%xmm5
   20e14:	66 45 0f c2 ee 04    	cmpneqpd %xmm14,%xmm13
   20e1a:	66 44 0f 54 e9       	andpd  %xmm1,%xmm13
   20e1f:	66 44 0f 29 ac 24 c0 	movapd %xmm13,0x1c0(%rsp)
   20e26:	01 00 00 
   20e29:	66 0f 28 c1          	movapd %xmm1,%xmm0
   20e2d:	66 41 0f 54 ca       	andpd  %xmm10,%xmm1
   20e32:	66 0f 55 c6          	andnpd %xmm6,%xmm0
   20e36:	66 0f 56 c1          	orpd   %xmm1,%xmm0
   20e3a:	66 41 0f 28 f4       	movapd %xmm12,%xmm6
   20e3f:	66 41 0f c2 f6 00    	cmpeqpd %xmm14,%xmm6
   20e45:	66 0f 28 ce          	movapd %xmm6,%xmm1
   20e49:	66 41 0f 54 ca       	andpd  %xmm10,%xmm1
   20e4e:	66 41 0f 55 f4       	andnpd %xmm12,%xmm6
   20e53:	66 0f 56 f1          	orpd   %xmm1,%xmm6
   20e57:	66 44 0f 28 ea       	movapd %xmm2,%xmm13
   20e5c:	66 45 0f c2 ee 00    	cmpeqpd %xmm14,%xmm13
   20e62:	66 41 0f 28 cd       	movapd %xmm13,%xmm1
   20e67:	66 41 0f 54 ca       	andpd  %xmm10,%xmm1
   20e6c:	66 44 0f 55 ea       	andnpd %xmm2,%xmm13
   20e71:	66 44 0f 56 e9       	orpd   %xmm1,%xmm13
   20e76:	66 44 0f 29 ac 24 b0 	movapd %xmm13,0x1b0(%rsp)
   20e7d:	01 00 00 
   20e80:	66 45 0f 54 da       	andpd  %xmm10,%xmm11
   20e85:	66 45 0f 56 cb       	orpd   %xmm11,%xmm9
   20e8a:	66 41 0f 54 da       	andpd  %xmm10,%xmm3
   20e8f:	66 0f 56 eb          	orpd   %xmm3,%xmm5
   20e93:	66 45 0f 28 dc       	movapd %xmm12,%xmm11
   20e98:	66 45 0f 5e df       	divpd  %xmm15,%xmm11
   20e9d:	66 44 0f 28 ea       	movapd %xmm2,%xmm13
   20ea2:	66 44 0f 5e e8       	divpd  %xmm0,%xmm13
   20ea7:	66 44 0f 28 3d e0 48 	movapd -0x1b720(%rip),%xmm15        # 5790 <std::thread::current::id::ID+0x4b18>
   20eae:	fe ff 
   20eb0:	66 0f 28 84 24 00 01 	movapd 0x100(%rsp),%xmm0
   20eb7:	00 00 
   20eb9:	66 41 0f 57 c7       	xorpd  %xmm15,%xmm0
   20ebe:	66 0f 29 44 24 40    	movapd %xmm0,0x40(%rsp)
   20ec4:	66 0f 28 44 24 20    	movapd 0x20(%rsp),%xmm0
   20eca:	66 41 0f 57 c7       	xorpd  %xmm15,%xmm0
   20ecf:	66 0f 29 44 24 50    	movapd %xmm0,0x50(%rsp)
   20ed5:	66 0f 28 84 24 e0 00 	movapd 0xe0(%rsp),%xmm0
   20edc:	00 00 
   20ede:	66 41 0f 57 c7       	xorpd  %xmm15,%xmm0
   20ee3:	66 0f 29 44 24 60    	movapd %xmm0,0x60(%rsp)
   20ee9:	66 0f 28 84 24 f0 00 	movapd 0xf0(%rsp),%xmm0
   20ef0:	00 00 
   20ef2:	66 41 0f 57 c7       	xorpd  %xmm15,%xmm0
   20ef7:	66 0f 29 44 24 70    	movapd %xmm0,0x70(%rsp)
   20efd:	66 44 0f 28 94 24 80 	movapd 0x180(%rsp),%xmm10
   20f04:	01 00 00 
   20f07:	66 41 0f 28 c2       	movapd %xmm10,%xmm0
   20f0c:	66 41 0f 57 c7       	xorpd  %xmm15,%xmm0
   20f11:	66 0f 29 84 24 80 00 	movapd %xmm0,0x80(%rsp)
   20f18:	00 00 
   20f1a:	66 0f 28 c8          	movapd %xmm0,%xmm1
   20f1e:	66 41 0f 5e c9       	divpd  %xmm9,%xmm1
   20f23:	66 44 0f 28 8c 24 90 	movapd 0x190(%rsp),%xmm9
   20f2a:	01 00 00 
   20f2d:	66 41 0f 28 c1       	movapd %xmm9,%xmm0
   20f32:	66 41 0f 57 c7       	xorpd  %xmm15,%xmm0
   20f37:	66 0f 29 84 24 90 00 	movapd %xmm0,0x90(%rsp)
   20f3e:	00 00 
   20f40:	66 0f 28 d8          	movapd %xmm0,%xmm3
   20f44:	66 0f 5e dd          	divpd  %xmm5,%xmm3
   20f48:	66 0f 54 cc          	andpd  %xmm4,%xmm1
   20f4c:	66 0f 28 05 fc 47 fe 	movapd -0x1b804(%rip),%xmm0        # 5750 <std::thread::current::id::ID+0x4ad8>
   20f53:	ff 
   20f54:	66 0f 55 e0          	andnpd %xmm0,%xmm4
   20f58:	66 0f 56 e1          	orpd   %xmm1,%xmm4
   20f5c:	66 0f 28 8c 24 c0 01 	movapd 0x1c0(%rsp),%xmm1
   20f63:	00 00 
   20f65:	66 0f 54 d9          	andpd  %xmm1,%xmm3
   20f69:	66 0f 55 c8          	andnpd %xmm0,%xmm1
   20f6d:	66 0f 56 cb          	orpd   %xmm3,%xmm1
   20f71:	66 0f 28 e9          	movapd %xmm1,%xmm5
   20f75:	66 0f 28 5c 24 10    	movapd 0x10(%rsp),%xmm3
   20f7b:	66 41 0f c2 de 04    	cmpneqpd %xmm14,%xmm3
   20f81:	66 0f 29 5c 24 10    	movapd %xmm3,0x10(%rsp)
   20f87:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   20f8b:	66 0f c2 cf 02       	cmplepd %xmm7,%xmm1
   20f90:	66 0f 54 cb          	andpd  %xmm3,%xmm1
   20f94:	66 44 0f 54 d9       	andpd  %xmm1,%xmm11
   20f99:	66 45 0f c2 e6 04    	cmpneqpd %xmm14,%xmm12
   20f9f:	66 44 0f 54 e1       	andpd  %xmm1,%xmm12
   20fa4:	66 0f 28 d9          	movapd %xmm1,%xmm3
   20fa8:	66 0f 55 dc          	andnpd %xmm4,%xmm3
   20fac:	66 41 0f 56 db       	orpd   %xmm11,%xmm3
   20fb1:	66 44 0f 28 5c 24 30 	movapd 0x30(%rsp),%xmm11
   20fb8:	66 45 0f c2 de 04    	cmpneqpd %xmm14,%xmm11
   20fbe:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   20fc2:	66 41 0f c2 c8 02    	cmplepd %xmm8,%xmm1
   20fc8:	66 41 0f 54 cb       	andpd  %xmm11,%xmm1
   20fcd:	66 44 0f 54 e9       	andpd  %xmm1,%xmm13
   20fd2:	66 41 0f c2 d6 04    	cmpneqpd %xmm14,%xmm2
   20fd8:	66 0f 54 d1          	andpd  %xmm1,%xmm2
   20fdc:	66 0f 28 e1          	movapd %xmm1,%xmm4
   20fe0:	66 0f 55 e5          	andnpd %xmm5,%xmm4
   20fe4:	66 41 0f 56 e5       	orpd   %xmm13,%xmm4
   20fe9:	66 41 0f 28 ca       	movapd %xmm10,%xmm1
   20fee:	66 0f 5e ce          	divpd  %xmm6,%xmm1
   20ff2:	66 41 0f 28 f1       	movapd %xmm9,%xmm6
   20ff7:	66 0f 5e b4 24 b0 01 	divpd  0x1b0(%rsp),%xmm6
   20ffe:	00 00 
   21000:	66 41 0f 54 cc       	andpd  %xmm12,%xmm1
   21005:	66 44 0f 55 e0       	andnpd %xmm0,%xmm12
   2100a:	66 44 0f 56 e1       	orpd   %xmm1,%xmm12
   2100f:	66 0f 54 f2          	andpd  %xmm2,%xmm6
   21013:	66 0f 55 d0          	andnpd %xmm0,%xmm2
   21017:	66 0f 56 d6          	orpd   %xmm6,%xmm2
   2101b:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   2101f:	66 0f c2 cb 01       	cmpltpd %xmm3,%xmm1
   21024:	66 0f 54 d9          	andpd  %xmm1,%xmm3
   21028:	66 0f 55 c8          	andnpd %xmm0,%xmm1
   2102c:	66 0f 56 cb          	orpd   %xmm3,%xmm1
   21030:	66 0f 57 db          	xorpd  %xmm3,%xmm3
   21034:	66 0f c2 dc 01       	cmpltpd %xmm4,%xmm3
   21039:	66 0f 54 e3          	andpd  %xmm3,%xmm4
   2103d:	66 0f 55 d8          	andnpd %xmm0,%xmm3
   21041:	66 0f 56 dc          	orpd   %xmm4,%xmm3
   21045:	66 0f 57 e4          	xorpd  %xmm4,%xmm4
   21049:	66 41 0f c2 e4 01    	cmpltpd %xmm12,%xmm4
   2104f:	66 44 0f 54 e4       	andpd  %xmm4,%xmm12
   21054:	66 0f 55 e0          	andnpd %xmm0,%xmm4
   21058:	66 41 0f 56 e4       	orpd   %xmm12,%xmm4
   2105d:	66 0f 57 ed          	xorpd  %xmm5,%xmm5
   21061:	66 0f c2 ea 01       	cmpltpd %xmm2,%xmm5
   21066:	66 0f 54 d5          	andpd  %xmm5,%xmm2
   2106a:	66 0f 55 e8          	andnpd %xmm0,%xmm5
   2106e:	66 0f 56 ea          	orpd   %xmm2,%xmm5
   21072:	66 0f 28 05 a6 41 fe 	movapd -0x1be5a(%rip),%xmm0        # 5220 <std::thread::current::id::ID+0x45a8>
   21079:	ff 
   2107a:	66 44 0f 28 ac 24 f0 	movapd 0x1f0(%rsp),%xmm13
   21081:	01 00 00 
   21084:	66 44 0f 54 e8       	andpd  %xmm0,%xmm13
   21089:	66 44 0f 58 ac 24 c0 	addpd  0xc0(%rsp),%xmm13
   21090:	00 00 00 
   21093:	66 44 0f 28 a4 24 d0 	movapd 0x1d0(%rsp),%xmm12
   2109a:	01 00 00 
   2109d:	66 44 0f 54 e0       	andpd  %xmm0,%xmm12
   210a2:	66 44 0f 58 a4 24 e0 	addpd  0x1e0(%rsp),%xmm12
   210a9:	01 00 00 
   210ac:	66 0f 54 f8          	andpd  %xmm0,%xmm7
   210b0:	66 0f 28 35 68 44 fe 	movapd -0x1bb98(%rip),%xmm6        # 5520 <std::thread::current::id::ID+0x48a8>
   210b7:	ff 
   210b8:	66 44 0f 59 ee       	mulpd  %xmm6,%xmm13
   210bd:	66 41 0f c2 fd 02    	cmplepd %xmm13,%xmm7
   210c3:	66 44 0f 59 e6       	mulpd  %xmm6,%xmm12
   210c8:	66 44 0f 54 c0       	andpd  %xmm0,%xmm8
   210cd:	66 45 0f c2 c4 02    	cmplepd %xmm12,%xmm8
   210d3:	66 0f 54 7c 24 10    	andpd  0x10(%rsp),%xmm7
   210d9:	66 45 0f 54 c3       	andpd  %xmm11,%xmm8
   210de:	66 0f 28 f1          	movapd %xmm1,%xmm6
   210e2:	66 0f 5d f4          	minpd  %xmm4,%xmm6
   210e6:	66 0f 55 fe          	andnpd %xmm6,%xmm7
   210ea:	66 0f 28 f3          	movapd %xmm3,%xmm6
   210ee:	66 0f 5d f5          	minpd  %xmm5,%xmm6
   210f2:	66 44 0f 55 c6       	andnpd %xmm6,%xmm8
   210f7:	66 0f 29 bc 24 00 02 	movapd %xmm7,0x200(%rsp)
   210fe:	00 00 
   21100:	66 0f 5f cc          	maxpd  %xmm4,%xmm1
   21104:	66 0f 5f dd          	maxpd  %xmm5,%xmm3
   21108:	66 44 0f 29 84 24 10 	movapd %xmm8,0x210(%rsp)
   2110f:	02 00 00 
   21112:	66 0f 29 8c 24 20 02 	movapd %xmm1,0x220(%rsp)
   21119:	00 00 
   2111b:	66 0f 29 9c 24 30 02 	movapd %xmm3,0x230(%rsp)
   21122:	00 00 
   21124:	66 0f 28 8c 24 e0 00 	movapd 0xe0(%rsp),%xmm1
   2112b:	00 00 
   2112d:	66 0f 28 e1          	movapd %xmm1,%xmm4
   21131:	66 41 0f c2 e6 04    	cmpneqpd %xmm14,%xmm4
   21137:	66 0f 54 c8          	andpd  %xmm0,%xmm1
   2113b:	66 41 0f 28 ea       	movapd %xmm10,%xmm5
   21140:	66 0f 54 e8          	andpd  %xmm0,%xmm5
   21144:	66 0f 28 dc          	movapd %xmm4,%xmm3
   21148:	66 0f 54 d9          	andpd  %xmm1,%xmm3
   2114c:	66 0f 55 e5          	andnpd %xmm5,%xmm4
   21150:	66 0f 56 e3          	orpd   %xmm3,%xmm4
   21154:	66 44 0f 28 9c 24 00 	movapd 0x100(%rsp),%xmm11
   2115b:	01 00 00 
   2115e:	66 41 0f 28 f3       	movapd %xmm11,%xmm6
   21163:	66 41 0f c2 f6 04    	cmpneqpd %xmm14,%xmm6
   21169:	66 44 0f 28 54 24 20 	movapd 0x20(%rsp),%xmm10
   21170:	66 41 0f 28 fa       	movapd %xmm10,%xmm7
   21175:	66 41 0f c2 fe 04    	cmpneqpd %xmm14,%xmm7
   2117b:	66 0f 28 9c 24 f0 00 	movapd 0xf0(%rsp),%xmm3
   21182:	00 00 
   21184:	66 44 0f c2 f3 04    	cmpneqpd %xmm3,%xmm14
   2118a:	66 0f 54 d8          	andpd  %xmm0,%xmm3
   2118e:	66 45 0f 28 c1       	movapd %xmm9,%xmm8
   21193:	66 44 0f 54 c0       	andpd  %xmm0,%xmm8
   21198:	66 45 0f 28 ce       	movapd %xmm14,%xmm9
   2119d:	66 44 0f 54 cb       	andpd  %xmm3,%xmm9
   211a2:	66 45 0f 55 f0       	andnpd %xmm8,%xmm14
   211a7:	66 45 0f 56 f1       	orpd   %xmm9,%xmm14
   211ac:	66 45 0f 28 cb       	movapd %xmm11,%xmm9
   211b1:	66 44 0f 54 c8       	andpd  %xmm0,%xmm9
   211b6:	66 44 0f 54 ce       	andpd  %xmm6,%xmm9
   211bb:	66 0f 55 f4          	andnpd %xmm4,%xmm6
   211bf:	66 41 0f 56 f1       	orpd   %xmm9,%xmm6
   211c4:	66 41 0f 28 e2       	movapd %xmm10,%xmm4
   211c9:	66 0f 54 e0          	andpd  %xmm0,%xmm4
   211cd:	66 0f 54 e7          	andpd  %xmm7,%xmm4
   211d1:	66 41 0f 55 fe       	andnpd %xmm14,%xmm7
   211d6:	66 0f 56 fc          	orpd   %xmm4,%xmm7
   211da:	66 0f 28 15 ee 40 fe 	movapd -0x1bf12(%rip),%xmm2        # 52d0 <std::thread::current::id::ID+0x4658>
   211e1:	ff 
   211e2:	66 0f 5f f2          	maxpd  %xmm2,%xmm6
   211e6:	66 0f 5f fa          	maxpd  %xmm2,%xmm7
   211ea:	66 0f 5f cd          	maxpd  %xmm5,%xmm1
   211ee:	66 41 0f 5f d8       	maxpd  %xmm8,%xmm3
   211f3:	66 0f 28 ac 24 a0 01 	movapd 0x1a0(%rsp),%xmm5
   211fa:	00 00 
   211fc:	66 0f 28 d5          	movapd %xmm5,%xmm2
   21200:	66 0f 54 d0          	andpd  %xmm0,%xmm2
   21204:	66 0f 5f ca          	maxpd  %xmm2,%xmm1
   21208:	66 0f 5e ce          	divpd  %xmm6,%xmm1
   2120c:	66 0f 28 a4 24 70 01 	movapd 0x170(%rsp),%xmm4
   21213:	00 00 
   21215:	66 0f 54 c4          	andpd  %xmm4,%xmm0
   21219:	66 0f 5f d8          	maxpd  %xmm0,%xmm3
   2121d:	66 0f 5e df          	divpd  %xmm7,%xmm3
   21221:	f2 0f 10 05 07 60 fe 	movsd  -0x19ff9(%rip),%xmm0        # 7230 <std::thread::current::id::ID+0x65b8>
   21228:	ff 
   21229:	66 0f 28 15 6f 44 fe 	movapd -0x1bb91(%rip),%xmm2        # 56a0 <std::thread::current::id::ID+0x4a28>
   21230:	ff 
   21231:	66 0f 58 ca          	addpd  %xmm2,%xmm1
   21235:	66 0f 58 da          	addpd  %xmm2,%xmm3
   21239:	66 0f c2 c2 00       	cmpeqpd %xmm2,%xmm0
   2123e:	66 0f c2 d2 00       	cmpeqpd %xmm2,%xmm2
   21243:	66 0f 54 ca          	andpd  %xmm2,%xmm1
   21247:	66 0f 28 35 51 44 fe 	movapd -0x1bbaf(%rip),%xmm6        # 56a0 <std::thread::current::id::ID+0x4a28>
   2124e:	ff 
   2124f:	66 0f 55 d6          	andnpd %xmm6,%xmm2
   21253:	66 0f 56 d1          	orpd   %xmm1,%xmm2
   21257:	66 0f 29 94 24 40 02 	movapd %xmm2,0x240(%rsp)
   2125e:	00 00 
   21260:	66 0f 54 d8          	andpd  %xmm0,%xmm3
   21264:	66 0f 55 c6          	andnpd %xmm6,%xmm0
   21268:	66 0f 56 c3          	orpd   %xmm3,%xmm0
   2126c:	66 0f 29 84 24 50 02 	movapd %xmm0,0x250(%rsp)
   21273:	00 00 
   21275:	66 0f 28 c5          	movapd %xmm5,%xmm0
   21279:	66 41 0f 57 c7       	xorpd  %xmm15,%xmm0
   2127e:	66 0f 29 84 24 a0 00 	movapd %xmm0,0xa0(%rsp)
   21285:	00 00 
   21287:	66 44 0f 57 fc       	xorpd  %xmm4,%xmm15
   2128c:	66 44 0f 29 bc 24 b0 	movapd %xmm15,0xb0(%rsp)
   21293:	00 00 00 
   21296:	48 8d bc 24 20 01 00 	lea    0x120(%rsp),%rdi
   2129d:	00 
   2129e:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
   212a3:	48 8d 94 24 00 02 00 	lea    0x200(%rsp),%rdx
   212aa:	00 
   212ab:	48 8d 8c 24 40 02 00 	lea    0x240(%rsp),%rcx
   212b2:	00 
   212b3:	41 b8 60 00 00 00    	mov    $0x60,%r8d
   212b9:	e8 62 03 00 00       	call   21620 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::entry::<fearless_simd::generated::sse2::Sse2, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::sse2::Sse2>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>, usize, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::sse2::Sse2>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2]>>
   212be:	f2 0f 10 84 24 20 01 	movsd  0x120(%rsp),%xmm0
   212c5:	00 00 
   212c7:	f2 0f 10 8c 24 28 01 	movsd  0x128(%rsp),%xmm1
   212ce:	00 00 
   212d0:	f2 0f 10 9c 24 30 01 	movsd  0x130(%rsp),%xmm3
   212d7:	00 00 
   212d9:	f2 0f 5d 05 ff 5e fe 	minsd  -0x1a101(%rip),%xmm0        # 71e0 <std::thread::current::id::ID+0x6568>
   212e0:	ff 
   212e1:	f2 0f 5d c8          	minsd  %xmm0,%xmm1
   212e5:	f2 0f 5d d9          	minsd  %xmm1,%xmm3
   212e9:	66 48 0f 7e d8       	movq   %xmm3,%rax
   212ee:	49 bf ff ff ff ff ff 	movabs $0x7fffffffffffffff,%r15
   212f5:	ff ff 7f 
   212f8:	4c 21 f8             	and    %r15,%rax
   212fb:	41 be 0e 00 00 00    	mov    $0xe,%r14d
   21301:	48 b9 ff ff ff ff ff 	movabs $0x7fefffffffffffff,%rcx
   21308:	ff ef 7f 
   2130b:	48 39 c8             	cmp    %rcx,%rax
   2130e:	7e 12                	jle    21322 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xa12>
   21310:	4c 89 f0             	mov    %r14,%rax
   21313:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
   21317:	5b                   	pop    %rbx
   21318:	41 5c                	pop    %r12
   2131a:	41 5d                	pop    %r13
   2131c:	41 5e                	pop    %r14
   2131e:	41 5f                	pop    %r15
   21320:	5d                   	pop    %rbp
   21321:	c3                   	ret
   21322:	0f 28 84 24 40 01 00 	movaps 0x140(%rsp),%xmm0
   21329:	00 
   2132a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   2132f:	0f 28 84 24 50 01 00 	movaps 0x150(%rsp),%xmm0
   21336:	00 
   21337:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
   2133c:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   21342:	0f 57 c9             	xorps  %xmm1,%xmm1
   21345:	f3 0f 5a c8          	cvtss2sd %xmm0,%xmm1
   21349:	0f 28 c1             	movaps %xmm1,%xmm0
   2134c:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   21350:	f2 0f 11 8c 24 c0 00 	movsd  %xmm1,0xc0(%rsp)
   21357:	00 00 
   21359:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   2135d:	f2 0f 10 0d cb 5e fe 	movsd  -0x1a135(%rip),%xmm1        # 7230 <std::thread::current::id::ID+0x65b8>
   21364:	ff 
   21365:	f2 0f 5e c8          	divsd  %xmm0,%xmm1
   21369:	66 0f 14 c9          	unpcklpd %xmm1,%xmm1
   2136d:	66 0f 28 84 24 a0 01 	movapd 0x1a0(%rsp),%xmm0
   21374:	00 00 
   21376:	66 0f 5c c1          	subpd  %xmm1,%xmm0
   2137a:	66 0f 29 84 24 a0 00 	movapd %xmm0,0xa0(%rsp)
   21381:	00 00 
   21383:	66 0f 28 94 24 70 01 	movapd 0x170(%rsp),%xmm2
   2138a:	00 00 
   2138c:	66 0f 5c d1          	subpd  %xmm1,%xmm2
   21390:	0f 28 84 24 00 01 00 	movaps 0x100(%rsp),%xmm0
   21397:	00 
   21398:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
   2139d:	0f 28 44 24 20       	movaps 0x20(%rsp),%xmm0
   213a2:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
   213a7:	0f 28 84 24 e0 00 00 	movaps 0xe0(%rsp),%xmm0
   213ae:	00 
   213af:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
   213b4:	0f 28 84 24 f0 00 00 	movaps 0xf0(%rsp),%xmm0
   213bb:	00 
   213bc:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
   213c1:	0f 28 84 24 80 01 00 	movaps 0x180(%rsp),%xmm0
   213c8:	00 
   213c9:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
   213d0:	00 
   213d1:	0f 28 84 24 90 01 00 	movaps 0x190(%rsp),%xmm0
   213d8:	00 
   213d9:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
   213e0:	00 
   213e1:	66 0f 29 94 24 b0 00 	movapd %xmm2,0xb0(%rsp)
   213e8:	00 00 
   213ea:	66 0f 28 c3          	movapd %xmm3,%xmm0
   213ee:	66 0f 14 c3          	unpcklpd %xmm3,%xmm0
   213f2:	66 0f 29 84 24 60 02 	movapd %xmm0,0x260(%rsp)
   213f9:	00 00 
   213fb:	66 0f 29 84 24 70 02 	movapd %xmm0,0x270(%rsp)
   21402:	00 00 
   21404:	48 8d bc 24 20 01 00 	lea    0x120(%rsp),%rdi
   2140b:	00 
   2140c:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
   21411:	48 8d 94 24 00 02 00 	lea    0x200(%rsp),%rdx
   21418:	00 
   21419:	48 8d 8c 24 60 02 00 	lea    0x260(%rsp),%rcx
   21420:	00 
   21421:	41 b8 40 00 00 00    	mov    $0x40,%r8d
   21427:	0f 29 5c 24 20       	movaps %xmm3,0x20(%rsp)
   2142c:	e8 ef 01 00 00       	call   21620 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::entry::<fearless_simd::generated::sse2::Sse2, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::sse2::Sse2>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>, usize, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::sse2::Sse2>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2]>>
   21431:	66 0f 28 54 24 20    	movapd 0x20(%rsp),%xmm2
   21437:	66 0f 28 c2          	movapd %xmm2,%xmm0
   2143b:	f2 0f 5d 84 24 20 01 	minsd  0x120(%rsp),%xmm0
   21442:	00 00 
   21444:	66 0f 28 c8          	movapd %xmm0,%xmm1
   21448:	f2 0f c2 c8 03       	cmpunordsd %xmm0,%xmm1
   2144d:	66 0f 54 d1          	andpd  %xmm1,%xmm2
   21451:	66 0f 55 c8          	andnpd %xmm0,%xmm1
   21455:	66 0f 56 ca          	orpd   %xmm2,%xmm1
   21459:	f2 0f 10 84 24 28 01 	movsd  0x128(%rsp),%xmm0
   21460:	00 00 
   21462:	66 0f 28 d1          	movapd %xmm1,%xmm2
   21466:	f2 0f 5d d0          	minsd  %xmm0,%xmm2
   2146a:	66 0f 28 da          	movapd %xmm2,%xmm3
   2146e:	f2 0f c2 da 03       	cmpunordsd %xmm2,%xmm3
   21473:	66 0f 54 cb          	andpd  %xmm3,%xmm1
   21477:	66 0f 55 da          	andnpd %xmm2,%xmm3
   2147b:	66 0f 56 d9          	orpd   %xmm1,%xmm3
   2147f:	f2 0f 10 84 24 30 01 	movsd  0x130(%rsp),%xmm0
   21486:	00 00 
   21488:	66 0f 28 cb          	movapd %xmm3,%xmm1
   2148c:	66 0f 28 54 24 10    	movapd 0x10(%rsp),%xmm2
   21492:	66 0f 5d 94 24 40 01 	minpd  0x140(%rsp),%xmm2
   21499:	00 00 
   2149b:	f2 0f 5d c8          	minsd  %xmm0,%xmm1
   2149f:	66 0f 28 c1          	movapd %xmm1,%xmm0
   214a3:	f2 0f c2 c1 03       	cmpunordsd %xmm1,%xmm0
   214a8:	66 0f 54 d8          	andpd  %xmm0,%xmm3
   214ac:	66 0f 55 c1          	andnpd %xmm1,%xmm0
   214b0:	66 0f 56 c3          	orpd   %xmm3,%xmm0
   214b4:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
   214b8:	0f 87 52 fe ff ff    	ja     21310 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xa00>
   214be:	66 0f 28 ca          	movapd %xmm2,%xmm1
   214c2:	66 0f 15 ca          	unpckhpd %xmm2,%xmm1
   214c6:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
   214ca:	0f 87 40 fe ff ff    	ja     21310 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xa00>
   214d0:	66 0f 28 4c 24 30    	movapd 0x30(%rsp),%xmm1
   214d6:	f2 0f 5d 8c 24 50 01 	minsd  0x150(%rsp),%xmm1
   214dd:	00 00 
   214df:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
   214e3:	0f 87 27 fe ff ff    	ja     21310 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xa00>
   214e9:	f2 0f 59 84 24 c0 00 	mulsd  0xc0(%rsp),%xmm0
   214f0:	00 00 
   214f2:	66 48 0f 7e c0       	movq   %xmm0,%rax
   214f7:	48 85 c0             	test   %rax,%rax
   214fa:	0f 98 c1             	sets   %cl
   214fd:	49 21 c7             	and    %rax,%r15
   21500:	48 b8 00 00 00 00 00 	movabs $0xfff0000000000000,%rax
   21507:	00 f0 ff 
   2150a:	4c 01 f8             	add    %r15,%rax
   2150d:	48 c1 e8 35          	shr    $0x35,%rax
   21511:	3d ff 03 00 00       	cmp    $0x3ff,%eax
   21516:	0f 92 c0             	setb   %al
   21519:	20 c8                	and    %cl,%al
   2151b:	49 8d 57 ff          	lea    -0x1(%r15),%rdx
   2151f:	48 be ff ff ff ff ff 	movabs $0xfffffffffffff,%rsi
   21526:	ff 0f 00 
   21529:	48 39 f2             	cmp    %rsi,%rdx
   2152c:	0f 92 c2             	setb   %dl
   2152f:	20 ca                	and    %cl,%dl
   21531:	48 b9 00 00 00 00 00 	movabs $0x7ff0000000000000,%rcx
   21538:	00 f0 7f 
   2153b:	49 39 cf             	cmp    %rcx,%r15
   2153e:	0f 9f c1             	setg   %cl
   21541:	40 0f 94 c6          	sete   %sil
   21545:	40 08 ce             	or     %cl,%sil
   21548:	40 08 d6             	or     %dl,%sil
   2154b:	40 08 c6             	or     %al,%sil
   2154e:	0f 85 bc fd ff ff    	jne    21310 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xa00>
   21554:	0f 57 c9             	xorps  %xmm1,%xmm1
   21557:	f2 0f 5a c8          	cvtsd2ss %xmm0,%xmm1
   2155b:	0f 28 84 24 d0 00 00 	movaps 0xd0(%rsp),%xmm0
   21562:	00 
   21563:	0f 56 05 66 42 fe ff 	orps   -0x1bd9a(%rip),%xmm0        # 57d0 <std::thread::current::id::ID+0x4b58>
   2156a:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
   21571:	00 
   21572:	41 bc 40 00 00 00    	mov    $0x40,%r12d
   21578:	0f b6 db             	movzbl %bl,%ebx
   2157b:	4c 8d 7c 24 40       	lea    0x40(%rsp),%r15
   21580:	eb 1b                	jmp    2159d <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xc8d>
   21582:	41 bd 01 00 00 80    	mov    $0x80000001,%r13d
   21588:	66 41 0f 6e cd       	movd   %r13d,%xmm1
   2158d:	0f 57 c0             	xorps  %xmm0,%xmm0
   21590:	f3 0f 5f c8          	maxss  %xmm0,%xmm1
   21594:	41 ff cc             	dec    %r12d
   21597:	0f 84 73 fd ff ff    	je     21310 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xa00>
   2159d:	66 41 0f 7e cd       	movd   %xmm1,%r13d
   215a2:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   215a8:	f3 0f 11 44 24 40    	movss  %xmm0,0x40(%rsp)
   215ae:	f3 0f 11 4c 24 10    	movss  %xmm1,0x10(%rsp)
   215b4:	f3 0f 11 4c 24 44    	movss  %xmm1,0x44(%rsp)
   215ba:	0f 28 84 24 d0 00 00 	movaps 0xd0(%rsp),%xmm0
   215c1:	00 
   215c2:	f3 0f 11 44 24 48    	movss  %xmm0,0x48(%rsp)
   215c8:	c7 44 24 4c 00 00 80 	movl   $0xff800000,0x4c(%rsp)
   215cf:	ff 
   215d0:	4c 89 ff             	mov    %r15,%rdi
   215d3:	89 de                	mov    %ebx,%esi
   215d5:	e8 d6 0c 00 00       	call   222b0 <gpui_canvas::color::gamut::in_gamut>
   215da:	84 c0                	test   %al,%al
   215dc:	75 28                	jne    21606 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xcf6>
   215de:	41 81 fd 00 00 80 ff 	cmp    $0xff800000,%r13d
   215e5:	66 0f 6e 4c 24 10    	movd   0x10(%rsp),%xmm1
   215eb:	74 a0                	je     2158d <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xc7d>
   215ed:	44 89 e8             	mov    %r13d,%eax
   215f0:	25 ff ff ff 7f       	and    $0x7fffffff,%eax
   215f5:	74 8b                	je     21582 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xc72>
   215f7:	41 39 c5             	cmp    %eax,%r13d
   215fa:	75 05                	jne    21601 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xcf1>
   215fc:	41 ff cd             	dec    %r13d
   215ff:	eb 87                	jmp    21588 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xc78>
   21601:	41 ff c5             	inc    %r13d
   21604:	eb 82                	jmp    21588 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xc78>
   21606:	49 c1 e5 20          	shl    $0x20,%r13
   2160a:	41 be ff ff ff ff    	mov    $0xffffffff,%r14d
   21610:	4d 09 ee             	or     %r13,%r14
   21613:	e9 f8 fc ff ff       	jmp    21310 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xa00>
   21618:	cc                   	int3
   21619:	cc                   	int3
   2161a:	cc                   	int3
   2161b:	cc                   	int3
   2161c:	cc                   	int3
   2161d:	cc                   	int3
   2161e:	cc                   	int3
   2161f:	cc                   	int3

<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::entry::<fearless_simd::generated::sse2::Sse2, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::sse2::Sse2>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>, usize, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::sse2::Sse2>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2]>:
   21620:	55                   	push   %rbp
   21621:	48 89 e5             	mov    %rsp,%rbp
   21624:	48 83 e4 e0          	and    $0xffffffffffffffe0,%rsp
   21628:	48 81 ec c0 03 00 00 	sub    $0x3c0,%rsp
   2162f:	66 44 0f 28 06       	movapd (%rsi),%xmm8
   21634:	66 44 0f 28 76 10    	movapd 0x10(%rsi),%xmm14
   2163a:	66 44 0f 28 5e 20    	movapd 0x20(%rsi),%xmm11
   21640:	66 44 0f 28 7e 30    	movapd 0x30(%rsi),%xmm15
   21646:	66 0f 28 66 40       	movapd 0x40(%rsi),%xmm4
   2164b:	66 0f 28 6e 60       	movapd 0x60(%rsi),%xmm5
   21650:	66 0f 28 76 70       	movapd 0x70(%rsi),%xmm6
   21655:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   21659:	66 0f c2 d5 01       	cmpltpd %xmm5,%xmm2
   2165e:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   21662:	66 0f c2 ce 01       	cmpltpd %xmm6,%xmm1
   21667:	66 0f 28 05 e1 40 fe 	movapd -0x1bf1f(%rip),%xmm0        # 5750 <std::thread::current::id::ID+0x4ad8>
   2166e:	ff 
   2166f:	66 0f 55 d0          	andnpd %xmm0,%xmm2
   21673:	66 0f 29 54 24 30    	movapd %xmm2,0x30(%rsp)
   21679:	66 0f 55 c8          	andnpd %xmm0,%xmm1
   2167d:	66 0f 29 4c 24 40    	movapd %xmm1,0x40(%rsp)
   21683:	0f 28 42 20          	movaps 0x20(%rdx),%xmm0
   21687:	0f 28 4a 30          	movaps 0x30(%rdx),%xmm1
   2168b:	0f 29 84 24 00 02 00 	movaps %xmm0,0x200(%rsp)
   21692:	00 
   21693:	0f 29 8c 24 10 02 00 	movaps %xmm1,0x210(%rsp)
   2169a:	00 
   2169b:	0f 28 02             	movaps (%rdx),%xmm0
   2169e:	0f 29 84 24 e0 01 00 	movaps %xmm0,0x1e0(%rsp)
   216a5:	00 
   216a6:	0f 28 42 10          	movaps 0x10(%rdx),%xmm0
   216aa:	0f 29 84 24 f0 01 00 	movaps %xmm0,0x1f0(%rsp)
   216b1:	00 
   216b2:	0f 28 84 24 e0 01 00 	movaps 0x1e0(%rsp),%xmm0
   216b9:	00 
   216ba:	0f 28 8c 24 f0 01 00 	movaps 0x1f0(%rsp),%xmm1
   216c1:	00 
   216c2:	0f 28 94 24 00 02 00 	movaps 0x200(%rsp),%xmm2
   216c9:	00 
   216ca:	0f 28 9c 24 10 02 00 	movaps 0x210(%rsp),%xmm3
   216d1:	00 
   216d2:	0f 29 9c 24 10 03 00 	movaps %xmm3,0x310(%rsp)
   216d9:	00 
   216da:	0f 29 94 24 00 03 00 	movaps %xmm2,0x300(%rsp)
   216e1:	00 
   216e2:	0f 29 8c 24 f0 02 00 	movaps %xmm1,0x2f0(%rsp)
   216e9:	00 
   216ea:	0f 29 84 24 e0 02 00 	movaps %xmm0,0x2e0(%rsp)
   216f1:	00 
   216f2:	0f 28 84 24 10 03 00 	movaps 0x310(%rsp),%xmm0
   216f9:	00 
   216fa:	0f 29 84 24 70 03 00 	movaps %xmm0,0x370(%rsp)
   21701:	00 
   21702:	0f 28 84 24 d0 02 00 	movaps 0x2d0(%rsp),%xmm0
   21709:	00 
   2170a:	0f 28 8c 24 e0 02 00 	movaps 0x2e0(%rsp),%xmm1
   21711:	00 
   21712:	0f 28 94 24 f0 02 00 	movaps 0x2f0(%rsp),%xmm2
   21719:	00 
   2171a:	0f 28 9c 24 00 03 00 	movaps 0x300(%rsp),%xmm3
   21721:	00 
   21722:	0f 29 9c 24 60 03 00 	movaps %xmm3,0x360(%rsp)
   21729:	00 
   2172a:	0f 29 94 24 50 03 00 	movaps %xmm2,0x350(%rsp)
   21731:	00 
   21732:	0f 29 8c 24 40 03 00 	movaps %xmm1,0x340(%rsp)
   21739:	00 
   2173a:	0f 29 84 24 30 03 00 	movaps %xmm0,0x330(%rsp)
   21741:	00 
   21742:	66 0f 28 05 06 40 fe 	movapd -0x1bffa(%rip),%xmm0        # 5750 <std::thread::current::id::ID+0x4ad8>
   21749:	ff 
   2174a:	66 0f 29 84 24 80 03 	movapd %xmm0,0x380(%rsp)
   21751:	00 00 
   21753:	66 0f 29 84 24 90 03 	movapd %xmm0,0x390(%rsp)
   2175a:	00 00 
   2175c:	48 8d 84 24 40 03 00 	lea    0x340(%rsp),%rax
   21763:	00 
   21764:	66 0f 28 0d b4 3a fe 	movapd -0x1c54c(%rip),%xmm1        # 5220 <std::thread::current::id::ID+0x45a8>
   2176b:	ff 
   2176c:	66 41 0f 28 d0       	movapd %xmm8,%xmm2
   21771:	66 0f 54 d1          	andpd  %xmm1,%xmm2
   21775:	66 41 0f 28 de       	movapd %xmm14,%xmm3
   2177a:	66 0f 54 d9          	andpd  %xmm1,%xmm3
   2177e:	66 41 0f 28 fb       	movapd %xmm11,%xmm7
   21783:	66 0f 54 f9          	andpd  %xmm1,%xmm7
   21787:	66 45 0f 28 cf       	movapd %xmm15,%xmm9
   2178c:	66 44 0f 54 c9       	andpd  %xmm1,%xmm9
   21791:	66 0f 29 a4 24 80 00 	movapd %xmm4,0x80(%rsp)
   21798:	00 00 
   2179a:	66 0f 54 e1          	andpd  %xmm1,%xmm4
   2179e:	66 0f 29 a4 24 d0 01 	movapd %xmm4,0x1d0(%rsp)
   217a5:	00 00 
   217a7:	66 0f 28 66 50       	movapd 0x50(%rsi),%xmm4
   217ac:	66 0f 29 a4 24 b0 00 	movapd %xmm4,0xb0(%rsp)
   217b3:	00 00 
   217b5:	66 0f 54 e1          	andpd  %xmm1,%xmm4
   217b9:	66 0f 29 a4 24 10 01 	movapd %xmm4,0x110(%rsp)
   217c0:	00 00 
   217c2:	66 0f 28 e5          	movapd %xmm5,%xmm4
   217c6:	66 0f 54 e1          	andpd  %xmm1,%xmm4
   217ca:	66 0f 29 a4 24 50 02 	movapd %xmm4,0x250(%rsp)
   217d1:	00 00 
   217d3:	66 0f 28 e6          	movapd %xmm6,%xmm4
   217d7:	66 0f 54 e1          	andpd  %xmm1,%xmm4
   217db:	66 0f 29 a4 24 40 02 	movapd %xmm4,0x240(%rsp)
   217e2:	00 00 
   217e4:	66 0f 28 0d e4 3b fe 	movapd -0x1c41c(%rip),%xmm1        # 53d0 <std::thread::current::id::ID+0x4758>
   217eb:	ff 
   217ec:	66 41 0f 28 e0       	movapd %xmm8,%xmm4
   217f1:	66 0f 59 e1          	mulpd  %xmm1,%xmm4
   217f5:	66 0f 29 a4 24 c0 01 	movapd %xmm4,0x1c0(%rsp)
   217fc:	00 00 
   217fe:	66 41 0f 28 e6       	movapd %xmm14,%xmm4
   21803:	66 0f 59 e1          	mulpd  %xmm1,%xmm4
   21807:	66 0f 29 a4 24 b0 01 	movapd %xmm4,0x1b0(%rsp)
   2180e:	00 00 
   21810:	66 41 0f 28 e3       	movapd %xmm11,%xmm4
   21815:	66 41 0f 58 e3       	addpd  %xmm11,%xmm4
   2181a:	66 0f 29 a4 24 a0 01 	movapd %xmm4,0x1a0(%rsp)
   21821:	00 00 
   21823:	66 41 0f 28 e7       	movapd %xmm15,%xmm4
   21828:	66 41 0f 58 e7       	addpd  %xmm15,%xmm4
   2182d:	66 0f 29 a4 24 f0 00 	movapd %xmm4,0xf0(%rsp)
   21834:	00 00 
   21836:	66 0f 29 94 24 90 02 	movapd %xmm2,0x290(%rsp)
   2183d:	00 00 
   2183f:	66 0f 59 d1          	mulpd  %xmm1,%xmm2
   21843:	66 0f 29 94 24 90 01 	movapd %xmm2,0x190(%rsp)
   2184a:	00 00 
   2184c:	66 0f 29 9c 24 80 02 	movapd %xmm3,0x280(%rsp)
   21853:	00 00 
   21855:	66 0f 59 cb          	mulpd  %xmm3,%xmm1
   21859:	66 0f 29 8c 24 00 01 	movapd %xmm1,0x100(%rsp)
   21860:	00 00 
   21862:	66 0f 29 bc 24 70 02 	movapd %xmm7,0x270(%rsp)
   21869:	00 00 
   2186b:	66 0f 58 ff          	addpd  %xmm7,%xmm7
   2186f:	66 0f 29 bc 24 e0 00 	movapd %xmm7,0xe0(%rsp)
   21876:	00 00 
   21878:	66 44 0f 29 8c 24 60 	movapd %xmm9,0x260(%rsp)
   2187f:	02 00 00 
   21882:	66 45 0f 58 c9       	addpd  %xmm9,%xmm9
   21887:	66 44 0f 29 8c 24 d0 	movapd %xmm9,0xd0(%rsp)
   2188e:	00 00 00 
   21891:	31 d2                	xor    %edx,%edx
   21893:	0f 28 09             	movaps (%rcx),%xmm1
   21896:	0f 29 8c 24 30 02 00 	movaps %xmm1,0x230(%rsp)
   2189d:	00 
   2189e:	66 0f 28 49 10       	movapd 0x10(%rcx),%xmm1
   218a3:	66 0f 29 8c 24 20 02 	movapd %xmm1,0x220(%rsp)
   218aa:	00 00 
   218ac:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   218b0:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   218b4:	66 0f 29 44 24 60    	movapd %xmm0,0x60(%rsp)
   218ba:	66 0f 29 44 24 50    	movapd %xmm0,0x50(%rsp)
   218c0:	66 44 0f 29 84 24 80 	movapd %xmm8,0x180(%rsp)
   218c7:	01 00 00 
   218ca:	66 44 0f 29 b4 24 70 	movapd %xmm14,0x170(%rsp)
   218d1:	01 00 00 
   218d4:	66 44 0f 29 9c 24 60 	movapd %xmm11,0x160(%rsp)
   218db:	01 00 00 
   218de:	66 44 0f 29 bc 24 50 	movapd %xmm15,0x150(%rsp)
   218e5:	01 00 00 
   218e8:	66 0f 29 ac 24 40 01 	movapd %xmm5,0x140(%rsp)
   218ef:	00 00 
   218f1:	66 0f 29 b4 24 a0 02 	movapd %xmm6,0x2a0(%rsp)
   218f8:	00 00 
   218fa:	eb 74                	jmp    21970 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::entry::<fearless_simd::generated::sse2::Sse2, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::sse2::Sse2>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>, usize, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::sse2::Sse2>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2]>+0x350>
   218fc:	0f 1f 40 00          	nopl   0x0(%rax)
   21900:	48 ff c2             	inc    %rdx
   21903:	66 0f 54 34 24       	andpd  (%rsp),%xmm6
   21908:	66 0f 54 8c 24 a0 00 	andpd  0xa0(%rsp),%xmm1
   2190f:	00 00 
   21911:	66 0f 28 54 24 70    	movapd 0x70(%rsp),%xmm2
   21917:	66 0f 54 94 24 20 01 	andpd  0x120(%rsp),%xmm2
   2191e:	00 00 
   21920:	66 0f 28 84 24 c0 00 	movapd 0xc0(%rsp),%xmm0
   21927:	00 00 
   21929:	66 0f 54 84 24 30 01 	andpd  0x130(%rsp),%xmm0
   21930:	00 00 
   21932:	66 0f 54 d6          	andpd  %xmm6,%xmm2
   21936:	66 0f 55 74 24 50    	andnpd 0x50(%rsp),%xmm6
   2193c:	66 0f 56 f2          	orpd   %xmm2,%xmm6
   21940:	66 0f 29 74 24 50    	movapd %xmm6,0x50(%rsp)
   21946:	66 0f 54 c1          	andpd  %xmm1,%xmm0
   2194a:	66 0f 55 4c 24 60    	andnpd 0x60(%rsp),%xmm1
   21950:	66 0f 56 c8          	orpd   %xmm0,%xmm1
   21954:	66 0f 29 4c 24 60    	movapd %xmm1,0x60(%rsp)
   2195a:	48 83 fa 03          	cmp    $0x3,%rdx
   2195e:	66 0f 28 4c 24 20    	movapd 0x20(%rsp),%xmm1
   21964:	66 0f 28 54 24 10    	movapd 0x10(%rsp),%xmm2
   2196a:	0f 84 11 09 00 00    	je     22281 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::entry::<fearless_simd::generated::sse2::Sse2, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::sse2::Sse2>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>, usize, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::sse2::Sse2>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2]>+0xc61>
   21970:	66 0f 29 94 24 20 01 	movapd %xmm2,0x120(%rsp)
   21977:	00 00 
   21979:	66 0f 29 8c 24 30 01 	movapd %xmm1,0x130(%rsp)
   21980:	00 00 
   21982:	48 89 d1             	mov    %rdx,%rcx
   21985:	48 c1 e1 05          	shl    $0x5,%rcx
   21989:	66 0f 28 0c 08       	movapd (%rax,%rcx,1),%xmm1
   2198e:	66 0f 28 44 08 10    	movapd 0x10(%rax,%rcx,1),%xmm0
   21994:	66 0f 28 d1          	movapd %xmm1,%xmm2
   21998:	66 44 0f 28 0d af 3d 	movapd -0x1c251(%rip),%xmm9        # 5750 <std::thread::current::id::ID+0x4ad8>
   2199f:	fe ff 
   219a1:	66 41 0f c2 d1 01    	cmpltpd %xmm9,%xmm2
   219a7:	66 0f 28 d8          	movapd %xmm0,%xmm3
   219ab:	66 41 0f c2 d9 01    	cmpltpd %xmm9,%xmm3
   219b1:	66 0f 29 54 24 70    	movapd %xmm2,0x70(%rsp)
   219b7:	66 0f 29 8c 24 b0 02 	movapd %xmm1,0x2b0(%rsp)
   219be:	00 00 
   219c0:	66 0f 54 d1          	andpd  %xmm1,%xmm2
   219c4:	66 0f 29 1c 24       	movapd %xmm3,(%rsp)
   219c9:	66 0f 29 84 24 90 00 	movapd %xmm0,0x90(%rsp)
   219d0:	00 00 
   219d2:	66 0f 54 d8          	andpd  %xmm0,%xmm3
   219d6:	66 0f 29 94 24 a0 00 	movapd %xmm2,0xa0(%rsp)
   219dd:	00 00 
   219df:	66 0f 28 f2          	movapd %xmm2,%xmm6
   219e3:	66 0f 28 05 35 38 fe 	movapd -0x1c7cb(%rip),%xmm0        # 5220 <std::thread::current::id::ID+0x45a8>
   219ea:	ff 
   219eb:	66 0f 54 f0          	andpd  %xmm0,%xmm6
   219ef:	66 0f 29 9c 24 c0 02 	movapd %xmm3,0x2c0(%rsp)
   219f6:	00 00 
   219f8:	66 44 0f 28 c3       	movapd %xmm3,%xmm8
   219fd:	66 44 0f 54 c0       	andpd  %xmm0,%xmm8
   21a02:	66 0f 28 05 96 3c fe 	movapd -0x1c36a(%rip),%xmm0        # 56a0 <std::thread::current::id::ID+0x4a28>
   21a09:	ff 
   21a0a:	66 0f 58 f0          	addpd  %xmm0,%xmm6
   21a0e:	66 44 0f 58 c0       	addpd  %xmm0,%xmm8
   21a13:	66 0f 28 05 05 3b fe 	movapd -0x1c4fb(%rip),%xmm0        # 5520 <std::thread::current::id::ID+0x48a8>
   21a1a:	ff 
   21a1b:	66 0f 59 f0          	mulpd  %xmm0,%xmm6
   21a1f:	66 44 0f 59 c0       	mulpd  %xmm0,%xmm8
   21a24:	b9 1f 00 00 00       	mov    $0x1f,%ecx
   21a29:	66 41 0f 28 e9       	movapd %xmm9,%xmm5
   21a2e:	66 90                	xchg   %ax,%ax
   21a30:	66 0f 29 ac 24 c0 00 	movapd %xmm5,0xc0(%rsp)
   21a37:	00 00 
   21a39:	66 44 0f 29 44 24 20 	movapd %xmm8,0x20(%rsp)
   21a40:	66 0f 29 74 24 10    	movapd %xmm6,0x10(%rsp)
   21a46:	66 0f 28 8c 24 a0 00 	movapd 0xa0(%rsp),%xmm1
   21a4d:	00 00 
   21a4f:	66 0f 28 e1          	movapd %xmm1,%xmm4
   21a53:	66 0f 5c e6          	subpd  %xmm6,%xmm4
   21a57:	66 0f 28 94 24 c0 02 	movapd 0x2c0(%rsp),%xmm2
   21a5e:	00 00 
   21a60:	66 0f 28 ea          	movapd %xmm2,%xmm5
   21a64:	66 41 0f 5c e8       	subpd  %xmm8,%xmm5
   21a69:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
   21a6d:	66 0f 5f e0          	maxpd  %xmm0,%xmm4
   21a71:	66 0f 5f e8          	maxpd  %xmm0,%xmm5
   21a75:	66 44 0f 28 54 24 10 	movapd 0x10(%rsp),%xmm10
   21a7c:	66 44 0f 58 d1       	addpd  %xmm1,%xmm10
   21a81:	66 41 0f 28 c0       	movapd %xmm8,%xmm0
   21a86:	66 0f 58 c2          	addpd  %xmm2,%xmm0
   21a8a:	66 44 0f 28 84 24 c0 	movapd 0x1c0(%rsp),%xmm8
   21a91:	01 00 00 
   21a94:	66 41 0f 28 f8       	movapd %xmm8,%xmm7
   21a99:	66 0f 59 fc          	mulpd  %xmm4,%xmm7
   21a9d:	66 0f 28 8c 24 b0 01 	movapd 0x1b0(%rsp),%xmm1
   21aa4:	00 00 
   21aa6:	66 0f 28 d9          	movapd %xmm1,%xmm3
   21aaa:	66 0f 59 dd          	mulpd  %xmm5,%xmm3
   21aae:	66 0f 28 94 24 a0 01 	movapd 0x1a0(%rsp),%xmm2
   21ab5:	00 00 
   21ab7:	66 0f 58 fa          	addpd  %xmm2,%xmm7
   21abb:	66 0f 58 9c 24 f0 00 	addpd  0xf0(%rsp),%xmm3
   21ac2:	00 00 
   21ac4:	66 0f 59 fc          	mulpd  %xmm4,%xmm7
   21ac8:	66 0f 59 dd          	mulpd  %xmm5,%xmm3
   21acc:	66 44 0f 28 9c 24 80 	movapd 0x80(%rsp),%xmm11
   21ad3:	00 00 00 
   21ad6:	66 41 0f 58 fb       	addpd  %xmm11,%xmm7
   21adb:	66 0f 28 b4 24 b0 00 	movapd 0xb0(%rsp),%xmm6
   21ae2:	00 00 
   21ae4:	66 0f 58 de          	addpd  %xmm6,%xmm3
   21ae8:	66 44 0f 28 a4 24 90 	movapd 0x190(%rsp),%xmm12
   21aef:	01 00 00 
   21af2:	66 45 0f 28 fc       	movapd %xmm12,%xmm15
   21af7:	66 44 0f 59 fc       	mulpd  %xmm4,%xmm15
   21afc:	66 44 0f 28 b4 24 00 	movapd 0x100(%rsp),%xmm14
   21b03:	01 00 00 
   21b06:	66 44 0f 59 f5       	mulpd  %xmm5,%xmm14
   21b0b:	66 44 0f 58 bc 24 e0 	addpd  0xe0(%rsp),%xmm15
   21b12:	00 00 00 
   21b15:	66 44 0f 58 b4 24 d0 	addpd  0xd0(%rsp),%xmm14
   21b1c:	00 00 00 
   21b1f:	66 44 0f 59 fc       	mulpd  %xmm4,%xmm15
   21b24:	66 44 0f 59 f5       	mulpd  %xmm5,%xmm14
   21b29:	66 44 0f 28 ac 24 d0 	movapd 0x1d0(%rsp),%xmm13
   21b30:	01 00 00 
   21b33:	66 45 0f 58 fd       	addpd  %xmm13,%xmm15
   21b38:	66 44 0f 58 b4 24 10 	addpd  0x110(%rsp),%xmm14
   21b3f:	01 00 00 
   21b42:	66 0f 28 25 d6 39 fe 	movapd -0x1c62a(%rip),%xmm4        # 5520 <std::thread::current::id::ID+0x48a8>
   21b49:	ff 
   21b4a:	66 44 0f 59 fc       	mulpd  %xmm4,%xmm15
   21b4f:	66 44 0f 59 f4       	mulpd  %xmm4,%xmm14
   21b54:	66 41 0f 28 e8       	movapd %xmm8,%xmm5
   21b59:	66 41 0f 59 ea       	mulpd  %xmm10,%xmm5
   21b5e:	66 44 0f 28 c1       	movapd %xmm1,%xmm8
   21b63:	66 44 0f 59 c0       	mulpd  %xmm0,%xmm8
   21b68:	66 0f 58 ea          	addpd  %xmm2,%xmm5
   21b6c:	66 44 0f 58 84 24 f0 	addpd  0xf0(%rsp),%xmm8
   21b73:	00 00 00 
   21b76:	66 41 0f 59 ea       	mulpd  %xmm10,%xmm5
   21b7b:	66 44 0f 59 c0       	mulpd  %xmm0,%xmm8
   21b80:	66 41 0f 58 eb       	addpd  %xmm11,%xmm5
   21b85:	66 44 0f 58 c6       	addpd  %xmm6,%xmm8
   21b8a:	66 45 0f 59 e2       	mulpd  %xmm10,%xmm12
   21b8f:	66 44 0f 58 a4 24 e0 	addpd  0xe0(%rsp),%xmm12
   21b96:	00 00 00 
   21b99:	66 45 0f 59 e2       	mulpd  %xmm10,%xmm12
   21b9e:	66 44 0f 28 94 24 00 	movapd 0x100(%rsp),%xmm10
   21ba5:	01 00 00 
   21ba8:	66 44 0f 59 d0       	mulpd  %xmm0,%xmm10
   21bad:	66 44 0f 58 94 24 d0 	addpd  0xd0(%rsp),%xmm10
   21bb4:	00 00 00 
   21bb7:	66 44 0f 59 d0       	mulpd  %xmm0,%xmm10
   21bbc:	66 45 0f 58 e5       	addpd  %xmm13,%xmm12
   21bc1:	66 44 0f 58 94 24 10 	addpd  0x110(%rsp),%xmm10
   21bc8:	01 00 00 
   21bcb:	66 0f 28 05 4d 39 fe 	movapd -0x1c6b3(%rip),%xmm0        # 5520 <std::thread::current::id::ID+0x48a8>
   21bd2:	ff 
   21bd3:	66 44 0f 59 e0       	mulpd  %xmm0,%xmm12
   21bd8:	66 44 0f 59 d0       	mulpd  %xmm0,%xmm10
   21bdd:	66 41 0f 28 c7       	movapd %xmm15,%xmm0
   21be2:	66 0f 28 0d a6 3b fe 	movapd -0x1c45a(%rip),%xmm1        # 5790 <std::thread::current::id::ID+0x4b18>
   21be9:	ff 
   21bea:	66 0f 57 c1          	xorpd  %xmm1,%xmm0
   21bee:	66 44 0f c2 ff 01    	cmpltpd %xmm7,%xmm15
   21bf4:	66 0f c2 f8 01       	cmpltpd %xmm0,%xmm7
   21bf9:	66 41 0f 28 c6       	movapd %xmm14,%xmm0
   21bfe:	66 0f 57 c1          	xorpd  %xmm1,%xmm0
   21c02:	66 44 0f c2 f3 01    	cmpltpd %xmm3,%xmm14
   21c08:	66 0f c2 d8 01       	cmpltpd %xmm0,%xmm3
   21c0d:	66 41 0f 28 c4       	movapd %xmm12,%xmm0
   21c12:	66 0f c2 c5 01       	cmpltpd %xmm5,%xmm0
   21c17:	66 0f 54 c7          	andpd  %xmm7,%xmm0
   21c1b:	66 41 0f 28 fa       	movapd %xmm10,%xmm7
   21c20:	66 41 0f c2 f8 01    	cmpltpd %xmm8,%xmm7
   21c26:	66 0f 54 fb          	andpd  %xmm3,%xmm7
   21c2a:	66 44 0f 57 e1       	xorpd  %xmm1,%xmm12
   21c2f:	66 41 0f c2 ec 01    	cmpltpd %xmm12,%xmm5
   21c35:	66 41 0f 54 ef       	andpd  %xmm15,%xmm5
   21c3a:	66 0f 56 e8          	orpd   %xmm0,%xmm5
   21c3e:	66 44 0f 57 d1       	xorpd  %xmm1,%xmm10
   21c43:	66 45 0f c2 c2 01    	cmpltpd %xmm10,%xmm8
   21c49:	66 0f 28 74 24 10    	movapd 0x10(%rsp),%xmm6
   21c4f:	66 45 0f 54 c6       	andpd  %xmm14,%xmm8
   21c54:	66 44 0f 56 c7       	orpd   %xmm7,%xmm8
   21c59:	66 41 0f 28 c1       	movapd %xmm9,%xmm0
   21c5e:	66 0f 28 3d ea 3a fe 	movapd -0x1c516(%rip),%xmm7        # 5750 <std::thread::current::id::ID+0x4ad8>
   21c65:	ff 
   21c66:	66 0f c2 c7 00       	cmpeqpd %xmm7,%xmm0
   21c6b:	66 0f 28 4c 24 70    	movapd 0x70(%rsp),%xmm1
   21c71:	66 0f 54 c1          	andpd  %xmm1,%xmm0
   21c75:	66 0f 54 c5          	andpd  %xmm5,%xmm0
   21c79:	66 0f 28 ac 24 c0 00 	movapd 0xc0(%rsp),%xmm5
   21c80:	00 00 
   21c82:	66 0f 28 dd          	movapd %xmm5,%xmm3
   21c86:	66 0f c2 df 00       	cmpeqpd %xmm7,%xmm3
   21c8b:	66 0f 28 14 24       	movapd (%rsp),%xmm2
   21c90:	66 0f 54 da          	andpd  %xmm2,%xmm3
   21c94:	66 41 0f 54 d8       	andpd  %xmm8,%xmm3
   21c99:	66 44 0f 28 44 24 20 	movapd 0x20(%rsp),%xmm8
   21ca0:	66 0f 28 e0          	movapd %xmm0,%xmm4
   21ca4:	66 41 0f 55 c1       	andnpd %xmm9,%xmm0
   21ca9:	66 0f 58 f6          	addpd  %xmm6,%xmm6
   21cad:	66 0f 54 e6          	andpd  %xmm6,%xmm4
   21cb1:	66 44 0f 28 c8       	movapd %xmm0,%xmm9
   21cb6:	66 44 0f 56 cc       	orpd   %xmm4,%xmm9
   21cbb:	66 0f 28 c3          	movapd %xmm3,%xmm0
   21cbf:	66 0f 55 dd          	andnpd %xmm5,%xmm3
   21cc3:	66 45 0f 58 c0       	addpd  %xmm8,%xmm8
   21cc8:	66 41 0f 54 c0       	andpd  %xmm8,%xmm0
   21ccd:	66 0f 28 eb          	movapd %xmm3,%xmm5
   21cd1:	66 0f 56 e8          	orpd   %xmm0,%xmm5
   21cd5:	66 41 0f 28 c1       	movapd %xmm9,%xmm0
   21cda:	66 0f c2 c7 00       	cmpeqpd %xmm7,%xmm0
   21cdf:	66 0f 54 c1          	andpd  %xmm1,%xmm0
   21ce3:	66 44 0f 50 c8       	movmskpd %xmm0,%r9d
   21ce8:	66 0f 28 c5          	movapd %xmm5,%xmm0
   21cec:	f2 0f c2 c7 00       	cmpeqsd %xmm7,%xmm0
   21cf1:	66 0f 54 c2          	andpd  %xmm2,%xmm0
   21cf5:	66 44 0f 50 d0       	movmskpd %xmm0,%r10d
   21cfa:	41 c1 e2 02          	shl    $0x2,%r10d
   21cfe:	41 83 e2 04          	and    $0x4,%r10d
   21d02:	83 e9 01             	sub    $0x1,%ecx
   21d05:	40 0f 92 c6          	setb   %sil
   21d09:	45 09 ca             	or     %r9d,%r10d
   21d0c:	74 09                	je     21d17 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::entry::<fearless_simd::generated::sse2::Sse2, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::sse2::Sse2>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>, usize, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::sse2::Sse2>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2]>+0x6f7>
   21d0e:	40 84 f6             	test   %sil,%sil
   21d11:	0f 84 19 fd ff ff    	je     21a30 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::entry::<fearless_simd::generated::sse2::Sse2, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::sse2::Sse2>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>, usize, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::sse2::Sse2>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2]>+0x410>
   21d17:	66 0f 28 bc 24 b0 02 	movapd 0x2b0(%rsp),%xmm7
   21d1e:	00 00 
   21d20:	66 44 0f 28 f7       	movapd %xmm7,%xmm14
   21d25:	66 0f 28 94 24 30 02 	movapd 0x230(%rsp),%xmm2
   21d2c:	00 00 
   21d2e:	66 44 0f 5d f2       	minpd  %xmm2,%xmm14
   21d33:	66 0f 28 b4 24 90 00 	movapd 0x90(%rsp),%xmm6
   21d3a:	00 00 
   21d3c:	66 0f 28 e6          	movapd %xmm6,%xmm4
   21d40:	66 0f 28 9c 24 20 02 	movapd 0x220(%rsp),%xmm3
   21d47:	00 00 
   21d49:	66 0f 5d e3          	minpd  %xmm3,%xmm4
   21d4d:	66 44 0f 54 4c 24 70 	andpd  0x70(%rsp),%xmm9
   21d54:	66 0f 54 2c 24       	andpd  (%rsp),%xmm5
   21d59:	66 0f 28 c7          	movapd %xmm7,%xmm0
   21d5d:	66 41 0f 5c c1       	subpd  %xmm9,%xmm0
   21d62:	66 0f 28 ce          	movapd %xmm6,%xmm1
   21d66:	66 0f 5c cd          	subpd  %xmm5,%xmm1
   21d6a:	66 0f c2 c2 01       	cmpltpd %xmm2,%xmm0
   21d6f:	66 0f c2 cb 01       	cmpltpd %xmm3,%xmm1
   21d74:	66 41 0f 5c fe       	subpd  %xmm14,%xmm7
   21d79:	66 0f 5c f4          	subpd  %xmm4,%xmm6
   21d7d:	66 0f 28 15 9b 34 fe 	movapd -0x1cb65(%rip),%xmm2        # 5220 <std::thread::current::id::ID+0x45a8>
   21d84:	ff 
   21d85:	66 0f 54 fa          	andpd  %xmm2,%xmm7
   21d89:	66 0f 54 f2          	andpd  %xmm2,%xmm6
   21d8d:	66 41 0f 58 f9       	addpd  %xmm9,%xmm7
   21d92:	66 0f 54 f8          	andpd  %xmm0,%xmm7
   21d96:	66 0f 58 f5          	addpd  %xmm5,%xmm6
   21d9a:	66 0f 54 f1          	andpd  %xmm1,%xmm6
   21d9e:	66 0f 28 c7          	movapd %xmm7,%xmm0
   21da2:	66 44 0f 28 15 a5 39 	movapd -0x1c65b(%rip),%xmm10        # 5750 <std::thread::current::id::ID+0x4ad8>
   21da9:	fe ff 
   21dab:	66 41 0f c2 c2 01    	cmpltpd %xmm10,%xmm0
   21db1:	66 44 0f 28 e6       	movapd %xmm6,%xmm12
   21db6:	66 45 0f c2 e2 01    	cmpltpd %xmm10,%xmm12
   21dbc:	66 0f 54 f8          	andpd  %xmm0,%xmm7
   21dc0:	66 0f 29 44 24 70    	movapd %xmm0,0x70(%rsp)
   21dc6:	66 0f 28 c8          	movapd %xmm0,%xmm1
   21dca:	66 0f 76 c0          	pcmpeqd %xmm0,%xmm0
   21dce:	66 0f 57 c8          	xorpd  %xmm0,%xmm1
   21dd2:	66 0f 29 0c 24       	movapd %xmm1,(%rsp)
   21dd7:	66 41 0f 54 f4       	andpd  %xmm12,%xmm6
   21ddc:	66 0f 29 b4 24 90 00 	movapd %xmm6,0x90(%rsp)
   21de3:	00 00 
   21de5:	66 44 0f 29 a4 24 c0 	movapd %xmm12,0xc0(%rsp)
   21dec:	00 00 00 
   21def:	66 44 0f 57 e0       	xorpd  %xmm0,%xmm12
   21df4:	66 44 0f 29 64 24 20 	movapd %xmm12,0x20(%rsp)
   21dfb:	66 0f 28 84 24 80 01 	movapd 0x180(%rsp),%xmm0
   21e02:	00 00 
   21e04:	66 41 0f 59 c6       	mulpd  %xmm14,%xmm0
   21e09:	66 44 0f 28 8c 24 c0 	movapd 0x1c0(%rsp),%xmm9
   21e10:	01 00 00 
   21e13:	66 45 0f 59 ce       	mulpd  %xmm14,%xmm9
   21e18:	66 0f 28 b4 24 b0 01 	movapd 0x1b0(%rsp),%xmm6
   21e1f:	00 00 
   21e21:	66 44 0f 28 e4       	movapd %xmm4,%xmm12
   21e26:	66 0f 59 f4          	mulpd  %xmm4,%xmm6
   21e2a:	66 44 0f 58 8c 24 a0 	addpd  0x1a0(%rsp),%xmm9
   21e31:	01 00 00 
   21e34:	66 0f 58 b4 24 f0 00 	addpd  0xf0(%rsp),%xmm6
   21e3b:	00 00 
   21e3d:	66 45 0f 59 ce       	mulpd  %xmm14,%xmm9
   21e42:	66 0f 59 f4          	mulpd  %xmm4,%xmm6
   21e46:	66 44 0f 58 8c 24 80 	addpd  0x80(%rsp),%xmm9
   21e4d:	00 00 00 
   21e50:	66 44 0f 28 94 24 b0 	movapd 0xb0(%rsp),%xmm10
   21e57:	00 00 00 
   21e5a:	66 41 0f 58 f2       	addpd  %xmm10,%xmm6
   21e5f:	66 0f 28 a4 24 90 01 	movapd 0x190(%rsp),%xmm4
   21e66:	00 00 
   21e68:	66 41 0f 59 e6       	mulpd  %xmm14,%xmm4
   21e6d:	66 0f 28 9c 24 00 01 	movapd 0x100(%rsp),%xmm3
   21e74:	00 00 
   21e76:	66 41 0f 59 dc       	mulpd  %xmm12,%xmm3
   21e7b:	66 0f 28 ac 24 e0 00 	movapd 0xe0(%rsp),%xmm5
   21e82:	00 00 
   21e84:	66 0f 58 ec          	addpd  %xmm4,%xmm5
   21e88:	66 41 0f 59 ee       	mulpd  %xmm14,%xmm5
   21e8d:	66 44 0f 28 9c 24 d0 	movapd 0x1d0(%rsp),%xmm11
   21e94:	01 00 00 
   21e97:	66 41 0f 58 eb       	addpd  %xmm11,%xmm5
   21e9c:	66 0f 28 0d 7c 36 fe 	movapd -0x1c984(%rip),%xmm1        # 5520 <std::thread::current::id::ID+0x48a8>
   21ea3:	ff 
   21ea4:	66 0f 59 e9          	mulpd  %xmm1,%xmm5
   21ea8:	66 44 0f 54 ca       	andpd  %xmm2,%xmm9
   21ead:	66 44 0f 58 cd       	addpd  %xmm5,%xmm9
   21eb2:	66 0f 28 ac 24 d0 00 	movapd 0xd0(%rsp),%xmm5
   21eb9:	00 00 
   21ebb:	66 0f 58 eb          	addpd  %xmm3,%xmm5
   21ebf:	66 41 0f 59 ec       	mulpd  %xmm12,%xmm5
   21ec4:	66 44 0f 28 bc 24 10 	movapd 0x110(%rsp),%xmm15
   21ecb:	01 00 00 
   21ece:	66 41 0f 58 ef       	addpd  %xmm15,%xmm5
   21ed3:	66 0f 59 e9          	mulpd  %xmm1,%xmm5
   21ed7:	66 0f 54 f2          	andpd  %xmm2,%xmm6
   21edb:	66 0f 58 f5          	addpd  %xmm5,%xmm6
   21edf:	66 0f 28 94 24 90 02 	movapd 0x290(%rsp),%xmm2
   21ee6:	00 00 
   21ee8:	66 0f 28 ea          	movapd %xmm2,%xmm5
   21eec:	66 44 0f 29 74 24 10 	movapd %xmm14,0x10(%rsp)
   21ef3:	66 41 0f 59 ee       	mulpd  %xmm14,%xmm5
   21ef8:	66 44 0f 28 ac 24 70 	movapd 0x270(%rsp),%xmm13
   21eff:	02 00 00 
   21f02:	66 41 0f 58 ed       	addpd  %xmm13,%xmm5
   21f07:	66 41 0f 59 ee       	mulpd  %xmm14,%xmm5
   21f0c:	66 41 0f 58 eb       	addpd  %xmm11,%xmm5
   21f11:	66 41 0f 59 ee       	mulpd  %xmm14,%xmm5
   21f16:	66 0f 58 ac 24 50 02 	addpd  0x250(%rsp),%xmm5
   21f1d:	00 00 
   21f1f:	66 0f 59 e9          	mulpd  %xmm1,%xmm5
   21f23:	66 44 0f 59 cf       	mulpd  %xmm7,%xmm9
   21f28:	66 44 0f 58 cd       	addpd  %xmm5,%xmm9
   21f2d:	66 44 0f 28 9c 24 80 	movapd 0x280(%rsp),%xmm11
   21f34:	02 00 00 
   21f37:	66 41 0f 28 eb       	movapd %xmm11,%xmm5
   21f3c:	66 41 0f 59 ec       	mulpd  %xmm12,%xmm5
   21f41:	66 44 0f 28 b4 24 60 	movapd 0x260(%rsp),%xmm14
   21f48:	02 00 00 
   21f4b:	66 41 0f 58 ee       	addpd  %xmm14,%xmm5
   21f50:	66 41 0f 59 ec       	mulpd  %xmm12,%xmm5
   21f55:	66 41 0f 58 ef       	addpd  %xmm15,%xmm5
   21f5a:	66 41 0f 59 ec       	mulpd  %xmm12,%xmm5
   21f5f:	66 0f 58 ac 24 40 02 	addpd  0x240(%rsp),%xmm5
   21f66:	00 00 
   21f68:	66 0f 59 e9          	mulpd  %xmm1,%xmm5
   21f6c:	66 0f 28 8c 24 90 00 	movapd 0x90(%rsp),%xmm1
   21f73:	00 00 
   21f75:	66 0f 59 f1          	mulpd  %xmm1,%xmm6
   21f79:	66 0f 58 f5          	addpd  %xmm5,%xmm6
   21f7d:	66 41 0f 58 e5       	addpd  %xmm13,%xmm4
   21f82:	66 41 0f 58 de       	addpd  %xmm14,%xmm3
   21f87:	66 0f 28 ea          	movapd %xmm2,%xmm5
   21f8b:	66 0f 59 ef          	mulpd  %xmm7,%xmm5
   21f8f:	66 0f 58 ec          	addpd  %xmm4,%xmm5
   21f93:	66 41 0f 28 e3       	movapd %xmm11,%xmm4
   21f98:	66 0f 59 e1          	mulpd  %xmm1,%xmm4
   21f9c:	66 0f 58 e3          	addpd  %xmm3,%xmm4
   21fa0:	66 0f 28 9c 24 70 01 	movapd 0x170(%rsp),%xmm3
   21fa7:	00 00 
   21fa9:	66 41 0f 59 dc       	mulpd  %xmm12,%xmm3
   21fae:	66 44 0f 28 9c 24 60 	movapd 0x160(%rsp),%xmm11
   21fb5:	01 00 00 
   21fb8:	66 41 0f 58 c3       	addpd  %xmm11,%xmm0
   21fbd:	66 44 0f 28 bc 24 50 	movapd 0x150(%rsp),%xmm15
   21fc4:	01 00 00 
   21fc7:	66 41 0f 58 df       	addpd  %xmm15,%xmm3
   21fcc:	66 0f 28 54 24 10    	movapd 0x10(%rsp),%xmm2
   21fd2:	66 0f 59 c2          	mulpd  %xmm2,%xmm0
   21fd6:	66 41 0f 59 dc       	mulpd  %xmm12,%xmm3
   21fdb:	66 0f 58 84 24 80 00 	addpd  0x80(%rsp),%xmm0
   21fe2:	00 00 
   21fe4:	66 41 0f 58 da       	addpd  %xmm10,%xmm3
   21fe9:	66 0f 59 c2          	mulpd  %xmm2,%xmm0
   21fed:	66 41 0f 59 dc       	mulpd  %xmm12,%xmm3
   21ff2:	66 0f 58 84 24 40 01 	addpd  0x140(%rsp),%xmm0
   21ff9:	00 00 
   21ffb:	66 0f 28 94 24 a0 02 	movapd 0x2a0(%rsp),%xmm2
   22002:	00 00 
   22004:	66 0f 58 da          	addpd  %xmm2,%xmm3
   22008:	66 0f 59 ef          	mulpd  %xmm7,%xmm5
   2200c:	66 0f 59 e1          	mulpd  %xmm1,%xmm4
   22010:	66 0f 59 ef          	mulpd  %xmm7,%xmm5
   22014:	66 41 0f 58 e9       	addpd  %xmm9,%xmm5
   22019:	66 0f 59 e1          	mulpd  %xmm1,%xmm4
   2201d:	66 0f 58 e6          	addpd  %xmm6,%xmm4
   22021:	66 44 0f 28 d0       	movapd %xmm0,%xmm10
   22026:	66 0f 28 0d f2 31 fe 	movapd -0x1ce0e(%rip),%xmm1        # 5220 <std::thread::current::id::ID+0x45a8>
   2202d:	ff 
   2202e:	66 44 0f 54 d1       	andpd  %xmm1,%xmm10
   22033:	66 44 0f 28 eb       	movapd %xmm3,%xmm13
   22038:	66 44 0f 54 e9       	andpd  %xmm1,%xmm13
   2203d:	66 44 0f c2 d5 02    	cmplepd %xmm5,%xmm10
   22043:	66 44 0f 56 14 24    	orpd   (%rsp),%xmm10
   22049:	66 44 0f c2 ec 02    	cmplepd %xmm4,%xmm13
   2204f:	66 44 0f 56 6c 24 20 	orpd   0x20(%rsp),%xmm13
   22056:	66 0f 28 4c 24 30    	movapd 0x30(%rsp),%xmm1
   2205c:	66 44 0f 28 0d eb 36 	movapd -0x1c915(%rip),%xmm9        # 5750 <std::thread::current::id::ID+0x4ad8>
   22063:	fe ff 
   22065:	66 41 0f c2 c9 00    	cmpeqpd %xmm9,%xmm1
   2206b:	66 0f 28 7c 24 40    	movapd 0x40(%rsp),%xmm7
   22071:	66 41 0f c2 f9 00    	cmpeqpd %xmm9,%xmm7
   22077:	66 0f 28 74 24 50    	movapd 0x50(%rsp),%xmm6
   2207d:	66 41 0f c2 f1 00    	cmpeqpd %xmm9,%xmm6
   22083:	66 0f 54 f1          	andpd  %xmm1,%xmm6
   22087:	66 0f 28 4c 24 60    	movapd 0x60(%rsp),%xmm1
   2208d:	66 41 0f c2 c9 00    	cmpeqpd %xmm9,%xmm1
   22093:	66 0f 54 cf          	andpd  %xmm7,%xmm1
   22097:	66 0f c2 e8 01       	cmpltpd %xmm0,%xmm5
   2209c:	66 0f c2 e3 01       	cmpltpd %xmm3,%xmm4
   220a1:	66 44 0f 29 14 24    	movapd %xmm10,(%rsp)
   220a7:	66 41 0f 28 c2       	movapd %xmm10,%xmm0
   220ac:	66 0f 55 c5          	andnpd %xmm5,%xmm0
   220b0:	66 0f 54 c6          	andpd  %xmm6,%xmm0
   220b4:	66 44 0f 29 ac 24 a0 	movapd %xmm13,0xa0(%rsp)
   220bb:	00 00 00 
   220be:	66 45 0f 28 d5       	movapd %xmm13,%xmm10
   220c3:	66 44 0f 55 d4       	andnpd %xmm4,%xmm10
   220c8:	66 44 0f 54 d1       	andpd  %xmm1,%xmm10
   220cd:	66 0f 50 c8          	movmskpd %xmm0,%ecx
   220d1:	66 41 0f 50 f2       	movmskpd %xmm10,%esi
   220d6:	c1 e6 02             	shl    $0x2,%esi
   220d9:	83 e6 04             	and    $0x4,%esi
   220dc:	09 ce                	or     %ecx,%esi
   220de:	4c 89 c1             	mov    %r8,%rcx
   220e1:	66 44 0f 29 64 24 20 	movapd %xmm12,0x20(%rsp)
   220e8:	66 41 0f 28 ec       	movapd %xmm12,%xmm5
   220ed:	66 0f 28 64 24 10    	movapd 0x10(%rsp),%xmm4
   220f3:	66 44 0f 28 a4 24 30 	movapd 0x130(%rsp),%xmm12
   220fa:	01 00 00 
   220fd:	66 44 0f 28 ac 24 20 	movapd 0x120(%rsp),%xmm13
   22104:	01 00 00 
   22107:	66 44 0f 28 0d 70 32 	movapd -0x1cd90(%rip),%xmm9        # 5380 <std::thread::current::id::ID+0x4708>
   2210e:	fe ff 
   22110:	0f 84 ea f7 ff ff    	je     21900 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::entry::<fearless_simd::generated::sse2::Sse2, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::sse2::Sse2>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>, usize, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::sse2::Sse2>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2]>+0x2e0>
   22116:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   2211d:	00 00 00 
   22120:	66 0f 28 fc          	movapd %xmm4,%xmm7
   22124:	66 41 0f 5c fd       	subpd  %xmm13,%xmm7
   22129:	66 0f 28 dd          	movapd %xmm5,%xmm3
   2212d:	66 41 0f 5c dc       	subpd  %xmm12,%xmm3
   22132:	66 41 0f 59 f9       	mulpd  %xmm9,%xmm7
   22137:	66 41 0f 59 d9       	mulpd  %xmm9,%xmm3
   2213c:	66 41 0f 58 fd       	addpd  %xmm13,%xmm7
   22141:	66 41 0f 58 dc       	addpd  %xmm12,%xmm3
   22146:	66 44 0f 28 84 24 80 	movapd 0x180(%rsp),%xmm8
   2214d:	01 00 00 
   22150:	66 44 0f 59 c7       	mulpd  %xmm7,%xmm8
   22155:	66 44 0f 28 b4 24 70 	movapd 0x170(%rsp),%xmm14
   2215c:	01 00 00 
   2215f:	66 44 0f 59 f3       	mulpd  %xmm3,%xmm14
   22164:	66 45 0f 58 c3       	addpd  %xmm11,%xmm8
   22169:	66 45 0f 58 f7       	addpd  %xmm15,%xmm14
   2216e:	66 44 0f 59 c7       	mulpd  %xmm7,%xmm8
   22173:	66 44 0f 59 f3       	mulpd  %xmm3,%xmm14
   22178:	66 44 0f 58 84 24 80 	addpd  0x80(%rsp),%xmm8
   2217f:	00 00 00 
   22182:	66 44 0f 58 b4 24 b0 	addpd  0xb0(%rsp),%xmm14
   22189:	00 00 00 
   2218c:	66 44 0f 59 c7       	mulpd  %xmm7,%xmm8
   22191:	66 44 0f 59 f3       	mulpd  %xmm3,%xmm14
   22196:	66 44 0f 58 84 24 40 	addpd  0x140(%rsp),%xmm8
   2219d:	01 00 00 
   221a0:	66 44 0f 58 f2       	addpd  %xmm2,%xmm14
   221a5:	66 45 0f 57 ff       	xorpd  %xmm15,%xmm15
   221aa:	66 45 0f c2 f8 01    	cmpltpd %xmm8,%xmm15
   221b0:	66 45 0f 57 db       	xorpd  %xmm11,%xmm11
   221b5:	66 45 0f c2 de 01    	cmpltpd %xmm14,%xmm11
   221bb:	66 44 0f 28 c0       	movapd %xmm0,%xmm8
   221c0:	66 45 0f 54 c7       	andpd  %xmm15,%xmm8
   221c5:	66 45 0f 28 f0       	movapd %xmm8,%xmm14
   221ca:	66 44 0f 55 c4       	andnpd %xmm4,%xmm8
   221cf:	66 41 0f 28 e2       	movapd %xmm10,%xmm4
   221d4:	66 41 0f 54 e3       	andpd  %xmm11,%xmm4
   221d9:	66 44 0f 54 f7       	andpd  %xmm7,%xmm14
   221de:	66 45 0f 56 c6       	orpd   %xmm14,%xmm8
   221e3:	66 44 0f 28 f4       	movapd %xmm4,%xmm14
   221e8:	66 0f 55 e5          	andnpd %xmm5,%xmm4
   221ec:	66 44 0f 54 f3       	andpd  %xmm3,%xmm14
   221f1:	66 41 0f 56 e6       	orpd   %xmm14,%xmm4
   221f6:	66 44 0f 55 f8       	andnpd %xmm0,%xmm15
   221fb:	66 41 0f 54 ff       	andpd  %xmm15,%xmm7
   22200:	66 45 0f 55 fd       	andnpd %xmm13,%xmm15
   22205:	66 45 0f 28 ef       	movapd %xmm15,%xmm13
   2220a:	66 44 0f 28 bc 24 50 	movapd 0x150(%rsp),%xmm15
   22211:	01 00 00 
   22214:	66 44 0f 56 ef       	orpd   %xmm7,%xmm13
   22219:	66 45 0f 55 da       	andnpd %xmm10,%xmm11
   2221e:	66 41 0f 54 db       	andpd  %xmm11,%xmm3
   22223:	66 45 0f 55 dc       	andnpd %xmm12,%xmm11
   22228:	66 45 0f 28 e3       	movapd %xmm11,%xmm12
   2222d:	66 44 0f 28 9c 24 60 	movapd 0x160(%rsp),%xmm11
   22234:	01 00 00 
   22237:	66 44 0f 56 e3       	orpd   %xmm3,%xmm12
   2223c:	66 0f 28 ec          	movapd %xmm4,%xmm5
   22240:	66 41 0f 28 e0       	movapd %xmm8,%xmm4
   22245:	48 ff c9             	dec    %rcx
   22248:	0f 85 d2 fe ff ff    	jne    22120 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::entry::<fearless_simd::generated::sse2::Sse2, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::sse2::Sse2>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>, usize, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::sse2::Sse2>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2]>+0xb00>
   2224e:	66 44 0f 54 e8       	andpd  %xmm0,%xmm13
   22253:	66 0f 55 44 24 30    	andnpd 0x30(%rsp),%xmm0
   22259:	66 41 0f 56 c5       	orpd   %xmm13,%xmm0
   2225e:	66 45 0f 54 e2       	andpd  %xmm10,%xmm12
   22263:	66 44 0f 55 54 24 40 	andnpd 0x40(%rsp),%xmm10
   2226a:	66 45 0f 56 d4       	orpd   %xmm12,%xmm10
   2226f:	66 44 0f 29 54 24 40 	movapd %xmm10,0x40(%rsp)
   22276:	66 0f 29 44 24 30    	movapd %xmm0,0x30(%rsp)
   2227c:	e9 7f f6 ff ff       	jmp    21900 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::entry::<fearless_simd::generated::sse2::Sse2, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::sse2::Sse2>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>, usize, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::sse2::Sse2>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2]>+0x2e0>
   22281:	0f 28 44 24 30       	movaps 0x30(%rsp),%xmm0
   22286:	0f 29 07             	movaps %xmm0,(%rdi)
   22289:	0f 28 44 24 40       	movaps 0x40(%rsp),%xmm0
   2228e:	0f 29 47 10          	movaps %xmm0,0x10(%rdi)
   22292:	0f 28 44 24 50       	movaps 0x50(%rsp),%xmm0
   22297:	0f 29 47 20          	movaps %xmm0,0x20(%rdi)
   2229b:	0f 28 44 24 60       	movaps 0x60(%rsp),%xmm0
   222a0:	0f 29 47 30          	movaps %xmm0,0x30(%rdi)
   222a4:	48 89 ec             	mov    %rbp,%rsp
   222a7:	5d                   	pop    %rbp
   222a8:	c3                   	ret
   222a9:	cc                   	int3
   222aa:	cc                   	int3
   222ab:	cc                   	int3
   222ac:	cc                   	int3
   222ad:	cc                   	int3
   222ae:	cc                   	int3
   222af:	cc                   	int3

gpui_canvas::color::gamut::in_gamut:
   222b0:	55                   	push   %rbp
   222b1:	53                   	push   %rbx
   222b2:	48 83 ec 68          	sub    $0x68,%rsp
   222b6:	89 f3                	mov    %esi,%ebx
   222b8:	f3 0f 7e 0f          	movq   (%rdi),%xmm1
   222bc:	8b 4f 08             	mov    0x8(%rdi),%ecx
   222bf:	8b 57 0c             	mov    0xc(%rdi),%edx
   222c2:	89 c8                	mov    %ecx,%eax
   222c4:	81 fa 00 00 00 c0    	cmp    $0xc0000000,%edx
   222ca:	0f 82 ea 00 00 00    	jb     223ba <gpui_canvas::color::gamut::in_gamut+0x10a>
   222d0:	89 c8                	mov    %ecx,%eax
   222d2:	85 c9                	test   %ecx,%ecx
   222d4:	0f 88 db 00 00 00    	js     223b5 <gpui_canvas::color::gamut::in_gamut+0x105>
   222da:	c1 e8 08             	shr    $0x8,%eax
   222dd:	89 ce                	mov    %ecx,%esi
   222df:	48 69 f6 8f e7 54 52 	imul   $0x5254e78f,%rsi,%rsi
   222e6:	48 c1 ee 2e          	shr    $0x2e,%rsi
   222ea:	48 69 f8 09 a8 a7 01 	imul   $0x1a7a809,%rax,%rdi
   222f1:	48 c1 ef 20          	shr    $0x20,%rdi
   222f5:	66 41 0f 7e c9       	movd   %xmm1,%r9d
   222fa:	45 89 ca             	mov    %r9d,%r10d
   222fd:	41 c1 e2 08          	shl    $0x8,%r10d
   22301:	66 0f 70 c1 55       	pshufd $0x55,%xmm1,%xmm0
   22306:	66 41 0f 7e c0       	movd   %xmm0,%r8d
   2230b:	45 89 c3             	mov    %r8d,%r11d
   2230e:	45 0f a4 cb 08       	shld   $0x8,%r9d,%r11d
   22313:	69 ee 55 52 00 00    	imul   $0x5255,%esi,%ebp
   22319:	c1 ed 16             	shr    $0x16,%ebp
   2231c:	69 ed c7 00 00 00    	imul   $0xc7,%ebp,%ebp
   22322:	29 ee                	sub    %ebp,%esi
   22324:	44 89 dd             	mov    %r11d,%ebp
   22327:	c1 e5 08             	shl    $0x8,%ebp
   2232a:	41 81 e3 ff ff 7f 00 	and    $0x7fffff,%r11d
   22331:	41 81 e2 00 00 00 80 	and    $0x80000000,%r10d
   22338:	81 e5 00 00 00 80    	and    $0x80000000,%ebp
   2233e:	44 09 dd             	or     %r11d,%ebp
   22341:	41 81 e1 ff ff 7f 00 	and    $0x7fffff,%r9d
   22348:	45 09 d1             	or     %r10d,%r9d
   2234b:	c1 e6 17             	shl    $0x17,%esi
   2234e:	09 ee                	or     %ebp,%esi
   22350:	c1 e7 0f             	shl    $0xf,%edi
   22353:	81 e7 00 00 80 ff    	and    $0xff800000,%edi
   22359:	41 0f ac c8 10       	shrd   $0x10,%ecx,%r8d
   2235e:	44 09 cf             	or     %r9d,%edi
   22361:	4c 69 c8 9f 53 49 01 	imul   $0x149539f,%rax,%r9
   22368:	49 c1 e9 20          	shr    $0x20,%r9
   2236c:	45 69 c9 c7 00 00 00 	imul   $0xc7,%r9d,%r9d
   22373:	44 29 c8             	sub    %r9d,%eax
   22376:	45 89 c1             	mov    %r8d,%r9d
   22379:	41 81 e1 ff ff 7f 00 	and    $0x7fffff,%r9d
   22380:	41 c1 e0 08          	shl    $0x8,%r8d
   22384:	41 81 e0 00 00 00 80 	and    $0x80000000,%r8d
   2238b:	45 09 c8             	or     %r9d,%r8d
   2238e:	c1 e0 17             	shl    $0x17,%eax
   22391:	44 09 c0             	or     %r8d,%eax
   22394:	66 0f 6e c6          	movd   %esi,%xmm0
   22398:	66 0f 6e cf          	movd   %edi,%xmm1
   2239c:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
   223a0:	c1 ea 1e             	shr    $0x1e,%edx
   223a3:	31 ed                	xor    %ebp,%ebp
   223a5:	48 8d 35 18 52 fe ff 	lea    -0x1ade8(%rip),%rsi        # 75c4 <std::thread::current::id::ID+0x694c>
   223ac:	48 63 14 96          	movslq (%rsi,%rdx,4),%rdx
   223b0:	48 01 f2             	add    %rsi,%rdx
   223b3:	ff e2                	jmp    *%rdx
   223b5:	25 ff ff ff 7f       	and    $0x7fffffff,%eax
   223ba:	c1 ea 1e             	shr    $0x1e,%edx
   223bd:	31 ed                	xor    %ebp,%ebp
   223bf:	48 8d 35 fe 51 fe ff 	lea    -0x1ae02(%rip),%rsi        # 75c4 <std::thread::current::id::ID+0x694c>
   223c6:	48 63 14 96          	movslq (%rsi,%rdx,4),%rdx
   223ca:	48 01 f2             	add    %rsi,%rdx
   223cd:	ff e2                	jmp    *%rdx
   223cf:	40 b5 01             	mov    $0x1,%bpl
   223d2:	f3 0f 5a e9          	cvtss2sd %xmm1,%xmm5
   223d6:	66 0f 70 f1 55       	pshufd $0x55,%xmm1,%xmm6
   223db:	f3 0f 5a e6          	cvtss2sd %xmm6,%xmm4
   223df:	66 0f 6e d0          	movd   %eax,%xmm2
   223e3:	0f 28 05 36 2e fe ff 	movaps -0x1d1ca(%rip),%xmm0        # 5220 <std::thread::current::id::ID+0x45a8>
   223ea:	0f 54 c5             	andps  %xmm5,%xmm0
   223ed:	f2 0f 10 1d 13 4e fe 	movsd  -0x1b1ed(%rip),%xmm3        # 7208 <std::thread::current::id::ID+0x6590>
   223f4:	ff 
   223f5:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   223f9:	66 0f 7e 54 24 30    	movd   %xmm2,0x30(%rsp)
   223ff:	73 53                	jae    22454 <gpui_canvas::color::gamut::in_gamut+0x1a4>
   22401:	0f 2e c9             	ucomiss %xmm1,%xmm1
   22404:	0f 29 64 24 10       	movaps %xmm4,0x10(%rsp)
   22409:	0f 29 74 24 50       	movaps %xmm6,0x50(%rsp)
   2240e:	7a 4e                	jp     2245e <gpui_canvas::color::gamut::in_gamut+0x1ae>
   22410:	0f 54 2d 79 33 fe ff 	andps  -0x1cc87(%rip),%xmm5        # 5790 <std::thread::current::id::ID+0x4b18>
   22417:	0f 56 2d 82 32 fe ff 	orps   -0x1cd7e(%rip),%xmm5        # 56a0 <std::thread::current::id::ID+0x4a28>
   2241e:	0f 29 2c 24          	movaps %xmm5,(%rsp)
   22422:	eb 46                	jmp    2246a <gpui_canvas::color::gamut::in_gamut+0x1ba>
   22424:	0f 5a e9             	cvtps2pd %xmm1,%xmm5
   22427:	66 0f 6e c0          	movd   %eax,%xmm0
   2242b:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   2242f:	e9 ad 01 00 00       	jmp    225e1 <gpui_canvas::color::gamut::in_gamut+0x331>
   22434:	85 c9                	test   %ecx,%ecx
   22436:	0f 88 86 02 00 00    	js     226c2 <gpui_canvas::color::gamut::in_gamut+0x412>
   2243c:	0f 5a e9             	cvtps2pd %xmm1,%xmm5
   2243f:	66 0f 6e c0          	movd   %eax,%xmm0
   22443:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   22447:	84 db                	test   %bl,%bl
   22449:	0f 84 5e 02 00 00    	je     226ad <gpui_canvas::color::gamut::in_gamut+0x3fd>
   2244f:	e9 a7 02 00 00       	jmp    226fb <gpui_canvas::color::gamut::in_gamut+0x44b>
   22454:	f2 0f 5e 2d 14 4d fe 	divsd  -0x1b2ec(%rip),%xmm5        # 7170 <std::thread::current::id::ID+0x64f8>
   2245b:	ff 
   2245c:	eb 4b                	jmp    224a9 <gpui_canvas::color::gamut::in_gamut+0x1f9>
   2245e:	f2 0f 10 0d 62 4e fe 	movsd  -0x1b19e(%rip),%xmm1        # 72c8 <std::thread::current::id::ID+0x6650>
   22465:	ff 
   22466:	0f 29 0c 24          	movaps %xmm1,(%rsp)
   2246a:	f2 0f 58 05 1e 4f fe 	addsd  -0x1b0e2(%rip),%xmm0        # 7390 <std::thread::current::id::ID+0x6718>
   22471:	ff 
   22472:	f2 0f 5e 05 6e 4e fe 	divsd  -0x1b192(%rip),%xmm0        # 72e8 <std::thread::current::id::ID+0x6670>
   22479:	ff 
   2247a:	f2 0f 10 0d fe 4d fe 	movsd  -0x1b202(%rip),%xmm1        # 7280 <std::thread::current::id::ID+0x6608>
   22481:	ff 
   22482:	ff 15 e0 2d 04 00    	call   *0x42de0(%rip)        # 65268 <pow@GLIBC_2.29>
   22488:	66 0f 28 e8          	movapd %xmm0,%xmm5
   2248c:	f2 0f 59 2c 24       	mulsd  (%rsp),%xmm5
   22491:	66 0f 6e 54 24 30    	movd   0x30(%rsp),%xmm2
   22497:	f2 0f 10 1d 69 4d fe 	movsd  -0x1b297(%rip),%xmm3        # 7208 <std::thread::current::id::ID+0x6590>
   2249e:	ff 
   2249f:	0f 28 64 24 10       	movaps 0x10(%rsp),%xmm4
   224a4:	0f 28 74 24 50       	movaps 0x50(%rsp),%xmm6
   224a9:	0f 57 c9             	xorps  %xmm1,%xmm1
   224ac:	f3 0f 5a ca          	cvtss2sd %xmm2,%xmm1
   224b0:	0f 28 05 69 2d fe ff 	movaps -0x1d297(%rip),%xmm0        # 5220 <std::thread::current::id::ID+0x45a8>
   224b7:	0f 54 c4             	andps  %xmm4,%xmm0
   224ba:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   224be:	66 0f 29 2c 24       	movapd %xmm5,(%rsp)
   224c3:	73 1f                	jae    224e4 <gpui_canvas::color::gamut::in_gamut+0x234>
   224c5:	0f 2e f6             	ucomiss %xmm6,%xmm6
   224c8:	0f 29 4c 24 20       	movaps %xmm1,0x20(%rsp)
   224cd:	7a 4b                	jp     2251a <gpui_canvas::color::gamut::in_gamut+0x26a>
   224cf:	0f 54 25 ba 32 fe ff 	andps  -0x1cd46(%rip),%xmm4        # 5790 <std::thread::current::id::ID+0x4b18>
   224d6:	0f 56 25 c3 31 fe ff 	orps   -0x1ce3d(%rip),%xmm4        # 56a0 <std::thread::current::id::ID+0x4a28>
   224dd:	0f 29 64 24 10       	movaps %xmm4,0x10(%rsp)
   224e2:	eb 43                	jmp    22527 <gpui_canvas::color::gamut::in_gamut+0x277>
   224e4:	f2 0f 5e 25 84 4c fe 	divsd  -0x1b37c(%rip),%xmm4        # 7170 <std::thread::current::id::ID+0x64f8>
   224eb:	ff 
   224ec:	0f 28 05 2d 2d fe ff 	movaps -0x1d2d3(%rip),%xmm0        # 5220 <std::thread::current::id::ID+0x45a8>
   224f3:	0f 54 c1             	andps  %xmm1,%xmm0
   224f6:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   224fa:	72 7e                	jb     2257a <gpui_canvas::color::gamut::in_gamut+0x2ca>
   224fc:	f2 0f 5e 0d 6c 4c fe 	divsd  -0x1b394(%rip),%xmm1        # 7170 <std::thread::current::id::ID+0x64f8>
   22503:	ff 
   22504:	66 0f 28 c1          	movapd %xmm1,%xmm0
   22508:	66 0f 14 ec          	unpcklpd %xmm4,%xmm5
   2250c:	40 84 ed             	test   %bpl,%bpl
   2250f:	0f 85 cc 00 00 00    	jne    225e1 <gpui_canvas::color::gamut::in_gamut+0x331>
   22515:	e9 8f 01 00 00       	jmp    226a9 <gpui_canvas::color::gamut::in_gamut+0x3f9>
   2251a:	f2 0f 10 0d a6 4d fe 	movsd  -0x1b25a(%rip),%xmm1        # 72c8 <std::thread::current::id::ID+0x6650>
   22521:	ff 
   22522:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
   22527:	f2 0f 58 05 61 4e fe 	addsd  -0x1b19f(%rip),%xmm0        # 7390 <std::thread::current::id::ID+0x6718>
   2252e:	ff 
   2252f:	f2 0f 5e 05 b1 4d fe 	divsd  -0x1b24f(%rip),%xmm0        # 72e8 <std::thread::current::id::ID+0x6670>
   22536:	ff 
   22537:	f2 0f 10 0d 41 4d fe 	movsd  -0x1b2bf(%rip),%xmm1        # 7280 <std::thread::current::id::ID+0x6608>
   2253e:	ff 
   2253f:	ff 15 23 2d 04 00    	call   *0x42d23(%rip)        # 65268 <pow@GLIBC_2.29>
   22545:	66 0f 28 e0          	movapd %xmm0,%xmm4
   22549:	f2 0f 59 64 24 10    	mulsd  0x10(%rsp),%xmm4
   2254f:	66 0f 28 2c 24       	movapd (%rsp),%xmm5
   22554:	f3 0f 10 54 24 30    	movss  0x30(%rsp),%xmm2
   2255a:	f2 0f 10 1d a6 4c fe 	movsd  -0x1b35a(%rip),%xmm3        # 7208 <std::thread::current::id::ID+0x6590>
   22561:	ff 
   22562:	66 0f 28 4c 24 20    	movapd 0x20(%rsp),%xmm1
   22568:	66 0f 28 05 b0 2c fe 	movapd -0x1d350(%rip),%xmm0        # 5220 <std::thread::current::id::ID+0x45a8>
   2256f:	ff 
   22570:	66 0f 54 c1          	andpd  %xmm1,%xmm0
   22574:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   22578:	73 82                	jae    224fc <gpui_canvas::color::gamut::in_gamut+0x24c>
   2257a:	0f 2e d2             	ucomiss %xmm2,%xmm2
   2257d:	66 0f 29 64 24 10    	movapd %xmm4,0x10(%rsp)
   22583:	7a 12                	jp     22597 <gpui_canvas::color::gamut::in_gamut+0x2e7>
   22585:	66 0f 54 0d 03 32 fe 	andpd  -0x1cdfd(%rip),%xmm1        # 5790 <std::thread::current::id::ID+0x4b18>
   2258c:	ff 
   2258d:	66 0f 56 0d 0b 31 fe 	orpd   -0x1cef5(%rip),%xmm1        # 56a0 <std::thread::current::id::ID+0x4a28>
   22594:	ff 
   22595:	eb 08                	jmp    2259f <gpui_canvas::color::gamut::in_gamut+0x2ef>
   22597:	f2 0f 10 0d 29 4d fe 	movsd  -0x1b2d7(%rip),%xmm1        # 72c8 <std::thread::current::id::ID+0x6650>
   2259e:	ff 
   2259f:	66 0f 29 4c 24 20    	movapd %xmm1,0x20(%rsp)
   225a5:	f2 0f 58 05 e3 4d fe 	addsd  -0x1b21d(%rip),%xmm0        # 7390 <std::thread::current::id::ID+0x6718>
   225ac:	ff 
   225ad:	f2 0f 5e 05 33 4d fe 	divsd  -0x1b2cd(%rip),%xmm0        # 72e8 <std::thread::current::id::ID+0x6670>
   225b4:	ff 
   225b5:	f2 0f 10 0d c3 4c fe 	movsd  -0x1b33d(%rip),%xmm1        # 7280 <std::thread::current::id::ID+0x6608>
   225bc:	ff 
   225bd:	ff 15 a5 2c 04 00    	call   *0x42ca5(%rip)        # 65268 <pow@GLIBC_2.29>
   225c3:	f2 0f 59 44 24 20    	mulsd  0x20(%rsp),%xmm0
   225c9:	66 0f 28 2c 24       	movapd (%rsp),%xmm5
   225ce:	66 0f 28 64 24 10    	movapd 0x10(%rsp),%xmm4
   225d4:	66 0f 14 ec          	unpcklpd %xmm4,%xmm5
   225d8:	40 84 ed             	test   %bpl,%bpl
   225db:	0f 84 c8 00 00 00    	je     226a9 <gpui_canvas::color::gamut::in_gamut+0x3f9>
   225e1:	66 0f 28 d5          	movapd %xmm5,%xmm2
   225e5:	66 0f c6 d5 01       	shufpd $0x1,%xmm5,%xmm2
   225ea:	66 0f 59 15 ce 30 fe 	mulpd  -0x1cf32(%rip),%xmm2        # 56c0 <std::thread::current::id::ID+0x4a48>
   225f1:	ff 
   225f2:	66 0f 57 db          	xorpd  %xmm3,%xmm3
   225f6:	66 0f 16 1d 6a 4d fe 	movhpd -0x1b296(%rip),%xmm3        # 7368 <std::thread::current::id::ID+0x66f0>
   225fd:	ff 
   225fe:	66 0f 59 dd          	mulpd  %xmm5,%xmm3
   22602:	0f 28 c8             	movaps %xmm0,%xmm1
   22605:	0f 16 c8             	movlhps %xmm0,%xmm1
   22608:	66 0f 59 0d 30 2c fe 	mulpd  -0x1d3d0(%rip),%xmm1        # 5240 <std::thread::current::id::ID+0x45c8>
   2260f:	ff 
   22610:	66 0f 58 da          	addpd  %xmm2,%xmm3
   22614:	66 0f 58 cb          	addpd  %xmm3,%xmm1
   22618:	f2 0f 10 15 a8 4b fe 	movsd  -0x1b458(%rip),%xmm2        # 71c8 <std::thread::current::id::ID+0x6550>
   2261f:	ff 
   22620:	f2 0f 59 d5          	mulsd  %xmm5,%xmm2
   22624:	f2 0f 10 e8          	movsd  %xmm0,%xmm5
   22628:	66 0f 59 2d 30 2c fe 	mulpd  -0x1d3d0(%rip),%xmm5        # 5260 <std::thread::current::id::ID+0x45e8>
   2262f:	ff 
   22630:	66 0f 28 c5          	movapd %xmm5,%xmm0
   22634:	66 0f 15 c5          	unpckhpd %xmm5,%xmm0
   22638:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   2263c:	f2 0f 58 c5          	addsd  %xmm5,%xmm0
   22640:	f2 0f 10 15 40 4b fe 	movsd  -0x1b4c0(%rip),%xmm2        # 7188 <std::thread::current::id::ID+0x6510>
   22647:	ff 
   22648:	66 0f 28 d9          	movapd %xmm1,%xmm3
   2264c:	f2 0f 10 d8          	movsd  %xmm0,%xmm3
   22650:	66 0f 59 1d 08 2f fe 	mulpd  -0x1d0f8(%rip),%xmm3        # 5560 <std::thread::current::id::ID+0x48e8>
   22657:	ff 
   22658:	66 0f 28 e1          	movapd %xmm1,%xmm4
   2265c:	66 0f c6 e0 01       	shufpd $0x1,%xmm0,%xmm4
   22661:	66 0f 59 25 27 2e fe 	mulpd  -0x1d1d9(%rip),%xmm4        # 5490 <std::thread::current::id::ID+0x4818>
   22668:	ff 
   22669:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
   2266d:	66 0f 58 e3          	addpd  %xmm3,%xmm4
   22671:	66 0f 28 e9          	movapd %xmm1,%xmm5
   22675:	66 0f 14 e9          	unpcklpd %xmm1,%xmm5
   22679:	66 0f 59 2d 1f 31 fe 	mulpd  -0x1cee1(%rip),%xmm5        # 57a0 <std::thread::current::id::ID+0x4b28>
   22680:	ff 
   22681:	66 0f 28 c4          	movapd %xmm4,%xmm0
   22685:	66 0f 5c c5          	subpd  %xmm5,%xmm0
   22689:	66 0f 58 ec          	addpd  %xmm4,%xmm5
   2268d:	f2 0f 10 e8          	movsd  %xmm0,%xmm5
   22691:	66 0f 59 0d a7 2e fe 	mulpd  -0x1d159(%rip),%xmm1        # 5540 <std::thread::current::id::ID+0x48c8>
   22698:	ff 
   22699:	66 0f 28 c1          	movapd %xmm1,%xmm0
   2269d:	66 0f 15 c1          	unpckhpd %xmm1,%xmm0
   226a1:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   226a5:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
   226a9:	84 db                	test   %bl,%bl
   226ab:	75 4e                	jne    226fb <gpui_canvas::color::gamut::in_gamut+0x44b>
   226ad:	31 c0                	xor    %eax,%eax
   226af:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   226b3:	66 0f 2e e9          	ucomisd %xmm1,%xmm5
   226b7:	0f 83 08 01 00 00    	jae    227c5 <gpui_canvas::color::gamut::in_gamut+0x515>
   226bd:	e9 41 01 00 00       	jmp    22803 <gpui_canvas::color::gamut::in_gamut+0x553>
   226c2:	66 0f 6f d1          	movdqa %xmm1,%xmm2
   226c6:	0f c6 c9 55          	shufps $0x55,%xmm1,%xmm1
   226ca:	66 0f ef c0          	pxor   %xmm0,%xmm0
   226ce:	0f 2e c8             	ucomiss %xmm0,%xmm1
   226d1:	0f 85 35 01 00 00    	jne    2280c <gpui_canvas::color::gamut::in_gamut+0x55c>
   226d7:	0f 8a 2f 01 00 00    	jp     2280c <gpui_canvas::color::gamut::in_gamut+0x55c>
   226dd:	0f 57 c9             	xorps  %xmm1,%xmm1
   226e0:	f3 0f 5a ca          	cvtss2sd %xmm2,%xmm1
   226e4:	0f 28 c1             	movaps %xmm1,%xmm0
   226e7:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   226eb:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   226ef:	66 0f 28 e8          	movapd %xmm0,%xmm5
   226f3:	66 0f 14 e8          	unpcklpd %xmm0,%xmm5
   226f7:	84 db                	test   %bl,%bl
   226f9:	74 b2                	je     226ad <gpui_canvas::color::gamut::in_gamut+0x3fd>
   226fb:	66 0f 28 0d dd 2b fe 	movapd -0x1d423(%rip),%xmm1        # 52e0 <std::thread::current::id::ID+0x4668>
   22702:	ff 
   22703:	66 0f 59 cd          	mulpd  %xmm5,%xmm1
   22707:	66 0f 28 d5          	movapd %xmm5,%xmm2
   2270b:	66 0f c6 d5 01       	shufpd $0x1,%xmm5,%xmm2
   22710:	66 0f 59 15 08 30 fe 	mulpd  -0x1cff8(%rip),%xmm2        # 5720 <std::thread::current::id::ID+0x4aa8>
   22717:	ff 
   22718:	66 0f 58 d1          	addpd  %xmm1,%xmm2
   2271c:	66 0f 28 c8          	movapd %xmm0,%xmm1
   22720:	66 0f 14 c8          	unpcklpd %xmm0,%xmm1
   22724:	66 0f 59 0d 64 2c fe 	mulpd  -0x1d39c(%rip),%xmm1        # 5390 <std::thread::current::id::ID+0x4718>
   2272b:	ff 
   2272c:	f2 0f 10 1d e4 4a fe 	movsd  -0x1b51c(%rip),%xmm3        # 7218 <std::thread::current::id::ID+0x65a0>
   22733:	ff 
   22734:	f2 0f 59 dd          	mulsd  %xmm5,%xmm3
   22738:	f2 0f 10 e8          	movsd  %xmm0,%xmm5
   2273c:	66 0f 59 2d 5c 2c fe 	mulpd  -0x1d3a4(%rip),%xmm5        # 53a0 <std::thread::current::id::ID+0x4728>
   22743:	ff 
   22744:	66 0f 58 ca          	addpd  %xmm2,%xmm1
   22748:	66 0f 28 c5          	movapd %xmm5,%xmm0
   2274c:	66 0f 15 c5          	unpckhpd %xmm5,%xmm0
   22750:	f2 0f 58 c3          	addsd  %xmm3,%xmm0
   22754:	66 0f 28 d1          	movapd %xmm1,%xmm2
   22758:	66 0f c6 d1 01       	shufpd $0x1,%xmm1,%xmm2
   2275d:	66 0f 59 15 eb 2a fe 	mulpd  -0x1d515(%rip),%xmm2        # 5250 <std::thread::current::id::ID+0x45d8>
   22764:	ff 
   22765:	f2 0f 58 c5          	addsd  %xmm5,%xmm0
   22769:	66 0f 28 1d 4f 2b fe 	movapd -0x1d4b1(%rip),%xmm3        # 52c0 <std::thread::current::id::ID+0x4648>
   22770:	ff 
   22771:	66 0f 59 d9          	mulpd  %xmm1,%xmm3
   22775:	66 0f 5c da          	subpd  %xmm2,%xmm3
   22779:	66 0f 28 e8          	movapd %xmm0,%xmm5
   2277d:	66 0f 14 e8          	unpcklpd %xmm0,%xmm5
   22781:	66 0f 59 2d e7 2b fe 	mulpd  -0x1d419(%rip),%xmm5        # 5370 <std::thread::current::id::ID+0x46f8>
   22788:	ff 
   22789:	66 0f 28 d3          	movapd %xmm3,%xmm2
   2278d:	66 0f 5c d5          	subpd  %xmm5,%xmm2
   22791:	66 0f 58 eb          	addpd  %xmm3,%xmm5
   22795:	f2 0f 10 ea          	movsd  %xmm2,%xmm5
   22799:	66 0f 59 0d 5f 2e fe 	mulpd  -0x1d1a1(%rip),%xmm1        # 5600 <std::thread::current::id::ID+0x4988>
   227a0:	ff 
   227a1:	66 0f 28 d1          	movapd %xmm1,%xmm2
   227a5:	66 0f 15 d1          	unpckhpd %xmm1,%xmm2
   227a9:	f2 0f 5c ca          	subsd  %xmm2,%xmm1
   227ad:	f2 0f 59 05 0b 4b fe 	mulsd  -0x1b4f5(%rip),%xmm0        # 72c0 <std::thread::current::id::ID+0x6648>
   227b4:	ff 
   227b5:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
   227b9:	31 c0                	xor    %eax,%eax
   227bb:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   227bf:	66 0f 2e e9          	ucomisd %xmm1,%xmm5
   227c3:	72 3e                	jb     22803 <gpui_canvas::color::gamut::in_gamut+0x553>
   227c5:	f2 0f 10 0d 63 4a fe 	movsd  -0x1b59d(%rip),%xmm1        # 7230 <std::thread::current::id::ID+0x65b8>
   227cc:	ff 
   227cd:	66 0f 2e cd          	ucomisd %xmm5,%xmm1
   227d1:	72 30                	jb     22803 <gpui_canvas::color::gamut::in_gamut+0x553>
   227d3:	66 0f 15 ed          	unpckhpd %xmm5,%xmm5
   227d7:	31 c0                	xor    %eax,%eax
   227d9:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   227dd:	66 0f 2e ea          	ucomisd %xmm2,%xmm5
   227e1:	72 20                	jb     22803 <gpui_canvas::color::gamut::in_gamut+0x553>
   227e3:	66 0f 2e cd          	ucomisd %xmm5,%xmm1
   227e7:	72 1a                	jb     22803 <gpui_canvas::color::gamut::in_gamut+0x553>
   227e9:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   227ed:	f2 0f c2 c8 02       	cmplesd %xmm0,%xmm1
   227f2:	f2 0f c2 05 35 4a fe 	cmplesd -0x1b5cb(%rip),%xmm0        # 7230 <std::thread::current::id::ID+0x65b8>
   227f9:	ff 02 
   227fb:	66 0f 54 c1          	andpd  %xmm1,%xmm0
   227ff:	66 0f 7e c0          	movd   %xmm0,%eax
   22803:	24 01                	and    $0x1,%al
   22805:	48 83 c4 68          	add    $0x68,%rsp
   22809:	5b                   	pop    %rbx
   2280a:	5d                   	pop    %rbp
   2280b:	c3                   	ret
   2280c:	66 0f 6e c0          	movd   %eax,%xmm0
   22810:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   22814:	f2 0f 59 05 44 4b fe 	mulsd  -0x1b4bc(%rip),%xmm0        # 7360 <std::thread::current::id::ID+0x66e8>
   2281b:	ff 
   2281c:	48 8d 7c 24 48       	lea    0x48(%rsp),%rdi
   22821:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
   22826:	0f 29 0c 24          	movaps %xmm1,(%rsp)
   2282a:	66 0f 7f 54 24 30    	movdqa %xmm2,0x30(%rsp)
   22830:	ff 15 5a 2a 04 00    	call   *0x42a5a(%rip)        # 65290 <sincos@GLIBC_2.2.5>
   22836:	0f 28 44 24 30       	movaps 0x30(%rsp),%xmm0
   2283b:	0f 57 c9             	xorps  %xmm1,%xmm1
   2283e:	f3 0f 5a c8          	cvtss2sd %xmm0,%xmm1
   22842:	0f 28 04 24          	movaps (%rsp),%xmm0
   22846:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   2284a:	f2 0f 10 54 24 40    	movsd  0x40(%rsp),%xmm2
   22850:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
   22854:	f2 0f 59 44 24 48    	mulsd  0x48(%rsp),%xmm0
   2285a:	f2 0f 10 1d d6 4a fe 	movsd  -0x1b52a(%rip),%xmm3        # 7338 <std::thread::current::id::ID+0x66c0>
   22861:	ff 
   22862:	f2 0f 59 da          	mulsd  %xmm2,%xmm3
   22866:	f2 0f 58 d9          	addsd  %xmm1,%xmm3
   2286a:	f2 0f 10 2d 5e 4a fe 	movsd  -0x1b5a2(%rip),%xmm5        # 72d0 <std::thread::current::id::ID+0x6658>
   22871:	ff 
   22872:	f2 0f 59 e8          	mulsd  %xmm0,%xmm5
   22876:	f2 0f 58 eb          	addsd  %xmm3,%xmm5
   2287a:	f2 0f 10 1d 0e 4a fe 	movsd  -0x1b5f2(%rip),%xmm3        # 7290 <std::thread::current::id::ID+0x6618>
   22881:	ff 
   22882:	f2 0f 59 da          	mulsd  %xmm2,%xmm3
   22886:	f2 0f 58 d9          	addsd  %xmm1,%xmm3
   2288a:	f2 0f 10 35 06 4b fe 	movsd  -0x1b4fa(%rip),%xmm6        # 7398 <std::thread::current::id::ID+0x6720>
   22891:	ff 
   22892:	f2 0f 59 f0          	mulsd  %xmm0,%xmm6
   22896:	f2 0f 58 f3          	addsd  %xmm3,%xmm6
   2289a:	f2 0f 59 15 7e 4a fe 	mulsd  -0x1b582(%rip),%xmm2        # 7320 <std::thread::current::id::ID+0x66a8>
   228a1:	ff 
   228a2:	f2 0f 58 d1          	addsd  %xmm1,%xmm2
   228a6:	f2 0f 59 05 ca 48 fe 	mulsd  -0x1b736(%rip),%xmm0        # 7178 <std::thread::current::id::ID+0x6500>
   228ad:	ff 
   228ae:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   228b2:	66 0f 28 e5          	movapd %xmm5,%xmm4
   228b6:	f2 0f 59 e5          	mulsd  %xmm5,%xmm4
   228ba:	f2 0f 59 e5          	mulsd  %xmm5,%xmm4
   228be:	66 0f 28 de          	movapd %xmm6,%xmm3
   228c2:	f2 0f 59 de          	mulsd  %xmm6,%xmm3
   228c6:	f2 0f 59 de          	mulsd  %xmm6,%xmm3
   228ca:	66 0f 28 c8          	movapd %xmm0,%xmm1
   228ce:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   228d2:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   228d6:	f2 0f 10 05 c2 4a fe 	movsd  -0x1b53e(%rip),%xmm0        # 73a0 <std::thread::current::id::ID+0x6728>
   228dd:	ff 
   228de:	f2 0f 59 c4          	mulsd  %xmm4,%xmm0
   228e2:	f2 0f 10 15 5e 49 fe 	movsd  -0x1b6a2(%rip),%xmm2        # 7248 <std::thread::current::id::ID+0x65d0>
   228e9:	ff 
   228ea:	f2 0f 59 d3          	mulsd  %xmm3,%xmm2
   228ee:	f2 0f 58 d0          	addsd  %xmm0,%xmm2
   228f2:	f2 0f 10 05 56 49 fe 	movsd  -0x1b6aa(%rip),%xmm0        # 7250 <std::thread::current::id::ID+0x65d8>
   228f9:	ff 
   228fa:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   228fe:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   22902:	f2 0f 10 15 7e 48 fe 	movsd  -0x1b782(%rip),%xmm2        # 7188 <std::thread::current::id::ID+0x6510>
   22909:	ff 
   2290a:	66 0f 14 e4          	unpcklpd %xmm4,%xmm4
   2290e:	66 0f 59 25 4a 2e fe 	mulpd  -0x1d1b6(%rip),%xmm4        # 5760 <std::thread::current::id::ID+0x4ae8>
   22915:	ff 
   22916:	66 0f 14 db          	unpcklpd %xmm3,%xmm3
   2291a:	66 0f 59 1d 4e 2e fe 	mulpd  -0x1d1b2(%rip),%xmm3        # 5770 <std::thread::current::id::ID+0x4af8>
   22921:	ff 
   22922:	66 0f 58 dc          	addpd  %xmm4,%xmm3
   22926:	66 0f 14 c9          	unpcklpd %xmm1,%xmm1
   2292a:	66 0f 59 0d fe 2b fe 	mulpd  -0x1d402(%rip),%xmm1        # 5530 <std::thread::current::id::ID+0x48b8>
   22931:	ff 
   22932:	66 0f 58 cb          	addpd  %xmm3,%xmm1
   22936:	e9 0d fd ff ff       	jmp    22648 <gpui_canvas::color::gamut::in_gamut+0x398>

