<gpui_canvas::color::OutputProfile>::max_chroma:
   1f700:	66 0f 7e c1          	movd   %xmm0,%ecx
   1f704:	81 e1 ff ff ff 7f    	and    $0x7fffffff,%ecx
   1f70a:	b8 0d 00 00 00       	mov    $0xd,%eax
   1f70f:	81 f9 ff ff 7f 7f    	cmp    $0x7f7fffff,%ecx
   1f715:	7f 38                	jg     1f74f <<gpui_canvas::color::OutputProfile>::max_chroma+0x4f>
   1f717:	0f 57 e4             	xorps  %xmm4,%xmm4
   1f71a:	0f 57 d2             	xorps  %xmm2,%xmm2
   1f71d:	f3 0f c2 d0 06       	cmpnless %xmm0,%xmm2
   1f722:	0f 28 d8             	movaps %xmm0,%xmm3
   1f725:	f3 0f c2 1d 8a 61 fe 	cmpnless -0x19e76(%rip),%xmm3        # 58b8 <std::thread::current::id::ID+0x4c40>
   1f72c:	ff 06 
   1f72e:	0f 56 da             	orps   %xmm2,%xmm3
   1f731:	66 0f 7e d9          	movd   %xmm3,%ecx
   1f735:	66 0f 7e ca          	movd   %xmm1,%edx
   1f739:	81 e2 ff ff ff 7f    	and    $0x7fffffff,%edx
   1f73f:	81 fa 00 00 80 7f    	cmp    $0x7f800000,%edx
   1f745:	0f 9d c2             	setge  %dl
   1f748:	08 ca                	or     %cl,%dl
   1f74a:	f6 c2 01             	test   $0x1,%dl
   1f74d:	74 01                	je     1f750 <<gpui_canvas::color::OutputProfile>::max_chroma+0x50>
   1f74f:	c3                   	ret
   1f750:	0f 2e c4             	ucomiss %xmm4,%xmm0
   1f753:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   1f758:	75 02                	jne    1f75c <<gpui_canvas::color::OutputProfile>::max_chroma+0x5c>
   1f75a:	7b f3                	jnp    1f74f <<gpui_canvas::color::OutputProfile>::max_chroma+0x4f>
   1f75c:	0f 2e 05 55 61 fe ff 	ucomiss -0x19eab(%rip),%xmm0        # 58b8 <std::thread::current::id::ID+0x4c40>
   1f763:	75 02                	jne    1f767 <<gpui_canvas::color::OutputProfile>::max_chroma+0x67>
   1f765:	7b e8                	jnp    1f74f <<gpui_canvas::color::OutputProfile>::max_chroma+0x4f>
   1f767:	53                   	push   %rbx
   1f768:	48 83 ec 10          	sub    $0x10,%rsp
   1f76c:	f3 0f 11 44 24 0c    	movss  %xmm0,0xc(%rsp)
   1f772:	89 fb                	mov    %edi,%ebx
   1f774:	0f 57 c0             	xorps  %xmm0,%xmm0
   1f777:	f3 0f 5a c1          	cvtss2sd %xmm1,%xmm0
   1f77b:	f2 0f 10 0d 7d 7c fe 	movsd  -0x18383(%rip),%xmm1        # 7400 <std::thread::current::id::ID+0x6788>
   1f782:	ff 
   1f783:	ff 15 2f 5b 04 00    	call   *0x45b2f(%rip)        # 652b8 <_DYNAMIC+0x378>
   1f789:	f2 0f 10 1d 6f 7c fe 	movsd  -0x18391(%rip),%xmm3        # 7400 <std::thread::current::id::ID+0x6788>
   1f790:	ff 
   1f791:	f2 0f 58 d8          	addsd  %xmm0,%xmm3
   1f795:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   1f799:	66 0f 28 d0          	movapd %xmm0,%xmm2
   1f79d:	f2 0f c2 d1 01       	cmpltsd %xmm1,%xmm2
   1f7a2:	66 0f 54 da          	andpd  %xmm2,%xmm3
   1f7a6:	66 0f 55 d0          	andnpd %xmm0,%xmm2
   1f7aa:	66 0f 56 d3          	orpd   %xmm3,%xmm2
   1f7ae:	66 0f 2e 15 82 7b fe 	ucomisd -0x1847e(%rip),%xmm2        # 7338 <std::thread::current::id::ID+0x66c0>
   1f7b5:	ff 
   1f7b6:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   1f7ba:	73 0f                	jae    1f7cb <<gpui_canvas::color::OutputProfile>::max_chroma+0xcb>
   1f7bc:	0f 57 c0             	xorps  %xmm0,%xmm0
   1f7bf:	f2 0f 5a c2          	cvtsd2ss %xmm2,%xmm0
   1f7c3:	f3 0f c2 c8 00       	cmpeqss %xmm0,%xmm1
   1f7c8:	0f 55 c8             	andnps %xmm0,%xmm1
   1f7cb:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   1f7d1:	0f b6 fb             	movzbl %bl,%edi
   1f7d4:	48 83 c4 10          	add    $0x10,%rsp
   1f7d8:	5b                   	pop    %rbx
   1f7d9:	e9 02 1f 00 00       	jmp    216e0 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>>
   1f7de:	cc                   	int3
   1f7df:	cc                   	int3

<gpui_canvas::color::Color>::fit_chroma:
   20310:	55                   	push   %rbp
   20311:	41 57                	push   %r15
   20313:	41 56                	push   %r14
   20315:	41 54                	push   %r12
   20317:	53                   	push   %rbx
   20318:	48 83 ec 30          	sub    $0x30,%rsp
   2031c:	48 89 fb             	mov    %rdi,%rbx
   2031f:	44 8b 66 08          	mov    0x8(%rsi),%r12d
   20323:	44 8b 7e 0c          	mov    0xc(%rsi),%r15d
   20327:	41 81 ff 00 00 00 c0 	cmp    $0xc0000000,%r15d
   2032e:	0f 92 c0             	setb   %al
   20331:	45 85 e4             	test   %r12d,%r12d
   20334:	0f 99 c1             	setns  %cl
   20337:	08 c1                	or     %al,%cl
   20339:	74 09                	je     20344 <<gpui_canvas::color::Color>::fit_chroma+0x34>
   2033b:	c7 43 04 0d 00 00 00 	movl   $0xd,0x4(%rbx)
   20342:	eb 4a                	jmp    2038e <<gpui_canvas::color::Color>::fit_chroma+0x7e>
   20344:	49 89 f6             	mov    %rsi,%r14
   20347:	0f 10 06             	movups (%rsi),%xmm0
   2034a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   2034f:	0f b6 ea             	movzbl %dl,%ebp
   20352:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   20357:	89 ee                	mov    %ebp,%esi
   20359:	e8 92 1f 00 00       	call   222f0 <gpui_canvas::color::gamut::in_gamut>
   2035e:	84 c0                	test   %al,%al
   20360:	74 0c                	je     2036e <<gpui_canvas::color::Color>::fit_chroma+0x5e>
   20362:	41 0f 10 06          	movups (%r14),%xmm0
   20366:	0f 11 43 04          	movups %xmm0,0x4(%rbx)
   2036a:	31 c0                	xor    %eax,%eax
   2036c:	eb 25                	jmp    20393 <<gpui_canvas::color::Color>::fit_chroma+0x83>
   2036e:	41 8b 16             	mov    (%r14),%edx
   20371:	89 d6                	mov    %edx,%esi
   20373:	81 e6 ff ff ff 7f    	and    $0x7fffffff,%esi
   20379:	b8 0d 00 00 00       	mov    $0xd,%eax
   2037e:	31 c9                	xor    %ecx,%ecx
   20380:	81 fe ff ff 7f 7f    	cmp    $0x7f7fffff,%esi
   20386:	7e 1d                	jle    203a5 <<gpui_canvas::color::Color>::fit_chroma+0x95>
   20388:	89 43 04             	mov    %eax,0x4(%rbx)
   2038b:	89 4b 08             	mov    %ecx,0x8(%rbx)
   2038e:	b8 01 00 00 00       	mov    $0x1,%eax
   20393:	89 03                	mov    %eax,(%rbx)
   20395:	48 89 d8             	mov    %rbx,%rax
   20398:	48 83 c4 30          	add    $0x30,%rsp
   2039c:	5b                   	pop    %rbx
   2039d:	41 5c                	pop    %r12
   2039f:	41 5e                	pop    %r14
   203a1:	41 5f                	pop    %r15
   203a3:	5d                   	pop    %rbp
   203a4:	c3                   	ret
   203a5:	44 89 e6             	mov    %r12d,%esi
   203a8:	81 e6 ff ff ff 7f    	and    $0x7fffffff,%esi
   203ae:	66 0f 6e c6          	movd   %esi,%xmm0
   203b2:	0f 2e 05 37 55 fe ff 	ucomiss -0x1aac9(%rip),%xmm0        # 58f0 <std::thread::current::id::ID+0x4c78>
   203b9:	74 cd                	je     20388 <<gpui_canvas::color::Color>::fit_chroma+0x78>
   203bb:	66 0f 6e d2          	movd   %edx,%xmm2
   203bf:	0f 57 c9             	xorps  %xmm1,%xmm1
   203c2:	0f 2e d1             	ucomiss %xmm1,%xmm2
   203c5:	72 c1                	jb     20388 <<gpui_canvas::color::Color>::fit_chroma+0x78>
   203c7:	f3 0f 10 0d e9 54 fe 	movss  -0x1ab17(%rip),%xmm1        # 58b8 <std::thread::current::id::ID+0x4c40>
   203ce:	ff 
   203cf:	0f 2e ca             	ucomiss %xmm2,%xmm1
   203d2:	72 b4                	jb     20388 <<gpui_canvas::color::Color>::fit_chroma+0x78>
   203d4:	f3 41 0f 10 5e 04    	movss  0x4(%r14),%xmm3
   203da:	31 c9                	xor    %ecx,%ecx
   203dc:	0f 57 c9             	xorps  %xmm1,%xmm1
   203df:	0f 2e d1             	ucomiss %xmm1,%xmm2
   203e2:	f3 0f 11 54 24 0c    	movss  %xmm2,0xc(%rsp)
   203e8:	75 02                	jne    203ec <<gpui_canvas::color::Color>::fit_chroma+0xdc>
   203ea:	7b 63                	jnp    2044f <<gpui_canvas::color::Color>::fit_chroma+0x13f>
   203ec:	0f 2e 15 c5 54 fe ff 	ucomiss -0x1ab3b(%rip),%xmm2        # 58b8 <std::thread::current::id::ID+0x4c40>
   203f3:	75 02                	jne    203f7 <<gpui_canvas::color::Color>::fit_chroma+0xe7>
   203f5:	7b 58                	jnp    2044f <<gpui_canvas::color::Color>::fit_chroma+0x13f>
   203f7:	0f 29 5c 24 20       	movaps %xmm3,0x20(%rsp)
   203fc:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   20400:	f2 0f 10 0d f8 6f fe 	movsd  -0x19008(%rip),%xmm1        # 7400 <std::thread::current::id::ID+0x6788>
   20407:	ff 
   20408:	ff 15 aa 4e 04 00    	call   *0x44eaa(%rip)        # 652b8 <_DYNAMIC+0x378>
   2040e:	66 0f 2e 05 22 6f fe 	ucomisd -0x190de(%rip),%xmm0        # 7338 <std::thread::current::id::ID+0x66c0>
   20415:	ff 
   20416:	0f 57 c9             	xorps  %xmm1,%xmm1
   20419:	73 0c                	jae    20427 <<gpui_canvas::color::Color>::fit_chroma+0x117>
   2041b:	f2 0f 5a c0          	cvtsd2ss %xmm0,%xmm0
   2041f:	f3 0f c2 c8 00       	cmpeqss %xmm0,%xmm1
   20424:	0f 55 c8             	andnps %xmm0,%xmm1
   20427:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   2042d:	89 ef                	mov    %ebp,%edi
   2042f:	e8 ac 12 00 00       	call   216e0 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>>
   20434:	f3 0f 10 54 24 0c    	movss  0xc(%rsp),%xmm2
   2043a:	48 89 c1             	mov    %rax,%rcx
   2043d:	48 c1 e9 20          	shr    $0x20,%rcx
   20441:	83 f8 ff             	cmp    $0xffffffff,%eax
   20444:	0f 28 5c 24 20       	movaps 0x20(%rsp),%xmm3
   20449:	0f 85 39 ff ff ff    	jne    20388 <<gpui_canvas::color::Color>::fit_chroma+0x78>
   2044f:	66 0f 6e c1          	movd   %ecx,%xmm0
   20453:	0f 28 cb             	movaps %xmm3,%xmm1
   20456:	f3 0f 5d c8          	minss  %xmm0,%xmm1
   2045a:	0f 28 e1             	movaps %xmm1,%xmm4
   2045d:	f3 0f c2 e1 03       	cmpunordss %xmm1,%xmm4
   20462:	0f 28 c4             	movaps %xmm4,%xmm0
   20465:	0f 55 c1             	andnps %xmm1,%xmm0
   20468:	0f 54 e3             	andps  %xmm3,%xmm4
   2046b:	0f 56 e0             	orps   %xmm0,%xmm4
   2046e:	f3 0f 11 54 24 10    	movss  %xmm2,0x10(%rsp)
   20474:	0f 29 64 24 20       	movaps %xmm4,0x20(%rsp)
   20479:	f3 0f 11 64 24 14    	movss  %xmm4,0x14(%rsp)
   2047f:	44 89 64 24 18       	mov    %r12d,0x18(%rsp)
   20484:	44 89 7c 24 1c       	mov    %r15d,0x1c(%rsp)
   20489:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   2048e:	89 ee                	mov    %ebp,%esi
   20490:	e8 5b 1e 00 00       	call   222f0 <gpui_canvas::color::gamut::in_gamut>
   20495:	84 c0                	test   %al,%al
   20497:	74 1c                	je     204b5 <<gpui_canvas::color::Color>::fit_chroma+0x1a5>
   20499:	0f 28 44 24 20       	movaps 0x20(%rsp),%xmm0
   2049e:	f3 0f 11 43 08       	movss  %xmm0,0x8(%rbx)
   204a3:	44 89 63 0c          	mov    %r12d,0xc(%rbx)
   204a7:	44 89 7b 10          	mov    %r15d,0x10(%rbx)
   204ab:	31 c0                	xor    %eax,%eax
   204ad:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   204b3:	eb 0d                	jmp    204c2 <<gpui_canvas::color::Color>::fit_chroma+0x1b2>
   204b5:	b8 01 00 00 00       	mov    $0x1,%eax
   204ba:	f3 0f 10 05 ee 53 fe 	movss  -0x1ac12(%rip),%xmm0        # 58b0 <std::thread::current::id::ID+0x4c38>
   204c1:	ff 
   204c2:	f3 0f 11 43 04       	movss  %xmm0,0x4(%rbx)
   204c7:	e9 c7 fe ff ff       	jmp    20393 <<gpui_canvas::color::Color>::fit_chroma+0x83>
   204cc:	cc                   	int3
   204cd:	cc                   	int3
   204ce:	cc                   	int3
   204cf:	cc                   	int3

gpui_canvas::color::gamut::first_exit::<fearless_simd::generated::sse2::Sse2>:
   209d0:	55                   	push   %rbp
   209d1:	48 89 e5             	mov    %rsp,%rbp
   209d4:	41 57                	push   %r15
   209d6:	41 56                	push   %r14
   209d8:	41 55                	push   %r13
   209da:	41 54                	push   %r12
   209dc:	53                   	push   %rbx
   209dd:	48 83 e4 e0          	and    $0xffffffffffffffe0,%rsp
   209e1:	48 81 ec 40 03 00 00 	sub    $0x340,%rsp
   209e8:	48 89 cb             	mov    %rcx,%rbx
   209eb:	66 44 0f 28 26       	movapd (%rsi),%xmm12
   209f0:	66 44 0f 28 5e 10    	movapd 0x10(%rsi),%xmm11
   209f6:	66 44 0f 28 56 20    	movapd 0x20(%rsi),%xmm10
   209fc:	66 44 0f 28 4e 30    	movapd 0x30(%rsi),%xmm9
   20a02:	66 44 0f 28 46 40    	movapd 0x40(%rsi),%xmm8
   20a08:	66 0f 28 7e 50       	movapd 0x50(%rsi),%xmm7
   20a0d:	66 0f 28 76 60       	movapd 0x60(%rsi),%xmm6
   20a12:	66 44 0f 28 7e 70    	movapd 0x70(%rsi),%xmm15
   20a18:	66 0f 28 12          	movapd (%rdx),%xmm2
   20a1c:	66 0f 28 5a 10       	movapd 0x10(%rdx),%xmm3
   20a21:	66 0f 28 62 20       	movapd 0x20(%rdx),%xmm4
   20a26:	66 45 0f 57 f6       	xorpd  %xmm14,%xmm14
   20a2b:	66 44 0f c2 f6 01    	cmpltpd %xmm6,%xmm14
   20a31:	66 45 0f 57 ed       	xorpd  %xmm13,%xmm13
   20a36:	66 45 0f c2 ef 01    	cmpltpd %xmm15,%xmm13
   20a3c:	66 0f 28 2d 3c 4d fe 	movapd -0x1b2c4(%rip),%xmm5        # 5780 <std::thread::current::id::ID+0x4b08>
   20a43:	ff 
   20a44:	66 44 0f 55 f5       	andnpd %xmm5,%xmm14
   20a49:	66 44 0f 55 ed       	andnpd %xmm5,%xmm13
   20a4e:	66 0f 28 6a 30       	movapd 0x30(%rdx),%xmm5
   20a53:	66 44 0f 29 74 24 10 	movapd %xmm14,0x10(%rsp)
   20a5a:	66 44 0f 29 37       	movapd %xmm14,(%rdi)
   20a5f:	66 44 0f 29 6c 24 20 	movapd %xmm13,0x20(%rsp)
   20a66:	66 44 0f 29 6f 10    	movapd %xmm13,0x10(%rdi)
   20a6c:	66 0f 5d d0          	minpd  %xmm0,%xmm2
   20a70:	4c 8d ac 24 c0 02 00 	lea    0x2c0(%rsp),%r13
   20a77:	00 
   20a78:	66 0f 29 94 24 c0 02 	movapd %xmm2,0x2c0(%rsp)
   20a7f:	00 00 
   20a81:	66 0f 5d d9          	minpd  %xmm1,%xmm3
   20a85:	66 0f 5d e0          	minpd  %xmm0,%xmm4
   20a89:	66 0f 5d e9          	minpd  %xmm1,%xmm5
   20a8d:	66 0f 29 9c 24 d0 02 	movapd %xmm3,0x2d0(%rsp)
   20a94:	00 00 
   20a96:	66 0f 29 a4 24 e0 02 	movapd %xmm4,0x2e0(%rsp)
   20a9d:	00 00 
   20a9f:	66 0f 29 ac 24 f0 02 	movapd %xmm5,0x2f0(%rsp)
   20aa6:	00 00 
   20aa8:	66 0f 29 84 24 00 03 	movapd %xmm0,0x300(%rsp)
   20aaf:	00 00 
   20ab1:	66 0f 29 8c 24 10 03 	movapd %xmm1,0x310(%rsp)
   20ab8:	00 00 
   20aba:	66 0f 28 05 7e 47 fe 	movapd -0x1b882(%rip),%xmm0        # 5240 <std::thread::current::id::ID+0x45c8>
   20ac1:	ff 
   20ac2:	66 44 0f 29 64 24 40 	movapd %xmm12,0x40(%rsp)
   20ac9:	66 44 0f 54 e0       	andpd  %xmm0,%xmm12
   20ace:	66 44 0f 29 a4 24 80 	movapd %xmm12,0x180(%rsp)
   20ad5:	01 00 00 
   20ad8:	66 44 0f 29 5c 24 30 	movapd %xmm11,0x30(%rsp)
   20adf:	66 44 0f 54 d8       	andpd  %xmm0,%xmm11
   20ae4:	66 44 0f 29 9c 24 70 	movapd %xmm11,0x170(%rsp)
   20aeb:	01 00 00 
   20aee:	66 44 0f 29 94 24 e0 	movapd %xmm10,0xe0(%rsp)
   20af5:	00 00 00 
   20af8:	66 44 0f 54 d0       	andpd  %xmm0,%xmm10
   20afd:	66 44 0f 29 94 24 60 	movapd %xmm10,0x160(%rsp)
   20b04:	01 00 00 
   20b07:	66 44 0f 29 8c 24 d0 	movapd %xmm9,0xd0(%rsp)
   20b0e:	00 00 00 
   20b11:	66 41 0f 28 c9       	movapd %xmm9,%xmm1
   20b16:	66 45 0f 28 ef       	movapd %xmm15,%xmm13
   20b1b:	66 0f 54 c8          	andpd  %xmm0,%xmm1
   20b1f:	66 0f 29 8c 24 50 01 	movapd %xmm1,0x150(%rsp)
   20b26:	00 00 
   20b28:	66 45 0f 28 f8       	movapd %xmm8,%xmm15
   20b2d:	66 44 0f 54 c0       	andpd  %xmm0,%xmm8
   20b32:	66 44 0f 29 84 24 40 	movapd %xmm8,0x140(%rsp)
   20b39:	01 00 00 
   20b3c:	66 44 0f 28 df       	movapd %xmm7,%xmm11
   20b41:	66 0f 54 f8          	andpd  %xmm0,%xmm7
   20b45:	66 0f 29 bc 24 30 01 	movapd %xmm7,0x130(%rsp)
   20b4c:	00 00 
   20b4e:	66 0f 28 e6          	movapd %xmm6,%xmm4
   20b52:	66 0f 28 ce          	movapd %xmm6,%xmm1
   20b56:	66 0f 54 c8          	andpd  %xmm0,%xmm1
   20b5a:	66 0f 29 8c 24 20 01 	movapd %xmm1,0x120(%rsp)
   20b61:	00 00 
   20b63:	66 41 0f 28 cd       	movapd %xmm13,%xmm1
   20b68:	66 0f 54 c8          	andpd  %xmm0,%xmm1
   20b6c:	66 0f 29 8c 24 10 01 	movapd %xmm1,0x110(%rsp)
   20b73:	00 00 
   20b75:	45 31 f6             	xor    %r14d,%r14d
   20b78:	4c 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%r15
   20b7f:	00 
   20b80:	4c 8d a4 24 00 02 00 	lea    0x200(%rsp),%r12
   20b87:	00 
   20b88:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
   20b8c:	0f 28 0f             	movaps (%rdi),%xmm1
   20b8f:	0f 29 4c 24 60       	movaps %xmm1,0x60(%rsp)
   20b94:	48 89 7c 24 58       	mov    %rdi,0x58(%rsp)
   20b99:	66 0f 28 4f 10       	movapd 0x10(%rdi),%xmm1
   20b9e:	66 0f 29 4c 24 70    	movapd %xmm1,0x70(%rsp)
   20ba4:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   20ba8:	66 44 0f 29 bc 24 00 	movapd %xmm15,0x100(%rsp)
   20baf:	01 00 00 
   20bb2:	66 44 0f 29 9c 24 f0 	movapd %xmm11,0xf0(%rsp)
   20bb9:	00 00 00 
   20bbc:	66 0f 29 b4 24 a0 00 	movapd %xmm6,0xa0(%rsp)
   20bc3:	00 00 
   20bc5:	66 44 0f 29 ac 24 90 	movapd %xmm13,0x190(%rsp)
   20bcc:	01 00 00 
   20bcf:	eb 3c                	jmp    20c0d <gpui_canvas::color::gamut::first_exit::<fearless_simd::generated::sse2::Sse2>+0x23d>
   20bd1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   20bd8:	0f 1f 84 00 00 00 00 
   20bdf:	00 
   20be0:	66 45 0f 28 ec       	movapd %xmm12,%xmm13
   20be5:	49 ff c6             	inc    %r14
   20be8:	66 0f 28 84 24 b0 00 	movapd 0xb0(%rsp),%xmm0
   20bef:	00 00 
   20bf1:	66 0f 28 8c 24 c0 00 	movapd 0xc0(%rsp),%xmm1
   20bf8:	00 00 
   20bfa:	49 83 fe 03          	cmp    $0x3,%r14
   20bfe:	66 0f 28 a4 24 a0 00 	movapd 0xa0(%rsp),%xmm4
   20c05:	00 00 
   20c07:	0f 84 38 04 00 00    	je     21045 <gpui_canvas::color::gamut::first_exit::<fearless_simd::generated::sse2::Sse2>+0x675>
   20c0d:	66 0f 29 8c 24 c0 01 	movapd %xmm1,0x1c0(%rsp)
   20c14:	00 00 
   20c16:	66 0f 29 84 24 d0 01 	movapd %xmm0,0x1d0(%rsp)
   20c1d:	00 00 
   20c1f:	4c 89 f0             	mov    %r14,%rax
   20c22:	48 c1 e0 05          	shl    $0x5,%rax
   20c26:	66 45 0f 28 4c 05 00 	movapd 0x0(%r13,%rax,1),%xmm9
   20c2d:	66 41 0f 28 74 05 10 	movapd 0x10(%r13,%rax,1),%xmm6
   20c34:	66 0f 28 54 24 40    	movapd 0x40(%rsp),%xmm2
   20c3a:	66 41 0f 59 d1       	mulpd  %xmm9,%xmm2
   20c3f:	66 0f 28 5c 24 30    	movapd 0x30(%rsp),%xmm3
   20c45:	66 0f 59 de          	mulpd  %xmm6,%xmm3
   20c49:	66 44 0f 28 b4 24 e0 	movapd 0xe0(%rsp),%xmm14
   20c50:	00 00 00 
   20c53:	66 41 0f 58 d6       	addpd  %xmm14,%xmm2
   20c58:	66 0f 28 ac 24 d0 00 	movapd 0xd0(%rsp),%xmm5
   20c5f:	00 00 
   20c61:	66 0f 58 dd          	addpd  %xmm5,%xmm3
   20c65:	66 41 0f 59 d1       	mulpd  %xmm9,%xmm2
   20c6a:	66 0f 59 de          	mulpd  %xmm6,%xmm3
   20c6e:	66 41 0f 58 d7       	addpd  %xmm15,%xmm2
   20c73:	66 41 0f 58 db       	addpd  %xmm11,%xmm3
   20c78:	66 41 0f 59 d1       	mulpd  %xmm9,%xmm2
   20c7d:	66 0f 59 de          	mulpd  %xmm6,%xmm3
   20c81:	66 0f 58 d4          	addpd  %xmm4,%xmm2
   20c85:	66 41 0f 58 dd       	addpd  %xmm13,%xmm3
   20c8a:	66 0f 28 8c 24 80 01 	movapd 0x180(%rsp),%xmm1
   20c91:	00 00 
   20c93:	66 41 0f 59 c9       	mulpd  %xmm9,%xmm1
   20c98:	66 0f 58 8c 24 60 01 	addpd  0x160(%rsp),%xmm1
   20c9f:	00 00 
   20ca1:	66 0f 28 84 24 70 01 	movapd 0x170(%rsp),%xmm0
   20ca8:	00 00 
   20caa:	66 0f 59 c6          	mulpd  %xmm6,%xmm0
   20cae:	66 0f 58 84 24 50 01 	addpd  0x150(%rsp),%xmm0
   20cb5:	00 00 
   20cb7:	66 41 0f 59 c9       	mulpd  %xmm9,%xmm1
   20cbc:	66 0f 58 8c 24 40 01 	addpd  0x140(%rsp),%xmm1
   20cc3:	00 00 
   20cc5:	66 0f 59 c6          	mulpd  %xmm6,%xmm0
   20cc9:	66 0f 58 84 24 30 01 	addpd  0x130(%rsp),%xmm0
   20cd0:	00 00 
   20cd2:	66 41 0f 59 c9       	mulpd  %xmm9,%xmm1
   20cd7:	66 0f 58 8c 24 20 01 	addpd  0x120(%rsp),%xmm1
   20cde:	00 00 
   20ce0:	66 0f 59 c6          	mulpd  %xmm6,%xmm0
   20ce4:	66 0f 58 84 24 10 01 	addpd  0x110(%rsp),%xmm0
   20ceb:	00 00 
   20ced:	66 0f 29 94 24 80 00 	movapd %xmm2,0x80(%rsp)
   20cf4:	00 00 
   20cf6:	66 44 0f 28 15 41 45 	movapd -0x1babf(%rip),%xmm10        # 5240 <std::thread::current::id::ID+0x45c8>
   20cfd:	fe ff 
   20cff:	66 41 0f 54 d2       	andpd  %xmm10,%xmm2
   20d04:	66 44 0f 28 25 73 45 	movapd -0x1ba8d(%rip),%xmm12        # 5280 <std::thread::current::id::ID+0x4608>
   20d0b:	fe ff 
   20d0d:	66 41 0f 59 cc       	mulpd  %xmm12,%xmm1
   20d12:	66 0f c2 d1 02       	cmplepd %xmm1,%xmm2
   20d17:	66 0f 29 9c 24 90 00 	movapd %xmm3,0x90(%rsp)
   20d1e:	00 00 
   20d20:	66 41 0f 54 da       	andpd  %xmm10,%xmm3
   20d25:	66 41 0f 59 c4       	mulpd  %xmm12,%xmm0
   20d2a:	66 0f c2 d8 02       	cmplepd %xmm0,%xmm3
   20d2f:	0f 28 44 24 40       	movaps 0x40(%rsp),%xmm0
   20d34:	0f 29 84 24 00 02 00 	movaps %xmm0,0x200(%rsp)
   20d3b:	00 
   20d3c:	66 0f 28 44 24 30    	movapd 0x30(%rsp),%xmm0
   20d42:	66 0f 29 84 24 10 02 	movapd %xmm0,0x210(%rsp)
   20d49:	00 00 
   20d4b:	66 44 0f 29 b4 24 20 	movapd %xmm14,0x220(%rsp)
   20d52:	02 00 00 
   20d55:	66 0f 29 ac 24 30 02 	movapd %xmm5,0x230(%rsp)
   20d5c:	00 00 
   20d5e:	66 44 0f 29 bc 24 40 	movapd %xmm15,0x240(%rsp)
   20d65:	02 00 00 
   20d68:	66 44 0f 29 9c 24 50 	movapd %xmm11,0x250(%rsp)
   20d6f:	02 00 00 
   20d72:	66 0f 29 a4 24 60 02 	movapd %xmm4,0x260(%rsp)
   20d79:	00 00 
   20d7b:	66 44 0f 29 ac 24 70 	movapd %xmm13,0x270(%rsp)
   20d82:	02 00 00 
   20d85:	66 44 0f 29 8c 24 80 	movapd %xmm9,0x280(%rsp)
   20d8c:	02 00 00 
   20d8f:	66 0f 29 b4 24 90 02 	movapd %xmm6,0x290(%rsp)
   20d96:	00 00 
   20d98:	66 0f 50 c2          	movmskpd %xmm2,%eax
   20d9c:	66 0f 50 cb          	movmskpd %xmm3,%ecx
   20da0:	c1 e1 02             	shl    $0x2,%ecx
   20da3:	83 e1 04             	and    $0x4,%ecx
   20da6:	09 c1                	or     %eax,%ecx
   20da8:	66 44 0f 29 8c 24 c0 	movapd %xmm9,0xc0(%rsp)
   20daf:	00 00 00 
   20db2:	66 0f 29 b4 24 b0 00 	movapd %xmm6,0xb0(%rsp)
   20db9:	00 00 
   20dbb:	0f 84 9f 00 00 00    	je     20e60 <gpui_canvas::color::gamut::first_exit::<fearless_simd::generated::sse2::Sse2>+0x490>
   20dc1:	66 0f 29 94 24 b0 01 	movapd %xmm2,0x1b0(%rsp)
   20dc8:	00 00 
   20dca:	66 44 0f 54 ca       	andpd  %xmm2,%xmm9
   20dcf:	66 0f 54 f3          	andpd  %xmm3,%xmm6
   20dd3:	4c 89 ff             	mov    %r15,%rdi
   20dd6:	4c 89 e6             	mov    %r12,%rsi
   20dd9:	66 41 0f 28 c1       	movapd %xmm9,%xmm0
   20dde:	66 0f 28 ce          	movapd %xmm6,%xmm1
   20de2:	66 0f 29 9c 24 a0 01 	movapd %xmm3,0x1a0(%rsp)
   20de9:	00 00 
   20deb:	e8 80 02 00 00       	call   21070 <gpui_canvas::color::gamut::exact_endpoint_sign::<fearless_simd::generated::sse2::Sse2>>
   20df0:	66 0f 28 b4 24 b0 00 	movapd 0xb0(%rsp),%xmm6
   20df7:	00 00 
   20df9:	66 44 0f 28 8c 24 c0 	movapd 0xc0(%rsp),%xmm9
   20e00:	00 00 00 
   20e03:	66 44 0f 28 9c 24 f0 	movapd 0xf0(%rsp),%xmm11
   20e0a:	00 00 00 
   20e0d:	66 44 0f 28 bc 24 00 	movapd 0x100(%rsp),%xmm15
   20e14:	01 00 00 
   20e17:	66 0f 28 84 24 e0 01 	movapd 0x1e0(%rsp),%xmm0
   20e1e:	00 00 
   20e20:	66 0f 28 a4 24 b0 01 	movapd 0x1b0(%rsp),%xmm4
   20e27:	00 00 
   20e29:	66 0f 54 c4          	andpd  %xmm4,%xmm0
   20e2d:	66 0f 55 a4 24 80 00 	andnpd 0x80(%rsp),%xmm4
   20e34:	00 00 
   20e36:	66 0f 56 e0          	orpd   %xmm0,%xmm4
   20e3a:	66 0f 28 84 24 f0 01 	movapd 0x1f0(%rsp),%xmm0
   20e41:	00 00 
   20e43:	66 0f 28 9c 24 a0 01 	movapd 0x1a0(%rsp),%xmm3
   20e4a:	00 00 
   20e4c:	66 0f 54 c3          	andpd  %xmm3,%xmm0
   20e50:	66 0f 55 9c 24 90 00 	andnpd 0x90(%rsp),%xmm3
   20e57:	00 00 
   20e59:	66 0f 56 d8          	orpd   %xmm0,%xmm3
   20e5d:	eb 13                	jmp    20e72 <gpui_canvas::color::gamut::first_exit::<fearless_simd::generated::sse2::Sse2>+0x4a2>
   20e5f:	90                   	nop
   20e60:	66 0f 28 9c 24 90 00 	movapd 0x90(%rsp),%xmm3
   20e67:	00 00 
   20e69:	66 0f 28 a4 24 80 00 	movapd 0x80(%rsp),%xmm4
   20e70:	00 00 
   20e72:	66 0f 28 4c 24 10    	movapd 0x10(%rsp),%xmm1
   20e78:	66 0f 28 05 00 49 fe 	movapd -0x1b700(%rip),%xmm0        # 5780 <std::thread::current::id::ID+0x4b08>
   20e7f:	ff 
   20e80:	66 0f c2 c8 00       	cmpeqpd %xmm0,%xmm1
   20e85:	66 0f 28 54 24 20    	movapd 0x20(%rsp),%xmm2
   20e8b:	66 0f c2 d0 00       	cmpeqpd %xmm0,%xmm2
   20e90:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
   20e94:	66 0f c2 c4 01       	cmpltpd %xmm4,%xmm0
   20e99:	66 0f 54 c1          	andpd  %xmm1,%xmm0
   20e9d:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   20ea1:	66 0f c2 cb 01       	cmpltpd %xmm3,%xmm1
   20ea6:	66 0f 54 ca          	andpd  %xmm2,%xmm1
   20eaa:	66 0f 50 c0          	movmskpd %xmm0,%eax
   20eae:	66 0f 50 c9          	movmskpd %xmm1,%ecx
   20eb2:	c1 e1 02             	shl    $0x2,%ecx
   20eb5:	83 e1 04             	and    $0x4,%ecx
   20eb8:	09 c1                	or     %eax,%ecx
   20eba:	48 89 d8             	mov    %rbx,%rax
   20ebd:	66 0f 28 de          	movapd %xmm6,%xmm3
   20ec1:	66 41 0f 28 e9       	movapd %xmm9,%xmm5
   20ec6:	66 44 0f 28 94 24 a0 	movapd 0xa0(%rsp),%xmm10
   20ecd:	00 00 00 
   20ed0:	66 44 0f 28 a4 24 90 	movapd 0x190(%rsp),%xmm12
   20ed7:	01 00 00 
   20eda:	66 0f 28 3d ce 44 fe 	movapd -0x1bb32(%rip),%xmm7        # 53b0 <std::thread::current::id::ID+0x4738>
   20ee1:	ff 
   20ee2:	66 44 0f 28 ac 24 d0 	movapd 0x1d0(%rsp),%xmm13
   20ee9:	01 00 00 
   20eec:	66 44 0f 28 b4 24 c0 	movapd 0x1c0(%rsp),%xmm14
   20ef3:	01 00 00 
   20ef6:	0f 84 e4 fc ff ff    	je     20be0 <gpui_canvas::color::gamut::first_exit::<fearless_simd::generated::sse2::Sse2>+0x210>
   20efc:	0f 1f 40 00          	nopl   0x0(%rax)
   20f00:	66 0f 28 e5          	movapd %xmm5,%xmm4
   20f04:	66 41 0f 5c e6       	subpd  %xmm14,%xmm4
   20f09:	66 0f 28 d3          	movapd %xmm3,%xmm2
   20f0d:	66 41 0f 5c d5       	subpd  %xmm13,%xmm2
   20f12:	66 0f 59 e7          	mulpd  %xmm7,%xmm4
   20f16:	66 0f 59 d7          	mulpd  %xmm7,%xmm2
   20f1a:	66 41 0f 58 e6       	addpd  %xmm14,%xmm4
   20f1f:	66 41 0f 58 d5       	addpd  %xmm13,%xmm2
   20f24:	66 0f 28 74 24 40    	movapd 0x40(%rsp),%xmm6
   20f2a:	66 0f 59 f4          	mulpd  %xmm4,%xmm6
   20f2e:	66 44 0f 28 44 24 30 	movapd 0x30(%rsp),%xmm8
   20f35:	66 44 0f 59 c2       	mulpd  %xmm2,%xmm8
   20f3a:	66 0f 58 b4 24 e0 00 	addpd  0xe0(%rsp),%xmm6
   20f41:	00 00 
   20f43:	66 44 0f 58 84 24 d0 	addpd  0xd0(%rsp),%xmm8
   20f4a:	00 00 00 
   20f4d:	66 0f 59 f4          	mulpd  %xmm4,%xmm6
   20f51:	66 44 0f 59 c2       	mulpd  %xmm2,%xmm8
   20f56:	66 41 0f 58 f7       	addpd  %xmm15,%xmm6
   20f5b:	66 45 0f 58 c3       	addpd  %xmm11,%xmm8
   20f60:	66 0f 59 f4          	mulpd  %xmm4,%xmm6
   20f64:	66 44 0f 59 c2       	mulpd  %xmm2,%xmm8
   20f69:	66 41 0f 58 f2       	addpd  %xmm10,%xmm6
   20f6e:	66 45 0f 58 c4       	addpd  %xmm12,%xmm8
   20f73:	66 45 0f 57 c9       	xorpd  %xmm9,%xmm9
   20f78:	66 44 0f c2 ce 01    	cmpltpd %xmm6,%xmm9
   20f7e:	66 0f 57 ff          	xorpd  %xmm7,%xmm7
   20f82:	66 41 0f c2 f8 01    	cmpltpd %xmm8,%xmm7
   20f88:	66 0f 28 f0          	movapd %xmm0,%xmm6
   20f8c:	66 41 0f 54 f1       	andpd  %xmm9,%xmm6
   20f91:	66 44 0f 28 c6       	movapd %xmm6,%xmm8
   20f96:	66 0f 55 f5          	andnpd %xmm5,%xmm6
   20f9a:	66 0f 28 e9          	movapd %xmm1,%xmm5
   20f9e:	66 0f 54 ef          	andpd  %xmm7,%xmm5
   20fa2:	66 44 0f 54 c4       	andpd  %xmm4,%xmm8
   20fa7:	66 41 0f 56 f0       	orpd   %xmm8,%xmm6
   20fac:	66 44 0f 28 c5       	movapd %xmm5,%xmm8
   20fb1:	66 0f 55 eb          	andnpd %xmm3,%xmm5
   20fb5:	66 44 0f 54 c2       	andpd  %xmm2,%xmm8
   20fba:	66 41 0f 56 e8       	orpd   %xmm8,%xmm5
   20fbf:	66 44 0f 55 c8       	andnpd %xmm0,%xmm9
   20fc4:	66 41 0f 54 e1       	andpd  %xmm9,%xmm4
   20fc9:	66 45 0f 55 ce       	andnpd %xmm14,%xmm9
   20fce:	66 45 0f 28 f1       	movapd %xmm9,%xmm14
   20fd3:	66 44 0f 56 f4       	orpd   %xmm4,%xmm14
   20fd8:	66 0f 55 f9          	andnpd %xmm1,%xmm7
   20fdc:	66 0f 54 d7          	andpd  %xmm7,%xmm2
   20fe0:	66 41 0f 55 fd       	andnpd %xmm13,%xmm7
   20fe5:	66 44 0f 28 ef       	movapd %xmm7,%xmm13
   20fea:	66 0f 28 3d be 43 fe 	movapd -0x1bc42(%rip),%xmm7        # 53b0 <std::thread::current::id::ID+0x4738>
   20ff1:	ff 
   20ff2:	66 44 0f 56 ea       	orpd   %xmm2,%xmm13
   20ff7:	66 0f 28 dd          	movapd %xmm5,%xmm3
   20ffb:	66 0f 28 ee          	movapd %xmm6,%xmm5
   20fff:	48 ff c8             	dec    %rax
   21002:	0f 85 f8 fe ff ff    	jne    20f00 <gpui_canvas::color::gamut::first_exit::<fearless_simd::generated::sse2::Sse2>+0x530>
   21008:	66 44 0f 54 f0       	andpd  %xmm0,%xmm14
   2100d:	66 0f 55 44 24 10    	andnpd 0x10(%rsp),%xmm0
   21013:	66 41 0f 56 c6       	orpd   %xmm14,%xmm0
   21018:	66 44 0f 54 e9       	andpd  %xmm1,%xmm13
   2101d:	66 0f 55 4c 24 20    	andnpd 0x20(%rsp),%xmm1
   21023:	66 41 0f 56 cd       	orpd   %xmm13,%xmm1
   21028:	66 0f 29 4c 24 70    	movapd %xmm1,0x70(%rsp)
   2102e:	66 0f 29 44 24 60    	movapd %xmm0,0x60(%rsp)
   21034:	66 0f 29 4c 24 20    	movapd %xmm1,0x20(%rsp)
   2103a:	66 0f 29 44 24 10    	movapd %xmm0,0x10(%rsp)
   21040:	e9 9b fb ff ff       	jmp    20be0 <gpui_canvas::color::gamut::first_exit::<fearless_simd::generated::sse2::Sse2>+0x210>
   21045:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
   2104a:	0f 28 44 24 60       	movaps 0x60(%rsp),%xmm0
   2104f:	0f 29 00             	movaps %xmm0,(%rax)
   21052:	0f 28 44 24 70       	movaps 0x70(%rsp),%xmm0
   21057:	0f 29 40 10          	movaps %xmm0,0x10(%rax)
   2105b:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
   2105f:	5b                   	pop    %rbx
   21060:	41 5c                	pop    %r12
   21062:	41 5d                	pop    %r13
   21064:	41 5e                	pop    %r14
   21066:	41 5f                	pop    %r15
   21068:	5d                   	pop    %rbp
   21069:	c3                   	ret
   2106a:	cc                   	int3
   2106b:	cc                   	int3
   2106c:	cc                   	int3
   2106d:	cc                   	int3
   2106e:	cc                   	int3
   2106f:	cc                   	int3

gpui_canvas::color::gamut::exact_endpoint_sign::<fearless_simd::generated::sse2::Sse2>:
   21070:	55                   	push   %rbp
   21071:	48 89 e5             	mov    %rsp,%rbp
   21074:	41 57                	push   %r15
   21076:	41 56                	push   %r14
   21078:	41 55                	push   %r13
   2107a:	41 54                	push   %r12
   2107c:	53                   	push   %rbx
   2107d:	48 83 e4 e0          	and    $0xffffffffffffffe0,%rsp
   21081:	48 81 ec 20 06 00 00 	sub    $0x620,%rsp
   21088:	0f 29 4c 24 30       	movaps %xmm1,0x30(%rsp)
   2108d:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
   21092:	49 89 f7             	mov    %rsi,%r15
   21095:	0f 57 c0             	xorps  %xmm0,%xmm0
   21098:	0f 29 47 10          	movaps %xmm0,0x10(%rdi)
   2109c:	48 89 7c 24 18       	mov    %rdi,0x18(%rsp)
   210a1:	0f 29 07             	movaps %xmm0,(%rdi)
   210a4:	4c 8d b4 24 20 02 00 	lea    0x220(%rsp),%r14
   210ab:	00 
   210ac:	31 db                	xor    %ebx,%ebx
   210ae:	ba e0 01 00 00       	mov    $0x1e0,%edx
   210b3:	4c 89 f7             	mov    %r14,%rdi
   210b6:	31 f6                	xor    %esi,%esi
   210b8:	ff 15 62 41 04 00    	call   *0x44162(%rip)        # 65220 <memset@GLIBC_2.2.5>
   210be:	66 44 0f 28 6c 24 20 	movapd 0x20(%rsp),%xmm13
   210c5:	66 44 0f 28 64 24 30 	movapd 0x30(%rsp),%xmm12
   210cc:	41 0f 28 07          	movaps (%r15),%xmm0
   210d0:	41 0f 28 4f 10       	movaps 0x10(%r15),%xmm1
   210d5:	0f 29 84 24 00 02 00 	movaps %xmm0,0x200(%rsp)
   210dc:	00 
   210dd:	0f 29 8c 24 10 02 00 	movaps %xmm1,0x210(%rsp)
   210e4:	00 
   210e5:	41 0f 28 47 20       	movaps 0x20(%r15),%xmm0
   210ea:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
   210ef:	41 0f 28 47 30       	movaps 0x30(%r15),%xmm0
   210f4:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
   210f9:	41 0f 28 47 40       	movaps 0x40(%r15),%xmm0
   210fe:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
   21103:	41 0f 28 47 50       	movaps 0x50(%r15),%xmm0
   21108:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
   2110d:	41 0f 28 47 60       	movaps 0x60(%r15),%xmm0
   21112:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
   21119:	00 
   2111a:	41 0f 28 47 70       	movaps 0x70(%r15),%xmm0
   2111f:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
   21126:	00 
   21127:	0f 28 44 24 40       	movaps 0x40(%rsp),%xmm0
   2112c:	0f 28 4c 24 50       	movaps 0x50(%rsp),%xmm1
   21131:	0f 28 54 24 60       	movaps 0x60(%rsp),%xmm2
   21136:	0f 28 5c 24 70       	movaps 0x70(%rsp),%xmm3
   2113b:	0f 29 84 24 20 01 00 	movaps %xmm0,0x120(%rsp)
   21142:	00 
   21143:	0f 29 8c 24 30 01 00 	movaps %xmm1,0x130(%rsp)
   2114a:	00 
   2114b:	0f 29 94 24 40 01 00 	movaps %xmm2,0x140(%rsp)
   21152:	00 
   21153:	0f 29 9c 24 50 01 00 	movaps %xmm3,0x150(%rsp)
   2115a:	00 
   2115b:	0f 28 84 24 80 00 00 	movaps 0x80(%rsp),%xmm0
   21162:	00 
   21163:	0f 29 84 24 60 01 00 	movaps %xmm0,0x160(%rsp)
   2116a:	00 
   2116b:	0f 28 84 24 90 00 00 	movaps 0x90(%rsp),%xmm0
   21172:	00 
   21173:	0f 29 84 24 70 01 00 	movaps %xmm0,0x170(%rsp)
   2117a:	00 
   2117b:	0f 28 84 24 70 01 00 	movaps 0x170(%rsp),%xmm0
   21182:	00 
   21183:	0f 29 84 24 f0 01 00 	movaps %xmm0,0x1f0(%rsp)
   2118a:	00 
   2118b:	0f 28 84 24 60 01 00 	movaps 0x160(%rsp),%xmm0
   21192:	00 
   21193:	0f 29 84 24 e0 01 00 	movaps %xmm0,0x1e0(%rsp)
   2119a:	00 
   2119b:	0f 28 84 24 50 01 00 	movaps 0x150(%rsp),%xmm0
   211a2:	00 
   211a3:	0f 29 84 24 d0 01 00 	movaps %xmm0,0x1d0(%rsp)
   211aa:	00 
   211ab:	0f 28 84 24 10 01 00 	movaps 0x110(%rsp),%xmm0
   211b2:	00 
   211b3:	0f 28 8c 24 20 01 00 	movaps 0x120(%rsp),%xmm1
   211ba:	00 
   211bb:	0f 28 94 24 30 01 00 	movaps 0x130(%rsp),%xmm2
   211c2:	00 
   211c3:	66 0f 28 9c 24 40 01 	movapd 0x140(%rsp),%xmm3
   211ca:	00 00 
   211cc:	66 0f 29 9c 24 c0 01 	movapd %xmm3,0x1c0(%rsp)
   211d3:	00 00 
   211d5:	0f 29 94 24 b0 01 00 	movaps %xmm2,0x1b0(%rsp)
   211dc:	00 
   211dd:	0f 29 8c 24 a0 01 00 	movaps %xmm1,0x1a0(%rsp)
   211e4:	00 
   211e5:	0f 29 84 24 90 01 00 	movaps %xmm0,0x190(%rsp)
   211ec:	00 
   211ed:	66 0f 28 05 3b 44 fe 	movapd -0x1bbc5(%rip),%xmm0        # 5630 <std::thread::current::id::ID+0x49b8>
   211f4:	ff 
   211f5:	66 45 0f 28 fd       	movapd %xmm13,%xmm15
   211fa:	66 44 0f 59 f8       	mulpd  %xmm0,%xmm15
   211ff:	66 41 0f 28 d4       	movapd %xmm12,%xmm2
   21204:	66 0f 59 d0          	mulpd  %xmm0,%xmm2
   21208:	66 41 0f 28 c7       	movapd %xmm15,%xmm0
   2120d:	66 41 0f 5c c5       	subpd  %xmm13,%xmm0
   21212:	66 0f 28 ca          	movapd %xmm2,%xmm1
   21216:	66 41 0f 5c cc       	subpd  %xmm12,%xmm1
   2121b:	66 44 0f 5c f8       	subpd  %xmm0,%xmm15
   21220:	66 0f 5c d1          	subpd  %xmm1,%xmm2
   21224:	66 41 0f 28 c5       	movapd %xmm13,%xmm0
   21229:	66 41 0f 5c c7       	subpd  %xmm15,%xmm0
   2122e:	66 0f 29 84 24 f0 00 	movapd %xmm0,0xf0(%rsp)
   21235:	00 00 
   21237:	66 41 0f 28 c4       	movapd %xmm12,%xmm0
   2123c:	66 0f 29 94 24 00 01 	movapd %xmm2,0x100(%rsp)
   21243:	00 00 
   21245:	66 0f 5c c2          	subpd  %xmm2,%xmm0
   21249:	66 0f 29 84 24 e0 00 	movapd %xmm0,0xe0(%rsp)
   21250:	00 00 
   21252:	41 bd 01 00 00 00    	mov    $0x1,%r13d
   21258:	4c 8d bc 24 00 04 00 	lea    0x400(%rsp),%r15
   2125f:	00 
   21260:	4c 8d a4 24 00 02 00 	lea    0x200(%rsp),%r12
   21267:	00 
   21268:	66 44 0f 29 bc 24 b0 	movapd %xmm15,0xb0(%rsp)
   2126f:	00 00 00 
   21272:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   21279:	1f 84 00 00 00 00 00 
   21280:	48 89 d8             	mov    %rbx,%rax
   21283:	48 ff c3             	inc    %rbx
   21286:	48 c1 e0 05          	shl    $0x5,%rax
   2128a:	48 8d 8c 24 a0 01 00 	lea    0x1a0(%rsp),%rcx
   21291:	00 
   21292:	0f 28 04 01          	movaps (%rcx,%rax,1),%xmm0
   21296:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
   2129d:	00 
   2129e:	0f 28 44 01 10       	movaps 0x10(%rcx,%rax,1),%xmm0
   212a3:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
   212aa:	00 
   212ab:	ba 00 02 00 00       	mov    $0x200,%edx
   212b0:	4c 89 ff             	mov    %r15,%rdi
   212b3:	4c 89 e6             	mov    %r12,%rsi
   212b6:	ff 15 bc 3f 04 00    	call   *0x43fbc(%rip)        # 65278 <memcpy@GLIBC_2.14>
   212bc:	66 44 0f 28 bc 24 b0 	movapd 0xb0(%rsp),%xmm15
   212c3:	00 00 00 
   212c6:	66 44 0f 28 35 61 43 	movapd -0x1bc9f(%rip),%xmm14        # 5630 <std::thread::current::id::ID+0x49b8>
   212cd:	fe ff 
   212cf:	66 44 0f 28 6c 24 20 	movapd 0x20(%rsp),%xmm13
   212d6:	66 44 0f 28 64 24 30 	movapd 0x30(%rsp),%xmm12
   212dd:	49 c1 e5 05          	shl    $0x5,%r13
   212e1:	4a 8d 0c 2c          	lea    (%rsp,%r13,1),%rcx
   212e5:	48 81 c1 00 04 00 00 	add    $0x400,%rcx
   212ec:	31 f6                	xor    %esi,%esi
   212ee:	4c 89 fa             	mov    %r15,%rdx
   212f1:	45 31 ed             	xor    %r13d,%r13d
   212f4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   212fb:	00 00 00 00 00 
   21300:	4c 89 ef             	mov    %r13,%rdi
   21303:	48 89 f0             	mov    %rsi,%rax
   21306:	66 0f 28 1a          	movapd (%rdx),%xmm3
   2130a:	66 0f 28 52 10       	movapd 0x10(%rdx),%xmm2
   2130f:	66 41 0f 28 c5       	movapd %xmm13,%xmm0
   21314:	66 0f 59 c3          	mulpd  %xmm3,%xmm0
   21318:	66 41 0f 28 cc       	movapd %xmm12,%xmm1
   2131d:	66 0f 59 ca          	mulpd  %xmm2,%xmm1
   21321:	66 0f 28 eb          	movapd %xmm3,%xmm5
   21325:	66 41 0f 59 ee       	mulpd  %xmm14,%xmm5
   2132a:	66 0f 28 e2          	movapd %xmm2,%xmm4
   2132e:	66 41 0f 59 e6       	mulpd  %xmm14,%xmm4
   21333:	66 0f 28 f5          	movapd %xmm5,%xmm6
   21337:	66 0f 5c f3          	subpd  %xmm3,%xmm6
   2133b:	66 0f 28 fc          	movapd %xmm4,%xmm7
   2133f:	66 0f 5c fa          	subpd  %xmm2,%xmm7
   21343:	66 0f 5c ee          	subpd  %xmm6,%xmm5
   21347:	66 0f 5c e7          	subpd  %xmm7,%xmm4
   2134b:	66 0f 5c dd          	subpd  %xmm5,%xmm3
   2134f:	66 0f 5c d4          	subpd  %xmm4,%xmm2
   21353:	66 41 0f 28 f7       	movapd %xmm15,%xmm6
   21358:	66 0f 59 f5          	mulpd  %xmm5,%xmm6
   2135c:	66 44 0f 28 84 24 00 	movapd 0x100(%rsp),%xmm8
   21363:	01 00 00 
   21366:	66 41 0f 28 f8       	movapd %xmm8,%xmm7
   2136b:	66 0f 59 fc          	mulpd  %xmm4,%xmm7
   2136f:	66 0f 5c f0          	subpd  %xmm0,%xmm6
   21373:	66 0f 5c f9          	subpd  %xmm1,%xmm7
   21377:	66 44 0f 28 8c 24 f0 	movapd 0xf0(%rsp),%xmm9
   2137e:	00 00 00 
   21381:	66 41 0f 59 e9       	mulpd  %xmm9,%xmm5
   21386:	66 0f 58 ee          	addpd  %xmm6,%xmm5
   2138a:	66 44 0f 28 94 24 e0 	movapd 0xe0(%rsp),%xmm10
   21391:	00 00 00 
   21394:	66 41 0f 59 e2       	mulpd  %xmm10,%xmm4
   21399:	66 0f 58 e7          	addpd  %xmm7,%xmm4
   2139d:	66 41 0f 28 f7       	movapd %xmm15,%xmm6
   213a2:	66 0f 59 f3          	mulpd  %xmm3,%xmm6
   213a6:	66 0f 58 f5          	addpd  %xmm5,%xmm6
   213aa:	66 41 0f 28 e8       	movapd %xmm8,%xmm5
   213af:	66 0f 59 ea          	mulpd  %xmm2,%xmm5
   213b3:	66 0f 58 ec          	addpd  %xmm4,%xmm5
   213b7:	66 41 0f 59 d9       	mulpd  %xmm9,%xmm3
   213bc:	66 0f 58 de          	addpd  %xmm6,%xmm3
   213c0:	66 41 0f 59 d2       	mulpd  %xmm10,%xmm2
   213c5:	66 0f 58 d5          	addpd  %xmm5,%xmm2
   213c9:	4c 89 ee             	mov    %r13,%rsi
   213cc:	48 c1 e6 05          	shl    $0x5,%rsi
   213d0:	48 01 e6             	add    %rsp,%rsi
   213d3:	48 81 c6 00 02 00 00 	add    $0x200,%rsi
   213da:	4d 85 ed             	test   %r13,%r13
   213dd:	0f 84 8a 00 00 00    	je     2146d <gpui_canvas::color::gamut::exact_endpoint_sign::<fearless_simd::generated::sse2::Sse2>+0x3fd>
   213e3:	4d 89 e0             	mov    %r12,%r8
   213e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   213ed:	00 00 00 
   213f0:	66 0f 28 e3          	movapd %xmm3,%xmm4
   213f4:	66 0f 28 ea          	movapd %xmm2,%xmm5
   213f8:	66 41 0f 28 30       	movapd (%r8),%xmm6
   213fd:	66 41 0f 28 78 10    	movapd 0x10(%r8),%xmm7
   21403:	66 0f 58 de          	addpd  %xmm6,%xmm3
   21407:	66 0f 58 d7          	addpd  %xmm7,%xmm2
   2140b:	66 44 0f 28 c3       	movapd %xmm3,%xmm8
   21410:	66 44 0f 5c c4       	subpd  %xmm4,%xmm8
   21415:	66 44 0f 28 ca       	movapd %xmm2,%xmm9
   2141a:	66 44 0f 5c cd       	subpd  %xmm5,%xmm9
   2141f:	66 44 0f 28 d3       	movapd %xmm3,%xmm10
   21424:	66 45 0f 5c d0       	subpd  %xmm8,%xmm10
   21429:	66 44 0f 28 da       	movapd %xmm2,%xmm11
   2142e:	66 45 0f 5c d9       	subpd  %xmm9,%xmm11
   21433:	66 41 0f 5c e2       	subpd  %xmm10,%xmm4
   21438:	66 41 0f 5c eb       	subpd  %xmm11,%xmm5
   2143d:	66 41 0f 5c f0       	subpd  %xmm8,%xmm6
   21442:	66 0f 58 f4          	addpd  %xmm4,%xmm6
   21446:	66 41 0f 5c f9       	subpd  %xmm9,%xmm7
   2144b:	66 0f 58 fd          	addpd  %xmm5,%xmm7
   2144f:	66 41 0f 29 30       	movapd %xmm6,(%r8)
   21454:	66 41 0f 29 78 10    	movapd %xmm7,0x10(%r8)
   2145a:	49 83 c0 20          	add    $0x20,%r8
   2145e:	49 39 f0             	cmp    %rsi,%r8
   21461:	75 8d                	jne    213f0 <gpui_canvas::color::gamut::exact_endpoint_sign::<fearless_simd::generated::sse2::Sse2>+0x380>
   21463:	48 83 ff 10          	cmp    $0x10,%rdi
   21467:	0f 83 45 02 00 00    	jae    216b2 <gpui_canvas::color::gamut::exact_endpoint_sign::<fearless_simd::generated::sse2::Sse2>+0x642>
   2146d:	48 83 c2 20          	add    $0x20,%rdx
   21471:	66 0f 29 1e          	movapd %xmm3,(%rsi)
   21475:	66 0f 29 56 10       	movapd %xmm2,0x10(%rsi)
   2147a:	4d 89 e0             	mov    %r12,%r8
   2147d:	0f 1f 00             	nopl   (%rax)
   21480:	66 0f 28 d0          	movapd %xmm0,%xmm2
   21484:	66 0f 28 d9          	movapd %xmm1,%xmm3
   21488:	66 41 0f 28 20       	movapd (%r8),%xmm4
   2148d:	66 41 0f 28 68 10    	movapd 0x10(%r8),%xmm5
   21493:	66 0f 58 c4          	addpd  %xmm4,%xmm0
   21497:	66 0f 58 cd          	addpd  %xmm5,%xmm1
   2149b:	66 0f 28 f0          	movapd %xmm0,%xmm6
   2149f:	66 0f 5c f2          	subpd  %xmm2,%xmm6
   214a3:	66 0f 28 f9          	movapd %xmm1,%xmm7
   214a7:	66 0f 5c fb          	subpd  %xmm3,%xmm7
   214ab:	66 44 0f 28 c0       	movapd %xmm0,%xmm8
   214b0:	66 44 0f 5c c6       	subpd  %xmm6,%xmm8
   214b5:	66 44 0f 28 c9       	movapd %xmm1,%xmm9
   214ba:	66 44 0f 5c cf       	subpd  %xmm7,%xmm9
   214bf:	66 41 0f 5c d0       	subpd  %xmm8,%xmm2
   214c4:	66 41 0f 5c d9       	subpd  %xmm9,%xmm3
   214c9:	66 0f 5c e6          	subpd  %xmm6,%xmm4
   214cd:	66 0f 58 e2          	addpd  %xmm2,%xmm4
   214d1:	66 0f 5c ef          	subpd  %xmm7,%xmm5
   214d5:	66 0f 58 eb          	addpd  %xmm3,%xmm5
   214d9:	66 41 0f 29 20       	movapd %xmm4,(%r8)
   214de:	66 41 0f 29 68 10    	movapd %xmm5,0x10(%r8)
   214e4:	49 39 f0             	cmp    %rsi,%r8
   214e7:	4d 8d 40 20          	lea    0x20(%r8),%r8
   214eb:	75 93                	jne    21480 <gpui_canvas::color::gamut::exact_endpoint_sign::<fearless_simd::generated::sse2::Sse2>+0x410>
   214ed:	66 0f 29 46 20       	movapd %xmm0,0x20(%rsi)
   214f2:	66 0f 29 4e 30       	movapd %xmm1,0x30(%rsi)
   214f7:	4c 8d 6f 02          	lea    0x2(%rdi),%r13
   214fb:	48 8d 70 01          	lea    0x1(%rax),%rsi
   214ff:	48 39 ca             	cmp    %rcx,%rdx
   21502:	0f 85 f8 fd ff ff    	jne    21300 <gpui_canvas::color::gamut::exact_endpoint_sign::<fearless_simd::generated::sse2::Sse2>+0x290>
   21508:	4c 89 e9             	mov    %r13,%rcx
   2150b:	48 c1 e1 05          	shl    $0x5,%rcx
   2150f:	48 01 e1             	add    %rsp,%rcx
   21512:	48 81 c1 00 02 00 00 	add    $0x200,%rcx
   21519:	4c 89 e2             	mov    %r12,%rdx
   2151c:	66 44 0f 28 84 24 d0 	movapd 0xd0(%rsp),%xmm8
   21523:	00 00 00 
   21526:	66 44 0f 28 8c 24 c0 	movapd 0xc0(%rsp),%xmm9
   2152d:	00 00 00 
   21530:	66 41 0f 28 c1       	movapd %xmm9,%xmm0
   21535:	66 41 0f 28 c8       	movapd %xmm8,%xmm1
   2153a:	66 0f 28 12          	movapd (%rdx),%xmm2
   2153e:	66 0f 28 5a 10       	movapd 0x10(%rdx),%xmm3
   21543:	66 44 0f 58 c2       	addpd  %xmm2,%xmm8
   21548:	66 44 0f 58 cb       	addpd  %xmm3,%xmm9
   2154d:	66 41 0f 28 e0       	movapd %xmm8,%xmm4
   21552:	66 0f 5c e1          	subpd  %xmm1,%xmm4
   21556:	66 41 0f 28 e9       	movapd %xmm9,%xmm5
   2155b:	66 0f 5c e8          	subpd  %xmm0,%xmm5
   2155f:	66 41 0f 28 f0       	movapd %xmm8,%xmm6
   21564:	66 0f 5c f4          	subpd  %xmm4,%xmm6
   21568:	66 41 0f 28 f9       	movapd %xmm9,%xmm7
   2156d:	66 0f 5c fd          	subpd  %xmm5,%xmm7
   21571:	66 0f 5c ce          	subpd  %xmm6,%xmm1
   21575:	66 0f 5c c7          	subpd  %xmm7,%xmm0
   21579:	66 0f 5c d4          	subpd  %xmm4,%xmm2
   2157d:	66 0f 58 d1          	addpd  %xmm1,%xmm2
   21581:	66 0f 5c dd          	subpd  %xmm5,%xmm3
   21585:	66 0f 58 d8          	addpd  %xmm0,%xmm3
   21589:	66 0f 29 12          	movapd %xmm2,(%rdx)
   2158d:	66 0f 29 5a 10       	movapd %xmm3,0x10(%rdx)
   21592:	48 83 c2 20          	add    $0x20,%rdx
   21596:	48 39 ca             	cmp    %rcx,%rdx
   21599:	75 95                	jne    21530 <gpui_canvas::color::gamut::exact_endpoint_sign::<fearless_simd::generated::sse2::Sse2>+0x4c0>
   2159b:	48 83 ff 0e          	cmp    $0xe,%rdi
   2159f:	0f 83 1f 01 00 00    	jae    216c4 <gpui_canvas::color::gamut::exact_endpoint_sign::<fearless_simd::generated::sse2::Sse2>+0x654>
   215a5:	66 44 0f 29 01       	movapd %xmm8,(%rcx)
   215aa:	66 44 0f 29 49 10    	movapd %xmm9,0x10(%rcx)
   215b0:	49 83 cd 01          	or     $0x1,%r13
   215b4:	48 83 fb 03          	cmp    $0x3,%rbx
   215b8:	0f 85 c2 fc ff ff    	jne    21280 <gpui_canvas::color::gamut::exact_endpoint_sign::<fearless_simd::generated::sse2::Sse2>+0x210>
   215be:	66 0f 28 9c 24 00 02 	movapd 0x200(%rsp),%xmm3
   215c5:	00 00 
   215c7:	66 0f 28 a4 24 10 02 	movapd 0x210(%rsp),%xmm4
   215ce:	00 00 
   215d0:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   215d4:	66 0f 28 d3          	movapd %xmm3,%xmm2
   215d8:	66 0f c2 d1 04       	cmpneqpd %xmm1,%xmm2
   215dd:	66 0f 28 c4          	movapd %xmm4,%xmm0
   215e1:	66 0f c2 c1 04       	cmpneqpd %xmm1,%xmm0
   215e6:	66 0f 54 d3          	andpd  %xmm3,%xmm2
   215ea:	66 0f 54 c4          	andpd  %xmm4,%xmm0
   215ee:	48 f7 d0             	not    %rax
   215f1:	48 c1 e0 06          	shl    $0x6,%rax
   215f5:	75 0a                	jne    21601 <gpui_canvas::color::gamut::exact_endpoint_sign::<fearless_simd::generated::sse2::Sse2>+0x591>
   215f7:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
   215fc:	e9 99 00 00 00       	jmp    2169a <gpui_canvas::color::gamut::exact_endpoint_sign::<fearless_simd::generated::sse2::Sse2>+0x62a>
   21601:	49 c1 e5 05          	shl    $0x5,%r13
   21605:	4a 8d 04 2c          	lea    (%rsp,%r13,1),%rax
   21609:	48 05 00 02 00 00    	add    $0x200,%rax
   2160f:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
   21614:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   2161b:	00 00 00 00 00 
   21620:	66 41 0f 28 1e       	movapd (%r14),%xmm3
   21625:	66 41 0f 28 66 10    	movapd 0x10(%r14),%xmm4
   2162b:	66 41 0f 28 6e 20    	movapd 0x20(%r14),%xmm5
   21631:	66 41 0f 28 76 30    	movapd 0x30(%r14),%xmm6
   21637:	66 0f 28 fb          	movapd %xmm3,%xmm7
   2163b:	66 0f c2 f9 04       	cmpneqpd %xmm1,%xmm7
   21640:	66 44 0f 28 c4       	movapd %xmm4,%xmm8
   21645:	66 44 0f c2 c1 04    	cmpneqpd %xmm1,%xmm8
   2164b:	66 0f 54 df          	andpd  %xmm7,%xmm3
   2164f:	66 0f 55 fa          	andnpd %xmm2,%xmm7
   21653:	66 0f 56 fb          	orpd   %xmm3,%xmm7
   21657:	66 41 0f 54 e0       	andpd  %xmm8,%xmm4
   2165c:	66 44 0f 55 c0       	andnpd %xmm0,%xmm8
   21661:	66 44 0f 56 c4       	orpd   %xmm4,%xmm8
   21666:	66 0f 28 d5          	movapd %xmm5,%xmm2
   2166a:	66 0f c2 d1 04       	cmpneqpd %xmm1,%xmm2
   2166f:	66 0f 28 c6          	movapd %xmm6,%xmm0
   21673:	66 0f c2 c1 04       	cmpneqpd %xmm1,%xmm0
   21678:	66 0f 54 ea          	andpd  %xmm2,%xmm5
   2167c:	66 0f 55 d7          	andnpd %xmm7,%xmm2
   21680:	66 0f 56 d5          	orpd   %xmm5,%xmm2
   21684:	66 0f 54 f0          	andpd  %xmm0,%xmm6
   21688:	66 41 0f 55 c0       	andnpd %xmm8,%xmm0
   2168d:	66 0f 56 c6          	orpd   %xmm6,%xmm0
   21691:	49 83 c6 40          	add    $0x40,%r14
   21695:	49 39 c6             	cmp    %rax,%r14
   21698:	75 86                	jne    21620 <gpui_canvas::color::gamut::exact_endpoint_sign::<fearless_simd::generated::sse2::Sse2>+0x5b0>
   2169a:	66 0f 29 11          	movapd %xmm2,(%rcx)
   2169e:	66 0f 29 41 10       	movapd %xmm0,0x10(%rcx)
   216a3:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
   216a7:	5b                   	pop    %rbx
   216a8:	41 5c                	pop    %r12
   216aa:	41 5d                	pop    %r13
   216ac:	41 5e                	pop    %r14
   216ae:	41 5f                	pop    %r15
   216b0:	5d                   	pop    %rbp
   216b1:	c3                   	ret
   216b2:	48 8d 15 27 1b 04 00 	lea    0x41b27(%rip),%rdx        # 631e0 <__frame_dummy_init_array_entry+0x250>
   216b9:	be 10 00 00 00       	mov    $0x10,%esi
   216be:	ff 15 74 3b 04 00    	call   *0x43b74(%rip)        # 65238 <_DYNAMIC+0x2f8>
   216c4:	48 8d 15 15 1b 04 00 	lea    0x41b15(%rip),%rdx        # 631e0 <__frame_dummy_init_array_entry+0x250>
   216cb:	be 10 00 00 00       	mov    $0x10,%esi
   216d0:	4c 89 ef             	mov    %r13,%rdi
   216d3:	ff 15 5f 3b 04 00    	call   *0x43b5f(%rip)        # 65238 <_DYNAMIC+0x2f8>
   216d9:	cc                   	int3
   216da:	cc                   	int3
   216db:	cc                   	int3
   216dc:	cc                   	int3
   216dd:	cc                   	int3
   216de:	cc                   	int3
   216df:	cc                   	int3

gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>:
   216e0:	55                   	push   %rbp
   216e1:	48 89 e5             	mov    %rsp,%rbp
   216e4:	41 57                	push   %r15
   216e6:	41 56                	push   %r14
   216e8:	41 55                	push   %r13
   216ea:	41 54                	push   %r12
   216ec:	53                   	push   %rbx
   216ed:	48 83 e4 e0          	and    $0xffffffffffffffe0,%rsp
   216f1:	48 81 ec 40 02 00 00 	sub    $0x240,%rsp
   216f8:	f3 0f 11 44 24 1c    	movss  %xmm0,0x1c(%rsp)
   216fe:	89 fb                	mov    %edi,%ebx
   21700:	0f 29 8c 24 f0 00 00 	movaps %xmm1,0xf0(%rsp)
   21707:	00 
   21708:	0f 57 c0             	xorps  %xmm0,%xmm0
   2170b:	f3 0f 5a c1          	cvtss2sd %xmm1,%xmm0
   2170f:	f2 0f 59 05 c9 5c fe 	mulsd  -0x1a337(%rip),%xmm0        # 73e0 <std::thread::current::id::ID+0x6768>
   21716:	ff 
   21717:	48 8d bc 24 08 01 00 	lea    0x108(%rsp),%rdi
   2171e:	00 
   2171f:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
   21726:	00 
   21727:	ff 15 bb 3b 04 00    	call   *0x43bbb(%rip)        # 652e8 <sincos@GLIBC_2.2.5>
   2172d:	f2 0f 10 84 24 08 01 	movsd  0x108(%rsp),%xmm0
   21734:	00 00 
   21736:	f2 0f 10 8c 24 00 01 	movsd  0x100(%rsp),%xmm1
   2173d:	00 00 
   2173f:	f2 0f 10 15 71 5c fe 	movsd  -0x1a38f(%rip),%xmm2        # 73b8 <std::thread::current::id::ID+0x6740>
   21746:	ff 
   21747:	f2 0f 59 d1          	mulsd  %xmm1,%xmm2
   2174b:	66 0f 57 db          	xorpd  %xmm3,%xmm3
   2174f:	f2 0f 58 d3          	addsd  %xmm3,%xmm2
   21753:	f2 0f 10 25 b5 5b fe 	movsd  -0x1a44b(%rip),%xmm4        # 7310 <std::thread::current::id::ID+0x6698>
   2175a:	ff 
   2175b:	f2 0f 59 e1          	mulsd  %xmm1,%xmm4
   2175f:	f2 0f 58 e3          	addsd  %xmm3,%xmm4
   21763:	f2 0f 10 3d e5 5b fe 	movsd  -0x1a41b(%rip),%xmm7        # 7350 <std::thread::current::id::ID+0x66d8>
   2176a:	ff 
   2176b:	f2 0f 59 f8          	mulsd  %xmm0,%xmm7
   2176f:	f2 0f 58 fa          	addsd  %xmm2,%xmm7
   21773:	f2 0f 10 2d 9d 5c fe 	movsd  -0x1a363(%rip),%xmm5        # 7418 <std::thread::current::id::ID+0x67a0>
   2177a:	ff 
   2177b:	f2 0f 59 e8          	mulsd  %xmm0,%xmm5
   2177f:	f2 0f 58 ec          	addsd  %xmm4,%xmm5
   21783:	f2 0f 59 0d 15 5c fe 	mulsd  -0x1a3eb(%rip),%xmm1        # 73a0 <std::thread::current::id::ID+0x6728>
   2178a:	ff 
   2178b:	f2 0f 58 cb          	addsd  %xmm3,%xmm1
   2178f:	f2 0f 59 05 61 5a fe 	mulsd  -0x1a59f(%rip),%xmm0        # 71f8 <std::thread::current::id::ID+0x6580>
   21796:	ff 
   21797:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
   2179b:	85 db                	test   %ebx,%ebx
   2179d:	74 34                	je     217d3 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xf3>
   2179f:	66 0f 28 15 39 3b fe 	movapd -0x1c4c7(%rip),%xmm2        # 52e0 <std::thread::current::id::ID+0x4668>
   217a6:	ff 
   217a7:	66 0f 28 0d 31 40 fe 	movapd -0x1bfcf(%rip),%xmm1        # 57e0 <std::thread::current::id::ID+0x4b68>
   217ae:	ff 
   217af:	66 44 0f 28 1d c8 40 	movapd -0x1bf38(%rip),%xmm11        # 5880 <std::thread::current::id::ID+0x4c08>
   217b6:	fe ff 
   217b8:	f3 0f 7e 1d 90 5a fe 	movq   -0x1a570(%rip),%xmm3        # 7250 <std::thread::current::id::ID+0x65d8>
   217bf:	ff 
   217c0:	f3 0f 7e 35 68 5b fe 	movq   -0x1a498(%rip),%xmm6        # 7330 <std::thread::current::id::ID+0x66b8>
   217c7:	ff 
   217c8:	f3 44 0f 7e 05 87 5a 	movq   -0x1a579(%rip),%xmm8        # 7258 <std::thread::current::id::ID+0x65e0>
   217cf:	fe ff 
   217d1:	eb 32                	jmp    21805 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x125>
   217d3:	66 0f 28 15 e5 3d fe 	movapd -0x1c21b(%rip),%xmm2        # 55c0 <std::thread::current::id::ID+0x4948>
   217da:	ff 
   217db:	66 0f 28 0d cd 3e fe 	movapd -0x1c133(%rip),%xmm1        # 56b0 <std::thread::current::id::ID+0x4a38>
   217e2:	ff 
   217e3:	66 44 0f 28 1d 54 3d 	movapd -0x1c2ac(%rip),%xmm11        # 5540 <std::thread::current::id::ID+0x48c8>
   217ea:	fe ff 
   217ec:	f3 0f 7e 1d 8c 5b fe 	movq   -0x1a474(%rip),%xmm3        # 7380 <std::thread::current::id::ID+0x6708>
   217f3:	ff 
   217f4:	f3 0f 7e 35 74 5b fe 	movq   -0x1a48c(%rip),%xmm6        # 7370 <std::thread::current::id::ID+0x66f8>
   217fb:	ff 
   217fc:	f3 44 0f 7e 05 e3 5a 	movq   -0x1a51d(%rip),%xmm8        # 72e8 <std::thread::current::id::ID+0x6670>
   21803:	fe ff 
   21805:	f3 0f 7e e3          	movq   %xmm3,%xmm4
   21809:	f3 0f 7e f6          	movq   %xmm6,%xmm6
   2180d:	f3 41 0f 7e d8       	movq   %xmm8,%xmm3
   21812:	66 0f 14 fd          	unpcklpd %xmm5,%xmm7
   21816:	66 0f 28 ef          	movapd %xmm7,%xmm5
   2181a:	66 0f 59 ef          	mulpd  %xmm7,%xmm5
   2181e:	66 44 0f 28 c0       	movapd %xmm0,%xmm8
   21823:	f2 44 0f 59 c0       	mulsd  %xmm0,%xmm8
   21828:	f2 44 0f 59 c0       	mulsd  %xmm0,%xmm8
   2182d:	66 0f 59 ef          	mulpd  %xmm7,%xmm5
   21831:	66 0f 29 6c 24 40    	movapd %xmm5,0x40(%rsp)
   21837:	f2 44 0f 11 44 24 50 	movsd  %xmm8,0x50(%rsp)
   2183e:	f2 0f 10 6c 24 40    	movsd  0x40(%rsp),%xmm5
   21844:	66 0f 14 ed          	unpcklpd %xmm5,%xmm5
   21848:	66 44 0f 28 c2       	movapd %xmm2,%xmm8
   2184d:	66 44 0f 59 c5       	mulpd  %xmm5,%xmm8
   21852:	66 0f 59 ec          	mulpd  %xmm4,%xmm5
   21856:	66 44 0f 10 64 24 48 	movupd 0x48(%rsp),%xmm12
   2185d:	66 45 0f 28 cc       	movapd %xmm12,%xmm9
   21862:	66 45 0f 14 cc       	unpcklpd %xmm12,%xmm9
   21867:	66 44 0f 28 d1       	movapd %xmm1,%xmm10
   2186c:	66 45 0f 59 d1       	mulpd  %xmm9,%xmm10
   21871:	66 45 0f 58 d0       	addpd  %xmm8,%xmm10
   21876:	66 44 0f 59 ce       	mulpd  %xmm6,%xmm9
   2187b:	66 44 0f 58 cd       	addpd  %xmm5,%xmm9
   21880:	66 45 0f 15 e4       	unpckhpd %xmm12,%xmm12
   21885:	66 41 0f 28 eb       	movapd %xmm11,%xmm5
   2188a:	66 41 0f 59 ec       	mulpd  %xmm12,%xmm5
   2188f:	66 41 0f 58 ea       	addpd  %xmm10,%xmm5
   21894:	66 44 0f 28 f5       	movapd %xmm5,%xmm14
   21899:	66 0f 29 ac 24 60 01 	movapd %xmm5,0x160(%rsp)
   218a0:	00 00 
   218a2:	66 44 0f 59 e3       	mulpd  %xmm3,%xmm12
   218a7:	66 45 0f 58 e1       	addpd  %xmm9,%xmm12
   218ac:	66 44 0f 29 64 24 30 	movapd %xmm12,0x30(%rsp)
   218b3:	66 0f 28 2d 45 3b fe 	movapd -0x1c4bb(%rip),%xmm5        # 5400 <std::thread::current::id::ID+0x4788>
   218ba:	ff 
   218bb:	66 44 0f 28 c7       	movapd %xmm7,%xmm8
   218c0:	66 44 0f 59 c5       	mulpd  %xmm5,%xmm8
   218c5:	f2 44 0f 10 0d 52 5a 	movsd  -0x1a5ae(%rip),%xmm9        # 7320 <std::thread::current::id::ID+0x66a8>
   218cc:	fe ff 
   218ce:	f2 44 0f 59 c8       	mulsd  %xmm0,%xmm9
   218d3:	f2 41 0f 59 c1       	mulsd  %xmm9,%xmm0
   218d8:	66 41 0f 59 f8       	mulpd  %xmm8,%xmm7
   218dd:	66 0f 29 7c 24 40    	movapd %xmm7,0x40(%rsp)
   218e3:	f2 0f 11 44 24 50    	movsd  %xmm0,0x50(%rsp)
   218e9:	f2 0f 10 44 24 40    	movsd  0x40(%rsp),%xmm0
   218ef:	66 0f 14 c0          	unpcklpd %xmm0,%xmm0
   218f3:	66 0f 28 fa          	movapd %xmm2,%xmm7
   218f7:	66 0f 59 f8          	mulpd  %xmm0,%xmm7
   218fb:	66 0f 59 c4          	mulpd  %xmm4,%xmm0
   218ff:	66 44 0f 10 6c 24 48 	movupd 0x48(%rsp),%xmm13
   21906:	66 45 0f 28 d5       	movapd %xmm13,%xmm10
   2190b:	66 45 0f 14 d5       	unpcklpd %xmm13,%xmm10
   21910:	66 45 0f 28 e3       	movapd %xmm11,%xmm12
   21915:	66 44 0f 28 d9       	movapd %xmm1,%xmm11
   2191a:	66 45 0f 59 da       	mulpd  %xmm10,%xmm11
   2191f:	66 44 0f 58 df       	addpd  %xmm7,%xmm11
   21924:	66 44 0f 59 d6       	mulpd  %xmm6,%xmm10
   21929:	66 44 0f 58 d0       	addpd  %xmm0,%xmm10
   2192e:	66 45 0f 15 ed       	unpckhpd %xmm13,%xmm13
   21933:	66 41 0f 28 c4       	movapd %xmm12,%xmm0
   21938:	66 41 0f 59 c5       	mulpd  %xmm13,%xmm0
   2193d:	66 41 0f 58 c3       	addpd  %xmm11,%xmm0
   21942:	66 44 0f 28 d8       	movapd %xmm0,%xmm11
   21947:	66 0f 29 84 24 40 01 	movapd %xmm0,0x140(%rsp)
   2194e:	00 00 
   21950:	66 44 0f 59 eb       	mulpd  %xmm3,%xmm13
   21955:	66 45 0f 58 ea       	addpd  %xmm10,%xmm13
   2195a:	66 44 0f 29 ac 24 50 	movapd %xmm13,0x150(%rsp)
   21961:	01 00 00 
   21964:	66 44 0f 29 44 24 40 	movapd %xmm8,0x40(%rsp)
   2196b:	f2 44 0f 11 4c 24 50 	movsd  %xmm9,0x50(%rsp)
   21972:	f2 0f 10 44 24 40    	movsd  0x40(%rsp),%xmm0
   21978:	66 0f 14 c0          	unpcklpd %xmm0,%xmm0
   2197c:	66 0f 28 fa          	movapd %xmm2,%xmm7
   21980:	66 0f 59 f8          	mulpd  %xmm0,%xmm7
   21984:	66 0f 59 c4          	mulpd  %xmm4,%xmm0
   21988:	66 44 0f 10 54 24 48 	movupd 0x48(%rsp),%xmm10
   2198f:	66 45 0f 28 c2       	movapd %xmm10,%xmm8
   21994:	66 45 0f 14 c2       	unpcklpd %xmm10,%xmm8
   21999:	66 44 0f 28 c9       	movapd %xmm1,%xmm9
   2199e:	66 45 0f 59 c8       	mulpd  %xmm8,%xmm9
   219a3:	66 44 0f 58 cf       	addpd  %xmm7,%xmm9
   219a8:	66 44 0f 59 c6       	mulpd  %xmm6,%xmm8
   219ad:	66 44 0f 58 c0       	addpd  %xmm0,%xmm8
   219b2:	66 45 0f 15 d2       	unpckhpd %xmm10,%xmm10
   219b7:	66 41 0f 28 c4       	movapd %xmm12,%xmm0
   219bc:	66 41 0f 59 c2       	mulpd  %xmm10,%xmm0
   219c1:	66 41 0f 58 c1       	addpd  %xmm9,%xmm0
   219c6:	66 44 0f 28 c8       	movapd %xmm0,%xmm9
   219cb:	66 0f 29 84 24 20 01 	movapd %xmm0,0x120(%rsp)
   219d2:	00 00 
   219d4:	66 44 0f 59 d3       	mulpd  %xmm3,%xmm10
   219d9:	66 45 0f 58 d0       	addpd  %xmm8,%xmm10
   219de:	66 44 0f 29 94 24 30 	movapd %xmm10,0x130(%rsp)
   219e5:	01 00 00 
   219e8:	0f 28 05 e1 3c fe ff 	movaps -0x1c31f(%rip),%xmm0        # 56d0 <std::thread::current::id::ID+0x4a58>
   219ef:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
   219f4:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
   219fb:	00 f0 3f 
   219fe:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   21a03:	66 0f 10 44 24 48    	movupd 0x48(%rsp),%xmm0
   21a09:	66 0f 28 f8          	movapd %xmm0,%xmm7
   21a0d:	66 0f 14 f8          	unpcklpd %xmm0,%xmm7
   21a11:	66 0f 59 cf          	mulpd  %xmm7,%xmm1
   21a15:	66 0f 59 fe          	mulpd  %xmm6,%xmm7
   21a19:	66 0f 58 ca          	addpd  %xmm2,%xmm1
   21a1d:	66 0f 58 fc          	addpd  %xmm4,%xmm7
   21a21:	66 0f 15 c0          	unpckhpd %xmm0,%xmm0
   21a25:	66 44 0f 59 e0       	mulpd  %xmm0,%xmm12
   21a2a:	66 44 0f 58 e1       	addpd  %xmm1,%xmm12
   21a2f:	66 44 0f 29 a4 24 70 	movapd %xmm12,0x170(%rsp)
   21a36:	01 00 00 
   21a39:	66 0f 59 c3          	mulpd  %xmm3,%xmm0
   21a3d:	66 0f 58 c7          	addpd  %xmm7,%xmm0
   21a41:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   21a45:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   21a49:	66 0f 16 0d 5f 58 fe 	movhpd -0x1a7a1(%rip),%xmm1        # 72b0 <std::thread::current::id::ID+0x6638>
   21a50:	ff 
   21a51:	66 0f 58 c8          	addpd  %xmm0,%xmm1
   21a55:	66 0f 29 8c 24 10 01 	movapd %xmm1,0x110(%rsp)
   21a5c:	00 00 
   21a5e:	66 44 0f 59 f5       	mulpd  %xmm5,%xmm14
   21a63:	66 0f 59 6c 24 30    	mulpd  0x30(%rsp),%xmm5
   21a69:	66 44 0f 28 e5       	movapd %xmm5,%xmm12
   21a6e:	66 45 0f 58 db       	addpd  %xmm11,%xmm11
   21a73:	66 45 0f 58 ed       	addpd  %xmm13,%xmm13
   21a78:	66 41 0f 28 f3       	movapd %xmm11,%xmm6
   21a7d:	66 41 0f 59 f3       	mulpd  %xmm11,%xmm6
   21a82:	66 41 0f 28 c6       	movapd %xmm14,%xmm0
   21a87:	66 41 0f 59 c1       	mulpd  %xmm9,%xmm0
   21a8c:	66 0f 28 0d dc 39 fe 	movapd -0x1c624(%rip),%xmm1        # 5470 <std::thread::current::id::ID+0x47f8>
   21a93:	ff 
   21a94:	66 0f 59 c1          	mulpd  %xmm1,%xmm0
   21a98:	66 0f 5c f0          	subpd  %xmm0,%xmm6
   21a9c:	66 0f 28 c5          	movapd %xmm5,%xmm0
   21aa0:	66 41 0f 59 c2       	mulpd  %xmm10,%xmm0
   21aa5:	66 0f 59 c1          	mulpd  %xmm1,%xmm0
   21aa9:	66 41 0f 28 fd       	movapd %xmm13,%xmm7
   21aae:	66 41 0f 59 fd       	mulpd  %xmm13,%xmm7
   21ab3:	66 0f 5c f8          	subpd  %xmm0,%xmm7
   21ab7:	66 45 0f 28 cb       	movapd %xmm11,%xmm9
   21abc:	66 44 0f c2 ca 01    	cmpltpd %xmm2,%xmm9
   21ac2:	66 0f 28 05 c6 3d fe 	movapd -0x1c23a(%rip),%xmm0        # 5890 <std::thread::current::id::ID+0x4c18>
   21ac9:	ff 
   21aca:	66 45 0f 28 c1       	movapd %xmm9,%xmm8
   21acf:	66 44 0f 54 c0       	andpd  %xmm0,%xmm8
   21ad4:	66 0f 28 0d f4 3b fe 	movapd -0x1c40c(%rip),%xmm1        # 56d0 <std::thread::current::id::ID+0x4a58>
   21adb:	ff 
   21adc:	66 44 0f 55 c9       	andnpd %xmm1,%xmm9
   21ae1:	66 45 0f 56 c8       	orpd   %xmm8,%xmm9
   21ae6:	66 45 0f 28 d5       	movapd %xmm13,%xmm10
   21aeb:	66 44 0f c2 d2 01    	cmpltpd %xmm2,%xmm10
   21af1:	66 41 0f 54 c2       	andpd  %xmm10,%xmm0
   21af6:	66 44 0f 55 d1       	andnpd %xmm1,%xmm10
   21afb:	66 44 0f 28 c1       	movapd %xmm1,%xmm8
   21b00:	66 44 0f 56 d0       	orpd   %xmm0,%xmm10
   21b05:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
   21b09:	66 0f c2 c6 02       	cmplepd %xmm6,%xmm0
   21b0e:	66 0f 29 44 24 20    	movapd %xmm0,0x20(%rsp)
   21b14:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   21b18:	66 0f 5f f1          	maxpd  %xmm1,%xmm6
   21b1c:	66 0f 51 f6          	sqrtpd %xmm6,%xmm6
   21b20:	66 41 0f 59 f1       	mulpd  %xmm9,%xmm6
   21b25:	66 0f 57 e4          	xorpd  %xmm4,%xmm4
   21b29:	66 0f c2 e7 02       	cmplepd %xmm7,%xmm4
   21b2e:	66 0f 5f f9          	maxpd  %xmm1,%xmm7
   21b32:	66 0f 51 ff          	sqrtpd %xmm7,%xmm7
   21b36:	66 41 0f 59 fa       	mulpd  %xmm10,%xmm7
   21b3b:	66 41 0f 28 eb       	movapd %xmm11,%xmm5
   21b40:	66 41 0f 58 f3       	addpd  %xmm11,%xmm6
   21b45:	66 41 0f 58 fd       	addpd  %xmm13,%xmm7
   21b4a:	66 0f 28 05 4e 3d fe 	movapd -0x1c2b2(%rip),%xmm0        # 58a0 <std::thread::current::id::ID+0x4c28>
   21b51:	ff 
   21b52:	66 0f 59 f0          	mulpd  %xmm0,%xmm6
   21b56:	66 0f 59 f8          	mulpd  %xmm0,%xmm7
   21b5a:	66 45 0f 28 de       	movapd %xmm14,%xmm11
   21b5f:	66 44 0f c2 d9 00    	cmpeqpd %xmm1,%xmm11
   21b65:	66 0f 28 d5          	movapd %xmm5,%xmm2
   21b69:	66 0f c2 d1 00       	cmpeqpd %xmm1,%xmm2
   21b6e:	66 44 0f 28 fa       	movapd %xmm2,%xmm15
   21b73:	66 0f 55 d5          	andnpd %xmm5,%xmm2
   21b77:	66 0f c2 e9 04       	cmpneqpd %xmm1,%xmm5
   21b7c:	66 0f 57 db          	xorpd  %xmm3,%xmm3
   21b80:	66 41 0f 54 eb       	andpd  %xmm11,%xmm5
   21b85:	66 0f 29 ac 24 90 01 	movapd %xmm5,0x190(%rsp)
   21b8c:	00 00 
   21b8e:	66 41 0f 28 cb       	movapd %xmm11,%xmm1
   21b93:	66 45 0f 28 c8       	movapd %xmm8,%xmm9
   21b98:	66 45 0f 54 d8       	andpd  %xmm8,%xmm11
   21b9d:	66 41 0f 55 ce       	andnpd %xmm14,%xmm1
   21ba2:	66 41 0f 56 cb       	orpd   %xmm11,%xmm1
   21ba7:	66 41 0f 28 ec       	movapd %xmm12,%xmm5
   21bac:	66 45 0f 28 dc       	movapd %xmm12,%xmm11
   21bb1:	66 44 0f c2 db 00    	cmpeqpd %xmm3,%xmm11
   21bb7:	66 41 0f 28 c5       	movapd %xmm13,%xmm0
   21bbc:	66 45 0f 28 d5       	movapd %xmm13,%xmm10
   21bc1:	66 44 0f c2 d3 00    	cmpeqpd %xmm3,%xmm10
   21bc7:	66 45 0f 28 ea       	movapd %xmm10,%xmm13
   21bcc:	66 44 0f 55 d0       	andnpd %xmm0,%xmm10
   21bd1:	66 0f c2 c3 04       	cmpneqpd %xmm3,%xmm0
   21bd6:	66 41 0f 54 c3       	andpd  %xmm11,%xmm0
   21bdb:	66 0f 29 84 24 a0 01 	movapd %xmm0,0x1a0(%rsp)
   21be2:	00 00 
   21be4:	66 41 0f 28 c3       	movapd %xmm11,%xmm0
   21be9:	66 45 0f 54 d8       	andpd  %xmm8,%xmm11
   21bee:	66 41 0f 55 c4       	andnpd %xmm12,%xmm0
   21bf3:	66 41 0f 56 c3       	orpd   %xmm11,%xmm0
   21bf8:	66 44 0f 28 c6       	movapd %xmm6,%xmm8
   21bfd:	66 44 0f c2 c3 00    	cmpeqpd %xmm3,%xmm8
   21c03:	66 45 0f 28 e0       	movapd %xmm8,%xmm12
   21c08:	66 45 0f 54 e1       	andpd  %xmm9,%xmm12
   21c0d:	66 44 0f 55 c6       	andnpd %xmm6,%xmm8
   21c12:	66 45 0f 56 c4       	orpd   %xmm12,%xmm8
   21c17:	66 44 0f 29 84 24 d0 	movapd %xmm8,0x1d0(%rsp)
   21c1e:	01 00 00 
   21c21:	66 44 0f 28 df       	movapd %xmm7,%xmm11
   21c26:	66 44 0f c2 db 00    	cmpeqpd %xmm3,%xmm11
   21c2c:	66 45 0f 28 e3       	movapd %xmm11,%xmm12
   21c31:	66 45 0f 54 e1       	andpd  %xmm9,%xmm12
   21c36:	66 44 0f 55 df       	andnpd %xmm7,%xmm11
   21c3b:	66 45 0f 56 dc       	orpd   %xmm12,%xmm11
   21c40:	66 45 0f 54 f9       	andpd  %xmm9,%xmm15
   21c45:	66 41 0f 56 d7       	orpd   %xmm15,%xmm2
   21c4a:	66 45 0f 54 e9       	andpd  %xmm9,%xmm13
   21c4f:	66 45 0f 56 d5       	orpd   %xmm13,%xmm10
   21c54:	66 45 0f 57 c9       	xorpd  %xmm9,%xmm9
   21c59:	66 45 0f c2 f1 04    	cmpneqpd %xmm9,%xmm14
   21c5f:	66 44 0f 28 44 24 20 	movapd 0x20(%rsp),%xmm8
   21c66:	66 45 0f 54 c6       	andpd  %xmm14,%xmm8
   21c6b:	66 44 0f 29 44 24 20 	movapd %xmm8,0x20(%rsp)
   21c72:	66 41 0f c2 e9 04    	cmpneqpd %xmm9,%xmm5
   21c78:	66 0f 54 e5          	andpd  %xmm5,%xmm4
   21c7c:	66 0f 29 a4 24 c0 01 	movapd %xmm4,0x1c0(%rsp)
   21c83:	00 00 
   21c85:	66 0f 28 de          	movapd %xmm6,%xmm3
   21c89:	66 0f 5e d9          	divpd  %xmm1,%xmm3
   21c8d:	66 0f 29 9c 24 b0 01 	movapd %xmm3,0x1b0(%rsp)
   21c94:	00 00 
   21c96:	66 0f 28 cf          	movapd %xmm7,%xmm1
   21c9a:	66 0f 5e c8          	divpd  %xmm0,%xmm1
   21c9e:	66 0f 29 8c 24 80 01 	movapd %xmm1,0x180(%rsp)
   21ca5:	00 00 
   21ca7:	66 44 0f 28 3d 10 3b 	movapd -0x1c4f0(%rip),%xmm15        # 57c0 <std::thread::current::id::ID+0x4b48>
   21cae:	fe ff 
   21cb0:	66 0f 28 ac 24 60 01 	movapd 0x160(%rsp),%xmm5
   21cb7:	00 00 
   21cb9:	66 0f 28 c5          	movapd %xmm5,%xmm0
   21cbd:	66 41 0f 57 c7       	xorpd  %xmm15,%xmm0
   21cc2:	66 0f 29 44 24 40    	movapd %xmm0,0x40(%rsp)
   21cc8:	66 44 0f 28 4c 24 30 	movapd 0x30(%rsp),%xmm9
   21ccf:	66 41 0f 28 c1       	movapd %xmm9,%xmm0
   21cd4:	66 41 0f 57 c7       	xorpd  %xmm15,%xmm0
   21cd9:	66 0f 29 44 24 50    	movapd %xmm0,0x50(%rsp)
   21cdf:	66 44 0f 28 a4 24 40 	movapd 0x140(%rsp),%xmm12
   21ce6:	01 00 00 
   21ce9:	66 41 0f 28 c4       	movapd %xmm12,%xmm0
   21cee:	66 41 0f 57 c7       	xorpd  %xmm15,%xmm0
   21cf3:	66 0f 29 44 24 60    	movapd %xmm0,0x60(%rsp)
   21cf9:	66 44 0f 28 ac 24 50 	movapd 0x150(%rsp),%xmm13
   21d00:	01 00 00 
   21d03:	66 41 0f 28 c5       	movapd %xmm13,%xmm0
   21d08:	66 41 0f 57 c7       	xorpd  %xmm15,%xmm0
   21d0d:	66 0f 29 44 24 70    	movapd %xmm0,0x70(%rsp)
   21d13:	66 44 0f 28 84 24 20 	movapd 0x120(%rsp),%xmm8
   21d1a:	01 00 00 
   21d1d:	66 41 0f 28 c0       	movapd %xmm8,%xmm0
   21d22:	66 41 0f 57 c7       	xorpd  %xmm15,%xmm0
   21d27:	66 0f 29 84 24 80 00 	movapd %xmm0,0x80(%rsp)
   21d2e:	00 00 
   21d30:	66 0f 5e c2          	divpd  %xmm2,%xmm0
   21d34:	66 44 0f 28 b4 24 30 	movapd 0x130(%rsp),%xmm14
   21d3b:	01 00 00 
   21d3e:	66 41 0f 28 ce       	movapd %xmm14,%xmm1
   21d43:	66 41 0f 57 cf       	xorpd  %xmm15,%xmm1
   21d48:	66 0f 29 8c 24 90 00 	movapd %xmm1,0x90(%rsp)
   21d4f:	00 00 
   21d51:	66 41 0f 5e ca       	divpd  %xmm10,%xmm1
   21d56:	66 0f 28 94 24 90 01 	movapd 0x190(%rsp),%xmm2
   21d5d:	00 00 
   21d5f:	66 0f 54 c2          	andpd  %xmm2,%xmm0
   21d63:	66 44 0f 28 15 14 3a 	movapd -0x1c5ec(%rip),%xmm10        # 5780 <std::thread::current::id::ID+0x4b08>
   21d6a:	fe ff 
   21d6c:	66 41 0f 55 d2       	andnpd %xmm10,%xmm2
   21d71:	66 0f 56 d0          	orpd   %xmm0,%xmm2
   21d75:	66 0f 28 84 24 a0 01 	movapd 0x1a0(%rsp),%xmm0
   21d7c:	00 00 
   21d7e:	66 0f 54 c8          	andpd  %xmm0,%xmm1
   21d82:	66 41 0f 55 c2       	andnpd %xmm10,%xmm0
   21d87:	66 0f 56 c1          	orpd   %xmm1,%xmm0
   21d8b:	66 0f 28 e0          	movapd %xmm0,%xmm4
   21d8f:	66 0f 28 44 24 20    	movapd 0x20(%rsp),%xmm0
   21d95:	66 0f 28 8c 24 b0 01 	movapd 0x1b0(%rsp),%xmm1
   21d9c:	00 00 
   21d9e:	66 0f 54 c8          	andpd  %xmm0,%xmm1
   21da2:	66 0f 57 db          	xorpd  %xmm3,%xmm3
   21da6:	66 0f c2 f3 04       	cmpneqpd %xmm3,%xmm6
   21dab:	66 0f 54 f0          	andpd  %xmm0,%xmm6
   21daf:	66 0f 55 c2          	andnpd %xmm2,%xmm0
   21db3:	66 0f 56 c1          	orpd   %xmm1,%xmm0
   21db7:	66 0f 28 8c 24 c0 01 	movapd 0x1c0(%rsp),%xmm1
   21dbe:	00 00 
   21dc0:	66 0f 28 94 24 80 01 	movapd 0x180(%rsp),%xmm2
   21dc7:	00 00 
   21dc9:	66 0f 54 d1          	andpd  %xmm1,%xmm2
   21dcd:	66 0f c2 fb 04       	cmpneqpd %xmm3,%xmm7
   21dd2:	66 0f 54 f9          	andpd  %xmm1,%xmm7
   21dd6:	66 0f 55 cc          	andnpd %xmm4,%xmm1
   21dda:	66 0f 56 ca          	orpd   %xmm2,%xmm1
   21dde:	66 41 0f 28 d8       	movapd %xmm8,%xmm3
   21de3:	66 0f 5e 9c 24 d0 01 	divpd  0x1d0(%rsp),%xmm3
   21dea:	00 00 
   21dec:	66 41 0f 28 e6       	movapd %xmm14,%xmm4
   21df1:	66 41 0f 5e e3       	divpd  %xmm11,%xmm4
   21df6:	66 0f 54 de          	andpd  %xmm6,%xmm3
   21dfa:	66 41 0f 55 f2       	andnpd %xmm10,%xmm6
   21dff:	66 0f 56 f3          	orpd   %xmm3,%xmm6
   21e03:	66 0f 54 e7          	andpd  %xmm7,%xmm4
   21e07:	66 41 0f 55 fa       	andnpd %xmm10,%xmm7
   21e0c:	66 0f 56 fc          	orpd   %xmm4,%xmm7
   21e10:	66 0f 57 db          	xorpd  %xmm3,%xmm3
   21e14:	66 0f c2 d8 01       	cmpltpd %xmm0,%xmm3
   21e19:	66 0f 54 c3          	andpd  %xmm3,%xmm0
   21e1d:	66 41 0f 55 da       	andnpd %xmm10,%xmm3
   21e22:	66 0f 56 d8          	orpd   %xmm0,%xmm3
   21e26:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
   21e2a:	66 0f c2 c1 01       	cmpltpd %xmm1,%xmm0
   21e2f:	66 0f 54 c8          	andpd  %xmm0,%xmm1
   21e33:	66 41 0f 55 c2       	andnpd %xmm10,%xmm0
   21e38:	66 0f 56 c1          	orpd   %xmm1,%xmm0
   21e3c:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   21e40:	66 0f c2 ce 01       	cmpltpd %xmm6,%xmm1
   21e45:	66 0f 54 f1          	andpd  %xmm1,%xmm6
   21e49:	66 41 0f 55 ca       	andnpd %xmm10,%xmm1
   21e4e:	66 0f 56 ce          	orpd   %xmm6,%xmm1
   21e52:	66 0f 57 e4          	xorpd  %xmm4,%xmm4
   21e56:	66 0f c2 e7 01       	cmpltpd %xmm7,%xmm4
   21e5b:	66 0f 54 fc          	andpd  %xmm4,%xmm7
   21e5f:	66 41 0f 55 e2       	andnpd %xmm10,%xmm4
   21e64:	66 0f 56 e7          	orpd   %xmm7,%xmm4
   21e68:	66 0f 28 f3          	movapd %xmm3,%xmm6
   21e6c:	66 0f 5d f1          	minpd  %xmm1,%xmm6
   21e70:	66 0f 29 b4 24 e0 01 	movapd %xmm6,0x1e0(%rsp)
   21e77:	00 00 
   21e79:	66 0f 28 f0          	movapd %xmm0,%xmm6
   21e7d:	66 0f 5d f4          	minpd  %xmm4,%xmm6
   21e81:	66 0f 5f d9          	maxpd  %xmm1,%xmm3
   21e85:	66 0f 5f c4          	maxpd  %xmm4,%xmm0
   21e89:	66 0f 29 b4 24 f0 01 	movapd %xmm6,0x1f0(%rsp)
   21e90:	00 00 
   21e92:	66 0f 29 9c 24 00 02 	movapd %xmm3,0x200(%rsp)
   21e99:	00 00 
   21e9b:	66 0f 29 84 24 10 02 	movapd %xmm0,0x210(%rsp)
   21ea2:	00 00 
   21ea4:	66 0f 28 25 94 33 fe 	movapd -0x1cc6c(%rip),%xmm4        # 5240 <std::thread::current::id::ID+0x45c8>
   21eab:	ff 
   21eac:	66 41 0f 28 cc       	movapd %xmm12,%xmm1
   21eb1:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
   21eb5:	66 0f c2 c8 04       	cmpneqpd %xmm0,%xmm1
   21eba:	66 41 0f 28 dc       	movapd %xmm12,%xmm3
   21ebf:	66 0f 54 dc          	andpd  %xmm4,%xmm3
   21ec3:	66 41 0f 28 f0       	movapd %xmm8,%xmm6
   21ec8:	66 0f 54 f4          	andpd  %xmm4,%xmm6
   21ecc:	66 0f 28 c1          	movapd %xmm1,%xmm0
   21ed0:	66 0f 54 c3          	andpd  %xmm3,%xmm0
   21ed4:	66 0f 55 ce          	andnpd %xmm6,%xmm1
   21ed8:	66 0f 56 c8          	orpd   %xmm0,%xmm1
   21edc:	66 0f 28 fd          	movapd %xmm5,%xmm7
   21ee0:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
   21ee4:	66 0f c2 f8 04       	cmpneqpd %xmm0,%xmm7
   21ee9:	66 45 0f 28 c1       	movapd %xmm9,%xmm8
   21eee:	66 44 0f c2 c0 04    	cmpneqpd %xmm0,%xmm8
   21ef4:	66 41 0f c2 c5 04    	cmpneqpd %xmm13,%xmm0
   21efa:	66 44 0f 54 ec       	andpd  %xmm4,%xmm13
   21eff:	66 44 0f 54 f4       	andpd  %xmm4,%xmm14
   21f04:	66 44 0f 28 d0       	movapd %xmm0,%xmm10
   21f09:	66 45 0f 54 d5       	andpd  %xmm13,%xmm10
   21f0e:	66 41 0f 55 c6       	andnpd %xmm14,%xmm0
   21f13:	66 41 0f 56 c2       	orpd   %xmm10,%xmm0
   21f18:	66 44 0f 28 d5       	movapd %xmm5,%xmm10
   21f1d:	66 44 0f 54 d4       	andpd  %xmm4,%xmm10
   21f22:	66 44 0f 54 d7       	andpd  %xmm7,%xmm10
   21f27:	66 0f 55 f9          	andnpd %xmm1,%xmm7
   21f2b:	66 41 0f 56 fa       	orpd   %xmm10,%xmm7
   21f30:	66 44 0f 54 cc       	andpd  %xmm4,%xmm9
   21f35:	66 45 0f 54 c8       	andpd  %xmm8,%xmm9
   21f3a:	66 44 0f 55 c0       	andnpd %xmm0,%xmm8
   21f3f:	66 45 0f 56 c1       	orpd   %xmm9,%xmm8
   21f44:	66 0f 28 0d b4 33 fe 	movapd -0x1cc4c(%rip),%xmm1        # 5300 <std::thread::current::id::ID+0x4688>
   21f4b:	ff 
   21f4c:	66 0f 5f f9          	maxpd  %xmm1,%xmm7
   21f50:	66 44 0f 5f c1       	maxpd  %xmm1,%xmm8
   21f55:	66 0f 5f de          	maxpd  %xmm6,%xmm3
   21f59:	66 45 0f 5f ee       	maxpd  %xmm14,%xmm13
   21f5e:	66 0f 28 94 24 70 01 	movapd 0x170(%rsp),%xmm2
   21f65:	00 00 
   21f67:	66 0f 28 ca          	movapd %xmm2,%xmm1
   21f6b:	66 0f 54 cc          	andpd  %xmm4,%xmm1
   21f6f:	66 0f 5f d9          	maxpd  %xmm1,%xmm3
   21f73:	66 0f 5e df          	divpd  %xmm7,%xmm3
   21f77:	66 0f 28 b4 24 10 01 	movapd 0x110(%rsp),%xmm6
   21f7e:	00 00 
   21f80:	66 0f 54 e6          	andpd  %xmm6,%xmm4
   21f84:	66 44 0f 5f ec       	maxpd  %xmm4,%xmm13
   21f89:	66 45 0f 5e e8       	divpd  %xmm8,%xmm13
   21f8e:	f2 0f 10 0d 1a 53 fe 	movsd  -0x1ace6(%rip),%xmm1        # 72b0 <std::thread::current::id::ID+0x6638>
   21f95:	ff 
   21f96:	66 0f 28 05 32 37 fe 	movapd -0x1c8ce(%rip),%xmm0        # 56d0 <std::thread::current::id::ID+0x4a58>
   21f9d:	ff 
   21f9e:	66 0f 58 d8          	addpd  %xmm0,%xmm3
   21fa2:	66 44 0f 58 e8       	addpd  %xmm0,%xmm13
   21fa7:	66 0f c2 c8 00       	cmpeqpd %xmm0,%xmm1
   21fac:	66 0f c2 c0 00       	cmpeqpd %xmm0,%xmm0
   21fb1:	66 0f 54 d8          	andpd  %xmm0,%xmm3
   21fb5:	66 0f 28 25 13 37 fe 	movapd -0x1c8ed(%rip),%xmm4        # 56d0 <std::thread::current::id::ID+0x4a58>
   21fbc:	ff 
   21fbd:	66 0f 55 c4          	andnpd %xmm4,%xmm0
   21fc1:	66 0f 56 c3          	orpd   %xmm3,%xmm0
   21fc5:	66 44 0f 54 e9       	andpd  %xmm1,%xmm13
   21fca:	66 0f 55 cc          	andnpd %xmm4,%xmm1
   21fce:	66 41 0f 56 cd       	orpd   %xmm13,%xmm1
   21fd3:	66 41 0f 57 d7       	xorpd  %xmm15,%xmm2
   21fd8:	66 0f 29 94 24 a0 00 	movapd %xmm2,0xa0(%rsp)
   21fdf:	00 00 
   21fe1:	66 44 0f 57 fe       	xorpd  %xmm6,%xmm15
   21fe6:	66 44 0f 29 bc 24 b0 	movapd %xmm15,0xb0(%rsp)
   21fed:	00 00 00 
   21ff0:	48 8d bc 24 c0 00 00 	lea    0xc0(%rsp),%rdi
   21ff7:	00 
   21ff8:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
   21ffd:	48 8d 94 24 e0 01 00 	lea    0x1e0(%rsp),%rdx
   22004:	00 
   22005:	b9 60 00 00 00       	mov    $0x60,%ecx
   2200a:	e8 c1 e9 ff ff       	call   209d0 <gpui_canvas::color::gamut::first_exit::<fearless_simd::generated::sse2::Sse2>>
   2200f:	f2 0f 10 84 24 c0 00 	movsd  0xc0(%rsp),%xmm0
   22016:	00 00 
   22018:	f2 0f 10 8c 24 c8 00 	movsd  0xc8(%rsp),%xmm1
   2201f:	00 00 
   22021:	f2 0f 10 9c 24 d0 00 	movsd  0xd0(%rsp),%xmm3
   22028:	00 00 
   2202a:	f2 0f 5d 05 2e 52 fe 	minsd  -0x1add2(%rip),%xmm0        # 7260 <std::thread::current::id::ID+0x65e8>
   22031:	ff 
   22032:	f2 0f 5d c8          	minsd  %xmm0,%xmm1
   22036:	f2 0f 5d d9          	minsd  %xmm1,%xmm3
   2203a:	66 48 0f 7e d8       	movq   %xmm3,%rax
   2203f:	49 bf ff ff ff ff ff 	movabs $0x7fffffffffffffff,%r15
   22046:	ff ff 7f 
   22049:	4c 21 f8             	and    %r15,%rax
   2204c:	41 be 0e 00 00 00    	mov    $0xe,%r14d
   22052:	48 b9 ff ff ff ff ff 	movabs $0x7fefffffffffffff,%rcx
   22059:	ff ef 7f 
   2205c:	48 39 c8             	cmp    %rcx,%rax
   2205f:	0f 8f 72 02 00 00    	jg     222d7 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xbf7>
   22065:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
   2206b:	0f 57 c9             	xorps  %xmm1,%xmm1
   2206e:	f3 0f 5a c8          	cvtss2sd %xmm0,%xmm1
   22072:	f2 0f 11 4c 24 20    	movsd  %xmm1,0x20(%rsp)
   22078:	0f 28 c1             	movaps %xmm1,%xmm0
   2207b:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   2207f:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   22083:	f2 0f 10 0d 25 52 fe 	movsd  -0x1addb(%rip),%xmm1        # 72b0 <std::thread::current::id::ID+0x6638>
   2208a:	ff 
   2208b:	f2 0f 5e c8          	divsd  %xmm0,%xmm1
   2208f:	66 0f 14 c9          	unpcklpd %xmm1,%xmm1
   22093:	66 0f 28 84 24 70 01 	movapd 0x170(%rsp),%xmm0
   2209a:	00 00 
   2209c:	66 0f 5c c1          	subpd  %xmm1,%xmm0
   220a0:	66 0f 29 84 24 a0 00 	movapd %xmm0,0xa0(%rsp)
   220a7:	00 00 
   220a9:	66 0f 28 94 24 10 01 	movapd 0x110(%rsp),%xmm2
   220b0:	00 00 
   220b2:	66 0f 5c d1          	subpd  %xmm1,%xmm2
   220b6:	0f 28 84 24 60 01 00 	movaps 0x160(%rsp),%xmm0
   220bd:	00 
   220be:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
   220c3:	0f 28 44 24 30       	movaps 0x30(%rsp),%xmm0
   220c8:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
   220cd:	0f 28 84 24 40 01 00 	movaps 0x140(%rsp),%xmm0
   220d4:	00 
   220d5:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
   220da:	0f 28 84 24 50 01 00 	movaps 0x150(%rsp),%xmm0
   220e1:	00 
   220e2:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
   220e7:	0f 28 84 24 20 01 00 	movaps 0x120(%rsp),%xmm0
   220ee:	00 
   220ef:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
   220f6:	00 
   220f7:	0f 28 84 24 30 01 00 	movaps 0x130(%rsp),%xmm0
   220fe:	00 
   220ff:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
   22106:	00 
   22107:	66 0f 29 94 24 b0 00 	movapd %xmm2,0xb0(%rsp)
   2210e:	00 00 
   22110:	66 0f 28 c3          	movapd %xmm3,%xmm0
   22114:	66 0f 14 c3          	unpcklpd %xmm3,%xmm0
   22118:	48 8d bc 24 c0 00 00 	lea    0xc0(%rsp),%rdi
   2211f:	00 
   22120:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
   22125:	48 8d 94 24 e0 01 00 	lea    0x1e0(%rsp),%rdx
   2212c:	00 
   2212d:	b9 40 00 00 00       	mov    $0x40,%ecx
   22132:	66 0f 28 c8          	movapd %xmm0,%xmm1
   22136:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
   2213b:	e8 90 e8 ff ff       	call   209d0 <gpui_canvas::color::gamut::first_exit::<fearless_simd::generated::sse2::Sse2>>
   22140:	66 0f 28 54 24 30    	movapd 0x30(%rsp),%xmm2
   22146:	66 0f 28 c2          	movapd %xmm2,%xmm0
   2214a:	f2 0f 5d 84 24 c0 00 	minsd  0xc0(%rsp),%xmm0
   22151:	00 00 
   22153:	66 0f 28 c8          	movapd %xmm0,%xmm1
   22157:	f2 0f c2 c8 03       	cmpunordsd %xmm0,%xmm1
   2215c:	66 0f 54 d1          	andpd  %xmm1,%xmm2
   22160:	66 0f 55 c8          	andnpd %xmm0,%xmm1
   22164:	66 0f 56 ca          	orpd   %xmm2,%xmm1
   22168:	f2 0f 10 84 24 c8 00 	movsd  0xc8(%rsp),%xmm0
   2216f:	00 00 
   22171:	66 0f 28 d1          	movapd %xmm1,%xmm2
   22175:	f2 0f 5d d0          	minsd  %xmm0,%xmm2
   22179:	66 0f 28 da          	movapd %xmm2,%xmm3
   2217d:	f2 0f c2 da 03       	cmpunordsd %xmm2,%xmm3
   22182:	66 0f 54 cb          	andpd  %xmm3,%xmm1
   22186:	66 0f 55 da          	andnpd %xmm2,%xmm3
   2218a:	66 0f 56 d9          	orpd   %xmm1,%xmm3
   2218e:	f2 0f 10 84 24 d0 00 	movsd  0xd0(%rsp),%xmm0
   22195:	00 00 
   22197:	66 0f 28 cb          	movapd %xmm3,%xmm1
   2219b:	f2 0f 5d c8          	minsd  %xmm0,%xmm1
   2219f:	66 0f 28 c1          	movapd %xmm1,%xmm0
   221a3:	f2 0f c2 c1 03       	cmpunordsd %xmm1,%xmm0
   221a8:	66 0f 54 d8          	andpd  %xmm0,%xmm3
   221ac:	66 0f 55 c1          	andnpd %xmm1,%xmm0
   221b0:	66 0f 56 c3          	orpd   %xmm3,%xmm0
   221b4:	f2 0f 59 44 24 20    	mulsd  0x20(%rsp),%xmm0
   221ba:	66 48 0f 7e c0       	movq   %xmm0,%rax
   221bf:	48 85 c0             	test   %rax,%rax
   221c2:	0f 98 c1             	sets   %cl
   221c5:	49 21 c7             	and    %rax,%r15
   221c8:	48 b8 00 00 00 00 00 	movabs $0xfff0000000000000,%rax
   221cf:	00 f0 ff 
   221d2:	4c 01 f8             	add    %r15,%rax
   221d5:	48 c1 e8 35          	shr    $0x35,%rax
   221d9:	3d ff 03 00 00       	cmp    $0x3ff,%eax
   221de:	0f 92 c0             	setb   %al
   221e1:	20 c8                	and    %cl,%al
   221e3:	49 8d 57 ff          	lea    -0x1(%r15),%rdx
   221e7:	48 be ff ff ff ff ff 	movabs $0xfffffffffffff,%rsi
   221ee:	ff 0f 00 
   221f1:	48 39 f2             	cmp    %rsi,%rdx
   221f4:	0f 92 c2             	setb   %dl
   221f7:	20 ca                	and    %cl,%dl
   221f9:	48 b9 00 00 00 00 00 	movabs $0x7ff0000000000000,%rcx
   22200:	00 f0 7f 
   22203:	49 39 cf             	cmp    %rcx,%r15
   22206:	0f 9f c1             	setg   %cl
   22209:	40 0f 94 c6          	sete   %sil
   2220d:	40 08 ce             	or     %cl,%sil
   22210:	40 08 d6             	or     %dl,%sil
   22213:	40 08 c6             	or     %al,%sil
   22216:	0f 85 bb 00 00 00    	jne    222d7 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xbf7>
   2221c:	0f 57 c9             	xorps  %xmm1,%xmm1
   2221f:	f2 0f 5a c8          	cvtsd2ss %xmm0,%xmm1
   22223:	0f 28 84 24 f0 00 00 	movaps 0xf0(%rsp),%xmm0
   2222a:	00 
   2222b:	0f 56 05 ce 35 fe ff 	orps   -0x1ca32(%rip),%xmm0        # 5800 <std::thread::current::id::ID+0x4b88>
   22232:	0f 29 84 24 f0 00 00 	movaps %xmm0,0xf0(%rsp)
   22239:	00 
   2223a:	41 bc 40 00 00 00    	mov    $0x40,%r12d
   22240:	0f b6 db             	movzbl %bl,%ebx
   22243:	4c 8d 7c 24 40       	lea    0x40(%rsp),%r15
   22248:	eb 17                	jmp    22261 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xb81>
   2224a:	41 bd 01 00 00 80    	mov    $0x80000001,%r13d
   22250:	66 41 0f 6e cd       	movd   %r13d,%xmm1
   22255:	0f 57 c0             	xorps  %xmm0,%xmm0
   22258:	f3 0f 5f c8          	maxss  %xmm0,%xmm1
   2225c:	41 ff cc             	dec    %r12d
   2225f:	74 76                	je     222d7 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xbf7>
   22261:	66 41 0f 7e cd       	movd   %xmm1,%r13d
   22266:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
   2226c:	f3 0f 11 44 24 40    	movss  %xmm0,0x40(%rsp)
   22272:	f3 0f 11 4c 24 20    	movss  %xmm1,0x20(%rsp)
   22278:	f3 0f 11 4c 24 44    	movss  %xmm1,0x44(%rsp)
   2227e:	0f 28 84 24 f0 00 00 	movaps 0xf0(%rsp),%xmm0
   22285:	00 
   22286:	f3 0f 11 44 24 48    	movss  %xmm0,0x48(%rsp)
   2228c:	c7 44 24 4c 00 00 80 	movl   $0xff800000,0x4c(%rsp)
   22293:	ff 
   22294:	4c 89 ff             	mov    %r15,%rdi
   22297:	89 de                	mov    %ebx,%esi
   22299:	e8 52 00 00 00       	call   222f0 <gpui_canvas::color::gamut::in_gamut>
   2229e:	84 c0                	test   %al,%al
   222a0:	75 28                	jne    222ca <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xbea>
   222a2:	41 81 fd 00 00 80 ff 	cmp    $0xff800000,%r13d
   222a9:	66 0f 6e 4c 24 20    	movd   0x20(%rsp),%xmm1
   222af:	74 a4                	je     22255 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xb75>
   222b1:	44 89 e8             	mov    %r13d,%eax
   222b4:	25 ff ff ff 7f       	and    $0x7fffffff,%eax
   222b9:	74 8f                	je     2224a <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xb6a>
   222bb:	41 39 c5             	cmp    %eax,%r13d
   222be:	75 05                	jne    222c5 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xbe5>
   222c0:	41 ff cd             	dec    %r13d
   222c3:	eb 8b                	jmp    22250 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xb70>
   222c5:	41 ff c5             	inc    %r13d
   222c8:	eb 86                	jmp    22250 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xb70>
   222ca:	49 c1 e5 20          	shl    $0x20,%r13
   222ce:	41 be ff ff ff ff    	mov    $0xffffffff,%r14d
   222d4:	4d 09 ee             	or     %r13,%r14
   222d7:	4c 89 f0             	mov    %r14,%rax
   222da:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
   222de:	5b                   	pop    %rbx
   222df:	41 5c                	pop    %r12
   222e1:	41 5d                	pop    %r13
   222e3:	41 5e                	pop    %r14
   222e5:	41 5f                	pop    %r15
   222e7:	5d                   	pop    %rbp
   222e8:	c3                   	ret
   222e9:	cc                   	int3
   222ea:	cc                   	int3
   222eb:	cc                   	int3
   222ec:	cc                   	int3
   222ed:	cc                   	int3
   222ee:	cc                   	int3
   222ef:	cc                   	int3

gpui_canvas::color::gamut::in_gamut:
   222f0:	55                   	push   %rbp
   222f1:	53                   	push   %rbx
   222f2:	48 83 ec 68          	sub    $0x68,%rsp
   222f6:	89 f3                	mov    %esi,%ebx
   222f8:	f3 0f 7e 0f          	movq   (%rdi),%xmm1
   222fc:	8b 4f 08             	mov    0x8(%rdi),%ecx
   222ff:	8b 57 0c             	mov    0xc(%rdi),%edx
   22302:	89 c8                	mov    %ecx,%eax
   22304:	81 fa 00 00 00 c0    	cmp    $0xc0000000,%edx
   2230a:	0f 82 ea 00 00 00    	jb     223fa <gpui_canvas::color::gamut::in_gamut+0x10a>
   22310:	89 c8                	mov    %ecx,%eax
   22312:	85 c9                	test   %ecx,%ecx
   22314:	0f 88 db 00 00 00    	js     223f5 <gpui_canvas::color::gamut::in_gamut+0x105>
   2231a:	c1 e8 08             	shr    $0x8,%eax
   2231d:	89 ce                	mov    %ecx,%esi
   2231f:	48 69 f6 8f e7 54 52 	imul   $0x5254e78f,%rsi,%rsi
   22326:	48 c1 ee 2e          	shr    $0x2e,%rsi
   2232a:	48 69 f8 09 a8 a7 01 	imul   $0x1a7a809,%rax,%rdi
   22331:	48 c1 ef 20          	shr    $0x20,%rdi
   22335:	66 41 0f 7e c9       	movd   %xmm1,%r9d
   2233a:	45 89 ca             	mov    %r9d,%r10d
   2233d:	41 c1 e2 08          	shl    $0x8,%r10d
   22341:	66 0f 70 c1 55       	pshufd $0x55,%xmm1,%xmm0
   22346:	66 41 0f 7e c0       	movd   %xmm0,%r8d
   2234b:	45 89 c3             	mov    %r8d,%r11d
   2234e:	45 0f a4 cb 08       	shld   $0x8,%r9d,%r11d
   22353:	69 ee 55 52 00 00    	imul   $0x5255,%esi,%ebp
   22359:	c1 ed 16             	shr    $0x16,%ebp
   2235c:	69 ed c7 00 00 00    	imul   $0xc7,%ebp,%ebp
   22362:	29 ee                	sub    %ebp,%esi
   22364:	44 89 dd             	mov    %r11d,%ebp
   22367:	c1 e5 08             	shl    $0x8,%ebp
   2236a:	41 81 e3 ff ff 7f 00 	and    $0x7fffff,%r11d
   22371:	41 81 e2 00 00 00 80 	and    $0x80000000,%r10d
   22378:	81 e5 00 00 00 80    	and    $0x80000000,%ebp
   2237e:	44 09 dd             	or     %r11d,%ebp
   22381:	41 81 e1 ff ff 7f 00 	and    $0x7fffff,%r9d
   22388:	45 09 d1             	or     %r10d,%r9d
   2238b:	c1 e6 17             	shl    $0x17,%esi
   2238e:	09 ee                	or     %ebp,%esi
   22390:	c1 e7 0f             	shl    $0xf,%edi
   22393:	81 e7 00 00 80 ff    	and    $0xff800000,%edi
   22399:	41 0f ac c8 10       	shrd   $0x10,%ecx,%r8d
   2239e:	44 09 cf             	or     %r9d,%edi
   223a1:	4c 69 c8 9f 53 49 01 	imul   $0x149539f,%rax,%r9
   223a8:	49 c1 e9 20          	shr    $0x20,%r9
   223ac:	45 69 c9 c7 00 00 00 	imul   $0xc7,%r9d,%r9d
   223b3:	44 29 c8             	sub    %r9d,%eax
   223b6:	45 89 c1             	mov    %r8d,%r9d
   223b9:	41 81 e1 ff ff 7f 00 	and    $0x7fffff,%r9d
   223c0:	41 c1 e0 08          	shl    $0x8,%r8d
   223c4:	41 81 e0 00 00 00 80 	and    $0x80000000,%r8d
   223cb:	45 09 c8             	or     %r9d,%r8d
   223ce:	c1 e0 17             	shl    $0x17,%eax
   223d1:	44 09 c0             	or     %r8d,%eax
   223d4:	66 0f 6e c6          	movd   %esi,%xmm0
   223d8:	66 0f 6e cf          	movd   %edi,%xmm1
   223dc:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
   223e0:	c1 ea 1e             	shr    $0x1e,%edx
   223e3:	31 ed                	xor    %ebp,%ebp
   223e5:	48 8d 35 58 52 fe ff 	lea    -0x1ada8(%rip),%rsi        # 7644 <std::thread::current::id::ID+0x69cc>
   223ec:	48 63 14 96          	movslq (%rsi,%rdx,4),%rdx
   223f0:	48 01 f2             	add    %rsi,%rdx
   223f3:	ff e2                	jmp    *%rdx
   223f5:	25 ff ff ff 7f       	and    $0x7fffffff,%eax
   223fa:	c1 ea 1e             	shr    $0x1e,%edx
   223fd:	31 ed                	xor    %ebp,%ebp
   223ff:	48 8d 35 3e 52 fe ff 	lea    -0x1adc2(%rip),%rsi        # 7644 <std::thread::current::id::ID+0x69cc>
   22406:	48 63 14 96          	movslq (%rsi,%rdx,4),%rdx
   2240a:	48 01 f2             	add    %rsi,%rdx
   2240d:	ff e2                	jmp    *%rdx
   2240f:	40 b5 01             	mov    $0x1,%bpl
   22412:	f3 0f 5a e9          	cvtss2sd %xmm1,%xmm5
   22416:	66 0f 70 f1 55       	pshufd $0x55,%xmm1,%xmm6
   2241b:	f3 0f 5a e6          	cvtss2sd %xmm6,%xmm4
   2241f:	66 0f 6e d0          	movd   %eax,%xmm2
   22423:	0f 28 05 16 2e fe ff 	movaps -0x1d1ea(%rip),%xmm0        # 5240 <std::thread::current::id::ID+0x45c8>
   2242a:	0f 54 c5             	andps  %xmm5,%xmm0
   2242d:	f2 0f 10 1d 53 4e fe 	movsd  -0x1b1ad(%rip),%xmm3        # 7288 <std::thread::current::id::ID+0x6610>
   22434:	ff 
   22435:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   22439:	66 0f 7e 54 24 30    	movd   %xmm2,0x30(%rsp)
   2243f:	73 53                	jae    22494 <gpui_canvas::color::gamut::in_gamut+0x1a4>
   22441:	0f 2e c9             	ucomiss %xmm1,%xmm1
   22444:	0f 29 64 24 10       	movaps %xmm4,0x10(%rsp)
   22449:	0f 29 74 24 50       	movaps %xmm6,0x50(%rsp)
   2244e:	7a 4e                	jp     2249e <gpui_canvas::color::gamut::in_gamut+0x1ae>
   22450:	0f 54 2d 69 33 fe ff 	andps  -0x1cc97(%rip),%xmm5        # 57c0 <std::thread::current::id::ID+0x4b48>
   22457:	0f 56 2d 72 32 fe ff 	orps   -0x1cd8e(%rip),%xmm5        # 56d0 <std::thread::current::id::ID+0x4a58>
   2245e:	0f 29 2c 24          	movaps %xmm5,(%rsp)
   22462:	eb 46                	jmp    224aa <gpui_canvas::color::gamut::in_gamut+0x1ba>
   22464:	0f 5a e9             	cvtps2pd %xmm1,%xmm5
   22467:	66 0f 6e c0          	movd   %eax,%xmm0
   2246b:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   2246f:	e9 ad 01 00 00       	jmp    22621 <gpui_canvas::color::gamut::in_gamut+0x331>
   22474:	85 c9                	test   %ecx,%ecx
   22476:	0f 88 86 02 00 00    	js     22702 <gpui_canvas::color::gamut::in_gamut+0x412>
   2247c:	0f 5a e9             	cvtps2pd %xmm1,%xmm5
   2247f:	66 0f 6e c0          	movd   %eax,%xmm0
   22483:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   22487:	84 db                	test   %bl,%bl
   22489:	0f 84 5e 02 00 00    	je     226ed <gpui_canvas::color::gamut::in_gamut+0x3fd>
   2248f:	e9 a7 02 00 00       	jmp    2273b <gpui_canvas::color::gamut::in_gamut+0x44b>
   22494:	f2 0f 5e 2d 54 4d fe 	divsd  -0x1b2ac(%rip),%xmm5        # 71f0 <std::thread::current::id::ID+0x6578>
   2249b:	ff 
   2249c:	eb 4b                	jmp    224e9 <gpui_canvas::color::gamut::in_gamut+0x1f9>
   2249e:	f2 0f 10 0d a2 4e fe 	movsd  -0x1b15e(%rip),%xmm1        # 7348 <std::thread::current::id::ID+0x66d0>
   224a5:	ff 
   224a6:	0f 29 0c 24          	movaps %xmm1,(%rsp)
   224aa:	f2 0f 58 05 5e 4f fe 	addsd  -0x1b0a2(%rip),%xmm0        # 7410 <std::thread::current::id::ID+0x6798>
   224b1:	ff 
   224b2:	f2 0f 5e 05 ae 4e fe 	divsd  -0x1b152(%rip),%xmm0        # 7368 <std::thread::current::id::ID+0x66f0>
   224b9:	ff 
   224ba:	f2 0f 10 0d 3e 4e fe 	movsd  -0x1b1c2(%rip),%xmm1        # 7300 <std::thread::current::id::ID+0x6688>
   224c1:	ff 
   224c2:	ff 15 f8 2d 04 00    	call   *0x42df8(%rip)        # 652c0 <pow@GLIBC_2.29>
   224c8:	66 0f 28 e8          	movapd %xmm0,%xmm5
   224cc:	f2 0f 59 2c 24       	mulsd  (%rsp),%xmm5
   224d1:	66 0f 6e 54 24 30    	movd   0x30(%rsp),%xmm2
   224d7:	f2 0f 10 1d a9 4d fe 	movsd  -0x1b257(%rip),%xmm3        # 7288 <std::thread::current::id::ID+0x6610>
   224de:	ff 
   224df:	0f 28 64 24 10       	movaps 0x10(%rsp),%xmm4
   224e4:	0f 28 74 24 50       	movaps 0x50(%rsp),%xmm6
   224e9:	0f 57 c9             	xorps  %xmm1,%xmm1
   224ec:	f3 0f 5a ca          	cvtss2sd %xmm2,%xmm1
   224f0:	0f 28 05 49 2d fe ff 	movaps -0x1d2b7(%rip),%xmm0        # 5240 <std::thread::current::id::ID+0x45c8>
   224f7:	0f 54 c4             	andps  %xmm4,%xmm0
   224fa:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   224fe:	66 0f 29 2c 24       	movapd %xmm5,(%rsp)
   22503:	73 1f                	jae    22524 <gpui_canvas::color::gamut::in_gamut+0x234>
   22505:	0f 2e f6             	ucomiss %xmm6,%xmm6
   22508:	0f 29 4c 24 20       	movaps %xmm1,0x20(%rsp)
   2250d:	7a 4b                	jp     2255a <gpui_canvas::color::gamut::in_gamut+0x26a>
   2250f:	0f 54 25 aa 32 fe ff 	andps  -0x1cd56(%rip),%xmm4        # 57c0 <std::thread::current::id::ID+0x4b48>
   22516:	0f 56 25 b3 31 fe ff 	orps   -0x1ce4d(%rip),%xmm4        # 56d0 <std::thread::current::id::ID+0x4a58>
   2251d:	0f 29 64 24 10       	movaps %xmm4,0x10(%rsp)
   22522:	eb 43                	jmp    22567 <gpui_canvas::color::gamut::in_gamut+0x277>
   22524:	f2 0f 5e 25 c4 4c fe 	divsd  -0x1b33c(%rip),%xmm4        # 71f0 <std::thread::current::id::ID+0x6578>
   2252b:	ff 
   2252c:	0f 28 05 0d 2d fe ff 	movaps -0x1d2f3(%rip),%xmm0        # 5240 <std::thread::current::id::ID+0x45c8>
   22533:	0f 54 c1             	andps  %xmm1,%xmm0
   22536:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   2253a:	72 7e                	jb     225ba <gpui_canvas::color::gamut::in_gamut+0x2ca>
   2253c:	f2 0f 5e 0d ac 4c fe 	divsd  -0x1b354(%rip),%xmm1        # 71f0 <std::thread::current::id::ID+0x6578>
   22543:	ff 
   22544:	66 0f 28 c1          	movapd %xmm1,%xmm0
   22548:	66 0f 14 ec          	unpcklpd %xmm4,%xmm5
   2254c:	40 84 ed             	test   %bpl,%bpl
   2254f:	0f 85 cc 00 00 00    	jne    22621 <gpui_canvas::color::gamut::in_gamut+0x331>
   22555:	e9 8f 01 00 00       	jmp    226e9 <gpui_canvas::color::gamut::in_gamut+0x3f9>
   2255a:	f2 0f 10 0d e6 4d fe 	movsd  -0x1b21a(%rip),%xmm1        # 7348 <std::thread::current::id::ID+0x66d0>
   22561:	ff 
   22562:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
   22567:	f2 0f 58 05 a1 4e fe 	addsd  -0x1b15f(%rip),%xmm0        # 7410 <std::thread::current::id::ID+0x6798>
   2256e:	ff 
   2256f:	f2 0f 5e 05 f1 4d fe 	divsd  -0x1b20f(%rip),%xmm0        # 7368 <std::thread::current::id::ID+0x66f0>
   22576:	ff 
   22577:	f2 0f 10 0d 81 4d fe 	movsd  -0x1b27f(%rip),%xmm1        # 7300 <std::thread::current::id::ID+0x6688>
   2257e:	ff 
   2257f:	ff 15 3b 2d 04 00    	call   *0x42d3b(%rip)        # 652c0 <pow@GLIBC_2.29>
   22585:	66 0f 28 e0          	movapd %xmm0,%xmm4
   22589:	f2 0f 59 64 24 10    	mulsd  0x10(%rsp),%xmm4
   2258f:	66 0f 28 2c 24       	movapd (%rsp),%xmm5
   22594:	f3 0f 10 54 24 30    	movss  0x30(%rsp),%xmm2
   2259a:	f2 0f 10 1d e6 4c fe 	movsd  -0x1b31a(%rip),%xmm3        # 7288 <std::thread::current::id::ID+0x6610>
   225a1:	ff 
   225a2:	66 0f 28 4c 24 20    	movapd 0x20(%rsp),%xmm1
   225a8:	66 0f 28 05 90 2c fe 	movapd -0x1d370(%rip),%xmm0        # 5240 <std::thread::current::id::ID+0x45c8>
   225af:	ff 
   225b0:	66 0f 54 c1          	andpd  %xmm1,%xmm0
   225b4:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   225b8:	73 82                	jae    2253c <gpui_canvas::color::gamut::in_gamut+0x24c>
   225ba:	0f 2e d2             	ucomiss %xmm2,%xmm2
   225bd:	66 0f 29 64 24 10    	movapd %xmm4,0x10(%rsp)
   225c3:	7a 12                	jp     225d7 <gpui_canvas::color::gamut::in_gamut+0x2e7>
   225c5:	66 0f 54 0d f3 31 fe 	andpd  -0x1ce0d(%rip),%xmm1        # 57c0 <std::thread::current::id::ID+0x4b48>
   225cc:	ff 
   225cd:	66 0f 56 0d fb 30 fe 	orpd   -0x1cf05(%rip),%xmm1        # 56d0 <std::thread::current::id::ID+0x4a58>
   225d4:	ff 
   225d5:	eb 08                	jmp    225df <gpui_canvas::color::gamut::in_gamut+0x2ef>
   225d7:	f2 0f 10 0d 69 4d fe 	movsd  -0x1b297(%rip),%xmm1        # 7348 <std::thread::current::id::ID+0x66d0>
   225de:	ff 
   225df:	66 0f 29 4c 24 20    	movapd %xmm1,0x20(%rsp)
   225e5:	f2 0f 58 05 23 4e fe 	addsd  -0x1b1dd(%rip),%xmm0        # 7410 <std::thread::current::id::ID+0x6798>
   225ec:	ff 
   225ed:	f2 0f 5e 05 73 4d fe 	divsd  -0x1b28d(%rip),%xmm0        # 7368 <std::thread::current::id::ID+0x66f0>
   225f4:	ff 
   225f5:	f2 0f 10 0d 03 4d fe 	movsd  -0x1b2fd(%rip),%xmm1        # 7300 <std::thread::current::id::ID+0x6688>
   225fc:	ff 
   225fd:	ff 15 bd 2c 04 00    	call   *0x42cbd(%rip)        # 652c0 <pow@GLIBC_2.29>
   22603:	f2 0f 59 44 24 20    	mulsd  0x20(%rsp),%xmm0
   22609:	66 0f 28 2c 24       	movapd (%rsp),%xmm5
   2260e:	66 0f 28 64 24 10    	movapd 0x10(%rsp),%xmm4
   22614:	66 0f 14 ec          	unpcklpd %xmm4,%xmm5
   22618:	40 84 ed             	test   %bpl,%bpl
   2261b:	0f 84 c8 00 00 00    	je     226e9 <gpui_canvas::color::gamut::in_gamut+0x3f9>
   22621:	66 0f 28 d5          	movapd %xmm5,%xmm2
   22625:	66 0f c6 d5 01       	shufpd $0x1,%xmm5,%xmm2
   2262a:	66 0f 59 15 be 30 fe 	mulpd  -0x1cf42(%rip),%xmm2        # 56f0 <std::thread::current::id::ID+0x4a78>
   22631:	ff 
   22632:	66 0f 57 db          	xorpd  %xmm3,%xmm3
   22636:	66 0f 16 1d aa 4d fe 	movhpd -0x1b256(%rip),%xmm3        # 73e8 <std::thread::current::id::ID+0x6770>
   2263d:	ff 
   2263e:	66 0f 59 dd          	mulpd  %xmm5,%xmm3
   22642:	0f 28 c8             	movaps %xmm0,%xmm1
   22645:	0f 16 c8             	movlhps %xmm0,%xmm1
   22648:	66 0f 59 0d 10 2c fe 	mulpd  -0x1d3f0(%rip),%xmm1        # 5260 <std::thread::current::id::ID+0x45e8>
   2264f:	ff 
   22650:	66 0f 58 da          	addpd  %xmm2,%xmm3
   22654:	66 0f 58 cb          	addpd  %xmm3,%xmm1
   22658:	f2 0f 10 15 e8 4b fe 	movsd  -0x1b418(%rip),%xmm2        # 7248 <std::thread::current::id::ID+0x65d0>
   2265f:	ff 
   22660:	f2 0f 59 d5          	mulsd  %xmm5,%xmm2
   22664:	f2 0f 10 e8          	movsd  %xmm0,%xmm5
   22668:	66 0f 59 2d 20 2c fe 	mulpd  -0x1d3e0(%rip),%xmm5        # 5290 <std::thread::current::id::ID+0x4618>
   2266f:	ff 
   22670:	66 0f 28 c5          	movapd %xmm5,%xmm0
   22674:	66 0f 15 c5          	unpckhpd %xmm5,%xmm0
   22678:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   2267c:	f2 0f 58 c5          	addsd  %xmm5,%xmm0
   22680:	f2 0f 10 15 80 4b fe 	movsd  -0x1b480(%rip),%xmm2        # 7208 <std::thread::current::id::ID+0x6590>
   22687:	ff 
   22688:	66 0f 28 d9          	movapd %xmm1,%xmm3
   2268c:	f2 0f 10 d8          	movsd  %xmm0,%xmm3
   22690:	66 0f 59 1d e8 2e fe 	mulpd  -0x1d118(%rip),%xmm3        # 5580 <std::thread::current::id::ID+0x4908>
   22697:	ff 
   22698:	66 0f 28 e1          	movapd %xmm1,%xmm4
   2269c:	66 0f c6 e0 01       	shufpd $0x1,%xmm0,%xmm4
   226a1:	66 0f 59 25 17 2e fe 	mulpd  -0x1d1e9(%rip),%xmm4        # 54c0 <std::thread::current::id::ID+0x4848>
   226a8:	ff 
   226a9:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
   226ad:	66 0f 58 e3          	addpd  %xmm3,%xmm4
   226b1:	66 0f 28 e9          	movapd %xmm1,%xmm5
   226b5:	66 0f 14 e9          	unpcklpd %xmm1,%xmm5
   226b9:	66 0f 59 2d 0f 31 fe 	mulpd  -0x1cef1(%rip),%xmm5        # 57d0 <std::thread::current::id::ID+0x4b58>
   226c0:	ff 
   226c1:	66 0f 28 c4          	movapd %xmm4,%xmm0
   226c5:	66 0f 5c c5          	subpd  %xmm5,%xmm0
   226c9:	66 0f 58 ec          	addpd  %xmm4,%xmm5
   226cd:	f2 0f 10 e8          	movsd  %xmm0,%xmm5
   226d1:	66 0f 59 0d 87 2e fe 	mulpd  -0x1d179(%rip),%xmm1        # 5560 <std::thread::current::id::ID+0x48e8>
   226d8:	ff 
   226d9:	66 0f 28 c1          	movapd %xmm1,%xmm0
   226dd:	66 0f 15 c1          	unpckhpd %xmm1,%xmm0
   226e1:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   226e5:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
   226e9:	84 db                	test   %bl,%bl
   226eb:	75 4e                	jne    2273b <gpui_canvas::color::gamut::in_gamut+0x44b>
   226ed:	31 c0                	xor    %eax,%eax
   226ef:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   226f3:	66 0f 2e e9          	ucomisd %xmm1,%xmm5
   226f7:	0f 83 08 01 00 00    	jae    22805 <gpui_canvas::color::gamut::in_gamut+0x515>
   226fd:	e9 41 01 00 00       	jmp    22843 <gpui_canvas::color::gamut::in_gamut+0x553>
   22702:	66 0f 6f d1          	movdqa %xmm1,%xmm2
   22706:	0f c6 c9 55          	shufps $0x55,%xmm1,%xmm1
   2270a:	66 0f ef c0          	pxor   %xmm0,%xmm0
   2270e:	0f 2e c8             	ucomiss %xmm0,%xmm1
   22711:	0f 85 35 01 00 00    	jne    2284c <gpui_canvas::color::gamut::in_gamut+0x55c>
   22717:	0f 8a 2f 01 00 00    	jp     2284c <gpui_canvas::color::gamut::in_gamut+0x55c>
   2271d:	0f 57 c9             	xorps  %xmm1,%xmm1
   22720:	f3 0f 5a ca          	cvtss2sd %xmm2,%xmm1
   22724:	0f 28 c1             	movaps %xmm1,%xmm0
   22727:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   2272b:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   2272f:	66 0f 28 e8          	movapd %xmm0,%xmm5
   22733:	66 0f 14 e8          	unpcklpd %xmm0,%xmm5
   22737:	84 db                	test   %bl,%bl
   22739:	74 b2                	je     226ed <gpui_canvas::color::gamut::in_gamut+0x3fd>
   2273b:	66 0f 28 0d cd 2b fe 	movapd -0x1d433(%rip),%xmm1        # 5310 <std::thread::current::id::ID+0x4698>
   22742:	ff 
   22743:	66 0f 59 cd          	mulpd  %xmm5,%xmm1
   22747:	66 0f 28 d5          	movapd %xmm5,%xmm2
   2274b:	66 0f c6 d5 01       	shufpd $0x1,%xmm5,%xmm2
   22750:	66 0f 59 15 f8 2f fe 	mulpd  -0x1d008(%rip),%xmm2        # 5750 <std::thread::current::id::ID+0x4ad8>
   22757:	ff 
   22758:	66 0f 58 d1          	addpd  %xmm1,%xmm2
   2275c:	66 0f 28 c8          	movapd %xmm0,%xmm1
   22760:	66 0f 14 c8          	unpcklpd %xmm0,%xmm1
   22764:	66 0f 59 0d 54 2c fe 	mulpd  -0x1d3ac(%rip),%xmm1        # 53c0 <std::thread::current::id::ID+0x4748>
   2276b:	ff 
   2276c:	f2 0f 10 1d 24 4b fe 	movsd  -0x1b4dc(%rip),%xmm3        # 7298 <std::thread::current::id::ID+0x6620>
   22773:	ff 
   22774:	f2 0f 59 dd          	mulsd  %xmm5,%xmm3
   22778:	f2 0f 10 e8          	movsd  %xmm0,%xmm5
   2277c:	66 0f 59 2d 4c 2c fe 	mulpd  -0x1d3b4(%rip),%xmm5        # 53d0 <std::thread::current::id::ID+0x4758>
   22783:	ff 
   22784:	66 0f 58 ca          	addpd  %xmm2,%xmm1
   22788:	66 0f 28 c5          	movapd %xmm5,%xmm0
   2278c:	66 0f 15 c5          	unpckhpd %xmm5,%xmm0
   22790:	f2 0f 58 c3          	addsd  %xmm3,%xmm0
   22794:	66 0f 28 d1          	movapd %xmm1,%xmm2
   22798:	66 0f c6 d1 01       	shufpd $0x1,%xmm1,%xmm2
   2279d:	66 0f 59 15 cb 2a fe 	mulpd  -0x1d535(%rip),%xmm2        # 5270 <std::thread::current::id::ID+0x45f8>
   227a4:	ff 
   227a5:	f2 0f 58 c5          	addsd  %xmm5,%xmm0
   227a9:	66 0f 28 1d 3f 2b fe 	movapd -0x1d4c1(%rip),%xmm3        # 52f0 <std::thread::current::id::ID+0x4678>
   227b0:	ff 
   227b1:	66 0f 59 d9          	mulpd  %xmm1,%xmm3
   227b5:	66 0f 5c da          	subpd  %xmm2,%xmm3
   227b9:	66 0f 28 e8          	movapd %xmm0,%xmm5
   227bd:	66 0f 14 e8          	unpcklpd %xmm0,%xmm5
   227c1:	66 0f 59 2d d7 2b fe 	mulpd  -0x1d429(%rip),%xmm5        # 53a0 <std::thread::current::id::ID+0x4728>
   227c8:	ff 
   227c9:	66 0f 28 d3          	movapd %xmm3,%xmm2
   227cd:	66 0f 5c d5          	subpd  %xmm5,%xmm2
   227d1:	66 0f 58 eb          	addpd  %xmm3,%xmm5
   227d5:	f2 0f 10 ea          	movsd  %xmm2,%xmm5
   227d9:	66 0f 59 0d 3f 2e fe 	mulpd  -0x1d1c1(%rip),%xmm1        # 5620 <std::thread::current::id::ID+0x49a8>
   227e0:	ff 
   227e1:	66 0f 28 d1          	movapd %xmm1,%xmm2
   227e5:	66 0f 15 d1          	unpckhpd %xmm1,%xmm2
   227e9:	f2 0f 5c ca          	subsd  %xmm2,%xmm1
   227ed:	f2 0f 59 05 4b 4b fe 	mulsd  -0x1b4b5(%rip),%xmm0        # 7340 <std::thread::current::id::ID+0x66c8>
   227f4:	ff 
   227f5:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
   227f9:	31 c0                	xor    %eax,%eax
   227fb:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   227ff:	66 0f 2e e9          	ucomisd %xmm1,%xmm5
   22803:	72 3e                	jb     22843 <gpui_canvas::color::gamut::in_gamut+0x553>
   22805:	f2 0f 10 0d a3 4a fe 	movsd  -0x1b55d(%rip),%xmm1        # 72b0 <std::thread::current::id::ID+0x6638>
   2280c:	ff 
   2280d:	66 0f 2e cd          	ucomisd %xmm5,%xmm1
   22811:	72 30                	jb     22843 <gpui_canvas::color::gamut::in_gamut+0x553>
   22813:	66 0f 15 ed          	unpckhpd %xmm5,%xmm5
   22817:	31 c0                	xor    %eax,%eax
   22819:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   2281d:	66 0f 2e ea          	ucomisd %xmm2,%xmm5
   22821:	72 20                	jb     22843 <gpui_canvas::color::gamut::in_gamut+0x553>
   22823:	66 0f 2e cd          	ucomisd %xmm5,%xmm1
   22827:	72 1a                	jb     22843 <gpui_canvas::color::gamut::in_gamut+0x553>
   22829:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   2282d:	f2 0f c2 c8 02       	cmplesd %xmm0,%xmm1
   22832:	f2 0f c2 05 75 4a fe 	cmplesd -0x1b58b(%rip),%xmm0        # 72b0 <std::thread::current::id::ID+0x6638>
   22839:	ff 02 
   2283b:	66 0f 54 c1          	andpd  %xmm1,%xmm0
   2283f:	66 0f 7e c0          	movd   %xmm0,%eax
   22843:	24 01                	and    $0x1,%al
   22845:	48 83 c4 68          	add    $0x68,%rsp
   22849:	5b                   	pop    %rbx
   2284a:	5d                   	pop    %rbp
   2284b:	c3                   	ret
   2284c:	66 0f 6e c0          	movd   %eax,%xmm0
   22850:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   22854:	f2 0f 59 05 84 4b fe 	mulsd  -0x1b47c(%rip),%xmm0        # 73e0 <std::thread::current::id::ID+0x6768>
   2285b:	ff 
   2285c:	48 8d 7c 24 48       	lea    0x48(%rsp),%rdi
   22861:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
   22866:	0f 29 0c 24          	movaps %xmm1,(%rsp)
   2286a:	66 0f 7f 54 24 30    	movdqa %xmm2,0x30(%rsp)
   22870:	ff 15 72 2a 04 00    	call   *0x42a72(%rip)        # 652e8 <sincos@GLIBC_2.2.5>
   22876:	0f 28 44 24 30       	movaps 0x30(%rsp),%xmm0
   2287b:	0f 57 c9             	xorps  %xmm1,%xmm1
   2287e:	f3 0f 5a c8          	cvtss2sd %xmm0,%xmm1
   22882:	0f 28 04 24          	movaps (%rsp),%xmm0
   22886:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   2288a:	f2 0f 10 54 24 40    	movsd  0x40(%rsp),%xmm2
   22890:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
   22894:	f2 0f 59 44 24 48    	mulsd  0x48(%rsp),%xmm0
   2289a:	f2 0f 10 1d 16 4b fe 	movsd  -0x1b4ea(%rip),%xmm3        # 73b8 <std::thread::current::id::ID+0x6740>
   228a1:	ff 
   228a2:	f2 0f 59 da          	mulsd  %xmm2,%xmm3
   228a6:	f2 0f 58 d9          	addsd  %xmm1,%xmm3
   228aa:	f2 0f 10 2d 9e 4a fe 	movsd  -0x1b562(%rip),%xmm5        # 7350 <std::thread::current::id::ID+0x66d8>
   228b1:	ff 
   228b2:	f2 0f 59 e8          	mulsd  %xmm0,%xmm5
   228b6:	f2 0f 58 eb          	addsd  %xmm3,%xmm5
   228ba:	f2 0f 10 1d 4e 4a fe 	movsd  -0x1b5b2(%rip),%xmm3        # 7310 <std::thread::current::id::ID+0x6698>
   228c1:	ff 
   228c2:	f2 0f 59 da          	mulsd  %xmm2,%xmm3
   228c6:	f2 0f 58 d9          	addsd  %xmm1,%xmm3
   228ca:	f2 0f 10 35 46 4b fe 	movsd  -0x1b4ba(%rip),%xmm6        # 7418 <std::thread::current::id::ID+0x67a0>
   228d1:	ff 
   228d2:	f2 0f 59 f0          	mulsd  %xmm0,%xmm6
   228d6:	f2 0f 58 f3          	addsd  %xmm3,%xmm6
   228da:	f2 0f 59 15 be 4a fe 	mulsd  -0x1b542(%rip),%xmm2        # 73a0 <std::thread::current::id::ID+0x6728>
   228e1:	ff 
   228e2:	f2 0f 58 d1          	addsd  %xmm1,%xmm2
   228e6:	f2 0f 59 05 0a 49 fe 	mulsd  -0x1b6f6(%rip),%xmm0        # 71f8 <std::thread::current::id::ID+0x6580>
   228ed:	ff 
   228ee:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   228f2:	66 0f 28 e5          	movapd %xmm5,%xmm4
   228f6:	f2 0f 59 e5          	mulsd  %xmm5,%xmm4
   228fa:	f2 0f 59 e5          	mulsd  %xmm5,%xmm4
   228fe:	66 0f 28 de          	movapd %xmm6,%xmm3
   22902:	f2 0f 59 de          	mulsd  %xmm6,%xmm3
   22906:	f2 0f 59 de          	mulsd  %xmm6,%xmm3
   2290a:	66 0f 28 c8          	movapd %xmm0,%xmm1
   2290e:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   22912:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   22916:	f2 0f 10 05 02 4b fe 	movsd  -0x1b4fe(%rip),%xmm0        # 7420 <std::thread::current::id::ID+0x67a8>
   2291d:	ff 
   2291e:	f2 0f 59 c4          	mulsd  %xmm4,%xmm0
   22922:	f2 0f 10 15 9e 49 fe 	movsd  -0x1b662(%rip),%xmm2        # 72c8 <std::thread::current::id::ID+0x6650>
   22929:	ff 
   2292a:	f2 0f 59 d3          	mulsd  %xmm3,%xmm2
   2292e:	f2 0f 58 d0          	addsd  %xmm0,%xmm2
   22932:	f2 0f 10 05 96 49 fe 	movsd  -0x1b66a(%rip),%xmm0        # 72d0 <std::thread::current::id::ID+0x6658>
   22939:	ff 
   2293a:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   2293e:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   22942:	f2 0f 10 15 be 48 fe 	movsd  -0x1b742(%rip),%xmm2        # 7208 <std::thread::current::id::ID+0x6590>
   22949:	ff 
   2294a:	66 0f 14 e4          	unpcklpd %xmm4,%xmm4
   2294e:	66 0f 59 25 3a 2e fe 	mulpd  -0x1d1c6(%rip),%xmm4        # 5790 <std::thread::current::id::ID+0x4b18>
   22955:	ff 
   22956:	66 0f 14 db          	unpcklpd %xmm3,%xmm3
   2295a:	66 0f 59 1d 3e 2e fe 	mulpd  -0x1d1c2(%rip),%xmm3        # 57a0 <std::thread::current::id::ID+0x4b28>
   22961:	ff 
   22962:	66 0f 58 dc          	addpd  %xmm4,%xmm3
   22966:	66 0f 14 c9          	unpcklpd %xmm1,%xmm1
   2296a:	66 0f 59 0d de 2b fe 	mulpd  -0x1d422(%rip),%xmm1        # 5550 <std::thread::current::id::ID+0x48d8>
   22971:	ff 
   22972:	66 0f 58 cb          	addpd  %xmm3,%xmm1
   22976:	e9 0d fd ff ff       	jmp    22688 <gpui_canvas::color::gamut::in_gamut+0x398>

