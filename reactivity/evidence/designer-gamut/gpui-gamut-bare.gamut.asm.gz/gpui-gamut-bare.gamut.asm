<gpui_canvas::color::OutputProfile>::max_chroma:
   1ef80:	66 0f 7e c1          	movd   %xmm0,%ecx
   1ef84:	81 e1 ff ff ff 7f    	and    $0x7fffffff,%ecx
   1ef8a:	b8 0d 00 00 00       	mov    $0xd,%eax
   1ef8f:	81 f9 ff ff 7f 7f    	cmp    $0x7f7fffff,%ecx
   1ef95:	7f 38                	jg     1efcf <<gpui_canvas::color::OutputProfile>::max_chroma+0x4f>
   1ef97:	0f 57 e4             	xorps  %xmm4,%xmm4
   1ef9a:	0f 57 d2             	xorps  %xmm2,%xmm2
   1ef9d:	f3 0f c2 d0 06       	cmpnless %xmm0,%xmm2
   1efa2:	0f 28 d8             	movaps %xmm0,%xmm3
   1efa5:	f3 0f c2 1d 3a 66 fe 	cmpnless -0x199c6(%rip),%xmm3        # 55e8 <std::thread::current::id::ID+0x4970>
   1efac:	ff 06 
   1efae:	0f 56 da             	orps   %xmm2,%xmm3
   1efb1:	66 0f 7e d9          	movd   %xmm3,%ecx
   1efb5:	66 0f 7e ca          	movd   %xmm1,%edx
   1efb9:	81 e2 ff ff ff 7f    	and    $0x7fffffff,%edx
   1efbf:	81 fa 00 00 80 7f    	cmp    $0x7f800000,%edx
   1efc5:	0f 9d c2             	setge  %dl
   1efc8:	08 ca                	or     %cl,%dl
   1efca:	f6 c2 01             	test   $0x1,%dl
   1efcd:	74 01                	je     1efd0 <<gpui_canvas::color::OutputProfile>::max_chroma+0x50>
   1efcf:	c3                   	ret
   1efd0:	0f 2e c4             	ucomiss %xmm4,%xmm0
   1efd3:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   1efd8:	75 02                	jne    1efdc <<gpui_canvas::color::OutputProfile>::max_chroma+0x5c>
   1efda:	7b f3                	jnp    1efcf <<gpui_canvas::color::OutputProfile>::max_chroma+0x4f>
   1efdc:	0f 2e 05 05 66 fe ff 	ucomiss -0x199fb(%rip),%xmm0        # 55e8 <std::thread::current::id::ID+0x4970>
   1efe3:	75 02                	jne    1efe7 <<gpui_canvas::color::OutputProfile>::max_chroma+0x67>
   1efe5:	7b e8                	jnp    1efcf <<gpui_canvas::color::OutputProfile>::max_chroma+0x4f>
   1efe7:	53                   	push   %rbx
   1efe8:	48 83 ec 10          	sub    $0x10,%rsp
   1efec:	f3 0f 11 44 24 0c    	movss  %xmm0,0xc(%rsp)
   1eff2:	89 fb                	mov    %edi,%ebx
   1eff4:	0f 57 c0             	xorps  %xmm0,%xmm0
   1eff7:	f3 0f 5a c1          	cvtss2sd %xmm1,%xmm0
   1effb:	f2 0f 10 0d 35 80 fe 	movsd  -0x17fcb(%rip),%xmm1        # 7038 <std::thread::current::id::ID+0x63c0>
   1f002:	ff 
   1f003:	ff 15 df 47 04 00    	call   *0x447df(%rip)        # 637e8 <_DYNAMIC+0x370>
   1f009:	f2 0f 10 1d 27 80 fe 	movsd  -0x17fd9(%rip),%xmm3        # 7038 <std::thread::current::id::ID+0x63c0>
   1f010:	ff 
   1f011:	f2 0f 58 d8          	addsd  %xmm0,%xmm3
   1f015:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   1f019:	66 0f 28 d0          	movapd %xmm0,%xmm2
   1f01d:	f2 0f c2 d1 01       	cmpltsd %xmm1,%xmm2
   1f022:	66 0f 54 da          	andpd  %xmm2,%xmm3
   1f026:	66 0f 55 d0          	andnpd %xmm0,%xmm2
   1f02a:	66 0f 56 d3          	orpd   %xmm3,%xmm2
   1f02e:	66 0f 2e 15 82 7f fe 	ucomisd -0x1807e(%rip),%xmm2        # 6fb8 <std::thread::current::id::ID+0x6340>
   1f035:	ff 
   1f036:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   1f03a:	73 0f                	jae    1f04b <<gpui_canvas::color::OutputProfile>::max_chroma+0xcb>
   1f03c:	0f 57 c0             	xorps  %xmm0,%xmm0
   1f03f:	f2 0f 5a c2          	cvtsd2ss %xmm2,%xmm0
   1f043:	f3 0f c2 c8 00       	cmpeqss %xmm0,%xmm1
   1f048:	0f 55 c8             	andnps %xmm0,%xmm1
   1f04b:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   1f051:	0f b6 fb             	movzbl %bl,%edi
   1f054:	48 83 c4 10          	add    $0x10,%rsp
   1f058:	5b                   	pop    %rbx
   1f059:	e9 32 0a 00 00       	jmp    1fa90 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>>
   1f05e:	cc                   	int3
   1f05f:	cc                   	int3

<gpui_canvas::color::Color>::fit_chroma:
   1f3d0:	55                   	push   %rbp
   1f3d1:	41 57                	push   %r15
   1f3d3:	41 56                	push   %r14
   1f3d5:	41 54                	push   %r12
   1f3d7:	53                   	push   %rbx
   1f3d8:	48 83 ec 30          	sub    $0x30,%rsp
   1f3dc:	48 89 fb             	mov    %rdi,%rbx
   1f3df:	44 8b 66 08          	mov    0x8(%rsi),%r12d
   1f3e3:	44 8b 7e 0c          	mov    0xc(%rsi),%r15d
   1f3e7:	41 81 ff 00 00 00 c0 	cmp    $0xc0000000,%r15d
   1f3ee:	0f 92 c0             	setb   %al
   1f3f1:	45 85 e4             	test   %r12d,%r12d
   1f3f4:	0f 99 c1             	setns  %cl
   1f3f7:	08 c1                	or     %al,%cl
   1f3f9:	74 09                	je     1f404 <<gpui_canvas::color::Color>::fit_chroma+0x34>
   1f3fb:	c7 43 04 0d 00 00 00 	movl   $0xd,0x4(%rbx)
   1f402:	eb 4a                	jmp    1f44e <<gpui_canvas::color::Color>::fit_chroma+0x7e>
   1f404:	49 89 f6             	mov    %rsi,%r14
   1f407:	0f 10 06             	movups (%rsi),%xmm0
   1f40a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   1f40f:	0f b6 ea             	movzbl %dl,%ebp
   1f412:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   1f417:	89 ee                	mov    %ebp,%esi
   1f419:	e8 c2 1f 00 00       	call   213e0 <gpui_canvas::color::gamut::in_gamut>
   1f41e:	84 c0                	test   %al,%al
   1f420:	74 0c                	je     1f42e <<gpui_canvas::color::Color>::fit_chroma+0x5e>
   1f422:	41 0f 10 06          	movups (%r14),%xmm0
   1f426:	0f 11 43 04          	movups %xmm0,0x4(%rbx)
   1f42a:	31 c0                	xor    %eax,%eax
   1f42c:	eb 25                	jmp    1f453 <<gpui_canvas::color::Color>::fit_chroma+0x83>
   1f42e:	41 8b 16             	mov    (%r14),%edx
   1f431:	89 d6                	mov    %edx,%esi
   1f433:	81 e6 ff ff ff 7f    	and    $0x7fffffff,%esi
   1f439:	b8 0d 00 00 00       	mov    $0xd,%eax
   1f43e:	31 c9                	xor    %ecx,%ecx
   1f440:	81 fe ff ff 7f 7f    	cmp    $0x7f7fffff,%esi
   1f446:	7e 1d                	jle    1f465 <<gpui_canvas::color::Color>::fit_chroma+0x95>
   1f448:	89 43 04             	mov    %eax,0x4(%rbx)
   1f44b:	89 4b 08             	mov    %ecx,0x8(%rbx)
   1f44e:	b8 01 00 00 00       	mov    $0x1,%eax
   1f453:	89 03                	mov    %eax,(%rbx)
   1f455:	48 89 d8             	mov    %rbx,%rax
   1f458:	48 83 c4 30          	add    $0x30,%rsp
   1f45c:	5b                   	pop    %rbx
   1f45d:	41 5c                	pop    %r12
   1f45f:	41 5e                	pop    %r14
   1f461:	41 5f                	pop    %r15
   1f463:	5d                   	pop    %rbp
   1f464:	c3                   	ret
   1f465:	44 89 e6             	mov    %r12d,%esi
   1f468:	81 e6 ff ff ff 7f    	and    $0x7fffffff,%esi
   1f46e:	66 0f 6e c6          	movd   %esi,%xmm0
   1f472:	0f 2e 05 a3 61 fe ff 	ucomiss -0x19e5d(%rip),%xmm0        # 561c <std::thread::current::id::ID+0x49a4>
   1f479:	74 cd                	je     1f448 <<gpui_canvas::color::Color>::fit_chroma+0x78>
   1f47b:	66 0f 6e d2          	movd   %edx,%xmm2
   1f47f:	0f 57 c9             	xorps  %xmm1,%xmm1
   1f482:	0f 2e d1             	ucomiss %xmm1,%xmm2
   1f485:	72 c1                	jb     1f448 <<gpui_canvas::color::Color>::fit_chroma+0x78>
   1f487:	f3 0f 10 0d 59 61 fe 	movss  -0x19ea7(%rip),%xmm1        # 55e8 <std::thread::current::id::ID+0x4970>
   1f48e:	ff 
   1f48f:	0f 2e ca             	ucomiss %xmm2,%xmm1
   1f492:	72 b4                	jb     1f448 <<gpui_canvas::color::Color>::fit_chroma+0x78>
   1f494:	f3 41 0f 10 5e 04    	movss  0x4(%r14),%xmm3
   1f49a:	31 c9                	xor    %ecx,%ecx
   1f49c:	0f 57 c9             	xorps  %xmm1,%xmm1
   1f49f:	0f 2e d1             	ucomiss %xmm1,%xmm2
   1f4a2:	f3 0f 11 54 24 0c    	movss  %xmm2,0xc(%rsp)
   1f4a8:	75 02                	jne    1f4ac <<gpui_canvas::color::Color>::fit_chroma+0xdc>
   1f4aa:	7b 63                	jnp    1f50f <<gpui_canvas::color::Color>::fit_chroma+0x13f>
   1f4ac:	0f 2e 15 35 61 fe ff 	ucomiss -0x19ecb(%rip),%xmm2        # 55e8 <std::thread::current::id::ID+0x4970>
   1f4b3:	75 02                	jne    1f4b7 <<gpui_canvas::color::Color>::fit_chroma+0xe7>
   1f4b5:	7b 58                	jnp    1f50f <<gpui_canvas::color::Color>::fit_chroma+0x13f>
   1f4b7:	0f 29 5c 24 20       	movaps %xmm3,0x20(%rsp)
   1f4bc:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   1f4c0:	f2 0f 10 0d 70 7b fe 	movsd  -0x18490(%rip),%xmm1        # 7038 <std::thread::current::id::ID+0x63c0>
   1f4c7:	ff 
   1f4c8:	ff 15 1a 43 04 00    	call   *0x4431a(%rip)        # 637e8 <_DYNAMIC+0x370>
   1f4ce:	66 0f 2e 05 e2 7a fe 	ucomisd -0x1851e(%rip),%xmm0        # 6fb8 <std::thread::current::id::ID+0x6340>
   1f4d5:	ff 
   1f4d6:	0f 57 c9             	xorps  %xmm1,%xmm1
   1f4d9:	73 0c                	jae    1f4e7 <<gpui_canvas::color::Color>::fit_chroma+0x117>
   1f4db:	f2 0f 5a c0          	cvtsd2ss %xmm0,%xmm0
   1f4df:	f3 0f c2 c8 00       	cmpeqss %xmm0,%xmm1
   1f4e4:	0f 55 c8             	andnps %xmm0,%xmm1
   1f4e7:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   1f4ed:	89 ef                	mov    %ebp,%edi
   1f4ef:	e8 9c 05 00 00       	call   1fa90 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>>
   1f4f4:	f3 0f 10 54 24 0c    	movss  0xc(%rsp),%xmm2
   1f4fa:	48 89 c1             	mov    %rax,%rcx
   1f4fd:	48 c1 e9 20          	shr    $0x20,%rcx
   1f501:	83 f8 ff             	cmp    $0xffffffff,%eax
   1f504:	0f 28 5c 24 20       	movaps 0x20(%rsp),%xmm3
   1f509:	0f 85 39 ff ff ff    	jne    1f448 <<gpui_canvas::color::Color>::fit_chroma+0x78>
   1f50f:	66 0f 6e c1          	movd   %ecx,%xmm0
   1f513:	0f 28 cb             	movaps %xmm3,%xmm1
   1f516:	f3 0f 5d c8          	minss  %xmm0,%xmm1
   1f51a:	0f 28 e1             	movaps %xmm1,%xmm4
   1f51d:	f3 0f c2 e1 03       	cmpunordss %xmm1,%xmm4
   1f522:	0f 28 c4             	movaps %xmm4,%xmm0
   1f525:	0f 55 c1             	andnps %xmm1,%xmm0
   1f528:	0f 54 e3             	andps  %xmm3,%xmm4
   1f52b:	0f 56 e0             	orps   %xmm0,%xmm4
   1f52e:	f3 0f 11 54 24 10    	movss  %xmm2,0x10(%rsp)
   1f534:	0f 29 64 24 20       	movaps %xmm4,0x20(%rsp)
   1f539:	f3 0f 11 64 24 14    	movss  %xmm4,0x14(%rsp)
   1f53f:	44 89 64 24 18       	mov    %r12d,0x18(%rsp)
   1f544:	44 89 7c 24 1c       	mov    %r15d,0x1c(%rsp)
   1f549:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   1f54e:	89 ee                	mov    %ebp,%esi
   1f550:	e8 8b 1e 00 00       	call   213e0 <gpui_canvas::color::gamut::in_gamut>
   1f555:	84 c0                	test   %al,%al
   1f557:	74 1c                	je     1f575 <<gpui_canvas::color::Color>::fit_chroma+0x1a5>
   1f559:	0f 28 44 24 20       	movaps 0x20(%rsp),%xmm0
   1f55e:	f3 0f 11 43 08       	movss  %xmm0,0x8(%rbx)
   1f563:	44 89 63 0c          	mov    %r12d,0xc(%rbx)
   1f567:	44 89 7b 10          	mov    %r15d,0x10(%rbx)
   1f56b:	31 c0                	xor    %eax,%eax
   1f56d:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   1f573:	eb 0d                	jmp    1f582 <<gpui_canvas::color::Color>::fit_chroma+0x1b2>
   1f575:	b8 01 00 00 00       	mov    $0x1,%eax
   1f57a:	f3 0f 10 05 5e 60 fe 	movss  -0x19fa2(%rip),%xmm0        # 55e0 <std::thread::current::id::ID+0x4968>
   1f581:	ff 
   1f582:	f3 0f 11 43 04       	movss  %xmm0,0x4(%rbx)
   1f587:	e9 c7 fe ff ff       	jmp    1f453 <<gpui_canvas::color::Color>::fit_chroma+0x83>
   1f58c:	cc                   	int3
   1f58d:	cc                   	int3
   1f58e:	cc                   	int3
   1f58f:	cc                   	int3

gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>:
   1fa90:	55                   	push   %rbp
   1fa91:	41 57                	push   %r15
   1fa93:	41 56                	push   %r14
   1fa95:	41 54                	push   %r12
   1fa97:	53                   	push   %rbx
   1fa98:	48 81 ec a0 01 00 00 	sub    $0x1a0,%rsp
   1fa9f:	f3 0f 11 84 24 ac 00 	movss  %xmm0,0xac(%rsp)
   1faa6:	00 00 
   1faa8:	89 fb                	mov    %edi,%ebx
   1faaa:	0f 29 8c 24 50 01 00 	movaps %xmm1,0x150(%rsp)
   1fab1:	00 
   1fab2:	0f 57 c0             	xorps  %xmm0,%xmm0
   1fab5:	f3 0f 5a c1          	cvtss2sd %xmm1,%xmm0
   1fab9:	f2 0f 59 05 5f 75 fe 	mulsd  -0x18aa1(%rip),%xmm0        # 7020 <std::thread::current::id::ID+0x63a8>
   1fac0:	ff 
   1fac1:	48 8d bc 24 68 01 00 	lea    0x168(%rsp),%rdi
   1fac8:	00 
   1fac9:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
   1fad0:	00 
   1fad1:	ff 15 29 3d 04 00    	call   *0x43d29(%rip)        # 63800 <sincos@GLIBC_2.2.5>
   1fad7:	f2 0f 10 8c 24 68 01 	movsd  0x168(%rsp),%xmm1
   1fade:	00 00 
   1fae0:	f2 0f 10 94 24 60 01 	movsd  0x160(%rsp),%xmm2
   1fae7:	00 00 
   1fae9:	f2 0f 10 05 27 75 fe 	movsd  -0x18ad9(%rip),%xmm0        # 7018 <std::thread::current::id::ID+0x63a0>
   1faf0:	ff 
   1faf1:	f2 0f 59 c2          	mulsd  %xmm2,%xmm0
   1faf5:	66 0f 57 db          	xorpd  %xmm3,%xmm3
   1faf9:	f2 0f 58 c3          	addsd  %xmm3,%xmm0
   1fafd:	f2 0f 10 25 93 74 fe 	movsd  -0x18b6d(%rip),%xmm4        # 6f98 <std::thread::current::id::ID+0x6320>
   1fb04:	ff 
   1fb05:	f2 0f 59 e2          	mulsd  %xmm2,%xmm4
   1fb09:	f2 0f 58 e3          	addsd  %xmm3,%xmm4
   1fb0d:	f2 0f 10 2d b3 74 fe 	movsd  -0x18b4d(%rip),%xmm5        # 6fc8 <std::thread::current::id::ID+0x6350>
   1fb14:	ff 
   1fb15:	f2 0f 59 e9          	mulsd  %xmm1,%xmm5
   1fb19:	f2 0f 58 e8          	addsd  %xmm0,%xmm5
   1fb1d:	f2 0f 10 05 23 75 fe 	movsd  -0x18add(%rip),%xmm0        # 7048 <std::thread::current::id::ID+0x63d0>
   1fb24:	ff 
   1fb25:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   1fb29:	f2 0f 58 c4          	addsd  %xmm4,%xmm0
   1fb2d:	f2 0f 59 15 d3 74 fe 	mulsd  -0x18b2d(%rip),%xmm2        # 7008 <std::thread::current::id::ID+0x6390>
   1fb34:	ff 
   1fb35:	f2 0f 58 d3          	addsd  %xmm3,%xmm2
   1fb39:	f2 0f 59 0d 97 73 fe 	mulsd  -0x18c69(%rip),%xmm1        # 6ed8 <std::thread::current::id::ID+0x6260>
   1fb40:	ff 
   1fb41:	f2 0f 58 ca          	addsd  %xmm2,%xmm1
   1fb45:	85 db                	test   %ebx,%ebx
   1fb47:	74 35                	je     1fb7e <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xee>
   1fb49:	66 44 0f 28 2d 0e 56 	movapd -0x1a9f2(%rip),%xmm13        # 5160 <std::thread::current::id::ID+0x44e8>
   1fb50:	fe ff 
   1fb52:	66 0f 28 15 f6 59 fe 	movapd -0x1a60a(%rip),%xmm2        # 5550 <std::thread::current::id::ID+0x48d8>
   1fb59:	ff 
   1fb5a:	66 44 0f 28 1d 4d 5a 	movapd -0x1a5b3(%rip),%xmm11        # 55b0 <std::thread::current::id::ID+0x4938>
   1fb61:	fe ff 
   1fb63:	f3 0f 7e 25 a5 73 fe 	movq   -0x18c5b(%rip),%xmm4        # 6f10 <std::thread::current::id::ID+0x6298>
   1fb6a:	ff 
   1fb6b:	f3 0f 7e 3d 3d 74 fe 	movq   -0x18bc3(%rip),%xmm7        # 6fb0 <std::thread::current::id::ID+0x6338>
   1fb72:	ff 
   1fb73:	f3 44 0f 7e 05 9c 73 	movq   -0x18c64(%rip),%xmm8        # 6f18 <std::thread::current::id::ID+0x62a0>
   1fb7a:	fe ff 
   1fb7c:	eb 33                	jmp    1fbb1 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x121>
   1fb7e:	66 44 0f 28 2d 09 58 	movapd -0x1a7f7(%rip),%xmm13        # 5390 <std::thread::current::id::ID+0x4718>
   1fb85:	fe ff 
   1fb87:	66 0f 28 15 d1 58 fe 	movapd -0x1a72f(%rip),%xmm2        # 5460 <std::thread::current::id::ID+0x47e8>
   1fb8e:	ff 
   1fb8f:	66 44 0f 28 1d 98 57 	movapd -0x1a868(%rip),%xmm11        # 5330 <std::thread::current::id::ID+0x46b8>
   1fb96:	fe ff 
   1fb98:	f3 0f 7e 25 58 74 fe 	movq   -0x18ba8(%rip),%xmm4        # 6ff8 <std::thread::current::id::ID+0x6380>
   1fb9f:	ff 
   1fba0:	f3 0f 7e 3d 40 74 fe 	movq   -0x18bc0(%rip),%xmm7        # 6fe8 <std::thread::current::id::ID+0x6370>
   1fba7:	ff 
   1fba8:	f3 44 0f 7e 05 cf 73 	movq   -0x18c31(%rip),%xmm8        # 6f80 <std::thread::current::id::ID+0x6308>
   1fbaf:	fe ff 
   1fbb1:	f3 0f 7e f4          	movq   %xmm4,%xmm6
   1fbb5:	f3 0f 7e ff          	movq   %xmm7,%xmm7
   1fbb9:	f3 41 0f 7e e0       	movq   %xmm8,%xmm4
   1fbbe:	66 0f 14 e8          	unpcklpd %xmm0,%xmm5
   1fbc2:	66 0f 28 c5          	movapd %xmm5,%xmm0
   1fbc6:	66 0f 59 c5          	mulpd  %xmm5,%xmm0
   1fbca:	66 44 0f 28 c1       	movapd %xmm1,%xmm8
   1fbcf:	f2 44 0f 59 c1       	mulsd  %xmm1,%xmm8
   1fbd4:	f2 44 0f 59 c1       	mulsd  %xmm1,%xmm8
   1fbd9:	66 0f 59 c5          	mulpd  %xmm5,%xmm0
   1fbdd:	66 0f 29 44 24 40    	movapd %xmm0,0x40(%rsp)
   1fbe3:	f2 44 0f 11 44 24 50 	movsd  %xmm8,0x50(%rsp)
   1fbea:	f2 0f 10 44 24 40    	movsd  0x40(%rsp),%xmm0
   1fbf0:	66 0f 14 c0          	unpcklpd %xmm0,%xmm0
   1fbf4:	66 45 0f 28 c5       	movapd %xmm13,%xmm8
   1fbf9:	66 44 0f 59 c0       	mulpd  %xmm0,%xmm8
   1fbfe:	66 0f 59 c6          	mulpd  %xmm6,%xmm0
   1fc02:	66 44 0f 10 64 24 48 	movupd 0x48(%rsp),%xmm12
   1fc09:	66 45 0f 28 cc       	movapd %xmm12,%xmm9
   1fc0e:	66 45 0f 14 cc       	unpcklpd %xmm12,%xmm9
   1fc13:	66 44 0f 28 d2       	movapd %xmm2,%xmm10
   1fc18:	66 45 0f 59 d1       	mulpd  %xmm9,%xmm10
   1fc1d:	66 45 0f 58 d0       	addpd  %xmm8,%xmm10
   1fc22:	66 44 0f 59 cf       	mulpd  %xmm7,%xmm9
   1fc27:	66 44 0f 58 c8       	addpd  %xmm0,%xmm9
   1fc2c:	66 45 0f 15 e4       	unpckhpd %xmm12,%xmm12
   1fc31:	66 45 0f 28 f3       	movapd %xmm11,%xmm14
   1fc36:	66 45 0f 59 f4       	mulpd  %xmm12,%xmm14
   1fc3b:	66 45 0f 58 f2       	addpd  %xmm10,%xmm14
   1fc40:	66 44 0f 29 b4 24 c0 	movapd %xmm14,0xc0(%rsp)
   1fc47:	00 00 00 
   1fc4a:	66 44 0f 59 e4       	mulpd  %xmm4,%xmm12
   1fc4f:	66 45 0f 58 e1       	addpd  %xmm9,%xmm12
   1fc54:	66 44 0f 29 a4 24 f0 	movapd %xmm12,0xf0(%rsp)
   1fc5b:	00 00 00 
   1fc5e:	66 44 0f 28 c5       	movapd %xmm5,%xmm8
   1fc63:	66 44 0f 59 05 e4 55 	mulpd  -0x1aa1c(%rip),%xmm8        # 5250 <std::thread::current::id::ID+0x45d8>
   1fc6a:	fe ff 
   1fc6c:	f2 44 0f 10 0d 2b 73 	movsd  -0x18cd5(%rip),%xmm9        # 6fa0 <std::thread::current::id::ID+0x6328>
   1fc73:	fe ff 
   1fc75:	f2 44 0f 59 c9       	mulsd  %xmm1,%xmm9
   1fc7a:	f2 41 0f 59 c9       	mulsd  %xmm9,%xmm1
   1fc7f:	66 41 0f 59 e8       	mulpd  %xmm8,%xmm5
   1fc84:	66 0f 29 6c 24 40    	movapd %xmm5,0x40(%rsp)
   1fc8a:	f2 0f 11 4c 24 50    	movsd  %xmm1,0x50(%rsp)
   1fc90:	f2 0f 10 44 24 40    	movsd  0x40(%rsp),%xmm0
   1fc96:	66 0f 14 c0          	unpcklpd %xmm0,%xmm0
   1fc9a:	66 41 0f 28 cd       	movapd %xmm13,%xmm1
   1fc9f:	66 0f 59 c8          	mulpd  %xmm0,%xmm1
   1fca3:	66 0f 59 c6          	mulpd  %xmm6,%xmm0
   1fca7:	66 44 0f 10 7c 24 48 	movupd 0x48(%rsp),%xmm15
   1fcae:	66 41 0f 28 ef       	movapd %xmm15,%xmm5
   1fcb3:	66 41 0f 14 ef       	unpcklpd %xmm15,%xmm5
   1fcb8:	66 44 0f 28 d2       	movapd %xmm2,%xmm10
   1fcbd:	66 44 0f 59 d5       	mulpd  %xmm5,%xmm10
   1fcc2:	66 44 0f 58 d1       	addpd  %xmm1,%xmm10
   1fcc7:	66 0f 59 ef          	mulpd  %xmm7,%xmm5
   1fccb:	66 0f 58 e8          	addpd  %xmm0,%xmm5
   1fccf:	66 45 0f 15 ff       	unpckhpd %xmm15,%xmm15
   1fcd4:	66 41 0f 28 c3       	movapd %xmm11,%xmm0
   1fcd9:	66 41 0f 59 c7       	mulpd  %xmm15,%xmm0
   1fcde:	66 41 0f 58 c2       	addpd  %xmm10,%xmm0
   1fce3:	66 44 0f 28 d0       	movapd %xmm0,%xmm10
   1fce8:	66 0f 29 84 24 b0 00 	movapd %xmm0,0xb0(%rsp)
   1fcef:	00 00 
   1fcf1:	66 44 0f 59 fc       	mulpd  %xmm4,%xmm15
   1fcf6:	66 44 0f 58 fd       	addpd  %xmm5,%xmm15
   1fcfb:	66 44 0f 29 7c 24 60 	movapd %xmm15,0x60(%rsp)
   1fd02:	66 44 0f 29 44 24 40 	movapd %xmm8,0x40(%rsp)
   1fd09:	f2 44 0f 11 4c 24 50 	movsd  %xmm9,0x50(%rsp)
   1fd10:	f2 0f 10 44 24 40    	movsd  0x40(%rsp),%xmm0
   1fd16:	66 0f 14 c0          	unpcklpd %xmm0,%xmm0
   1fd1a:	66 41 0f 28 cd       	movapd %xmm13,%xmm1
   1fd1f:	66 0f 59 c8          	mulpd  %xmm0,%xmm1
   1fd23:	66 0f 59 c6          	mulpd  %xmm6,%xmm0
   1fd27:	66 44 0f 10 4c 24 48 	movupd 0x48(%rsp),%xmm9
   1fd2e:	66 41 0f 28 e9       	movapd %xmm9,%xmm5
   1fd33:	66 41 0f 14 e9       	unpcklpd %xmm9,%xmm5
   1fd38:	66 44 0f 28 c2       	movapd %xmm2,%xmm8
   1fd3d:	66 44 0f 59 c5       	mulpd  %xmm5,%xmm8
   1fd42:	66 44 0f 58 c1       	addpd  %xmm1,%xmm8
   1fd47:	66 0f 59 ef          	mulpd  %xmm7,%xmm5
   1fd4b:	66 0f 58 e8          	addpd  %xmm0,%xmm5
   1fd4f:	66 45 0f 15 c9       	unpckhpd %xmm9,%xmm9
   1fd54:	66 41 0f 28 db       	movapd %xmm11,%xmm3
   1fd59:	66 41 0f 59 d9       	mulpd  %xmm9,%xmm3
   1fd5e:	66 41 0f 58 d8       	addpd  %xmm8,%xmm3
   1fd63:	66 0f 29 9c 24 80 00 	movapd %xmm3,0x80(%rsp)
   1fd6a:	00 00 
   1fd6c:	66 44 0f 59 cc       	mulpd  %xmm4,%xmm9
   1fd71:	66 44 0f 58 cd       	addpd  %xmm5,%xmm9
   1fd76:	66 44 0f 29 0c 24    	movapd %xmm9,(%rsp)
   1fd7c:	0f 28 05 ed 56 fe ff 	movaps -0x1a913(%rip),%xmm0        # 5470 <std::thread::current::id::ID+0x47f8>
   1fd83:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
   1fd88:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
   1fd8f:	00 f0 3f 
   1fd92:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   1fd97:	66 0f 10 4c 24 48    	movupd 0x48(%rsp),%xmm1
   1fd9d:	66 0f 28 c1          	movapd %xmm1,%xmm0
   1fda1:	66 0f 14 c1          	unpcklpd %xmm1,%xmm0
   1fda5:	66 0f 59 d0          	mulpd  %xmm0,%xmm2
   1fda9:	66 0f 59 c7          	mulpd  %xmm7,%xmm0
   1fdad:	66 41 0f 58 d5       	addpd  %xmm13,%xmm2
   1fdb2:	66 0f 58 c6          	addpd  %xmm6,%xmm0
   1fdb6:	66 0f 15 c9          	unpckhpd %xmm1,%xmm1
   1fdba:	66 44 0f 59 d9       	mulpd  %xmm1,%xmm11
   1fdbf:	66 44 0f 58 da       	addpd  %xmm2,%xmm11
   1fdc4:	66 44 0f 29 9c 24 90 	movapd %xmm11,0x90(%rsp)
   1fdcb:	00 00 00 
   1fdce:	66 0f 59 cc          	mulpd  %xmm4,%xmm1
   1fdd2:	66 0f 58 c8          	addpd  %xmm0,%xmm1
   1fdd6:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
   1fdda:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   1fdde:	66 0f 16 15 72 71 fe 	movhpd -0x18e8e(%rip),%xmm2        # 6f58 <std::thread::current::id::ID+0x62e0>
   1fde5:	ff 
   1fde6:	66 0f 58 d1          	addpd  %xmm1,%xmm2
   1fdea:	66 0f 29 54 24 20    	movapd %xmm2,0x20(%rsp)
   1fdf0:	66 41 0f 28 ce       	movapd %xmm14,%xmm1
   1fdf5:	66 44 0f 28 35 52 54 	movapd -0x1abae(%rip),%xmm14        # 5250 <std::thread::current::id::ID+0x45d8>
   1fdfc:	fe ff 
   1fdfe:	66 41 0f 59 ce       	mulpd  %xmm14,%xmm1
   1fe03:	66 0f 28 f1          	movapd %xmm1,%xmm6
   1fe07:	66 45 0f 59 f4       	mulpd  %xmm12,%xmm14
   1fe0c:	66 45 0f 28 da       	movapd %xmm10,%xmm11
   1fe11:	66 45 0f 58 da       	addpd  %xmm10,%xmm11
   1fe16:	66 41 0f 28 cf       	movapd %xmm15,%xmm1
   1fe1b:	66 41 0f 58 cf       	addpd  %xmm15,%xmm1
   1fe20:	66 45 0f 28 c3       	movapd %xmm11,%xmm8
   1fe25:	66 45 0f 59 c3       	mulpd  %xmm11,%xmm8
   1fe2a:	66 0f 28 d6          	movapd %xmm6,%xmm2
   1fe2e:	66 0f 59 d3          	mulpd  %xmm3,%xmm2
   1fe32:	66 0f 28 2d 56 54 fe 	movapd -0x1abaa(%rip),%xmm5        # 5290 <std::thread::current::id::ID+0x4618>
   1fe39:	ff 
   1fe3a:	66 0f 59 d5          	mulpd  %xmm5,%xmm2
   1fe3e:	66 44 0f 5c c2       	subpd  %xmm2,%xmm8
   1fe43:	66 41 0f 28 d6       	movapd %xmm14,%xmm2
   1fe48:	66 45 0f 28 fe       	movapd %xmm14,%xmm15
   1fe4d:	66 44 0f 29 74 24 70 	movapd %xmm14,0x70(%rsp)
   1fe54:	66 41 0f 59 d1       	mulpd  %xmm9,%xmm2
   1fe59:	66 0f 59 d5          	mulpd  %xmm5,%xmm2
   1fe5d:	66 44 0f 28 d1       	movapd %xmm1,%xmm10
   1fe62:	66 44 0f 59 d1       	mulpd  %xmm1,%xmm10
   1fe67:	66 44 0f 5c d2       	subpd  %xmm2,%xmm10
   1fe6c:	66 41 0f 28 eb       	movapd %xmm11,%xmm5
   1fe71:	66 0f c2 e8 01       	cmpltpd %xmm0,%xmm5
   1fe76:	66 0f 28 15 42 57 fe 	movapd -0x1a8be(%rip),%xmm2        # 55c0 <std::thread::current::id::ID+0x4948>
   1fe7d:	ff 
   1fe7e:	66 0f 28 fd          	movapd %xmm5,%xmm7
   1fe82:	66 0f 54 fa          	andpd  %xmm2,%xmm7
   1fe86:	66 0f 28 25 e2 55 fe 	movapd -0x1aa1e(%rip),%xmm4        # 5470 <std::thread::current::id::ID+0x47f8>
   1fe8d:	ff 
   1fe8e:	66 0f 55 ec          	andnpd %xmm4,%xmm5
   1fe92:	66 0f 56 ef          	orpd   %xmm7,%xmm5
   1fe96:	66 44 0f 28 e1       	movapd %xmm1,%xmm12
   1fe9b:	66 0f 28 f9          	movapd %xmm1,%xmm7
   1fe9f:	66 44 0f c2 e0 01    	cmpltpd %xmm0,%xmm12
   1fea5:	66 41 0f 54 d4       	andpd  %xmm12,%xmm2
   1feaa:	66 44 0f 55 e4       	andnpd %xmm4,%xmm12
   1feaf:	66 44 0f 56 e2       	orpd   %xmm2,%xmm12
   1feb4:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   1feb8:	66 41 0f c2 c8 02    	cmplepd %xmm8,%xmm1
   1febe:	66 0f 29 4c 24 30    	movapd %xmm1,0x30(%rsp)
   1fec4:	66 44 0f 5f c0       	maxpd  %xmm0,%xmm8
   1fec9:	66 45 0f 51 c8       	sqrtpd %xmm8,%xmm9
   1fece:	66 44 0f 59 cd       	mulpd  %xmm5,%xmm9
   1fed3:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   1fed7:	66 41 0f c2 ca 02    	cmplepd %xmm10,%xmm1
   1fedd:	66 0f 29 4c 24 10    	movapd %xmm1,0x10(%rsp)
   1fee3:	66 44 0f 5f d0       	maxpd  %xmm0,%xmm10
   1fee8:	66 45 0f 51 d2       	sqrtpd %xmm10,%xmm10
   1feed:	66 45 0f 59 d4       	mulpd  %xmm12,%xmm10
   1fef2:	66 45 0f 58 cb       	addpd  %xmm11,%xmm9
   1fef7:	66 44 0f 58 d7       	addpd  %xmm7,%xmm10
   1fefc:	66 0f 28 15 cc 56 fe 	movapd -0x1a934(%rip),%xmm2        # 55d0 <std::thread::current::id::ID+0x4958>
   1ff03:	ff 
   1ff04:	66 44 0f 59 ca       	mulpd  %xmm2,%xmm9
   1ff09:	66 44 0f 59 d2       	mulpd  %xmm2,%xmm10
   1ff0e:	66 0f 29 b4 24 40 01 	movapd %xmm6,0x140(%rsp)
   1ff15:	00 00 
   1ff17:	66 0f 28 d6          	movapd %xmm6,%xmm2
   1ff1b:	66 0f c2 d0 00       	cmpeqpd %xmm0,%xmm2
   1ff20:	66 45 0f 28 eb       	movapd %xmm11,%xmm13
   1ff25:	66 44 0f c2 e8 00    	cmpeqpd %xmm0,%xmm13
   1ff2b:	66 45 0f 28 c5       	movapd %xmm13,%xmm8
   1ff30:	66 45 0f 55 eb       	andnpd %xmm11,%xmm13
   1ff35:	66 44 0f c2 d8 04    	cmpneqpd %xmm0,%xmm11
   1ff3b:	66 44 0f 54 da       	andpd  %xmm2,%xmm11
   1ff40:	66 44 0f 28 f2       	movapd %xmm2,%xmm14
   1ff45:	66 0f 54 d4          	andpd  %xmm4,%xmm2
   1ff49:	66 44 0f 55 f6       	andnpd %xmm6,%xmm14
   1ff4e:	66 44 0f 56 f2       	orpd   %xmm2,%xmm14
   1ff53:	66 44 0f c2 f8 00    	cmpeqpd %xmm0,%xmm15
   1ff59:	66 41 0f 28 cf       	movapd %xmm15,%xmm1
   1ff5e:	66 0f 54 cc          	andpd  %xmm4,%xmm1
   1ff62:	66 41 0f 28 d9       	movapd %xmm9,%xmm3
   1ff67:	66 0f c2 d8 00       	cmpeqpd %xmm0,%xmm3
   1ff6c:	66 41 0f 28 f2       	movapd %xmm10,%xmm6
   1ff71:	66 0f c2 f0 00       	cmpeqpd %xmm0,%xmm6
   1ff76:	66 0f 28 eb          	movapd %xmm3,%xmm5
   1ff7a:	66 0f 54 ec          	andpd  %xmm4,%xmm5
   1ff7e:	66 44 0f 28 e6       	movapd %xmm6,%xmm12
   1ff83:	66 44 0f 54 e4       	andpd  %xmm4,%xmm12
   1ff88:	66 0f 28 d7          	movapd %xmm7,%xmm2
   1ff8c:	66 0f c2 d0 00       	cmpeqpd %xmm0,%xmm2
   1ff91:	66 44 0f 54 c4       	andpd  %xmm4,%xmm8
   1ff96:	66 0f 54 e2          	andpd  %xmm2,%xmm4
   1ff9a:	66 0f 55 d7          	andnpd %xmm7,%xmm2
   1ff9e:	66 0f c2 f8 04       	cmpneqpd %xmm0,%xmm7
   1ffa3:	66 41 0f 54 ff       	andpd  %xmm15,%xmm7
   1ffa8:	66 0f 29 bc 24 e0 00 	movapd %xmm7,0xe0(%rsp)
   1ffaf:	00 00 
   1ffb1:	66 0f 28 7c 24 70    	movapd 0x70(%rsp),%xmm7
   1ffb7:	66 44 0f 55 ff       	andnpd %xmm7,%xmm15
   1ffbc:	66 44 0f 56 f9       	orpd   %xmm1,%xmm15
   1ffc1:	66 41 0f 55 d9       	andnpd %xmm9,%xmm3
   1ffc6:	66 0f 56 dd          	orpd   %xmm5,%xmm3
   1ffca:	66 41 0f 55 f2       	andnpd %xmm10,%xmm6
   1ffcf:	66 41 0f 56 f4       	orpd   %xmm12,%xmm6
   1ffd4:	66 45 0f 56 e8       	orpd   %xmm8,%xmm13
   1ffd9:	66 0f 56 d4          	orpd   %xmm4,%xmm2
   1ffdd:	66 0f 28 8c 24 40 01 	movapd 0x140(%rsp),%xmm1
   1ffe4:	00 00 
   1ffe6:	66 0f c2 c8 04       	cmpneqpd %xmm0,%xmm1
   1ffeb:	66 0f 28 64 24 30    	movapd 0x30(%rsp),%xmm4
   1fff1:	66 0f 54 e1          	andpd  %xmm1,%xmm4
   1fff5:	66 0f 29 64 24 30    	movapd %xmm4,0x30(%rsp)
   1fffb:	66 0f c2 f8 04       	cmpneqpd %xmm0,%xmm7
   20000:	66 0f 28 4c 24 10    	movapd 0x10(%rsp),%xmm1
   20006:	66 0f 54 cf          	andpd  %xmm7,%xmm1
   2000a:	66 0f 29 4c 24 10    	movapd %xmm1,0x10(%rsp)
   20010:	66 41 0f 28 e1       	movapd %xmm9,%xmm4
   20015:	66 41 0f 5e e6       	divpd  %xmm14,%xmm4
   2001a:	66 41 0f 28 ca       	movapd %xmm10,%xmm1
   2001f:	66 41 0f 5e cf       	divpd  %xmm15,%xmm1
   20024:	66 44 0f 28 bc 24 b0 	movapd 0xb0(%rsp),%xmm15
   2002b:	00 00 00 
   2002e:	66 44 0f 28 35 f9 54 	movapd -0x1ab07(%rip),%xmm14        # 5530 <std::thread::current::id::ID+0x48b8>
   20035:	fe ff 
   20037:	66 0f 28 bc 24 80 00 	movapd 0x80(%rsp),%xmm7
   2003e:	00 00 
   20040:	66 0f 28 ef          	movapd %xmm7,%xmm5
   20044:	66 41 0f 57 ee       	xorpd  %xmm14,%xmm5
   20049:	66 41 0f 5e ed       	divpd  %xmm13,%xmm5
   2004e:	66 44 0f 28 6c 24 60 	movapd 0x60(%rsp),%xmm13
   20055:	66 44 0f 28 04 24    	movapd (%rsp),%xmm8
   2005b:	66 45 0f 28 e0       	movapd %xmm8,%xmm12
   20060:	66 45 0f 57 e6       	xorpd  %xmm14,%xmm12
   20065:	66 44 0f 5e e2       	divpd  %xmm2,%xmm12
   2006a:	66 41 0f 54 eb       	andpd  %xmm11,%xmm5
   2006f:	66 44 0f 28 35 78 54 	movapd -0x1ab88(%rip),%xmm14        # 54f0 <std::thread::current::id::ID+0x4878>
   20076:	fe ff 
   20078:	66 45 0f 55 de       	andnpd %xmm14,%xmm11
   2007d:	66 44 0f 56 dd       	orpd   %xmm5,%xmm11
   20082:	66 0f 28 94 24 e0 00 	movapd 0xe0(%rsp),%xmm2
   20089:	00 00 
   2008b:	66 44 0f 54 e2       	andpd  %xmm2,%xmm12
   20090:	66 41 0f 55 d6       	andnpd %xmm14,%xmm2
   20095:	66 41 0f 56 d4       	orpd   %xmm12,%xmm2
   2009a:	66 0f 28 ef          	movapd %xmm7,%xmm5
   2009e:	66 0f 28 7c 24 30    	movapd 0x30(%rsp),%xmm7
   200a4:	66 0f 54 e7          	andpd  %xmm7,%xmm4
   200a8:	66 44 0f c2 c8 04    	cmpneqpd %xmm0,%xmm9
   200ae:	66 44 0f 54 cf       	andpd  %xmm7,%xmm9
   200b3:	66 41 0f 55 fb       	andnpd %xmm11,%xmm7
   200b8:	66 0f 56 fc          	orpd   %xmm4,%xmm7
   200bc:	66 44 0f 28 5c 24 10 	movapd 0x10(%rsp),%xmm11
   200c3:	66 41 0f 54 cb       	andpd  %xmm11,%xmm1
   200c8:	66 44 0f c2 d0 04    	cmpneqpd %xmm0,%xmm10
   200ce:	66 45 0f 54 d3       	andpd  %xmm11,%xmm10
   200d3:	66 44 0f 55 da       	andnpd %xmm2,%xmm11
   200d8:	66 44 0f 56 d9       	orpd   %xmm1,%xmm11
   200dd:	66 0f 28 cd          	movapd %xmm5,%xmm1
   200e1:	66 0f 5e cb          	divpd  %xmm3,%xmm1
   200e5:	66 41 0f 28 d0       	movapd %xmm8,%xmm2
   200ea:	66 0f 5e d6          	divpd  %xmm6,%xmm2
   200ee:	66 41 0f 54 c9       	andpd  %xmm9,%xmm1
   200f3:	66 45 0f 55 ce       	andnpd %xmm14,%xmm9
   200f8:	66 44 0f 56 c9       	orpd   %xmm1,%xmm9
   200fd:	66 41 0f 54 d2       	andpd  %xmm10,%xmm2
   20102:	66 45 0f 55 d6       	andnpd %xmm14,%xmm10
   20107:	66 44 0f 56 d2       	orpd   %xmm2,%xmm10
   2010c:	66 45 0f 57 c0       	xorpd  %xmm8,%xmm8
   20111:	66 44 0f c2 c7 01    	cmpltpd %xmm7,%xmm8
   20117:	66 41 0f 54 f8       	andpd  %xmm8,%xmm7
   2011c:	66 45 0f 55 c6       	andnpd %xmm14,%xmm8
   20121:	66 44 0f 56 c7       	orpd   %xmm7,%xmm8
   20126:	66 45 0f 57 e4       	xorpd  %xmm12,%xmm12
   2012b:	66 45 0f c2 e3 01    	cmpltpd %xmm11,%xmm12
   20131:	66 45 0f 54 dc       	andpd  %xmm12,%xmm11
   20136:	66 45 0f 55 e6       	andnpd %xmm14,%xmm12
   2013b:	66 45 0f 56 e3       	orpd   %xmm11,%xmm12
   20140:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   20144:	66 41 0f c2 c9 01    	cmpltpd %xmm9,%xmm1
   2014a:	66 44 0f 54 c9       	andpd  %xmm1,%xmm9
   2014f:	66 41 0f 55 ce       	andnpd %xmm14,%xmm1
   20154:	66 41 0f 56 c9       	orpd   %xmm9,%xmm1
   20159:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   2015d:	66 41 0f c2 d2 01    	cmpltpd %xmm10,%xmm2
   20163:	66 44 0f 54 d2       	andpd  %xmm2,%xmm10
   20168:	66 41 0f 55 d6       	andnpd %xmm14,%xmm2
   2016d:	66 41 0f 56 d2       	orpd   %xmm10,%xmm2
   20172:	66 41 0f 28 d8       	movapd %xmm8,%xmm3
   20177:	66 0f 5d d9          	minpd  %xmm1,%xmm3
   2017b:	66 0f 29 9c 24 30 01 	movapd %xmm3,0x130(%rsp)
   20182:	00 00 
   20184:	66 44 0f 5f c1       	maxpd  %xmm1,%xmm8
   20189:	66 41 0f 28 cc       	movapd %xmm12,%xmm1
   2018e:	66 0f 5d ca          	minpd  %xmm2,%xmm1
   20192:	66 0f 29 8c 24 20 01 	movapd %xmm1,0x120(%rsp)
   20199:	00 00 
   2019b:	66 44 0f 5f e2       	maxpd  %xmm2,%xmm12
   201a0:	66 41 0f 28 ef       	movapd %xmm15,%xmm5
   201a5:	66 0f c2 e8 04       	cmpneqpd %xmm0,%xmm5
   201aa:	66 0f 28 35 4e 4f fe 	movapd -0x1b0b2(%rip),%xmm6        # 5100 <std::thread::current::id::ID+0x4488>
   201b1:	ff 
   201b2:	66 41 0f 28 e7       	movapd %xmm15,%xmm4
   201b7:	66 0f 54 e6          	andpd  %xmm6,%xmm4
   201bb:	66 44 0f 28 b4 24 80 	movapd 0x80(%rsp),%xmm14
   201c2:	00 00 00 
   201c5:	66 41 0f 28 de       	movapd %xmm14,%xmm3
   201ca:	66 0f 54 de          	andpd  %xmm6,%xmm3
   201ce:	66 0f 28 cd          	movapd %xmm5,%xmm1
   201d2:	66 0f 54 cc          	andpd  %xmm4,%xmm1
   201d6:	66 0f 55 eb          	andnpd %xmm3,%xmm5
   201da:	66 0f 56 e9          	orpd   %xmm1,%xmm5
   201de:	66 41 0f 28 cd       	movapd %xmm13,%xmm1
   201e3:	66 0f c2 c8 04       	cmpneqpd %xmm0,%xmm1
   201e8:	66 45 0f 28 dd       	movapd %xmm13,%xmm11
   201ed:	66 44 0f 54 de       	andpd  %xmm6,%xmm11
   201f2:	66 0f 28 3c 24       	movapd (%rsp),%xmm7
   201f7:	66 0f 54 fe          	andpd  %xmm6,%xmm7
   201fb:	66 44 0f 28 c9       	movapd %xmm1,%xmm9
   20200:	66 45 0f 54 cb       	andpd  %xmm11,%xmm9
   20205:	66 0f 55 cf          	andnpd %xmm7,%xmm1
   20209:	66 41 0f 56 c9       	orpd   %xmm9,%xmm1
   2020e:	66 44 0f 28 94 24 c0 	movapd 0xc0(%rsp),%xmm10
   20215:	00 00 00 
   20218:	66 45 0f 28 ca       	movapd %xmm10,%xmm9
   2021d:	66 44 0f c2 c8 04    	cmpneqpd %xmm0,%xmm9
   20223:	66 44 0f 54 d6       	andpd  %xmm6,%xmm10
   20228:	66 45 0f 54 d1       	andpd  %xmm9,%xmm10
   2022d:	66 44 0f 55 cd       	andnpd %xmm5,%xmm9
   20232:	66 45 0f 56 ca       	orpd   %xmm10,%xmm9
   20237:	66 0f 28 94 24 f0 00 	movapd 0xf0(%rsp),%xmm2
   2023e:	00 00 
   20240:	66 0f 28 ea          	movapd %xmm2,%xmm5
   20244:	66 0f c2 e8 04       	cmpneqpd %xmm0,%xmm5
   20249:	66 44 0f 28 d2       	movapd %xmm2,%xmm10
   2024e:	66 44 0f 54 d6       	andpd  %xmm6,%xmm10
   20253:	66 44 0f 54 d5       	andpd  %xmm5,%xmm10
   20258:	66 0f 55 e9          	andnpd %xmm1,%xmm5
   2025c:	66 41 0f 56 ea       	orpd   %xmm10,%xmm5
   20261:	66 0f 28 0d 07 4f fe 	movapd -0x1b0f9(%rip),%xmm1        # 5170 <std::thread::current::id::ID+0x44f8>
   20268:	ff 
   20269:	66 44 0f 5f c9       	maxpd  %xmm1,%xmm9
   2026e:	66 0f 5f e9          	maxpd  %xmm1,%xmm5
   20272:	66 0f 5f e3          	maxpd  %xmm3,%xmm4
   20276:	66 44 0f 5f df       	maxpd  %xmm7,%xmm11
   2027b:	66 0f 28 bc 24 90 00 	movapd 0x90(%rsp),%xmm7
   20282:	00 00 
   20284:	66 0f 28 cf          	movapd %xmm7,%xmm1
   20288:	66 0f 54 ce          	andpd  %xmm6,%xmm1
   2028c:	66 0f 5f e1          	maxpd  %xmm1,%xmm4
   20290:	66 41 0f 5e e1       	divpd  %xmm9,%xmm4
   20295:	66 0f 28 5c 24 20    	movapd 0x20(%rsp),%xmm3
   2029b:	66 0f 54 f3          	andpd  %xmm3,%xmm6
   2029f:	66 44 0f 5f de       	maxpd  %xmm6,%xmm11
   202a4:	66 41 0f 28 f6       	movapd %xmm14,%xmm6
   202a9:	66 44 0f 5e dd       	divpd  %xmm5,%xmm11
   202ae:	66 0f 28 0d ba 51 fe 	movapd -0x1ae46(%rip),%xmm1        # 5470 <std::thread::current::id::ID+0x47f8>
   202b5:	ff 
   202b6:	66 0f 58 e1          	addpd  %xmm1,%xmm4
   202ba:	66 44 0f 58 d9       	addpd  %xmm1,%xmm11
   202bf:	66 0f 28 cf          	movapd %xmm7,%xmm1
   202c3:	66 0f 28 ef          	movapd %xmm7,%xmm5
   202c7:	66 44 0f 28 15 60 52 	movapd -0x1ada0(%rip),%xmm10        # 5530 <std::thread::current::id::ID+0x48b8>
   202ce:	fe ff 
   202d0:	66 41 0f 57 ca       	xorpd  %xmm10,%xmm1
   202d5:	66 0f 57 ff          	xorpd  %xmm7,%xmm7
   202d9:	66 0f c2 f9 01       	cmpltpd %xmm1,%xmm7
   202de:	66 44 0f 28 8c 24 c0 	movapd 0xc0(%rsp),%xmm9
   202e5:	00 00 00 
   202e8:	66 45 0f 57 ca       	xorpd  %xmm10,%xmm9
   202ed:	66 41 0f 57 d2       	xorpd  %xmm10,%xmm2
   202f2:	66 44 0f 57 d3       	xorpd  %xmm3,%xmm10
   202f7:	66 45 0f 57 f6       	xorpd  %xmm14,%xmm14
   202fc:	66 45 0f c2 f2 01    	cmpltpd %xmm10,%xmm14
   20302:	66 0f 28 9c 24 30 01 	movapd 0x130(%rsp),%xmm3
   20309:	00 00 
   2030b:	66 0f 5d dc          	minpd  %xmm4,%xmm3
   2030f:	66 0f 28 cb          	movapd %xmm3,%xmm1
   20313:	66 41 0f 59 c9       	mulpd  %xmm9,%xmm1
   20318:	66 41 0f 5c cf       	subpd  %xmm15,%xmm1
   2031d:	66 0f 59 cb          	mulpd  %xmm3,%xmm1
   20321:	66 0f 5c ce          	subpd  %xmm6,%xmm1
   20325:	66 0f 59 cb          	mulpd  %xmm3,%xmm1
   20329:	66 0f 5c cd          	subpd  %xmm5,%xmm1
   2032d:	66 0f 57 ed          	xorpd  %xmm5,%xmm5
   20331:	66 0f c2 e9 01       	cmpltpd %xmm1,%xmm5
   20336:	66 44 0f 28 94 24 20 	movapd 0x120(%rsp),%xmm10
   2033d:	01 00 00 
   20340:	66 45 0f 5d d3       	minpd  %xmm11,%xmm10
   20345:	66 41 0f 28 ca       	movapd %xmm10,%xmm1
   2034a:	66 0f 29 54 24 30    	movapd %xmm2,0x30(%rsp)
   20350:	66 0f 59 ca          	mulpd  %xmm2,%xmm1
   20354:	66 41 0f 5c cd       	subpd  %xmm13,%xmm1
   20359:	66 41 0f 59 ca       	mulpd  %xmm10,%xmm1
   2035e:	66 0f 5c 0c 24       	subpd  (%rsp),%xmm1
   20363:	66 41 0f 59 ca       	mulpd  %xmm10,%xmm1
   20368:	66 0f 5c 4c 24 20    	subpd  0x20(%rsp),%xmm1
   2036e:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   20372:	66 0f c2 d1 01       	cmpltpd %xmm1,%xmm2
   20377:	66 0f 28 0d 71 51 fe 	movapd -0x1ae8f(%rip),%xmm1        # 54f0 <std::thread::current::id::ID+0x4878>
   2037e:	ff 
   2037f:	66 0f 55 f9          	andnpd %xmm1,%xmm7
   20383:	66 44 0f 55 f1       	andnpd %xmm1,%xmm14
   20388:	66 44 0f 29 84 24 10 	movapd %xmm8,0x110(%rsp)
   2038f:	01 00 00 
   20392:	66 0f 29 a4 24 90 01 	movapd %xmm4,0x190(%rsp)
   20399:	00 00 
   2039b:	66 44 0f 5d c4       	minpd  %xmm4,%xmm8
   203a0:	66 44 0f 29 a4 24 00 	movapd %xmm12,0x100(%rsp)
   203a7:	01 00 00 
   203aa:	66 41 0f 28 e4       	movapd %xmm12,%xmm4
   203af:	66 41 0f 5d e3       	minpd  %xmm11,%xmm4
   203b4:	66 0f 28 0d 34 51 fe 	movapd -0x1aecc(%rip),%xmm1        # 54f0 <std::thread::current::id::ID+0x4878>
   203bb:	ff 
   203bc:	66 0f 29 bc 24 d0 00 	movapd %xmm7,0xd0(%rsp)
   203c3:	00 00 
   203c5:	66 44 0f 28 e7       	movapd %xmm7,%xmm12
   203ca:	66 44 0f c2 e1 00    	cmpeqpd %xmm1,%xmm12
   203d0:	66 44 0f 29 74 24 70 	movapd %xmm14,0x70(%rsp)
   203d7:	66 44 0f c2 f1 00    	cmpeqpd %xmm1,%xmm14
   203dd:	66 41 0f 54 ec       	andpd  %xmm12,%xmm5
   203e2:	66 41 0f 54 d6       	andpd  %xmm14,%xmm2
   203e7:	66 0f 50 c5          	movmskpd %xmm5,%eax
   203eb:	66 0f 50 ca          	movmskpd %xmm2,%ecx
   203ef:	c1 e1 02             	shl    $0x2,%ecx
   203f2:	83 e1 04             	and    $0x4,%ecx
   203f5:	09 c1                	or     %eax,%ecx
   203f7:	66 44 0f 29 4c 24 10 	movapd %xmm9,0x10(%rsp)
   203fe:	66 44 0f 29 9c 24 70 	movapd %xmm11,0x170(%rsp)
   20405:	01 00 00 
   20408:	0f 84 e9 01 00 00    	je     205f7 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xb67>
   2040e:	66 0f 29 a4 24 80 01 	movapd %xmm4,0x180(%rsp)
   20415:	00 00 
   20417:	b8 60 00 00 00       	mov    $0x60,%eax
   2041c:	66 45 0f 28 e2       	movapd %xmm10,%xmm12
   20421:	66 44 0f 28 db       	movapd %xmm3,%xmm11
   20426:	66 45 0f 57 f6       	xorpd  %xmm14,%xmm14
   2042b:	66 0f 29 ac 24 e0 00 	movapd %xmm5,0xe0(%rsp)
   20432:	00 00 
   20434:	66 0f 29 94 24 40 01 	movapd %xmm2,0x140(%rsp)
   2043b:	00 00 
   2043d:	0f 1f 00             	nopl   (%rax)
   20440:	66 41 0f 28 cb       	movapd %xmm11,%xmm1
   20445:	66 41 0f 5c ce       	subpd  %xmm14,%xmm1
   2044a:	66 41 0f 28 f4       	movapd %xmm12,%xmm6
   2044f:	66 0f 5c f0          	subpd  %xmm0,%xmm6
   20453:	66 0f 28 15 95 4d fe 	movapd -0x1b26b(%rip),%xmm2        # 51f0 <std::thread::current::id::ID+0x4578>
   2045a:	ff 
   2045b:	66 0f 59 ca          	mulpd  %xmm2,%xmm1
   2045f:	66 0f 59 f2          	mulpd  %xmm2,%xmm6
   20463:	66 41 0f 58 ce       	addpd  %xmm14,%xmm1
   20468:	66 0f 58 f0          	addpd  %xmm0,%xmm6
   2046c:	66 0f 28 d1          	movapd %xmm1,%xmm2
   20470:	66 41 0f 59 d1       	mulpd  %xmm9,%xmm2
   20475:	66 44 0f 28 ce       	movapd %xmm6,%xmm9
   2047a:	66 44 0f 59 4c 24 30 	mulpd  0x30(%rsp),%xmm9
   20481:	66 41 0f 5c d7       	subpd  %xmm15,%xmm2
   20486:	66 45 0f 5c cd       	subpd  %xmm13,%xmm9
   2048b:	66 0f 59 d1          	mulpd  %xmm1,%xmm2
   2048f:	66 44 0f 59 ce       	mulpd  %xmm6,%xmm9
   20494:	66 0f 5c 94 24 80 00 	subpd  0x80(%rsp),%xmm2
   2049b:	00 00 
   2049d:	66 44 0f 5c 0c 24    	subpd  (%rsp),%xmm9
   204a3:	66 0f 59 d1          	mulpd  %xmm1,%xmm2
   204a7:	66 44 0f 59 ce       	mulpd  %xmm6,%xmm9
   204ac:	66 0f 5c 94 24 90 00 	subpd  0x90(%rsp),%xmm2
   204b3:	00 00 
   204b5:	66 44 0f 5c 4c 24 20 	subpd  0x20(%rsp),%xmm9
   204bc:	66 0f 57 ed          	xorpd  %xmm5,%xmm5
   204c0:	66 0f c2 ea 01       	cmpltpd %xmm2,%xmm5
   204c5:	66 41 0f 28 ff       	movapd %xmm15,%xmm7
   204ca:	66 45 0f 57 ff       	xorpd  %xmm15,%xmm15
   204cf:	66 45 0f c2 f9 01    	cmpltpd %xmm9,%xmm15
   204d5:	66 0f 28 e0          	movapd %xmm0,%xmm4
   204d9:	66 0f 28 84 24 e0 00 	movapd 0xe0(%rsp),%xmm0
   204e0:	00 00 
   204e2:	66 44 0f 28 e8       	movapd %xmm0,%xmm13
   204e7:	66 44 0f 54 ed       	andpd  %xmm5,%xmm13
   204ec:	66 41 0f 28 d5       	movapd %xmm13,%xmm2
   204f1:	66 45 0f 55 eb       	andnpd %xmm11,%xmm13
   204f6:	66 44 0f 28 9c 24 40 	movapd 0x140(%rsp),%xmm11
   204fd:	01 00 00 
   20500:	66 45 0f 28 cb       	movapd %xmm11,%xmm9
   20505:	66 45 0f 54 cf       	andpd  %xmm15,%xmm9
   2050a:	66 0f 54 d1          	andpd  %xmm1,%xmm2
   2050e:	66 44 0f 56 ea       	orpd   %xmm2,%xmm13
   20513:	66 41 0f 28 d1       	movapd %xmm9,%xmm2
   20518:	66 45 0f 55 cc       	andnpd %xmm12,%xmm9
   2051d:	66 0f 54 d6          	andpd  %xmm6,%xmm2
   20521:	66 44 0f 56 ca       	orpd   %xmm2,%xmm9
   20526:	66 0f 55 e8          	andnpd %xmm0,%xmm5
   2052a:	66 0f 54 cd          	andpd  %xmm5,%xmm1
   2052e:	66 41 0f 55 ee       	andnpd %xmm14,%xmm5
   20533:	66 44 0f 28 f5       	movapd %xmm5,%xmm14
   20538:	66 44 0f 56 f1       	orpd   %xmm1,%xmm14
   2053d:	66 45 0f 55 fb       	andnpd %xmm11,%xmm15
   20542:	66 41 0f 54 f7       	andpd  %xmm15,%xmm6
   20547:	66 44 0f 55 fc       	andnpd %xmm4,%xmm15
   2054c:	66 41 0f 28 c7       	movapd %xmm15,%xmm0
   20551:	66 44 0f 28 ff       	movapd %xmm7,%xmm15
   20556:	66 0f 56 c6          	orpd   %xmm6,%xmm0
   2055a:	66 45 0f 28 e1       	movapd %xmm9,%xmm12
   2055f:	66 44 0f 28 4c 24 10 	movapd 0x10(%rsp),%xmm9
   20566:	66 45 0f 28 dd       	movapd %xmm13,%xmm11
   2056b:	66 44 0f 28 6c 24 60 	movapd 0x60(%rsp),%xmm13
   20572:	48 ff c8             	dec    %rax
   20575:	0f 85 c5 fe ff ff    	jne    20440 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x9b0>
   2057b:	66 0f 28 8c 24 e0 00 	movapd 0xe0(%rsp),%xmm1
   20582:	00 00 
   20584:	66 44 0f 54 f1       	andpd  %xmm1,%xmm14
   20589:	66 0f 55 8c 24 d0 00 	andnpd 0xd0(%rsp),%xmm1
   20590:	00 00 
   20592:	66 41 0f 56 ce       	orpd   %xmm14,%xmm1
   20597:	66 0f 28 94 24 40 01 	movapd 0x140(%rsp),%xmm2
   2059e:	00 00 
   205a0:	66 0f 54 c2          	andpd  %xmm2,%xmm0
   205a4:	66 0f 55 54 24 70    	andnpd 0x70(%rsp),%xmm2
   205aa:	66 0f 56 d0          	orpd   %xmm0,%xmm2
   205ae:	66 44 0f 28 e1       	movapd %xmm1,%xmm12
   205b3:	66 0f 28 05 35 4f fe 	movapd -0x1b0cb(%rip),%xmm0        # 54f0 <std::thread::current::id::ID+0x4878>
   205ba:	ff 
   205bb:	66 44 0f c2 e0 00    	cmpeqpd %xmm0,%xmm12
   205c1:	66 44 0f 28 f2       	movapd %xmm2,%xmm14
   205c6:	66 44 0f c2 f0 00    	cmpeqpd %xmm0,%xmm14
   205cc:	66 0f 29 54 24 70    	movapd %xmm2,0x70(%rsp)
   205d2:	66 0f 29 8c 24 d0 00 	movapd %xmm1,0xd0(%rsp)
   205d9:	00 00 
   205db:	66 0f 28 b4 24 80 00 	movapd 0x80(%rsp),%xmm6
   205e2:	00 00 
   205e4:	66 44 0f 28 9c 24 70 	movapd 0x170(%rsp),%xmm11
   205eb:	01 00 00 
   205ee:	66 0f 28 a4 24 80 01 	movapd 0x180(%rsp),%xmm4
   205f5:	00 00 
   205f7:	66 41 0f 28 c0       	movapd %xmm8,%xmm0
   205fc:	66 41 0f 59 c1       	mulpd  %xmm9,%xmm0
   20601:	66 0f 28 cc          	movapd %xmm4,%xmm1
   20605:	66 0f 28 54 24 30    	movapd 0x30(%rsp),%xmm2
   2060b:	66 0f 59 ca          	mulpd  %xmm2,%xmm1
   2060f:	66 41 0f 5c c7       	subpd  %xmm15,%xmm0
   20614:	66 41 0f 5c cd       	subpd  %xmm13,%xmm1
   20619:	66 41 0f 59 c0       	mulpd  %xmm8,%xmm0
   2061e:	66 0f 59 cc          	mulpd  %xmm4,%xmm1
   20622:	66 0f 5c c6          	subpd  %xmm6,%xmm0
   20626:	66 0f 5c 0c 24       	subpd  (%rsp),%xmm1
   2062b:	66 41 0f 59 c0       	mulpd  %xmm8,%xmm0
   20630:	66 0f 59 cc          	mulpd  %xmm4,%xmm1
   20634:	66 0f 5c 84 24 90 00 	subpd  0x90(%rsp),%xmm0
   2063b:	00 00 
   2063d:	66 0f 5c 4c 24 20    	subpd  0x20(%rsp),%xmm1
   20643:	66 0f 57 ed          	xorpd  %xmm5,%xmm5
   20647:	66 0f 57 ff          	xorpd  %xmm7,%xmm7
   2064b:	66 0f c2 f8 01       	cmpltpd %xmm0,%xmm7
   20650:	66 45 0f 57 ed       	xorpd  %xmm13,%xmm13
   20655:	66 44 0f c2 e9 01    	cmpltpd %xmm1,%xmm13
   2065b:	66 41 0f 54 fc       	andpd  %xmm12,%xmm7
   20660:	66 45 0f 54 ee       	andpd  %xmm14,%xmm13
   20665:	66 0f 50 c7          	movmskpd %xmm7,%eax
   20669:	66 41 0f 50 cd       	movmskpd %xmm13,%ecx
   2066e:	c1 e1 02             	shl    $0x2,%ecx
   20671:	83 e1 04             	and    $0x4,%ecx
   20674:	09 c1                	or     %eax,%ecx
   20676:	0f 84 c4 01 00 00    	je     20840 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xdb0>
   2067c:	b8 60 00 00 00       	mov    $0x60,%eax
   20681:	66 44 0f 28 cc       	movapd %xmm4,%xmm9
   20686:	66 45 0f 28 d8       	movapd %xmm8,%xmm11
   2068b:	66 44 0f 28 7c 24 60 	movapd 0x60(%rsp),%xmm15
   20692:	66 0f 28 44 24 20    	movapd 0x20(%rsp),%xmm0
   20698:	66 44 0f 28 b4 24 90 	movapd 0x90(%rsp),%xmm14
   2069f:	00 00 00 
   206a2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   206a9:	1f 84 00 00 00 00 00 
   206b0:	66 41 0f 28 cb       	movapd %xmm11,%xmm1
   206b5:	66 0f 5c cb          	subpd  %xmm3,%xmm1
   206b9:	66 41 0f 28 f1       	movapd %xmm9,%xmm6
   206be:	66 41 0f 5c f2       	subpd  %xmm10,%xmm6
   206c3:	66 0f 28 2d 25 4b fe 	movapd -0x1b4db(%rip),%xmm5        # 51f0 <std::thread::current::id::ID+0x4578>
   206ca:	ff 
   206cb:	66 0f 59 cd          	mulpd  %xmm5,%xmm1
   206cf:	66 0f 59 f5          	mulpd  %xmm5,%xmm6
   206d3:	66 0f 58 cb          	addpd  %xmm3,%xmm1
   206d7:	66 41 0f 58 f2       	addpd  %xmm10,%xmm6
   206dc:	66 44 0f 28 e1       	movapd %xmm1,%xmm12
   206e1:	66 44 0f 59 64 24 10 	mulpd  0x10(%rsp),%xmm12
   206e8:	66 0f 28 ee          	movapd %xmm6,%xmm5
   206ec:	66 0f 59 ea          	mulpd  %xmm2,%xmm5
   206f0:	66 44 0f 5c a4 24 b0 	subpd  0xb0(%rsp),%xmm12
   206f7:	00 00 00 
   206fa:	66 41 0f 5c ef       	subpd  %xmm15,%xmm5
   206ff:	66 44 0f 59 e1       	mulpd  %xmm1,%xmm12
   20704:	66 0f 59 ee          	mulpd  %xmm6,%xmm5
   20708:	66 44 0f 5c a4 24 80 	subpd  0x80(%rsp),%xmm12
   2070f:	00 00 00 
   20712:	66 0f 5c 2c 24       	subpd  (%rsp),%xmm5
   20717:	66 44 0f 59 e1       	mulpd  %xmm1,%xmm12
   2071c:	66 0f 59 ee          	mulpd  %xmm6,%xmm5
   20720:	66 45 0f 5c e6       	subpd  %xmm14,%xmm12
   20725:	66 0f 5c e8          	subpd  %xmm0,%xmm5
   20729:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   2072d:	66 41 0f c2 d4 01    	cmpltpd %xmm12,%xmm2
   20733:	66 45 0f 57 f6       	xorpd  %xmm14,%xmm14
   20738:	66 44 0f c2 f5 01    	cmpltpd %xmm5,%xmm14
   2073e:	66 44 0f 28 e7       	movapd %xmm7,%xmm12
   20743:	66 44 0f 54 e2       	andpd  %xmm2,%xmm12
   20748:	66 41 0f 28 ec       	movapd %xmm12,%xmm5
   2074d:	66 45 0f 55 e3       	andnpd %xmm11,%xmm12
   20752:	66 45 0f 28 dd       	movapd %xmm13,%xmm11
   20757:	66 45 0f 54 de       	andpd  %xmm14,%xmm11
   2075c:	66 0f 54 e9          	andpd  %xmm1,%xmm5
   20760:	66 44 0f 56 e5       	orpd   %xmm5,%xmm12
   20765:	66 41 0f 28 eb       	movapd %xmm11,%xmm5
   2076a:	66 45 0f 55 d9       	andnpd %xmm9,%xmm11
   2076f:	66 0f 54 ee          	andpd  %xmm6,%xmm5
   20773:	66 44 0f 56 dd       	orpd   %xmm5,%xmm11
   20778:	66 0f 55 d7          	andnpd %xmm7,%xmm2
   2077c:	66 0f 54 ca          	andpd  %xmm2,%xmm1
   20780:	66 0f 55 d3          	andnpd %xmm3,%xmm2
   20784:	66 0f 28 da          	movapd %xmm2,%xmm3
   20788:	66 0f 28 54 24 30    	movapd 0x30(%rsp),%xmm2
   2078e:	66 0f 56 d9          	orpd   %xmm1,%xmm3
   20792:	66 45 0f 55 f5       	andnpd %xmm13,%xmm14
   20797:	66 41 0f 54 f6       	andpd  %xmm14,%xmm6
   2079c:	66 45 0f 55 f2       	andnpd %xmm10,%xmm14
   207a1:	66 45 0f 28 d6       	movapd %xmm14,%xmm10
   207a6:	66 44 0f 28 b4 24 90 	movapd 0x90(%rsp),%xmm14
   207ad:	00 00 00 
   207b0:	66 44 0f 56 d6       	orpd   %xmm6,%xmm10
   207b5:	66 45 0f 28 cb       	movapd %xmm11,%xmm9
   207ba:	66 45 0f 28 dc       	movapd %xmm12,%xmm11
   207bf:	48 ff c8             	dec    %rax
   207c2:	0f 85 e8 fe ff ff    	jne    206b0 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xc20>
   207c8:	66 0f 54 df          	andpd  %xmm7,%xmm3
   207cc:	66 0f 55 bc 24 d0 00 	andnpd 0xd0(%rsp),%xmm7
   207d3:	00 00 
   207d5:	66 0f 56 fb          	orpd   %xmm3,%xmm7
   207d9:	66 45 0f 54 d5       	andpd  %xmm13,%xmm10
   207de:	66 44 0f 55 6c 24 70 	andnpd 0x70(%rsp),%xmm13
   207e5:	66 45 0f 56 ea       	orpd   %xmm10,%xmm13
   207ea:	66 44 0f 28 e7       	movapd %xmm7,%xmm12
   207ef:	66 0f 28 05 f9 4c fe 	movapd -0x1b307(%rip),%xmm0        # 54f0 <std::thread::current::id::ID+0x4878>
   207f6:	ff 
   207f7:	66 44 0f c2 e0 00    	cmpeqpd %xmm0,%xmm12
   207fd:	66 45 0f 28 f5       	movapd %xmm13,%xmm14
   20802:	66 44 0f c2 f0 00    	cmpeqpd %xmm0,%xmm14
   20808:	66 44 0f 29 6c 24 70 	movapd %xmm13,0x70(%rsp)
   2080f:	66 0f 29 bc 24 d0 00 	movapd %xmm7,0xd0(%rsp)
   20816:	00 00 
   20818:	66 44 0f 28 bc 24 b0 	movapd 0xb0(%rsp),%xmm15
   2081f:	00 00 00 
   20822:	66 0f 28 b4 24 80 00 	movapd 0x80(%rsp),%xmm6
   20829:	00 00 
   2082b:	66 44 0f 28 9c 24 70 	movapd 0x170(%rsp),%xmm11
   20832:	01 00 00 
   20835:	66 44 0f 28 4c 24 10 	movapd 0x10(%rsp),%xmm9
   2083c:	66 0f 57 ed          	xorpd  %xmm5,%xmm5
   20840:	66 44 0f 28 94 24 90 	movapd 0x190(%rsp),%xmm10
   20847:	01 00 00 
   2084a:	66 41 0f 28 c2       	movapd %xmm10,%xmm0
   2084f:	66 41 0f 59 c1       	mulpd  %xmm9,%xmm0
   20854:	66 41 0f 28 cb       	movapd %xmm11,%xmm1
   20859:	66 0f 59 ca          	mulpd  %xmm2,%xmm1
   2085d:	66 41 0f 5c c7       	subpd  %xmm15,%xmm0
   20862:	66 0f 5c 4c 24 60    	subpd  0x60(%rsp),%xmm1
   20868:	66 41 0f 59 c2       	mulpd  %xmm10,%xmm0
   2086d:	66 41 0f 59 cb       	mulpd  %xmm11,%xmm1
   20872:	66 0f 5c c6          	subpd  %xmm6,%xmm0
   20876:	66 0f 5c 0c 24       	subpd  (%rsp),%xmm1
   2087b:	66 41 0f 59 c2       	mulpd  %xmm10,%xmm0
   20880:	66 41 0f 59 cb       	mulpd  %xmm11,%xmm1
   20885:	66 0f 5c 84 24 90 00 	subpd  0x90(%rsp),%xmm0
   2088c:	00 00 
   2088e:	66 0f 5c 4c 24 20    	subpd  0x20(%rsp),%xmm1
   20894:	66 0f 57 ff          	xorpd  %xmm7,%xmm7
   20898:	66 0f c2 f8 01       	cmpltpd %xmm0,%xmm7
   2089d:	66 41 0f 54 fc       	andpd  %xmm12,%xmm7
   208a2:	66 0f c2 e9 01       	cmpltpd %xmm1,%xmm5
   208a7:	66 41 0f 54 ee       	andpd  %xmm14,%xmm5
   208ac:	66 0f 50 c7          	movmskpd %xmm7,%eax
   208b0:	66 0f 50 cd          	movmskpd %xmm5,%ecx
   208b4:	c1 e1 02             	shl    $0x2,%ecx
   208b7:	83 e1 04             	and    $0x4,%ecx
   208ba:	09 c1                	or     %eax,%ecx
   208bc:	0f 84 71 01 00 00    	je     20a33 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xfa3>
   208c2:	b8 60 00 00 00       	mov    $0x60,%eax
   208c7:	66 44 0f 28 7c 24 60 	movapd 0x60(%rsp),%xmm15
   208ce:	66 0f 28 c2          	movapd %xmm2,%xmm0
   208d2:	66 44 0f 28 f5       	movapd %xmm5,%xmm14
   208d7:	66 44 0f 28 a4 24 90 	movapd 0x90(%rsp),%xmm12
   208de:	00 00 00 
   208e1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   208e8:	0f 1f 84 00 00 00 00 
   208ef:	00 
   208f0:	66 41 0f 28 ca       	movapd %xmm10,%xmm1
   208f5:	66 41 0f 5c c8       	subpd  %xmm8,%xmm1
   208fa:	66 41 0f 28 eb       	movapd %xmm11,%xmm5
   208ff:	66 0f 5c ec          	subpd  %xmm4,%xmm5
   20903:	66 0f 28 15 e5 48 fe 	movapd -0x1b71b(%rip),%xmm2        # 51f0 <std::thread::current::id::ID+0x4578>
   2090a:	ff 
   2090b:	66 0f 59 ca          	mulpd  %xmm2,%xmm1
   2090f:	66 0f 59 ea          	mulpd  %xmm2,%xmm5
   20913:	66 41 0f 58 c8       	addpd  %xmm8,%xmm1
   20918:	66 0f 58 ec          	addpd  %xmm4,%xmm5
   2091c:	66 0f 28 d1          	movapd %xmm1,%xmm2
   20920:	66 41 0f 59 d1       	mulpd  %xmm9,%xmm2
   20925:	66 0f 28 dd          	movapd %xmm5,%xmm3
   20929:	66 0f 59 d8          	mulpd  %xmm0,%xmm3
   2092d:	66 0f 5c 94 24 b0 00 	subpd  0xb0(%rsp),%xmm2
   20934:	00 00 
   20936:	66 41 0f 5c df       	subpd  %xmm15,%xmm3
   2093b:	66 0f 59 d1          	mulpd  %xmm1,%xmm2
   2093f:	66 0f 59 dd          	mulpd  %xmm5,%xmm3
   20943:	66 0f 5c d6          	subpd  %xmm6,%xmm2
   20947:	66 0f 5c 1c 24       	subpd  (%rsp),%xmm3
   2094c:	66 0f 59 d1          	mulpd  %xmm1,%xmm2
   20950:	66 0f 59 dd          	mulpd  %xmm5,%xmm3
   20954:	66 41 0f 5c d4       	subpd  %xmm12,%xmm2
   20959:	66 0f 5c 5c 24 20    	subpd  0x20(%rsp),%xmm3
   2095f:	66 45 0f 57 c9       	xorpd  %xmm9,%xmm9
   20964:	66 44 0f c2 ca 01    	cmpltpd %xmm2,%xmm9
   2096a:	66 44 0f 28 ee       	movapd %xmm6,%xmm13
   2096f:	66 0f 57 f6          	xorpd  %xmm6,%xmm6
   20973:	66 0f c2 f3 01       	cmpltpd %xmm3,%xmm6
   20978:	66 0f 28 d7          	movapd %xmm7,%xmm2
   2097c:	66 41 0f 54 d1       	andpd  %xmm9,%xmm2
   20981:	66 0f 28 da          	movapd %xmm2,%xmm3
   20985:	66 41 0f 55 d2       	andnpd %xmm10,%xmm2
   2098a:	66 45 0f 28 d6       	movapd %xmm14,%xmm10
   2098f:	66 44 0f 54 d6       	andpd  %xmm6,%xmm10
   20994:	66 0f 54 d9          	andpd  %xmm1,%xmm3
   20998:	66 0f 56 d3          	orpd   %xmm3,%xmm2
   2099c:	66 41 0f 28 da       	movapd %xmm10,%xmm3
   209a1:	66 45 0f 55 d3       	andnpd %xmm11,%xmm10
   209a6:	66 0f 54 dd          	andpd  %xmm5,%xmm3
   209aa:	66 44 0f 56 d3       	orpd   %xmm3,%xmm10
   209af:	66 44 0f 55 cf       	andnpd %xmm7,%xmm9
   209b4:	66 41 0f 54 c9       	andpd  %xmm9,%xmm1
   209b9:	66 45 0f 55 c8       	andnpd %xmm8,%xmm9
   209be:	66 45 0f 28 c1       	movapd %xmm9,%xmm8
   209c3:	66 44 0f 28 4c 24 10 	movapd 0x10(%rsp),%xmm9
   209ca:	66 44 0f 56 c1       	orpd   %xmm1,%xmm8
   209cf:	66 41 0f 55 f6       	andnpd %xmm14,%xmm6
   209d4:	66 0f 54 ee          	andpd  %xmm6,%xmm5
   209d8:	66 0f 55 f4          	andnpd %xmm4,%xmm6
   209dc:	66 0f 28 e6          	movapd %xmm6,%xmm4
   209e0:	66 41 0f 28 f5       	movapd %xmm13,%xmm6
   209e5:	66 0f 56 e5          	orpd   %xmm5,%xmm4
   209e9:	66 45 0f 28 da       	movapd %xmm10,%xmm11
   209ee:	66 44 0f 28 d2       	movapd %xmm2,%xmm10
   209f3:	48 ff c8             	dec    %rax
   209f6:	0f 85 f4 fe ff ff    	jne    208f0 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xe60>
   209fc:	66 44 0f 54 c7       	andpd  %xmm7,%xmm8
   20a01:	66 0f 55 bc 24 d0 00 	andnpd 0xd0(%rsp),%xmm7
   20a08:	00 00 
   20a0a:	66 41 0f 56 f8       	orpd   %xmm8,%xmm7
   20a0f:	66 41 0f 54 e6       	andpd  %xmm14,%xmm4
   20a14:	66 44 0f 55 74 24 70 	andnpd 0x70(%rsp),%xmm14
   20a1b:	66 44 0f 56 f4       	orpd   %xmm4,%xmm14
   20a20:	66 44 0f 29 74 24 70 	movapd %xmm14,0x70(%rsp)
   20a27:	66 44 0f 28 bc 24 b0 	movapd 0xb0(%rsp),%xmm15
   20a2e:	00 00 00 
   20a31:	eb 09                	jmp    20a3c <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xfac>
   20a33:	66 0f 28 bc 24 d0 00 	movapd 0xd0(%rsp),%xmm7
   20a3a:	00 00 
   20a3c:	66 0f 70 c7 ee       	pshufd $0xee,%xmm7,%xmm0
   20a41:	f2 0f 5d 3d d7 64 fe 	minsd  -0x19b29(%rip),%xmm7        # 6f20 <std::thread::current::id::ID+0x62a8>
   20a48:	ff 
   20a49:	f2 0f 5d c7          	minsd  %xmm7,%xmm0
   20a4d:	66 0f 28 4c 24 70    	movapd 0x70(%rsp),%xmm1
   20a53:	f2 0f 5d c8          	minsd  %xmm0,%xmm1
   20a57:	66 48 0f 7e c8       	movq   %xmm1,%rax
   20a5c:	48 b9 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rcx
   20a63:	ff ff 7f 
   20a66:	48 21 c1             	and    %rax,%rcx
   20a69:	41 be 0e 00 00 00    	mov    $0xe,%r14d
   20a6f:	48 b8 ff ff ff ff ff 	movabs $0x7fefffffffffffff,%rax
   20a76:	ff ef 7f 
   20a79:	48 39 c1             	cmp    %rax,%rcx
   20a7c:	66 44 0f 28 ac 24 f0 	movapd 0xf0(%rsp),%xmm13
   20a83:	00 00 00 
   20a86:	66 0f 28 54 24 20    	movapd 0x20(%rsp),%xmm2
   20a8c:	66 44 0f 28 b4 24 90 	movapd 0x90(%rsp),%xmm14
   20a93:	00 00 00 
   20a96:	0f 8f 24 09 00 00    	jg     213c0 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x1930>
   20a9c:	66 0f 28 e1          	movapd %xmm1,%xmm4
   20aa0:	f3 0f 10 84 24 ac 00 	movss  0xac(%rsp),%xmm0
   20aa7:	00 00 
   20aa9:	0f 57 c9             	xorps  %xmm1,%xmm1
   20aac:	f3 0f 5a c8          	cvtss2sd %xmm0,%xmm1
   20ab0:	0f 28 c1             	movaps %xmm1,%xmm0
   20ab3:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   20ab7:	f2 0f 11 8c 24 e0 00 	movsd  %xmm1,0xe0(%rsp)
   20abe:	00 00 
   20ac0:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   20ac4:	f2 0f 10 0d 8c 64 fe 	movsd  -0x19b74(%rip),%xmm1        # 6f58 <std::thread::current::id::ID+0x62e0>
   20acb:	ff 
   20acc:	f2 0f 5e c8          	divsd  %xmm0,%xmm1
   20ad0:	66 0f 14 c9          	unpcklpd %xmm1,%xmm1
   20ad4:	66 44 0f 5c f1       	subpd  %xmm1,%xmm14
   20ad9:	66 0f 5c d1          	subpd  %xmm1,%xmm2
   20add:	66 0f 29 64 24 70    	movapd %xmm4,0x70(%rsp)
   20ae3:	66 0f 14 e4          	unpcklpd %xmm4,%xmm4
   20ae7:	66 0f 28 ca          	movapd %xmm2,%xmm1
   20aeb:	66 45 0f 57 c0       	xorpd  %xmm8,%xmm8
   20af0:	66 45 0f 57 c9       	xorpd  %xmm9,%xmm9
   20af5:	66 45 0f c2 ce 01    	cmpltpd %xmm14,%xmm9
   20afb:	66 45 0f 57 e4       	xorpd  %xmm12,%xmm12
   20b00:	66 44 0f c2 e2 01    	cmpltpd %xmm2,%xmm12
   20b06:	66 0f 28 05 e2 49 fe 	movapd -0x1b61e(%rip),%xmm0        # 54f0 <std::thread::current::id::ID+0x4878>
   20b0d:	ff 
   20b0e:	66 44 0f 55 c8       	andnpd %xmm0,%xmm9
   20b13:	66 44 0f 55 e0       	andnpd %xmm0,%xmm12
   20b18:	66 0f 28 9c 24 30 01 	movapd 0x130(%rsp),%xmm3
   20b1f:	00 00 
   20b21:	66 0f 5d dc          	minpd  %xmm4,%xmm3
   20b25:	66 0f 28 ac 24 20 01 	movapd 0x120(%rsp),%xmm5
   20b2c:	00 00 
   20b2e:	66 0f 5d ec          	minpd  %xmm4,%xmm5
   20b32:	66 0f 28 84 24 10 01 	movapd 0x110(%rsp),%xmm0
   20b39:	00 00 
   20b3b:	66 0f 5d c4          	minpd  %xmm4,%xmm0
   20b3f:	66 0f 29 84 24 10 01 	movapd %xmm0,0x110(%rsp)
   20b46:	00 00 
   20b48:	66 0f 28 84 24 00 01 	movapd 0x100(%rsp),%xmm0
   20b4f:	00 00 
   20b51:	66 0f 5d c4          	minpd  %xmm4,%xmm0
   20b55:	66 0f 29 84 24 00 01 	movapd %xmm0,0x100(%rsp)
   20b5c:	00 00 
   20b5e:	66 44 0f 29 4c 24 10 	movapd %xmm9,0x10(%rsp)
   20b65:	66 0f 28 05 83 49 fe 	movapd -0x1b67d(%rip),%xmm0        # 54f0 <std::thread::current::id::ID+0x4878>
   20b6c:	ff 
   20b6d:	66 44 0f c2 c8 00    	cmpeqpd %xmm0,%xmm9
   20b73:	66 44 0f 28 94 24 c0 	movapd 0xc0(%rsp),%xmm10
   20b7a:	00 00 00 
   20b7d:	66 41 0f 28 c2       	movapd %xmm10,%xmm0
   20b82:	66 0f 59 c3          	mulpd  %xmm3,%xmm0
   20b86:	66 41 0f 28 d5       	movapd %xmm13,%xmm2
   20b8b:	66 0f 59 d5          	mulpd  %xmm5,%xmm2
   20b8f:	66 41 0f 58 c7       	addpd  %xmm15,%xmm0
   20b94:	66 0f 58 54 24 60    	addpd  0x60(%rsp),%xmm2
   20b9a:	66 0f 59 c3          	mulpd  %xmm3,%xmm0
   20b9e:	66 0f 59 d5          	mulpd  %xmm5,%xmm2
   20ba2:	66 0f 58 c6          	addpd  %xmm6,%xmm0
   20ba6:	66 0f 58 14 24       	addpd  (%rsp),%xmm2
   20bab:	66 0f 59 c3          	mulpd  %xmm3,%xmm0
   20baf:	66 0f 59 d5          	mulpd  %xmm5,%xmm2
   20bb3:	66 41 0f 58 c6       	addpd  %xmm14,%xmm0
   20bb8:	66 0f 29 4c 24 20    	movapd %xmm1,0x20(%rsp)
   20bbe:	66 0f 58 d1          	addpd  %xmm1,%xmm2
   20bc2:	66 0f 57 ff          	xorpd  %xmm7,%xmm7
   20bc6:	66 0f c2 f8 01       	cmpltpd %xmm0,%xmm7
   20bcb:	66 45 0f 57 db       	xorpd  %xmm11,%xmm11
   20bd0:	66 44 0f c2 da 01    	cmpltpd %xmm2,%xmm11
   20bd6:	66 41 0f 28 f4       	movapd %xmm12,%xmm6
   20bdb:	66 0f c2 35 0c 49 fe 	cmpeqpd -0x1b6f4(%rip),%xmm6        # 54f0 <std::thread::current::id::ID+0x4878>
   20be2:	ff 00 
   20be4:	66 41 0f 54 f9       	andpd  %xmm9,%xmm7
   20be9:	66 44 0f 54 de       	andpd  %xmm6,%xmm11
   20bee:	66 0f 50 c7          	movmskpd %xmm7,%eax
   20bf2:	66 41 0f 50 cb       	movmskpd %xmm11,%ecx
   20bf7:	c1 e1 02             	shl    $0x2,%ecx
   20bfa:	83 e1 04             	and    $0x4,%ecx
   20bfd:	09 c1                	or     %eax,%ecx
   20bff:	66 0f 29 9c 24 30 01 	movapd %xmm3,0x130(%rsp)
   20c06:	00 00 
   20c08:	66 0f 29 ac 24 20 01 	movapd %xmm5,0x120(%rsp)
   20c0f:	00 00 
   20c11:	0f 84 e2 01 00 00    	je     20df9 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x1369>
   20c17:	66 44 0f 29 64 24 30 	movapd %xmm12,0x30(%rsp)
   20c1e:	b8 40 00 00 00       	mov    $0x40,%eax
   20c23:	66 44 0f 28 cd       	movapd %xmm5,%xmm9
   20c28:	66 0f 28 d3          	movapd %xmm3,%xmm2
   20c2c:	66 45 0f 57 ff       	xorpd  %xmm15,%xmm15
   20c31:	66 44 0f 29 b4 24 90 	movapd %xmm14,0x90(%rsp)
   20c38:	00 00 00 
   20c3b:	66 0f 28 0c 24       	movapd (%rsp),%xmm1
   20c40:	66 0f 28 9c 24 80 00 	movapd 0x80(%rsp),%xmm3
   20c47:	00 00 
   20c49:	66 0f 28 44 24 20    	movapd 0x20(%rsp),%xmm0
   20c4f:	66 0f 28 6c 24 60    	movapd 0x60(%rsp),%xmm5
   20c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   20c5c:	00 00 00 00 
   20c60:	66 44 0f 28 d2       	movapd %xmm2,%xmm10
   20c65:	66 45 0f 5c d7       	subpd  %xmm15,%xmm10
   20c6a:	66 41 0f 28 f1       	movapd %xmm9,%xmm6
   20c6f:	66 41 0f 5c f0       	subpd  %xmm8,%xmm6
   20c74:	66 44 0f 28 25 73 45 	movapd -0x1ba8d(%rip),%xmm12        # 51f0 <std::thread::current::id::ID+0x4578>
   20c7b:	fe ff 
   20c7d:	66 45 0f 59 d4       	mulpd  %xmm12,%xmm10
   20c82:	66 41 0f 59 f4       	mulpd  %xmm12,%xmm6
   20c87:	66 45 0f 58 d7       	addpd  %xmm15,%xmm10
   20c8c:	66 41 0f 58 f0       	addpd  %xmm8,%xmm6
   20c91:	66 44 0f 28 a4 24 c0 	movapd 0xc0(%rsp),%xmm12
   20c98:	00 00 00 
   20c9b:	66 45 0f 59 e2       	mulpd  %xmm10,%xmm12
   20ca0:	66 44 0f 28 b4 24 f0 	movapd 0xf0(%rsp),%xmm14
   20ca7:	00 00 00 
   20caa:	66 44 0f 59 f6       	mulpd  %xmm6,%xmm14
   20caf:	66 44 0f 58 a4 24 b0 	addpd  0xb0(%rsp),%xmm12
   20cb6:	00 00 00 
   20cb9:	66 44 0f 58 f5       	addpd  %xmm5,%xmm14
   20cbe:	66 45 0f 59 e2       	mulpd  %xmm10,%xmm12
   20cc3:	66 44 0f 59 f6       	mulpd  %xmm6,%xmm14
   20cc8:	66 44 0f 58 e3       	addpd  %xmm3,%xmm12
   20ccd:	66 44 0f 58 f1       	addpd  %xmm1,%xmm14
   20cd2:	66 45 0f 59 e2       	mulpd  %xmm10,%xmm12
   20cd7:	66 44 0f 59 f6       	mulpd  %xmm6,%xmm14
   20cdc:	66 44 0f 58 a4 24 90 	addpd  0x90(%rsp),%xmm12
   20ce3:	00 00 00 
   20ce6:	66 44 0f 58 f0       	addpd  %xmm0,%xmm14
   20ceb:	66 0f 57 ed          	xorpd  %xmm5,%xmm5
   20cef:	66 41 0f c2 ec 01    	cmpltpd %xmm12,%xmm5
   20cf5:	66 45 0f 57 ed       	xorpd  %xmm13,%xmm13
   20cfa:	66 45 0f c2 ee 01    	cmpltpd %xmm14,%xmm13
   20d00:	66 44 0f 28 e7       	movapd %xmm7,%xmm12
   20d05:	66 44 0f 54 e5       	andpd  %xmm5,%xmm12
   20d0a:	66 45 0f 28 f4       	movapd %xmm12,%xmm14
   20d0f:	66 44 0f 55 e2       	andnpd %xmm2,%xmm12
   20d14:	66 41 0f 28 d3       	movapd %xmm11,%xmm2
   20d19:	66 41 0f 54 d5       	andpd  %xmm13,%xmm2
   20d1e:	66 45 0f 54 f2       	andpd  %xmm10,%xmm14
   20d23:	66 45 0f 56 e6       	orpd   %xmm14,%xmm12
   20d28:	66 44 0f 28 f2       	movapd %xmm2,%xmm14
   20d2d:	66 41 0f 55 d1       	andnpd %xmm9,%xmm2
   20d32:	66 44 0f 54 f6       	andpd  %xmm6,%xmm14
   20d37:	66 41 0f 56 d6       	orpd   %xmm14,%xmm2
   20d3c:	66 0f 55 ef          	andnpd %xmm7,%xmm5
   20d40:	66 44 0f 54 d5       	andpd  %xmm5,%xmm10
   20d45:	66 41 0f 55 ef       	andnpd %xmm15,%xmm5
   20d4a:	66 44 0f 28 fd       	movapd %xmm5,%xmm15
   20d4f:	66 45 0f 56 fa       	orpd   %xmm10,%xmm15
   20d54:	66 45 0f 55 eb       	andnpd %xmm11,%xmm13
   20d59:	66 41 0f 54 f5       	andpd  %xmm13,%xmm6
   20d5e:	66 45 0f 55 e8       	andnpd %xmm8,%xmm13
   20d63:	66 45 0f 28 c5       	movapd %xmm13,%xmm8
   20d68:	66 0f 28 6c 24 60    	movapd 0x60(%rsp),%xmm5
   20d6e:	66 44 0f 56 c6       	orpd   %xmm6,%xmm8
   20d73:	66 44 0f 28 ca       	movapd %xmm2,%xmm9
   20d78:	66 41 0f 28 d4       	movapd %xmm12,%xmm2
   20d7d:	48 ff c8             	dec    %rax
   20d80:	0f 85 da fe ff ff    	jne    20c60 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x11d0>
   20d86:	66 44 0f 54 ff       	andpd  %xmm7,%xmm15
   20d8b:	66 0f 55 7c 24 10    	andnpd 0x10(%rsp),%xmm7
   20d91:	66 41 0f 56 ff       	orpd   %xmm15,%xmm7
   20d96:	66 45 0f 54 c3       	andpd  %xmm11,%xmm8
   20d9b:	66 44 0f 55 5c 24 30 	andnpd 0x30(%rsp),%xmm11
   20da2:	66 45 0f 56 d8       	orpd   %xmm8,%xmm11
   20da7:	66 44 0f 28 cf       	movapd %xmm7,%xmm9
   20dac:	66 0f 28 05 3c 47 fe 	movapd -0x1b8c4(%rip),%xmm0        # 54f0 <std::thread::current::id::ID+0x4878>
   20db3:	ff 
   20db4:	66 44 0f c2 c8 00    	cmpeqpd %xmm0,%xmm9
   20dba:	66 41 0f 28 f3       	movapd %xmm11,%xmm6
   20dbf:	66 0f c2 f0 00       	cmpeqpd %xmm0,%xmm6
   20dc4:	66 45 0f 28 c3       	movapd %xmm11,%xmm8
   20dc9:	66 0f 29 7c 24 10    	movapd %xmm7,0x10(%rsp)
   20dcf:	66 44 0f 28 b4 24 90 	movapd 0x90(%rsp),%xmm14
   20dd6:	00 00 00 
   20dd9:	66 44 0f 28 ac 24 f0 	movapd 0xf0(%rsp),%xmm13
   20de0:	00 00 00 
   20de3:	66 44 0f 28 94 24 c0 	movapd 0xc0(%rsp),%xmm10
   20dea:	00 00 00 
   20ded:	66 44 0f 28 bc 24 b0 	movapd 0xb0(%rsp),%xmm15
   20df4:	00 00 00 
   20df7:	eb 0b                	jmp    20e04 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x1374>
   20df9:	66 0f 28 6c 24 60    	movapd 0x60(%rsp),%xmm5
   20dff:	66 45 0f 28 c4       	movapd %xmm12,%xmm8
   20e04:	66 41 0f 28 c2       	movapd %xmm10,%xmm0
   20e09:	66 0f 28 8c 24 10 01 	movapd 0x110(%rsp),%xmm1
   20e10:	00 00 
   20e12:	66 0f 59 c1          	mulpd  %xmm1,%xmm0
   20e16:	66 41 0f 28 d5       	movapd %xmm13,%xmm2
   20e1b:	66 44 0f 28 94 24 00 	movapd 0x100(%rsp),%xmm10
   20e22:	01 00 00 
   20e25:	66 41 0f 59 d2       	mulpd  %xmm10,%xmm2
   20e2a:	66 41 0f 58 c7       	addpd  %xmm15,%xmm0
   20e2f:	66 0f 58 d5          	addpd  %xmm5,%xmm2
   20e33:	66 0f 59 c1          	mulpd  %xmm1,%xmm0
   20e37:	66 41 0f 59 d2       	mulpd  %xmm10,%xmm2
   20e3c:	66 0f 58 84 24 80 00 	addpd  0x80(%rsp),%xmm0
   20e43:	00 00 
   20e45:	66 0f 58 14 24       	addpd  (%rsp),%xmm2
   20e4a:	66 0f 59 c1          	mulpd  %xmm1,%xmm0
   20e4e:	66 41 0f 59 d2       	mulpd  %xmm10,%xmm2
   20e53:	66 41 0f 58 c6       	addpd  %xmm14,%xmm0
   20e58:	66 0f 28 5c 24 20    	movapd 0x20(%rsp),%xmm3
   20e5e:	66 0f 58 d3          	addpd  %xmm3,%xmm2
   20e62:	66 45 0f 57 e4       	xorpd  %xmm12,%xmm12
   20e67:	66 0f 57 ff          	xorpd  %xmm7,%xmm7
   20e6b:	66 0f c2 f8 01       	cmpltpd %xmm0,%xmm7
   20e70:	66 45 0f 57 db       	xorpd  %xmm11,%xmm11
   20e75:	66 44 0f c2 da 01    	cmpltpd %xmm2,%xmm11
   20e7b:	66 41 0f 54 f9       	andpd  %xmm9,%xmm7
   20e80:	66 44 0f 54 de       	andpd  %xmm6,%xmm11
   20e85:	66 0f 50 c7          	movmskpd %xmm7,%eax
   20e89:	66 41 0f 50 cb       	movmskpd %xmm11,%ecx
   20e8e:	c1 e1 02             	shl    $0x2,%ecx
   20e91:	83 e1 04             	and    $0x4,%ecx
   20e94:	09 c1                	or     %eax,%ecx
   20e96:	0f 84 dc 01 00 00    	je     21078 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x15e8>
   20e9c:	66 44 0f 29 44 24 30 	movapd %xmm8,0x30(%rsp)
   20ea3:	b8 40 00 00 00       	mov    $0x40,%eax
   20ea8:	66 41 0f 28 f2       	movapd %xmm10,%xmm6
   20ead:	66 0f 28 d1          	movapd %xmm1,%xmm2
   20eb1:	66 0f 28 8c 24 80 00 	movapd 0x80(%rsp),%xmm1
   20eb8:	00 00 
   20eba:	66 44 0f 28 bc 24 30 	movapd 0x130(%rsp),%xmm15
   20ec1:	01 00 00 
   20ec4:	66 44 0f 28 a4 24 20 	movapd 0x120(%rsp),%xmm12
   20ecb:	01 00 00 
   20ece:	66 44 0f 28 84 24 c0 	movapd 0xc0(%rsp),%xmm8
   20ed5:	00 00 00 
   20ed8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   20edf:	00 
   20ee0:	66 44 0f 28 ca       	movapd %xmm2,%xmm9
   20ee5:	66 45 0f 5c cf       	subpd  %xmm15,%xmm9
   20eea:	66 0f 28 ee          	movapd %xmm6,%xmm5
   20eee:	66 41 0f 5c ec       	subpd  %xmm12,%xmm5
   20ef3:	66 0f 28 05 f5 42 fe 	movapd -0x1bd0b(%rip),%xmm0        # 51f0 <std::thread::current::id::ID+0x4578>
   20efa:	ff 
   20efb:	66 44 0f 59 c8       	mulpd  %xmm0,%xmm9
   20f00:	66 0f 59 e8          	mulpd  %xmm0,%xmm5
   20f04:	66 45 0f 58 cf       	addpd  %xmm15,%xmm9
   20f09:	66 41 0f 58 ec       	addpd  %xmm12,%xmm5
   20f0e:	66 45 0f 28 d0       	movapd %xmm8,%xmm10
   20f13:	66 45 0f 59 d1       	mulpd  %xmm9,%xmm10
   20f18:	66 41 0f 28 c4       	movapd %xmm12,%xmm0
   20f1d:	66 44 0f 28 ac 24 f0 	movapd 0xf0(%rsp),%xmm13
   20f24:	00 00 00 
   20f27:	66 44 0f 59 ed       	mulpd  %xmm5,%xmm13
   20f2c:	66 44 0f 58 94 24 b0 	addpd  0xb0(%rsp),%xmm10
   20f33:	00 00 00 
   20f36:	66 44 0f 58 6c 24 60 	addpd  0x60(%rsp),%xmm13
   20f3d:	66 45 0f 59 d1       	mulpd  %xmm9,%xmm10
   20f42:	66 44 0f 59 ed       	mulpd  %xmm5,%xmm13
   20f47:	66 44 0f 58 d1       	addpd  %xmm1,%xmm10
   20f4c:	66 44 0f 58 2c 24    	addpd  (%rsp),%xmm13
   20f52:	66 45 0f 59 d1       	mulpd  %xmm9,%xmm10
   20f57:	66 44 0f 59 ed       	mulpd  %xmm5,%xmm13
   20f5c:	66 45 0f 58 d6       	addpd  %xmm14,%xmm10
   20f61:	66 44 0f 58 6c 24 20 	addpd  0x20(%rsp),%xmm13
   20f68:	66 41 0f 28 de       	movapd %xmm14,%xmm3
   20f6d:	66 45 0f 57 f6       	xorpd  %xmm14,%xmm14
   20f72:	66 45 0f c2 f2 01    	cmpltpd %xmm10,%xmm14
   20f78:	66 45 0f 57 e4       	xorpd  %xmm12,%xmm12
   20f7d:	66 45 0f c2 e5 01    	cmpltpd %xmm13,%xmm12
   20f83:	66 44 0f 28 d7       	movapd %xmm7,%xmm10
   20f88:	66 45 0f 54 d6       	andpd  %xmm14,%xmm10
   20f8d:	66 45 0f 28 ea       	movapd %xmm10,%xmm13
   20f92:	66 44 0f 55 d2       	andnpd %xmm2,%xmm10
   20f97:	66 41 0f 28 d3       	movapd %xmm11,%xmm2
   20f9c:	66 41 0f 54 d4       	andpd  %xmm12,%xmm2
   20fa1:	66 45 0f 54 e9       	andpd  %xmm9,%xmm13
   20fa6:	66 45 0f 56 d5       	orpd   %xmm13,%xmm10
   20fab:	66 44 0f 28 ea       	movapd %xmm2,%xmm13
   20fb0:	66 0f 55 d6          	andnpd %xmm6,%xmm2
   20fb4:	66 44 0f 54 ed       	andpd  %xmm5,%xmm13
   20fb9:	66 41 0f 56 d5       	orpd   %xmm13,%xmm2
   20fbe:	66 44 0f 55 f7       	andnpd %xmm7,%xmm14
   20fc3:	66 45 0f 54 ce       	andpd  %xmm14,%xmm9
   20fc8:	66 45 0f 55 f7       	andnpd %xmm15,%xmm14
   20fcd:	66 45 0f 28 fe       	movapd %xmm14,%xmm15
   20fd2:	66 44 0f 28 f3       	movapd %xmm3,%xmm14
   20fd7:	66 45 0f 56 f9       	orpd   %xmm9,%xmm15
   20fdc:	66 45 0f 55 e3       	andnpd %xmm11,%xmm12
   20fe1:	66 41 0f 54 ec       	andpd  %xmm12,%xmm5
   20fe6:	66 44 0f 55 e0       	andnpd %xmm0,%xmm12
   20feb:	66 44 0f 56 e5       	orpd   %xmm5,%xmm12
   20ff0:	66 0f 28 f2          	movapd %xmm2,%xmm6
   20ff4:	66 41 0f 28 d2       	movapd %xmm10,%xmm2
   20ff9:	48 ff c8             	dec    %rax
   20ffc:	0f 85 de fe ff ff    	jne    20ee0 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x1450>
   21002:	66 44 0f 54 ff       	andpd  %xmm7,%xmm15
   21007:	66 0f 55 7c 24 10    	andnpd 0x10(%rsp),%xmm7
   2100d:	66 41 0f 56 ff       	orpd   %xmm15,%xmm7
   21012:	66 45 0f 54 e3       	andpd  %xmm11,%xmm12
   21017:	66 44 0f 55 5c 24 30 	andnpd 0x30(%rsp),%xmm11
   2101e:	66 45 0f 56 dc       	orpd   %xmm12,%xmm11
   21023:	66 44 0f 28 cf       	movapd %xmm7,%xmm9
   21028:	66 0f 28 35 c0 44 fe 	movapd -0x1bb40(%rip),%xmm6        # 54f0 <std::thread::current::id::ID+0x4878>
   2102f:	ff 
   21030:	66 44 0f c2 ce 00    	cmpeqpd %xmm6,%xmm9
   21036:	66 41 0f c2 f3 00    	cmpeqpd %xmm11,%xmm6
   2103c:	66 45 0f 28 c3       	movapd %xmm11,%xmm8
   21041:	66 0f 29 7c 24 10    	movapd %xmm7,0x10(%rsp)
   21047:	66 0f 28 4c 24 60    	movapd 0x60(%rsp),%xmm1
   2104d:	66 44 0f 28 bc 24 b0 	movapd 0xb0(%rsp),%xmm15
   21054:	00 00 00 
   21057:	66 0f 28 7c 24 20    	movapd 0x20(%rsp),%xmm7
   2105d:	66 44 0f 28 94 24 00 	movapd 0x100(%rsp),%xmm10
   21064:	01 00 00 
   21067:	66 44 0f 28 ac 24 f0 	movapd 0xf0(%rsp),%xmm13
   2106e:	00 00 00 
   21071:	66 45 0f 57 e4       	xorpd  %xmm12,%xmm12
   21076:	eb 08                	jmp    21080 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x15f0>
   21078:	66 0f 28 cd          	movapd %xmm5,%xmm1
   2107c:	66 0f 28 fb          	movapd %xmm3,%xmm7
   21080:	66 0f 28 84 24 c0 00 	movapd 0xc0(%rsp),%xmm0
   21087:	00 00 
   21089:	66 0f 59 c4          	mulpd  %xmm4,%xmm0
   2108d:	66 41 0f 28 ed       	movapd %xmm13,%xmm5
   21092:	66 0f 59 ec          	mulpd  %xmm4,%xmm5
   21096:	66 41 0f 58 c7       	addpd  %xmm15,%xmm0
   2109b:	66 0f 58 e9          	addpd  %xmm1,%xmm5
   2109f:	66 0f 59 c4          	mulpd  %xmm4,%xmm0
   210a3:	66 0f 59 ec          	mulpd  %xmm4,%xmm5
   210a7:	66 0f 58 84 24 80 00 	addpd  0x80(%rsp),%xmm0
   210ae:	00 00 
   210b0:	66 0f 28 0c 24       	movapd (%rsp),%xmm1
   210b5:	66 0f 58 e9          	addpd  %xmm1,%xmm5
   210b9:	66 0f 59 c4          	mulpd  %xmm4,%xmm0
   210bd:	66 0f 59 ec          	mulpd  %xmm4,%xmm5
   210c1:	66 41 0f 58 c6       	addpd  %xmm14,%xmm0
   210c6:	66 0f 58 ef          	addpd  %xmm7,%xmm5
   210ca:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   210ce:	66 0f c2 d0 01       	cmpltpd %xmm0,%xmm2
   210d3:	66 41 0f 54 d1       	andpd  %xmm9,%xmm2
   210d8:	66 44 0f c2 e5 01    	cmpltpd %xmm5,%xmm12
   210de:	66 44 0f 54 e6       	andpd  %xmm6,%xmm12
   210e3:	66 0f 50 c2          	movmskpd %xmm2,%eax
   210e7:	66 41 0f 28 c4       	movapd %xmm12,%xmm0
   210ec:	66 41 0f 50 cc       	movmskpd %xmm12,%ecx
   210f1:	c1 e1 02             	shl    $0x2,%ecx
   210f4:	83 e1 04             	and    $0x4,%ecx
   210f7:	09 c1                	or     %eax,%ecx
   210f9:	66 44 0f 28 a4 24 10 	movapd 0x110(%rsp),%xmm12
   21100:	01 00 00 
   21103:	0f 84 72 01 00 00    	je     2127b <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x17eb>
   21109:	66 41 0f 28 dd       	movapd %xmm13,%xmm3
   2110e:	66 45 0f 28 ef       	movapd %xmm15,%xmm13
   21113:	66 44 0f 29 44 24 30 	movapd %xmm8,0x30(%rsp)
   2111a:	b8 40 00 00 00       	mov    $0x40,%eax
   2111f:	66 0f 28 fc          	movapd %xmm4,%xmm7
   21123:	66 44 0f 28 fb       	movapd %xmm3,%xmm15
   21128:	66 0f 28 8c 24 c0 00 	movapd 0xc0(%rsp),%xmm1
   2112f:	00 00 
   21131:	66 0f 28 d8          	movapd %xmm0,%xmm3
   21135:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   2113c:	00 00 00 00 
   21140:	66 0f 28 f7          	movapd %xmm7,%xmm6
   21144:	66 41 0f 5c f4       	subpd  %xmm12,%xmm6
   21149:	66 0f 28 ec          	movapd %xmm4,%xmm5
   2114d:	66 41 0f 5c ea       	subpd  %xmm10,%xmm5
   21152:	66 0f 28 05 96 40 fe 	movapd -0x1bf6a(%rip),%xmm0        # 51f0 <std::thread::current::id::ID+0x4578>
   21159:	ff 
   2115a:	66 0f 59 f0          	mulpd  %xmm0,%xmm6
   2115e:	66 0f 59 e8          	mulpd  %xmm0,%xmm5
   21162:	66 41 0f 58 f4       	addpd  %xmm12,%xmm6
   21167:	66 41 0f 58 ea       	addpd  %xmm10,%xmm5
   2116c:	66 44 0f 28 c9       	movapd %xmm1,%xmm9
   21171:	66 44 0f 59 ce       	mulpd  %xmm6,%xmm9
   21176:	66 41 0f 28 c2       	movapd %xmm10,%xmm0
   2117b:	66 45 0f 28 c4       	movapd %xmm12,%xmm8
   21180:	66 45 0f 28 df       	movapd %xmm15,%xmm11
   21185:	66 44 0f 59 dd       	mulpd  %xmm5,%xmm11
   2118a:	66 45 0f 58 cd       	addpd  %xmm13,%xmm9
   2118f:	66 44 0f 58 5c 24 60 	addpd  0x60(%rsp),%xmm11
   21196:	66 44 0f 59 ce       	mulpd  %xmm6,%xmm9
   2119b:	66 44 0f 59 dd       	mulpd  %xmm5,%xmm11
   211a0:	66 44 0f 58 8c 24 80 	addpd  0x80(%rsp),%xmm9
   211a7:	00 00 00 
   211aa:	66 44 0f 58 1c 24    	addpd  (%rsp),%xmm11
   211b0:	66 44 0f 59 ce       	mulpd  %xmm6,%xmm9
   211b5:	66 44 0f 59 dd       	mulpd  %xmm5,%xmm11
   211ba:	66 45 0f 58 ce       	addpd  %xmm14,%xmm9
   211bf:	66 44 0f 58 5c 24 20 	addpd  0x20(%rsp),%xmm11
   211c6:	66 45 0f 57 e4       	xorpd  %xmm12,%xmm12
   211cb:	66 45 0f c2 e1 01    	cmpltpd %xmm9,%xmm12
   211d1:	66 45 0f 57 d2       	xorpd  %xmm10,%xmm10
   211d6:	66 45 0f c2 d3 01    	cmpltpd %xmm11,%xmm10
   211dc:	66 44 0f 28 ca       	movapd %xmm2,%xmm9
   211e1:	66 45 0f 54 cc       	andpd  %xmm12,%xmm9
   211e6:	66 45 0f 28 d9       	movapd %xmm9,%xmm11
   211eb:	66 44 0f 55 cf       	andnpd %xmm7,%xmm9
   211f0:	66 0f 28 fb          	movapd %xmm3,%xmm7
   211f4:	66 41 0f 54 fa       	andpd  %xmm10,%xmm7
   211f9:	66 44 0f 54 de       	andpd  %xmm6,%xmm11
   211fe:	66 45 0f 56 cb       	orpd   %xmm11,%xmm9
   21203:	66 44 0f 28 df       	movapd %xmm7,%xmm11
   21208:	66 0f 55 fc          	andnpd %xmm4,%xmm7
   2120c:	66 44 0f 54 dd       	andpd  %xmm5,%xmm11
   21211:	66 41 0f 56 fb       	orpd   %xmm11,%xmm7
   21216:	66 44 0f 55 e2       	andnpd %xmm2,%xmm12
   2121b:	66 41 0f 54 f4       	andpd  %xmm12,%xmm6
   21220:	66 45 0f 55 e0       	andnpd %xmm8,%xmm12
   21225:	66 44 0f 56 e6       	orpd   %xmm6,%xmm12
   2122a:	66 44 0f 55 d3       	andnpd %xmm3,%xmm10
   2122f:	66 41 0f 54 ea       	andpd  %xmm10,%xmm5
   21234:	66 44 0f 55 d0       	andnpd %xmm0,%xmm10
   21239:	66 44 0f 56 d5       	orpd   %xmm5,%xmm10
   2123e:	66 0f 28 e7          	movapd %xmm7,%xmm4
   21242:	66 41 0f 28 f9       	movapd %xmm9,%xmm7
   21247:	48 ff c8             	dec    %rax
   2124a:	0f 85 f0 fe ff ff    	jne    21140 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x16b0>
   21250:	66 44 0f 54 e2       	andpd  %xmm2,%xmm12
   21255:	66 0f 55 54 24 10    	andnpd 0x10(%rsp),%xmm2
   2125b:	66 41 0f 56 d4       	orpd   %xmm12,%xmm2
   21260:	66 44 0f 54 d3       	andpd  %xmm3,%xmm10
   21265:	66 0f 55 5c 24 30    	andnpd 0x30(%rsp),%xmm3
   2126b:	66 41 0f 56 da       	orpd   %xmm10,%xmm3
   21270:	66 44 0f 28 c3       	movapd %xmm3,%xmm8
   21275:	66 0f 28 ca          	movapd %xmm2,%xmm1
   21279:	eb 06                	jmp    21281 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x17f1>
   2127b:	66 0f 28 4c 24 10    	movapd 0x10(%rsp),%xmm1
   21281:	66 0f 70 c1 ee       	pshufd $0xee,%xmm1,%xmm0
   21286:	66 0f 28 5c 24 70    	movapd 0x70(%rsp),%xmm3
   2128c:	66 0f 28 d3          	movapd %xmm3,%xmm2
   21290:	f2 0f 5d d1          	minsd  %xmm1,%xmm2
   21294:	66 0f 28 ca          	movapd %xmm2,%xmm1
   21298:	f2 0f c2 ca 03       	cmpunordsd %xmm2,%xmm1
   2129d:	66 0f 28 e1          	movapd %xmm1,%xmm4
   212a1:	66 0f 55 e2          	andnpd %xmm2,%xmm4
   212a5:	66 0f 54 cb          	andpd  %xmm3,%xmm1
   212a9:	66 0f 56 cc          	orpd   %xmm4,%xmm1
   212ad:	66 0f 28 d1          	movapd %xmm1,%xmm2
   212b1:	f2 0f 5d d0          	minsd  %xmm0,%xmm2
   212b5:	66 0f 28 c2          	movapd %xmm2,%xmm0
   212b9:	f2 0f c2 c2 03       	cmpunordsd %xmm2,%xmm0
   212be:	66 0f 54 c8          	andpd  %xmm0,%xmm1
   212c2:	66 0f 55 c2          	andnpd %xmm2,%xmm0
   212c6:	66 0f 56 c1          	orpd   %xmm1,%xmm0
   212ca:	66 0f 28 c8          	movapd %xmm0,%xmm1
   212ce:	f2 41 0f 5d c8       	minsd  %xmm8,%xmm1
   212d3:	66 0f 28 d1          	movapd %xmm1,%xmm2
   212d7:	f2 0f c2 d1 03       	cmpunordsd %xmm1,%xmm2
   212dc:	66 0f 54 c2          	andpd  %xmm2,%xmm0
   212e0:	66 0f 55 d1          	andnpd %xmm1,%xmm2
   212e4:	66 0f 56 d0          	orpd   %xmm0,%xmm2
   212e8:	f2 0f 59 94 24 e0 00 	mulsd  0xe0(%rsp),%xmm2
   212ef:	00 00 
   212f1:	0f 57 c9             	xorps  %xmm1,%xmm1
   212f4:	f2 0f 5a ca          	cvtsd2ss %xmm2,%xmm1
   212f8:	0f 28 84 24 50 01 00 	movaps 0x150(%rsp),%xmm0
   212ff:	00 
   21300:	0f 56 05 69 42 fe ff 	orps   -0x1bd97(%rip),%xmm0        # 5570 <std::thread::current::id::ID+0x48f8>
   21307:	0f 29 84 24 50 01 00 	movaps %xmm0,0x150(%rsp)
   2130e:	00 
   2130f:	bd 40 00 00 00       	mov    $0x40,%ebp
   21314:	0f b6 db             	movzbl %bl,%ebx
   21317:	4c 8d 7c 24 40       	lea    0x40(%rsp),%r15
   2131c:	eb 1a                	jmp    21338 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x18a8>
   2131e:	41 bc 01 00 00 80    	mov    $0x80000001,%r12d
   21324:	66 41 0f 6e cc       	movd   %r12d,%xmm1
   21329:	0f 57 c0             	xorps  %xmm0,%xmm0
   2132c:	f3 0f 5f c8          	maxss  %xmm0,%xmm1
   21330:	ff cd                	dec    %ebp
   21332:	0f 84 88 00 00 00    	je     213c0 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x1930>
   21338:	66 41 0f 7e cc       	movd   %xmm1,%r12d
   2133d:	f3 0f 10 84 24 ac 00 	movss  0xac(%rsp),%xmm0
   21344:	00 00 
   21346:	f3 0f 11 44 24 40    	movss  %xmm0,0x40(%rsp)
   2134c:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
   21351:	f3 0f 11 4c 24 44    	movss  %xmm1,0x44(%rsp)
   21357:	0f 28 84 24 50 01 00 	movaps 0x150(%rsp),%xmm0
   2135e:	00 
   2135f:	f3 0f 11 44 24 48    	movss  %xmm0,0x48(%rsp)
   21365:	c7 44 24 4c 00 00 80 	movl   $0xff800000,0x4c(%rsp)
   2136c:	ff 
   2136d:	4c 89 ff             	mov    %r15,%rdi
   21370:	89 de                	mov    %ebx,%esi
   21372:	e8 69 00 00 00       	call   213e0 <gpui_canvas::color::gamut::in_gamut>
   21377:	84 c0                	test   %al,%al
   21379:	75 38                	jne    213b3 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x1923>
   2137b:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
   21380:	0f 2e c9             	ucomiss %xmm1,%xmm1
   21383:	0f 9a c0             	setp   %al
   21386:	41 81 fc 00 00 80 ff 	cmp    $0xff800000,%r12d
   2138d:	0f 94 c1             	sete   %cl
   21390:	08 c1                	or     %al,%cl
   21392:	75 95                	jne    21329 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x1899>
   21394:	44 89 e0             	mov    %r12d,%eax
   21397:	25 ff ff ff 7f       	and    $0x7fffffff,%eax
   2139c:	74 80                	je     2131e <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x188e>
   2139e:	41 39 c4             	cmp    %eax,%r12d
   213a1:	75 08                	jne    213ab <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x191b>
   213a3:	41 ff cc             	dec    %r12d
   213a6:	e9 79 ff ff ff       	jmp    21324 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x1894>
   213ab:	41 ff c4             	inc    %r12d
   213ae:	e9 71 ff ff ff       	jmp    21324 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x1894>
   213b3:	49 c1 e4 20          	shl    $0x20,%r12
   213b7:	41 be ff ff ff ff    	mov    $0xffffffff,%r14d
   213bd:	4d 09 e6             	or     %r12,%r14
   213c0:	4c 89 f0             	mov    %r14,%rax
   213c3:	48 81 c4 a0 01 00 00 	add    $0x1a0,%rsp
   213ca:	5b                   	pop    %rbx
   213cb:	41 5c                	pop    %r12
   213cd:	41 5e                	pop    %r14
   213cf:	41 5f                	pop    %r15
   213d1:	5d                   	pop    %rbp
   213d2:	c3                   	ret
   213d3:	cc                   	int3
   213d4:	cc                   	int3
   213d5:	cc                   	int3
   213d6:	cc                   	int3
   213d7:	cc                   	int3
   213d8:	cc                   	int3
   213d9:	cc                   	int3
   213da:	cc                   	int3
   213db:	cc                   	int3
   213dc:	cc                   	int3
   213dd:	cc                   	int3
   213de:	cc                   	int3
   213df:	cc                   	int3

gpui_canvas::color::gamut::in_gamut:
   213e0:	55                   	push   %rbp
   213e1:	53                   	push   %rbx
   213e2:	48 83 ec 68          	sub    $0x68,%rsp
   213e6:	89 f3                	mov    %esi,%ebx
   213e8:	f3 0f 7e 0f          	movq   (%rdi),%xmm1
   213ec:	8b 4f 08             	mov    0x8(%rdi),%ecx
   213ef:	8b 57 0c             	mov    0xc(%rdi),%edx
   213f2:	89 c8                	mov    %ecx,%eax
   213f4:	81 fa 00 00 00 c0    	cmp    $0xc0000000,%edx
   213fa:	0f 82 ea 00 00 00    	jb     214ea <gpui_canvas::color::gamut::in_gamut+0x10a>
   21400:	89 c8                	mov    %ecx,%eax
   21402:	85 c9                	test   %ecx,%ecx
   21404:	0f 88 db 00 00 00    	js     214e5 <gpui_canvas::color::gamut::in_gamut+0x105>
   2140a:	c1 e8 08             	shr    $0x8,%eax
   2140d:	89 ce                	mov    %ecx,%esi
   2140f:	48 69 f6 8f e7 54 52 	imul   $0x5254e78f,%rsi,%rsi
   21416:	48 c1 ee 2e          	shr    $0x2e,%rsi
   2141a:	48 69 f8 09 a8 a7 01 	imul   $0x1a7a809,%rax,%rdi
   21421:	48 c1 ef 20          	shr    $0x20,%rdi
   21425:	66 41 0f 7e c9       	movd   %xmm1,%r9d
   2142a:	45 89 ca             	mov    %r9d,%r10d
   2142d:	41 c1 e2 08          	shl    $0x8,%r10d
   21431:	66 0f 70 c1 55       	pshufd $0x55,%xmm1,%xmm0
   21436:	66 41 0f 7e c0       	movd   %xmm0,%r8d
   2143b:	45 89 c3             	mov    %r8d,%r11d
   2143e:	45 0f a4 cb 08       	shld   $0x8,%r9d,%r11d
   21443:	69 ee 55 52 00 00    	imul   $0x5255,%esi,%ebp
   21449:	c1 ed 16             	shr    $0x16,%ebp
   2144c:	69 ed c7 00 00 00    	imul   $0xc7,%ebp,%ebp
   21452:	29 ee                	sub    %ebp,%esi
   21454:	44 89 dd             	mov    %r11d,%ebp
   21457:	c1 e5 08             	shl    $0x8,%ebp
   2145a:	41 81 e3 ff ff 7f 00 	and    $0x7fffff,%r11d
   21461:	41 81 e2 00 00 00 80 	and    $0x80000000,%r10d
   21468:	81 e5 00 00 00 80    	and    $0x80000000,%ebp
   2146e:	44 09 dd             	or     %r11d,%ebp
   21471:	41 81 e1 ff ff 7f 00 	and    $0x7fffff,%r9d
   21478:	45 09 d1             	or     %r10d,%r9d
   2147b:	c1 e6 17             	shl    $0x17,%esi
   2147e:	09 ee                	or     %ebp,%esi
   21480:	c1 e7 0f             	shl    $0xf,%edi
   21483:	81 e7 00 00 80 ff    	and    $0xff800000,%edi
   21489:	41 0f ac c8 10       	shrd   $0x10,%ecx,%r8d
   2148e:	44 09 cf             	or     %r9d,%edi
   21491:	4c 69 c8 9f 53 49 01 	imul   $0x149539f,%rax,%r9
   21498:	49 c1 e9 20          	shr    $0x20,%r9
   2149c:	45 69 c9 c7 00 00 00 	imul   $0xc7,%r9d,%r9d
   214a3:	44 29 c8             	sub    %r9d,%eax
   214a6:	45 89 c1             	mov    %r8d,%r9d
   214a9:	41 81 e1 ff ff 7f 00 	and    $0x7fffff,%r9d
   214b0:	41 c1 e0 08          	shl    $0x8,%r8d
   214b4:	41 81 e0 00 00 00 80 	and    $0x80000000,%r8d
   214bb:	45 09 c8             	or     %r9d,%r8d
   214be:	c1 e0 17             	shl    $0x17,%eax
   214c1:	44 09 c0             	or     %r8d,%eax
   214c4:	66 0f 6e c6          	movd   %esi,%xmm0
   214c8:	66 0f 6e cf          	movd   %edi,%xmm1
   214cc:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
   214d0:	c1 ea 1e             	shr    $0x1e,%edx
   214d3:	31 ed                	xor    %ebp,%ebp
   214d5:	48 8d 35 78 5d fe ff 	lea    -0x1a288(%rip),%rsi        # 7254 <std::thread::current::id::ID+0x65dc>
   214dc:	48 63 14 96          	movslq (%rsi,%rdx,4),%rdx
   214e0:	48 01 f2             	add    %rsi,%rdx
   214e3:	ff e2                	jmp    *%rdx
   214e5:	25 ff ff ff 7f       	and    $0x7fffffff,%eax
   214ea:	c1 ea 1e             	shr    $0x1e,%edx
   214ed:	31 ed                	xor    %ebp,%ebp
   214ef:	48 8d 35 5e 5d fe ff 	lea    -0x1a2a2(%rip),%rsi        # 7254 <std::thread::current::id::ID+0x65dc>
   214f6:	48 63 14 96          	movslq (%rsi,%rdx,4),%rdx
   214fa:	48 01 f2             	add    %rsi,%rdx
   214fd:	ff e2                	jmp    *%rdx
   214ff:	40 b5 01             	mov    $0x1,%bpl
   21502:	f3 0f 5a e9          	cvtss2sd %xmm1,%xmm5
   21506:	66 0f 70 f1 55       	pshufd $0x55,%xmm1,%xmm6
   2150b:	f3 0f 5a e6          	cvtss2sd %xmm6,%xmm4
   2150f:	66 0f 6e d0          	movd   %eax,%xmm2
   21513:	0f 28 05 e6 3b fe ff 	movaps -0x1c41a(%rip),%xmm0        # 5100 <std::thread::current::id::ID+0x4488>
   2151a:	0f 54 c5             	andps  %xmm5,%xmm0
   2151d:	f2 0f 10 1d 0b 5a fe 	movsd  -0x1a5f5(%rip),%xmm3        # 6f30 <std::thread::current::id::ID+0x62b8>
   21524:	ff 
   21525:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   21529:	66 0f 7e 54 24 30    	movd   %xmm2,0x30(%rsp)
   2152f:	73 53                	jae    21584 <gpui_canvas::color::gamut::in_gamut+0x1a4>
   21531:	0f 2e c9             	ucomiss %xmm1,%xmm1
   21534:	0f 29 64 24 10       	movaps %xmm4,0x10(%rsp)
   21539:	0f 29 74 24 50       	movaps %xmm6,0x50(%rsp)
   2153e:	7a 4e                	jp     2158e <gpui_canvas::color::gamut::in_gamut+0x1ae>
   21540:	0f 54 2d e9 3f fe ff 	andps  -0x1c017(%rip),%xmm5        # 5530 <std::thread::current::id::ID+0x48b8>
   21547:	0f 56 2d 22 3f fe ff 	orps   -0x1c0de(%rip),%xmm5        # 5470 <std::thread::current::id::ID+0x47f8>
   2154e:	0f 29 2c 24          	movaps %xmm5,(%rsp)
   21552:	eb 46                	jmp    2159a <gpui_canvas::color::gamut::in_gamut+0x1ba>
   21554:	0f 5a e9             	cvtps2pd %xmm1,%xmm5
   21557:	66 0f 6e c0          	movd   %eax,%xmm0
   2155b:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   2155f:	e9 ad 01 00 00       	jmp    21711 <gpui_canvas::color::gamut::in_gamut+0x331>
   21564:	85 c9                	test   %ecx,%ecx
   21566:	0f 88 86 02 00 00    	js     217f2 <gpui_canvas::color::gamut::in_gamut+0x412>
   2156c:	0f 5a e9             	cvtps2pd %xmm1,%xmm5
   2156f:	66 0f 6e c0          	movd   %eax,%xmm0
   21573:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   21577:	84 db                	test   %bl,%bl
   21579:	0f 84 5e 02 00 00    	je     217dd <gpui_canvas::color::gamut::in_gamut+0x3fd>
   2157f:	e9 a7 02 00 00       	jmp    2182b <gpui_canvas::color::gamut::in_gamut+0x44b>
   21584:	f2 0f 5e 2d 44 59 fe 	divsd  -0x1a6bc(%rip),%xmm5        # 6ed0 <std::thread::current::id::ID+0x6258>
   2158b:	ff 
   2158c:	eb 4b                	jmp    215d9 <gpui_canvas::color::gamut::in_gamut+0x1f9>
   2158e:	f2 0f 10 0d 2a 5a fe 	movsd  -0x1a5d6(%rip),%xmm1        # 6fc0 <std::thread::current::id::ID+0x6348>
   21595:	ff 
   21596:	0f 29 0c 24          	movaps %xmm1,(%rsp)
   2159a:	f2 0f 58 05 9e 5a fe 	addsd  -0x1a562(%rip),%xmm0        # 7040 <std::thread::current::id::ID+0x63c8>
   215a1:	ff 
   215a2:	f2 0f 5e 05 36 5a fe 	divsd  -0x1a5ca(%rip),%xmm0        # 6fe0 <std::thread::current::id::ID+0x6368>
   215a9:	ff 
   215aa:	f2 0f 10 0d d6 59 fe 	movsd  -0x1a62a(%rip),%xmm1        # 6f88 <std::thread::current::id::ID+0x6310>
   215b1:	ff 
   215b2:	ff 15 38 22 04 00    	call   *0x42238(%rip)        # 637f0 <pow@GLIBC_2.29>
   215b8:	66 0f 28 e8          	movapd %xmm0,%xmm5
   215bc:	f2 0f 59 2c 24       	mulsd  (%rsp),%xmm5
   215c1:	66 0f 6e 54 24 30    	movd   0x30(%rsp),%xmm2
   215c7:	f2 0f 10 1d 61 59 fe 	movsd  -0x1a69f(%rip),%xmm3        # 6f30 <std::thread::current::id::ID+0x62b8>
   215ce:	ff 
   215cf:	0f 28 64 24 10       	movaps 0x10(%rsp),%xmm4
   215d4:	0f 28 74 24 50       	movaps 0x50(%rsp),%xmm6
   215d9:	0f 57 c9             	xorps  %xmm1,%xmm1
   215dc:	f3 0f 5a ca          	cvtss2sd %xmm2,%xmm1
   215e0:	0f 28 05 19 3b fe ff 	movaps -0x1c4e7(%rip),%xmm0        # 5100 <std::thread::current::id::ID+0x4488>
   215e7:	0f 54 c4             	andps  %xmm4,%xmm0
   215ea:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   215ee:	66 0f 29 2c 24       	movapd %xmm5,(%rsp)
   215f3:	73 1f                	jae    21614 <gpui_canvas::color::gamut::in_gamut+0x234>
   215f5:	0f 2e f6             	ucomiss %xmm6,%xmm6
   215f8:	0f 29 4c 24 20       	movaps %xmm1,0x20(%rsp)
   215fd:	7a 4b                	jp     2164a <gpui_canvas::color::gamut::in_gamut+0x26a>
   215ff:	0f 54 25 2a 3f fe ff 	andps  -0x1c0d6(%rip),%xmm4        # 5530 <std::thread::current::id::ID+0x48b8>
   21606:	0f 56 25 63 3e fe ff 	orps   -0x1c19d(%rip),%xmm4        # 5470 <std::thread::current::id::ID+0x47f8>
   2160d:	0f 29 64 24 10       	movaps %xmm4,0x10(%rsp)
   21612:	eb 43                	jmp    21657 <gpui_canvas::color::gamut::in_gamut+0x277>
   21614:	f2 0f 5e 25 b4 58 fe 	divsd  -0x1a74c(%rip),%xmm4        # 6ed0 <std::thread::current::id::ID+0x6258>
   2161b:	ff 
   2161c:	0f 28 05 dd 3a fe ff 	movaps -0x1c523(%rip),%xmm0        # 5100 <std::thread::current::id::ID+0x4488>
   21623:	0f 54 c1             	andps  %xmm1,%xmm0
   21626:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   2162a:	72 7e                	jb     216aa <gpui_canvas::color::gamut::in_gamut+0x2ca>
   2162c:	f2 0f 5e 0d 9c 58 fe 	divsd  -0x1a764(%rip),%xmm1        # 6ed0 <std::thread::current::id::ID+0x6258>
   21633:	ff 
   21634:	66 0f 28 c1          	movapd %xmm1,%xmm0
   21638:	66 0f 14 ec          	unpcklpd %xmm4,%xmm5
   2163c:	40 84 ed             	test   %bpl,%bpl
   2163f:	0f 85 cc 00 00 00    	jne    21711 <gpui_canvas::color::gamut::in_gamut+0x331>
   21645:	e9 8f 01 00 00       	jmp    217d9 <gpui_canvas::color::gamut::in_gamut+0x3f9>
   2164a:	f2 0f 10 0d 6e 59 fe 	movsd  -0x1a692(%rip),%xmm1        # 6fc0 <std::thread::current::id::ID+0x6348>
   21651:	ff 
   21652:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
   21657:	f2 0f 58 05 e1 59 fe 	addsd  -0x1a61f(%rip),%xmm0        # 7040 <std::thread::current::id::ID+0x63c8>
   2165e:	ff 
   2165f:	f2 0f 5e 05 79 59 fe 	divsd  -0x1a687(%rip),%xmm0        # 6fe0 <std::thread::current::id::ID+0x6368>
   21666:	ff 
   21667:	f2 0f 10 0d 19 59 fe 	movsd  -0x1a6e7(%rip),%xmm1        # 6f88 <std::thread::current::id::ID+0x6310>
   2166e:	ff 
   2166f:	ff 15 7b 21 04 00    	call   *0x4217b(%rip)        # 637f0 <pow@GLIBC_2.29>
   21675:	66 0f 28 e0          	movapd %xmm0,%xmm4
   21679:	f2 0f 59 64 24 10    	mulsd  0x10(%rsp),%xmm4
   2167f:	66 0f 28 2c 24       	movapd (%rsp),%xmm5
   21684:	f3 0f 10 54 24 30    	movss  0x30(%rsp),%xmm2
   2168a:	f2 0f 10 1d 9e 58 fe 	movsd  -0x1a762(%rip),%xmm3        # 6f30 <std::thread::current::id::ID+0x62b8>
   21691:	ff 
   21692:	66 0f 28 4c 24 20    	movapd 0x20(%rsp),%xmm1
   21698:	66 0f 28 05 60 3a fe 	movapd -0x1c5a0(%rip),%xmm0        # 5100 <std::thread::current::id::ID+0x4488>
   2169f:	ff 
   216a0:	66 0f 54 c1          	andpd  %xmm1,%xmm0
   216a4:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   216a8:	73 82                	jae    2162c <gpui_canvas::color::gamut::in_gamut+0x24c>
   216aa:	0f 2e d2             	ucomiss %xmm2,%xmm2
   216ad:	66 0f 29 64 24 10    	movapd %xmm4,0x10(%rsp)
   216b3:	7a 12                	jp     216c7 <gpui_canvas::color::gamut::in_gamut+0x2e7>
   216b5:	66 0f 54 0d 73 3e fe 	andpd  -0x1c18d(%rip),%xmm1        # 5530 <std::thread::current::id::ID+0x48b8>
   216bc:	ff 
   216bd:	66 0f 56 0d ab 3d fe 	orpd   -0x1c255(%rip),%xmm1        # 5470 <std::thread::current::id::ID+0x47f8>
   216c4:	ff 
   216c5:	eb 08                	jmp    216cf <gpui_canvas::color::gamut::in_gamut+0x2ef>
   216c7:	f2 0f 10 0d f1 58 fe 	movsd  -0x1a70f(%rip),%xmm1        # 6fc0 <std::thread::current::id::ID+0x6348>
   216ce:	ff 
   216cf:	66 0f 29 4c 24 20    	movapd %xmm1,0x20(%rsp)
   216d5:	f2 0f 58 05 63 59 fe 	addsd  -0x1a69d(%rip),%xmm0        # 7040 <std::thread::current::id::ID+0x63c8>
   216dc:	ff 
   216dd:	f2 0f 5e 05 fb 58 fe 	divsd  -0x1a705(%rip),%xmm0        # 6fe0 <std::thread::current::id::ID+0x6368>
   216e4:	ff 
   216e5:	f2 0f 10 0d 9b 58 fe 	movsd  -0x1a765(%rip),%xmm1        # 6f88 <std::thread::current::id::ID+0x6310>
   216ec:	ff 
   216ed:	ff 15 fd 20 04 00    	call   *0x420fd(%rip)        # 637f0 <pow@GLIBC_2.29>
   216f3:	f2 0f 59 44 24 20    	mulsd  0x20(%rsp),%xmm0
   216f9:	66 0f 28 2c 24       	movapd (%rsp),%xmm5
   216fe:	66 0f 28 64 24 10    	movapd 0x10(%rsp),%xmm4
   21704:	66 0f 14 ec          	unpcklpd %xmm4,%xmm5
   21708:	40 84 ed             	test   %bpl,%bpl
   2170b:	0f 84 c8 00 00 00    	je     217d9 <gpui_canvas::color::gamut::in_gamut+0x3f9>
   21711:	66 0f 28 d5          	movapd %xmm5,%xmm2
   21715:	66 0f c6 d5 01       	shufpd $0x1,%xmm5,%xmm2
   2171a:	66 0f 59 15 5e 3d fe 	mulpd  -0x1c2a2(%rip),%xmm2        # 5480 <std::thread::current::id::ID+0x4808>
   21721:	ff 
   21722:	66 0f 57 db          	xorpd  %xmm3,%xmm3
   21726:	66 0f 16 1d fa 58 fe 	movhpd -0x1a706(%rip),%xmm3        # 7028 <std::thread::current::id::ID+0x63b0>
   2172d:	ff 
   2172e:	66 0f 59 dd          	mulpd  %xmm5,%xmm3
   21732:	0f 28 c8             	movaps %xmm0,%xmm1
   21735:	0f 16 c8             	movlhps %xmm0,%xmm1
   21738:	66 0f 59 0d d0 39 fe 	mulpd  -0x1c630(%rip),%xmm1        # 5110 <std::thread::current::id::ID+0x4498>
   2173f:	ff 
   21740:	66 0f 58 da          	addpd  %xmm2,%xmm3
   21744:	66 0f 58 cb          	addpd  %xmm3,%xmm1
   21748:	f2 0f 10 15 b8 57 fe 	movsd  -0x1a848(%rip),%xmm2        # 6f08 <std::thread::current::id::ID+0x6290>
   2174f:	ff 
   21750:	f2 0f 59 d5          	mulsd  %xmm5,%xmm2
   21754:	f2 0f 10 e8          	movsd  %xmm0,%xmm5
   21758:	66 0f 59 2d c0 39 fe 	mulpd  -0x1c640(%rip),%xmm5        # 5120 <std::thread::current::id::ID+0x44a8>
   2175f:	ff 
   21760:	66 0f 28 c5          	movapd %xmm5,%xmm0
   21764:	66 0f 15 c5          	unpckhpd %xmm5,%xmm0
   21768:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   2176c:	f2 0f 58 c5          	addsd  %xmm5,%xmm0
   21770:	f2 0f 10 15 68 57 fe 	movsd  -0x1a898(%rip),%xmm2        # 6ee0 <std::thread::current::id::ID+0x6268>
   21777:	ff 
   21778:	66 0f 28 d9          	movapd %xmm1,%xmm3
   2177c:	f2 0f 10 d8          	movsd  %xmm0,%xmm3
   21780:	66 0f 59 1d e8 3b fe 	mulpd  -0x1c418(%rip),%xmm3        # 5370 <std::thread::current::id::ID+0x46f8>
   21787:	ff 
   21788:	66 0f 28 e1          	movapd %xmm1,%xmm4
   2178c:	66 0f c6 e0 01       	shufpd $0x1,%xmm0,%xmm4
   21791:	66 0f 59 25 47 3b fe 	mulpd  -0x1c4b9(%rip),%xmm4        # 52e0 <std::thread::current::id::ID+0x4668>
   21798:	ff 
   21799:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
   2179d:	66 0f 58 e3          	addpd  %xmm3,%xmm4
   217a1:	66 0f 28 e9          	movapd %xmm1,%xmm5
   217a5:	66 0f 14 e9          	unpcklpd %xmm1,%xmm5
   217a9:	66 0f 59 2d 8f 3d fe 	mulpd  -0x1c271(%rip),%xmm5        # 5540 <std::thread::current::id::ID+0x48c8>
   217b0:	ff 
   217b1:	66 0f 28 c4          	movapd %xmm4,%xmm0
   217b5:	66 0f 5c c5          	subpd  %xmm5,%xmm0
   217b9:	66 0f 58 ec          	addpd  %xmm4,%xmm5
   217bd:	f2 0f 10 e8          	movsd  %xmm0,%xmm5
   217c1:	66 0f 59 0d 87 3b fe 	mulpd  -0x1c479(%rip),%xmm1        # 5350 <std::thread::current::id::ID+0x46d8>
   217c8:	ff 
   217c9:	66 0f 28 c1          	movapd %xmm1,%xmm0
   217cd:	66 0f 15 c1          	unpckhpd %xmm1,%xmm0
   217d1:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   217d5:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
   217d9:	84 db                	test   %bl,%bl
   217db:	75 4e                	jne    2182b <gpui_canvas::color::gamut::in_gamut+0x44b>
   217dd:	31 c0                	xor    %eax,%eax
   217df:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   217e3:	66 0f 2e e9          	ucomisd %xmm1,%xmm5
   217e7:	0f 83 08 01 00 00    	jae    218f5 <gpui_canvas::color::gamut::in_gamut+0x515>
   217ed:	e9 41 01 00 00       	jmp    21933 <gpui_canvas::color::gamut::in_gamut+0x553>
   217f2:	66 0f 6f d1          	movdqa %xmm1,%xmm2
   217f6:	0f c6 c9 55          	shufps $0x55,%xmm1,%xmm1
   217fa:	66 0f ef c0          	pxor   %xmm0,%xmm0
   217fe:	0f 2e c8             	ucomiss %xmm0,%xmm1
   21801:	0f 85 35 01 00 00    	jne    2193c <gpui_canvas::color::gamut::in_gamut+0x55c>
   21807:	0f 8a 2f 01 00 00    	jp     2193c <gpui_canvas::color::gamut::in_gamut+0x55c>
   2180d:	0f 57 c9             	xorps  %xmm1,%xmm1
   21810:	f3 0f 5a ca          	cvtss2sd %xmm2,%xmm1
   21814:	0f 28 c1             	movaps %xmm1,%xmm0
   21817:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   2181b:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   2181f:	66 0f 28 e8          	movapd %xmm0,%xmm5
   21823:	66 0f 14 e8          	unpcklpd %xmm0,%xmm5
   21827:	84 db                	test   %bl,%bl
   21829:	74 b2                	je     217dd <gpui_canvas::color::gamut::in_gamut+0x3fd>
   2182b:	66 0f 28 0d 4d 39 fe 	movapd -0x1c6b3(%rip),%xmm1        # 5180 <std::thread::current::id::ID+0x4508>
   21832:	ff 
   21833:	66 0f 59 cd          	mulpd  %xmm5,%xmm1
   21837:	66 0f 28 d5          	movapd %xmm5,%xmm2
   2183b:	66 0f c6 d5 01       	shufpd $0x1,%xmm5,%xmm2
   21840:	66 0f 59 15 88 3c fe 	mulpd  -0x1c378(%rip),%xmm2        # 54d0 <std::thread::current::id::ID+0x4858>
   21847:	ff 
   21848:	66 0f 58 d1          	addpd  %xmm1,%xmm2
   2184c:	66 0f 28 c8          	movapd %xmm0,%xmm1
   21850:	66 0f 14 c8          	unpcklpd %xmm0,%xmm1
   21854:	66 0f 59 0d b4 39 fe 	mulpd  -0x1c64c(%rip),%xmm1        # 5210 <std::thread::current::id::ID+0x4598>
   2185b:	ff 
   2185c:	f2 0f 10 1d dc 56 fe 	movsd  -0x1a924(%rip),%xmm3        # 6f40 <std::thread::current::id::ID+0x62c8>
   21863:	ff 
   21864:	f2 0f 59 dd          	mulsd  %xmm5,%xmm3
   21868:	f2 0f 10 e8          	movsd  %xmm0,%xmm5
   2186c:	66 0f 59 2d ac 39 fe 	mulpd  -0x1c654(%rip),%xmm5        # 5220 <std::thread::current::id::ID+0x45a8>
   21873:	ff 
   21874:	66 0f 58 ca          	addpd  %xmm2,%xmm1
   21878:	66 0f 28 c5          	movapd %xmm5,%xmm0
   2187c:	66 0f 15 c5          	unpckhpd %xmm5,%xmm0
   21880:	f2 0f 58 c3          	addsd  %xmm3,%xmm0
   21884:	66 0f 28 d1          	movapd %xmm1,%xmm2
   21888:	66 0f c6 d1 01       	shufpd $0x1,%xmm1,%xmm2
   2188d:	66 0f 59 15 9b 38 fe 	mulpd  -0x1c765(%rip),%xmm2        # 5130 <std::thread::current::id::ID+0x44b8>
   21894:	ff 
   21895:	f2 0f 58 c5          	addsd  %xmm5,%xmm0
   21899:	66 0f 28 1d ef 38 fe 	movapd -0x1c711(%rip),%xmm3        # 5190 <std::thread::current::id::ID+0x4518>
   218a0:	ff 
   218a1:	66 0f 59 d9          	mulpd  %xmm1,%xmm3
   218a5:	66 0f 5c da          	subpd  %xmm2,%xmm3
   218a9:	66 0f 28 e8          	movapd %xmm0,%xmm5
   218ad:	66 0f 14 e8          	unpcklpd %xmm0,%xmm5
   218b1:	66 0f 59 2d 47 39 fe 	mulpd  -0x1c6b9(%rip),%xmm5        # 5200 <std::thread::current::id::ID+0x4588>
   218b8:	ff 
   218b9:	66 0f 28 d3          	movapd %xmm3,%xmm2
   218bd:	66 0f 5c d5          	subpd  %xmm5,%xmm2
   218c1:	66 0f 58 eb          	addpd  %xmm3,%xmm5
   218c5:	f2 0f 10 ea          	movsd  %xmm2,%xmm5
   218c9:	66 0f 59 0d 1f 3b fe 	mulpd  -0x1c4e1(%rip),%xmm1        # 53f0 <std::thread::current::id::ID+0x4778>
   218d0:	ff 
   218d1:	66 0f 28 d1          	movapd %xmm1,%xmm2
   218d5:	66 0f 15 d1          	unpckhpd %xmm1,%xmm2
   218d9:	f2 0f 5c ca          	subsd  %xmm2,%xmm1
   218dd:	f2 0f 59 05 eb 56 fe 	mulsd  -0x1a915(%rip),%xmm0        # 6fd0 <std::thread::current::id::ID+0x6358>
   218e4:	ff 
   218e5:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
   218e9:	31 c0                	xor    %eax,%eax
   218eb:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   218ef:	66 0f 2e e9          	ucomisd %xmm1,%xmm5
   218f3:	72 3e                	jb     21933 <gpui_canvas::color::gamut::in_gamut+0x553>
   218f5:	f2 0f 10 0d 5b 56 fe 	movsd  -0x1a9a5(%rip),%xmm1        # 6f58 <std::thread::current::id::ID+0x62e0>
   218fc:	ff 
   218fd:	66 0f 2e cd          	ucomisd %xmm5,%xmm1
   21901:	72 30                	jb     21933 <gpui_canvas::color::gamut::in_gamut+0x553>
   21903:	66 0f 15 ed          	unpckhpd %xmm5,%xmm5
   21907:	31 c0                	xor    %eax,%eax
   21909:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   2190d:	66 0f 2e ea          	ucomisd %xmm2,%xmm5
   21911:	72 20                	jb     21933 <gpui_canvas::color::gamut::in_gamut+0x553>
   21913:	66 0f 2e cd          	ucomisd %xmm5,%xmm1
   21917:	72 1a                	jb     21933 <gpui_canvas::color::gamut::in_gamut+0x553>
   21919:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   2191d:	f2 0f c2 c8 02       	cmplesd %xmm0,%xmm1
   21922:	f2 0f c2 05 2d 56 fe 	cmplesd -0x1a9d3(%rip),%xmm0        # 6f58 <std::thread::current::id::ID+0x62e0>
   21929:	ff 02 
   2192b:	66 0f 54 c1          	andpd  %xmm1,%xmm0
   2192f:	66 0f 7e c0          	movd   %xmm0,%eax
   21933:	24 01                	and    $0x1,%al
   21935:	48 83 c4 68          	add    $0x68,%rsp
   21939:	5b                   	pop    %rbx
   2193a:	5d                   	pop    %rbp
   2193b:	c3                   	ret
   2193c:	66 0f 6e c0          	movd   %eax,%xmm0
   21940:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   21944:	f2 0f 59 05 d4 56 fe 	mulsd  -0x1a92c(%rip),%xmm0        # 7020 <std::thread::current::id::ID+0x63a8>
   2194b:	ff 
   2194c:	48 8d 7c 24 48       	lea    0x48(%rsp),%rdi
   21951:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
   21956:	0f 29 0c 24          	movaps %xmm1,(%rsp)
   2195a:	66 0f 7f 54 24 30    	movdqa %xmm2,0x30(%rsp)
   21960:	ff 15 9a 1e 04 00    	call   *0x41e9a(%rip)        # 63800 <sincos@GLIBC_2.2.5>
   21966:	0f 28 44 24 30       	movaps 0x30(%rsp),%xmm0
   2196b:	0f 57 c9             	xorps  %xmm1,%xmm1
   2196e:	f3 0f 5a c8          	cvtss2sd %xmm0,%xmm1
   21972:	0f 28 04 24          	movaps (%rsp),%xmm0
   21976:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   2197a:	f2 0f 10 54 24 40    	movsd  0x40(%rsp),%xmm2
   21980:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
   21984:	f2 0f 59 44 24 48    	mulsd  0x48(%rsp),%xmm0
   2198a:	f2 0f 10 1d 86 56 fe 	movsd  -0x1a97a(%rip),%xmm3        # 7018 <std::thread::current::id::ID+0x63a0>
   21991:	ff 
   21992:	f2 0f 59 da          	mulsd  %xmm2,%xmm3
   21996:	f2 0f 58 d9          	addsd  %xmm1,%xmm3
   2199a:	f2 0f 10 2d 26 56 fe 	movsd  -0x1a9da(%rip),%xmm5        # 6fc8 <std::thread::current::id::ID+0x6350>
   219a1:	ff 
   219a2:	f2 0f 59 e8          	mulsd  %xmm0,%xmm5
   219a6:	f2 0f 58 eb          	addsd  %xmm3,%xmm5
   219aa:	f2 0f 10 1d e6 55 fe 	movsd  -0x1aa1a(%rip),%xmm3        # 6f98 <std::thread::current::id::ID+0x6320>
   219b1:	ff 
   219b2:	f2 0f 59 da          	mulsd  %xmm2,%xmm3
   219b6:	f2 0f 58 d9          	addsd  %xmm1,%xmm3
   219ba:	f2 0f 10 35 86 56 fe 	movsd  -0x1a97a(%rip),%xmm6        # 7048 <std::thread::current::id::ID+0x63d0>
   219c1:	ff 
   219c2:	f2 0f 59 f0          	mulsd  %xmm0,%xmm6
   219c6:	f2 0f 58 f3          	addsd  %xmm3,%xmm6
   219ca:	f2 0f 59 15 36 56 fe 	mulsd  -0x1a9ca(%rip),%xmm2        # 7008 <std::thread::current::id::ID+0x6390>
   219d1:	ff 
   219d2:	f2 0f 58 d1          	addsd  %xmm1,%xmm2
   219d6:	f2 0f 59 05 fa 54 fe 	mulsd  -0x1ab06(%rip),%xmm0        # 6ed8 <std::thread::current::id::ID+0x6260>
   219dd:	ff 
   219de:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   219e2:	66 0f 28 e5          	movapd %xmm5,%xmm4
   219e6:	f2 0f 59 e5          	mulsd  %xmm5,%xmm4
   219ea:	f2 0f 59 e5          	mulsd  %xmm5,%xmm4
   219ee:	66 0f 28 de          	movapd %xmm6,%xmm3
   219f2:	f2 0f 59 de          	mulsd  %xmm6,%xmm3
   219f6:	f2 0f 59 de          	mulsd  %xmm6,%xmm3
   219fa:	66 0f 28 c8          	movapd %xmm0,%xmm1
   219fe:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   21a02:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   21a06:	f2 0f 10 05 42 56 fe 	movsd  -0x1a9be(%rip),%xmm0        # 7050 <std::thread::current::id::ID+0x63d8>
   21a0d:	ff 
   21a0e:	f2 0f 59 c4          	mulsd  %xmm4,%xmm0
   21a12:	f2 0f 10 15 4e 55 fe 	movsd  -0x1aab2(%rip),%xmm2        # 6f68 <std::thread::current::id::ID+0x62f0>
   21a19:	ff 
   21a1a:	f2 0f 59 d3          	mulsd  %xmm3,%xmm2
   21a1e:	f2 0f 58 d0          	addsd  %xmm0,%xmm2
   21a22:	f2 0f 10 05 46 55 fe 	movsd  -0x1aaba(%rip),%xmm0        # 6f70 <std::thread::current::id::ID+0x62f8>
   21a29:	ff 
   21a2a:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   21a2e:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   21a32:	f2 0f 10 15 a6 54 fe 	movsd  -0x1ab5a(%rip),%xmm2        # 6ee0 <std::thread::current::id::ID+0x6268>
   21a39:	ff 
   21a3a:	66 0f 14 e4          	unpcklpd %xmm4,%xmm4
   21a3e:	66 0f 59 25 ba 3a fe 	mulpd  -0x1c546(%rip),%xmm4        # 5500 <std::thread::current::id::ID+0x4888>
   21a45:	ff 
   21a46:	66 0f 14 db          	unpcklpd %xmm3,%xmm3
   21a4a:	66 0f 59 1d be 3a fe 	mulpd  -0x1c542(%rip),%xmm3        # 5510 <std::thread::current::id::ID+0x4898>
   21a51:	ff 
   21a52:	66 0f 58 dc          	addpd  %xmm4,%xmm3
   21a56:	66 0f 14 c9          	unpcklpd %xmm1,%xmm1
   21a5a:	66 0f 59 0d de 38 fe 	mulpd  -0x1c722(%rip),%xmm1        # 5340 <std::thread::current::id::ID+0x46c8>
   21a61:	ff 
   21a62:	66 0f 58 cb          	addpd  %xmm3,%xmm1
   21a66:	e9 0d fd ff ff       	jmp    21778 <gpui_canvas::color::gamut::in_gamut+0x398>

