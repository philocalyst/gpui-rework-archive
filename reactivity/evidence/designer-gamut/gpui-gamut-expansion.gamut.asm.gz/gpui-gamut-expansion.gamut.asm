<gpui_canvas::color::OutputProfile>::max_chroma:
   1f060:	66 0f 7e c1          	movd   %xmm0,%ecx
   1f064:	81 e1 ff ff ff 7f    	and    $0x7fffffff,%ecx
   1f06a:	b8 0d 00 00 00       	mov    $0xd,%eax
   1f06f:	81 f9 ff ff 7f 7f    	cmp    $0x7f7fffff,%ecx
   1f075:	7f 38                	jg     1f0af <<gpui_canvas::color::OutputProfile>::max_chroma+0x4f>
   1f077:	0f 57 e4             	xorps  %xmm4,%xmm4
   1f07a:	0f 57 d2             	xorps  %xmm2,%xmm2
   1f07d:	f3 0f c2 d0 06       	cmpnless %xmm0,%xmm2
   1f082:	0f 28 d8             	movaps %xmm0,%xmm3
   1f085:	f3 0f c2 1d 9a 65 fe 	cmpnless -0x19a66(%rip),%xmm3        # 5628 <std::thread::current::id::ID+0x49b0>
   1f08c:	ff 06 
   1f08e:	0f 56 da             	orps   %xmm2,%xmm3
   1f091:	66 0f 7e d9          	movd   %xmm3,%ecx
   1f095:	66 0f 7e ca          	movd   %xmm1,%edx
   1f099:	81 e2 ff ff ff 7f    	and    $0x7fffffff,%edx
   1f09f:	81 fa 00 00 80 7f    	cmp    $0x7f800000,%edx
   1f0a5:	0f 9d c2             	setge  %dl
   1f0a8:	08 ca                	or     %cl,%dl
   1f0aa:	f6 c2 01             	test   $0x1,%dl
   1f0ad:	74 01                	je     1f0b0 <<gpui_canvas::color::OutputProfile>::max_chroma+0x50>
   1f0af:	c3                   	ret
   1f0b0:	0f 2e c4             	ucomiss %xmm4,%xmm0
   1f0b3:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   1f0b8:	75 02                	jne    1f0bc <<gpui_canvas::color::OutputProfile>::max_chroma+0x5c>
   1f0ba:	7b f3                	jnp    1f0af <<gpui_canvas::color::OutputProfile>::max_chroma+0x4f>
   1f0bc:	0f 2e 05 65 65 fe ff 	ucomiss -0x19a9b(%rip),%xmm0        # 5628 <std::thread::current::id::ID+0x49b0>
   1f0c3:	75 02                	jne    1f0c7 <<gpui_canvas::color::OutputProfile>::max_chroma+0x67>
   1f0c5:	7b e8                	jnp    1f0af <<gpui_canvas::color::OutputProfile>::max_chroma+0x4f>
   1f0c7:	53                   	push   %rbx
   1f0c8:	48 83 ec 10          	sub    $0x10,%rsp
   1f0cc:	f3 0f 11 44 24 0c    	movss  %xmm0,0xc(%rsp)
   1f0d2:	89 fb                	mov    %edi,%ebx
   1f0d4:	0f 57 c0             	xorps  %xmm0,%xmm0
   1f0d7:	f3 0f 5a c1          	cvtss2sd %xmm1,%xmm0
   1f0db:	f2 0f 10 0d e5 7f fe 	movsd  -0x1801b(%rip),%xmm1        # 70c8 <std::thread::current::id::ID+0x6450>
   1f0e2:	ff 
   1f0e3:	ff 15 c7 47 04 00    	call   *0x447c7(%rip)        # 638b0 <_DYNAMIC+0x370>
   1f0e9:	f2 0f 10 1d d7 7f fe 	movsd  -0x18029(%rip),%xmm3        # 70c8 <std::thread::current::id::ID+0x6450>
   1f0f0:	ff 
   1f0f1:	f2 0f 58 d8          	addsd  %xmm0,%xmm3
   1f0f5:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   1f0f9:	66 0f 28 d0          	movapd %xmm0,%xmm2
   1f0fd:	f2 0f c2 d1 01       	cmpltsd %xmm1,%xmm2
   1f102:	66 0f 54 da          	andpd  %xmm2,%xmm3
   1f106:	66 0f 55 d0          	andnpd %xmm0,%xmm2
   1f10a:	66 0f 56 d3          	orpd   %xmm3,%xmm2
   1f10e:	66 0f 2e 15 32 7f fe 	ucomisd -0x180ce(%rip),%xmm2        # 7048 <std::thread::current::id::ID+0x63d0>
   1f115:	ff 
   1f116:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   1f11a:	73 0f                	jae    1f12b <<gpui_canvas::color::OutputProfile>::max_chroma+0xcb>
   1f11c:	0f 57 c0             	xorps  %xmm0,%xmm0
   1f11f:	f2 0f 5a c2          	cvtsd2ss %xmm2,%xmm0
   1f123:	f3 0f c2 c8 00       	cmpeqss %xmm0,%xmm1
   1f128:	0f 55 c8             	andnps %xmm0,%xmm1
   1f12b:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   1f131:	0f b6 fb             	movzbl %bl,%edi
   1f134:	48 83 c4 10          	add    $0x10,%rsp
   1f138:	5b                   	pop    %rbx
   1f139:	e9 42 17 00 00       	jmp    20880 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>>
   1f13e:	cc                   	int3
   1f13f:	cc                   	int3

<gpui_canvas::color::Color>::fit_chroma:
   1f4b0:	55                   	push   %rbp
   1f4b1:	41 57                	push   %r15
   1f4b3:	41 56                	push   %r14
   1f4b5:	41 54                	push   %r12
   1f4b7:	53                   	push   %rbx
   1f4b8:	48 83 ec 30          	sub    $0x30,%rsp
   1f4bc:	48 89 fb             	mov    %rdi,%rbx
   1f4bf:	44 8b 66 08          	mov    0x8(%rsi),%r12d
   1f4c3:	44 8b 7e 0c          	mov    0xc(%rsi),%r15d
   1f4c7:	41 81 ff 00 00 00 c0 	cmp    $0xc0000000,%r15d
   1f4ce:	0f 92 c0             	setb   %al
   1f4d1:	45 85 e4             	test   %r12d,%r12d
   1f4d4:	0f 99 c1             	setns  %cl
   1f4d7:	08 c1                	or     %al,%cl
   1f4d9:	74 09                	je     1f4e4 <<gpui_canvas::color::Color>::fit_chroma+0x34>
   1f4db:	c7 43 04 0d 00 00 00 	movl   $0xd,0x4(%rbx)
   1f4e2:	eb 4a                	jmp    1f52e <<gpui_canvas::color::Color>::fit_chroma+0x7e>
   1f4e4:	49 89 f6             	mov    %rsi,%r14
   1f4e7:	0f 10 06             	movups (%rsi),%xmm0
   1f4ea:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   1f4ef:	0f b6 ea             	movzbl %dl,%ebp
   1f4f2:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   1f4f7:	89 ee                	mov    %ebp,%esi
   1f4f9:	e8 92 1f 00 00       	call   21490 <gpui_canvas::color::gamut::in_gamut>
   1f4fe:	84 c0                	test   %al,%al
   1f500:	74 0c                	je     1f50e <<gpui_canvas::color::Color>::fit_chroma+0x5e>
   1f502:	41 0f 10 06          	movups (%r14),%xmm0
   1f506:	0f 11 43 04          	movups %xmm0,0x4(%rbx)
   1f50a:	31 c0                	xor    %eax,%eax
   1f50c:	eb 25                	jmp    1f533 <<gpui_canvas::color::Color>::fit_chroma+0x83>
   1f50e:	41 8b 16             	mov    (%r14),%edx
   1f511:	89 d6                	mov    %edx,%esi
   1f513:	81 e6 ff ff ff 7f    	and    $0x7fffffff,%esi
   1f519:	b8 0d 00 00 00       	mov    $0xd,%eax
   1f51e:	31 c9                	xor    %ecx,%ecx
   1f520:	81 fe ff ff 7f 7f    	cmp    $0x7f7fffff,%esi
   1f526:	7e 1d                	jle    1f545 <<gpui_canvas::color::Color>::fit_chroma+0x95>
   1f528:	89 43 04             	mov    %eax,0x4(%rbx)
   1f52b:	89 4b 08             	mov    %ecx,0x8(%rbx)
   1f52e:	b8 01 00 00 00       	mov    $0x1,%eax
   1f533:	89 03                	mov    %eax,(%rbx)
   1f535:	48 89 d8             	mov    %rbx,%rax
   1f538:	48 83 c4 30          	add    $0x30,%rsp
   1f53c:	5b                   	pop    %rbx
   1f53d:	41 5c                	pop    %r12
   1f53f:	41 5e                	pop    %r14
   1f541:	41 5f                	pop    %r15
   1f543:	5d                   	pop    %rbp
   1f544:	c3                   	ret
   1f545:	44 89 e6             	mov    %r12d,%esi
   1f548:	81 e6 ff ff ff 7f    	and    $0x7fffffff,%esi
   1f54e:	66 0f 6e c6          	movd   %esi,%xmm0
   1f552:	0f 2e 05 03 61 fe ff 	ucomiss -0x19efd(%rip),%xmm0        # 565c <std::thread::current::id::ID+0x49e4>
   1f559:	74 cd                	je     1f528 <<gpui_canvas::color::Color>::fit_chroma+0x78>
   1f55b:	66 0f 6e d2          	movd   %edx,%xmm2
   1f55f:	0f 57 c9             	xorps  %xmm1,%xmm1
   1f562:	0f 2e d1             	ucomiss %xmm1,%xmm2
   1f565:	72 c1                	jb     1f528 <<gpui_canvas::color::Color>::fit_chroma+0x78>
   1f567:	f3 0f 10 0d b9 60 fe 	movss  -0x19f47(%rip),%xmm1        # 5628 <std::thread::current::id::ID+0x49b0>
   1f56e:	ff 
   1f56f:	0f 2e ca             	ucomiss %xmm2,%xmm1
   1f572:	72 b4                	jb     1f528 <<gpui_canvas::color::Color>::fit_chroma+0x78>
   1f574:	f3 41 0f 10 5e 04    	movss  0x4(%r14),%xmm3
   1f57a:	31 c9                	xor    %ecx,%ecx
   1f57c:	0f 57 c9             	xorps  %xmm1,%xmm1
   1f57f:	0f 2e d1             	ucomiss %xmm1,%xmm2
   1f582:	f3 0f 11 54 24 0c    	movss  %xmm2,0xc(%rsp)
   1f588:	75 02                	jne    1f58c <<gpui_canvas::color::Color>::fit_chroma+0xdc>
   1f58a:	7b 63                	jnp    1f5ef <<gpui_canvas::color::Color>::fit_chroma+0x13f>
   1f58c:	0f 2e 15 95 60 fe ff 	ucomiss -0x19f6b(%rip),%xmm2        # 5628 <std::thread::current::id::ID+0x49b0>
   1f593:	75 02                	jne    1f597 <<gpui_canvas::color::Color>::fit_chroma+0xe7>
   1f595:	7b 58                	jnp    1f5ef <<gpui_canvas::color::Color>::fit_chroma+0x13f>
   1f597:	0f 29 5c 24 20       	movaps %xmm3,0x20(%rsp)
   1f59c:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   1f5a0:	f2 0f 10 0d 20 7b fe 	movsd  -0x184e0(%rip),%xmm1        # 70c8 <std::thread::current::id::ID+0x6450>
   1f5a7:	ff 
   1f5a8:	ff 15 02 43 04 00    	call   *0x44302(%rip)        # 638b0 <_DYNAMIC+0x370>
   1f5ae:	66 0f 2e 05 92 7a fe 	ucomisd -0x1856e(%rip),%xmm0        # 7048 <std::thread::current::id::ID+0x63d0>
   1f5b5:	ff 
   1f5b6:	0f 57 c9             	xorps  %xmm1,%xmm1
   1f5b9:	73 0c                	jae    1f5c7 <<gpui_canvas::color::Color>::fit_chroma+0x117>
   1f5bb:	f2 0f 5a c0          	cvtsd2ss %xmm0,%xmm0
   1f5bf:	f3 0f c2 c8 00       	cmpeqss %xmm0,%xmm1
   1f5c4:	0f 55 c8             	andnps %xmm0,%xmm1
   1f5c7:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   1f5cd:	89 ef                	mov    %ebp,%edi
   1f5cf:	e8 ac 12 00 00       	call   20880 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>>
   1f5d4:	f3 0f 10 54 24 0c    	movss  0xc(%rsp),%xmm2
   1f5da:	48 89 c1             	mov    %rax,%rcx
   1f5dd:	48 c1 e9 20          	shr    $0x20,%rcx
   1f5e1:	83 f8 ff             	cmp    $0xffffffff,%eax
   1f5e4:	0f 28 5c 24 20       	movaps 0x20(%rsp),%xmm3
   1f5e9:	0f 85 39 ff ff ff    	jne    1f528 <<gpui_canvas::color::Color>::fit_chroma+0x78>
   1f5ef:	66 0f 6e c1          	movd   %ecx,%xmm0
   1f5f3:	0f 28 cb             	movaps %xmm3,%xmm1
   1f5f6:	f3 0f 5d c8          	minss  %xmm0,%xmm1
   1f5fa:	0f 28 e1             	movaps %xmm1,%xmm4
   1f5fd:	f3 0f c2 e1 03       	cmpunordss %xmm1,%xmm4
   1f602:	0f 28 c4             	movaps %xmm4,%xmm0
   1f605:	0f 55 c1             	andnps %xmm1,%xmm0
   1f608:	0f 54 e3             	andps  %xmm3,%xmm4
   1f60b:	0f 56 e0             	orps   %xmm0,%xmm4
   1f60e:	f3 0f 11 54 24 10    	movss  %xmm2,0x10(%rsp)
   1f614:	0f 29 64 24 20       	movaps %xmm4,0x20(%rsp)
   1f619:	f3 0f 11 64 24 14    	movss  %xmm4,0x14(%rsp)
   1f61f:	44 89 64 24 18       	mov    %r12d,0x18(%rsp)
   1f624:	44 89 7c 24 1c       	mov    %r15d,0x1c(%rsp)
   1f629:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   1f62e:	89 ee                	mov    %ebp,%esi
   1f630:	e8 5b 1e 00 00       	call   21490 <gpui_canvas::color::gamut::in_gamut>
   1f635:	84 c0                	test   %al,%al
   1f637:	74 1c                	je     1f655 <<gpui_canvas::color::Color>::fit_chroma+0x1a5>
   1f639:	0f 28 44 24 20       	movaps 0x20(%rsp),%xmm0
   1f63e:	f3 0f 11 43 08       	movss  %xmm0,0x8(%rbx)
   1f643:	44 89 63 0c          	mov    %r12d,0xc(%rbx)
   1f647:	44 89 7b 10          	mov    %r15d,0x10(%rbx)
   1f64b:	31 c0                	xor    %eax,%eax
   1f64d:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   1f653:	eb 0d                	jmp    1f662 <<gpui_canvas::color::Color>::fit_chroma+0x1b2>
   1f655:	b8 01 00 00 00       	mov    $0x1,%eax
   1f65a:	f3 0f 10 05 be 5f fe 	movss  -0x1a042(%rip),%xmm0        # 5620 <std::thread::current::id::ID+0x49a8>
   1f661:	ff 
   1f662:	f3 0f 11 43 04       	movss  %xmm0,0x4(%rbx)
   1f667:	e9 c7 fe ff ff       	jmp    1f533 <<gpui_canvas::color::Color>::fit_chroma+0x83>
   1f66c:	cc                   	int3
   1f66d:	cc                   	int3
   1f66e:	cc                   	int3
   1f66f:	cc                   	int3

gpui_canvas::color::gamut::first_exit::<fearless_simd::generated::sse2::Sse2>:
   1fb70:	55                   	push   %rbp
   1fb71:	48 89 e5             	mov    %rsp,%rbp
   1fb74:	41 57                	push   %r15
   1fb76:	41 56                	push   %r14
   1fb78:	41 55                	push   %r13
   1fb7a:	41 54                	push   %r12
   1fb7c:	53                   	push   %rbx
   1fb7d:	48 83 e4 e0          	and    $0xffffffffffffffe0,%rsp
   1fb81:	48 81 ec 40 03 00 00 	sub    $0x340,%rsp
   1fb88:	48 89 cb             	mov    %rcx,%rbx
   1fb8b:	66 44 0f 28 26       	movapd (%rsi),%xmm12
   1fb90:	66 44 0f 28 5e 10    	movapd 0x10(%rsi),%xmm11
   1fb96:	66 44 0f 28 56 20    	movapd 0x20(%rsi),%xmm10
   1fb9c:	66 44 0f 28 4e 30    	movapd 0x30(%rsi),%xmm9
   1fba2:	66 44 0f 28 46 40    	movapd 0x40(%rsi),%xmm8
   1fba8:	66 0f 28 7e 50       	movapd 0x50(%rsi),%xmm7
   1fbad:	66 0f 28 76 60       	movapd 0x60(%rsi),%xmm6
   1fbb2:	66 44 0f 28 7e 70    	movapd 0x70(%rsi),%xmm15
   1fbb8:	66 0f 28 12          	movapd (%rdx),%xmm2
   1fbbc:	66 0f 28 5a 10       	movapd 0x10(%rdx),%xmm3
   1fbc1:	66 0f 28 62 20       	movapd 0x20(%rdx),%xmm4
   1fbc6:	66 45 0f 57 f6       	xorpd  %xmm14,%xmm14
   1fbcb:	66 44 0f c2 f6 01    	cmpltpd %xmm6,%xmm14
   1fbd1:	66 45 0f 57 ed       	xorpd  %xmm13,%xmm13
   1fbd6:	66 45 0f c2 ef 01    	cmpltpd %xmm15,%xmm13
   1fbdc:	66 0f 28 2d 4c 59 fe 	movapd -0x1a6b4(%rip),%xmm5        # 5530 <std::thread::current::id::ID+0x48b8>
   1fbe3:	ff 
   1fbe4:	66 44 0f 55 f5       	andnpd %xmm5,%xmm14
   1fbe9:	66 44 0f 55 ed       	andnpd %xmm5,%xmm13
   1fbee:	66 0f 28 6a 30       	movapd 0x30(%rdx),%xmm5
   1fbf3:	66 44 0f 29 74 24 10 	movapd %xmm14,0x10(%rsp)
   1fbfa:	66 44 0f 29 37       	movapd %xmm14,(%rdi)
   1fbff:	66 44 0f 29 6c 24 20 	movapd %xmm13,0x20(%rsp)
   1fc06:	66 44 0f 29 6f 10    	movapd %xmm13,0x10(%rdi)
   1fc0c:	66 0f 5d d0          	minpd  %xmm0,%xmm2
   1fc10:	4c 8d ac 24 c0 02 00 	lea    0x2c0(%rsp),%r13
   1fc17:	00 
   1fc18:	66 0f 29 94 24 c0 02 	movapd %xmm2,0x2c0(%rsp)
   1fc1f:	00 00 
   1fc21:	66 0f 5d d9          	minpd  %xmm1,%xmm3
   1fc25:	66 0f 5d e0          	minpd  %xmm0,%xmm4
   1fc29:	66 0f 5d e9          	minpd  %xmm1,%xmm5
   1fc2d:	66 0f 29 9c 24 d0 02 	movapd %xmm3,0x2d0(%rsp)
   1fc34:	00 00 
   1fc36:	66 0f 29 a4 24 e0 02 	movapd %xmm4,0x2e0(%rsp)
   1fc3d:	00 00 
   1fc3f:	66 0f 29 ac 24 f0 02 	movapd %xmm5,0x2f0(%rsp)
   1fc46:	00 00 
   1fc48:	66 0f 29 84 24 00 03 	movapd %xmm0,0x300(%rsp)
   1fc4f:	00 00 
   1fc51:	66 0f 29 8c 24 10 03 	movapd %xmm1,0x310(%rsp)
   1fc58:	00 00 
   1fc5a:	66 0f 28 05 be 54 fe 	movapd -0x1ab42(%rip),%xmm0        # 5120 <std::thread::current::id::ID+0x44a8>
   1fc61:	ff 
   1fc62:	66 44 0f 29 64 24 40 	movapd %xmm12,0x40(%rsp)
   1fc69:	66 44 0f 54 e0       	andpd  %xmm0,%xmm12
   1fc6e:	66 44 0f 29 a4 24 80 	movapd %xmm12,0x180(%rsp)
   1fc75:	01 00 00 
   1fc78:	66 44 0f 29 5c 24 30 	movapd %xmm11,0x30(%rsp)
   1fc7f:	66 44 0f 54 d8       	andpd  %xmm0,%xmm11
   1fc84:	66 44 0f 29 9c 24 70 	movapd %xmm11,0x170(%rsp)
   1fc8b:	01 00 00 
   1fc8e:	66 44 0f 29 94 24 e0 	movapd %xmm10,0xe0(%rsp)
   1fc95:	00 00 00 
   1fc98:	66 44 0f 54 d0       	andpd  %xmm0,%xmm10
   1fc9d:	66 44 0f 29 94 24 60 	movapd %xmm10,0x160(%rsp)
   1fca4:	01 00 00 
   1fca7:	66 44 0f 29 8c 24 d0 	movapd %xmm9,0xd0(%rsp)
   1fcae:	00 00 00 
   1fcb1:	66 41 0f 28 c9       	movapd %xmm9,%xmm1
   1fcb6:	66 45 0f 28 ef       	movapd %xmm15,%xmm13
   1fcbb:	66 0f 54 c8          	andpd  %xmm0,%xmm1
   1fcbf:	66 0f 29 8c 24 50 01 	movapd %xmm1,0x150(%rsp)
   1fcc6:	00 00 
   1fcc8:	66 45 0f 28 f8       	movapd %xmm8,%xmm15
   1fccd:	66 44 0f 54 c0       	andpd  %xmm0,%xmm8
   1fcd2:	66 44 0f 29 84 24 40 	movapd %xmm8,0x140(%rsp)
   1fcd9:	01 00 00 
   1fcdc:	66 44 0f 28 df       	movapd %xmm7,%xmm11
   1fce1:	66 0f 54 f8          	andpd  %xmm0,%xmm7
   1fce5:	66 0f 29 bc 24 30 01 	movapd %xmm7,0x130(%rsp)
   1fcec:	00 00 
   1fcee:	66 0f 28 e6          	movapd %xmm6,%xmm4
   1fcf2:	66 0f 28 ce          	movapd %xmm6,%xmm1
   1fcf6:	66 0f 54 c8          	andpd  %xmm0,%xmm1
   1fcfa:	66 0f 29 8c 24 20 01 	movapd %xmm1,0x120(%rsp)
   1fd01:	00 00 
   1fd03:	66 41 0f 28 cd       	movapd %xmm13,%xmm1
   1fd08:	66 0f 54 c8          	andpd  %xmm0,%xmm1
   1fd0c:	66 0f 29 8c 24 10 01 	movapd %xmm1,0x110(%rsp)
   1fd13:	00 00 
   1fd15:	45 31 f6             	xor    %r14d,%r14d
   1fd18:	4c 8d bc 24 e0 01 00 	lea    0x1e0(%rsp),%r15
   1fd1f:	00 
   1fd20:	4c 8d a4 24 00 02 00 	lea    0x200(%rsp),%r12
   1fd27:	00 
   1fd28:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
   1fd2c:	0f 28 0f             	movaps (%rdi),%xmm1
   1fd2f:	0f 29 4c 24 60       	movaps %xmm1,0x60(%rsp)
   1fd34:	48 89 7c 24 58       	mov    %rdi,0x58(%rsp)
   1fd39:	66 0f 28 4f 10       	movapd 0x10(%rdi),%xmm1
   1fd3e:	66 0f 29 4c 24 70    	movapd %xmm1,0x70(%rsp)
   1fd44:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   1fd48:	66 44 0f 29 bc 24 00 	movapd %xmm15,0x100(%rsp)
   1fd4f:	01 00 00 
   1fd52:	66 44 0f 29 9c 24 f0 	movapd %xmm11,0xf0(%rsp)
   1fd59:	00 00 00 
   1fd5c:	66 0f 29 b4 24 a0 00 	movapd %xmm6,0xa0(%rsp)
   1fd63:	00 00 
   1fd65:	66 44 0f 29 ac 24 90 	movapd %xmm13,0x190(%rsp)
   1fd6c:	01 00 00 
   1fd6f:	eb 3c                	jmp    1fdad <gpui_canvas::color::gamut::first_exit::<fearless_simd::generated::sse2::Sse2>+0x23d>
   1fd71:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   1fd78:	0f 1f 84 00 00 00 00 
   1fd7f:	00 
   1fd80:	66 45 0f 28 ec       	movapd %xmm12,%xmm13
   1fd85:	49 ff c6             	inc    %r14
   1fd88:	66 0f 28 84 24 b0 00 	movapd 0xb0(%rsp),%xmm0
   1fd8f:	00 00 
   1fd91:	66 0f 28 8c 24 c0 00 	movapd 0xc0(%rsp),%xmm1
   1fd98:	00 00 
   1fd9a:	49 83 fe 03          	cmp    $0x3,%r14
   1fd9e:	66 0f 28 a4 24 a0 00 	movapd 0xa0(%rsp),%xmm4
   1fda5:	00 00 
   1fda7:	0f 84 38 04 00 00    	je     201e5 <gpui_canvas::color::gamut::first_exit::<fearless_simd::generated::sse2::Sse2>+0x675>
   1fdad:	66 0f 29 8c 24 c0 01 	movapd %xmm1,0x1c0(%rsp)
   1fdb4:	00 00 
   1fdb6:	66 0f 29 84 24 d0 01 	movapd %xmm0,0x1d0(%rsp)
   1fdbd:	00 00 
   1fdbf:	4c 89 f0             	mov    %r14,%rax
   1fdc2:	48 c1 e0 05          	shl    $0x5,%rax
   1fdc6:	66 45 0f 28 4c 05 00 	movapd 0x0(%r13,%rax,1),%xmm9
   1fdcd:	66 41 0f 28 74 05 10 	movapd 0x10(%r13,%rax,1),%xmm6
   1fdd4:	66 0f 28 54 24 40    	movapd 0x40(%rsp),%xmm2
   1fdda:	66 41 0f 59 d1       	mulpd  %xmm9,%xmm2
   1fddf:	66 0f 28 5c 24 30    	movapd 0x30(%rsp),%xmm3
   1fde5:	66 0f 59 de          	mulpd  %xmm6,%xmm3
   1fde9:	66 44 0f 28 b4 24 e0 	movapd 0xe0(%rsp),%xmm14
   1fdf0:	00 00 00 
   1fdf3:	66 41 0f 58 d6       	addpd  %xmm14,%xmm2
   1fdf8:	66 0f 28 ac 24 d0 00 	movapd 0xd0(%rsp),%xmm5
   1fdff:	00 00 
   1fe01:	66 0f 58 dd          	addpd  %xmm5,%xmm3
   1fe05:	66 41 0f 59 d1       	mulpd  %xmm9,%xmm2
   1fe0a:	66 0f 59 de          	mulpd  %xmm6,%xmm3
   1fe0e:	66 41 0f 58 d7       	addpd  %xmm15,%xmm2
   1fe13:	66 41 0f 58 db       	addpd  %xmm11,%xmm3
   1fe18:	66 41 0f 59 d1       	mulpd  %xmm9,%xmm2
   1fe1d:	66 0f 59 de          	mulpd  %xmm6,%xmm3
   1fe21:	66 0f 58 d4          	addpd  %xmm4,%xmm2
   1fe25:	66 41 0f 58 dd       	addpd  %xmm13,%xmm3
   1fe2a:	66 0f 28 8c 24 80 01 	movapd 0x180(%rsp),%xmm1
   1fe31:	00 00 
   1fe33:	66 41 0f 59 c9       	mulpd  %xmm9,%xmm1
   1fe38:	66 0f 58 8c 24 60 01 	addpd  0x160(%rsp),%xmm1
   1fe3f:	00 00 
   1fe41:	66 0f 28 84 24 70 01 	movapd 0x170(%rsp),%xmm0
   1fe48:	00 00 
   1fe4a:	66 0f 59 c6          	mulpd  %xmm6,%xmm0
   1fe4e:	66 0f 58 84 24 50 01 	addpd  0x150(%rsp),%xmm0
   1fe55:	00 00 
   1fe57:	66 41 0f 59 c9       	mulpd  %xmm9,%xmm1
   1fe5c:	66 0f 58 8c 24 40 01 	addpd  0x140(%rsp),%xmm1
   1fe63:	00 00 
   1fe65:	66 0f 59 c6          	mulpd  %xmm6,%xmm0
   1fe69:	66 0f 58 84 24 30 01 	addpd  0x130(%rsp),%xmm0
   1fe70:	00 00 
   1fe72:	66 41 0f 59 c9       	mulpd  %xmm9,%xmm1
   1fe77:	66 0f 58 8c 24 20 01 	addpd  0x120(%rsp),%xmm1
   1fe7e:	00 00 
   1fe80:	66 0f 59 c6          	mulpd  %xmm6,%xmm0
   1fe84:	66 0f 58 84 24 10 01 	addpd  0x110(%rsp),%xmm0
   1fe8b:	00 00 
   1fe8d:	66 0f 29 94 24 80 00 	movapd %xmm2,0x80(%rsp)
   1fe94:	00 00 
   1fe96:	66 44 0f 28 15 81 52 	movapd -0x1ad7f(%rip),%xmm10        # 5120 <std::thread::current::id::ID+0x44a8>
   1fe9d:	fe ff 
   1fe9f:	66 41 0f 54 d2       	andpd  %xmm10,%xmm2
   1fea4:	66 44 0f 28 25 93 52 	movapd -0x1ad6d(%rip),%xmm12        # 5140 <std::thread::current::id::ID+0x44c8>
   1feab:	fe ff 
   1fead:	66 41 0f 59 cc       	mulpd  %xmm12,%xmm1
   1feb2:	66 0f c2 d1 02       	cmplepd %xmm1,%xmm2
   1feb7:	66 0f 29 9c 24 90 00 	movapd %xmm3,0x90(%rsp)
   1febe:	00 00 
   1fec0:	66 41 0f 54 da       	andpd  %xmm10,%xmm3
   1fec5:	66 41 0f 59 c4       	mulpd  %xmm12,%xmm0
   1feca:	66 0f c2 d8 02       	cmplepd %xmm0,%xmm3
   1fecf:	0f 28 44 24 40       	movaps 0x40(%rsp),%xmm0
   1fed4:	0f 29 84 24 00 02 00 	movaps %xmm0,0x200(%rsp)
   1fedb:	00 
   1fedc:	66 0f 28 44 24 30    	movapd 0x30(%rsp),%xmm0
   1fee2:	66 0f 29 84 24 10 02 	movapd %xmm0,0x210(%rsp)
   1fee9:	00 00 
   1feeb:	66 44 0f 29 b4 24 20 	movapd %xmm14,0x220(%rsp)
   1fef2:	02 00 00 
   1fef5:	66 0f 29 ac 24 30 02 	movapd %xmm5,0x230(%rsp)
   1fefc:	00 00 
   1fefe:	66 44 0f 29 bc 24 40 	movapd %xmm15,0x240(%rsp)
   1ff05:	02 00 00 
   1ff08:	66 44 0f 29 9c 24 50 	movapd %xmm11,0x250(%rsp)
   1ff0f:	02 00 00 
   1ff12:	66 0f 29 a4 24 60 02 	movapd %xmm4,0x260(%rsp)
   1ff19:	00 00 
   1ff1b:	66 44 0f 29 ac 24 70 	movapd %xmm13,0x270(%rsp)
   1ff22:	02 00 00 
   1ff25:	66 44 0f 29 8c 24 80 	movapd %xmm9,0x280(%rsp)
   1ff2c:	02 00 00 
   1ff2f:	66 0f 29 b4 24 90 02 	movapd %xmm6,0x290(%rsp)
   1ff36:	00 00 
   1ff38:	66 0f 50 c2          	movmskpd %xmm2,%eax
   1ff3c:	66 0f 50 cb          	movmskpd %xmm3,%ecx
   1ff40:	c1 e1 02             	shl    $0x2,%ecx
   1ff43:	83 e1 04             	and    $0x4,%ecx
   1ff46:	09 c1                	or     %eax,%ecx
   1ff48:	66 44 0f 29 8c 24 c0 	movapd %xmm9,0xc0(%rsp)
   1ff4f:	00 00 00 
   1ff52:	66 0f 29 b4 24 b0 00 	movapd %xmm6,0xb0(%rsp)
   1ff59:	00 00 
   1ff5b:	0f 84 9f 00 00 00    	je     20000 <gpui_canvas::color::gamut::first_exit::<fearless_simd::generated::sse2::Sse2>+0x490>
   1ff61:	66 0f 29 94 24 b0 01 	movapd %xmm2,0x1b0(%rsp)
   1ff68:	00 00 
   1ff6a:	66 44 0f 54 ca       	andpd  %xmm2,%xmm9
   1ff6f:	66 0f 54 f3          	andpd  %xmm3,%xmm6
   1ff73:	4c 89 ff             	mov    %r15,%rdi
   1ff76:	4c 89 e6             	mov    %r12,%rsi
   1ff79:	66 41 0f 28 c1       	movapd %xmm9,%xmm0
   1ff7e:	66 0f 28 ce          	movapd %xmm6,%xmm1
   1ff82:	66 0f 29 9c 24 a0 01 	movapd %xmm3,0x1a0(%rsp)
   1ff89:	00 00 
   1ff8b:	e8 80 02 00 00       	call   20210 <gpui_canvas::color::gamut::exact_endpoint_sign::<fearless_simd::generated::sse2::Sse2>>
   1ff90:	66 0f 28 b4 24 b0 00 	movapd 0xb0(%rsp),%xmm6
   1ff97:	00 00 
   1ff99:	66 44 0f 28 8c 24 c0 	movapd 0xc0(%rsp),%xmm9
   1ffa0:	00 00 00 
   1ffa3:	66 44 0f 28 9c 24 f0 	movapd 0xf0(%rsp),%xmm11
   1ffaa:	00 00 00 
   1ffad:	66 44 0f 28 bc 24 00 	movapd 0x100(%rsp),%xmm15
   1ffb4:	01 00 00 
   1ffb7:	66 0f 28 84 24 e0 01 	movapd 0x1e0(%rsp),%xmm0
   1ffbe:	00 00 
   1ffc0:	66 0f 28 a4 24 b0 01 	movapd 0x1b0(%rsp),%xmm4
   1ffc7:	00 00 
   1ffc9:	66 0f 54 c4          	andpd  %xmm4,%xmm0
   1ffcd:	66 0f 55 a4 24 80 00 	andnpd 0x80(%rsp),%xmm4
   1ffd4:	00 00 
   1ffd6:	66 0f 56 e0          	orpd   %xmm0,%xmm4
   1ffda:	66 0f 28 84 24 f0 01 	movapd 0x1f0(%rsp),%xmm0
   1ffe1:	00 00 
   1ffe3:	66 0f 28 9c 24 a0 01 	movapd 0x1a0(%rsp),%xmm3
   1ffea:	00 00 
   1ffec:	66 0f 54 c3          	andpd  %xmm3,%xmm0
   1fff0:	66 0f 55 9c 24 90 00 	andnpd 0x90(%rsp),%xmm3
   1fff7:	00 00 
   1fff9:	66 0f 56 d8          	orpd   %xmm0,%xmm3
   1fffd:	eb 13                	jmp    20012 <gpui_canvas::color::gamut::first_exit::<fearless_simd::generated::sse2::Sse2>+0x4a2>
   1ffff:	90                   	nop
   20000:	66 0f 28 9c 24 90 00 	movapd 0x90(%rsp),%xmm3
   20007:	00 00 
   20009:	66 0f 28 a4 24 80 00 	movapd 0x80(%rsp),%xmm4
   20010:	00 00 
   20012:	66 0f 28 4c 24 10    	movapd 0x10(%rsp),%xmm1
   20018:	66 0f 28 05 10 55 fe 	movapd -0x1aaf0(%rip),%xmm0        # 5530 <std::thread::current::id::ID+0x48b8>
   2001f:	ff 
   20020:	66 0f c2 c8 00       	cmpeqpd %xmm0,%xmm1
   20025:	66 0f 28 54 24 20    	movapd 0x20(%rsp),%xmm2
   2002b:	66 0f c2 d0 00       	cmpeqpd %xmm0,%xmm2
   20030:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
   20034:	66 0f c2 c4 01       	cmpltpd %xmm4,%xmm0
   20039:	66 0f 54 c1          	andpd  %xmm1,%xmm0
   2003d:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   20041:	66 0f c2 cb 01       	cmpltpd %xmm3,%xmm1
   20046:	66 0f 54 ca          	andpd  %xmm2,%xmm1
   2004a:	66 0f 50 c0          	movmskpd %xmm0,%eax
   2004e:	66 0f 50 c9          	movmskpd %xmm1,%ecx
   20052:	c1 e1 02             	shl    $0x2,%ecx
   20055:	83 e1 04             	and    $0x4,%ecx
   20058:	09 c1                	or     %eax,%ecx
   2005a:	48 89 d8             	mov    %rbx,%rax
   2005d:	66 0f 28 de          	movapd %xmm6,%xmm3
   20061:	66 41 0f 28 e9       	movapd %xmm9,%xmm5
   20066:	66 44 0f 28 94 24 a0 	movapd 0xa0(%rsp),%xmm10
   2006d:	00 00 00 
   20070:	66 44 0f 28 a4 24 90 	movapd 0x190(%rsp),%xmm12
   20077:	01 00 00 
   2007a:	66 0f 28 3d 9e 51 fe 	movapd -0x1ae62(%rip),%xmm7        # 5220 <std::thread::current::id::ID+0x45a8>
   20081:	ff 
   20082:	66 44 0f 28 ac 24 d0 	movapd 0x1d0(%rsp),%xmm13
   20089:	01 00 00 
   2008c:	66 44 0f 28 b4 24 c0 	movapd 0x1c0(%rsp),%xmm14
   20093:	01 00 00 
   20096:	0f 84 e4 fc ff ff    	je     1fd80 <gpui_canvas::color::gamut::first_exit::<fearless_simd::generated::sse2::Sse2>+0x210>
   2009c:	0f 1f 40 00          	nopl   0x0(%rax)
   200a0:	66 0f 28 e5          	movapd %xmm5,%xmm4
   200a4:	66 41 0f 5c e6       	subpd  %xmm14,%xmm4
   200a9:	66 0f 28 d3          	movapd %xmm3,%xmm2
   200ad:	66 41 0f 5c d5       	subpd  %xmm13,%xmm2
   200b2:	66 0f 59 e7          	mulpd  %xmm7,%xmm4
   200b6:	66 0f 59 d7          	mulpd  %xmm7,%xmm2
   200ba:	66 41 0f 58 e6       	addpd  %xmm14,%xmm4
   200bf:	66 41 0f 58 d5       	addpd  %xmm13,%xmm2
   200c4:	66 0f 28 74 24 40    	movapd 0x40(%rsp),%xmm6
   200ca:	66 0f 59 f4          	mulpd  %xmm4,%xmm6
   200ce:	66 44 0f 28 44 24 30 	movapd 0x30(%rsp),%xmm8
   200d5:	66 44 0f 59 c2       	mulpd  %xmm2,%xmm8
   200da:	66 0f 58 b4 24 e0 00 	addpd  0xe0(%rsp),%xmm6
   200e1:	00 00 
   200e3:	66 44 0f 58 84 24 d0 	addpd  0xd0(%rsp),%xmm8
   200ea:	00 00 00 
   200ed:	66 0f 59 f4          	mulpd  %xmm4,%xmm6
   200f1:	66 44 0f 59 c2       	mulpd  %xmm2,%xmm8
   200f6:	66 41 0f 58 f7       	addpd  %xmm15,%xmm6
   200fb:	66 45 0f 58 c3       	addpd  %xmm11,%xmm8
   20100:	66 0f 59 f4          	mulpd  %xmm4,%xmm6
   20104:	66 44 0f 59 c2       	mulpd  %xmm2,%xmm8
   20109:	66 41 0f 58 f2       	addpd  %xmm10,%xmm6
   2010e:	66 45 0f 58 c4       	addpd  %xmm12,%xmm8
   20113:	66 45 0f 57 c9       	xorpd  %xmm9,%xmm9
   20118:	66 44 0f c2 ce 01    	cmpltpd %xmm6,%xmm9
   2011e:	66 0f 57 ff          	xorpd  %xmm7,%xmm7
   20122:	66 41 0f c2 f8 01    	cmpltpd %xmm8,%xmm7
   20128:	66 0f 28 f0          	movapd %xmm0,%xmm6
   2012c:	66 41 0f 54 f1       	andpd  %xmm9,%xmm6
   20131:	66 44 0f 28 c6       	movapd %xmm6,%xmm8
   20136:	66 0f 55 f5          	andnpd %xmm5,%xmm6
   2013a:	66 0f 28 e9          	movapd %xmm1,%xmm5
   2013e:	66 0f 54 ef          	andpd  %xmm7,%xmm5
   20142:	66 44 0f 54 c4       	andpd  %xmm4,%xmm8
   20147:	66 41 0f 56 f0       	orpd   %xmm8,%xmm6
   2014c:	66 44 0f 28 c5       	movapd %xmm5,%xmm8
   20151:	66 0f 55 eb          	andnpd %xmm3,%xmm5
   20155:	66 44 0f 54 c2       	andpd  %xmm2,%xmm8
   2015a:	66 41 0f 56 e8       	orpd   %xmm8,%xmm5
   2015f:	66 44 0f 55 c8       	andnpd %xmm0,%xmm9
   20164:	66 41 0f 54 e1       	andpd  %xmm9,%xmm4
   20169:	66 45 0f 55 ce       	andnpd %xmm14,%xmm9
   2016e:	66 45 0f 28 f1       	movapd %xmm9,%xmm14
   20173:	66 44 0f 56 f4       	orpd   %xmm4,%xmm14
   20178:	66 0f 55 f9          	andnpd %xmm1,%xmm7
   2017c:	66 0f 54 d7          	andpd  %xmm7,%xmm2
   20180:	66 41 0f 55 fd       	andnpd %xmm13,%xmm7
   20185:	66 44 0f 28 ef       	movapd %xmm7,%xmm13
   2018a:	66 0f 28 3d 8e 50 fe 	movapd -0x1af72(%rip),%xmm7        # 5220 <std::thread::current::id::ID+0x45a8>
   20191:	ff 
   20192:	66 44 0f 56 ea       	orpd   %xmm2,%xmm13
   20197:	66 0f 28 dd          	movapd %xmm5,%xmm3
   2019b:	66 0f 28 ee          	movapd %xmm6,%xmm5
   2019f:	48 ff c8             	dec    %rax
   201a2:	0f 85 f8 fe ff ff    	jne    200a0 <gpui_canvas::color::gamut::first_exit::<fearless_simd::generated::sse2::Sse2>+0x530>
   201a8:	66 44 0f 54 f0       	andpd  %xmm0,%xmm14
   201ad:	66 0f 55 44 24 10    	andnpd 0x10(%rsp),%xmm0
   201b3:	66 41 0f 56 c6       	orpd   %xmm14,%xmm0
   201b8:	66 44 0f 54 e9       	andpd  %xmm1,%xmm13
   201bd:	66 0f 55 4c 24 20    	andnpd 0x20(%rsp),%xmm1
   201c3:	66 41 0f 56 cd       	orpd   %xmm13,%xmm1
   201c8:	66 0f 29 4c 24 70    	movapd %xmm1,0x70(%rsp)
   201ce:	66 0f 29 44 24 60    	movapd %xmm0,0x60(%rsp)
   201d4:	66 0f 29 4c 24 20    	movapd %xmm1,0x20(%rsp)
   201da:	66 0f 29 44 24 10    	movapd %xmm0,0x10(%rsp)
   201e0:	e9 9b fb ff ff       	jmp    1fd80 <gpui_canvas::color::gamut::first_exit::<fearless_simd::generated::sse2::Sse2>+0x210>
   201e5:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
   201ea:	0f 28 44 24 60       	movaps 0x60(%rsp),%xmm0
   201ef:	0f 29 00             	movaps %xmm0,(%rax)
   201f2:	0f 28 44 24 70       	movaps 0x70(%rsp),%xmm0
   201f7:	0f 29 40 10          	movaps %xmm0,0x10(%rax)
   201fb:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
   201ff:	5b                   	pop    %rbx
   20200:	41 5c                	pop    %r12
   20202:	41 5d                	pop    %r13
   20204:	41 5e                	pop    %r14
   20206:	41 5f                	pop    %r15
   20208:	5d                   	pop    %rbp
   20209:	c3                   	ret
   2020a:	cc                   	int3
   2020b:	cc                   	int3
   2020c:	cc                   	int3
   2020d:	cc                   	int3
   2020e:	cc                   	int3
   2020f:	cc                   	int3

gpui_canvas::color::gamut::exact_endpoint_sign::<fearless_simd::generated::sse2::Sse2>:
   20210:	55                   	push   %rbp
   20211:	48 89 e5             	mov    %rsp,%rbp
   20214:	41 57                	push   %r15
   20216:	41 56                	push   %r14
   20218:	41 55                	push   %r13
   2021a:	41 54                	push   %r12
   2021c:	53                   	push   %rbx
   2021d:	48 83 e4 e0          	and    $0xffffffffffffffe0,%rsp
   20221:	48 81 ec 20 06 00 00 	sub    $0x620,%rsp
   20228:	0f 29 4c 24 30       	movaps %xmm1,0x30(%rsp)
   2022d:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
   20232:	49 89 f7             	mov    %rsi,%r15
   20235:	0f 57 c0             	xorps  %xmm0,%xmm0
   20238:	0f 29 47 10          	movaps %xmm0,0x10(%rdi)
   2023c:	48 89 7c 24 18       	mov    %rdi,0x18(%rsp)
   20241:	0f 29 07             	movaps %xmm0,(%rdi)
   20244:	4c 8d b4 24 20 02 00 	lea    0x220(%rsp),%r14
   2024b:	00 
   2024c:	31 db                	xor    %ebx,%ebx
   2024e:	ba e0 01 00 00       	mov    $0x1e0,%edx
   20253:	4c 89 f7             	mov    %r14,%rdi
   20256:	31 f6                	xor    %esi,%esi
   20258:	ff 15 ba 35 04 00    	call   *0x435ba(%rip)        # 63818 <memset@GLIBC_2.2.5>
   2025e:	66 44 0f 28 6c 24 20 	movapd 0x20(%rsp),%xmm13
   20265:	66 44 0f 28 64 24 30 	movapd 0x30(%rsp),%xmm12
   2026c:	41 0f 28 07          	movaps (%r15),%xmm0
   20270:	41 0f 28 4f 10       	movaps 0x10(%r15),%xmm1
   20275:	0f 29 84 24 00 02 00 	movaps %xmm0,0x200(%rsp)
   2027c:	00 
   2027d:	0f 29 8c 24 10 02 00 	movaps %xmm1,0x210(%rsp)
   20284:	00 
   20285:	41 0f 28 47 20       	movaps 0x20(%r15),%xmm0
   2028a:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
   2028f:	41 0f 28 47 30       	movaps 0x30(%r15),%xmm0
   20294:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
   20299:	41 0f 28 47 40       	movaps 0x40(%r15),%xmm0
   2029e:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
   202a3:	41 0f 28 47 50       	movaps 0x50(%r15),%xmm0
   202a8:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
   202ad:	41 0f 28 47 60       	movaps 0x60(%r15),%xmm0
   202b2:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
   202b9:	00 
   202ba:	41 0f 28 47 70       	movaps 0x70(%r15),%xmm0
   202bf:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
   202c6:	00 
   202c7:	0f 28 44 24 40       	movaps 0x40(%rsp),%xmm0
   202cc:	0f 28 4c 24 50       	movaps 0x50(%rsp),%xmm1
   202d1:	0f 28 54 24 60       	movaps 0x60(%rsp),%xmm2
   202d6:	0f 28 5c 24 70       	movaps 0x70(%rsp),%xmm3
   202db:	0f 29 84 24 20 01 00 	movaps %xmm0,0x120(%rsp)
   202e2:	00 
   202e3:	0f 29 8c 24 30 01 00 	movaps %xmm1,0x130(%rsp)
   202ea:	00 
   202eb:	0f 29 94 24 40 01 00 	movaps %xmm2,0x140(%rsp)
   202f2:	00 
   202f3:	0f 29 9c 24 50 01 00 	movaps %xmm3,0x150(%rsp)
   202fa:	00 
   202fb:	0f 28 84 24 80 00 00 	movaps 0x80(%rsp),%xmm0
   20302:	00 
   20303:	0f 29 84 24 60 01 00 	movaps %xmm0,0x160(%rsp)
   2030a:	00 
   2030b:	0f 28 84 24 90 00 00 	movaps 0x90(%rsp),%xmm0
   20312:	00 
   20313:	0f 29 84 24 70 01 00 	movaps %xmm0,0x170(%rsp)
   2031a:	00 
   2031b:	0f 28 84 24 70 01 00 	movaps 0x170(%rsp),%xmm0
   20322:	00 
   20323:	0f 29 84 24 f0 01 00 	movaps %xmm0,0x1f0(%rsp)
   2032a:	00 
   2032b:	0f 28 84 24 60 01 00 	movaps 0x160(%rsp),%xmm0
   20332:	00 
   20333:	0f 29 84 24 e0 01 00 	movaps %xmm0,0x1e0(%rsp)
   2033a:	00 
   2033b:	0f 28 84 24 50 01 00 	movaps 0x150(%rsp),%xmm0
   20342:	00 
   20343:	0f 29 84 24 d0 01 00 	movaps %xmm0,0x1d0(%rsp)
   2034a:	00 
   2034b:	0f 28 84 24 10 01 00 	movaps 0x110(%rsp),%xmm0
   20352:	00 
   20353:	0f 28 8c 24 20 01 00 	movaps 0x120(%rsp),%xmm1
   2035a:	00 
   2035b:	0f 28 94 24 30 01 00 	movaps 0x130(%rsp),%xmm2
   20362:	00 
   20363:	66 0f 28 9c 24 40 01 	movapd 0x140(%rsp),%xmm3
   2036a:	00 00 
   2036c:	66 0f 29 9c 24 c0 01 	movapd %xmm3,0x1c0(%rsp)
   20373:	00 00 
   20375:	0f 29 94 24 b0 01 00 	movaps %xmm2,0x1b0(%rsp)
   2037c:	00 
   2037d:	0f 29 8c 24 a0 01 00 	movaps %xmm1,0x1a0(%rsp)
   20384:	00 
   20385:	0f 29 84 24 90 01 00 	movaps %xmm0,0x190(%rsp)
   2038c:	00 
   2038d:	66 0f 28 05 8b 50 fe 	movapd -0x1af75(%rip),%xmm0        # 5420 <std::thread::current::id::ID+0x47a8>
   20394:	ff 
   20395:	66 45 0f 28 fd       	movapd %xmm13,%xmm15
   2039a:	66 44 0f 59 f8       	mulpd  %xmm0,%xmm15
   2039f:	66 41 0f 28 d4       	movapd %xmm12,%xmm2
   203a4:	66 0f 59 d0          	mulpd  %xmm0,%xmm2
   203a8:	66 41 0f 28 c7       	movapd %xmm15,%xmm0
   203ad:	66 41 0f 5c c5       	subpd  %xmm13,%xmm0
   203b2:	66 0f 28 ca          	movapd %xmm2,%xmm1
   203b6:	66 41 0f 5c cc       	subpd  %xmm12,%xmm1
   203bb:	66 44 0f 5c f8       	subpd  %xmm0,%xmm15
   203c0:	66 0f 5c d1          	subpd  %xmm1,%xmm2
   203c4:	66 41 0f 28 c5       	movapd %xmm13,%xmm0
   203c9:	66 41 0f 5c c7       	subpd  %xmm15,%xmm0
   203ce:	66 0f 29 84 24 f0 00 	movapd %xmm0,0xf0(%rsp)
   203d5:	00 00 
   203d7:	66 41 0f 28 c4       	movapd %xmm12,%xmm0
   203dc:	66 0f 29 94 24 00 01 	movapd %xmm2,0x100(%rsp)
   203e3:	00 00 
   203e5:	66 0f 5c c2          	subpd  %xmm2,%xmm0
   203e9:	66 0f 29 84 24 e0 00 	movapd %xmm0,0xe0(%rsp)
   203f0:	00 00 
   203f2:	41 bd 01 00 00 00    	mov    $0x1,%r13d
   203f8:	4c 8d bc 24 00 04 00 	lea    0x400(%rsp),%r15
   203ff:	00 
   20400:	4c 8d a4 24 00 02 00 	lea    0x200(%rsp),%r12
   20407:	00 
   20408:	66 44 0f 29 bc 24 b0 	movapd %xmm15,0xb0(%rsp)
   2040f:	00 00 00 
   20412:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   20419:	1f 84 00 00 00 00 00 
   20420:	48 89 d8             	mov    %rbx,%rax
   20423:	48 ff c3             	inc    %rbx
   20426:	48 c1 e0 05          	shl    $0x5,%rax
   2042a:	48 8d 8c 24 a0 01 00 	lea    0x1a0(%rsp),%rcx
   20431:	00 
   20432:	0f 28 04 01          	movaps (%rcx,%rax,1),%xmm0
   20436:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
   2043d:	00 
   2043e:	0f 28 44 01 10       	movaps 0x10(%rcx,%rax,1),%xmm0
   20443:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
   2044a:	00 
   2044b:	ba 00 02 00 00       	mov    $0x200,%edx
   20450:	4c 89 ff             	mov    %r15,%rdi
   20453:	4c 89 e6             	mov    %r12,%rsi
   20456:	ff 15 14 34 04 00    	call   *0x43414(%rip)        # 63870 <memcpy@GLIBC_2.14>
   2045c:	66 44 0f 28 bc 24 b0 	movapd 0xb0(%rsp),%xmm15
   20463:	00 00 00 
   20466:	66 44 0f 28 35 b1 4f 	movapd -0x1b04f(%rip),%xmm14        # 5420 <std::thread::current::id::ID+0x47a8>
   2046d:	fe ff 
   2046f:	66 44 0f 28 6c 24 20 	movapd 0x20(%rsp),%xmm13
   20476:	66 44 0f 28 64 24 30 	movapd 0x30(%rsp),%xmm12
   2047d:	49 c1 e5 05          	shl    $0x5,%r13
   20481:	4a 8d 0c 2c          	lea    (%rsp,%r13,1),%rcx
   20485:	48 81 c1 00 04 00 00 	add    $0x400,%rcx
   2048c:	31 f6                	xor    %esi,%esi
   2048e:	4c 89 fa             	mov    %r15,%rdx
   20491:	45 31 ed             	xor    %r13d,%r13d
   20494:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   2049b:	00 00 00 00 00 
   204a0:	4c 89 ef             	mov    %r13,%rdi
   204a3:	48 89 f0             	mov    %rsi,%rax
   204a6:	66 0f 28 1a          	movapd (%rdx),%xmm3
   204aa:	66 0f 28 52 10       	movapd 0x10(%rdx),%xmm2
   204af:	66 41 0f 28 c5       	movapd %xmm13,%xmm0
   204b4:	66 0f 59 c3          	mulpd  %xmm3,%xmm0
   204b8:	66 41 0f 28 cc       	movapd %xmm12,%xmm1
   204bd:	66 0f 59 ca          	mulpd  %xmm2,%xmm1
   204c1:	66 0f 28 eb          	movapd %xmm3,%xmm5
   204c5:	66 41 0f 59 ee       	mulpd  %xmm14,%xmm5
   204ca:	66 0f 28 e2          	movapd %xmm2,%xmm4
   204ce:	66 41 0f 59 e6       	mulpd  %xmm14,%xmm4
   204d3:	66 0f 28 f5          	movapd %xmm5,%xmm6
   204d7:	66 0f 5c f3          	subpd  %xmm3,%xmm6
   204db:	66 0f 28 fc          	movapd %xmm4,%xmm7
   204df:	66 0f 5c fa          	subpd  %xmm2,%xmm7
   204e3:	66 0f 5c ee          	subpd  %xmm6,%xmm5
   204e7:	66 0f 5c e7          	subpd  %xmm7,%xmm4
   204eb:	66 0f 5c dd          	subpd  %xmm5,%xmm3
   204ef:	66 0f 5c d4          	subpd  %xmm4,%xmm2
   204f3:	66 41 0f 28 f7       	movapd %xmm15,%xmm6
   204f8:	66 0f 59 f5          	mulpd  %xmm5,%xmm6
   204fc:	66 44 0f 28 84 24 00 	movapd 0x100(%rsp),%xmm8
   20503:	01 00 00 
   20506:	66 41 0f 28 f8       	movapd %xmm8,%xmm7
   2050b:	66 0f 59 fc          	mulpd  %xmm4,%xmm7
   2050f:	66 0f 5c f0          	subpd  %xmm0,%xmm6
   20513:	66 0f 5c f9          	subpd  %xmm1,%xmm7
   20517:	66 44 0f 28 8c 24 f0 	movapd 0xf0(%rsp),%xmm9
   2051e:	00 00 00 
   20521:	66 41 0f 59 e9       	mulpd  %xmm9,%xmm5
   20526:	66 0f 58 ee          	addpd  %xmm6,%xmm5
   2052a:	66 44 0f 28 94 24 e0 	movapd 0xe0(%rsp),%xmm10
   20531:	00 00 00 
   20534:	66 41 0f 59 e2       	mulpd  %xmm10,%xmm4
   20539:	66 0f 58 e7          	addpd  %xmm7,%xmm4
   2053d:	66 41 0f 28 f7       	movapd %xmm15,%xmm6
   20542:	66 0f 59 f3          	mulpd  %xmm3,%xmm6
   20546:	66 0f 58 f5          	addpd  %xmm5,%xmm6
   2054a:	66 41 0f 28 e8       	movapd %xmm8,%xmm5
   2054f:	66 0f 59 ea          	mulpd  %xmm2,%xmm5
   20553:	66 0f 58 ec          	addpd  %xmm4,%xmm5
   20557:	66 41 0f 59 d9       	mulpd  %xmm9,%xmm3
   2055c:	66 0f 58 de          	addpd  %xmm6,%xmm3
   20560:	66 41 0f 59 d2       	mulpd  %xmm10,%xmm2
   20565:	66 0f 58 d5          	addpd  %xmm5,%xmm2
   20569:	4c 89 ee             	mov    %r13,%rsi
   2056c:	48 c1 e6 05          	shl    $0x5,%rsi
   20570:	48 01 e6             	add    %rsp,%rsi
   20573:	48 81 c6 00 02 00 00 	add    $0x200,%rsi
   2057a:	4d 85 ed             	test   %r13,%r13
   2057d:	0f 84 8a 00 00 00    	je     2060d <gpui_canvas::color::gamut::exact_endpoint_sign::<fearless_simd::generated::sse2::Sse2>+0x3fd>
   20583:	4d 89 e0             	mov    %r12,%r8
   20586:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   2058d:	00 00 00 
   20590:	66 0f 28 e3          	movapd %xmm3,%xmm4
   20594:	66 0f 28 ea          	movapd %xmm2,%xmm5
   20598:	66 41 0f 28 30       	movapd (%r8),%xmm6
   2059d:	66 41 0f 28 78 10    	movapd 0x10(%r8),%xmm7
   205a3:	66 0f 58 de          	addpd  %xmm6,%xmm3
   205a7:	66 0f 58 d7          	addpd  %xmm7,%xmm2
   205ab:	66 44 0f 28 c3       	movapd %xmm3,%xmm8
   205b0:	66 44 0f 5c c4       	subpd  %xmm4,%xmm8
   205b5:	66 44 0f 28 ca       	movapd %xmm2,%xmm9
   205ba:	66 44 0f 5c cd       	subpd  %xmm5,%xmm9
   205bf:	66 44 0f 28 d3       	movapd %xmm3,%xmm10
   205c4:	66 45 0f 5c d0       	subpd  %xmm8,%xmm10
   205c9:	66 44 0f 28 da       	movapd %xmm2,%xmm11
   205ce:	66 45 0f 5c d9       	subpd  %xmm9,%xmm11
   205d3:	66 41 0f 5c e2       	subpd  %xmm10,%xmm4
   205d8:	66 41 0f 5c eb       	subpd  %xmm11,%xmm5
   205dd:	66 41 0f 5c f0       	subpd  %xmm8,%xmm6
   205e2:	66 0f 58 f4          	addpd  %xmm4,%xmm6
   205e6:	66 41 0f 5c f9       	subpd  %xmm9,%xmm7
   205eb:	66 0f 58 fd          	addpd  %xmm5,%xmm7
   205ef:	66 41 0f 29 30       	movapd %xmm6,(%r8)
   205f4:	66 41 0f 29 78 10    	movapd %xmm7,0x10(%r8)
   205fa:	49 83 c0 20          	add    $0x20,%r8
   205fe:	49 39 f0             	cmp    %rsi,%r8
   20601:	75 8d                	jne    20590 <gpui_canvas::color::gamut::exact_endpoint_sign::<fearless_simd::generated::sse2::Sse2>+0x380>
   20603:	48 83 ff 10          	cmp    $0x10,%rdi
   20607:	0f 83 45 02 00 00    	jae    20852 <gpui_canvas::color::gamut::exact_endpoint_sign::<fearless_simd::generated::sse2::Sse2>+0x642>
   2060d:	48 83 c2 20          	add    $0x20,%rdx
   20611:	66 0f 29 1e          	movapd %xmm3,(%rsi)
   20615:	66 0f 29 56 10       	movapd %xmm2,0x10(%rsi)
   2061a:	4d 89 e0             	mov    %r12,%r8
   2061d:	0f 1f 00             	nopl   (%rax)
   20620:	66 0f 28 d0          	movapd %xmm0,%xmm2
   20624:	66 0f 28 d9          	movapd %xmm1,%xmm3
   20628:	66 41 0f 28 20       	movapd (%r8),%xmm4
   2062d:	66 41 0f 28 68 10    	movapd 0x10(%r8),%xmm5
   20633:	66 0f 58 c4          	addpd  %xmm4,%xmm0
   20637:	66 0f 58 cd          	addpd  %xmm5,%xmm1
   2063b:	66 0f 28 f0          	movapd %xmm0,%xmm6
   2063f:	66 0f 5c f2          	subpd  %xmm2,%xmm6
   20643:	66 0f 28 f9          	movapd %xmm1,%xmm7
   20647:	66 0f 5c fb          	subpd  %xmm3,%xmm7
   2064b:	66 44 0f 28 c0       	movapd %xmm0,%xmm8
   20650:	66 44 0f 5c c6       	subpd  %xmm6,%xmm8
   20655:	66 44 0f 28 c9       	movapd %xmm1,%xmm9
   2065a:	66 44 0f 5c cf       	subpd  %xmm7,%xmm9
   2065f:	66 41 0f 5c d0       	subpd  %xmm8,%xmm2
   20664:	66 41 0f 5c d9       	subpd  %xmm9,%xmm3
   20669:	66 0f 5c e6          	subpd  %xmm6,%xmm4
   2066d:	66 0f 58 e2          	addpd  %xmm2,%xmm4
   20671:	66 0f 5c ef          	subpd  %xmm7,%xmm5
   20675:	66 0f 58 eb          	addpd  %xmm3,%xmm5
   20679:	66 41 0f 29 20       	movapd %xmm4,(%r8)
   2067e:	66 41 0f 29 68 10    	movapd %xmm5,0x10(%r8)
   20684:	49 39 f0             	cmp    %rsi,%r8
   20687:	4d 8d 40 20          	lea    0x20(%r8),%r8
   2068b:	75 93                	jne    20620 <gpui_canvas::color::gamut::exact_endpoint_sign::<fearless_simd::generated::sse2::Sse2>+0x410>
   2068d:	66 0f 29 46 20       	movapd %xmm0,0x20(%rsi)
   20692:	66 0f 29 4e 30       	movapd %xmm1,0x30(%rsi)
   20697:	4c 8d 6f 02          	lea    0x2(%rdi),%r13
   2069b:	48 8d 70 01          	lea    0x1(%rax),%rsi
   2069f:	48 39 ca             	cmp    %rcx,%rdx
   206a2:	0f 85 f8 fd ff ff    	jne    204a0 <gpui_canvas::color::gamut::exact_endpoint_sign::<fearless_simd::generated::sse2::Sse2>+0x290>
   206a8:	4c 89 e9             	mov    %r13,%rcx
   206ab:	48 c1 e1 05          	shl    $0x5,%rcx
   206af:	48 01 e1             	add    %rsp,%rcx
   206b2:	48 81 c1 00 02 00 00 	add    $0x200,%rcx
   206b9:	4c 89 e2             	mov    %r12,%rdx
   206bc:	66 44 0f 28 84 24 d0 	movapd 0xd0(%rsp),%xmm8
   206c3:	00 00 00 
   206c6:	66 44 0f 28 8c 24 c0 	movapd 0xc0(%rsp),%xmm9
   206cd:	00 00 00 
   206d0:	66 41 0f 28 c1       	movapd %xmm9,%xmm0
   206d5:	66 41 0f 28 c8       	movapd %xmm8,%xmm1
   206da:	66 0f 28 12          	movapd (%rdx),%xmm2
   206de:	66 0f 28 5a 10       	movapd 0x10(%rdx),%xmm3
   206e3:	66 44 0f 58 c2       	addpd  %xmm2,%xmm8
   206e8:	66 44 0f 58 cb       	addpd  %xmm3,%xmm9
   206ed:	66 41 0f 28 e0       	movapd %xmm8,%xmm4
   206f2:	66 0f 5c e1          	subpd  %xmm1,%xmm4
   206f6:	66 41 0f 28 e9       	movapd %xmm9,%xmm5
   206fb:	66 0f 5c e8          	subpd  %xmm0,%xmm5
   206ff:	66 41 0f 28 f0       	movapd %xmm8,%xmm6
   20704:	66 0f 5c f4          	subpd  %xmm4,%xmm6
   20708:	66 41 0f 28 f9       	movapd %xmm9,%xmm7
   2070d:	66 0f 5c fd          	subpd  %xmm5,%xmm7
   20711:	66 0f 5c ce          	subpd  %xmm6,%xmm1
   20715:	66 0f 5c c7          	subpd  %xmm7,%xmm0
   20719:	66 0f 5c d4          	subpd  %xmm4,%xmm2
   2071d:	66 0f 58 d1          	addpd  %xmm1,%xmm2
   20721:	66 0f 5c dd          	subpd  %xmm5,%xmm3
   20725:	66 0f 58 d8          	addpd  %xmm0,%xmm3
   20729:	66 0f 29 12          	movapd %xmm2,(%rdx)
   2072d:	66 0f 29 5a 10       	movapd %xmm3,0x10(%rdx)
   20732:	48 83 c2 20          	add    $0x20,%rdx
   20736:	48 39 ca             	cmp    %rcx,%rdx
   20739:	75 95                	jne    206d0 <gpui_canvas::color::gamut::exact_endpoint_sign::<fearless_simd::generated::sse2::Sse2>+0x4c0>
   2073b:	48 83 ff 0e          	cmp    $0xe,%rdi
   2073f:	0f 83 1f 01 00 00    	jae    20864 <gpui_canvas::color::gamut::exact_endpoint_sign::<fearless_simd::generated::sse2::Sse2>+0x654>
   20745:	66 44 0f 29 01       	movapd %xmm8,(%rcx)
   2074a:	66 44 0f 29 49 10    	movapd %xmm9,0x10(%rcx)
   20750:	49 83 cd 01          	or     $0x1,%r13
   20754:	48 83 fb 03          	cmp    $0x3,%rbx
   20758:	0f 85 c2 fc ff ff    	jne    20420 <gpui_canvas::color::gamut::exact_endpoint_sign::<fearless_simd::generated::sse2::Sse2>+0x210>
   2075e:	66 0f 28 9c 24 00 02 	movapd 0x200(%rsp),%xmm3
   20765:	00 00 
   20767:	66 0f 28 a4 24 10 02 	movapd 0x210(%rsp),%xmm4
   2076e:	00 00 
   20770:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   20774:	66 0f 28 d3          	movapd %xmm3,%xmm2
   20778:	66 0f c2 d1 04       	cmpneqpd %xmm1,%xmm2
   2077d:	66 0f 28 c4          	movapd %xmm4,%xmm0
   20781:	66 0f c2 c1 04       	cmpneqpd %xmm1,%xmm0
   20786:	66 0f 54 d3          	andpd  %xmm3,%xmm2
   2078a:	66 0f 54 c4          	andpd  %xmm4,%xmm0
   2078e:	48 f7 d0             	not    %rax
   20791:	48 c1 e0 06          	shl    $0x6,%rax
   20795:	75 0a                	jne    207a1 <gpui_canvas::color::gamut::exact_endpoint_sign::<fearless_simd::generated::sse2::Sse2>+0x591>
   20797:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
   2079c:	e9 99 00 00 00       	jmp    2083a <gpui_canvas::color::gamut::exact_endpoint_sign::<fearless_simd::generated::sse2::Sse2>+0x62a>
   207a1:	49 c1 e5 05          	shl    $0x5,%r13
   207a5:	4a 8d 04 2c          	lea    (%rsp,%r13,1),%rax
   207a9:	48 05 00 02 00 00    	add    $0x200,%rax
   207af:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
   207b4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   207bb:	00 00 00 00 00 
   207c0:	66 41 0f 28 1e       	movapd (%r14),%xmm3
   207c5:	66 41 0f 28 66 10    	movapd 0x10(%r14),%xmm4
   207cb:	66 41 0f 28 6e 20    	movapd 0x20(%r14),%xmm5
   207d1:	66 41 0f 28 76 30    	movapd 0x30(%r14),%xmm6
   207d7:	66 0f 28 fb          	movapd %xmm3,%xmm7
   207db:	66 0f c2 f9 04       	cmpneqpd %xmm1,%xmm7
   207e0:	66 44 0f 28 c4       	movapd %xmm4,%xmm8
   207e5:	66 44 0f c2 c1 04    	cmpneqpd %xmm1,%xmm8
   207eb:	66 0f 54 df          	andpd  %xmm7,%xmm3
   207ef:	66 0f 55 fa          	andnpd %xmm2,%xmm7
   207f3:	66 0f 56 fb          	orpd   %xmm3,%xmm7
   207f7:	66 41 0f 54 e0       	andpd  %xmm8,%xmm4
   207fc:	66 44 0f 55 c0       	andnpd %xmm0,%xmm8
   20801:	66 44 0f 56 c4       	orpd   %xmm4,%xmm8
   20806:	66 0f 28 d5          	movapd %xmm5,%xmm2
   2080a:	66 0f c2 d1 04       	cmpneqpd %xmm1,%xmm2
   2080f:	66 0f 28 c6          	movapd %xmm6,%xmm0
   20813:	66 0f c2 c1 04       	cmpneqpd %xmm1,%xmm0
   20818:	66 0f 54 ea          	andpd  %xmm2,%xmm5
   2081c:	66 0f 55 d7          	andnpd %xmm7,%xmm2
   20820:	66 0f 56 d5          	orpd   %xmm5,%xmm2
   20824:	66 0f 54 f0          	andpd  %xmm0,%xmm6
   20828:	66 41 0f 55 c0       	andnpd %xmm8,%xmm0
   2082d:	66 0f 56 c6          	orpd   %xmm6,%xmm0
   20831:	49 83 c6 40          	add    $0x40,%r14
   20835:	49 39 c6             	cmp    %rax,%r14
   20838:	75 86                	jne    207c0 <gpui_canvas::color::gamut::exact_endpoint_sign::<fearless_simd::generated::sse2::Sse2>+0x5b0>
   2083a:	66 0f 29 11          	movapd %xmm2,(%rcx)
   2083e:	66 0f 29 41 10       	movapd %xmm0,0x10(%rcx)
   20843:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
   20847:	5b                   	pop    %rbx
   20848:	41 5c                	pop    %r12
   2084a:	41 5d                	pop    %r13
   2084c:	41 5e                	pop    %r14
   2084e:	41 5f                	pop    %r15
   20850:	5d                   	pop    %rbp
   20851:	c3                   	ret
   20852:	48 8d 15 87 0f 04 00 	lea    0x40f87(%rip),%rdx        # 617e0 <__frame_dummy_init_array_entry+0x220>
   20859:	be 10 00 00 00       	mov    $0x10,%esi
   2085e:	ff 15 cc 2f 04 00    	call   *0x42fcc(%rip)        # 63830 <_DYNAMIC+0x2f0>
   20864:	48 8d 15 75 0f 04 00 	lea    0x40f75(%rip),%rdx        # 617e0 <__frame_dummy_init_array_entry+0x220>
   2086b:	be 10 00 00 00       	mov    $0x10,%esi
   20870:	4c 89 ef             	mov    %r13,%rdi
   20873:	ff 15 b7 2f 04 00    	call   *0x42fb7(%rip)        # 63830 <_DYNAMIC+0x2f0>
   20879:	cc                   	int3
   2087a:	cc                   	int3
   2087b:	cc                   	int3
   2087c:	cc                   	int3
   2087d:	cc                   	int3
   2087e:	cc                   	int3
   2087f:	cc                   	int3

gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>:
   20880:	55                   	push   %rbp
   20881:	48 89 e5             	mov    %rsp,%rbp
   20884:	41 57                	push   %r15
   20886:	41 56                	push   %r14
   20888:	41 55                	push   %r13
   2088a:	41 54                	push   %r12
   2088c:	53                   	push   %rbx
   2088d:	48 83 e4 e0          	and    $0xffffffffffffffe0,%rsp
   20891:	48 81 ec 40 02 00 00 	sub    $0x240,%rsp
   20898:	f3 0f 11 44 24 1c    	movss  %xmm0,0x1c(%rsp)
   2089e:	89 fb                	mov    %edi,%ebx
   208a0:	0f 29 8c 24 f0 00 00 	movaps %xmm1,0xf0(%rsp)
   208a7:	00 
   208a8:	0f 57 c0             	xorps  %xmm0,%xmm0
   208ab:	f3 0f 5a c1          	cvtss2sd %xmm1,%xmm0
   208af:	f2 0f 59 05 f9 67 fe 	mulsd  -0x19807(%rip),%xmm0        # 70b0 <std::thread::current::id::ID+0x6438>
   208b6:	ff 
   208b7:	48 8d bc 24 08 01 00 	lea    0x108(%rsp),%rdi
   208be:	00 
   208bf:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
   208c6:	00 
   208c7:	ff 15 fb 2f 04 00    	call   *0x42ffb(%rip)        # 638c8 <sincos@GLIBC_2.2.5>
   208cd:	f2 0f 10 84 24 08 01 	movsd  0x108(%rsp),%xmm0
   208d4:	00 00 
   208d6:	f2 0f 10 8c 24 00 01 	movsd  0x100(%rsp),%xmm1
   208dd:	00 00 
   208df:	f2 0f 10 15 c1 67 fe 	movsd  -0x1983f(%rip),%xmm2        # 70a8 <std::thread::current::id::ID+0x6430>
   208e6:	ff 
   208e7:	f2 0f 59 d1          	mulsd  %xmm1,%xmm2
   208eb:	66 0f 57 db          	xorpd  %xmm3,%xmm3
   208ef:	f2 0f 58 d3          	addsd  %xmm3,%xmm2
   208f3:	f2 0f 10 25 2d 67 fe 	movsd  -0x198d3(%rip),%xmm4        # 7028 <std::thread::current::id::ID+0x63b0>
   208fa:	ff 
   208fb:	f2 0f 59 e1          	mulsd  %xmm1,%xmm4
   208ff:	f2 0f 58 e3          	addsd  %xmm3,%xmm4
   20903:	f2 0f 10 3d 4d 67 fe 	movsd  -0x198b3(%rip),%xmm7        # 7058 <std::thread::current::id::ID+0x63e0>
   2090a:	ff 
   2090b:	f2 0f 59 f8          	mulsd  %xmm0,%xmm7
   2090f:	f2 0f 58 fa          	addsd  %xmm2,%xmm7
   20913:	f2 0f 10 2d bd 67 fe 	movsd  -0x19843(%rip),%xmm5        # 70d8 <std::thread::current::id::ID+0x6460>
   2091a:	ff 
   2091b:	f2 0f 59 e8          	mulsd  %xmm0,%xmm5
   2091f:	f2 0f 58 ec          	addsd  %xmm4,%xmm5
   20923:	f2 0f 59 0d 6d 67 fe 	mulsd  -0x19893(%rip),%xmm1        # 7098 <std::thread::current::id::ID+0x6420>
   2092a:	ff 
   2092b:	f2 0f 58 cb          	addsd  %xmm3,%xmm1
   2092f:	f2 0f 59 05 31 66 fe 	mulsd  -0x199cf(%rip),%xmm0        # 6f68 <std::thread::current::id::ID+0x62f0>
   20936:	ff 
   20937:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
   2093b:	85 db                	test   %ebx,%ebx
   2093d:	74 34                	je     20973 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xf3>
   2093f:	66 0f 28 15 49 48 fe 	movapd -0x1b7b7(%rip),%xmm2        # 5190 <std::thread::current::id::ID+0x4518>
   20946:	ff 
   20947:	66 0f 28 0d 41 4c fe 	movapd -0x1b3bf(%rip),%xmm1        # 5590 <std::thread::current::id::ID+0x4918>
   2094e:	ff 
   2094f:	66 44 0f 28 1d 98 4c 	movapd -0x1b368(%rip),%xmm11        # 55f0 <std::thread::current::id::ID+0x4978>
   20956:	fe ff 
   20958:	f3 0f 7e 1d 40 66 fe 	movq   -0x199c0(%rip),%xmm3        # 6fa0 <std::thread::current::id::ID+0x6328>
   2095f:	ff 
   20960:	f3 0f 7e 35 d8 66 fe 	movq   -0x19928(%rip),%xmm6        # 7040 <std::thread::current::id::ID+0x63c8>
   20967:	ff 
   20968:	f3 44 0f 7e 05 37 66 	movq   -0x199c9(%rip),%xmm8        # 6fa8 <std::thread::current::id::ID+0x6330>
   2096f:	fe ff 
   20971:	eb 32                	jmp    209a5 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x125>
   20973:	66 0f 28 15 45 4a fe 	movapd -0x1b5bb(%rip),%xmm2        # 53c0 <std::thread::current::id::ID+0x4748>
   2097a:	ff 
   2097b:	66 0f 28 0d 1d 4b fe 	movapd -0x1b4e3(%rip),%xmm1        # 54a0 <std::thread::current::id::ID+0x4828>
   20982:	ff 
   20983:	66 44 0f 28 1d d4 49 	movapd -0x1b62c(%rip),%xmm11        # 5360 <std::thread::current::id::ID+0x46e8>
   2098a:	fe ff 
   2098c:	f3 0f 7e 1d f4 66 fe 	movq   -0x1990c(%rip),%xmm3        # 7088 <std::thread::current::id::ID+0x6410>
   20993:	ff 
   20994:	f3 0f 7e 35 dc 66 fe 	movq   -0x19924(%rip),%xmm6        # 7078 <std::thread::current::id::ID+0x6400>
   2099b:	ff 
   2099c:	f3 44 0f 7e 05 6b 66 	movq   -0x19995(%rip),%xmm8        # 7010 <std::thread::current::id::ID+0x6398>
   209a3:	fe ff 
   209a5:	f3 0f 7e e3          	movq   %xmm3,%xmm4
   209a9:	f3 0f 7e f6          	movq   %xmm6,%xmm6
   209ad:	f3 41 0f 7e d8       	movq   %xmm8,%xmm3
   209b2:	66 0f 14 fd          	unpcklpd %xmm5,%xmm7
   209b6:	66 0f 28 ef          	movapd %xmm7,%xmm5
   209ba:	66 0f 59 ef          	mulpd  %xmm7,%xmm5
   209be:	66 44 0f 28 c0       	movapd %xmm0,%xmm8
   209c3:	f2 44 0f 59 c0       	mulsd  %xmm0,%xmm8
   209c8:	f2 44 0f 59 c0       	mulsd  %xmm0,%xmm8
   209cd:	66 0f 59 ef          	mulpd  %xmm7,%xmm5
   209d1:	66 0f 29 6c 24 40    	movapd %xmm5,0x40(%rsp)
   209d7:	f2 44 0f 11 44 24 50 	movsd  %xmm8,0x50(%rsp)
   209de:	f2 0f 10 6c 24 40    	movsd  0x40(%rsp),%xmm5
   209e4:	66 0f 14 ed          	unpcklpd %xmm5,%xmm5
   209e8:	66 44 0f 28 c2       	movapd %xmm2,%xmm8
   209ed:	66 44 0f 59 c5       	mulpd  %xmm5,%xmm8
   209f2:	66 0f 59 ec          	mulpd  %xmm4,%xmm5
   209f6:	66 44 0f 10 64 24 48 	movupd 0x48(%rsp),%xmm12
   209fd:	66 45 0f 28 cc       	movapd %xmm12,%xmm9
   20a02:	66 45 0f 14 cc       	unpcklpd %xmm12,%xmm9
   20a07:	66 44 0f 28 d1       	movapd %xmm1,%xmm10
   20a0c:	66 45 0f 59 d1       	mulpd  %xmm9,%xmm10
   20a11:	66 45 0f 58 d0       	addpd  %xmm8,%xmm10
   20a16:	66 44 0f 59 ce       	mulpd  %xmm6,%xmm9
   20a1b:	66 44 0f 58 cd       	addpd  %xmm5,%xmm9
   20a20:	66 45 0f 15 e4       	unpckhpd %xmm12,%xmm12
   20a25:	66 41 0f 28 eb       	movapd %xmm11,%xmm5
   20a2a:	66 41 0f 59 ec       	mulpd  %xmm12,%xmm5
   20a2f:	66 41 0f 58 ea       	addpd  %xmm10,%xmm5
   20a34:	66 44 0f 28 f5       	movapd %xmm5,%xmm14
   20a39:	66 0f 29 ac 24 60 01 	movapd %xmm5,0x160(%rsp)
   20a40:	00 00 
   20a42:	66 44 0f 59 e3       	mulpd  %xmm3,%xmm12
   20a47:	66 45 0f 58 e1       	addpd  %xmm9,%xmm12
   20a4c:	66 44 0f 29 64 24 30 	movapd %xmm12,0x30(%rsp)
   20a53:	66 0f 28 2d 25 48 fe 	movapd -0x1b7db(%rip),%xmm5        # 5280 <std::thread::current::id::ID+0x4608>
   20a5a:	ff 
   20a5b:	66 44 0f 28 c7       	movapd %xmm7,%xmm8
   20a60:	66 44 0f 59 c5       	mulpd  %xmm5,%xmm8
   20a65:	f2 44 0f 10 0d c2 65 	movsd  -0x19a3e(%rip),%xmm9        # 7030 <std::thread::current::id::ID+0x63b8>
   20a6c:	fe ff 
   20a6e:	f2 44 0f 59 c8       	mulsd  %xmm0,%xmm9
   20a73:	f2 41 0f 59 c1       	mulsd  %xmm9,%xmm0
   20a78:	66 41 0f 59 f8       	mulpd  %xmm8,%xmm7
   20a7d:	66 0f 29 7c 24 40    	movapd %xmm7,0x40(%rsp)
   20a83:	f2 0f 11 44 24 50    	movsd  %xmm0,0x50(%rsp)
   20a89:	f2 0f 10 44 24 40    	movsd  0x40(%rsp),%xmm0
   20a8f:	66 0f 14 c0          	unpcklpd %xmm0,%xmm0
   20a93:	66 0f 28 fa          	movapd %xmm2,%xmm7
   20a97:	66 0f 59 f8          	mulpd  %xmm0,%xmm7
   20a9b:	66 0f 59 c4          	mulpd  %xmm4,%xmm0
   20a9f:	66 44 0f 10 6c 24 48 	movupd 0x48(%rsp),%xmm13
   20aa6:	66 45 0f 28 d5       	movapd %xmm13,%xmm10
   20aab:	66 45 0f 14 d5       	unpcklpd %xmm13,%xmm10
   20ab0:	66 45 0f 28 e3       	movapd %xmm11,%xmm12
   20ab5:	66 44 0f 28 d9       	movapd %xmm1,%xmm11
   20aba:	66 45 0f 59 da       	mulpd  %xmm10,%xmm11
   20abf:	66 44 0f 58 df       	addpd  %xmm7,%xmm11
   20ac4:	66 44 0f 59 d6       	mulpd  %xmm6,%xmm10
   20ac9:	66 44 0f 58 d0       	addpd  %xmm0,%xmm10
   20ace:	66 45 0f 15 ed       	unpckhpd %xmm13,%xmm13
   20ad3:	66 41 0f 28 c4       	movapd %xmm12,%xmm0
   20ad8:	66 41 0f 59 c5       	mulpd  %xmm13,%xmm0
   20add:	66 41 0f 58 c3       	addpd  %xmm11,%xmm0
   20ae2:	66 44 0f 28 d8       	movapd %xmm0,%xmm11
   20ae7:	66 0f 29 84 24 40 01 	movapd %xmm0,0x140(%rsp)
   20aee:	00 00 
   20af0:	66 44 0f 59 eb       	mulpd  %xmm3,%xmm13
   20af5:	66 45 0f 58 ea       	addpd  %xmm10,%xmm13
   20afa:	66 44 0f 29 ac 24 50 	movapd %xmm13,0x150(%rsp)
   20b01:	01 00 00 
   20b04:	66 44 0f 29 44 24 40 	movapd %xmm8,0x40(%rsp)
   20b0b:	f2 44 0f 11 4c 24 50 	movsd  %xmm9,0x50(%rsp)
   20b12:	f2 0f 10 44 24 40    	movsd  0x40(%rsp),%xmm0
   20b18:	66 0f 14 c0          	unpcklpd %xmm0,%xmm0
   20b1c:	66 0f 28 fa          	movapd %xmm2,%xmm7
   20b20:	66 0f 59 f8          	mulpd  %xmm0,%xmm7
   20b24:	66 0f 59 c4          	mulpd  %xmm4,%xmm0
   20b28:	66 44 0f 10 54 24 48 	movupd 0x48(%rsp),%xmm10
   20b2f:	66 45 0f 28 c2       	movapd %xmm10,%xmm8
   20b34:	66 45 0f 14 c2       	unpcklpd %xmm10,%xmm8
   20b39:	66 44 0f 28 c9       	movapd %xmm1,%xmm9
   20b3e:	66 45 0f 59 c8       	mulpd  %xmm8,%xmm9
   20b43:	66 44 0f 58 cf       	addpd  %xmm7,%xmm9
   20b48:	66 44 0f 59 c6       	mulpd  %xmm6,%xmm8
   20b4d:	66 44 0f 58 c0       	addpd  %xmm0,%xmm8
   20b52:	66 45 0f 15 d2       	unpckhpd %xmm10,%xmm10
   20b57:	66 41 0f 28 c4       	movapd %xmm12,%xmm0
   20b5c:	66 41 0f 59 c2       	mulpd  %xmm10,%xmm0
   20b61:	66 41 0f 58 c1       	addpd  %xmm9,%xmm0
   20b66:	66 44 0f 28 c8       	movapd %xmm0,%xmm9
   20b6b:	66 0f 29 84 24 20 01 	movapd %xmm0,0x120(%rsp)
   20b72:	00 00 
   20b74:	66 44 0f 59 d3       	mulpd  %xmm3,%xmm10
   20b79:	66 45 0f 58 d0       	addpd  %xmm8,%xmm10
   20b7e:	66 44 0f 29 94 24 30 	movapd %xmm10,0x130(%rsp)
   20b85:	01 00 00 
   20b88:	0f 28 05 21 49 fe ff 	movaps -0x1b6df(%rip),%xmm0        # 54b0 <std::thread::current::id::ID+0x4838>
   20b8f:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
   20b94:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
   20b9b:	00 f0 3f 
   20b9e:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   20ba3:	66 0f 10 44 24 48    	movupd 0x48(%rsp),%xmm0
   20ba9:	66 0f 28 f8          	movapd %xmm0,%xmm7
   20bad:	66 0f 14 f8          	unpcklpd %xmm0,%xmm7
   20bb1:	66 0f 59 cf          	mulpd  %xmm7,%xmm1
   20bb5:	66 0f 59 fe          	mulpd  %xmm6,%xmm7
   20bb9:	66 0f 58 ca          	addpd  %xmm2,%xmm1
   20bbd:	66 0f 58 fc          	addpd  %xmm4,%xmm7
   20bc1:	66 0f 15 c0          	unpckhpd %xmm0,%xmm0
   20bc5:	66 44 0f 59 e0       	mulpd  %xmm0,%xmm12
   20bca:	66 44 0f 58 e1       	addpd  %xmm1,%xmm12
   20bcf:	66 44 0f 29 a4 24 70 	movapd %xmm12,0x170(%rsp)
   20bd6:	01 00 00 
   20bd9:	66 0f 59 c3          	mulpd  %xmm3,%xmm0
   20bdd:	66 0f 58 c7          	addpd  %xmm7,%xmm0
   20be1:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   20be5:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   20be9:	66 0f 16 0d f7 63 fe 	movhpd -0x19c09(%rip),%xmm1        # 6fe8 <std::thread::current::id::ID+0x6370>
   20bf0:	ff 
   20bf1:	66 0f 58 c8          	addpd  %xmm0,%xmm1
   20bf5:	66 0f 29 8c 24 10 01 	movapd %xmm1,0x110(%rsp)
   20bfc:	00 00 
   20bfe:	66 44 0f 59 f5       	mulpd  %xmm5,%xmm14
   20c03:	66 0f 59 6c 24 30    	mulpd  0x30(%rsp),%xmm5
   20c09:	66 44 0f 28 e5       	movapd %xmm5,%xmm12
   20c0e:	66 45 0f 58 db       	addpd  %xmm11,%xmm11
   20c13:	66 45 0f 58 ed       	addpd  %xmm13,%xmm13
   20c18:	66 41 0f 28 f3       	movapd %xmm11,%xmm6
   20c1d:	66 41 0f 59 f3       	mulpd  %xmm11,%xmm6
   20c22:	66 41 0f 28 c6       	movapd %xmm14,%xmm0
   20c27:	66 41 0f 59 c1       	mulpd  %xmm9,%xmm0
   20c2c:	66 0f 28 0d 8c 46 fe 	movapd -0x1b974(%rip),%xmm1        # 52c0 <std::thread::current::id::ID+0x4648>
   20c33:	ff 
   20c34:	66 0f 59 c1          	mulpd  %xmm1,%xmm0
   20c38:	66 0f 5c f0          	subpd  %xmm0,%xmm6
   20c3c:	66 0f 28 c5          	movapd %xmm5,%xmm0
   20c40:	66 41 0f 59 c2       	mulpd  %xmm10,%xmm0
   20c45:	66 0f 59 c1          	mulpd  %xmm1,%xmm0
   20c49:	66 41 0f 28 fd       	movapd %xmm13,%xmm7
   20c4e:	66 41 0f 59 fd       	mulpd  %xmm13,%xmm7
   20c53:	66 0f 5c f8          	subpd  %xmm0,%xmm7
   20c57:	66 45 0f 28 cb       	movapd %xmm11,%xmm9
   20c5c:	66 44 0f c2 ca 01    	cmpltpd %xmm2,%xmm9
   20c62:	66 0f 28 05 96 49 fe 	movapd -0x1b66a(%rip),%xmm0        # 5600 <std::thread::current::id::ID+0x4988>
   20c69:	ff 
   20c6a:	66 45 0f 28 c1       	movapd %xmm9,%xmm8
   20c6f:	66 44 0f 54 c0       	andpd  %xmm0,%xmm8
   20c74:	66 0f 28 0d 34 48 fe 	movapd -0x1b7cc(%rip),%xmm1        # 54b0 <std::thread::current::id::ID+0x4838>
   20c7b:	ff 
   20c7c:	66 44 0f 55 c9       	andnpd %xmm1,%xmm9
   20c81:	66 45 0f 56 c8       	orpd   %xmm8,%xmm9
   20c86:	66 45 0f 28 d5       	movapd %xmm13,%xmm10
   20c8b:	66 44 0f c2 d2 01    	cmpltpd %xmm2,%xmm10
   20c91:	66 41 0f 54 c2       	andpd  %xmm10,%xmm0
   20c96:	66 44 0f 55 d1       	andnpd %xmm1,%xmm10
   20c9b:	66 44 0f 28 c1       	movapd %xmm1,%xmm8
   20ca0:	66 44 0f 56 d0       	orpd   %xmm0,%xmm10
   20ca5:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
   20ca9:	66 0f c2 c6 02       	cmplepd %xmm6,%xmm0
   20cae:	66 0f 29 44 24 20    	movapd %xmm0,0x20(%rsp)
   20cb4:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   20cb8:	66 0f 5f f1          	maxpd  %xmm1,%xmm6
   20cbc:	66 0f 51 f6          	sqrtpd %xmm6,%xmm6
   20cc0:	66 41 0f 59 f1       	mulpd  %xmm9,%xmm6
   20cc5:	66 0f 57 e4          	xorpd  %xmm4,%xmm4
   20cc9:	66 0f c2 e7 02       	cmplepd %xmm7,%xmm4
   20cce:	66 0f 5f f9          	maxpd  %xmm1,%xmm7
   20cd2:	66 0f 51 ff          	sqrtpd %xmm7,%xmm7
   20cd6:	66 41 0f 59 fa       	mulpd  %xmm10,%xmm7
   20cdb:	66 41 0f 28 eb       	movapd %xmm11,%xmm5
   20ce0:	66 41 0f 58 f3       	addpd  %xmm11,%xmm6
   20ce5:	66 41 0f 58 fd       	addpd  %xmm13,%xmm7
   20cea:	66 0f 28 05 1e 49 fe 	movapd -0x1b6e2(%rip),%xmm0        # 5610 <std::thread::current::id::ID+0x4998>
   20cf1:	ff 
   20cf2:	66 0f 59 f0          	mulpd  %xmm0,%xmm6
   20cf6:	66 0f 59 f8          	mulpd  %xmm0,%xmm7
   20cfa:	66 45 0f 28 de       	movapd %xmm14,%xmm11
   20cff:	66 44 0f c2 d9 00    	cmpeqpd %xmm1,%xmm11
   20d05:	66 0f 28 d5          	movapd %xmm5,%xmm2
   20d09:	66 0f c2 d1 00       	cmpeqpd %xmm1,%xmm2
   20d0e:	66 44 0f 28 fa       	movapd %xmm2,%xmm15
   20d13:	66 0f 55 d5          	andnpd %xmm5,%xmm2
   20d17:	66 0f c2 e9 04       	cmpneqpd %xmm1,%xmm5
   20d1c:	66 0f 57 db          	xorpd  %xmm3,%xmm3
   20d20:	66 41 0f 54 eb       	andpd  %xmm11,%xmm5
   20d25:	66 0f 29 ac 24 90 01 	movapd %xmm5,0x190(%rsp)
   20d2c:	00 00 
   20d2e:	66 41 0f 28 cb       	movapd %xmm11,%xmm1
   20d33:	66 45 0f 28 c8       	movapd %xmm8,%xmm9
   20d38:	66 45 0f 54 d8       	andpd  %xmm8,%xmm11
   20d3d:	66 41 0f 55 ce       	andnpd %xmm14,%xmm1
   20d42:	66 41 0f 56 cb       	orpd   %xmm11,%xmm1
   20d47:	66 41 0f 28 ec       	movapd %xmm12,%xmm5
   20d4c:	66 45 0f 28 dc       	movapd %xmm12,%xmm11
   20d51:	66 44 0f c2 db 00    	cmpeqpd %xmm3,%xmm11
   20d57:	66 41 0f 28 c5       	movapd %xmm13,%xmm0
   20d5c:	66 45 0f 28 d5       	movapd %xmm13,%xmm10
   20d61:	66 44 0f c2 d3 00    	cmpeqpd %xmm3,%xmm10
   20d67:	66 45 0f 28 ea       	movapd %xmm10,%xmm13
   20d6c:	66 44 0f 55 d0       	andnpd %xmm0,%xmm10
   20d71:	66 0f c2 c3 04       	cmpneqpd %xmm3,%xmm0
   20d76:	66 41 0f 54 c3       	andpd  %xmm11,%xmm0
   20d7b:	66 0f 29 84 24 a0 01 	movapd %xmm0,0x1a0(%rsp)
   20d82:	00 00 
   20d84:	66 41 0f 28 c3       	movapd %xmm11,%xmm0
   20d89:	66 45 0f 54 d8       	andpd  %xmm8,%xmm11
   20d8e:	66 41 0f 55 c4       	andnpd %xmm12,%xmm0
   20d93:	66 41 0f 56 c3       	orpd   %xmm11,%xmm0
   20d98:	66 44 0f 28 c6       	movapd %xmm6,%xmm8
   20d9d:	66 44 0f c2 c3 00    	cmpeqpd %xmm3,%xmm8
   20da3:	66 45 0f 28 e0       	movapd %xmm8,%xmm12
   20da8:	66 45 0f 54 e1       	andpd  %xmm9,%xmm12
   20dad:	66 44 0f 55 c6       	andnpd %xmm6,%xmm8
   20db2:	66 45 0f 56 c4       	orpd   %xmm12,%xmm8
   20db7:	66 44 0f 29 84 24 d0 	movapd %xmm8,0x1d0(%rsp)
   20dbe:	01 00 00 
   20dc1:	66 44 0f 28 df       	movapd %xmm7,%xmm11
   20dc6:	66 44 0f c2 db 00    	cmpeqpd %xmm3,%xmm11
   20dcc:	66 45 0f 28 e3       	movapd %xmm11,%xmm12
   20dd1:	66 45 0f 54 e1       	andpd  %xmm9,%xmm12
   20dd6:	66 44 0f 55 df       	andnpd %xmm7,%xmm11
   20ddb:	66 45 0f 56 dc       	orpd   %xmm12,%xmm11
   20de0:	66 45 0f 54 f9       	andpd  %xmm9,%xmm15
   20de5:	66 41 0f 56 d7       	orpd   %xmm15,%xmm2
   20dea:	66 45 0f 54 e9       	andpd  %xmm9,%xmm13
   20def:	66 45 0f 56 d5       	orpd   %xmm13,%xmm10
   20df4:	66 45 0f 57 c9       	xorpd  %xmm9,%xmm9
   20df9:	66 45 0f c2 f1 04    	cmpneqpd %xmm9,%xmm14
   20dff:	66 44 0f 28 44 24 20 	movapd 0x20(%rsp),%xmm8
   20e06:	66 45 0f 54 c6       	andpd  %xmm14,%xmm8
   20e0b:	66 44 0f 29 44 24 20 	movapd %xmm8,0x20(%rsp)
   20e12:	66 41 0f c2 e9 04    	cmpneqpd %xmm9,%xmm5
   20e18:	66 0f 54 e5          	andpd  %xmm5,%xmm4
   20e1c:	66 0f 29 a4 24 c0 01 	movapd %xmm4,0x1c0(%rsp)
   20e23:	00 00 
   20e25:	66 0f 28 de          	movapd %xmm6,%xmm3
   20e29:	66 0f 5e d9          	divpd  %xmm1,%xmm3
   20e2d:	66 0f 29 9c 24 b0 01 	movapd %xmm3,0x1b0(%rsp)
   20e34:	00 00 
   20e36:	66 0f 28 cf          	movapd %xmm7,%xmm1
   20e3a:	66 0f 5e c8          	divpd  %xmm0,%xmm1
   20e3e:	66 0f 29 8c 24 80 01 	movapd %xmm1,0x180(%rsp)
   20e45:	00 00 
   20e47:	66 44 0f 28 3d 20 47 	movapd -0x1b8e0(%rip),%xmm15        # 5570 <std::thread::current::id::ID+0x48f8>
   20e4e:	fe ff 
   20e50:	66 0f 28 ac 24 60 01 	movapd 0x160(%rsp),%xmm5
   20e57:	00 00 
   20e59:	66 0f 28 c5          	movapd %xmm5,%xmm0
   20e5d:	66 41 0f 57 c7       	xorpd  %xmm15,%xmm0
   20e62:	66 0f 29 44 24 40    	movapd %xmm0,0x40(%rsp)
   20e68:	66 44 0f 28 4c 24 30 	movapd 0x30(%rsp),%xmm9
   20e6f:	66 41 0f 28 c1       	movapd %xmm9,%xmm0
   20e74:	66 41 0f 57 c7       	xorpd  %xmm15,%xmm0
   20e79:	66 0f 29 44 24 50    	movapd %xmm0,0x50(%rsp)
   20e7f:	66 44 0f 28 a4 24 40 	movapd 0x140(%rsp),%xmm12
   20e86:	01 00 00 
   20e89:	66 41 0f 28 c4       	movapd %xmm12,%xmm0
   20e8e:	66 41 0f 57 c7       	xorpd  %xmm15,%xmm0
   20e93:	66 0f 29 44 24 60    	movapd %xmm0,0x60(%rsp)
   20e99:	66 44 0f 28 ac 24 50 	movapd 0x150(%rsp),%xmm13
   20ea0:	01 00 00 
   20ea3:	66 41 0f 28 c5       	movapd %xmm13,%xmm0
   20ea8:	66 41 0f 57 c7       	xorpd  %xmm15,%xmm0
   20ead:	66 0f 29 44 24 70    	movapd %xmm0,0x70(%rsp)
   20eb3:	66 44 0f 28 84 24 20 	movapd 0x120(%rsp),%xmm8
   20eba:	01 00 00 
   20ebd:	66 41 0f 28 c0       	movapd %xmm8,%xmm0
   20ec2:	66 41 0f 57 c7       	xorpd  %xmm15,%xmm0
   20ec7:	66 0f 29 84 24 80 00 	movapd %xmm0,0x80(%rsp)
   20ece:	00 00 
   20ed0:	66 0f 5e c2          	divpd  %xmm2,%xmm0
   20ed4:	66 44 0f 28 b4 24 30 	movapd 0x130(%rsp),%xmm14
   20edb:	01 00 00 
   20ede:	66 41 0f 28 ce       	movapd %xmm14,%xmm1
   20ee3:	66 41 0f 57 cf       	xorpd  %xmm15,%xmm1
   20ee8:	66 0f 29 8c 24 90 00 	movapd %xmm1,0x90(%rsp)
   20eef:	00 00 
   20ef1:	66 41 0f 5e ca       	divpd  %xmm10,%xmm1
   20ef6:	66 0f 28 94 24 90 01 	movapd 0x190(%rsp),%xmm2
   20efd:	00 00 
   20eff:	66 0f 54 c2          	andpd  %xmm2,%xmm0
   20f03:	66 44 0f 28 15 24 46 	movapd -0x1b9dc(%rip),%xmm10        # 5530 <std::thread::current::id::ID+0x48b8>
   20f0a:	fe ff 
   20f0c:	66 41 0f 55 d2       	andnpd %xmm10,%xmm2
   20f11:	66 0f 56 d0          	orpd   %xmm0,%xmm2
   20f15:	66 0f 28 84 24 a0 01 	movapd 0x1a0(%rsp),%xmm0
   20f1c:	00 00 
   20f1e:	66 0f 54 c8          	andpd  %xmm0,%xmm1
   20f22:	66 41 0f 55 c2       	andnpd %xmm10,%xmm0
   20f27:	66 0f 56 c1          	orpd   %xmm1,%xmm0
   20f2b:	66 0f 28 e0          	movapd %xmm0,%xmm4
   20f2f:	66 0f 28 44 24 20    	movapd 0x20(%rsp),%xmm0
   20f35:	66 0f 28 8c 24 b0 01 	movapd 0x1b0(%rsp),%xmm1
   20f3c:	00 00 
   20f3e:	66 0f 54 c8          	andpd  %xmm0,%xmm1
   20f42:	66 0f 57 db          	xorpd  %xmm3,%xmm3
   20f46:	66 0f c2 f3 04       	cmpneqpd %xmm3,%xmm6
   20f4b:	66 0f 54 f0          	andpd  %xmm0,%xmm6
   20f4f:	66 0f 55 c2          	andnpd %xmm2,%xmm0
   20f53:	66 0f 56 c1          	orpd   %xmm1,%xmm0
   20f57:	66 0f 28 8c 24 c0 01 	movapd 0x1c0(%rsp),%xmm1
   20f5e:	00 00 
   20f60:	66 0f 28 94 24 80 01 	movapd 0x180(%rsp),%xmm2
   20f67:	00 00 
   20f69:	66 0f 54 d1          	andpd  %xmm1,%xmm2
   20f6d:	66 0f c2 fb 04       	cmpneqpd %xmm3,%xmm7
   20f72:	66 0f 54 f9          	andpd  %xmm1,%xmm7
   20f76:	66 0f 55 cc          	andnpd %xmm4,%xmm1
   20f7a:	66 0f 56 ca          	orpd   %xmm2,%xmm1
   20f7e:	66 41 0f 28 d8       	movapd %xmm8,%xmm3
   20f83:	66 0f 5e 9c 24 d0 01 	divpd  0x1d0(%rsp),%xmm3
   20f8a:	00 00 
   20f8c:	66 41 0f 28 e6       	movapd %xmm14,%xmm4
   20f91:	66 41 0f 5e e3       	divpd  %xmm11,%xmm4
   20f96:	66 0f 54 de          	andpd  %xmm6,%xmm3
   20f9a:	66 41 0f 55 f2       	andnpd %xmm10,%xmm6
   20f9f:	66 0f 56 f3          	orpd   %xmm3,%xmm6
   20fa3:	66 0f 54 e7          	andpd  %xmm7,%xmm4
   20fa7:	66 41 0f 55 fa       	andnpd %xmm10,%xmm7
   20fac:	66 0f 56 fc          	orpd   %xmm4,%xmm7
   20fb0:	66 0f 57 db          	xorpd  %xmm3,%xmm3
   20fb4:	66 0f c2 d8 01       	cmpltpd %xmm0,%xmm3
   20fb9:	66 0f 54 c3          	andpd  %xmm3,%xmm0
   20fbd:	66 41 0f 55 da       	andnpd %xmm10,%xmm3
   20fc2:	66 0f 56 d8          	orpd   %xmm0,%xmm3
   20fc6:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
   20fca:	66 0f c2 c1 01       	cmpltpd %xmm1,%xmm0
   20fcf:	66 0f 54 c8          	andpd  %xmm0,%xmm1
   20fd3:	66 41 0f 55 c2       	andnpd %xmm10,%xmm0
   20fd8:	66 0f 56 c1          	orpd   %xmm1,%xmm0
   20fdc:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   20fe0:	66 0f c2 ce 01       	cmpltpd %xmm6,%xmm1
   20fe5:	66 0f 54 f1          	andpd  %xmm1,%xmm6
   20fe9:	66 41 0f 55 ca       	andnpd %xmm10,%xmm1
   20fee:	66 0f 56 ce          	orpd   %xmm6,%xmm1
   20ff2:	66 0f 57 e4          	xorpd  %xmm4,%xmm4
   20ff6:	66 0f c2 e7 01       	cmpltpd %xmm7,%xmm4
   20ffb:	66 0f 54 fc          	andpd  %xmm4,%xmm7
   20fff:	66 41 0f 55 e2       	andnpd %xmm10,%xmm4
   21004:	66 0f 56 e7          	orpd   %xmm7,%xmm4
   21008:	66 0f 28 f3          	movapd %xmm3,%xmm6
   2100c:	66 0f 5d f1          	minpd  %xmm1,%xmm6
   21010:	66 0f 29 b4 24 e0 01 	movapd %xmm6,0x1e0(%rsp)
   21017:	00 00 
   21019:	66 0f 28 f0          	movapd %xmm0,%xmm6
   2101d:	66 0f 5d f4          	minpd  %xmm4,%xmm6
   21021:	66 0f 5f d9          	maxpd  %xmm1,%xmm3
   21025:	66 0f 5f c4          	maxpd  %xmm4,%xmm0
   21029:	66 0f 29 b4 24 f0 01 	movapd %xmm6,0x1f0(%rsp)
   21030:	00 00 
   21032:	66 0f 29 9c 24 00 02 	movapd %xmm3,0x200(%rsp)
   21039:	00 00 
   2103b:	66 0f 29 84 24 10 02 	movapd %xmm0,0x210(%rsp)
   21042:	00 00 
   21044:	66 0f 28 25 d4 40 fe 	movapd -0x1bf2c(%rip),%xmm4        # 5120 <std::thread::current::id::ID+0x44a8>
   2104b:	ff 
   2104c:	66 41 0f 28 cc       	movapd %xmm12,%xmm1
   21051:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
   21055:	66 0f c2 c8 04       	cmpneqpd %xmm0,%xmm1
   2105a:	66 41 0f 28 dc       	movapd %xmm12,%xmm3
   2105f:	66 0f 54 dc          	andpd  %xmm4,%xmm3
   21063:	66 41 0f 28 f0       	movapd %xmm8,%xmm6
   21068:	66 0f 54 f4          	andpd  %xmm4,%xmm6
   2106c:	66 0f 28 c1          	movapd %xmm1,%xmm0
   21070:	66 0f 54 c3          	andpd  %xmm3,%xmm0
   21074:	66 0f 55 ce          	andnpd %xmm6,%xmm1
   21078:	66 0f 56 c8          	orpd   %xmm0,%xmm1
   2107c:	66 0f 28 fd          	movapd %xmm5,%xmm7
   21080:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
   21084:	66 0f c2 f8 04       	cmpneqpd %xmm0,%xmm7
   21089:	66 45 0f 28 c1       	movapd %xmm9,%xmm8
   2108e:	66 44 0f c2 c0 04    	cmpneqpd %xmm0,%xmm8
   21094:	66 41 0f c2 c5 04    	cmpneqpd %xmm13,%xmm0
   2109a:	66 44 0f 54 ec       	andpd  %xmm4,%xmm13
   2109f:	66 44 0f 54 f4       	andpd  %xmm4,%xmm14
   210a4:	66 44 0f 28 d0       	movapd %xmm0,%xmm10
   210a9:	66 45 0f 54 d5       	andpd  %xmm13,%xmm10
   210ae:	66 41 0f 55 c6       	andnpd %xmm14,%xmm0
   210b3:	66 41 0f 56 c2       	orpd   %xmm10,%xmm0
   210b8:	66 44 0f 28 d5       	movapd %xmm5,%xmm10
   210bd:	66 44 0f 54 d4       	andpd  %xmm4,%xmm10
   210c2:	66 44 0f 54 d7       	andpd  %xmm7,%xmm10
   210c7:	66 0f 55 f9          	andnpd %xmm1,%xmm7
   210cb:	66 41 0f 56 fa       	orpd   %xmm10,%xmm7
   210d0:	66 44 0f 54 cc       	andpd  %xmm4,%xmm9
   210d5:	66 45 0f 54 c8       	andpd  %xmm8,%xmm9
   210da:	66 44 0f 55 c0       	andnpd %xmm0,%xmm8
   210df:	66 45 0f 56 c1       	orpd   %xmm9,%xmm8
   210e4:	66 0f 28 0d b4 40 fe 	movapd -0x1bf4c(%rip),%xmm1        # 51a0 <std::thread::current::id::ID+0x4528>
   210eb:	ff 
   210ec:	66 0f 5f f9          	maxpd  %xmm1,%xmm7
   210f0:	66 44 0f 5f c1       	maxpd  %xmm1,%xmm8
   210f5:	66 0f 5f de          	maxpd  %xmm6,%xmm3
   210f9:	66 45 0f 5f ee       	maxpd  %xmm14,%xmm13
   210fe:	66 0f 28 94 24 70 01 	movapd 0x170(%rsp),%xmm2
   21105:	00 00 
   21107:	66 0f 28 ca          	movapd %xmm2,%xmm1
   2110b:	66 0f 54 cc          	andpd  %xmm4,%xmm1
   2110f:	66 0f 5f d9          	maxpd  %xmm1,%xmm3
   21113:	66 0f 5e df          	divpd  %xmm7,%xmm3
   21117:	66 0f 28 b4 24 10 01 	movapd 0x110(%rsp),%xmm6
   2111e:	00 00 
   21120:	66 0f 54 e6          	andpd  %xmm6,%xmm4
   21124:	66 44 0f 5f ec       	maxpd  %xmm4,%xmm13
   21129:	66 45 0f 5e e8       	divpd  %xmm8,%xmm13
   2112e:	f2 0f 10 0d b2 5e fe 	movsd  -0x1a14e(%rip),%xmm1        # 6fe8 <std::thread::current::id::ID+0x6370>
   21135:	ff 
   21136:	66 0f 28 05 72 43 fe 	movapd -0x1bc8e(%rip),%xmm0        # 54b0 <std::thread::current::id::ID+0x4838>
   2113d:	ff 
   2113e:	66 0f 58 d8          	addpd  %xmm0,%xmm3
   21142:	66 44 0f 58 e8       	addpd  %xmm0,%xmm13
   21147:	66 0f c2 c8 00       	cmpeqpd %xmm0,%xmm1
   2114c:	66 0f c2 c0 00       	cmpeqpd %xmm0,%xmm0
   21151:	66 0f 54 d8          	andpd  %xmm0,%xmm3
   21155:	66 0f 28 25 53 43 fe 	movapd -0x1bcad(%rip),%xmm4        # 54b0 <std::thread::current::id::ID+0x4838>
   2115c:	ff 
   2115d:	66 0f 55 c4          	andnpd %xmm4,%xmm0
   21161:	66 0f 56 c3          	orpd   %xmm3,%xmm0
   21165:	66 44 0f 54 e9       	andpd  %xmm1,%xmm13
   2116a:	66 0f 55 cc          	andnpd %xmm4,%xmm1
   2116e:	66 41 0f 56 cd       	orpd   %xmm13,%xmm1
   21173:	66 41 0f 57 d7       	xorpd  %xmm15,%xmm2
   21178:	66 0f 29 94 24 a0 00 	movapd %xmm2,0xa0(%rsp)
   2117f:	00 00 
   21181:	66 44 0f 57 fe       	xorpd  %xmm6,%xmm15
   21186:	66 44 0f 29 bc 24 b0 	movapd %xmm15,0xb0(%rsp)
   2118d:	00 00 00 
   21190:	48 8d bc 24 c0 00 00 	lea    0xc0(%rsp),%rdi
   21197:	00 
   21198:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
   2119d:	48 8d 94 24 e0 01 00 	lea    0x1e0(%rsp),%rdx
   211a4:	00 
   211a5:	b9 60 00 00 00       	mov    $0x60,%ecx
   211aa:	e8 c1 e9 ff ff       	call   1fb70 <gpui_canvas::color::gamut::first_exit::<fearless_simd::generated::sse2::Sse2>>
   211af:	f2 0f 10 84 24 c0 00 	movsd  0xc0(%rsp),%xmm0
   211b6:	00 00 
   211b8:	f2 0f 10 8c 24 c8 00 	movsd  0xc8(%rsp),%xmm1
   211bf:	00 00 
   211c1:	f2 0f 10 9c 24 d0 00 	movsd  0xd0(%rsp),%xmm3
   211c8:	00 00 
   211ca:	f2 0f 5d 05 de 5d fe 	minsd  -0x1a222(%rip),%xmm0        # 6fb0 <std::thread::current::id::ID+0x6338>
   211d1:	ff 
   211d2:	f2 0f 5d c8          	minsd  %xmm0,%xmm1
   211d6:	f2 0f 5d d9          	minsd  %xmm1,%xmm3
   211da:	66 48 0f 7e d8       	movq   %xmm3,%rax
   211df:	49 bf ff ff ff ff ff 	movabs $0x7fffffffffffffff,%r15
   211e6:	ff ff 7f 
   211e9:	4c 21 f8             	and    %r15,%rax
   211ec:	41 be 0e 00 00 00    	mov    $0xe,%r14d
   211f2:	48 b9 ff ff ff ff ff 	movabs $0x7fefffffffffffff,%rcx
   211f9:	ff ef 7f 
   211fc:	48 39 c8             	cmp    %rcx,%rax
   211ff:	0f 8f 72 02 00 00    	jg     21477 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xbf7>
   21205:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
   2120b:	0f 57 c9             	xorps  %xmm1,%xmm1
   2120e:	f3 0f 5a c8          	cvtss2sd %xmm0,%xmm1
   21212:	f2 0f 11 4c 24 20    	movsd  %xmm1,0x20(%rsp)
   21218:	0f 28 c1             	movaps %xmm1,%xmm0
   2121b:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   2121f:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   21223:	f2 0f 10 0d bd 5d fe 	movsd  -0x1a243(%rip),%xmm1        # 6fe8 <std::thread::current::id::ID+0x6370>
   2122a:	ff 
   2122b:	f2 0f 5e c8          	divsd  %xmm0,%xmm1
   2122f:	66 0f 14 c9          	unpcklpd %xmm1,%xmm1
   21233:	66 0f 28 84 24 70 01 	movapd 0x170(%rsp),%xmm0
   2123a:	00 00 
   2123c:	66 0f 5c c1          	subpd  %xmm1,%xmm0
   21240:	66 0f 29 84 24 a0 00 	movapd %xmm0,0xa0(%rsp)
   21247:	00 00 
   21249:	66 0f 28 94 24 10 01 	movapd 0x110(%rsp),%xmm2
   21250:	00 00 
   21252:	66 0f 5c d1          	subpd  %xmm1,%xmm2
   21256:	0f 28 84 24 60 01 00 	movaps 0x160(%rsp),%xmm0
   2125d:	00 
   2125e:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
   21263:	0f 28 44 24 30       	movaps 0x30(%rsp),%xmm0
   21268:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
   2126d:	0f 28 84 24 40 01 00 	movaps 0x140(%rsp),%xmm0
   21274:	00 
   21275:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
   2127a:	0f 28 84 24 50 01 00 	movaps 0x150(%rsp),%xmm0
   21281:	00 
   21282:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
   21287:	0f 28 84 24 20 01 00 	movaps 0x120(%rsp),%xmm0
   2128e:	00 
   2128f:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
   21296:	00 
   21297:	0f 28 84 24 30 01 00 	movaps 0x130(%rsp),%xmm0
   2129e:	00 
   2129f:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
   212a6:	00 
   212a7:	66 0f 29 94 24 b0 00 	movapd %xmm2,0xb0(%rsp)
   212ae:	00 00 
   212b0:	66 0f 28 c3          	movapd %xmm3,%xmm0
   212b4:	66 0f 14 c3          	unpcklpd %xmm3,%xmm0
   212b8:	48 8d bc 24 c0 00 00 	lea    0xc0(%rsp),%rdi
   212bf:	00 
   212c0:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
   212c5:	48 8d 94 24 e0 01 00 	lea    0x1e0(%rsp),%rdx
   212cc:	00 
   212cd:	b9 40 00 00 00       	mov    $0x40,%ecx
   212d2:	66 0f 28 c8          	movapd %xmm0,%xmm1
   212d6:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
   212db:	e8 90 e8 ff ff       	call   1fb70 <gpui_canvas::color::gamut::first_exit::<fearless_simd::generated::sse2::Sse2>>
   212e0:	66 0f 28 54 24 30    	movapd 0x30(%rsp),%xmm2
   212e6:	66 0f 28 c2          	movapd %xmm2,%xmm0
   212ea:	f2 0f 5d 84 24 c0 00 	minsd  0xc0(%rsp),%xmm0
   212f1:	00 00 
   212f3:	66 0f 28 c8          	movapd %xmm0,%xmm1
   212f7:	f2 0f c2 c8 03       	cmpunordsd %xmm0,%xmm1
   212fc:	66 0f 54 d1          	andpd  %xmm1,%xmm2
   21300:	66 0f 55 c8          	andnpd %xmm0,%xmm1
   21304:	66 0f 56 ca          	orpd   %xmm2,%xmm1
   21308:	f2 0f 10 84 24 c8 00 	movsd  0xc8(%rsp),%xmm0
   2130f:	00 00 
   21311:	66 0f 28 d1          	movapd %xmm1,%xmm2
   21315:	f2 0f 5d d0          	minsd  %xmm0,%xmm2
   21319:	66 0f 28 da          	movapd %xmm2,%xmm3
   2131d:	f2 0f c2 da 03       	cmpunordsd %xmm2,%xmm3
   21322:	66 0f 54 cb          	andpd  %xmm3,%xmm1
   21326:	66 0f 55 da          	andnpd %xmm2,%xmm3
   2132a:	66 0f 56 d9          	orpd   %xmm1,%xmm3
   2132e:	f2 0f 10 84 24 d0 00 	movsd  0xd0(%rsp),%xmm0
   21335:	00 00 
   21337:	66 0f 28 cb          	movapd %xmm3,%xmm1
   2133b:	f2 0f 5d c8          	minsd  %xmm0,%xmm1
   2133f:	66 0f 28 c1          	movapd %xmm1,%xmm0
   21343:	f2 0f c2 c1 03       	cmpunordsd %xmm1,%xmm0
   21348:	66 0f 54 d8          	andpd  %xmm0,%xmm3
   2134c:	66 0f 55 c1          	andnpd %xmm1,%xmm0
   21350:	66 0f 56 c3          	orpd   %xmm3,%xmm0
   21354:	f2 0f 59 44 24 20    	mulsd  0x20(%rsp),%xmm0
   2135a:	66 48 0f 7e c0       	movq   %xmm0,%rax
   2135f:	48 85 c0             	test   %rax,%rax
   21362:	0f 98 c1             	sets   %cl
   21365:	49 21 c7             	and    %rax,%r15
   21368:	48 b8 00 00 00 00 00 	movabs $0xfff0000000000000,%rax
   2136f:	00 f0 ff 
   21372:	4c 01 f8             	add    %r15,%rax
   21375:	48 c1 e8 35          	shr    $0x35,%rax
   21379:	3d ff 03 00 00       	cmp    $0x3ff,%eax
   2137e:	0f 92 c0             	setb   %al
   21381:	20 c8                	and    %cl,%al
   21383:	49 8d 57 ff          	lea    -0x1(%r15),%rdx
   21387:	48 be ff ff ff ff ff 	movabs $0xfffffffffffff,%rsi
   2138e:	ff 0f 00 
   21391:	48 39 f2             	cmp    %rsi,%rdx
   21394:	0f 92 c2             	setb   %dl
   21397:	20 ca                	and    %cl,%dl
   21399:	48 b9 00 00 00 00 00 	movabs $0x7ff0000000000000,%rcx
   213a0:	00 f0 7f 
   213a3:	49 39 cf             	cmp    %rcx,%r15
   213a6:	0f 9f c1             	setg   %cl
   213a9:	40 0f 94 c6          	sete   %sil
   213ad:	40 08 ce             	or     %cl,%sil
   213b0:	40 08 d6             	or     %dl,%sil
   213b3:	40 08 c6             	or     %al,%sil
   213b6:	0f 85 bb 00 00 00    	jne    21477 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xbf7>
   213bc:	0f 57 c9             	xorps  %xmm1,%xmm1
   213bf:	f2 0f 5a c8          	cvtsd2ss %xmm0,%xmm1
   213c3:	0f 28 84 24 f0 00 00 	movaps 0xf0(%rsp),%xmm0
   213ca:	00 
   213cb:	0f 56 05 de 41 fe ff 	orps   -0x1be22(%rip),%xmm0        # 55b0 <std::thread::current::id::ID+0x4938>
   213d2:	0f 29 84 24 f0 00 00 	movaps %xmm0,0xf0(%rsp)
   213d9:	00 
   213da:	41 bc 40 00 00 00    	mov    $0x40,%r12d
   213e0:	0f b6 db             	movzbl %bl,%ebx
   213e3:	4c 8d 7c 24 40       	lea    0x40(%rsp),%r15
   213e8:	eb 17                	jmp    21401 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xb81>
   213ea:	41 bd 01 00 00 80    	mov    $0x80000001,%r13d
   213f0:	66 41 0f 6e cd       	movd   %r13d,%xmm1
   213f5:	0f 57 c0             	xorps  %xmm0,%xmm0
   213f8:	f3 0f 5f c8          	maxss  %xmm0,%xmm1
   213fc:	41 ff cc             	dec    %r12d
   213ff:	74 76                	je     21477 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xbf7>
   21401:	66 41 0f 7e cd       	movd   %xmm1,%r13d
   21406:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
   2140c:	f3 0f 11 44 24 40    	movss  %xmm0,0x40(%rsp)
   21412:	f3 0f 11 4c 24 20    	movss  %xmm1,0x20(%rsp)
   21418:	f3 0f 11 4c 24 44    	movss  %xmm1,0x44(%rsp)
   2141e:	0f 28 84 24 f0 00 00 	movaps 0xf0(%rsp),%xmm0
   21425:	00 
   21426:	f3 0f 11 44 24 48    	movss  %xmm0,0x48(%rsp)
   2142c:	c7 44 24 4c 00 00 80 	movl   $0xff800000,0x4c(%rsp)
   21433:	ff 
   21434:	4c 89 ff             	mov    %r15,%rdi
   21437:	89 de                	mov    %ebx,%esi
   21439:	e8 52 00 00 00       	call   21490 <gpui_canvas::color::gamut::in_gamut>
   2143e:	84 c0                	test   %al,%al
   21440:	75 28                	jne    2146a <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xbea>
   21442:	41 81 fd 00 00 80 ff 	cmp    $0xff800000,%r13d
   21449:	66 0f 6e 4c 24 20    	movd   0x20(%rsp),%xmm1
   2144f:	74 a4                	je     213f5 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xb75>
   21451:	44 89 e8             	mov    %r13d,%eax
   21454:	25 ff ff ff 7f       	and    $0x7fffffff,%eax
   21459:	74 8f                	je     213ea <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xb6a>
   2145b:	41 39 c5             	cmp    %eax,%r13d
   2145e:	75 05                	jne    21465 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xbe5>
   21460:	41 ff cd             	dec    %r13d
   21463:	eb 8b                	jmp    213f0 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xb70>
   21465:	41 ff c5             	inc    %r13d
   21468:	eb 86                	jmp    213f0 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xb70>
   2146a:	49 c1 e5 20          	shl    $0x20,%r13
   2146e:	41 be ff ff ff ff    	mov    $0xffffffff,%r14d
   21474:	4d 09 ee             	or     %r13,%r14
   21477:	4c 89 f0             	mov    %r14,%rax
   2147a:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
   2147e:	5b                   	pop    %rbx
   2147f:	41 5c                	pop    %r12
   21481:	41 5d                	pop    %r13
   21483:	41 5e                	pop    %r14
   21485:	41 5f                	pop    %r15
   21487:	5d                   	pop    %rbp
   21488:	c3                   	ret
   21489:	cc                   	int3
   2148a:	cc                   	int3
   2148b:	cc                   	int3
   2148c:	cc                   	int3
   2148d:	cc                   	int3
   2148e:	cc                   	int3
   2148f:	cc                   	int3

gpui_canvas::color::gamut::in_gamut:
   21490:	55                   	push   %rbp
   21491:	53                   	push   %rbx
   21492:	48 83 ec 68          	sub    $0x68,%rsp
   21496:	89 f3                	mov    %esi,%ebx
   21498:	f3 0f 7e 0f          	movq   (%rdi),%xmm1
   2149c:	8b 4f 08             	mov    0x8(%rdi),%ecx
   2149f:	8b 57 0c             	mov    0xc(%rdi),%edx
   214a2:	89 c8                	mov    %ecx,%eax
   214a4:	81 fa 00 00 00 c0    	cmp    $0xc0000000,%edx
   214aa:	0f 82 ea 00 00 00    	jb     2159a <gpui_canvas::color::gamut::in_gamut+0x10a>
   214b0:	89 c8                	mov    %ecx,%eax
   214b2:	85 c9                	test   %ecx,%ecx
   214b4:	0f 88 db 00 00 00    	js     21595 <gpui_canvas::color::gamut::in_gamut+0x105>
   214ba:	c1 e8 08             	shr    $0x8,%eax
   214bd:	89 ce                	mov    %ecx,%esi
   214bf:	48 69 f6 8f e7 54 52 	imul   $0x5254e78f,%rsi,%rsi
   214c6:	48 c1 ee 2e          	shr    $0x2e,%rsi
   214ca:	48 69 f8 09 a8 a7 01 	imul   $0x1a7a809,%rax,%rdi
   214d1:	48 c1 ef 20          	shr    $0x20,%rdi
   214d5:	66 41 0f 7e c9       	movd   %xmm1,%r9d
   214da:	45 89 ca             	mov    %r9d,%r10d
   214dd:	41 c1 e2 08          	shl    $0x8,%r10d
   214e1:	66 0f 70 c1 55       	pshufd $0x55,%xmm1,%xmm0
   214e6:	66 41 0f 7e c0       	movd   %xmm0,%r8d
   214eb:	45 89 c3             	mov    %r8d,%r11d
   214ee:	45 0f a4 cb 08       	shld   $0x8,%r9d,%r11d
   214f3:	69 ee 55 52 00 00    	imul   $0x5255,%esi,%ebp
   214f9:	c1 ed 16             	shr    $0x16,%ebp
   214fc:	69 ed c7 00 00 00    	imul   $0xc7,%ebp,%ebp
   21502:	29 ee                	sub    %ebp,%esi
   21504:	44 89 dd             	mov    %r11d,%ebp
   21507:	c1 e5 08             	shl    $0x8,%ebp
   2150a:	41 81 e3 ff ff 7f 00 	and    $0x7fffff,%r11d
   21511:	41 81 e2 00 00 00 80 	and    $0x80000000,%r10d
   21518:	81 e5 00 00 00 80    	and    $0x80000000,%ebp
   2151e:	44 09 dd             	or     %r11d,%ebp
   21521:	41 81 e1 ff ff 7f 00 	and    $0x7fffff,%r9d
   21528:	45 09 d1             	or     %r10d,%r9d
   2152b:	c1 e6 17             	shl    $0x17,%esi
   2152e:	09 ee                	or     %ebp,%esi
   21530:	c1 e7 0f             	shl    $0xf,%edi
   21533:	81 e7 00 00 80 ff    	and    $0xff800000,%edi
   21539:	41 0f ac c8 10       	shrd   $0x10,%ecx,%r8d
   2153e:	44 09 cf             	or     %r9d,%edi
   21541:	4c 69 c8 9f 53 49 01 	imul   $0x149539f,%rax,%r9
   21548:	49 c1 e9 20          	shr    $0x20,%r9
   2154c:	45 69 c9 c7 00 00 00 	imul   $0xc7,%r9d,%r9d
   21553:	44 29 c8             	sub    %r9d,%eax
   21556:	45 89 c1             	mov    %r8d,%r9d
   21559:	41 81 e1 ff ff 7f 00 	and    $0x7fffff,%r9d
   21560:	41 c1 e0 08          	shl    $0x8,%r8d
   21564:	41 81 e0 00 00 00 80 	and    $0x80000000,%r8d
   2156b:	45 09 c8             	or     %r9d,%r8d
   2156e:	c1 e0 17             	shl    $0x17,%eax
   21571:	44 09 c0             	or     %r8d,%eax
   21574:	66 0f 6e c6          	movd   %esi,%xmm0
   21578:	66 0f 6e cf          	movd   %edi,%xmm1
   2157c:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
   21580:	c1 ea 1e             	shr    $0x1e,%edx
   21583:	31 ed                	xor    %ebp,%ebp
   21585:	48 8d 35 58 5d fe ff 	lea    -0x1a2a8(%rip),%rsi        # 72e4 <std::thread::current::id::ID+0x666c>
   2158c:	48 63 14 96          	movslq (%rsi,%rdx,4),%rdx
   21590:	48 01 f2             	add    %rsi,%rdx
   21593:	ff e2                	jmp    *%rdx
   21595:	25 ff ff ff 7f       	and    $0x7fffffff,%eax
   2159a:	c1 ea 1e             	shr    $0x1e,%edx
   2159d:	31 ed                	xor    %ebp,%ebp
   2159f:	48 8d 35 3e 5d fe ff 	lea    -0x1a2c2(%rip),%rsi        # 72e4 <std::thread::current::id::ID+0x666c>
   215a6:	48 63 14 96          	movslq (%rsi,%rdx,4),%rdx
   215aa:	48 01 f2             	add    %rsi,%rdx
   215ad:	ff e2                	jmp    *%rdx
   215af:	40 b5 01             	mov    $0x1,%bpl
   215b2:	f3 0f 5a e9          	cvtss2sd %xmm1,%xmm5
   215b6:	66 0f 70 f1 55       	pshufd $0x55,%xmm1,%xmm6
   215bb:	f3 0f 5a e6          	cvtss2sd %xmm6,%xmm4
   215bf:	66 0f 6e d0          	movd   %eax,%xmm2
   215c3:	0f 28 05 56 3b fe ff 	movaps -0x1c4aa(%rip),%xmm0        # 5120 <std::thread::current::id::ID+0x44a8>
   215ca:	0f 54 c5             	andps  %xmm5,%xmm0
   215cd:	f2 0f 10 1d eb 59 fe 	movsd  -0x1a615(%rip),%xmm3        # 6fc0 <std::thread::current::id::ID+0x6348>
   215d4:	ff 
   215d5:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   215d9:	66 0f 7e 54 24 30    	movd   %xmm2,0x30(%rsp)
   215df:	73 53                	jae    21634 <gpui_canvas::color::gamut::in_gamut+0x1a4>
   215e1:	0f 2e c9             	ucomiss %xmm1,%xmm1
   215e4:	0f 29 64 24 10       	movaps %xmm4,0x10(%rsp)
   215e9:	0f 29 74 24 50       	movaps %xmm6,0x50(%rsp)
   215ee:	7a 4e                	jp     2163e <gpui_canvas::color::gamut::in_gamut+0x1ae>
   215f0:	0f 54 2d 79 3f fe ff 	andps  -0x1c087(%rip),%xmm5        # 5570 <std::thread::current::id::ID+0x48f8>
   215f7:	0f 56 2d b2 3e fe ff 	orps   -0x1c14e(%rip),%xmm5        # 54b0 <std::thread::current::id::ID+0x4838>
   215fe:	0f 29 2c 24          	movaps %xmm5,(%rsp)
   21602:	eb 46                	jmp    2164a <gpui_canvas::color::gamut::in_gamut+0x1ba>
   21604:	0f 5a e9             	cvtps2pd %xmm1,%xmm5
   21607:	66 0f 6e c0          	movd   %eax,%xmm0
   2160b:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   2160f:	e9 ad 01 00 00       	jmp    217c1 <gpui_canvas::color::gamut::in_gamut+0x331>
   21614:	85 c9                	test   %ecx,%ecx
   21616:	0f 88 86 02 00 00    	js     218a2 <gpui_canvas::color::gamut::in_gamut+0x412>
   2161c:	0f 5a e9             	cvtps2pd %xmm1,%xmm5
   2161f:	66 0f 6e c0          	movd   %eax,%xmm0
   21623:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   21627:	84 db                	test   %bl,%bl
   21629:	0f 84 5e 02 00 00    	je     2188d <gpui_canvas::color::gamut::in_gamut+0x3fd>
   2162f:	e9 a7 02 00 00       	jmp    218db <gpui_canvas::color::gamut::in_gamut+0x44b>
   21634:	f2 0f 5e 2d 24 59 fe 	divsd  -0x1a6dc(%rip),%xmm5        # 6f60 <std::thread::current::id::ID+0x62e8>
   2163b:	ff 
   2163c:	eb 4b                	jmp    21689 <gpui_canvas::color::gamut::in_gamut+0x1f9>
   2163e:	f2 0f 10 0d 0a 5a fe 	movsd  -0x1a5f6(%rip),%xmm1        # 7050 <std::thread::current::id::ID+0x63d8>
   21645:	ff 
   21646:	0f 29 0c 24          	movaps %xmm1,(%rsp)
   2164a:	f2 0f 58 05 7e 5a fe 	addsd  -0x1a582(%rip),%xmm0        # 70d0 <std::thread::current::id::ID+0x6458>
   21651:	ff 
   21652:	f2 0f 5e 05 16 5a fe 	divsd  -0x1a5ea(%rip),%xmm0        # 7070 <std::thread::current::id::ID+0x63f8>
   21659:	ff 
   2165a:	f2 0f 10 0d b6 59 fe 	movsd  -0x1a64a(%rip),%xmm1        # 7018 <std::thread::current::id::ID+0x63a0>
   21661:	ff 
   21662:	ff 15 50 22 04 00    	call   *0x42250(%rip)        # 638b8 <pow@GLIBC_2.29>
   21668:	66 0f 28 e8          	movapd %xmm0,%xmm5
   2166c:	f2 0f 59 2c 24       	mulsd  (%rsp),%xmm5
   21671:	66 0f 6e 54 24 30    	movd   0x30(%rsp),%xmm2
   21677:	f2 0f 10 1d 41 59 fe 	movsd  -0x1a6bf(%rip),%xmm3        # 6fc0 <std::thread::current::id::ID+0x6348>
   2167e:	ff 
   2167f:	0f 28 64 24 10       	movaps 0x10(%rsp),%xmm4
   21684:	0f 28 74 24 50       	movaps 0x50(%rsp),%xmm6
   21689:	0f 57 c9             	xorps  %xmm1,%xmm1
   2168c:	f3 0f 5a ca          	cvtss2sd %xmm2,%xmm1
   21690:	0f 28 05 89 3a fe ff 	movaps -0x1c577(%rip),%xmm0        # 5120 <std::thread::current::id::ID+0x44a8>
   21697:	0f 54 c4             	andps  %xmm4,%xmm0
   2169a:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   2169e:	66 0f 29 2c 24       	movapd %xmm5,(%rsp)
   216a3:	73 1f                	jae    216c4 <gpui_canvas::color::gamut::in_gamut+0x234>
   216a5:	0f 2e f6             	ucomiss %xmm6,%xmm6
   216a8:	0f 29 4c 24 20       	movaps %xmm1,0x20(%rsp)
   216ad:	7a 4b                	jp     216fa <gpui_canvas::color::gamut::in_gamut+0x26a>
   216af:	0f 54 25 ba 3e fe ff 	andps  -0x1c146(%rip),%xmm4        # 5570 <std::thread::current::id::ID+0x48f8>
   216b6:	0f 56 25 f3 3d fe ff 	orps   -0x1c20d(%rip),%xmm4        # 54b0 <std::thread::current::id::ID+0x4838>
   216bd:	0f 29 64 24 10       	movaps %xmm4,0x10(%rsp)
   216c2:	eb 43                	jmp    21707 <gpui_canvas::color::gamut::in_gamut+0x277>
   216c4:	f2 0f 5e 25 94 58 fe 	divsd  -0x1a76c(%rip),%xmm4        # 6f60 <std::thread::current::id::ID+0x62e8>
   216cb:	ff 
   216cc:	0f 28 05 4d 3a fe ff 	movaps -0x1c5b3(%rip),%xmm0        # 5120 <std::thread::current::id::ID+0x44a8>
   216d3:	0f 54 c1             	andps  %xmm1,%xmm0
   216d6:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   216da:	72 7e                	jb     2175a <gpui_canvas::color::gamut::in_gamut+0x2ca>
   216dc:	f2 0f 5e 0d 7c 58 fe 	divsd  -0x1a784(%rip),%xmm1        # 6f60 <std::thread::current::id::ID+0x62e8>
   216e3:	ff 
   216e4:	66 0f 28 c1          	movapd %xmm1,%xmm0
   216e8:	66 0f 14 ec          	unpcklpd %xmm4,%xmm5
   216ec:	40 84 ed             	test   %bpl,%bpl
   216ef:	0f 85 cc 00 00 00    	jne    217c1 <gpui_canvas::color::gamut::in_gamut+0x331>
   216f5:	e9 8f 01 00 00       	jmp    21889 <gpui_canvas::color::gamut::in_gamut+0x3f9>
   216fa:	f2 0f 10 0d 4e 59 fe 	movsd  -0x1a6b2(%rip),%xmm1        # 7050 <std::thread::current::id::ID+0x63d8>
   21701:	ff 
   21702:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
   21707:	f2 0f 58 05 c1 59 fe 	addsd  -0x1a63f(%rip),%xmm0        # 70d0 <std::thread::current::id::ID+0x6458>
   2170e:	ff 
   2170f:	f2 0f 5e 05 59 59 fe 	divsd  -0x1a6a7(%rip),%xmm0        # 7070 <std::thread::current::id::ID+0x63f8>
   21716:	ff 
   21717:	f2 0f 10 0d f9 58 fe 	movsd  -0x1a707(%rip),%xmm1        # 7018 <std::thread::current::id::ID+0x63a0>
   2171e:	ff 
   2171f:	ff 15 93 21 04 00    	call   *0x42193(%rip)        # 638b8 <pow@GLIBC_2.29>
   21725:	66 0f 28 e0          	movapd %xmm0,%xmm4
   21729:	f2 0f 59 64 24 10    	mulsd  0x10(%rsp),%xmm4
   2172f:	66 0f 28 2c 24       	movapd (%rsp),%xmm5
   21734:	f3 0f 10 54 24 30    	movss  0x30(%rsp),%xmm2
   2173a:	f2 0f 10 1d 7e 58 fe 	movsd  -0x1a782(%rip),%xmm3        # 6fc0 <std::thread::current::id::ID+0x6348>
   21741:	ff 
   21742:	66 0f 28 4c 24 20    	movapd 0x20(%rsp),%xmm1
   21748:	66 0f 28 05 d0 39 fe 	movapd -0x1c630(%rip),%xmm0        # 5120 <std::thread::current::id::ID+0x44a8>
   2174f:	ff 
   21750:	66 0f 54 c1          	andpd  %xmm1,%xmm0
   21754:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   21758:	73 82                	jae    216dc <gpui_canvas::color::gamut::in_gamut+0x24c>
   2175a:	0f 2e d2             	ucomiss %xmm2,%xmm2
   2175d:	66 0f 29 64 24 10    	movapd %xmm4,0x10(%rsp)
   21763:	7a 12                	jp     21777 <gpui_canvas::color::gamut::in_gamut+0x2e7>
   21765:	66 0f 54 0d 03 3e fe 	andpd  -0x1c1fd(%rip),%xmm1        # 5570 <std::thread::current::id::ID+0x48f8>
   2176c:	ff 
   2176d:	66 0f 56 0d 3b 3d fe 	orpd   -0x1c2c5(%rip),%xmm1        # 54b0 <std::thread::current::id::ID+0x4838>
   21774:	ff 
   21775:	eb 08                	jmp    2177f <gpui_canvas::color::gamut::in_gamut+0x2ef>
   21777:	f2 0f 10 0d d1 58 fe 	movsd  -0x1a72f(%rip),%xmm1        # 7050 <std::thread::current::id::ID+0x63d8>
   2177e:	ff 
   2177f:	66 0f 29 4c 24 20    	movapd %xmm1,0x20(%rsp)
   21785:	f2 0f 58 05 43 59 fe 	addsd  -0x1a6bd(%rip),%xmm0        # 70d0 <std::thread::current::id::ID+0x6458>
   2178c:	ff 
   2178d:	f2 0f 5e 05 db 58 fe 	divsd  -0x1a725(%rip),%xmm0        # 7070 <std::thread::current::id::ID+0x63f8>
   21794:	ff 
   21795:	f2 0f 10 0d 7b 58 fe 	movsd  -0x1a785(%rip),%xmm1        # 7018 <std::thread::current::id::ID+0x63a0>
   2179c:	ff 
   2179d:	ff 15 15 21 04 00    	call   *0x42115(%rip)        # 638b8 <pow@GLIBC_2.29>
   217a3:	f2 0f 59 44 24 20    	mulsd  0x20(%rsp),%xmm0
   217a9:	66 0f 28 2c 24       	movapd (%rsp),%xmm5
   217ae:	66 0f 28 64 24 10    	movapd 0x10(%rsp),%xmm4
   217b4:	66 0f 14 ec          	unpcklpd %xmm4,%xmm5
   217b8:	40 84 ed             	test   %bpl,%bpl
   217bb:	0f 84 c8 00 00 00    	je     21889 <gpui_canvas::color::gamut::in_gamut+0x3f9>
   217c1:	66 0f 28 d5          	movapd %xmm5,%xmm2
   217c5:	66 0f c6 d5 01       	shufpd $0x1,%xmm5,%xmm2
   217ca:	66 0f 59 15 ee 3c fe 	mulpd  -0x1c312(%rip),%xmm2        # 54c0 <std::thread::current::id::ID+0x4848>
   217d1:	ff 
   217d2:	66 0f 57 db          	xorpd  %xmm3,%xmm3
   217d6:	66 0f 16 1d da 58 fe 	movhpd -0x1a726(%rip),%xmm3        # 70b8 <std::thread::current::id::ID+0x6440>
   217dd:	ff 
   217de:	66 0f 59 dd          	mulpd  %xmm5,%xmm3
   217e2:	0f 28 c8             	movaps %xmm0,%xmm1
   217e5:	0f 16 c8             	movlhps %xmm0,%xmm1
   217e8:	66 0f 59 0d 40 39 fe 	mulpd  -0x1c6c0(%rip),%xmm1        # 5130 <std::thread::current::id::ID+0x44b8>
   217ef:	ff 
   217f0:	66 0f 58 da          	addpd  %xmm2,%xmm3
   217f4:	66 0f 58 cb          	addpd  %xmm3,%xmm1
   217f8:	f2 0f 10 15 98 57 fe 	movsd  -0x1a868(%rip),%xmm2        # 6f98 <std::thread::current::id::ID+0x6320>
   217ff:	ff 
   21800:	f2 0f 59 d5          	mulsd  %xmm5,%xmm2
   21804:	f2 0f 10 e8          	movsd  %xmm0,%xmm5
   21808:	66 0f 59 2d 40 39 fe 	mulpd  -0x1c6c0(%rip),%xmm5        # 5150 <std::thread::current::id::ID+0x44d8>
   2180f:	ff 
   21810:	66 0f 28 c5          	movapd %xmm5,%xmm0
   21814:	66 0f 15 c5          	unpckhpd %xmm5,%xmm0
   21818:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   2181c:	f2 0f 58 c5          	addsd  %xmm5,%xmm0
   21820:	f2 0f 10 15 48 57 fe 	movsd  -0x1a8b8(%rip),%xmm2        # 6f70 <std::thread::current::id::ID+0x62f8>
   21827:	ff 
   21828:	66 0f 28 d9          	movapd %xmm1,%xmm3
   2182c:	f2 0f 10 d8          	movsd  %xmm0,%xmm3
   21830:	66 0f 59 1d 68 3b fe 	mulpd  -0x1c498(%rip),%xmm3        # 53a0 <std::thread::current::id::ID+0x4728>
   21837:	ff 
   21838:	66 0f 28 e1          	movapd %xmm1,%xmm4
   2183c:	66 0f c6 e0 01       	shufpd $0x1,%xmm0,%xmm4
   21841:	66 0f 59 25 c7 3a fe 	mulpd  -0x1c539(%rip),%xmm4        # 5310 <std::thread::current::id::ID+0x4698>
   21848:	ff 
   21849:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
   2184d:	66 0f 58 e3          	addpd  %xmm3,%xmm4
   21851:	66 0f 28 e9          	movapd %xmm1,%xmm5
   21855:	66 0f 14 e9          	unpcklpd %xmm1,%xmm5
   21859:	66 0f 59 2d 1f 3d fe 	mulpd  -0x1c2e1(%rip),%xmm5        # 5580 <std::thread::current::id::ID+0x4908>
   21860:	ff 
   21861:	66 0f 28 c4          	movapd %xmm4,%xmm0
   21865:	66 0f 5c c5          	subpd  %xmm5,%xmm0
   21869:	66 0f 58 ec          	addpd  %xmm4,%xmm5
   2186d:	f2 0f 10 e8          	movsd  %xmm0,%xmm5
   21871:	66 0f 59 0d 07 3b fe 	mulpd  -0x1c4f9(%rip),%xmm1        # 5380 <std::thread::current::id::ID+0x4708>
   21878:	ff 
   21879:	66 0f 28 c1          	movapd %xmm1,%xmm0
   2187d:	66 0f 15 c1          	unpckhpd %xmm1,%xmm0
   21881:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   21885:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
   21889:	84 db                	test   %bl,%bl
   2188b:	75 4e                	jne    218db <gpui_canvas::color::gamut::in_gamut+0x44b>
   2188d:	31 c0                	xor    %eax,%eax
   2188f:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   21893:	66 0f 2e e9          	ucomisd %xmm1,%xmm5
   21897:	0f 83 08 01 00 00    	jae    219a5 <gpui_canvas::color::gamut::in_gamut+0x515>
   2189d:	e9 41 01 00 00       	jmp    219e3 <gpui_canvas::color::gamut::in_gamut+0x553>
   218a2:	66 0f 6f d1          	movdqa %xmm1,%xmm2
   218a6:	0f c6 c9 55          	shufps $0x55,%xmm1,%xmm1
   218aa:	66 0f ef c0          	pxor   %xmm0,%xmm0
   218ae:	0f 2e c8             	ucomiss %xmm0,%xmm1
   218b1:	0f 85 35 01 00 00    	jne    219ec <gpui_canvas::color::gamut::in_gamut+0x55c>
   218b7:	0f 8a 2f 01 00 00    	jp     219ec <gpui_canvas::color::gamut::in_gamut+0x55c>
   218bd:	0f 57 c9             	xorps  %xmm1,%xmm1
   218c0:	f3 0f 5a ca          	cvtss2sd %xmm2,%xmm1
   218c4:	0f 28 c1             	movaps %xmm1,%xmm0
   218c7:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   218cb:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   218cf:	66 0f 28 e8          	movapd %xmm0,%xmm5
   218d3:	66 0f 14 e8          	unpcklpd %xmm0,%xmm5
   218d7:	84 db                	test   %bl,%bl
   218d9:	74 b2                	je     2188d <gpui_canvas::color::gamut::in_gamut+0x3fd>
   218db:	66 0f 28 0d cd 38 fe 	movapd -0x1c733(%rip),%xmm1        # 51b0 <std::thread::current::id::ID+0x4538>
   218e2:	ff 
   218e3:	66 0f 59 cd          	mulpd  %xmm5,%xmm1
   218e7:	66 0f 28 d5          	movapd %xmm5,%xmm2
   218eb:	66 0f c6 d5 01       	shufpd $0x1,%xmm5,%xmm2
   218f0:	66 0f 59 15 18 3c fe 	mulpd  -0x1c3e8(%rip),%xmm2        # 5510 <std::thread::current::id::ID+0x4898>
   218f7:	ff 
   218f8:	66 0f 58 d1          	addpd  %xmm1,%xmm2
   218fc:	66 0f 28 c8          	movapd %xmm0,%xmm1
   21900:	66 0f 14 c8          	unpcklpd %xmm0,%xmm1
   21904:	66 0f 59 0d 34 39 fe 	mulpd  -0x1c6cc(%rip),%xmm1        # 5240 <std::thread::current::id::ID+0x45c8>
   2190b:	ff 
   2190c:	f2 0f 10 1d bc 56 fe 	movsd  -0x1a944(%rip),%xmm3        # 6fd0 <std::thread::current::id::ID+0x6358>
   21913:	ff 
   21914:	f2 0f 59 dd          	mulsd  %xmm5,%xmm3
   21918:	f2 0f 10 e8          	movsd  %xmm0,%xmm5
   2191c:	66 0f 59 2d 2c 39 fe 	mulpd  -0x1c6d4(%rip),%xmm5        # 5250 <std::thread::current::id::ID+0x45d8>
   21923:	ff 
   21924:	66 0f 58 ca          	addpd  %xmm2,%xmm1
   21928:	66 0f 28 c5          	movapd %xmm5,%xmm0
   2192c:	66 0f 15 c5          	unpckhpd %xmm5,%xmm0
   21930:	f2 0f 58 c3          	addsd  %xmm3,%xmm0
   21934:	66 0f 28 d1          	movapd %xmm1,%xmm2
   21938:	66 0f c6 d1 01       	shufpd $0x1,%xmm1,%xmm2
   2193d:	66 0f 59 15 1b 38 fe 	mulpd  -0x1c7e5(%rip),%xmm2        # 5160 <std::thread::current::id::ID+0x44e8>
   21944:	ff 
   21945:	f2 0f 58 c5          	addsd  %xmm5,%xmm0
   21949:	66 0f 28 1d 6f 38 fe 	movapd -0x1c791(%rip),%xmm3        # 51c0 <std::thread::current::id::ID+0x4548>
   21950:	ff 
   21951:	66 0f 59 d9          	mulpd  %xmm1,%xmm3
   21955:	66 0f 5c da          	subpd  %xmm2,%xmm3
   21959:	66 0f 28 e8          	movapd %xmm0,%xmm5
   2195d:	66 0f 14 e8          	unpcklpd %xmm0,%xmm5
   21961:	66 0f 59 2d c7 38 fe 	mulpd  -0x1c739(%rip),%xmm5        # 5230 <std::thread::current::id::ID+0x45b8>
   21968:	ff 
   21969:	66 0f 28 d3          	movapd %xmm3,%xmm2
   2196d:	66 0f 5c d5          	subpd  %xmm5,%xmm2
   21971:	66 0f 58 eb          	addpd  %xmm3,%xmm5
   21975:	f2 0f 10 ea          	movsd  %xmm2,%xmm5
   21979:	66 0f 59 0d af 3a fe 	mulpd  -0x1c551(%rip),%xmm1        # 5430 <std::thread::current::id::ID+0x47b8>
   21980:	ff 
   21981:	66 0f 28 d1          	movapd %xmm1,%xmm2
   21985:	66 0f 15 d1          	unpckhpd %xmm1,%xmm2
   21989:	f2 0f 5c ca          	subsd  %xmm2,%xmm1
   2198d:	f2 0f 59 05 cb 56 fe 	mulsd  -0x1a935(%rip),%xmm0        # 7060 <std::thread::current::id::ID+0x63e8>
   21994:	ff 
   21995:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
   21999:	31 c0                	xor    %eax,%eax
   2199b:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   2199f:	66 0f 2e e9          	ucomisd %xmm1,%xmm5
   219a3:	72 3e                	jb     219e3 <gpui_canvas::color::gamut::in_gamut+0x553>
   219a5:	f2 0f 10 0d 3b 56 fe 	movsd  -0x1a9c5(%rip),%xmm1        # 6fe8 <std::thread::current::id::ID+0x6370>
   219ac:	ff 
   219ad:	66 0f 2e cd          	ucomisd %xmm5,%xmm1
   219b1:	72 30                	jb     219e3 <gpui_canvas::color::gamut::in_gamut+0x553>
   219b3:	66 0f 15 ed          	unpckhpd %xmm5,%xmm5
   219b7:	31 c0                	xor    %eax,%eax
   219b9:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   219bd:	66 0f 2e ea          	ucomisd %xmm2,%xmm5
   219c1:	72 20                	jb     219e3 <gpui_canvas::color::gamut::in_gamut+0x553>
   219c3:	66 0f 2e cd          	ucomisd %xmm5,%xmm1
   219c7:	72 1a                	jb     219e3 <gpui_canvas::color::gamut::in_gamut+0x553>
   219c9:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   219cd:	f2 0f c2 c8 02       	cmplesd %xmm0,%xmm1
   219d2:	f2 0f c2 05 0d 56 fe 	cmplesd -0x1a9f3(%rip),%xmm0        # 6fe8 <std::thread::current::id::ID+0x6370>
   219d9:	ff 02 
   219db:	66 0f 54 c1          	andpd  %xmm1,%xmm0
   219df:	66 0f 7e c0          	movd   %xmm0,%eax
   219e3:	24 01                	and    $0x1,%al
   219e5:	48 83 c4 68          	add    $0x68,%rsp
   219e9:	5b                   	pop    %rbx
   219ea:	5d                   	pop    %rbp
   219eb:	c3                   	ret
   219ec:	66 0f 6e c0          	movd   %eax,%xmm0
   219f0:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   219f4:	f2 0f 59 05 b4 56 fe 	mulsd  -0x1a94c(%rip),%xmm0        # 70b0 <std::thread::current::id::ID+0x6438>
   219fb:	ff 
   219fc:	48 8d 7c 24 48       	lea    0x48(%rsp),%rdi
   21a01:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
   21a06:	0f 29 0c 24          	movaps %xmm1,(%rsp)
   21a0a:	66 0f 7f 54 24 30    	movdqa %xmm2,0x30(%rsp)
   21a10:	ff 15 b2 1e 04 00    	call   *0x41eb2(%rip)        # 638c8 <sincos@GLIBC_2.2.5>
   21a16:	0f 28 44 24 30       	movaps 0x30(%rsp),%xmm0
   21a1b:	0f 57 c9             	xorps  %xmm1,%xmm1
   21a1e:	f3 0f 5a c8          	cvtss2sd %xmm0,%xmm1
   21a22:	0f 28 04 24          	movaps (%rsp),%xmm0
   21a26:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   21a2a:	f2 0f 10 54 24 40    	movsd  0x40(%rsp),%xmm2
   21a30:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
   21a34:	f2 0f 59 44 24 48    	mulsd  0x48(%rsp),%xmm0
   21a3a:	f2 0f 10 1d 66 56 fe 	movsd  -0x1a99a(%rip),%xmm3        # 70a8 <std::thread::current::id::ID+0x6430>
   21a41:	ff 
   21a42:	f2 0f 59 da          	mulsd  %xmm2,%xmm3
   21a46:	f2 0f 58 d9          	addsd  %xmm1,%xmm3
   21a4a:	f2 0f 10 2d 06 56 fe 	movsd  -0x1a9fa(%rip),%xmm5        # 7058 <std::thread::current::id::ID+0x63e0>
   21a51:	ff 
   21a52:	f2 0f 59 e8          	mulsd  %xmm0,%xmm5
   21a56:	f2 0f 58 eb          	addsd  %xmm3,%xmm5
   21a5a:	f2 0f 10 1d c6 55 fe 	movsd  -0x1aa3a(%rip),%xmm3        # 7028 <std::thread::current::id::ID+0x63b0>
   21a61:	ff 
   21a62:	f2 0f 59 da          	mulsd  %xmm2,%xmm3
   21a66:	f2 0f 58 d9          	addsd  %xmm1,%xmm3
   21a6a:	f2 0f 10 35 66 56 fe 	movsd  -0x1a99a(%rip),%xmm6        # 70d8 <std::thread::current::id::ID+0x6460>
   21a71:	ff 
   21a72:	f2 0f 59 f0          	mulsd  %xmm0,%xmm6
   21a76:	f2 0f 58 f3          	addsd  %xmm3,%xmm6
   21a7a:	f2 0f 59 15 16 56 fe 	mulsd  -0x1a9ea(%rip),%xmm2        # 7098 <std::thread::current::id::ID+0x6420>
   21a81:	ff 
   21a82:	f2 0f 58 d1          	addsd  %xmm1,%xmm2
   21a86:	f2 0f 59 05 da 54 fe 	mulsd  -0x1ab26(%rip),%xmm0        # 6f68 <std::thread::current::id::ID+0x62f0>
   21a8d:	ff 
   21a8e:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   21a92:	66 0f 28 e5          	movapd %xmm5,%xmm4
   21a96:	f2 0f 59 e5          	mulsd  %xmm5,%xmm4
   21a9a:	f2 0f 59 e5          	mulsd  %xmm5,%xmm4
   21a9e:	66 0f 28 de          	movapd %xmm6,%xmm3
   21aa2:	f2 0f 59 de          	mulsd  %xmm6,%xmm3
   21aa6:	f2 0f 59 de          	mulsd  %xmm6,%xmm3
   21aaa:	66 0f 28 c8          	movapd %xmm0,%xmm1
   21aae:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   21ab2:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   21ab6:	f2 0f 10 05 22 56 fe 	movsd  -0x1a9de(%rip),%xmm0        # 70e0 <std::thread::current::id::ID+0x6468>
   21abd:	ff 
   21abe:	f2 0f 59 c4          	mulsd  %xmm4,%xmm0
   21ac2:	f2 0f 10 15 2e 55 fe 	movsd  -0x1aad2(%rip),%xmm2        # 6ff8 <std::thread::current::id::ID+0x6380>
   21ac9:	ff 
   21aca:	f2 0f 59 d3          	mulsd  %xmm3,%xmm2
   21ace:	f2 0f 58 d0          	addsd  %xmm0,%xmm2
   21ad2:	f2 0f 10 05 26 55 fe 	movsd  -0x1aada(%rip),%xmm0        # 7000 <std::thread::current::id::ID+0x6388>
   21ad9:	ff 
   21ada:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   21ade:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   21ae2:	f2 0f 10 15 86 54 fe 	movsd  -0x1ab7a(%rip),%xmm2        # 6f70 <std::thread::current::id::ID+0x62f8>
   21ae9:	ff 
   21aea:	66 0f 14 e4          	unpcklpd %xmm4,%xmm4
   21aee:	66 0f 59 25 4a 3a fe 	mulpd  -0x1c5b6(%rip),%xmm4        # 5540 <std::thread::current::id::ID+0x48c8>
   21af5:	ff 
   21af6:	66 0f 14 db          	unpcklpd %xmm3,%xmm3
   21afa:	66 0f 59 1d 4e 3a fe 	mulpd  -0x1c5b2(%rip),%xmm3        # 5550 <std::thread::current::id::ID+0x48d8>
   21b01:	ff 
   21b02:	66 0f 58 dc          	addpd  %xmm4,%xmm3
   21b06:	66 0f 14 c9          	unpcklpd %xmm1,%xmm1
   21b0a:	66 0f 59 0d 5e 38 fe 	mulpd  -0x1c7a2(%rip),%xmm1        # 5370 <std::thread::current::id::ID+0x46f8>
   21b11:	ff 
   21b12:	66 0f 58 cb          	addpd  %xmm3,%xmm1
   21b16:	e9 0d fd ff ff       	jmp    21828 <gpui_canvas::color::gamut::in_gamut+0x398>

