<gpui_canvas::color::OutputProfile>::max_chroma:
   1f620:	66 0f 7e c1          	movd   %xmm0,%ecx
   1f624:	81 e1 ff ff ff 7f    	and    $0x7fffffff,%ecx
   1f62a:	b8 0d 00 00 00       	mov    $0xd,%eax
   1f62f:	81 f9 ff ff 7f 7f    	cmp    $0x7f7fffff,%ecx
   1f635:	7f 38                	jg     1f66f <<gpui_canvas::color::OutputProfile>::max_chroma+0x4f>
   1f637:	0f 57 e4             	xorps  %xmm4,%xmm4
   1f63a:	0f 57 d2             	xorps  %xmm2,%xmm2
   1f63d:	f3 0f c2 d0 06       	cmpnless %xmm0,%xmm2
   1f642:	0f 28 d8             	movaps %xmm0,%xmm3
   1f645:	f3 0f c2 1d 2a 62 fe 	cmpnless -0x19dd6(%rip),%xmm3        # 5878 <std::thread::current::id::ID+0x4c00>
   1f64c:	ff 06 
   1f64e:	0f 56 da             	orps   %xmm2,%xmm3
   1f651:	66 0f 7e d9          	movd   %xmm3,%ecx
   1f655:	66 0f 7e ca          	movd   %xmm1,%edx
   1f659:	81 e2 ff ff ff 7f    	and    $0x7fffffff,%edx
   1f65f:	81 fa 00 00 80 7f    	cmp    $0x7f800000,%edx
   1f665:	0f 9d c2             	setge  %dl
   1f668:	08 ca                	or     %cl,%dl
   1f66a:	f6 c2 01             	test   $0x1,%dl
   1f66d:	74 01                	je     1f670 <<gpui_canvas::color::OutputProfile>::max_chroma+0x50>
   1f66f:	c3                   	ret
   1f670:	0f 2e c4             	ucomiss %xmm4,%xmm0
   1f673:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   1f678:	75 02                	jne    1f67c <<gpui_canvas::color::OutputProfile>::max_chroma+0x5c>
   1f67a:	7b f3                	jnp    1f66f <<gpui_canvas::color::OutputProfile>::max_chroma+0x4f>
   1f67c:	0f 2e 05 f5 61 fe ff 	ucomiss -0x19e0b(%rip),%xmm0        # 5878 <std::thread::current::id::ID+0x4c00>
   1f683:	75 02                	jne    1f687 <<gpui_canvas::color::OutputProfile>::max_chroma+0x67>
   1f685:	7b e8                	jnp    1f66f <<gpui_canvas::color::OutputProfile>::max_chroma+0x4f>
   1f687:	53                   	push   %rbx
   1f688:	48 83 ec 10          	sub    $0x10,%rsp
   1f68c:	f3 0f 11 44 24 0c    	movss  %xmm0,0xc(%rsp)
   1f692:	89 fb                	mov    %edi,%ebx
   1f694:	0f 57 c0             	xorps  %xmm0,%xmm0
   1f697:	f3 0f 5a c1          	cvtss2sd %xmm1,%xmm0
   1f69b:	f2 0f 10 0d cd 7c fe 	movsd  -0x18333(%rip),%xmm1        # 7370 <std::thread::current::id::ID+0x66f8>
   1f6a2:	ff 
   1f6a3:	ff 15 47 5b 04 00    	call   *0x45b47(%rip)        # 651f0 <_DYNAMIC+0x378>
   1f6a9:	f2 0f 10 1d bf 7c fe 	movsd  -0x18341(%rip),%xmm3        # 7370 <std::thread::current::id::ID+0x66f8>
   1f6b0:	ff 
   1f6b1:	f2 0f 58 d8          	addsd  %xmm0,%xmm3
   1f6b5:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   1f6b9:	66 0f 28 d0          	movapd %xmm0,%xmm2
   1f6bd:	f2 0f c2 d1 01       	cmpltsd %xmm1,%xmm2
   1f6c2:	66 0f 54 da          	andpd  %xmm2,%xmm3
   1f6c6:	66 0f 55 d0          	andnpd %xmm0,%xmm2
   1f6ca:	66 0f 56 d3          	orpd   %xmm3,%xmm2
   1f6ce:	66 0f 2e 15 d2 7b fe 	ucomisd -0x1842e(%rip),%xmm2        # 72a8 <std::thread::current::id::ID+0x6630>
   1f6d5:	ff 
   1f6d6:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   1f6da:	73 0f                	jae    1f6eb <<gpui_canvas::color::OutputProfile>::max_chroma+0xcb>
   1f6dc:	0f 57 c0             	xorps  %xmm0,%xmm0
   1f6df:	f2 0f 5a c2          	cvtsd2ss %xmm2,%xmm0
   1f6e3:	f3 0f c2 c8 00       	cmpeqss %xmm0,%xmm1
   1f6e8:	0f 55 c8             	andnps %xmm0,%xmm1
   1f6eb:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   1f6f1:	0f b6 fb             	movzbl %bl,%edi
   1f6f4:	48 83 c4 10          	add    $0x10,%rsp
   1f6f8:	5b                   	pop    %rbx
   1f6f9:	e9 f2 11 00 00       	jmp    208f0 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>>
   1f6fe:	cc                   	int3
   1f6ff:	cc                   	int3

<gpui_canvas::color::Color>::fit_chroma:
   20230:	55                   	push   %rbp
   20231:	41 57                	push   %r15
   20233:	41 56                	push   %r14
   20235:	41 54                	push   %r12
   20237:	53                   	push   %rbx
   20238:	48 83 ec 30          	sub    $0x30,%rsp
   2023c:	48 89 fb             	mov    %rdi,%rbx
   2023f:	44 8b 66 08          	mov    0x8(%rsi),%r12d
   20243:	44 8b 7e 0c          	mov    0xc(%rsi),%r15d
   20247:	41 81 ff 00 00 00 c0 	cmp    $0xc0000000,%r15d
   2024e:	0f 92 c0             	setb   %al
   20251:	45 85 e4             	test   %r12d,%r12d
   20254:	0f 99 c1             	setns  %cl
   20257:	08 c1                	or     %al,%cl
   20259:	74 09                	je     20264 <<gpui_canvas::color::Color>::fit_chroma+0x34>
   2025b:	c7 43 04 0d 00 00 00 	movl   $0xd,0x4(%rbx)
   20262:	eb 4a                	jmp    202ae <<gpui_canvas::color::Color>::fit_chroma+0x7e>
   20264:	49 89 f6             	mov    %rsi,%r14
   20267:	0f 10 06             	movups (%rsi),%xmm0
   2026a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   2026f:	0f b6 ea             	movzbl %dl,%ebp
   20272:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   20277:	89 ee                	mov    %ebp,%esi
   20279:	e8 c2 1f 00 00       	call   22240 <gpui_canvas::color::gamut::in_gamut>
   2027e:	84 c0                	test   %al,%al
   20280:	74 0c                	je     2028e <<gpui_canvas::color::Color>::fit_chroma+0x5e>
   20282:	41 0f 10 06          	movups (%r14),%xmm0
   20286:	0f 11 43 04          	movups %xmm0,0x4(%rbx)
   2028a:	31 c0                	xor    %eax,%eax
   2028c:	eb 25                	jmp    202b3 <<gpui_canvas::color::Color>::fit_chroma+0x83>
   2028e:	41 8b 16             	mov    (%r14),%edx
   20291:	89 d6                	mov    %edx,%esi
   20293:	81 e6 ff ff ff 7f    	and    $0x7fffffff,%esi
   20299:	b8 0d 00 00 00       	mov    $0xd,%eax
   2029e:	31 c9                	xor    %ecx,%ecx
   202a0:	81 fe ff ff 7f 7f    	cmp    $0x7f7fffff,%esi
   202a6:	7e 1d                	jle    202c5 <<gpui_canvas::color::Color>::fit_chroma+0x95>
   202a8:	89 43 04             	mov    %eax,0x4(%rbx)
   202ab:	89 4b 08             	mov    %ecx,0x8(%rbx)
   202ae:	b8 01 00 00 00       	mov    $0x1,%eax
   202b3:	89 03                	mov    %eax,(%rbx)
   202b5:	48 89 d8             	mov    %rbx,%rax
   202b8:	48 83 c4 30          	add    $0x30,%rsp
   202bc:	5b                   	pop    %rbx
   202bd:	41 5c                	pop    %r12
   202bf:	41 5e                	pop    %r14
   202c1:	41 5f                	pop    %r15
   202c3:	5d                   	pop    %rbp
   202c4:	c3                   	ret
   202c5:	44 89 e6             	mov    %r12d,%esi
   202c8:	81 e6 ff ff ff 7f    	and    $0x7fffffff,%esi
   202ce:	66 0f 6e c6          	movd   %esi,%xmm0
   202d2:	0f 2e 05 d7 55 fe ff 	ucomiss -0x1aa29(%rip),%xmm0        # 58b0 <std::thread::current::id::ID+0x4c38>
   202d9:	74 cd                	je     202a8 <<gpui_canvas::color::Color>::fit_chroma+0x78>
   202db:	66 0f 6e d2          	movd   %edx,%xmm2
   202df:	0f 57 c9             	xorps  %xmm1,%xmm1
   202e2:	0f 2e d1             	ucomiss %xmm1,%xmm2
   202e5:	72 c1                	jb     202a8 <<gpui_canvas::color::Color>::fit_chroma+0x78>
   202e7:	f3 0f 10 0d 89 55 fe 	movss  -0x1aa77(%rip),%xmm1        # 5878 <std::thread::current::id::ID+0x4c00>
   202ee:	ff 
   202ef:	0f 2e ca             	ucomiss %xmm2,%xmm1
   202f2:	72 b4                	jb     202a8 <<gpui_canvas::color::Color>::fit_chroma+0x78>
   202f4:	f3 41 0f 10 5e 04    	movss  0x4(%r14),%xmm3
   202fa:	31 c9                	xor    %ecx,%ecx
   202fc:	0f 57 c9             	xorps  %xmm1,%xmm1
   202ff:	0f 2e d1             	ucomiss %xmm1,%xmm2
   20302:	f3 0f 11 54 24 0c    	movss  %xmm2,0xc(%rsp)
   20308:	75 02                	jne    2030c <<gpui_canvas::color::Color>::fit_chroma+0xdc>
   2030a:	7b 63                	jnp    2036f <<gpui_canvas::color::Color>::fit_chroma+0x13f>
   2030c:	0f 2e 15 65 55 fe ff 	ucomiss -0x1aa9b(%rip),%xmm2        # 5878 <std::thread::current::id::ID+0x4c00>
   20313:	75 02                	jne    20317 <<gpui_canvas::color::Color>::fit_chroma+0xe7>
   20315:	7b 58                	jnp    2036f <<gpui_canvas::color::Color>::fit_chroma+0x13f>
   20317:	0f 29 5c 24 20       	movaps %xmm3,0x20(%rsp)
   2031c:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   20320:	f2 0f 10 0d 48 70 fe 	movsd  -0x18fb8(%rip),%xmm1        # 7370 <std::thread::current::id::ID+0x66f8>
   20327:	ff 
   20328:	ff 15 c2 4e 04 00    	call   *0x44ec2(%rip)        # 651f0 <_DYNAMIC+0x378>
   2032e:	66 0f 2e 05 72 6f fe 	ucomisd -0x1908e(%rip),%xmm0        # 72a8 <std::thread::current::id::ID+0x6630>
   20335:	ff 
   20336:	0f 57 c9             	xorps  %xmm1,%xmm1
   20339:	73 0c                	jae    20347 <<gpui_canvas::color::Color>::fit_chroma+0x117>
   2033b:	f2 0f 5a c0          	cvtsd2ss %xmm0,%xmm0
   2033f:	f3 0f c2 c8 00       	cmpeqss %xmm0,%xmm1
   20344:	0f 55 c8             	andnps %xmm0,%xmm1
   20347:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   2034d:	89 ef                	mov    %ebp,%edi
   2034f:	e8 9c 05 00 00       	call   208f0 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>>
   20354:	f3 0f 10 54 24 0c    	movss  0xc(%rsp),%xmm2
   2035a:	48 89 c1             	mov    %rax,%rcx
   2035d:	48 c1 e9 20          	shr    $0x20,%rcx
   20361:	83 f8 ff             	cmp    $0xffffffff,%eax
   20364:	0f 28 5c 24 20       	movaps 0x20(%rsp),%xmm3
   20369:	0f 85 39 ff ff ff    	jne    202a8 <<gpui_canvas::color::Color>::fit_chroma+0x78>
   2036f:	66 0f 6e c1          	movd   %ecx,%xmm0
   20373:	0f 28 cb             	movaps %xmm3,%xmm1
   20376:	f3 0f 5d c8          	minss  %xmm0,%xmm1
   2037a:	0f 28 e1             	movaps %xmm1,%xmm4
   2037d:	f3 0f c2 e1 03       	cmpunordss %xmm1,%xmm4
   20382:	0f 28 c4             	movaps %xmm4,%xmm0
   20385:	0f 55 c1             	andnps %xmm1,%xmm0
   20388:	0f 54 e3             	andps  %xmm3,%xmm4
   2038b:	0f 56 e0             	orps   %xmm0,%xmm4
   2038e:	f3 0f 11 54 24 10    	movss  %xmm2,0x10(%rsp)
   20394:	0f 29 64 24 20       	movaps %xmm4,0x20(%rsp)
   20399:	f3 0f 11 64 24 14    	movss  %xmm4,0x14(%rsp)
   2039f:	44 89 64 24 18       	mov    %r12d,0x18(%rsp)
   203a4:	44 89 7c 24 1c       	mov    %r15d,0x1c(%rsp)
   203a9:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   203ae:	89 ee                	mov    %ebp,%esi
   203b0:	e8 8b 1e 00 00       	call   22240 <gpui_canvas::color::gamut::in_gamut>
   203b5:	84 c0                	test   %al,%al
   203b7:	74 1c                	je     203d5 <<gpui_canvas::color::Color>::fit_chroma+0x1a5>
   203b9:	0f 28 44 24 20       	movaps 0x20(%rsp),%xmm0
   203be:	f3 0f 11 43 08       	movss  %xmm0,0x8(%rbx)
   203c3:	44 89 63 0c          	mov    %r12d,0xc(%rbx)
   203c7:	44 89 7b 10          	mov    %r15d,0x10(%rbx)
   203cb:	31 c0                	xor    %eax,%eax
   203cd:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   203d3:	eb 0d                	jmp    203e2 <<gpui_canvas::color::Color>::fit_chroma+0x1b2>
   203d5:	b8 01 00 00 00       	mov    $0x1,%eax
   203da:	f3 0f 10 05 8e 54 fe 	movss  -0x1ab72(%rip),%xmm0        # 5870 <std::thread::current::id::ID+0x4bf8>
   203e1:	ff 
   203e2:	f3 0f 11 43 04       	movss  %xmm0,0x4(%rbx)
   203e7:	e9 c7 fe ff ff       	jmp    202b3 <<gpui_canvas::color::Color>::fit_chroma+0x83>
   203ec:	cc                   	int3
   203ed:	cc                   	int3
   203ee:	cc                   	int3
   203ef:	cc                   	int3

gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>:
   208f0:	55                   	push   %rbp
   208f1:	41 57                	push   %r15
   208f3:	41 56                	push   %r14
   208f5:	41 54                	push   %r12
   208f7:	53                   	push   %rbx
   208f8:	48 81 ec a0 01 00 00 	sub    $0x1a0,%rsp
   208ff:	f3 0f 11 84 24 ac 00 	movss  %xmm0,0xac(%rsp)
   20906:	00 00 
   20908:	89 fb                	mov    %edi,%ebx
   2090a:	0f 29 8c 24 50 01 00 	movaps %xmm1,0x150(%rsp)
   20911:	00 
   20912:	0f 57 c0             	xorps  %xmm0,%xmm0
   20915:	f3 0f 5a c1          	cvtss2sd %xmm1,%xmm0
   20919:	f2 0f 59 05 2f 6a fe 	mulsd  -0x195d1(%rip),%xmm0        # 7350 <std::thread::current::id::ID+0x66d8>
   20920:	ff 
   20921:	48 8d bc 24 68 01 00 	lea    0x168(%rsp),%rdi
   20928:	00 
   20929:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
   20930:	00 
   20931:	ff 15 e9 48 04 00    	call   *0x448e9(%rip)        # 65220 <sincos@GLIBC_2.2.5>
   20937:	f2 0f 10 8c 24 68 01 	movsd  0x168(%rsp),%xmm1
   2093e:	00 00 
   20940:	f2 0f 10 94 24 60 01 	movsd  0x160(%rsp),%xmm2
   20947:	00 00 
   20949:	f2 0f 10 05 d7 69 fe 	movsd  -0x19629(%rip),%xmm0        # 7328 <std::thread::current::id::ID+0x66b0>
   20950:	ff 
   20951:	f2 0f 59 c2          	mulsd  %xmm2,%xmm0
   20955:	66 0f 57 db          	xorpd  %xmm3,%xmm3
   20959:	f2 0f 58 c3          	addsd  %xmm3,%xmm0
   2095d:	f2 0f 10 25 1b 69 fe 	movsd  -0x196e5(%rip),%xmm4        # 7280 <std::thread::current::id::ID+0x6608>
   20964:	ff 
   20965:	f2 0f 59 e2          	mulsd  %xmm2,%xmm4
   20969:	f2 0f 58 e3          	addsd  %xmm3,%xmm4
   2096d:	f2 0f 10 2d 4b 69 fe 	movsd  -0x196b5(%rip),%xmm5        # 72c0 <std::thread::current::id::ID+0x6648>
   20974:	ff 
   20975:	f2 0f 59 e9          	mulsd  %xmm1,%xmm5
   20979:	f2 0f 58 e8          	addsd  %xmm0,%xmm5
   2097d:	f2 0f 10 05 03 6a fe 	movsd  -0x195fd(%rip),%xmm0        # 7388 <std::thread::current::id::ID+0x6710>
   20984:	ff 
   20985:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   20989:	f2 0f 58 c4          	addsd  %xmm4,%xmm0
   2098d:	f2 0f 59 15 7b 69 fe 	mulsd  -0x19685(%rip),%xmm2        # 7310 <std::thread::current::id::ID+0x6698>
   20994:	ff 
   20995:	f2 0f 58 d3          	addsd  %xmm3,%xmm2
   20999:	f2 0f 59 0d c7 67 fe 	mulsd  -0x19839(%rip),%xmm1        # 7168 <std::thread::current::id::ID+0x64f0>
   209a0:	ff 
   209a1:	f2 0f 58 ca          	addsd  %xmm2,%xmm1
   209a5:	85 db                	test   %ebx,%ebx
   209a7:	74 35                	je     209de <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xee>
   209a9:	66 44 0f 28 2d fe 48 	movapd -0x1b702(%rip),%xmm13        # 52b0 <std::thread::current::id::ID+0x4638>
   209b0:	fe ff 
   209b2:	66 0f 28 15 e6 4d fe 	movapd -0x1b21a(%rip),%xmm2        # 57a0 <std::thread::current::id::ID+0x4b28>
   209b9:	ff 
   209ba:	66 44 0f 28 1d 7d 4e 	movapd -0x1b183(%rip),%xmm11        # 5840 <std::thread::current::id::ID+0x4bc8>
   209c1:	fe ff 
   209c3:	f3 0f 7e 25 f5 67 fe 	movq   -0x1980b(%rip),%xmm4        # 71c0 <std::thread::current::id::ID+0x6548>
   209ca:	ff 
   209cb:	f3 0f 7e 3d cd 68 fe 	movq   -0x19733(%rip),%xmm7        # 72a0 <std::thread::current::id::ID+0x6628>
   209d2:	ff 
   209d3:	f3 44 0f 7e 05 ec 67 	movq   -0x19814(%rip),%xmm8        # 71c8 <std::thread::current::id::ID+0x6550>
   209da:	fe ff 
   209dc:	eb 33                	jmp    20a11 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x121>
   209de:	66 44 0f 28 2d a9 4b 	movapd -0x1b457(%rip),%xmm13        # 5590 <std::thread::current::id::ID+0x4918>
   209e5:	fe ff 
   209e7:	66 0f 28 15 81 4c fe 	movapd -0x1b37f(%rip),%xmm2        # 5670 <std::thread::current::id::ID+0x49f8>
   209ee:	ff 
   209ef:	66 44 0f 28 1d 18 4b 	movapd -0x1b4e8(%rip),%xmm11        # 5510 <std::thread::current::id::ID+0x4898>
   209f6:	fe ff 
   209f8:	f3 0f 7e 25 f0 68 fe 	movq   -0x19710(%rip),%xmm4        # 72f0 <std::thread::current::id::ID+0x6678>
   209ff:	ff 
   20a00:	f3 0f 7e 3d d8 68 fe 	movq   -0x19728(%rip),%xmm7        # 72e0 <std::thread::current::id::ID+0x6668>
   20a07:	ff 
   20a08:	f3 44 0f 7e 05 47 68 	movq   -0x197b9(%rip),%xmm8        # 7258 <std::thread::current::id::ID+0x65e0>
   20a0f:	fe ff 
   20a11:	f3 0f 7e f4          	movq   %xmm4,%xmm6
   20a15:	f3 0f 7e ff          	movq   %xmm7,%xmm7
   20a19:	f3 41 0f 7e e0       	movq   %xmm8,%xmm4
   20a1e:	66 0f 14 e8          	unpcklpd %xmm0,%xmm5
   20a22:	66 0f 28 c5          	movapd %xmm5,%xmm0
   20a26:	66 0f 59 c5          	mulpd  %xmm5,%xmm0
   20a2a:	66 44 0f 28 c1       	movapd %xmm1,%xmm8
   20a2f:	f2 44 0f 59 c1       	mulsd  %xmm1,%xmm8
   20a34:	f2 44 0f 59 c1       	mulsd  %xmm1,%xmm8
   20a39:	66 0f 59 c5          	mulpd  %xmm5,%xmm0
   20a3d:	66 0f 29 44 24 40    	movapd %xmm0,0x40(%rsp)
   20a43:	f2 44 0f 11 44 24 50 	movsd  %xmm8,0x50(%rsp)
   20a4a:	f2 0f 10 44 24 40    	movsd  0x40(%rsp),%xmm0
   20a50:	66 0f 14 c0          	unpcklpd %xmm0,%xmm0
   20a54:	66 45 0f 28 c5       	movapd %xmm13,%xmm8
   20a59:	66 44 0f 59 c0       	mulpd  %xmm0,%xmm8
   20a5e:	66 0f 59 c6          	mulpd  %xmm6,%xmm0
   20a62:	66 44 0f 10 64 24 48 	movupd 0x48(%rsp),%xmm12
   20a69:	66 45 0f 28 cc       	movapd %xmm12,%xmm9
   20a6e:	66 45 0f 14 cc       	unpcklpd %xmm12,%xmm9
   20a73:	66 44 0f 28 d2       	movapd %xmm2,%xmm10
   20a78:	66 45 0f 59 d1       	mulpd  %xmm9,%xmm10
   20a7d:	66 45 0f 58 d0       	addpd  %xmm8,%xmm10
   20a82:	66 44 0f 59 cf       	mulpd  %xmm7,%xmm9
   20a87:	66 44 0f 58 c8       	addpd  %xmm0,%xmm9
   20a8c:	66 45 0f 15 e4       	unpckhpd %xmm12,%xmm12
   20a91:	66 45 0f 28 f3       	movapd %xmm11,%xmm14
   20a96:	66 45 0f 59 f4       	mulpd  %xmm12,%xmm14
   20a9b:	66 45 0f 58 f2       	addpd  %xmm10,%xmm14
   20aa0:	66 44 0f 29 b4 24 c0 	movapd %xmm14,0xc0(%rsp)
   20aa7:	00 00 00 
   20aaa:	66 44 0f 59 e4       	mulpd  %xmm4,%xmm12
   20aaf:	66 45 0f 58 e1       	addpd  %xmm9,%xmm12
   20ab4:	66 44 0f 29 a4 24 f0 	movapd %xmm12,0xf0(%rsp)
   20abb:	00 00 00 
   20abe:	66 44 0f 28 c5       	movapd %xmm5,%xmm8
   20ac3:	66 44 0f 59 05 04 49 	mulpd  -0x1b6fc(%rip),%xmm8        # 53d0 <std::thread::current::id::ID+0x4758>
   20aca:	fe ff 
   20acc:	f2 44 0f 10 0d bb 67 	movsd  -0x19845(%rip),%xmm9        # 7290 <std::thread::current::id::ID+0x6618>
   20ad3:	fe ff 
   20ad5:	f2 44 0f 59 c9       	mulsd  %xmm1,%xmm9
   20ada:	f2 41 0f 59 c9       	mulsd  %xmm9,%xmm1
   20adf:	66 41 0f 59 e8       	mulpd  %xmm8,%xmm5
   20ae4:	66 0f 29 6c 24 40    	movapd %xmm5,0x40(%rsp)
   20aea:	f2 0f 11 4c 24 50    	movsd  %xmm1,0x50(%rsp)
   20af0:	f2 0f 10 44 24 40    	movsd  0x40(%rsp),%xmm0
   20af6:	66 0f 14 c0          	unpcklpd %xmm0,%xmm0
   20afa:	66 41 0f 28 cd       	movapd %xmm13,%xmm1
   20aff:	66 0f 59 c8          	mulpd  %xmm0,%xmm1
   20b03:	66 0f 59 c6          	mulpd  %xmm6,%xmm0
   20b07:	66 44 0f 10 7c 24 48 	movupd 0x48(%rsp),%xmm15
   20b0e:	66 41 0f 28 ef       	movapd %xmm15,%xmm5
   20b13:	66 41 0f 14 ef       	unpcklpd %xmm15,%xmm5
   20b18:	66 44 0f 28 d2       	movapd %xmm2,%xmm10
   20b1d:	66 44 0f 59 d5       	mulpd  %xmm5,%xmm10
   20b22:	66 44 0f 58 d1       	addpd  %xmm1,%xmm10
   20b27:	66 0f 59 ef          	mulpd  %xmm7,%xmm5
   20b2b:	66 0f 58 e8          	addpd  %xmm0,%xmm5
   20b2f:	66 45 0f 15 ff       	unpckhpd %xmm15,%xmm15
   20b34:	66 41 0f 28 c3       	movapd %xmm11,%xmm0
   20b39:	66 41 0f 59 c7       	mulpd  %xmm15,%xmm0
   20b3e:	66 41 0f 58 c2       	addpd  %xmm10,%xmm0
   20b43:	66 44 0f 28 d0       	movapd %xmm0,%xmm10
   20b48:	66 0f 29 84 24 b0 00 	movapd %xmm0,0xb0(%rsp)
   20b4f:	00 00 
   20b51:	66 44 0f 59 fc       	mulpd  %xmm4,%xmm15
   20b56:	66 44 0f 58 fd       	addpd  %xmm5,%xmm15
   20b5b:	66 44 0f 29 7c 24 60 	movapd %xmm15,0x60(%rsp)
   20b62:	66 44 0f 29 44 24 40 	movapd %xmm8,0x40(%rsp)
   20b69:	f2 44 0f 11 4c 24 50 	movsd  %xmm9,0x50(%rsp)
   20b70:	f2 0f 10 44 24 40    	movsd  0x40(%rsp),%xmm0
   20b76:	66 0f 14 c0          	unpcklpd %xmm0,%xmm0
   20b7a:	66 41 0f 28 cd       	movapd %xmm13,%xmm1
   20b7f:	66 0f 59 c8          	mulpd  %xmm0,%xmm1
   20b83:	66 0f 59 c6          	mulpd  %xmm6,%xmm0
   20b87:	66 44 0f 10 4c 24 48 	movupd 0x48(%rsp),%xmm9
   20b8e:	66 41 0f 28 e9       	movapd %xmm9,%xmm5
   20b93:	66 41 0f 14 e9       	unpcklpd %xmm9,%xmm5
   20b98:	66 44 0f 28 c2       	movapd %xmm2,%xmm8
   20b9d:	66 44 0f 59 c5       	mulpd  %xmm5,%xmm8
   20ba2:	66 44 0f 58 c1       	addpd  %xmm1,%xmm8
   20ba7:	66 0f 59 ef          	mulpd  %xmm7,%xmm5
   20bab:	66 0f 58 e8          	addpd  %xmm0,%xmm5
   20baf:	66 45 0f 15 c9       	unpckhpd %xmm9,%xmm9
   20bb4:	66 41 0f 28 db       	movapd %xmm11,%xmm3
   20bb9:	66 41 0f 59 d9       	mulpd  %xmm9,%xmm3
   20bbe:	66 41 0f 58 d8       	addpd  %xmm8,%xmm3
   20bc3:	66 0f 29 9c 24 80 00 	movapd %xmm3,0x80(%rsp)
   20bca:	00 00 
   20bcc:	66 44 0f 59 cc       	mulpd  %xmm4,%xmm9
   20bd1:	66 44 0f 58 cd       	addpd  %xmm5,%xmm9
   20bd6:	66 44 0f 29 0c 24    	movapd %xmm9,(%rsp)
   20bdc:	0f 28 05 ad 4a fe ff 	movaps -0x1b553(%rip),%xmm0        # 5690 <std::thread::current::id::ID+0x4a18>
   20be3:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
   20be8:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
   20bef:	00 f0 3f 
   20bf2:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   20bf7:	66 0f 10 4c 24 48    	movupd 0x48(%rsp),%xmm1
   20bfd:	66 0f 28 c1          	movapd %xmm1,%xmm0
   20c01:	66 0f 14 c1          	unpcklpd %xmm1,%xmm0
   20c05:	66 0f 59 d0          	mulpd  %xmm0,%xmm2
   20c09:	66 0f 59 c7          	mulpd  %xmm7,%xmm0
   20c0d:	66 41 0f 58 d5       	addpd  %xmm13,%xmm2
   20c12:	66 0f 58 c6          	addpd  %xmm6,%xmm0
   20c16:	66 0f 15 c9          	unpckhpd %xmm1,%xmm1
   20c1a:	66 44 0f 59 d9       	mulpd  %xmm1,%xmm11
   20c1f:	66 44 0f 58 da       	addpd  %xmm2,%xmm11
   20c24:	66 44 0f 29 9c 24 90 	movapd %xmm11,0x90(%rsp)
   20c2b:	00 00 00 
   20c2e:	66 0f 59 cc          	mulpd  %xmm4,%xmm1
   20c32:	66 0f 58 c8          	addpd  %xmm0,%xmm1
   20c36:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
   20c3a:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   20c3e:	66 0f 16 15 da 65 fe 	movhpd -0x19a26(%rip),%xmm2        # 7220 <std::thread::current::id::ID+0x65a8>
   20c45:	ff 
   20c46:	66 0f 58 d1          	addpd  %xmm1,%xmm2
   20c4a:	66 0f 29 54 24 20    	movapd %xmm2,0x20(%rsp)
   20c50:	66 41 0f 28 ce       	movapd %xmm14,%xmm1
   20c55:	66 44 0f 28 35 72 47 	movapd -0x1b88e(%rip),%xmm14        # 53d0 <std::thread::current::id::ID+0x4758>
   20c5c:	fe ff 
   20c5e:	66 41 0f 59 ce       	mulpd  %xmm14,%xmm1
   20c63:	66 0f 28 f1          	movapd %xmm1,%xmm6
   20c67:	66 45 0f 59 f4       	mulpd  %xmm12,%xmm14
   20c6c:	66 45 0f 28 da       	movapd %xmm10,%xmm11
   20c71:	66 45 0f 58 da       	addpd  %xmm10,%xmm11
   20c76:	66 41 0f 28 cf       	movapd %xmm15,%xmm1
   20c7b:	66 41 0f 58 cf       	addpd  %xmm15,%xmm1
   20c80:	66 45 0f 28 c3       	movapd %xmm11,%xmm8
   20c85:	66 45 0f 59 c3       	mulpd  %xmm11,%xmm8
   20c8a:	66 0f 28 d6          	movapd %xmm6,%xmm2
   20c8e:	66 0f 59 d3          	mulpd  %xmm3,%xmm2
   20c92:	66 0f 28 2d a6 47 fe 	movapd -0x1b85a(%rip),%xmm5        # 5440 <std::thread::current::id::ID+0x47c8>
   20c99:	ff 
   20c9a:	66 0f 59 d5          	mulpd  %xmm5,%xmm2
   20c9e:	66 44 0f 5c c2       	subpd  %xmm2,%xmm8
   20ca3:	66 41 0f 28 d6       	movapd %xmm14,%xmm2
   20ca8:	66 45 0f 28 fe       	movapd %xmm14,%xmm15
   20cad:	66 44 0f 29 74 24 70 	movapd %xmm14,0x70(%rsp)
   20cb4:	66 41 0f 59 d1       	mulpd  %xmm9,%xmm2
   20cb9:	66 0f 59 d5          	mulpd  %xmm5,%xmm2
   20cbd:	66 44 0f 28 d1       	movapd %xmm1,%xmm10
   20cc2:	66 44 0f 59 d1       	mulpd  %xmm1,%xmm10
   20cc7:	66 44 0f 5c d2       	subpd  %xmm2,%xmm10
   20ccc:	66 41 0f 28 eb       	movapd %xmm11,%xmm5
   20cd1:	66 0f c2 e8 01       	cmpltpd %xmm0,%xmm5
   20cd6:	66 0f 28 15 72 4b fe 	movapd -0x1b48e(%rip),%xmm2        # 5850 <std::thread::current::id::ID+0x4bd8>
   20cdd:	ff 
   20cde:	66 0f 28 fd          	movapd %xmm5,%xmm7
   20ce2:	66 0f 54 fa          	andpd  %xmm2,%xmm7
   20ce6:	66 0f 28 25 a2 49 fe 	movapd -0x1b65e(%rip),%xmm4        # 5690 <std::thread::current::id::ID+0x4a18>
   20ced:	ff 
   20cee:	66 0f 55 ec          	andnpd %xmm4,%xmm5
   20cf2:	66 0f 56 ef          	orpd   %xmm7,%xmm5
   20cf6:	66 44 0f 28 e1       	movapd %xmm1,%xmm12
   20cfb:	66 0f 28 f9          	movapd %xmm1,%xmm7
   20cff:	66 44 0f c2 e0 01    	cmpltpd %xmm0,%xmm12
   20d05:	66 41 0f 54 d4       	andpd  %xmm12,%xmm2
   20d0a:	66 44 0f 55 e4       	andnpd %xmm4,%xmm12
   20d0f:	66 44 0f 56 e2       	orpd   %xmm2,%xmm12
   20d14:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   20d18:	66 41 0f c2 c8 02    	cmplepd %xmm8,%xmm1
   20d1e:	66 0f 29 4c 24 30    	movapd %xmm1,0x30(%rsp)
   20d24:	66 44 0f 5f c0       	maxpd  %xmm0,%xmm8
   20d29:	66 45 0f 51 c8       	sqrtpd %xmm8,%xmm9
   20d2e:	66 44 0f 59 cd       	mulpd  %xmm5,%xmm9
   20d33:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   20d37:	66 41 0f c2 ca 02    	cmplepd %xmm10,%xmm1
   20d3d:	66 0f 29 4c 24 10    	movapd %xmm1,0x10(%rsp)
   20d43:	66 44 0f 5f d0       	maxpd  %xmm0,%xmm10
   20d48:	66 45 0f 51 d2       	sqrtpd %xmm10,%xmm10
   20d4d:	66 45 0f 59 d4       	mulpd  %xmm12,%xmm10
   20d52:	66 45 0f 58 cb       	addpd  %xmm11,%xmm9
   20d57:	66 44 0f 58 d7       	addpd  %xmm7,%xmm10
   20d5c:	66 0f 28 15 fc 4a fe 	movapd -0x1b504(%rip),%xmm2        # 5860 <std::thread::current::id::ID+0x4be8>
   20d63:	ff 
   20d64:	66 44 0f 59 ca       	mulpd  %xmm2,%xmm9
   20d69:	66 44 0f 59 d2       	mulpd  %xmm2,%xmm10
   20d6e:	66 0f 29 b4 24 40 01 	movapd %xmm6,0x140(%rsp)
   20d75:	00 00 
   20d77:	66 0f 28 d6          	movapd %xmm6,%xmm2
   20d7b:	66 0f c2 d0 00       	cmpeqpd %xmm0,%xmm2
   20d80:	66 45 0f 28 eb       	movapd %xmm11,%xmm13
   20d85:	66 44 0f c2 e8 00    	cmpeqpd %xmm0,%xmm13
   20d8b:	66 45 0f 28 c5       	movapd %xmm13,%xmm8
   20d90:	66 45 0f 55 eb       	andnpd %xmm11,%xmm13
   20d95:	66 44 0f c2 d8 04    	cmpneqpd %xmm0,%xmm11
   20d9b:	66 44 0f 54 da       	andpd  %xmm2,%xmm11
   20da0:	66 44 0f 28 f2       	movapd %xmm2,%xmm14
   20da5:	66 0f 54 d4          	andpd  %xmm4,%xmm2
   20da9:	66 44 0f 55 f6       	andnpd %xmm6,%xmm14
   20dae:	66 44 0f 56 f2       	orpd   %xmm2,%xmm14
   20db3:	66 44 0f c2 f8 00    	cmpeqpd %xmm0,%xmm15
   20db9:	66 41 0f 28 cf       	movapd %xmm15,%xmm1
   20dbe:	66 0f 54 cc          	andpd  %xmm4,%xmm1
   20dc2:	66 41 0f 28 d9       	movapd %xmm9,%xmm3
   20dc7:	66 0f c2 d8 00       	cmpeqpd %xmm0,%xmm3
   20dcc:	66 41 0f 28 f2       	movapd %xmm10,%xmm6
   20dd1:	66 0f c2 f0 00       	cmpeqpd %xmm0,%xmm6
   20dd6:	66 0f 28 eb          	movapd %xmm3,%xmm5
   20dda:	66 0f 54 ec          	andpd  %xmm4,%xmm5
   20dde:	66 44 0f 28 e6       	movapd %xmm6,%xmm12
   20de3:	66 44 0f 54 e4       	andpd  %xmm4,%xmm12
   20de8:	66 0f 28 d7          	movapd %xmm7,%xmm2
   20dec:	66 0f c2 d0 00       	cmpeqpd %xmm0,%xmm2
   20df1:	66 44 0f 54 c4       	andpd  %xmm4,%xmm8
   20df6:	66 0f 54 e2          	andpd  %xmm2,%xmm4
   20dfa:	66 0f 55 d7          	andnpd %xmm7,%xmm2
   20dfe:	66 0f c2 f8 04       	cmpneqpd %xmm0,%xmm7
   20e03:	66 41 0f 54 ff       	andpd  %xmm15,%xmm7
   20e08:	66 0f 29 bc 24 e0 00 	movapd %xmm7,0xe0(%rsp)
   20e0f:	00 00 
   20e11:	66 0f 28 7c 24 70    	movapd 0x70(%rsp),%xmm7
   20e17:	66 44 0f 55 ff       	andnpd %xmm7,%xmm15
   20e1c:	66 44 0f 56 f9       	orpd   %xmm1,%xmm15
   20e21:	66 41 0f 55 d9       	andnpd %xmm9,%xmm3
   20e26:	66 0f 56 dd          	orpd   %xmm5,%xmm3
   20e2a:	66 41 0f 55 f2       	andnpd %xmm10,%xmm6
   20e2f:	66 41 0f 56 f4       	orpd   %xmm12,%xmm6
   20e34:	66 45 0f 56 e8       	orpd   %xmm8,%xmm13
   20e39:	66 0f 56 d4          	orpd   %xmm4,%xmm2
   20e3d:	66 0f 28 8c 24 40 01 	movapd 0x140(%rsp),%xmm1
   20e44:	00 00 
   20e46:	66 0f c2 c8 04       	cmpneqpd %xmm0,%xmm1
   20e4b:	66 0f 28 64 24 30    	movapd 0x30(%rsp),%xmm4
   20e51:	66 0f 54 e1          	andpd  %xmm1,%xmm4
   20e55:	66 0f 29 64 24 30    	movapd %xmm4,0x30(%rsp)
   20e5b:	66 0f c2 f8 04       	cmpneqpd %xmm0,%xmm7
   20e60:	66 0f 28 4c 24 10    	movapd 0x10(%rsp),%xmm1
   20e66:	66 0f 54 cf          	andpd  %xmm7,%xmm1
   20e6a:	66 0f 29 4c 24 10    	movapd %xmm1,0x10(%rsp)
   20e70:	66 41 0f 28 e1       	movapd %xmm9,%xmm4
   20e75:	66 41 0f 5e e6       	divpd  %xmm14,%xmm4
   20e7a:	66 41 0f 28 ca       	movapd %xmm10,%xmm1
   20e7f:	66 41 0f 5e cf       	divpd  %xmm15,%xmm1
   20e84:	66 44 0f 28 bc 24 b0 	movapd 0xb0(%rsp),%xmm15
   20e8b:	00 00 00 
   20e8e:	66 44 0f 28 35 e9 48 	movapd -0x1b717(%rip),%xmm14        # 5780 <std::thread::current::id::ID+0x4b08>
   20e95:	fe ff 
   20e97:	66 0f 28 bc 24 80 00 	movapd 0x80(%rsp),%xmm7
   20e9e:	00 00 
   20ea0:	66 0f 28 ef          	movapd %xmm7,%xmm5
   20ea4:	66 41 0f 57 ee       	xorpd  %xmm14,%xmm5
   20ea9:	66 41 0f 5e ed       	divpd  %xmm13,%xmm5
   20eae:	66 44 0f 28 6c 24 60 	movapd 0x60(%rsp),%xmm13
   20eb5:	66 44 0f 28 04 24    	movapd (%rsp),%xmm8
   20ebb:	66 45 0f 28 e0       	movapd %xmm8,%xmm12
   20ec0:	66 45 0f 57 e6       	xorpd  %xmm14,%xmm12
   20ec5:	66 44 0f 5e e2       	divpd  %xmm2,%xmm12
   20eca:	66 41 0f 54 eb       	andpd  %xmm11,%xmm5
   20ecf:	66 44 0f 28 35 68 48 	movapd -0x1b798(%rip),%xmm14        # 5740 <std::thread::current::id::ID+0x4ac8>
   20ed6:	fe ff 
   20ed8:	66 45 0f 55 de       	andnpd %xmm14,%xmm11
   20edd:	66 44 0f 56 dd       	orpd   %xmm5,%xmm11
   20ee2:	66 0f 28 94 24 e0 00 	movapd 0xe0(%rsp),%xmm2
   20ee9:	00 00 
   20eeb:	66 44 0f 54 e2       	andpd  %xmm2,%xmm12
   20ef0:	66 41 0f 55 d6       	andnpd %xmm14,%xmm2
   20ef5:	66 41 0f 56 d4       	orpd   %xmm12,%xmm2
   20efa:	66 0f 28 ef          	movapd %xmm7,%xmm5
   20efe:	66 0f 28 7c 24 30    	movapd 0x30(%rsp),%xmm7
   20f04:	66 0f 54 e7          	andpd  %xmm7,%xmm4
   20f08:	66 44 0f c2 c8 04    	cmpneqpd %xmm0,%xmm9
   20f0e:	66 44 0f 54 cf       	andpd  %xmm7,%xmm9
   20f13:	66 41 0f 55 fb       	andnpd %xmm11,%xmm7
   20f18:	66 0f 56 fc          	orpd   %xmm4,%xmm7
   20f1c:	66 44 0f 28 5c 24 10 	movapd 0x10(%rsp),%xmm11
   20f23:	66 41 0f 54 cb       	andpd  %xmm11,%xmm1
   20f28:	66 44 0f c2 d0 04    	cmpneqpd %xmm0,%xmm10
   20f2e:	66 45 0f 54 d3       	andpd  %xmm11,%xmm10
   20f33:	66 44 0f 55 da       	andnpd %xmm2,%xmm11
   20f38:	66 44 0f 56 d9       	orpd   %xmm1,%xmm11
   20f3d:	66 0f 28 cd          	movapd %xmm5,%xmm1
   20f41:	66 0f 5e cb          	divpd  %xmm3,%xmm1
   20f45:	66 41 0f 28 d0       	movapd %xmm8,%xmm2
   20f4a:	66 0f 5e d6          	divpd  %xmm6,%xmm2
   20f4e:	66 41 0f 54 c9       	andpd  %xmm9,%xmm1
   20f53:	66 45 0f 55 ce       	andnpd %xmm14,%xmm9
   20f58:	66 44 0f 56 c9       	orpd   %xmm1,%xmm9
   20f5d:	66 41 0f 54 d2       	andpd  %xmm10,%xmm2
   20f62:	66 45 0f 55 d6       	andnpd %xmm14,%xmm10
   20f67:	66 44 0f 56 d2       	orpd   %xmm2,%xmm10
   20f6c:	66 45 0f 57 c0       	xorpd  %xmm8,%xmm8
   20f71:	66 44 0f c2 c7 01    	cmpltpd %xmm7,%xmm8
   20f77:	66 41 0f 54 f8       	andpd  %xmm8,%xmm7
   20f7c:	66 45 0f 55 c6       	andnpd %xmm14,%xmm8
   20f81:	66 44 0f 56 c7       	orpd   %xmm7,%xmm8
   20f86:	66 45 0f 57 e4       	xorpd  %xmm12,%xmm12
   20f8b:	66 45 0f c2 e3 01    	cmpltpd %xmm11,%xmm12
   20f91:	66 45 0f 54 dc       	andpd  %xmm12,%xmm11
   20f96:	66 45 0f 55 e6       	andnpd %xmm14,%xmm12
   20f9b:	66 45 0f 56 e3       	orpd   %xmm11,%xmm12
   20fa0:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   20fa4:	66 41 0f c2 c9 01    	cmpltpd %xmm9,%xmm1
   20faa:	66 44 0f 54 c9       	andpd  %xmm1,%xmm9
   20faf:	66 41 0f 55 ce       	andnpd %xmm14,%xmm1
   20fb4:	66 41 0f 56 c9       	orpd   %xmm9,%xmm1
   20fb9:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   20fbd:	66 41 0f c2 d2 01    	cmpltpd %xmm10,%xmm2
   20fc3:	66 44 0f 54 d2       	andpd  %xmm2,%xmm10
   20fc8:	66 41 0f 55 d6       	andnpd %xmm14,%xmm2
   20fcd:	66 41 0f 56 d2       	orpd   %xmm10,%xmm2
   20fd2:	66 41 0f 28 d8       	movapd %xmm8,%xmm3
   20fd7:	66 0f 5d d9          	minpd  %xmm1,%xmm3
   20fdb:	66 0f 29 9c 24 30 01 	movapd %xmm3,0x130(%rsp)
   20fe2:	00 00 
   20fe4:	66 44 0f 5f c1       	maxpd  %xmm1,%xmm8
   20fe9:	66 41 0f 28 cc       	movapd %xmm12,%xmm1
   20fee:	66 0f 5d ca          	minpd  %xmm2,%xmm1
   20ff2:	66 0f 29 8c 24 20 01 	movapd %xmm1,0x120(%rsp)
   20ff9:	00 00 
   20ffb:	66 44 0f 5f e2       	maxpd  %xmm2,%xmm12
   21000:	66 41 0f 28 ef       	movapd %xmm15,%xmm5
   21005:	66 0f c2 e8 04       	cmpneqpd %xmm0,%xmm5
   2100a:	66 0f 28 35 0e 42 fe 	movapd -0x1bdf2(%rip),%xmm6        # 5220 <std::thread::current::id::ID+0x45a8>
   21011:	ff 
   21012:	66 41 0f 28 e7       	movapd %xmm15,%xmm4
   21017:	66 0f 54 e6          	andpd  %xmm6,%xmm4
   2101b:	66 44 0f 28 b4 24 80 	movapd 0x80(%rsp),%xmm14
   21022:	00 00 00 
   21025:	66 41 0f 28 de       	movapd %xmm14,%xmm3
   2102a:	66 0f 54 de          	andpd  %xmm6,%xmm3
   2102e:	66 0f 28 cd          	movapd %xmm5,%xmm1
   21032:	66 0f 54 cc          	andpd  %xmm4,%xmm1
   21036:	66 0f 55 eb          	andnpd %xmm3,%xmm5
   2103a:	66 0f 56 e9          	orpd   %xmm1,%xmm5
   2103e:	66 41 0f 28 cd       	movapd %xmm13,%xmm1
   21043:	66 0f c2 c8 04       	cmpneqpd %xmm0,%xmm1
   21048:	66 45 0f 28 dd       	movapd %xmm13,%xmm11
   2104d:	66 44 0f 54 de       	andpd  %xmm6,%xmm11
   21052:	66 0f 28 3c 24       	movapd (%rsp),%xmm7
   21057:	66 0f 54 fe          	andpd  %xmm6,%xmm7
   2105b:	66 44 0f 28 c9       	movapd %xmm1,%xmm9
   21060:	66 45 0f 54 cb       	andpd  %xmm11,%xmm9
   21065:	66 0f 55 cf          	andnpd %xmm7,%xmm1
   21069:	66 41 0f 56 c9       	orpd   %xmm9,%xmm1
   2106e:	66 44 0f 28 94 24 c0 	movapd 0xc0(%rsp),%xmm10
   21075:	00 00 00 
   21078:	66 45 0f 28 ca       	movapd %xmm10,%xmm9
   2107d:	66 44 0f c2 c8 04    	cmpneqpd %xmm0,%xmm9
   21083:	66 44 0f 54 d6       	andpd  %xmm6,%xmm10
   21088:	66 45 0f 54 d1       	andpd  %xmm9,%xmm10
   2108d:	66 44 0f 55 cd       	andnpd %xmm5,%xmm9
   21092:	66 45 0f 56 ca       	orpd   %xmm10,%xmm9
   21097:	66 0f 28 94 24 f0 00 	movapd 0xf0(%rsp),%xmm2
   2109e:	00 00 
   210a0:	66 0f 28 ea          	movapd %xmm2,%xmm5
   210a4:	66 0f c2 e8 04       	cmpneqpd %xmm0,%xmm5
   210a9:	66 44 0f 28 d2       	movapd %xmm2,%xmm10
   210ae:	66 44 0f 54 d6       	andpd  %xmm6,%xmm10
   210b3:	66 44 0f 54 d5       	andpd  %xmm5,%xmm10
   210b8:	66 0f 55 e9          	andnpd %xmm1,%xmm5
   210bc:	66 41 0f 56 ea       	orpd   %xmm10,%xmm5
   210c1:	66 0f 28 0d 07 42 fe 	movapd -0x1bdf9(%rip),%xmm1        # 52d0 <std::thread::current::id::ID+0x4658>
   210c8:	ff 
   210c9:	66 44 0f 5f c9       	maxpd  %xmm1,%xmm9
   210ce:	66 0f 5f e9          	maxpd  %xmm1,%xmm5
   210d2:	66 0f 5f e3          	maxpd  %xmm3,%xmm4
   210d6:	66 44 0f 5f df       	maxpd  %xmm7,%xmm11
   210db:	66 0f 28 bc 24 90 00 	movapd 0x90(%rsp),%xmm7
   210e2:	00 00 
   210e4:	66 0f 28 cf          	movapd %xmm7,%xmm1
   210e8:	66 0f 54 ce          	andpd  %xmm6,%xmm1
   210ec:	66 0f 5f e1          	maxpd  %xmm1,%xmm4
   210f0:	66 41 0f 5e e1       	divpd  %xmm9,%xmm4
   210f5:	66 0f 28 5c 24 20    	movapd 0x20(%rsp),%xmm3
   210fb:	66 0f 54 f3          	andpd  %xmm3,%xmm6
   210ff:	66 44 0f 5f de       	maxpd  %xmm6,%xmm11
   21104:	66 41 0f 28 f6       	movapd %xmm14,%xmm6
   21109:	66 44 0f 5e dd       	divpd  %xmm5,%xmm11
   2110e:	66 0f 28 0d 7a 45 fe 	movapd -0x1ba86(%rip),%xmm1        # 5690 <std::thread::current::id::ID+0x4a18>
   21115:	ff 
   21116:	66 0f 58 e1          	addpd  %xmm1,%xmm4
   2111a:	66 44 0f 58 d9       	addpd  %xmm1,%xmm11
   2111f:	66 0f 28 cf          	movapd %xmm7,%xmm1
   21123:	66 0f 28 ef          	movapd %xmm7,%xmm5
   21127:	66 44 0f 28 15 50 46 	movapd -0x1b9b0(%rip),%xmm10        # 5780 <std::thread::current::id::ID+0x4b08>
   2112e:	fe ff 
   21130:	66 41 0f 57 ca       	xorpd  %xmm10,%xmm1
   21135:	66 0f 57 ff          	xorpd  %xmm7,%xmm7
   21139:	66 0f c2 f9 01       	cmpltpd %xmm1,%xmm7
   2113e:	66 44 0f 28 8c 24 c0 	movapd 0xc0(%rsp),%xmm9
   21145:	00 00 00 
   21148:	66 45 0f 57 ca       	xorpd  %xmm10,%xmm9
   2114d:	66 41 0f 57 d2       	xorpd  %xmm10,%xmm2
   21152:	66 44 0f 57 d3       	xorpd  %xmm3,%xmm10
   21157:	66 45 0f 57 f6       	xorpd  %xmm14,%xmm14
   2115c:	66 45 0f c2 f2 01    	cmpltpd %xmm10,%xmm14
   21162:	66 0f 28 9c 24 30 01 	movapd 0x130(%rsp),%xmm3
   21169:	00 00 
   2116b:	66 0f 5d dc          	minpd  %xmm4,%xmm3
   2116f:	66 0f 28 cb          	movapd %xmm3,%xmm1
   21173:	66 41 0f 59 c9       	mulpd  %xmm9,%xmm1
   21178:	66 41 0f 5c cf       	subpd  %xmm15,%xmm1
   2117d:	66 0f 59 cb          	mulpd  %xmm3,%xmm1
   21181:	66 0f 5c ce          	subpd  %xmm6,%xmm1
   21185:	66 0f 59 cb          	mulpd  %xmm3,%xmm1
   21189:	66 0f 5c cd          	subpd  %xmm5,%xmm1
   2118d:	66 0f 57 ed          	xorpd  %xmm5,%xmm5
   21191:	66 0f c2 e9 01       	cmpltpd %xmm1,%xmm5
   21196:	66 44 0f 28 94 24 20 	movapd 0x120(%rsp),%xmm10
   2119d:	01 00 00 
   211a0:	66 45 0f 5d d3       	minpd  %xmm11,%xmm10
   211a5:	66 41 0f 28 ca       	movapd %xmm10,%xmm1
   211aa:	66 0f 29 54 24 30    	movapd %xmm2,0x30(%rsp)
   211b0:	66 0f 59 ca          	mulpd  %xmm2,%xmm1
   211b4:	66 41 0f 5c cd       	subpd  %xmm13,%xmm1
   211b9:	66 41 0f 59 ca       	mulpd  %xmm10,%xmm1
   211be:	66 0f 5c 0c 24       	subpd  (%rsp),%xmm1
   211c3:	66 41 0f 59 ca       	mulpd  %xmm10,%xmm1
   211c8:	66 0f 5c 4c 24 20    	subpd  0x20(%rsp),%xmm1
   211ce:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   211d2:	66 0f c2 d1 01       	cmpltpd %xmm1,%xmm2
   211d7:	66 0f 28 0d 61 45 fe 	movapd -0x1ba9f(%rip),%xmm1        # 5740 <std::thread::current::id::ID+0x4ac8>
   211de:	ff 
   211df:	66 0f 55 f9          	andnpd %xmm1,%xmm7
   211e3:	66 44 0f 55 f1       	andnpd %xmm1,%xmm14
   211e8:	66 44 0f 29 84 24 10 	movapd %xmm8,0x110(%rsp)
   211ef:	01 00 00 
   211f2:	66 0f 29 a4 24 90 01 	movapd %xmm4,0x190(%rsp)
   211f9:	00 00 
   211fb:	66 44 0f 5d c4       	minpd  %xmm4,%xmm8
   21200:	66 44 0f 29 a4 24 00 	movapd %xmm12,0x100(%rsp)
   21207:	01 00 00 
   2120a:	66 41 0f 28 e4       	movapd %xmm12,%xmm4
   2120f:	66 41 0f 5d e3       	minpd  %xmm11,%xmm4
   21214:	66 0f 28 0d 24 45 fe 	movapd -0x1badc(%rip),%xmm1        # 5740 <std::thread::current::id::ID+0x4ac8>
   2121b:	ff 
   2121c:	66 0f 29 bc 24 d0 00 	movapd %xmm7,0xd0(%rsp)
   21223:	00 00 
   21225:	66 44 0f 28 e7       	movapd %xmm7,%xmm12
   2122a:	66 44 0f c2 e1 00    	cmpeqpd %xmm1,%xmm12
   21230:	66 44 0f 29 74 24 70 	movapd %xmm14,0x70(%rsp)
   21237:	66 44 0f c2 f1 00    	cmpeqpd %xmm1,%xmm14
   2123d:	66 41 0f 54 ec       	andpd  %xmm12,%xmm5
   21242:	66 41 0f 54 d6       	andpd  %xmm14,%xmm2
   21247:	66 0f 50 c5          	movmskpd %xmm5,%eax
   2124b:	66 0f 50 ca          	movmskpd %xmm2,%ecx
   2124f:	c1 e1 02             	shl    $0x2,%ecx
   21252:	83 e1 04             	and    $0x4,%ecx
   21255:	09 c1                	or     %eax,%ecx
   21257:	66 44 0f 29 4c 24 10 	movapd %xmm9,0x10(%rsp)
   2125e:	66 44 0f 29 9c 24 70 	movapd %xmm11,0x170(%rsp)
   21265:	01 00 00 
   21268:	0f 84 e9 01 00 00    	je     21457 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xb67>
   2126e:	66 0f 29 a4 24 80 01 	movapd %xmm4,0x180(%rsp)
   21275:	00 00 
   21277:	b8 60 00 00 00       	mov    $0x60,%eax
   2127c:	66 45 0f 28 e2       	movapd %xmm10,%xmm12
   21281:	66 44 0f 28 db       	movapd %xmm3,%xmm11
   21286:	66 45 0f 57 f6       	xorpd  %xmm14,%xmm14
   2128b:	66 0f 29 ac 24 e0 00 	movapd %xmm5,0xe0(%rsp)
   21292:	00 00 
   21294:	66 0f 29 94 24 40 01 	movapd %xmm2,0x140(%rsp)
   2129b:	00 00 
   2129d:	0f 1f 00             	nopl   (%rax)
   212a0:	66 41 0f 28 cb       	movapd %xmm11,%xmm1
   212a5:	66 41 0f 5c ce       	subpd  %xmm14,%xmm1
   212aa:	66 41 0f 28 f4       	movapd %xmm12,%xmm6
   212af:	66 0f 5c f0          	subpd  %xmm0,%xmm6
   212b3:	66 0f 28 15 c5 40 fe 	movapd -0x1bf3b(%rip),%xmm2        # 5380 <std::thread::current::id::ID+0x4708>
   212ba:	ff 
   212bb:	66 0f 59 ca          	mulpd  %xmm2,%xmm1
   212bf:	66 0f 59 f2          	mulpd  %xmm2,%xmm6
   212c3:	66 41 0f 58 ce       	addpd  %xmm14,%xmm1
   212c8:	66 0f 58 f0          	addpd  %xmm0,%xmm6
   212cc:	66 0f 28 d1          	movapd %xmm1,%xmm2
   212d0:	66 41 0f 59 d1       	mulpd  %xmm9,%xmm2
   212d5:	66 44 0f 28 ce       	movapd %xmm6,%xmm9
   212da:	66 44 0f 59 4c 24 30 	mulpd  0x30(%rsp),%xmm9
   212e1:	66 41 0f 5c d7       	subpd  %xmm15,%xmm2
   212e6:	66 45 0f 5c cd       	subpd  %xmm13,%xmm9
   212eb:	66 0f 59 d1          	mulpd  %xmm1,%xmm2
   212ef:	66 44 0f 59 ce       	mulpd  %xmm6,%xmm9
   212f4:	66 0f 5c 94 24 80 00 	subpd  0x80(%rsp),%xmm2
   212fb:	00 00 
   212fd:	66 44 0f 5c 0c 24    	subpd  (%rsp),%xmm9
   21303:	66 0f 59 d1          	mulpd  %xmm1,%xmm2
   21307:	66 44 0f 59 ce       	mulpd  %xmm6,%xmm9
   2130c:	66 0f 5c 94 24 90 00 	subpd  0x90(%rsp),%xmm2
   21313:	00 00 
   21315:	66 44 0f 5c 4c 24 20 	subpd  0x20(%rsp),%xmm9
   2131c:	66 0f 57 ed          	xorpd  %xmm5,%xmm5
   21320:	66 0f c2 ea 01       	cmpltpd %xmm2,%xmm5
   21325:	66 41 0f 28 ff       	movapd %xmm15,%xmm7
   2132a:	66 45 0f 57 ff       	xorpd  %xmm15,%xmm15
   2132f:	66 45 0f c2 f9 01    	cmpltpd %xmm9,%xmm15
   21335:	66 0f 28 e0          	movapd %xmm0,%xmm4
   21339:	66 0f 28 84 24 e0 00 	movapd 0xe0(%rsp),%xmm0
   21340:	00 00 
   21342:	66 44 0f 28 e8       	movapd %xmm0,%xmm13
   21347:	66 44 0f 54 ed       	andpd  %xmm5,%xmm13
   2134c:	66 41 0f 28 d5       	movapd %xmm13,%xmm2
   21351:	66 45 0f 55 eb       	andnpd %xmm11,%xmm13
   21356:	66 44 0f 28 9c 24 40 	movapd 0x140(%rsp),%xmm11
   2135d:	01 00 00 
   21360:	66 45 0f 28 cb       	movapd %xmm11,%xmm9
   21365:	66 45 0f 54 cf       	andpd  %xmm15,%xmm9
   2136a:	66 0f 54 d1          	andpd  %xmm1,%xmm2
   2136e:	66 44 0f 56 ea       	orpd   %xmm2,%xmm13
   21373:	66 41 0f 28 d1       	movapd %xmm9,%xmm2
   21378:	66 45 0f 55 cc       	andnpd %xmm12,%xmm9
   2137d:	66 0f 54 d6          	andpd  %xmm6,%xmm2
   21381:	66 44 0f 56 ca       	orpd   %xmm2,%xmm9
   21386:	66 0f 55 e8          	andnpd %xmm0,%xmm5
   2138a:	66 0f 54 cd          	andpd  %xmm5,%xmm1
   2138e:	66 41 0f 55 ee       	andnpd %xmm14,%xmm5
   21393:	66 44 0f 28 f5       	movapd %xmm5,%xmm14
   21398:	66 44 0f 56 f1       	orpd   %xmm1,%xmm14
   2139d:	66 45 0f 55 fb       	andnpd %xmm11,%xmm15
   213a2:	66 41 0f 54 f7       	andpd  %xmm15,%xmm6
   213a7:	66 44 0f 55 fc       	andnpd %xmm4,%xmm15
   213ac:	66 41 0f 28 c7       	movapd %xmm15,%xmm0
   213b1:	66 44 0f 28 ff       	movapd %xmm7,%xmm15
   213b6:	66 0f 56 c6          	orpd   %xmm6,%xmm0
   213ba:	66 45 0f 28 e1       	movapd %xmm9,%xmm12
   213bf:	66 44 0f 28 4c 24 10 	movapd 0x10(%rsp),%xmm9
   213c6:	66 45 0f 28 dd       	movapd %xmm13,%xmm11
   213cb:	66 44 0f 28 6c 24 60 	movapd 0x60(%rsp),%xmm13
   213d2:	48 ff c8             	dec    %rax
   213d5:	0f 85 c5 fe ff ff    	jne    212a0 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x9b0>
   213db:	66 0f 28 8c 24 e0 00 	movapd 0xe0(%rsp),%xmm1
   213e2:	00 00 
   213e4:	66 44 0f 54 f1       	andpd  %xmm1,%xmm14
   213e9:	66 0f 55 8c 24 d0 00 	andnpd 0xd0(%rsp),%xmm1
   213f0:	00 00 
   213f2:	66 41 0f 56 ce       	orpd   %xmm14,%xmm1
   213f7:	66 0f 28 94 24 40 01 	movapd 0x140(%rsp),%xmm2
   213fe:	00 00 
   21400:	66 0f 54 c2          	andpd  %xmm2,%xmm0
   21404:	66 0f 55 54 24 70    	andnpd 0x70(%rsp),%xmm2
   2140a:	66 0f 56 d0          	orpd   %xmm0,%xmm2
   2140e:	66 44 0f 28 e1       	movapd %xmm1,%xmm12
   21413:	66 0f 28 05 25 43 fe 	movapd -0x1bcdb(%rip),%xmm0        # 5740 <std::thread::current::id::ID+0x4ac8>
   2141a:	ff 
   2141b:	66 44 0f c2 e0 00    	cmpeqpd %xmm0,%xmm12
   21421:	66 44 0f 28 f2       	movapd %xmm2,%xmm14
   21426:	66 44 0f c2 f0 00    	cmpeqpd %xmm0,%xmm14
   2142c:	66 0f 29 54 24 70    	movapd %xmm2,0x70(%rsp)
   21432:	66 0f 29 8c 24 d0 00 	movapd %xmm1,0xd0(%rsp)
   21439:	00 00 
   2143b:	66 0f 28 b4 24 80 00 	movapd 0x80(%rsp),%xmm6
   21442:	00 00 
   21444:	66 44 0f 28 9c 24 70 	movapd 0x170(%rsp),%xmm11
   2144b:	01 00 00 
   2144e:	66 0f 28 a4 24 80 01 	movapd 0x180(%rsp),%xmm4
   21455:	00 00 
   21457:	66 41 0f 28 c0       	movapd %xmm8,%xmm0
   2145c:	66 41 0f 59 c1       	mulpd  %xmm9,%xmm0
   21461:	66 0f 28 cc          	movapd %xmm4,%xmm1
   21465:	66 0f 28 54 24 30    	movapd 0x30(%rsp),%xmm2
   2146b:	66 0f 59 ca          	mulpd  %xmm2,%xmm1
   2146f:	66 41 0f 5c c7       	subpd  %xmm15,%xmm0
   21474:	66 41 0f 5c cd       	subpd  %xmm13,%xmm1
   21479:	66 41 0f 59 c0       	mulpd  %xmm8,%xmm0
   2147e:	66 0f 59 cc          	mulpd  %xmm4,%xmm1
   21482:	66 0f 5c c6          	subpd  %xmm6,%xmm0
   21486:	66 0f 5c 0c 24       	subpd  (%rsp),%xmm1
   2148b:	66 41 0f 59 c0       	mulpd  %xmm8,%xmm0
   21490:	66 0f 59 cc          	mulpd  %xmm4,%xmm1
   21494:	66 0f 5c 84 24 90 00 	subpd  0x90(%rsp),%xmm0
   2149b:	00 00 
   2149d:	66 0f 5c 4c 24 20    	subpd  0x20(%rsp),%xmm1
   214a3:	66 0f 57 ed          	xorpd  %xmm5,%xmm5
   214a7:	66 0f 57 ff          	xorpd  %xmm7,%xmm7
   214ab:	66 0f c2 f8 01       	cmpltpd %xmm0,%xmm7
   214b0:	66 45 0f 57 ed       	xorpd  %xmm13,%xmm13
   214b5:	66 44 0f c2 e9 01    	cmpltpd %xmm1,%xmm13
   214bb:	66 41 0f 54 fc       	andpd  %xmm12,%xmm7
   214c0:	66 45 0f 54 ee       	andpd  %xmm14,%xmm13
   214c5:	66 0f 50 c7          	movmskpd %xmm7,%eax
   214c9:	66 41 0f 50 cd       	movmskpd %xmm13,%ecx
   214ce:	c1 e1 02             	shl    $0x2,%ecx
   214d1:	83 e1 04             	and    $0x4,%ecx
   214d4:	09 c1                	or     %eax,%ecx
   214d6:	0f 84 c4 01 00 00    	je     216a0 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xdb0>
   214dc:	b8 60 00 00 00       	mov    $0x60,%eax
   214e1:	66 44 0f 28 cc       	movapd %xmm4,%xmm9
   214e6:	66 45 0f 28 d8       	movapd %xmm8,%xmm11
   214eb:	66 44 0f 28 7c 24 60 	movapd 0x60(%rsp),%xmm15
   214f2:	66 0f 28 44 24 20    	movapd 0x20(%rsp),%xmm0
   214f8:	66 44 0f 28 b4 24 90 	movapd 0x90(%rsp),%xmm14
   214ff:	00 00 00 
   21502:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   21509:	1f 84 00 00 00 00 00 
   21510:	66 41 0f 28 cb       	movapd %xmm11,%xmm1
   21515:	66 0f 5c cb          	subpd  %xmm3,%xmm1
   21519:	66 41 0f 28 f1       	movapd %xmm9,%xmm6
   2151e:	66 41 0f 5c f2       	subpd  %xmm10,%xmm6
   21523:	66 0f 28 2d 55 3e fe 	movapd -0x1c1ab(%rip),%xmm5        # 5380 <std::thread::current::id::ID+0x4708>
   2152a:	ff 
   2152b:	66 0f 59 cd          	mulpd  %xmm5,%xmm1
   2152f:	66 0f 59 f5          	mulpd  %xmm5,%xmm6
   21533:	66 0f 58 cb          	addpd  %xmm3,%xmm1
   21537:	66 41 0f 58 f2       	addpd  %xmm10,%xmm6
   2153c:	66 44 0f 28 e1       	movapd %xmm1,%xmm12
   21541:	66 44 0f 59 64 24 10 	mulpd  0x10(%rsp),%xmm12
   21548:	66 0f 28 ee          	movapd %xmm6,%xmm5
   2154c:	66 0f 59 ea          	mulpd  %xmm2,%xmm5
   21550:	66 44 0f 5c a4 24 b0 	subpd  0xb0(%rsp),%xmm12
   21557:	00 00 00 
   2155a:	66 41 0f 5c ef       	subpd  %xmm15,%xmm5
   2155f:	66 44 0f 59 e1       	mulpd  %xmm1,%xmm12
   21564:	66 0f 59 ee          	mulpd  %xmm6,%xmm5
   21568:	66 44 0f 5c a4 24 80 	subpd  0x80(%rsp),%xmm12
   2156f:	00 00 00 
   21572:	66 0f 5c 2c 24       	subpd  (%rsp),%xmm5
   21577:	66 44 0f 59 e1       	mulpd  %xmm1,%xmm12
   2157c:	66 0f 59 ee          	mulpd  %xmm6,%xmm5
   21580:	66 45 0f 5c e6       	subpd  %xmm14,%xmm12
   21585:	66 0f 5c e8          	subpd  %xmm0,%xmm5
   21589:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   2158d:	66 41 0f c2 d4 01    	cmpltpd %xmm12,%xmm2
   21593:	66 45 0f 57 f6       	xorpd  %xmm14,%xmm14
   21598:	66 44 0f c2 f5 01    	cmpltpd %xmm5,%xmm14
   2159e:	66 44 0f 28 e7       	movapd %xmm7,%xmm12
   215a3:	66 44 0f 54 e2       	andpd  %xmm2,%xmm12
   215a8:	66 41 0f 28 ec       	movapd %xmm12,%xmm5
   215ad:	66 45 0f 55 e3       	andnpd %xmm11,%xmm12
   215b2:	66 45 0f 28 dd       	movapd %xmm13,%xmm11
   215b7:	66 45 0f 54 de       	andpd  %xmm14,%xmm11
   215bc:	66 0f 54 e9          	andpd  %xmm1,%xmm5
   215c0:	66 44 0f 56 e5       	orpd   %xmm5,%xmm12
   215c5:	66 41 0f 28 eb       	movapd %xmm11,%xmm5
   215ca:	66 45 0f 55 d9       	andnpd %xmm9,%xmm11
   215cf:	66 0f 54 ee          	andpd  %xmm6,%xmm5
   215d3:	66 44 0f 56 dd       	orpd   %xmm5,%xmm11
   215d8:	66 0f 55 d7          	andnpd %xmm7,%xmm2
   215dc:	66 0f 54 ca          	andpd  %xmm2,%xmm1
   215e0:	66 0f 55 d3          	andnpd %xmm3,%xmm2
   215e4:	66 0f 28 da          	movapd %xmm2,%xmm3
   215e8:	66 0f 28 54 24 30    	movapd 0x30(%rsp),%xmm2
   215ee:	66 0f 56 d9          	orpd   %xmm1,%xmm3
   215f2:	66 45 0f 55 f5       	andnpd %xmm13,%xmm14
   215f7:	66 41 0f 54 f6       	andpd  %xmm14,%xmm6
   215fc:	66 45 0f 55 f2       	andnpd %xmm10,%xmm14
   21601:	66 45 0f 28 d6       	movapd %xmm14,%xmm10
   21606:	66 44 0f 28 b4 24 90 	movapd 0x90(%rsp),%xmm14
   2160d:	00 00 00 
   21610:	66 44 0f 56 d6       	orpd   %xmm6,%xmm10
   21615:	66 45 0f 28 cb       	movapd %xmm11,%xmm9
   2161a:	66 45 0f 28 dc       	movapd %xmm12,%xmm11
   2161f:	48 ff c8             	dec    %rax
   21622:	0f 85 e8 fe ff ff    	jne    21510 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xc20>
   21628:	66 0f 54 df          	andpd  %xmm7,%xmm3
   2162c:	66 0f 55 bc 24 d0 00 	andnpd 0xd0(%rsp),%xmm7
   21633:	00 00 
   21635:	66 0f 56 fb          	orpd   %xmm3,%xmm7
   21639:	66 45 0f 54 d5       	andpd  %xmm13,%xmm10
   2163e:	66 44 0f 55 6c 24 70 	andnpd 0x70(%rsp),%xmm13
   21645:	66 45 0f 56 ea       	orpd   %xmm10,%xmm13
   2164a:	66 44 0f 28 e7       	movapd %xmm7,%xmm12
   2164f:	66 0f 28 05 e9 40 fe 	movapd -0x1bf17(%rip),%xmm0        # 5740 <std::thread::current::id::ID+0x4ac8>
   21656:	ff 
   21657:	66 44 0f c2 e0 00    	cmpeqpd %xmm0,%xmm12
   2165d:	66 45 0f 28 f5       	movapd %xmm13,%xmm14
   21662:	66 44 0f c2 f0 00    	cmpeqpd %xmm0,%xmm14
   21668:	66 44 0f 29 6c 24 70 	movapd %xmm13,0x70(%rsp)
   2166f:	66 0f 29 bc 24 d0 00 	movapd %xmm7,0xd0(%rsp)
   21676:	00 00 
   21678:	66 44 0f 28 bc 24 b0 	movapd 0xb0(%rsp),%xmm15
   2167f:	00 00 00 
   21682:	66 0f 28 b4 24 80 00 	movapd 0x80(%rsp),%xmm6
   21689:	00 00 
   2168b:	66 44 0f 28 9c 24 70 	movapd 0x170(%rsp),%xmm11
   21692:	01 00 00 
   21695:	66 44 0f 28 4c 24 10 	movapd 0x10(%rsp),%xmm9
   2169c:	66 0f 57 ed          	xorpd  %xmm5,%xmm5
   216a0:	66 44 0f 28 94 24 90 	movapd 0x190(%rsp),%xmm10
   216a7:	01 00 00 
   216aa:	66 41 0f 28 c2       	movapd %xmm10,%xmm0
   216af:	66 41 0f 59 c1       	mulpd  %xmm9,%xmm0
   216b4:	66 41 0f 28 cb       	movapd %xmm11,%xmm1
   216b9:	66 0f 59 ca          	mulpd  %xmm2,%xmm1
   216bd:	66 41 0f 5c c7       	subpd  %xmm15,%xmm0
   216c2:	66 0f 5c 4c 24 60    	subpd  0x60(%rsp),%xmm1
   216c8:	66 41 0f 59 c2       	mulpd  %xmm10,%xmm0
   216cd:	66 41 0f 59 cb       	mulpd  %xmm11,%xmm1
   216d2:	66 0f 5c c6          	subpd  %xmm6,%xmm0
   216d6:	66 0f 5c 0c 24       	subpd  (%rsp),%xmm1
   216db:	66 41 0f 59 c2       	mulpd  %xmm10,%xmm0
   216e0:	66 41 0f 59 cb       	mulpd  %xmm11,%xmm1
   216e5:	66 0f 5c 84 24 90 00 	subpd  0x90(%rsp),%xmm0
   216ec:	00 00 
   216ee:	66 0f 5c 4c 24 20    	subpd  0x20(%rsp),%xmm1
   216f4:	66 0f 57 ff          	xorpd  %xmm7,%xmm7
   216f8:	66 0f c2 f8 01       	cmpltpd %xmm0,%xmm7
   216fd:	66 41 0f 54 fc       	andpd  %xmm12,%xmm7
   21702:	66 0f c2 e9 01       	cmpltpd %xmm1,%xmm5
   21707:	66 41 0f 54 ee       	andpd  %xmm14,%xmm5
   2170c:	66 0f 50 c7          	movmskpd %xmm7,%eax
   21710:	66 0f 50 cd          	movmskpd %xmm5,%ecx
   21714:	c1 e1 02             	shl    $0x2,%ecx
   21717:	83 e1 04             	and    $0x4,%ecx
   2171a:	09 c1                	or     %eax,%ecx
   2171c:	0f 84 71 01 00 00    	je     21893 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xfa3>
   21722:	b8 60 00 00 00       	mov    $0x60,%eax
   21727:	66 44 0f 28 7c 24 60 	movapd 0x60(%rsp),%xmm15
   2172e:	66 0f 28 c2          	movapd %xmm2,%xmm0
   21732:	66 44 0f 28 f5       	movapd %xmm5,%xmm14
   21737:	66 44 0f 28 a4 24 90 	movapd 0x90(%rsp),%xmm12
   2173e:	00 00 00 
   21741:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   21748:	0f 1f 84 00 00 00 00 
   2174f:	00 
   21750:	66 41 0f 28 ca       	movapd %xmm10,%xmm1
   21755:	66 41 0f 5c c8       	subpd  %xmm8,%xmm1
   2175a:	66 41 0f 28 eb       	movapd %xmm11,%xmm5
   2175f:	66 0f 5c ec          	subpd  %xmm4,%xmm5
   21763:	66 0f 28 15 15 3c fe 	movapd -0x1c3eb(%rip),%xmm2        # 5380 <std::thread::current::id::ID+0x4708>
   2176a:	ff 
   2176b:	66 0f 59 ca          	mulpd  %xmm2,%xmm1
   2176f:	66 0f 59 ea          	mulpd  %xmm2,%xmm5
   21773:	66 41 0f 58 c8       	addpd  %xmm8,%xmm1
   21778:	66 0f 58 ec          	addpd  %xmm4,%xmm5
   2177c:	66 0f 28 d1          	movapd %xmm1,%xmm2
   21780:	66 41 0f 59 d1       	mulpd  %xmm9,%xmm2
   21785:	66 0f 28 dd          	movapd %xmm5,%xmm3
   21789:	66 0f 59 d8          	mulpd  %xmm0,%xmm3
   2178d:	66 0f 5c 94 24 b0 00 	subpd  0xb0(%rsp),%xmm2
   21794:	00 00 
   21796:	66 41 0f 5c df       	subpd  %xmm15,%xmm3
   2179b:	66 0f 59 d1          	mulpd  %xmm1,%xmm2
   2179f:	66 0f 59 dd          	mulpd  %xmm5,%xmm3
   217a3:	66 0f 5c d6          	subpd  %xmm6,%xmm2
   217a7:	66 0f 5c 1c 24       	subpd  (%rsp),%xmm3
   217ac:	66 0f 59 d1          	mulpd  %xmm1,%xmm2
   217b0:	66 0f 59 dd          	mulpd  %xmm5,%xmm3
   217b4:	66 41 0f 5c d4       	subpd  %xmm12,%xmm2
   217b9:	66 0f 5c 5c 24 20    	subpd  0x20(%rsp),%xmm3
   217bf:	66 45 0f 57 c9       	xorpd  %xmm9,%xmm9
   217c4:	66 44 0f c2 ca 01    	cmpltpd %xmm2,%xmm9
   217ca:	66 44 0f 28 ee       	movapd %xmm6,%xmm13
   217cf:	66 0f 57 f6          	xorpd  %xmm6,%xmm6
   217d3:	66 0f c2 f3 01       	cmpltpd %xmm3,%xmm6
   217d8:	66 0f 28 d7          	movapd %xmm7,%xmm2
   217dc:	66 41 0f 54 d1       	andpd  %xmm9,%xmm2
   217e1:	66 0f 28 da          	movapd %xmm2,%xmm3
   217e5:	66 41 0f 55 d2       	andnpd %xmm10,%xmm2
   217ea:	66 45 0f 28 d6       	movapd %xmm14,%xmm10
   217ef:	66 44 0f 54 d6       	andpd  %xmm6,%xmm10
   217f4:	66 0f 54 d9          	andpd  %xmm1,%xmm3
   217f8:	66 0f 56 d3          	orpd   %xmm3,%xmm2
   217fc:	66 41 0f 28 da       	movapd %xmm10,%xmm3
   21801:	66 45 0f 55 d3       	andnpd %xmm11,%xmm10
   21806:	66 0f 54 dd          	andpd  %xmm5,%xmm3
   2180a:	66 44 0f 56 d3       	orpd   %xmm3,%xmm10
   2180f:	66 44 0f 55 cf       	andnpd %xmm7,%xmm9
   21814:	66 41 0f 54 c9       	andpd  %xmm9,%xmm1
   21819:	66 45 0f 55 c8       	andnpd %xmm8,%xmm9
   2181e:	66 45 0f 28 c1       	movapd %xmm9,%xmm8
   21823:	66 44 0f 28 4c 24 10 	movapd 0x10(%rsp),%xmm9
   2182a:	66 44 0f 56 c1       	orpd   %xmm1,%xmm8
   2182f:	66 41 0f 55 f6       	andnpd %xmm14,%xmm6
   21834:	66 0f 54 ee          	andpd  %xmm6,%xmm5
   21838:	66 0f 55 f4          	andnpd %xmm4,%xmm6
   2183c:	66 0f 28 e6          	movapd %xmm6,%xmm4
   21840:	66 41 0f 28 f5       	movapd %xmm13,%xmm6
   21845:	66 0f 56 e5          	orpd   %xmm5,%xmm4
   21849:	66 45 0f 28 da       	movapd %xmm10,%xmm11
   2184e:	66 44 0f 28 d2       	movapd %xmm2,%xmm10
   21853:	48 ff c8             	dec    %rax
   21856:	0f 85 f4 fe ff ff    	jne    21750 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xe60>
   2185c:	66 44 0f 54 c7       	andpd  %xmm7,%xmm8
   21861:	66 0f 55 bc 24 d0 00 	andnpd 0xd0(%rsp),%xmm7
   21868:	00 00 
   2186a:	66 41 0f 56 f8       	orpd   %xmm8,%xmm7
   2186f:	66 41 0f 54 e6       	andpd  %xmm14,%xmm4
   21874:	66 44 0f 55 74 24 70 	andnpd 0x70(%rsp),%xmm14
   2187b:	66 44 0f 56 f4       	orpd   %xmm4,%xmm14
   21880:	66 44 0f 29 74 24 70 	movapd %xmm14,0x70(%rsp)
   21887:	66 44 0f 28 bc 24 b0 	movapd 0xb0(%rsp),%xmm15
   2188e:	00 00 00 
   21891:	eb 09                	jmp    2189c <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xfac>
   21893:	66 0f 28 bc 24 d0 00 	movapd 0xd0(%rsp),%xmm7
   2189a:	00 00 
   2189c:	66 0f 70 c7 ee       	pshufd $0xee,%xmm7,%xmm0
   218a1:	f2 0f 5d 3d 27 59 fe 	minsd  -0x1a6d9(%rip),%xmm7        # 71d0 <std::thread::current::id::ID+0x6558>
   218a8:	ff 
   218a9:	f2 0f 5d c7          	minsd  %xmm7,%xmm0
   218ad:	66 0f 28 4c 24 70    	movapd 0x70(%rsp),%xmm1
   218b3:	f2 0f 5d c8          	minsd  %xmm0,%xmm1
   218b7:	66 48 0f 7e c8       	movq   %xmm1,%rax
   218bc:	48 b9 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rcx
   218c3:	ff ff 7f 
   218c6:	48 21 c1             	and    %rax,%rcx
   218c9:	41 be 0e 00 00 00    	mov    $0xe,%r14d
   218cf:	48 b8 ff ff ff ff ff 	movabs $0x7fefffffffffffff,%rax
   218d6:	ff ef 7f 
   218d9:	48 39 c1             	cmp    %rax,%rcx
   218dc:	66 44 0f 28 ac 24 f0 	movapd 0xf0(%rsp),%xmm13
   218e3:	00 00 00 
   218e6:	66 0f 28 54 24 20    	movapd 0x20(%rsp),%xmm2
   218ec:	66 44 0f 28 b4 24 90 	movapd 0x90(%rsp),%xmm14
   218f3:	00 00 00 
   218f6:	0f 8f 24 09 00 00    	jg     22220 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x1930>
   218fc:	66 0f 28 e1          	movapd %xmm1,%xmm4
   21900:	f3 0f 10 84 24 ac 00 	movss  0xac(%rsp),%xmm0
   21907:	00 00 
   21909:	0f 57 c9             	xorps  %xmm1,%xmm1
   2190c:	f3 0f 5a c8          	cvtss2sd %xmm0,%xmm1
   21910:	0f 28 c1             	movaps %xmm1,%xmm0
   21913:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   21917:	f2 0f 11 8c 24 e0 00 	movsd  %xmm1,0xe0(%rsp)
   2191e:	00 00 
   21920:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   21924:	f2 0f 10 0d f4 58 fe 	movsd  -0x1a70c(%rip),%xmm1        # 7220 <std::thread::current::id::ID+0x65a8>
   2192b:	ff 
   2192c:	f2 0f 5e c8          	divsd  %xmm0,%xmm1
   21930:	66 0f 14 c9          	unpcklpd %xmm1,%xmm1
   21934:	66 44 0f 5c f1       	subpd  %xmm1,%xmm14
   21939:	66 0f 5c d1          	subpd  %xmm1,%xmm2
   2193d:	66 0f 29 64 24 70    	movapd %xmm4,0x70(%rsp)
   21943:	66 0f 14 e4          	unpcklpd %xmm4,%xmm4
   21947:	66 0f 28 ca          	movapd %xmm2,%xmm1
   2194b:	66 45 0f 57 c0       	xorpd  %xmm8,%xmm8
   21950:	66 45 0f 57 c9       	xorpd  %xmm9,%xmm9
   21955:	66 45 0f c2 ce 01    	cmpltpd %xmm14,%xmm9
   2195b:	66 45 0f 57 e4       	xorpd  %xmm12,%xmm12
   21960:	66 44 0f c2 e2 01    	cmpltpd %xmm2,%xmm12
   21966:	66 0f 28 05 d2 3d fe 	movapd -0x1c22e(%rip),%xmm0        # 5740 <std::thread::current::id::ID+0x4ac8>
   2196d:	ff 
   2196e:	66 44 0f 55 c8       	andnpd %xmm0,%xmm9
   21973:	66 44 0f 55 e0       	andnpd %xmm0,%xmm12
   21978:	66 0f 28 9c 24 30 01 	movapd 0x130(%rsp),%xmm3
   2197f:	00 00 
   21981:	66 0f 5d dc          	minpd  %xmm4,%xmm3
   21985:	66 0f 28 ac 24 20 01 	movapd 0x120(%rsp),%xmm5
   2198c:	00 00 
   2198e:	66 0f 5d ec          	minpd  %xmm4,%xmm5
   21992:	66 0f 28 84 24 10 01 	movapd 0x110(%rsp),%xmm0
   21999:	00 00 
   2199b:	66 0f 5d c4          	minpd  %xmm4,%xmm0
   2199f:	66 0f 29 84 24 10 01 	movapd %xmm0,0x110(%rsp)
   219a6:	00 00 
   219a8:	66 0f 28 84 24 00 01 	movapd 0x100(%rsp),%xmm0
   219af:	00 00 
   219b1:	66 0f 5d c4          	minpd  %xmm4,%xmm0
   219b5:	66 0f 29 84 24 00 01 	movapd %xmm0,0x100(%rsp)
   219bc:	00 00 
   219be:	66 44 0f 29 4c 24 10 	movapd %xmm9,0x10(%rsp)
   219c5:	66 0f 28 05 73 3d fe 	movapd -0x1c28d(%rip),%xmm0        # 5740 <std::thread::current::id::ID+0x4ac8>
   219cc:	ff 
   219cd:	66 44 0f c2 c8 00    	cmpeqpd %xmm0,%xmm9
   219d3:	66 44 0f 28 94 24 c0 	movapd 0xc0(%rsp),%xmm10
   219da:	00 00 00 
   219dd:	66 41 0f 28 c2       	movapd %xmm10,%xmm0
   219e2:	66 0f 59 c3          	mulpd  %xmm3,%xmm0
   219e6:	66 41 0f 28 d5       	movapd %xmm13,%xmm2
   219eb:	66 0f 59 d5          	mulpd  %xmm5,%xmm2
   219ef:	66 41 0f 58 c7       	addpd  %xmm15,%xmm0
   219f4:	66 0f 58 54 24 60    	addpd  0x60(%rsp),%xmm2
   219fa:	66 0f 59 c3          	mulpd  %xmm3,%xmm0
   219fe:	66 0f 59 d5          	mulpd  %xmm5,%xmm2
   21a02:	66 0f 58 c6          	addpd  %xmm6,%xmm0
   21a06:	66 0f 58 14 24       	addpd  (%rsp),%xmm2
   21a0b:	66 0f 59 c3          	mulpd  %xmm3,%xmm0
   21a0f:	66 0f 59 d5          	mulpd  %xmm5,%xmm2
   21a13:	66 41 0f 58 c6       	addpd  %xmm14,%xmm0
   21a18:	66 0f 29 4c 24 20    	movapd %xmm1,0x20(%rsp)
   21a1e:	66 0f 58 d1          	addpd  %xmm1,%xmm2
   21a22:	66 0f 57 ff          	xorpd  %xmm7,%xmm7
   21a26:	66 0f c2 f8 01       	cmpltpd %xmm0,%xmm7
   21a2b:	66 45 0f 57 db       	xorpd  %xmm11,%xmm11
   21a30:	66 44 0f c2 da 01    	cmpltpd %xmm2,%xmm11
   21a36:	66 41 0f 28 f4       	movapd %xmm12,%xmm6
   21a3b:	66 0f c2 35 fc 3c fe 	cmpeqpd -0x1c304(%rip),%xmm6        # 5740 <std::thread::current::id::ID+0x4ac8>
   21a42:	ff 00 
   21a44:	66 41 0f 54 f9       	andpd  %xmm9,%xmm7
   21a49:	66 44 0f 54 de       	andpd  %xmm6,%xmm11
   21a4e:	66 0f 50 c7          	movmskpd %xmm7,%eax
   21a52:	66 41 0f 50 cb       	movmskpd %xmm11,%ecx
   21a57:	c1 e1 02             	shl    $0x2,%ecx
   21a5a:	83 e1 04             	and    $0x4,%ecx
   21a5d:	09 c1                	or     %eax,%ecx
   21a5f:	66 0f 29 9c 24 30 01 	movapd %xmm3,0x130(%rsp)
   21a66:	00 00 
   21a68:	66 0f 29 ac 24 20 01 	movapd %xmm5,0x120(%rsp)
   21a6f:	00 00 
   21a71:	0f 84 e2 01 00 00    	je     21c59 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x1369>
   21a77:	66 44 0f 29 64 24 30 	movapd %xmm12,0x30(%rsp)
   21a7e:	b8 40 00 00 00       	mov    $0x40,%eax
   21a83:	66 44 0f 28 cd       	movapd %xmm5,%xmm9
   21a88:	66 0f 28 d3          	movapd %xmm3,%xmm2
   21a8c:	66 45 0f 57 ff       	xorpd  %xmm15,%xmm15
   21a91:	66 44 0f 29 b4 24 90 	movapd %xmm14,0x90(%rsp)
   21a98:	00 00 00 
   21a9b:	66 0f 28 0c 24       	movapd (%rsp),%xmm1
   21aa0:	66 0f 28 9c 24 80 00 	movapd 0x80(%rsp),%xmm3
   21aa7:	00 00 
   21aa9:	66 0f 28 44 24 20    	movapd 0x20(%rsp),%xmm0
   21aaf:	66 0f 28 6c 24 60    	movapd 0x60(%rsp),%xmm5
   21ab5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   21abc:	00 00 00 00 
   21ac0:	66 44 0f 28 d2       	movapd %xmm2,%xmm10
   21ac5:	66 45 0f 5c d7       	subpd  %xmm15,%xmm10
   21aca:	66 41 0f 28 f1       	movapd %xmm9,%xmm6
   21acf:	66 41 0f 5c f0       	subpd  %xmm8,%xmm6
   21ad4:	66 44 0f 28 25 a3 38 	movapd -0x1c75d(%rip),%xmm12        # 5380 <std::thread::current::id::ID+0x4708>
   21adb:	fe ff 
   21add:	66 45 0f 59 d4       	mulpd  %xmm12,%xmm10
   21ae2:	66 41 0f 59 f4       	mulpd  %xmm12,%xmm6
   21ae7:	66 45 0f 58 d7       	addpd  %xmm15,%xmm10
   21aec:	66 41 0f 58 f0       	addpd  %xmm8,%xmm6
   21af1:	66 44 0f 28 a4 24 c0 	movapd 0xc0(%rsp),%xmm12
   21af8:	00 00 00 
   21afb:	66 45 0f 59 e2       	mulpd  %xmm10,%xmm12
   21b00:	66 44 0f 28 b4 24 f0 	movapd 0xf0(%rsp),%xmm14
   21b07:	00 00 00 
   21b0a:	66 44 0f 59 f6       	mulpd  %xmm6,%xmm14
   21b0f:	66 44 0f 58 a4 24 b0 	addpd  0xb0(%rsp),%xmm12
   21b16:	00 00 00 
   21b19:	66 44 0f 58 f5       	addpd  %xmm5,%xmm14
   21b1e:	66 45 0f 59 e2       	mulpd  %xmm10,%xmm12
   21b23:	66 44 0f 59 f6       	mulpd  %xmm6,%xmm14
   21b28:	66 44 0f 58 e3       	addpd  %xmm3,%xmm12
   21b2d:	66 44 0f 58 f1       	addpd  %xmm1,%xmm14
   21b32:	66 45 0f 59 e2       	mulpd  %xmm10,%xmm12
   21b37:	66 44 0f 59 f6       	mulpd  %xmm6,%xmm14
   21b3c:	66 44 0f 58 a4 24 90 	addpd  0x90(%rsp),%xmm12
   21b43:	00 00 00 
   21b46:	66 44 0f 58 f0       	addpd  %xmm0,%xmm14
   21b4b:	66 0f 57 ed          	xorpd  %xmm5,%xmm5
   21b4f:	66 41 0f c2 ec 01    	cmpltpd %xmm12,%xmm5
   21b55:	66 45 0f 57 ed       	xorpd  %xmm13,%xmm13
   21b5a:	66 45 0f c2 ee 01    	cmpltpd %xmm14,%xmm13
   21b60:	66 44 0f 28 e7       	movapd %xmm7,%xmm12
   21b65:	66 44 0f 54 e5       	andpd  %xmm5,%xmm12
   21b6a:	66 45 0f 28 f4       	movapd %xmm12,%xmm14
   21b6f:	66 44 0f 55 e2       	andnpd %xmm2,%xmm12
   21b74:	66 41 0f 28 d3       	movapd %xmm11,%xmm2
   21b79:	66 41 0f 54 d5       	andpd  %xmm13,%xmm2
   21b7e:	66 45 0f 54 f2       	andpd  %xmm10,%xmm14
   21b83:	66 45 0f 56 e6       	orpd   %xmm14,%xmm12
   21b88:	66 44 0f 28 f2       	movapd %xmm2,%xmm14
   21b8d:	66 41 0f 55 d1       	andnpd %xmm9,%xmm2
   21b92:	66 44 0f 54 f6       	andpd  %xmm6,%xmm14
   21b97:	66 41 0f 56 d6       	orpd   %xmm14,%xmm2
   21b9c:	66 0f 55 ef          	andnpd %xmm7,%xmm5
   21ba0:	66 44 0f 54 d5       	andpd  %xmm5,%xmm10
   21ba5:	66 41 0f 55 ef       	andnpd %xmm15,%xmm5
   21baa:	66 44 0f 28 fd       	movapd %xmm5,%xmm15
   21baf:	66 45 0f 56 fa       	orpd   %xmm10,%xmm15
   21bb4:	66 45 0f 55 eb       	andnpd %xmm11,%xmm13
   21bb9:	66 41 0f 54 f5       	andpd  %xmm13,%xmm6
   21bbe:	66 45 0f 55 e8       	andnpd %xmm8,%xmm13
   21bc3:	66 45 0f 28 c5       	movapd %xmm13,%xmm8
   21bc8:	66 0f 28 6c 24 60    	movapd 0x60(%rsp),%xmm5
   21bce:	66 44 0f 56 c6       	orpd   %xmm6,%xmm8
   21bd3:	66 44 0f 28 ca       	movapd %xmm2,%xmm9
   21bd8:	66 41 0f 28 d4       	movapd %xmm12,%xmm2
   21bdd:	48 ff c8             	dec    %rax
   21be0:	0f 85 da fe ff ff    	jne    21ac0 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x11d0>
   21be6:	66 44 0f 54 ff       	andpd  %xmm7,%xmm15
   21beb:	66 0f 55 7c 24 10    	andnpd 0x10(%rsp),%xmm7
   21bf1:	66 41 0f 56 ff       	orpd   %xmm15,%xmm7
   21bf6:	66 45 0f 54 c3       	andpd  %xmm11,%xmm8
   21bfb:	66 44 0f 55 5c 24 30 	andnpd 0x30(%rsp),%xmm11
   21c02:	66 45 0f 56 d8       	orpd   %xmm8,%xmm11
   21c07:	66 44 0f 28 cf       	movapd %xmm7,%xmm9
   21c0c:	66 0f 28 05 2c 3b fe 	movapd -0x1c4d4(%rip),%xmm0        # 5740 <std::thread::current::id::ID+0x4ac8>
   21c13:	ff 
   21c14:	66 44 0f c2 c8 00    	cmpeqpd %xmm0,%xmm9
   21c1a:	66 41 0f 28 f3       	movapd %xmm11,%xmm6
   21c1f:	66 0f c2 f0 00       	cmpeqpd %xmm0,%xmm6
   21c24:	66 45 0f 28 c3       	movapd %xmm11,%xmm8
   21c29:	66 0f 29 7c 24 10    	movapd %xmm7,0x10(%rsp)
   21c2f:	66 44 0f 28 b4 24 90 	movapd 0x90(%rsp),%xmm14
   21c36:	00 00 00 
   21c39:	66 44 0f 28 ac 24 f0 	movapd 0xf0(%rsp),%xmm13
   21c40:	00 00 00 
   21c43:	66 44 0f 28 94 24 c0 	movapd 0xc0(%rsp),%xmm10
   21c4a:	00 00 00 
   21c4d:	66 44 0f 28 bc 24 b0 	movapd 0xb0(%rsp),%xmm15
   21c54:	00 00 00 
   21c57:	eb 0b                	jmp    21c64 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x1374>
   21c59:	66 0f 28 6c 24 60    	movapd 0x60(%rsp),%xmm5
   21c5f:	66 45 0f 28 c4       	movapd %xmm12,%xmm8
   21c64:	66 41 0f 28 c2       	movapd %xmm10,%xmm0
   21c69:	66 0f 28 8c 24 10 01 	movapd 0x110(%rsp),%xmm1
   21c70:	00 00 
   21c72:	66 0f 59 c1          	mulpd  %xmm1,%xmm0
   21c76:	66 41 0f 28 d5       	movapd %xmm13,%xmm2
   21c7b:	66 44 0f 28 94 24 00 	movapd 0x100(%rsp),%xmm10
   21c82:	01 00 00 
   21c85:	66 41 0f 59 d2       	mulpd  %xmm10,%xmm2
   21c8a:	66 41 0f 58 c7       	addpd  %xmm15,%xmm0
   21c8f:	66 0f 58 d5          	addpd  %xmm5,%xmm2
   21c93:	66 0f 59 c1          	mulpd  %xmm1,%xmm0
   21c97:	66 41 0f 59 d2       	mulpd  %xmm10,%xmm2
   21c9c:	66 0f 58 84 24 80 00 	addpd  0x80(%rsp),%xmm0
   21ca3:	00 00 
   21ca5:	66 0f 58 14 24       	addpd  (%rsp),%xmm2
   21caa:	66 0f 59 c1          	mulpd  %xmm1,%xmm0
   21cae:	66 41 0f 59 d2       	mulpd  %xmm10,%xmm2
   21cb3:	66 41 0f 58 c6       	addpd  %xmm14,%xmm0
   21cb8:	66 0f 28 5c 24 20    	movapd 0x20(%rsp),%xmm3
   21cbe:	66 0f 58 d3          	addpd  %xmm3,%xmm2
   21cc2:	66 45 0f 57 e4       	xorpd  %xmm12,%xmm12
   21cc7:	66 0f 57 ff          	xorpd  %xmm7,%xmm7
   21ccb:	66 0f c2 f8 01       	cmpltpd %xmm0,%xmm7
   21cd0:	66 45 0f 57 db       	xorpd  %xmm11,%xmm11
   21cd5:	66 44 0f c2 da 01    	cmpltpd %xmm2,%xmm11
   21cdb:	66 41 0f 54 f9       	andpd  %xmm9,%xmm7
   21ce0:	66 44 0f 54 de       	andpd  %xmm6,%xmm11
   21ce5:	66 0f 50 c7          	movmskpd %xmm7,%eax
   21ce9:	66 41 0f 50 cb       	movmskpd %xmm11,%ecx
   21cee:	c1 e1 02             	shl    $0x2,%ecx
   21cf1:	83 e1 04             	and    $0x4,%ecx
   21cf4:	09 c1                	or     %eax,%ecx
   21cf6:	0f 84 dc 01 00 00    	je     21ed8 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x15e8>
   21cfc:	66 44 0f 29 44 24 30 	movapd %xmm8,0x30(%rsp)
   21d03:	b8 40 00 00 00       	mov    $0x40,%eax
   21d08:	66 41 0f 28 f2       	movapd %xmm10,%xmm6
   21d0d:	66 0f 28 d1          	movapd %xmm1,%xmm2
   21d11:	66 0f 28 8c 24 80 00 	movapd 0x80(%rsp),%xmm1
   21d18:	00 00 
   21d1a:	66 44 0f 28 bc 24 30 	movapd 0x130(%rsp),%xmm15
   21d21:	01 00 00 
   21d24:	66 44 0f 28 a4 24 20 	movapd 0x120(%rsp),%xmm12
   21d2b:	01 00 00 
   21d2e:	66 44 0f 28 84 24 c0 	movapd 0xc0(%rsp),%xmm8
   21d35:	00 00 00 
   21d38:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   21d3f:	00 
   21d40:	66 44 0f 28 ca       	movapd %xmm2,%xmm9
   21d45:	66 45 0f 5c cf       	subpd  %xmm15,%xmm9
   21d4a:	66 0f 28 ee          	movapd %xmm6,%xmm5
   21d4e:	66 41 0f 5c ec       	subpd  %xmm12,%xmm5
   21d53:	66 0f 28 05 25 36 fe 	movapd -0x1c9db(%rip),%xmm0        # 5380 <std::thread::current::id::ID+0x4708>
   21d5a:	ff 
   21d5b:	66 44 0f 59 c8       	mulpd  %xmm0,%xmm9
   21d60:	66 0f 59 e8          	mulpd  %xmm0,%xmm5
   21d64:	66 45 0f 58 cf       	addpd  %xmm15,%xmm9
   21d69:	66 41 0f 58 ec       	addpd  %xmm12,%xmm5
   21d6e:	66 45 0f 28 d0       	movapd %xmm8,%xmm10
   21d73:	66 45 0f 59 d1       	mulpd  %xmm9,%xmm10
   21d78:	66 41 0f 28 c4       	movapd %xmm12,%xmm0
   21d7d:	66 44 0f 28 ac 24 f0 	movapd 0xf0(%rsp),%xmm13
   21d84:	00 00 00 
   21d87:	66 44 0f 59 ed       	mulpd  %xmm5,%xmm13
   21d8c:	66 44 0f 58 94 24 b0 	addpd  0xb0(%rsp),%xmm10
   21d93:	00 00 00 
   21d96:	66 44 0f 58 6c 24 60 	addpd  0x60(%rsp),%xmm13
   21d9d:	66 45 0f 59 d1       	mulpd  %xmm9,%xmm10
   21da2:	66 44 0f 59 ed       	mulpd  %xmm5,%xmm13
   21da7:	66 44 0f 58 d1       	addpd  %xmm1,%xmm10
   21dac:	66 44 0f 58 2c 24    	addpd  (%rsp),%xmm13
   21db2:	66 45 0f 59 d1       	mulpd  %xmm9,%xmm10
   21db7:	66 44 0f 59 ed       	mulpd  %xmm5,%xmm13
   21dbc:	66 45 0f 58 d6       	addpd  %xmm14,%xmm10
   21dc1:	66 44 0f 58 6c 24 20 	addpd  0x20(%rsp),%xmm13
   21dc8:	66 41 0f 28 de       	movapd %xmm14,%xmm3
   21dcd:	66 45 0f 57 f6       	xorpd  %xmm14,%xmm14
   21dd2:	66 45 0f c2 f2 01    	cmpltpd %xmm10,%xmm14
   21dd8:	66 45 0f 57 e4       	xorpd  %xmm12,%xmm12
   21ddd:	66 45 0f c2 e5 01    	cmpltpd %xmm13,%xmm12
   21de3:	66 44 0f 28 d7       	movapd %xmm7,%xmm10
   21de8:	66 45 0f 54 d6       	andpd  %xmm14,%xmm10
   21ded:	66 45 0f 28 ea       	movapd %xmm10,%xmm13
   21df2:	66 44 0f 55 d2       	andnpd %xmm2,%xmm10
   21df7:	66 41 0f 28 d3       	movapd %xmm11,%xmm2
   21dfc:	66 41 0f 54 d4       	andpd  %xmm12,%xmm2
   21e01:	66 45 0f 54 e9       	andpd  %xmm9,%xmm13
   21e06:	66 45 0f 56 d5       	orpd   %xmm13,%xmm10
   21e0b:	66 44 0f 28 ea       	movapd %xmm2,%xmm13
   21e10:	66 0f 55 d6          	andnpd %xmm6,%xmm2
   21e14:	66 44 0f 54 ed       	andpd  %xmm5,%xmm13
   21e19:	66 41 0f 56 d5       	orpd   %xmm13,%xmm2
   21e1e:	66 44 0f 55 f7       	andnpd %xmm7,%xmm14
   21e23:	66 45 0f 54 ce       	andpd  %xmm14,%xmm9
   21e28:	66 45 0f 55 f7       	andnpd %xmm15,%xmm14
   21e2d:	66 45 0f 28 fe       	movapd %xmm14,%xmm15
   21e32:	66 44 0f 28 f3       	movapd %xmm3,%xmm14
   21e37:	66 45 0f 56 f9       	orpd   %xmm9,%xmm15
   21e3c:	66 45 0f 55 e3       	andnpd %xmm11,%xmm12
   21e41:	66 41 0f 54 ec       	andpd  %xmm12,%xmm5
   21e46:	66 44 0f 55 e0       	andnpd %xmm0,%xmm12
   21e4b:	66 44 0f 56 e5       	orpd   %xmm5,%xmm12
   21e50:	66 0f 28 f2          	movapd %xmm2,%xmm6
   21e54:	66 41 0f 28 d2       	movapd %xmm10,%xmm2
   21e59:	48 ff c8             	dec    %rax
   21e5c:	0f 85 de fe ff ff    	jne    21d40 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x1450>
   21e62:	66 44 0f 54 ff       	andpd  %xmm7,%xmm15
   21e67:	66 0f 55 7c 24 10    	andnpd 0x10(%rsp),%xmm7
   21e6d:	66 41 0f 56 ff       	orpd   %xmm15,%xmm7
   21e72:	66 45 0f 54 e3       	andpd  %xmm11,%xmm12
   21e77:	66 44 0f 55 5c 24 30 	andnpd 0x30(%rsp),%xmm11
   21e7e:	66 45 0f 56 dc       	orpd   %xmm12,%xmm11
   21e83:	66 44 0f 28 cf       	movapd %xmm7,%xmm9
   21e88:	66 0f 28 35 b0 38 fe 	movapd -0x1c750(%rip),%xmm6        # 5740 <std::thread::current::id::ID+0x4ac8>
   21e8f:	ff 
   21e90:	66 44 0f c2 ce 00    	cmpeqpd %xmm6,%xmm9
   21e96:	66 41 0f c2 f3 00    	cmpeqpd %xmm11,%xmm6
   21e9c:	66 45 0f 28 c3       	movapd %xmm11,%xmm8
   21ea1:	66 0f 29 7c 24 10    	movapd %xmm7,0x10(%rsp)
   21ea7:	66 0f 28 4c 24 60    	movapd 0x60(%rsp),%xmm1
   21ead:	66 44 0f 28 bc 24 b0 	movapd 0xb0(%rsp),%xmm15
   21eb4:	00 00 00 
   21eb7:	66 0f 28 7c 24 20    	movapd 0x20(%rsp),%xmm7
   21ebd:	66 44 0f 28 94 24 00 	movapd 0x100(%rsp),%xmm10
   21ec4:	01 00 00 
   21ec7:	66 44 0f 28 ac 24 f0 	movapd 0xf0(%rsp),%xmm13
   21ece:	00 00 00 
   21ed1:	66 45 0f 57 e4       	xorpd  %xmm12,%xmm12
   21ed6:	eb 08                	jmp    21ee0 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x15f0>
   21ed8:	66 0f 28 cd          	movapd %xmm5,%xmm1
   21edc:	66 0f 28 fb          	movapd %xmm3,%xmm7
   21ee0:	66 0f 28 84 24 c0 00 	movapd 0xc0(%rsp),%xmm0
   21ee7:	00 00 
   21ee9:	66 0f 59 c4          	mulpd  %xmm4,%xmm0
   21eed:	66 41 0f 28 ed       	movapd %xmm13,%xmm5
   21ef2:	66 0f 59 ec          	mulpd  %xmm4,%xmm5
   21ef6:	66 41 0f 58 c7       	addpd  %xmm15,%xmm0
   21efb:	66 0f 58 e9          	addpd  %xmm1,%xmm5
   21eff:	66 0f 59 c4          	mulpd  %xmm4,%xmm0
   21f03:	66 0f 59 ec          	mulpd  %xmm4,%xmm5
   21f07:	66 0f 58 84 24 80 00 	addpd  0x80(%rsp),%xmm0
   21f0e:	00 00 
   21f10:	66 0f 28 0c 24       	movapd (%rsp),%xmm1
   21f15:	66 0f 58 e9          	addpd  %xmm1,%xmm5
   21f19:	66 0f 59 c4          	mulpd  %xmm4,%xmm0
   21f1d:	66 0f 59 ec          	mulpd  %xmm4,%xmm5
   21f21:	66 41 0f 58 c6       	addpd  %xmm14,%xmm0
   21f26:	66 0f 58 ef          	addpd  %xmm7,%xmm5
   21f2a:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   21f2e:	66 0f c2 d0 01       	cmpltpd %xmm0,%xmm2
   21f33:	66 41 0f 54 d1       	andpd  %xmm9,%xmm2
   21f38:	66 44 0f c2 e5 01    	cmpltpd %xmm5,%xmm12
   21f3e:	66 44 0f 54 e6       	andpd  %xmm6,%xmm12
   21f43:	66 0f 50 c2          	movmskpd %xmm2,%eax
   21f47:	66 41 0f 28 c4       	movapd %xmm12,%xmm0
   21f4c:	66 41 0f 50 cc       	movmskpd %xmm12,%ecx
   21f51:	c1 e1 02             	shl    $0x2,%ecx
   21f54:	83 e1 04             	and    $0x4,%ecx
   21f57:	09 c1                	or     %eax,%ecx
   21f59:	66 44 0f 28 a4 24 10 	movapd 0x110(%rsp),%xmm12
   21f60:	01 00 00 
   21f63:	0f 84 72 01 00 00    	je     220db <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x17eb>
   21f69:	66 41 0f 28 dd       	movapd %xmm13,%xmm3
   21f6e:	66 45 0f 28 ef       	movapd %xmm15,%xmm13
   21f73:	66 44 0f 29 44 24 30 	movapd %xmm8,0x30(%rsp)
   21f7a:	b8 40 00 00 00       	mov    $0x40,%eax
   21f7f:	66 0f 28 fc          	movapd %xmm4,%xmm7
   21f83:	66 44 0f 28 fb       	movapd %xmm3,%xmm15
   21f88:	66 0f 28 8c 24 c0 00 	movapd 0xc0(%rsp),%xmm1
   21f8f:	00 00 
   21f91:	66 0f 28 d8          	movapd %xmm0,%xmm3
   21f95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   21f9c:	00 00 00 00 
   21fa0:	66 0f 28 f7          	movapd %xmm7,%xmm6
   21fa4:	66 41 0f 5c f4       	subpd  %xmm12,%xmm6
   21fa9:	66 0f 28 ec          	movapd %xmm4,%xmm5
   21fad:	66 41 0f 5c ea       	subpd  %xmm10,%xmm5
   21fb2:	66 0f 28 05 c6 33 fe 	movapd -0x1cc3a(%rip),%xmm0        # 5380 <std::thread::current::id::ID+0x4708>
   21fb9:	ff 
   21fba:	66 0f 59 f0          	mulpd  %xmm0,%xmm6
   21fbe:	66 0f 59 e8          	mulpd  %xmm0,%xmm5
   21fc2:	66 41 0f 58 f4       	addpd  %xmm12,%xmm6
   21fc7:	66 41 0f 58 ea       	addpd  %xmm10,%xmm5
   21fcc:	66 44 0f 28 c9       	movapd %xmm1,%xmm9
   21fd1:	66 44 0f 59 ce       	mulpd  %xmm6,%xmm9
   21fd6:	66 41 0f 28 c2       	movapd %xmm10,%xmm0
   21fdb:	66 45 0f 28 c4       	movapd %xmm12,%xmm8
   21fe0:	66 45 0f 28 df       	movapd %xmm15,%xmm11
   21fe5:	66 44 0f 59 dd       	mulpd  %xmm5,%xmm11
   21fea:	66 45 0f 58 cd       	addpd  %xmm13,%xmm9
   21fef:	66 44 0f 58 5c 24 60 	addpd  0x60(%rsp),%xmm11
   21ff6:	66 44 0f 59 ce       	mulpd  %xmm6,%xmm9
   21ffb:	66 44 0f 59 dd       	mulpd  %xmm5,%xmm11
   22000:	66 44 0f 58 8c 24 80 	addpd  0x80(%rsp),%xmm9
   22007:	00 00 00 
   2200a:	66 44 0f 58 1c 24    	addpd  (%rsp),%xmm11
   22010:	66 44 0f 59 ce       	mulpd  %xmm6,%xmm9
   22015:	66 44 0f 59 dd       	mulpd  %xmm5,%xmm11
   2201a:	66 45 0f 58 ce       	addpd  %xmm14,%xmm9
   2201f:	66 44 0f 58 5c 24 20 	addpd  0x20(%rsp),%xmm11
   22026:	66 45 0f 57 e4       	xorpd  %xmm12,%xmm12
   2202b:	66 45 0f c2 e1 01    	cmpltpd %xmm9,%xmm12
   22031:	66 45 0f 57 d2       	xorpd  %xmm10,%xmm10
   22036:	66 45 0f c2 d3 01    	cmpltpd %xmm11,%xmm10
   2203c:	66 44 0f 28 ca       	movapd %xmm2,%xmm9
   22041:	66 45 0f 54 cc       	andpd  %xmm12,%xmm9
   22046:	66 45 0f 28 d9       	movapd %xmm9,%xmm11
   2204b:	66 44 0f 55 cf       	andnpd %xmm7,%xmm9
   22050:	66 0f 28 fb          	movapd %xmm3,%xmm7
   22054:	66 41 0f 54 fa       	andpd  %xmm10,%xmm7
   22059:	66 44 0f 54 de       	andpd  %xmm6,%xmm11
   2205e:	66 45 0f 56 cb       	orpd   %xmm11,%xmm9
   22063:	66 44 0f 28 df       	movapd %xmm7,%xmm11
   22068:	66 0f 55 fc          	andnpd %xmm4,%xmm7
   2206c:	66 44 0f 54 dd       	andpd  %xmm5,%xmm11
   22071:	66 41 0f 56 fb       	orpd   %xmm11,%xmm7
   22076:	66 44 0f 55 e2       	andnpd %xmm2,%xmm12
   2207b:	66 41 0f 54 f4       	andpd  %xmm12,%xmm6
   22080:	66 45 0f 55 e0       	andnpd %xmm8,%xmm12
   22085:	66 44 0f 56 e6       	orpd   %xmm6,%xmm12
   2208a:	66 44 0f 55 d3       	andnpd %xmm3,%xmm10
   2208f:	66 41 0f 54 ea       	andpd  %xmm10,%xmm5
   22094:	66 44 0f 55 d0       	andnpd %xmm0,%xmm10
   22099:	66 44 0f 56 d5       	orpd   %xmm5,%xmm10
   2209e:	66 0f 28 e7          	movapd %xmm7,%xmm4
   220a2:	66 41 0f 28 f9       	movapd %xmm9,%xmm7
   220a7:	48 ff c8             	dec    %rax
   220aa:	0f 85 f0 fe ff ff    	jne    21fa0 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x16b0>
   220b0:	66 44 0f 54 e2       	andpd  %xmm2,%xmm12
   220b5:	66 0f 55 54 24 10    	andnpd 0x10(%rsp),%xmm2
   220bb:	66 41 0f 56 d4       	orpd   %xmm12,%xmm2
   220c0:	66 44 0f 54 d3       	andpd  %xmm3,%xmm10
   220c5:	66 0f 55 5c 24 30    	andnpd 0x30(%rsp),%xmm3
   220cb:	66 41 0f 56 da       	orpd   %xmm10,%xmm3
   220d0:	66 44 0f 28 c3       	movapd %xmm3,%xmm8
   220d5:	66 0f 28 ca          	movapd %xmm2,%xmm1
   220d9:	eb 06                	jmp    220e1 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x17f1>
   220db:	66 0f 28 4c 24 10    	movapd 0x10(%rsp),%xmm1
   220e1:	66 0f 70 c1 ee       	pshufd $0xee,%xmm1,%xmm0
   220e6:	66 0f 28 5c 24 70    	movapd 0x70(%rsp),%xmm3
   220ec:	66 0f 28 d3          	movapd %xmm3,%xmm2
   220f0:	f2 0f 5d d1          	minsd  %xmm1,%xmm2
   220f4:	66 0f 28 ca          	movapd %xmm2,%xmm1
   220f8:	f2 0f c2 ca 03       	cmpunordsd %xmm2,%xmm1
   220fd:	66 0f 28 e1          	movapd %xmm1,%xmm4
   22101:	66 0f 55 e2          	andnpd %xmm2,%xmm4
   22105:	66 0f 54 cb          	andpd  %xmm3,%xmm1
   22109:	66 0f 56 cc          	orpd   %xmm4,%xmm1
   2210d:	66 0f 28 d1          	movapd %xmm1,%xmm2
   22111:	f2 0f 5d d0          	minsd  %xmm0,%xmm2
   22115:	66 0f 28 c2          	movapd %xmm2,%xmm0
   22119:	f2 0f c2 c2 03       	cmpunordsd %xmm2,%xmm0
   2211e:	66 0f 54 c8          	andpd  %xmm0,%xmm1
   22122:	66 0f 55 c2          	andnpd %xmm2,%xmm0
   22126:	66 0f 56 c1          	orpd   %xmm1,%xmm0
   2212a:	66 0f 28 c8          	movapd %xmm0,%xmm1
   2212e:	f2 41 0f 5d c8       	minsd  %xmm8,%xmm1
   22133:	66 0f 28 d1          	movapd %xmm1,%xmm2
   22137:	f2 0f c2 d1 03       	cmpunordsd %xmm1,%xmm2
   2213c:	66 0f 54 c2          	andpd  %xmm2,%xmm0
   22140:	66 0f 55 d1          	andnpd %xmm1,%xmm2
   22144:	66 0f 56 d0          	orpd   %xmm0,%xmm2
   22148:	f2 0f 59 94 24 e0 00 	mulsd  0xe0(%rsp),%xmm2
   2214f:	00 00 
   22151:	0f 57 c9             	xorps  %xmm1,%xmm1
   22154:	f2 0f 5a ca          	cvtsd2ss %xmm2,%xmm1
   22158:	0f 28 84 24 50 01 00 	movaps 0x150(%rsp),%xmm0
   2215f:	00 
   22160:	0f 56 05 59 36 fe ff 	orps   -0x1c9a7(%rip),%xmm0        # 57c0 <std::thread::current::id::ID+0x4b48>
   22167:	0f 29 84 24 50 01 00 	movaps %xmm0,0x150(%rsp)
   2216e:	00 
   2216f:	bd 40 00 00 00       	mov    $0x40,%ebp
   22174:	0f b6 db             	movzbl %bl,%ebx
   22177:	4c 8d 7c 24 40       	lea    0x40(%rsp),%r15
   2217c:	eb 1a                	jmp    22198 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x18a8>
   2217e:	41 bc 01 00 00 80    	mov    $0x80000001,%r12d
   22184:	66 41 0f 6e cc       	movd   %r12d,%xmm1
   22189:	0f 57 c0             	xorps  %xmm0,%xmm0
   2218c:	f3 0f 5f c8          	maxss  %xmm0,%xmm1
   22190:	ff cd                	dec    %ebp
   22192:	0f 84 88 00 00 00    	je     22220 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x1930>
   22198:	66 41 0f 7e cc       	movd   %xmm1,%r12d
   2219d:	f3 0f 10 84 24 ac 00 	movss  0xac(%rsp),%xmm0
   221a4:	00 00 
   221a6:	f3 0f 11 44 24 40    	movss  %xmm0,0x40(%rsp)
   221ac:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
   221b1:	f3 0f 11 4c 24 44    	movss  %xmm1,0x44(%rsp)
   221b7:	0f 28 84 24 50 01 00 	movaps 0x150(%rsp),%xmm0
   221be:	00 
   221bf:	f3 0f 11 44 24 48    	movss  %xmm0,0x48(%rsp)
   221c5:	c7 44 24 4c 00 00 80 	movl   $0xff800000,0x4c(%rsp)
   221cc:	ff 
   221cd:	4c 89 ff             	mov    %r15,%rdi
   221d0:	89 de                	mov    %ebx,%esi
   221d2:	e8 69 00 00 00       	call   22240 <gpui_canvas::color::gamut::in_gamut>
   221d7:	84 c0                	test   %al,%al
   221d9:	75 38                	jne    22213 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x1923>
   221db:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
   221e0:	0f 2e c9             	ucomiss %xmm1,%xmm1
   221e3:	0f 9a c0             	setp   %al
   221e6:	41 81 fc 00 00 80 ff 	cmp    $0xff800000,%r12d
   221ed:	0f 94 c1             	sete   %cl
   221f0:	08 c1                	or     %al,%cl
   221f2:	75 95                	jne    22189 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x1899>
   221f4:	44 89 e0             	mov    %r12d,%eax
   221f7:	25 ff ff ff 7f       	and    $0x7fffffff,%eax
   221fc:	74 80                	je     2217e <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x188e>
   221fe:	41 39 c4             	cmp    %eax,%r12d
   22201:	75 08                	jne    2220b <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x191b>
   22203:	41 ff cc             	dec    %r12d
   22206:	e9 79 ff ff ff       	jmp    22184 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x1894>
   2220b:	41 ff c4             	inc    %r12d
   2220e:	e9 71 ff ff ff       	jmp    22184 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x1894>
   22213:	49 c1 e4 20          	shl    $0x20,%r12
   22217:	41 be ff ff ff ff    	mov    $0xffffffff,%r14d
   2221d:	4d 09 e6             	or     %r12,%r14
   22220:	4c 89 f0             	mov    %r14,%rax
   22223:	48 81 c4 a0 01 00 00 	add    $0x1a0,%rsp
   2222a:	5b                   	pop    %rbx
   2222b:	41 5c                	pop    %r12
   2222d:	41 5e                	pop    %r14
   2222f:	41 5f                	pop    %r15
   22231:	5d                   	pop    %rbp
   22232:	c3                   	ret
   22233:	cc                   	int3
   22234:	cc                   	int3
   22235:	cc                   	int3
   22236:	cc                   	int3
   22237:	cc                   	int3
   22238:	cc                   	int3
   22239:	cc                   	int3
   2223a:	cc                   	int3
   2223b:	cc                   	int3
   2223c:	cc                   	int3
   2223d:	cc                   	int3
   2223e:	cc                   	int3
   2223f:	cc                   	int3

gpui_canvas::color::gamut::in_gamut:
   22240:	55                   	push   %rbp
   22241:	53                   	push   %rbx
   22242:	48 83 ec 68          	sub    $0x68,%rsp
   22246:	89 f3                	mov    %esi,%ebx
   22248:	f3 0f 7e 0f          	movq   (%rdi),%xmm1
   2224c:	8b 4f 08             	mov    0x8(%rdi),%ecx
   2224f:	8b 57 0c             	mov    0xc(%rdi),%edx
   22252:	89 c8                	mov    %ecx,%eax
   22254:	81 fa 00 00 00 c0    	cmp    $0xc0000000,%edx
   2225a:	0f 82 ea 00 00 00    	jb     2234a <gpui_canvas::color::gamut::in_gamut+0x10a>
   22260:	89 c8                	mov    %ecx,%eax
   22262:	85 c9                	test   %ecx,%ecx
   22264:	0f 88 db 00 00 00    	js     22345 <gpui_canvas::color::gamut::in_gamut+0x105>
   2226a:	c1 e8 08             	shr    $0x8,%eax
   2226d:	89 ce                	mov    %ecx,%esi
   2226f:	48 69 f6 8f e7 54 52 	imul   $0x5254e78f,%rsi,%rsi
   22276:	48 c1 ee 2e          	shr    $0x2e,%rsi
   2227a:	48 69 f8 09 a8 a7 01 	imul   $0x1a7a809,%rax,%rdi
   22281:	48 c1 ef 20          	shr    $0x20,%rdi
   22285:	66 41 0f 7e c9       	movd   %xmm1,%r9d
   2228a:	45 89 ca             	mov    %r9d,%r10d
   2228d:	41 c1 e2 08          	shl    $0x8,%r10d
   22291:	66 0f 70 c1 55       	pshufd $0x55,%xmm1,%xmm0
   22296:	66 41 0f 7e c0       	movd   %xmm0,%r8d
   2229b:	45 89 c3             	mov    %r8d,%r11d
   2229e:	45 0f a4 cb 08       	shld   $0x8,%r9d,%r11d
   222a3:	69 ee 55 52 00 00    	imul   $0x5255,%esi,%ebp
   222a9:	c1 ed 16             	shr    $0x16,%ebp
   222ac:	69 ed c7 00 00 00    	imul   $0xc7,%ebp,%ebp
   222b2:	29 ee                	sub    %ebp,%esi
   222b4:	44 89 dd             	mov    %r11d,%ebp
   222b7:	c1 e5 08             	shl    $0x8,%ebp
   222ba:	41 81 e3 ff ff 7f 00 	and    $0x7fffff,%r11d
   222c1:	41 81 e2 00 00 00 80 	and    $0x80000000,%r10d
   222c8:	81 e5 00 00 00 80    	and    $0x80000000,%ebp
   222ce:	44 09 dd             	or     %r11d,%ebp
   222d1:	41 81 e1 ff ff 7f 00 	and    $0x7fffff,%r9d
   222d8:	45 09 d1             	or     %r10d,%r9d
   222db:	c1 e6 17             	shl    $0x17,%esi
   222de:	09 ee                	or     %ebp,%esi
   222e0:	c1 e7 0f             	shl    $0xf,%edi
   222e3:	81 e7 00 00 80 ff    	and    $0xff800000,%edi
   222e9:	41 0f ac c8 10       	shrd   $0x10,%ecx,%r8d
   222ee:	44 09 cf             	or     %r9d,%edi
   222f1:	4c 69 c8 9f 53 49 01 	imul   $0x149539f,%rax,%r9
   222f8:	49 c1 e9 20          	shr    $0x20,%r9
   222fc:	45 69 c9 c7 00 00 00 	imul   $0xc7,%r9d,%r9d
   22303:	44 29 c8             	sub    %r9d,%eax
   22306:	45 89 c1             	mov    %r8d,%r9d
   22309:	41 81 e1 ff ff 7f 00 	and    $0x7fffff,%r9d
   22310:	41 c1 e0 08          	shl    $0x8,%r8d
   22314:	41 81 e0 00 00 00 80 	and    $0x80000000,%r8d
   2231b:	45 09 c8             	or     %r9d,%r8d
   2231e:	c1 e0 17             	shl    $0x17,%eax
   22321:	44 09 c0             	or     %r8d,%eax
   22324:	66 0f 6e c6          	movd   %esi,%xmm0
   22328:	66 0f 6e cf          	movd   %edi,%xmm1
   2232c:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
   22330:	c1 ea 1e             	shr    $0x1e,%edx
   22333:	31 ed                	xor    %ebp,%ebp
   22335:	48 8d 35 78 52 fe ff 	lea    -0x1ad88(%rip),%rsi        # 75b4 <std::thread::current::id::ID+0x693c>
   2233c:	48 63 14 96          	movslq (%rsi,%rdx,4),%rdx
   22340:	48 01 f2             	add    %rsi,%rdx
   22343:	ff e2                	jmp    *%rdx
   22345:	25 ff ff ff 7f       	and    $0x7fffffff,%eax
   2234a:	c1 ea 1e             	shr    $0x1e,%edx
   2234d:	31 ed                	xor    %ebp,%ebp
   2234f:	48 8d 35 5e 52 fe ff 	lea    -0x1ada2(%rip),%rsi        # 75b4 <std::thread::current::id::ID+0x693c>
   22356:	48 63 14 96          	movslq (%rsi,%rdx,4),%rdx
   2235a:	48 01 f2             	add    %rsi,%rdx
   2235d:	ff e2                	jmp    *%rdx
   2235f:	40 b5 01             	mov    $0x1,%bpl
   22362:	f3 0f 5a e9          	cvtss2sd %xmm1,%xmm5
   22366:	66 0f 70 f1 55       	pshufd $0x55,%xmm1,%xmm6
   2236b:	f3 0f 5a e6          	cvtss2sd %xmm6,%xmm4
   2236f:	66 0f 6e d0          	movd   %eax,%xmm2
   22373:	0f 28 05 a6 2e fe ff 	movaps -0x1d15a(%rip),%xmm0        # 5220 <std::thread::current::id::ID+0x45a8>
   2237a:	0f 54 c5             	andps  %xmm5,%xmm0
   2237d:	f2 0f 10 1d 73 4e fe 	movsd  -0x1b18d(%rip),%xmm3        # 71f8 <std::thread::current::id::ID+0x6580>
   22384:	ff 
   22385:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   22389:	66 0f 7e 54 24 30    	movd   %xmm2,0x30(%rsp)
   2238f:	73 53                	jae    223e4 <gpui_canvas::color::gamut::in_gamut+0x1a4>
   22391:	0f 2e c9             	ucomiss %xmm1,%xmm1
   22394:	0f 29 64 24 10       	movaps %xmm4,0x10(%rsp)
   22399:	0f 29 74 24 50       	movaps %xmm6,0x50(%rsp)
   2239e:	7a 4e                	jp     223ee <gpui_canvas::color::gamut::in_gamut+0x1ae>
   223a0:	0f 54 2d d9 33 fe ff 	andps  -0x1cc27(%rip),%xmm5        # 5780 <std::thread::current::id::ID+0x4b08>
   223a7:	0f 56 2d e2 32 fe ff 	orps   -0x1cd1e(%rip),%xmm5        # 5690 <std::thread::current::id::ID+0x4a18>
   223ae:	0f 29 2c 24          	movaps %xmm5,(%rsp)
   223b2:	eb 46                	jmp    223fa <gpui_canvas::color::gamut::in_gamut+0x1ba>
   223b4:	0f 5a e9             	cvtps2pd %xmm1,%xmm5
   223b7:	66 0f 6e c0          	movd   %eax,%xmm0
   223bb:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   223bf:	e9 ad 01 00 00       	jmp    22571 <gpui_canvas::color::gamut::in_gamut+0x331>
   223c4:	85 c9                	test   %ecx,%ecx
   223c6:	0f 88 86 02 00 00    	js     22652 <gpui_canvas::color::gamut::in_gamut+0x412>
   223cc:	0f 5a e9             	cvtps2pd %xmm1,%xmm5
   223cf:	66 0f 6e c0          	movd   %eax,%xmm0
   223d3:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   223d7:	84 db                	test   %bl,%bl
   223d9:	0f 84 5e 02 00 00    	je     2263d <gpui_canvas::color::gamut::in_gamut+0x3fd>
   223df:	e9 a7 02 00 00       	jmp    2268b <gpui_canvas::color::gamut::in_gamut+0x44b>
   223e4:	f2 0f 5e 2d 74 4d fe 	divsd  -0x1b28c(%rip),%xmm5        # 7160 <std::thread::current::id::ID+0x64e8>
   223eb:	ff 
   223ec:	eb 4b                	jmp    22439 <gpui_canvas::color::gamut::in_gamut+0x1f9>
   223ee:	f2 0f 10 0d c2 4e fe 	movsd  -0x1b13e(%rip),%xmm1        # 72b8 <std::thread::current::id::ID+0x6640>
   223f5:	ff 
   223f6:	0f 29 0c 24          	movaps %xmm1,(%rsp)
   223fa:	f2 0f 58 05 7e 4f fe 	addsd  -0x1b082(%rip),%xmm0        # 7380 <std::thread::current::id::ID+0x6708>
   22401:	ff 
   22402:	f2 0f 5e 05 ce 4e fe 	divsd  -0x1b132(%rip),%xmm0        # 72d8 <std::thread::current::id::ID+0x6660>
   22409:	ff 
   2240a:	f2 0f 10 0d 5e 4e fe 	movsd  -0x1b1a2(%rip),%xmm1        # 7270 <std::thread::current::id::ID+0x65f8>
   22411:	ff 
   22412:	ff 15 e0 2d 04 00    	call   *0x42de0(%rip)        # 651f8 <pow@GLIBC_2.29>
   22418:	66 0f 28 e8          	movapd %xmm0,%xmm5
   2241c:	f2 0f 59 2c 24       	mulsd  (%rsp),%xmm5
   22421:	66 0f 6e 54 24 30    	movd   0x30(%rsp),%xmm2
   22427:	f2 0f 10 1d c9 4d fe 	movsd  -0x1b237(%rip),%xmm3        # 71f8 <std::thread::current::id::ID+0x6580>
   2242e:	ff 
   2242f:	0f 28 64 24 10       	movaps 0x10(%rsp),%xmm4
   22434:	0f 28 74 24 50       	movaps 0x50(%rsp),%xmm6
   22439:	0f 57 c9             	xorps  %xmm1,%xmm1
   2243c:	f3 0f 5a ca          	cvtss2sd %xmm2,%xmm1
   22440:	0f 28 05 d9 2d fe ff 	movaps -0x1d227(%rip),%xmm0        # 5220 <std::thread::current::id::ID+0x45a8>
   22447:	0f 54 c4             	andps  %xmm4,%xmm0
   2244a:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   2244e:	66 0f 29 2c 24       	movapd %xmm5,(%rsp)
   22453:	73 1f                	jae    22474 <gpui_canvas::color::gamut::in_gamut+0x234>
   22455:	0f 2e f6             	ucomiss %xmm6,%xmm6
   22458:	0f 29 4c 24 20       	movaps %xmm1,0x20(%rsp)
   2245d:	7a 4b                	jp     224aa <gpui_canvas::color::gamut::in_gamut+0x26a>
   2245f:	0f 54 25 1a 33 fe ff 	andps  -0x1cce6(%rip),%xmm4        # 5780 <std::thread::current::id::ID+0x4b08>
   22466:	0f 56 25 23 32 fe ff 	orps   -0x1cddd(%rip),%xmm4        # 5690 <std::thread::current::id::ID+0x4a18>
   2246d:	0f 29 64 24 10       	movaps %xmm4,0x10(%rsp)
   22472:	eb 43                	jmp    224b7 <gpui_canvas::color::gamut::in_gamut+0x277>
   22474:	f2 0f 5e 25 e4 4c fe 	divsd  -0x1b31c(%rip),%xmm4        # 7160 <std::thread::current::id::ID+0x64e8>
   2247b:	ff 
   2247c:	0f 28 05 9d 2d fe ff 	movaps -0x1d263(%rip),%xmm0        # 5220 <std::thread::current::id::ID+0x45a8>
   22483:	0f 54 c1             	andps  %xmm1,%xmm0
   22486:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   2248a:	72 7e                	jb     2250a <gpui_canvas::color::gamut::in_gamut+0x2ca>
   2248c:	f2 0f 5e 0d cc 4c fe 	divsd  -0x1b334(%rip),%xmm1        # 7160 <std::thread::current::id::ID+0x64e8>
   22493:	ff 
   22494:	66 0f 28 c1          	movapd %xmm1,%xmm0
   22498:	66 0f 14 ec          	unpcklpd %xmm4,%xmm5
   2249c:	40 84 ed             	test   %bpl,%bpl
   2249f:	0f 85 cc 00 00 00    	jne    22571 <gpui_canvas::color::gamut::in_gamut+0x331>
   224a5:	e9 8f 01 00 00       	jmp    22639 <gpui_canvas::color::gamut::in_gamut+0x3f9>
   224aa:	f2 0f 10 0d 06 4e fe 	movsd  -0x1b1fa(%rip),%xmm1        # 72b8 <std::thread::current::id::ID+0x6640>
   224b1:	ff 
   224b2:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
   224b7:	f2 0f 58 05 c1 4e fe 	addsd  -0x1b13f(%rip),%xmm0        # 7380 <std::thread::current::id::ID+0x6708>
   224be:	ff 
   224bf:	f2 0f 5e 05 11 4e fe 	divsd  -0x1b1ef(%rip),%xmm0        # 72d8 <std::thread::current::id::ID+0x6660>
   224c6:	ff 
   224c7:	f2 0f 10 0d a1 4d fe 	movsd  -0x1b25f(%rip),%xmm1        # 7270 <std::thread::current::id::ID+0x65f8>
   224ce:	ff 
   224cf:	ff 15 23 2d 04 00    	call   *0x42d23(%rip)        # 651f8 <pow@GLIBC_2.29>
   224d5:	66 0f 28 e0          	movapd %xmm0,%xmm4
   224d9:	f2 0f 59 64 24 10    	mulsd  0x10(%rsp),%xmm4
   224df:	66 0f 28 2c 24       	movapd (%rsp),%xmm5
   224e4:	f3 0f 10 54 24 30    	movss  0x30(%rsp),%xmm2
   224ea:	f2 0f 10 1d 06 4d fe 	movsd  -0x1b2fa(%rip),%xmm3        # 71f8 <std::thread::current::id::ID+0x6580>
   224f1:	ff 
   224f2:	66 0f 28 4c 24 20    	movapd 0x20(%rsp),%xmm1
   224f8:	66 0f 28 05 20 2d fe 	movapd -0x1d2e0(%rip),%xmm0        # 5220 <std::thread::current::id::ID+0x45a8>
   224ff:	ff 
   22500:	66 0f 54 c1          	andpd  %xmm1,%xmm0
   22504:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   22508:	73 82                	jae    2248c <gpui_canvas::color::gamut::in_gamut+0x24c>
   2250a:	0f 2e d2             	ucomiss %xmm2,%xmm2
   2250d:	66 0f 29 64 24 10    	movapd %xmm4,0x10(%rsp)
   22513:	7a 12                	jp     22527 <gpui_canvas::color::gamut::in_gamut+0x2e7>
   22515:	66 0f 54 0d 63 32 fe 	andpd  -0x1cd9d(%rip),%xmm1        # 5780 <std::thread::current::id::ID+0x4b08>
   2251c:	ff 
   2251d:	66 0f 56 0d 6b 31 fe 	orpd   -0x1ce95(%rip),%xmm1        # 5690 <std::thread::current::id::ID+0x4a18>
   22524:	ff 
   22525:	eb 08                	jmp    2252f <gpui_canvas::color::gamut::in_gamut+0x2ef>
   22527:	f2 0f 10 0d 89 4d fe 	movsd  -0x1b277(%rip),%xmm1        # 72b8 <std::thread::current::id::ID+0x6640>
   2252e:	ff 
   2252f:	66 0f 29 4c 24 20    	movapd %xmm1,0x20(%rsp)
   22535:	f2 0f 58 05 43 4e fe 	addsd  -0x1b1bd(%rip),%xmm0        # 7380 <std::thread::current::id::ID+0x6708>
   2253c:	ff 
   2253d:	f2 0f 5e 05 93 4d fe 	divsd  -0x1b26d(%rip),%xmm0        # 72d8 <std::thread::current::id::ID+0x6660>
   22544:	ff 
   22545:	f2 0f 10 0d 23 4d fe 	movsd  -0x1b2dd(%rip),%xmm1        # 7270 <std::thread::current::id::ID+0x65f8>
   2254c:	ff 
   2254d:	ff 15 a5 2c 04 00    	call   *0x42ca5(%rip)        # 651f8 <pow@GLIBC_2.29>
   22553:	f2 0f 59 44 24 20    	mulsd  0x20(%rsp),%xmm0
   22559:	66 0f 28 2c 24       	movapd (%rsp),%xmm5
   2255e:	66 0f 28 64 24 10    	movapd 0x10(%rsp),%xmm4
   22564:	66 0f 14 ec          	unpcklpd %xmm4,%xmm5
   22568:	40 84 ed             	test   %bpl,%bpl
   2256b:	0f 84 c8 00 00 00    	je     22639 <gpui_canvas::color::gamut::in_gamut+0x3f9>
   22571:	66 0f 28 d5          	movapd %xmm5,%xmm2
   22575:	66 0f c6 d5 01       	shufpd $0x1,%xmm5,%xmm2
   2257a:	66 0f 59 15 2e 31 fe 	mulpd  -0x1ced2(%rip),%xmm2        # 56b0 <std::thread::current::id::ID+0x4a38>
   22581:	ff 
   22582:	66 0f 57 db          	xorpd  %xmm3,%xmm3
   22586:	66 0f 16 1d ca 4d fe 	movhpd -0x1b236(%rip),%xmm3        # 7358 <std::thread::current::id::ID+0x66e0>
   2258d:	ff 
   2258e:	66 0f 59 dd          	mulpd  %xmm5,%xmm3
   22592:	0f 28 c8             	movaps %xmm0,%xmm1
   22595:	0f 16 c8             	movlhps %xmm0,%xmm1
   22598:	66 0f 59 0d a0 2c fe 	mulpd  -0x1d360(%rip),%xmm1        # 5240 <std::thread::current::id::ID+0x45c8>
   2259f:	ff 
   225a0:	66 0f 58 da          	addpd  %xmm2,%xmm3
   225a4:	66 0f 58 cb          	addpd  %xmm3,%xmm1
   225a8:	f2 0f 10 15 08 4c fe 	movsd  -0x1b3f8(%rip),%xmm2        # 71b8 <std::thread::current::id::ID+0x6540>
   225af:	ff 
   225b0:	f2 0f 59 d5          	mulsd  %xmm5,%xmm2
   225b4:	f2 0f 10 e8          	movsd  %xmm0,%xmm5
   225b8:	66 0f 59 2d a0 2c fe 	mulpd  -0x1d360(%rip),%xmm5        # 5260 <std::thread::current::id::ID+0x45e8>
   225bf:	ff 
   225c0:	66 0f 28 c5          	movapd %xmm5,%xmm0
   225c4:	66 0f 15 c5          	unpckhpd %xmm5,%xmm0
   225c8:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   225cc:	f2 0f 58 c5          	addsd  %xmm5,%xmm0
   225d0:	f2 0f 10 15 a0 4b fe 	movsd  -0x1b460(%rip),%xmm2        # 7178 <std::thread::current::id::ID+0x6500>
   225d7:	ff 
   225d8:	66 0f 28 d9          	movapd %xmm1,%xmm3
   225dc:	f2 0f 10 d8          	movsd  %xmm0,%xmm3
   225e0:	66 0f 59 1d 68 2f fe 	mulpd  -0x1d098(%rip),%xmm3        # 5550 <std::thread::current::id::ID+0x48d8>
   225e7:	ff 
   225e8:	66 0f 28 e1          	movapd %xmm1,%xmm4
   225ec:	66 0f c6 e0 01       	shufpd $0x1,%xmm0,%xmm4
   225f1:	66 0f 59 25 97 2e fe 	mulpd  -0x1d169(%rip),%xmm4        # 5490 <std::thread::current::id::ID+0x4818>
   225f8:	ff 
   225f9:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
   225fd:	66 0f 58 e3          	addpd  %xmm3,%xmm4
   22601:	66 0f 28 e9          	movapd %xmm1,%xmm5
   22605:	66 0f 14 e9          	unpcklpd %xmm1,%xmm5
   22609:	66 0f 59 2d 7f 31 fe 	mulpd  -0x1ce81(%rip),%xmm5        # 5790 <std::thread::current::id::ID+0x4b18>
   22610:	ff 
   22611:	66 0f 28 c4          	movapd %xmm4,%xmm0
   22615:	66 0f 5c c5          	subpd  %xmm5,%xmm0
   22619:	66 0f 58 ec          	addpd  %xmm4,%xmm5
   2261d:	f2 0f 10 e8          	movsd  %xmm0,%xmm5
   22621:	66 0f 59 0d 07 2f fe 	mulpd  -0x1d0f9(%rip),%xmm1        # 5530 <std::thread::current::id::ID+0x48b8>
   22628:	ff 
   22629:	66 0f 28 c1          	movapd %xmm1,%xmm0
   2262d:	66 0f 15 c1          	unpckhpd %xmm1,%xmm0
   22631:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   22635:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
   22639:	84 db                	test   %bl,%bl
   2263b:	75 4e                	jne    2268b <gpui_canvas::color::gamut::in_gamut+0x44b>
   2263d:	31 c0                	xor    %eax,%eax
   2263f:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   22643:	66 0f 2e e9          	ucomisd %xmm1,%xmm5
   22647:	0f 83 08 01 00 00    	jae    22755 <gpui_canvas::color::gamut::in_gamut+0x515>
   2264d:	e9 41 01 00 00       	jmp    22793 <gpui_canvas::color::gamut::in_gamut+0x553>
   22652:	66 0f 6f d1          	movdqa %xmm1,%xmm2
   22656:	0f c6 c9 55          	shufps $0x55,%xmm1,%xmm1
   2265a:	66 0f ef c0          	pxor   %xmm0,%xmm0
   2265e:	0f 2e c8             	ucomiss %xmm0,%xmm1
   22661:	0f 85 35 01 00 00    	jne    2279c <gpui_canvas::color::gamut::in_gamut+0x55c>
   22667:	0f 8a 2f 01 00 00    	jp     2279c <gpui_canvas::color::gamut::in_gamut+0x55c>
   2266d:	0f 57 c9             	xorps  %xmm1,%xmm1
   22670:	f3 0f 5a ca          	cvtss2sd %xmm2,%xmm1
   22674:	0f 28 c1             	movaps %xmm1,%xmm0
   22677:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   2267b:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   2267f:	66 0f 28 e8          	movapd %xmm0,%xmm5
   22683:	66 0f 14 e8          	unpcklpd %xmm0,%xmm5
   22687:	84 db                	test   %bl,%bl
   22689:	74 b2                	je     2263d <gpui_canvas::color::gamut::in_gamut+0x3fd>
   2268b:	66 0f 28 0d 4d 2c fe 	movapd -0x1d3b3(%rip),%xmm1        # 52e0 <std::thread::current::id::ID+0x4668>
   22692:	ff 
   22693:	66 0f 59 cd          	mulpd  %xmm5,%xmm1
   22697:	66 0f 28 d5          	movapd %xmm5,%xmm2
   2269b:	66 0f c6 d5 01       	shufpd $0x1,%xmm5,%xmm2
   226a0:	66 0f 59 15 68 30 fe 	mulpd  -0x1cf98(%rip),%xmm2        # 5710 <std::thread::current::id::ID+0x4a98>
   226a7:	ff 
   226a8:	66 0f 58 d1          	addpd  %xmm1,%xmm2
   226ac:	66 0f 28 c8          	movapd %xmm0,%xmm1
   226b0:	66 0f 14 c8          	unpcklpd %xmm0,%xmm1
   226b4:	66 0f 59 0d d4 2c fe 	mulpd  -0x1d32c(%rip),%xmm1        # 5390 <std::thread::current::id::ID+0x4718>
   226bb:	ff 
   226bc:	f2 0f 10 1d 44 4b fe 	movsd  -0x1b4bc(%rip),%xmm3        # 7208 <std::thread::current::id::ID+0x6590>
   226c3:	ff 
   226c4:	f2 0f 59 dd          	mulsd  %xmm5,%xmm3
   226c8:	f2 0f 10 e8          	movsd  %xmm0,%xmm5
   226cc:	66 0f 59 2d cc 2c fe 	mulpd  -0x1d334(%rip),%xmm5        # 53a0 <std::thread::current::id::ID+0x4728>
   226d3:	ff 
   226d4:	66 0f 58 ca          	addpd  %xmm2,%xmm1
   226d8:	66 0f 28 c5          	movapd %xmm5,%xmm0
   226dc:	66 0f 15 c5          	unpckhpd %xmm5,%xmm0
   226e0:	f2 0f 58 c3          	addsd  %xmm3,%xmm0
   226e4:	66 0f 28 d1          	movapd %xmm1,%xmm2
   226e8:	66 0f c6 d1 01       	shufpd $0x1,%xmm1,%xmm2
   226ed:	66 0f 59 15 5b 2b fe 	mulpd  -0x1d4a5(%rip),%xmm2        # 5250 <std::thread::current::id::ID+0x45d8>
   226f4:	ff 
   226f5:	f2 0f 58 c5          	addsd  %xmm5,%xmm0
   226f9:	66 0f 28 1d bf 2b fe 	movapd -0x1d441(%rip),%xmm3        # 52c0 <std::thread::current::id::ID+0x4648>
   22700:	ff 
   22701:	66 0f 59 d9          	mulpd  %xmm1,%xmm3
   22705:	66 0f 5c da          	subpd  %xmm2,%xmm3
   22709:	66 0f 28 e8          	movapd %xmm0,%xmm5
   2270d:	66 0f 14 e8          	unpcklpd %xmm0,%xmm5
   22711:	66 0f 59 2d 57 2c fe 	mulpd  -0x1d3a9(%rip),%xmm5        # 5370 <std::thread::current::id::ID+0x46f8>
   22718:	ff 
   22719:	66 0f 28 d3          	movapd %xmm3,%xmm2
   2271d:	66 0f 5c d5          	subpd  %xmm5,%xmm2
   22721:	66 0f 58 eb          	addpd  %xmm3,%xmm5
   22725:	f2 0f 10 ea          	movsd  %xmm2,%xmm5
   22729:	66 0f 59 0d bf 2e fe 	mulpd  -0x1d141(%rip),%xmm1        # 55f0 <std::thread::current::id::ID+0x4978>
   22730:	ff 
   22731:	66 0f 28 d1          	movapd %xmm1,%xmm2
   22735:	66 0f 15 d1          	unpckhpd %xmm1,%xmm2
   22739:	f2 0f 5c ca          	subsd  %xmm2,%xmm1
   2273d:	f2 0f 59 05 6b 4b fe 	mulsd  -0x1b495(%rip),%xmm0        # 72b0 <std::thread::current::id::ID+0x6638>
   22744:	ff 
   22745:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
   22749:	31 c0                	xor    %eax,%eax
   2274b:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   2274f:	66 0f 2e e9          	ucomisd %xmm1,%xmm5
   22753:	72 3e                	jb     22793 <gpui_canvas::color::gamut::in_gamut+0x553>
   22755:	f2 0f 10 0d c3 4a fe 	movsd  -0x1b53d(%rip),%xmm1        # 7220 <std::thread::current::id::ID+0x65a8>
   2275c:	ff 
   2275d:	66 0f 2e cd          	ucomisd %xmm5,%xmm1
   22761:	72 30                	jb     22793 <gpui_canvas::color::gamut::in_gamut+0x553>
   22763:	66 0f 15 ed          	unpckhpd %xmm5,%xmm5
   22767:	31 c0                	xor    %eax,%eax
   22769:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   2276d:	66 0f 2e ea          	ucomisd %xmm2,%xmm5
   22771:	72 20                	jb     22793 <gpui_canvas::color::gamut::in_gamut+0x553>
   22773:	66 0f 2e cd          	ucomisd %xmm5,%xmm1
   22777:	72 1a                	jb     22793 <gpui_canvas::color::gamut::in_gamut+0x553>
   22779:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   2277d:	f2 0f c2 c8 02       	cmplesd %xmm0,%xmm1
   22782:	f2 0f c2 05 95 4a fe 	cmplesd -0x1b56b(%rip),%xmm0        # 7220 <std::thread::current::id::ID+0x65a8>
   22789:	ff 02 
   2278b:	66 0f 54 c1          	andpd  %xmm1,%xmm0
   2278f:	66 0f 7e c0          	movd   %xmm0,%eax
   22793:	24 01                	and    $0x1,%al
   22795:	48 83 c4 68          	add    $0x68,%rsp
   22799:	5b                   	pop    %rbx
   2279a:	5d                   	pop    %rbp
   2279b:	c3                   	ret
   2279c:	66 0f 6e c0          	movd   %eax,%xmm0
   227a0:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   227a4:	f2 0f 59 05 a4 4b fe 	mulsd  -0x1b45c(%rip),%xmm0        # 7350 <std::thread::current::id::ID+0x66d8>
   227ab:	ff 
   227ac:	48 8d 7c 24 48       	lea    0x48(%rsp),%rdi
   227b1:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
   227b6:	0f 29 0c 24          	movaps %xmm1,(%rsp)
   227ba:	66 0f 7f 54 24 30    	movdqa %xmm2,0x30(%rsp)
   227c0:	ff 15 5a 2a 04 00    	call   *0x42a5a(%rip)        # 65220 <sincos@GLIBC_2.2.5>
   227c6:	0f 28 44 24 30       	movaps 0x30(%rsp),%xmm0
   227cb:	0f 57 c9             	xorps  %xmm1,%xmm1
   227ce:	f3 0f 5a c8          	cvtss2sd %xmm0,%xmm1
   227d2:	0f 28 04 24          	movaps (%rsp),%xmm0
   227d6:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   227da:	f2 0f 10 54 24 40    	movsd  0x40(%rsp),%xmm2
   227e0:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
   227e4:	f2 0f 59 44 24 48    	mulsd  0x48(%rsp),%xmm0
   227ea:	f2 0f 10 1d 36 4b fe 	movsd  -0x1b4ca(%rip),%xmm3        # 7328 <std::thread::current::id::ID+0x66b0>
   227f1:	ff 
   227f2:	f2 0f 59 da          	mulsd  %xmm2,%xmm3
   227f6:	f2 0f 58 d9          	addsd  %xmm1,%xmm3
   227fa:	f2 0f 10 2d be 4a fe 	movsd  -0x1b542(%rip),%xmm5        # 72c0 <std::thread::current::id::ID+0x6648>
   22801:	ff 
   22802:	f2 0f 59 e8          	mulsd  %xmm0,%xmm5
   22806:	f2 0f 58 eb          	addsd  %xmm3,%xmm5
   2280a:	f2 0f 10 1d 6e 4a fe 	movsd  -0x1b592(%rip),%xmm3        # 7280 <std::thread::current::id::ID+0x6608>
   22811:	ff 
   22812:	f2 0f 59 da          	mulsd  %xmm2,%xmm3
   22816:	f2 0f 58 d9          	addsd  %xmm1,%xmm3
   2281a:	f2 0f 10 35 66 4b fe 	movsd  -0x1b49a(%rip),%xmm6        # 7388 <std::thread::current::id::ID+0x6710>
   22821:	ff 
   22822:	f2 0f 59 f0          	mulsd  %xmm0,%xmm6
   22826:	f2 0f 58 f3          	addsd  %xmm3,%xmm6
   2282a:	f2 0f 59 15 de 4a fe 	mulsd  -0x1b522(%rip),%xmm2        # 7310 <std::thread::current::id::ID+0x6698>
   22831:	ff 
   22832:	f2 0f 58 d1          	addsd  %xmm1,%xmm2
   22836:	f2 0f 59 05 2a 49 fe 	mulsd  -0x1b6d6(%rip),%xmm0        # 7168 <std::thread::current::id::ID+0x64f0>
   2283d:	ff 
   2283e:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   22842:	66 0f 28 e5          	movapd %xmm5,%xmm4
   22846:	f2 0f 59 e5          	mulsd  %xmm5,%xmm4
   2284a:	f2 0f 59 e5          	mulsd  %xmm5,%xmm4
   2284e:	66 0f 28 de          	movapd %xmm6,%xmm3
   22852:	f2 0f 59 de          	mulsd  %xmm6,%xmm3
   22856:	f2 0f 59 de          	mulsd  %xmm6,%xmm3
   2285a:	66 0f 28 c8          	movapd %xmm0,%xmm1
   2285e:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   22862:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   22866:	f2 0f 10 05 22 4b fe 	movsd  -0x1b4de(%rip),%xmm0        # 7390 <std::thread::current::id::ID+0x6718>
   2286d:	ff 
   2286e:	f2 0f 59 c4          	mulsd  %xmm4,%xmm0
   22872:	f2 0f 10 15 be 49 fe 	movsd  -0x1b642(%rip),%xmm2        # 7238 <std::thread::current::id::ID+0x65c0>
   22879:	ff 
   2287a:	f2 0f 59 d3          	mulsd  %xmm3,%xmm2
   2287e:	f2 0f 58 d0          	addsd  %xmm0,%xmm2
   22882:	f2 0f 10 05 b6 49 fe 	movsd  -0x1b64a(%rip),%xmm0        # 7240 <std::thread::current::id::ID+0x65c8>
   22889:	ff 
   2288a:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   2288e:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   22892:	f2 0f 10 15 de 48 fe 	movsd  -0x1b722(%rip),%xmm2        # 7178 <std::thread::current::id::ID+0x6500>
   22899:	ff 
   2289a:	66 0f 14 e4          	unpcklpd %xmm4,%xmm4
   2289e:	66 0f 59 25 aa 2e fe 	mulpd  -0x1d156(%rip),%xmm4        # 5750 <std::thread::current::id::ID+0x4ad8>
   228a5:	ff 
   228a6:	66 0f 14 db          	unpcklpd %xmm3,%xmm3
   228aa:	66 0f 59 1d ae 2e fe 	mulpd  -0x1d152(%rip),%xmm3        # 5760 <std::thread::current::id::ID+0x4ae8>
   228b1:	ff 
   228b2:	66 0f 58 dc          	addpd  %xmm4,%xmm3
   228b6:	66 0f 14 c9          	unpcklpd %xmm1,%xmm1
   228ba:	66 0f 59 0d 5e 2c fe 	mulpd  -0x1d3a2(%rip),%xmm1        # 5520 <std::thread::current::id::ID+0x48a8>
   228c1:	ff 
   228c2:	66 0f 58 cb          	addpd  %xmm3,%xmm1
   228c6:	e9 0d fd ff ff       	jmp    225d8 <gpui_canvas::color::gamut::in_gamut+0x398>

