from pathlib import Path
import hashlib
import json
import os
import subprocess

root = Path('/tmp/gpui-compact-slice-root')
output = Path('/tmp/gpui-compact-slice-evidence/miri-v2')
output.mkdir(exist_ok=False)
pin = '5bb2f124f57c73a4183c066ff09169c36f9cf644'
tool = Path(os.environ['MIRI'])
(output / 'tool.json').write_text(json.dumps({'miri': str(tool), 'sha256': hashlib.sha256(tool.read_bytes()).hexdigest(), 'bootstrap': os.environ.get('RUSTC_BOOTSTRAP'), 'rust_source': os.environ['RUST_SRC_PATH']}, indent=2) + '\n')
results = []
for target, short in [('x86_64-unknown-linux-gnu', 'x86_64'), ('i686-unknown-linux-gnu', 'i686'), ('s390x-unknown-linux-gnu', 's390x')]:
    for model, extra in [('stacked', ''), ('tree', ' -Zmiri-tree-borrows')]:
        name = short + '-' + model
        env = os.environ.copy()
        env['MIRI_SYSROOT'] = '/tmp/gpui-short-text-miri-sysroot-' + short
        env['MIRIFLAGS'] = '-Zmiri-strict-provenance -Zmiri-symbolic-alignment-check -Zmiri-seed=0' + extra
        command = ['/nix/store/9r02ykx9y35lf4gk6gc30gnag1y8ncp7-python3-3.13.15/bin/python3', '/tmp/gpui-run-frozen-gate-root.py', '--source', str(root), '--pin', pin, '--out', str(output / name), '--timeout', '180', '--', 'cargo', 'miri', 'test', '--offline', '--locked', '--lib', '--target', target, '--', '--test-threads=1']
        completed = subprocess.run(command, cwd=root, env=env)
        results.append({'gate': name, 'exit': completed.returncode})
        (output / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
assert all(row['exit'] == 0 for row in results)
