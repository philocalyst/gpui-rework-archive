from pathlib import Path
import hashlib,json,os,subprocess,sys,time
root=Path('/root/gpui-component-default-simd-sol-20261024');lane=sys.argv[1];prefix=Path('/tmp/gpui-component-simd-')
py='/nix/store/9r02ykx9y35lf4gk6gc30gnag1y8ncp7-python3-3.13.15/bin/python3'
target='/root/targets/component-ime-review-sol-'+lane+'-20261024' if lane!='default' else '/root/targets/component-ime-review-sol-20261024'
if lane=='hummingbird':target='/root/targets/component-default-simd-sol-hummingbird-20261024'
base=['--manifest-path','reactivity/Cargo.toml'];tail=['--locked','--offline','-j4','-Z','checksum-freshness','--config','build.fingerprint="content"']
if lane=='default':
 clean=['cargo','clean',*base,'--profile','dev']
 for pkg in ['gpui','gpui-component','gpui_canvas','gpui_gpu','gpui_inline_call','gpui_reactivity_core','gpui_reactivity_state','gpui_reactivity_host']:clean+=['-p',pkg]
 commands=[('clean-default',clean),('full-default',['cargo','test',*base,'-p','gpui','-p','gpui-component',*tail,'--message-format=json']),('standalone-default',['cargo','test',*base,'-p','gpui-component',*tail,'--message-format=json']),('strict-default',['cargo','clippy',*base,'-p','gpui','-p','gpui-component','--all-targets',*tail,'--message-format=json','--','-D','warnings'])]
elif lane=='native':commands=[('native-unit',['cargo','test',*base,'-p','gpui','--features','native,x11','--lib',*tail,'--message-format=json']),('strict-native',['cargo','clippy',*base,'-p','gpui','-p','gpui-component','--features','native,x11','--all-targets',*tail,'--message-format=json','--','-D','warnings'])]
elif lane=='hummingbird':commands=[('hummingbird-fresh',['cargo','check','--manifest-path','reactivity/ports/hummingbird/Cargo.toml','--all-targets',*tail,'--message-format=json'])]
else:raise ValueError(lane)
if lane=='native':
 clean=['cargo','clean',*base,'--profile','dev']
 for pkg in ['gpui','gpui-component','gpui_canvas','gpui_gpu','gpui_inline_call','gpui_reactivity_core','gpui_reactivity_state','gpui_reactivity_host']:clean+=['-p',pkg]
 commands.insert(0,('clean-native',clean))
guard='/tmp/gpui-component-simd-'+('port-inputs.py' if lane=='hummingbird' else 'inputs.py')
records=[]
for name,argv in commands:
 before=Path('/tmp/gpui-component-simd-'+name+'.before.json');after=Path('/tmp/gpui-component-simd-'+name+'.after.json');subprocess.run([py,guard,str(before)],check=True)
 Path('/tmp/gpui-component-simd-'+name+'.command.json').write_text(json.dumps(dict(argv=argv,cwd=str(root),target=target,dev_debug=0,test_debug=0,incremental=0),indent=2)+'\n')
 import shlex
 shell='source /tmp/gpui-native-env.sh\nsource /tmp/gpui-nightly-env.sh\nexport CARGO_TARGET_DIR='+shlex.quote(target)+'\nexport CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0\nexec '+shlex.join(argv)
 started=time.monotonic()
 with Path('/tmp/gpui-component-simd-'+name+'.jsonl').open('w') as stdout,Path('/tmp/gpui-component-simd-'+name+'.log').open('w') as stderr:r=subprocess.run(['bash','-c',shell],cwd=root,stdout=stdout,stderr=stderr)
 subprocess.run([py,guard,str(after)],check=True);assert json.loads(before.read_text())==json.loads(after.read_text())
 records.append(dict(name=name,exit=r.returncode,seconds=time.monotonic()-started));print(records[-1],flush=True)
Path('/tmp/gpui-component-simd-'+lane+'-fresh-gates.json').write_text(json.dumps(records,indent=2)+'\n')
raise SystemExit(any(row['exit'] for row in records))
