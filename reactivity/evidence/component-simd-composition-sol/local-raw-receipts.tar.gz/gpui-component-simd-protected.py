from pathlib import Path
import json,hashlib,subprocess,tomllib
root=Path('/root/gpui-component-default-simd-sol-20261024');base='fea3dc224b440dd807cebd088cc959b8626668de'
feature=set(subprocess.check_output(['git','-C',str(root),'diff','--name-only','957cf9d0865e9fd30a7e3d4ba4dea2e8aa97221c','3fc07815a0ce389db54e492dd1d889c6fca10699'],text=True).splitlines())
tracked=subprocess.check_output(['git','-C',str(root),'ls-tree','-r','--name-only',base,'reactivity/crates','reactivity/vendor','.cargo','clippy.toml','reactivity/Cargo.toml','reactivity/Cargo.lock','reactivity/ports/hummingbird'],text=True).splitlines()
records={}
for name in tracked:
 if name in feature:continue
 q=root/name
 assert q.is_file(),name
 actual=q.read_bytes();expected=subprocess.check_output(['git','-C',str(root),'show',base+':'+name]);assert actual==expected,name
 records[name]=hashlib.sha256(actual).hexdigest()
for closure in ['reader','remote.rs','runtime/ime.rs','shared_text.rs','examples/todo','ports/hummingbird/Cargo.lock']:
 print(closure,sum(closure in name for name in records))
lock=tomllib.loads((root/'reactivity/Cargo.lock').read_text());pkgs={x['name']:x for x in lock['package'] if x['name'] in ['gpui','gpui-component']}
assert 'parking_lot' in pkgs['gpui']['dependencies'];assert pkgs['gpui-component']['dependencies']==['allocation-counter','gpui']
Path('/tmp/gpui-component-simd-protected.json').write_text(json.dumps(dict(parent=base,files_byte_identical=records,reviewed_feature_exceptions=sorted(feature),lock_edges=pkgs),indent=2)+'\n')
print('protected',len(records))
