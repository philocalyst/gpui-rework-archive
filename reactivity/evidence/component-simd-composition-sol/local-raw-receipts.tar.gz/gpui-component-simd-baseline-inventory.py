from pathlib import Path
import sys,json
sys.path.insert(0,'/root/gpui-component-default-simd-sol-20261024/reactivity/tools')
import core_lines
r=core_lines.count('fea3dc224b440dd807cebd088cc959b8626668de',False,Path('/tmp/gpui-inventory-sol-target/release/inventory-rust'),Path('/nix/store/4m90mv0fyihsdrnidw8gkgmx6zvd5vqm-tokei-15.0.0/bin/tokei'))
Path('/tmp/gpui-component-simd-baseline-inventory.json').write_text(json.dumps(r,indent=2)+'\n');print(r['core_non_test_code_lines'])
