from pathlib import Path
import hashlib,json,os,select,signal,subprocess,sys
out=Path('/tmp/gpui-component-simd-native-fixtures');out.mkdir()
row=json.loads(Path('/root/gpui-component-simd-sol-artifacts-20261024/native-unit-14006e63d0/manifest.json').read_text())[0];binary=Path(row['frozen']);before=hashlib.sha256(binary.read_bytes()).hexdigest();assert before==row['sha256'];(out/'binary.json').write_text(json.dumps(row,indent=2)+'\n')
results=[];r,w=os.pipe()
with (out/'xvfb.log').open('w') as log:
 server=subprocess.Popen(['/nix/store/iw8dx6lhrkdc5wzszjzqzl677y68y88r-xvfb-21.1.24/bin/Xvfb','-displayfd',str(w),'-screen','0','1024x768x24','-nolisten','tcp'],pass_fds=(w,),stdout=log,stderr=subprocess.STDOUT)
 os.close(w)
 try:
  assert select.select([r],[],[],20)[0];display=':'+os.read(r,32).decode().strip();runtime=out/'runtime';runtime.mkdir(mode=0o700)
  env=dict(os.environ,DISPLAY=display,GSETTINGS_BACKEND='memory',XDG_RUNTIME_DIR=str(runtime),WINIT_X11_SCALE_FACTOR='1.25')
  for key in ['WAYLAND_DISPLAY','AT_SPI_BUS_ADDRESS','NO_AT_BRIDGE']:env.pop(key,None)
  cases=[('invalid','native::accessibility::linux_tests::invalid::native_atspi_invalid_input_state_and_events',False),('ime','native::accessibility::linux_tests::ime::native_atspi_ime_cjk_preview_old_candidate_ack_and_commit',True),('inspector','native::property_action_tests::native_contained_property_entry_recovers_and_reports_stale_targets',False)]
  for label,test,launcher in cases:
   argv=['/nix/store/8snmq54bp5d5vp5dihgn7xr53hayx629-dbus-1.16.2/bin/dbus-run-session','--']
   argv+=['/nix/store/9r02ykx9y35lf4gk6gc30gnag1y8ncp7-python3-3.13.15/bin/python3','/tmp/gpui-component-ime-atspi-launch.py',str(out),str(binary),test] if launcher else [str(binary),test,'--exact','--ignored','--nocapture','--test-threads=1']
   with (out/(label+'.stdout.log')).open('w') as stdout,(out/(label+'.stderr.log')).open('w') as stderr:
    p=subprocess.Popen(argv,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
    try:code=p.wait(timeout=70)
    finally:
     try:os.killpg(p.pid,signal.SIGTERM)
     except ProcessLookupError:pass
     if p.poll() is None:p.wait(timeout=5)
   results.append(dict(label=label,argv=argv,exit=code));print(results[-1],flush=True)
 finally:
  os.close(r);server.terminate()
  try:server.wait(timeout=5)
  except subprocess.TimeoutExpired:server.kill();server.wait()
assert hashlib.sha256(binary.read_bytes()).hexdigest()==before
(out/'result.json').write_text(json.dumps(dict(tests=results,binary_unchanged=True,children_reaped=True),indent=2)+'\n');sys.exit(any(r['exit'] for r in results))
