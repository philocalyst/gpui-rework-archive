from pathlib import Path
import json,subprocess,re,hashlib,tarfile,io
art=Path('/root/gpui-component-simd-sol-artifacts-20261024');r=json.loads((art/'native-app-14006e63d0/manifest.json').read_text())[0];p=Path(r['frozen'])
s=subprocess.check_output(['/nix/store/ddk8rvjihg4vhh1k6x9rc65y1zb1kx34-binutils-2.46/bin/readelf','-SW',str(p)],text=True);Path('/tmp/gpui-component-simd-native-app-sections.txt').write_text(s);match=re.search(r'\[\s*\d+\]\s+\.text\s+\S+\s+\S+\s+\S+\s+(\S+)',s);r['text_bytes']=int(match.group(1),16);Path('/tmp/gpui-component-simd-codegen.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
selected=[]
for manifest in art.glob('*/manifest.json'):
 rows=json.loads(manifest.read_text())
 for row in rows:
  if manifest.parent.name in ['native-unit-14006e63d0','native-app-14006e63d0'] or manifest.parent.name=='full-default-14006e63d0' and row['name'] in ['ime_contracts','ime','boolean_cohorts','question_futures','binding_costs','costs']:selected.append(row)
archive=art/'qualified-14006-key-executables.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for i,row in enumerate(selected):
  p=Path(row['frozen']);assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'];tar.add(p,arcname=str(i)+'-'+p.name)
 data=(json.dumps(selected,indent=2)+'\n').encode();info=tarfile.TarInfo('manifest.json');info.size=len(data);tar.addfile(info,io.BytesIO(data))
receipt=dict(path=str(archive),bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),executables=len(selected),source='14006e63d086c29229679db5edc823bec8a7912f');Path('/tmp/gpui-component-simd-key-executables.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
