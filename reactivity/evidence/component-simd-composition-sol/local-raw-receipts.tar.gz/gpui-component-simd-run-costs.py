from pathlib import Path
import hashlib,json,subprocess
art=Path('/root/gpui-component-simd-sol-artifacts-20261024');records=json.loads((art/'full-default-14006e63d0/manifest.json').read_text());out=Path('/tmp/gpui-component-simd-costs');out.mkdir();result=[]
for name in ['binding_costs','costs']:
 matches=[r for r in records if r['name']==name and '/component#' in r['package']];assert len(matches)==1,matches;r=matches[0];p=Path(r['frozen']);assert hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256']
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:code=subprocess.run([str(p)],stdout=stdout,stderr=stderr).returncode
 assert code==0;assert hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256'];result.append(dict(binary=r,exit=code))
(out/'receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
