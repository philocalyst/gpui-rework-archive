from pathlib import Path
import json
p=Path('/tmp/gpui-component-simd-codegen.py');p.write_text(p.read_text().replace('14006e63d01f44d503f1df9b4947c929c6742160','14006e63d086c29229679db5edc823bec8a7912f'))
p=Path('/tmp/gpui-component-simd-key-executables.json');r=json.loads(p.read_text());r['source']='14006e63d086c29229679db5edc823bec8a7912f';p.write_text(json.dumps(r,indent=2)+'\n')
local=Path('/tmp/gpui-component-simd-mac-14006-sol');base=Path('/tmp/gpui-component-ime-mac-3ab1-sol')
s=(base/'gateway.py').read_text().replace(str(base),str(local));(local/'gateway.py').write_text(s)
s=(base/'job.py').read_text().replace('component-ime-3ab1d964-sol','component-simd-14006e63-sol').replace('3ab1d964981f44d503f1df9b4947c929c6742160','14006e63d086c29229679db5edc823bec8a7912f').replace('2102','2103').replace('Main0e97','Mainfea3dc (ordinary component SIMD defaults)')
# Freeze the actual standalone app feature closure along with its executable.
s=s.replace("status['application'] = freeze('native-app-build', False) if app_code == 0 else []",'''status['application'] = freeze('native-app-build', False) if app_code == 0 else []
        app_rows=[json.loads(line) for line in (out/'native-app-build.stdout').read_text().splitlines() if line.startswith('{')]
        features={name:sorted({feature for row in app_rows if row.get('reason')=='compiler-artifact' and row['target']['name']==name for feature in row['features']}) for name in ['gpui','gpui_canvas','gpui_gpu']}
        assert all('simd' in values for values in features.values()),features
        (out/'standalone-app-feature-resolution.json').write_text(json.dumps(features,indent=2)+'\\n')''')
(local/'job.py').write_text(s)
s=(base/'stage.py').read_text().replace(str(base),str(local)).replace('component-ime-3ab1d964-sol','component-simd-14006e63-sol').replace('65536','40960')
s=s[:s.index("job=(local/'job.py')")]
(local/'stage-only.py').write_text(s)
s=(base/'poll.py').read_text().replace(str(base),str(local)).replace('component-ime-3ab1d964-sol','component-simd-14006e63-sol');(local/'poll.py').write_text(s)
