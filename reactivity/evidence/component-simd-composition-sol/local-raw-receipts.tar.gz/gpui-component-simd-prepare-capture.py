from pathlib import Path
s=Path('/tmp/gpui-boolean-cohort-native-capture.py').read_text().replace('/root/targets/boolean-cohort-sol-native-20261024/debug/examples/halloween','/root/gpui-component-simd-sol-artifacts-20261024/native-app-14006e63d0/halloween-halloween').replace('gpui-boolean-cohort','gpui-component-simd')
Path('/tmp/gpui-component-simd-native-capture.py').write_text(s)
