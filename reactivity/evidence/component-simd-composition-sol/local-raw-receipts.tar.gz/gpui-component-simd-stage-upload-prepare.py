from pathlib import Path
local=Path('/tmp/gpui-component-simd-mac-14006-sol');s=(local/'stage-only.py').read_text();index=s.index("extract='''");s=s[:index];s=s.replace('free>20*1024**3','free>4*1024**2');(local/'stage-upload-only.py').write_text(s)
