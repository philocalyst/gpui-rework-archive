from pathlib import Path
import json,subprocess,shlex,sys
root=Path('/root/gpui-component-default-simd-sol-20261024');py='/nix/store/9r02ykx9y35lf4gk6gc30gnag1y8ncp7-python3-3.13.15/bin/python3';target='/root/targets/component-ime-review-sol-native-20261024'
common=['--manifest-path','reactivity/Cargo.toml','-p','gpui-component','--features','native,x11','--example','halloween','--locked','--offline','-j4','-Z','checksum-freshness','--config','build.fingerprint="content"','--message-format=json']
for name,argv,expected in [('app',['cargo','build',*common],True),('scalar-opt-out',['cargo','check',*common,'--no-default-features'],False)]:
 before=Path('/tmp/gpui-component-simd-'+name+'.before.json');after=Path('/tmp/gpui-component-simd-'+name+'.after.json');subprocess.run([py,'/tmp/gpui-component-simd-inputs.py',str(before)],check=True)
 Path('/tmp/gpui-component-simd-'+name+'.command.json').write_text(json.dumps(dict(argv=argv,cwd=str(root),target=target),indent=2)+'\n')
 shell='source /tmp/gpui-native-env.sh\nsource /tmp/gpui-nightly-env.sh\nexport CARGO_TARGET_DIR='+shlex.quote(target)+'\nexport CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0\nexec '+shlex.join(argv)
 with Path('/tmp/gpui-component-simd-'+name+'.jsonl').open('w') as stdout,Path('/tmp/gpui-component-simd-'+name+'.log').open('w') as stderr:result=subprocess.run(['bash','-c',shell],cwd=root,stdout=stdout,stderr=stderr)
 subprocess.run([py,'/tmp/gpui-component-simd-inputs.py',str(after)],check=True);assert json.loads(before.read_text())==json.loads(after.read_text());assert result.returncode==0,name
 rows=[json.loads(l) for l in Path('/tmp/gpui-component-simd-'+name+'.jsonl').read_text().splitlines() if l.startswith('{')]
 graph={n:[r['features'] for r in rows if r.get('reason')=='compiler-artifact' and r['target']['name']==n and not r['profile']['test']] for n in ['gpui','gpui_canvas','gpui_gpu']}
 for n,records in graph.items():assert records and all(('simd' in f)==expected for f in records),(name,n,records)
 Path('/tmp/gpui-component-simd-'+name+'-feature-resolution.json').write_text(json.dumps(dict(simd_expected=expected,actual_libraries=graph),indent=2)+'\n');print(name,graph,flush=True)
 if name=='app':subprocess.run([py,'/tmp/gpui-component-simd-freeze.py','14006e63d086c29229679db5edc823bec8a7912f','native-app','/tmp/gpui-component-simd-app.jsonl'],check=True)
