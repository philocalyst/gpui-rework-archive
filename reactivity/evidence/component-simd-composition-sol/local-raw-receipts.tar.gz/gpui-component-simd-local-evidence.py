from pathlib import Path
import hashlib,io,json,shutil,tarfile
root=Path('/root/gpui-component-default-simd-sol-20261024');out=root/'reactivity/evidence/component-simd-composition-sol';out.mkdir(parents=True,exist_ok=True)
assert json.loads(Path('/tmp/gpui-component-simd-full-default.before.json').read_text())==json.loads(Path('/tmp/gpui-component-simd-final-local.after.json').read_text())
files={}
for pattern in ['gpui-component-simd-*.py','gpui-component-simd-*.json','gpui-component-simd-*.jsonl','gpui-component-simd-*.log','gpui-component-simd-*.stdout','gpui-component-simd-*.stderr']:
 for p in Path('/tmp').glob(pattern):
  if p.is_file():files[p.name]=p
for name in ['gpui-component-simd-costs','gpui-component-simd-native-fixtures']:
 for p in sorted((Path('/tmp')/name).rglob('*')):
  if p.is_file():files[name+'/'+str(p.relative_to(Path('/tmp')/name))]=p
members={};seen={}
with tarfile.open(out/'local-raw-receipts.tar.gz','w:gz') as tar:
 for name,p in sorted(files.items()):
  data=p.read_bytes();h=hashlib.sha256(data).hexdigest();members[name]={'bytes':len(data),'sha256':h}
  if h in seen:
   info=tar.gettarinfo(str(p),arcname=name);info.type=tarfile.LNKTYPE;info.linkname=seen[h];info.size=0;tar.addfile(info)
  else:tar.add(p,arcname=name);seen[h]=name
(out/'local-members.json').write_text(json.dumps(members,indent=2)+'\n')
copy={'/tmp/gpui-component-simd-inventory.json':'inventory.json','/tmp/gpui-component-simd-baseline-inventory.json':'baseline-inventory.json','/tmp/gpui-component-simd-protected.json':'protected.json','/tmp/gpui-component-simd-key-executables.json':'key-executables.json','/tmp/gpui-component-simd-app-feature-resolution.json':'standalone-simd-features.json','/tmp/gpui-component-simd-scalar-opt-out-feature-resolution.json':'scalar-opt-out-features.json'}
for p,n in copy.items():shutil.copy2(p,out/n)
records=[]
for p in sorted(Path('/root/gpui-component-simd-sol-artifacts-20261024').glob('*/manifest.json')):records.extend(json.loads(p.read_text()))
(out/'actual-frozen-executables.json').write_text(json.dumps(records,indent=2)+'\n')
for name in ['draft','focus','disabled','ready','resized']:shutil.copy2('/tmp/gpui-component-simd-halloween-native-'+name+'.png',out/('halloween-'+name+'.png'))
index={p.name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(out.iterdir()) if p.is_file()};(out/'local-artifacts.json').write_text(json.dumps(index,indent=2)+'\n');print(len(members),len(records),index['local-raw-receipts.tar.gz'])
