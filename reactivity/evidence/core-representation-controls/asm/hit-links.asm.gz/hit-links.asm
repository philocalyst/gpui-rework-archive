
/tmp/gpui-core-controls-artifacts/hit_cost-links-7768406cd14b0a536f3ac2d658e7be6914eb7c9dd6695353cb689182ce3e2738:     file format elf64-x86-64


Disassembly of section .text:

00000000004ed460 <<gpui::runtime::Win<hit_cost::Page>>::hit_target>:
  4ed460:	55                   	push   %rbp
  4ed461:	41 57                	push   %r15
  4ed463:	41 56                	push   %r14
  4ed465:	41 55                	push   %r13
  4ed467:	41 54                	push   %r12
  4ed469:	53                   	push   %rbx
  4ed46a:	48 81 ec 98 00 00 00 	sub    $0x98,%rsp
  4ed471:	48 8b 1e             	mov    (%rsi),%rbx
  4ed474:	48 85 db             	test   %rbx,%rbx
  4ed477:	0f 84 05 01 00 00    	je     4ed582 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x122>
  4ed47d:	b8 0e 00 00 00       	mov    $0xe,%eax
  4ed482:	80 bb 1e 09 00 00 00 	cmpb   $0x0,0x91e(%rbx)
  4ed489:	0f 85 f8 00 00 00    	jne    4ed587 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x127>
  4ed48f:	b8 12 00 00 00       	mov    $0x12,%eax
  4ed494:	80 bb 1a 09 00 00 01 	cmpb   $0x1,0x91a(%rbx)
  4ed49b:	0f 85 e6 00 00 00    	jne    4ed587 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x127>
  4ed4a1:	80 bb 1b 09 00 00 00 	cmpb   $0x0,0x91b(%rbx)
  4ed4a8:	0f 85 d9 00 00 00    	jne    4ed587 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x127>
  4ed4ae:	80 bb 1c 09 00 00 01 	cmpb   $0x1,0x91c(%rbx)
  4ed4b5:	0f 85 cc 00 00 00    	jne    4ed587 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x127>
  4ed4bb:	48 83 bb 20 07 00 00 	cmpq   $0xffffffffffffffff,0x720(%rbx)
  4ed4c2:	ff 
  4ed4c3:	0f 85 be 00 00 00    	jne    4ed587 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x127>
  4ed4c9:	48 8b 8b 20 08 00 00 	mov    0x820(%rbx),%rcx
  4ed4d0:	48 3b 8b 28 08 00 00 	cmp    0x828(%rbx),%rcx
  4ed4d7:	0f 85 aa 00 00 00    	jne    4ed587 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x127>
  4ed4dd:	48 8b 8b 30 08 00 00 	mov    0x830(%rbx),%rcx
  4ed4e4:	48 39 8b 38 08 00 00 	cmp    %rcx,0x838(%rbx)
  4ed4eb:	0f 85 96 00 00 00    	jne    4ed587 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x127>
  4ed4f1:	f3 0f 10 93 10 09 00 	movss  0x910(%rbx),%xmm2
  4ed4f8:	00 
  4ed4f9:	0f 2e 93 14 09 00 00 	ucomiss 0x914(%rbx),%xmm2
  4ed500:	0f 85 81 00 00 00    	jne    4ed587 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x127>
  4ed506:	7a 7f                	jp     4ed587 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x127>
  4ed508:	49 89 fd             	mov    %rdi,%r13
  4ed50b:	48 89 c8             	mov    %rcx,%rax
  4ed50e:	48 c1 e8 20          	shr    $0x20,%rax
  4ed512:	89 c9                	mov    %ecx,%ecx
  4ed514:	f3 48 0f 2a d9       	cvtsi2ss %rcx,%xmm3
  4ed519:	89 c0                	mov    %eax,%eax
  4ed51b:	0f 57 d2             	xorps  %xmm2,%xmm2
  4ed51e:	f3 48 0f 2a d0       	cvtsi2ss %rax,%xmm2
  4ed523:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
  4ed52a:	00 00 
  4ed52c:	f3 0f 11 5c 24 38    	movss  %xmm3,0x38(%rsp)
  4ed532:	f3 0f 11 54 24 3c    	movss  %xmm2,0x3c(%rsp)
  4ed538:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
  4ed53d:	f3 0f 11 44 24 08    	movss  %xmm0,0x8(%rsp)
  4ed543:	f3 0f 11 4c 24 0c    	movss  %xmm1,0xc(%rsp)
  4ed549:	ff 15 19 cf 33 00    	call   *0x33cf19(%rip)        # 82a468 <_DYNAMIC+0x498>
  4ed54f:	84 c0                	test   %al,%al
  4ed551:	0f 84 9a 02 00 00    	je     4ed7f1 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x391>
  4ed557:	48 8b 83 18 07 00 00 	mov    0x718(%rbx),%rax
  4ed55e:	48 85 c0             	test   %rax,%rax
  4ed561:	4c 89 ef             	mov    %r13,%rdi
  4ed564:	0f 84 91 02 00 00    	je     4ed7fb <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x39b>
  4ed56a:	4c 8d 64 24 30       	lea    0x30(%rsp),%r12
  4ed56f:	bd ff ff 01 00       	mov    $0x1ffff,%ebp
  4ed574:	f3 0f 10 4c 24 0c    	movss  0xc(%rsp),%xmm1
  4ed57a:	f3 0f 10 44 24 08    	movss  0x8(%rsp),%xmm0
  4ed580:	eb 2f                	jmp    4ed5b1 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x151>
  4ed582:	b8 0d 00 00 00       	mov    $0xd,%eax
  4ed587:	48 89 07             	mov    %rax,(%rdi)
  4ed58a:	48 89 f8             	mov    %rdi,%rax
  4ed58d:	48 81 c4 98 00 00 00 	add    $0x98,%rsp
  4ed594:	5b                   	pop    %rbx
  4ed595:	41 5c                	pop    %r12
  4ed597:	41 5d                	pop    %r13
  4ed599:	41 5e                	pop    %r14
  4ed59b:	41 5f                	pop    %r15
  4ed59d:	5d                   	pop    %rbp
  4ed59e:	c3                   	ret
  4ed59f:	48 29 d0             	sub    %rdx,%rax
  4ed5a2:	49 89 c7             	mov    %rax,%r15
  4ed5a5:	4c 89 f8             	mov    %r15,%rax
  4ed5a8:	4d 85 ff             	test   %r15,%r15
  4ed5ab:	0f 84 f2 02 00 00    	je     4ed8a3 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x443>
  4ed5b1:	4c 8d 78 ff          	lea    -0x1(%rax),%r15
  4ed5b5:	48 8b b3 18 07 00 00 	mov    0x718(%rbx),%rsi
  4ed5bc:	49 39 f7             	cmp    %rsi,%r15
  4ed5bf:	0f 83 04 03 00 00    	jae    4ed8c9 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x469>
  4ed5c5:	4c 8b b3 10 07 00 00 	mov    0x710(%rbx),%r14
  4ed5cc:	4b 8d 0c bf          	lea    (%r15,%r15,4),%rcx
  4ed5d0:	48 c1 e1 04          	shl    $0x4,%rcx
  4ed5d4:	41 8b 54 0e 48       	mov    0x48(%r14,%rcx,1),%edx
  4ed5d9:	c1 ea 11             	shr    $0x11,%edx
  4ed5dc:	75 c1                	jne    4ed59f <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x13f>
  4ed5de:	49 01 ce             	add    %rcx,%r14
  4ed5e1:	41 0f 10 56 10       	movups 0x10(%r14),%xmm2
  4ed5e6:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
  4ed5eb:	4c 89 e7             	mov    %r12,%rdi
  4ed5ee:	ff 15 74 ce 33 00    	call   *0x33ce74(%rip)        # 82a468 <_DYNAMIC+0x498>
  4ed5f4:	84 c0                	test   %al,%al
  4ed5f6:	0f 84 e1 01 00 00    	je     4ed7dd <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x37d>
  4ed5fc:	f3 41 0f 10 4e 30    	movss  0x30(%r14),%xmm1
  4ed602:	0f 2e c9             	ucomiss %xmm1,%xmm1
  4ed605:	0f 8a d2 01 00 00    	jp     4ed7dd <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x37d>
  4ed60b:	41 8b 46 44          	mov    0x44(%r14),%eax
  4ed60f:	48 8d 4c 24 14       	lea    0x14(%rsp),%rcx
  4ed614:	89 41 10             	mov    %eax,0x10(%rcx)
  4ed617:	41 0f 10 46 34       	movups 0x34(%r14),%xmm0
  4ed61c:	0f 11 01             	movups %xmm0,(%rcx)
  4ed61f:	f3 0f 11 4c 24 10    	movss  %xmm1,0x10(%rsp)
  4ed625:	48 8b 83 d0 07 00 00 	mov    0x7d0(%rbx),%rax
  4ed62c:	48 85 c0             	test   %rax,%rax
  4ed62f:	f3 0f 10 54 24 0c    	movss  0xc(%rsp),%xmm2
  4ed635:	f3 0f 10 5c 24 08    	movss  0x8(%rsp),%xmm3
  4ed63b:	74 3e                	je     4ed67b <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x21b>
  4ed63d:	48 8b b8 f0 00 00 00 	mov    0xf0(%rax),%rdi
  4ed644:	48 85 ff             	test   %rdi,%rdi
  4ed647:	74 32                	je     4ed67b <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x21b>
  4ed649:	49 8b 76 20          	mov    0x20(%r14),%rsi
  4ed64d:	0f 29 4c 24 70       	movaps %xmm1,0x70(%rsp)
  4ed652:	ff 15 18 ce 33 00    	call   *0x33ce18(%rip)        # 82a470 <_DYNAMIC+0x4a0>
  4ed658:	f3 0f 10 5c 24 08    	movss  0x8(%rsp),%xmm3
  4ed65e:	f3 0f 10 54 24 0c    	movss  0xc(%rsp),%xmm2
  4ed664:	0f 57 c9             	xorps  %xmm1,%xmm1
  4ed667:	0f 2e c1             	ucomiss %xmm1,%xmm0
  4ed66a:	0f 28 4c 24 70       	movaps 0x70(%rsp),%xmm1
  4ed66f:	0f 85 41 01 00 00    	jne    4ed7b6 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x356>
  4ed675:	0f 8a 3b 01 00 00    	jp     4ed7b6 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x356>
  4ed67b:	f3 0f 10 44 24 14    	movss  0x14(%rsp),%xmm0
  4ed681:	0f 14 c8             	unpcklps %xmm0,%xmm1
  4ed684:	0f 5a c1             	cvtps2pd %xmm1,%xmm0
  4ed687:	0f 5a 4c 24 18       	cvtps2pd 0x18(%rsp),%xmm1
  4ed68c:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
  4ed691:	0f 29 4c 24 40       	movaps %xmm1,0x40(%rsp)
  4ed696:	0f 5a 44 24 20       	cvtps2pd 0x20(%rsp),%xmm0
  4ed69b:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
  4ed6a0:	c6 44 24 60 00       	movb   $0x0,0x60(%rsp)
  4ed6a5:	41 0f 10 06          	movups (%r14),%xmm0
  4ed6a9:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
  4ed6b0:	00 
  4ed6b1:	4c 89 e7             	mov    %r12,%rdi
  4ed6b4:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
  4ed6bb:	00 
  4ed6bc:	0f 28 c3             	movaps %xmm3,%xmm0
  4ed6bf:	0f 28 ca             	movaps %xmm2,%xmm1
  4ed6c2:	ff 15 b0 cd 33 00    	call   *0x33cdb0(%rip)        # 82a478 <_DYNAMIC+0x4a8>
  4ed6c8:	84 c0                	test   %al,%al
  4ed6ca:	0f 84 0d 01 00 00    	je     4ed7dd <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x37d>
  4ed6d0:	48 83 bb e8 07 00 00 	cmpq   $0x0,0x7e8(%rbx)
  4ed6d7:	00 
  4ed6d8:	f3 0f 10 4c 24 0c    	movss  0xc(%rsp),%xmm1
  4ed6de:	f3 0f 10 44 24 08    	movss  0x8(%rsp),%xmm0
  4ed6e4:	0f 84 18 01 00 00    	je     4ed802 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x3a2>
  4ed6ea:	41 8b 46 48          	mov    0x48(%r14),%eax
  4ed6ee:	21 e8                	and    %ebp,%eax
  4ed6f0:	3d ff ff 01 00       	cmp    $0x1ffff,%eax
  4ed6f5:	0f 84 07 01 00 00    	je     4ed802 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x3a2>
  4ed6fb:	4c 89 ef             	mov    %r13,%rdi
  4ed6fe:	eb 11                	jmp    4ed711 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x2b1>
  4ed700:	41 8b 46 48          	mov    0x48(%r14),%eax
  4ed704:	21 e8                	and    %ebp,%eax
  4ed706:	3d ff ff 01 00       	cmp    $0x1ffff,%eax
  4ed70b:	0f 84 f1 00 00 00    	je     4ed802 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x3a2>
  4ed711:	89 c0                	mov    %eax,%eax
  4ed713:	48 8b b3 18 07 00 00 	mov    0x718(%rbx),%rsi
  4ed71a:	48 39 c6             	cmp    %rax,%rsi
  4ed71d:	0f 86 96 01 00 00    	jbe    4ed8b9 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x459>
  4ed723:	48 8b 8b 10 07 00 00 	mov    0x710(%rbx),%rcx
  4ed72a:	48 8d 04 80          	lea    (%rax,%rax,4),%rax
  4ed72e:	48 c1 e0 04          	shl    $0x4,%rax
  4ed732:	4c 8d 34 01          	lea    (%rcx,%rax,1),%r14
  4ed736:	0f b6 44 01 4d       	movzbl 0x4d(%rcx,%rax,1),%eax
  4ed73b:	83 f8 07             	cmp    $0x7,%eax
  4ed73e:	77 c0                	ja     4ed700 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x2a0>
  4ed740:	b9 b0 00 00 00       	mov    $0xb0,%ecx
  4ed745:	0f a3 c1             	bt     %eax,%ecx
  4ed748:	73 b6                	jae    4ed700 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x2a0>
  4ed74a:	f3 41 0f 10 5e 30    	movss  0x30(%r14),%xmm3
  4ed750:	0f 2e db             	ucomiss %xmm3,%xmm3
  4ed753:	0f 8a 4c fe ff ff    	jp     4ed5a5 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x145>
  4ed759:	f3 41 0f 10 56 34    	movss  0x34(%r14),%xmm2
  4ed75f:	0f 14 da             	unpcklps %xmm2,%xmm3
  4ed762:	0f 5a d3             	cvtps2pd %xmm3,%xmm2
  4ed765:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
  4ed76a:	41 0f 5a 56 38       	cvtps2pd 0x38(%r14),%xmm2
  4ed76f:	0f 29 54 24 40       	movaps %xmm2,0x40(%rsp)
  4ed774:	41 0f 5a 56 40       	cvtps2pd 0x40(%r14),%xmm2
  4ed779:	0f 29 54 24 50       	movaps %xmm2,0x50(%rsp)
  4ed77e:	c6 44 24 60 00       	movb   $0x0,0x60(%rsp)
  4ed783:	41 0f 10 16          	movups (%r14),%xmm2
  4ed787:	0f 29 54 24 10       	movaps %xmm2,0x10(%rsp)
  4ed78c:	4c 89 e7             	mov    %r12,%rdi
  4ed78f:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
  4ed794:	ff 15 de cc 33 00    	call   *0x33ccde(%rip)        # 82a478 <_DYNAMIC+0x4a8>
  4ed79a:	f3 0f 10 44 24 08    	movss  0x8(%rsp),%xmm0
  4ed7a0:	f3 0f 10 4c 24 0c    	movss  0xc(%rsp),%xmm1
  4ed7a6:	4c 89 ef             	mov    %r13,%rdi
  4ed7a9:	84 c0                	test   %al,%al
  4ed7ab:	0f 85 4f ff ff ff    	jne    4ed700 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x2a0>
  4ed7b1:	e9 ef fd ff ff       	jmp    4ed5a5 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x145>
  4ed7b6:	41 0f 10 0e          	movups (%r14),%xmm1
  4ed7ba:	0f 29 4c 24 30       	movaps %xmm1,0x30(%rsp)
  4ed7bf:	4c 89 e7             	mov    %r12,%rdi
  4ed7c2:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
  4ed7c7:	0f 28 cb             	movaps %xmm3,%xmm1
  4ed7ca:	ff 15 b0 cc 33 00    	call   *0x33ccb0(%rip)        # 82a480 <_DYNAMIC+0x4b0>
  4ed7d0:	48 f7 d0             	not    %rax
  4ed7d3:	48 c1 e0 1f          	shl    $0x1f,%rax
  4ed7d7:	0f 84 f3 fe ff ff    	je     4ed6d0 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x270>
  4ed7dd:	4c 89 ef             	mov    %r13,%rdi
  4ed7e0:	f3 0f 10 4c 24 0c    	movss  0xc(%rsp),%xmm1
  4ed7e6:	f3 0f 10 44 24 08    	movss  0x8(%rsp),%xmm0
  4ed7ec:	e9 b4 fd ff ff       	jmp    4ed5a5 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x145>
  4ed7f1:	31 ed                	xor    %ebp,%ebp
  4ed7f3:	4c 89 ef             	mov    %r13,%rdi
  4ed7f6:	e9 aa 00 00 00       	jmp    4ed8a5 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x445>
  4ed7fb:	31 ed                	xor    %ebp,%ebp
  4ed7fd:	e9 a3 00 00 00       	jmp    4ed8a5 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x445>
  4ed802:	4c 8d a3 70 07 00 00 	lea    0x770(%rbx),%r12
  4ed809:	31 ed                	xor    %ebp,%ebp
  4ed80b:	eb 14                	jmp    4ed821 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x3c1>
  4ed80d:	45 8b 7e 48          	mov    0x48(%r14),%r15d
  4ed811:	41 81 e7 ff ff 01 00 	and    $0x1ffff,%r15d
  4ed818:	49 81 ff ff ff 01 00 	cmp    $0x1ffff,%r15
  4ed81f:	74 dc                	je     4ed7fd <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x39d>
  4ed821:	48 8b b3 18 07 00 00 	mov    0x718(%rbx),%rsi
  4ed828:	49 39 f7             	cmp    %rsi,%r15
  4ed82b:	0f 83 a8 00 00 00    	jae    4ed8d9 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x479>
  4ed831:	48 8b 83 10 07 00 00 	mov    0x710(%rbx),%rax
  4ed838:	4b 8d 0c bf          	lea    (%r15,%r15,4),%rcx
  4ed83c:	48 c1 e1 04          	shl    $0x4,%rcx
  4ed840:	4c 8d 34 08          	lea    (%rax,%rcx,1),%r14
  4ed844:	4c 8d 3c 08          	lea    (%rax,%rcx,1),%r15
  4ed848:	49 83 c7 20          	add    $0x20,%r15
  4ed84c:	4c 89 e7             	mov    %r12,%rdi
  4ed84f:	4c 89 fe             	mov    %r15,%rsi
  4ed852:	e8 99 9c 00 00       	call   4f74f0 <<alloc::collections::btree::map::BTreeMap<usize, gpui::list::ListId>>::get::<usize>>
  4ed857:	48 85 c0             	test   %rax,%rax
  4ed85a:	4c 89 ef             	mov    %r13,%rdi
  4ed85d:	74 ae                	je     4ed80d <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x3ad>
  4ed85f:	48 8b 00             	mov    (%rax),%rax
  4ed862:	48 8b b3 88 02 00 00 	mov    0x288(%rbx),%rsi
  4ed869:	48 39 f0             	cmp    %rsi,%rax
  4ed86c:	73 7b                	jae    4ed8e9 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x489>
  4ed86e:	48 8b 8b 80 02 00 00 	mov    0x280(%rbx),%rcx
  4ed875:	48 8d 04 80          	lea    (%rax,%rax,4),%rax
  4ed879:	48 83 7c c1 08 00    	cmpq   $0x0,0x8(%rcx,%rax,8)
  4ed87f:	75 07                	jne    4ed888 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x428>
  4ed881:	41 80 7e 4d 02       	cmpb   $0x2,0x4d(%r14)
  4ed886:	75 85                	jne    4ed80d <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x3ad>
  4ed888:	49 8b 37             	mov    (%r15),%rsi
  4ed88b:	48 81 c3 58 07 00 00 	add    $0x758,%rbx
  4ed892:	48 89 df             	mov    %rbx,%rdi
  4ed895:	ff 15 ed cb 33 00    	call   *0x33cbed(%rip)        # 82a488 <_DYNAMIC+0x4b8>
  4ed89b:	4c 89 ef             	mov    %r13,%rdi
  4ed89e:	48 89 c5             	mov    %rax,%rbp
  4ed8a1:	eb 02                	jmp    4ed8a5 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x445>
  4ed8a3:	31 ed                	xor    %ebp,%ebp
  4ed8a5:	48 89 6f 08          	mov    %rbp,0x8(%rdi)
  4ed8a9:	48 89 57 10          	mov    %rdx,0x10(%rdi)
  4ed8ad:	48 c7 c0 fe ff ff ff 	mov    $0xfffffffffffffffe,%rax
  4ed8b4:	e9 ce fc ff ff       	jmp    4ed587 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x127>
  4ed8b9:	48 8d 15 50 5d 31 00 	lea    0x315d50(%rip),%rdx        # 803610 <__frame_dummy_init_array_entry+0x570>
  4ed8c0:	48 89 c7             	mov    %rax,%rdi
  4ed8c3:	ff 15 8f cb 33 00    	call   *0x33cb8f(%rip)        # 82a458 <_DYNAMIC+0x488>
  4ed8c9:	48 8d 15 f0 60 31 00 	lea    0x3160f0(%rip),%rdx        # 8039c0 <__frame_dummy_init_array_entry+0x920>
  4ed8d0:	4c 89 ff             	mov    %r15,%rdi
  4ed8d3:	ff 15 7f cb 33 00    	call   *0x33cb7f(%rip)        # 82a458 <_DYNAMIC+0x488>
  4ed8d9:	48 8d 15 f8 60 31 00 	lea    0x3160f8(%rip),%rdx        # 8039d8 <__frame_dummy_init_array_entry+0x938>
  4ed8e0:	4c 89 ff             	mov    %r15,%rdi
  4ed8e3:	ff 15 6f cb 33 00    	call   *0x33cb6f(%rip)        # 82a458 <_DYNAMIC+0x488>
  4ed8e9:	48 8d 15 00 61 31 00 	lea    0x316100(%rip),%rdx        # 8039f0 <__frame_dummy_init_array_entry+0x950>
  4ed8f0:	48 89 c7             	mov    %rax,%rdi
  4ed8f3:	ff 15 5f cb 33 00    	call   *0x33cb5f(%rip)        # 82a458 <_DYNAMIC+0x488>
