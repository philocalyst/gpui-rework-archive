
/tmp/gpui-core-controls-artifacts/hit_cost-parent-ce9b21c14b0bbc766c9d988abfe6d9d8a7be85715d27c9a90c3c5d1183790180:     file format elf64-x86-64


Disassembly of section .text:

00000000004e8bb0 <<gpui::runtime::Win<hit_cost::Page>>::hit_target>:
  4e8bb0:	55                   	push   %rbp
  4e8bb1:	41 57                	push   %r15
  4e8bb3:	41 56                	push   %r14
  4e8bb5:	41 55                	push   %r13
  4e8bb7:	41 54                	push   %r12
  4e8bb9:	53                   	push   %rbx
  4e8bba:	48 81 ec 98 00 00 00 	sub    $0x98,%rsp
  4e8bc1:	48 89 f8             	mov    %rdi,%rax
  4e8bc4:	48 8b 1e             	mov    (%rsi),%rbx
  4e8bc7:	48 85 db             	test   %rbx,%rbx
  4e8bca:	0f 84 05 01 00 00    	je     4e8cd5 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x125>
  4e8bd0:	b9 0e 00 00 00       	mov    $0xe,%ecx
  4e8bd5:	80 bb 1e 09 00 00 00 	cmpb   $0x0,0x91e(%rbx)
  4e8bdc:	0f 85 f8 00 00 00    	jne    4e8cda <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x12a>
  4e8be2:	b9 12 00 00 00       	mov    $0x12,%ecx
  4e8be7:	80 bb 1a 09 00 00 01 	cmpb   $0x1,0x91a(%rbx)
  4e8bee:	0f 85 e6 00 00 00    	jne    4e8cda <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x12a>
  4e8bf4:	80 bb 1b 09 00 00 00 	cmpb   $0x0,0x91b(%rbx)
  4e8bfb:	0f 85 d9 00 00 00    	jne    4e8cda <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x12a>
  4e8c01:	80 bb 1c 09 00 00 01 	cmpb   $0x1,0x91c(%rbx)
  4e8c08:	0f 85 cc 00 00 00    	jne    4e8cda <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x12a>
  4e8c0e:	48 83 bb 20 07 00 00 	cmpq   $0xffffffffffffffff,0x720(%rbx)
  4e8c15:	ff 
  4e8c16:	0f 85 be 00 00 00    	jne    4e8cda <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x12a>
  4e8c1c:	48 8b 93 20 08 00 00 	mov    0x820(%rbx),%rdx
  4e8c23:	48 3b 93 28 08 00 00 	cmp    0x828(%rbx),%rdx
  4e8c2a:	0f 85 aa 00 00 00    	jne    4e8cda <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x12a>
  4e8c30:	48 8b 93 30 08 00 00 	mov    0x830(%rbx),%rdx
  4e8c37:	48 39 93 38 08 00 00 	cmp    %rdx,0x838(%rbx)
  4e8c3e:	0f 85 96 00 00 00    	jne    4e8cda <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x12a>
  4e8c44:	f3 0f 10 93 10 09 00 	movss  0x910(%rbx),%xmm2
  4e8c4b:	00 
  4e8c4c:	0f 2e 93 14 09 00 00 	ucomiss 0x914(%rbx),%xmm2
  4e8c53:	0f 85 81 00 00 00    	jne    4e8cda <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x12a>
  4e8c59:	7a 7f                	jp     4e8cda <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x12a>
  4e8c5b:	49 89 c5             	mov    %rax,%r13
  4e8c5e:	48 89 d0             	mov    %rdx,%rax
  4e8c61:	48 c1 e8 20          	shr    $0x20,%rax
  4e8c65:	89 d1                	mov    %edx,%ecx
  4e8c67:	f3 48 0f 2a d9       	cvtsi2ss %rcx,%xmm3
  4e8c6c:	89 c0                	mov    %eax,%eax
  4e8c6e:	0f 57 d2             	xorps  %xmm2,%xmm2
  4e8c71:	f3 48 0f 2a d0       	cvtsi2ss %rax,%xmm2
  4e8c76:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
  4e8c7d:	00 00 
  4e8c7f:	f3 0f 11 5c 24 38    	movss  %xmm3,0x38(%rsp)
  4e8c85:	f3 0f 11 54 24 3c    	movss  %xmm2,0x3c(%rsp)
  4e8c8b:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
  4e8c90:	f3 0f 11 04 24       	movss  %xmm0,(%rsp)
  4e8c95:	f3 0f 11 4c 24 04    	movss  %xmm1,0x4(%rsp)
  4e8c9b:	ff 15 57 17 34 00    	call   *0x341757(%rip)        # 82a3f8 <_DYNAMIC+0x348>
  4e8ca1:	84 c0                	test   %al,%al
  4e8ca3:	0f 84 79 02 00 00    	je     4e8f22 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x372>
  4e8ca9:	48 8b 8b 18 07 00 00 	mov    0x718(%rbx),%rcx
  4e8cb0:	48 85 c9             	test   %rcx,%rcx
  4e8cb3:	4c 89 e8             	mov    %r13,%rax
  4e8cb6:	0f 84 15 03 00 00    	je     4e8fd1 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x421>
  4e8cbc:	48 8b 93 10 07 00 00 	mov    0x710(%rbx),%rdx
  4e8cc3:	4c 8d 34 89          	lea    (%rcx,%rcx,4),%r14
  4e8cc7:	49 c1 e6 04          	shl    $0x4,%r14
  4e8ccb:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
  4e8cd0:	49 01 d6             	add    %rdx,%r14
  4e8cd3:	eb 25                	jmp    4e8cfa <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x14a>
  4e8cd5:	b9 0d 00 00 00       	mov    $0xd,%ecx
  4e8cda:	48 89 08             	mov    %rcx,(%rax)
  4e8cdd:	48 81 c4 98 00 00 00 	add    $0x98,%rsp
  4e8ce4:	5b                   	pop    %rbx
  4e8ce5:	41 5c                	pop    %r12
  4e8ce7:	41 5d                	pop    %r13
  4e8ce9:	41 5e                	pop    %r14
  4e8ceb:	41 5f                	pop    %r15
  4e8ced:	5d                   	pop    %rbp
  4e8cee:	c3                   	ret
  4e8cef:	4c 39 74 24 08       	cmp    %r14,0x8(%rsp)
  4e8cf4:	0f 84 d3 02 00 00    	je     4e8fcd <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x41d>
  4e8cfa:	41 80 7e fe 00       	cmpb   $0x0,-0x2(%r14)
  4e8cff:	4d 8d 76 b0          	lea    -0x50(%r14),%r14
  4e8d03:	74 ea                	je     4e8cef <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x13f>
  4e8d05:	4c 89 f5             	mov    %r14,%rbp
  4e8d08:	48 2b 6c 24 08       	sub    0x8(%rsp),%rbp
  4e8d0d:	49 89 ec             	mov    %rbp,%r12
  4e8d10:	49 c1 ec 04          	shr    $0x4,%r12
  4e8d14:	48 b8 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rax
  4e8d1b:	cc cc cc 
  4e8d1e:	4c 0f af e0          	imul   %rax,%r12
  4e8d22:	48 8b b3 18 07 00 00 	mov    0x718(%rbx),%rsi
  4e8d29:	49 39 f4             	cmp    %rsi,%r12
  4e8d2c:	0f 83 d2 02 00 00    	jae    4e9004 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x454>
  4e8d32:	4c 8b bb 10 07 00 00 	mov    0x710(%rbx),%r15
  4e8d39:	41 0f 10 44 2f 10    	movups 0x10(%r15,%rbp,1),%xmm0
  4e8d3f:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
  4e8d44:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
  4e8d49:	f3 0f 10 04 24       	movss  (%rsp),%xmm0
  4e8d4e:	f3 0f 10 4c 24 04    	movss  0x4(%rsp),%xmm1
  4e8d54:	ff 15 9e 16 34 00    	call   *0x34169e(%rip)        # 82a3f8 <_DYNAMIC+0x348>
  4e8d5a:	84 c0                	test   %al,%al
  4e8d5c:	4c 89 e8             	mov    %r13,%rax
  4e8d5f:	74 8e                	je     4e8cef <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x13f>
  4e8d61:	49 01 ef             	add    %rbp,%r15
  4e8d64:	f3 41 0f 10 4f 30    	movss  0x30(%r15),%xmm1
  4e8d6a:	0f 2e c9             	ucomiss %xmm1,%xmm1
  4e8d6d:	7a 80                	jp     4e8cef <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x13f>
  4e8d6f:	41 8b 47 44          	mov    0x44(%r15),%eax
  4e8d73:	48 8d 4c 24 14       	lea    0x14(%rsp),%rcx
  4e8d78:	89 41 10             	mov    %eax,0x10(%rcx)
  4e8d7b:	41 0f 10 47 34       	movups 0x34(%r15),%xmm0
  4e8d80:	0f 11 01             	movups %xmm0,(%rcx)
  4e8d83:	f3 0f 11 4c 24 10    	movss  %xmm1,0x10(%rsp)
  4e8d89:	48 8b 83 d0 07 00 00 	mov    0x7d0(%rbx),%rax
  4e8d90:	48 85 c0             	test   %rax,%rax
  4e8d93:	74 32                	je     4e8dc7 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x217>
  4e8d95:	48 8b b8 f0 00 00 00 	mov    0xf0(%rax),%rdi
  4e8d9c:	48 85 ff             	test   %rdi,%rdi
  4e8d9f:	74 26                	je     4e8dc7 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x217>
  4e8da1:	49 8b 77 20          	mov    0x20(%r15),%rsi
  4e8da5:	0f 29 4c 24 70       	movaps %xmm1,0x70(%rsp)
  4e8daa:	ff 15 50 16 34 00    	call   *0x341650(%rip)        # 82a400 <_DYNAMIC+0x350>
  4e8db0:	0f 57 c9             	xorps  %xmm1,%xmm1
  4e8db3:	0f 2e c1             	ucomiss %xmm1,%xmm0
  4e8db6:	0f 28 4c 24 70       	movaps 0x70(%rsp),%xmm1
  4e8dbb:	0f 85 28 01 00 00    	jne    4e8ee9 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x339>
  4e8dc1:	0f 8a 22 01 00 00    	jp     4e8ee9 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x339>
  4e8dc7:	f3 0f 10 44 24 14    	movss  0x14(%rsp),%xmm0
  4e8dcd:	0f 14 c8             	unpcklps %xmm0,%xmm1
  4e8dd0:	0f 5a c1             	cvtps2pd %xmm1,%xmm0
  4e8dd3:	0f 5a 4c 24 18       	cvtps2pd 0x18(%rsp),%xmm1
  4e8dd8:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
  4e8ddd:	0f 29 4c 24 40       	movaps %xmm1,0x40(%rsp)
  4e8de2:	0f 5a 44 24 20       	cvtps2pd 0x20(%rsp),%xmm0
  4e8de7:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
  4e8dec:	c6 44 24 60 00       	movb   $0x0,0x60(%rsp)
  4e8df1:	41 0f 10 07          	movups (%r15),%xmm0
  4e8df5:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
  4e8dfc:	00 
  4e8dfd:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
  4e8e02:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
  4e8e09:	00 
  4e8e0a:	f3 0f 10 04 24       	movss  (%rsp),%xmm0
  4e8e0f:	f3 0f 10 4c 24 04    	movss  0x4(%rsp),%xmm1
  4e8e15:	ff 15 ed 15 34 00    	call   *0x3415ed(%rip)        # 82a408 <_DYNAMIC+0x358>
  4e8e1b:	84 c0                	test   %al,%al
  4e8e1d:	4c 89 e8             	mov    %r13,%rax
  4e8e20:	0f 84 c9 fe ff ff    	je     4e8cef <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x13f>
  4e8e26:	48 83 bb e8 07 00 00 	cmpq   $0x0,0x7e8(%rbx)
  4e8e2d:	00 
  4e8e2e:	0f 84 f8 00 00 00    	je     4e8f2c <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x37c>
  4e8e34:	41 8b 4f 48          	mov    0x48(%r15),%ecx
  4e8e38:	83 f9 ff             	cmp    $0xffffffff,%ecx
  4e8e3b:	0f 84 eb 00 00 00    	je     4e8f2c <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x37c>
  4e8e41:	89 cf                	mov    %ecx,%edi
  4e8e43:	48 8b b3 18 07 00 00 	mov    0x718(%rbx),%rsi
  4e8e4a:	48 39 fe             	cmp    %rdi,%rsi
  4e8e4d:	0f 86 94 01 00 00    	jbe    4e8fe7 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x437>
  4e8e53:	48 8b 8b 10 07 00 00 	mov    0x710(%rbx),%rcx
  4e8e5a:	48 8d 14 bf          	lea    (%rdi,%rdi,4),%rdx
  4e8e5e:	48 c1 e2 04          	shl    $0x4,%rdx
  4e8e62:	4c 8d 3c 11          	lea    (%rcx,%rdx,1),%r15
  4e8e66:	0f b6 4c 11 4d       	movzbl 0x4d(%rcx,%rdx,1),%ecx
  4e8e6b:	83 f9 07             	cmp    $0x7,%ecx
  4e8e6e:	77 c4                	ja     4e8e34 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x284>
  4e8e70:	ba b0 00 00 00       	mov    $0xb0,%edx
  4e8e75:	0f a3 ca             	bt     %ecx,%edx
  4e8e78:	73 ba                	jae    4e8e34 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x284>
  4e8e7a:	f3 41 0f 10 47 30    	movss  0x30(%r15),%xmm0
  4e8e80:	0f 2e c0             	ucomiss %xmm0,%xmm0
  4e8e83:	0f 8a 66 fe ff ff    	jp     4e8cef <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x13f>
  4e8e89:	f3 41 0f 10 4f 34    	movss  0x34(%r15),%xmm1
  4e8e8f:	0f 14 c1             	unpcklps %xmm1,%xmm0
  4e8e92:	0f 5a c0             	cvtps2pd %xmm0,%xmm0
  4e8e95:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
  4e8e9a:	41 0f 5a 47 38       	cvtps2pd 0x38(%r15),%xmm0
  4e8e9f:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
  4e8ea4:	41 0f 5a 47 40       	cvtps2pd 0x40(%r15),%xmm0
  4e8ea9:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
  4e8eae:	c6 44 24 60 00       	movb   $0x0,0x60(%rsp)
  4e8eb3:	41 0f 10 07          	movups (%r15),%xmm0
  4e8eb7:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
  4e8ebc:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
  4e8ec1:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
  4e8ec6:	f3 0f 10 04 24       	movss  (%rsp),%xmm0
  4e8ecb:	f3 0f 10 4c 24 04    	movss  0x4(%rsp),%xmm1
  4e8ed1:	ff 15 31 15 34 00    	call   *0x341531(%rip)        # 82a408 <_DYNAMIC+0x358>
  4e8ed7:	89 c1                	mov    %eax,%ecx
  4e8ed9:	4c 89 e8             	mov    %r13,%rax
  4e8edc:	84 c9                	test   %cl,%cl
  4e8ede:	0f 85 50 ff ff ff    	jne    4e8e34 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x284>
  4e8ee4:	e9 06 fe ff ff       	jmp    4e8cef <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x13f>
  4e8ee9:	41 0f 10 0f          	movups (%r15),%xmm1
  4e8eed:	0f 29 4c 24 30       	movaps %xmm1,0x30(%rsp)
  4e8ef2:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
  4e8ef7:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
  4e8efc:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
  4e8f01:	f3 0f 10 54 24 04    	movss  0x4(%rsp),%xmm2
  4e8f07:	ff 15 03 15 34 00    	call   *0x341503(%rip)        # 82a410 <_DYNAMIC+0x360>
  4e8f0d:	48 f7 d0             	not    %rax
  4e8f10:	48 c1 e0 1f          	shl    $0x1f,%rax
  4e8f14:	4c 89 e8             	mov    %r13,%rax
  4e8f17:	0f 85 d2 fd ff ff    	jne    4e8cef <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x13f>
  4e8f1d:	e9 04 ff ff ff       	jmp    4e8e26 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x276>
  4e8f22:	31 c9                	xor    %ecx,%ecx
  4e8f24:	4c 89 e8             	mov    %r13,%rax
  4e8f27:	e9 a7 00 00 00       	jmp    4e8fd3 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x423>
  4e8f2c:	4c 8d bb 70 07 00 00 	lea    0x770(%rbx),%r15
  4e8f33:	41 be ff ff ff ff    	mov    $0xffffffff,%r14d
  4e8f39:	eb 0d                	jmp    4e8f48 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x398>
  4e8f3b:	44 8b 65 48          	mov    0x48(%rbp),%r12d
  4e8f3f:	4d 39 f4             	cmp    %r14,%r12
  4e8f42:	0f 84 85 00 00 00    	je     4e8fcd <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x41d>
  4e8f48:	48 8b b3 18 07 00 00 	mov    0x718(%rbx),%rsi
  4e8f4f:	49 39 f4             	cmp    %rsi,%r12
  4e8f52:	0f 83 9c 00 00 00    	jae    4e8ff4 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x444>
  4e8f58:	48 8b 83 10 07 00 00 	mov    0x710(%rbx),%rax
  4e8f5f:	4b 8d 0c a4          	lea    (%r12,%r12,4),%rcx
  4e8f63:	48 c1 e1 04          	shl    $0x4,%rcx
  4e8f67:	48 8d 2c 08          	lea    (%rax,%rcx,1),%rbp
  4e8f6b:	4c 8d 24 08          	lea    (%rax,%rcx,1),%r12
  4e8f6f:	49 83 c4 20          	add    $0x20,%r12
  4e8f73:	4c 89 ff             	mov    %r15,%rdi
  4e8f76:	4c 89 e6             	mov    %r12,%rsi
  4e8f79:	e8 b2 e7 00 00       	call   4f7730 <<alloc::collections::btree::map::BTreeMap<usize, gpui::list::ListId>>::get::<usize>>
  4e8f7e:	48 89 c1             	mov    %rax,%rcx
  4e8f81:	48 85 c0             	test   %rax,%rax
  4e8f84:	4c 89 e8             	mov    %r13,%rax
  4e8f87:	74 b2                	je     4e8f3b <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x38b>
  4e8f89:	48 8b 39             	mov    (%rcx),%rdi
  4e8f8c:	48 8b b3 88 02 00 00 	mov    0x288(%rbx),%rsi
  4e8f93:	48 39 f7             	cmp    %rsi,%rdi
  4e8f96:	73 7c                	jae    4e9014 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x464>
  4e8f98:	48 8b 8b 80 02 00 00 	mov    0x280(%rbx),%rcx
  4e8f9f:	48 8d 14 bf          	lea    (%rdi,%rdi,4),%rdx
  4e8fa3:	48 83 7c d1 08 00    	cmpq   $0x0,0x8(%rcx,%rdx,8)
  4e8fa9:	75 06                	jne    4e8fb1 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x401>
  4e8fab:	80 7d 4d 02          	cmpb   $0x2,0x4d(%rbp)
  4e8faf:	75 8a                	jne    4e8f3b <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x38b>
  4e8fb1:	49 8b 34 24          	mov    (%r12),%rsi
  4e8fb5:	48 81 c3 58 07 00 00 	add    $0x758,%rbx
  4e8fbc:	48 89 df             	mov    %rbx,%rdi
  4e8fbf:	ff 15 53 14 34 00    	call   *0x341453(%rip)        # 82a418 <_DYNAMIC+0x368>
  4e8fc5:	48 89 c1             	mov    %rax,%rcx
  4e8fc8:	e9 57 ff ff ff       	jmp    4e8f24 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x374>
  4e8fcd:	31 c9                	xor    %ecx,%ecx
  4e8fcf:	eb 02                	jmp    4e8fd3 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x423>
  4e8fd1:	31 c9                	xor    %ecx,%ecx
  4e8fd3:	48 89 48 08          	mov    %rcx,0x8(%rax)
  4e8fd7:	48 89 50 10          	mov    %rdx,0x10(%rax)
  4e8fdb:	48 c7 c1 fe ff ff ff 	mov    $0xfffffffffffffffe,%rcx
  4e8fe2:	e9 f3 fc ff ff       	jmp    4e8cda <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x12a>
  4e8fe7:	48 8d 15 1a a7 31 00 	lea    0x31a71a(%rip),%rdx        # 803708 <__frame_dummy_init_array_entry+0x588>
  4e8fee:	ff 15 d4 13 34 00    	call   *0x3413d4(%rip)        # 82a3c8 <_DYNAMIC+0x318>
  4e8ff4:	48 8d 15 bd aa 31 00 	lea    0x31aabd(%rip),%rdx        # 803ab8 <__frame_dummy_init_array_entry+0x938>
  4e8ffb:	4c 89 e7             	mov    %r12,%rdi
  4e8ffe:	ff 15 c4 13 34 00    	call   *0x3413c4(%rip)        # 82a3c8 <_DYNAMIC+0x318>
  4e9004:	48 8d 15 e5 a6 31 00 	lea    0x31a6e5(%rip),%rdx        # 8036f0 <__frame_dummy_init_array_entry+0x570>
  4e900b:	4c 89 e7             	mov    %r12,%rdi
  4e900e:	ff 15 b4 13 34 00    	call   *0x3413b4(%rip)        # 82a3c8 <_DYNAMIC+0x318>
  4e9014:	48 8d 15 b5 aa 31 00 	lea    0x31aab5(%rip),%rdx        # 803ad0 <__frame_dummy_init_array_entry+0x950>
  4e901b:	ff 15 a7 13 34 00    	call   *0x3413a7(%rip)        # 82a3c8 <_DYNAMIC+0x318>
