
/tmp/gpui-hit-candidate-target/release/deps/hit_cost-eadb425003edae63:     file format elf64-x86-64


Disassembly of section .text:

00000000004ed490 <<gpui::runtime::Win<hit_cost::Page>>::hit_target>:
  4ed490:	55                   	push   %rbp
  4ed491:	41 57                	push   %r15
  4ed493:	41 56                	push   %r14
  4ed495:	41 55                	push   %r13
  4ed497:	41 54                	push   %r12
  4ed499:	53                   	push   %rbx
  4ed49a:	48 81 ec a8 00 00 00 	sub    $0xa8,%rsp
  4ed4a1:	48 89 f8             	mov    %rdi,%rax
  4ed4a4:	48 8b 1e             	mov    (%rsi),%rbx
  4ed4a7:	48 85 db             	test   %rbx,%rbx
  4ed4aa:	0f 84 24 01 00 00    	je     4ed5d4 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x144>
  4ed4b0:	b9 0e 00 00 00       	mov    $0xe,%ecx
  4ed4b5:	80 bb 1e 09 00 00 00 	cmpb   $0x0,0x91e(%rbx)
  4ed4bc:	0f 85 17 01 00 00    	jne    4ed5d9 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x149>
  4ed4c2:	b9 12 00 00 00       	mov    $0x12,%ecx
  4ed4c7:	80 bb 1a 09 00 00 01 	cmpb   $0x1,0x91a(%rbx)
  4ed4ce:	0f 85 05 01 00 00    	jne    4ed5d9 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x149>
  4ed4d4:	80 bb 1b 09 00 00 00 	cmpb   $0x0,0x91b(%rbx)
  4ed4db:	0f 85 f8 00 00 00    	jne    4ed5d9 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x149>
  4ed4e1:	80 bb 1c 09 00 00 01 	cmpb   $0x1,0x91c(%rbx)
  4ed4e8:	0f 85 eb 00 00 00    	jne    4ed5d9 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x149>
  4ed4ee:	48 83 bb 20 07 00 00 	cmpq   $0xffffffffffffffff,0x720(%rbx)
  4ed4f5:	ff 
  4ed4f6:	0f 85 dd 00 00 00    	jne    4ed5d9 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x149>
  4ed4fc:	48 8b 93 20 08 00 00 	mov    0x820(%rbx),%rdx
  4ed503:	48 3b 93 28 08 00 00 	cmp    0x828(%rbx),%rdx
  4ed50a:	0f 85 c9 00 00 00    	jne    4ed5d9 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x149>
  4ed510:	48 8b 93 30 08 00 00 	mov    0x830(%rbx),%rdx
  4ed517:	48 39 93 38 08 00 00 	cmp    %rdx,0x838(%rbx)
  4ed51e:	0f 85 b5 00 00 00    	jne    4ed5d9 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x149>
  4ed524:	f3 0f 10 93 10 09 00 	movss  0x910(%rbx),%xmm2
  4ed52b:	00 
  4ed52c:	0f 2e 93 14 09 00 00 	ucomiss 0x914(%rbx),%xmm2
  4ed533:	0f 85 a0 00 00 00    	jne    4ed5d9 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x149>
  4ed539:	0f 8a 9a 00 00 00    	jp     4ed5d9 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x149>
  4ed53f:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  4ed544:	48 89 d0             	mov    %rdx,%rax
  4ed547:	48 c1 e8 20          	shr    $0x20,%rax
  4ed54b:	89 d1                	mov    %edx,%ecx
  4ed54d:	f3 48 0f 2a d9       	cvtsi2ss %rcx,%xmm3
  4ed552:	89 c0                	mov    %eax,%eax
  4ed554:	0f 57 d2             	xorps  %xmm2,%xmm2
  4ed557:	f3 48 0f 2a d0       	cvtsi2ss %rax,%xmm2
  4ed55c:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
  4ed563:	00 00 
  4ed565:	f3 0f 11 5c 24 48    	movss  %xmm3,0x48(%rsp)
  4ed56b:	f3 0f 11 54 24 4c    	movss  %xmm2,0x4c(%rsp)
  4ed571:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
  4ed576:	f3 0f 11 44 24 08    	movss  %xmm0,0x8(%rsp)
  4ed57c:	f3 0f 11 4c 24 0c    	movss  %xmm1,0xc(%rsp)
  4ed582:	ff 15 80 cf 33 00    	call   *0x33cf80(%rip)        # 82a508 <_DYNAMIC+0x498>
  4ed588:	84 c0                	test   %al,%al
  4ed58a:	0f 84 f2 02 00 00    	je     4ed882 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x3f2>
  4ed590:	48 8b 8b 18 07 00 00 	mov    0x718(%rbx),%rcx
  4ed597:	48 85 c9             	test   %rcx,%rcx
  4ed59a:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  4ed59f:	0f 84 a4 03 00 00    	je     4ed949 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x4b9>
  4ed5a5:	48 8b b3 10 07 00 00 	mov    0x710(%rbx),%rsi
  4ed5ac:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
  4ed5b0:	48 c1 e1 04          	shl    $0x4,%rcx
  4ed5b4:	48 01 f1             	add    %rsi,%rcx
  4ed5b7:	49 bc cd cc cc cc cc 	movabs $0xcccccccccccccccd,%r12
  4ed5be:	cc cc cc 
  4ed5c1:	f3 0f 10 4c 24 0c    	movss  0xc(%rsp),%xmm1
  4ed5c7:	f3 0f 10 44 24 08    	movss  0x8(%rsp),%xmm0
  4ed5cd:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
  4ed5d2:	eb 3c                	jmp    4ed610 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x180>
  4ed5d4:	b9 0d 00 00 00       	mov    $0xd,%ecx
  4ed5d9:	48 89 08             	mov    %rcx,(%rax)
  4ed5dc:	48 81 c4 a8 00 00 00 	add    $0xa8,%rsp
  4ed5e3:	5b                   	pop    %rbx
  4ed5e4:	41 5c                	pop    %r12
  4ed5e6:	41 5d                	pop    %r13
  4ed5e8:	41 5e                	pop    %r14
  4ed5ea:	41 5f                	pop    %r15
  4ed5ec:	5d                   	pop    %rbp
  4ed5ed:	c3                   	ret
  4ed5ee:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  4ed5f3:	f3 0f 10 4c 24 0c    	movss  0xc(%rsp),%xmm1
  4ed5f9:	f3 0f 10 44 24 08    	movss  0x8(%rsp),%xmm0
  4ed5ff:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  4ed604:	4c 89 f1             	mov    %r14,%rcx
  4ed607:	4c 39 f6             	cmp    %r14,%rsi
  4ed60a:	0f 84 35 03 00 00    	je     4ed945 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x4b5>
  4ed610:	4c 8d 71 b0          	lea    -0x50(%rcx),%r14
  4ed614:	4d 89 f5             	mov    %r14,%r13
  4ed617:	49 29 f5             	sub    %rsi,%r13
  4ed61a:	4c 89 ed             	mov    %r13,%rbp
  4ed61d:	48 c1 ed 04          	shr    $0x4,%rbp
  4ed621:	49 0f af ec          	imul   %r12,%rbp
  4ed625:	80 79 fe 00          	cmpb   $0x0,-0x2(%rcx)
  4ed629:	0f 84 ed 01 00 00    	je     4ed81c <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x38c>
  4ed62f:	48 8b b3 18 07 00 00 	mov    0x718(%rbx),%rsi
  4ed636:	48 39 f5             	cmp    %rsi,%rbp
  4ed639:	0f 83 3d 03 00 00    	jae    4ed97c <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x4ec>
  4ed63f:	4c 8b bb 10 07 00 00 	mov    0x710(%rbx),%r15
  4ed646:	43 0f 10 54 2f 10    	movups 0x10(%r15,%r13,1),%xmm2
  4ed64c:	0f 29 54 24 40       	movaps %xmm2,0x40(%rsp)
  4ed651:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
  4ed656:	ff 15 ac ce 33 00    	call   *0x33ceac(%rip)        # 82a508 <_DYNAMIC+0x498>
  4ed65c:	84 c0                	test   %al,%al
  4ed65e:	74 8e                	je     4ed5ee <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x15e>
  4ed660:	4d 01 ef             	add    %r13,%r15
  4ed663:	f3 41 0f 10 4f 30    	movss  0x30(%r15),%xmm1
  4ed669:	0f 2e c9             	ucomiss %xmm1,%xmm1
  4ed66c:	7a 80                	jp     4ed5ee <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x15e>
  4ed66e:	41 8b 47 44          	mov    0x44(%r15),%eax
  4ed672:	48 8d 4c 24 24       	lea    0x24(%rsp),%rcx
  4ed677:	89 41 10             	mov    %eax,0x10(%rcx)
  4ed67a:	41 0f 10 47 34       	movups 0x34(%r15),%xmm0
  4ed67f:	0f 11 01             	movups %xmm0,(%rcx)
  4ed682:	f3 0f 11 4c 24 20    	movss  %xmm1,0x20(%rsp)
  4ed688:	48 8b 83 d0 07 00 00 	mov    0x7d0(%rbx),%rax
  4ed68f:	48 85 c0             	test   %rax,%rax
  4ed692:	f3 0f 10 54 24 0c    	movss  0xc(%rsp),%xmm2
  4ed698:	f3 0f 10 5c 24 08    	movss  0x8(%rsp),%xmm3
  4ed69e:	74 44                	je     4ed6e4 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x254>
  4ed6a0:	48 8b b8 f0 00 00 00 	mov    0xf0(%rax),%rdi
  4ed6a7:	48 85 ff             	test   %rdi,%rdi
  4ed6aa:	74 38                	je     4ed6e4 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x254>
  4ed6ac:	49 8b 77 20          	mov    0x20(%r15),%rsi
  4ed6b0:	0f 29 8c 24 80 00 00 	movaps %xmm1,0x80(%rsp)
  4ed6b7:	00 
  4ed6b8:	ff 15 52 ce 33 00    	call   *0x33ce52(%rip)        # 82a510 <_DYNAMIC+0x4a0>
  4ed6be:	f3 0f 10 5c 24 08    	movss  0x8(%rsp),%xmm3
  4ed6c4:	f3 0f 10 54 24 0c    	movss  0xc(%rsp),%xmm2
  4ed6ca:	0f 57 c9             	xorps  %xmm1,%xmm1
  4ed6cd:	0f 2e c1             	ucomiss %xmm1,%xmm0
  4ed6d0:	0f 28 8c 24 80 00 00 	movaps 0x80(%rsp),%xmm1
  4ed6d7:	00 
  4ed6d8:	0f 85 76 01 00 00    	jne    4ed854 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x3c4>
  4ed6de:	0f 8a 70 01 00 00    	jp     4ed854 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x3c4>
  4ed6e4:	f3 0f 10 44 24 24    	movss  0x24(%rsp),%xmm0
  4ed6ea:	0f 14 c8             	unpcklps %xmm0,%xmm1
  4ed6ed:	0f 5a c1             	cvtps2pd %xmm1,%xmm0
  4ed6f0:	0f 5a 4c 24 28       	cvtps2pd 0x28(%rsp),%xmm1
  4ed6f5:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
  4ed6fa:	0f 29 4c 24 50       	movaps %xmm1,0x50(%rsp)
  4ed6ff:	0f 5a 44 24 30       	cvtps2pd 0x30(%rsp),%xmm0
  4ed704:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
  4ed709:	c6 44 24 70 00       	movb   $0x0,0x70(%rsp)
  4ed70e:	41 0f 10 07          	movups (%r15),%xmm0
  4ed712:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
  4ed719:	00 
  4ed71a:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
  4ed71f:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
  4ed726:	00 
  4ed727:	0f 28 c3             	movaps %xmm3,%xmm0
  4ed72a:	0f 28 ca             	movaps %xmm2,%xmm1
  4ed72d:	ff 15 e5 cd 33 00    	call   *0x33cde5(%rip)        # 82a518 <_DYNAMIC+0x4a8>
  4ed733:	84 c0                	test   %al,%al
  4ed735:	0f 84 b3 fe ff ff    	je     4ed5ee <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x15e>
  4ed73b:	48 83 bb e8 07 00 00 	cmpq   $0x0,0x7e8(%rbx)
  4ed742:	00 
  4ed743:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  4ed748:	f3 0f 10 4c 24 0c    	movss  0xc(%rsp),%xmm1
  4ed74e:	f3 0f 10 44 24 08    	movss  0x8(%rsp),%xmm0
  4ed754:	0f 84 34 01 00 00    	je     4ed88e <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x3fe>
  4ed75a:	41 8b 4f 48          	mov    0x48(%r15),%ecx
  4ed75e:	ba ff ff 01 00       	mov    $0x1ffff,%edx
  4ed763:	21 d1                	and    %edx,%ecx
  4ed765:	81 f9 ff ff 01 00    	cmp    $0x1ffff,%ecx
  4ed76b:	0f 84 1d 01 00 00    	je     4ed88e <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x3fe>
  4ed771:	89 cf                	mov    %ecx,%edi
  4ed773:	48 8b b3 18 07 00 00 	mov    0x718(%rbx),%rsi
  4ed77a:	48 39 fe             	cmp    %rdi,%rsi
  4ed77d:	0f 86 dc 01 00 00    	jbe    4ed95f <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x4cf>
  4ed783:	48 8b 8b 10 07 00 00 	mov    0x710(%rbx),%rcx
  4ed78a:	48 8d 14 bf          	lea    (%rdi,%rdi,4),%rdx
  4ed78e:	48 c1 e2 04          	shl    $0x4,%rdx
  4ed792:	4c 8d 3c 11          	lea    (%rcx,%rdx,1),%r15
  4ed796:	0f b6 4c 11 4d       	movzbl 0x4d(%rcx,%rdx,1),%ecx
  4ed79b:	83 f9 07             	cmp    $0x7,%ecx
  4ed79e:	77 ba                	ja     4ed75a <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x2ca>
  4ed7a0:	ba b0 00 00 00       	mov    $0xb0,%edx
  4ed7a5:	0f a3 ca             	bt     %ecx,%edx
  4ed7a8:	73 b0                	jae    4ed75a <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x2ca>
  4ed7aa:	f3 41 0f 10 5f 30    	movss  0x30(%r15),%xmm3
  4ed7b0:	0f 2e db             	ucomiss %xmm3,%xmm3
  4ed7b3:	0f 8a 46 fe ff ff    	jp     4ed5ff <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x16f>
  4ed7b9:	f3 41 0f 10 57 34    	movss  0x34(%r15),%xmm2
  4ed7bf:	0f 14 da             	unpcklps %xmm2,%xmm3
  4ed7c2:	0f 5a d3             	cvtps2pd %xmm3,%xmm2
  4ed7c5:	0f 29 54 24 40       	movaps %xmm2,0x40(%rsp)
  4ed7ca:	41 0f 5a 57 38       	cvtps2pd 0x38(%r15),%xmm2
  4ed7cf:	0f 29 54 24 50       	movaps %xmm2,0x50(%rsp)
  4ed7d4:	41 0f 5a 57 40       	cvtps2pd 0x40(%r15),%xmm2
  4ed7d9:	0f 29 54 24 60       	movaps %xmm2,0x60(%rsp)
  4ed7de:	c6 44 24 70 00       	movb   $0x0,0x70(%rsp)
  4ed7e3:	41 0f 10 17          	movups (%r15),%xmm2
  4ed7e7:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
  4ed7ec:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
  4ed7f1:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
  4ed7f6:	ff 15 1c cd 33 00    	call   *0x33cd1c(%rip)        # 82a518 <_DYNAMIC+0x4a8>
  4ed7fc:	f3 0f 10 44 24 08    	movss  0x8(%rsp),%xmm0
  4ed802:	f3 0f 10 4c 24 0c    	movss  0xc(%rsp),%xmm1
  4ed808:	89 c1                	mov    %eax,%ecx
  4ed80a:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  4ed80f:	84 c9                	test   %cl,%cl
  4ed811:	0f 85 43 ff ff ff    	jne    4ed75a <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x2ca>
  4ed817:	e9 e3 fd ff ff       	jmp    4ed5ff <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x16f>
  4ed81c:	8b 49 f8             	mov    -0x8(%rcx),%ecx
  4ed81f:	48 81 f9 ff ff 03 00 	cmp    $0x3ffff,%rcx
  4ed826:	0f 86 d8 fd ff ff    	jbe    4ed604 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x174>
  4ed82c:	c1 e9 11             	shr    $0x11,%ecx
  4ed82f:	ba 02 00 00 00       	mov    $0x2,%edx
  4ed834:	48 29 ca             	sub    %rcx,%rdx
  4ed837:	48 83 c1 fe          	add    $0xfffffffffffffffe,%rcx
  4ed83b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
  4ed83f:	48 c1 e2 04          	shl    $0x4,%rdx
  4ed843:	48 39 e9             	cmp    %rbp,%rcx
  4ed846:	4d 8d 74 16 b0       	lea    -0x50(%r14,%rdx,1),%r14
  4ed84b:	4c 0f 43 f6          	cmovae %rsi,%r14
  4ed84f:	e9 b0 fd ff ff       	jmp    4ed604 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x174>
  4ed854:	41 0f 10 0f          	movups (%r15),%xmm1
  4ed858:	0f 29 4c 24 40       	movaps %xmm1,0x40(%rsp)
  4ed85d:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
  4ed862:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
  4ed867:	0f 28 cb             	movaps %xmm3,%xmm1
  4ed86a:	ff 15 b0 cc 33 00    	call   *0x33ccb0(%rip)        # 82a520 <_DYNAMIC+0x4b0>
  4ed870:	48 f7 d0             	not    %rax
  4ed873:	48 c1 e0 1f          	shl    $0x1f,%rax
  4ed877:	0f 85 71 fd ff ff    	jne    4ed5ee <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x15e>
  4ed87d:	e9 b9 fe ff ff       	jmp    4ed73b <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x2ab>
  4ed882:	31 c9                	xor    %ecx,%ecx
  4ed884:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  4ed889:	e9 bd 00 00 00       	jmp    4ed94b <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x4bb>
  4ed88e:	4c 8d bb 70 07 00 00 	lea    0x770(%rbx),%r15
  4ed895:	eb 17                	jmp    4ed8ae <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x41e>
  4ed897:	41 8b 6e 48          	mov    0x48(%r14),%ebp
  4ed89b:	81 e5 ff ff 01 00    	and    $0x1ffff,%ebp
  4ed8a1:	48 81 fd ff ff 01 00 	cmp    $0x1ffff,%rbp
  4ed8a8:	0f 84 97 00 00 00    	je     4ed945 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x4b5>
  4ed8ae:	48 8b b3 18 07 00 00 	mov    0x718(%rbx),%rsi
  4ed8b5:	48 39 f5             	cmp    %rsi,%rbp
  4ed8b8:	0f 83 ae 00 00 00    	jae    4ed96c <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x4dc>
  4ed8be:	48 8b 83 10 07 00 00 	mov    0x710(%rbx),%rax
  4ed8c5:	48 8d 0c ad 00 00 00 	lea    0x0(,%rbp,4),%rcx
  4ed8cc:	00 
  4ed8cd:	48 01 e9             	add    %rbp,%rcx
  4ed8d0:	48 c1 e1 04          	shl    $0x4,%rcx
  4ed8d4:	4c 8d 34 08          	lea    (%rax,%rcx,1),%r14
  4ed8d8:	4c 8d 24 08          	lea    (%rax,%rcx,1),%r12
  4ed8dc:	49 83 c4 20          	add    $0x20,%r12
  4ed8e0:	4c 89 ff             	mov    %r15,%rdi
  4ed8e3:	4c 89 e6             	mov    %r12,%rsi
  4ed8e6:	e8 a5 9c 00 00       	call   4f7590 <<alloc::collections::btree::map::BTreeMap<usize, gpui::list::ListId>>::get::<usize>>
  4ed8eb:	48 89 c1             	mov    %rax,%rcx
  4ed8ee:	48 85 c0             	test   %rax,%rax
  4ed8f1:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  4ed8f6:	74 9f                	je     4ed897 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x407>
  4ed8f8:	48 8b 39             	mov    (%rcx),%rdi
  4ed8fb:	48 8b b3 88 02 00 00 	mov    0x288(%rbx),%rsi
  4ed902:	48 39 f7             	cmp    %rsi,%rdi
  4ed905:	0f 83 81 00 00 00    	jae    4ed98c <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x4fc>
  4ed90b:	48 8b 8b 80 02 00 00 	mov    0x280(%rbx),%rcx
  4ed912:	48 8d 14 bf          	lea    (%rdi,%rdi,4),%rdx
  4ed916:	48 83 7c d1 08 00    	cmpq   $0x0,0x8(%rcx,%rdx,8)
  4ed91c:	75 0b                	jne    4ed929 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x499>
  4ed91e:	41 80 7e 4d 02       	cmpb   $0x2,0x4d(%r14)
  4ed923:	0f 85 6e ff ff ff    	jne    4ed897 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x407>
  4ed929:	49 8b 34 24          	mov    (%r12),%rsi
  4ed92d:	48 81 c3 58 07 00 00 	add    $0x758,%rbx
  4ed934:	48 89 df             	mov    %rbx,%rdi
  4ed937:	ff 15 eb cb 33 00    	call   *0x33cbeb(%rip)        # 82a528 <_DYNAMIC+0x4b8>
  4ed93d:	48 89 c1             	mov    %rax,%rcx
  4ed940:	e9 3f ff ff ff       	jmp    4ed884 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x3f4>
  4ed945:	31 c9                	xor    %ecx,%ecx
  4ed947:	eb 02                	jmp    4ed94b <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x4bb>
  4ed949:	31 c9                	xor    %ecx,%ecx
  4ed94b:	48 89 48 08          	mov    %rcx,0x8(%rax)
  4ed94f:	48 89 50 10          	mov    %rdx,0x10(%rax)
  4ed953:	48 c7 c1 fe ff ff ff 	mov    $0xfffffffffffffffe,%rcx
  4ed95a:	e9 7a fc ff ff       	jmp    4ed5d9 <<gpui::runtime::Win<hit_cost::Page>>::hit_target+0x149>
  4ed95f:	48 8d 15 62 5d 31 00 	lea    0x315d62(%rip),%rdx        # 8036c8 <__frame_dummy_init_array_entry+0x588>
  4ed966:	ff 15 8c cb 33 00    	call   *0x33cb8c(%rip)        # 82a4f8 <_DYNAMIC+0x488>
  4ed96c:	48 8d 15 05 61 31 00 	lea    0x316105(%rip),%rdx        # 803a78 <__frame_dummy_init_array_entry+0x938>
  4ed973:	48 89 ef             	mov    %rbp,%rdi
  4ed976:	ff 15 7c cb 33 00    	call   *0x33cb7c(%rip)        # 82a4f8 <_DYNAMIC+0x488>
  4ed97c:	48 8d 15 2d 5d 31 00 	lea    0x315d2d(%rip),%rdx        # 8036b0 <__frame_dummy_init_array_entry+0x570>
  4ed983:	48 89 ef             	mov    %rbp,%rdi
  4ed986:	ff 15 6c cb 33 00    	call   *0x33cb6c(%rip)        # 82a4f8 <_DYNAMIC+0x488>
  4ed98c:	48 8d 15 fd 60 31 00 	lea    0x3160fd(%rip),%rdx        # 803a90 <__frame_dummy_init_array_entry+0x950>
  4ed993:	ff 15 5f cb 33 00    	call   *0x33cb5f(%rip)        # 82a4f8 <_DYNAMIC+0x488>
