
/tmp/gpui-monotonic-control-bin/stream-final:     file format elf64-x86-64


Disassembly of section .text:

000000000066f5f0 <<parley::layout::run::Run<()>>::try_for_each_cluster::<gpui_canvas::Error, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#1}>>:
  66f5f0:	55                   	push   %rbp
  66f5f1:	41 57                	push   %r15
  66f5f3:	41 56                	push   %r14
  66f5f5:	41 55                	push   %r13
  66f5f7:	41 54                	push   %r12
  66f5f9:	53                   	push   %rbx
  66f5fa:	48 81 ec 68 01 00 00 	sub    $0x168,%rsp
  66f601:	48 89 cb             	mov    %rcx,%rbx
  66f604:	49 89 d6             	mov    %rdx,%r14
  66f607:	89 f2                	mov    %esi,%edx
  66f609:	48 89 fe             	mov    %rdi,%rsi
  66f60c:	4c 8d 7c 24 58       	lea    0x58(%rsp),%r15
  66f611:	4c 89 ff             	mov    %r15,%rdi
  66f614:	e8 07 11 00 00       	call   670720 <<parley::layout::run::Clusters<()>>::new>
  66f619:	f3 0f 10 03          	movss  (%rbx),%xmm0
  66f61d:	f3 0f 11 44 24 0c    	movss  %xmm0,0xc(%rsp)
  66f623:	48 8d 7c 24 24       	lea    0x24(%rsp),%rdi
  66f628:	4c 89 fe             	mov    %r15,%rsi
  66f62b:	e8 e0 13 00 00       	call   670a10 <<parley::layout::run::Clusters<()>>::advance_cursor>
  66f630:	83 7c 24 24 01       	cmpl   $0x1,0x24(%rsp)
  66f635:	0f 85 0c 01 00 00    	jne    66f747 <<parley::layout::run::Run<()>>::try_for_each_cluster::<gpui_canvas::Error, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#1}>+0x157>
  66f63b:	4c 8d a4 24 10 01 00 	lea    0x110(%rsp),%r12
  66f642:	00 
  66f643:	4c 8d 6c 24 48       	lea    0x48(%rsp),%r13
  66f648:	eb 74                	jmp    66f6be <<parley::layout::run::Run<()>>::try_for_each_cluster::<gpui_canvas::Error, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#1}>+0xce>
  66f64a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  66f650:	0f 57 c0             	xorps  %xmm0,%xmm0
  66f653:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  66f658:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  66f65d:	48 8b 54 24 68       	mov    0x68(%rsp),%rdx
  66f662:	f2 0f 10 4a 44       	movsd  0x44(%rdx),%xmm1
  66f667:	f2 0f 11 4c 24 10    	movsd  %xmm1,0x10(%rsp)
  66f66d:	f3 0f 11 44 24 18    	movss  %xmm0,0x18(%rsp)
  66f673:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
  66f677:	0f b6 89 8c 00 00 00 	movzbl 0x8c(%rcx),%ecx
  66f67e:	83 e1 01             	and    $0x1,%ecx
  66f681:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  66f686:	4c 89 e6             	mov    %r12,%rsi
  66f689:	4c 89 ea             	mov    %r13,%rdx
  66f68c:	ff 15 6e b6 11 00    	call   *0x11b66e(%rip)        # 78ad00 <_DYNAMIC+0x678>
  66f692:	f3 0f 10 4c 24 0c    	movss  0xc(%rsp),%xmm1
  66f698:	f3 0f 58 c8          	addss  %xmm0,%xmm1
  66f69c:	f3 0f 11 4c 24 0c    	movss  %xmm1,0xc(%rsp)
  66f6a2:	f3 0f 11 0b          	movss  %xmm1,(%rbx)
  66f6a6:	48 8d 7c 24 24       	lea    0x24(%rsp),%rdi
  66f6ab:	4c 89 fe             	mov    %r15,%rsi
  66f6ae:	e8 5d 13 00 00       	call   670a10 <<parley::layout::run::Clusters<()>>::advance_cursor>
  66f6b3:	80 7c 24 24 00       	cmpb   $0x0,0x24(%rsp)
  66f6b8:	0f 84 89 00 00 00    	je     66f747 <<parley::layout::run::Run<()>>::try_for_each_cluster::<gpui_canvas::Error, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#1}>+0x157>
  66f6be:	48 83 bc 24 10 01 00 	cmpq   $0x0,0x110(%rsp)
  66f6c5:	00 00 
  66f6c7:	0f 84 91 00 00 00    	je     66f75e <<parley::layout::run::Run<()>>::try_for_each_cluster::<gpui_canvas::Error, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#1}>+0x16e>
  66f6cd:	4c 89 7c 24 38       	mov    %r15,0x38(%rsp)
  66f6d2:	4c 89 64 24 40       	mov    %r12,0x40(%rsp)
  66f6d7:	48 8d 44 24 28       	lea    0x28(%rsp),%rax
  66f6dc:	0f 10 00             	movups (%rax),%xmm0
  66f6df:	41 0f 11 45 00       	movups %xmm0,0x0(%r13)
  66f6e4:	49 8b 6e 10          	mov    0x10(%r14),%rbp
  66f6e8:	49 3b 2e             	cmp    (%r14),%rbp
  66f6eb:	75 09                	jne    66f6f6 <<parley::layout::run::Run<()>>::try_for_each_cluster::<gpui_canvas::Error, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#1}>+0x106>
  66f6ed:	4c 89 f7             	mov    %r14,%rdi
  66f6f0:	ff 15 6a b4 11 00    	call   *0x11b46a(%rip)        # 78ab60 <_DYNAMIC+0x4d8>
  66f6f6:	49 8b 46 08          	mov    0x8(%r14),%rax
  66f6fa:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  66f700:	f3 0f 11 04 a8       	movss  %xmm0,(%rax,%rbp,4)
  66f705:	48 ff c5             	inc    %rbp
  66f708:	49 89 6e 10          	mov    %rbp,0x10(%r14)
  66f70c:	48 83 7c 24 70 00    	cmpq   $0x0,0x70(%rsp)
  66f712:	0f 84 38 ff ff ff    	je     66f650 <<parley::layout::run::Run<()>>::try_for_each_cluster::<gpui_canvas::Error, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#1}>+0x60>
  66f718:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  66f71d:	8b 7c 24 78          	mov    0x78(%rsp),%edi
  66f721:	48 8b b0 18 01 00 00 	mov    0x118(%rax),%rsi
  66f728:	48 39 fe             	cmp    %rdi,%rsi
  66f72b:	76 4a                	jbe    66f777 <<parley::layout::run::Run<()>>::try_for_each_cluster::<gpui_canvas::Error, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#1}>+0x187>
  66f72d:	48 8b 80 10 01 00 00 	mov    0x110(%rax),%rax
  66f734:	48 6b cf 70          	imul   $0x70,%rdi,%rcx
  66f738:	f3 0f 10 44 08 50    	movss  0x50(%rax,%rcx,1),%xmm0
  66f73e:	8b 44 08 54          	mov    0x54(%rax,%rcx,1),%eax
  66f742:	e9 11 ff ff ff       	jmp    66f658 <<parley::layout::run::Run<()>>::try_for_each_cluster::<gpui_canvas::Error, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#1}>+0x68>
  66f747:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  66f74c:	48 81 c4 68 01 00 00 	add    $0x168,%rsp
  66f753:	5b                   	pop    %rbx
  66f754:	41 5c                	pop    %r12
  66f756:	41 5d                	pop    %r13
  66f758:	41 5e                	pop    %r14
  66f75a:	41 5f                	pop    %r15
  66f75c:	5d                   	pop    %rbp
  66f75d:	c3                   	ret
  66f75e:	48 8d 3d 1b e6 be ff 	lea    -0x4119e5(%rip),%rdi        # 25dd80 <anon.f18ce338d7d9510e0caff92e3aadadaf.0.llvm.8620189955531555138>
  66f765:	48 8d 15 c4 09 11 00 	lea    0x1109c4(%rip),%rdx        # 780130 <anon.f18ce338d7d9510e0caff92e3aadadaf.2.llvm.8620189955531555138>
  66f76c:	be 63 00 00 00       	mov    $0x63,%esi
  66f771:	ff 15 f1 b3 11 00    	call   *0x11b3f1(%rip)        # 78ab68 <_DYNAMIC+0x4e0>
  66f777:	48 8d 15 ca 09 11 00 	lea    0x1109ca(%rip),%rdx        # 780148 <anon.f18ce338d7d9510e0caff92e3aadadaf.3.llvm.8620189955531555138>
  66f77e:	ff 15 64 b2 11 00    	call   *0x11b264(%rip)        # 78a9e8 <_DYNAMIC+0x360>
