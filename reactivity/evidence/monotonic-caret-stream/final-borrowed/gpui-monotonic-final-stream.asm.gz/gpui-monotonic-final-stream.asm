
/tmp/gpui-monotonic-control-bin/stream-final:     file format elf64-x86-64


Disassembly of section .text:

0000000000679aa0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>>:
  679aa0:	55                   	push   %rbp
  679aa1:	41 57                	push   %r15
  679aa3:	41 56                	push   %r14
  679aa5:	41 55                	push   %r13
  679aa7:	41 54                	push   %r12
  679aa9:	53                   	push   %rbx
  679aaa:	48 81 ec 98 03 00 00 	sub    $0x398,%rsp
  679ab1:	48 89 54 24 48       	mov    %rdx,0x48(%rsp)
  679ab6:	48 8b af 50 01 00 00 	mov    0x150(%rdi),%rbp
  679abd:	48 89 e8             	mov    %rbp,%rax
  679ac0:	48 c1 e8 20          	shr    $0x20,%rax
  679ac4:	74 0d                	je     679ad3 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x33>
  679ac6:	e8 45 22 00 00       	call   67bd10 <parley::editing::geometry::visit_indexed::<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>>
  679acb:	41 89 c5             	mov    %eax,%r13d
  679ace:	e9 63 0d 00 00       	jmp    67a836 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xd96>
  679ad3:	f3 0f 11 44 24 20    	movss  %xmm0,0x20(%rsp)
  679ad9:	48 89 74 24 40       	mov    %rsi,0x40(%rsp)
  679ade:	48 8b 5f 70          	mov    0x70(%rdi),%rbx
  679ae2:	48 89 d8             	mov    %rbx,%rax
  679ae5:	48 c1 e8 20          	shr    $0x20,%rax
  679ae9:	41 bd fe ff ff ff    	mov    $0xfffffffe,%r13d
  679aef:	0f 85 21 0d 00 00    	jne    67a816 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xd76>
  679af5:	48 8b 97 18 01 00 00 	mov    0x118(%rdi),%rdx
  679afc:	48 89 d0             	mov    %rdx,%rax
  679aff:	48 c1 e8 20          	shr    $0x20,%rax
  679b03:	0f 85 0d 0d 00 00    	jne    67a816 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xd76>
  679b09:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  679b0e:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  679b15:	00 
  679b16:	48 c7 84 24 88 00 00 	movq   $0x0,0x88(%rsp)
  679b1d:	00 00 00 00 00 
  679b22:	48 c7 84 24 90 00 00 	movq   $0x4,0x90(%rsp)
  679b29:	00 04 00 00 00 
  679b2e:	48 c7 84 24 98 00 00 	movq   $0x0,0x98(%rsp)
  679b35:	00 00 00 00 00 
  679b3a:	48 8b 87 10 01 00 00 	mov    0x110(%rdi),%rax
  679b41:	48 6b ca 70          	imul   $0x70,%rdx,%rcx
  679b45:	48 01 c1             	add    %rax,%rcx
  679b48:	48 89 8c 24 e0 00 00 	mov    %rcx,0xe0(%rsp)
  679b4f:	00 
  679b50:	48 89 94 24 68 02 00 	mov    %rdx,0x268(%rsp)
  679b57:	00 
  679b58:	48 85 d2             	test   %rdx,%rdx
  679b5b:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
  679b60:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  679b65:	0f 84 a0 04 00 00    	je     67a00b <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x56b>
  679b6b:	48 8b 8f 30 01 00 00 	mov    0x130(%rdi),%rcx
  679b72:	48 89 8c 24 80 02 00 	mov    %rcx,0x280(%rsp)
  679b79:	00 
  679b7a:	48 8b 8f 28 01 00 00 	mov    0x128(%rdi),%rcx
  679b81:	48 89 8c 24 78 02 00 	mov    %rcx,0x278(%rsp)
  679b88:	00 
  679b89:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
  679b8d:	48 89 8c 24 d8 00 00 	mov    %rcx,0xd8(%rsp)
  679b94:	00 
  679b95:	48 8b 4f 58          	mov    0x58(%rdi),%rcx
  679b99:	48 8b 97 e8 00 00 00 	mov    0xe8(%rdi),%rdx
  679ba0:	48 39 d1             	cmp    %rdx,%rcx
  679ba3:	48 89 4c 24 58       	mov    %rcx,0x58(%rsp)
  679ba8:	48 0f 42 d1          	cmovb  %rcx,%rdx
  679bac:	48 89 94 24 70 02 00 	mov    %rdx,0x270(%rsp)
  679bb3:	00 
  679bb4:	48 8b 4f 68          	mov    0x68(%rdi),%rcx
  679bb8:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
  679bbd:	48 8b 8f 80 00 00 00 	mov    0x80(%rdi),%rcx
  679bc4:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
  679bc9:	4c 8b b7 88 00 00 00 	mov    0x88(%rdi),%r14
  679bd0:	48 8b 8f 98 00 00 00 	mov    0x98(%rdi),%rcx
  679bd7:	48 89 8c 24 f0 00 00 	mov    %rcx,0xf0(%rsp)
  679bde:	00 
  679bdf:	48 8b 8f a0 00 00 00 	mov    0xa0(%rdi),%rcx
  679be6:	48 89 8c 24 e8 00 00 	mov    %rcx,0xe8(%rsp)
  679bed:	00 
  679bee:	48 c7 44 24 70 00 00 	movq   $0x0,0x70(%rsp)
  679bf5:	00 00 
  679bf7:	4c 8d ac 24 50 01 00 	lea    0x150(%rsp),%r13
  679bfe:	00 
  679bff:	4c 8d 84 24 80 00 00 	lea    0x80(%rsp),%r8
  679c06:	00 
  679c07:	4c 8d 8c 24 88 00 00 	lea    0x88(%rsp),%r9
  679c0e:	00 
  679c0f:	48 8d 0d 5a 6f 10 00 	lea    0x106f5a(%rip),%rcx        # 780b70 <anon.dc752cbb3d3389760d876509e45b0baf.29.llvm.3241084255590532952>
  679c16:	48 89 8c 24 a0 00 00 	mov    %rcx,0xa0(%rsp)
  679c1d:	00 
  679c1e:	48 c7 44 24 68 00 00 	movq   $0x0,0x68(%rsp)
  679c25:	00 00 
  679c27:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
  679c2e:	00 00 
  679c30:	49 89 c4             	mov    %rax,%r12
  679c33:	48 89 6c 24 78       	mov    %rbp,0x78(%rsp)
  679c38:	48 89 9c 24 b0 00 00 	mov    %rbx,0xb0(%rsp)
  679c3f:	00 
  679c40:	4c 89 b4 24 a8 00 00 	mov    %r14,0xa8(%rsp)
  679c47:	00 
  679c48:	eb 2e                	jmp    679c78 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1d8>
  679c4a:	48 8b 84 24 90 02 00 	mov    0x290(%rsp),%rax
  679c51:	00 
  679c52:	49 89 c4             	mov    %rax,%r12
  679c55:	48 3b 84 24 e0 00 00 	cmp    0xe0(%rsp),%rax
  679c5c:	00 
  679c5d:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  679c62:	4c 8d 84 24 80 00 00 	lea    0x80(%rsp),%r8
  679c69:	00 
  679c6a:	4c 8d 8c 24 88 00 00 	lea    0x88(%rsp),%r9
  679c71:	00 
  679c72:	0f 84 9c 03 00 00    	je     67a014 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x574>
  679c78:	49 8b 54 24 10       	mov    0x10(%r12),%rdx
  679c7d:	49 8b 4c 24 18       	mov    0x18(%r12),%rcx
  679c82:	48 89 fe             	mov    %rdi,%rsi
  679c85:	4c 89 ef             	mov    %r13,%rdi
  679c88:	e8 33 1d 00 00       	call   67b9c0 <parley::editing::geometry::source_runs::<()>>
  679c8d:	4c 8b bc 24 58 01 00 	mov    0x158(%rsp),%r15
  679c94:	00 
  679c95:	4d 85 ff             	test   %r15,%r15
  679c98:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
  679c9d:	0f 84 2a 0b 00 00    	je     67a7cd <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xd2d>
  679ca3:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
  679caa:	00 
  679cab:	49 8d 44 24 70       	lea    0x70(%r12),%rax
  679cb0:	48 89 84 24 90 02 00 	mov    %rax,0x290(%rsp)
  679cb7:	00 
  679cb8:	48 8b 84 24 60 01 00 	mov    0x160(%rsp),%rax
  679cbf:	00 
  679cc0:	4d 8d 24 c7          	lea    (%r15,%rax,8),%r12
  679cc4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  679ccb:	00 00 00 00 00 
  679cd0:	4d 39 e7             	cmp    %r12,%r15
  679cd3:	0f 84 71 ff ff ff    	je     679c4a <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1aa>
  679cd9:	41 8b 07             	mov    (%r15),%eax
  679cdc:	49 83 c7 08          	add    $0x8,%r15
  679ce0:	48 39 c8             	cmp    %rcx,%rax
  679ce3:	74 eb                	je     679cd0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x230>
  679ce5:	48 8b 8c 24 88 02 00 	mov    0x288(%rsp),%rcx
  679cec:	00 
  679ced:	48 03 41 10          	add    0x10(%rcx),%rax
  679cf1:	41 bd fe ff ff ff    	mov    $0xfffffffe,%r13d
  679cf7:	41 b6 01             	mov    $0x1,%r14b
  679cfa:	48 3b 41 18          	cmp    0x18(%rcx),%rax
  679cfe:	0f 83 e9 0a 00 00    	jae    67a7ed <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xd4d>
  679d04:	48 3b 84 24 80 02 00 	cmp    0x280(%rsp),%rax
  679d0b:	00 
  679d0c:	0f 83 db 0a 00 00    	jae    67a7ed <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xd4d>
  679d12:	48 8d 04 80          	lea    (%rax,%rax,4),%rax
  679d16:	48 8b 8c 24 78 02 00 	mov    0x278(%rsp),%rcx
  679d1d:	00 
  679d1e:	80 7c c1 21 00       	cmpb   $0x0,0x21(%rcx,%rax,8)
  679d23:	0f 85 c4 0a 00 00    	jne    67a7ed <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xd4d>
  679d29:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
  679d2d:	48 8b 48 10          	mov    0x10(%rax),%rcx
  679d31:	48 3b 8c 24 70 02 00 	cmp    0x270(%rsp),%rcx
  679d38:	00 
  679d39:	0f 83 ae 0a 00 00    	jae    67a7ed <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xd4d>
  679d3f:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
  679d44:	41 89 cd             	mov    %ecx,%r13d
  679d47:	4c 39 6c 24 58       	cmp    %r13,0x58(%rsp)
  679d4c:	0f 86 52 0e 00 00    	jbe    67aba4 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1104>
  679d52:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
  679d59:	00 
  679d5a:	4c 01 e9             	add    %r13,%rcx
  679d5d:	48 c1 e1 04          	shl    $0x4,%rcx
  679d61:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
  679d66:	48 89 94 24 f0 02 00 	mov    %rdx,0x2f0(%rsp)
  679d6d:	00 
  679d6e:	48 89 9c 24 f8 02 00 	mov    %rbx,0x2f8(%rsp)
  679d75:	00 
  679d76:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
  679d7b:	48 89 94 24 00 03 00 	mov    %rdx,0x300(%rsp)
  679d82:	00 
  679d83:	48 8b b4 24 a8 00 00 	mov    0xa8(%rsp),%rsi
  679d8a:	00 
  679d8b:	48 89 b4 24 08 03 00 	mov    %rsi,0x308(%rsp)
  679d92:	00 
  679d93:	48 8b 94 24 f0 00 00 	mov    0xf0(%rsp),%rdx
  679d9a:	00 
  679d9b:	48 89 94 24 10 03 00 	mov    %rdx,0x310(%rsp)
  679da2:	00 
  679da3:	48 8b 94 24 e8 00 00 	mov    0xe8(%rsp),%rdx
  679daa:	00 
  679dab:	48 89 94 24 18 03 00 	mov    %rdx,0x318(%rsp)
  679db2:	00 
  679db3:	48 8b 94 24 d8 00 00 	mov    0xd8(%rsp),%rdx
  679dba:	00 
  679dbb:	48 8b 4c 0a 50       	mov    0x50(%rdx,%rcx,1),%rcx
  679dc0:	48 89 8c 24 20 03 00 	mov    %rcx,0x320(%rsp)
  679dc7:	00 
  679dc8:	44 8b 68 18          	mov    0x18(%rax),%r13d
  679dcc:	44 8b 70 1c          	mov    0x1c(%rax),%r14d
  679dd0:	45 39 f5             	cmp    %r14d,%r13d
  679dd3:	75 07                	jne    679ddc <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x33c>
  679dd5:	0f 57 c0             	xorps  %xmm0,%xmm0
  679dd8:	31 db                	xor    %ebx,%ebx
  679dda:	eb 69                	jmp    679e45 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x3a5>
  679ddc:	4c 39 ee             	cmp    %r13,%rsi
  679ddf:	0f 86 92 0d 00 00    	jbe    67ab77 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x10d7>
  679de5:	49 8d 46 ff          	lea    -0x1(%r14),%rax
  679de9:	48 39 f0             	cmp    %rsi,%rax
  679dec:	0f 83 93 0d 00 00    	jae    67ab85 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x10e5>
  679df2:	4a 8d 04 6d 00 00 00 	lea    0x0(,%r13,2),%rax
  679df9:	00 
  679dfa:	4c 01 e8             	add    %r13,%rax
  679dfd:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
  679e02:	48 8d 3c c1          	lea    (%rcx,%rax,8),%rdi
  679e06:	8b 1c c1             	mov    (%rcx,%rax,8),%ebx
  679e09:	f3 0f 10 44 c1 10    	movss  0x10(%rcx,%rax,8),%xmm0
  679e0f:	f3 0f 11 84 24 b8 00 	movss  %xmm0,0xb8(%rsp)
  679e16:	00 00 
  679e18:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  679e1d:	48 8b 94 24 b0 00 00 	mov    0xb0(%rsp),%rdx
  679e24:	00 
  679e25:	ff 15 e5 0e 11 00    	call   *0x110ee5(%rip)        # 78ad10 <_DYNAMIC+0x688>
  679e2b:	89 c0                	mov    %eax,%eax
  679e2d:	0f 57 c0             	xorps  %xmm0,%xmm0
  679e30:	f3 48 0f 2a c0       	cvtsi2ss %rax,%xmm0
  679e35:	f3 0f 10 8c 24 b8 00 	movss  0xb8(%rsp),%xmm1
  679e3c:	00 00 
  679e3e:	f3 0f 5e c8          	divss  %xmm0,%xmm1
  679e42:	0f 28 c1             	movaps %xmm1,%xmm0
  679e45:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  679e4a:	48 89 84 24 50 01 00 	mov    %rax,0x150(%rsp)
  679e51:	00 
  679e52:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
  679e59:	00 
  679e5a:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
  679e61:	00 
  679e62:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  679e67:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
  679e6e:	00 
  679e6f:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
  679e76:	00 
  679e77:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
  679e7e:	00 
  679e7f:	48 8b 84 24 f0 00 00 	mov    0xf0(%rsp),%rax
  679e86:	00 
  679e87:	48 89 84 24 70 01 00 	mov    %rax,0x170(%rsp)
  679e8e:	00 
  679e8f:	48 8b 84 24 e8 00 00 	mov    0xe8(%rsp),%rax
  679e96:	00 
  679e97:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
  679e9e:	00 
  679e9f:	44 89 ac 24 80 01 00 	mov    %r13d,0x180(%rsp)
  679ea6:	00 
  679ea7:	44 89 b4 24 84 01 00 	mov    %r14d,0x184(%rsp)
  679eae:	00 
  679eaf:	89 9c 24 88 01 00 00 	mov    %ebx,0x188(%rsp)
  679eb6:	44 89 ac 24 8c 01 00 	mov    %r13d,0x18c(%rsp)
  679ebd:	00 
  679ebe:	f3 0f 11 84 24 90 01 	movss  %xmm0,0x190(%rsp)
  679ec5:	00 00 
  679ec7:	48 85 ed             	test   %rbp,%rbp
  679eca:	0f 84 a5 00 00 00    	je     679f75 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x4d5>
  679ed0:	31 ed                	xor    %ebp,%ebp
  679ed2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  679ed9:	1f 84 00 00 00 00 00 
  679ee0:	4c 8d ac 24 50 01 00 	lea    0x150(%rsp),%r13
  679ee7:	00 
  679ee8:	48 8d bc 24 18 02 00 	lea    0x218(%rsp),%rdi
  679eef:	00 
  679ef0:	4c 89 ee             	mov    %r13,%rsi
  679ef3:	ff 15 1f 0e 11 00    	call   *0x110e1f(%rip)        # 78ad18 <_DYNAMIC+0x690>
  679ef9:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
  679efe:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  679f03:	48 8d 1c 28          	lea    (%rax,%rbp,1),%rbx
  679f07:	83 bc 24 18 02 00 00 	cmpl   $0x1,0x218(%rsp)
  679f0e:	01 
  679f0f:	0f 85 ae 00 00 00    	jne    679fc3 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x523>
  679f15:	8b b4 24 1c 02 00 00 	mov    0x21c(%rsp),%esi
  679f1c:	8b 94 24 20 02 00 00 	mov    0x220(%rsp),%edx
  679f23:	48 8d bc 24 f0 02 00 	lea    0x2f0(%rsp),%rdi
  679f2a:	00 
  679f2b:	ff 15 27 0d 11 00    	call   *0x110d27(%rip)        # 78ac58 <_DYNAMIC+0x5d0>
  679f31:	41 bd fe ff ff ff    	mov    $0xfffffffe,%r13d
  679f37:	41 b6 01             	mov    $0x1,%r14b
  679f3a:	48 39 d0             	cmp    %rdx,%rax
  679f3d:	0f 87 aa 08 00 00    	ja     67a7ed <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xd4d>
  679f43:	48 3b 54 24 78       	cmp    0x78(%rsp),%rdx
  679f48:	0f 87 9f 08 00 00    	ja     67a7ed <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xd4d>
  679f4e:	48 39 d0             	cmp    %rdx,%rax
  679f51:	73 10                	jae    679f63 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x4c3>
  679f53:	48 3b 44 24 70       	cmp    0x70(%rsp),%rax
  679f58:	48 89 54 24 70       	mov    %rdx,0x70(%rsp)
  679f5d:	0f 82 19 01 00 00    	jb     67a07c <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x5dc>
  679f63:	48 c1 eb 20          	shr    $0x20,%rbx
  679f67:	0f 85 80 08 00 00    	jne    67a7ed <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xd4d>
  679f6d:	48 ff c5             	inc    %rbp
  679f70:	e9 6b ff ff ff       	jmp    679ee0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x440>
  679f75:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  679f7a:	48 8d 58 01          	lea    0x1(%rax),%rbx
  679f7e:	31 ed                	xor    %ebp,%ebp
  679f80:	4c 8d ac 24 50 01 00 	lea    0x150(%rsp),%r13
  679f87:	00 
  679f88:	4c 8d b4 24 18 02 00 	lea    0x218(%rsp),%r14
  679f8f:	00 
  679f90:	4c 89 f7             	mov    %r14,%rdi
  679f93:	4c 89 ee             	mov    %r13,%rsi
  679f96:	ff 15 7c 0d 11 00    	call   *0x110d7c(%rip)        # 78ad18 <_DYNAMIC+0x690>
  679f9c:	83 bc 24 18 02 00 00 	cmpl   $0x1,0x218(%rsp)
  679fa3:	01 
  679fa4:	75 0e                	jne    679fb4 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x514>
  679fa6:	48 39 eb             	cmp    %rbp,%rbx
  679fa9:	0f 84 8d 0a 00 00    	je     67aa3c <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xf9c>
  679faf:	48 ff cd             	dec    %rbp
  679fb2:	eb dc                	jmp    679f90 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x4f0>
  679fb4:	48 29 6c 24 08       	sub    %rbp,0x8(%rsp)
  679fb9:	48 f7 dd             	neg    %rbp
  679fbc:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
  679fc1:	eb 05                	jmp    679fc8 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x528>
  679fc3:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
  679fc8:	48 8d 04 c9          	lea    (%rcx,%rcx,8),%rax
  679fcc:	48 c1 e0 04          	shl    $0x4,%rax
  679fd0:	48 03 84 24 d8 00 00 	add    0xd8(%rsp),%rax
  679fd7:	00 
  679fd8:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
  679fdd:	48 39 cd             	cmp    %rcx,%rbp
  679fe0:	48 0f 46 e9          	cmovbe %rcx,%rbp
  679fe4:	f6 80 8c 00 00 00 01 	testb  $0x1,0x8c(%rax)
  679feb:	48 0f 45 cd          	cmovne %rbp,%rcx
  679fef:	48 89 4c 24 68       	mov    %rcx,0x68(%rsp)
  679ff4:	48 8b 6c 24 78       	mov    0x78(%rsp),%rbp
  679ff9:	48 8b 9c 24 b0 00 00 	mov    0xb0(%rsp),%rbx
  67a000:	00 
  67a001:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
  67a006:	e9 c5 fc ff ff       	jmp    679cd0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x230>
  67a00b:	48 c7 44 24 68 00 00 	movq   $0x0,0x68(%rsp)
  67a012:	00 00 
  67a014:	48 8b 5c 24 68       	mov    0x68(%rsp),%rbx
  67a019:	4c 8d 3c 9d 00 00 00 	lea    0x0(,%rbx,4),%r15
  67a020:	00 
  67a021:	48 89 d8             	mov    %rbx,%rax
  67a024:	48 c1 e8 3e          	shr    $0x3e,%rax
  67a028:	0f 95 c0             	setne  %al
  67a02b:	48 b9 fc ff ff ff ff 	movabs $0x7ffffffffffffffc,%rcx
  67a032:	ff ff 7f 
  67a035:	49 39 cf             	cmp    %rcx,%r15
  67a038:	0f 97 c1             	seta   %cl
  67a03b:	08 c1                	or     %al,%cl
  67a03d:	74 17                	je     67a056 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x5b6>
  67a03f:	45 31 e4             	xor    %r12d,%r12d
  67a042:	41 b6 01             	mov    $0x1,%r14b
  67a045:	4c 89 e7             	mov    %r12,%rdi
  67a048:	4c 89 fe             	mov    %r15,%rsi
  67a04b:	ff 15 87 09 11 00    	call   *0x110987(%rip)        # 78a9d8 <_DYNAMIC+0x350>
  67a051:	e9 67 0b 00 00       	jmp    67abbd <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x111d>
  67a056:	4d 85 ff             	test   %r15,%r15
  67a059:	74 43                	je     67a09e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x5fe>
  67a05b:	ff 15 ef 08 11 00    	call   *0x1108ef(%rip)        # 78a950 <_DYNAMIC+0x2c8>
  67a061:	41 bc 04 00 00 00    	mov    $0x4,%r12d
  67a067:	be 04 00 00 00       	mov    $0x4,%esi
  67a06c:	4c 89 ff             	mov    %r15,%rdi
  67a06f:	ff 15 43 08 11 00    	call   *0x110843(%rip)        # 78a8b8 <_DYNAMIC+0x230>
  67a075:	48 85 c0             	test   %rax,%rax
  67a078:	75 2b                	jne    67a0a5 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x605>
  67a07a:	eb c6                	jmp    67a042 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x5a2>
  67a07c:	45 31 f6             	xor    %r14d,%r14d
  67a07f:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
  67a084:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  67a089:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
  67a08e:	f3 0f 10 44 24 20    	movss  0x20(%rsp),%xmm0
  67a094:	e8 77 1c 00 00       	call   67bd10 <parley::editing::geometry::visit_indexed::<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>>
  67a099:	e9 4c 07 00 00       	jmp    67a7ea <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xd4a>
  67a09e:	b8 04 00 00 00       	mov    $0x4,%eax
  67a0a3:	31 db                	xor    %ebx,%ebx
  67a0a5:	48 89 9c 24 c0 00 00 	mov    %rbx,0xc0(%rsp)
  67a0ac:	00 
  67a0ad:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
  67a0b4:	00 
  67a0b5:	48 c7 84 24 d0 00 00 	movq   $0x0,0xd0(%rsp)
  67a0bc:	00 00 00 00 00 
  67a0c1:	f3 0f 10 44 24 20    	movss  0x20(%rsp),%xmm0
  67a0c7:	f3 0f 11 44 24 34    	movss  %xmm0,0x34(%rsp)
  67a0cd:	48 8d bc 24 00 03 00 	lea    0x300(%rsp),%rdi
  67a0d4:	00 
  67a0d5:	ba 98 00 00 00       	mov    $0x98,%edx
  67a0da:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
  67a0df:	ff 15 73 08 11 00    	call   *0x110873(%rip)        # 78a958 <memcpy@GLIBC_2.14>
  67a0e5:	48 c7 84 24 f0 02 00 	movq   $0x2,0x2f0(%rsp)
  67a0ec:	00 02 00 00 00 
  67a0f1:	48 c7 84 24 f8 00 00 	movq   $0x0,0xf8(%rsp)
  67a0f8:	00 00 00 00 00 
  67a0fd:	c7 84 24 dc 02 00 00 	movl   $0x0,0x2dc(%rsp)
  67a104:	00 00 00 00 
  67a108:	48 c7 84 24 08 01 00 	movq   $0x0,0x108(%rsp)
  67a10f:	00 00 00 00 00 
  67a114:	48 83 bc 24 68 02 00 	cmpq   $0x0,0x268(%rsp)
  67a11b:	00 00 
  67a11d:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  67a122:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  67a127:	0f 84 53 05 00 00    	je     67a680 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xbe0>
  67a12d:	31 db                	xor    %ebx,%ebx
  67a12f:	48 8d bc 24 50 01 00 	lea    0x150(%rsp),%rdi
  67a136:	00 
  67a137:	4c 8d 84 24 80 00 00 	lea    0x80(%rsp),%r8
  67a13e:	00 
  67a13f:	4c 8d 8c 24 88 00 00 	lea    0x88(%rsp),%r9
  67a146:	00 
  67a147:	48 8d 0d ea 68 10 00 	lea    0x1068ea(%rip),%rcx        # 780a38 <anon.d820930e22e03c91e626aa1842c889e0.45.llvm.13819100402519517944+0x258>
  67a14e:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
  67a153:	48 8d 0d 3e 69 10 00 	lea    0x10693e(%rip),%rcx        # 780a98 <anon.d820930e22e03c91e626aa1842c889e0.45.llvm.13819100402519517944+0x2b8>
  67a15a:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
  67a15f:	eb 35                	jmp    67a196 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x6f6>
  67a161:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  67a166:	48 3b 84 24 e0 00 00 	cmp    0xe0(%rsp),%rax
  67a16d:	00 
  67a16e:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  67a173:	48 8b 5c 24 20       	mov    0x20(%rsp),%rbx
  67a178:	48 8d bc 24 50 01 00 	lea    0x150(%rsp),%rdi
  67a17f:	00 
  67a180:	4c 8d 84 24 80 00 00 	lea    0x80(%rsp),%r8
  67a187:	00 
  67a188:	4c 8d 8c 24 88 00 00 	lea    0x88(%rsp),%r9
  67a18f:	00 
  67a190:	0f 84 ea 04 00 00    	je     67a680 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xbe0>
  67a196:	48 89 b4 24 10 01 00 	mov    %rsi,0x110(%rsp)
  67a19d:	00 
  67a19e:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
  67a1a5:	00 
  67a1a6:	89 9c 24 20 01 00 00 	mov    %ebx,0x120(%rsp)
  67a1ad:	48 8b 50 10          	mov    0x10(%rax),%rdx
  67a1b1:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  67a1b6:	48 8b 48 18          	mov    0x18(%rax),%rcx
  67a1ba:	e8 01 18 00 00       	call   67b9c0 <parley::editing::geometry::source_runs::<()>>
  67a1bf:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
  67a1c4:	4c 8b bc 24 58 01 00 	mov    0x158(%rsp),%r15
  67a1cb:	00 
  67a1cc:	4d 85 ff             	test   %r15,%r15
  67a1cf:	0f 84 13 09 00 00    	je     67aae8 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1048>
  67a1d5:	4c 8b b4 24 10 01 00 	mov    0x110(%rsp),%r14
  67a1dc:	00 
  67a1dd:	48 8b 9c 24 18 01 00 	mov    0x118(%rsp),%rbx
  67a1e4:	00 
  67a1e5:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
  67a1e9:	48 8b 73 18          	mov    0x18(%rbx),%rsi
  67a1ed:	49 8b 96 30 01 00 00 	mov    0x130(%r14),%rdx
  67a1f4:	48 39 fe             	cmp    %rdi,%rsi
  67a1f7:	0f 82 d9 08 00 00    	jb     67aad6 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1036>
  67a1fd:	48 39 d6             	cmp    %rdx,%rsi
  67a200:	0f 87 d0 08 00 00    	ja     67aad6 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1036>
  67a206:	48 8b 84 24 60 01 00 	mov    0x160(%rsp),%rax
  67a20d:	00 
  67a20e:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  67a213:	48 39 f7             	cmp    %rsi,%rdi
  67a216:	0f 85 d4 02 00 00    	jne    67a4f0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xa50>
  67a21c:	48 83 44 24 60 70    	addq   $0x70,0x60(%rsp)
  67a222:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  67a227:	ff c0                	inc    %eax
  67a229:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  67a22e:	48 c1 64 24 08 03    	shlq   $0x3,0x8(%rsp)
  67a234:	45 31 f6             	xor    %r14d,%r14d
  67a237:	eb 0b                	jmp    67a244 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x7a4>
  67a239:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  67a240:	49 83 c6 08          	add    $0x8,%r14
  67a244:	4c 39 74 24 08       	cmp    %r14,0x8(%rsp)
  67a249:	0f 84 12 ff ff ff    	je     67a161 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x6c1>
  67a24f:	43 8b 04 37          	mov    (%r15,%r14,1),%eax
  67a253:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
  67a258:	48 39 c8             	cmp    %rcx,%rax
  67a25b:	74 e3                	je     67a240 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x7a0>
  67a25d:	48 8b 94 24 18 01 00 	mov    0x118(%rsp),%rdx
  67a264:	00 
  67a265:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
  67a269:	48 01 c1             	add    %rax,%rcx
  67a26c:	48 3b 4a 18          	cmp    0x18(%rdx),%rcx
  67a270:	0f 83 af 08 00 00    	jae    67ab25 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1085>
  67a276:	48 8b ac 24 10 01 00 	mov    0x110(%rsp),%rbp
  67a27d:	00 
  67a27e:	48 3b 8d 30 01 00 00 	cmp    0x130(%rbp),%rcx
  67a285:	0f 83 9a 08 00 00    	jae    67ab25 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1085>
  67a28b:	48 8b 95 28 01 00 00 	mov    0x128(%rbp),%rdx
  67a292:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
  67a296:	48 8d 0c f2          	lea    (%rdx,%rsi,8),%rcx
  67a29a:	80 7c f2 21 01       	cmpb   $0x1,0x21(%rdx,%rsi,8)
  67a29f:	0f 84 61 08 00 00    	je     67ab06 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1066>
  67a2a5:	48 8b 59 10          	mov    0x10(%rcx),%rbx
  67a2a9:	48 8b 75 58          	mov    0x58(%rbp),%rsi
  67a2ad:	48 39 f3             	cmp    %rsi,%rbx
  67a2b0:	0f 83 6f 08 00 00    	jae    67ab25 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1085>
  67a2b6:	48 3b 9d e8 00 00 00 	cmp    0xe8(%rbp),%rbx
  67a2bd:	0f 83 62 08 00 00    	jae    67ab25 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1085>
  67a2c3:	f3 43 0f 10 44 37 04 	movss  0x4(%r15,%r14,1),%xmm0
  67a2ca:	8b 94 24 20 01 00 00 	mov    0x120(%rsp),%edx
  67a2d1:	48 8b 7d 50          	mov    0x50(%rbp),%rdi
  67a2d5:	4c 8d 04 db          	lea    (%rbx,%rbx,8),%r8
  67a2d9:	49 c1 e0 04          	shl    $0x4,%r8
  67a2dd:	4c 8d 0c 9b          	lea    (%rbx,%rbx,4),%r9
  67a2e1:	49 c1 e1 04          	shl    $0x4,%r9
  67a2e5:	4c 03 8d e0 00 00 00 	add    0xe0(%rbp),%r9
  67a2ec:	4e 8d 14 07          	lea    (%rdi,%r8,1),%r10
  67a2f0:	48 89 ac 24 98 02 00 	mov    %rbp,0x298(%rsp)
  67a2f7:	00 
  67a2f8:	4c 89 94 24 a0 02 00 	mov    %r10,0x2a0(%rsp)
  67a2ff:	00 
  67a300:	4c 89 8c 24 a8 02 00 	mov    %r9,0x2a8(%rsp)
  67a307:	00 
  67a308:	48 89 8c 24 b0 02 00 	mov    %rcx,0x2b0(%rsp)
  67a30f:	00 
  67a310:	89 94 24 b8 02 00 00 	mov    %edx,0x2b8(%rsp)
  67a317:	89 84 24 bc 02 00 00 	mov    %eax,0x2bc(%rsp)
  67a31e:	89 9c 24 c0 02 00 00 	mov    %ebx,0x2c0(%rsp)
  67a325:	f3 0f 11 44 24 54    	movss  %xmm0,0x54(%rsp)
  67a32b:	48 c7 84 24 d0 00 00 	movq   $0x0,0xd0(%rsp)
  67a332:	00 00 00 00 00 
  67a337:	42 f6 84 07 8c 00 00 	testb  $0x1,0x8c(%rdi,%r8,1)
  67a33e:	00 01 
  67a340:	74 2f                	je     67a371 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x8d1>
  67a342:	48 8d bc 24 98 02 00 	lea    0x298(%rsp),%rdi
  67a349:	00 
  67a34a:	be 01 00 00 00       	mov    $0x1,%esi
  67a34f:	48 8d 94 24 c0 00 00 	lea    0xc0(%rsp),%rdx
  67a356:	00 
  67a357:	48 8d 4c 24 54       	lea    0x54(%rsp),%rcx
  67a35c:	e8 8f 52 ff ff       	call   66f5f0 <<parley::layout::run::Run<()>>::try_for_each_cluster::<gpui_canvas::Error, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#1}>>
  67a361:	41 89 c5             	mov    %eax,%r13d
  67a364:	83 f8 ff             	cmp    $0xffffffff,%eax
  67a367:	0f 85 e3 02 00 00    	jne    67a650 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xbb0>
  67a36d:	48 8b 75 58          	mov    0x58(%rbp),%rsi
  67a371:	48 c7 84 24 f8 01 00 	movq   $0x0,0x1f8(%rsp)
  67a378:	00 00 00 00 00 
  67a37d:	c7 84 24 bc 00 00 00 	movl   $0x0,0xbc(%rsp)
  67a384:	00 00 00 00 
  67a388:	c6 44 24 07 00       	movb   $0x0,0x7(%rsp)
  67a38d:	89 df                	mov    %ebx,%edi
  67a38f:	48 39 fe             	cmp    %rdi,%rsi
  67a392:	0f 86 9d 07 00 00    	jbe    67ab35 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1095>
  67a398:	0f 10 45 68          	movups 0x68(%rbp),%xmm0
  67a39c:	0f 10 8d 80 00 00 00 	movups 0x80(%rbp),%xmm1
  67a3a3:	0f 10 95 98 00 00 00 	movups 0x98(%rbp),%xmm2
  67a3aa:	48 8b 45 50          	mov    0x50(%rbp),%rax
  67a3ae:	48 8d 0c ff          	lea    (%rdi,%rdi,8),%rcx
  67a3b2:	48 c1 e1 04          	shl    $0x4,%rcx
  67a3b6:	0f 11 84 24 18 02 00 	movups %xmm0,0x218(%rsp)
  67a3bd:	00 
  67a3be:	0f 11 8c 24 28 02 00 	movups %xmm1,0x228(%rsp)
  67a3c5:	00 
  67a3c6:	0f 11 94 24 38 02 00 	movups %xmm2,0x238(%rsp)
  67a3cd:	00 
  67a3ce:	48 8b 44 08 50       	mov    0x50(%rax,%rcx,1),%rax
  67a3d3:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
  67a3da:	00 
  67a3db:	48 c7 84 24 08 02 00 	movq   $0x0,0x208(%rsp)
  67a3e2:	00 00 00 00 00 
  67a3e7:	48 8d 84 24 18 02 00 	lea    0x218(%rsp),%rax
  67a3ee:	00 
  67a3ef:	48 89 84 24 50 01 00 	mov    %rax,0x150(%rsp)
  67a3f6:	00 
  67a3f7:	48 8d 84 24 c0 00 00 	lea    0xc0(%rsp),%rax
  67a3fe:	00 
  67a3ff:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
  67a406:	00 
  67a407:	48 8d 84 24 08 02 00 	lea    0x208(%rsp),%rax
  67a40e:	00 
  67a40f:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
  67a416:	00 
  67a417:	48 8d 44 24 54       	lea    0x54(%rsp),%rax
  67a41c:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
  67a423:	00 
  67a424:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  67a429:	48 89 84 24 70 01 00 	mov    %rax,0x170(%rsp)
  67a430:	00 
  67a431:	48 8d 44 24 07       	lea    0x7(%rsp),%rax
  67a436:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
  67a43d:	00 
  67a43e:	48 8d 84 24 f0 02 00 	lea    0x2f0(%rsp),%rax
  67a445:	00 
  67a446:	48 89 84 24 80 01 00 	mov    %rax,0x180(%rsp)
  67a44d:	00 
  67a44e:	48 8d 84 24 f8 00 00 	lea    0xf8(%rsp),%rax
  67a455:	00 
  67a456:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
  67a45d:	00 
  67a45e:	48 8d 44 24 34       	lea    0x34(%rsp),%rax
  67a463:	48 89 84 24 90 01 00 	mov    %rax,0x190(%rsp)
  67a46a:	00 
  67a46b:	48 8d 44 24 48       	lea    0x48(%rsp),%rax
  67a470:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
  67a477:	00 
  67a478:	48 8d 84 24 f8 01 00 	lea    0x1f8(%rsp),%rax
  67a47f:	00 
  67a480:	48 89 84 24 a0 01 00 	mov    %rax,0x1a0(%rsp)
  67a487:	00 
  67a488:	48 8d 84 24 10 01 00 	lea    0x110(%rsp),%rax
  67a48f:	00 
  67a490:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
  67a497:	00 
  67a498:	48 8d 84 24 bc 00 00 	lea    0xbc(%rsp),%rax
  67a49f:	00 
  67a4a0:	48 89 84 24 b0 01 00 	mov    %rax,0x1b0(%rsp)
  67a4a7:	00 
  67a4a8:	48 8d 84 24 dc 02 00 	lea    0x2dc(%rsp),%rax
  67a4af:	00 
  67a4b0:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
  67a4b7:	00 
  67a4b8:	48 8d 84 24 08 01 00 	lea    0x108(%rsp),%rax
  67a4bf:	00 
  67a4c0:	48 89 84 24 c0 01 00 	mov    %rax,0x1c0(%rsp)
  67a4c7:	00 
  67a4c8:	48 8d bc 24 98 02 00 	lea    0x298(%rsp),%rdi
  67a4cf:	00 
  67a4d0:	31 f6                	xor    %esi,%esi
  67a4d2:	48 8d 94 24 50 01 00 	lea    0x150(%rsp),%rdx
  67a4d9:	00 
  67a4da:	e8 51 49 ff ff       	call   66ee30 <<parley::layout::run::Run<()>>::try_for_each_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>>
  67a4df:	41 89 c5             	mov    %eax,%r13d
  67a4e2:	83 f8 fe             	cmp    $0xfffffffe,%eax
  67a4e5:	0f 84 55 fd ff ff    	je     67a240 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x7a0>
  67a4eb:	e9 60 01 00 00       	jmp    67a650 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xbb0>
  67a4f0:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
  67a4f7:	00 
  67a4f8:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  67a4fd:	f3 0f 10 4b 28       	movss  0x28(%rbx),%xmm1
  67a502:	8b 84 24 20 01 00 00 	mov    0x120(%rsp),%eax
  67a509:	89 44 24 78          	mov    %eax,0x78(%rsp)
  67a50d:	48 c1 e7 03          	shl    $0x3,%rdi
  67a511:	48 8d 04 bf          	lea    (%rdi,%rdi,4),%rax
  67a515:	4d 8b ae 28 01 00 00 	mov    0x128(%r14),%r13
  67a51c:	49 01 c5             	add    %rax,%r13
  67a51f:	48 c1 e6 03          	shl    $0x3,%rsi
  67a523:	48 8d 2c b6          	lea    (%rsi,%rsi,4),%rbp
  67a527:	48 29 c5             	sub    %rax,%rbp
  67a52a:	45 31 e4             	xor    %r12d,%r12d
  67a52d:	eb 1c                	jmp    67a54b <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xaab>
  67a52f:	90                   	nop
  67a530:	f3 0f 10 4c 24 28    	movss  0x28(%rsp),%xmm1
  67a536:	49 83 c5 28          	add    $0x28,%r13
  67a53a:	f3 0f 58 c8          	addss  %xmm0,%xmm1
  67a53e:	49 ff c4             	inc    %r12
  67a541:	48 83 c5 d8          	add    $0xffffffffffffffd8,%rbp
  67a545:	0f 84 d1 fc ff ff    	je     67a21c <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x77c>
  67a54b:	49 8b 7d 10          	mov    0x10(%r13),%rdi
  67a54f:	41 80 7d 21 01       	cmpb   $0x1,0x21(%r13)
  67a554:	75 2a                	jne    67a580 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xae0>
  67a556:	49 8b 76 40          	mov    0x40(%r14),%rsi
  67a55a:	48 39 f7             	cmp    %rsi,%rdi
  67a55d:	0f 83 f2 05 00 00    	jae    67ab55 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x10b5>
  67a563:	49 8b 46 38          	mov    0x38(%r14),%rax
  67a567:	48 6b cf 38          	imul   $0x38,%rdi,%rcx
  67a56b:	f3 0f 10 44 08 24    	movss  0x24(%rax,%rcx,1),%xmm0
  67a571:	eb c3                	jmp    67a536 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xa96>
  67a573:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  67a57a:	84 00 00 00 00 00 
  67a580:	49 8b 76 58          	mov    0x58(%r14),%rsi
  67a584:	48 39 f7             	cmp    %rsi,%rdi
  67a587:	0f 83 dd 05 00 00    	jae    67ab6a <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x10ca>
  67a58d:	49 8b b6 e8 00 00 00 	mov    0xe8(%r14),%rsi
  67a594:	48 39 f7             	cmp    %rsi,%rdi
  67a597:	0f 83 a1 05 00 00    	jae    67ab3e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x109e>
  67a59d:	48 8d 04 ff          	lea    (%rdi,%rdi,8),%rax
  67a5a1:	48 c1 e0 04          	shl    $0x4,%rax
  67a5a5:	49 03 46 50          	add    0x50(%r14),%rax
  67a5a9:	48 8d 0c bf          	lea    (%rdi,%rdi,4),%rcx
  67a5ad:	48 c1 e1 04          	shl    $0x4,%rcx
  67a5b1:	49 03 8e e0 00 00 00 	add    0xe0(%r14),%rcx
  67a5b8:	4c 89 b4 24 50 01 00 	mov    %r14,0x150(%rsp)
  67a5bf:	00 
  67a5c0:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
  67a5c7:	00 
  67a5c8:	48 89 8c 24 60 01 00 	mov    %rcx,0x160(%rsp)
  67a5cf:	00 
  67a5d0:	4c 89 ac 24 68 01 00 	mov    %r13,0x168(%rsp)
  67a5d7:	00 
  67a5d8:	8b 44 24 78          	mov    0x78(%rsp),%eax
  67a5dc:	89 84 24 70 01 00 00 	mov    %eax,0x170(%rsp)
  67a5e3:	44 89 a4 24 74 01 00 	mov    %r12d,0x174(%rsp)
  67a5ea:	00 
  67a5eb:	89 bc 24 78 01 00 00 	mov    %edi,0x178(%rsp)
  67a5f2:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
  67a5f9:	00 
  67a5fa:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
  67a5fe:	4c 01 e7             	add    %r12,%rdi
  67a601:	48 8b b0 30 01 00 00 	mov    0x130(%rax),%rsi
  67a608:	48 39 f7             	cmp    %rsi,%rdi
  67a60b:	0f 83 4d 05 00 00    	jae    67ab5e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x10be>
  67a611:	48 8b 80 28 01 00 00 	mov    0x128(%rax),%rax
  67a618:	48 8d 0c bf          	lea    (%rdi,%rdi,4),%rcx
  67a61c:	48 8b 7c c8 10       	mov    0x10(%rax,%rcx,8),%rdi
  67a621:	48 2b 7c 24 70       	sub    0x70(%rsp),%rdi
  67a626:	48 3b 7c 24 08       	cmp    0x8(%rsp),%rdi
  67a62b:	0f 83 16 05 00 00    	jae    67ab47 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x10a7>
  67a631:	f3 0f 11 4c 24 28    	movss  %xmm1,0x28(%rsp)
  67a637:	f3 41 0f 11 4c ff 04 	movss  %xmm1,0x4(%r15,%rdi,8)
  67a63e:	48 8d bc 24 50 01 00 	lea    0x150(%rsp),%rdi
  67a645:	00 
  67a646:	e8 b5 5a ff ff       	call   670100 <<parley::layout::run::Run<()>>::advance>
  67a64b:	e9 e0 fe ff ff       	jmp    67a530 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xa90>
  67a650:	41 89 d4             	mov    %edx,%r12d
  67a653:	48 8b b4 24 00 03 00 	mov    0x300(%rsp),%rsi
  67a65a:	00 
  67a65b:	48 85 f6             	test   %rsi,%rsi
  67a65e:	0f 84 21 04 00 00    	je     67aa85 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xfe5>
  67a664:	48 8b bc 24 08 03 00 	mov    0x308(%rsp),%rdi
  67a66b:	00 
  67a66c:	48 c1 e6 03          	shl    $0x3,%rsi
  67a670:	ba 08 00 00 00       	mov    $0x8,%edx
  67a675:	ff 15 45 02 11 00    	call   *0x110245(%rip)        # 78a8c0 <_DYNAMIC+0x238>
  67a67b:	e9 05 04 00 00       	jmp    67aa85 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xfe5>
  67a680:	48 8d 84 24 68 01 00 	lea    0x168(%rsp),%rax
  67a687:	00 
  67a688:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  67a68d:	4c 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%r14
  67a694:	00 
  67a695:	4c 8d bc 24 58 01 00 	lea    0x158(%rsp),%r15
  67a69c:	00 
  67a69d:	31 ed                	xor    %ebp,%ebp
  67a69f:	4c 8d a4 24 18 02 00 	lea    0x218(%rsp),%r12
  67a6a6:	00 
  67a6a7:	48 8b 1d 5a 06 11 00 	mov    0x11065a(%rip),%rbx        # 78ad08 <_DYNAMIC+0x680>
  67a6ae:	48 8b 84 24 f0 02 00 	mov    0x2f0(%rsp),%rax
  67a6b5:	00 
  67a6b6:	48 83 f8 02          	cmp    $0x2,%rax
  67a6ba:	75 1d                	jne    67a6d9 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xc39>
  67a6bc:	48 8d bc 24 00 03 00 	lea    0x300(%rsp),%rdi
  67a6c3:	00 
  67a6c4:	e8 37 d2 ff ff       	call   677900 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  67a6c9:	48 89 84 24 f0 02 00 	mov    %rax,0x2f0(%rsp)
  67a6d0:	00 
  67a6d1:	48 89 94 24 f8 02 00 	mov    %rdx,0x2f8(%rsp)
  67a6d8:	00 
  67a6d9:	48 83 f8 01          	cmp    $0x1,%rax
  67a6dd:	0f 85 6b 01 00 00    	jne    67a84e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xdae>
  67a6e3:	4c 8b ac 24 f8 02 00 	mov    0x2f8(%rsp),%r13
  67a6ea:	00 
  67a6eb:	83 bc 24 f8 00 00 00 	cmpl   $0x1,0xf8(%rsp)
  67a6f2:	01 
  67a6f3:	75 0e                	jne    67a703 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xc63>
  67a6f5:	4c 3b ac 24 00 01 00 	cmp    0x100(%rsp),%r13
  67a6fc:	00 
  67a6fd:	0f 82 6f 01 00 00    	jb     67a872 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xdd2>
  67a703:	48 c7 84 24 f0 02 00 	movq   $0x2,0x2f0(%rsp)
  67a70a:	00 02 00 00 00 
  67a70f:	48 c7 84 24 f8 00 00 	movq   $0x1,0xf8(%rsp)
  67a716:	00 01 00 00 00 
  67a71b:	4c 89 ac 24 00 01 00 	mov    %r13,0x100(%rsp)
  67a722:	00 
  67a723:	4c 89 f1             	mov    %r14,%rcx
  67a726:	4c 39 ac 24 08 01 00 	cmp    %r13,0x108(%rsp)
  67a72d:	00 
  67a72e:	74 02                	je     67a732 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xc92>
  67a730:	31 c9                	xor    %ecx,%ecx
  67a732:	80 bc 24 dc 02 00 00 	cmpb   $0x0,0x2dc(%rsp)
  67a739:	00 
  67a73a:	48 0f 44 cd          	cmove  %rbp,%rcx
  67a73e:	f3 0f 10 44 24 34    	movss  0x34(%rsp),%xmm0
  67a744:	4c 89 e7             	mov    %r12,%rdi
  67a747:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  67a74c:	4c 89 ea             	mov    %r13,%rdx
  67a74f:	45 31 c0             	xor    %r8d,%r8d
  67a752:	ff d3                	call   *%rbx
  67a754:	4c 89 ac 24 50 01 00 	mov    %r13,0x150(%rsp)
  67a75b:	00 
  67a75c:	48 8b 84 24 58 02 00 	mov    0x258(%rsp),%rax
  67a763:	00 
  67a764:	49 89 47 40          	mov    %rax,0x40(%r15)
  67a768:	0f 10 84 24 18 02 00 	movups 0x218(%rsp),%xmm0
  67a76f:	00 
  67a770:	0f 10 8c 24 28 02 00 	movups 0x228(%rsp),%xmm1
  67a777:	00 
  67a778:	0f 10 94 24 38 02 00 	movups 0x238(%rsp),%xmm2
  67a77f:	00 
  67a780:	0f 10 9c 24 48 02 00 	movups 0x248(%rsp),%xmm3
  67a787:	00 
  67a788:	41 0f 11 5f 30       	movups %xmm3,0x30(%r15)
  67a78d:	41 0f 11 57 20       	movups %xmm2,0x20(%r15)
  67a792:	41 0f 11 4f 10       	movups %xmm1,0x10(%r15)
  67a797:	41 0f 11 07          	movups %xmm0,(%r15)
  67a79b:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
  67a7a0:	4c 89 ee             	mov    %r13,%rsi
  67a7a3:	4c 89 fa             	mov    %r15,%rdx
  67a7a6:	e8 d5 27 00 00       	call   67cf80 <gpui_canvas::text::planner::append_carets::{closure#1}>
  67a7ab:	41 89 c5             	mov    %eax,%r13d
  67a7ae:	83 f8 ff             	cmp    $0xffffffff,%eax
  67a7b1:	0f 84 f7 fe ff ff    	je     67a6ae <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xc0e>
  67a7b7:	48 8b b4 24 00 03 00 	mov    0x300(%rsp),%rsi
  67a7be:	00 
  67a7bf:	48 85 f6             	test   %rsi,%rsi
  67a7c2:	0f 85 9c fe ff ff    	jne    67a664 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xbc4>
  67a7c8:	e9 b8 02 00 00       	jmp    67aa85 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xfe5>
  67a7cd:	45 31 f6             	xor    %r14d,%r14d
  67a7d0:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
  67a7d5:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  67a7da:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
  67a7df:	f3 0f 10 44 24 20    	movss  0x20(%rsp),%xmm0
  67a7e5:	e8 26 15 00 00       	call   67bd10 <parley::editing::geometry::visit_indexed::<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>>
  67a7ea:	41 89 c5             	mov    %eax,%r13d
  67a7ed:	48 8b b4 24 88 00 00 	mov    0x88(%rsp),%rsi
  67a7f4:	00 
  67a7f5:	48 85 f6             	test   %rsi,%rsi
  67a7f8:	74 17                	je     67a811 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xd71>
  67a7fa:	48 8b bc 24 90 00 00 	mov    0x90(%rsp),%rdi
  67a801:	00 
  67a802:	48 c1 e6 03          	shl    $0x3,%rsi
  67a806:	ba 04 00 00 00       	mov    $0x4,%edx
  67a80b:	ff 15 af 00 11 00    	call   *0x1100af(%rip)        # 78a8c0 <_DYNAMIC+0x238>
  67a811:	45 84 f6             	test   %r14b,%r14b
  67a814:	74 20                	je     67a836 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xd96>
  67a816:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  67a81b:	48 8b 30             	mov    (%rax),%rsi
  67a81e:	48 85 f6             	test   %rsi,%rsi
  67a821:	74 13                	je     67a836 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xd96>
  67a823:	48 8b 78 08          	mov    0x8(%rax),%rdi
  67a827:	48 c1 e6 03          	shl    $0x3,%rsi
  67a82b:	ba 08 00 00 00       	mov    $0x8,%edx
  67a830:	ff 15 8a 00 11 00    	call   *0x11008a(%rip)        # 78a8c0 <_DYNAMIC+0x238>
  67a836:	44 89 e8             	mov    %r13d,%eax
  67a839:	44 89 e2             	mov    %r12d,%edx
  67a83c:	48 81 c4 98 03 00 00 	add    $0x398,%rsp
  67a843:	5b                   	pop    %rbx
  67a844:	41 5c                	pop    %r12
  67a846:	41 5d                	pop    %r13
  67a848:	41 5e                	pop    %r14
  67a84a:	41 5f                	pop    %r15
  67a84c:	5d                   	pop    %rbp
  67a84d:	c3                   	ret
  67a84e:	48 8b b4 24 00 03 00 	mov    0x300(%rsp),%rsi
  67a855:	00 
  67a856:	41 bd ff ff ff ff    	mov    $0xffffffff,%r13d
  67a85c:	48 85 f6             	test   %rsi,%rsi
  67a85f:	0f 84 20 02 00 00    	je     67aa85 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xfe5>
  67a865:	48 8b bc 24 08 03 00 	mov    0x308(%rsp),%rdi
  67a86c:	00 
  67a86d:	e9 04 02 00 00       	jmp    67aa76 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xfd6>
  67a872:	48 8d bc 24 50 01 00 	lea    0x150(%rsp),%rdi
  67a879:	00 
  67a87a:	48 8d b4 24 f0 02 00 	lea    0x2f0(%rsp),%rsi
  67a881:	00 
  67a882:	ba a8 00 00 00       	mov    $0xa8,%edx
  67a887:	ff 15 cb 00 11 00    	call   *0x1100cb(%rip)        # 78a958 <memcpy@GLIBC_2.14>
  67a88d:	f3 0f 10 44 24 34    	movss  0x34(%rsp),%xmm0
  67a893:	f3 0f 11 44 24 08    	movss  %xmm0,0x8(%rsp)
  67a899:	4c 8b 7c 24 48       	mov    0x48(%rsp),%r15
  67a89e:	48 8d 9c 24 60 01 00 	lea    0x160(%rsp),%rbx
  67a8a5:	00 
  67a8a6:	4c 8d b4 24 b8 02 00 	lea    0x2b8(%rsp),%r14
  67a8ad:	00 
  67a8ae:	48 8d ac 24 20 02 00 	lea    0x220(%rsp),%rbp
  67a8b5:	00 
  67a8b6:	4c 8d a4 24 08 02 00 	lea    0x208(%rsp),%r12
  67a8bd:	00 
  67a8be:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
  67a8c5:	00 
  67a8c6:	4c 8b ac 24 58 01 00 	mov    0x158(%rsp),%r13
  67a8cd:	00 
  67a8ce:	48 c7 84 24 50 01 00 	movq   $0x2,0x150(%rsp)
  67a8d5:	00 02 00 00 00 
  67a8da:	48 83 f8 02          	cmp    $0x2,%rax
  67a8de:	75 0b                	jne    67a8eb <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xe4b>
  67a8e0:	48 89 df             	mov    %rbx,%rdi
  67a8e3:	e8 18 d0 ff ff       	call   677900 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  67a8e8:	49 89 d5             	mov    %rdx,%r13
  67a8eb:	48 83 f8 01          	cmp    $0x1,%rax
  67a8ef:	0f 85 66 01 00 00    	jne    67aa5b <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xfbb>
  67a8f5:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  67a8fa:	4c 89 ee             	mov    %r13,%rsi
  67a8fd:	ba 01 00 00 00       	mov    $0x1,%edx
  67a902:	e8 39 bc 00 00       	call   686540 <<parley::editing::cursor::Cursor>::from_byte_index::<()>>
  67a907:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
  67a90e:	00 
  67a90f:	80 e2 01             	and    $0x1,%dl
  67a912:	88 94 24 00 02 00 00 	mov    %dl,0x200(%rsp)
  67a919:	4c 39 e8             	cmp    %r13,%rax
  67a91c:	0f 85 bc 00 00 00    	jne    67a9de <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xf3e>
  67a922:	48 8d bc 24 98 02 00 	lea    0x298(%rsp),%rdi
  67a929:	00 
  67a92a:	48 8d b4 24 f8 01 00 	lea    0x1f8(%rsp),%rsi
  67a931:	00 
  67a932:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  67a937:	f3 0f 10 44 24 08    	movss  0x8(%rsp),%xmm0
  67a93d:	e8 be bc 00 00       	call   686600 <<parley::editing::cursor::Cursor>::geometry::<()>>
  67a942:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  67a947:	4c 89 ee             	mov    %r13,%rsi
  67a94a:	31 d2                	xor    %edx,%edx
  67a94c:	e8 ef bb 00 00       	call   686540 <<parley::editing::cursor::Cursor>::from_byte_index::<()>>
  67a951:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
  67a958:	00 
  67a959:	80 e2 01             	and    $0x1,%dl
  67a95c:	88 94 24 10 02 00 00 	mov    %dl,0x210(%rsp)
  67a963:	48 8d bc 24 10 01 00 	lea    0x110(%rsp),%rdi
  67a96a:	00 
  67a96b:	4c 89 e6             	mov    %r12,%rsi
  67a96e:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  67a973:	f3 0f 10 44 24 08    	movss  0x8(%rsp),%xmm0
  67a979:	e8 82 bc 00 00       	call   686600 <<parley::editing::cursor::Cursor>::geometry::<()>>
  67a97e:	0f 10 84 24 10 01 00 	movups 0x110(%rsp),%xmm0
  67a985:	00 
  67a986:	0f 10 8c 24 20 01 00 	movups 0x120(%rsp),%xmm1
  67a98d:	00 
  67a98e:	41 0f 11 4e 10       	movups %xmm1,0x10(%r14)
  67a993:	41 0f 11 06          	movups %xmm0,(%r14)
  67a997:	0f 10 84 24 98 02 00 	movups 0x298(%rsp),%xmm0
  67a99e:	00 
  67a99f:	0f 10 8c 24 a8 02 00 	movups 0x2a8(%rsp),%xmm1
  67a9a6:	00 
  67a9a7:	0f 10 94 24 b8 02 00 	movups 0x2b8(%rsp),%xmm2
  67a9ae:	00 
  67a9af:	0f 10 9c 24 c8 02 00 	movups 0x2c8(%rsp),%xmm3
  67a9b6:	00 
  67a9b7:	0f 29 84 24 10 01 00 	movaps %xmm0,0x110(%rsp)
  67a9be:	00 
  67a9bf:	0f 29 8c 24 20 01 00 	movaps %xmm1,0x120(%rsp)
  67a9c6:	00 
  67a9c7:	0f 29 94 24 30 01 00 	movaps %xmm2,0x130(%rsp)
  67a9ce:	00 
  67a9cf:	0f 29 9c 24 40 01 00 	movaps %xmm3,0x140(%rsp)
  67a9d6:	00 
  67a9d7:	b8 01 00 00 00       	mov    $0x1,%eax
  67a9dc:	eb 02                	jmp    67a9e0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xf40>
  67a9de:	31 c0                	xor    %eax,%eax
  67a9e0:	4c 89 ac 24 18 02 00 	mov    %r13,0x218(%rsp)
  67a9e7:	00 
  67a9e8:	48 89 84 24 20 02 00 	mov    %rax,0x220(%rsp)
  67a9ef:	00 
  67a9f0:	0f 28 84 24 10 01 00 	movaps 0x110(%rsp),%xmm0
  67a9f7:	00 
  67a9f8:	0f 28 8c 24 20 01 00 	movaps 0x120(%rsp),%xmm1
  67a9ff:	00 
  67aa00:	0f 28 94 24 30 01 00 	movaps 0x130(%rsp),%xmm2
  67aa07:	00 
  67aa08:	0f 28 9c 24 40 01 00 	movaps 0x140(%rsp),%xmm3
  67aa0f:	00 
  67aa10:	0f 11 5d 38          	movups %xmm3,0x38(%rbp)
  67aa14:	0f 11 55 28          	movups %xmm2,0x28(%rbp)
  67aa18:	0f 11 4d 18          	movups %xmm1,0x18(%rbp)
  67aa1c:	0f 11 45 08          	movups %xmm0,0x8(%rbp)
  67aa20:	4c 89 ff             	mov    %r15,%rdi
  67aa23:	4c 89 ee             	mov    %r13,%rsi
  67aa26:	48 89 ea             	mov    %rbp,%rdx
  67aa29:	e8 52 25 00 00       	call   67cf80 <gpui_canvas::text::planner::append_carets::{closure#1}>
  67aa2e:	41 89 c5             	mov    %eax,%r13d
  67aa31:	83 f8 ff             	cmp    $0xffffffff,%eax
  67aa34:	0f 84 84 fe ff ff    	je     67a8be <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xe1e>
  67aa3a:	eb 25                	jmp    67aa61 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xfc1>
  67aa3c:	41 bd fe ff ff ff    	mov    $0xfffffffe,%r13d
  67aa42:	41 b6 01             	mov    $0x1,%r14b
  67aa45:	48 8b b4 24 88 00 00 	mov    0x88(%rsp),%rsi
  67aa4c:	00 
  67aa4d:	48 85 f6             	test   %rsi,%rsi
  67aa50:	0f 85 a4 fd ff ff    	jne    67a7fa <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xd5a>
  67aa56:	e9 b6 fd ff ff       	jmp    67a811 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xd71>
  67aa5b:	41 bd ff ff ff ff    	mov    $0xffffffff,%r13d
  67aa61:	48 8b b4 24 60 01 00 	mov    0x160(%rsp),%rsi
  67aa68:	00 
  67aa69:	48 85 f6             	test   %rsi,%rsi
  67aa6c:	74 17                	je     67aa85 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xfe5>
  67aa6e:	48 8b bc 24 68 01 00 	mov    0x168(%rsp),%rdi
  67aa75:	00 
  67aa76:	48 c1 e6 03          	shl    $0x3,%rsi
  67aa7a:	ba 08 00 00 00       	mov    $0x8,%edx
  67aa7f:	ff 15 3b fe 10 00    	call   *0x10fe3b(%rip)        # 78a8c0 <_DYNAMIC+0x238>
  67aa85:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
  67aa8c:	00 
  67aa8d:	48 85 f6             	test   %rsi,%rsi
  67aa90:	74 17                	je     67aaa9 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1009>
  67aa92:	48 8b bc 24 c8 00 00 	mov    0xc8(%rsp),%rdi
  67aa99:	00 
  67aa9a:	48 c1 e6 02          	shl    $0x2,%rsi
  67aa9e:	ba 04 00 00 00       	mov    $0x4,%edx
  67aaa3:	ff 15 17 fe 10 00    	call   *0x10fe17(%rip)        # 78a8c0 <_DYNAMIC+0x238>
  67aaa9:	48 8b b4 24 88 00 00 	mov    0x88(%rsp),%rsi
  67aab0:	00 
  67aab1:	48 85 f6             	test   %rsi,%rsi
  67aab4:	0f 84 7c fd ff ff    	je     67a836 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xd96>
  67aaba:	48 8b bc 24 90 00 00 	mov    0x90(%rsp),%rdi
  67aac1:	00 
  67aac2:	48 c1 e6 03          	shl    $0x3,%rsi
  67aac6:	ba 04 00 00 00       	mov    $0x4,%edx
  67aacb:	ff 15 ef fd 10 00    	call   *0x10fdef(%rip)        # 78a8c0 <_DYNAMIC+0x238>
  67aad1:	e9 60 fd ff ff       	jmp    67a836 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xd96>
  67aad6:	48 8d 0d a3 57 10 00 	lea    0x1057a3(%rip),%rcx        # 780280 <anon.f18ce338d7d9510e0caff92e3aadadaf.24.llvm.8620189955531555138>
  67aadd:	ff 15 a5 ff 10 00    	call   *0x10ffa5(%rip)        # 78aa88 <_DYNAMIC+0x400>
  67aae3:	e9 d5 00 00 00       	jmp    67abbd <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x111d>
  67aae8:	48 8d 3d 2e 37 be ff 	lea    -0x41c8d2(%rip),%rdi        # 25e21d <anon.d820930e22e03c91e626aa1842c889e0.74.llvm.13819100402519517944+0x28>
  67aaef:	48 8d 15 2a 5f 10 00 	lea    0x105f2a(%rip),%rdx        # 780a20 <anon.d820930e22e03c91e626aa1842c889e0.45.llvm.13819100402519517944+0x240>
  67aaf6:	be 21 00 00 00       	mov    $0x21,%esi
  67aafb:	ff 15 67 00 11 00    	call   *0x110067(%rip)        # 78ab68 <_DYNAMIC+0x4e0>
  67ab01:	e9 b7 00 00 00       	jmp    67abbd <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x111d>
  67ab06:	48 8b 41 10          	mov    0x10(%rcx),%rax
  67ab0a:	48 3b 45 40          	cmp    0x40(%rbp),%rax
  67ab0e:	48 8d 05 3b 5f 10 00 	lea    0x105f3b(%rip),%rax        # 780a50 <anon.d820930e22e03c91e626aa1842c889e0.45.llvm.13819100402519517944+0x270>
  67ab15:	48 8d 0d 1c 5f 10 00 	lea    0x105f1c(%rip),%rcx        # 780a38 <anon.d820930e22e03c91e626aa1842c889e0.45.llvm.13819100402519517944+0x258>
  67ab1c:	48 0f 42 c8          	cmovb  %rax,%rcx
  67ab20:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
  67ab25:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
  67ab2a:	ff 15 90 fe 10 00    	call   *0x10fe90(%rip)        # 78a9c0 <_DYNAMIC+0x338>
  67ab30:	e9 88 00 00 00       	jmp    67abbd <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x111d>
  67ab35:	48 8d 05 34 60 10 00 	lea    0x106034(%rip),%rax        # 780b70 <anon.dc752cbb3d3389760d876509e45b0baf.29.llvm.3241084255590532952>
  67ab3c:	eb 27                	jmp    67ab65 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x10c5>
  67ab3e:	48 8d 05 6b 5f 10 00 	lea    0x105f6b(%rip),%rax        # 780ab0 <anon.d820930e22e03c91e626aa1842c889e0.45.llvm.13819100402519517944+0x2d0>
  67ab45:	eb 1e                	jmp    67ab65 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x10c5>
  67ab47:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  67ab4c:	48 8d 05 2d 5f 10 00 	lea    0x105f2d(%rip),%rax        # 780a80 <anon.d820930e22e03c91e626aa1842c889e0.45.llvm.13819100402519517944+0x2a0>
  67ab53:	eb 10                	jmp    67ab65 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x10c5>
  67ab55:	48 8d 05 6c 5f 10 00 	lea    0x105f6c(%rip),%rax        # 780ac8 <anon.d820930e22e03c91e626aa1842c889e0.45.llvm.13819100402519517944+0x2e8>
  67ab5c:	eb 07                	jmp    67ab65 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x10c5>
  67ab5e:	48 8d 05 03 5f 10 00 	lea    0x105f03(%rip),%rax        # 780a68 <anon.d820930e22e03c91e626aa1842c889e0.45.llvm.13819100402519517944+0x288>
  67ab65:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  67ab6a:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
  67ab6f:	ff 15 73 fe 10 00    	call   *0x10fe73(%rip)        # 78a9e8 <_DYNAMIC+0x360>
  67ab75:	eb 46                	jmp    67abbd <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x111d>
  67ab77:	48 89 74 24 58       	mov    %rsi,0x58(%rsp)
  67ab7c:	48 8d 05 5d 5f 10 00 	lea    0x105f5d(%rip),%rax        # 780ae0 <anon.d820930e22e03c91e626aa1842c889e0.45.llvm.13819100402519517944+0x300>
  67ab83:	eb 17                	jmp    67ab9c <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x10fc>
  67ab85:	49 89 c5             	mov    %rax,%r13
  67ab88:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
  67ab8f:	00 
  67ab90:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  67ab95:	48 8d 05 5c 5f 10 00 	lea    0x105f5c(%rip),%rax        # 780af8 <anon.d820930e22e03c91e626aa1842c889e0.45.llvm.13819100402519517944+0x318>
  67ab9c:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  67aba3:	00 
  67aba4:	41 b6 01             	mov    $0x1,%r14b
  67aba7:	4c 89 ef             	mov    %r13,%rdi
  67abaa:	48 8b 74 24 58       	mov    0x58(%rsp),%rsi
  67abaf:	48 8b 94 24 a0 00 00 	mov    0xa0(%rsp),%rdx
  67abb6:	00 
  67abb7:	ff 15 2b fe 10 00    	call   *0x10fe2b(%rip)        # 78a9e8 <_DYNAMIC+0x360>
  67abbd:	0f 0b                	ud2
  67abbf:	eb 28                	jmp    67abe9 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1149>
  67abc1:	eb 1c                	jmp    67abdf <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x113f>
  67abc3:	eb 1a                	jmp    67abdf <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x113f>
  67abc5:	49 89 c7             	mov    %rax,%r15
  67abc8:	48 8b b4 24 60 01 00 	mov    0x160(%rsp),%rsi
  67abcf:	00 
  67abd0:	48 85 f6             	test   %rsi,%rsi
  67abd3:	75 31                	jne    67ac06 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1166>
  67abd5:	eb 46                	jmp    67ac1d <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x117d>
  67abd7:	eb 10                	jmp    67abe9 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1149>
  67abd9:	eb 0e                	jmp    67abe9 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1149>
  67abdb:	eb 0c                	jmp    67abe9 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1149>
  67abdd:	eb 00                	jmp    67abdf <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x113f>
  67abdf:	49 89 c7             	mov    %rax,%r15
  67abe2:	41 b6 01             	mov    $0x1,%r14b
  67abe5:	eb 67                	jmp    67ac4e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x11ae>
  67abe7:	eb 00                	jmp    67abe9 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1149>
  67abe9:	49 89 c7             	mov    %rax,%r15
  67abec:	48 8b b4 24 00 03 00 	mov    0x300(%rsp),%rsi
  67abf3:	00 
  67abf4:	48 85 f6             	test   %rsi,%rsi
  67abf7:	74 24                	je     67ac1d <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x117d>
  67abf9:	48 8d 84 24 08 03 00 	lea    0x308(%rsp),%rax
  67ac00:	00 
  67ac01:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  67ac06:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  67ac0b:	48 8b 38             	mov    (%rax),%rdi
  67ac0e:	48 c1 e6 03          	shl    $0x3,%rsi
  67ac12:	ba 08 00 00 00       	mov    $0x8,%edx
  67ac17:	ff 15 a3 fc 10 00    	call   *0x10fca3(%rip)        # 78a8c0 <_DYNAMIC+0x238>
  67ac1d:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
  67ac24:	00 
  67ac25:	48 85 f6             	test   %rsi,%rsi
  67ac28:	75 05                	jne    67ac2f <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x118f>
  67ac2a:	45 31 f6             	xor    %r14d,%r14d
  67ac2d:	eb 1f                	jmp    67ac4e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x11ae>
  67ac2f:	48 8b bc 24 c8 00 00 	mov    0xc8(%rsp),%rdi
  67ac36:	00 
  67ac37:	48 c1 e6 02          	shl    $0x2,%rsi
  67ac3b:	ba 04 00 00 00       	mov    $0x4,%edx
  67ac40:	ff 15 7a fc 10 00    	call   *0x10fc7a(%rip)        # 78a8c0 <_DYNAMIC+0x238>
  67ac46:	45 31 f6             	xor    %r14d,%r14d
  67ac49:	eb 03                	jmp    67ac4e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x11ae>
  67ac4b:	49 89 c7             	mov    %rax,%r15
  67ac4e:	48 8b b4 24 88 00 00 	mov    0x88(%rsp),%rsi
  67ac55:	00 
  67ac56:	48 85 f6             	test   %rsi,%rsi
  67ac59:	74 17                	je     67ac72 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x11d2>
  67ac5b:	48 8b bc 24 90 00 00 	mov    0x90(%rsp),%rdi
  67ac62:	00 
  67ac63:	48 c1 e6 03          	shl    $0x3,%rsi
  67ac67:	ba 04 00 00 00       	mov    $0x4,%edx
  67ac6c:	ff 15 4e fc 10 00    	call   *0x10fc4e(%rip)        # 78a8c0 <_DYNAMIC+0x238>
  67ac72:	45 84 f6             	test   %r14b,%r14b
  67ac75:	74 25                	je     67ac9c <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x11fc>
  67ac77:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  67ac7c:	48 8b 30             	mov    (%rax),%rsi
  67ac7f:	48 85 f6             	test   %rsi,%rsi
  67ac82:	74 18                	je     67ac9c <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x11fc>
  67ac84:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  67ac89:	48 8b 78 08          	mov    0x8(%rax),%rdi
  67ac8d:	48 c1 e6 03          	shl    $0x3,%rsi
  67ac91:	ba 08 00 00 00       	mov    $0x8,%edx
  67ac96:	ff 15 24 fc 10 00    	call   *0x10fc24(%rip)        # 78a8c0 <_DYNAMIC+0x238>
  67ac9c:	4c 89 ff             	mov    %r15,%rdi
  67ac9f:	e8 3c 3b 10 00       	call   77e7e0 <_Unwind_Resume@plt>
