
/tmp/gpui-monotonic-control-bin/stream-shared:     file format elf64-x86-64


Disassembly of section .text:

000000000066a9a0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>>:
  66a9a0:	55                   	push   %rbp
  66a9a1:	41 57                	push   %r15
  66a9a3:	41 56                	push   %r14
  66a9a5:	41 55                	push   %r13
  66a9a7:	41 54                	push   %r12
  66a9a9:	53                   	push   %rbx
  66a9aa:	48 81 ec 08 08 00 00 	sub    $0x808,%rsp
  66a9b1:	48 89 f5             	mov    %rsi,%rbp
  66a9b4:	49 89 fd             	mov    %rdi,%r13
  66a9b7:	48 8b 87 50 01 00 00 	mov    0x150(%rdi),%rax
  66a9be:	48 89 84 24 f0 00 00 	mov    %rax,0xf0(%rsp)
  66a9c5:	00 
  66a9c6:	48 c1 e8 20          	shr    $0x20,%rax
  66a9ca:	74 12                	je     66a9de <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x3e>
  66a9cc:	4c 89 ef             	mov    %r13,%rdi
  66a9cf:	48 89 ee             	mov    %rbp,%rsi
  66a9d2:	e8 49 24 00 00       	call   66ce20 <parley::editing::geometry::visit_indexed::<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>>
  66a9d7:	89 c3                	mov    %eax,%ebx
  66a9d9:	e9 b5 19 00 00       	jmp    66c393 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19f3>
  66a9de:	f3 0f 11 44 24 1c    	movss  %xmm0,0x1c(%rsp)
  66a9e4:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
  66a9e9:	bb fe ff ff ff       	mov    $0xfffffffe,%ebx
  66a9ee:	41 83 7d 74 00       	cmpl   $0x0,0x74(%r13)
  66a9f3:	0f 85 7e 19 00 00    	jne    66c377 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19d7>
  66a9f9:	49 8b 95 18 01 00 00 	mov    0x118(%r13),%rdx
  66aa00:	48 89 d0             	mov    %rdx,%rax
  66aa03:	48 c1 e8 20          	shr    $0x20,%rax
  66aa07:	0f 85 6a 19 00 00    	jne    66c377 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19d7>
  66aa0d:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  66aa12:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
  66aa19:	00 
  66aa1a:	48 c7 84 24 00 01 00 	movq   $0x0,0x100(%rsp)
  66aa21:	00 00 00 00 00 
  66aa26:	48 c7 84 24 08 01 00 	movq   $0x4,0x108(%rsp)
  66aa2d:	00 04 00 00 00 
  66aa32:	48 c7 84 24 10 01 00 	movq   $0x0,0x110(%rsp)
  66aa39:	00 00 00 00 00 
  66aa3e:	49 8b 8d 10 01 00 00 	mov    0x110(%r13),%rcx
  66aa45:	48 6b c2 70          	imul   $0x70,%rdx,%rax
  66aa49:	48 89 4c 24 68       	mov    %rcx,0x68(%rsp)
  66aa4e:	48 01 c8             	add    %rcx,%rax
  66aa51:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
  66aa58:	00 
  66aa59:	48 85 d2             	test   %rdx,%rdx
  66aa5c:	48 89 6c 24 20       	mov    %rbp,0x20(%rsp)
  66aa61:	4c 89 6c 24 28       	mov    %r13,0x28(%rsp)
  66aa66:	48 89 94 24 b8 00 00 	mov    %rdx,0xb8(%rsp)
  66aa6d:	00 
  66aa6e:	0f 84 7b 03 00 00    	je     66adef <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x44f>
  66aa74:	49 8b 85 30 01 00 00 	mov    0x130(%r13),%rax
  66aa7b:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
  66aa82:	00 
  66aa83:	49 8b 85 28 01 00 00 	mov    0x128(%r13),%rax
  66aa8a:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
  66aa8f:	49 8b 45 50          	mov    0x50(%r13),%rax
  66aa93:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
  66aa9a:	00 
  66aa9b:	49 8b 45 58          	mov    0x58(%r13),%rax
  66aa9f:	49 8b 8d e8 00 00 00 	mov    0xe8(%r13),%rcx
  66aaa6:	48 39 c8             	cmp    %rcx,%rax
  66aaa9:	48 0f 42 c8          	cmovb  %rax,%rcx
  66aaad:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  66aab2:	49 8b 85 e0 00 00 00 	mov    0xe0(%r13),%rax
  66aab9:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
  66aac0:	00 
  66aac1:	48 83 bc 24 f0 00 00 	cmpq   $0x0,0xf0(%rsp)
  66aac8:	00 00 
  66aaca:	48 8b 5c 24 50       	mov    0x50(%rsp),%rbx
  66aacf:	0f 84 5e 03 00 00    	je     66ae33 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x493>
  66aad5:	48 c7 44 24 48 00 00 	movq   $0x0,0x48(%rsp)
  66aadc:	00 00 
  66aade:	4c 8d bc 24 b0 03 00 	lea    0x3b0(%rsp),%r15
  66aae5:	00 
  66aae6:	4c 8d a4 24 f8 00 00 	lea    0xf8(%rsp),%r12
  66aaed:	00 
  66aaee:	4c 8d 8c 24 00 01 00 	lea    0x100(%rsp),%r9
  66aaf5:	00 
  66aaf6:	45 31 f6             	xor    %r14d,%r14d
  66aaf9:	48 c7 44 24 38 00 00 	movq   $0x0,0x38(%rsp)
  66ab00:	00 00 
  66ab02:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  66ab07:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
  66ab0e:	00 00 
  66ab10:	eb 34                	jmp    66ab46 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a6>
  66ab12:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
  66ab17:	48 89 d0             	mov    %rdx,%rax
  66ab1a:	8b 8c 24 c0 00 00 00 	mov    0xc0(%rsp),%ecx
  66ab21:	48 89 4c 24 40       	mov    %rcx,0x40(%rsp)
  66ab26:	48 3b 94 24 20 01 00 	cmp    0x120(%rsp),%rdx
  66ab2d:	00 
  66ab2e:	4c 8b 6c 24 28       	mov    0x28(%rsp),%r13
  66ab33:	4c 8b 74 24 60       	mov    0x60(%rsp),%r14
  66ab38:	4c 8d 8c 24 00 01 00 	lea    0x100(%rsp),%r9
  66ab3f:	00 
  66ab40:	0f 84 ac 02 00 00    	je     66adf2 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x452>
  66ab46:	48 8b 50 10          	mov    0x10(%rax),%rdx
  66ab4a:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  66ab51:	00 
  66ab52:	48 8b 48 18          	mov    0x18(%rax),%rcx
  66ab56:	4c 89 ff             	mov    %r15,%rdi
  66ab59:	4c 89 ee             	mov    %r13,%rsi
  66ab5c:	4d 89 e0             	mov    %r12,%r8
  66ab5f:	e8 cc 1e 00 00       	call   66ca30 <parley::editing::geometry::source_runs::<()>>
  66ab64:	4c 8b ac 24 b8 03 00 	mov    0x3b8(%rsp),%r13
  66ab6b:	00 
  66ab6c:	4d 85 ed             	test   %r13,%r13
  66ab6f:	0f 84 44 17 00 00    	je     66c2b9 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1919>
  66ab75:	4c 89 74 24 60       	mov    %r14,0x60(%rsp)
  66ab7a:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  66ab81:	00 
  66ab82:	48 83 c0 70          	add    $0x70,%rax
  66ab86:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  66ab8b:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  66ab90:	ff c0                	inc    %eax
  66ab92:	89 84 24 c0 00 00 00 	mov    %eax,0xc0(%rsp)
  66ab99:	48 8b 84 24 c0 03 00 	mov    0x3c0(%rsp),%rax
  66aba0:	00 
  66aba1:	4c 8d 34 c5 00 00 00 	lea    0x0(,%rax,8),%r14
  66aba8:	00 
  66aba9:	4d 01 ee             	add    %r13,%r14
  66abac:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
  66abb1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  66abb8:	0f 1f 84 00 00 00 00 
  66abbf:	00 
  66abc0:	4d 39 f5             	cmp    %r14,%r13
  66abc3:	0f 84 49 ff ff ff    	je     66ab12 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x172>
  66abc9:	41 8b 45 00          	mov    0x0(%r13),%eax
  66abcd:	49 83 c5 08          	add    $0x8,%r13
  66abd1:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
  66abd6:	48 39 c8             	cmp    %rcx,%rax
  66abd9:	74 e5                	je     66abc0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x220>
  66abdb:	48 8b b4 24 a0 00 00 	mov    0xa0(%rsp),%rsi
  66abe2:	00 
  66abe3:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
  66abe7:	48 01 c1             	add    %rax,%rcx
  66abea:	bb fe ff ff ff       	mov    $0xfffffffe,%ebx
  66abef:	40 b7 01             	mov    $0x1,%dil
  66abf2:	48 3b 4e 18          	cmp    0x18(%rsi),%rcx
  66abf6:	0f 83 4c 17 00 00    	jae    66c348 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19a8>
  66abfc:	48 3b 8c 24 98 00 00 	cmp    0x98(%rsp),%rcx
  66ac03:	00 
  66ac04:	0f 83 3e 17 00 00    	jae    66c348 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19a8>
  66ac0a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
  66ac0e:	80 7c ca 21 00       	cmpb   $0x0,0x21(%rdx,%rcx,8)
  66ac13:	0f 85 2f 17 00 00    	jne    66c348 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19a8>
  66ac19:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
  66ac1d:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
  66ac21:	48 3b 4c 24 10       	cmp    0x10(%rsp),%rcx
  66ac26:	0f 83 1c 17 00 00    	jae    66c348 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19a8>
  66ac2c:	4c 8d 24 c9          	lea    (%rcx,%rcx,8),%r12
  66ac30:	49 c1 e4 04          	shl    $0x4,%r12
  66ac34:	4c 03 a4 24 d0 00 00 	add    0xd0(%rsp),%r12
  66ac3b:	00 
  66ac3c:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
  66ac40:	48 c1 e6 04          	shl    $0x4,%rsi
  66ac44:	48 03 b4 24 c8 00 00 	add    0xc8(%rsp),%rsi
  66ac4b:	00 
  66ac4c:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
  66ac51:	48 89 bc 24 b0 03 00 	mov    %rdi,0x3b0(%rsp)
  66ac58:	00 
  66ac59:	4c 89 a4 24 b8 03 00 	mov    %r12,0x3b8(%rsp)
  66ac60:	00 
  66ac61:	48 89 b4 24 c0 03 00 	mov    %rsi,0x3c0(%rsp)
  66ac68:	00 
  66ac69:	48 89 94 24 c8 03 00 	mov    %rdx,0x3c8(%rsp)
  66ac70:	00 
  66ac71:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
  66ac76:	89 94 24 d0 03 00 00 	mov    %edx,0x3d0(%rsp)
  66ac7d:	89 84 24 d4 03 00 00 	mov    %eax,0x3d4(%rsp)
  66ac84:	89 8c 24 d8 03 00 00 	mov    %ecx,0x3d8(%rsp)
  66ac8b:	48 8d 9c 24 f8 06 00 	lea    0x6f8(%rsp),%rbx
  66ac92:	00 
  66ac93:	48 89 df             	mov    %rbx,%rdi
  66ac96:	4c 89 fe             	mov    %r15,%rsi
  66ac99:	31 d2                	xor    %edx,%edx
  66ac9b:	e8 a0 cd ff ff       	call   667a40 <<parley::layout::run::Clusters<()>>::new>
  66aca0:	ba 10 01 00 00       	mov    $0x110,%edx
  66aca5:	4c 89 ff             	mov    %r15,%rdi
  66aca8:	48 89 de             	mov    %rbx,%rsi
  66acab:	ff 15 67 f8 11 00    	call   *0x11f867(%rip)        # 78a518 <memcpy@GLIBC_2.14>
  66acb1:	45 31 ff             	xor    %r15d,%r15d
  66acb4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  66acbb:	00 00 00 00 00 
  66acc0:	48 8b 5c 24 50       	mov    0x50(%rsp),%rbx
  66acc5:	48 8d bc 24 80 02 00 	lea    0x280(%rsp),%rdi
  66accc:	00 
  66accd:	48 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%rsi
  66acd4:	00 
  66acd5:	e8 c6 f5 ff ff       	call   66a2a0 <<parley::layout::run::Clusters<()> as core::iter::traits::iterator::Iterator>::next>
  66acda:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  66acdf:	4a 8d 2c 38          	lea    (%rax,%r15,1),%rbp
  66ace3:	48 8b 84 24 80 02 00 	mov    0x280(%rsp),%rax
  66acea:	00 
  66aceb:	48 85 c0             	test   %rax,%rax
  66acee:	0f 84 b9 00 00 00    	je     66adad <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x40d>
  66acf4:	8b bc 24 a8 02 00 00 	mov    0x2a8(%rsp),%edi
  66acfb:	48 8b 70 58          	mov    0x58(%rax),%rsi
  66acff:	48 39 fe             	cmp    %rdi,%rsi
  66ad02:	0f 86 f7 1a 00 00    	jbe    66c7ff <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1e5f>
  66ad08:	8b b4 24 00 03 00 00 	mov    0x300(%rsp),%esi
  66ad0f:	8b 94 24 04 03 00 00 	mov    0x304(%rsp),%edx
  66ad16:	48 8b 48 50          	mov    0x50(%rax),%rcx
  66ad1a:	48 8d 3c ff          	lea    (%rdi,%rdi,8),%rdi
  66ad1e:	48 c1 e7 04          	shl    $0x4,%rdi
  66ad22:	0f 10 40 68          	movups 0x68(%rax),%xmm0
  66ad26:	0f 10 88 80 00 00 00 	movups 0x80(%rax),%xmm1
  66ad2d:	0f 10 90 98 00 00 00 	movups 0x98(%rax),%xmm2
  66ad34:	0f 11 84 24 e8 05 00 	movups %xmm0,0x5e8(%rsp)
  66ad3b:	00 
  66ad3c:	0f 11 8c 24 f8 05 00 	movups %xmm1,0x5f8(%rsp)
  66ad43:	00 
  66ad44:	0f 11 94 24 08 06 00 	movups %xmm2,0x608(%rsp)
  66ad4b:	00 
  66ad4c:	48 8b 44 39 50       	mov    0x50(%rcx,%rdi,1),%rax
  66ad51:	48 89 84 24 18 06 00 	mov    %rax,0x618(%rsp)
  66ad58:	00 
  66ad59:	48 8d bc 24 e8 05 00 	lea    0x5e8(%rsp),%rdi
  66ad60:	00 
  66ad61:	ff 15 09 fa 11 00    	call   *0x11fa09(%rip)        # 78a770 <_DYNAMIC+0x528>
  66ad67:	bb fe ff ff ff       	mov    $0xfffffffe,%ebx
  66ad6c:	40 b7 01             	mov    $0x1,%dil
  66ad6f:	48 39 d0             	cmp    %rdx,%rax
  66ad72:	0f 87 cb 15 00 00    	ja     66c343 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19a3>
  66ad78:	48 3b 94 24 f0 00 00 	cmp    0xf0(%rsp),%rdx
  66ad7f:	00 
  66ad80:	0f 87 bd 15 00 00    	ja     66c343 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19a3>
  66ad86:	48 39 d0             	cmp    %rdx,%rax
  66ad89:	73 10                	jae    66ad9b <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x3fb>
  66ad8b:	48 3b 44 24 48       	cmp    0x48(%rsp),%rax
  66ad90:	48 89 54 24 48       	mov    %rdx,0x48(%rsp)
  66ad95:	0f 82 7a 15 00 00    	jb     66c315 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1975>
  66ad9b:	48 c1 ed 20          	shr    $0x20,%rbp
  66ad9f:	0f 85 9e 15 00 00    	jne    66c343 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19a3>
  66ada5:	49 ff c7             	inc    %r15
  66ada8:	e9 13 ff ff ff       	jmp    66acc0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x320>
  66adad:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  66adb2:	49 39 c7             	cmp    %rax,%r15
  66adb5:	4c 0f 46 f8          	cmovbe %rax,%r15
  66adb9:	41 f6 84 24 8c 00 00 	testb  $0x1,0x8c(%r12)
  66adc0:	00 01 
  66adc2:	49 0f 45 c7          	cmovne %r15,%rax
  66adc6:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  66adcb:	48 89 6c 24 38       	mov    %rbp,0x38(%rsp)
  66add0:	48 8b 6c 24 20       	mov    0x20(%rsp),%rbp
  66add5:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
  66adda:	4c 8d bc 24 b0 03 00 	lea    0x3b0(%rsp),%r15
  66ade1:	00 
  66ade2:	4c 8d a4 24 f8 00 00 	lea    0xf8(%rsp),%r12
  66ade9:	00 
  66adea:	e9 d1 fd ff ff       	jmp    66abc0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x220>
  66adef:	45 31 f6             	xor    %r14d,%r14d
  66adf2:	4a 8d 1c b5 00 00 00 	lea    0x0(,%r14,4),%rbx
  66adf9:	00 
  66adfa:	4c 89 f0             	mov    %r14,%rax
  66adfd:	48 c1 e8 3e          	shr    $0x3e,%rax
  66ae01:	0f 95 c0             	setne  %al
  66ae04:	48 b9 fc ff ff ff ff 	movabs $0x7ffffffffffffffc,%rcx
  66ae0b:	ff ff 7f 
  66ae0e:	48 39 cb             	cmp    %rcx,%rbx
  66ae11:	0f 97 c1             	seta   %cl
  66ae14:	08 c1                	or     %al,%cl
  66ae16:	0f 84 40 02 00 00    	je     66b05c <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x6bc>
  66ae1c:	45 31 f6             	xor    %r14d,%r14d
  66ae1f:	41 b7 01             	mov    $0x1,%r15b
  66ae22:	4c 89 f7             	mov    %r14,%rdi
  66ae25:	48 89 de             	mov    %rbx,%rsi
  66ae28:	ff 15 6a f7 11 00    	call   *0x11f76a(%rip)        # 78a598 <_DYNAMIC+0x350>
  66ae2e:	e9 b7 1a 00 00       	jmp    66c8ea <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f4a>
  66ae33:	45 31 f6             	xor    %r14d,%r14d
  66ae36:	41 bc ff ff ff ff    	mov    $0xffffffff,%r12d
  66ae3c:	48 c7 44 24 70 00 00 	movq   $0x0,0x70(%rsp)
  66ae43:	00 00 
  66ae45:	4c 8b 7c 24 68       	mov    0x68(%rsp),%r15
  66ae4a:	48 c7 44 24 38 00 00 	movq   $0x0,0x38(%rsp)
  66ae51:	00 00 
  66ae53:	eb 27                	jmp    66ae7c <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x4dc>
  66ae55:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
  66ae5a:	49 89 cf             	mov    %rcx,%r15
  66ae5d:	8b 84 24 a0 00 00 00 	mov    0xa0(%rsp),%eax
  66ae64:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  66ae69:	48 3b 8c 24 20 01 00 	cmp    0x120(%rsp),%rcx
  66ae70:	00 
  66ae71:	4c 8b 6c 24 28       	mov    0x28(%rsp),%r13
  66ae76:	0f 84 76 ff ff ff    	je     66adf2 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x452>
  66ae7c:	49 8b 57 10          	mov    0x10(%r15),%rdx
  66ae80:	49 8b 4f 18          	mov    0x18(%r15),%rcx
  66ae84:	48 8d bc 24 b0 03 00 	lea    0x3b0(%rsp),%rdi
  66ae8b:	00 
  66ae8c:	4c 89 ee             	mov    %r13,%rsi
  66ae8f:	4c 8d 84 24 f8 00 00 	lea    0xf8(%rsp),%r8
  66ae96:	00 
  66ae97:	4c 8d 8c 24 00 01 00 	lea    0x100(%rsp),%r9
  66ae9e:	00 
  66ae9f:	e8 8c 1b 00 00       	call   66ca30 <parley::editing::geometry::source_runs::<()>>
  66aea4:	4c 8b ac 24 b8 03 00 	mov    0x3b8(%rsp),%r13
  66aeab:	00 
  66aeac:	4d 85 ed             	test   %r13,%r13
  66aeaf:	0f 84 04 14 00 00    	je     66c2b9 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1919>
  66aeb5:	4c 89 7c 24 40       	mov    %r15,0x40(%rsp)
  66aeba:	49 8d 47 70          	lea    0x70(%r15),%rax
  66aebe:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  66aec3:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  66aec8:	ff c0                	inc    %eax
  66aeca:	89 84 24 a0 00 00 00 	mov    %eax,0xa0(%rsp)
  66aed1:	48 8b 84 24 c0 03 00 	mov    0x3c0(%rsp),%rax
  66aed8:	00 
  66aed9:	4c 8d 3c c5 00 00 00 	lea    0x0(,%rax,8),%r15
  66aee0:	00 
  66aee1:	4d 01 ef             	add    %r13,%r15
  66aee4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  66aeeb:	00 00 00 00 00 
  66aef0:	4d 39 fd             	cmp    %r15,%r13
  66aef3:	0f 84 5c ff ff ff    	je     66ae55 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x4b5>
  66aef9:	41 8b 45 00          	mov    0x0(%r13),%eax
  66aefd:	49 83 c5 08          	add    $0x8,%r13
  66af01:	4c 39 e0             	cmp    %r12,%rax
  66af04:	74 ea                	je     66aef0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x550>
  66af06:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
  66af0b:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
  66af0f:	48 01 c1             	add    %rax,%rcx
  66af12:	bb fe ff ff ff       	mov    $0xfffffffe,%ebx
  66af17:	40 b7 01             	mov    $0x1,%dil
  66af1a:	48 3b 4a 18          	cmp    0x18(%rdx),%rcx
  66af1e:	0f 83 24 14 00 00    	jae    66c348 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19a8>
  66af24:	48 3b 8c 24 98 00 00 	cmp    0x98(%rsp),%rcx
  66af2b:	00 
  66af2c:	0f 83 16 14 00 00    	jae    66c348 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19a8>
  66af32:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
  66af36:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
  66af3b:	80 7c ca 21 00       	cmpb   $0x0,0x21(%rdx,%rcx,8)
  66af40:	0f 85 02 14 00 00    	jne    66c348 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19a8>
  66af46:	4c 89 74 24 60       	mov    %r14,0x60(%rsp)
  66af4b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
  66af4f:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
  66af53:	48 3b 4c 24 10       	cmp    0x10(%rsp),%rcx
  66af58:	0f 83 ea 13 00 00    	jae    66c348 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19a8>
  66af5e:	48 8d 1c c9          	lea    (%rcx,%rcx,8),%rbx
  66af62:	48 c1 e3 04          	shl    $0x4,%rbx
  66af66:	48 03 9c 24 d0 00 00 	add    0xd0(%rsp),%rbx
  66af6d:	00 
  66af6e:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
  66af72:	48 c1 e6 04          	shl    $0x4,%rsi
  66af76:	48 03 b4 24 c8 00 00 	add    0xc8(%rsp),%rsi
  66af7d:	00 
  66af7e:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
  66af83:	48 89 bc 24 b0 03 00 	mov    %rdi,0x3b0(%rsp)
  66af8a:	00 
  66af8b:	48 89 9c 24 b8 03 00 	mov    %rbx,0x3b8(%rsp)
  66af92:	00 
  66af93:	48 89 b4 24 c0 03 00 	mov    %rsi,0x3c0(%rsp)
  66af9a:	00 
  66af9b:	48 89 94 24 c8 03 00 	mov    %rdx,0x3c8(%rsp)
  66afa2:	00 
  66afa3:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
  66afa8:	89 94 24 d0 03 00 00 	mov    %edx,0x3d0(%rsp)
  66afaf:	89 84 24 d4 03 00 00 	mov    %eax,0x3d4(%rsp)
  66afb6:	89 8c 24 d8 03 00 00 	mov    %ecx,0x3d8(%rsp)
  66afbd:	48 8d ac 24 f8 06 00 	lea    0x6f8(%rsp),%rbp
  66afc4:	00 
  66afc5:	48 89 ef             	mov    %rbp,%rdi
  66afc8:	4c 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%r14
  66afcf:	00 
  66afd0:	4c 89 f6             	mov    %r14,%rsi
  66afd3:	31 d2                	xor    %edx,%edx
  66afd5:	e8 66 ca ff ff       	call   667a40 <<parley::layout::run::Clusters<()>>::new>
  66afda:	ba 10 01 00 00       	mov    $0x110,%edx
  66afdf:	4c 89 f7             	mov    %r14,%rdi
  66afe2:	48 89 ee             	mov    %rbp,%rsi
  66afe5:	ff 15 2d f5 11 00    	call   *0x11f52d(%rip)        # 78a518 <memcpy@GLIBC_2.14>
  66afeb:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  66aff0:	4c 8d 70 01          	lea    0x1(%rax),%r14
  66aff4:	31 ed                	xor    %ebp,%ebp
  66aff6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  66affd:	00 00 00 
  66b000:	48 8d bc 24 80 02 00 	lea    0x280(%rsp),%rdi
  66b007:	00 
  66b008:	48 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%rsi
  66b00f:	00 
  66b010:	e8 8b f2 ff ff       	call   66a2a0 <<parley::layout::run::Clusters<()> as core::iter::traits::iterator::Iterator>::next>
  66b015:	48 83 bc 24 80 02 00 	cmpq   $0x0,0x280(%rsp)
  66b01c:	00 00 
  66b01e:	74 0e                	je     66b02e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x68e>
  66b020:	49 39 ee             	cmp    %rbp,%r14
  66b023:	0f 84 12 13 00 00    	je     66c33b <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x199b>
  66b029:	48 ff cd             	dec    %rbp
  66b02c:	eb d2                	jmp    66b000 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x660>
  66b02e:	48 29 6c 24 70       	sub    %rbp,0x70(%rsp)
  66b033:	48 f7 dd             	neg    %rbp
  66b036:	4c 8b 74 24 60       	mov    0x60(%rsp),%r14
  66b03b:	4c 39 f5             	cmp    %r14,%rbp
  66b03e:	49 0f 46 ee          	cmovbe %r14,%rbp
  66b042:	f6 83 8c 00 00 00 01 	testb  $0x1,0x8c(%rbx)
  66b049:	4c 0f 45 f5          	cmovne %rbp,%r14
  66b04d:	48 8b 6c 24 20       	mov    0x20(%rsp),%rbp
  66b052:	48 8b 5c 24 50       	mov    0x50(%rsp),%rbx
  66b057:	e9 94 fe ff ff       	jmp    66aef0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x550>
  66b05c:	48 85 db             	test   %rbx,%rbx
  66b05f:	74 2f                	je     66b090 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x6f0>
  66b061:	4d 89 f4             	mov    %r14,%r12
  66b064:	ff 15 a6 f4 11 00    	call   *0x11f4a6(%rip)        # 78a510 <_DYNAMIC+0x2c8>
  66b06a:	41 be 04 00 00 00    	mov    $0x4,%r14d
  66b070:	be 04 00 00 00       	mov    $0x4,%esi
  66b075:	48 89 df             	mov    %rbx,%rdi
  66b078:	ff 15 fa f3 11 00    	call   *0x11f3fa(%rip)        # 78a478 <_DYNAMIC+0x230>
  66b07e:	48 85 c0             	test   %rax,%rax
  66b081:	4c 8b bc 24 b8 00 00 	mov    0xb8(%rsp),%r15
  66b088:	00 
  66b089:	75 15                	jne    66b0a0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x700>
  66b08b:	e9 8f fd ff ff       	jmp    66ae1f <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x47f>
  66b090:	b8 04 00 00 00       	mov    $0x4,%eax
  66b095:	45 31 e4             	xor    %r12d,%r12d
  66b098:	4c 8b bc 24 b8 00 00 	mov    0xb8(%rsp),%r15
  66b09f:	00 
  66b0a0:	4c 89 a4 24 d8 00 00 	mov    %r12,0xd8(%rsp)
  66b0a7:	00 
  66b0a8:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
  66b0af:	00 
  66b0b0:	48 c7 84 24 e8 00 00 	movq   $0x0,0xe8(%rsp)
  66b0b7:	00 00 00 00 00 
  66b0bc:	48 8d bc 24 e8 01 00 	lea    0x1e8(%rsp),%rdi
  66b0c3:	00 
  66b0c4:	ba 98 00 00 00       	mov    $0x98,%edx
  66b0c9:	48 89 ee             	mov    %rbp,%rsi
  66b0cc:	ff 15 46 f4 11 00    	call   *0x11f446(%rip)        # 78a518 <memcpy@GLIBC_2.14>
  66b0d2:	48 c7 84 24 d8 01 00 	movq   $0x2,0x1d8(%rsp)
  66b0d9:	00 02 00 00 00 
  66b0de:	c7 84 24 3c 01 00 00 	movl   $0x0,0x13c(%rsp)
  66b0e5:	00 00 00 00 
  66b0e9:	4d 85 ff             	test   %r15,%r15
  66b0ec:	0f 84 40 11 00 00    	je     66c232 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1892>
  66b0f2:	49 8b 85 30 01 00 00 	mov    0x130(%r13),%rax
  66b0f9:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  66b0fe:	49 8b 85 28 01 00 00 	mov    0x128(%r13),%rax
  66b105:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
  66b10c:	00 
  66b10d:	49 8b 45 58          	mov    0x58(%r13),%rax
  66b111:	49 8b 8d e8 00 00 00 	mov    0xe8(%r13),%rcx
  66b118:	48 39 c8             	cmp    %rcx,%rax
  66b11b:	48 89 8c 24 a0 01 00 	mov    %rcx,0x1a0(%rsp)
  66b122:	00 
  66b123:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
  66b12a:	00 
  66b12b:	48 0f 42 c8          	cmovb  %rax,%rcx
  66b12f:	48 89 8c 24 90 03 00 	mov    %rcx,0x390(%rsp)
  66b136:	00 
  66b137:	49 8b 85 e0 00 00 00 	mov    0xe0(%r13),%rax
  66b13e:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
  66b145:	00 
  66b146:	49 8b 45 50          	mov    0x50(%r13),%rax
  66b14a:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
  66b151:	00 
  66b152:	49 8b 45 38          	mov    0x38(%r13),%rax
  66b156:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
  66b15d:	00 
  66b15e:	49 8b 45 40          	mov    0x40(%r13),%rax
  66b162:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  66b169:	00 
  66b16a:	48 8d 05 bf 4e 11 00 	lea    0x114ebf(%rip),%rax        # 780030 <anon.1a71af429ce32665251a25071ff44b21.68.llvm.16581668395387327457+0xc0>
  66b171:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
  66b178:	00 
  66b179:	48 8d 05 70 4f 11 00 	lea    0x114f70(%rip),%rax        # 7800f0 <anon.89d2c5d0d416cd03e9cb3036fced70ec.21.llvm.1506394962952114297>
  66b180:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  66b185:	31 db                	xor    %ebx,%ebx
  66b187:	48 c7 84 24 a8 00 00 	movq   $0x0,0xa8(%rsp)
  66b18e:	00 00 00 00 00 
  66b193:	48 c7 44 24 70 00 00 	movq   $0x0,0x70(%rsp)
  66b19a:	00 00 
  66b19c:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  66b1a1:	eb 25                	jmp    66b1c8 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x828>
  66b1a3:	48 8b 94 24 a0 03 00 	mov    0x3a0(%rsp),%rdx
  66b1aa:	00 
  66b1ab:	48 89 d0             	mov    %rdx,%rax
  66b1ae:	8b 8c 24 38 01 00 00 	mov    0x138(%rsp),%ecx
  66b1b5:	48 89 4c 24 70       	mov    %rcx,0x70(%rsp)
  66b1ba:	48 3b 94 24 20 01 00 	cmp    0x120(%rsp),%rdx
  66b1c1:	00 
  66b1c2:	0f 84 77 12 00 00    	je     66c43f <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a9f>
  66b1c8:	48 8b 50 10          	mov    0x10(%rax),%rdx
  66b1cc:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
  66b1d1:	48 8b 48 18          	mov    0x18(%rax),%rcx
  66b1d5:	48 8d bc 24 b0 03 00 	lea    0x3b0(%rsp),%rdi
  66b1dc:	00 
  66b1dd:	4c 89 ee             	mov    %r13,%rsi
  66b1e0:	4c 8d 84 24 f8 00 00 	lea    0xf8(%rsp),%r8
  66b1e7:	00 
  66b1e8:	4c 8d 8c 24 00 01 00 	lea    0x100(%rsp),%r9
  66b1ef:	00 
  66b1f0:	e8 3b 18 00 00       	call   66ca30 <parley::editing::geometry::source_runs::<()>>
  66b1f5:	48 8b ac 24 b8 03 00 	mov    0x3b8(%rsp),%rbp
  66b1fc:	00 
  66b1fd:	48 85 ed             	test   %rbp,%rbp
  66b200:	0f 84 ca 15 00 00    	je     66c7d0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1e30>
  66b206:	48 89 9c 24 88 00 00 	mov    %rbx,0x88(%rsp)
  66b20d:	00 
  66b20e:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  66b213:	48 8b 78 10          	mov    0x10(%rax),%rdi
  66b217:	48 8b 70 18          	mov    0x18(%rax),%rsi
  66b21b:	48 39 fe             	cmp    %rdi,%rsi
  66b21e:	0f 82 95 15 00 00    	jb     66c7b9 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1e19>
  66b224:	48 3b 74 24 10       	cmp    0x10(%rsp),%rsi
  66b229:	0f 87 8a 15 00 00    	ja     66c7b9 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1e19>
  66b22f:	48 8b 9c 24 c0 03 00 	mov    0x3c0(%rsp),%rbx
  66b236:	00 
  66b237:	48 39 f7             	cmp    %rsi,%rdi
  66b23a:	0f 85 6b 0e 00 00    	jne    66c0ab <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x170b>
  66b240:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  66b245:	48 83 c0 70          	add    $0x70,%rax
  66b249:	48 89 84 24 a0 03 00 	mov    %rax,0x3a0(%rsp)
  66b250:	00 
  66b251:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  66b256:	ff c0                	inc    %eax
  66b258:	89 84 24 38 01 00 00 	mov    %eax,0x138(%rsp)
  66b25f:	4c 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%r10
  66b266:	00 
  66b267:	49 01 ea             	add    %rbp,%r10
  66b26a:	4c 8d b4 24 b8 03 00 	lea    0x3b8(%rsp),%r14
  66b271:	00 
  66b272:	4c 8d bc 24 b0 02 00 	lea    0x2b0(%rsp),%r15
  66b279:	00 
  66b27a:	4c 8d a4 24 00 03 00 	lea    0x300(%rsp),%r12
  66b281:	00 
  66b282:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
  66b287:	48 8b 9c 24 88 00 00 	mov    0x88(%rsp),%rbx
  66b28e:	00 
  66b28f:	90                   	nop
  66b290:	4c 39 d5             	cmp    %r10,%rbp
  66b293:	0f 84 0a ff ff ff    	je     66b1a3 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x803>
  66b299:	8b 45 00             	mov    0x0(%rbp),%eax
  66b29c:	48 83 c5 08          	add    $0x8,%rbp
  66b2a0:	48 39 c8             	cmp    %rcx,%rax
  66b2a3:	74 eb                	je     66b290 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x8f0>
  66b2a5:	48 8b 54 24 68       	mov    0x68(%rsp),%rdx
  66b2aa:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
  66b2ae:	48 01 c1             	add    %rax,%rcx
  66b2b1:	48 3b 4a 18          	cmp    0x18(%rdx),%rcx
  66b2b5:	0f 83 21 16 00 00    	jae    66c8dc <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f3c>
  66b2bb:	48 3b 4c 24 10       	cmp    0x10(%rsp),%rcx
  66b2c0:	0f 83 16 16 00 00    	jae    66c8dc <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f3c>
  66b2c6:	48 8d 14 89          	lea    (%rcx,%rcx,4),%rdx
  66b2ca:	48 8b b4 24 98 00 00 	mov    0x98(%rsp),%rsi
  66b2d1:	00 
  66b2d2:	48 8b 4c d6 10       	mov    0x10(%rsi,%rdx,8),%rcx
  66b2d7:	80 7c d6 21 01       	cmpb   $0x1,0x21(%rsi,%rdx,8)
  66b2dc:	0f 84 d8 15 00 00    	je     66c8ba <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f1a>
  66b2e2:	48 3b 8c 24 90 03 00 	cmp    0x390(%rsp),%rcx
  66b2e9:	00 
  66b2ea:	0f 83 ec 15 00 00    	jae    66c8dc <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f3c>
  66b2f0:	f3 0f 10 45 fc       	movss  -0x4(%rbp),%xmm0
  66b2f5:	f3 0f 11 44 24 38    	movss  %xmm0,0x38(%rsp)
  66b2fb:	48 8b b4 24 98 00 00 	mov    0x98(%rsp),%rsi
  66b302:	00 
  66b303:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
  66b307:	48 8d 34 c9          	lea    (%rcx,%rcx,8),%rsi
  66b30b:	48 c1 e6 04          	shl    $0x4,%rsi
  66b30f:	4c 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%r9
  66b316:	00 
  66b317:	49 8d 3c 31          	lea    (%r9,%rsi,1),%rdi
  66b31b:	4c 8d 04 89          	lea    (%rcx,%rcx,4),%r8
  66b31f:	49 c1 e0 04          	shl    $0x4,%r8
  66b323:	4c 03 84 24 d0 00 00 	add    0xd0(%rsp),%r8
  66b32a:	00 
  66b32b:	4c 89 ac 24 a8 01 00 	mov    %r13,0x1a8(%rsp)
  66b332:	00 
  66b333:	48 89 bc 24 b0 01 00 	mov    %rdi,0x1b0(%rsp)
  66b33a:	00 
  66b33b:	4c 89 84 24 b8 01 00 	mov    %r8,0x1b8(%rsp)
  66b342:	00 
  66b343:	48 89 94 24 c0 01 00 	mov    %rdx,0x1c0(%rsp)
  66b34a:	00 
  66b34b:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
  66b350:	89 94 24 c8 01 00 00 	mov    %edx,0x1c8(%rsp)
  66b357:	89 84 24 cc 01 00 00 	mov    %eax,0x1cc(%rsp)
  66b35e:	89 8c 24 d0 01 00 00 	mov    %ecx,0x1d0(%rsp)
  66b365:	48 c7 84 24 e8 00 00 	movq   $0x0,0xe8(%rsp)
  66b36c:	00 00 00 00 00 
  66b371:	41 0f b6 84 31 8c 00 	movzbl 0x8c(%r9,%rsi,1),%eax
  66b378:	00 00 
  66b37a:	88 84 24 a0 00 00 00 	mov    %al,0xa0(%rsp)
  66b381:	a8 01                	test   $0x1,%al
  66b383:	4c 89 94 24 98 03 00 	mov    %r10,0x398(%rsp)
  66b38a:	00 
  66b38b:	0f 85 2b 0b 00 00    	jne    66bebc <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x151c>
  66b391:	4c 8d ac 24 80 02 00 	lea    0x280(%rsp),%r13
  66b398:	00 
  66b399:	4c 89 ef             	mov    %r13,%rdi
  66b39c:	48 8d b4 24 a8 01 00 	lea    0x1a8(%rsp),%rsi
  66b3a3:	00 
  66b3a4:	31 d2                	xor    %edx,%edx
  66b3a6:	e8 95 c6 ff ff       	call   667a40 <<parley::layout::run::Clusters<()>>::new>
  66b3ab:	ba 10 01 00 00       	mov    $0x110,%edx
  66b3b0:	4c 89 f7             	mov    %r14,%rdi
  66b3b3:	4c 89 ee             	mov    %r13,%rsi
  66b3b6:	ff 15 5c f1 11 00    	call   *0x11f15c(%rip)        # 78a518 <memcpy@GLIBC_2.14>
  66b3bc:	48 c7 84 24 b0 03 00 	movq   $0x0,0x3b0(%rsp)
  66b3c3:	00 00 00 00 00 
  66b3c8:	0f b6 84 24 3c 01 00 	movzbl 0x13c(%rsp),%eax
  66b3cf:	00 
  66b3d0:	88 44 24 0f          	mov    %al,0xf(%rsp)
  66b3d4:	0f 57 c0             	xorps  %xmm0,%xmm0
  66b3d7:	f3 0f 11 84 24 90 00 	movss  %xmm0,0x90(%rsp)
  66b3de:	00 00 
  66b3e0:	48 c7 84 24 b0 00 00 	movq   $0x0,0xb0(%rsp)
  66b3e7:	00 00 00 00 00 
  66b3ec:	c7 44 24 5c 00 00 00 	movl   $0x0,0x5c(%rsp)
  66b3f3:	00 
  66b3f4:	4c 89 ef             	mov    %r13,%rdi
  66b3f7:	4c 89 f6             	mov    %r14,%rsi
  66b3fa:	e8 a1 ee ff ff       	call   66a2a0 <<parley::layout::run::Clusters<()> as core::iter::traits::iterator::Iterator>::next>
  66b3ff:	4c 8b b4 24 80 02 00 	mov    0x280(%rsp),%r14
  66b406:	00 
  66b407:	4d 85 f6             	test   %r14,%r14
  66b40a:	0f 84 9a 0a 00 00    	je     66beaa <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x150a>
  66b410:	ba 88 00 00 00       	mov    $0x88,%edx
  66b415:	4c 8d a4 24 60 05 00 	lea    0x560(%rsp),%r12
  66b41c:	00 
  66b41d:	4c 89 e7             	mov    %r12,%rdi
  66b420:	48 8d b4 24 88 02 00 	lea    0x288(%rsp),%rsi
  66b427:	00 
  66b428:	48 8b 1d e9 f0 11 00 	mov    0x11f0e9(%rip),%rbx        # 78a518 <memcpy@GLIBC_2.14>
  66b42f:	ff d3                	call   *%rbx
  66b431:	4c 8b bc 24 b0 03 00 	mov    0x3b0(%rsp),%r15
  66b438:	00 
  66b439:	49 8d 47 01          	lea    0x1(%r15),%rax
  66b43d:	48 89 84 24 b0 03 00 	mov    %rax,0x3b0(%rsp)
  66b444:	00 
  66b445:	4c 89 b4 24 d0 04 00 	mov    %r14,0x4d0(%rsp)
  66b44c:	00 
  66b44d:	ba 88 00 00 00       	mov    $0x88,%edx
  66b452:	48 8d bc 24 d8 04 00 	lea    0x4d8(%rsp),%rdi
  66b459:	00 
  66b45a:	4c 89 e6             	mov    %r12,%rsi
  66b45d:	ff d3                	call   *%rbx
  66b45f:	44 8b ac 24 f8 04 00 	mov    0x4f8(%rsp),%r13d
  66b466:	00 
  66b467:	49 8b 46 58          	mov    0x58(%r14),%rax
  66b46b:	4c 39 e8             	cmp    %r13,%rax
  66b46e:	0f 86 7a 13 00 00    	jbe    66c7ee <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1e4e>
  66b474:	49 8b 46 50          	mov    0x50(%r14),%rax
  66b478:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
  66b47f:	00 
  66b480:	4c 01 e9             	add    %r13,%rcx
  66b483:	48 c1 e1 04          	shl    $0x4,%rcx
  66b487:	41 0f 10 46 68       	movups 0x68(%r14),%xmm0
  66b48c:	41 0f 10 8e 80 00 00 	movups 0x80(%r14),%xmm1
  66b493:	00 
  66b494:	41 0f 10 96 98 00 00 	movups 0x98(%r14),%xmm2
  66b49b:	00 
  66b49c:	0f 11 84 24 80 02 00 	movups %xmm0,0x280(%rsp)
  66b4a3:	00 
  66b4a4:	0f 11 8c 24 90 02 00 	movups %xmm1,0x290(%rsp)
  66b4ab:	00 
  66b4ac:	0f 11 94 24 a0 02 00 	movups %xmm2,0x2a0(%rsp)
  66b4b3:	00 
  66b4b4:	48 8b 44 08 50       	mov    0x50(%rax,%rcx,1),%rax
  66b4b9:	48 89 84 24 b0 02 00 	mov    %rax,0x2b0(%rsp)
  66b4c0:	00 
  66b4c1:	8b 9c 24 50 05 00 00 	mov    0x550(%rsp),%ebx
  66b4c8:	44 8b a4 24 54 05 00 	mov    0x554(%rsp),%r12d
  66b4cf:	00 
  66b4d0:	48 8d bc 24 80 02 00 	lea    0x280(%rsp),%rdi
  66b4d7:	00 
  66b4d8:	89 de                	mov    %ebx,%esi
  66b4da:	44 89 e2             	mov    %r12d,%edx
  66b4dd:	ff 15 8d f2 11 00    	call   *0x11f28d(%rip)        # 78a770 <_DYNAMIC+0x528>
  66b4e3:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  66b4e8:	48 89 54 24 48       	mov    %rdx,0x48(%rsp)
  66b4ed:	f6 84 24 a0 00 00 00 	testb  $0x1,0xa0(%rsp)
  66b4f4:	01 
  66b4f5:	75 39                	jne    66b530 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xb90>
  66b4f7:	48 83 bc 24 e8 04 00 	cmpq   $0x0,0x4e8(%rsp)
  66b4fe:	00 00 
  66b500:	74 67                	je     66b569 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xbc9>
  66b502:	8b 84 24 f0 04 00 00 	mov    0x4f0(%rsp),%eax
  66b509:	49 8b 8e 18 01 00 00 	mov    0x118(%r14),%rcx
  66b510:	48 39 c1             	cmp    %rax,%rcx
  66b513:	0f 86 6a 13 00 00    	jbe    66c883 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ee3>
  66b519:	49 8b 8e 10 01 00 00 	mov    0x110(%r14),%rcx
  66b520:	48 6b c0 70          	imul   $0x70,%rax,%rax
  66b524:	f3 0f 10 44 01 50    	movss  0x50(%rcx,%rax,1),%xmm0
  66b52a:	8b 44 01 54          	mov    0x54(%rcx,%rax,1),%eax
  66b52e:	eb 41                	jmp    66b571 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xbd1>
  66b530:	48 8b 84 24 e8 00 00 	mov    0xe8(%rsp),%rax
  66b537:	00 
  66b538:	49 f7 d7             	not    %r15
  66b53b:	49 01 c7             	add    %rax,%r15
  66b53e:	0f 83 2e 13 00 00    	jae    66c872 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ed2>
  66b544:	48 8b 84 24 e0 00 00 	mov    0xe0(%rsp),%rax
  66b54b:	00 
  66b54c:	f3 42 0f 10 04 b8    	movss  (%rax,%r15,4),%xmm0
  66b552:	f3 0f 11 44 24 78    	movss  %xmm0,0x78(%rsp)
  66b558:	f3 0f 10 84 24 90 00 	movss  0x90(%rsp),%xmm0
  66b55f:	00 00 
  66b561:	f3 0f 11 44 24 40    	movss  %xmm0,0x40(%rsp)
  66b567:	eb 7a                	jmp    66b5e3 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xc43>
  66b569:	0f 57 c0             	xorps  %xmm0,%xmm0
  66b56c:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  66b571:	48 8b 8c 24 d8 04 00 	mov    0x4d8(%rsp),%rcx
  66b578:	00 
  66b579:	48 8b 94 24 e0 04 00 	mov    0x4e0(%rsp),%rdx
  66b580:	00 
  66b581:	f2 0f 10 4a 44       	movsd  0x44(%rdx),%xmm1
  66b586:	f2 0f 11 8c 24 80 02 	movsd  %xmm1,0x280(%rsp)
  66b58d:	00 00 
  66b58f:	f3 0f 11 84 24 88 02 	movss  %xmm0,0x288(%rsp)
  66b596:	00 00 
  66b598:	89 84 24 8c 02 00 00 	mov    %eax,0x28c(%rsp)
  66b59f:	0f b6 89 8c 00 00 00 	movzbl 0x8c(%rcx),%ecx
  66b5a6:	83 e1 01             	and    $0x1,%ecx
  66b5a9:	48 8d bc 24 80 02 00 	lea    0x280(%rsp),%rdi
  66b5b0:	00 
  66b5b1:	48 8d b4 24 00 05 00 	lea    0x500(%rsp),%rsi
  66b5b8:	00 
  66b5b9:	48 8d 94 24 50 05 00 	lea    0x550(%rsp),%rdx
  66b5c0:	00 
  66b5c1:	ff 15 a1 f1 11 00    	call   *0x11f1a1(%rip)        # 78a768 <_DYNAMIC+0x520>
  66b5c7:	f3 0f 10 4c 24 38    	movss  0x38(%rsp),%xmm1
  66b5cd:	f3 0f 58 c1          	addss  %xmm1,%xmm0
  66b5d1:	f3 0f 11 4c 24 40    	movss  %xmm1,0x40(%rsp)
  66b5d7:	f3 0f 11 4c 24 78    	movss  %xmm1,0x78(%rsp)
  66b5dd:	f3 0f 11 44 24 38    	movss  %xmm0,0x38(%rsp)
  66b5e3:	48 83 bc 24 f0 00 00 	cmpq   $0x0,0xf0(%rsp)
  66b5ea:	00 00 
  66b5ec:	74 22                	je     66b610 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xc70>
  66b5ee:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  66b5f3:	48 3b 44 24 48       	cmp    0x48(%rsp),%rax
  66b5f8:	0f 82 43 02 00 00    	jb     66b841 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xea1>
  66b5fe:	eb 10                	jmp    66b610 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xc70>
  66b600:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  66b605:	48 3b 44 24 48       	cmp    0x48(%rsp),%rax
  66b60a:	0f 82 29 02 00 00    	jb     66b839 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xe99>
  66b610:	48 8d bc 24 80 02 00 	lea    0x280(%rsp),%rdi
  66b617:	00 
  66b618:	48 8d b4 24 b8 03 00 	lea    0x3b8(%rsp),%rsi
  66b61f:	00 
  66b620:	e8 7b ec ff ff       	call   66a2a0 <<parley::layout::run::Clusters<()> as core::iter::traits::iterator::Iterator>::next>
  66b625:	4c 8b b4 24 80 02 00 	mov    0x280(%rsp),%r14
  66b62c:	00 
  66b62d:	4d 85 f6             	test   %r14,%r14
  66b630:	0f 84 74 08 00 00    	je     66beaa <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x150a>
  66b636:	ba 88 00 00 00       	mov    $0x88,%edx
  66b63b:	4c 8d a4 24 60 05 00 	lea    0x560(%rsp),%r12
  66b642:	00 
  66b643:	4c 89 e7             	mov    %r12,%rdi
  66b646:	48 8d b4 24 88 02 00 	lea    0x288(%rsp),%rsi
  66b64d:	00 
  66b64e:	48 8b 1d c3 ee 11 00 	mov    0x11eec3(%rip),%rbx        # 78a518 <memcpy@GLIBC_2.14>
  66b655:	ff d3                	call   *%rbx
  66b657:	4c 8b bc 24 b0 03 00 	mov    0x3b0(%rsp),%r15
  66b65e:	00 
  66b65f:	49 8d 47 01          	lea    0x1(%r15),%rax
  66b663:	48 89 84 24 b0 03 00 	mov    %rax,0x3b0(%rsp)
  66b66a:	00 
  66b66b:	4c 89 b4 24 d0 04 00 	mov    %r14,0x4d0(%rsp)
  66b672:	00 
  66b673:	ba 88 00 00 00       	mov    $0x88,%edx
  66b678:	48 8d bc 24 d8 04 00 	lea    0x4d8(%rsp),%rdi
  66b67f:	00 
  66b680:	4c 89 e6             	mov    %r12,%rsi
  66b683:	ff d3                	call   *%rbx
  66b685:	44 8b ac 24 f8 04 00 	mov    0x4f8(%rsp),%r13d
  66b68c:	00 
  66b68d:	49 8b 46 58          	mov    0x58(%r14),%rax
  66b691:	4c 39 e8             	cmp    %r13,%rax
  66b694:	0f 86 54 11 00 00    	jbe    66c7ee <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1e4e>
  66b69a:	49 8b 46 50          	mov    0x50(%r14),%rax
  66b69e:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
  66b6a5:	00 
  66b6a6:	4c 01 e9             	add    %r13,%rcx
  66b6a9:	48 c1 e1 04          	shl    $0x4,%rcx
  66b6ad:	41 0f 10 46 68       	movups 0x68(%r14),%xmm0
  66b6b2:	41 0f 10 8e 80 00 00 	movups 0x80(%r14),%xmm1
  66b6b9:	00 
  66b6ba:	41 0f 10 96 98 00 00 	movups 0x98(%r14),%xmm2
  66b6c1:	00 
  66b6c2:	0f 11 84 24 80 02 00 	movups %xmm0,0x280(%rsp)
  66b6c9:	00 
  66b6ca:	0f 11 8c 24 90 02 00 	movups %xmm1,0x290(%rsp)
  66b6d1:	00 
  66b6d2:	0f 11 94 24 a0 02 00 	movups %xmm2,0x2a0(%rsp)
  66b6d9:	00 
  66b6da:	48 8b 44 08 50       	mov    0x50(%rax,%rcx,1),%rax
  66b6df:	48 89 84 24 b0 02 00 	mov    %rax,0x2b0(%rsp)
  66b6e6:	00 
  66b6e7:	8b 9c 24 50 05 00 00 	mov    0x550(%rsp),%ebx
  66b6ee:	44 8b a4 24 54 05 00 	mov    0x554(%rsp),%r12d
  66b6f5:	00 
  66b6f6:	48 8d bc 24 80 02 00 	lea    0x280(%rsp),%rdi
  66b6fd:	00 
  66b6fe:	89 de                	mov    %ebx,%esi
  66b700:	44 89 e2             	mov    %r12d,%edx
  66b703:	ff 15 67 f0 11 00    	call   *0x11f067(%rip)        # 78a770 <_DYNAMIC+0x528>
  66b709:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  66b70e:	48 89 54 24 48       	mov    %rdx,0x48(%rsp)
  66b713:	f6 84 24 a0 00 00 00 	testb  $0x1,0xa0(%rsp)
  66b71a:	01 
  66b71b:	75 43                	jne    66b760 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xdc0>
  66b71d:	48 83 bc 24 e8 04 00 	cmpq   $0x0,0x4e8(%rsp)
  66b724:	00 00 
  66b726:	0f 84 7f 00 00 00    	je     66b7ab <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xe0b>
  66b72c:	8b 84 24 f0 04 00 00 	mov    0x4f0(%rsp),%eax
  66b733:	49 8b 8e 18 01 00 00 	mov    0x118(%r14),%rcx
  66b73a:	48 39 c1             	cmp    %rax,%rcx
  66b73d:	0f 86 40 11 00 00    	jbe    66c883 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ee3>
  66b743:	49 8b 8e 10 01 00 00 	mov    0x110(%r14),%rcx
  66b74a:	48 6b c0 70          	imul   $0x70,%rax,%rax
  66b74e:	f3 0f 10 44 01 50    	movss  0x50(%rcx,%rax,1),%xmm0
  66b754:	8b 44 01 54          	mov    0x54(%rcx,%rax,1),%eax
  66b758:	eb 59                	jmp    66b7b3 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xe13>
  66b75a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  66b760:	48 8b 84 24 e8 00 00 	mov    0xe8(%rsp),%rax
  66b767:	00 
  66b768:	49 f7 d7             	not    %r15
  66b76b:	49 01 c7             	add    %rax,%r15
  66b76e:	0f 83 fe 10 00 00    	jae    66c872 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ed2>
  66b774:	48 8b 84 24 e0 00 00 	mov    0xe0(%rsp),%rax
  66b77b:	00 
  66b77c:	f3 42 0f 10 04 b8    	movss  (%rax,%r15,4),%xmm0
  66b782:	f3 0f 11 44 24 78    	movss  %xmm0,0x78(%rsp)
  66b788:	f3 0f 10 84 24 90 00 	movss  0x90(%rsp),%xmm0
  66b78f:	00 00 
  66b791:	f3 0f 11 44 24 40    	movss  %xmm0,0x40(%rsp)
  66b797:	48 83 bc 24 f0 00 00 	cmpq   $0x0,0xf0(%rsp)
  66b79e:	00 00 
  66b7a0:	0f 85 5a fe ff ff    	jne    66b600 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xc60>
  66b7a6:	e9 65 fe ff ff       	jmp    66b610 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xc70>
  66b7ab:	0f 57 c0             	xorps  %xmm0,%xmm0
  66b7ae:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  66b7b3:	48 8b 8c 24 d8 04 00 	mov    0x4d8(%rsp),%rcx
  66b7ba:	00 
  66b7bb:	48 8b 94 24 e0 04 00 	mov    0x4e0(%rsp),%rdx
  66b7c2:	00 
  66b7c3:	f2 0f 10 4a 44       	movsd  0x44(%rdx),%xmm1
  66b7c8:	f2 0f 11 8c 24 80 02 	movsd  %xmm1,0x280(%rsp)
  66b7cf:	00 00 
  66b7d1:	f3 0f 11 84 24 88 02 	movss  %xmm0,0x288(%rsp)
  66b7d8:	00 00 
  66b7da:	89 84 24 8c 02 00 00 	mov    %eax,0x28c(%rsp)
  66b7e1:	0f b6 89 8c 00 00 00 	movzbl 0x8c(%rcx),%ecx
  66b7e8:	83 e1 01             	and    $0x1,%ecx
  66b7eb:	48 8d bc 24 80 02 00 	lea    0x280(%rsp),%rdi
  66b7f2:	00 
  66b7f3:	48 8d b4 24 00 05 00 	lea    0x500(%rsp),%rsi
  66b7fa:	00 
  66b7fb:	48 8d 94 24 50 05 00 	lea    0x550(%rsp),%rdx
  66b802:	00 
  66b803:	ff 15 5f ef 11 00    	call   *0x11ef5f(%rip)        # 78a768 <_DYNAMIC+0x520>
  66b809:	f3 0f 10 4c 24 38    	movss  0x38(%rsp),%xmm1
  66b80f:	f3 0f 58 c1          	addss  %xmm1,%xmm0
  66b813:	f3 0f 11 4c 24 40    	movss  %xmm1,0x40(%rsp)
  66b819:	f3 0f 11 4c 24 78    	movss  %xmm1,0x78(%rsp)
  66b81f:	f3 0f 11 44 24 38    	movss  %xmm0,0x38(%rsp)
  66b825:	48 83 bc 24 f0 00 00 	cmpq   $0x0,0xf0(%rsp)
  66b82c:	00 00 
  66b82e:	0f 85 cc fd ff ff    	jne    66b600 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xc60>
  66b834:	e9 d7 fd ff ff       	jmp    66b610 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xc70>
  66b839:	c7 44 24 5c 00 00 00 	movl   $0x0,0x5c(%rsp)
  66b840:	00 
  66b841:	48 8b 84 24 f0 04 00 	mov    0x4f0(%rsp),%rax
  66b848:	00 
  66b849:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
  66b850:	00 
  66b851:	89 9c 24 30 01 00 00 	mov    %ebx,0x130(%rsp)
  66b858:	f3 0f 10 44 24 78    	movss  0x78(%rsp),%xmm0
  66b85e:	f3 0f 11 84 24 34 01 	movss  %xmm0,0x134(%rsp)
  66b865:	00 00 
  66b867:	48 8b 84 24 d8 01 00 	mov    0x1d8(%rsp),%rax
  66b86e:	00 
  66b86f:	48 83 f8 02          	cmp    $0x2,%rax
  66b873:	75 22                	jne    66b897 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xef7>
  66b875:	48 8d bc 24 e8 01 00 	lea    0x1e8(%rsp),%rdi
  66b87c:	00 
  66b87d:	e8 ae e6 00 00       	call   679f30 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  66b882:	49 89 d7             	mov    %rdx,%r15
  66b885:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
  66b88c:	00 
  66b88d:	48 89 94 24 e0 01 00 	mov    %rdx,0x1e0(%rsp)
  66b894:	00 
  66b895:	eb 08                	jmp    66b89f <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xeff>
  66b897:	4c 8b bc 24 e0 01 00 	mov    0x1e0(%rsp),%r15
  66b89e:	00 
  66b89f:	89 d9                	mov    %ebx,%ecx
  66b8a1:	48 89 8c 24 90 00 00 	mov    %rcx,0x90(%rsp)
  66b8a8:	00 
  66b8a9:	44 89 e1             	mov    %r12d,%ecx
  66b8ac:	48 89 8c 24 18 01 00 	mov    %rcx,0x118(%rsp)
  66b8b3:	00 
  66b8b4:	48 83 f8 01          	cmp    $0x1,%rax
  66b8b8:	0f 85 97 01 00 00    	jne    66ba55 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x10b5>
  66b8be:	4c 3b 7c 24 48       	cmp    0x48(%rsp),%r15
  66b8c3:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
  66b8ca:	00 
  66b8cb:	0f 83 27 05 00 00    	jae    66bdf8 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1458>
  66b8d1:	48 83 f9 01          	cmp    $0x1,%rcx
  66b8d5:	75 0e                	jne    66b8e5 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xf45>
  66b8d7:	4c 3b bc 24 80 00 00 	cmp    0x80(%rsp),%r15
  66b8de:	00 
  66b8df:	0f 82 f3 09 00 00    	jb     66c2d8 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1938>
  66b8e5:	f3 0f 10 4c 24 40    	movss  0x40(%rsp),%xmm1
  66b8eb:	0f 57 c0             	xorps  %xmm0,%xmm0
  66b8ee:	f3 0f 5a c1          	cvtss2sd %xmm1,%xmm0
  66b8f2:	f2 0f 11 84 24 88 00 	movsd  %xmm0,0x88(%rsp)
  66b8f9:	00 00 
  66b8fb:	f3 0f 58 4c 24 1c    	addss  0x1c(%rsp),%xmm1
  66b901:	0f 57 c0             	xorps  %xmm0,%xmm0
  66b904:	f3 0f 5a c1          	cvtss2sd %xmm1,%xmm0
  66b908:	f2 0f 11 84 24 80 00 	movsd  %xmm0,0x80(%rsp)
  66b90f:	00 00 
  66b911:	48 c7 84 24 d8 01 00 	movq   $0x2,0x1d8(%rsp)
  66b918:	00 02 00 00 00 
  66b91d:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  66b922:	49 39 d7             	cmp    %rdx,%r15
  66b925:	0f 85 37 01 00 00    	jne    66ba62 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x10c2>
  66b92b:	48 39 94 24 b0 00 00 	cmp    %rdx,0xb0(%rsp)
  66b932:	00 
  66b933:	0f 94 c0             	sete   %al
  66b936:	22 44 24 5c          	and    0x5c(%rsp),%al
  66b93a:	4c 8d 84 24 28 01 00 	lea    0x128(%rsp),%r8
  66b941:	00 
  66b942:	3c 01                	cmp    $0x1,%al
  66b944:	0f 85 32 01 00 00    	jne    66ba7c <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x10dc>
  66b94a:	49 8b 46 58          	mov    0x58(%r14),%rax
  66b94e:	4c 39 e8             	cmp    %r13,%rax
  66b951:	0f 86 97 0e 00 00    	jbe    66c7ee <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1e4e>
  66b957:	49 8b 56 70          	mov    0x70(%r14),%rdx
  66b95b:	48 8b bc 24 90 00 00 	mov    0x90(%rsp),%rdi
  66b962:	00 
  66b963:	48 8b b4 24 18 01 00 	mov    0x118(%rsp),%rsi
  66b96a:	00 
  66b96b:	39 fe                	cmp    %edi,%esi
  66b96d:	0f 82 34 0e 00 00    	jb     66c7a7 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1e07>
  66b973:	48 39 f2             	cmp    %rsi,%rdx
  66b976:	0f 82 2b 0e 00 00    	jb     66c7a7 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1e07>
  66b97c:	39 fe                	cmp    %edi,%esi
  66b97e:	0f 84 28 0f 00 00    	je     66c8ac <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f0c>
  66b984:	49 8b 46 68          	mov    0x68(%r14),%rax
  66b988:	48 8d 0c 7f          	lea    (%rdi,%rdi,2),%rcx
  66b98c:	80 7c 88 07 06       	cmpb   $0x6,0x7(%rax,%rcx,4)
  66b991:	48 8b 94 24 b0 00 00 	mov    0xb0(%rsp),%rdx
  66b998:	00 
  66b999:	0f 84 dd 00 00 00    	je     66ba7c <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x10dc>
  66b99f:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  66b9a4:	f3 0f 10 40 40       	movss  0x40(%rax),%xmm0
  66b9a9:	f3 0f 10 48 44       	movss  0x44(%rax),%xmm1
  66b9ae:	0f 28 d0             	movaps %xmm0,%xmm2
  66b9b1:	f3 0f 5d 50 48       	minss  0x48(%rax),%xmm2
  66b9b6:	0f 28 da             	movaps %xmm2,%xmm3
  66b9b9:	f3 0f c2 da 03       	cmpunordss %xmm2,%xmm3
  66b9be:	0f 28 e3             	movaps %xmm3,%xmm4
  66b9c1:	0f 55 e2             	andnps %xmm2,%xmm4
  66b9c4:	0f 54 d8             	andps  %xmm0,%xmm3
  66b9c7:	0f 56 dc             	orps   %xmm4,%xmm3
  66b9ca:	0f 57 c0             	xorps  %xmm0,%xmm0
  66b9cd:	f3 0f 5a c3          	cvtss2sd %xmm3,%xmm0
  66b9d1:	0f 28 d1             	movaps %xmm1,%xmm2
  66b9d4:	f3 0f 5f 50 4c       	maxss  0x4c(%rax),%xmm2
  66b9d9:	0f 28 da             	movaps %xmm2,%xmm3
  66b9dc:	f3 0f c2 da 03       	cmpunordss %xmm2,%xmm3
  66b9e1:	0f 28 e3             	movaps %xmm3,%xmm4
  66b9e4:	0f 55 e2             	andnps %xmm2,%xmm4
  66b9e7:	0f 54 d9             	andps  %xmm1,%xmm3
  66b9ea:	0f 56 dc             	orps   %xmm4,%xmm3
  66b9ed:	0f 57 c9             	xorps  %xmm1,%xmm1
  66b9f0:	f3 0f 5a cb          	cvtss2sd %xmm3,%xmm1
  66b9f4:	f2 0f 10 94 24 88 00 	movsd  0x88(%rsp),%xmm2
  66b9fb:	00 00 
  66b9fd:	f2 0f 11 94 24 58 01 	movsd  %xmm2,0x158(%rsp)
  66ba04:	00 00 
  66ba06:	f2 0f 11 84 24 60 01 	movsd  %xmm0,0x160(%rsp)
  66ba0d:	00 00 
  66ba0f:	f2 0f 10 9c 24 80 00 	movsd  0x80(%rsp),%xmm3
  66ba16:	00 00 
  66ba18:	f2 0f 11 9c 24 68 01 	movsd  %xmm3,0x168(%rsp)
  66ba1f:	00 00 
  66ba21:	f2 0f 11 8c 24 70 01 	movsd  %xmm1,0x170(%rsp)
  66ba28:	00 00 
  66ba2a:	f2 0f 11 94 24 78 01 	movsd  %xmm2,0x178(%rsp)
  66ba31:	00 00 
  66ba33:	f2 0f 11 84 24 80 01 	movsd  %xmm0,0x180(%rsp)
  66ba3a:	00 00 
  66ba3c:	f2 0f 11 9c 24 88 01 	movsd  %xmm3,0x188(%rsp)
  66ba43:	00 00 
  66ba45:	f2 0f 11 8c 24 90 01 	movsd  %xmm1,0x190(%rsp)
  66ba4c:	00 00 
  66ba4e:	b8 01 00 00 00       	mov    $0x1,%eax
  66ba53:	eb 1d                	jmp    66ba72 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x10d2>
  66ba55:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
  66ba5c:	00 
  66ba5d:	e9 96 03 00 00       	jmp    66bdf8 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1458>
  66ba62:	4c 89 fa             	mov    %r15,%rdx
  66ba65:	41 b8 00 00 00 00    	mov    $0x0,%r8d
  66ba6b:	b8 00 00 00 00       	mov    $0x0,%eax
  66ba70:	76 0a                	jbe    66ba7c <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x10dc>
  66ba72:	48 89 84 24 50 01 00 	mov    %rax,0x150(%rsp)
  66ba79:	00 
  66ba7a:	eb 40                	jmp    66babc <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x111c>
  66ba7c:	48 39 94 24 a8 00 00 	cmp    %rdx,0xa8(%rsp)
  66ba83:	00 
  66ba84:	b9 00 00 00 00       	mov    $0x0,%ecx
  66ba89:	48 8d 84 24 40 01 00 	lea    0x140(%rsp),%rax
  66ba90:	00 
  66ba91:	48 0f 44 c8          	cmove  %rax,%rcx
  66ba95:	f6 44 24 0f 01       	testb  $0x1,0xf(%rsp)
  66ba9a:	b8 00 00 00 00       	mov    $0x0,%eax
  66ba9f:	48 0f 44 c8          	cmove  %rax,%rcx
  66baa3:	48 8d bc 24 50 01 00 	lea    0x150(%rsp),%rdi
  66baaa:	00 
  66baab:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  66bab0:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
  66bab6:	ff 15 7c eb 11 00    	call   *0x11eb7c(%rip)        # 78a638 <_DYNAMIC+0x3f0>
  66babc:	4c 89 bc 24 80 02 00 	mov    %r15,0x280(%rsp)
  66bac3:	00 
  66bac4:	48 8b 84 24 90 01 00 	mov    0x190(%rsp),%rax
  66bacb:	00 
  66bacc:	48 8d 94 24 88 02 00 	lea    0x288(%rsp),%rdx
  66bad3:	00 
  66bad4:	48 89 42 40          	mov    %rax,0x40(%rdx)
  66bad8:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
  66badf:	00 
  66bae0:	48 8b 8c 24 58 01 00 	mov    0x158(%rsp),%rcx
  66bae7:	00 
  66bae8:	0f 10 84 24 60 01 00 	movups 0x160(%rsp),%xmm0
  66baef:	00 
  66baf0:	0f 10 8c 24 70 01 00 	movups 0x170(%rsp),%xmm1
  66baf7:	00 
  66baf8:	0f 10 94 24 80 01 00 	movups 0x180(%rsp),%xmm2
  66baff:	00 
  66bb00:	0f 11 52 30          	movups %xmm2,0x30(%rdx)
  66bb04:	0f 11 4a 20          	movups %xmm1,0x20(%rdx)
  66bb08:	0f 11 42 10          	movups %xmm0,0x10(%rdx)
  66bb0c:	48 89 02             	mov    %rax,(%rdx)
  66bb0f:	48 89 4a 08          	mov    %rcx,0x8(%rdx)
  66bb13:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
  66bb18:	4c 89 fe             	mov    %r15,%rsi
  66bb1b:	e8 10 25 00 00       	call   66e030 <gpui_canvas::text::planner::append_carets::{closure#1}>
  66bb20:	89 c3                	mov    %eax,%ebx
  66bb22:	83 f8 ff             	cmp    $0xffffffff,%eax
  66bb25:	0f 85 07 09 00 00    	jne    66c432 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a92>
  66bb2b:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  66bb30:	48 39 8c 24 b0 00 00 	cmp    %rcx,0xb0(%rsp)
  66bb37:	00 
  66bb38:	0f 94 c0             	sete   %al
  66bb3b:	8b 54 24 5c          	mov    0x5c(%rsp),%edx
  66bb3f:	20 c2                	and    %al,%dl
  66bb41:	89 54 24 5c          	mov    %edx,0x5c(%rsp)
  66bb45:	48 39 8c 24 a8 00 00 	cmp    %rcx,0xa8(%rsp)
  66bb4c:	00 
  66bb4d:	b9 00 00 00 00       	mov    $0x0,%ecx
  66bb52:	48 8d 84 24 40 01 00 	lea    0x140(%rsp),%rax
  66bb59:	00 
  66bb5a:	48 0f 44 c8          	cmove  %rax,%rcx
  66bb5e:	f6 44 24 0f 01       	testb  $0x1,0xf(%rsp)
  66bb63:	b8 00 00 00 00       	mov    $0x0,%eax
  66bb68:	48 0f 44 c8          	cmove  %rax,%rcx
  66bb6c:	48 89 4c 24 40       	mov    %rcx,0x40(%rsp)
  66bb71:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  66bb78:	0f 1f 84 00 00 00 00 
  66bb7f:	00 
  66bb80:	48 8b 84 24 d8 01 00 	mov    0x1d8(%rsp),%rax
  66bb87:	00 
  66bb88:	48 83 f8 02          	cmp    $0x2,%rax
  66bb8c:	75 22                	jne    66bbb0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1210>
  66bb8e:	48 8d bc 24 e8 01 00 	lea    0x1e8(%rsp),%rdi
  66bb95:	00 
  66bb96:	e8 95 e3 00 00       	call   679f30 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  66bb9b:	49 89 d4             	mov    %rdx,%r12
  66bb9e:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
  66bba5:	00 
  66bba6:	48 89 94 24 e0 01 00 	mov    %rdx,0x1e0(%rsp)
  66bbad:	00 
  66bbae:	eb 08                	jmp    66bbb8 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1218>
  66bbb0:	4c 8b a4 24 e0 01 00 	mov    0x1e0(%rsp),%r12
  66bbb7:	00 
  66bbb8:	b9 01 00 00 00       	mov    $0x1,%ecx
  66bbbd:	48 83 f8 01          	cmp    $0x1,%rax
  66bbc1:	0f 85 29 02 00 00    	jne    66bdf0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1450>
  66bbc7:	4c 3b 64 24 48       	cmp    0x48(%rsp),%r12
  66bbcc:	0f 83 1e 02 00 00    	jae    66bdf0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1450>
  66bbd2:	4d 39 fc             	cmp    %r15,%r12
  66bbd5:	0f 82 fd 06 00 00    	jb     66c2d8 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1938>
  66bbdb:	48 c7 84 24 d8 01 00 	movq   $0x2,0x1d8(%rsp)
  66bbe2:	00 02 00 00 00 
  66bbe7:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  66bbec:	49 39 d4             	cmp    %rdx,%r12
  66bbef:	0f 85 30 01 00 00    	jne    66bd25 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1385>
  66bbf5:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
  66bbfa:	4c 8d 84 24 28 01 00 	lea    0x128(%rsp),%r8
  66bc01:	00 
  66bc02:	80 7c 24 5c 00       	cmpb   $0x0,0x5c(%rsp)
  66bc07:	0f 84 53 01 00 00    	je     66bd60 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x13c0>
  66bc0d:	49 8b 46 58          	mov    0x58(%r14),%rax
  66bc11:	4c 39 e8             	cmp    %r13,%rax
  66bc14:	0f 86 d4 0b 00 00    	jbe    66c7ee <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1e4e>
  66bc1a:	49 8b 56 70          	mov    0x70(%r14),%rdx
  66bc1e:	48 8b bc 24 90 00 00 	mov    0x90(%rsp),%rdi
  66bc25:	00 
  66bc26:	48 8b b4 24 18 01 00 	mov    0x118(%rsp),%rsi
  66bc2d:	00 
  66bc2e:	39 fe                	cmp    %edi,%esi
  66bc30:	0f 82 71 0b 00 00    	jb     66c7a7 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1e07>
  66bc36:	48 39 f2             	cmp    %rsi,%rdx
  66bc39:	0f 82 68 0b 00 00    	jb     66c7a7 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1e07>
  66bc3f:	39 fe                	cmp    %edi,%esi
  66bc41:	0f 84 65 0c 00 00    	je     66c8ac <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f0c>
  66bc47:	49 8b 46 68          	mov    0x68(%r14),%rax
  66bc4b:	48 8d 0c 7f          	lea    (%rdi,%rdi,2),%rcx
  66bc4f:	80 7c 88 07 06       	cmpb   $0x6,0x7(%rax,%rcx,4)
  66bc54:	48 8b 94 24 b0 00 00 	mov    0xb0(%rsp),%rdx
  66bc5b:	00 
  66bc5c:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
  66bc61:	0f 84 f9 00 00 00    	je     66bd60 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x13c0>
  66bc67:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  66bc6c:	f3 0f 10 40 40       	movss  0x40(%rax),%xmm0
  66bc71:	f3 0f 10 48 44       	movss  0x44(%rax),%xmm1
  66bc76:	0f 28 d0             	movaps %xmm0,%xmm2
  66bc79:	f3 0f 5d 50 48       	minss  0x48(%rax),%xmm2
  66bc7e:	0f 28 da             	movaps %xmm2,%xmm3
  66bc81:	f3 0f c2 da 03       	cmpunordss %xmm2,%xmm3
  66bc86:	0f 28 e3             	movaps %xmm3,%xmm4
  66bc89:	0f 55 e2             	andnps %xmm2,%xmm4
  66bc8c:	0f 54 d8             	andps  %xmm0,%xmm3
  66bc8f:	0f 56 dc             	orps   %xmm4,%xmm3
  66bc92:	0f 57 c0             	xorps  %xmm0,%xmm0
  66bc95:	f3 0f 5a c3          	cvtss2sd %xmm3,%xmm0
  66bc99:	0f 28 d1             	movaps %xmm1,%xmm2
  66bc9c:	f3 0f 5f 50 4c       	maxss  0x4c(%rax),%xmm2
  66bca1:	0f 28 da             	movaps %xmm2,%xmm3
  66bca4:	f3 0f c2 da 03       	cmpunordss %xmm2,%xmm3
  66bca9:	0f 28 e3             	movaps %xmm3,%xmm4
  66bcac:	0f 55 e2             	andnps %xmm2,%xmm4
  66bcaf:	0f 54 d9             	andps  %xmm1,%xmm3
  66bcb2:	0f 56 dc             	orps   %xmm4,%xmm3
  66bcb5:	0f 57 c9             	xorps  %xmm1,%xmm1
  66bcb8:	f3 0f 5a cb          	cvtss2sd %xmm3,%xmm1
  66bcbc:	f2 0f 10 94 24 88 00 	movsd  0x88(%rsp),%xmm2
  66bcc3:	00 00 
  66bcc5:	f2 0f 11 94 24 58 01 	movsd  %xmm2,0x158(%rsp)
  66bccc:	00 00 
  66bcce:	f2 0f 11 84 24 60 01 	movsd  %xmm0,0x160(%rsp)
  66bcd5:	00 00 
  66bcd7:	f2 0f 10 9c 24 80 00 	movsd  0x80(%rsp),%xmm3
  66bcde:	00 00 
  66bce0:	f2 0f 11 9c 24 68 01 	movsd  %xmm3,0x168(%rsp)
  66bce7:	00 00 
  66bce9:	f2 0f 11 8c 24 70 01 	movsd  %xmm1,0x170(%rsp)
  66bcf0:	00 00 
  66bcf2:	f2 0f 11 94 24 78 01 	movsd  %xmm2,0x178(%rsp)
  66bcf9:	00 00 
  66bcfb:	f2 0f 11 84 24 80 01 	movsd  %xmm0,0x180(%rsp)
  66bd02:	00 00 
  66bd04:	f2 0f 11 9c 24 88 01 	movsd  %xmm3,0x188(%rsp)
  66bd0b:	00 00 
  66bd0d:	f2 0f 11 8c 24 90 01 	movsd  %xmm1,0x190(%rsp)
  66bd14:	00 00 
  66bd16:	b8 01 00 00 00       	mov    $0x1,%eax
  66bd1b:	48 89 84 24 50 01 00 	mov    %rax,0x150(%rsp)
  66bd22:	00 
  66bd23:	eb 54                	jmp    66bd79 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x13d9>
  66bd25:	76 0c                	jbe    66bd33 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1393>
  66bd27:	31 c0                	xor    %eax,%eax
  66bd29:	48 89 84 24 50 01 00 	mov    %rax,0x150(%rsp)
  66bd30:	00 
  66bd31:	eb 46                	jmp    66bd79 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x13d9>
  66bd33:	4c 39 a4 24 a8 00 00 	cmp    %r12,0xa8(%rsp)
  66bd3a:	00 
  66bd3b:	b9 00 00 00 00       	mov    $0x0,%ecx
  66bd40:	48 8d 84 24 40 01 00 	lea    0x140(%rsp),%rax
  66bd47:	00 
  66bd48:	48 0f 44 c8          	cmove  %rax,%rcx
  66bd4c:	f6 44 24 0f 01       	testb  $0x1,0xf(%rsp)
  66bd51:	b8 00 00 00 00       	mov    $0x0,%eax
  66bd56:	48 0f 44 c8          	cmove  %rax,%rcx
  66bd5a:	4c 89 e2             	mov    %r12,%rdx
  66bd5d:	45 31 c0             	xor    %r8d,%r8d
  66bd60:	48 8d bc 24 50 01 00 	lea    0x150(%rsp),%rdi
  66bd67:	00 
  66bd68:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  66bd6d:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
  66bd73:	ff 15 bf e8 11 00    	call   *0x11e8bf(%rip)        # 78a638 <_DYNAMIC+0x3f0>
  66bd79:	4c 89 a4 24 80 02 00 	mov    %r12,0x280(%rsp)
  66bd80:	00 
  66bd81:	48 8b 84 24 90 01 00 	mov    0x190(%rsp),%rax
  66bd88:	00 
  66bd89:	48 8d 94 24 88 02 00 	lea    0x288(%rsp),%rdx
  66bd90:	00 
  66bd91:	48 89 42 40          	mov    %rax,0x40(%rdx)
  66bd95:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
  66bd9c:	00 
  66bd9d:	48 8b 8c 24 58 01 00 	mov    0x158(%rsp),%rcx
  66bda4:	00 
  66bda5:	0f 10 84 24 60 01 00 	movups 0x160(%rsp),%xmm0
  66bdac:	00 
  66bdad:	0f 10 8c 24 70 01 00 	movups 0x170(%rsp),%xmm1
  66bdb4:	00 
  66bdb5:	0f 10 94 24 80 01 00 	movups 0x180(%rsp),%xmm2
  66bdbc:	00 
  66bdbd:	0f 11 52 30          	movups %xmm2,0x30(%rdx)
  66bdc1:	0f 11 4a 20          	movups %xmm1,0x20(%rdx)
  66bdc5:	0f 11 42 10          	movups %xmm0,0x10(%rdx)
  66bdc9:	48 89 02             	mov    %rax,(%rdx)
  66bdcc:	48 89 4a 08          	mov    %rcx,0x8(%rdx)
  66bdd0:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
  66bdd5:	4c 89 e6             	mov    %r12,%rsi
  66bdd8:	e8 53 22 00 00       	call   66e030 <gpui_canvas::text::planner::append_carets::{closure#1}>
  66bddd:	89 c3                	mov    %eax,%ebx
  66bddf:	4d 89 e7             	mov    %r12,%r15
  66bde2:	83 f8 ff             	cmp    $0xffffffff,%eax
  66bde5:	0f 84 95 fd ff ff    	je     66bb80 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x11e0>
  66bdeb:	e9 42 06 00 00       	jmp    66c432 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a92>
  66bdf0:	4c 89 bc 24 80 00 00 	mov    %r15,0x80(%rsp)
  66bdf7:	00 
  66bdf8:	49 8b 46 58          	mov    0x58(%r14),%rax
  66bdfc:	4c 39 e8             	cmp    %r13,%rax
  66bdff:	0f 86 e9 09 00 00    	jbe    66c7ee <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1e4e>
  66be05:	49 8b 56 70          	mov    0x70(%r14),%rdx
  66be09:	48 8b bc 24 90 00 00 	mov    0x90(%rsp),%rdi
  66be10:	00 
  66be11:	48 8b b4 24 18 01 00 	mov    0x118(%rsp),%rsi
  66be18:	00 
  66be19:	39 fe                	cmp    %edi,%esi
  66be1b:	0f 82 86 09 00 00    	jb     66c7a7 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1e07>
  66be21:	48 39 f2             	cmp    %rsi,%rdx
  66be24:	0f 82 7d 09 00 00    	jb     66c7a7 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1e07>
  66be2a:	48 89 8c 24 88 00 00 	mov    %rcx,0x88(%rsp)
  66be31:	00 
  66be32:	39 fe                	cmp    %edi,%esi
  66be34:	0f 84 72 0a 00 00    	je     66c8ac <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f0c>
  66be3a:	49 8b 46 68          	mov    0x68(%r14),%rax
  66be3e:	48 8d 0c 7f          	lea    (%rdi,%rdi,2),%rcx
  66be42:	80 7c 88 07 06       	cmpb   $0x6,0x7(%rax,%rcx,4)
  66be47:	0f 95 c0             	setne  %al
  66be4a:	89 44 24 5c          	mov    %eax,0x5c(%rsp)
  66be4e:	0f 10 84 24 28 01 00 	movups 0x128(%rsp),%xmm0
  66be55:	00 
  66be56:	48 8d 84 24 40 01 00 	lea    0x140(%rsp),%rax
  66be5d:	00 
  66be5e:	0f 11 00             	movups %xmm0,(%rax)
  66be61:	c7 84 24 3c 01 00 00 	movl   $0x1,0x13c(%rsp)
  66be68:	01 00 00 00 
  66be6c:	c6 44 24 0f 01       	movb   $0x1,0xf(%rsp)
  66be71:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
  66be76:	48 89 8c 24 a8 00 00 	mov    %rcx,0xa8(%rsp)
  66be7d:	00 
  66be7e:	f3 0f 10 44 24 78    	movss  0x78(%rsp),%xmm0
  66be84:	f3 0f 11 84 24 90 00 	movss  %xmm0,0x90(%rsp)
  66be8b:	00 00 
  66be8d:	48 89 8c 24 b0 00 00 	mov    %rcx,0xb0(%rsp)
  66be94:	00 
  66be95:	4c 8d b4 24 b8 03 00 	lea    0x3b8(%rsp),%r14
  66be9c:	00 
  66be9d:	4c 8d ac 24 80 02 00 	lea    0x280(%rsp),%r13
  66bea4:	00 
  66bea5:	e9 4a f5 ff ff       	jmp    66b3f4 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xa54>
  66beaa:	4c 8b 6c 24 28       	mov    0x28(%rsp),%r13
  66beaf:	4c 8b 94 24 98 03 00 	mov    0x398(%rsp),%r10
  66beb6:	00 
  66beb7:	e9 ae f3 ff ff       	jmp    66b26a <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x8ca>
  66bebc:	48 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%rax
  66bec3:	00 
  66bec4:	48 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%rcx
  66becb:	00 
  66becc:	48 8b 94 24 b8 01 00 	mov    0x1b8(%rsp),%rdx
  66bed3:	00 
  66bed4:	48 8b b4 24 c0 01 00 	mov    0x1c0(%rsp),%rsi
  66bedb:	00 
  66bedc:	8b bc 24 c8 01 00 00 	mov    0x1c8(%rsp),%edi
  66bee3:	89 bc 24 d0 03 00 00 	mov    %edi,0x3d0(%rsp)
  66beea:	8b bc 24 cc 01 00 00 	mov    0x1cc(%rsp),%edi
  66bef1:	89 bc 24 d4 03 00 00 	mov    %edi,0x3d4(%rsp)
  66bef8:	8b bc 24 d0 01 00 00 	mov    0x1d0(%rsp),%edi
  66beff:	89 bc 24 d8 03 00 00 	mov    %edi,0x3d8(%rsp)
  66bf06:	8b bc 24 d4 01 00 00 	mov    0x1d4(%rsp),%edi
  66bf0d:	89 bc 24 dc 03 00 00 	mov    %edi,0x3dc(%rsp)
  66bf14:	48 89 94 24 c0 03 00 	mov    %rdx,0x3c0(%rsp)
  66bf1b:	00 
  66bf1c:	48 89 b4 24 c8 03 00 	mov    %rsi,0x3c8(%rsp)
  66bf23:	00 
  66bf24:	48 89 84 24 b0 03 00 	mov    %rax,0x3b0(%rsp)
  66bf2b:	00 
  66bf2c:	48 89 8c 24 b8 03 00 	mov    %rcx,0x3b8(%rsp)
  66bf33:	00 
  66bf34:	48 8d bc 24 e8 05 00 	lea    0x5e8(%rsp),%rdi
  66bf3b:	00 
  66bf3c:	48 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%rsi
  66bf43:	00 
  66bf44:	ba 01 00 00 00       	mov    $0x1,%edx
  66bf49:	e8 f2 ba ff ff       	call   667a40 <<parley::layout::run::Clusters<()>>::new>
  66bf4e:	4c 8d ac 24 80 02 00 	lea    0x280(%rsp),%r13
  66bf55:	00 
  66bf56:	ba 10 01 00 00       	mov    $0x110,%edx
  66bf5b:	48 8d bc 24 b0 03 00 	lea    0x3b0(%rsp),%rdi
  66bf62:	00 
  66bf63:	48 8d b4 24 e8 05 00 	lea    0x5e8(%rsp),%rsi
  66bf6a:	00 
  66bf6b:	ff 15 a7 e5 11 00    	call   *0x11e5a7(%rip)        # 78a518 <memcpy@GLIBC_2.14>
  66bf71:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  66bf78:	0f 1f 84 00 00 00 00 
  66bf7f:	00 
  66bf80:	48 8d bc 24 d0 04 00 	lea    0x4d0(%rsp),%rdi
  66bf87:	00 
  66bf88:	48 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%rsi
  66bf8f:	00 
  66bf90:	e8 0b e3 ff ff       	call   66a2a0 <<parley::layout::run::Clusters<()> as core::iter::traits::iterator::Iterator>::next>
  66bf95:	48 83 bc 24 d0 04 00 	cmpq   $0x0,0x4d0(%rsp)
  66bf9c:	00 00 
  66bf9e:	0f 84 f5 f3 ff ff    	je     66b399 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x9f9>
  66bfa4:	ba 90 00 00 00       	mov    $0x90,%edx
  66bfa9:	4c 89 ef             	mov    %r13,%rdi
  66bfac:	48 8d b4 24 d0 04 00 	lea    0x4d0(%rsp),%rsi
  66bfb3:	00 
  66bfb4:	ff 15 5e e5 11 00    	call   *0x11e55e(%rip)        # 78a518 <memcpy@GLIBC_2.14>
  66bfba:	48 8b 9c 24 e8 00 00 	mov    0xe8(%rsp),%rbx
  66bfc1:	00 
  66bfc2:	48 3b 9c 24 d8 00 00 	cmp    0xd8(%rsp),%rbx
  66bfc9:	00 
  66bfca:	75 0e                	jne    66bfda <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x163a>
  66bfcc:	48 8d bc 24 d8 00 00 	lea    0xd8(%rsp),%rdi
  66bfd3:	00 
  66bfd4:	ff 15 2e e8 11 00    	call   *0x11e82e(%rip)        # 78a808 <_DYNAMIC+0x5c0>
  66bfda:	48 8b 84 24 e0 00 00 	mov    0xe0(%rsp),%rax
  66bfe1:	00 
  66bfe2:	f3 0f 10 44 24 38    	movss  0x38(%rsp),%xmm0
  66bfe8:	f3 0f 11 04 98       	movss  %xmm0,(%rax,%rbx,4)
  66bfed:	48 ff c3             	inc    %rbx
  66bff0:	48 89 9c 24 e8 00 00 	mov    %rbx,0xe8(%rsp)
  66bff7:	00 
  66bff8:	48 83 bc 24 98 02 00 	cmpq   $0x0,0x298(%rsp)
  66bfff:	00 00 
  66c001:	74 3f                	je     66c042 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x16a2>
  66c003:	48 8b 84 24 80 02 00 	mov    0x280(%rsp),%rax
  66c00a:	00 
  66c00b:	44 8b ac 24 a0 02 00 	mov    0x2a0(%rsp),%r13d
  66c012:	00 
  66c013:	48 8b 88 18 01 00 00 	mov    0x118(%rax),%rcx
  66c01a:	4c 39 e9             	cmp    %r13,%rcx
  66c01d:	0f 86 63 08 00 00    	jbe    66c886 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ee6>
  66c023:	48 8b 80 10 01 00 00 	mov    0x110(%rax),%rax
  66c02a:	49 6b cd 70          	imul   $0x70,%r13,%rcx
  66c02e:	f3 0f 10 44 08 50    	movss  0x50(%rax,%rcx,1),%xmm0
  66c034:	8b 44 08 54          	mov    0x54(%rax,%rcx,1),%eax
  66c038:	4c 8d ac 24 80 02 00 	lea    0x280(%rsp),%r13
  66c03f:	00 
  66c040:	eb 08                	jmp    66c04a <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x16aa>
  66c042:	0f 57 c0             	xorps  %xmm0,%xmm0
  66c045:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  66c04a:	48 8b 8c 24 88 02 00 	mov    0x288(%rsp),%rcx
  66c051:	00 
  66c052:	48 8b 94 24 90 02 00 	mov    0x290(%rsp),%rdx
  66c059:	00 
  66c05a:	f2 0f 10 4a 44       	movsd  0x44(%rdx),%xmm1
  66c05f:	f2 0f 11 8c 24 60 05 	movsd  %xmm1,0x560(%rsp)
  66c066:	00 00 
  66c068:	f3 0f 11 84 24 68 05 	movss  %xmm0,0x568(%rsp)
  66c06f:	00 00 
  66c071:	89 84 24 6c 05 00 00 	mov    %eax,0x56c(%rsp)
  66c078:	0f b6 89 8c 00 00 00 	movzbl 0x8c(%rcx),%ecx
  66c07f:	83 e1 01             	and    $0x1,%ecx
  66c082:	48 8d bc 24 60 05 00 	lea    0x560(%rsp),%rdi
  66c089:	00 
  66c08a:	4c 89 fe             	mov    %r15,%rsi
  66c08d:	4c 89 e2             	mov    %r12,%rdx
  66c090:	ff 15 d2 e6 11 00    	call   *0x11e6d2(%rip)        # 78a768 <_DYNAMIC+0x520>
  66c096:	f3 0f 10 4c 24 38    	movss  0x38(%rsp),%xmm1
  66c09c:	f3 0f 58 c8          	addss  %xmm0,%xmm1
  66c0a0:	f3 0f 11 4c 24 38    	movss  %xmm1,0x38(%rsp)
  66c0a6:	e9 d5 fe ff ff       	jmp    66bf80 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x15e0>
  66c0ab:	48 8b 84 24 b0 03 00 	mov    0x3b0(%rsp),%rax
  66c0b2:	00 
  66c0b3:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  66c0b8:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  66c0bd:	f3 0f 10 48 28       	movss  0x28(%rax),%xmm1
  66c0c2:	48 c1 e7 03          	shl    $0x3,%rdi
  66c0c6:	48 8d 04 bf          	lea    (%rdi,%rdi,4),%rax
  66c0ca:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
  66c0d1:	00 
  66c0d2:	4c 8d 3c 01          	lea    (%rcx,%rax,1),%r15
  66c0d6:	48 c1 e6 03          	shl    $0x3,%rsi
  66c0da:	4c 8d 24 b6          	lea    (%rsi,%rsi,4),%r12
  66c0de:	49 29 c4             	sub    %rax,%r12
  66c0e1:	45 31 f6             	xor    %r14d,%r14d
  66c0e4:	eb 1f                	jmp    66c105 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1765>
  66c0e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  66c0ed:	00 00 00 
  66c0f0:	49 83 c7 28          	add    $0x28,%r15
  66c0f4:	f3 0f 58 c8          	addss  %xmm0,%xmm1
  66c0f8:	49 ff c6             	inc    %r14
  66c0fb:	49 83 c4 d8          	add    $0xffffffffffffffd8,%r12
  66c0ff:	0f 84 3b f1 ff ff    	je     66b240 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x8a0>
  66c105:	4d 8b 6f 10          	mov    0x10(%r15),%r13
  66c109:	41 80 7f 21 01       	cmpb   $0x1,0x21(%r15)
  66c10e:	75 30                	jne    66c140 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x17a0>
  66c110:	4c 3b ac 24 c0 00 00 	cmp    0xc0(%rsp),%r13
  66c117:	00 
  66c118:	0f 83 09 07 00 00    	jae    66c827 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1e87>
  66c11e:	49 6b c5 38          	imul   $0x38,%r13,%rax
  66c122:	48 8b 8c 24 a8 03 00 	mov    0x3a8(%rsp),%rcx
  66c129:	00 
  66c12a:	f3 0f 10 44 01 24    	movss  0x24(%rcx,%rax,1),%xmm0
  66c130:	4c 8b 6c 24 28       	mov    0x28(%rsp),%r13
  66c135:	eb b9                	jmp    66c0f0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1750>
  66c137:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  66c13e:	00 00 
  66c140:	4c 3b ac 24 b8 00 00 	cmp    0xb8(%rsp),%r13
  66c147:	00 
  66c148:	0f 83 ef 06 00 00    	jae    66c83d <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1e9d>
  66c14e:	4c 3b ac 24 a0 01 00 	cmp    0x1a0(%rsp),%r13
  66c155:	00 
  66c156:	0f 83 f7 06 00 00    	jae    66c853 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1eb3>
  66c15c:	4a 8d 04 ed 00 00 00 	lea    0x0(,%r13,8),%rax
  66c163:	00 
  66c164:	4c 01 e8             	add    %r13,%rax
  66c167:	48 c1 e0 04          	shl    $0x4,%rax
  66c16b:	48 03 84 24 c8 00 00 	add    0xc8(%rsp),%rax
  66c172:	00 
  66c173:	4a 8d 0c ad 00 00 00 	lea    0x0(,%r13,4),%rcx
  66c17a:	00 
  66c17b:	4c 01 e9             	add    %r13,%rcx
  66c17e:	48 c1 e1 04          	shl    $0x4,%rcx
  66c182:	48 03 8c 24 d0 00 00 	add    0xd0(%rsp),%rcx
  66c189:	00 
  66c18a:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
  66c18f:	48 89 94 24 b0 03 00 	mov    %rdx,0x3b0(%rsp)
  66c196:	00 
  66c197:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
  66c19e:	00 
  66c19f:	48 89 8c 24 c0 03 00 	mov    %rcx,0x3c0(%rsp)
  66c1a6:	00 
  66c1a7:	4c 89 bc 24 c8 03 00 	mov    %r15,0x3c8(%rsp)
  66c1ae:	00 
  66c1af:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  66c1b4:	89 84 24 d0 03 00 00 	mov    %eax,0x3d0(%rsp)
  66c1bb:	44 89 b4 24 d4 03 00 	mov    %r14d,0x3d4(%rsp)
  66c1c2:	00 
  66c1c3:	44 89 ac 24 d8 03 00 	mov    %r13d,0x3d8(%rsp)
  66c1ca:	00 
  66c1cb:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  66c1d0:	4c 8b 68 10          	mov    0x10(%rax),%r13
  66c1d4:	4d 01 f5             	add    %r14,%r13
  66c1d7:	4c 3b 6c 24 10       	cmp    0x10(%rsp),%r13
  66c1dc:	0f 83 87 06 00 00    	jae    66c869 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ec9>
  66c1e2:	4a 8d 04 ad 00 00 00 	lea    0x0(,%r13,4),%rax
  66c1e9:	00 
  66c1ea:	4c 01 e8             	add    %r13,%rax
  66c1ed:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
  66c1f4:	00 
  66c1f5:	4c 8b 6c c1 10       	mov    0x10(%rcx,%rax,8),%r13
  66c1fa:	4c 2b 6c 24 48       	sub    0x48(%rsp),%r13
  66c1ff:	49 39 dd             	cmp    %rbx,%r13
  66c202:	0f 83 11 06 00 00    	jae    66c819 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1e79>
  66c208:	f3 0f 11 4c 24 38    	movss  %xmm1,0x38(%rsp)
  66c20e:	f3 42 0f 11 4c ed 04 	movss  %xmm1,0x4(%rbp,%r13,8)
  66c215:	48 8d bc 24 b0 03 00 	lea    0x3b0(%rsp),%rdi
  66c21c:	00 
  66c21d:	e8 5e b3 ff ff       	call   667580 <<parley::layout::run::Run<()>>::advance>
  66c222:	4c 8b 6c 24 28       	mov    0x28(%rsp),%r13
  66c227:	f3 0f 10 4c 24 38    	movss  0x38(%rsp),%xmm1
  66c22d:	e9 be fe ff ff       	jmp    66c0f0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1750>
  66c232:	4c 8d b4 24 b8 03 00 	lea    0x3b8(%rsp),%r14
  66c239:	00 
  66c23a:	31 db                	xor    %ebx,%ebx
  66c23c:	48 8d bc 24 e8 01 00 	lea    0x1e8(%rsp),%rdi
  66c243:	00 
  66c244:	e8 e7 dc 00 00       	call   679f30 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  66c249:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
  66c250:	00 
  66c251:	48 89 94 24 e0 01 00 	mov    %rdx,0x1e0(%rsp)
  66c258:	00 
  66c259:	48 83 f8 01          	cmp    $0x1,%rax
  66c25d:	0f 85 bd 04 00 00    	jne    66c720 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1d80>
  66c263:	4d 89 f5             	mov    %r14,%r13
  66c266:	4c 8b b4 24 e0 01 00 	mov    0x1e0(%rsp),%r14
  66c26d:	00 
  66c26e:	4c 3b b4 24 80 00 00 	cmp    0x80(%rsp),%r14
  66c275:	00 
  66c276:	0f 92 c0             	setb   %al
  66c279:	84 c3                	test   %al,%bl
  66c27b:	0f 84 26 01 00 00    	je     66c3a7 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a07>
  66c281:	48 8d 9c 24 b0 03 00 	lea    0x3b0(%rsp),%rbx
  66c288:	00 
  66c289:	48 8d b4 24 d8 01 00 	lea    0x1d8(%rsp),%rsi
  66c290:	00 
  66c291:	ba a8 00 00 00       	mov    $0xa8,%edx
  66c296:	48 89 df             	mov    %rbx,%rdi
  66c299:	ff 15 79 e2 11 00    	call   *0x11e279(%rip)        # 78a518 <memcpy@GLIBC_2.14>
  66c29f:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
  66c2a4:	48 89 de             	mov    %rbx,%rsi
  66c2a7:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
  66c2ad:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
  66c2b2:	e8 39 09 00 00       	call   66cbf0 <parley::editing::geometry::visit_direct::<(), gpui_canvas::Error, core::iter::adapters::peekable::Peekable<icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>>, gpui_canvas::text::planner::append_carets::{closure#1}>>
  66c2b7:	eb 55                	jmp    66c30e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x196e>
  66c2b9:	45 31 ff             	xor    %r15d,%r15d
  66c2bc:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
  66c2c1:	48 89 ee             	mov    %rbp,%rsi
  66c2c4:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
  66c2ca:	48 89 da             	mov    %rbx,%rdx
  66c2cd:	e8 4e 0b 00 00       	call   66ce20 <parley::editing::geometry::visit_indexed::<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>>
  66c2d2:	89 c3                	mov    %eax,%ebx
  66c2d4:	31 ff                	xor    %edi,%edi
  66c2d6:	eb 70                	jmp    66c348 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19a8>
  66c2d8:	48 8d 9c 24 80 02 00 	lea    0x280(%rsp),%rbx
  66c2df:	00 
  66c2e0:	48 8d b4 24 d8 01 00 	lea    0x1d8(%rsp),%rsi
  66c2e7:	00 
  66c2e8:	ba a8 00 00 00       	mov    $0xa8,%edx
  66c2ed:	48 89 df             	mov    %rbx,%rdi
  66c2f0:	ff 15 22 e2 11 00    	call   *0x11e222(%rip)        # 78a518 <memcpy@GLIBC_2.14>
  66c2f6:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
  66c2fb:	48 89 de             	mov    %rbx,%rsi
  66c2fe:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
  66c304:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
  66c309:	e8 e2 08 00 00       	call   66cbf0 <parley::editing::geometry::visit_direct::<(), gpui_canvas::Error, core::iter::adapters::peekable::Peekable<icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>>, gpui_canvas::text::planner::append_carets::{closure#1}>>
  66c30e:	89 c3                	mov    %eax,%ebx
  66c310:	e9 34 04 00 00       	jmp    66c749 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1da9>
  66c315:	45 31 ff             	xor    %r15d,%r15d
  66c318:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
  66c31d:	48 8b 6c 24 20       	mov    0x20(%rsp),%rbp
  66c322:	48 89 ee             	mov    %rbp,%rsi
  66c325:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
  66c32b:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
  66c330:	e8 eb 0a 00 00       	call   66ce20 <parley::editing::geometry::visit_indexed::<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>>
  66c335:	89 c3                	mov    %eax,%ebx
  66c337:	31 ff                	xor    %edi,%edi
  66c339:	eb 08                	jmp    66c343 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19a3>
  66c33b:	bb fe ff ff ff       	mov    $0xfffffffe,%ebx
  66c340:	40 b7 01             	mov    $0x1,%dil
  66c343:	48 8b 6c 24 20       	mov    0x20(%rsp),%rbp
  66c348:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
  66c34f:	00 
  66c350:	48 85 f6             	test   %rsi,%rsi
  66c353:	74 1d                	je     66c372 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19d2>
  66c355:	41 89 fe             	mov    %edi,%r14d
  66c358:	48 8b bc 24 08 01 00 	mov    0x108(%rsp),%rdi
  66c35f:	00 
  66c360:	48 c1 e6 03          	shl    $0x3,%rsi
  66c364:	ba 04 00 00 00       	mov    $0x4,%edx
  66c369:	ff 15 11 e1 11 00    	call   *0x11e111(%rip)        # 78a480 <_DYNAMIC+0x238>
  66c36f:	44 89 f7             	mov    %r14d,%edi
  66c372:	40 84 ff             	test   %dil,%dil
  66c375:	74 1c                	je     66c393 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19f3>
  66c377:	48 8b 75 00          	mov    0x0(%rbp),%rsi
  66c37b:	48 85 f6             	test   %rsi,%rsi
  66c37e:	74 13                	je     66c393 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19f3>
  66c380:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
  66c384:	48 c1 e6 03          	shl    $0x3,%rsi
  66c388:	ba 08 00 00 00       	mov    $0x8,%edx
  66c38d:	ff 15 ed e0 11 00    	call   *0x11e0ed(%rip)        # 78a480 <_DYNAMIC+0x238>
  66c393:	89 d8                	mov    %ebx,%eax
  66c395:	48 81 c4 08 08 00 00 	add    $0x808,%rsp
  66c39c:	5b                   	pop    %rbx
  66c39d:	41 5c                	pop    %r12
  66c39f:	41 5d                	pop    %r13
  66c3a1:	41 5e                	pop    %r14
  66c3a3:	41 5f                	pop    %r15
  66c3a5:	5d                   	pop    %rbp
  66c3a6:	c3                   	ret
  66c3a7:	48 c7 84 24 d8 01 00 	movq   $0x2,0x1d8(%rsp)
  66c3ae:	00 02 00 00 00 
  66c3b3:	48 8d bc 24 80 02 00 	lea    0x280(%rsp),%rdi
  66c3ba:	00 
  66c3bb:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  66c3c0:	4c 89 f2             	mov    %r14,%rdx
  66c3c3:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
  66c3c9:	31 c9                	xor    %ecx,%ecx
  66c3cb:	45 31 c0             	xor    %r8d,%r8d
  66c3ce:	ff 15 64 e2 11 00    	call   *0x11e264(%rip)        # 78a638 <_DYNAMIC+0x3f0>
  66c3d4:	4c 89 ea             	mov    %r13,%rdx
  66c3d7:	4c 89 b4 24 b0 03 00 	mov    %r14,0x3b0(%rsp)
  66c3de:	00 
  66c3df:	48 8b 84 24 c0 02 00 	mov    0x2c0(%rsp),%rax
  66c3e6:	00 
  66c3e7:	48 89 42 40          	mov    %rax,0x40(%rdx)
  66c3eb:	0f 10 84 24 80 02 00 	movups 0x280(%rsp),%xmm0
  66c3f2:	00 
  66c3f3:	0f 10 8c 24 90 02 00 	movups 0x290(%rsp),%xmm1
  66c3fa:	00 
  66c3fb:	0f 10 94 24 a0 02 00 	movups 0x2a0(%rsp),%xmm2
  66c402:	00 
  66c403:	0f 10 9c 24 b0 02 00 	movups 0x2b0(%rsp),%xmm3
  66c40a:	00 
  66c40b:	0f 11 5a 30          	movups %xmm3,0x30(%rdx)
  66c40f:	0f 11 52 20          	movups %xmm2,0x20(%rdx)
  66c413:	0f 11 4a 10          	movups %xmm1,0x10(%rdx)
  66c417:	0f 11 02             	movups %xmm0,(%rdx)
  66c41a:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
  66c41f:	4c 89 f6             	mov    %r14,%rsi
  66c422:	e8 09 1c 00 00       	call   66e030 <gpui_canvas::text::planner::append_carets::{closure#1}>
  66c427:	89 c3                	mov    %eax,%ebx
  66c429:	83 f8 ff             	cmp    $0xffffffff,%eax
  66c42c:	0f 84 0d 02 00 00    	je     66c63f <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1c9f>
  66c432:	48 8b b4 24 e8 01 00 	mov    0x1e8(%rsp),%rsi
  66c439:	00 
  66c43a:	e9 ee 02 00 00       	jmp    66c72d <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1d8d>
  66c43f:	8b 8c 24 3c 01 00 00 	mov    0x13c(%rsp),%ecx
  66c446:	48 8b 84 24 d8 01 00 	mov    0x1d8(%rsp),%rax
  66c44d:	00 
  66c44e:	f6 c1 01             	test   $0x1,%cl
  66c451:	0f 84 3d 03 00 00    	je     66c794 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1df4>
  66c457:	83 f8 02             	cmp    $0x2,%eax
  66c45a:	48 8b 6c 24 20       	mov    0x20(%rsp),%rbp
  66c45f:	75 1d                	jne    66c47e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ade>
  66c461:	48 8d bc 24 e8 01 00 	lea    0x1e8(%rsp),%rdi
  66c468:	00 
  66c469:	e8 c2 da 00 00       	call   679f30 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  66c46e:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
  66c475:	00 
  66c476:	48 89 94 24 e0 01 00 	mov    %rdx,0x1e0(%rsp)
  66c47d:	00 
  66c47e:	48 83 f8 01          	cmp    $0x1,%rax
  66c482:	0f 85 98 02 00 00    	jne    66c720 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1d80>
  66c488:	4c 8b b4 24 e0 01 00 	mov    0x1e0(%rsp),%r14
  66c48f:	00 
  66c490:	4c 3b b4 24 80 00 00 	cmp    0x80(%rsp),%r14
  66c497:	00 
  66c498:	0f 92 c0             	setb   %al
  66c49b:	84 c3                	test   %al,%bl
  66c49d:	0f 85 de fd ff ff    	jne    66c281 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18e1>
  66c4a3:	48 c7 84 24 d8 01 00 	movq   $0x2,0x1d8(%rsp)
  66c4aa:	00 02 00 00 00 
  66c4af:	31 c9                	xor    %ecx,%ecx
  66c4b1:	4c 39 b4 24 a8 00 00 	cmp    %r14,0xa8(%rsp)
  66c4b8:	00 
  66c4b9:	48 8d 84 24 40 01 00 	lea    0x140(%rsp),%rax
  66c4c0:	00 
  66c4c1:	48 0f 44 c8          	cmove  %rax,%rcx
  66c4c5:	48 8d bc 24 80 02 00 	lea    0x280(%rsp),%rdi
  66c4cc:	00 
  66c4cd:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  66c4d2:	4c 89 f2             	mov    %r14,%rdx
  66c4d5:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
  66c4db:	45 31 c0             	xor    %r8d,%r8d
  66c4de:	ff 15 54 e1 11 00    	call   *0x11e154(%rip)        # 78a638 <_DYNAMIC+0x3f0>
  66c4e4:	48 8d 94 24 b8 03 00 	lea    0x3b8(%rsp),%rdx
  66c4eb:	00 
  66c4ec:	4c 89 b4 24 b0 03 00 	mov    %r14,0x3b0(%rsp)
  66c4f3:	00 
  66c4f4:	48 8b 84 24 c0 02 00 	mov    0x2c0(%rsp),%rax
  66c4fb:	00 
  66c4fc:	48 89 42 40          	mov    %rax,0x40(%rdx)
  66c500:	0f 10 84 24 80 02 00 	movups 0x280(%rsp),%xmm0
  66c507:	00 
  66c508:	0f 10 8c 24 90 02 00 	movups 0x290(%rsp),%xmm1
  66c50f:	00 
  66c510:	0f 10 94 24 a0 02 00 	movups 0x2a0(%rsp),%xmm2
  66c517:	00 
  66c518:	0f 10 9c 24 b0 02 00 	movups 0x2b0(%rsp),%xmm3
  66c51f:	00 
  66c520:	0f 11 5a 30          	movups %xmm3,0x30(%rdx)
  66c524:	0f 11 52 20          	movups %xmm2,0x20(%rdx)
  66c528:	0f 11 4a 10          	movups %xmm1,0x10(%rdx)
  66c52c:	0f 11 02             	movups %xmm0,(%rdx)
  66c52f:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
  66c534:	4c 89 f6             	mov    %r14,%rsi
  66c537:	e8 f4 1a 00 00       	call   66e030 <gpui_canvas::text::planner::append_carets::{closure#1}>
  66c53c:	89 c3                	mov    %eax,%ebx
  66c53e:	83 f8 ff             	cmp    $0xffffffff,%eax
  66c541:	0f 85 eb fe ff ff    	jne    66c432 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a92>
  66c547:	4c 8d bc 24 80 02 00 	lea    0x280(%rsp),%r15
  66c54e:	00 
  66c54f:	48 8b 84 24 d8 01 00 	mov    0x1d8(%rsp),%rax
  66c556:	00 
  66c557:	48 83 f8 02          	cmp    $0x2,%rax
  66c55b:	75 1d                	jne    66c57a <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1bda>
  66c55d:	48 8d bc 24 e8 01 00 	lea    0x1e8(%rsp),%rdi
  66c564:	00 
  66c565:	e8 c6 d9 00 00       	call   679f30 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  66c56a:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
  66c571:	00 
  66c572:	48 89 94 24 e0 01 00 	mov    %rdx,0x1e0(%rsp)
  66c579:	00 
  66c57a:	48 83 f8 01          	cmp    $0x1,%rax
  66c57e:	0f 85 9c 01 00 00    	jne    66c720 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1d80>
  66c584:	4c 8b a4 24 e0 01 00 	mov    0x1e0(%rsp),%r12
  66c58b:	00 
  66c58c:	4d 39 f4             	cmp    %r14,%r12
  66c58f:	0f 82 ec fc ff ff    	jb     66c281 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18e1>
  66c595:	48 c7 84 24 d8 01 00 	movq   $0x2,0x1d8(%rsp)
  66c59c:	00 02 00 00 00 
  66c5a1:	4c 39 a4 24 a8 00 00 	cmp    %r12,0xa8(%rsp)
  66c5a8:	00 
  66c5a9:	b9 00 00 00 00       	mov    $0x0,%ecx
  66c5ae:	48 8d 84 24 40 01 00 	lea    0x140(%rsp),%rax
  66c5b5:	00 
  66c5b6:	48 0f 44 c8          	cmove  %rax,%rcx
  66c5ba:	4c 89 ff             	mov    %r15,%rdi
  66c5bd:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  66c5c2:	4c 89 e2             	mov    %r12,%rdx
  66c5c5:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
  66c5cb:	45 31 c0             	xor    %r8d,%r8d
  66c5ce:	ff 15 64 e0 11 00    	call   *0x11e064(%rip)        # 78a638 <_DYNAMIC+0x3f0>
  66c5d4:	4c 89 a4 24 b0 03 00 	mov    %r12,0x3b0(%rsp)
  66c5db:	00 
  66c5dc:	48 8b 84 24 c0 02 00 	mov    0x2c0(%rsp),%rax
  66c5e3:	00 
  66c5e4:	48 8d 94 24 b8 03 00 	lea    0x3b8(%rsp),%rdx
  66c5eb:	00 
  66c5ec:	48 89 42 40          	mov    %rax,0x40(%rdx)
  66c5f0:	0f 10 84 24 80 02 00 	movups 0x280(%rsp),%xmm0
  66c5f7:	00 
  66c5f8:	0f 10 8c 24 90 02 00 	movups 0x290(%rsp),%xmm1
  66c5ff:	00 
  66c600:	0f 10 94 24 a0 02 00 	movups 0x2a0(%rsp),%xmm2
  66c607:	00 
  66c608:	0f 10 9c 24 b0 02 00 	movups 0x2b0(%rsp),%xmm3
  66c60f:	00 
  66c610:	0f 11 5a 30          	movups %xmm3,0x30(%rdx)
  66c614:	0f 11 52 20          	movups %xmm2,0x20(%rdx)
  66c618:	0f 11 4a 10          	movups %xmm1,0x10(%rdx)
  66c61c:	0f 11 02             	movups %xmm0,(%rdx)
  66c61f:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
  66c624:	4c 89 e6             	mov    %r12,%rsi
  66c627:	e8 04 1a 00 00       	call   66e030 <gpui_canvas::text::planner::append_carets::{closure#1}>
  66c62c:	89 c3                	mov    %eax,%ebx
  66c62e:	4d 89 e6             	mov    %r12,%r14
  66c631:	83 f8 ff             	cmp    $0xffffffff,%eax
  66c634:	0f 84 15 ff ff ff    	je     66c54f <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1baf>
  66c63a:	e9 f3 fd ff ff       	jmp    66c432 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a92>
  66c63f:	4c 8d bc 24 80 02 00 	lea    0x280(%rsp),%r15
  66c646:	00 
  66c647:	48 8b 84 24 d8 01 00 	mov    0x1d8(%rsp),%rax
  66c64e:	00 
  66c64f:	48 83 f8 02          	cmp    $0x2,%rax
  66c653:	75 1d                	jne    66c672 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1cd2>
  66c655:	48 8d bc 24 e8 01 00 	lea    0x1e8(%rsp),%rdi
  66c65c:	00 
  66c65d:	e8 ce d8 00 00       	call   679f30 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  66c662:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
  66c669:	00 
  66c66a:	48 89 94 24 e0 01 00 	mov    %rdx,0x1e0(%rsp)
  66c671:	00 
  66c672:	48 83 f8 01          	cmp    $0x1,%rax
  66c676:	0f 85 a4 00 00 00    	jne    66c720 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1d80>
  66c67c:	4c 8b a4 24 e0 01 00 	mov    0x1e0(%rsp),%r12
  66c683:	00 
  66c684:	4d 39 f4             	cmp    %r14,%r12
  66c687:	0f 82 f4 fb ff ff    	jb     66c281 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18e1>
  66c68d:	48 c7 84 24 d8 01 00 	movq   $0x2,0x1d8(%rsp)
  66c694:	00 02 00 00 00 
  66c699:	4c 89 ff             	mov    %r15,%rdi
  66c69c:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  66c6a1:	4c 89 e2             	mov    %r12,%rdx
  66c6a4:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
  66c6aa:	31 c9                	xor    %ecx,%ecx
  66c6ac:	45 31 c0             	xor    %r8d,%r8d
  66c6af:	ff 15 83 df 11 00    	call   *0x11df83(%rip)        # 78a638 <_DYNAMIC+0x3f0>
  66c6b5:	4c 89 a4 24 b0 03 00 	mov    %r12,0x3b0(%rsp)
  66c6bc:	00 
  66c6bd:	48 8b 84 24 c0 02 00 	mov    0x2c0(%rsp),%rax
  66c6c4:	00 
  66c6c5:	4c 89 ea             	mov    %r13,%rdx
  66c6c8:	49 89 45 40          	mov    %rax,0x40(%r13)
  66c6cc:	0f 10 84 24 80 02 00 	movups 0x280(%rsp),%xmm0
  66c6d3:	00 
  66c6d4:	0f 10 8c 24 90 02 00 	movups 0x290(%rsp),%xmm1
  66c6db:	00 
  66c6dc:	0f 10 94 24 a0 02 00 	movups 0x2a0(%rsp),%xmm2
  66c6e3:	00 
  66c6e4:	0f 10 9c 24 b0 02 00 	movups 0x2b0(%rsp),%xmm3
  66c6eb:	00 
  66c6ec:	41 0f 11 5d 30       	movups %xmm3,0x30(%r13)
  66c6f1:	41 0f 11 55 20       	movups %xmm2,0x20(%r13)
  66c6f6:	41 0f 11 4d 10       	movups %xmm1,0x10(%r13)
  66c6fb:	41 0f 11 45 00       	movups %xmm0,0x0(%r13)
  66c700:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
  66c705:	4c 89 e6             	mov    %r12,%rsi
  66c708:	e8 23 19 00 00       	call   66e030 <gpui_canvas::text::planner::append_carets::{closure#1}>
  66c70d:	89 c3                	mov    %eax,%ebx
  66c70f:	4d 89 e6             	mov    %r12,%r14
  66c712:	83 f8 ff             	cmp    $0xffffffff,%eax
  66c715:	0f 84 2c ff ff ff    	je     66c647 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ca7>
  66c71b:	e9 12 fd ff ff       	jmp    66c432 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a92>
  66c720:	48 8b b4 24 e8 01 00 	mov    0x1e8(%rsp),%rsi
  66c727:	00 
  66c728:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
  66c72d:	48 85 f6             	test   %rsi,%rsi
  66c730:	74 17                	je     66c749 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1da9>
  66c732:	48 8b bc 24 f0 01 00 	mov    0x1f0(%rsp),%rdi
  66c739:	00 
  66c73a:	48 c1 e6 03          	shl    $0x3,%rsi
  66c73e:	ba 08 00 00 00       	mov    $0x8,%edx
  66c743:	ff 15 37 dd 11 00    	call   *0x11dd37(%rip)        # 78a480 <_DYNAMIC+0x238>
  66c749:	48 8b b4 24 d8 00 00 	mov    0xd8(%rsp),%rsi
  66c750:	00 
  66c751:	48 85 f6             	test   %rsi,%rsi
  66c754:	74 17                	je     66c76d <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1dcd>
  66c756:	48 8b bc 24 e0 00 00 	mov    0xe0(%rsp),%rdi
  66c75d:	00 
  66c75e:	48 c1 e6 02          	shl    $0x2,%rsi
  66c762:	ba 04 00 00 00       	mov    $0x4,%edx
  66c767:	ff 15 13 dd 11 00    	call   *0x11dd13(%rip)        # 78a480 <_DYNAMIC+0x238>
  66c76d:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
  66c774:	00 
  66c775:	48 85 f6             	test   %rsi,%rsi
  66c778:	0f 84 15 fc ff ff    	je     66c393 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19f3>
  66c77e:	48 8b bc 24 08 01 00 	mov    0x108(%rsp),%rdi
  66c785:	00 
  66c786:	48 c1 e6 03          	shl    $0x3,%rsi
  66c78a:	ba 04 00 00 00       	mov    $0x4,%edx
  66c78f:	e9 f9 fb ff ff       	jmp    66c38d <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19ed>
  66c794:	83 f8 02             	cmp    $0x2,%eax
  66c797:	48 8b 6c 24 20       	mov    0x20(%rsp),%rbp
  66c79c:	0f 84 9a fa ff ff    	je     66c23c <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x189c>
  66c7a2:	e9 b2 fa ff ff       	jmp    66c259 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18b9>
  66c7a7:	48 8d 0d 5a 39 11 00 	lea    0x11395a(%rip),%rcx        # 780108 <anon.89d2c5d0d416cd03e9cb3036fced70ec.23.llvm.1506394962952114297>
  66c7ae:	ff 15 74 df 11 00    	call   *0x11df74(%rip)        # 78a728 <_DYNAMIC+0x4e0>
  66c7b4:	e9 31 01 00 00       	jmp    66c8ea <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f4a>
  66c7b9:	48 8d 0d 68 41 11 00 	lea    0x114168(%rip),%rcx        # 780928 <anon.e03b8aad59caf4fdbca6396e1e2d1ccc.19.llvm.4670190096578414633>
  66c7c0:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  66c7c5:	ff 15 5d df 11 00    	call   *0x11df5d(%rip)        # 78a728 <_DYNAMIC+0x4e0>
  66c7cb:	e9 1a 01 00 00       	jmp    66c8ea <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f4a>
  66c7d0:	48 8d 3d 41 96 9b ff 	lea    -0x6469bf(%rip),%rdi        # 25e18 <anon.9fcffffb41e17e3581a91abe69cbbd86.17.llvm.6872408754362722203+0x16b>
  66c7d7:	48 8d 15 3a 38 11 00 	lea    0x11383a(%rip),%rdx        # 780018 <anon.1a71af429ce32665251a25071ff44b21.68.llvm.16581668395387327457+0xa8>
  66c7de:	be 21 00 00 00       	mov    $0x21,%esi
  66c7e3:	ff 15 77 df 11 00    	call   *0x11df77(%rip)        # 78a760 <_DYNAMIC+0x518>
  66c7e9:	e9 fc 00 00 00       	jmp    66c8ea <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f4a>
  66c7ee:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  66c7f3:	48 8d 05 56 39 11 00 	lea    0x113956(%rip),%rax        # 780150 <anon.89d2c5d0d416cd03e9cb3036fced70ec.28.llvm.1506394962952114297>
  66c7fa:	e9 93 00 00 00       	jmp    66c892 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ef2>
  66c7ff:	41 b7 01             	mov    $0x1,%r15b
  66c802:	48 8d 15 47 39 11 00 	lea    0x113947(%rip),%rdx        # 780150 <anon.89d2c5d0d416cd03e9cb3036fced70ec.28.llvm.1506394962952114297>
  66c809:	48 8b 6c 24 20       	mov    0x20(%rsp),%rbp
  66c80e:	ff 15 94 dd 11 00    	call   *0x11dd94(%rip)        # 78a5a8 <_DYNAMIC+0x360>
  66c814:	e9 d1 00 00 00       	jmp    66c8ea <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f4a>
  66c819:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
  66c81e:	48 8d 05 6b 38 11 00 	lea    0x11386b(%rip),%rax        # 780090 <anon.1a71af429ce32665251a25071ff44b21.68.llvm.16581668395387327457+0x120>
  66c825:	eb 6b                	jmp    66c892 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ef2>
  66c827:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
  66c82e:	00 
  66c82f:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  66c834:	48 8d 05 9d 38 11 00 	lea    0x11389d(%rip),%rax        # 7800d8 <anon.1a71af429ce32665251a25071ff44b21.68.llvm.16581668395387327457+0x168>
  66c83b:	eb 55                	jmp    66c892 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ef2>
  66c83d:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  66c844:	00 
  66c845:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  66c84a:	48 8d 05 57 38 11 00 	lea    0x113857(%rip),%rax        # 7800a8 <anon.1a71af429ce32665251a25071ff44b21.68.llvm.16581668395387327457+0x138>
  66c851:	eb 3f                	jmp    66c892 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ef2>
  66c853:	48 8b 84 24 a0 01 00 	mov    0x1a0(%rsp),%rax
  66c85a:	00 
  66c85b:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  66c860:	48 8d 05 59 38 11 00 	lea    0x113859(%rip),%rax        # 7800c0 <anon.1a71af429ce32665251a25071ff44b21.68.llvm.16581668395387327457+0x150>
  66c867:	eb 29                	jmp    66c892 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ef2>
  66c869:	48 8d 05 08 38 11 00 	lea    0x113808(%rip),%rax        # 780078 <anon.1a71af429ce32665251a25071ff44b21.68.llvm.16581668395387327457+0x108>
  66c870:	eb 20                	jmp    66c892 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ef2>
  66c872:	4d 89 fd             	mov    %r15,%r13
  66c875:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  66c87a:	48 8d 05 c7 37 11 00 	lea    0x1137c7(%rip),%rax        # 780048 <anon.1a71af429ce32665251a25071ff44b21.68.llvm.16581668395387327457+0xd8>
  66c881:	eb 0f                	jmp    66c892 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ef2>
  66c883:	49 89 c5             	mov    %rax,%r13
  66c886:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  66c88b:	48 8d 05 a6 38 11 00 	lea    0x1138a6(%rip),%rax        # 780138 <anon.89d2c5d0d416cd03e9cb3036fced70ec.26.llvm.1506394962952114297>
  66c892:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  66c897:	4c 89 ef             	mov    %r13,%rdi
  66c89a:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  66c89f:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
  66c8a4:	ff 15 fe dc 11 00    	call   *0x11dcfe(%rip)        # 78a5a8 <_DYNAMIC+0x360>
  66c8aa:	eb 3e                	jmp    66c8ea <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f4a>
  66c8ac:	45 31 ed             	xor    %r13d,%r13d
  66c8af:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  66c8b6:	00 00 
  66c8b8:	eb dd                	jmp    66c897 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ef7>
  66c8ba:	48 3b 8c 24 c0 00 00 	cmp    0xc0(%rsp),%rcx
  66c8c1:	00 
  66c8c2:	48 8d 05 97 37 11 00 	lea    0x113797(%rip),%rax        # 780060 <anon.1a71af429ce32665251a25071ff44b21.68.llvm.16581668395387327457+0xf0>
  66c8c9:	48 8d 0d 60 37 11 00 	lea    0x113760(%rip),%rcx        # 780030 <anon.1a71af429ce32665251a25071ff44b21.68.llvm.16581668395387327457+0xc0>
  66c8d0:	48 0f 42 c8          	cmovb  %rax,%rcx
  66c8d4:	48 89 8c 24 98 01 00 	mov    %rcx,0x198(%rsp)
  66c8db:	00 
  66c8dc:	48 8b bc 24 98 01 00 	mov    0x198(%rsp),%rdi
  66c8e3:	00 
  66c8e4:	ff 15 96 dc 11 00    	call   *0x11dc96(%rip)        # 78a580 <_DYNAMIC+0x338>
  66c8ea:	0f 0b                	ud2
  66c8ec:	48 89 c3             	mov    %rax,%rbx
  66c8ef:	eb 50                	jmp    66c941 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1fa1>
  66c8f1:	48 89 c3             	mov    %rax,%rbx
  66c8f4:	eb 4b                	jmp    66c941 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1fa1>
  66c8f6:	48 89 c3             	mov    %rax,%rbx
  66c8f9:	48 8b 6c 24 20       	mov    0x20(%rsp),%rbp
  66c8fe:	eb 65                	jmp    66c965 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1fc5>
  66c900:	48 89 c3             	mov    %rax,%rbx
  66c903:	eb 3c                	jmp    66c941 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1fa1>
  66c905:	48 89 c3             	mov    %rax,%rbx
  66c908:	eb 37                	jmp    66c941 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1fa1>
  66c90a:	eb 2d                	jmp    66c939 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f99>
  66c90c:	eb 2b                	jmp    66c939 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f99>
  66c90e:	eb 08                	jmp    66c918 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f78>
  66c910:	eb 27                	jmp    66c939 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f99>
  66c912:	eb 04                	jmp    66c918 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f78>
  66c914:	eb 14                	jmp    66c92a <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f8a>
  66c916:	eb 21                	jmp    66c939 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f99>
  66c918:	48 89 c3             	mov    %rax,%rbx
  66c91b:	41 b7 01             	mov    $0x1,%r15b
  66c91e:	eb 76                	jmp    66c996 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ff6>
  66c920:	eb 17                	jmp    66c939 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f99>
  66c922:	eb 15                	jmp    66c939 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f99>
  66c924:	eb 04                	jmp    66c92a <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f8a>
  66c926:	eb 11                	jmp    66c939 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f99>
  66c928:	eb 0f                	jmp    66c939 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f99>
  66c92a:	48 89 c3             	mov    %rax,%rbx
  66c92d:	41 b7 01             	mov    $0x1,%r15b
  66c930:	48 8b 6c 24 20       	mov    0x20(%rsp),%rbp
  66c935:	eb 5f                	jmp    66c996 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ff6>
  66c937:	eb 00                	jmp    66c939 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f99>
  66c939:	48 89 c3             	mov    %rax,%rbx
  66c93c:	48 8b 6c 24 20       	mov    0x20(%rsp),%rbp
  66c941:	48 8b b4 24 e8 01 00 	mov    0x1e8(%rsp),%rsi
  66c948:	00 
  66c949:	48 85 f6             	test   %rsi,%rsi
  66c94c:	74 17                	je     66c965 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1fc5>
  66c94e:	48 8b bc 24 f0 01 00 	mov    0x1f0(%rsp),%rdi
  66c955:	00 
  66c956:	48 c1 e6 03          	shl    $0x3,%rsi
  66c95a:	ba 08 00 00 00       	mov    $0x8,%edx
  66c95f:	ff 15 1b db 11 00    	call   *0x11db1b(%rip)        # 78a480 <_DYNAMIC+0x238>
  66c965:	48 8b b4 24 d8 00 00 	mov    0xd8(%rsp),%rsi
  66c96c:	00 
  66c96d:	48 85 f6             	test   %rsi,%rsi
  66c970:	75 05                	jne    66c977 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1fd7>
  66c972:	45 31 ff             	xor    %r15d,%r15d
  66c975:	eb 1f                	jmp    66c996 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ff6>
  66c977:	48 8b bc 24 e0 00 00 	mov    0xe0(%rsp),%rdi
  66c97e:	00 
  66c97f:	48 c1 e6 02          	shl    $0x2,%rsi
  66c983:	ba 04 00 00 00       	mov    $0x4,%edx
  66c988:	ff 15 f2 da 11 00    	call   *0x11daf2(%rip)        # 78a480 <_DYNAMIC+0x238>
  66c98e:	45 31 ff             	xor    %r15d,%r15d
  66c991:	eb 03                	jmp    66c996 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ff6>
  66c993:	48 89 c3             	mov    %rax,%rbx
  66c996:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
  66c99d:	00 
  66c99e:	48 85 f6             	test   %rsi,%rsi
  66c9a1:	74 17                	je     66c9ba <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x201a>
  66c9a3:	48 8b bc 24 08 01 00 	mov    0x108(%rsp),%rdi
  66c9aa:	00 
  66c9ab:	48 c1 e6 03          	shl    $0x3,%rsi
  66c9af:	ba 04 00 00 00       	mov    $0x4,%edx
  66c9b4:	ff 15 c6 da 11 00    	call   *0x11dac6(%rip)        # 78a480 <_DYNAMIC+0x238>
  66c9ba:	45 84 ff             	test   %r15b,%r15b
  66c9bd:	74 1c                	je     66c9db <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x203b>
  66c9bf:	48 8b 75 00          	mov    0x0(%rbp),%rsi
  66c9c3:	48 85 f6             	test   %rsi,%rsi
  66c9c6:	74 13                	je     66c9db <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x203b>
  66c9c8:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
  66c9cc:	48 c1 e6 03          	shl    $0x3,%rsi
  66c9d0:	ba 08 00 00 00       	mov    $0x8,%edx
  66c9d5:	ff 15 a5 da 11 00    	call   *0x11daa5(%rip)        # 78a480 <_DYNAMIC+0x238>
  66c9db:	48 89 df             	mov    %rbx,%rdi
  66c9de:	e8 dd 1a 11 00       	call   77e4c0 <_Unwind_Resume@plt>
