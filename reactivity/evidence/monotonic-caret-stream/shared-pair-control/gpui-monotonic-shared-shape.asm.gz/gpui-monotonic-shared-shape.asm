
/tmp/gpui-monotonic-control-bin/stream-shared:     file format elf64-x86-64


Disassembly of section .text:

0000000000684570 <<gpui_canvas::text::planner::Planner>::shape>:
  684570:	55                   	push   %rbp
  684571:	41 57                	push   %r15
  684573:	41 56                	push   %r14
  684575:	41 55                	push   %r13
  684577:	41 54                	push   %r12
  684579:	53                   	push   %rbx
  68457a:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
  684581:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
  684588:	00 
  684589:	48 81 ec e8 01 00 00 	sub    $0x1e8,%rsp
  684590:	44 89 8c 24 2c 02 00 	mov    %r9d,0x22c(%rsp)
  684597:	00 
  684598:	f3 0f 11 8c 24 cc 01 	movss  %xmm1,0x1cc(%rsp)
  68459f:	00 00 
  6845a1:	44 89 84 24 c8 01 00 	mov    %r8d,0x1c8(%rsp)
  6845a8:	00 
  6845a9:	f3 0f 11 84 24 84 00 	movss  %xmm0,0x84(%rsp)
  6845b0:	00 00 
  6845b2:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
  6845b7:	49 89 f5             	mov    %rsi,%r13
  6845ba:	48 89 bc 24 38 03 00 	mov    %rdi,0x338(%rsp)
  6845c1:	00 
  6845c2:	4c 8d 24 0a          	lea    (%rdx,%rcx,1),%r12
  6845c6:	48 85 c9             	test   %rcx,%rcx
  6845c9:	48 89 34 24          	mov    %rsi,(%rsp)
  6845cd:	48 89 94 24 48 01 00 	mov    %rdx,0x148(%rsp)
  6845d4:	00 
  6845d5:	4c 89 a4 24 b0 01 00 	mov    %r12,0x1b0(%rsp)
  6845dc:	00 
  6845dd:	0f 84 90 03 00 00    	je     684973 <<gpui_canvas::text::planner::Planner>::shape+0x403>
  6845e3:	49 8d 85 78 0a 00 00 	lea    0xa78(%r13),%rax
  6845ea:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  6845ef:	48 8d b4 24 ec 0c 00 	lea    0xcec(%rsp),%rsi
  6845f6:	00 
  6845f7:	49 8d 45 38          	lea    0x38(%r13),%rax
  6845fb:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  684600:	49 8d 45 3c          	lea    0x3c(%r13),%rax
  684604:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  68460b:	00 
  68460c:	49 8d 45 58          	lea    0x58(%r13),%rax
  684610:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
  684617:	00 
  684618:	49 8d 45 5c          	lea    0x5c(%r13),%rax
  68461c:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  684621:	45 31 ff             	xor    %r15d,%r15d
  684624:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  68462b:	00 
  68462c:	4c 8b 05 0d 65 10 00 	mov    0x10650d(%rip),%r8        # 78ab40 <_DYNAMIC+0x8f8>
  684633:	49 89 d6             	mov    %rdx,%r14
  684636:	44 89 7c 24 30       	mov    %r15d,0x30(%rsp)
  68463b:	eb 1c                	jmp    684659 <<gpui_canvas::text::planner::Planner>::shape+0xe9>
  68463d:	0f 1f 00             	nopl   (%rax)
  684640:	41 8d 87 d8 df ff ff 	lea    -0x2028(%r15),%eax
  684647:	83 f8 02             	cmp    $0x2,%eax
  68464a:	0f 83 e1 00 00 00    	jae    684731 <<gpui_canvas::text::planner::Planner>::shape+0x1c1>
  684650:	4d 39 e6             	cmp    %r12,%r14
  684653:	0f 84 ba 02 00 00    	je     684913 <<gpui_canvas::text::planner::Planner>::shape+0x3a3>
  684659:	45 0f b6 3e          	movzbl (%r14),%r15d
  68465d:	45 84 ff             	test   %r15b,%r15b
  684660:	78 1e                	js     684680 <<gpui_canvas::text::planner::Planner>::shape+0x110>
  684662:	49 ff c6             	inc    %r14
  684665:	41 81 ff 27 20 00 00 	cmp    $0x2027,%r15d
  68466c:	0f 8e 9e 00 00 00    	jle    684710 <<gpui_canvas::text::planner::Planner>::shape+0x1a0>
  684672:	eb cc                	jmp    684640 <<gpui_canvas::text::planner::Planner>::shape+0xd0>
  684674:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  68467b:	00 00 00 00 00 
  684680:	44 89 f8             	mov    %r15d,%eax
  684683:	83 e0 1f             	and    $0x1f,%eax
  684686:	41 0f b6 56 01       	movzbl 0x1(%r14),%edx
  68468b:	83 e2 3f             	and    $0x3f,%edx
  68468e:	41 80 ff df          	cmp    $0xdf,%r15b
  684692:	76 3d                	jbe    6846d1 <<gpui_canvas::text::planner::Planner>::shape+0x161>
  684694:	41 0f b6 4e 02       	movzbl 0x2(%r14),%ecx
  684699:	c1 e2 06             	shl    $0x6,%edx
  68469c:	83 e1 3f             	and    $0x3f,%ecx
  68469f:	09 d1                	or     %edx,%ecx
  6846a1:	41 80 ff f0          	cmp    $0xf0,%r15b
  6846a5:	72 44                	jb     6846eb <<gpui_canvas::text::planner::Planner>::shape+0x17b>
  6846a7:	45 0f b6 7e 03       	movzbl 0x3(%r14),%r15d
  6846ac:	49 83 c6 04          	add    $0x4,%r14
  6846b0:	83 e0 07             	and    $0x7,%eax
  6846b3:	c1 e0 12             	shl    $0x12,%eax
  6846b6:	c1 e1 06             	shl    $0x6,%ecx
  6846b9:	41 83 e7 3f          	and    $0x3f,%r15d
  6846bd:	41 09 cf             	or     %ecx,%r15d
  6846c0:	41 09 c7             	or     %eax,%r15d
  6846c3:	41 81 ff 27 20 00 00 	cmp    $0x2027,%r15d
  6846ca:	7e 44                	jle    684710 <<gpui_canvas::text::planner::Planner>::shape+0x1a0>
  6846cc:	e9 6f ff ff ff       	jmp    684640 <<gpui_canvas::text::planner::Planner>::shape+0xd0>
  6846d1:	49 83 c6 02          	add    $0x2,%r14
  6846d5:	c1 e0 06             	shl    $0x6,%eax
  6846d8:	09 d0                	or     %edx,%eax
  6846da:	41 89 c7             	mov    %eax,%r15d
  6846dd:	41 81 ff 27 20 00 00 	cmp    $0x2027,%r15d
  6846e4:	7e 2a                	jle    684710 <<gpui_canvas::text::planner::Planner>::shape+0x1a0>
  6846e6:	e9 55 ff ff ff       	jmp    684640 <<gpui_canvas::text::planner::Planner>::shape+0xd0>
  6846eb:	49 83 c6 03          	add    $0x3,%r14
  6846ef:	c1 e0 0c             	shl    $0xc,%eax
  6846f2:	09 c1                	or     %eax,%ecx
  6846f4:	41 89 cf             	mov    %ecx,%r15d
  6846f7:	41 81 ff 27 20 00 00 	cmp    $0x2027,%r15d
  6846fe:	0f 8f 3c ff ff ff    	jg     684640 <<gpui_canvas::text::planner::Planner>::shape+0xd0>
  684704:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  68470b:	00 00 00 00 00 
  684710:	41 83 ff 0a          	cmp    $0xa,%r15d
  684714:	0f 84 36 ff ff ff    	je     684650 <<gpui_canvas::text::planner::Planner>::shape+0xe0>
  68471a:	41 83 ff 0d          	cmp    $0xd,%r15d
  68471e:	0f 84 2c ff ff ff    	je     684650 <<gpui_canvas::text::planner::Planner>::shape+0xe0>
  684724:	41 81 ff 85 00 00 00 	cmp    $0x85,%r15d
  68472b:	0f 84 1f ff ff ff    	je     684650 <<gpui_canvas::text::planner::Planner>::shape+0xe0>
  684731:	49 89 fd             	mov    %rdi,%r13
  684734:	48 8d 3d 25 c3 0f 00 	lea    0xfc325(%rip),%rdi        # 780a60 <anon.e03b8aad59caf4fdbca6396e1e2d1ccc.19.llvm.4670190096578414633+0x138>
  68473b:	48 89 f3             	mov    %rsi,%rbx
  68473e:	44 89 fe             	mov    %r15d,%esi
  684741:	4c 89 c5             	mov    %r8,%rbp
  684744:	ff 15 66 64 10 00    	call   *0x106466(%rip)        # 78abb0 <_DYNAMIC+0x968>
  68474a:	49 89 e8             	mov    %rbp,%r8
  68474d:	4c 89 ef             	mov    %r13,%rdi
  684750:	48 89 de             	mov    %rbx,%rsi
  684753:	84 c0                	test   %al,%al
  684755:	0f 85 f5 fe ff ff    	jne    684650 <<gpui_canvas::text::planner::Planner>::shape+0xe0>
  68475b:	41 bc 0a 00 00 00    	mov    $0xa,%r12d
  684761:	41 83 ff 20          	cmp    $0x20,%r15d
  684765:	0f 82 5b 02 00 00    	jb     6849c6 <<gpui_canvas::text::planner::Planner>::shape+0x456>
  68476b:	41 8d 47 81          	lea    -0x7f(%r15),%eax
  68476f:	83 f8 21             	cmp    $0x21,%eax
  684772:	0f 82 4e 02 00 00    	jb     6849c6 <<gpui_canvas::text::planner::Planner>::shape+0x456>
  684778:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  68477d:	44 89 fe             	mov    %r15d,%esi
  684780:	e8 cb 3b 00 00       	call   688350 <<gpui_canvas::text::planner::Cmap>::glyph_index>
  684785:	49 89 e8             	mov    %rbp,%r8
  684788:	4c 89 ef             	mov    %r13,%rdi
  68478b:	a8 01                	test   $0x1,%al
  68478d:	4c 8b a4 24 b0 01 00 	mov    0x1b0(%rsp),%r12
  684794:	00 
  684795:	74 0c                	je     6847a3 <<gpui_canvas::text::planner::Planner>::shape+0x233>
  684797:	48 89 de             	mov    %rbx,%rsi
  68479a:	66 85 d2             	test   %dx,%dx
  68479d:	0f 85 ad fe ff ff    	jne    684650 <<gpui_canvas::text::planner::Planner>::shape+0xe0>
  6847a3:	48 8b 0c 24          	mov    (%rsp),%rcx
  6847a7:	48 8b 81 40 0a 00 00 	mov    0xa40(%rcx),%rax
  6847ae:	41 bc 0b 00 00 00    	mov    $0xb,%r12d
  6847b4:	80 78 38 01          	cmpb   $0x1,0x38(%rax)
  6847b8:	0f 85 08 02 00 00    	jne    6849c6 <<gpui_canvas::text::planner::Planner>::shape+0x456>
  6847be:	48 83 79 30 00       	cmpq   $0x0,0x30(%rcx)
  6847c3:	0f 85 e9 00 00 00    	jne    6848b2 <<gpui_canvas::text::planner::Planner>::shape+0x342>
  6847c9:	ba 48 ab 03 00       	mov    $0x3ab48,%edx
  6847ce:	48 8d 35 23 1b 9a ff 	lea    -0x65e4dd(%rip),%rsi        # 262f8 <gpui_canvas::text::ARABIC_BYTES>
  6847d5:	31 c9                	xor    %ecx,%ecx
  6847d7:	41 ff d0             	call   *%r8
  6847da:	83 bc 24 10 07 00 00 	cmpl   $0xffffffff,0x710(%rsp)
  6847e1:	ff 
  6847e2:	0f 84 8d 2f 00 00    	je     687775 <<gpui_canvas::text::planner::Planner>::shape+0x3205>
  6847e8:	8b 84 24 e8 0c 00 00 	mov    0xce8(%rsp),%eax
  6847ef:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6847f3:	0f 10 03             	movups (%rbx),%xmm0
  6847f6:	0f 10 4b 0c          	movups 0xc(%rbx),%xmm1
  6847fa:	0f 29 84 24 c0 04 00 	movaps %xmm0,0x4c0(%rsp)
  684801:	00 
  684802:	0f 11 8c 24 cc 04 00 	movups %xmm1,0x4cc(%rsp)
  684809:	00 
  68480a:	ba 14 69 00 00       	mov    $0x6914,%edx
  68480f:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  684816:	00 
  684817:	48 8d 35 22 c6 9d ff 	lea    -0x6239de(%rip),%rsi        # 60e40 <gpui_canvas::text::HEBREW_BYTES>
  68481e:	31 c9                	xor    %ecx,%ecx
  684820:	ff 15 1a 63 10 00    	call   *0x10631a(%rip)        # 78ab40 <_DYNAMIC+0x8f8>
  684826:	83 bc 24 10 07 00 00 	cmpl   $0xffffffff,0x710(%rsp)
  68482d:	ff 
  68482e:	0f 84 53 2f 00 00    	je     687787 <<gpui_canvas::text::planner::Planner>::shape+0x3217>
  684834:	8b 94 24 e8 0c 00 00 	mov    0xce8(%rsp),%edx
  68483b:	48 8d 84 24 ec 0c 00 	lea    0xcec(%rsp),%rax
  684842:	00 
  684843:	0f 10 00             	movups (%rax),%xmm0
  684846:	0f 10 48 0c          	movups 0xc(%rax),%xmm1
  68484a:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
  684851:	00 
  684852:	0f 11 8c 24 4c 03 00 	movups %xmm1,0x34c(%rsp)
  684859:	00 
  68485a:	48 8b 04 24          	mov    (%rsp),%rax
  68485e:	48 c7 40 30 01 00 00 	movq   $0x1,0x30(%rax)
  684865:	00 
  684866:	8b 4c 24 08          	mov    0x8(%rsp),%ecx
  68486a:	89 48 38             	mov    %ecx,0x38(%rax)
  68486d:	0f 10 84 24 cc 04 00 	movups 0x4cc(%rsp),%xmm0
  684874:	00 
  684875:	48 8b 8c 24 00 01 00 	mov    0x100(%rsp),%rcx
  68487c:	00 
  68487d:	0f 11 41 0c          	movups %xmm0,0xc(%rcx)
  684881:	0f 28 84 24 c0 04 00 	movaps 0x4c0(%rsp),%xmm0
  684888:	00 
  684889:	0f 11 01             	movups %xmm0,(%rcx)
  68488c:	89 94 24 d0 01 00 00 	mov    %edx,0x1d0(%rsp)
  684893:	89 50 58             	mov    %edx,0x58(%rax)
  684896:	0f 10 84 24 4c 03 00 	movups 0x34c(%rsp),%xmm0
  68489d:	00 
  68489e:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6848a3:	0f 11 40 0c          	movups %xmm0,0xc(%rax)
  6848a7:	0f 28 84 24 40 03 00 	movaps 0x340(%rsp),%xmm0
  6848ae:	00 
  6848af:	0f 11 00             	movups %xmm0,(%rax)
  6848b2:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
  6848b7:	44 89 fe             	mov    %r15d,%esi
  6848ba:	e8 91 3a 00 00       	call   688350 <<gpui_canvas::text::planner::Cmap>::glyph_index>
  6848bf:	66 85 d2             	test   %dx,%dx
  6848c2:	0f 95 c1             	setne  %cl
  6848c5:	20 c1                	and    %al,%cl
  6848c7:	88 4c 24 60          	mov    %cl,0x60(%rsp)
  6848cb:	48 8b bc 24 10 01 00 	mov    0x110(%rsp),%rdi
  6848d2:	00 
  6848d3:	44 89 fe             	mov    %r15d,%esi
  6848d6:	e8 75 3a 00 00       	call   688350 <<gpui_canvas::text::planner::Cmap>::glyph_index>
  6848db:	66 85 d2             	test   %dx,%dx
  6848de:	0f 95 c1             	setne  %cl
  6848e1:	20 c1                	and    %al,%cl
  6848e3:	00 c9                	add    %cl,%cl
  6848e5:	0a 4c 24 60          	or     0x60(%rsp),%cl
  6848e9:	0f 84 d7 00 00 00    	je     6849c6 <<gpui_canvas::text::planner::Planner>::shape+0x456>
  6848ef:	44 8b 7c 24 30       	mov    0x30(%rsp),%r15d
  6848f4:	41 08 cf             	or     %cl,%r15b
  6848f7:	4c 8b a4 24 b0 01 00 	mov    0x1b0(%rsp),%r12
  6848fe:	00 
  6848ff:	4d 39 e6             	cmp    %r12,%r14
  684902:	48 89 de             	mov    %rbx,%rsi
  684905:	4c 89 ef             	mov    %r13,%rdi
  684908:	49 89 e8             	mov    %rbp,%r8
  68490b:	0f 85 25 fd ff ff    	jne    684636 <<gpui_canvas::text::planner::Planner>::shape+0xc6>
  684911:	eb 05                	jmp    684918 <<gpui_canvas::text::planner::Planner>::shape+0x3a8>
  684913:	44 8b 7c 24 30       	mov    0x30(%rsp),%r15d
  684918:	41 f6 c7 01          	test   $0x1,%r15b
  68491c:	4c 8b 2c 24          	mov    (%rsp),%r13
  684920:	0f 84 c5 00 00 00    	je     6849eb <<gpui_canvas::text::planner::Planner>::shape+0x47b>
  684926:	49 83 bd 48 0a 00 00 	cmpq   $0x0,0xa48(%r13)
  68492d:	00 
  68492e:	0f 85 b7 00 00 00    	jne    6849eb <<gpui_canvas::text::planner::Planner>::shape+0x47b>
  684934:	48 8d 35 85 8b 10 00 	lea    0x108b85(%rip),%rsi        # 78d4c0 <gpui_canvas::text::ARABIC_FONT>
  68493b:	48 8d 15 b6 19 9a ff 	lea    -0x65e64a(%rip),%rdx        # 262f8 <gpui_canvas::text::ARABIC_BYTES>
  684942:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  684949:	00 
  68494a:	b9 48 ab 03 00       	mov    $0x3ab48,%ecx
  68494f:	45 31 c0             	xor    %r8d,%r8d
  684952:	e8 89 c1 ff ff       	call   680ae0 <<gpui_canvas::text::FontFace>::shared_static>
  684957:	83 bc 24 10 07 00 00 	cmpl   $0x1,0x710(%rsp)
  68495e:	01 
  68495f:	75 1a                	jne    68497b <<gpui_canvas::text::planner::Planner>::shape+0x40b>
  684961:	44 8b a4 24 14 07 00 	mov    0x714(%rsp),%r12d
  684968:	00 
  684969:	44 8b bc 24 18 07 00 	mov    0x718(%rsp),%r15d
  684970:	00 
  684971:	eb 53                	jmp    6849c6 <<gpui_canvas::text::planner::Planner>::shape+0x456>
  684973:	45 31 ff             	xor    %r15d,%r15d
  684976:	e9 84 00 00 00       	jmp    6849ff <<gpui_canvas::text::planner::Planner>::shape+0x48f>
  68497b:	44 89 fd             	mov    %r15d,%ebp
  68497e:	49 8d 9d 48 0a 00 00 	lea    0xa48(%r13),%rbx
  684985:	4c 8b bc 24 18 07 00 	mov    0x718(%rsp),%r15
  68498c:	00 
  68498d:	48 8b 03             	mov    (%rbx),%rax
  684990:	48 85 c0             	test   %rax,%rax
  684993:	74 0f                	je     6849a4 <<gpui_canvas::text::planner::Planner>::shape+0x434>
  684995:	f0 48 ff 08          	lock decq (%rax)
  684999:	75 09                	jne    6849a4 <<gpui_canvas::text::planner::Planner>::shape+0x434>
  68499b:	48 89 df             	mov    %rbx,%rdi
  68499e:	ff 15 04 5b 10 00    	call   *0x105b04(%rip)        # 78a4a8 <_DYNAMIC+0x260>
  6849a4:	4d 89 bd 48 0a 00 00 	mov    %r15,0xa48(%r13)
  6849ab:	be 01 00 00 00       	mov    $0x1,%esi
  6849b0:	4c 89 ef             	mov    %r13,%rdi
  6849b3:	e8 98 36 00 00       	call   688050 <<gpui_canvas::text::planner::Planner>::register>
  6849b8:	83 f8 ff             	cmp    $0xffffffff,%eax
  6849bb:	41 89 ef             	mov    %ebp,%r15d
  6849be:	74 2b                	je     6849eb <<gpui_canvas::text::planner::Planner>::shape+0x47b>
  6849c0:	41 89 c4             	mov    %eax,%r12d
  6849c3:	45 31 ff             	xor    %r15d,%r15d
  6849c6:	44 89 a4 24 90 00 00 	mov    %r12d,0x90(%rsp)
  6849cd:	00 
  6849ce:	44 89 bc 24 94 00 00 	mov    %r15d,0x94(%rsp)
  6849d5:	00 
  6849d6:	48 c7 84 24 88 00 00 	movq   $0xffffffffffffffff,0x88(%rsp)
  6849dd:	00 ff ff ff ff 
  6849e2:	4c 8b 2c 24          	mov    (%rsp),%r13
  6849e6:	e9 b6 28 00 00       	jmp    6872a1 <<gpui_canvas::text::planner::Planner>::shape+0x2d31>
  6849eb:	41 f6 c7 02          	test   $0x2,%r15b
  6849ef:	74 0e                	je     6849ff <<gpui_canvas::text::planner::Planner>::shape+0x48f>
  6849f1:	49 83 bd 50 0a 00 00 	cmpq   $0x0,0xa50(%r13)
  6849f8:	00 
  6849f9:	0f 84 3f 2a 00 00    	je     68743e <<gpui_canvas::text::planner::Planner>::shape+0x2ece>
  6849ff:	48 c7 84 24 a0 02 00 	movq   $0xffffffffffffffff,0x2a0(%rsp)
  684a06:	00 ff ff ff ff 
  684a0b:	48 8d 05 14 72 bd ff 	lea    -0x428dec(%rip),%rax        # 25bc26 <gpui_canvas::text::PRIMARY_BYTES+0x1f44d2>
  684a12:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
  684a19:	00 
  684a1a:	48 c7 84 24 b0 02 00 	movq   $0xc,0x2b0(%rsp)
  684a21:	00 0c 00 00 00 
  684a26:	48 c7 84 24 b8 02 00 	movq   $0xffffffffffffffff,0x2b8(%rsp)
  684a2d:	00 ff ff ff ff 
  684a32:	48 8d 05 f9 71 bd ff 	lea    -0x428e07(%rip),%rax        # 25bc32 <gpui_canvas::text::PRIMARY_BYTES+0x1f44de>
  684a39:	48 89 84 24 c0 02 00 	mov    %rax,0x2c0(%rsp)
  684a40:	00 
  684a41:	48 c7 84 24 c8 02 00 	movq   $0x11,0x2c8(%rsp)
  684a48:	00 11 00 00 00 
  684a4d:	48 c7 84 24 d0 02 00 	movq   $0xffffffffffffffff,0x2d0(%rsp)
  684a54:	00 ff ff ff ff 
  684a59:	48 8d 1d e3 71 bd ff 	lea    -0x428e1d(%rip),%rbx        # 25bc43 <gpui_canvas::text::PRIMARY_BYTES+0x1f44ef>
  684a60:	48 89 9c 24 d8 02 00 	mov    %rbx,0x2d8(%rsp)
  684a67:	00 
  684a68:	48 c7 84 24 e0 02 00 	movq   $0x11,0x2e0(%rsp)
  684a6f:	00 11 00 00 00 
  684a74:	41 f6 c7 01          	test   $0x1,%r15b
  684a78:	75 1d                	jne    684a97 <<gpui_canvas::text::planner::Planner>::shape+0x527>
  684a7a:	4c 8d b4 24 b8 02 00 	lea    0x2b8(%rsp),%r14
  684a81:	00 
  684a82:	b8 01 00 00 00       	mov    $0x1,%eax
  684a87:	48 89 84 24 10 02 00 	mov    %rax,0x210(%rsp)
  684a8e:	00 
  684a8f:	41 f6 c7 02          	test   $0x2,%r15b
  684a93:	75 25                	jne    684aba <<gpui_canvas::text::planner::Planner>::shape+0x54a>
  684a95:	eb 5b                	jmp    684af2 <<gpui_canvas::text::planner::Planner>::shape+0x582>
  684a97:	4c 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%r14
  684a9e:	00 
  684a9f:	48 89 84 24 c0 02 00 	mov    %rax,0x2c0(%rsp)
  684aa6:	00 
  684aa7:	b8 02 00 00 00       	mov    $0x2,%eax
  684aac:	48 89 84 24 10 02 00 	mov    %rax,0x210(%rsp)
  684ab3:	00 
  684ab4:	41 f6 c7 02          	test   $0x2,%r15b
  684ab8:	74 38                	je     684af2 <<gpui_canvas::text::planner::Planner>::shape+0x582>
  684aba:	49 8b 36             	mov    (%r14),%rsi
  684abd:	48 83 fe fd          	cmp    $0xfffffffffffffffd,%rsi
  684ac1:	77 14                	ja     684ad7 <<gpui_canvas::text::planner::Planner>::shape+0x567>
  684ac3:	48 85 f6             	test   %rsi,%rsi
  684ac6:	74 0f                	je     684ad7 <<gpui_canvas::text::planner::Planner>::shape+0x567>
  684ac8:	49 8b 7e 08          	mov    0x8(%r14),%rdi
  684acc:	ba 01 00 00 00       	mov    $0x1,%edx
  684ad1:	ff 15 a9 59 10 00    	call   *0x1059a9(%rip)        # 78a480 <_DYNAMIC+0x238>
  684ad7:	49 c7 06 ff ff ff ff 	movq   $0xffffffffffffffff,(%r14)
  684ade:	49 89 5e 08          	mov    %rbx,0x8(%r14)
  684ae2:	49 c7 46 10 11 00 00 	movq   $0x11,0x10(%r14)
  684ae9:	00 
  684aea:	48 ff 84 24 10 02 00 	incq   0x210(%rsp)
  684af1:	00 
  684af2:	48 c7 84 24 e8 00 00 	movq   $0x0,0xe8(%rsp)
  684af9:	00 00 00 00 00 
  684afe:	48 c7 84 24 f0 00 00 	movq   $0x4,0xf0(%rsp)
  684b05:	00 04 00 00 00 
  684b0a:	48 c7 84 24 f8 00 00 	movq   $0x0,0xf8(%rsp)
  684b11:	00 00 00 00 00 
  684b16:	48 c7 84 24 50 01 00 	movq   $0xffffffffffffffff,0x150(%rsp)
  684b1d:	00 ff ff ff ff 
  684b22:	f6 84 24 c8 01 00 00 	testb  $0x1,0x1c8(%rsp)
  684b29:	01 
  684b2a:	75 11                	jne    684b3d <<gpui_canvas::text::planner::Planner>::shape+0x5cd>
  684b2c:	f3 0f 10 05 18 8d 99 	movss  -0x6672e8(%rip),%xmm0        # 1d84c <GCC_except_table0+0x94>
  684b33:	ff 
  684b34:	f3 0f 11 84 24 cc 01 	movss  %xmm0,0x1cc(%rsp)
  684b3b:	00 00 
  684b3d:	49 8d 45 78          	lea    0x78(%r13),%rax
  684b41:	48 89 84 24 30 03 00 	mov    %rax,0x330(%rsp)
  684b48:	00 
  684b49:	49 8d 85 38 06 00 00 	lea    0x638(%r13),%rax
  684b50:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
  684b57:	00 
  684b58:	49 8d 85 c8 08 00 00 	lea    0x8c8(%r13),%rax
  684b5f:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  684b64:	4c 8d ac 24 50 03 00 	lea    0x350(%rsp),%r13
  684b6b:	00 
  684b6c:	0f 57 c0             	xorps  %xmm0,%xmm0
  684b6f:	0f 29 84 24 80 02 00 	movaps %xmm0,0x280(%rsp)
  684b76:	00 
  684b77:	f3 0f 11 44 24 1c    	movss  %xmm0,0x1c(%rsp)
  684b7d:	f3 0f 11 44 24 7c    	movss  %xmm0,0x7c(%rsp)
  684b83:	4c 8d a4 24 c8 04 00 	lea    0x4c8(%rsp),%r12
  684b8a:	00 
  684b8b:	48 8d 05 0e c0 0f 00 	lea    0xfc00e(%rip),%rax        # 780ba0 <anon.e03b8aad59caf4fdbca6396e1e2d1ccc.19.llvm.4670190096578414633+0x278>
  684b92:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  684b97:	48 8d 05 52 b5 0f 00 	lea    0xfb552(%rip),%rax        # 7800f0 <anon.89d2c5d0d416cd03e9cb3036fced70ec.21.llvm.1506394962952114297>
  684b9e:	48 89 84 24 70 02 00 	mov    %rax,0x270(%rsp)
  684ba5:	00 
  684ba6:	48 c7 84 24 08 02 00 	movq   $0x0,0x208(%rsp)
  684bad:	00 00 00 00 00 
  684bb2:	31 d2                	xor    %edx,%edx
  684bb4:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  684bbb:	00 
  684bbc:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  684bc1:	31 c0                	xor    %eax,%eax
  684bc3:	be fe ff ff ff       	mov    $0xfffffffe,%esi
  684bc8:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
  684bcd:	83 fe fe             	cmp    $0xfffffffe,%esi
  684bd0:	75 2e                	jne    684c00 <<gpui_canvas::text::planner::Planner>::shape+0x690>
  684bd2:	4c 8b 4c 24 28       	mov    0x28(%rsp),%r9
  684bd7:	4c 3b 8c 24 b0 01 00 	cmp    0x1b0(%rsp),%r9
  684bde:	00 
  684bdf:	74 33                	je     684c14 <<gpui_canvas::text::planner::Planner>::shape+0x6a4>
  684be1:	41 0f b6 09          	movzbl (%r9),%ecx
  684be5:	84 c9                	test   %cl,%cl
  684be7:	78 46                	js     684c2f <<gpui_canvas::text::planner::Planner>::shape+0x6bf>
  684be9:	49 8d 51 01          	lea    0x1(%r9),%rdx
  684bed:	e9 9a 00 00 00       	jmp    684c8c <<gpui_canvas::text::planner::Planner>::shape+0x71c>
  684bf2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  684bf9:	1f 84 00 00 00 00 00 
  684c00:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
  684c05:	89 f1                	mov    %esi,%ecx
  684c07:	4c 8b 84 24 10 03 00 	mov    0x310(%rsp),%r8
  684c0e:	00 
  684c0f:	e9 81 00 00 00       	jmp    684c95 <<gpui_canvas::text::planner::Planner>::shape+0x725>
  684c14:	c7 84 24 80 00 00 00 	movl   $0xfffffffe,0x80(%rsp)
  684c1b:	fe ff ff ff 
  684c1f:	b1 01                	mov    $0x1,%cl
  684c21:	89 4c 24 4c          	mov    %ecx,0x4c(%rsp)
  684c25:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
  684c2a:	e9 d7 01 00 00       	jmp    684e06 <<gpui_canvas::text::planner::Planner>::shape+0x896>
  684c2f:	49 89 c0             	mov    %rax,%r8
  684c32:	89 c8                	mov    %ecx,%eax
  684c34:	83 e0 1f             	and    $0x1f,%eax
  684c37:	41 0f b6 79 01       	movzbl 0x1(%r9),%edi
  684c3c:	83 e7 3f             	and    $0x3f,%edi
  684c3f:	80 f9 e0             	cmp    $0xe0,%cl
  684c42:	72 2d                	jb     684c71 <<gpui_canvas::text::planner::Planner>::shape+0x701>
  684c44:	41 0f b6 71 02       	movzbl 0x2(%r9),%esi
  684c49:	c1 e7 06             	shl    $0x6,%edi
  684c4c:	83 e6 3f             	and    $0x3f,%esi
  684c4f:	09 fe                	or     %edi,%esi
  684c51:	80 f9 f0             	cmp    $0xf0,%cl
  684c54:	72 28                	jb     684c7e <<gpui_canvas::text::planner::Planner>::shape+0x70e>
  684c56:	49 8d 51 04          	lea    0x4(%r9),%rdx
  684c5a:	41 0f b6 49 03       	movzbl 0x3(%r9),%ecx
  684c5f:	83 e0 07             	and    $0x7,%eax
  684c62:	c1 e0 12             	shl    $0x12,%eax
  684c65:	c1 e6 06             	shl    $0x6,%esi
  684c68:	83 e1 3f             	and    $0x3f,%ecx
  684c6b:	09 f1                	or     %esi,%ecx
  684c6d:	09 c1                	or     %eax,%ecx
  684c6f:	eb 18                	jmp    684c89 <<gpui_canvas::text::planner::Planner>::shape+0x719>
  684c71:	49 8d 51 02          	lea    0x2(%r9),%rdx
  684c75:	c1 e0 06             	shl    $0x6,%eax
  684c78:	09 f8                	or     %edi,%eax
  684c7a:	89 c1                	mov    %eax,%ecx
  684c7c:	eb 0b                	jmp    684c89 <<gpui_canvas::text::planner::Planner>::shape+0x719>
  684c7e:	49 8d 51 03          	lea    0x3(%r9),%rdx
  684c82:	c1 e0 0c             	shl    $0xc,%eax
  684c85:	09 c6                	or     %eax,%esi
  684c87:	89 f1                	mov    %esi,%ecx
  684c89:	4c 89 c0             	mov    %r8,%rax
  684c8c:	49 89 c0             	mov    %rax,%r8
  684c8f:	4c 29 c8             	sub    %r9,%rax
  684c92:	48 01 d0             	add    %rdx,%rax
  684c95:	c7 84 24 80 00 00 00 	movl   $0xfffffffe,0x80(%rsp)
  684c9c:	fe ff ff ff 
  684ca0:	40 b6 01             	mov    $0x1,%sil
  684ca3:	89 74 24 4c          	mov    %esi,0x4c(%rsp)
  684ca7:	83 f9 0c             	cmp    $0xc,%ecx
  684caa:	7e 24                	jle    684cd0 <<gpui_canvas::text::planner::Planner>::shape+0x760>
  684cac:	83 f9 0d             	cmp    $0xd,%ecx
  684caf:	0f 84 5b 01 00 00    	je     684e10 <<gpui_canvas::text::planner::Planner>::shape+0x8a0>
  684cb5:	81 f9 85 00 00 00    	cmp    $0x85,%ecx
  684cbb:	74 21                	je     684cde <<gpui_canvas::text::planner::Planner>::shape+0x76e>
  684cbd:	81 f9 29 20 00 00    	cmp    $0x2029,%ecx
  684cc3:	74 19                	je     684cde <<gpui_canvas::text::planner::Planner>::shape+0x76e>
  684cc5:	e9 83 00 00 00       	jmp    684d4d <<gpui_canvas::text::planner::Planner>::shape+0x7dd>
  684cca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  684cd0:	83 f9 ff             	cmp    $0xffffffff,%ecx
  684cd3:	0f 84 23 01 00 00    	je     684dfc <<gpui_canvas::text::planner::Planner>::shape+0x88c>
  684cd9:	83 f9 0a             	cmp    $0xa,%ecx
  684cdc:	75 6f                	jne    684d4d <<gpui_canvas::text::planner::Planner>::shape+0x7dd>
  684cde:	48 89 54 24 28       	mov    %rdx,0x28(%rsp)
  684ce3:	81 f9 80 00 00 00    	cmp    $0x80,%ecx
  684ce9:	0f 83 32 01 00 00    	jae    684e21 <<gpui_canvas::text::planner::Planner>::shape+0x8b1>
  684cef:	49 8d 70 01          	lea    0x1(%r8),%rsi
  684cf3:	83 f9 0d             	cmp    $0xd,%ecx
  684cf6:	0f 85 37 01 00 00    	jne    684e33 <<gpui_canvas::text::planner::Planner>::shape+0x8c3>
  684cfc:	4c 8b 4c 24 28       	mov    0x28(%rsp),%r9
  684d01:	4c 3b 8c 24 b0 01 00 	cmp    0x1b0(%rsp),%r9
  684d08:	00 
  684d09:	0f 84 78 23 00 00    	je     687087 <<gpui_canvas::text::planner::Planner>::shape+0x2b17>
  684d0f:	45 0f b6 11          	movzbl (%r9),%r10d
  684d13:	49 89 f3             	mov    %rsi,%r11
  684d16:	45 84 d2             	test   %r10b,%r10b
  684d19:	0f 88 78 23 00 00    	js     687097 <<gpui_canvas::text::planner::Planner>::shape+0x2b27>
  684d1f:	49 8d 59 01          	lea    0x1(%r9),%rbx
  684d23:	e9 ce 23 00 00       	jmp    6870f6 <<gpui_canvas::text::planner::Planner>::shape+0x2b86>
  684d28:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  684d2f:	00 
  684d30:	81 f9 29 20 00 00    	cmp    $0x2029,%ecx
  684d36:	0f 84 d9 00 00 00    	je     684e15 <<gpui_canvas::text::planner::Planner>::shape+0x8a5>
  684d3c:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
  684d41:	81 f9 85 00 00 00    	cmp    $0x85,%ecx
  684d47:	0f 84 c8 00 00 00    	je     684e15 <<gpui_canvas::text::planner::Planner>::shape+0x8a5>
  684d4d:	48 3b 94 24 b0 01 00 	cmp    0x1b0(%rsp),%rdx
  684d54:	00 
  684d55:	0f 84 a1 00 00 00    	je     684dfc <<gpui_canvas::text::planner::Planner>::shape+0x88c>
  684d5b:	49 89 c0             	mov    %rax,%r8
  684d5e:	0f b6 0a             	movzbl (%rdx),%ecx
  684d61:	84 c9                	test   %cl,%cl
  684d63:	78 0b                	js     684d70 <<gpui_canvas::text::planner::Planner>::shape+0x800>
  684d65:	48 8d 42 01          	lea    0x1(%rdx),%rax
  684d69:	eb 65                	jmp    684dd0 <<gpui_canvas::text::planner::Planner>::shape+0x860>
  684d6b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  684d70:	89 c8                	mov    %ecx,%eax
  684d72:	83 e0 1f             	and    $0x1f,%eax
  684d75:	0f b6 7a 01          	movzbl 0x1(%rdx),%edi
  684d79:	83 e7 3f             	and    $0x3f,%edi
  684d7c:	80 f9 df             	cmp    $0xdf,%cl
  684d7f:	76 2e                	jbe    684daf <<gpui_canvas::text::planner::Planner>::shape+0x83f>
  684d81:	0f b6 72 02          	movzbl 0x2(%rdx),%esi
  684d85:	c1 e7 06             	shl    $0x6,%edi
  684d88:	83 e6 3f             	and    $0x3f,%esi
  684d8b:	09 fe                	or     %edi,%esi
  684d8d:	80 f9 f0             	cmp    $0xf0,%cl
  684d90:	72 2d                	jb     684dbf <<gpui_canvas::text::planner::Planner>::shape+0x84f>
  684d92:	48 8d 7a 04          	lea    0x4(%rdx),%rdi
  684d96:	0f b6 4a 03          	movzbl 0x3(%rdx),%ecx
  684d9a:	83 e0 07             	and    $0x7,%eax
  684d9d:	c1 e0 12             	shl    $0x12,%eax
  684da0:	c1 e6 06             	shl    $0x6,%esi
  684da3:	83 e1 3f             	and    $0x3f,%ecx
  684da6:	09 f1                	or     %esi,%ecx
  684da8:	09 c1                	or     %eax,%ecx
  684daa:	48 89 f8             	mov    %rdi,%rax
  684dad:	eb 21                	jmp    684dd0 <<gpui_canvas::text::planner::Planner>::shape+0x860>
  684daf:	48 8d 72 02          	lea    0x2(%rdx),%rsi
  684db3:	c1 e0 06             	shl    $0x6,%eax
  684db6:	09 f8                	or     %edi,%eax
  684db8:	89 c1                	mov    %eax,%ecx
  684dba:	48 89 f0             	mov    %rsi,%rax
  684dbd:	eb 11                	jmp    684dd0 <<gpui_canvas::text::planner::Planner>::shape+0x860>
  684dbf:	48 8d 4a 03          	lea    0x3(%rdx),%rcx
  684dc3:	c1 e0 0c             	shl    $0xc,%eax
  684dc6:	09 c6                	or     %eax,%esi
  684dc8:	48 89 c8             	mov    %rcx,%rax
  684dcb:	89 f1                	mov    %esi,%ecx
  684dcd:	0f 1f 00             	nopl   (%rax)
  684dd0:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  684dd5:	48 29 d0             	sub    %rdx,%rax
  684dd8:	4c 01 c0             	add    %r8,%rax
  684ddb:	81 f9 84 00 00 00    	cmp    $0x84,%ecx
  684de1:	0f 8f 49 ff ff ff    	jg     684d30 <<gpui_canvas::text::planner::Planner>::shape+0x7c0>
  684de7:	83 f9 0a             	cmp    $0xa,%ecx
  684dea:	74 29                	je     684e15 <<gpui_canvas::text::planner::Planner>::shape+0x8a5>
  684dec:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
  684df1:	83 f9 0d             	cmp    $0xd,%ecx
  684df4:	0f 85 53 ff ff ff    	jne    684d4d <<gpui_canvas::text::planner::Planner>::shape+0x7dd>
  684dfa:	eb 19                	jmp    684e15 <<gpui_canvas::text::planner::Planner>::shape+0x8a5>
  684dfc:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
  684e01:	48 89 54 24 28       	mov    %rdx,0x28(%rsp)
  684e06:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  684e0b:	48 89 fe             	mov    %rdi,%rsi
  684e0e:	eb 33                	jmp    684e43 <<gpui_canvas::text::planner::Planner>::shape+0x8d3>
  684e10:	48 89 54 24 28       	mov    %rdx,0x28(%rsp)
  684e15:	81 f9 80 00 00 00    	cmp    $0x80,%ecx
  684e1b:	0f 82 ce fe ff ff    	jb     684cef <<gpui_canvas::text::planner::Planner>::shape+0x77f>
  684e21:	81 f9 00 08 00 00    	cmp    $0x800,%ecx
  684e27:	be 03 00 00 00       	mov    $0x3,%esi
  684e2c:	48 83 de 00          	sbb    $0x0,%rsi
  684e30:	4c 01 c6             	add    %r8,%rsi
  684e33:	c7 44 24 4c 00 00 00 	movl   $0x0,0x4c(%rsp)
  684e3a:	00 
  684e3b:	4c 89 c1             	mov    %r8,%rcx
  684e3e:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  684e43:	48 89 ca             	mov    %rcx,%rdx
  684e46:	48 29 fa             	sub    %rdi,%rdx
  684e49:	48 89 94 24 10 01 00 	mov    %rdx,0x110(%rsp)
  684e50:	00 
  684e51:	0f 82 a8 2c 00 00    	jb     687aff <<gpui_canvas::text::planner::Planner>::shape+0x358f>
  684e57:	48 83 7c 24 30 00    	cmpq   $0x0,0x30(%rsp)
  684e5d:	48 89 84 24 20 03 00 	mov    %rax,0x320(%rsp)
  684e64:	00 
  684e65:	74 2f                	je     684e96 <<gpui_canvas::text::planner::Planner>::shape+0x926>
  684e67:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
  684e6c:	48 3b 54 24 50       	cmp    0x50(%rsp),%rdx
  684e71:	73 1d                	jae    684e90 <<gpui_canvas::text::planner::Planner>::shape+0x920>
  684e73:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  684e7a:	00 
  684e7b:	80 3c 10 bf          	cmpb   $0xbf,(%rax,%rdx,1)
  684e7f:	7f 15                	jg     684e96 <<gpui_canvas::text::planner::Planner>::shape+0x926>
  684e81:	e9 79 2c 00 00       	jmp    687aff <<gpui_canvas::text::planner::Planner>::shape+0x358f>
  684e86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  684e8d:	00 00 00 
  684e90:	0f 85 69 2c 00 00    	jne    687aff <<gpui_canvas::text::planner::Planner>::shape+0x358f>
  684e96:	48 85 c9             	test   %rcx,%rcx
  684e99:	74 2b                	je     684ec6 <<gpui_canvas::text::planner::Planner>::shape+0x956>
  684e9b:	48 3b 4c 24 50       	cmp    0x50(%rsp),%rcx
  684ea0:	73 1e                	jae    684ec0 <<gpui_canvas::text::planner::Planner>::shape+0x950>
  684ea2:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  684ea9:	00 
  684eaa:	80 3c 08 c0          	cmpb   $0xc0,(%rax,%rcx,1)
  684eae:	7d 16                	jge    684ec6 <<gpui_canvas::text::planner::Planner>::shape+0x956>
  684eb0:	e9 4a 2c 00 00       	jmp    687aff <<gpui_canvas::text::planner::Planner>::shape+0x358f>
  684eb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  684ebc:	00 00 00 00 
  684ec0:	0f 85 39 2c 00 00    	jne    687aff <<gpui_canvas::text::planner::Planner>::shape+0x358f>
  684ec6:	48 89 8c 24 00 01 00 	mov    %rcx,0x100(%rsp)
  684ecd:	00 
  684ece:	48 89 b4 24 18 03 00 	mov    %rsi,0x318(%rsp)
  684ed5:	00 
  684ed6:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  684edd:	00 
  684ede:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  684ee3:	48 01 c1             	add    %rax,%rcx
  684ee6:	48 8d bc 24 98 04 00 	lea    0x498(%rsp),%rdi
  684eed:	00 
  684eee:	48 8b b4 24 30 03 00 	mov    0x330(%rsp),%rsi
  684ef5:	00 
  684ef6:	48 8b 94 24 28 03 00 	mov    0x328(%rsp),%rdx
  684efd:	00 
  684efe:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  684f03:	4c 8b 84 24 10 01 00 	mov    0x110(%rsp),%r8
  684f0a:	00 
  684f0b:	f3 0f 10 05 c9 88 99 	movss  -0x667737(%rip),%xmm0        # 1d7dc <GCC_except_table0+0x24>
  684f12:	ff 
  684f13:	45 31 c9             	xor    %r9d,%r9d
  684f16:	e8 15 c1 ff ff       	call   681030 <<parley::context::LayoutContext<()>>::ranged_builder>
  684f1b:	48 8d bc 24 98 04 00 	lea    0x498(%rsp),%rdi
  684f22:	00 
  684f23:	48 8d b4 24 a0 02 00 	lea    0x2a0(%rsp),%rsi
  684f2a:	00 
  684f2b:	48 8b 94 24 10 02 00 	mov    0x210(%rsp),%rdx
  684f32:	00 
  684f33:	e8 68 36 ff ff       	call   6785a0 <<parley::builder::RangedBuilder<()>>::push_default::<&[parlance::font_family::FontFamilyName]>>
  684f38:	4c 8b bc 24 98 04 00 	mov    0x498(%rsp),%r15
  684f3f:	00 
  684f40:	48 8b 9c 24 a0 04 00 	mov    0x4a0(%rsp),%rbx
  684f47:	00 
  684f48:	49 8d b7 30 02 00 00 	lea    0x230(%r15),%rsi
  684f4f:	c6 84 24 10 07 00 00 	movb   $0x1,0x710(%rsp)
  684f56:	01 
  684f57:	f3 0f 10 84 24 84 00 	movss  0x84(%rsp),%xmm0
  684f5e:	00 00 
  684f60:	f3 0f 11 84 24 14 07 	movss  %xmm0,0x714(%rsp)
  684f67:	00 00 
  684f69:	f3 0f 10 84 24 b8 04 	movss  0x4b8(%rsp),%xmm0
  684f70:	00 00 
  684f72:	48 8d bc 24 c0 04 00 	lea    0x4c0(%rsp),%rdi
  684f79:	00 
  684f7a:	48 89 f5             	mov    %rsi,%rbp
  684f7d:	48 89 da             	mov    %rbx,%rdx
  684f80:	4c 8d b4 24 10 07 00 	lea    0x710(%rsp),%r14
  684f87:	00 
  684f88:	4c 89 f1             	mov    %r14,%rcx
  684f8b:	f3 0f 11 44 24 60    	movss  %xmm0,0x60(%rsp)
  684f91:	e8 1a f0 fe ff       	call   673fb0 <<parley::resolve::ResolveContext>::resolve_property::<()>>
  684f96:	4c 89 f7             	mov    %r14,%rdi
  684f99:	e8 b2 36 ff ff       	call   678650 <core::ptr::drop_glue::<parley::style::StyleProperty<()>>>
  684f9e:	49 83 bf 20 05 00 00 	cmpq   $0xffffffffffffffff,0x520(%r15)
  684fa5:	ff 
  684fa6:	0f 84 8e 27 00 00    	je     68773a <<gpui_canvas::text::planner::Planner>::shape+0x31ca>
  684fac:	4d 8d b7 98 04 00 00 	lea    0x498(%r15),%r14
  684fb3:	4c 89 f7             	mov    %r14,%rdi
  684fb6:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
  684fbd:	00 
  684fbe:	e8 8d f5 fe ff       	call   674550 <<parley::resolve::ResolvedStyle<()>>::apply>
  684fc3:	66 c7 84 24 10 07 00 	movw   $0x117,0x710(%rsp)
  684fca:	00 17 01 
  684fcd:	48 8d bc 24 c0 04 00 	lea    0x4c0(%rsp),%rdi
  684fd4:	00 
  684fd5:	48 89 ee             	mov    %rbp,%rsi
  684fd8:	48 89 da             	mov    %rbx,%rdx
  684fdb:	48 8d 9c 24 10 07 00 	lea    0x710(%rsp),%rbx
  684fe2:	00 
  684fe3:	48 89 d9             	mov    %rbx,%rcx
  684fe6:	f3 0f 10 44 24 60    	movss  0x60(%rsp),%xmm0
  684fec:	e8 bf ef fe ff       	call   673fb0 <<parley::resolve::ResolveContext>::resolve_property::<()>>
  684ff1:	48 89 df             	mov    %rbx,%rdi
  684ff4:	e8 57 36 ff ff       	call   678650 <core::ptr::drop_glue::<parley::style::StyleProperty<()>>>
  684ff9:	49 83 bf 20 05 00 00 	cmpq   $0xffffffffffffffff,0x520(%r15)
  685000:	ff 
  685001:	0f 84 33 27 00 00    	je     68773a <<gpui_canvas::text::planner::Planner>::shape+0x31ca>
  685007:	4c 89 f7             	mov    %r14,%rdi
  68500a:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
  685011:	00 
  685012:	e8 39 f5 fe ff       	call   674550 <<parley::resolve::ResolvedStyle<()>>::apply>
  685017:	48 8d bc 24 98 04 00 	lea    0x498(%rsp),%rdi
  68501e:	00 
  68501f:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  685024:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  685029:	48 8b 8c 24 10 01 00 	mov    0x110(%rsp),%rcx
  685030:	00 
  685031:	e8 da 2e ff ff       	call   677f10 <<parley::builder::RangedBuilder<()>>::build_into::<&str>>
  685036:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  68503d:	00 
  68503e:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  685043:	e8 68 4f fe ff       	call   669fb0 <<parley::layout::line_break::BreakLines<()>>::new>
  685048:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  68504f:	00 
  685050:	f3 0f 10 84 24 cc 01 	movss  0x1cc(%rsp),%xmm0
  685057:	00 00 
  685059:	e8 32 40 fe ff       	call   669090 <<parley::layout::line_break::BreakLines<()>>::break_remaining>
  68505e:	80 bc 24 2c 02 00 00 	cmpb   $0x0,0x22c(%rsp)
  685065:	00 
  685066:	74 18                	je     685080 <<gpui_canvas::text::planner::Planner>::shape+0xb10>
  685068:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  68506f:	00 ff 
  685071:	0f 85 0c 02 00 00    	jne    685283 <<gpui_canvas::text::planner::Planner>::shape+0xd13>
  685077:	31 c0                	xor    %eax,%eax
  685079:	e9 88 01 00 00       	jmp    685206 <<gpui_canvas::text::planner::Planner>::shape+0xc96>
  68507e:	66 90                	xchg   %ax,%ax
  685080:	48 83 7c 24 30 00    	cmpq   $0x0,0x30(%rsp)
  685086:	48 8b 84 24 00 01 00 	mov    0x100(%rsp),%rax
  68508d:	00 
  68508e:	0f 85 5c 01 00 00    	jne    6851f0 <<gpui_canvas::text::planner::Planner>::shape+0xc80>
  685094:	48 3b 44 24 50       	cmp    0x50(%rsp),%rax
  685099:	0f 85 51 01 00 00    	jne    6851f0 <<gpui_canvas::text::planner::Planner>::shape+0xc80>
  68509f:	48 8b 04 24          	mov    (%rsp),%rax
  6850a3:	48 83 b8 e0 09 00 00 	cmpq   $0x1,0x9e0(%rax)
  6850aa:	01 
  6850ab:	0f 85 3f 01 00 00    	jne    6851f0 <<gpui_canvas::text::planner::Planner>::shape+0xc80>
  6850b1:	48 8b 14 24          	mov    (%rsp),%rdx
  6850b5:	48 8b 82 d8 09 00 00 	mov    0x9d8(%rdx),%rax
  6850bc:	48 8d 48 70          	lea    0x70(%rax),%rcx
  6850c0:	48 89 8c 24 18 07 00 	mov    %rcx,0x718(%rsp)
  6850c7:	00 
  6850c8:	48 c7 84 24 20 07 00 	movq   $0x0,0x720(%rsp)
  6850cf:	00 00 00 00 00 
  6850d4:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  6850d9:	48 89 b4 24 28 07 00 	mov    %rsi,0x728(%rsp)
  6850e0:	00 
  6850e1:	48 c7 84 24 58 07 00 	movq   $0x0,0x758(%rsp)
  6850e8:	00 00 00 00 00 
  6850ed:	48 89 94 24 c0 04 00 	mov    %rdx,0x4c0(%rsp)
  6850f4:	00 
  6850f5:	48 c7 84 24 30 07 00 	movq   $0x0,0x730(%rsp)
  6850fc:	00 00 00 00 00 
  685101:	48 89 8c 24 10 07 00 	mov    %rcx,0x710(%rsp)
  685108:	00 
  685109:	48 8b 78 10          	mov    0x10(%rax),%rdi
  68510d:	48 8b 70 18          	mov    0x18(%rax),%rsi
  685111:	48 8b 92 f8 09 00 00 	mov    0x9f8(%rdx),%rdx
  685118:	48 39 fe             	cmp    %rdi,%rsi
  68511b:	0f 82 95 29 00 00    	jb     687ab6 <<gpui_canvas::text::planner::Planner>::shape+0x3546>
  685121:	48 39 d6             	cmp    %rdx,%rsi
  685124:	0f 87 8c 29 00 00    	ja     687ab6 <<gpui_canvas::text::planner::Planner>::shape+0x3546>
  68512a:	48 8b 04 24          	mov    (%rsp),%rax
  68512e:	48 8b 80 f0 09 00 00 	mov    0x9f0(%rax),%rax
  685135:	48 8d 0c bf          	lea    (%rdi,%rdi,4),%rcx
  685139:	48 8d 0c c8          	lea    (%rax,%rcx,8),%rcx
  68513d:	48 8d 14 b6          	lea    (%rsi,%rsi,4),%rdx
  685141:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
  685145:	48 89 8c 24 30 07 00 	mov    %rcx,0x730(%rsp)
  68514c:	00 
  68514d:	48 89 84 24 38 07 00 	mov    %rax,0x738(%rsp)
  685154:	00 
  685155:	48 c7 84 24 40 07 00 	movq   $0x0,0x740(%rsp)
  68515c:	00 00 00 00 00 
  685161:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  685166:	48 89 84 24 48 07 00 	mov    %rax,0x748(%rsp)
  68516d:	00 
  68516e:	c7 84 24 50 07 00 00 	movl   $0x0,0x750(%rsp)
  685175:	00 00 00 00 
  685179:	48 8d bc 24 30 07 00 	lea    0x730(%rsp),%rdi
  685180:	00 
  685181:	48 8d b4 24 58 07 00 	lea    0x758(%rsp),%rsi
  685188:	00 
  685189:	48 8d 94 24 c0 04 00 	lea    0x4c0(%rsp),%rdx
  685190:	00 
  685191:	e8 3a 84 ff ff       	call   67d5d0 <<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}> as core::iter::traits::iterator::Iterator>::try_fold::<(), core::iter::adapters::filter_map::filter_map_try_fold<parley::layout::line::LineItem<()>, parley::layout::run::Run<()>, (), core::ops::control_flow::ControlFlow<()>, <parley::layout::line::Line<()>>::runs::{closure#0}, &mut core::iter::traits::iterator::Iterator::all::check<parley::layout::run::Run<()>, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#2}>::{closure#0}>::{closure#0}, core::ops::control_flow::ControlFlow<()>>>
  685196:	48 c7 84 24 20 07 00 	movq   $0x1,0x720(%rsp)
  68519d:	00 01 00 00 00 
  6851a2:	84 c0                	test   %al,%al
  6851a4:	75 4a                	jne    6851f0 <<gpui_canvas::text::planner::Planner>::shape+0xc80>
  6851a6:	48 c7 84 24 30 07 00 	movq   $0x0,0x730(%rsp)
  6851ad:	00 00 00 00 00 
  6851b2:	48 83 bc 24 58 07 00 	cmpq   $0x0,0x758(%rsp)
  6851b9:	00 00 
  6851bb:	0f 84 4b 1e 00 00    	je     68700c <<gpui_canvas::text::planner::Planner>::shape+0x2a9c>
  6851c1:	48 8d bc 24 58 07 00 	lea    0x758(%rsp),%rdi
  6851c8:	00 
  6851c9:	48 8d b4 24 80 07 00 	lea    0x780(%rsp),%rsi
  6851d0:	00 
  6851d1:	48 8d 94 24 c0 04 00 	lea    0x4c0(%rsp),%rdx
  6851d8:	00 
  6851d9:	e8 f2 83 ff ff       	call   67d5d0 <<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}> as core::iter::traits::iterator::Iterator>::try_fold::<(), core::iter::adapters::filter_map::filter_map_try_fold<parley::layout::line::LineItem<()>, parley::layout::run::Run<()>, (), core::ops::control_flow::ControlFlow<()>, <parley::layout::line::Line<()>>::runs::{closure#0}, &mut core::iter::traits::iterator::Iterator::all::check<parley::layout::run::Run<()>, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#2}>::{closure#0}>::{closure#0}, core::ops::control_flow::ControlFlow<()>>>
  6851de:	84 c0                	test   %al,%al
  6851e0:	0f 84 26 1e 00 00    	je     68700c <<gpui_canvas::text::planner::Planner>::shape+0x2a9c>
  6851e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  6851ed:	00 00 00 
  6851f0:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  6851f7:	00 ff 
  6851f9:	0f 85 84 00 00 00    	jne    685283 <<gpui_canvas::text::planner::Planner>::shape+0xd13>
  6851ff:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
  685206:	48 c7 84 24 50 01 00 	movq   $0x0,0x150(%rsp)
  68520d:	00 00 00 00 00 
  685212:	48 c7 84 24 58 01 00 	movq   $0x4,0x158(%rsp)
  685219:	00 04 00 00 00 
  68521e:	48 8d 8c 24 58 01 00 	lea    0x158(%rsp),%rcx
  685225:	00 
  685226:	0f 57 c0             	xorps  %xmm0,%xmm0
  685229:	0f 11 41 08          	movups %xmm0,0x8(%rcx)
  68522d:	48 c7 84 24 70 01 00 	movq   $0x4,0x170(%rsp)
  685234:	00 04 00 00 00 
  685239:	48 c7 84 24 78 01 00 	movq   $0x0,0x178(%rsp)
  685240:	00 00 00 00 00 
  685245:	48 89 84 24 80 01 00 	mov    %rax,0x180(%rsp)
  68524c:	00 
  68524d:	48 c7 84 24 88 01 00 	movq   $0x4,0x188(%rsp)
  685254:	00 04 00 00 00 
  685259:	48 c7 84 24 90 01 00 	movq   $0x0,0x190(%rsp)
  685260:	00 00 00 00 00 
  685265:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  68526a:	89 84 24 98 01 00 00 	mov    %eax,0x198(%rsp)
  685271:	f3 0f 10 84 24 84 00 	movss  0x84(%rsp),%xmm0
  685278:	00 00 
  68527a:	f3 0f 11 84 24 9c 01 	movss  %xmm0,0x19c(%rsp)
  685281:	00 00 
  685283:	48 8b 04 24          	mov    (%rsp),%rax
  685287:	4c 8b b0 e0 09 00 00 	mov    0x9e0(%rax),%r14
  68528e:	4d 85 f6             	test   %r14,%r14
  685291:	0f 84 09 01 00 00    	je     6853a0 <<gpui_canvas::text::planner::Planner>::shape+0xe30>
  685297:	48 8b a8 d8 09 00 00 	mov    0x9d8(%rax),%rbp
  68529e:	45 31 ff             	xor    %r15d,%r15d
  6852a1:	31 db                	xor    %ebx,%ebx
  6852a3:	eb 17                	jmp    6852bc <<gpui_canvas::text::planner::Planner>::shape+0xd4c>
  6852a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6852ac:	00 00 00 00 
  6852b0:	49 ff c7             	inc    %r15
  6852b3:	4d 39 f7             	cmp    %r14,%r15
  6852b6:	0f 84 e6 00 00 00    	je     6853a2 <<gpui_canvas::text::planner::Planner>::shape+0xe32>
  6852bc:	49 6b c7 70          	imul   $0x70,%r15,%rax
  6852c0:	48 01 e8             	add    %rbp,%rax
  6852c3:	48 89 9c 24 10 07 00 	mov    %rbx,0x710(%rsp)
  6852ca:	00 
  6852cb:	48 c7 84 24 18 07 00 	movq   $0x0,0x718(%rsp)
  6852d2:	00 00 00 00 00 
  6852d7:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
  6852dc:	48 89 8c 24 20 07 00 	mov    %rcx,0x720(%rsp)
  6852e3:	00 
  6852e4:	48 89 84 24 28 07 00 	mov    %rax,0x728(%rsp)
  6852eb:	00 
  6852ec:	44 89 bc 24 30 07 00 	mov    %r15d,0x730(%rsp)
  6852f3:	00 
  6852f4:	c6 84 24 d8 07 00 00 	movb   $0x2,0x7d8(%rsp)
  6852fb:	02 
  6852fc:	c7 84 24 e0 07 00 00 	movl   $0x0,0x7e0(%rsp)
  685303:	00 00 00 00 
  685307:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
  68530e:	00 
  68530f:	48 8d b4 24 18 07 00 	lea    0x718(%rsp),%rsi
  685316:	00 
  685317:	e8 04 8d ff ff       	call   67e020 <<parley::layout::line::GlyphRunIter<()> as core::iter::traits::iterator::Iterator>::next>
  68531c:	83 bc 24 40 03 00 00 	cmpl   $0x1,0x340(%rsp)
  685323:	01 
  685324:	75 8a                	jne    6852b0 <<gpui_canvas::text::planner::Planner>::shape+0xd40>
  685326:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  68532d:	00 00 00 
  685330:	49 8b 45 38          	mov    0x38(%r13),%rax
  685334:	49 89 44 24 40       	mov    %rax,0x40(%r12)
  685339:	41 0f 10 45 f8       	movups -0x8(%r13),%xmm0
  68533e:	41 0f 10 4d 08       	movups 0x8(%r13),%xmm1
  685343:	41 0f 10 55 18       	movups 0x18(%r13),%xmm2
  685348:	41 0f 10 5d 28       	movups 0x28(%r13),%xmm3
  68534d:	41 0f 11 5c 24 30    	movups %xmm3,0x30(%r12)
  685353:	41 0f 11 54 24 20    	movups %xmm2,0x20(%r12)
  685359:	41 0f 11 4c 24 10    	movups %xmm1,0x10(%r12)
  68535f:	41 0f 11 04 24       	movups %xmm0,(%r12)
  685364:	48 89 9c 24 c0 04 00 	mov    %rbx,0x4c0(%rsp)
  68536b:	00 
  68536c:	48 89 de             	mov    %rbx,%rsi
  68536f:	4c 89 e2             	mov    %r12,%rdx
  685372:	e8 69 88 ff ff       	call   67dbe0 <<&mut core::iter::adapters::map::map_fold<parley::layout::line::PositionedLayoutItem<()>, usize, usize, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#5}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineData>>, <parley::layout::layout::Layout<()>>::lines::{closure#0}>, parley::layout::line::GlyphRunIter<()>, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#4}>, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#5}>>::{closure#0}>::{closure#0} as core::ops::function::FnMut<(usize, parley::layout::line::PositionedLayoutItem<()>)>>::call_mut>
  685377:	48 89 c3             	mov    %rax,%rbx
  68537a:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
  685381:	00 
  685382:	48 8d b4 24 18 07 00 	lea    0x718(%rsp),%rsi
  685389:	00 
  68538a:	e8 91 8c ff ff       	call   67e020 <<parley::layout::line::GlyphRunIter<()> as core::iter::traits::iterator::Iterator>::next>
  68538f:	80 bc 24 40 03 00 00 	cmpb   $0x0,0x340(%rsp)
  685396:	00 
  685397:	75 97                	jne    685330 <<gpui_canvas::text::planner::Planner>::shape+0xdc0>
  685399:	e9 12 ff ff ff       	jmp    6852b0 <<gpui_canvas::text::planner::Planner>::shape+0xd40>
  68539e:	66 90                	xchg   %ax,%ax
  6853a0:	31 db                	xor    %ebx,%ebx
  6853a2:	48 8b b4 24 f8 00 00 	mov    0xf8(%rsp),%rsi
  6853a9:	00 
  6853aa:	48 89 f0             	mov    %rsi,%rax
  6853ad:	48 01 d8             	add    %rbx,%rax
  6853b0:	0f 92 c1             	setb   %cl
  6853b3:	48 3d 01 80 00 00    	cmp    $0x8001,%rax
  6853b9:	0f 93 c0             	setae  %al
  6853bc:	08 c8                	or     %cl,%al
  6853be:	0f 85 9b 1d 00 00    	jne    68715f <<gpui_canvas::text::planner::Planner>::shape+0x2bef>
  6853c4:	48 8b 6c 24 30       	mov    0x30(%rsp),%rbp
  6853c9:	48 39 ac 24 00 01 00 	cmp    %rbp,0x100(%rsp)
  6853d0:	00 
  6853d1:	74 14                	je     6853e7 <<gpui_canvas::text::planner::Planner>::shape+0xe77>
  6853d3:	48 8b 84 24 e8 00 00 	mov    0xe8(%rsp),%rax
  6853da:	00 
  6853db:	48 29 f0             	sub    %rsi,%rax
  6853de:	48 39 c3             	cmp    %rax,%rbx
  6853e1:	0f 87 58 1d 00 00    	ja     68713f <<gpui_canvas::text::planner::Planner>::shape+0x2bcf>
  6853e7:	48 85 ed             	test   %rbp,%rbp
  6853ea:	48 8b 9c 24 00 01 00 	mov    0x100(%rsp),%rbx
  6853f1:	00 
  6853f2:	74 26                	je     68541a <<gpui_canvas::text::planner::Planner>::shape+0xeaa>
  6853f4:	0f 57 c0             	xorps  %xmm0,%xmm0
  6853f7:	f3 0f 11 84 24 d4 00 	movss  %xmm0,0xd4(%rsp)
  6853fe:	00 00 
  685400:	48 39 eb             	cmp    %rbp,%rbx
  685403:	75 4b                	jne    685450 <<gpui_canvas::text::planner::Planner>::shape+0xee0>
  685405:	48 8b 0c 24          	mov    (%rsp),%rcx
  685409:	48 8b 81 e0 09 00 00 	mov    0x9e0(%rcx),%rax
  685410:	48 85 c0             	test   %rax,%rax
  685413:	75 7c                	jne    685491 <<gpui_canvas::text::planner::Planner>::shape+0xf21>
  685415:	e9 9b 14 00 00       	jmp    6868b5 <<gpui_canvas::text::planner::Planner>::shape+0x2345>
  68541a:	48 8b 04 24          	mov    (%rsp),%rax
  68541e:	48 83 b8 e0 09 00 00 	cmpq   $0x0,0x9e0(%rax)
  685425:	00 
  685426:	74 0e                	je     685436 <<gpui_canvas::text::planner::Planner>::shape+0xec6>
  685428:	48 8b 80 d8 09 00 00 	mov    0x9d8(%rax),%rax
  68542f:	f3 0f 10 40 24       	movss  0x24(%rax),%xmm0
  685434:	eb 03                	jmp    685439 <<gpui_canvas::text::planner::Planner>::shape+0xec9>
  685436:	0f 57 c0             	xorps  %xmm0,%xmm0
  685439:	f3 0f 11 44 24 7c    	movss  %xmm0,0x7c(%rsp)
  68543f:	0f 57 c0             	xorps  %xmm0,%xmm0
  685442:	f3 0f 11 84 24 d4 00 	movss  %xmm0,0xd4(%rsp)
  685449:	00 00 
  68544b:	48 39 eb             	cmp    %rbp,%rbx
  68544e:	74 b5                	je     685405 <<gpui_canvas::text::planner::Planner>::shape+0xe95>
  685450:	83 bc 24 c8 01 00 00 	cmpl   $0x0,0x1c8(%rsp)
  685457:	00 
  685458:	74 0e                	je     685468 <<gpui_canvas::text::planner::Planner>::shape+0xef8>
  68545a:	48 8b 04 24          	mov    (%rsp),%rax
  68545e:	f3 0f 10 80 28 0a 00 	movss  0xa28(%rax),%xmm0
  685465:	00 
  685466:	eb 0c                	jmp    685474 <<gpui_canvas::text::planner::Planner>::shape+0xf04>
  685468:	48 8b 04 24          	mov    (%rsp),%rax
  68546c:	f3 0f 10 80 2c 0a 00 	movss  0xa2c(%rax),%xmm0
  685473:	00 
  685474:	f3 0f 11 84 24 d4 00 	movss  %xmm0,0xd4(%rsp)
  68547b:	00 00 
  68547d:	48 8b 0c 24          	mov    (%rsp),%rcx
  685481:	48 8b 81 e0 09 00 00 	mov    0x9e0(%rcx),%rax
  685488:	48 85 c0             	test   %rax,%rax
  68548b:	0f 84 24 14 00 00    	je     6868b5 <<gpui_canvas::text::planner::Planner>::shape+0x2345>
  685491:	48 8b 89 d8 09 00 00 	mov    0x9d8(%rcx),%rcx
  685498:	48 6b c0 70          	imul   $0x70,%rax,%rax
  68549c:	48 89 8c 24 c8 00 00 	mov    %rcx,0xc8(%rsp)
  6854a3:	00 
  6854a4:	48 01 c8             	add    %rcx,%rax
  6854a7:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
  6854ae:	00 
  6854af:	c7 44 24 78 00 00 00 	movl   $0x0,0x78(%rsp)
  6854b6:	00 
  6854b7:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  6854be:	00 ff 
  6854c0:	74 2e                	je     6854f0 <<gpui_canvas::text::planner::Planner>::shape+0xf80>
  6854c2:	48 39 eb             	cmp    %rbp,%rbx
  6854c5:	75 3c                	jne    685503 <<gpui_canvas::text::planner::Planner>::shape+0xf93>
  6854c7:	45 31 f6             	xor    %r14d,%r14d
  6854ca:	45 31 ff             	xor    %r15d,%r15d
  6854cd:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  6854d4:	00 
  6854d5:	48 8b 8c 24 78 01 00 	mov    0x178(%rsp),%rcx
  6854dc:	00 
  6854dd:	48 89 8c 24 58 02 00 	mov    %rcx,0x258(%rsp)
  6854e4:	00 
  6854e5:	80 78 68 02          	cmpb   $0x2,0x68(%rax)
  6854e9:	74 41                	je     68552c <<gpui_canvas::text::planner::Planner>::shape+0xfbc>
  6854eb:	e9 da 01 00 00       	jmp    6856ca <<gpui_canvas::text::planner::Planner>::shape+0x115a>
  6854f0:	8b 4c 24 78          	mov    0x78(%rsp),%ecx
  6854f4:	89 c8                	mov    %ecx,%eax
  6854f6:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
  6854fd:	00 
  6854fe:	e9 cd 03 00 00       	jmp    6858d0 <<gpui_canvas::text::planner::Planner>::shape+0x1360>
  685503:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  68550a:	00 
  68550b:	4c 8b 38             	mov    (%rax),%r15
  68550e:	4c 8b 70 08          	mov    0x8(%rax),%r14
  685512:	48 8b 8c 24 78 01 00 	mov    0x178(%rsp),%rcx
  685519:	00 
  68551a:	48 89 8c 24 58 02 00 	mov    %rcx,0x258(%rsp)
  685521:	00 
  685522:	80 78 68 02          	cmpb   $0x2,0x68(%rax)
  685526:	0f 85 9e 01 00 00    	jne    6856ca <<gpui_canvas::text::planner::Planner>::shape+0x115a>
  68552c:	48 8b 78 10          	mov    0x10(%rax),%rdi
  685530:	48 8b 70 18          	mov    0x18(%rax),%rsi
  685534:	48 8b 04 24          	mov    (%rsp),%rax
  685538:	48 8b 90 f8 09 00 00 	mov    0x9f8(%rax),%rdx
  68553f:	48 39 fe             	cmp    %rdi,%rsi
  685542:	0f 82 80 25 00 00    	jb     687ac8 <<gpui_canvas::text::planner::Planner>::shape+0x3558>
  685548:	48 39 d6             	cmp    %rdx,%rsi
  68554b:	0f 87 77 25 00 00    	ja     687ac8 <<gpui_canvas::text::planner::Planner>::shape+0x3558>
  685551:	48 8b 04 24          	mov    (%rsp),%rax
  685555:	48 8b 80 f0 09 00 00 	mov    0x9f0(%rax),%rax
  68555c:	48 8d 0c bf          	lea    (%rdi,%rdi,4),%rcx
  685560:	48 8d 0c c8          	lea    (%rax,%rcx,8),%rcx
  685564:	48 8d 14 b6          	lea    (%rsi,%rsi,4),%rdx
  685568:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
  68556c:	48 89 8c 24 c0 04 00 	mov    %rcx,0x4c0(%rsp)
  685573:	00 
  685574:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
  68557b:	00 
  68557c:	48 c7 84 24 d0 04 00 	movq   $0x0,0x4d0(%rsp)
  685583:	00 00 00 00 00 
  685588:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  68558d:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
  685594:	00 
  685595:	8b 44 24 78          	mov    0x78(%rsp),%eax
  685599:	89 84 24 e0 04 00 00 	mov    %eax,0x4e0(%rsp)
  6855a0:	c6 84 24 00 07 00 00 	movb   $0x2,0x700(%rsp)
  6855a7:	02 
  6855a8:	48 8d 84 24 08 07 00 	lea    0x708(%rsp),%rax
  6855af:	00 
  6855b0:	48 89 84 24 40 03 00 	mov    %rax,0x340(%rsp)
  6855b7:	00 
  6855b8:	c6 84 24 f0 05 00 00 	movb   $0x2,0x5f0(%rsp)
  6855bf:	02 
  6855c0:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  6855c7:	00 
  6855c8:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
  6855cf:	00 
  6855d0:	48 8d 94 24 40 03 00 	lea    0x340(%rsp),%rdx
  6855d7:	00 
  6855d8:	48 8d 8c 24 e8 04 00 	lea    0x4e8(%rsp),%rcx
  6855df:	00 
  6855e0:	e8 bb 78 ff ff       	call   67cea0 <<core::iter::adapters::map::Map<core::iter::adapters::filter_map::FilterMap<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}>, <parley::layout::line::Line<()>>::runs::{closure#0}>, gpui_canvas::text::planner::freeze_line::{closure#0}> as core::iter::traits::iterator::Iterator>::try_fold::<(), <core::iter::adapters::flatten::FlattenCompat<_, _>>::iter_try_fold::flatten<parley::layout::run::Clusters<()>, (), core::ops::control_flow::ControlFlow<parley::layout::cluster::Cluster<()>>, <core::iter::adapters::flatten::FlattenCompat<_, _> as core::iter::traits::iterator::Iterator>::try_fold::flatten<parley::layout::run::Clusters<()>, (), core::ops::control_flow::ControlFlow<parley::layout::cluster::Cluster<()>>, core::iter::traits::iterator::Iterator::find::check<parley::layout::cluster::Cluster<()>, &mut gpui_canvas::text::planner::freeze_line::{closure#1}>::{closure#0}>::{closure#0}>::{closure#0}, core::ops::control_flow::ControlFlow<parley::layout::cluster::Cluster<()>>>>
  6855e5:	48 8b 8c 24 10 07 00 	mov    0x710(%rsp),%rcx
  6855ec:	00 
  6855ed:	48 85 c9             	test   %rcx,%rcx
  6855f0:	0f 84 ba 00 00 00    	je     6856b0 <<gpui_canvas::text::planner::Planner>::shape+0x1140>
  6855f6:	8b bc 24 38 07 00 00 	mov    0x738(%rsp),%edi
  6855fd:	8b b4 24 90 07 00 00 	mov    0x790(%rsp),%esi
  685604:	8b 94 24 94 07 00 00 	mov    0x794(%rsp),%edx
  68560b:	48 8b 41 58          	mov    0x58(%rcx),%rax
  68560f:	48 39 f8             	cmp    %rdi,%rax
  685612:	0f 86 d3 25 00 00    	jbe    687beb <<gpui_canvas::text::planner::Planner>::shape+0x367b>
  685618:	48 8b 41 50          	mov    0x50(%rcx),%rax
  68561c:	48 8d 3c ff          	lea    (%rdi,%rdi,8),%rdi
  685620:	48 c1 e7 04          	shl    $0x4,%rdi
  685624:	0f 10 41 68          	movups 0x68(%rcx),%xmm0
  685628:	0f 10 89 80 00 00 00 	movups 0x80(%rcx),%xmm1
  68562f:	0f 10 91 98 00 00 00 	movups 0x98(%rcx),%xmm2
  685636:	0f 11 84 24 10 07 00 	movups %xmm0,0x710(%rsp)
  68563d:	00 
  68563e:	0f 11 8c 24 20 07 00 	movups %xmm1,0x720(%rsp)
  685645:	00 
  685646:	0f 11 94 24 30 07 00 	movups %xmm2,0x730(%rsp)
  68564d:	00 
  68564e:	48 8b 44 38 50       	mov    0x50(%rax,%rdi,1),%rax
  685653:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
  68565a:	00 
  68565b:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  685662:	00 
  685663:	ff 15 07 51 10 00    	call   *0x105107(%rip)        # 78a770 <_DYNAMIC+0x528>
  685669:	48 89 c3             	mov    %rax,%rbx
  68566c:	ba 48 02 00 00       	mov    $0x248,%edx
  685671:	4c 89 7c 24 60       	mov    %r15,0x60(%rsp)
  685676:	4c 8d bc 24 10 07 00 	lea    0x710(%rsp),%r15
  68567d:	00 
  68567e:	4c 89 ff             	mov    %r15,%rdi
  685681:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
  685688:	00 
  685689:	ff 15 89 4e 10 00    	call   *0x104e89(%rip)        # 78a518 <memcpy@GLIBC_2.14>
  68568f:	4c 89 ff             	mov    %r15,%rdi
  685692:	4c 8b 7c 24 60       	mov    0x60(%rsp),%r15
  685697:	48 89 de             	mov    %rbx,%rsi
  68569a:	e8 a1 7a ff ff       	call   67d140 <<core::iter::adapters::map::Map<core::iter::adapters::filter::Filter<core::iter::adapters::flatten::FlatMap<core::iter::adapters::filter_map::FilterMap<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}>, <parley::layout::line::Line<()>>::runs::{closure#0}>, parley::layout::run::Clusters<()>, gpui_canvas::text::planner::freeze_line::{closure#0}>, gpui_canvas::text::planner::freeze_line::{closure#1}>, gpui_canvas::text::planner::freeze_line::{closure#2}> as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::traits::iterator::Iterator::min_by::fold<usize, <usize as core::cmp::Ord>::cmp>::{closure#0}>>
  68569f:	4c 39 f0             	cmp    %r14,%rax
  6856a2:	4c 0f 42 f0          	cmovb  %rax,%r14
  6856a6:	48 8b 9c 24 00 01 00 	mov    0x100(%rsp),%rbx
  6856ad:	00 
  6856ae:	eb 1a                	jmp    6856ca <<gpui_canvas::text::planner::Planner>::shape+0x115a>
  6856b0:	80 bc 24 00 07 00 00 	cmpb   $0x2,0x700(%rsp)
  6856b7:	02 
  6856b8:	c6 84 24 f0 05 00 00 	movb   $0x2,0x5f0(%rsp)
  6856bf:	02 
  6856c0:	48 8b 9c 24 00 01 00 	mov    0x100(%rsp),%rbx
  6856c7:	00 
  6856c8:	75 36                	jne    685700 <<gpui_canvas::text::planner::Planner>::shape+0x1190>
  6856ca:	4d 39 f7             	cmp    %r14,%r15
  6856cd:	0f 87 67 1e 00 00    	ja     68753a <<gpui_canvas::text::planner::Planner>::shape+0x2fca>
  6856d3:	4d 85 ff             	test   %r15,%r15
  6856d6:	0f 84 a0 00 00 00    	je     68577c <<gpui_canvas::text::planner::Planner>::shape+0x120c>
  6856dc:	4c 3b bc 24 10 01 00 	cmp    0x110(%rsp),%r15
  6856e3:	00 
  6856e4:	0f 83 8c 00 00 00    	jae    685776 <<gpui_canvas::text::planner::Planner>::shape+0x1206>
  6856ea:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6856ef:	42 80 3c 38 bf       	cmpb   $0xbf,(%rax,%r15,1)
  6856f4:	0f 8f 82 00 00 00    	jg     68577c <<gpui_canvas::text::planner::Planner>::shape+0x120c>
  6856fa:	e9 3b 1e 00 00       	jmp    68753a <<gpui_canvas::text::planner::Planner>::shape+0x2fca>
  6856ff:	90                   	nop
  685700:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  685707:	00 
  685708:	48 8d b4 24 f8 05 00 	lea    0x5f8(%rsp),%rsi
  68570f:	00 
  685710:	e8 8b 4b fe ff       	call   66a2a0 <<parley::layout::run::Clusters<()> as core::iter::traits::iterator::Iterator>::next>
  685715:	48 8b 8c 24 10 07 00 	mov    0x710(%rsp),%rcx
  68571c:	00 
  68571d:	48 85 c9             	test   %rcx,%rcx
  685720:	74 a8                	je     6856ca <<gpui_canvas::text::planner::Planner>::shape+0x115a>
  685722:	8b bc 24 38 07 00 00 	mov    0x738(%rsp),%edi
  685729:	48 8b 41 58          	mov    0x58(%rcx),%rax
  68572d:	48 39 f8             	cmp    %rdi,%rax
  685730:	0f 86 32 24 00 00    	jbe    687b68 <<gpui_canvas::text::planner::Planner>::shape+0x35f8>
  685736:	8b b4 24 90 07 00 00 	mov    0x790(%rsp),%esi
  68573d:	8b 94 24 94 07 00 00 	mov    0x794(%rsp),%edx
  685744:	4c 8b 41 70          	mov    0x70(%rcx),%r8
  685748:	39 f2                	cmp    %esi,%edx
  68574a:	0f 82 fb 22 00 00    	jb     687a4b <<gpui_canvas::text::planner::Planner>::shape+0x34db>
  685750:	49 39 d0             	cmp    %rdx,%r8
  685753:	0f 82 f2 22 00 00    	jb     687a4b <<gpui_canvas::text::planner::Planner>::shape+0x34db>
  685759:	39 f2                	cmp    %esi,%edx
  68575b:	0f 84 18 24 00 00    	je     687b79 <<gpui_canvas::text::planner::Planner>::shape+0x3609>
  685761:	4c 8b 41 68          	mov    0x68(%rcx),%r8
  685765:	4c 8d 0c 76          	lea    (%rsi,%rsi,2),%r9
  685769:	43 80 7c 88 07 06    	cmpb   $0x6,0x7(%r8,%r9,4)
  68576f:	75 8f                	jne    685700 <<gpui_canvas::text::planner::Planner>::shape+0x1190>
  685771:	e9 99 fe ff ff       	jmp    68560f <<gpui_canvas::text::planner::Planner>::shape+0x109f>
  685776:	0f 85 be 1d 00 00    	jne    68753a <<gpui_canvas::text::planner::Planner>::shape+0x2fca>
  68577c:	4d 85 f6             	test   %r14,%r14
  68577f:	74 21                	je     6857a2 <<gpui_canvas::text::planner::Planner>::shape+0x1232>
  685781:	4c 3b b4 24 10 01 00 	cmp    0x110(%rsp),%r14
  685788:	00 
  685789:	73 11                	jae    68579c <<gpui_canvas::text::planner::Planner>::shape+0x122c>
  68578b:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  685790:	42 80 3c 30 c0       	cmpb   $0xc0,(%rax,%r14,1)
  685795:	7d 0b                	jge    6857a2 <<gpui_canvas::text::planner::Planner>::shape+0x1232>
  685797:	e9 9e 1d 00 00       	jmp    68753a <<gpui_canvas::text::planner::Planner>::shape+0x2fca>
  68579c:	0f 85 98 1d 00 00    	jne    68753a <<gpui_canvas::text::planner::Planner>::shape+0x2fca>
  6857a2:	0f 57 c0             	xorps  %xmm0,%xmm0
  6857a5:	48 39 eb             	cmp    %rbp,%rbx
  6857a8:	74 0d                	je     6857b7 <<gpui_canvas::text::planner::Planner>::shape+0x1247>
  6857aa:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  6857b1:	00 
  6857b2:	f3 0f 10 40 30       	movss  0x30(%rax),%xmm0
  6857b7:	f3 0f 11 44 24 60    	movss  %xmm0,0x60(%rsp)
  6857bd:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  6857c4:	00 
  6857c5:	f3 0f 10 48 40       	movss  0x40(%rax),%xmm1
  6857ca:	f3 0f 10 40 44       	movss  0x44(%rax),%xmm0
  6857cf:	0f 29 8c 24 90 02 00 	movaps %xmm1,0x290(%rsp)
  6857d6:	00 
  6857d7:	f3 0f 5d 48 48       	minss  0x48(%rax),%xmm1
  6857dc:	0f 29 8c 24 a0 01 00 	movaps %xmm1,0x1a0(%rsp)
  6857e3:	00 
  6857e4:	0f 29 84 24 d0 01 00 	movaps %xmm0,0x1d0(%rsp)
  6857eb:	00 
  6857ec:	f3 0f 5f 40 4c       	maxss  0x4c(%rax),%xmm0
  6857f1:	0f 29 84 24 20 01 00 	movaps %xmm0,0x120(%rsp)
  6857f8:	00 
  6857f9:	f3 0f 10 40 24       	movss  0x24(%rax),%xmm0
  6857fe:	f3 0f 58 44 24 1c    	addss  0x1c(%rsp),%xmm0
  685804:	f3 0f 11 44 24 08    	movss  %xmm0,0x8(%rsp)
  68580a:	48 8b 9c 24 78 01 00 	mov    0x178(%rsp),%rbx
  685811:	00 
  685812:	48 3b 9c 24 68 01 00 	cmp    0x168(%rsp),%rbx
  685819:	00 
  68581a:	75 0e                	jne    68582a <<gpui_canvas::text::planner::Planner>::shape+0x12ba>
  68581c:	48 8d bc 24 68 01 00 	lea    0x168(%rsp),%rdi
  685823:	00 
  685824:	ff 15 76 53 10 00    	call   *0x105376(%rip)        # 78aba0 <_DYNAMIC+0x958>
  68582a:	41 01 ef             	add    %ebp,%r15d
  68582d:	41 01 ee             	add    %ebp,%r14d
  685830:	0f 28 94 24 a0 01 00 	movaps 0x1a0(%rsp),%xmm2
  685837:	00 
  685838:	0f 28 c2             	movaps %xmm2,%xmm0
  68583b:	f3 0f c2 c2 03       	cmpunordss %xmm2,%xmm0
  685840:	0f 28 c8             	movaps %xmm0,%xmm1
  685843:	0f 55 ca             	andnps %xmm2,%xmm1
  685846:	0f 54 84 24 90 02 00 	andps  0x290(%rsp),%xmm0
  68584d:	00 
  68584e:	0f 56 c1             	orps   %xmm1,%xmm0
  685851:	f3 0f 10 4c 24 1c    	movss  0x1c(%rsp),%xmm1
  685857:	f3 0f 58 c8          	addss  %xmm0,%xmm1
  68585b:	0f 28 a4 24 20 01 00 	movaps 0x120(%rsp),%xmm4
  685862:	00 
  685863:	0f 28 d4             	movaps %xmm4,%xmm2
  685866:	f3 0f c2 d4 03       	cmpunordss %xmm4,%xmm2
  68586b:	0f 28 da             	movaps %xmm2,%xmm3
  68586e:	0f 55 dc             	andnps %xmm4,%xmm3
  685871:	0f 54 94 24 d0 01 00 	andps  0x1d0(%rsp),%xmm2
  685878:	00 
  685879:	0f 56 d3             	orps   %xmm3,%xmm2
  68587c:	f3 0f 5c d0          	subss  %xmm0,%xmm2
  685880:	48 8b 84 24 70 01 00 	mov    0x170(%rsp),%rax
  685887:	00 
  685888:	48 8d 0c 5b          	lea    (%rbx,%rbx,2),%rcx
  68588c:	44 89 3c c8          	mov    %r15d,(%rax,%rcx,8)
  685890:	44 89 74 c8 04       	mov    %r14d,0x4(%rax,%rcx,8)
  685895:	f3 0f 11 4c c8 08    	movss  %xmm1,0x8(%rax,%rcx,8)
  68589b:	f3 0f 11 54 c8 0c    	movss  %xmm2,0xc(%rax,%rcx,8)
  6858a1:	f3 0f 10 44 24 08    	movss  0x8(%rsp),%xmm0
  6858a7:	f3 0f 11 44 c8 10    	movss  %xmm0,0x10(%rax,%rcx,8)
  6858ad:	f3 0f 10 44 24 60    	movss  0x60(%rsp),%xmm0
  6858b3:	f3 0f 11 44 c8 14    	movss  %xmm0,0x14(%rax,%rcx,8)
  6858b9:	48 ff c3             	inc    %rbx
  6858bc:	48 89 9c 24 78 01 00 	mov    %rbx,0x178(%rsp)
  6858c3:	00 
  6858c4:	44 89 b4 24 18 02 00 	mov    %r14d,0x218(%rsp)
  6858cb:	00 
  6858cc:	8b 4c 24 78          	mov    0x78(%rsp),%ecx
  6858d0:	48 c7 84 24 10 07 00 	movq   $0x0,0x710(%rsp)
  6858d7:	00 00 00 00 00 
  6858dc:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  6858e1:	48 89 84 24 18 07 00 	mov    %rax,0x718(%rsp)
  6858e8:	00 
  6858e9:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  6858f0:	00 
  6858f1:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
  6858f8:	00 
  6858f9:	48 83 c0 70          	add    $0x70,%rax
  6858fd:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
  685904:	00 
  685905:	89 8c 24 28 07 00 00 	mov    %ecx,0x728(%rsp)
  68590c:	ff c1                	inc    %ecx
  68590e:	89 4c 24 78          	mov    %ecx,0x78(%rsp)
  685912:	c6 84 24 d0 07 00 00 	movb   $0x2,0x7d0(%rsp)
  685919:	02 
  68591a:	c7 84 24 d8 07 00 00 	movl   $0x0,0x7d8(%rsp)
  685921:	00 00 00 00 
  685925:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
  68592c:	00 
  68592d:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
  685934:	00 
  685935:	e8 e6 86 ff ff       	call   67e020 <<parley::layout::line::GlyphRunIter<()> as core::iter::traits::iterator::Iterator>::next>
  68593a:	83 bc 24 40 03 00 00 	cmpl   $0x1,0x340(%rsp)
  685941:	01 
  685942:	0f 85 4a 0f 00 00    	jne    686892 <<gpui_canvas::text::planner::Planner>::shape+0x2322>
  685948:	48 8b 84 24 48 03 00 	mov    0x348(%rsp),%rax
  68594f:	00 
  685950:	48 85 c0             	test   %rax,%rax
  685953:	0f 84 d1 1b 00 00    	je     68752a <<gpui_canvas::text::planner::Planner>::shape+0x2fba>
  685959:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
  685960:	00 
  685961:	41 0f 10 45 00       	movups 0x0(%r13),%xmm0
  685966:	41 0f 10 4d 10       	movups 0x10(%r13),%xmm1
  68596b:	41 0f 10 55 20       	movups 0x20(%r13),%xmm2
  685970:	41 0f 10 5d 30       	movups 0x30(%r13),%xmm3
  685975:	48 8d 8c 24 a0 03 00 	lea    0x3a0(%rsp),%rcx
  68597c:	00 
  68597d:	0f 11 59 30          	movups %xmm3,0x30(%rcx)
  685981:	0f 11 51 20          	movups %xmm2,0x20(%rcx)
  685985:	0f 11 49 10          	movups %xmm1,0x10(%rcx)
  685989:	0f 11 01             	movups %xmm0,(%rcx)
  68598c:	4c 8b 9c 24 a0 03 00 	mov    0x3a0(%rsp),%r11
  685993:	00 
  685994:	49 8b 4b 30          	mov    0x30(%r11),%rcx
  685998:	49 8b 73 38          	mov    0x38(%r11),%rsi
  68599c:	48 89 f2             	mov    %rsi,%rdx
  68599f:	48 29 ca             	sub    %rcx,%rdx
  6859a2:	40 0f 92 c7          	setb   %dil
  6859a6:	48 3b b0 d0 00 00 00 	cmp    0xd0(%rax),%rsi
  6859ad:	40 0f 97 c6          	seta   %sil
  6859b1:	48 01 c9             	add    %rcx,%rcx
  6859b4:	48 03 88 c8 00 00 00 	add    0xc8(%rax),%rcx
  6859bb:	40 08 fe             	or     %dil,%sil
  6859be:	40 84 f6             	test   %sil,%sil
  6859c1:	be 00 00 00 00       	mov    $0x0,%esi
  6859c6:	48 0f 45 d6          	cmovne %rsi,%rdx
  6859ca:	be 02 00 00 00       	mov    $0x2,%esi
  6859cf:	48 0f 45 ce          	cmovne %rsi,%rcx
  6859d3:	48 01 d2             	add    %rdx,%rdx
  6859d6:	31 f6                	xor    %esi,%esi
  6859d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  6859df:	00 
  6859e0:	48 39 f2             	cmp    %rsi,%rdx
  6859e3:	74 10                	je     6859f5 <<gpui_canvas::text::planner::Planner>::shape+0x1485>
  6859e5:	66 83 3c 31 00       	cmpw   $0x0,(%rcx,%rsi,1)
  6859ea:	48 8d 76 02          	lea    0x2(%rsi),%rsi
  6859ee:	74 f0                	je     6859e0 <<gpui_canvas::text::planner::Planner>::shape+0x1470>
  6859f0:	e9 77 17 00 00       	jmp    68716c <<gpui_canvas::text::planner::Planner>::shape+0x2bfc>
  6859f5:	49 8b 4b 40          	mov    0x40(%r11),%rcx
  6859f9:	48 3b 88 b8 00 00 00 	cmp    0xb8(%rax),%rcx
  685a00:	0f 83 d4 20 00 00    	jae    687ada <<gpui_canvas::text::planner::Planner>::shape+0x356a>
  685a06:	48 c1 e1 06          	shl    $0x6,%rcx
  685a0a:	48 03 88 b0 00 00 00 	add    0xb0(%rax),%rcx
  685a11:	48 8b 34 24          	mov    (%rsp),%rsi
  685a15:	83 3e 01             	cmpl   $0x1,(%rsi)
  685a18:	75 0f                	jne    685a29 <<gpui_canvas::text::planner::Planner>::shape+0x14b9>
  685a1a:	48 8b 56 08          	mov    0x8(%rsi),%rdx
  685a1e:	48 3b 51 10          	cmp    0x10(%rcx),%rdx
  685a22:	75 05                	jne    685a29 <<gpui_canvas::text::planner::Planner>::shape+0x14b9>
  685a24:	45 31 c0             	xor    %r8d,%r8d
  685a27:	eb 4c                	jmp    685a75 <<gpui_canvas::text::planner::Planner>::shape+0x1505>
  685a29:	83 7e 10 01          	cmpl   $0x1,0x10(%rsi)
  685a2d:	75 10                	jne    685a3f <<gpui_canvas::text::planner::Planner>::shape+0x14cf>
  685a2f:	48 8b 56 18          	mov    0x18(%rsi),%rdx
  685a33:	41 b8 01 00 00 00    	mov    $0x1,%r8d
  685a39:	48 3b 51 10          	cmp    0x10(%rcx),%rdx
  685a3d:	74 1e                	je     685a5d <<gpui_canvas::text::planner::Planner>::shape+0x14ed>
  685a3f:	83 7e 20 01          	cmpl   $0x1,0x20(%rsi)
  685a43:	0f 85 0f 1b 00 00    	jne    687558 <<gpui_canvas::text::planner::Planner>::shape+0x2fe8>
  685a49:	48 8b 56 28          	mov    0x28(%rsi),%rdx
  685a4d:	41 b8 02 00 00 00    	mov    $0x2,%r8d
  685a53:	48 3b 51 10          	cmp    0x10(%rcx),%rdx
  685a57:	0f 85 fb 1a 00 00    	jne    687558 <<gpui_canvas::text::planner::Planner>::shape+0x2fe8>
  685a5d:	41 8d 48 ff          	lea    -0x1(%r8),%ecx
  685a61:	48 8b 94 24 08 02 00 	mov    0x208(%rsp),%rdx
  685a68:	00 
  685a69:	48 0f ab ca          	bts    %rcx,%rdx
  685a6d:	48 89 94 24 08 02 00 	mov    %rdx,0x208(%rsp)
  685a74:	00 
  685a75:	8b bc 24 c0 03 00 00 	mov    0x3c0(%rsp),%edi
  685a7c:	48 8b 70 58          	mov    0x58(%rax),%rsi
  685a80:	48 39 fe             	cmp    %rdi,%rsi
  685a83:	0f 86 17 21 00 00    	jbe    687ba0 <<gpui_canvas::text::planner::Planner>::shape+0x3630>
  685a89:	48 8b 94 24 b0 03 00 	mov    0x3b0(%rsp),%rdx
  685a90:	00 
  685a91:	48 85 d2             	test   %rdx,%rdx
  685a94:	4c 89 84 24 60 02 00 	mov    %r8,0x260(%rsp)
  685a9b:	00 
  685a9c:	48 89 94 24 e8 02 00 	mov    %rdx,0x2e8(%rsp)
  685aa3:	00 
  685aa4:	74 0a                	je     685ab0 <<gpui_canvas::text::planner::Planner>::shape+0x1540>
  685aa6:	48 8d 4a 18          	lea    0x18(%rdx),%rcx
  685aaa:	48 83 c2 1c          	add    $0x1c,%rdx
  685aae:	eb 1b                	jmp    685acb <<gpui_canvas::text::planner::Planner>::shape+0x155b>
  685ab0:	48 8b 48 50          	mov    0x50(%rax),%rcx
  685ab4:	48 8d 34 ff          	lea    (%rdi,%rdi,8),%rsi
  685ab8:	48 c1 e6 04          	shl    $0x4,%rsi
  685abc:	48 8d 14 31          	lea    (%rcx,%rsi,1),%rdx
  685ac0:	48 83 c2 54          	add    $0x54,%rdx
  685ac4:	48 01 f1             	add    %rsi,%rcx
  685ac7:	48 83 c1 50          	add    $0x50,%rcx
  685acb:	48 8b b4 24 f8 00 00 	mov    0xf8(%rsp),%rsi
  685ad2:	00 
  685ad3:	48 89 b4 24 f0 02 00 	mov    %rsi,0x2f0(%rsp)
  685ada:	00 
  685adb:	48 8b 70 68          	mov    0x68(%rax),%rsi
  685adf:	48 8b 78 70          	mov    0x70(%rax),%rdi
  685ae3:	4c 8b 80 80 00 00 00 	mov    0x80(%rax),%r8
  685aea:	4c 8b 88 88 00 00 00 	mov    0x88(%rax),%r9
  685af1:	4c 8b 90 98 00 00 00 	mov    0x98(%rax),%r10
  685af8:	48 8b 80 a0 00 00 00 	mov    0xa0(%rax),%rax
  685aff:	8b 12                	mov    (%rdx),%edx
  685b01:	8b 09                	mov    (%rcx),%ecx
  685b03:	4c 89 9c 24 48 02 00 	mov    %r11,0x248(%rsp)
  685b0a:	00 
  685b0b:	45 0f b6 9b 8c 00 00 	movzbl 0x8c(%r11),%r11d
  685b12:	00 
  685b13:	41 80 e3 01          	and    $0x1,%r11b
  685b17:	89 d3                	mov    %edx,%ebx
  685b19:	29 cb                	sub    %ecx,%ebx
  685b1b:	48 c7 84 24 c0 04 00 	movq   $0x0,0x4c0(%rsp)
  685b22:	00 00 00 00 00 
  685b27:	48 c7 84 24 e0 04 00 	movq   $0x0,0x4e0(%rsp)
  685b2e:	00 00 00 00 00 
  685b33:	c7 84 24 00 05 00 00 	movl   $0x0,0x500(%rsp)
  685b3a:	00 00 00 00 
  685b3e:	89 9c 24 04 05 00 00 	mov    %ebx,0x504(%rsp)
  685b45:	48 89 b4 24 08 05 00 	mov    %rsi,0x508(%rsp)
  685b4c:	00 
  685b4d:	48 89 bc 24 10 05 00 	mov    %rdi,0x510(%rsp)
  685b54:	00 
  685b55:	4c 89 84 24 18 05 00 	mov    %r8,0x518(%rsp)
  685b5c:	00 
  685b5d:	4c 89 8c 24 20 05 00 	mov    %r9,0x520(%rsp)
  685b64:	00 
  685b65:	4c 89 94 24 28 05 00 	mov    %r10,0x528(%rsp)
  685b6c:	00 
  685b6d:	48 89 84 24 30 05 00 	mov    %rax,0x530(%rsp)
  685b74:	00 
  685b75:	89 8c 24 38 05 00 00 	mov    %ecx,0x538(%rsp)
  685b7c:	89 94 24 3c 05 00 00 	mov    %edx,0x53c(%rsp)
  685b83:	89 8c 24 40 05 00 00 	mov    %ecx,0x540(%rsp)
  685b8a:	89 94 24 44 05 00 00 	mov    %edx,0x544(%rsp)
  685b91:	44 88 9c 24 48 05 00 	mov    %r11b,0x548(%rsp)
  685b98:	00 
  685b99:	f2 0f 10 84 24 d0 03 	movsd  0x3d0(%rsp),%xmm0
  685ba0:	00 00 
  685ba2:	0f 29 84 24 e0 03 00 	movaps %xmm0,0x3e0(%rsp)
  685ba9:	00 
  685baa:	8b 94 24 c8 03 00 00 	mov    0x3c8(%rsp),%edx
  685bb1:	8b 8c 24 cc 03 00 00 	mov    0x3cc(%rsp),%ecx
  685bb8:	48 8d bc 24 f8 03 00 	lea    0x3f8(%rsp),%rdi
  685bbf:	00 
  685bc0:	48 8d b4 24 98 03 00 	lea    0x398(%rsp),%rsi
  685bc7:	00 
  685bc8:	e8 03 1d fe ff       	call   6678d0 <<parley::layout::run::Run<()>>::glyphs_in>
  685bcd:	0f 28 94 24 e0 03 00 	movaps 0x3e0(%rsp),%xmm2
  685bd4:	00 
  685bd5:	0f 13 94 24 90 04 00 	movlps %xmm2,0x490(%rsp)
  685bdc:	00 
  685bdd:	48 8b 9c 24 f8 03 00 	mov    0x3f8(%rsp),%rbx
  685be4:	00 
  685be5:	48 8b 84 24 00 04 00 	mov    0x400(%rsp),%rax
  685bec:	00 
  685bed:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  685bf4:	00 
  685bf5:	0f b6 84 24 08 04 00 	movzbl 0x408(%rsp),%eax
  685bfc:	00 
  685bfd:	8b 8c 24 0c 04 00 00 	mov    0x40c(%rsp),%ecx
  685c04:	89 8c 24 bc 01 00 00 	mov    %ecx,0x1bc(%rsp)
  685c0b:	f2 0f 10 84 24 10 04 	movsd  0x410(%rsp),%xmm0
  685c12:	00 00 
  685c14:	0f 29 84 24 30 02 00 	movaps %xmm0,0x230(%rsp)
  685c1b:	00 
  685c1c:	f3 0f 10 84 24 18 04 	movss  0x418(%rsp),%xmm0
  685c23:	00 00 
  685c25:	f3 0f 11 84 24 b8 01 	movss  %xmm0,0x1b8(%rsp)
  685c2c:	00 00 
  685c2e:	48 8b 8c 24 20 04 00 	mov    0x420(%rsp),%rcx
  685c35:	00 
  685c36:	48 89 8c 24 68 02 00 	mov    %rcx,0x268(%rsp)
  685c3d:	00 
  685c3e:	48 8b 8c 24 28 04 00 	mov    0x428(%rsp),%rcx
  685c45:	00 
  685c46:	48 89 8c 24 00 02 00 	mov    %rcx,0x200(%rsp)
  685c4d:	00 
  685c4e:	48 8b 94 24 30 04 00 	mov    0x430(%rsp),%rdx
  685c55:	00 
  685c56:	4c 8b b4 24 38 04 00 	mov    0x438(%rsp),%r14
  685c5d:	00 
  685c5e:	48 8b 8c 24 40 04 00 	mov    0x440(%rsp),%rcx
  685c65:	00 
  685c66:	48 89 8c 24 78 02 00 	mov    %rcx,0x278(%rsp)
  685c6d:	00 
  685c6e:	48 8b 8c 24 48 04 00 	mov    0x448(%rsp),%rcx
  685c75:	00 
  685c76:	48 89 8c 24 40 01 00 	mov    %rcx,0x140(%rsp)
  685c7d:	00 
  685c7e:	8b 8c 24 50 04 00 00 	mov    0x450(%rsp),%ecx
  685c85:	48 89 8c 24 f0 01 00 	mov    %rcx,0x1f0(%rsp)
  685c8c:	00 
  685c8d:	8b 8c 24 54 04 00 00 	mov    0x454(%rsp),%ecx
  685c94:	48 89 8c 24 f8 01 00 	mov    %rcx,0x1f8(%rsp)
  685c9b:	00 
  685c9c:	8b 8c 24 58 04 00 00 	mov    0x458(%rsp),%ecx
  685ca3:	48 89 8c 24 20 01 00 	mov    %rcx,0x120(%rsp)
  685caa:	00 
  685cab:	44 8b bc 24 5c 04 00 	mov    0x45c(%rsp),%r15d
  685cb2:	00 
  685cb3:	f3 0f 10 84 24 60 04 	movss  0x460(%rsp),%xmm0
  685cba:	00 00 
  685cbc:	f3 0f 11 84 24 c0 01 	movss  %xmm0,0x1c0(%rsp)
  685cc3:	00 00 
  685cc5:	f3 0f 10 84 24 64 04 	movss  0x464(%rsp),%xmm0
  685ccc:	00 00 
  685cce:	f3 0f 11 44 24 58    	movss  %xmm0,0x58(%rsp)
  685cd4:	48 8b 8c 24 68 04 00 	mov    0x468(%rsp),%rcx
  685cdb:	00 
  685cdc:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
  685ce1:	f3 0f 10 84 24 80 04 	movss  0x480(%rsp),%xmm0
  685ce8:	00 00 
  685cea:	f3 0f 10 8c 24 7c 04 	movss  0x47c(%rsp),%xmm1
  685cf1:	00 00 
  685cf3:	f3 0f 11 84 24 28 02 	movss  %xmm0,0x228(%rsp)
  685cfa:	00 00 
  685cfc:	f3 0f 58 c8          	addss  %xmm0,%xmm1
  685d00:	f3 0f 10 84 24 84 04 	movss  0x484(%rsp),%xmm0
  685d07:	00 00 
  685d09:	f3 0f 11 8c 24 24 02 	movss  %xmm1,0x224(%rsp)
  685d10:	00 00 
  685d12:	f3 0f 58 c1          	addss  %xmm1,%xmm0
  685d16:	f3 0f 11 84 24 1c 02 	movss  %xmm0,0x21c(%rsp)
  685d1d:	00 00 
  685d1f:	0f 28 c2             	movaps %xmm2,%xmm0
  685d22:	0f b6 8c 24 8c 04 00 	movzbl 0x48c(%rsp),%ecx
  685d29:	00 
  685d2a:	88 8c 24 90 02 00 00 	mov    %cl,0x290(%rsp)
  685d31:	48 8b 8c 24 70 04 00 	mov    0x470(%rsp),%rcx
  685d38:	00 
  685d39:	48 89 8c 24 38 01 00 	mov    %rcx,0x138(%rsp)
  685d40:	00 
  685d41:	8b 8c 24 78 04 00 00 	mov    0x478(%rsp),%ecx
  685d48:	89 8c 24 dc 00 00 00 	mov    %ecx,0xdc(%rsp)
  685d4f:	8b 8c 24 88 04 00 00 	mov    0x488(%rsp),%ecx
  685d56:	89 8c 24 20 02 00 00 	mov    %ecx,0x220(%rsp)
  685d5d:	48 8d 4a 16          	lea    0x16(%rdx),%rcx
  685d61:	48 89 8c 24 50 02 00 	mov    %rcx,0x250(%rsp)
  685d68:	00 
  685d69:	48 89 94 24 d0 01 00 	mov    %rdx,0x1d0(%rsp)
  685d70:	00 
  685d71:	48 8d 4a 2e          	lea    0x2e(%rdx),%rcx
  685d75:	48 89 8c 24 00 03 00 	mov    %rcx,0x300(%rsp)
  685d7c:	00 
  685d7d:	4c 89 b4 24 e8 01 00 	mov    %r14,0x1e8(%rsp)
  685d84:	00 
  685d85:	eb 6e                	jmp    685df5 <<gpui_canvas::text::planner::Planner>::shape+0x1885>
  685d87:	03 6c 24 30          	add    0x30(%rsp),%ebp
  685d8b:	0f 28 8c 24 a0 01 00 	movaps 0x1a0(%rsp),%xmm1
  685d92:	00 
  685d93:	f3 0f 58 4c 24 1c    	addss  0x1c(%rsp),%xmm1
  685d99:	48 8b 84 24 f0 00 00 	mov    0xf0(%rsp),%rax
  685da0:	00 
  685da1:	4c 89 f1             	mov    %r14,%rcx
  685da4:	48 c1 e1 04          	shl    $0x4,%rcx
  685da8:	89 2c 08             	mov    %ebp,(%rax,%rcx,1)
  685dab:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  685db1:	f3 0f 11 44 08 04    	movss  %xmm0,0x4(%rax,%rcx,1)
  685db7:	f3 0f 11 4c 08 08    	movss  %xmm1,0x8(%rax,%rcx,1)
  685dbd:	8b 54 24 5c          	mov    0x5c(%rsp),%edx
  685dc1:	66 89 54 08 0c       	mov    %dx,0xc(%rax,%rcx,1)
  685dc6:	48 8b 94 24 60 02 00 	mov    0x260(%rsp),%rdx
  685dcd:	00 
  685dce:	88 54 08 0e          	mov    %dl,0xe(%rax,%rcx,1)
  685dd2:	c6 44 08 0f 00       	movb   $0x0,0xf(%rax,%rcx,1)
  685dd7:	49 ff c6             	inc    %r14
  685dda:	4c 89 b4 24 f8 00 00 	mov    %r14,0xf8(%rsp)
  685de1:	00 
  685de2:	31 c0                	xor    %eax,%eax
  685de4:	4c 8b b4 24 e8 01 00 	mov    0x1e8(%rsp),%r14
  685deb:	00 
  685dec:	f3 0f 10 84 24 c4 01 	movss  0x1c4(%rsp),%xmm0
  685df3:	00 00 
  685df5:	f3 0f 11 44 24 0c    	movss  %xmm0,0xc(%rsp)
  685dfb:	a8 01                	test   $0x1,%al
  685dfd:	74 61                	je     685e60 <<gpui_canvas::text::planner::Planner>::shape+0x18f0>
  685dff:	f3 0f 10 84 24 b8 01 	movss  0x1b8(%rsp),%xmm0
  685e06:	00 00 
  685e08:	f3 0f 11 44 24 08    	movss  %xmm0,0x8(%rsp)
  685e0e:	8b 84 24 bc 01 00 00 	mov    0x1bc(%rsp),%eax
  685e15:	89 44 24 5c          	mov    %eax,0x5c(%rsp)
  685e19:	0f 28 84 24 30 02 00 	movaps 0x230(%rsp),%xmm0
  685e20:	00 
  685e21:	0f 29 84 24 a0 01 00 	movaps %xmm0,0x1a0(%rsp)
  685e28:	00 
  685e29:	83 bc 24 dc 00 00 00 	cmpl   $0x0,0xdc(%rsp)
  685e30:	00 
  685e31:	74 71                	je     685ea4 <<gpui_canvas::text::planner::Planner>::shape+0x1934>
  685e33:	48 83 7c 24 60 00    	cmpq   $0x0,0x60(%rsp)
  685e39:	74 7c                	je     685eb7 <<gpui_canvas::text::planner::Planner>::shape+0x1947>
  685e3b:	0f 28 84 24 a0 01 00 	movaps 0x1a0(%rsp),%xmm0
  685e42:	00 
  685e43:	f3 0f 11 84 24 d8 00 	movss  %xmm0,0xd8(%rsp)
  685e4a:	00 00 
  685e4c:	e9 94 00 00 00       	jmp    685ee5 <<gpui_canvas::text::planner::Planner>::shape+0x1975>
  685e51:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  685e58:	0f 1f 84 00 00 00 00 
  685e5f:	00 
  685e60:	48 3b 9c 24 c0 00 00 	cmp    0xc0(%rsp),%rbx
  685e67:	00 
  685e68:	0f 84 3d 01 00 00    	je     685fab <<gpui_canvas::text::planner::Planner>::shape+0x1a3b>
  685e6e:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  685e73:	8b 03                	mov    (%rbx),%eax
  685e75:	89 44 24 5c          	mov    %eax,0x5c(%rsp)
  685e79:	f2 0f 10 43 04       	movsd  0x4(%rbx),%xmm0
  685e7e:	0f 29 84 24 a0 01 00 	movaps %xmm0,0x1a0(%rsp)
  685e85:	00 
  685e86:	f3 0f 10 43 0c       	movss  0xc(%rbx),%xmm0
  685e8b:	f3 0f 11 44 24 08    	movss  %xmm0,0x8(%rsp)
  685e91:	48 83 c3 10          	add    $0x10,%rbx
  685e95:	48 89 54 24 60       	mov    %rdx,0x60(%rsp)
  685e9a:	83 bc 24 dc 00 00 00 	cmpl   $0x0,0xdc(%rsp)
  685ea1:	00 
  685ea2:	75 8f                	jne    685e33 <<gpui_canvas::text::planner::Planner>::shape+0x18c3>
  685ea4:	0f 28 84 24 a0 01 00 	movaps 0x1a0(%rsp),%xmm0
  685eab:	00 
  685eac:	f3 0f 11 84 24 d8 00 	movss  %xmm0,0xd8(%rsp)
  685eb3:	00 00 
  685eb5:	eb 5f                	jmp    685f16 <<gpui_canvas::text::planner::Planner>::shape+0x19a6>
  685eb7:	f3 0f 10 84 24 c0 01 	movss  0x1c0(%rsp),%xmm0
  685ebe:	00 00 
  685ec0:	0f 28 c8             	movaps %xmm0,%xmm1
  685ec3:	f3 0f 58 8c 24 a0 01 	addss  0x1a0(%rsp),%xmm1
  685eca:	00 00 
  685ecc:	f3 0f 11 8c 24 d8 00 	movss  %xmm1,0xd8(%rsp)
  685ed3:	00 00 
  685ed5:	f3 0f 10 4c 24 08    	movss  0x8(%rsp),%xmm1
  685edb:	f3 0f 58 c8          	addss  %xmm0,%xmm1
  685edf:	f3 0f 11 4c 24 08    	movss  %xmm1,0x8(%rsp)
  685ee5:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  685eea:	48 ff c2             	inc    %rdx
  685eed:	48 8b 84 24 38 01 00 	mov    0x138(%rsp),%rax
  685ef4:	00 
  685ef5:	48 89 54 24 60       	mov    %rdx,0x60(%rsp)
  685efa:	48 39 c2             	cmp    %rax,%rdx
  685efd:	75 17                	jne    685f16 <<gpui_canvas::text::planner::Planner>::shape+0x19a6>
  685eff:	f3 0f 10 44 24 08    	movss  0x8(%rsp),%xmm0
  685f05:	f3 0f 58 44 24 58    	addss  0x58(%rsp),%xmm0
  685f0b:	f3 0f 11 44 24 08    	movss  %xmm0,0x8(%rsp)
  685f11:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  685f16:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
  685f1d:	00 
  685f1e:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
  685f25:	00 
  685f26:	e8 95 26 00 00       	call   6885c0 <<core::iter::adapters::flatten::FlattenCompat<core::iter::adapters::map::Map<core::ops::range::Range<u32>, <parley::layout::run::Run<()>>::glyph_source_ranges::{closure#0}>, core::iter::sources::repeat_n::RepeatN<core::ops::range::Range<usize>>> as core::iter::traits::iterator::Iterator>::next>
  685f2b:	83 bc 24 88 00 00 00 	cmpl   $0x1,0x88(%rsp)
  685f32:	01 
  685f33:	0f 85 e0 15 00 00    	jne    687519 <<gpui_canvas::text::planner::Planner>::shape+0x2fa9>
  685f39:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  685f3f:	f3 0f 58 44 24 08    	addss  0x8(%rsp),%xmm0
  685f45:	31 c0                	xor    %eax,%eax
  685f47:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  685f4c:	48 39 8c 24 00 01 00 	cmp    %rcx,0x100(%rsp)
  685f53:	00 
  685f54:	0f 84 9b fe ff ff    	je     685df5 <<gpui_canvas::text::planner::Planner>::shape+0x1885>
  685f5a:	f3 0f 11 84 24 c4 01 	movss  %xmm0,0x1c4(%rsp)
  685f61:	00 00 
  685f63:	4c 8b 8c 24 90 00 00 	mov    0x90(%rsp),%r9
  685f6a:	00 
  685f6b:	48 8b ac 24 98 00 00 	mov    0x98(%rsp),%rbp
  685f72:	00 
  685f73:	49 39 e9             	cmp    %rbp,%r9
  685f76:	48 8b 8c 24 10 01 00 	mov    0x110(%rsp),%rcx
  685f7d:	00 
  685f7e:	0f 87 85 15 00 00    	ja     687509 <<gpui_canvas::text::planner::Planner>::shape+0x2f99>
  685f84:	4d 85 c9             	test   %r9,%r9
  685f87:	0f 84 f7 04 00 00    	je     686484 <<gpui_canvas::text::planner::Planner>::shape+0x1f14>
  685f8d:	49 39 c9             	cmp    %rcx,%r9
  685f90:	0f 83 e8 04 00 00    	jae    68647e <<gpui_canvas::text::planner::Planner>::shape+0x1f0e>
  685f96:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  685f9b:	42 80 3c 08 bf       	cmpb   $0xbf,(%rax,%r9,1)
  685fa0:	0f 8f de 04 00 00    	jg     686484 <<gpui_canvas::text::planner::Planner>::shape+0x1f14>
  685fa6:	e9 5e 15 00 00       	jmp    687509 <<gpui_canvas::text::planner::Planner>::shape+0x2f99>
  685fab:	48 89 9c 24 c0 00 00 	mov    %rbx,0xc0(%rsp)
  685fb2:	00 
  685fb3:	f6 84 24 90 02 00 00 	testb  $0x1,0x290(%rsp)
  685fba:	01 
  685fbb:	74 19                	je     685fd6 <<gpui_canvas::text::planner::Planner>::shape+0x1a66>
  685fbd:	4c 89 fa             	mov    %r15,%rdx
  685fc0:	48 8b 8c 24 20 01 00 	mov    0x120(%rsp),%rcx
  685fc7:	00 
  685fc8:	39 d1                	cmp    %edx,%ecx
  685fca:	0f 83 3d 01 00 00    	jae    68610d <<gpui_canvas::text::planner::Planner>::shape+0x1b9d>
  685fd0:	ff ca                	dec    %edx
  685fd2:	89 d0                	mov    %edx,%eax
  685fd4:	eb 19                	jmp    685fef <<gpui_canvas::text::planner::Planner>::shape+0x1a7f>
  685fd6:	4c 89 fa             	mov    %r15,%rdx
  685fd9:	48 8b ac 24 20 01 00 	mov    0x120(%rsp),%rbp
  685fe0:	00 
  685fe1:	39 d5                	cmp    %edx,%ebp
  685fe3:	0f 83 3f 01 00 00    	jae    686128 <<gpui_canvas::text::planner::Planner>::shape+0x1bb8>
  685fe9:	8d 4d 01             	lea    0x1(%rbp),%ecx
  685fec:	48 89 e8             	mov    %rbp,%rax
  685fef:	89 c7                	mov    %eax,%edi
  685ff1:	49 39 fe             	cmp    %rdi,%r14
  685ff4:	0f 86 29 1b 00 00    	jbe    687b23 <<gpui_canvas::text::planner::Planner>::shape+0x35b3>
  685ffa:	49 89 d7             	mov    %rdx,%r15
  685ffd:	48 8d 04 7f          	lea    (%rdi,%rdi,2),%rax
  686001:	48 8b 94 24 d0 01 00 	mov    0x1d0(%rsp),%rdx
  686008:	00 
  686009:	8b 5c c2 08          	mov    0x8(%rdx,%rax,8),%ebx
  68600d:	f6 44 c2 17 01       	testb  $0x1,0x17(%rdx,%rax,8)
  686012:	0f 85 63 05 00 00    	jne    68657b <<gpui_canvas::text::planner::Planner>::shape+0x200b>
  686018:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
  68601c:	8b 50 0c             	mov    0xc(%rax),%edx
  68601f:	48 8d 34 1a          	lea    (%rdx,%rbx,1),%rsi
  686023:	48 3b b4 24 40 01 00 	cmp    0x140(%rsp),%rsi
  68602a:	00 
  68602b:	0f 87 27 17 00 00    	ja     687758 <<gpui_canvas::text::planner::Planner>::shape+0x31e8>
  686031:	48 c1 e3 04          	shl    $0x4,%rbx
  686035:	48 03 9c 24 78 02 00 	add    0x278(%rsp),%rbx
  68603c:	00 
  68603d:	48 89 d0             	mov    %rdx,%rax
  686040:	48 c1 e0 04          	shl    $0x4,%rax
  686044:	48 01 d8             	add    %rbx,%rax
  686047:	0f 57 c0             	xorps  %xmm0,%xmm0
  68604a:	0f 29 84 24 30 02 00 	movaps %xmm0,0x230(%rsp)
  686051:	00 
  686052:	48 85 d2             	test   %rdx,%rdx
  686055:	0f 85 bf 06 00 00    	jne    68671a <<gpui_canvas::text::planner::Planner>::shape+0x21aa>
  68605b:	89 ca                	mov    %ecx,%edx
  68605d:	48 89 94 24 20 01 00 	mov    %rdx,0x120(%rsp)
  686064:	00 
  686065:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  68606c:	00 00 00 00 
  686070:	f6 84 24 90 02 00 00 	testb  $0x1,0x290(%rsp)
  686077:	01 
  686078:	74 16                	je     686090 <<gpui_canvas::text::planner::Planner>::shape+0x1b20>
  68607a:	44 39 f9             	cmp    %r15d,%ecx
  68607d:	0f 83 c4 00 00 00    	jae    686147 <<gpui_canvas::text::planner::Planner>::shape+0x1bd7>
  686083:	41 ff cf             	dec    %r15d
  686086:	4c 89 f8             	mov    %r15,%rax
  686089:	89 ca                	mov    %ecx,%edx
  68608b:	89 c1                	mov    %eax,%ecx
  68608d:	eb 19                	jmp    6860a8 <<gpui_canvas::text::planner::Planner>::shape+0x1b38>
  68608f:	90                   	nop
  686090:	4c 89 fa             	mov    %r15,%rdx
  686093:	39 d1                	cmp    %edx,%ecx
  686095:	0f 83 5c 01 00 00    	jae    6861f7 <<gpui_canvas::text::planner::Planner>::shape+0x1c87>
  68609b:	8d 41 01             	lea    0x1(%rcx),%eax
  68609e:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
  6860a5:	00 
  6860a6:	89 c2                	mov    %eax,%edx
  6860a8:	89 cf                	mov    %ecx,%edi
  6860aa:	49 39 fe             	cmp    %rdi,%r14
  6860ad:	0f 86 70 1a 00 00    	jbe    687b23 <<gpui_canvas::text::planner::Planner>::shape+0x35b3>
  6860b3:	48 8d 04 7f          	lea    (%rdi,%rdi,2),%rax
  6860b7:	48 8b 8c 24 d0 01 00 	mov    0x1d0(%rsp),%rcx
  6860be:	00 
  6860bf:	8b 5c c1 08          	mov    0x8(%rcx,%rax,8),%ebx
  6860c3:	f6 44 c1 17 01       	testb  $0x1,0x17(%rcx,%rax,8)
  6860c8:	0f 85 a5 04 00 00    	jne    686573 <<gpui_canvas::text::planner::Planner>::shape+0x2003>
  6860ce:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
  6860d2:	8b 78 0c             	mov    0xc(%rax),%edi
  6860d5:	48 8d 34 1f          	lea    (%rdi,%rbx,1),%rsi
  6860d9:	48 3b b4 24 40 01 00 	cmp    0x140(%rsp),%rsi
  6860e0:	00 
  6860e1:	0f 87 71 16 00 00    	ja     687758 <<gpui_canvas::text::planner::Planner>::shape+0x31e8>
  6860e7:	48 c1 e3 04          	shl    $0x4,%rbx
  6860eb:	48 03 9c 24 78 02 00 	add    0x278(%rsp),%rbx
  6860f2:	00 
  6860f3:	48 89 f8             	mov    %rdi,%rax
  6860f6:	48 c1 e0 04          	shl    $0x4,%rax
  6860fa:	48 01 d8             	add    %rbx,%rax
  6860fd:	89 d1                	mov    %edx,%ecx
  6860ff:	48 85 ff             	test   %rdi,%rdi
  686102:	0f 84 68 ff ff ff    	je     686070 <<gpui_canvas::text::planner::Planner>::shape+0x1b00>
  686108:	e9 df 04 00 00       	jmp    6865ec <<gpui_canvas::text::planner::Planner>::shape+0x207c>
  68610d:	48 89 d8             	mov    %rbx,%rax
  686110:	3b 8c 24 f0 01 00 00 	cmp    0x1f0(%rsp),%ecx
  686117:	0f 95 c2             	setne  %dl
  68611a:	84 94 24 dc 00 00 00 	test   %dl,0xdc(%rsp)
  686121:	75 4e                	jne    686171 <<gpui_canvas::text::planner::Planner>::shape+0x1c01>
  686123:	e9 0c 06 00 00       	jmp    686734 <<gpui_canvas::text::planner::Planner>::shape+0x21c4>
  686128:	48 89 d8             	mov    %rbx,%rax
  68612b:	3b 94 24 f8 01 00 00 	cmp    0x1f8(%rsp),%edx
  686132:	0f 95 c1             	setne  %cl
  686135:	84 8c 24 dc 00 00 00 	test   %cl,0xdc(%rsp)
  68613c:	0f 85 df 00 00 00    	jne    686221 <<gpui_canvas::text::planner::Planner>::shape+0x1cb1>
  686142:	e9 ed 05 00 00       	jmp    686734 <<gpui_canvas::text::planner::Planner>::shape+0x21c4>
  686147:	0f 57 c0             	xorps  %xmm0,%xmm0
  68614a:	0f 29 84 24 30 02 00 	movaps %xmm0,0x230(%rsp)
  686151:	00 
  686152:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  686159:	00 
  68615a:	3b 8c 24 f0 01 00 00 	cmp    0x1f0(%rsp),%ecx
  686161:	0f 95 c2             	setne  %dl
  686164:	84 94 24 dc 00 00 00 	test   %dl,0xdc(%rsp)
  68616b:	0f 84 c3 05 00 00    	je     686734 <<gpui_canvas::text::planner::Planner>::shape+0x21c4>
  686171:	8d 79 ff             	lea    -0x1(%rcx),%edi
  686174:	49 39 fe             	cmp    %rdi,%r14
  686177:	0f 86 47 1a 00 00    	jbe    687bc4 <<gpui_canvas::text::planner::Planner>::shape+0x3654>
  68617d:	3b bc 24 f0 01 00 00 	cmp    0x1f0(%rsp),%edi
  686184:	76 48                	jbe    6861ce <<gpui_canvas::text::planner::Planner>::shape+0x1c5e>
  686186:	48 8d 14 7f          	lea    (%rdi,%rdi,2),%rdx
  68618a:	48 8b b4 24 50 02 00 	mov    0x250(%rsp),%rsi
  686191:	00 
  686192:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
  686196:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  68619d:	00 00 00 
  6861a0:	49 39 fe             	cmp    %rdi,%r14
  6861a3:	0f 86 9b 19 00 00    	jbe    687b44 <<gpui_canvas::text::planner::Planner>::shape+0x35d4>
  6861a9:	f6 42 01 02          	testb  $0x2,0x1(%rdx)
  6861ad:	75 1f                	jne    6861ce <<gpui_canvas::text::planner::Planner>::shape+0x1c5e>
  6861af:	48 ff cf             	dec    %rdi
  6861b2:	48 83 c2 e8          	add    $0xffffffffffffffe8,%rdx
  6861b6:	39 bc 24 f0 01 00 00 	cmp    %edi,0x1f0(%rsp)
  6861bd:	72 e1                	jb     6861a0 <<gpui_canvas::text::planner::Planner>::shape+0x1c30>
  6861bf:	48 8b 94 24 f0 01 00 	mov    0x1f0(%rsp),%rdx
  6861c6:	00 
  6861c7:	48 89 d7             	mov    %rdx,%rdi
  6861ca:	89 d5                	mov    %edx,%ebp
  6861cc:	eb 02                	jmp    6861d0 <<gpui_canvas::text::planner::Planner>::shape+0x1c60>
  6861ce:	89 fd                	mov    %edi,%ebp
  6861d0:	49 39 fe             	cmp    %rdi,%r14
  6861d3:	0f 86 f7 19 00 00    	jbe    687bd0 <<gpui_canvas::text::planner::Planner>::shape+0x3660>
  6861d9:	48 89 ac 24 20 01 00 	mov    %rbp,0x120(%rsp)
  6861e0:	00 
  6861e1:	89 ca                	mov    %ecx,%edx
  6861e3:	48 ff ca             	dec    %rdx
  6861e6:	4c 39 f2             	cmp    %r14,%rdx
  6861e9:	0f 83 ed 19 00 00    	jae    687bdc <<gpui_canvas::text::planner::Planner>::shape+0x366c>
  6861ef:	41 89 cf             	mov    %ecx,%r15d
  6861f2:	e9 a8 00 00 00       	jmp    68629f <<gpui_canvas::text::planner::Planner>::shape+0x1d2f>
  6861f7:	0f 57 c0             	xorps  %xmm0,%xmm0
  6861fa:	0f 29 84 24 30 02 00 	movaps %xmm0,0x230(%rsp)
  686201:	00 
  686202:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  686209:	00 
  68620a:	3b 94 24 f8 01 00 00 	cmp    0x1f8(%rsp),%edx
  686211:	0f 95 c1             	setne  %cl
  686214:	84 8c 24 dc 00 00 00 	test   %cl,0xdc(%rsp)
  68621b:	0f 84 13 05 00 00    	je     686734 <<gpui_canvas::text::planner::Planner>::shape+0x21c4>
  686221:	49 89 d0             	mov    %rdx,%r8
  686224:	48 89 d1             	mov    %rdx,%rcx
  686227:	89 cf                	mov    %ecx,%edi
  686229:	49 39 fe             	cmp    %rdi,%r14
  68622c:	0f 86 7d 19 00 00    	jbe    687baf <<gpui_canvas::text::planner::Planner>::shape+0x363f>
  686232:	44 8d 79 01          	lea    0x1(%rcx),%r15d
  686236:	44 3b bc 24 f8 01 00 	cmp    0x1f8(%rsp),%r15d
  68623d:	00 
  68623e:	73 48                	jae    686288 <<gpui_canvas::text::planner::Planner>::shape+0x1d18>
  686240:	44 89 fa             	mov    %r15d,%edx
  686243:	48 8d 0c 52          	lea    (%rdx,%rdx,2),%rcx
  686247:	48 8b b4 24 50 02 00 	mov    0x250(%rsp),%rsi
  68624e:	00 
  68624f:	48 8d 34 ce          	lea    (%rsi,%rcx,8),%rsi
  686253:	49 89 d7             	mov    %rdx,%r15
  686256:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  68625d:	00 00 00 
  686260:	4d 39 fe             	cmp    %r15,%r14
  686263:	0f 86 c3 18 00 00    	jbe    687b2c <<gpui_canvas::text::planner::Planner>::shape+0x35bc>
  686269:	f6 46 01 02          	testb  $0x2,0x1(%rsi)
  68626d:	75 19                	jne    686288 <<gpui_canvas::text::planner::Planner>::shape+0x1d18>
  68626f:	49 ff c7             	inc    %r15
  686272:	48 83 c6 18          	add    $0x18,%rsi
  686276:	4c 39 bc 24 f8 01 00 	cmp    %r15,0x1f8(%rsp)
  68627d:	00 
  68627e:	75 e0                	jne    686260 <<gpui_canvas::text::planner::Planner>::shape+0x1cf0>
  686280:	4c 8b bc 24 f8 01 00 	mov    0x1f8(%rsp),%r15
  686287:	00 
  686288:	44 89 fa             	mov    %r15d,%edx
  68628b:	48 ff ca             	dec    %rdx
  68628e:	4c 39 f2             	cmp    %r14,%rdx
  686291:	0f 83 21 19 00 00    	jae    687bb8 <<gpui_canvas::text::planner::Planner>::shape+0x3648>
  686297:	4c 89 84 24 20 01 00 	mov    %r8,0x120(%rsp)
  68629e:	00 
  68629f:	48 83 bc 24 68 02 00 	cmpq   $0x0,0x268(%rsp)
  6862a6:	00 00 
  6862a8:	0f 84 86 04 00 00    	je     686734 <<gpui_canvas::text::planner::Planner>::shape+0x21c4>
  6862ae:	48 8d 0c 7f          	lea    (%rdi,%rdi,2),%rcx
  6862b2:	48 8b b4 24 d0 01 00 	mov    0x1d0(%rsp),%rsi
  6862b9:	00 
  6862ba:	8b 0c ce             	mov    (%rsi,%rcx,8),%ecx
  6862bd:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
  6862c1:	8b 74 d6 04          	mov    0x4(%rsi,%rdx,8),%esi
  6862c5:	39 ce                	cmp    %ecx,%esi
  6862c7:	0f 82 b3 17 00 00    	jb     687a80 <<gpui_canvas::text::planner::Planner>::shape+0x3510>
  6862cd:	48 39 b4 24 00 02 00 	cmp    %rsi,0x200(%rsp)
  6862d4:	00 
  6862d5:	0f 82 a5 17 00 00    	jb     687a80 <<gpui_canvas::text::planner::Planner>::shape+0x3510>
  6862db:	39 ce                	cmp    %ecx,%esi
  6862dd:	0f 84 ad 18 00 00    	je     687b90 <<gpui_canvas::text::planner::Planner>::shape+0x3620>
  6862e3:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  6862e7:	48 8b 94 24 68 02 00 	mov    0x268(%rsp),%rdx
  6862ee:	00 
  6862ef:	0f b6 4c 8a 07       	movzbl 0x7(%rdx,%rcx,4),%ecx
  6862f4:	8d 51 ff             	lea    -0x1(%rcx),%edx
  6862f7:	83 fa 02             	cmp    $0x2,%edx
  6862fa:	73 26                	jae    686322 <<gpui_canvas::text::planner::Planner>::shape+0x1db2>
  6862fc:	f3 0f 10 84 24 24 02 	movss  0x224(%rsp),%xmm0
  686303:	00 00 
  686305:	f3 0f 11 44 24 58    	movss  %xmm0,0x58(%rsp)
  68630b:	4c 89 fa             	mov    %r15,%rdx
  68630e:	3b 94 24 20 02 00 00 	cmp    0x220(%rsp),%edx
  686315:	77 2b                	ja     686342 <<gpui_canvas::text::planner::Planner>::shape+0x1dd2>
  686317:	f3 0f 10 84 24 1c 02 	movss  0x21c(%rsp),%xmm0
  68631e:	00 00 
  686320:	eb 1a                	jmp    68633c <<gpui_canvas::text::planner::Planner>::shape+0x1dcc>
  686322:	f3 0f 10 84 24 28 02 	movss  0x228(%rsp),%xmm0
  686329:	00 00 
  68632b:	f3 0f 11 44 24 58    	movss  %xmm0,0x58(%rsp)
  686331:	83 f9 06             	cmp    $0x6,%ecx
  686334:	4c 89 fa             	mov    %r15,%rdx
  686337:	75 09                	jne    686342 <<gpui_canvas::text::planner::Planner>::shape+0x1dd2>
  686339:	0f 57 c0             	xorps  %xmm0,%xmm0
  68633c:	f3 0f 11 44 24 58    	movss  %xmm0,0x58(%rsp)
  686342:	89 d6                	mov    %edx,%esi
  686344:	49 39 f6             	cmp    %rsi,%r14
  686347:	0f 92 c1             	setb   %cl
  68634a:	3b 94 24 20 01 00 00 	cmp    0x120(%rsp),%edx
  686351:	0f 82 0e 01 00 00    	jb     686465 <<gpui_canvas::text::planner::Planner>::shape+0x1ef5>
  686357:	48 8b bc 24 20 01 00 	mov    0x120(%rsp),%rdi
  68635e:	00 
  68635f:	89 fa                	mov    %edi,%edx
  686361:	84 c9                	test   %cl,%cl
  686363:	0f 85 36 17 00 00    	jne    687a9f <<gpui_canvas::text::planner::Planner>::shape+0x352f>
  686369:	44 39 ff             	cmp    %r15d,%edi
  68636c:	75 11                	jne    68637f <<gpui_canvas::text::planner::Planner>::shape+0x1e0f>
  68636e:	48 c7 84 24 38 01 00 	movq   $0x0,0x138(%rsp)
  686375:	00 00 00 00 00 
  68637a:	e9 bd 00 00 00       	jmp    68643c <<gpui_canvas::text::planner::Planner>::shape+0x1ecc>
  68637f:	48 8d 0c d5 00 00 00 	lea    0x0(,%rdx,8),%rcx
  686386:	00 
  686387:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  68638b:	48 8d 7e ff          	lea    -0x1(%rsi),%rdi
  68638f:	48 39 d7             	cmp    %rdx,%rdi
  686392:	75 10                	jne    6863a4 <<gpui_canvas::text::planner::Planner>::shape+0x1e34>
  686394:	31 d2                	xor    %edx,%edx
  686396:	48 c7 84 24 38 01 00 	movq   $0x0,0x138(%rsp)
  68639d:	00 00 00 00 00 
  6863a2:	eb 67                	jmp    68640b <<gpui_canvas::text::planner::Planner>::shape+0x1e9b>
  6863a4:	48 29 d6             	sub    %rdx,%rsi
  6863a7:	48 89 f7             	mov    %rsi,%rdi
  6863aa:	48 83 e7 fe          	and    $0xfffffffffffffffe,%rdi
  6863ae:	48 8b 94 24 00 03 00 	mov    0x300(%rsp),%rdx
  6863b5:	00 
  6863b6:	4c 8d 04 0a          	lea    (%rdx,%rcx,1),%r8
  6863ba:	31 d2                	xor    %edx,%edx
  6863bc:	45 31 d2             	xor    %r10d,%r10d
  6863bf:	41 bb 01 00 00 00    	mov    $0x1,%r11d
  6863c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6863cc:	00 00 00 00 
  6863d0:	45 8b 48 de          	mov    -0x22(%r8),%r9d
  6863d4:	41 f6 40 e9 01       	testb  $0x1,-0x17(%r8)
  6863d9:	4d 0f 45 cb          	cmovne %r11,%r9
  6863dd:	4d 01 d1             	add    %r10,%r9
  6863e0:	41 f6 40 01 01       	testb  $0x1,0x1(%r8)
  6863e5:	45 8b 50 f6          	mov    -0xa(%r8),%r10d
  6863e9:	4d 0f 45 d3          	cmovne %r11,%r10
  6863ed:	4d 01 ca             	add    %r9,%r10
  6863f0:	48 83 c2 02          	add    $0x2,%rdx
  6863f4:	49 83 c0 30          	add    $0x30,%r8
  6863f8:	48 39 d7             	cmp    %rdx,%rdi
  6863fb:	75 d3                	jne    6863d0 <<gpui_canvas::text::planner::Planner>::shape+0x1e60>
  6863fd:	4c 89 94 24 38 01 00 	mov    %r10,0x138(%rsp)
  686404:	00 
  686405:	40 f6 c6 01          	test   $0x1,%sil
  686409:	74 31                	je     68643c <<gpui_canvas::text::planner::Planner>::shape+0x1ecc>
  68640b:	48 8b b4 24 38 01 00 	mov    0x138(%rsp),%rsi
  686412:	00 
  686413:	48 03 8c 24 d0 01 00 	add    0x1d0(%rsp),%rcx
  68641a:	00 
  68641b:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
  68641f:	f6 44 d1 17 01       	testb  $0x1,0x17(%rcx,%rdx,8)
  686424:	8b 54 d1 0c          	mov    0xc(%rcx,%rdx,8),%edx
  686428:	b9 01 00 00 00       	mov    $0x1,%ecx
  68642d:	48 0f 45 d1          	cmovne %rcx,%rdx
  686431:	48 01 f2             	add    %rsi,%rdx
  686434:	48 89 94 24 38 01 00 	mov    %rdx,0x138(%rsp)
  68643b:	00 
  68643c:	0f 57 c0             	xorps  %xmm0,%xmm0
  68643f:	f3 0f 11 84 24 c0 01 	movss  %xmm0,0x1c0(%rsp)
  686446:	00 00 
  686448:	b9 00 00 00 00       	mov    $0x0,%ecx
  68644d:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
  686452:	ba 00 00 00 00       	mov    $0x0,%edx
  686457:	48 39 c3             	cmp    %rax,%rbx
  68645a:	0f 84 53 fb ff ff    	je     685fb3 <<gpui_canvas::text::planner::Planner>::shape+0x1a43>
  686460:	e9 0e fa ff ff       	jmp    685e73 <<gpui_canvas::text::planner::Planner>::shape+0x1903>
  686465:	b1 01                	mov    $0x1,%cl
  686467:	48 8b bc 24 20 01 00 	mov    0x120(%rsp),%rdi
  68646e:	00 
  68646f:	89 fa                	mov    %edi,%edx
  686471:	84 c9                	test   %cl,%cl
  686473:	0f 84 f0 fe ff ff    	je     686369 <<gpui_canvas::text::planner::Planner>::shape+0x1df9>
  686479:	e9 21 16 00 00       	jmp    687a9f <<gpui_canvas::text::planner::Planner>::shape+0x352f>
  68647e:	0f 85 85 10 00 00    	jne    687509 <<gpui_canvas::text::planner::Planner>::shape+0x2f99>
  686484:	48 85 ed             	test   %rbp,%rbp
  686487:	0f 94 c2             	sete   %dl
  68648a:	74 1b                	je     6864a7 <<gpui_canvas::text::planner::Planner>::shape+0x1f37>
  68648c:	48 39 cd             	cmp    %rcx,%rbp
  68648f:	73 10                	jae    6864a1 <<gpui_canvas::text::planner::Planner>::shape+0x1f31>
  686491:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  686496:	80 3c 28 c0          	cmpb   $0xc0,(%rax,%rbp,1)
  68649a:	7d 0b                	jge    6864a7 <<gpui_canvas::text::planner::Planner>::shape+0x1f37>
  68649c:	e9 68 10 00 00       	jmp    687509 <<gpui_canvas::text::planner::Planner>::shape+0x2f99>
  6864a1:	0f 85 62 10 00 00    	jne    687509 <<gpui_canvas::text::planner::Planner>::shape+0x2f99>
  6864a7:	83 7c 24 5c 00       	cmpl   $0x0,0x5c(%rsp)
  6864ac:	0f 84 9a 00 00 00    	je     68654c <<gpui_canvas::text::planner::Planner>::shape+0x1fdc>
  6864b2:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  6864b8:	f3 0f 58 84 24 d8 00 	addss  0xd8(%rsp),%xmm0
  6864bf:	00 00 
  6864c1:	f3 0f 11 44 24 0c    	movss  %xmm0,0xc(%rsp)
  6864c7:	66 0f 7e c1          	movd   %xmm0,%ecx
  6864cb:	0f 28 84 24 a0 01 00 	movaps 0x1a0(%rsp),%xmm0
  6864d2:	00 
  6864d3:	0f 58 84 24 e0 03 00 	addps  0x3e0(%rsp),%xmm0
  6864da:	00 
  6864db:	0f c6 c0 55          	shufps $0x55,%xmm0,%xmm0
  6864df:	0f 29 84 24 a0 01 00 	movaps %xmm0,0x1a0(%rsp)
  6864e6:	00 
  6864e7:	66 0f 7e c0          	movd   %xmm0,%eax
  6864eb:	81 e1 ff ff ff 7f    	and    $0x7fffffff,%ecx
  6864f1:	25 ff ff ff 7f       	and    $0x7fffffff,%eax
  6864f6:	3d 00 00 80 7f       	cmp    $0x7f800000,%eax
  6864fb:	0f 9d c0             	setge  %al
  6864fe:	81 f9 ff ff 7f 7f    	cmp    $0x7f7fffff,%ecx
  686504:	0f 8f 20 10 00 00    	jg     68752a <<gpui_canvas::text::planner::Planner>::shape+0x2fba>
  68650a:	84 c0                	test   %al,%al
  68650c:	0f 85 18 10 00 00    	jne    68752a <<gpui_canvas::text::planner::Planner>::shape+0x2fba>
  686512:	81 7c 24 5c ff ff 00 	cmpl   $0xffff,0x5c(%rsp)
  686519:	00 
  68651a:	0f 87 e9 0f 00 00    	ja     687509 <<gpui_canvas::text::planner::Planner>::shape+0x2f99>
  686520:	4c 89 cd             	mov    %r9,%rbp
  686523:	4c 8b b4 24 f8 00 00 	mov    0xf8(%rsp),%r14
  68652a:	00 
  68652b:	4c 3b b4 24 e8 00 00 	cmp    0xe8(%rsp),%r14
  686532:	00 
  686533:	0f 85 4e f8 ff ff    	jne    685d87 <<gpui_canvas::text::planner::Planner>::shape+0x1817>
  686539:	48 8d bc 24 e8 00 00 	lea    0xe8(%rsp),%rdi
  686540:	00 
  686541:	ff 15 31 46 10 00    	call   *0x104631(%rip)        # 78ab78 <_DYNAMIC+0x930>
  686547:	e9 3b f8 ff ff       	jmp    685d87 <<gpui_canvas::text::planner::Planner>::shape+0x1817>
  68654c:	4d 85 c9             	test   %r9,%r9
  68654f:	0f 84 af 00 00 00    	je     686604 <<gpui_canvas::text::planner::Planner>::shape+0x2094>
  686555:	49 39 c9             	cmp    %rcx,%r9
  686558:	0f 83 a0 00 00 00    	jae    6865fe <<gpui_canvas::text::planner::Planner>::shape+0x208e>
  68655e:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  686563:	42 80 3c 08 bf       	cmpb   $0xbf,(%rax,%r9,1)
  686568:	0f 8f 96 00 00 00    	jg     686604 <<gpui_canvas::text::planner::Planner>::shape+0x2094>
  68656e:	e9 63 10 00 00       	jmp    6875d6 <<gpui_canvas::text::planner::Planner>::shape+0x3066>
  686573:	48 8b 8c 24 20 01 00 	mov    0x120(%rsp),%rcx
  68657a:	00 
  68657b:	89 da                	mov    %ebx,%edx
  68657d:	48 8d 04 7f          	lea    (%rdi,%rdi,2),%rax
  686581:	48 8b b4 24 d0 01 00 	mov    0x1d0(%rsp),%rsi
  686588:	00 
  686589:	f3 0f 10 44 c6 10    	movss  0x10(%rsi,%rax,8),%xmm0
  68658f:	0f 57 c9             	xorps  %xmm1,%xmm1
  686592:	0f 29 8c 24 a0 01 00 	movaps %xmm1,0x1a0(%rsp)
  686599:	00 
  68659a:	bb 04 00 00 00       	mov    $0x4,%ebx
  68659f:	b8 04 00 00 00       	mov    $0x4,%eax
  6865a4:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  6865ab:	00 
  6865ac:	48 89 8c 24 20 01 00 	mov    %rcx,0x120(%rsp)
  6865b3:	00 
  6865b4:	f3 0f 11 84 24 b8 01 	movss  %xmm0,0x1b8(%rsp)
  6865bb:	00 00 
  6865bd:	f3 0f 11 44 24 08    	movss  %xmm0,0x8(%rsp)
  6865c3:	89 94 24 bc 01 00 00 	mov    %edx,0x1bc(%rsp)
  6865ca:	89 54 24 5c          	mov    %edx,0x5c(%rsp)
  6865ce:	0f 57 c0             	xorps  %xmm0,%xmm0
  6865d1:	0f 29 84 24 30 02 00 	movaps %xmm0,0x230(%rsp)
  6865d8:	00 
  6865d9:	83 bc 24 dc 00 00 00 	cmpl   $0x0,0xdc(%rsp)
  6865e0:	00 
  6865e1:	0f 85 4c f8 ff ff    	jne    685e33 <<gpui_canvas::text::planner::Planner>::shape+0x18c3>
  6865e7:	e9 b8 f8 ff ff       	jmp    685ea4 <<gpui_canvas::text::planner::Planner>::shape+0x1934>
  6865ec:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  6865f1:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  6865f8:	00 
  6865f9:	e9 75 f8 ff ff       	jmp    685e73 <<gpui_canvas::text::planner::Planner>::shape+0x1903>
  6865fe:	0f 85 d2 0f 00 00    	jne    6875d6 <<gpui_canvas::text::planner::Planner>::shape+0x3066>
  686604:	48 85 ed             	test   %rbp,%rbp
  686607:	4c 89 8c 24 f8 02 00 	mov    %r9,0x2f8(%rsp)
  68660e:	00 
  68660f:	74 1b                	je     68662c <<gpui_canvas::text::planner::Planner>::shape+0x20bc>
  686611:	48 39 cd             	cmp    %rcx,%rbp
  686614:	73 10                	jae    686626 <<gpui_canvas::text::planner::Planner>::shape+0x20b6>
  686616:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  68661b:	80 3c 28 c0          	cmpb   $0xc0,(%rax,%rbp,1)
  68661f:	7d 0b                	jge    68662c <<gpui_canvas::text::planner::Planner>::shape+0x20bc>
  686621:	e9 b6 0f 00 00       	jmp    6875dc <<gpui_canvas::text::planner::Planner>::shape+0x306c>
  686626:	0f 85 b0 0f 00 00    	jne    6875dc <<gpui_canvas::text::planner::Planner>::shape+0x306c>
  68662c:	89 54 24 0c          	mov    %edx,0xc(%rsp)
  686630:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  686635:	4e 8d 34 08          	lea    (%rax,%r9,1),%r14
  686639:	48 01 e8             	add    %rbp,%rax
  68663c:	48 89 84 24 a0 01 00 	mov    %rax,0x1a0(%rsp)
  686643:	00 
  686644:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  68664b:	00 00 00 00 00 
  686650:	4c 3b b4 24 a0 01 00 	cmp    0x1a0(%rsp),%r14
  686657:	00 
  686658:	0f 84 8c 00 00 00    	je     6866ea <<gpui_canvas::text::planner::Planner>::shape+0x217a>
  68665e:	41 0f b6 36          	movzbl (%r14),%esi
  686662:	40 84 f6             	test   %sil,%sil
  686665:	78 09                	js     686670 <<gpui_canvas::text::planner::Planner>::shape+0x2100>
  686667:	49 ff c6             	inc    %r14
  68666a:	eb 64                	jmp    6866d0 <<gpui_canvas::text::planner::Planner>::shape+0x2160>
  68666c:	0f 1f 40 00          	nopl   0x0(%rax)
  686670:	89 f0                	mov    %esi,%eax
  686672:	83 e0 1f             	and    $0x1f,%eax
  686675:	41 0f b6 56 01       	movzbl 0x1(%r14),%edx
  68667a:	83 e2 3f             	and    $0x3f,%edx
  68667d:	40 80 fe df          	cmp    $0xdf,%sil
  686681:	76 2e                	jbe    6866b1 <<gpui_canvas::text::planner::Planner>::shape+0x2141>
  686683:	41 0f b6 4e 02       	movzbl 0x2(%r14),%ecx
  686688:	c1 e2 06             	shl    $0x6,%edx
  68668b:	83 e1 3f             	and    $0x3f,%ecx
  68668e:	09 d1                	or     %edx,%ecx
  686690:	40 80 fe f0          	cmp    $0xf0,%sil
  686694:	72 28                	jb     6866be <<gpui_canvas::text::planner::Planner>::shape+0x214e>
  686696:	41 0f b6 76 03       	movzbl 0x3(%r14),%esi
  68669b:	49 83 c6 04          	add    $0x4,%r14
  68669f:	83 e0 07             	and    $0x7,%eax
  6866a2:	c1 e0 12             	shl    $0x12,%eax
  6866a5:	c1 e1 06             	shl    $0x6,%ecx
  6866a8:	83 e6 3f             	and    $0x3f,%esi
  6866ab:	09 ce                	or     %ecx,%esi
  6866ad:	09 c6                	or     %eax,%esi
  6866af:	eb 1f                	jmp    6866d0 <<gpui_canvas::text::planner::Planner>::shape+0x2160>
  6866b1:	49 83 c6 02          	add    $0x2,%r14
  6866b5:	c1 e0 06             	shl    $0x6,%eax
  6866b8:	09 d0                	or     %edx,%eax
  6866ba:	89 c6                	mov    %eax,%esi
  6866bc:	eb 12                	jmp    6866d0 <<gpui_canvas::text::planner::Planner>::shape+0x2160>
  6866be:	49 83 c6 03          	add    $0x3,%r14
  6866c2:	c1 e0 0c             	shl    $0xc,%eax
  6866c5:	09 c1                	or     %eax,%ecx
  6866c7:	89 ce                	mov    %ecx,%esi
  6866c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  6866d0:	48 8d 3d 89 a3 0f 00 	lea    0xfa389(%rip),%rdi        # 780a60 <anon.e03b8aad59caf4fdbca6396e1e2d1ccc.19.llvm.4670190096578414633+0x138>
  6866d7:	ff 15 d3 44 10 00    	call   *0x1044d3(%rip)        # 78abb0 <_DYNAMIC+0x968>
  6866dd:	84 c0                	test   %al,%al
  6866df:	0f 85 6b ff ff ff    	jne    686650 <<gpui_canvas::text::planner::Planner>::shape+0x20e0>
  6866e5:	e9 fa 0e 00 00       	jmp    6875e4 <<gpui_canvas::text::planner::Planner>::shape+0x3074>
  6866ea:	31 c0                	xor    %eax,%eax
  6866ec:	0f 57 c0             	xorps  %xmm0,%xmm0
  6866ef:	f3 0f 10 4c 24 08    	movss  0x8(%rsp),%xmm1
  6866f5:	0f 2e c8             	ucomiss %xmm0,%xmm1
  6866f8:	4c 8b b4 24 e8 01 00 	mov    0x1e8(%rsp),%r14
  6866ff:	00 
  686700:	f3 0f 10 84 24 c4 01 	movss  0x1c4(%rsp),%xmm0
  686707:	00 00 
  686709:	0f 85 d5 0e 00 00    	jne    6875e4 <<gpui_canvas::text::planner::Planner>::shape+0x3074>
  68670f:	0f 8b e0 f6 ff ff    	jnp    685df5 <<gpui_canvas::text::planner::Planner>::shape+0x1885>
  686715:	e9 ca 0e 00 00       	jmp    6875e4 <<gpui_canvas::text::planner::Planner>::shape+0x3074>
  68671a:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  68671f:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  686726:	00 
  686727:	48 89 8c 24 20 01 00 	mov    %rcx,0x120(%rsp)
  68672e:	00 
  68672f:	e9 3f f7 ff ff       	jmp    685e73 <<gpui_canvas::text::planner::Planner>::shape+0x1903>
  686734:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
  68673b:	00 
  68673c:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
  686743:	00 
  686744:	e8 77 1e 00 00       	call   6885c0 <<core::iter::adapters::flatten::FlattenCompat<core::iter::adapters::map::Map<core::ops::range::Range<u32>, <parley::layout::run::Run<()>>::glyph_source_ranges::{closure#0}>, core::iter::sources::repeat_n::RepeatN<core::ops::range::Range<usize>>> as core::iter::traits::iterator::Iterator>::next>
  686749:	48 83 bc 24 88 00 00 	cmpq   $0x0,0x88(%rsp)
  686750:	00 00 
  686752:	0f 85 b1 0d 00 00    	jne    687509 <<gpui_canvas::text::planner::Planner>::shape+0x2f99>
  686758:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
  68675f:	00 
  686760:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  686764:	0f 84 bb f1 ff ff    	je     685925 <<gpui_canvas::text::planner::Planner>::shape+0x13b5>
  68676a:	48 8b 8c 24 00 01 00 	mov    0x100(%rsp),%rcx
  686771:	00 
  686772:	48 3b 4c 24 30       	cmp    0x30(%rsp),%rcx
  686777:	48 8b 8c 24 10 01 00 	mov    0x110(%rsp),%rcx
  68677e:	00 
  68677f:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  686784:	75 0f                	jne    686795 <<gpui_canvas::text::planner::Planner>::shape+0x2225>
  686786:	31 db                	xor    %ebx,%ebx
  686788:	45 31 f6             	xor    %r14d,%r14d
  68678b:	48 8b b4 24 48 02 00 	mov    0x248(%rsp),%rsi
  686792:	00 
  686793:	eb 6d                	jmp    686802 <<gpui_canvas::text::planner::Planner>::shape+0x2292>
  686795:	48 8b bc 24 e8 02 00 	mov    0x2e8(%rsp),%rdi
  68679c:	00 
  68679d:	48 85 ff             	test   %rdi,%rdi
  6867a0:	48 8b b4 24 48 02 00 	mov    0x248(%rsp),%rsi
  6867a7:	00 
  6867a8:	48 0f 44 fe          	cmove  %rsi,%rdi
  6867ac:	48 8b 1f             	mov    (%rdi),%rbx
  6867af:	4c 8b 77 08          	mov    0x8(%rdi),%r14
  6867b3:	4c 39 f3             	cmp    %r14,%rbx
  6867b6:	0f 87 4d 0d 00 00    	ja     687509 <<gpui_canvas::text::planner::Planner>::shape+0x2f99>
  6867bc:	48 85 db             	test   %rbx,%rbx
  6867bf:	74 10                	je     6867d1 <<gpui_canvas::text::planner::Planner>::shape+0x2261>
  6867c1:	48 39 cb             	cmp    %rcx,%rbx
  6867c4:	73 0f                	jae    6867d5 <<gpui_canvas::text::planner::Planner>::shape+0x2265>
  6867c6:	80 3c 1a bf          	cmpb   $0xbf,(%rdx,%rbx,1)
  6867ca:	7f 12                	jg     6867de <<gpui_canvas::text::planner::Planner>::shape+0x226e>
  6867cc:	e9 38 0d 00 00       	jmp    687509 <<gpui_canvas::text::planner::Planner>::shape+0x2f99>
  6867d1:	31 db                	xor    %ebx,%ebx
  6867d3:	eb 09                	jmp    6867de <<gpui_canvas::text::planner::Planner>::shape+0x226e>
  6867d5:	48 89 cb             	mov    %rcx,%rbx
  6867d8:	0f 85 2b 0d 00 00    	jne    687509 <<gpui_canvas::text::planner::Planner>::shape+0x2f99>
  6867de:	4d 85 f6             	test   %r14,%r14
  6867e1:	74 11                	je     6867f4 <<gpui_canvas::text::planner::Planner>::shape+0x2284>
  6867e3:	49 39 ce             	cmp    %rcx,%r14
  6867e6:	73 11                	jae    6867f9 <<gpui_canvas::text::planner::Planner>::shape+0x2289>
  6867e8:	42 80 3c 32 c0       	cmpb   $0xc0,(%rdx,%r14,1)
  6867ed:	7d 13                	jge    686802 <<gpui_canvas::text::planner::Planner>::shape+0x2292>
  6867ef:	e9 15 0d 00 00       	jmp    687509 <<gpui_canvas::text::planner::Planner>::shape+0x2f99>
  6867f4:	45 31 f6             	xor    %r14d,%r14d
  6867f7:	eb 09                	jmp    686802 <<gpui_canvas::text::planner::Planner>::shape+0x2292>
  6867f9:	49 89 ce             	mov    %rcx,%r14
  6867fc:	0f 85 07 0d 00 00    	jne    687509 <<gpui_canvas::text::planner::Planner>::shape+0x2f99>
  686802:	8b 8c 24 f8 00 00 00 	mov    0xf8(%rsp),%ecx
  686809:	89 4c 24 60          	mov    %ecx,0x60(%rsp)
  68680d:	0f b6 ae 8c 00 00 00 	movzbl 0x8c(%rsi),%ebp
  686814:	4c 8b bc 24 60 01 00 	mov    0x160(%rsp),%r15
  68681b:	00 
  68681c:	49 39 c7             	cmp    %rax,%r15
  68681f:	75 0e                	jne    68682f <<gpui_canvas::text::planner::Planner>::shape+0x22bf>
  686821:	48 8d bc 24 50 01 00 	lea    0x150(%rsp),%rdi
  686828:	00 
  686829:	ff 15 51 43 10 00    	call   *0x104351(%rip)        # 78ab80 <_DYNAMIC+0x938>
  68682f:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  686834:	01 c3                	add    %eax,%ebx
  686836:	41 01 c6             	add    %eax,%r14d
  686839:	40 80 e5 01          	and    $0x1,%bpl
  68683d:	48 8b 84 24 58 01 00 	mov    0x158(%rsp),%rax
  686844:	00 
  686845:	4b 8d 0c 7f          	lea    (%r15,%r15,2),%rcx
  686849:	89 1c c8             	mov    %ebx,(%rax,%rcx,8)
  68684c:	44 89 74 c8 04       	mov    %r14d,0x4(%rax,%rcx,8)
  686851:	48 8b 94 24 f0 02 00 	mov    0x2f0(%rsp),%rdx
  686858:	00 
  686859:	89 54 c8 08          	mov    %edx,0x8(%rax,%rcx,8)
  68685d:	8b 54 24 60          	mov    0x60(%rsp),%edx
  686861:	89 54 c8 0c          	mov    %edx,0xc(%rax,%rcx,8)
  686865:	48 8b 94 24 58 02 00 	mov    0x258(%rsp),%rdx
  68686c:	00 
  68686d:	89 54 c8 10          	mov    %edx,0x10(%rax,%rcx,8)
  686871:	48 8b 94 24 60 02 00 	mov    0x260(%rsp),%rdx
  686878:	00 
  686879:	88 54 c8 14          	mov    %dl,0x14(%rax,%rcx,8)
  68687d:	40 88 6c c8 15       	mov    %bpl,0x15(%rax,%rcx,8)
  686882:	49 ff c7             	inc    %r15
  686885:	4c 89 bc 24 60 01 00 	mov    %r15,0x160(%rsp)
  68688c:	00 
  68688d:	e9 93 f0 ff ff       	jmp    685925 <<gpui_canvas::text::planner::Planner>::shape+0x13b5>
  686892:	48 8b 84 24 08 03 00 	mov    0x308(%rsp),%rax
  686899:	00 
  68689a:	48 39 84 24 c8 00 00 	cmp    %rax,0xc8(%rsp)
  6868a1:	00 
  6868a2:	48 8b 6c 24 30       	mov    0x30(%rsp),%rbp
  6868a7:	48 8b 9c 24 00 01 00 	mov    0x100(%rsp),%rbx
  6868ae:	00 
  6868af:	0f 85 02 ec ff ff    	jne    6854b7 <<gpui_canvas::text::planner::Planner>::shape+0xf47>
  6868b5:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  6868bc:	00 ff 
  6868be:	0f 84 d9 06 00 00    	je     686f9d <<gpui_canvas::text::planner::Planner>::shape+0x2a2d>
  6868c4:	48 83 bc 24 80 01 00 	cmpq   $0xffffffffffffffff,0x180(%rsp)
  6868cb:	00 ff 
  6868cd:	0f 84 ca 06 00 00    	je     686f9d <<gpui_canvas::text::planner::Planner>::shape+0x2a2d>
  6868d3:	48 89 ac 24 88 00 00 	mov    %rbp,0x88(%rsp)
  6868da:	00 
  6868db:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
  6868e1:	f3 0f 11 84 24 e0 00 	movss  %xmm0,0xe0(%rsp)
  6868e8:	00 00 
  6868ea:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  6868ef:	48 89 84 24 40 03 00 	mov    %rax,0x340(%rsp)
  6868f6:	00 
  6868f7:	48 8d 84 24 e0 00 00 	lea    0xe0(%rsp),%rax
  6868fe:	00 
  6868ff:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
  686906:	00 
  686907:	48 8d 84 24 88 00 00 	lea    0x88(%rsp),%rax
  68690e:	00 
  68690f:	48 89 84 24 50 03 00 	mov    %rax,0x350(%rsp)
  686916:	00 
  686917:	48 8d 84 24 80 01 00 	lea    0x180(%rsp),%rax
  68691e:	00 
  68691f:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
  686926:	00 
  686927:	48 03 9c 24 48 01 00 	add    0x148(%rsp),%rbx
  68692e:	00 
  68692f:	48 c7 84 24 10 07 00 	movq   $0x0,0x710(%rsp)
  686936:	00 00 00 00 00 
  68693b:	48 c7 84 24 18 07 00 	movq   $0x8,0x718(%rsp)
  686942:	00 08 00 00 00 
  686947:	48 c7 84 24 20 07 00 	movq   $0x0,0x720(%rsp)
  68694e:	00 00 00 00 00 
  686953:	c7 84 24 30 07 00 00 	movl   $0xffffffff,0x730(%rsp)
  68695a:	ff ff ff ff 
  68695e:	4c 8b 7c 24 10       	mov    0x10(%rsp),%r15
  686963:	4c 89 bc 24 38 07 00 	mov    %r15,0x738(%rsp)
  68696a:	00 
  68696b:	48 89 9c 24 40 07 00 	mov    %rbx,0x740(%rsp)
  686972:	00 
  686973:	48 c7 84 24 48 07 00 	movq   $0x0,0x748(%rsp)
  68697a:	00 00 00 00 00 
  68697f:	48 8d 05 4a a2 0f 00 	lea    0xfa24a(%rip),%rax        # 780bd0 <anon.e03b8aad59caf4fdbca6396e1e2d1ccc.19.llvm.4670190096578414633+0x2a8>
  686986:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
  68698d:	00 
  68698e:	48 8d 05 db b7 ff ff 	lea    -0x4825(%rip),%rax        # 682170 <icu_segmenter::rule_segmenter_v1::empty_handle_complex::<icu_segmenter::scaffold::Utf8>>
  686995:	48 89 84 24 58 07 00 	mov    %rax,0x758(%rsp)
  68699c:	00 
  68699d:	4c 8b b4 24 10 01 00 	mov    0x110(%rsp),%r14
  6869a4:	00 
  6869a5:	4c 89 b4 24 60 07 00 	mov    %r14,0x760(%rsp)
  6869ac:	00 
  6869ad:	48 c7 84 24 68 07 00 	movq   $0x0,0x768(%rsp)
  6869b4:	00 00 00 00 00 
  6869b9:	48 c7 84 24 98 07 00 	movq   $0x0,0x798(%rsp)
  6869c0:	00 00 00 00 00 
  6869c5:	c6 84 24 a0 07 00 00 	movb   $0x0,0x7a0(%rsp)
  6869cc:	00 
  6869cd:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  6869d4:	00 
  6869d5:	e8 56 35 ff ff       	call   679f30 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  6869da:	48 83 f8 01          	cmp    $0x1,%rax
  6869de:	0f 85 9b 01 00 00    	jne    686b7f <<gpui_canvas::text::planner::Planner>::shape+0x260f>
  6869e4:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  6869eb:	00 
  6869ec:	e8 3f 35 ff ff       	call   679f30 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  6869f1:	48 83 f8 01          	cmp    $0x1,%rax
  6869f5:	0f 85 84 01 00 00    	jne    686b7f <<gpui_canvas::text::planner::Planner>::shape+0x260f>
  6869fb:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  686a02:	00 
  686a03:	e8 28 35 ff ff       	call   679f30 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  686a08:	48 83 f8 01          	cmp    $0x1,%rax
  686a0c:	0f 85 6d 01 00 00    	jne    686b7f <<gpui_canvas::text::planner::Planner>::shape+0x260f>
  686a12:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  686a19:	00 
  686a1a:	e8 11 35 ff ff       	call   679f30 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  686a1f:	48 83 f8 01          	cmp    $0x1,%rax
  686a23:	0f 85 56 01 00 00    	jne    686b7f <<gpui_canvas::text::planner::Planner>::shape+0x260f>
  686a29:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  686a30:	00 
  686a31:	e8 fa 34 ff ff       	call   679f30 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  686a36:	48 83 f8 01          	cmp    $0x1,%rax
  686a3a:	0f 85 3f 01 00 00    	jne    686b7f <<gpui_canvas::text::planner::Planner>::shape+0x260f>
  686a40:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  686a47:	00 
  686a48:	e8 e3 34 ff ff       	call   679f30 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  686a4d:	48 83 f8 01          	cmp    $0x1,%rax
  686a51:	0f 85 28 01 00 00    	jne    686b7f <<gpui_canvas::text::planner::Planner>::shape+0x260f>
  686a57:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  686a5e:	00 
  686a5f:	e8 cc 34 ff ff       	call   679f30 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  686a64:	48 83 f8 01          	cmp    $0x1,%rax
  686a68:	0f 85 11 01 00 00    	jne    686b7f <<gpui_canvas::text::planner::Planner>::shape+0x260f>
  686a6e:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  686a75:	00 
  686a76:	e8 b5 34 ff ff       	call   679f30 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  686a7b:	a8 01                	test   $0x1,%al
  686a7d:	0f 84 fc 00 00 00    	je     686b7f <<gpui_canvas::text::planner::Planner>::shape+0x260f>
  686a83:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  686a8a:	00 
  686a8b:	e8 a0 34 ff ff       	call   679f30 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  686a90:	48 83 f8 01          	cmp    $0x1,%rax
  686a94:	0f 85 e5 00 00 00    	jne    686b7f <<gpui_canvas::text::planner::Planner>::shape+0x260f>
  686a9a:	48 8b b4 24 10 07 00 	mov    0x710(%rsp),%rsi
  686aa1:	00 
  686aa2:	48 85 f6             	test   %rsi,%rsi
  686aa5:	74 17                	je     686abe <<gpui_canvas::text::planner::Planner>::shape+0x254e>
  686aa7:	48 8b bc 24 18 07 00 	mov    0x718(%rsp),%rdi
  686aae:	00 
  686aaf:	48 c1 e6 03          	shl    $0x3,%rsi
  686ab3:	ba 08 00 00 00       	mov    $0x8,%edx
  686ab8:	ff 15 c2 39 10 00    	call   *0x1039c2(%rip)        # 78a480 <_DYNAMIC+0x238>
  686abe:	48 c7 84 24 10 07 00 	movq   $0x0,0x710(%rsp)
  686ac5:	00 00 00 00 00 
  686aca:	48 c7 84 24 18 07 00 	movq   $0x8,0x718(%rsp)
  686ad1:	00 08 00 00 00 
  686ad6:	48 c7 84 24 20 07 00 	movq   $0x0,0x720(%rsp)
  686add:	00 00 00 00 00 
  686ae2:	c7 84 24 30 07 00 00 	movl   $0xffffffff,0x730(%rsp)
  686ae9:	ff ff ff ff 
  686aed:	4c 89 bc 24 38 07 00 	mov    %r15,0x738(%rsp)
  686af4:	00 
  686af5:	48 89 9c 24 40 07 00 	mov    %rbx,0x740(%rsp)
  686afc:	00 
  686afd:	48 c7 84 24 48 07 00 	movq   $0x0,0x748(%rsp)
  686b04:	00 00 00 00 00 
  686b09:	48 8d 05 c0 a0 0f 00 	lea    0xfa0c0(%rip),%rax        # 780bd0 <anon.e03b8aad59caf4fdbca6396e1e2d1ccc.19.llvm.4670190096578414633+0x2a8>
  686b10:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
  686b17:	00 
  686b18:	48 8d 05 51 b6 ff ff 	lea    -0x49af(%rip),%rax        # 682170 <icu_segmenter::rule_segmenter_v1::empty_handle_complex::<icu_segmenter::scaffold::Utf8>>
  686b1f:	48 89 84 24 58 07 00 	mov    %rax,0x758(%rsp)
  686b26:	00 
  686b27:	4c 89 b4 24 60 07 00 	mov    %r14,0x760(%rsp)
  686b2e:	00 
  686b2f:	48 c7 84 24 68 07 00 	movq   $0x0,0x768(%rsp)
  686b36:	00 00 00 00 00 
  686b3b:	48 c7 84 24 98 07 00 	movq   $0x0,0x798(%rsp)
  686b42:	00 00 00 00 00 
  686b47:	c6 84 24 a0 07 00 00 	movb   $0x0,0x7a0(%rsp)
  686b4e:	00 
  686b4f:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  686b54:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
  686b5b:	00 
  686b5c:	f3 0f 10 05 78 6c 99 	movss  -0x669388(%rip),%xmm0        # 1d7dc <GCC_except_table0+0x24>
  686b63:	ff 
  686b64:	48 8d 94 24 40 03 00 	lea    0x340(%rsp),%rdx
  686b6b:	00 
  686b6c:	e8 2f 3e fe ff       	call   66a9a0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>>
  686b71:	83 f8 ff             	cmp    $0xffffffff,%eax
  686b74:	0f 84 23 04 00 00    	je     686f9d <<gpui_canvas::text::planner::Planner>::shape+0x2a2d>
  686b7a:	e9 6d 0f 00 00       	jmp    687aec <<gpui_canvas::text::planner::Planner>::shape+0x357c>
  686b7f:	48 8b b4 24 10 07 00 	mov    0x710(%rsp),%rsi
  686b86:	00 
  686b87:	48 85 f6             	test   %rsi,%rsi
  686b8a:	74 17                	je     686ba3 <<gpui_canvas::text::planner::Planner>::shape+0x2633>
  686b8c:	48 8b bc 24 18 07 00 	mov    0x718(%rsp),%rdi
  686b93:	00 
  686b94:	48 c1 e6 03          	shl    $0x3,%rsi
  686b98:	ba 08 00 00 00       	mov    $0x8,%edx
  686b9d:	ff 15 dd 38 10 00    	call   *0x1038dd(%rip)        # 78a480 <_DYNAMIC+0x238>
  686ba3:	48 c7 84 24 10 07 00 	movq   $0x0,0x710(%rsp)
  686baa:	00 00 00 00 00 
  686baf:	48 c7 84 24 18 07 00 	movq   $0x8,0x718(%rsp)
  686bb6:	00 08 00 00 00 
  686bbb:	48 c7 84 24 20 07 00 	movq   $0x0,0x720(%rsp)
  686bc2:	00 00 00 00 00 
  686bc7:	c7 84 24 30 07 00 00 	movl   $0xffffffff,0x730(%rsp)
  686bce:	ff ff ff ff 
  686bd2:	4c 89 bc 24 38 07 00 	mov    %r15,0x738(%rsp)
  686bd9:	00 
  686bda:	48 89 9c 24 40 07 00 	mov    %rbx,0x740(%rsp)
  686be1:	00 
  686be2:	48 c7 84 24 48 07 00 	movq   $0x0,0x748(%rsp)
  686be9:	00 00 00 00 00 
  686bee:	48 8d 05 db 9f 0f 00 	lea    0xf9fdb(%rip),%rax        # 780bd0 <anon.e03b8aad59caf4fdbca6396e1e2d1ccc.19.llvm.4670190096578414633+0x2a8>
  686bf5:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
  686bfc:	00 
  686bfd:	48 8d 05 6c b5 ff ff 	lea    -0x4a94(%rip),%rax        # 682170 <icu_segmenter::rule_segmenter_v1::empty_handle_complex::<icu_segmenter::scaffold::Utf8>>
  686c04:	48 89 84 24 58 07 00 	mov    %rax,0x758(%rsp)
  686c0b:	00 
  686c0c:	4c 89 b4 24 60 07 00 	mov    %r14,0x760(%rsp)
  686c13:	00 
  686c14:	48 c7 84 24 68 07 00 	movq   $0x0,0x768(%rsp)
  686c1b:	00 00 00 00 00 
  686c20:	48 c7 84 24 98 07 00 	movq   $0x0,0x798(%rsp)
  686c27:	00 00 00 00 00 
  686c2c:	c6 84 24 a0 07 00 00 	movb   $0x0,0x7a0(%rsp)
  686c33:	00 
  686c34:	eb 42                	jmp    686c78 <<gpui_canvas::text::planner::Planner>::shape+0x2708>
  686c36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  686c3d:	00 00 00 
  686c40:	0f 28 84 24 00 01 00 	movaps 0x100(%rsp),%xmm0
  686c47:	00 
  686c48:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
  686c4d:	48 8b 84 24 88 01 00 	mov    0x188(%rsp),%rax
  686c54:	00 
  686c55:	48 8d 0c 5b          	lea    (%rbx,%rbx,2),%rcx
  686c59:	44 89 3c 88          	mov    %r15d,(%rax,%rcx,4)
  686c5d:	0f 28 44 24 30       	movaps 0x30(%rsp),%xmm0
  686c62:	f3 0f 11 44 88 04    	movss  %xmm0,0x4(%rax,%rcx,4)
  686c68:	40 88 6c 88 08       	mov    %bpl,0x8(%rax,%rcx,4)
  686c6d:	48 ff c3             	inc    %rbx
  686c70:	48 89 9c 24 90 01 00 	mov    %rbx,0x190(%rsp)
  686c77:	00 
  686c78:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  686c7f:	00 
  686c80:	e8 ab 32 ff ff       	call   679f30 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  686c85:	48 83 f8 01          	cmp    $0x1,%rax
  686c89:	0f 85 ea 02 00 00    	jne    686f79 <<gpui_canvas::text::planner::Planner>::shape+0x2a09>
  686c8f:	49 89 d6             	mov    %rdx,%r14
  686c92:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  686c97:	48 89 d6             	mov    %rdx,%rsi
  686c9a:	ba 01 00 00 00       	mov    $0x1,%edx
  686c9f:	e8 cc e4 fd ff       	call   665170 <<parley::editing::cursor::Cursor>::from_byte_index::<()>>
  686ca4:	48 89 c3             	mov    %rax,%rbx
  686ca7:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
  686cae:	00 
  686caf:	80 e2 01             	and    $0x1,%dl
  686cb2:	88 94 24 a0 03 00 00 	mov    %dl,0x3a0(%rsp)
  686cb9:	4c 39 f0             	cmp    %r14,%rax
  686cbc:	0f 85 ae 00 00 00    	jne    686d70 <<gpui_canvas::text::planner::Planner>::shape+0x2800>
  686cc2:	48 8d bc 24 c0 04 00 	lea    0x4c0(%rsp),%rdi
  686cc9:	00 
  686cca:	48 8d b4 24 98 03 00 	lea    0x398(%rsp),%rsi
  686cd1:	00 
  686cd2:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  686cd7:	f3 0f 10 05 fd 6a 99 	movss  -0x669503(%rip),%xmm0        # 1d7dc <GCC_except_table0+0x24>
  686cde:	ff 
  686cdf:	e8 4c e5 fd ff       	call   665230 <<parley::editing::cursor::Cursor>::geometry::<()>>
  686ce4:	f3 0f 10 84 24 e0 00 	movss  0xe0(%rsp),%xmm0
  686ceb:	00 00 
  686ced:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
  686cf1:	f2 0f 58 84 24 c8 04 	addsd  0x4c8(%rsp),%xmm0
  686cf8:	00 00 
  686cfa:	66 0f 28 8c 24 c0 04 	movapd 0x4c0(%rsp),%xmm1
  686d01:	00 00 
  686d03:	66 0f 28 94 24 d0 04 	movapd 0x4d0(%rsp),%xmm2
  686d0a:	00 00 
  686d0c:	66 0f 5c d1          	subpd  %xmm1,%xmm2
  686d10:	66 0f 14 c8          	unpcklpd %xmm0,%xmm1
  686d14:	66 0f 5a c9          	cvtpd2ps %xmm1,%xmm1
  686d18:	66 0f 5a d2          	cvtpd2ps %xmm2,%xmm2
  686d1c:	66 0f 29 4c 24 30    	movapd %xmm1,0x30(%rsp)
  686d22:	66 0f 29 94 24 10 01 	movapd %xmm2,0x110(%rsp)
  686d29:	00 00 
  686d2b:	66 0f 14 ca          	unpcklpd %xmm2,%xmm1
  686d2f:	66 0f 54 0d d9 e7 99 	andpd  -0x661827(%rip),%xmm1        # 25510 <anon.1508e9dce0c1a49d095b8c30671814b4.0.llvm.16300762181250184790+0x7e0>
  686d36:	ff 
  686d37:	66 0f 66 0d a1 e1 99 	pcmpgtd -0x661e5f(%rip),%xmm1        # 24ee0 <anon.1508e9dce0c1a49d095b8c30671814b4.0.llvm.16300762181250184790+0x1b0>
  686d3e:	ff 
  686d3f:	0f 50 c1             	movmskps %xmm1,%eax
  686d42:	85 c0                	test   %eax,%eax
  686d44:	0f 85 73 07 00 00    	jne    6874bd <<gpui_canvas::text::planner::Planner>::shape+0x2f4d>
  686d4a:	f2 0f 5a c0          	cvtsd2ss %xmm0,%xmm0
  686d4e:	f3 0f 11 44 24 10    	movss  %xmm0,0x10(%rsp)
  686d54:	0f 28 84 24 10 01 00 	movaps 0x110(%rsp),%xmm0
  686d5b:	00 
  686d5c:	0f c6 c0 55          	shufps $0x55,%xmm0,%xmm0
  686d60:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
  686d65:	eb 09                	jmp    686d70 <<gpui_canvas::text::planner::Planner>::shape+0x2800>
  686d67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  686d6e:	00 00 
  686d70:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  686d75:	4c 89 f6             	mov    %r14,%rsi
  686d78:	31 d2                	xor    %edx,%edx
  686d7a:	e8 f1 e3 fd ff       	call   665170 <<parley::editing::cursor::Cursor>::from_byte_index::<()>>
  686d7f:	48 89 c5             	mov    %rax,%rbp
  686d82:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
  686d89:	00 
  686d8a:	80 e2 01             	and    $0x1,%dl
  686d8d:	88 94 24 a0 03 00 00 	mov    %dl,0x3a0(%rsp)
  686d94:	4c 39 f0             	cmp    %r14,%rax
  686d97:	0f 85 23 01 00 00    	jne    686ec0 <<gpui_canvas::text::planner::Planner>::shape+0x2950>
  686d9d:	48 8d bc 24 c0 04 00 	lea    0x4c0(%rsp),%rdi
  686da4:	00 
  686da5:	48 8d b4 24 98 03 00 	lea    0x398(%rsp),%rsi
  686dac:	00 
  686dad:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  686db2:	f3 0f 10 05 22 6a 99 	movss  -0x6695de(%rip),%xmm0        # 1d7dc <GCC_except_table0+0x24>
  686db9:	ff 
  686dba:	e8 71 e4 fd ff       	call   665230 <<parley::editing::cursor::Cursor>::geometry::<()>>
  686dbf:	f3 0f 10 84 24 e0 00 	movss  0xe0(%rsp),%xmm0
  686dc6:	00 00 
  686dc8:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
  686dcc:	f2 0f 58 84 24 c8 04 	addsd  0x4c8(%rsp),%xmm0
  686dd3:	00 00 
  686dd5:	66 0f 28 8c 24 c0 04 	movapd 0x4c0(%rsp),%xmm1
  686ddc:	00 00 
  686dde:	66 0f 28 94 24 d0 04 	movapd 0x4d0(%rsp),%xmm2
  686de5:	00 00 
  686de7:	66 0f 5c d1          	subpd  %xmm1,%xmm2
  686deb:	66 0f 14 c8          	unpcklpd %xmm0,%xmm1
  686def:	66 0f 5a c9          	cvtpd2ps %xmm1,%xmm1
  686df3:	66 0f 5a c2          	cvtpd2ps %xmm2,%xmm0
  686df7:	66 0f 14 c8          	unpcklpd %xmm0,%xmm1
  686dfb:	66 0f 29 8c 24 00 01 	movapd %xmm1,0x100(%rsp)
  686e02:	00 00 
  686e04:	66 0f 28 c1          	movapd %xmm1,%xmm0
  686e08:	66 0f 54 05 00 e7 99 	andpd  -0x661900(%rip),%xmm0        # 25510 <anon.1508e9dce0c1a49d095b8c30671814b4.0.llvm.16300762181250184790+0x7e0>
  686e0f:	ff 
  686e10:	66 0f 66 05 c8 e0 99 	pcmpgtd -0x661f38(%rip),%xmm0        # 24ee0 <anon.1508e9dce0c1a49d095b8c30671814b4.0.llvm.16300762181250184790+0x1b0>
  686e17:	ff 
  686e18:	0f 50 c0             	movmskps %xmm0,%eax
  686e1b:	85 c0                	test   %eax,%eax
  686e1d:	0f 85 9a 06 00 00    	jne    6874bd <<gpui_canvas::text::planner::Planner>::shape+0x2f4d>
  686e23:	44 8b bc 24 88 00 00 	mov    0x88(%rsp),%r15d
  686e2a:	00 
  686e2b:	45 01 f7             	add    %r14d,%r15d
  686e2e:	4c 39 f3             	cmp    %r14,%rbx
  686e31:	0f 85 09 01 00 00    	jne    686f40 <<gpui_canvas::text::planner::Planner>::shape+0x29d0>
  686e37:	0f 28 44 24 30       	movaps 0x30(%rsp),%xmm0
  686e3c:	0f 28 8c 24 00 01 00 	movaps 0x100(%rsp),%xmm1
  686e43:	00 
  686e44:	0f 2e c1             	ucomiss %xmm1,%xmm0
  686e47:	0f 85 87 00 00 00    	jne    686ed4 <<gpui_canvas::text::planner::Planner>::shape+0x2964>
  686e4d:	0f 8a 81 00 00 00    	jp     686ed4 <<gpui_canvas::text::planner::Planner>::shape+0x2964>
  686e53:	0f 28 c1             	movaps %xmm1,%xmm0
  686e56:	0f c6 c1 55          	shufps $0x55,%xmm1,%xmm0
  686e5a:	f3 0f 10 54 24 10    	movss  0x10(%rsp),%xmm2
  686e60:	0f 2e d0             	ucomiss %xmm0,%xmm2
  686e63:	75 6f                	jne    686ed4 <<gpui_canvas::text::planner::Planner>::shape+0x2964>
  686e65:	7a 6d                	jp     686ed4 <<gpui_canvas::text::planner::Planner>::shape+0x2964>
  686e67:	0f 28 c1             	movaps %xmm1,%xmm0
  686e6a:	66 0f 15 c1          	unpckhpd %xmm1,%xmm0
  686e6e:	0f 28 94 24 10 01 00 	movaps 0x110(%rsp),%xmm2
  686e75:	00 
  686e76:	0f 2e d0             	ucomiss %xmm0,%xmm2
  686e79:	75 59                	jne    686ed4 <<gpui_canvas::text::planner::Planner>::shape+0x2964>
  686e7b:	7a 57                	jp     686ed4 <<gpui_canvas::text::planner::Planner>::shape+0x2964>
  686e7d:	0f 28 c1             	movaps %xmm1,%xmm0
  686e80:	0f c6 c1 ff          	shufps $0xff,%xmm1,%xmm0
  686e84:	0f 28 4c 24 60       	movaps 0x60(%rsp),%xmm1
  686e89:	0f 2e c8             	ucomiss %xmm0,%xmm1
  686e8c:	75 46                	jne    686ed4 <<gpui_canvas::text::planner::Planner>::shape+0x2964>
  686e8e:	7a 44                	jp     686ed4 <<gpui_canvas::text::planner::Planner>::shape+0x2964>
  686e90:	48 8b 9c 24 90 01 00 	mov    0x190(%rsp),%rbx
  686e97:	00 
  686e98:	40 b5 03             	mov    $0x3,%bpl
  686e9b:	48 3b 9c 24 80 01 00 	cmp    0x180(%rsp),%rbx
  686ea2:	00 
  686ea3:	0f 85 a4 fd ff ff    	jne    686c4d <<gpui_canvas::text::planner::Planner>::shape+0x26dd>
  686ea9:	48 8d bc 24 80 01 00 	lea    0x180(%rsp),%rdi
  686eb0:	00 
  686eb1:	ff 15 a9 39 10 00    	call   *0x1039a9(%rip)        # 78a860 <_DYNAMIC+0x618>
  686eb7:	e9 91 fd ff ff       	jmp    686c4d <<gpui_canvas::text::planner::Planner>::shape+0x26dd>
  686ebc:	0f 1f 40 00          	nopl   0x0(%rax)
  686ec0:	4c 39 f3             	cmp    %r14,%rbx
  686ec3:	0f 85 af fd ff ff    	jne    686c78 <<gpui_canvas::text::planner::Planner>::shape+0x2708>
  686ec9:	44 8b bc 24 88 00 00 	mov    0x88(%rsp),%r15d
  686ed0:	00 
  686ed1:	45 01 f7             	add    %r14d,%r15d
  686ed4:	48 8b 9c 24 90 01 00 	mov    0x190(%rsp),%rbx
  686edb:	00 
  686edc:	48 3b 9c 24 80 01 00 	cmp    0x180(%rsp),%rbx
  686ee3:	00 
  686ee4:	75 0e                	jne    686ef4 <<gpui_canvas::text::planner::Planner>::shape+0x2984>
  686ee6:	48 8d bc 24 80 01 00 	lea    0x180(%rsp),%rdi
  686eed:	00 
  686eee:	ff 15 6c 39 10 00    	call   *0x10396c(%rip)        # 78a860 <_DYNAMIC+0x618>
  686ef4:	48 8b 84 24 88 01 00 	mov    0x188(%rsp),%rax
  686efb:	00 
  686efc:	48 8d 0c 5b          	lea    (%rbx,%rbx,2),%rcx
  686f00:	44 89 3c 88          	mov    %r15d,(%rax,%rcx,4)
  686f04:	0f 28 44 24 30       	movaps 0x30(%rsp),%xmm0
  686f09:	f3 0f 11 44 88 04    	movss  %xmm0,0x4(%rax,%rcx,4)
  686f0f:	c6 44 88 08 01       	movb   $0x1,0x8(%rax,%rcx,4)
  686f14:	48 ff c3             	inc    %rbx
  686f17:	48 89 9c 24 90 01 00 	mov    %rbx,0x190(%rsp)
  686f1e:	00 
  686f1f:	4c 39 f5             	cmp    %r14,%rbp
  686f22:	0f 85 50 fd ff ff    	jne    686c78 <<gpui_canvas::text::planner::Planner>::shape+0x2708>
  686f28:	40 b5 02             	mov    $0x2,%bpl
  686f2b:	48 3b 9c 24 80 01 00 	cmp    0x180(%rsp),%rbx
  686f32:	00 
  686f33:	0f 85 07 fd ff ff    	jne    686c40 <<gpui_canvas::text::planner::Planner>::shape+0x26d0>
  686f39:	eb 1e                	jmp    686f59 <<gpui_canvas::text::planner::Planner>::shape+0x29e9>
  686f3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  686f40:	48 8b 9c 24 90 01 00 	mov    0x190(%rsp),%rbx
  686f47:	00 
  686f48:	40 b5 02             	mov    $0x2,%bpl
  686f4b:	48 3b 9c 24 80 01 00 	cmp    0x180(%rsp),%rbx
  686f52:	00 
  686f53:	0f 85 e7 fc ff ff    	jne    686c40 <<gpui_canvas::text::planner::Planner>::shape+0x26d0>
  686f59:	48 8d bc 24 80 01 00 	lea    0x180(%rsp),%rdi
  686f60:	00 
  686f61:	ff 15 f9 38 10 00    	call   *0x1038f9(%rip)        # 78a860 <_DYNAMIC+0x618>
  686f67:	0f 28 84 24 00 01 00 	movaps 0x100(%rsp),%xmm0
  686f6e:	00 
  686f6f:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
  686f74:	e9 d4 fc ff ff       	jmp    686c4d <<gpui_canvas::text::planner::Planner>::shape+0x26dd>
  686f79:	48 8b b4 24 10 07 00 	mov    0x710(%rsp),%rsi
  686f80:	00 
  686f81:	48 85 f6             	test   %rsi,%rsi
  686f84:	74 17                	je     686f9d <<gpui_canvas::text::planner::Planner>::shape+0x2a2d>
  686f86:	48 8b bc 24 18 07 00 	mov    0x718(%rsp),%rdi
  686f8d:	00 
  686f8e:	48 c1 e6 03          	shl    $0x3,%rsi
  686f92:	ba 08 00 00 00       	mov    $0x8,%edx
  686f97:	ff 15 e3 34 10 00    	call   *0x1034e3(%rip)        # 78a480 <_DYNAMIC+0x238>
  686f9d:	0f 28 9c 24 80 02 00 	movaps 0x280(%rsp),%xmm3
  686fa4:	00 
  686fa5:	0f 28 c3             	movaps %xmm3,%xmm0
  686fa8:	f3 0f 5f 84 24 d4 00 	maxss  0xd4(%rsp),%xmm0
  686faf:	00 00 
  686fb1:	0f 28 c8             	movaps %xmm0,%xmm1
  686fb4:	f3 0f c2 c8 03       	cmpunordss %xmm0,%xmm1
  686fb9:	0f 28 d1             	movaps %xmm1,%xmm2
  686fbc:	0f 55 d0             	andnps %xmm0,%xmm2
  686fbf:	0f 54 cb             	andps  %xmm3,%xmm1
  686fc2:	0f 56 ca             	orps   %xmm2,%xmm1
  686fc5:	0f 29 8c 24 80 02 00 	movaps %xmm1,0x280(%rsp)
  686fcc:	00 
  686fcd:	48 8b 04 24          	mov    (%rsp),%rax
  686fd1:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
  686fd7:	f3 0f 58 80 30 0a 00 	addss  0xa30(%rax),%xmm0
  686fde:	00 
  686fdf:	f3 0f 11 44 24 1c    	movss  %xmm0,0x1c(%rsp)
  686fe5:	80 7c 24 4c 00       	cmpb   $0x0,0x4c(%rsp)
  686fea:	48 8b 84 24 20 03 00 	mov    0x320(%rsp),%rax
  686ff1:	00 
  686ff2:	8b b4 24 80 00 00 00 	mov    0x80(%rsp),%esi
  686ff9:	48 8b 94 24 18 03 00 	mov    0x318(%rsp),%rdx
  687000:	00 
  687001:	0f 84 c1 db ff ff    	je     684bc8 <<gpui_canvas::text::planner::Planner>::shape+0x658>
  687007:	e9 6c 05 00 00       	jmp    687578 <<gpui_canvas::text::planner::Planner>::shape+0x3008>
  68700c:	48 8b 0c 24          	mov    (%rsp),%rcx
  687010:	48 8b 81 d8 09 00 00 	mov    0x9d8(%rcx),%rax
  687017:	48 6b 89 e0 09 00 00 	imul   $0x70,0x9e0(%rcx),%rcx
  68701e:	70 
  68701f:	48 01 c1             	add    %rax,%rcx
  687022:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
  687029:	00 
  68702a:	48 89 8c 24 18 07 00 	mov    %rcx,0x718(%rsp)
  687031:	00 
  687032:	48 c7 84 24 20 07 00 	movq   $0x0,0x720(%rsp)
  687039:	00 00 00 00 00 
  68703e:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  687043:	48 89 84 24 28 07 00 	mov    %rax,0x728(%rsp)
  68704a:	00 
  68704b:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  687052:	00 
  687053:	31 f6                	xor    %esi,%esi
  687055:	48 8d 94 24 e7 00 00 	lea    0xe7(%rsp),%rdx
  68705c:	00 
  68705d:	e8 ee 5c ff ff       	call   67cd50 <<core::iter::adapters::map::Map<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineData>>, <parley::layout::layout::Layout<()>>::lines::{closure#0}>, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#3}> as core::iter::traits::iterator::Iterator>::fold::<usize, <core::iter::adapters::flatten::FlattenCompat<_, _>>::iter_fold::flatten<core::iter::adapters::filter_map::FilterMap<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}>, <parley::layout::line::Line<()>>::runs::{closure#0}>, usize, <core::iter::adapters::flatten::FlattenCompat<_, _> as core::iter::traits::iterator::Iterator>::count::count<core::iter::adapters::filter_map::FilterMap<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}>, <parley::layout::line::Line<()>>::runs::{closure#0}>>>::{closure#0}>>
  687062:	48 83 f8 02          	cmp    $0x2,%rax
  687066:	0f 82 17 e2 ff ff    	jb     685283 <<gpui_canvas::text::planner::Planner>::shape+0xd13>
  68706c:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
  687073:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  68707a:	00 ff 
  68707c:	0f 84 84 e1 ff ff    	je     685206 <<gpui_canvas::text::planner::Planner>::shape+0xc96>
  687082:	e9 fc e1 ff ff       	jmp    685283 <<gpui_canvas::text::planner::Planner>::shape+0xd13>
  687087:	c7 84 24 80 00 00 00 	movl   $0xffffffff,0x80(%rsp)
  68708e:	ff ff ff ff 
  687092:	e9 9c dd ff ff       	jmp    684e33 <<gpui_canvas::text::planner::Planner>::shape+0x8c3>
  687097:	44 89 d2             	mov    %r10d,%edx
  68709a:	83 e2 1f             	and    $0x1f,%edx
  68709d:	41 0f b6 79 01       	movzbl 0x1(%r9),%edi
  6870a2:	83 e7 3f             	and    $0x3f,%edi
  6870a5:	41 80 fa df          	cmp    $0xdf,%r10b
  6870a9:	76 31                	jbe    6870dc <<gpui_canvas::text::planner::Planner>::shape+0x2b6c>
  6870ab:	41 0f b6 71 02       	movzbl 0x2(%r9),%esi
  6870b0:	c1 e7 06             	shl    $0x6,%edi
  6870b3:	83 e6 3f             	and    $0x3f,%esi
  6870b6:	09 fe                	or     %edi,%esi
  6870b8:	41 80 fa f0          	cmp    $0xf0,%r10b
  6870bc:	72 2c                	jb     6870ea <<gpui_canvas::text::planner::Planner>::shape+0x2b7a>
  6870be:	49 8d 59 04          	lea    0x4(%r9),%rbx
  6870c2:	45 0f b6 51 03       	movzbl 0x3(%r9),%r10d
  6870c7:	83 e2 07             	and    $0x7,%edx
  6870ca:	c1 e2 12             	shl    $0x12,%edx
  6870cd:	c1 e6 06             	shl    $0x6,%esi
  6870d0:	41 83 e2 3f          	and    $0x3f,%r10d
  6870d4:	41 09 f2             	or     %esi,%r10d
  6870d7:	41 09 d2             	or     %edx,%r10d
  6870da:	eb 1a                	jmp    6870f6 <<gpui_canvas::text::planner::Planner>::shape+0x2b86>
  6870dc:	49 8d 59 02          	lea    0x2(%r9),%rbx
  6870e0:	c1 e2 06             	shl    $0x6,%edx
  6870e3:	09 fa                	or     %edi,%edx
  6870e5:	41 89 d2             	mov    %edx,%r10d
  6870e8:	eb 0c                	jmp    6870f6 <<gpui_canvas::text::planner::Planner>::shape+0x2b86>
  6870ea:	49 8d 59 03          	lea    0x3(%r9),%rbx
  6870ee:	c1 e2 0c             	shl    $0xc,%edx
  6870f1:	09 d6                	or     %edx,%esi
  6870f3:	41 89 f2             	mov    %esi,%r10d
  6870f6:	49 8d 50 02          	lea    0x2(%r8),%rdx
  6870fa:	4c 89 c1             	mov    %r8,%rcx
  6870fd:	48 89 c6             	mov    %rax,%rsi
  687100:	4c 29 ce             	sub    %r9,%rsi
  687103:	48 01 de             	add    %rbx,%rsi
  687106:	41 83 fa 0a          	cmp    $0xa,%r10d
  68710a:	bf fe ff ff ff       	mov    $0xfffffffe,%edi
  68710f:	44 0f 44 d7          	cmove  %edi,%r10d
  687113:	44 89 94 24 80 00 00 	mov    %r10d,0x80(%rsp)
  68711a:	00 
  68711b:	4c 0f 44 da          	cmove  %rdx,%r11
  68711f:	c7 44 24 4c 00 00 00 	movl   $0x0,0x4c(%rsp)
  687126:	00 
  687127:	48 89 84 24 10 03 00 	mov    %rax,0x310(%rsp)
  68712e:	00 
  68712f:	48 89 f0             	mov    %rsi,%rax
  687132:	4c 89 de             	mov    %r11,%rsi
  687135:	48 89 5c 24 28       	mov    %rbx,0x28(%rsp)
  68713a:	e9 ff dc ff ff       	jmp    684e3e <<gpui_canvas::text::planner::Planner>::shape+0x8ce>
  68713f:	b9 04 00 00 00       	mov    $0x4,%ecx
  687144:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  68714a:	48 8d bc 24 e8 00 00 	lea    0xe8(%rsp),%rdi
  687151:	00 
  687152:	48 89 da             	mov    %rbx,%rdx
  687155:	e8 f6 98 ff ff       	call   680a50 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  68715a:	e9 88 e2 ff ff       	jmp    6853e7 <<gpui_canvas::text::planner::Planner>::shape+0xe77>
  68715f:	c7 84 24 90 00 00 00 	movl   $0x7,0x90(%rsp)
  687166:	07 00 00 00 
  68716a:	eb 0b                	jmp    687177 <<gpui_canvas::text::planner::Planner>::shape+0x2c07>
  68716c:	c7 84 24 90 00 00 00 	movl   $0x4,0x90(%rsp)
  687173:	04 00 00 00 
  687177:	48 c7 84 24 88 00 00 	movq   $0xffffffffffffffff,0x88(%rsp)
  68717e:	00 ff ff ff ff 
  687183:	4c 8b 2c 24          	mov    (%rsp),%r13
  687187:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
  68718e:	00 
  68718f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  687193:	74 76                	je     68720b <<gpui_canvas::text::planner::Planner>::shape+0x2c9b>
  687195:	48 85 c0             	test   %rax,%rax
  687198:	74 1b                	je     6871b5 <<gpui_canvas::text::planner::Planner>::shape+0x2c45>
  68719a:	48 8b bc 24 58 01 00 	mov    0x158(%rsp),%rdi
  6871a1:	00 
  6871a2:	48 c1 e0 03          	shl    $0x3,%rax
  6871a6:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  6871aa:	ba 04 00 00 00       	mov    $0x4,%edx
  6871af:	ff 15 cb 32 10 00    	call   *0x1032cb(%rip)        # 78a480 <_DYNAMIC+0x238>
  6871b5:	48 8b 84 24 68 01 00 	mov    0x168(%rsp),%rax
  6871bc:	00 
  6871bd:	48 85 c0             	test   %rax,%rax
  6871c0:	74 1b                	je     6871dd <<gpui_canvas::text::planner::Planner>::shape+0x2c6d>
  6871c2:	48 8b bc 24 70 01 00 	mov    0x170(%rsp),%rdi
  6871c9:	00 
  6871ca:	48 c1 e0 03          	shl    $0x3,%rax
  6871ce:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  6871d2:	ba 04 00 00 00       	mov    $0x4,%edx
  6871d7:	ff 15 a3 32 10 00    	call   *0x1032a3(%rip)        # 78a480 <_DYNAMIC+0x238>
  6871dd:	48 8b 84 24 80 01 00 	mov    0x180(%rsp),%rax
  6871e4:	00 
  6871e5:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6871e9:	74 20                	je     68720b <<gpui_canvas::text::planner::Planner>::shape+0x2c9b>
  6871eb:	48 85 c0             	test   %rax,%rax
  6871ee:	74 1b                	je     68720b <<gpui_canvas::text::planner::Planner>::shape+0x2c9b>
  6871f0:	48 8b bc 24 88 01 00 	mov    0x188(%rsp),%rdi
  6871f7:	00 
  6871f8:	48 c1 e0 02          	shl    $0x2,%rax
  6871fc:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  687200:	ba 04 00 00 00       	mov    $0x4,%edx
  687205:	ff 15 75 32 10 00    	call   *0x103275(%rip)        # 78a480 <_DYNAMIC+0x238>
  68720b:	48 8b b4 24 e8 00 00 	mov    0xe8(%rsp),%rsi
  687212:	00 
  687213:	48 85 f6             	test   %rsi,%rsi
  687216:	74 17                	je     68722f <<gpui_canvas::text::planner::Planner>::shape+0x2cbf>
  687218:	48 8b bc 24 f0 00 00 	mov    0xf0(%rsp),%rdi
  68721f:	00 
  687220:	48 c1 e6 04          	shl    $0x4,%rsi
  687224:	ba 04 00 00 00       	mov    $0x4,%edx
  687229:	ff 15 51 32 10 00    	call   *0x103251(%rip)        # 78a480 <_DYNAMIC+0x238>
  68722f:	48 8b b4 24 a0 02 00 	mov    0x2a0(%rsp),%rsi
  687236:	00 
  687237:	48 83 fe fd          	cmp    $0xfffffffffffffffd,%rsi
  68723b:	77 18                	ja     687255 <<gpui_canvas::text::planner::Planner>::shape+0x2ce5>
  68723d:	48 85 f6             	test   %rsi,%rsi
  687240:	74 13                	je     687255 <<gpui_canvas::text::planner::Planner>::shape+0x2ce5>
  687242:	48 8b bc 24 a8 02 00 	mov    0x2a8(%rsp),%rdi
  687249:	00 
  68724a:	ba 01 00 00 00       	mov    $0x1,%edx
  68724f:	ff 15 2b 32 10 00    	call   *0x10322b(%rip)        # 78a480 <_DYNAMIC+0x238>
  687255:	48 8b b4 24 b8 02 00 	mov    0x2b8(%rsp),%rsi
  68725c:	00 
  68725d:	48 83 fe fd          	cmp    $0xfffffffffffffffd,%rsi
  687261:	77 18                	ja     68727b <<gpui_canvas::text::planner::Planner>::shape+0x2d0b>
  687263:	48 85 f6             	test   %rsi,%rsi
  687266:	74 13                	je     68727b <<gpui_canvas::text::planner::Planner>::shape+0x2d0b>
  687268:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
  68726f:	00 
  687270:	ba 01 00 00 00       	mov    $0x1,%edx
  687275:	ff 15 05 32 10 00    	call   *0x103205(%rip)        # 78a480 <_DYNAMIC+0x238>
  68727b:	48 8b b4 24 d0 02 00 	mov    0x2d0(%rsp),%rsi
  687282:	00 
  687283:	48 83 fe fd          	cmp    $0xfffffffffffffffd,%rsi
  687287:	77 18                	ja     6872a1 <<gpui_canvas::text::planner::Planner>::shape+0x2d31>
  687289:	48 85 f6             	test   %rsi,%rsi
  68728c:	74 13                	je     6872a1 <<gpui_canvas::text::planner::Planner>::shape+0x2d31>
  68728e:	48 8b bc 24 d8 02 00 	mov    0x2d8(%rsp),%rdi
  687295:	00 
  687296:	ba 01 00 00 00       	mov    $0x1,%edx
  68729b:	ff 15 df 31 10 00    	call   *0x1031df(%rip)        # 78a480 <_DYNAMIC+0x238>
  6872a1:	49 8d bd c8 08 00 00 	lea    0x8c8(%r13),%rdi
  6872a8:	e8 23 b7 ff ff       	call   6829d0 <core::ptr::drop_glue::<parley::layout::layout::Layout<()>>>
  6872ad:	49 c7 85 c8 08 00 00 	movq   $0x0,0x8c8(%r13)
  6872b4:	00 00 00 00 
  6872b8:	49 c7 85 d0 08 00 00 	movq   $0x4,0x8d0(%r13)
  6872bf:	04 00 00 00 
  6872c3:	0f 57 c0             	xorps  %xmm0,%xmm0
  6872c6:	41 0f 11 85 d8 08 00 	movups %xmm0,0x8d8(%r13)
  6872cd:	00 
  6872ce:	49 c7 85 e8 08 00 00 	movq   $0x4,0x8e8(%r13)
  6872d5:	04 00 00 00 
  6872d9:	41 0f 11 85 f0 08 00 	movups %xmm0,0x8f0(%r13)
  6872e0:	00 
  6872e1:	49 c7 85 00 09 00 00 	movq   $0x8,0x900(%r13)
  6872e8:	08 00 00 00 
  6872ec:	41 0f 11 85 08 09 00 	movups %xmm0,0x908(%r13)
  6872f3:	00 
  6872f4:	49 c7 85 18 09 00 00 	movq   $0x8,0x918(%r13)
  6872fb:	08 00 00 00 
  6872ff:	41 0f 11 85 20 09 00 	movups %xmm0,0x920(%r13)
  687306:	00 
  687307:	49 c7 85 30 09 00 00 	movq   $0x4,0x930(%r13)
  68730e:	04 00 00 00 
  687312:	41 0f 11 85 38 09 00 	movups %xmm0,0x938(%r13)
  687319:	00 
  68731a:	49 c7 85 48 09 00 00 	movq   $0x4,0x948(%r13)
  687321:	04 00 00 00 
  687325:	41 0f 11 85 50 09 00 	movups %xmm0,0x950(%r13)
  68732c:	00 
  68732d:	49 c7 85 60 09 00 00 	movq   $0x4,0x960(%r13)
  687334:	04 00 00 00 
  687338:	41 0f 11 85 68 09 00 	movups %xmm0,0x968(%r13)
  68733f:	00 
  687340:	49 c7 85 78 09 00 00 	movq   $0x8,0x978(%r13)
  687347:	08 00 00 00 
  68734b:	41 0f 11 85 80 09 00 	movups %xmm0,0x980(%r13)
  687352:	00 
  687353:	49 c7 85 90 09 00 00 	movq   $0x2,0x990(%r13)
  68735a:	02 00 00 00 
  68735e:	41 0f 11 85 98 09 00 	movups %xmm0,0x998(%r13)
  687365:	00 
  687366:	49 c7 85 a8 09 00 00 	movq   $0x4,0x9a8(%r13)
  68736d:	04 00 00 00 
  687371:	41 0f 11 85 b0 09 00 	movups %xmm0,0x9b0(%r13)
  687378:	00 
  687379:	49 c7 85 c0 09 00 00 	movq   $0x8,0x9c0(%r13)
  687380:	08 00 00 00 
  687384:	41 0f 11 85 c8 09 00 	movups %xmm0,0x9c8(%r13)
  68738b:	00 
  68738c:	49 c7 85 d8 09 00 00 	movq   $0x8,0x9d8(%r13)
  687393:	08 00 00 00 
  687397:	41 0f 11 85 e0 09 00 	movups %xmm0,0x9e0(%r13)
  68739e:	00 
  68739f:	49 c7 85 f0 09 00 00 	movq   $0x8,0x9f0(%r13)
  6873a6:	08 00 00 00 
  6873aa:	41 0f 11 85 f8 09 00 	movups %xmm0,0x9f8(%r13)
  6873b1:	00 
  6873b2:	49 c7 85 08 0a 00 00 	movq   $0x4,0xa08(%r13)
  6873b9:	04 00 00 00 
  6873bd:	41 0f 11 85 10 0a 00 	movups %xmm0,0xa10(%r13)
  6873c4:	00 
  6873c5:	41 c7 85 20 0a 00 00 	movl   $0x3f800000,0xa20(%r13)
  6873cc:	00 00 80 3f 
  6873d0:	41 0f 11 85 24 0a 00 	movups %xmm0,0xa24(%r13)
  6873d7:	00 
  6873d8:	49 c7 85 32 0a 00 00 	movq   $0x0,0xa32(%r13)
  6873df:	00 00 00 00 
  6873e3:	66 41 c7 85 3a 0a 00 	movw   $0xff01,0xa3a(%r13)
  6873ea:	00 01 ff 
  6873ed:	41 c6 85 3c 0a 00 00 	movb   $0x0,0xa3c(%r13)
  6873f4:	00 
  6873f5:	48 8b 8c 24 b8 00 00 	mov    0xb8(%rsp),%rcx
  6873fc:	00 
  6873fd:	48 8b 84 24 38 03 00 	mov    0x338(%rsp),%rax
  687404:	00 
  687405:	48 89 48 30          	mov    %rcx,0x30(%rax)
  687409:	0f 10 84 24 88 00 00 	movups 0x88(%rsp),%xmm0
  687410:	00 
  687411:	0f 10 8c 24 98 00 00 	movups 0x98(%rsp),%xmm1
  687418:	00 
  687419:	0f 10 94 24 a8 00 00 	movups 0xa8(%rsp),%xmm2
  687420:	00 
  687421:	0f 11 50 20          	movups %xmm2,0x20(%rax)
  687425:	0f 11 48 10          	movups %xmm1,0x10(%rax)
  687429:	0f 11 00             	movups %xmm0,(%rax)
  68742c:	48 81 c4 e8 11 00 00 	add    $0x11e8,%rsp
  687433:	5b                   	pop    %rbx
  687434:	41 5c                	pop    %r12
  687436:	41 5d                	pop    %r13
  687438:	41 5e                	pop    %r14
  68743a:	41 5f                	pop    %r15
  68743c:	5d                   	pop    %rbp
  68743d:	c3                   	ret
  68743e:	48 8d 35 8b 60 10 00 	lea    0x10608b(%rip),%rsi        # 78d4d0 <gpui_canvas::text::HEBREW_FONT>
  687445:	48 8d 15 f4 99 9d ff 	lea    -0x62660c(%rip),%rdx        # 60e40 <gpui_canvas::text::HEBREW_BYTES>
  68744c:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  687453:	00 
  687454:	b9 14 69 00 00       	mov    $0x6914,%ecx
  687459:	45 31 c0             	xor    %r8d,%r8d
  68745c:	e8 7f 96 ff ff       	call   680ae0 <<gpui_canvas::text::FontFace>::shared_static>
  687461:	80 bc 24 10 07 00 00 	cmpb   $0x0,0x710(%rsp)
  687468:	00 
  687469:	0f 85 f2 d4 ff ff    	jne    684961 <<gpui_canvas::text::planner::Planner>::shape+0x3f1>
  68746f:	44 89 fd             	mov    %r15d,%ebp
  687472:	49 8d 9d 50 0a 00 00 	lea    0xa50(%r13),%rbx
  687479:	4c 8b bc 24 18 07 00 	mov    0x718(%rsp),%r15
  687480:	00 
  687481:	48 8b 03             	mov    (%rbx),%rax
  687484:	48 85 c0             	test   %rax,%rax
  687487:	74 0f                	je     687498 <<gpui_canvas::text::planner::Planner>::shape+0x2f28>
  687489:	f0 48 ff 08          	lock decq (%rax)
  68748d:	75 09                	jne    687498 <<gpui_canvas::text::planner::Planner>::shape+0x2f28>
  68748f:	48 89 df             	mov    %rbx,%rdi
  687492:	ff 15 10 30 10 00    	call   *0x103010(%rip)        # 78a4a8 <_DYNAMIC+0x260>
  687498:	4d 89 bd 50 0a 00 00 	mov    %r15,0xa50(%r13)
  68749f:	be 02 00 00 00       	mov    $0x2,%esi
  6874a4:	4c 89 ef             	mov    %r13,%rdi
  6874a7:	e8 a4 0b 00 00       	call   688050 <<gpui_canvas::text::planner::Planner>::register>
  6874ac:	83 f8 ff             	cmp    $0xffffffff,%eax
  6874af:	41 89 ef             	mov    %ebp,%r15d
  6874b2:	0f 85 08 d5 ff ff    	jne    6849c0 <<gpui_canvas::text::planner::Planner>::shape+0x450>
  6874b8:	e9 42 d5 ff ff       	jmp    6849ff <<gpui_canvas::text::planner::Planner>::shape+0x48f>
  6874bd:	48 8b b4 24 10 07 00 	mov    0x710(%rsp),%rsi
  6874c4:	00 
  6874c5:	48 85 f6             	test   %rsi,%rsi
  6874c8:	74 17                	je     6874e1 <<gpui_canvas::text::planner::Planner>::shape+0x2f71>
  6874ca:	48 8b bc 24 18 07 00 	mov    0x718(%rsp),%rdi
  6874d1:	00 
  6874d2:	48 c1 e6 03          	shl    $0x3,%rsi
  6874d6:	ba 08 00 00 00       	mov    $0x8,%edx
  6874db:	ff 15 9f 2f 10 00    	call   *0x102f9f(%rip)        # 78a480 <_DYNAMIC+0x238>
  6874e1:	b8 01 00 00 00       	mov    $0x1,%eax
  6874e6:	4c 8b 2c 24          	mov    (%rsp),%r13
  6874ea:	89 84 24 90 00 00 00 	mov    %eax,0x90(%rsp)
  6874f1:	89 94 24 94 00 00 00 	mov    %edx,0x94(%rsp)
  6874f8:	48 c7 84 24 88 00 00 	movq   $0xffffffffffffffff,0x88(%rsp)
  6874ff:	00 ff ff ff ff 
  687504:	e9 7e fc ff ff       	jmp    687187 <<gpui_canvas::text::planner::Planner>::shape+0x2c17>
  687509:	c7 84 24 90 00 00 00 	movl   $0x3,0x90(%rsp)
  687510:	03 00 00 00 
  687514:	e9 5e fc ff ff       	jmp    687177 <<gpui_canvas::text::planner::Planner>::shape+0x2c07>
  687519:	48 c7 84 24 90 00 00 	movq   $0x3,0x90(%rsp)
  687520:	00 03 00 00 00 
  687525:	e9 4d fc ff ff       	jmp    687177 <<gpui_canvas::text::planner::Planner>::shape+0x2c07>
  68752a:	c7 84 24 90 00 00 00 	movl   $0x1,0x90(%rsp)
  687531:	01 00 00 00 
  687535:	e9 3d fc ff ff       	jmp    687177 <<gpui_canvas::text::planner::Planner>::shape+0x2c07>
  68753a:	c7 84 24 90 00 00 00 	movl   $0x3,0x90(%rsp)
  687541:	03 00 00 00 
  687545:	8b 84 24 18 02 00 00 	mov    0x218(%rsp),%eax
  68754c:	89 84 24 94 00 00 00 	mov    %eax,0x94(%rsp)
  687553:	e9 1f fc ff ff       	jmp    687177 <<gpui_canvas::text::planner::Planner>::shape+0x2c07>
  687558:	48 c7 84 24 90 00 00 	movq   $0xc,0x90(%rsp)
  68755f:	00 0c 00 00 00 
  687564:	48 c7 84 24 88 00 00 	movq   $0xffffffffffffffff,0x88(%rsp)
  68756b:	00 ff ff ff ff 
  687570:	49 89 f5             	mov    %rsi,%r13
  687573:	e9 0f fc ff ff       	jmp    687187 <<gpui_canvas::text::planner::Planner>::shape+0x2c17>
  687578:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  68757f:	00 ff 
  687581:	4c 8b 2c 24          	mov    (%rsp),%r13
  687585:	0f 84 4a 01 00 00    	je     6876d5 <<gpui_canvas::text::planner::Planner>::shape+0x3165>
  68758b:	48 8b 84 24 80 01 00 	mov    0x180(%rsp),%rax
  687592:	00 
  687593:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  687597:	0f 84 1b 03 00 00    	je     6878b8 <<gpui_canvas::text::planner::Planner>::shape+0x3348>
  68759d:	48 8b b4 24 90 01 00 	mov    0x190(%rsp),%rsi
  6875a4:	00 
  6875a5:	48 39 f0             	cmp    %rsi,%rax
  6875a8:	0f 86 0a 03 00 00    	jbe    6878b8 <<gpui_canvas::text::planner::Planner>::shape+0x3348>
  6875ae:	48 8d bc 24 80 01 00 	lea    0x180(%rsp),%rdi
  6875b5:	00 
  6875b6:	e8 e5 0c 00 00       	call   6882a0 <<alloc::raw_vec::RawVecInner>::shrink>
  6875bb:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6875bf:	0f 84 f3 02 00 00    	je     6878b8 <<gpui_canvas::text::planner::Planner>::shape+0x3348>
  6875c5:	48 89 c7             	mov    %rax,%rdi
  6875c8:	48 89 d6             	mov    %rdx,%rsi
  6875cb:	ff 15 c7 2f 10 00    	call   *0x102fc7(%rip)        # 78a598 <_DYNAMIC+0x350>
  6875d1:	e9 25 06 00 00       	jmp    687bfb <<gpui_canvas::text::planner::Planner>::shape+0x368b>
  6875d6:	4c 8b 2c 24          	mov    (%rsp),%r13
  6875da:	eb 25                	jmp    687601 <<gpui_canvas::text::planner::Planner>::shape+0x3091>
  6875dc:	c7 44 24 0c 00 00 00 	movl   $0x0,0xc(%rsp)
  6875e3:	00 
  6875e4:	4c 8b 8c 24 f8 02 00 	mov    0x2f8(%rsp),%r9
  6875eb:	00 
  6875ec:	4d 85 c9             	test   %r9,%r9
  6875ef:	74 23                	je     687614 <<gpui_canvas::text::planner::Planner>::shape+0x30a4>
  6875f1:	4c 8b 2c 24          	mov    (%rsp),%r13
  6875f5:	48 8b 8c 24 10 01 00 	mov    0x110(%rsp),%rcx
  6875fc:	00 
  6875fd:	8b 54 24 0c          	mov    0xc(%rsp),%edx
  687601:	49 39 c9             	cmp    %rcx,%r9
  687604:	73 23                	jae    687629 <<gpui_canvas::text::planner::Planner>::shape+0x30b9>
  687606:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  68760b:	42 80 3c 08 bf       	cmpb   $0xbf,(%rax,%r9,1)
  687610:	7f 1c                	jg     68762e <<gpui_canvas::text::planner::Planner>::shape+0x30be>
  687612:	eb 4c                	jmp    687660 <<gpui_canvas::text::planner::Planner>::shape+0x30f0>
  687614:	45 31 c9             	xor    %r9d,%r9d
  687617:	4c 8b 2c 24          	mov    (%rsp),%r13
  68761b:	48 8b 8c 24 10 01 00 	mov    0x110(%rsp),%rcx
  687622:	00 
  687623:	8b 54 24 0c          	mov    0xc(%rsp),%edx
  687627:	eb 05                	jmp    68762e <<gpui_canvas::text::planner::Planner>::shape+0x30be>
  687629:	49 89 c9             	mov    %rcx,%r9
  68762c:	75 32                	jne    687660 <<gpui_canvas::text::planner::Planner>::shape+0x30f0>
  68762e:	84 d2                	test   %dl,%dl
  687630:	74 1a                	je     68764c <<gpui_canvas::text::planner::Planner>::shape+0x30dc>
  687632:	4c 39 cd             	cmp    %r9,%rbp
  687635:	74 29                	je     687660 <<gpui_canvas::text::planner::Planner>::shape+0x30f0>
  687637:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
  68763c:	43 0f b6 0c 08       	movzbl (%r8,%r9,1),%ecx
  687641:	84 c9                	test   %cl,%cl
  687643:	78 44                	js     687689 <<gpui_canvas::text::planner::Planner>::shape+0x3119>
  687645:	b8 0b 00 00 00       	mov    $0xb,%eax
  68764a:	eb 1e                	jmp    68766a <<gpui_canvas::text::planner::Planner>::shape+0x30fa>
  68764c:	48 39 cd             	cmp    %rcx,%rbp
  68764f:	73 0d                	jae    68765e <<gpui_canvas::text::planner::Planner>::shape+0x30ee>
  687651:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  687656:	80 3c 28 bf          	cmpb   $0xbf,(%rax,%rbp,1)
  68765a:	7f d6                	jg     687632 <<gpui_canvas::text::planner::Planner>::shape+0x30c2>
  68765c:	eb 02                	jmp    687660 <<gpui_canvas::text::planner::Planner>::shape+0x30f0>
  68765e:	74 d2                	je     687632 <<gpui_canvas::text::planner::Planner>::shape+0x30c2>
  687660:	b8 03 00 00 00       	mov    $0x3,%eax
  687665:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
  68766a:	89 84 24 90 00 00 00 	mov    %eax,0x90(%rsp)
  687671:	89 8c 24 94 00 00 00 	mov    %ecx,0x94(%rsp)
  687678:	48 c7 84 24 88 00 00 	movq   $0xffffffffffffffff,0x88(%rsp)
  68767f:	00 ff ff ff ff 
  687684:	e9 fe fa ff ff       	jmp    687187 <<gpui_canvas::text::planner::Planner>::shape+0x2c17>
  687689:	89 ca                	mov    %ecx,%edx
  68768b:	83 e2 1f             	and    $0x1f,%edx
  68768e:	43 0f b6 7c 08 01    	movzbl 0x1(%r8,%r9,1),%edi
  687694:	83 e7 3f             	and    $0x3f,%edi
  687697:	b8 0b 00 00 00       	mov    $0xb,%eax
  68769c:	80 f9 df             	cmp    $0xdf,%cl
  68769f:	76 2b                	jbe    6876cc <<gpui_canvas::text::planner::Planner>::shape+0x315c>
  6876a1:	43 0f b6 74 08 02    	movzbl 0x2(%r8,%r9,1),%esi
  6876a7:	c1 e7 06             	shl    $0x6,%edi
  6876aa:	83 e6 3f             	and    $0x3f,%esi
  6876ad:	09 fe                	or     %edi,%esi
  6876af:	80 f9 f0             	cmp    $0xf0,%cl
  6876b2:	72 7a                	jb     68772e <<gpui_canvas::text::planner::Planner>::shape+0x31be>
  6876b4:	43 0f b6 4c 08 03    	movzbl 0x3(%r8,%r9,1),%ecx
  6876ba:	83 e2 07             	and    $0x7,%edx
  6876bd:	c1 e2 12             	shl    $0x12,%edx
  6876c0:	c1 e6 06             	shl    $0x6,%esi
  6876c3:	83 e1 3f             	and    $0x3f,%ecx
  6876c6:	09 f1                	or     %esi,%ecx
  6876c8:	09 d1                	or     %edx,%ecx
  6876ca:	eb 9e                	jmp    68766a <<gpui_canvas::text::planner::Planner>::shape+0x30fa>
  6876cc:	c1 e2 06             	shl    $0x6,%edx
  6876cf:	09 fa                	or     %edi,%edx
  6876d1:	89 d1                	mov    %edx,%ecx
  6876d3:	eb 95                	jmp    68766a <<gpui_canvas::text::planner::Planner>::shape+0x30fa>
  6876d5:	48 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%rax
  6876dc:	00 
  6876dd:	48 85 c0             	test   %rax,%rax
  6876e0:	0f 84 b6 00 00 00    	je     68779c <<gpui_canvas::text::planner::Planner>::shape+0x322c>
  6876e6:	48 8b 8c 24 f0 00 00 	mov    0xf0(%rsp),%rcx
  6876ed:	00 
  6876ee:	48 c1 e0 04          	shl    $0x4,%rax
  6876f2:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
  6876f7:	2b 54 01 f0          	sub    -0x10(%rcx,%rax,1),%edx
  6876fb:	0f 83 a8 00 00 00    	jae    6877a9 <<gpui_canvas::text::planner::Planner>::shape+0x3239>
  687701:	c7 84 24 90 00 00 00 	movl   $0x3,0x90(%rsp)
  687708:	03 00 00 00 
  68770c:	48 c7 84 24 88 00 00 	movq   $0xffffffffffffffff,0x88(%rsp)
  687713:	00 ff ff ff ff 
  687718:	48 8b b4 24 e8 00 00 	mov    0xe8(%rsp),%rsi
  68771f:	00 
  687720:	48 85 f6             	test   %rsi,%rsi
  687723:	0f 85 ef fa ff ff    	jne    687218 <<gpui_canvas::text::planner::Planner>::shape+0x2ca8>
  687729:	e9 01 fb ff ff       	jmp    68722f <<gpui_canvas::text::planner::Planner>::shape+0x2cbf>
  68772e:	c1 e2 0c             	shl    $0xc,%edx
  687731:	09 d6                	or     %edx,%esi
  687733:	89 f1                	mov    %esi,%ecx
  687735:	e9 30 ff ff ff       	jmp    68766a <<gpui_canvas::text::planner::Planner>::shape+0x30fa>
  68773a:	48 8d 3d 07 e5 99 ff 	lea    -0x661af9(%rip),%rdi        # 25c48 <anon.9fcffffb41e17e3581a91abe69cbbd86.4.llvm.6872408754362722203>
  687741:	48 8d 15 80 81 0f 00 	lea    0xf8180(%rip),%rdx        # 77f8c8 <anon.9fcffffb41e17e3581a91abe69cbbd86.5.llvm.6872408754362722203>
  687748:	be ad 00 00 00       	mov    $0xad,%esi
  68774d:	ff 15 25 2e 10 00    	call   *0x102e25(%rip)        # 78a578 <_DYNAMIC+0x330>
  687753:	e9 a3 04 00 00       	jmp    687bfb <<gpui_canvas::text::planner::Planner>::shape+0x368b>
  687758:	48 8d 0d 51 93 0f 00 	lea    0xf9351(%rip),%rcx        # 780ab0 <anon.e03b8aad59caf4fdbca6396e1e2d1ccc.19.llvm.4670190096578414633+0x188>
  68775f:	48 89 df             	mov    %rbx,%rdi
  687762:	48 8b 94 24 40 01 00 	mov    0x140(%rsp),%rdx
  687769:	00 
  68776a:	ff 15 b8 2f 10 00    	call   *0x102fb8(%rip)        # 78a728 <_DYNAMIC+0x4e0>
  687770:	e9 86 04 00 00       	jmp    687bfb <<gpui_canvas::text::planner::Planner>::shape+0x368b>
  687775:	41 bc 03 00 00 00    	mov    $0x3,%r12d
  68777b:	8b 44 24 08          	mov    0x8(%rsp),%eax
  68777f:	41 89 c7             	mov    %eax,%r15d
  687782:	e9 3f d2 ff ff       	jmp    6849c6 <<gpui_canvas::text::planner::Planner>::shape+0x456>
  687787:	41 bc 03 00 00 00    	mov    $0x3,%r12d
  68778d:	8b 84 24 d0 01 00 00 	mov    0x1d0(%rsp),%eax
  687794:	41 89 c7             	mov    %eax,%r15d
  687797:	e9 2a d2 ff ff       	jmp    6849c6 <<gpui_canvas::text::planner::Planner>::shape+0x456>
  68779c:	48 83 7c 24 50 00    	cmpq   $0x0,0x50(%rsp)
  6877a2:	75 11                	jne    6877b5 <<gpui_canvas::text::planner::Planner>::shape+0x3245>
  6877a4:	e9 0f 01 00 00       	jmp    6878b8 <<gpui_canvas::text::planner::Planner>::shape+0x3348>
  6877a9:	81 fa ff 00 00 00    	cmp    $0xff,%edx
  6877af:	0f 86 b1 02 00 00    	jbe    687a66 <<gpui_canvas::text::planner::Planner>::shape+0x34f6>
  6877b5:	bf 04 00 00 00       	mov    $0x4,%edi
  6877ba:	be 18 00 00 00       	mov    $0x18,%esi
  6877bf:	e8 ac 0d 00 00       	call   688570 <alloc::boxed::box_new_uninit>
  6877c4:	48 89 c3             	mov    %rax,%rbx
  6877c7:	8b 84 24 f8 00 00 00 	mov    0xf8(%rsp),%eax
  6877ce:	c7 03 00 00 00 00    	movl   $0x0,(%rbx)
  6877d4:	4c 8b 7c 24 50       	mov    0x50(%rsp),%r15
  6877d9:	44 89 7b 04          	mov    %r15d,0x4(%rbx)
  6877dd:	c7 43 08 00 00 00 00 	movl   $0x0,0x8(%rbx)
  6877e4:	89 43 0c             	mov    %eax,0xc(%rbx)
  6877e7:	c7 43 10 00 00 00 00 	movl   $0x0,0x10(%rbx)
  6877ee:	66 c7 43 14 00 00    	movw   $0x0,0x14(%rbx)
  6877f4:	bf 04 00 00 00       	mov    $0x4,%edi
  6877f9:	be 18 00 00 00       	mov    $0x18,%esi
  6877fe:	e8 6d 0d 00 00       	call   688570 <alloc::boxed::box_new_uninit>
  687803:	49 89 c6             	mov    %rax,%r14
  687806:	c7 00 00 00 00 00    	movl   $0x0,(%rax)
  68780c:	44 89 78 04          	mov    %r15d,0x4(%rax)
  687810:	c7 40 08 00 00 00 00 	movl   $0x0,0x8(%rax)
  687817:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
  68781d:	f3 0f 11 40 0c       	movss  %xmm0,0xc(%rax)
  687822:	f3 0f 10 44 24 7c    	movss  0x7c(%rsp),%xmm0
  687828:	f3 0f 11 40 10       	movss  %xmm0,0x10(%rax)
  68782d:	0f 28 84 24 80 02 00 	movaps 0x280(%rsp),%xmm0
  687834:	00 
  687835:	f3 0f 11 40 14       	movss  %xmm0,0x14(%rax)
  68783a:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  687841:	00 ff 
  687843:	74 0d                	je     687852 <<gpui_canvas::text::planner::Planner>::shape+0x32e2>
  687845:	48 8d bc 24 50 01 00 	lea    0x150(%rsp),%rdi
  68784c:	00 
  68784d:	e8 ae c2 ff ff       	call   683b00 <core::ptr::drop_glue::<gpui_canvas::text::layout::TextGeometry>>
  687852:	48 c7 84 24 50 01 00 	movq   $0x1,0x150(%rsp)
  687859:	00 01 00 00 00 
  68785e:	48 89 9c 24 58 01 00 	mov    %rbx,0x158(%rsp)
  687865:	00 
  687866:	48 c7 84 24 60 01 00 	movq   $0x1,0x160(%rsp)
  68786d:	00 01 00 00 00 
  687872:	48 c7 84 24 68 01 00 	movq   $0x1,0x168(%rsp)
  687879:	00 01 00 00 00 
  68787e:	4c 89 b4 24 70 01 00 	mov    %r14,0x170(%rsp)
  687885:	00 
  687886:	48 c7 84 24 78 01 00 	movq   $0x1,0x178(%rsp)
  68788d:	00 01 00 00 00 
  687892:	48 c7 84 24 80 01 00 	movq   $0xffffffffffffffff,0x180(%rsp)
  687899:	00 ff ff ff ff 
  68789e:	44 89 bc 24 98 01 00 	mov    %r15d,0x198(%rsp)
  6878a5:	00 
  6878a6:	f3 0f 10 84 24 84 00 	movss  0x84(%rsp),%xmm0
  6878ad:	00 00 
  6878af:	f3 0f 11 84 24 9c 01 	movss  %xmm0,0x19c(%rsp)
  6878b6:	00 00 
  6878b8:	4c 8b bc 24 e8 00 00 	mov    0xe8(%rsp),%r15
  6878bf:	00 
  6878c0:	48 8b 9c 24 f0 00 00 	mov    0xf0(%rsp),%rbx
  6878c7:	00 
  6878c8:	4c 8b b4 24 f8 00 00 	mov    0xf8(%rsp),%r14
  6878cf:	00 
  6878d0:	4c 89 ef             	mov    %r13,%rdi
  6878d3:	48 8b b4 24 08 02 00 	mov    0x208(%rsp),%rsi
  6878da:	00 
  6878db:	e8 30 06 00 00       	call   687f10 <<gpui_canvas::text::planner::Planner>::font_set>
  6878e0:	49 89 c4             	mov    %rax,%r12
  6878e3:	48 89 84 24 c0 04 00 	mov    %rax,0x4c0(%rsp)
  6878ea:	00 
  6878eb:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
  6878f2:	00 
  6878f3:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6878f7:	0f 84 c7 00 00 00    	je     6879c4 <<gpui_canvas::text::planner::Planner>::shape+0x3454>
  6878fd:	48 8d 94 24 58 01 00 	lea    0x158(%rsp),%rdx
  687904:	00 
  687905:	48 8b 4a 40          	mov    0x40(%rdx),%rcx
  687909:	48 89 8c 24 68 07 00 	mov    %rcx,0x768(%rsp)
  687910:	00 
  687911:	0f 10 02             	movups (%rdx),%xmm0
  687914:	0f 10 4a 10          	movups 0x10(%rdx),%xmm1
  687918:	0f 10 52 20          	movups 0x20(%rdx),%xmm2
  68791c:	0f 10 5a 30          	movups 0x30(%rdx),%xmm3
  687920:	0f 11 9c 24 58 07 00 	movups %xmm3,0x758(%rsp)
  687927:	00 
  687928:	0f 11 94 24 48 07 00 	movups %xmm2,0x748(%rsp)
  68792f:	00 
  687930:	0f 11 8c 24 38 07 00 	movups %xmm1,0x738(%rsp)
  687937:	00 
  687938:	0f 11 84 24 28 07 00 	movups %xmm0,0x728(%rsp)
  68793f:	00 
  687940:	48 c7 84 24 10 07 00 	movq   $0x1,0x710(%rsp)
  687947:	00 01 00 00 00 
  68794c:	48 c7 84 24 18 07 00 	movq   $0x1,0x718(%rsp)
  687953:	00 01 00 00 00 
  687958:	4c 8d ac 24 20 07 00 	lea    0x720(%rsp),%r13
  68795f:	00 
  687960:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
  687967:	00 
  687968:	bf 08 00 00 00       	mov    $0x8,%edi
  68796d:	be 60 00 00 00       	mov    $0x60,%esi
  687972:	e8 f9 0b 00 00       	call   688570 <alloc::boxed::box_new_uninit>
  687977:	0f 10 84 24 60 07 00 	movups 0x760(%rsp),%xmm0
  68797e:	00 
  68797f:	0f 11 40 50          	movups %xmm0,0x50(%rax)
  687983:	0f 10 84 24 50 07 00 	movups 0x750(%rsp),%xmm0
  68798a:	00 
  68798b:	0f 11 40 40          	movups %xmm0,0x40(%rax)
  68798f:	0f 10 84 24 10 07 00 	movups 0x710(%rsp),%xmm0
  687996:	00 
  687997:	0f 10 8c 24 20 07 00 	movups 0x720(%rsp),%xmm1
  68799e:	00 
  68799f:	0f 10 94 24 30 07 00 	movups 0x730(%rsp),%xmm2
  6879a6:	00 
  6879a7:	0f 10 9c 24 40 07 00 	movups 0x740(%rsp),%xmm3
  6879ae:	00 
  6879af:	0f 11 58 30          	movups %xmm3,0x30(%rax)
  6879b3:	0f 11 50 20          	movups %xmm2,0x20(%rax)
  6879b7:	0f 11 48 10          	movups %xmm1,0x10(%rax)
  6879bb:	0f 11 00             	movups %xmm0,(%rax)
  6879be:	4c 8b 2c 24          	mov    (%rsp),%r13
  6879c2:	eb 02                	jmp    6879c6 <<gpui_canvas::text::planner::Planner>::shape+0x3456>
  6879c4:	31 c0                	xor    %eax,%eax
  6879c6:	4c 89 bc 24 88 00 00 	mov    %r15,0x88(%rsp)
  6879cd:	00 
  6879ce:	48 89 9c 24 90 00 00 	mov    %rbx,0x90(%rsp)
  6879d5:	00 
  6879d6:	4c 89 b4 24 98 00 00 	mov    %r14,0x98(%rsp)
  6879dd:	00 
  6879de:	4c 89 a4 24 a0 00 00 	mov    %r12,0xa0(%rsp)
  6879e5:	00 
  6879e6:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
  6879ed:	00 
  6879ee:	0f 28 84 24 80 02 00 	movaps 0x280(%rsp),%xmm0
  6879f5:	00 
  6879f6:	f3 0f 11 84 24 b0 00 	movss  %xmm0,0xb0(%rsp)
  6879fd:	00 00 
  6879ff:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
  687a05:	f3 0f 11 84 24 b4 00 	movss  %xmm0,0xb4(%rsp)
  687a0c:	00 00 
  687a0e:	f3 0f 10 44 24 7c    	movss  0x7c(%rsp),%xmm0
  687a14:	f3 0f 11 84 24 b8 00 	movss  %xmm0,0xb8(%rsp)
  687a1b:	00 00 
  687a1d:	f3 0f 10 84 24 84 00 	movss  0x84(%rsp),%xmm0
  687a24:	00 00 
  687a26:	f3 0f 11 84 24 bc 00 	movss  %xmm0,0xbc(%rsp)
  687a2d:	00 00 
  687a2f:	48 8d bc 24 a0 02 00 	lea    0x2a0(%rsp),%rdi
  687a36:	00 
  687a37:	e8 a4 a8 ff ff       	call   6822e0 <core::ptr::drop_glue::<[parlance::font_family::FontFamilyName; 3]>>
  687a3c:	49 83 ff ff          	cmp    $0xffffffffffffffff,%r15
  687a40:	0f 85 af f9 ff ff    	jne    6873f5 <<gpui_canvas::text::planner::Planner>::shape+0x2e85>
  687a46:	e9 56 f8 ff ff       	jmp    6872a1 <<gpui_canvas::text::planner::Planner>::shape+0x2d31>
  687a4b:	48 8d 0d b6 86 0f 00 	lea    0xf86b6(%rip),%rcx        # 780108 <anon.89d2c5d0d416cd03e9cb3036fced70ec.23.llvm.1506394962952114297>
  687a52:	48 89 f7             	mov    %rsi,%rdi
  687a55:	48 89 d6             	mov    %rdx,%rsi
  687a58:	4c 89 c2             	mov    %r8,%rdx
  687a5b:	ff 15 c7 2c 10 00    	call   *0x102cc7(%rip)        # 78a728 <_DYNAMIC+0x4e0>
  687a61:	e9 95 01 00 00       	jmp    687bfb <<gpui_canvas::text::planner::Planner>::shape+0x368b>
  687a66:	48 01 c1             	add    %rax,%rcx
  687a69:	88 51 ff             	mov    %dl,-0x1(%rcx)
  687a6c:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  687a73:	00 ff 
  687a75:	0f 85 10 fb ff ff    	jne    68758b <<gpui_canvas::text::planner::Planner>::shape+0x301b>
  687a7b:	e9 38 fe ff ff       	jmp    6878b8 <<gpui_canvas::text::planner::Planner>::shape+0x3348>
  687a80:	48 89 cb             	mov    %rcx,%rbx
  687a83:	48 8b 84 24 00 02 00 	mov    0x200(%rsp),%rax
  687a8a:	00 
  687a8b:	48 89 84 24 40 01 00 	mov    %rax,0x140(%rsp)
  687a92:	00 
  687a93:	48 8d 0d 1e 91 0f 00 	lea    0xf911e(%rip),%rcx        # 780bb8 <anon.e03b8aad59caf4fdbca6396e1e2d1ccc.19.llvm.4670190096578414633+0x290>
  687a9a:	e9 c0 fc ff ff       	jmp    68775f <<gpui_canvas::text::planner::Planner>::shape+0x31ef>
  687a9f:	48 89 d3             	mov    %rdx,%rbx
  687aa2:	4c 89 b4 24 40 01 00 	mov    %r14,0x140(%rsp)
  687aa9:	00 
  687aaa:	48 8d 0d cf 8f 0f 00 	lea    0xf8fcf(%rip),%rcx        # 780a80 <anon.e03b8aad59caf4fdbca6396e1e2d1ccc.19.llvm.4670190096578414633+0x158>
  687ab1:	e9 a9 fc ff ff       	jmp    68775f <<gpui_canvas::text::planner::Planner>::shape+0x31ef>
  687ab6:	48 8d 0d 6b 8e 0f 00 	lea    0xf8e6b(%rip),%rcx        # 780928 <anon.e03b8aad59caf4fdbca6396e1e2d1ccc.19.llvm.4670190096578414633>
  687abd:	ff 15 65 2c 10 00    	call   *0x102c65(%rip)        # 78a728 <_DYNAMIC+0x4e0>
  687ac3:	e9 33 01 00 00       	jmp    687bfb <<gpui_canvas::text::planner::Planner>::shape+0x368b>
  687ac8:	48 8d 0d 59 8e 0f 00 	lea    0xf8e59(%rip),%rcx        # 780928 <anon.e03b8aad59caf4fdbca6396e1e2d1ccc.19.llvm.4670190096578414633>
  687acf:	ff 15 53 2c 10 00    	call   *0x102c53(%rip)        # 78a728 <_DYNAMIC+0x4e0>
  687ad5:	e9 21 01 00 00       	jmp    687bfb <<gpui_canvas::text::planner::Planner>::shape+0x368b>
  687ada:	48 8d 3d 1f 82 0f 00 	lea    0xf821f(%rip),%rdi        # 77fd00 <anon.1a71af429ce32665251a25071ff44b21.39.llvm.16581668395387327457>
  687ae1:	ff 15 99 2a 10 00    	call   *0x102a99(%rip)        # 78a580 <_DYNAMIC+0x338>
  687ae7:	e9 0f 01 00 00       	jmp    687bfb <<gpui_canvas::text::planner::Planner>::shape+0x368b>
  687aec:	83 f8 fe             	cmp    $0xfffffffe,%eax
  687aef:	0f 85 f1 f9 ff ff    	jne    6874e6 <<gpui_canvas::text::planner::Planner>::shape+0x2f76>
  687af5:	b8 03 00 00 00       	mov    $0x3,%eax
  687afa:	e9 e7 f9 ff ff       	jmp    6874e6 <<gpui_canvas::text::planner::Planner>::shape+0x2f76>
  687aff:	4c 8d 05 f2 8f 0f 00 	lea    0xf8ff2(%rip),%r8        # 780af8 <anon.e03b8aad59caf4fdbca6396e1e2d1ccc.19.llvm.4670190096578414633+0x1d0>
  687b06:	48 8b bc 24 48 01 00 	mov    0x148(%rsp),%rdi
  687b0d:	00 
  687b0e:	48 8b 74 24 50       	mov    0x50(%rsp),%rsi
  687b13:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
  687b18:	ff 15 32 2f 10 00    	call   *0x102f32(%rip)        # 78aa50 <_DYNAMIC+0x808>
  687b1e:	e9 d8 00 00 00       	jmp    687bfb <<gpui_canvas::text::planner::Planner>::shape+0x368b>
  687b23:	48 8d 05 6e 8f 0f 00 	lea    0xf8f6e(%rip),%rax        # 780a98 <anon.e03b8aad59caf4fdbca6396e1e2d1ccc.19.llvm.4670190096578414633+0x170>
  687b2a:	eb 1f                	jmp    687b4b <<gpui_canvas::text::planner::Planner>::shape+0x35db>
  687b2c:	49 39 d6             	cmp    %rdx,%r14
  687b2f:	49 0f 47 d6          	cmova  %r14,%rdx
  687b33:	48 8d 05 4e 91 0f 00 	lea    0xf914e(%rip),%rax        # 780c88 <anon.e03b8aad59caf4fdbca6396e1e2d1ccc.19.llvm.4670190096578414633+0x360>
  687b3a:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  687b3f:	48 89 d7             	mov    %rdx,%rdi
  687b42:	eb 0c                	jmp    687b50 <<gpui_canvas::text::planner::Planner>::shape+0x35e0>
  687b44:	48 8d 05 0d 90 0f 00 	lea    0xf900d(%rip),%rax        # 780b58 <anon.e03b8aad59caf4fdbca6396e1e2d1ccc.19.llvm.4670190096578414633+0x230>
  687b4b:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  687b50:	48 8b b4 24 e8 01 00 	mov    0x1e8(%rsp),%rsi
  687b57:	00 
  687b58:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
  687b5d:	ff 15 45 2a 10 00    	call   *0x102a45(%rip)        # 78a5a8 <_DYNAMIC+0x360>
  687b63:	e9 93 00 00 00       	jmp    687bfb <<gpui_canvas::text::planner::Planner>::shape+0x368b>
  687b68:	48 8d 0d e1 85 0f 00 	lea    0xf85e1(%rip),%rcx        # 780150 <anon.89d2c5d0d416cd03e9cb3036fced70ec.28.llvm.1506394962952114297>
  687b6f:	48 89 8c 24 70 02 00 	mov    %rcx,0x270(%rsp)
  687b76:	00 
  687b77:	eb 04                	jmp    687b7d <<gpui_canvas::text::planner::Planner>::shape+0x360d>
  687b79:	31 ff                	xor    %edi,%edi
  687b7b:	31 c0                	xor    %eax,%eax
  687b7d:	48 89 c6             	mov    %rax,%rsi
  687b80:	48 8b 94 24 70 02 00 	mov    0x270(%rsp),%rdx
  687b87:	00 
  687b88:	ff 15 1a 2a 10 00    	call   *0x102a1a(%rip)        # 78a5a8 <_DYNAMIC+0x360>
  687b8e:	eb 6b                	jmp    687bfb <<gpui_canvas::text::planner::Planner>::shape+0x368b>
  687b90:	31 ff                	xor    %edi,%edi
  687b92:	48 c7 84 24 e8 01 00 	movq   $0x0,0x1e8(%rsp)
  687b99:	00 00 00 00 00 
  687b9e:	eb b0                	jmp    687b50 <<gpui_canvas::text::planner::Planner>::shape+0x35e0>
  687ba0:	48 8d 15 c9 83 0f 00 	lea    0xf83c9(%rip),%rdx        # 77ff70 <anon.1a71af429ce32665251a25071ff44b21.68.llvm.16581668395387327457>
  687ba7:	ff 15 fb 29 10 00    	call   *0x1029fb(%rip)        # 78a5a8 <_DYNAMIC+0x360>
  687bad:	eb 4c                	jmp    687bfb <<gpui_canvas::text::planner::Planner>::shape+0x368b>
  687baf:	48 8d 05 ba 90 0f 00 	lea    0xf90ba(%rip),%rax        # 780c70 <anon.e03b8aad59caf4fdbca6396e1e2d1ccc.19.llvm.4670190096578414633+0x348>
  687bb6:	eb 93                	jmp    687b4b <<gpui_canvas::text::planner::Planner>::shape+0x35db>
  687bb8:	48 89 d7             	mov    %rdx,%rdi
  687bbb:	48 8d 05 de 90 0f 00 	lea    0xf90de(%rip),%rax        # 780ca0 <anon.e03b8aad59caf4fdbca6396e1e2d1ccc.19.llvm.4670190096578414633+0x378>
  687bc2:	eb 87                	jmp    687b4b <<gpui_canvas::text::planner::Planner>::shape+0x35db>
  687bc4:	48 8d 05 75 8f 0f 00 	lea    0xf8f75(%rip),%rax        # 780b40 <anon.e03b8aad59caf4fdbca6396e1e2d1ccc.19.llvm.4670190096578414633+0x218>
  687bcb:	e9 7b ff ff ff       	jmp    687b4b <<gpui_canvas::text::planner::Planner>::shape+0x35db>
  687bd0:	48 8d 05 99 8f 0f 00 	lea    0xf8f99(%rip),%rax        # 780b70 <anon.e03b8aad59caf4fdbca6396e1e2d1ccc.19.llvm.4670190096578414633+0x248>
  687bd7:	e9 6f ff ff ff       	jmp    687b4b <<gpui_canvas::text::planner::Planner>::shape+0x35db>
  687bdc:	48 89 d7             	mov    %rdx,%rdi
  687bdf:	48 8d 05 a2 8f 0f 00 	lea    0xf8fa2(%rip),%rax        # 780b88 <anon.e03b8aad59caf4fdbca6396e1e2d1ccc.19.llvm.4670190096578414633+0x260>
  687be6:	e9 60 ff ff ff       	jmp    687b4b <<gpui_canvas::text::planner::Planner>::shape+0x35db>
  687beb:	48 8d 15 5e 85 0f 00 	lea    0xf855e(%rip),%rdx        # 780150 <anon.89d2c5d0d416cd03e9cb3036fced70ec.28.llvm.1506394962952114297>
  687bf2:	48 89 c6             	mov    %rax,%rsi
  687bf5:	ff 15 ad 29 10 00    	call   *0x1029ad(%rip)        # 78a5a8 <_DYNAMIC+0x360>
  687bfb:	0f 0b                	ud2
  687bfd:	49 89 c6             	mov    %rax,%r14
  687c00:	be 18 00 00 00       	mov    $0x18,%esi
  687c05:	ba 04 00 00 00       	mov    $0x4,%edx
  687c0a:	48 89 df             	mov    %rbx,%rdi
  687c0d:	ff 15 6d 28 10 00    	call   *0x10286d(%rip)        # 78a480 <_DYNAMIC+0x238>
  687c13:	e9 9a 02 00 00       	jmp    687eb2 <<gpui_canvas::text::planner::Planner>::shape+0x3942>
  687c18:	49 89 c6             	mov    %rax,%r14
  687c1b:	4c 89 ef             	mov    %r13,%rdi
  687c1e:	e8 dd be ff ff       	call   683b00 <core::ptr::drop_glue::<gpui_canvas::text::layout::TextGeometry>>
  687c23:	f0 49 ff 0c 24       	lock decq (%r12)
  687c28:	75 0e                	jne    687c38 <<gpui_canvas::text::planner::Planner>::shape+0x36c8>
  687c2a:	48 8d bc 24 c0 04 00 	lea    0x4c0(%rsp),%rdi
  687c31:	00 
  687c32:	ff 15 60 28 10 00    	call   *0x102860(%rip)        # 78a498 <_DYNAMIC+0x250>
  687c38:	31 ed                	xor    %ebp,%ebp
  687c3a:	eb 0c                	jmp    687c48 <<gpui_canvas::text::planner::Planner>::shape+0x36d8>
  687c3c:	ff 15 5e 28 10 00    	call   *0x10285e(%rip)        # 78a4a0 <_DYNAMIC+0x258>
  687c42:	49 89 c6             	mov    %rax,%r14
  687c45:	40 b5 01             	mov    $0x1,%bpl
  687c48:	4d 85 ff             	test   %r15,%r15
  687c4b:	74 15                	je     687c62 <<gpui_canvas::text::planner::Planner>::shape+0x36f2>
  687c4d:	49 c1 e7 04          	shl    $0x4,%r15
  687c51:	ba 04 00 00 00       	mov    $0x4,%edx
  687c56:	48 89 df             	mov    %rbx,%rdi
  687c59:	4c 89 fe             	mov    %r15,%rsi
  687c5c:	ff 15 1e 28 10 00    	call   *0x10281e(%rip)        # 78a480 <_DYNAMIC+0x238>
  687c62:	40 84 ed             	test   %bpl,%bpl
  687c65:	0f 84 89 02 00 00    	je     687ef4 <<gpui_canvas::text::planner::Planner>::shape+0x3984>
  687c6b:	31 db                	xor    %ebx,%ebx
  687c6d:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  687c74:	00 ff 
  687c76:	0f 84 fb 01 00 00    	je     687e77 <<gpui_canvas::text::planner::Planner>::shape+0x3907>
  687c7c:	e9 3e 02 00 00       	jmp    687ebf <<gpui_canvas::text::planner::Planner>::shape+0x394f>
  687c81:	49 89 c6             	mov    %rax,%r14
  687c84:	4c 89 3b             	mov    %r15,(%rbx)
  687c87:	4c 89 f7             	mov    %r14,%rdi
  687c8a:	e8 31 68 0f 00       	call   77e4c0 <_Unwind_Resume@plt>
  687c8f:	e9 1b 02 00 00       	jmp    687eaf <<gpui_canvas::text::planner::Planner>::shape+0x393f>
  687c94:	e9 16 02 00 00       	jmp    687eaf <<gpui_canvas::text::planner::Planner>::shape+0x393f>
  687c99:	e9 11 02 00 00       	jmp    687eaf <<gpui_canvas::text::planner::Planner>::shape+0x393f>
  687c9e:	e9 b7 01 00 00       	jmp    687e5a <<gpui_canvas::text::planner::Planner>::shape+0x38ea>
  687ca3:	e9 07 02 00 00       	jmp    687eaf <<gpui_canvas::text::planner::Planner>::shape+0x393f>
  687ca8:	e9 02 02 00 00       	jmp    687eaf <<gpui_canvas::text::planner::Planner>::shape+0x393f>
  687cad:	e9 fd 01 00 00       	jmp    687eaf <<gpui_canvas::text::planner::Planner>::shape+0x393f>
  687cb2:	e9 a3 01 00 00       	jmp    687e5a <<gpui_canvas::text::planner::Planner>::shape+0x38ea>
  687cb7:	e9 f3 01 00 00       	jmp    687eaf <<gpui_canvas::text::planner::Planner>::shape+0x393f>
  687cbc:	49 89 c6             	mov    %rax,%r14
  687cbf:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  687cc6:	00 
  687cc7:	e8 84 09 ff ff       	call   678650 <core::ptr::drop_glue::<parley::style::StyleProperty<()>>>
  687ccc:	e9 e1 01 00 00       	jmp    687eb2 <<gpui_canvas::text::planner::Planner>::shape+0x3942>
  687cd1:	ff 15 c9 27 10 00    	call   *0x1027c9(%rip)        # 78a4a0 <_DYNAMIC+0x258>
  687cd7:	49 89 c6             	mov    %rax,%r14
  687cda:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  687ce1:	00 
  687ce2:	e8 69 09 ff ff       	call   678650 <core::ptr::drop_glue::<parley::style::StyleProperty<()>>>
  687ce7:	e9 c6 01 00 00       	jmp    687eb2 <<gpui_canvas::text::planner::Planner>::shape+0x3942>
  687cec:	ff 15 ae 27 10 00    	call   *0x1027ae(%rip)        # 78a4a0 <_DYNAMIC+0x258>
  687cf2:	49 89 c6             	mov    %rax,%r14
  687cf5:	49 c7 85 c8 08 00 00 	movq   $0x0,0x8c8(%r13)
  687cfc:	00 00 00 00 
  687d00:	49 c7 85 d0 08 00 00 	movq   $0x4,0x8d0(%r13)
  687d07:	04 00 00 00 
  687d0b:	0f 57 c0             	xorps  %xmm0,%xmm0
  687d0e:	41 0f 11 85 d8 08 00 	movups %xmm0,0x8d8(%r13)
  687d15:	00 
  687d16:	49 c7 85 e8 08 00 00 	movq   $0x4,0x8e8(%r13)
  687d1d:	04 00 00 00 
  687d21:	41 0f 11 85 f0 08 00 	movups %xmm0,0x8f0(%r13)
  687d28:	00 
  687d29:	49 c7 85 00 09 00 00 	movq   $0x8,0x900(%r13)
  687d30:	08 00 00 00 
  687d34:	41 0f 11 85 08 09 00 	movups %xmm0,0x908(%r13)
  687d3b:	00 
  687d3c:	49 c7 85 18 09 00 00 	movq   $0x8,0x918(%r13)
  687d43:	08 00 00 00 
  687d47:	41 0f 11 85 20 09 00 	movups %xmm0,0x920(%r13)
  687d4e:	00 
  687d4f:	49 c7 85 30 09 00 00 	movq   $0x4,0x930(%r13)
  687d56:	04 00 00 00 
  687d5a:	41 0f 11 85 38 09 00 	movups %xmm0,0x938(%r13)
  687d61:	00 
  687d62:	49 c7 85 48 09 00 00 	movq   $0x4,0x948(%r13)
  687d69:	04 00 00 00 
  687d6d:	41 0f 11 85 50 09 00 	movups %xmm0,0x950(%r13)
  687d74:	00 
  687d75:	49 c7 85 60 09 00 00 	movq   $0x4,0x960(%r13)
  687d7c:	04 00 00 00 
  687d80:	41 0f 11 85 68 09 00 	movups %xmm0,0x968(%r13)
  687d87:	00 
  687d88:	49 c7 85 78 09 00 00 	movq   $0x8,0x978(%r13)
  687d8f:	08 00 00 00 
  687d93:	41 0f 11 85 80 09 00 	movups %xmm0,0x980(%r13)
  687d9a:	00 
  687d9b:	49 c7 85 90 09 00 00 	movq   $0x2,0x990(%r13)
  687da2:	02 00 00 00 
  687da6:	41 0f 11 85 98 09 00 	movups %xmm0,0x998(%r13)
  687dad:	00 
  687dae:	49 c7 85 a8 09 00 00 	movq   $0x4,0x9a8(%r13)
  687db5:	04 00 00 00 
  687db9:	41 0f 11 85 b0 09 00 	movups %xmm0,0x9b0(%r13)
  687dc0:	00 
  687dc1:	49 c7 85 c0 09 00 00 	movq   $0x8,0x9c0(%r13)
  687dc8:	08 00 00 00 
  687dcc:	41 0f 11 85 c8 09 00 	movups %xmm0,0x9c8(%r13)
  687dd3:	00 
  687dd4:	49 c7 85 d8 09 00 00 	movq   $0x8,0x9d8(%r13)
  687ddb:	08 00 00 00 
  687ddf:	41 0f 11 85 e0 09 00 	movups %xmm0,0x9e0(%r13)
  687de6:	00 
  687de7:	49 c7 85 f0 09 00 00 	movq   $0x8,0x9f0(%r13)
  687dee:	08 00 00 00 
  687df2:	41 0f 11 85 f8 09 00 	movups %xmm0,0x9f8(%r13)
  687df9:	00 
  687dfa:	49 c7 85 08 0a 00 00 	movq   $0x4,0xa08(%r13)
  687e01:	04 00 00 00 
  687e05:	41 0f 11 85 10 0a 00 	movups %xmm0,0xa10(%r13)
  687e0c:	00 
  687e0d:	41 c7 85 20 0a 00 00 	movl   $0x3f800000,0xa20(%r13)
  687e14:	00 00 80 3f 
  687e18:	41 0f 11 85 24 0a 00 	movups %xmm0,0xa24(%r13)
  687e1f:	00 
  687e20:	49 c7 85 32 0a 00 00 	movq   $0x0,0xa32(%r13)
  687e27:	00 00 00 00 
  687e2b:	66 41 c7 85 3a 0a 00 	movw   $0xff01,0xa3a(%r13)
  687e32:	00 01 ff 
  687e35:	41 c6 85 3c 0a 00 00 	movb   $0x0,0xa3c(%r13)
  687e3c:	00 
  687e3d:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
  687e44:	00 
  687e45:	e8 a6 a5 ff ff       	call   6823f0 <core::ptr::drop_glue::<core::result::Result<gpui_canvas::text::TextLayout, gpui_canvas::Error>>>
  687e4a:	4c 89 f7             	mov    %r14,%rdi
  687e4d:	e8 6e 66 0f 00       	call   77e4c0 <_Unwind_Resume@plt>
  687e52:	ff 15 48 26 10 00    	call   *0x102648(%rip)        # 78a4a0 <_DYNAMIC+0x258>
  687e58:	eb 55                	jmp    687eaf <<gpui_canvas::text::planner::Planner>::shape+0x393f>
  687e5a:	49 89 c6             	mov    %rax,%r14
  687e5d:	48 8b b4 24 10 07 00 	mov    0x710(%rsp),%rsi
  687e64:	00 
  687e65:	b3 01                	mov    $0x1,%bl
  687e67:	48 85 f6             	test   %rsi,%rsi
  687e6a:	75 11                	jne    687e7d <<gpui_canvas::text::planner::Planner>::shape+0x390d>
  687e6c:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  687e73:	00 ff 
  687e75:	75 48                	jne    687ebf <<gpui_canvas::text::planner::Planner>::shape+0x394f>
  687e77:	84 db                	test   %bl,%bl
  687e79:	75 55                	jne    687ed0 <<gpui_canvas::text::planner::Planner>::shape+0x3960>
  687e7b:	eb 77                	jmp    687ef4 <<gpui_canvas::text::planner::Planner>::shape+0x3984>
  687e7d:	48 8b bc 24 18 07 00 	mov    0x718(%rsp),%rdi
  687e84:	00 
  687e85:	48 c1 e6 03          	shl    $0x3,%rsi
  687e89:	ba 08 00 00 00       	mov    $0x8,%edx
  687e8e:	ff 15 ec 25 10 00    	call   *0x1025ec(%rip)        # 78a480 <_DYNAMIC+0x238>
  687e94:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  687e9b:	00 ff 
  687e9d:	74 d8                	je     687e77 <<gpui_canvas::text::planner::Planner>::shape+0x3907>
  687e9f:	eb 1e                	jmp    687ebf <<gpui_canvas::text::planner::Planner>::shape+0x394f>
  687ea1:	eb 0c                	jmp    687eaf <<gpui_canvas::text::planner::Planner>::shape+0x393f>
  687ea3:	eb 0a                	jmp    687eaf <<gpui_canvas::text::planner::Planner>::shape+0x393f>
  687ea5:	eb 08                	jmp    687eaf <<gpui_canvas::text::planner::Planner>::shape+0x393f>
  687ea7:	eb 06                	jmp    687eaf <<gpui_canvas::text::planner::Planner>::shape+0x393f>
  687ea9:	eb 04                	jmp    687eaf <<gpui_canvas::text::planner::Planner>::shape+0x393f>
  687eab:	eb 02                	jmp    687eaf <<gpui_canvas::text::planner::Planner>::shape+0x393f>
  687ead:	eb 00                	jmp    687eaf <<gpui_canvas::text::planner::Planner>::shape+0x393f>
  687eaf:	49 89 c6             	mov    %rax,%r14
  687eb2:	b3 01                	mov    $0x1,%bl
  687eb4:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  687ebb:	00 ff 
  687ebd:	74 b8                	je     687e77 <<gpui_canvas::text::planner::Planner>::shape+0x3907>
  687ebf:	48 8d bc 24 50 01 00 	lea    0x150(%rsp),%rdi
  687ec6:	00 
  687ec7:	e8 34 bc ff ff       	call   683b00 <core::ptr::drop_glue::<gpui_canvas::text::layout::TextGeometry>>
  687ecc:	84 db                	test   %bl,%bl
  687ece:	74 24                	je     687ef4 <<gpui_canvas::text::planner::Planner>::shape+0x3984>
  687ed0:	48 8b b4 24 e8 00 00 	mov    0xe8(%rsp),%rsi
  687ed7:	00 
  687ed8:	48 85 f6             	test   %rsi,%rsi
  687edb:	74 17                	je     687ef4 <<gpui_canvas::text::planner::Planner>::shape+0x3984>
  687edd:	48 8b bc 24 f0 00 00 	mov    0xf0(%rsp),%rdi
  687ee4:	00 
  687ee5:	48 c1 e6 04          	shl    $0x4,%rsi
  687ee9:	ba 04 00 00 00       	mov    $0x4,%edx
  687eee:	ff 15 8c 25 10 00    	call   *0x10258c(%rip)        # 78a480 <_DYNAMIC+0x238>
  687ef4:	48 8d bc 24 a0 02 00 	lea    0x2a0(%rsp),%rdi
  687efb:	00 
  687efc:	e8 df a3 ff ff       	call   6822e0 <core::ptr::drop_glue::<[parlance::font_family::FontFamilyName; 3]>>
  687f01:	4c 89 f7             	mov    %r14,%rdi
  687f04:	e8 b7 65 0f 00       	call   77e4c0 <_Unwind_Resume@plt>
