
/tmp/gpui-monotonic-control-bin/stream-shared:     file format elf64-x86-64


Disassembly of section .text:

000000000066db50 <parley::editing::geometry::pair_from_entries::<()>>:
  66db50:	55                   	push   %rbp
  66db51:	41 57                	push   %r15
  66db53:	41 56                	push   %r14
  66db55:	41 55                	push   %r13
  66db57:	41 54                	push   %r12
  66db59:	53                   	push   %rbx
  66db5a:	48 81 ec d8 01 00 00 	sub    $0x1d8,%rsp
  66db61:	49 89 f6             	mov    %rsi,%r14
  66db64:	48 89 fb             	mov    %rdi,%rbx
  66db67:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  66db6c:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
  66db71:	4d 85 c0             	test   %r8,%r8
  66db74:	74 4a                	je     66dbc0 <parley::editing::geometry::pair_from_entries::<()>+0x70>
  66db76:	41 8b 00             	mov    (%r8),%eax
  66db79:	49 39 86 18 01 00 00 	cmp    %rax,0x118(%r14)
  66db80:	76 3e                	jbe    66dbc0 <parley::editing::geometry::pair_from_entries::<()>+0x70>
  66db82:	41 8b 70 04          	mov    0x4(%r8),%esi
  66db86:	4c 6b c8 70          	imul   $0x70,%rax,%r9
  66db8a:	4d 8b 96 10 01 00 00 	mov    0x110(%r14),%r10
  66db91:	4b 8b 7c 0a 10       	mov    0x10(%r10,%r9,1),%rdi
  66db96:	48 01 f7             	add    %rsi,%rdi
  66db99:	4b 3b 7c 0a 18       	cmp    0x18(%r10,%r9,1),%rdi
  66db9e:	73 20                	jae    66dbc0 <parley::editing::geometry::pair_from_entries::<()>+0x70>
  66dba0:	49 3b be 30 01 00 00 	cmp    0x130(%r14),%rdi
  66dba7:	73 17                	jae    66dbc0 <parley::editing::geometry::pair_from_entries::<()>+0x70>
  66dba9:	4d 8b 8e 28 01 00 00 	mov    0x128(%r14),%r9
  66dbb0:	48 8d 3c bf          	lea    (%rdi,%rdi,4),%rdi
  66dbb4:	41 80 7c f9 21 00    	cmpb   $0x0,0x21(%r9,%rdi,8)
  66dbba:	0f 84 e7 01 00 00    	je     66dda7 <parley::editing::geometry::pair_from_entries::<()>+0x257>
  66dbc0:	48 c7 84 24 48 01 00 	movq   $0x0,0x148(%rsp)
  66dbc7:	00 00 00 00 00 
  66dbcc:	49 8b 86 50 01 00 00 	mov    0x150(%r14),%rax
  66dbd3:	40 b5 01             	mov    $0x1,%bpl
  66dbd6:	45 31 ff             	xor    %r15d,%r15d
  66dbd9:	48 39 d0             	cmp    %rdx,%rax
  66dbdc:	0f 85 0a 03 00 00    	jne    66deec <parley::editing::geometry::pair_from_entries::<()>+0x39c>
  66dbe2:	48 85 c9             	test   %rcx,%rcx
  66dbe5:	f3 0f 11 44 24 0c    	movss  %xmm0,0xc(%rsp)
  66dbeb:	74 48                	je     66dc35 <parley::editing::geometry::pair_from_entries::<()>+0xe5>
  66dbed:	8b 01                	mov    (%rcx),%eax
  66dbef:	49 39 86 18 01 00 00 	cmp    %rax,0x118(%r14)
  66dbf6:	76 3d                	jbe    66dc35 <parley::editing::geometry::pair_from_entries::<()>+0xe5>
  66dbf8:	8b 71 04             	mov    0x4(%rcx),%esi
  66dbfb:	4c 6b c0 70          	imul   $0x70,%rax,%r8
  66dbff:	4d 8b 8e 10 01 00 00 	mov    0x110(%r14),%r9
  66dc06:	4b 8b 7c 01 10       	mov    0x10(%r9,%r8,1),%rdi
  66dc0b:	48 01 f7             	add    %rsi,%rdi
  66dc0e:	4b 3b 7c 01 18       	cmp    0x18(%r9,%r8,1),%rdi
  66dc13:	73 20                	jae    66dc35 <parley::editing::geometry::pair_from_entries::<()>+0xe5>
  66dc15:	49 3b be 30 01 00 00 	cmp    0x130(%r14),%rdi
  66dc1c:	73 17                	jae    66dc35 <parley::editing::geometry::pair_from_entries::<()>+0xe5>
  66dc1e:	4d 8b 86 28 01 00 00 	mov    0x128(%r14),%r8
  66dc25:	48 8d 3c bf          	lea    (%rdi,%rdi,4),%rdi
  66dc29:	41 80 7c f8 21 00    	cmpb   $0x0,0x21(%r8,%rdi,8)
  66dc2f:	0f 84 d3 02 00 00    	je     66df08 <parley::editing::geometry::pair_from_entries::<()>+0x3b8>
  66dc35:	48 c7 84 24 b8 00 00 	movq   $0x0,0xb8(%rsp)
  66dc3c:	00 00 00 00 00 
  66dc41:	45 31 e4             	xor    %r12d,%r12d
  66dc44:	48 89 54 24 60       	mov    %rdx,0x60(%rsp)
  66dc49:	40 88 6c 24 68       	mov    %bpl,0x68(%rsp)
  66dc4e:	4c 89 64 24 20       	mov    %r12,0x20(%rsp)
  66dc53:	4c 89 7c 24 28       	mov    %r15,0x28(%rsp)
  66dc58:	48 8d bc 24 98 00 00 	lea    0x98(%rsp),%rdi
  66dc5f:	00 
  66dc60:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
  66dc65:	48 8d 4c 24 20       	lea    0x20(%rsp),%rcx
  66dc6a:	4c 8d 44 24 10       	lea    0x10(%rsp),%r8
  66dc6f:	4c 8d 4c 24 18       	lea    0x18(%rsp),%r9
  66dc74:	49 89 d5             	mov    %rdx,%r13
  66dc77:	4c 89 f2             	mov    %r14,%rdx
  66dc7a:	e8 41 71 ff ff       	call   664dc0 <<parley::editing::cursor::Cursor>::geometry_with::<(), parley::editing::geometry::pair_from_entries<()>::{closure#2}::{closure#0}>>
  66dc7f:	4d 85 ed             	test   %r13,%r13
  66dc82:	0f 84 bb 00 00 00    	je     66dd43 <parley::editing::geometry::pair_from_entries::<()>+0x1f3>
  66dc88:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  66dc8f:	00 
  66dc90:	48 85 c0             	test   %rax,%rax
  66dc93:	0f 84 aa 00 00 00    	je     66dd43 <parley::editing::geometry::pair_from_entries::<()>+0x1f3>
  66dc99:	8b bc 24 70 01 00 00 	mov    0x170(%rsp),%edi
  66dca0:	48 8b 70 58          	mov    0x58(%rax),%rsi
  66dca4:	48 39 fe             	cmp    %rdi,%rsi
  66dca7:	0f 86 ef 02 00 00    	jbe    66df9c <parley::editing::geometry::pair_from_entries::<()>+0x44c>
  66dcad:	48 8b 48 50          	mov    0x50(%rax),%rcx
  66dcb1:	48 8d 14 ff          	lea    (%rdi,%rdi,8),%rdx
  66dcb5:	48 c1 e2 04          	shl    $0x4,%rdx
  66dcb9:	0f 10 40 68          	movups 0x68(%rax),%xmm0
  66dcbd:	0f 10 88 80 00 00 00 	movups 0x80(%rax),%xmm1
  66dcc4:	0f 10 90 98 00 00 00 	movups 0x98(%rax),%xmm2
  66dccb:	0f 11 44 24 20       	movups %xmm0,0x20(%rsp)
  66dcd0:	0f 11 4c 24 30       	movups %xmm1,0x30(%rsp)
  66dcd5:	0f 11 54 24 40       	movups %xmm2,0x40(%rsp)
  66dcda:	48 8b 44 11 50       	mov    0x50(%rcx,%rdx,1),%rax
  66dcdf:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  66dce4:	8b b4 24 c8 01 00 00 	mov    0x1c8(%rsp),%esi
  66dceb:	8b 94 24 cc 01 00 00 	mov    0x1cc(%rsp),%edx
  66dcf2:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
  66dcf7:	ff 15 73 ca 11 00    	call   *0x11ca73(%rip)        # 78a770 <_DYNAMIC+0x528>
  66dcfd:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
  66dd04:	00 
  66dd05:	c6 84 24 90 00 00 00 	movb   $0x0,0x90(%rsp)
  66dd0c:	00 
  66dd0d:	4c 89 64 24 20       	mov    %r12,0x20(%rsp)
  66dd12:	4c 89 7c 24 28       	mov    %r15,0x28(%rsp)
  66dd17:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
  66dd1c:	48 8d b4 24 88 00 00 	lea    0x88(%rsp),%rsi
  66dd23:	00 
  66dd24:	48 8d 4c 24 20       	lea    0x20(%rsp),%rcx
  66dd29:	4c 8d 44 24 10       	lea    0x10(%rsp),%r8
  66dd2e:	4c 8d 4c 24 18       	lea    0x18(%rsp),%r9
  66dd33:	4c 89 f2             	mov    %r14,%rdx
  66dd36:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  66dd3c:	e8 7f 70 ff ff       	call   664dc0 <<parley::editing::cursor::Cursor>::geometry_with::<(), parley::editing::geometry::pair_from_entries<()>::{closure#2}::{closure#0}>>
  66dd41:	eb 1a                	jmp    66dd5d <parley::editing::geometry::pair_from_entries::<()>+0x20d>
  66dd43:	0f 10 84 24 98 00 00 	movups 0x98(%rsp),%xmm0
  66dd4a:	00 
  66dd4b:	0f 10 8c 24 a8 00 00 	movups 0xa8(%rsp),%xmm1
  66dd52:	00 
  66dd53:	0f 29 4c 24 70       	movaps %xmm1,0x70(%rsp)
  66dd58:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
  66dd5d:	0f 10 84 24 98 00 00 	movups 0x98(%rsp),%xmm0
  66dd64:	00 
  66dd65:	0f 10 8c 24 a8 00 00 	movups 0xa8(%rsp),%xmm1
  66dd6c:	00 
  66dd6d:	0f 29 4c 24 30       	movaps %xmm1,0x30(%rsp)
  66dd72:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
  66dd77:	0f 28 54 24 60       	movaps 0x60(%rsp),%xmm2
  66dd7c:	0f 28 5c 24 70       	movaps 0x70(%rsp),%xmm3
  66dd81:	0f 29 54 24 40       	movaps %xmm2,0x40(%rsp)
  66dd86:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
  66dd8b:	0f 11 5b 38          	movups %xmm3,0x38(%rbx)
  66dd8f:	0f 11 53 28          	movups %xmm2,0x28(%rbx)
  66dd93:	0f 11 4b 18          	movups %xmm1,0x18(%rbx)
  66dd97:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
  66dd9b:	48 c7 03 01 00 00 00 	movq   $0x1,(%rbx)
  66dda2:	e9 4c 01 00 00       	jmp    66def3 <parley::editing::geometry::pair_from_entries::<()>+0x3a3>
  66dda7:	4d 8d 0c f9          	lea    (%r9,%rdi,8),%r9
  66ddab:	49 8b 79 10          	mov    0x10(%r9),%rdi
  66ddaf:	49 3b 7e 58          	cmp    0x58(%r14),%rdi
  66ddb3:	0f 83 07 fe ff ff    	jae    66dbc0 <parley::editing::geometry::pair_from_entries::<()>+0x70>
  66ddb9:	49 3b be e8 00 00 00 	cmp    0xe8(%r14),%rdi
  66ddc0:	0f 83 fa fd ff ff    	jae    66dbc0 <parley::editing::geometry::pair_from_entries::<()>+0x70>
  66ddc6:	4c 8d 14 ff          	lea    (%rdi,%rdi,8),%r10
  66ddca:	49 c1 e2 04          	shl    $0x4,%r10
  66ddce:	4d 03 56 50          	add    0x50(%r14),%r10
  66ddd2:	4c 8d 1c bf          	lea    (%rdi,%rdi,4),%r11
  66ddd6:	49 c1 e3 04          	shl    $0x4,%r11
  66ddda:	4d 03 9e e0 00 00 00 	add    0xe0(%r14),%r11
  66dde1:	4c 89 b4 24 b8 00 00 	mov    %r14,0xb8(%rsp)
  66dde8:	00 
  66dde9:	4c 89 94 24 c0 00 00 	mov    %r10,0xc0(%rsp)
  66ddf0:	00 
  66ddf1:	4c 89 9c 24 c8 00 00 	mov    %r11,0xc8(%rsp)
  66ddf8:	00 
  66ddf9:	4c 89 8c 24 d0 00 00 	mov    %r9,0xd0(%rsp)
  66de00:	00 
  66de01:	89 84 24 d8 00 00 00 	mov    %eax,0xd8(%rsp)
  66de08:	89 b4 24 dc 00 00 00 	mov    %esi,0xdc(%rsp)
  66de0f:	89 bc 24 e0 00 00 00 	mov    %edi,0xe0(%rsp)
  66de16:	41 8b 40 08          	mov    0x8(%r8),%eax
  66de1a:	4c 8d bc 24 48 01 00 	lea    0x148(%rsp),%r15
  66de21:	00 
  66de22:	48 8d b4 24 b8 00 00 	lea    0xb8(%rsp),%rsi
  66de29:	00 
  66de2a:	4c 89 ff             	mov    %r15,%rdi
  66de2d:	49 89 d4             	mov    %rdx,%r12
  66de30:	89 c2                	mov    %eax,%edx
  66de32:	49 89 cd             	mov    %rcx,%r13
  66de35:	f3 0f 11 44 24 0c    	movss  %xmm0,0xc(%rsp)
  66de3b:	e8 f0 92 ff ff       	call   667130 <<parley::layout::run::Run<()>>::cluster_containing_char>
  66de40:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  66de46:	4c 89 e9             	mov    %r13,%rcx
  66de49:	4c 89 e2             	mov    %r12,%rdx
  66de4c:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  66de53:	00 
  66de54:	48 85 c0             	test   %rax,%rax
  66de57:	0f 84 6f fd ff ff    	je     66dbcc <parley::editing::geometry::pair_from_entries::<()>+0x7c>
  66de5d:	8b bc 24 70 01 00 00 	mov    0x170(%rsp),%edi
  66de64:	48 8b 70 58          	mov    0x58(%rax),%rsi
  66de68:	48 39 fe             	cmp    %rdi,%rsi
  66de6b:	0f 86 2b 01 00 00    	jbe    66df9c <parley::editing::geometry::pair_from_entries::<()>+0x44c>
  66de71:	48 8b 48 50          	mov    0x50(%rax),%rcx
  66de75:	48 8d 14 ff          	lea    (%rdi,%rdi,8),%rdx
  66de79:	48 c1 e2 04          	shl    $0x4,%rdx
  66de7d:	0f 10 40 68          	movups 0x68(%rax),%xmm0
  66de81:	0f 10 88 80 00 00 00 	movups 0x80(%rax),%xmm1
  66de88:	0f 10 90 98 00 00 00 	movups 0x98(%rax),%xmm2
  66de8f:	0f 11 84 24 b8 00 00 	movups %xmm0,0xb8(%rsp)
  66de96:	00 
  66de97:	0f 11 8c 24 c8 00 00 	movups %xmm1,0xc8(%rsp)
  66de9e:	00 
  66de9f:	0f 11 94 24 d8 00 00 	movups %xmm2,0xd8(%rsp)
  66dea6:	00 
  66dea7:	48 8b 44 11 50       	mov    0x50(%rcx,%rdx,1),%rax
  66deac:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
  66deb3:	00 
  66deb4:	8b b4 24 c8 01 00 00 	mov    0x1c8(%rsp),%esi
  66debb:	8b 94 24 cc 01 00 00 	mov    0x1cc(%rsp),%edx
  66dec2:	48 8d bc 24 b8 00 00 	lea    0xb8(%rsp),%rdi
  66dec9:	00 
  66deca:	ff 15 a0 c8 11 00    	call   *0x11c8a0(%rip)        # 78a770 <_DYNAMIC+0x528>
  66ded0:	48 85 c0             	test   %rax,%rax
  66ded3:	40 0f 95 c5          	setne  %bpl
  66ded7:	4c 89 e2             	mov    %r12,%rdx
  66deda:	4c 89 e9             	mov    %r13,%rcx
  66dedd:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  66dee3:	48 39 d0             	cmp    %rdx,%rax
  66dee6:	0f 84 f6 fc ff ff    	je     66dbe2 <parley::editing::geometry::pair_from_entries::<()>+0x92>
  66deec:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
  66def3:	48 89 d8             	mov    %rbx,%rax
  66def6:	48 81 c4 d8 01 00 00 	add    $0x1d8,%rsp
  66defd:	5b                   	pop    %rbx
  66defe:	41 5c                	pop    %r12
  66df00:	41 5d                	pop    %r13
  66df02:	41 5e                	pop    %r14
  66df04:	41 5f                	pop    %r15
  66df06:	5d                   	pop    %rbp
  66df07:	c3                   	ret
  66df08:	4d 8d 04 f8          	lea    (%r8,%rdi,8),%r8
  66df0c:	49 8b 78 10          	mov    0x10(%r8),%rdi
  66df10:	49 3b 7e 58          	cmp    0x58(%r14),%rdi
  66df14:	0f 83 1b fd ff ff    	jae    66dc35 <parley::editing::geometry::pair_from_entries::<()>+0xe5>
  66df1a:	49 3b be e8 00 00 00 	cmp    0xe8(%r14),%rdi
  66df21:	0f 83 0e fd ff ff    	jae    66dc35 <parley::editing::geometry::pair_from_entries::<()>+0xe5>
  66df27:	4c 8d 0c ff          	lea    (%rdi,%rdi,8),%r9
  66df2b:	49 c1 e1 04          	shl    $0x4,%r9
  66df2f:	4d 03 4e 50          	add    0x50(%r14),%r9
  66df33:	4c 8d 14 bf          	lea    (%rdi,%rdi,4),%r10
  66df37:	49 c1 e2 04          	shl    $0x4,%r10
  66df3b:	4d 03 96 e0 00 00 00 	add    0xe0(%r14),%r10
  66df42:	4c 89 74 24 20       	mov    %r14,0x20(%rsp)
  66df47:	4c 89 4c 24 28       	mov    %r9,0x28(%rsp)
  66df4c:	4c 89 54 24 30       	mov    %r10,0x30(%rsp)
  66df51:	4c 89 44 24 38       	mov    %r8,0x38(%rsp)
  66df56:	89 44 24 40          	mov    %eax,0x40(%rsp)
  66df5a:	89 74 24 44          	mov    %esi,0x44(%rsp)
  66df5e:	89 7c 24 48          	mov    %edi,0x48(%rsp)
  66df62:	8b 41 08             	mov    0x8(%rcx),%eax
  66df65:	4c 8d a4 24 b8 00 00 	lea    0xb8(%rsp),%r12
  66df6c:	00 
  66df6d:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
  66df72:	4c 89 e7             	mov    %r12,%rdi
  66df75:	49 89 d5             	mov    %rdx,%r13
  66df78:	89 c2                	mov    %eax,%edx
  66df7a:	e8 b1 91 ff ff       	call   667130 <<parley::layout::run::Run<()>>::cluster_containing_char>
  66df7f:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  66df85:	4c 89 ea             	mov    %r13,%rdx
  66df88:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  66df8f:	00 
  66df90:	48 85 c0             	test   %rax,%rax
  66df93:	4c 0f 44 e0          	cmove  %rax,%r12
  66df97:	e9 a8 fc ff ff       	jmp    66dc44 <parley::editing::geometry::pair_from_entries::<()>+0xf4>
  66df9c:	48 8d 15 ad 21 11 00 	lea    0x1121ad(%rip),%rdx        # 780150 <anon.89d2c5d0d416cd03e9cb3036fced70ec.28.llvm.1506394962952114297>
  66dfa3:	ff 15 ff c5 11 00    	call   *0x11c5ff(%rip)        # 78a5a8 <_DYNAMIC+0x360>
