
/tmp/gpui-monotonic-control-bin/stream16:     file format elf64-x86-64


Disassembly of section .text:

00000000006740a0 <<gpui_canvas::text::planner::Planner>::shape>:
  6740a0:	55                   	push   %rbp
  6740a1:	41 57                	push   %r15
  6740a3:	41 56                	push   %r14
  6740a5:	41 55                	push   %r13
  6740a7:	41 54                	push   %r12
  6740a9:	53                   	push   %rbx
  6740aa:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
  6740b1:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
  6740b8:	00 
  6740b9:	48 81 ec e8 01 00 00 	sub    $0x1e8,%rsp
  6740c0:	44 89 8c 24 2c 02 00 	mov    %r9d,0x22c(%rsp)
  6740c7:	00 
  6740c8:	f3 0f 11 8c 24 cc 01 	movss  %xmm1,0x1cc(%rsp)
  6740cf:	00 00 
  6740d1:	44 89 84 24 c8 01 00 	mov    %r8d,0x1c8(%rsp)
  6740d8:	00 
  6740d9:	f3 0f 11 84 24 84 00 	movss  %xmm0,0x84(%rsp)
  6740e0:	00 00 
  6740e2:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
  6740e7:	49 89 f5             	mov    %rsi,%r13
  6740ea:	48 89 bc 24 38 03 00 	mov    %rdi,0x338(%rsp)
  6740f1:	00 
  6740f2:	4c 8d 24 0a          	lea    (%rdx,%rcx,1),%r12
  6740f6:	48 85 c9             	test   %rcx,%rcx
  6740f9:	48 89 34 24          	mov    %rsi,(%rsp)
  6740fd:	48 89 94 24 48 01 00 	mov    %rdx,0x148(%rsp)
  674104:	00 
  674105:	4c 89 a4 24 b0 01 00 	mov    %r12,0x1b0(%rsp)
  67410c:	00 
  67410d:	0f 84 90 03 00 00    	je     6744a3 <<gpui_canvas::text::planner::Planner>::shape+0x403>
  674113:	49 8d 85 78 0a 00 00 	lea    0xa78(%r13),%rax
  67411a:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  67411f:	48 8d b4 24 ec 0c 00 	lea    0xcec(%rsp),%rsi
  674126:	00 
  674127:	49 8d 45 38          	lea    0x38(%r13),%rax
  67412b:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  674130:	49 8d 45 3c          	lea    0x3c(%r13),%rax
  674134:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  67413b:	00 
  67413c:	49 8d 45 58          	lea    0x58(%r13),%rax
  674140:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
  674147:	00 
  674148:	49 8d 45 5c          	lea    0x5c(%r13),%rax
  67414c:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  674151:	45 31 ff             	xor    %r15d,%r15d
  674154:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  67415b:	00 
  67415c:	4c 8b 05 65 5f 11 00 	mov    0x115f65(%rip),%r8        # 78a0c8 <_DYNAMIC+0x428>
  674163:	49 89 d6             	mov    %rdx,%r14
  674166:	44 89 7c 24 30       	mov    %r15d,0x30(%rsp)
  67416b:	eb 1c                	jmp    674189 <<gpui_canvas::text::planner::Planner>::shape+0xe9>
  67416d:	0f 1f 00             	nopl   (%rax)
  674170:	41 8d 87 d8 df ff ff 	lea    -0x2028(%r15),%eax
  674177:	83 f8 02             	cmp    $0x2,%eax
  67417a:	0f 83 e1 00 00 00    	jae    674261 <<gpui_canvas::text::planner::Planner>::shape+0x1c1>
  674180:	4d 39 e6             	cmp    %r12,%r14
  674183:	0f 84 ba 02 00 00    	je     674443 <<gpui_canvas::text::planner::Planner>::shape+0x3a3>
  674189:	45 0f b6 3e          	movzbl (%r14),%r15d
  67418d:	45 84 ff             	test   %r15b,%r15b
  674190:	78 1e                	js     6741b0 <<gpui_canvas::text::planner::Planner>::shape+0x110>
  674192:	49 ff c6             	inc    %r14
  674195:	41 81 ff 27 20 00 00 	cmp    $0x2027,%r15d
  67419c:	0f 8e 9e 00 00 00    	jle    674240 <<gpui_canvas::text::planner::Planner>::shape+0x1a0>
  6741a2:	eb cc                	jmp    674170 <<gpui_canvas::text::planner::Planner>::shape+0xd0>
  6741a4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  6741ab:	00 00 00 00 00 
  6741b0:	44 89 f8             	mov    %r15d,%eax
  6741b3:	83 e0 1f             	and    $0x1f,%eax
  6741b6:	41 0f b6 56 01       	movzbl 0x1(%r14),%edx
  6741bb:	83 e2 3f             	and    $0x3f,%edx
  6741be:	41 80 ff df          	cmp    $0xdf,%r15b
  6741c2:	76 3d                	jbe    674201 <<gpui_canvas::text::planner::Planner>::shape+0x161>
  6741c4:	41 0f b6 4e 02       	movzbl 0x2(%r14),%ecx
  6741c9:	c1 e2 06             	shl    $0x6,%edx
  6741cc:	83 e1 3f             	and    $0x3f,%ecx
  6741cf:	09 d1                	or     %edx,%ecx
  6741d1:	41 80 ff f0          	cmp    $0xf0,%r15b
  6741d5:	72 44                	jb     67421b <<gpui_canvas::text::planner::Planner>::shape+0x17b>
  6741d7:	45 0f b6 7e 03       	movzbl 0x3(%r14),%r15d
  6741dc:	49 83 c6 04          	add    $0x4,%r14
  6741e0:	83 e0 07             	and    $0x7,%eax
  6741e3:	c1 e0 12             	shl    $0x12,%eax
  6741e6:	c1 e1 06             	shl    $0x6,%ecx
  6741e9:	41 83 e7 3f          	and    $0x3f,%r15d
  6741ed:	41 09 cf             	or     %ecx,%r15d
  6741f0:	41 09 c7             	or     %eax,%r15d
  6741f3:	41 81 ff 27 20 00 00 	cmp    $0x2027,%r15d
  6741fa:	7e 44                	jle    674240 <<gpui_canvas::text::planner::Planner>::shape+0x1a0>
  6741fc:	e9 6f ff ff ff       	jmp    674170 <<gpui_canvas::text::planner::Planner>::shape+0xd0>
  674201:	49 83 c6 02          	add    $0x2,%r14
  674205:	c1 e0 06             	shl    $0x6,%eax
  674208:	09 d0                	or     %edx,%eax
  67420a:	41 89 c7             	mov    %eax,%r15d
  67420d:	41 81 ff 27 20 00 00 	cmp    $0x2027,%r15d
  674214:	7e 2a                	jle    674240 <<gpui_canvas::text::planner::Planner>::shape+0x1a0>
  674216:	e9 55 ff ff ff       	jmp    674170 <<gpui_canvas::text::planner::Planner>::shape+0xd0>
  67421b:	49 83 c6 03          	add    $0x3,%r14
  67421f:	c1 e0 0c             	shl    $0xc,%eax
  674222:	09 c1                	or     %eax,%ecx
  674224:	41 89 cf             	mov    %ecx,%r15d
  674227:	41 81 ff 27 20 00 00 	cmp    $0x2027,%r15d
  67422e:	0f 8f 3c ff ff ff    	jg     674170 <<gpui_canvas::text::planner::Planner>::shape+0xd0>
  674234:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  67423b:	00 00 00 00 00 
  674240:	41 83 ff 0a          	cmp    $0xa,%r15d
  674244:	0f 84 36 ff ff ff    	je     674180 <<gpui_canvas::text::planner::Planner>::shape+0xe0>
  67424a:	41 83 ff 0d          	cmp    $0xd,%r15d
  67424e:	0f 84 2c ff ff ff    	je     674180 <<gpui_canvas::text::planner::Planner>::shape+0xe0>
  674254:	41 81 ff 85 00 00 00 	cmp    $0x85,%r15d
  67425b:	0f 84 1f ff ff ff    	je     674180 <<gpui_canvas::text::planner::Planner>::shape+0xe0>
  674261:	49 89 fd             	mov    %rdi,%r13
  674264:	48 8d 3d ed b5 10 00 	lea    0x10b5ed(%rip),%rdi        # 77f858 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0x30>
  67426b:	48 89 f3             	mov    %rsi,%rbx
  67426e:	44 89 fe             	mov    %r15d,%esi
  674271:	4c 89 c5             	mov    %r8,%rbp
  674274:	ff 15 56 61 11 00    	call   *0x116156(%rip)        # 78a3d0 <_DYNAMIC+0x730>
  67427a:	49 89 e8             	mov    %rbp,%r8
  67427d:	4c 89 ef             	mov    %r13,%rdi
  674280:	48 89 de             	mov    %rbx,%rsi
  674283:	84 c0                	test   %al,%al
  674285:	0f 85 f5 fe ff ff    	jne    674180 <<gpui_canvas::text::planner::Planner>::shape+0xe0>
  67428b:	41 bc 0a 00 00 00    	mov    $0xa,%r12d
  674291:	41 83 ff 20          	cmp    $0x20,%r15d
  674295:	0f 82 5b 02 00 00    	jb     6744f6 <<gpui_canvas::text::planner::Planner>::shape+0x456>
  67429b:	41 8d 47 81          	lea    -0x7f(%r15),%eax
  67429f:	83 f8 21             	cmp    $0x21,%eax
  6742a2:	0f 82 4e 02 00 00    	jb     6744f6 <<gpui_canvas::text::planner::Planner>::shape+0x456>
  6742a8:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  6742ad:	44 89 fe             	mov    %r15d,%esi
  6742b0:	e8 bb 3b 00 00       	call   677e70 <<gpui_canvas::text::planner::Cmap>::glyph_index>
  6742b5:	49 89 e8             	mov    %rbp,%r8
  6742b8:	4c 89 ef             	mov    %r13,%rdi
  6742bb:	a8 01                	test   $0x1,%al
  6742bd:	4c 8b a4 24 b0 01 00 	mov    0x1b0(%rsp),%r12
  6742c4:	00 
  6742c5:	74 0c                	je     6742d3 <<gpui_canvas::text::planner::Planner>::shape+0x233>
  6742c7:	48 89 de             	mov    %rbx,%rsi
  6742ca:	66 85 d2             	test   %dx,%dx
  6742cd:	0f 85 ad fe ff ff    	jne    674180 <<gpui_canvas::text::planner::Planner>::shape+0xe0>
  6742d3:	48 8b 0c 24          	mov    (%rsp),%rcx
  6742d7:	48 8b 81 40 0a 00 00 	mov    0xa40(%rcx),%rax
  6742de:	41 bc 0b 00 00 00    	mov    $0xb,%r12d
  6742e4:	80 78 38 01          	cmpb   $0x1,0x38(%rax)
  6742e8:	0f 85 08 02 00 00    	jne    6744f6 <<gpui_canvas::text::planner::Planner>::shape+0x456>
  6742ee:	48 83 79 30 00       	cmpq   $0x0,0x30(%rcx)
  6742f3:	0f 85 e9 00 00 00    	jne    6743e2 <<gpui_canvas::text::planner::Planner>::shape+0x342>
  6742f9:	ba 48 ab 03 00       	mov    $0x3ab48,%edx
  6742fe:	48 8d 35 f7 17 9b ff 	lea    -0x64e809(%rip),%rsi        # 25afc <gpui_canvas::text::ARABIC_BYTES>
  674305:	31 c9                	xor    %ecx,%ecx
  674307:	41 ff d0             	call   *%r8
  67430a:	83 bc 24 10 07 00 00 	cmpl   $0xffffffff,0x710(%rsp)
  674311:	ff 
  674312:	0f 84 7d 2f 00 00    	je     677295 <<gpui_canvas::text::planner::Planner>::shape+0x31f5>
  674318:	8b 84 24 e8 0c 00 00 	mov    0xce8(%rsp),%eax
  67431f:	89 44 24 08          	mov    %eax,0x8(%rsp)
  674323:	0f 10 03             	movups (%rbx),%xmm0
  674326:	0f 10 4b 0c          	movups 0xc(%rbx),%xmm1
  67432a:	0f 29 84 24 c0 04 00 	movaps %xmm0,0x4c0(%rsp)
  674331:	00 
  674332:	0f 11 8c 24 cc 04 00 	movups %xmm1,0x4cc(%rsp)
  674339:	00 
  67433a:	ba 14 69 00 00       	mov    $0x6914,%edx
  67433f:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  674346:	00 
  674347:	48 8d 35 f6 c2 9e ff 	lea    -0x613d0a(%rip),%rsi        # 60644 <gpui_canvas::text::HEBREW_BYTES>
  67434e:	31 c9                	xor    %ecx,%ecx
  674350:	ff 15 72 5d 11 00    	call   *0x115d72(%rip)        # 78a0c8 <_DYNAMIC+0x428>
  674356:	83 bc 24 10 07 00 00 	cmpl   $0xffffffff,0x710(%rsp)
  67435d:	ff 
  67435e:	0f 84 43 2f 00 00    	je     6772a7 <<gpui_canvas::text::planner::Planner>::shape+0x3207>
  674364:	8b 94 24 e8 0c 00 00 	mov    0xce8(%rsp),%edx
  67436b:	48 8d 84 24 ec 0c 00 	lea    0xcec(%rsp),%rax
  674372:	00 
  674373:	0f 10 00             	movups (%rax),%xmm0
  674376:	0f 10 48 0c          	movups 0xc(%rax),%xmm1
  67437a:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
  674381:	00 
  674382:	0f 11 8c 24 4c 03 00 	movups %xmm1,0x34c(%rsp)
  674389:	00 
  67438a:	48 8b 04 24          	mov    (%rsp),%rax
  67438e:	48 c7 40 30 01 00 00 	movq   $0x1,0x30(%rax)
  674395:	00 
  674396:	8b 4c 24 08          	mov    0x8(%rsp),%ecx
  67439a:	89 48 38             	mov    %ecx,0x38(%rax)
  67439d:	0f 10 84 24 cc 04 00 	movups 0x4cc(%rsp),%xmm0
  6743a4:	00 
  6743a5:	48 8b 8c 24 00 01 00 	mov    0x100(%rsp),%rcx
  6743ac:	00 
  6743ad:	0f 11 41 0c          	movups %xmm0,0xc(%rcx)
  6743b1:	0f 28 84 24 c0 04 00 	movaps 0x4c0(%rsp),%xmm0
  6743b8:	00 
  6743b9:	0f 11 01             	movups %xmm0,(%rcx)
  6743bc:	89 94 24 d0 01 00 00 	mov    %edx,0x1d0(%rsp)
  6743c3:	89 50 58             	mov    %edx,0x58(%rax)
  6743c6:	0f 10 84 24 4c 03 00 	movups 0x34c(%rsp),%xmm0
  6743cd:	00 
  6743ce:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6743d3:	0f 11 40 0c          	movups %xmm0,0xc(%rax)
  6743d7:	0f 28 84 24 40 03 00 	movaps 0x340(%rsp),%xmm0
  6743de:	00 
  6743df:	0f 11 00             	movups %xmm0,(%rax)
  6743e2:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
  6743e7:	44 89 fe             	mov    %r15d,%esi
  6743ea:	e8 81 3a 00 00       	call   677e70 <<gpui_canvas::text::planner::Cmap>::glyph_index>
  6743ef:	66 85 d2             	test   %dx,%dx
  6743f2:	0f 95 c1             	setne  %cl
  6743f5:	20 c1                	and    %al,%cl
  6743f7:	88 4c 24 60          	mov    %cl,0x60(%rsp)
  6743fb:	48 8b bc 24 10 01 00 	mov    0x110(%rsp),%rdi
  674402:	00 
  674403:	44 89 fe             	mov    %r15d,%esi
  674406:	e8 65 3a 00 00       	call   677e70 <<gpui_canvas::text::planner::Cmap>::glyph_index>
  67440b:	66 85 d2             	test   %dx,%dx
  67440e:	0f 95 c1             	setne  %cl
  674411:	20 c1                	and    %al,%cl
  674413:	00 c9                	add    %cl,%cl
  674415:	0a 4c 24 60          	or     0x60(%rsp),%cl
  674419:	0f 84 d7 00 00 00    	je     6744f6 <<gpui_canvas::text::planner::Planner>::shape+0x456>
  67441f:	44 8b 7c 24 30       	mov    0x30(%rsp),%r15d
  674424:	41 08 cf             	or     %cl,%r15b
  674427:	4c 8b a4 24 b0 01 00 	mov    0x1b0(%rsp),%r12
  67442e:	00 
  67442f:	4d 39 e6             	cmp    %r12,%r14
  674432:	48 89 de             	mov    %rbx,%rsi
  674435:	4c 89 ef             	mov    %r13,%rdi
  674438:	49 89 e8             	mov    %rbp,%r8
  67443b:	0f 85 25 fd ff ff    	jne    674166 <<gpui_canvas::text::planner::Planner>::shape+0xc6>
  674441:	eb 05                	jmp    674448 <<gpui_canvas::text::planner::Planner>::shape+0x3a8>
  674443:	44 8b 7c 24 30       	mov    0x30(%rsp),%r15d
  674448:	41 f6 c7 01          	test   $0x1,%r15b
  67444c:	4c 8b 2c 24          	mov    (%rsp),%r13
  674450:	0f 84 c5 00 00 00    	je     67451b <<gpui_canvas::text::planner::Planner>::shape+0x47b>
  674456:	49 83 bd 48 0a 00 00 	cmpq   $0x0,0xa48(%r13)
  67445d:	00 
  67445e:	0f 85 b7 00 00 00    	jne    67451b <<gpui_canvas::text::planner::Planner>::shape+0x47b>
  674464:	48 8d 35 ad 8a 11 00 	lea    0x118aad(%rip),%rsi        # 78cf18 <gpui_canvas::text::ARABIC_FONT>
  67446b:	48 8d 15 8a 16 9b ff 	lea    -0x64e976(%rip),%rdx        # 25afc <gpui_canvas::text::ARABIC_BYTES>
  674472:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  674479:	00 
  67447a:	b9 48 ab 03 00       	mov    $0x3ab48,%ecx
  67447f:	45 31 c0             	xor    %r8d,%r8d
  674482:	e8 09 fa fe ff       	call   663e90 <<gpui_canvas::text::FontFace>::shared_static>
  674487:	83 bc 24 10 07 00 00 	cmpl   $0x1,0x710(%rsp)
  67448e:	01 
  67448f:	75 1a                	jne    6744ab <<gpui_canvas::text::planner::Planner>::shape+0x40b>
  674491:	44 8b a4 24 14 07 00 	mov    0x714(%rsp),%r12d
  674498:	00 
  674499:	44 8b bc 24 18 07 00 	mov    0x718(%rsp),%r15d
  6744a0:	00 
  6744a1:	eb 53                	jmp    6744f6 <<gpui_canvas::text::planner::Planner>::shape+0x456>
  6744a3:	45 31 ff             	xor    %r15d,%r15d
  6744a6:	e9 84 00 00 00       	jmp    67452f <<gpui_canvas::text::planner::Planner>::shape+0x48f>
  6744ab:	44 89 fd             	mov    %r15d,%ebp
  6744ae:	49 8d 9d 48 0a 00 00 	lea    0xa48(%r13),%rbx
  6744b5:	4c 8b bc 24 18 07 00 	mov    0x718(%rsp),%r15
  6744bc:	00 
  6744bd:	48 8b 03             	mov    (%rbx),%rax
  6744c0:	48 85 c0             	test   %rax,%rax
  6744c3:	74 0f                	je     6744d4 <<gpui_canvas::text::planner::Planner>::shape+0x434>
  6744c5:	f0 48 ff 08          	lock decq (%rax)
  6744c9:	75 09                	jne    6744d4 <<gpui_canvas::text::planner::Planner>::shape+0x434>
  6744cb:	48 89 df             	mov    %rbx,%rdi
  6744ce:	ff 15 2c 5a 11 00    	call   *0x115a2c(%rip)        # 789f00 <_DYNAMIC+0x260>
  6744d4:	4d 89 bd 48 0a 00 00 	mov    %r15,0xa48(%r13)
  6744db:	be 01 00 00 00       	mov    $0x1,%esi
  6744e0:	4c 89 ef             	mov    %r13,%rdi
  6744e3:	e8 88 36 00 00       	call   677b70 <<gpui_canvas::text::planner::Planner>::register>
  6744e8:	83 f8 ff             	cmp    $0xffffffff,%eax
  6744eb:	41 89 ef             	mov    %ebp,%r15d
  6744ee:	74 2b                	je     67451b <<gpui_canvas::text::planner::Planner>::shape+0x47b>
  6744f0:	41 89 c4             	mov    %eax,%r12d
  6744f3:	45 31 ff             	xor    %r15d,%r15d
  6744f6:	44 89 a4 24 90 00 00 	mov    %r12d,0x90(%rsp)
  6744fd:	00 
  6744fe:	44 89 bc 24 94 00 00 	mov    %r15d,0x94(%rsp)
  674505:	00 
  674506:	48 c7 84 24 88 00 00 	movq   $0xffffffffffffffff,0x88(%rsp)
  67450d:	00 ff ff ff ff 
  674512:	4c 8b 2c 24          	mov    (%rsp),%r13
  674516:	e9 a6 28 00 00       	jmp    676dc1 <<gpui_canvas::text::planner::Planner>::shape+0x2d21>
  67451b:	41 f6 c7 02          	test   $0x2,%r15b
  67451f:	74 0e                	je     67452f <<gpui_canvas::text::planner::Planner>::shape+0x48f>
  674521:	49 83 bd 50 0a 00 00 	cmpq   $0x0,0xa50(%r13)
  674528:	00 
  674529:	0f 84 2f 2a 00 00    	je     676f5e <<gpui_canvas::text::planner::Planner>::shape+0x2ebe>
  67452f:	48 c7 84 24 a0 02 00 	movq   $0xffffffffffffffff,0x2a0(%rsp)
  674536:	00 ff ff ff ff 
  67453b:	48 8d 05 1c 73 be ff 	lea    -0x418ce4(%rip),%rax        # 25b85e <gpui_canvas::text::PRIMARY_BYTES+0x1f4906>
  674542:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
  674549:	00 
  67454a:	48 c7 84 24 b0 02 00 	movq   $0xc,0x2b0(%rsp)
  674551:	00 0c 00 00 00 
  674556:	48 c7 84 24 b8 02 00 	movq   $0xffffffffffffffff,0x2b8(%rsp)
  67455d:	00 ff ff ff ff 
  674562:	48 8d 05 01 73 be ff 	lea    -0x418cff(%rip),%rax        # 25b86a <gpui_canvas::text::PRIMARY_BYTES+0x1f4912>
  674569:	48 89 84 24 c0 02 00 	mov    %rax,0x2c0(%rsp)
  674570:	00 
  674571:	48 c7 84 24 c8 02 00 	movq   $0x11,0x2c8(%rsp)
  674578:	00 11 00 00 00 
  67457d:	48 c7 84 24 d0 02 00 	movq   $0xffffffffffffffff,0x2d0(%rsp)
  674584:	00 ff ff ff ff 
  674589:	48 8d 1d eb 72 be ff 	lea    -0x418d15(%rip),%rbx        # 25b87b <gpui_canvas::text::PRIMARY_BYTES+0x1f4923>
  674590:	48 89 9c 24 d8 02 00 	mov    %rbx,0x2d8(%rsp)
  674597:	00 
  674598:	48 c7 84 24 e0 02 00 	movq   $0x11,0x2e0(%rsp)
  67459f:	00 11 00 00 00 
  6745a4:	41 f6 c7 01          	test   $0x1,%r15b
  6745a8:	75 1d                	jne    6745c7 <<gpui_canvas::text::planner::Planner>::shape+0x527>
  6745aa:	4c 8d b4 24 b8 02 00 	lea    0x2b8(%rsp),%r14
  6745b1:	00 
  6745b2:	b8 01 00 00 00       	mov    $0x1,%eax
  6745b7:	48 89 84 24 10 02 00 	mov    %rax,0x210(%rsp)
  6745be:	00 
  6745bf:	41 f6 c7 02          	test   $0x2,%r15b
  6745c3:	75 25                	jne    6745ea <<gpui_canvas::text::planner::Planner>::shape+0x54a>
  6745c5:	eb 5b                	jmp    674622 <<gpui_canvas::text::planner::Planner>::shape+0x582>
  6745c7:	4c 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%r14
  6745ce:	00 
  6745cf:	48 89 84 24 c0 02 00 	mov    %rax,0x2c0(%rsp)
  6745d6:	00 
  6745d7:	b8 02 00 00 00       	mov    $0x2,%eax
  6745dc:	48 89 84 24 10 02 00 	mov    %rax,0x210(%rsp)
  6745e3:	00 
  6745e4:	41 f6 c7 02          	test   $0x2,%r15b
  6745e8:	74 38                	je     674622 <<gpui_canvas::text::planner::Planner>::shape+0x582>
  6745ea:	49 8b 36             	mov    (%r14),%rsi
  6745ed:	48 83 fe fd          	cmp    $0xfffffffffffffffd,%rsi
  6745f1:	77 14                	ja     674607 <<gpui_canvas::text::planner::Planner>::shape+0x567>
  6745f3:	48 85 f6             	test   %rsi,%rsi
  6745f6:	74 0f                	je     674607 <<gpui_canvas::text::planner::Planner>::shape+0x567>
  6745f8:	49 8b 7e 08          	mov    0x8(%r14),%rdi
  6745fc:	ba 01 00 00 00       	mov    $0x1,%edx
  674601:	ff 15 d1 58 11 00    	call   *0x1158d1(%rip)        # 789ed8 <_DYNAMIC+0x238>
  674607:	49 c7 06 ff ff ff ff 	movq   $0xffffffffffffffff,(%r14)
  67460e:	49 89 5e 08          	mov    %rbx,0x8(%r14)
  674612:	49 c7 46 10 11 00 00 	movq   $0x11,0x10(%r14)
  674619:	00 
  67461a:	48 ff 84 24 10 02 00 	incq   0x210(%rsp)
  674621:	00 
  674622:	48 c7 84 24 e8 00 00 	movq   $0x0,0xe8(%rsp)
  674629:	00 00 00 00 00 
  67462e:	48 c7 84 24 f0 00 00 	movq   $0x4,0xf0(%rsp)
  674635:	00 04 00 00 00 
  67463a:	48 c7 84 24 f8 00 00 	movq   $0x0,0xf8(%rsp)
  674641:	00 00 00 00 00 
  674646:	48 c7 84 24 50 01 00 	movq   $0xffffffffffffffff,0x150(%rsp)
  67464d:	00 ff ff ff ff 
  674652:	f6 84 24 c8 01 00 00 	testb  $0x1,0x1c8(%rsp)
  674659:	01 
  67465a:	75 11                	jne    67466d <<gpui_canvas::text::planner::Planner>::shape+0x5cd>
  67465c:	f3 0f 10 05 e8 91 9a 	movss  -0x656e18(%rip),%xmm0        # 1d84c <GCC_except_table0+0x94>
  674663:	ff 
  674664:	f3 0f 11 84 24 cc 01 	movss  %xmm0,0x1cc(%rsp)
  67466b:	00 00 
  67466d:	49 8d 45 78          	lea    0x78(%r13),%rax
  674671:	48 89 84 24 30 03 00 	mov    %rax,0x330(%rsp)
  674678:	00 
  674679:	49 8d 85 38 06 00 00 	lea    0x638(%r13),%rax
  674680:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
  674687:	00 
  674688:	49 8d 85 c8 08 00 00 	lea    0x8c8(%r13),%rax
  67468f:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  674694:	4c 8d ac 24 50 03 00 	lea    0x350(%rsp),%r13
  67469b:	00 
  67469c:	0f 57 c0             	xorps  %xmm0,%xmm0
  67469f:	0f 29 84 24 80 02 00 	movaps %xmm0,0x280(%rsp)
  6746a6:	00 
  6746a7:	f3 0f 11 44 24 1c    	movss  %xmm0,0x1c(%rsp)
  6746ad:	f3 0f 11 44 24 7c    	movss  %xmm0,0x7c(%rsp)
  6746b3:	4c 8d a4 24 c8 04 00 	lea    0x4c8(%rsp),%r12
  6746ba:	00 
  6746bb:	48 8d 05 d6 b2 10 00 	lea    0x10b2d6(%rip),%rax        # 77f998 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0x170>
  6746c2:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  6746c7:	48 8d 05 ca b0 10 00 	lea    0x10b0ca(%rip),%rax        # 77f798 <anon.abe2914d8fd9d1076326722b06c47a5f.25.llvm.962491032109686297>
  6746ce:	48 89 84 24 70 02 00 	mov    %rax,0x270(%rsp)
  6746d5:	00 
  6746d6:	48 c7 84 24 08 02 00 	movq   $0x0,0x208(%rsp)
  6746dd:	00 00 00 00 00 
  6746e2:	31 d2                	xor    %edx,%edx
  6746e4:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  6746eb:	00 
  6746ec:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  6746f1:	31 c0                	xor    %eax,%eax
  6746f3:	be fe ff ff ff       	mov    $0xfffffffe,%esi
  6746f8:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
  6746fd:	83 fe fe             	cmp    $0xfffffffe,%esi
  674700:	75 2e                	jne    674730 <<gpui_canvas::text::planner::Planner>::shape+0x690>
  674702:	4c 8b 4c 24 28       	mov    0x28(%rsp),%r9
  674707:	4c 3b 8c 24 b0 01 00 	cmp    0x1b0(%rsp),%r9
  67470e:	00 
  67470f:	74 33                	je     674744 <<gpui_canvas::text::planner::Planner>::shape+0x6a4>
  674711:	41 0f b6 09          	movzbl (%r9),%ecx
  674715:	84 c9                	test   %cl,%cl
  674717:	78 46                	js     67475f <<gpui_canvas::text::planner::Planner>::shape+0x6bf>
  674719:	49 8d 51 01          	lea    0x1(%r9),%rdx
  67471d:	e9 9a 00 00 00       	jmp    6747bc <<gpui_canvas::text::planner::Planner>::shape+0x71c>
  674722:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  674729:	1f 84 00 00 00 00 00 
  674730:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
  674735:	89 f1                	mov    %esi,%ecx
  674737:	4c 8b 84 24 10 03 00 	mov    0x310(%rsp),%r8
  67473e:	00 
  67473f:	e9 81 00 00 00       	jmp    6747c5 <<gpui_canvas::text::planner::Planner>::shape+0x725>
  674744:	c7 84 24 80 00 00 00 	movl   $0xfffffffe,0x80(%rsp)
  67474b:	fe ff ff ff 
  67474f:	b1 01                	mov    $0x1,%cl
  674751:	89 4c 24 4c          	mov    %ecx,0x4c(%rsp)
  674755:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
  67475a:	e9 d7 01 00 00       	jmp    674936 <<gpui_canvas::text::planner::Planner>::shape+0x896>
  67475f:	49 89 c0             	mov    %rax,%r8
  674762:	89 c8                	mov    %ecx,%eax
  674764:	83 e0 1f             	and    $0x1f,%eax
  674767:	41 0f b6 79 01       	movzbl 0x1(%r9),%edi
  67476c:	83 e7 3f             	and    $0x3f,%edi
  67476f:	80 f9 e0             	cmp    $0xe0,%cl
  674772:	72 2d                	jb     6747a1 <<gpui_canvas::text::planner::Planner>::shape+0x701>
  674774:	41 0f b6 71 02       	movzbl 0x2(%r9),%esi
  674779:	c1 e7 06             	shl    $0x6,%edi
  67477c:	83 e6 3f             	and    $0x3f,%esi
  67477f:	09 fe                	or     %edi,%esi
  674781:	80 f9 f0             	cmp    $0xf0,%cl
  674784:	72 28                	jb     6747ae <<gpui_canvas::text::planner::Planner>::shape+0x70e>
  674786:	49 8d 51 04          	lea    0x4(%r9),%rdx
  67478a:	41 0f b6 49 03       	movzbl 0x3(%r9),%ecx
  67478f:	83 e0 07             	and    $0x7,%eax
  674792:	c1 e0 12             	shl    $0x12,%eax
  674795:	c1 e6 06             	shl    $0x6,%esi
  674798:	83 e1 3f             	and    $0x3f,%ecx
  67479b:	09 f1                	or     %esi,%ecx
  67479d:	09 c1                	or     %eax,%ecx
  67479f:	eb 18                	jmp    6747b9 <<gpui_canvas::text::planner::Planner>::shape+0x719>
  6747a1:	49 8d 51 02          	lea    0x2(%r9),%rdx
  6747a5:	c1 e0 06             	shl    $0x6,%eax
  6747a8:	09 f8                	or     %edi,%eax
  6747aa:	89 c1                	mov    %eax,%ecx
  6747ac:	eb 0b                	jmp    6747b9 <<gpui_canvas::text::planner::Planner>::shape+0x719>
  6747ae:	49 8d 51 03          	lea    0x3(%r9),%rdx
  6747b2:	c1 e0 0c             	shl    $0xc,%eax
  6747b5:	09 c6                	or     %eax,%esi
  6747b7:	89 f1                	mov    %esi,%ecx
  6747b9:	4c 89 c0             	mov    %r8,%rax
  6747bc:	49 89 c0             	mov    %rax,%r8
  6747bf:	4c 29 c8             	sub    %r9,%rax
  6747c2:	48 01 d0             	add    %rdx,%rax
  6747c5:	c7 84 24 80 00 00 00 	movl   $0xfffffffe,0x80(%rsp)
  6747cc:	fe ff ff ff 
  6747d0:	40 b6 01             	mov    $0x1,%sil
  6747d3:	89 74 24 4c          	mov    %esi,0x4c(%rsp)
  6747d7:	83 f9 0c             	cmp    $0xc,%ecx
  6747da:	7e 24                	jle    674800 <<gpui_canvas::text::planner::Planner>::shape+0x760>
  6747dc:	83 f9 0d             	cmp    $0xd,%ecx
  6747df:	0f 84 5b 01 00 00    	je     674940 <<gpui_canvas::text::planner::Planner>::shape+0x8a0>
  6747e5:	81 f9 85 00 00 00    	cmp    $0x85,%ecx
  6747eb:	74 21                	je     67480e <<gpui_canvas::text::planner::Planner>::shape+0x76e>
  6747ed:	81 f9 29 20 00 00    	cmp    $0x2029,%ecx
  6747f3:	74 19                	je     67480e <<gpui_canvas::text::planner::Planner>::shape+0x76e>
  6747f5:	e9 83 00 00 00       	jmp    67487d <<gpui_canvas::text::planner::Planner>::shape+0x7dd>
  6747fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  674800:	83 f9 ff             	cmp    $0xffffffff,%ecx
  674803:	0f 84 23 01 00 00    	je     67492c <<gpui_canvas::text::planner::Planner>::shape+0x88c>
  674809:	83 f9 0a             	cmp    $0xa,%ecx
  67480c:	75 6f                	jne    67487d <<gpui_canvas::text::planner::Planner>::shape+0x7dd>
  67480e:	48 89 54 24 28       	mov    %rdx,0x28(%rsp)
  674813:	81 f9 80 00 00 00    	cmp    $0x80,%ecx
  674819:	0f 83 32 01 00 00    	jae    674951 <<gpui_canvas::text::planner::Planner>::shape+0x8b1>
  67481f:	49 8d 70 01          	lea    0x1(%r8),%rsi
  674823:	83 f9 0d             	cmp    $0xd,%ecx
  674826:	0f 85 37 01 00 00    	jne    674963 <<gpui_canvas::text::planner::Planner>::shape+0x8c3>
  67482c:	4c 8b 4c 24 28       	mov    0x28(%rsp),%r9
  674831:	4c 3b 8c 24 b0 01 00 	cmp    0x1b0(%rsp),%r9
  674838:	00 
  674839:	0f 84 68 23 00 00    	je     676ba7 <<gpui_canvas::text::planner::Planner>::shape+0x2b07>
  67483f:	45 0f b6 11          	movzbl (%r9),%r10d
  674843:	49 89 f3             	mov    %rsi,%r11
  674846:	45 84 d2             	test   %r10b,%r10b
  674849:	0f 88 68 23 00 00    	js     676bb7 <<gpui_canvas::text::planner::Planner>::shape+0x2b17>
  67484f:	49 8d 59 01          	lea    0x1(%r9),%rbx
  674853:	e9 be 23 00 00       	jmp    676c16 <<gpui_canvas::text::planner::Planner>::shape+0x2b76>
  674858:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  67485f:	00 
  674860:	81 f9 29 20 00 00    	cmp    $0x2029,%ecx
  674866:	0f 84 d9 00 00 00    	je     674945 <<gpui_canvas::text::planner::Planner>::shape+0x8a5>
  67486c:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
  674871:	81 f9 85 00 00 00    	cmp    $0x85,%ecx
  674877:	0f 84 c8 00 00 00    	je     674945 <<gpui_canvas::text::planner::Planner>::shape+0x8a5>
  67487d:	48 3b 94 24 b0 01 00 	cmp    0x1b0(%rsp),%rdx
  674884:	00 
  674885:	0f 84 a1 00 00 00    	je     67492c <<gpui_canvas::text::planner::Planner>::shape+0x88c>
  67488b:	49 89 c0             	mov    %rax,%r8
  67488e:	0f b6 0a             	movzbl (%rdx),%ecx
  674891:	84 c9                	test   %cl,%cl
  674893:	78 0b                	js     6748a0 <<gpui_canvas::text::planner::Planner>::shape+0x800>
  674895:	48 8d 42 01          	lea    0x1(%rdx),%rax
  674899:	eb 65                	jmp    674900 <<gpui_canvas::text::planner::Planner>::shape+0x860>
  67489b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6748a0:	89 c8                	mov    %ecx,%eax
  6748a2:	83 e0 1f             	and    $0x1f,%eax
  6748a5:	0f b6 7a 01          	movzbl 0x1(%rdx),%edi
  6748a9:	83 e7 3f             	and    $0x3f,%edi
  6748ac:	80 f9 df             	cmp    $0xdf,%cl
  6748af:	76 2e                	jbe    6748df <<gpui_canvas::text::planner::Planner>::shape+0x83f>
  6748b1:	0f b6 72 02          	movzbl 0x2(%rdx),%esi
  6748b5:	c1 e7 06             	shl    $0x6,%edi
  6748b8:	83 e6 3f             	and    $0x3f,%esi
  6748bb:	09 fe                	or     %edi,%esi
  6748bd:	80 f9 f0             	cmp    $0xf0,%cl
  6748c0:	72 2d                	jb     6748ef <<gpui_canvas::text::planner::Planner>::shape+0x84f>
  6748c2:	48 8d 7a 04          	lea    0x4(%rdx),%rdi
  6748c6:	0f b6 4a 03          	movzbl 0x3(%rdx),%ecx
  6748ca:	83 e0 07             	and    $0x7,%eax
  6748cd:	c1 e0 12             	shl    $0x12,%eax
  6748d0:	c1 e6 06             	shl    $0x6,%esi
  6748d3:	83 e1 3f             	and    $0x3f,%ecx
  6748d6:	09 f1                	or     %esi,%ecx
  6748d8:	09 c1                	or     %eax,%ecx
  6748da:	48 89 f8             	mov    %rdi,%rax
  6748dd:	eb 21                	jmp    674900 <<gpui_canvas::text::planner::Planner>::shape+0x860>
  6748df:	48 8d 72 02          	lea    0x2(%rdx),%rsi
  6748e3:	c1 e0 06             	shl    $0x6,%eax
  6748e6:	09 f8                	or     %edi,%eax
  6748e8:	89 c1                	mov    %eax,%ecx
  6748ea:	48 89 f0             	mov    %rsi,%rax
  6748ed:	eb 11                	jmp    674900 <<gpui_canvas::text::planner::Planner>::shape+0x860>
  6748ef:	48 8d 4a 03          	lea    0x3(%rdx),%rcx
  6748f3:	c1 e0 0c             	shl    $0xc,%eax
  6748f6:	09 c6                	or     %eax,%esi
  6748f8:	48 89 c8             	mov    %rcx,%rax
  6748fb:	89 f1                	mov    %esi,%ecx
  6748fd:	0f 1f 00             	nopl   (%rax)
  674900:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  674905:	48 29 d0             	sub    %rdx,%rax
  674908:	4c 01 c0             	add    %r8,%rax
  67490b:	81 f9 84 00 00 00    	cmp    $0x84,%ecx
  674911:	0f 8f 49 ff ff ff    	jg     674860 <<gpui_canvas::text::planner::Planner>::shape+0x7c0>
  674917:	83 f9 0a             	cmp    $0xa,%ecx
  67491a:	74 29                	je     674945 <<gpui_canvas::text::planner::Planner>::shape+0x8a5>
  67491c:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
  674921:	83 f9 0d             	cmp    $0xd,%ecx
  674924:	0f 85 53 ff ff ff    	jne    67487d <<gpui_canvas::text::planner::Planner>::shape+0x7dd>
  67492a:	eb 19                	jmp    674945 <<gpui_canvas::text::planner::Planner>::shape+0x8a5>
  67492c:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
  674931:	48 89 54 24 28       	mov    %rdx,0x28(%rsp)
  674936:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  67493b:	48 89 fe             	mov    %rdi,%rsi
  67493e:	eb 33                	jmp    674973 <<gpui_canvas::text::planner::Planner>::shape+0x8d3>
  674940:	48 89 54 24 28       	mov    %rdx,0x28(%rsp)
  674945:	81 f9 80 00 00 00    	cmp    $0x80,%ecx
  67494b:	0f 82 ce fe ff ff    	jb     67481f <<gpui_canvas::text::planner::Planner>::shape+0x77f>
  674951:	81 f9 00 08 00 00    	cmp    $0x800,%ecx
  674957:	be 03 00 00 00       	mov    $0x3,%esi
  67495c:	48 83 de 00          	sbb    $0x0,%rsi
  674960:	4c 01 c6             	add    %r8,%rsi
  674963:	c7 44 24 4c 00 00 00 	movl   $0x0,0x4c(%rsp)
  67496a:	00 
  67496b:	4c 89 c1             	mov    %r8,%rcx
  67496e:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  674973:	48 89 ca             	mov    %rcx,%rdx
  674976:	48 29 fa             	sub    %rdi,%rdx
  674979:	48 89 94 24 10 01 00 	mov    %rdx,0x110(%rsp)
  674980:	00 
  674981:	0f 82 98 2c 00 00    	jb     67761f <<gpui_canvas::text::planner::Planner>::shape+0x357f>
  674987:	48 83 7c 24 30 00    	cmpq   $0x0,0x30(%rsp)
  67498d:	48 89 84 24 20 03 00 	mov    %rax,0x320(%rsp)
  674994:	00 
  674995:	74 2f                	je     6749c6 <<gpui_canvas::text::planner::Planner>::shape+0x926>
  674997:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
  67499c:	48 3b 54 24 50       	cmp    0x50(%rsp),%rdx
  6749a1:	73 1d                	jae    6749c0 <<gpui_canvas::text::planner::Planner>::shape+0x920>
  6749a3:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  6749aa:	00 
  6749ab:	80 3c 10 bf          	cmpb   $0xbf,(%rax,%rdx,1)
  6749af:	7f 15                	jg     6749c6 <<gpui_canvas::text::planner::Planner>::shape+0x926>
  6749b1:	e9 69 2c 00 00       	jmp    67761f <<gpui_canvas::text::planner::Planner>::shape+0x357f>
  6749b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  6749bd:	00 00 00 
  6749c0:	0f 85 59 2c 00 00    	jne    67761f <<gpui_canvas::text::planner::Planner>::shape+0x357f>
  6749c6:	48 85 c9             	test   %rcx,%rcx
  6749c9:	74 2b                	je     6749f6 <<gpui_canvas::text::planner::Planner>::shape+0x956>
  6749cb:	48 3b 4c 24 50       	cmp    0x50(%rsp),%rcx
  6749d0:	73 1e                	jae    6749f0 <<gpui_canvas::text::planner::Planner>::shape+0x950>
  6749d2:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  6749d9:	00 
  6749da:	80 3c 08 c0          	cmpb   $0xc0,(%rax,%rcx,1)
  6749de:	7d 16                	jge    6749f6 <<gpui_canvas::text::planner::Planner>::shape+0x956>
  6749e0:	e9 3a 2c 00 00       	jmp    67761f <<gpui_canvas::text::planner::Planner>::shape+0x357f>
  6749e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6749ec:	00 00 00 00 
  6749f0:	0f 85 29 2c 00 00    	jne    67761f <<gpui_canvas::text::planner::Planner>::shape+0x357f>
  6749f6:	48 89 8c 24 00 01 00 	mov    %rcx,0x100(%rsp)
  6749fd:	00 
  6749fe:	48 89 b4 24 18 03 00 	mov    %rsi,0x318(%rsp)
  674a05:	00 
  674a06:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  674a0d:	00 
  674a0e:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  674a13:	48 01 c1             	add    %rax,%rcx
  674a16:	48 8d bc 24 98 04 00 	lea    0x498(%rsp),%rdi
  674a1d:	00 
  674a1e:	48 8b b4 24 30 03 00 	mov    0x330(%rsp),%rsi
  674a25:	00 
  674a26:	48 8b 94 24 28 03 00 	mov    0x328(%rsp),%rdx
  674a2d:	00 
  674a2e:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  674a33:	4c 8b 84 24 10 01 00 	mov    0x110(%rsp),%r8
  674a3a:	00 
  674a3b:	f3 0f 10 05 99 8d 9a 	movss  -0x657267(%rip),%xmm0        # 1d7dc <GCC_except_table0+0x24>
  674a42:	ff 
  674a43:	45 31 c9             	xor    %r9d,%r9d
  674a46:	e8 95 f9 fe ff       	call   6643e0 <<parley::context::LayoutContext<()>>::ranged_builder>
  674a4b:	48 8d bc 24 98 04 00 	lea    0x498(%rsp),%rdi
  674a52:	00 
  674a53:	48 8d b4 24 a0 02 00 	lea    0x2a0(%rsp),%rsi
  674a5a:	00 
  674a5b:	48 8b 94 24 10 02 00 	mov    0x210(%rsp),%rdx
  674a62:	00 
  674a63:	e8 a8 45 ff ff       	call   669010 <<parley::builder::RangedBuilder<()>>::push_default::<&[parlance::font_family::FontFamilyName]>>
  674a68:	4c 8b bc 24 98 04 00 	mov    0x498(%rsp),%r15
  674a6f:	00 
  674a70:	48 8b 9c 24 a0 04 00 	mov    0x4a0(%rsp),%rbx
  674a77:	00 
  674a78:	49 8d b7 30 02 00 00 	lea    0x230(%r15),%rsi
  674a7f:	c6 84 24 10 07 00 00 	movb   $0x1,0x710(%rsp)
  674a86:	01 
  674a87:	f3 0f 10 84 24 84 00 	movss  0x84(%rsp),%xmm0
  674a8e:	00 00 
  674a90:	f3 0f 11 84 24 14 07 	movss  %xmm0,0x714(%rsp)
  674a97:	00 00 
  674a99:	f3 0f 10 84 24 b8 04 	movss  0x4b8(%rsp),%xmm0
  674aa0:	00 00 
  674aa2:	48 8d bc 24 c0 04 00 	lea    0x4c0(%rsp),%rdi
  674aa9:	00 
  674aaa:	48 89 f5             	mov    %rsi,%rbp
  674aad:	48 89 da             	mov    %rbx,%rdx
  674ab0:	4c 8d b4 24 10 07 00 	lea    0x710(%rsp),%r14
  674ab7:	00 
  674ab8:	4c 89 f1             	mov    %r14,%rcx
  674abb:	f3 0f 11 44 24 60    	movss  %xmm0,0x60(%rsp)
  674ac1:	e8 4a 0a ff ff       	call   665510 <<parley::resolve::ResolveContext>::resolve_property::<()>>
  674ac6:	4c 89 f7             	mov    %r14,%rdi
  674ac9:	e8 f2 45 ff ff       	call   6690c0 <core::ptr::drop_glue::<parley::style::StyleProperty<()>>>
  674ace:	49 83 bf 20 05 00 00 	cmpq   $0xffffffffffffffff,0x520(%r15)
  674ad5:	ff 
  674ad6:	0f 84 7e 27 00 00    	je     67725a <<gpui_canvas::text::planner::Planner>::shape+0x31ba>
  674adc:	4d 8d b7 98 04 00 00 	lea    0x498(%r15),%r14
  674ae3:	4c 89 f7             	mov    %r14,%rdi
  674ae6:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
  674aed:	00 
  674aee:	e8 bd 0f ff ff       	call   665ab0 <<parley::resolve::ResolvedStyle<()>>::apply>
  674af3:	66 c7 84 24 10 07 00 	movw   $0x117,0x710(%rsp)
  674afa:	00 17 01 
  674afd:	48 8d bc 24 c0 04 00 	lea    0x4c0(%rsp),%rdi
  674b04:	00 
  674b05:	48 89 ee             	mov    %rbp,%rsi
  674b08:	48 89 da             	mov    %rbx,%rdx
  674b0b:	48 8d 9c 24 10 07 00 	lea    0x710(%rsp),%rbx
  674b12:	00 
  674b13:	48 89 d9             	mov    %rbx,%rcx
  674b16:	f3 0f 10 44 24 60    	movss  0x60(%rsp),%xmm0
  674b1c:	e8 ef 09 ff ff       	call   665510 <<parley::resolve::ResolveContext>::resolve_property::<()>>
  674b21:	48 89 df             	mov    %rbx,%rdi
  674b24:	e8 97 45 ff ff       	call   6690c0 <core::ptr::drop_glue::<parley::style::StyleProperty<()>>>
  674b29:	49 83 bf 20 05 00 00 	cmpq   $0xffffffffffffffff,0x520(%r15)
  674b30:	ff 
  674b31:	0f 84 23 27 00 00    	je     67725a <<gpui_canvas::text::planner::Planner>::shape+0x31ba>
  674b37:	4c 89 f7             	mov    %r14,%rdi
  674b3a:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
  674b41:	00 
  674b42:	e8 69 0f ff ff       	call   665ab0 <<parley::resolve::ResolvedStyle<()>>::apply>
  674b47:	48 8d bc 24 98 04 00 	lea    0x498(%rsp),%rdi
  674b4e:	00 
  674b4f:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  674b54:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  674b59:	48 8b 8c 24 10 01 00 	mov    0x110(%rsp),%rcx
  674b60:	00 
  674b61:	e8 1a 3e ff ff       	call   668980 <<parley::builder::RangedBuilder<()>>::build_into::<&str>>
  674b66:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  674b6d:	00 
  674b6e:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  674b73:	e8 08 87 00 00       	call   67d280 <<parley::layout::line_break::BreakLines<()>>::new>
  674b78:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  674b7f:	00 
  674b80:	f3 0f 10 84 24 cc 01 	movss  0x1cc(%rsp),%xmm0
  674b87:	00 00 
  674b89:	e8 d2 77 00 00       	call   67c360 <<parley::layout::line_break::BreakLines<()>>::break_remaining>
  674b8e:	80 bc 24 2c 02 00 00 	cmpb   $0x0,0x22c(%rsp)
  674b95:	00 
  674b96:	74 18                	je     674bb0 <<gpui_canvas::text::planner::Planner>::shape+0xb10>
  674b98:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  674b9f:	00 ff 
  674ba1:	0f 85 fc 01 00 00    	jne    674da3 <<gpui_canvas::text::planner::Planner>::shape+0xd03>
  674ba7:	31 c0                	xor    %eax,%eax
  674ba9:	e9 78 01 00 00       	jmp    674d26 <<gpui_canvas::text::planner::Planner>::shape+0xc86>
  674bae:	66 90                	xchg   %ax,%ax
  674bb0:	48 83 7c 24 30 00    	cmpq   $0x0,0x30(%rsp)
  674bb6:	48 8b 84 24 00 01 00 	mov    0x100(%rsp),%rax
  674bbd:	00 
  674bbe:	0f 85 4c 01 00 00    	jne    674d10 <<gpui_canvas::text::planner::Planner>::shape+0xc70>
  674bc4:	48 3b 44 24 50       	cmp    0x50(%rsp),%rax
  674bc9:	0f 85 41 01 00 00    	jne    674d10 <<gpui_canvas::text::planner::Planner>::shape+0xc70>
  674bcf:	48 8b 04 24          	mov    (%rsp),%rax
  674bd3:	48 83 b8 e0 09 00 00 	cmpq   $0x1,0x9e0(%rax)
  674bda:	01 
  674bdb:	0f 85 2f 01 00 00    	jne    674d10 <<gpui_canvas::text::planner::Planner>::shape+0xc70>
  674be1:	48 8b 14 24          	mov    (%rsp),%rdx
  674be5:	48 8b 82 d8 09 00 00 	mov    0x9d8(%rdx),%rax
  674bec:	48 8d 48 70          	lea    0x70(%rax),%rcx
  674bf0:	48 89 8c 24 18 07 00 	mov    %rcx,0x718(%rsp)
  674bf7:	00 
  674bf8:	48 c7 84 24 20 07 00 	movq   $0x0,0x720(%rsp)
  674bff:	00 00 00 00 00 
  674c04:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  674c09:	48 89 b4 24 28 07 00 	mov    %rsi,0x728(%rsp)
  674c10:	00 
  674c11:	48 c7 84 24 58 07 00 	movq   $0x0,0x758(%rsp)
  674c18:	00 00 00 00 00 
  674c1d:	48 89 94 24 c0 04 00 	mov    %rdx,0x4c0(%rsp)
  674c24:	00 
  674c25:	48 89 8c 24 10 07 00 	mov    %rcx,0x710(%rsp)
  674c2c:	00 
  674c2d:	48 8b 78 10          	mov    0x10(%rax),%rdi
  674c31:	48 8b 70 18          	mov    0x18(%rax),%rsi
  674c35:	48 8b 92 f8 09 00 00 	mov    0x9f8(%rdx),%rdx
  674c3c:	48 39 fe             	cmp    %rdi,%rsi
  674c3f:	0f 82 91 29 00 00    	jb     6775d6 <<gpui_canvas::text::planner::Planner>::shape+0x3536>
  674c45:	48 39 d6             	cmp    %rdx,%rsi
  674c48:	0f 87 88 29 00 00    	ja     6775d6 <<gpui_canvas::text::planner::Planner>::shape+0x3536>
  674c4e:	48 8b 04 24          	mov    (%rsp),%rax
  674c52:	48 8b 80 f0 09 00 00 	mov    0x9f0(%rax),%rax
  674c59:	48 8d 0c bf          	lea    (%rdi,%rdi,4),%rcx
  674c5d:	48 8d 0c c8          	lea    (%rax,%rcx,8),%rcx
  674c61:	48 8d 14 b6          	lea    (%rsi,%rsi,4),%rdx
  674c65:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
  674c69:	48 89 8c 24 30 07 00 	mov    %rcx,0x730(%rsp)
  674c70:	00 
  674c71:	48 89 84 24 38 07 00 	mov    %rax,0x738(%rsp)
  674c78:	00 
  674c79:	48 c7 84 24 40 07 00 	movq   $0x0,0x740(%rsp)
  674c80:	00 00 00 00 00 
  674c85:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  674c8a:	48 89 84 24 48 07 00 	mov    %rax,0x748(%rsp)
  674c91:	00 
  674c92:	c7 84 24 50 07 00 00 	movl   $0x0,0x750(%rsp)
  674c99:	00 00 00 00 
  674c9d:	48 8d bc 24 30 07 00 	lea    0x730(%rsp),%rdi
  674ca4:	00 
  674ca5:	48 8d 94 24 c0 04 00 	lea    0x4c0(%rsp),%rdx
  674cac:	00 
  674cad:	e8 ce 97 00 00       	call   67e480 <<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}> as core::iter::traits::iterator::Iterator>::try_fold::<(), core::iter::adapters::filter_map::filter_map_try_fold<parley::layout::line::LineItem<()>, parley::layout::run::Run<()>, (), core::ops::control_flow::ControlFlow<()>, <parley::layout::line::Line<()>>::runs::{closure#0}, &mut core::iter::traits::iterator::Iterator::all::check<parley::layout::run::Run<()>, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#2}>::{closure#0}>::{closure#0}, core::ops::control_flow::ControlFlow<()>>>
  674cb2:	48 c7 84 24 20 07 00 	movq   $0x1,0x720(%rsp)
  674cb9:	00 01 00 00 00 
  674cbe:	84 c0                	test   %al,%al
  674cc0:	75 4e                	jne    674d10 <<gpui_canvas::text::planner::Planner>::shape+0xc70>
  674cc2:	48 c7 84 24 30 07 00 	movq   $0x0,0x730(%rsp)
  674cc9:	00 00 00 00 00 
  674cce:	48 83 bc 24 58 07 00 	cmpq   $0x0,0x758(%rsp)
  674cd5:	00 00 
  674cd7:	0f 84 4f 1e 00 00    	je     676b2c <<gpui_canvas::text::planner::Planner>::shape+0x2a8c>
  674cdd:	48 8d bc 24 58 07 00 	lea    0x758(%rsp),%rdi
  674ce4:	00 
  674ce5:	48 8d b4 24 80 07 00 	lea    0x780(%rsp),%rsi
  674cec:	00 
  674ced:	48 8d 94 24 c0 04 00 	lea    0x4c0(%rsp),%rdx
  674cf4:	00 
  674cf5:	e8 86 97 00 00       	call   67e480 <<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}> as core::iter::traits::iterator::Iterator>::try_fold::<(), core::iter::adapters::filter_map::filter_map_try_fold<parley::layout::line::LineItem<()>, parley::layout::run::Run<()>, (), core::ops::control_flow::ControlFlow<()>, <parley::layout::line::Line<()>>::runs::{closure#0}, &mut core::iter::traits::iterator::Iterator::all::check<parley::layout::run::Run<()>, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#2}>::{closure#0}>::{closure#0}, core::ops::control_flow::ControlFlow<()>>>
  674cfa:	84 c0                	test   %al,%al
  674cfc:	0f 84 2a 1e 00 00    	je     676b2c <<gpui_canvas::text::planner::Planner>::shape+0x2a8c>
  674d02:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  674d09:	1f 84 00 00 00 00 00 
  674d10:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  674d17:	00 ff 
  674d19:	0f 85 84 00 00 00    	jne    674da3 <<gpui_canvas::text::planner::Planner>::shape+0xd03>
  674d1f:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
  674d26:	48 c7 84 24 50 01 00 	movq   $0x0,0x150(%rsp)
  674d2d:	00 00 00 00 00 
  674d32:	48 c7 84 24 58 01 00 	movq   $0x4,0x158(%rsp)
  674d39:	00 04 00 00 00 
  674d3e:	48 8d 8c 24 58 01 00 	lea    0x158(%rsp),%rcx
  674d45:	00 
  674d46:	0f 57 c0             	xorps  %xmm0,%xmm0
  674d49:	0f 11 41 08          	movups %xmm0,0x8(%rcx)
  674d4d:	48 c7 84 24 70 01 00 	movq   $0x4,0x170(%rsp)
  674d54:	00 04 00 00 00 
  674d59:	48 c7 84 24 78 01 00 	movq   $0x0,0x178(%rsp)
  674d60:	00 00 00 00 00 
  674d65:	48 89 84 24 80 01 00 	mov    %rax,0x180(%rsp)
  674d6c:	00 
  674d6d:	48 c7 84 24 88 01 00 	movq   $0x4,0x188(%rsp)
  674d74:	00 04 00 00 00 
  674d79:	48 c7 84 24 90 01 00 	movq   $0x0,0x190(%rsp)
  674d80:	00 00 00 00 00 
  674d85:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  674d8a:	89 84 24 98 01 00 00 	mov    %eax,0x198(%rsp)
  674d91:	f3 0f 10 84 24 84 00 	movss  0x84(%rsp),%xmm0
  674d98:	00 00 
  674d9a:	f3 0f 11 84 24 9c 01 	movss  %xmm0,0x19c(%rsp)
  674da1:	00 00 
  674da3:	48 8b 04 24          	mov    (%rsp),%rax
  674da7:	4c 8b b0 e0 09 00 00 	mov    0x9e0(%rax),%r14
  674dae:	4d 85 f6             	test   %r14,%r14
  674db1:	0f 84 09 01 00 00    	je     674ec0 <<gpui_canvas::text::planner::Planner>::shape+0xe20>
  674db7:	48 8b a8 d8 09 00 00 	mov    0x9d8(%rax),%rbp
  674dbe:	45 31 ff             	xor    %r15d,%r15d
  674dc1:	31 db                	xor    %ebx,%ebx
  674dc3:	eb 17                	jmp    674ddc <<gpui_canvas::text::planner::Planner>::shape+0xd3c>
  674dc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  674dcc:	00 00 00 00 
  674dd0:	49 ff c7             	inc    %r15
  674dd3:	4d 39 f7             	cmp    %r14,%r15
  674dd6:	0f 84 e6 00 00 00    	je     674ec2 <<gpui_canvas::text::planner::Planner>::shape+0xe22>
  674ddc:	49 6b c7 70          	imul   $0x70,%r15,%rax
  674de0:	48 01 e8             	add    %rbp,%rax
  674de3:	48 89 9c 24 10 07 00 	mov    %rbx,0x710(%rsp)
  674dea:	00 
  674deb:	48 c7 84 24 18 07 00 	movq   $0x0,0x718(%rsp)
  674df2:	00 00 00 00 00 
  674df7:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
  674dfc:	48 89 8c 24 20 07 00 	mov    %rcx,0x720(%rsp)
  674e03:	00 
  674e04:	48 89 84 24 28 07 00 	mov    %rax,0x728(%rsp)
  674e0b:	00 
  674e0c:	44 89 bc 24 30 07 00 	mov    %r15d,0x730(%rsp)
  674e13:	00 
  674e14:	c6 84 24 d8 07 00 00 	movb   $0x2,0x7d8(%rsp)
  674e1b:	02 
  674e1c:	c7 84 24 e0 07 00 00 	movl   $0x0,0x7e0(%rsp)
  674e23:	00 00 00 00 
  674e27:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
  674e2e:	00 
  674e2f:	48 8d b4 24 18 07 00 	lea    0x718(%rsp),%rsi
  674e36:	00 
  674e37:	e8 44 9e 00 00       	call   67ec80 <<parley::layout::line::GlyphRunIter<()> as core::iter::traits::iterator::Iterator>::next>
  674e3c:	83 bc 24 40 03 00 00 	cmpl   $0x1,0x340(%rsp)
  674e43:	01 
  674e44:	75 8a                	jne    674dd0 <<gpui_canvas::text::planner::Planner>::shape+0xd30>
  674e46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  674e4d:	00 00 00 
  674e50:	49 8b 45 38          	mov    0x38(%r13),%rax
  674e54:	49 89 44 24 40       	mov    %rax,0x40(%r12)
  674e59:	41 0f 10 45 f8       	movups -0x8(%r13),%xmm0
  674e5e:	41 0f 10 4d 08       	movups 0x8(%r13),%xmm1
  674e63:	41 0f 10 55 18       	movups 0x18(%r13),%xmm2
  674e68:	41 0f 10 5d 28       	movups 0x28(%r13),%xmm3
  674e6d:	41 0f 11 5c 24 30    	movups %xmm3,0x30(%r12)
  674e73:	41 0f 11 54 24 20    	movups %xmm2,0x20(%r12)
  674e79:	41 0f 11 4c 24 10    	movups %xmm1,0x10(%r12)
  674e7f:	41 0f 11 04 24       	movups %xmm0,(%r12)
  674e84:	48 89 9c 24 c0 04 00 	mov    %rbx,0x4c0(%rsp)
  674e8b:	00 
  674e8c:	48 89 de             	mov    %rbx,%rsi
  674e8f:	4c 89 e2             	mov    %r12,%rdx
  674e92:	e8 a9 99 00 00       	call   67e840 <<&mut core::iter::adapters::map::map_fold<parley::layout::line::PositionedLayoutItem<()>, usize, usize, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#5}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineData>>, <parley::layout::layout::Layout<()>>::lines::{closure#0}>, parley::layout::line::GlyphRunIter<()>, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#4}>, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#5}>>::{closure#0}>::{closure#0} as core::ops::function::FnMut<(usize, parley::layout::line::PositionedLayoutItem<()>)>>::call_mut>
  674e97:	48 89 c3             	mov    %rax,%rbx
  674e9a:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
  674ea1:	00 
  674ea2:	48 8d b4 24 18 07 00 	lea    0x718(%rsp),%rsi
  674ea9:	00 
  674eaa:	e8 d1 9d 00 00       	call   67ec80 <<parley::layout::line::GlyphRunIter<()> as core::iter::traits::iterator::Iterator>::next>
  674eaf:	80 bc 24 40 03 00 00 	cmpb   $0x0,0x340(%rsp)
  674eb6:	00 
  674eb7:	75 97                	jne    674e50 <<gpui_canvas::text::planner::Planner>::shape+0xdb0>
  674eb9:	e9 12 ff ff ff       	jmp    674dd0 <<gpui_canvas::text::planner::Planner>::shape+0xd30>
  674ebe:	66 90                	xchg   %ax,%ax
  674ec0:	31 db                	xor    %ebx,%ebx
  674ec2:	48 8b b4 24 f8 00 00 	mov    0xf8(%rsp),%rsi
  674ec9:	00 
  674eca:	48 89 f0             	mov    %rsi,%rax
  674ecd:	48 01 d8             	add    %rbx,%rax
  674ed0:	0f 92 c1             	setb   %cl
  674ed3:	48 3d 01 80 00 00    	cmp    $0x8001,%rax
  674ed9:	0f 93 c0             	setae  %al
  674edc:	08 c8                	or     %cl,%al
  674ede:	0f 85 9b 1d 00 00    	jne    676c7f <<gpui_canvas::text::planner::Planner>::shape+0x2bdf>
  674ee4:	48 8b 6c 24 30       	mov    0x30(%rsp),%rbp
  674ee9:	48 39 ac 24 00 01 00 	cmp    %rbp,0x100(%rsp)
  674ef0:	00 
  674ef1:	74 14                	je     674f07 <<gpui_canvas::text::planner::Planner>::shape+0xe67>
  674ef3:	48 8b 84 24 e8 00 00 	mov    0xe8(%rsp),%rax
  674efa:	00 
  674efb:	48 29 f0             	sub    %rsi,%rax
  674efe:	48 39 c3             	cmp    %rax,%rbx
  674f01:	0f 87 58 1d 00 00    	ja     676c5f <<gpui_canvas::text::planner::Planner>::shape+0x2bbf>
  674f07:	48 85 ed             	test   %rbp,%rbp
  674f0a:	48 8b 9c 24 00 01 00 	mov    0x100(%rsp),%rbx
  674f11:	00 
  674f12:	74 26                	je     674f3a <<gpui_canvas::text::planner::Planner>::shape+0xe9a>
  674f14:	0f 57 c0             	xorps  %xmm0,%xmm0
  674f17:	f3 0f 11 84 24 d4 00 	movss  %xmm0,0xd4(%rsp)
  674f1e:	00 00 
  674f20:	48 39 eb             	cmp    %rbp,%rbx
  674f23:	75 4b                	jne    674f70 <<gpui_canvas::text::planner::Planner>::shape+0xed0>
  674f25:	48 8b 0c 24          	mov    (%rsp),%rcx
  674f29:	48 8b 81 e0 09 00 00 	mov    0x9e0(%rcx),%rax
  674f30:	48 85 c0             	test   %rax,%rax
  674f33:	75 7c                	jne    674fb1 <<gpui_canvas::text::planner::Planner>::shape+0xf11>
  674f35:	e9 9b 14 00 00       	jmp    6763d5 <<gpui_canvas::text::planner::Planner>::shape+0x2335>
  674f3a:	48 8b 04 24          	mov    (%rsp),%rax
  674f3e:	48 83 b8 e0 09 00 00 	cmpq   $0x0,0x9e0(%rax)
  674f45:	00 
  674f46:	74 0e                	je     674f56 <<gpui_canvas::text::planner::Planner>::shape+0xeb6>
  674f48:	48 8b 80 d8 09 00 00 	mov    0x9d8(%rax),%rax
  674f4f:	f3 0f 10 40 24       	movss  0x24(%rax),%xmm0
  674f54:	eb 03                	jmp    674f59 <<gpui_canvas::text::planner::Planner>::shape+0xeb9>
  674f56:	0f 57 c0             	xorps  %xmm0,%xmm0
  674f59:	f3 0f 11 44 24 7c    	movss  %xmm0,0x7c(%rsp)
  674f5f:	0f 57 c0             	xorps  %xmm0,%xmm0
  674f62:	f3 0f 11 84 24 d4 00 	movss  %xmm0,0xd4(%rsp)
  674f69:	00 00 
  674f6b:	48 39 eb             	cmp    %rbp,%rbx
  674f6e:	74 b5                	je     674f25 <<gpui_canvas::text::planner::Planner>::shape+0xe85>
  674f70:	83 bc 24 c8 01 00 00 	cmpl   $0x0,0x1c8(%rsp)
  674f77:	00 
  674f78:	74 0e                	je     674f88 <<gpui_canvas::text::planner::Planner>::shape+0xee8>
  674f7a:	48 8b 04 24          	mov    (%rsp),%rax
  674f7e:	f3 0f 10 80 28 0a 00 	movss  0xa28(%rax),%xmm0
  674f85:	00 
  674f86:	eb 0c                	jmp    674f94 <<gpui_canvas::text::planner::Planner>::shape+0xef4>
  674f88:	48 8b 04 24          	mov    (%rsp),%rax
  674f8c:	f3 0f 10 80 2c 0a 00 	movss  0xa2c(%rax),%xmm0
  674f93:	00 
  674f94:	f3 0f 11 84 24 d4 00 	movss  %xmm0,0xd4(%rsp)
  674f9b:	00 00 
  674f9d:	48 8b 0c 24          	mov    (%rsp),%rcx
  674fa1:	48 8b 81 e0 09 00 00 	mov    0x9e0(%rcx),%rax
  674fa8:	48 85 c0             	test   %rax,%rax
  674fab:	0f 84 24 14 00 00    	je     6763d5 <<gpui_canvas::text::planner::Planner>::shape+0x2335>
  674fb1:	48 8b 89 d8 09 00 00 	mov    0x9d8(%rcx),%rcx
  674fb8:	48 6b c0 70          	imul   $0x70,%rax,%rax
  674fbc:	48 89 8c 24 c8 00 00 	mov    %rcx,0xc8(%rsp)
  674fc3:	00 
  674fc4:	48 01 c8             	add    %rcx,%rax
  674fc7:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
  674fce:	00 
  674fcf:	c7 44 24 78 00 00 00 	movl   $0x0,0x78(%rsp)
  674fd6:	00 
  674fd7:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  674fde:	00 ff 
  674fe0:	74 2e                	je     675010 <<gpui_canvas::text::planner::Planner>::shape+0xf70>
  674fe2:	48 39 eb             	cmp    %rbp,%rbx
  674fe5:	75 3c                	jne    675023 <<gpui_canvas::text::planner::Planner>::shape+0xf83>
  674fe7:	45 31 f6             	xor    %r14d,%r14d
  674fea:	45 31 ff             	xor    %r15d,%r15d
  674fed:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  674ff4:	00 
  674ff5:	48 8b 8c 24 78 01 00 	mov    0x178(%rsp),%rcx
  674ffc:	00 
  674ffd:	48 89 8c 24 58 02 00 	mov    %rcx,0x258(%rsp)
  675004:	00 
  675005:	80 78 68 02          	cmpb   $0x2,0x68(%rax)
  675009:	74 41                	je     67504c <<gpui_canvas::text::planner::Planner>::shape+0xfac>
  67500b:	e9 da 01 00 00       	jmp    6751ea <<gpui_canvas::text::planner::Planner>::shape+0x114a>
  675010:	8b 4c 24 78          	mov    0x78(%rsp),%ecx
  675014:	89 c8                	mov    %ecx,%eax
  675016:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
  67501d:	00 
  67501e:	e9 cd 03 00 00       	jmp    6753f0 <<gpui_canvas::text::planner::Planner>::shape+0x1350>
  675023:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  67502a:	00 
  67502b:	4c 8b 38             	mov    (%rax),%r15
  67502e:	4c 8b 70 08          	mov    0x8(%rax),%r14
  675032:	48 8b 8c 24 78 01 00 	mov    0x178(%rsp),%rcx
  675039:	00 
  67503a:	48 89 8c 24 58 02 00 	mov    %rcx,0x258(%rsp)
  675041:	00 
  675042:	80 78 68 02          	cmpb   $0x2,0x68(%rax)
  675046:	0f 85 9e 01 00 00    	jne    6751ea <<gpui_canvas::text::planner::Planner>::shape+0x114a>
  67504c:	48 8b 78 10          	mov    0x10(%rax),%rdi
  675050:	48 8b 70 18          	mov    0x18(%rax),%rsi
  675054:	48 8b 04 24          	mov    (%rsp),%rax
  675058:	48 8b 90 f8 09 00 00 	mov    0x9f8(%rax),%rdx
  67505f:	48 39 fe             	cmp    %rdi,%rsi
  675062:	0f 82 80 25 00 00    	jb     6775e8 <<gpui_canvas::text::planner::Planner>::shape+0x3548>
  675068:	48 39 d6             	cmp    %rdx,%rsi
  67506b:	0f 87 77 25 00 00    	ja     6775e8 <<gpui_canvas::text::planner::Planner>::shape+0x3548>
  675071:	48 8b 04 24          	mov    (%rsp),%rax
  675075:	48 8b 80 f0 09 00 00 	mov    0x9f0(%rax),%rax
  67507c:	48 8d 0c bf          	lea    (%rdi,%rdi,4),%rcx
  675080:	48 8d 0c c8          	lea    (%rax,%rcx,8),%rcx
  675084:	48 8d 14 b6          	lea    (%rsi,%rsi,4),%rdx
  675088:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
  67508c:	48 89 8c 24 c0 04 00 	mov    %rcx,0x4c0(%rsp)
  675093:	00 
  675094:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
  67509b:	00 
  67509c:	48 c7 84 24 d0 04 00 	movq   $0x0,0x4d0(%rsp)
  6750a3:	00 00 00 00 00 
  6750a8:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  6750ad:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
  6750b4:	00 
  6750b5:	8b 44 24 78          	mov    0x78(%rsp),%eax
  6750b9:	89 84 24 e0 04 00 00 	mov    %eax,0x4e0(%rsp)
  6750c0:	c6 84 24 00 07 00 00 	movb   $0x2,0x700(%rsp)
  6750c7:	02 
  6750c8:	48 8d 84 24 08 07 00 	lea    0x708(%rsp),%rax
  6750cf:	00 
  6750d0:	48 89 84 24 40 03 00 	mov    %rax,0x340(%rsp)
  6750d7:	00 
  6750d8:	c6 84 24 f0 05 00 00 	movb   $0x2,0x5f0(%rsp)
  6750df:	02 
  6750e0:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  6750e7:	00 
  6750e8:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
  6750ef:	00 
  6750f0:	48 8d 94 24 40 03 00 	lea    0x340(%rsp),%rdx
  6750f7:	00 
  6750f8:	48 8d 8c 24 e8 04 00 	lea    0x4e8(%rsp),%rcx
  6750ff:	00 
  675100:	e8 bb 8c 00 00       	call   67ddc0 <<core::iter::adapters::map::Map<core::iter::adapters::filter_map::FilterMap<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}>, <parley::layout::line::Line<()>>::runs::{closure#0}>, gpui_canvas::text::planner::freeze_line::{closure#0}> as core::iter::traits::iterator::Iterator>::try_fold::<(), <core::iter::adapters::flatten::FlattenCompat<_, _>>::iter_try_fold::flatten<parley::layout::run::Clusters<()>, (), core::ops::control_flow::ControlFlow<parley::layout::cluster::Cluster<()>>, <core::iter::adapters::flatten::FlattenCompat<_, _> as core::iter::traits::iterator::Iterator>::try_fold::flatten<parley::layout::run::Clusters<()>, (), core::ops::control_flow::ControlFlow<parley::layout::cluster::Cluster<()>>, core::iter::traits::iterator::Iterator::find::check<parley::layout::cluster::Cluster<()>, &mut gpui_canvas::text::planner::freeze_line::{closure#1}>::{closure#0}>::{closure#0}>::{closure#0}, core::ops::control_flow::ControlFlow<parley::layout::cluster::Cluster<()>>>>
  675105:	48 8b 8c 24 10 07 00 	mov    0x710(%rsp),%rcx
  67510c:	00 
  67510d:	48 85 c9             	test   %rcx,%rcx
  675110:	0f 84 ba 00 00 00    	je     6751d0 <<gpui_canvas::text::planner::Planner>::shape+0x1130>
  675116:	8b bc 24 38 07 00 00 	mov    0x738(%rsp),%edi
  67511d:	8b b4 24 90 07 00 00 	mov    0x790(%rsp),%esi
  675124:	8b 94 24 94 07 00 00 	mov    0x794(%rsp),%edx
  67512b:	48 8b 41 58          	mov    0x58(%rcx),%rax
  67512f:	48 39 f8             	cmp    %rdi,%rax
  675132:	0f 86 d3 25 00 00    	jbe    67770b <<gpui_canvas::text::planner::Planner>::shape+0x366b>
  675138:	48 8b 41 50          	mov    0x50(%rcx),%rax
  67513c:	48 8d 3c ff          	lea    (%rdi,%rdi,8),%rdi
  675140:	48 c1 e7 04          	shl    $0x4,%rdi
  675144:	0f 10 41 68          	movups 0x68(%rcx),%xmm0
  675148:	0f 10 89 80 00 00 00 	movups 0x80(%rcx),%xmm1
  67514f:	0f 10 91 98 00 00 00 	movups 0x98(%rcx),%xmm2
  675156:	0f 11 84 24 10 07 00 	movups %xmm0,0x710(%rsp)
  67515d:	00 
  67515e:	0f 11 8c 24 20 07 00 	movups %xmm1,0x720(%rsp)
  675165:	00 
  675166:	0f 11 94 24 30 07 00 	movups %xmm2,0x730(%rsp)
  67516d:	00 
  67516e:	48 8b 44 38 50       	mov    0x50(%rax,%rdi,1),%rax
  675173:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
  67517a:	00 
  67517b:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  675182:	00 
  675183:	ff 15 c7 51 11 00    	call   *0x1151c7(%rip)        # 78a350 <_DYNAMIC+0x6b0>
  675189:	48 89 c3             	mov    %rax,%rbx
  67518c:	ba 48 02 00 00       	mov    $0x248,%edx
  675191:	4c 89 7c 24 60       	mov    %r15,0x60(%rsp)
  675196:	4c 8d bc 24 10 07 00 	lea    0x710(%rsp),%r15
  67519d:	00 
  67519e:	4c 89 ff             	mov    %r15,%rdi
  6751a1:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
  6751a8:	00 
  6751a9:	ff 15 c1 4d 11 00    	call   *0x114dc1(%rip)        # 789f70 <memcpy@GLIBC_2.14>
  6751af:	4c 89 ff             	mov    %r15,%rdi
  6751b2:	4c 8b 7c 24 60       	mov    0x60(%rsp),%r15
  6751b7:	48 89 de             	mov    %rbx,%rsi
  6751ba:	e8 31 8e 00 00       	call   67dff0 <<core::iter::adapters::map::Map<core::iter::adapters::filter::Filter<core::iter::adapters::flatten::FlatMap<core::iter::adapters::filter_map::FilterMap<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}>, <parley::layout::line::Line<()>>::runs::{closure#0}>, parley::layout::run::Clusters<()>, gpui_canvas::text::planner::freeze_line::{closure#0}>, gpui_canvas::text::planner::freeze_line::{closure#1}>, gpui_canvas::text::planner::freeze_line::{closure#2}> as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::traits::iterator::Iterator::min_by::fold<usize, <usize as core::cmp::Ord>::cmp>::{closure#0}>>
  6751bf:	4c 39 f0             	cmp    %r14,%rax
  6751c2:	4c 0f 42 f0          	cmovb  %rax,%r14
  6751c6:	48 8b 9c 24 00 01 00 	mov    0x100(%rsp),%rbx
  6751cd:	00 
  6751ce:	eb 1a                	jmp    6751ea <<gpui_canvas::text::planner::Planner>::shape+0x114a>
  6751d0:	80 bc 24 00 07 00 00 	cmpb   $0x2,0x700(%rsp)
  6751d7:	02 
  6751d8:	c6 84 24 f0 05 00 00 	movb   $0x2,0x5f0(%rsp)
  6751df:	02 
  6751e0:	48 8b 9c 24 00 01 00 	mov    0x100(%rsp),%rbx
  6751e7:	00 
  6751e8:	75 36                	jne    675220 <<gpui_canvas::text::planner::Planner>::shape+0x1180>
  6751ea:	4d 39 f7             	cmp    %r14,%r15
  6751ed:	0f 87 67 1e 00 00    	ja     67705a <<gpui_canvas::text::planner::Planner>::shape+0x2fba>
  6751f3:	4d 85 ff             	test   %r15,%r15
  6751f6:	0f 84 a0 00 00 00    	je     67529c <<gpui_canvas::text::planner::Planner>::shape+0x11fc>
  6751fc:	4c 3b bc 24 10 01 00 	cmp    0x110(%rsp),%r15
  675203:	00 
  675204:	0f 83 8c 00 00 00    	jae    675296 <<gpui_canvas::text::planner::Planner>::shape+0x11f6>
  67520a:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  67520f:	42 80 3c 38 bf       	cmpb   $0xbf,(%rax,%r15,1)
  675214:	0f 8f 82 00 00 00    	jg     67529c <<gpui_canvas::text::planner::Planner>::shape+0x11fc>
  67521a:	e9 3b 1e 00 00       	jmp    67705a <<gpui_canvas::text::planner::Planner>::shape+0x2fba>
  67521f:	90                   	nop
  675220:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  675227:	00 
  675228:	48 8d b4 24 f8 05 00 	lea    0x5f8(%rsp),%rsi
  67522f:	00 
  675230:	e8 3b 83 00 00       	call   67d570 <<parley::layout::run::Clusters<()> as core::iter::traits::iterator::Iterator>::next>
  675235:	48 8b 8c 24 10 07 00 	mov    0x710(%rsp),%rcx
  67523c:	00 
  67523d:	48 85 c9             	test   %rcx,%rcx
  675240:	74 a8                	je     6751ea <<gpui_canvas::text::planner::Planner>::shape+0x114a>
  675242:	8b bc 24 38 07 00 00 	mov    0x738(%rsp),%edi
  675249:	48 8b 41 58          	mov    0x58(%rcx),%rax
  67524d:	48 39 f8             	cmp    %rdi,%rax
  675250:	0f 86 32 24 00 00    	jbe    677688 <<gpui_canvas::text::planner::Planner>::shape+0x35e8>
  675256:	8b b4 24 90 07 00 00 	mov    0x790(%rsp),%esi
  67525d:	8b 94 24 94 07 00 00 	mov    0x794(%rsp),%edx
  675264:	4c 8b 41 70          	mov    0x70(%rcx),%r8
  675268:	39 f2                	cmp    %esi,%edx
  67526a:	0f 82 fb 22 00 00    	jb     67756b <<gpui_canvas::text::planner::Planner>::shape+0x34cb>
  675270:	49 39 d0             	cmp    %rdx,%r8
  675273:	0f 82 f2 22 00 00    	jb     67756b <<gpui_canvas::text::planner::Planner>::shape+0x34cb>
  675279:	39 f2                	cmp    %esi,%edx
  67527b:	0f 84 18 24 00 00    	je     677699 <<gpui_canvas::text::planner::Planner>::shape+0x35f9>
  675281:	4c 8b 41 68          	mov    0x68(%rcx),%r8
  675285:	4c 8d 0c 76          	lea    (%rsi,%rsi,2),%r9
  675289:	43 80 7c 88 07 06    	cmpb   $0x6,0x7(%r8,%r9,4)
  67528f:	75 8f                	jne    675220 <<gpui_canvas::text::planner::Planner>::shape+0x1180>
  675291:	e9 99 fe ff ff       	jmp    67512f <<gpui_canvas::text::planner::Planner>::shape+0x108f>
  675296:	0f 85 be 1d 00 00    	jne    67705a <<gpui_canvas::text::planner::Planner>::shape+0x2fba>
  67529c:	4d 85 f6             	test   %r14,%r14
  67529f:	74 21                	je     6752c2 <<gpui_canvas::text::planner::Planner>::shape+0x1222>
  6752a1:	4c 3b b4 24 10 01 00 	cmp    0x110(%rsp),%r14
  6752a8:	00 
  6752a9:	73 11                	jae    6752bc <<gpui_canvas::text::planner::Planner>::shape+0x121c>
  6752ab:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6752b0:	42 80 3c 30 c0       	cmpb   $0xc0,(%rax,%r14,1)
  6752b5:	7d 0b                	jge    6752c2 <<gpui_canvas::text::planner::Planner>::shape+0x1222>
  6752b7:	e9 9e 1d 00 00       	jmp    67705a <<gpui_canvas::text::planner::Planner>::shape+0x2fba>
  6752bc:	0f 85 98 1d 00 00    	jne    67705a <<gpui_canvas::text::planner::Planner>::shape+0x2fba>
  6752c2:	0f 57 c0             	xorps  %xmm0,%xmm0
  6752c5:	48 39 eb             	cmp    %rbp,%rbx
  6752c8:	74 0d                	je     6752d7 <<gpui_canvas::text::planner::Planner>::shape+0x1237>
  6752ca:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  6752d1:	00 
  6752d2:	f3 0f 10 40 30       	movss  0x30(%rax),%xmm0
  6752d7:	f3 0f 11 44 24 60    	movss  %xmm0,0x60(%rsp)
  6752dd:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  6752e4:	00 
  6752e5:	f3 0f 10 48 40       	movss  0x40(%rax),%xmm1
  6752ea:	f3 0f 10 40 44       	movss  0x44(%rax),%xmm0
  6752ef:	0f 29 8c 24 90 02 00 	movaps %xmm1,0x290(%rsp)
  6752f6:	00 
  6752f7:	f3 0f 5d 48 48       	minss  0x48(%rax),%xmm1
  6752fc:	0f 29 8c 24 a0 01 00 	movaps %xmm1,0x1a0(%rsp)
  675303:	00 
  675304:	0f 29 84 24 d0 01 00 	movaps %xmm0,0x1d0(%rsp)
  67530b:	00 
  67530c:	f3 0f 5f 40 4c       	maxss  0x4c(%rax),%xmm0
  675311:	0f 29 84 24 20 01 00 	movaps %xmm0,0x120(%rsp)
  675318:	00 
  675319:	f3 0f 10 40 24       	movss  0x24(%rax),%xmm0
  67531e:	f3 0f 58 44 24 1c    	addss  0x1c(%rsp),%xmm0
  675324:	f3 0f 11 44 24 08    	movss  %xmm0,0x8(%rsp)
  67532a:	48 8b 9c 24 78 01 00 	mov    0x178(%rsp),%rbx
  675331:	00 
  675332:	48 3b 9c 24 68 01 00 	cmp    0x168(%rsp),%rbx
  675339:	00 
  67533a:	75 0e                	jne    67534a <<gpui_canvas::text::planner::Planner>::shape+0x12aa>
  67533c:	48 8d bc 24 68 01 00 	lea    0x168(%rsp),%rdi
  675343:	00 
  675344:	ff 15 66 4e 11 00    	call   *0x114e66(%rip)        # 78a1b0 <_DYNAMIC+0x510>
  67534a:	41 01 ef             	add    %ebp,%r15d
  67534d:	41 01 ee             	add    %ebp,%r14d
  675350:	0f 28 94 24 a0 01 00 	movaps 0x1a0(%rsp),%xmm2
  675357:	00 
  675358:	0f 28 c2             	movaps %xmm2,%xmm0
  67535b:	f3 0f c2 c2 03       	cmpunordss %xmm2,%xmm0
  675360:	0f 28 c8             	movaps %xmm0,%xmm1
  675363:	0f 55 ca             	andnps %xmm2,%xmm1
  675366:	0f 54 84 24 90 02 00 	andps  0x290(%rsp),%xmm0
  67536d:	00 
  67536e:	0f 56 c1             	orps   %xmm1,%xmm0
  675371:	f3 0f 10 4c 24 1c    	movss  0x1c(%rsp),%xmm1
  675377:	f3 0f 58 c8          	addss  %xmm0,%xmm1
  67537b:	0f 28 a4 24 20 01 00 	movaps 0x120(%rsp),%xmm4
  675382:	00 
  675383:	0f 28 d4             	movaps %xmm4,%xmm2
  675386:	f3 0f c2 d4 03       	cmpunordss %xmm4,%xmm2
  67538b:	0f 28 da             	movaps %xmm2,%xmm3
  67538e:	0f 55 dc             	andnps %xmm4,%xmm3
  675391:	0f 54 94 24 d0 01 00 	andps  0x1d0(%rsp),%xmm2
  675398:	00 
  675399:	0f 56 d3             	orps   %xmm3,%xmm2
  67539c:	f3 0f 5c d0          	subss  %xmm0,%xmm2
  6753a0:	48 8b 84 24 70 01 00 	mov    0x170(%rsp),%rax
  6753a7:	00 
  6753a8:	48 8d 0c 5b          	lea    (%rbx,%rbx,2),%rcx
  6753ac:	44 89 3c c8          	mov    %r15d,(%rax,%rcx,8)
  6753b0:	44 89 74 c8 04       	mov    %r14d,0x4(%rax,%rcx,8)
  6753b5:	f3 0f 11 4c c8 08    	movss  %xmm1,0x8(%rax,%rcx,8)
  6753bb:	f3 0f 11 54 c8 0c    	movss  %xmm2,0xc(%rax,%rcx,8)
  6753c1:	f3 0f 10 44 24 08    	movss  0x8(%rsp),%xmm0
  6753c7:	f3 0f 11 44 c8 10    	movss  %xmm0,0x10(%rax,%rcx,8)
  6753cd:	f3 0f 10 44 24 60    	movss  0x60(%rsp),%xmm0
  6753d3:	f3 0f 11 44 c8 14    	movss  %xmm0,0x14(%rax,%rcx,8)
  6753d9:	48 ff c3             	inc    %rbx
  6753dc:	48 89 9c 24 78 01 00 	mov    %rbx,0x178(%rsp)
  6753e3:	00 
  6753e4:	44 89 b4 24 18 02 00 	mov    %r14d,0x218(%rsp)
  6753eb:	00 
  6753ec:	8b 4c 24 78          	mov    0x78(%rsp),%ecx
  6753f0:	48 c7 84 24 10 07 00 	movq   $0x0,0x710(%rsp)
  6753f7:	00 00 00 00 00 
  6753fc:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  675401:	48 89 84 24 18 07 00 	mov    %rax,0x718(%rsp)
  675408:	00 
  675409:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  675410:	00 
  675411:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
  675418:	00 
  675419:	48 83 c0 70          	add    $0x70,%rax
  67541d:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
  675424:	00 
  675425:	89 8c 24 28 07 00 00 	mov    %ecx,0x728(%rsp)
  67542c:	ff c1                	inc    %ecx
  67542e:	89 4c 24 78          	mov    %ecx,0x78(%rsp)
  675432:	c6 84 24 d0 07 00 00 	movb   $0x2,0x7d0(%rsp)
  675439:	02 
  67543a:	c7 84 24 d8 07 00 00 	movl   $0x0,0x7d8(%rsp)
  675441:	00 00 00 00 
  675445:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
  67544c:	00 
  67544d:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
  675454:	00 
  675455:	e8 26 98 00 00       	call   67ec80 <<parley::layout::line::GlyphRunIter<()> as core::iter::traits::iterator::Iterator>::next>
  67545a:	83 bc 24 40 03 00 00 	cmpl   $0x1,0x340(%rsp)
  675461:	01 
  675462:	0f 85 4a 0f 00 00    	jne    6763b2 <<gpui_canvas::text::planner::Planner>::shape+0x2312>
  675468:	48 8b 84 24 48 03 00 	mov    0x348(%rsp),%rax
  67546f:	00 
  675470:	48 85 c0             	test   %rax,%rax
  675473:	0f 84 d1 1b 00 00    	je     67704a <<gpui_canvas::text::planner::Planner>::shape+0x2faa>
  675479:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
  675480:	00 
  675481:	41 0f 10 45 00       	movups 0x0(%r13),%xmm0
  675486:	41 0f 10 4d 10       	movups 0x10(%r13),%xmm1
  67548b:	41 0f 10 55 20       	movups 0x20(%r13),%xmm2
  675490:	41 0f 10 5d 30       	movups 0x30(%r13),%xmm3
  675495:	48 8d 8c 24 a0 03 00 	lea    0x3a0(%rsp),%rcx
  67549c:	00 
  67549d:	0f 11 59 30          	movups %xmm3,0x30(%rcx)
  6754a1:	0f 11 51 20          	movups %xmm2,0x20(%rcx)
  6754a5:	0f 11 49 10          	movups %xmm1,0x10(%rcx)
  6754a9:	0f 11 01             	movups %xmm0,(%rcx)
  6754ac:	4c 8b 9c 24 a0 03 00 	mov    0x3a0(%rsp),%r11
  6754b3:	00 
  6754b4:	49 8b 4b 30          	mov    0x30(%r11),%rcx
  6754b8:	49 8b 73 38          	mov    0x38(%r11),%rsi
  6754bc:	48 89 f2             	mov    %rsi,%rdx
  6754bf:	48 29 ca             	sub    %rcx,%rdx
  6754c2:	40 0f 92 c7          	setb   %dil
  6754c6:	48 3b b0 d0 00 00 00 	cmp    0xd0(%rax),%rsi
  6754cd:	40 0f 97 c6          	seta   %sil
  6754d1:	48 01 c9             	add    %rcx,%rcx
  6754d4:	48 03 88 c8 00 00 00 	add    0xc8(%rax),%rcx
  6754db:	40 08 fe             	or     %dil,%sil
  6754de:	40 84 f6             	test   %sil,%sil
  6754e1:	be 00 00 00 00       	mov    $0x0,%esi
  6754e6:	48 0f 45 d6          	cmovne %rsi,%rdx
  6754ea:	be 02 00 00 00       	mov    $0x2,%esi
  6754ef:	48 0f 45 ce          	cmovne %rsi,%rcx
  6754f3:	48 01 d2             	add    %rdx,%rdx
  6754f6:	31 f6                	xor    %esi,%esi
  6754f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  6754ff:	00 
  675500:	48 39 f2             	cmp    %rsi,%rdx
  675503:	74 10                	je     675515 <<gpui_canvas::text::planner::Planner>::shape+0x1475>
  675505:	66 83 3c 31 00       	cmpw   $0x0,(%rcx,%rsi,1)
  67550a:	48 8d 76 02          	lea    0x2(%rsi),%rsi
  67550e:	74 f0                	je     675500 <<gpui_canvas::text::planner::Planner>::shape+0x1460>
  675510:	e9 77 17 00 00       	jmp    676c8c <<gpui_canvas::text::planner::Planner>::shape+0x2bec>
  675515:	49 8b 4b 40          	mov    0x40(%r11),%rcx
  675519:	48 3b 88 b8 00 00 00 	cmp    0xb8(%rax),%rcx
  675520:	0f 83 d4 20 00 00    	jae    6775fa <<gpui_canvas::text::planner::Planner>::shape+0x355a>
  675526:	48 c1 e1 06          	shl    $0x6,%rcx
  67552a:	48 03 88 b0 00 00 00 	add    0xb0(%rax),%rcx
  675531:	48 8b 34 24          	mov    (%rsp),%rsi
  675535:	83 3e 01             	cmpl   $0x1,(%rsi)
  675538:	75 0f                	jne    675549 <<gpui_canvas::text::planner::Planner>::shape+0x14a9>
  67553a:	48 8b 56 08          	mov    0x8(%rsi),%rdx
  67553e:	48 3b 51 10          	cmp    0x10(%rcx),%rdx
  675542:	75 05                	jne    675549 <<gpui_canvas::text::planner::Planner>::shape+0x14a9>
  675544:	45 31 c0             	xor    %r8d,%r8d
  675547:	eb 4c                	jmp    675595 <<gpui_canvas::text::planner::Planner>::shape+0x14f5>
  675549:	83 7e 10 01          	cmpl   $0x1,0x10(%rsi)
  67554d:	75 10                	jne    67555f <<gpui_canvas::text::planner::Planner>::shape+0x14bf>
  67554f:	48 8b 56 18          	mov    0x18(%rsi),%rdx
  675553:	41 b8 01 00 00 00    	mov    $0x1,%r8d
  675559:	48 3b 51 10          	cmp    0x10(%rcx),%rdx
  67555d:	74 1e                	je     67557d <<gpui_canvas::text::planner::Planner>::shape+0x14dd>
  67555f:	83 7e 20 01          	cmpl   $0x1,0x20(%rsi)
  675563:	0f 85 0f 1b 00 00    	jne    677078 <<gpui_canvas::text::planner::Planner>::shape+0x2fd8>
  675569:	48 8b 56 28          	mov    0x28(%rsi),%rdx
  67556d:	41 b8 02 00 00 00    	mov    $0x2,%r8d
  675573:	48 3b 51 10          	cmp    0x10(%rcx),%rdx
  675577:	0f 85 fb 1a 00 00    	jne    677078 <<gpui_canvas::text::planner::Planner>::shape+0x2fd8>
  67557d:	41 8d 48 ff          	lea    -0x1(%r8),%ecx
  675581:	48 8b 94 24 08 02 00 	mov    0x208(%rsp),%rdx
  675588:	00 
  675589:	48 0f ab ca          	bts    %rcx,%rdx
  67558d:	48 89 94 24 08 02 00 	mov    %rdx,0x208(%rsp)
  675594:	00 
  675595:	8b bc 24 c0 03 00 00 	mov    0x3c0(%rsp),%edi
  67559c:	48 8b 70 58          	mov    0x58(%rax),%rsi
  6755a0:	48 39 fe             	cmp    %rdi,%rsi
  6755a3:	0f 86 17 21 00 00    	jbe    6776c0 <<gpui_canvas::text::planner::Planner>::shape+0x3620>
  6755a9:	48 8b 94 24 b0 03 00 	mov    0x3b0(%rsp),%rdx
  6755b0:	00 
  6755b1:	48 85 d2             	test   %rdx,%rdx
  6755b4:	4c 89 84 24 60 02 00 	mov    %r8,0x260(%rsp)
  6755bb:	00 
  6755bc:	48 89 94 24 e8 02 00 	mov    %rdx,0x2e8(%rsp)
  6755c3:	00 
  6755c4:	74 0a                	je     6755d0 <<gpui_canvas::text::planner::Planner>::shape+0x1530>
  6755c6:	48 8d 4a 18          	lea    0x18(%rdx),%rcx
  6755ca:	48 83 c2 1c          	add    $0x1c,%rdx
  6755ce:	eb 1b                	jmp    6755eb <<gpui_canvas::text::planner::Planner>::shape+0x154b>
  6755d0:	48 8b 48 50          	mov    0x50(%rax),%rcx
  6755d4:	48 8d 34 ff          	lea    (%rdi,%rdi,8),%rsi
  6755d8:	48 c1 e6 04          	shl    $0x4,%rsi
  6755dc:	48 8d 14 31          	lea    (%rcx,%rsi,1),%rdx
  6755e0:	48 83 c2 54          	add    $0x54,%rdx
  6755e4:	48 01 f1             	add    %rsi,%rcx
  6755e7:	48 83 c1 50          	add    $0x50,%rcx
  6755eb:	48 8b b4 24 f8 00 00 	mov    0xf8(%rsp),%rsi
  6755f2:	00 
  6755f3:	48 89 b4 24 f0 02 00 	mov    %rsi,0x2f0(%rsp)
  6755fa:	00 
  6755fb:	48 8b 70 68          	mov    0x68(%rax),%rsi
  6755ff:	48 8b 78 70          	mov    0x70(%rax),%rdi
  675603:	4c 8b 80 80 00 00 00 	mov    0x80(%rax),%r8
  67560a:	4c 8b 88 88 00 00 00 	mov    0x88(%rax),%r9
  675611:	4c 8b 90 98 00 00 00 	mov    0x98(%rax),%r10
  675618:	48 8b 80 a0 00 00 00 	mov    0xa0(%rax),%rax
  67561f:	8b 12                	mov    (%rdx),%edx
  675621:	8b 09                	mov    (%rcx),%ecx
  675623:	4c 89 9c 24 48 02 00 	mov    %r11,0x248(%rsp)
  67562a:	00 
  67562b:	45 0f b6 9b 8c 00 00 	movzbl 0x8c(%r11),%r11d
  675632:	00 
  675633:	41 80 e3 01          	and    $0x1,%r11b
  675637:	89 d3                	mov    %edx,%ebx
  675639:	29 cb                	sub    %ecx,%ebx
  67563b:	48 c7 84 24 c0 04 00 	movq   $0x0,0x4c0(%rsp)
  675642:	00 00 00 00 00 
  675647:	48 c7 84 24 e0 04 00 	movq   $0x0,0x4e0(%rsp)
  67564e:	00 00 00 00 00 
  675653:	c7 84 24 00 05 00 00 	movl   $0x0,0x500(%rsp)
  67565a:	00 00 00 00 
  67565e:	89 9c 24 04 05 00 00 	mov    %ebx,0x504(%rsp)
  675665:	48 89 b4 24 08 05 00 	mov    %rsi,0x508(%rsp)
  67566c:	00 
  67566d:	48 89 bc 24 10 05 00 	mov    %rdi,0x510(%rsp)
  675674:	00 
  675675:	4c 89 84 24 18 05 00 	mov    %r8,0x518(%rsp)
  67567c:	00 
  67567d:	4c 89 8c 24 20 05 00 	mov    %r9,0x520(%rsp)
  675684:	00 
  675685:	4c 89 94 24 28 05 00 	mov    %r10,0x528(%rsp)
  67568c:	00 
  67568d:	48 89 84 24 30 05 00 	mov    %rax,0x530(%rsp)
  675694:	00 
  675695:	89 8c 24 38 05 00 00 	mov    %ecx,0x538(%rsp)
  67569c:	89 94 24 3c 05 00 00 	mov    %edx,0x53c(%rsp)
  6756a3:	89 8c 24 40 05 00 00 	mov    %ecx,0x540(%rsp)
  6756aa:	89 94 24 44 05 00 00 	mov    %edx,0x544(%rsp)
  6756b1:	44 88 9c 24 48 05 00 	mov    %r11b,0x548(%rsp)
  6756b8:	00 
  6756b9:	f2 0f 10 84 24 d0 03 	movsd  0x3d0(%rsp),%xmm0
  6756c0:	00 00 
  6756c2:	0f 29 84 24 e0 03 00 	movaps %xmm0,0x3e0(%rsp)
  6756c9:	00 
  6756ca:	8b 94 24 c8 03 00 00 	mov    0x3c8(%rsp),%edx
  6756d1:	8b 8c 24 cc 03 00 00 	mov    0x3cc(%rsp),%ecx
  6756d8:	48 8d bc 24 f8 03 00 	lea    0x3f8(%rsp),%rdi
  6756df:	00 
  6756e0:	48 8d b4 24 98 03 00 	lea    0x398(%rsp),%rsi
  6756e7:	00 
  6756e8:	e8 b3 54 00 00       	call   67aba0 <<parley::layout::run::Run<()>>::glyphs_in>
  6756ed:	0f 28 94 24 e0 03 00 	movaps 0x3e0(%rsp),%xmm2
  6756f4:	00 
  6756f5:	0f 13 94 24 90 04 00 	movlps %xmm2,0x490(%rsp)
  6756fc:	00 
  6756fd:	48 8b 9c 24 f8 03 00 	mov    0x3f8(%rsp),%rbx
  675704:	00 
  675705:	48 8b 84 24 00 04 00 	mov    0x400(%rsp),%rax
  67570c:	00 
  67570d:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  675714:	00 
  675715:	0f b6 84 24 08 04 00 	movzbl 0x408(%rsp),%eax
  67571c:	00 
  67571d:	8b 8c 24 0c 04 00 00 	mov    0x40c(%rsp),%ecx
  675724:	89 8c 24 bc 01 00 00 	mov    %ecx,0x1bc(%rsp)
  67572b:	f2 0f 10 84 24 10 04 	movsd  0x410(%rsp),%xmm0
  675732:	00 00 
  675734:	0f 29 84 24 30 02 00 	movaps %xmm0,0x230(%rsp)
  67573b:	00 
  67573c:	f3 0f 10 84 24 18 04 	movss  0x418(%rsp),%xmm0
  675743:	00 00 
  675745:	f3 0f 11 84 24 b8 01 	movss  %xmm0,0x1b8(%rsp)
  67574c:	00 00 
  67574e:	48 8b 8c 24 20 04 00 	mov    0x420(%rsp),%rcx
  675755:	00 
  675756:	48 89 8c 24 68 02 00 	mov    %rcx,0x268(%rsp)
  67575d:	00 
  67575e:	48 8b 8c 24 28 04 00 	mov    0x428(%rsp),%rcx
  675765:	00 
  675766:	48 89 8c 24 00 02 00 	mov    %rcx,0x200(%rsp)
  67576d:	00 
  67576e:	48 8b 94 24 30 04 00 	mov    0x430(%rsp),%rdx
  675775:	00 
  675776:	4c 8b b4 24 38 04 00 	mov    0x438(%rsp),%r14
  67577d:	00 
  67577e:	48 8b 8c 24 40 04 00 	mov    0x440(%rsp),%rcx
  675785:	00 
  675786:	48 89 8c 24 78 02 00 	mov    %rcx,0x278(%rsp)
  67578d:	00 
  67578e:	48 8b 8c 24 48 04 00 	mov    0x448(%rsp),%rcx
  675795:	00 
  675796:	48 89 8c 24 40 01 00 	mov    %rcx,0x140(%rsp)
  67579d:	00 
  67579e:	8b 8c 24 50 04 00 00 	mov    0x450(%rsp),%ecx
  6757a5:	48 89 8c 24 f0 01 00 	mov    %rcx,0x1f0(%rsp)
  6757ac:	00 
  6757ad:	8b 8c 24 54 04 00 00 	mov    0x454(%rsp),%ecx
  6757b4:	48 89 8c 24 f8 01 00 	mov    %rcx,0x1f8(%rsp)
  6757bb:	00 
  6757bc:	8b 8c 24 58 04 00 00 	mov    0x458(%rsp),%ecx
  6757c3:	48 89 8c 24 20 01 00 	mov    %rcx,0x120(%rsp)
  6757ca:	00 
  6757cb:	44 8b bc 24 5c 04 00 	mov    0x45c(%rsp),%r15d
  6757d2:	00 
  6757d3:	f3 0f 10 84 24 60 04 	movss  0x460(%rsp),%xmm0
  6757da:	00 00 
  6757dc:	f3 0f 11 84 24 c0 01 	movss  %xmm0,0x1c0(%rsp)
  6757e3:	00 00 
  6757e5:	f3 0f 10 84 24 64 04 	movss  0x464(%rsp),%xmm0
  6757ec:	00 00 
  6757ee:	f3 0f 11 44 24 58    	movss  %xmm0,0x58(%rsp)
  6757f4:	48 8b 8c 24 68 04 00 	mov    0x468(%rsp),%rcx
  6757fb:	00 
  6757fc:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
  675801:	f3 0f 10 84 24 80 04 	movss  0x480(%rsp),%xmm0
  675808:	00 00 
  67580a:	f3 0f 10 8c 24 7c 04 	movss  0x47c(%rsp),%xmm1
  675811:	00 00 
  675813:	f3 0f 11 84 24 28 02 	movss  %xmm0,0x228(%rsp)
  67581a:	00 00 
  67581c:	f3 0f 58 c8          	addss  %xmm0,%xmm1
  675820:	f3 0f 10 84 24 84 04 	movss  0x484(%rsp),%xmm0
  675827:	00 00 
  675829:	f3 0f 11 8c 24 24 02 	movss  %xmm1,0x224(%rsp)
  675830:	00 00 
  675832:	f3 0f 58 c1          	addss  %xmm1,%xmm0
  675836:	f3 0f 11 84 24 1c 02 	movss  %xmm0,0x21c(%rsp)
  67583d:	00 00 
  67583f:	0f 28 c2             	movaps %xmm2,%xmm0
  675842:	0f b6 8c 24 8c 04 00 	movzbl 0x48c(%rsp),%ecx
  675849:	00 
  67584a:	88 8c 24 90 02 00 00 	mov    %cl,0x290(%rsp)
  675851:	48 8b 8c 24 70 04 00 	mov    0x470(%rsp),%rcx
  675858:	00 
  675859:	48 89 8c 24 38 01 00 	mov    %rcx,0x138(%rsp)
  675860:	00 
  675861:	8b 8c 24 78 04 00 00 	mov    0x478(%rsp),%ecx
  675868:	89 8c 24 dc 00 00 00 	mov    %ecx,0xdc(%rsp)
  67586f:	8b 8c 24 88 04 00 00 	mov    0x488(%rsp),%ecx
  675876:	89 8c 24 20 02 00 00 	mov    %ecx,0x220(%rsp)
  67587d:	48 8d 4a 16          	lea    0x16(%rdx),%rcx
  675881:	48 89 8c 24 50 02 00 	mov    %rcx,0x250(%rsp)
  675888:	00 
  675889:	48 89 94 24 d0 01 00 	mov    %rdx,0x1d0(%rsp)
  675890:	00 
  675891:	48 8d 4a 2e          	lea    0x2e(%rdx),%rcx
  675895:	48 89 8c 24 00 03 00 	mov    %rcx,0x300(%rsp)
  67589c:	00 
  67589d:	4c 89 b4 24 e8 01 00 	mov    %r14,0x1e8(%rsp)
  6758a4:	00 
  6758a5:	eb 6e                	jmp    675915 <<gpui_canvas::text::planner::Planner>::shape+0x1875>
  6758a7:	03 6c 24 30          	add    0x30(%rsp),%ebp
  6758ab:	0f 28 8c 24 a0 01 00 	movaps 0x1a0(%rsp),%xmm1
  6758b2:	00 
  6758b3:	f3 0f 58 4c 24 1c    	addss  0x1c(%rsp),%xmm1
  6758b9:	48 8b 84 24 f0 00 00 	mov    0xf0(%rsp),%rax
  6758c0:	00 
  6758c1:	4c 89 f1             	mov    %r14,%rcx
  6758c4:	48 c1 e1 04          	shl    $0x4,%rcx
  6758c8:	89 2c 08             	mov    %ebp,(%rax,%rcx,1)
  6758cb:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  6758d1:	f3 0f 11 44 08 04    	movss  %xmm0,0x4(%rax,%rcx,1)
  6758d7:	f3 0f 11 4c 08 08    	movss  %xmm1,0x8(%rax,%rcx,1)
  6758dd:	8b 54 24 5c          	mov    0x5c(%rsp),%edx
  6758e1:	66 89 54 08 0c       	mov    %dx,0xc(%rax,%rcx,1)
  6758e6:	48 8b 94 24 60 02 00 	mov    0x260(%rsp),%rdx
  6758ed:	00 
  6758ee:	88 54 08 0e          	mov    %dl,0xe(%rax,%rcx,1)
  6758f2:	c6 44 08 0f 00       	movb   $0x0,0xf(%rax,%rcx,1)
  6758f7:	49 ff c6             	inc    %r14
  6758fa:	4c 89 b4 24 f8 00 00 	mov    %r14,0xf8(%rsp)
  675901:	00 
  675902:	31 c0                	xor    %eax,%eax
  675904:	4c 8b b4 24 e8 01 00 	mov    0x1e8(%rsp),%r14
  67590b:	00 
  67590c:	f3 0f 10 84 24 c4 01 	movss  0x1c4(%rsp),%xmm0
  675913:	00 00 
  675915:	f3 0f 11 44 24 0c    	movss  %xmm0,0xc(%rsp)
  67591b:	a8 01                	test   $0x1,%al
  67591d:	74 61                	je     675980 <<gpui_canvas::text::planner::Planner>::shape+0x18e0>
  67591f:	f3 0f 10 84 24 b8 01 	movss  0x1b8(%rsp),%xmm0
  675926:	00 00 
  675928:	f3 0f 11 44 24 08    	movss  %xmm0,0x8(%rsp)
  67592e:	8b 84 24 bc 01 00 00 	mov    0x1bc(%rsp),%eax
  675935:	89 44 24 5c          	mov    %eax,0x5c(%rsp)
  675939:	0f 28 84 24 30 02 00 	movaps 0x230(%rsp),%xmm0
  675940:	00 
  675941:	0f 29 84 24 a0 01 00 	movaps %xmm0,0x1a0(%rsp)
  675948:	00 
  675949:	83 bc 24 dc 00 00 00 	cmpl   $0x0,0xdc(%rsp)
  675950:	00 
  675951:	74 71                	je     6759c4 <<gpui_canvas::text::planner::Planner>::shape+0x1924>
  675953:	48 83 7c 24 60 00    	cmpq   $0x0,0x60(%rsp)
  675959:	74 7c                	je     6759d7 <<gpui_canvas::text::planner::Planner>::shape+0x1937>
  67595b:	0f 28 84 24 a0 01 00 	movaps 0x1a0(%rsp),%xmm0
  675962:	00 
  675963:	f3 0f 11 84 24 d8 00 	movss  %xmm0,0xd8(%rsp)
  67596a:	00 00 
  67596c:	e9 94 00 00 00       	jmp    675a05 <<gpui_canvas::text::planner::Planner>::shape+0x1965>
  675971:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  675978:	0f 1f 84 00 00 00 00 
  67597f:	00 
  675980:	48 3b 9c 24 c0 00 00 	cmp    0xc0(%rsp),%rbx
  675987:	00 
  675988:	0f 84 3d 01 00 00    	je     675acb <<gpui_canvas::text::planner::Planner>::shape+0x1a2b>
  67598e:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  675993:	8b 03                	mov    (%rbx),%eax
  675995:	89 44 24 5c          	mov    %eax,0x5c(%rsp)
  675999:	f2 0f 10 43 04       	movsd  0x4(%rbx),%xmm0
  67599e:	0f 29 84 24 a0 01 00 	movaps %xmm0,0x1a0(%rsp)
  6759a5:	00 
  6759a6:	f3 0f 10 43 0c       	movss  0xc(%rbx),%xmm0
  6759ab:	f3 0f 11 44 24 08    	movss  %xmm0,0x8(%rsp)
  6759b1:	48 83 c3 10          	add    $0x10,%rbx
  6759b5:	48 89 54 24 60       	mov    %rdx,0x60(%rsp)
  6759ba:	83 bc 24 dc 00 00 00 	cmpl   $0x0,0xdc(%rsp)
  6759c1:	00 
  6759c2:	75 8f                	jne    675953 <<gpui_canvas::text::planner::Planner>::shape+0x18b3>
  6759c4:	0f 28 84 24 a0 01 00 	movaps 0x1a0(%rsp),%xmm0
  6759cb:	00 
  6759cc:	f3 0f 11 84 24 d8 00 	movss  %xmm0,0xd8(%rsp)
  6759d3:	00 00 
  6759d5:	eb 5f                	jmp    675a36 <<gpui_canvas::text::planner::Planner>::shape+0x1996>
  6759d7:	f3 0f 10 84 24 c0 01 	movss  0x1c0(%rsp),%xmm0
  6759de:	00 00 
  6759e0:	0f 28 c8             	movaps %xmm0,%xmm1
  6759e3:	f3 0f 58 8c 24 a0 01 	addss  0x1a0(%rsp),%xmm1
  6759ea:	00 00 
  6759ec:	f3 0f 11 8c 24 d8 00 	movss  %xmm1,0xd8(%rsp)
  6759f3:	00 00 
  6759f5:	f3 0f 10 4c 24 08    	movss  0x8(%rsp),%xmm1
  6759fb:	f3 0f 58 c8          	addss  %xmm0,%xmm1
  6759ff:	f3 0f 11 4c 24 08    	movss  %xmm1,0x8(%rsp)
  675a05:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  675a0a:	48 ff c2             	inc    %rdx
  675a0d:	48 8b 84 24 38 01 00 	mov    0x138(%rsp),%rax
  675a14:	00 
  675a15:	48 89 54 24 60       	mov    %rdx,0x60(%rsp)
  675a1a:	48 39 c2             	cmp    %rax,%rdx
  675a1d:	75 17                	jne    675a36 <<gpui_canvas::text::planner::Planner>::shape+0x1996>
  675a1f:	f3 0f 10 44 24 08    	movss  0x8(%rsp),%xmm0
  675a25:	f3 0f 58 44 24 58    	addss  0x58(%rsp),%xmm0
  675a2b:	f3 0f 11 44 24 08    	movss  %xmm0,0x8(%rsp)
  675a31:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  675a36:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
  675a3d:	00 
  675a3e:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
  675a45:	00 
  675a46:	e8 95 26 00 00       	call   6780e0 <<core::iter::adapters::flatten::FlattenCompat<core::iter::adapters::map::Map<core::ops::range::Range<u32>, <parley::layout::run::Run<()>>::glyph_source_ranges::{closure#0}>, core::iter::sources::repeat_n::RepeatN<core::ops::range::Range<usize>>> as core::iter::traits::iterator::Iterator>::next>
  675a4b:	83 bc 24 88 00 00 00 	cmpl   $0x1,0x88(%rsp)
  675a52:	01 
  675a53:	0f 85 e0 15 00 00    	jne    677039 <<gpui_canvas::text::planner::Planner>::shape+0x2f99>
  675a59:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  675a5f:	f3 0f 58 44 24 08    	addss  0x8(%rsp),%xmm0
  675a65:	31 c0                	xor    %eax,%eax
  675a67:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  675a6c:	48 39 8c 24 00 01 00 	cmp    %rcx,0x100(%rsp)
  675a73:	00 
  675a74:	0f 84 9b fe ff ff    	je     675915 <<gpui_canvas::text::planner::Planner>::shape+0x1875>
  675a7a:	f3 0f 11 84 24 c4 01 	movss  %xmm0,0x1c4(%rsp)
  675a81:	00 00 
  675a83:	4c 8b 8c 24 90 00 00 	mov    0x90(%rsp),%r9
  675a8a:	00 
  675a8b:	48 8b ac 24 98 00 00 	mov    0x98(%rsp),%rbp
  675a92:	00 
  675a93:	49 39 e9             	cmp    %rbp,%r9
  675a96:	48 8b 8c 24 10 01 00 	mov    0x110(%rsp),%rcx
  675a9d:	00 
  675a9e:	0f 87 85 15 00 00    	ja     677029 <<gpui_canvas::text::planner::Planner>::shape+0x2f89>
  675aa4:	4d 85 c9             	test   %r9,%r9
  675aa7:	0f 84 f7 04 00 00    	je     675fa4 <<gpui_canvas::text::planner::Planner>::shape+0x1f04>
  675aad:	49 39 c9             	cmp    %rcx,%r9
  675ab0:	0f 83 e8 04 00 00    	jae    675f9e <<gpui_canvas::text::planner::Planner>::shape+0x1efe>
  675ab6:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  675abb:	42 80 3c 08 bf       	cmpb   $0xbf,(%rax,%r9,1)
  675ac0:	0f 8f de 04 00 00    	jg     675fa4 <<gpui_canvas::text::planner::Planner>::shape+0x1f04>
  675ac6:	e9 5e 15 00 00       	jmp    677029 <<gpui_canvas::text::planner::Planner>::shape+0x2f89>
  675acb:	48 89 9c 24 c0 00 00 	mov    %rbx,0xc0(%rsp)
  675ad2:	00 
  675ad3:	f6 84 24 90 02 00 00 	testb  $0x1,0x290(%rsp)
  675ada:	01 
  675adb:	74 19                	je     675af6 <<gpui_canvas::text::planner::Planner>::shape+0x1a56>
  675add:	4c 89 fa             	mov    %r15,%rdx
  675ae0:	48 8b 8c 24 20 01 00 	mov    0x120(%rsp),%rcx
  675ae7:	00 
  675ae8:	39 d1                	cmp    %edx,%ecx
  675aea:	0f 83 3d 01 00 00    	jae    675c2d <<gpui_canvas::text::planner::Planner>::shape+0x1b8d>
  675af0:	ff ca                	dec    %edx
  675af2:	89 d0                	mov    %edx,%eax
  675af4:	eb 19                	jmp    675b0f <<gpui_canvas::text::planner::Planner>::shape+0x1a6f>
  675af6:	4c 89 fa             	mov    %r15,%rdx
  675af9:	48 8b ac 24 20 01 00 	mov    0x120(%rsp),%rbp
  675b00:	00 
  675b01:	39 d5                	cmp    %edx,%ebp
  675b03:	0f 83 3f 01 00 00    	jae    675c48 <<gpui_canvas::text::planner::Planner>::shape+0x1ba8>
  675b09:	8d 4d 01             	lea    0x1(%rbp),%ecx
  675b0c:	48 89 e8             	mov    %rbp,%rax
  675b0f:	89 c7                	mov    %eax,%edi
  675b11:	49 39 fe             	cmp    %rdi,%r14
  675b14:	0f 86 29 1b 00 00    	jbe    677643 <<gpui_canvas::text::planner::Planner>::shape+0x35a3>
  675b1a:	49 89 d7             	mov    %rdx,%r15
  675b1d:	48 8d 04 7f          	lea    (%rdi,%rdi,2),%rax
  675b21:	48 8b 94 24 d0 01 00 	mov    0x1d0(%rsp),%rdx
  675b28:	00 
  675b29:	8b 5c c2 08          	mov    0x8(%rdx,%rax,8),%ebx
  675b2d:	f6 44 c2 17 01       	testb  $0x1,0x17(%rdx,%rax,8)
  675b32:	0f 85 63 05 00 00    	jne    67609b <<gpui_canvas::text::planner::Planner>::shape+0x1ffb>
  675b38:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
  675b3c:	8b 50 0c             	mov    0xc(%rax),%edx
  675b3f:	48 8d 34 1a          	lea    (%rdx,%rbx,1),%rsi
  675b43:	48 3b b4 24 40 01 00 	cmp    0x140(%rsp),%rsi
  675b4a:	00 
  675b4b:	0f 87 27 17 00 00    	ja     677278 <<gpui_canvas::text::planner::Planner>::shape+0x31d8>
  675b51:	48 c1 e3 04          	shl    $0x4,%rbx
  675b55:	48 03 9c 24 78 02 00 	add    0x278(%rsp),%rbx
  675b5c:	00 
  675b5d:	48 89 d0             	mov    %rdx,%rax
  675b60:	48 c1 e0 04          	shl    $0x4,%rax
  675b64:	48 01 d8             	add    %rbx,%rax
  675b67:	0f 57 c0             	xorps  %xmm0,%xmm0
  675b6a:	0f 29 84 24 30 02 00 	movaps %xmm0,0x230(%rsp)
  675b71:	00 
  675b72:	48 85 d2             	test   %rdx,%rdx
  675b75:	0f 85 bf 06 00 00    	jne    67623a <<gpui_canvas::text::planner::Planner>::shape+0x219a>
  675b7b:	89 ca                	mov    %ecx,%edx
  675b7d:	48 89 94 24 20 01 00 	mov    %rdx,0x120(%rsp)
  675b84:	00 
  675b85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  675b8c:	00 00 00 00 
  675b90:	f6 84 24 90 02 00 00 	testb  $0x1,0x290(%rsp)
  675b97:	01 
  675b98:	74 16                	je     675bb0 <<gpui_canvas::text::planner::Planner>::shape+0x1b10>
  675b9a:	44 39 f9             	cmp    %r15d,%ecx
  675b9d:	0f 83 c4 00 00 00    	jae    675c67 <<gpui_canvas::text::planner::Planner>::shape+0x1bc7>
  675ba3:	41 ff cf             	dec    %r15d
  675ba6:	4c 89 f8             	mov    %r15,%rax
  675ba9:	89 ca                	mov    %ecx,%edx
  675bab:	89 c1                	mov    %eax,%ecx
  675bad:	eb 19                	jmp    675bc8 <<gpui_canvas::text::planner::Planner>::shape+0x1b28>
  675baf:	90                   	nop
  675bb0:	4c 89 fa             	mov    %r15,%rdx
  675bb3:	39 d1                	cmp    %edx,%ecx
  675bb5:	0f 83 5c 01 00 00    	jae    675d17 <<gpui_canvas::text::planner::Planner>::shape+0x1c77>
  675bbb:	8d 41 01             	lea    0x1(%rcx),%eax
  675bbe:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
  675bc5:	00 
  675bc6:	89 c2                	mov    %eax,%edx
  675bc8:	89 cf                	mov    %ecx,%edi
  675bca:	49 39 fe             	cmp    %rdi,%r14
  675bcd:	0f 86 70 1a 00 00    	jbe    677643 <<gpui_canvas::text::planner::Planner>::shape+0x35a3>
  675bd3:	48 8d 04 7f          	lea    (%rdi,%rdi,2),%rax
  675bd7:	48 8b 8c 24 d0 01 00 	mov    0x1d0(%rsp),%rcx
  675bde:	00 
  675bdf:	8b 5c c1 08          	mov    0x8(%rcx,%rax,8),%ebx
  675be3:	f6 44 c1 17 01       	testb  $0x1,0x17(%rcx,%rax,8)
  675be8:	0f 85 a5 04 00 00    	jne    676093 <<gpui_canvas::text::planner::Planner>::shape+0x1ff3>
  675bee:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
  675bf2:	8b 78 0c             	mov    0xc(%rax),%edi
  675bf5:	48 8d 34 1f          	lea    (%rdi,%rbx,1),%rsi
  675bf9:	48 3b b4 24 40 01 00 	cmp    0x140(%rsp),%rsi
  675c00:	00 
  675c01:	0f 87 71 16 00 00    	ja     677278 <<gpui_canvas::text::planner::Planner>::shape+0x31d8>
  675c07:	48 c1 e3 04          	shl    $0x4,%rbx
  675c0b:	48 03 9c 24 78 02 00 	add    0x278(%rsp),%rbx
  675c12:	00 
  675c13:	48 89 f8             	mov    %rdi,%rax
  675c16:	48 c1 e0 04          	shl    $0x4,%rax
  675c1a:	48 01 d8             	add    %rbx,%rax
  675c1d:	89 d1                	mov    %edx,%ecx
  675c1f:	48 85 ff             	test   %rdi,%rdi
  675c22:	0f 84 68 ff ff ff    	je     675b90 <<gpui_canvas::text::planner::Planner>::shape+0x1af0>
  675c28:	e9 df 04 00 00       	jmp    67610c <<gpui_canvas::text::planner::Planner>::shape+0x206c>
  675c2d:	48 89 d8             	mov    %rbx,%rax
  675c30:	3b 8c 24 f0 01 00 00 	cmp    0x1f0(%rsp),%ecx
  675c37:	0f 95 c2             	setne  %dl
  675c3a:	84 94 24 dc 00 00 00 	test   %dl,0xdc(%rsp)
  675c41:	75 4e                	jne    675c91 <<gpui_canvas::text::planner::Planner>::shape+0x1bf1>
  675c43:	e9 0c 06 00 00       	jmp    676254 <<gpui_canvas::text::planner::Planner>::shape+0x21b4>
  675c48:	48 89 d8             	mov    %rbx,%rax
  675c4b:	3b 94 24 f8 01 00 00 	cmp    0x1f8(%rsp),%edx
  675c52:	0f 95 c1             	setne  %cl
  675c55:	84 8c 24 dc 00 00 00 	test   %cl,0xdc(%rsp)
  675c5c:	0f 85 df 00 00 00    	jne    675d41 <<gpui_canvas::text::planner::Planner>::shape+0x1ca1>
  675c62:	e9 ed 05 00 00       	jmp    676254 <<gpui_canvas::text::planner::Planner>::shape+0x21b4>
  675c67:	0f 57 c0             	xorps  %xmm0,%xmm0
  675c6a:	0f 29 84 24 30 02 00 	movaps %xmm0,0x230(%rsp)
  675c71:	00 
  675c72:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  675c79:	00 
  675c7a:	3b 8c 24 f0 01 00 00 	cmp    0x1f0(%rsp),%ecx
  675c81:	0f 95 c2             	setne  %dl
  675c84:	84 94 24 dc 00 00 00 	test   %dl,0xdc(%rsp)
  675c8b:	0f 84 c3 05 00 00    	je     676254 <<gpui_canvas::text::planner::Planner>::shape+0x21b4>
  675c91:	8d 79 ff             	lea    -0x1(%rcx),%edi
  675c94:	49 39 fe             	cmp    %rdi,%r14
  675c97:	0f 86 47 1a 00 00    	jbe    6776e4 <<gpui_canvas::text::planner::Planner>::shape+0x3644>
  675c9d:	3b bc 24 f0 01 00 00 	cmp    0x1f0(%rsp),%edi
  675ca4:	76 48                	jbe    675cee <<gpui_canvas::text::planner::Planner>::shape+0x1c4e>
  675ca6:	48 8d 14 7f          	lea    (%rdi,%rdi,2),%rdx
  675caa:	48 8b b4 24 50 02 00 	mov    0x250(%rsp),%rsi
  675cb1:	00 
  675cb2:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
  675cb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  675cbd:	00 00 00 
  675cc0:	49 39 fe             	cmp    %rdi,%r14
  675cc3:	0f 86 9b 19 00 00    	jbe    677664 <<gpui_canvas::text::planner::Planner>::shape+0x35c4>
  675cc9:	f6 42 01 02          	testb  $0x2,0x1(%rdx)
  675ccd:	75 1f                	jne    675cee <<gpui_canvas::text::planner::Planner>::shape+0x1c4e>
  675ccf:	48 ff cf             	dec    %rdi
  675cd2:	48 83 c2 e8          	add    $0xffffffffffffffe8,%rdx
  675cd6:	39 bc 24 f0 01 00 00 	cmp    %edi,0x1f0(%rsp)
  675cdd:	72 e1                	jb     675cc0 <<gpui_canvas::text::planner::Planner>::shape+0x1c20>
  675cdf:	48 8b 94 24 f0 01 00 	mov    0x1f0(%rsp),%rdx
  675ce6:	00 
  675ce7:	48 89 d7             	mov    %rdx,%rdi
  675cea:	89 d5                	mov    %edx,%ebp
  675cec:	eb 02                	jmp    675cf0 <<gpui_canvas::text::planner::Planner>::shape+0x1c50>
  675cee:	89 fd                	mov    %edi,%ebp
  675cf0:	49 39 fe             	cmp    %rdi,%r14
  675cf3:	0f 86 f7 19 00 00    	jbe    6776f0 <<gpui_canvas::text::planner::Planner>::shape+0x3650>
  675cf9:	48 89 ac 24 20 01 00 	mov    %rbp,0x120(%rsp)
  675d00:	00 
  675d01:	89 ca                	mov    %ecx,%edx
  675d03:	48 ff ca             	dec    %rdx
  675d06:	4c 39 f2             	cmp    %r14,%rdx
  675d09:	0f 83 ed 19 00 00    	jae    6776fc <<gpui_canvas::text::planner::Planner>::shape+0x365c>
  675d0f:	41 89 cf             	mov    %ecx,%r15d
  675d12:	e9 a8 00 00 00       	jmp    675dbf <<gpui_canvas::text::planner::Planner>::shape+0x1d1f>
  675d17:	0f 57 c0             	xorps  %xmm0,%xmm0
  675d1a:	0f 29 84 24 30 02 00 	movaps %xmm0,0x230(%rsp)
  675d21:	00 
  675d22:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  675d29:	00 
  675d2a:	3b 94 24 f8 01 00 00 	cmp    0x1f8(%rsp),%edx
  675d31:	0f 95 c1             	setne  %cl
  675d34:	84 8c 24 dc 00 00 00 	test   %cl,0xdc(%rsp)
  675d3b:	0f 84 13 05 00 00    	je     676254 <<gpui_canvas::text::planner::Planner>::shape+0x21b4>
  675d41:	49 89 d0             	mov    %rdx,%r8
  675d44:	48 89 d1             	mov    %rdx,%rcx
  675d47:	89 cf                	mov    %ecx,%edi
  675d49:	49 39 fe             	cmp    %rdi,%r14
  675d4c:	0f 86 7d 19 00 00    	jbe    6776cf <<gpui_canvas::text::planner::Planner>::shape+0x362f>
  675d52:	44 8d 79 01          	lea    0x1(%rcx),%r15d
  675d56:	44 3b bc 24 f8 01 00 	cmp    0x1f8(%rsp),%r15d
  675d5d:	00 
  675d5e:	73 48                	jae    675da8 <<gpui_canvas::text::planner::Planner>::shape+0x1d08>
  675d60:	44 89 fa             	mov    %r15d,%edx
  675d63:	48 8d 0c 52          	lea    (%rdx,%rdx,2),%rcx
  675d67:	48 8b b4 24 50 02 00 	mov    0x250(%rsp),%rsi
  675d6e:	00 
  675d6f:	48 8d 34 ce          	lea    (%rsi,%rcx,8),%rsi
  675d73:	49 89 d7             	mov    %rdx,%r15
  675d76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  675d7d:	00 00 00 
  675d80:	4d 39 fe             	cmp    %r15,%r14
  675d83:	0f 86 c3 18 00 00    	jbe    67764c <<gpui_canvas::text::planner::Planner>::shape+0x35ac>
  675d89:	f6 46 01 02          	testb  $0x2,0x1(%rsi)
  675d8d:	75 19                	jne    675da8 <<gpui_canvas::text::planner::Planner>::shape+0x1d08>
  675d8f:	49 ff c7             	inc    %r15
  675d92:	48 83 c6 18          	add    $0x18,%rsi
  675d96:	4c 39 bc 24 f8 01 00 	cmp    %r15,0x1f8(%rsp)
  675d9d:	00 
  675d9e:	75 e0                	jne    675d80 <<gpui_canvas::text::planner::Planner>::shape+0x1ce0>
  675da0:	4c 8b bc 24 f8 01 00 	mov    0x1f8(%rsp),%r15
  675da7:	00 
  675da8:	44 89 fa             	mov    %r15d,%edx
  675dab:	48 ff ca             	dec    %rdx
  675dae:	4c 39 f2             	cmp    %r14,%rdx
  675db1:	0f 83 21 19 00 00    	jae    6776d8 <<gpui_canvas::text::planner::Planner>::shape+0x3638>
  675db7:	4c 89 84 24 20 01 00 	mov    %r8,0x120(%rsp)
  675dbe:	00 
  675dbf:	48 83 bc 24 68 02 00 	cmpq   $0x0,0x268(%rsp)
  675dc6:	00 00 
  675dc8:	0f 84 86 04 00 00    	je     676254 <<gpui_canvas::text::planner::Planner>::shape+0x21b4>
  675dce:	48 8d 0c 7f          	lea    (%rdi,%rdi,2),%rcx
  675dd2:	48 8b b4 24 d0 01 00 	mov    0x1d0(%rsp),%rsi
  675dd9:	00 
  675dda:	8b 0c ce             	mov    (%rsi,%rcx,8),%ecx
  675ddd:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
  675de1:	8b 74 d6 04          	mov    0x4(%rsi,%rdx,8),%esi
  675de5:	39 ce                	cmp    %ecx,%esi
  675de7:	0f 82 b3 17 00 00    	jb     6775a0 <<gpui_canvas::text::planner::Planner>::shape+0x3500>
  675ded:	48 39 b4 24 00 02 00 	cmp    %rsi,0x200(%rsp)
  675df4:	00 
  675df5:	0f 82 a5 17 00 00    	jb     6775a0 <<gpui_canvas::text::planner::Planner>::shape+0x3500>
  675dfb:	39 ce                	cmp    %ecx,%esi
  675dfd:	0f 84 ad 18 00 00    	je     6776b0 <<gpui_canvas::text::planner::Planner>::shape+0x3610>
  675e03:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  675e07:	48 8b 94 24 68 02 00 	mov    0x268(%rsp),%rdx
  675e0e:	00 
  675e0f:	0f b6 4c 8a 07       	movzbl 0x7(%rdx,%rcx,4),%ecx
  675e14:	8d 51 ff             	lea    -0x1(%rcx),%edx
  675e17:	83 fa 02             	cmp    $0x2,%edx
  675e1a:	73 26                	jae    675e42 <<gpui_canvas::text::planner::Planner>::shape+0x1da2>
  675e1c:	f3 0f 10 84 24 24 02 	movss  0x224(%rsp),%xmm0
  675e23:	00 00 
  675e25:	f3 0f 11 44 24 58    	movss  %xmm0,0x58(%rsp)
  675e2b:	4c 89 fa             	mov    %r15,%rdx
  675e2e:	3b 94 24 20 02 00 00 	cmp    0x220(%rsp),%edx
  675e35:	77 2b                	ja     675e62 <<gpui_canvas::text::planner::Planner>::shape+0x1dc2>
  675e37:	f3 0f 10 84 24 1c 02 	movss  0x21c(%rsp),%xmm0
  675e3e:	00 00 
  675e40:	eb 1a                	jmp    675e5c <<gpui_canvas::text::planner::Planner>::shape+0x1dbc>
  675e42:	f3 0f 10 84 24 28 02 	movss  0x228(%rsp),%xmm0
  675e49:	00 00 
  675e4b:	f3 0f 11 44 24 58    	movss  %xmm0,0x58(%rsp)
  675e51:	83 f9 06             	cmp    $0x6,%ecx
  675e54:	4c 89 fa             	mov    %r15,%rdx
  675e57:	75 09                	jne    675e62 <<gpui_canvas::text::planner::Planner>::shape+0x1dc2>
  675e59:	0f 57 c0             	xorps  %xmm0,%xmm0
  675e5c:	f3 0f 11 44 24 58    	movss  %xmm0,0x58(%rsp)
  675e62:	89 d6                	mov    %edx,%esi
  675e64:	49 39 f6             	cmp    %rsi,%r14
  675e67:	0f 92 c1             	setb   %cl
  675e6a:	3b 94 24 20 01 00 00 	cmp    0x120(%rsp),%edx
  675e71:	0f 82 0e 01 00 00    	jb     675f85 <<gpui_canvas::text::planner::Planner>::shape+0x1ee5>
  675e77:	48 8b bc 24 20 01 00 	mov    0x120(%rsp),%rdi
  675e7e:	00 
  675e7f:	89 fa                	mov    %edi,%edx
  675e81:	84 c9                	test   %cl,%cl
  675e83:	0f 85 36 17 00 00    	jne    6775bf <<gpui_canvas::text::planner::Planner>::shape+0x351f>
  675e89:	44 39 ff             	cmp    %r15d,%edi
  675e8c:	75 11                	jne    675e9f <<gpui_canvas::text::planner::Planner>::shape+0x1dff>
  675e8e:	48 c7 84 24 38 01 00 	movq   $0x0,0x138(%rsp)
  675e95:	00 00 00 00 00 
  675e9a:	e9 bd 00 00 00       	jmp    675f5c <<gpui_canvas::text::planner::Planner>::shape+0x1ebc>
  675e9f:	48 8d 0c d5 00 00 00 	lea    0x0(,%rdx,8),%rcx
  675ea6:	00 
  675ea7:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  675eab:	48 8d 7e ff          	lea    -0x1(%rsi),%rdi
  675eaf:	48 39 d7             	cmp    %rdx,%rdi
  675eb2:	75 10                	jne    675ec4 <<gpui_canvas::text::planner::Planner>::shape+0x1e24>
  675eb4:	31 d2                	xor    %edx,%edx
  675eb6:	48 c7 84 24 38 01 00 	movq   $0x0,0x138(%rsp)
  675ebd:	00 00 00 00 00 
  675ec2:	eb 67                	jmp    675f2b <<gpui_canvas::text::planner::Planner>::shape+0x1e8b>
  675ec4:	48 29 d6             	sub    %rdx,%rsi
  675ec7:	48 89 f7             	mov    %rsi,%rdi
  675eca:	48 83 e7 fe          	and    $0xfffffffffffffffe,%rdi
  675ece:	48 8b 94 24 00 03 00 	mov    0x300(%rsp),%rdx
  675ed5:	00 
  675ed6:	4c 8d 04 0a          	lea    (%rdx,%rcx,1),%r8
  675eda:	31 d2                	xor    %edx,%edx
  675edc:	45 31 d2             	xor    %r10d,%r10d
  675edf:	41 bb 01 00 00 00    	mov    $0x1,%r11d
  675ee5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  675eec:	00 00 00 00 
  675ef0:	45 8b 48 de          	mov    -0x22(%r8),%r9d
  675ef4:	41 f6 40 e9 01       	testb  $0x1,-0x17(%r8)
  675ef9:	4d 0f 45 cb          	cmovne %r11,%r9
  675efd:	4d 01 d1             	add    %r10,%r9
  675f00:	41 f6 40 01 01       	testb  $0x1,0x1(%r8)
  675f05:	45 8b 50 f6          	mov    -0xa(%r8),%r10d
  675f09:	4d 0f 45 d3          	cmovne %r11,%r10
  675f0d:	4d 01 ca             	add    %r9,%r10
  675f10:	48 83 c2 02          	add    $0x2,%rdx
  675f14:	49 83 c0 30          	add    $0x30,%r8
  675f18:	48 39 d7             	cmp    %rdx,%rdi
  675f1b:	75 d3                	jne    675ef0 <<gpui_canvas::text::planner::Planner>::shape+0x1e50>
  675f1d:	4c 89 94 24 38 01 00 	mov    %r10,0x138(%rsp)
  675f24:	00 
  675f25:	40 f6 c6 01          	test   $0x1,%sil
  675f29:	74 31                	je     675f5c <<gpui_canvas::text::planner::Planner>::shape+0x1ebc>
  675f2b:	48 8b b4 24 38 01 00 	mov    0x138(%rsp),%rsi
  675f32:	00 
  675f33:	48 03 8c 24 d0 01 00 	add    0x1d0(%rsp),%rcx
  675f3a:	00 
  675f3b:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
  675f3f:	f6 44 d1 17 01       	testb  $0x1,0x17(%rcx,%rdx,8)
  675f44:	8b 54 d1 0c          	mov    0xc(%rcx,%rdx,8),%edx
  675f48:	b9 01 00 00 00       	mov    $0x1,%ecx
  675f4d:	48 0f 45 d1          	cmovne %rcx,%rdx
  675f51:	48 01 f2             	add    %rsi,%rdx
  675f54:	48 89 94 24 38 01 00 	mov    %rdx,0x138(%rsp)
  675f5b:	00 
  675f5c:	0f 57 c0             	xorps  %xmm0,%xmm0
  675f5f:	f3 0f 11 84 24 c0 01 	movss  %xmm0,0x1c0(%rsp)
  675f66:	00 00 
  675f68:	b9 00 00 00 00       	mov    $0x0,%ecx
  675f6d:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
  675f72:	ba 00 00 00 00       	mov    $0x0,%edx
  675f77:	48 39 c3             	cmp    %rax,%rbx
  675f7a:	0f 84 53 fb ff ff    	je     675ad3 <<gpui_canvas::text::planner::Planner>::shape+0x1a33>
  675f80:	e9 0e fa ff ff       	jmp    675993 <<gpui_canvas::text::planner::Planner>::shape+0x18f3>
  675f85:	b1 01                	mov    $0x1,%cl
  675f87:	48 8b bc 24 20 01 00 	mov    0x120(%rsp),%rdi
  675f8e:	00 
  675f8f:	89 fa                	mov    %edi,%edx
  675f91:	84 c9                	test   %cl,%cl
  675f93:	0f 84 f0 fe ff ff    	je     675e89 <<gpui_canvas::text::planner::Planner>::shape+0x1de9>
  675f99:	e9 21 16 00 00       	jmp    6775bf <<gpui_canvas::text::planner::Planner>::shape+0x351f>
  675f9e:	0f 85 85 10 00 00    	jne    677029 <<gpui_canvas::text::planner::Planner>::shape+0x2f89>
  675fa4:	48 85 ed             	test   %rbp,%rbp
  675fa7:	0f 94 c2             	sete   %dl
  675faa:	74 1b                	je     675fc7 <<gpui_canvas::text::planner::Planner>::shape+0x1f27>
  675fac:	48 39 cd             	cmp    %rcx,%rbp
  675faf:	73 10                	jae    675fc1 <<gpui_canvas::text::planner::Planner>::shape+0x1f21>
  675fb1:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  675fb6:	80 3c 28 c0          	cmpb   $0xc0,(%rax,%rbp,1)
  675fba:	7d 0b                	jge    675fc7 <<gpui_canvas::text::planner::Planner>::shape+0x1f27>
  675fbc:	e9 68 10 00 00       	jmp    677029 <<gpui_canvas::text::planner::Planner>::shape+0x2f89>
  675fc1:	0f 85 62 10 00 00    	jne    677029 <<gpui_canvas::text::planner::Planner>::shape+0x2f89>
  675fc7:	83 7c 24 5c 00       	cmpl   $0x0,0x5c(%rsp)
  675fcc:	0f 84 9a 00 00 00    	je     67606c <<gpui_canvas::text::planner::Planner>::shape+0x1fcc>
  675fd2:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  675fd8:	f3 0f 58 84 24 d8 00 	addss  0xd8(%rsp),%xmm0
  675fdf:	00 00 
  675fe1:	f3 0f 11 44 24 0c    	movss  %xmm0,0xc(%rsp)
  675fe7:	66 0f 7e c1          	movd   %xmm0,%ecx
  675feb:	0f 28 84 24 a0 01 00 	movaps 0x1a0(%rsp),%xmm0
  675ff2:	00 
  675ff3:	0f 58 84 24 e0 03 00 	addps  0x3e0(%rsp),%xmm0
  675ffa:	00 
  675ffb:	0f c6 c0 55          	shufps $0x55,%xmm0,%xmm0
  675fff:	0f 29 84 24 a0 01 00 	movaps %xmm0,0x1a0(%rsp)
  676006:	00 
  676007:	66 0f 7e c0          	movd   %xmm0,%eax
  67600b:	81 e1 ff ff ff 7f    	and    $0x7fffffff,%ecx
  676011:	25 ff ff ff 7f       	and    $0x7fffffff,%eax
  676016:	3d 00 00 80 7f       	cmp    $0x7f800000,%eax
  67601b:	0f 9d c0             	setge  %al
  67601e:	81 f9 ff ff 7f 7f    	cmp    $0x7f7fffff,%ecx
  676024:	0f 8f 20 10 00 00    	jg     67704a <<gpui_canvas::text::planner::Planner>::shape+0x2faa>
  67602a:	84 c0                	test   %al,%al
  67602c:	0f 85 18 10 00 00    	jne    67704a <<gpui_canvas::text::planner::Planner>::shape+0x2faa>
  676032:	81 7c 24 5c ff ff 00 	cmpl   $0xffff,0x5c(%rsp)
  676039:	00 
  67603a:	0f 87 e9 0f 00 00    	ja     677029 <<gpui_canvas::text::planner::Planner>::shape+0x2f89>
  676040:	4c 89 cd             	mov    %r9,%rbp
  676043:	4c 8b b4 24 f8 00 00 	mov    0xf8(%rsp),%r14
  67604a:	00 
  67604b:	4c 3b b4 24 e8 00 00 	cmp    0xe8(%rsp),%r14
  676052:	00 
  676053:	0f 85 4e f8 ff ff    	jne    6758a7 <<gpui_canvas::text::planner::Planner>::shape+0x1807>
  676059:	48 8d bc 24 e8 00 00 	lea    0xe8(%rsp),%rdi
  676060:	00 
  676061:	ff 15 d1 40 11 00    	call   *0x1140d1(%rip)        # 78a138 <_DYNAMIC+0x498>
  676067:	e9 3b f8 ff ff       	jmp    6758a7 <<gpui_canvas::text::planner::Planner>::shape+0x1807>
  67606c:	4d 85 c9             	test   %r9,%r9
  67606f:	0f 84 af 00 00 00    	je     676124 <<gpui_canvas::text::planner::Planner>::shape+0x2084>
  676075:	49 39 c9             	cmp    %rcx,%r9
  676078:	0f 83 a0 00 00 00    	jae    67611e <<gpui_canvas::text::planner::Planner>::shape+0x207e>
  67607e:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  676083:	42 80 3c 08 bf       	cmpb   $0xbf,(%rax,%r9,1)
  676088:	0f 8f 96 00 00 00    	jg     676124 <<gpui_canvas::text::planner::Planner>::shape+0x2084>
  67608e:	e9 63 10 00 00       	jmp    6770f6 <<gpui_canvas::text::planner::Planner>::shape+0x3056>
  676093:	48 8b 8c 24 20 01 00 	mov    0x120(%rsp),%rcx
  67609a:	00 
  67609b:	89 da                	mov    %ebx,%edx
  67609d:	48 8d 04 7f          	lea    (%rdi,%rdi,2),%rax
  6760a1:	48 8b b4 24 d0 01 00 	mov    0x1d0(%rsp),%rsi
  6760a8:	00 
  6760a9:	f3 0f 10 44 c6 10    	movss  0x10(%rsi,%rax,8),%xmm0
  6760af:	0f 57 c9             	xorps  %xmm1,%xmm1
  6760b2:	0f 29 8c 24 a0 01 00 	movaps %xmm1,0x1a0(%rsp)
  6760b9:	00 
  6760ba:	bb 04 00 00 00       	mov    $0x4,%ebx
  6760bf:	b8 04 00 00 00       	mov    $0x4,%eax
  6760c4:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  6760cb:	00 
  6760cc:	48 89 8c 24 20 01 00 	mov    %rcx,0x120(%rsp)
  6760d3:	00 
  6760d4:	f3 0f 11 84 24 b8 01 	movss  %xmm0,0x1b8(%rsp)
  6760db:	00 00 
  6760dd:	f3 0f 11 44 24 08    	movss  %xmm0,0x8(%rsp)
  6760e3:	89 94 24 bc 01 00 00 	mov    %edx,0x1bc(%rsp)
  6760ea:	89 54 24 5c          	mov    %edx,0x5c(%rsp)
  6760ee:	0f 57 c0             	xorps  %xmm0,%xmm0
  6760f1:	0f 29 84 24 30 02 00 	movaps %xmm0,0x230(%rsp)
  6760f8:	00 
  6760f9:	83 bc 24 dc 00 00 00 	cmpl   $0x0,0xdc(%rsp)
  676100:	00 
  676101:	0f 85 4c f8 ff ff    	jne    675953 <<gpui_canvas::text::planner::Planner>::shape+0x18b3>
  676107:	e9 b8 f8 ff ff       	jmp    6759c4 <<gpui_canvas::text::planner::Planner>::shape+0x1924>
  67610c:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  676111:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  676118:	00 
  676119:	e9 75 f8 ff ff       	jmp    675993 <<gpui_canvas::text::planner::Planner>::shape+0x18f3>
  67611e:	0f 85 d2 0f 00 00    	jne    6770f6 <<gpui_canvas::text::planner::Planner>::shape+0x3056>
  676124:	48 85 ed             	test   %rbp,%rbp
  676127:	4c 89 8c 24 f8 02 00 	mov    %r9,0x2f8(%rsp)
  67612e:	00 
  67612f:	74 1b                	je     67614c <<gpui_canvas::text::planner::Planner>::shape+0x20ac>
  676131:	48 39 cd             	cmp    %rcx,%rbp
  676134:	73 10                	jae    676146 <<gpui_canvas::text::planner::Planner>::shape+0x20a6>
  676136:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  67613b:	80 3c 28 c0          	cmpb   $0xc0,(%rax,%rbp,1)
  67613f:	7d 0b                	jge    67614c <<gpui_canvas::text::planner::Planner>::shape+0x20ac>
  676141:	e9 b6 0f 00 00       	jmp    6770fc <<gpui_canvas::text::planner::Planner>::shape+0x305c>
  676146:	0f 85 b0 0f 00 00    	jne    6770fc <<gpui_canvas::text::planner::Planner>::shape+0x305c>
  67614c:	89 54 24 0c          	mov    %edx,0xc(%rsp)
  676150:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  676155:	4e 8d 34 08          	lea    (%rax,%r9,1),%r14
  676159:	48 01 e8             	add    %rbp,%rax
  67615c:	48 89 84 24 a0 01 00 	mov    %rax,0x1a0(%rsp)
  676163:	00 
  676164:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  67616b:	00 00 00 00 00 
  676170:	4c 3b b4 24 a0 01 00 	cmp    0x1a0(%rsp),%r14
  676177:	00 
  676178:	0f 84 8c 00 00 00    	je     67620a <<gpui_canvas::text::planner::Planner>::shape+0x216a>
  67617e:	41 0f b6 36          	movzbl (%r14),%esi
  676182:	40 84 f6             	test   %sil,%sil
  676185:	78 09                	js     676190 <<gpui_canvas::text::planner::Planner>::shape+0x20f0>
  676187:	49 ff c6             	inc    %r14
  67618a:	eb 64                	jmp    6761f0 <<gpui_canvas::text::planner::Planner>::shape+0x2150>
  67618c:	0f 1f 40 00          	nopl   0x0(%rax)
  676190:	89 f0                	mov    %esi,%eax
  676192:	83 e0 1f             	and    $0x1f,%eax
  676195:	41 0f b6 56 01       	movzbl 0x1(%r14),%edx
  67619a:	83 e2 3f             	and    $0x3f,%edx
  67619d:	40 80 fe df          	cmp    $0xdf,%sil
  6761a1:	76 2e                	jbe    6761d1 <<gpui_canvas::text::planner::Planner>::shape+0x2131>
  6761a3:	41 0f b6 4e 02       	movzbl 0x2(%r14),%ecx
  6761a8:	c1 e2 06             	shl    $0x6,%edx
  6761ab:	83 e1 3f             	and    $0x3f,%ecx
  6761ae:	09 d1                	or     %edx,%ecx
  6761b0:	40 80 fe f0          	cmp    $0xf0,%sil
  6761b4:	72 28                	jb     6761de <<gpui_canvas::text::planner::Planner>::shape+0x213e>
  6761b6:	41 0f b6 76 03       	movzbl 0x3(%r14),%esi
  6761bb:	49 83 c6 04          	add    $0x4,%r14
  6761bf:	83 e0 07             	and    $0x7,%eax
  6761c2:	c1 e0 12             	shl    $0x12,%eax
  6761c5:	c1 e1 06             	shl    $0x6,%ecx
  6761c8:	83 e6 3f             	and    $0x3f,%esi
  6761cb:	09 ce                	or     %ecx,%esi
  6761cd:	09 c6                	or     %eax,%esi
  6761cf:	eb 1f                	jmp    6761f0 <<gpui_canvas::text::planner::Planner>::shape+0x2150>
  6761d1:	49 83 c6 02          	add    $0x2,%r14
  6761d5:	c1 e0 06             	shl    $0x6,%eax
  6761d8:	09 d0                	or     %edx,%eax
  6761da:	89 c6                	mov    %eax,%esi
  6761dc:	eb 12                	jmp    6761f0 <<gpui_canvas::text::planner::Planner>::shape+0x2150>
  6761de:	49 83 c6 03          	add    $0x3,%r14
  6761e2:	c1 e0 0c             	shl    $0xc,%eax
  6761e5:	09 c1                	or     %eax,%ecx
  6761e7:	89 ce                	mov    %ecx,%esi
  6761e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  6761f0:	48 8d 3d 61 96 10 00 	lea    0x109661(%rip),%rdi        # 77f858 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0x30>
  6761f7:	ff 15 d3 41 11 00    	call   *0x1141d3(%rip)        # 78a3d0 <_DYNAMIC+0x730>
  6761fd:	84 c0                	test   %al,%al
  6761ff:	0f 85 6b ff ff ff    	jne    676170 <<gpui_canvas::text::planner::Planner>::shape+0x20d0>
  676205:	e9 fa 0e 00 00       	jmp    677104 <<gpui_canvas::text::planner::Planner>::shape+0x3064>
  67620a:	31 c0                	xor    %eax,%eax
  67620c:	0f 57 c0             	xorps  %xmm0,%xmm0
  67620f:	f3 0f 10 4c 24 08    	movss  0x8(%rsp),%xmm1
  676215:	0f 2e c8             	ucomiss %xmm0,%xmm1
  676218:	4c 8b b4 24 e8 01 00 	mov    0x1e8(%rsp),%r14
  67621f:	00 
  676220:	f3 0f 10 84 24 c4 01 	movss  0x1c4(%rsp),%xmm0
  676227:	00 00 
  676229:	0f 85 d5 0e 00 00    	jne    677104 <<gpui_canvas::text::planner::Planner>::shape+0x3064>
  67622f:	0f 8b e0 f6 ff ff    	jnp    675915 <<gpui_canvas::text::planner::Planner>::shape+0x1875>
  676235:	e9 ca 0e 00 00       	jmp    677104 <<gpui_canvas::text::planner::Planner>::shape+0x3064>
  67623a:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  67623f:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  676246:	00 
  676247:	48 89 8c 24 20 01 00 	mov    %rcx,0x120(%rsp)
  67624e:	00 
  67624f:	e9 3f f7 ff ff       	jmp    675993 <<gpui_canvas::text::planner::Planner>::shape+0x18f3>
  676254:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
  67625b:	00 
  67625c:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
  676263:	00 
  676264:	e8 77 1e 00 00       	call   6780e0 <<core::iter::adapters::flatten::FlattenCompat<core::iter::adapters::map::Map<core::ops::range::Range<u32>, <parley::layout::run::Run<()>>::glyph_source_ranges::{closure#0}>, core::iter::sources::repeat_n::RepeatN<core::ops::range::Range<usize>>> as core::iter::traits::iterator::Iterator>::next>
  676269:	48 83 bc 24 88 00 00 	cmpq   $0x0,0x88(%rsp)
  676270:	00 00 
  676272:	0f 85 b1 0d 00 00    	jne    677029 <<gpui_canvas::text::planner::Planner>::shape+0x2f89>
  676278:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
  67627f:	00 
  676280:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  676284:	0f 84 bb f1 ff ff    	je     675445 <<gpui_canvas::text::planner::Planner>::shape+0x13a5>
  67628a:	48 8b 8c 24 00 01 00 	mov    0x100(%rsp),%rcx
  676291:	00 
  676292:	48 3b 4c 24 30       	cmp    0x30(%rsp),%rcx
  676297:	48 8b 8c 24 10 01 00 	mov    0x110(%rsp),%rcx
  67629e:	00 
  67629f:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  6762a4:	75 0f                	jne    6762b5 <<gpui_canvas::text::planner::Planner>::shape+0x2215>
  6762a6:	31 db                	xor    %ebx,%ebx
  6762a8:	45 31 f6             	xor    %r14d,%r14d
  6762ab:	48 8b b4 24 48 02 00 	mov    0x248(%rsp),%rsi
  6762b2:	00 
  6762b3:	eb 6d                	jmp    676322 <<gpui_canvas::text::planner::Planner>::shape+0x2282>
  6762b5:	48 8b bc 24 e8 02 00 	mov    0x2e8(%rsp),%rdi
  6762bc:	00 
  6762bd:	48 85 ff             	test   %rdi,%rdi
  6762c0:	48 8b b4 24 48 02 00 	mov    0x248(%rsp),%rsi
  6762c7:	00 
  6762c8:	48 0f 44 fe          	cmove  %rsi,%rdi
  6762cc:	48 8b 1f             	mov    (%rdi),%rbx
  6762cf:	4c 8b 77 08          	mov    0x8(%rdi),%r14
  6762d3:	4c 39 f3             	cmp    %r14,%rbx
  6762d6:	0f 87 4d 0d 00 00    	ja     677029 <<gpui_canvas::text::planner::Planner>::shape+0x2f89>
  6762dc:	48 85 db             	test   %rbx,%rbx
  6762df:	74 10                	je     6762f1 <<gpui_canvas::text::planner::Planner>::shape+0x2251>
  6762e1:	48 39 cb             	cmp    %rcx,%rbx
  6762e4:	73 0f                	jae    6762f5 <<gpui_canvas::text::planner::Planner>::shape+0x2255>
  6762e6:	80 3c 1a bf          	cmpb   $0xbf,(%rdx,%rbx,1)
  6762ea:	7f 12                	jg     6762fe <<gpui_canvas::text::planner::Planner>::shape+0x225e>
  6762ec:	e9 38 0d 00 00       	jmp    677029 <<gpui_canvas::text::planner::Planner>::shape+0x2f89>
  6762f1:	31 db                	xor    %ebx,%ebx
  6762f3:	eb 09                	jmp    6762fe <<gpui_canvas::text::planner::Planner>::shape+0x225e>
  6762f5:	48 89 cb             	mov    %rcx,%rbx
  6762f8:	0f 85 2b 0d 00 00    	jne    677029 <<gpui_canvas::text::planner::Planner>::shape+0x2f89>
  6762fe:	4d 85 f6             	test   %r14,%r14
  676301:	74 11                	je     676314 <<gpui_canvas::text::planner::Planner>::shape+0x2274>
  676303:	49 39 ce             	cmp    %rcx,%r14
  676306:	73 11                	jae    676319 <<gpui_canvas::text::planner::Planner>::shape+0x2279>
  676308:	42 80 3c 32 c0       	cmpb   $0xc0,(%rdx,%r14,1)
  67630d:	7d 13                	jge    676322 <<gpui_canvas::text::planner::Planner>::shape+0x2282>
  67630f:	e9 15 0d 00 00       	jmp    677029 <<gpui_canvas::text::planner::Planner>::shape+0x2f89>
  676314:	45 31 f6             	xor    %r14d,%r14d
  676317:	eb 09                	jmp    676322 <<gpui_canvas::text::planner::Planner>::shape+0x2282>
  676319:	49 89 ce             	mov    %rcx,%r14
  67631c:	0f 85 07 0d 00 00    	jne    677029 <<gpui_canvas::text::planner::Planner>::shape+0x2f89>
  676322:	8b 8c 24 f8 00 00 00 	mov    0xf8(%rsp),%ecx
  676329:	89 4c 24 60          	mov    %ecx,0x60(%rsp)
  67632d:	0f b6 ae 8c 00 00 00 	movzbl 0x8c(%rsi),%ebp
  676334:	4c 8b bc 24 60 01 00 	mov    0x160(%rsp),%r15
  67633b:	00 
  67633c:	49 39 c7             	cmp    %rax,%r15
  67633f:	75 0e                	jne    67634f <<gpui_canvas::text::planner::Planner>::shape+0x22af>
  676341:	48 8d bc 24 50 01 00 	lea    0x150(%rsp),%rdi
  676348:	00 
  676349:	ff 15 f9 3d 11 00    	call   *0x113df9(%rip)        # 78a148 <_DYNAMIC+0x4a8>
  67634f:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  676354:	01 c3                	add    %eax,%ebx
  676356:	41 01 c6             	add    %eax,%r14d
  676359:	40 80 e5 01          	and    $0x1,%bpl
  67635d:	48 8b 84 24 58 01 00 	mov    0x158(%rsp),%rax
  676364:	00 
  676365:	4b 8d 0c 7f          	lea    (%r15,%r15,2),%rcx
  676369:	89 1c c8             	mov    %ebx,(%rax,%rcx,8)
  67636c:	44 89 74 c8 04       	mov    %r14d,0x4(%rax,%rcx,8)
  676371:	48 8b 94 24 f0 02 00 	mov    0x2f0(%rsp),%rdx
  676378:	00 
  676379:	89 54 c8 08          	mov    %edx,0x8(%rax,%rcx,8)
  67637d:	8b 54 24 60          	mov    0x60(%rsp),%edx
  676381:	89 54 c8 0c          	mov    %edx,0xc(%rax,%rcx,8)
  676385:	48 8b 94 24 58 02 00 	mov    0x258(%rsp),%rdx
  67638c:	00 
  67638d:	89 54 c8 10          	mov    %edx,0x10(%rax,%rcx,8)
  676391:	48 8b 94 24 60 02 00 	mov    0x260(%rsp),%rdx
  676398:	00 
  676399:	88 54 c8 14          	mov    %dl,0x14(%rax,%rcx,8)
  67639d:	40 88 6c c8 15       	mov    %bpl,0x15(%rax,%rcx,8)
  6763a2:	49 ff c7             	inc    %r15
  6763a5:	4c 89 bc 24 60 01 00 	mov    %r15,0x160(%rsp)
  6763ac:	00 
  6763ad:	e9 93 f0 ff ff       	jmp    675445 <<gpui_canvas::text::planner::Planner>::shape+0x13a5>
  6763b2:	48 8b 84 24 08 03 00 	mov    0x308(%rsp),%rax
  6763b9:	00 
  6763ba:	48 39 84 24 c8 00 00 	cmp    %rax,0xc8(%rsp)
  6763c1:	00 
  6763c2:	48 8b 6c 24 30       	mov    0x30(%rsp),%rbp
  6763c7:	48 8b 9c 24 00 01 00 	mov    0x100(%rsp),%rbx
  6763ce:	00 
  6763cf:	0f 85 02 ec ff ff    	jne    674fd7 <<gpui_canvas::text::planner::Planner>::shape+0xf37>
  6763d5:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  6763dc:	00 ff 
  6763de:	0f 84 d9 06 00 00    	je     676abd <<gpui_canvas::text::planner::Planner>::shape+0x2a1d>
  6763e4:	48 83 bc 24 80 01 00 	cmpq   $0xffffffffffffffff,0x180(%rsp)
  6763eb:	00 ff 
  6763ed:	0f 84 ca 06 00 00    	je     676abd <<gpui_canvas::text::planner::Planner>::shape+0x2a1d>
  6763f3:	48 89 ac 24 88 00 00 	mov    %rbp,0x88(%rsp)
  6763fa:	00 
  6763fb:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
  676401:	f3 0f 11 84 24 e0 00 	movss  %xmm0,0xe0(%rsp)
  676408:	00 00 
  67640a:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  67640f:	48 89 84 24 40 03 00 	mov    %rax,0x340(%rsp)
  676416:	00 
  676417:	48 8d 84 24 e0 00 00 	lea    0xe0(%rsp),%rax
  67641e:	00 
  67641f:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
  676426:	00 
  676427:	48 8d 84 24 88 00 00 	lea    0x88(%rsp),%rax
  67642e:	00 
  67642f:	48 89 84 24 50 03 00 	mov    %rax,0x350(%rsp)
  676436:	00 
  676437:	48 8d 84 24 80 01 00 	lea    0x180(%rsp),%rax
  67643e:	00 
  67643f:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
  676446:	00 
  676447:	48 03 9c 24 48 01 00 	add    0x148(%rsp),%rbx
  67644e:	00 
  67644f:	48 c7 84 24 10 07 00 	movq   $0x0,0x710(%rsp)
  676456:	00 00 00 00 00 
  67645b:	48 c7 84 24 18 07 00 	movq   $0x8,0x718(%rsp)
  676462:	00 08 00 00 00 
  676467:	48 c7 84 24 20 07 00 	movq   $0x0,0x720(%rsp)
  67646e:	00 00 00 00 00 
  676473:	c7 84 24 30 07 00 00 	movl   $0xffffffff,0x730(%rsp)
  67647a:	ff ff ff ff 
  67647e:	4c 8b 7c 24 10       	mov    0x10(%rsp),%r15
  676483:	4c 89 bc 24 38 07 00 	mov    %r15,0x738(%rsp)
  67648a:	00 
  67648b:	48 89 9c 24 40 07 00 	mov    %rbx,0x740(%rsp)
  676492:	00 
  676493:	48 c7 84 24 48 07 00 	movq   $0x0,0x748(%rsp)
  67649a:	00 00 00 00 00 
  67649f:	48 8d 05 22 95 10 00 	lea    0x109522(%rip),%rax        # 77f9c8 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0x1a0>
  6764a6:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
  6764ad:	00 
  6764ae:	48 8d 05 eb b7 ff ff 	lea    -0x4815(%rip),%rax        # 671ca0 <icu_segmenter::rule_segmenter_v1::empty_handle_complex::<icu_segmenter::scaffold::Utf8>>
  6764b5:	48 89 84 24 58 07 00 	mov    %rax,0x758(%rsp)
  6764bc:	00 
  6764bd:	4c 8b b4 24 10 01 00 	mov    0x110(%rsp),%r14
  6764c4:	00 
  6764c5:	4c 89 b4 24 60 07 00 	mov    %r14,0x760(%rsp)
  6764cc:	00 
  6764cd:	48 c7 84 24 68 07 00 	movq   $0x0,0x768(%rsp)
  6764d4:	00 00 00 00 00 
  6764d9:	48 c7 84 24 98 07 00 	movq   $0x0,0x798(%rsp)
  6764e0:	00 00 00 00 00 
  6764e5:	c6 84 24 a0 07 00 00 	movb   $0x0,0x7a0(%rsp)
  6764ec:	00 
  6764ed:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  6764f4:	00 
  6764f5:	e8 a6 44 ff ff       	call   66a9a0 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  6764fa:	48 83 f8 01          	cmp    $0x1,%rax
  6764fe:	0f 85 9b 01 00 00    	jne    67669f <<gpui_canvas::text::planner::Planner>::shape+0x25ff>
  676504:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  67650b:	00 
  67650c:	e8 8f 44 ff ff       	call   66a9a0 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  676511:	48 83 f8 01          	cmp    $0x1,%rax
  676515:	0f 85 84 01 00 00    	jne    67669f <<gpui_canvas::text::planner::Planner>::shape+0x25ff>
  67651b:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  676522:	00 
  676523:	e8 78 44 ff ff       	call   66a9a0 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  676528:	48 83 f8 01          	cmp    $0x1,%rax
  67652c:	0f 85 6d 01 00 00    	jne    67669f <<gpui_canvas::text::planner::Planner>::shape+0x25ff>
  676532:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  676539:	00 
  67653a:	e8 61 44 ff ff       	call   66a9a0 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  67653f:	48 83 f8 01          	cmp    $0x1,%rax
  676543:	0f 85 56 01 00 00    	jne    67669f <<gpui_canvas::text::planner::Planner>::shape+0x25ff>
  676549:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  676550:	00 
  676551:	e8 4a 44 ff ff       	call   66a9a0 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  676556:	48 83 f8 01          	cmp    $0x1,%rax
  67655a:	0f 85 3f 01 00 00    	jne    67669f <<gpui_canvas::text::planner::Planner>::shape+0x25ff>
  676560:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  676567:	00 
  676568:	e8 33 44 ff ff       	call   66a9a0 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  67656d:	48 83 f8 01          	cmp    $0x1,%rax
  676571:	0f 85 28 01 00 00    	jne    67669f <<gpui_canvas::text::planner::Planner>::shape+0x25ff>
  676577:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  67657e:	00 
  67657f:	e8 1c 44 ff ff       	call   66a9a0 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  676584:	48 83 f8 01          	cmp    $0x1,%rax
  676588:	0f 85 11 01 00 00    	jne    67669f <<gpui_canvas::text::planner::Planner>::shape+0x25ff>
  67658e:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  676595:	00 
  676596:	e8 05 44 ff ff       	call   66a9a0 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  67659b:	a8 01                	test   $0x1,%al
  67659d:	0f 84 fc 00 00 00    	je     67669f <<gpui_canvas::text::planner::Planner>::shape+0x25ff>
  6765a3:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  6765aa:	00 
  6765ab:	e8 f0 43 ff ff       	call   66a9a0 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  6765b0:	48 83 f8 01          	cmp    $0x1,%rax
  6765b4:	0f 85 e5 00 00 00    	jne    67669f <<gpui_canvas::text::planner::Planner>::shape+0x25ff>
  6765ba:	48 8b b4 24 10 07 00 	mov    0x710(%rsp),%rsi
  6765c1:	00 
  6765c2:	48 85 f6             	test   %rsi,%rsi
  6765c5:	74 17                	je     6765de <<gpui_canvas::text::planner::Planner>::shape+0x253e>
  6765c7:	48 8b bc 24 18 07 00 	mov    0x718(%rsp),%rdi
  6765ce:	00 
  6765cf:	48 c1 e6 03          	shl    $0x3,%rsi
  6765d3:	ba 08 00 00 00       	mov    $0x8,%edx
  6765d8:	ff 15 fa 38 11 00    	call   *0x1138fa(%rip)        # 789ed8 <_DYNAMIC+0x238>
  6765de:	48 c7 84 24 10 07 00 	movq   $0x0,0x710(%rsp)
  6765e5:	00 00 00 00 00 
  6765ea:	48 c7 84 24 18 07 00 	movq   $0x8,0x718(%rsp)
  6765f1:	00 08 00 00 00 
  6765f6:	48 c7 84 24 20 07 00 	movq   $0x0,0x720(%rsp)
  6765fd:	00 00 00 00 00 
  676602:	c7 84 24 30 07 00 00 	movl   $0xffffffff,0x730(%rsp)
  676609:	ff ff ff ff 
  67660d:	4c 89 bc 24 38 07 00 	mov    %r15,0x738(%rsp)
  676614:	00 
  676615:	48 89 9c 24 40 07 00 	mov    %rbx,0x740(%rsp)
  67661c:	00 
  67661d:	48 c7 84 24 48 07 00 	movq   $0x0,0x748(%rsp)
  676624:	00 00 00 00 00 
  676629:	48 8d 05 98 93 10 00 	lea    0x109398(%rip),%rax        # 77f9c8 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0x1a0>
  676630:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
  676637:	00 
  676638:	48 8d 05 61 b6 ff ff 	lea    -0x499f(%rip),%rax        # 671ca0 <icu_segmenter::rule_segmenter_v1::empty_handle_complex::<icu_segmenter::scaffold::Utf8>>
  67663f:	48 89 84 24 58 07 00 	mov    %rax,0x758(%rsp)
  676646:	00 
  676647:	4c 89 b4 24 60 07 00 	mov    %r14,0x760(%rsp)
  67664e:	00 
  67664f:	48 c7 84 24 68 07 00 	movq   $0x0,0x768(%rsp)
  676656:	00 00 00 00 00 
  67665b:	48 c7 84 24 98 07 00 	movq   $0x0,0x798(%rsp)
  676662:	00 00 00 00 00 
  676667:	c6 84 24 a0 07 00 00 	movb   $0x0,0x7a0(%rsp)
  67666e:	00 
  67666f:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  676674:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
  67667b:	00 
  67667c:	f3 0f 10 05 58 71 9a 	movss  -0x658ea8(%rip),%xmm0        # 1d7dc <GCC_except_table0+0x24>
  676683:	ff 
  676684:	48 8d 94 24 40 03 00 	lea    0x340(%rsp),%rdx
  67668b:	00 
  67668c:	e8 6f 65 ff ff       	call   66cc00 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>>
  676691:	83 f8 ff             	cmp    $0xffffffff,%eax
  676694:	0f 84 23 04 00 00    	je     676abd <<gpui_canvas::text::planner::Planner>::shape+0x2a1d>
  67669a:	e9 6d 0f 00 00       	jmp    67760c <<gpui_canvas::text::planner::Planner>::shape+0x356c>
  67669f:	48 8b b4 24 10 07 00 	mov    0x710(%rsp),%rsi
  6766a6:	00 
  6766a7:	48 85 f6             	test   %rsi,%rsi
  6766aa:	74 17                	je     6766c3 <<gpui_canvas::text::planner::Planner>::shape+0x2623>
  6766ac:	48 8b bc 24 18 07 00 	mov    0x718(%rsp),%rdi
  6766b3:	00 
  6766b4:	48 c1 e6 03          	shl    $0x3,%rsi
  6766b8:	ba 08 00 00 00       	mov    $0x8,%edx
  6766bd:	ff 15 15 38 11 00    	call   *0x113815(%rip)        # 789ed8 <_DYNAMIC+0x238>
  6766c3:	48 c7 84 24 10 07 00 	movq   $0x0,0x710(%rsp)
  6766ca:	00 00 00 00 00 
  6766cf:	48 c7 84 24 18 07 00 	movq   $0x8,0x718(%rsp)
  6766d6:	00 08 00 00 00 
  6766db:	48 c7 84 24 20 07 00 	movq   $0x0,0x720(%rsp)
  6766e2:	00 00 00 00 00 
  6766e7:	c7 84 24 30 07 00 00 	movl   $0xffffffff,0x730(%rsp)
  6766ee:	ff ff ff ff 
  6766f2:	4c 89 bc 24 38 07 00 	mov    %r15,0x738(%rsp)
  6766f9:	00 
  6766fa:	48 89 9c 24 40 07 00 	mov    %rbx,0x740(%rsp)
  676701:	00 
  676702:	48 c7 84 24 48 07 00 	movq   $0x0,0x748(%rsp)
  676709:	00 00 00 00 00 
  67670e:	48 8d 05 b3 92 10 00 	lea    0x1092b3(%rip),%rax        # 77f9c8 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0x1a0>
  676715:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
  67671c:	00 
  67671d:	48 8d 05 7c b5 ff ff 	lea    -0x4a84(%rip),%rax        # 671ca0 <icu_segmenter::rule_segmenter_v1::empty_handle_complex::<icu_segmenter::scaffold::Utf8>>
  676724:	48 89 84 24 58 07 00 	mov    %rax,0x758(%rsp)
  67672b:	00 
  67672c:	4c 89 b4 24 60 07 00 	mov    %r14,0x760(%rsp)
  676733:	00 
  676734:	48 c7 84 24 68 07 00 	movq   $0x0,0x768(%rsp)
  67673b:	00 00 00 00 00 
  676740:	48 c7 84 24 98 07 00 	movq   $0x0,0x798(%rsp)
  676747:	00 00 00 00 00 
  67674c:	c6 84 24 a0 07 00 00 	movb   $0x0,0x7a0(%rsp)
  676753:	00 
  676754:	eb 42                	jmp    676798 <<gpui_canvas::text::planner::Planner>::shape+0x26f8>
  676756:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  67675d:	00 00 00 
  676760:	0f 28 84 24 00 01 00 	movaps 0x100(%rsp),%xmm0
  676767:	00 
  676768:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
  67676d:	48 8b 84 24 88 01 00 	mov    0x188(%rsp),%rax
  676774:	00 
  676775:	48 8d 0c 5b          	lea    (%rbx,%rbx,2),%rcx
  676779:	44 89 3c 88          	mov    %r15d,(%rax,%rcx,4)
  67677d:	0f 28 44 24 30       	movaps 0x30(%rsp),%xmm0
  676782:	f3 0f 11 44 88 04    	movss  %xmm0,0x4(%rax,%rcx,4)
  676788:	40 88 6c 88 08       	mov    %bpl,0x8(%rax,%rcx,4)
  67678d:	48 ff c3             	inc    %rbx
  676790:	48 89 9c 24 90 01 00 	mov    %rbx,0x190(%rsp)
  676797:	00 
  676798:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  67679f:	00 
  6767a0:	e8 fb 41 ff ff       	call   66a9a0 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  6767a5:	48 83 f8 01          	cmp    $0x1,%rax
  6767a9:	0f 85 ea 02 00 00    	jne    676a99 <<gpui_canvas::text::planner::Planner>::shape+0x29f9>
  6767af:	49 89 d6             	mov    %rdx,%r14
  6767b2:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  6767b7:	48 89 d6             	mov    %rdx,%rsi
  6767ba:	ba 01 00 00 00       	mov    $0x1,%edx
  6767bf:	e8 8c 20 00 00       	call   678850 <<parley::editing::cursor::Cursor>::from_byte_index::<()>>
  6767c4:	48 89 c3             	mov    %rax,%rbx
  6767c7:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
  6767ce:	00 
  6767cf:	80 e2 01             	and    $0x1,%dl
  6767d2:	88 94 24 a0 03 00 00 	mov    %dl,0x3a0(%rsp)
  6767d9:	4c 39 f0             	cmp    %r14,%rax
  6767dc:	0f 85 ae 00 00 00    	jne    676890 <<gpui_canvas::text::planner::Planner>::shape+0x27f0>
  6767e2:	48 8d bc 24 c0 04 00 	lea    0x4c0(%rsp),%rdi
  6767e9:	00 
  6767ea:	48 8d b4 24 98 03 00 	lea    0x398(%rsp),%rsi
  6767f1:	00 
  6767f2:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  6767f7:	f3 0f 10 05 dd 6f 9a 	movss  -0x659023(%rip),%xmm0        # 1d7dc <GCC_except_table0+0x24>
  6767fe:	ff 
  6767ff:	e8 0c 21 00 00       	call   678910 <<parley::editing::cursor::Cursor>::geometry::<()>>
  676804:	f3 0f 10 84 24 e0 00 	movss  0xe0(%rsp),%xmm0
  67680b:	00 00 
  67680d:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
  676811:	f2 0f 58 84 24 c8 04 	addsd  0x4c8(%rsp),%xmm0
  676818:	00 00 
  67681a:	66 0f 28 8c 24 c0 04 	movapd 0x4c0(%rsp),%xmm1
  676821:	00 00 
  676823:	66 0f 28 94 24 d0 04 	movapd 0x4d0(%rsp),%xmm2
  67682a:	00 00 
  67682c:	66 0f 5c d1          	subpd  %xmm1,%xmm2
  676830:	66 0f 14 c8          	unpcklpd %xmm0,%xmm1
  676834:	66 0f 5a c9          	cvtpd2ps %xmm1,%xmm1
  676838:	66 0f 5a d2          	cvtpd2ps %xmm2,%xmm2
  67683c:	66 0f 29 4c 24 30    	movapd %xmm1,0x30(%rsp)
  676842:	66 0f 29 94 24 10 01 	movapd %xmm2,0x110(%rsp)
  676849:	00 00 
  67684b:	66 0f 14 ca          	unpcklpd %xmm2,%xmm1
  67684f:	66 0f 54 0d b9 ec 9a 	andpd  -0x651347(%rip),%xmm1        # 25510 <anon.1508e9dce0c1a49d095b8c30671814b4.0.llvm.16300762181250184790+0x7e0>
  676856:	ff 
  676857:	66 0f 66 0d 81 e6 9a 	pcmpgtd -0x65197f(%rip),%xmm1        # 24ee0 <anon.1508e9dce0c1a49d095b8c30671814b4.0.llvm.16300762181250184790+0x1b0>
  67685e:	ff 
  67685f:	0f 50 c1             	movmskps %xmm1,%eax
  676862:	85 c0                	test   %eax,%eax
  676864:	0f 85 73 07 00 00    	jne    676fdd <<gpui_canvas::text::planner::Planner>::shape+0x2f3d>
  67686a:	f2 0f 5a c0          	cvtsd2ss %xmm0,%xmm0
  67686e:	f3 0f 11 44 24 10    	movss  %xmm0,0x10(%rsp)
  676874:	0f 28 84 24 10 01 00 	movaps 0x110(%rsp),%xmm0
  67687b:	00 
  67687c:	0f c6 c0 55          	shufps $0x55,%xmm0,%xmm0
  676880:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
  676885:	eb 09                	jmp    676890 <<gpui_canvas::text::planner::Planner>::shape+0x27f0>
  676887:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  67688e:	00 00 
  676890:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  676895:	4c 89 f6             	mov    %r14,%rsi
  676898:	31 d2                	xor    %edx,%edx
  67689a:	e8 b1 1f 00 00       	call   678850 <<parley::editing::cursor::Cursor>::from_byte_index::<()>>
  67689f:	48 89 c5             	mov    %rax,%rbp
  6768a2:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
  6768a9:	00 
  6768aa:	80 e2 01             	and    $0x1,%dl
  6768ad:	88 94 24 a0 03 00 00 	mov    %dl,0x3a0(%rsp)
  6768b4:	4c 39 f0             	cmp    %r14,%rax
  6768b7:	0f 85 23 01 00 00    	jne    6769e0 <<gpui_canvas::text::planner::Planner>::shape+0x2940>
  6768bd:	48 8d bc 24 c0 04 00 	lea    0x4c0(%rsp),%rdi
  6768c4:	00 
  6768c5:	48 8d b4 24 98 03 00 	lea    0x398(%rsp),%rsi
  6768cc:	00 
  6768cd:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  6768d2:	f3 0f 10 05 02 6f 9a 	movss  -0x6590fe(%rip),%xmm0        # 1d7dc <GCC_except_table0+0x24>
  6768d9:	ff 
  6768da:	e8 31 20 00 00       	call   678910 <<parley::editing::cursor::Cursor>::geometry::<()>>
  6768df:	f3 0f 10 84 24 e0 00 	movss  0xe0(%rsp),%xmm0
  6768e6:	00 00 
  6768e8:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
  6768ec:	f2 0f 58 84 24 c8 04 	addsd  0x4c8(%rsp),%xmm0
  6768f3:	00 00 
  6768f5:	66 0f 28 8c 24 c0 04 	movapd 0x4c0(%rsp),%xmm1
  6768fc:	00 00 
  6768fe:	66 0f 28 94 24 d0 04 	movapd 0x4d0(%rsp),%xmm2
  676905:	00 00 
  676907:	66 0f 5c d1          	subpd  %xmm1,%xmm2
  67690b:	66 0f 14 c8          	unpcklpd %xmm0,%xmm1
  67690f:	66 0f 5a c9          	cvtpd2ps %xmm1,%xmm1
  676913:	66 0f 5a c2          	cvtpd2ps %xmm2,%xmm0
  676917:	66 0f 14 c8          	unpcklpd %xmm0,%xmm1
  67691b:	66 0f 29 8c 24 00 01 	movapd %xmm1,0x100(%rsp)
  676922:	00 00 
  676924:	66 0f 28 c1          	movapd %xmm1,%xmm0
  676928:	66 0f 54 05 e0 eb 9a 	andpd  -0x651420(%rip),%xmm0        # 25510 <anon.1508e9dce0c1a49d095b8c30671814b4.0.llvm.16300762181250184790+0x7e0>
  67692f:	ff 
  676930:	66 0f 66 05 a8 e5 9a 	pcmpgtd -0x651a58(%rip),%xmm0        # 24ee0 <anon.1508e9dce0c1a49d095b8c30671814b4.0.llvm.16300762181250184790+0x1b0>
  676937:	ff 
  676938:	0f 50 c0             	movmskps %xmm0,%eax
  67693b:	85 c0                	test   %eax,%eax
  67693d:	0f 85 9a 06 00 00    	jne    676fdd <<gpui_canvas::text::planner::Planner>::shape+0x2f3d>
  676943:	44 8b bc 24 88 00 00 	mov    0x88(%rsp),%r15d
  67694a:	00 
  67694b:	45 01 f7             	add    %r14d,%r15d
  67694e:	4c 39 f3             	cmp    %r14,%rbx
  676951:	0f 85 09 01 00 00    	jne    676a60 <<gpui_canvas::text::planner::Planner>::shape+0x29c0>
  676957:	0f 28 44 24 30       	movaps 0x30(%rsp),%xmm0
  67695c:	0f 28 8c 24 00 01 00 	movaps 0x100(%rsp),%xmm1
  676963:	00 
  676964:	0f 2e c1             	ucomiss %xmm1,%xmm0
  676967:	0f 85 87 00 00 00    	jne    6769f4 <<gpui_canvas::text::planner::Planner>::shape+0x2954>
  67696d:	0f 8a 81 00 00 00    	jp     6769f4 <<gpui_canvas::text::planner::Planner>::shape+0x2954>
  676973:	0f 28 c1             	movaps %xmm1,%xmm0
  676976:	0f c6 c1 55          	shufps $0x55,%xmm1,%xmm0
  67697a:	f3 0f 10 54 24 10    	movss  0x10(%rsp),%xmm2
  676980:	0f 2e d0             	ucomiss %xmm0,%xmm2
  676983:	75 6f                	jne    6769f4 <<gpui_canvas::text::planner::Planner>::shape+0x2954>
  676985:	7a 6d                	jp     6769f4 <<gpui_canvas::text::planner::Planner>::shape+0x2954>
  676987:	0f 28 c1             	movaps %xmm1,%xmm0
  67698a:	66 0f 15 c1          	unpckhpd %xmm1,%xmm0
  67698e:	0f 28 94 24 10 01 00 	movaps 0x110(%rsp),%xmm2
  676995:	00 
  676996:	0f 2e d0             	ucomiss %xmm0,%xmm2
  676999:	75 59                	jne    6769f4 <<gpui_canvas::text::planner::Planner>::shape+0x2954>
  67699b:	7a 57                	jp     6769f4 <<gpui_canvas::text::planner::Planner>::shape+0x2954>
  67699d:	0f 28 c1             	movaps %xmm1,%xmm0
  6769a0:	0f c6 c1 ff          	shufps $0xff,%xmm1,%xmm0
  6769a4:	0f 28 4c 24 60       	movaps 0x60(%rsp),%xmm1
  6769a9:	0f 2e c8             	ucomiss %xmm0,%xmm1
  6769ac:	75 46                	jne    6769f4 <<gpui_canvas::text::planner::Planner>::shape+0x2954>
  6769ae:	7a 44                	jp     6769f4 <<gpui_canvas::text::planner::Planner>::shape+0x2954>
  6769b0:	48 8b 9c 24 90 01 00 	mov    0x190(%rsp),%rbx
  6769b7:	00 
  6769b8:	40 b5 03             	mov    $0x3,%bpl
  6769bb:	48 3b 9c 24 80 01 00 	cmp    0x180(%rsp),%rbx
  6769c2:	00 
  6769c3:	0f 85 a4 fd ff ff    	jne    67676d <<gpui_canvas::text::planner::Planner>::shape+0x26cd>
  6769c9:	48 8d bc 24 80 01 00 	lea    0x180(%rsp),%rdi
  6769d0:	00 
  6769d1:	ff 15 79 37 11 00    	call   *0x113779(%rip)        # 78a150 <_DYNAMIC+0x4b0>
  6769d7:	e9 91 fd ff ff       	jmp    67676d <<gpui_canvas::text::planner::Planner>::shape+0x26cd>
  6769dc:	0f 1f 40 00          	nopl   0x0(%rax)
  6769e0:	4c 39 f3             	cmp    %r14,%rbx
  6769e3:	0f 85 af fd ff ff    	jne    676798 <<gpui_canvas::text::planner::Planner>::shape+0x26f8>
  6769e9:	44 8b bc 24 88 00 00 	mov    0x88(%rsp),%r15d
  6769f0:	00 
  6769f1:	45 01 f7             	add    %r14d,%r15d
  6769f4:	48 8b 9c 24 90 01 00 	mov    0x190(%rsp),%rbx
  6769fb:	00 
  6769fc:	48 3b 9c 24 80 01 00 	cmp    0x180(%rsp),%rbx
  676a03:	00 
  676a04:	75 0e                	jne    676a14 <<gpui_canvas::text::planner::Planner>::shape+0x2974>
  676a06:	48 8d bc 24 80 01 00 	lea    0x180(%rsp),%rdi
  676a0d:	00 
  676a0e:	ff 15 3c 37 11 00    	call   *0x11373c(%rip)        # 78a150 <_DYNAMIC+0x4b0>
  676a14:	48 8b 84 24 88 01 00 	mov    0x188(%rsp),%rax
  676a1b:	00 
  676a1c:	48 8d 0c 5b          	lea    (%rbx,%rbx,2),%rcx
  676a20:	44 89 3c 88          	mov    %r15d,(%rax,%rcx,4)
  676a24:	0f 28 44 24 30       	movaps 0x30(%rsp),%xmm0
  676a29:	f3 0f 11 44 88 04    	movss  %xmm0,0x4(%rax,%rcx,4)
  676a2f:	c6 44 88 08 01       	movb   $0x1,0x8(%rax,%rcx,4)
  676a34:	48 ff c3             	inc    %rbx
  676a37:	48 89 9c 24 90 01 00 	mov    %rbx,0x190(%rsp)
  676a3e:	00 
  676a3f:	4c 39 f5             	cmp    %r14,%rbp
  676a42:	0f 85 50 fd ff ff    	jne    676798 <<gpui_canvas::text::planner::Planner>::shape+0x26f8>
  676a48:	40 b5 02             	mov    $0x2,%bpl
  676a4b:	48 3b 9c 24 80 01 00 	cmp    0x180(%rsp),%rbx
  676a52:	00 
  676a53:	0f 85 07 fd ff ff    	jne    676760 <<gpui_canvas::text::planner::Planner>::shape+0x26c0>
  676a59:	eb 1e                	jmp    676a79 <<gpui_canvas::text::planner::Planner>::shape+0x29d9>
  676a5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  676a60:	48 8b 9c 24 90 01 00 	mov    0x190(%rsp),%rbx
  676a67:	00 
  676a68:	40 b5 02             	mov    $0x2,%bpl
  676a6b:	48 3b 9c 24 80 01 00 	cmp    0x180(%rsp),%rbx
  676a72:	00 
  676a73:	0f 85 e7 fc ff ff    	jne    676760 <<gpui_canvas::text::planner::Planner>::shape+0x26c0>
  676a79:	48 8d bc 24 80 01 00 	lea    0x180(%rsp),%rdi
  676a80:	00 
  676a81:	ff 15 c9 36 11 00    	call   *0x1136c9(%rip)        # 78a150 <_DYNAMIC+0x4b0>
  676a87:	0f 28 84 24 00 01 00 	movaps 0x100(%rsp),%xmm0
  676a8e:	00 
  676a8f:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
  676a94:	e9 d4 fc ff ff       	jmp    67676d <<gpui_canvas::text::planner::Planner>::shape+0x26cd>
  676a99:	48 8b b4 24 10 07 00 	mov    0x710(%rsp),%rsi
  676aa0:	00 
  676aa1:	48 85 f6             	test   %rsi,%rsi
  676aa4:	74 17                	je     676abd <<gpui_canvas::text::planner::Planner>::shape+0x2a1d>
  676aa6:	48 8b bc 24 18 07 00 	mov    0x718(%rsp),%rdi
  676aad:	00 
  676aae:	48 c1 e6 03          	shl    $0x3,%rsi
  676ab2:	ba 08 00 00 00       	mov    $0x8,%edx
  676ab7:	ff 15 1b 34 11 00    	call   *0x11341b(%rip)        # 789ed8 <_DYNAMIC+0x238>
  676abd:	0f 28 9c 24 80 02 00 	movaps 0x280(%rsp),%xmm3
  676ac4:	00 
  676ac5:	0f 28 c3             	movaps %xmm3,%xmm0
  676ac8:	f3 0f 5f 84 24 d4 00 	maxss  0xd4(%rsp),%xmm0
  676acf:	00 00 
  676ad1:	0f 28 c8             	movaps %xmm0,%xmm1
  676ad4:	f3 0f c2 c8 03       	cmpunordss %xmm0,%xmm1
  676ad9:	0f 28 d1             	movaps %xmm1,%xmm2
  676adc:	0f 55 d0             	andnps %xmm0,%xmm2
  676adf:	0f 54 cb             	andps  %xmm3,%xmm1
  676ae2:	0f 56 ca             	orps   %xmm2,%xmm1
  676ae5:	0f 29 8c 24 80 02 00 	movaps %xmm1,0x280(%rsp)
  676aec:	00 
  676aed:	48 8b 04 24          	mov    (%rsp),%rax
  676af1:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
  676af7:	f3 0f 58 80 30 0a 00 	addss  0xa30(%rax),%xmm0
  676afe:	00 
  676aff:	f3 0f 11 44 24 1c    	movss  %xmm0,0x1c(%rsp)
  676b05:	80 7c 24 4c 00       	cmpb   $0x0,0x4c(%rsp)
  676b0a:	48 8b 84 24 20 03 00 	mov    0x320(%rsp),%rax
  676b11:	00 
  676b12:	8b b4 24 80 00 00 00 	mov    0x80(%rsp),%esi
  676b19:	48 8b 94 24 18 03 00 	mov    0x318(%rsp),%rdx
  676b20:	00 
  676b21:	0f 84 d1 db ff ff    	je     6746f8 <<gpui_canvas::text::planner::Planner>::shape+0x658>
  676b27:	e9 6c 05 00 00       	jmp    677098 <<gpui_canvas::text::planner::Planner>::shape+0x2ff8>
  676b2c:	48 8b 0c 24          	mov    (%rsp),%rcx
  676b30:	48 8b 81 d8 09 00 00 	mov    0x9d8(%rcx),%rax
  676b37:	48 6b 89 e0 09 00 00 	imul   $0x70,0x9e0(%rcx),%rcx
  676b3e:	70 
  676b3f:	48 01 c1             	add    %rax,%rcx
  676b42:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
  676b49:	00 
  676b4a:	48 89 8c 24 18 07 00 	mov    %rcx,0x718(%rsp)
  676b51:	00 
  676b52:	48 c7 84 24 20 07 00 	movq   $0x0,0x720(%rsp)
  676b59:	00 00 00 00 00 
  676b5e:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  676b63:	48 89 84 24 28 07 00 	mov    %rax,0x728(%rsp)
  676b6a:	00 
  676b6b:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  676b72:	00 
  676b73:	31 f6                	xor    %esi,%esi
  676b75:	48 8d 94 24 e7 00 00 	lea    0xe7(%rsp),%rdx
  676b7c:	00 
  676b7d:	e8 ee 70 00 00       	call   67dc70 <<core::iter::adapters::map::Map<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineData>>, <parley::layout::layout::Layout<()>>::lines::{closure#0}>, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#3}> as core::iter::traits::iterator::Iterator>::fold::<usize, <core::iter::adapters::flatten::FlattenCompat<_, _>>::iter_fold::flatten<core::iter::adapters::filter_map::FilterMap<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}>, <parley::layout::line::Line<()>>::runs::{closure#0}>, usize, <core::iter::adapters::flatten::FlattenCompat<_, _> as core::iter::traits::iterator::Iterator>::count::count<core::iter::adapters::filter_map::FilterMap<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}>, <parley::layout::line::Line<()>>::runs::{closure#0}>>>::{closure#0}>>
  676b82:	48 83 f8 02          	cmp    $0x2,%rax
  676b86:	0f 82 17 e2 ff ff    	jb     674da3 <<gpui_canvas::text::planner::Planner>::shape+0xd03>
  676b8c:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
  676b93:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  676b9a:	00 ff 
  676b9c:	0f 84 84 e1 ff ff    	je     674d26 <<gpui_canvas::text::planner::Planner>::shape+0xc86>
  676ba2:	e9 fc e1 ff ff       	jmp    674da3 <<gpui_canvas::text::planner::Planner>::shape+0xd03>
  676ba7:	c7 84 24 80 00 00 00 	movl   $0xffffffff,0x80(%rsp)
  676bae:	ff ff ff ff 
  676bb2:	e9 ac dd ff ff       	jmp    674963 <<gpui_canvas::text::planner::Planner>::shape+0x8c3>
  676bb7:	44 89 d2             	mov    %r10d,%edx
  676bba:	83 e2 1f             	and    $0x1f,%edx
  676bbd:	41 0f b6 79 01       	movzbl 0x1(%r9),%edi
  676bc2:	83 e7 3f             	and    $0x3f,%edi
  676bc5:	41 80 fa df          	cmp    $0xdf,%r10b
  676bc9:	76 31                	jbe    676bfc <<gpui_canvas::text::planner::Planner>::shape+0x2b5c>
  676bcb:	41 0f b6 71 02       	movzbl 0x2(%r9),%esi
  676bd0:	c1 e7 06             	shl    $0x6,%edi
  676bd3:	83 e6 3f             	and    $0x3f,%esi
  676bd6:	09 fe                	or     %edi,%esi
  676bd8:	41 80 fa f0          	cmp    $0xf0,%r10b
  676bdc:	72 2c                	jb     676c0a <<gpui_canvas::text::planner::Planner>::shape+0x2b6a>
  676bde:	49 8d 59 04          	lea    0x4(%r9),%rbx
  676be2:	45 0f b6 51 03       	movzbl 0x3(%r9),%r10d
  676be7:	83 e2 07             	and    $0x7,%edx
  676bea:	c1 e2 12             	shl    $0x12,%edx
  676bed:	c1 e6 06             	shl    $0x6,%esi
  676bf0:	41 83 e2 3f          	and    $0x3f,%r10d
  676bf4:	41 09 f2             	or     %esi,%r10d
  676bf7:	41 09 d2             	or     %edx,%r10d
  676bfa:	eb 1a                	jmp    676c16 <<gpui_canvas::text::planner::Planner>::shape+0x2b76>
  676bfc:	49 8d 59 02          	lea    0x2(%r9),%rbx
  676c00:	c1 e2 06             	shl    $0x6,%edx
  676c03:	09 fa                	or     %edi,%edx
  676c05:	41 89 d2             	mov    %edx,%r10d
  676c08:	eb 0c                	jmp    676c16 <<gpui_canvas::text::planner::Planner>::shape+0x2b76>
  676c0a:	49 8d 59 03          	lea    0x3(%r9),%rbx
  676c0e:	c1 e2 0c             	shl    $0xc,%edx
  676c11:	09 d6                	or     %edx,%esi
  676c13:	41 89 f2             	mov    %esi,%r10d
  676c16:	49 8d 50 02          	lea    0x2(%r8),%rdx
  676c1a:	4c 89 c1             	mov    %r8,%rcx
  676c1d:	48 89 c6             	mov    %rax,%rsi
  676c20:	4c 29 ce             	sub    %r9,%rsi
  676c23:	48 01 de             	add    %rbx,%rsi
  676c26:	41 83 fa 0a          	cmp    $0xa,%r10d
  676c2a:	bf fe ff ff ff       	mov    $0xfffffffe,%edi
  676c2f:	44 0f 44 d7          	cmove  %edi,%r10d
  676c33:	44 89 94 24 80 00 00 	mov    %r10d,0x80(%rsp)
  676c3a:	00 
  676c3b:	4c 0f 44 da          	cmove  %rdx,%r11
  676c3f:	c7 44 24 4c 00 00 00 	movl   $0x0,0x4c(%rsp)
  676c46:	00 
  676c47:	48 89 84 24 10 03 00 	mov    %rax,0x310(%rsp)
  676c4e:	00 
  676c4f:	48 89 f0             	mov    %rsi,%rax
  676c52:	4c 89 de             	mov    %r11,%rsi
  676c55:	48 89 5c 24 28       	mov    %rbx,0x28(%rsp)
  676c5a:	e9 0f dd ff ff       	jmp    67496e <<gpui_canvas::text::planner::Planner>::shape+0x8ce>
  676c5f:	b9 04 00 00 00       	mov    $0x4,%ecx
  676c64:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  676c6a:	48 8d bc 24 e8 00 00 	lea    0xe8(%rsp),%rdi
  676c71:	00 
  676c72:	48 89 da             	mov    %rbx,%rdx
  676c75:	e8 86 d1 fe ff       	call   663e00 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  676c7a:	e9 88 e2 ff ff       	jmp    674f07 <<gpui_canvas::text::planner::Planner>::shape+0xe67>
  676c7f:	c7 84 24 90 00 00 00 	movl   $0x7,0x90(%rsp)
  676c86:	07 00 00 00 
  676c8a:	eb 0b                	jmp    676c97 <<gpui_canvas::text::planner::Planner>::shape+0x2bf7>
  676c8c:	c7 84 24 90 00 00 00 	movl   $0x4,0x90(%rsp)
  676c93:	04 00 00 00 
  676c97:	48 c7 84 24 88 00 00 	movq   $0xffffffffffffffff,0x88(%rsp)
  676c9e:	00 ff ff ff ff 
  676ca3:	4c 8b 2c 24          	mov    (%rsp),%r13
  676ca7:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
  676cae:	00 
  676caf:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  676cb3:	74 76                	je     676d2b <<gpui_canvas::text::planner::Planner>::shape+0x2c8b>
  676cb5:	48 85 c0             	test   %rax,%rax
  676cb8:	74 1b                	je     676cd5 <<gpui_canvas::text::planner::Planner>::shape+0x2c35>
  676cba:	48 8b bc 24 58 01 00 	mov    0x158(%rsp),%rdi
  676cc1:	00 
  676cc2:	48 c1 e0 03          	shl    $0x3,%rax
  676cc6:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  676cca:	ba 04 00 00 00       	mov    $0x4,%edx
  676ccf:	ff 15 03 32 11 00    	call   *0x113203(%rip)        # 789ed8 <_DYNAMIC+0x238>
  676cd5:	48 8b 84 24 68 01 00 	mov    0x168(%rsp),%rax
  676cdc:	00 
  676cdd:	48 85 c0             	test   %rax,%rax
  676ce0:	74 1b                	je     676cfd <<gpui_canvas::text::planner::Planner>::shape+0x2c5d>
  676ce2:	48 8b bc 24 70 01 00 	mov    0x170(%rsp),%rdi
  676ce9:	00 
  676cea:	48 c1 e0 03          	shl    $0x3,%rax
  676cee:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  676cf2:	ba 04 00 00 00       	mov    $0x4,%edx
  676cf7:	ff 15 db 31 11 00    	call   *0x1131db(%rip)        # 789ed8 <_DYNAMIC+0x238>
  676cfd:	48 8b 84 24 80 01 00 	mov    0x180(%rsp),%rax
  676d04:	00 
  676d05:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  676d09:	74 20                	je     676d2b <<gpui_canvas::text::planner::Planner>::shape+0x2c8b>
  676d0b:	48 85 c0             	test   %rax,%rax
  676d0e:	74 1b                	je     676d2b <<gpui_canvas::text::planner::Planner>::shape+0x2c8b>
  676d10:	48 8b bc 24 88 01 00 	mov    0x188(%rsp),%rdi
  676d17:	00 
  676d18:	48 c1 e0 02          	shl    $0x2,%rax
  676d1c:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  676d20:	ba 04 00 00 00       	mov    $0x4,%edx
  676d25:	ff 15 ad 31 11 00    	call   *0x1131ad(%rip)        # 789ed8 <_DYNAMIC+0x238>
  676d2b:	48 8b b4 24 e8 00 00 	mov    0xe8(%rsp),%rsi
  676d32:	00 
  676d33:	48 85 f6             	test   %rsi,%rsi
  676d36:	74 17                	je     676d4f <<gpui_canvas::text::planner::Planner>::shape+0x2caf>
  676d38:	48 8b bc 24 f0 00 00 	mov    0xf0(%rsp),%rdi
  676d3f:	00 
  676d40:	48 c1 e6 04          	shl    $0x4,%rsi
  676d44:	ba 04 00 00 00       	mov    $0x4,%edx
  676d49:	ff 15 89 31 11 00    	call   *0x113189(%rip)        # 789ed8 <_DYNAMIC+0x238>
  676d4f:	48 8b b4 24 a0 02 00 	mov    0x2a0(%rsp),%rsi
  676d56:	00 
  676d57:	48 83 fe fd          	cmp    $0xfffffffffffffffd,%rsi
  676d5b:	77 18                	ja     676d75 <<gpui_canvas::text::planner::Planner>::shape+0x2cd5>
  676d5d:	48 85 f6             	test   %rsi,%rsi
  676d60:	74 13                	je     676d75 <<gpui_canvas::text::planner::Planner>::shape+0x2cd5>
  676d62:	48 8b bc 24 a8 02 00 	mov    0x2a8(%rsp),%rdi
  676d69:	00 
  676d6a:	ba 01 00 00 00       	mov    $0x1,%edx
  676d6f:	ff 15 63 31 11 00    	call   *0x113163(%rip)        # 789ed8 <_DYNAMIC+0x238>
  676d75:	48 8b b4 24 b8 02 00 	mov    0x2b8(%rsp),%rsi
  676d7c:	00 
  676d7d:	48 83 fe fd          	cmp    $0xfffffffffffffffd,%rsi
  676d81:	77 18                	ja     676d9b <<gpui_canvas::text::planner::Planner>::shape+0x2cfb>
  676d83:	48 85 f6             	test   %rsi,%rsi
  676d86:	74 13                	je     676d9b <<gpui_canvas::text::planner::Planner>::shape+0x2cfb>
  676d88:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
  676d8f:	00 
  676d90:	ba 01 00 00 00       	mov    $0x1,%edx
  676d95:	ff 15 3d 31 11 00    	call   *0x11313d(%rip)        # 789ed8 <_DYNAMIC+0x238>
  676d9b:	48 8b b4 24 d0 02 00 	mov    0x2d0(%rsp),%rsi
  676da2:	00 
  676da3:	48 83 fe fd          	cmp    $0xfffffffffffffffd,%rsi
  676da7:	77 18                	ja     676dc1 <<gpui_canvas::text::planner::Planner>::shape+0x2d21>
  676da9:	48 85 f6             	test   %rsi,%rsi
  676dac:	74 13                	je     676dc1 <<gpui_canvas::text::planner::Planner>::shape+0x2d21>
  676dae:	48 8b bc 24 d8 02 00 	mov    0x2d8(%rsp),%rdi
  676db5:	00 
  676db6:	ba 01 00 00 00       	mov    $0x1,%edx
  676dbb:	ff 15 17 31 11 00    	call   *0x113117(%rip)        # 789ed8 <_DYNAMIC+0x238>
  676dc1:	49 8d bd c8 08 00 00 	lea    0x8c8(%r13),%rdi
  676dc8:	e8 33 b7 ff ff       	call   672500 <core::ptr::drop_glue::<parley::layout::layout::Layout<()>>>
  676dcd:	49 c7 85 c8 08 00 00 	movq   $0x0,0x8c8(%r13)
  676dd4:	00 00 00 00 
  676dd8:	49 c7 85 d0 08 00 00 	movq   $0x4,0x8d0(%r13)
  676ddf:	04 00 00 00 
  676de3:	0f 57 c0             	xorps  %xmm0,%xmm0
  676de6:	41 0f 11 85 d8 08 00 	movups %xmm0,0x8d8(%r13)
  676ded:	00 
  676dee:	49 c7 85 e8 08 00 00 	movq   $0x4,0x8e8(%r13)
  676df5:	04 00 00 00 
  676df9:	41 0f 11 85 f0 08 00 	movups %xmm0,0x8f0(%r13)
  676e00:	00 
  676e01:	49 c7 85 00 09 00 00 	movq   $0x8,0x900(%r13)
  676e08:	08 00 00 00 
  676e0c:	41 0f 11 85 08 09 00 	movups %xmm0,0x908(%r13)
  676e13:	00 
  676e14:	49 c7 85 18 09 00 00 	movq   $0x8,0x918(%r13)
  676e1b:	08 00 00 00 
  676e1f:	41 0f 11 85 20 09 00 	movups %xmm0,0x920(%r13)
  676e26:	00 
  676e27:	49 c7 85 30 09 00 00 	movq   $0x4,0x930(%r13)
  676e2e:	04 00 00 00 
  676e32:	41 0f 11 85 38 09 00 	movups %xmm0,0x938(%r13)
  676e39:	00 
  676e3a:	49 c7 85 48 09 00 00 	movq   $0x4,0x948(%r13)
  676e41:	04 00 00 00 
  676e45:	41 0f 11 85 50 09 00 	movups %xmm0,0x950(%r13)
  676e4c:	00 
  676e4d:	49 c7 85 60 09 00 00 	movq   $0x4,0x960(%r13)
  676e54:	04 00 00 00 
  676e58:	41 0f 11 85 68 09 00 	movups %xmm0,0x968(%r13)
  676e5f:	00 
  676e60:	49 c7 85 78 09 00 00 	movq   $0x8,0x978(%r13)
  676e67:	08 00 00 00 
  676e6b:	41 0f 11 85 80 09 00 	movups %xmm0,0x980(%r13)
  676e72:	00 
  676e73:	49 c7 85 90 09 00 00 	movq   $0x2,0x990(%r13)
  676e7a:	02 00 00 00 
  676e7e:	41 0f 11 85 98 09 00 	movups %xmm0,0x998(%r13)
  676e85:	00 
  676e86:	49 c7 85 a8 09 00 00 	movq   $0x4,0x9a8(%r13)
  676e8d:	04 00 00 00 
  676e91:	41 0f 11 85 b0 09 00 	movups %xmm0,0x9b0(%r13)
  676e98:	00 
  676e99:	49 c7 85 c0 09 00 00 	movq   $0x8,0x9c0(%r13)
  676ea0:	08 00 00 00 
  676ea4:	41 0f 11 85 c8 09 00 	movups %xmm0,0x9c8(%r13)
  676eab:	00 
  676eac:	49 c7 85 d8 09 00 00 	movq   $0x8,0x9d8(%r13)
  676eb3:	08 00 00 00 
  676eb7:	41 0f 11 85 e0 09 00 	movups %xmm0,0x9e0(%r13)
  676ebe:	00 
  676ebf:	49 c7 85 f0 09 00 00 	movq   $0x8,0x9f0(%r13)
  676ec6:	08 00 00 00 
  676eca:	41 0f 11 85 f8 09 00 	movups %xmm0,0x9f8(%r13)
  676ed1:	00 
  676ed2:	49 c7 85 08 0a 00 00 	movq   $0x4,0xa08(%r13)
  676ed9:	04 00 00 00 
  676edd:	41 0f 11 85 10 0a 00 	movups %xmm0,0xa10(%r13)
  676ee4:	00 
  676ee5:	41 c7 85 20 0a 00 00 	movl   $0x3f800000,0xa20(%r13)
  676eec:	00 00 80 3f 
  676ef0:	41 0f 11 85 24 0a 00 	movups %xmm0,0xa24(%r13)
  676ef7:	00 
  676ef8:	49 c7 85 32 0a 00 00 	movq   $0x0,0xa32(%r13)
  676eff:	00 00 00 00 
  676f03:	66 41 c7 85 3a 0a 00 	movw   $0xff01,0xa3a(%r13)
  676f0a:	00 01 ff 
  676f0d:	41 c6 85 3c 0a 00 00 	movb   $0x0,0xa3c(%r13)
  676f14:	00 
  676f15:	48 8b 8c 24 b8 00 00 	mov    0xb8(%rsp),%rcx
  676f1c:	00 
  676f1d:	48 8b 84 24 38 03 00 	mov    0x338(%rsp),%rax
  676f24:	00 
  676f25:	48 89 48 30          	mov    %rcx,0x30(%rax)
  676f29:	0f 10 84 24 88 00 00 	movups 0x88(%rsp),%xmm0
  676f30:	00 
  676f31:	0f 10 8c 24 98 00 00 	movups 0x98(%rsp),%xmm1
  676f38:	00 
  676f39:	0f 10 94 24 a8 00 00 	movups 0xa8(%rsp),%xmm2
  676f40:	00 
  676f41:	0f 11 50 20          	movups %xmm2,0x20(%rax)
  676f45:	0f 11 48 10          	movups %xmm1,0x10(%rax)
  676f49:	0f 11 00             	movups %xmm0,(%rax)
  676f4c:	48 81 c4 e8 11 00 00 	add    $0x11e8,%rsp
  676f53:	5b                   	pop    %rbx
  676f54:	41 5c                	pop    %r12
  676f56:	41 5d                	pop    %r13
  676f58:	41 5e                	pop    %r14
  676f5a:	41 5f                	pop    %r15
  676f5c:	5d                   	pop    %rbp
  676f5d:	c3                   	ret
  676f5e:	48 8d 35 c3 5f 11 00 	lea    0x115fc3(%rip),%rsi        # 78cf28 <gpui_canvas::text::HEBREW_FONT>
  676f65:	48 8d 15 d8 96 9e ff 	lea    -0x616928(%rip),%rdx        # 60644 <gpui_canvas::text::HEBREW_BYTES>
  676f6c:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  676f73:	00 
  676f74:	b9 14 69 00 00       	mov    $0x6914,%ecx
  676f79:	45 31 c0             	xor    %r8d,%r8d
  676f7c:	e8 0f cf fe ff       	call   663e90 <<gpui_canvas::text::FontFace>::shared_static>
  676f81:	80 bc 24 10 07 00 00 	cmpb   $0x0,0x710(%rsp)
  676f88:	00 
  676f89:	0f 85 02 d5 ff ff    	jne    674491 <<gpui_canvas::text::planner::Planner>::shape+0x3f1>
  676f8f:	44 89 fd             	mov    %r15d,%ebp
  676f92:	49 8d 9d 50 0a 00 00 	lea    0xa50(%r13),%rbx
  676f99:	4c 8b bc 24 18 07 00 	mov    0x718(%rsp),%r15
  676fa0:	00 
  676fa1:	48 8b 03             	mov    (%rbx),%rax
  676fa4:	48 85 c0             	test   %rax,%rax
  676fa7:	74 0f                	je     676fb8 <<gpui_canvas::text::planner::Planner>::shape+0x2f18>
  676fa9:	f0 48 ff 08          	lock decq (%rax)
  676fad:	75 09                	jne    676fb8 <<gpui_canvas::text::planner::Planner>::shape+0x2f18>
  676faf:	48 89 df             	mov    %rbx,%rdi
  676fb2:	ff 15 48 2f 11 00    	call   *0x112f48(%rip)        # 789f00 <_DYNAMIC+0x260>
  676fb8:	4d 89 bd 50 0a 00 00 	mov    %r15,0xa50(%r13)
  676fbf:	be 02 00 00 00       	mov    $0x2,%esi
  676fc4:	4c 89 ef             	mov    %r13,%rdi
  676fc7:	e8 a4 0b 00 00       	call   677b70 <<gpui_canvas::text::planner::Planner>::register>
  676fcc:	83 f8 ff             	cmp    $0xffffffff,%eax
  676fcf:	41 89 ef             	mov    %ebp,%r15d
  676fd2:	0f 85 18 d5 ff ff    	jne    6744f0 <<gpui_canvas::text::planner::Planner>::shape+0x450>
  676fd8:	e9 52 d5 ff ff       	jmp    67452f <<gpui_canvas::text::planner::Planner>::shape+0x48f>
  676fdd:	48 8b b4 24 10 07 00 	mov    0x710(%rsp),%rsi
  676fe4:	00 
  676fe5:	48 85 f6             	test   %rsi,%rsi
  676fe8:	74 17                	je     677001 <<gpui_canvas::text::planner::Planner>::shape+0x2f61>
  676fea:	48 8b bc 24 18 07 00 	mov    0x718(%rsp),%rdi
  676ff1:	00 
  676ff2:	48 c1 e6 03          	shl    $0x3,%rsi
  676ff6:	ba 08 00 00 00       	mov    $0x8,%edx
  676ffb:	ff 15 d7 2e 11 00    	call   *0x112ed7(%rip)        # 789ed8 <_DYNAMIC+0x238>
  677001:	b8 01 00 00 00       	mov    $0x1,%eax
  677006:	4c 8b 2c 24          	mov    (%rsp),%r13
  67700a:	89 84 24 90 00 00 00 	mov    %eax,0x90(%rsp)
  677011:	89 94 24 94 00 00 00 	mov    %edx,0x94(%rsp)
  677018:	48 c7 84 24 88 00 00 	movq   $0xffffffffffffffff,0x88(%rsp)
  67701f:	00 ff ff ff ff 
  677024:	e9 7e fc ff ff       	jmp    676ca7 <<gpui_canvas::text::planner::Planner>::shape+0x2c07>
  677029:	c7 84 24 90 00 00 00 	movl   $0x3,0x90(%rsp)
  677030:	03 00 00 00 
  677034:	e9 5e fc ff ff       	jmp    676c97 <<gpui_canvas::text::planner::Planner>::shape+0x2bf7>
  677039:	48 c7 84 24 90 00 00 	movq   $0x3,0x90(%rsp)
  677040:	00 03 00 00 00 
  677045:	e9 4d fc ff ff       	jmp    676c97 <<gpui_canvas::text::planner::Planner>::shape+0x2bf7>
  67704a:	c7 84 24 90 00 00 00 	movl   $0x1,0x90(%rsp)
  677051:	01 00 00 00 
  677055:	e9 3d fc ff ff       	jmp    676c97 <<gpui_canvas::text::planner::Planner>::shape+0x2bf7>
  67705a:	c7 84 24 90 00 00 00 	movl   $0x3,0x90(%rsp)
  677061:	03 00 00 00 
  677065:	8b 84 24 18 02 00 00 	mov    0x218(%rsp),%eax
  67706c:	89 84 24 94 00 00 00 	mov    %eax,0x94(%rsp)
  677073:	e9 1f fc ff ff       	jmp    676c97 <<gpui_canvas::text::planner::Planner>::shape+0x2bf7>
  677078:	48 c7 84 24 90 00 00 	movq   $0xc,0x90(%rsp)
  67707f:	00 0c 00 00 00 
  677084:	48 c7 84 24 88 00 00 	movq   $0xffffffffffffffff,0x88(%rsp)
  67708b:	00 ff ff ff ff 
  677090:	49 89 f5             	mov    %rsi,%r13
  677093:	e9 0f fc ff ff       	jmp    676ca7 <<gpui_canvas::text::planner::Planner>::shape+0x2c07>
  677098:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  67709f:	00 ff 
  6770a1:	4c 8b 2c 24          	mov    (%rsp),%r13
  6770a5:	0f 84 4a 01 00 00    	je     6771f5 <<gpui_canvas::text::planner::Planner>::shape+0x3155>
  6770ab:	48 8b 84 24 80 01 00 	mov    0x180(%rsp),%rax
  6770b2:	00 
  6770b3:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6770b7:	0f 84 1b 03 00 00    	je     6773d8 <<gpui_canvas::text::planner::Planner>::shape+0x3338>
  6770bd:	48 8b b4 24 90 01 00 	mov    0x190(%rsp),%rsi
  6770c4:	00 
  6770c5:	48 39 f0             	cmp    %rsi,%rax
  6770c8:	0f 86 0a 03 00 00    	jbe    6773d8 <<gpui_canvas::text::planner::Planner>::shape+0x3338>
  6770ce:	48 8d bc 24 80 01 00 	lea    0x180(%rsp),%rdi
  6770d5:	00 
  6770d6:	e8 e5 0c 00 00       	call   677dc0 <<alloc::raw_vec::RawVecInner>::shrink>
  6770db:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6770df:	0f 84 f3 02 00 00    	je     6773d8 <<gpui_canvas::text::planner::Planner>::shape+0x3338>
  6770e5:	48 89 c7             	mov    %rax,%rdi
  6770e8:	48 89 d6             	mov    %rdx,%rsi
  6770eb:	ff 15 ff 2e 11 00    	call   *0x112eff(%rip)        # 789ff0 <_DYNAMIC+0x350>
  6770f1:	e9 25 06 00 00       	jmp    67771b <<gpui_canvas::text::planner::Planner>::shape+0x367b>
  6770f6:	4c 8b 2c 24          	mov    (%rsp),%r13
  6770fa:	eb 25                	jmp    677121 <<gpui_canvas::text::planner::Planner>::shape+0x3081>
  6770fc:	c7 44 24 0c 00 00 00 	movl   $0x0,0xc(%rsp)
  677103:	00 
  677104:	4c 8b 8c 24 f8 02 00 	mov    0x2f8(%rsp),%r9
  67710b:	00 
  67710c:	4d 85 c9             	test   %r9,%r9
  67710f:	74 23                	je     677134 <<gpui_canvas::text::planner::Planner>::shape+0x3094>
  677111:	4c 8b 2c 24          	mov    (%rsp),%r13
  677115:	48 8b 8c 24 10 01 00 	mov    0x110(%rsp),%rcx
  67711c:	00 
  67711d:	8b 54 24 0c          	mov    0xc(%rsp),%edx
  677121:	49 39 c9             	cmp    %rcx,%r9
  677124:	73 23                	jae    677149 <<gpui_canvas::text::planner::Planner>::shape+0x30a9>
  677126:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  67712b:	42 80 3c 08 bf       	cmpb   $0xbf,(%rax,%r9,1)
  677130:	7f 1c                	jg     67714e <<gpui_canvas::text::planner::Planner>::shape+0x30ae>
  677132:	eb 4c                	jmp    677180 <<gpui_canvas::text::planner::Planner>::shape+0x30e0>
  677134:	45 31 c9             	xor    %r9d,%r9d
  677137:	4c 8b 2c 24          	mov    (%rsp),%r13
  67713b:	48 8b 8c 24 10 01 00 	mov    0x110(%rsp),%rcx
  677142:	00 
  677143:	8b 54 24 0c          	mov    0xc(%rsp),%edx
  677147:	eb 05                	jmp    67714e <<gpui_canvas::text::planner::Planner>::shape+0x30ae>
  677149:	49 89 c9             	mov    %rcx,%r9
  67714c:	75 32                	jne    677180 <<gpui_canvas::text::planner::Planner>::shape+0x30e0>
  67714e:	84 d2                	test   %dl,%dl
  677150:	74 1a                	je     67716c <<gpui_canvas::text::planner::Planner>::shape+0x30cc>
  677152:	4c 39 cd             	cmp    %r9,%rbp
  677155:	74 29                	je     677180 <<gpui_canvas::text::planner::Planner>::shape+0x30e0>
  677157:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
  67715c:	43 0f b6 0c 08       	movzbl (%r8,%r9,1),%ecx
  677161:	84 c9                	test   %cl,%cl
  677163:	78 44                	js     6771a9 <<gpui_canvas::text::planner::Planner>::shape+0x3109>
  677165:	b8 0b 00 00 00       	mov    $0xb,%eax
  67716a:	eb 1e                	jmp    67718a <<gpui_canvas::text::planner::Planner>::shape+0x30ea>
  67716c:	48 39 cd             	cmp    %rcx,%rbp
  67716f:	73 0d                	jae    67717e <<gpui_canvas::text::planner::Planner>::shape+0x30de>
  677171:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  677176:	80 3c 28 bf          	cmpb   $0xbf,(%rax,%rbp,1)
  67717a:	7f d6                	jg     677152 <<gpui_canvas::text::planner::Planner>::shape+0x30b2>
  67717c:	eb 02                	jmp    677180 <<gpui_canvas::text::planner::Planner>::shape+0x30e0>
  67717e:	74 d2                	je     677152 <<gpui_canvas::text::planner::Planner>::shape+0x30b2>
  677180:	b8 03 00 00 00       	mov    $0x3,%eax
  677185:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
  67718a:	89 84 24 90 00 00 00 	mov    %eax,0x90(%rsp)
  677191:	89 8c 24 94 00 00 00 	mov    %ecx,0x94(%rsp)
  677198:	48 c7 84 24 88 00 00 	movq   $0xffffffffffffffff,0x88(%rsp)
  67719f:	00 ff ff ff ff 
  6771a4:	e9 fe fa ff ff       	jmp    676ca7 <<gpui_canvas::text::planner::Planner>::shape+0x2c07>
  6771a9:	89 ca                	mov    %ecx,%edx
  6771ab:	83 e2 1f             	and    $0x1f,%edx
  6771ae:	43 0f b6 7c 08 01    	movzbl 0x1(%r8,%r9,1),%edi
  6771b4:	83 e7 3f             	and    $0x3f,%edi
  6771b7:	b8 0b 00 00 00       	mov    $0xb,%eax
  6771bc:	80 f9 df             	cmp    $0xdf,%cl
  6771bf:	76 2b                	jbe    6771ec <<gpui_canvas::text::planner::Planner>::shape+0x314c>
  6771c1:	43 0f b6 74 08 02    	movzbl 0x2(%r8,%r9,1),%esi
  6771c7:	c1 e7 06             	shl    $0x6,%edi
  6771ca:	83 e6 3f             	and    $0x3f,%esi
  6771cd:	09 fe                	or     %edi,%esi
  6771cf:	80 f9 f0             	cmp    $0xf0,%cl
  6771d2:	72 7a                	jb     67724e <<gpui_canvas::text::planner::Planner>::shape+0x31ae>
  6771d4:	43 0f b6 4c 08 03    	movzbl 0x3(%r8,%r9,1),%ecx
  6771da:	83 e2 07             	and    $0x7,%edx
  6771dd:	c1 e2 12             	shl    $0x12,%edx
  6771e0:	c1 e6 06             	shl    $0x6,%esi
  6771e3:	83 e1 3f             	and    $0x3f,%ecx
  6771e6:	09 f1                	or     %esi,%ecx
  6771e8:	09 d1                	or     %edx,%ecx
  6771ea:	eb 9e                	jmp    67718a <<gpui_canvas::text::planner::Planner>::shape+0x30ea>
  6771ec:	c1 e2 06             	shl    $0x6,%edx
  6771ef:	09 fa                	or     %edi,%edx
  6771f1:	89 d1                	mov    %edx,%ecx
  6771f3:	eb 95                	jmp    67718a <<gpui_canvas::text::planner::Planner>::shape+0x30ea>
  6771f5:	48 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%rax
  6771fc:	00 
  6771fd:	48 85 c0             	test   %rax,%rax
  677200:	0f 84 b6 00 00 00    	je     6772bc <<gpui_canvas::text::planner::Planner>::shape+0x321c>
  677206:	48 8b 8c 24 f0 00 00 	mov    0xf0(%rsp),%rcx
  67720d:	00 
  67720e:	48 c1 e0 04          	shl    $0x4,%rax
  677212:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
  677217:	2b 54 01 f0          	sub    -0x10(%rcx,%rax,1),%edx
  67721b:	0f 83 a8 00 00 00    	jae    6772c9 <<gpui_canvas::text::planner::Planner>::shape+0x3229>
  677221:	c7 84 24 90 00 00 00 	movl   $0x3,0x90(%rsp)
  677228:	03 00 00 00 
  67722c:	48 c7 84 24 88 00 00 	movq   $0xffffffffffffffff,0x88(%rsp)
  677233:	00 ff ff ff ff 
  677238:	48 8b b4 24 e8 00 00 	mov    0xe8(%rsp),%rsi
  67723f:	00 
  677240:	48 85 f6             	test   %rsi,%rsi
  677243:	0f 85 ef fa ff ff    	jne    676d38 <<gpui_canvas::text::planner::Planner>::shape+0x2c98>
  677249:	e9 01 fb ff ff       	jmp    676d4f <<gpui_canvas::text::planner::Planner>::shape+0x2caf>
  67724e:	c1 e2 0c             	shl    $0xc,%edx
  677251:	09 d6                	or     %edx,%esi
  677253:	89 f1                	mov    %esi,%ecx
  677255:	e9 30 ff ff ff       	jmp    67718a <<gpui_canvas::text::planner::Planner>::shape+0x30ea>
  67725a:	48 8d 3d c3 71 be ff 	lea    -0x418e3d(%rip),%rdi        # 25e424 <anon.d7ce62ce2e7b4c41dc536f409ba3a6d7.4.llvm.17812702614352144307>
  677261:	48 8d 15 b8 93 10 00 	lea    0x1093b8(%rip),%rdx        # 780620 <anon.d7ce62ce2e7b4c41dc536f409ba3a6d7.5.llvm.17812702614352144307>
  677268:	be ad 00 00 00       	mov    $0xad,%esi
  67726d:	ff 15 5d 2d 11 00    	call   *0x112d5d(%rip)        # 789fd0 <_DYNAMIC+0x330>
  677273:	e9 a3 04 00 00       	jmp    67771b <<gpui_canvas::text::planner::Planner>::shape+0x367b>
  677278:	48 8d 0d 29 86 10 00 	lea    0x108629(%rip),%rcx        # 77f8a8 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0x80>
  67727f:	48 89 df             	mov    %rbx,%rdi
  677282:	48 8b 94 24 40 01 00 	mov    0x140(%rsp),%rdx
  677289:	00 
  67728a:	ff 15 70 2f 11 00    	call   *0x112f70(%rip)        # 78a200 <_DYNAMIC+0x560>
  677290:	e9 86 04 00 00       	jmp    67771b <<gpui_canvas::text::planner::Planner>::shape+0x367b>
  677295:	41 bc 03 00 00 00    	mov    $0x3,%r12d
  67729b:	8b 44 24 08          	mov    0x8(%rsp),%eax
  67729f:	41 89 c7             	mov    %eax,%r15d
  6772a2:	e9 4f d2 ff ff       	jmp    6744f6 <<gpui_canvas::text::planner::Planner>::shape+0x456>
  6772a7:	41 bc 03 00 00 00    	mov    $0x3,%r12d
  6772ad:	8b 84 24 d0 01 00 00 	mov    0x1d0(%rsp),%eax
  6772b4:	41 89 c7             	mov    %eax,%r15d
  6772b7:	e9 3a d2 ff ff       	jmp    6744f6 <<gpui_canvas::text::planner::Planner>::shape+0x456>
  6772bc:	48 83 7c 24 50 00    	cmpq   $0x0,0x50(%rsp)
  6772c2:	75 11                	jne    6772d5 <<gpui_canvas::text::planner::Planner>::shape+0x3235>
  6772c4:	e9 0f 01 00 00       	jmp    6773d8 <<gpui_canvas::text::planner::Planner>::shape+0x3338>
  6772c9:	81 fa ff 00 00 00    	cmp    $0xff,%edx
  6772cf:	0f 86 b1 02 00 00    	jbe    677586 <<gpui_canvas::text::planner::Planner>::shape+0x34e6>
  6772d5:	bf 04 00 00 00       	mov    $0x4,%edi
  6772da:	be 18 00 00 00       	mov    $0x18,%esi
  6772df:	e8 ac 0d 00 00       	call   678090 <alloc::boxed::box_new_uninit>
  6772e4:	48 89 c3             	mov    %rax,%rbx
  6772e7:	8b 84 24 f8 00 00 00 	mov    0xf8(%rsp),%eax
  6772ee:	c7 03 00 00 00 00    	movl   $0x0,(%rbx)
  6772f4:	4c 8b 7c 24 50       	mov    0x50(%rsp),%r15
  6772f9:	44 89 7b 04          	mov    %r15d,0x4(%rbx)
  6772fd:	c7 43 08 00 00 00 00 	movl   $0x0,0x8(%rbx)
  677304:	89 43 0c             	mov    %eax,0xc(%rbx)
  677307:	c7 43 10 00 00 00 00 	movl   $0x0,0x10(%rbx)
  67730e:	66 c7 43 14 00 00    	movw   $0x0,0x14(%rbx)
  677314:	bf 04 00 00 00       	mov    $0x4,%edi
  677319:	be 18 00 00 00       	mov    $0x18,%esi
  67731e:	e8 6d 0d 00 00       	call   678090 <alloc::boxed::box_new_uninit>
  677323:	49 89 c6             	mov    %rax,%r14
  677326:	c7 00 00 00 00 00    	movl   $0x0,(%rax)
  67732c:	44 89 78 04          	mov    %r15d,0x4(%rax)
  677330:	c7 40 08 00 00 00 00 	movl   $0x0,0x8(%rax)
  677337:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
  67733d:	f3 0f 11 40 0c       	movss  %xmm0,0xc(%rax)
  677342:	f3 0f 10 44 24 7c    	movss  0x7c(%rsp),%xmm0
  677348:	f3 0f 11 40 10       	movss  %xmm0,0x10(%rax)
  67734d:	0f 28 84 24 80 02 00 	movaps 0x280(%rsp),%xmm0
  677354:	00 
  677355:	f3 0f 11 40 14       	movss  %xmm0,0x14(%rax)
  67735a:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  677361:	00 ff 
  677363:	74 0d                	je     677372 <<gpui_canvas::text::planner::Planner>::shape+0x32d2>
  677365:	48 8d bc 24 50 01 00 	lea    0x150(%rsp),%rdi
  67736c:	00 
  67736d:	e8 be c2 ff ff       	call   673630 <core::ptr::drop_glue::<gpui_canvas::text::layout::TextGeometry>>
  677372:	48 c7 84 24 50 01 00 	movq   $0x1,0x150(%rsp)
  677379:	00 01 00 00 00 
  67737e:	48 89 9c 24 58 01 00 	mov    %rbx,0x158(%rsp)
  677385:	00 
  677386:	48 c7 84 24 60 01 00 	movq   $0x1,0x160(%rsp)
  67738d:	00 01 00 00 00 
  677392:	48 c7 84 24 68 01 00 	movq   $0x1,0x168(%rsp)
  677399:	00 01 00 00 00 
  67739e:	4c 89 b4 24 70 01 00 	mov    %r14,0x170(%rsp)
  6773a5:	00 
  6773a6:	48 c7 84 24 78 01 00 	movq   $0x1,0x178(%rsp)
  6773ad:	00 01 00 00 00 
  6773b2:	48 c7 84 24 80 01 00 	movq   $0xffffffffffffffff,0x180(%rsp)
  6773b9:	00 ff ff ff ff 
  6773be:	44 89 bc 24 98 01 00 	mov    %r15d,0x198(%rsp)
  6773c5:	00 
  6773c6:	f3 0f 10 84 24 84 00 	movss  0x84(%rsp),%xmm0
  6773cd:	00 00 
  6773cf:	f3 0f 11 84 24 9c 01 	movss  %xmm0,0x19c(%rsp)
  6773d6:	00 00 
  6773d8:	4c 8b bc 24 e8 00 00 	mov    0xe8(%rsp),%r15
  6773df:	00 
  6773e0:	48 8b 9c 24 f0 00 00 	mov    0xf0(%rsp),%rbx
  6773e7:	00 
  6773e8:	4c 8b b4 24 f8 00 00 	mov    0xf8(%rsp),%r14
  6773ef:	00 
  6773f0:	4c 89 ef             	mov    %r13,%rdi
  6773f3:	48 8b b4 24 08 02 00 	mov    0x208(%rsp),%rsi
  6773fa:	00 
  6773fb:	e8 30 06 00 00       	call   677a30 <<gpui_canvas::text::planner::Planner>::font_set>
  677400:	49 89 c4             	mov    %rax,%r12
  677403:	48 89 84 24 c0 04 00 	mov    %rax,0x4c0(%rsp)
  67740a:	00 
  67740b:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
  677412:	00 
  677413:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  677417:	0f 84 c7 00 00 00    	je     6774e4 <<gpui_canvas::text::planner::Planner>::shape+0x3444>
  67741d:	48 8d 94 24 58 01 00 	lea    0x158(%rsp),%rdx
  677424:	00 
  677425:	48 8b 4a 40          	mov    0x40(%rdx),%rcx
  677429:	48 89 8c 24 68 07 00 	mov    %rcx,0x768(%rsp)
  677430:	00 
  677431:	0f 10 02             	movups (%rdx),%xmm0
  677434:	0f 10 4a 10          	movups 0x10(%rdx),%xmm1
  677438:	0f 10 52 20          	movups 0x20(%rdx),%xmm2
  67743c:	0f 10 5a 30          	movups 0x30(%rdx),%xmm3
  677440:	0f 11 9c 24 58 07 00 	movups %xmm3,0x758(%rsp)
  677447:	00 
  677448:	0f 11 94 24 48 07 00 	movups %xmm2,0x748(%rsp)
  67744f:	00 
  677450:	0f 11 8c 24 38 07 00 	movups %xmm1,0x738(%rsp)
  677457:	00 
  677458:	0f 11 84 24 28 07 00 	movups %xmm0,0x728(%rsp)
  67745f:	00 
  677460:	48 c7 84 24 10 07 00 	movq   $0x1,0x710(%rsp)
  677467:	00 01 00 00 00 
  67746c:	48 c7 84 24 18 07 00 	movq   $0x1,0x718(%rsp)
  677473:	00 01 00 00 00 
  677478:	4c 8d ac 24 20 07 00 	lea    0x720(%rsp),%r13
  67747f:	00 
  677480:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
  677487:	00 
  677488:	bf 08 00 00 00       	mov    $0x8,%edi
  67748d:	be 60 00 00 00       	mov    $0x60,%esi
  677492:	e8 f9 0b 00 00       	call   678090 <alloc::boxed::box_new_uninit>
  677497:	0f 10 84 24 60 07 00 	movups 0x760(%rsp),%xmm0
  67749e:	00 
  67749f:	0f 11 40 50          	movups %xmm0,0x50(%rax)
  6774a3:	0f 10 84 24 50 07 00 	movups 0x750(%rsp),%xmm0
  6774aa:	00 
  6774ab:	0f 11 40 40          	movups %xmm0,0x40(%rax)
  6774af:	0f 10 84 24 10 07 00 	movups 0x710(%rsp),%xmm0
  6774b6:	00 
  6774b7:	0f 10 8c 24 20 07 00 	movups 0x720(%rsp),%xmm1
  6774be:	00 
  6774bf:	0f 10 94 24 30 07 00 	movups 0x730(%rsp),%xmm2
  6774c6:	00 
  6774c7:	0f 10 9c 24 40 07 00 	movups 0x740(%rsp),%xmm3
  6774ce:	00 
  6774cf:	0f 11 58 30          	movups %xmm3,0x30(%rax)
  6774d3:	0f 11 50 20          	movups %xmm2,0x20(%rax)
  6774d7:	0f 11 48 10          	movups %xmm1,0x10(%rax)
  6774db:	0f 11 00             	movups %xmm0,(%rax)
  6774de:	4c 8b 2c 24          	mov    (%rsp),%r13
  6774e2:	eb 02                	jmp    6774e6 <<gpui_canvas::text::planner::Planner>::shape+0x3446>
  6774e4:	31 c0                	xor    %eax,%eax
  6774e6:	4c 89 bc 24 88 00 00 	mov    %r15,0x88(%rsp)
  6774ed:	00 
  6774ee:	48 89 9c 24 90 00 00 	mov    %rbx,0x90(%rsp)
  6774f5:	00 
  6774f6:	4c 89 b4 24 98 00 00 	mov    %r14,0x98(%rsp)
  6774fd:	00 
  6774fe:	4c 89 a4 24 a0 00 00 	mov    %r12,0xa0(%rsp)
  677505:	00 
  677506:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
  67750d:	00 
  67750e:	0f 28 84 24 80 02 00 	movaps 0x280(%rsp),%xmm0
  677515:	00 
  677516:	f3 0f 11 84 24 b0 00 	movss  %xmm0,0xb0(%rsp)
  67751d:	00 00 
  67751f:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
  677525:	f3 0f 11 84 24 b4 00 	movss  %xmm0,0xb4(%rsp)
  67752c:	00 00 
  67752e:	f3 0f 10 44 24 7c    	movss  0x7c(%rsp),%xmm0
  677534:	f3 0f 11 84 24 b8 00 	movss  %xmm0,0xb8(%rsp)
  67753b:	00 00 
  67753d:	f3 0f 10 84 24 84 00 	movss  0x84(%rsp),%xmm0
  677544:	00 00 
  677546:	f3 0f 11 84 24 bc 00 	movss  %xmm0,0xbc(%rsp)
  67754d:	00 00 
  67754f:	48 8d bc 24 a0 02 00 	lea    0x2a0(%rsp),%rdi
  677556:	00 
  677557:	e8 b4 a8 ff ff       	call   671e10 <core::ptr::drop_glue::<[parlance::font_family::FontFamilyName; 3]>>
  67755c:	49 83 ff ff          	cmp    $0xffffffffffffffff,%r15
  677560:	0f 85 af f9 ff ff    	jne    676f15 <<gpui_canvas::text::planner::Planner>::shape+0x2e75>
  677566:	e9 56 f8 ff ff       	jmp    676dc1 <<gpui_canvas::text::planner::Planner>::shape+0x2d21>
  67756b:	48 8d 0d 3e 82 10 00 	lea    0x10823e(%rip),%rcx        # 77f7b0 <anon.abe2914d8fd9d1076326722b06c47a5f.27.llvm.962491032109686297>
  677572:	48 89 f7             	mov    %rsi,%rdi
  677575:	48 89 d6             	mov    %rdx,%rsi
  677578:	4c 89 c2             	mov    %r8,%rdx
  67757b:	ff 15 7f 2c 11 00    	call   *0x112c7f(%rip)        # 78a200 <_DYNAMIC+0x560>
  677581:	e9 95 01 00 00       	jmp    67771b <<gpui_canvas::text::planner::Planner>::shape+0x367b>
  677586:	48 01 c1             	add    %rax,%rcx
  677589:	88 51 ff             	mov    %dl,-0x1(%rcx)
  67758c:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  677593:	00 ff 
  677595:	0f 85 10 fb ff ff    	jne    6770ab <<gpui_canvas::text::planner::Planner>::shape+0x300b>
  67759b:	e9 38 fe ff ff       	jmp    6773d8 <<gpui_canvas::text::planner::Planner>::shape+0x3338>
  6775a0:	48 89 cb             	mov    %rcx,%rbx
  6775a3:	48 8b 84 24 00 02 00 	mov    0x200(%rsp),%rax
  6775aa:	00 
  6775ab:	48 89 84 24 40 01 00 	mov    %rax,0x140(%rsp)
  6775b2:	00 
  6775b3:	48 8d 0d f6 83 10 00 	lea    0x1083f6(%rip),%rcx        # 77f9b0 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0x188>
  6775ba:	e9 c0 fc ff ff       	jmp    67727f <<gpui_canvas::text::planner::Planner>::shape+0x31df>
  6775bf:	48 89 d3             	mov    %rdx,%rbx
  6775c2:	4c 89 b4 24 40 01 00 	mov    %r14,0x140(%rsp)
  6775c9:	00 
  6775ca:	48 8d 0d a7 82 10 00 	lea    0x1082a7(%rip),%rcx        # 77f878 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0x50>
  6775d1:	e9 a9 fc ff ff       	jmp    67727f <<gpui_canvas::text::planner::Planner>::shape+0x31df>
  6775d6:	48 8d 0d 7b 8b 10 00 	lea    0x108b7b(%rip),%rcx        # 780158 <anon.c85b311aa65b1c615d2dfba884aacc4b.17.llvm.18174800310199966706>
  6775dd:	ff 15 1d 2c 11 00    	call   *0x112c1d(%rip)        # 78a200 <_DYNAMIC+0x560>
  6775e3:	e9 33 01 00 00       	jmp    67771b <<gpui_canvas::text::planner::Planner>::shape+0x367b>
  6775e8:	48 8d 0d 69 8b 10 00 	lea    0x108b69(%rip),%rcx        # 780158 <anon.c85b311aa65b1c615d2dfba884aacc4b.17.llvm.18174800310199966706>
  6775ef:	ff 15 0b 2c 11 00    	call   *0x112c0b(%rip)        # 78a200 <_DYNAMIC+0x560>
  6775f5:	e9 21 01 00 00       	jmp    67771b <<gpui_canvas::text::planner::Planner>::shape+0x367b>
  6775fa:	48 8d 3d c7 87 10 00 	lea    0x1087c7(%rip),%rdi        # 77fdc8 <anon.8910945c9b008592b86f990050da00b9.41.llvm.15053945833241892313>
  677601:	ff 15 d1 29 11 00    	call   *0x1129d1(%rip)        # 789fd8 <_DYNAMIC+0x338>
  677607:	e9 0f 01 00 00       	jmp    67771b <<gpui_canvas::text::planner::Planner>::shape+0x367b>
  67760c:	83 f8 fe             	cmp    $0xfffffffe,%eax
  67760f:	0f 85 f1 f9 ff ff    	jne    677006 <<gpui_canvas::text::planner::Planner>::shape+0x2f66>
  677615:	b8 03 00 00 00       	mov    $0x3,%eax
  67761a:	e9 e7 f9 ff ff       	jmp    677006 <<gpui_canvas::text::planner::Planner>::shape+0x2f66>
  67761f:	4c 8d 05 ca 82 10 00 	lea    0x1082ca(%rip),%r8        # 77f8f0 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0xc8>
  677626:	48 8b bc 24 48 01 00 	mov    0x148(%rsp),%rdi
  67762d:	00 
  67762e:	48 8b 74 24 50       	mov    0x50(%rsp),%rsi
  677633:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
  677638:	ff 15 3a 2c 11 00    	call   *0x112c3a(%rip)        # 78a278 <_DYNAMIC+0x5d8>
  67763e:	e9 d8 00 00 00       	jmp    67771b <<gpui_canvas::text::planner::Planner>::shape+0x367b>
  677643:	48 8d 05 46 82 10 00 	lea    0x108246(%rip),%rax        # 77f890 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0x68>
  67764a:	eb 1f                	jmp    67766b <<gpui_canvas::text::planner::Planner>::shape+0x35cb>
  67764c:	49 39 d6             	cmp    %rdx,%r14
  67764f:	49 0f 47 d6          	cmova  %r14,%rdx
  677653:	48 8d 05 26 84 10 00 	lea    0x108426(%rip),%rax        # 77fa80 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0x258>
  67765a:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  67765f:	48 89 d7             	mov    %rdx,%rdi
  677662:	eb 0c                	jmp    677670 <<gpui_canvas::text::planner::Planner>::shape+0x35d0>
  677664:	48 8d 05 e5 82 10 00 	lea    0x1082e5(%rip),%rax        # 77f950 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0x128>
  67766b:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  677670:	48 8b b4 24 e8 01 00 	mov    0x1e8(%rsp),%rsi
  677677:	00 
  677678:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
  67767d:	ff 15 7d 29 11 00    	call   *0x11297d(%rip)        # 78a000 <_DYNAMIC+0x360>
  677683:	e9 93 00 00 00       	jmp    67771b <<gpui_canvas::text::planner::Planner>::shape+0x367b>
  677688:	48 8d 0d 69 81 10 00 	lea    0x108169(%rip),%rcx        # 77f7f8 <anon.abe2914d8fd9d1076326722b06c47a5f.32.llvm.962491032109686297>
  67768f:	48 89 8c 24 70 02 00 	mov    %rcx,0x270(%rsp)
  677696:	00 
  677697:	eb 04                	jmp    67769d <<gpui_canvas::text::planner::Planner>::shape+0x35fd>
  677699:	31 ff                	xor    %edi,%edi
  67769b:	31 c0                	xor    %eax,%eax
  67769d:	48 89 c6             	mov    %rax,%rsi
  6776a0:	48 8b 94 24 70 02 00 	mov    0x270(%rsp),%rdx
  6776a7:	00 
  6776a8:	ff 15 52 29 11 00    	call   *0x112952(%rip)        # 78a000 <_DYNAMIC+0x360>
  6776ae:	eb 6b                	jmp    67771b <<gpui_canvas::text::planner::Planner>::shape+0x367b>
  6776b0:	31 ff                	xor    %edi,%edi
  6776b2:	48 c7 84 24 e8 01 00 	movq   $0x0,0x1e8(%rsp)
  6776b9:	00 00 00 00 00 
  6776be:	eb b0                	jmp    677670 <<gpui_canvas::text::planner::Planner>::shape+0x35d0>
  6776c0:	48 8d 15 71 89 10 00 	lea    0x108971(%rip),%rdx        # 780038 <anon.8910945c9b008592b86f990050da00b9.70.llvm.15053945833241892313>
  6776c7:	ff 15 33 29 11 00    	call   *0x112933(%rip)        # 78a000 <_DYNAMIC+0x360>
  6776cd:	eb 4c                	jmp    67771b <<gpui_canvas::text::planner::Planner>::shape+0x367b>
  6776cf:	48 8d 05 92 83 10 00 	lea    0x108392(%rip),%rax        # 77fa68 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0x240>
  6776d6:	eb 93                	jmp    67766b <<gpui_canvas::text::planner::Planner>::shape+0x35cb>
  6776d8:	48 89 d7             	mov    %rdx,%rdi
  6776db:	48 8d 05 b6 83 10 00 	lea    0x1083b6(%rip),%rax        # 77fa98 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0x270>
  6776e2:	eb 87                	jmp    67766b <<gpui_canvas::text::planner::Planner>::shape+0x35cb>
  6776e4:	48 8d 05 4d 82 10 00 	lea    0x10824d(%rip),%rax        # 77f938 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0x110>
  6776eb:	e9 7b ff ff ff       	jmp    67766b <<gpui_canvas::text::planner::Planner>::shape+0x35cb>
  6776f0:	48 8d 05 71 82 10 00 	lea    0x108271(%rip),%rax        # 77f968 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0x140>
  6776f7:	e9 6f ff ff ff       	jmp    67766b <<gpui_canvas::text::planner::Planner>::shape+0x35cb>
  6776fc:	48 89 d7             	mov    %rdx,%rdi
  6776ff:	48 8d 05 7a 82 10 00 	lea    0x10827a(%rip),%rax        # 77f980 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0x158>
  677706:	e9 60 ff ff ff       	jmp    67766b <<gpui_canvas::text::planner::Planner>::shape+0x35cb>
  67770b:	48 8d 15 e6 80 10 00 	lea    0x1080e6(%rip),%rdx        # 77f7f8 <anon.abe2914d8fd9d1076326722b06c47a5f.32.llvm.962491032109686297>
  677712:	48 89 c6             	mov    %rax,%rsi
  677715:	ff 15 e5 28 11 00    	call   *0x1128e5(%rip)        # 78a000 <_DYNAMIC+0x360>
  67771b:	0f 0b                	ud2
  67771d:	49 89 c6             	mov    %rax,%r14
  677720:	be 18 00 00 00       	mov    $0x18,%esi
  677725:	ba 04 00 00 00       	mov    $0x4,%edx
  67772a:	48 89 df             	mov    %rbx,%rdi
  67772d:	ff 15 a5 27 11 00    	call   *0x1127a5(%rip)        # 789ed8 <_DYNAMIC+0x238>
  677733:	e9 9a 02 00 00       	jmp    6779d2 <<gpui_canvas::text::planner::Planner>::shape+0x3932>
  677738:	49 89 c6             	mov    %rax,%r14
  67773b:	4c 89 ef             	mov    %r13,%rdi
  67773e:	e8 ed be ff ff       	call   673630 <core::ptr::drop_glue::<gpui_canvas::text::layout::TextGeometry>>
  677743:	f0 49 ff 0c 24       	lock decq (%r12)
  677748:	75 0e                	jne    677758 <<gpui_canvas::text::planner::Planner>::shape+0x36b8>
  67774a:	48 8d bc 24 c0 04 00 	lea    0x4c0(%rsp),%rdi
  677751:	00 
  677752:	ff 15 98 27 11 00    	call   *0x112798(%rip)        # 789ef0 <_DYNAMIC+0x250>
  677758:	31 ed                	xor    %ebp,%ebp
  67775a:	eb 0c                	jmp    677768 <<gpui_canvas::text::planner::Planner>::shape+0x36c8>
  67775c:	ff 15 96 27 11 00    	call   *0x112796(%rip)        # 789ef8 <_DYNAMIC+0x258>
  677762:	49 89 c6             	mov    %rax,%r14
  677765:	40 b5 01             	mov    $0x1,%bpl
  677768:	4d 85 ff             	test   %r15,%r15
  67776b:	74 15                	je     677782 <<gpui_canvas::text::planner::Planner>::shape+0x36e2>
  67776d:	49 c1 e7 04          	shl    $0x4,%r15
  677771:	ba 04 00 00 00       	mov    $0x4,%edx
  677776:	48 89 df             	mov    %rbx,%rdi
  677779:	4c 89 fe             	mov    %r15,%rsi
  67777c:	ff 15 56 27 11 00    	call   *0x112756(%rip)        # 789ed8 <_DYNAMIC+0x238>
  677782:	40 84 ed             	test   %bpl,%bpl
  677785:	0f 84 89 02 00 00    	je     677a14 <<gpui_canvas::text::planner::Planner>::shape+0x3974>
  67778b:	31 db                	xor    %ebx,%ebx
  67778d:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  677794:	00 ff 
  677796:	0f 84 fb 01 00 00    	je     677997 <<gpui_canvas::text::planner::Planner>::shape+0x38f7>
  67779c:	e9 3e 02 00 00       	jmp    6779df <<gpui_canvas::text::planner::Planner>::shape+0x393f>
  6777a1:	49 89 c6             	mov    %rax,%r14
  6777a4:	4c 89 3b             	mov    %r15,(%rbx)
  6777a7:	4c 89 f7             	mov    %r14,%rdi
  6777aa:	e8 51 67 10 00       	call   77df00 <_Unwind_Resume@plt>
  6777af:	e9 1b 02 00 00       	jmp    6779cf <<gpui_canvas::text::planner::Planner>::shape+0x392f>
  6777b4:	e9 16 02 00 00       	jmp    6779cf <<gpui_canvas::text::planner::Planner>::shape+0x392f>
  6777b9:	e9 11 02 00 00       	jmp    6779cf <<gpui_canvas::text::planner::Planner>::shape+0x392f>
  6777be:	e9 b7 01 00 00       	jmp    67797a <<gpui_canvas::text::planner::Planner>::shape+0x38da>
  6777c3:	e9 07 02 00 00       	jmp    6779cf <<gpui_canvas::text::planner::Planner>::shape+0x392f>
  6777c8:	e9 02 02 00 00       	jmp    6779cf <<gpui_canvas::text::planner::Planner>::shape+0x392f>
  6777cd:	e9 fd 01 00 00       	jmp    6779cf <<gpui_canvas::text::planner::Planner>::shape+0x392f>
  6777d2:	e9 a3 01 00 00       	jmp    67797a <<gpui_canvas::text::planner::Planner>::shape+0x38da>
  6777d7:	e9 f3 01 00 00       	jmp    6779cf <<gpui_canvas::text::planner::Planner>::shape+0x392f>
  6777dc:	49 89 c6             	mov    %rax,%r14
  6777df:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  6777e6:	00 
  6777e7:	e8 d4 18 ff ff       	call   6690c0 <core::ptr::drop_glue::<parley::style::StyleProperty<()>>>
  6777ec:	e9 e1 01 00 00       	jmp    6779d2 <<gpui_canvas::text::planner::Planner>::shape+0x3932>
  6777f1:	ff 15 01 27 11 00    	call   *0x112701(%rip)        # 789ef8 <_DYNAMIC+0x258>
  6777f7:	49 89 c6             	mov    %rax,%r14
  6777fa:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  677801:	00 
  677802:	e8 b9 18 ff ff       	call   6690c0 <core::ptr::drop_glue::<parley::style::StyleProperty<()>>>
  677807:	e9 c6 01 00 00       	jmp    6779d2 <<gpui_canvas::text::planner::Planner>::shape+0x3932>
  67780c:	ff 15 e6 26 11 00    	call   *0x1126e6(%rip)        # 789ef8 <_DYNAMIC+0x258>
  677812:	49 89 c6             	mov    %rax,%r14
  677815:	49 c7 85 c8 08 00 00 	movq   $0x0,0x8c8(%r13)
  67781c:	00 00 00 00 
  677820:	49 c7 85 d0 08 00 00 	movq   $0x4,0x8d0(%r13)
  677827:	04 00 00 00 
  67782b:	0f 57 c0             	xorps  %xmm0,%xmm0
  67782e:	41 0f 11 85 d8 08 00 	movups %xmm0,0x8d8(%r13)
  677835:	00 
  677836:	49 c7 85 e8 08 00 00 	movq   $0x4,0x8e8(%r13)
  67783d:	04 00 00 00 
  677841:	41 0f 11 85 f0 08 00 	movups %xmm0,0x8f0(%r13)
  677848:	00 
  677849:	49 c7 85 00 09 00 00 	movq   $0x8,0x900(%r13)
  677850:	08 00 00 00 
  677854:	41 0f 11 85 08 09 00 	movups %xmm0,0x908(%r13)
  67785b:	00 
  67785c:	49 c7 85 18 09 00 00 	movq   $0x8,0x918(%r13)
  677863:	08 00 00 00 
  677867:	41 0f 11 85 20 09 00 	movups %xmm0,0x920(%r13)
  67786e:	00 
  67786f:	49 c7 85 30 09 00 00 	movq   $0x4,0x930(%r13)
  677876:	04 00 00 00 
  67787a:	41 0f 11 85 38 09 00 	movups %xmm0,0x938(%r13)
  677881:	00 
  677882:	49 c7 85 48 09 00 00 	movq   $0x4,0x948(%r13)
  677889:	04 00 00 00 
  67788d:	41 0f 11 85 50 09 00 	movups %xmm0,0x950(%r13)
  677894:	00 
  677895:	49 c7 85 60 09 00 00 	movq   $0x4,0x960(%r13)
  67789c:	04 00 00 00 
  6778a0:	41 0f 11 85 68 09 00 	movups %xmm0,0x968(%r13)
  6778a7:	00 
  6778a8:	49 c7 85 78 09 00 00 	movq   $0x8,0x978(%r13)
  6778af:	08 00 00 00 
  6778b3:	41 0f 11 85 80 09 00 	movups %xmm0,0x980(%r13)
  6778ba:	00 
  6778bb:	49 c7 85 90 09 00 00 	movq   $0x2,0x990(%r13)
  6778c2:	02 00 00 00 
  6778c6:	41 0f 11 85 98 09 00 	movups %xmm0,0x998(%r13)
  6778cd:	00 
  6778ce:	49 c7 85 a8 09 00 00 	movq   $0x4,0x9a8(%r13)
  6778d5:	04 00 00 00 
  6778d9:	41 0f 11 85 b0 09 00 	movups %xmm0,0x9b0(%r13)
  6778e0:	00 
  6778e1:	49 c7 85 c0 09 00 00 	movq   $0x8,0x9c0(%r13)
  6778e8:	08 00 00 00 
  6778ec:	41 0f 11 85 c8 09 00 	movups %xmm0,0x9c8(%r13)
  6778f3:	00 
  6778f4:	49 c7 85 d8 09 00 00 	movq   $0x8,0x9d8(%r13)
  6778fb:	08 00 00 00 
  6778ff:	41 0f 11 85 e0 09 00 	movups %xmm0,0x9e0(%r13)
  677906:	00 
  677907:	49 c7 85 f0 09 00 00 	movq   $0x8,0x9f0(%r13)
  67790e:	08 00 00 00 
  677912:	41 0f 11 85 f8 09 00 	movups %xmm0,0x9f8(%r13)
  677919:	00 
  67791a:	49 c7 85 08 0a 00 00 	movq   $0x4,0xa08(%r13)
  677921:	04 00 00 00 
  677925:	41 0f 11 85 10 0a 00 	movups %xmm0,0xa10(%r13)
  67792c:	00 
  67792d:	41 c7 85 20 0a 00 00 	movl   $0x3f800000,0xa20(%r13)
  677934:	00 00 80 3f 
  677938:	41 0f 11 85 24 0a 00 	movups %xmm0,0xa24(%r13)
  67793f:	00 
  677940:	49 c7 85 32 0a 00 00 	movq   $0x0,0xa32(%r13)
  677947:	00 00 00 00 
  67794b:	66 41 c7 85 3a 0a 00 	movw   $0xff01,0xa3a(%r13)
  677952:	00 01 ff 
  677955:	41 c6 85 3c 0a 00 00 	movb   $0x0,0xa3c(%r13)
  67795c:	00 
  67795d:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
  677964:	00 
  677965:	e8 b6 a5 ff ff       	call   671f20 <core::ptr::drop_glue::<core::result::Result<gpui_canvas::text::TextLayout, gpui_canvas::Error>>>
  67796a:	4c 89 f7             	mov    %r14,%rdi
  67796d:	e8 8e 65 10 00       	call   77df00 <_Unwind_Resume@plt>
  677972:	ff 15 80 25 11 00    	call   *0x112580(%rip)        # 789ef8 <_DYNAMIC+0x258>
  677978:	eb 55                	jmp    6779cf <<gpui_canvas::text::planner::Planner>::shape+0x392f>
  67797a:	49 89 c6             	mov    %rax,%r14
  67797d:	48 8b b4 24 10 07 00 	mov    0x710(%rsp),%rsi
  677984:	00 
  677985:	b3 01                	mov    $0x1,%bl
  677987:	48 85 f6             	test   %rsi,%rsi
  67798a:	75 11                	jne    67799d <<gpui_canvas::text::planner::Planner>::shape+0x38fd>
  67798c:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  677993:	00 ff 
  677995:	75 48                	jne    6779df <<gpui_canvas::text::planner::Planner>::shape+0x393f>
  677997:	84 db                	test   %bl,%bl
  677999:	75 55                	jne    6779f0 <<gpui_canvas::text::planner::Planner>::shape+0x3950>
  67799b:	eb 77                	jmp    677a14 <<gpui_canvas::text::planner::Planner>::shape+0x3974>
  67799d:	48 8b bc 24 18 07 00 	mov    0x718(%rsp),%rdi
  6779a4:	00 
  6779a5:	48 c1 e6 03          	shl    $0x3,%rsi
  6779a9:	ba 08 00 00 00       	mov    $0x8,%edx
  6779ae:	ff 15 24 25 11 00    	call   *0x112524(%rip)        # 789ed8 <_DYNAMIC+0x238>
  6779b4:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  6779bb:	00 ff 
  6779bd:	74 d8                	je     677997 <<gpui_canvas::text::planner::Planner>::shape+0x38f7>
  6779bf:	eb 1e                	jmp    6779df <<gpui_canvas::text::planner::Planner>::shape+0x393f>
  6779c1:	eb 0c                	jmp    6779cf <<gpui_canvas::text::planner::Planner>::shape+0x392f>
  6779c3:	eb 0a                	jmp    6779cf <<gpui_canvas::text::planner::Planner>::shape+0x392f>
  6779c5:	eb 08                	jmp    6779cf <<gpui_canvas::text::planner::Planner>::shape+0x392f>
  6779c7:	eb 06                	jmp    6779cf <<gpui_canvas::text::planner::Planner>::shape+0x392f>
  6779c9:	eb 04                	jmp    6779cf <<gpui_canvas::text::planner::Planner>::shape+0x392f>
  6779cb:	eb 02                	jmp    6779cf <<gpui_canvas::text::planner::Planner>::shape+0x392f>
  6779cd:	eb 00                	jmp    6779cf <<gpui_canvas::text::planner::Planner>::shape+0x392f>
  6779cf:	49 89 c6             	mov    %rax,%r14
  6779d2:	b3 01                	mov    $0x1,%bl
  6779d4:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  6779db:	00 ff 
  6779dd:	74 b8                	je     677997 <<gpui_canvas::text::planner::Planner>::shape+0x38f7>
  6779df:	48 8d bc 24 50 01 00 	lea    0x150(%rsp),%rdi
  6779e6:	00 
  6779e7:	e8 44 bc ff ff       	call   673630 <core::ptr::drop_glue::<gpui_canvas::text::layout::TextGeometry>>
  6779ec:	84 db                	test   %bl,%bl
  6779ee:	74 24                	je     677a14 <<gpui_canvas::text::planner::Planner>::shape+0x3974>
  6779f0:	48 8b b4 24 e8 00 00 	mov    0xe8(%rsp),%rsi
  6779f7:	00 
  6779f8:	48 85 f6             	test   %rsi,%rsi
  6779fb:	74 17                	je     677a14 <<gpui_canvas::text::planner::Planner>::shape+0x3974>
  6779fd:	48 8b bc 24 f0 00 00 	mov    0xf0(%rsp),%rdi
  677a04:	00 
  677a05:	48 c1 e6 04          	shl    $0x4,%rsi
  677a09:	ba 04 00 00 00       	mov    $0x4,%edx
  677a0e:	ff 15 c4 24 11 00    	call   *0x1124c4(%rip)        # 789ed8 <_DYNAMIC+0x238>
  677a14:	48 8d bc 24 a0 02 00 	lea    0x2a0(%rsp),%rdi
  677a1b:	00 
  677a1c:	e8 ef a3 ff ff       	call   671e10 <core::ptr::drop_glue::<[parlance::font_family::FontFamilyName; 3]>>
  677a21:	4c 89 f7             	mov    %r14,%rdi
  677a24:	e8 d7 64 10 00       	call   77df00 <_Unwind_Resume@plt>
