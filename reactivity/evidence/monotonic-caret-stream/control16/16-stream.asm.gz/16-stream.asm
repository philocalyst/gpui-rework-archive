
/tmp/gpui-monotonic-control-bin/stream16:     file format elf64-x86-64


Disassembly of section .text:

000000000066cc00 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>>:
  66cc00:	55                   	push   %rbp
  66cc01:	41 57                	push   %r15
  66cc03:	41 56                	push   %r14
  66cc05:	41 55                	push   %r13
  66cc07:	41 54                	push   %r12
  66cc09:	53                   	push   %rbx
  66cc0a:	48 81 ec a8 07 00 00 	sub    $0x7a8,%rsp
  66cc11:	49 89 d7             	mov    %rdx,%r15
  66cc14:	49 89 f4             	mov    %rsi,%r12
  66cc17:	48 89 fb             	mov    %rdi,%rbx
  66cc1a:	48 8b af 50 01 00 00 	mov    0x150(%rdi),%rbp
  66cc21:	48 89 e8             	mov    %rbp,%rax
  66cc24:	48 c1 e8 20          	shr    $0x20,%rax
  66cc28:	74 16                	je     66cc40 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x40>
  66cc2a:	48 89 df             	mov    %rbx,%rdi
  66cc2d:	4c 89 e6             	mov    %r12,%rsi
  66cc30:	4c 89 fa             	mov    %r15,%rdx
  66cc33:	e8 b8 2c 00 00       	call   66f8f0 <parley::editing::geometry::visit_indexed::<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>>
  66cc38:	41 89 c6             	mov    %eax,%r14d
  66cc3b:	e9 93 18 00 00       	jmp    66e4d3 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18d3>
  66cc40:	f3 0f 11 44 24 04    	movss  %xmm0,0x4(%rsp)
  66cc46:	41 be fe ff ff ff    	mov    $0xfffffffe,%r14d
  66cc4c:	83 7b 74 00          	cmpl   $0x0,0x74(%rbx)
  66cc50:	0f 85 60 18 00 00    	jne    66e4b6 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18b6>
  66cc56:	48 8b 93 18 01 00 00 	mov    0x118(%rbx),%rdx
  66cc5d:	48 89 d0             	mov    %rdx,%rax
  66cc60:	48 c1 e8 20          	shr    $0x20,%rax
  66cc64:	0f 85 4c 18 00 00    	jne    66e4b6 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18b6>
  66cc6a:	48 c7 84 24 a8 00 00 	movq   $0x0,0xa8(%rsp)
  66cc71:	00 00 00 00 00 
  66cc76:	48 c7 84 24 b0 00 00 	movq   $0x8,0xb0(%rsp)
  66cc7d:	00 08 00 00 00 
  66cc82:	48 c7 84 24 b8 00 00 	movq   $0x0,0xb8(%rsp)
  66cc89:	00 00 00 00 00 
  66cc8e:	48 8b 8b 10 01 00 00 	mov    0x110(%rbx),%rcx
  66cc95:	48 6b c2 70          	imul   $0x70,%rdx,%rax
  66cc99:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
  66cc9e:	48 01 c8             	add    %rcx,%rax
  66cca1:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
  66cca8:	00 
  66cca9:	48 85 d2             	test   %rdx,%rdx
  66ccac:	4c 89 64 24 18       	mov    %r12,0x18(%rsp)
  66ccb1:	4c 89 bc 24 30 01 00 	mov    %r15,0x130(%rsp)
  66ccb8:	00 
  66ccb9:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
  66ccbe:	48 89 94 24 80 00 00 	mov    %rdx,0x80(%rsp)
  66ccc5:	00 
  66ccc6:	0f 84 4c 03 00 00    	je     66d018 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x418>
  66cccc:	48 8b 83 30 01 00 00 	mov    0x130(%rbx),%rax
  66ccd3:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  66ccda:	00 
  66ccdb:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
  66cce2:	48 89 84 24 f0 00 00 	mov    %rax,0xf0(%rsp)
  66cce9:	00 
  66ccea:	48 8b 43 50          	mov    0x50(%rbx),%rax
  66ccee:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
  66ccf3:	48 8b 43 58          	mov    0x58(%rbx),%rax
  66ccf7:	48 8b 8b e8 00 00 00 	mov    0xe8(%rbx),%rcx
  66ccfe:	48 39 c8             	cmp    %rcx,%rax
  66cd01:	48 0f 42 c8          	cmovb  %rax,%rcx
  66cd05:	48 89 4c 24 70       	mov    %rcx,0x70(%rsp)
  66cd0a:	48 8b 83 e0 00 00 00 	mov    0xe0(%rbx),%rax
  66cd11:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  66cd16:	48 85 ed             	test   %rbp,%rbp
  66cd19:	0f 84 59 03 00 00    	je     66d078 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x478>
  66cd1f:	48 c7 44 24 58 00 00 	movq   $0x0,0x58(%rsp)
  66cd26:	00 00 
  66cd28:	48 8d 8c 24 a8 00 00 	lea    0xa8(%rsp),%rcx
  66cd2f:	00 
  66cd30:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
  66cd37:	00 00 
  66cd39:	48 c7 44 24 48 00 00 	movq   $0x0,0x48(%rsp)
  66cd40:	00 00 
  66cd42:	4c 8b 74 24 50       	mov    0x50(%rsp),%r14
  66cd47:	45 31 ed             	xor    %r13d,%r13d
  66cd4a:	48 89 6c 24 40       	mov    %rbp,0x40(%rsp)
  66cd4f:	eb 38                	jmp    66cd89 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x189>
  66cd51:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
  66cd56:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  66cd5d:	00 
  66cd5e:	49 89 c6             	mov    %rax,%r14
  66cd61:	8b 8c 24 c0 00 00 00 	mov    0xc0(%rsp),%ecx
  66cd68:	41 89 cd             	mov    %ecx,%r13d
  66cd6b:	48 3b 84 24 60 01 00 	cmp    0x160(%rsp),%rax
  66cd72:	00 
  66cd73:	4c 8b bc 24 30 01 00 	mov    0x130(%rsp),%r15
  66cd7a:	00 
  66cd7b:	48 8d 8c 24 a8 00 00 	lea    0xa8(%rsp),%rcx
  66cd82:	00 
  66cd83:	0f 84 a5 02 00 00    	je     66d02e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x42e>
  66cd89:	49 8b 76 10          	mov    0x10(%r14),%rsi
  66cd8d:	49 8b 56 18          	mov    0x18(%r14),%rdx
  66cd91:	48 89 df             	mov    %rbx,%rdi
  66cd94:	e8 97 26 00 00       	call   66f430 <parley::editing::geometry::source_runs::<()>>
  66cd99:	48 83 f8 01          	cmp    $0x1,%rax
  66cd9d:	0f 85 ef 15 00 00    	jne    66e392 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1792>
  66cda3:	4c 89 b4 24 28 01 00 	mov    %r14,0x128(%rsp)
  66cdaa:	00 
  66cdab:	49 8d 46 70          	lea    0x70(%r14),%rax
  66cdaf:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
  66cdb6:	00 
  66cdb7:	4c 89 ac 24 20 01 00 	mov    %r13,0x120(%rsp)
  66cdbe:	00 
  66cdbf:	41 8d 45 01          	lea    0x1(%r13),%eax
  66cdc3:	89 84 24 c0 00 00 00 	mov    %eax,0xc0(%rsp)
  66cdca:	4c 8b ac 24 b0 00 00 	mov    0xb0(%rsp),%r13
  66cdd1:	00 
  66cdd2:	4c 8b bc 24 b8 00 00 	mov    0xb8(%rsp),%r15
  66cdd9:	00 
  66cdda:	49 c1 e7 04          	shl    $0x4,%r15
  66cdde:	4d 01 ef             	add    %r13,%r15
  66cde1:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
  66cde8:	00 
  66cde9:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  66cdee:	66 90                	xchg   %ax,%ax
  66cdf0:	4d 39 fd             	cmp    %r15,%r13
  66cdf3:	0f 84 58 ff ff ff    	je     66cd51 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x151>
  66cdf9:	49 8b 45 00          	mov    0x0(%r13),%rax
  66cdfd:	49 83 c5 10          	add    $0x10,%r13
  66ce01:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  66ce05:	74 e9                	je     66cdf0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f0>
  66ce07:	48 8b b4 24 28 01 00 	mov    0x128(%rsp),%rsi
  66ce0e:	00 
  66ce0f:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
  66ce13:	48 01 c1             	add    %rax,%rcx
  66ce16:	41 be fe ff ff ff    	mov    $0xfffffffe,%r14d
  66ce1c:	b3 01                	mov    $0x1,%bl
  66ce1e:	48 3b 4e 18          	cmp    0x18(%rsi),%rcx
  66ce22:	0f 83 66 16 00 00    	jae    66e48e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x188e>
  66ce28:	48 3b 8c 24 00 01 00 	cmp    0x100(%rsp),%rcx
  66ce2f:	00 
  66ce30:	0f 83 58 16 00 00    	jae    66e48e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x188e>
  66ce36:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
  66ce3a:	48 8b b4 24 f0 00 00 	mov    0xf0(%rsp),%rsi
  66ce41:	00 
  66ce42:	80 7c ce 21 00       	cmpb   $0x0,0x21(%rsi,%rcx,8)
  66ce47:	0f 85 41 16 00 00    	jne    66e48e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x188e>
  66ce4d:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
  66ce52:	48 8d 14 ce          	lea    (%rsi,%rcx,8),%rdx
  66ce56:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
  66ce5a:	48 3b 4c 24 70       	cmp    0x70(%rsp),%rcx
  66ce5f:	0f 83 29 16 00 00    	jae    66e48e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x188e>
  66ce65:	48 8d 3c c9          	lea    (%rcx,%rcx,8),%rdi
  66ce69:	48 c1 e7 04          	shl    $0x4,%rdi
  66ce6d:	48 03 7c 24 68       	add    0x68(%rsp),%rdi
  66ce72:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
  66ce76:	48 c1 e6 04          	shl    $0x4,%rsi
  66ce7a:	48 03 74 24 10       	add    0x10(%rsp),%rsi
  66ce7f:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
  66ce84:	48 89 9c 24 30 03 00 	mov    %rbx,0x330(%rsp)
  66ce8b:	00 
  66ce8c:	48 89 bc 24 18 01 00 	mov    %rdi,0x118(%rsp)
  66ce93:	00 
  66ce94:	48 89 bc 24 38 03 00 	mov    %rdi,0x338(%rsp)
  66ce9b:	00 
  66ce9c:	48 89 b4 24 40 03 00 	mov    %rsi,0x340(%rsp)
  66cea3:	00 
  66cea4:	48 89 94 24 48 03 00 	mov    %rdx,0x348(%rsp)
  66ceab:	00 
  66ceac:	48 8b 94 24 20 01 00 	mov    0x120(%rsp),%rdx
  66ceb3:	00 
  66ceb4:	89 94 24 50 03 00 00 	mov    %edx,0x350(%rsp)
  66cebb:	89 84 24 54 03 00 00 	mov    %eax,0x354(%rsp)
  66cec2:	89 8c 24 58 03 00 00 	mov    %ecx,0x358(%rsp)
  66cec9:	4c 8d b4 24 98 06 00 	lea    0x698(%rsp),%r14
  66ced0:	00 
  66ced1:	4c 89 f7             	mov    %r14,%rdi
  66ced4:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
  66cedb:	00 
  66cedc:	49 89 f4             	mov    %rsi,%r12
  66cedf:	31 d2                	xor    %edx,%edx
  66cee1:	e8 2a de 00 00       	call   67ad10 <<parley::layout::run::Clusters<()>>::new>
  66cee6:	ba 10 01 00 00       	mov    $0x110,%edx
  66ceeb:	4c 89 e7             	mov    %r12,%rdi
  66ceee:	4c 89 f6             	mov    %r14,%rsi
  66cef1:	ff 15 79 d0 11 00    	call   *0x11d079(%rip)        # 789f70 <memcpy@GLIBC_2.14>
  66cef7:	4c 89 e6             	mov    %r12,%rsi
  66cefa:	31 ed                	xor    %ebp,%ebp
  66cefc:	0f 1f 40 00          	nopl   0x0(%rax)
  66cf00:	48 8d bc 24 00 02 00 	lea    0x200(%rsp),%rdi
  66cf07:	00 
  66cf08:	e8 63 06 01 00       	call   67d570 <<parley::layout::run::Clusters<()> as core::iter::traits::iterator::Iterator>::next>
  66cf0d:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  66cf12:	4c 8d 24 28          	lea    (%rax,%rbp,1),%r12
  66cf16:	48 8b 84 24 00 02 00 	mov    0x200(%rsp),%rax
  66cf1d:	00 
  66cf1e:	48 85 c0             	test   %rax,%rax
  66cf21:	0f 84 c3 00 00 00    	je     66cfea <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x3ea>
  66cf27:	8b bc 24 28 02 00 00 	mov    0x228(%rsp),%edi
  66cf2e:	48 8b 70 58          	mov    0x58(%rax),%rsi
  66cf32:	48 39 fe             	cmp    %rdi,%rsi
  66cf35:	0f 86 f4 15 00 00    	jbe    66e52f <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x192f>
  66cf3b:	8b b4 24 80 02 00 00 	mov    0x280(%rsp),%esi
  66cf42:	8b 94 24 84 02 00 00 	mov    0x284(%rsp),%edx
  66cf49:	48 8b 48 50          	mov    0x50(%rax),%rcx
  66cf4d:	48 8d 3c ff          	lea    (%rdi,%rdi,8),%rdi
  66cf51:	48 c1 e7 04          	shl    $0x4,%rdi
  66cf55:	0f 10 40 68          	movups 0x68(%rax),%xmm0
  66cf59:	0f 10 88 80 00 00 00 	movups 0x80(%rax),%xmm1
  66cf60:	0f 10 90 98 00 00 00 	movups 0x98(%rax),%xmm2
  66cf67:	0f 11 84 24 88 05 00 	movups %xmm0,0x588(%rsp)
  66cf6e:	00 
  66cf6f:	0f 11 8c 24 98 05 00 	movups %xmm1,0x598(%rsp)
  66cf76:	00 
  66cf77:	0f 11 94 24 a8 05 00 	movups %xmm2,0x5a8(%rsp)
  66cf7e:	00 
  66cf7f:	48 8b 44 39 50       	mov    0x50(%rcx,%rdi,1),%rax
  66cf84:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
  66cf8b:	00 
  66cf8c:	48 8d bc 24 88 05 00 	lea    0x588(%rsp),%rdi
  66cf93:	00 
  66cf94:	ff 15 b6 d3 11 00    	call   *0x11d3b6(%rip)        # 78a350 <_DYNAMIC+0x6b0>
  66cf9a:	41 be fe ff ff ff    	mov    $0xfffffffe,%r14d
  66cfa0:	b3 01                	mov    $0x1,%bl
  66cfa2:	48 39 d0             	cmp    %rdx,%rax
  66cfa5:	0f 87 de 14 00 00    	ja     66e489 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1889>
  66cfab:	48 3b 54 24 40       	cmp    0x40(%rsp),%rdx
  66cfb0:	0f 87 d3 14 00 00    	ja     66e489 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1889>
  66cfb6:	48 39 d0             	cmp    %rdx,%rax
  66cfb9:	73 10                	jae    66cfcb <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x3cb>
  66cfbb:	48 3b 44 24 58       	cmp    0x58(%rsp),%rax
  66cfc0:	48 89 54 24 58       	mov    %rdx,0x58(%rsp)
  66cfc5:	0f 82 8f 14 00 00    	jb     66e45a <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x185a>
  66cfcb:	49 c1 ec 20          	shr    $0x20,%r12
  66cfcf:	0f 85 b4 14 00 00    	jne    66e489 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1889>
  66cfd5:	48 ff c5             	inc    %rbp
  66cfd8:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
  66cfdd:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
  66cfe4:	00 
  66cfe5:	e9 16 ff ff ff       	jmp    66cf00 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x300>
  66cfea:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  66cfef:	48 39 d5             	cmp    %rdx,%rbp
  66cff2:	48 0f 46 ea          	cmovbe %rdx,%rbp
  66cff6:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
  66cffd:	00 
  66cffe:	f6 80 8c 00 00 00 01 	testb  $0x1,0x8c(%rax)
  66d005:	48 0f 45 d5          	cmovne %rbp,%rdx
  66d009:	4c 89 64 24 48       	mov    %r12,0x48(%rsp)
  66d00e:	4c 8b 64 24 18       	mov    0x18(%rsp),%r12
  66d013:	e9 d8 fd ff ff       	jmp    66cdf0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f0>
  66d018:	b8 08 00 00 00       	mov    $0x8,%eax
  66d01d:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
  66d024:	00 
  66d025:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
  66d02c:	00 00 
  66d02e:	48 8b 6c 24 20       	mov    0x20(%rsp),%rbp
  66d033:	4c 8d 34 ad 00 00 00 	lea    0x0(,%rbp,4),%r14
  66d03a:	00 
  66d03b:	48 89 e8             	mov    %rbp,%rax
  66d03e:	48 c1 e8 3e          	shr    $0x3e,%rax
  66d042:	0f 95 c0             	setne  %al
  66d045:	48 b9 fc ff ff ff ff 	movabs $0x7ffffffffffffffc,%rcx
  66d04c:	ff ff 7f 
  66d04f:	49 39 ce             	cmp    %rcx,%r14
  66d052:	0f 97 c1             	seta   %cl
  66d055:	08 c1                	or     %al,%cl
  66d057:	0f 84 2a 02 00 00    	je     66d287 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x687>
  66d05d:	45 31 e4             	xor    %r12d,%r12d
  66d060:	b3 01                	mov    $0x1,%bl
  66d062:	4c 89 e7             	mov    %r12,%rdi
  66d065:	4c 89 f6             	mov    %r14,%rsi
  66d068:	4c 8b 64 24 18       	mov    0x18(%rsp),%r12
  66d06d:	ff 15 7d cf 11 00    	call   *0x11cf7d(%rip)        # 789ff0 <_DYNAMIC+0x350>
  66d073:	e9 bc 15 00 00       	jmp    66e634 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a34>
  66d078:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
  66d07f:	00 00 
  66d081:	48 8d ac 24 30 03 00 	lea    0x330(%rsp),%rbp
  66d088:	00 
  66d089:	48 c7 84 24 90 00 00 	movq   $0x0,0x90(%rsp)
  66d090:	00 00 00 00 00 
  66d095:	4c 8b 74 24 50       	mov    0x50(%rsp),%r14
  66d09a:	45 31 ed             	xor    %r13d,%r13d
  66d09d:	eb 25                	jmp    66d0c4 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x4c4>
  66d09f:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  66d0a4:	49 89 c6             	mov    %rax,%r14
  66d0a7:	8b 4c 24 40          	mov    0x40(%rsp),%ecx
  66d0ab:	41 89 cd             	mov    %ecx,%r13d
  66d0ae:	48 3b 84 24 60 01 00 	cmp    0x160(%rsp),%rax
  66d0b5:	00 
  66d0b6:	4c 8b bc 24 30 01 00 	mov    0x130(%rsp),%r15
  66d0bd:	00 
  66d0be:	0f 84 6a ff ff ff    	je     66d02e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x42e>
  66d0c4:	49 8b 76 10          	mov    0x10(%r14),%rsi
  66d0c8:	49 8b 56 18          	mov    0x18(%r14),%rdx
  66d0cc:	48 89 df             	mov    %rbx,%rdi
  66d0cf:	48 8d 8c 24 a8 00 00 	lea    0xa8(%rsp),%rcx
  66d0d6:	00 
  66d0d7:	e8 54 23 00 00       	call   66f430 <parley::editing::geometry::source_runs::<()>>
  66d0dc:	48 83 f8 01          	cmp    $0x1,%rax
  66d0e0:	0f 85 ac 12 00 00    	jne    66e392 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1792>
  66d0e6:	49 8d 46 70          	lea    0x70(%r14),%rax
  66d0ea:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  66d0ef:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
  66d0f4:	41 8d 45 01          	lea    0x1(%r13),%eax
  66d0f8:	89 44 24 40          	mov    %eax,0x40(%rsp)
  66d0fc:	4c 8b bc 24 b0 00 00 	mov    0xb0(%rsp),%r15
  66d103:	00 
  66d104:	4c 8b ac 24 b8 00 00 	mov    0xb8(%rsp),%r13
  66d10b:	00 
  66d10c:	49 c1 e5 04          	shl    $0x4,%r13
  66d110:	4d 01 fd             	add    %r15,%r13
  66d113:	4c 89 bc 24 88 00 00 	mov    %r15,0x88(%rsp)
  66d11a:	00 
  66d11b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  66d120:	4d 39 ef             	cmp    %r13,%r15
  66d123:	0f 84 76 ff ff ff    	je     66d09f <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x49f>
  66d129:	49 8b 07             	mov    (%r15),%rax
  66d12c:	49 83 c7 10          	add    $0x10,%r15
  66d130:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  66d134:	74 ea                	je     66d120 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x520>
  66d136:	49 8b 4e 10          	mov    0x10(%r14),%rcx
  66d13a:	48 01 c1             	add    %rax,%rcx
  66d13d:	4c 89 f2             	mov    %r14,%rdx
  66d140:	41 be fe ff ff ff    	mov    $0xfffffffe,%r14d
  66d146:	b3 01                	mov    $0x1,%bl
  66d148:	48 89 94 24 c0 00 00 	mov    %rdx,0xc0(%rsp)
  66d14f:	00 
  66d150:	48 3b 4a 18          	cmp    0x18(%rdx),%rcx
  66d154:	0f 83 34 13 00 00    	jae    66e48e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x188e>
  66d15a:	48 3b 8c 24 00 01 00 	cmp    0x100(%rsp),%rcx
  66d161:	00 
  66d162:	0f 83 26 13 00 00    	jae    66e48e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x188e>
  66d168:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
  66d16c:	48 8b 94 24 f0 00 00 	mov    0xf0(%rsp),%rdx
  66d173:	00 
  66d174:	80 7c ca 21 00       	cmpb   $0x0,0x21(%rdx,%rcx,8)
  66d179:	0f 85 0f 13 00 00    	jne    66e48e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x188e>
  66d17f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
  66d183:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
  66d187:	48 3b 4c 24 70       	cmp    0x70(%rsp),%rcx
  66d18c:	0f 83 fc 12 00 00    	jae    66e48e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x188e>
  66d192:	48 8d 1c c9          	lea    (%rcx,%rcx,8),%rbx
  66d196:	48 c1 e3 04          	shl    $0x4,%rbx
  66d19a:	48 03 5c 24 68       	add    0x68(%rsp),%rbx
  66d19f:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
  66d1a3:	48 c1 e6 04          	shl    $0x4,%rsi
  66d1a7:	48 03 74 24 10       	add    0x10(%rsp),%rsi
  66d1ac:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  66d1b1:	48 89 bc 24 30 03 00 	mov    %rdi,0x330(%rsp)
  66d1b8:	00 
  66d1b9:	48 89 9c 24 38 03 00 	mov    %rbx,0x338(%rsp)
  66d1c0:	00 
  66d1c1:	48 89 b4 24 40 03 00 	mov    %rsi,0x340(%rsp)
  66d1c8:	00 
  66d1c9:	48 89 94 24 48 03 00 	mov    %rdx,0x348(%rsp)
  66d1d0:	00 
  66d1d1:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
  66d1d6:	89 94 24 50 03 00 00 	mov    %edx,0x350(%rsp)
  66d1dd:	89 84 24 54 03 00 00 	mov    %eax,0x354(%rsp)
  66d1e4:	89 8c 24 58 03 00 00 	mov    %ecx,0x358(%rsp)
  66d1eb:	4c 8d b4 24 98 06 00 	lea    0x698(%rsp),%r14
  66d1f2:	00 
  66d1f3:	4c 89 f7             	mov    %r14,%rdi
  66d1f6:	48 89 ee             	mov    %rbp,%rsi
  66d1f9:	31 d2                	xor    %edx,%edx
  66d1fb:	e8 10 db 00 00       	call   67ad10 <<parley::layout::run::Clusters<()>>::new>
  66d200:	ba 10 01 00 00       	mov    $0x110,%edx
  66d205:	48 89 ef             	mov    %rbp,%rdi
  66d208:	4c 89 f6             	mov    %r14,%rsi
  66d20b:	ff 15 5f cd 11 00    	call   *0x11cd5f(%rip)        # 789f70 <memcpy@GLIBC_2.14>
  66d211:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  66d218:	00 
  66d219:	4c 8d 60 01          	lea    0x1(%rax),%r12
  66d21d:	45 31 f6             	xor    %r14d,%r14d
  66d220:	48 8d bc 24 00 02 00 	lea    0x200(%rsp),%rdi
  66d227:	00 
  66d228:	48 89 ee             	mov    %rbp,%rsi
  66d22b:	e8 40 03 01 00       	call   67d570 <<parley::layout::run::Clusters<()> as core::iter::traits::iterator::Iterator>::next>
  66d230:	48 83 bc 24 00 02 00 	cmpq   $0x0,0x200(%rsp)
  66d237:	00 00 
  66d239:	74 0e                	je     66d249 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x649>
  66d23b:	4d 39 f4             	cmp    %r14,%r12
  66d23e:	0f 84 3d 12 00 00    	je     66e481 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1881>
  66d244:	49 ff ce             	dec    %r14
  66d247:	eb d7                	jmp    66d220 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x620>
  66d249:	4c 29 b4 24 90 00 00 	sub    %r14,0x90(%rsp)
  66d250:	00 
  66d251:	49 f7 de             	neg    %r14
  66d254:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  66d259:	49 39 c6             	cmp    %rax,%r14
  66d25c:	4c 0f 46 f0          	cmovbe %rax,%r14
  66d260:	f6 83 8c 00 00 00 01 	testb  $0x1,0x8c(%rbx)
  66d267:	49 0f 45 c6          	cmovne %r14,%rax
  66d26b:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  66d270:	4c 8b 64 24 18       	mov    0x18(%rsp),%r12
  66d275:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
  66d27a:	4c 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%r14
  66d281:	00 
  66d282:	e9 99 fe ff ff       	jmp    66d120 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x520>
  66d287:	4d 85 f6             	test   %r14,%r14
  66d28a:	74 32                	je     66d2be <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x6be>
  66d28c:	ff 15 d6 cc 11 00    	call   *0x11ccd6(%rip)        # 789f68 <_DYNAMIC+0x2c8>
  66d292:	41 bc 04 00 00 00    	mov    $0x4,%r12d
  66d298:	be 04 00 00 00       	mov    $0x4,%esi
  66d29d:	4c 89 f7             	mov    %r14,%rdi
  66d2a0:	ff 15 2a cc 11 00    	call   *0x11cc2a(%rip)        # 789ed0 <_DYNAMIC+0x230>
  66d2a6:	48 85 c0             	test   %rax,%rax
  66d2a9:	4c 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13
  66d2b0:	00 
  66d2b1:	0f 84 a9 fd ff ff    	je     66d060 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x460>
  66d2b7:	4c 8b 64 24 18       	mov    0x18(%rsp),%r12
  66d2bc:	eb 0f                	jmp    66d2cd <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x6cd>
  66d2be:	b8 04 00 00 00       	mov    $0x4,%eax
  66d2c3:	31 ed                	xor    %ebp,%ebp
  66d2c5:	4c 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13
  66d2cc:	00 
  66d2cd:	48 89 ac 24 38 01 00 	mov    %rbp,0x138(%rsp)
  66d2d4:	00 
  66d2d5:	48 89 84 24 40 01 00 	mov    %rax,0x140(%rsp)
  66d2dc:	00 
  66d2dd:	48 c7 84 24 48 01 00 	movq   $0x0,0x148(%rsp)
  66d2e4:	00 00 00 00 00 
  66d2e9:	48 8d bc 24 60 04 00 	lea    0x460(%rsp),%rdi
  66d2f0:	00 
  66d2f1:	ba 98 00 00 00       	mov    $0x98,%edx
  66d2f6:	4c 89 e6             	mov    %r12,%rsi
  66d2f9:	ff 15 71 cc 11 00    	call   *0x11cc71(%rip)        # 789f70 <memcpy@GLIBC_2.14>
  66d2ff:	48 c7 84 24 50 04 00 	movq   $0x2,0x450(%rsp)
  66d306:	00 02 00 00 00 
  66d30b:	4d 85 ed             	test   %r13,%r13
  66d30e:	0f 84 4a 10 00 00    	je     66e35e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x175e>
  66d314:	48 8b 83 30 01 00 00 	mov    0x130(%rbx),%rax
  66d31b:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  66d320:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
  66d327:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
  66d32c:	48 8b 43 58          	mov    0x58(%rbx),%rax
  66d330:	48 8b 8b e8 00 00 00 	mov    0xe8(%rbx),%rcx
  66d337:	48 39 c8             	cmp    %rcx,%rax
  66d33a:	48 89 8c 24 c8 01 00 	mov    %rcx,0x1c8(%rsp)
  66d341:	00 
  66d342:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
  66d349:	00 
  66d34a:	48 0f 42 c8          	cmovb  %rax,%rcx
  66d34e:	48 89 8c 24 18 03 00 	mov    %rcx,0x318(%rsp)
  66d355:	00 
  66d356:	48 8b 83 e0 00 00 00 	mov    0xe0(%rbx),%rax
  66d35d:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
  66d364:	00 
  66d365:	48 8b 43 50          	mov    0x50(%rbx),%rax
  66d369:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
  66d370:	00 
  66d371:	4c 8d ac 24 38 03 00 	lea    0x338(%rsp),%r13
  66d378:	00 
  66d379:	48 8b 43 38          	mov    0x38(%rbx),%rax
  66d37d:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
  66d384:	00 
  66d385:	48 8b 43 40          	mov    0x40(%rbx),%rax
  66d389:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  66d390:	00 
  66d391:	48 8d 8c 24 a8 00 00 	lea    0xa8(%rsp),%rcx
  66d398:	00 
  66d399:	48 8d 05 38 23 11 00 	lea    0x112338(%rip),%rax        # 77f6d8 <__frame_dummy_init_array_entry+0x798>
  66d3a0:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
  66d3a7:	00 
  66d3a8:	48 8d 05 e9 23 11 00 	lea    0x1123e9(%rip),%rax        # 77f798 <anon.abe2914d8fd9d1076326722b06c47a5f.25.llvm.962491032109686297>
  66d3af:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  66d3b4:	48 c7 84 24 c0 01 00 	movq   $0x0,0x1c0(%rsp)
  66d3bb:	00 00 00 00 00 
  66d3c0:	48 c7 44 24 70 00 00 	movq   $0x0,0x70(%rsp)
  66d3c7:	00 00 
  66d3c9:	eb 34                	jmp    66d3ff <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x7ff>
  66d3cb:	48 8b 8c 24 20 03 00 	mov    0x320(%rsp),%rcx
  66d3d2:	00 
  66d3d3:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
  66d3d8:	8b 84 24 8c 01 00 00 	mov    0x18c(%rsp),%eax
  66d3df:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  66d3e4:	48 3b 8c 24 60 01 00 	cmp    0x160(%rsp),%rcx
  66d3eb:	00 
  66d3ec:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
  66d3f1:	48 8d 8c 24 a8 00 00 	lea    0xa8(%rsp),%rcx
  66d3f8:	00 
  66d3f9:	0f 84 5f 0f 00 00    	je     66e35e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x175e>
  66d3ff:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  66d404:	48 8b 70 10          	mov    0x10(%rax),%rsi
  66d408:	48 8b 50 18          	mov    0x18(%rax),%rdx
  66d40c:	48 89 df             	mov    %rbx,%rdi
  66d40f:	e8 1c 20 00 00       	call   66f430 <parley::editing::geometry::source_runs::<()>>
  66d414:	48 83 f8 01          	cmp    $0x1,%rax
  66d418:	0f 85 f3 10 00 00    	jne    66e511 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1911>
  66d41e:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  66d423:	48 8b 78 10          	mov    0x10(%rax),%rdi
  66d427:	48 8b 70 18          	mov    0x18(%rax),%rsi
  66d42b:	48 39 fe             	cmp    %rdi,%rsi
  66d42e:	0f 82 c6 10 00 00    	jb     66e4fa <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18fa>
  66d434:	48 3b 74 24 10       	cmp    0x10(%rsp),%rsi
  66d439:	0f 87 bb 10 00 00    	ja     66e4fa <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18fa>
  66d43f:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
  66d446:	00 
  66d447:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
  66d44e:	00 
  66d44f:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  66d456:	00 
  66d457:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  66d45c:	48 39 f7             	cmp    %rsi,%rdi
  66d45f:	0f 85 74 0d 00 00    	jne    66e1d9 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x15d9>
  66d465:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  66d46a:	48 83 c0 70          	add    $0x70,%rax
  66d46e:	48 89 84 24 20 03 00 	mov    %rax,0x320(%rsp)
  66d475:	00 
  66d476:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  66d47b:	ff c0                	inc    %eax
  66d47d:	89 84 24 8c 01 00 00 	mov    %eax,0x18c(%rsp)
  66d484:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  66d489:	48 c1 e0 04          	shl    $0x4,%rax
  66d48d:	48 8b 9c 24 88 00 00 	mov    0x88(%rsp),%rbx
  66d494:	00 
  66d495:	48 01 d8             	add    %rbx,%rax
  66d498:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  66d49d:	4c 8b bc 24 30 01 00 	mov    0x130(%rsp),%r15
  66d4a4:	00 
  66d4a5:	4c 8b 64 24 18       	mov    0x18(%rsp),%r12
  66d4aa:	4c 8d b4 24 00 02 00 	lea    0x200(%rsp),%r14
  66d4b1:	00 
  66d4b2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  66d4b9:	1f 84 00 00 00 00 00 
  66d4c0:	48 3b 5c 24 20       	cmp    0x20(%rsp),%rbx
  66d4c5:	0f 84 00 ff ff ff    	je     66d3cb <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x7cb>
  66d4cb:	48 8b 03             	mov    (%rbx),%rax
  66d4ce:	48 83 c3 10          	add    $0x10,%rbx
  66d4d2:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  66d4d6:	74 e8                	je     66d4c0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x8c0>
  66d4d8:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
  66d4dd:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
  66d4e1:	48 01 c1             	add    %rax,%rcx
  66d4e4:	48 3b 4a 18          	cmp    0x18(%rdx),%rcx
  66d4e8:	0f 83 0f 11 00 00    	jae    66e5fd <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19fd>
  66d4ee:	48 3b 4c 24 10       	cmp    0x10(%rsp),%rcx
  66d4f3:	0f 83 04 11 00 00    	jae    66e5fd <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19fd>
  66d4f9:	48 8d 14 89          	lea    (%rcx,%rcx,4),%rdx
  66d4fd:	48 8b 74 24 68       	mov    0x68(%rsp),%rsi
  66d502:	48 8b 4c d6 10       	mov    0x10(%rsi,%rdx,8),%rcx
  66d507:	80 7c d6 21 01       	cmpb   $0x1,0x21(%rsi,%rdx,8)
  66d50c:	0f 84 c9 10 00 00    	je     66e5db <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19db>
  66d512:	48 3b 8c 24 18 03 00 	cmp    0x318(%rsp),%rcx
  66d519:	00 
  66d51a:	0f 83 dd 10 00 00    	jae    66e5fd <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19fd>
  66d520:	f3 0f 10 43 f8       	movss  -0x8(%rbx),%xmm0
  66d525:	f3 0f 11 44 24 48    	movss  %xmm0,0x48(%rsp)
  66d52b:	48 8b 74 24 68       	mov    0x68(%rsp),%rsi
  66d530:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
  66d534:	48 8d 34 c9          	lea    (%rcx,%rcx,8),%rsi
  66d538:	48 c1 e6 04          	shl    $0x4,%rsi
  66d53c:	4c 8b 94 24 20 01 00 	mov    0x120(%rsp),%r10
  66d543:	00 
  66d544:	49 8d 3c 32          	lea    (%r10,%rsi,1),%rdi
  66d548:	4c 8d 04 89          	lea    (%rcx,%rcx,4),%r8
  66d54c:	49 c1 e0 04          	shl    $0x4,%r8
  66d550:	4c 03 84 24 28 01 00 	add    0x128(%rsp),%r8
  66d557:	00 
  66d558:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
  66d55d:	4c 89 8c 24 d0 01 00 	mov    %r9,0x1d0(%rsp)
  66d564:	00 
  66d565:	48 89 bc 24 d8 01 00 	mov    %rdi,0x1d8(%rsp)
  66d56c:	00 
  66d56d:	4c 89 84 24 e0 01 00 	mov    %r8,0x1e0(%rsp)
  66d574:	00 
  66d575:	48 89 94 24 e8 01 00 	mov    %rdx,0x1e8(%rsp)
  66d57c:	00 
  66d57d:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
  66d582:	89 94 24 f0 01 00 00 	mov    %edx,0x1f0(%rsp)
  66d589:	89 84 24 f4 01 00 00 	mov    %eax,0x1f4(%rsp)
  66d590:	89 8c 24 f8 01 00 00 	mov    %ecx,0x1f8(%rsp)
  66d597:	48 c7 84 24 48 01 00 	movq   $0x0,0x148(%rsp)
  66d59e:	00 00 00 00 00 
  66d5a3:	41 0f b6 84 32 8c 00 	movzbl 0x8c(%r10,%rsi,1),%eax
  66d5aa:	00 00 
  66d5ac:	88 44 24 2f          	mov    %al,0x2f(%rsp)
  66d5b0:	a8 01                	test   $0x1,%al
  66d5b2:	0f 84 fa 01 00 00    	je     66d7b2 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xbb2>
  66d5b8:	48 8b 84 24 d0 01 00 	mov    0x1d0(%rsp),%rax
  66d5bf:	00 
  66d5c0:	48 8b 8c 24 d8 01 00 	mov    0x1d8(%rsp),%rcx
  66d5c7:	00 
  66d5c8:	48 8b 94 24 e0 01 00 	mov    0x1e0(%rsp),%rdx
  66d5cf:	00 
  66d5d0:	48 8b b4 24 e8 01 00 	mov    0x1e8(%rsp),%rsi
  66d5d7:	00 
  66d5d8:	8b bc 24 f0 01 00 00 	mov    0x1f0(%rsp),%edi
  66d5df:	89 bc 24 50 03 00 00 	mov    %edi,0x350(%rsp)
  66d5e6:	8b bc 24 f4 01 00 00 	mov    0x1f4(%rsp),%edi
  66d5ed:	89 bc 24 54 03 00 00 	mov    %edi,0x354(%rsp)
  66d5f4:	8b bc 24 f8 01 00 00 	mov    0x1f8(%rsp),%edi
  66d5fb:	89 bc 24 58 03 00 00 	mov    %edi,0x358(%rsp)
  66d602:	8b bc 24 fc 01 00 00 	mov    0x1fc(%rsp),%edi
  66d609:	89 bc 24 5c 03 00 00 	mov    %edi,0x35c(%rsp)
  66d610:	48 89 94 24 40 03 00 	mov    %rdx,0x340(%rsp)
  66d617:	00 
  66d618:	48 89 b4 24 48 03 00 	mov    %rsi,0x348(%rsp)
  66d61f:	00 
  66d620:	48 89 84 24 30 03 00 	mov    %rax,0x330(%rsp)
  66d627:	00 
  66d628:	48 89 8c 24 38 03 00 	mov    %rcx,0x338(%rsp)
  66d62f:	00 
  66d630:	48 8d bc 24 88 05 00 	lea    0x588(%rsp),%rdi
  66d637:	00 
  66d638:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
  66d63f:	00 
  66d640:	ba 01 00 00 00       	mov    $0x1,%edx
  66d645:	e8 c6 d6 00 00       	call   67ad10 <<parley::layout::run::Clusters<()>>::new>
  66d64a:	ba 10 01 00 00       	mov    $0x110,%edx
  66d64f:	48 8d bc 24 30 03 00 	lea    0x330(%rsp),%rdi
  66d656:	00 
  66d657:	48 8d b4 24 88 05 00 	lea    0x588(%rsp),%rsi
  66d65e:	00 
  66d65f:	ff 15 0b c9 11 00    	call   *0x11c90b(%rip)        # 789f70 <memcpy@GLIBC_2.14>
  66d665:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  66d66c:	00 00 00 00 
  66d670:	48 8d bc 24 f8 04 00 	lea    0x4f8(%rsp),%rdi
  66d677:	00 
  66d678:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
  66d67f:	00 
  66d680:	e8 eb fe 00 00       	call   67d570 <<parley::layout::run::Clusters<()> as core::iter::traits::iterator::Iterator>::next>
  66d685:	48 83 bc 24 f8 04 00 	cmpq   $0x0,0x4f8(%rsp)
  66d68c:	00 00 
  66d68e:	0f 84 16 01 00 00    	je     66d7aa <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xbaa>
  66d694:	ba 90 00 00 00       	mov    $0x90,%edx
  66d699:	48 8d bc 24 00 02 00 	lea    0x200(%rsp),%rdi
  66d6a0:	00 
  66d6a1:	48 8d b4 24 f8 04 00 	lea    0x4f8(%rsp),%rsi
  66d6a8:	00 
  66d6a9:	ff 15 c1 c8 11 00    	call   *0x11c8c1(%rip)        # 789f70 <memcpy@GLIBC_2.14>
  66d6af:	4c 8b b4 24 48 01 00 	mov    0x148(%rsp),%r14
  66d6b6:	00 
  66d6b7:	4c 3b b4 24 38 01 00 	cmp    0x138(%rsp),%r14
  66d6be:	00 
  66d6bf:	75 0e                	jne    66d6cf <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xacf>
  66d6c1:	48 8d bc 24 38 01 00 	lea    0x138(%rsp),%rdi
  66d6c8:	00 
  66d6c9:	ff 15 a9 ca 11 00    	call   *0x11caa9(%rip)        # 78a178 <_DYNAMIC+0x4d8>
  66d6cf:	48 8b 84 24 40 01 00 	mov    0x140(%rsp),%rax
  66d6d6:	00 
  66d6d7:	f3 0f 10 44 24 48    	movss  0x48(%rsp),%xmm0
  66d6dd:	f3 42 0f 11 04 b0    	movss  %xmm0,(%rax,%r14,4)
  66d6e3:	49 ff c6             	inc    %r14
  66d6e6:	4c 89 b4 24 48 01 00 	mov    %r14,0x148(%rsp)
  66d6ed:	00 
  66d6ee:	48 83 bc 24 18 02 00 	cmpq   $0x0,0x218(%rsp)
  66d6f5:	00 00 
  66d6f7:	74 3e                	je     66d737 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xb37>
  66d6f9:	48 8b 84 24 00 02 00 	mov    0x200(%rsp),%rax
  66d700:	00 
  66d701:	8b ac 24 20 02 00 00 	mov    0x220(%rsp),%ebp
  66d708:	48 8b 88 18 01 00 00 	mov    0x118(%rax),%rcx
  66d70f:	48 39 e9             	cmp    %rbp,%rcx
  66d712:	0f 86 f8 0e 00 00    	jbe    66e610 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a10>
  66d718:	48 8b 80 10 01 00 00 	mov    0x110(%rax),%rax
  66d71f:	48 6b cd 70          	imul   $0x70,%rbp,%rcx
  66d723:	f3 0f 10 44 08 50    	movss  0x50(%rax,%rcx,1),%xmm0
  66d729:	8b 44 08 54          	mov    0x54(%rax,%rcx,1),%eax
  66d72d:	4c 8d ac 24 38 03 00 	lea    0x338(%rsp),%r13
  66d734:	00 
  66d735:	eb 08                	jmp    66d73f <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xb3f>
  66d737:	0f 57 c0             	xorps  %xmm0,%xmm0
  66d73a:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  66d73f:	48 8b 8c 24 08 02 00 	mov    0x208(%rsp),%rcx
  66d746:	00 
  66d747:	48 8b 94 24 10 02 00 	mov    0x210(%rsp),%rdx
  66d74e:	00 
  66d74f:	f2 0f 10 4a 44       	movsd  0x44(%rdx),%xmm1
  66d754:	f2 0f 11 8c 24 68 01 	movsd  %xmm1,0x168(%rsp)
  66d75b:	00 00 
  66d75d:	f3 0f 11 84 24 70 01 	movss  %xmm0,0x170(%rsp)
  66d764:	00 00 
  66d766:	89 84 24 74 01 00 00 	mov    %eax,0x174(%rsp)
  66d76d:	0f b6 89 8c 00 00 00 	movzbl 0x8c(%rcx),%ecx
  66d774:	83 e1 01             	and    $0x1,%ecx
  66d777:	48 8d bc 24 68 01 00 	lea    0x168(%rsp),%rdi
  66d77e:	00 
  66d77f:	48 8d b4 24 30 02 00 	lea    0x230(%rsp),%rsi
  66d786:	00 
  66d787:	48 8d 94 24 80 02 00 	lea    0x280(%rsp),%rdx
  66d78e:	00 
  66d78f:	ff 15 fb cb 11 00    	call   *0x11cbfb(%rip)        # 78a390 <_DYNAMIC+0x6f0>
  66d795:	f3 0f 10 4c 24 48    	movss  0x48(%rsp),%xmm1
  66d79b:	f3 0f 58 c8          	addss  %xmm0,%xmm1
  66d79f:	f3 0f 11 4c 24 48    	movss  %xmm1,0x48(%rsp)
  66d7a5:	e9 c6 fe ff ff       	jmp    66d670 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xa70>
  66d7aa:	4c 8d b4 24 00 02 00 	lea    0x200(%rsp),%r14
  66d7b1:	00 
  66d7b2:	4c 89 f7             	mov    %r14,%rdi
  66d7b5:	48 8d b4 24 d0 01 00 	lea    0x1d0(%rsp),%rsi
  66d7bc:	00 
  66d7bd:	31 d2                	xor    %edx,%edx
  66d7bf:	e8 4c d5 00 00       	call   67ad10 <<parley::layout::run::Clusters<()>>::new>
  66d7c4:	ba 10 01 00 00       	mov    $0x110,%edx
  66d7c9:	4c 89 ef             	mov    %r13,%rdi
  66d7cc:	4c 89 f6             	mov    %r14,%rsi
  66d7cf:	ff 15 9b c7 11 00    	call   *0x11c79b(%rip)        # 789f70 <memcpy@GLIBC_2.14>
  66d7d5:	48 c7 84 24 30 03 00 	movq   $0x0,0x330(%rsp)
  66d7dc:	00 00 00 00 00 
  66d7e1:	0f 57 c0             	xorps  %xmm0,%xmm0
  66d7e4:	f3 0f 11 44 24 7c    	movss  %xmm0,0x7c(%rsp)
  66d7ea:	45 31 e4             	xor    %r12d,%r12d
  66d7ed:	c7 44 24 3c 00 00 00 	movl   $0x0,0x3c(%rsp)
  66d7f4:	00 
  66d7f5:	4c 89 f7             	mov    %r14,%rdi
  66d7f8:	4c 89 ee             	mov    %r13,%rsi
  66d7fb:	e8 70 fd 00 00       	call   67d570 <<parley::layout::run::Clusters<()> as core::iter::traits::iterator::Iterator>::next>
  66d800:	4c 8b b4 24 00 02 00 	mov    0x200(%rsp),%r14
  66d807:	00 
  66d808:	4d 85 f6             	test   %r14,%r14
  66d80b:	0f 84 bb 09 00 00    	je     66e1cc <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x15cc>
  66d811:	ba 88 00 00 00       	mov    $0x88,%edx
  66d816:	48 8d bc 24 00 05 00 	lea    0x500(%rsp),%rdi
  66d81d:	00 
  66d81e:	48 8d b4 24 08 02 00 	lea    0x208(%rsp),%rsi
  66d825:	00 
  66d826:	ff 15 44 c7 11 00    	call   *0x11c744(%rip)        # 789f70 <memcpy@GLIBC_2.14>
  66d82c:	4c 89 f2             	mov    %r14,%rdx
  66d82f:	4c 8b b4 24 30 03 00 	mov    0x330(%rsp),%r14
  66d836:	00 
  66d837:	49 8d 46 01          	lea    0x1(%r14),%rax
  66d83b:	48 89 84 24 30 03 00 	mov    %rax,0x330(%rsp)
  66d842:	00 
  66d843:	48 89 94 24 f8 04 00 	mov    %rdx,0x4f8(%rsp)
  66d84a:	00 
  66d84b:	8b ac 24 20 05 00 00 	mov    0x520(%rsp),%ebp
  66d852:	48 8b 42 58          	mov    0x58(%rdx),%rax
  66d856:	48 39 e8             	cmp    %rbp,%rax
  66d859:	0f 86 50 0d 00 00    	jbe    66e5af <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19af>
  66d85f:	48 8b 42 50          	mov    0x50(%rdx),%rax
  66d863:	48 8d 0c ed 00 00 00 	lea    0x0(,%rbp,8),%rcx
  66d86a:	00 
  66d86b:	48 01 e9             	add    %rbp,%rcx
  66d86e:	48 c1 e1 04          	shl    $0x4,%rcx
  66d872:	0f 10 42 68          	movups 0x68(%rdx),%xmm0
  66d876:	0f 10 8a 80 00 00 00 	movups 0x80(%rdx),%xmm1
  66d87d:	48 89 54 24 60       	mov    %rdx,0x60(%rsp)
  66d882:	0f 10 92 98 00 00 00 	movups 0x98(%rdx),%xmm2
  66d889:	0f 11 84 24 00 02 00 	movups %xmm0,0x200(%rsp)
  66d890:	00 
  66d891:	0f 11 8c 24 10 02 00 	movups %xmm1,0x210(%rsp)
  66d898:	00 
  66d899:	0f 11 94 24 20 02 00 	movups %xmm2,0x220(%rsp)
  66d8a0:	00 
  66d8a1:	48 8b 44 08 50       	mov    0x50(%rax,%rcx,1),%rax
  66d8a6:	48 89 84 24 30 02 00 	mov    %rax,0x230(%rsp)
  66d8ad:	00 
  66d8ae:	8b b4 24 78 05 00 00 	mov    0x578(%rsp),%esi
  66d8b5:	8b 94 24 7c 05 00 00 	mov    0x57c(%rsp),%edx
  66d8bc:	48 8d bc 24 00 02 00 	lea    0x200(%rsp),%rdi
  66d8c3:	00 
  66d8c4:	48 89 b4 24 58 01 00 	mov    %rsi,0x158(%rsp)
  66d8cb:	00 
  66d8cc:	48 89 94 24 50 01 00 	mov    %rdx,0x150(%rsp)
  66d8d3:	00 
  66d8d4:	ff 15 76 ca 11 00    	call   *0x11ca76(%rip)        # 78a350 <_DYNAMIC+0x6b0>
  66d8da:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  66d8df:	48 89 54 24 58       	mov    %rdx,0x58(%rsp)
  66d8e4:	f6 44 24 2f 01       	testb  $0x1,0x2f(%rsp)
  66d8e9:	75 4a                	jne    66d935 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xd35>
  66d8eb:	48 83 bc 24 10 05 00 	cmpq   $0x0,0x510(%rsp)
  66d8f2:	00 00 
  66d8f4:	0f 84 a9 00 00 00    	je     66d9a3 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xda3>
  66d8fa:	8b 84 24 18 05 00 00 	mov    0x518(%rsp),%eax
  66d901:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  66d906:	48 8b 8a 18 01 00 00 	mov    0x118(%rdx),%rcx
  66d90d:	48 39 c1             	cmp    %rax,%rcx
  66d910:	48 8d bc 24 00 02 00 	lea    0x200(%rsp),%rdi
  66d917:	00 
  66d918:	0f 86 ef 0c 00 00    	jbe    66e60d <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a0d>
  66d91e:	48 8b 8a 10 01 00 00 	mov    0x110(%rdx),%rcx
  66d925:	48 6b c0 70          	imul   $0x70,%rax,%rax
  66d929:	f3 0f 10 44 01 50    	movss  0x50(%rcx,%rax,1),%xmm0
  66d92f:	8b 44 01 54          	mov    0x54(%rcx,%rax,1),%eax
  66d933:	eb 7e                	jmp    66d9b3 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xdb3>
  66d935:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  66d93c:	00 
  66d93d:	49 f7 d6             	not    %r14
  66d940:	49 01 c6             	add    %rax,%r14
  66d943:	0f 83 81 0c 00 00    	jae    66e5ca <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19ca>
  66d949:	48 8b 84 24 40 01 00 	mov    0x140(%rsp),%rax
  66d950:	00 
  66d951:	f3 0f 10 44 24 7c    	movss  0x7c(%rsp),%xmm0
  66d957:	f3 0f 11 84 24 a0 01 	movss  %xmm0,0x1a0(%rsp)
  66d95e:	00 00 
  66d960:	f3 42 0f 10 04 b0    	movss  (%rax,%r14,4),%xmm0
  66d966:	f3 0f 11 44 24 7c    	movss  %xmm0,0x7c(%rsp)
  66d96c:	48 8b 84 24 50 04 00 	mov    0x450(%rsp),%rax
  66d973:	00 
  66d974:	48 83 f8 02          	cmp    $0x2,%rax
  66d978:	0f 85 b4 00 00 00    	jne    66da32 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xe32>
  66d97e:	48 8d bc 24 60 04 00 	lea    0x460(%rsp),%rdi
  66d985:	00 
  66d986:	e8 15 d0 ff ff       	call   66a9a0 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  66d98b:	49 89 d5             	mov    %rdx,%r13
  66d98e:	48 89 84 24 50 04 00 	mov    %rax,0x450(%rsp)
  66d995:	00 
  66d996:	48 89 94 24 58 04 00 	mov    %rdx,0x458(%rsp)
  66d99d:	00 
  66d99e:	e9 97 00 00 00       	jmp    66da3a <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xe3a>
  66d9a3:	0f 57 c0             	xorps  %xmm0,%xmm0
  66d9a6:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  66d9ab:	48 8d bc 24 00 02 00 	lea    0x200(%rsp),%rdi
  66d9b2:	00 
  66d9b3:	48 8b 8c 24 00 05 00 	mov    0x500(%rsp),%rcx
  66d9ba:	00 
  66d9bb:	48 8b 94 24 08 05 00 	mov    0x508(%rsp),%rdx
  66d9c2:	00 
  66d9c3:	f2 0f 10 4a 44       	movsd  0x44(%rdx),%xmm1
  66d9c8:	f2 0f 11 8c 24 00 02 	movsd  %xmm1,0x200(%rsp)
  66d9cf:	00 00 
  66d9d1:	f3 0f 11 84 24 08 02 	movss  %xmm0,0x208(%rsp)
  66d9d8:	00 00 
  66d9da:	89 84 24 0c 02 00 00 	mov    %eax,0x20c(%rsp)
  66d9e1:	0f b6 89 8c 00 00 00 	movzbl 0x8c(%rcx),%ecx
  66d9e8:	83 e1 01             	and    $0x1,%ecx
  66d9eb:	48 8d b4 24 28 05 00 	lea    0x528(%rsp),%rsi
  66d9f2:	00 
  66d9f3:	48 8d 94 24 78 05 00 	lea    0x578(%rsp),%rdx
  66d9fa:	00 
  66d9fb:	ff 15 8f c9 11 00    	call   *0x11c98f(%rip)        # 78a390 <_DYNAMIC+0x6f0>
  66da01:	f3 0f 10 4c 24 48    	movss  0x48(%rsp),%xmm1
  66da07:	f3 0f 58 c1          	addss  %xmm1,%xmm0
  66da0b:	f3 0f 11 8c 24 a0 01 	movss  %xmm1,0x1a0(%rsp)
  66da12:	00 00 
  66da14:	f3 0f 11 4c 24 7c    	movss  %xmm1,0x7c(%rsp)
  66da1a:	f3 0f 11 44 24 48    	movss  %xmm0,0x48(%rsp)
  66da20:	48 8b 84 24 50 04 00 	mov    0x450(%rsp),%rax
  66da27:	00 
  66da28:	48 83 f8 02          	cmp    $0x2,%rax
  66da2c:	0f 84 4c ff ff ff    	je     66d97e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xd7e>
  66da32:	4c 8b ac 24 58 04 00 	mov    0x458(%rsp),%r13
  66da39:	00 
  66da3a:	48 83 f8 01          	cmp    $0x1,%rax
  66da3e:	0f 85 6b 06 00 00    	jne    66e0af <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x14af>
  66da44:	4c 3b 6c 24 58       	cmp    0x58(%rsp),%r13
  66da49:	4c 8b 44 24 40       	mov    0x40(%rsp),%r8
  66da4e:	0f 83 5b 06 00 00    	jae    66e0af <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x14af>
  66da54:	4c 3b ac 24 90 01 00 	cmp    0x190(%rsp),%r13
  66da5b:	00 
  66da5c:	0f 92 c0             	setb   %al
  66da5f:	84 84 24 c0 01 00 00 	test   %al,0x1c0(%rsp)
  66da66:	0f 85 44 09 00 00    	jne    66e3b0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x17b0>
  66da6c:	f3 0f 10 8c 24 a0 01 	movss  0x1a0(%rsp),%xmm1
  66da73:	00 00 
  66da75:	0f 57 c0             	xorps  %xmm0,%xmm0
  66da78:	f3 0f 5a c1          	cvtss2sd %xmm1,%xmm0
  66da7c:	0f 29 84 24 90 01 00 	movaps %xmm0,0x190(%rsp)
  66da83:	00 
  66da84:	f3 0f 58 4c 24 04    	addss  0x4(%rsp),%xmm1
  66da8a:	0f 57 c0             	xorps  %xmm0,%xmm0
  66da8d:	f3 0f 5a c1          	cvtss2sd %xmm1,%xmm0
  66da91:	0f 29 84 24 a0 01 00 	movaps %xmm0,0x1a0(%rsp)
  66da98:	00 
  66da99:	48 c7 84 24 50 04 00 	movq   $0x2,0x450(%rsp)
  66daa0:	00 02 00 00 00 
  66daa5:	4d 39 c5             	cmp    %r8,%r13
  66daa8:	0f 85 fc 00 00 00    	jne    66dbaa <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xfaa>
  66daae:	4d 39 c4             	cmp    %r8,%r12
  66dab1:	0f 94 c0             	sete   %al
  66dab4:	22 44 24 3c          	and    0x3c(%rsp),%al
  66dab8:	3c 01                	cmp    $0x1,%al
  66daba:	75 57                	jne    66db13 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xf13>
  66dabc:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  66dac1:	48 8b 41 58          	mov    0x58(%rcx),%rax
  66dac5:	48 39 e8             	cmp    %rbp,%rax
  66dac8:	0f 86 e1 0a 00 00    	jbe    66e5af <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19af>
  66dace:	48 8b 51 70          	mov    0x70(%rcx),%rdx
  66dad2:	48 8b bc 24 58 01 00 	mov    0x158(%rsp),%rdi
  66dad9:	00 
  66dada:	48 8b b4 24 50 01 00 	mov    0x150(%rsp),%rsi
  66dae1:	00 
  66dae2:	39 fe                	cmp    %edi,%esi
  66dae4:	0f 82 fe 09 00 00    	jb     66e4e8 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18e8>
  66daea:	48 39 f2             	cmp    %rsi,%rdx
  66daed:	0f 82 f5 09 00 00    	jb     66e4e8 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18e8>
  66daf3:	39 fe                	cmp    %edi,%esi
  66daf5:	0f 84 c2 0a 00 00    	je     66e5bd <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19bd>
  66dafb:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  66db00:	48 8b 40 68          	mov    0x68(%rax),%rax
  66db04:	48 8d 0c 7f          	lea    (%rdi,%rdi,2),%rcx
  66db08:	80 7c 88 07 06       	cmpb   $0x6,0x7(%rax,%rcx,4)
  66db0d:	0f 85 24 06 00 00    	jne    66e137 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1537>
  66db13:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  66db18:	4c 89 c6             	mov    %r8,%rsi
  66db1b:	ba 01 00 00 00       	mov    $0x1,%edx
  66db20:	e8 2b ad 00 00       	call   678850 <<parley::editing::cursor::Cursor>::from_byte_index::<()>>
  66db25:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
  66db2c:	00 
  66db2d:	80 e2 01             	and    $0x1,%dl
  66db30:	88 94 24 d8 00 00 00 	mov    %dl,0xd8(%rsp)
  66db37:	48 3b 44 24 40       	cmp    0x40(%rsp),%rax
  66db3c:	0f 85 62 01 00 00    	jne    66dca4 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x10a4>
  66db42:	48 8d bc 24 00 02 00 	lea    0x200(%rsp),%rdi
  66db49:	00 
  66db4a:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
  66db51:	00 
  66db52:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  66db57:	f3 0f 10 44 24 04    	movss  0x4(%rsp),%xmm0
  66db5d:	e8 ae ad 00 00       	call   678910 <<parley::editing::cursor::Cursor>::geometry::<()>>
  66db62:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  66db67:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
  66db6c:	31 d2                	xor    %edx,%edx
  66db6e:	e8 dd ac 00 00       	call   678850 <<parley::editing::cursor::Cursor>::from_byte_index::<()>>
  66db73:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
  66db7a:	00 
  66db7b:	80 e2 01             	and    $0x1,%dl
  66db7e:	88 94 24 e8 00 00 00 	mov    %dl,0xe8(%rsp)
  66db85:	48 8d bc 24 68 01 00 	lea    0x168(%rsp),%rdi
  66db8c:	00 
  66db8d:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
  66db94:	00 
  66db95:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  66db9a:	f3 0f 10 44 24 04    	movss  0x4(%rsp),%xmm0
  66dba0:	e8 6b ad 00 00       	call   678910 <<parley::editing::cursor::Cursor>::geometry::<()>>
  66dba5:	e9 94 00 00 00       	jmp    66dc3e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x103e>
  66dbaa:	0f 87 f4 00 00 00    	ja     66dca4 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x10a4>
  66dbb0:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  66dbb5:	4c 89 ee             	mov    %r13,%rsi
  66dbb8:	ba 01 00 00 00       	mov    $0x1,%edx
  66dbbd:	e8 8e ac 00 00       	call   678850 <<parley::editing::cursor::Cursor>::from_byte_index::<()>>
  66dbc2:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
  66dbc9:	00 
  66dbca:	80 e2 01             	and    $0x1,%dl
  66dbcd:	88 94 24 d8 00 00 00 	mov    %dl,0xd8(%rsp)
  66dbd4:	4c 39 e8             	cmp    %r13,%rax
  66dbd7:	0f 85 c7 00 00 00    	jne    66dca4 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x10a4>
  66dbdd:	48 8d bc 24 00 02 00 	lea    0x200(%rsp),%rdi
  66dbe4:	00 
  66dbe5:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
  66dbec:	00 
  66dbed:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  66dbf2:	f3 0f 10 44 24 04    	movss  0x4(%rsp),%xmm0
  66dbf8:	e8 13 ad 00 00       	call   678910 <<parley::editing::cursor::Cursor>::geometry::<()>>
  66dbfd:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  66dc02:	4c 89 ee             	mov    %r13,%rsi
  66dc05:	31 d2                	xor    %edx,%edx
  66dc07:	e8 44 ac 00 00       	call   678850 <<parley::editing::cursor::Cursor>::from_byte_index::<()>>
  66dc0c:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
  66dc13:	00 
  66dc14:	80 e2 01             	and    $0x1,%dl
  66dc17:	88 94 24 e8 00 00 00 	mov    %dl,0xe8(%rsp)
  66dc1e:	48 8d bc 24 68 01 00 	lea    0x168(%rsp),%rdi
  66dc25:	00 
  66dc26:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
  66dc2d:	00 
  66dc2e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  66dc33:	f3 0f 10 44 24 04    	movss  0x4(%rsp),%xmm0
  66dc39:	e8 d2 ac 00 00       	call   678910 <<parley::editing::cursor::Cursor>::geometry::<()>>
  66dc3e:	0f 10 84 24 68 01 00 	movups 0x168(%rsp),%xmm0
  66dc45:	00 
  66dc46:	0f 10 8c 24 78 01 00 	movups 0x178(%rsp),%xmm1
  66dc4d:	00 
  66dc4e:	48 8d 84 24 30 02 00 	lea    0x230(%rsp),%rax
  66dc55:	00 
  66dc56:	0f 11 08             	movups %xmm1,(%rax)
  66dc59:	0f 11 40 f0          	movups %xmm0,-0x10(%rax)
  66dc5d:	0f 28 84 24 00 02 00 	movaps 0x200(%rsp),%xmm0
  66dc64:	00 
  66dc65:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
  66dc6c:	00 
  66dc6d:	0f 28 84 24 10 02 00 	movaps 0x210(%rsp),%xmm0
  66dc74:	00 
  66dc75:	0f 29 84 24 00 01 00 	movaps %xmm0,0x100(%rsp)
  66dc7c:	00 
  66dc7d:	0f 28 84 24 20 02 00 	movaps 0x220(%rsp),%xmm0
  66dc84:	00 
  66dc85:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
  66dc8c:	00 
  66dc8d:	0f 28 84 24 30 02 00 	movaps 0x230(%rsp),%xmm0
  66dc94:	00 
  66dc95:	0f 29 84 24 f0 00 00 	movaps %xmm0,0xf0(%rsp)
  66dc9c:	00 
  66dc9d:	b8 01 00 00 00       	mov    $0x1,%eax
  66dca2:	eb 02                	jmp    66dca6 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x10a6>
  66dca4:	31 c0                	xor    %eax,%eax
  66dca6:	4c 89 ac 24 00 02 00 	mov    %r13,0x200(%rsp)
  66dcad:	00 
  66dcae:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
  66dcb5:	00 
  66dcb6:	0f 28 84 24 90 00 00 	movaps 0x90(%rsp),%xmm0
  66dcbd:	00 
  66dcbe:	0f 11 84 24 10 02 00 	movups %xmm0,0x210(%rsp)
  66dcc5:	00 
  66dcc6:	0f 28 84 24 00 01 00 	movaps 0x100(%rsp),%xmm0
  66dccd:	00 
  66dcce:	0f 11 84 24 20 02 00 	movups %xmm0,0x220(%rsp)
  66dcd5:	00 
  66dcd6:	0f 28 84 24 c0 00 00 	movaps 0xc0(%rsp),%xmm0
  66dcdd:	00 
  66dcde:	0f 11 84 24 30 02 00 	movups %xmm0,0x230(%rsp)
  66dce5:	00 
  66dce6:	0f 28 84 24 f0 00 00 	movaps 0xf0(%rsp),%xmm0
  66dced:	00 
  66dcee:	0f 11 84 24 40 02 00 	movups %xmm0,0x240(%rsp)
  66dcf5:	00 
  66dcf6:	4c 89 ff             	mov    %r15,%rdi
  66dcf9:	4c 89 ee             	mov    %r13,%rsi
  66dcfc:	48 8d 94 24 08 02 00 	lea    0x208(%rsp),%rdx
  66dd03:	00 
  66dd04:	e8 77 29 00 00       	call   670680 <gpui_canvas::text::planner::append_carets::{closure#1}>
  66dd09:	41 89 c6             	mov    %eax,%r14d
  66dd0c:	83 f8 ff             	cmp    $0xffffffff,%eax
  66dd0f:	0f 85 d9 06 00 00    	jne    66e3ee <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x17ee>
  66dd15:	4c 3b 64 24 40       	cmp    0x40(%rsp),%r12
  66dd1a:	0f 94 c0             	sete   %al
  66dd1d:	8b 4c 24 3c          	mov    0x3c(%rsp),%ecx
  66dd21:	20 c1                	and    %al,%cl
  66dd23:	89 4c 24 3c          	mov    %ecx,0x3c(%rsp)
  66dd27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  66dd2e:	00 00 
  66dd30:	48 8b 84 24 50 04 00 	mov    0x450(%rsp),%rax
  66dd37:	00 
  66dd38:	48 83 f8 02          	cmp    $0x2,%rax
  66dd3c:	75 22                	jne    66dd60 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1160>
  66dd3e:	48 8d bc 24 60 04 00 	lea    0x460(%rsp),%rdi
  66dd45:	00 
  66dd46:	e8 55 cc ff ff       	call   66a9a0 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  66dd4b:	49 89 d4             	mov    %rdx,%r12
  66dd4e:	48 89 84 24 50 04 00 	mov    %rax,0x450(%rsp)
  66dd55:	00 
  66dd56:	48 89 94 24 58 04 00 	mov    %rdx,0x458(%rsp)
  66dd5d:	00 
  66dd5e:	eb 08                	jmp    66dd68 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1168>
  66dd60:	4c 8b a4 24 58 04 00 	mov    0x458(%rsp),%r12
  66dd67:	00 
  66dd68:	b1 01                	mov    $0x1,%cl
  66dd6a:	48 89 8c 24 c0 01 00 	mov    %rcx,0x1c0(%rsp)
  66dd71:	00 
  66dd72:	48 83 f8 01          	cmp    $0x1,%rax
  66dd76:	0f 85 2b 03 00 00    	jne    66e0a7 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x14a7>
  66dd7c:	4c 3b 64 24 58       	cmp    0x58(%rsp),%r12
  66dd81:	4c 8b 44 24 40       	mov    0x40(%rsp),%r8
  66dd86:	0f 83 1b 03 00 00    	jae    66e0a7 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x14a7>
  66dd8c:	4d 39 ec             	cmp    %r13,%r12
  66dd8f:	0f 82 1b 06 00 00    	jb     66e3b0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x17b0>
  66dd95:	48 c7 84 24 50 04 00 	movq   $0x2,0x450(%rsp)
  66dd9c:	00 02 00 00 00 
  66dda1:	4d 39 c4             	cmp    %r8,%r12
  66dda4:	0f 85 f5 00 00 00    	jne    66de9f <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x129f>
  66ddaa:	80 7c 24 3c 00       	cmpb   $0x0,0x3c(%rsp)
  66ddaf:	74 57                	je     66de08 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1208>
  66ddb1:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  66ddb6:	48 8b 41 58          	mov    0x58(%rcx),%rax
  66ddba:	48 39 e8             	cmp    %rbp,%rax
  66ddbd:	0f 86 ec 07 00 00    	jbe    66e5af <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19af>
  66ddc3:	48 8b 51 70          	mov    0x70(%rcx),%rdx
  66ddc7:	48 8b bc 24 58 01 00 	mov    0x158(%rsp),%rdi
  66ddce:	00 
  66ddcf:	48 8b b4 24 50 01 00 	mov    0x150(%rsp),%rsi
  66ddd6:	00 
  66ddd7:	39 fe                	cmp    %edi,%esi
  66ddd9:	0f 82 09 07 00 00    	jb     66e4e8 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18e8>
  66dddf:	48 39 f2             	cmp    %rsi,%rdx
  66dde2:	0f 82 00 07 00 00    	jb     66e4e8 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18e8>
  66dde8:	39 fe                	cmp    %edi,%esi
  66ddea:	0f 84 cd 07 00 00    	je     66e5bd <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19bd>
  66ddf0:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  66ddf5:	48 8b 40 68          	mov    0x68(%rax),%rax
  66ddf9:	48 8d 0c 7f          	lea    (%rdi,%rdi,2),%rcx
  66ddfd:	80 7c 88 07 06       	cmpb   $0x6,0x7(%rax,%rcx,4)
  66de02:	0f 85 0a 02 00 00    	jne    66e012 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1412>
  66de08:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  66de0d:	4c 89 c6             	mov    %r8,%rsi
  66de10:	ba 01 00 00 00       	mov    $0x1,%edx
  66de15:	e8 36 aa 00 00       	call   678850 <<parley::editing::cursor::Cursor>::from_byte_index::<()>>
  66de1a:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
  66de21:	00 
  66de22:	80 e2 01             	and    $0x1,%dl
  66de25:	88 94 24 d8 00 00 00 	mov    %dl,0xd8(%rsp)
  66de2c:	48 3b 44 24 40       	cmp    0x40(%rsp),%rax
  66de31:	0f 85 62 01 00 00    	jne    66df99 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1399>
  66de37:	48 8d bc 24 00 02 00 	lea    0x200(%rsp),%rdi
  66de3e:	00 
  66de3f:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
  66de46:	00 
  66de47:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  66de4c:	f3 0f 10 44 24 04    	movss  0x4(%rsp),%xmm0
  66de52:	e8 b9 aa 00 00       	call   678910 <<parley::editing::cursor::Cursor>::geometry::<()>>
  66de57:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  66de5c:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
  66de61:	31 d2                	xor    %edx,%edx
  66de63:	e8 e8 a9 00 00       	call   678850 <<parley::editing::cursor::Cursor>::from_byte_index::<()>>
  66de68:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
  66de6f:	00 
  66de70:	80 e2 01             	and    $0x1,%dl
  66de73:	88 94 24 e8 00 00 00 	mov    %dl,0xe8(%rsp)
  66de7a:	48 8d bc 24 68 01 00 	lea    0x168(%rsp),%rdi
  66de81:	00 
  66de82:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
  66de89:	00 
  66de8a:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  66de8f:	f3 0f 10 44 24 04    	movss  0x4(%rsp),%xmm0
  66de95:	e8 76 aa 00 00       	call   678910 <<parley::editing::cursor::Cursor>::geometry::<()>>
  66de9a:	e9 94 00 00 00       	jmp    66df33 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1333>
  66de9f:	0f 87 f4 00 00 00    	ja     66df99 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1399>
  66dea5:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  66deaa:	4c 89 e6             	mov    %r12,%rsi
  66dead:	ba 01 00 00 00       	mov    $0x1,%edx
  66deb2:	e8 99 a9 00 00       	call   678850 <<parley::editing::cursor::Cursor>::from_byte_index::<()>>
  66deb7:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
  66debe:	00 
  66debf:	80 e2 01             	and    $0x1,%dl
  66dec2:	88 94 24 d8 00 00 00 	mov    %dl,0xd8(%rsp)
  66dec9:	4c 39 e0             	cmp    %r12,%rax
  66decc:	0f 85 c7 00 00 00    	jne    66df99 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1399>
  66ded2:	48 8d bc 24 00 02 00 	lea    0x200(%rsp),%rdi
  66ded9:	00 
  66deda:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
  66dee1:	00 
  66dee2:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  66dee7:	f3 0f 10 44 24 04    	movss  0x4(%rsp),%xmm0
  66deed:	e8 1e aa 00 00       	call   678910 <<parley::editing::cursor::Cursor>::geometry::<()>>
  66def2:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  66def7:	4c 89 e6             	mov    %r12,%rsi
  66defa:	31 d2                	xor    %edx,%edx
  66defc:	e8 4f a9 00 00       	call   678850 <<parley::editing::cursor::Cursor>::from_byte_index::<()>>
  66df01:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
  66df08:	00 
  66df09:	80 e2 01             	and    $0x1,%dl
  66df0c:	88 94 24 e8 00 00 00 	mov    %dl,0xe8(%rsp)
  66df13:	48 8d bc 24 68 01 00 	lea    0x168(%rsp),%rdi
  66df1a:	00 
  66df1b:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
  66df22:	00 
  66df23:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  66df28:	f3 0f 10 44 24 04    	movss  0x4(%rsp),%xmm0
  66df2e:	e8 dd a9 00 00       	call   678910 <<parley::editing::cursor::Cursor>::geometry::<()>>
  66df33:	0f 10 84 24 68 01 00 	movups 0x168(%rsp),%xmm0
  66df3a:	00 
  66df3b:	0f 10 8c 24 78 01 00 	movups 0x178(%rsp),%xmm1
  66df42:	00 
  66df43:	48 8d 84 24 30 02 00 	lea    0x230(%rsp),%rax
  66df4a:	00 
  66df4b:	0f 11 08             	movups %xmm1,(%rax)
  66df4e:	0f 11 40 f0          	movups %xmm0,-0x10(%rax)
  66df52:	0f 28 84 24 00 02 00 	movaps 0x200(%rsp),%xmm0
  66df59:	00 
  66df5a:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
  66df61:	00 
  66df62:	0f 28 84 24 10 02 00 	movaps 0x210(%rsp),%xmm0
  66df69:	00 
  66df6a:	0f 29 84 24 00 01 00 	movaps %xmm0,0x100(%rsp)
  66df71:	00 
  66df72:	0f 28 84 24 20 02 00 	movaps 0x220(%rsp),%xmm0
  66df79:	00 
  66df7a:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
  66df81:	00 
  66df82:	0f 28 84 24 30 02 00 	movaps 0x230(%rsp),%xmm0
  66df89:	00 
  66df8a:	0f 29 84 24 f0 00 00 	movaps %xmm0,0xf0(%rsp)
  66df91:	00 
  66df92:	b8 01 00 00 00       	mov    $0x1,%eax
  66df97:	eb 02                	jmp    66df9b <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x139b>
  66df99:	31 c0                	xor    %eax,%eax
  66df9b:	4c 89 a4 24 00 02 00 	mov    %r12,0x200(%rsp)
  66dfa2:	00 
  66dfa3:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
  66dfaa:	00 
  66dfab:	0f 28 84 24 90 00 00 	movaps 0x90(%rsp),%xmm0
  66dfb2:	00 
  66dfb3:	0f 11 84 24 10 02 00 	movups %xmm0,0x210(%rsp)
  66dfba:	00 
  66dfbb:	0f 28 84 24 00 01 00 	movaps 0x100(%rsp),%xmm0
  66dfc2:	00 
  66dfc3:	0f 11 84 24 20 02 00 	movups %xmm0,0x220(%rsp)
  66dfca:	00 
  66dfcb:	0f 28 84 24 c0 00 00 	movaps 0xc0(%rsp),%xmm0
  66dfd2:	00 
  66dfd3:	0f 11 84 24 30 02 00 	movups %xmm0,0x230(%rsp)
  66dfda:	00 
  66dfdb:	0f 28 84 24 f0 00 00 	movaps 0xf0(%rsp),%xmm0
  66dfe2:	00 
  66dfe3:	0f 11 84 24 40 02 00 	movups %xmm0,0x240(%rsp)
  66dfea:	00 
  66dfeb:	4c 89 ff             	mov    %r15,%rdi
  66dfee:	4c 89 e6             	mov    %r12,%rsi
  66dff1:	48 8d 94 24 08 02 00 	lea    0x208(%rsp),%rdx
  66dff8:	00 
  66dff9:	e8 82 26 00 00       	call   670680 <gpui_canvas::text::planner::append_carets::{closure#1}>
  66dffe:	41 89 c6             	mov    %eax,%r14d
  66e001:	4d 89 e5             	mov    %r12,%r13
  66e004:	83 f8 ff             	cmp    $0xffffffff,%eax
  66e007:	0f 84 23 fd ff ff    	je     66dd30 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1130>
  66e00d:	e9 dc 03 00 00       	jmp    66e3ee <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x17ee>
  66e012:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  66e017:	f3 0f 10 40 40       	movss  0x40(%rax),%xmm0
  66e01c:	0f 28 c8             	movaps %xmm0,%xmm1
  66e01f:	f3 0f 5d 48 48       	minss  0x48(%rax),%xmm1
  66e024:	0f 28 d1             	movaps %xmm1,%xmm2
  66e027:	f3 0f c2 d1 03       	cmpunordss %xmm1,%xmm2
  66e02c:	0f 28 da             	movaps %xmm2,%xmm3
  66e02f:	0f 55 d9             	andnps %xmm1,%xmm3
  66e032:	0f 54 d0             	andps  %xmm0,%xmm2
  66e035:	0f 56 d3             	orps   %xmm3,%xmm2
  66e038:	0f 57 c0             	xorps  %xmm0,%xmm0
  66e03b:	f3 0f 5a c2          	cvtss2sd %xmm2,%xmm0
  66e03f:	f3 0f 10 48 44       	movss  0x44(%rax),%xmm1
  66e044:	0f 28 d1             	movaps %xmm1,%xmm2
  66e047:	f3 0f 5f 50 4c       	maxss  0x4c(%rax),%xmm2
  66e04c:	0f 28 da             	movaps %xmm2,%xmm3
  66e04f:	f3 0f c2 da 03       	cmpunordss %xmm2,%xmm3
  66e054:	0f 28 e3             	movaps %xmm3,%xmm4
  66e057:	0f 55 e2             	andnps %xmm2,%xmm4
  66e05a:	0f 54 d9             	andps  %xmm1,%xmm3
  66e05d:	0f 56 dc             	orps   %xmm4,%xmm3
  66e060:	0f 57 c9             	xorps  %xmm1,%xmm1
  66e063:	f3 0f 5a cb          	cvtss2sd %xmm3,%xmm1
  66e067:	0f 28 94 24 90 01 00 	movaps 0x190(%rsp),%xmm2
  66e06e:	00 
  66e06f:	0f 16 d0             	movlhps %xmm0,%xmm2
  66e072:	0f 28 84 24 a0 01 00 	movaps 0x1a0(%rsp),%xmm0
  66e079:	00 
  66e07a:	0f 16 c1             	movlhps %xmm1,%xmm0
  66e07d:	b8 01 00 00 00       	mov    $0x1,%eax
  66e082:	0f 29 94 24 90 00 00 	movaps %xmm2,0x90(%rsp)
  66e089:	00 
  66e08a:	0f 29 94 24 c0 00 00 	movaps %xmm2,0xc0(%rsp)
  66e091:	00 
  66e092:	0f 29 84 24 00 01 00 	movaps %xmm0,0x100(%rsp)
  66e099:	00 
  66e09a:	0f 29 84 24 f0 00 00 	movaps %xmm0,0xf0(%rsp)
  66e0a1:	00 
  66e0a2:	e9 f4 fe ff ff       	jmp    66df9b <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x139b>
  66e0a7:	4c 89 ac 24 90 01 00 	mov    %r13,0x190(%rsp)
  66e0ae:	00 
  66e0af:	4c 8d b4 24 00 02 00 	lea    0x200(%rsp),%r14
  66e0b6:	00 
  66e0b7:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  66e0bc:	48 3b 44 24 58       	cmp    0x58(%rsp),%rax
  66e0c1:	73 5a                	jae    66e11d <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x151d>
  66e0c3:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  66e0c8:	48 8b 41 58          	mov    0x58(%rcx),%rax
  66e0cc:	48 39 e8             	cmp    %rbp,%rax
  66e0cf:	0f 86 da 04 00 00    	jbe    66e5af <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19af>
  66e0d5:	48 8b 51 70          	mov    0x70(%rcx),%rdx
  66e0d9:	48 8b bc 24 58 01 00 	mov    0x158(%rsp),%rdi
  66e0e0:	00 
  66e0e1:	48 8b b4 24 50 01 00 	mov    0x150(%rsp),%rsi
  66e0e8:	00 
  66e0e9:	39 fe                	cmp    %edi,%esi
  66e0eb:	0f 82 f7 03 00 00    	jb     66e4e8 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18e8>
  66e0f1:	48 39 f2             	cmp    %rsi,%rdx
  66e0f4:	0f 82 ee 03 00 00    	jb     66e4e8 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18e8>
  66e0fa:	39 fe                	cmp    %edi,%esi
  66e0fc:	0f 84 bb 04 00 00    	je     66e5bd <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19bd>
  66e102:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  66e107:	48 8b 40 68          	mov    0x68(%rax),%rax
  66e10b:	48 8d 0c 7f          	lea    (%rdi,%rdi,2),%rcx
  66e10f:	80 7c 88 07 06       	cmpb   $0x6,0x7(%rax,%rcx,4)
  66e114:	0f 95 c0             	setne  %al
  66e117:	89 44 24 3c          	mov    %eax,0x3c(%rsp)
  66e11b:	eb 08                	jmp    66e125 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1525>
  66e11d:	c7 44 24 3c 00 00 00 	movl   $0x0,0x3c(%rsp)
  66e124:	00 
  66e125:	4c 8d ac 24 38 03 00 	lea    0x338(%rsp),%r13
  66e12c:	00 
  66e12d:	4c 8b 64 24 58       	mov    0x58(%rsp),%r12
  66e132:	e9 be f6 ff ff       	jmp    66d7f5 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xbf5>
  66e137:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  66e13c:	f3 0f 10 40 40       	movss  0x40(%rax),%xmm0
  66e141:	0f 28 c8             	movaps %xmm0,%xmm1
  66e144:	f3 0f 5d 48 48       	minss  0x48(%rax),%xmm1
  66e149:	0f 28 d1             	movaps %xmm1,%xmm2
  66e14c:	f3 0f c2 d1 03       	cmpunordss %xmm1,%xmm2
  66e151:	0f 28 da             	movaps %xmm2,%xmm3
  66e154:	0f 55 d9             	andnps %xmm1,%xmm3
  66e157:	0f 54 d0             	andps  %xmm0,%xmm2
  66e15a:	0f 56 d3             	orps   %xmm3,%xmm2
  66e15d:	0f 57 c0             	xorps  %xmm0,%xmm0
  66e160:	f3 0f 5a c2          	cvtss2sd %xmm2,%xmm0
  66e164:	f3 0f 10 48 44       	movss  0x44(%rax),%xmm1
  66e169:	0f 28 d1             	movaps %xmm1,%xmm2
  66e16c:	f3 0f 5f 50 4c       	maxss  0x4c(%rax),%xmm2
  66e171:	0f 28 da             	movaps %xmm2,%xmm3
  66e174:	f3 0f c2 da 03       	cmpunordss %xmm2,%xmm3
  66e179:	0f 28 e3             	movaps %xmm3,%xmm4
  66e17c:	0f 55 e2             	andnps %xmm2,%xmm4
  66e17f:	0f 54 d9             	andps  %xmm1,%xmm3
  66e182:	0f 56 dc             	orps   %xmm4,%xmm3
  66e185:	0f 57 c9             	xorps  %xmm1,%xmm1
  66e188:	f3 0f 5a cb          	cvtss2sd %xmm3,%xmm1
  66e18c:	0f 28 94 24 90 01 00 	movaps 0x190(%rsp),%xmm2
  66e193:	00 
  66e194:	0f 16 d0             	movlhps %xmm0,%xmm2
  66e197:	0f 28 84 24 a0 01 00 	movaps 0x1a0(%rsp),%xmm0
  66e19e:	00 
  66e19f:	0f 16 c1             	movlhps %xmm1,%xmm0
  66e1a2:	b8 01 00 00 00       	mov    $0x1,%eax
  66e1a7:	0f 29 94 24 90 00 00 	movaps %xmm2,0x90(%rsp)
  66e1ae:	00 
  66e1af:	0f 29 94 24 c0 00 00 	movaps %xmm2,0xc0(%rsp)
  66e1b6:	00 
  66e1b7:	0f 29 84 24 00 01 00 	movaps %xmm0,0x100(%rsp)
  66e1be:	00 
  66e1bf:	0f 29 84 24 f0 00 00 	movaps %xmm0,0xf0(%rsp)
  66e1c6:	00 
  66e1c7:	e9 da fa ff ff       	jmp    66dca6 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x10a6>
  66e1cc:	4c 8d ac 24 38 03 00 	lea    0x338(%rsp),%r13
  66e1d3:	00 
  66e1d4:	e9 cc f2 ff ff       	jmp    66d4a5 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x8a5>
  66e1d9:	49 89 d6             	mov    %rdx,%r14
  66e1dc:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  66e1e1:	f3 0f 10 48 28       	movss  0x28(%rax),%xmm1
  66e1e6:	48 c1 e7 03          	shl    $0x3,%rdi
  66e1ea:	48 8d 04 bf          	lea    (%rdi,%rdi,4),%rax
  66e1ee:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
  66e1f3:	48 8d 1c 01          	lea    (%rcx,%rax,1),%rbx
  66e1f7:	48 c1 e6 03          	shl    $0x3,%rsi
  66e1fb:	4c 8d 3c b6          	lea    (%rsi,%rsi,4),%r15
  66e1ff:	49 29 c7             	sub    %rax,%r15
  66e202:	45 31 e4             	xor    %r12d,%r12d
  66e205:	eb 2c                	jmp    66e233 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1633>
  66e207:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  66e20e:	00 00 
  66e210:	4c 8d ac 24 38 03 00 	lea    0x338(%rsp),%r13
  66e217:	00 
  66e218:	f3 0f 10 4c 24 48    	movss  0x48(%rsp),%xmm1
  66e21e:	48 83 c3 28          	add    $0x28,%rbx
  66e222:	f3 0f 58 c8          	addss  %xmm0,%xmm1
  66e226:	49 ff c4             	inc    %r12
  66e229:	49 83 c7 d8          	add    $0xffffffffffffffd8,%r15
  66e22d:	0f 84 32 f2 ff ff    	je     66d465 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x865>
  66e233:	48 8b 6b 10          	mov    0x10(%rbx),%rbp
  66e237:	80 7b 21 01          	cmpb   $0x1,0x21(%rbx)
  66e23b:	75 33                	jne    66e270 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1670>
  66e23d:	48 3b ac 24 80 00 00 	cmp    0x80(%rsp),%rbp
  66e244:	00 
  66e245:	0f 83 2c 03 00 00    	jae    66e577 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1977>
  66e24b:	48 6b c5 38          	imul   $0x38,%rbp,%rax
  66e24f:	48 8b 8c 24 28 03 00 	mov    0x328(%rsp),%rcx
  66e256:	00 
  66e257:	f3 0f 10 44 01 24    	movss  0x24(%rcx,%rax,1),%xmm0
  66e25d:	4c 8d ac 24 38 03 00 	lea    0x338(%rsp),%r13
  66e264:	00 
  66e265:	eb b7                	jmp    66e21e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x161e>
  66e267:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  66e26e:	00 00 
  66e270:	48 3b ac 24 18 01 00 	cmp    0x118(%rsp),%rbp
  66e277:	00 
  66e278:	0f 83 12 03 00 00    	jae    66e590 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1990>
  66e27e:	48 3b ac 24 c8 01 00 	cmp    0x1c8(%rsp),%rbp
  66e285:	00 
  66e286:	0f 83 bc 02 00 00    	jae    66e548 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1948>
  66e28c:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
  66e293:	00 
  66e294:	48 01 e8             	add    %rbp,%rax
  66e297:	48 c1 e0 04          	shl    $0x4,%rax
  66e29b:	48 03 84 24 20 01 00 	add    0x120(%rsp),%rax
  66e2a2:	00 
  66e2a3:	48 8d 0c ad 00 00 00 	lea    0x0(,%rbp,4),%rcx
  66e2aa:	00 
  66e2ab:	48 01 e9             	add    %rbp,%rcx
  66e2ae:	48 c1 e1 04          	shl    $0x4,%rcx
  66e2b2:	48 03 8c 24 28 01 00 	add    0x128(%rsp),%rcx
  66e2b9:	00 
  66e2ba:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  66e2bf:	48 89 94 24 30 03 00 	mov    %rdx,0x330(%rsp)
  66e2c6:	00 
  66e2c7:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
  66e2ce:	00 
  66e2cf:	48 89 8c 24 40 03 00 	mov    %rcx,0x340(%rsp)
  66e2d6:	00 
  66e2d7:	48 89 9c 24 48 03 00 	mov    %rbx,0x348(%rsp)
  66e2de:	00 
  66e2df:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  66e2e4:	89 84 24 50 03 00 00 	mov    %eax,0x350(%rsp)
  66e2eb:	44 89 a4 24 54 03 00 	mov    %r12d,0x354(%rsp)
  66e2f2:	00 
  66e2f3:	89 ac 24 58 03 00 00 	mov    %ebp,0x358(%rsp)
  66e2fa:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  66e2ff:	48 8b 68 10          	mov    0x10(%rax),%rbp
  66e303:	4c 01 e5             	add    %r12,%rbp
  66e306:	48 3b 6c 24 10       	cmp    0x10(%rsp),%rbp
  66e30b:	0f 83 95 02 00 00    	jae    66e5a6 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19a6>
  66e311:	48 8d 04 ad 00 00 00 	lea    0x0(,%rbp,4),%rax
  66e318:	00 
  66e319:	48 01 e8             	add    %rbp,%rax
  66e31c:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
  66e321:	48 8b 6c c1 10       	mov    0x10(%rcx,%rax,8),%rbp
  66e326:	4c 29 f5             	sub    %r14,%rbp
  66e329:	48 3b 6c 24 20       	cmp    0x20(%rsp),%rbp
  66e32e:	0f 83 2d 02 00 00    	jae    66e561 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1961>
  66e334:	48 c1 e5 04          	shl    $0x4,%rbp
  66e338:	48 8b 84 24 88 00 00 	mov    0x88(%rsp),%rax
  66e33f:	00 
  66e340:	f3 0f 11 4c 24 48    	movss  %xmm1,0x48(%rsp)
  66e346:	f3 0f 11 4c 28 08    	movss  %xmm1,0x8(%rax,%rbp,1)
  66e34c:	48 8d bc 24 30 03 00 	lea    0x330(%rsp),%rdi
  66e353:	00 
  66e354:	e8 f7 c4 00 00       	call   67a850 <<parley::layout::run::Run<()>>::advance>
  66e359:	e9 b2 fe ff ff       	jmp    66e210 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1610>
  66e35e:	4c 8d b4 24 30 03 00 	lea    0x330(%rsp),%r14
  66e365:	00 
  66e366:	48 8d b4 24 50 04 00 	lea    0x450(%rsp),%rsi
  66e36d:	00 
  66e36e:	ba a8 00 00 00       	mov    $0xa8,%edx
  66e373:	4c 89 f7             	mov    %r14,%rdi
  66e376:	ff 15 f4 bb 11 00    	call   *0x11bbf4(%rip)        # 789f70 <memcpy@GLIBC_2.14>
  66e37c:	48 89 df             	mov    %rbx,%rdi
  66e37f:	4c 89 f6             	mov    %r14,%rsi
  66e382:	f3 0f 10 44 24 04    	movss  0x4(%rsp),%xmm0
  66e388:	4c 89 fa             	mov    %r15,%rdx
  66e38b:	e8 30 13 00 00       	call   66f6c0 <parley::editing::geometry::visit_direct::<(), gpui_canvas::Error, core::iter::adapters::peekable::Peekable<icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>>, gpui_canvas::text::planner::append_carets::{closure#1}>>
  66e390:	eb 57                	jmp    66e3e9 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x17e9>
  66e392:	48 89 df             	mov    %rbx,%rdi
  66e395:	31 db                	xor    %ebx,%ebx
  66e397:	4c 89 e6             	mov    %r12,%rsi
  66e39a:	f3 0f 10 44 24 04    	movss  0x4(%rsp),%xmm0
  66e3a0:	4c 89 fa             	mov    %r15,%rdx
  66e3a3:	e8 48 15 00 00       	call   66f8f0 <parley::editing::geometry::visit_indexed::<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>>
  66e3a8:	41 89 c6             	mov    %eax,%r14d
  66e3ab:	e9 de 00 00 00       	jmp    66e48e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x188e>
  66e3b0:	4c 8d b4 24 00 02 00 	lea    0x200(%rsp),%r14
  66e3b7:	00 
  66e3b8:	48 8d b4 24 50 04 00 	lea    0x450(%rsp),%rsi
  66e3bf:	00 
  66e3c0:	ba a8 00 00 00       	mov    $0xa8,%edx
  66e3c5:	4c 89 f7             	mov    %r14,%rdi
  66e3c8:	ff 15 a2 bb 11 00    	call   *0x11bba2(%rip)        # 789f70 <memcpy@GLIBC_2.14>
  66e3ce:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  66e3d3:	4c 89 f6             	mov    %r14,%rsi
  66e3d6:	f3 0f 10 44 24 04    	movss  0x4(%rsp),%xmm0
  66e3dc:	4c 89 fa             	mov    %r15,%rdx
  66e3df:	4c 8b 64 24 18       	mov    0x18(%rsp),%r12
  66e3e4:	e8 d7 12 00 00       	call   66f6c0 <parley::editing::geometry::visit_direct::<(), gpui_canvas::Error, core::iter::adapters::peekable::Peekable<icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>>, gpui_canvas::text::planner::append_carets::{closure#1}>>
  66e3e9:	41 89 c6             	mov    %eax,%r14d
  66e3ec:	eb 24                	jmp    66e412 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1812>
  66e3ee:	48 8b b4 24 60 04 00 	mov    0x460(%rsp),%rsi
  66e3f5:	00 
  66e3f6:	48 85 f6             	test   %rsi,%rsi
  66e3f9:	74 17                	je     66e412 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1812>
  66e3fb:	48 8b bc 24 68 04 00 	mov    0x468(%rsp),%rdi
  66e402:	00 
  66e403:	48 c1 e6 03          	shl    $0x3,%rsi
  66e407:	ba 08 00 00 00       	mov    $0x8,%edx
  66e40c:	ff 15 c6 ba 11 00    	call   *0x11bac6(%rip)        # 789ed8 <_DYNAMIC+0x238>
  66e412:	48 8b b4 24 38 01 00 	mov    0x138(%rsp),%rsi
  66e419:	00 
  66e41a:	48 85 f6             	test   %rsi,%rsi
  66e41d:	74 17                	je     66e436 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1836>
  66e41f:	48 8b bc 24 40 01 00 	mov    0x140(%rsp),%rdi
  66e426:	00 
  66e427:	48 c1 e6 02          	shl    $0x2,%rsi
  66e42b:	ba 04 00 00 00       	mov    $0x4,%edx
  66e430:	ff 15 a2 ba 11 00    	call   *0x11baa2(%rip)        # 789ed8 <_DYNAMIC+0x238>
  66e436:	48 8b b4 24 a8 00 00 	mov    0xa8(%rsp),%rsi
  66e43d:	00 
  66e43e:	48 85 f6             	test   %rsi,%rsi
  66e441:	0f 84 8c 00 00 00    	je     66e4d3 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18d3>
  66e447:	48 c1 e6 04          	shl    $0x4,%rsi
  66e44b:	ba 08 00 00 00       	mov    $0x8,%edx
  66e450:	48 8b bc 24 88 00 00 	mov    0x88(%rsp),%rdi
  66e457:	00 
  66e458:	eb 73                	jmp    66e4cd <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18cd>
  66e45a:	31 db                	xor    %ebx,%ebx
  66e45c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  66e461:	4c 8b 64 24 18       	mov    0x18(%rsp),%r12
  66e466:	4c 89 e6             	mov    %r12,%rsi
  66e469:	f3 0f 10 44 24 04    	movss  0x4(%rsp),%xmm0
  66e46f:	48 8b 94 24 30 01 00 	mov    0x130(%rsp),%rdx
  66e476:	00 
  66e477:	e8 74 14 00 00       	call   66f8f0 <parley::editing::geometry::visit_indexed::<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>>
  66e47c:	41 89 c6             	mov    %eax,%r14d
  66e47f:	eb 08                	jmp    66e489 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1889>
  66e481:	41 be fe ff ff ff    	mov    $0xfffffffe,%r14d
  66e487:	b3 01                	mov    $0x1,%bl
  66e489:	4c 8b 64 24 18       	mov    0x18(%rsp),%r12
  66e48e:	48 8b b4 24 a8 00 00 	mov    0xa8(%rsp),%rsi
  66e495:	00 
  66e496:	48 85 f6             	test   %rsi,%rsi
  66e499:	74 17                	je     66e4b2 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18b2>
  66e49b:	48 8b bc 24 b0 00 00 	mov    0xb0(%rsp),%rdi
  66e4a2:	00 
  66e4a3:	48 c1 e6 04          	shl    $0x4,%rsi
  66e4a7:	ba 08 00 00 00       	mov    $0x8,%edx
  66e4ac:	ff 15 26 ba 11 00    	call   *0x11ba26(%rip)        # 789ed8 <_DYNAMIC+0x238>
  66e4b2:	84 db                	test   %bl,%bl
  66e4b4:	74 1d                	je     66e4d3 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18d3>
  66e4b6:	49 8b 34 24          	mov    (%r12),%rsi
  66e4ba:	48 85 f6             	test   %rsi,%rsi
  66e4bd:	74 14                	je     66e4d3 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18d3>
  66e4bf:	49 8b 7c 24 08       	mov    0x8(%r12),%rdi
  66e4c4:	48 c1 e6 03          	shl    $0x3,%rsi
  66e4c8:	ba 08 00 00 00       	mov    $0x8,%edx
  66e4cd:	ff 15 05 ba 11 00    	call   *0x11ba05(%rip)        # 789ed8 <_DYNAMIC+0x238>
  66e4d3:	44 89 f0             	mov    %r14d,%eax
  66e4d6:	48 81 c4 a8 07 00 00 	add    $0x7a8,%rsp
  66e4dd:	5b                   	pop    %rbx
  66e4de:	41 5c                	pop    %r12
  66e4e0:	41 5d                	pop    %r13
  66e4e2:	41 5e                	pop    %r14
  66e4e4:	41 5f                	pop    %r15
  66e4e6:	5d                   	pop    %rbp
  66e4e7:	c3                   	ret
  66e4e8:	48 8d 0d c1 12 11 00 	lea    0x1112c1(%rip),%rcx        # 77f7b0 <anon.abe2914d8fd9d1076326722b06c47a5f.27.llvm.962491032109686297>
  66e4ef:	ff 15 0b bd 11 00    	call   *0x11bd0b(%rip)        # 78a200 <_DYNAMIC+0x560>
  66e4f5:	e9 3a 01 00 00       	jmp    66e634 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a34>
  66e4fa:	48 8d 0d 57 1c 11 00 	lea    0x111c57(%rip),%rcx        # 780158 <anon.c85b311aa65b1c615d2dfba884aacc4b.17.llvm.18174800310199966706>
  66e501:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  66e506:	ff 15 f4 bc 11 00    	call   *0x11bcf4(%rip)        # 78a200 <_DYNAMIC+0x560>
  66e50c:	e9 23 01 00 00       	jmp    66e634 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a34>
  66e511:	48 8d 3d 9b d2 be ff 	lea    -0x412d65(%rip),%rdi        # 25b7b3 <gpui_canvas::text::PRIMARY_BYTES+0x1f485b>
  66e518:	48 8d 15 a1 11 11 00 	lea    0x1111a1(%rip),%rdx        # 77f6c0 <__frame_dummy_init_array_entry+0x780>
  66e51f:	be 21 00 00 00       	mov    $0x21,%esi
  66e524:	ff 15 56 bc 11 00    	call   *0x11bc56(%rip)        # 78a180 <_DYNAMIC+0x4e0>
  66e52a:	e9 05 01 00 00       	jmp    66e634 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a34>
  66e52f:	b3 01                	mov    $0x1,%bl
  66e531:	48 8d 15 c0 12 11 00 	lea    0x1112c0(%rip),%rdx        # 77f7f8 <anon.abe2914d8fd9d1076326722b06c47a5f.32.llvm.962491032109686297>
  66e538:	4c 8b 64 24 18       	mov    0x18(%rsp),%r12
  66e53d:	ff 15 bd ba 11 00    	call   *0x11babd(%rip)        # 78a000 <_DYNAMIC+0x360>
  66e543:	e9 ec 00 00 00       	jmp    66e634 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a34>
  66e548:	48 8b 84 24 c8 01 00 	mov    0x1c8(%rsp),%rax
  66e54f:	00 
  66e550:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  66e555:	48 8d 05 0c 12 11 00 	lea    0x11120c(%rip),%rax        # 77f768 <__frame_dummy_init_array_entry+0x828>
  66e55c:	e9 bb 00 00 00       	jmp    66e61c <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a1c>
  66e561:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  66e566:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  66e56b:	48 8d 05 c6 11 11 00 	lea    0x1111c6(%rip),%rax        # 77f738 <__frame_dummy_init_array_entry+0x7f8>
  66e572:	e9 a5 00 00 00       	jmp    66e61c <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a1c>
  66e577:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  66e57e:	00 
  66e57f:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  66e584:	48 8d 05 f5 11 11 00 	lea    0x1111f5(%rip),%rax        # 77f780 <__frame_dummy_init_array_entry+0x840>
  66e58b:	e9 8c 00 00 00       	jmp    66e61c <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a1c>
  66e590:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
  66e597:	00 
  66e598:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  66e59d:	48 8d 05 ac 11 11 00 	lea    0x1111ac(%rip),%rax        # 77f750 <__frame_dummy_init_array_entry+0x810>
  66e5a4:	eb 76                	jmp    66e61c <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a1c>
  66e5a6:	48 8d 05 73 11 11 00 	lea    0x111173(%rip),%rax        # 77f720 <__frame_dummy_init_array_entry+0x7e0>
  66e5ad:	eb 6d                	jmp    66e61c <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a1c>
  66e5af:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  66e5b4:	48 8d 05 3d 12 11 00 	lea    0x11123d(%rip),%rax        # 77f7f8 <anon.abe2914d8fd9d1076326722b06c47a5f.32.llvm.962491032109686297>
  66e5bb:	eb 5f                	jmp    66e61c <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a1c>
  66e5bd:	31 ed                	xor    %ebp,%ebp
  66e5bf:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  66e5c6:	00 00 
  66e5c8:	eb 57                	jmp    66e621 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a21>
  66e5ca:	4c 89 f5             	mov    %r14,%rbp
  66e5cd:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  66e5d2:	48 8d 05 17 11 11 00 	lea    0x111117(%rip),%rax        # 77f6f0 <__frame_dummy_init_array_entry+0x7b0>
  66e5d9:	eb 41                	jmp    66e61c <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a1c>
  66e5db:	48 3b 8c 24 80 00 00 	cmp    0x80(%rsp),%rcx
  66e5e2:	00 
  66e5e3:	48 8d 05 1e 11 11 00 	lea    0x11111e(%rip),%rax        # 77f708 <__frame_dummy_init_array_entry+0x7c8>
  66e5ea:	48 8d 0d e7 10 11 00 	lea    0x1110e7(%rip),%rcx        # 77f6d8 <__frame_dummy_init_array_entry+0x798>
  66e5f1:	48 0f 42 c8          	cmovb  %rax,%rcx
  66e5f5:	48 89 8c 24 b8 01 00 	mov    %rcx,0x1b8(%rsp)
  66e5fc:	00 
  66e5fd:	48 8b bc 24 b8 01 00 	mov    0x1b8(%rsp),%rdi
  66e604:	00 
  66e605:	ff 15 cd b9 11 00    	call   *0x11b9cd(%rip)        # 789fd8 <_DYNAMIC+0x338>
  66e60b:	eb 27                	jmp    66e634 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a34>
  66e60d:	48 89 c5             	mov    %rax,%rbp
  66e610:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  66e615:	48 8d 05 c4 11 11 00 	lea    0x1111c4(%rip),%rax        # 77f7e0 <anon.abe2914d8fd9d1076326722b06c47a5f.30.llvm.962491032109686297>
  66e61c:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  66e621:	48 89 ef             	mov    %rbp,%rdi
  66e624:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  66e629:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
  66e62e:	ff 15 cc b9 11 00    	call   *0x11b9cc(%rip)        # 78a000 <_DYNAMIC+0x360>
  66e634:	0f 0b                	ud2
  66e636:	49 89 c6             	mov    %rax,%r14
  66e639:	eb 60                	jmp    66e69b <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a9b>
  66e63b:	49 89 c6             	mov    %rax,%r14
  66e63e:	eb 37                	jmp    66e677 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a77>
  66e640:	49 89 c6             	mov    %rax,%r14
  66e643:	eb 32                	jmp    66e677 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a77>
  66e645:	eb 1a                	jmp    66e661 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a61>
  66e647:	eb 26                	jmp    66e66f <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a6f>
  66e649:	eb 04                	jmp    66e64f <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a4f>
  66e64b:	eb 22                	jmp    66e66f <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a6f>
  66e64d:	eb 12                	jmp    66e661 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a61>
  66e64f:	49 89 c6             	mov    %rax,%r14
  66e652:	b3 01                	mov    $0x1,%bl
  66e654:	eb 74                	jmp    66e6ca <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1aca>
  66e656:	eb 17                	jmp    66e66f <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a6f>
  66e658:	49 89 c6             	mov    %rax,%r14
  66e65b:	eb 1a                	jmp    66e677 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a77>
  66e65d:	eb 10                	jmp    66e66f <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a6f>
  66e65f:	eb 00                	jmp    66e661 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a61>
  66e661:	49 89 c6             	mov    %rax,%r14
  66e664:	b3 01                	mov    $0x1,%bl
  66e666:	4c 8b 64 24 18       	mov    0x18(%rsp),%r12
  66e66b:	eb 5d                	jmp    66e6ca <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1aca>
  66e66d:	eb 00                	jmp    66e66f <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a6f>
  66e66f:	49 89 c6             	mov    %rax,%r14
  66e672:	4c 8b 64 24 18       	mov    0x18(%rsp),%r12
  66e677:	48 8b b4 24 60 04 00 	mov    0x460(%rsp),%rsi
  66e67e:	00 
  66e67f:	48 85 f6             	test   %rsi,%rsi
  66e682:	74 17                	je     66e69b <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a9b>
  66e684:	48 8b bc 24 68 04 00 	mov    0x468(%rsp),%rdi
  66e68b:	00 
  66e68c:	48 c1 e6 03          	shl    $0x3,%rsi
  66e690:	ba 08 00 00 00       	mov    $0x8,%edx
  66e695:	ff 15 3d b8 11 00    	call   *0x11b83d(%rip)        # 789ed8 <_DYNAMIC+0x238>
  66e69b:	48 8b b4 24 38 01 00 	mov    0x138(%rsp),%rsi
  66e6a2:	00 
  66e6a3:	48 85 f6             	test   %rsi,%rsi
  66e6a6:	75 04                	jne    66e6ac <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1aac>
  66e6a8:	31 db                	xor    %ebx,%ebx
  66e6aa:	eb 1e                	jmp    66e6ca <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1aca>
  66e6ac:	48 8b bc 24 40 01 00 	mov    0x140(%rsp),%rdi
  66e6b3:	00 
  66e6b4:	48 c1 e6 02          	shl    $0x2,%rsi
  66e6b8:	ba 04 00 00 00       	mov    $0x4,%edx
  66e6bd:	ff 15 15 b8 11 00    	call   *0x11b815(%rip)        # 789ed8 <_DYNAMIC+0x238>
  66e6c3:	31 db                	xor    %ebx,%ebx
  66e6c5:	eb 03                	jmp    66e6ca <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1aca>
  66e6c7:	49 89 c6             	mov    %rax,%r14
  66e6ca:	48 8b b4 24 a8 00 00 	mov    0xa8(%rsp),%rsi
  66e6d1:	00 
  66e6d2:	48 85 f6             	test   %rsi,%rsi
  66e6d5:	74 17                	je     66e6ee <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1aee>
  66e6d7:	48 8b bc 24 b0 00 00 	mov    0xb0(%rsp),%rdi
  66e6de:	00 
  66e6df:	48 c1 e6 04          	shl    $0x4,%rsi
  66e6e3:	ba 08 00 00 00       	mov    $0x8,%edx
  66e6e8:	ff 15 ea b7 11 00    	call   *0x11b7ea(%rip)        # 789ed8 <_DYNAMIC+0x238>
  66e6ee:	84 db                	test   %bl,%bl
  66e6f0:	74 1d                	je     66e70f <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1b0f>
  66e6f2:	49 8b 34 24          	mov    (%r12),%rsi
  66e6f6:	48 85 f6             	test   %rsi,%rsi
  66e6f9:	74 14                	je     66e70f <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1b0f>
  66e6fb:	49 8b 7c 24 08       	mov    0x8(%r12),%rdi
  66e700:	48 c1 e6 03          	shl    $0x3,%rsi
  66e704:	ba 08 00 00 00       	mov    $0x8,%edx
  66e709:	ff 15 c9 b7 11 00    	call   *0x11b7c9(%rip)        # 789ed8 <_DYNAMIC+0x238>
  66e70f:	4c 89 f7             	mov    %r14,%rdi
  66e712:	e8 e9 f7 10 00       	call   77df00 <_Unwind_Resume@plt>
