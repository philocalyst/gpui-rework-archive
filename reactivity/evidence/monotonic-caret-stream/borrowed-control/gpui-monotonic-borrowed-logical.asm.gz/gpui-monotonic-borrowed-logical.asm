
/tmp/gpui-monotonic-control-bin/stream-borrowed:     file format elf64-x86-64


Disassembly of section .text:

000000000066ee30 <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>>:
  66ee30:	55                   	push   %rbp
  66ee31:	41 57                	push   %r15
  66ee33:	41 56                	push   %r14
  66ee35:	41 55                	push   %r13
  66ee37:	41 54                	push   %r12
  66ee39:	53                   	push   %rbx
  66ee3a:	48 81 ec 58 02 00 00 	sub    $0x258,%rsp
  66ee41:	48 89 d3             	mov    %rdx,%rbx
  66ee44:	89 f2                	mov    %esi,%edx
  66ee46:	48 89 fe             	mov    %rdi,%rsi
  66ee49:	4c 8d b4 24 48 01 00 	lea    0x148(%rsp),%r14
  66ee50:	00 
  66ee51:	4c 89 f7             	mov    %r14,%rdi
  66ee54:	e8 c7 18 00 00       	call   670720 <<parley::layout::run::Clusters<()>>::new>
  66ee59:	48 8b 03             	mov    (%rbx),%rax
  66ee5c:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
  66ee63:	00 
  66ee64:	48 8b 43 08          	mov    0x8(%rbx),%rax
  66ee68:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
  66ee6f:	00 
  66ee70:	4c 8b 6b 10          	mov    0x10(%rbx),%r13
  66ee74:	48 8b 43 18          	mov    0x18(%rbx),%rax
  66ee78:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
  66ee7d:	48 8b 43 20          	mov    0x20(%rbx),%rax
  66ee81:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  66ee86:	4c 8b 63 30          	mov    0x30(%rbx),%r12
  66ee8a:	4c 8b 7b 38          	mov    0x38(%rbx),%r15
  66ee8e:	48 8b 43 40          	mov    0x40(%rbx),%rax
  66ee92:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  66ee97:	48 8b 6b 68          	mov    0x68(%rbx),%rbp
  66ee9b:	48 8b 43 70          	mov    0x70(%rbx),%rax
  66ee9f:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  66eea4:	48 8b 43 28          	mov    0x28(%rbx),%rax
  66eea8:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  66eead:	48 8b 43 50          	mov    0x50(%rbx),%rax
  66eeb1:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  66eeb6:	48 8b 43 58          	mov    0x58(%rbx),%rax
  66eeba:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
  66eec1:	00 
  66eec2:	48 8b 43 60          	mov    0x60(%rbx),%rax
  66eec6:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  66eecb:	48 8b 43 48          	mov    0x48(%rbx),%rax
  66eecf:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  66eed4:	48 8d bc 24 fc 00 00 	lea    0xfc(%rsp),%rdi
  66eedb:	00 
  66eedc:	4c 89 f6             	mov    %r14,%rsi
  66eedf:	e8 2c 1b 00 00       	call   670a10 <<parley::layout::run::Clusters<()>>::advance_cursor>
  66eee4:	83 bc 24 fc 00 00 00 	cmpl   $0x1,0xfc(%rsp)
  66eeeb:	01 
  66eeec:	0f 85 a8 06 00 00    	jne    66f59a <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0x76a>
  66eef2:	48 8d 45 04          	lea    0x4(%rbp),%rax
  66eef6:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  66eefb:	4c 89 bc 24 e8 00 00 	mov    %r15,0xe8(%rsp)
  66ef02:	00 
  66ef03:	eb 39                	jmp    66ef3e <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0x10e>
  66ef05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  66ef0c:	00 00 00 00 
  66ef10:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  66ef15:	c6 00 00             	movb   $0x0,(%rax)
  66ef18:	48 8d bc 24 fc 00 00 	lea    0xfc(%rsp),%rdi
  66ef1f:	00 
  66ef20:	4c 8d b4 24 48 01 00 	lea    0x148(%rsp),%r14
  66ef27:	00 
  66ef28:	4c 89 f6             	mov    %r14,%rsi
  66ef2b:	e8 e0 1a 00 00       	call   670a10 <<parley::layout::run::Clusters<()>>::advance_cursor>
  66ef30:	80 bc 24 fc 00 00 00 	cmpb   $0x0,0xfc(%rsp)
  66ef37:	00 
  66ef38:	0f 84 5c 06 00 00    	je     66f59a <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0x76a>
  66ef3e:	48 83 bc 24 00 02 00 	cmpq   $0x0,0x200(%rsp)
  66ef45:	00 00 
  66ef47:	0f 84 6b 06 00 00    	je     66f5b8 <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0x788>
  66ef4d:	4c 89 b4 24 10 01 00 	mov    %r14,0x110(%rsp)
  66ef54:	00 
  66ef55:	48 8d 84 24 00 02 00 	lea    0x200(%rsp),%rax
  66ef5c:	00 
  66ef5d:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
  66ef64:	00 
  66ef65:	48 8d 84 24 00 01 00 	lea    0x100(%rsp),%rax
  66ef6c:	00 
  66ef6d:	0f 10 00             	movups (%rax),%xmm0
  66ef70:	48 8d 84 24 20 01 00 	lea    0x120(%rsp),%rax
  66ef77:	00 
  66ef78:	0f 11 00             	movups %xmm0,(%rax)
  66ef7b:	8b 9c 24 20 01 00 00 	mov    0x120(%rsp),%ebx
  66ef82:	8b 94 24 24 01 00 00 	mov    0x124(%rsp),%edx
  66ef89:	48 8b bc 24 e0 00 00 	mov    0xe0(%rsp),%rdi
  66ef90:	00 
  66ef91:	89 de                	mov    %ebx,%esi
  66ef93:	ff 15 bf bc 11 00    	call   *0x11bcbf(%rip)        # 78ac58 <_DYNAMIC+0x5d0>
  66ef99:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  66ef9e:	49 89 d6             	mov    %rdx,%r14
  66efa1:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
  66efa8:	00 
  66efa9:	0f b6 80 8c 00 00 00 	movzbl 0x8c(%rax),%eax
  66efb0:	88 44 24 0f          	mov    %al,0xf(%rsp)
  66efb4:	a8 01                	test   $0x1,%al
  66efb6:	75 58                	jne    66f010 <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0x1e0>
  66efb8:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  66efbd:	f3 0f 10 00          	movss  (%rax),%xmm0
  66efc1:	f3 0f 11 44 24 10    	movss  %xmm0,0x10(%rsp)
  66efc7:	48 83 bc 24 60 01 00 	cmpq   $0x0,0x160(%rsp)
  66efce:	00 00 
  66efd0:	0f 84 7c 00 00 00    	je     66f052 <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0x222>
  66efd6:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  66efdd:	00 
  66efde:	8b bc 24 68 01 00 00 	mov    0x168(%rsp),%edi
  66efe5:	48 8b b0 18 01 00 00 	mov    0x118(%rax),%rsi
  66efec:	48 39 fe             	cmp    %rdi,%rsi
  66efef:	0f 86 e9 05 00 00    	jbe    66f5de <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0x7ae>
  66eff5:	48 8b 80 10 01 00 00 	mov    0x110(%rax),%rax
  66effc:	48 6b cf 70          	imul   $0x70,%rdi,%rcx
  66f000:	f3 0f 10 44 08 50    	movss  0x50(%rax,%rcx,1),%xmm0
  66f006:	8b 44 08 54          	mov    0x54(%rax,%rcx,1),%eax
  66f00a:	eb 4e                	jmp    66f05a <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0x22a>
  66f00c:	0f 1f 40 00          	nopl   0x0(%rax)
  66f010:	48 8b 8c 24 d8 00 00 	mov    0xd8(%rsp),%rcx
  66f017:	00 
  66f018:	48 8b 71 10          	mov    0x10(%rcx),%rsi
  66f01c:	49 8b 45 00          	mov    0x0(%r13),%rax
  66f020:	48 89 c7             	mov    %rax,%rdi
  66f023:	48 f7 d7             	not    %rdi
  66f026:	48 01 f7             	add    %rsi,%rdi
  66f029:	0f 83 a2 05 00 00    	jae    66f5d1 <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0x7a1>
  66f02f:	48 8b 49 08          	mov    0x8(%rcx),%rcx
  66f033:	f3 0f 10 04 b9       	movss  (%rcx,%rdi,4),%xmm0
  66f038:	f3 0f 11 44 24 10    	movss  %xmm0,0x10(%rsp)
  66f03e:	48 ff c0             	inc    %rax
  66f041:	49 89 45 00          	mov    %rax,0x0(%r13)
  66f045:	4c 39 74 24 28       	cmp    %r14,0x28(%rsp)
  66f04a:	0f 83 c0 fe ff ff    	jae    66ef10 <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0xe0>
  66f050:	eb 65                	jmp    66f0b7 <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0x287>
  66f052:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  66f057:	0f 57 c0             	xorps  %xmm0,%xmm0
  66f05a:	48 8b 8c 24 58 01 00 	mov    0x158(%rsp),%rcx
  66f061:	00 
  66f062:	f2 0f 10 49 44       	movsd  0x44(%rcx),%xmm1
  66f067:	f2 0f 11 4c 24 30    	movsd  %xmm1,0x30(%rsp)
  66f06d:	f3 0f 11 44 24 38    	movss  %xmm0,0x38(%rsp)
  66f073:	89 44 24 3c          	mov    %eax,0x3c(%rsp)
  66f077:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
  66f07c:	48 8d b4 24 00 02 00 	lea    0x200(%rsp),%rsi
  66f083:	00 
  66f084:	48 8d 94 24 20 01 00 	lea    0x120(%rsp),%rdx
  66f08b:	00 
  66f08c:	31 c9                	xor    %ecx,%ecx
  66f08e:	ff 15 6c bc 11 00    	call   *0x11bc6c(%rip)        # 78ad00 <_DYNAMIC+0x678>
  66f094:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  66f099:	f3 0f 58 00          	addss  (%rax),%xmm0
  66f09d:	f3 0f 11 00          	movss  %xmm0,(%rax)
  66f0a1:	49 8b 45 00          	mov    0x0(%r13),%rax
  66f0a5:	48 ff c0             	inc    %rax
  66f0a8:	49 89 45 00          	mov    %rax,0x0(%r13)
  66f0ac:	4c 39 74 24 28       	cmp    %r14,0x28(%rsp)
  66f0b1:	0f 83 59 fe ff ff    	jae    66ef10 <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0xe0>
  66f0b7:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  66f0bc:	48 83 b8 50 01 00 00 	cmpq   $0x0,0x150(%rax)
  66f0c3:	00 
  66f0c4:	0f 84 46 fe ff ff    	je     66ef10 <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0xe0>
  66f0ca:	48 8b 84 24 68 01 00 	mov    0x168(%rsp),%rax
  66f0d1:	00 
  66f0d2:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  66f0d7:	89 5c 24 38          	mov    %ebx,0x38(%rsp)
  66f0db:	f3 0f 10 44 24 10    	movss  0x10(%rsp),%xmm0
  66f0e1:	f3 0f 11 44 24 3c    	movss  %xmm0,0x3c(%rsp)
  66f0e7:	0f b7 84 24 2c 01 00 	movzwl 0x12c(%rsp),%eax
  66f0ee:	00 
  66f0ef:	83 e0 0e             	and    $0xe,%eax
  66f0f2:	89 44 24 14          	mov    %eax,0x14(%rsp)
  66f0f6:	4c 89 b4 24 f0 00 00 	mov    %r14,0xf0(%rsp)
  66f0fd:	00 
  66f0fe:	eb 3d                	jmp    66f13d <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0x30d>
  66f100:	49 8b 4d 08          	mov    0x8(%r13),%rcx
  66f104:	48 8d 14 6d 00 00 00 	lea    0x0(,%rbp,2),%rdx
  66f10b:	00 
  66f10c:	48 01 ea             	add    %rbp,%rdx
  66f10f:	48 8d 04 91          	lea    (%rcx,%rdx,4),%rax
  66f113:	89 1c 91             	mov    %ebx,(%rcx,%rdx,4)
  66f116:	b1 03                	mov    $0x3,%cl
  66f118:	f3 0f 11 60 04       	movss  %xmm4,0x4(%rax)
  66f11d:	88 48 08             	mov    %cl,0x8(%rax)
  66f120:	48 ff c5             	inc    %rbp
  66f123:	49 89 6d 10          	mov    %rbp,0x10(%r13)
  66f127:	4d 89 f5             	mov    %r14,%r13
  66f12a:	4c 89 fd             	mov    %r15,%rbp
  66f12d:	4c 8b bc 24 e8 00 00 	mov    0xe8(%rsp),%r15
  66f134:	00 
  66f135:	4c 8b b4 24 f0 00 00 	mov    0xf0(%rsp),%r14
  66f13c:	00 
  66f13d:	49 8b 04 24          	mov    (%r12),%rax
  66f141:	48 83 f8 02          	cmp    $0x2,%rax
  66f145:	75 13                	jne    66f15a <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0x32a>
  66f147:	49 8d 7c 24 10       	lea    0x10(%r12),%rdi
  66f14c:	e8 af 87 00 00       	call   677900 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  66f151:	49 89 04 24          	mov    %rax,(%r12)
  66f155:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
  66f15a:	48 83 f8 01          	cmp    $0x1,%rax
  66f15e:	0f 85 ca 03 00 00    	jne    66f52e <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0x6fe>
  66f164:	49 8b 5c 24 08       	mov    0x8(%r12),%rbx
  66f169:	4c 39 f3             	cmp    %r14,%rbx
  66f16c:	0f 83 bc 03 00 00    	jae    66f52e <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0x6fe>
  66f172:	41 80 3f 00          	cmpb   $0x0,(%r15)
  66f176:	74 0a                	je     66f182 <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0x352>
  66f178:	49 3b 5f 08          	cmp    0x8(%r15),%rbx
  66f17c:	0f 82 f2 03 00 00    	jb     66f574 <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0x744>
  66f182:	49 c7 04 24 02 00 00 	movq   $0x2,(%r12)
  66f189:	00 
  66f18a:	49 c7 07 01 00 00 00 	movq   $0x1,(%r15)
  66f191:	49 89 5f 08          	mov    %rbx,0x8(%r15)
  66f195:	48 3b 5c 24 28       	cmp    0x28(%rsp),%rbx
  66f19a:	0f 85 80 00 00 00    	jne    66f220 <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0x3f0>
  66f1a0:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  66f1a5:	80 38 00             	cmpb   $0x0,(%rax)
  66f1a8:	74 21                	je     66f1cb <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0x39b>
  66f1aa:	66 83 7c 24 14 0c    	cmpw   $0xc,0x14(%rsp)
  66f1b0:	0f 94 c0             	sete   %al
  66f1b3:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  66f1b8:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
  66f1bd:	48 39 11             	cmp    %rdx,(%rcx)
  66f1c0:	0f 95 c1             	setne  %cl
  66f1c3:	08 c1                	or     %al,%cl
  66f1c5:	0f 84 c5 00 00 00    	je     66f290 <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0x460>
  66f1cb:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  66f1d0:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
  66f1d5:	48 39 10             	cmp    %rdx,(%rax)
  66f1d8:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  66f1dd:	f3 0f 10 00          	movss  (%rax),%xmm0
  66f1e1:	b9 00 00 00 00       	mov    $0x0,%ecx
  66f1e6:	48 0f 44 4c 24 40    	cmove  0x40(%rsp),%rcx
  66f1ec:	80 7d 00 00          	cmpb   $0x0,0x0(%rbp)
  66f1f0:	b8 00 00 00 00       	mov    $0x0,%eax
  66f1f5:	48 0f 44 c8          	cmove  %rax,%rcx
  66f1f9:	48 8d 7c 24 78       	lea    0x78(%rsp),%rdi
  66f1fe:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  66f203:	4c 8d 44 24 30       	lea    0x30(%rsp),%r8
  66f208:	ff 15 fa ba 11 00    	call   *0x11bafa(%rip)        # 78ad08 <_DYNAMIC+0x680>
  66f20e:	48 83 7c 24 78 01    	cmpq   $0x1,0x78(%rsp)
  66f214:	0f 85 23 ff ff ff    	jne    66f13d <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0x30d>
  66f21a:	e9 61 01 00 00       	jmp    66f380 <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0x550>
  66f21f:	90                   	nop
  66f220:	76 1e                	jbe    66f240 <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0x410>
  66f222:	48 c7 44 24 78 00 00 	movq   $0x0,0x78(%rsp)
  66f229:	00 00 
  66f22b:	48 83 7c 24 78 01    	cmpq   $0x1,0x78(%rsp)
  66f231:	0f 85 06 ff ff ff    	jne    66f13d <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0x30d>
  66f237:	e9 44 01 00 00       	jmp    66f380 <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0x550>
  66f23c:	0f 1f 40 00          	nopl   0x0(%rax)
  66f240:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  66f245:	48 39 18             	cmp    %rbx,(%rax)
  66f248:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  66f24d:	f3 0f 10 00          	movss  (%rax),%xmm0
  66f251:	b9 00 00 00 00       	mov    $0x0,%ecx
  66f256:	48 0f 44 4c 24 40    	cmove  0x40(%rsp),%rcx
  66f25c:	80 7d 00 00          	cmpb   $0x0,0x0(%rbp)
  66f260:	b8 00 00 00 00       	mov    $0x0,%eax
  66f265:	48 0f 44 c8          	cmove  %rax,%rcx
  66f269:	48 8d 7c 24 78       	lea    0x78(%rsp),%rdi
  66f26e:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  66f273:	48 89 da             	mov    %rbx,%rdx
  66f276:	45 31 c0             	xor    %r8d,%r8d
  66f279:	ff 15 89 ba 11 00    	call   *0x11ba89(%rip)        # 78ad08 <_DYNAMIC+0x680>
  66f27f:	48 83 7c 24 78 01    	cmpq   $0x1,0x78(%rsp)
  66f285:	0f 85 b2 fe ff ff    	jne    66f13d <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0x30d>
  66f28b:	e9 f0 00 00 00       	jmp    66f380 <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0x550>
  66f290:	f3 0f 10 44 24 10    	movss  0x10(%rsp),%xmm0
  66f296:	f6 44 24 0f 01       	testb  $0x1,0xf(%rsp)
  66f29b:	74 09                	je     66f2a6 <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0x476>
  66f29d:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  66f2a2:	f3 0f 10 00          	movss  (%rax),%xmm0
  66f2a6:	48 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%rax
  66f2ad:	00 
  66f2ae:	48 8b 40 08          	mov    0x8(%rax),%rax
  66f2b2:	0f 57 c9             	xorps  %xmm1,%xmm1
  66f2b5:	f3 0f 5a c8          	cvtss2sd %xmm0,%xmm1
  66f2b9:	f3 0f 10 50 40       	movss  0x40(%rax),%xmm2
  66f2be:	f3 0f 10 58 44       	movss  0x44(%rax),%xmm3
  66f2c3:	0f 28 e2             	movaps %xmm2,%xmm4
  66f2c6:	f3 0f 5d 60 48       	minss  0x48(%rax),%xmm4
  66f2cb:	0f 28 ec             	movaps %xmm4,%xmm5
  66f2ce:	f3 0f c2 ec 03       	cmpunordss %xmm4,%xmm5
  66f2d3:	0f 28 f5             	movaps %xmm5,%xmm6
  66f2d6:	0f 55 f4             	andnps %xmm4,%xmm6
  66f2d9:	0f 54 ea             	andps  %xmm2,%xmm5
  66f2dc:	0f 56 ee             	orps   %xmm6,%xmm5
  66f2df:	0f 57 d2             	xorps  %xmm2,%xmm2
  66f2e2:	f3 0f 5a d5          	cvtss2sd %xmm5,%xmm2
  66f2e6:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
  66f2eb:	f3 0f 58 01          	addss  (%rcx),%xmm0
  66f2ef:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
  66f2f3:	0f 28 e3             	movaps %xmm3,%xmm4
  66f2f6:	f3 0f 5f 60 4c       	maxss  0x4c(%rax),%xmm4
  66f2fb:	0f 28 ec             	movaps %xmm4,%xmm5
  66f2fe:	f3 0f c2 ec 03       	cmpunordss %xmm4,%xmm5
  66f303:	0f 28 f5             	movaps %xmm5,%xmm6
  66f306:	0f 55 f4             	andnps %xmm4,%xmm6
  66f309:	0f 54 eb             	andps  %xmm3,%xmm5
  66f30c:	0f 56 ee             	orps   %xmm6,%xmm5
  66f30f:	0f 57 db             	xorps  %xmm3,%xmm3
  66f312:	f3 0f 5a dd          	cvtss2sd %xmm5,%xmm3
  66f316:	f2 0f 11 8c 24 80 00 	movsd  %xmm1,0x80(%rsp)
  66f31d:	00 00 
  66f31f:	f2 0f 11 94 24 88 00 	movsd  %xmm2,0x88(%rsp)
  66f326:	00 00 
  66f328:	f2 0f 11 84 24 90 00 	movsd  %xmm0,0x90(%rsp)
  66f32f:	00 00 
  66f331:	f2 0f 11 9c 24 98 00 	movsd  %xmm3,0x98(%rsp)
  66f338:	00 00 
  66f33a:	f2 0f 11 8c 24 a0 00 	movsd  %xmm1,0xa0(%rsp)
  66f341:	00 00 
  66f343:	f2 0f 11 94 24 a8 00 	movsd  %xmm2,0xa8(%rsp)
  66f34a:	00 00 
  66f34c:	f2 0f 11 84 24 b0 00 	movsd  %xmm0,0xb0(%rsp)
  66f353:	00 00 
  66f355:	f2 0f 11 9c 24 b8 00 	movsd  %xmm3,0xb8(%rsp)
  66f35c:	00 00 
  66f35e:	48 c7 44 24 78 01 00 	movq   $0x1,0x78(%rsp)
  66f365:	00 00 
  66f367:	48 83 7c 24 78 01    	cmpq   $0x1,0x78(%rsp)
  66f36d:	0f 85 ca fd ff ff    	jne    66f13d <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0x30d>
  66f373:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  66f37a:	84 00 00 00 00 00 
  66f380:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  66f385:	48 8b 00             	mov    (%rax),%rax
  66f388:	48 8b 48 08          	mov    0x8(%rax),%rcx
  66f38c:	f3 0f 10 01          	movss  (%rcx),%xmm0
  66f390:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
  66f394:	66 0f 10 8c 24 80 00 	movupd 0x80(%rsp),%xmm1
  66f39b:	00 00 
  66f39d:	66 0f 10 94 24 90 00 	movupd 0x90(%rsp),%xmm2
  66f3a4:	00 00 
  66f3a6:	f2 0f 10 9c 24 88 00 	movsd  0x88(%rsp),%xmm3
  66f3ad:	00 00 
  66f3af:	f2 0f 58 d8          	addsd  %xmm0,%xmm3
  66f3b3:	66 0f 5c d1          	subpd  %xmm1,%xmm2
  66f3b7:	66 0f 14 cb          	unpcklpd %xmm3,%xmm1
  66f3bb:	66 0f 5a e1          	cvtpd2ps %xmm1,%xmm4
  66f3bf:	66 0f 5a ca          	cvtpd2ps %xmm2,%xmm1
  66f3c3:	66 0f 14 e1          	unpcklpd %xmm1,%xmm4
  66f3c7:	66 0f 28 cc          	movapd %xmm4,%xmm1
  66f3cb:	66 0f 28 1d cd 61 9b 	movapd -0x649e33(%rip),%xmm3        # 255a0 <anon.0798ea9c2d8130e279e9b803b375062d.0.llvm.722421148570242323+0x7e0>
  66f3d2:	ff 
  66f3d3:	66 0f 54 cb          	andpd  %xmm3,%xmm1
  66f3d7:	66 0f 66 0d 91 5b 9b 	pcmpgtd -0x64a46f(%rip),%xmm1        # 24f70 <anon.0798ea9c2d8130e279e9b803b375062d.0.llvm.722421148570242323+0x1b0>
  66f3de:	ff 
  66f3df:	0f 50 c9             	movmskps %xmm1,%ecx
  66f3e2:	85 c9                	test   %ecx,%ecx
  66f3e4:	0f 85 b7 01 00 00    	jne    66f5a1 <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0x771>
  66f3ea:	66 0f 10 8c 24 a0 00 	movupd 0xa0(%rsp),%xmm1
  66f3f1:	00 00 
  66f3f3:	66 0f 10 94 24 b0 00 	movupd 0xb0(%rsp),%xmm2
  66f3fa:	00 00 
  66f3fc:	f2 0f 58 84 24 a8 00 	addsd  0xa8(%rsp),%xmm0
  66f403:	00 00 
  66f405:	66 0f 5c d1          	subpd  %xmm1,%xmm2
  66f409:	66 0f 14 c8          	unpcklpd %xmm0,%xmm1
  66f40d:	66 0f 5a c2          	cvtpd2ps %xmm2,%xmm0
  66f411:	66 0f 5a c9          	cvtpd2ps %xmm1,%xmm1
  66f415:	66 0f 14 c8          	unpcklpd %xmm0,%xmm1
  66f419:	66 0f 28 c1          	movapd %xmm1,%xmm0
  66f41d:	66 0f 54 c3          	andpd  %xmm3,%xmm0
  66f421:	66 0f 66 05 47 5b 9b 	pcmpgtd -0x64a4b9(%rip),%xmm0        # 24f70 <anon.0798ea9c2d8130e279e9b803b375062d.0.llvm.722421148570242323+0x1b0>
  66f428:	ff 
  66f429:	0f 50 c8             	movmskps %xmm0,%ecx
  66f42c:	85 c9                	test   %ecx,%ecx
  66f42e:	0f 85 6d 01 00 00    	jne    66f5a1 <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0x771>
  66f434:	49 89 ef             	mov    %rbp,%r15
  66f437:	4d 89 ee             	mov    %r13,%r14
  66f43a:	48 8b 48 10          	mov    0x10(%rax),%rcx
  66f43e:	4c 8b 68 18          	mov    0x18(%rax),%r13
  66f442:	03 19                	add    (%rcx),%ebx
  66f444:	66 0f 28 c4          	movapd %xmm4,%xmm0
  66f448:	0f c2 c1 00          	cmpeqps %xmm1,%xmm0
  66f44c:	0f 50 c0             	movmskps %xmm0,%eax
  66f44f:	a8 08                	test   $0x8,%al
  66f451:	74 4d                	je     66f4a0 <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0x670>
  66f453:	89 c1                	mov    %eax,%ecx
  66f455:	80 e1 04             	and    $0x4,%cl
  66f458:	c0 e9 02             	shr    $0x2,%cl
  66f45b:	74 43                	je     66f4a0 <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0x670>
  66f45d:	0f 2e e1             	ucomiss %xmm1,%xmm4
  66f460:	75 3e                	jne    66f4a0 <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0x670>
  66f462:	7a 3c                	jp     66f4a0 <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0x670>
  66f464:	24 02                	and    $0x2,%al
  66f466:	d0 e8                	shr    $1,%al
  66f468:	74 36                	je     66f4a0 <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0x670>
  66f46a:	49 8b 6d 10          	mov    0x10(%r13),%rbp
  66f46e:	49 3b 6d 00          	cmp    0x0(%r13),%rbp
  66f472:	0f 85 88 fc ff ff    	jne    66f100 <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0x2d0>
  66f478:	4c 89 ef             	mov    %r13,%rdi
  66f47b:	0f 29 a4 24 c0 00 00 	movaps %xmm4,0xc0(%rsp)
  66f482:	00 
  66f483:	ff 15 af b6 11 00    	call   *0x11b6af(%rip)        # 78ab38 <_DYNAMIC+0x4b0>
  66f489:	0f 28 a4 24 c0 00 00 	movaps 0xc0(%rsp),%xmm4
  66f490:	00 
  66f491:	e9 6a fc ff ff       	jmp    66f100 <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0x2d0>
  66f496:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  66f49d:	00 00 00 
  66f4a0:	49 8b 6d 10          	mov    0x10(%r13),%rbp
  66f4a4:	49 3b 6d 00          	cmp    0x0(%r13),%rbp
  66f4a8:	0f 29 8c 24 30 01 00 	movaps %xmm1,0x130(%rsp)
  66f4af:	00 
  66f4b0:	75 21                	jne    66f4d3 <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0x6a3>
  66f4b2:	4c 89 ef             	mov    %r13,%rdi
  66f4b5:	0f 29 a4 24 c0 00 00 	movaps %xmm4,0xc0(%rsp)
  66f4bc:	00 
  66f4bd:	ff 15 75 b6 11 00    	call   *0x11b675(%rip)        # 78ab38 <_DYNAMIC+0x4b0>
  66f4c3:	0f 28 8c 24 30 01 00 	movaps 0x130(%rsp),%xmm1
  66f4ca:	00 
  66f4cb:	0f 28 a4 24 c0 00 00 	movaps 0xc0(%rsp),%xmm4
  66f4d2:	00 
  66f4d3:	49 8b 45 08          	mov    0x8(%r13),%rax
  66f4d7:	48 8d 0c 6d 00 00 00 	lea    0x0(,%rbp,2),%rcx
  66f4de:	00 
  66f4df:	48 01 e9             	add    %rbp,%rcx
  66f4e2:	89 1c 88             	mov    %ebx,(%rax,%rcx,4)
  66f4e5:	f3 0f 11 64 88 04    	movss  %xmm4,0x4(%rax,%rcx,4)
  66f4eb:	c6 44 88 08 01       	movb   $0x1,0x8(%rax,%rcx,4)
  66f4f0:	48 ff c5             	inc    %rbp
  66f4f3:	49 89 6d 10          	mov    %rbp,0x10(%r13)
  66f4f7:	49 3b 6d 00          	cmp    0x0(%r13),%rbp
  66f4fb:	75 11                	jne    66f50e <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0x6de>
  66f4fd:	4c 89 ef             	mov    %r13,%rdi
  66f500:	ff 15 32 b6 11 00    	call   *0x11b632(%rip)        # 78ab38 <_DYNAMIC+0x4b0>
  66f506:	0f 28 8c 24 30 01 00 	movaps 0x130(%rsp),%xmm1
  66f50d:	00 
  66f50e:	49 8b 4d 08          	mov    0x8(%r13),%rcx
  66f512:	48 8d 14 6d 00 00 00 	lea    0x0(,%rbp,2),%rdx
  66f519:	00 
  66f51a:	48 01 ea             	add    %rbp,%rdx
  66f51d:	48 8d 04 91          	lea    (%rcx,%rdx,4),%rax
  66f521:	89 1c 91             	mov    %ebx,(%rcx,%rdx,4)
  66f524:	b1 02                	mov    $0x2,%cl
  66f526:	0f 28 e1             	movaps %xmm1,%xmm4
  66f529:	e9 ea fb ff ff       	jmp    66f118 <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0x2e8>
  66f52e:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  66f533:	4c 89 30             	mov    %r14,(%rax)
  66f536:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  66f53b:	f3 0f 10 44 24 10    	movss  0x10(%rsp),%xmm0
  66f541:	f3 0f 11 00          	movss  %xmm0,(%rax)
  66f545:	66 83 7c 24 14 0c    	cmpw   $0xc,0x14(%rsp)
  66f54b:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  66f550:	0f 95 00             	setne  (%rax)
  66f553:	c7 45 00 01 00 00 00 	movl   $0x1,0x0(%rbp)
  66f55a:	0f 10 44 24 30       	movups 0x30(%rsp),%xmm0
  66f55f:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  66f564:	0f 11 00             	movups %xmm0,(%rax)
  66f567:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  66f56c:	4c 89 30             	mov    %r14,(%rax)
  66f56f:	e9 a4 f9 ff ff       	jmp    66ef18 <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0xe8>
  66f574:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  66f579:	f3 0f 10 00          	movss  (%rax),%xmm0
  66f57d:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  66f582:	4c 89 e6             	mov    %r12,%rsi
  66f585:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
  66f58a:	e8 f1 c5 00 00       	call   67bb80 <parley::editing::geometry::visit_direct::<(), gpui_canvas::Error, &mut core::iter::adapters::peekable::Peekable<icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>>, gpui_canvas::text::planner::append_carets::{closure#1}>>
  66f58f:	83 f8 fe             	cmp    $0xfffffffe,%eax
  66f592:	0f 84 80 f9 ff ff    	je     66ef18 <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0xe8>
  66f598:	eb 0c                	jmp    66f5a6 <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0x776>
  66f59a:	b8 fe ff ff ff       	mov    $0xfffffffe,%eax
  66f59f:	eb 05                	jmp    66f5a6 <<parley::layout::run::Run<()>>::try_for_each_caret_cluster::<core::ops::control_flow::ControlFlow<gpui_canvas::Error>, parley::editing::geometry::visit_source_pairs<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>::{closure#2}>+0x776>
  66f5a1:	b8 01 00 00 00       	mov    $0x1,%eax
  66f5a6:	48 81 c4 58 02 00 00 	add    $0x258,%rsp
  66f5ad:	5b                   	pop    %rbx
  66f5ae:	41 5c                	pop    %r12
  66f5b0:	41 5d                	pop    %r13
  66f5b2:	41 5e                	pop    %r14
  66f5b4:	41 5f                	pop    %r15
  66f5b6:	5d                   	pop    %rbp
  66f5b7:	c3                   	ret
  66f5b8:	48 8d 3d c1 e7 be ff 	lea    -0x41183f(%rip),%rdi        # 25dd80 <anon.62868e170f60758b8c346cd4185a0643.0.llvm.4228727425897277816>
  66f5bf:	48 8d 15 6a 0b 11 00 	lea    0x110b6a(%rip),%rdx        # 780130 <anon.62868e170f60758b8c346cd4185a0643.2.llvm.4228727425897277816>
  66f5c6:	be 63 00 00 00       	mov    $0x63,%esi
  66f5cb:	ff 15 97 b5 11 00    	call   *0x11b597(%rip)        # 78ab68 <_DYNAMIC+0x4e0>
  66f5d1:	48 8d 15 88 0b 11 00 	lea    0x110b88(%rip),%rdx        # 780160 <anon.62868e170f60758b8c346cd4185a0643.3.llvm.4228727425897277816+0x18>
  66f5d8:	ff 15 0a b4 11 00    	call   *0x11b40a(%rip)        # 78a9e8 <_DYNAMIC+0x360>
  66f5de:	48 8d 15 63 0b 11 00 	lea    0x110b63(%rip),%rdx        # 780148 <anon.62868e170f60758b8c346cd4185a0643.3.llvm.4228727425897277816>
  66f5e5:	ff 15 fd b3 11 00    	call   *0x11b3fd(%rip)        # 78a9e8 <_DYNAMIC+0x360>
