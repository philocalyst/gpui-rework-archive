
/tmp/gpui-monotonic-control-bin/stream-borrowed:     file format elf64-x86-64


Disassembly of section .text:

000000000067caa0 <parley::editing::geometry::pair_from_entries::<()>>:
  67caa0:	55                   	push   %rbp
  67caa1:	41 57                	push   %r15
  67caa3:	41 56                	push   %r14
  67caa5:	41 55                	push   %r13
  67caa7:	41 54                	push   %r12
  67caa9:	53                   	push   %rbx
  67caaa:	48 81 ec d8 01 00 00 	sub    $0x1d8,%rsp
  67cab1:	49 89 f6             	mov    %rsi,%r14
  67cab4:	48 89 fb             	mov    %rdi,%rbx
  67cab7:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  67cabc:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
  67cac1:	4d 85 c0             	test   %r8,%r8
  67cac4:	74 4a                	je     67cb10 <parley::editing::geometry::pair_from_entries::<()>+0x70>
  67cac6:	41 8b 00             	mov    (%r8),%eax
  67cac9:	49 39 86 18 01 00 00 	cmp    %rax,0x118(%r14)
  67cad0:	76 3e                	jbe    67cb10 <parley::editing::geometry::pair_from_entries::<()>+0x70>
  67cad2:	41 8b 70 04          	mov    0x4(%r8),%esi
  67cad6:	4c 6b c8 70          	imul   $0x70,%rax,%r9
  67cada:	4d 8b 96 10 01 00 00 	mov    0x110(%r14),%r10
  67cae1:	4b 8b 7c 0a 10       	mov    0x10(%r10,%r9,1),%rdi
  67cae6:	48 01 f7             	add    %rsi,%rdi
  67cae9:	4b 3b 7c 0a 18       	cmp    0x18(%r10,%r9,1),%rdi
  67caee:	73 20                	jae    67cb10 <parley::editing::geometry::pair_from_entries::<()>+0x70>
  67caf0:	49 3b be 30 01 00 00 	cmp    0x130(%r14),%rdi
  67caf7:	73 17                	jae    67cb10 <parley::editing::geometry::pair_from_entries::<()>+0x70>
  67caf9:	4d 8b 8e 28 01 00 00 	mov    0x128(%r14),%r9
  67cb00:	48 8d 3c bf          	lea    (%rdi,%rdi,4),%rdi
  67cb04:	41 80 7c f9 21 00    	cmpb   $0x0,0x21(%r9,%rdi,8)
  67cb0a:	0f 84 e7 01 00 00    	je     67ccf7 <parley::editing::geometry::pair_from_entries::<()>+0x257>
  67cb10:	48 c7 84 24 48 01 00 	movq   $0x0,0x148(%rsp)
  67cb17:	00 00 00 00 00 
  67cb1c:	49 8b 86 50 01 00 00 	mov    0x150(%r14),%rax
  67cb23:	40 b5 01             	mov    $0x1,%bpl
  67cb26:	45 31 ff             	xor    %r15d,%r15d
  67cb29:	48 39 d0             	cmp    %rdx,%rax
  67cb2c:	0f 85 0a 03 00 00    	jne    67ce3c <parley::editing::geometry::pair_from_entries::<()>+0x39c>
  67cb32:	48 85 c9             	test   %rcx,%rcx
  67cb35:	f3 0f 11 44 24 0c    	movss  %xmm0,0xc(%rsp)
  67cb3b:	74 48                	je     67cb85 <parley::editing::geometry::pair_from_entries::<()>+0xe5>
  67cb3d:	8b 01                	mov    (%rcx),%eax
  67cb3f:	49 39 86 18 01 00 00 	cmp    %rax,0x118(%r14)
  67cb46:	76 3d                	jbe    67cb85 <parley::editing::geometry::pair_from_entries::<()>+0xe5>
  67cb48:	8b 71 04             	mov    0x4(%rcx),%esi
  67cb4b:	4c 6b c0 70          	imul   $0x70,%rax,%r8
  67cb4f:	4d 8b 8e 10 01 00 00 	mov    0x110(%r14),%r9
  67cb56:	4b 8b 7c 01 10       	mov    0x10(%r9,%r8,1),%rdi
  67cb5b:	48 01 f7             	add    %rsi,%rdi
  67cb5e:	4b 3b 7c 01 18       	cmp    0x18(%r9,%r8,1),%rdi
  67cb63:	73 20                	jae    67cb85 <parley::editing::geometry::pair_from_entries::<()>+0xe5>
  67cb65:	49 3b be 30 01 00 00 	cmp    0x130(%r14),%rdi
  67cb6c:	73 17                	jae    67cb85 <parley::editing::geometry::pair_from_entries::<()>+0xe5>
  67cb6e:	4d 8b 86 28 01 00 00 	mov    0x128(%r14),%r8
  67cb75:	48 8d 3c bf          	lea    (%rdi,%rdi,4),%rdi
  67cb79:	41 80 7c f8 21 00    	cmpb   $0x0,0x21(%r8,%rdi,8)
  67cb7f:	0f 84 d3 02 00 00    	je     67ce58 <parley::editing::geometry::pair_from_entries::<()>+0x3b8>
  67cb85:	48 c7 84 24 b8 00 00 	movq   $0x0,0xb8(%rsp)
  67cb8c:	00 00 00 00 00 
  67cb91:	45 31 e4             	xor    %r12d,%r12d
  67cb94:	48 89 54 24 60       	mov    %rdx,0x60(%rsp)
  67cb99:	40 88 6c 24 68       	mov    %bpl,0x68(%rsp)
  67cb9e:	4c 89 64 24 20       	mov    %r12,0x20(%rsp)
  67cba3:	4c 89 7c 24 28       	mov    %r15,0x28(%rsp)
  67cba8:	48 8d bc 24 98 00 00 	lea    0x98(%rsp),%rdi
  67cbaf:	00 
  67cbb0:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
  67cbb5:	48 8d 4c 24 20       	lea    0x20(%rsp),%rcx
  67cbba:	4c 8d 44 24 10       	lea    0x10(%rsp),%r8
  67cbbf:	4c 8d 4c 24 18       	lea    0x18(%rsp),%r9
  67cbc4:	49 89 d5             	mov    %rdx,%r13
  67cbc7:	4c 89 f2             	mov    %r14,%rdx
  67cbca:	e8 c1 95 00 00       	call   686190 <<parley::editing::cursor::Cursor>::geometry_with::<(), parley::editing::geometry::pair_from_entries<()>::{closure#2}::{closure#0}>>
  67cbcf:	4d 85 ed             	test   %r13,%r13
  67cbd2:	0f 84 bb 00 00 00    	je     67cc93 <parley::editing::geometry::pair_from_entries::<()>+0x1f3>
  67cbd8:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  67cbdf:	00 
  67cbe0:	48 85 c0             	test   %rax,%rax
  67cbe3:	0f 84 aa 00 00 00    	je     67cc93 <parley::editing::geometry::pair_from_entries::<()>+0x1f3>
  67cbe9:	8b bc 24 70 01 00 00 	mov    0x170(%rsp),%edi
  67cbf0:	48 8b 70 58          	mov    0x58(%rax),%rsi
  67cbf4:	48 39 fe             	cmp    %rdi,%rsi
  67cbf7:	0f 86 ef 02 00 00    	jbe    67ceec <parley::editing::geometry::pair_from_entries::<()>+0x44c>
  67cbfd:	48 8b 48 50          	mov    0x50(%rax),%rcx
  67cc01:	48 8d 14 ff          	lea    (%rdi,%rdi,8),%rdx
  67cc05:	48 c1 e2 04          	shl    $0x4,%rdx
  67cc09:	0f 10 40 68          	movups 0x68(%rax),%xmm0
  67cc0d:	0f 10 88 80 00 00 00 	movups 0x80(%rax),%xmm1
  67cc14:	0f 10 90 98 00 00 00 	movups 0x98(%rax),%xmm2
  67cc1b:	0f 11 44 24 20       	movups %xmm0,0x20(%rsp)
  67cc20:	0f 11 4c 24 30       	movups %xmm1,0x30(%rsp)
  67cc25:	0f 11 54 24 40       	movups %xmm2,0x40(%rsp)
  67cc2a:	48 8b 44 11 50       	mov    0x50(%rcx,%rdx,1),%rax
  67cc2f:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  67cc34:	8b b4 24 c8 01 00 00 	mov    0x1c8(%rsp),%esi
  67cc3b:	8b 94 24 cc 01 00 00 	mov    0x1cc(%rsp),%edx
  67cc42:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
  67cc47:	ff 15 0b e0 10 00    	call   *0x10e00b(%rip)        # 78ac58 <_DYNAMIC+0x5d0>
  67cc4d:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
  67cc54:	00 
  67cc55:	c6 84 24 90 00 00 00 	movb   $0x0,0x90(%rsp)
  67cc5c:	00 
  67cc5d:	4c 89 64 24 20       	mov    %r12,0x20(%rsp)
  67cc62:	4c 89 7c 24 28       	mov    %r15,0x28(%rsp)
  67cc67:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
  67cc6c:	48 8d b4 24 88 00 00 	lea    0x88(%rsp),%rsi
  67cc73:	00 
  67cc74:	48 8d 4c 24 20       	lea    0x20(%rsp),%rcx
  67cc79:	4c 8d 44 24 10       	lea    0x10(%rsp),%r8
  67cc7e:	4c 8d 4c 24 18       	lea    0x18(%rsp),%r9
  67cc83:	4c 89 f2             	mov    %r14,%rdx
  67cc86:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  67cc8c:	e8 ff 94 00 00       	call   686190 <<parley::editing::cursor::Cursor>::geometry_with::<(), parley::editing::geometry::pair_from_entries<()>::{closure#2}::{closure#0}>>
  67cc91:	eb 1a                	jmp    67ccad <parley::editing::geometry::pair_from_entries::<()>+0x20d>
  67cc93:	0f 10 84 24 98 00 00 	movups 0x98(%rsp),%xmm0
  67cc9a:	00 
  67cc9b:	0f 10 8c 24 a8 00 00 	movups 0xa8(%rsp),%xmm1
  67cca2:	00 
  67cca3:	0f 29 4c 24 70       	movaps %xmm1,0x70(%rsp)
  67cca8:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
  67ccad:	0f 10 84 24 98 00 00 	movups 0x98(%rsp),%xmm0
  67ccb4:	00 
  67ccb5:	0f 10 8c 24 a8 00 00 	movups 0xa8(%rsp),%xmm1
  67ccbc:	00 
  67ccbd:	0f 29 4c 24 30       	movaps %xmm1,0x30(%rsp)
  67ccc2:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
  67ccc7:	0f 28 54 24 60       	movaps 0x60(%rsp),%xmm2
  67cccc:	0f 28 5c 24 70       	movaps 0x70(%rsp),%xmm3
  67ccd1:	0f 29 54 24 40       	movaps %xmm2,0x40(%rsp)
  67ccd6:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
  67ccdb:	0f 11 5b 38          	movups %xmm3,0x38(%rbx)
  67ccdf:	0f 11 53 28          	movups %xmm2,0x28(%rbx)
  67cce3:	0f 11 4b 18          	movups %xmm1,0x18(%rbx)
  67cce7:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
  67cceb:	48 c7 03 01 00 00 00 	movq   $0x1,(%rbx)
  67ccf2:	e9 4c 01 00 00       	jmp    67ce43 <parley::editing::geometry::pair_from_entries::<()>+0x3a3>
  67ccf7:	4d 8d 0c f9          	lea    (%r9,%rdi,8),%r9
  67ccfb:	49 8b 79 10          	mov    0x10(%r9),%rdi
  67ccff:	49 3b 7e 58          	cmp    0x58(%r14),%rdi
  67cd03:	0f 83 07 fe ff ff    	jae    67cb10 <parley::editing::geometry::pair_from_entries::<()>+0x70>
  67cd09:	49 3b be e8 00 00 00 	cmp    0xe8(%r14),%rdi
  67cd10:	0f 83 fa fd ff ff    	jae    67cb10 <parley::editing::geometry::pair_from_entries::<()>+0x70>
  67cd16:	4c 8d 14 ff          	lea    (%rdi,%rdi,8),%r10
  67cd1a:	49 c1 e2 04          	shl    $0x4,%r10
  67cd1e:	4d 03 56 50          	add    0x50(%r14),%r10
  67cd22:	4c 8d 1c bf          	lea    (%rdi,%rdi,4),%r11
  67cd26:	49 c1 e3 04          	shl    $0x4,%r11
  67cd2a:	4d 03 9e e0 00 00 00 	add    0xe0(%r14),%r11
  67cd31:	4c 89 b4 24 b8 00 00 	mov    %r14,0xb8(%rsp)
  67cd38:	00 
  67cd39:	4c 89 94 24 c0 00 00 	mov    %r10,0xc0(%rsp)
  67cd40:	00 
  67cd41:	4c 89 9c 24 c8 00 00 	mov    %r11,0xc8(%rsp)
  67cd48:	00 
  67cd49:	4c 89 8c 24 d0 00 00 	mov    %r9,0xd0(%rsp)
  67cd50:	00 
  67cd51:	89 84 24 d8 00 00 00 	mov    %eax,0xd8(%rsp)
  67cd58:	89 b4 24 dc 00 00 00 	mov    %esi,0xdc(%rsp)
  67cd5f:	89 bc 24 e0 00 00 00 	mov    %edi,0xe0(%rsp)
  67cd66:	41 8b 40 08          	mov    0x8(%r8),%eax
  67cd6a:	4c 8d bc 24 48 01 00 	lea    0x148(%rsp),%r15
  67cd71:	00 
  67cd72:	48 8d b4 24 b8 00 00 	lea    0xb8(%rsp),%rsi
  67cd79:	00 
  67cd7a:	4c 89 ff             	mov    %r15,%rdi
  67cd7d:	49 89 d4             	mov    %rdx,%r12
  67cd80:	89 c2                	mov    %eax,%edx
  67cd82:	49 89 cd             	mov    %rcx,%r13
  67cd85:	f3 0f 11 44 24 0c    	movss  %xmm0,0xc(%rsp)
  67cd8b:	e8 20 2f ff ff       	call   66fcb0 <<parley::layout::run::Run<()>>::cluster_containing_char>
  67cd90:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  67cd96:	4c 89 e9             	mov    %r13,%rcx
  67cd99:	4c 89 e2             	mov    %r12,%rdx
  67cd9c:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  67cda3:	00 
  67cda4:	48 85 c0             	test   %rax,%rax
  67cda7:	0f 84 6f fd ff ff    	je     67cb1c <parley::editing::geometry::pair_from_entries::<()>+0x7c>
  67cdad:	8b bc 24 70 01 00 00 	mov    0x170(%rsp),%edi
  67cdb4:	48 8b 70 58          	mov    0x58(%rax),%rsi
  67cdb8:	48 39 fe             	cmp    %rdi,%rsi
  67cdbb:	0f 86 2b 01 00 00    	jbe    67ceec <parley::editing::geometry::pair_from_entries::<()>+0x44c>
  67cdc1:	48 8b 48 50          	mov    0x50(%rax),%rcx
  67cdc5:	48 8d 14 ff          	lea    (%rdi,%rdi,8),%rdx
  67cdc9:	48 c1 e2 04          	shl    $0x4,%rdx
  67cdcd:	0f 10 40 68          	movups 0x68(%rax),%xmm0
  67cdd1:	0f 10 88 80 00 00 00 	movups 0x80(%rax),%xmm1
  67cdd8:	0f 10 90 98 00 00 00 	movups 0x98(%rax),%xmm2
  67cddf:	0f 11 84 24 b8 00 00 	movups %xmm0,0xb8(%rsp)
  67cde6:	00 
  67cde7:	0f 11 8c 24 c8 00 00 	movups %xmm1,0xc8(%rsp)
  67cdee:	00 
  67cdef:	0f 11 94 24 d8 00 00 	movups %xmm2,0xd8(%rsp)
  67cdf6:	00 
  67cdf7:	48 8b 44 11 50       	mov    0x50(%rcx,%rdx,1),%rax
  67cdfc:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
  67ce03:	00 
  67ce04:	8b b4 24 c8 01 00 00 	mov    0x1c8(%rsp),%esi
  67ce0b:	8b 94 24 cc 01 00 00 	mov    0x1cc(%rsp),%edx
  67ce12:	48 8d bc 24 b8 00 00 	lea    0xb8(%rsp),%rdi
  67ce19:	00 
  67ce1a:	ff 15 38 de 10 00    	call   *0x10de38(%rip)        # 78ac58 <_DYNAMIC+0x5d0>
  67ce20:	48 85 c0             	test   %rax,%rax
  67ce23:	40 0f 95 c5          	setne  %bpl
  67ce27:	4c 89 e2             	mov    %r12,%rdx
  67ce2a:	4c 89 e9             	mov    %r13,%rcx
  67ce2d:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  67ce33:	48 39 d0             	cmp    %rdx,%rax
  67ce36:	0f 84 f6 fc ff ff    	je     67cb32 <parley::editing::geometry::pair_from_entries::<()>+0x92>
  67ce3c:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
  67ce43:	48 89 d8             	mov    %rbx,%rax
  67ce46:	48 81 c4 d8 01 00 00 	add    $0x1d8,%rsp
  67ce4d:	5b                   	pop    %rbx
  67ce4e:	41 5c                	pop    %r12
  67ce50:	41 5d                	pop    %r13
  67ce52:	41 5e                	pop    %r14
  67ce54:	41 5f                	pop    %r15
  67ce56:	5d                   	pop    %rbp
  67ce57:	c3                   	ret
  67ce58:	4d 8d 04 f8          	lea    (%r8,%rdi,8),%r8
  67ce5c:	49 8b 78 10          	mov    0x10(%r8),%rdi
  67ce60:	49 3b 7e 58          	cmp    0x58(%r14),%rdi
  67ce64:	0f 83 1b fd ff ff    	jae    67cb85 <parley::editing::geometry::pair_from_entries::<()>+0xe5>
  67ce6a:	49 3b be e8 00 00 00 	cmp    0xe8(%r14),%rdi
  67ce71:	0f 83 0e fd ff ff    	jae    67cb85 <parley::editing::geometry::pair_from_entries::<()>+0xe5>
  67ce77:	4c 8d 0c ff          	lea    (%rdi,%rdi,8),%r9
  67ce7b:	49 c1 e1 04          	shl    $0x4,%r9
  67ce7f:	4d 03 4e 50          	add    0x50(%r14),%r9
  67ce83:	4c 8d 14 bf          	lea    (%rdi,%rdi,4),%r10
  67ce87:	49 c1 e2 04          	shl    $0x4,%r10
  67ce8b:	4d 03 96 e0 00 00 00 	add    0xe0(%r14),%r10
  67ce92:	4c 89 74 24 20       	mov    %r14,0x20(%rsp)
  67ce97:	4c 89 4c 24 28       	mov    %r9,0x28(%rsp)
  67ce9c:	4c 89 54 24 30       	mov    %r10,0x30(%rsp)
  67cea1:	4c 89 44 24 38       	mov    %r8,0x38(%rsp)
  67cea6:	89 44 24 40          	mov    %eax,0x40(%rsp)
  67ceaa:	89 74 24 44          	mov    %esi,0x44(%rsp)
  67ceae:	89 7c 24 48          	mov    %edi,0x48(%rsp)
  67ceb2:	8b 41 08             	mov    0x8(%rcx),%eax
  67ceb5:	4c 8d a4 24 b8 00 00 	lea    0xb8(%rsp),%r12
  67cebc:	00 
  67cebd:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
  67cec2:	4c 89 e7             	mov    %r12,%rdi
  67cec5:	49 89 d5             	mov    %rdx,%r13
  67cec8:	89 c2                	mov    %eax,%edx
  67ceca:	e8 e1 2d ff ff       	call   66fcb0 <<parley::layout::run::Run<()>>::cluster_containing_char>
  67cecf:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  67ced5:	4c 89 ea             	mov    %r13,%rdx
  67ced8:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  67cedf:	00 
  67cee0:	48 85 c0             	test   %rax,%rax
  67cee3:	4c 0f 44 e0          	cmove  %rax,%r12
  67cee7:	e9 a8 fc ff ff       	jmp    67cb94 <parley::editing::geometry::pair_from_entries::<()>+0xf4>
  67ceec:	48 8d 15 7d 3c 10 00 	lea    0x103c7d(%rip),%rdx        # 780b70 <anon.dc752cbb3d3389760d876509e45b0baf.29.llvm.10480319710464438355>
  67cef3:	ff 15 ef da 10 00    	call   *0x10daef(%rip)        # 78a9e8 <_DYNAMIC+0x360>
