
/tmp/gpui-monotonic-control-bin/stream-borrowed:     file format elf64-x86-64


Disassembly of section .text:

0000000000670a10 <<parley::layout::run::Clusters<()>>::advance_cursor>:
  670a10:	55                   	push   %rbp
  670a11:	41 57                	push   %r15
  670a13:	41 56                	push   %r14
  670a15:	41 55                	push   %r13
  670a17:	41 54                	push   %r12
  670a19:	53                   	push   %rbx
  670a1a:	48 81 ec 88 00 00 00 	sub    $0x88,%rsp
  670a21:	49 89 f6             	mov    %rsi,%r14
  670a24:	49 89 fd             	mov    %rdi,%r13
  670a27:	80 be 08 01 00 00 00 	cmpb   $0x0,0x108(%rsi)
  670a2e:	0f 84 b4 01 00 00    	je     670be8 <<parley::layout::run::Clusters<()>>::advance_cursor+0x1d8>
  670a34:	45 8b 8e a0 00 00 00 	mov    0xa0(%r14),%r9d
  670a3b:	45 8b 96 a4 00 00 00 	mov    0xa4(%r14),%r10d
  670a42:	31 c0                	xor    %eax,%eax
  670a44:	41 bb 00 00 00 00    	mov    $0x0,%r11d
  670a4a:	45 39 d1             	cmp    %r10d,%r9d
  670a4d:	74 2c                	je     670a7b <<parley::layout::run::Clusters<()>>::advance_cursor+0x6b>
  670a4f:	49 8b b6 88 00 00 00 	mov    0x88(%r14),%rsi
  670a56:	4c 39 ce             	cmp    %r9,%rsi
  670a59:	0f 86 39 05 00 00    	jbe    670f98 <<parley::layout::run::Clusters<()>>::advance_cursor+0x588>
  670a5f:	49 8d 7a ff          	lea    -0x1(%r10),%rdi
  670a63:	48 39 f7             	cmp    %rsi,%rdi
  670a66:	0f 83 3c 05 00 00    	jae    670fa8 <<parley::layout::run::Clusters<()>>::advance_cursor+0x598>
  670a6c:	49 8b 8e 80 00 00 00 	mov    0x80(%r14),%rcx
  670a73:	4b 8d 14 49          	lea    (%r9,%r9,2),%rdx
  670a77:	44 8b 1c d1          	mov    (%rcx,%rdx,8),%r11d
  670a7b:	41 8b 8e a8 00 00 00 	mov    0xa8(%r14),%ecx
  670a82:	44 39 d9             	cmp    %r11d,%ecx
  670a85:	0f 84 bb 04 00 00    	je     670f46 <<parley::layout::run::Clusters<()>>::advance_cursor+0x536>
  670a8b:	45 8b a6 ac 00 00 00 	mov    0xac(%r14),%r12d
  670a92:	49 8b b6 88 00 00 00 	mov    0x88(%r14),%rsi
  670a99:	4c 39 e6             	cmp    %r12,%rsi
  670a9c:	0f 86 13 05 00 00    	jbe    670fb5 <<parley::layout::run::Clusters<()>>::advance_cursor+0x5a5>
  670aa2:	48 89 8c 24 80 00 00 	mov    %rcx,0x80(%rsp)
  670aa9:	00 
  670aaa:	44 8d 79 ff          	lea    -0x1(%rcx),%r15d
  670aae:	49 8b 96 80 00 00 00 	mov    0x80(%r14),%rdx
  670ab5:	4b 8d 04 64          	lea    (%r12,%r12,2),%rax
  670ab9:	44 3b 3c c2          	cmp    (%rdx,%rax,8),%r15d
  670abd:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
  670ac2:	48 89 54 24 28       	mov    %rdx,0x28(%rsp)
  670ac7:	73 7d                	jae    670b46 <<parley::layout::run::Clusters<()>>::advance_cursor+0x136>
  670ac9:	41 ff cc             	dec    %r12d
  670acc:	45 89 a6 ac 00 00 00 	mov    %r12d,0xac(%r14)
  670ad3:	0f 57 c0             	xorps  %xmm0,%xmm0
  670ad6:	45 39 d1             	cmp    %r10d,%r9d
  670ad9:	74 62                	je     670b3d <<parley::layout::run::Clusters<()>>::advance_cursor+0x12d>
  670adb:	4c 89 54 24 18       	mov    %r10,0x18(%rsp)
  670ae0:	4c 39 e6             	cmp    %r12,%rsi
  670ae3:	0f 86 00 02 00 00    	jbe    670ce9 <<parley::layout::run::Clusters<()>>::advance_cursor+0x2d9>
  670ae9:	4c 89 cd             	mov    %r9,%rbp
  670aec:	44 89 db             	mov    %r11d,%ebx
  670aef:	4b 8d 04 64          	lea    (%r12,%r12,2),%rax
  670af3:	48 8d 3c c2          	lea    (%rdx,%rax,8),%rdi
  670af7:	f3 0f 10 44 c2 10    	movss  0x10(%rdx,%rax,8),%xmm0
  670afd:	f3 0f 11 44 24 0c    	movss  %xmm0,0xc(%rsp)
  670b03:	49 8b 76 70          	mov    0x70(%r14),%rsi
  670b07:	49 8b 56 78          	mov    0x78(%r14),%rdx
  670b0b:	ff 15 ff a1 11 00    	call   *0x11a1ff(%rip)        # 78ad10 <_DYNAMIC+0x688>
  670b11:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
  670b16:	89 c0                	mov    %eax,%eax
  670b18:	0f 57 c0             	xorps  %xmm0,%xmm0
  670b1b:	f3 48 0f 2a c0       	cvtsi2ss %rax,%xmm0
  670b20:	f3 0f 10 4c 24 0c    	movss  0xc(%rsp),%xmm1
  670b26:	f3 0f 5e c8          	divss  %xmm0,%xmm1
  670b2a:	0f 28 c1             	movaps %xmm1,%xmm0
  670b2d:	41 89 db             	mov    %ebx,%r11d
  670b30:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  670b35:	49 89 e9             	mov    %rbp,%r9
  670b38:	4c 8b 54 24 18       	mov    0x18(%rsp),%r10
  670b3d:	f3 41 0f 11 86 b0 00 	movss  %xmm0,0xb0(%r14)
  670b44:	00 00 
  670b46:	4c 39 e6             	cmp    %r12,%rsi
  670b49:	0f 86 76 04 00 00    	jbe    670fc5 <<parley::layout::run::Clusters<()>>::advance_cursor+0x5b5>
  670b4f:	4b 8d 04 64          	lea    (%r12,%r12,2),%rax
  670b53:	44 8b 44 c2 04       	mov    0x4(%rdx,%rax,8),%r8d
  670b58:	f3 41 0f 10 a6 b0 00 	movss  0xb0(%r14),%xmm4
  670b5f:	00 00 
  670b61:	45 39 df             	cmp    %r11d,%r15d
  670b64:	0f 86 a5 01 00 00    	jbe    670d0f <<parley::layout::run::Clusters<()>>::advance_cursor+0x2ff>
  670b6a:	44 89 44 24 08       	mov    %r8d,0x8(%rsp)
  670b6f:	4c 89 6c 24 20       	mov    %r13,0x20(%rsp)
  670b74:	49 8b 6e 70          	mov    0x70(%r14),%rbp
  670b78:	4d 8b 6e 78          	mov    0x78(%r14),%r13
  670b7c:	45 39 d1             	cmp    %r10d,%r9d
  670b7f:	0f 85 1b 01 00 00    	jne    670ca0 <<parley::layout::run::Clusters<()>>::advance_cursor+0x290>
  670b85:	0f 57 c0             	xorps  %xmm0,%xmm0
  670b88:	eb 0f                	jmp    670b99 <<parley::layout::run::Clusters<()>>::advance_cursor+0x189>
  670b8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  670b90:	45 39 df             	cmp    %r11d,%r15d
  670b93:	0f 86 a0 01 00 00    	jbe    670d39 <<parley::layout::run::Clusters<()>>::advance_cursor+0x329>
  670b99:	44 89 ff             	mov    %r15d,%edi
  670b9c:	49 39 fd             	cmp    %rdi,%r13
  670b9f:	0f 86 b7 03 00 00    	jbe    670f5c <<parley::layout::run::Clusters<()>>::advance_cursor+0x54c>
  670ba5:	48 8d 04 7f          	lea    (%rdi,%rdi,2),%rax
  670ba9:	80 7c 85 08 00       	cmpb   $0x0,0x8(%rbp,%rax,4)
  670bae:	0f 85 51 01 00 00    	jne    670d05 <<parley::layout::run::Clusters<()>>::advance_cursor+0x2f5>
  670bb4:	44 89 e7             	mov    %r12d,%edi
  670bb7:	48 39 fe             	cmp    %rdi,%rsi
  670bba:	0f 86 ac 03 00 00    	jbe    670f6c <<parley::layout::run::Clusters<()>>::advance_cursor+0x55c>
  670bc0:	41 ff cf             	dec    %r15d
  670bc3:	48 8d 04 7f          	lea    (%rdi,%rdi,2),%rax
  670bc7:	44 3b 3c c2          	cmp    (%rdx,%rax,8),%r15d
  670bcb:	73 c3                	jae    670b90 <<parley::layout::run::Clusters<()>>::advance_cursor+0x180>
  670bcd:	41 ff cc             	dec    %r12d
  670bd0:	45 89 a6 ac 00 00 00 	mov    %r12d,0xac(%r14)
  670bd7:	41 c7 86 b0 00 00 00 	movl   $0x0,0xb0(%r14)
  670bde:	00 00 00 00 
  670be2:	f3 0f 58 e0          	addss  %xmm0,%xmm4
  670be6:	eb a8                	jmp    670b90 <<parley::layout::run::Clusters<()>>::advance_cursor+0x180>
  670be8:	49 8d 76 70          	lea    0x70(%r14),%rsi
  670bec:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
  670bf1:	ff 15 21 a1 11 00    	call   *0x11a121(%rip)        # 78ad18 <_DYNAMIC+0x690>
  670bf7:	80 7c 24 30 00       	cmpb   $0x0,0x30(%rsp)
  670bfc:	0f 84 fc 00 00 00    	je     670cfe <<parley::layout::run::Clusters<()>>::advance_cursor+0x2ee>
  670c02:	44 8b 5c 24 34       	mov    0x34(%rsp),%r11d
  670c07:	44 8b 7c 24 38       	mov    0x38(%rsp),%r15d
  670c0c:	f3 0f 10 64 24 3c    	movss  0x3c(%rsp),%xmm4
  670c12:	0f b7 5c 24 40       	movzwl 0x40(%rsp),%ebx
  670c17:	0f b7 6c 24 42       	movzwl 0x42(%rsp),%ebp
  670c1c:	41 0f b6 86 08 01 00 	movzbl 0x108(%r14),%eax
  670c23:	00 
  670c24:	8d 48 04             	lea    0x4(%rax),%ecx
  670c27:	0f b6 c9             	movzbl %cl,%ecx
  670c2a:	0f a3 cb             	bt     %ecx,%ebx
  670c2d:	0f 82 71 01 00 00    	jb     670da4 <<parley::layout::run::Clusters<()>>::advance_cursor+0x394>
  670c33:	e9 f1 02 00 00       	jmp    670f29 <<parley::layout::run::Clusters<()>>::advance_cursor+0x519>
  670c38:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  670c3f:	00 
  670c40:	44 89 db             	mov    %r11d,%ebx
  670c43:	4b 8d 04 64          	lea    (%r12,%r12,2),%rax
  670c47:	48 8d 3c c2          	lea    (%rdx,%rax,8),%rdi
  670c4b:	f3 0f 10 44 c2 10    	movss  0x10(%rdx,%rax,8),%xmm0
  670c51:	f3 0f 11 44 24 0c    	movss  %xmm0,0xc(%rsp)
  670c57:	48 89 ee             	mov    %rbp,%rsi
  670c5a:	4c 89 ea             	mov    %r13,%rdx
  670c5d:	ff 15 ad a0 11 00    	call   *0x11a0ad(%rip)        # 78ad10 <_DYNAMIC+0x688>
  670c63:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
  670c68:	89 c0                	mov    %eax,%eax
  670c6a:	0f 57 c0             	xorps  %xmm0,%xmm0
  670c6d:	f3 48 0f 2a c0       	cvtsi2ss %rax,%xmm0
  670c72:	f3 0f 10 4c 24 0c    	movss  0xc(%rsp),%xmm1
  670c78:	f3 0f 5e c8          	divss  %xmm0,%xmm1
  670c7c:	f3 41 0f 11 8e b0 00 	movss  %xmm1,0xb0(%r14)
  670c83:	00 00 
  670c85:	f3 0f 10 64 24 18    	movss  0x18(%rsp),%xmm4
  670c8b:	f3 0f 58 e1          	addss  %xmm1,%xmm4
  670c8f:	41 89 db             	mov    %ebx,%r11d
  670c92:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  670c97:	45 39 df             	cmp    %r11d,%r15d
  670c9a:	0f 86 99 00 00 00    	jbe    670d39 <<parley::layout::run::Clusters<()>>::advance_cursor+0x329>
  670ca0:	44 89 ff             	mov    %r15d,%edi
  670ca3:	49 39 fd             	cmp    %rdi,%r13
  670ca6:	0f 86 b0 02 00 00    	jbe    670f5c <<parley::layout::run::Clusters<()>>::advance_cursor+0x54c>
  670cac:	48 8d 04 7f          	lea    (%rdi,%rdi,2),%rax
  670cb0:	80 7c 85 08 00       	cmpb   $0x0,0x8(%rbp,%rax,4)
  670cb5:	75 4e                	jne    670d05 <<parley::layout::run::Clusters<()>>::advance_cursor+0x2f5>
  670cb7:	44 89 e7             	mov    %r12d,%edi
  670cba:	48 39 fe             	cmp    %rdi,%rsi
  670cbd:	0f 86 a9 02 00 00    	jbe    670f6c <<parley::layout::run::Clusters<()>>::advance_cursor+0x55c>
  670cc3:	41 ff cf             	dec    %r15d
  670cc6:	48 8d 04 7f          	lea    (%rdi,%rdi,2),%rax
  670cca:	44 3b 3c c2          	cmp    (%rdx,%rax,8),%r15d
  670cce:	73 c7                	jae    670c97 <<parley::layout::run::Clusters<()>>::advance_cursor+0x287>
  670cd0:	f3 0f 11 64 24 18    	movss  %xmm4,0x18(%rsp)
  670cd6:	41 ff cc             	dec    %r12d
  670cd9:	45 89 a6 ac 00 00 00 	mov    %r12d,0xac(%r14)
  670ce0:	4c 39 e6             	cmp    %r12,%rsi
  670ce3:	0f 87 57 ff ff ff    	ja     670c40 <<parley::layout::run::Clusters<()>>::advance_cursor+0x230>
  670ce9:	48 8d 15 60 f5 10 00 	lea    0x10f560(%rip),%rdx        # 780250 <anon.62868e170f60758b8c346cd4185a0643.3.llvm.4228727425897277816+0x108>
  670cf0:	4c 89 e7             	mov    %r12,%rdi
  670cf3:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  670cf8:	ff 15 ea 9c 11 00    	call   *0x119cea(%rip)        # 78a9e8 <_DYNAMIC+0x360>
  670cfe:	31 c0                	xor    %eax,%eax
  670d00:	e9 41 02 00 00       	jmp    670f46 <<parley::layout::run::Clusters<()>>::advance_cursor+0x536>
  670d05:	4c 8b 6c 24 20       	mov    0x20(%rsp),%r13
  670d0a:	44 8b 44 24 08       	mov    0x8(%rsp),%r8d
  670d0f:	66 b8 10 00          	mov    $0x10,%ax
  670d13:	45 39 df             	cmp    %r11d,%r15d
  670d16:	74 2f                	je     670d47 <<parley::layout::run::Clusters<()>>::advance_cursor+0x337>
  670d18:	44 89 e7             	mov    %r12d,%edi
  670d1b:	48 39 fe             	cmp    %rdi,%rsi
  670d1e:	0f 86 be 02 00 00    	jbe    670fe2 <<parley::layout::run::Clusters<()>>::advance_cursor+0x5d2>
  670d24:	48 8d 0c 7f          	lea    (%rdi,%rdi,2),%rcx
  670d28:	31 c0                	xor    %eax,%eax
  670d2a:	44 3b 3c ca          	cmp    (%rdx,%rcx,8),%r15d
  670d2e:	0f 94 c0             	sete   %al
  670d31:	c1 e0 04             	shl    $0x4,%eax
  670d34:	45 89 fb             	mov    %r15d,%r11d
  670d37:	eb 0e                	jmp    670d47 <<parley::layout::run::Clusters<()>>::advance_cursor+0x337>
  670d39:	66 b8 10 00          	mov    $0x10,%ax
  670d3d:	4c 8b 6c 24 20       	mov    0x20(%rsp),%r13
  670d42:	44 8b 44 24 08       	mov    0x8(%rsp),%r8d
  670d47:	44 89 df             	mov    %r11d,%edi
  670d4a:	49 8b 76 78          	mov    0x78(%r14),%rsi
  670d4e:	48 39 fe             	cmp    %rdi,%rsi
  670d51:	4c 8b bc 24 80 00 00 	mov    0x80(%rsp),%r15
  670d58:	00 
  670d59:	0f 86 76 02 00 00    	jbe    670fd5 <<parley::layout::run::Clusters<()>>::advance_cursor+0x5c5>
  670d5f:	31 c9                	xor    %ecx,%ecx
  670d61:	45 39 c7             	cmp    %r8d,%r15d
  670d64:	0f 94 c1             	sete   %cl
  670d67:	49 8b 56 70          	mov    0x70(%r14),%rdx
  670d6b:	48 8d 34 7f          	lea    (%rdi,%rdi,2),%rsi
  670d6f:	0f b6 7c b2 07       	movzbl 0x7(%rdx,%rsi,4),%edi
  670d74:	0f b6 54 b2 06       	movzbl 0x6(%rdx,%rsi,4),%edx
  670d79:	45 89 9e a8 00 00 00 	mov    %r11d,0xa8(%r14)
  670d80:	c1 ea 04             	shr    $0x4,%edx
  670d83:	83 e2 01             	and    $0x1,%edx
  670d86:	8d 14 7a             	lea    (%rdx,%rdi,2),%edx
  670d89:	c1 e1 05             	shl    $0x5,%ecx
  670d8c:	0f b7 d8             	movzwl %ax,%ebx
  670d8f:	09 cb                	or     %ecx,%ebx
  670d91:	09 d3                	or     %edx,%ebx
  670d93:	b0 01                	mov    $0x1,%al
  670d95:	8d 48 04             	lea    0x4(%rax),%ecx
  670d98:	0f b6 c9             	movzbl %cl,%ecx
  670d9b:	0f a3 cb             	bt     %ecx,%ebx
  670d9e:	0f 83 85 01 00 00    	jae    670f29 <<parley::layout::run::Clusters<()>>::advance_cursor+0x519>
  670da4:	49 8d 76 30          	lea    0x30(%r14),%rsi
  670da8:	84 c0                	test   %al,%al
  670daa:	74 21                	je     670dcd <<parley::layout::run::Clusters<()>>::advance_cursor+0x3bd>
  670dac:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
  670db1:	45 89 dc             	mov    %r11d,%r12d
  670db4:	f3 0f 11 64 24 18    	movss  %xmm4,0x18(%rsp)
  670dba:	e8 21 f8 ff ff       	call   6705e0 <<parley_engine::shape::atom::Atoms>::prev>
  670dbf:	f3 0f 10 64 24 18    	movss  0x18(%rsp),%xmm4
  670dc5:	45 89 e3             	mov    %r12d,%r11d
  670dc8:	e9 e6 00 00 00       	jmp    670eb3 <<parley::layout::run::Clusters<()>>::advance_cursor+0x4a3>
  670dcd:	45 8b 56 64          	mov    0x64(%r14),%r10d
  670dd1:	41 8b 7e 68          	mov    0x68(%r14),%edi
  670dd5:	44 39 d7             	cmp    %r10d,%edi
  670dd8:	75 0e                	jne    670de8 <<parley::layout::run::Clusters<()>>::advance_cursor+0x3d8>
  670dda:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
  670de1:	00 00 
  670de3:	e9 cb 00 00 00       	jmp    670eb3 <<parley::layout::run::Clusters<()>>::advance_cursor+0x4a3>
  670de8:	49 8b 46 48          	mov    0x48(%r14),%rax
  670dec:	48 39 f8             	cmp    %rdi,%rax
  670def:	0f 86 fa 01 00 00    	jbe    670fef <<parley::layout::run::Clusters<()>>::advance_cursor+0x5df>
  670df5:	49 8b 56 40          	mov    0x40(%r14),%rdx
  670df9:	4c 8d 0c 7f          	lea    (%rdi,%rdi,2),%r9
  670dfd:	f3 42 0f 10 44 ca 10 	movss  0x10(%rdx,%r9,8),%xmm0
  670e04:	44 8d 47 01          	lea    0x1(%rdi),%r8d
  670e08:	45 39 d0             	cmp    %r10d,%r8d
  670e0b:	73 4b                	jae    670e58 <<parley::layout::run::Clusters<()>>::advance_cursor+0x448>
  670e0d:	45 89 dc             	mov    %r11d,%r12d
  670e10:	44 89 c1             	mov    %r8d,%ecx
  670e13:	4c 8d 04 49          	lea    (%rcx,%rcx,2),%r8
  670e17:	4e 8d 1c c2          	lea    (%rdx,%r8,8),%r11
  670e1b:	49 83 c3 16          	add    $0x16,%r11
  670e1f:	49 89 c8             	mov    %rcx,%r8
  670e22:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  670e29:	1f 84 00 00 00 00 00 
  670e30:	4c 39 c0             	cmp    %r8,%rax
  670e33:	0f 86 45 01 00 00    	jbe    670f7e <<parley::layout::run::Clusters<()>>::advance_cursor+0x56e>
  670e39:	41 f6 43 01 02       	testb  $0x2,0x1(%r11)
  670e3e:	75 15                	jne    670e55 <<parley::layout::run::Clusters<()>>::advance_cursor+0x445>
  670e40:	f3 41 0f 58 43 fa    	addss  -0x6(%r11),%xmm0
  670e46:	49 ff c0             	inc    %r8
  670e49:	49 83 c3 18          	add    $0x18,%r11
  670e4d:	4d 39 c2             	cmp    %r8,%r10
  670e50:	75 de                	jne    670e30 <<parley::layout::run::Clusters<()>>::advance_cursor+0x420>
  670e52:	45 89 d0             	mov    %r10d,%r8d
  670e55:	45 89 e3             	mov    %r12d,%r11d
  670e58:	45 89 46 68          	mov    %r8d,0x68(%r14)
  670e5c:	44 89 c1             	mov    %r8d,%ecx
  670e5f:	48 ff c9             	dec    %rcx
  670e62:	48 39 c1             	cmp    %rax,%rcx
  670e65:	0f 83 94 01 00 00    	jae    670fff <<parley::layout::run::Clusters<()>>::advance_cursor+0x5ef>
  670e6b:	4a 8d 04 ca          	lea    (%rdx,%r9,8),%rax
  670e6f:	8b 00                	mov    (%rax),%eax
  670e71:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  670e75:	8b 4c ca 04          	mov    0x4(%rdx,%rcx,8),%ecx
  670e79:	48 8b 56 30          	mov    0x30(%rsi),%rdx
  670e7d:	48 89 54 24 60       	mov    %rdx,0x60(%rsp)
  670e82:	0f 10 0e             	movups (%rsi),%xmm1
  670e85:	0f 10 56 10          	movups 0x10(%rsi),%xmm2
  670e89:	0f 10 5e 20          	movups 0x20(%rsi),%xmm3
  670e8d:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
  670e92:	0f 29 54 24 40       	movaps %xmm2,0x40(%rsp)
  670e97:	0f 29 4c 24 30       	movaps %xmm1,0x30(%rsp)
  670e9c:	89 7c 24 68          	mov    %edi,0x68(%rsp)
  670ea0:	44 89 44 24 6c       	mov    %r8d,0x6c(%rsp)
  670ea5:	89 44 24 70          	mov    %eax,0x70(%rsp)
  670ea9:	89 4c 24 74          	mov    %ecx,0x74(%rsp)
  670ead:	f3 0f 11 44 24 78    	movss  %xmm0,0x78(%rsp)
  670eb3:	8b 44 24 70          	mov    0x70(%rsp),%eax
  670eb7:	41 89 86 f8 00 00 00 	mov    %eax,0xf8(%r14)
  670ebe:	8b 44 24 74          	mov    0x74(%rsp),%eax
  670ec2:	41 89 86 fc 00 00 00 	mov    %eax,0xfc(%r14)
  670ec9:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
  670ece:	49 89 86 00 01 00 00 	mov    %rax,0x100(%r14)
  670ed5:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  670eda:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
  670edf:	0f 28 44 24 40       	movaps 0x40(%rsp),%xmm0
  670ee4:	0f 28 4c 24 50       	movaps 0x50(%rsp),%xmm1
  670ee9:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  670eee:	49 89 96 e8 00 00 00 	mov    %rdx,0xe8(%r14)
  670ef5:	8b 54 24 68          	mov    0x68(%rsp),%edx
  670ef9:	41 89 96 f0 00 00 00 	mov    %edx,0xf0(%r14)
  670f00:	8b 54 24 6c          	mov    0x6c(%rsp),%edx
  670f04:	41 89 96 f4 00 00 00 	mov    %edx,0xf4(%r14)
  670f0b:	41 0f 11 8e d8 00 00 	movups %xmm1,0xd8(%r14)
  670f12:	00 
  670f13:	41 0f 11 86 c8 00 00 	movups %xmm0,0xc8(%r14)
  670f1a:	00 
  670f1b:	49 89 86 b8 00 00 00 	mov    %rax,0xb8(%r14)
  670f22:	49 89 8e c0 00 00 00 	mov    %rcx,0xc0(%r14)
  670f29:	45 89 5d 04          	mov    %r11d,0x4(%r13)
  670f2d:	45 89 7d 08          	mov    %r15d,0x8(%r13)
  670f31:	f3 41 0f 11 65 0c    	movss  %xmm4,0xc(%r13)
  670f37:	66 41 89 5d 10       	mov    %bx,0x10(%r13)
  670f3c:	66 41 89 6d 12       	mov    %bp,0x12(%r13)
  670f41:	b8 01 00 00 00       	mov    $0x1,%eax
  670f46:	41 89 45 00          	mov    %eax,0x0(%r13)
  670f4a:	48 81 c4 88 00 00 00 	add    $0x88,%rsp
  670f51:	5b                   	pop    %rbx
  670f52:	41 5c                	pop    %r12
  670f54:	41 5d                	pop    %r13
  670f56:	41 5e                	pop    %r14
  670f58:	41 5f                	pop    %r15
  670f5a:	5d                   	pop    %rbp
  670f5b:	c3                   	ret
  670f5c:	48 8d 15 25 f4 10 00 	lea    0x10f425(%rip),%rdx        # 780388 <anon.62868e170f60758b8c346cd4185a0643.25.llvm.4228727425897277816+0xf0>
  670f63:	4c 89 ee             	mov    %r13,%rsi
  670f66:	ff 15 7c 9a 11 00    	call   *0x119a7c(%rip)        # 78a9e8 <_DYNAMIC+0x360>
  670f6c:	48 8d 15 2d f4 10 00 	lea    0x10f42d(%rip),%rdx        # 7803a0 <anon.62868e170f60758b8c346cd4185a0643.25.llvm.4228727425897277816+0x108>
  670f73:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  670f78:	ff 15 6a 9a 11 00    	call   *0x119a6a(%rip)        # 78a9e8 <_DYNAMIC+0x360>
  670f7e:	48 39 c8             	cmp    %rcx,%rax
  670f81:	48 0f 47 c8          	cmova  %rax,%rcx
  670f85:	48 8d 15 8c f4 10 00 	lea    0x10f48c(%rip),%rdx        # 780418 <anon.62868e170f60758b8c346cd4185a0643.45.llvm.4228727425897277816+0x30>
  670f8c:	48 89 cf             	mov    %rcx,%rdi
  670f8f:	48 89 c6             	mov    %rax,%rsi
  670f92:	ff 15 50 9a 11 00    	call   *0x119a50(%rip)        # 78a9e8 <_DYNAMIC+0x360>
  670f98:	48 8d 15 d9 f1 10 00 	lea    0x10f1d9(%rip),%rdx        # 780178 <anon.62868e170f60758b8c346cd4185a0643.3.llvm.4228727425897277816+0x30>
  670f9f:	4c 89 cf             	mov    %r9,%rdi
  670fa2:	ff 15 40 9a 11 00    	call   *0x119a40(%rip)        # 78a9e8 <_DYNAMIC+0x360>
  670fa8:	48 8d 15 e1 f1 10 00 	lea    0x10f1e1(%rip),%rdx        # 780190 <anon.62868e170f60758b8c346cd4185a0643.3.llvm.4228727425897277816+0x48>
  670faf:	ff 15 33 9a 11 00    	call   *0x119a33(%rip)        # 78a9e8 <_DYNAMIC+0x360>
  670fb5:	48 8d 15 9c f3 10 00 	lea    0x10f39c(%rip),%rdx        # 780358 <anon.62868e170f60758b8c346cd4185a0643.25.llvm.4228727425897277816+0xc0>
  670fbc:	4c 89 e7             	mov    %r12,%rdi
  670fbf:	ff 15 23 9a 11 00    	call   *0x119a23(%rip)        # 78a9e8 <_DYNAMIC+0x360>
  670fc5:	48 8d 15 a4 f3 10 00 	lea    0x10f3a4(%rip),%rdx        # 780370 <anon.62868e170f60758b8c346cd4185a0643.25.llvm.4228727425897277816+0xd8>
  670fcc:	4c 89 e7             	mov    %r12,%rdi
  670fcf:	ff 15 13 9a 11 00    	call   *0x119a13(%rip)        # 78a9e8 <_DYNAMIC+0x360>
  670fd5:	48 8d 15 f4 f3 10 00 	lea    0x10f3f4(%rip),%rdx        # 7803d0 <anon.62868e170f60758b8c346cd4185a0643.25.llvm.4228727425897277816+0x138>
  670fdc:	ff 15 06 9a 11 00    	call   *0x119a06(%rip)        # 78a9e8 <_DYNAMIC+0x360>
  670fe2:	48 8d 15 cf f3 10 00 	lea    0x10f3cf(%rip),%rdx        # 7803b8 <anon.62868e170f60758b8c346cd4185a0643.25.llvm.4228727425897277816+0x120>
  670fe9:	ff 15 f9 99 11 00    	call   *0x1199f9(%rip)        # 78a9e8 <_DYNAMIC+0x360>
  670fef:	48 8d 15 0a f4 10 00 	lea    0x10f40a(%rip),%rdx        # 780400 <anon.62868e170f60758b8c346cd4185a0643.45.llvm.4228727425897277816+0x18>
  670ff6:	48 89 c6             	mov    %rax,%rsi
  670ff9:	ff 15 e9 99 11 00    	call   *0x1199e9(%rip)        # 78a9e8 <_DYNAMIC+0x360>
  670fff:	48 8d 15 2a f4 10 00 	lea    0x10f42a(%rip),%rdx        # 780430 <anon.62868e170f60758b8c346cd4185a0643.45.llvm.4228727425897277816+0x48>
  671006:	48 89 cf             	mov    %rcx,%rdi
  671009:	48 89 c6             	mov    %rax,%rsi
  67100c:	ff 15 d6 99 11 00    	call   *0x1199d6(%rip)        # 78a9e8 <_DYNAMIC+0x360>
