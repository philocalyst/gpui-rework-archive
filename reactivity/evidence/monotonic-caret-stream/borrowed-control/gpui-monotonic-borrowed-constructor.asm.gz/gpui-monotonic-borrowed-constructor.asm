
/tmp/gpui-monotonic-control-bin/stream-borrowed:     file format elf64-x86-64


Disassembly of section .text:

0000000000670720 <<parley::layout::run::Clusters<()>>::new>:
  670720:	55                   	push   %rbp
  670721:	41 57                	push   %r15
  670723:	41 56                	push   %r14
  670725:	41 55                	push   %r13
  670727:	41 54                	push   %r12
  670729:	53                   	push   %rbx
  67072a:	48 83 ec 38          	sub    $0x38,%rsp
  67072e:	49 89 f4             	mov    %rsi,%r12
  670731:	49 89 fe             	mov    %rdi,%r14
  670734:	48 8b 06             	mov    (%rsi),%rax
  670737:	8b 7e 28             	mov    0x28(%rsi),%edi
  67073a:	48 8b 70 58          	mov    0x58(%rax),%rsi
  67073e:	48 39 fe             	cmp    %rdi,%rsi
  670741:	0f 86 73 02 00 00    	jbe    6709ba <<parley::layout::run::Clusters<()>>::new+0x29a>
  670747:	49 8b 4c 24 18       	mov    0x18(%r12),%rcx
  67074c:	48 85 c9             	test   %rcx,%rcx
  67074f:	74 0a                	je     67075b <<parley::layout::run::Clusters<()>>::new+0x3b>
  670751:	48 8d 79 18          	lea    0x18(%rcx),%rdi
  670755:	48 83 c1 1c          	add    $0x1c,%rcx
  670759:	eb 1c                	jmp    670777 <<parley::layout::run::Clusters<()>>::new+0x57>
  67075b:	4c 8b 40 50          	mov    0x50(%rax),%r8
  67075f:	48 8d 34 ff          	lea    (%rdi,%rdi,8),%rsi
  670763:	48 c1 e6 04          	shl    $0x4,%rsi
  670767:	49 8d 0c 30          	lea    (%r8,%rsi,1),%rcx
  67076b:	48 83 c1 54          	add    $0x54,%rcx
  67076f:	49 8d 3c 30          	lea    (%r8,%rsi,1),%rdi
  670773:	48 83 c7 50          	add    $0x50,%rdi
  670777:	4c 8b 40 68          	mov    0x68(%rax),%r8
  67077b:	4c 8b 48 70          	mov    0x70(%rax),%r9
  67077f:	4c 8b b8 80 00 00 00 	mov    0x80(%rax),%r15
  670786:	48 8b b0 88 00 00 00 	mov    0x88(%rax),%rsi
  67078d:	4c 8b 90 98 00 00 00 	mov    0x98(%rax),%r10
  670794:	4c 8b 98 a0 00 00 00 	mov    0xa0(%rax),%r11
  67079b:	8b 29                	mov    (%rcx),%ebp
  67079d:	8b 1f                	mov    (%rdi),%ebx
  67079f:	84 d2                	test   %dl,%dl
  6707a1:	74 19                	je     6707bc <<parley::layout::run::Clusters<()>>::new+0x9c>
  6707a3:	39 eb                	cmp    %ebp,%ebx
  6707a5:	75 2c                	jne    6707d3 <<parley::layout::run::Clusters<()>>::new+0xb3>
  6707a7:	44 8d 6d 01          	lea    0x1(%rbp),%r13d
  6707ab:	41 39 ed             	cmp    %ebp,%r13d
  6707ae:	44 0f 46 ed          	cmovbe %ebp,%r13d
  6707b2:	41 ff cd             	dec    %r13d
  6707b5:	0f 57 db             	xorps  %xmm3,%xmm3
  6707b8:	31 c9                	xor    %ecx,%ecx
  6707ba:	eb 10                	jmp    6707cc <<parley::layout::run::Clusters<()>>::new+0xac>
  6707bc:	39 eb                	cmp    %ebp,%ebx
  6707be:	0f 85 b4 00 00 00    	jne    670878 <<parley::layout::run::Clusters<()>>::new+0x158>
  6707c4:	0f 57 db             	xorps  %xmm3,%xmm3
  6707c7:	31 c9                	xor    %ecx,%ecx
  6707c9:	41 89 ed             	mov    %ebp,%r13d
  6707cc:	89 e8                	mov    %ebp,%eax
  6707ce:	e9 37 01 00 00       	jmp    67090a <<parley::layout::run::Clusters<()>>::new+0x1ea>
  6707d3:	48 39 de             	cmp    %rbx,%rsi
  6707d6:	0f 86 eb 01 00 00    	jbe    6709c7 <<parley::layout::run::Clusters<()>>::new+0x2a7>
  6707dc:	48 8d 7d ff          	lea    -0x1(%rbp),%rdi
  6707e0:	48 39 f7             	cmp    %rsi,%rdi
  6707e3:	0f 83 ee 01 00 00    	jae    6709d7 <<parley::layout::run::Clusters<()>>::new+0x2b7>
  6707e9:	4c 89 5c 24 20       	mov    %r11,0x20(%rsp)
  6707ee:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
  6707f3:	89 54 24 0c          	mov    %edx,0xc(%rsp)
  6707f7:	44 8d 6b 01          	lea    0x1(%rbx),%r13d
  6707fb:	41 39 ed             	cmp    %ebp,%r13d
  6707fe:	44 0f 46 ed          	cmovbe %ebp,%r13d
  670802:	41 ff cd             	dec    %r13d
  670805:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
  67080a:	4c 39 ee             	cmp    %r13,%rsi
  67080d:	0f 86 e3 01 00 00    	jbe    6709f6 <<parley::layout::run::Clusters<()>>::new+0x2d6>
  670813:	48 8d 04 7f          	lea    (%rdi,%rdi,2),%rax
  670817:	41 8b 44 c7 04       	mov    0x4(%r15,%rax,8),%eax
  67081c:	89 44 24 08          	mov    %eax,0x8(%rsp)
  670820:	4a 8d 04 6d 00 00 00 	lea    0x0(,%r13,2),%rax
  670827:	00 
  670828:	4c 01 e8             	add    %r13,%rax
  67082b:	49 8d 3c c7          	lea    (%r15,%rax,8),%rdi
  67082f:	f3 41 0f 10 44 c7 10 	movss  0x10(%r15,%rax,8),%xmm0
  670836:	f3 0f 11 44 24 04    	movss  %xmm0,0x4(%rsp)
  67083c:	4c 89 c6             	mov    %r8,%rsi
  67083f:	4c 89 ca             	mov    %r9,%rdx
  670842:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
  670847:	4c 89 4c 24 30       	mov    %r9,0x30(%rsp)
  67084c:	ff 15 be a4 11 00    	call   *0x11a4be(%rip)        # 78ad10 <_DYNAMIC+0x688>
  670852:	f3 0f 10 5c 24 04    	movss  0x4(%rsp),%xmm3
  670858:	8b 4c 24 08          	mov    0x8(%rsp),%ecx
  67085c:	4c 8b 4c 24 30       	mov    0x30(%rsp),%r9
  670861:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
  670866:	89 c0                	mov    %eax,%eax
  670868:	0f 57 c0             	xorps  %xmm0,%xmm0
  67086b:	f3 48 0f 2a c0       	cvtsi2ss %rax,%xmm0
  670870:	f3 0f 5e d8          	divss  %xmm0,%xmm3
  670874:	89 e8                	mov    %ebp,%eax
  670876:	eb 7f                	jmp    6708f7 <<parley::layout::run::Clusters<()>>::new+0x1d7>
  670878:	48 39 de             	cmp    %rbx,%rsi
  67087b:	0f 86 46 01 00 00    	jbe    6709c7 <<parley::layout::run::Clusters<()>>::new+0x2a7>
  670881:	4c 89 5c 24 20       	mov    %r11,0x20(%rsp)
  670886:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
  67088b:	89 54 24 0c          	mov    %edx,0xc(%rsp)
  67088f:	48 8d 7d ff          	lea    -0x1(%rbp),%rdi
  670893:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
  670898:	48 39 f7             	cmp    %rsi,%rdi
  67089b:	0f 83 43 01 00 00    	jae    6709e4 <<parley::layout::run::Clusters<()>>::new+0x2c4>
  6708a1:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
  6708a5:	49 8d 3c c7          	lea    (%r15,%rax,8),%rdi
  6708a9:	41 8b 0c c7          	mov    (%r15,%rax,8),%ecx
  6708ad:	89 4c 24 08          	mov    %ecx,0x8(%rsp)
  6708b1:	f3 41 0f 10 44 c7 10 	movss  0x10(%r15,%rax,8),%xmm0
  6708b8:	f3 0f 11 44 24 04    	movss  %xmm0,0x4(%rsp)
  6708be:	4c 89 c6             	mov    %r8,%rsi
  6708c1:	4c 89 ca             	mov    %r9,%rdx
  6708c4:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
  6708c9:	4d 89 cd             	mov    %r9,%r13
  6708cc:	ff 15 3e a4 11 00    	call   *0x11a43e(%rip)        # 78ad10 <_DYNAMIC+0x688>
  6708d2:	f3 0f 10 5c 24 04    	movss  0x4(%rsp),%xmm3
  6708d8:	8b 4c 24 08          	mov    0x8(%rsp),%ecx
  6708dc:	4d 89 e9             	mov    %r13,%r9
  6708df:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
  6708e4:	89 c0                	mov    %eax,%eax
  6708e6:	0f 57 c0             	xorps  %xmm0,%xmm0
  6708e9:	f3 48 0f 2a c0       	cvtsi2ss %rax,%xmm0
  6708ee:	f3 0f 5e d8          	divss  %xmm0,%xmm3
  6708f2:	41 89 dd             	mov    %ebx,%r13d
  6708f5:	89 d8                	mov    %ebx,%eax
  6708f7:	8b 54 24 0c          	mov    0xc(%rsp),%edx
  6708fb:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  670900:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
  670905:	4c 8b 5c 24 20       	mov    0x20(%rsp),%r11
  67090a:	41 0f 10 04 24       	movups (%r12),%xmm0
  67090f:	41 0f 10 4c 24 10    	movups 0x10(%r12),%xmm1
  670915:	41 0f 10 54 24 20    	movups 0x20(%r12),%xmm2
  67091b:	41 0f 11 56 20       	movups %xmm2,0x20(%r14)
  670920:	41 0f 11 4e 10       	movups %xmm1,0x10(%r14)
  670925:	41 0f 11 06          	movups %xmm0,(%r14)
  670929:	4d 89 46 30          	mov    %r8,0x30(%r14)
  67092d:	4d 89 4e 38          	mov    %r9,0x38(%r14)
  670931:	4d 89 7e 40          	mov    %r15,0x40(%r14)
  670935:	49 89 76 48          	mov    %rsi,0x48(%r14)
  670939:	4d 89 56 50          	mov    %r10,0x50(%r14)
  67093d:	4d 89 5e 58          	mov    %r11,0x58(%r14)
  670941:	41 89 5e 60          	mov    %ebx,0x60(%r14)
  670945:	41 89 6e 64          	mov    %ebp,0x64(%r14)
  670949:	41 89 46 68          	mov    %eax,0x68(%r14)
  67094d:	4d 89 46 70          	mov    %r8,0x70(%r14)
  670951:	4d 89 4e 78          	mov    %r9,0x78(%r14)
  670955:	4d 89 be 80 00 00 00 	mov    %r15,0x80(%r14)
  67095c:	49 89 b6 88 00 00 00 	mov    %rsi,0x88(%r14)
  670963:	4d 89 96 90 00 00 00 	mov    %r10,0x90(%r14)
  67096a:	4d 89 9e 98 00 00 00 	mov    %r11,0x98(%r14)
  670971:	41 89 9e a0 00 00 00 	mov    %ebx,0xa0(%r14)
  670978:	41 89 ae a4 00 00 00 	mov    %ebp,0xa4(%r14)
  67097f:	41 89 8e a8 00 00 00 	mov    %ecx,0xa8(%r14)
  670986:	45 89 ae ac 00 00 00 	mov    %r13d,0xac(%r14)
  67098d:	f3 41 0f 11 9e b0 00 	movss  %xmm3,0xb0(%r14)
  670994:	00 00 
  670996:	49 c7 86 b8 00 00 00 	movq   $0x0,0xb8(%r14)
  67099d:	00 00 00 00 
  6709a1:	41 88 96 08 01 00 00 	mov    %dl,0x108(%r14)
  6709a8:	4c 89 f0             	mov    %r14,%rax
  6709ab:	48 83 c4 38          	add    $0x38,%rsp
  6709af:	5b                   	pop    %rbx
  6709b0:	41 5c                	pop    %r12
  6709b2:	41 5d                	pop    %r13
  6709b4:	41 5e                	pop    %r14
  6709b6:	41 5f                	pop    %r15
  6709b8:	5d                   	pop    %rbp
  6709b9:	c3                   	ret
  6709ba:	48 8d 15 27 fa 10 00 	lea    0x10fa27(%rip),%rdx        # 7803e8 <anon.62868e170f60758b8c346cd4185a0643.45.llvm.4228727425897277816>
  6709c1:	ff 15 21 a0 11 00    	call   *0x11a021(%rip)        # 78a9e8 <_DYNAMIC+0x360>
  6709c7:	48 8d 15 aa f7 10 00 	lea    0x10f7aa(%rip),%rdx        # 780178 <anon.62868e170f60758b8c346cd4185a0643.3.llvm.4228727425897277816+0x30>
  6709ce:	48 89 df             	mov    %rbx,%rdi
  6709d1:	ff 15 11 a0 11 00    	call   *0x11a011(%rip)        # 78a9e8 <_DYNAMIC+0x360>
  6709d7:	48 8d 15 b2 f7 10 00 	lea    0x10f7b2(%rip),%rdx        # 780190 <anon.62868e170f60758b8c346cd4185a0643.3.llvm.4228727425897277816+0x48>
  6709de:	ff 15 04 a0 11 00    	call   *0x11a004(%rip)        # 78a9e8 <_DYNAMIC+0x360>
  6709e4:	48 8d 15 a5 f7 10 00 	lea    0x10f7a5(%rip),%rdx        # 780190 <anon.62868e170f60758b8c346cd4185a0643.3.llvm.4228727425897277816+0x48>
  6709eb:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  6709f0:	ff 15 f2 9f 11 00    	call   *0x119ff2(%rip)        # 78a9e8 <_DYNAMIC+0x360>
  6709f6:	48 8d 15 53 f8 10 00 	lea    0x10f853(%rip),%rdx        # 780250 <anon.62868e170f60758b8c346cd4185a0643.3.llvm.4228727425897277816+0x108>
  6709fd:	4c 89 ef             	mov    %r13,%rdi
  670a00:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  670a05:	ff 15 dd 9f 11 00    	call   *0x119fdd(%rip)        # 78a9e8 <_DYNAMIC+0x360>
