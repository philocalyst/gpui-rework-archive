
/tmp/gpui-monotonic-control-bin/stream-borrowed:     file format elf64-x86-64


Disassembly of section .text:

000000000066ab60 <<gpui_canvas::text::planner::Planner>::shape>:
  66ab60:	55                   	push   %rbp
  66ab61:	41 57                	push   %r15
  66ab63:	41 56                	push   %r14
  66ab65:	41 55                	push   %r13
  66ab67:	41 54                	push   %r12
  66ab69:	53                   	push   %rbx
  66ab6a:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
  66ab71:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
  66ab78:	00 
  66ab79:	48 81 ec b8 01 00 00 	sub    $0x1b8,%rsp
  66ab80:	44 89 8c 24 3c 02 00 	mov    %r9d,0x23c(%rsp)
  66ab87:	00 
  66ab88:	f3 0f 11 8c 24 dc 01 	movss  %xmm1,0x1dc(%rsp)
  66ab8f:	00 00 
  66ab91:	44 89 84 24 d8 01 00 	mov    %r8d,0x1d8(%rsp)
  66ab98:	00 
  66ab99:	f3 0f 11 44 24 6c    	movss  %xmm0,0x6c(%rsp)
  66ab9f:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
  66aba4:	49 89 f5             	mov    %rsi,%r13
  66aba7:	48 89 bc 24 28 03 00 	mov    %rdi,0x328(%rsp)
  66abae:	00 
  66abaf:	4c 8d 24 0a          	lea    (%rdx,%rcx,1),%r12
  66abb3:	48 85 c9             	test   %rcx,%rcx
  66abb6:	48 89 34 24          	mov    %rsi,(%rsp)
  66abba:	48 89 94 24 60 01 00 	mov    %rdx,0x160(%rsp)
  66abc1:	00 
  66abc2:	4c 89 a4 24 c0 01 00 	mov    %r12,0x1c0(%rsp)
  66abc9:	00 
  66abca:	0f 84 9f 03 00 00    	je     66af6f <<gpui_canvas::text::planner::Planner>::shape+0x40f>
  66abd0:	49 8d 85 78 0a 00 00 	lea    0xa78(%r13),%rax
  66abd7:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  66abdc:	48 8d b4 24 bc 0c 00 	lea    0xcbc(%rsp),%rsi
  66abe3:	00 
  66abe4:	49 8d 45 38          	lea    0x38(%r13),%rax
  66abe8:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  66abed:	49 8d 45 3c          	lea    0x3c(%r13),%rax
  66abf1:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  66abf8:	00 
  66abf9:	49 8d 45 58          	lea    0x58(%r13),%rax
  66abfd:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  66ac02:	49 8d 45 5c          	lea    0x5c(%r13),%rax
  66ac06:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
  66ac0d:	00 
  66ac0e:	45 31 ff             	xor    %r15d,%r15d
  66ac11:	48 8d bc 24 e0 06 00 	lea    0x6e0(%rsp),%rdi
  66ac18:	00 
  66ac19:	4c 8b 05 90 fe 11 00 	mov    0x11fe90(%rip),%r8        # 78aab0 <_DYNAMIC+0x428>
  66ac20:	49 89 d6             	mov    %rdx,%r14
  66ac23:	44 89 7c 24 20       	mov    %r15d,0x20(%rsp)
  66ac28:	eb 1f                	jmp    66ac49 <<gpui_canvas::text::planner::Planner>::shape+0xe9>
  66ac2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  66ac30:	41 8d 87 d8 df ff ff 	lea    -0x2028(%r15),%eax
  66ac37:	83 f8 02             	cmp    $0x2,%eax
  66ac3a:	0f 83 e1 00 00 00    	jae    66ad21 <<gpui_canvas::text::planner::Planner>::shape+0x1c1>
  66ac40:	4d 39 e6             	cmp    %r12,%r14
  66ac43:	0f 84 c6 02 00 00    	je     66af0f <<gpui_canvas::text::planner::Planner>::shape+0x3af>
  66ac49:	45 0f b6 3e          	movzbl (%r14),%r15d
  66ac4d:	45 84 ff             	test   %r15b,%r15b
  66ac50:	78 1e                	js     66ac70 <<gpui_canvas::text::planner::Planner>::shape+0x110>
  66ac52:	49 ff c6             	inc    %r14
  66ac55:	41 81 ff 27 20 00 00 	cmp    $0x2027,%r15d
  66ac5c:	0f 8e 9e 00 00 00    	jle    66ad00 <<gpui_canvas::text::planner::Planner>::shape+0x1a0>
  66ac62:	eb cc                	jmp    66ac30 <<gpui_canvas::text::planner::Planner>::shape+0xd0>
  66ac64:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  66ac6b:	00 00 00 00 00 
  66ac70:	44 89 f8             	mov    %r15d,%eax
  66ac73:	83 e0 1f             	and    $0x1f,%eax
  66ac76:	41 0f b6 56 01       	movzbl 0x1(%r14),%edx
  66ac7b:	83 e2 3f             	and    $0x3f,%edx
  66ac7e:	41 80 ff df          	cmp    $0xdf,%r15b
  66ac82:	76 3d                	jbe    66acc1 <<gpui_canvas::text::planner::Planner>::shape+0x161>
  66ac84:	41 0f b6 4e 02       	movzbl 0x2(%r14),%ecx
  66ac89:	c1 e2 06             	shl    $0x6,%edx
  66ac8c:	83 e1 3f             	and    $0x3f,%ecx
  66ac8f:	09 d1                	or     %edx,%ecx
  66ac91:	41 80 ff f0          	cmp    $0xf0,%r15b
  66ac95:	72 44                	jb     66acdb <<gpui_canvas::text::planner::Planner>::shape+0x17b>
  66ac97:	45 0f b6 7e 03       	movzbl 0x3(%r14),%r15d
  66ac9c:	49 83 c6 04          	add    $0x4,%r14
  66aca0:	83 e0 07             	and    $0x7,%eax
  66aca3:	c1 e0 12             	shl    $0x12,%eax
  66aca6:	c1 e1 06             	shl    $0x6,%ecx
  66aca9:	41 83 e7 3f          	and    $0x3f,%r15d
  66acad:	41 09 cf             	or     %ecx,%r15d
  66acb0:	41 09 c7             	or     %eax,%r15d
  66acb3:	41 81 ff 27 20 00 00 	cmp    $0x2027,%r15d
  66acba:	7e 44                	jle    66ad00 <<gpui_canvas::text::planner::Planner>::shape+0x1a0>
  66acbc:	e9 6f ff ff ff       	jmp    66ac30 <<gpui_canvas::text::planner::Planner>::shape+0xd0>
  66acc1:	49 83 c6 02          	add    $0x2,%r14
  66acc5:	c1 e0 06             	shl    $0x6,%eax
  66acc8:	09 d0                	or     %edx,%eax
  66acca:	41 89 c7             	mov    %eax,%r15d
  66accd:	41 81 ff 27 20 00 00 	cmp    $0x2027,%r15d
  66acd4:	7e 2a                	jle    66ad00 <<gpui_canvas::text::planner::Planner>::shape+0x1a0>
  66acd6:	e9 55 ff ff ff       	jmp    66ac30 <<gpui_canvas::text::planner::Planner>::shape+0xd0>
  66acdb:	49 83 c6 03          	add    $0x3,%r14
  66acdf:	c1 e0 0c             	shl    $0xc,%eax
  66ace2:	09 c1                	or     %eax,%ecx
  66ace4:	41 89 cf             	mov    %ecx,%r15d
  66ace7:	41 81 ff 27 20 00 00 	cmp    $0x2027,%r15d
  66acee:	0f 8f 3c ff ff ff    	jg     66ac30 <<gpui_canvas::text::planner::Planner>::shape+0xd0>
  66acf4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  66acfb:	00 00 00 00 00 
  66ad00:	41 83 ff 0a          	cmp    $0xa,%r15d
  66ad04:	0f 84 36 ff ff ff    	je     66ac40 <<gpui_canvas::text::planner::Planner>::shape+0xe0>
  66ad0a:	41 83 ff 0d          	cmp    $0xd,%r15d
  66ad0e:	0f 84 2c ff ff ff    	je     66ac40 <<gpui_canvas::text::planner::Planner>::shape+0xe0>
  66ad14:	41 81 ff 85 00 00 00 	cmp    $0x85,%r15d
  66ad1b:	0f 84 1f ff ff ff    	je     66ac40 <<gpui_canvas::text::planner::Planner>::shape+0xe0>
  66ad21:	49 89 fd             	mov    %rdi,%r13
  66ad24:	48 8d 3d ad 51 11 00 	lea    0x1151ad(%rip),%rdi        # 77fed8 <anon.fcf2ae708c8bfcebac3bd597053acdb9.9.llvm.16263823325747306480+0x2b8>
  66ad2b:	48 89 f3             	mov    %rsi,%rbx
  66ad2e:	44 89 fe             	mov    %r15d,%esi
  66ad31:	4c 89 c5             	mov    %r8,%rbp
  66ad34:	ff 15 6e ff 11 00    	call   *0x11ff6e(%rip)        # 78aca8 <_DYNAMIC+0x620>
  66ad3a:	49 89 e8             	mov    %rbp,%r8
  66ad3d:	4c 89 ef             	mov    %r13,%rdi
  66ad40:	48 89 de             	mov    %rbx,%rsi
  66ad43:	84 c0                	test   %al,%al
  66ad45:	0f 85 f5 fe ff ff    	jne    66ac40 <<gpui_canvas::text::planner::Planner>::shape+0xe0>
  66ad4b:	41 bc 0a 00 00 00    	mov    $0xa,%r12d
  66ad51:	41 83 ff 20          	cmp    $0x20,%r15d
  66ad55:	0f 82 67 02 00 00    	jb     66afc2 <<gpui_canvas::text::planner::Planner>::shape+0x462>
  66ad5b:	41 8d 47 81          	lea    -0x7f(%r15),%eax
  66ad5f:	83 f8 21             	cmp    $0x21,%eax
  66ad62:	0f 82 5a 02 00 00    	jb     66afc2 <<gpui_canvas::text::planner::Planner>::shape+0x462>
  66ad68:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  66ad6d:	44 89 fe             	mov    %r15d,%esi
  66ad70:	e8 1b 3b 00 00       	call   66e890 <<gpui_canvas::text::planner::Cmap>::glyph_index>
  66ad75:	49 89 e8             	mov    %rbp,%r8
  66ad78:	4c 89 ef             	mov    %r13,%rdi
  66ad7b:	a8 01                	test   $0x1,%al
  66ad7d:	4c 8b a4 24 c0 01 00 	mov    0x1c0(%rsp),%r12
  66ad84:	00 
  66ad85:	74 0c                	je     66ad93 <<gpui_canvas::text::planner::Planner>::shape+0x233>
  66ad87:	48 89 de             	mov    %rbx,%rsi
  66ad8a:	66 85 d2             	test   %dx,%dx
  66ad8d:	0f 85 ad fe ff ff    	jne    66ac40 <<gpui_canvas::text::planner::Planner>::shape+0xe0>
  66ad93:	48 8b 0c 24          	mov    (%rsp),%rcx
  66ad97:	48 8b 81 40 0a 00 00 	mov    0xa40(%rcx),%rax
  66ad9e:	41 bc 0b 00 00 00    	mov    $0xb,%r12d
  66ada4:	80 78 38 01          	cmpb   $0x1,0x38(%rax)
  66ada8:	0f 85 14 02 00 00    	jne    66afc2 <<gpui_canvas::text::planner::Planner>::shape+0x462>
  66adae:	48 83 79 30 00       	cmpq   $0x0,0x30(%rcx)
  66adb3:	0f 85 f2 00 00 00    	jne    66aeab <<gpui_canvas::text::planner::Planner>::shape+0x34b>
  66adb9:	ba 48 ab 03 00       	mov    $0x3ab48,%edx
  66adbe:	48 8d 35 c7 ad 9b ff 	lea    -0x645239(%rip),%rsi        # 25b8c <gpui_canvas::text::ARABIC_BYTES>
  66adc5:	31 c9                	xor    %ecx,%ecx
  66adc7:	41 ff d0             	call   *%r8
  66adca:	83 bc 24 e0 06 00 00 	cmpl   $0xffffffff,0x6e0(%rsp)
  66add1:	ff 
  66add2:	0f 84 f7 2e 00 00    	je     66dccf <<gpui_canvas::text::planner::Planner>::shape+0x316f>
  66add8:	8b 84 24 b8 0c 00 00 	mov    0xcb8(%rsp),%eax
  66addf:	89 84 24 f0 01 00 00 	mov    %eax,0x1f0(%rsp)
  66ade6:	0f 10 03             	movups (%rbx),%xmm0
  66ade9:	0f 10 4b 0c          	movups 0xc(%rbx),%xmm1
  66aded:	0f 29 84 24 90 04 00 	movaps %xmm0,0x490(%rsp)
  66adf4:	00 
  66adf5:	0f 11 8c 24 9c 04 00 	movups %xmm1,0x49c(%rsp)
  66adfc:	00 
  66adfd:	ba 14 69 00 00       	mov    $0x6914,%edx
  66ae02:	48 8d bc 24 e0 06 00 	lea    0x6e0(%rsp),%rdi
  66ae09:	00 
  66ae0a:	48 8d 35 c3 58 9f ff 	lea    -0x60a73d(%rip),%rsi        # 606d4 <gpui_canvas::text::HEBREW_BYTES>
  66ae11:	31 c9                	xor    %ecx,%ecx
  66ae13:	ff 15 97 fc 11 00    	call   *0x11fc97(%rip)        # 78aab0 <_DYNAMIC+0x428>
  66ae19:	83 bc 24 e0 06 00 00 	cmpl   $0xffffffff,0x6e0(%rsp)
  66ae20:	ff 
  66ae21:	0f 84 bd 2e 00 00    	je     66dce4 <<gpui_canvas::text::planner::Planner>::shape+0x3184>
  66ae27:	8b 94 24 b8 0c 00 00 	mov    0xcb8(%rsp),%edx
  66ae2e:	48 8d 84 24 bc 0c 00 	lea    0xcbc(%rsp),%rax
  66ae35:	00 
  66ae36:	0f 10 00             	movups (%rax),%xmm0
  66ae39:	0f 10 48 0c          	movups 0xc(%rax),%xmm1
  66ae3d:	0f 29 84 24 30 03 00 	movaps %xmm0,0x330(%rsp)
  66ae44:	00 
  66ae45:	0f 11 8c 24 3c 03 00 	movups %xmm1,0x33c(%rsp)
  66ae4c:	00 
  66ae4d:	48 8b 04 24          	mov    (%rsp),%rax
  66ae51:	48 c7 40 30 01 00 00 	movq   $0x1,0x30(%rax)
  66ae58:	00 
  66ae59:	8b 8c 24 f0 01 00 00 	mov    0x1f0(%rsp),%ecx
  66ae60:	89 48 38             	mov    %ecx,0x38(%rax)
  66ae63:	0f 10 84 24 9c 04 00 	movups 0x49c(%rsp),%xmm0
  66ae6a:	00 
  66ae6b:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
  66ae72:	00 
  66ae73:	0f 11 41 0c          	movups %xmm0,0xc(%rcx)
  66ae77:	0f 28 84 24 90 04 00 	movaps 0x490(%rsp),%xmm0
  66ae7e:	00 
  66ae7f:	0f 11 01             	movups %xmm0,(%rcx)
  66ae82:	89 94 24 90 00 00 00 	mov    %edx,0x90(%rsp)
  66ae89:	89 50 58             	mov    %edx,0x58(%rax)
  66ae8c:	0f 10 84 24 3c 03 00 	movups 0x33c(%rsp),%xmm0
  66ae93:	00 
  66ae94:	48 8b 84 24 e0 00 00 	mov    0xe0(%rsp),%rax
  66ae9b:	00 
  66ae9c:	0f 11 40 0c          	movups %xmm0,0xc(%rax)
  66aea0:	0f 28 84 24 30 03 00 	movaps 0x330(%rsp),%xmm0
  66aea7:	00 
  66aea8:	0f 11 00             	movups %xmm0,(%rax)
  66aeab:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  66aeb0:	44 89 fe             	mov    %r15d,%esi
  66aeb3:	e8 d8 39 00 00       	call   66e890 <<gpui_canvas::text::planner::Cmap>::glyph_index>
  66aeb8:	66 85 d2             	test   %dx,%dx
  66aebb:	0f 95 c1             	setne  %cl
  66aebe:	20 c1                	and    %al,%cl
  66aec0:	88 8c 24 30 01 00 00 	mov    %cl,0x130(%rsp)
  66aec7:	48 8b 7c 24 70       	mov    0x70(%rsp),%rdi
  66aecc:	44 89 fe             	mov    %r15d,%esi
  66aecf:	e8 bc 39 00 00       	call   66e890 <<gpui_canvas::text::planner::Cmap>::glyph_index>
  66aed4:	66 85 d2             	test   %dx,%dx
  66aed7:	0f 95 c1             	setne  %cl
  66aeda:	20 c1                	and    %al,%cl
  66aedc:	00 c9                	add    %cl,%cl
  66aede:	0a 8c 24 30 01 00 00 	or     0x130(%rsp),%cl
  66aee5:	0f 84 d7 00 00 00    	je     66afc2 <<gpui_canvas::text::planner::Planner>::shape+0x462>
  66aeeb:	44 8b 7c 24 20       	mov    0x20(%rsp),%r15d
  66aef0:	41 08 cf             	or     %cl,%r15b
  66aef3:	4c 8b a4 24 c0 01 00 	mov    0x1c0(%rsp),%r12
  66aefa:	00 
  66aefb:	4d 39 e6             	cmp    %r12,%r14
  66aefe:	48 89 de             	mov    %rbx,%rsi
  66af01:	4c 89 ef             	mov    %r13,%rdi
  66af04:	49 89 e8             	mov    %rbp,%r8
  66af07:	0f 85 16 fd ff ff    	jne    66ac23 <<gpui_canvas::text::planner::Planner>::shape+0xc3>
  66af0d:	eb 05                	jmp    66af14 <<gpui_canvas::text::planner::Planner>::shape+0x3b4>
  66af0f:	44 8b 7c 24 20       	mov    0x20(%rsp),%r15d
  66af14:	41 f6 c7 01          	test   $0x1,%r15b
  66af18:	4c 8b 2c 24          	mov    (%rsp),%r13
  66af1c:	0f 84 c5 00 00 00    	je     66afe7 <<gpui_canvas::text::planner::Planner>::shape+0x487>
  66af22:	49 83 bd 48 0a 00 00 	cmpq   $0x0,0xa48(%r13)
  66af29:	00 
  66af2a:	0f 85 b7 00 00 00    	jne    66afe7 <<gpui_canvas::text::planner::Planner>::shape+0x487>
  66af30:	48 8d 35 c9 29 12 00 	lea    0x1229c9(%rip),%rsi        # 78d900 <gpui_canvas::text::ARABIC_FONT>
  66af37:	48 8d 15 4e ac 9b ff 	lea    -0x6453b2(%rip),%rdx        # 25b8c <gpui_canvas::text::ARABIC_BYTES>
  66af3e:	48 8d bc 24 e0 06 00 	lea    0x6e0(%rsp),%rdi
  66af45:	00 
  66af46:	b9 48 ab 03 00       	mov    $0x3ab48,%ecx
  66af4b:	45 31 c0             	xor    %r8d,%r8d
  66af4e:	e8 cd 94 ff ff       	call   664420 <<gpui_canvas::text::FontFace>::shared_static>
  66af53:	83 bc 24 e0 06 00 00 	cmpl   $0x1,0x6e0(%rsp)
  66af5a:	01 
  66af5b:	75 1a                	jne    66af77 <<gpui_canvas::text::planner::Planner>::shape+0x417>
  66af5d:	44 8b a4 24 e4 06 00 	mov    0x6e4(%rsp),%r12d
  66af64:	00 
  66af65:	44 8b bc 24 e8 06 00 	mov    0x6e8(%rsp),%r15d
  66af6c:	00 
  66af6d:	eb 53                	jmp    66afc2 <<gpui_canvas::text::planner::Planner>::shape+0x462>
  66af6f:	45 31 ff             	xor    %r15d,%r15d
  66af72:	e9 84 00 00 00       	jmp    66affb <<gpui_canvas::text::planner::Planner>::shape+0x49b>
  66af77:	44 89 fd             	mov    %r15d,%ebp
  66af7a:	49 8d 9d 48 0a 00 00 	lea    0xa48(%r13),%rbx
  66af81:	4c 8b bc 24 e8 06 00 	mov    0x6e8(%rsp),%r15
  66af88:	00 
  66af89:	48 8b 03             	mov    (%rbx),%rax
  66af8c:	48 85 c0             	test   %rax,%rax
  66af8f:	74 0f                	je     66afa0 <<gpui_canvas::text::planner::Planner>::shape+0x440>
  66af91:	f0 48 ff 08          	lock decq (%rax)
  66af95:	75 09                	jne    66afa0 <<gpui_canvas::text::planner::Planner>::shape+0x440>
  66af97:	48 89 df             	mov    %rbx,%rdi
  66af9a:	ff 15 48 f9 11 00    	call   *0x11f948(%rip)        # 78a8e8 <_DYNAMIC+0x260>
  66afa0:	4d 89 bd 48 0a 00 00 	mov    %r15,0xa48(%r13)
  66afa7:	be 01 00 00 00       	mov    $0x1,%esi
  66afac:	4c 89 ef             	mov    %r13,%rdi
  66afaf:	e8 dc 35 00 00       	call   66e590 <<gpui_canvas::text::planner::Planner>::register>
  66afb4:	83 f8 ff             	cmp    $0xffffffff,%eax
  66afb7:	41 89 ef             	mov    %ebp,%r15d
  66afba:	74 2b                	je     66afe7 <<gpui_canvas::text::planner::Planner>::shape+0x487>
  66afbc:	41 89 c4             	mov    %eax,%r12d
  66afbf:	45 31 ff             	xor    %r15d,%r15d
  66afc2:	44 89 a4 24 a0 00 00 	mov    %r12d,0xa0(%rsp)
  66afc9:	00 
  66afca:	44 89 bc 24 a4 00 00 	mov    %r15d,0xa4(%rsp)
  66afd1:	00 
  66afd2:	48 c7 84 24 98 00 00 	movq   $0xffffffffffffffff,0x98(%rsp)
  66afd9:	00 ff ff ff ff 
  66afde:	4c 8b 2c 24          	mov    (%rsp),%r13
  66afe2:	e9 38 28 00 00       	jmp    66d81f <<gpui_canvas::text::planner::Planner>::shape+0x2cbf>
  66afe7:	41 f6 c7 02          	test   $0x2,%r15b
  66afeb:	74 0e                	je     66affb <<gpui_canvas::text::planner::Planner>::shape+0x49b>
  66afed:	49 83 bd 50 0a 00 00 	cmpq   $0x0,0xa50(%r13)
  66aff4:	00 
  66aff5:	0f 84 c1 29 00 00    	je     66d9bc <<gpui_canvas::text::planner::Planner>::shape+0x2e5c>
  66affb:	48 c7 84 24 a0 02 00 	movq   $0xffffffffffffffff,0x2a0(%rsp)
  66b002:	00 ff ff ff ff 
  66b007:	48 8d 05 cc 04 bf ff 	lea    -0x40fb34(%rip),%rax        # 25b4da <anon.fcf2ae708c8bfcebac3bd597053acdb9.5.llvm.16263823325747306480+0xa2>
  66b00e:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
  66b015:	00 
  66b016:	48 c7 84 24 b0 02 00 	movq   $0xc,0x2b0(%rsp)
  66b01d:	00 0c 00 00 00 
  66b022:	48 c7 84 24 b8 02 00 	movq   $0xffffffffffffffff,0x2b8(%rsp)
  66b029:	00 ff ff ff ff 
  66b02e:	48 8d 05 b1 04 bf ff 	lea    -0x40fb4f(%rip),%rax        # 25b4e6 <anon.fcf2ae708c8bfcebac3bd597053acdb9.5.llvm.16263823325747306480+0xae>
  66b035:	48 89 84 24 c0 02 00 	mov    %rax,0x2c0(%rsp)
  66b03c:	00 
  66b03d:	48 c7 84 24 c8 02 00 	movq   $0x11,0x2c8(%rsp)
  66b044:	00 11 00 00 00 
  66b049:	48 c7 84 24 d0 02 00 	movq   $0xffffffffffffffff,0x2d0(%rsp)
  66b050:	00 ff ff ff ff 
  66b055:	48 8d 1d 9b 04 bf ff 	lea    -0x40fb65(%rip),%rbx        # 25b4f7 <anon.fcf2ae708c8bfcebac3bd597053acdb9.5.llvm.16263823325747306480+0xbf>
  66b05c:	48 89 9c 24 d8 02 00 	mov    %rbx,0x2d8(%rsp)
  66b063:	00 
  66b064:	48 c7 84 24 e0 02 00 	movq   $0x11,0x2e0(%rsp)
  66b06b:	00 11 00 00 00 
  66b070:	41 f6 c7 01          	test   $0x1,%r15b
  66b074:	75 1d                	jne    66b093 <<gpui_canvas::text::planner::Planner>::shape+0x533>
  66b076:	4c 8d b4 24 b8 02 00 	lea    0x2b8(%rsp),%r14
  66b07d:	00 
  66b07e:	b8 01 00 00 00       	mov    $0x1,%eax
  66b083:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
  66b08a:	00 
  66b08b:	41 f6 c7 02          	test   $0x2,%r15b
  66b08f:	75 25                	jne    66b0b6 <<gpui_canvas::text::planner::Planner>::shape+0x556>
  66b091:	eb 5b                	jmp    66b0ee <<gpui_canvas::text::planner::Planner>::shape+0x58e>
  66b093:	4c 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%r14
  66b09a:	00 
  66b09b:	48 89 84 24 c0 02 00 	mov    %rax,0x2c0(%rsp)
  66b0a2:	00 
  66b0a3:	b8 02 00 00 00       	mov    $0x2,%eax
  66b0a8:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
  66b0af:	00 
  66b0b0:	41 f6 c7 02          	test   $0x2,%r15b
  66b0b4:	74 38                	je     66b0ee <<gpui_canvas::text::planner::Planner>::shape+0x58e>
  66b0b6:	49 8b 36             	mov    (%r14),%rsi
  66b0b9:	48 83 fe fd          	cmp    $0xfffffffffffffffd,%rsi
  66b0bd:	77 14                	ja     66b0d3 <<gpui_canvas::text::planner::Planner>::shape+0x573>
  66b0bf:	48 85 f6             	test   %rsi,%rsi
  66b0c2:	74 0f                	je     66b0d3 <<gpui_canvas::text::planner::Planner>::shape+0x573>
  66b0c4:	49 8b 7e 08          	mov    0x8(%r14),%rdi
  66b0c8:	ba 01 00 00 00       	mov    $0x1,%edx
  66b0cd:	ff 15 ed f7 11 00    	call   *0x11f7ed(%rip)        # 78a8c0 <_DYNAMIC+0x238>
  66b0d3:	49 c7 06 ff ff ff ff 	movq   $0xffffffffffffffff,(%r14)
  66b0da:	49 89 5e 08          	mov    %rbx,0x8(%r14)
  66b0de:	49 c7 46 10 11 00 00 	movq   $0x11,0x10(%r14)
  66b0e5:	00 
  66b0e6:	48 ff 84 24 18 02 00 	incq   0x218(%rsp)
  66b0ed:	00 
  66b0ee:	48 c7 84 24 18 01 00 	movq   $0x0,0x118(%rsp)
  66b0f5:	00 00 00 00 00 
  66b0fa:	48 c7 84 24 20 01 00 	movq   $0x4,0x120(%rsp)
  66b101:	00 04 00 00 00 
  66b106:	48 c7 84 24 28 01 00 	movq   $0x0,0x128(%rsp)
  66b10d:	00 00 00 00 00 
  66b112:	48 c7 84 24 68 01 00 	movq   $0xffffffffffffffff,0x168(%rsp)
  66b119:	00 ff ff ff ff 
  66b11e:	f6 84 24 d8 01 00 00 	testb  $0x1,0x1d8(%rsp)
  66b125:	01 
  66b126:	75 11                	jne    66b139 <<gpui_canvas::text::planner::Planner>::shape+0x5d9>
  66b128:	f3 0f 10 05 ac 27 9b 	movss  -0x64d854(%rip),%xmm0        # 1d8dc <GCC_except_table0+0x94>
  66b12f:	ff 
  66b130:	f3 0f 11 84 24 dc 01 	movss  %xmm0,0x1dc(%rsp)
  66b137:	00 00 
  66b139:	49 8d 45 78          	lea    0x78(%r13),%rax
  66b13d:	48 89 84 24 20 03 00 	mov    %rax,0x320(%rsp)
  66b144:	00 
  66b145:	49 8d 85 38 06 00 00 	lea    0x638(%r13),%rax
  66b14c:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
  66b153:	00 
  66b154:	49 8d 85 c8 08 00 00 	lea    0x8c8(%r13),%rax
  66b15b:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  66b160:	4c 8d ac 24 40 03 00 	lea    0x340(%rsp),%r13
  66b167:	00 
  66b168:	0f 57 c0             	xorps  %xmm0,%xmm0
  66b16b:	0f 29 84 24 90 02 00 	movaps %xmm0,0x290(%rsp)
  66b172:	00 
  66b173:	f3 0f 11 44 24 0c    	movss  %xmm0,0xc(%rsp)
  66b179:	f3 0f 11 44 24 64    	movss  %xmm0,0x64(%rsp)
  66b17f:	4c 8d a4 24 98 04 00 	lea    0x498(%rsp),%r12
  66b186:	00 
  66b187:	48 8d 05 8a 4e 11 00 	lea    0x114e8a(%rip),%rax        # 780018 <anon.fcf2ae708c8bfcebac3bd597053acdb9.9.llvm.16263823325747306480+0x3f8>
  66b18e:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  66b193:	48 8d 05 76 59 11 00 	lea    0x115976(%rip),%rax        # 780b10 <anon.dc752cbb3d3389760d876509e45b0baf.23.llvm.10480319710464438355>
  66b19a:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
  66b1a1:	00 
  66b1a2:	48 c7 84 24 10 02 00 	movq   $0x0,0x210(%rsp)
  66b1a9:	00 00 00 00 00 
  66b1ae:	31 db                	xor    %ebx,%ebx
  66b1b0:	48 8b 84 24 60 01 00 	mov    0x160(%rsp),%rax
  66b1b7:	00 
  66b1b8:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  66b1bd:	31 c0                	xor    %eax,%eax
  66b1bf:	be fe ff ff ff       	mov    $0xfffffffe,%esi
  66b1c4:	83 fe fe             	cmp    $0xfffffffe,%esi
  66b1c7:	75 27                	jne    66b1f0 <<gpui_canvas::text::planner::Planner>::shape+0x690>
  66b1c9:	4c 8b 4c 24 18       	mov    0x18(%rsp),%r9
  66b1ce:	4c 3b 8c 24 c0 01 00 	cmp    0x1c0(%rsp),%r9
  66b1d5:	00 
  66b1d6:	74 2c                	je     66b204 <<gpui_canvas::text::planner::Planner>::shape+0x6a4>
  66b1d8:	41 0f b6 09          	movzbl (%r9),%ecx
  66b1dc:	84 c9                	test   %cl,%cl
  66b1de:	78 3f                	js     66b21f <<gpui_canvas::text::planner::Planner>::shape+0x6bf>
  66b1e0:	49 8d 51 01          	lea    0x1(%r9),%rdx
  66b1e4:	e9 93 00 00 00       	jmp    66b27c <<gpui_canvas::text::planner::Planner>::shape+0x71c>
  66b1e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  66b1f0:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
  66b1f5:	89 f1                	mov    %esi,%ecx
  66b1f7:	4c 8b 84 24 00 03 00 	mov    0x300(%rsp),%r8
  66b1fe:	00 
  66b1ff:	e9 81 00 00 00       	jmp    66b285 <<gpui_canvas::text::planner::Planner>::shape+0x725>
  66b204:	c7 44 24 68 fe ff ff 	movl   $0xfffffffe,0x68(%rsp)
  66b20b:	ff 
  66b20c:	b1 01                	mov    $0x1,%cl
  66b20e:	89 4c 24 3c          	mov    %ecx,0x3c(%rsp)
  66b212:	4c 8b 74 24 48       	mov    0x48(%rsp),%r14
  66b217:	48 89 de             	mov    %rbx,%rsi
  66b21a:	e9 ea 01 00 00       	jmp    66b409 <<gpui_canvas::text::planner::Planner>::shape+0x8a9>
  66b21f:	49 89 c0             	mov    %rax,%r8
  66b222:	89 c8                	mov    %ecx,%eax
  66b224:	83 e0 1f             	and    $0x1f,%eax
  66b227:	41 0f b6 79 01       	movzbl 0x1(%r9),%edi
  66b22c:	83 e7 3f             	and    $0x3f,%edi
  66b22f:	80 f9 e0             	cmp    $0xe0,%cl
  66b232:	72 2d                	jb     66b261 <<gpui_canvas::text::planner::Planner>::shape+0x701>
  66b234:	41 0f b6 71 02       	movzbl 0x2(%r9),%esi
  66b239:	c1 e7 06             	shl    $0x6,%edi
  66b23c:	83 e6 3f             	and    $0x3f,%esi
  66b23f:	09 fe                	or     %edi,%esi
  66b241:	80 f9 f0             	cmp    $0xf0,%cl
  66b244:	72 28                	jb     66b26e <<gpui_canvas::text::planner::Planner>::shape+0x70e>
  66b246:	49 8d 51 04          	lea    0x4(%r9),%rdx
  66b24a:	41 0f b6 49 03       	movzbl 0x3(%r9),%ecx
  66b24f:	83 e0 07             	and    $0x7,%eax
  66b252:	c1 e0 12             	shl    $0x12,%eax
  66b255:	c1 e6 06             	shl    $0x6,%esi
  66b258:	83 e1 3f             	and    $0x3f,%ecx
  66b25b:	09 f1                	or     %esi,%ecx
  66b25d:	09 c1                	or     %eax,%ecx
  66b25f:	eb 18                	jmp    66b279 <<gpui_canvas::text::planner::Planner>::shape+0x719>
  66b261:	49 8d 51 02          	lea    0x2(%r9),%rdx
  66b265:	c1 e0 06             	shl    $0x6,%eax
  66b268:	09 f8                	or     %edi,%eax
  66b26a:	89 c1                	mov    %eax,%ecx
  66b26c:	eb 0b                	jmp    66b279 <<gpui_canvas::text::planner::Planner>::shape+0x719>
  66b26e:	49 8d 51 03          	lea    0x3(%r9),%rdx
  66b272:	c1 e0 0c             	shl    $0xc,%eax
  66b275:	09 c6                	or     %eax,%esi
  66b277:	89 f1                	mov    %esi,%ecx
  66b279:	4c 89 c0             	mov    %r8,%rax
  66b27c:	49 89 c0             	mov    %rax,%r8
  66b27f:	4c 29 c8             	sub    %r9,%rax
  66b282:	48 01 d0             	add    %rdx,%rax
  66b285:	c7 44 24 68 fe ff ff 	movl   $0xfffffffe,0x68(%rsp)
  66b28c:	ff 
  66b28d:	40 b6 01             	mov    $0x1,%sil
  66b290:	89 74 24 3c          	mov    %esi,0x3c(%rsp)
  66b294:	83 f9 0c             	cmp    $0xc,%ecx
  66b297:	7e 27                	jle    66b2c0 <<gpui_canvas::text::planner::Planner>::shape+0x760>
  66b299:	83 f9 0d             	cmp    $0xd,%ecx
  66b29c:	0f 84 39 01 00 00    	je     66b3db <<gpui_canvas::text::planner::Planner>::shape+0x87b>
  66b2a2:	81 f9 85 00 00 00    	cmp    $0x85,%ecx
  66b2a8:	74 24                	je     66b2ce <<gpui_canvas::text::planner::Planner>::shape+0x76e>
  66b2aa:	81 f9 29 20 00 00    	cmp    $0x2029,%ecx
  66b2b0:	74 1c                	je     66b2ce <<gpui_canvas::text::planner::Planner>::shape+0x76e>
  66b2b2:	eb 69                	jmp    66b31d <<gpui_canvas::text::planner::Planner>::shape+0x7bd>
  66b2b4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  66b2bb:	00 00 00 00 00 
  66b2c0:	83 f9 ff             	cmp    $0xffffffff,%ecx
  66b2c3:	0f 84 03 01 00 00    	je     66b3cc <<gpui_canvas::text::planner::Planner>::shape+0x86c>
  66b2c9:	83 f9 0a             	cmp    $0xa,%ecx
  66b2cc:	75 4f                	jne    66b31d <<gpui_canvas::text::planner::Planner>::shape+0x7bd>
  66b2ce:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
  66b2d3:	81 f9 80 00 00 00    	cmp    $0x80,%ecx
  66b2d9:	0f 83 0d 01 00 00    	jae    66b3ec <<gpui_canvas::text::planner::Planner>::shape+0x88c>
  66b2df:	49 8d 70 01          	lea    0x1(%r8),%rsi
  66b2e3:	83 f9 0d             	cmp    $0xd,%ecx
  66b2e6:	0f 84 dd 21 00 00    	je     66d4c9 <<gpui_canvas::text::planner::Planner>::shape+0x2969>
  66b2ec:	4d 89 c6             	mov    %r8,%r14
  66b2ef:	e9 0d 01 00 00       	jmp    66b401 <<gpui_canvas::text::planner::Planner>::shape+0x8a1>
  66b2f4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  66b2fb:	00 00 00 00 00 
  66b300:	81 f9 29 20 00 00    	cmp    $0x2029,%ecx
  66b306:	0f 84 d4 00 00 00    	je     66b3e0 <<gpui_canvas::text::planner::Planner>::shape+0x880>
  66b30c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
  66b311:	81 f9 85 00 00 00    	cmp    $0x85,%ecx
  66b317:	0f 84 c3 00 00 00    	je     66b3e0 <<gpui_canvas::text::planner::Planner>::shape+0x880>
  66b31d:	48 3b 94 24 c0 01 00 	cmp    0x1c0(%rsp),%rdx
  66b324:	00 
  66b325:	0f 84 a1 00 00 00    	je     66b3cc <<gpui_canvas::text::planner::Planner>::shape+0x86c>
  66b32b:	49 89 c0             	mov    %rax,%r8
  66b32e:	0f b6 0a             	movzbl (%rdx),%ecx
  66b331:	84 c9                	test   %cl,%cl
  66b333:	78 0b                	js     66b340 <<gpui_canvas::text::planner::Planner>::shape+0x7e0>
  66b335:	48 8d 42 01          	lea    0x1(%rdx),%rax
  66b339:	eb 65                	jmp    66b3a0 <<gpui_canvas::text::planner::Planner>::shape+0x840>
  66b33b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  66b340:	89 c8                	mov    %ecx,%eax
  66b342:	83 e0 1f             	and    $0x1f,%eax
  66b345:	0f b6 7a 01          	movzbl 0x1(%rdx),%edi
  66b349:	83 e7 3f             	and    $0x3f,%edi
  66b34c:	80 f9 df             	cmp    $0xdf,%cl
  66b34f:	76 2e                	jbe    66b37f <<gpui_canvas::text::planner::Planner>::shape+0x81f>
  66b351:	0f b6 72 02          	movzbl 0x2(%rdx),%esi
  66b355:	c1 e7 06             	shl    $0x6,%edi
  66b358:	83 e6 3f             	and    $0x3f,%esi
  66b35b:	09 fe                	or     %edi,%esi
  66b35d:	80 f9 f0             	cmp    $0xf0,%cl
  66b360:	72 2d                	jb     66b38f <<gpui_canvas::text::planner::Planner>::shape+0x82f>
  66b362:	48 8d 7a 04          	lea    0x4(%rdx),%rdi
  66b366:	0f b6 4a 03          	movzbl 0x3(%rdx),%ecx
  66b36a:	83 e0 07             	and    $0x7,%eax
  66b36d:	c1 e0 12             	shl    $0x12,%eax
  66b370:	c1 e6 06             	shl    $0x6,%esi
  66b373:	83 e1 3f             	and    $0x3f,%ecx
  66b376:	09 f1                	or     %esi,%ecx
  66b378:	09 c1                	or     %eax,%ecx
  66b37a:	48 89 f8             	mov    %rdi,%rax
  66b37d:	eb 21                	jmp    66b3a0 <<gpui_canvas::text::planner::Planner>::shape+0x840>
  66b37f:	48 8d 72 02          	lea    0x2(%rdx),%rsi
  66b383:	c1 e0 06             	shl    $0x6,%eax
  66b386:	09 f8                	or     %edi,%eax
  66b388:	89 c1                	mov    %eax,%ecx
  66b38a:	48 89 f0             	mov    %rsi,%rax
  66b38d:	eb 11                	jmp    66b3a0 <<gpui_canvas::text::planner::Planner>::shape+0x840>
  66b38f:	48 8d 4a 03          	lea    0x3(%rdx),%rcx
  66b393:	c1 e0 0c             	shl    $0xc,%eax
  66b396:	09 c6                	or     %eax,%esi
  66b398:	48 89 c8             	mov    %rcx,%rax
  66b39b:	89 f1                	mov    %esi,%ecx
  66b39d:	0f 1f 00             	nopl   (%rax)
  66b3a0:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  66b3a5:	48 29 d0             	sub    %rdx,%rax
  66b3a8:	4c 01 c0             	add    %r8,%rax
  66b3ab:	81 f9 84 00 00 00    	cmp    $0x84,%ecx
  66b3b1:	0f 8f 49 ff ff ff    	jg     66b300 <<gpui_canvas::text::planner::Planner>::shape+0x7a0>
  66b3b7:	83 f9 0a             	cmp    $0xa,%ecx
  66b3ba:	74 24                	je     66b3e0 <<gpui_canvas::text::planner::Planner>::shape+0x880>
  66b3bc:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
  66b3c1:	83 f9 0d             	cmp    $0xd,%ecx
  66b3c4:	0f 85 53 ff ff ff    	jne    66b31d <<gpui_canvas::text::planner::Planner>::shape+0x7bd>
  66b3ca:	eb 14                	jmp    66b3e0 <<gpui_canvas::text::planner::Planner>::shape+0x880>
  66b3cc:	4c 8b 74 24 48       	mov    0x48(%rsp),%r14
  66b3d1:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
  66b3d6:	48 89 de             	mov    %rbx,%rsi
  66b3d9:	eb 2e                	jmp    66b409 <<gpui_canvas::text::planner::Planner>::shape+0x8a9>
  66b3db:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
  66b3e0:	81 f9 80 00 00 00    	cmp    $0x80,%ecx
  66b3e6:	0f 82 f3 fe ff ff    	jb     66b2df <<gpui_canvas::text::planner::Planner>::shape+0x77f>
  66b3ec:	81 f9 00 08 00 00    	cmp    $0x800,%ecx
  66b3f2:	be 03 00 00 00       	mov    $0x3,%esi
  66b3f7:	48 83 de 00          	sbb    $0x0,%rsi
  66b3fb:	4d 89 c6             	mov    %r8,%r14
  66b3fe:	4c 01 c6             	add    %r8,%rsi
  66b401:	c7 44 24 3c 00 00 00 	movl   $0x0,0x3c(%rsp)
  66b408:	00 
  66b409:	4d 89 f7             	mov    %r14,%r15
  66b40c:	49 29 df             	sub    %rbx,%r15
  66b40f:	0f 82 64 2c 00 00    	jb     66e079 <<gpui_canvas::text::planner::Planner>::shape+0x3519>
  66b415:	48 85 db             	test   %rbx,%rbx
  66b418:	48 89 84 24 10 03 00 	mov    %rax,0x310(%rsp)
  66b41f:	00 
  66b420:	74 24                	je     66b446 <<gpui_canvas::text::planner::Planner>::shape+0x8e6>
  66b422:	48 3b 5c 24 48       	cmp    0x48(%rsp),%rbx
  66b427:	73 17                	jae    66b440 <<gpui_canvas::text::planner::Planner>::shape+0x8e0>
  66b429:	48 8b 84 24 60 01 00 	mov    0x160(%rsp),%rax
  66b430:	00 
  66b431:	80 3c 18 bf          	cmpb   $0xbf,(%rax,%rbx,1)
  66b435:	7f 0f                	jg     66b446 <<gpui_canvas::text::planner::Planner>::shape+0x8e6>
  66b437:	e9 3d 2c 00 00       	jmp    66e079 <<gpui_canvas::text::planner::Planner>::shape+0x3519>
  66b43c:	0f 1f 40 00          	nopl   0x0(%rax)
  66b440:	0f 85 33 2c 00 00    	jne    66e079 <<gpui_canvas::text::planner::Planner>::shape+0x3519>
  66b446:	4d 85 f6             	test   %r14,%r14
  66b449:	74 2b                	je     66b476 <<gpui_canvas::text::planner::Planner>::shape+0x916>
  66b44b:	4c 3b 74 24 48       	cmp    0x48(%rsp),%r14
  66b450:	73 1e                	jae    66b470 <<gpui_canvas::text::planner::Planner>::shape+0x910>
  66b452:	48 8b 84 24 60 01 00 	mov    0x160(%rsp),%rax
  66b459:	00 
  66b45a:	42 80 3c 30 c0       	cmpb   $0xc0,(%rax,%r14,1)
  66b45f:	7d 15                	jge    66b476 <<gpui_canvas::text::planner::Planner>::shape+0x916>
  66b461:	e9 13 2c 00 00       	jmp    66e079 <<gpui_canvas::text::planner::Planner>::shape+0x3519>
  66b466:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  66b46d:	00 00 00 
  66b470:	0f 85 03 2c 00 00    	jne    66e079 <<gpui_canvas::text::planner::Planner>::shape+0x3519>
  66b476:	48 89 b4 24 08 03 00 	mov    %rsi,0x308(%rsp)
  66b47d:	00 
  66b47e:	48 8b 84 24 60 01 00 	mov    0x160(%rsp),%rax
  66b485:	00 
  66b486:	48 8d 0c 18          	lea    (%rax,%rbx,1),%rcx
  66b48a:	48 8d bc 24 68 04 00 	lea    0x468(%rsp),%rdi
  66b491:	00 
  66b492:	48 8b b4 24 20 03 00 	mov    0x320(%rsp),%rsi
  66b499:	00 
  66b49a:	48 8b 94 24 18 03 00 	mov    0x318(%rsp),%rdx
  66b4a1:	00 
  66b4a2:	48 89 8c 24 80 00 00 	mov    %rcx,0x80(%rsp)
  66b4a9:	00 
  66b4aa:	4d 89 f8             	mov    %r15,%r8
  66b4ad:	f3 0f 10 05 b7 23 9b 	movss  -0x64dc49(%rip),%xmm0        # 1d86c <GCC_except_table0+0x24>
  66b4b4:	ff 
  66b4b5:	45 31 c9             	xor    %r9d,%r9d
  66b4b8:	e8 b3 94 ff ff       	call   664970 <<parley::context::LayoutContext<()>>::ranged_builder>
  66b4bd:	48 8d bc 24 68 04 00 	lea    0x468(%rsp),%rdi
  66b4c4:	00 
  66b4c5:	48 8d b4 24 a0 02 00 	lea    0x2a0(%rsp),%rsi
  66b4cc:	00 
  66b4cd:	48 8b 94 24 18 02 00 	mov    0x218(%rsp),%rdx
  66b4d4:	00 
  66b4d5:	e8 c6 b8 00 00       	call   676da0 <<parley::builder::RangedBuilder<()>>::push_default::<&[parlance::font_family::FontFamilyName]>>
  66b4da:	f3 0f 10 44 24 6c    	movss  0x6c(%rsp),%xmm0
  66b4e0:	f3 0f 11 84 24 e4 06 	movss  %xmm0,0x6e4(%rsp)
  66b4e7:	00 00 
  66b4e9:	c6 84 24 e0 06 00 00 	movb   $0x1,0x6e0(%rsp)
  66b4f0:	01 
  66b4f1:	48 8d bc 24 68 04 00 	lea    0x468(%rsp),%rdi
  66b4f8:	00 
  66b4f9:	48 8d b4 24 e0 06 00 	lea    0x6e0(%rsp),%rsi
  66b500:	00 
  66b501:	e8 6a b7 00 00       	call   676c70 <<parley::builder::RangedBuilder<()>>::push_default::<parley::style::StyleProperty<()>>>
  66b506:	66 c7 84 24 e0 06 00 	movw   $0x117,0x6e0(%rsp)
  66b50d:	00 17 01 
  66b510:	48 8d bc 24 68 04 00 	lea    0x468(%rsp),%rdi
  66b517:	00 
  66b518:	48 8d b4 24 e0 06 00 	lea    0x6e0(%rsp),%rsi
  66b51f:	00 
  66b520:	e8 4b b7 00 00       	call   676c70 <<parley::builder::RangedBuilder<()>>::push_default::<parley::style::StyleProperty<()>>>
  66b525:	48 8d bc 24 68 04 00 	lea    0x468(%rsp),%rdi
  66b52c:	00 
  66b52d:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  66b532:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
  66b539:	00 
  66b53a:	4c 89 f9             	mov    %r15,%rcx
  66b53d:	e8 be 8a 00 00       	call   674000 <<parley::builder::RangedBuilder<()>>::build_into::<&str>>
  66b542:	48 8d bc 24 e0 06 00 	lea    0x6e0(%rsp),%rdi
  66b549:	00 
  66b54a:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  66b54f:	e8 4c a9 01 00       	call   685ea0 <<parley::layout::line_break::BreakLines<()>>::new>
  66b554:	48 8d bc 24 e0 06 00 	lea    0x6e0(%rsp),%rdi
  66b55b:	00 
  66b55c:	f3 0f 10 84 24 dc 01 	movss  0x1dc(%rsp),%xmm0
  66b563:	00 00 
  66b565:	e8 16 9a 01 00       	call   684f80 <<parley::layout::line_break::BreakLines<()>>::break_remaining>
  66b56a:	80 bc 24 3c 02 00 00 	cmpb   $0x0,0x23c(%rsp)
  66b571:	00 
  66b572:	4c 89 b4 24 b8 01 00 	mov    %r14,0x1b8(%rsp)
  66b579:	00 
  66b57a:	74 24                	je     66b5a0 <<gpui_canvas::text::planner::Planner>::shape+0xa40>
  66b57c:	48 83 bc 24 68 01 00 	cmpq   $0xffffffffffffffff,0x168(%rsp)
  66b583:	00 ff 
  66b585:	0f 85 05 02 00 00    	jne    66b790 <<gpui_canvas::text::planner::Planner>::shape+0xc30>
  66b58b:	31 c0                	xor    %eax,%eax
  66b58d:	e9 84 01 00 00       	jmp    66b716 <<gpui_canvas::text::planner::Planner>::shape+0xbb6>
  66b592:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  66b599:	1f 84 00 00 00 00 00 
  66b5a0:	48 85 db             	test   %rbx,%rbx
  66b5a3:	0f 85 57 01 00 00    	jne    66b700 <<gpui_canvas::text::planner::Planner>::shape+0xba0>
  66b5a9:	4c 3b 74 24 48       	cmp    0x48(%rsp),%r14
  66b5ae:	0f 85 4c 01 00 00    	jne    66b700 <<gpui_canvas::text::planner::Planner>::shape+0xba0>
  66b5b4:	48 8b 04 24          	mov    (%rsp),%rax
  66b5b8:	48 83 b8 e0 09 00 00 	cmpq   $0x1,0x9e0(%rax)
  66b5bf:	01 
  66b5c0:	0f 85 3a 01 00 00    	jne    66b700 <<gpui_canvas::text::planner::Planner>::shape+0xba0>
  66b5c6:	48 8b 14 24          	mov    (%rsp),%rdx
  66b5ca:	48 8b 82 d8 09 00 00 	mov    0x9d8(%rdx),%rax
  66b5d1:	48 8d 48 70          	lea    0x70(%rax),%rcx
  66b5d5:	48 89 8c 24 e8 06 00 	mov    %rcx,0x6e8(%rsp)
  66b5dc:	00 
  66b5dd:	48 c7 84 24 f0 06 00 	movq   $0x0,0x6f0(%rsp)
  66b5e4:	00 00 00 00 00 
  66b5e9:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  66b5ee:	48 89 b4 24 f8 06 00 	mov    %rsi,0x6f8(%rsp)
  66b5f5:	00 
  66b5f6:	48 c7 84 24 28 07 00 	movq   $0x0,0x728(%rsp)
  66b5fd:	00 00 00 00 00 
  66b602:	48 89 94 24 90 04 00 	mov    %rdx,0x490(%rsp)
  66b609:	00 
  66b60a:	48 c7 84 24 00 07 00 	movq   $0x0,0x700(%rsp)
  66b611:	00 00 00 00 00 
  66b616:	48 89 8c 24 e0 06 00 	mov    %rcx,0x6e0(%rsp)
  66b61d:	00 
  66b61e:	48 8b 78 10          	mov    0x10(%rax),%rdi
  66b622:	48 8b 70 18          	mov    0x18(%rax),%rsi
  66b626:	48 8b 92 f8 09 00 00 	mov    0x9f8(%rdx),%rdx
  66b62d:	48 39 fe             	cmp    %rdi,%rsi
  66b630:	0f 82 dc 29 00 00    	jb     66e012 <<gpui_canvas::text::planner::Planner>::shape+0x34b2>
  66b636:	48 39 d6             	cmp    %rdx,%rsi
  66b639:	0f 87 d3 29 00 00    	ja     66e012 <<gpui_canvas::text::planner::Planner>::shape+0x34b2>
  66b63f:	48 8b 04 24          	mov    (%rsp),%rax
  66b643:	48 8b 80 f0 09 00 00 	mov    0x9f0(%rax),%rax
  66b64a:	48 8d 0c bf          	lea    (%rdi,%rdi,4),%rcx
  66b64e:	48 8d 0c c8          	lea    (%rax,%rcx,8),%rcx
  66b652:	48 8d 14 b6          	lea    (%rsi,%rsi,4),%rdx
  66b656:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
  66b65a:	48 89 8c 24 00 07 00 	mov    %rcx,0x700(%rsp)
  66b661:	00 
  66b662:	48 89 84 24 08 07 00 	mov    %rax,0x708(%rsp)
  66b669:	00 
  66b66a:	48 c7 84 24 10 07 00 	movq   $0x0,0x710(%rsp)
  66b671:	00 00 00 00 00 
  66b676:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  66b67b:	48 89 84 24 18 07 00 	mov    %rax,0x718(%rsp)
  66b682:	00 
  66b683:	c7 84 24 20 07 00 00 	movl   $0x0,0x720(%rsp)
  66b68a:	00 00 00 00 
  66b68e:	48 8d bc 24 00 07 00 	lea    0x700(%rsp),%rdi
  66b695:	00 
  66b696:	48 8d b4 24 28 07 00 	lea    0x728(%rsp),%rsi
  66b69d:	00 
  66b69e:	48 8d 94 24 90 04 00 	lea    0x490(%rsp),%rdx
  66b6a5:	00 
  66b6a6:	e8 15 c2 ff ff       	call   6678c0 <<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}> as core::iter::traits::iterator::Iterator>::try_fold::<(), core::iter::adapters::filter_map::filter_map_try_fold<parley::layout::line::LineItem<()>, parley::layout::run::Run<()>, (), core::ops::control_flow::ControlFlow<()>, <parley::layout::line::Line<()>>::runs::{closure#0}, &mut core::iter::traits::iterator::Iterator::all::check<parley::layout::run::Run<()>, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#2}>::{closure#0}>::{closure#0}, core::ops::control_flow::ControlFlow<()>>>
  66b6ab:	48 c7 84 24 f0 06 00 	movq   $0x1,0x6f0(%rsp)
  66b6b2:	00 01 00 00 00 
  66b6b7:	84 c0                	test   %al,%al
  66b6b9:	75 45                	jne    66b700 <<gpui_canvas::text::planner::Planner>::shape+0xba0>
  66b6bb:	48 c7 84 24 00 07 00 	movq   $0x0,0x700(%rsp)
  66b6c2:	00 00 00 00 00 
  66b6c7:	48 83 bc 24 28 07 00 	cmpq   $0x0,0x728(%rsp)
  66b6ce:	00 00 
  66b6d0:	0f 84 af 1e 00 00    	je     66d585 <<gpui_canvas::text::planner::Planner>::shape+0x2a25>
  66b6d6:	48 8d bc 24 28 07 00 	lea    0x728(%rsp),%rdi
  66b6dd:	00 
  66b6de:	48 8d b4 24 50 07 00 	lea    0x750(%rsp),%rsi
  66b6e5:	00 
  66b6e6:	48 8d 94 24 90 04 00 	lea    0x490(%rsp),%rdx
  66b6ed:	00 
  66b6ee:	e8 cd c1 ff ff       	call   6678c0 <<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}> as core::iter::traits::iterator::Iterator>::try_fold::<(), core::iter::adapters::filter_map::filter_map_try_fold<parley::layout::line::LineItem<()>, parley::layout::run::Run<()>, (), core::ops::control_flow::ControlFlow<()>, <parley::layout::line::Line<()>>::runs::{closure#0}, &mut core::iter::traits::iterator::Iterator::all::check<parley::layout::run::Run<()>, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#2}>::{closure#0}>::{closure#0}, core::ops::control_flow::ControlFlow<()>>>
  66b6f3:	84 c0                	test   %al,%al
  66b6f5:	0f 84 8a 1e 00 00    	je     66d585 <<gpui_canvas::text::planner::Planner>::shape+0x2a25>
  66b6fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  66b700:	48 83 bc 24 68 01 00 	cmpq   $0xffffffffffffffff,0x168(%rsp)
  66b707:	00 ff 
  66b709:	0f 85 81 00 00 00    	jne    66b790 <<gpui_canvas::text::planner::Planner>::shape+0xc30>
  66b70f:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
  66b716:	48 c7 84 24 68 01 00 	movq   $0x0,0x168(%rsp)
  66b71d:	00 00 00 00 00 
  66b722:	48 c7 84 24 70 01 00 	movq   $0x4,0x170(%rsp)
  66b729:	00 04 00 00 00 
  66b72e:	48 8d 8c 24 70 01 00 	lea    0x170(%rsp),%rcx
  66b735:	00 
  66b736:	0f 57 c0             	xorps  %xmm0,%xmm0
  66b739:	0f 11 41 08          	movups %xmm0,0x8(%rcx)
  66b73d:	48 c7 84 24 88 01 00 	movq   $0x4,0x188(%rsp)
  66b744:	00 04 00 00 00 
  66b749:	48 c7 84 24 90 01 00 	movq   $0x0,0x190(%rsp)
  66b750:	00 00 00 00 00 
  66b755:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
  66b75c:	00 
  66b75d:	48 c7 84 24 a0 01 00 	movq   $0x4,0x1a0(%rsp)
  66b764:	00 04 00 00 00 
  66b769:	48 c7 84 24 a8 01 00 	movq   $0x0,0x1a8(%rsp)
  66b770:	00 00 00 00 00 
  66b775:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  66b77a:	89 84 24 b0 01 00 00 	mov    %eax,0x1b0(%rsp)
  66b781:	f3 0f 10 44 24 6c    	movss  0x6c(%rsp),%xmm0
  66b787:	f3 0f 11 84 24 b4 01 	movss  %xmm0,0x1b4(%rsp)
  66b78e:	00 00 
  66b790:	4c 89 7c 24 40       	mov    %r15,0x40(%rsp)
  66b795:	48 89 9c 24 90 00 00 	mov    %rbx,0x90(%rsp)
  66b79c:	00 
  66b79d:	48 8b 04 24          	mov    (%rsp),%rax
  66b7a1:	4c 8b b0 e0 09 00 00 	mov    0x9e0(%rax),%r14
  66b7a8:	4d 85 f6             	test   %r14,%r14
  66b7ab:	0f 84 ff 00 00 00    	je     66b8b0 <<gpui_canvas::text::planner::Planner>::shape+0xd50>
  66b7b1:	48 8b a8 d8 09 00 00 	mov    0x9d8(%rax),%rbp
  66b7b8:	45 31 ff             	xor    %r15d,%r15d
  66b7bb:	31 db                	xor    %ebx,%ebx
  66b7bd:	eb 0d                	jmp    66b7cc <<gpui_canvas::text::planner::Planner>::shape+0xc6c>
  66b7bf:	90                   	nop
  66b7c0:	49 ff c7             	inc    %r15
  66b7c3:	4d 39 f7             	cmp    %r14,%r15
  66b7c6:	0f 84 e6 00 00 00    	je     66b8b2 <<gpui_canvas::text::planner::Planner>::shape+0xd52>
  66b7cc:	49 6b c7 70          	imul   $0x70,%r15,%rax
  66b7d0:	48 01 e8             	add    %rbp,%rax
  66b7d3:	48 89 9c 24 e0 06 00 	mov    %rbx,0x6e0(%rsp)
  66b7da:	00 
  66b7db:	48 c7 84 24 e8 06 00 	movq   $0x0,0x6e8(%rsp)
  66b7e2:	00 00 00 00 00 
  66b7e7:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  66b7ec:	48 89 8c 24 f0 06 00 	mov    %rcx,0x6f0(%rsp)
  66b7f3:	00 
  66b7f4:	48 89 84 24 f8 06 00 	mov    %rax,0x6f8(%rsp)
  66b7fb:	00 
  66b7fc:	44 89 bc 24 00 07 00 	mov    %r15d,0x700(%rsp)
  66b803:	00 
  66b804:	c6 84 24 a8 07 00 00 	movb   $0x2,0x7a8(%rsp)
  66b80b:	02 
  66b80c:	c7 84 24 b0 07 00 00 	movl   $0x0,0x7b0(%rsp)
  66b813:	00 00 00 00 
  66b817:	48 8d bc 24 30 03 00 	lea    0x330(%rsp),%rdi
  66b81e:	00 
  66b81f:	48 8d b4 24 e8 06 00 	lea    0x6e8(%rsp),%rsi
  66b826:	00 
  66b827:	e8 34 59 00 00       	call   671160 <<parley::layout::line::GlyphRunIter<()> as core::iter::traits::iterator::Iterator>::next>
  66b82c:	83 bc 24 30 03 00 00 	cmpl   $0x1,0x330(%rsp)
  66b833:	01 
  66b834:	75 8a                	jne    66b7c0 <<gpui_canvas::text::planner::Planner>::shape+0xc60>
  66b836:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  66b83d:	00 00 00 
  66b840:	49 8b 45 38          	mov    0x38(%r13),%rax
  66b844:	49 89 44 24 40       	mov    %rax,0x40(%r12)
  66b849:	41 0f 10 45 f8       	movups -0x8(%r13),%xmm0
  66b84e:	41 0f 10 4d 08       	movups 0x8(%r13),%xmm1
  66b853:	41 0f 10 55 18       	movups 0x18(%r13),%xmm2
  66b858:	41 0f 10 5d 28       	movups 0x28(%r13),%xmm3
  66b85d:	41 0f 11 5c 24 30    	movups %xmm3,0x30(%r12)
  66b863:	41 0f 11 54 24 20    	movups %xmm2,0x20(%r12)
  66b869:	41 0f 11 4c 24 10    	movups %xmm1,0x10(%r12)
  66b86f:	41 0f 11 04 24       	movups %xmm0,(%r12)
  66b874:	48 89 9c 24 90 04 00 	mov    %rbx,0x490(%rsp)
  66b87b:	00 
  66b87c:	48 89 de             	mov    %rbx,%rsi
  66b87f:	4c 89 e2             	mov    %r12,%rdx
  66b882:	e8 69 c5 ff ff       	call   667df0 <<&mut core::iter::adapters::map::map_fold<parley::layout::line::PositionedLayoutItem<()>, usize, usize, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#5}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineData>>, <parley::layout::layout::Layout<()>>::lines::{closure#0}>, parley::layout::line::GlyphRunIter<()>, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#4}>, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#5}>>::{closure#0}>::{closure#0} as core::ops::function::FnMut<(usize, parley::layout::line::PositionedLayoutItem<()>)>>::call_mut>
  66b887:	48 89 c3             	mov    %rax,%rbx
  66b88a:	48 8d bc 24 30 03 00 	lea    0x330(%rsp),%rdi
  66b891:	00 
  66b892:	48 8d b4 24 e8 06 00 	lea    0x6e8(%rsp),%rsi
  66b899:	00 
  66b89a:	e8 c1 58 00 00       	call   671160 <<parley::layout::line::GlyphRunIter<()> as core::iter::traits::iterator::Iterator>::next>
  66b89f:	80 bc 24 30 03 00 00 	cmpb   $0x0,0x330(%rsp)
  66b8a6:	00 
  66b8a7:	75 97                	jne    66b840 <<gpui_canvas::text::planner::Planner>::shape+0xce0>
  66b8a9:	e9 12 ff ff ff       	jmp    66b7c0 <<gpui_canvas::text::planner::Planner>::shape+0xc60>
  66b8ae:	66 90                	xchg   %ax,%ax
  66b8b0:	31 db                	xor    %ebx,%ebx
  66b8b2:	48 8b b4 24 28 01 00 	mov    0x128(%rsp),%rsi
  66b8b9:	00 
  66b8ba:	48 89 f0             	mov    %rsi,%rax
  66b8bd:	48 01 d8             	add    %rbx,%rax
  66b8c0:	0f 92 c1             	setb   %cl
  66b8c3:	48 3d 01 80 00 00    	cmp    $0x8001,%rax
  66b8c9:	0f 93 c0             	setae  %al
  66b8cc:	08 c8                	or     %cl,%al
  66b8ce:	0f 85 09 1e 00 00    	jne    66d6dd <<gpui_canvas::text::planner::Planner>::shape+0x2b7d>
  66b8d4:	48 8b ac 24 90 00 00 	mov    0x90(%rsp),%rbp
  66b8db:	00 
  66b8dc:	4c 8b b4 24 b8 01 00 	mov    0x1b8(%rsp),%r14
  66b8e3:	00 
  66b8e4:	49 39 ee             	cmp    %rbp,%r14
  66b8e7:	4c 8b 7c 24 40       	mov    0x40(%rsp),%r15
  66b8ec:	74 14                	je     66b902 <<gpui_canvas::text::planner::Planner>::shape+0xda2>
  66b8ee:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
  66b8f5:	00 
  66b8f6:	48 29 f0             	sub    %rsi,%rax
  66b8f9:	48 39 c3             	cmp    %rax,%rbx
  66b8fc:	0f 87 bb 1d 00 00    	ja     66d6bd <<gpui_canvas::text::planner::Planner>::shape+0x2b5d>
  66b902:	48 85 ed             	test   %rbp,%rbp
  66b905:	74 26                	je     66b92d <<gpui_canvas::text::planner::Planner>::shape+0xdcd>
  66b907:	0f 57 c0             	xorps  %xmm0,%xmm0
  66b90a:	f3 0f 11 84 24 04 01 	movss  %xmm0,0x104(%rsp)
  66b911:	00 00 
  66b913:	49 39 ee             	cmp    %rbp,%r14
  66b916:	75 4b                	jne    66b963 <<gpui_canvas::text::planner::Planner>::shape+0xe03>
  66b918:	48 8b 0c 24          	mov    (%rsp),%rcx
  66b91c:	48 8b 81 e0 09 00 00 	mov    0x9e0(%rcx),%rax
  66b923:	48 85 c0             	test   %rax,%rax
  66b926:	75 7c                	jne    66b9a4 <<gpui_canvas::text::planner::Planner>::shape+0xe44>
  66b928:	e9 cc 14 00 00       	jmp    66cdf9 <<gpui_canvas::text::planner::Planner>::shape+0x2299>
  66b92d:	48 8b 04 24          	mov    (%rsp),%rax
  66b931:	48 83 b8 e0 09 00 00 	cmpq   $0x0,0x9e0(%rax)
  66b938:	00 
  66b939:	74 0e                	je     66b949 <<gpui_canvas::text::planner::Planner>::shape+0xde9>
  66b93b:	48 8b 80 d8 09 00 00 	mov    0x9d8(%rax),%rax
  66b942:	f3 0f 10 40 24       	movss  0x24(%rax),%xmm0
  66b947:	eb 03                	jmp    66b94c <<gpui_canvas::text::planner::Planner>::shape+0xdec>
  66b949:	0f 57 c0             	xorps  %xmm0,%xmm0
  66b94c:	f3 0f 11 44 24 64    	movss  %xmm0,0x64(%rsp)
  66b952:	0f 57 c0             	xorps  %xmm0,%xmm0
  66b955:	f3 0f 11 84 24 04 01 	movss  %xmm0,0x104(%rsp)
  66b95c:	00 00 
  66b95e:	49 39 ee             	cmp    %rbp,%r14
  66b961:	74 b5                	je     66b918 <<gpui_canvas::text::planner::Planner>::shape+0xdb8>
  66b963:	83 bc 24 d8 01 00 00 	cmpl   $0x0,0x1d8(%rsp)
  66b96a:	00 
  66b96b:	74 0e                	je     66b97b <<gpui_canvas::text::planner::Planner>::shape+0xe1b>
  66b96d:	48 8b 04 24          	mov    (%rsp),%rax
  66b971:	f3 0f 10 80 28 0a 00 	movss  0xa28(%rax),%xmm0
  66b978:	00 
  66b979:	eb 0c                	jmp    66b987 <<gpui_canvas::text::planner::Planner>::shape+0xe27>
  66b97b:	48 8b 04 24          	mov    (%rsp),%rax
  66b97f:	f3 0f 10 80 2c 0a 00 	movss  0xa2c(%rax),%xmm0
  66b986:	00 
  66b987:	f3 0f 11 84 24 04 01 	movss  %xmm0,0x104(%rsp)
  66b98e:	00 00 
  66b990:	48 8b 0c 24          	mov    (%rsp),%rcx
  66b994:	48 8b 81 e0 09 00 00 	mov    0x9e0(%rcx),%rax
  66b99b:	48 85 c0             	test   %rax,%rax
  66b99e:	0f 84 55 14 00 00    	je     66cdf9 <<gpui_canvas::text::planner::Planner>::shape+0x2299>
  66b9a4:	48 8b 89 d8 09 00 00 	mov    0x9d8(%rcx),%rcx
  66b9ab:	48 6b c0 70          	imul   $0x70,%rax,%rax
  66b9af:	48 89 8c 24 f8 00 00 	mov    %rcx,0xf8(%rsp)
  66b9b6:	00 
  66b9b7:	48 01 c8             	add    %rcx,%rax
  66b9ba:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
  66b9c1:	00 
  66b9c2:	c7 44 24 60 00 00 00 	movl   $0x0,0x60(%rsp)
  66b9c9:	00 
  66b9ca:	48 83 bc 24 68 01 00 	cmpq   $0xffffffffffffffff,0x168(%rsp)
  66b9d1:	00 ff 
  66b9d3:	74 2d                	je     66ba02 <<gpui_canvas::text::planner::Planner>::shape+0xea2>
  66b9d5:	49 39 ee             	cmp    %rbp,%r14
  66b9d8:	75 3b                	jne    66ba15 <<gpui_canvas::text::planner::Planner>::shape+0xeb5>
  66b9da:	45 31 f6             	xor    %r14d,%r14d
  66b9dd:	31 db                	xor    %ebx,%ebx
  66b9df:	48 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%rax
  66b9e6:	00 
  66b9e7:	48 8b 8c 24 90 01 00 	mov    0x190(%rsp),%rcx
  66b9ee:	00 
  66b9ef:	48 89 8c 24 60 02 00 	mov    %rcx,0x260(%rsp)
  66b9f6:	00 
  66b9f7:	80 78 68 02          	cmpb   $0x2,0x68(%rax)
  66b9fb:	74 41                	je     66ba3e <<gpui_canvas::text::planner::Planner>::shape+0xede>
  66b9fd:	e9 d4 01 00 00       	jmp    66bbd6 <<gpui_canvas::text::planner::Planner>::shape+0x1076>
  66ba02:	8b 4c 24 60          	mov    0x60(%rsp),%ecx
  66ba06:	89 c8                	mov    %ecx,%eax
  66ba08:	48 89 84 24 60 02 00 	mov    %rax,0x260(%rsp)
  66ba0f:	00 
  66ba10:	e9 e6 03 00 00       	jmp    66bdfb <<gpui_canvas::text::planner::Planner>::shape+0x129b>
  66ba15:	48 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%rax
  66ba1c:	00 
  66ba1d:	48 8b 18             	mov    (%rax),%rbx
  66ba20:	4c 8b 70 08          	mov    0x8(%rax),%r14
  66ba24:	48 8b 8c 24 90 01 00 	mov    0x190(%rsp),%rcx
  66ba2b:	00 
  66ba2c:	48 89 8c 24 60 02 00 	mov    %rcx,0x260(%rsp)
  66ba33:	00 
  66ba34:	80 78 68 02          	cmpb   $0x2,0x68(%rax)
  66ba38:	0f 85 98 01 00 00    	jne    66bbd6 <<gpui_canvas::text::planner::Planner>::shape+0x1076>
  66ba3e:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
  66ba43:	48 8b 78 10          	mov    0x10(%rax),%rdi
  66ba47:	48 8b 70 18          	mov    0x18(%rax),%rsi
  66ba4b:	48 8b 04 24          	mov    (%rsp),%rax
  66ba4f:	48 8b 90 f8 09 00 00 	mov    0x9f8(%rax),%rdx
  66ba56:	48 39 fe             	cmp    %rdi,%rsi
  66ba59:	0f 82 c5 25 00 00    	jb     66e024 <<gpui_canvas::text::planner::Planner>::shape+0x34c4>
  66ba5f:	48 39 d6             	cmp    %rdx,%rsi
  66ba62:	0f 87 bc 25 00 00    	ja     66e024 <<gpui_canvas::text::planner::Planner>::shape+0x34c4>
  66ba68:	48 8b 04 24          	mov    (%rsp),%rax
  66ba6c:	48 8b 80 f0 09 00 00 	mov    0x9f0(%rax),%rax
  66ba73:	48 8d 0c bf          	lea    (%rdi,%rdi,4),%rcx
  66ba77:	48 8d 0c c8          	lea    (%rax,%rcx,8),%rcx
  66ba7b:	48 8d 14 b6          	lea    (%rsi,%rsi,4),%rdx
  66ba7f:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
  66ba83:	48 89 8c 24 90 04 00 	mov    %rcx,0x490(%rsp)
  66ba8a:	00 
  66ba8b:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
  66ba92:	00 
  66ba93:	48 c7 84 24 a0 04 00 	movq   $0x0,0x4a0(%rsp)
  66ba9a:	00 00 00 00 00 
  66ba9f:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  66baa4:	48 89 84 24 a8 04 00 	mov    %rax,0x4a8(%rsp)
  66baab:	00 
  66baac:	8b 44 24 60          	mov    0x60(%rsp),%eax
  66bab0:	89 84 24 b0 04 00 00 	mov    %eax,0x4b0(%rsp)
  66bab7:	c6 84 24 d0 06 00 00 	movb   $0x2,0x6d0(%rsp)
  66babe:	02 
  66babf:	48 8d 84 24 d8 06 00 	lea    0x6d8(%rsp),%rax
  66bac6:	00 
  66bac7:	48 89 84 24 30 03 00 	mov    %rax,0x330(%rsp)
  66bace:	00 
  66bacf:	c6 84 24 c0 05 00 00 	movb   $0x2,0x5c0(%rsp)
  66bad6:	02 
  66bad7:	48 8d bc 24 e0 06 00 	lea    0x6e0(%rsp),%rdi
  66bade:	00 
  66badf:	48 8d b4 24 90 04 00 	lea    0x490(%rsp),%rsi
  66bae6:	00 
  66bae7:	48 8d 94 24 30 03 00 	lea    0x330(%rsp),%rdx
  66baee:	00 
  66baef:	48 8d 8c 24 b8 04 00 	lea    0x4b8(%rsp),%rcx
  66baf6:	00 
  66baf7:	e8 24 b5 ff ff       	call   667020 <<core::iter::adapters::map::Map<core::iter::adapters::filter_map::FilterMap<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}>, <parley::layout::line::Line<()>>::runs::{closure#0}>, gpui_canvas::text::planner::freeze_line::{closure#0}> as core::iter::traits::iterator::Iterator>::try_fold::<(), <core::iter::adapters::flatten::FlattenCompat<_, _>>::iter_try_fold::flatten<parley::layout::run::Clusters<()>, (), core::ops::control_flow::ControlFlow<parley::layout::cluster::Cluster<()>>, <core::iter::adapters::flatten::FlattenCompat<_, _> as core::iter::traits::iterator::Iterator>::try_fold::flatten<parley::layout::run::Clusters<()>, (), core::ops::control_flow::ControlFlow<parley::layout::cluster::Cluster<()>>, core::iter::traits::iterator::Iterator::find::check<parley::layout::cluster::Cluster<()>, &mut gpui_canvas::text::planner::freeze_line::{closure#1}>::{closure#0}>::{closure#0}>::{closure#0}, core::ops::control_flow::ControlFlow<parley::layout::cluster::Cluster<()>>>>
  66bafc:	48 8b 8c 24 e0 06 00 	mov    0x6e0(%rsp),%rcx
  66bb03:	00 
  66bb04:	48 85 c9             	test   %rcx,%rcx
  66bb07:	0f 84 b2 00 00 00    	je     66bbbf <<gpui_canvas::text::planner::Planner>::shape+0x105f>
  66bb0d:	8b bc 24 08 07 00 00 	mov    0x708(%rsp),%edi
  66bb14:	8b b4 24 60 07 00 00 	mov    0x760(%rsp),%esi
  66bb1b:	8b 94 24 64 07 00 00 	mov    0x764(%rsp),%edx
  66bb22:	48 8b 41 58          	mov    0x58(%rcx),%rax
  66bb26:	48 39 f8             	cmp    %rdi,%rax
  66bb29:	0f 86 33 26 00 00    	jbe    66e162 <<gpui_canvas::text::planner::Planner>::shape+0x3602>
  66bb2f:	48 8b 41 50          	mov    0x50(%rcx),%rax
  66bb33:	48 8d 3c ff          	lea    (%rdi,%rdi,8),%rdi
  66bb37:	48 c1 e7 04          	shl    $0x4,%rdi
  66bb3b:	0f 10 41 68          	movups 0x68(%rcx),%xmm0
  66bb3f:	0f 10 89 80 00 00 00 	movups 0x80(%rcx),%xmm1
  66bb46:	0f 10 91 98 00 00 00 	movups 0x98(%rcx),%xmm2
  66bb4d:	0f 11 84 24 e0 06 00 	movups %xmm0,0x6e0(%rsp)
  66bb54:	00 
  66bb55:	0f 11 8c 24 f0 06 00 	movups %xmm1,0x6f0(%rsp)
  66bb5c:	00 
  66bb5d:	0f 11 94 24 00 07 00 	movups %xmm2,0x700(%rsp)
  66bb64:	00 
  66bb65:	48 8b 44 38 50       	mov    0x50(%rax,%rdi,1),%rax
  66bb6a:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
  66bb71:	00 
  66bb72:	48 8d bc 24 e0 06 00 	lea    0x6e0(%rsp),%rdi
  66bb79:	00 
  66bb7a:	ff 15 d8 f0 11 00    	call   *0x11f0d8(%rip)        # 78ac58 <_DYNAMIC+0x5d0>
  66bb80:	48 89 c3             	mov    %rax,%rbx
  66bb83:	ba 48 02 00 00       	mov    $0x248,%edx
  66bb88:	4c 8d bc 24 e0 06 00 	lea    0x6e0(%rsp),%r15
  66bb8f:	00 
  66bb90:	4c 89 ff             	mov    %r15,%rdi
  66bb93:	48 8d b4 24 90 04 00 	lea    0x490(%rsp),%rsi
  66bb9a:	00 
  66bb9b:	ff 15 b7 ed 11 00    	call   *0x11edb7(%rip)        # 78a958 <memcpy@GLIBC_2.14>
  66bba1:	4c 89 ff             	mov    %r15,%rdi
  66bba4:	4c 8b 7c 24 40       	mov    0x40(%rsp),%r15
  66bba9:	48 89 de             	mov    %rbx,%rsi
  66bbac:	e8 4f b7 ff ff       	call   667300 <<core::iter::adapters::map::Map<core::iter::adapters::filter::Filter<core::iter::adapters::flatten::FlatMap<core::iter::adapters::filter_map::FilterMap<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}>, <parley::layout::line::Line<()>>::runs::{closure#0}>, parley::layout::run::Clusters<()>, gpui_canvas::text::planner::freeze_line::{closure#0}>, gpui_canvas::text::planner::freeze_line::{closure#1}>, gpui_canvas::text::planner::freeze_line::{closure#2}> as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::traits::iterator::Iterator::min_by::fold<usize, <usize as core::cmp::Ord>::cmp>::{closure#0}>>
  66bbb1:	4c 39 f0             	cmp    %r14,%rax
  66bbb4:	4c 0f 42 f0          	cmovb  %rax,%r14
  66bbb8:	48 8b 5c 24 20       	mov    0x20(%rsp),%rbx
  66bbbd:	eb 17                	jmp    66bbd6 <<gpui_canvas::text::planner::Planner>::shape+0x1076>
  66bbbf:	80 bc 24 d0 06 00 00 	cmpb   $0x2,0x6d0(%rsp)
  66bbc6:	02 
  66bbc7:	c6 84 24 c0 05 00 00 	movb   $0x2,0x5c0(%rsp)
  66bbce:	02 
  66bbcf:	48 8b 5c 24 20       	mov    0x20(%rsp),%rbx
  66bbd4:	75 32                	jne    66bc08 <<gpui_canvas::text::planner::Planner>::shape+0x10a8>
  66bbd6:	4c 39 f3             	cmp    %r14,%rbx
  66bbd9:	0f 87 d9 1e 00 00    	ja     66dab8 <<gpui_canvas::text::planner::Planner>::shape+0x2f58>
  66bbdf:	48 85 db             	test   %rbx,%rbx
  66bbe2:	0f 84 b9 00 00 00    	je     66bca1 <<gpui_canvas::text::planner::Planner>::shape+0x1141>
  66bbe8:	4c 39 fb             	cmp    %r15,%rbx
  66bbeb:	0f 83 aa 00 00 00    	jae    66bc9b <<gpui_canvas::text::planner::Planner>::shape+0x113b>
  66bbf1:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  66bbf8:	00 
  66bbf9:	80 3c 18 bf          	cmpb   $0xbf,(%rax,%rbx,1)
  66bbfd:	0f 8f 9e 00 00 00    	jg     66bca1 <<gpui_canvas::text::planner::Planner>::shape+0x1141>
  66bc03:	e9 b0 1e 00 00       	jmp    66dab8 <<gpui_canvas::text::planner::Planner>::shape+0x2f58>
  66bc08:	48 8d bc 24 e0 06 00 	lea    0x6e0(%rsp),%rdi
  66bc0f:	00 
  66bc10:	48 8d b4 24 c8 05 00 	lea    0x5c8(%rsp),%rsi
  66bc17:	00 
  66bc18:	e8 f3 4d 00 00       	call   670a10 <<parley::layout::run::Clusters<()>>::advance_cursor>
  66bc1d:	83 bc 24 e0 06 00 00 	cmpl   $0x1,0x6e0(%rsp)
  66bc24:	01 
  66bc25:	75 af                	jne    66bbd6 <<gpui_canvas::text::planner::Planner>::shape+0x1076>
  66bc27:	48 83 bc 24 80 06 00 	cmpq   $0x0,0x680(%rsp)
  66bc2e:	00 00 
  66bc30:	0f 84 00 24 00 00    	je     66e036 <<gpui_canvas::text::planner::Planner>::shape+0x34d6>
  66bc36:	48 8b 8c 24 c8 05 00 	mov    0x5c8(%rsp),%rcx
  66bc3d:	00 
  66bc3e:	48 85 c9             	test   %rcx,%rcx
  66bc41:	74 93                	je     66bbd6 <<gpui_canvas::text::planner::Planner>::shape+0x1076>
  66bc43:	8b bc 24 f0 05 00 00 	mov    0x5f0(%rsp),%edi
  66bc4a:	48 8b 41 58          	mov    0x58(%rcx),%rax
  66bc4e:	48 39 f8             	cmp    %rdi,%rax
  66bc51:	0f 86 9b 24 00 00    	jbe    66e0f2 <<gpui_canvas::text::planner::Planner>::shape+0x3592>
  66bc57:	8b b4 24 e4 06 00 00 	mov    0x6e4(%rsp),%esi
  66bc5e:	8b 94 24 e8 06 00 00 	mov    0x6e8(%rsp),%edx
  66bc65:	4c 8b 41 70          	mov    0x70(%rcx),%r8
  66bc69:	39 f2                	cmp    %esi,%edx
  66bc6b:	0f 82 86 23 00 00    	jb     66dff7 <<gpui_canvas::text::planner::Planner>::shape+0x3497>
  66bc71:	49 39 d0             	cmp    %rdx,%r8
  66bc74:	0f 82 7d 23 00 00    	jb     66dff7 <<gpui_canvas::text::planner::Planner>::shape+0x3497>
  66bc7a:	39 f2                	cmp    %esi,%edx
  66bc7c:	0f 84 81 24 00 00    	je     66e103 <<gpui_canvas::text::planner::Planner>::shape+0x35a3>
  66bc82:	4c 8b 41 68          	mov    0x68(%rcx),%r8
  66bc86:	4c 8d 0c 76          	lea    (%rsi,%rsi,2),%r9
  66bc8a:	43 80 7c 88 07 06    	cmpb   $0x6,0x7(%r8,%r9,4)
  66bc90:	0f 85 72 ff ff ff    	jne    66bc08 <<gpui_canvas::text::planner::Planner>::shape+0x10a8>
  66bc96:	e9 8b fe ff ff       	jmp    66bb26 <<gpui_canvas::text::planner::Planner>::shape+0xfc6>
  66bc9b:	0f 85 17 1e 00 00    	jne    66dab8 <<gpui_canvas::text::planner::Planner>::shape+0x2f58>
  66bca1:	4d 85 f6             	test   %r14,%r14
  66bca4:	74 1f                	je     66bcc5 <<gpui_canvas::text::planner::Planner>::shape+0x1165>
  66bca6:	4d 39 fe             	cmp    %r15,%r14
  66bca9:	73 14                	jae    66bcbf <<gpui_canvas::text::planner::Planner>::shape+0x115f>
  66bcab:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  66bcb2:	00 
  66bcb3:	42 80 3c 30 c0       	cmpb   $0xc0,(%rax,%r14,1)
  66bcb8:	7d 0b                	jge    66bcc5 <<gpui_canvas::text::planner::Planner>::shape+0x1165>
  66bcba:	e9 f9 1d 00 00       	jmp    66dab8 <<gpui_canvas::text::planner::Planner>::shape+0x2f58>
  66bcbf:	0f 85 f3 1d 00 00    	jne    66dab8 <<gpui_canvas::text::planner::Planner>::shape+0x2f58>
  66bcc5:	49 89 df             	mov    %rbx,%r15
  66bcc8:	0f 57 c0             	xorps  %xmm0,%xmm0
  66bccb:	48 39 ac 24 b8 01 00 	cmp    %rbp,0x1b8(%rsp)
  66bcd2:	00 
  66bcd3:	74 0d                	je     66bce2 <<gpui_canvas::text::planner::Planner>::shape+0x1182>
  66bcd5:	48 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%rax
  66bcdc:	00 
  66bcdd:	f3 0f 10 40 30       	movss  0x30(%rax),%xmm0
  66bce2:	f3 0f 11 44 24 20    	movss  %xmm0,0x20(%rsp)
  66bce8:	48 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%rax
  66bcef:	00 
  66bcf0:	f3 0f 10 48 40       	movss  0x40(%rax),%xmm1
  66bcf5:	f3 0f 10 40 44       	movss  0x44(%rax),%xmm0
  66bcfa:	0f 29 8c 24 f0 01 00 	movaps %xmm1,0x1f0(%rsp)
  66bd01:	00 
  66bd02:	f3 0f 5d 48 48       	minss  0x48(%rax),%xmm1
  66bd07:	0f 29 8c 24 d0 00 00 	movaps %xmm1,0xd0(%rsp)
  66bd0e:	00 
  66bd0f:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
  66bd16:	00 
  66bd17:	f3 0f 5f 40 4c       	maxss  0x4c(%rax),%xmm0
  66bd1c:	0f 29 84 24 30 01 00 	movaps %xmm0,0x130(%rsp)
  66bd23:	00 
  66bd24:	f3 0f 10 40 24       	movss  0x24(%rax),%xmm0
  66bd29:	f3 0f 58 44 24 0c    	addss  0xc(%rsp),%xmm0
  66bd2f:	f3 0f 11 44 24 70    	movss  %xmm0,0x70(%rsp)
  66bd35:	48 8b 9c 24 90 01 00 	mov    0x190(%rsp),%rbx
  66bd3c:	00 
  66bd3d:	48 3b 9c 24 80 01 00 	cmp    0x180(%rsp),%rbx
  66bd44:	00 
  66bd45:	75 0e                	jne    66bd55 <<gpui_canvas::text::planner::Planner>::shape+0x11f5>
  66bd47:	48 8d bc 24 80 01 00 	lea    0x180(%rsp),%rdi
  66bd4e:	00 
  66bd4f:	ff 15 43 ee 11 00    	call   *0x11ee43(%rip)        # 78ab98 <_DYNAMIC+0x510>
  66bd55:	41 01 ef             	add    %ebp,%r15d
  66bd58:	41 01 ee             	add    %ebp,%r14d
  66bd5b:	0f 28 94 24 d0 00 00 	movaps 0xd0(%rsp),%xmm2
  66bd62:	00 
  66bd63:	0f 28 c2             	movaps %xmm2,%xmm0
  66bd66:	f3 0f c2 c2 03       	cmpunordss %xmm2,%xmm0
  66bd6b:	0f 28 c8             	movaps %xmm0,%xmm1
  66bd6e:	0f 55 ca             	andnps %xmm2,%xmm1
  66bd71:	0f 54 84 24 f0 01 00 	andps  0x1f0(%rsp),%xmm0
  66bd78:	00 
  66bd79:	0f 56 c1             	orps   %xmm1,%xmm0
  66bd7c:	f3 0f 10 4c 24 0c    	movss  0xc(%rsp),%xmm1
  66bd82:	f3 0f 58 c8          	addss  %xmm0,%xmm1
  66bd86:	0f 28 a4 24 30 01 00 	movaps 0x130(%rsp),%xmm4
  66bd8d:	00 
  66bd8e:	0f 28 d4             	movaps %xmm4,%xmm2
  66bd91:	f3 0f c2 d4 03       	cmpunordss %xmm4,%xmm2
  66bd96:	0f 28 da             	movaps %xmm2,%xmm3
  66bd99:	0f 55 dc             	andnps %xmm4,%xmm3
  66bd9c:	0f 54 94 24 e0 00 00 	andps  0xe0(%rsp),%xmm2
  66bda3:	00 
  66bda4:	0f 56 d3             	orps   %xmm3,%xmm2
  66bda7:	f3 0f 5c d0          	subss  %xmm0,%xmm2
  66bdab:	48 8b 84 24 88 01 00 	mov    0x188(%rsp),%rax
  66bdb2:	00 
  66bdb3:	48 8d 0c 5b          	lea    (%rbx,%rbx,2),%rcx
  66bdb7:	44 89 3c c8          	mov    %r15d,(%rax,%rcx,8)
  66bdbb:	44 89 74 c8 04       	mov    %r14d,0x4(%rax,%rcx,8)
  66bdc0:	f3 0f 11 4c c8 08    	movss  %xmm1,0x8(%rax,%rcx,8)
  66bdc6:	f3 0f 11 54 c8 0c    	movss  %xmm2,0xc(%rax,%rcx,8)
  66bdcc:	f3 0f 10 44 24 70    	movss  0x70(%rsp),%xmm0
  66bdd2:	f3 0f 11 44 c8 10    	movss  %xmm0,0x10(%rax,%rcx,8)
  66bdd8:	f3 0f 10 44 24 20    	movss  0x20(%rsp),%xmm0
  66bdde:	f3 0f 11 44 c8 14    	movss  %xmm0,0x14(%rax,%rcx,8)
  66bde4:	48 ff c3             	inc    %rbx
  66bde7:	48 89 9c 24 90 01 00 	mov    %rbx,0x190(%rsp)
  66bdee:	00 
  66bdef:	44 89 b4 24 24 02 00 	mov    %r14d,0x224(%rsp)
  66bdf6:	00 
  66bdf7:	8b 4c 24 60          	mov    0x60(%rsp),%ecx
  66bdfb:	48 c7 84 24 e0 06 00 	movq   $0x0,0x6e0(%rsp)
  66be02:	00 00 00 00 00 
  66be07:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  66be0c:	48 89 84 24 e8 06 00 	mov    %rax,0x6e8(%rsp)
  66be13:	00 
  66be14:	48 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%rax
  66be1b:	00 
  66be1c:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
  66be23:	00 
  66be24:	48 83 c0 70          	add    $0x70,%rax
  66be28:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
  66be2f:	00 
  66be30:	89 8c 24 f8 06 00 00 	mov    %ecx,0x6f8(%rsp)
  66be37:	ff c1                	inc    %ecx
  66be39:	89 4c 24 60          	mov    %ecx,0x60(%rsp)
  66be3d:	c6 84 24 a0 07 00 00 	movb   $0x2,0x7a0(%rsp)
  66be44:	02 
  66be45:	c7 84 24 a8 07 00 00 	movl   $0x0,0x7a8(%rsp)
  66be4c:	00 00 00 00 
  66be50:	48 8d bc 24 30 03 00 	lea    0x330(%rsp),%rdi
  66be57:	00 
  66be58:	48 8d b4 24 e0 06 00 	lea    0x6e0(%rsp),%rsi
  66be5f:	00 
  66be60:	e8 fb 52 00 00       	call   671160 <<parley::layout::line::GlyphRunIter<()> as core::iter::traits::iterator::Iterator>::next>
  66be65:	83 bc 24 30 03 00 00 	cmpl   $0x1,0x330(%rsp)
  66be6c:	01 
  66be6d:	0f 85 5b 0f 00 00    	jne    66cdce <<gpui_canvas::text::planner::Planner>::shape+0x226e>
  66be73:	48 8b 84 24 38 03 00 	mov    0x338(%rsp),%rax
  66be7a:	00 
  66be7b:	48 85 c0             	test   %rax,%rax
  66be7e:	0f 84 24 1c 00 00    	je     66daa8 <<gpui_canvas::text::planner::Planner>::shape+0x2f48>
  66be84:	48 89 84 24 80 03 00 	mov    %rax,0x380(%rsp)
  66be8b:	00 
  66be8c:	41 0f 10 45 00       	movups 0x0(%r13),%xmm0
  66be91:	41 0f 10 4d 10       	movups 0x10(%r13),%xmm1
  66be96:	41 0f 10 55 20       	movups 0x20(%r13),%xmm2
  66be9b:	41 0f 10 5d 30       	movups 0x30(%r13),%xmm3
  66bea0:	48 8d 8c 24 88 03 00 	lea    0x388(%rsp),%rcx
  66bea7:	00 
  66bea8:	0f 11 59 30          	movups %xmm3,0x30(%rcx)
  66beac:	0f 11 51 20          	movups %xmm2,0x20(%rcx)
  66beb0:	0f 11 49 10          	movups %xmm1,0x10(%rcx)
  66beb4:	0f 11 01             	movups %xmm0,(%rcx)
  66beb7:	48 8b 8c 24 88 03 00 	mov    0x388(%rsp),%rcx
  66bebe:	00 
  66bebf:	48 8b 51 30          	mov    0x30(%rcx),%rdx
  66bec3:	48 8b 79 38          	mov    0x38(%rcx),%rdi
  66bec7:	48 89 fe             	mov    %rdi,%rsi
  66beca:	48 29 d6             	sub    %rdx,%rsi
  66becd:	41 0f 92 c0          	setb   %r8b
  66bed1:	48 3b b8 d0 00 00 00 	cmp    0xd0(%rax),%rdi
  66bed8:	40 0f 97 c7          	seta   %dil
  66bedc:	48 01 d2             	add    %rdx,%rdx
  66bedf:	48 03 90 c8 00 00 00 	add    0xc8(%rax),%rdx
  66bee6:	44 08 c7             	or     %r8b,%dil
  66bee9:	40 84 ff             	test   %dil,%dil
  66beec:	bf 00 00 00 00       	mov    $0x0,%edi
  66bef1:	48 0f 45 f7          	cmovne %rdi,%rsi
  66bef5:	bf 02 00 00 00       	mov    $0x2,%edi
  66befa:	48 0f 45 d7          	cmovne %rdi,%rdx
  66befe:	48 01 f6             	add    %rsi,%rsi
  66bf01:	31 ff                	xor    %edi,%edi
  66bf03:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  66bf0a:	84 00 00 00 00 00 
  66bf10:	48 39 fe             	cmp    %rdi,%rsi
  66bf13:	74 10                	je     66bf25 <<gpui_canvas::text::planner::Planner>::shape+0x13c5>
  66bf15:	66 83 3c 3a 00       	cmpw   $0x0,(%rdx,%rdi,1)
  66bf1a:	48 8d 7f 02          	lea    0x2(%rdi),%rdi
  66bf1e:	74 f0                	je     66bf10 <<gpui_canvas::text::planner::Planner>::shape+0x13b0>
  66bf20:	e9 c5 17 00 00       	jmp    66d6ea <<gpui_canvas::text::planner::Planner>::shape+0x2b8a>
  66bf25:	48 8b 51 40          	mov    0x40(%rcx),%rdx
  66bf29:	48 3b 90 b8 00 00 00 	cmp    0xb8(%rax),%rdx
  66bf30:	0f 83 1e 21 00 00    	jae    66e054 <<gpui_canvas::text::planner::Planner>::shape+0x34f4>
  66bf36:	48 c1 e2 06          	shl    $0x6,%rdx
  66bf3a:	48 03 90 b0 00 00 00 	add    0xb0(%rax),%rdx
  66bf41:	48 8b 3c 24          	mov    (%rsp),%rdi
  66bf45:	83 3f 01             	cmpl   $0x1,(%rdi)
  66bf48:	75 0f                	jne    66bf59 <<gpui_canvas::text::planner::Planner>::shape+0x13f9>
  66bf4a:	48 8b 77 08          	mov    0x8(%rdi),%rsi
  66bf4e:	48 3b 72 10          	cmp    0x10(%rdx),%rsi
  66bf52:	75 05                	jne    66bf59 <<gpui_canvas::text::planner::Planner>::shape+0x13f9>
  66bf54:	45 31 f6             	xor    %r14d,%r14d
  66bf57:	eb 4c                	jmp    66bfa5 <<gpui_canvas::text::planner::Planner>::shape+0x1445>
  66bf59:	83 7f 10 01          	cmpl   $0x1,0x10(%rdi)
  66bf5d:	75 10                	jne    66bf6f <<gpui_canvas::text::planner::Planner>::shape+0x140f>
  66bf5f:	48 8b 77 18          	mov    0x18(%rdi),%rsi
  66bf63:	41 be 01 00 00 00    	mov    $0x1,%r14d
  66bf69:	48 3b 72 10          	cmp    0x10(%rdx),%rsi
  66bf6d:	74 1e                	je     66bf8d <<gpui_canvas::text::planner::Planner>::shape+0x142d>
  66bf6f:	83 7f 20 01          	cmpl   $0x1,0x20(%rdi)
  66bf73:	0f 85 5d 1b 00 00    	jne    66dad6 <<gpui_canvas::text::planner::Planner>::shape+0x2f76>
  66bf79:	48 8b 77 28          	mov    0x28(%rdi),%rsi
  66bf7d:	41 be 02 00 00 00    	mov    $0x2,%r14d
  66bf83:	48 3b 72 10          	cmp    0x10(%rdx),%rsi
  66bf87:	0f 85 49 1b 00 00    	jne    66dad6 <<gpui_canvas::text::planner::Planner>::shape+0x2f76>
  66bf8d:	41 8d 56 ff          	lea    -0x1(%r14),%edx
  66bf91:	48 8b b4 24 10 02 00 	mov    0x210(%rsp),%rsi
  66bf98:	00 
  66bf99:	48 0f ab d6          	bts    %rdx,%rsi
  66bf9d:	48 89 b4 24 10 02 00 	mov    %rsi,0x210(%rsp)
  66bfa4:	00 
  66bfa5:	8b bc 24 a8 03 00 00 	mov    0x3a8(%rsp),%edi
  66bfac:	48 8b 70 58          	mov    0x58(%rax),%rsi
  66bfb0:	48 39 fe             	cmp    %rdi,%rsi
  66bfb3:	0f 86 61 21 00 00    	jbe    66e11a <<gpui_canvas::text::planner::Planner>::shape+0x35ba>
  66bfb9:	48 8b 94 24 98 03 00 	mov    0x398(%rsp),%rdx
  66bfc0:	00 
  66bfc1:	48 85 d2             	test   %rdx,%rdx
  66bfc4:	74 0a                	je     66bfd0 <<gpui_canvas::text::planner::Planner>::shape+0x1470>
  66bfc6:	48 8d 72 18          	lea    0x18(%rdx),%rsi
  66bfca:	48 83 c2 1c          	add    $0x1c,%rdx
  66bfce:	eb 1b                	jmp    66bfeb <<gpui_canvas::text::planner::Planner>::shape+0x148b>
  66bfd0:	48 8b 70 50          	mov    0x50(%rax),%rsi
  66bfd4:	48 8d 3c ff          	lea    (%rdi,%rdi,8),%rdi
  66bfd8:	48 c1 e7 04          	shl    $0x4,%rdi
  66bfdc:	48 8d 14 3e          	lea    (%rsi,%rdi,1),%rdx
  66bfe0:	48 83 c2 54          	add    $0x54,%rdx
  66bfe4:	48 01 fe             	add    %rdi,%rsi
  66bfe7:	48 83 c6 50          	add    $0x50,%rsi
  66bfeb:	48 8b bc 24 28 01 00 	mov    0x128(%rsp),%rdi
  66bff2:	00 
  66bff3:	48 89 bc 24 e8 02 00 	mov    %rdi,0x2e8(%rsp)
  66bffa:	00 
  66bffb:	48 8b 78 68          	mov    0x68(%rax),%rdi
  66bfff:	4c 8b 40 70          	mov    0x70(%rax),%r8
  66c003:	4c 8b 88 80 00 00 00 	mov    0x80(%rax),%r9
  66c00a:	4c 8b 90 88 00 00 00 	mov    0x88(%rax),%r10
  66c011:	4c 8b 98 98 00 00 00 	mov    0x98(%rax),%r11
  66c018:	48 8b 80 a0 00 00 00 	mov    0xa0(%rax),%rax
  66c01f:	8b 12                	mov    (%rdx),%edx
  66c021:	8b 36                	mov    (%rsi),%esi
  66c023:	0f b6 89 8c 00 00 00 	movzbl 0x8c(%rcx),%ecx
  66c02a:	80 e1 01             	and    $0x1,%cl
  66c02d:	89 d3                	mov    %edx,%ebx
  66c02f:	29 f3                	sub    %esi,%ebx
  66c031:	48 c7 84 24 90 04 00 	movq   $0x0,0x490(%rsp)
  66c038:	00 00 00 00 00 
  66c03d:	48 c7 84 24 b0 04 00 	movq   $0x0,0x4b0(%rsp)
  66c044:	00 00 00 00 00 
  66c049:	c7 84 24 d0 04 00 00 	movl   $0x0,0x4d0(%rsp)
  66c050:	00 00 00 00 
  66c054:	89 9c 24 d4 04 00 00 	mov    %ebx,0x4d4(%rsp)
  66c05b:	48 89 bc 24 d8 04 00 	mov    %rdi,0x4d8(%rsp)
  66c062:	00 
  66c063:	4c 89 84 24 e0 04 00 	mov    %r8,0x4e0(%rsp)
  66c06a:	00 
  66c06b:	4c 89 8c 24 e8 04 00 	mov    %r9,0x4e8(%rsp)
  66c072:	00 
  66c073:	4c 89 94 24 f0 04 00 	mov    %r10,0x4f0(%rsp)
  66c07a:	00 
  66c07b:	4c 89 9c 24 f8 04 00 	mov    %r11,0x4f8(%rsp)
  66c082:	00 
  66c083:	48 89 84 24 00 05 00 	mov    %rax,0x500(%rsp)
  66c08a:	00 
  66c08b:	89 b4 24 08 05 00 00 	mov    %esi,0x508(%rsp)
  66c092:	89 94 24 0c 05 00 00 	mov    %edx,0x50c(%rsp)
  66c099:	89 b4 24 10 05 00 00 	mov    %esi,0x510(%rsp)
  66c0a0:	89 94 24 14 05 00 00 	mov    %edx,0x514(%rsp)
  66c0a7:	88 8c 24 18 05 00 00 	mov    %cl,0x518(%rsp)
  66c0ae:	48 8d bc 24 c8 03 00 	lea    0x3c8(%rsp),%rdi
  66c0b5:	00 
  66c0b6:	48 8d b4 24 80 03 00 	lea    0x380(%rsp),%rsi
  66c0bd:	00 
  66c0be:	e8 8d 43 00 00       	call   670450 <<parley::layout::line::GlyphRun<()>>::positioned_glyphs>
  66c0c3:	48 8b 9c 24 c8 03 00 	mov    0x3c8(%rsp),%rbx
  66c0ca:	00 
  66c0cb:	48 8b 84 24 d0 03 00 	mov    0x3d0(%rsp),%rax
  66c0d2:	00 
  66c0d3:	48 89 84 24 f0 00 00 	mov    %rax,0xf0(%rsp)
  66c0da:	00 
  66c0db:	0f b6 84 24 d8 03 00 	movzbl 0x3d8(%rsp),%eax
  66c0e2:	00 
  66c0e3:	8b 8c 24 dc 03 00 00 	mov    0x3dc(%rsp),%ecx
  66c0ea:	89 8c 24 cc 01 00 00 	mov    %ecx,0x1cc(%rsp)
  66c0f1:	f2 0f 10 84 24 e0 03 	movsd  0x3e0(%rsp),%xmm0
  66c0f8:	00 00 
  66c0fa:	0f 29 84 24 40 02 00 	movaps %xmm0,0x240(%rsp)
  66c101:	00 
  66c102:	f3 0f 10 84 24 e8 03 	movss  0x3e8(%rsp),%xmm0
  66c109:	00 00 
  66c10b:	f3 0f 11 84 24 c8 01 	movss  %xmm0,0x1c8(%rsp)
  66c112:	00 00 
  66c114:	48 8b 8c 24 f0 03 00 	mov    0x3f0(%rsp),%rcx
  66c11b:	00 
  66c11c:	48 89 8c 24 80 02 00 	mov    %rcx,0x280(%rsp)
  66c123:	00 
  66c124:	48 8b 8c 24 f8 03 00 	mov    0x3f8(%rsp),%rcx
  66c12b:	00 
  66c12c:	48 89 8c 24 08 02 00 	mov    %rcx,0x208(%rsp)
  66c133:	00 
  66c134:	48 8b 94 24 00 04 00 	mov    0x400(%rsp),%rdx
  66c13b:	00 
  66c13c:	48 8b 8c 24 08 04 00 	mov    0x408(%rsp),%rcx
  66c143:	00 
  66c144:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  66c149:	48 8b b4 24 10 04 00 	mov    0x410(%rsp),%rsi
  66c150:	00 
  66c151:	48 8b 8c 24 18 04 00 	mov    0x418(%rsp),%rcx
  66c158:	00 
  66c159:	48 89 8c 24 50 01 00 	mov    %rcx,0x150(%rsp)
  66c160:	00 
  66c161:	8b 8c 24 20 04 00 00 	mov    0x420(%rsp),%ecx
  66c168:	48 89 8c 24 70 02 00 	mov    %rcx,0x270(%rsp)
  66c16f:	00 
  66c170:	8b 8c 24 24 04 00 00 	mov    0x424(%rsp),%ecx
  66c177:	48 89 8c 24 78 02 00 	mov    %rcx,0x278(%rsp)
  66c17e:	00 
  66c17f:	8b 8c 24 28 04 00 00 	mov    0x428(%rsp),%ecx
  66c186:	48 89 8c 24 d0 00 00 	mov    %rcx,0xd0(%rsp)
  66c18d:	00 
  66c18e:	8b 8c 24 2c 04 00 00 	mov    0x42c(%rsp),%ecx
  66c195:	48 89 4c 24 70       	mov    %rcx,0x70(%rsp)
  66c19a:	f3 0f 10 84 24 30 04 	movss  0x430(%rsp),%xmm0
  66c1a1:	00 00 
  66c1a3:	f3 0f 11 84 24 d0 01 	movss  %xmm0,0x1d0(%rsp)
  66c1aa:	00 00 
  66c1ac:	f3 0f 10 84 24 34 04 	movss  0x434(%rsp),%xmm0
  66c1b3:	00 00 
  66c1b5:	f3 0f 11 44 24 50    	movss  %xmm0,0x50(%rsp)
  66c1bb:	48 8b 8c 24 38 04 00 	mov    0x438(%rsp),%rcx
  66c1c2:	00 
  66c1c3:	48 89 8c 24 e0 00 00 	mov    %rcx,0xe0(%rsp)
  66c1ca:	00 
  66c1cb:	f3 0f 10 84 24 50 04 	movss  0x450(%rsp),%xmm0
  66c1d2:	00 00 
  66c1d4:	f3 0f 10 94 24 60 04 	movss  0x460(%rsp),%xmm2
  66c1db:	00 00 
  66c1dd:	f3 0f 10 8c 24 64 04 	movss  0x464(%rsp),%xmm1
  66c1e4:	00 00 
  66c1e6:	f3 0f 11 8c 24 38 02 	movss  %xmm1,0x238(%rsp)
  66c1ed:	00 00 
  66c1ef:	f3 0f 10 8c 24 4c 04 	movss  0x44c(%rsp),%xmm1
  66c1f6:	00 00 
  66c1f8:	f3 0f 11 84 24 34 02 	movss  %xmm0,0x234(%rsp)
  66c1ff:	00 00 
  66c201:	f3 0f 58 c8          	addss  %xmm0,%xmm1
  66c205:	f3 0f 10 84 24 54 04 	movss  0x454(%rsp),%xmm0
  66c20c:	00 00 
  66c20e:	f3 0f 11 8c 24 30 02 	movss  %xmm1,0x230(%rsp)
  66c215:	00 00 
  66c217:	f3 0f 58 c1          	addss  %xmm1,%xmm0
  66c21b:	f3 0f 11 84 24 28 02 	movss  %xmm0,0x228(%rsp)
  66c222:	00 00 
  66c224:	0f b6 8c 24 5c 04 00 	movzbl 0x45c(%rsp),%ecx
  66c22b:	00 
  66c22c:	88 4c 24 0b          	mov    %cl,0xb(%rsp)
  66c230:	48 8b 8c 24 40 04 00 	mov    0x440(%rsp),%rcx
  66c237:	00 
  66c238:	48 89 8c 24 48 01 00 	mov    %rcx,0x148(%rsp)
  66c23f:	00 
  66c240:	8b 8c 24 48 04 00 00 	mov    0x448(%rsp),%ecx
  66c247:	89 8c 24 0c 01 00 00 	mov    %ecx,0x10c(%rsp)
  66c24e:	8b 8c 24 58 04 00 00 	mov    0x458(%rsp),%ecx
  66c255:	89 8c 24 2c 02 00 00 	mov    %ecx,0x22c(%rsp)
  66c25c:	48 8d 4a 16          	lea    0x16(%rdx),%rcx
  66c260:	48 89 8c 24 58 02 00 	mov    %rcx,0x258(%rsp)
  66c267:	00 
  66c268:	48 89 94 24 f0 01 00 	mov    %rdx,0x1f0(%rsp)
  66c26f:	00 
  66c270:	48 8d 4a 2e          	lea    0x2e(%rdx),%rcx
  66c274:	48 89 8c 24 f0 02 00 	mov    %rcx,0x2f0(%rsp)
  66c27b:	00 
  66c27c:	4c 89 b4 24 68 02 00 	mov    %r14,0x268(%rsp)
  66c283:	00 
  66c284:	49 89 f6             	mov    %rsi,%r14
  66c287:	eb 71                	jmp    66c2fa <<gpui_canvas::text::planner::Planner>::shape+0x179a>
  66c289:	44 03 bc 24 90 00 00 	add    0x90(%rsp),%r15d
  66c290:	00 
  66c291:	0f 28 8c 24 e0 01 00 	movaps 0x1e0(%rsp),%xmm1
  66c298:	00 
  66c299:	f3 0f 58 4c 24 0c    	addss  0xc(%rsp),%xmm1
  66c29f:	48 8b 84 24 20 01 00 	mov    0x120(%rsp),%rax
  66c2a6:	00 
  66c2a7:	4c 89 f1             	mov    %r14,%rcx
  66c2aa:	48 c1 e1 04          	shl    $0x4,%rcx
  66c2ae:	44 89 3c 08          	mov    %r15d,(%rax,%rcx,1)
  66c2b2:	f3 0f 10 84 24 58 01 	movss  0x158(%rsp),%xmm0
  66c2b9:	00 00 
  66c2bb:	f3 0f 11 44 08 04    	movss  %xmm0,0x4(%rax,%rcx,1)
  66c2c1:	f3 0f 11 4c 08 08    	movss  %xmm1,0x8(%rax,%rcx,1)
  66c2c7:	8b 54 24 54          	mov    0x54(%rsp),%edx
  66c2cb:	66 89 54 08 0c       	mov    %dx,0xc(%rax,%rcx,1)
  66c2d0:	48 8b 94 24 68 02 00 	mov    0x268(%rsp),%rdx
  66c2d7:	00 
  66c2d8:	88 54 08 0e          	mov    %dl,0xe(%rax,%rcx,1)
  66c2dc:	c6 44 08 0f 00       	movb   $0x0,0xf(%rax,%rcx,1)
  66c2e1:	49 ff c6             	inc    %r14
  66c2e4:	4c 89 b4 24 28 01 00 	mov    %r14,0x128(%rsp)
  66c2eb:	00 
  66c2ec:	31 c0                	xor    %eax,%eax
  66c2ee:	49 89 ee             	mov    %rbp,%r14
  66c2f1:	f3 0f 10 94 24 d4 01 	movss  0x1d4(%rsp),%xmm2
  66c2f8:	00 00 
  66c2fa:	f3 0f 11 94 24 58 01 	movss  %xmm2,0x158(%rsp)
  66c301:	00 00 
  66c303:	a8 01                	test   $0x1,%al
  66c305:	74 59                	je     66c360 <<gpui_canvas::text::planner::Planner>::shape+0x1800>
  66c307:	f3 0f 10 84 24 c8 01 	movss  0x1c8(%rsp),%xmm0
  66c30e:	00 00 
  66c310:	f3 0f 11 84 24 30 01 	movss  %xmm0,0x130(%rsp)
  66c317:	00 00 
  66c319:	8b 84 24 cc 01 00 00 	mov    0x1cc(%rsp),%eax
  66c320:	89 44 24 54          	mov    %eax,0x54(%rsp)
  66c324:	0f 28 84 24 40 02 00 	movaps 0x240(%rsp),%xmm0
  66c32b:	00 
  66c32c:	0f 29 84 24 e0 01 00 	movaps %xmm0,0x1e0(%rsp)
  66c333:	00 
  66c334:	83 bc 24 0c 01 00 00 	cmpl   $0x0,0x10c(%rsp)
  66c33b:	00 
  66c33c:	74 6f                	je     66c3ad <<gpui_canvas::text::planner::Planner>::shape+0x184d>
  66c33e:	48 83 bc 24 e0 00 00 	cmpq   $0x0,0xe0(%rsp)
  66c345:	00 00 
  66c347:	74 77                	je     66c3c0 <<gpui_canvas::text::planner::Planner>::shape+0x1860>
  66c349:	0f 28 84 24 e0 01 00 	movaps 0x1e0(%rsp),%xmm0
  66c350:	00 
  66c351:	f3 0f 11 84 24 08 01 	movss  %xmm0,0x108(%rsp)
  66c358:	00 00 
  66c35a:	e9 95 00 00 00       	jmp    66c3f4 <<gpui_canvas::text::planner::Planner>::shape+0x1894>
  66c35f:	90                   	nop
  66c360:	48 3b 9c 24 f0 00 00 	cmp    0xf0(%rsp),%rbx
  66c367:	00 
  66c368:	0f 84 67 01 00 00    	je     66c4d5 <<gpui_canvas::text::planner::Planner>::shape+0x1975>
  66c36e:	48 8b 94 24 e0 00 00 	mov    0xe0(%rsp),%rdx
  66c375:	00 
  66c376:	8b 03                	mov    (%rbx),%eax
  66c378:	89 44 24 54          	mov    %eax,0x54(%rsp)
  66c37c:	f2 0f 10 43 04       	movsd  0x4(%rbx),%xmm0
  66c381:	0f 29 84 24 e0 01 00 	movaps %xmm0,0x1e0(%rsp)
  66c388:	00 
  66c389:	f3 0f 10 43 0c       	movss  0xc(%rbx),%xmm0
  66c38e:	f3 0f 11 84 24 30 01 	movss  %xmm0,0x130(%rsp)
  66c395:	00 00 
  66c397:	48 83 c3 10          	add    $0x10,%rbx
  66c39b:	48 89 94 24 e0 00 00 	mov    %rdx,0xe0(%rsp)
  66c3a2:	00 
  66c3a3:	83 bc 24 0c 01 00 00 	cmpl   $0x0,0x10c(%rsp)
  66c3aa:	00 
  66c3ab:	75 91                	jne    66c33e <<gpui_canvas::text::planner::Planner>::shape+0x17de>
  66c3ad:	0f 28 84 24 e0 01 00 	movaps 0x1e0(%rsp),%xmm0
  66c3b4:	00 
  66c3b5:	f3 0f 11 84 24 08 01 	movss  %xmm0,0x108(%rsp)
  66c3bc:	00 00 
  66c3be:	eb 74                	jmp    66c434 <<gpui_canvas::text::planner::Planner>::shape+0x18d4>
  66c3c0:	f3 0f 10 84 24 d0 01 	movss  0x1d0(%rsp),%xmm0
  66c3c7:	00 00 
  66c3c9:	0f 28 c8             	movaps %xmm0,%xmm1
  66c3cc:	f3 0f 58 8c 24 e0 01 	addss  0x1e0(%rsp),%xmm1
  66c3d3:	00 00 
  66c3d5:	f3 0f 11 8c 24 08 01 	movss  %xmm1,0x108(%rsp)
  66c3dc:	00 00 
  66c3de:	f3 0f 10 8c 24 30 01 	movss  0x130(%rsp),%xmm1
  66c3e5:	00 00 
  66c3e7:	f3 0f 58 c8          	addss  %xmm0,%xmm1
  66c3eb:	f3 0f 11 8c 24 30 01 	movss  %xmm1,0x130(%rsp)
  66c3f2:	00 00 
  66c3f4:	48 8b 94 24 e0 00 00 	mov    0xe0(%rsp),%rdx
  66c3fb:	00 
  66c3fc:	48 ff c2             	inc    %rdx
  66c3ff:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  66c406:	00 
  66c407:	48 89 94 24 e0 00 00 	mov    %rdx,0xe0(%rsp)
  66c40e:	00 
  66c40f:	48 39 c2             	cmp    %rax,%rdx
  66c412:	75 20                	jne    66c434 <<gpui_canvas::text::planner::Planner>::shape+0x18d4>
  66c414:	f3 0f 10 84 24 30 01 	movss  0x130(%rsp),%xmm0
  66c41b:	00 00 
  66c41d:	f3 0f 58 44 24 50    	addss  0x50(%rsp),%xmm0
  66c423:	f3 0f 11 84 24 30 01 	movss  %xmm0,0x130(%rsp)
  66c42a:	00 00 
  66c42c:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
  66c433:	00 
  66c434:	48 8d bc 24 98 00 00 	lea    0x98(%rsp),%rdi
  66c43b:	00 
  66c43c:	48 8d b4 24 90 04 00 	lea    0x490(%rsp),%rsi
  66c443:	00 
  66c444:	e8 b7 26 00 00       	call   66eb00 <<core::iter::adapters::flatten::FlattenCompat<core::iter::adapters::map::Map<core::ops::range::Range<u32>, <parley::layout::run::Run<()>>::glyph_source_ranges::{closure#0}>, core::iter::sources::repeat_n::RepeatN<core::ops::range::Range<usize>>> as core::iter::traits::iterator::Iterator>::next>
  66c449:	83 bc 24 98 00 00 00 	cmpl   $0x1,0x98(%rsp)
  66c450:	01 
  66c451:	0f 85 40 16 00 00    	jne    66da97 <<gpui_canvas::text::planner::Planner>::shape+0x2f37>
  66c457:	f3 0f 10 94 24 58 01 	movss  0x158(%rsp),%xmm2
  66c45e:	00 00 
  66c460:	f3 0f 58 94 24 30 01 	addss  0x130(%rsp),%xmm2
  66c467:	00 00 
  66c469:	31 c0                	xor    %eax,%eax
  66c46b:	48 8b 8c 24 b8 01 00 	mov    0x1b8(%rsp),%rcx
  66c472:	00 
  66c473:	48 3b 8c 24 90 00 00 	cmp    0x90(%rsp),%rcx
  66c47a:	00 
  66c47b:	0f 84 79 fe ff ff    	je     66c2fa <<gpui_canvas::text::planner::Planner>::shape+0x179a>
  66c481:	f3 0f 11 94 24 d4 01 	movss  %xmm2,0x1d4(%rsp)
  66c488:	00 00 
  66c48a:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  66c491:	00 
  66c492:	48 8b 8c 24 a8 00 00 	mov    0xa8(%rsp),%rcx
  66c499:	00 
  66c49a:	48 39 c8             	cmp    %rcx,%rax
  66c49d:	4c 8b 84 24 80 00 00 	mov    0x80(%rsp),%r8
  66c4a4:	00 
  66c4a5:	0f 87 dc 15 00 00    	ja     66da87 <<gpui_canvas::text::planner::Planner>::shape+0x2f27>
  66c4ab:	49 89 c7             	mov    %rax,%r15
  66c4ae:	48 89 cd             	mov    %rcx,%rbp
  66c4b1:	48 85 c0             	test   %rax,%rax
  66c4b4:	0f 84 fd 04 00 00    	je     66c9b7 <<gpui_canvas::text::planner::Planner>::shape+0x1e57>
  66c4ba:	4c 3b 7c 24 40       	cmp    0x40(%rsp),%r15
  66c4bf:	0f 83 ec 04 00 00    	jae    66c9b1 <<gpui_canvas::text::planner::Planner>::shape+0x1e51>
  66c4c5:	43 80 3c 38 bf       	cmpb   $0xbf,(%r8,%r15,1)
  66c4ca:	0f 8f e7 04 00 00    	jg     66c9b7 <<gpui_canvas::text::planner::Planner>::shape+0x1e57>
  66c4d0:	e9 b2 15 00 00       	jmp    66da87 <<gpui_canvas::text::planner::Planner>::shape+0x2f27>
  66c4d5:	48 89 9c 24 f0 00 00 	mov    %rbx,0xf0(%rsp)
  66c4dc:	00 
  66c4dd:	f6 44 24 0b 01       	testb  $0x1,0xb(%rsp)
  66c4e2:	74 2e                	je     66c512 <<gpui_canvas::text::planner::Planner>::shape+0x19b2>
  66c4e4:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  66c4e9:	48 8b 8c 24 d0 00 00 	mov    0xd0(%rsp),%rcx
  66c4f0:	00 
  66c4f1:	39 c1                	cmp    %eax,%ecx
  66c4f3:	4c 8b 8c 24 78 02 00 	mov    0x278(%rsp),%r9
  66c4fa:	00 
  66c4fb:	4c 8b 84 24 70 02 00 	mov    0x270(%rsp),%r8
  66c502:	00 
  66c503:	0f 83 53 01 00 00    	jae    66c65c <<gpui_canvas::text::planner::Planner>::shape+0x1afc>
  66c509:	ff c8                	dec    %eax
  66c50b:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  66c510:	eb 28                	jmp    66c53a <<gpui_canvas::text::planner::Planner>::shape+0x19da>
  66c512:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
  66c517:	48 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%rax
  66c51e:	00 
  66c51f:	39 d0                	cmp    %edx,%eax
  66c521:	4c 8b 8c 24 78 02 00 	mov    0x278(%rsp),%r9
  66c528:	00 
  66c529:	4c 8b 84 24 70 02 00 	mov    0x270(%rsp),%r8
  66c530:	00 
  66c531:	0f 83 3c 01 00 00    	jae    66c673 <<gpui_canvas::text::planner::Planner>::shape+0x1b13>
  66c537:	8d 48 01             	lea    0x1(%rax),%ecx
  66c53a:	89 c7                	mov    %eax,%edi
  66c53c:	48 39 7c 24 20       	cmp    %rdi,0x20(%rsp)
  66c541:	48 8b 94 24 f0 01 00 	mov    0x1f0(%rsp),%rdx
  66c548:	00 
  66c549:	0f 86 4f 1b 00 00    	jbe    66e09e <<gpui_canvas::text::planner::Planner>::shape+0x353e>
  66c54f:	48 8d 04 7f          	lea    (%rdi,%rdi,2),%rax
  66c553:	8b 5c c2 08          	mov    0x8(%rdx,%rax,8),%ebx
  66c557:	f6 44 c2 17 01       	testb  $0x1,0x17(%rdx,%rax,8)
  66c55c:	0f 85 55 05 00 00    	jne    66cab7 <<gpui_canvas::text::planner::Planner>::shape+0x1f57>
  66c562:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
  66c566:	8b 50 0c             	mov    0xc(%rax),%edx
  66c569:	48 8d 34 1a          	lea    (%rdx,%rbx,1),%rsi
  66c56d:	48 3b b4 24 50 01 00 	cmp    0x150(%rsp),%rsi
  66c574:	00 
  66c575:	0f 87 37 17 00 00    	ja     66dcb2 <<gpui_canvas::text::planner::Planner>::shape+0x3152>
  66c57b:	48 c1 e3 04          	shl    $0x4,%rbx
  66c57f:	4c 01 f3             	add    %r14,%rbx
  66c582:	48 89 d0             	mov    %rdx,%rax
  66c585:	48 c1 e0 04          	shl    $0x4,%rax
  66c589:	48 01 d8             	add    %rbx,%rax
  66c58c:	0f 57 c0             	xorps  %xmm0,%xmm0
  66c58f:	0f 29 84 24 40 02 00 	movaps %xmm0,0x240(%rsp)
  66c596:	00 
  66c597:	48 85 d2             	test   %rdx,%rdx
  66c59a:	0f 85 ad 06 00 00    	jne    66cc4d <<gpui_canvas::text::planner::Planner>::shape+0x20ed>
  66c5a0:	89 ca                	mov    %ecx,%edx
  66c5a2:	48 89 94 24 d0 00 00 	mov    %rdx,0xd0(%rsp)
  66c5a9:	00 
  66c5aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  66c5b0:	f6 44 24 0b 01       	testb  $0x1,0xb(%rsp)
  66c5b5:	74 29                	je     66c5e0 <<gpui_canvas::text::planner::Planner>::shape+0x1a80>
  66c5b7:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
  66c5bc:	39 d1                	cmp    %edx,%ecx
  66c5be:	0f 83 ca 00 00 00    	jae    66c68e <<gpui_canvas::text::planner::Planner>::shape+0x1b2e>
  66c5c4:	ff ca                	dec    %edx
  66c5c6:	48 89 d0             	mov    %rdx,%rax
  66c5c9:	89 ca                	mov    %ecx,%edx
  66c5cb:	48 89 c1             	mov    %rax,%rcx
  66c5ce:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  66c5d3:	eb 25                	jmp    66c5fa <<gpui_canvas::text::planner::Planner>::shape+0x1a9a>
  66c5d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  66c5dc:	00 00 00 00 
  66c5e0:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
  66c5e5:	39 d1                	cmp    %edx,%ecx
  66c5e7:	0f 83 43 01 00 00    	jae    66c730 <<gpui_canvas::text::planner::Planner>::shape+0x1bd0>
  66c5ed:	8d 41 01             	lea    0x1(%rcx),%eax
  66c5f0:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
  66c5f7:	00 
  66c5f8:	89 c2                	mov    %eax,%edx
  66c5fa:	89 cf                	mov    %ecx,%edi
  66c5fc:	48 39 7c 24 20       	cmp    %rdi,0x20(%rsp)
  66c601:	48 8b 8c 24 f0 01 00 	mov    0x1f0(%rsp),%rcx
  66c608:	00 
  66c609:	0f 86 8f 1a 00 00    	jbe    66e09e <<gpui_canvas::text::planner::Planner>::shape+0x353e>
  66c60f:	48 8d 04 7f          	lea    (%rdi,%rdi,2),%rax
  66c613:	8b 5c c1 08          	mov    0x8(%rcx,%rax,8),%ebx
  66c617:	f6 44 c1 17 01       	testb  $0x1,0x17(%rcx,%rax,8)
  66c61c:	0f 85 8d 04 00 00    	jne    66caaf <<gpui_canvas::text::planner::Planner>::shape+0x1f4f>
  66c622:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
  66c626:	8b 78 0c             	mov    0xc(%rax),%edi
  66c629:	48 8d 34 1f          	lea    (%rdi,%rbx,1),%rsi
  66c62d:	48 3b b4 24 50 01 00 	cmp    0x150(%rsp),%rsi
  66c634:	00 
  66c635:	0f 87 77 16 00 00    	ja     66dcb2 <<gpui_canvas::text::planner::Planner>::shape+0x3152>
  66c63b:	48 c1 e3 04          	shl    $0x4,%rbx
  66c63f:	4c 01 f3             	add    %r14,%rbx
  66c642:	48 89 f8             	mov    %rdi,%rax
  66c645:	48 c1 e0 04          	shl    $0x4,%rax
  66c649:	48 01 d8             	add    %rbx,%rax
  66c64c:	89 d1                	mov    %edx,%ecx
  66c64e:	48 85 ff             	test   %rdi,%rdi
  66c651:	0f 84 59 ff ff ff    	je     66c5b0 <<gpui_canvas::text::planner::Planner>::shape+0x1a50>
  66c657:	e9 cf 04 00 00       	jmp    66cb2b <<gpui_canvas::text::planner::Planner>::shape+0x1fcb>
  66c65c:	48 89 d8             	mov    %rbx,%rax
  66c65f:	44 39 c1             	cmp    %r8d,%ecx
  66c662:	0f 95 c2             	setne  %dl
  66c665:	84 94 24 0c 01 00 00 	test   %dl,0x10c(%rsp)
  66c66c:	75 46                	jne    66c6b4 <<gpui_canvas::text::planner::Planner>::shape+0x1b54>
  66c66e:	e9 f7 05 00 00       	jmp    66cc6a <<gpui_canvas::text::planner::Planner>::shape+0x210a>
  66c673:	48 89 d8             	mov    %rbx,%rax
  66c676:	44 39 ca             	cmp    %r9d,%edx
  66c679:	0f 95 c1             	setne  %cl
  66c67c:	84 8c 24 0c 01 00 00 	test   %cl,0x10c(%rsp)
  66c683:	0f 85 cd 00 00 00    	jne    66c756 <<gpui_canvas::text::planner::Planner>::shape+0x1bf6>
  66c689:	e9 dc 05 00 00       	jmp    66cc6a <<gpui_canvas::text::planner::Planner>::shape+0x210a>
  66c68e:	0f 57 c0             	xorps  %xmm0,%xmm0
  66c691:	0f 29 84 24 40 02 00 	movaps %xmm0,0x240(%rsp)
  66c698:	00 
  66c699:	48 89 84 24 f0 00 00 	mov    %rax,0xf0(%rsp)
  66c6a0:	00 
  66c6a1:	44 39 c1             	cmp    %r8d,%ecx
  66c6a4:	0f 95 c2             	setne  %dl
  66c6a7:	84 94 24 0c 01 00 00 	test   %dl,0x10c(%rsp)
  66c6ae:	0f 84 b6 05 00 00    	je     66cc6a <<gpui_canvas::text::planner::Planner>::shape+0x210a>
  66c6b4:	8d 79 ff             	lea    -0x1(%rcx),%edi
  66c6b7:	48 39 7c 24 20       	cmp    %rdi,0x20(%rsp)
  66c6bc:	0f 86 7c 1a 00 00    	jbe    66e13e <<gpui_canvas::text::planner::Planner>::shape+0x35de>
  66c6c2:	44 39 c7             	cmp    %r8d,%edi
  66c6c5:	76 3e                	jbe    66c705 <<gpui_canvas::text::planner::Planner>::shape+0x1ba5>
  66c6c7:	48 8d 14 7f          	lea    (%rdi,%rdi,2),%rdx
  66c6cb:	48 8b b4 24 58 02 00 	mov    0x258(%rsp),%rsi
  66c6d2:	00 
  66c6d3:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
  66c6d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  66c6de:	00 00 
  66c6e0:	48 39 7c 24 20       	cmp    %rdi,0x20(%rsp)
  66c6e5:	0f 86 d9 19 00 00    	jbe    66e0c4 <<gpui_canvas::text::planner::Planner>::shape+0x3564>
  66c6eb:	f6 42 01 02          	testb  $0x2,0x1(%rdx)
  66c6ef:	75 14                	jne    66c705 <<gpui_canvas::text::planner::Planner>::shape+0x1ba5>
  66c6f1:	48 ff cf             	dec    %rdi
  66c6f4:	48 83 c2 e8          	add    $0xffffffffffffffe8,%rdx
  66c6f8:	41 39 f8             	cmp    %edi,%r8d
  66c6fb:	72 e3                	jb     66c6e0 <<gpui_canvas::text::planner::Planner>::shape+0x1b80>
  66c6fd:	4c 89 c7             	mov    %r8,%rdi
  66c700:	44 89 c2             	mov    %r8d,%edx
  66c703:	eb 02                	jmp    66c707 <<gpui_canvas::text::planner::Planner>::shape+0x1ba7>
  66c705:	89 fa                	mov    %edi,%edx
  66c707:	48 89 94 24 d0 00 00 	mov    %rdx,0xd0(%rsp)
  66c70e:	00 
  66c70f:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  66c714:	48 39 fe             	cmp    %rdi,%rsi
  66c717:	0f 86 2a 1a 00 00    	jbe    66e147 <<gpui_canvas::text::planner::Planner>::shape+0x35e7>
  66c71d:	89 ca                	mov    %ecx,%edx
  66c71f:	48 ff ca             	dec    %rdx
  66c722:	48 39 f2             	cmp    %rsi,%rdx
  66c725:	0f 82 9d 00 00 00    	jb     66c7c8 <<gpui_canvas::text::planner::Planner>::shape+0x1c68>
  66c72b:	e9 23 1a 00 00       	jmp    66e153 <<gpui_canvas::text::planner::Planner>::shape+0x35f3>
  66c730:	0f 57 c0             	xorps  %xmm0,%xmm0
  66c733:	0f 29 84 24 40 02 00 	movaps %xmm0,0x240(%rsp)
  66c73a:	00 
  66c73b:	48 89 84 24 f0 00 00 	mov    %rax,0xf0(%rsp)
  66c742:	00 
  66c743:	44 39 ca             	cmp    %r9d,%edx
  66c746:	0f 95 c1             	setne  %cl
  66c749:	84 8c 24 0c 01 00 00 	test   %cl,0x10c(%rsp)
  66c750:	0f 84 14 05 00 00    	je     66cc6a <<gpui_canvas::text::planner::Planner>::shape+0x210a>
  66c756:	49 89 d0             	mov    %rdx,%r8
  66c759:	48 89 d1             	mov    %rdx,%rcx
  66c75c:	89 cf                	mov    %ecx,%edi
  66c75e:	48 39 7c 24 20       	cmp    %rdi,0x20(%rsp)
  66c763:	0f 86 c0 19 00 00    	jbe    66e129 <<gpui_canvas::text::planner::Planner>::shape+0x35c9>
  66c769:	ff c1                	inc    %ecx
  66c76b:	44 39 c9             	cmp    %r9d,%ecx
  66c76e:	73 40                	jae    66c7b0 <<gpui_canvas::text::planner::Planner>::shape+0x1c50>
  66c770:	89 ca                	mov    %ecx,%edx
  66c772:	48 8d 0c 52          	lea    (%rdx,%rdx,2),%rcx
  66c776:	48 8b b4 24 58 02 00 	mov    0x258(%rsp),%rsi
  66c77d:	00 
  66c77e:	48 8d 34 ce          	lea    (%rsi,%rcx,8),%rsi
  66c782:	48 89 d1             	mov    %rdx,%rcx
  66c785:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  66c78c:	00 00 00 00 
  66c790:	48 39 4c 24 20       	cmp    %rcx,0x20(%rsp)
  66c795:	0f 86 0c 19 00 00    	jbe    66e0a7 <<gpui_canvas::text::planner::Planner>::shape+0x3547>
  66c79b:	f6 46 01 02          	testb  $0x2,0x1(%rsi)
  66c79f:	75 0f                	jne    66c7b0 <<gpui_canvas::text::planner::Planner>::shape+0x1c50>
  66c7a1:	48 ff c1             	inc    %rcx
  66c7a4:	48 83 c6 18          	add    $0x18,%rsi
  66c7a8:	49 39 c9             	cmp    %rcx,%r9
  66c7ab:	75 e3                	jne    66c790 <<gpui_canvas::text::planner::Planner>::shape+0x1c30>
  66c7ad:	44 89 c9             	mov    %r9d,%ecx
  66c7b0:	89 ca                	mov    %ecx,%edx
  66c7b2:	48 ff ca             	dec    %rdx
  66c7b5:	48 3b 54 24 20       	cmp    0x20(%rsp),%rdx
  66c7ba:	0f 83 72 19 00 00    	jae    66e132 <<gpui_canvas::text::planner::Planner>::shape+0x35d2>
  66c7c0:	4c 89 84 24 d0 00 00 	mov    %r8,0xd0(%rsp)
  66c7c7:	00 
  66c7c8:	48 89 4c 24 70       	mov    %rcx,0x70(%rsp)
  66c7cd:	48 83 bc 24 80 02 00 	cmpq   $0x0,0x280(%rsp)
  66c7d4:	00 00 
  66c7d6:	0f 84 8e 04 00 00    	je     66cc6a <<gpui_canvas::text::planner::Planner>::shape+0x210a>
  66c7dc:	48 8d 0c 7f          	lea    (%rdi,%rdi,2),%rcx
  66c7e0:	48 8b b4 24 f0 01 00 	mov    0x1f0(%rsp),%rsi
  66c7e7:	00 
  66c7e8:	8b 0c ce             	mov    (%rsi,%rcx,8),%ecx
  66c7eb:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
  66c7ef:	8b 74 d6 04          	mov    0x4(%rsi,%rdx,8),%esi
  66c7f3:	39 ce                	cmp    %ecx,%esi
  66c7f5:	0f 82 c1 17 00 00    	jb     66dfbc <<gpui_canvas::text::planner::Planner>::shape+0x345c>
  66c7fb:	48 39 b4 24 08 02 00 	cmp    %rsi,0x208(%rsp)
  66c802:	00 
  66c803:	0f 82 b3 17 00 00    	jb     66dfbc <<gpui_canvas::text::planner::Planner>::shape+0x345c>
  66c809:	39 ce                	cmp    %ecx,%esi
  66c80b:	0f 84 d4 18 00 00    	je     66e0e5 <<gpui_canvas::text::planner::Planner>::shape+0x3585>
  66c811:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  66c815:	48 8b 94 24 80 02 00 	mov    0x280(%rsp),%rdx
  66c81c:	00 
  66c81d:	0f b6 4c 8a 07       	movzbl 0x7(%rdx,%rcx,4),%ecx
  66c822:	8d 51 ff             	lea    -0x1(%rcx),%edx
  66c825:	83 fa 02             	cmp    $0x2,%edx
  66c828:	73 28                	jae    66c852 <<gpui_canvas::text::planner::Planner>::shape+0x1cf2>
  66c82a:	f3 0f 10 84 24 30 02 	movss  0x230(%rsp),%xmm0
  66c831:	00 00 
  66c833:	f3 0f 11 44 24 50    	movss  %xmm0,0x50(%rsp)
  66c839:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
  66c83e:	3b 94 24 2c 02 00 00 	cmp    0x22c(%rsp),%edx
  66c845:	77 2d                	ja     66c874 <<gpui_canvas::text::planner::Planner>::shape+0x1d14>
  66c847:	f3 0f 10 84 24 28 02 	movss  0x228(%rsp),%xmm0
  66c84e:	00 00 
  66c850:	eb 1c                	jmp    66c86e <<gpui_canvas::text::planner::Planner>::shape+0x1d0e>
  66c852:	f3 0f 10 84 24 34 02 	movss  0x234(%rsp),%xmm0
  66c859:	00 00 
  66c85b:	f3 0f 11 44 24 50    	movss  %xmm0,0x50(%rsp)
  66c861:	83 f9 06             	cmp    $0x6,%ecx
  66c864:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
  66c869:	75 09                	jne    66c874 <<gpui_canvas::text::planner::Planner>::shape+0x1d14>
  66c86b:	0f 57 c0             	xorps  %xmm0,%xmm0
  66c86e:	f3 0f 11 44 24 50    	movss  %xmm0,0x50(%rsp)
  66c874:	89 d6                	mov    %edx,%esi
  66c876:	48 39 74 24 20       	cmp    %rsi,0x20(%rsp)
  66c87b:	0f 92 c1             	setb   %cl
  66c87e:	3b 94 24 d0 00 00 00 	cmp    0xd0(%rsp),%edx
  66c885:	0f 82 0d 01 00 00    	jb     66c998 <<gpui_canvas::text::planner::Planner>::shape+0x1e38>
  66c88b:	48 8b bc 24 d0 00 00 	mov    0xd0(%rsp),%rdi
  66c892:	00 
  66c893:	89 fa                	mov    %edi,%edx
  66c895:	84 c9                	test   %cl,%cl
  66c897:	0f 85 3e 17 00 00    	jne    66dfdb <<gpui_canvas::text::planner::Planner>::shape+0x347b>
  66c89d:	3b 7c 24 70          	cmp    0x70(%rsp),%edi
  66c8a1:	75 11                	jne    66c8b4 <<gpui_canvas::text::planner::Planner>::shape+0x1d54>
  66c8a3:	48 c7 84 24 48 01 00 	movq   $0x0,0x148(%rsp)
  66c8aa:	00 00 00 00 00 
  66c8af:	e9 b8 00 00 00       	jmp    66c96c <<gpui_canvas::text::planner::Planner>::shape+0x1e0c>
  66c8b4:	48 8d 0c d5 00 00 00 	lea    0x0(,%rdx,8),%rcx
  66c8bb:	00 
  66c8bc:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  66c8c0:	48 8d 7e ff          	lea    -0x1(%rsi),%rdi
  66c8c4:	48 39 d7             	cmp    %rdx,%rdi
  66c8c7:	75 10                	jne    66c8d9 <<gpui_canvas::text::planner::Planner>::shape+0x1d79>
  66c8c9:	31 d2                	xor    %edx,%edx
  66c8cb:	48 c7 84 24 48 01 00 	movq   $0x0,0x148(%rsp)
  66c8d2:	00 00 00 00 00 
  66c8d7:	eb 62                	jmp    66c93b <<gpui_canvas::text::planner::Planner>::shape+0x1ddb>
  66c8d9:	48 29 d6             	sub    %rdx,%rsi
  66c8dc:	48 89 f7             	mov    %rsi,%rdi
  66c8df:	48 83 e7 fe          	and    $0xfffffffffffffffe,%rdi
  66c8e3:	48 8b 94 24 f0 02 00 	mov    0x2f0(%rsp),%rdx
  66c8ea:	00 
  66c8eb:	4c 8d 04 0a          	lea    (%rdx,%rcx,1),%r8
  66c8ef:	31 d2                	xor    %edx,%edx
  66c8f1:	45 31 d2             	xor    %r10d,%r10d
  66c8f4:	41 bb 01 00 00 00    	mov    $0x1,%r11d
  66c8fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  66c900:	45 8b 48 de          	mov    -0x22(%r8),%r9d
  66c904:	41 f6 40 e9 01       	testb  $0x1,-0x17(%r8)
  66c909:	4d 0f 45 cb          	cmovne %r11,%r9
  66c90d:	4d 01 d1             	add    %r10,%r9
  66c910:	41 f6 40 01 01       	testb  $0x1,0x1(%r8)
  66c915:	45 8b 50 f6          	mov    -0xa(%r8),%r10d
  66c919:	4d 0f 45 d3          	cmovne %r11,%r10
  66c91d:	4d 01 ca             	add    %r9,%r10
  66c920:	48 83 c2 02          	add    $0x2,%rdx
  66c924:	49 83 c0 30          	add    $0x30,%r8
  66c928:	48 39 d7             	cmp    %rdx,%rdi
  66c92b:	75 d3                	jne    66c900 <<gpui_canvas::text::planner::Planner>::shape+0x1da0>
  66c92d:	4c 89 94 24 48 01 00 	mov    %r10,0x148(%rsp)
  66c934:	00 
  66c935:	40 f6 c6 01          	test   $0x1,%sil
  66c939:	74 31                	je     66c96c <<gpui_canvas::text::planner::Planner>::shape+0x1e0c>
  66c93b:	48 8b b4 24 48 01 00 	mov    0x148(%rsp),%rsi
  66c942:	00 
  66c943:	48 03 8c 24 f0 01 00 	add    0x1f0(%rsp),%rcx
  66c94a:	00 
  66c94b:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
  66c94f:	f6 44 d1 17 01       	testb  $0x1,0x17(%rcx,%rdx,8)
  66c954:	8b 54 d1 0c          	mov    0xc(%rcx,%rdx,8),%edx
  66c958:	b9 01 00 00 00       	mov    $0x1,%ecx
  66c95d:	48 0f 45 d1          	cmovne %rcx,%rdx
  66c961:	48 01 f2             	add    %rsi,%rdx
  66c964:	48 89 94 24 48 01 00 	mov    %rdx,0x148(%rsp)
  66c96b:	00 
  66c96c:	0f 57 c0             	xorps  %xmm0,%xmm0
  66c96f:	f3 0f 11 84 24 d0 01 	movss  %xmm0,0x1d0(%rsp)
  66c976:	00 00 
  66c978:	b9 00 00 00 00       	mov    $0x0,%ecx
  66c97d:	48 89 8c 24 e0 00 00 	mov    %rcx,0xe0(%rsp)
  66c984:	00 
  66c985:	ba 00 00 00 00       	mov    $0x0,%edx
  66c98a:	48 39 c3             	cmp    %rax,%rbx
  66c98d:	0f 84 4a fb ff ff    	je     66c4dd <<gpui_canvas::text::planner::Planner>::shape+0x197d>
  66c993:	e9 de f9 ff ff       	jmp    66c376 <<gpui_canvas::text::planner::Planner>::shape+0x1816>
  66c998:	b1 01                	mov    $0x1,%cl
  66c99a:	48 8b bc 24 d0 00 00 	mov    0xd0(%rsp),%rdi
  66c9a1:	00 
  66c9a2:	89 fa                	mov    %edi,%edx
  66c9a4:	84 c9                	test   %cl,%cl
  66c9a6:	0f 84 f1 fe ff ff    	je     66c89d <<gpui_canvas::text::planner::Planner>::shape+0x1d3d>
  66c9ac:	e9 2a 16 00 00       	jmp    66dfdb <<gpui_canvas::text::planner::Planner>::shape+0x347b>
  66c9b1:	0f 85 d0 10 00 00    	jne    66da87 <<gpui_canvas::text::planner::Planner>::shape+0x2f27>
  66c9b7:	48 85 ed             	test   %rbp,%rbp
  66c9ba:	0f 94 c0             	sete   %al
  66c9bd:	89 84 24 00 01 00 00 	mov    %eax,0x100(%rsp)
  66c9c4:	74 19                	je     66c9df <<gpui_canvas::text::planner::Planner>::shape+0x1e7f>
  66c9c6:	48 3b 6c 24 40       	cmp    0x40(%rsp),%rbp
  66c9cb:	73 0c                	jae    66c9d9 <<gpui_canvas::text::planner::Planner>::shape+0x1e79>
  66c9cd:	41 80 3c 28 c0       	cmpb   $0xc0,(%r8,%rbp,1)
  66c9d2:	7d 0b                	jge    66c9df <<gpui_canvas::text::planner::Planner>::shape+0x1e7f>
  66c9d4:	e9 ae 10 00 00       	jmp    66da87 <<gpui_canvas::text::planner::Planner>::shape+0x2f27>
  66c9d9:	0f 85 a8 10 00 00    	jne    66da87 <<gpui_canvas::text::planner::Planner>::shape+0x2f27>
  66c9df:	83 7c 24 54 00       	cmpl   $0x0,0x54(%rsp)
  66c9e4:	0f 84 a1 00 00 00    	je     66ca8b <<gpui_canvas::text::planner::Planner>::shape+0x1f2b>
  66c9ea:	f3 0f 10 84 24 58 01 	movss  0x158(%rsp),%xmm0
  66c9f1:	00 00 
  66c9f3:	f3 0f 58 84 24 08 01 	addss  0x108(%rsp),%xmm0
  66c9fa:	00 00 
  66c9fc:	f3 0f 11 84 24 58 01 	movss  %xmm0,0x158(%rsp)
  66ca03:	00 00 
  66ca05:	66 0f 7e c1          	movd   %xmm0,%ecx
  66ca09:	0f 28 84 24 e0 01 00 	movaps 0x1e0(%rsp),%xmm0
  66ca10:	00 
  66ca11:	0f c6 c0 55          	shufps $0x55,%xmm0,%xmm0
  66ca15:	f3 0f 58 84 24 38 02 	addss  0x238(%rsp),%xmm0
  66ca1c:	00 00 
  66ca1e:	0f 29 84 24 e0 01 00 	movaps %xmm0,0x1e0(%rsp)
  66ca25:	00 
  66ca26:	66 0f 7e c0          	movd   %xmm0,%eax
  66ca2a:	81 e1 ff ff ff 7f    	and    $0x7fffffff,%ecx
  66ca30:	25 ff ff ff 7f       	and    $0x7fffffff,%eax
  66ca35:	3d 00 00 80 7f       	cmp    $0x7f800000,%eax
  66ca3a:	0f 9d c0             	setge  %al
  66ca3d:	81 f9 ff ff 7f 7f    	cmp    $0x7f7fffff,%ecx
  66ca43:	0f 8f 5f 10 00 00    	jg     66daa8 <<gpui_canvas::text::planner::Planner>::shape+0x2f48>
  66ca49:	84 c0                	test   %al,%al
  66ca4b:	0f 85 57 10 00 00    	jne    66daa8 <<gpui_canvas::text::planner::Planner>::shape+0x2f48>
  66ca51:	81 7c 24 54 ff ff 00 	cmpl   $0xffff,0x54(%rsp)
  66ca58:	00 
  66ca59:	0f 87 28 10 00 00    	ja     66da87 <<gpui_canvas::text::planner::Planner>::shape+0x2f27>
  66ca5f:	4c 89 f5             	mov    %r14,%rbp
  66ca62:	4c 8b b4 24 28 01 00 	mov    0x128(%rsp),%r14
  66ca69:	00 
  66ca6a:	4c 3b b4 24 18 01 00 	cmp    0x118(%rsp),%r14
  66ca71:	00 
  66ca72:	0f 85 11 f8 ff ff    	jne    66c289 <<gpui_canvas::text::planner::Planner>::shape+0x1729>
  66ca78:	48 8d bc 24 18 01 00 	lea    0x118(%rsp),%rdi
  66ca7f:	00 
  66ca80:	ff 15 9a e0 11 00    	call   *0x11e09a(%rip)        # 78ab20 <_DYNAMIC+0x498>
  66ca86:	e9 fe f7 ff ff       	jmp    66c289 <<gpui_canvas::text::planner::Planner>::shape+0x1729>
  66ca8b:	4d 85 ff             	test   %r15,%r15
  66ca8e:	0f 84 b2 00 00 00    	je     66cb46 <<gpui_canvas::text::planner::Planner>::shape+0x1fe6>
  66ca94:	4c 3b 7c 24 40       	cmp    0x40(%rsp),%r15
  66ca99:	0f 83 a1 00 00 00    	jae    66cb40 <<gpui_canvas::text::planner::Planner>::shape+0x1fe0>
  66ca9f:	43 80 3c 38 bf       	cmpb   $0xbf,(%r8,%r15,1)
  66caa4:	0f 8f 9c 00 00 00    	jg     66cb46 <<gpui_canvas::text::planner::Planner>::shape+0x1fe6>
  66caaa:	e9 a5 10 00 00       	jmp    66db54 <<gpui_canvas::text::planner::Planner>::shape+0x2ff4>
  66caaf:	48 8b 8c 24 d0 00 00 	mov    0xd0(%rsp),%rcx
  66cab6:	00 
  66cab7:	89 de                	mov    %ebx,%esi
  66cab9:	48 8d 04 7f          	lea    (%rdi,%rdi,2),%rax
  66cabd:	48 8b 94 24 f0 01 00 	mov    0x1f0(%rsp),%rdx
  66cac4:	00 
  66cac5:	f3 0f 10 44 c2 10    	movss  0x10(%rdx,%rax,8),%xmm0
  66cacb:	0f 57 c9             	xorps  %xmm1,%xmm1
  66cace:	0f 29 8c 24 e0 01 00 	movaps %xmm1,0x1e0(%rsp)
  66cad5:	00 
  66cad6:	bb 04 00 00 00       	mov    $0x4,%ebx
  66cadb:	b8 04 00 00 00       	mov    $0x4,%eax
  66cae0:	48 89 84 24 f0 00 00 	mov    %rax,0xf0(%rsp)
  66cae7:	00 
  66cae8:	48 89 8c 24 d0 00 00 	mov    %rcx,0xd0(%rsp)
  66caef:	00 
  66caf0:	f3 0f 11 84 24 c8 01 	movss  %xmm0,0x1c8(%rsp)
  66caf7:	00 00 
  66caf9:	f3 0f 11 84 24 30 01 	movss  %xmm0,0x130(%rsp)
  66cb00:	00 00 
  66cb02:	89 b4 24 cc 01 00 00 	mov    %esi,0x1cc(%rsp)
  66cb09:	89 74 24 54          	mov    %esi,0x54(%rsp)
  66cb0d:	0f 57 c0             	xorps  %xmm0,%xmm0
  66cb10:	0f 29 84 24 40 02 00 	movaps %xmm0,0x240(%rsp)
  66cb17:	00 
  66cb18:	83 bc 24 0c 01 00 00 	cmpl   $0x0,0x10c(%rsp)
  66cb1f:	00 
  66cb20:	0f 85 18 f8 ff ff    	jne    66c33e <<gpui_canvas::text::planner::Planner>::shape+0x17de>
  66cb26:	e9 82 f8 ff ff       	jmp    66c3ad <<gpui_canvas::text::planner::Planner>::shape+0x184d>
  66cb2b:	48 8b 94 24 e0 00 00 	mov    0xe0(%rsp),%rdx
  66cb32:	00 
  66cb33:	48 89 84 24 f0 00 00 	mov    %rax,0xf0(%rsp)
  66cb3a:	00 
  66cb3b:	e9 36 f8 ff ff       	jmp    66c376 <<gpui_canvas::text::planner::Planner>::shape+0x1816>
  66cb40:	0f 85 0e 10 00 00    	jne    66db54 <<gpui_canvas::text::planner::Planner>::shape+0x2ff4>
  66cb46:	48 89 e8             	mov    %rbp,%rax
  66cb49:	48 85 ed             	test   %rbp,%rbp
  66cb4c:	74 19                	je     66cb67 <<gpui_canvas::text::planner::Planner>::shape+0x2007>
  66cb4e:	48 3b 44 24 40       	cmp    0x40(%rsp),%rax
  66cb53:	73 0c                	jae    66cb61 <<gpui_canvas::text::planner::Planner>::shape+0x2001>
  66cb55:	41 80 3c 00 c0       	cmpb   $0xc0,(%r8,%rax,1)
  66cb5a:	7d 0b                	jge    66cb67 <<gpui_canvas::text::planner::Planner>::shape+0x2007>
  66cb5c:	e9 fe 0f 00 00       	jmp    66db5f <<gpui_canvas::text::planner::Planner>::shape+0x2fff>
  66cb61:	0f 85 f8 0f 00 00    	jne    66db5f <<gpui_canvas::text::planner::Planner>::shape+0x2fff>
  66cb67:	4c 89 b4 24 58 01 00 	mov    %r14,0x158(%rsp)
  66cb6e:	00 
  66cb6f:	4f 8d 34 38          	lea    (%r8,%r15,1),%r14
  66cb73:	4c 01 c0             	add    %r8,%rax
  66cb76:	48 89 84 24 e0 01 00 	mov    %rax,0x1e0(%rsp)
  66cb7d:	00 
  66cb7e:	66 90                	xchg   %ax,%ax
  66cb80:	4c 3b b4 24 e0 01 00 	cmp    0x1e0(%rsp),%r14
  66cb87:	00 
  66cb88:	0f 84 8c 00 00 00    	je     66cc1a <<gpui_canvas::text::planner::Planner>::shape+0x20ba>
  66cb8e:	41 0f b6 36          	movzbl (%r14),%esi
  66cb92:	40 84 f6             	test   %sil,%sil
  66cb95:	78 09                	js     66cba0 <<gpui_canvas::text::planner::Planner>::shape+0x2040>
  66cb97:	49 ff c6             	inc    %r14
  66cb9a:	eb 64                	jmp    66cc00 <<gpui_canvas::text::planner::Planner>::shape+0x20a0>
  66cb9c:	0f 1f 40 00          	nopl   0x0(%rax)
  66cba0:	89 f0                	mov    %esi,%eax
  66cba2:	83 e0 1f             	and    $0x1f,%eax
  66cba5:	41 0f b6 56 01       	movzbl 0x1(%r14),%edx
  66cbaa:	83 e2 3f             	and    $0x3f,%edx
  66cbad:	40 80 fe df          	cmp    $0xdf,%sil
  66cbb1:	76 2e                	jbe    66cbe1 <<gpui_canvas::text::planner::Planner>::shape+0x2081>
  66cbb3:	41 0f b6 4e 02       	movzbl 0x2(%r14),%ecx
  66cbb8:	c1 e2 06             	shl    $0x6,%edx
  66cbbb:	83 e1 3f             	and    $0x3f,%ecx
  66cbbe:	09 d1                	or     %edx,%ecx
  66cbc0:	40 80 fe f0          	cmp    $0xf0,%sil
  66cbc4:	72 28                	jb     66cbee <<gpui_canvas::text::planner::Planner>::shape+0x208e>
  66cbc6:	41 0f b6 76 03       	movzbl 0x3(%r14),%esi
  66cbcb:	49 83 c6 04          	add    $0x4,%r14
  66cbcf:	83 e0 07             	and    $0x7,%eax
  66cbd2:	c1 e0 12             	shl    $0x12,%eax
  66cbd5:	c1 e1 06             	shl    $0x6,%ecx
  66cbd8:	83 e6 3f             	and    $0x3f,%esi
  66cbdb:	09 ce                	or     %ecx,%esi
  66cbdd:	09 c6                	or     %eax,%esi
  66cbdf:	eb 1f                	jmp    66cc00 <<gpui_canvas::text::planner::Planner>::shape+0x20a0>
  66cbe1:	49 83 c6 02          	add    $0x2,%r14
  66cbe5:	c1 e0 06             	shl    $0x6,%eax
  66cbe8:	09 d0                	or     %edx,%eax
  66cbea:	89 c6                	mov    %eax,%esi
  66cbec:	eb 12                	jmp    66cc00 <<gpui_canvas::text::planner::Planner>::shape+0x20a0>
  66cbee:	49 83 c6 03          	add    $0x3,%r14
  66cbf2:	c1 e0 0c             	shl    $0xc,%eax
  66cbf5:	09 c1                	or     %eax,%ecx
  66cbf7:	89 ce                	mov    %ecx,%esi
  66cbf9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  66cc00:	48 8d 3d d1 32 11 00 	lea    0x1132d1(%rip),%rdi        # 77fed8 <anon.fcf2ae708c8bfcebac3bd597053acdb9.9.llvm.16263823325747306480+0x2b8>
  66cc07:	ff 15 9b e0 11 00    	call   *0x11e09b(%rip)        # 78aca8 <_DYNAMIC+0x620>
  66cc0d:	84 c0                	test   %al,%al
  66cc0f:	0f 85 6b ff ff ff    	jne    66cb80 <<gpui_canvas::text::planner::Planner>::shape+0x2020>
  66cc15:	e9 50 0f 00 00       	jmp    66db6a <<gpui_canvas::text::planner::Planner>::shape+0x300a>
  66cc1a:	31 c0                	xor    %eax,%eax
  66cc1c:	0f 57 c0             	xorps  %xmm0,%xmm0
  66cc1f:	f3 0f 10 8c 24 30 01 	movss  0x130(%rsp),%xmm1
  66cc26:	00 00 
  66cc28:	0f 2e c8             	ucomiss %xmm0,%xmm1
  66cc2b:	4c 8b b4 24 58 01 00 	mov    0x158(%rsp),%r14
  66cc32:	00 
  66cc33:	f3 0f 10 94 24 d4 01 	movss  0x1d4(%rsp),%xmm2
  66cc3a:	00 00 
  66cc3c:	0f 85 28 0f 00 00    	jne    66db6a <<gpui_canvas::text::planner::Planner>::shape+0x300a>
  66cc42:	0f 8b b2 f6 ff ff    	jnp    66c2fa <<gpui_canvas::text::planner::Planner>::shape+0x179a>
  66cc48:	e9 1d 0f 00 00       	jmp    66db6a <<gpui_canvas::text::planner::Planner>::shape+0x300a>
  66cc4d:	48 8b 94 24 e0 00 00 	mov    0xe0(%rsp),%rdx
  66cc54:	00 
  66cc55:	48 89 84 24 f0 00 00 	mov    %rax,0xf0(%rsp)
  66cc5c:	00 
  66cc5d:	48 89 8c 24 d0 00 00 	mov    %rcx,0xd0(%rsp)
  66cc64:	00 
  66cc65:	e9 0c f7 ff ff       	jmp    66c376 <<gpui_canvas::text::planner::Planner>::shape+0x1816>
  66cc6a:	48 8d bc 24 98 00 00 	lea    0x98(%rsp),%rdi
  66cc71:	00 
  66cc72:	48 8d b4 24 90 04 00 	lea    0x490(%rsp),%rsi
  66cc79:	00 
  66cc7a:	e8 81 1e 00 00       	call   66eb00 <<core::iter::adapters::flatten::FlattenCompat<core::iter::adapters::map::Map<core::ops::range::Range<u32>, <parley::layout::run::Run<()>>::glyph_source_ranges::{closure#0}>, core::iter::sources::repeat_n::RepeatN<core::ops::range::Range<usize>>> as core::iter::traits::iterator::Iterator>::next>
  66cc7f:	48 83 bc 24 98 00 00 	cmpq   $0x0,0x98(%rsp)
  66cc86:	00 00 
  66cc88:	0f 85 f9 0d 00 00    	jne    66da87 <<gpui_canvas::text::planner::Planner>::shape+0x2f27>
  66cc8e:	48 8b 84 24 68 01 00 	mov    0x168(%rsp),%rax
  66cc95:	00 
  66cc96:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  66cc9a:	0f 84 b0 f1 ff ff    	je     66be50 <<gpui_canvas::text::planner::Planner>::shape+0x12f0>
  66cca0:	48 8b 8c 24 88 03 00 	mov    0x388(%rsp),%rcx
  66cca7:	00 
  66cca8:	48 8b 94 24 b8 01 00 	mov    0x1b8(%rsp),%rdx
  66ccaf:	00 
  66ccb0:	48 3b 94 24 90 00 00 	cmp    0x90(%rsp),%rdx
  66ccb7:	00 
  66ccb8:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
  66ccbd:	75 07                	jne    66ccc6 <<gpui_canvas::text::planner::Planner>::shape+0x2166>
  66ccbf:	31 db                	xor    %ebx,%ebx
  66ccc1:	45 31 f6             	xor    %r14d,%r14d
  66ccc4:	eb 75                	jmp    66cd3b <<gpui_canvas::text::planner::Planner>::shape+0x21db>
  66ccc6:	48 8b 94 24 98 03 00 	mov    0x398(%rsp),%rdx
  66cccd:	00 
  66ccce:	48 85 d2             	test   %rdx,%rdx
  66ccd1:	48 0f 44 d1          	cmove  %rcx,%rdx
  66ccd5:	48 8b 1a             	mov    (%rdx),%rbx
  66ccd8:	4c 8b 72 08          	mov    0x8(%rdx),%r14
  66ccdc:	4c 39 f3             	cmp    %r14,%rbx
  66ccdf:	0f 87 a2 0d 00 00    	ja     66da87 <<gpui_canvas::text::planner::Planner>::shape+0x2f27>
  66cce5:	48 85 db             	test   %rbx,%rbx
  66cce8:	74 18                	je     66cd02 <<gpui_canvas::text::planner::Planner>::shape+0x21a2>
  66ccea:	48 39 f3             	cmp    %rsi,%rbx
  66cced:	73 17                	jae    66cd06 <<gpui_canvas::text::planner::Planner>::shape+0x21a6>
  66ccef:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
  66ccf6:	00 
  66ccf7:	80 3c 1a bf          	cmpb   $0xbf,(%rdx,%rbx,1)
  66ccfb:	7f 12                	jg     66cd0f <<gpui_canvas::text::planner::Planner>::shape+0x21af>
  66ccfd:	e9 85 0d 00 00       	jmp    66da87 <<gpui_canvas::text::planner::Planner>::shape+0x2f27>
  66cd02:	31 db                	xor    %ebx,%ebx
  66cd04:	eb 09                	jmp    66cd0f <<gpui_canvas::text::planner::Planner>::shape+0x21af>
  66cd06:	48 89 f3             	mov    %rsi,%rbx
  66cd09:	0f 85 78 0d 00 00    	jne    66da87 <<gpui_canvas::text::planner::Planner>::shape+0x2f27>
  66cd0f:	4d 85 f6             	test   %r14,%r14
  66cd12:	74 19                	je     66cd2d <<gpui_canvas::text::planner::Planner>::shape+0x21cd>
  66cd14:	49 39 f6             	cmp    %rsi,%r14
  66cd17:	73 19                	jae    66cd32 <<gpui_canvas::text::planner::Planner>::shape+0x21d2>
  66cd19:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
  66cd20:	00 
  66cd21:	42 80 3c 32 c0       	cmpb   $0xc0,(%rdx,%r14,1)
  66cd26:	7d 13                	jge    66cd3b <<gpui_canvas::text::planner::Planner>::shape+0x21db>
  66cd28:	e9 5a 0d 00 00       	jmp    66da87 <<gpui_canvas::text::planner::Planner>::shape+0x2f27>
  66cd2d:	45 31 f6             	xor    %r14d,%r14d
  66cd30:	eb 09                	jmp    66cd3b <<gpui_canvas::text::planner::Planner>::shape+0x21db>
  66cd32:	49 89 f6             	mov    %rsi,%r14
  66cd35:	0f 85 4c 0d 00 00    	jne    66da87 <<gpui_canvas::text::planner::Planner>::shape+0x2f27>
  66cd3b:	8b 94 24 28 01 00 00 	mov    0x128(%rsp),%edx
  66cd42:	89 54 24 20          	mov    %edx,0x20(%rsp)
  66cd46:	0f b6 a9 8c 00 00 00 	movzbl 0x8c(%rcx),%ebp
  66cd4d:	4c 8b bc 24 78 01 00 	mov    0x178(%rsp),%r15
  66cd54:	00 
  66cd55:	49 39 c7             	cmp    %rax,%r15
  66cd58:	75 0e                	jne    66cd68 <<gpui_canvas::text::planner::Planner>::shape+0x2208>
  66cd5a:	48 8d bc 24 68 01 00 	lea    0x168(%rsp),%rdi
  66cd61:	00 
  66cd62:	ff 15 c8 dd 11 00    	call   *0x11ddc8(%rip)        # 78ab30 <_DYNAMIC+0x4a8>
  66cd68:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  66cd6f:	00 
  66cd70:	01 c3                	add    %eax,%ebx
  66cd72:	41 01 c6             	add    %eax,%r14d
  66cd75:	40 80 e5 01          	and    $0x1,%bpl
  66cd79:	48 8b 84 24 70 01 00 	mov    0x170(%rsp),%rax
  66cd80:	00 
  66cd81:	4b 8d 0c 7f          	lea    (%r15,%r15,2),%rcx
  66cd85:	89 1c c8             	mov    %ebx,(%rax,%rcx,8)
  66cd88:	44 89 74 c8 04       	mov    %r14d,0x4(%rax,%rcx,8)
  66cd8d:	48 8b 94 24 e8 02 00 	mov    0x2e8(%rsp),%rdx
  66cd94:	00 
  66cd95:	89 54 c8 08          	mov    %edx,0x8(%rax,%rcx,8)
  66cd99:	8b 54 24 20          	mov    0x20(%rsp),%edx
  66cd9d:	89 54 c8 0c          	mov    %edx,0xc(%rax,%rcx,8)
  66cda1:	48 8b 94 24 60 02 00 	mov    0x260(%rsp),%rdx
  66cda8:	00 
  66cda9:	89 54 c8 10          	mov    %edx,0x10(%rax,%rcx,8)
  66cdad:	48 8b 94 24 68 02 00 	mov    0x268(%rsp),%rdx
  66cdb4:	00 
  66cdb5:	88 54 c8 14          	mov    %dl,0x14(%rax,%rcx,8)
  66cdb9:	40 88 6c c8 15       	mov    %bpl,0x15(%rax,%rcx,8)
  66cdbe:	49 ff c7             	inc    %r15
  66cdc1:	4c 89 bc 24 78 01 00 	mov    %r15,0x178(%rsp)
  66cdc8:	00 
  66cdc9:	e9 82 f0 ff ff       	jmp    66be50 <<gpui_canvas::text::planner::Planner>::shape+0x12f0>
  66cdce:	48 8b 84 24 f8 02 00 	mov    0x2f8(%rsp),%rax
  66cdd5:	00 
  66cdd6:	48 39 84 24 f8 00 00 	cmp    %rax,0xf8(%rsp)
  66cddd:	00 
  66cdde:	48 8b ac 24 90 00 00 	mov    0x90(%rsp),%rbp
  66cde5:	00 
  66cde6:	4c 8b b4 24 b8 01 00 	mov    0x1b8(%rsp),%r14
  66cded:	00 
  66cdee:	4c 8b 7c 24 40       	mov    0x40(%rsp),%r15
  66cdf3:	0f 85 d1 eb ff ff    	jne    66b9ca <<gpui_canvas::text::planner::Planner>::shape+0xe6a>
  66cdf9:	48 83 bc 24 68 01 00 	cmpq   $0xffffffffffffffff,0x168(%rsp)
  66ce00:	00 ff 
  66ce02:	0f 84 11 07 00 00    	je     66d519 <<gpui_canvas::text::planner::Planner>::shape+0x29b9>
  66ce08:	48 83 bc 24 98 01 00 	cmpq   $0xffffffffffffffff,0x198(%rsp)
  66ce0f:	00 ff 
  66ce11:	0f 84 02 07 00 00    	je     66d519 <<gpui_canvas::text::planner::Planner>::shape+0x29b9>
  66ce17:	48 89 ac 24 98 00 00 	mov    %rbp,0x98(%rsp)
  66ce1e:	00 
  66ce1f:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  66ce25:	f3 0f 11 84 24 10 01 	movss  %xmm0,0x110(%rsp)
  66ce2c:	00 00 
  66ce2e:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  66ce33:	48 89 84 24 30 03 00 	mov    %rax,0x330(%rsp)
  66ce3a:	00 
  66ce3b:	48 8d 84 24 10 01 00 	lea    0x110(%rsp),%rax
  66ce42:	00 
  66ce43:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
  66ce4a:	00 
  66ce4b:	48 8d 84 24 98 00 00 	lea    0x98(%rsp),%rax
  66ce52:	00 
  66ce53:	48 89 84 24 40 03 00 	mov    %rax,0x340(%rsp)
  66ce5a:	00 
  66ce5b:	48 8d 84 24 98 01 00 	lea    0x198(%rsp),%rax
  66ce62:	00 
  66ce63:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
  66ce6a:	00 
  66ce6b:	4c 03 b4 24 60 01 00 	add    0x160(%rsp),%r14
  66ce72:	00 
  66ce73:	48 c7 84 24 e0 06 00 	movq   $0x0,0x6e0(%rsp)
  66ce7a:	00 00 00 00 00 
  66ce7f:	48 c7 84 24 e8 06 00 	movq   $0x8,0x6e8(%rsp)
  66ce86:	00 08 00 00 00 
  66ce8b:	48 c7 84 24 f0 06 00 	movq   $0x0,0x6f0(%rsp)
  66ce92:	00 00 00 00 00 
  66ce97:	c7 84 24 00 07 00 00 	movl   $0xffffffff,0x700(%rsp)
  66ce9e:	ff ff ff ff 
  66cea2:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  66cea9:	00 
  66ceaa:	48 89 84 24 08 07 00 	mov    %rax,0x708(%rsp)
  66ceb1:	00 
  66ceb2:	4c 89 b4 24 10 07 00 	mov    %r14,0x710(%rsp)
  66ceb9:	00 
  66ceba:	48 c7 84 24 18 07 00 	movq   $0x0,0x718(%rsp)
  66cec1:	00 00 00 00 00 
  66cec6:	48 8d 05 7b 31 11 00 	lea    0x11317b(%rip),%rax        # 780048 <anon.fcf2ae708c8bfcebac3bd597053acdb9.9.llvm.16263823325747306480+0x428>
  66cecd:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
  66ced4:	00 
  66ced5:	48 8d 05 84 b8 ff ff 	lea    -0x477c(%rip),%rax        # 668760 <icu_segmenter::rule_segmenter_v1::empty_handle_complex::<icu_segmenter::scaffold::Utf8>>
  66cedc:	48 89 84 24 28 07 00 	mov    %rax,0x728(%rsp)
  66cee3:	00 
  66cee4:	4c 89 bc 24 30 07 00 	mov    %r15,0x730(%rsp)
  66ceeb:	00 
  66ceec:	48 c7 84 24 38 07 00 	movq   $0x0,0x738(%rsp)
  66cef3:	00 00 00 00 00 
  66cef8:	48 c7 84 24 68 07 00 	movq   $0x0,0x768(%rsp)
  66ceff:	00 00 00 00 00 
  66cf04:	c6 84 24 70 07 00 00 	movb   $0x0,0x770(%rsp)
  66cf0b:	00 
  66cf0c:	48 8d bc 24 e0 06 00 	lea    0x6e0(%rsp),%rdi
  66cf13:	00 
  66cf14:	e8 e7 a9 00 00       	call   677900 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  66cf19:	48 83 f8 01          	cmp    $0x1,%rax
  66cf1d:	0f 85 a3 01 00 00    	jne    66d0c6 <<gpui_canvas::text::planner::Planner>::shape+0x2566>
  66cf23:	48 8d bc 24 e0 06 00 	lea    0x6e0(%rsp),%rdi
  66cf2a:	00 
  66cf2b:	e8 d0 a9 00 00       	call   677900 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  66cf30:	48 83 f8 01          	cmp    $0x1,%rax
  66cf34:	0f 85 8c 01 00 00    	jne    66d0c6 <<gpui_canvas::text::planner::Planner>::shape+0x2566>
  66cf3a:	48 8d bc 24 e0 06 00 	lea    0x6e0(%rsp),%rdi
  66cf41:	00 
  66cf42:	e8 b9 a9 00 00       	call   677900 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  66cf47:	48 83 f8 01          	cmp    $0x1,%rax
  66cf4b:	0f 85 75 01 00 00    	jne    66d0c6 <<gpui_canvas::text::planner::Planner>::shape+0x2566>
  66cf51:	48 8d bc 24 e0 06 00 	lea    0x6e0(%rsp),%rdi
  66cf58:	00 
  66cf59:	e8 a2 a9 00 00       	call   677900 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  66cf5e:	48 83 f8 01          	cmp    $0x1,%rax
  66cf62:	0f 85 5e 01 00 00    	jne    66d0c6 <<gpui_canvas::text::planner::Planner>::shape+0x2566>
  66cf68:	48 8d bc 24 e0 06 00 	lea    0x6e0(%rsp),%rdi
  66cf6f:	00 
  66cf70:	e8 8b a9 00 00       	call   677900 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  66cf75:	48 83 f8 01          	cmp    $0x1,%rax
  66cf79:	0f 85 47 01 00 00    	jne    66d0c6 <<gpui_canvas::text::planner::Planner>::shape+0x2566>
  66cf7f:	48 8d bc 24 e0 06 00 	lea    0x6e0(%rsp),%rdi
  66cf86:	00 
  66cf87:	e8 74 a9 00 00       	call   677900 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  66cf8c:	48 83 f8 01          	cmp    $0x1,%rax
  66cf90:	0f 85 30 01 00 00    	jne    66d0c6 <<gpui_canvas::text::planner::Planner>::shape+0x2566>
  66cf96:	48 8d bc 24 e0 06 00 	lea    0x6e0(%rsp),%rdi
  66cf9d:	00 
  66cf9e:	e8 5d a9 00 00       	call   677900 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  66cfa3:	48 83 f8 01          	cmp    $0x1,%rax
  66cfa7:	0f 85 19 01 00 00    	jne    66d0c6 <<gpui_canvas::text::planner::Planner>::shape+0x2566>
  66cfad:	48 8d bc 24 e0 06 00 	lea    0x6e0(%rsp),%rdi
  66cfb4:	00 
  66cfb5:	e8 46 a9 00 00       	call   677900 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  66cfba:	a8 01                	test   $0x1,%al
  66cfbc:	0f 84 04 01 00 00    	je     66d0c6 <<gpui_canvas::text::planner::Planner>::shape+0x2566>
  66cfc2:	48 8d bc 24 e0 06 00 	lea    0x6e0(%rsp),%rdi
  66cfc9:	00 
  66cfca:	e8 31 a9 00 00       	call   677900 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  66cfcf:	48 83 f8 01          	cmp    $0x1,%rax
  66cfd3:	0f 85 ed 00 00 00    	jne    66d0c6 <<gpui_canvas::text::planner::Planner>::shape+0x2566>
  66cfd9:	48 8b b4 24 e0 06 00 	mov    0x6e0(%rsp),%rsi
  66cfe0:	00 
  66cfe1:	48 85 f6             	test   %rsi,%rsi
  66cfe4:	74 17                	je     66cffd <<gpui_canvas::text::planner::Planner>::shape+0x249d>
  66cfe6:	48 8b bc 24 e8 06 00 	mov    0x6e8(%rsp),%rdi
  66cfed:	00 
  66cfee:	48 c1 e6 03          	shl    $0x3,%rsi
  66cff2:	ba 08 00 00 00       	mov    $0x8,%edx
  66cff7:	ff 15 c3 d8 11 00    	call   *0x11d8c3(%rip)        # 78a8c0 <_DYNAMIC+0x238>
  66cffd:	48 c7 84 24 e0 06 00 	movq   $0x0,0x6e0(%rsp)
  66d004:	00 00 00 00 00 
  66d009:	48 c7 84 24 e8 06 00 	movq   $0x8,0x6e8(%rsp)
  66d010:	00 08 00 00 00 
  66d015:	48 c7 84 24 f0 06 00 	movq   $0x0,0x6f0(%rsp)
  66d01c:	00 00 00 00 00 
  66d021:	c7 84 24 00 07 00 00 	movl   $0xffffffff,0x700(%rsp)
  66d028:	ff ff ff ff 
  66d02c:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  66d033:	00 
  66d034:	48 89 84 24 08 07 00 	mov    %rax,0x708(%rsp)
  66d03b:	00 
  66d03c:	4c 89 b4 24 10 07 00 	mov    %r14,0x710(%rsp)
  66d043:	00 
  66d044:	48 c7 84 24 18 07 00 	movq   $0x0,0x718(%rsp)
  66d04b:	00 00 00 00 00 
  66d050:	48 8d 05 f1 2f 11 00 	lea    0x112ff1(%rip),%rax        # 780048 <anon.fcf2ae708c8bfcebac3bd597053acdb9.9.llvm.16263823325747306480+0x428>
  66d057:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
  66d05e:	00 
  66d05f:	48 8d 05 fa b6 ff ff 	lea    -0x4906(%rip),%rax        # 668760 <icu_segmenter::rule_segmenter_v1::empty_handle_complex::<icu_segmenter::scaffold::Utf8>>
  66d066:	48 89 84 24 28 07 00 	mov    %rax,0x728(%rsp)
  66d06d:	00 
  66d06e:	4c 89 bc 24 30 07 00 	mov    %r15,0x730(%rsp)
  66d075:	00 
  66d076:	48 c7 84 24 38 07 00 	movq   $0x0,0x738(%rsp)
  66d07d:	00 00 00 00 00 
  66d082:	48 c7 84 24 68 07 00 	movq   $0x0,0x768(%rsp)
  66d089:	00 00 00 00 00 
  66d08e:	c6 84 24 70 07 00 00 	movb   $0x0,0x770(%rsp)
  66d095:	00 
  66d096:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  66d09b:	48 8d b4 24 e0 06 00 	lea    0x6e0(%rsp),%rsi
  66d0a2:	00 
  66d0a3:	f3 0f 10 05 c1 07 9b 	movss  -0x64f83f(%rip),%xmm0        # 1d86c <GCC_except_table0+0x24>
  66d0aa:	ff 
  66d0ab:	48 8d 94 24 30 03 00 	lea    0x330(%rsp),%rdx
  66d0b2:	00 
  66d0b3:	e8 e8 c9 00 00       	call   679aa0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>>
  66d0b8:	83 f8 ff             	cmp    $0xffffffff,%eax
  66d0bb:	0f 84 58 04 00 00    	je     66d519 <<gpui_canvas::text::planner::Planner>::shape+0x29b9>
  66d0c1:	e9 a0 0f 00 00       	jmp    66e066 <<gpui_canvas::text::planner::Planner>::shape+0x3506>
  66d0c6:	48 8b b4 24 e0 06 00 	mov    0x6e0(%rsp),%rsi
  66d0cd:	00 
  66d0ce:	48 85 f6             	test   %rsi,%rsi
  66d0d1:	74 17                	je     66d0ea <<gpui_canvas::text::planner::Planner>::shape+0x258a>
  66d0d3:	48 8b bc 24 e8 06 00 	mov    0x6e8(%rsp),%rdi
  66d0da:	00 
  66d0db:	48 c1 e6 03          	shl    $0x3,%rsi
  66d0df:	ba 08 00 00 00       	mov    $0x8,%edx
  66d0e4:	ff 15 d6 d7 11 00    	call   *0x11d7d6(%rip)        # 78a8c0 <_DYNAMIC+0x238>
  66d0ea:	48 c7 84 24 e0 06 00 	movq   $0x0,0x6e0(%rsp)
  66d0f1:	00 00 00 00 00 
  66d0f6:	48 c7 84 24 e8 06 00 	movq   $0x8,0x6e8(%rsp)
  66d0fd:	00 08 00 00 00 
  66d102:	48 c7 84 24 f0 06 00 	movq   $0x0,0x6f0(%rsp)
  66d109:	00 00 00 00 00 
  66d10e:	c7 84 24 00 07 00 00 	movl   $0xffffffff,0x700(%rsp)
  66d115:	ff ff ff ff 
  66d119:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  66d120:	00 
  66d121:	48 89 84 24 08 07 00 	mov    %rax,0x708(%rsp)
  66d128:	00 
  66d129:	4c 89 b4 24 10 07 00 	mov    %r14,0x710(%rsp)
  66d130:	00 
  66d131:	48 c7 84 24 18 07 00 	movq   $0x0,0x718(%rsp)
  66d138:	00 00 00 00 00 
  66d13d:	48 8d 05 04 2f 11 00 	lea    0x112f04(%rip),%rax        # 780048 <anon.fcf2ae708c8bfcebac3bd597053acdb9.9.llvm.16263823325747306480+0x428>
  66d144:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
  66d14b:	00 
  66d14c:	48 8d 05 0d b6 ff ff 	lea    -0x49f3(%rip),%rax        # 668760 <icu_segmenter::rule_segmenter_v1::empty_handle_complex::<icu_segmenter::scaffold::Utf8>>
  66d153:	48 89 84 24 28 07 00 	mov    %rax,0x728(%rsp)
  66d15a:	00 
  66d15b:	4c 89 bc 24 30 07 00 	mov    %r15,0x730(%rsp)
  66d162:	00 
  66d163:	48 c7 84 24 38 07 00 	movq   $0x0,0x738(%rsp)
  66d16a:	00 00 00 00 00 
  66d16f:	48 c7 84 24 68 07 00 	movq   $0x0,0x768(%rsp)
  66d176:	00 00 00 00 00 
  66d17b:	c6 84 24 70 07 00 00 	movb   $0x0,0x770(%rsp)
  66d182:	00 
  66d183:	eb 43                	jmp    66d1c8 <<gpui_canvas::text::planner::Planner>::shape+0x2668>
  66d185:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  66d18c:	00 00 00 00 
  66d190:	0f 28 84 24 80 00 00 	movaps 0x80(%rsp),%xmm0
  66d197:	00 
  66d198:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
  66d19d:	48 8b 84 24 a0 01 00 	mov    0x1a0(%rsp),%rax
  66d1a4:	00 
  66d1a5:	48 8d 0c 5b          	lea    (%rbx,%rbx,2),%rcx
  66d1a9:	44 89 3c 88          	mov    %r15d,(%rax,%rcx,4)
  66d1ad:	0f 28 44 24 20       	movaps 0x20(%rsp),%xmm0
  66d1b2:	f3 0f 11 44 88 04    	movss  %xmm0,0x4(%rax,%rcx,4)
  66d1b8:	40 88 6c 88 08       	mov    %bpl,0x8(%rax,%rcx,4)
  66d1bd:	48 ff c3             	inc    %rbx
  66d1c0:	48 89 9c 24 a8 01 00 	mov    %rbx,0x1a8(%rsp)
  66d1c7:	00 
  66d1c8:	48 8d bc 24 e0 06 00 	lea    0x6e0(%rsp),%rdi
  66d1cf:	00 
  66d1d0:	e8 2b a7 00 00       	call   677900 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  66d1d5:	48 83 f8 01          	cmp    $0x1,%rax
  66d1d9:	0f 85 16 03 00 00    	jne    66d4f5 <<gpui_canvas::text::planner::Planner>::shape+0x2995>
  66d1df:	49 89 d6             	mov    %rdx,%r14
  66d1e2:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  66d1e7:	48 89 d6             	mov    %rdx,%rsi
  66d1ea:	ba 01 00 00 00       	mov    $0x1,%edx
  66d1ef:	e8 4c 93 01 00       	call   686540 <<parley::editing::cursor::Cursor>::from_byte_index::<()>>
  66d1f4:	48 89 c3             	mov    %rax,%rbx
  66d1f7:	48 89 84 24 80 03 00 	mov    %rax,0x380(%rsp)
  66d1fe:	00 
  66d1ff:	80 e2 01             	and    $0x1,%dl
  66d202:	88 94 24 88 03 00 00 	mov    %dl,0x388(%rsp)
  66d209:	4c 39 f0             	cmp    %r14,%rax
  66d20c:	0f 85 ae 00 00 00    	jne    66d2c0 <<gpui_canvas::text::planner::Planner>::shape+0x2760>
  66d212:	48 8d bc 24 90 04 00 	lea    0x490(%rsp),%rdi
  66d219:	00 
  66d21a:	48 8d b4 24 80 03 00 	lea    0x380(%rsp),%rsi
  66d221:	00 
  66d222:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  66d227:	f3 0f 10 05 3d 06 9b 	movss  -0x64f9c3(%rip),%xmm0        # 1d86c <GCC_except_table0+0x24>
  66d22e:	ff 
  66d22f:	e8 cc 93 01 00       	call   686600 <<parley::editing::cursor::Cursor>::geometry::<()>>
  66d234:	f3 0f 10 84 24 10 01 	movss  0x110(%rsp),%xmm0
  66d23b:	00 00 
  66d23d:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
  66d241:	f2 0f 58 84 24 98 04 	addsd  0x498(%rsp),%xmm0
  66d248:	00 00 
  66d24a:	66 0f 28 8c 24 90 04 	movapd 0x490(%rsp),%xmm1
  66d251:	00 00 
  66d253:	66 0f 28 94 24 a0 04 	movapd 0x4a0(%rsp),%xmm2
  66d25a:	00 00 
  66d25c:	66 0f 5c d1          	subpd  %xmm1,%xmm2
  66d260:	66 0f 14 c8          	unpcklpd %xmm0,%xmm1
  66d264:	66 0f 5a c9          	cvtpd2ps %xmm1,%xmm1
  66d268:	66 0f 5a d2          	cvtpd2ps %xmm2,%xmm2
  66d26c:	66 0f 29 4c 24 20    	movapd %xmm1,0x20(%rsp)
  66d272:	66 0f 29 54 24 70    	movapd %xmm2,0x70(%rsp)
  66d278:	66 0f 14 ca          	unpcklpd %xmm2,%xmm1
  66d27c:	66 0f 54 0d 1c 83 9b 	andpd  -0x647ce4(%rip),%xmm1        # 255a0 <anon.0798ea9c2d8130e279e9b803b375062d.0.llvm.722421148570242323+0x7e0>
  66d283:	ff 
  66d284:	66 0f 66 0d e4 7c 9b 	pcmpgtd -0x64831c(%rip),%xmm1        # 24f70 <anon.0798ea9c2d8130e279e9b803b375062d.0.llvm.722421148570242323+0x1b0>
  66d28b:	ff 
  66d28c:	0f 50 c1             	movmskps %xmm1,%eax
  66d28f:	85 c0                	test   %eax,%eax
  66d291:	0f 85 a4 07 00 00    	jne    66da3b <<gpui_canvas::text::planner::Planner>::shape+0x2edb>
  66d297:	f2 0f 5a c0          	cvtsd2ss %xmm0,%xmm0
  66d29b:	f3 0f 11 84 24 e0 00 	movss  %xmm0,0xe0(%rsp)
  66d2a2:	00 00 
  66d2a4:	0f 28 44 24 70       	movaps 0x70(%rsp),%xmm0
  66d2a9:	0f c6 c0 55          	shufps $0x55,%xmm0,%xmm0
  66d2ad:	0f 29 84 24 30 01 00 	movaps %xmm0,0x130(%rsp)
  66d2b4:	00 
  66d2b5:	eb 09                	jmp    66d2c0 <<gpui_canvas::text::planner::Planner>::shape+0x2760>
  66d2b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  66d2be:	00 00 
  66d2c0:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  66d2c5:	4c 89 f6             	mov    %r14,%rsi
  66d2c8:	31 d2                	xor    %edx,%edx
  66d2ca:	e8 71 92 01 00       	call   686540 <<parley::editing::cursor::Cursor>::from_byte_index::<()>>
  66d2cf:	48 89 c5             	mov    %rax,%rbp
  66d2d2:	48 89 84 24 80 03 00 	mov    %rax,0x380(%rsp)
  66d2d9:	00 
  66d2da:	80 e2 01             	and    $0x1,%dl
  66d2dd:	88 94 24 88 03 00 00 	mov    %dl,0x388(%rsp)
  66d2e4:	4c 39 f0             	cmp    %r14,%rax
  66d2e7:	0f 85 23 01 00 00    	jne    66d410 <<gpui_canvas::text::planner::Planner>::shape+0x28b0>
  66d2ed:	48 8d bc 24 90 04 00 	lea    0x490(%rsp),%rdi
  66d2f4:	00 
  66d2f5:	48 8d b4 24 80 03 00 	lea    0x380(%rsp),%rsi
  66d2fc:	00 
  66d2fd:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  66d302:	f3 0f 10 05 62 05 9b 	movss  -0x64fa9e(%rip),%xmm0        # 1d86c <GCC_except_table0+0x24>
  66d309:	ff 
  66d30a:	e8 f1 92 01 00       	call   686600 <<parley::editing::cursor::Cursor>::geometry::<()>>
  66d30f:	f3 0f 10 84 24 10 01 	movss  0x110(%rsp),%xmm0
  66d316:	00 00 
  66d318:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
  66d31c:	f2 0f 58 84 24 98 04 	addsd  0x498(%rsp),%xmm0
  66d323:	00 00 
  66d325:	66 0f 28 8c 24 90 04 	movapd 0x490(%rsp),%xmm1
  66d32c:	00 00 
  66d32e:	66 0f 28 94 24 a0 04 	movapd 0x4a0(%rsp),%xmm2
  66d335:	00 00 
  66d337:	66 0f 5c d1          	subpd  %xmm1,%xmm2
  66d33b:	66 0f 14 c8          	unpcklpd %xmm0,%xmm1
  66d33f:	66 0f 5a c9          	cvtpd2ps %xmm1,%xmm1
  66d343:	66 0f 5a c2          	cvtpd2ps %xmm2,%xmm0
  66d347:	66 0f 14 c8          	unpcklpd %xmm0,%xmm1
  66d34b:	66 0f 29 8c 24 80 00 	movapd %xmm1,0x80(%rsp)
  66d352:	00 00 
  66d354:	66 0f 28 c1          	movapd %xmm1,%xmm0
  66d358:	66 0f 54 05 40 82 9b 	andpd  -0x647dc0(%rip),%xmm0        # 255a0 <anon.0798ea9c2d8130e279e9b803b375062d.0.llvm.722421148570242323+0x7e0>
  66d35f:	ff 
  66d360:	66 0f 66 05 08 7c 9b 	pcmpgtd -0x6483f8(%rip),%xmm0        # 24f70 <anon.0798ea9c2d8130e279e9b803b375062d.0.llvm.722421148570242323+0x1b0>
  66d367:	ff 
  66d368:	0f 50 c0             	movmskps %xmm0,%eax
  66d36b:	85 c0                	test   %eax,%eax
  66d36d:	0f 85 c8 06 00 00    	jne    66da3b <<gpui_canvas::text::planner::Planner>::shape+0x2edb>
  66d373:	44 8b bc 24 98 00 00 	mov    0x98(%rsp),%r15d
  66d37a:	00 
  66d37b:	45 01 f7             	add    %r14d,%r15d
  66d37e:	4c 39 f3             	cmp    %r14,%rbx
  66d381:	0f 85 09 01 00 00    	jne    66d490 <<gpui_canvas::text::planner::Planner>::shape+0x2930>
  66d387:	0f 28 44 24 20       	movaps 0x20(%rsp),%xmm0
  66d38c:	0f 28 8c 24 80 00 00 	movaps 0x80(%rsp),%xmm1
  66d393:	00 
  66d394:	0f 2e c1             	ucomiss %xmm1,%xmm0
  66d397:	0f 85 87 00 00 00    	jne    66d424 <<gpui_canvas::text::planner::Planner>::shape+0x28c4>
  66d39d:	0f 8a 81 00 00 00    	jp     66d424 <<gpui_canvas::text::planner::Planner>::shape+0x28c4>
  66d3a3:	0f 28 c1             	movaps %xmm1,%xmm0
  66d3a6:	0f c6 c1 55          	shufps $0x55,%xmm1,%xmm0
  66d3aa:	f3 0f 10 94 24 e0 00 	movss  0xe0(%rsp),%xmm2
  66d3b1:	00 00 
  66d3b3:	0f 2e d0             	ucomiss %xmm0,%xmm2
  66d3b6:	75 6c                	jne    66d424 <<gpui_canvas::text::planner::Planner>::shape+0x28c4>
  66d3b8:	7a 6a                	jp     66d424 <<gpui_canvas::text::planner::Planner>::shape+0x28c4>
  66d3ba:	0f 28 c1             	movaps %xmm1,%xmm0
  66d3bd:	66 0f 15 c1          	unpckhpd %xmm1,%xmm0
  66d3c1:	0f 28 54 24 70       	movaps 0x70(%rsp),%xmm2
  66d3c6:	0f 2e d0             	ucomiss %xmm0,%xmm2
  66d3c9:	75 59                	jne    66d424 <<gpui_canvas::text::planner::Planner>::shape+0x28c4>
  66d3cb:	7a 57                	jp     66d424 <<gpui_canvas::text::planner::Planner>::shape+0x28c4>
  66d3cd:	0f 28 c1             	movaps %xmm1,%xmm0
  66d3d0:	0f c6 c1 ff          	shufps $0xff,%xmm1,%xmm0
  66d3d4:	0f 28 8c 24 30 01 00 	movaps 0x130(%rsp),%xmm1
  66d3db:	00 
  66d3dc:	0f 2e c8             	ucomiss %xmm0,%xmm1
  66d3df:	75 43                	jne    66d424 <<gpui_canvas::text::planner::Planner>::shape+0x28c4>
  66d3e1:	7a 41                	jp     66d424 <<gpui_canvas::text::planner::Planner>::shape+0x28c4>
  66d3e3:	48 8b 9c 24 a8 01 00 	mov    0x1a8(%rsp),%rbx
  66d3ea:	00 
  66d3eb:	40 b5 03             	mov    $0x3,%bpl
  66d3ee:	48 3b 9c 24 98 01 00 	cmp    0x198(%rsp),%rbx
  66d3f5:	00 
  66d3f6:	0f 85 a1 fd ff ff    	jne    66d19d <<gpui_canvas::text::planner::Planner>::shape+0x263d>
  66d3fc:	48 8d bc 24 98 01 00 	lea    0x198(%rsp),%rdi
  66d403:	00 
  66d404:	ff 15 2e d7 11 00    	call   *0x11d72e(%rip)        # 78ab38 <_DYNAMIC+0x4b0>
  66d40a:	e9 8e fd ff ff       	jmp    66d19d <<gpui_canvas::text::planner::Planner>::shape+0x263d>
  66d40f:	90                   	nop
  66d410:	4c 39 f3             	cmp    %r14,%rbx
  66d413:	0f 85 af fd ff ff    	jne    66d1c8 <<gpui_canvas::text::planner::Planner>::shape+0x2668>
  66d419:	44 8b bc 24 98 00 00 	mov    0x98(%rsp),%r15d
  66d420:	00 
  66d421:	45 01 f7             	add    %r14d,%r15d
  66d424:	48 8b 9c 24 a8 01 00 	mov    0x1a8(%rsp),%rbx
  66d42b:	00 
  66d42c:	48 3b 9c 24 98 01 00 	cmp    0x198(%rsp),%rbx
  66d433:	00 
  66d434:	75 0e                	jne    66d444 <<gpui_canvas::text::planner::Planner>::shape+0x28e4>
  66d436:	48 8d bc 24 98 01 00 	lea    0x198(%rsp),%rdi
  66d43d:	00 
  66d43e:	ff 15 f4 d6 11 00    	call   *0x11d6f4(%rip)        # 78ab38 <_DYNAMIC+0x4b0>
  66d444:	48 8b 84 24 a0 01 00 	mov    0x1a0(%rsp),%rax
  66d44b:	00 
  66d44c:	48 8d 0c 5b          	lea    (%rbx,%rbx,2),%rcx
  66d450:	44 89 3c 88          	mov    %r15d,(%rax,%rcx,4)
  66d454:	0f 28 44 24 20       	movaps 0x20(%rsp),%xmm0
  66d459:	f3 0f 11 44 88 04    	movss  %xmm0,0x4(%rax,%rcx,4)
  66d45f:	c6 44 88 08 01       	movb   $0x1,0x8(%rax,%rcx,4)
  66d464:	48 ff c3             	inc    %rbx
  66d467:	48 89 9c 24 a8 01 00 	mov    %rbx,0x1a8(%rsp)
  66d46e:	00 
  66d46f:	4c 39 f5             	cmp    %r14,%rbp
  66d472:	0f 85 50 fd ff ff    	jne    66d1c8 <<gpui_canvas::text::planner::Planner>::shape+0x2668>
  66d478:	40 b5 02             	mov    $0x2,%bpl
  66d47b:	48 3b 9c 24 98 01 00 	cmp    0x198(%rsp),%rbx
  66d482:	00 
  66d483:	0f 85 07 fd ff ff    	jne    66d190 <<gpui_canvas::text::planner::Planner>::shape+0x2630>
  66d489:	eb 1e                	jmp    66d4a9 <<gpui_canvas::text::planner::Planner>::shape+0x2949>
  66d48b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  66d490:	48 8b 9c 24 a8 01 00 	mov    0x1a8(%rsp),%rbx
  66d497:	00 
  66d498:	40 b5 02             	mov    $0x2,%bpl
  66d49b:	48 3b 9c 24 98 01 00 	cmp    0x198(%rsp),%rbx
  66d4a2:	00 
  66d4a3:	0f 85 e7 fc ff ff    	jne    66d190 <<gpui_canvas::text::planner::Planner>::shape+0x2630>
  66d4a9:	48 8d bc 24 98 01 00 	lea    0x198(%rsp),%rdi
  66d4b0:	00 
  66d4b1:	ff 15 81 d6 11 00    	call   *0x11d681(%rip)        # 78ab38 <_DYNAMIC+0x4b0>
  66d4b7:	0f 28 84 24 80 00 00 	movaps 0x80(%rsp),%xmm0
  66d4be:	00 
  66d4bf:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
  66d4c4:	e9 d4 fc ff ff       	jmp    66d19d <<gpui_canvas::text::planner::Planner>::shape+0x263d>
  66d4c9:	4c 8b 4c 24 18       	mov    0x18(%rsp),%r9
  66d4ce:	4c 3b 8c 24 c0 01 00 	cmp    0x1c0(%rsp),%r9
  66d4d5:	00 
  66d4d6:	0f 84 24 01 00 00    	je     66d600 <<gpui_canvas::text::planner::Planner>::shape+0x2aa0>
  66d4dc:	45 0f b6 11          	movzbl (%r9),%r10d
  66d4e0:	49 89 f3             	mov    %rsi,%r11
  66d4e3:	45 84 d2             	test   %r10b,%r10b
  66d4e6:	0f 88 2c 01 00 00    	js     66d618 <<gpui_canvas::text::planner::Planner>::shape+0x2ab8>
  66d4ec:	49 8d 49 01          	lea    0x1(%r9),%rcx
  66d4f0:	e9 82 01 00 00       	jmp    66d677 <<gpui_canvas::text::planner::Planner>::shape+0x2b17>
  66d4f5:	48 8b b4 24 e0 06 00 	mov    0x6e0(%rsp),%rsi
  66d4fc:	00 
  66d4fd:	48 85 f6             	test   %rsi,%rsi
  66d500:	74 17                	je     66d519 <<gpui_canvas::text::planner::Planner>::shape+0x29b9>
  66d502:	48 8b bc 24 e8 06 00 	mov    0x6e8(%rsp),%rdi
  66d509:	00 
  66d50a:	48 c1 e6 03          	shl    $0x3,%rsi
  66d50e:	ba 08 00 00 00       	mov    $0x8,%edx
  66d513:	ff 15 a7 d3 11 00    	call   *0x11d3a7(%rip)        # 78a8c0 <_DYNAMIC+0x238>
  66d519:	0f 28 9c 24 90 02 00 	movaps 0x290(%rsp),%xmm3
  66d520:	00 
  66d521:	0f 28 c3             	movaps %xmm3,%xmm0
  66d524:	f3 0f 5f 84 24 04 01 	maxss  0x104(%rsp),%xmm0
  66d52b:	00 00 
  66d52d:	0f 28 c8             	movaps %xmm0,%xmm1
  66d530:	f3 0f c2 c8 03       	cmpunordss %xmm0,%xmm1
  66d535:	0f 28 d1             	movaps %xmm1,%xmm2
  66d538:	0f 55 d0             	andnps %xmm0,%xmm2
  66d53b:	0f 54 cb             	andps  %xmm3,%xmm1
  66d53e:	0f 56 ca             	orps   %xmm2,%xmm1
  66d541:	0f 29 8c 24 90 02 00 	movaps %xmm1,0x290(%rsp)
  66d548:	00 
  66d549:	48 8b 04 24          	mov    (%rsp),%rax
  66d54d:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  66d553:	f3 0f 58 80 30 0a 00 	addss  0xa30(%rax),%xmm0
  66d55a:	00 
  66d55b:	f3 0f 11 44 24 0c    	movss  %xmm0,0xc(%rsp)
  66d561:	80 7c 24 3c 00       	cmpb   $0x0,0x3c(%rsp)
  66d566:	48 8b 84 24 10 03 00 	mov    0x310(%rsp),%rax
  66d56d:	00 
  66d56e:	8b 74 24 68          	mov    0x68(%rsp),%esi
  66d572:	48 8b 9c 24 08 03 00 	mov    0x308(%rsp),%rbx
  66d579:	00 
  66d57a:	0f 84 44 dc ff ff    	je     66b1c4 <<gpui_canvas::text::planner::Planner>::shape+0x664>
  66d580:	e9 71 05 00 00       	jmp    66daf6 <<gpui_canvas::text::planner::Planner>::shape+0x2f96>
  66d585:	48 8b 0c 24          	mov    (%rsp),%rcx
  66d589:	48 8b 81 d8 09 00 00 	mov    0x9d8(%rcx),%rax
  66d590:	48 6b 89 e0 09 00 00 	imul   $0x70,0x9e0(%rcx),%rcx
  66d597:	70 
  66d598:	48 01 c1             	add    %rax,%rcx
  66d59b:	48 89 84 24 e0 06 00 	mov    %rax,0x6e0(%rsp)
  66d5a2:	00 
  66d5a3:	48 89 8c 24 e8 06 00 	mov    %rcx,0x6e8(%rsp)
  66d5aa:	00 
  66d5ab:	48 c7 84 24 f0 06 00 	movq   $0x0,0x6f0(%rsp)
  66d5b2:	00 00 00 00 00 
  66d5b7:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  66d5bc:	48 89 84 24 f8 06 00 	mov    %rax,0x6f8(%rsp)
  66d5c3:	00 
  66d5c4:	48 8d bc 24 e0 06 00 	lea    0x6e0(%rsp),%rdi
  66d5cb:	00 
  66d5cc:	31 f6                	xor    %esi,%esi
  66d5ce:	48 8d 94 24 17 01 00 	lea    0x117(%rsp),%rdx
  66d5d5:	00 
  66d5d6:	e8 e5 98 ff ff       	call   666ec0 <<core::iter::adapters::map::Map<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineData>>, <parley::layout::layout::Layout<()>>::lines::{closure#0}>, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#3}> as core::iter::traits::iterator::Iterator>::fold::<usize, <core::iter::adapters::flatten::FlattenCompat<_, _>>::iter_fold::flatten<core::iter::adapters::filter_map::FilterMap<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}>, <parley::layout::line::Line<()>>::runs::{closure#0}>, usize, <core::iter::adapters::flatten::FlattenCompat<_, _> as core::iter::traits::iterator::Iterator>::count::count<core::iter::adapters::filter_map::FilterMap<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}>, <parley::layout::line::Line<()>>::runs::{closure#0}>>>::{closure#0}>>
  66d5db:	48 83 f8 02          	cmp    $0x2,%rax
  66d5df:	0f 82 ab e1 ff ff    	jb     66b790 <<gpui_canvas::text::planner::Planner>::shape+0xc30>
  66d5e5:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
  66d5ec:	48 83 bc 24 68 01 00 	cmpq   $0xffffffffffffffff,0x168(%rsp)
  66d5f3:	00 ff 
  66d5f5:	0f 84 1b e1 ff ff    	je     66b716 <<gpui_canvas::text::planner::Planner>::shape+0xbb6>
  66d5fb:	e9 90 e1 ff ff       	jmp    66b790 <<gpui_canvas::text::planner::Planner>::shape+0xc30>
  66d600:	c7 44 24 68 ff ff ff 	movl   $0xffffffff,0x68(%rsp)
  66d607:	ff 
  66d608:	c7 44 24 3c 00 00 00 	movl   $0x0,0x3c(%rsp)
  66d60f:	00 
  66d610:	4d 89 c6             	mov    %r8,%r14
  66d613:	e9 f1 dd ff ff       	jmp    66b409 <<gpui_canvas::text::planner::Planner>::shape+0x8a9>
  66d618:	44 89 d2             	mov    %r10d,%edx
  66d61b:	83 e2 1f             	and    $0x1f,%edx
  66d61e:	41 0f b6 79 01       	movzbl 0x1(%r9),%edi
  66d623:	83 e7 3f             	and    $0x3f,%edi
  66d626:	41 80 fa df          	cmp    $0xdf,%r10b
  66d62a:	76 31                	jbe    66d65d <<gpui_canvas::text::planner::Planner>::shape+0x2afd>
  66d62c:	41 0f b6 71 02       	movzbl 0x2(%r9),%esi
  66d631:	c1 e7 06             	shl    $0x6,%edi
  66d634:	83 e6 3f             	and    $0x3f,%esi
  66d637:	09 fe                	or     %edi,%esi
  66d639:	41 80 fa f0          	cmp    $0xf0,%r10b
  66d63d:	72 2c                	jb     66d66b <<gpui_canvas::text::planner::Planner>::shape+0x2b0b>
  66d63f:	49 8d 49 04          	lea    0x4(%r9),%rcx
  66d643:	45 0f b6 51 03       	movzbl 0x3(%r9),%r10d
  66d648:	83 e2 07             	and    $0x7,%edx
  66d64b:	c1 e2 12             	shl    $0x12,%edx
  66d64e:	c1 e6 06             	shl    $0x6,%esi
  66d651:	41 83 e2 3f          	and    $0x3f,%r10d
  66d655:	41 09 f2             	or     %esi,%r10d
  66d658:	41 09 d2             	or     %edx,%r10d
  66d65b:	eb 1a                	jmp    66d677 <<gpui_canvas::text::planner::Planner>::shape+0x2b17>
  66d65d:	49 8d 49 02          	lea    0x2(%r9),%rcx
  66d661:	c1 e2 06             	shl    $0x6,%edx
  66d664:	09 fa                	or     %edi,%edx
  66d666:	41 89 d2             	mov    %edx,%r10d
  66d669:	eb 0c                	jmp    66d677 <<gpui_canvas::text::planner::Planner>::shape+0x2b17>
  66d66b:	49 8d 49 03          	lea    0x3(%r9),%rcx
  66d66f:	c1 e2 0c             	shl    $0xc,%edx
  66d672:	09 d6                	or     %edx,%esi
  66d674:	41 89 f2             	mov    %esi,%r10d
  66d677:	4d 89 c6             	mov    %r8,%r14
  66d67a:	49 8d 50 02          	lea    0x2(%r8),%rdx
  66d67e:	48 89 c6             	mov    %rax,%rsi
  66d681:	4c 29 ce             	sub    %r9,%rsi
  66d684:	48 01 ce             	add    %rcx,%rsi
  66d687:	41 83 fa 0a          	cmp    $0xa,%r10d
  66d68b:	bf fe ff ff ff       	mov    $0xfffffffe,%edi
  66d690:	44 0f 44 d7          	cmove  %edi,%r10d
  66d694:	44 89 54 24 68       	mov    %r10d,0x68(%rsp)
  66d699:	4c 0f 44 da          	cmove  %rdx,%r11
  66d69d:	c7 44 24 3c 00 00 00 	movl   $0x0,0x3c(%rsp)
  66d6a4:	00 
  66d6a5:	48 89 84 24 00 03 00 	mov    %rax,0x300(%rsp)
  66d6ac:	00 
  66d6ad:	48 89 f0             	mov    %rsi,%rax
  66d6b0:	4c 89 de             	mov    %r11,%rsi
  66d6b3:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
  66d6b8:	e9 4c dd ff ff       	jmp    66b409 <<gpui_canvas::text::planner::Planner>::shape+0x8a9>
  66d6bd:	b9 04 00 00 00       	mov    $0x4,%ecx
  66d6c2:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  66d6c8:	48 8d bc 24 18 01 00 	lea    0x118(%rsp),%rdi
  66d6cf:	00 
  66d6d0:	48 89 da             	mov    %rbx,%rdx
  66d6d3:	e8 b8 6c ff ff       	call   664390 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  66d6d8:	e9 25 e2 ff ff       	jmp    66b902 <<gpui_canvas::text::planner::Planner>::shape+0xda2>
  66d6dd:	c7 84 24 a0 00 00 00 	movl   $0x7,0xa0(%rsp)
  66d6e4:	07 00 00 00 
  66d6e8:	eb 0b                	jmp    66d6f5 <<gpui_canvas::text::planner::Planner>::shape+0x2b95>
  66d6ea:	c7 84 24 a0 00 00 00 	movl   $0x4,0xa0(%rsp)
  66d6f1:	04 00 00 00 
  66d6f5:	48 c7 84 24 98 00 00 	movq   $0xffffffffffffffff,0x98(%rsp)
  66d6fc:	00 ff ff ff ff 
  66d701:	4c 8b 2c 24          	mov    (%rsp),%r13
  66d705:	48 8b 84 24 68 01 00 	mov    0x168(%rsp),%rax
  66d70c:	00 
  66d70d:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  66d711:	74 76                	je     66d789 <<gpui_canvas::text::planner::Planner>::shape+0x2c29>
  66d713:	48 85 c0             	test   %rax,%rax
  66d716:	74 1b                	je     66d733 <<gpui_canvas::text::planner::Planner>::shape+0x2bd3>
  66d718:	48 8b bc 24 70 01 00 	mov    0x170(%rsp),%rdi
  66d71f:	00 
  66d720:	48 c1 e0 03          	shl    $0x3,%rax
  66d724:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  66d728:	ba 04 00 00 00       	mov    $0x4,%edx
  66d72d:	ff 15 8d d1 11 00    	call   *0x11d18d(%rip)        # 78a8c0 <_DYNAMIC+0x238>
  66d733:	48 8b 84 24 80 01 00 	mov    0x180(%rsp),%rax
  66d73a:	00 
  66d73b:	48 85 c0             	test   %rax,%rax
  66d73e:	74 1b                	je     66d75b <<gpui_canvas::text::planner::Planner>::shape+0x2bfb>
  66d740:	48 8b bc 24 88 01 00 	mov    0x188(%rsp),%rdi
  66d747:	00 
  66d748:	48 c1 e0 03          	shl    $0x3,%rax
  66d74c:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  66d750:	ba 04 00 00 00       	mov    $0x4,%edx
  66d755:	ff 15 65 d1 11 00    	call   *0x11d165(%rip)        # 78a8c0 <_DYNAMIC+0x238>
  66d75b:	48 8b 84 24 98 01 00 	mov    0x198(%rsp),%rax
  66d762:	00 
  66d763:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  66d767:	74 20                	je     66d789 <<gpui_canvas::text::planner::Planner>::shape+0x2c29>
  66d769:	48 85 c0             	test   %rax,%rax
  66d76c:	74 1b                	je     66d789 <<gpui_canvas::text::planner::Planner>::shape+0x2c29>
  66d76e:	48 8b bc 24 a0 01 00 	mov    0x1a0(%rsp),%rdi
  66d775:	00 
  66d776:	48 c1 e0 02          	shl    $0x2,%rax
  66d77a:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  66d77e:	ba 04 00 00 00       	mov    $0x4,%edx
  66d783:	ff 15 37 d1 11 00    	call   *0x11d137(%rip)        # 78a8c0 <_DYNAMIC+0x238>
  66d789:	48 8b b4 24 18 01 00 	mov    0x118(%rsp),%rsi
  66d790:	00 
  66d791:	48 85 f6             	test   %rsi,%rsi
  66d794:	74 17                	je     66d7ad <<gpui_canvas::text::planner::Planner>::shape+0x2c4d>
  66d796:	48 8b bc 24 20 01 00 	mov    0x120(%rsp),%rdi
  66d79d:	00 
  66d79e:	48 c1 e6 04          	shl    $0x4,%rsi
  66d7a2:	ba 04 00 00 00       	mov    $0x4,%edx
  66d7a7:	ff 15 13 d1 11 00    	call   *0x11d113(%rip)        # 78a8c0 <_DYNAMIC+0x238>
  66d7ad:	48 8b b4 24 a0 02 00 	mov    0x2a0(%rsp),%rsi
  66d7b4:	00 
  66d7b5:	48 83 fe fd          	cmp    $0xfffffffffffffffd,%rsi
  66d7b9:	77 18                	ja     66d7d3 <<gpui_canvas::text::planner::Planner>::shape+0x2c73>
  66d7bb:	48 85 f6             	test   %rsi,%rsi
  66d7be:	74 13                	je     66d7d3 <<gpui_canvas::text::planner::Planner>::shape+0x2c73>
  66d7c0:	48 8b bc 24 a8 02 00 	mov    0x2a8(%rsp),%rdi
  66d7c7:	00 
  66d7c8:	ba 01 00 00 00       	mov    $0x1,%edx
  66d7cd:	ff 15 ed d0 11 00    	call   *0x11d0ed(%rip)        # 78a8c0 <_DYNAMIC+0x238>
  66d7d3:	48 8b b4 24 b8 02 00 	mov    0x2b8(%rsp),%rsi
  66d7da:	00 
  66d7db:	48 83 fe fd          	cmp    $0xfffffffffffffffd,%rsi
  66d7df:	77 18                	ja     66d7f9 <<gpui_canvas::text::planner::Planner>::shape+0x2c99>
  66d7e1:	48 85 f6             	test   %rsi,%rsi
  66d7e4:	74 13                	je     66d7f9 <<gpui_canvas::text::planner::Planner>::shape+0x2c99>
  66d7e6:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
  66d7ed:	00 
  66d7ee:	ba 01 00 00 00       	mov    $0x1,%edx
  66d7f3:	ff 15 c7 d0 11 00    	call   *0x11d0c7(%rip)        # 78a8c0 <_DYNAMIC+0x238>
  66d7f9:	48 8b b4 24 d0 02 00 	mov    0x2d0(%rsp),%rsi
  66d800:	00 
  66d801:	48 83 fe fd          	cmp    $0xfffffffffffffffd,%rsi
  66d805:	77 18                	ja     66d81f <<gpui_canvas::text::planner::Planner>::shape+0x2cbf>
  66d807:	48 85 f6             	test   %rsi,%rsi
  66d80a:	74 13                	je     66d81f <<gpui_canvas::text::planner::Planner>::shape+0x2cbf>
  66d80c:	48 8b bc 24 d8 02 00 	mov    0x2d8(%rsp),%rdi
  66d813:	00 
  66d814:	ba 01 00 00 00       	mov    $0x1,%edx
  66d819:	ff 15 a1 d0 11 00    	call   *0x11d0a1(%rip)        # 78a8c0 <_DYNAMIC+0x238>
  66d81f:	49 8d bd c8 08 00 00 	lea    0x8c8(%r13),%rdi
  66d826:	e8 95 b7 ff ff       	call   668fc0 <core::ptr::drop_glue::<parley::layout::layout::Layout<()>>>
  66d82b:	49 c7 85 c8 08 00 00 	movq   $0x0,0x8c8(%r13)
  66d832:	00 00 00 00 
  66d836:	49 c7 85 d0 08 00 00 	movq   $0x4,0x8d0(%r13)
  66d83d:	04 00 00 00 
  66d841:	0f 57 c0             	xorps  %xmm0,%xmm0
  66d844:	41 0f 11 85 d8 08 00 	movups %xmm0,0x8d8(%r13)
  66d84b:	00 
  66d84c:	49 c7 85 e8 08 00 00 	movq   $0x4,0x8e8(%r13)
  66d853:	04 00 00 00 
  66d857:	41 0f 11 85 f0 08 00 	movups %xmm0,0x8f0(%r13)
  66d85e:	00 
  66d85f:	49 c7 85 00 09 00 00 	movq   $0x8,0x900(%r13)
  66d866:	08 00 00 00 
  66d86a:	41 0f 11 85 08 09 00 	movups %xmm0,0x908(%r13)
  66d871:	00 
  66d872:	49 c7 85 18 09 00 00 	movq   $0x8,0x918(%r13)
  66d879:	08 00 00 00 
  66d87d:	41 0f 11 85 20 09 00 	movups %xmm0,0x920(%r13)
  66d884:	00 
  66d885:	49 c7 85 30 09 00 00 	movq   $0x4,0x930(%r13)
  66d88c:	04 00 00 00 
  66d890:	41 0f 11 85 38 09 00 	movups %xmm0,0x938(%r13)
  66d897:	00 
  66d898:	49 c7 85 48 09 00 00 	movq   $0x4,0x948(%r13)
  66d89f:	04 00 00 00 
  66d8a3:	41 0f 11 85 50 09 00 	movups %xmm0,0x950(%r13)
  66d8aa:	00 
  66d8ab:	49 c7 85 60 09 00 00 	movq   $0x4,0x960(%r13)
  66d8b2:	04 00 00 00 
  66d8b6:	41 0f 11 85 68 09 00 	movups %xmm0,0x968(%r13)
  66d8bd:	00 
  66d8be:	49 c7 85 78 09 00 00 	movq   $0x8,0x978(%r13)
  66d8c5:	08 00 00 00 
  66d8c9:	41 0f 11 85 80 09 00 	movups %xmm0,0x980(%r13)
  66d8d0:	00 
  66d8d1:	49 c7 85 90 09 00 00 	movq   $0x2,0x990(%r13)
  66d8d8:	02 00 00 00 
  66d8dc:	41 0f 11 85 98 09 00 	movups %xmm0,0x998(%r13)
  66d8e3:	00 
  66d8e4:	49 c7 85 a8 09 00 00 	movq   $0x4,0x9a8(%r13)
  66d8eb:	04 00 00 00 
  66d8ef:	41 0f 11 85 b0 09 00 	movups %xmm0,0x9b0(%r13)
  66d8f6:	00 
  66d8f7:	49 c7 85 c0 09 00 00 	movq   $0x8,0x9c0(%r13)
  66d8fe:	08 00 00 00 
  66d902:	41 0f 11 85 c8 09 00 	movups %xmm0,0x9c8(%r13)
  66d909:	00 
  66d90a:	49 c7 85 d8 09 00 00 	movq   $0x8,0x9d8(%r13)
  66d911:	08 00 00 00 
  66d915:	41 0f 11 85 e0 09 00 	movups %xmm0,0x9e0(%r13)
  66d91c:	00 
  66d91d:	49 c7 85 f0 09 00 00 	movq   $0x8,0x9f0(%r13)
  66d924:	08 00 00 00 
  66d928:	41 0f 11 85 f8 09 00 	movups %xmm0,0x9f8(%r13)
  66d92f:	00 
  66d930:	49 c7 85 08 0a 00 00 	movq   $0x4,0xa08(%r13)
  66d937:	04 00 00 00 
  66d93b:	41 0f 11 85 10 0a 00 	movups %xmm0,0xa10(%r13)
  66d942:	00 
  66d943:	41 c7 85 20 0a 00 00 	movl   $0x3f800000,0xa20(%r13)
  66d94a:	00 00 80 3f 
  66d94e:	41 0f 11 85 24 0a 00 	movups %xmm0,0xa24(%r13)
  66d955:	00 
  66d956:	49 c7 85 32 0a 00 00 	movq   $0x0,0xa32(%r13)
  66d95d:	00 00 00 00 
  66d961:	66 41 c7 85 3a 0a 00 	movw   $0xff01,0xa3a(%r13)
  66d968:	00 01 ff 
  66d96b:	41 c6 85 3c 0a 00 00 	movb   $0x0,0xa3c(%r13)
  66d972:	00 
  66d973:	48 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%rcx
  66d97a:	00 
  66d97b:	48 8b 84 24 28 03 00 	mov    0x328(%rsp),%rax
  66d982:	00 
  66d983:	48 89 48 30          	mov    %rcx,0x30(%rax)
  66d987:	0f 10 84 24 98 00 00 	movups 0x98(%rsp),%xmm0
  66d98e:	00 
  66d98f:	0f 10 8c 24 a8 00 00 	movups 0xa8(%rsp),%xmm1
  66d996:	00 
  66d997:	0f 10 94 24 b8 00 00 	movups 0xb8(%rsp),%xmm2
  66d99e:	00 
  66d99f:	0f 11 50 20          	movups %xmm2,0x20(%rax)
  66d9a3:	0f 11 48 10          	movups %xmm1,0x10(%rax)
  66d9a7:	0f 11 00             	movups %xmm0,(%rax)
  66d9aa:	48 81 c4 b8 11 00 00 	add    $0x11b8,%rsp
  66d9b1:	5b                   	pop    %rbx
  66d9b2:	41 5c                	pop    %r12
  66d9b4:	41 5d                	pop    %r13
  66d9b6:	41 5e                	pop    %r14
  66d9b8:	41 5f                	pop    %r15
  66d9ba:	5d                   	pop    %rbp
  66d9bb:	c3                   	ret
  66d9bc:	48 8d 35 4d ff 11 00 	lea    0x11ff4d(%rip),%rsi        # 78d910 <gpui_canvas::text::HEBREW_FONT>
  66d9c3:	48 8d 15 0a 2d 9f ff 	lea    -0x60d2f6(%rip),%rdx        # 606d4 <gpui_canvas::text::HEBREW_BYTES>
  66d9ca:	48 8d bc 24 e0 06 00 	lea    0x6e0(%rsp),%rdi
  66d9d1:	00 
  66d9d2:	b9 14 69 00 00       	mov    $0x6914,%ecx
  66d9d7:	45 31 c0             	xor    %r8d,%r8d
  66d9da:	e8 41 6a ff ff       	call   664420 <<gpui_canvas::text::FontFace>::shared_static>
  66d9df:	80 bc 24 e0 06 00 00 	cmpb   $0x0,0x6e0(%rsp)
  66d9e6:	00 
  66d9e7:	0f 85 70 d5 ff ff    	jne    66af5d <<gpui_canvas::text::planner::Planner>::shape+0x3fd>
  66d9ed:	44 89 fd             	mov    %r15d,%ebp
  66d9f0:	49 8d 9d 50 0a 00 00 	lea    0xa50(%r13),%rbx
  66d9f7:	4c 8b bc 24 e8 06 00 	mov    0x6e8(%rsp),%r15
  66d9fe:	00 
  66d9ff:	48 8b 03             	mov    (%rbx),%rax
  66da02:	48 85 c0             	test   %rax,%rax
  66da05:	74 0f                	je     66da16 <<gpui_canvas::text::planner::Planner>::shape+0x2eb6>
  66da07:	f0 48 ff 08          	lock decq (%rax)
  66da0b:	75 09                	jne    66da16 <<gpui_canvas::text::planner::Planner>::shape+0x2eb6>
  66da0d:	48 89 df             	mov    %rbx,%rdi
  66da10:	ff 15 d2 ce 11 00    	call   *0x11ced2(%rip)        # 78a8e8 <_DYNAMIC+0x260>
  66da16:	4d 89 bd 50 0a 00 00 	mov    %r15,0xa50(%r13)
  66da1d:	be 02 00 00 00       	mov    $0x2,%esi
  66da22:	4c 89 ef             	mov    %r13,%rdi
  66da25:	e8 66 0b 00 00       	call   66e590 <<gpui_canvas::text::planner::Planner>::register>
  66da2a:	83 f8 ff             	cmp    $0xffffffff,%eax
  66da2d:	41 89 ef             	mov    %ebp,%r15d
  66da30:	0f 85 86 d5 ff ff    	jne    66afbc <<gpui_canvas::text::planner::Planner>::shape+0x45c>
  66da36:	e9 c0 d5 ff ff       	jmp    66affb <<gpui_canvas::text::planner::Planner>::shape+0x49b>
  66da3b:	48 8b b4 24 e0 06 00 	mov    0x6e0(%rsp),%rsi
  66da42:	00 
  66da43:	48 85 f6             	test   %rsi,%rsi
  66da46:	74 17                	je     66da5f <<gpui_canvas::text::planner::Planner>::shape+0x2eff>
  66da48:	48 8b bc 24 e8 06 00 	mov    0x6e8(%rsp),%rdi
  66da4f:	00 
  66da50:	48 c1 e6 03          	shl    $0x3,%rsi
  66da54:	ba 08 00 00 00       	mov    $0x8,%edx
  66da59:	ff 15 61 ce 11 00    	call   *0x11ce61(%rip)        # 78a8c0 <_DYNAMIC+0x238>
  66da5f:	b8 01 00 00 00       	mov    $0x1,%eax
  66da64:	4c 8b 2c 24          	mov    (%rsp),%r13
  66da68:	89 84 24 a0 00 00 00 	mov    %eax,0xa0(%rsp)
  66da6f:	89 94 24 a4 00 00 00 	mov    %edx,0xa4(%rsp)
  66da76:	48 c7 84 24 98 00 00 	movq   $0xffffffffffffffff,0x98(%rsp)
  66da7d:	00 ff ff ff ff 
  66da82:	e9 7e fc ff ff       	jmp    66d705 <<gpui_canvas::text::planner::Planner>::shape+0x2ba5>
  66da87:	c7 84 24 a0 00 00 00 	movl   $0x3,0xa0(%rsp)
  66da8e:	03 00 00 00 
  66da92:	e9 5e fc ff ff       	jmp    66d6f5 <<gpui_canvas::text::planner::Planner>::shape+0x2b95>
  66da97:	48 c7 84 24 a0 00 00 	movq   $0x3,0xa0(%rsp)
  66da9e:	00 03 00 00 00 
  66daa3:	e9 4d fc ff ff       	jmp    66d6f5 <<gpui_canvas::text::planner::Planner>::shape+0x2b95>
  66daa8:	c7 84 24 a0 00 00 00 	movl   $0x1,0xa0(%rsp)
  66daaf:	01 00 00 00 
  66dab3:	e9 3d fc ff ff       	jmp    66d6f5 <<gpui_canvas::text::planner::Planner>::shape+0x2b95>
  66dab8:	c7 84 24 a0 00 00 00 	movl   $0x3,0xa0(%rsp)
  66dabf:	03 00 00 00 
  66dac3:	8b 84 24 24 02 00 00 	mov    0x224(%rsp),%eax
  66daca:	89 84 24 a4 00 00 00 	mov    %eax,0xa4(%rsp)
  66dad1:	e9 1f fc ff ff       	jmp    66d6f5 <<gpui_canvas::text::planner::Planner>::shape+0x2b95>
  66dad6:	48 c7 84 24 a0 00 00 	movq   $0xc,0xa0(%rsp)
  66dadd:	00 0c 00 00 00 
  66dae2:	48 c7 84 24 98 00 00 	movq   $0xffffffffffffffff,0x98(%rsp)
  66dae9:	00 ff ff ff ff 
  66daee:	49 89 fd             	mov    %rdi,%r13
  66daf1:	e9 0f fc ff ff       	jmp    66d705 <<gpui_canvas::text::planner::Planner>::shape+0x2ba5>
  66daf6:	48 83 bc 24 68 01 00 	cmpq   $0xffffffffffffffff,0x168(%rsp)
  66dafd:	00 ff 
  66daff:	4c 8b 2c 24          	mov    (%rsp),%r13
  66db03:	0f 84 44 01 00 00    	je     66dc4d <<gpui_canvas::text::planner::Planner>::shape+0x30ed>
  66db09:	48 8b 84 24 98 01 00 	mov    0x198(%rsp),%rax
  66db10:	00 
  66db11:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  66db15:	0f 84 f7 02 00 00    	je     66de12 <<gpui_canvas::text::planner::Planner>::shape+0x32b2>
  66db1b:	48 8b b4 24 a8 01 00 	mov    0x1a8(%rsp),%rsi
  66db22:	00 
  66db23:	48 39 f0             	cmp    %rsi,%rax
  66db26:	0f 86 e6 02 00 00    	jbe    66de12 <<gpui_canvas::text::planner::Planner>::shape+0x32b2>
  66db2c:	48 8d bc 24 98 01 00 	lea    0x198(%rsp),%rdi
  66db33:	00 
  66db34:	e8 a7 0c 00 00       	call   66e7e0 <<alloc::raw_vec::RawVecInner>::shrink>
  66db39:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  66db3d:	0f 84 cf 02 00 00    	je     66de12 <<gpui_canvas::text::planner::Planner>::shape+0x32b2>
  66db43:	48 89 c7             	mov    %rax,%rdi
  66db46:	48 89 d6             	mov    %rdx,%rsi
  66db49:	ff 15 89 ce 11 00    	call   *0x11ce89(%rip)        # 78a9d8 <_DYNAMIC+0x350>
  66db4f:	e9 1e 06 00 00       	jmp    66e172 <<gpui_canvas::text::planner::Planner>::shape+0x3612>
  66db54:	4c 8b 2c 24          	mov    (%rsp),%r13
  66db58:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  66db5d:	eb 21                	jmp    66db80 <<gpui_canvas::text::planner::Planner>::shape+0x3020>
  66db5f:	c7 84 24 00 01 00 00 	movl   $0x0,0x100(%rsp)
  66db66:	00 00 00 00 
  66db6a:	4d 85 ff             	test   %r15,%r15
  66db6d:	74 1f                	je     66db8e <<gpui_canvas::text::planner::Planner>::shape+0x302e>
  66db6f:	4c 8b 2c 24          	mov    (%rsp),%r13
  66db73:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  66db78:	4c 8b 84 24 80 00 00 	mov    0x80(%rsp),%r8
  66db7f:	00 
  66db80:	49 39 c7             	cmp    %rax,%r15
  66db83:	73 1f                	jae    66dba4 <<gpui_canvas::text::planner::Planner>::shape+0x3044>
  66db85:	43 80 3c 38 bf       	cmpb   $0xbf,(%r8,%r15,1)
  66db8a:	7f 1d                	jg     66dba9 <<gpui_canvas::text::planner::Planner>::shape+0x3049>
  66db8c:	eb 4a                	jmp    66dbd8 <<gpui_canvas::text::planner::Planner>::shape+0x3078>
  66db8e:	45 31 ff             	xor    %r15d,%r15d
  66db91:	4c 8b 2c 24          	mov    (%rsp),%r13
  66db95:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  66db9a:	4c 8b 84 24 80 00 00 	mov    0x80(%rsp),%r8
  66dba1:	00 
  66dba2:	eb 05                	jmp    66dba9 <<gpui_canvas::text::planner::Planner>::shape+0x3049>
  66dba4:	49 89 c7             	mov    %rax,%r15
  66dba7:	75 2f                	jne    66dbd8 <<gpui_canvas::text::planner::Planner>::shape+0x3078>
  66dba9:	80 bc 24 00 01 00 00 	cmpb   $0x0,0x100(%rsp)
  66dbb0:	00 
  66dbb1:	74 15                	je     66dbc8 <<gpui_canvas::text::planner::Planner>::shape+0x3068>
  66dbb3:	4c 39 fd             	cmp    %r15,%rbp
  66dbb6:	74 20                	je     66dbd8 <<gpui_canvas::text::planner::Planner>::shape+0x3078>
  66dbb8:	43 0f b6 0c 38       	movzbl (%r8,%r15,1),%ecx
  66dbbd:	84 c9                	test   %cl,%cl
  66dbbf:	78 40                	js     66dc01 <<gpui_canvas::text::planner::Planner>::shape+0x30a1>
  66dbc1:	b8 0b 00 00 00       	mov    $0xb,%eax
  66dbc6:	eb 1a                	jmp    66dbe2 <<gpui_canvas::text::planner::Planner>::shape+0x3082>
  66dbc8:	48 39 c5             	cmp    %rax,%rbp
  66dbcb:	73 09                	jae    66dbd6 <<gpui_canvas::text::planner::Planner>::shape+0x3076>
  66dbcd:	41 80 3c 28 bf       	cmpb   $0xbf,(%r8,%rbp,1)
  66dbd2:	7f df                	jg     66dbb3 <<gpui_canvas::text::planner::Planner>::shape+0x3053>
  66dbd4:	eb 02                	jmp    66dbd8 <<gpui_canvas::text::planner::Planner>::shape+0x3078>
  66dbd6:	74 db                	je     66dbb3 <<gpui_canvas::text::planner::Planner>::shape+0x3053>
  66dbd8:	b8 03 00 00 00       	mov    $0x3,%eax
  66dbdd:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
  66dbe2:	89 84 24 a0 00 00 00 	mov    %eax,0xa0(%rsp)
  66dbe9:	89 8c 24 a4 00 00 00 	mov    %ecx,0xa4(%rsp)
  66dbf0:	48 c7 84 24 98 00 00 	movq   $0xffffffffffffffff,0x98(%rsp)
  66dbf7:	00 ff ff ff ff 
  66dbfc:	e9 04 fb ff ff       	jmp    66d705 <<gpui_canvas::text::planner::Planner>::shape+0x2ba5>
  66dc01:	89 ca                	mov    %ecx,%edx
  66dc03:	83 e2 1f             	and    $0x1f,%edx
  66dc06:	43 0f b6 7c 38 01    	movzbl 0x1(%r8,%r15,1),%edi
  66dc0c:	83 e7 3f             	and    $0x3f,%edi
  66dc0f:	b8 0b 00 00 00       	mov    $0xb,%eax
  66dc14:	80 f9 df             	cmp    $0xdf,%cl
  66dc17:	76 2b                	jbe    66dc44 <<gpui_canvas::text::planner::Planner>::shape+0x30e4>
  66dc19:	43 0f b6 74 38 02    	movzbl 0x2(%r8,%r15,1),%esi
  66dc1f:	c1 e7 06             	shl    $0x6,%edi
  66dc22:	83 e6 3f             	and    $0x3f,%esi
  66dc25:	09 fe                	or     %edi,%esi
  66dc27:	80 f9 f0             	cmp    $0xf0,%cl
  66dc2a:	72 7a                	jb     66dca6 <<gpui_canvas::text::planner::Planner>::shape+0x3146>
  66dc2c:	43 0f b6 4c 38 03    	movzbl 0x3(%r8,%r15,1),%ecx
  66dc32:	83 e2 07             	and    $0x7,%edx
  66dc35:	c1 e2 12             	shl    $0x12,%edx
  66dc38:	c1 e6 06             	shl    $0x6,%esi
  66dc3b:	83 e1 3f             	and    $0x3f,%ecx
  66dc3e:	09 f1                	or     %esi,%ecx
  66dc40:	09 d1                	or     %edx,%ecx
  66dc42:	eb 9e                	jmp    66dbe2 <<gpui_canvas::text::planner::Planner>::shape+0x3082>
  66dc44:	c1 e2 06             	shl    $0x6,%edx
  66dc47:	09 fa                	or     %edi,%edx
  66dc49:	89 d1                	mov    %edx,%ecx
  66dc4b:	eb 95                	jmp    66dbe2 <<gpui_canvas::text::planner::Planner>::shape+0x3082>
  66dc4d:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
  66dc54:	00 
  66dc55:	48 85 c0             	test   %rax,%rax
  66dc58:	0f 84 9b 00 00 00    	je     66dcf9 <<gpui_canvas::text::planner::Planner>::shape+0x3199>
  66dc5e:	48 8b 8c 24 20 01 00 	mov    0x120(%rsp),%rcx
  66dc65:	00 
  66dc66:	48 c1 e0 04          	shl    $0x4,%rax
  66dc6a:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
  66dc6f:	2b 54 01 f0          	sub    -0x10(%rcx,%rax,1),%edx
  66dc73:	0f 83 8d 00 00 00    	jae    66dd06 <<gpui_canvas::text::planner::Planner>::shape+0x31a6>
  66dc79:	c7 84 24 a0 00 00 00 	movl   $0x3,0xa0(%rsp)
  66dc80:	03 00 00 00 
  66dc84:	48 c7 84 24 98 00 00 	movq   $0xffffffffffffffff,0x98(%rsp)
  66dc8b:	00 ff ff ff ff 
  66dc90:	48 8b b4 24 18 01 00 	mov    0x118(%rsp),%rsi
  66dc97:	00 
  66dc98:	48 85 f6             	test   %rsi,%rsi
  66dc9b:	0f 85 f5 fa ff ff    	jne    66d796 <<gpui_canvas::text::planner::Planner>::shape+0x2c36>
  66dca1:	e9 07 fb ff ff       	jmp    66d7ad <<gpui_canvas::text::planner::Planner>::shape+0x2c4d>
  66dca6:	c1 e2 0c             	shl    $0xc,%edx
  66dca9:	09 d6                	or     %edx,%esi
  66dcab:	89 f1                	mov    %esi,%ecx
  66dcad:	e9 30 ff ff ff       	jmp    66dbe2 <<gpui_canvas::text::planner::Planner>::shape+0x3082>
  66dcb2:	48 8d 0d 6f 22 11 00 	lea    0x11226f(%rip),%rcx        # 77ff28 <anon.fcf2ae708c8bfcebac3bd597053acdb9.9.llvm.16263823325747306480+0x308>
  66dcb9:	48 89 df             	mov    %rbx,%rdi
  66dcbc:	48 8b 94 24 50 01 00 	mov    0x150(%rsp),%rdx
  66dcc3:	00 
  66dcc4:	ff 15 be cd 11 00    	call   *0x11cdbe(%rip)        # 78aa88 <_DYNAMIC+0x400>
  66dcca:	e9 a3 04 00 00       	jmp    66e172 <<gpui_canvas::text::planner::Planner>::shape+0x3612>
  66dccf:	41 bc 03 00 00 00    	mov    $0x3,%r12d
  66dcd5:	8b 84 24 f0 01 00 00 	mov    0x1f0(%rsp),%eax
  66dcdc:	41 89 c7             	mov    %eax,%r15d
  66dcdf:	e9 de d2 ff ff       	jmp    66afc2 <<gpui_canvas::text::planner::Planner>::shape+0x462>
  66dce4:	41 bc 03 00 00 00    	mov    $0x3,%r12d
  66dcea:	8b 84 24 90 00 00 00 	mov    0x90(%rsp),%eax
  66dcf1:	41 89 c7             	mov    %eax,%r15d
  66dcf4:	e9 c9 d2 ff ff       	jmp    66afc2 <<gpui_canvas::text::planner::Planner>::shape+0x462>
  66dcf9:	48 83 7c 24 48 00    	cmpq   $0x0,0x48(%rsp)
  66dcff:	75 11                	jne    66dd12 <<gpui_canvas::text::planner::Planner>::shape+0x31b2>
  66dd01:	e9 0c 01 00 00       	jmp    66de12 <<gpui_canvas::text::planner::Planner>::shape+0x32b2>
  66dd06:	81 fa ff 00 00 00    	cmp    $0xff,%edx
  66dd0c:	0f 86 90 02 00 00    	jbe    66dfa2 <<gpui_canvas::text::planner::Planner>::shape+0x3442>
  66dd12:	bf 04 00 00 00       	mov    $0x4,%edi
  66dd17:	be 18 00 00 00       	mov    $0x18,%esi
  66dd1c:	e8 8f 0d 00 00       	call   66eab0 <alloc::boxed::box_new_uninit>
  66dd21:	48 89 c3             	mov    %rax,%rbx
  66dd24:	8b 84 24 28 01 00 00 	mov    0x128(%rsp),%eax
  66dd2b:	c7 03 00 00 00 00    	movl   $0x0,(%rbx)
  66dd31:	4c 8b 7c 24 48       	mov    0x48(%rsp),%r15
  66dd36:	44 89 7b 04          	mov    %r15d,0x4(%rbx)
  66dd3a:	c7 43 08 00 00 00 00 	movl   $0x0,0x8(%rbx)
  66dd41:	89 43 0c             	mov    %eax,0xc(%rbx)
  66dd44:	c7 43 10 00 00 00 00 	movl   $0x0,0x10(%rbx)
  66dd4b:	66 c7 43 14 00 00    	movw   $0x0,0x14(%rbx)
  66dd51:	bf 04 00 00 00       	mov    $0x4,%edi
  66dd56:	be 18 00 00 00       	mov    $0x18,%esi
  66dd5b:	e8 50 0d 00 00       	call   66eab0 <alloc::boxed::box_new_uninit>
  66dd60:	49 89 c6             	mov    %rax,%r14
  66dd63:	c7 00 00 00 00 00    	movl   $0x0,(%rax)
  66dd69:	44 89 78 04          	mov    %r15d,0x4(%rax)
  66dd6d:	c7 40 08 00 00 00 00 	movl   $0x0,0x8(%rax)
  66dd74:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  66dd7a:	f3 0f 11 40 0c       	movss  %xmm0,0xc(%rax)
  66dd7f:	f3 0f 10 44 24 64    	movss  0x64(%rsp),%xmm0
  66dd85:	f3 0f 11 40 10       	movss  %xmm0,0x10(%rax)
  66dd8a:	0f 28 84 24 90 02 00 	movaps 0x290(%rsp),%xmm0
  66dd91:	00 
  66dd92:	f3 0f 11 40 14       	movss  %xmm0,0x14(%rax)
  66dd97:	48 83 bc 24 68 01 00 	cmpq   $0xffffffffffffffff,0x168(%rsp)
  66dd9e:	00 ff 
  66dda0:	74 0d                	je     66ddaf <<gpui_canvas::text::planner::Planner>::shape+0x324f>
  66dda2:	48 8d bc 24 68 01 00 	lea    0x168(%rsp),%rdi
  66dda9:	00 
  66ddaa:	e8 41 c3 ff ff       	call   66a0f0 <core::ptr::drop_glue::<gpui_canvas::text::layout::TextGeometry>>
  66ddaf:	48 c7 84 24 68 01 00 	movq   $0x1,0x168(%rsp)
  66ddb6:	00 01 00 00 00 
  66ddbb:	48 89 9c 24 70 01 00 	mov    %rbx,0x170(%rsp)
  66ddc2:	00 
  66ddc3:	48 c7 84 24 78 01 00 	movq   $0x1,0x178(%rsp)
  66ddca:	00 01 00 00 00 
  66ddcf:	48 c7 84 24 80 01 00 	movq   $0x1,0x180(%rsp)
  66ddd6:	00 01 00 00 00 
  66dddb:	4c 89 b4 24 88 01 00 	mov    %r14,0x188(%rsp)
  66dde2:	00 
  66dde3:	48 c7 84 24 90 01 00 	movq   $0x1,0x190(%rsp)
  66ddea:	00 01 00 00 00 
  66ddef:	48 c7 84 24 98 01 00 	movq   $0xffffffffffffffff,0x198(%rsp)
  66ddf6:	00 ff ff ff ff 
  66ddfb:	44 89 bc 24 b0 01 00 	mov    %r15d,0x1b0(%rsp)
  66de02:	00 
  66de03:	f3 0f 10 44 24 6c    	movss  0x6c(%rsp),%xmm0
  66de09:	f3 0f 11 84 24 b4 01 	movss  %xmm0,0x1b4(%rsp)
  66de10:	00 00 
  66de12:	4c 8b bc 24 18 01 00 	mov    0x118(%rsp),%r15
  66de19:	00 
  66de1a:	48 8b 9c 24 20 01 00 	mov    0x120(%rsp),%rbx
  66de21:	00 
  66de22:	4c 8b b4 24 28 01 00 	mov    0x128(%rsp),%r14
  66de29:	00 
  66de2a:	4c 89 ef             	mov    %r13,%rdi
  66de2d:	48 8b b4 24 10 02 00 	mov    0x210(%rsp),%rsi
  66de34:	00 
  66de35:	e8 16 06 00 00       	call   66e450 <<gpui_canvas::text::planner::Planner>::font_set>
  66de3a:	49 89 c4             	mov    %rax,%r12
  66de3d:	48 89 84 24 90 04 00 	mov    %rax,0x490(%rsp)
  66de44:	00 
  66de45:	48 8b 84 24 68 01 00 	mov    0x168(%rsp),%rax
  66de4c:	00 
  66de4d:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  66de51:	0f 84 c7 00 00 00    	je     66df1e <<gpui_canvas::text::planner::Planner>::shape+0x33be>
  66de57:	48 8d 94 24 70 01 00 	lea    0x170(%rsp),%rdx
  66de5e:	00 
  66de5f:	48 8b 4a 40          	mov    0x40(%rdx),%rcx
  66de63:	48 89 8c 24 38 07 00 	mov    %rcx,0x738(%rsp)
  66de6a:	00 
  66de6b:	0f 10 02             	movups (%rdx),%xmm0
  66de6e:	0f 10 4a 10          	movups 0x10(%rdx),%xmm1
  66de72:	0f 10 52 20          	movups 0x20(%rdx),%xmm2
  66de76:	0f 10 5a 30          	movups 0x30(%rdx),%xmm3
  66de7a:	0f 11 9c 24 28 07 00 	movups %xmm3,0x728(%rsp)
  66de81:	00 
  66de82:	0f 11 94 24 18 07 00 	movups %xmm2,0x718(%rsp)
  66de89:	00 
  66de8a:	0f 11 8c 24 08 07 00 	movups %xmm1,0x708(%rsp)
  66de91:	00 
  66de92:	0f 11 84 24 f8 06 00 	movups %xmm0,0x6f8(%rsp)
  66de99:	00 
  66de9a:	48 c7 84 24 e0 06 00 	movq   $0x1,0x6e0(%rsp)
  66dea1:	00 01 00 00 00 
  66dea6:	48 c7 84 24 e8 06 00 	movq   $0x1,0x6e8(%rsp)
  66dead:	00 01 00 00 00 
  66deb2:	4c 8d ac 24 f0 06 00 	lea    0x6f0(%rsp),%r13
  66deb9:	00 
  66deba:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
  66dec1:	00 
  66dec2:	bf 08 00 00 00       	mov    $0x8,%edi
  66dec7:	be 60 00 00 00       	mov    $0x60,%esi
  66decc:	e8 df 0b 00 00       	call   66eab0 <alloc::boxed::box_new_uninit>
  66ded1:	0f 10 84 24 30 07 00 	movups 0x730(%rsp),%xmm0
  66ded8:	00 
  66ded9:	0f 11 40 50          	movups %xmm0,0x50(%rax)
  66dedd:	0f 10 84 24 20 07 00 	movups 0x720(%rsp),%xmm0
  66dee4:	00 
  66dee5:	0f 11 40 40          	movups %xmm0,0x40(%rax)
  66dee9:	0f 10 84 24 e0 06 00 	movups 0x6e0(%rsp),%xmm0
  66def0:	00 
  66def1:	0f 10 8c 24 f0 06 00 	movups 0x6f0(%rsp),%xmm1
  66def8:	00 
  66def9:	0f 10 94 24 00 07 00 	movups 0x700(%rsp),%xmm2
  66df00:	00 
  66df01:	0f 10 9c 24 10 07 00 	movups 0x710(%rsp),%xmm3
  66df08:	00 
  66df09:	0f 11 58 30          	movups %xmm3,0x30(%rax)
  66df0d:	0f 11 50 20          	movups %xmm2,0x20(%rax)
  66df11:	0f 11 48 10          	movups %xmm1,0x10(%rax)
  66df15:	0f 11 00             	movups %xmm0,(%rax)
  66df18:	4c 8b 2c 24          	mov    (%rsp),%r13
  66df1c:	eb 02                	jmp    66df20 <<gpui_canvas::text::planner::Planner>::shape+0x33c0>
  66df1e:	31 c0                	xor    %eax,%eax
  66df20:	4c 89 bc 24 98 00 00 	mov    %r15,0x98(%rsp)
  66df27:	00 
  66df28:	48 89 9c 24 a0 00 00 	mov    %rbx,0xa0(%rsp)
  66df2f:	00 
  66df30:	4c 89 b4 24 a8 00 00 	mov    %r14,0xa8(%rsp)
  66df37:	00 
  66df38:	4c 89 a4 24 b0 00 00 	mov    %r12,0xb0(%rsp)
  66df3f:	00 
  66df40:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
  66df47:	00 
  66df48:	0f 28 84 24 90 02 00 	movaps 0x290(%rsp),%xmm0
  66df4f:	00 
  66df50:	f3 0f 11 84 24 c0 00 	movss  %xmm0,0xc0(%rsp)
  66df57:	00 00 
  66df59:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  66df5f:	f3 0f 11 84 24 c4 00 	movss  %xmm0,0xc4(%rsp)
  66df66:	00 00 
  66df68:	f3 0f 10 44 24 64    	movss  0x64(%rsp),%xmm0
  66df6e:	f3 0f 11 84 24 c8 00 	movss  %xmm0,0xc8(%rsp)
  66df75:	00 00 
  66df77:	f3 0f 10 44 24 6c    	movss  0x6c(%rsp),%xmm0
  66df7d:	f3 0f 11 84 24 cc 00 	movss  %xmm0,0xcc(%rsp)
  66df84:	00 00 
  66df86:	48 8d bc 24 a0 02 00 	lea    0x2a0(%rsp),%rdi
  66df8d:	00 
  66df8e:	e8 3d a9 ff ff       	call   6688d0 <core::ptr::drop_glue::<[parlance::font_family::FontFamilyName; 3]>>
  66df93:	49 83 ff ff          	cmp    $0xffffffffffffffff,%r15
  66df97:	0f 85 d6 f9 ff ff    	jne    66d973 <<gpui_canvas::text::planner::Planner>::shape+0x2e13>
  66df9d:	e9 7d f8 ff ff       	jmp    66d81f <<gpui_canvas::text::planner::Planner>::shape+0x2cbf>
  66dfa2:	48 01 c1             	add    %rax,%rcx
  66dfa5:	88 51 ff             	mov    %dl,-0x1(%rcx)
  66dfa8:	48 83 bc 24 68 01 00 	cmpq   $0xffffffffffffffff,0x168(%rsp)
  66dfaf:	00 ff 
  66dfb1:	0f 85 52 fb ff ff    	jne    66db09 <<gpui_canvas::text::planner::Planner>::shape+0x2fa9>
  66dfb7:	e9 56 fe ff ff       	jmp    66de12 <<gpui_canvas::text::planner::Planner>::shape+0x32b2>
  66dfbc:	48 89 cb             	mov    %rcx,%rbx
  66dfbf:	48 8b 84 24 08 02 00 	mov    0x208(%rsp),%rax
  66dfc6:	00 
  66dfc7:	48 89 84 24 50 01 00 	mov    %rax,0x150(%rsp)
  66dfce:	00 
  66dfcf:	48 8d 0d 5a 20 11 00 	lea    0x11205a(%rip),%rcx        # 780030 <anon.fcf2ae708c8bfcebac3bd597053acdb9.9.llvm.16263823325747306480+0x410>
  66dfd6:	e9 de fc ff ff       	jmp    66dcb9 <<gpui_canvas::text::planner::Planner>::shape+0x3159>
  66dfdb:	48 89 d3             	mov    %rdx,%rbx
  66dfde:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  66dfe3:	48 89 84 24 50 01 00 	mov    %rax,0x150(%rsp)
  66dfea:	00 
  66dfeb:	48 8d 0d 06 1f 11 00 	lea    0x111f06(%rip),%rcx        # 77fef8 <anon.fcf2ae708c8bfcebac3bd597053acdb9.9.llvm.16263823325747306480+0x2d8>
  66dff2:	e9 c2 fc ff ff       	jmp    66dcb9 <<gpui_canvas::text::planner::Planner>::shape+0x3159>
  66dff7:	48 8d 0d 2a 2b 11 00 	lea    0x112b2a(%rip),%rcx        # 780b28 <anon.dc752cbb3d3389760d876509e45b0baf.24.llvm.10480319710464438355>
  66dffe:	48 89 f7             	mov    %rsi,%rdi
  66e001:	48 89 d6             	mov    %rdx,%rsi
  66e004:	4c 89 c2             	mov    %r8,%rdx
  66e007:	ff 15 7b ca 11 00    	call   *0x11ca7b(%rip)        # 78aa88 <_DYNAMIC+0x400>
  66e00d:	e9 60 01 00 00       	jmp    66e172 <<gpui_canvas::text::planner::Planner>::shape+0x3612>
  66e012:	48 8d 0d 67 22 11 00 	lea    0x112267(%rip),%rcx        # 780280 <anon.62868e170f60758b8c346cd4185a0643.24.llvm.4228727425897277816>
  66e019:	ff 15 69 ca 11 00    	call   *0x11ca69(%rip)        # 78aa88 <_DYNAMIC+0x400>
  66e01f:	e9 4e 01 00 00       	jmp    66e172 <<gpui_canvas::text::planner::Planner>::shape+0x3612>
  66e024:	48 8d 0d 55 22 11 00 	lea    0x112255(%rip),%rcx        # 780280 <anon.62868e170f60758b8c346cd4185a0643.24.llvm.4228727425897277816>
  66e02b:	ff 15 57 ca 11 00    	call   *0x11ca57(%rip)        # 78aa88 <_DYNAMIC+0x400>
  66e031:	e9 3c 01 00 00       	jmp    66e172 <<gpui_canvas::text::planner::Planner>::shape+0x3612>
  66e036:	48 8d 3d 43 fd be ff 	lea    -0x4102bd(%rip),%rdi        # 25dd80 <anon.62868e170f60758b8c346cd4185a0643.0.llvm.4228727425897277816>
  66e03d:	48 8d 15 74 24 11 00 	lea    0x112474(%rip),%rdx        # 7804b8 <anon.62868e170f60758b8c346cd4185a0643.77.llvm.4228727425897277816>
  66e044:	be 63 00 00 00       	mov    $0x63,%esi
  66e049:	ff 15 19 cb 11 00    	call   *0x11cb19(%rip)        # 78ab68 <_DYNAMIC+0x4e0>
  66e04f:	e9 1e 01 00 00       	jmp    66e172 <<gpui_canvas::text::planner::Planner>::shape+0x3612>
  66e054:	48 8d 3d 3d 22 11 00 	lea    0x11223d(%rip),%rdi        # 780298 <anon.62868e170f60758b8c346cd4185a0643.25.llvm.4228727425897277816>
  66e05b:	ff 15 5f c9 11 00    	call   *0x11c95f(%rip)        # 78a9c0 <_DYNAMIC+0x338>
  66e061:	e9 0c 01 00 00       	jmp    66e172 <<gpui_canvas::text::planner::Planner>::shape+0x3612>
  66e066:	83 f8 fe             	cmp    $0xfffffffe,%eax
  66e069:	0f 85 f5 f9 ff ff    	jne    66da64 <<gpui_canvas::text::planner::Planner>::shape+0x2f04>
  66e06f:	b8 03 00 00 00       	mov    $0x3,%eax
  66e074:	e9 eb f9 ff ff       	jmp    66da64 <<gpui_canvas::text::planner::Planner>::shape+0x2f04>
  66e079:	4c 8d 05 f0 1e 11 00 	lea    0x111ef0(%rip),%r8        # 77ff70 <anon.fcf2ae708c8bfcebac3bd597053acdb9.9.llvm.16263823325747306480+0x350>
  66e080:	48 8b bc 24 60 01 00 	mov    0x160(%rsp),%rdi
  66e087:	00 
  66e088:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
  66e08d:	48 89 da             	mov    %rbx,%rdx
  66e090:	4c 89 f1             	mov    %r14,%rcx
  66e093:	ff 15 17 cc 11 00    	call   *0x11cc17(%rip)        # 78acb0 <_DYNAMIC+0x628>
  66e099:	e9 d4 00 00 00       	jmp    66e172 <<gpui_canvas::text::planner::Planner>::shape+0x3612>
  66e09e:	48 8d 05 6b 1e 11 00 	lea    0x111e6b(%rip),%rax        # 77ff10 <anon.fcf2ae708c8bfcebac3bd597053acdb9.9.llvm.16263823325747306480+0x2f0>
  66e0a5:	eb 24                	jmp    66e0cb <<gpui_canvas::text::planner::Planner>::shape+0x356b>
  66e0a7:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  66e0ac:	48 39 d0             	cmp    %rdx,%rax
  66e0af:	48 0f 47 d0          	cmova  %rax,%rdx
  66e0b3:	48 8d 05 46 20 11 00 	lea    0x112046(%rip),%rax        # 780100 <anon.fcf2ae708c8bfcebac3bd597053acdb9.9.llvm.16263823325747306480+0x4e0>
  66e0ba:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  66e0bf:	48 89 d7             	mov    %rdx,%rdi
  66e0c2:	eb 0c                	jmp    66e0d0 <<gpui_canvas::text::planner::Planner>::shape+0x3570>
  66e0c4:	48 8d 05 05 1f 11 00 	lea    0x111f05(%rip),%rax        # 77ffd0 <anon.fcf2ae708c8bfcebac3bd597053acdb9.9.llvm.16263823325747306480+0x3b0>
  66e0cb:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  66e0d0:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  66e0d5:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
  66e0da:	ff 15 08 c9 11 00    	call   *0x11c908(%rip)        # 78a9e8 <_DYNAMIC+0x360>
  66e0e0:	e9 8d 00 00 00       	jmp    66e172 <<gpui_canvas::text::planner::Planner>::shape+0x3612>
  66e0e5:	31 ff                	xor    %edi,%edi
  66e0e7:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
  66e0ee:	00 00 
  66e0f0:	eb de                	jmp    66e0d0 <<gpui_canvas::text::planner::Planner>::shape+0x3570>
  66e0f2:	48 8d 0d 77 2a 11 00 	lea    0x112a77(%rip),%rcx        # 780b70 <anon.dc752cbb3d3389760d876509e45b0baf.29.llvm.10480319710464438355>
  66e0f9:	48 89 8c 24 88 02 00 	mov    %rcx,0x288(%rsp)
  66e100:	00 
  66e101:	eb 04                	jmp    66e107 <<gpui_canvas::text::planner::Planner>::shape+0x35a7>
  66e103:	31 ff                	xor    %edi,%edi
  66e105:	31 c0                	xor    %eax,%eax
  66e107:	48 89 c6             	mov    %rax,%rsi
  66e10a:	48 8b 94 24 88 02 00 	mov    0x288(%rsp),%rdx
  66e111:	00 
  66e112:	ff 15 d0 c8 11 00    	call   *0x11c8d0(%rip)        # 78a9e8 <_DYNAMIC+0x360>
  66e118:	eb 58                	jmp    66e172 <<gpui_canvas::text::planner::Planner>::shape+0x3612>
  66e11a:	48 8d 15 c7 22 11 00 	lea    0x1122c7(%rip),%rdx        # 7803e8 <anon.62868e170f60758b8c346cd4185a0643.45.llvm.4228727425897277816>
  66e121:	ff 15 c1 c8 11 00    	call   *0x11c8c1(%rip)        # 78a9e8 <_DYNAMIC+0x360>
  66e127:	eb 49                	jmp    66e172 <<gpui_canvas::text::planner::Planner>::shape+0x3612>
  66e129:	48 8d 05 b8 1f 11 00 	lea    0x111fb8(%rip),%rax        # 7800e8 <anon.fcf2ae708c8bfcebac3bd597053acdb9.9.llvm.16263823325747306480+0x4c8>
  66e130:	eb 99                	jmp    66e0cb <<gpui_canvas::text::planner::Planner>::shape+0x356b>
  66e132:	48 89 d7             	mov    %rdx,%rdi
  66e135:	48 8d 05 dc 1f 11 00 	lea    0x111fdc(%rip),%rax        # 780118 <anon.fcf2ae708c8bfcebac3bd597053acdb9.9.llvm.16263823325747306480+0x4f8>
  66e13c:	eb 8d                	jmp    66e0cb <<gpui_canvas::text::planner::Planner>::shape+0x356b>
  66e13e:	48 8d 05 73 1e 11 00 	lea    0x111e73(%rip),%rax        # 77ffb8 <anon.fcf2ae708c8bfcebac3bd597053acdb9.9.llvm.16263823325747306480+0x398>
  66e145:	eb 84                	jmp    66e0cb <<gpui_canvas::text::planner::Planner>::shape+0x356b>
  66e147:	48 8d 05 9a 1e 11 00 	lea    0x111e9a(%rip),%rax        # 77ffe8 <anon.fcf2ae708c8bfcebac3bd597053acdb9.9.llvm.16263823325747306480+0x3c8>
  66e14e:	e9 78 ff ff ff       	jmp    66e0cb <<gpui_canvas::text::planner::Planner>::shape+0x356b>
  66e153:	48 89 d7             	mov    %rdx,%rdi
  66e156:	48 8d 05 a3 1e 11 00 	lea    0x111ea3(%rip),%rax        # 780000 <anon.fcf2ae708c8bfcebac3bd597053acdb9.9.llvm.16263823325747306480+0x3e0>
  66e15d:	e9 69 ff ff ff       	jmp    66e0cb <<gpui_canvas::text::planner::Planner>::shape+0x356b>
  66e162:	48 8d 15 07 2a 11 00 	lea    0x112a07(%rip),%rdx        # 780b70 <anon.dc752cbb3d3389760d876509e45b0baf.29.llvm.10480319710464438355>
  66e169:	48 89 c6             	mov    %rax,%rsi
  66e16c:	ff 15 76 c8 11 00    	call   *0x11c876(%rip)        # 78a9e8 <_DYNAMIC+0x360>
  66e172:	0f 0b                	ud2
  66e174:	49 89 c6             	mov    %rax,%r14
  66e177:	be 18 00 00 00       	mov    $0x18,%esi
  66e17c:	ba 04 00 00 00       	mov    $0x4,%edx
  66e181:	48 89 df             	mov    %rbx,%rdi
  66e184:	ff 15 36 c7 11 00    	call   *0x11c736(%rip)        # 78a8c0 <_DYNAMIC+0x238>
  66e18a:	e9 64 02 00 00       	jmp    66e3f3 <<gpui_canvas::text::planner::Planner>::shape+0x3893>
  66e18f:	49 89 c6             	mov    %rax,%r14
  66e192:	4c 89 ef             	mov    %r13,%rdi
  66e195:	e8 56 bf ff ff       	call   66a0f0 <core::ptr::drop_glue::<gpui_canvas::text::layout::TextGeometry>>
  66e19a:	f0 49 ff 0c 24       	lock decq (%r12)
  66e19f:	75 0e                	jne    66e1af <<gpui_canvas::text::planner::Planner>::shape+0x364f>
  66e1a1:	48 8d bc 24 90 04 00 	lea    0x490(%rsp),%rdi
  66e1a8:	00 
  66e1a9:	ff 15 29 c7 11 00    	call   *0x11c729(%rip)        # 78a8d8 <_DYNAMIC+0x250>
  66e1af:	31 ed                	xor    %ebp,%ebp
  66e1b1:	eb 0c                	jmp    66e1bf <<gpui_canvas::text::planner::Planner>::shape+0x365f>
  66e1b3:	ff 15 27 c7 11 00    	call   *0x11c727(%rip)        # 78a8e0 <_DYNAMIC+0x258>
  66e1b9:	49 89 c6             	mov    %rax,%r14
  66e1bc:	40 b5 01             	mov    $0x1,%bpl
  66e1bf:	4d 85 ff             	test   %r15,%r15
  66e1c2:	74 15                	je     66e1d9 <<gpui_canvas::text::planner::Planner>::shape+0x3679>
  66e1c4:	49 c1 e7 04          	shl    $0x4,%r15
  66e1c8:	ba 04 00 00 00       	mov    $0x4,%edx
  66e1cd:	48 89 df             	mov    %rbx,%rdi
  66e1d0:	4c 89 fe             	mov    %r15,%rsi
  66e1d3:	ff 15 e7 c6 11 00    	call   *0x11c6e7(%rip)        # 78a8c0 <_DYNAMIC+0x238>
  66e1d9:	40 84 ed             	test   %bpl,%bpl
  66e1dc:	0f 84 53 02 00 00    	je     66e435 <<gpui_canvas::text::planner::Planner>::shape+0x38d5>
  66e1e2:	31 db                	xor    %ebx,%ebx
  66e1e4:	48 83 bc 24 68 01 00 	cmpq   $0xffffffffffffffff,0x168(%rsp)
  66e1eb:	00 ff 
  66e1ed:	0f 84 c5 01 00 00    	je     66e3b8 <<gpui_canvas::text::planner::Planner>::shape+0x3858>
  66e1f3:	e9 08 02 00 00       	jmp    66e400 <<gpui_canvas::text::planner::Planner>::shape+0x38a0>
  66e1f8:	49 89 c6             	mov    %rax,%r14
  66e1fb:	4c 89 3b             	mov    %r15,(%rbx)
  66e1fe:	4c 89 f7             	mov    %r14,%rdi
  66e201:	e8 da 05 11 00       	call   77e7e0 <_Unwind_Resume@plt>
  66e206:	e9 e5 01 00 00       	jmp    66e3f0 <<gpui_canvas::text::planner::Planner>::shape+0x3890>
  66e20b:	e9 e0 01 00 00       	jmp    66e3f0 <<gpui_canvas::text::planner::Planner>::shape+0x3890>
  66e210:	e9 db 01 00 00       	jmp    66e3f0 <<gpui_canvas::text::planner::Planner>::shape+0x3890>
  66e215:	e9 81 01 00 00       	jmp    66e39b <<gpui_canvas::text::planner::Planner>::shape+0x383b>
  66e21a:	e9 d1 01 00 00       	jmp    66e3f0 <<gpui_canvas::text::planner::Planner>::shape+0x3890>
  66e21f:	e9 cc 01 00 00       	jmp    66e3f0 <<gpui_canvas::text::planner::Planner>::shape+0x3890>
  66e224:	e9 c7 01 00 00       	jmp    66e3f0 <<gpui_canvas::text::planner::Planner>::shape+0x3890>
  66e229:	e9 6d 01 00 00       	jmp    66e39b <<gpui_canvas::text::planner::Planner>::shape+0x383b>
  66e22e:	e9 bd 01 00 00       	jmp    66e3f0 <<gpui_canvas::text::planner::Planner>::shape+0x3890>
  66e233:	49 89 c6             	mov    %rax,%r14
  66e236:	49 c7 85 c8 08 00 00 	movq   $0x0,0x8c8(%r13)
  66e23d:	00 00 00 00 
  66e241:	49 c7 85 d0 08 00 00 	movq   $0x4,0x8d0(%r13)
  66e248:	04 00 00 00 
  66e24c:	0f 57 c0             	xorps  %xmm0,%xmm0
  66e24f:	41 0f 11 85 d8 08 00 	movups %xmm0,0x8d8(%r13)
  66e256:	00 
  66e257:	49 c7 85 e8 08 00 00 	movq   $0x4,0x8e8(%r13)
  66e25e:	04 00 00 00 
  66e262:	41 0f 11 85 f0 08 00 	movups %xmm0,0x8f0(%r13)
  66e269:	00 
  66e26a:	49 c7 85 00 09 00 00 	movq   $0x8,0x900(%r13)
  66e271:	08 00 00 00 
  66e275:	41 0f 11 85 08 09 00 	movups %xmm0,0x908(%r13)
  66e27c:	00 
  66e27d:	49 c7 85 18 09 00 00 	movq   $0x8,0x918(%r13)
  66e284:	08 00 00 00 
  66e288:	41 0f 11 85 20 09 00 	movups %xmm0,0x920(%r13)
  66e28f:	00 
  66e290:	49 c7 85 30 09 00 00 	movq   $0x4,0x930(%r13)
  66e297:	04 00 00 00 
  66e29b:	41 0f 11 85 38 09 00 	movups %xmm0,0x938(%r13)
  66e2a2:	00 
  66e2a3:	49 c7 85 48 09 00 00 	movq   $0x4,0x948(%r13)
  66e2aa:	04 00 00 00 
  66e2ae:	41 0f 11 85 50 09 00 	movups %xmm0,0x950(%r13)
  66e2b5:	00 
  66e2b6:	49 c7 85 60 09 00 00 	movq   $0x4,0x960(%r13)
  66e2bd:	04 00 00 00 
  66e2c1:	41 0f 11 85 68 09 00 	movups %xmm0,0x968(%r13)
  66e2c8:	00 
  66e2c9:	49 c7 85 78 09 00 00 	movq   $0x8,0x978(%r13)
  66e2d0:	08 00 00 00 
  66e2d4:	41 0f 11 85 80 09 00 	movups %xmm0,0x980(%r13)
  66e2db:	00 
  66e2dc:	49 c7 85 90 09 00 00 	movq   $0x2,0x990(%r13)
  66e2e3:	02 00 00 00 
  66e2e7:	41 0f 11 85 98 09 00 	movups %xmm0,0x998(%r13)
  66e2ee:	00 
  66e2ef:	49 c7 85 a8 09 00 00 	movq   $0x4,0x9a8(%r13)
  66e2f6:	04 00 00 00 
  66e2fa:	41 0f 11 85 b0 09 00 	movups %xmm0,0x9b0(%r13)
  66e301:	00 
  66e302:	49 c7 85 c0 09 00 00 	movq   $0x8,0x9c0(%r13)
  66e309:	08 00 00 00 
  66e30d:	41 0f 11 85 c8 09 00 	movups %xmm0,0x9c8(%r13)
  66e314:	00 
  66e315:	49 c7 85 d8 09 00 00 	movq   $0x8,0x9d8(%r13)
  66e31c:	08 00 00 00 
  66e320:	41 0f 11 85 e0 09 00 	movups %xmm0,0x9e0(%r13)
  66e327:	00 
  66e328:	49 c7 85 f0 09 00 00 	movq   $0x8,0x9f0(%r13)
  66e32f:	08 00 00 00 
  66e333:	41 0f 11 85 f8 09 00 	movups %xmm0,0x9f8(%r13)
  66e33a:	00 
  66e33b:	49 c7 85 08 0a 00 00 	movq   $0x4,0xa08(%r13)
  66e342:	04 00 00 00 
  66e346:	41 0f 11 85 10 0a 00 	movups %xmm0,0xa10(%r13)
  66e34d:	00 
  66e34e:	41 c7 85 20 0a 00 00 	movl   $0x3f800000,0xa20(%r13)
  66e355:	00 00 80 3f 
  66e359:	41 0f 11 85 24 0a 00 	movups %xmm0,0xa24(%r13)
  66e360:	00 
  66e361:	49 c7 85 32 0a 00 00 	movq   $0x0,0xa32(%r13)
  66e368:	00 00 00 00 
  66e36c:	66 41 c7 85 3a 0a 00 	movw   $0xff01,0xa3a(%r13)
  66e373:	00 01 ff 
  66e376:	41 c6 85 3c 0a 00 00 	movb   $0x0,0xa3c(%r13)
  66e37d:	00 
  66e37e:	48 8d bc 24 98 00 00 	lea    0x98(%rsp),%rdi
  66e385:	00 
  66e386:	e8 55 a6 ff ff       	call   6689e0 <core::ptr::drop_glue::<core::result::Result<gpui_canvas::text::TextLayout, gpui_canvas::Error>>>
  66e38b:	4c 89 f7             	mov    %r14,%rdi
  66e38e:	e8 4d 04 11 00       	call   77e7e0 <_Unwind_Resume@plt>
  66e393:	ff 15 47 c5 11 00    	call   *0x11c547(%rip)        # 78a8e0 <_DYNAMIC+0x258>
  66e399:	eb 55                	jmp    66e3f0 <<gpui_canvas::text::planner::Planner>::shape+0x3890>
  66e39b:	49 89 c6             	mov    %rax,%r14
  66e39e:	48 8b b4 24 e0 06 00 	mov    0x6e0(%rsp),%rsi
  66e3a5:	00 
  66e3a6:	b3 01                	mov    $0x1,%bl
  66e3a8:	48 85 f6             	test   %rsi,%rsi
  66e3ab:	75 11                	jne    66e3be <<gpui_canvas::text::planner::Planner>::shape+0x385e>
  66e3ad:	48 83 bc 24 68 01 00 	cmpq   $0xffffffffffffffff,0x168(%rsp)
  66e3b4:	00 ff 
  66e3b6:	75 48                	jne    66e400 <<gpui_canvas::text::planner::Planner>::shape+0x38a0>
  66e3b8:	84 db                	test   %bl,%bl
  66e3ba:	75 55                	jne    66e411 <<gpui_canvas::text::planner::Planner>::shape+0x38b1>
  66e3bc:	eb 77                	jmp    66e435 <<gpui_canvas::text::planner::Planner>::shape+0x38d5>
  66e3be:	48 8b bc 24 e8 06 00 	mov    0x6e8(%rsp),%rdi
  66e3c5:	00 
  66e3c6:	48 c1 e6 03          	shl    $0x3,%rsi
  66e3ca:	ba 08 00 00 00       	mov    $0x8,%edx
  66e3cf:	ff 15 eb c4 11 00    	call   *0x11c4eb(%rip)        # 78a8c0 <_DYNAMIC+0x238>
  66e3d5:	48 83 bc 24 68 01 00 	cmpq   $0xffffffffffffffff,0x168(%rsp)
  66e3dc:	00 ff 
  66e3de:	74 d8                	je     66e3b8 <<gpui_canvas::text::planner::Planner>::shape+0x3858>
  66e3e0:	eb 1e                	jmp    66e400 <<gpui_canvas::text::planner::Planner>::shape+0x38a0>
  66e3e2:	eb 0c                	jmp    66e3f0 <<gpui_canvas::text::planner::Planner>::shape+0x3890>
  66e3e4:	eb 0a                	jmp    66e3f0 <<gpui_canvas::text::planner::Planner>::shape+0x3890>
  66e3e6:	eb 08                	jmp    66e3f0 <<gpui_canvas::text::planner::Planner>::shape+0x3890>
  66e3e8:	eb 06                	jmp    66e3f0 <<gpui_canvas::text::planner::Planner>::shape+0x3890>
  66e3ea:	eb 04                	jmp    66e3f0 <<gpui_canvas::text::planner::Planner>::shape+0x3890>
  66e3ec:	eb 02                	jmp    66e3f0 <<gpui_canvas::text::planner::Planner>::shape+0x3890>
  66e3ee:	eb 00                	jmp    66e3f0 <<gpui_canvas::text::planner::Planner>::shape+0x3890>
  66e3f0:	49 89 c6             	mov    %rax,%r14
  66e3f3:	b3 01                	mov    $0x1,%bl
  66e3f5:	48 83 bc 24 68 01 00 	cmpq   $0xffffffffffffffff,0x168(%rsp)
  66e3fc:	00 ff 
  66e3fe:	74 b8                	je     66e3b8 <<gpui_canvas::text::planner::Planner>::shape+0x3858>
  66e400:	48 8d bc 24 68 01 00 	lea    0x168(%rsp),%rdi
  66e407:	00 
  66e408:	e8 e3 bc ff ff       	call   66a0f0 <core::ptr::drop_glue::<gpui_canvas::text::layout::TextGeometry>>
  66e40d:	84 db                	test   %bl,%bl
  66e40f:	74 24                	je     66e435 <<gpui_canvas::text::planner::Planner>::shape+0x38d5>
  66e411:	48 8b b4 24 18 01 00 	mov    0x118(%rsp),%rsi
  66e418:	00 
  66e419:	48 85 f6             	test   %rsi,%rsi
  66e41c:	74 17                	je     66e435 <<gpui_canvas::text::planner::Planner>::shape+0x38d5>
  66e41e:	48 8b bc 24 20 01 00 	mov    0x120(%rsp),%rdi
  66e425:	00 
  66e426:	48 c1 e6 04          	shl    $0x4,%rsi
  66e42a:	ba 04 00 00 00       	mov    $0x4,%edx
  66e42f:	ff 15 8b c4 11 00    	call   *0x11c48b(%rip)        # 78a8c0 <_DYNAMIC+0x238>
  66e435:	48 8d bc 24 a0 02 00 	lea    0x2a0(%rsp),%rdi
  66e43c:	00 
  66e43d:	e8 8e a4 ff ff       	call   6688d0 <core::ptr::drop_glue::<[parlance::font_family::FontFamilyName; 3]>>
  66e442:	4c 89 f7             	mov    %r14,%rdi
  66e445:	e8 96 03 11 00       	call   77e7e0 <_Unwind_Resume@plt>
