
/tmp/gpui-monotonic-control-bin/stream-inline:     file format elf64-x86-64


Disassembly of section .text:

0000000000674060 <<gpui_canvas::text::planner::Planner>::shape>:
  674060:	55                   	push   %rbp
  674061:	41 57                	push   %r15
  674063:	41 56                	push   %r14
  674065:	41 55                	push   %r13
  674067:	41 54                	push   %r12
  674069:	53                   	push   %rbx
  67406a:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
  674071:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
  674078:	00 
  674079:	48 81 ec e8 01 00 00 	sub    $0x1e8,%rsp
  674080:	44 89 8c 24 2c 02 00 	mov    %r9d,0x22c(%rsp)
  674087:	00 
  674088:	f3 0f 11 8c 24 cc 01 	movss  %xmm1,0x1cc(%rsp)
  67408f:	00 00 
  674091:	44 89 84 24 c8 01 00 	mov    %r8d,0x1c8(%rsp)
  674098:	00 
  674099:	f3 0f 11 84 24 84 00 	movss  %xmm0,0x84(%rsp)
  6740a0:	00 00 
  6740a2:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
  6740a7:	49 89 f5             	mov    %rsi,%r13
  6740aa:	48 89 bc 24 38 03 00 	mov    %rdi,0x338(%rsp)
  6740b1:	00 
  6740b2:	4c 8d 24 0a          	lea    (%rdx,%rcx,1),%r12
  6740b6:	48 85 c9             	test   %rcx,%rcx
  6740b9:	48 89 34 24          	mov    %rsi,(%rsp)
  6740bd:	48 89 94 24 48 01 00 	mov    %rdx,0x148(%rsp)
  6740c4:	00 
  6740c5:	4c 89 a4 24 b0 01 00 	mov    %r12,0x1b0(%rsp)
  6740cc:	00 
  6740cd:	0f 84 90 03 00 00    	je     674463 <<gpui_canvas::text::planner::Planner>::shape+0x403>
  6740d3:	49 8d 85 78 0a 00 00 	lea    0xa78(%r13),%rax
  6740da:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  6740df:	48 8d b4 24 ec 0c 00 	lea    0xcec(%rsp),%rsi
  6740e6:	00 
  6740e7:	49 8d 45 38          	lea    0x38(%r13),%rax
  6740eb:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  6740f0:	49 8d 45 3c          	lea    0x3c(%r13),%rax
  6740f4:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  6740fb:	00 
  6740fc:	49 8d 45 58          	lea    0x58(%r13),%rax
  674100:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
  674107:	00 
  674108:	49 8d 45 5c          	lea    0x5c(%r13),%rax
  67410c:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  674111:	45 31 ff             	xor    %r15d,%r15d
  674114:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  67411b:	00 
  67411c:	4c 8b 05 85 60 11 00 	mov    0x116085(%rip),%r8        # 78a1a8 <_DYNAMIC+0x428>
  674123:	49 89 d6             	mov    %rdx,%r14
  674126:	44 89 7c 24 30       	mov    %r15d,0x30(%rsp)
  67412b:	eb 1c                	jmp    674149 <<gpui_canvas::text::planner::Planner>::shape+0xe9>
  67412d:	0f 1f 00             	nopl   (%rax)
  674130:	41 8d 87 d8 df ff ff 	lea    -0x2028(%r15),%eax
  674137:	83 f8 02             	cmp    $0x2,%eax
  67413a:	0f 83 e1 00 00 00    	jae    674221 <<gpui_canvas::text::planner::Planner>::shape+0x1c1>
  674140:	4d 39 e6             	cmp    %r12,%r14
  674143:	0f 84 ba 02 00 00    	je     674403 <<gpui_canvas::text::planner::Planner>::shape+0x3a3>
  674149:	45 0f b6 3e          	movzbl (%r14),%r15d
  67414d:	45 84 ff             	test   %r15b,%r15b
  674150:	78 1e                	js     674170 <<gpui_canvas::text::planner::Planner>::shape+0x110>
  674152:	49 ff c6             	inc    %r14
  674155:	41 81 ff 27 20 00 00 	cmp    $0x2027,%r15d
  67415c:	0f 8e 9e 00 00 00    	jle    674200 <<gpui_canvas::text::planner::Planner>::shape+0x1a0>
  674162:	eb cc                	jmp    674130 <<gpui_canvas::text::planner::Planner>::shape+0xd0>
  674164:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  67416b:	00 00 00 00 00 
  674170:	44 89 f8             	mov    %r15d,%eax
  674173:	83 e0 1f             	and    $0x1f,%eax
  674176:	41 0f b6 56 01       	movzbl 0x1(%r14),%edx
  67417b:	83 e2 3f             	and    $0x3f,%edx
  67417e:	41 80 ff df          	cmp    $0xdf,%r15b
  674182:	76 3d                	jbe    6741c1 <<gpui_canvas::text::planner::Planner>::shape+0x161>
  674184:	41 0f b6 4e 02       	movzbl 0x2(%r14),%ecx
  674189:	c1 e2 06             	shl    $0x6,%edx
  67418c:	83 e1 3f             	and    $0x3f,%ecx
  67418f:	09 d1                	or     %edx,%ecx
  674191:	41 80 ff f0          	cmp    $0xf0,%r15b
  674195:	72 44                	jb     6741db <<gpui_canvas::text::planner::Planner>::shape+0x17b>
  674197:	45 0f b6 7e 03       	movzbl 0x3(%r14),%r15d
  67419c:	49 83 c6 04          	add    $0x4,%r14
  6741a0:	83 e0 07             	and    $0x7,%eax
  6741a3:	c1 e0 12             	shl    $0x12,%eax
  6741a6:	c1 e1 06             	shl    $0x6,%ecx
  6741a9:	41 83 e7 3f          	and    $0x3f,%r15d
  6741ad:	41 09 cf             	or     %ecx,%r15d
  6741b0:	41 09 c7             	or     %eax,%r15d
  6741b3:	41 81 ff 27 20 00 00 	cmp    $0x2027,%r15d
  6741ba:	7e 44                	jle    674200 <<gpui_canvas::text::planner::Planner>::shape+0x1a0>
  6741bc:	e9 6f ff ff ff       	jmp    674130 <<gpui_canvas::text::planner::Planner>::shape+0xd0>
  6741c1:	49 83 c6 02          	add    $0x2,%r14
  6741c5:	c1 e0 06             	shl    $0x6,%eax
  6741c8:	09 d0                	or     %edx,%eax
  6741ca:	41 89 c7             	mov    %eax,%r15d
  6741cd:	41 81 ff 27 20 00 00 	cmp    $0x2027,%r15d
  6741d4:	7e 2a                	jle    674200 <<gpui_canvas::text::planner::Planner>::shape+0x1a0>
  6741d6:	e9 55 ff ff ff       	jmp    674130 <<gpui_canvas::text::planner::Planner>::shape+0xd0>
  6741db:	49 83 c6 03          	add    $0x3,%r14
  6741df:	c1 e0 0c             	shl    $0xc,%eax
  6741e2:	09 c1                	or     %eax,%ecx
  6741e4:	41 89 cf             	mov    %ecx,%r15d
  6741e7:	41 81 ff 27 20 00 00 	cmp    $0x2027,%r15d
  6741ee:	0f 8f 3c ff ff ff    	jg     674130 <<gpui_canvas::text::planner::Planner>::shape+0xd0>
  6741f4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  6741fb:	00 00 00 00 00 
  674200:	41 83 ff 0a          	cmp    $0xa,%r15d
  674204:	0f 84 36 ff ff ff    	je     674140 <<gpui_canvas::text::planner::Planner>::shape+0xe0>
  67420a:	41 83 ff 0d          	cmp    $0xd,%r15d
  67420e:	0f 84 2c ff ff ff    	je     674140 <<gpui_canvas::text::planner::Planner>::shape+0xe0>
  674214:	41 81 ff 85 00 00 00 	cmp    $0x85,%r15d
  67421b:	0f 84 1f ff ff ff    	je     674140 <<gpui_canvas::text::planner::Planner>::shape+0xe0>
  674221:	49 89 fd             	mov    %rdi,%r13
  674224:	48 8d 3d 0d b7 10 00 	lea    0x10b70d(%rip),%rdi        # 77f938 <anon.1a3692c52bba9218a112fc8e64fef457.3.llvm.8970656708749461829+0x388>
  67422b:	48 89 f3             	mov    %rsi,%rbx
  67422e:	44 89 fe             	mov    %r15d,%esi
  674231:	4c 89 c5             	mov    %r8,%rbp
  674234:	ff 15 76 62 11 00    	call   *0x116276(%rip)        # 78a4b0 <_DYNAMIC+0x730>
  67423a:	49 89 e8             	mov    %rbp,%r8
  67423d:	4c 89 ef             	mov    %r13,%rdi
  674240:	48 89 de             	mov    %rbx,%rsi
  674243:	84 c0                	test   %al,%al
  674245:	0f 85 f5 fe ff ff    	jne    674140 <<gpui_canvas::text::planner::Planner>::shape+0xe0>
  67424b:	41 bc 0a 00 00 00    	mov    $0xa,%r12d
  674251:	41 83 ff 20          	cmp    $0x20,%r15d
  674255:	0f 82 5b 02 00 00    	jb     6744b6 <<gpui_canvas::text::planner::Planner>::shape+0x456>
  67425b:	41 8d 47 81          	lea    -0x7f(%r15),%eax
  67425f:	83 f8 21             	cmp    $0x21,%eax
  674262:	0f 82 4e 02 00 00    	jb     6744b6 <<gpui_canvas::text::planner::Planner>::shape+0x456>
  674268:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  67426d:	44 89 fe             	mov    %r15d,%esi
  674270:	e8 bb 3b 00 00       	call   677e30 <<gpui_canvas::text::planner::Cmap>::glyph_index>
  674275:	49 89 e8             	mov    %rbp,%r8
  674278:	4c 89 ef             	mov    %r13,%rdi
  67427b:	a8 01                	test   $0x1,%al
  67427d:	4c 8b a4 24 b0 01 00 	mov    0x1b0(%rsp),%r12
  674284:	00 
  674285:	74 0c                	je     674293 <<gpui_canvas::text::planner::Planner>::shape+0x233>
  674287:	48 89 de             	mov    %rbx,%rsi
  67428a:	66 85 d2             	test   %dx,%dx
  67428d:	0f 85 ad fe ff ff    	jne    674140 <<gpui_canvas::text::planner::Planner>::shape+0xe0>
  674293:	48 8b 0c 24          	mov    (%rsp),%rcx
  674297:	48 8b 81 40 0a 00 00 	mov    0xa40(%rcx),%rax
  67429e:	41 bc 0b 00 00 00    	mov    $0xb,%r12d
  6742a4:	80 78 38 01          	cmpb   $0x1,0x38(%rax)
  6742a8:	0f 85 08 02 00 00    	jne    6744b6 <<gpui_canvas::text::planner::Planner>::shape+0x456>
  6742ae:	48 83 79 30 00       	cmpq   $0x0,0x30(%rcx)
  6742b3:	0f 85 e9 00 00 00    	jne    6743a2 <<gpui_canvas::text::planner::Planner>::shape+0x342>
  6742b9:	ba 48 ab 03 00       	mov    $0x3ab48,%edx
  6742be:	48 8d 35 27 18 9b ff 	lea    -0x64e7d9(%rip),%rsi        # 25aec <gpui_canvas::text::ARABIC_BYTES>
  6742c5:	31 c9                	xor    %ecx,%ecx
  6742c7:	41 ff d0             	call   *%r8
  6742ca:	83 bc 24 10 07 00 00 	cmpl   $0xffffffff,0x710(%rsp)
  6742d1:	ff 
  6742d2:	0f 84 7d 2f 00 00    	je     677255 <<gpui_canvas::text::planner::Planner>::shape+0x31f5>
  6742d8:	8b 84 24 e8 0c 00 00 	mov    0xce8(%rsp),%eax
  6742df:	89 44 24 08          	mov    %eax,0x8(%rsp)
  6742e3:	0f 10 03             	movups (%rbx),%xmm0
  6742e6:	0f 10 4b 0c          	movups 0xc(%rbx),%xmm1
  6742ea:	0f 29 84 24 c0 04 00 	movaps %xmm0,0x4c0(%rsp)
  6742f1:	00 
  6742f2:	0f 11 8c 24 cc 04 00 	movups %xmm1,0x4cc(%rsp)
  6742f9:	00 
  6742fa:	ba 14 69 00 00       	mov    $0x6914,%edx
  6742ff:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  674306:	00 
  674307:	48 8d 35 26 c3 9e ff 	lea    -0x613cda(%rip),%rsi        # 60634 <gpui_canvas::text::HEBREW_BYTES>
  67430e:	31 c9                	xor    %ecx,%ecx
  674310:	ff 15 92 5e 11 00    	call   *0x115e92(%rip)        # 78a1a8 <_DYNAMIC+0x428>
  674316:	83 bc 24 10 07 00 00 	cmpl   $0xffffffff,0x710(%rsp)
  67431d:	ff 
  67431e:	0f 84 43 2f 00 00    	je     677267 <<gpui_canvas::text::planner::Planner>::shape+0x3207>
  674324:	8b 94 24 e8 0c 00 00 	mov    0xce8(%rsp),%edx
  67432b:	48 8d 84 24 ec 0c 00 	lea    0xcec(%rsp),%rax
  674332:	00 
  674333:	0f 10 00             	movups (%rax),%xmm0
  674336:	0f 10 48 0c          	movups 0xc(%rax),%xmm1
  67433a:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
  674341:	00 
  674342:	0f 11 8c 24 4c 03 00 	movups %xmm1,0x34c(%rsp)
  674349:	00 
  67434a:	48 8b 04 24          	mov    (%rsp),%rax
  67434e:	48 c7 40 30 01 00 00 	movq   $0x1,0x30(%rax)
  674355:	00 
  674356:	8b 4c 24 08          	mov    0x8(%rsp),%ecx
  67435a:	89 48 38             	mov    %ecx,0x38(%rax)
  67435d:	0f 10 84 24 cc 04 00 	movups 0x4cc(%rsp),%xmm0
  674364:	00 
  674365:	48 8b 8c 24 00 01 00 	mov    0x100(%rsp),%rcx
  67436c:	00 
  67436d:	0f 11 41 0c          	movups %xmm0,0xc(%rcx)
  674371:	0f 28 84 24 c0 04 00 	movaps 0x4c0(%rsp),%xmm0
  674378:	00 
  674379:	0f 11 01             	movups %xmm0,(%rcx)
  67437c:	89 94 24 d0 01 00 00 	mov    %edx,0x1d0(%rsp)
  674383:	89 50 58             	mov    %edx,0x58(%rax)
  674386:	0f 10 84 24 4c 03 00 	movups 0x34c(%rsp),%xmm0
  67438d:	00 
  67438e:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  674393:	0f 11 40 0c          	movups %xmm0,0xc(%rax)
  674397:	0f 28 84 24 40 03 00 	movaps 0x340(%rsp),%xmm0
  67439e:	00 
  67439f:	0f 11 00             	movups %xmm0,(%rax)
  6743a2:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
  6743a7:	44 89 fe             	mov    %r15d,%esi
  6743aa:	e8 81 3a 00 00       	call   677e30 <<gpui_canvas::text::planner::Cmap>::glyph_index>
  6743af:	66 85 d2             	test   %dx,%dx
  6743b2:	0f 95 c1             	setne  %cl
  6743b5:	20 c1                	and    %al,%cl
  6743b7:	88 4c 24 60          	mov    %cl,0x60(%rsp)
  6743bb:	48 8b bc 24 10 01 00 	mov    0x110(%rsp),%rdi
  6743c2:	00 
  6743c3:	44 89 fe             	mov    %r15d,%esi
  6743c6:	e8 65 3a 00 00       	call   677e30 <<gpui_canvas::text::planner::Cmap>::glyph_index>
  6743cb:	66 85 d2             	test   %dx,%dx
  6743ce:	0f 95 c1             	setne  %cl
  6743d1:	20 c1                	and    %al,%cl
  6743d3:	00 c9                	add    %cl,%cl
  6743d5:	0a 4c 24 60          	or     0x60(%rsp),%cl
  6743d9:	0f 84 d7 00 00 00    	je     6744b6 <<gpui_canvas::text::planner::Planner>::shape+0x456>
  6743df:	44 8b 7c 24 30       	mov    0x30(%rsp),%r15d
  6743e4:	41 08 cf             	or     %cl,%r15b
  6743e7:	4c 8b a4 24 b0 01 00 	mov    0x1b0(%rsp),%r12
  6743ee:	00 
  6743ef:	4d 39 e6             	cmp    %r12,%r14
  6743f2:	48 89 de             	mov    %rbx,%rsi
  6743f5:	4c 89 ef             	mov    %r13,%rdi
  6743f8:	49 89 e8             	mov    %rbp,%r8
  6743fb:	0f 85 25 fd ff ff    	jne    674126 <<gpui_canvas::text::planner::Planner>::shape+0xc6>
  674401:	eb 05                	jmp    674408 <<gpui_canvas::text::planner::Planner>::shape+0x3a8>
  674403:	44 8b 7c 24 30       	mov    0x30(%rsp),%r15d
  674408:	41 f6 c7 01          	test   $0x1,%r15b
  67440c:	4c 8b 2c 24          	mov    (%rsp),%r13
  674410:	0f 84 c5 00 00 00    	je     6744db <<gpui_canvas::text::planner::Planner>::shape+0x47b>
  674416:	49 83 bd 48 0a 00 00 	cmpq   $0x0,0xa48(%r13)
  67441d:	00 
  67441e:	0f 85 b7 00 00 00    	jne    6744db <<gpui_canvas::text::planner::Planner>::shape+0x47b>
  674424:	48 8d 35 cd 8b 11 00 	lea    0x118bcd(%rip),%rsi        # 78cff8 <gpui_canvas::text::ARABIC_FONT>
  67442b:	48 8d 15 ba 16 9b ff 	lea    -0x64e946(%rip),%rdx        # 25aec <gpui_canvas::text::ARABIC_BYTES>
  674432:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  674439:	00 
  67443a:	b9 48 ab 03 00       	mov    $0x3ab48,%ecx
  67443f:	45 31 c0             	xor    %r8d,%r8d
  674442:	e8 d9 fa fe ff       	call   663f20 <<gpui_canvas::text::FontFace>::shared_static>
  674447:	83 bc 24 10 07 00 00 	cmpl   $0x1,0x710(%rsp)
  67444e:	01 
  67444f:	75 1a                	jne    67446b <<gpui_canvas::text::planner::Planner>::shape+0x40b>
  674451:	44 8b a4 24 14 07 00 	mov    0x714(%rsp),%r12d
  674458:	00 
  674459:	44 8b bc 24 18 07 00 	mov    0x718(%rsp),%r15d
  674460:	00 
  674461:	eb 53                	jmp    6744b6 <<gpui_canvas::text::planner::Planner>::shape+0x456>
  674463:	45 31 ff             	xor    %r15d,%r15d
  674466:	e9 84 00 00 00       	jmp    6744ef <<gpui_canvas::text::planner::Planner>::shape+0x48f>
  67446b:	44 89 fd             	mov    %r15d,%ebp
  67446e:	49 8d 9d 48 0a 00 00 	lea    0xa48(%r13),%rbx
  674475:	4c 8b bc 24 18 07 00 	mov    0x718(%rsp),%r15
  67447c:	00 
  67447d:	48 8b 03             	mov    (%rbx),%rax
  674480:	48 85 c0             	test   %rax,%rax
  674483:	74 0f                	je     674494 <<gpui_canvas::text::planner::Planner>::shape+0x434>
  674485:	f0 48 ff 08          	lock decq (%rax)
  674489:	75 09                	jne    674494 <<gpui_canvas::text::planner::Planner>::shape+0x434>
  67448b:	48 89 df             	mov    %rbx,%rdi
  67448e:	ff 15 4c 5b 11 00    	call   *0x115b4c(%rip)        # 789fe0 <_DYNAMIC+0x260>
  674494:	4d 89 bd 48 0a 00 00 	mov    %r15,0xa48(%r13)
  67449b:	be 01 00 00 00       	mov    $0x1,%esi
  6744a0:	4c 89 ef             	mov    %r13,%rdi
  6744a3:	e8 88 36 00 00       	call   677b30 <<gpui_canvas::text::planner::Planner>::register>
  6744a8:	83 f8 ff             	cmp    $0xffffffff,%eax
  6744ab:	41 89 ef             	mov    %ebp,%r15d
  6744ae:	74 2b                	je     6744db <<gpui_canvas::text::planner::Planner>::shape+0x47b>
  6744b0:	41 89 c4             	mov    %eax,%r12d
  6744b3:	45 31 ff             	xor    %r15d,%r15d
  6744b6:	44 89 a4 24 90 00 00 	mov    %r12d,0x90(%rsp)
  6744bd:	00 
  6744be:	44 89 bc 24 94 00 00 	mov    %r15d,0x94(%rsp)
  6744c5:	00 
  6744c6:	48 c7 84 24 88 00 00 	movq   $0xffffffffffffffff,0x88(%rsp)
  6744cd:	00 ff ff ff ff 
  6744d2:	4c 8b 2c 24          	mov    (%rsp),%r13
  6744d6:	e9 a6 28 00 00       	jmp    676d81 <<gpui_canvas::text::planner::Planner>::shape+0x2d21>
  6744db:	41 f6 c7 02          	test   $0x2,%r15b
  6744df:	74 0e                	je     6744ef <<gpui_canvas::text::planner::Planner>::shape+0x48f>
  6744e1:	49 83 bd 50 0a 00 00 	cmpq   $0x0,0xa50(%r13)
  6744e8:	00 
  6744e9:	0f 84 2f 2a 00 00    	je     676f1e <<gpui_canvas::text::planner::Planner>::shape+0x2ebe>
  6744ef:	48 c7 84 24 a0 02 00 	movq   $0xffffffffffffffff,0x2a0(%rsp)
  6744f6:	00 ff ff ff ff 
  6744fb:	48 8d 05 50 73 be ff 	lea    -0x418cb0(%rip),%rax        # 25b852 <anon.1a3692c52bba9218a112fc8e64fef457.1.llvm.8970656708749461829+0x2c6>
  674502:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
  674509:	00 
  67450a:	48 c7 84 24 b0 02 00 	movq   $0xc,0x2b0(%rsp)
  674511:	00 0c 00 00 00 
  674516:	48 c7 84 24 b8 02 00 	movq   $0xffffffffffffffff,0x2b8(%rsp)
  67451d:	00 ff ff ff ff 
  674522:	48 8d 05 35 73 be ff 	lea    -0x418ccb(%rip),%rax        # 25b85e <anon.1a3692c52bba9218a112fc8e64fef457.1.llvm.8970656708749461829+0x2d2>
  674529:	48 89 84 24 c0 02 00 	mov    %rax,0x2c0(%rsp)
  674530:	00 
  674531:	48 c7 84 24 c8 02 00 	movq   $0x11,0x2c8(%rsp)
  674538:	00 11 00 00 00 
  67453d:	48 c7 84 24 d0 02 00 	movq   $0xffffffffffffffff,0x2d0(%rsp)
  674544:	00 ff ff ff ff 
  674549:	48 8d 1d 1f 73 be ff 	lea    -0x418ce1(%rip),%rbx        # 25b86f <anon.1a3692c52bba9218a112fc8e64fef457.1.llvm.8970656708749461829+0x2e3>
  674550:	48 89 9c 24 d8 02 00 	mov    %rbx,0x2d8(%rsp)
  674557:	00 
  674558:	48 c7 84 24 e0 02 00 	movq   $0x11,0x2e0(%rsp)
  67455f:	00 11 00 00 00 
  674564:	41 f6 c7 01          	test   $0x1,%r15b
  674568:	75 1d                	jne    674587 <<gpui_canvas::text::planner::Planner>::shape+0x527>
  67456a:	4c 8d b4 24 b8 02 00 	lea    0x2b8(%rsp),%r14
  674571:	00 
  674572:	b8 01 00 00 00       	mov    $0x1,%eax
  674577:	48 89 84 24 10 02 00 	mov    %rax,0x210(%rsp)
  67457e:	00 
  67457f:	41 f6 c7 02          	test   $0x2,%r15b
  674583:	75 25                	jne    6745aa <<gpui_canvas::text::planner::Planner>::shape+0x54a>
  674585:	eb 5b                	jmp    6745e2 <<gpui_canvas::text::planner::Planner>::shape+0x582>
  674587:	4c 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%r14
  67458e:	00 
  67458f:	48 89 84 24 c0 02 00 	mov    %rax,0x2c0(%rsp)
  674596:	00 
  674597:	b8 02 00 00 00       	mov    $0x2,%eax
  67459c:	48 89 84 24 10 02 00 	mov    %rax,0x210(%rsp)
  6745a3:	00 
  6745a4:	41 f6 c7 02          	test   $0x2,%r15b
  6745a8:	74 38                	je     6745e2 <<gpui_canvas::text::planner::Planner>::shape+0x582>
  6745aa:	49 8b 36             	mov    (%r14),%rsi
  6745ad:	48 83 fe fd          	cmp    $0xfffffffffffffffd,%rsi
  6745b1:	77 14                	ja     6745c7 <<gpui_canvas::text::planner::Planner>::shape+0x567>
  6745b3:	48 85 f6             	test   %rsi,%rsi
  6745b6:	74 0f                	je     6745c7 <<gpui_canvas::text::planner::Planner>::shape+0x567>
  6745b8:	49 8b 7e 08          	mov    0x8(%r14),%rdi
  6745bc:	ba 01 00 00 00       	mov    $0x1,%edx
  6745c1:	ff 15 f1 59 11 00    	call   *0x1159f1(%rip)        # 789fb8 <_DYNAMIC+0x238>
  6745c7:	49 c7 06 ff ff ff ff 	movq   $0xffffffffffffffff,(%r14)
  6745ce:	49 89 5e 08          	mov    %rbx,0x8(%r14)
  6745d2:	49 c7 46 10 11 00 00 	movq   $0x11,0x10(%r14)
  6745d9:	00 
  6745da:	48 ff 84 24 10 02 00 	incq   0x210(%rsp)
  6745e1:	00 
  6745e2:	48 c7 84 24 e8 00 00 	movq   $0x0,0xe8(%rsp)
  6745e9:	00 00 00 00 00 
  6745ee:	48 c7 84 24 f0 00 00 	movq   $0x4,0xf0(%rsp)
  6745f5:	00 04 00 00 00 
  6745fa:	48 c7 84 24 f8 00 00 	movq   $0x0,0xf8(%rsp)
  674601:	00 00 00 00 00 
  674606:	48 c7 84 24 50 01 00 	movq   $0xffffffffffffffff,0x150(%rsp)
  67460d:	00 ff ff ff ff 
  674612:	f6 84 24 c8 01 00 00 	testb  $0x1,0x1c8(%rsp)
  674619:	01 
  67461a:	75 11                	jne    67462d <<gpui_canvas::text::planner::Planner>::shape+0x5cd>
  67461c:	f3 0f 10 05 18 92 9a 	movss  -0x656de8(%rip),%xmm0        # 1d83c <GCC_except_table0+0x94>
  674623:	ff 
  674624:	f3 0f 11 84 24 cc 01 	movss  %xmm0,0x1cc(%rsp)
  67462b:	00 00 
  67462d:	49 8d 45 78          	lea    0x78(%r13),%rax
  674631:	48 89 84 24 30 03 00 	mov    %rax,0x330(%rsp)
  674638:	00 
  674639:	49 8d 85 38 06 00 00 	lea    0x638(%r13),%rax
  674640:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
  674647:	00 
  674648:	49 8d 85 c8 08 00 00 	lea    0x8c8(%r13),%rax
  67464f:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  674654:	4c 8d ac 24 50 03 00 	lea    0x350(%rsp),%r13
  67465b:	00 
  67465c:	0f 57 c0             	xorps  %xmm0,%xmm0
  67465f:	0f 29 84 24 80 02 00 	movaps %xmm0,0x280(%rsp)
  674666:	00 
  674667:	f3 0f 11 44 24 1c    	movss  %xmm0,0x1c(%rsp)
  67466d:	f3 0f 11 44 24 7c    	movss  %xmm0,0x7c(%rsp)
  674673:	4c 8d a4 24 c8 04 00 	lea    0x4c8(%rsp),%r12
  67467a:	00 
  67467b:	48 8d 05 f6 b3 10 00 	lea    0x10b3f6(%rip),%rax        # 77fa78 <anon.1a3692c52bba9218a112fc8e64fef457.3.llvm.8970656708749461829+0x4c8>
  674682:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  674687:	48 8d 05 92 ae 10 00 	lea    0x10ae92(%rip),%rax        # 77f520 <anon.98eb2121465841304e196c1cc83cb241.21.llvm.14436572662246312189>
  67468e:	48 89 84 24 70 02 00 	mov    %rax,0x270(%rsp)
  674695:	00 
  674696:	48 c7 84 24 08 02 00 	movq   $0x0,0x208(%rsp)
  67469d:	00 00 00 00 00 
  6746a2:	31 d2                	xor    %edx,%edx
  6746a4:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  6746ab:	00 
  6746ac:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  6746b1:	31 c0                	xor    %eax,%eax
  6746b3:	be fe ff ff ff       	mov    $0xfffffffe,%esi
  6746b8:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
  6746bd:	83 fe fe             	cmp    $0xfffffffe,%esi
  6746c0:	75 2e                	jne    6746f0 <<gpui_canvas::text::planner::Planner>::shape+0x690>
  6746c2:	4c 8b 4c 24 28       	mov    0x28(%rsp),%r9
  6746c7:	4c 3b 8c 24 b0 01 00 	cmp    0x1b0(%rsp),%r9
  6746ce:	00 
  6746cf:	74 33                	je     674704 <<gpui_canvas::text::planner::Planner>::shape+0x6a4>
  6746d1:	41 0f b6 09          	movzbl (%r9),%ecx
  6746d5:	84 c9                	test   %cl,%cl
  6746d7:	78 46                	js     67471f <<gpui_canvas::text::planner::Planner>::shape+0x6bf>
  6746d9:	49 8d 51 01          	lea    0x1(%r9),%rdx
  6746dd:	e9 9a 00 00 00       	jmp    67477c <<gpui_canvas::text::planner::Planner>::shape+0x71c>
  6746e2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6746e9:	1f 84 00 00 00 00 00 
  6746f0:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
  6746f5:	89 f1                	mov    %esi,%ecx
  6746f7:	4c 8b 84 24 10 03 00 	mov    0x310(%rsp),%r8
  6746fe:	00 
  6746ff:	e9 81 00 00 00       	jmp    674785 <<gpui_canvas::text::planner::Planner>::shape+0x725>
  674704:	c7 84 24 80 00 00 00 	movl   $0xfffffffe,0x80(%rsp)
  67470b:	fe ff ff ff 
  67470f:	b1 01                	mov    $0x1,%cl
  674711:	89 4c 24 4c          	mov    %ecx,0x4c(%rsp)
  674715:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
  67471a:	e9 d7 01 00 00       	jmp    6748f6 <<gpui_canvas::text::planner::Planner>::shape+0x896>
  67471f:	49 89 c0             	mov    %rax,%r8
  674722:	89 c8                	mov    %ecx,%eax
  674724:	83 e0 1f             	and    $0x1f,%eax
  674727:	41 0f b6 79 01       	movzbl 0x1(%r9),%edi
  67472c:	83 e7 3f             	and    $0x3f,%edi
  67472f:	80 f9 e0             	cmp    $0xe0,%cl
  674732:	72 2d                	jb     674761 <<gpui_canvas::text::planner::Planner>::shape+0x701>
  674734:	41 0f b6 71 02       	movzbl 0x2(%r9),%esi
  674739:	c1 e7 06             	shl    $0x6,%edi
  67473c:	83 e6 3f             	and    $0x3f,%esi
  67473f:	09 fe                	or     %edi,%esi
  674741:	80 f9 f0             	cmp    $0xf0,%cl
  674744:	72 28                	jb     67476e <<gpui_canvas::text::planner::Planner>::shape+0x70e>
  674746:	49 8d 51 04          	lea    0x4(%r9),%rdx
  67474a:	41 0f b6 49 03       	movzbl 0x3(%r9),%ecx
  67474f:	83 e0 07             	and    $0x7,%eax
  674752:	c1 e0 12             	shl    $0x12,%eax
  674755:	c1 e6 06             	shl    $0x6,%esi
  674758:	83 e1 3f             	and    $0x3f,%ecx
  67475b:	09 f1                	or     %esi,%ecx
  67475d:	09 c1                	or     %eax,%ecx
  67475f:	eb 18                	jmp    674779 <<gpui_canvas::text::planner::Planner>::shape+0x719>
  674761:	49 8d 51 02          	lea    0x2(%r9),%rdx
  674765:	c1 e0 06             	shl    $0x6,%eax
  674768:	09 f8                	or     %edi,%eax
  67476a:	89 c1                	mov    %eax,%ecx
  67476c:	eb 0b                	jmp    674779 <<gpui_canvas::text::planner::Planner>::shape+0x719>
  67476e:	49 8d 51 03          	lea    0x3(%r9),%rdx
  674772:	c1 e0 0c             	shl    $0xc,%eax
  674775:	09 c6                	or     %eax,%esi
  674777:	89 f1                	mov    %esi,%ecx
  674779:	4c 89 c0             	mov    %r8,%rax
  67477c:	49 89 c0             	mov    %rax,%r8
  67477f:	4c 29 c8             	sub    %r9,%rax
  674782:	48 01 d0             	add    %rdx,%rax
  674785:	c7 84 24 80 00 00 00 	movl   $0xfffffffe,0x80(%rsp)
  67478c:	fe ff ff ff 
  674790:	40 b6 01             	mov    $0x1,%sil
  674793:	89 74 24 4c          	mov    %esi,0x4c(%rsp)
  674797:	83 f9 0c             	cmp    $0xc,%ecx
  67479a:	7e 24                	jle    6747c0 <<gpui_canvas::text::planner::Planner>::shape+0x760>
  67479c:	83 f9 0d             	cmp    $0xd,%ecx
  67479f:	0f 84 5b 01 00 00    	je     674900 <<gpui_canvas::text::planner::Planner>::shape+0x8a0>
  6747a5:	81 f9 85 00 00 00    	cmp    $0x85,%ecx
  6747ab:	74 21                	je     6747ce <<gpui_canvas::text::planner::Planner>::shape+0x76e>
  6747ad:	81 f9 29 20 00 00    	cmp    $0x2029,%ecx
  6747b3:	74 19                	je     6747ce <<gpui_canvas::text::planner::Planner>::shape+0x76e>
  6747b5:	e9 83 00 00 00       	jmp    67483d <<gpui_canvas::text::planner::Planner>::shape+0x7dd>
  6747ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  6747c0:	83 f9 ff             	cmp    $0xffffffff,%ecx
  6747c3:	0f 84 23 01 00 00    	je     6748ec <<gpui_canvas::text::planner::Planner>::shape+0x88c>
  6747c9:	83 f9 0a             	cmp    $0xa,%ecx
  6747cc:	75 6f                	jne    67483d <<gpui_canvas::text::planner::Planner>::shape+0x7dd>
  6747ce:	48 89 54 24 28       	mov    %rdx,0x28(%rsp)
  6747d3:	81 f9 80 00 00 00    	cmp    $0x80,%ecx
  6747d9:	0f 83 32 01 00 00    	jae    674911 <<gpui_canvas::text::planner::Planner>::shape+0x8b1>
  6747df:	49 8d 70 01          	lea    0x1(%r8),%rsi
  6747e3:	83 f9 0d             	cmp    $0xd,%ecx
  6747e6:	0f 85 37 01 00 00    	jne    674923 <<gpui_canvas::text::planner::Planner>::shape+0x8c3>
  6747ec:	4c 8b 4c 24 28       	mov    0x28(%rsp),%r9
  6747f1:	4c 3b 8c 24 b0 01 00 	cmp    0x1b0(%rsp),%r9
  6747f8:	00 
  6747f9:	0f 84 68 23 00 00    	je     676b67 <<gpui_canvas::text::planner::Planner>::shape+0x2b07>
  6747ff:	45 0f b6 11          	movzbl (%r9),%r10d
  674803:	49 89 f3             	mov    %rsi,%r11
  674806:	45 84 d2             	test   %r10b,%r10b
  674809:	0f 88 68 23 00 00    	js     676b77 <<gpui_canvas::text::planner::Planner>::shape+0x2b17>
  67480f:	49 8d 59 01          	lea    0x1(%r9),%rbx
  674813:	e9 be 23 00 00       	jmp    676bd6 <<gpui_canvas::text::planner::Planner>::shape+0x2b76>
  674818:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  67481f:	00 
  674820:	81 f9 29 20 00 00    	cmp    $0x2029,%ecx
  674826:	0f 84 d9 00 00 00    	je     674905 <<gpui_canvas::text::planner::Planner>::shape+0x8a5>
  67482c:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
  674831:	81 f9 85 00 00 00    	cmp    $0x85,%ecx
  674837:	0f 84 c8 00 00 00    	je     674905 <<gpui_canvas::text::planner::Planner>::shape+0x8a5>
  67483d:	48 3b 94 24 b0 01 00 	cmp    0x1b0(%rsp),%rdx
  674844:	00 
  674845:	0f 84 a1 00 00 00    	je     6748ec <<gpui_canvas::text::planner::Planner>::shape+0x88c>
  67484b:	49 89 c0             	mov    %rax,%r8
  67484e:	0f b6 0a             	movzbl (%rdx),%ecx
  674851:	84 c9                	test   %cl,%cl
  674853:	78 0b                	js     674860 <<gpui_canvas::text::planner::Planner>::shape+0x800>
  674855:	48 8d 42 01          	lea    0x1(%rdx),%rax
  674859:	eb 65                	jmp    6748c0 <<gpui_canvas::text::planner::Planner>::shape+0x860>
  67485b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  674860:	89 c8                	mov    %ecx,%eax
  674862:	83 e0 1f             	and    $0x1f,%eax
  674865:	0f b6 7a 01          	movzbl 0x1(%rdx),%edi
  674869:	83 e7 3f             	and    $0x3f,%edi
  67486c:	80 f9 df             	cmp    $0xdf,%cl
  67486f:	76 2e                	jbe    67489f <<gpui_canvas::text::planner::Planner>::shape+0x83f>
  674871:	0f b6 72 02          	movzbl 0x2(%rdx),%esi
  674875:	c1 e7 06             	shl    $0x6,%edi
  674878:	83 e6 3f             	and    $0x3f,%esi
  67487b:	09 fe                	or     %edi,%esi
  67487d:	80 f9 f0             	cmp    $0xf0,%cl
  674880:	72 2d                	jb     6748af <<gpui_canvas::text::planner::Planner>::shape+0x84f>
  674882:	48 8d 7a 04          	lea    0x4(%rdx),%rdi
  674886:	0f b6 4a 03          	movzbl 0x3(%rdx),%ecx
  67488a:	83 e0 07             	and    $0x7,%eax
  67488d:	c1 e0 12             	shl    $0x12,%eax
  674890:	c1 e6 06             	shl    $0x6,%esi
  674893:	83 e1 3f             	and    $0x3f,%ecx
  674896:	09 f1                	or     %esi,%ecx
  674898:	09 c1                	or     %eax,%ecx
  67489a:	48 89 f8             	mov    %rdi,%rax
  67489d:	eb 21                	jmp    6748c0 <<gpui_canvas::text::planner::Planner>::shape+0x860>
  67489f:	48 8d 72 02          	lea    0x2(%rdx),%rsi
  6748a3:	c1 e0 06             	shl    $0x6,%eax
  6748a6:	09 f8                	or     %edi,%eax
  6748a8:	89 c1                	mov    %eax,%ecx
  6748aa:	48 89 f0             	mov    %rsi,%rax
  6748ad:	eb 11                	jmp    6748c0 <<gpui_canvas::text::planner::Planner>::shape+0x860>
  6748af:	48 8d 4a 03          	lea    0x3(%rdx),%rcx
  6748b3:	c1 e0 0c             	shl    $0xc,%eax
  6748b6:	09 c6                	or     %eax,%esi
  6748b8:	48 89 c8             	mov    %rcx,%rax
  6748bb:	89 f1                	mov    %esi,%ecx
  6748bd:	0f 1f 00             	nopl   (%rax)
  6748c0:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  6748c5:	48 29 d0             	sub    %rdx,%rax
  6748c8:	4c 01 c0             	add    %r8,%rax
  6748cb:	81 f9 84 00 00 00    	cmp    $0x84,%ecx
  6748d1:	0f 8f 49 ff ff ff    	jg     674820 <<gpui_canvas::text::planner::Planner>::shape+0x7c0>
  6748d7:	83 f9 0a             	cmp    $0xa,%ecx
  6748da:	74 29                	je     674905 <<gpui_canvas::text::planner::Planner>::shape+0x8a5>
  6748dc:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
  6748e1:	83 f9 0d             	cmp    $0xd,%ecx
  6748e4:	0f 85 53 ff ff ff    	jne    67483d <<gpui_canvas::text::planner::Planner>::shape+0x7dd>
  6748ea:	eb 19                	jmp    674905 <<gpui_canvas::text::planner::Planner>::shape+0x8a5>
  6748ec:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
  6748f1:	48 89 54 24 28       	mov    %rdx,0x28(%rsp)
  6748f6:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  6748fb:	48 89 fe             	mov    %rdi,%rsi
  6748fe:	eb 33                	jmp    674933 <<gpui_canvas::text::planner::Planner>::shape+0x8d3>
  674900:	48 89 54 24 28       	mov    %rdx,0x28(%rsp)
  674905:	81 f9 80 00 00 00    	cmp    $0x80,%ecx
  67490b:	0f 82 ce fe ff ff    	jb     6747df <<gpui_canvas::text::planner::Planner>::shape+0x77f>
  674911:	81 f9 00 08 00 00    	cmp    $0x800,%ecx
  674917:	be 03 00 00 00       	mov    $0x3,%esi
  67491c:	48 83 de 00          	sbb    $0x0,%rsi
  674920:	4c 01 c6             	add    %r8,%rsi
  674923:	c7 44 24 4c 00 00 00 	movl   $0x0,0x4c(%rsp)
  67492a:	00 
  67492b:	4c 89 c1             	mov    %r8,%rcx
  67492e:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  674933:	48 89 ca             	mov    %rcx,%rdx
  674936:	48 29 fa             	sub    %rdi,%rdx
  674939:	48 89 94 24 10 01 00 	mov    %rdx,0x110(%rsp)
  674940:	00 
  674941:	0f 82 98 2c 00 00    	jb     6775df <<gpui_canvas::text::planner::Planner>::shape+0x357f>
  674947:	48 83 7c 24 30 00    	cmpq   $0x0,0x30(%rsp)
  67494d:	48 89 84 24 20 03 00 	mov    %rax,0x320(%rsp)
  674954:	00 
  674955:	74 2f                	je     674986 <<gpui_canvas::text::planner::Planner>::shape+0x926>
  674957:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
  67495c:	48 3b 54 24 50       	cmp    0x50(%rsp),%rdx
  674961:	73 1d                	jae    674980 <<gpui_canvas::text::planner::Planner>::shape+0x920>
  674963:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  67496a:	00 
  67496b:	80 3c 10 bf          	cmpb   $0xbf,(%rax,%rdx,1)
  67496f:	7f 15                	jg     674986 <<gpui_canvas::text::planner::Planner>::shape+0x926>
  674971:	e9 69 2c 00 00       	jmp    6775df <<gpui_canvas::text::planner::Planner>::shape+0x357f>
  674976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  67497d:	00 00 00 
  674980:	0f 85 59 2c 00 00    	jne    6775df <<gpui_canvas::text::planner::Planner>::shape+0x357f>
  674986:	48 85 c9             	test   %rcx,%rcx
  674989:	74 2b                	je     6749b6 <<gpui_canvas::text::planner::Planner>::shape+0x956>
  67498b:	48 3b 4c 24 50       	cmp    0x50(%rsp),%rcx
  674990:	73 1e                	jae    6749b0 <<gpui_canvas::text::planner::Planner>::shape+0x950>
  674992:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  674999:	00 
  67499a:	80 3c 08 c0          	cmpb   $0xc0,(%rax,%rcx,1)
  67499e:	7d 16                	jge    6749b6 <<gpui_canvas::text::planner::Planner>::shape+0x956>
  6749a0:	e9 3a 2c 00 00       	jmp    6775df <<gpui_canvas::text::planner::Planner>::shape+0x357f>
  6749a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6749ac:	00 00 00 00 
  6749b0:	0f 85 29 2c 00 00    	jne    6775df <<gpui_canvas::text::planner::Planner>::shape+0x357f>
  6749b6:	48 89 8c 24 00 01 00 	mov    %rcx,0x100(%rsp)
  6749bd:	00 
  6749be:	48 89 b4 24 18 03 00 	mov    %rsi,0x318(%rsp)
  6749c5:	00 
  6749c6:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  6749cd:	00 
  6749ce:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  6749d3:	48 01 c1             	add    %rax,%rcx
  6749d6:	48 8d bc 24 98 04 00 	lea    0x498(%rsp),%rdi
  6749dd:	00 
  6749de:	48 8b b4 24 30 03 00 	mov    0x330(%rsp),%rsi
  6749e5:	00 
  6749e6:	48 8b 94 24 28 03 00 	mov    0x328(%rsp),%rdx
  6749ed:	00 
  6749ee:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  6749f3:	4c 8b 84 24 10 01 00 	mov    0x110(%rsp),%r8
  6749fa:	00 
  6749fb:	f3 0f 10 05 c9 8d 9a 	movss  -0x657237(%rip),%xmm0        # 1d7cc <GCC_except_table0+0x24>
  674a02:	ff 
  674a03:	45 31 c9             	xor    %r9d,%r9d
  674a06:	e8 65 fa fe ff       	call   664470 <<parley::context::LayoutContext<()>>::ranged_builder>
  674a0b:	48 8d bc 24 98 04 00 	lea    0x498(%rsp),%rdi
  674a12:	00 
  674a13:	48 8d b4 24 a0 02 00 	lea    0x2a0(%rsp),%rsi
  674a1a:	00 
  674a1b:	48 8b 94 24 10 02 00 	mov    0x210(%rsp),%rdx
  674a22:	00 
  674a23:	e8 d8 aa ff ff       	call   66f500 <<parley::builder::RangedBuilder<()>>::push_default::<&[parlance::font_family::FontFamilyName]>>
  674a28:	4c 8b bc 24 98 04 00 	mov    0x498(%rsp),%r15
  674a2f:	00 
  674a30:	48 8b 9c 24 a0 04 00 	mov    0x4a0(%rsp),%rbx
  674a37:	00 
  674a38:	49 8d b7 30 02 00 00 	lea    0x230(%r15),%rsi
  674a3f:	c6 84 24 10 07 00 00 	movb   $0x1,0x710(%rsp)
  674a46:	01 
  674a47:	f3 0f 10 84 24 84 00 	movss  0x84(%rsp),%xmm0
  674a4e:	00 00 
  674a50:	f3 0f 11 84 24 14 07 	movss  %xmm0,0x714(%rsp)
  674a57:	00 00 
  674a59:	f3 0f 10 84 24 b8 04 	movss  0x4b8(%rsp),%xmm0
  674a60:	00 00 
  674a62:	48 8d bc 24 c0 04 00 	lea    0x4c0(%rsp),%rdi
  674a69:	00 
  674a6a:	48 89 f5             	mov    %rsi,%rbp
  674a6d:	48 89 da             	mov    %rbx,%rdx
  674a70:	4c 8d b4 24 10 07 00 	lea    0x710(%rsp),%r14
  674a77:	00 
  674a78:	4c 89 f1             	mov    %r14,%rcx
  674a7b:	f3 0f 11 44 24 60    	movss  %xmm0,0x60(%rsp)
  674a81:	e8 1a 0b ff ff       	call   6655a0 <<parley::resolve::ResolveContext>::resolve_property::<()>>
  674a86:	4c 89 f7             	mov    %r14,%rdi
  674a89:	e8 22 ab ff ff       	call   66f5b0 <core::ptr::drop_glue::<parley::style::StyleProperty<()>>>
  674a8e:	49 83 bf 20 05 00 00 	cmpq   $0xffffffffffffffff,0x520(%r15)
  674a95:	ff 
  674a96:	0f 84 7e 27 00 00    	je     67721a <<gpui_canvas::text::planner::Planner>::shape+0x31ba>
  674a9c:	4d 8d b7 98 04 00 00 	lea    0x498(%r15),%r14
  674aa3:	4c 89 f7             	mov    %r14,%rdi
  674aa6:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
  674aad:	00 
  674aae:	e8 8d 10 ff ff       	call   665b40 <<parley::resolve::ResolvedStyle<()>>::apply>
  674ab3:	66 c7 84 24 10 07 00 	movw   $0x117,0x710(%rsp)
  674aba:	00 17 01 
  674abd:	48 8d bc 24 c0 04 00 	lea    0x4c0(%rsp),%rdi
  674ac4:	00 
  674ac5:	48 89 ee             	mov    %rbp,%rsi
  674ac8:	48 89 da             	mov    %rbx,%rdx
  674acb:	48 8d 9c 24 10 07 00 	lea    0x710(%rsp),%rbx
  674ad2:	00 
  674ad3:	48 89 d9             	mov    %rbx,%rcx
  674ad6:	f3 0f 10 44 24 60    	movss  0x60(%rsp),%xmm0
  674adc:	e8 bf 0a ff ff       	call   6655a0 <<parley::resolve::ResolveContext>::resolve_property::<()>>
  674ae1:	48 89 df             	mov    %rbx,%rdi
  674ae4:	e8 c7 aa ff ff       	call   66f5b0 <core::ptr::drop_glue::<parley::style::StyleProperty<()>>>
  674ae9:	49 83 bf 20 05 00 00 	cmpq   $0xffffffffffffffff,0x520(%r15)
  674af0:	ff 
  674af1:	0f 84 23 27 00 00    	je     67721a <<gpui_canvas::text::planner::Planner>::shape+0x31ba>
  674af7:	4c 89 f7             	mov    %r14,%rdi
  674afa:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
  674b01:	00 
  674b02:	e8 39 10 ff ff       	call   665b40 <<parley::resolve::ResolvedStyle<()>>::apply>
  674b07:	48 8d bc 24 98 04 00 	lea    0x498(%rsp),%rdi
  674b0e:	00 
  674b0f:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  674b14:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  674b19:	48 8b 8c 24 10 01 00 	mov    0x110(%rsp),%rcx
  674b20:	00 
  674b21:	e8 4a a3 ff ff       	call   66ee70 <<parley::builder::RangedBuilder<()>>::build_into::<&str>>
  674b26:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  674b2d:	00 
  674b2e:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  674b33:	e8 98 ed 00 00       	call   6838d0 <<parley::layout::line_break::BreakLines<()>>::new>
  674b38:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  674b3f:	00 
  674b40:	f3 0f 10 84 24 cc 01 	movss  0x1cc(%rsp),%xmm0
  674b47:	00 00 
  674b49:	e8 62 de 00 00       	call   6829b0 <<parley::layout::line_break::BreakLines<()>>::break_remaining>
  674b4e:	80 bc 24 2c 02 00 00 	cmpb   $0x0,0x22c(%rsp)
  674b55:	00 
  674b56:	74 18                	je     674b70 <<gpui_canvas::text::planner::Planner>::shape+0xb10>
  674b58:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  674b5f:	00 ff 
  674b61:	0f 85 fc 01 00 00    	jne    674d63 <<gpui_canvas::text::planner::Planner>::shape+0xd03>
  674b67:	31 c0                	xor    %eax,%eax
  674b69:	e9 78 01 00 00       	jmp    674ce6 <<gpui_canvas::text::planner::Planner>::shape+0xc86>
  674b6e:	66 90                	xchg   %ax,%ax
  674b70:	48 83 7c 24 30 00    	cmpq   $0x0,0x30(%rsp)
  674b76:	48 8b 84 24 00 01 00 	mov    0x100(%rsp),%rax
  674b7d:	00 
  674b7e:	0f 85 4c 01 00 00    	jne    674cd0 <<gpui_canvas::text::planner::Planner>::shape+0xc70>
  674b84:	48 3b 44 24 50       	cmp    0x50(%rsp),%rax
  674b89:	0f 85 41 01 00 00    	jne    674cd0 <<gpui_canvas::text::planner::Planner>::shape+0xc70>
  674b8f:	48 8b 04 24          	mov    (%rsp),%rax
  674b93:	48 83 b8 e0 09 00 00 	cmpq   $0x1,0x9e0(%rax)
  674b9a:	01 
  674b9b:	0f 85 2f 01 00 00    	jne    674cd0 <<gpui_canvas::text::planner::Planner>::shape+0xc70>
  674ba1:	48 8b 14 24          	mov    (%rsp),%rdx
  674ba5:	48 8b 82 d8 09 00 00 	mov    0x9d8(%rdx),%rax
  674bac:	48 8d 48 70          	lea    0x70(%rax),%rcx
  674bb0:	48 89 8c 24 18 07 00 	mov    %rcx,0x718(%rsp)
  674bb7:	00 
  674bb8:	48 c7 84 24 20 07 00 	movq   $0x0,0x720(%rsp)
  674bbf:	00 00 00 00 00 
  674bc4:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  674bc9:	48 89 b4 24 28 07 00 	mov    %rsi,0x728(%rsp)
  674bd0:	00 
  674bd1:	48 c7 84 24 58 07 00 	movq   $0x0,0x758(%rsp)
  674bd8:	00 00 00 00 00 
  674bdd:	48 89 94 24 c0 04 00 	mov    %rdx,0x4c0(%rsp)
  674be4:	00 
  674be5:	48 89 8c 24 10 07 00 	mov    %rcx,0x710(%rsp)
  674bec:	00 
  674bed:	48 8b 78 10          	mov    0x10(%rax),%rdi
  674bf1:	48 8b 70 18          	mov    0x18(%rax),%rsi
  674bf5:	48 8b 92 f8 09 00 00 	mov    0x9f8(%rdx),%rdx
  674bfc:	48 39 fe             	cmp    %rdi,%rsi
  674bff:	0f 82 91 29 00 00    	jb     677596 <<gpui_canvas::text::planner::Planner>::shape+0x3536>
  674c05:	48 39 d6             	cmp    %rdx,%rsi
  674c08:	0f 87 88 29 00 00    	ja     677596 <<gpui_canvas::text::planner::Planner>::shape+0x3536>
  674c0e:	48 8b 04 24          	mov    (%rsp),%rax
  674c12:	48 8b 80 f0 09 00 00 	mov    0x9f0(%rax),%rax
  674c19:	48 8d 0c bf          	lea    (%rdi,%rdi,4),%rcx
  674c1d:	48 8d 0c c8          	lea    (%rax,%rcx,8),%rcx
  674c21:	48 8d 14 b6          	lea    (%rsi,%rsi,4),%rdx
  674c25:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
  674c29:	48 89 8c 24 30 07 00 	mov    %rcx,0x730(%rsp)
  674c30:	00 
  674c31:	48 89 84 24 38 07 00 	mov    %rax,0x738(%rsp)
  674c38:	00 
  674c39:	48 c7 84 24 40 07 00 	movq   $0x0,0x740(%rsp)
  674c40:	00 00 00 00 00 
  674c45:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  674c4a:	48 89 84 24 48 07 00 	mov    %rax,0x748(%rsp)
  674c51:	00 
  674c52:	c7 84 24 50 07 00 00 	movl   $0x0,0x750(%rsp)
  674c59:	00 00 00 00 
  674c5d:	48 8d bc 24 30 07 00 	lea    0x730(%rsp),%rdi
  674c64:	00 
  674c65:	48 8d 94 24 c0 04 00 	lea    0x4c0(%rsp),%rdx
  674c6c:	00 
  674c6d:	e8 5e fe 00 00       	call   684ad0 <<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}> as core::iter::traits::iterator::Iterator>::try_fold::<(), core::iter::adapters::filter_map::filter_map_try_fold<parley::layout::line::LineItem<()>, parley::layout::run::Run<()>, (), core::ops::control_flow::ControlFlow<()>, <parley::layout::line::Line<()>>::runs::{closure#0}, &mut core::iter::traits::iterator::Iterator::all::check<parley::layout::run::Run<()>, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#2}>::{closure#0}>::{closure#0}, core::ops::control_flow::ControlFlow<()>>>
  674c72:	48 c7 84 24 20 07 00 	movq   $0x1,0x720(%rsp)
  674c79:	00 01 00 00 00 
  674c7e:	84 c0                	test   %al,%al
  674c80:	75 4e                	jne    674cd0 <<gpui_canvas::text::planner::Planner>::shape+0xc70>
  674c82:	48 c7 84 24 30 07 00 	movq   $0x0,0x730(%rsp)
  674c89:	00 00 00 00 00 
  674c8e:	48 83 bc 24 58 07 00 	cmpq   $0x0,0x758(%rsp)
  674c95:	00 00 
  674c97:	0f 84 4f 1e 00 00    	je     676aec <<gpui_canvas::text::planner::Planner>::shape+0x2a8c>
  674c9d:	48 8d bc 24 58 07 00 	lea    0x758(%rsp),%rdi
  674ca4:	00 
  674ca5:	48 8d b4 24 80 07 00 	lea    0x780(%rsp),%rsi
  674cac:	00 
  674cad:	48 8d 94 24 c0 04 00 	lea    0x4c0(%rsp),%rdx
  674cb4:	00 
  674cb5:	e8 16 fe 00 00       	call   684ad0 <<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}> as core::iter::traits::iterator::Iterator>::try_fold::<(), core::iter::adapters::filter_map::filter_map_try_fold<parley::layout::line::LineItem<()>, parley::layout::run::Run<()>, (), core::ops::control_flow::ControlFlow<()>, <parley::layout::line::Line<()>>::runs::{closure#0}, &mut core::iter::traits::iterator::Iterator::all::check<parley::layout::run::Run<()>, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#2}>::{closure#0}>::{closure#0}, core::ops::control_flow::ControlFlow<()>>>
  674cba:	84 c0                	test   %al,%al
  674cbc:	0f 84 2a 1e 00 00    	je     676aec <<gpui_canvas::text::planner::Planner>::shape+0x2a8c>
  674cc2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  674cc9:	1f 84 00 00 00 00 00 
  674cd0:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  674cd7:	00 ff 
  674cd9:	0f 85 84 00 00 00    	jne    674d63 <<gpui_canvas::text::planner::Planner>::shape+0xd03>
  674cdf:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
  674ce6:	48 c7 84 24 50 01 00 	movq   $0x0,0x150(%rsp)
  674ced:	00 00 00 00 00 
  674cf2:	48 c7 84 24 58 01 00 	movq   $0x4,0x158(%rsp)
  674cf9:	00 04 00 00 00 
  674cfe:	48 8d 8c 24 58 01 00 	lea    0x158(%rsp),%rcx
  674d05:	00 
  674d06:	0f 57 c0             	xorps  %xmm0,%xmm0
  674d09:	0f 11 41 08          	movups %xmm0,0x8(%rcx)
  674d0d:	48 c7 84 24 70 01 00 	movq   $0x4,0x170(%rsp)
  674d14:	00 04 00 00 00 
  674d19:	48 c7 84 24 78 01 00 	movq   $0x0,0x178(%rsp)
  674d20:	00 00 00 00 00 
  674d25:	48 89 84 24 80 01 00 	mov    %rax,0x180(%rsp)
  674d2c:	00 
  674d2d:	48 c7 84 24 88 01 00 	movq   $0x4,0x188(%rsp)
  674d34:	00 04 00 00 00 
  674d39:	48 c7 84 24 90 01 00 	movq   $0x0,0x190(%rsp)
  674d40:	00 00 00 00 00 
  674d45:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  674d4a:	89 84 24 98 01 00 00 	mov    %eax,0x198(%rsp)
  674d51:	f3 0f 10 84 24 84 00 	movss  0x84(%rsp),%xmm0
  674d58:	00 00 
  674d5a:	f3 0f 11 84 24 9c 01 	movss  %xmm0,0x19c(%rsp)
  674d61:	00 00 
  674d63:	48 8b 04 24          	mov    (%rsp),%rax
  674d67:	4c 8b b0 e0 09 00 00 	mov    0x9e0(%rax),%r14
  674d6e:	4d 85 f6             	test   %r14,%r14
  674d71:	0f 84 09 01 00 00    	je     674e80 <<gpui_canvas::text::planner::Planner>::shape+0xe20>
  674d77:	48 8b a8 d8 09 00 00 	mov    0x9d8(%rax),%rbp
  674d7e:	45 31 ff             	xor    %r15d,%r15d
  674d81:	31 db                	xor    %ebx,%ebx
  674d83:	eb 17                	jmp    674d9c <<gpui_canvas::text::planner::Planner>::shape+0xd3c>
  674d85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  674d8c:	00 00 00 00 
  674d90:	49 ff c7             	inc    %r15
  674d93:	4d 39 f7             	cmp    %r14,%r15
  674d96:	0f 84 e6 00 00 00    	je     674e82 <<gpui_canvas::text::planner::Planner>::shape+0xe22>
  674d9c:	49 6b c7 70          	imul   $0x70,%r15,%rax
  674da0:	48 01 e8             	add    %rbp,%rax
  674da3:	48 89 9c 24 10 07 00 	mov    %rbx,0x710(%rsp)
  674daa:	00 
  674dab:	48 c7 84 24 18 07 00 	movq   $0x0,0x718(%rsp)
  674db2:	00 00 00 00 00 
  674db7:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
  674dbc:	48 89 8c 24 20 07 00 	mov    %rcx,0x720(%rsp)
  674dc3:	00 
  674dc4:	48 89 84 24 28 07 00 	mov    %rax,0x728(%rsp)
  674dcb:	00 
  674dcc:	44 89 bc 24 30 07 00 	mov    %r15d,0x730(%rsp)
  674dd3:	00 
  674dd4:	c6 84 24 d8 07 00 00 	movb   $0x2,0x7d8(%rsp)
  674ddb:	02 
  674ddc:	c7 84 24 e0 07 00 00 	movl   $0x0,0x7e0(%rsp)
  674de3:	00 00 00 00 
  674de7:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
  674dee:	00 
  674def:	48 8d b4 24 18 07 00 	lea    0x718(%rsp),%rsi
  674df6:	00 
  674df7:	e8 d4 04 01 00       	call   6852d0 <<parley::layout::line::GlyphRunIter<()> as core::iter::traits::iterator::Iterator>::next>
  674dfc:	83 bc 24 40 03 00 00 	cmpl   $0x1,0x340(%rsp)
  674e03:	01 
  674e04:	75 8a                	jne    674d90 <<gpui_canvas::text::planner::Planner>::shape+0xd30>
  674e06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  674e0d:	00 00 00 
  674e10:	49 8b 45 38          	mov    0x38(%r13),%rax
  674e14:	49 89 44 24 40       	mov    %rax,0x40(%r12)
  674e19:	41 0f 10 45 f8       	movups -0x8(%r13),%xmm0
  674e1e:	41 0f 10 4d 08       	movups 0x8(%r13),%xmm1
  674e23:	41 0f 10 55 18       	movups 0x18(%r13),%xmm2
  674e28:	41 0f 10 5d 28       	movups 0x28(%r13),%xmm3
  674e2d:	41 0f 11 5c 24 30    	movups %xmm3,0x30(%r12)
  674e33:	41 0f 11 54 24 20    	movups %xmm2,0x20(%r12)
  674e39:	41 0f 11 4c 24 10    	movups %xmm1,0x10(%r12)
  674e3f:	41 0f 11 04 24       	movups %xmm0,(%r12)
  674e44:	48 89 9c 24 c0 04 00 	mov    %rbx,0x4c0(%rsp)
  674e4b:	00 
  674e4c:	48 89 de             	mov    %rbx,%rsi
  674e4f:	4c 89 e2             	mov    %r12,%rdx
  674e52:	e8 39 00 01 00       	call   684e90 <<&mut core::iter::adapters::map::map_fold<parley::layout::line::PositionedLayoutItem<()>, usize, usize, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#5}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineData>>, <parley::layout::layout::Layout<()>>::lines::{closure#0}>, parley::layout::line::GlyphRunIter<()>, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#4}>, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#5}>>::{closure#0}>::{closure#0} as core::ops::function::FnMut<(usize, parley::layout::line::PositionedLayoutItem<()>)>>::call_mut>
  674e57:	48 89 c3             	mov    %rax,%rbx
  674e5a:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
  674e61:	00 
  674e62:	48 8d b4 24 18 07 00 	lea    0x718(%rsp),%rsi
  674e69:	00 
  674e6a:	e8 61 04 01 00       	call   6852d0 <<parley::layout::line::GlyphRunIter<()> as core::iter::traits::iterator::Iterator>::next>
  674e6f:	80 bc 24 40 03 00 00 	cmpb   $0x0,0x340(%rsp)
  674e76:	00 
  674e77:	75 97                	jne    674e10 <<gpui_canvas::text::planner::Planner>::shape+0xdb0>
  674e79:	e9 12 ff ff ff       	jmp    674d90 <<gpui_canvas::text::planner::Planner>::shape+0xd30>
  674e7e:	66 90                	xchg   %ax,%ax
  674e80:	31 db                	xor    %ebx,%ebx
  674e82:	48 8b b4 24 f8 00 00 	mov    0xf8(%rsp),%rsi
  674e89:	00 
  674e8a:	48 89 f0             	mov    %rsi,%rax
  674e8d:	48 01 d8             	add    %rbx,%rax
  674e90:	0f 92 c1             	setb   %cl
  674e93:	48 3d 01 80 00 00    	cmp    $0x8001,%rax
  674e99:	0f 93 c0             	setae  %al
  674e9c:	08 c8                	or     %cl,%al
  674e9e:	0f 85 9b 1d 00 00    	jne    676c3f <<gpui_canvas::text::planner::Planner>::shape+0x2bdf>
  674ea4:	48 8b 6c 24 30       	mov    0x30(%rsp),%rbp
  674ea9:	48 39 ac 24 00 01 00 	cmp    %rbp,0x100(%rsp)
  674eb0:	00 
  674eb1:	74 14                	je     674ec7 <<gpui_canvas::text::planner::Planner>::shape+0xe67>
  674eb3:	48 8b 84 24 e8 00 00 	mov    0xe8(%rsp),%rax
  674eba:	00 
  674ebb:	48 29 f0             	sub    %rsi,%rax
  674ebe:	48 39 c3             	cmp    %rax,%rbx
  674ec1:	0f 87 58 1d 00 00    	ja     676c1f <<gpui_canvas::text::planner::Planner>::shape+0x2bbf>
  674ec7:	48 85 ed             	test   %rbp,%rbp
  674eca:	48 8b 9c 24 00 01 00 	mov    0x100(%rsp),%rbx
  674ed1:	00 
  674ed2:	74 26                	je     674efa <<gpui_canvas::text::planner::Planner>::shape+0xe9a>
  674ed4:	0f 57 c0             	xorps  %xmm0,%xmm0
  674ed7:	f3 0f 11 84 24 d4 00 	movss  %xmm0,0xd4(%rsp)
  674ede:	00 00 
  674ee0:	48 39 eb             	cmp    %rbp,%rbx
  674ee3:	75 4b                	jne    674f30 <<gpui_canvas::text::planner::Planner>::shape+0xed0>
  674ee5:	48 8b 0c 24          	mov    (%rsp),%rcx
  674ee9:	48 8b 81 e0 09 00 00 	mov    0x9e0(%rcx),%rax
  674ef0:	48 85 c0             	test   %rax,%rax
  674ef3:	75 7c                	jne    674f71 <<gpui_canvas::text::planner::Planner>::shape+0xf11>
  674ef5:	e9 9b 14 00 00       	jmp    676395 <<gpui_canvas::text::planner::Planner>::shape+0x2335>
  674efa:	48 8b 04 24          	mov    (%rsp),%rax
  674efe:	48 83 b8 e0 09 00 00 	cmpq   $0x0,0x9e0(%rax)
  674f05:	00 
  674f06:	74 0e                	je     674f16 <<gpui_canvas::text::planner::Planner>::shape+0xeb6>
  674f08:	48 8b 80 d8 09 00 00 	mov    0x9d8(%rax),%rax
  674f0f:	f3 0f 10 40 24       	movss  0x24(%rax),%xmm0
  674f14:	eb 03                	jmp    674f19 <<gpui_canvas::text::planner::Planner>::shape+0xeb9>
  674f16:	0f 57 c0             	xorps  %xmm0,%xmm0
  674f19:	f3 0f 11 44 24 7c    	movss  %xmm0,0x7c(%rsp)
  674f1f:	0f 57 c0             	xorps  %xmm0,%xmm0
  674f22:	f3 0f 11 84 24 d4 00 	movss  %xmm0,0xd4(%rsp)
  674f29:	00 00 
  674f2b:	48 39 eb             	cmp    %rbp,%rbx
  674f2e:	74 b5                	je     674ee5 <<gpui_canvas::text::planner::Planner>::shape+0xe85>
  674f30:	83 bc 24 c8 01 00 00 	cmpl   $0x0,0x1c8(%rsp)
  674f37:	00 
  674f38:	74 0e                	je     674f48 <<gpui_canvas::text::planner::Planner>::shape+0xee8>
  674f3a:	48 8b 04 24          	mov    (%rsp),%rax
  674f3e:	f3 0f 10 80 28 0a 00 	movss  0xa28(%rax),%xmm0
  674f45:	00 
  674f46:	eb 0c                	jmp    674f54 <<gpui_canvas::text::planner::Planner>::shape+0xef4>
  674f48:	48 8b 04 24          	mov    (%rsp),%rax
  674f4c:	f3 0f 10 80 2c 0a 00 	movss  0xa2c(%rax),%xmm0
  674f53:	00 
  674f54:	f3 0f 11 84 24 d4 00 	movss  %xmm0,0xd4(%rsp)
  674f5b:	00 00 
  674f5d:	48 8b 0c 24          	mov    (%rsp),%rcx
  674f61:	48 8b 81 e0 09 00 00 	mov    0x9e0(%rcx),%rax
  674f68:	48 85 c0             	test   %rax,%rax
  674f6b:	0f 84 24 14 00 00    	je     676395 <<gpui_canvas::text::planner::Planner>::shape+0x2335>
  674f71:	48 8b 89 d8 09 00 00 	mov    0x9d8(%rcx),%rcx
  674f78:	48 6b c0 70          	imul   $0x70,%rax,%rax
  674f7c:	48 89 8c 24 c8 00 00 	mov    %rcx,0xc8(%rsp)
  674f83:	00 
  674f84:	48 01 c8             	add    %rcx,%rax
  674f87:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
  674f8e:	00 
  674f8f:	c7 44 24 78 00 00 00 	movl   $0x0,0x78(%rsp)
  674f96:	00 
  674f97:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  674f9e:	00 ff 
  674fa0:	74 2e                	je     674fd0 <<gpui_canvas::text::planner::Planner>::shape+0xf70>
  674fa2:	48 39 eb             	cmp    %rbp,%rbx
  674fa5:	75 3c                	jne    674fe3 <<gpui_canvas::text::planner::Planner>::shape+0xf83>
  674fa7:	45 31 f6             	xor    %r14d,%r14d
  674faa:	45 31 ff             	xor    %r15d,%r15d
  674fad:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  674fb4:	00 
  674fb5:	48 8b 8c 24 78 01 00 	mov    0x178(%rsp),%rcx
  674fbc:	00 
  674fbd:	48 89 8c 24 58 02 00 	mov    %rcx,0x258(%rsp)
  674fc4:	00 
  674fc5:	80 78 68 02          	cmpb   $0x2,0x68(%rax)
  674fc9:	74 41                	je     67500c <<gpui_canvas::text::planner::Planner>::shape+0xfac>
  674fcb:	e9 da 01 00 00       	jmp    6751aa <<gpui_canvas::text::planner::Planner>::shape+0x114a>
  674fd0:	8b 4c 24 78          	mov    0x78(%rsp),%ecx
  674fd4:	89 c8                	mov    %ecx,%eax
  674fd6:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
  674fdd:	00 
  674fde:	e9 cd 03 00 00       	jmp    6753b0 <<gpui_canvas::text::planner::Planner>::shape+0x1350>
  674fe3:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  674fea:	00 
  674feb:	4c 8b 38             	mov    (%rax),%r15
  674fee:	4c 8b 70 08          	mov    0x8(%rax),%r14
  674ff2:	48 8b 8c 24 78 01 00 	mov    0x178(%rsp),%rcx
  674ff9:	00 
  674ffa:	48 89 8c 24 58 02 00 	mov    %rcx,0x258(%rsp)
  675001:	00 
  675002:	80 78 68 02          	cmpb   $0x2,0x68(%rax)
  675006:	0f 85 9e 01 00 00    	jne    6751aa <<gpui_canvas::text::planner::Planner>::shape+0x114a>
  67500c:	48 8b 78 10          	mov    0x10(%rax),%rdi
  675010:	48 8b 70 18          	mov    0x18(%rax),%rsi
  675014:	48 8b 04 24          	mov    (%rsp),%rax
  675018:	48 8b 90 f8 09 00 00 	mov    0x9f8(%rax),%rdx
  67501f:	48 39 fe             	cmp    %rdi,%rsi
  675022:	0f 82 80 25 00 00    	jb     6775a8 <<gpui_canvas::text::planner::Planner>::shape+0x3548>
  675028:	48 39 d6             	cmp    %rdx,%rsi
  67502b:	0f 87 77 25 00 00    	ja     6775a8 <<gpui_canvas::text::planner::Planner>::shape+0x3548>
  675031:	48 8b 04 24          	mov    (%rsp),%rax
  675035:	48 8b 80 f0 09 00 00 	mov    0x9f0(%rax),%rax
  67503c:	48 8d 0c bf          	lea    (%rdi,%rdi,4),%rcx
  675040:	48 8d 0c c8          	lea    (%rax,%rcx,8),%rcx
  675044:	48 8d 14 b6          	lea    (%rsi,%rsi,4),%rdx
  675048:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
  67504c:	48 89 8c 24 c0 04 00 	mov    %rcx,0x4c0(%rsp)
  675053:	00 
  675054:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
  67505b:	00 
  67505c:	48 c7 84 24 d0 04 00 	movq   $0x0,0x4d0(%rsp)
  675063:	00 00 00 00 00 
  675068:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  67506d:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
  675074:	00 
  675075:	8b 44 24 78          	mov    0x78(%rsp),%eax
  675079:	89 84 24 e0 04 00 00 	mov    %eax,0x4e0(%rsp)
  675080:	c6 84 24 00 07 00 00 	movb   $0x2,0x700(%rsp)
  675087:	02 
  675088:	48 8d 84 24 08 07 00 	lea    0x708(%rsp),%rax
  67508f:	00 
  675090:	48 89 84 24 40 03 00 	mov    %rax,0x340(%rsp)
  675097:	00 
  675098:	c6 84 24 f0 05 00 00 	movb   $0x2,0x5f0(%rsp)
  67509f:	02 
  6750a0:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  6750a7:	00 
  6750a8:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
  6750af:	00 
  6750b0:	48 8d 94 24 40 03 00 	lea    0x340(%rsp),%rdx
  6750b7:	00 
  6750b8:	48 8d 8c 24 e8 04 00 	lea    0x4e8(%rsp),%rcx
  6750bf:	00 
  6750c0:	e8 4b f3 00 00       	call   684410 <<core::iter::adapters::map::Map<core::iter::adapters::filter_map::FilterMap<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}>, <parley::layout::line::Line<()>>::runs::{closure#0}>, gpui_canvas::text::planner::freeze_line::{closure#0}> as core::iter::traits::iterator::Iterator>::try_fold::<(), <core::iter::adapters::flatten::FlattenCompat<_, _>>::iter_try_fold::flatten<parley::layout::run::Clusters<()>, (), core::ops::control_flow::ControlFlow<parley::layout::cluster::Cluster<()>>, <core::iter::adapters::flatten::FlattenCompat<_, _> as core::iter::traits::iterator::Iterator>::try_fold::flatten<parley::layout::run::Clusters<()>, (), core::ops::control_flow::ControlFlow<parley::layout::cluster::Cluster<()>>, core::iter::traits::iterator::Iterator::find::check<parley::layout::cluster::Cluster<()>, &mut gpui_canvas::text::planner::freeze_line::{closure#1}>::{closure#0}>::{closure#0}>::{closure#0}, core::ops::control_flow::ControlFlow<parley::layout::cluster::Cluster<()>>>>
  6750c5:	48 8b 8c 24 10 07 00 	mov    0x710(%rsp),%rcx
  6750cc:	00 
  6750cd:	48 85 c9             	test   %rcx,%rcx
  6750d0:	0f 84 ba 00 00 00    	je     675190 <<gpui_canvas::text::planner::Planner>::shape+0x1130>
  6750d6:	8b bc 24 38 07 00 00 	mov    0x738(%rsp),%edi
  6750dd:	8b b4 24 90 07 00 00 	mov    0x790(%rsp),%esi
  6750e4:	8b 94 24 94 07 00 00 	mov    0x794(%rsp),%edx
  6750eb:	48 8b 41 58          	mov    0x58(%rcx),%rax
  6750ef:	48 39 f8             	cmp    %rdi,%rax
  6750f2:	0f 86 d3 25 00 00    	jbe    6776cb <<gpui_canvas::text::planner::Planner>::shape+0x366b>
  6750f8:	48 8b 41 50          	mov    0x50(%rcx),%rax
  6750fc:	48 8d 3c ff          	lea    (%rdi,%rdi,8),%rdi
  675100:	48 c1 e7 04          	shl    $0x4,%rdi
  675104:	0f 10 41 68          	movups 0x68(%rcx),%xmm0
  675108:	0f 10 89 80 00 00 00 	movups 0x80(%rcx),%xmm1
  67510f:	0f 10 91 98 00 00 00 	movups 0x98(%rcx),%xmm2
  675116:	0f 11 84 24 10 07 00 	movups %xmm0,0x710(%rsp)
  67511d:	00 
  67511e:	0f 11 8c 24 20 07 00 	movups %xmm1,0x720(%rsp)
  675125:	00 
  675126:	0f 11 94 24 30 07 00 	movups %xmm2,0x730(%rsp)
  67512d:	00 
  67512e:	48 8b 44 38 50       	mov    0x50(%rax,%rdi,1),%rax
  675133:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
  67513a:	00 
  67513b:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  675142:	00 
  675143:	ff 15 ef 51 11 00    	call   *0x1151ef(%rip)        # 78a338 <_DYNAMIC+0x5b8>
  675149:	48 89 c3             	mov    %rax,%rbx
  67514c:	ba 48 02 00 00       	mov    $0x248,%edx
  675151:	4c 89 7c 24 60       	mov    %r15,0x60(%rsp)
  675156:	4c 8d bc 24 10 07 00 	lea    0x710(%rsp),%r15
  67515d:	00 
  67515e:	4c 89 ff             	mov    %r15,%rdi
  675161:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
  675168:	00 
  675169:	ff 15 e1 4e 11 00    	call   *0x114ee1(%rip)        # 78a050 <memcpy@GLIBC_2.14>
  67516f:	4c 89 ff             	mov    %r15,%rdi
  675172:	4c 8b 7c 24 60       	mov    0x60(%rsp),%r15
  675177:	48 89 de             	mov    %rbx,%rsi
  67517a:	e8 c1 f4 00 00       	call   684640 <<core::iter::adapters::map::Map<core::iter::adapters::filter::Filter<core::iter::adapters::flatten::FlatMap<core::iter::adapters::filter_map::FilterMap<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}>, <parley::layout::line::Line<()>>::runs::{closure#0}>, parley::layout::run::Clusters<()>, gpui_canvas::text::planner::freeze_line::{closure#0}>, gpui_canvas::text::planner::freeze_line::{closure#1}>, gpui_canvas::text::planner::freeze_line::{closure#2}> as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::traits::iterator::Iterator::min_by::fold<usize, <usize as core::cmp::Ord>::cmp>::{closure#0}>>
  67517f:	4c 39 f0             	cmp    %r14,%rax
  675182:	4c 0f 42 f0          	cmovb  %rax,%r14
  675186:	48 8b 9c 24 00 01 00 	mov    0x100(%rsp),%rbx
  67518d:	00 
  67518e:	eb 1a                	jmp    6751aa <<gpui_canvas::text::planner::Planner>::shape+0x114a>
  675190:	80 bc 24 00 07 00 00 	cmpb   $0x2,0x700(%rsp)
  675197:	02 
  675198:	c6 84 24 f0 05 00 00 	movb   $0x2,0x5f0(%rsp)
  67519f:	02 
  6751a0:	48 8b 9c 24 00 01 00 	mov    0x100(%rsp),%rbx
  6751a7:	00 
  6751a8:	75 36                	jne    6751e0 <<gpui_canvas::text::planner::Planner>::shape+0x1180>
  6751aa:	4d 39 f7             	cmp    %r14,%r15
  6751ad:	0f 87 67 1e 00 00    	ja     67701a <<gpui_canvas::text::planner::Planner>::shape+0x2fba>
  6751b3:	4d 85 ff             	test   %r15,%r15
  6751b6:	0f 84 a0 00 00 00    	je     67525c <<gpui_canvas::text::planner::Planner>::shape+0x11fc>
  6751bc:	4c 3b bc 24 10 01 00 	cmp    0x110(%rsp),%r15
  6751c3:	00 
  6751c4:	0f 83 8c 00 00 00    	jae    675256 <<gpui_canvas::text::planner::Planner>::shape+0x11f6>
  6751ca:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6751cf:	42 80 3c 38 bf       	cmpb   $0xbf,(%rax,%r15,1)
  6751d4:	0f 8f 82 00 00 00    	jg     67525c <<gpui_canvas::text::planner::Planner>::shape+0x11fc>
  6751da:	e9 3b 1e 00 00       	jmp    67701a <<gpui_canvas::text::planner::Planner>::shape+0x2fba>
  6751df:	90                   	nop
  6751e0:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  6751e7:	00 
  6751e8:	48 8d b4 24 f8 05 00 	lea    0x5f8(%rsp),%rsi
  6751ef:	00 
  6751f0:	e8 cb e9 00 00       	call   683bc0 <<parley::layout::run::Clusters<()> as core::iter::traits::iterator::Iterator>::next>
  6751f5:	48 8b 8c 24 10 07 00 	mov    0x710(%rsp),%rcx
  6751fc:	00 
  6751fd:	48 85 c9             	test   %rcx,%rcx
  675200:	74 a8                	je     6751aa <<gpui_canvas::text::planner::Planner>::shape+0x114a>
  675202:	8b bc 24 38 07 00 00 	mov    0x738(%rsp),%edi
  675209:	48 8b 41 58          	mov    0x58(%rcx),%rax
  67520d:	48 39 f8             	cmp    %rdi,%rax
  675210:	0f 86 32 24 00 00    	jbe    677648 <<gpui_canvas::text::planner::Planner>::shape+0x35e8>
  675216:	8b b4 24 90 07 00 00 	mov    0x790(%rsp),%esi
  67521d:	8b 94 24 94 07 00 00 	mov    0x794(%rsp),%edx
  675224:	4c 8b 41 70          	mov    0x70(%rcx),%r8
  675228:	39 f2                	cmp    %esi,%edx
  67522a:	0f 82 fb 22 00 00    	jb     67752b <<gpui_canvas::text::planner::Planner>::shape+0x34cb>
  675230:	49 39 d0             	cmp    %rdx,%r8
  675233:	0f 82 f2 22 00 00    	jb     67752b <<gpui_canvas::text::planner::Planner>::shape+0x34cb>
  675239:	39 f2                	cmp    %esi,%edx
  67523b:	0f 84 18 24 00 00    	je     677659 <<gpui_canvas::text::planner::Planner>::shape+0x35f9>
  675241:	4c 8b 41 68          	mov    0x68(%rcx),%r8
  675245:	4c 8d 0c 76          	lea    (%rsi,%rsi,2),%r9
  675249:	43 80 7c 88 07 06    	cmpb   $0x6,0x7(%r8,%r9,4)
  67524f:	75 8f                	jne    6751e0 <<gpui_canvas::text::planner::Planner>::shape+0x1180>
  675251:	e9 99 fe ff ff       	jmp    6750ef <<gpui_canvas::text::planner::Planner>::shape+0x108f>
  675256:	0f 85 be 1d 00 00    	jne    67701a <<gpui_canvas::text::planner::Planner>::shape+0x2fba>
  67525c:	4d 85 f6             	test   %r14,%r14
  67525f:	74 21                	je     675282 <<gpui_canvas::text::planner::Planner>::shape+0x1222>
  675261:	4c 3b b4 24 10 01 00 	cmp    0x110(%rsp),%r14
  675268:	00 
  675269:	73 11                	jae    67527c <<gpui_canvas::text::planner::Planner>::shape+0x121c>
  67526b:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  675270:	42 80 3c 30 c0       	cmpb   $0xc0,(%rax,%r14,1)
  675275:	7d 0b                	jge    675282 <<gpui_canvas::text::planner::Planner>::shape+0x1222>
  675277:	e9 9e 1d 00 00       	jmp    67701a <<gpui_canvas::text::planner::Planner>::shape+0x2fba>
  67527c:	0f 85 98 1d 00 00    	jne    67701a <<gpui_canvas::text::planner::Planner>::shape+0x2fba>
  675282:	0f 57 c0             	xorps  %xmm0,%xmm0
  675285:	48 39 eb             	cmp    %rbp,%rbx
  675288:	74 0d                	je     675297 <<gpui_canvas::text::planner::Planner>::shape+0x1237>
  67528a:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  675291:	00 
  675292:	f3 0f 10 40 30       	movss  0x30(%rax),%xmm0
  675297:	f3 0f 11 44 24 60    	movss  %xmm0,0x60(%rsp)
  67529d:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  6752a4:	00 
  6752a5:	f3 0f 10 48 40       	movss  0x40(%rax),%xmm1
  6752aa:	f3 0f 10 40 44       	movss  0x44(%rax),%xmm0
  6752af:	0f 29 8c 24 90 02 00 	movaps %xmm1,0x290(%rsp)
  6752b6:	00 
  6752b7:	f3 0f 5d 48 48       	minss  0x48(%rax),%xmm1
  6752bc:	0f 29 8c 24 a0 01 00 	movaps %xmm1,0x1a0(%rsp)
  6752c3:	00 
  6752c4:	0f 29 84 24 d0 01 00 	movaps %xmm0,0x1d0(%rsp)
  6752cb:	00 
  6752cc:	f3 0f 5f 40 4c       	maxss  0x4c(%rax),%xmm0
  6752d1:	0f 29 84 24 20 01 00 	movaps %xmm0,0x120(%rsp)
  6752d8:	00 
  6752d9:	f3 0f 10 40 24       	movss  0x24(%rax),%xmm0
  6752de:	f3 0f 58 44 24 1c    	addss  0x1c(%rsp),%xmm0
  6752e4:	f3 0f 11 44 24 08    	movss  %xmm0,0x8(%rsp)
  6752ea:	48 8b 9c 24 78 01 00 	mov    0x178(%rsp),%rbx
  6752f1:	00 
  6752f2:	48 3b 9c 24 68 01 00 	cmp    0x168(%rsp),%rbx
  6752f9:	00 
  6752fa:	75 0e                	jne    67530a <<gpui_canvas::text::planner::Planner>::shape+0x12aa>
  6752fc:	48 8d bc 24 68 01 00 	lea    0x168(%rsp),%rdi
  675303:	00 
  675304:	ff 15 86 4f 11 00    	call   *0x114f86(%rip)        # 78a290 <_DYNAMIC+0x510>
  67530a:	41 01 ef             	add    %ebp,%r15d
  67530d:	41 01 ee             	add    %ebp,%r14d
  675310:	0f 28 94 24 a0 01 00 	movaps 0x1a0(%rsp),%xmm2
  675317:	00 
  675318:	0f 28 c2             	movaps %xmm2,%xmm0
  67531b:	f3 0f c2 c2 03       	cmpunordss %xmm2,%xmm0
  675320:	0f 28 c8             	movaps %xmm0,%xmm1
  675323:	0f 55 ca             	andnps %xmm2,%xmm1
  675326:	0f 54 84 24 90 02 00 	andps  0x290(%rsp),%xmm0
  67532d:	00 
  67532e:	0f 56 c1             	orps   %xmm1,%xmm0
  675331:	f3 0f 10 4c 24 1c    	movss  0x1c(%rsp),%xmm1
  675337:	f3 0f 58 c8          	addss  %xmm0,%xmm1
  67533b:	0f 28 a4 24 20 01 00 	movaps 0x120(%rsp),%xmm4
  675342:	00 
  675343:	0f 28 d4             	movaps %xmm4,%xmm2
  675346:	f3 0f c2 d4 03       	cmpunordss %xmm4,%xmm2
  67534b:	0f 28 da             	movaps %xmm2,%xmm3
  67534e:	0f 55 dc             	andnps %xmm4,%xmm3
  675351:	0f 54 94 24 d0 01 00 	andps  0x1d0(%rsp),%xmm2
  675358:	00 
  675359:	0f 56 d3             	orps   %xmm3,%xmm2
  67535c:	f3 0f 5c d0          	subss  %xmm0,%xmm2
  675360:	48 8b 84 24 70 01 00 	mov    0x170(%rsp),%rax
  675367:	00 
  675368:	48 8d 0c 5b          	lea    (%rbx,%rbx,2),%rcx
  67536c:	44 89 3c c8          	mov    %r15d,(%rax,%rcx,8)
  675370:	44 89 74 c8 04       	mov    %r14d,0x4(%rax,%rcx,8)
  675375:	f3 0f 11 4c c8 08    	movss  %xmm1,0x8(%rax,%rcx,8)
  67537b:	f3 0f 11 54 c8 0c    	movss  %xmm2,0xc(%rax,%rcx,8)
  675381:	f3 0f 10 44 24 08    	movss  0x8(%rsp),%xmm0
  675387:	f3 0f 11 44 c8 10    	movss  %xmm0,0x10(%rax,%rcx,8)
  67538d:	f3 0f 10 44 24 60    	movss  0x60(%rsp),%xmm0
  675393:	f3 0f 11 44 c8 14    	movss  %xmm0,0x14(%rax,%rcx,8)
  675399:	48 ff c3             	inc    %rbx
  67539c:	48 89 9c 24 78 01 00 	mov    %rbx,0x178(%rsp)
  6753a3:	00 
  6753a4:	44 89 b4 24 18 02 00 	mov    %r14d,0x218(%rsp)
  6753ab:	00 
  6753ac:	8b 4c 24 78          	mov    0x78(%rsp),%ecx
  6753b0:	48 c7 84 24 10 07 00 	movq   $0x0,0x710(%rsp)
  6753b7:	00 00 00 00 00 
  6753bc:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  6753c1:	48 89 84 24 18 07 00 	mov    %rax,0x718(%rsp)
  6753c8:	00 
  6753c9:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  6753d0:	00 
  6753d1:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
  6753d8:	00 
  6753d9:	48 83 c0 70          	add    $0x70,%rax
  6753dd:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
  6753e4:	00 
  6753e5:	89 8c 24 28 07 00 00 	mov    %ecx,0x728(%rsp)
  6753ec:	ff c1                	inc    %ecx
  6753ee:	89 4c 24 78          	mov    %ecx,0x78(%rsp)
  6753f2:	c6 84 24 d0 07 00 00 	movb   $0x2,0x7d0(%rsp)
  6753f9:	02 
  6753fa:	c7 84 24 d8 07 00 00 	movl   $0x0,0x7d8(%rsp)
  675401:	00 00 00 00 
  675405:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
  67540c:	00 
  67540d:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
  675414:	00 
  675415:	e8 b6 fe 00 00       	call   6852d0 <<parley::layout::line::GlyphRunIter<()> as core::iter::traits::iterator::Iterator>::next>
  67541a:	83 bc 24 40 03 00 00 	cmpl   $0x1,0x340(%rsp)
  675421:	01 
  675422:	0f 85 4a 0f 00 00    	jne    676372 <<gpui_canvas::text::planner::Planner>::shape+0x2312>
  675428:	48 8b 84 24 48 03 00 	mov    0x348(%rsp),%rax
  67542f:	00 
  675430:	48 85 c0             	test   %rax,%rax
  675433:	0f 84 d1 1b 00 00    	je     67700a <<gpui_canvas::text::planner::Planner>::shape+0x2faa>
  675439:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
  675440:	00 
  675441:	41 0f 10 45 00       	movups 0x0(%r13),%xmm0
  675446:	41 0f 10 4d 10       	movups 0x10(%r13),%xmm1
  67544b:	41 0f 10 55 20       	movups 0x20(%r13),%xmm2
  675450:	41 0f 10 5d 30       	movups 0x30(%r13),%xmm3
  675455:	48 8d 8c 24 a0 03 00 	lea    0x3a0(%rsp),%rcx
  67545c:	00 
  67545d:	0f 11 59 30          	movups %xmm3,0x30(%rcx)
  675461:	0f 11 51 20          	movups %xmm2,0x20(%rcx)
  675465:	0f 11 49 10          	movups %xmm1,0x10(%rcx)
  675469:	0f 11 01             	movups %xmm0,(%rcx)
  67546c:	4c 8b 9c 24 a0 03 00 	mov    0x3a0(%rsp),%r11
  675473:	00 
  675474:	49 8b 4b 30          	mov    0x30(%r11),%rcx
  675478:	49 8b 73 38          	mov    0x38(%r11),%rsi
  67547c:	48 89 f2             	mov    %rsi,%rdx
  67547f:	48 29 ca             	sub    %rcx,%rdx
  675482:	40 0f 92 c7          	setb   %dil
  675486:	48 3b b0 d0 00 00 00 	cmp    0xd0(%rax),%rsi
  67548d:	40 0f 97 c6          	seta   %sil
  675491:	48 01 c9             	add    %rcx,%rcx
  675494:	48 03 88 c8 00 00 00 	add    0xc8(%rax),%rcx
  67549b:	40 08 fe             	or     %dil,%sil
  67549e:	40 84 f6             	test   %sil,%sil
  6754a1:	be 00 00 00 00       	mov    $0x0,%esi
  6754a6:	48 0f 45 d6          	cmovne %rsi,%rdx
  6754aa:	be 02 00 00 00       	mov    $0x2,%esi
  6754af:	48 0f 45 ce          	cmovne %rsi,%rcx
  6754b3:	48 01 d2             	add    %rdx,%rdx
  6754b6:	31 f6                	xor    %esi,%esi
  6754b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  6754bf:	00 
  6754c0:	48 39 f2             	cmp    %rsi,%rdx
  6754c3:	74 10                	je     6754d5 <<gpui_canvas::text::planner::Planner>::shape+0x1475>
  6754c5:	66 83 3c 31 00       	cmpw   $0x0,(%rcx,%rsi,1)
  6754ca:	48 8d 76 02          	lea    0x2(%rsi),%rsi
  6754ce:	74 f0                	je     6754c0 <<gpui_canvas::text::planner::Planner>::shape+0x1460>
  6754d0:	e9 77 17 00 00       	jmp    676c4c <<gpui_canvas::text::planner::Planner>::shape+0x2bec>
  6754d5:	49 8b 4b 40          	mov    0x40(%r11),%rcx
  6754d9:	48 3b 88 b8 00 00 00 	cmp    0xb8(%rax),%rcx
  6754e0:	0f 83 d4 20 00 00    	jae    6775ba <<gpui_canvas::text::planner::Planner>::shape+0x355a>
  6754e6:	48 c1 e1 06          	shl    $0x6,%rcx
  6754ea:	48 03 88 b0 00 00 00 	add    0xb0(%rax),%rcx
  6754f1:	48 8b 34 24          	mov    (%rsp),%rsi
  6754f5:	83 3e 01             	cmpl   $0x1,(%rsi)
  6754f8:	75 0f                	jne    675509 <<gpui_canvas::text::planner::Planner>::shape+0x14a9>
  6754fa:	48 8b 56 08          	mov    0x8(%rsi),%rdx
  6754fe:	48 3b 51 10          	cmp    0x10(%rcx),%rdx
  675502:	75 05                	jne    675509 <<gpui_canvas::text::planner::Planner>::shape+0x14a9>
  675504:	45 31 c0             	xor    %r8d,%r8d
  675507:	eb 4c                	jmp    675555 <<gpui_canvas::text::planner::Planner>::shape+0x14f5>
  675509:	83 7e 10 01          	cmpl   $0x1,0x10(%rsi)
  67550d:	75 10                	jne    67551f <<gpui_canvas::text::planner::Planner>::shape+0x14bf>
  67550f:	48 8b 56 18          	mov    0x18(%rsi),%rdx
  675513:	41 b8 01 00 00 00    	mov    $0x1,%r8d
  675519:	48 3b 51 10          	cmp    0x10(%rcx),%rdx
  67551d:	74 1e                	je     67553d <<gpui_canvas::text::planner::Planner>::shape+0x14dd>
  67551f:	83 7e 20 01          	cmpl   $0x1,0x20(%rsi)
  675523:	0f 85 0f 1b 00 00    	jne    677038 <<gpui_canvas::text::planner::Planner>::shape+0x2fd8>
  675529:	48 8b 56 28          	mov    0x28(%rsi),%rdx
  67552d:	41 b8 02 00 00 00    	mov    $0x2,%r8d
  675533:	48 3b 51 10          	cmp    0x10(%rcx),%rdx
  675537:	0f 85 fb 1a 00 00    	jne    677038 <<gpui_canvas::text::planner::Planner>::shape+0x2fd8>
  67553d:	41 8d 48 ff          	lea    -0x1(%r8),%ecx
  675541:	48 8b 94 24 08 02 00 	mov    0x208(%rsp),%rdx
  675548:	00 
  675549:	48 0f ab ca          	bts    %rcx,%rdx
  67554d:	48 89 94 24 08 02 00 	mov    %rdx,0x208(%rsp)
  675554:	00 
  675555:	8b bc 24 c0 03 00 00 	mov    0x3c0(%rsp),%edi
  67555c:	48 8b 70 58          	mov    0x58(%rax),%rsi
  675560:	48 39 fe             	cmp    %rdi,%rsi
  675563:	0f 86 17 21 00 00    	jbe    677680 <<gpui_canvas::text::planner::Planner>::shape+0x3620>
  675569:	48 8b 94 24 b0 03 00 	mov    0x3b0(%rsp),%rdx
  675570:	00 
  675571:	48 85 d2             	test   %rdx,%rdx
  675574:	4c 89 84 24 60 02 00 	mov    %r8,0x260(%rsp)
  67557b:	00 
  67557c:	48 89 94 24 e8 02 00 	mov    %rdx,0x2e8(%rsp)
  675583:	00 
  675584:	74 0a                	je     675590 <<gpui_canvas::text::planner::Planner>::shape+0x1530>
  675586:	48 8d 4a 18          	lea    0x18(%rdx),%rcx
  67558a:	48 83 c2 1c          	add    $0x1c,%rdx
  67558e:	eb 1b                	jmp    6755ab <<gpui_canvas::text::planner::Planner>::shape+0x154b>
  675590:	48 8b 48 50          	mov    0x50(%rax),%rcx
  675594:	48 8d 34 ff          	lea    (%rdi,%rdi,8),%rsi
  675598:	48 c1 e6 04          	shl    $0x4,%rsi
  67559c:	48 8d 14 31          	lea    (%rcx,%rsi,1),%rdx
  6755a0:	48 83 c2 54          	add    $0x54,%rdx
  6755a4:	48 01 f1             	add    %rsi,%rcx
  6755a7:	48 83 c1 50          	add    $0x50,%rcx
  6755ab:	48 8b b4 24 f8 00 00 	mov    0xf8(%rsp),%rsi
  6755b2:	00 
  6755b3:	48 89 b4 24 f0 02 00 	mov    %rsi,0x2f0(%rsp)
  6755ba:	00 
  6755bb:	48 8b 70 68          	mov    0x68(%rax),%rsi
  6755bf:	48 8b 78 70          	mov    0x70(%rax),%rdi
  6755c3:	4c 8b 80 80 00 00 00 	mov    0x80(%rax),%r8
  6755ca:	4c 8b 88 88 00 00 00 	mov    0x88(%rax),%r9
  6755d1:	4c 8b 90 98 00 00 00 	mov    0x98(%rax),%r10
  6755d8:	48 8b 80 a0 00 00 00 	mov    0xa0(%rax),%rax
  6755df:	8b 12                	mov    (%rdx),%edx
  6755e1:	8b 09                	mov    (%rcx),%ecx
  6755e3:	4c 89 9c 24 48 02 00 	mov    %r11,0x248(%rsp)
  6755ea:	00 
  6755eb:	45 0f b6 9b 8c 00 00 	movzbl 0x8c(%r11),%r11d
  6755f2:	00 
  6755f3:	41 80 e3 01          	and    $0x1,%r11b
  6755f7:	89 d3                	mov    %edx,%ebx
  6755f9:	29 cb                	sub    %ecx,%ebx
  6755fb:	48 c7 84 24 c0 04 00 	movq   $0x0,0x4c0(%rsp)
  675602:	00 00 00 00 00 
  675607:	48 c7 84 24 e0 04 00 	movq   $0x0,0x4e0(%rsp)
  67560e:	00 00 00 00 00 
  675613:	c7 84 24 00 05 00 00 	movl   $0x0,0x500(%rsp)
  67561a:	00 00 00 00 
  67561e:	89 9c 24 04 05 00 00 	mov    %ebx,0x504(%rsp)
  675625:	48 89 b4 24 08 05 00 	mov    %rsi,0x508(%rsp)
  67562c:	00 
  67562d:	48 89 bc 24 10 05 00 	mov    %rdi,0x510(%rsp)
  675634:	00 
  675635:	4c 89 84 24 18 05 00 	mov    %r8,0x518(%rsp)
  67563c:	00 
  67563d:	4c 89 8c 24 20 05 00 	mov    %r9,0x520(%rsp)
  675644:	00 
  675645:	4c 89 94 24 28 05 00 	mov    %r10,0x528(%rsp)
  67564c:	00 
  67564d:	48 89 84 24 30 05 00 	mov    %rax,0x530(%rsp)
  675654:	00 
  675655:	89 8c 24 38 05 00 00 	mov    %ecx,0x538(%rsp)
  67565c:	89 94 24 3c 05 00 00 	mov    %edx,0x53c(%rsp)
  675663:	89 8c 24 40 05 00 00 	mov    %ecx,0x540(%rsp)
  67566a:	89 94 24 44 05 00 00 	mov    %edx,0x544(%rsp)
  675671:	44 88 9c 24 48 05 00 	mov    %r11b,0x548(%rsp)
  675678:	00 
  675679:	f2 0f 10 84 24 d0 03 	movsd  0x3d0(%rsp),%xmm0
  675680:	00 00 
  675682:	0f 29 84 24 e0 03 00 	movaps %xmm0,0x3e0(%rsp)
  675689:	00 
  67568a:	8b 94 24 c8 03 00 00 	mov    0x3c8(%rsp),%edx
  675691:	8b 8c 24 cc 03 00 00 	mov    0x3cc(%rsp),%ecx
  675698:	48 8d bc 24 f8 03 00 	lea    0x3f8(%rsp),%rdi
  67569f:	00 
  6756a0:	48 8d b4 24 98 03 00 	lea    0x398(%rsp),%rsi
  6756a7:	00 
  6756a8:	e8 43 bb 00 00       	call   6811f0 <<parley::layout::run::Run<()>>::glyphs_in>
  6756ad:	0f 28 94 24 e0 03 00 	movaps 0x3e0(%rsp),%xmm2
  6756b4:	00 
  6756b5:	0f 13 94 24 90 04 00 	movlps %xmm2,0x490(%rsp)
  6756bc:	00 
  6756bd:	48 8b 9c 24 f8 03 00 	mov    0x3f8(%rsp),%rbx
  6756c4:	00 
  6756c5:	48 8b 84 24 00 04 00 	mov    0x400(%rsp),%rax
  6756cc:	00 
  6756cd:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  6756d4:	00 
  6756d5:	0f b6 84 24 08 04 00 	movzbl 0x408(%rsp),%eax
  6756dc:	00 
  6756dd:	8b 8c 24 0c 04 00 00 	mov    0x40c(%rsp),%ecx
  6756e4:	89 8c 24 bc 01 00 00 	mov    %ecx,0x1bc(%rsp)
  6756eb:	f2 0f 10 84 24 10 04 	movsd  0x410(%rsp),%xmm0
  6756f2:	00 00 
  6756f4:	0f 29 84 24 30 02 00 	movaps %xmm0,0x230(%rsp)
  6756fb:	00 
  6756fc:	f3 0f 10 84 24 18 04 	movss  0x418(%rsp),%xmm0
  675703:	00 00 
  675705:	f3 0f 11 84 24 b8 01 	movss  %xmm0,0x1b8(%rsp)
  67570c:	00 00 
  67570e:	48 8b 8c 24 20 04 00 	mov    0x420(%rsp),%rcx
  675715:	00 
  675716:	48 89 8c 24 68 02 00 	mov    %rcx,0x268(%rsp)
  67571d:	00 
  67571e:	48 8b 8c 24 28 04 00 	mov    0x428(%rsp),%rcx
  675725:	00 
  675726:	48 89 8c 24 00 02 00 	mov    %rcx,0x200(%rsp)
  67572d:	00 
  67572e:	48 8b 94 24 30 04 00 	mov    0x430(%rsp),%rdx
  675735:	00 
  675736:	4c 8b b4 24 38 04 00 	mov    0x438(%rsp),%r14
  67573d:	00 
  67573e:	48 8b 8c 24 40 04 00 	mov    0x440(%rsp),%rcx
  675745:	00 
  675746:	48 89 8c 24 78 02 00 	mov    %rcx,0x278(%rsp)
  67574d:	00 
  67574e:	48 8b 8c 24 48 04 00 	mov    0x448(%rsp),%rcx
  675755:	00 
  675756:	48 89 8c 24 40 01 00 	mov    %rcx,0x140(%rsp)
  67575d:	00 
  67575e:	8b 8c 24 50 04 00 00 	mov    0x450(%rsp),%ecx
  675765:	48 89 8c 24 f0 01 00 	mov    %rcx,0x1f0(%rsp)
  67576c:	00 
  67576d:	8b 8c 24 54 04 00 00 	mov    0x454(%rsp),%ecx
  675774:	48 89 8c 24 f8 01 00 	mov    %rcx,0x1f8(%rsp)
  67577b:	00 
  67577c:	8b 8c 24 58 04 00 00 	mov    0x458(%rsp),%ecx
  675783:	48 89 8c 24 20 01 00 	mov    %rcx,0x120(%rsp)
  67578a:	00 
  67578b:	44 8b bc 24 5c 04 00 	mov    0x45c(%rsp),%r15d
  675792:	00 
  675793:	f3 0f 10 84 24 60 04 	movss  0x460(%rsp),%xmm0
  67579a:	00 00 
  67579c:	f3 0f 11 84 24 c0 01 	movss  %xmm0,0x1c0(%rsp)
  6757a3:	00 00 
  6757a5:	f3 0f 10 84 24 64 04 	movss  0x464(%rsp),%xmm0
  6757ac:	00 00 
  6757ae:	f3 0f 11 44 24 58    	movss  %xmm0,0x58(%rsp)
  6757b4:	48 8b 8c 24 68 04 00 	mov    0x468(%rsp),%rcx
  6757bb:	00 
  6757bc:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
  6757c1:	f3 0f 10 84 24 80 04 	movss  0x480(%rsp),%xmm0
  6757c8:	00 00 
  6757ca:	f3 0f 10 8c 24 7c 04 	movss  0x47c(%rsp),%xmm1
  6757d1:	00 00 
  6757d3:	f3 0f 11 84 24 28 02 	movss  %xmm0,0x228(%rsp)
  6757da:	00 00 
  6757dc:	f3 0f 58 c8          	addss  %xmm0,%xmm1
  6757e0:	f3 0f 10 84 24 84 04 	movss  0x484(%rsp),%xmm0
  6757e7:	00 00 
  6757e9:	f3 0f 11 8c 24 24 02 	movss  %xmm1,0x224(%rsp)
  6757f0:	00 00 
  6757f2:	f3 0f 58 c1          	addss  %xmm1,%xmm0
  6757f6:	f3 0f 11 84 24 1c 02 	movss  %xmm0,0x21c(%rsp)
  6757fd:	00 00 
  6757ff:	0f 28 c2             	movaps %xmm2,%xmm0
  675802:	0f b6 8c 24 8c 04 00 	movzbl 0x48c(%rsp),%ecx
  675809:	00 
  67580a:	88 8c 24 90 02 00 00 	mov    %cl,0x290(%rsp)
  675811:	48 8b 8c 24 70 04 00 	mov    0x470(%rsp),%rcx
  675818:	00 
  675819:	48 89 8c 24 38 01 00 	mov    %rcx,0x138(%rsp)
  675820:	00 
  675821:	8b 8c 24 78 04 00 00 	mov    0x478(%rsp),%ecx
  675828:	89 8c 24 dc 00 00 00 	mov    %ecx,0xdc(%rsp)
  67582f:	8b 8c 24 88 04 00 00 	mov    0x488(%rsp),%ecx
  675836:	89 8c 24 20 02 00 00 	mov    %ecx,0x220(%rsp)
  67583d:	48 8d 4a 16          	lea    0x16(%rdx),%rcx
  675841:	48 89 8c 24 50 02 00 	mov    %rcx,0x250(%rsp)
  675848:	00 
  675849:	48 89 94 24 d0 01 00 	mov    %rdx,0x1d0(%rsp)
  675850:	00 
  675851:	48 8d 4a 2e          	lea    0x2e(%rdx),%rcx
  675855:	48 89 8c 24 00 03 00 	mov    %rcx,0x300(%rsp)
  67585c:	00 
  67585d:	4c 89 b4 24 e8 01 00 	mov    %r14,0x1e8(%rsp)
  675864:	00 
  675865:	eb 6e                	jmp    6758d5 <<gpui_canvas::text::planner::Planner>::shape+0x1875>
  675867:	03 6c 24 30          	add    0x30(%rsp),%ebp
  67586b:	0f 28 8c 24 a0 01 00 	movaps 0x1a0(%rsp),%xmm1
  675872:	00 
  675873:	f3 0f 58 4c 24 1c    	addss  0x1c(%rsp),%xmm1
  675879:	48 8b 84 24 f0 00 00 	mov    0xf0(%rsp),%rax
  675880:	00 
  675881:	4c 89 f1             	mov    %r14,%rcx
  675884:	48 c1 e1 04          	shl    $0x4,%rcx
  675888:	89 2c 08             	mov    %ebp,(%rax,%rcx,1)
  67588b:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  675891:	f3 0f 11 44 08 04    	movss  %xmm0,0x4(%rax,%rcx,1)
  675897:	f3 0f 11 4c 08 08    	movss  %xmm1,0x8(%rax,%rcx,1)
  67589d:	8b 54 24 5c          	mov    0x5c(%rsp),%edx
  6758a1:	66 89 54 08 0c       	mov    %dx,0xc(%rax,%rcx,1)
  6758a6:	48 8b 94 24 60 02 00 	mov    0x260(%rsp),%rdx
  6758ad:	00 
  6758ae:	88 54 08 0e          	mov    %dl,0xe(%rax,%rcx,1)
  6758b2:	c6 44 08 0f 00       	movb   $0x0,0xf(%rax,%rcx,1)
  6758b7:	49 ff c6             	inc    %r14
  6758ba:	4c 89 b4 24 f8 00 00 	mov    %r14,0xf8(%rsp)
  6758c1:	00 
  6758c2:	31 c0                	xor    %eax,%eax
  6758c4:	4c 8b b4 24 e8 01 00 	mov    0x1e8(%rsp),%r14
  6758cb:	00 
  6758cc:	f3 0f 10 84 24 c4 01 	movss  0x1c4(%rsp),%xmm0
  6758d3:	00 00 
  6758d5:	f3 0f 11 44 24 0c    	movss  %xmm0,0xc(%rsp)
  6758db:	a8 01                	test   $0x1,%al
  6758dd:	74 61                	je     675940 <<gpui_canvas::text::planner::Planner>::shape+0x18e0>
  6758df:	f3 0f 10 84 24 b8 01 	movss  0x1b8(%rsp),%xmm0
  6758e6:	00 00 
  6758e8:	f3 0f 11 44 24 08    	movss  %xmm0,0x8(%rsp)
  6758ee:	8b 84 24 bc 01 00 00 	mov    0x1bc(%rsp),%eax
  6758f5:	89 44 24 5c          	mov    %eax,0x5c(%rsp)
  6758f9:	0f 28 84 24 30 02 00 	movaps 0x230(%rsp),%xmm0
  675900:	00 
  675901:	0f 29 84 24 a0 01 00 	movaps %xmm0,0x1a0(%rsp)
  675908:	00 
  675909:	83 bc 24 dc 00 00 00 	cmpl   $0x0,0xdc(%rsp)
  675910:	00 
  675911:	74 71                	je     675984 <<gpui_canvas::text::planner::Planner>::shape+0x1924>
  675913:	48 83 7c 24 60 00    	cmpq   $0x0,0x60(%rsp)
  675919:	74 7c                	je     675997 <<gpui_canvas::text::planner::Planner>::shape+0x1937>
  67591b:	0f 28 84 24 a0 01 00 	movaps 0x1a0(%rsp),%xmm0
  675922:	00 
  675923:	f3 0f 11 84 24 d8 00 	movss  %xmm0,0xd8(%rsp)
  67592a:	00 00 
  67592c:	e9 94 00 00 00       	jmp    6759c5 <<gpui_canvas::text::planner::Planner>::shape+0x1965>
  675931:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  675938:	0f 1f 84 00 00 00 00 
  67593f:	00 
  675940:	48 3b 9c 24 c0 00 00 	cmp    0xc0(%rsp),%rbx
  675947:	00 
  675948:	0f 84 3d 01 00 00    	je     675a8b <<gpui_canvas::text::planner::Planner>::shape+0x1a2b>
  67594e:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  675953:	8b 03                	mov    (%rbx),%eax
  675955:	89 44 24 5c          	mov    %eax,0x5c(%rsp)
  675959:	f2 0f 10 43 04       	movsd  0x4(%rbx),%xmm0
  67595e:	0f 29 84 24 a0 01 00 	movaps %xmm0,0x1a0(%rsp)
  675965:	00 
  675966:	f3 0f 10 43 0c       	movss  0xc(%rbx),%xmm0
  67596b:	f3 0f 11 44 24 08    	movss  %xmm0,0x8(%rsp)
  675971:	48 83 c3 10          	add    $0x10,%rbx
  675975:	48 89 54 24 60       	mov    %rdx,0x60(%rsp)
  67597a:	83 bc 24 dc 00 00 00 	cmpl   $0x0,0xdc(%rsp)
  675981:	00 
  675982:	75 8f                	jne    675913 <<gpui_canvas::text::planner::Planner>::shape+0x18b3>
  675984:	0f 28 84 24 a0 01 00 	movaps 0x1a0(%rsp),%xmm0
  67598b:	00 
  67598c:	f3 0f 11 84 24 d8 00 	movss  %xmm0,0xd8(%rsp)
  675993:	00 00 
  675995:	eb 5f                	jmp    6759f6 <<gpui_canvas::text::planner::Planner>::shape+0x1996>
  675997:	f3 0f 10 84 24 c0 01 	movss  0x1c0(%rsp),%xmm0
  67599e:	00 00 
  6759a0:	0f 28 c8             	movaps %xmm0,%xmm1
  6759a3:	f3 0f 58 8c 24 a0 01 	addss  0x1a0(%rsp),%xmm1
  6759aa:	00 00 
  6759ac:	f3 0f 11 8c 24 d8 00 	movss  %xmm1,0xd8(%rsp)
  6759b3:	00 00 
  6759b5:	f3 0f 10 4c 24 08    	movss  0x8(%rsp),%xmm1
  6759bb:	f3 0f 58 c8          	addss  %xmm0,%xmm1
  6759bf:	f3 0f 11 4c 24 08    	movss  %xmm1,0x8(%rsp)
  6759c5:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  6759ca:	48 ff c2             	inc    %rdx
  6759cd:	48 8b 84 24 38 01 00 	mov    0x138(%rsp),%rax
  6759d4:	00 
  6759d5:	48 89 54 24 60       	mov    %rdx,0x60(%rsp)
  6759da:	48 39 c2             	cmp    %rax,%rdx
  6759dd:	75 17                	jne    6759f6 <<gpui_canvas::text::planner::Planner>::shape+0x1996>
  6759df:	f3 0f 10 44 24 08    	movss  0x8(%rsp),%xmm0
  6759e5:	f3 0f 58 44 24 58    	addss  0x58(%rsp),%xmm0
  6759eb:	f3 0f 11 44 24 08    	movss  %xmm0,0x8(%rsp)
  6759f1:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  6759f6:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
  6759fd:	00 
  6759fe:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
  675a05:	00 
  675a06:	e8 95 26 00 00       	call   6780a0 <<core::iter::adapters::flatten::FlattenCompat<core::iter::adapters::map::Map<core::ops::range::Range<u32>, <parley::layout::run::Run<()>>::glyph_source_ranges::{closure#0}>, core::iter::sources::repeat_n::RepeatN<core::ops::range::Range<usize>>> as core::iter::traits::iterator::Iterator>::next>
  675a0b:	83 bc 24 88 00 00 00 	cmpl   $0x1,0x88(%rsp)
  675a12:	01 
  675a13:	0f 85 e0 15 00 00    	jne    676ff9 <<gpui_canvas::text::planner::Planner>::shape+0x2f99>
  675a19:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  675a1f:	f3 0f 58 44 24 08    	addss  0x8(%rsp),%xmm0
  675a25:	31 c0                	xor    %eax,%eax
  675a27:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  675a2c:	48 39 8c 24 00 01 00 	cmp    %rcx,0x100(%rsp)
  675a33:	00 
  675a34:	0f 84 9b fe ff ff    	je     6758d5 <<gpui_canvas::text::planner::Planner>::shape+0x1875>
  675a3a:	f3 0f 11 84 24 c4 01 	movss  %xmm0,0x1c4(%rsp)
  675a41:	00 00 
  675a43:	4c 8b 8c 24 90 00 00 	mov    0x90(%rsp),%r9
  675a4a:	00 
  675a4b:	48 8b ac 24 98 00 00 	mov    0x98(%rsp),%rbp
  675a52:	00 
  675a53:	49 39 e9             	cmp    %rbp,%r9
  675a56:	48 8b 8c 24 10 01 00 	mov    0x110(%rsp),%rcx
  675a5d:	00 
  675a5e:	0f 87 85 15 00 00    	ja     676fe9 <<gpui_canvas::text::planner::Planner>::shape+0x2f89>
  675a64:	4d 85 c9             	test   %r9,%r9
  675a67:	0f 84 f7 04 00 00    	je     675f64 <<gpui_canvas::text::planner::Planner>::shape+0x1f04>
  675a6d:	49 39 c9             	cmp    %rcx,%r9
  675a70:	0f 83 e8 04 00 00    	jae    675f5e <<gpui_canvas::text::planner::Planner>::shape+0x1efe>
  675a76:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  675a7b:	42 80 3c 08 bf       	cmpb   $0xbf,(%rax,%r9,1)
  675a80:	0f 8f de 04 00 00    	jg     675f64 <<gpui_canvas::text::planner::Planner>::shape+0x1f04>
  675a86:	e9 5e 15 00 00       	jmp    676fe9 <<gpui_canvas::text::planner::Planner>::shape+0x2f89>
  675a8b:	48 89 9c 24 c0 00 00 	mov    %rbx,0xc0(%rsp)
  675a92:	00 
  675a93:	f6 84 24 90 02 00 00 	testb  $0x1,0x290(%rsp)
  675a9a:	01 
  675a9b:	74 19                	je     675ab6 <<gpui_canvas::text::planner::Planner>::shape+0x1a56>
  675a9d:	4c 89 fa             	mov    %r15,%rdx
  675aa0:	48 8b 8c 24 20 01 00 	mov    0x120(%rsp),%rcx
  675aa7:	00 
  675aa8:	39 d1                	cmp    %edx,%ecx
  675aaa:	0f 83 3d 01 00 00    	jae    675bed <<gpui_canvas::text::planner::Planner>::shape+0x1b8d>
  675ab0:	ff ca                	dec    %edx
  675ab2:	89 d0                	mov    %edx,%eax
  675ab4:	eb 19                	jmp    675acf <<gpui_canvas::text::planner::Planner>::shape+0x1a6f>
  675ab6:	4c 89 fa             	mov    %r15,%rdx
  675ab9:	48 8b ac 24 20 01 00 	mov    0x120(%rsp),%rbp
  675ac0:	00 
  675ac1:	39 d5                	cmp    %edx,%ebp
  675ac3:	0f 83 3f 01 00 00    	jae    675c08 <<gpui_canvas::text::planner::Planner>::shape+0x1ba8>
  675ac9:	8d 4d 01             	lea    0x1(%rbp),%ecx
  675acc:	48 89 e8             	mov    %rbp,%rax
  675acf:	89 c7                	mov    %eax,%edi
  675ad1:	49 39 fe             	cmp    %rdi,%r14
  675ad4:	0f 86 29 1b 00 00    	jbe    677603 <<gpui_canvas::text::planner::Planner>::shape+0x35a3>
  675ada:	49 89 d7             	mov    %rdx,%r15
  675add:	48 8d 04 7f          	lea    (%rdi,%rdi,2),%rax
  675ae1:	48 8b 94 24 d0 01 00 	mov    0x1d0(%rsp),%rdx
  675ae8:	00 
  675ae9:	8b 5c c2 08          	mov    0x8(%rdx,%rax,8),%ebx
  675aed:	f6 44 c2 17 01       	testb  $0x1,0x17(%rdx,%rax,8)
  675af2:	0f 85 63 05 00 00    	jne    67605b <<gpui_canvas::text::planner::Planner>::shape+0x1ffb>
  675af8:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
  675afc:	8b 50 0c             	mov    0xc(%rax),%edx
  675aff:	48 8d 34 1a          	lea    (%rdx,%rbx,1),%rsi
  675b03:	48 3b b4 24 40 01 00 	cmp    0x140(%rsp),%rsi
  675b0a:	00 
  675b0b:	0f 87 27 17 00 00    	ja     677238 <<gpui_canvas::text::planner::Planner>::shape+0x31d8>
  675b11:	48 c1 e3 04          	shl    $0x4,%rbx
  675b15:	48 03 9c 24 78 02 00 	add    0x278(%rsp),%rbx
  675b1c:	00 
  675b1d:	48 89 d0             	mov    %rdx,%rax
  675b20:	48 c1 e0 04          	shl    $0x4,%rax
  675b24:	48 01 d8             	add    %rbx,%rax
  675b27:	0f 57 c0             	xorps  %xmm0,%xmm0
  675b2a:	0f 29 84 24 30 02 00 	movaps %xmm0,0x230(%rsp)
  675b31:	00 
  675b32:	48 85 d2             	test   %rdx,%rdx
  675b35:	0f 85 bf 06 00 00    	jne    6761fa <<gpui_canvas::text::planner::Planner>::shape+0x219a>
  675b3b:	89 ca                	mov    %ecx,%edx
  675b3d:	48 89 94 24 20 01 00 	mov    %rdx,0x120(%rsp)
  675b44:	00 
  675b45:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  675b4c:	00 00 00 00 
  675b50:	f6 84 24 90 02 00 00 	testb  $0x1,0x290(%rsp)
  675b57:	01 
  675b58:	74 16                	je     675b70 <<gpui_canvas::text::planner::Planner>::shape+0x1b10>
  675b5a:	44 39 f9             	cmp    %r15d,%ecx
  675b5d:	0f 83 c4 00 00 00    	jae    675c27 <<gpui_canvas::text::planner::Planner>::shape+0x1bc7>
  675b63:	41 ff cf             	dec    %r15d
  675b66:	4c 89 f8             	mov    %r15,%rax
  675b69:	89 ca                	mov    %ecx,%edx
  675b6b:	89 c1                	mov    %eax,%ecx
  675b6d:	eb 19                	jmp    675b88 <<gpui_canvas::text::planner::Planner>::shape+0x1b28>
  675b6f:	90                   	nop
  675b70:	4c 89 fa             	mov    %r15,%rdx
  675b73:	39 d1                	cmp    %edx,%ecx
  675b75:	0f 83 5c 01 00 00    	jae    675cd7 <<gpui_canvas::text::planner::Planner>::shape+0x1c77>
  675b7b:	8d 41 01             	lea    0x1(%rcx),%eax
  675b7e:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
  675b85:	00 
  675b86:	89 c2                	mov    %eax,%edx
  675b88:	89 cf                	mov    %ecx,%edi
  675b8a:	49 39 fe             	cmp    %rdi,%r14
  675b8d:	0f 86 70 1a 00 00    	jbe    677603 <<gpui_canvas::text::planner::Planner>::shape+0x35a3>
  675b93:	48 8d 04 7f          	lea    (%rdi,%rdi,2),%rax
  675b97:	48 8b 8c 24 d0 01 00 	mov    0x1d0(%rsp),%rcx
  675b9e:	00 
  675b9f:	8b 5c c1 08          	mov    0x8(%rcx,%rax,8),%ebx
  675ba3:	f6 44 c1 17 01       	testb  $0x1,0x17(%rcx,%rax,8)
  675ba8:	0f 85 a5 04 00 00    	jne    676053 <<gpui_canvas::text::planner::Planner>::shape+0x1ff3>
  675bae:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
  675bb2:	8b 78 0c             	mov    0xc(%rax),%edi
  675bb5:	48 8d 34 1f          	lea    (%rdi,%rbx,1),%rsi
  675bb9:	48 3b b4 24 40 01 00 	cmp    0x140(%rsp),%rsi
  675bc0:	00 
  675bc1:	0f 87 71 16 00 00    	ja     677238 <<gpui_canvas::text::planner::Planner>::shape+0x31d8>
  675bc7:	48 c1 e3 04          	shl    $0x4,%rbx
  675bcb:	48 03 9c 24 78 02 00 	add    0x278(%rsp),%rbx
  675bd2:	00 
  675bd3:	48 89 f8             	mov    %rdi,%rax
  675bd6:	48 c1 e0 04          	shl    $0x4,%rax
  675bda:	48 01 d8             	add    %rbx,%rax
  675bdd:	89 d1                	mov    %edx,%ecx
  675bdf:	48 85 ff             	test   %rdi,%rdi
  675be2:	0f 84 68 ff ff ff    	je     675b50 <<gpui_canvas::text::planner::Planner>::shape+0x1af0>
  675be8:	e9 df 04 00 00       	jmp    6760cc <<gpui_canvas::text::planner::Planner>::shape+0x206c>
  675bed:	48 89 d8             	mov    %rbx,%rax
  675bf0:	3b 8c 24 f0 01 00 00 	cmp    0x1f0(%rsp),%ecx
  675bf7:	0f 95 c2             	setne  %dl
  675bfa:	84 94 24 dc 00 00 00 	test   %dl,0xdc(%rsp)
  675c01:	75 4e                	jne    675c51 <<gpui_canvas::text::planner::Planner>::shape+0x1bf1>
  675c03:	e9 0c 06 00 00       	jmp    676214 <<gpui_canvas::text::planner::Planner>::shape+0x21b4>
  675c08:	48 89 d8             	mov    %rbx,%rax
  675c0b:	3b 94 24 f8 01 00 00 	cmp    0x1f8(%rsp),%edx
  675c12:	0f 95 c1             	setne  %cl
  675c15:	84 8c 24 dc 00 00 00 	test   %cl,0xdc(%rsp)
  675c1c:	0f 85 df 00 00 00    	jne    675d01 <<gpui_canvas::text::planner::Planner>::shape+0x1ca1>
  675c22:	e9 ed 05 00 00       	jmp    676214 <<gpui_canvas::text::planner::Planner>::shape+0x21b4>
  675c27:	0f 57 c0             	xorps  %xmm0,%xmm0
  675c2a:	0f 29 84 24 30 02 00 	movaps %xmm0,0x230(%rsp)
  675c31:	00 
  675c32:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  675c39:	00 
  675c3a:	3b 8c 24 f0 01 00 00 	cmp    0x1f0(%rsp),%ecx
  675c41:	0f 95 c2             	setne  %dl
  675c44:	84 94 24 dc 00 00 00 	test   %dl,0xdc(%rsp)
  675c4b:	0f 84 c3 05 00 00    	je     676214 <<gpui_canvas::text::planner::Planner>::shape+0x21b4>
  675c51:	8d 79 ff             	lea    -0x1(%rcx),%edi
  675c54:	49 39 fe             	cmp    %rdi,%r14
  675c57:	0f 86 47 1a 00 00    	jbe    6776a4 <<gpui_canvas::text::planner::Planner>::shape+0x3644>
  675c5d:	3b bc 24 f0 01 00 00 	cmp    0x1f0(%rsp),%edi
  675c64:	76 48                	jbe    675cae <<gpui_canvas::text::planner::Planner>::shape+0x1c4e>
  675c66:	48 8d 14 7f          	lea    (%rdi,%rdi,2),%rdx
  675c6a:	48 8b b4 24 50 02 00 	mov    0x250(%rsp),%rsi
  675c71:	00 
  675c72:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
  675c76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  675c7d:	00 00 00 
  675c80:	49 39 fe             	cmp    %rdi,%r14
  675c83:	0f 86 9b 19 00 00    	jbe    677624 <<gpui_canvas::text::planner::Planner>::shape+0x35c4>
  675c89:	f6 42 01 02          	testb  $0x2,0x1(%rdx)
  675c8d:	75 1f                	jne    675cae <<gpui_canvas::text::planner::Planner>::shape+0x1c4e>
  675c8f:	48 ff cf             	dec    %rdi
  675c92:	48 83 c2 e8          	add    $0xffffffffffffffe8,%rdx
  675c96:	39 bc 24 f0 01 00 00 	cmp    %edi,0x1f0(%rsp)
  675c9d:	72 e1                	jb     675c80 <<gpui_canvas::text::planner::Planner>::shape+0x1c20>
  675c9f:	48 8b 94 24 f0 01 00 	mov    0x1f0(%rsp),%rdx
  675ca6:	00 
  675ca7:	48 89 d7             	mov    %rdx,%rdi
  675caa:	89 d5                	mov    %edx,%ebp
  675cac:	eb 02                	jmp    675cb0 <<gpui_canvas::text::planner::Planner>::shape+0x1c50>
  675cae:	89 fd                	mov    %edi,%ebp
  675cb0:	49 39 fe             	cmp    %rdi,%r14
  675cb3:	0f 86 f7 19 00 00    	jbe    6776b0 <<gpui_canvas::text::planner::Planner>::shape+0x3650>
  675cb9:	48 89 ac 24 20 01 00 	mov    %rbp,0x120(%rsp)
  675cc0:	00 
  675cc1:	89 ca                	mov    %ecx,%edx
  675cc3:	48 ff ca             	dec    %rdx
  675cc6:	4c 39 f2             	cmp    %r14,%rdx
  675cc9:	0f 83 ed 19 00 00    	jae    6776bc <<gpui_canvas::text::planner::Planner>::shape+0x365c>
  675ccf:	41 89 cf             	mov    %ecx,%r15d
  675cd2:	e9 a8 00 00 00       	jmp    675d7f <<gpui_canvas::text::planner::Planner>::shape+0x1d1f>
  675cd7:	0f 57 c0             	xorps  %xmm0,%xmm0
  675cda:	0f 29 84 24 30 02 00 	movaps %xmm0,0x230(%rsp)
  675ce1:	00 
  675ce2:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  675ce9:	00 
  675cea:	3b 94 24 f8 01 00 00 	cmp    0x1f8(%rsp),%edx
  675cf1:	0f 95 c1             	setne  %cl
  675cf4:	84 8c 24 dc 00 00 00 	test   %cl,0xdc(%rsp)
  675cfb:	0f 84 13 05 00 00    	je     676214 <<gpui_canvas::text::planner::Planner>::shape+0x21b4>
  675d01:	49 89 d0             	mov    %rdx,%r8
  675d04:	48 89 d1             	mov    %rdx,%rcx
  675d07:	89 cf                	mov    %ecx,%edi
  675d09:	49 39 fe             	cmp    %rdi,%r14
  675d0c:	0f 86 7d 19 00 00    	jbe    67768f <<gpui_canvas::text::planner::Planner>::shape+0x362f>
  675d12:	44 8d 79 01          	lea    0x1(%rcx),%r15d
  675d16:	44 3b bc 24 f8 01 00 	cmp    0x1f8(%rsp),%r15d
  675d1d:	00 
  675d1e:	73 48                	jae    675d68 <<gpui_canvas::text::planner::Planner>::shape+0x1d08>
  675d20:	44 89 fa             	mov    %r15d,%edx
  675d23:	48 8d 0c 52          	lea    (%rdx,%rdx,2),%rcx
  675d27:	48 8b b4 24 50 02 00 	mov    0x250(%rsp),%rsi
  675d2e:	00 
  675d2f:	48 8d 34 ce          	lea    (%rsi,%rcx,8),%rsi
  675d33:	49 89 d7             	mov    %rdx,%r15
  675d36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  675d3d:	00 00 00 
  675d40:	4d 39 fe             	cmp    %r15,%r14
  675d43:	0f 86 c3 18 00 00    	jbe    67760c <<gpui_canvas::text::planner::Planner>::shape+0x35ac>
  675d49:	f6 46 01 02          	testb  $0x2,0x1(%rsi)
  675d4d:	75 19                	jne    675d68 <<gpui_canvas::text::planner::Planner>::shape+0x1d08>
  675d4f:	49 ff c7             	inc    %r15
  675d52:	48 83 c6 18          	add    $0x18,%rsi
  675d56:	4c 39 bc 24 f8 01 00 	cmp    %r15,0x1f8(%rsp)
  675d5d:	00 
  675d5e:	75 e0                	jne    675d40 <<gpui_canvas::text::planner::Planner>::shape+0x1ce0>
  675d60:	4c 8b bc 24 f8 01 00 	mov    0x1f8(%rsp),%r15
  675d67:	00 
  675d68:	44 89 fa             	mov    %r15d,%edx
  675d6b:	48 ff ca             	dec    %rdx
  675d6e:	4c 39 f2             	cmp    %r14,%rdx
  675d71:	0f 83 21 19 00 00    	jae    677698 <<gpui_canvas::text::planner::Planner>::shape+0x3638>
  675d77:	4c 89 84 24 20 01 00 	mov    %r8,0x120(%rsp)
  675d7e:	00 
  675d7f:	48 83 bc 24 68 02 00 	cmpq   $0x0,0x268(%rsp)
  675d86:	00 00 
  675d88:	0f 84 86 04 00 00    	je     676214 <<gpui_canvas::text::planner::Planner>::shape+0x21b4>
  675d8e:	48 8d 0c 7f          	lea    (%rdi,%rdi,2),%rcx
  675d92:	48 8b b4 24 d0 01 00 	mov    0x1d0(%rsp),%rsi
  675d99:	00 
  675d9a:	8b 0c ce             	mov    (%rsi,%rcx,8),%ecx
  675d9d:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
  675da1:	8b 74 d6 04          	mov    0x4(%rsi,%rdx,8),%esi
  675da5:	39 ce                	cmp    %ecx,%esi
  675da7:	0f 82 b3 17 00 00    	jb     677560 <<gpui_canvas::text::planner::Planner>::shape+0x3500>
  675dad:	48 39 b4 24 00 02 00 	cmp    %rsi,0x200(%rsp)
  675db4:	00 
  675db5:	0f 82 a5 17 00 00    	jb     677560 <<gpui_canvas::text::planner::Planner>::shape+0x3500>
  675dbb:	39 ce                	cmp    %ecx,%esi
  675dbd:	0f 84 ad 18 00 00    	je     677670 <<gpui_canvas::text::planner::Planner>::shape+0x3610>
  675dc3:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  675dc7:	48 8b 94 24 68 02 00 	mov    0x268(%rsp),%rdx
  675dce:	00 
  675dcf:	0f b6 4c 8a 07       	movzbl 0x7(%rdx,%rcx,4),%ecx
  675dd4:	8d 51 ff             	lea    -0x1(%rcx),%edx
  675dd7:	83 fa 02             	cmp    $0x2,%edx
  675dda:	73 26                	jae    675e02 <<gpui_canvas::text::planner::Planner>::shape+0x1da2>
  675ddc:	f3 0f 10 84 24 24 02 	movss  0x224(%rsp),%xmm0
  675de3:	00 00 
  675de5:	f3 0f 11 44 24 58    	movss  %xmm0,0x58(%rsp)
  675deb:	4c 89 fa             	mov    %r15,%rdx
  675dee:	3b 94 24 20 02 00 00 	cmp    0x220(%rsp),%edx
  675df5:	77 2b                	ja     675e22 <<gpui_canvas::text::planner::Planner>::shape+0x1dc2>
  675df7:	f3 0f 10 84 24 1c 02 	movss  0x21c(%rsp),%xmm0
  675dfe:	00 00 
  675e00:	eb 1a                	jmp    675e1c <<gpui_canvas::text::planner::Planner>::shape+0x1dbc>
  675e02:	f3 0f 10 84 24 28 02 	movss  0x228(%rsp),%xmm0
  675e09:	00 00 
  675e0b:	f3 0f 11 44 24 58    	movss  %xmm0,0x58(%rsp)
  675e11:	83 f9 06             	cmp    $0x6,%ecx
  675e14:	4c 89 fa             	mov    %r15,%rdx
  675e17:	75 09                	jne    675e22 <<gpui_canvas::text::planner::Planner>::shape+0x1dc2>
  675e19:	0f 57 c0             	xorps  %xmm0,%xmm0
  675e1c:	f3 0f 11 44 24 58    	movss  %xmm0,0x58(%rsp)
  675e22:	89 d6                	mov    %edx,%esi
  675e24:	49 39 f6             	cmp    %rsi,%r14
  675e27:	0f 92 c1             	setb   %cl
  675e2a:	3b 94 24 20 01 00 00 	cmp    0x120(%rsp),%edx
  675e31:	0f 82 0e 01 00 00    	jb     675f45 <<gpui_canvas::text::planner::Planner>::shape+0x1ee5>
  675e37:	48 8b bc 24 20 01 00 	mov    0x120(%rsp),%rdi
  675e3e:	00 
  675e3f:	89 fa                	mov    %edi,%edx
  675e41:	84 c9                	test   %cl,%cl
  675e43:	0f 85 36 17 00 00    	jne    67757f <<gpui_canvas::text::planner::Planner>::shape+0x351f>
  675e49:	44 39 ff             	cmp    %r15d,%edi
  675e4c:	75 11                	jne    675e5f <<gpui_canvas::text::planner::Planner>::shape+0x1dff>
  675e4e:	48 c7 84 24 38 01 00 	movq   $0x0,0x138(%rsp)
  675e55:	00 00 00 00 00 
  675e5a:	e9 bd 00 00 00       	jmp    675f1c <<gpui_canvas::text::planner::Planner>::shape+0x1ebc>
  675e5f:	48 8d 0c d5 00 00 00 	lea    0x0(,%rdx,8),%rcx
  675e66:	00 
  675e67:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  675e6b:	48 8d 7e ff          	lea    -0x1(%rsi),%rdi
  675e6f:	48 39 d7             	cmp    %rdx,%rdi
  675e72:	75 10                	jne    675e84 <<gpui_canvas::text::planner::Planner>::shape+0x1e24>
  675e74:	31 d2                	xor    %edx,%edx
  675e76:	48 c7 84 24 38 01 00 	movq   $0x0,0x138(%rsp)
  675e7d:	00 00 00 00 00 
  675e82:	eb 67                	jmp    675eeb <<gpui_canvas::text::planner::Planner>::shape+0x1e8b>
  675e84:	48 29 d6             	sub    %rdx,%rsi
  675e87:	48 89 f7             	mov    %rsi,%rdi
  675e8a:	48 83 e7 fe          	and    $0xfffffffffffffffe,%rdi
  675e8e:	48 8b 94 24 00 03 00 	mov    0x300(%rsp),%rdx
  675e95:	00 
  675e96:	4c 8d 04 0a          	lea    (%rdx,%rcx,1),%r8
  675e9a:	31 d2                	xor    %edx,%edx
  675e9c:	45 31 d2             	xor    %r10d,%r10d
  675e9f:	41 bb 01 00 00 00    	mov    $0x1,%r11d
  675ea5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  675eac:	00 00 00 00 
  675eb0:	45 8b 48 de          	mov    -0x22(%r8),%r9d
  675eb4:	41 f6 40 e9 01       	testb  $0x1,-0x17(%r8)
  675eb9:	4d 0f 45 cb          	cmovne %r11,%r9
  675ebd:	4d 01 d1             	add    %r10,%r9
  675ec0:	41 f6 40 01 01       	testb  $0x1,0x1(%r8)
  675ec5:	45 8b 50 f6          	mov    -0xa(%r8),%r10d
  675ec9:	4d 0f 45 d3          	cmovne %r11,%r10
  675ecd:	4d 01 ca             	add    %r9,%r10
  675ed0:	48 83 c2 02          	add    $0x2,%rdx
  675ed4:	49 83 c0 30          	add    $0x30,%r8
  675ed8:	48 39 d7             	cmp    %rdx,%rdi
  675edb:	75 d3                	jne    675eb0 <<gpui_canvas::text::planner::Planner>::shape+0x1e50>
  675edd:	4c 89 94 24 38 01 00 	mov    %r10,0x138(%rsp)
  675ee4:	00 
  675ee5:	40 f6 c6 01          	test   $0x1,%sil
  675ee9:	74 31                	je     675f1c <<gpui_canvas::text::planner::Planner>::shape+0x1ebc>
  675eeb:	48 8b b4 24 38 01 00 	mov    0x138(%rsp),%rsi
  675ef2:	00 
  675ef3:	48 03 8c 24 d0 01 00 	add    0x1d0(%rsp),%rcx
  675efa:	00 
  675efb:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
  675eff:	f6 44 d1 17 01       	testb  $0x1,0x17(%rcx,%rdx,8)
  675f04:	8b 54 d1 0c          	mov    0xc(%rcx,%rdx,8),%edx
  675f08:	b9 01 00 00 00       	mov    $0x1,%ecx
  675f0d:	48 0f 45 d1          	cmovne %rcx,%rdx
  675f11:	48 01 f2             	add    %rsi,%rdx
  675f14:	48 89 94 24 38 01 00 	mov    %rdx,0x138(%rsp)
  675f1b:	00 
  675f1c:	0f 57 c0             	xorps  %xmm0,%xmm0
  675f1f:	f3 0f 11 84 24 c0 01 	movss  %xmm0,0x1c0(%rsp)
  675f26:	00 00 
  675f28:	b9 00 00 00 00       	mov    $0x0,%ecx
  675f2d:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
  675f32:	ba 00 00 00 00       	mov    $0x0,%edx
  675f37:	48 39 c3             	cmp    %rax,%rbx
  675f3a:	0f 84 53 fb ff ff    	je     675a93 <<gpui_canvas::text::planner::Planner>::shape+0x1a33>
  675f40:	e9 0e fa ff ff       	jmp    675953 <<gpui_canvas::text::planner::Planner>::shape+0x18f3>
  675f45:	b1 01                	mov    $0x1,%cl
  675f47:	48 8b bc 24 20 01 00 	mov    0x120(%rsp),%rdi
  675f4e:	00 
  675f4f:	89 fa                	mov    %edi,%edx
  675f51:	84 c9                	test   %cl,%cl
  675f53:	0f 84 f0 fe ff ff    	je     675e49 <<gpui_canvas::text::planner::Planner>::shape+0x1de9>
  675f59:	e9 21 16 00 00       	jmp    67757f <<gpui_canvas::text::planner::Planner>::shape+0x351f>
  675f5e:	0f 85 85 10 00 00    	jne    676fe9 <<gpui_canvas::text::planner::Planner>::shape+0x2f89>
  675f64:	48 85 ed             	test   %rbp,%rbp
  675f67:	0f 94 c2             	sete   %dl
  675f6a:	74 1b                	je     675f87 <<gpui_canvas::text::planner::Planner>::shape+0x1f27>
  675f6c:	48 39 cd             	cmp    %rcx,%rbp
  675f6f:	73 10                	jae    675f81 <<gpui_canvas::text::planner::Planner>::shape+0x1f21>
  675f71:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  675f76:	80 3c 28 c0          	cmpb   $0xc0,(%rax,%rbp,1)
  675f7a:	7d 0b                	jge    675f87 <<gpui_canvas::text::planner::Planner>::shape+0x1f27>
  675f7c:	e9 68 10 00 00       	jmp    676fe9 <<gpui_canvas::text::planner::Planner>::shape+0x2f89>
  675f81:	0f 85 62 10 00 00    	jne    676fe9 <<gpui_canvas::text::planner::Planner>::shape+0x2f89>
  675f87:	83 7c 24 5c 00       	cmpl   $0x0,0x5c(%rsp)
  675f8c:	0f 84 9a 00 00 00    	je     67602c <<gpui_canvas::text::planner::Planner>::shape+0x1fcc>
  675f92:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  675f98:	f3 0f 58 84 24 d8 00 	addss  0xd8(%rsp),%xmm0
  675f9f:	00 00 
  675fa1:	f3 0f 11 44 24 0c    	movss  %xmm0,0xc(%rsp)
  675fa7:	66 0f 7e c1          	movd   %xmm0,%ecx
  675fab:	0f 28 84 24 a0 01 00 	movaps 0x1a0(%rsp),%xmm0
  675fb2:	00 
  675fb3:	0f 58 84 24 e0 03 00 	addps  0x3e0(%rsp),%xmm0
  675fba:	00 
  675fbb:	0f c6 c0 55          	shufps $0x55,%xmm0,%xmm0
  675fbf:	0f 29 84 24 a0 01 00 	movaps %xmm0,0x1a0(%rsp)
  675fc6:	00 
  675fc7:	66 0f 7e c0          	movd   %xmm0,%eax
  675fcb:	81 e1 ff ff ff 7f    	and    $0x7fffffff,%ecx
  675fd1:	25 ff ff ff 7f       	and    $0x7fffffff,%eax
  675fd6:	3d 00 00 80 7f       	cmp    $0x7f800000,%eax
  675fdb:	0f 9d c0             	setge  %al
  675fde:	81 f9 ff ff 7f 7f    	cmp    $0x7f7fffff,%ecx
  675fe4:	0f 8f 20 10 00 00    	jg     67700a <<gpui_canvas::text::planner::Planner>::shape+0x2faa>
  675fea:	84 c0                	test   %al,%al
  675fec:	0f 85 18 10 00 00    	jne    67700a <<gpui_canvas::text::planner::Planner>::shape+0x2faa>
  675ff2:	81 7c 24 5c ff ff 00 	cmpl   $0xffff,0x5c(%rsp)
  675ff9:	00 
  675ffa:	0f 87 e9 0f 00 00    	ja     676fe9 <<gpui_canvas::text::planner::Planner>::shape+0x2f89>
  676000:	4c 89 cd             	mov    %r9,%rbp
  676003:	4c 8b b4 24 f8 00 00 	mov    0xf8(%rsp),%r14
  67600a:	00 
  67600b:	4c 3b b4 24 e8 00 00 	cmp    0xe8(%rsp),%r14
  676012:	00 
  676013:	0f 85 4e f8 ff ff    	jne    675867 <<gpui_canvas::text::planner::Planner>::shape+0x1807>
  676019:	48 8d bc 24 e8 00 00 	lea    0xe8(%rsp),%rdi
  676020:	00 
  676021:	ff 15 f1 41 11 00    	call   *0x1141f1(%rip)        # 78a218 <_DYNAMIC+0x498>
  676027:	e9 3b f8 ff ff       	jmp    675867 <<gpui_canvas::text::planner::Planner>::shape+0x1807>
  67602c:	4d 85 c9             	test   %r9,%r9
  67602f:	0f 84 af 00 00 00    	je     6760e4 <<gpui_canvas::text::planner::Planner>::shape+0x2084>
  676035:	49 39 c9             	cmp    %rcx,%r9
  676038:	0f 83 a0 00 00 00    	jae    6760de <<gpui_canvas::text::planner::Planner>::shape+0x207e>
  67603e:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  676043:	42 80 3c 08 bf       	cmpb   $0xbf,(%rax,%r9,1)
  676048:	0f 8f 96 00 00 00    	jg     6760e4 <<gpui_canvas::text::planner::Planner>::shape+0x2084>
  67604e:	e9 63 10 00 00       	jmp    6770b6 <<gpui_canvas::text::planner::Planner>::shape+0x3056>
  676053:	48 8b 8c 24 20 01 00 	mov    0x120(%rsp),%rcx
  67605a:	00 
  67605b:	89 da                	mov    %ebx,%edx
  67605d:	48 8d 04 7f          	lea    (%rdi,%rdi,2),%rax
  676061:	48 8b b4 24 d0 01 00 	mov    0x1d0(%rsp),%rsi
  676068:	00 
  676069:	f3 0f 10 44 c6 10    	movss  0x10(%rsi,%rax,8),%xmm0
  67606f:	0f 57 c9             	xorps  %xmm1,%xmm1
  676072:	0f 29 8c 24 a0 01 00 	movaps %xmm1,0x1a0(%rsp)
  676079:	00 
  67607a:	bb 04 00 00 00       	mov    $0x4,%ebx
  67607f:	b8 04 00 00 00       	mov    $0x4,%eax
  676084:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  67608b:	00 
  67608c:	48 89 8c 24 20 01 00 	mov    %rcx,0x120(%rsp)
  676093:	00 
  676094:	f3 0f 11 84 24 b8 01 	movss  %xmm0,0x1b8(%rsp)
  67609b:	00 00 
  67609d:	f3 0f 11 44 24 08    	movss  %xmm0,0x8(%rsp)
  6760a3:	89 94 24 bc 01 00 00 	mov    %edx,0x1bc(%rsp)
  6760aa:	89 54 24 5c          	mov    %edx,0x5c(%rsp)
  6760ae:	0f 57 c0             	xorps  %xmm0,%xmm0
  6760b1:	0f 29 84 24 30 02 00 	movaps %xmm0,0x230(%rsp)
  6760b8:	00 
  6760b9:	83 bc 24 dc 00 00 00 	cmpl   $0x0,0xdc(%rsp)
  6760c0:	00 
  6760c1:	0f 85 4c f8 ff ff    	jne    675913 <<gpui_canvas::text::planner::Planner>::shape+0x18b3>
  6760c7:	e9 b8 f8 ff ff       	jmp    675984 <<gpui_canvas::text::planner::Planner>::shape+0x1924>
  6760cc:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  6760d1:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  6760d8:	00 
  6760d9:	e9 75 f8 ff ff       	jmp    675953 <<gpui_canvas::text::planner::Planner>::shape+0x18f3>
  6760de:	0f 85 d2 0f 00 00    	jne    6770b6 <<gpui_canvas::text::planner::Planner>::shape+0x3056>
  6760e4:	48 85 ed             	test   %rbp,%rbp
  6760e7:	4c 89 8c 24 f8 02 00 	mov    %r9,0x2f8(%rsp)
  6760ee:	00 
  6760ef:	74 1b                	je     67610c <<gpui_canvas::text::planner::Planner>::shape+0x20ac>
  6760f1:	48 39 cd             	cmp    %rcx,%rbp
  6760f4:	73 10                	jae    676106 <<gpui_canvas::text::planner::Planner>::shape+0x20a6>
  6760f6:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6760fb:	80 3c 28 c0          	cmpb   $0xc0,(%rax,%rbp,1)
  6760ff:	7d 0b                	jge    67610c <<gpui_canvas::text::planner::Planner>::shape+0x20ac>
  676101:	e9 b6 0f 00 00       	jmp    6770bc <<gpui_canvas::text::planner::Planner>::shape+0x305c>
  676106:	0f 85 b0 0f 00 00    	jne    6770bc <<gpui_canvas::text::planner::Planner>::shape+0x305c>
  67610c:	89 54 24 0c          	mov    %edx,0xc(%rsp)
  676110:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  676115:	4e 8d 34 08          	lea    (%rax,%r9,1),%r14
  676119:	48 01 e8             	add    %rbp,%rax
  67611c:	48 89 84 24 a0 01 00 	mov    %rax,0x1a0(%rsp)
  676123:	00 
  676124:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  67612b:	00 00 00 00 00 
  676130:	4c 3b b4 24 a0 01 00 	cmp    0x1a0(%rsp),%r14
  676137:	00 
  676138:	0f 84 8c 00 00 00    	je     6761ca <<gpui_canvas::text::planner::Planner>::shape+0x216a>
  67613e:	41 0f b6 36          	movzbl (%r14),%esi
  676142:	40 84 f6             	test   %sil,%sil
  676145:	78 09                	js     676150 <<gpui_canvas::text::planner::Planner>::shape+0x20f0>
  676147:	49 ff c6             	inc    %r14
  67614a:	eb 64                	jmp    6761b0 <<gpui_canvas::text::planner::Planner>::shape+0x2150>
  67614c:	0f 1f 40 00          	nopl   0x0(%rax)
  676150:	89 f0                	mov    %esi,%eax
  676152:	83 e0 1f             	and    $0x1f,%eax
  676155:	41 0f b6 56 01       	movzbl 0x1(%r14),%edx
  67615a:	83 e2 3f             	and    $0x3f,%edx
  67615d:	40 80 fe df          	cmp    $0xdf,%sil
  676161:	76 2e                	jbe    676191 <<gpui_canvas::text::planner::Planner>::shape+0x2131>
  676163:	41 0f b6 4e 02       	movzbl 0x2(%r14),%ecx
  676168:	c1 e2 06             	shl    $0x6,%edx
  67616b:	83 e1 3f             	and    $0x3f,%ecx
  67616e:	09 d1                	or     %edx,%ecx
  676170:	40 80 fe f0          	cmp    $0xf0,%sil
  676174:	72 28                	jb     67619e <<gpui_canvas::text::planner::Planner>::shape+0x213e>
  676176:	41 0f b6 76 03       	movzbl 0x3(%r14),%esi
  67617b:	49 83 c6 04          	add    $0x4,%r14
  67617f:	83 e0 07             	and    $0x7,%eax
  676182:	c1 e0 12             	shl    $0x12,%eax
  676185:	c1 e1 06             	shl    $0x6,%ecx
  676188:	83 e6 3f             	and    $0x3f,%esi
  67618b:	09 ce                	or     %ecx,%esi
  67618d:	09 c6                	or     %eax,%esi
  67618f:	eb 1f                	jmp    6761b0 <<gpui_canvas::text::planner::Planner>::shape+0x2150>
  676191:	49 83 c6 02          	add    $0x2,%r14
  676195:	c1 e0 06             	shl    $0x6,%eax
  676198:	09 d0                	or     %edx,%eax
  67619a:	89 c6                	mov    %eax,%esi
  67619c:	eb 12                	jmp    6761b0 <<gpui_canvas::text::planner::Planner>::shape+0x2150>
  67619e:	49 83 c6 03          	add    $0x3,%r14
  6761a2:	c1 e0 0c             	shl    $0xc,%eax
  6761a5:	09 c1                	or     %eax,%ecx
  6761a7:	89 ce                	mov    %ecx,%esi
  6761a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  6761b0:	48 8d 3d 81 97 10 00 	lea    0x109781(%rip),%rdi        # 77f938 <anon.1a3692c52bba9218a112fc8e64fef457.3.llvm.8970656708749461829+0x388>
  6761b7:	ff 15 f3 42 11 00    	call   *0x1142f3(%rip)        # 78a4b0 <_DYNAMIC+0x730>
  6761bd:	84 c0                	test   %al,%al
  6761bf:	0f 85 6b ff ff ff    	jne    676130 <<gpui_canvas::text::planner::Planner>::shape+0x20d0>
  6761c5:	e9 fa 0e 00 00       	jmp    6770c4 <<gpui_canvas::text::planner::Planner>::shape+0x3064>
  6761ca:	31 c0                	xor    %eax,%eax
  6761cc:	0f 57 c0             	xorps  %xmm0,%xmm0
  6761cf:	f3 0f 10 4c 24 08    	movss  0x8(%rsp),%xmm1
  6761d5:	0f 2e c8             	ucomiss %xmm0,%xmm1
  6761d8:	4c 8b b4 24 e8 01 00 	mov    0x1e8(%rsp),%r14
  6761df:	00 
  6761e0:	f3 0f 10 84 24 c4 01 	movss  0x1c4(%rsp),%xmm0
  6761e7:	00 00 
  6761e9:	0f 85 d5 0e 00 00    	jne    6770c4 <<gpui_canvas::text::planner::Planner>::shape+0x3064>
  6761ef:	0f 8b e0 f6 ff ff    	jnp    6758d5 <<gpui_canvas::text::planner::Planner>::shape+0x1875>
  6761f5:	e9 ca 0e 00 00       	jmp    6770c4 <<gpui_canvas::text::planner::Planner>::shape+0x3064>
  6761fa:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  6761ff:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  676206:	00 
  676207:	48 89 8c 24 20 01 00 	mov    %rcx,0x120(%rsp)
  67620e:	00 
  67620f:	e9 3f f7 ff ff       	jmp    675953 <<gpui_canvas::text::planner::Planner>::shape+0x18f3>
  676214:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
  67621b:	00 
  67621c:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
  676223:	00 
  676224:	e8 77 1e 00 00       	call   6780a0 <<core::iter::adapters::flatten::FlattenCompat<core::iter::adapters::map::Map<core::ops::range::Range<u32>, <parley::layout::run::Run<()>>::glyph_source_ranges::{closure#0}>, core::iter::sources::repeat_n::RepeatN<core::ops::range::Range<usize>>> as core::iter::traits::iterator::Iterator>::next>
  676229:	48 83 bc 24 88 00 00 	cmpq   $0x0,0x88(%rsp)
  676230:	00 00 
  676232:	0f 85 b1 0d 00 00    	jne    676fe9 <<gpui_canvas::text::planner::Planner>::shape+0x2f89>
  676238:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
  67623f:	00 
  676240:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  676244:	0f 84 bb f1 ff ff    	je     675405 <<gpui_canvas::text::planner::Planner>::shape+0x13a5>
  67624a:	48 8b 8c 24 00 01 00 	mov    0x100(%rsp),%rcx
  676251:	00 
  676252:	48 3b 4c 24 30       	cmp    0x30(%rsp),%rcx
  676257:	48 8b 8c 24 10 01 00 	mov    0x110(%rsp),%rcx
  67625e:	00 
  67625f:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  676264:	75 0f                	jne    676275 <<gpui_canvas::text::planner::Planner>::shape+0x2215>
  676266:	31 db                	xor    %ebx,%ebx
  676268:	45 31 f6             	xor    %r14d,%r14d
  67626b:	48 8b b4 24 48 02 00 	mov    0x248(%rsp),%rsi
  676272:	00 
  676273:	eb 6d                	jmp    6762e2 <<gpui_canvas::text::planner::Planner>::shape+0x2282>
  676275:	48 8b bc 24 e8 02 00 	mov    0x2e8(%rsp),%rdi
  67627c:	00 
  67627d:	48 85 ff             	test   %rdi,%rdi
  676280:	48 8b b4 24 48 02 00 	mov    0x248(%rsp),%rsi
  676287:	00 
  676288:	48 0f 44 fe          	cmove  %rsi,%rdi
  67628c:	48 8b 1f             	mov    (%rdi),%rbx
  67628f:	4c 8b 77 08          	mov    0x8(%rdi),%r14
  676293:	4c 39 f3             	cmp    %r14,%rbx
  676296:	0f 87 4d 0d 00 00    	ja     676fe9 <<gpui_canvas::text::planner::Planner>::shape+0x2f89>
  67629c:	48 85 db             	test   %rbx,%rbx
  67629f:	74 10                	je     6762b1 <<gpui_canvas::text::planner::Planner>::shape+0x2251>
  6762a1:	48 39 cb             	cmp    %rcx,%rbx
  6762a4:	73 0f                	jae    6762b5 <<gpui_canvas::text::planner::Planner>::shape+0x2255>
  6762a6:	80 3c 1a bf          	cmpb   $0xbf,(%rdx,%rbx,1)
  6762aa:	7f 12                	jg     6762be <<gpui_canvas::text::planner::Planner>::shape+0x225e>
  6762ac:	e9 38 0d 00 00       	jmp    676fe9 <<gpui_canvas::text::planner::Planner>::shape+0x2f89>
  6762b1:	31 db                	xor    %ebx,%ebx
  6762b3:	eb 09                	jmp    6762be <<gpui_canvas::text::planner::Planner>::shape+0x225e>
  6762b5:	48 89 cb             	mov    %rcx,%rbx
  6762b8:	0f 85 2b 0d 00 00    	jne    676fe9 <<gpui_canvas::text::planner::Planner>::shape+0x2f89>
  6762be:	4d 85 f6             	test   %r14,%r14
  6762c1:	74 11                	je     6762d4 <<gpui_canvas::text::planner::Planner>::shape+0x2274>
  6762c3:	49 39 ce             	cmp    %rcx,%r14
  6762c6:	73 11                	jae    6762d9 <<gpui_canvas::text::planner::Planner>::shape+0x2279>
  6762c8:	42 80 3c 32 c0       	cmpb   $0xc0,(%rdx,%r14,1)
  6762cd:	7d 13                	jge    6762e2 <<gpui_canvas::text::planner::Planner>::shape+0x2282>
  6762cf:	e9 15 0d 00 00       	jmp    676fe9 <<gpui_canvas::text::planner::Planner>::shape+0x2f89>
  6762d4:	45 31 f6             	xor    %r14d,%r14d
  6762d7:	eb 09                	jmp    6762e2 <<gpui_canvas::text::planner::Planner>::shape+0x2282>
  6762d9:	49 89 ce             	mov    %rcx,%r14
  6762dc:	0f 85 07 0d 00 00    	jne    676fe9 <<gpui_canvas::text::planner::Planner>::shape+0x2f89>
  6762e2:	8b 8c 24 f8 00 00 00 	mov    0xf8(%rsp),%ecx
  6762e9:	89 4c 24 60          	mov    %ecx,0x60(%rsp)
  6762ed:	0f b6 ae 8c 00 00 00 	movzbl 0x8c(%rsi),%ebp
  6762f4:	4c 8b bc 24 60 01 00 	mov    0x160(%rsp),%r15
  6762fb:	00 
  6762fc:	49 39 c7             	cmp    %rax,%r15
  6762ff:	75 0e                	jne    67630f <<gpui_canvas::text::planner::Planner>::shape+0x22af>
  676301:	48 8d bc 24 50 01 00 	lea    0x150(%rsp),%rdi
  676308:	00 
  676309:	ff 15 19 3f 11 00    	call   *0x113f19(%rip)        # 78a228 <_DYNAMIC+0x4a8>
  67630f:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  676314:	01 c3                	add    %eax,%ebx
  676316:	41 01 c6             	add    %eax,%r14d
  676319:	40 80 e5 01          	and    $0x1,%bpl
  67631d:	48 8b 84 24 58 01 00 	mov    0x158(%rsp),%rax
  676324:	00 
  676325:	4b 8d 0c 7f          	lea    (%r15,%r15,2),%rcx
  676329:	89 1c c8             	mov    %ebx,(%rax,%rcx,8)
  67632c:	44 89 74 c8 04       	mov    %r14d,0x4(%rax,%rcx,8)
  676331:	48 8b 94 24 f0 02 00 	mov    0x2f0(%rsp),%rdx
  676338:	00 
  676339:	89 54 c8 08          	mov    %edx,0x8(%rax,%rcx,8)
  67633d:	8b 54 24 60          	mov    0x60(%rsp),%edx
  676341:	89 54 c8 0c          	mov    %edx,0xc(%rax,%rcx,8)
  676345:	48 8b 94 24 58 02 00 	mov    0x258(%rsp),%rdx
  67634c:	00 
  67634d:	89 54 c8 10          	mov    %edx,0x10(%rax,%rcx,8)
  676351:	48 8b 94 24 60 02 00 	mov    0x260(%rsp),%rdx
  676358:	00 
  676359:	88 54 c8 14          	mov    %dl,0x14(%rax,%rcx,8)
  67635d:	40 88 6c c8 15       	mov    %bpl,0x15(%rax,%rcx,8)
  676362:	49 ff c7             	inc    %r15
  676365:	4c 89 bc 24 60 01 00 	mov    %r15,0x160(%rsp)
  67636c:	00 
  67636d:	e9 93 f0 ff ff       	jmp    675405 <<gpui_canvas::text::planner::Planner>::shape+0x13a5>
  676372:	48 8b 84 24 08 03 00 	mov    0x308(%rsp),%rax
  676379:	00 
  67637a:	48 39 84 24 c8 00 00 	cmp    %rax,0xc8(%rsp)
  676381:	00 
  676382:	48 8b 6c 24 30       	mov    0x30(%rsp),%rbp
  676387:	48 8b 9c 24 00 01 00 	mov    0x100(%rsp),%rbx
  67638e:	00 
  67638f:	0f 85 02 ec ff ff    	jne    674f97 <<gpui_canvas::text::planner::Planner>::shape+0xf37>
  676395:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  67639c:	00 ff 
  67639e:	0f 84 d9 06 00 00    	je     676a7d <<gpui_canvas::text::planner::Planner>::shape+0x2a1d>
  6763a4:	48 83 bc 24 80 01 00 	cmpq   $0xffffffffffffffff,0x180(%rsp)
  6763ab:	00 ff 
  6763ad:	0f 84 ca 06 00 00    	je     676a7d <<gpui_canvas::text::planner::Planner>::shape+0x2a1d>
  6763b3:	48 89 ac 24 88 00 00 	mov    %rbp,0x88(%rsp)
  6763ba:	00 
  6763bb:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
  6763c1:	f3 0f 11 84 24 e0 00 	movss  %xmm0,0xe0(%rsp)
  6763c8:	00 00 
  6763ca:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  6763cf:	48 89 84 24 40 03 00 	mov    %rax,0x340(%rsp)
  6763d6:	00 
  6763d7:	48 8d 84 24 e0 00 00 	lea    0xe0(%rsp),%rax
  6763de:	00 
  6763df:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
  6763e6:	00 
  6763e7:	48 8d 84 24 88 00 00 	lea    0x88(%rsp),%rax
  6763ee:	00 
  6763ef:	48 89 84 24 50 03 00 	mov    %rax,0x350(%rsp)
  6763f6:	00 
  6763f7:	48 8d 84 24 80 01 00 	lea    0x180(%rsp),%rax
  6763fe:	00 
  6763ff:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
  676406:	00 
  676407:	48 03 9c 24 48 01 00 	add    0x148(%rsp),%rbx
  67640e:	00 
  67640f:	48 c7 84 24 10 07 00 	movq   $0x0,0x710(%rsp)
  676416:	00 00 00 00 00 
  67641b:	48 c7 84 24 18 07 00 	movq   $0x8,0x718(%rsp)
  676422:	00 08 00 00 00 
  676427:	48 c7 84 24 20 07 00 	movq   $0x0,0x720(%rsp)
  67642e:	00 00 00 00 00 
  676433:	c7 84 24 30 07 00 00 	movl   $0xffffffff,0x730(%rsp)
  67643a:	ff ff ff ff 
  67643e:	4c 8b 7c 24 10       	mov    0x10(%rsp),%r15
  676443:	4c 89 bc 24 38 07 00 	mov    %r15,0x738(%rsp)
  67644a:	00 
  67644b:	48 89 9c 24 40 07 00 	mov    %rbx,0x740(%rsp)
  676452:	00 
  676453:	48 c7 84 24 48 07 00 	movq   $0x0,0x748(%rsp)
  67645a:	00 00 00 00 00 
  67645f:	48 8d 05 42 96 10 00 	lea    0x109642(%rip),%rax        # 77faa8 <anon.1a3692c52bba9218a112fc8e64fef457.3.llvm.8970656708749461829+0x4f8>
  676466:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
  67646d:	00 
  67646e:	48 8d 05 eb b7 ff ff 	lea    -0x4815(%rip),%rax        # 671c60 <icu_segmenter::rule_segmenter_v1::empty_handle_complex::<icu_segmenter::scaffold::Utf8>>
  676475:	48 89 84 24 58 07 00 	mov    %rax,0x758(%rsp)
  67647c:	00 
  67647d:	4c 8b b4 24 10 01 00 	mov    0x110(%rsp),%r14
  676484:	00 
  676485:	4c 89 b4 24 60 07 00 	mov    %r14,0x760(%rsp)
  67648c:	00 
  67648d:	48 c7 84 24 68 07 00 	movq   $0x0,0x768(%rsp)
  676494:	00 00 00 00 00 
  676499:	48 c7 84 24 98 07 00 	movq   $0x0,0x798(%rsp)
  6764a0:	00 00 00 00 00 
  6764a5:	c6 84 24 a0 07 00 00 	movb   $0x0,0x7a0(%rsp)
  6764ac:	00 
  6764ad:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  6764b4:	00 
  6764b5:	e8 d6 a9 ff ff       	call   670e90 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  6764ba:	48 83 f8 01          	cmp    $0x1,%rax
  6764be:	0f 85 9b 01 00 00    	jne    67665f <<gpui_canvas::text::planner::Planner>::shape+0x25ff>
  6764c4:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  6764cb:	00 
  6764cc:	e8 bf a9 ff ff       	call   670e90 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  6764d1:	48 83 f8 01          	cmp    $0x1,%rax
  6764d5:	0f 85 84 01 00 00    	jne    67665f <<gpui_canvas::text::planner::Planner>::shape+0x25ff>
  6764db:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  6764e2:	00 
  6764e3:	e8 a8 a9 ff ff       	call   670e90 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  6764e8:	48 83 f8 01          	cmp    $0x1,%rax
  6764ec:	0f 85 6d 01 00 00    	jne    67665f <<gpui_canvas::text::planner::Planner>::shape+0x25ff>
  6764f2:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  6764f9:	00 
  6764fa:	e8 91 a9 ff ff       	call   670e90 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  6764ff:	48 83 f8 01          	cmp    $0x1,%rax
  676503:	0f 85 56 01 00 00    	jne    67665f <<gpui_canvas::text::planner::Planner>::shape+0x25ff>
  676509:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  676510:	00 
  676511:	e8 7a a9 ff ff       	call   670e90 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  676516:	48 83 f8 01          	cmp    $0x1,%rax
  67651a:	0f 85 3f 01 00 00    	jne    67665f <<gpui_canvas::text::planner::Planner>::shape+0x25ff>
  676520:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  676527:	00 
  676528:	e8 63 a9 ff ff       	call   670e90 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  67652d:	48 83 f8 01          	cmp    $0x1,%rax
  676531:	0f 85 28 01 00 00    	jne    67665f <<gpui_canvas::text::planner::Planner>::shape+0x25ff>
  676537:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  67653e:	00 
  67653f:	e8 4c a9 ff ff       	call   670e90 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  676544:	48 83 f8 01          	cmp    $0x1,%rax
  676548:	0f 85 11 01 00 00    	jne    67665f <<gpui_canvas::text::planner::Planner>::shape+0x25ff>
  67654e:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  676555:	00 
  676556:	e8 35 a9 ff ff       	call   670e90 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  67655b:	a8 01                	test   $0x1,%al
  67655d:	0f 84 fc 00 00 00    	je     67665f <<gpui_canvas::text::planner::Planner>::shape+0x25ff>
  676563:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  67656a:	00 
  67656b:	e8 20 a9 ff ff       	call   670e90 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  676570:	48 83 f8 01          	cmp    $0x1,%rax
  676574:	0f 85 e5 00 00 00    	jne    67665f <<gpui_canvas::text::planner::Planner>::shape+0x25ff>
  67657a:	48 8b b4 24 10 07 00 	mov    0x710(%rsp),%rsi
  676581:	00 
  676582:	48 85 f6             	test   %rsi,%rsi
  676585:	74 17                	je     67659e <<gpui_canvas::text::planner::Planner>::shape+0x253e>
  676587:	48 8b bc 24 18 07 00 	mov    0x718(%rsp),%rdi
  67658e:	00 
  67658f:	48 c1 e6 03          	shl    $0x3,%rsi
  676593:	ba 08 00 00 00       	mov    $0x8,%edx
  676598:	ff 15 1a 3a 11 00    	call   *0x113a1a(%rip)        # 789fb8 <_DYNAMIC+0x238>
  67659e:	48 c7 84 24 10 07 00 	movq   $0x0,0x710(%rsp)
  6765a5:	00 00 00 00 00 
  6765aa:	48 c7 84 24 18 07 00 	movq   $0x8,0x718(%rsp)
  6765b1:	00 08 00 00 00 
  6765b6:	48 c7 84 24 20 07 00 	movq   $0x0,0x720(%rsp)
  6765bd:	00 00 00 00 00 
  6765c2:	c7 84 24 30 07 00 00 	movl   $0xffffffff,0x730(%rsp)
  6765c9:	ff ff ff ff 
  6765cd:	4c 89 bc 24 38 07 00 	mov    %r15,0x738(%rsp)
  6765d4:	00 
  6765d5:	48 89 9c 24 40 07 00 	mov    %rbx,0x740(%rsp)
  6765dc:	00 
  6765dd:	48 c7 84 24 48 07 00 	movq   $0x0,0x748(%rsp)
  6765e4:	00 00 00 00 00 
  6765e9:	48 8d 05 b8 94 10 00 	lea    0x1094b8(%rip),%rax        # 77faa8 <anon.1a3692c52bba9218a112fc8e64fef457.3.llvm.8970656708749461829+0x4f8>
  6765f0:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
  6765f7:	00 
  6765f8:	48 8d 05 61 b6 ff ff 	lea    -0x499f(%rip),%rax        # 671c60 <icu_segmenter::rule_segmenter_v1::empty_handle_complex::<icu_segmenter::scaffold::Utf8>>
  6765ff:	48 89 84 24 58 07 00 	mov    %rax,0x758(%rsp)
  676606:	00 
  676607:	4c 89 b4 24 60 07 00 	mov    %r14,0x760(%rsp)
  67660e:	00 
  67660f:	48 c7 84 24 68 07 00 	movq   $0x0,0x768(%rsp)
  676616:	00 00 00 00 00 
  67661b:	48 c7 84 24 98 07 00 	movq   $0x0,0x798(%rsp)
  676622:	00 00 00 00 00 
  676627:	c6 84 24 a0 07 00 00 	movb   $0x0,0x7a0(%rsp)
  67662e:	00 
  67662f:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  676634:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
  67663b:	00 
  67663c:	f3 0f 10 05 88 71 9a 	movss  -0x658e78(%rip),%xmm0        # 1d7cc <GCC_except_table0+0x24>
  676643:	ff 
  676644:	48 8d 94 24 40 03 00 	lea    0x340(%rsp),%rdx
  67664b:	00 
  67664c:	e8 4f 15 ff ff       	call   667ba0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>>
  676651:	83 f8 ff             	cmp    $0xffffffff,%eax
  676654:	0f 84 23 04 00 00    	je     676a7d <<gpui_canvas::text::planner::Planner>::shape+0x2a1d>
  67665a:	e9 6d 0f 00 00       	jmp    6775cc <<gpui_canvas::text::planner::Planner>::shape+0x356c>
  67665f:	48 8b b4 24 10 07 00 	mov    0x710(%rsp),%rsi
  676666:	00 
  676667:	48 85 f6             	test   %rsi,%rsi
  67666a:	74 17                	je     676683 <<gpui_canvas::text::planner::Planner>::shape+0x2623>
  67666c:	48 8b bc 24 18 07 00 	mov    0x718(%rsp),%rdi
  676673:	00 
  676674:	48 c1 e6 03          	shl    $0x3,%rsi
  676678:	ba 08 00 00 00       	mov    $0x8,%edx
  67667d:	ff 15 35 39 11 00    	call   *0x113935(%rip)        # 789fb8 <_DYNAMIC+0x238>
  676683:	48 c7 84 24 10 07 00 	movq   $0x0,0x710(%rsp)
  67668a:	00 00 00 00 00 
  67668f:	48 c7 84 24 18 07 00 	movq   $0x8,0x718(%rsp)
  676696:	00 08 00 00 00 
  67669b:	48 c7 84 24 20 07 00 	movq   $0x0,0x720(%rsp)
  6766a2:	00 00 00 00 00 
  6766a7:	c7 84 24 30 07 00 00 	movl   $0xffffffff,0x730(%rsp)
  6766ae:	ff ff ff ff 
  6766b2:	4c 89 bc 24 38 07 00 	mov    %r15,0x738(%rsp)
  6766b9:	00 
  6766ba:	48 89 9c 24 40 07 00 	mov    %rbx,0x740(%rsp)
  6766c1:	00 
  6766c2:	48 c7 84 24 48 07 00 	movq   $0x0,0x748(%rsp)
  6766c9:	00 00 00 00 00 
  6766ce:	48 8d 05 d3 93 10 00 	lea    0x1093d3(%rip),%rax        # 77faa8 <anon.1a3692c52bba9218a112fc8e64fef457.3.llvm.8970656708749461829+0x4f8>
  6766d5:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
  6766dc:	00 
  6766dd:	48 8d 05 7c b5 ff ff 	lea    -0x4a84(%rip),%rax        # 671c60 <icu_segmenter::rule_segmenter_v1::empty_handle_complex::<icu_segmenter::scaffold::Utf8>>
  6766e4:	48 89 84 24 58 07 00 	mov    %rax,0x758(%rsp)
  6766eb:	00 
  6766ec:	4c 89 b4 24 60 07 00 	mov    %r14,0x760(%rsp)
  6766f3:	00 
  6766f4:	48 c7 84 24 68 07 00 	movq   $0x0,0x768(%rsp)
  6766fb:	00 00 00 00 00 
  676700:	48 c7 84 24 98 07 00 	movq   $0x0,0x798(%rsp)
  676707:	00 00 00 00 00 
  67670c:	c6 84 24 a0 07 00 00 	movb   $0x0,0x7a0(%rsp)
  676713:	00 
  676714:	eb 42                	jmp    676758 <<gpui_canvas::text::planner::Planner>::shape+0x26f8>
  676716:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  67671d:	00 00 00 
  676720:	0f 28 84 24 00 01 00 	movaps 0x100(%rsp),%xmm0
  676727:	00 
  676728:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
  67672d:	48 8b 84 24 88 01 00 	mov    0x188(%rsp),%rax
  676734:	00 
  676735:	48 8d 0c 5b          	lea    (%rbx,%rbx,2),%rcx
  676739:	44 89 3c 88          	mov    %r15d,(%rax,%rcx,4)
  67673d:	0f 28 44 24 30       	movaps 0x30(%rsp),%xmm0
  676742:	f3 0f 11 44 88 04    	movss  %xmm0,0x4(%rax,%rcx,4)
  676748:	40 88 6c 88 08       	mov    %bpl,0x8(%rax,%rcx,4)
  67674d:	48 ff c3             	inc    %rbx
  676750:	48 89 9c 24 90 01 00 	mov    %rbx,0x190(%rsp)
  676757:	00 
  676758:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  67675f:	00 
  676760:	e8 2b a7 ff ff       	call   670e90 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  676765:	48 83 f8 01          	cmp    $0x1,%rax
  676769:	0f 85 ea 02 00 00    	jne    676a59 <<gpui_canvas::text::planner::Planner>::shape+0x29f9>
  67676f:	49 89 d6             	mov    %rdx,%r14
  676772:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  676777:	48 89 d6             	mov    %rdx,%rsi
  67677a:	ba 01 00 00 00       	mov    $0x1,%edx
  67677f:	e8 1c 87 00 00       	call   67eea0 <<parley::editing::cursor::Cursor>::from_byte_index::<()>>
  676784:	48 89 c3             	mov    %rax,%rbx
  676787:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
  67678e:	00 
  67678f:	80 e2 01             	and    $0x1,%dl
  676792:	88 94 24 a0 03 00 00 	mov    %dl,0x3a0(%rsp)
  676799:	4c 39 f0             	cmp    %r14,%rax
  67679c:	0f 85 ae 00 00 00    	jne    676850 <<gpui_canvas::text::planner::Planner>::shape+0x27f0>
  6767a2:	48 8d bc 24 c0 04 00 	lea    0x4c0(%rsp),%rdi
  6767a9:	00 
  6767aa:	48 8d b4 24 98 03 00 	lea    0x398(%rsp),%rsi
  6767b1:	00 
  6767b2:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  6767b7:	f3 0f 10 05 0d 70 9a 	movss  -0x658ff3(%rip),%xmm0        # 1d7cc <GCC_except_table0+0x24>
  6767be:	ff 
  6767bf:	e8 9c 87 00 00       	call   67ef60 <<parley::editing::cursor::Cursor>::geometry::<()>>
  6767c4:	f3 0f 10 84 24 e0 00 	movss  0xe0(%rsp),%xmm0
  6767cb:	00 00 
  6767cd:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
  6767d1:	f2 0f 58 84 24 c8 04 	addsd  0x4c8(%rsp),%xmm0
  6767d8:	00 00 
  6767da:	66 0f 28 8c 24 c0 04 	movapd 0x4c0(%rsp),%xmm1
  6767e1:	00 00 
  6767e3:	66 0f 28 94 24 d0 04 	movapd 0x4d0(%rsp),%xmm2
  6767ea:	00 00 
  6767ec:	66 0f 5c d1          	subpd  %xmm1,%xmm2
  6767f0:	66 0f 14 c8          	unpcklpd %xmm0,%xmm1
  6767f4:	66 0f 5a c9          	cvtpd2ps %xmm1,%xmm1
  6767f8:	66 0f 5a d2          	cvtpd2ps %xmm2,%xmm2
  6767fc:	66 0f 29 4c 24 30    	movapd %xmm1,0x30(%rsp)
  676802:	66 0f 29 94 24 10 01 	movapd %xmm2,0x110(%rsp)
  676809:	00 00 
  67680b:	66 0f 14 ca          	unpcklpd %xmm2,%xmm1
  67680f:	66 0f 54 0d e9 ec 9a 	andpd  -0x651317(%rip),%xmm1        # 25500 <anon.1508e9dce0c1a49d095b8c30671814b4.0.llvm.16300762181250184790+0x7e0>
  676816:	ff 
  676817:	66 0f 66 0d b1 e6 9a 	pcmpgtd -0x65194f(%rip),%xmm1        # 24ed0 <anon.1508e9dce0c1a49d095b8c30671814b4.0.llvm.16300762181250184790+0x1b0>
  67681e:	ff 
  67681f:	0f 50 c1             	movmskps %xmm1,%eax
  676822:	85 c0                	test   %eax,%eax
  676824:	0f 85 73 07 00 00    	jne    676f9d <<gpui_canvas::text::planner::Planner>::shape+0x2f3d>
  67682a:	f2 0f 5a c0          	cvtsd2ss %xmm0,%xmm0
  67682e:	f3 0f 11 44 24 10    	movss  %xmm0,0x10(%rsp)
  676834:	0f 28 84 24 10 01 00 	movaps 0x110(%rsp),%xmm0
  67683b:	00 
  67683c:	0f c6 c0 55          	shufps $0x55,%xmm0,%xmm0
  676840:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
  676845:	eb 09                	jmp    676850 <<gpui_canvas::text::planner::Planner>::shape+0x27f0>
  676847:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  67684e:	00 00 
  676850:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  676855:	4c 89 f6             	mov    %r14,%rsi
  676858:	31 d2                	xor    %edx,%edx
  67685a:	e8 41 86 00 00       	call   67eea0 <<parley::editing::cursor::Cursor>::from_byte_index::<()>>
  67685f:	48 89 c5             	mov    %rax,%rbp
  676862:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
  676869:	00 
  67686a:	80 e2 01             	and    $0x1,%dl
  67686d:	88 94 24 a0 03 00 00 	mov    %dl,0x3a0(%rsp)
  676874:	4c 39 f0             	cmp    %r14,%rax
  676877:	0f 85 23 01 00 00    	jne    6769a0 <<gpui_canvas::text::planner::Planner>::shape+0x2940>
  67687d:	48 8d bc 24 c0 04 00 	lea    0x4c0(%rsp),%rdi
  676884:	00 
  676885:	48 8d b4 24 98 03 00 	lea    0x398(%rsp),%rsi
  67688c:	00 
  67688d:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  676892:	f3 0f 10 05 32 6f 9a 	movss  -0x6590ce(%rip),%xmm0        # 1d7cc <GCC_except_table0+0x24>
  676899:	ff 
  67689a:	e8 c1 86 00 00       	call   67ef60 <<parley::editing::cursor::Cursor>::geometry::<()>>
  67689f:	f3 0f 10 84 24 e0 00 	movss  0xe0(%rsp),%xmm0
  6768a6:	00 00 
  6768a8:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
  6768ac:	f2 0f 58 84 24 c8 04 	addsd  0x4c8(%rsp),%xmm0
  6768b3:	00 00 
  6768b5:	66 0f 28 8c 24 c0 04 	movapd 0x4c0(%rsp),%xmm1
  6768bc:	00 00 
  6768be:	66 0f 28 94 24 d0 04 	movapd 0x4d0(%rsp),%xmm2
  6768c5:	00 00 
  6768c7:	66 0f 5c d1          	subpd  %xmm1,%xmm2
  6768cb:	66 0f 14 c8          	unpcklpd %xmm0,%xmm1
  6768cf:	66 0f 5a c9          	cvtpd2ps %xmm1,%xmm1
  6768d3:	66 0f 5a c2          	cvtpd2ps %xmm2,%xmm0
  6768d7:	66 0f 14 c8          	unpcklpd %xmm0,%xmm1
  6768db:	66 0f 29 8c 24 00 01 	movapd %xmm1,0x100(%rsp)
  6768e2:	00 00 
  6768e4:	66 0f 28 c1          	movapd %xmm1,%xmm0
  6768e8:	66 0f 54 05 10 ec 9a 	andpd  -0x6513f0(%rip),%xmm0        # 25500 <anon.1508e9dce0c1a49d095b8c30671814b4.0.llvm.16300762181250184790+0x7e0>
  6768ef:	ff 
  6768f0:	66 0f 66 05 d8 e5 9a 	pcmpgtd -0x651a28(%rip),%xmm0        # 24ed0 <anon.1508e9dce0c1a49d095b8c30671814b4.0.llvm.16300762181250184790+0x1b0>
  6768f7:	ff 
  6768f8:	0f 50 c0             	movmskps %xmm0,%eax
  6768fb:	85 c0                	test   %eax,%eax
  6768fd:	0f 85 9a 06 00 00    	jne    676f9d <<gpui_canvas::text::planner::Planner>::shape+0x2f3d>
  676903:	44 8b bc 24 88 00 00 	mov    0x88(%rsp),%r15d
  67690a:	00 
  67690b:	45 01 f7             	add    %r14d,%r15d
  67690e:	4c 39 f3             	cmp    %r14,%rbx
  676911:	0f 85 09 01 00 00    	jne    676a20 <<gpui_canvas::text::planner::Planner>::shape+0x29c0>
  676917:	0f 28 44 24 30       	movaps 0x30(%rsp),%xmm0
  67691c:	0f 28 8c 24 00 01 00 	movaps 0x100(%rsp),%xmm1
  676923:	00 
  676924:	0f 2e c1             	ucomiss %xmm1,%xmm0
  676927:	0f 85 87 00 00 00    	jne    6769b4 <<gpui_canvas::text::planner::Planner>::shape+0x2954>
  67692d:	0f 8a 81 00 00 00    	jp     6769b4 <<gpui_canvas::text::planner::Planner>::shape+0x2954>
  676933:	0f 28 c1             	movaps %xmm1,%xmm0
  676936:	0f c6 c1 55          	shufps $0x55,%xmm1,%xmm0
  67693a:	f3 0f 10 54 24 10    	movss  0x10(%rsp),%xmm2
  676940:	0f 2e d0             	ucomiss %xmm0,%xmm2
  676943:	75 6f                	jne    6769b4 <<gpui_canvas::text::planner::Planner>::shape+0x2954>
  676945:	7a 6d                	jp     6769b4 <<gpui_canvas::text::planner::Planner>::shape+0x2954>
  676947:	0f 28 c1             	movaps %xmm1,%xmm0
  67694a:	66 0f 15 c1          	unpckhpd %xmm1,%xmm0
  67694e:	0f 28 94 24 10 01 00 	movaps 0x110(%rsp),%xmm2
  676955:	00 
  676956:	0f 2e d0             	ucomiss %xmm0,%xmm2
  676959:	75 59                	jne    6769b4 <<gpui_canvas::text::planner::Planner>::shape+0x2954>
  67695b:	7a 57                	jp     6769b4 <<gpui_canvas::text::planner::Planner>::shape+0x2954>
  67695d:	0f 28 c1             	movaps %xmm1,%xmm0
  676960:	0f c6 c1 ff          	shufps $0xff,%xmm1,%xmm0
  676964:	0f 28 4c 24 60       	movaps 0x60(%rsp),%xmm1
  676969:	0f 2e c8             	ucomiss %xmm0,%xmm1
  67696c:	75 46                	jne    6769b4 <<gpui_canvas::text::planner::Planner>::shape+0x2954>
  67696e:	7a 44                	jp     6769b4 <<gpui_canvas::text::planner::Planner>::shape+0x2954>
  676970:	48 8b 9c 24 90 01 00 	mov    0x190(%rsp),%rbx
  676977:	00 
  676978:	40 b5 03             	mov    $0x3,%bpl
  67697b:	48 3b 9c 24 80 01 00 	cmp    0x180(%rsp),%rbx
  676982:	00 
  676983:	0f 85 a4 fd ff ff    	jne    67672d <<gpui_canvas::text::planner::Planner>::shape+0x26cd>
  676989:	48 8d bc 24 80 01 00 	lea    0x180(%rsp),%rdi
  676990:	00 
  676991:	ff 15 99 38 11 00    	call   *0x113899(%rip)        # 78a230 <_DYNAMIC+0x4b0>
  676997:	e9 91 fd ff ff       	jmp    67672d <<gpui_canvas::text::planner::Planner>::shape+0x26cd>
  67699c:	0f 1f 40 00          	nopl   0x0(%rax)
  6769a0:	4c 39 f3             	cmp    %r14,%rbx
  6769a3:	0f 85 af fd ff ff    	jne    676758 <<gpui_canvas::text::planner::Planner>::shape+0x26f8>
  6769a9:	44 8b bc 24 88 00 00 	mov    0x88(%rsp),%r15d
  6769b0:	00 
  6769b1:	45 01 f7             	add    %r14d,%r15d
  6769b4:	48 8b 9c 24 90 01 00 	mov    0x190(%rsp),%rbx
  6769bb:	00 
  6769bc:	48 3b 9c 24 80 01 00 	cmp    0x180(%rsp),%rbx
  6769c3:	00 
  6769c4:	75 0e                	jne    6769d4 <<gpui_canvas::text::planner::Planner>::shape+0x2974>
  6769c6:	48 8d bc 24 80 01 00 	lea    0x180(%rsp),%rdi
  6769cd:	00 
  6769ce:	ff 15 5c 38 11 00    	call   *0x11385c(%rip)        # 78a230 <_DYNAMIC+0x4b0>
  6769d4:	48 8b 84 24 88 01 00 	mov    0x188(%rsp),%rax
  6769db:	00 
  6769dc:	48 8d 0c 5b          	lea    (%rbx,%rbx,2),%rcx
  6769e0:	44 89 3c 88          	mov    %r15d,(%rax,%rcx,4)
  6769e4:	0f 28 44 24 30       	movaps 0x30(%rsp),%xmm0
  6769e9:	f3 0f 11 44 88 04    	movss  %xmm0,0x4(%rax,%rcx,4)
  6769ef:	c6 44 88 08 01       	movb   $0x1,0x8(%rax,%rcx,4)
  6769f4:	48 ff c3             	inc    %rbx
  6769f7:	48 89 9c 24 90 01 00 	mov    %rbx,0x190(%rsp)
  6769fe:	00 
  6769ff:	4c 39 f5             	cmp    %r14,%rbp
  676a02:	0f 85 50 fd ff ff    	jne    676758 <<gpui_canvas::text::planner::Planner>::shape+0x26f8>
  676a08:	40 b5 02             	mov    $0x2,%bpl
  676a0b:	48 3b 9c 24 80 01 00 	cmp    0x180(%rsp),%rbx
  676a12:	00 
  676a13:	0f 85 07 fd ff ff    	jne    676720 <<gpui_canvas::text::planner::Planner>::shape+0x26c0>
  676a19:	eb 1e                	jmp    676a39 <<gpui_canvas::text::planner::Planner>::shape+0x29d9>
  676a1b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  676a20:	48 8b 9c 24 90 01 00 	mov    0x190(%rsp),%rbx
  676a27:	00 
  676a28:	40 b5 02             	mov    $0x2,%bpl
  676a2b:	48 3b 9c 24 80 01 00 	cmp    0x180(%rsp),%rbx
  676a32:	00 
  676a33:	0f 85 e7 fc ff ff    	jne    676720 <<gpui_canvas::text::planner::Planner>::shape+0x26c0>
  676a39:	48 8d bc 24 80 01 00 	lea    0x180(%rsp),%rdi
  676a40:	00 
  676a41:	ff 15 e9 37 11 00    	call   *0x1137e9(%rip)        # 78a230 <_DYNAMIC+0x4b0>
  676a47:	0f 28 84 24 00 01 00 	movaps 0x100(%rsp),%xmm0
  676a4e:	00 
  676a4f:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
  676a54:	e9 d4 fc ff ff       	jmp    67672d <<gpui_canvas::text::planner::Planner>::shape+0x26cd>
  676a59:	48 8b b4 24 10 07 00 	mov    0x710(%rsp),%rsi
  676a60:	00 
  676a61:	48 85 f6             	test   %rsi,%rsi
  676a64:	74 17                	je     676a7d <<gpui_canvas::text::planner::Planner>::shape+0x2a1d>
  676a66:	48 8b bc 24 18 07 00 	mov    0x718(%rsp),%rdi
  676a6d:	00 
  676a6e:	48 c1 e6 03          	shl    $0x3,%rsi
  676a72:	ba 08 00 00 00       	mov    $0x8,%edx
  676a77:	ff 15 3b 35 11 00    	call   *0x11353b(%rip)        # 789fb8 <_DYNAMIC+0x238>
  676a7d:	0f 28 9c 24 80 02 00 	movaps 0x280(%rsp),%xmm3
  676a84:	00 
  676a85:	0f 28 c3             	movaps %xmm3,%xmm0
  676a88:	f3 0f 5f 84 24 d4 00 	maxss  0xd4(%rsp),%xmm0
  676a8f:	00 00 
  676a91:	0f 28 c8             	movaps %xmm0,%xmm1
  676a94:	f3 0f c2 c8 03       	cmpunordss %xmm0,%xmm1
  676a99:	0f 28 d1             	movaps %xmm1,%xmm2
  676a9c:	0f 55 d0             	andnps %xmm0,%xmm2
  676a9f:	0f 54 cb             	andps  %xmm3,%xmm1
  676aa2:	0f 56 ca             	orps   %xmm2,%xmm1
  676aa5:	0f 29 8c 24 80 02 00 	movaps %xmm1,0x280(%rsp)
  676aac:	00 
  676aad:	48 8b 04 24          	mov    (%rsp),%rax
  676ab1:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
  676ab7:	f3 0f 58 80 30 0a 00 	addss  0xa30(%rax),%xmm0
  676abe:	00 
  676abf:	f3 0f 11 44 24 1c    	movss  %xmm0,0x1c(%rsp)
  676ac5:	80 7c 24 4c 00       	cmpb   $0x0,0x4c(%rsp)
  676aca:	48 8b 84 24 20 03 00 	mov    0x320(%rsp),%rax
  676ad1:	00 
  676ad2:	8b b4 24 80 00 00 00 	mov    0x80(%rsp),%esi
  676ad9:	48 8b 94 24 18 03 00 	mov    0x318(%rsp),%rdx
  676ae0:	00 
  676ae1:	0f 84 d1 db ff ff    	je     6746b8 <<gpui_canvas::text::planner::Planner>::shape+0x658>
  676ae7:	e9 6c 05 00 00       	jmp    677058 <<gpui_canvas::text::planner::Planner>::shape+0x2ff8>
  676aec:	48 8b 0c 24          	mov    (%rsp),%rcx
  676af0:	48 8b 81 d8 09 00 00 	mov    0x9d8(%rcx),%rax
  676af7:	48 6b 89 e0 09 00 00 	imul   $0x70,0x9e0(%rcx),%rcx
  676afe:	70 
  676aff:	48 01 c1             	add    %rax,%rcx
  676b02:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
  676b09:	00 
  676b0a:	48 89 8c 24 18 07 00 	mov    %rcx,0x718(%rsp)
  676b11:	00 
  676b12:	48 c7 84 24 20 07 00 	movq   $0x0,0x720(%rsp)
  676b19:	00 00 00 00 00 
  676b1e:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  676b23:	48 89 84 24 28 07 00 	mov    %rax,0x728(%rsp)
  676b2a:	00 
  676b2b:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  676b32:	00 
  676b33:	31 f6                	xor    %esi,%esi
  676b35:	48 8d 94 24 e7 00 00 	lea    0xe7(%rsp),%rdx
  676b3c:	00 
  676b3d:	e8 7e d7 00 00       	call   6842c0 <<core::iter::adapters::map::Map<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineData>>, <parley::layout::layout::Layout<()>>::lines::{closure#0}>, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#3}> as core::iter::traits::iterator::Iterator>::fold::<usize, <core::iter::adapters::flatten::FlattenCompat<_, _>>::iter_fold::flatten<core::iter::adapters::filter_map::FilterMap<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}>, <parley::layout::line::Line<()>>::runs::{closure#0}>, usize, <core::iter::adapters::flatten::FlattenCompat<_, _> as core::iter::traits::iterator::Iterator>::count::count<core::iter::adapters::filter_map::FilterMap<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}>, <parley::layout::line::Line<()>>::runs::{closure#0}>>>::{closure#0}>>
  676b42:	48 83 f8 02          	cmp    $0x2,%rax
  676b46:	0f 82 17 e2 ff ff    	jb     674d63 <<gpui_canvas::text::planner::Planner>::shape+0xd03>
  676b4c:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
  676b53:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  676b5a:	00 ff 
  676b5c:	0f 84 84 e1 ff ff    	je     674ce6 <<gpui_canvas::text::planner::Planner>::shape+0xc86>
  676b62:	e9 fc e1 ff ff       	jmp    674d63 <<gpui_canvas::text::planner::Planner>::shape+0xd03>
  676b67:	c7 84 24 80 00 00 00 	movl   $0xffffffff,0x80(%rsp)
  676b6e:	ff ff ff ff 
  676b72:	e9 ac dd ff ff       	jmp    674923 <<gpui_canvas::text::planner::Planner>::shape+0x8c3>
  676b77:	44 89 d2             	mov    %r10d,%edx
  676b7a:	83 e2 1f             	and    $0x1f,%edx
  676b7d:	41 0f b6 79 01       	movzbl 0x1(%r9),%edi
  676b82:	83 e7 3f             	and    $0x3f,%edi
  676b85:	41 80 fa df          	cmp    $0xdf,%r10b
  676b89:	76 31                	jbe    676bbc <<gpui_canvas::text::planner::Planner>::shape+0x2b5c>
  676b8b:	41 0f b6 71 02       	movzbl 0x2(%r9),%esi
  676b90:	c1 e7 06             	shl    $0x6,%edi
  676b93:	83 e6 3f             	and    $0x3f,%esi
  676b96:	09 fe                	or     %edi,%esi
  676b98:	41 80 fa f0          	cmp    $0xf0,%r10b
  676b9c:	72 2c                	jb     676bca <<gpui_canvas::text::planner::Planner>::shape+0x2b6a>
  676b9e:	49 8d 59 04          	lea    0x4(%r9),%rbx
  676ba2:	45 0f b6 51 03       	movzbl 0x3(%r9),%r10d
  676ba7:	83 e2 07             	and    $0x7,%edx
  676baa:	c1 e2 12             	shl    $0x12,%edx
  676bad:	c1 e6 06             	shl    $0x6,%esi
  676bb0:	41 83 e2 3f          	and    $0x3f,%r10d
  676bb4:	41 09 f2             	or     %esi,%r10d
  676bb7:	41 09 d2             	or     %edx,%r10d
  676bba:	eb 1a                	jmp    676bd6 <<gpui_canvas::text::planner::Planner>::shape+0x2b76>
  676bbc:	49 8d 59 02          	lea    0x2(%r9),%rbx
  676bc0:	c1 e2 06             	shl    $0x6,%edx
  676bc3:	09 fa                	or     %edi,%edx
  676bc5:	41 89 d2             	mov    %edx,%r10d
  676bc8:	eb 0c                	jmp    676bd6 <<gpui_canvas::text::planner::Planner>::shape+0x2b76>
  676bca:	49 8d 59 03          	lea    0x3(%r9),%rbx
  676bce:	c1 e2 0c             	shl    $0xc,%edx
  676bd1:	09 d6                	or     %edx,%esi
  676bd3:	41 89 f2             	mov    %esi,%r10d
  676bd6:	49 8d 50 02          	lea    0x2(%r8),%rdx
  676bda:	4c 89 c1             	mov    %r8,%rcx
  676bdd:	48 89 c6             	mov    %rax,%rsi
  676be0:	4c 29 ce             	sub    %r9,%rsi
  676be3:	48 01 de             	add    %rbx,%rsi
  676be6:	41 83 fa 0a          	cmp    $0xa,%r10d
  676bea:	bf fe ff ff ff       	mov    $0xfffffffe,%edi
  676bef:	44 0f 44 d7          	cmove  %edi,%r10d
  676bf3:	44 89 94 24 80 00 00 	mov    %r10d,0x80(%rsp)
  676bfa:	00 
  676bfb:	4c 0f 44 da          	cmove  %rdx,%r11
  676bff:	c7 44 24 4c 00 00 00 	movl   $0x0,0x4c(%rsp)
  676c06:	00 
  676c07:	48 89 84 24 10 03 00 	mov    %rax,0x310(%rsp)
  676c0e:	00 
  676c0f:	48 89 f0             	mov    %rsi,%rax
  676c12:	4c 89 de             	mov    %r11,%rsi
  676c15:	48 89 5c 24 28       	mov    %rbx,0x28(%rsp)
  676c1a:	e9 0f dd ff ff       	jmp    67492e <<gpui_canvas::text::planner::Planner>::shape+0x8ce>
  676c1f:	b9 04 00 00 00       	mov    $0x4,%ecx
  676c24:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  676c2a:	48 8d bc 24 e8 00 00 	lea    0xe8(%rsp),%rdi
  676c31:	00 
  676c32:	48 89 da             	mov    %rbx,%rdx
  676c35:	e8 56 d2 fe ff       	call   663e90 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  676c3a:	e9 88 e2 ff ff       	jmp    674ec7 <<gpui_canvas::text::planner::Planner>::shape+0xe67>
  676c3f:	c7 84 24 90 00 00 00 	movl   $0x7,0x90(%rsp)
  676c46:	07 00 00 00 
  676c4a:	eb 0b                	jmp    676c57 <<gpui_canvas::text::planner::Planner>::shape+0x2bf7>
  676c4c:	c7 84 24 90 00 00 00 	movl   $0x4,0x90(%rsp)
  676c53:	04 00 00 00 
  676c57:	48 c7 84 24 88 00 00 	movq   $0xffffffffffffffff,0x88(%rsp)
  676c5e:	00 ff ff ff ff 
  676c63:	4c 8b 2c 24          	mov    (%rsp),%r13
  676c67:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
  676c6e:	00 
  676c6f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  676c73:	74 76                	je     676ceb <<gpui_canvas::text::planner::Planner>::shape+0x2c8b>
  676c75:	48 85 c0             	test   %rax,%rax
  676c78:	74 1b                	je     676c95 <<gpui_canvas::text::planner::Planner>::shape+0x2c35>
  676c7a:	48 8b bc 24 58 01 00 	mov    0x158(%rsp),%rdi
  676c81:	00 
  676c82:	48 c1 e0 03          	shl    $0x3,%rax
  676c86:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  676c8a:	ba 04 00 00 00       	mov    $0x4,%edx
  676c8f:	ff 15 23 33 11 00    	call   *0x113323(%rip)        # 789fb8 <_DYNAMIC+0x238>
  676c95:	48 8b 84 24 68 01 00 	mov    0x168(%rsp),%rax
  676c9c:	00 
  676c9d:	48 85 c0             	test   %rax,%rax
  676ca0:	74 1b                	je     676cbd <<gpui_canvas::text::planner::Planner>::shape+0x2c5d>
  676ca2:	48 8b bc 24 70 01 00 	mov    0x170(%rsp),%rdi
  676ca9:	00 
  676caa:	48 c1 e0 03          	shl    $0x3,%rax
  676cae:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  676cb2:	ba 04 00 00 00       	mov    $0x4,%edx
  676cb7:	ff 15 fb 32 11 00    	call   *0x1132fb(%rip)        # 789fb8 <_DYNAMIC+0x238>
  676cbd:	48 8b 84 24 80 01 00 	mov    0x180(%rsp),%rax
  676cc4:	00 
  676cc5:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  676cc9:	74 20                	je     676ceb <<gpui_canvas::text::planner::Planner>::shape+0x2c8b>
  676ccb:	48 85 c0             	test   %rax,%rax
  676cce:	74 1b                	je     676ceb <<gpui_canvas::text::planner::Planner>::shape+0x2c8b>
  676cd0:	48 8b bc 24 88 01 00 	mov    0x188(%rsp),%rdi
  676cd7:	00 
  676cd8:	48 c1 e0 02          	shl    $0x2,%rax
  676cdc:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  676ce0:	ba 04 00 00 00       	mov    $0x4,%edx
  676ce5:	ff 15 cd 32 11 00    	call   *0x1132cd(%rip)        # 789fb8 <_DYNAMIC+0x238>
  676ceb:	48 8b b4 24 e8 00 00 	mov    0xe8(%rsp),%rsi
  676cf2:	00 
  676cf3:	48 85 f6             	test   %rsi,%rsi
  676cf6:	74 17                	je     676d0f <<gpui_canvas::text::planner::Planner>::shape+0x2caf>
  676cf8:	48 8b bc 24 f0 00 00 	mov    0xf0(%rsp),%rdi
  676cff:	00 
  676d00:	48 c1 e6 04          	shl    $0x4,%rsi
  676d04:	ba 04 00 00 00       	mov    $0x4,%edx
  676d09:	ff 15 a9 32 11 00    	call   *0x1132a9(%rip)        # 789fb8 <_DYNAMIC+0x238>
  676d0f:	48 8b b4 24 a0 02 00 	mov    0x2a0(%rsp),%rsi
  676d16:	00 
  676d17:	48 83 fe fd          	cmp    $0xfffffffffffffffd,%rsi
  676d1b:	77 18                	ja     676d35 <<gpui_canvas::text::planner::Planner>::shape+0x2cd5>
  676d1d:	48 85 f6             	test   %rsi,%rsi
  676d20:	74 13                	je     676d35 <<gpui_canvas::text::planner::Planner>::shape+0x2cd5>
  676d22:	48 8b bc 24 a8 02 00 	mov    0x2a8(%rsp),%rdi
  676d29:	00 
  676d2a:	ba 01 00 00 00       	mov    $0x1,%edx
  676d2f:	ff 15 83 32 11 00    	call   *0x113283(%rip)        # 789fb8 <_DYNAMIC+0x238>
  676d35:	48 8b b4 24 b8 02 00 	mov    0x2b8(%rsp),%rsi
  676d3c:	00 
  676d3d:	48 83 fe fd          	cmp    $0xfffffffffffffffd,%rsi
  676d41:	77 18                	ja     676d5b <<gpui_canvas::text::planner::Planner>::shape+0x2cfb>
  676d43:	48 85 f6             	test   %rsi,%rsi
  676d46:	74 13                	je     676d5b <<gpui_canvas::text::planner::Planner>::shape+0x2cfb>
  676d48:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
  676d4f:	00 
  676d50:	ba 01 00 00 00       	mov    $0x1,%edx
  676d55:	ff 15 5d 32 11 00    	call   *0x11325d(%rip)        # 789fb8 <_DYNAMIC+0x238>
  676d5b:	48 8b b4 24 d0 02 00 	mov    0x2d0(%rsp),%rsi
  676d62:	00 
  676d63:	48 83 fe fd          	cmp    $0xfffffffffffffffd,%rsi
  676d67:	77 18                	ja     676d81 <<gpui_canvas::text::planner::Planner>::shape+0x2d21>
  676d69:	48 85 f6             	test   %rsi,%rsi
  676d6c:	74 13                	je     676d81 <<gpui_canvas::text::planner::Planner>::shape+0x2d21>
  676d6e:	48 8b bc 24 d8 02 00 	mov    0x2d8(%rsp),%rdi
  676d75:	00 
  676d76:	ba 01 00 00 00       	mov    $0x1,%edx
  676d7b:	ff 15 37 32 11 00    	call   *0x113237(%rip)        # 789fb8 <_DYNAMIC+0x238>
  676d81:	49 8d bd c8 08 00 00 	lea    0x8c8(%r13),%rdi
  676d88:	e8 33 b7 ff ff       	call   6724c0 <core::ptr::drop_glue::<parley::layout::layout::Layout<()>>>
  676d8d:	49 c7 85 c8 08 00 00 	movq   $0x0,0x8c8(%r13)
  676d94:	00 00 00 00 
  676d98:	49 c7 85 d0 08 00 00 	movq   $0x4,0x8d0(%r13)
  676d9f:	04 00 00 00 
  676da3:	0f 57 c0             	xorps  %xmm0,%xmm0
  676da6:	41 0f 11 85 d8 08 00 	movups %xmm0,0x8d8(%r13)
  676dad:	00 
  676dae:	49 c7 85 e8 08 00 00 	movq   $0x4,0x8e8(%r13)
  676db5:	04 00 00 00 
  676db9:	41 0f 11 85 f0 08 00 	movups %xmm0,0x8f0(%r13)
  676dc0:	00 
  676dc1:	49 c7 85 00 09 00 00 	movq   $0x8,0x900(%r13)
  676dc8:	08 00 00 00 
  676dcc:	41 0f 11 85 08 09 00 	movups %xmm0,0x908(%r13)
  676dd3:	00 
  676dd4:	49 c7 85 18 09 00 00 	movq   $0x8,0x918(%r13)
  676ddb:	08 00 00 00 
  676ddf:	41 0f 11 85 20 09 00 	movups %xmm0,0x920(%r13)
  676de6:	00 
  676de7:	49 c7 85 30 09 00 00 	movq   $0x4,0x930(%r13)
  676dee:	04 00 00 00 
  676df2:	41 0f 11 85 38 09 00 	movups %xmm0,0x938(%r13)
  676df9:	00 
  676dfa:	49 c7 85 48 09 00 00 	movq   $0x4,0x948(%r13)
  676e01:	04 00 00 00 
  676e05:	41 0f 11 85 50 09 00 	movups %xmm0,0x950(%r13)
  676e0c:	00 
  676e0d:	49 c7 85 60 09 00 00 	movq   $0x4,0x960(%r13)
  676e14:	04 00 00 00 
  676e18:	41 0f 11 85 68 09 00 	movups %xmm0,0x968(%r13)
  676e1f:	00 
  676e20:	49 c7 85 78 09 00 00 	movq   $0x8,0x978(%r13)
  676e27:	08 00 00 00 
  676e2b:	41 0f 11 85 80 09 00 	movups %xmm0,0x980(%r13)
  676e32:	00 
  676e33:	49 c7 85 90 09 00 00 	movq   $0x2,0x990(%r13)
  676e3a:	02 00 00 00 
  676e3e:	41 0f 11 85 98 09 00 	movups %xmm0,0x998(%r13)
  676e45:	00 
  676e46:	49 c7 85 a8 09 00 00 	movq   $0x4,0x9a8(%r13)
  676e4d:	04 00 00 00 
  676e51:	41 0f 11 85 b0 09 00 	movups %xmm0,0x9b0(%r13)
  676e58:	00 
  676e59:	49 c7 85 c0 09 00 00 	movq   $0x8,0x9c0(%r13)
  676e60:	08 00 00 00 
  676e64:	41 0f 11 85 c8 09 00 	movups %xmm0,0x9c8(%r13)
  676e6b:	00 
  676e6c:	49 c7 85 d8 09 00 00 	movq   $0x8,0x9d8(%r13)
  676e73:	08 00 00 00 
  676e77:	41 0f 11 85 e0 09 00 	movups %xmm0,0x9e0(%r13)
  676e7e:	00 
  676e7f:	49 c7 85 f0 09 00 00 	movq   $0x8,0x9f0(%r13)
  676e86:	08 00 00 00 
  676e8a:	41 0f 11 85 f8 09 00 	movups %xmm0,0x9f8(%r13)
  676e91:	00 
  676e92:	49 c7 85 08 0a 00 00 	movq   $0x4,0xa08(%r13)
  676e99:	04 00 00 00 
  676e9d:	41 0f 11 85 10 0a 00 	movups %xmm0,0xa10(%r13)
  676ea4:	00 
  676ea5:	41 c7 85 20 0a 00 00 	movl   $0x3f800000,0xa20(%r13)
  676eac:	00 00 80 3f 
  676eb0:	41 0f 11 85 24 0a 00 	movups %xmm0,0xa24(%r13)
  676eb7:	00 
  676eb8:	49 c7 85 32 0a 00 00 	movq   $0x0,0xa32(%r13)
  676ebf:	00 00 00 00 
  676ec3:	66 41 c7 85 3a 0a 00 	movw   $0xff01,0xa3a(%r13)
  676eca:	00 01 ff 
  676ecd:	41 c6 85 3c 0a 00 00 	movb   $0x0,0xa3c(%r13)
  676ed4:	00 
  676ed5:	48 8b 8c 24 b8 00 00 	mov    0xb8(%rsp),%rcx
  676edc:	00 
  676edd:	48 8b 84 24 38 03 00 	mov    0x338(%rsp),%rax
  676ee4:	00 
  676ee5:	48 89 48 30          	mov    %rcx,0x30(%rax)
  676ee9:	0f 10 84 24 88 00 00 	movups 0x88(%rsp),%xmm0
  676ef0:	00 
  676ef1:	0f 10 8c 24 98 00 00 	movups 0x98(%rsp),%xmm1
  676ef8:	00 
  676ef9:	0f 10 94 24 a8 00 00 	movups 0xa8(%rsp),%xmm2
  676f00:	00 
  676f01:	0f 11 50 20          	movups %xmm2,0x20(%rax)
  676f05:	0f 11 48 10          	movups %xmm1,0x10(%rax)
  676f09:	0f 11 00             	movups %xmm0,(%rax)
  676f0c:	48 81 c4 e8 11 00 00 	add    $0x11e8,%rsp
  676f13:	5b                   	pop    %rbx
  676f14:	41 5c                	pop    %r12
  676f16:	41 5d                	pop    %r13
  676f18:	41 5e                	pop    %r14
  676f1a:	41 5f                	pop    %r15
  676f1c:	5d                   	pop    %rbp
  676f1d:	c3                   	ret
  676f1e:	48 8d 35 e3 60 11 00 	lea    0x1160e3(%rip),%rsi        # 78d008 <gpui_canvas::text::HEBREW_FONT>
  676f25:	48 8d 15 08 97 9e ff 	lea    -0x6168f8(%rip),%rdx        # 60634 <gpui_canvas::text::HEBREW_BYTES>
  676f2c:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  676f33:	00 
  676f34:	b9 14 69 00 00       	mov    $0x6914,%ecx
  676f39:	45 31 c0             	xor    %r8d,%r8d
  676f3c:	e8 df cf fe ff       	call   663f20 <<gpui_canvas::text::FontFace>::shared_static>
  676f41:	80 bc 24 10 07 00 00 	cmpb   $0x0,0x710(%rsp)
  676f48:	00 
  676f49:	0f 85 02 d5 ff ff    	jne    674451 <<gpui_canvas::text::planner::Planner>::shape+0x3f1>
  676f4f:	44 89 fd             	mov    %r15d,%ebp
  676f52:	49 8d 9d 50 0a 00 00 	lea    0xa50(%r13),%rbx
  676f59:	4c 8b bc 24 18 07 00 	mov    0x718(%rsp),%r15
  676f60:	00 
  676f61:	48 8b 03             	mov    (%rbx),%rax
  676f64:	48 85 c0             	test   %rax,%rax
  676f67:	74 0f                	je     676f78 <<gpui_canvas::text::planner::Planner>::shape+0x2f18>
  676f69:	f0 48 ff 08          	lock decq (%rax)
  676f6d:	75 09                	jne    676f78 <<gpui_canvas::text::planner::Planner>::shape+0x2f18>
  676f6f:	48 89 df             	mov    %rbx,%rdi
  676f72:	ff 15 68 30 11 00    	call   *0x113068(%rip)        # 789fe0 <_DYNAMIC+0x260>
  676f78:	4d 89 bd 50 0a 00 00 	mov    %r15,0xa50(%r13)
  676f7f:	be 02 00 00 00       	mov    $0x2,%esi
  676f84:	4c 89 ef             	mov    %r13,%rdi
  676f87:	e8 a4 0b 00 00       	call   677b30 <<gpui_canvas::text::planner::Planner>::register>
  676f8c:	83 f8 ff             	cmp    $0xffffffff,%eax
  676f8f:	41 89 ef             	mov    %ebp,%r15d
  676f92:	0f 85 18 d5 ff ff    	jne    6744b0 <<gpui_canvas::text::planner::Planner>::shape+0x450>
  676f98:	e9 52 d5 ff ff       	jmp    6744ef <<gpui_canvas::text::planner::Planner>::shape+0x48f>
  676f9d:	48 8b b4 24 10 07 00 	mov    0x710(%rsp),%rsi
  676fa4:	00 
  676fa5:	48 85 f6             	test   %rsi,%rsi
  676fa8:	74 17                	je     676fc1 <<gpui_canvas::text::planner::Planner>::shape+0x2f61>
  676faa:	48 8b bc 24 18 07 00 	mov    0x718(%rsp),%rdi
  676fb1:	00 
  676fb2:	48 c1 e6 03          	shl    $0x3,%rsi
  676fb6:	ba 08 00 00 00       	mov    $0x8,%edx
  676fbb:	ff 15 f7 2f 11 00    	call   *0x112ff7(%rip)        # 789fb8 <_DYNAMIC+0x238>
  676fc1:	b8 01 00 00 00       	mov    $0x1,%eax
  676fc6:	4c 8b 2c 24          	mov    (%rsp),%r13
  676fca:	89 84 24 90 00 00 00 	mov    %eax,0x90(%rsp)
  676fd1:	89 94 24 94 00 00 00 	mov    %edx,0x94(%rsp)
  676fd8:	48 c7 84 24 88 00 00 	movq   $0xffffffffffffffff,0x88(%rsp)
  676fdf:	00 ff ff ff ff 
  676fe4:	e9 7e fc ff ff       	jmp    676c67 <<gpui_canvas::text::planner::Planner>::shape+0x2c07>
  676fe9:	c7 84 24 90 00 00 00 	movl   $0x3,0x90(%rsp)
  676ff0:	03 00 00 00 
  676ff4:	e9 5e fc ff ff       	jmp    676c57 <<gpui_canvas::text::planner::Planner>::shape+0x2bf7>
  676ff9:	48 c7 84 24 90 00 00 	movq   $0x3,0x90(%rsp)
  677000:	00 03 00 00 00 
  677005:	e9 4d fc ff ff       	jmp    676c57 <<gpui_canvas::text::planner::Planner>::shape+0x2bf7>
  67700a:	c7 84 24 90 00 00 00 	movl   $0x1,0x90(%rsp)
  677011:	01 00 00 00 
  677015:	e9 3d fc ff ff       	jmp    676c57 <<gpui_canvas::text::planner::Planner>::shape+0x2bf7>
  67701a:	c7 84 24 90 00 00 00 	movl   $0x3,0x90(%rsp)
  677021:	03 00 00 00 
  677025:	8b 84 24 18 02 00 00 	mov    0x218(%rsp),%eax
  67702c:	89 84 24 94 00 00 00 	mov    %eax,0x94(%rsp)
  677033:	e9 1f fc ff ff       	jmp    676c57 <<gpui_canvas::text::planner::Planner>::shape+0x2bf7>
  677038:	48 c7 84 24 90 00 00 	movq   $0xc,0x90(%rsp)
  67703f:	00 0c 00 00 00 
  677044:	48 c7 84 24 88 00 00 	movq   $0xffffffffffffffff,0x88(%rsp)
  67704b:	00 ff ff ff ff 
  677050:	49 89 f5             	mov    %rsi,%r13
  677053:	e9 0f fc ff ff       	jmp    676c67 <<gpui_canvas::text::planner::Planner>::shape+0x2c07>
  677058:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  67705f:	00 ff 
  677061:	4c 8b 2c 24          	mov    (%rsp),%r13
  677065:	0f 84 4a 01 00 00    	je     6771b5 <<gpui_canvas::text::planner::Planner>::shape+0x3155>
  67706b:	48 8b 84 24 80 01 00 	mov    0x180(%rsp),%rax
  677072:	00 
  677073:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  677077:	0f 84 1b 03 00 00    	je     677398 <<gpui_canvas::text::planner::Planner>::shape+0x3338>
  67707d:	48 8b b4 24 90 01 00 	mov    0x190(%rsp),%rsi
  677084:	00 
  677085:	48 39 f0             	cmp    %rsi,%rax
  677088:	0f 86 0a 03 00 00    	jbe    677398 <<gpui_canvas::text::planner::Planner>::shape+0x3338>
  67708e:	48 8d bc 24 80 01 00 	lea    0x180(%rsp),%rdi
  677095:	00 
  677096:	e8 e5 0c 00 00       	call   677d80 <<alloc::raw_vec::RawVecInner>::shrink>
  67709b:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  67709f:	0f 84 f3 02 00 00    	je     677398 <<gpui_canvas::text::planner::Planner>::shape+0x3338>
  6770a5:	48 89 c7             	mov    %rax,%rdi
  6770a8:	48 89 d6             	mov    %rdx,%rsi
  6770ab:	ff 15 1f 30 11 00    	call   *0x11301f(%rip)        # 78a0d0 <_DYNAMIC+0x350>
  6770b1:	e9 25 06 00 00       	jmp    6776db <<gpui_canvas::text::planner::Planner>::shape+0x367b>
  6770b6:	4c 8b 2c 24          	mov    (%rsp),%r13
  6770ba:	eb 25                	jmp    6770e1 <<gpui_canvas::text::planner::Planner>::shape+0x3081>
  6770bc:	c7 44 24 0c 00 00 00 	movl   $0x0,0xc(%rsp)
  6770c3:	00 
  6770c4:	4c 8b 8c 24 f8 02 00 	mov    0x2f8(%rsp),%r9
  6770cb:	00 
  6770cc:	4d 85 c9             	test   %r9,%r9
  6770cf:	74 23                	je     6770f4 <<gpui_canvas::text::planner::Planner>::shape+0x3094>
  6770d1:	4c 8b 2c 24          	mov    (%rsp),%r13
  6770d5:	48 8b 8c 24 10 01 00 	mov    0x110(%rsp),%rcx
  6770dc:	00 
  6770dd:	8b 54 24 0c          	mov    0xc(%rsp),%edx
  6770e1:	49 39 c9             	cmp    %rcx,%r9
  6770e4:	73 23                	jae    677109 <<gpui_canvas::text::planner::Planner>::shape+0x30a9>
  6770e6:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6770eb:	42 80 3c 08 bf       	cmpb   $0xbf,(%rax,%r9,1)
  6770f0:	7f 1c                	jg     67710e <<gpui_canvas::text::planner::Planner>::shape+0x30ae>
  6770f2:	eb 4c                	jmp    677140 <<gpui_canvas::text::planner::Planner>::shape+0x30e0>
  6770f4:	45 31 c9             	xor    %r9d,%r9d
  6770f7:	4c 8b 2c 24          	mov    (%rsp),%r13
  6770fb:	48 8b 8c 24 10 01 00 	mov    0x110(%rsp),%rcx
  677102:	00 
  677103:	8b 54 24 0c          	mov    0xc(%rsp),%edx
  677107:	eb 05                	jmp    67710e <<gpui_canvas::text::planner::Planner>::shape+0x30ae>
  677109:	49 89 c9             	mov    %rcx,%r9
  67710c:	75 32                	jne    677140 <<gpui_canvas::text::planner::Planner>::shape+0x30e0>
  67710e:	84 d2                	test   %dl,%dl
  677110:	74 1a                	je     67712c <<gpui_canvas::text::planner::Planner>::shape+0x30cc>
  677112:	4c 39 cd             	cmp    %r9,%rbp
  677115:	74 29                	je     677140 <<gpui_canvas::text::planner::Planner>::shape+0x30e0>
  677117:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
  67711c:	43 0f b6 0c 08       	movzbl (%r8,%r9,1),%ecx
  677121:	84 c9                	test   %cl,%cl
  677123:	78 44                	js     677169 <<gpui_canvas::text::planner::Planner>::shape+0x3109>
  677125:	b8 0b 00 00 00       	mov    $0xb,%eax
  67712a:	eb 1e                	jmp    67714a <<gpui_canvas::text::planner::Planner>::shape+0x30ea>
  67712c:	48 39 cd             	cmp    %rcx,%rbp
  67712f:	73 0d                	jae    67713e <<gpui_canvas::text::planner::Planner>::shape+0x30de>
  677131:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  677136:	80 3c 28 bf          	cmpb   $0xbf,(%rax,%rbp,1)
  67713a:	7f d6                	jg     677112 <<gpui_canvas::text::planner::Planner>::shape+0x30b2>
  67713c:	eb 02                	jmp    677140 <<gpui_canvas::text::planner::Planner>::shape+0x30e0>
  67713e:	74 d2                	je     677112 <<gpui_canvas::text::planner::Planner>::shape+0x30b2>
  677140:	b8 03 00 00 00       	mov    $0x3,%eax
  677145:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
  67714a:	89 84 24 90 00 00 00 	mov    %eax,0x90(%rsp)
  677151:	89 8c 24 94 00 00 00 	mov    %ecx,0x94(%rsp)
  677158:	48 c7 84 24 88 00 00 	movq   $0xffffffffffffffff,0x88(%rsp)
  67715f:	00 ff ff ff ff 
  677164:	e9 fe fa ff ff       	jmp    676c67 <<gpui_canvas::text::planner::Planner>::shape+0x2c07>
  677169:	89 ca                	mov    %ecx,%edx
  67716b:	83 e2 1f             	and    $0x1f,%edx
  67716e:	43 0f b6 7c 08 01    	movzbl 0x1(%r8,%r9,1),%edi
  677174:	83 e7 3f             	and    $0x3f,%edi
  677177:	b8 0b 00 00 00       	mov    $0xb,%eax
  67717c:	80 f9 df             	cmp    $0xdf,%cl
  67717f:	76 2b                	jbe    6771ac <<gpui_canvas::text::planner::Planner>::shape+0x314c>
  677181:	43 0f b6 74 08 02    	movzbl 0x2(%r8,%r9,1),%esi
  677187:	c1 e7 06             	shl    $0x6,%edi
  67718a:	83 e6 3f             	and    $0x3f,%esi
  67718d:	09 fe                	or     %edi,%esi
  67718f:	80 f9 f0             	cmp    $0xf0,%cl
  677192:	72 7a                	jb     67720e <<gpui_canvas::text::planner::Planner>::shape+0x31ae>
  677194:	43 0f b6 4c 08 03    	movzbl 0x3(%r8,%r9,1),%ecx
  67719a:	83 e2 07             	and    $0x7,%edx
  67719d:	c1 e2 12             	shl    $0x12,%edx
  6771a0:	c1 e6 06             	shl    $0x6,%esi
  6771a3:	83 e1 3f             	and    $0x3f,%ecx
  6771a6:	09 f1                	or     %esi,%ecx
  6771a8:	09 d1                	or     %edx,%ecx
  6771aa:	eb 9e                	jmp    67714a <<gpui_canvas::text::planner::Planner>::shape+0x30ea>
  6771ac:	c1 e2 06             	shl    $0x6,%edx
  6771af:	09 fa                	or     %edi,%edx
  6771b1:	89 d1                	mov    %edx,%ecx
  6771b3:	eb 95                	jmp    67714a <<gpui_canvas::text::planner::Planner>::shape+0x30ea>
  6771b5:	48 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%rax
  6771bc:	00 
  6771bd:	48 85 c0             	test   %rax,%rax
  6771c0:	0f 84 b6 00 00 00    	je     67727c <<gpui_canvas::text::planner::Planner>::shape+0x321c>
  6771c6:	48 8b 8c 24 f0 00 00 	mov    0xf0(%rsp),%rcx
  6771cd:	00 
  6771ce:	48 c1 e0 04          	shl    $0x4,%rax
  6771d2:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
  6771d7:	2b 54 01 f0          	sub    -0x10(%rcx,%rax,1),%edx
  6771db:	0f 83 a8 00 00 00    	jae    677289 <<gpui_canvas::text::planner::Planner>::shape+0x3229>
  6771e1:	c7 84 24 90 00 00 00 	movl   $0x3,0x90(%rsp)
  6771e8:	03 00 00 00 
  6771ec:	48 c7 84 24 88 00 00 	movq   $0xffffffffffffffff,0x88(%rsp)
  6771f3:	00 ff ff ff ff 
  6771f8:	48 8b b4 24 e8 00 00 	mov    0xe8(%rsp),%rsi
  6771ff:	00 
  677200:	48 85 f6             	test   %rsi,%rsi
  677203:	0f 85 ef fa ff ff    	jne    676cf8 <<gpui_canvas::text::planner::Planner>::shape+0x2c98>
  677209:	e9 01 fb ff ff       	jmp    676d0f <<gpui_canvas::text::planner::Planner>::shape+0x2caf>
  67720e:	c1 e2 0c             	shl    $0xc,%edx
  677211:	09 d6                	or     %edx,%esi
  677213:	89 f1                	mov    %esi,%ecx
  677215:	e9 30 ff ff ff       	jmp    67714a <<gpui_canvas::text::planner::Planner>::shape+0x30ea>
  67721a:	48 8d 3d f7 71 be ff 	lea    -0x418e09(%rip),%rdi        # 25e418 <anon.bed1e15ea09922136a836d7820f2c1fc.5.llvm.1182798584467922838>
  677221:	48 8d 15 d8 94 10 00 	lea    0x1094d8(%rip),%rdx        # 780700 <anon.bed1e15ea09922136a836d7820f2c1fc.6.llvm.1182798584467922838>
  677228:	be ad 00 00 00       	mov    $0xad,%esi
  67722d:	ff 15 7d 2e 11 00    	call   *0x112e7d(%rip)        # 78a0b0 <_DYNAMIC+0x330>
  677233:	e9 a3 04 00 00       	jmp    6776db <<gpui_canvas::text::planner::Planner>::shape+0x367b>
  677238:	48 8d 0d 49 87 10 00 	lea    0x108749(%rip),%rcx        # 77f988 <anon.1a3692c52bba9218a112fc8e64fef457.3.llvm.8970656708749461829+0x3d8>
  67723f:	48 89 df             	mov    %rbx,%rdi
  677242:	48 8b 94 24 40 01 00 	mov    0x140(%rsp),%rdx
  677249:	00 
  67724a:	ff 15 90 30 11 00    	call   *0x113090(%rip)        # 78a2e0 <_DYNAMIC+0x560>
  677250:	e9 86 04 00 00       	jmp    6776db <<gpui_canvas::text::planner::Planner>::shape+0x367b>
  677255:	41 bc 03 00 00 00    	mov    $0x3,%r12d
  67725b:	8b 44 24 08          	mov    0x8(%rsp),%eax
  67725f:	41 89 c7             	mov    %eax,%r15d
  677262:	e9 4f d2 ff ff       	jmp    6744b6 <<gpui_canvas::text::planner::Planner>::shape+0x456>
  677267:	41 bc 03 00 00 00    	mov    $0x3,%r12d
  67726d:	8b 84 24 d0 01 00 00 	mov    0x1d0(%rsp),%eax
  677274:	41 89 c7             	mov    %eax,%r15d
  677277:	e9 3a d2 ff ff       	jmp    6744b6 <<gpui_canvas::text::planner::Planner>::shape+0x456>
  67727c:	48 83 7c 24 50 00    	cmpq   $0x0,0x50(%rsp)
  677282:	75 11                	jne    677295 <<gpui_canvas::text::planner::Planner>::shape+0x3235>
  677284:	e9 0f 01 00 00       	jmp    677398 <<gpui_canvas::text::planner::Planner>::shape+0x3338>
  677289:	81 fa ff 00 00 00    	cmp    $0xff,%edx
  67728f:	0f 86 b1 02 00 00    	jbe    677546 <<gpui_canvas::text::planner::Planner>::shape+0x34e6>
  677295:	bf 04 00 00 00       	mov    $0x4,%edi
  67729a:	be 18 00 00 00       	mov    $0x18,%esi
  67729f:	e8 ac 0d 00 00       	call   678050 <alloc::boxed::box_new_uninit>
  6772a4:	48 89 c3             	mov    %rax,%rbx
  6772a7:	8b 84 24 f8 00 00 00 	mov    0xf8(%rsp),%eax
  6772ae:	c7 03 00 00 00 00    	movl   $0x0,(%rbx)
  6772b4:	4c 8b 7c 24 50       	mov    0x50(%rsp),%r15
  6772b9:	44 89 7b 04          	mov    %r15d,0x4(%rbx)
  6772bd:	c7 43 08 00 00 00 00 	movl   $0x0,0x8(%rbx)
  6772c4:	89 43 0c             	mov    %eax,0xc(%rbx)
  6772c7:	c7 43 10 00 00 00 00 	movl   $0x0,0x10(%rbx)
  6772ce:	66 c7 43 14 00 00    	movw   $0x0,0x14(%rbx)
  6772d4:	bf 04 00 00 00       	mov    $0x4,%edi
  6772d9:	be 18 00 00 00       	mov    $0x18,%esi
  6772de:	e8 6d 0d 00 00       	call   678050 <alloc::boxed::box_new_uninit>
  6772e3:	49 89 c6             	mov    %rax,%r14
  6772e6:	c7 00 00 00 00 00    	movl   $0x0,(%rax)
  6772ec:	44 89 78 04          	mov    %r15d,0x4(%rax)
  6772f0:	c7 40 08 00 00 00 00 	movl   $0x0,0x8(%rax)
  6772f7:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
  6772fd:	f3 0f 11 40 0c       	movss  %xmm0,0xc(%rax)
  677302:	f3 0f 10 44 24 7c    	movss  0x7c(%rsp),%xmm0
  677308:	f3 0f 11 40 10       	movss  %xmm0,0x10(%rax)
  67730d:	0f 28 84 24 80 02 00 	movaps 0x280(%rsp),%xmm0
  677314:	00 
  677315:	f3 0f 11 40 14       	movss  %xmm0,0x14(%rax)
  67731a:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  677321:	00 ff 
  677323:	74 0d                	je     677332 <<gpui_canvas::text::planner::Planner>::shape+0x32d2>
  677325:	48 8d bc 24 50 01 00 	lea    0x150(%rsp),%rdi
  67732c:	00 
  67732d:	e8 be c2 ff ff       	call   6735f0 <core::ptr::drop_glue::<gpui_canvas::text::layout::TextGeometry>>
  677332:	48 c7 84 24 50 01 00 	movq   $0x1,0x150(%rsp)
  677339:	00 01 00 00 00 
  67733e:	48 89 9c 24 58 01 00 	mov    %rbx,0x158(%rsp)
  677345:	00 
  677346:	48 c7 84 24 60 01 00 	movq   $0x1,0x160(%rsp)
  67734d:	00 01 00 00 00 
  677352:	48 c7 84 24 68 01 00 	movq   $0x1,0x168(%rsp)
  677359:	00 01 00 00 00 
  67735e:	4c 89 b4 24 70 01 00 	mov    %r14,0x170(%rsp)
  677365:	00 
  677366:	48 c7 84 24 78 01 00 	movq   $0x1,0x178(%rsp)
  67736d:	00 01 00 00 00 
  677372:	48 c7 84 24 80 01 00 	movq   $0xffffffffffffffff,0x180(%rsp)
  677379:	00 ff ff ff ff 
  67737e:	44 89 bc 24 98 01 00 	mov    %r15d,0x198(%rsp)
  677385:	00 
  677386:	f3 0f 10 84 24 84 00 	movss  0x84(%rsp),%xmm0
  67738d:	00 00 
  67738f:	f3 0f 11 84 24 9c 01 	movss  %xmm0,0x19c(%rsp)
  677396:	00 00 
  677398:	4c 8b bc 24 e8 00 00 	mov    0xe8(%rsp),%r15
  67739f:	00 
  6773a0:	48 8b 9c 24 f0 00 00 	mov    0xf0(%rsp),%rbx
  6773a7:	00 
  6773a8:	4c 8b b4 24 f8 00 00 	mov    0xf8(%rsp),%r14
  6773af:	00 
  6773b0:	4c 89 ef             	mov    %r13,%rdi
  6773b3:	48 8b b4 24 08 02 00 	mov    0x208(%rsp),%rsi
  6773ba:	00 
  6773bb:	e8 30 06 00 00       	call   6779f0 <<gpui_canvas::text::planner::Planner>::font_set>
  6773c0:	49 89 c4             	mov    %rax,%r12
  6773c3:	48 89 84 24 c0 04 00 	mov    %rax,0x4c0(%rsp)
  6773ca:	00 
  6773cb:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
  6773d2:	00 
  6773d3:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6773d7:	0f 84 c7 00 00 00    	je     6774a4 <<gpui_canvas::text::planner::Planner>::shape+0x3444>
  6773dd:	48 8d 94 24 58 01 00 	lea    0x158(%rsp),%rdx
  6773e4:	00 
  6773e5:	48 8b 4a 40          	mov    0x40(%rdx),%rcx
  6773e9:	48 89 8c 24 68 07 00 	mov    %rcx,0x768(%rsp)
  6773f0:	00 
  6773f1:	0f 10 02             	movups (%rdx),%xmm0
  6773f4:	0f 10 4a 10          	movups 0x10(%rdx),%xmm1
  6773f8:	0f 10 52 20          	movups 0x20(%rdx),%xmm2
  6773fc:	0f 10 5a 30          	movups 0x30(%rdx),%xmm3
  677400:	0f 11 9c 24 58 07 00 	movups %xmm3,0x758(%rsp)
  677407:	00 
  677408:	0f 11 94 24 48 07 00 	movups %xmm2,0x748(%rsp)
  67740f:	00 
  677410:	0f 11 8c 24 38 07 00 	movups %xmm1,0x738(%rsp)
  677417:	00 
  677418:	0f 11 84 24 28 07 00 	movups %xmm0,0x728(%rsp)
  67741f:	00 
  677420:	48 c7 84 24 10 07 00 	movq   $0x1,0x710(%rsp)
  677427:	00 01 00 00 00 
  67742c:	48 c7 84 24 18 07 00 	movq   $0x1,0x718(%rsp)
  677433:	00 01 00 00 00 
  677438:	4c 8d ac 24 20 07 00 	lea    0x720(%rsp),%r13
  67743f:	00 
  677440:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
  677447:	00 
  677448:	bf 08 00 00 00       	mov    $0x8,%edi
  67744d:	be 60 00 00 00       	mov    $0x60,%esi
  677452:	e8 f9 0b 00 00       	call   678050 <alloc::boxed::box_new_uninit>
  677457:	0f 10 84 24 60 07 00 	movups 0x760(%rsp),%xmm0
  67745e:	00 
  67745f:	0f 11 40 50          	movups %xmm0,0x50(%rax)
  677463:	0f 10 84 24 50 07 00 	movups 0x750(%rsp),%xmm0
  67746a:	00 
  67746b:	0f 11 40 40          	movups %xmm0,0x40(%rax)
  67746f:	0f 10 84 24 10 07 00 	movups 0x710(%rsp),%xmm0
  677476:	00 
  677477:	0f 10 8c 24 20 07 00 	movups 0x720(%rsp),%xmm1
  67747e:	00 
  67747f:	0f 10 94 24 30 07 00 	movups 0x730(%rsp),%xmm2
  677486:	00 
  677487:	0f 10 9c 24 40 07 00 	movups 0x740(%rsp),%xmm3
  67748e:	00 
  67748f:	0f 11 58 30          	movups %xmm3,0x30(%rax)
  677493:	0f 11 50 20          	movups %xmm2,0x20(%rax)
  677497:	0f 11 48 10          	movups %xmm1,0x10(%rax)
  67749b:	0f 11 00             	movups %xmm0,(%rax)
  67749e:	4c 8b 2c 24          	mov    (%rsp),%r13
  6774a2:	eb 02                	jmp    6774a6 <<gpui_canvas::text::planner::Planner>::shape+0x3446>
  6774a4:	31 c0                	xor    %eax,%eax
  6774a6:	4c 89 bc 24 88 00 00 	mov    %r15,0x88(%rsp)
  6774ad:	00 
  6774ae:	48 89 9c 24 90 00 00 	mov    %rbx,0x90(%rsp)
  6774b5:	00 
  6774b6:	4c 89 b4 24 98 00 00 	mov    %r14,0x98(%rsp)
  6774bd:	00 
  6774be:	4c 89 a4 24 a0 00 00 	mov    %r12,0xa0(%rsp)
  6774c5:	00 
  6774c6:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
  6774cd:	00 
  6774ce:	0f 28 84 24 80 02 00 	movaps 0x280(%rsp),%xmm0
  6774d5:	00 
  6774d6:	f3 0f 11 84 24 b0 00 	movss  %xmm0,0xb0(%rsp)
  6774dd:	00 00 
  6774df:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
  6774e5:	f3 0f 11 84 24 b4 00 	movss  %xmm0,0xb4(%rsp)
  6774ec:	00 00 
  6774ee:	f3 0f 10 44 24 7c    	movss  0x7c(%rsp),%xmm0
  6774f4:	f3 0f 11 84 24 b8 00 	movss  %xmm0,0xb8(%rsp)
  6774fb:	00 00 
  6774fd:	f3 0f 10 84 24 84 00 	movss  0x84(%rsp),%xmm0
  677504:	00 00 
  677506:	f3 0f 11 84 24 bc 00 	movss  %xmm0,0xbc(%rsp)
  67750d:	00 00 
  67750f:	48 8d bc 24 a0 02 00 	lea    0x2a0(%rsp),%rdi
  677516:	00 
  677517:	e8 b4 a8 ff ff       	call   671dd0 <core::ptr::drop_glue::<[parlance::font_family::FontFamilyName; 3]>>
  67751c:	49 83 ff ff          	cmp    $0xffffffffffffffff,%r15
  677520:	0f 85 af f9 ff ff    	jne    676ed5 <<gpui_canvas::text::planner::Planner>::shape+0x2e75>
  677526:	e9 56 f8 ff ff       	jmp    676d81 <<gpui_canvas::text::planner::Planner>::shape+0x2d21>
  67752b:	48 8d 0d 06 80 10 00 	lea    0x108006(%rip),%rcx        # 77f538 <anon.98eb2121465841304e196c1cc83cb241.23.llvm.14436572662246312189>
  677532:	48 89 f7             	mov    %rsi,%rdi
  677535:	48 89 d6             	mov    %rdx,%rsi
  677538:	4c 89 c2             	mov    %r8,%rdx
  67753b:	ff 15 9f 2d 11 00    	call   *0x112d9f(%rip)        # 78a2e0 <_DYNAMIC+0x560>
  677541:	e9 95 01 00 00       	jmp    6776db <<gpui_canvas::text::planner::Planner>::shape+0x367b>
  677546:	48 01 c1             	add    %rax,%rcx
  677549:	88 51 ff             	mov    %dl,-0x1(%rcx)
  67754c:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  677553:	00 ff 
  677555:	0f 85 10 fb ff ff    	jne    67706b <<gpui_canvas::text::planner::Planner>::shape+0x300b>
  67755b:	e9 38 fe ff ff       	jmp    677398 <<gpui_canvas::text::planner::Planner>::shape+0x3338>
  677560:	48 89 cb             	mov    %rcx,%rbx
  677563:	48 8b 84 24 00 02 00 	mov    0x200(%rsp),%rax
  67756a:	00 
  67756b:	48 89 84 24 40 01 00 	mov    %rax,0x140(%rsp)
  677572:	00 
  677573:	48 8d 0d 16 85 10 00 	lea    0x108516(%rip),%rcx        # 77fa90 <anon.1a3692c52bba9218a112fc8e64fef457.3.llvm.8970656708749461829+0x4e0>
  67757a:	e9 c0 fc ff ff       	jmp    67723f <<gpui_canvas::text::planner::Planner>::shape+0x31df>
  67757f:	48 89 d3             	mov    %rdx,%rbx
  677582:	4c 89 b4 24 40 01 00 	mov    %r14,0x140(%rsp)
  677589:	00 
  67758a:	48 8d 0d c7 83 10 00 	lea    0x1083c7(%rip),%rcx        # 77f958 <anon.1a3692c52bba9218a112fc8e64fef457.3.llvm.8970656708749461829+0x3a8>
  677591:	e9 a9 fc ff ff       	jmp    67723f <<gpui_canvas::text::planner::Planner>::shape+0x31df>
  677596:	48 8d 0d e3 8f 10 00 	lea    0x108fe3(%rip),%rcx        # 780580 <anon.c85b311aa65b1c615d2dfba884aacc4b.17.llvm.6911206892222571341>
  67759d:	ff 15 3d 2d 11 00    	call   *0x112d3d(%rip)        # 78a2e0 <_DYNAMIC+0x560>
  6775a3:	e9 33 01 00 00       	jmp    6776db <<gpui_canvas::text::planner::Planner>::shape+0x367b>
  6775a8:	48 8d 0d d1 8f 10 00 	lea    0x108fd1(%rip),%rcx        # 780580 <anon.c85b311aa65b1c615d2dfba884aacc4b.17.llvm.6911206892222571341>
  6775af:	ff 15 2b 2d 11 00    	call   *0x112d2b(%rip)        # 78a2e0 <_DYNAMIC+0x560>
  6775b5:	e9 21 01 00 00       	jmp    6776db <<gpui_canvas::text::planner::Planner>::shape+0x367b>
  6775ba:	48 8d 3d 2f 8c 10 00 	lea    0x108c2f(%rip),%rdi        # 7801f0 <anon.8910945c9b008592b86f990050da00b9.41.llvm.6620413135221661696>
  6775c1:	ff 15 f1 2a 11 00    	call   *0x112af1(%rip)        # 78a0b8 <_DYNAMIC+0x338>
  6775c7:	e9 0f 01 00 00       	jmp    6776db <<gpui_canvas::text::planner::Planner>::shape+0x367b>
  6775cc:	83 f8 fe             	cmp    $0xfffffffe,%eax
  6775cf:	0f 85 f1 f9 ff ff    	jne    676fc6 <<gpui_canvas::text::planner::Planner>::shape+0x2f66>
  6775d5:	b8 03 00 00 00       	mov    $0x3,%eax
  6775da:	e9 e7 f9 ff ff       	jmp    676fc6 <<gpui_canvas::text::planner::Planner>::shape+0x2f66>
  6775df:	4c 8d 05 ea 83 10 00 	lea    0x1083ea(%rip),%r8        # 77f9d0 <anon.1a3692c52bba9218a112fc8e64fef457.3.llvm.8970656708749461829+0x420>
  6775e6:	48 8b bc 24 48 01 00 	mov    0x148(%rsp),%rdi
  6775ed:	00 
  6775ee:	48 8b 74 24 50       	mov    0x50(%rsp),%rsi
  6775f3:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
  6775f8:	ff 15 c2 2d 11 00    	call   *0x112dc2(%rip)        # 78a3c0 <_DYNAMIC+0x640>
  6775fe:	e9 d8 00 00 00       	jmp    6776db <<gpui_canvas::text::planner::Planner>::shape+0x367b>
  677603:	48 8d 05 66 83 10 00 	lea    0x108366(%rip),%rax        # 77f970 <anon.1a3692c52bba9218a112fc8e64fef457.3.llvm.8970656708749461829+0x3c0>
  67760a:	eb 1f                	jmp    67762b <<gpui_canvas::text::planner::Planner>::shape+0x35cb>
  67760c:	49 39 d6             	cmp    %rdx,%r14
  67760f:	49 0f 47 d6          	cmova  %r14,%rdx
  677613:	48 8d 05 46 85 10 00 	lea    0x108546(%rip),%rax        # 77fb60 <anon.1a3692c52bba9218a112fc8e64fef457.3.llvm.8970656708749461829+0x5b0>
  67761a:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  67761f:	48 89 d7             	mov    %rdx,%rdi
  677622:	eb 0c                	jmp    677630 <<gpui_canvas::text::planner::Planner>::shape+0x35d0>
  677624:	48 8d 05 05 84 10 00 	lea    0x108405(%rip),%rax        # 77fa30 <anon.1a3692c52bba9218a112fc8e64fef457.3.llvm.8970656708749461829+0x480>
  67762b:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  677630:	48 8b b4 24 e8 01 00 	mov    0x1e8(%rsp),%rsi
  677637:	00 
  677638:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
  67763d:	ff 15 9d 2a 11 00    	call   *0x112a9d(%rip)        # 78a0e0 <_DYNAMIC+0x360>
  677643:	e9 93 00 00 00       	jmp    6776db <<gpui_canvas::text::planner::Planner>::shape+0x367b>
  677648:	48 8d 0d 31 7f 10 00 	lea    0x107f31(%rip),%rcx        # 77f580 <anon.98eb2121465841304e196c1cc83cb241.28.llvm.14436572662246312189>
  67764f:	48 89 8c 24 70 02 00 	mov    %rcx,0x270(%rsp)
  677656:	00 
  677657:	eb 04                	jmp    67765d <<gpui_canvas::text::planner::Planner>::shape+0x35fd>
  677659:	31 ff                	xor    %edi,%edi
  67765b:	31 c0                	xor    %eax,%eax
  67765d:	48 89 c6             	mov    %rax,%rsi
  677660:	48 8b 94 24 70 02 00 	mov    0x270(%rsp),%rdx
  677667:	00 
  677668:	ff 15 72 2a 11 00    	call   *0x112a72(%rip)        # 78a0e0 <_DYNAMIC+0x360>
  67766e:	eb 6b                	jmp    6776db <<gpui_canvas::text::planner::Planner>::shape+0x367b>
  677670:	31 ff                	xor    %edi,%edi
  677672:	48 c7 84 24 e8 01 00 	movq   $0x0,0x1e8(%rsp)
  677679:	00 00 00 00 00 
  67767e:	eb b0                	jmp    677630 <<gpui_canvas::text::planner::Planner>::shape+0x35d0>
  677680:	48 8d 15 d9 8d 10 00 	lea    0x108dd9(%rip),%rdx        # 780460 <anon.8910945c9b008592b86f990050da00b9.70.llvm.6620413135221661696>
  677687:	ff 15 53 2a 11 00    	call   *0x112a53(%rip)        # 78a0e0 <_DYNAMIC+0x360>
  67768d:	eb 4c                	jmp    6776db <<gpui_canvas::text::planner::Planner>::shape+0x367b>
  67768f:	48 8d 05 b2 84 10 00 	lea    0x1084b2(%rip),%rax        # 77fb48 <anon.1a3692c52bba9218a112fc8e64fef457.3.llvm.8970656708749461829+0x598>
  677696:	eb 93                	jmp    67762b <<gpui_canvas::text::planner::Planner>::shape+0x35cb>
  677698:	48 89 d7             	mov    %rdx,%rdi
  67769b:	48 8d 05 d6 84 10 00 	lea    0x1084d6(%rip),%rax        # 77fb78 <anon.1a3692c52bba9218a112fc8e64fef457.3.llvm.8970656708749461829+0x5c8>
  6776a2:	eb 87                	jmp    67762b <<gpui_canvas::text::planner::Planner>::shape+0x35cb>
  6776a4:	48 8d 05 6d 83 10 00 	lea    0x10836d(%rip),%rax        # 77fa18 <anon.1a3692c52bba9218a112fc8e64fef457.3.llvm.8970656708749461829+0x468>
  6776ab:	e9 7b ff ff ff       	jmp    67762b <<gpui_canvas::text::planner::Planner>::shape+0x35cb>
  6776b0:	48 8d 05 91 83 10 00 	lea    0x108391(%rip),%rax        # 77fa48 <anon.1a3692c52bba9218a112fc8e64fef457.3.llvm.8970656708749461829+0x498>
  6776b7:	e9 6f ff ff ff       	jmp    67762b <<gpui_canvas::text::planner::Planner>::shape+0x35cb>
  6776bc:	48 89 d7             	mov    %rdx,%rdi
  6776bf:	48 8d 05 9a 83 10 00 	lea    0x10839a(%rip),%rax        # 77fa60 <anon.1a3692c52bba9218a112fc8e64fef457.3.llvm.8970656708749461829+0x4b0>
  6776c6:	e9 60 ff ff ff       	jmp    67762b <<gpui_canvas::text::planner::Planner>::shape+0x35cb>
  6776cb:	48 8d 15 ae 7e 10 00 	lea    0x107eae(%rip),%rdx        # 77f580 <anon.98eb2121465841304e196c1cc83cb241.28.llvm.14436572662246312189>
  6776d2:	48 89 c6             	mov    %rax,%rsi
  6776d5:	ff 15 05 2a 11 00    	call   *0x112a05(%rip)        # 78a0e0 <_DYNAMIC+0x360>
  6776db:	0f 0b                	ud2
  6776dd:	49 89 c6             	mov    %rax,%r14
  6776e0:	be 18 00 00 00       	mov    $0x18,%esi
  6776e5:	ba 04 00 00 00       	mov    $0x4,%edx
  6776ea:	48 89 df             	mov    %rbx,%rdi
  6776ed:	ff 15 c5 28 11 00    	call   *0x1128c5(%rip)        # 789fb8 <_DYNAMIC+0x238>
  6776f3:	e9 9a 02 00 00       	jmp    677992 <<gpui_canvas::text::planner::Planner>::shape+0x3932>
  6776f8:	49 89 c6             	mov    %rax,%r14
  6776fb:	4c 89 ef             	mov    %r13,%rdi
  6776fe:	e8 ed be ff ff       	call   6735f0 <core::ptr::drop_glue::<gpui_canvas::text::layout::TextGeometry>>
  677703:	f0 49 ff 0c 24       	lock decq (%r12)
  677708:	75 0e                	jne    677718 <<gpui_canvas::text::planner::Planner>::shape+0x36b8>
  67770a:	48 8d bc 24 c0 04 00 	lea    0x4c0(%rsp),%rdi
  677711:	00 
  677712:	ff 15 b8 28 11 00    	call   *0x1128b8(%rip)        # 789fd0 <_DYNAMIC+0x250>
  677718:	31 ed                	xor    %ebp,%ebp
  67771a:	eb 0c                	jmp    677728 <<gpui_canvas::text::planner::Planner>::shape+0x36c8>
  67771c:	ff 15 b6 28 11 00    	call   *0x1128b6(%rip)        # 789fd8 <_DYNAMIC+0x258>
  677722:	49 89 c6             	mov    %rax,%r14
  677725:	40 b5 01             	mov    $0x1,%bpl
  677728:	4d 85 ff             	test   %r15,%r15
  67772b:	74 15                	je     677742 <<gpui_canvas::text::planner::Planner>::shape+0x36e2>
  67772d:	49 c1 e7 04          	shl    $0x4,%r15
  677731:	ba 04 00 00 00       	mov    $0x4,%edx
  677736:	48 89 df             	mov    %rbx,%rdi
  677739:	4c 89 fe             	mov    %r15,%rsi
  67773c:	ff 15 76 28 11 00    	call   *0x112876(%rip)        # 789fb8 <_DYNAMIC+0x238>
  677742:	40 84 ed             	test   %bpl,%bpl
  677745:	0f 84 89 02 00 00    	je     6779d4 <<gpui_canvas::text::planner::Planner>::shape+0x3974>
  67774b:	31 db                	xor    %ebx,%ebx
  67774d:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  677754:	00 ff 
  677756:	0f 84 fb 01 00 00    	je     677957 <<gpui_canvas::text::planner::Planner>::shape+0x38f7>
  67775c:	e9 3e 02 00 00       	jmp    67799f <<gpui_canvas::text::planner::Planner>::shape+0x393f>
  677761:	49 89 c6             	mov    %rax,%r14
  677764:	4c 89 3b             	mov    %r15,(%rbx)
  677767:	4c 89 f7             	mov    %r14,%rdi
  67776a:	e8 71 68 10 00       	call   77dfe0 <_Unwind_Resume@plt>
  67776f:	e9 1b 02 00 00       	jmp    67798f <<gpui_canvas::text::planner::Planner>::shape+0x392f>
  677774:	e9 16 02 00 00       	jmp    67798f <<gpui_canvas::text::planner::Planner>::shape+0x392f>
  677779:	e9 11 02 00 00       	jmp    67798f <<gpui_canvas::text::planner::Planner>::shape+0x392f>
  67777e:	e9 b7 01 00 00       	jmp    67793a <<gpui_canvas::text::planner::Planner>::shape+0x38da>
  677783:	e9 07 02 00 00       	jmp    67798f <<gpui_canvas::text::planner::Planner>::shape+0x392f>
  677788:	e9 02 02 00 00       	jmp    67798f <<gpui_canvas::text::planner::Planner>::shape+0x392f>
  67778d:	e9 fd 01 00 00       	jmp    67798f <<gpui_canvas::text::planner::Planner>::shape+0x392f>
  677792:	e9 a3 01 00 00       	jmp    67793a <<gpui_canvas::text::planner::Planner>::shape+0x38da>
  677797:	e9 f3 01 00 00       	jmp    67798f <<gpui_canvas::text::planner::Planner>::shape+0x392f>
  67779c:	49 89 c6             	mov    %rax,%r14
  67779f:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  6777a6:	00 
  6777a7:	e8 04 7e ff ff       	call   66f5b0 <core::ptr::drop_glue::<parley::style::StyleProperty<()>>>
  6777ac:	e9 e1 01 00 00       	jmp    677992 <<gpui_canvas::text::planner::Planner>::shape+0x3932>
  6777b1:	ff 15 21 28 11 00    	call   *0x112821(%rip)        # 789fd8 <_DYNAMIC+0x258>
  6777b7:	49 89 c6             	mov    %rax,%r14
  6777ba:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  6777c1:	00 
  6777c2:	e8 e9 7d ff ff       	call   66f5b0 <core::ptr::drop_glue::<parley::style::StyleProperty<()>>>
  6777c7:	e9 c6 01 00 00       	jmp    677992 <<gpui_canvas::text::planner::Planner>::shape+0x3932>
  6777cc:	ff 15 06 28 11 00    	call   *0x112806(%rip)        # 789fd8 <_DYNAMIC+0x258>
  6777d2:	49 89 c6             	mov    %rax,%r14
  6777d5:	49 c7 85 c8 08 00 00 	movq   $0x0,0x8c8(%r13)
  6777dc:	00 00 00 00 
  6777e0:	49 c7 85 d0 08 00 00 	movq   $0x4,0x8d0(%r13)
  6777e7:	04 00 00 00 
  6777eb:	0f 57 c0             	xorps  %xmm0,%xmm0
  6777ee:	41 0f 11 85 d8 08 00 	movups %xmm0,0x8d8(%r13)
  6777f5:	00 
  6777f6:	49 c7 85 e8 08 00 00 	movq   $0x4,0x8e8(%r13)
  6777fd:	04 00 00 00 
  677801:	41 0f 11 85 f0 08 00 	movups %xmm0,0x8f0(%r13)
  677808:	00 
  677809:	49 c7 85 00 09 00 00 	movq   $0x8,0x900(%r13)
  677810:	08 00 00 00 
  677814:	41 0f 11 85 08 09 00 	movups %xmm0,0x908(%r13)
  67781b:	00 
  67781c:	49 c7 85 18 09 00 00 	movq   $0x8,0x918(%r13)
  677823:	08 00 00 00 
  677827:	41 0f 11 85 20 09 00 	movups %xmm0,0x920(%r13)
  67782e:	00 
  67782f:	49 c7 85 30 09 00 00 	movq   $0x4,0x930(%r13)
  677836:	04 00 00 00 
  67783a:	41 0f 11 85 38 09 00 	movups %xmm0,0x938(%r13)
  677841:	00 
  677842:	49 c7 85 48 09 00 00 	movq   $0x4,0x948(%r13)
  677849:	04 00 00 00 
  67784d:	41 0f 11 85 50 09 00 	movups %xmm0,0x950(%r13)
  677854:	00 
  677855:	49 c7 85 60 09 00 00 	movq   $0x4,0x960(%r13)
  67785c:	04 00 00 00 
  677860:	41 0f 11 85 68 09 00 	movups %xmm0,0x968(%r13)
  677867:	00 
  677868:	49 c7 85 78 09 00 00 	movq   $0x8,0x978(%r13)
  67786f:	08 00 00 00 
  677873:	41 0f 11 85 80 09 00 	movups %xmm0,0x980(%r13)
  67787a:	00 
  67787b:	49 c7 85 90 09 00 00 	movq   $0x2,0x990(%r13)
  677882:	02 00 00 00 
  677886:	41 0f 11 85 98 09 00 	movups %xmm0,0x998(%r13)
  67788d:	00 
  67788e:	49 c7 85 a8 09 00 00 	movq   $0x4,0x9a8(%r13)
  677895:	04 00 00 00 
  677899:	41 0f 11 85 b0 09 00 	movups %xmm0,0x9b0(%r13)
  6778a0:	00 
  6778a1:	49 c7 85 c0 09 00 00 	movq   $0x8,0x9c0(%r13)
  6778a8:	08 00 00 00 
  6778ac:	41 0f 11 85 c8 09 00 	movups %xmm0,0x9c8(%r13)
  6778b3:	00 
  6778b4:	49 c7 85 d8 09 00 00 	movq   $0x8,0x9d8(%r13)
  6778bb:	08 00 00 00 
  6778bf:	41 0f 11 85 e0 09 00 	movups %xmm0,0x9e0(%r13)
  6778c6:	00 
  6778c7:	49 c7 85 f0 09 00 00 	movq   $0x8,0x9f0(%r13)
  6778ce:	08 00 00 00 
  6778d2:	41 0f 11 85 f8 09 00 	movups %xmm0,0x9f8(%r13)
  6778d9:	00 
  6778da:	49 c7 85 08 0a 00 00 	movq   $0x4,0xa08(%r13)
  6778e1:	04 00 00 00 
  6778e5:	41 0f 11 85 10 0a 00 	movups %xmm0,0xa10(%r13)
  6778ec:	00 
  6778ed:	41 c7 85 20 0a 00 00 	movl   $0x3f800000,0xa20(%r13)
  6778f4:	00 00 80 3f 
  6778f8:	41 0f 11 85 24 0a 00 	movups %xmm0,0xa24(%r13)
  6778ff:	00 
  677900:	49 c7 85 32 0a 00 00 	movq   $0x0,0xa32(%r13)
  677907:	00 00 00 00 
  67790b:	66 41 c7 85 3a 0a 00 	movw   $0xff01,0xa3a(%r13)
  677912:	00 01 ff 
  677915:	41 c6 85 3c 0a 00 00 	movb   $0x0,0xa3c(%r13)
  67791c:	00 
  67791d:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
  677924:	00 
  677925:	e8 b6 a5 ff ff       	call   671ee0 <core::ptr::drop_glue::<core::result::Result<gpui_canvas::text::TextLayout, gpui_canvas::Error>>>
  67792a:	4c 89 f7             	mov    %r14,%rdi
  67792d:	e8 ae 66 10 00       	call   77dfe0 <_Unwind_Resume@plt>
  677932:	ff 15 a0 26 11 00    	call   *0x1126a0(%rip)        # 789fd8 <_DYNAMIC+0x258>
  677938:	eb 55                	jmp    67798f <<gpui_canvas::text::planner::Planner>::shape+0x392f>
  67793a:	49 89 c6             	mov    %rax,%r14
  67793d:	48 8b b4 24 10 07 00 	mov    0x710(%rsp),%rsi
  677944:	00 
  677945:	b3 01                	mov    $0x1,%bl
  677947:	48 85 f6             	test   %rsi,%rsi
  67794a:	75 11                	jne    67795d <<gpui_canvas::text::planner::Planner>::shape+0x38fd>
  67794c:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  677953:	00 ff 
  677955:	75 48                	jne    67799f <<gpui_canvas::text::planner::Planner>::shape+0x393f>
  677957:	84 db                	test   %bl,%bl
  677959:	75 55                	jne    6779b0 <<gpui_canvas::text::planner::Planner>::shape+0x3950>
  67795b:	eb 77                	jmp    6779d4 <<gpui_canvas::text::planner::Planner>::shape+0x3974>
  67795d:	48 8b bc 24 18 07 00 	mov    0x718(%rsp),%rdi
  677964:	00 
  677965:	48 c1 e6 03          	shl    $0x3,%rsi
  677969:	ba 08 00 00 00       	mov    $0x8,%edx
  67796e:	ff 15 44 26 11 00    	call   *0x112644(%rip)        # 789fb8 <_DYNAMIC+0x238>
  677974:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  67797b:	00 ff 
  67797d:	74 d8                	je     677957 <<gpui_canvas::text::planner::Planner>::shape+0x38f7>
  67797f:	eb 1e                	jmp    67799f <<gpui_canvas::text::planner::Planner>::shape+0x393f>
  677981:	eb 0c                	jmp    67798f <<gpui_canvas::text::planner::Planner>::shape+0x392f>
  677983:	eb 0a                	jmp    67798f <<gpui_canvas::text::planner::Planner>::shape+0x392f>
  677985:	eb 08                	jmp    67798f <<gpui_canvas::text::planner::Planner>::shape+0x392f>
  677987:	eb 06                	jmp    67798f <<gpui_canvas::text::planner::Planner>::shape+0x392f>
  677989:	eb 04                	jmp    67798f <<gpui_canvas::text::planner::Planner>::shape+0x392f>
  67798b:	eb 02                	jmp    67798f <<gpui_canvas::text::planner::Planner>::shape+0x392f>
  67798d:	eb 00                	jmp    67798f <<gpui_canvas::text::planner::Planner>::shape+0x392f>
  67798f:	49 89 c6             	mov    %rax,%r14
  677992:	b3 01                	mov    $0x1,%bl
  677994:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  67799b:	00 ff 
  67799d:	74 b8                	je     677957 <<gpui_canvas::text::planner::Planner>::shape+0x38f7>
  67799f:	48 8d bc 24 50 01 00 	lea    0x150(%rsp),%rdi
  6779a6:	00 
  6779a7:	e8 44 bc ff ff       	call   6735f0 <core::ptr::drop_glue::<gpui_canvas::text::layout::TextGeometry>>
  6779ac:	84 db                	test   %bl,%bl
  6779ae:	74 24                	je     6779d4 <<gpui_canvas::text::planner::Planner>::shape+0x3974>
  6779b0:	48 8b b4 24 e8 00 00 	mov    0xe8(%rsp),%rsi
  6779b7:	00 
  6779b8:	48 85 f6             	test   %rsi,%rsi
  6779bb:	74 17                	je     6779d4 <<gpui_canvas::text::planner::Planner>::shape+0x3974>
  6779bd:	48 8b bc 24 f0 00 00 	mov    0xf0(%rsp),%rdi
  6779c4:	00 
  6779c5:	48 c1 e6 04          	shl    $0x4,%rsi
  6779c9:	ba 04 00 00 00       	mov    $0x4,%edx
  6779ce:	ff 15 e4 25 11 00    	call   *0x1125e4(%rip)        # 789fb8 <_DYNAMIC+0x238>
  6779d4:	48 8d bc 24 a0 02 00 	lea    0x2a0(%rsp),%rdi
  6779db:	00 
  6779dc:	e8 ef a3 ff ff       	call   671dd0 <core::ptr::drop_glue::<[parlance::font_family::FontFamilyName; 3]>>
  6779e1:	4c 89 f7             	mov    %r14,%rdi
  6779e4:	e8 f7 65 10 00       	call   77dfe0 <_Unwind_Resume@plt>
