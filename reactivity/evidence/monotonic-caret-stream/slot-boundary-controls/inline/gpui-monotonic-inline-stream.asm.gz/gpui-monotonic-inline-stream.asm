
/tmp/gpui-monotonic-control-bin/stream-inline:     file format elf64-x86-64


Disassembly of section .text:

0000000000667ba0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>>:
  667ba0:	55                   	push   %rbp
  667ba1:	41 57                	push   %r15
  667ba3:	41 56                	push   %r14
  667ba5:	41 55                	push   %r13
  667ba7:	41 54                	push   %r12
  667ba9:	53                   	push   %rbx
  667baa:	48 81 ec a8 07 00 00 	sub    $0x7a8,%rsp
  667bb1:	49 89 fd             	mov    %rdi,%r13
  667bb4:	4c 8b 87 50 01 00 00 	mov    0x150(%rdi),%r8
  667bbb:	4c 89 c0             	mov    %r8,%rax
  667bbe:	48 c1 e8 20          	shr    $0x20,%rax
  667bc2:	74 10                	je     667bd4 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x34>
  667bc4:	4c 89 ef             	mov    %r13,%rdi
  667bc7:	e8 44 2c 00 00       	call   66a810 <parley::editing::geometry::visit_indexed::<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>>
  667bcc:	41 89 c6             	mov    %eax,%r14d
  667bcf:	e9 00 19 00 00       	jmp    6694d4 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1934>
  667bd4:	f3 0f 11 44 24 0c    	movss  %xmm0,0xc(%rsp)
  667bda:	41 be fe ff ff ff    	mov    $0xfffffffe,%r14d
  667be0:	41 83 7d 74 00       	cmpl   $0x0,0x74(%r13)
  667be5:	0f 85 cb 18 00 00    	jne    6694b6 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1916>
  667beb:	49 8b bd 18 01 00 00 	mov    0x118(%r13),%rdi
  667bf2:	48 89 f8             	mov    %rdi,%rax
  667bf5:	48 c1 e8 20          	shr    $0x20,%rax
  667bf9:	0f 85 b7 18 00 00    	jne    6694b6 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1916>
  667bff:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  667c04:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
  667c0b:	00 
  667c0c:	48 c7 84 24 40 01 00 	movq   $0x0,0x140(%rsp)
  667c13:	00 00 00 00 00 
  667c18:	48 c7 84 24 48 01 00 	movq   $0x4,0x148(%rsp)
  667c1f:	00 04 00 00 00 
  667c24:	48 c7 84 24 50 01 00 	movq   $0x0,0x150(%rsp)
  667c2b:	00 00 00 00 00 
  667c30:	49 8b 8d 10 01 00 00 	mov    0x110(%r13),%rcx
  667c37:	48 6b c7 70          	imul   $0x70,%rdi,%rax
  667c3b:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
  667c40:	48 01 c8             	add    %rcx,%rax
  667c43:	48 89 84 24 70 01 00 	mov    %rax,0x170(%rsp)
  667c4a:	00 
  667c4b:	48 85 ff             	test   %rdi,%rdi
  667c4e:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
  667c53:	48 89 94 24 a8 00 00 	mov    %rdx,0xa8(%rsp)
  667c5a:	00 
  667c5b:	48 89 bc 24 18 01 00 	mov    %rdi,0x118(%rsp)
  667c62:	00 
  667c63:	0f 84 80 03 00 00    	je     667fe9 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x449>
  667c69:	49 8b 85 30 01 00 00 	mov    0x130(%r13),%rax
  667c70:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  667c77:	00 
  667c78:	4d 8b a5 28 01 00 00 	mov    0x128(%r13),%r12
  667c7f:	49 8b 45 50          	mov    0x50(%r13),%rax
  667c83:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  667c88:	49 8b 45 58          	mov    0x58(%r13),%rax
  667c8c:	49 8b 8d e8 00 00 00 	mov    0xe8(%r13),%rcx
  667c93:	48 39 c8             	cmp    %rcx,%rax
  667c96:	48 0f 42 c8          	cmovb  %rax,%rcx
  667c9a:	48 89 8c 24 80 00 00 	mov    %rcx,0x80(%rsp)
  667ca1:	00 
  667ca2:	49 8b 85 e0 00 00 00 	mov    0xe0(%r13),%rax
  667ca9:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
  667cb0:	00 
  667cb1:	4d 85 c0             	test   %r8,%r8
  667cb4:	4c 89 a4 24 c8 00 00 	mov    %r12,0xc8(%rsp)
  667cbb:	00 
  667cbc:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
  667cc1:	0f 84 76 03 00 00    	je     66803d <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x49d>
  667cc7:	4c 89 44 24 50       	mov    %r8,0x50(%rsp)
  667ccc:	48 c7 84 24 b0 00 00 	movq   $0x0,0xb0(%rsp)
  667cd3:	00 00 00 00 00 
  667cd8:	48 8d 9c 24 30 03 00 	lea    0x330(%rsp),%rbx
  667cdf:	00 
  667ce0:	4c 8d 84 24 f8 00 00 	lea    0xf8(%rsp),%r8
  667ce7:	00 
  667ce8:	4c 8d 8c 24 40 01 00 	lea    0x140(%rsp),%r9
  667cef:	00 
  667cf0:	41 be ff ff ff ff    	mov    $0xffffffff,%r14d
  667cf6:	48 c7 44 24 60 00 00 	movq   $0x0,0x60(%rsp)
  667cfd:	00 00 
  667cff:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
  667d06:	00 00 
  667d08:	4c 8b 64 24 48       	mov    0x48(%rsp),%r12
  667d0d:	48 c7 84 24 90 00 00 	movq   $0x0,0x90(%rsp)
  667d14:	00 00 00 00 00 
  667d19:	eb 35                	jmp    667d50 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1b0>
  667d1b:	48 8b 4c 24 58       	mov    0x58(%rsp),%rcx
  667d20:	49 89 cc             	mov    %rcx,%r12
  667d23:	8b 84 24 c0 00 00 00 	mov    0xc0(%rsp),%eax
  667d2a:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
  667d31:	00 
  667d32:	48 3b 8c 24 70 01 00 	cmp    0x170(%rsp),%rcx
  667d39:	00 
  667d3a:	4c 8d 84 24 f8 00 00 	lea    0xf8(%rsp),%r8
  667d41:	00 
  667d42:	4c 8d 8c 24 40 01 00 	lea    0x140(%rsp),%r9
  667d49:	00 
  667d4a:	0f 84 a2 02 00 00    	je     667ff2 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x452>
  667d50:	49 8b 54 24 10       	mov    0x10(%r12),%rdx
  667d55:	49 8b 4c 24 18       	mov    0x18(%r12),%rcx
  667d5a:	48 89 df             	mov    %rbx,%rdi
  667d5d:	4c 89 ee             	mov    %r13,%rsi
  667d60:	e8 bb 26 00 00       	call   66a420 <parley::editing::geometry::source_runs::<()>>
  667d65:	4c 8b bc 24 38 03 00 	mov    0x338(%rsp),%r15
  667d6c:	00 
  667d6d:	4d 85 ff             	test   %r15,%r15
  667d70:	0f 84 08 16 00 00    	je     66937e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x17de>
  667d76:	4c 89 a4 24 20 01 00 	mov    %r12,0x120(%rsp)
  667d7d:	00 
  667d7e:	49 8d 44 24 70       	lea    0x70(%r12),%rax
  667d83:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  667d88:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  667d8f:	00 
  667d90:	ff c0                	inc    %eax
  667d92:	89 84 24 c0 00 00 00 	mov    %eax,0xc0(%rsp)
  667d99:	48 8b 84 24 40 03 00 	mov    0x340(%rsp),%rax
  667da0:	00 
  667da1:	4d 8d 24 c7          	lea    (%r15,%rax,8),%r12
  667da5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  667dac:	00 00 00 00 
  667db0:	4d 39 e7             	cmp    %r12,%r15
  667db3:	0f 84 62 ff ff ff    	je     667d1b <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x17b>
  667db9:	41 8b 07             	mov    (%r15),%eax
  667dbc:	49 83 c7 08          	add    $0x8,%r15
  667dc0:	4c 39 f0             	cmp    %r14,%rax
  667dc3:	74 eb                	je     667db0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x210>
  667dc5:	48 8b 94 24 20 01 00 	mov    0x120(%rsp),%rdx
  667dcc:	00 
  667dcd:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
  667dd1:	48 01 c1             	add    %rax,%rcx
  667dd4:	41 be fe ff ff ff    	mov    $0xfffffffe,%r14d
  667dda:	40 b7 01             	mov    $0x1,%dil
  667ddd:	48 3b 4a 18          	cmp    0x18(%rdx),%rcx
  667de1:	0f 83 9d 16 00 00    	jae    669484 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18e4>
  667de7:	48 3b 8c 24 00 01 00 	cmp    0x100(%rsp),%rcx
  667dee:	00 
  667def:	0f 83 8f 16 00 00    	jae    669484 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18e4>
  667df5:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
  667df9:	48 8b 94 24 c8 00 00 	mov    0xc8(%rsp),%rdx
  667e00:	00 
  667e01:	80 7c ca 21 00       	cmpb   $0x0,0x21(%rdx,%rcx,8)
  667e06:	0f 85 78 16 00 00    	jne    669484 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18e4>
  667e0c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
  667e10:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
  667e14:	48 3b 8c 24 80 00 00 	cmp    0x80(%rsp),%rcx
  667e1b:	00 
  667e1c:	0f 83 62 16 00 00    	jae    669484 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18e4>
  667e22:	4c 8d 04 c9          	lea    (%rcx,%rcx,8),%r8
  667e26:	49 c1 e0 04          	shl    $0x4,%r8
  667e2a:	4c 03 44 24 20       	add    0x20(%rsp),%r8
  667e2f:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
  667e33:	48 c1 e6 04          	shl    $0x4,%rsi
  667e37:	48 03 b4 24 d0 00 00 	add    0xd0(%rsp),%rsi
  667e3e:	00 
  667e3f:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  667e44:	48 89 bc 24 30 03 00 	mov    %rdi,0x330(%rsp)
  667e4b:	00 
  667e4c:	4c 89 84 24 68 01 00 	mov    %r8,0x168(%rsp)
  667e53:	00 
  667e54:	4c 89 84 24 38 03 00 	mov    %r8,0x338(%rsp)
  667e5b:	00 
  667e5c:	48 89 b4 24 40 03 00 	mov    %rsi,0x340(%rsp)
  667e63:	00 
  667e64:	48 89 94 24 48 03 00 	mov    %rdx,0x348(%rsp)
  667e6b:	00 
  667e6c:	48 8b 94 24 90 00 00 	mov    0x90(%rsp),%rdx
  667e73:	00 
  667e74:	89 94 24 50 03 00 00 	mov    %edx,0x350(%rsp)
  667e7b:	89 84 24 54 03 00 00 	mov    %eax,0x354(%rsp)
  667e82:	89 8c 24 58 03 00 00 	mov    %ecx,0x358(%rsp)
  667e89:	4c 8d b4 24 98 06 00 	lea    0x698(%rsp),%r14
  667e90:	00 
  667e91:	4c 89 f7             	mov    %r14,%rdi
  667e94:	48 89 de             	mov    %rbx,%rsi
  667e97:	31 d2                	xor    %edx,%edx
  667e99:	e8 c2 94 01 00       	call   681360 <<parley::layout::run::Clusters<()>>::new>
  667e9e:	ba 10 01 00 00       	mov    $0x110,%edx
  667ea3:	48 89 df             	mov    %rbx,%rdi
  667ea6:	4c 89 f6             	mov    %r14,%rsi
  667ea9:	ff 15 a1 21 12 00    	call   *0x1221a1(%rip)        # 78a050 <memcpy@GLIBC_2.14>
  667eaf:	45 31 ed             	xor    %r13d,%r13d
  667eb2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  667eb9:	1f 84 00 00 00 00 00 
  667ec0:	41 be ff ff ff ff    	mov    $0xffffffff,%r14d
  667ec6:	48 8d bc 24 00 02 00 	lea    0x200(%rsp),%rdi
  667ecd:	00 
  667ece:	48 89 dd             	mov    %rbx,%rbp
  667ed1:	48 89 de             	mov    %rbx,%rsi
  667ed4:	e8 e7 bc 01 00       	call   683bc0 <<parley::layout::run::Clusters<()> as core::iter::traits::iterator::Iterator>::next>
  667ed9:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  667ede:	4a 8d 1c 28          	lea    (%rax,%r13,1),%rbx
  667ee2:	48 8b 84 24 00 02 00 	mov    0x200(%rsp),%rax
  667ee9:	00 
  667eea:	48 85 c0             	test   %rax,%rax
  667eed:	0f 84 c0 00 00 00    	je     667fb3 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x413>
  667ef3:	8b bc 24 28 02 00 00 	mov    0x228(%rsp),%edi
  667efa:	48 8b 70 58          	mov    0x58(%rax),%rsi
  667efe:	48 39 fe             	cmp    %rdi,%rsi
  667f01:	0f 86 29 16 00 00    	jbe    669530 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1990>
  667f07:	8b b4 24 80 02 00 00 	mov    0x280(%rsp),%esi
  667f0e:	8b 94 24 84 02 00 00 	mov    0x284(%rsp),%edx
  667f15:	48 8b 48 50          	mov    0x50(%rax),%rcx
  667f19:	48 8d 3c ff          	lea    (%rdi,%rdi,8),%rdi
  667f1d:	48 c1 e7 04          	shl    $0x4,%rdi
  667f21:	0f 10 40 68          	movups 0x68(%rax),%xmm0
  667f25:	0f 10 88 80 00 00 00 	movups 0x80(%rax),%xmm1
  667f2c:	0f 10 90 98 00 00 00 	movups 0x98(%rax),%xmm2
  667f33:	0f 11 84 24 88 05 00 	movups %xmm0,0x588(%rsp)
  667f3a:	00 
  667f3b:	0f 11 8c 24 98 05 00 	movups %xmm1,0x598(%rsp)
  667f42:	00 
  667f43:	0f 11 94 24 a8 05 00 	movups %xmm2,0x5a8(%rsp)
  667f4a:	00 
  667f4b:	48 8b 44 39 50       	mov    0x50(%rcx,%rdi,1),%rax
  667f50:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
  667f57:	00 
  667f58:	48 8d bc 24 88 05 00 	lea    0x588(%rsp),%rdi
  667f5f:	00 
  667f60:	ff 15 d2 23 12 00    	call   *0x1223d2(%rip)        # 78a338 <_DYNAMIC+0x5b8>
  667f66:	41 be fe ff ff ff    	mov    $0xfffffffe,%r14d
  667f6c:	40 b7 01             	mov    $0x1,%dil
  667f6f:	48 39 d0             	cmp    %rdx,%rax
  667f72:	0f 87 0c 15 00 00    	ja     669484 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18e4>
  667f78:	48 3b 54 24 50       	cmp    0x50(%rsp),%rdx
  667f7d:	0f 87 01 15 00 00    	ja     669484 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18e4>
  667f83:	48 39 d0             	cmp    %rdx,%rax
  667f86:	73 16                	jae    667f9e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x3fe>
  667f88:	48 3b 84 24 b0 00 00 	cmp    0xb0(%rsp),%rax
  667f8f:	00 
  667f90:	48 89 94 24 b0 00 00 	mov    %rdx,0xb0(%rsp)
  667f97:	00 
  667f98:	0f 82 b4 14 00 00    	jb     669452 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18b2>
  667f9e:	48 c1 eb 20          	shr    $0x20,%rbx
  667fa2:	0f 85 dc 14 00 00    	jne    669484 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18e4>
  667fa8:	49 ff c5             	inc    %r13
  667fab:	48 89 eb             	mov    %rbp,%rbx
  667fae:	e9 0d ff ff ff       	jmp    667ec0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x320>
  667fb3:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  667fb8:	49 39 c5             	cmp    %rax,%r13
  667fbb:	4c 0f 46 e8          	cmovbe %rax,%r13
  667fbf:	48 8b 8c 24 68 01 00 	mov    0x168(%rsp),%rcx
  667fc6:	00 
  667fc7:	f6 81 8c 00 00 00 01 	testb  $0x1,0x8c(%rcx)
  667fce:	49 0f 45 c5          	cmovne %r13,%rax
  667fd2:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  667fd7:	48 89 5c 24 30       	mov    %rbx,0x30(%rsp)
  667fdc:	4c 8b 6c 24 10       	mov    0x10(%rsp),%r13
  667fe1:	48 89 eb             	mov    %rbp,%rbx
  667fe4:	e9 c7 fd ff ff       	jmp    667db0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x210>
  667fe9:	48 c7 44 24 60 00 00 	movq   $0x0,0x60(%rsp)
  667ff0:	00 00 
  667ff2:	4c 8b 7c 24 60       	mov    0x60(%rsp),%r15
  667ff7:	4e 8d 34 bd 00 00 00 	lea    0x0(,%r15,4),%r14
  667ffe:	00 
  667fff:	4c 89 f8             	mov    %r15,%rax
  668002:	48 c1 e8 3e          	shr    $0x3e,%rax
  668006:	0f 95 c0             	setne  %al
  668009:	48 b9 fc ff ff ff ff 	movabs $0x7ffffffffffffffc,%rcx
  668010:	ff ff 7f 
  668013:	49 39 ce             	cmp    %rcx,%r14
  668016:	0f 97 c1             	seta   %cl
  668019:	08 c1                	or     %al,%cl
  66801b:	0f 84 3a 02 00 00    	je     66825b <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x6bb>
  668021:	45 31 e4             	xor    %r12d,%r12d
  668024:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
  668029:	40 b5 01             	mov    $0x1,%bpl
  66802c:	4c 89 e7             	mov    %r12,%rdi
  66802f:	4c 89 f6             	mov    %r14,%rsi
  668032:	ff 15 98 20 12 00    	call   *0x122098(%rip)        # 78a0d0 <_DYNAMIC+0x350>
  668038:	e9 f7 15 00 00       	jmp    669634 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a94>
  66803d:	48 c7 44 24 60 00 00 	movq   $0x0,0x60(%rsp)
  668044:	00 00 
  668046:	48 8d ac 24 30 03 00 	lea    0x330(%rsp),%rbp
  66804d:	00 
  66804e:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
  668053:	48 c7 84 24 90 00 00 	movq   $0x0,0x90(%rsp)
  66805a:	00 00 00 00 00 
  66805f:	4c 8b 74 24 48       	mov    0x48(%rsp),%r14
  668064:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
  66806b:	00 00 
  66806d:	eb 27                	jmp    668096 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x4f6>
  66806f:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
  668074:	49 89 ce             	mov    %rcx,%r14
  668077:	8b 84 24 b0 00 00 00 	mov    0xb0(%rsp),%eax
  66807e:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  668083:	48 3b 8c 24 70 01 00 	cmp    0x170(%rsp),%rcx
  66808a:	00 
  66808b:	4c 8b 6c 24 10       	mov    0x10(%rsp),%r13
  668090:	0f 84 5c ff ff ff    	je     667ff2 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x452>
  668096:	49 8b 56 10          	mov    0x10(%r14),%rdx
  66809a:	49 8b 4e 18          	mov    0x18(%r14),%rcx
  66809e:	48 89 ef             	mov    %rbp,%rdi
  6680a1:	4c 89 ee             	mov    %r13,%rsi
  6680a4:	4c 8d 84 24 f8 00 00 	lea    0xf8(%rsp),%r8
  6680ab:	00 
  6680ac:	4c 8d 8c 24 40 01 00 	lea    0x140(%rsp),%r9
  6680b3:	00 
  6680b4:	e8 67 23 00 00       	call   66a420 <parley::editing::geometry::source_runs::<()>>
  6680b9:	4c 8b bc 24 38 03 00 	mov    0x338(%rsp),%r15
  6680c0:	00 
  6680c1:	4d 85 ff             	test   %r15,%r15
  6680c4:	0f 84 b4 12 00 00    	je     66937e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x17de>
  6680ca:	49 8d 46 70          	lea    0x70(%r14),%rax
  6680ce:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  6680d3:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  6680d8:	ff c0                	inc    %eax
  6680da:	89 84 24 b0 00 00 00 	mov    %eax,0xb0(%rsp)
  6680e1:	48 8b 84 24 40 03 00 	mov    0x340(%rsp),%rax
  6680e8:	00 
  6680e9:	4d 8d 2c c7          	lea    (%r15,%rax,8),%r13
  6680ed:	0f 1f 00             	nopl   (%rax)
  6680f0:	4d 39 ef             	cmp    %r13,%r15
  6680f3:	0f 84 76 ff ff ff    	je     66806f <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x4cf>
  6680f9:	41 8b 07             	mov    (%r15),%eax
  6680fc:	49 83 c7 08          	add    $0x8,%r15
  668100:	48 39 d8             	cmp    %rbx,%rax
  668103:	74 eb                	je     6680f0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x550>
  668105:	49 8b 4e 10          	mov    0x10(%r14),%rcx
  668109:	48 01 c1             	add    %rax,%rcx
  66810c:	4c 89 f2             	mov    %r14,%rdx
  66810f:	41 be fe ff ff ff    	mov    $0xfffffffe,%r14d
  668115:	40 b7 01             	mov    $0x1,%dil
  668118:	48 89 54 24 58       	mov    %rdx,0x58(%rsp)
  66811d:	48 3b 4a 18          	cmp    0x18(%rdx),%rcx
  668121:	0f 83 5d 13 00 00    	jae    669484 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18e4>
  668127:	48 3b 8c 24 00 01 00 	cmp    0x100(%rsp),%rcx
  66812e:	00 
  66812f:	0f 83 4f 13 00 00    	jae    669484 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18e4>
  668135:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
  668139:	41 80 7c cc 21 00    	cmpb   $0x0,0x21(%r12,%rcx,8)
  66813f:	0f 85 3f 13 00 00    	jne    669484 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18e4>
  668145:	49 8d 14 cc          	lea    (%r12,%rcx,8),%rdx
  668149:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
  66814d:	48 3b 8c 24 80 00 00 	cmp    0x80(%rsp),%rcx
  668154:	00 
  668155:	0f 83 29 13 00 00    	jae    669484 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18e4>
  66815b:	4c 8d 34 c9          	lea    (%rcx,%rcx,8),%r14
  66815f:	49 c1 e6 04          	shl    $0x4,%r14
  668163:	4c 03 74 24 20       	add    0x20(%rsp),%r14
  668168:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
  66816c:	48 c1 e6 04          	shl    $0x4,%rsi
  668170:	48 03 b4 24 d0 00 00 	add    0xd0(%rsp),%rsi
  668177:	00 
  668178:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  66817d:	48 89 bc 24 30 03 00 	mov    %rdi,0x330(%rsp)
  668184:	00 
  668185:	4c 89 b4 24 38 03 00 	mov    %r14,0x338(%rsp)
  66818c:	00 
  66818d:	48 89 b4 24 40 03 00 	mov    %rsi,0x340(%rsp)
  668194:	00 
  668195:	48 89 94 24 48 03 00 	mov    %rdx,0x348(%rsp)
  66819c:	00 
  66819d:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
  6681a2:	89 94 24 50 03 00 00 	mov    %edx,0x350(%rsp)
  6681a9:	89 84 24 54 03 00 00 	mov    %eax,0x354(%rsp)
  6681b0:	89 8c 24 58 03 00 00 	mov    %ecx,0x358(%rsp)
  6681b7:	4c 8d a4 24 98 06 00 	lea    0x698(%rsp),%r12
  6681be:	00 
  6681bf:	4c 89 e7             	mov    %r12,%rdi
  6681c2:	48 89 ee             	mov    %rbp,%rsi
  6681c5:	31 d2                	xor    %edx,%edx
  6681c7:	e8 94 91 01 00       	call   681360 <<parley::layout::run::Clusters<()>>::new>
  6681cc:	ba 10 01 00 00       	mov    $0x110,%edx
  6681d1:	48 89 eb             	mov    %rbp,%rbx
  6681d4:	48 89 ef             	mov    %rbp,%rdi
  6681d7:	4c 89 e6             	mov    %r12,%rsi
  6681da:	ff 15 70 1e 12 00    	call   *0x121e70(%rip)        # 78a050 <memcpy@GLIBC_2.14>
  6681e0:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  6681e7:	00 
  6681e8:	4c 8d 60 01          	lea    0x1(%rax),%r12
  6681ec:	31 ed                	xor    %ebp,%ebp
  6681ee:	66 90                	xchg   %ax,%ax
  6681f0:	48 8d bc 24 00 02 00 	lea    0x200(%rsp),%rdi
  6681f7:	00 
  6681f8:	48 89 de             	mov    %rbx,%rsi
  6681fb:	e8 c0 b9 01 00       	call   683bc0 <<parley::layout::run::Clusters<()> as core::iter::traits::iterator::Iterator>::next>
  668200:	48 83 bc 24 00 02 00 	cmpq   $0x0,0x200(%rsp)
  668207:	00 00 
  668209:	74 0e                	je     668219 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x679>
  66820b:	49 39 ec             	cmp    %rbp,%r12
  66820e:	0f 84 67 12 00 00    	je     66947b <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18db>
  668214:	48 ff cd             	dec    %rbp
  668217:	eb d7                	jmp    6681f0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x650>
  668219:	48 29 ac 24 90 00 00 	sub    %rbp,0x90(%rsp)
  668220:	00 
  668221:	48 f7 dd             	neg    %rbp
  668224:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  668229:	48 39 c5             	cmp    %rax,%rbp
  66822c:	48 0f 46 e8          	cmovbe %rax,%rbp
  668230:	41 f6 86 8c 00 00 00 	testb  $0x1,0x8c(%r14)
  668237:	01 
  668238:	48 0f 45 c5          	cmovne %rbp,%rax
  66823c:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  668241:	4c 8b a4 24 c8 00 00 	mov    0xc8(%rsp),%r12
  668248:	00 
  668249:	48 89 dd             	mov    %rbx,%rbp
  66824c:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
  668251:	4c 8b 74 24 58       	mov    0x58(%rsp),%r14
  668256:	e9 95 fe ff ff       	jmp    6680f0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x550>
  66825b:	4d 85 f6             	test   %r14,%r14
  66825e:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
  668263:	74 24                	je     668289 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x6e9>
  668265:	ff 15 dd 1d 12 00    	call   *0x121ddd(%rip)        # 78a048 <_DYNAMIC+0x2c8>
  66826b:	41 bc 04 00 00 00    	mov    $0x4,%r12d
  668271:	be 04 00 00 00       	mov    $0x4,%esi
  668276:	4c 89 f7             	mov    %r14,%rdi
  668279:	ff 15 31 1d 12 00    	call   *0x121d31(%rip)        # 789fb0 <_DYNAMIC+0x230>
  66827f:	48 85 c0             	test   %rax,%rax
  668282:	75 0d                	jne    668291 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x6f1>
  668284:	e9 a0 fd ff ff       	jmp    668029 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x489>
  668289:	b8 04 00 00 00       	mov    $0x4,%eax
  66828e:	45 31 ff             	xor    %r15d,%r15d
  668291:	4c 89 bc 24 28 01 00 	mov    %r15,0x128(%rsp)
  668298:	00 
  668299:	48 89 84 24 30 01 00 	mov    %rax,0x130(%rsp)
  6682a0:	00 
  6682a1:	48 c7 84 24 38 01 00 	movq   $0x0,0x138(%rsp)
  6682a8:	00 00 00 00 00 
  6682ad:	48 8d bc 24 60 04 00 	lea    0x460(%rsp),%rdi
  6682b4:	00 
  6682b5:	ba 98 00 00 00       	mov    $0x98,%edx
  6682ba:	48 89 de             	mov    %rbx,%rsi
  6682bd:	ff 15 8d 1d 12 00    	call   *0x121d8d(%rip)        # 78a050 <memcpy@GLIBC_2.14>
  6682c3:	48 c7 84 24 50 04 00 	movq   $0x2,0x450(%rsp)
  6682ca:	00 02 00 00 00 
  6682cf:	48 83 bc 24 18 01 00 	cmpq   $0x0,0x118(%rsp)
  6682d6:	00 00 
  6682d8:	0f 84 67 10 00 00    	je     669345 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x17a5>
  6682de:	49 8b 85 30 01 00 00 	mov    0x130(%r13),%rax
  6682e5:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  6682ea:	49 8b 45 58          	mov    0x58(%r13),%rax
  6682ee:	49 8b 8d e8 00 00 00 	mov    0xe8(%r13),%rcx
  6682f5:	48 39 c8             	cmp    %rcx,%rax
  6682f8:	48 89 8c 24 18 01 00 	mov    %rcx,0x118(%rsp)
  6682ff:	00 
  668300:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
  668307:	00 
  668308:	48 0f 42 c8          	cmovb  %rax,%rcx
  66830c:	48 89 8c 24 28 03 00 	mov    %rcx,0x328(%rsp)
  668313:	00 
  668314:	49 8b 85 28 01 00 00 	mov    0x128(%r13),%rax
  66831b:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  668322:	00 
  668323:	49 8b 85 e0 00 00 00 	mov    0xe0(%r13),%rax
  66832a:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
  668331:	00 
  668332:	49 8b 45 50          	mov    0x50(%r13),%rax
  668336:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
  66833d:	00 
  66833e:	48 8d ac 24 38 03 00 	lea    0x338(%rsp),%rbp
  668345:	00 
  668346:	49 8b 45 38          	mov    0x38(%r13),%rax
  66834a:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
  668351:	00 
  668352:	49 8b 45 40          	mov    0x40(%r13),%rax
  668356:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  66835d:	00 
  66835e:	48 8d bc 24 30 03 00 	lea    0x330(%rsp),%rdi
  668365:	00 
  668366:	4c 8d 84 24 f8 00 00 	lea    0xf8(%rsp),%r8
  66836d:	00 
  66836e:	4c 8d 8c 24 40 01 00 	lea    0x140(%rsp),%r9
  668375:	00 
  668376:	48 8d 05 e3 70 11 00 	lea    0x1170e3(%rip),%rax        # 77f460 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0xc0>
  66837d:	48 89 84 24 c0 01 00 	mov    %rax,0x1c0(%rsp)
  668384:	00 
  668385:	48 8d 05 94 71 11 00 	lea    0x117194(%rip),%rax        # 77f520 <anon.98eb2121465841304e196c1cc83cb241.21.llvm.14436572662246312189>
  66838c:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  668391:	45 31 f6             	xor    %r14d,%r14d
  668394:	48 c7 44 24 58 00 00 	movq   $0x0,0x58(%rsp)
  66839b:	00 00 
  66839d:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
  6683a2:	eb 30                	jmp    6683d4 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x834>
  6683a4:	4c 89 54 24 48       	mov    %r10,0x48(%rsp)
  6683a9:	44 89 d8             	mov    %r11d,%eax
  6683ac:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  6683b1:	4c 3b 94 24 70 01 00 	cmp    0x170(%rsp),%r10
  6683b8:	00 
  6683b9:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
  6683be:	48 8d bc 24 30 03 00 	lea    0x330(%rsp),%rdi
  6683c5:	00 
  6683c6:	4c 8b b4 24 a0 01 00 	mov    0x1a0(%rsp),%r14
  6683cd:	00 
  6683ce:	0f 84 71 0f 00 00    	je     669345 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x17a5>
  6683d4:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  6683d9:	48 8b 50 10          	mov    0x10(%rax),%rdx
  6683dd:	48 8b 48 18          	mov    0x18(%rax),%rcx
  6683e1:	4c 89 ee             	mov    %r13,%rsi
  6683e4:	e8 37 20 00 00       	call   66a420 <parley::editing::geometry::source_runs::<()>>
  6683e9:	48 8b 9c 24 38 03 00 	mov    0x338(%rsp),%rbx
  6683f0:	00 
  6683f1:	48 85 db             	test   %rbx,%rbx
  6683f4:	0f 84 18 11 00 00    	je     669512 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1972>
  6683fa:	4c 89 b4 24 a0 01 00 	mov    %r14,0x1a0(%rsp)
  668401:	00 
  668402:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  668407:	48 8b 78 10          	mov    0x10(%rax),%rdi
  66840b:	48 8b 70 18          	mov    0x18(%rax),%rsi
  66840f:	48 39 fe             	cmp    %rdi,%rsi
  668412:	0f 82 e3 10 00 00    	jb     6694fb <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x195b>
  668418:	48 3b 74 24 20       	cmp    0x20(%rsp),%rsi
  66841d:	0f 87 d8 10 00 00    	ja     6694fb <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x195b>
  668423:	4c 8b bc 24 40 03 00 	mov    0x340(%rsp),%r15
  66842a:	00 
  66842b:	48 39 f7             	cmp    %rsi,%rdi
  66842e:	0f 85 91 0d 00 00    	jne    6691c5 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1625>
  668434:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  668439:	4c 8d 50 70          	lea    0x70(%rax),%r10
  66843d:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  668442:	44 8d 58 01          	lea    0x1(%rax),%r11d
  668446:	4e 8d 34 fb          	lea    (%rbx,%r15,8),%r14
  66844a:	4c 8b 6c 24 10       	mov    0x10(%rsp),%r13
  66844f:	4c 8d 84 24 f8 00 00 	lea    0xf8(%rsp),%r8
  668456:	00 
  668457:	4c 8d 8c 24 40 01 00 	lea    0x140(%rsp),%r9
  66845e:	00 
  66845f:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
  668464:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  66846b:	00 00 00 00 00 
  668470:	4c 39 f3             	cmp    %r14,%rbx
  668473:	0f 84 2b ff ff ff    	je     6683a4 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x804>
  668479:	8b 03                	mov    (%rbx),%eax
  66847b:	48 83 c3 08          	add    $0x8,%rbx
  66847f:	48 39 c8             	cmp    %rcx,%rax
  668482:	74 ec                	je     668470 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x8d0>
  668484:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
  668489:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
  66848d:	48 01 c1             	add    %rax,%rcx
  668490:	48 3b 4a 18          	cmp    0x18(%rdx),%rcx
  668494:	0f 83 63 11 00 00    	jae    6695fd <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a5d>
  66849a:	48 3b 4c 24 20       	cmp    0x20(%rsp),%rcx
  66849f:	0f 83 58 11 00 00    	jae    6695fd <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a5d>
  6684a5:	48 8d 14 89          	lea    (%rcx,%rcx,4),%rdx
  6684a9:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
  6684b0:	00 
  6684b1:	48 8b 4c d6 10       	mov    0x10(%rsi,%rdx,8),%rcx
  6684b6:	80 7c d6 21 01       	cmpb   $0x1,0x21(%rsi,%rdx,8)
  6684bb:	0f 84 1a 11 00 00    	je     6695db <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a3b>
  6684c1:	48 3b 8c 24 28 03 00 	cmp    0x328(%rsp),%rcx
  6684c8:	00 
  6684c9:	0f 83 2e 11 00 00    	jae    6695fd <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a5d>
  6684cf:	f3 0f 10 43 fc       	movss  -0x4(%rbx),%xmm0
  6684d4:	f3 0f 11 44 24 30    	movss  %xmm0,0x30(%rsp)
  6684da:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
  6684e1:	00 
  6684e2:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
  6684e6:	48 8d 34 c9          	lea    (%rcx,%rcx,8),%rsi
  6684ea:	48 c1 e6 04          	shl    $0x4,%rsi
  6684ee:	4c 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%r9
  6684f5:	00 
  6684f6:	49 8d 3c 31          	lea    (%r9,%rsi,1),%rdi
  6684fa:	4c 8d 04 89          	lea    (%rcx,%rcx,4),%r8
  6684fe:	49 c1 e0 04          	shl    $0x4,%r8
  668502:	4c 03 84 24 d0 00 00 	add    0xd0(%rsp),%r8
  668509:	00 
  66850a:	4c 89 ac 24 d0 01 00 	mov    %r13,0x1d0(%rsp)
  668511:	00 
  668512:	48 89 bc 24 d8 01 00 	mov    %rdi,0x1d8(%rsp)
  668519:	00 
  66851a:	4c 89 84 24 e0 01 00 	mov    %r8,0x1e0(%rsp)
  668521:	00 
  668522:	48 89 94 24 e8 01 00 	mov    %rdx,0x1e8(%rsp)
  668529:	00 
  66852a:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
  66852f:	89 94 24 f0 01 00 00 	mov    %edx,0x1f0(%rsp)
  668536:	89 84 24 f4 01 00 00 	mov    %eax,0x1f4(%rsp)
  66853d:	89 8c 24 f8 01 00 00 	mov    %ecx,0x1f8(%rsp)
  668544:	48 c7 84 24 38 01 00 	movq   $0x0,0x138(%rsp)
  66854b:	00 00 00 00 00 
  668550:	41 0f b6 84 31 8c 00 	movzbl 0x8c(%r9,%rsi,1),%eax
  668557:	00 00 
  668559:	88 44 24 2f          	mov    %al,0x2f(%rsp)
  66855d:	a8 01                	test   $0x1,%al
  66855f:	4c 89 94 24 20 03 00 	mov    %r10,0x320(%rsp)
  668566:	00 
  668567:	44 89 9c 24 9c 01 00 	mov    %r11d,0x19c(%rsp)
  66856e:	00 
  66856f:	4c 89 b4 24 18 03 00 	mov    %r14,0x318(%rsp)
  668576:	00 
  668577:	0f 85 2b 0a 00 00    	jne    668fa8 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1408>
  66857d:	48 8d bc 24 00 02 00 	lea    0x200(%rsp),%rdi
  668584:	00 
  668585:	48 8d b4 24 d0 01 00 	lea    0x1d0(%rsp),%rsi
  66858c:	00 
  66858d:	31 d2                	xor    %edx,%edx
  66858f:	e8 cc 8d 01 00       	call   681360 <<parley::layout::run::Clusters<()>>::new>
  668594:	ba 10 01 00 00       	mov    $0x110,%edx
  668599:	48 89 ef             	mov    %rbp,%rdi
  66859c:	4c 8d b4 24 00 02 00 	lea    0x200(%rsp),%r14
  6685a3:	00 
  6685a4:	4c 89 f6             	mov    %r14,%rsi
  6685a7:	ff 15 a3 1a 12 00    	call   *0x121aa3(%rip)        # 78a050 <memcpy@GLIBC_2.14>
  6685ad:	4c 89 f7             	mov    %r14,%rdi
  6685b0:	48 c7 84 24 30 03 00 	movq   $0x0,0x330(%rsp)
  6685b7:	00 00 00 00 00 
  6685bc:	0f 57 c0             	xorps  %xmm0,%xmm0
  6685bf:	f3 0f 11 84 24 8c 00 	movss  %xmm0,0x8c(%rsp)
  6685c6:	00 00 
  6685c8:	45 31 ed             	xor    %r13d,%r13d
  6685cb:	c7 44 24 44 00 00 00 	movl   $0x0,0x44(%rsp)
  6685d2:	00 
  6685d3:	48 89 ee             	mov    %rbp,%rsi
  6685d6:	e8 e5 b5 01 00       	call   683bc0 <<parley::layout::run::Clusters<()> as core::iter::traits::iterator::Iterator>::next>
  6685db:	4c 8b bc 24 00 02 00 	mov    0x200(%rsp),%r15
  6685e2:	00 
  6685e3:	4d 85 ff             	test   %r15,%r15
  6685e6:	0f 84 b4 0b 00 00    	je     6691a0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1600>
  6685ec:	ba 88 00 00 00       	mov    $0x88,%edx
  6685f1:	48 8d bc 24 00 05 00 	lea    0x500(%rsp),%rdi
  6685f8:	00 
  6685f9:	48 8d b4 24 08 02 00 	lea    0x208(%rsp),%rsi
  668600:	00 
  668601:	ff 15 49 1a 12 00    	call   *0x121a49(%rip)        # 78a050 <memcpy@GLIBC_2.14>
  668607:	4c 8b b4 24 30 03 00 	mov    0x330(%rsp),%r14
  66860e:	00 
  66860f:	49 8d 46 01          	lea    0x1(%r14),%rax
  668613:	48 89 84 24 30 03 00 	mov    %rax,0x330(%rsp)
  66861a:	00 
  66861b:	4c 89 bc 24 f8 04 00 	mov    %r15,0x4f8(%rsp)
  668622:	00 
  668623:	8b ac 24 20 05 00 00 	mov    0x520(%rsp),%ebp
  66862a:	49 8b 47 58          	mov    0x58(%r15),%rax
  66862e:	48 39 e8             	cmp    %rbp,%rax
  668631:	0f 86 78 0f 00 00    	jbe    6695af <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a0f>
  668637:	49 8b 47 50          	mov    0x50(%r15),%rax
  66863b:	48 8d 0c ed 00 00 00 	lea    0x0(,%rbp,8),%rcx
  668642:	00 
  668643:	48 01 e9             	add    %rbp,%rcx
  668646:	48 c1 e1 04          	shl    $0x4,%rcx
  66864a:	41 0f 10 47 68       	movups 0x68(%r15),%xmm0
  66864f:	41 0f 10 8f 80 00 00 	movups 0x80(%r15),%xmm1
  668656:	00 
  668657:	4c 89 7c 24 78       	mov    %r15,0x78(%rsp)
  66865c:	41 0f 10 97 98 00 00 	movups 0x98(%r15),%xmm2
  668663:	00 
  668664:	0f 11 84 24 00 02 00 	movups %xmm0,0x200(%rsp)
  66866b:	00 
  66866c:	0f 11 8c 24 10 02 00 	movups %xmm1,0x210(%rsp)
  668673:	00 
  668674:	0f 11 94 24 20 02 00 	movups %xmm2,0x220(%rsp)
  66867b:	00 
  66867c:	48 8b 44 08 50       	mov    0x50(%rax,%rcx,1),%rax
  668681:	48 89 84 24 30 02 00 	mov    %rax,0x230(%rsp)
  668688:	00 
  668689:	8b b4 24 78 05 00 00 	mov    0x578(%rsp),%esi
  668690:	8b 94 24 7c 05 00 00 	mov    0x57c(%rsp),%edx
  668697:	48 8d bc 24 00 02 00 	lea    0x200(%rsp),%rdi
  66869e:	00 
  66869f:	48 89 b4 24 60 01 00 	mov    %rsi,0x160(%rsp)
  6686a6:	00 
  6686a7:	48 89 94 24 58 01 00 	mov    %rdx,0x158(%rsp)
  6686ae:	00 
  6686af:	ff 15 83 1c 12 00    	call   *0x121c83(%rip)        # 78a338 <_DYNAMIC+0x5b8>
  6686b5:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
  6686ba:	49 89 c7             	mov    %rax,%r15
  6686bd:	f6 44 24 2f 01       	testb  $0x1,0x2f(%rsp)
  6686c2:	75 45                	jne    668709 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xb69>
  6686c4:	48 83 bc 24 10 05 00 	cmpq   $0x0,0x510(%rsp)
  6686cb:	00 00 
  6686cd:	0f 84 b2 00 00 00    	je     668785 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xbe5>
  6686d3:	8b 84 24 18 05 00 00 	mov    0x518(%rsp),%eax
  6686da:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
  6686df:	48 8b 8a 18 01 00 00 	mov    0x118(%rdx),%rcx
  6686e6:	48 39 c1             	cmp    %rax,%rcx
  6686e9:	0f 86 1e 0f 00 00    	jbe    66960d <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a6d>
  6686ef:	48 8b 8a 10 01 00 00 	mov    0x110(%rdx),%rcx
  6686f6:	48 6b c0 70          	imul   $0x70,%rax,%rax
  6686fa:	f3 0f 10 44 01 50    	movss  0x50(%rcx,%rax,1),%xmm0
  668700:	8b 44 01 54          	mov    0x54(%rcx,%rax,1),%eax
  668704:	e9 84 00 00 00       	jmp    66878d <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xbed>
  668709:	48 8b 84 24 38 01 00 	mov    0x138(%rsp),%rax
  668710:	00 
  668711:	49 f7 d6             	not    %r14
  668714:	49 01 c6             	add    %rax,%r14
  668717:	0f 83 ad 0e 00 00    	jae    6695ca <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a2a>
  66871d:	48 8b 84 24 30 01 00 	mov    0x130(%rsp),%rax
  668724:	00 
  668725:	f3 0f 10 84 24 8c 00 	movss  0x8c(%rsp),%xmm0
  66872c:	00 00 
  66872e:	f3 0f 11 84 24 b0 01 	movss  %xmm0,0x1b0(%rsp)
  668735:	00 00 
  668737:	f3 42 0f 10 04 b0    	movss  (%rax,%r14,4),%xmm0
  66873d:	f3 0f 11 84 24 8c 00 	movss  %xmm0,0x8c(%rsp)
  668744:	00 00 
  668746:	48 8b 84 24 50 04 00 	mov    0x450(%rsp),%rax
  66874d:	00 
  66874e:	48 83 f8 02          	cmp    $0x2,%rax
  668752:	4c 8b b4 24 a0 01 00 	mov    0x1a0(%rsp),%r14
  668759:	00 
  66875a:	0f 85 bf 00 00 00    	jne    66881f <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xc7f>
  668760:	48 8d bc 24 60 04 00 	lea    0x460(%rsp),%rdi
  668767:	00 
  668768:	e8 23 87 00 00       	call   670e90 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  66876d:	49 89 d4             	mov    %rdx,%r12
  668770:	48 89 84 24 50 04 00 	mov    %rax,0x450(%rsp)
  668777:	00 
  668778:	48 89 94 24 58 04 00 	mov    %rdx,0x458(%rsp)
  66877f:	00 
  668780:	e9 a2 00 00 00       	jmp    668827 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xc87>
  668785:	0f 57 c0             	xorps  %xmm0,%xmm0
  668788:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  66878d:	48 8b 8c 24 00 05 00 	mov    0x500(%rsp),%rcx
  668794:	00 
  668795:	48 8b 94 24 08 05 00 	mov    0x508(%rsp),%rdx
  66879c:	00 
  66879d:	f2 0f 10 4a 44       	movsd  0x44(%rdx),%xmm1
  6687a2:	f2 0f 11 8c 24 00 02 	movsd  %xmm1,0x200(%rsp)
  6687a9:	00 00 
  6687ab:	f3 0f 11 84 24 08 02 	movss  %xmm0,0x208(%rsp)
  6687b2:	00 00 
  6687b4:	89 84 24 0c 02 00 00 	mov    %eax,0x20c(%rsp)
  6687bb:	0f b6 89 8c 00 00 00 	movzbl 0x8c(%rcx),%ecx
  6687c2:	83 e1 01             	and    $0x1,%ecx
  6687c5:	48 8d bc 24 00 02 00 	lea    0x200(%rsp),%rdi
  6687cc:	00 
  6687cd:	48 8d b4 24 28 05 00 	lea    0x528(%rsp),%rsi
  6687d4:	00 
  6687d5:	48 8d 94 24 78 05 00 	lea    0x578(%rsp),%rdx
  6687dc:	00 
  6687dd:	ff 15 5d 1b 12 00    	call   *0x121b5d(%rip)        # 78a340 <_DYNAMIC+0x5c0>
  6687e3:	f3 0f 10 4c 24 30    	movss  0x30(%rsp),%xmm1
  6687e9:	f3 0f 58 c1          	addss  %xmm1,%xmm0
  6687ed:	f3 0f 11 8c 24 b0 01 	movss  %xmm1,0x1b0(%rsp)
  6687f4:	00 00 
  6687f6:	f3 0f 11 8c 24 8c 00 	movss  %xmm1,0x8c(%rsp)
  6687fd:	00 00 
  6687ff:	f3 0f 11 44 24 30    	movss  %xmm0,0x30(%rsp)
  668805:	48 8b 84 24 50 04 00 	mov    0x450(%rsp),%rax
  66880c:	00 
  66880d:	48 83 f8 02          	cmp    $0x2,%rax
  668811:	4c 8b b4 24 a0 01 00 	mov    0x1a0(%rsp),%r14
  668818:	00 
  668819:	0f 84 41 ff ff ff    	je     668760 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xbc0>
  66881f:	4c 8b a4 24 58 04 00 	mov    0x458(%rsp),%r12
  668826:	00 
  668827:	48 83 f8 01          	cmp    $0x1,%rax
  66882b:	0f 85 57 06 00 00    	jne    668e88 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x12e8>
  668831:	4c 3b 64 24 50       	cmp    0x50(%rsp),%r12
  668836:	4d 89 f8             	mov    %r15,%r8
  668839:	0f 83 4c 06 00 00    	jae    668e8b <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x12eb>
  66883f:	4c 3b a4 24 c8 01 00 	cmp    0x1c8(%rsp),%r12
  668846:	00 
  668847:	0f 92 c0             	setb   %al
  66884a:	41 84 c6             	test   %al,%r14b
  66884d:	0f 85 50 0b 00 00    	jne    6693a3 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1803>
  668853:	f3 0f 10 8c 24 b0 01 	movss  0x1b0(%rsp),%xmm1
  66885a:	00 00 
  66885c:	0f 57 c0             	xorps  %xmm0,%xmm0
  66885f:	f3 0f 5a c1          	cvtss2sd %xmm1,%xmm0
  668863:	0f 29 84 24 a0 01 00 	movaps %xmm0,0x1a0(%rsp)
  66886a:	00 
  66886b:	f3 0f 58 4c 24 0c    	addss  0xc(%rsp),%xmm1
  668871:	0f 57 c0             	xorps  %xmm0,%xmm0
  668874:	f3 0f 5a c1          	cvtss2sd %xmm1,%xmm0
  668878:	0f 29 84 24 b0 01 00 	movaps %xmm0,0x1b0(%rsp)
  66887f:	00 
  668880:	48 c7 84 24 50 04 00 	movq   $0x2,0x450(%rsp)
  668887:	00 02 00 00 00 
  66888c:	4d 39 c4             	cmp    %r8,%r12
  66888f:	0f 85 f8 00 00 00    	jne    66898d <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xded>
  668895:	4d 39 c5             	cmp    %r8,%r13
  668898:	0f 94 c0             	sete   %al
  66889b:	22 44 24 44          	and    0x44(%rsp),%al
  66889f:	3c 01                	cmp    $0x1,%al
  6688a1:	75 57                	jne    6688fa <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xd5a>
  6688a3:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
  6688a8:	48 8b 41 58          	mov    0x58(%rcx),%rax
  6688ac:	48 39 e8             	cmp    %rbp,%rax
  6688af:	0f 86 fa 0c 00 00    	jbe    6695af <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a0f>
  6688b5:	48 8b 51 70          	mov    0x70(%rcx),%rdx
  6688b9:	48 8b bc 24 60 01 00 	mov    0x160(%rsp),%rdi
  6688c0:	00 
  6688c1:	48 8b b4 24 58 01 00 	mov    0x158(%rsp),%rsi
  6688c8:	00 
  6688c9:	39 fe                	cmp    %edi,%esi
  6688cb:	0f 82 18 0c 00 00    	jb     6694e9 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1949>
  6688d1:	48 39 f2             	cmp    %rsi,%rdx
  6688d4:	0f 82 0f 0c 00 00    	jb     6694e9 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1949>
  6688da:	39 fe                	cmp    %edi,%esi
  6688dc:	0f 84 db 0c 00 00    	je     6695bd <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a1d>
  6688e2:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
  6688e7:	48 8b 40 68          	mov    0x68(%rax),%rax
  6688eb:	48 8d 0c 7f          	lea    (%rdi,%rdi,2),%rcx
  6688ef:	80 7c 88 07 06       	cmpb   $0x6,0x7(%rax,%rcx,4)
  6688f4:	0f 85 1c 06 00 00    	jne    668f16 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1376>
  6688fa:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  6688ff:	4c 89 c6             	mov    %r8,%rsi
  668902:	ba 01 00 00 00       	mov    $0x1,%edx
  668907:	e8 94 65 01 00       	call   67eea0 <<parley::editing::cursor::Cursor>::from_byte_index::<()>>
  66890c:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
  668913:	00 
  668914:	80 e2 01             	and    $0x1,%dl
  668917:	88 94 24 e0 00 00 00 	mov    %dl,0xe0(%rsp)
  66891e:	4c 39 f8             	cmp    %r15,%rax
  668921:	0f 85 5d 01 00 00    	jne    668a84 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xee4>
  668927:	48 8d bc 24 00 02 00 	lea    0x200(%rsp),%rdi
  66892e:	00 
  66892f:	48 8d b4 24 d8 00 00 	lea    0xd8(%rsp),%rsi
  668936:	00 
  668937:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  66893c:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  668942:	e8 19 66 01 00       	call   67ef60 <<parley::editing::cursor::Cursor>::geometry::<()>>
  668947:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  66894c:	4c 89 fe             	mov    %r15,%rsi
  66894f:	31 d2                	xor    %edx,%edx
  668951:	e8 4a 65 01 00       	call   67eea0 <<parley::editing::cursor::Cursor>::from_byte_index::<()>>
  668956:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
  66895d:	00 
  66895e:	80 e2 01             	and    $0x1,%dl
  668961:	88 94 24 f0 00 00 00 	mov    %dl,0xf0(%rsp)
  668968:	48 8d bc 24 78 01 00 	lea    0x178(%rsp),%rdi
  66896f:	00 
  668970:	48 8d b4 24 e8 00 00 	lea    0xe8(%rsp),%rsi
  668977:	00 
  668978:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  66897d:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  668983:	e8 d8 65 01 00       	call   67ef60 <<parley::editing::cursor::Cursor>::geometry::<()>>
  668988:	e9 94 00 00 00       	jmp    668a21 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xe81>
  66898d:	0f 87 f1 00 00 00    	ja     668a84 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xee4>
  668993:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  668998:	4c 89 e6             	mov    %r12,%rsi
  66899b:	ba 01 00 00 00       	mov    $0x1,%edx
  6689a0:	e8 fb 64 01 00       	call   67eea0 <<parley::editing::cursor::Cursor>::from_byte_index::<()>>
  6689a5:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
  6689ac:	00 
  6689ad:	80 e2 01             	and    $0x1,%dl
  6689b0:	88 94 24 e0 00 00 00 	mov    %dl,0xe0(%rsp)
  6689b7:	4c 39 e0             	cmp    %r12,%rax
  6689ba:	0f 85 c4 00 00 00    	jne    668a84 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xee4>
  6689c0:	48 8d bc 24 00 02 00 	lea    0x200(%rsp),%rdi
  6689c7:	00 
  6689c8:	48 8d b4 24 d8 00 00 	lea    0xd8(%rsp),%rsi
  6689cf:	00 
  6689d0:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  6689d5:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  6689db:	e8 80 65 01 00       	call   67ef60 <<parley::editing::cursor::Cursor>::geometry::<()>>
  6689e0:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  6689e5:	4c 89 e6             	mov    %r12,%rsi
  6689e8:	31 d2                	xor    %edx,%edx
  6689ea:	e8 b1 64 01 00       	call   67eea0 <<parley::editing::cursor::Cursor>::from_byte_index::<()>>
  6689ef:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
  6689f6:	00 
  6689f7:	80 e2 01             	and    $0x1,%dl
  6689fa:	88 94 24 f0 00 00 00 	mov    %dl,0xf0(%rsp)
  668a01:	48 8d bc 24 78 01 00 	lea    0x178(%rsp),%rdi
  668a08:	00 
  668a09:	48 8d b4 24 e8 00 00 	lea    0xe8(%rsp),%rsi
  668a10:	00 
  668a11:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  668a16:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  668a1c:	e8 3f 65 01 00       	call   67ef60 <<parley::editing::cursor::Cursor>::geometry::<()>>
  668a21:	0f 10 84 24 78 01 00 	movups 0x178(%rsp),%xmm0
  668a28:	00 
  668a29:	0f 10 8c 24 88 01 00 	movups 0x188(%rsp),%xmm1
  668a30:	00 
  668a31:	48 8d 84 24 30 02 00 	lea    0x230(%rsp),%rax
  668a38:	00 
  668a39:	0f 11 08             	movups %xmm1,(%rax)
  668a3c:	0f 11 40 f0          	movups %xmm0,-0x10(%rax)
  668a40:	0f 28 84 24 00 02 00 	movaps 0x200(%rsp),%xmm0
  668a47:	00 
  668a48:	0f 29 84 24 b0 00 00 	movaps %xmm0,0xb0(%rsp)
  668a4f:	00 
  668a50:	0f 28 84 24 10 02 00 	movaps 0x210(%rsp),%xmm0
  668a57:	00 
  668a58:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
  668a5d:	0f 28 84 24 20 02 00 	movaps 0x220(%rsp),%xmm0
  668a64:	00 
  668a65:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
  668a6c:	00 
  668a6d:	0f 28 84 24 30 02 00 	movaps 0x230(%rsp),%xmm0
  668a74:	00 
  668a75:	0f 29 84 24 00 01 00 	movaps %xmm0,0x100(%rsp)
  668a7c:	00 
  668a7d:	b8 01 00 00 00       	mov    $0x1,%eax
  668a82:	eb 02                	jmp    668a86 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xee6>
  668a84:	31 c0                	xor    %eax,%eax
  668a86:	4c 89 a4 24 00 02 00 	mov    %r12,0x200(%rsp)
  668a8d:	00 
  668a8e:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
  668a95:	00 
  668a96:	0f 28 84 24 b0 00 00 	movaps 0xb0(%rsp),%xmm0
  668a9d:	00 
  668a9e:	0f 11 84 24 10 02 00 	movups %xmm0,0x210(%rsp)
  668aa5:	00 
  668aa6:	0f 28 44 24 60       	movaps 0x60(%rsp),%xmm0
  668aab:	0f 11 84 24 20 02 00 	movups %xmm0,0x220(%rsp)
  668ab2:	00 
  668ab3:	0f 28 84 24 90 00 00 	movaps 0x90(%rsp),%xmm0
  668aba:	00 
  668abb:	0f 11 84 24 30 02 00 	movups %xmm0,0x230(%rsp)
  668ac2:	00 
  668ac3:	0f 28 84 24 00 01 00 	movaps 0x100(%rsp),%xmm0
  668aca:	00 
  668acb:	0f 11 84 24 40 02 00 	movups %xmm0,0x240(%rsp)
  668ad2:	00 
  668ad3:	48 8b bc 24 a8 00 00 	mov    0xa8(%rsp),%rdi
  668ada:	00 
  668adb:	4c 89 e6             	mov    %r12,%rsi
  668ade:	48 8d 94 24 08 02 00 	lea    0x208(%rsp),%rdx
  668ae5:	00 
  668ae6:	e8 b5 2a 00 00       	call   66b5a0 <gpui_canvas::text::planner::append_carets::{closure#1}>
  668aeb:	41 89 c6             	mov    %eax,%r14d
  668aee:	83 f8 ff             	cmp    $0xffffffff,%eax
  668af1:	0f 85 ef 08 00 00    	jne    6693e6 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1846>
  668af7:	4d 39 fd             	cmp    %r15,%r13
  668afa:	0f 94 c0             	sete   %al
  668afd:	8b 4c 24 44          	mov    0x44(%rsp),%ecx
  668b01:	20 c1                	and    %al,%cl
  668b03:	89 4c 24 44          	mov    %ecx,0x44(%rsp)
  668b07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  668b0e:	00 00 
  668b10:	48 8b 84 24 50 04 00 	mov    0x450(%rsp),%rax
  668b17:	00 
  668b18:	48 83 f8 02          	cmp    $0x2,%rax
  668b1c:	75 22                	jne    668b40 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xfa0>
  668b1e:	48 8d bc 24 60 04 00 	lea    0x460(%rsp),%rdi
  668b25:	00 
  668b26:	e8 65 83 00 00       	call   670e90 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  668b2b:	49 89 d5             	mov    %rdx,%r13
  668b2e:	48 89 84 24 50 04 00 	mov    %rax,0x450(%rsp)
  668b35:	00 
  668b36:	48 89 94 24 58 04 00 	mov    %rdx,0x458(%rsp)
  668b3d:	00 
  668b3e:	eb 08                	jmp    668b48 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xfa8>
  668b40:	4c 8b ac 24 58 04 00 	mov    0x458(%rsp),%r13
  668b47:	00 
  668b48:	41 b6 01             	mov    $0x1,%r14b
  668b4b:	48 83 f8 01          	cmp    $0x1,%rax
  668b4f:	0f 85 2b 03 00 00    	jne    668e80 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x12e0>
  668b55:	4c 3b 6c 24 50       	cmp    0x50(%rsp),%r13
  668b5a:	4d 89 f8             	mov    %r15,%r8
  668b5d:	0f 83 13 03 00 00    	jae    668e76 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x12d6>
  668b63:	4d 39 e5             	cmp    %r12,%r13
  668b66:	0f 82 37 08 00 00    	jb     6693a3 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1803>
  668b6c:	48 c7 84 24 50 04 00 	movq   $0x2,0x450(%rsp)
  668b73:	00 02 00 00 00 
  668b78:	4d 39 c5             	cmp    %r8,%r13
  668b7b:	0f 85 f1 00 00 00    	jne    668c72 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x10d2>
  668b81:	80 7c 24 44 00       	cmpb   $0x0,0x44(%rsp)
  668b86:	74 57                	je     668bdf <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x103f>
  668b88:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
  668b8d:	48 8b 41 58          	mov    0x58(%rcx),%rax
  668b91:	48 39 e8             	cmp    %rbp,%rax
  668b94:	0f 86 15 0a 00 00    	jbe    6695af <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a0f>
  668b9a:	48 8b 51 70          	mov    0x70(%rcx),%rdx
  668b9e:	48 8b bc 24 60 01 00 	mov    0x160(%rsp),%rdi
  668ba5:	00 
  668ba6:	48 8b b4 24 58 01 00 	mov    0x158(%rsp),%rsi
  668bad:	00 
  668bae:	39 fe                	cmp    %edi,%esi
  668bb0:	0f 82 33 09 00 00    	jb     6694e9 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1949>
  668bb6:	48 39 f2             	cmp    %rsi,%rdx
  668bb9:	0f 82 2a 09 00 00    	jb     6694e9 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1949>
  668bbf:	39 fe                	cmp    %edi,%esi
  668bc1:	0f 84 f6 09 00 00    	je     6695bd <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a1d>
  668bc7:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
  668bcc:	48 8b 40 68          	mov    0x68(%rax),%rax
  668bd0:	48 8d 0c 7f          	lea    (%rdi,%rdi,2),%rcx
  668bd4:	80 7c 88 07 06       	cmpb   $0x6,0x7(%rax,%rcx,4)
  668bd9:	0f 85 05 02 00 00    	jne    668de4 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1244>
  668bdf:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  668be4:	4c 89 c6             	mov    %r8,%rsi
  668be7:	ba 01 00 00 00       	mov    $0x1,%edx
  668bec:	e8 af 62 01 00       	call   67eea0 <<parley::editing::cursor::Cursor>::from_byte_index::<()>>
  668bf1:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
  668bf8:	00 
  668bf9:	80 e2 01             	and    $0x1,%dl
  668bfc:	88 94 24 e0 00 00 00 	mov    %dl,0xe0(%rsp)
  668c03:	4c 39 f8             	cmp    %r15,%rax
  668c06:	0f 85 5d 01 00 00    	jne    668d69 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x11c9>
  668c0c:	48 8d bc 24 00 02 00 	lea    0x200(%rsp),%rdi
  668c13:	00 
  668c14:	48 8d b4 24 d8 00 00 	lea    0xd8(%rsp),%rsi
  668c1b:	00 
  668c1c:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  668c21:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  668c27:	e8 34 63 01 00       	call   67ef60 <<parley::editing::cursor::Cursor>::geometry::<()>>
  668c2c:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  668c31:	4c 89 fe             	mov    %r15,%rsi
  668c34:	31 d2                	xor    %edx,%edx
  668c36:	e8 65 62 01 00       	call   67eea0 <<parley::editing::cursor::Cursor>::from_byte_index::<()>>
  668c3b:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
  668c42:	00 
  668c43:	80 e2 01             	and    $0x1,%dl
  668c46:	88 94 24 f0 00 00 00 	mov    %dl,0xf0(%rsp)
  668c4d:	48 8d bc 24 78 01 00 	lea    0x178(%rsp),%rdi
  668c54:	00 
  668c55:	48 8d b4 24 e8 00 00 	lea    0xe8(%rsp),%rsi
  668c5c:	00 
  668c5d:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  668c62:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  668c68:	e8 f3 62 01 00       	call   67ef60 <<parley::editing::cursor::Cursor>::geometry::<()>>
  668c6d:	e9 94 00 00 00       	jmp    668d06 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1166>
  668c72:	0f 87 f1 00 00 00    	ja     668d69 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x11c9>
  668c78:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  668c7d:	4c 89 ee             	mov    %r13,%rsi
  668c80:	ba 01 00 00 00       	mov    $0x1,%edx
  668c85:	e8 16 62 01 00       	call   67eea0 <<parley::editing::cursor::Cursor>::from_byte_index::<()>>
  668c8a:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
  668c91:	00 
  668c92:	80 e2 01             	and    $0x1,%dl
  668c95:	88 94 24 e0 00 00 00 	mov    %dl,0xe0(%rsp)
  668c9c:	4c 39 e8             	cmp    %r13,%rax
  668c9f:	0f 85 c4 00 00 00    	jne    668d69 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x11c9>
  668ca5:	48 8d bc 24 00 02 00 	lea    0x200(%rsp),%rdi
  668cac:	00 
  668cad:	48 8d b4 24 d8 00 00 	lea    0xd8(%rsp),%rsi
  668cb4:	00 
  668cb5:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  668cba:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  668cc0:	e8 9b 62 01 00       	call   67ef60 <<parley::editing::cursor::Cursor>::geometry::<()>>
  668cc5:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  668cca:	4c 89 ee             	mov    %r13,%rsi
  668ccd:	31 d2                	xor    %edx,%edx
  668ccf:	e8 cc 61 01 00       	call   67eea0 <<parley::editing::cursor::Cursor>::from_byte_index::<()>>
  668cd4:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
  668cdb:	00 
  668cdc:	80 e2 01             	and    $0x1,%dl
  668cdf:	88 94 24 f0 00 00 00 	mov    %dl,0xf0(%rsp)
  668ce6:	48 8d bc 24 78 01 00 	lea    0x178(%rsp),%rdi
  668ced:	00 
  668cee:	48 8d b4 24 e8 00 00 	lea    0xe8(%rsp),%rsi
  668cf5:	00 
  668cf6:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  668cfb:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  668d01:	e8 5a 62 01 00       	call   67ef60 <<parley::editing::cursor::Cursor>::geometry::<()>>
  668d06:	0f 10 84 24 78 01 00 	movups 0x178(%rsp),%xmm0
  668d0d:	00 
  668d0e:	0f 10 8c 24 88 01 00 	movups 0x188(%rsp),%xmm1
  668d15:	00 
  668d16:	48 8d 84 24 30 02 00 	lea    0x230(%rsp),%rax
  668d1d:	00 
  668d1e:	0f 11 08             	movups %xmm1,(%rax)
  668d21:	0f 11 40 f0          	movups %xmm0,-0x10(%rax)
  668d25:	0f 28 84 24 00 02 00 	movaps 0x200(%rsp),%xmm0
  668d2c:	00 
  668d2d:	0f 29 84 24 b0 00 00 	movaps %xmm0,0xb0(%rsp)
  668d34:	00 
  668d35:	0f 28 84 24 10 02 00 	movaps 0x210(%rsp),%xmm0
  668d3c:	00 
  668d3d:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
  668d42:	0f 28 84 24 20 02 00 	movaps 0x220(%rsp),%xmm0
  668d49:	00 
  668d4a:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
  668d51:	00 
  668d52:	0f 28 84 24 30 02 00 	movaps 0x230(%rsp),%xmm0
  668d59:	00 
  668d5a:	0f 29 84 24 00 01 00 	movaps %xmm0,0x100(%rsp)
  668d61:	00 
  668d62:	b8 01 00 00 00       	mov    $0x1,%eax
  668d67:	eb 02                	jmp    668d6b <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x11cb>
  668d69:	31 c0                	xor    %eax,%eax
  668d6b:	4c 89 ac 24 00 02 00 	mov    %r13,0x200(%rsp)
  668d72:	00 
  668d73:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
  668d7a:	00 
  668d7b:	0f 28 84 24 b0 00 00 	movaps 0xb0(%rsp),%xmm0
  668d82:	00 
  668d83:	0f 11 84 24 10 02 00 	movups %xmm0,0x210(%rsp)
  668d8a:	00 
  668d8b:	0f 28 44 24 60       	movaps 0x60(%rsp),%xmm0
  668d90:	0f 11 84 24 20 02 00 	movups %xmm0,0x220(%rsp)
  668d97:	00 
  668d98:	0f 28 84 24 90 00 00 	movaps 0x90(%rsp),%xmm0
  668d9f:	00 
  668da0:	0f 11 84 24 30 02 00 	movups %xmm0,0x230(%rsp)
  668da7:	00 
  668da8:	0f 28 84 24 00 01 00 	movaps 0x100(%rsp),%xmm0
  668daf:	00 
  668db0:	0f 11 84 24 40 02 00 	movups %xmm0,0x240(%rsp)
  668db7:	00 
  668db8:	48 8b bc 24 a8 00 00 	mov    0xa8(%rsp),%rdi
  668dbf:	00 
  668dc0:	4c 89 ee             	mov    %r13,%rsi
  668dc3:	48 8d 94 24 08 02 00 	lea    0x208(%rsp),%rdx
  668dca:	00 
  668dcb:	e8 d0 27 00 00       	call   66b5a0 <gpui_canvas::text::planner::append_carets::{closure#1}>
  668dd0:	41 89 c6             	mov    %eax,%r14d
  668dd3:	4d 89 ec             	mov    %r13,%r12
  668dd6:	83 f8 ff             	cmp    $0xffffffff,%eax
  668dd9:	0f 84 31 fd ff ff    	je     668b10 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xf70>
  668ddf:	e9 02 06 00 00       	jmp    6693e6 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1846>
  668de4:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  668de9:	f3 0f 10 40 40       	movss  0x40(%rax),%xmm0
  668dee:	0f 28 c8             	movaps %xmm0,%xmm1
  668df1:	f3 0f 5d 48 48       	minss  0x48(%rax),%xmm1
  668df6:	0f 28 d1             	movaps %xmm1,%xmm2
  668df9:	f3 0f c2 d1 03       	cmpunordss %xmm1,%xmm2
  668dfe:	0f 28 da             	movaps %xmm2,%xmm3
  668e01:	0f 55 d9             	andnps %xmm1,%xmm3
  668e04:	0f 54 d0             	andps  %xmm0,%xmm2
  668e07:	0f 56 d3             	orps   %xmm3,%xmm2
  668e0a:	0f 57 c0             	xorps  %xmm0,%xmm0
  668e0d:	f3 0f 5a c2          	cvtss2sd %xmm2,%xmm0
  668e11:	f3 0f 10 48 44       	movss  0x44(%rax),%xmm1
  668e16:	0f 28 d1             	movaps %xmm1,%xmm2
  668e19:	f3 0f 5f 50 4c       	maxss  0x4c(%rax),%xmm2
  668e1e:	0f 28 da             	movaps %xmm2,%xmm3
  668e21:	f3 0f c2 da 03       	cmpunordss %xmm2,%xmm3
  668e26:	0f 28 e3             	movaps %xmm3,%xmm4
  668e29:	0f 55 e2             	andnps %xmm2,%xmm4
  668e2c:	0f 54 d9             	andps  %xmm1,%xmm3
  668e2f:	0f 56 dc             	orps   %xmm4,%xmm3
  668e32:	0f 57 c9             	xorps  %xmm1,%xmm1
  668e35:	f3 0f 5a cb          	cvtss2sd %xmm3,%xmm1
  668e39:	0f 28 94 24 a0 01 00 	movaps 0x1a0(%rsp),%xmm2
  668e40:	00 
  668e41:	0f 16 d0             	movlhps %xmm0,%xmm2
  668e44:	0f 28 84 24 b0 01 00 	movaps 0x1b0(%rsp),%xmm0
  668e4b:	00 
  668e4c:	0f 16 c1             	movlhps %xmm1,%xmm0
  668e4f:	b8 01 00 00 00       	mov    $0x1,%eax
  668e54:	0f 29 94 24 b0 00 00 	movaps %xmm2,0xb0(%rsp)
  668e5b:	00 
  668e5c:	0f 29 94 24 90 00 00 	movaps %xmm2,0x90(%rsp)
  668e63:	00 
  668e64:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
  668e69:	0f 29 84 24 00 01 00 	movaps %xmm0,0x100(%rsp)
  668e70:	00 
  668e71:	e9 f5 fe ff ff       	jmp    668d6b <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x11cb>
  668e76:	4c 89 a4 24 c8 01 00 	mov    %r12,0x1c8(%rsp)
  668e7d:	00 
  668e7e:	eb 0b                	jmp    668e8b <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x12eb>
  668e80:	4c 89 a4 24 c8 01 00 	mov    %r12,0x1c8(%rsp)
  668e87:	00 
  668e88:	4d 89 f8             	mov    %r15,%r8
  668e8b:	4c 3b 44 24 50       	cmp    0x50(%rsp),%r8
  668e90:	4c 89 b4 24 a0 01 00 	mov    %r14,0x1a0(%rsp)
  668e97:	00 
  668e98:	73 5a                	jae    668ef4 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1354>
  668e9a:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
  668e9f:	48 8b 41 58          	mov    0x58(%rcx),%rax
  668ea3:	48 39 e8             	cmp    %rbp,%rax
  668ea6:	0f 86 03 07 00 00    	jbe    6695af <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a0f>
  668eac:	48 8b 51 70          	mov    0x70(%rcx),%rdx
  668eb0:	48 8b bc 24 60 01 00 	mov    0x160(%rsp),%rdi
  668eb7:	00 
  668eb8:	48 8b b4 24 58 01 00 	mov    0x158(%rsp),%rsi
  668ebf:	00 
  668ec0:	39 fe                	cmp    %edi,%esi
  668ec2:	0f 82 21 06 00 00    	jb     6694e9 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1949>
  668ec8:	48 39 f2             	cmp    %rsi,%rdx
  668ecb:	0f 82 18 06 00 00    	jb     6694e9 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1949>
  668ed1:	39 fe                	cmp    %edi,%esi
  668ed3:	0f 84 e4 06 00 00    	je     6695bd <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a1d>
  668ed9:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
  668ede:	48 8b 40 68          	mov    0x68(%rax),%rax
  668ee2:	48 8d 0c 7f          	lea    (%rdi,%rdi,2),%rcx
  668ee6:	80 7c 88 07 06       	cmpb   $0x6,0x7(%rax,%rcx,4)
  668eeb:	0f 95 c0             	setne  %al
  668eee:	89 44 24 44          	mov    %eax,0x44(%rsp)
  668ef2:	eb 08                	jmp    668efc <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x135c>
  668ef4:	c7 44 24 44 00 00 00 	movl   $0x0,0x44(%rsp)
  668efb:	00 
  668efc:	48 8d ac 24 38 03 00 	lea    0x338(%rsp),%rbp
  668f03:	00 
  668f04:	4c 8b 6c 24 50       	mov    0x50(%rsp),%r13
  668f09:	48 8d bc 24 00 02 00 	lea    0x200(%rsp),%rdi
  668f10:	00 
  668f11:	e9 bd f6 ff ff       	jmp    6685d3 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xa33>
  668f16:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  668f1b:	f3 0f 10 40 40       	movss  0x40(%rax),%xmm0
  668f20:	0f 28 c8             	movaps %xmm0,%xmm1
  668f23:	f3 0f 5d 48 48       	minss  0x48(%rax),%xmm1
  668f28:	0f 28 d1             	movaps %xmm1,%xmm2
  668f2b:	f3 0f c2 d1 03       	cmpunordss %xmm1,%xmm2
  668f30:	0f 28 da             	movaps %xmm2,%xmm3
  668f33:	0f 55 d9             	andnps %xmm1,%xmm3
  668f36:	0f 54 d0             	andps  %xmm0,%xmm2
  668f39:	0f 56 d3             	orps   %xmm3,%xmm2
  668f3c:	0f 57 c0             	xorps  %xmm0,%xmm0
  668f3f:	f3 0f 5a c2          	cvtss2sd %xmm2,%xmm0
  668f43:	f3 0f 10 48 44       	movss  0x44(%rax),%xmm1
  668f48:	0f 28 d1             	movaps %xmm1,%xmm2
  668f4b:	f3 0f 5f 50 4c       	maxss  0x4c(%rax),%xmm2
  668f50:	0f 28 da             	movaps %xmm2,%xmm3
  668f53:	f3 0f c2 da 03       	cmpunordss %xmm2,%xmm3
  668f58:	0f 28 e3             	movaps %xmm3,%xmm4
  668f5b:	0f 55 e2             	andnps %xmm2,%xmm4
  668f5e:	0f 54 d9             	andps  %xmm1,%xmm3
  668f61:	0f 56 dc             	orps   %xmm4,%xmm3
  668f64:	0f 57 c9             	xorps  %xmm1,%xmm1
  668f67:	f3 0f 5a cb          	cvtss2sd %xmm3,%xmm1
  668f6b:	0f 28 94 24 a0 01 00 	movaps 0x1a0(%rsp),%xmm2
  668f72:	00 
  668f73:	0f 16 d0             	movlhps %xmm0,%xmm2
  668f76:	0f 28 84 24 b0 01 00 	movaps 0x1b0(%rsp),%xmm0
  668f7d:	00 
  668f7e:	0f 16 c1             	movlhps %xmm1,%xmm0
  668f81:	b8 01 00 00 00       	mov    $0x1,%eax
  668f86:	0f 29 94 24 b0 00 00 	movaps %xmm2,0xb0(%rsp)
  668f8d:	00 
  668f8e:	0f 29 94 24 90 00 00 	movaps %xmm2,0x90(%rsp)
  668f95:	00 
  668f96:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
  668f9b:	0f 29 84 24 00 01 00 	movaps %xmm0,0x100(%rsp)
  668fa2:	00 
  668fa3:	e9 de fa ff ff       	jmp    668a86 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xee6>
  668fa8:	48 8b 84 24 d0 01 00 	mov    0x1d0(%rsp),%rax
  668faf:	00 
  668fb0:	48 8b 8c 24 d8 01 00 	mov    0x1d8(%rsp),%rcx
  668fb7:	00 
  668fb8:	48 8b 94 24 e0 01 00 	mov    0x1e0(%rsp),%rdx
  668fbf:	00 
  668fc0:	48 8b b4 24 e8 01 00 	mov    0x1e8(%rsp),%rsi
  668fc7:	00 
  668fc8:	8b bc 24 f0 01 00 00 	mov    0x1f0(%rsp),%edi
  668fcf:	89 bc 24 50 03 00 00 	mov    %edi,0x350(%rsp)
  668fd6:	8b bc 24 f4 01 00 00 	mov    0x1f4(%rsp),%edi
  668fdd:	89 bc 24 54 03 00 00 	mov    %edi,0x354(%rsp)
  668fe4:	8b bc 24 f8 01 00 00 	mov    0x1f8(%rsp),%edi
  668feb:	89 bc 24 58 03 00 00 	mov    %edi,0x358(%rsp)
  668ff2:	8b bc 24 fc 01 00 00 	mov    0x1fc(%rsp),%edi
  668ff9:	89 bc 24 5c 03 00 00 	mov    %edi,0x35c(%rsp)
  669000:	48 89 94 24 40 03 00 	mov    %rdx,0x340(%rsp)
  669007:	00 
  669008:	48 89 b4 24 48 03 00 	mov    %rsi,0x348(%rsp)
  66900f:	00 
  669010:	48 89 84 24 30 03 00 	mov    %rax,0x330(%rsp)
  669017:	00 
  669018:	48 89 8c 24 38 03 00 	mov    %rcx,0x338(%rsp)
  66901f:	00 
  669020:	48 8d bc 24 88 05 00 	lea    0x588(%rsp),%rdi
  669027:	00 
  669028:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
  66902f:	00 
  669030:	ba 01 00 00 00       	mov    $0x1,%edx
  669035:	e8 26 83 01 00       	call   681360 <<parley::layout::run::Clusters<()>>::new>
  66903a:	4c 8d a4 24 30 02 00 	lea    0x230(%rsp),%r12
  669041:	00 
  669042:	4c 8d ac 24 80 02 00 	lea    0x280(%rsp),%r13
  669049:	00 
  66904a:	ba 10 01 00 00       	mov    $0x110,%edx
  66904f:	48 8d bc 24 30 03 00 	lea    0x330(%rsp),%rdi
  669056:	00 
  669057:	48 8d b4 24 88 05 00 	lea    0x588(%rsp),%rsi
  66905e:	00 
  66905f:	ff 15 eb 0f 12 00    	call   *0x120feb(%rip)        # 78a050 <memcpy@GLIBC_2.14>
  669065:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  66906c:	00 00 00 00 
  669070:	48 8d bc 24 f8 04 00 	lea    0x4f8(%rsp),%rdi
  669077:	00 
  669078:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
  66907f:	00 
  669080:	e8 3b ab 01 00       	call   683bc0 <<parley::layout::run::Clusters<()> as core::iter::traits::iterator::Iterator>::next>
  669085:	48 83 bc 24 f8 04 00 	cmpq   $0x0,0x4f8(%rsp)
  66908c:	00 00 
  66908e:	0f 84 e9 f4 ff ff    	je     66857d <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x9dd>
  669094:	ba 90 00 00 00       	mov    $0x90,%edx
  669099:	48 8d bc 24 00 02 00 	lea    0x200(%rsp),%rdi
  6690a0:	00 
  6690a1:	48 8d b4 24 f8 04 00 	lea    0x4f8(%rsp),%rsi
  6690a8:	00 
  6690a9:	ff 15 a1 0f 12 00    	call   *0x120fa1(%rip)        # 78a050 <memcpy@GLIBC_2.14>
  6690af:	4c 8b b4 24 38 01 00 	mov    0x138(%rsp),%r14
  6690b6:	00 
  6690b7:	4c 3b b4 24 28 01 00 	cmp    0x128(%rsp),%r14
  6690be:	00 
  6690bf:	75 0e                	jne    6690cf <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x152f>
  6690c1:	48 8d bc 24 28 01 00 	lea    0x128(%rsp),%rdi
  6690c8:	00 
  6690c9:	ff 15 89 11 12 00    	call   *0x121189(%rip)        # 78a258 <_DYNAMIC+0x4d8>
  6690cf:	48 8b 84 24 30 01 00 	mov    0x130(%rsp),%rax
  6690d6:	00 
  6690d7:	f3 0f 10 44 24 30    	movss  0x30(%rsp),%xmm0
  6690dd:	f3 42 0f 11 04 b0    	movss  %xmm0,(%rax,%r14,4)
  6690e3:	49 ff c6             	inc    %r14
  6690e6:	4c 89 b4 24 38 01 00 	mov    %r14,0x138(%rsp)
  6690ed:	00 
  6690ee:	48 83 bc 24 18 02 00 	cmpq   $0x0,0x218(%rsp)
  6690f5:	00 00 
  6690f7:	74 3e                	je     669137 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1597>
  6690f9:	48 8b 84 24 00 02 00 	mov    0x200(%rsp),%rax
  669100:	00 
  669101:	8b ac 24 20 02 00 00 	mov    0x220(%rsp),%ebp
  669108:	48 8b 88 18 01 00 00 	mov    0x118(%rax),%rcx
  66910f:	48 39 e9             	cmp    %rbp,%rcx
  669112:	0f 86 f8 04 00 00    	jbe    669610 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a70>
  669118:	48 8b 80 10 01 00 00 	mov    0x110(%rax),%rax
  66911f:	48 6b cd 70          	imul   $0x70,%rbp,%rcx
  669123:	f3 0f 10 44 08 50    	movss  0x50(%rax,%rcx,1),%xmm0
  669129:	8b 44 08 54          	mov    0x54(%rax,%rcx,1),%eax
  66912d:	48 8d ac 24 38 03 00 	lea    0x338(%rsp),%rbp
  669134:	00 
  669135:	eb 08                	jmp    66913f <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x159f>
  669137:	0f 57 c0             	xorps  %xmm0,%xmm0
  66913a:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  66913f:	48 8b 8c 24 08 02 00 	mov    0x208(%rsp),%rcx
  669146:	00 
  669147:	48 8b 94 24 10 02 00 	mov    0x210(%rsp),%rdx
  66914e:	00 
  66914f:	f2 0f 10 4a 44       	movsd  0x44(%rdx),%xmm1
  669154:	f2 0f 11 8c 24 78 01 	movsd  %xmm1,0x178(%rsp)
  66915b:	00 00 
  66915d:	f3 0f 11 84 24 80 01 	movss  %xmm0,0x180(%rsp)
  669164:	00 00 
  669166:	89 84 24 84 01 00 00 	mov    %eax,0x184(%rsp)
  66916d:	0f b6 89 8c 00 00 00 	movzbl 0x8c(%rcx),%ecx
  669174:	83 e1 01             	and    $0x1,%ecx
  669177:	48 8d bc 24 78 01 00 	lea    0x178(%rsp),%rdi
  66917e:	00 
  66917f:	4c 89 e6             	mov    %r12,%rsi
  669182:	4c 89 ea             	mov    %r13,%rdx
  669185:	ff 15 b5 11 12 00    	call   *0x1211b5(%rip)        # 78a340 <_DYNAMIC+0x5c0>
  66918b:	f3 0f 10 4c 24 30    	movss  0x30(%rsp),%xmm1
  669191:	f3 0f 58 c8          	addss  %xmm0,%xmm1
  669195:	f3 0f 11 4c 24 30    	movss  %xmm1,0x30(%rsp)
  66919b:	e9 d0 fe ff ff       	jmp    669070 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x14d0>
  6691a0:	48 8d ac 24 38 03 00 	lea    0x338(%rsp),%rbp
  6691a7:	00 
  6691a8:	4c 8b 94 24 20 03 00 	mov    0x320(%rsp),%r10
  6691af:	00 
  6691b0:	44 8b 9c 24 9c 01 00 	mov    0x19c(%rsp),%r11d
  6691b7:	00 
  6691b8:	4c 8b b4 24 18 03 00 	mov    0x318(%rsp),%r14
  6691bf:	00 
  6691c0:	e9 85 f2 ff ff       	jmp    66844a <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x8aa>
  6691c5:	48 8b 84 24 30 03 00 	mov    0x330(%rsp),%rax
  6691cc:	00 
  6691cd:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  6691d2:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  6691d7:	f3 0f 10 48 28       	movss  0x28(%rax),%xmm1
  6691dc:	48 c1 e7 03          	shl    $0x3,%rdi
  6691e0:	48 8d 04 bf          	lea    (%rdi,%rdi,4),%rax
  6691e4:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
  6691eb:	00 
  6691ec:	4c 8d 2c 01          	lea    (%rcx,%rax,1),%r13
  6691f0:	48 c1 e6 03          	shl    $0x3,%rsi
  6691f4:	4c 8d 34 b6          	lea    (%rsi,%rsi,4),%r14
  6691f8:	49 29 c6             	sub    %rax,%r14
  6691fb:	45 31 e4             	xor    %r12d,%r12d
  6691fe:	eb 23                	jmp    669223 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1683>
  669200:	48 8d ac 24 38 03 00 	lea    0x338(%rsp),%rbp
  669207:	00 
  669208:	f3 0f 10 4c 24 30    	movss  0x30(%rsp),%xmm1
  66920e:	49 83 c5 28          	add    $0x28,%r13
  669212:	f3 0f 58 c8          	addss  %xmm0,%xmm1
  669216:	49 ff c4             	inc    %r12
  669219:	49 83 c6 d8          	add    $0xffffffffffffffd8,%r14
  66921d:	0f 84 11 f2 ff ff    	je     668434 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x894>
  669223:	49 8b 6d 10          	mov    0x10(%r13),%rbp
  669227:	41 80 7d 21 01       	cmpb   $0x1,0x21(%r13)
  66922c:	75 32                	jne    669260 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x16c0>
  66922e:	48 3b ac 24 c0 00 00 	cmp    0xc0(%rsp),%rbp
  669235:	00 
  669236:	0f 83 5d 03 00 00    	jae    669599 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19f9>
  66923c:	48 6b c5 38          	imul   $0x38,%rbp,%rax
  669240:	48 8b 8c 24 68 01 00 	mov    0x168(%rsp),%rcx
  669247:	00 
  669248:	f3 0f 10 44 01 24    	movss  0x24(%rcx,%rax,1),%xmm0
  66924e:	48 8d ac 24 38 03 00 	lea    0x338(%rsp),%rbp
  669255:	00 
  669256:	eb b6                	jmp    66920e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x166e>
  669258:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  66925f:	00 
  669260:	48 3b ac 24 20 01 00 	cmp    0x120(%rsp),%rbp
  669267:	00 
  669268:	0f 83 dc 02 00 00    	jae    66954a <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19aa>
  66926e:	48 3b ac 24 18 01 00 	cmp    0x118(%rsp),%rbp
  669275:	00 
  669276:	0f 83 f3 02 00 00    	jae    66956f <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19cf>
  66927c:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
  669283:	00 
  669284:	48 01 e8             	add    %rbp,%rax
  669287:	48 c1 e0 04          	shl    $0x4,%rax
  66928b:	48 03 84 24 c8 00 00 	add    0xc8(%rsp),%rax
  669292:	00 
  669293:	48 8d 0c ad 00 00 00 	lea    0x0(,%rbp,4),%rcx
  66929a:	00 
  66929b:	48 01 e9             	add    %rbp,%rcx
  66929e:	48 c1 e1 04          	shl    $0x4,%rcx
  6692a2:	48 03 8c 24 d0 00 00 	add    0xd0(%rsp),%rcx
  6692a9:	00 
  6692aa:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  6692af:	48 89 94 24 30 03 00 	mov    %rdx,0x330(%rsp)
  6692b6:	00 
  6692b7:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
  6692be:	00 
  6692bf:	48 89 8c 24 40 03 00 	mov    %rcx,0x340(%rsp)
  6692c6:	00 
  6692c7:	4c 89 ac 24 48 03 00 	mov    %r13,0x348(%rsp)
  6692ce:	00 
  6692cf:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  6692d4:	89 84 24 50 03 00 00 	mov    %eax,0x350(%rsp)
  6692db:	44 89 a4 24 54 03 00 	mov    %r12d,0x354(%rsp)
  6692e2:	00 
  6692e3:	89 ac 24 58 03 00 00 	mov    %ebp,0x358(%rsp)
  6692ea:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  6692ef:	48 8b 68 10          	mov    0x10(%rax),%rbp
  6692f3:	4c 01 e5             	add    %r12,%rbp
  6692f6:	48 3b 6c 24 20       	cmp    0x20(%rsp),%rbp
  6692fb:	0f 83 62 02 00 00    	jae    669563 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19c3>
  669301:	48 8d 04 ad 00 00 00 	lea    0x0(,%rbp,4),%rax
  669308:	00 
  669309:	48 01 e8             	add    %rbp,%rax
  66930c:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
  669313:	00 
  669314:	48 8b 6c c1 10       	mov    0x10(%rcx,%rax,8),%rbp
  669319:	48 2b 6c 24 50       	sub    0x50(%rsp),%rbp
  66931e:	4c 39 fd             	cmp    %r15,%rbp
  669321:	48 8d bc 24 30 03 00 	lea    0x330(%rsp),%rdi
  669328:	00 
  669329:	0f 83 59 02 00 00    	jae    669588 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19e8>
  66932f:	f3 0f 11 4c 24 30    	movss  %xmm1,0x30(%rsp)
  669335:	f3 0f 11 4c eb 04    	movss  %xmm1,0x4(%rbx,%rbp,8)
  66933b:	e8 60 7b 01 00       	call   680ea0 <<parley::layout::run::Run<()>>::advance>
  669340:	e9 bb fe ff ff       	jmp    669200 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1660>
  669345:	4c 8d b4 24 30 03 00 	lea    0x330(%rsp),%r14
  66934c:	00 
  66934d:	48 8d b4 24 50 04 00 	lea    0x450(%rsp),%rsi
  669354:	00 
  669355:	ba a8 00 00 00       	mov    $0xa8,%edx
  66935a:	4c 89 f7             	mov    %r14,%rdi
  66935d:	ff 15 ed 0c 12 00    	call   *0x120ced(%rip)        # 78a050 <memcpy@GLIBC_2.14>
  669363:	4c 89 ef             	mov    %r13,%rdi
  669366:	4c 89 f6             	mov    %r14,%rsi
  669369:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  66936f:	48 8b 94 24 a8 00 00 	mov    0xa8(%rsp),%rdx
  669376:	00 
  669377:	e8 64 12 00 00       	call   66a5e0 <parley::editing::geometry::visit_direct::<(), gpui_canvas::Error, core::iter::adapters::peekable::Peekable<icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>>, gpui_canvas::text::planner::append_carets::{closure#1}>>
  66937c:	eb 63                	jmp    6693e1 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1841>
  66937e:	31 ed                	xor    %ebp,%ebp
  669380:	4c 89 ef             	mov    %r13,%rdi
  669383:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
  669388:	48 89 de             	mov    %rbx,%rsi
  66938b:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  669391:	48 8b 94 24 a8 00 00 	mov    0xa8(%rsp),%rdx
  669398:	00 
  669399:	e8 72 14 00 00       	call   66a810 <parley::editing::geometry::visit_indexed::<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>>
  66939e:	e9 d1 00 00 00       	jmp    669474 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18d4>
  6693a3:	4c 8d b4 24 00 02 00 	lea    0x200(%rsp),%r14
  6693aa:	00 
  6693ab:	48 8d b4 24 50 04 00 	lea    0x450(%rsp),%rsi
  6693b2:	00 
  6693b3:	ba a8 00 00 00       	mov    $0xa8,%edx
  6693b8:	4c 89 f7             	mov    %r14,%rdi
  6693bb:	ff 15 8f 0c 12 00    	call   *0x120c8f(%rip)        # 78a050 <memcpy@GLIBC_2.14>
  6693c1:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  6693c6:	4c 89 f6             	mov    %r14,%rsi
  6693c9:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  6693cf:	48 8b 94 24 a8 00 00 	mov    0xa8(%rsp),%rdx
  6693d6:	00 
  6693d7:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
  6693dc:	e8 ff 11 00 00       	call   66a5e0 <parley::editing::geometry::visit_direct::<(), gpui_canvas::Error, core::iter::adapters::peekable::Peekable<icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>>, gpui_canvas::text::planner::append_carets::{closure#1}>>
  6693e1:	41 89 c6             	mov    %eax,%r14d
  6693e4:	eb 24                	jmp    66940a <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x186a>
  6693e6:	48 8b b4 24 60 04 00 	mov    0x460(%rsp),%rsi
  6693ed:	00 
  6693ee:	48 85 f6             	test   %rsi,%rsi
  6693f1:	74 17                	je     66940a <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x186a>
  6693f3:	48 8b bc 24 68 04 00 	mov    0x468(%rsp),%rdi
  6693fa:	00 
  6693fb:	48 c1 e6 03          	shl    $0x3,%rsi
  6693ff:	ba 08 00 00 00       	mov    $0x8,%edx
  669404:	ff 15 ae 0b 12 00    	call   *0x120bae(%rip)        # 789fb8 <_DYNAMIC+0x238>
  66940a:	48 8b b4 24 28 01 00 	mov    0x128(%rsp),%rsi
  669411:	00 
  669412:	48 85 f6             	test   %rsi,%rsi
  669415:	74 17                	je     66942e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x188e>
  669417:	48 8b bc 24 30 01 00 	mov    0x130(%rsp),%rdi
  66941e:	00 
  66941f:	48 c1 e6 02          	shl    $0x2,%rsi
  669423:	ba 04 00 00 00       	mov    $0x4,%edx
  669428:	ff 15 8a 0b 12 00    	call   *0x120b8a(%rip)        # 789fb8 <_DYNAMIC+0x238>
  66942e:	48 8b b4 24 40 01 00 	mov    0x140(%rsp),%rsi
  669435:	00 
  669436:	48 85 f6             	test   %rsi,%rsi
  669439:	0f 84 95 00 00 00    	je     6694d4 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1934>
  66943f:	48 8b bc 24 48 01 00 	mov    0x148(%rsp),%rdi
  669446:	00 
  669447:	48 c1 e6 03          	shl    $0x3,%rsi
  66944b:	ba 04 00 00 00       	mov    $0x4,%edx
  669450:	eb 7c                	jmp    6694ce <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x192e>
  669452:	31 ed                	xor    %ebp,%ebp
  669454:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  669459:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
  66945e:	48 89 de             	mov    %rbx,%rsi
  669461:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  669467:	48 8b 94 24 a8 00 00 	mov    0xa8(%rsp),%rdx
  66946e:	00 
  66946f:	e8 9c 13 00 00       	call   66a810 <parley::editing::geometry::visit_indexed::<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>>
  669474:	41 89 c6             	mov    %eax,%r14d
  669477:	31 ff                	xor    %edi,%edi
  669479:	eb 09                	jmp    669484 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18e4>
  66947b:	41 be fe ff ff ff    	mov    $0xfffffffe,%r14d
  669481:	40 b7 01             	mov    $0x1,%dil
  669484:	48 8b b4 24 40 01 00 	mov    0x140(%rsp),%rsi
  66948b:	00 
  66948c:	48 85 f6             	test   %rsi,%rsi
  66948f:	74 1b                	je     6694ac <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x190c>
  669491:	89 fb                	mov    %edi,%ebx
  669493:	48 8b bc 24 48 01 00 	mov    0x148(%rsp),%rdi
  66949a:	00 
  66949b:	48 c1 e6 03          	shl    $0x3,%rsi
  66949f:	ba 04 00 00 00       	mov    $0x4,%edx
  6694a4:	ff 15 0e 0b 12 00    	call   *0x120b0e(%rip)        # 789fb8 <_DYNAMIC+0x238>
  6694aa:	89 df                	mov    %ebx,%edi
  6694ac:	40 84 ff             	test   %dil,%dil
  6694af:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  6694b4:	74 1e                	je     6694d4 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1934>
  6694b6:	48 89 f0             	mov    %rsi,%rax
  6694b9:	48 8b 36             	mov    (%rsi),%rsi
  6694bc:	48 85 f6             	test   %rsi,%rsi
  6694bf:	74 13                	je     6694d4 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1934>
  6694c1:	48 8b 78 08          	mov    0x8(%rax),%rdi
  6694c5:	48 c1 e6 03          	shl    $0x3,%rsi
  6694c9:	ba 08 00 00 00       	mov    $0x8,%edx
  6694ce:	ff 15 e4 0a 12 00    	call   *0x120ae4(%rip)        # 789fb8 <_DYNAMIC+0x238>
  6694d4:	44 89 f0             	mov    %r14d,%eax
  6694d7:	48 81 c4 a8 07 00 00 	add    $0x7a8,%rsp
  6694de:	5b                   	pop    %rbx
  6694df:	41 5c                	pop    %r12
  6694e1:	41 5d                	pop    %r13
  6694e3:	41 5e                	pop    %r14
  6694e5:	41 5f                	pop    %r15
  6694e7:	5d                   	pop    %rbp
  6694e8:	c3                   	ret
  6694e9:	48 8d 0d 48 60 11 00 	lea    0x116048(%rip),%rcx        # 77f538 <anon.98eb2121465841304e196c1cc83cb241.23.llvm.14436572662246312189>
  6694f0:	ff 15 ea 0d 12 00    	call   *0x120dea(%rip)        # 78a2e0 <_DYNAMIC+0x560>
  6694f6:	e9 39 01 00 00       	jmp    669634 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a94>
  6694fb:	48 8d 0d 7e 70 11 00 	lea    0x11707e(%rip),%rcx        # 780580 <anon.c85b311aa65b1c615d2dfba884aacc4b.17.llvm.6911206892222571341>
  669502:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  669507:	ff 15 d3 0d 12 00    	call   *0x120dd3(%rip)        # 78a2e0 <_DYNAMIC+0x560>
  66950d:	e9 22 01 00 00       	jmp    669634 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a94>
  669512:	48 8d 3d bb 1f bf ff 	lea    -0x40e045(%rip),%rdi        # 25b4d4 <gpui_canvas::text::PRIMARY_BYTES+0x1f458c>
  669519:	48 8d 15 28 5f 11 00 	lea    0x115f28(%rip),%rdx        # 77f448 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0xa8>
  669520:	be 21 00 00 00       	mov    $0x21,%esi
  669525:	ff 15 35 0d 12 00    	call   *0x120d35(%rip)        # 78a260 <_DYNAMIC+0x4e0>
  66952b:	e9 04 01 00 00       	jmp    669634 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a94>
  669530:	40 b5 01             	mov    $0x1,%bpl
  669533:	48 8d 15 46 60 11 00 	lea    0x116046(%rip),%rdx        # 77f580 <anon.98eb2121465841304e196c1cc83cb241.28.llvm.14436572662246312189>
  66953a:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
  66953f:	ff 15 9b 0b 12 00    	call   *0x120b9b(%rip)        # 78a0e0 <_DYNAMIC+0x360>
  669545:	e9 ea 00 00 00       	jmp    669634 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a94>
  66954a:	48 8b 84 24 20 01 00 	mov    0x120(%rsp),%rax
  669551:	00 
  669552:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  669557:	48 8d 05 7a 5f 11 00 	lea    0x115f7a(%rip),%rax        # 77f4d8 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0x138>
  66955e:	e9 b9 00 00 00       	jmp    66961c <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a7c>
  669563:	48 8d 05 3e 5f 11 00 	lea    0x115f3e(%rip),%rax        # 77f4a8 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0x108>
  66956a:	e9 ad 00 00 00       	jmp    66961c <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a7c>
  66956f:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
  669576:	00 
  669577:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  66957c:	48 8d 05 6d 5f 11 00 	lea    0x115f6d(%rip),%rax        # 77f4f0 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0x150>
  669583:	e9 94 00 00 00       	jmp    66961c <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a7c>
  669588:	4c 89 7c 24 20       	mov    %r15,0x20(%rsp)
  66958d:	48 8d 05 2c 5f 11 00 	lea    0x115f2c(%rip),%rax        # 77f4c0 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0x120>
  669594:	e9 83 00 00 00       	jmp    66961c <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a7c>
  669599:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
  6695a0:	00 
  6695a1:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  6695a6:	48 8d 05 5b 5f 11 00 	lea    0x115f5b(%rip),%rax        # 77f508 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0x168>
  6695ad:	eb 6d                	jmp    66961c <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a7c>
  6695af:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  6695b4:	48 8d 05 c5 5f 11 00 	lea    0x115fc5(%rip),%rax        # 77f580 <anon.98eb2121465841304e196c1cc83cb241.28.llvm.14436572662246312189>
  6695bb:	eb 5f                	jmp    66961c <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a7c>
  6695bd:	31 ed                	xor    %ebp,%ebp
  6695bf:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
  6695c6:	00 00 
  6695c8:	eb 57                	jmp    669621 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a81>
  6695ca:	4c 89 f5             	mov    %r14,%rbp
  6695cd:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  6695d2:	48 8d 05 9f 5e 11 00 	lea    0x115e9f(%rip),%rax        # 77f478 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0xd8>
  6695d9:	eb 41                	jmp    66961c <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a7c>
  6695db:	48 3b 8c 24 c0 00 00 	cmp    0xc0(%rsp),%rcx
  6695e2:	00 
  6695e3:	48 8d 05 a6 5e 11 00 	lea    0x115ea6(%rip),%rax        # 77f490 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0xf0>
  6695ea:	48 8d 0d 6f 5e 11 00 	lea    0x115e6f(%rip),%rcx        # 77f460 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0xc0>
  6695f1:	48 0f 42 c8          	cmovb  %rax,%rcx
  6695f5:	48 89 8c 24 c0 01 00 	mov    %rcx,0x1c0(%rsp)
  6695fc:	00 
  6695fd:	48 8b bc 24 c0 01 00 	mov    0x1c0(%rsp),%rdi
  669604:	00 
  669605:	ff 15 ad 0a 12 00    	call   *0x120aad(%rip)        # 78a0b8 <_DYNAMIC+0x338>
  66960b:	eb 27                	jmp    669634 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a94>
  66960d:	48 89 c5             	mov    %rax,%rbp
  669610:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  669615:	48 8d 05 4c 5f 11 00 	lea    0x115f4c(%rip),%rax        # 77f568 <anon.98eb2121465841304e196c1cc83cb241.26.llvm.14436572662246312189>
  66961c:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  669621:	48 89 ef             	mov    %rbp,%rdi
  669624:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  669629:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
  66962e:	ff 15 ac 0a 12 00    	call   *0x120aac(%rip)        # 78a0e0 <_DYNAMIC+0x360>
  669634:	0f 0b                	ud2
  669636:	49 89 c6             	mov    %rax,%r14
  669639:	eb 53                	jmp    66968e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1aee>
  66963b:	eb 25                	jmp    669662 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ac2>
  66963d:	eb 23                	jmp    669662 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ac2>
  66963f:	eb 12                	jmp    669653 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ab3>
  669641:	eb 1f                	jmp    669662 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ac2>
  669643:	eb 0e                	jmp    669653 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ab3>
  669645:	eb 1b                	jmp    669662 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ac2>
  669647:	eb 0a                	jmp    669653 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ab3>
  669649:	eb 08                	jmp    669653 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ab3>
  66964b:	eb 15                	jmp    669662 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ac2>
  66964d:	eb 13                	jmp    669662 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ac2>
  66964f:	eb 11                	jmp    669662 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ac2>
  669651:	eb 00                	jmp    669653 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ab3>
  669653:	49 89 c6             	mov    %rax,%r14
  669656:	40 b5 01             	mov    $0x1,%bpl
  669659:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
  66965e:	eb 5d                	jmp    6696bd <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1b1d>
  669660:	eb 00                	jmp    669662 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ac2>
  669662:	49 89 c6             	mov    %rax,%r14
  669665:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
  66966a:	48 8b b4 24 60 04 00 	mov    0x460(%rsp),%rsi
  669671:	00 
  669672:	48 85 f6             	test   %rsi,%rsi
  669675:	74 17                	je     66968e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1aee>
  669677:	48 8b bc 24 68 04 00 	mov    0x468(%rsp),%rdi
  66967e:	00 
  66967f:	48 c1 e6 03          	shl    $0x3,%rsi
  669683:	ba 08 00 00 00       	mov    $0x8,%edx
  669688:	ff 15 2a 09 12 00    	call   *0x12092a(%rip)        # 789fb8 <_DYNAMIC+0x238>
  66968e:	48 8b b4 24 28 01 00 	mov    0x128(%rsp),%rsi
  669695:	00 
  669696:	48 85 f6             	test   %rsi,%rsi
  669699:	75 04                	jne    66969f <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1aff>
  66969b:	31 ed                	xor    %ebp,%ebp
  66969d:	eb 1e                	jmp    6696bd <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1b1d>
  66969f:	48 8b bc 24 30 01 00 	mov    0x130(%rsp),%rdi
  6696a6:	00 
  6696a7:	48 c1 e6 02          	shl    $0x2,%rsi
  6696ab:	ba 04 00 00 00       	mov    $0x4,%edx
  6696b0:	ff 15 02 09 12 00    	call   *0x120902(%rip)        # 789fb8 <_DYNAMIC+0x238>
  6696b6:	31 ed                	xor    %ebp,%ebp
  6696b8:	eb 03                	jmp    6696bd <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1b1d>
  6696ba:	49 89 c6             	mov    %rax,%r14
  6696bd:	48 8b b4 24 40 01 00 	mov    0x140(%rsp),%rsi
  6696c4:	00 
  6696c5:	48 85 f6             	test   %rsi,%rsi
  6696c8:	74 17                	je     6696e1 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1b41>
  6696ca:	48 8b bc 24 48 01 00 	mov    0x148(%rsp),%rdi
  6696d1:	00 
  6696d2:	48 c1 e6 03          	shl    $0x3,%rsi
  6696d6:	ba 04 00 00 00       	mov    $0x4,%edx
  6696db:	ff 15 d7 08 12 00    	call   *0x1208d7(%rip)        # 789fb8 <_DYNAMIC+0x238>
  6696e1:	40 84 ed             	test   %bpl,%bpl
  6696e4:	74 1b                	je     669701 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1b61>
  6696e6:	48 8b 33             	mov    (%rbx),%rsi
  6696e9:	48 85 f6             	test   %rsi,%rsi
  6696ec:	74 13                	je     669701 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1b61>
  6696ee:	48 8b 7b 08          	mov    0x8(%rbx),%rdi
  6696f2:	48 c1 e6 03          	shl    $0x3,%rsi
  6696f6:	ba 08 00 00 00       	mov    $0x8,%edx
  6696fb:	ff 15 b7 08 12 00    	call   *0x1208b7(%rip)        # 789fb8 <_DYNAMIC+0x238>
  669701:	4c 89 f7             	mov    %r14,%rdi
  669704:	e8 d7 48 11 00       	call   77dfe0 <_Unwind_Resume@plt>
