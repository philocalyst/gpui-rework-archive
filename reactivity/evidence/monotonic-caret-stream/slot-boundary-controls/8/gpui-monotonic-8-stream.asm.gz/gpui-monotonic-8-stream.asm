
/tmp/gpui-monotonic-control-bin/stream8:     file format elf64-x86-64


Disassembly of section .text:

0000000000676620 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>>:
  676620:	55                   	push   %rbp
  676621:	41 57                	push   %r15
  676623:	41 56                	push   %r14
  676625:	41 55                	push   %r13
  676627:	41 54                	push   %r12
  676629:	53                   	push   %rbx
  67662a:	48 81 ec a8 07 00 00 	sub    $0x7a8,%rsp
  676631:	49 89 d7             	mov    %rdx,%r15
  676634:	4c 8b a7 50 01 00 00 	mov    0x150(%rdi),%r12
  67663b:	4c 89 e0             	mov    %r12,%rax
  67663e:	48 c1 e8 20          	shr    $0x20,%rax
  676642:	74 10                	je     676654 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x34>
  676644:	4c 89 fa             	mov    %r15,%rdx
  676647:	e8 84 2c 00 00       	call   6792d0 <parley::editing::geometry::visit_indexed::<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>>
  67664c:	41 89 c6             	mov    %eax,%r14d
  67664f:	e9 ae 18 00 00       	jmp    677f02 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18e2>
  676654:	f3 0f 11 44 24 14    	movss  %xmm0,0x14(%rsp)
  67665a:	41 be fe ff ff ff    	mov    $0xfffffffe,%r14d
  676660:	83 7f 74 00          	cmpl   $0x0,0x74(%rdi)
  676664:	0f 85 7a 18 00 00    	jne    677ee4 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18c4>
  67666a:	48 8b 97 18 01 00 00 	mov    0x118(%rdi),%rdx
  676671:	48 89 d0             	mov    %rdx,%rax
  676674:	48 c1 e8 20          	shr    $0x20,%rax
  676678:	0f 85 66 18 00 00    	jne    677ee4 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18c4>
  67667e:	48 c7 84 24 b8 00 00 	movq   $0x0,0xb8(%rsp)
  676685:	00 00 00 00 00 
  67668a:	48 c7 84 24 c0 00 00 	movq   $0x4,0xc0(%rsp)
  676691:	00 04 00 00 00 
  676696:	48 c7 84 24 c8 00 00 	movq   $0x0,0xc8(%rsp)
  67669d:	00 00 00 00 00 
  6766a2:	48 8b 8f 10 01 00 00 	mov    0x110(%rdi),%rcx
  6766a9:	48 6b c2 70          	imul   $0x70,%rdx,%rax
  6766ad:	48 89 4c 24 58       	mov    %rcx,0x58(%rsp)
  6766b2:	48 01 c8             	add    %rcx,%rax
  6766b5:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
  6766bc:	00 
  6766bd:	48 85 d2             	test   %rdx,%rdx
  6766c0:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
  6766c5:	4c 89 bc 24 30 01 00 	mov    %r15,0x130(%rsp)
  6766cc:	00 
  6766cd:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
  6766d2:	48 89 94 24 e0 00 00 	mov    %rdx,0xe0(%rsp)
  6766d9:	00 
  6766da:	0f 84 58 03 00 00    	je     676a38 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x418>
  6766e0:	48 8b 87 30 01 00 00 	mov    0x130(%rdi),%rax
  6766e7:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
  6766ee:	00 
  6766ef:	48 8b af 28 01 00 00 	mov    0x128(%rdi),%rbp
  6766f6:	48 8b 47 50          	mov    0x50(%rdi),%rax
  6766fa:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
  6766ff:	48 8b 47 58          	mov    0x58(%rdi),%rax
  676703:	48 8b 8f e8 00 00 00 	mov    0xe8(%rdi),%rcx
  67670a:	48 39 c8             	cmp    %rcx,%rax
  67670d:	48 0f 42 c8          	cmovb  %rax,%rcx
  676711:	48 89 4c 24 70       	mov    %rcx,0x70(%rsp)
  676716:	48 8b 87 e0 00 00 00 	mov    0xe0(%rdi),%rax
  67671d:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  676722:	4d 85 e4             	test   %r12,%r12
  676725:	48 89 ac 24 e8 00 00 	mov    %rbp,0xe8(%rsp)
  67672c:	00 
  67672d:	0f 84 63 03 00 00    	je     676a96 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x476>
  676733:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
  67673a:	00 00 
  67673c:	4c 8d b4 24 b8 00 00 	lea    0xb8(%rsp),%r14
  676743:	00 
  676744:	41 bd ff ff ff ff    	mov    $0xffffffff,%r13d
  67674a:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
  676751:	00 00 
  676753:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
  67675a:	00 00 
  67675c:	48 8b 5c 24 58       	mov    0x58(%rsp),%rbx
  676761:	48 c7 84 24 80 00 00 	movq   $0x0,0x80(%rsp)
  676768:	00 00 00 00 00 
  67676d:	eb 30                	jmp    67679f <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x17f>
  67676f:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
  676776:	00 
  676777:	48 89 cb             	mov    %rcx,%rbx
  67677a:	8b 84 24 d0 00 00 00 	mov    0xd0(%rsp),%eax
  676781:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  676788:	00 
  676789:	48 3b 8c 24 60 01 00 	cmp    0x160(%rsp),%rcx
  676790:	00 
  676791:	4c 8b bc 24 30 01 00 	mov    0x130(%rsp),%r15
  676798:	00 
  676799:	0f 84 af 02 00 00    	je     676a4e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x42e>
  67679f:	48 8b 73 10          	mov    0x10(%rbx),%rsi
  6767a3:	48 8b 53 18          	mov    0x18(%rbx),%rdx
  6767a7:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  6767ac:	4c 89 f1             	mov    %r14,%rcx
  6767af:	e8 9c 26 00 00       	call   678e50 <parley::editing::geometry::source_runs::<()>>
  6767b4:	48 83 f8 01          	cmp    $0x1,%rax
  6767b8:	0f 85 f6 15 00 00    	jne    677db4 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1794>
  6767be:	48 89 9c 24 28 01 00 	mov    %rbx,0x128(%rsp)
  6767c5:	00 
  6767c6:	48 8d 43 70          	lea    0x70(%rbx),%rax
  6767ca:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  6767d1:	00 
  6767d2:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  6767d9:	00 
  6767da:	ff c0                	inc    %eax
  6767dc:	89 84 24 d0 00 00 00 	mov    %eax,0xd0(%rsp)
  6767e3:	48 8b 9c 24 c0 00 00 	mov    0xc0(%rsp),%rbx
  6767ea:	00 
  6767eb:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  6767f2:	00 
  6767f3:	4c 8d 3c c3          	lea    (%rbx,%rax,8),%r15
  6767f7:	48 89 9c 24 98 00 00 	mov    %rbx,0x98(%rsp)
  6767fe:	00 
  6767ff:	90                   	nop
  676800:	4c 39 fb             	cmp    %r15,%rbx
  676803:	0f 84 66 ff ff ff    	je     67676f <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x14f>
  676809:	8b 03                	mov    (%rbx),%eax
  67680b:	48 83 c3 08          	add    $0x8,%rbx
  67680f:	4c 39 e8             	cmp    %r13,%rax
  676812:	74 ec                	je     676800 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1e0>
  676814:	48 8b 94 24 28 01 00 	mov    0x128(%rsp),%rdx
  67681b:	00 
  67681c:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
  676820:	48 01 c1             	add    %rax,%rcx
  676823:	41 be fe ff ff ff    	mov    $0xfffffffe,%r14d
  676829:	40 b7 01             	mov    $0x1,%dil
  67682c:	48 3b 4a 18          	cmp    0x18(%rdx),%rcx
  676830:	0f 83 7c 16 00 00    	jae    677eb2 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1892>
  676836:	48 3b 8c 24 10 01 00 	cmp    0x110(%rsp),%rcx
  67683d:	00 
  67683e:	0f 83 6e 16 00 00    	jae    677eb2 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1892>
  676844:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
  676848:	80 7c cd 21 00       	cmpb   $0x0,0x21(%rbp,%rcx,8)
  67684d:	0f 85 5f 16 00 00    	jne    677eb2 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1892>
  676853:	48 8d 14 cd 00 00 00 	lea    0x0(,%rcx,8),%rdx
  67685a:	00 
  67685b:	48 01 ea             	add    %rbp,%rdx
  67685e:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
  676862:	48 3b 4c 24 70       	cmp    0x70(%rsp),%rcx
  676867:	0f 83 45 16 00 00    	jae    677eb2 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1892>
  67686d:	4c 8d 04 c9          	lea    (%rcx,%rcx,8),%r8
  676871:	49 c1 e0 04          	shl    $0x4,%r8
  676875:	4c 03 44 24 68       	add    0x68(%rsp),%r8
  67687a:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
  67687e:	48 c1 e6 04          	shl    $0x4,%rsi
  676882:	48 03 74 24 20       	add    0x20(%rsp),%rsi
  676887:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  67688c:	48 89 bc 24 30 03 00 	mov    %rdi,0x330(%rsp)
  676893:	00 
  676894:	4c 89 84 24 20 01 00 	mov    %r8,0x120(%rsp)
  67689b:	00 
  67689c:	4c 89 84 24 38 03 00 	mov    %r8,0x338(%rsp)
  6768a3:	00 
  6768a4:	48 89 b4 24 40 03 00 	mov    %rsi,0x340(%rsp)
  6768ab:	00 
  6768ac:	48 89 94 24 48 03 00 	mov    %rdx,0x348(%rsp)
  6768b3:	00 
  6768b4:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
  6768bb:	00 
  6768bc:	89 94 24 50 03 00 00 	mov    %edx,0x350(%rsp)
  6768c3:	89 84 24 54 03 00 00 	mov    %eax,0x354(%rsp)
  6768ca:	89 8c 24 58 03 00 00 	mov    %ecx,0x358(%rsp)
  6768d1:	4c 8d b4 24 98 06 00 	lea    0x698(%rsp),%r14
  6768d8:	00 
  6768d9:	4c 89 f7             	mov    %r14,%rdi
  6768dc:	4c 8d ac 24 30 03 00 	lea    0x330(%rsp),%r13
  6768e3:	00 
  6768e4:	4c 89 ee             	mov    %r13,%rsi
  6768e7:	31 d2                	xor    %edx,%edx
  6768e9:	e8 c2 a7 00 00       	call   6810b0 <<parley::layout::run::Clusters<()>>::new>
  6768ee:	ba 10 01 00 00       	mov    $0x110,%edx
  6768f3:	4c 89 ef             	mov    %r13,%rdi
  6768f6:	4c 89 f6             	mov    %r14,%rsi
  6768f9:	ff 15 81 34 11 00    	call   *0x113481(%rip)        # 789d80 <memcpy@GLIBC_2.14>
  6768ff:	45 31 ed             	xor    %r13d,%r13d
  676902:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  676909:	1f 84 00 00 00 00 00 
  676910:	48 8d bc 24 00 02 00 	lea    0x200(%rsp),%rdi
  676917:	00 
  676918:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
  67691f:	00 
  676920:	e8 eb cf 00 00       	call   683910 <<parley::layout::run::Clusters<()> as core::iter::traits::iterator::Iterator>::next>
  676925:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  67692a:	4a 8d 2c 28          	lea    (%rax,%r13,1),%rbp
  67692e:	48 8b 84 24 00 02 00 	mov    0x200(%rsp),%rax
  676935:	00 
  676936:	48 85 c0             	test   %rax,%rax
  676939:	0f 84 b5 00 00 00    	je     6769f4 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x3d4>
  67693f:	8b bc 24 28 02 00 00 	mov    0x228(%rsp),%edi
  676946:	48 8b 70 58          	mov    0x58(%rax),%rsi
  67694a:	48 39 fe             	cmp    %rdi,%rsi
  67694d:	0f 86 0b 16 00 00    	jbe    677f5e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x193e>
  676953:	8b b4 24 80 02 00 00 	mov    0x280(%rsp),%esi
  67695a:	8b 94 24 84 02 00 00 	mov    0x284(%rsp),%edx
  676961:	48 8b 48 50          	mov    0x50(%rax),%rcx
  676965:	48 8d 3c ff          	lea    (%rdi,%rdi,8),%rdi
  676969:	48 c1 e7 04          	shl    $0x4,%rdi
  67696d:	0f 10 40 68          	movups 0x68(%rax),%xmm0
  676971:	0f 10 88 80 00 00 00 	movups 0x80(%rax),%xmm1
  676978:	0f 10 90 98 00 00 00 	movups 0x98(%rax),%xmm2
  67697f:	0f 11 84 24 88 05 00 	movups %xmm0,0x588(%rsp)
  676986:	00 
  676987:	0f 11 8c 24 98 05 00 	movups %xmm1,0x598(%rsp)
  67698e:	00 
  67698f:	0f 11 94 24 a8 05 00 	movups %xmm2,0x5a8(%rsp)
  676996:	00 
  676997:	48 8b 44 39 50       	mov    0x50(%rcx,%rdi,1),%rax
  67699c:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
  6769a3:	00 
  6769a4:	48 8d bc 24 88 05 00 	lea    0x588(%rsp),%rdi
  6769ab:	00 
  6769ac:	ff 15 be 36 11 00    	call   *0x1136be(%rip)        # 78a070 <_DYNAMIC+0x5c0>
  6769b2:	41 be fe ff ff ff    	mov    $0xfffffffe,%r14d
  6769b8:	40 b7 01             	mov    $0x1,%dil
  6769bb:	48 39 d0             	cmp    %rdx,%rax
  6769be:	0f 87 ee 14 00 00    	ja     677eb2 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1892>
  6769c4:	4c 39 e2             	cmp    %r12,%rdx
  6769c7:	0f 87 e5 14 00 00    	ja     677eb2 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1892>
  6769cd:	48 39 d0             	cmp    %rdx,%rax
  6769d0:	73 10                	jae    6769e2 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x3c2>
  6769d2:	48 3b 44 24 30       	cmp    0x30(%rsp),%rax
  6769d7:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
  6769dc:	0f 82 9e 14 00 00    	jb     677e80 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1860>
  6769e2:	48 c1 ed 20          	shr    $0x20,%rbp
  6769e6:	0f 85 c6 14 00 00    	jne    677eb2 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1892>
  6769ec:	49 ff c5             	inc    %r13
  6769ef:	e9 1c ff ff ff       	jmp    676910 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x2f0>
  6769f4:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  6769f9:	49 39 c5             	cmp    %rax,%r13
  6769fc:	4c 0f 46 e8          	cmovbe %rax,%r13
  676a00:	48 8b 8c 24 20 01 00 	mov    0x120(%rsp),%rcx
  676a07:	00 
  676a08:	f6 81 8c 00 00 00 01 	testb  $0x1,0x8c(%rcx)
  676a0f:	49 0f 45 c5          	cmovne %r13,%rax
  676a13:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  676a18:	48 89 6c 24 50       	mov    %rbp,0x50(%rsp)
  676a1d:	48 8b ac 24 e8 00 00 	mov    0xe8(%rsp),%rbp
  676a24:	00 
  676a25:	4c 8d b4 24 b8 00 00 	lea    0xb8(%rsp),%r14
  676a2c:	00 
  676a2d:	41 bd ff ff ff ff    	mov    $0xffffffff,%r13d
  676a33:	e9 c8 fd ff ff       	jmp    676800 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1e0>
  676a38:	b8 04 00 00 00       	mov    $0x4,%eax
  676a3d:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
  676a44:	00 
  676a45:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
  676a4c:	00 00 
  676a4e:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  676a53:	4c 8d 34 85 00 00 00 	lea    0x0(,%rax,4),%r14
  676a5a:	00 
  676a5b:	48 c1 e8 3e          	shr    $0x3e,%rax
  676a5f:	0f 95 c0             	setne  %al
  676a62:	48 b9 fc ff ff ff ff 	movabs $0x7ffffffffffffffc,%rcx
  676a69:	ff ff 7f 
  676a6c:	49 39 ce             	cmp    %rcx,%r14
  676a6f:	0f 97 c1             	seta   %cl
  676a72:	08 c1                	or     %al,%cl
  676a74:	0f 84 59 02 00 00    	je     676cd3 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x6b3>
  676a7a:	45 31 e4             	xor    %r12d,%r12d
  676a7d:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
  676a82:	40 b5 01             	mov    $0x1,%bpl
  676a85:	4c 89 e7             	mov    %r12,%rdi
  676a88:	4c 89 f6             	mov    %r14,%rsi
  676a8b:	ff 15 6f 33 11 00    	call   *0x11336f(%rip)        # 789e00 <_DYNAMIC+0x350>
  676a91:	e9 c9 15 00 00       	jmp    67805f <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a3f>
  676a96:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
  676a9d:	00 00 
  676a9f:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
  676aa4:	4c 8d a4 24 98 06 00 	lea    0x698(%rsp),%r12
  676aab:	00 
  676aac:	48 c7 84 24 a0 00 00 	movq   $0x0,0xa0(%rsp)
  676ab3:	00 00 00 00 00 
  676ab8:	4c 8b 74 24 58       	mov    0x58(%rsp),%r14
  676abd:	45 31 ed             	xor    %r13d,%r13d
  676ac0:	eb 25                	jmp    676ae7 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x4c7>
  676ac2:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  676ac7:	49 89 c6             	mov    %rax,%r14
  676aca:	8b 4c 24 30          	mov    0x30(%rsp),%ecx
  676ace:	41 89 cd             	mov    %ecx,%r13d
  676ad1:	48 3b 84 24 60 01 00 	cmp    0x160(%rsp),%rax
  676ad8:	00 
  676ad9:	4c 8b bc 24 30 01 00 	mov    0x130(%rsp),%r15
  676ae0:	00 
  676ae1:	0f 84 67 ff ff ff    	je     676a4e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x42e>
  676ae7:	49 8b 76 10          	mov    0x10(%r14),%rsi
  676aeb:	49 8b 56 18          	mov    0x18(%r14),%rdx
  676aef:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  676af4:	48 8d 8c 24 b8 00 00 	lea    0xb8(%rsp),%rcx
  676afb:	00 
  676afc:	e8 4f 23 00 00       	call   678e50 <parley::editing::geometry::source_runs::<()>>
  676b01:	48 83 f8 01          	cmp    $0x1,%rax
  676b05:	0f 85 a9 12 00 00    	jne    677db4 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1794>
  676b0b:	49 8d 46 70          	lea    0x70(%r14),%rax
  676b0f:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  676b14:	4c 89 ac 24 80 00 00 	mov    %r13,0x80(%rsp)
  676b1b:	00 
  676b1c:	41 8d 45 01          	lea    0x1(%r13),%eax
  676b20:	89 44 24 30          	mov    %eax,0x30(%rsp)
  676b24:	4c 8b ac 24 c0 00 00 	mov    0xc0(%rsp),%r13
  676b2b:	00 
  676b2c:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  676b33:	00 
  676b34:	4c 8d 3c c5 00 00 00 	lea    0x0(,%rax,8),%r15
  676b3b:	00 
  676b3c:	4d 01 ef             	add    %r13,%r15
  676b3f:	4c 89 ac 24 98 00 00 	mov    %r13,0x98(%rsp)
  676b46:	00 
  676b47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  676b4e:	00 00 
  676b50:	4d 39 fd             	cmp    %r15,%r13
  676b53:	0f 84 69 ff ff ff    	je     676ac2 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x4a2>
  676b59:	41 8b 45 00          	mov    0x0(%r13),%eax
  676b5d:	49 83 c5 08          	add    $0x8,%r13
  676b61:	48 39 d8             	cmp    %rbx,%rax
  676b64:	74 ea                	je     676b50 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x530>
  676b66:	49 8b 4e 10          	mov    0x10(%r14),%rcx
  676b6a:	48 01 c1             	add    %rax,%rcx
  676b6d:	4c 89 f2             	mov    %r14,%rdx
  676b70:	41 be fe ff ff ff    	mov    $0xfffffffe,%r14d
  676b76:	40 b7 01             	mov    $0x1,%dil
  676b79:	48 89 94 24 d0 00 00 	mov    %rdx,0xd0(%rsp)
  676b80:	00 
  676b81:	48 3b 4a 18          	cmp    0x18(%rdx),%rcx
  676b85:	0f 83 27 13 00 00    	jae    677eb2 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1892>
  676b8b:	48 3b 8c 24 10 01 00 	cmp    0x110(%rsp),%rcx
  676b92:	00 
  676b93:	0f 83 19 13 00 00    	jae    677eb2 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1892>
  676b99:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
  676b9d:	80 7c cd 21 00       	cmpb   $0x0,0x21(%rbp,%rcx,8)
  676ba2:	0f 85 0a 13 00 00    	jne    677eb2 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1892>
  676ba8:	48 8d 14 cd 00 00 00 	lea    0x0(,%rcx,8),%rdx
  676baf:	00 
  676bb0:	48 01 ea             	add    %rbp,%rdx
  676bb3:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
  676bb7:	48 3b 4c 24 70       	cmp    0x70(%rsp),%rcx
  676bbc:	0f 83 f0 12 00 00    	jae    677eb2 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1892>
  676bc2:	4c 8d 34 c9          	lea    (%rcx,%rcx,8),%r14
  676bc6:	49 c1 e6 04          	shl    $0x4,%r14
  676bca:	4c 03 74 24 68       	add    0x68(%rsp),%r14
  676bcf:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
  676bd3:	48 c1 e6 04          	shl    $0x4,%rsi
  676bd7:	48 03 74 24 20       	add    0x20(%rsp),%rsi
  676bdc:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  676be1:	48 89 bc 24 30 03 00 	mov    %rdi,0x330(%rsp)
  676be8:	00 
  676be9:	4c 89 b4 24 38 03 00 	mov    %r14,0x338(%rsp)
  676bf0:	00 
  676bf1:	48 89 b4 24 40 03 00 	mov    %rsi,0x340(%rsp)
  676bf8:	00 
  676bf9:	48 89 94 24 48 03 00 	mov    %rdx,0x348(%rsp)
  676c00:	00 
  676c01:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
  676c08:	00 
  676c09:	89 94 24 50 03 00 00 	mov    %edx,0x350(%rsp)
  676c10:	89 84 24 54 03 00 00 	mov    %eax,0x354(%rsp)
  676c17:	89 8c 24 58 03 00 00 	mov    %ecx,0x358(%rsp)
  676c1e:	4c 89 e7             	mov    %r12,%rdi
  676c21:	48 8d ac 24 30 03 00 	lea    0x330(%rsp),%rbp
  676c28:	00 
  676c29:	48 89 ee             	mov    %rbp,%rsi
  676c2c:	31 d2                	xor    %edx,%edx
  676c2e:	e8 7d a4 00 00       	call   6810b0 <<parley::layout::run::Clusters<()>>::new>
  676c33:	ba 10 01 00 00       	mov    $0x110,%edx
  676c38:	48 89 ef             	mov    %rbp,%rdi
  676c3b:	4c 89 e6             	mov    %r12,%rsi
  676c3e:	ff 15 3c 31 11 00    	call   *0x11313c(%rip)        # 789d80 <memcpy@GLIBC_2.14>
  676c44:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  676c4b:	00 
  676c4c:	48 8d 68 01          	lea    0x1(%rax),%rbp
  676c50:	45 31 e4             	xor    %r12d,%r12d
  676c53:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  676c5a:	84 00 00 00 00 00 
  676c60:	48 8d bc 24 00 02 00 	lea    0x200(%rsp),%rdi
  676c67:	00 
  676c68:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
  676c6f:	00 
  676c70:	e8 9b cc 00 00       	call   683910 <<parley::layout::run::Clusters<()> as core::iter::traits::iterator::Iterator>::next>
  676c75:	48 83 bc 24 00 02 00 	cmpq   $0x0,0x200(%rsp)
  676c7c:	00 00 
  676c7e:	74 0e                	je     676c8e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x66e>
  676c80:	4c 39 e5             	cmp    %r12,%rbp
  676c83:	0f 84 20 12 00 00    	je     677ea9 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1889>
  676c89:	49 ff cc             	dec    %r12
  676c8c:	eb d2                	jmp    676c60 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x640>
  676c8e:	4c 29 a4 24 a0 00 00 	sub    %r12,0xa0(%rsp)
  676c95:	00 
  676c96:	49 f7 dc             	neg    %r12
  676c99:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  676c9e:	49 39 c4             	cmp    %rax,%r12
  676ca1:	4c 0f 46 e0          	cmovbe %rax,%r12
  676ca5:	41 f6 86 8c 00 00 00 	testb  $0x1,0x8c(%r14)
  676cac:	01 
  676cad:	49 0f 45 c4          	cmovne %r12,%rax
  676cb1:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  676cb6:	48 8b ac 24 e8 00 00 	mov    0xe8(%rsp),%rbp
  676cbd:	00 
  676cbe:	4c 8d a4 24 98 06 00 	lea    0x698(%rsp),%r12
  676cc5:	00 
  676cc6:	4c 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%r14
  676ccd:	00 
  676cce:	e9 7d fe ff ff       	jmp    676b50 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x530>
  676cd3:	4d 85 f6             	test   %r14,%r14
  676cd6:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
  676cdb:	74 2a                	je     676d07 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x6e7>
  676cdd:	ff 15 95 30 11 00    	call   *0x113095(%rip)        # 789d78 <_DYNAMIC+0x2c8>
  676ce3:	41 bc 04 00 00 00    	mov    $0x4,%r12d
  676ce9:	be 04 00 00 00       	mov    $0x4,%esi
  676cee:	4c 89 f7             	mov    %r14,%rdi
  676cf1:	ff 15 e9 2f 11 00    	call   *0x112fe9(%rip)        # 789ce0 <_DYNAMIC+0x230>
  676cf7:	48 85 c0             	test   %rax,%rax
  676cfa:	0f 84 82 fd ff ff    	je     676a82 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x462>
  676d00:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
  676d05:	eb 07                	jmp    676d0e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x6ee>
  676d07:	b8 04 00 00 00       	mov    $0x4,%eax
  676d0c:	31 c9                	xor    %ecx,%ecx
  676d0e:	48 89 8c 24 38 01 00 	mov    %rcx,0x138(%rsp)
  676d15:	00 
  676d16:	48 89 84 24 40 01 00 	mov    %rax,0x140(%rsp)
  676d1d:	00 
  676d1e:	48 c7 84 24 48 01 00 	movq   $0x0,0x148(%rsp)
  676d25:	00 00 00 00 00 
  676d2a:	48 8d bc 24 60 04 00 	lea    0x460(%rsp),%rdi
  676d31:	00 
  676d32:	ba 98 00 00 00       	mov    $0x98,%edx
  676d37:	48 89 de             	mov    %rbx,%rsi
  676d3a:	ff 15 40 30 11 00    	call   *0x113040(%rip)        # 789d80 <memcpy@GLIBC_2.14>
  676d40:	48 c7 84 24 50 04 00 	movq   $0x2,0x450(%rsp)
  676d47:	00 02 00 00 00 
  676d4c:	48 83 bc 24 e0 00 00 	cmpq   $0x0,0xe0(%rsp)
  676d53:	00 00 
  676d55:	0f 84 23 10 00 00    	je     677d7e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x175e>
  676d5b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  676d60:	48 8b 88 30 01 00 00 	mov    0x130(%rax),%rcx
  676d67:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  676d6c:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
  676d73:	48 89 4c 24 68       	mov    %rcx,0x68(%rsp)
  676d78:	48 8b 48 58          	mov    0x58(%rax),%rcx
  676d7c:	48 8b 90 e8 00 00 00 	mov    0xe8(%rax),%rdx
  676d83:	48 39 d1             	cmp    %rdx,%rcx
  676d86:	48 89 94 24 c8 01 00 	mov    %rdx,0x1c8(%rsp)
  676d8d:	00 
  676d8e:	48 89 8c 24 20 01 00 	mov    %rcx,0x120(%rsp)
  676d95:	00 
  676d96:	48 0f 42 d1          	cmovb  %rcx,%rdx
  676d9a:	48 89 94 24 20 03 00 	mov    %rdx,0x320(%rsp)
  676da1:	00 
  676da2:	48 8b 88 e0 00 00 00 	mov    0xe0(%rax),%rcx
  676da9:	48 89 8c 24 e8 00 00 	mov    %rcx,0xe8(%rsp)
  676db0:	00 
  676db1:	48 8b 48 50          	mov    0x50(%rax),%rcx
  676db5:	48 89 8c 24 28 01 00 	mov    %rcx,0x128(%rsp)
  676dbc:	00 
  676dbd:	48 8b 48 38          	mov    0x38(%rax),%rcx
  676dc1:	48 89 8c 24 28 03 00 	mov    %rcx,0x328(%rsp)
  676dc8:	00 
  676dc9:	48 8b 40 40          	mov    0x40(%rax),%rax
  676dcd:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
  676dd4:	00 
  676dd5:	48 8d 8c 24 b8 00 00 	lea    0xb8(%rsp),%rcx
  676ddc:	00 
  676ddd:	48 8d 05 04 8a 10 00 	lea    0x108a04(%rip),%rax        # 77f7e8 <anon.06a23643b1506f5b010724d430886465.32.llvm.301643317217076259+0xa8>
  676de4:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
  676deb:	00 
  676dec:	48 8d 05 b5 8a 10 00 	lea    0x108ab5(%rip),%rax        # 77f8a8 <anon.078e2e963a048095b6b8e4da3cd13e67.21.llvm.9964956014867501821>
  676df3:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  676df8:	48 c7 84 24 a0 01 00 	movq   $0x0,0x1a0(%rsp)
  676dff:	00 00 00 00 00 
  676e04:	48 c7 44 24 70 00 00 	movq   $0x0,0x70(%rsp)
  676e0b:	00 00 
  676e0d:	eb 27                	jmp    676e36 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x816>
  676e0f:	4c 89 5c 24 58       	mov    %r11,0x58(%rsp)
  676e14:	89 e8                	mov    %ebp,%eax
  676e16:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  676e1b:	4c 3b 9c 24 60 01 00 	cmp    0x160(%rsp),%r11
  676e22:	00 
  676e23:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
  676e28:	48 8d 8c 24 b8 00 00 	lea    0xb8(%rsp),%rcx
  676e2f:	00 
  676e30:	0f 84 48 0f 00 00    	je     677d7e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x175e>
  676e36:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  676e3b:	48 8b 70 10          	mov    0x10(%rax),%rsi
  676e3f:	48 8b 50 18          	mov    0x18(%rax),%rdx
  676e43:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  676e48:	e8 03 20 00 00       	call   678e50 <parley::editing::geometry::source_runs::<()>>
  676e4d:	48 83 f8 01          	cmp    $0x1,%rax
  676e51:	0f 85 e9 10 00 00    	jne    677f40 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1920>
  676e57:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  676e5c:	48 8b 78 10          	mov    0x10(%rax),%rdi
  676e60:	48 8b 70 18          	mov    0x18(%rax),%rsi
  676e64:	48 39 fe             	cmp    %rdi,%rsi
  676e67:	0f 82 bc 10 00 00    	jb     677f29 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1909>
  676e6d:	48 3b 74 24 20       	cmp    0x20(%rsp),%rsi
  676e72:	0f 87 b1 10 00 00    	ja     677f29 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1909>
  676e78:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
  676e7f:	00 
  676e80:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
  676e87:	00 
  676e88:	48 8b 9c 24 c8 00 00 	mov    0xc8(%rsp),%rbx
  676e8f:	00 
  676e90:	48 39 f7             	cmp    %rsi,%rdi
  676e93:	0f 85 80 0d 00 00    	jne    677c19 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x15f9>
  676e99:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  676e9e:	4c 8d 58 70          	lea    0x70(%rax),%r11
  676ea2:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  676ea7:	8d 68 01             	lea    0x1(%rax),%ebp
  676eaa:	48 8b 84 24 98 00 00 	mov    0x98(%rsp),%rax
  676eb1:	00 
  676eb2:	4c 8d 34 d8          	lea    (%rax,%rbx,8),%r14
  676eb6:	48 89 c3             	mov    %rax,%rbx
  676eb9:	4c 8b bc 24 30 01 00 	mov    0x130(%rsp),%r15
  676ec0:	00 
  676ec1:	4c 8d a4 24 30 02 00 	lea    0x230(%rsp),%r12
  676ec8:	00 
  676ec9:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
  676ece:	66 90                	xchg   %ax,%ax
  676ed0:	4c 39 f3             	cmp    %r14,%rbx
  676ed3:	0f 84 36 ff ff ff    	je     676e0f <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x7ef>
  676ed9:	8b 03                	mov    (%rbx),%eax
  676edb:	48 83 c3 08          	add    $0x8,%rbx
  676edf:	48 39 c8             	cmp    %rcx,%rax
  676ee2:	74 ec                	je     676ed0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x8b0>
  676ee4:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
  676ee9:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
  676eed:	48 01 c1             	add    %rax,%rcx
  676ef0:	48 3b 4a 18          	cmp    0x18(%rdx),%rcx
  676ef4:	0f 83 2e 11 00 00    	jae    678028 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a08>
  676efa:	48 3b 4c 24 20       	cmp    0x20(%rsp),%rcx
  676eff:	0f 83 23 11 00 00    	jae    678028 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a08>
  676f05:	48 8d 14 89          	lea    (%rcx,%rcx,4),%rdx
  676f09:	48 8b 74 24 68       	mov    0x68(%rsp),%rsi
  676f0e:	48 8b 4c d6 10       	mov    0x10(%rsi,%rdx,8),%rcx
  676f13:	80 7c d6 21 01       	cmpb   $0x1,0x21(%rsi,%rdx,8)
  676f18:	0f 84 e8 10 00 00    	je     678006 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19e6>
  676f1e:	48 3b 8c 24 20 03 00 	cmp    0x320(%rsp),%rcx
  676f25:	00 
  676f26:	0f 83 fc 10 00 00    	jae    678028 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a08>
  676f2c:	f3 0f 10 43 fc       	movss  -0x4(%rbx),%xmm0
  676f31:	f3 0f 11 44 24 50    	movss  %xmm0,0x50(%rsp)
  676f37:	48 8b 74 24 68       	mov    0x68(%rsp),%rsi
  676f3c:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
  676f40:	48 8d 34 c9          	lea    (%rcx,%rcx,8),%rsi
  676f44:	48 c1 e6 04          	shl    $0x4,%rsi
  676f48:	4c 8b 94 24 28 01 00 	mov    0x128(%rsp),%r10
  676f4f:	00 
  676f50:	49 8d 3c 32          	lea    (%r10,%rsi,1),%rdi
  676f54:	4c 8d 04 89          	lea    (%rcx,%rcx,4),%r8
  676f58:	49 c1 e0 04          	shl    $0x4,%r8
  676f5c:	4c 03 84 24 e8 00 00 	add    0xe8(%rsp),%r8
  676f63:	00 
  676f64:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
  676f69:	4c 89 8c 24 d0 01 00 	mov    %r9,0x1d0(%rsp)
  676f70:	00 
  676f71:	48 89 bc 24 d8 01 00 	mov    %rdi,0x1d8(%rsp)
  676f78:	00 
  676f79:	4c 89 84 24 e0 01 00 	mov    %r8,0x1e0(%rsp)
  676f80:	00 
  676f81:	48 89 94 24 e8 01 00 	mov    %rdx,0x1e8(%rsp)
  676f88:	00 
  676f89:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
  676f8e:	89 94 24 f0 01 00 00 	mov    %edx,0x1f0(%rsp)
  676f95:	89 84 24 f4 01 00 00 	mov    %eax,0x1f4(%rsp)
  676f9c:	89 8c 24 f8 01 00 00 	mov    %ecx,0x1f8(%rsp)
  676fa3:	48 c7 84 24 48 01 00 	movq   $0x0,0x148(%rsp)
  676faa:	00 00 00 00 00 
  676faf:	41 0f b6 84 32 8c 00 	movzbl 0x8c(%r10,%rsi,1),%eax
  676fb6:	00 00 
  676fb8:	88 44 24 2f          	mov    %al,0x2f(%rsp)
  676fbc:	a8 01                	test   $0x1,%al
  676fbe:	4c 89 9c 24 18 03 00 	mov    %r11,0x318(%rsp)
  676fc5:	00 
  676fc6:	89 ac 24 8c 01 00 00 	mov    %ebp,0x18c(%rsp)
  676fcd:	4c 89 b4 24 10 03 00 	mov    %r14,0x310(%rsp)
  676fd4:	00 
  676fd5:	0f 85 3c 0a 00 00    	jne    677a17 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x13f7>
  676fdb:	48 8d bc 24 00 02 00 	lea    0x200(%rsp),%rdi
  676fe2:	00 
  676fe3:	48 8d b4 24 d0 01 00 	lea    0x1d0(%rsp),%rsi
  676fea:	00 
  676feb:	31 d2                	xor    %edx,%edx
  676fed:	e8 be a0 00 00       	call   6810b0 <<parley::layout::run::Clusters<()>>::new>
  676ff2:	ba 10 01 00 00       	mov    $0x110,%edx
  676ff7:	4c 8d b4 24 38 03 00 	lea    0x338(%rsp),%r14
  676ffe:	00 
  676fff:	4c 89 f7             	mov    %r14,%rdi
  677002:	4c 8d a4 24 00 02 00 	lea    0x200(%rsp),%r12
  677009:	00 
  67700a:	4c 89 e6             	mov    %r12,%rsi
  67700d:	ff 15 6d 2d 11 00    	call   *0x112d6d(%rip)        # 789d80 <memcpy@GLIBC_2.14>
  677013:	4c 89 e7             	mov    %r12,%rdi
  677016:	4c 89 f6             	mov    %r14,%rsi
  677019:	48 c7 84 24 30 03 00 	movq   $0x0,0x330(%rsp)
  677020:	00 00 00 00 00 
  677025:	0f 57 c0             	xorps  %xmm0,%xmm0
  677028:	f3 0f 11 44 24 7c    	movss  %xmm0,0x7c(%rsp)
  67702e:	45 31 e4             	xor    %r12d,%r12d
  677031:	c7 44 24 4c 00 00 00 	movl   $0x0,0x4c(%rsp)
  677038:	00 
  677039:	e8 d2 c8 00 00       	call   683910 <<parley::layout::run::Clusters<()> as core::iter::traits::iterator::Iterator>::next>
  67703e:	4c 8b ac 24 00 02 00 	mov    0x200(%rsp),%r13
  677045:	00 
  677046:	4d 85 ed             	test   %r13,%r13
  677049:	0f 84 ae 0b 00 00    	je     677bfd <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x15dd>
  67704f:	ba 88 00 00 00       	mov    $0x88,%edx
  677054:	48 8d bc 24 00 05 00 	lea    0x500(%rsp),%rdi
  67705b:	00 
  67705c:	48 8d b4 24 08 02 00 	lea    0x208(%rsp),%rsi
  677063:	00 
  677064:	ff 15 16 2d 11 00    	call   *0x112d16(%rip)        # 789d80 <memcpy@GLIBC_2.14>
  67706a:	4c 8b b4 24 30 03 00 	mov    0x330(%rsp),%r14
  677071:	00 
  677072:	49 8d 46 01          	lea    0x1(%r14),%rax
  677076:	48 89 84 24 30 03 00 	mov    %rax,0x330(%rsp)
  67707d:	00 
  67707e:	4c 89 ac 24 f8 04 00 	mov    %r13,0x4f8(%rsp)
  677085:	00 
  677086:	8b ac 24 20 05 00 00 	mov    0x520(%rsp),%ebp
  67708d:	49 8b 45 58          	mov    0x58(%r13),%rax
  677091:	48 39 e8             	cmp    %rbp,%rax
  677094:	0f 86 40 0f 00 00    	jbe    677fda <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19ba>
  67709a:	49 8b 45 50          	mov    0x50(%r13),%rax
  67709e:	48 8d 0c ed 00 00 00 	lea    0x0(,%rbp,8),%rcx
  6770a5:	00 
  6770a6:	48 01 e9             	add    %rbp,%rcx
  6770a9:	48 c1 e1 04          	shl    $0x4,%rcx
  6770ad:	41 0f 10 45 68       	movups 0x68(%r13),%xmm0
  6770b2:	41 0f 10 8d 80 00 00 	movups 0x80(%r13),%xmm1
  6770b9:	00 
  6770ba:	4c 89 6c 24 60       	mov    %r13,0x60(%rsp)
  6770bf:	41 0f 10 95 98 00 00 	movups 0x98(%r13),%xmm2
  6770c6:	00 
  6770c7:	0f 11 84 24 00 02 00 	movups %xmm0,0x200(%rsp)
  6770ce:	00 
  6770cf:	0f 11 8c 24 10 02 00 	movups %xmm1,0x210(%rsp)
  6770d6:	00 
  6770d7:	0f 11 94 24 20 02 00 	movups %xmm2,0x220(%rsp)
  6770de:	00 
  6770df:	48 8b 44 08 50       	mov    0x50(%rax,%rcx,1),%rax
  6770e4:	48 89 84 24 30 02 00 	mov    %rax,0x230(%rsp)
  6770eb:	00 
  6770ec:	8b b4 24 78 05 00 00 	mov    0x578(%rsp),%esi
  6770f3:	8b 94 24 7c 05 00 00 	mov    0x57c(%rsp),%edx
  6770fa:	48 8d bc 24 00 02 00 	lea    0x200(%rsp),%rdi
  677101:	00 
  677102:	48 89 b4 24 58 01 00 	mov    %rsi,0x158(%rsp)
  677109:	00 
  67710a:	48 89 94 24 50 01 00 	mov    %rdx,0x150(%rsp)
  677111:	00 
  677112:	ff 15 58 2f 11 00    	call   *0x112f58(%rip)        # 78a070 <_DYNAMIC+0x5c0>
  677118:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  67711d:	48 89 54 24 40       	mov    %rdx,0x40(%rsp)
  677122:	f6 44 24 2f 01       	testb  $0x1,0x2f(%rsp)
  677127:	75 42                	jne    67716b <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xb4b>
  677129:	48 83 bc 24 10 05 00 	cmpq   $0x0,0x510(%rsp)
  677130:	00 00 
  677132:	0f 84 a9 00 00 00    	je     6771e1 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xbc1>
  677138:	8b 84 24 18 05 00 00 	mov    0x518(%rsp),%eax
  67713f:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  677144:	48 8b 8a 18 01 00 00 	mov    0x118(%rdx),%rcx
  67714b:	48 39 c1             	cmp    %rax,%rcx
  67714e:	0f 86 e4 0e 00 00    	jbe    678038 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a18>
  677154:	48 8b 8a 10 01 00 00 	mov    0x110(%rdx),%rcx
  67715b:	48 6b c0 70          	imul   $0x70,%rax,%rax
  67715f:	f3 0f 10 44 01 50    	movss  0x50(%rcx,%rax,1),%xmm0
  677165:	8b 44 01 54          	mov    0x54(%rcx,%rax,1),%eax
  677169:	eb 7e                	jmp    6771e9 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xbc9>
  67716b:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  677172:	00 
  677173:	49 f7 d6             	not    %r14
  677176:	49 01 c6             	add    %rax,%r14
  677179:	0f 83 76 0e 00 00    	jae    677ff5 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19d5>
  67717f:	48 8b 84 24 40 01 00 	mov    0x140(%rsp),%rax
  677186:	00 
  677187:	f3 0f 10 44 24 7c    	movss  0x7c(%rsp),%xmm0
  67718d:	f3 0f 11 84 24 90 01 	movss  %xmm0,0x190(%rsp)
  677194:	00 00 
  677196:	f3 42 0f 10 04 b0    	movss  (%rax,%r14,4),%xmm0
  67719c:	f3 0f 11 44 24 7c    	movss  %xmm0,0x7c(%rsp)
  6771a2:	48 8b 84 24 50 04 00 	mov    0x450(%rsp),%rax
  6771a9:	00 
  6771aa:	48 83 f8 02          	cmp    $0x2,%rax
  6771ae:	4c 8b b4 24 a0 01 00 	mov    0x1a0(%rsp),%r14
  6771b5:	00 
  6771b6:	0f 85 bc 00 00 00    	jne    677278 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xc58>
  6771bc:	48 8d bc 24 60 04 00 	lea    0x460(%rsp),%rdi
  6771c3:	00 
  6771c4:	e8 a7 a9 ff ff       	call   671b70 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  6771c9:	49 89 d5             	mov    %rdx,%r13
  6771cc:	48 89 84 24 50 04 00 	mov    %rax,0x450(%rsp)
  6771d3:	00 
  6771d4:	48 89 94 24 58 04 00 	mov    %rdx,0x458(%rsp)
  6771db:	00 
  6771dc:	e9 9f 00 00 00       	jmp    677280 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xc60>
  6771e1:	0f 57 c0             	xorps  %xmm0,%xmm0
  6771e4:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  6771e9:	48 8b 8c 24 00 05 00 	mov    0x500(%rsp),%rcx
  6771f0:	00 
  6771f1:	48 8b 94 24 08 05 00 	mov    0x508(%rsp),%rdx
  6771f8:	00 
  6771f9:	f2 0f 10 4a 44       	movsd  0x44(%rdx),%xmm1
  6771fe:	f2 0f 11 8c 24 00 02 	movsd  %xmm1,0x200(%rsp)
  677205:	00 00 
  677207:	f3 0f 11 84 24 08 02 	movss  %xmm0,0x208(%rsp)
  67720e:	00 00 
  677210:	89 84 24 0c 02 00 00 	mov    %eax,0x20c(%rsp)
  677217:	0f b6 89 8c 00 00 00 	movzbl 0x8c(%rcx),%ecx
  67721e:	83 e1 01             	and    $0x1,%ecx
  677221:	48 8d bc 24 00 02 00 	lea    0x200(%rsp),%rdi
  677228:	00 
  677229:	48 8d b4 24 28 05 00 	lea    0x528(%rsp),%rsi
  677230:	00 
  677231:	48 8d 94 24 78 05 00 	lea    0x578(%rsp),%rdx
  677238:	00 
  677239:	ff 15 a1 30 11 00    	call   *0x1130a1(%rip)        # 78a2e0 <_DYNAMIC+0x830>
  67723f:	f3 0f 10 4c 24 50    	movss  0x50(%rsp),%xmm1
  677245:	f3 0f 58 c1          	addss  %xmm1,%xmm0
  677249:	f3 0f 11 8c 24 90 01 	movss  %xmm1,0x190(%rsp)
  677250:	00 00 
  677252:	f3 0f 11 4c 24 7c    	movss  %xmm1,0x7c(%rsp)
  677258:	f3 0f 11 44 24 50    	movss  %xmm0,0x50(%rsp)
  67725e:	48 8b 84 24 50 04 00 	mov    0x450(%rsp),%rax
  677265:	00 
  677266:	48 83 f8 02          	cmp    $0x2,%rax
  67726a:	4c 8b b4 24 a0 01 00 	mov    0x1a0(%rsp),%r14
  677271:	00 
  677272:	0f 84 44 ff ff ff    	je     6771bc <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xb9c>
  677278:	4c 8b ac 24 58 04 00 	mov    0x458(%rsp),%r13
  67727f:	00 
  677280:	48 83 f8 01          	cmp    $0x1,%rax
  677284:	0f 85 68 06 00 00    	jne    6778f2 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x12d2>
  67728a:	4c 3b 6c 24 40       	cmp    0x40(%rsp),%r13
  67728f:	4c 8b 44 24 30       	mov    0x30(%rsp),%r8
  677294:	0f 83 5d 06 00 00    	jae    6778f7 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x12d7>
  67729a:	4c 3b ac 24 c0 01 00 	cmp    0x1c0(%rsp),%r13
  6772a1:	00 
  6772a2:	0f 92 c0             	setb   %al
  6772a5:	41 84 c6             	test   %al,%r14b
  6772a8:	0f 85 28 0b 00 00    	jne    677dd6 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x17b6>
  6772ae:	f3 0f 10 8c 24 90 01 	movss  0x190(%rsp),%xmm1
  6772b5:	00 00 
  6772b7:	0f 57 c0             	xorps  %xmm0,%xmm0
  6772ba:	f3 0f 5a c1          	cvtss2sd %xmm1,%xmm0
  6772be:	0f 29 84 24 a0 01 00 	movaps %xmm0,0x1a0(%rsp)
  6772c5:	00 
  6772c6:	f3 0f 58 4c 24 14    	addss  0x14(%rsp),%xmm1
  6772cc:	0f 57 c0             	xorps  %xmm0,%xmm0
  6772cf:	f3 0f 5a c1          	cvtss2sd %xmm1,%xmm0
  6772d3:	0f 29 84 24 90 01 00 	movaps %xmm0,0x190(%rsp)
  6772da:	00 
  6772db:	48 c7 84 24 50 04 00 	movq   $0x2,0x450(%rsp)
  6772e2:	00 02 00 00 00 
  6772e7:	4d 39 c5             	cmp    %r8,%r13
  6772ea:	0f 85 fc 00 00 00    	jne    6773ec <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xdcc>
  6772f0:	4d 39 c4             	cmp    %r8,%r12
  6772f3:	0f 94 c0             	sete   %al
  6772f6:	22 44 24 4c          	and    0x4c(%rsp),%al
  6772fa:	3c 01                	cmp    $0x1,%al
  6772fc:	75 57                	jne    677355 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xd35>
  6772fe:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  677303:	48 8b 41 58          	mov    0x58(%rcx),%rax
  677307:	48 39 e8             	cmp    %rbp,%rax
  67730a:	0f 86 ca 0c 00 00    	jbe    677fda <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19ba>
  677310:	48 8b 51 70          	mov    0x70(%rcx),%rdx
  677314:	48 8b bc 24 58 01 00 	mov    0x158(%rsp),%rdi
  67731b:	00 
  67731c:	48 8b b4 24 50 01 00 	mov    0x150(%rsp),%rsi
  677323:	00 
  677324:	39 fe                	cmp    %edi,%esi
  677326:	0f 82 eb 0b 00 00    	jb     677f17 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18f7>
  67732c:	48 39 f2             	cmp    %rsi,%rdx
  67732f:	0f 82 e2 0b 00 00    	jb     677f17 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18f7>
  677335:	39 fe                	cmp    %edi,%esi
  677337:	0f 84 ab 0c 00 00    	je     677fe8 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19c8>
  67733d:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  677342:	48 8b 40 68          	mov    0x68(%rax),%rax
  677346:	48 8d 0c 7f          	lea    (%rdi,%rdi,2),%rcx
  67734a:	80 7c 88 07 06       	cmpb   $0x6,0x7(%rax,%rcx,4)
  67734f:	0f 85 2d 06 00 00    	jne    677982 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1362>
  677355:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  67735a:	4c 89 c6             	mov    %r8,%rsi
  67735d:	ba 01 00 00 00       	mov    $0x1,%edx
  677362:	e8 89 78 00 00       	call   67ebf0 <<parley::editing::cursor::Cursor>::from_byte_index::<()>>
  677367:	48 89 84 24 f0 00 00 	mov    %rax,0xf0(%rsp)
  67736e:	00 
  67736f:	80 e2 01             	and    $0x1,%dl
  677372:	88 94 24 f8 00 00 00 	mov    %dl,0xf8(%rsp)
  677379:	48 3b 44 24 30       	cmp    0x30(%rsp),%rax
  67737e:	0f 85 62 01 00 00    	jne    6774e6 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xec6>
  677384:	48 8d bc 24 00 02 00 	lea    0x200(%rsp),%rdi
  67738b:	00 
  67738c:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
  677393:	00 
  677394:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  677399:	f3 0f 10 44 24 14    	movss  0x14(%rsp),%xmm0
  67739f:	e8 0c 79 00 00       	call   67ecb0 <<parley::editing::cursor::Cursor>::geometry::<()>>
  6773a4:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  6773a9:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
  6773ae:	31 d2                	xor    %edx,%edx
  6773b0:	e8 3b 78 00 00       	call   67ebf0 <<parley::editing::cursor::Cursor>::from_byte_index::<()>>
  6773b5:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  6773bc:	00 
  6773bd:	80 e2 01             	and    $0x1,%dl
  6773c0:	88 94 24 08 01 00 00 	mov    %dl,0x108(%rsp)
  6773c7:	48 8d bc 24 68 01 00 	lea    0x168(%rsp),%rdi
  6773ce:	00 
  6773cf:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
  6773d6:	00 
  6773d7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  6773dc:	f3 0f 10 44 24 14    	movss  0x14(%rsp),%xmm0
  6773e2:	e8 c9 78 00 00       	call   67ecb0 <<parley::editing::cursor::Cursor>::geometry::<()>>
  6773e7:	e9 94 00 00 00       	jmp    677480 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xe60>
  6773ec:	0f 87 f4 00 00 00    	ja     6774e6 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xec6>
  6773f2:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  6773f7:	4c 89 ee             	mov    %r13,%rsi
  6773fa:	ba 01 00 00 00       	mov    $0x1,%edx
  6773ff:	e8 ec 77 00 00       	call   67ebf0 <<parley::editing::cursor::Cursor>::from_byte_index::<()>>
  677404:	48 89 84 24 f0 00 00 	mov    %rax,0xf0(%rsp)
  67740b:	00 
  67740c:	80 e2 01             	and    $0x1,%dl
  67740f:	88 94 24 f8 00 00 00 	mov    %dl,0xf8(%rsp)
  677416:	4c 39 e8             	cmp    %r13,%rax
  677419:	0f 85 c7 00 00 00    	jne    6774e6 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xec6>
  67741f:	48 8d bc 24 00 02 00 	lea    0x200(%rsp),%rdi
  677426:	00 
  677427:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
  67742e:	00 
  67742f:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  677434:	f3 0f 10 44 24 14    	movss  0x14(%rsp),%xmm0
  67743a:	e8 71 78 00 00       	call   67ecb0 <<parley::editing::cursor::Cursor>::geometry::<()>>
  67743f:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  677444:	4c 89 ee             	mov    %r13,%rsi
  677447:	31 d2                	xor    %edx,%edx
  677449:	e8 a2 77 00 00       	call   67ebf0 <<parley::editing::cursor::Cursor>::from_byte_index::<()>>
  67744e:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  677455:	00 
  677456:	80 e2 01             	and    $0x1,%dl
  677459:	88 94 24 08 01 00 00 	mov    %dl,0x108(%rsp)
  677460:	48 8d bc 24 68 01 00 	lea    0x168(%rsp),%rdi
  677467:	00 
  677468:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
  67746f:	00 
  677470:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  677475:	f3 0f 10 44 24 14    	movss  0x14(%rsp),%xmm0
  67747b:	e8 30 78 00 00       	call   67ecb0 <<parley::editing::cursor::Cursor>::geometry::<()>>
  677480:	0f 10 84 24 68 01 00 	movups 0x168(%rsp),%xmm0
  677487:	00 
  677488:	0f 10 8c 24 78 01 00 	movups 0x178(%rsp),%xmm1
  67748f:	00 
  677490:	48 8d 84 24 30 02 00 	lea    0x230(%rsp),%rax
  677497:	00 
  677498:	0f 11 08             	movups %xmm1,(%rax)
  67749b:	0f 11 40 f0          	movups %xmm0,-0x10(%rax)
  67749f:	0f 28 84 24 00 02 00 	movaps 0x200(%rsp),%xmm0
  6774a6:	00 
  6774a7:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
  6774ae:	00 
  6774af:	0f 28 84 24 10 02 00 	movaps 0x210(%rsp),%xmm0
  6774b6:	00 
  6774b7:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
  6774be:	00 
  6774bf:	0f 28 84 24 20 02 00 	movaps 0x220(%rsp),%xmm0
  6774c6:	00 
  6774c7:	0f 29 84 24 10 01 00 	movaps %xmm0,0x110(%rsp)
  6774ce:	00 
  6774cf:	0f 28 84 24 30 02 00 	movaps 0x230(%rsp),%xmm0
  6774d6:	00 
  6774d7:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
  6774de:	00 
  6774df:	b8 01 00 00 00       	mov    $0x1,%eax
  6774e4:	eb 02                	jmp    6774e8 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xec8>
  6774e6:	31 c0                	xor    %eax,%eax
  6774e8:	4c 89 ac 24 00 02 00 	mov    %r13,0x200(%rsp)
  6774ef:	00 
  6774f0:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
  6774f7:	00 
  6774f8:	0f 28 84 24 80 00 00 	movaps 0x80(%rsp),%xmm0
  6774ff:	00 
  677500:	0f 11 84 24 10 02 00 	movups %xmm0,0x210(%rsp)
  677507:	00 
  677508:	0f 28 84 24 a0 00 00 	movaps 0xa0(%rsp),%xmm0
  67750f:	00 
  677510:	0f 11 84 24 20 02 00 	movups %xmm0,0x220(%rsp)
  677517:	00 
  677518:	0f 28 84 24 10 01 00 	movaps 0x110(%rsp),%xmm0
  67751f:	00 
  677520:	0f 11 84 24 30 02 00 	movups %xmm0,0x230(%rsp)
  677527:	00 
  677528:	0f 28 84 24 d0 00 00 	movaps 0xd0(%rsp),%xmm0
  67752f:	00 
  677530:	0f 11 84 24 40 02 00 	movups %xmm0,0x240(%rsp)
  677537:	00 
  677538:	4c 89 ff             	mov    %r15,%rdi
  67753b:	4c 89 ee             	mov    %r13,%rsi
  67753e:	48 8d 94 24 08 02 00 	lea    0x208(%rsp),%rdx
  677545:	00 
  677546:	e8 15 2b 00 00       	call   67a060 <gpui_canvas::text::planner::append_carets::{closure#1}>
  67754b:	41 89 c6             	mov    %eax,%r14d
  67754e:	83 f8 ff             	cmp    $0xffffffff,%eax
  677551:	0f 85 bd 08 00 00    	jne    677e14 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x17f4>
  677557:	4c 3b 64 24 30       	cmp    0x30(%rsp),%r12
  67755c:	0f 94 c0             	sete   %al
  67755f:	8b 4c 24 4c          	mov    0x4c(%rsp),%ecx
  677563:	20 c1                	and    %al,%cl
  677565:	89 4c 24 4c          	mov    %ecx,0x4c(%rsp)
  677569:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  677570:	48 8b 84 24 50 04 00 	mov    0x450(%rsp),%rax
  677577:	00 
  677578:	48 83 f8 02          	cmp    $0x2,%rax
  67757c:	75 22                	jne    6775a0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xf80>
  67757e:	48 8d bc 24 60 04 00 	lea    0x460(%rsp),%rdi
  677585:	00 
  677586:	e8 e5 a5 ff ff       	call   671b70 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  67758b:	49 89 d4             	mov    %rdx,%r12
  67758e:	48 89 84 24 50 04 00 	mov    %rax,0x450(%rsp)
  677595:	00 
  677596:	48 89 94 24 58 04 00 	mov    %rdx,0x458(%rsp)
  67759d:	00 
  67759e:	eb 08                	jmp    6775a8 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xf88>
  6775a0:	4c 8b a4 24 58 04 00 	mov    0x458(%rsp),%r12
  6775a7:	00 
  6775a8:	41 b6 01             	mov    $0x1,%r14b
  6775ab:	48 83 f8 01          	cmp    $0x1,%rax
  6775af:	0f 85 35 03 00 00    	jne    6778ea <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x12ca>
  6775b5:	4c 3b 64 24 40       	cmp    0x40(%rsp),%r12
  6775ba:	4c 8b 44 24 30       	mov    0x30(%rsp),%r8
  6775bf:	0f 83 1b 03 00 00    	jae    6778e0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x12c0>
  6775c5:	4d 39 ec             	cmp    %r13,%r12
  6775c8:	0f 82 08 08 00 00    	jb     677dd6 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x17b6>
  6775ce:	48 c7 84 24 50 04 00 	movq   $0x2,0x450(%rsp)
  6775d5:	00 02 00 00 00 
  6775da:	4d 39 c4             	cmp    %r8,%r12
  6775dd:	0f 85 f5 00 00 00    	jne    6776d8 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x10b8>
  6775e3:	80 7c 24 4c 00       	cmpb   $0x0,0x4c(%rsp)
  6775e8:	74 57                	je     677641 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1021>
  6775ea:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  6775ef:	48 8b 41 58          	mov    0x58(%rcx),%rax
  6775f3:	48 39 e8             	cmp    %rbp,%rax
  6775f6:	0f 86 de 09 00 00    	jbe    677fda <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19ba>
  6775fc:	48 8b 51 70          	mov    0x70(%rcx),%rdx
  677600:	48 8b bc 24 58 01 00 	mov    0x158(%rsp),%rdi
  677607:	00 
  677608:	48 8b b4 24 50 01 00 	mov    0x150(%rsp),%rsi
  67760f:	00 
  677610:	39 fe                	cmp    %edi,%esi
  677612:	0f 82 ff 08 00 00    	jb     677f17 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18f7>
  677618:	48 39 f2             	cmp    %rsi,%rdx
  67761b:	0f 82 f6 08 00 00    	jb     677f17 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18f7>
  677621:	39 fe                	cmp    %edi,%esi
  677623:	0f 84 bf 09 00 00    	je     677fe8 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19c8>
  677629:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  67762e:	48 8b 40 68          	mov    0x68(%rax),%rax
  677632:	48 8d 0c 7f          	lea    (%rdi,%rdi,2),%rcx
  677636:	80 7c 88 07 06       	cmpb   $0x6,0x7(%rax,%rcx,4)
  67763b:	0f 85 0a 02 00 00    	jne    67784b <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x122b>
  677641:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  677646:	4c 89 c6             	mov    %r8,%rsi
  677649:	ba 01 00 00 00       	mov    $0x1,%edx
  67764e:	e8 9d 75 00 00       	call   67ebf0 <<parley::editing::cursor::Cursor>::from_byte_index::<()>>
  677653:	48 89 84 24 f0 00 00 	mov    %rax,0xf0(%rsp)
  67765a:	00 
  67765b:	80 e2 01             	and    $0x1,%dl
  67765e:	88 94 24 f8 00 00 00 	mov    %dl,0xf8(%rsp)
  677665:	48 3b 44 24 30       	cmp    0x30(%rsp),%rax
  67766a:	0f 85 62 01 00 00    	jne    6777d2 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x11b2>
  677670:	48 8d bc 24 00 02 00 	lea    0x200(%rsp),%rdi
  677677:	00 
  677678:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
  67767f:	00 
  677680:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  677685:	f3 0f 10 44 24 14    	movss  0x14(%rsp),%xmm0
  67768b:	e8 20 76 00 00       	call   67ecb0 <<parley::editing::cursor::Cursor>::geometry::<()>>
  677690:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  677695:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
  67769a:	31 d2                	xor    %edx,%edx
  67769c:	e8 4f 75 00 00       	call   67ebf0 <<parley::editing::cursor::Cursor>::from_byte_index::<()>>
  6776a1:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  6776a8:	00 
  6776a9:	80 e2 01             	and    $0x1,%dl
  6776ac:	88 94 24 08 01 00 00 	mov    %dl,0x108(%rsp)
  6776b3:	48 8d bc 24 68 01 00 	lea    0x168(%rsp),%rdi
  6776ba:	00 
  6776bb:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
  6776c2:	00 
  6776c3:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  6776c8:	f3 0f 10 44 24 14    	movss  0x14(%rsp),%xmm0
  6776ce:	e8 dd 75 00 00       	call   67ecb0 <<parley::editing::cursor::Cursor>::geometry::<()>>
  6776d3:	e9 94 00 00 00       	jmp    67776c <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x114c>
  6776d8:	0f 87 f4 00 00 00    	ja     6777d2 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x11b2>
  6776de:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  6776e3:	4c 89 e6             	mov    %r12,%rsi
  6776e6:	ba 01 00 00 00       	mov    $0x1,%edx
  6776eb:	e8 00 75 00 00       	call   67ebf0 <<parley::editing::cursor::Cursor>::from_byte_index::<()>>
  6776f0:	48 89 84 24 f0 00 00 	mov    %rax,0xf0(%rsp)
  6776f7:	00 
  6776f8:	80 e2 01             	and    $0x1,%dl
  6776fb:	88 94 24 f8 00 00 00 	mov    %dl,0xf8(%rsp)
  677702:	4c 39 e0             	cmp    %r12,%rax
  677705:	0f 85 c7 00 00 00    	jne    6777d2 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x11b2>
  67770b:	48 8d bc 24 00 02 00 	lea    0x200(%rsp),%rdi
  677712:	00 
  677713:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
  67771a:	00 
  67771b:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  677720:	f3 0f 10 44 24 14    	movss  0x14(%rsp),%xmm0
  677726:	e8 85 75 00 00       	call   67ecb0 <<parley::editing::cursor::Cursor>::geometry::<()>>
  67772b:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  677730:	4c 89 e6             	mov    %r12,%rsi
  677733:	31 d2                	xor    %edx,%edx
  677735:	e8 b6 74 00 00       	call   67ebf0 <<parley::editing::cursor::Cursor>::from_byte_index::<()>>
  67773a:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  677741:	00 
  677742:	80 e2 01             	and    $0x1,%dl
  677745:	88 94 24 08 01 00 00 	mov    %dl,0x108(%rsp)
  67774c:	48 8d bc 24 68 01 00 	lea    0x168(%rsp),%rdi
  677753:	00 
  677754:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
  67775b:	00 
  67775c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  677761:	f3 0f 10 44 24 14    	movss  0x14(%rsp),%xmm0
  677767:	e8 44 75 00 00       	call   67ecb0 <<parley::editing::cursor::Cursor>::geometry::<()>>
  67776c:	0f 10 84 24 68 01 00 	movups 0x168(%rsp),%xmm0
  677773:	00 
  677774:	0f 10 8c 24 78 01 00 	movups 0x178(%rsp),%xmm1
  67777b:	00 
  67777c:	48 8d 84 24 30 02 00 	lea    0x230(%rsp),%rax
  677783:	00 
  677784:	0f 11 08             	movups %xmm1,(%rax)
  677787:	0f 11 40 f0          	movups %xmm0,-0x10(%rax)
  67778b:	0f 28 84 24 00 02 00 	movaps 0x200(%rsp),%xmm0
  677792:	00 
  677793:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
  67779a:	00 
  67779b:	0f 28 84 24 10 02 00 	movaps 0x210(%rsp),%xmm0
  6777a2:	00 
  6777a3:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
  6777aa:	00 
  6777ab:	0f 28 84 24 20 02 00 	movaps 0x220(%rsp),%xmm0
  6777b2:	00 
  6777b3:	0f 29 84 24 10 01 00 	movaps %xmm0,0x110(%rsp)
  6777ba:	00 
  6777bb:	0f 28 84 24 30 02 00 	movaps 0x230(%rsp),%xmm0
  6777c2:	00 
  6777c3:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
  6777ca:	00 
  6777cb:	b8 01 00 00 00       	mov    $0x1,%eax
  6777d0:	eb 02                	jmp    6777d4 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x11b4>
  6777d2:	31 c0                	xor    %eax,%eax
  6777d4:	4c 89 a4 24 00 02 00 	mov    %r12,0x200(%rsp)
  6777db:	00 
  6777dc:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
  6777e3:	00 
  6777e4:	0f 28 84 24 80 00 00 	movaps 0x80(%rsp),%xmm0
  6777eb:	00 
  6777ec:	0f 11 84 24 10 02 00 	movups %xmm0,0x210(%rsp)
  6777f3:	00 
  6777f4:	0f 28 84 24 a0 00 00 	movaps 0xa0(%rsp),%xmm0
  6777fb:	00 
  6777fc:	0f 11 84 24 20 02 00 	movups %xmm0,0x220(%rsp)
  677803:	00 
  677804:	0f 28 84 24 10 01 00 	movaps 0x110(%rsp),%xmm0
  67780b:	00 
  67780c:	0f 11 84 24 30 02 00 	movups %xmm0,0x230(%rsp)
  677813:	00 
  677814:	0f 28 84 24 d0 00 00 	movaps 0xd0(%rsp),%xmm0
  67781b:	00 
  67781c:	0f 11 84 24 40 02 00 	movups %xmm0,0x240(%rsp)
  677823:	00 
  677824:	4c 89 ff             	mov    %r15,%rdi
  677827:	4c 89 e6             	mov    %r12,%rsi
  67782a:	48 8d 94 24 08 02 00 	lea    0x208(%rsp),%rdx
  677831:	00 
  677832:	e8 29 28 00 00       	call   67a060 <gpui_canvas::text::planner::append_carets::{closure#1}>
  677837:	41 89 c6             	mov    %eax,%r14d
  67783a:	4d 89 e5             	mov    %r12,%r13
  67783d:	83 f8 ff             	cmp    $0xffffffff,%eax
  677840:	0f 84 2a fd ff ff    	je     677570 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xf50>
  677846:	e9 c9 05 00 00       	jmp    677e14 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x17f4>
  67784b:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  677850:	f3 0f 10 40 40       	movss  0x40(%rax),%xmm0
  677855:	0f 28 c8             	movaps %xmm0,%xmm1
  677858:	f3 0f 5d 48 48       	minss  0x48(%rax),%xmm1
  67785d:	0f 28 d1             	movaps %xmm1,%xmm2
  677860:	f3 0f c2 d1 03       	cmpunordss %xmm1,%xmm2
  677865:	0f 28 da             	movaps %xmm2,%xmm3
  677868:	0f 55 d9             	andnps %xmm1,%xmm3
  67786b:	0f 54 d0             	andps  %xmm0,%xmm2
  67786e:	0f 56 d3             	orps   %xmm3,%xmm2
  677871:	0f 57 c0             	xorps  %xmm0,%xmm0
  677874:	f3 0f 5a c2          	cvtss2sd %xmm2,%xmm0
  677878:	f3 0f 10 48 44       	movss  0x44(%rax),%xmm1
  67787d:	0f 28 d1             	movaps %xmm1,%xmm2
  677880:	f3 0f 5f 50 4c       	maxss  0x4c(%rax),%xmm2
  677885:	0f 28 da             	movaps %xmm2,%xmm3
  677888:	f3 0f c2 da 03       	cmpunordss %xmm2,%xmm3
  67788d:	0f 28 e3             	movaps %xmm3,%xmm4
  677890:	0f 55 e2             	andnps %xmm2,%xmm4
  677893:	0f 54 d9             	andps  %xmm1,%xmm3
  677896:	0f 56 dc             	orps   %xmm4,%xmm3
  677899:	0f 57 c9             	xorps  %xmm1,%xmm1
  67789c:	f3 0f 5a cb          	cvtss2sd %xmm3,%xmm1
  6778a0:	0f 28 94 24 a0 01 00 	movaps 0x1a0(%rsp),%xmm2
  6778a7:	00 
  6778a8:	0f 16 d0             	movlhps %xmm0,%xmm2
  6778ab:	0f 28 84 24 90 01 00 	movaps 0x190(%rsp),%xmm0
  6778b2:	00 
  6778b3:	0f 16 c1             	movlhps %xmm1,%xmm0
  6778b6:	b8 01 00 00 00       	mov    $0x1,%eax
  6778bb:	0f 29 94 24 80 00 00 	movaps %xmm2,0x80(%rsp)
  6778c2:	00 
  6778c3:	0f 29 94 24 10 01 00 	movaps %xmm2,0x110(%rsp)
  6778ca:	00 
  6778cb:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
  6778d2:	00 
  6778d3:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
  6778da:	00 
  6778db:	e9 f4 fe ff ff       	jmp    6777d4 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x11b4>
  6778e0:	4c 89 ac 24 c0 01 00 	mov    %r13,0x1c0(%rsp)
  6778e7:	00 
  6778e8:	eb 0d                	jmp    6778f7 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x12d7>
  6778ea:	4c 89 ac 24 c0 01 00 	mov    %r13,0x1c0(%rsp)
  6778f1:	00 
  6778f2:	4c 8b 44 24 30       	mov    0x30(%rsp),%r8
  6778f7:	4c 3b 44 24 40       	cmp    0x40(%rsp),%r8
  6778fc:	4c 89 b4 24 a0 01 00 	mov    %r14,0x1a0(%rsp)
  677903:	00 
  677904:	73 5a                	jae    677960 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1340>
  677906:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  67790b:	48 8b 41 58          	mov    0x58(%rcx),%rax
  67790f:	48 39 e8             	cmp    %rbp,%rax
  677912:	0f 86 c2 06 00 00    	jbe    677fda <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19ba>
  677918:	48 8b 51 70          	mov    0x70(%rcx),%rdx
  67791c:	48 8b bc 24 58 01 00 	mov    0x158(%rsp),%rdi
  677923:	00 
  677924:	48 8b b4 24 50 01 00 	mov    0x150(%rsp),%rsi
  67792b:	00 
  67792c:	39 fe                	cmp    %edi,%esi
  67792e:	0f 82 e3 05 00 00    	jb     677f17 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18f7>
  677934:	48 39 f2             	cmp    %rsi,%rdx
  677937:	0f 82 da 05 00 00    	jb     677f17 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18f7>
  67793d:	39 fe                	cmp    %edi,%esi
  67793f:	0f 84 a3 06 00 00    	je     677fe8 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19c8>
  677945:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  67794a:	48 8b 40 68          	mov    0x68(%rax),%rax
  67794e:	48 8d 0c 7f          	lea    (%rdi,%rdi,2),%rcx
  677952:	80 7c 88 07 06       	cmpb   $0x6,0x7(%rax,%rcx,4)
  677957:	0f 95 c0             	setne  %al
  67795a:	89 44 24 4c          	mov    %eax,0x4c(%rsp)
  67795e:	eb 08                	jmp    677968 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1348>
  677960:	c7 44 24 4c 00 00 00 	movl   $0x0,0x4c(%rsp)
  677967:	00 
  677968:	4c 8b 64 24 40       	mov    0x40(%rsp),%r12
  67796d:	48 8d b4 24 38 03 00 	lea    0x338(%rsp),%rsi
  677974:	00 
  677975:	48 8d bc 24 00 02 00 	lea    0x200(%rsp),%rdi
  67797c:	00 
  67797d:	e9 b7 f6 ff ff       	jmp    677039 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xa19>
  677982:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  677987:	f3 0f 10 40 40       	movss  0x40(%rax),%xmm0
  67798c:	0f 28 c8             	movaps %xmm0,%xmm1
  67798f:	f3 0f 5d 48 48       	minss  0x48(%rax),%xmm1
  677994:	0f 28 d1             	movaps %xmm1,%xmm2
  677997:	f3 0f c2 d1 03       	cmpunordss %xmm1,%xmm2
  67799c:	0f 28 da             	movaps %xmm2,%xmm3
  67799f:	0f 55 d9             	andnps %xmm1,%xmm3
  6779a2:	0f 54 d0             	andps  %xmm0,%xmm2
  6779a5:	0f 56 d3             	orps   %xmm3,%xmm2
  6779a8:	0f 57 c0             	xorps  %xmm0,%xmm0
  6779ab:	f3 0f 5a c2          	cvtss2sd %xmm2,%xmm0
  6779af:	f3 0f 10 48 44       	movss  0x44(%rax),%xmm1
  6779b4:	0f 28 d1             	movaps %xmm1,%xmm2
  6779b7:	f3 0f 5f 50 4c       	maxss  0x4c(%rax),%xmm2
  6779bc:	0f 28 da             	movaps %xmm2,%xmm3
  6779bf:	f3 0f c2 da 03       	cmpunordss %xmm2,%xmm3
  6779c4:	0f 28 e3             	movaps %xmm3,%xmm4
  6779c7:	0f 55 e2             	andnps %xmm2,%xmm4
  6779ca:	0f 54 d9             	andps  %xmm1,%xmm3
  6779cd:	0f 56 dc             	orps   %xmm4,%xmm3
  6779d0:	0f 57 c9             	xorps  %xmm1,%xmm1
  6779d3:	f3 0f 5a cb          	cvtss2sd %xmm3,%xmm1
  6779d7:	0f 28 94 24 a0 01 00 	movaps 0x1a0(%rsp),%xmm2
  6779de:	00 
  6779df:	0f 16 d0             	movlhps %xmm0,%xmm2
  6779e2:	0f 28 84 24 90 01 00 	movaps 0x190(%rsp),%xmm0
  6779e9:	00 
  6779ea:	0f 16 c1             	movlhps %xmm1,%xmm0
  6779ed:	b8 01 00 00 00       	mov    $0x1,%eax
  6779f2:	0f 29 94 24 80 00 00 	movaps %xmm2,0x80(%rsp)
  6779f9:	00 
  6779fa:	0f 29 94 24 10 01 00 	movaps %xmm2,0x110(%rsp)
  677a01:	00 
  677a02:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
  677a09:	00 
  677a0a:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
  677a11:	00 
  677a12:	e9 d1 fa ff ff       	jmp    6774e8 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xec8>
  677a17:	48 8b 84 24 d0 01 00 	mov    0x1d0(%rsp),%rax
  677a1e:	00 
  677a1f:	48 8b 8c 24 d8 01 00 	mov    0x1d8(%rsp),%rcx
  677a26:	00 
  677a27:	48 8b 94 24 e0 01 00 	mov    0x1e0(%rsp),%rdx
  677a2e:	00 
  677a2f:	48 8b b4 24 e8 01 00 	mov    0x1e8(%rsp),%rsi
  677a36:	00 
  677a37:	8b bc 24 f0 01 00 00 	mov    0x1f0(%rsp),%edi
  677a3e:	89 bc 24 50 03 00 00 	mov    %edi,0x350(%rsp)
  677a45:	8b bc 24 f4 01 00 00 	mov    0x1f4(%rsp),%edi
  677a4c:	89 bc 24 54 03 00 00 	mov    %edi,0x354(%rsp)
  677a53:	8b bc 24 f8 01 00 00 	mov    0x1f8(%rsp),%edi
  677a5a:	89 bc 24 58 03 00 00 	mov    %edi,0x358(%rsp)
  677a61:	8b bc 24 fc 01 00 00 	mov    0x1fc(%rsp),%edi
  677a68:	89 bc 24 5c 03 00 00 	mov    %edi,0x35c(%rsp)
  677a6f:	48 89 94 24 40 03 00 	mov    %rdx,0x340(%rsp)
  677a76:	00 
  677a77:	48 89 b4 24 48 03 00 	mov    %rsi,0x348(%rsp)
  677a7e:	00 
  677a7f:	48 89 84 24 30 03 00 	mov    %rax,0x330(%rsp)
  677a86:	00 
  677a87:	48 89 8c 24 38 03 00 	mov    %rcx,0x338(%rsp)
  677a8e:	00 
  677a8f:	48 8d bc 24 88 05 00 	lea    0x588(%rsp),%rdi
  677a96:	00 
  677a97:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
  677a9e:	00 
  677a9f:	ba 01 00 00 00       	mov    $0x1,%edx
  677aa4:	e8 07 96 00 00       	call   6810b0 <<parley::layout::run::Clusters<()>>::new>
  677aa9:	ba 10 01 00 00       	mov    $0x110,%edx
  677aae:	48 8d bc 24 30 03 00 	lea    0x330(%rsp),%rdi
  677ab5:	00 
  677ab6:	48 8d b4 24 88 05 00 	lea    0x588(%rsp),%rsi
  677abd:	00 
  677abe:	ff 15 bc 22 11 00    	call   *0x1122bc(%rip)        # 789d80 <memcpy@GLIBC_2.14>
  677ac4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  677acb:	00 00 00 00 00 
  677ad0:	48 8d bc 24 f8 04 00 	lea    0x4f8(%rsp),%rdi
  677ad7:	00 
  677ad8:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
  677adf:	00 
  677ae0:	e8 2b be 00 00       	call   683910 <<parley::layout::run::Clusters<()> as core::iter::traits::iterator::Iterator>::next>
  677ae5:	48 83 bc 24 f8 04 00 	cmpq   $0x0,0x4f8(%rsp)
  677aec:	00 00 
  677aee:	0f 84 e7 f4 ff ff    	je     676fdb <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x9bb>
  677af4:	ba 90 00 00 00       	mov    $0x90,%edx
  677af9:	48 8d bc 24 00 02 00 	lea    0x200(%rsp),%rdi
  677b00:	00 
  677b01:	48 8d b4 24 f8 04 00 	lea    0x4f8(%rsp),%rsi
  677b08:	00 
  677b09:	ff 15 71 22 11 00    	call   *0x112271(%rip)        # 789d80 <memcpy@GLIBC_2.14>
  677b0f:	4c 8b b4 24 48 01 00 	mov    0x148(%rsp),%r14
  677b16:	00 
  677b17:	4c 3b b4 24 38 01 00 	cmp    0x138(%rsp),%r14
  677b1e:	00 
  677b1f:	75 0e                	jne    677b2f <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x150f>
  677b21:	48 8d bc 24 38 01 00 	lea    0x138(%rsp),%rdi
  677b28:	00 
  677b29:	ff 15 51 24 11 00    	call   *0x112451(%rip)        # 789f80 <_DYNAMIC+0x4d0>
  677b2f:	48 8b 84 24 40 01 00 	mov    0x140(%rsp),%rax
  677b36:	00 
  677b37:	f3 0f 10 44 24 50    	movss  0x50(%rsp),%xmm0
  677b3d:	f3 42 0f 11 04 b0    	movss  %xmm0,(%rax,%r14,4)
  677b43:	49 ff c6             	inc    %r14
  677b46:	4c 89 b4 24 48 01 00 	mov    %r14,0x148(%rsp)
  677b4d:	00 
  677b4e:	48 83 bc 24 18 02 00 	cmpq   $0x0,0x218(%rsp)
  677b55:	00 00 
  677b57:	74 36                	je     677b8f <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x156f>
  677b59:	48 8b 84 24 00 02 00 	mov    0x200(%rsp),%rax
  677b60:	00 
  677b61:	8b ac 24 20 02 00 00 	mov    0x220(%rsp),%ebp
  677b68:	48 8b 88 18 01 00 00 	mov    0x118(%rax),%rcx
  677b6f:	48 39 e9             	cmp    %rbp,%rcx
  677b72:	0f 86 c3 04 00 00    	jbe    67803b <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a1b>
  677b78:	48 8b 80 10 01 00 00 	mov    0x110(%rax),%rax
  677b7f:	48 6b cd 70          	imul   $0x70,%rbp,%rcx
  677b83:	f3 0f 10 44 08 50    	movss  0x50(%rax,%rcx,1),%xmm0
  677b89:	8b 44 08 54          	mov    0x54(%rax,%rcx,1),%eax
  677b8d:	eb 08                	jmp    677b97 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1577>
  677b8f:	0f 57 c0             	xorps  %xmm0,%xmm0
  677b92:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  677b97:	48 8b 8c 24 08 02 00 	mov    0x208(%rsp),%rcx
  677b9e:	00 
  677b9f:	48 8b 94 24 10 02 00 	mov    0x210(%rsp),%rdx
  677ba6:	00 
  677ba7:	f2 0f 10 4a 44       	movsd  0x44(%rdx),%xmm1
  677bac:	f2 0f 11 8c 24 68 01 	movsd  %xmm1,0x168(%rsp)
  677bb3:	00 00 
  677bb5:	f3 0f 11 84 24 70 01 	movss  %xmm0,0x170(%rsp)
  677bbc:	00 00 
  677bbe:	89 84 24 74 01 00 00 	mov    %eax,0x174(%rsp)
  677bc5:	0f b6 89 8c 00 00 00 	movzbl 0x8c(%rcx),%ecx
  677bcc:	83 e1 01             	and    $0x1,%ecx
  677bcf:	48 8d bc 24 68 01 00 	lea    0x168(%rsp),%rdi
  677bd6:	00 
  677bd7:	4c 89 e6             	mov    %r12,%rsi
  677bda:	48 8d 94 24 80 02 00 	lea    0x280(%rsp),%rdx
  677be1:	00 
  677be2:	ff 15 f8 26 11 00    	call   *0x1126f8(%rip)        # 78a2e0 <_DYNAMIC+0x830>
  677be8:	f3 0f 10 4c 24 50    	movss  0x50(%rsp),%xmm1
  677bee:	f3 0f 58 c8          	addss  %xmm0,%xmm1
  677bf2:	f3 0f 11 4c 24 50    	movss  %xmm1,0x50(%rsp)
  677bf8:	e9 d3 fe ff ff       	jmp    677ad0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x14b0>
  677bfd:	4c 8b 9c 24 18 03 00 	mov    0x318(%rsp),%r11
  677c04:	00 
  677c05:	8b ac 24 8c 01 00 00 	mov    0x18c(%rsp),%ebp
  677c0c:	4c 8b b4 24 10 03 00 	mov    0x310(%rsp),%r14
  677c13:	00 
  677c14:	e9 a8 f2 ff ff       	jmp    676ec1 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x8a1>
  677c19:	49 89 d6             	mov    %rdx,%r14
  677c1c:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  677c21:	f3 0f 10 48 28       	movss  0x28(%rax),%xmm1
  677c26:	48 c1 e7 03          	shl    $0x3,%rdi
  677c2a:	48 8d 04 bf          	lea    (%rdi,%rdi,4),%rax
  677c2e:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
  677c33:	4c 8d 3c 01          	lea    (%rcx,%rax,1),%r15
  677c37:	48 c1 e6 03          	shl    $0x3,%rsi
  677c3b:	4c 8d 24 b6          	lea    (%rsi,%rsi,4),%r12
  677c3f:	49 29 c4             	sub    %rax,%r12
  677c42:	45 31 ed             	xor    %r13d,%r13d
  677c45:	eb 3e                	jmp    677c85 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1665>
  677c47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  677c4e:	00 00 
  677c50:	48 3b ac 24 e0 00 00 	cmp    0xe0(%rsp),%rbp
  677c57:	00 
  677c58:	0f 83 44 03 00 00    	jae    677fa2 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1982>
  677c5e:	48 6b c5 38          	imul   $0x38,%rbp,%rax
  677c62:	48 8b 8c 24 28 03 00 	mov    0x328(%rsp),%rcx
  677c69:	00 
  677c6a:	f3 0f 10 44 01 24    	movss  0x24(%rcx,%rax,1),%xmm0
  677c70:	49 83 c7 28          	add    $0x28,%r15
  677c74:	f3 0f 58 c8          	addss  %xmm0,%xmm1
  677c78:	49 ff c5             	inc    %r13
  677c7b:	49 83 c4 d8          	add    $0xffffffffffffffd8,%r12
  677c7f:	0f 84 14 f2 ff ff    	je     676e99 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x879>
  677c85:	49 8b 6f 10          	mov    0x10(%r15),%rbp
  677c89:	41 80 7f 21 01       	cmpb   $0x1,0x21(%r15)
  677c8e:	74 c0                	je     677c50 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1630>
  677c90:	48 3b ac 24 20 01 00 	cmp    0x120(%rsp),%rbp
  677c97:	00 
  677c98:	0f 83 1d 03 00 00    	jae    677fbb <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x199b>
  677c9e:	48 3b ac 24 c8 01 00 	cmp    0x1c8(%rsp),%rbp
  677ca5:	00 
  677ca6:	0f 83 cc 02 00 00    	jae    677f78 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1958>
  677cac:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
  677cb3:	00 
  677cb4:	48 01 e8             	add    %rbp,%rax
  677cb7:	48 c1 e0 04          	shl    $0x4,%rax
  677cbb:	48 03 84 24 28 01 00 	add    0x128(%rsp),%rax
  677cc2:	00 
  677cc3:	48 8d 0c ad 00 00 00 	lea    0x0(,%rbp,4),%rcx
  677cca:	00 
  677ccb:	48 01 e9             	add    %rbp,%rcx
  677cce:	48 c1 e1 04          	shl    $0x4,%rcx
  677cd2:	48 03 8c 24 e8 00 00 	add    0xe8(%rsp),%rcx
  677cd9:	00 
  677cda:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  677cdf:	48 89 94 24 30 03 00 	mov    %rdx,0x330(%rsp)
  677ce6:	00 
  677ce7:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
  677cee:	00 
  677cef:	48 89 8c 24 40 03 00 	mov    %rcx,0x340(%rsp)
  677cf6:	00 
  677cf7:	4c 89 bc 24 48 03 00 	mov    %r15,0x348(%rsp)
  677cfe:	00 
  677cff:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  677d04:	89 84 24 50 03 00 00 	mov    %eax,0x350(%rsp)
  677d0b:	44 89 ac 24 54 03 00 	mov    %r13d,0x354(%rsp)
  677d12:	00 
  677d13:	89 ac 24 58 03 00 00 	mov    %ebp,0x358(%rsp)
  677d1a:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  677d1f:	48 8b 68 10          	mov    0x10(%rax),%rbp
  677d23:	4c 01 ed             	add    %r13,%rbp
  677d26:	48 3b 6c 24 20       	cmp    0x20(%rsp),%rbp
  677d2b:	0f 83 a0 02 00 00    	jae    677fd1 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19b1>
  677d31:	48 8d 04 ad 00 00 00 	lea    0x0(,%rbp,4),%rax
  677d38:	00 
  677d39:	48 01 e8             	add    %rbp,%rax
  677d3c:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
  677d41:	48 8b 6c c1 10       	mov    0x10(%rcx,%rax,8),%rbp
  677d46:	4c 29 f5             	sub    %r14,%rbp
  677d49:	48 39 dd             	cmp    %rbx,%rbp
  677d4c:	0f 83 3f 02 00 00    	jae    677f91 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1971>
  677d52:	48 8b 84 24 98 00 00 	mov    0x98(%rsp),%rax
  677d59:	00 
  677d5a:	f3 0f 11 4c 24 50    	movss  %xmm1,0x50(%rsp)
  677d60:	f3 0f 11 4c e8 04    	movss  %xmm1,0x4(%rax,%rbp,8)
  677d66:	48 8d bc 24 30 03 00 	lea    0x330(%rsp),%rdi
  677d6d:	00 
  677d6e:	e8 7d 8e 00 00       	call   680bf0 <<parley::layout::run::Run<()>>::advance>
  677d73:	f3 0f 10 4c 24 50    	movss  0x50(%rsp),%xmm1
  677d79:	e9 f2 fe ff ff       	jmp    677c70 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1650>
  677d7e:	4c 8d b4 24 30 03 00 	lea    0x330(%rsp),%r14
  677d85:	00 
  677d86:	48 8d b4 24 50 04 00 	lea    0x450(%rsp),%rsi
  677d8d:	00 
  677d8e:	ba a8 00 00 00       	mov    $0xa8,%edx
  677d93:	4c 89 f7             	mov    %r14,%rdi
  677d96:	ff 15 e4 1f 11 00    	call   *0x111fe4(%rip)        # 789d80 <memcpy@GLIBC_2.14>
  677d9c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  677da1:	4c 89 f6             	mov    %r14,%rsi
  677da4:	f3 0f 10 44 24 14    	movss  0x14(%rsp),%xmm0
  677daa:	4c 89 fa             	mov    %r15,%rdx
  677dad:	e8 ee 12 00 00       	call   6790a0 <parley::editing::geometry::visit_direct::<(), gpui_canvas::Error, core::iter::adapters::peekable::Peekable<icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>>, gpui_canvas::text::planner::append_carets::{closure#1}>>
  677db2:	eb 5b                	jmp    677e0f <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x17ef>
  677db4:	31 ed                	xor    %ebp,%ebp
  677db6:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  677dbb:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
  677dc0:	48 89 de             	mov    %rbx,%rsi
  677dc3:	f3 0f 10 44 24 14    	movss  0x14(%rsp),%xmm0
  677dc9:	4c 89 fa             	mov    %r15,%rdx
  677dcc:	e8 ff 14 00 00       	call   6792d0 <parley::editing::geometry::visit_indexed::<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>>
  677dd1:	e9 cc 00 00 00       	jmp    677ea2 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1882>
  677dd6:	4c 8d b4 24 00 02 00 	lea    0x200(%rsp),%r14
  677ddd:	00 
  677dde:	48 8d b4 24 50 04 00 	lea    0x450(%rsp),%rsi
  677de5:	00 
  677de6:	ba a8 00 00 00       	mov    $0xa8,%edx
  677deb:	4c 89 f7             	mov    %r14,%rdi
  677dee:	ff 15 8c 1f 11 00    	call   *0x111f8c(%rip)        # 789d80 <memcpy@GLIBC_2.14>
  677df4:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  677df9:	4c 89 f6             	mov    %r14,%rsi
  677dfc:	f3 0f 10 44 24 14    	movss  0x14(%rsp),%xmm0
  677e02:	4c 89 fa             	mov    %r15,%rdx
  677e05:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
  677e0a:	e8 91 12 00 00       	call   6790a0 <parley::editing::geometry::visit_direct::<(), gpui_canvas::Error, core::iter::adapters::peekable::Peekable<icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>>, gpui_canvas::text::planner::append_carets::{closure#1}>>
  677e0f:	41 89 c6             	mov    %eax,%r14d
  677e12:	eb 24                	jmp    677e38 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1818>
  677e14:	48 8b b4 24 60 04 00 	mov    0x460(%rsp),%rsi
  677e1b:	00 
  677e1c:	48 85 f6             	test   %rsi,%rsi
  677e1f:	74 17                	je     677e38 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1818>
  677e21:	48 8b bc 24 68 04 00 	mov    0x468(%rsp),%rdi
  677e28:	00 
  677e29:	48 c1 e6 03          	shl    $0x3,%rsi
  677e2d:	ba 08 00 00 00       	mov    $0x8,%edx
  677e32:	ff 15 b0 1e 11 00    	call   *0x111eb0(%rip)        # 789ce8 <_DYNAMIC+0x238>
  677e38:	48 8b b4 24 38 01 00 	mov    0x138(%rsp),%rsi
  677e3f:	00 
  677e40:	48 85 f6             	test   %rsi,%rsi
  677e43:	74 17                	je     677e5c <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x183c>
  677e45:	48 8b bc 24 40 01 00 	mov    0x140(%rsp),%rdi
  677e4c:	00 
  677e4d:	48 c1 e6 02          	shl    $0x2,%rsi
  677e51:	ba 04 00 00 00       	mov    $0x4,%edx
  677e56:	ff 15 8c 1e 11 00    	call   *0x111e8c(%rip)        # 789ce8 <_DYNAMIC+0x238>
  677e5c:	48 8b b4 24 b8 00 00 	mov    0xb8(%rsp),%rsi
  677e63:	00 
  677e64:	48 85 f6             	test   %rsi,%rsi
  677e67:	0f 84 95 00 00 00    	je     677f02 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18e2>
  677e6d:	48 c1 e6 03          	shl    $0x3,%rsi
  677e71:	ba 04 00 00 00       	mov    $0x4,%edx
  677e76:	48 8b bc 24 98 00 00 	mov    0x98(%rsp),%rdi
  677e7d:	00 
  677e7e:	eb 7c                	jmp    677efc <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18dc>
  677e80:	31 ed                	xor    %ebp,%ebp
  677e82:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  677e87:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
  677e8c:	48 89 de             	mov    %rbx,%rsi
  677e8f:	f3 0f 10 44 24 14    	movss  0x14(%rsp),%xmm0
  677e95:	48 8b 94 24 30 01 00 	mov    0x130(%rsp),%rdx
  677e9c:	00 
  677e9d:	e8 2e 14 00 00       	call   6792d0 <parley::editing::geometry::visit_indexed::<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>>
  677ea2:	41 89 c6             	mov    %eax,%r14d
  677ea5:	31 ff                	xor    %edi,%edi
  677ea7:	eb 09                	jmp    677eb2 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1892>
  677ea9:	41 be fe ff ff ff    	mov    $0xfffffffe,%r14d
  677eaf:	40 b7 01             	mov    $0x1,%dil
  677eb2:	48 8b b4 24 b8 00 00 	mov    0xb8(%rsp),%rsi
  677eb9:	00 
  677eba:	48 85 f6             	test   %rsi,%rsi
  677ebd:	74 1b                	je     677eda <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18ba>
  677ebf:	89 fb                	mov    %edi,%ebx
  677ec1:	48 8b bc 24 c0 00 00 	mov    0xc0(%rsp),%rdi
  677ec8:	00 
  677ec9:	48 c1 e6 03          	shl    $0x3,%rsi
  677ecd:	ba 04 00 00 00       	mov    $0x4,%edx
  677ed2:	ff 15 10 1e 11 00    	call   *0x111e10(%rip)        # 789ce8 <_DYNAMIC+0x238>
  677ed8:	89 df                	mov    %ebx,%edi
  677eda:	40 84 ff             	test   %dil,%dil
  677edd:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  677ee2:	74 1e                	je     677f02 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18e2>
  677ee4:	48 89 f0             	mov    %rsi,%rax
  677ee7:	48 8b 36             	mov    (%rsi),%rsi
  677eea:	48 85 f6             	test   %rsi,%rsi
  677eed:	74 13                	je     677f02 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18e2>
  677eef:	48 8b 78 08          	mov    0x8(%rax),%rdi
  677ef3:	48 c1 e6 03          	shl    $0x3,%rsi
  677ef7:	ba 08 00 00 00       	mov    $0x8,%edx
  677efc:	ff 15 e6 1d 11 00    	call   *0x111de6(%rip)        # 789ce8 <_DYNAMIC+0x238>
  677f02:	44 89 f0             	mov    %r14d,%eax
  677f05:	48 81 c4 a8 07 00 00 	add    $0x7a8,%rsp
  677f0c:	5b                   	pop    %rbx
  677f0d:	41 5c                	pop    %r12
  677f0f:	41 5d                	pop    %r13
  677f11:	41 5e                	pop    %r14
  677f13:	41 5f                	pop    %r15
  677f15:	5d                   	pop    %rbp
  677f16:	c3                   	ret
  677f17:	48 8d 0d a2 79 10 00 	lea    0x1079a2(%rip),%rcx        # 77f8c0 <anon.078e2e963a048095b6b8e4da3cd13e67.23.llvm.9964956014867501821>
  677f1e:	ff 15 e4 20 11 00    	call   *0x1120e4(%rip)        # 78a008 <_DYNAMIC+0x558>
  677f24:	e9 36 01 00 00       	jmp    67805f <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a3f>
  677f29:	48 8d 0d 80 83 10 00 	lea    0x108380(%rip),%rcx        # 7802b0 <anon.c85b311aa65b1c615d2dfba884aacc4b.17.llvm.6911206892222571341>
  677f30:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  677f35:	ff 15 cd 20 11 00    	call   *0x1120cd(%rip)        # 78a008 <_DYNAMIC+0x558>
  677f3b:	e9 1f 01 00 00       	jmp    67805f <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a3f>
  677f40:	48 8d 3d ec 61 be ff 	lea    -0x419e14(%rip),%rdi        # 25e133 <anon.06a23643b1506f5b010724d430886465.20.llvm.301643317217076259+0x15>
  677f47:	48 8d 15 82 78 10 00 	lea    0x107882(%rip),%rdx        # 77f7d0 <anon.06a23643b1506f5b010724d430886465.32.llvm.301643317217076259+0x90>
  677f4e:	be 21 00 00 00       	mov    $0x21,%esi
  677f53:	ff 15 2f 20 11 00    	call   *0x11202f(%rip)        # 789f88 <_DYNAMIC+0x4d8>
  677f59:	e9 01 01 00 00       	jmp    67805f <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a3f>
  677f5e:	40 b5 01             	mov    $0x1,%bpl
  677f61:	48 8d 15 a0 79 10 00 	lea    0x1079a0(%rip),%rdx        # 77f908 <anon.078e2e963a048095b6b8e4da3cd13e67.28.llvm.9964956014867501821>
  677f68:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
  677f6d:	ff 15 9d 1e 11 00    	call   *0x111e9d(%rip)        # 789e10 <_DYNAMIC+0x360>
  677f73:	e9 e7 00 00 00       	jmp    67805f <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a3f>
  677f78:	48 8b 84 24 c8 01 00 	mov    0x1c8(%rsp),%rax
  677f7f:	00 
  677f80:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  677f85:	48 8d 05 ec 78 10 00 	lea    0x1078ec(%rip),%rax        # 77f878 <anon.06a23643b1506f5b010724d430886465.32.llvm.301643317217076259+0x138>
  677f8c:	e9 b6 00 00 00       	jmp    678047 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a27>
  677f91:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
  677f96:	48 8d 05 ab 78 10 00 	lea    0x1078ab(%rip),%rax        # 77f848 <anon.06a23643b1506f5b010724d430886465.32.llvm.301643317217076259+0x108>
  677f9d:	e9 a5 00 00 00       	jmp    678047 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a27>
  677fa2:	48 8b 84 24 e0 00 00 	mov    0xe0(%rsp),%rax
  677fa9:	00 
  677faa:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  677faf:	48 8d 05 da 78 10 00 	lea    0x1078da(%rip),%rax        # 77f890 <anon.06a23643b1506f5b010724d430886465.32.llvm.301643317217076259+0x150>
  677fb6:	e9 8c 00 00 00       	jmp    678047 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a27>
  677fbb:	48 8b 84 24 20 01 00 	mov    0x120(%rsp),%rax
  677fc2:	00 
  677fc3:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  677fc8:	48 8d 05 91 78 10 00 	lea    0x107891(%rip),%rax        # 77f860 <anon.06a23643b1506f5b010724d430886465.32.llvm.301643317217076259+0x120>
  677fcf:	eb 76                	jmp    678047 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a27>
  677fd1:	48 8d 05 58 78 10 00 	lea    0x107858(%rip),%rax        # 77f830 <anon.06a23643b1506f5b010724d430886465.32.llvm.301643317217076259+0xf0>
  677fd8:	eb 6d                	jmp    678047 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a27>
  677fda:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  677fdf:	48 8d 05 22 79 10 00 	lea    0x107922(%rip),%rax        # 77f908 <anon.078e2e963a048095b6b8e4da3cd13e67.28.llvm.9964956014867501821>
  677fe6:	eb 5f                	jmp    678047 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a27>
  677fe8:	31 ed                	xor    %ebp,%ebp
  677fea:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
  677ff1:	00 00 
  677ff3:	eb 57                	jmp    67804c <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a2c>
  677ff5:	4c 89 f5             	mov    %r14,%rbp
  677ff8:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  677ffd:	48 8d 05 fc 77 10 00 	lea    0x1077fc(%rip),%rax        # 77f800 <anon.06a23643b1506f5b010724d430886465.32.llvm.301643317217076259+0xc0>
  678004:	eb 41                	jmp    678047 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a27>
  678006:	48 3b 8c 24 e0 00 00 	cmp    0xe0(%rsp),%rcx
  67800d:	00 
  67800e:	48 8d 05 03 78 10 00 	lea    0x107803(%rip),%rax        # 77f818 <anon.06a23643b1506f5b010724d430886465.32.llvm.301643317217076259+0xd8>
  678015:	48 8d 0d cc 77 10 00 	lea    0x1077cc(%rip),%rcx        # 77f7e8 <anon.06a23643b1506f5b010724d430886465.32.llvm.301643317217076259+0xa8>
  67801c:	48 0f 42 c8          	cmovb  %rax,%rcx
  678020:	48 89 8c 24 b8 01 00 	mov    %rcx,0x1b8(%rsp)
  678027:	00 
  678028:	48 8b bc 24 b8 01 00 	mov    0x1b8(%rsp),%rdi
  67802f:	00 
  678030:	ff 15 b2 1d 11 00    	call   *0x111db2(%rip)        # 789de8 <_DYNAMIC+0x338>
  678036:	eb 27                	jmp    67805f <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a3f>
  678038:	48 89 c5             	mov    %rax,%rbp
  67803b:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  678040:	48 8d 05 a9 78 10 00 	lea    0x1078a9(%rip),%rax        # 77f8f0 <anon.078e2e963a048095b6b8e4da3cd13e67.26.llvm.9964956014867501821>
  678047:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  67804c:	48 89 ef             	mov    %rbp,%rdi
  67804f:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  678054:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
  678059:	ff 15 b1 1d 11 00    	call   *0x111db1(%rip)        # 789e10 <_DYNAMIC+0x360>
  67805f:	0f 0b                	ud2
  678061:	49 89 c6             	mov    %rax,%r14
  678064:	eb 56                	jmp    6780bc <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a9c>
  678066:	eb 28                	jmp    678090 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a70>
  678068:	49 89 c6             	mov    %rax,%r14
  67806b:	eb 2b                	jmp    678098 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a78>
  67806d:	eb 12                	jmp    678081 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a61>
  67806f:	eb 1f                	jmp    678090 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a70>
  678071:	eb 0e                	jmp    678081 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a61>
  678073:	eb 1b                	jmp    678090 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a70>
  678075:	eb 0a                	jmp    678081 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a61>
  678077:	eb 08                	jmp    678081 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a61>
  678079:	eb 15                	jmp    678090 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a70>
  67807b:	eb 13                	jmp    678090 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a70>
  67807d:	eb 11                	jmp    678090 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a70>
  67807f:	eb 00                	jmp    678081 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a61>
  678081:	49 89 c6             	mov    %rax,%r14
  678084:	40 b5 01             	mov    $0x1,%bpl
  678087:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
  67808c:	eb 5d                	jmp    6780eb <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1acb>
  67808e:	eb 00                	jmp    678090 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a70>
  678090:	49 89 c6             	mov    %rax,%r14
  678093:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
  678098:	48 8b b4 24 60 04 00 	mov    0x460(%rsp),%rsi
  67809f:	00 
  6780a0:	48 85 f6             	test   %rsi,%rsi
  6780a3:	74 17                	je     6780bc <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a9c>
  6780a5:	48 8b bc 24 68 04 00 	mov    0x468(%rsp),%rdi
  6780ac:	00 
  6780ad:	48 c1 e6 03          	shl    $0x3,%rsi
  6780b1:	ba 08 00 00 00       	mov    $0x8,%edx
  6780b6:	ff 15 2c 1c 11 00    	call   *0x111c2c(%rip)        # 789ce8 <_DYNAMIC+0x238>
  6780bc:	48 8b b4 24 38 01 00 	mov    0x138(%rsp),%rsi
  6780c3:	00 
  6780c4:	48 85 f6             	test   %rsi,%rsi
  6780c7:	75 04                	jne    6780cd <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1aad>
  6780c9:	31 ed                	xor    %ebp,%ebp
  6780cb:	eb 1e                	jmp    6780eb <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1acb>
  6780cd:	48 8b bc 24 40 01 00 	mov    0x140(%rsp),%rdi
  6780d4:	00 
  6780d5:	48 c1 e6 02          	shl    $0x2,%rsi
  6780d9:	ba 04 00 00 00       	mov    $0x4,%edx
  6780de:	ff 15 04 1c 11 00    	call   *0x111c04(%rip)        # 789ce8 <_DYNAMIC+0x238>
  6780e4:	31 ed                	xor    %ebp,%ebp
  6780e6:	eb 03                	jmp    6780eb <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1acb>
  6780e8:	49 89 c6             	mov    %rax,%r14
  6780eb:	48 8b b4 24 b8 00 00 	mov    0xb8(%rsp),%rsi
  6780f2:	00 
  6780f3:	48 85 f6             	test   %rsi,%rsi
  6780f6:	74 17                	je     67810f <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1aef>
  6780f8:	48 8b bc 24 c0 00 00 	mov    0xc0(%rsp),%rdi
  6780ff:	00 
  678100:	48 c1 e6 03          	shl    $0x3,%rsi
  678104:	ba 04 00 00 00       	mov    $0x4,%edx
  678109:	ff 15 d9 1b 11 00    	call   *0x111bd9(%rip)        # 789ce8 <_DYNAMIC+0x238>
  67810f:	40 84 ed             	test   %bpl,%bpl
  678112:	74 1b                	je     67812f <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1b0f>
  678114:	48 8b 33             	mov    (%rbx),%rsi
  678117:	48 85 f6             	test   %rsi,%rsi
  67811a:	74 13                	je     67812f <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1b0f>
  67811c:	48 8b 7b 08          	mov    0x8(%rbx),%rdi
  678120:	48 c1 e6 03          	shl    $0x3,%rsi
  678124:	ba 08 00 00 00       	mov    $0x8,%edx
  678129:	ff 15 b9 1b 11 00    	call   *0x111bb9(%rip)        # 789ce8 <_DYNAMIC+0x238>
  67812f:	4c 89 f7             	mov    %r14,%rdi
  678132:	e8 d9 5b 10 00       	call   77dd10 <_Unwind_Resume@plt>
