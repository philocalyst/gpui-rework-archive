
/tmp/gpui-monotonic-control-bin/stream8:     file format elf64-x86-64


Disassembly of section .text:

0000000000668cd0 <<gpui_canvas::text::planner::Planner>::shape>:
  668cd0:	55                   	push   %rbp
  668cd1:	41 57                	push   %r15
  668cd3:	41 56                	push   %r14
  668cd5:	41 55                	push   %r13
  668cd7:	41 54                	push   %r12
  668cd9:	53                   	push   %rbx
  668cda:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
  668ce1:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
  668ce8:	00 
  668ce9:	48 81 ec e8 01 00 00 	sub    $0x1e8,%rsp
  668cf0:	44 89 8c 24 2c 02 00 	mov    %r9d,0x22c(%rsp)
  668cf7:	00 
  668cf8:	f3 0f 11 8c 24 cc 01 	movss  %xmm1,0x1cc(%rsp)
  668cff:	00 00 
  668d01:	44 89 84 24 c8 01 00 	mov    %r8d,0x1c8(%rsp)
  668d08:	00 
  668d09:	f3 0f 11 84 24 84 00 	movss  %xmm0,0x84(%rsp)
  668d10:	00 00 
  668d12:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
  668d17:	49 89 f5             	mov    %rsi,%r13
  668d1a:	48 89 bc 24 38 03 00 	mov    %rdi,0x338(%rsp)
  668d21:	00 
  668d22:	4c 8d 24 0a          	lea    (%rdx,%rcx,1),%r12
  668d26:	48 85 c9             	test   %rcx,%rcx
  668d29:	48 89 34 24          	mov    %rsi,(%rsp)
  668d2d:	48 89 94 24 48 01 00 	mov    %rdx,0x148(%rsp)
  668d34:	00 
  668d35:	4c 89 a4 24 b0 01 00 	mov    %r12,0x1b0(%rsp)
  668d3c:	00 
  668d3d:	0f 84 90 03 00 00    	je     6690d3 <<gpui_canvas::text::planner::Planner>::shape+0x403>
  668d43:	49 8d 85 78 0a 00 00 	lea    0xa78(%r13),%rax
  668d4a:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  668d4f:	48 8d b4 24 ec 0c 00 	lea    0xcec(%rsp),%rsi
  668d56:	00 
  668d57:	49 8d 45 38          	lea    0x38(%r13),%rax
  668d5b:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  668d60:	49 8d 45 3c          	lea    0x3c(%r13),%rax
  668d64:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  668d6b:	00 
  668d6c:	49 8d 45 58          	lea    0x58(%r13),%rax
  668d70:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
  668d77:	00 
  668d78:	49 8d 45 5c          	lea    0x5c(%r13),%rax
  668d7c:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  668d81:	45 31 ff             	xor    %r15d,%r15d
  668d84:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  668d8b:	00 
  668d8c:	4c 8b 05 3d 11 12 00 	mov    0x12113d(%rip),%r8        # 789ed0 <_DYNAMIC+0x420>
  668d93:	49 89 d6             	mov    %rdx,%r14
  668d96:	44 89 7c 24 30       	mov    %r15d,0x30(%rsp)
  668d9b:	eb 1c                	jmp    668db9 <<gpui_canvas::text::planner::Planner>::shape+0xe9>
  668d9d:	0f 1f 00             	nopl   (%rax)
  668da0:	41 8d 87 d8 df ff ff 	lea    -0x2028(%r15),%eax
  668da7:	83 f8 02             	cmp    $0x2,%eax
  668daa:	0f 83 e1 00 00 00    	jae    668e91 <<gpui_canvas::text::planner::Planner>::shape+0x1c1>
  668db0:	4d 39 e6             	cmp    %r12,%r14
  668db3:	0f 84 ba 02 00 00    	je     669073 <<gpui_canvas::text::planner::Planner>::shape+0x3a3>
  668db9:	45 0f b6 3e          	movzbl (%r14),%r15d
  668dbd:	45 84 ff             	test   %r15b,%r15b
  668dc0:	78 1e                	js     668de0 <<gpui_canvas::text::planner::Planner>::shape+0x110>
  668dc2:	49 ff c6             	inc    %r14
  668dc5:	41 81 ff 27 20 00 00 	cmp    $0x2027,%r15d
  668dcc:	0f 8e 9e 00 00 00    	jle    668e70 <<gpui_canvas::text::planner::Planner>::shape+0x1a0>
  668dd2:	eb cc                	jmp    668da0 <<gpui_canvas::text::planner::Planner>::shape+0xd0>
  668dd4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  668ddb:	00 00 00 00 00 
  668de0:	44 89 f8             	mov    %r15d,%eax
  668de3:	83 e0 1f             	and    $0x1f,%eax
  668de6:	41 0f b6 56 01       	movzbl 0x1(%r14),%edx
  668deb:	83 e2 3f             	and    $0x3f,%edx
  668dee:	41 80 ff df          	cmp    $0xdf,%r15b
  668df2:	76 3d                	jbe    668e31 <<gpui_canvas::text::planner::Planner>::shape+0x161>
  668df4:	41 0f b6 4e 02       	movzbl 0x2(%r14),%ecx
  668df9:	c1 e2 06             	shl    $0x6,%edx
  668dfc:	83 e1 3f             	and    $0x3f,%ecx
  668dff:	09 d1                	or     %edx,%ecx
  668e01:	41 80 ff f0          	cmp    $0xf0,%r15b
  668e05:	72 44                	jb     668e4b <<gpui_canvas::text::planner::Planner>::shape+0x17b>
  668e07:	45 0f b6 7e 03       	movzbl 0x3(%r14),%r15d
  668e0c:	49 83 c6 04          	add    $0x4,%r14
  668e10:	83 e0 07             	and    $0x7,%eax
  668e13:	c1 e0 12             	shl    $0x12,%eax
  668e16:	c1 e1 06             	shl    $0x6,%ecx
  668e19:	41 83 e7 3f          	and    $0x3f,%r15d
  668e1d:	41 09 cf             	or     %ecx,%r15d
  668e20:	41 09 c7             	or     %eax,%r15d
  668e23:	41 81 ff 27 20 00 00 	cmp    $0x2027,%r15d
  668e2a:	7e 44                	jle    668e70 <<gpui_canvas::text::planner::Planner>::shape+0x1a0>
  668e2c:	e9 6f ff ff ff       	jmp    668da0 <<gpui_canvas::text::planner::Planner>::shape+0xd0>
  668e31:	49 83 c6 02          	add    $0x2,%r14
  668e35:	c1 e0 06             	shl    $0x6,%eax
  668e38:	09 d0                	or     %edx,%eax
  668e3a:	41 89 c7             	mov    %eax,%r15d
  668e3d:	41 81 ff 27 20 00 00 	cmp    $0x2027,%r15d
  668e44:	7e 2a                	jle    668e70 <<gpui_canvas::text::planner::Planner>::shape+0x1a0>
  668e46:	e9 55 ff ff ff       	jmp    668da0 <<gpui_canvas::text::planner::Planner>::shape+0xd0>
  668e4b:	49 83 c6 03          	add    $0x3,%r14
  668e4f:	c1 e0 0c             	shl    $0xc,%eax
  668e52:	09 c1                	or     %eax,%ecx
  668e54:	41 89 cf             	mov    %ecx,%r15d
  668e57:	41 81 ff 27 20 00 00 	cmp    $0x2027,%r15d
  668e5e:	0f 8f 3c ff ff ff    	jg     668da0 <<gpui_canvas::text::planner::Planner>::shape+0xd0>
  668e64:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  668e6b:	00 00 00 00 00 
  668e70:	41 83 ff 0a          	cmp    $0xa,%r15d
  668e74:	0f 84 36 ff ff ff    	je     668db0 <<gpui_canvas::text::planner::Planner>::shape+0xe0>
  668e7a:	41 83 ff 0d          	cmp    $0xd,%r15d
  668e7e:	0f 84 2c ff ff ff    	je     668db0 <<gpui_canvas::text::planner::Planner>::shape+0xe0>
  668e84:	41 81 ff 85 00 00 00 	cmp    $0x85,%r15d
  668e8b:	0f 84 1f ff ff ff    	je     668db0 <<gpui_canvas::text::planner::Planner>::shape+0xe0>
  668e91:	49 89 fd             	mov    %rdi,%r13
  668e94:	48 8d 3d 65 62 11 00 	lea    0x116265(%rip),%rdi        # 77f100 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0x30>
  668e9b:	48 89 f3             	mov    %rsi,%rbx
  668e9e:	44 89 fe             	mov    %r15d,%esi
  668ea1:	4c 89 c5             	mov    %r8,%rbp
  668ea4:	ff 15 be 11 12 00    	call   *0x1211be(%rip)        # 78a068 <_DYNAMIC+0x5b8>
  668eaa:	49 89 e8             	mov    %rbp,%r8
  668ead:	4c 89 ef             	mov    %r13,%rdi
  668eb0:	48 89 de             	mov    %rbx,%rsi
  668eb3:	84 c0                	test   %al,%al
  668eb5:	0f 85 f5 fe ff ff    	jne    668db0 <<gpui_canvas::text::planner::Planner>::shape+0xe0>
  668ebb:	41 bc 0a 00 00 00    	mov    $0xa,%r12d
  668ec1:	41 83 ff 20          	cmp    $0x20,%r15d
  668ec5:	0f 82 5b 02 00 00    	jb     669126 <<gpui_canvas::text::planner::Planner>::shape+0x456>
  668ecb:	41 8d 47 81          	lea    -0x7f(%r15),%eax
  668ecf:	83 f8 21             	cmp    $0x21,%eax
  668ed2:	0f 82 4e 02 00 00    	jb     669126 <<gpui_canvas::text::planner::Planner>::shape+0x456>
  668ed8:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  668edd:	44 89 fe             	mov    %r15d,%esi
  668ee0:	e8 bb 3b 00 00       	call   66caa0 <<gpui_canvas::text::planner::Cmap>::glyph_index>
  668ee5:	49 89 e8             	mov    %rbp,%r8
  668ee8:	4c 89 ef             	mov    %r13,%rdi
  668eeb:	a8 01                	test   $0x1,%al
  668eed:	4c 8b a4 24 b0 01 00 	mov    0x1b0(%rsp),%r12
  668ef4:	00 
  668ef5:	74 0c                	je     668f03 <<gpui_canvas::text::planner::Planner>::shape+0x233>
  668ef7:	48 89 de             	mov    %rbx,%rsi
  668efa:	66 85 d2             	test   %dx,%dx
  668efd:	0f 85 ad fe ff ff    	jne    668db0 <<gpui_canvas::text::planner::Planner>::shape+0xe0>
  668f03:	48 8b 0c 24          	mov    (%rsp),%rcx
  668f07:	48 8b 81 40 0a 00 00 	mov    0xa40(%rcx),%rax
  668f0e:	41 bc 0b 00 00 00    	mov    $0xb,%r12d
  668f14:	80 78 38 01          	cmpb   $0x1,0x38(%rax)
  668f18:	0f 85 08 02 00 00    	jne    669126 <<gpui_canvas::text::planner::Planner>::shape+0x456>
  668f1e:	48 83 79 30 00       	cmpq   $0x0,0x30(%rcx)
  668f23:	0f 85 e9 00 00 00    	jne    669012 <<gpui_canvas::text::planner::Planner>::shape+0x342>
  668f29:	ba 48 ab 03 00       	mov    $0x3ab48,%edx
  668f2e:	48 8d 35 c7 cb 9b ff 	lea    -0x643439(%rip),%rsi        # 25afc <gpui_canvas::text::ARABIC_BYTES>
  668f35:	31 c9                	xor    %ecx,%ecx
  668f37:	41 ff d0             	call   *%r8
  668f3a:	83 bc 24 10 07 00 00 	cmpl   $0xffffffff,0x710(%rsp)
  668f41:	ff 
  668f42:	0f 84 7d 2f 00 00    	je     66bec5 <<gpui_canvas::text::planner::Planner>::shape+0x31f5>
  668f48:	8b 84 24 e8 0c 00 00 	mov    0xce8(%rsp),%eax
  668f4f:	89 44 24 08          	mov    %eax,0x8(%rsp)
  668f53:	0f 10 03             	movups (%rbx),%xmm0
  668f56:	0f 10 4b 0c          	movups 0xc(%rbx),%xmm1
  668f5a:	0f 29 84 24 c0 04 00 	movaps %xmm0,0x4c0(%rsp)
  668f61:	00 
  668f62:	0f 11 8c 24 cc 04 00 	movups %xmm1,0x4cc(%rsp)
  668f69:	00 
  668f6a:	ba 14 69 00 00       	mov    $0x6914,%edx
  668f6f:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  668f76:	00 
  668f77:	48 8d 35 c6 76 9f ff 	lea    -0x60893a(%rip),%rsi        # 60644 <gpui_canvas::text::HEBREW_BYTES>
  668f7e:	31 c9                	xor    %ecx,%ecx
  668f80:	ff 15 4a 0f 12 00    	call   *0x120f4a(%rip)        # 789ed0 <_DYNAMIC+0x420>
  668f86:	83 bc 24 10 07 00 00 	cmpl   $0xffffffff,0x710(%rsp)
  668f8d:	ff 
  668f8e:	0f 84 43 2f 00 00    	je     66bed7 <<gpui_canvas::text::planner::Planner>::shape+0x3207>
  668f94:	8b 94 24 e8 0c 00 00 	mov    0xce8(%rsp),%edx
  668f9b:	48 8d 84 24 ec 0c 00 	lea    0xcec(%rsp),%rax
  668fa2:	00 
  668fa3:	0f 10 00             	movups (%rax),%xmm0
  668fa6:	0f 10 48 0c          	movups 0xc(%rax),%xmm1
  668faa:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
  668fb1:	00 
  668fb2:	0f 11 8c 24 4c 03 00 	movups %xmm1,0x34c(%rsp)
  668fb9:	00 
  668fba:	48 8b 04 24          	mov    (%rsp),%rax
  668fbe:	48 c7 40 30 01 00 00 	movq   $0x1,0x30(%rax)
  668fc5:	00 
  668fc6:	8b 4c 24 08          	mov    0x8(%rsp),%ecx
  668fca:	89 48 38             	mov    %ecx,0x38(%rax)
  668fcd:	0f 10 84 24 cc 04 00 	movups 0x4cc(%rsp),%xmm0
  668fd4:	00 
  668fd5:	48 8b 8c 24 00 01 00 	mov    0x100(%rsp),%rcx
  668fdc:	00 
  668fdd:	0f 11 41 0c          	movups %xmm0,0xc(%rcx)
  668fe1:	0f 28 84 24 c0 04 00 	movaps 0x4c0(%rsp),%xmm0
  668fe8:	00 
  668fe9:	0f 11 01             	movups %xmm0,(%rcx)
  668fec:	89 94 24 d0 01 00 00 	mov    %edx,0x1d0(%rsp)
  668ff3:	89 50 58             	mov    %edx,0x58(%rax)
  668ff6:	0f 10 84 24 4c 03 00 	movups 0x34c(%rsp),%xmm0
  668ffd:	00 
  668ffe:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  669003:	0f 11 40 0c          	movups %xmm0,0xc(%rax)
  669007:	0f 28 84 24 40 03 00 	movaps 0x340(%rsp),%xmm0
  66900e:	00 
  66900f:	0f 11 00             	movups %xmm0,(%rax)
  669012:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
  669017:	44 89 fe             	mov    %r15d,%esi
  66901a:	e8 81 3a 00 00       	call   66caa0 <<gpui_canvas::text::planner::Cmap>::glyph_index>
  66901f:	66 85 d2             	test   %dx,%dx
  669022:	0f 95 c1             	setne  %cl
  669025:	20 c1                	and    %al,%cl
  669027:	88 4c 24 60          	mov    %cl,0x60(%rsp)
  66902b:	48 8b bc 24 10 01 00 	mov    0x110(%rsp),%rdi
  669032:	00 
  669033:	44 89 fe             	mov    %r15d,%esi
  669036:	e8 65 3a 00 00       	call   66caa0 <<gpui_canvas::text::planner::Cmap>::glyph_index>
  66903b:	66 85 d2             	test   %dx,%dx
  66903e:	0f 95 c1             	setne  %cl
  669041:	20 c1                	and    %al,%cl
  669043:	00 c9                	add    %cl,%cl
  669045:	0a 4c 24 60          	or     0x60(%rsp),%cl
  669049:	0f 84 d7 00 00 00    	je     669126 <<gpui_canvas::text::planner::Planner>::shape+0x456>
  66904f:	44 8b 7c 24 30       	mov    0x30(%rsp),%r15d
  669054:	41 08 cf             	or     %cl,%r15b
  669057:	4c 8b a4 24 b0 01 00 	mov    0x1b0(%rsp),%r12
  66905e:	00 
  66905f:	4d 39 e6             	cmp    %r12,%r14
  669062:	48 89 de             	mov    %rbx,%rsi
  669065:	4c 89 ef             	mov    %r13,%rdi
  669068:	49 89 e8             	mov    %rbp,%r8
  66906b:	0f 85 25 fd ff ff    	jne    668d96 <<gpui_canvas::text::planner::Planner>::shape+0xc6>
  669071:	eb 05                	jmp    669078 <<gpui_canvas::text::planner::Planner>::shape+0x3a8>
  669073:	44 8b 7c 24 30       	mov    0x30(%rsp),%r15d
  669078:	41 f6 c7 01          	test   $0x1,%r15b
  66907c:	4c 8b 2c 24          	mov    (%rsp),%r13
  669080:	0f 84 c5 00 00 00    	je     66914b <<gpui_canvas::text::planner::Planner>::shape+0x47b>
  669086:	49 83 bd 48 0a 00 00 	cmpq   $0x0,0xa48(%r13)
  66908d:	00 
  66908e:	0f 85 b7 00 00 00    	jne    66914b <<gpui_canvas::text::planner::Planner>::shape+0x47b>
  669094:	48 8d 35 8d 3c 12 00 	lea    0x123c8d(%rip),%rsi        # 78cd28 <gpui_canvas::text::ARABIC_FONT>
  66909b:	48 8d 15 5a ca 9b ff 	lea    -0x6435a6(%rip),%rdx        # 25afc <gpui_canvas::text::ARABIC_BYTES>
  6690a2:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  6690a9:	00 
  6690aa:	b9 48 ab 03 00       	mov    $0x3ab48,%ecx
  6690af:	45 31 c0             	xor    %r8d,%r8d
  6690b2:	e8 29 ae ff ff       	call   663ee0 <<gpui_canvas::text::FontFace>::shared_static>
  6690b7:	83 bc 24 10 07 00 00 	cmpl   $0x1,0x710(%rsp)
  6690be:	01 
  6690bf:	75 1a                	jne    6690db <<gpui_canvas::text::planner::Planner>::shape+0x40b>
  6690c1:	44 8b a4 24 14 07 00 	mov    0x714(%rsp),%r12d
  6690c8:	00 
  6690c9:	44 8b bc 24 18 07 00 	mov    0x718(%rsp),%r15d
  6690d0:	00 
  6690d1:	eb 53                	jmp    669126 <<gpui_canvas::text::planner::Planner>::shape+0x456>
  6690d3:	45 31 ff             	xor    %r15d,%r15d
  6690d6:	e9 84 00 00 00       	jmp    66915f <<gpui_canvas::text::planner::Planner>::shape+0x48f>
  6690db:	44 89 fd             	mov    %r15d,%ebp
  6690de:	49 8d 9d 48 0a 00 00 	lea    0xa48(%r13),%rbx
  6690e5:	4c 8b bc 24 18 07 00 	mov    0x718(%rsp),%r15
  6690ec:	00 
  6690ed:	48 8b 03             	mov    (%rbx),%rax
  6690f0:	48 85 c0             	test   %rax,%rax
  6690f3:	74 0f                	je     669104 <<gpui_canvas::text::planner::Planner>::shape+0x434>
  6690f5:	f0 48 ff 08          	lock decq (%rax)
  6690f9:	75 09                	jne    669104 <<gpui_canvas::text::planner::Planner>::shape+0x434>
  6690fb:	48 89 df             	mov    %rbx,%rdi
  6690fe:	ff 15 0c 0c 12 00    	call   *0x120c0c(%rip)        # 789d10 <_DYNAMIC+0x260>
  669104:	4d 89 bd 48 0a 00 00 	mov    %r15,0xa48(%r13)
  66910b:	be 01 00 00 00       	mov    $0x1,%esi
  669110:	4c 89 ef             	mov    %r13,%rdi
  669113:	e8 88 36 00 00       	call   66c7a0 <<gpui_canvas::text::planner::Planner>::register>
  669118:	83 f8 ff             	cmp    $0xffffffff,%eax
  66911b:	41 89 ef             	mov    %ebp,%r15d
  66911e:	74 2b                	je     66914b <<gpui_canvas::text::planner::Planner>::shape+0x47b>
  669120:	41 89 c4             	mov    %eax,%r12d
  669123:	45 31 ff             	xor    %r15d,%r15d
  669126:	44 89 a4 24 90 00 00 	mov    %r12d,0x90(%rsp)
  66912d:	00 
  66912e:	44 89 bc 24 94 00 00 	mov    %r15d,0x94(%rsp)
  669135:	00 
  669136:	48 c7 84 24 88 00 00 	movq   $0xffffffffffffffff,0x88(%rsp)
  66913d:	00 ff ff ff ff 
  669142:	4c 8b 2c 24          	mov    (%rsp),%r13
  669146:	e9 a6 28 00 00       	jmp    66b9f1 <<gpui_canvas::text::planner::Planner>::shape+0x2d21>
  66914b:	41 f6 c7 02          	test   $0x2,%r15b
  66914f:	74 0e                	je     66915f <<gpui_canvas::text::planner::Planner>::shape+0x48f>
  669151:	49 83 bd 50 0a 00 00 	cmpq   $0x0,0xa50(%r13)
  669158:	00 
  669159:	0f 84 2f 2a 00 00    	je     66bb8e <<gpui_canvas::text::planner::Planner>::shape+0x2ebe>
  66915f:	48 c7 84 24 a0 02 00 	movq   $0xffffffffffffffff,0x2a0(%rsp)
  669166:	00 ff ff ff ff 
  66916b:	48 8d 05 fc 23 bf ff 	lea    -0x40dc04(%rip),%rax        # 25b56e <gpui_canvas::text::PRIMARY_BYTES+0x1f4616>
  669172:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
  669179:	00 
  66917a:	48 c7 84 24 b0 02 00 	movq   $0xc,0x2b0(%rsp)
  669181:	00 0c 00 00 00 
  669186:	48 c7 84 24 b8 02 00 	movq   $0xffffffffffffffff,0x2b8(%rsp)
  66918d:	00 ff ff ff ff 
  669192:	48 8d 05 e1 23 bf ff 	lea    -0x40dc1f(%rip),%rax        # 25b57a <gpui_canvas::text::PRIMARY_BYTES+0x1f4622>
  669199:	48 89 84 24 c0 02 00 	mov    %rax,0x2c0(%rsp)
  6691a0:	00 
  6691a1:	48 c7 84 24 c8 02 00 	movq   $0x11,0x2c8(%rsp)
  6691a8:	00 11 00 00 00 
  6691ad:	48 c7 84 24 d0 02 00 	movq   $0xffffffffffffffff,0x2d0(%rsp)
  6691b4:	00 ff ff ff ff 
  6691b9:	48 8d 1d cb 23 bf ff 	lea    -0x40dc35(%rip),%rbx        # 25b58b <gpui_canvas::text::PRIMARY_BYTES+0x1f4633>
  6691c0:	48 89 9c 24 d8 02 00 	mov    %rbx,0x2d8(%rsp)
  6691c7:	00 
  6691c8:	48 c7 84 24 e0 02 00 	movq   $0x11,0x2e0(%rsp)
  6691cf:	00 11 00 00 00 
  6691d4:	41 f6 c7 01          	test   $0x1,%r15b
  6691d8:	75 1d                	jne    6691f7 <<gpui_canvas::text::planner::Planner>::shape+0x527>
  6691da:	4c 8d b4 24 b8 02 00 	lea    0x2b8(%rsp),%r14
  6691e1:	00 
  6691e2:	b8 01 00 00 00       	mov    $0x1,%eax
  6691e7:	48 89 84 24 10 02 00 	mov    %rax,0x210(%rsp)
  6691ee:	00 
  6691ef:	41 f6 c7 02          	test   $0x2,%r15b
  6691f3:	75 25                	jne    66921a <<gpui_canvas::text::planner::Planner>::shape+0x54a>
  6691f5:	eb 5b                	jmp    669252 <<gpui_canvas::text::planner::Planner>::shape+0x582>
  6691f7:	4c 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%r14
  6691fe:	00 
  6691ff:	48 89 84 24 c0 02 00 	mov    %rax,0x2c0(%rsp)
  669206:	00 
  669207:	b8 02 00 00 00       	mov    $0x2,%eax
  66920c:	48 89 84 24 10 02 00 	mov    %rax,0x210(%rsp)
  669213:	00 
  669214:	41 f6 c7 02          	test   $0x2,%r15b
  669218:	74 38                	je     669252 <<gpui_canvas::text::planner::Planner>::shape+0x582>
  66921a:	49 8b 36             	mov    (%r14),%rsi
  66921d:	48 83 fe fd          	cmp    $0xfffffffffffffffd,%rsi
  669221:	77 14                	ja     669237 <<gpui_canvas::text::planner::Planner>::shape+0x567>
  669223:	48 85 f6             	test   %rsi,%rsi
  669226:	74 0f                	je     669237 <<gpui_canvas::text::planner::Planner>::shape+0x567>
  669228:	49 8b 7e 08          	mov    0x8(%r14),%rdi
  66922c:	ba 01 00 00 00       	mov    $0x1,%edx
  669231:	ff 15 b1 0a 12 00    	call   *0x120ab1(%rip)        # 789ce8 <_DYNAMIC+0x238>
  669237:	49 c7 06 ff ff ff ff 	movq   $0xffffffffffffffff,(%r14)
  66923e:	49 89 5e 08          	mov    %rbx,0x8(%r14)
  669242:	49 c7 46 10 11 00 00 	movq   $0x11,0x10(%r14)
  669249:	00 
  66924a:	48 ff 84 24 10 02 00 	incq   0x210(%rsp)
  669251:	00 
  669252:	48 c7 84 24 e8 00 00 	movq   $0x0,0xe8(%rsp)
  669259:	00 00 00 00 00 
  66925e:	48 c7 84 24 f0 00 00 	movq   $0x4,0xf0(%rsp)
  669265:	00 04 00 00 00 
  66926a:	48 c7 84 24 f8 00 00 	movq   $0x0,0xf8(%rsp)
  669271:	00 00 00 00 00 
  669276:	48 c7 84 24 50 01 00 	movq   $0xffffffffffffffff,0x150(%rsp)
  66927d:	00 ff ff ff ff 
  669282:	f6 84 24 c8 01 00 00 	testb  $0x1,0x1c8(%rsp)
  669289:	01 
  66928a:	75 11                	jne    66929d <<gpui_canvas::text::planner::Planner>::shape+0x5cd>
  66928c:	f3 0f 10 05 a8 45 9b 	movss  -0x64ba58(%rip),%xmm0        # 1d83c <GCC_except_table0+0x94>
  669293:	ff 
  669294:	f3 0f 11 84 24 cc 01 	movss  %xmm0,0x1cc(%rsp)
  66929b:	00 00 
  66929d:	49 8d 45 78          	lea    0x78(%r13),%rax
  6692a1:	48 89 84 24 30 03 00 	mov    %rax,0x330(%rsp)
  6692a8:	00 
  6692a9:	49 8d 85 38 06 00 00 	lea    0x638(%r13),%rax
  6692b0:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
  6692b7:	00 
  6692b8:	49 8d 85 c8 08 00 00 	lea    0x8c8(%r13),%rax
  6692bf:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  6692c4:	4c 8d ac 24 50 03 00 	lea    0x350(%rsp),%r13
  6692cb:	00 
  6692cc:	0f 57 c0             	xorps  %xmm0,%xmm0
  6692cf:	0f 29 84 24 80 02 00 	movaps %xmm0,0x280(%rsp)
  6692d6:	00 
  6692d7:	f3 0f 11 44 24 1c    	movss  %xmm0,0x1c(%rsp)
  6692dd:	f3 0f 11 44 24 7c    	movss  %xmm0,0x7c(%rsp)
  6692e3:	4c 8d a4 24 c8 04 00 	lea    0x4c8(%rsp),%r12
  6692ea:	00 
  6692eb:	48 8d 05 4e 5f 11 00 	lea    0x115f4e(%rip),%rax        # 77f240 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0x170>
  6692f2:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  6692f7:	48 8d 05 aa 65 11 00 	lea    0x1165aa(%rip),%rax        # 77f8a8 <anon.078e2e963a048095b6b8e4da3cd13e67.21.llvm.9964956014867501821>
  6692fe:	48 89 84 24 70 02 00 	mov    %rax,0x270(%rsp)
  669305:	00 
  669306:	48 c7 84 24 08 02 00 	movq   $0x0,0x208(%rsp)
  66930d:	00 00 00 00 00 
  669312:	31 d2                	xor    %edx,%edx
  669314:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  66931b:	00 
  66931c:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  669321:	31 c0                	xor    %eax,%eax
  669323:	be fe ff ff ff       	mov    $0xfffffffe,%esi
  669328:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
  66932d:	83 fe fe             	cmp    $0xfffffffe,%esi
  669330:	75 2e                	jne    669360 <<gpui_canvas::text::planner::Planner>::shape+0x690>
  669332:	4c 8b 4c 24 28       	mov    0x28(%rsp),%r9
  669337:	4c 3b 8c 24 b0 01 00 	cmp    0x1b0(%rsp),%r9
  66933e:	00 
  66933f:	74 33                	je     669374 <<gpui_canvas::text::planner::Planner>::shape+0x6a4>
  669341:	41 0f b6 09          	movzbl (%r9),%ecx
  669345:	84 c9                	test   %cl,%cl
  669347:	78 46                	js     66938f <<gpui_canvas::text::planner::Planner>::shape+0x6bf>
  669349:	49 8d 51 01          	lea    0x1(%r9),%rdx
  66934d:	e9 9a 00 00 00       	jmp    6693ec <<gpui_canvas::text::planner::Planner>::shape+0x71c>
  669352:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  669359:	1f 84 00 00 00 00 00 
  669360:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
  669365:	89 f1                	mov    %esi,%ecx
  669367:	4c 8b 84 24 10 03 00 	mov    0x310(%rsp),%r8
  66936e:	00 
  66936f:	e9 81 00 00 00       	jmp    6693f5 <<gpui_canvas::text::planner::Planner>::shape+0x725>
  669374:	c7 84 24 80 00 00 00 	movl   $0xfffffffe,0x80(%rsp)
  66937b:	fe ff ff ff 
  66937f:	b1 01                	mov    $0x1,%cl
  669381:	89 4c 24 4c          	mov    %ecx,0x4c(%rsp)
  669385:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
  66938a:	e9 d7 01 00 00       	jmp    669566 <<gpui_canvas::text::planner::Planner>::shape+0x896>
  66938f:	49 89 c0             	mov    %rax,%r8
  669392:	89 c8                	mov    %ecx,%eax
  669394:	83 e0 1f             	and    $0x1f,%eax
  669397:	41 0f b6 79 01       	movzbl 0x1(%r9),%edi
  66939c:	83 e7 3f             	and    $0x3f,%edi
  66939f:	80 f9 e0             	cmp    $0xe0,%cl
  6693a2:	72 2d                	jb     6693d1 <<gpui_canvas::text::planner::Planner>::shape+0x701>
  6693a4:	41 0f b6 71 02       	movzbl 0x2(%r9),%esi
  6693a9:	c1 e7 06             	shl    $0x6,%edi
  6693ac:	83 e6 3f             	and    $0x3f,%esi
  6693af:	09 fe                	or     %edi,%esi
  6693b1:	80 f9 f0             	cmp    $0xf0,%cl
  6693b4:	72 28                	jb     6693de <<gpui_canvas::text::planner::Planner>::shape+0x70e>
  6693b6:	49 8d 51 04          	lea    0x4(%r9),%rdx
  6693ba:	41 0f b6 49 03       	movzbl 0x3(%r9),%ecx
  6693bf:	83 e0 07             	and    $0x7,%eax
  6693c2:	c1 e0 12             	shl    $0x12,%eax
  6693c5:	c1 e6 06             	shl    $0x6,%esi
  6693c8:	83 e1 3f             	and    $0x3f,%ecx
  6693cb:	09 f1                	or     %esi,%ecx
  6693cd:	09 c1                	or     %eax,%ecx
  6693cf:	eb 18                	jmp    6693e9 <<gpui_canvas::text::planner::Planner>::shape+0x719>
  6693d1:	49 8d 51 02          	lea    0x2(%r9),%rdx
  6693d5:	c1 e0 06             	shl    $0x6,%eax
  6693d8:	09 f8                	or     %edi,%eax
  6693da:	89 c1                	mov    %eax,%ecx
  6693dc:	eb 0b                	jmp    6693e9 <<gpui_canvas::text::planner::Planner>::shape+0x719>
  6693de:	49 8d 51 03          	lea    0x3(%r9),%rdx
  6693e2:	c1 e0 0c             	shl    $0xc,%eax
  6693e5:	09 c6                	or     %eax,%esi
  6693e7:	89 f1                	mov    %esi,%ecx
  6693e9:	4c 89 c0             	mov    %r8,%rax
  6693ec:	49 89 c0             	mov    %rax,%r8
  6693ef:	4c 29 c8             	sub    %r9,%rax
  6693f2:	48 01 d0             	add    %rdx,%rax
  6693f5:	c7 84 24 80 00 00 00 	movl   $0xfffffffe,0x80(%rsp)
  6693fc:	fe ff ff ff 
  669400:	40 b6 01             	mov    $0x1,%sil
  669403:	89 74 24 4c          	mov    %esi,0x4c(%rsp)
  669407:	83 f9 0c             	cmp    $0xc,%ecx
  66940a:	7e 24                	jle    669430 <<gpui_canvas::text::planner::Planner>::shape+0x760>
  66940c:	83 f9 0d             	cmp    $0xd,%ecx
  66940f:	0f 84 5b 01 00 00    	je     669570 <<gpui_canvas::text::planner::Planner>::shape+0x8a0>
  669415:	81 f9 85 00 00 00    	cmp    $0x85,%ecx
  66941b:	74 21                	je     66943e <<gpui_canvas::text::planner::Planner>::shape+0x76e>
  66941d:	81 f9 29 20 00 00    	cmp    $0x2029,%ecx
  669423:	74 19                	je     66943e <<gpui_canvas::text::planner::Planner>::shape+0x76e>
  669425:	e9 83 00 00 00       	jmp    6694ad <<gpui_canvas::text::planner::Planner>::shape+0x7dd>
  66942a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  669430:	83 f9 ff             	cmp    $0xffffffff,%ecx
  669433:	0f 84 23 01 00 00    	je     66955c <<gpui_canvas::text::planner::Planner>::shape+0x88c>
  669439:	83 f9 0a             	cmp    $0xa,%ecx
  66943c:	75 6f                	jne    6694ad <<gpui_canvas::text::planner::Planner>::shape+0x7dd>
  66943e:	48 89 54 24 28       	mov    %rdx,0x28(%rsp)
  669443:	81 f9 80 00 00 00    	cmp    $0x80,%ecx
  669449:	0f 83 32 01 00 00    	jae    669581 <<gpui_canvas::text::planner::Planner>::shape+0x8b1>
  66944f:	49 8d 70 01          	lea    0x1(%r8),%rsi
  669453:	83 f9 0d             	cmp    $0xd,%ecx
  669456:	0f 85 37 01 00 00    	jne    669593 <<gpui_canvas::text::planner::Planner>::shape+0x8c3>
  66945c:	4c 8b 4c 24 28       	mov    0x28(%rsp),%r9
  669461:	4c 3b 8c 24 b0 01 00 	cmp    0x1b0(%rsp),%r9
  669468:	00 
  669469:	0f 84 68 23 00 00    	je     66b7d7 <<gpui_canvas::text::planner::Planner>::shape+0x2b07>
  66946f:	45 0f b6 11          	movzbl (%r9),%r10d
  669473:	49 89 f3             	mov    %rsi,%r11
  669476:	45 84 d2             	test   %r10b,%r10b
  669479:	0f 88 68 23 00 00    	js     66b7e7 <<gpui_canvas::text::planner::Planner>::shape+0x2b17>
  66947f:	49 8d 59 01          	lea    0x1(%r9),%rbx
  669483:	e9 be 23 00 00       	jmp    66b846 <<gpui_canvas::text::planner::Planner>::shape+0x2b76>
  669488:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  66948f:	00 
  669490:	81 f9 29 20 00 00    	cmp    $0x2029,%ecx
  669496:	0f 84 d9 00 00 00    	je     669575 <<gpui_canvas::text::planner::Planner>::shape+0x8a5>
  66949c:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
  6694a1:	81 f9 85 00 00 00    	cmp    $0x85,%ecx
  6694a7:	0f 84 c8 00 00 00    	je     669575 <<gpui_canvas::text::planner::Planner>::shape+0x8a5>
  6694ad:	48 3b 94 24 b0 01 00 	cmp    0x1b0(%rsp),%rdx
  6694b4:	00 
  6694b5:	0f 84 a1 00 00 00    	je     66955c <<gpui_canvas::text::planner::Planner>::shape+0x88c>
  6694bb:	49 89 c0             	mov    %rax,%r8
  6694be:	0f b6 0a             	movzbl (%rdx),%ecx
  6694c1:	84 c9                	test   %cl,%cl
  6694c3:	78 0b                	js     6694d0 <<gpui_canvas::text::planner::Planner>::shape+0x800>
  6694c5:	48 8d 42 01          	lea    0x1(%rdx),%rax
  6694c9:	eb 65                	jmp    669530 <<gpui_canvas::text::planner::Planner>::shape+0x860>
  6694cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6694d0:	89 c8                	mov    %ecx,%eax
  6694d2:	83 e0 1f             	and    $0x1f,%eax
  6694d5:	0f b6 7a 01          	movzbl 0x1(%rdx),%edi
  6694d9:	83 e7 3f             	and    $0x3f,%edi
  6694dc:	80 f9 df             	cmp    $0xdf,%cl
  6694df:	76 2e                	jbe    66950f <<gpui_canvas::text::planner::Planner>::shape+0x83f>
  6694e1:	0f b6 72 02          	movzbl 0x2(%rdx),%esi
  6694e5:	c1 e7 06             	shl    $0x6,%edi
  6694e8:	83 e6 3f             	and    $0x3f,%esi
  6694eb:	09 fe                	or     %edi,%esi
  6694ed:	80 f9 f0             	cmp    $0xf0,%cl
  6694f0:	72 2d                	jb     66951f <<gpui_canvas::text::planner::Planner>::shape+0x84f>
  6694f2:	48 8d 7a 04          	lea    0x4(%rdx),%rdi
  6694f6:	0f b6 4a 03          	movzbl 0x3(%rdx),%ecx
  6694fa:	83 e0 07             	and    $0x7,%eax
  6694fd:	c1 e0 12             	shl    $0x12,%eax
  669500:	c1 e6 06             	shl    $0x6,%esi
  669503:	83 e1 3f             	and    $0x3f,%ecx
  669506:	09 f1                	or     %esi,%ecx
  669508:	09 c1                	or     %eax,%ecx
  66950a:	48 89 f8             	mov    %rdi,%rax
  66950d:	eb 21                	jmp    669530 <<gpui_canvas::text::planner::Planner>::shape+0x860>
  66950f:	48 8d 72 02          	lea    0x2(%rdx),%rsi
  669513:	c1 e0 06             	shl    $0x6,%eax
  669516:	09 f8                	or     %edi,%eax
  669518:	89 c1                	mov    %eax,%ecx
  66951a:	48 89 f0             	mov    %rsi,%rax
  66951d:	eb 11                	jmp    669530 <<gpui_canvas::text::planner::Planner>::shape+0x860>
  66951f:	48 8d 4a 03          	lea    0x3(%rdx),%rcx
  669523:	c1 e0 0c             	shl    $0xc,%eax
  669526:	09 c6                	or     %eax,%esi
  669528:	48 89 c8             	mov    %rcx,%rax
  66952b:	89 f1                	mov    %esi,%ecx
  66952d:	0f 1f 00             	nopl   (%rax)
  669530:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  669535:	48 29 d0             	sub    %rdx,%rax
  669538:	4c 01 c0             	add    %r8,%rax
  66953b:	81 f9 84 00 00 00    	cmp    $0x84,%ecx
  669541:	0f 8f 49 ff ff ff    	jg     669490 <<gpui_canvas::text::planner::Planner>::shape+0x7c0>
  669547:	83 f9 0a             	cmp    $0xa,%ecx
  66954a:	74 29                	je     669575 <<gpui_canvas::text::planner::Planner>::shape+0x8a5>
  66954c:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
  669551:	83 f9 0d             	cmp    $0xd,%ecx
  669554:	0f 85 53 ff ff ff    	jne    6694ad <<gpui_canvas::text::planner::Planner>::shape+0x7dd>
  66955a:	eb 19                	jmp    669575 <<gpui_canvas::text::planner::Planner>::shape+0x8a5>
  66955c:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
  669561:	48 89 54 24 28       	mov    %rdx,0x28(%rsp)
  669566:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  66956b:	48 89 fe             	mov    %rdi,%rsi
  66956e:	eb 33                	jmp    6695a3 <<gpui_canvas::text::planner::Planner>::shape+0x8d3>
  669570:	48 89 54 24 28       	mov    %rdx,0x28(%rsp)
  669575:	81 f9 80 00 00 00    	cmp    $0x80,%ecx
  66957b:	0f 82 ce fe ff ff    	jb     66944f <<gpui_canvas::text::planner::Planner>::shape+0x77f>
  669581:	81 f9 00 08 00 00    	cmp    $0x800,%ecx
  669587:	be 03 00 00 00       	mov    $0x3,%esi
  66958c:	48 83 de 00          	sbb    $0x0,%rsi
  669590:	4c 01 c6             	add    %r8,%rsi
  669593:	c7 44 24 4c 00 00 00 	movl   $0x0,0x4c(%rsp)
  66959a:	00 
  66959b:	4c 89 c1             	mov    %r8,%rcx
  66959e:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  6695a3:	48 89 ca             	mov    %rcx,%rdx
  6695a6:	48 29 fa             	sub    %rdi,%rdx
  6695a9:	48 89 94 24 10 01 00 	mov    %rdx,0x110(%rsp)
  6695b0:	00 
  6695b1:	0f 82 98 2c 00 00    	jb     66c24f <<gpui_canvas::text::planner::Planner>::shape+0x357f>
  6695b7:	48 83 7c 24 30 00    	cmpq   $0x0,0x30(%rsp)
  6695bd:	48 89 84 24 20 03 00 	mov    %rax,0x320(%rsp)
  6695c4:	00 
  6695c5:	74 2f                	je     6695f6 <<gpui_canvas::text::planner::Planner>::shape+0x926>
  6695c7:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
  6695cc:	48 3b 54 24 50       	cmp    0x50(%rsp),%rdx
  6695d1:	73 1d                	jae    6695f0 <<gpui_canvas::text::planner::Planner>::shape+0x920>
  6695d3:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  6695da:	00 
  6695db:	80 3c 10 bf          	cmpb   $0xbf,(%rax,%rdx,1)
  6695df:	7f 15                	jg     6695f6 <<gpui_canvas::text::planner::Planner>::shape+0x926>
  6695e1:	e9 69 2c 00 00       	jmp    66c24f <<gpui_canvas::text::planner::Planner>::shape+0x357f>
  6695e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  6695ed:	00 00 00 
  6695f0:	0f 85 59 2c 00 00    	jne    66c24f <<gpui_canvas::text::planner::Planner>::shape+0x357f>
  6695f6:	48 85 c9             	test   %rcx,%rcx
  6695f9:	74 2b                	je     669626 <<gpui_canvas::text::planner::Planner>::shape+0x956>
  6695fb:	48 3b 4c 24 50       	cmp    0x50(%rsp),%rcx
  669600:	73 1e                	jae    669620 <<gpui_canvas::text::planner::Planner>::shape+0x950>
  669602:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  669609:	00 
  66960a:	80 3c 08 c0          	cmpb   $0xc0,(%rax,%rcx,1)
  66960e:	7d 16                	jge    669626 <<gpui_canvas::text::planner::Planner>::shape+0x956>
  669610:	e9 3a 2c 00 00       	jmp    66c24f <<gpui_canvas::text::planner::Planner>::shape+0x357f>
  669615:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  66961c:	00 00 00 00 
  669620:	0f 85 29 2c 00 00    	jne    66c24f <<gpui_canvas::text::planner::Planner>::shape+0x357f>
  669626:	48 89 8c 24 00 01 00 	mov    %rcx,0x100(%rsp)
  66962d:	00 
  66962e:	48 89 b4 24 18 03 00 	mov    %rsi,0x318(%rsp)
  669635:	00 
  669636:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  66963d:	00 
  66963e:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  669643:	48 01 c1             	add    %rax,%rcx
  669646:	48 8d bc 24 98 04 00 	lea    0x498(%rsp),%rdi
  66964d:	00 
  66964e:	48 8b b4 24 30 03 00 	mov    0x330(%rsp),%rsi
  669655:	00 
  669656:	48 8b 94 24 28 03 00 	mov    0x328(%rsp),%rdx
  66965d:	00 
  66965e:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  669663:	4c 8b 84 24 10 01 00 	mov    0x110(%rsp),%r8
  66966a:	00 
  66966b:	f3 0f 10 05 59 41 9b 	movss  -0x64bea7(%rip),%xmm0        # 1d7cc <GCC_except_table0+0x24>
  669672:	ff 
  669673:	45 31 c9             	xor    %r9d,%r9d
  669676:	e8 b5 ad ff ff       	call   664430 <<parley::context::LayoutContext<()>>::ranged_builder>
  66967b:	48 8d bc 24 98 04 00 	lea    0x498(%rsp),%rdi
  669682:	00 
  669683:	48 8d b4 24 a0 02 00 	lea    0x2a0(%rsp),%rsi
  66968a:	00 
  66968b:	48 8b 94 24 10 02 00 	mov    0x210(%rsp),%rdx
  669692:	00 
  669693:	e8 48 6b 00 00       	call   6701e0 <<parley::builder::RangedBuilder<()>>::push_default::<&[parlance::font_family::FontFamilyName]>>
  669698:	4c 8b bc 24 98 04 00 	mov    0x498(%rsp),%r15
  66969f:	00 
  6696a0:	48 8b 9c 24 a0 04 00 	mov    0x4a0(%rsp),%rbx
  6696a7:	00 
  6696a8:	49 8d b7 30 02 00 00 	lea    0x230(%r15),%rsi
  6696af:	c6 84 24 10 07 00 00 	movb   $0x1,0x710(%rsp)
  6696b6:	01 
  6696b7:	f3 0f 10 84 24 84 00 	movss  0x84(%rsp),%xmm0
  6696be:	00 00 
  6696c0:	f3 0f 11 84 24 14 07 	movss  %xmm0,0x714(%rsp)
  6696c7:	00 00 
  6696c9:	f3 0f 10 84 24 b8 04 	movss  0x4b8(%rsp),%xmm0
  6696d0:	00 00 
  6696d2:	48 8d bc 24 c0 04 00 	lea    0x4c0(%rsp),%rdi
  6696d9:	00 
  6696da:	48 89 f5             	mov    %rsi,%rbp
  6696dd:	48 89 da             	mov    %rbx,%rdx
  6696e0:	4c 8d b4 24 10 07 00 	lea    0x710(%rsp),%r14
  6696e7:	00 
  6696e8:	4c 89 f1             	mov    %r14,%rcx
  6696eb:	f3 0f 11 44 24 60    	movss  %xmm0,0x60(%rsp)
  6696f1:	e8 6a be ff ff       	call   665560 <<parley::resolve::ResolveContext>::resolve_property::<()>>
  6696f6:	4c 89 f7             	mov    %r14,%rdi
  6696f9:	e8 92 6b 00 00       	call   670290 <core::ptr::drop_glue::<parley::style::StyleProperty<()>>>
  6696fe:	49 83 bf 20 05 00 00 	cmpq   $0xffffffffffffffff,0x520(%r15)
  669705:	ff 
  669706:	0f 84 7e 27 00 00    	je     66be8a <<gpui_canvas::text::planner::Planner>::shape+0x31ba>
  66970c:	4d 8d b7 98 04 00 00 	lea    0x498(%r15),%r14
  669713:	4c 89 f7             	mov    %r14,%rdi
  669716:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
  66971d:	00 
  66971e:	e8 dd c3 ff ff       	call   665b00 <<parley::resolve::ResolvedStyle<()>>::apply>
  669723:	66 c7 84 24 10 07 00 	movw   $0x117,0x710(%rsp)
  66972a:	00 17 01 
  66972d:	48 8d bc 24 c0 04 00 	lea    0x4c0(%rsp),%rdi
  669734:	00 
  669735:	48 89 ee             	mov    %rbp,%rsi
  669738:	48 89 da             	mov    %rbx,%rdx
  66973b:	48 8d 9c 24 10 07 00 	lea    0x710(%rsp),%rbx
  669742:	00 
  669743:	48 89 d9             	mov    %rbx,%rcx
  669746:	f3 0f 10 44 24 60    	movss  0x60(%rsp),%xmm0
  66974c:	e8 0f be ff ff       	call   665560 <<parley::resolve::ResolveContext>::resolve_property::<()>>
  669751:	48 89 df             	mov    %rbx,%rdi
  669754:	e8 37 6b 00 00       	call   670290 <core::ptr::drop_glue::<parley::style::StyleProperty<()>>>
  669759:	49 83 bf 20 05 00 00 	cmpq   $0xffffffffffffffff,0x520(%r15)
  669760:	ff 
  669761:	0f 84 23 27 00 00    	je     66be8a <<gpui_canvas::text::planner::Planner>::shape+0x31ba>
  669767:	4c 89 f7             	mov    %r14,%rdi
  66976a:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
  669771:	00 
  669772:	e8 89 c3 ff ff       	call   665b00 <<parley::resolve::ResolvedStyle<()>>::apply>
  669777:	48 8d bc 24 98 04 00 	lea    0x498(%rsp),%rdi
  66977e:	00 
  66977f:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  669784:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  669789:	48 8b 8c 24 10 01 00 	mov    0x110(%rsp),%rcx
  669790:	00 
  669791:	e8 ba 63 00 00       	call   66fb50 <<parley::builder::RangedBuilder<()>>::build_into::<&str>>
  669796:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  66979d:	00 
  66979e:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  6697a3:	e8 78 9e 01 00       	call   683620 <<parley::layout::line_break::BreakLines<()>>::new>
  6697a8:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  6697af:	00 
  6697b0:	f3 0f 10 84 24 cc 01 	movss  0x1cc(%rsp),%xmm0
  6697b7:	00 00 
  6697b9:	e8 42 8f 01 00       	call   682700 <<parley::layout::line_break::BreakLines<()>>::break_remaining>
  6697be:	80 bc 24 2c 02 00 00 	cmpb   $0x0,0x22c(%rsp)
  6697c5:	00 
  6697c6:	74 18                	je     6697e0 <<gpui_canvas::text::planner::Planner>::shape+0xb10>
  6697c8:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  6697cf:	00 ff 
  6697d1:	0f 85 fc 01 00 00    	jne    6699d3 <<gpui_canvas::text::planner::Planner>::shape+0xd03>
  6697d7:	31 c0                	xor    %eax,%eax
  6697d9:	e9 78 01 00 00       	jmp    669956 <<gpui_canvas::text::planner::Planner>::shape+0xc86>
  6697de:	66 90                	xchg   %ax,%ax
  6697e0:	48 83 7c 24 30 00    	cmpq   $0x0,0x30(%rsp)
  6697e6:	48 8b 84 24 00 01 00 	mov    0x100(%rsp),%rax
  6697ed:	00 
  6697ee:	0f 85 4c 01 00 00    	jne    669940 <<gpui_canvas::text::planner::Planner>::shape+0xc70>
  6697f4:	48 3b 44 24 50       	cmp    0x50(%rsp),%rax
  6697f9:	0f 85 41 01 00 00    	jne    669940 <<gpui_canvas::text::planner::Planner>::shape+0xc70>
  6697ff:	48 8b 04 24          	mov    (%rsp),%rax
  669803:	48 83 b8 e0 09 00 00 	cmpq   $0x1,0x9e0(%rax)
  66980a:	01 
  66980b:	0f 85 2f 01 00 00    	jne    669940 <<gpui_canvas::text::planner::Planner>::shape+0xc70>
  669811:	48 8b 14 24          	mov    (%rsp),%rdx
  669815:	48 8b 82 d8 09 00 00 	mov    0x9d8(%rdx),%rax
  66981c:	48 8d 48 70          	lea    0x70(%rax),%rcx
  669820:	48 89 8c 24 18 07 00 	mov    %rcx,0x718(%rsp)
  669827:	00 
  669828:	48 c7 84 24 20 07 00 	movq   $0x0,0x720(%rsp)
  66982f:	00 00 00 00 00 
  669834:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  669839:	48 89 b4 24 28 07 00 	mov    %rsi,0x728(%rsp)
  669840:	00 
  669841:	48 c7 84 24 58 07 00 	movq   $0x0,0x758(%rsp)
  669848:	00 00 00 00 00 
  66984d:	48 89 94 24 c0 04 00 	mov    %rdx,0x4c0(%rsp)
  669854:	00 
  669855:	48 89 8c 24 10 07 00 	mov    %rcx,0x710(%rsp)
  66985c:	00 
  66985d:	48 8b 78 10          	mov    0x10(%rax),%rdi
  669861:	48 8b 70 18          	mov    0x18(%rax),%rsi
  669865:	48 8b 92 f8 09 00 00 	mov    0x9f8(%rdx),%rdx
  66986c:	48 39 fe             	cmp    %rdi,%rsi
  66986f:	0f 82 91 29 00 00    	jb     66c206 <<gpui_canvas::text::planner::Planner>::shape+0x3536>
  669875:	48 39 d6             	cmp    %rdx,%rsi
  669878:	0f 87 88 29 00 00    	ja     66c206 <<gpui_canvas::text::planner::Planner>::shape+0x3536>
  66987e:	48 8b 04 24          	mov    (%rsp),%rax
  669882:	48 8b 80 f0 09 00 00 	mov    0x9f0(%rax),%rax
  669889:	48 8d 0c bf          	lea    (%rdi,%rdi,4),%rcx
  66988d:	48 8d 0c c8          	lea    (%rax,%rcx,8),%rcx
  669891:	48 8d 14 b6          	lea    (%rsi,%rsi,4),%rdx
  669895:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
  669899:	48 89 8c 24 30 07 00 	mov    %rcx,0x730(%rsp)
  6698a0:	00 
  6698a1:	48 89 84 24 38 07 00 	mov    %rax,0x738(%rsp)
  6698a8:	00 
  6698a9:	48 c7 84 24 40 07 00 	movq   $0x0,0x740(%rsp)
  6698b0:	00 00 00 00 00 
  6698b5:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  6698ba:	48 89 84 24 48 07 00 	mov    %rax,0x748(%rsp)
  6698c1:	00 
  6698c2:	c7 84 24 50 07 00 00 	movl   $0x0,0x750(%rsp)
  6698c9:	00 00 00 00 
  6698cd:	48 8d bc 24 30 07 00 	lea    0x730(%rsp),%rdi
  6698d4:	00 
  6698d5:	48 8d 94 24 c0 04 00 	lea    0x4c0(%rsp),%rdx
  6698dc:	00 
  6698dd:	e8 1e af 01 00       	call   684800 <<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}> as core::iter::traits::iterator::Iterator>::try_fold::<(), core::iter::adapters::filter_map::filter_map_try_fold<parley::layout::line::LineItem<()>, parley::layout::run::Run<()>, (), core::ops::control_flow::ControlFlow<()>, <parley::layout::line::Line<()>>::runs::{closure#0}, &mut core::iter::traits::iterator::Iterator::all::check<parley::layout::run::Run<()>, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#2}>::{closure#0}>::{closure#0}, core::ops::control_flow::ControlFlow<()>>>
  6698e2:	48 c7 84 24 20 07 00 	movq   $0x1,0x720(%rsp)
  6698e9:	00 01 00 00 00 
  6698ee:	84 c0                	test   %al,%al
  6698f0:	75 4e                	jne    669940 <<gpui_canvas::text::planner::Planner>::shape+0xc70>
  6698f2:	48 c7 84 24 30 07 00 	movq   $0x0,0x730(%rsp)
  6698f9:	00 00 00 00 00 
  6698fe:	48 83 bc 24 58 07 00 	cmpq   $0x0,0x758(%rsp)
  669905:	00 00 
  669907:	0f 84 4f 1e 00 00    	je     66b75c <<gpui_canvas::text::planner::Planner>::shape+0x2a8c>
  66990d:	48 8d bc 24 58 07 00 	lea    0x758(%rsp),%rdi
  669914:	00 
  669915:	48 8d b4 24 80 07 00 	lea    0x780(%rsp),%rsi
  66991c:	00 
  66991d:	48 8d 94 24 c0 04 00 	lea    0x4c0(%rsp),%rdx
  669924:	00 
  669925:	e8 d6 ae 01 00       	call   684800 <<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}> as core::iter::traits::iterator::Iterator>::try_fold::<(), core::iter::adapters::filter_map::filter_map_try_fold<parley::layout::line::LineItem<()>, parley::layout::run::Run<()>, (), core::ops::control_flow::ControlFlow<()>, <parley::layout::line::Line<()>>::runs::{closure#0}, &mut core::iter::traits::iterator::Iterator::all::check<parley::layout::run::Run<()>, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#2}>::{closure#0}>::{closure#0}, core::ops::control_flow::ControlFlow<()>>>
  66992a:	84 c0                	test   %al,%al
  66992c:	0f 84 2a 1e 00 00    	je     66b75c <<gpui_canvas::text::planner::Planner>::shape+0x2a8c>
  669932:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  669939:	1f 84 00 00 00 00 00 
  669940:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  669947:	00 ff 
  669949:	0f 85 84 00 00 00    	jne    6699d3 <<gpui_canvas::text::planner::Planner>::shape+0xd03>
  66994f:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
  669956:	48 c7 84 24 50 01 00 	movq   $0x0,0x150(%rsp)
  66995d:	00 00 00 00 00 
  669962:	48 c7 84 24 58 01 00 	movq   $0x4,0x158(%rsp)
  669969:	00 04 00 00 00 
  66996e:	48 8d 8c 24 58 01 00 	lea    0x158(%rsp),%rcx
  669975:	00 
  669976:	0f 57 c0             	xorps  %xmm0,%xmm0
  669979:	0f 11 41 08          	movups %xmm0,0x8(%rcx)
  66997d:	48 c7 84 24 70 01 00 	movq   $0x4,0x170(%rsp)
  669984:	00 04 00 00 00 
  669989:	48 c7 84 24 78 01 00 	movq   $0x0,0x178(%rsp)
  669990:	00 00 00 00 00 
  669995:	48 89 84 24 80 01 00 	mov    %rax,0x180(%rsp)
  66999c:	00 
  66999d:	48 c7 84 24 88 01 00 	movq   $0x4,0x188(%rsp)
  6699a4:	00 04 00 00 00 
  6699a9:	48 c7 84 24 90 01 00 	movq   $0x0,0x190(%rsp)
  6699b0:	00 00 00 00 00 
  6699b5:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  6699ba:	89 84 24 98 01 00 00 	mov    %eax,0x198(%rsp)
  6699c1:	f3 0f 10 84 24 84 00 	movss  0x84(%rsp),%xmm0
  6699c8:	00 00 
  6699ca:	f3 0f 11 84 24 9c 01 	movss  %xmm0,0x19c(%rsp)
  6699d1:	00 00 
  6699d3:	48 8b 04 24          	mov    (%rsp),%rax
  6699d7:	4c 8b b0 e0 09 00 00 	mov    0x9e0(%rax),%r14
  6699de:	4d 85 f6             	test   %r14,%r14
  6699e1:	0f 84 09 01 00 00    	je     669af0 <<gpui_canvas::text::planner::Planner>::shape+0xe20>
  6699e7:	48 8b a8 d8 09 00 00 	mov    0x9d8(%rax),%rbp
  6699ee:	45 31 ff             	xor    %r15d,%r15d
  6699f1:	31 db                	xor    %ebx,%ebx
  6699f3:	eb 17                	jmp    669a0c <<gpui_canvas::text::planner::Planner>::shape+0xd3c>
  6699f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6699fc:	00 00 00 00 
  669a00:	49 ff c7             	inc    %r15
  669a03:	4d 39 f7             	cmp    %r14,%r15
  669a06:	0f 84 e6 00 00 00    	je     669af2 <<gpui_canvas::text::planner::Planner>::shape+0xe22>
  669a0c:	49 6b c7 70          	imul   $0x70,%r15,%rax
  669a10:	48 01 e8             	add    %rbp,%rax
  669a13:	48 89 9c 24 10 07 00 	mov    %rbx,0x710(%rsp)
  669a1a:	00 
  669a1b:	48 c7 84 24 18 07 00 	movq   $0x0,0x718(%rsp)
  669a22:	00 00 00 00 00 
  669a27:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
  669a2c:	48 89 8c 24 20 07 00 	mov    %rcx,0x720(%rsp)
  669a33:	00 
  669a34:	48 89 84 24 28 07 00 	mov    %rax,0x728(%rsp)
  669a3b:	00 
  669a3c:	44 89 bc 24 30 07 00 	mov    %r15d,0x730(%rsp)
  669a43:	00 
  669a44:	c6 84 24 d8 07 00 00 	movb   $0x2,0x7d8(%rsp)
  669a4b:	02 
  669a4c:	c7 84 24 e0 07 00 00 	movl   $0x0,0x7e0(%rsp)
  669a53:	00 00 00 00 
  669a57:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
  669a5e:	00 
  669a5f:	48 8d b4 24 18 07 00 	lea    0x718(%rsp),%rsi
  669a66:	00 
  669a67:	e8 94 b5 01 00       	call   685000 <<parley::layout::line::GlyphRunIter<()> as core::iter::traits::iterator::Iterator>::next>
  669a6c:	83 bc 24 40 03 00 00 	cmpl   $0x1,0x340(%rsp)
  669a73:	01 
  669a74:	75 8a                	jne    669a00 <<gpui_canvas::text::planner::Planner>::shape+0xd30>
  669a76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  669a7d:	00 00 00 
  669a80:	49 8b 45 38          	mov    0x38(%r13),%rax
  669a84:	49 89 44 24 40       	mov    %rax,0x40(%r12)
  669a89:	41 0f 10 45 f8       	movups -0x8(%r13),%xmm0
  669a8e:	41 0f 10 4d 08       	movups 0x8(%r13),%xmm1
  669a93:	41 0f 10 55 18       	movups 0x18(%r13),%xmm2
  669a98:	41 0f 10 5d 28       	movups 0x28(%r13),%xmm3
  669a9d:	41 0f 11 5c 24 30    	movups %xmm3,0x30(%r12)
  669aa3:	41 0f 11 54 24 20    	movups %xmm2,0x20(%r12)
  669aa9:	41 0f 11 4c 24 10    	movups %xmm1,0x10(%r12)
  669aaf:	41 0f 11 04 24       	movups %xmm0,(%r12)
  669ab4:	48 89 9c 24 c0 04 00 	mov    %rbx,0x4c0(%rsp)
  669abb:	00 
  669abc:	48 89 de             	mov    %rbx,%rsi
  669abf:	4c 89 e2             	mov    %r12,%rdx
  669ac2:	e8 f9 b0 01 00       	call   684bc0 <<&mut core::iter::adapters::map::map_fold<parley::layout::line::PositionedLayoutItem<()>, usize, usize, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#5}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineData>>, <parley::layout::layout::Layout<()>>::lines::{closure#0}>, parley::layout::line::GlyphRunIter<()>, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#4}>, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#5}>>::{closure#0}>::{closure#0} as core::ops::function::FnMut<(usize, parley::layout::line::PositionedLayoutItem<()>)>>::call_mut>
  669ac7:	48 89 c3             	mov    %rax,%rbx
  669aca:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
  669ad1:	00 
  669ad2:	48 8d b4 24 18 07 00 	lea    0x718(%rsp),%rsi
  669ad9:	00 
  669ada:	e8 21 b5 01 00       	call   685000 <<parley::layout::line::GlyphRunIter<()> as core::iter::traits::iterator::Iterator>::next>
  669adf:	80 bc 24 40 03 00 00 	cmpb   $0x0,0x340(%rsp)
  669ae6:	00 
  669ae7:	75 97                	jne    669a80 <<gpui_canvas::text::planner::Planner>::shape+0xdb0>
  669ae9:	e9 12 ff ff ff       	jmp    669a00 <<gpui_canvas::text::planner::Planner>::shape+0xd30>
  669aee:	66 90                	xchg   %ax,%ax
  669af0:	31 db                	xor    %ebx,%ebx
  669af2:	48 8b b4 24 f8 00 00 	mov    0xf8(%rsp),%rsi
  669af9:	00 
  669afa:	48 89 f0             	mov    %rsi,%rax
  669afd:	48 01 d8             	add    %rbx,%rax
  669b00:	0f 92 c1             	setb   %cl
  669b03:	48 3d 01 80 00 00    	cmp    $0x8001,%rax
  669b09:	0f 93 c0             	setae  %al
  669b0c:	08 c8                	or     %cl,%al
  669b0e:	0f 85 9b 1d 00 00    	jne    66b8af <<gpui_canvas::text::planner::Planner>::shape+0x2bdf>
  669b14:	48 8b 6c 24 30       	mov    0x30(%rsp),%rbp
  669b19:	48 39 ac 24 00 01 00 	cmp    %rbp,0x100(%rsp)
  669b20:	00 
  669b21:	74 14                	je     669b37 <<gpui_canvas::text::planner::Planner>::shape+0xe67>
  669b23:	48 8b 84 24 e8 00 00 	mov    0xe8(%rsp),%rax
  669b2a:	00 
  669b2b:	48 29 f0             	sub    %rsi,%rax
  669b2e:	48 39 c3             	cmp    %rax,%rbx
  669b31:	0f 87 58 1d 00 00    	ja     66b88f <<gpui_canvas::text::planner::Planner>::shape+0x2bbf>
  669b37:	48 85 ed             	test   %rbp,%rbp
  669b3a:	48 8b 9c 24 00 01 00 	mov    0x100(%rsp),%rbx
  669b41:	00 
  669b42:	74 26                	je     669b6a <<gpui_canvas::text::planner::Planner>::shape+0xe9a>
  669b44:	0f 57 c0             	xorps  %xmm0,%xmm0
  669b47:	f3 0f 11 84 24 d4 00 	movss  %xmm0,0xd4(%rsp)
  669b4e:	00 00 
  669b50:	48 39 eb             	cmp    %rbp,%rbx
  669b53:	75 4b                	jne    669ba0 <<gpui_canvas::text::planner::Planner>::shape+0xed0>
  669b55:	48 8b 0c 24          	mov    (%rsp),%rcx
  669b59:	48 8b 81 e0 09 00 00 	mov    0x9e0(%rcx),%rax
  669b60:	48 85 c0             	test   %rax,%rax
  669b63:	75 7c                	jne    669be1 <<gpui_canvas::text::planner::Planner>::shape+0xf11>
  669b65:	e9 9b 14 00 00       	jmp    66b005 <<gpui_canvas::text::planner::Planner>::shape+0x2335>
  669b6a:	48 8b 04 24          	mov    (%rsp),%rax
  669b6e:	48 83 b8 e0 09 00 00 	cmpq   $0x0,0x9e0(%rax)
  669b75:	00 
  669b76:	74 0e                	je     669b86 <<gpui_canvas::text::planner::Planner>::shape+0xeb6>
  669b78:	48 8b 80 d8 09 00 00 	mov    0x9d8(%rax),%rax
  669b7f:	f3 0f 10 40 24       	movss  0x24(%rax),%xmm0
  669b84:	eb 03                	jmp    669b89 <<gpui_canvas::text::planner::Planner>::shape+0xeb9>
  669b86:	0f 57 c0             	xorps  %xmm0,%xmm0
  669b89:	f3 0f 11 44 24 7c    	movss  %xmm0,0x7c(%rsp)
  669b8f:	0f 57 c0             	xorps  %xmm0,%xmm0
  669b92:	f3 0f 11 84 24 d4 00 	movss  %xmm0,0xd4(%rsp)
  669b99:	00 00 
  669b9b:	48 39 eb             	cmp    %rbp,%rbx
  669b9e:	74 b5                	je     669b55 <<gpui_canvas::text::planner::Planner>::shape+0xe85>
  669ba0:	83 bc 24 c8 01 00 00 	cmpl   $0x0,0x1c8(%rsp)
  669ba7:	00 
  669ba8:	74 0e                	je     669bb8 <<gpui_canvas::text::planner::Planner>::shape+0xee8>
  669baa:	48 8b 04 24          	mov    (%rsp),%rax
  669bae:	f3 0f 10 80 28 0a 00 	movss  0xa28(%rax),%xmm0
  669bb5:	00 
  669bb6:	eb 0c                	jmp    669bc4 <<gpui_canvas::text::planner::Planner>::shape+0xef4>
  669bb8:	48 8b 04 24          	mov    (%rsp),%rax
  669bbc:	f3 0f 10 80 2c 0a 00 	movss  0xa2c(%rax),%xmm0
  669bc3:	00 
  669bc4:	f3 0f 11 84 24 d4 00 	movss  %xmm0,0xd4(%rsp)
  669bcb:	00 00 
  669bcd:	48 8b 0c 24          	mov    (%rsp),%rcx
  669bd1:	48 8b 81 e0 09 00 00 	mov    0x9e0(%rcx),%rax
  669bd8:	48 85 c0             	test   %rax,%rax
  669bdb:	0f 84 24 14 00 00    	je     66b005 <<gpui_canvas::text::planner::Planner>::shape+0x2335>
  669be1:	48 8b 89 d8 09 00 00 	mov    0x9d8(%rcx),%rcx
  669be8:	48 6b c0 70          	imul   $0x70,%rax,%rax
  669bec:	48 89 8c 24 c8 00 00 	mov    %rcx,0xc8(%rsp)
  669bf3:	00 
  669bf4:	48 01 c8             	add    %rcx,%rax
  669bf7:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
  669bfe:	00 
  669bff:	c7 44 24 78 00 00 00 	movl   $0x0,0x78(%rsp)
  669c06:	00 
  669c07:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  669c0e:	00 ff 
  669c10:	74 2e                	je     669c40 <<gpui_canvas::text::planner::Planner>::shape+0xf70>
  669c12:	48 39 eb             	cmp    %rbp,%rbx
  669c15:	75 3c                	jne    669c53 <<gpui_canvas::text::planner::Planner>::shape+0xf83>
  669c17:	45 31 f6             	xor    %r14d,%r14d
  669c1a:	45 31 ff             	xor    %r15d,%r15d
  669c1d:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  669c24:	00 
  669c25:	48 8b 8c 24 78 01 00 	mov    0x178(%rsp),%rcx
  669c2c:	00 
  669c2d:	48 89 8c 24 58 02 00 	mov    %rcx,0x258(%rsp)
  669c34:	00 
  669c35:	80 78 68 02          	cmpb   $0x2,0x68(%rax)
  669c39:	74 41                	je     669c7c <<gpui_canvas::text::planner::Planner>::shape+0xfac>
  669c3b:	e9 da 01 00 00       	jmp    669e1a <<gpui_canvas::text::planner::Planner>::shape+0x114a>
  669c40:	8b 4c 24 78          	mov    0x78(%rsp),%ecx
  669c44:	89 c8                	mov    %ecx,%eax
  669c46:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
  669c4d:	00 
  669c4e:	e9 cd 03 00 00       	jmp    66a020 <<gpui_canvas::text::planner::Planner>::shape+0x1350>
  669c53:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  669c5a:	00 
  669c5b:	4c 8b 38             	mov    (%rax),%r15
  669c5e:	4c 8b 70 08          	mov    0x8(%rax),%r14
  669c62:	48 8b 8c 24 78 01 00 	mov    0x178(%rsp),%rcx
  669c69:	00 
  669c6a:	48 89 8c 24 58 02 00 	mov    %rcx,0x258(%rsp)
  669c71:	00 
  669c72:	80 78 68 02          	cmpb   $0x2,0x68(%rax)
  669c76:	0f 85 9e 01 00 00    	jne    669e1a <<gpui_canvas::text::planner::Planner>::shape+0x114a>
  669c7c:	48 8b 78 10          	mov    0x10(%rax),%rdi
  669c80:	48 8b 70 18          	mov    0x18(%rax),%rsi
  669c84:	48 8b 04 24          	mov    (%rsp),%rax
  669c88:	48 8b 90 f8 09 00 00 	mov    0x9f8(%rax),%rdx
  669c8f:	48 39 fe             	cmp    %rdi,%rsi
  669c92:	0f 82 80 25 00 00    	jb     66c218 <<gpui_canvas::text::planner::Planner>::shape+0x3548>
  669c98:	48 39 d6             	cmp    %rdx,%rsi
  669c9b:	0f 87 77 25 00 00    	ja     66c218 <<gpui_canvas::text::planner::Planner>::shape+0x3548>
  669ca1:	48 8b 04 24          	mov    (%rsp),%rax
  669ca5:	48 8b 80 f0 09 00 00 	mov    0x9f0(%rax),%rax
  669cac:	48 8d 0c bf          	lea    (%rdi,%rdi,4),%rcx
  669cb0:	48 8d 0c c8          	lea    (%rax,%rcx,8),%rcx
  669cb4:	48 8d 14 b6          	lea    (%rsi,%rsi,4),%rdx
  669cb8:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
  669cbc:	48 89 8c 24 c0 04 00 	mov    %rcx,0x4c0(%rsp)
  669cc3:	00 
  669cc4:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
  669ccb:	00 
  669ccc:	48 c7 84 24 d0 04 00 	movq   $0x0,0x4d0(%rsp)
  669cd3:	00 00 00 00 00 
  669cd8:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  669cdd:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
  669ce4:	00 
  669ce5:	8b 44 24 78          	mov    0x78(%rsp),%eax
  669ce9:	89 84 24 e0 04 00 00 	mov    %eax,0x4e0(%rsp)
  669cf0:	c6 84 24 00 07 00 00 	movb   $0x2,0x700(%rsp)
  669cf7:	02 
  669cf8:	48 8d 84 24 08 07 00 	lea    0x708(%rsp),%rax
  669cff:	00 
  669d00:	48 89 84 24 40 03 00 	mov    %rax,0x340(%rsp)
  669d07:	00 
  669d08:	c6 84 24 f0 05 00 00 	movb   $0x2,0x5f0(%rsp)
  669d0f:	02 
  669d10:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  669d17:	00 
  669d18:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
  669d1f:	00 
  669d20:	48 8d 94 24 40 03 00 	lea    0x340(%rsp),%rdx
  669d27:	00 
  669d28:	48 8d 8c 24 e8 04 00 	lea    0x4e8(%rsp),%rcx
  669d2f:	00 
  669d30:	e8 2b a4 01 00       	call   684160 <<core::iter::adapters::map::Map<core::iter::adapters::filter_map::FilterMap<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}>, <parley::layout::line::Line<()>>::runs::{closure#0}>, gpui_canvas::text::planner::freeze_line::{closure#0}> as core::iter::traits::iterator::Iterator>::try_fold::<(), <core::iter::adapters::flatten::FlattenCompat<_, _>>::iter_try_fold::flatten<parley::layout::run::Clusters<()>, (), core::ops::control_flow::ControlFlow<parley::layout::cluster::Cluster<()>>, <core::iter::adapters::flatten::FlattenCompat<_, _> as core::iter::traits::iterator::Iterator>::try_fold::flatten<parley::layout::run::Clusters<()>, (), core::ops::control_flow::ControlFlow<parley::layout::cluster::Cluster<()>>, core::iter::traits::iterator::Iterator::find::check<parley::layout::cluster::Cluster<()>, &mut gpui_canvas::text::planner::freeze_line::{closure#1}>::{closure#0}>::{closure#0}>::{closure#0}, core::ops::control_flow::ControlFlow<parley::layout::cluster::Cluster<()>>>>
  669d35:	48 8b 8c 24 10 07 00 	mov    0x710(%rsp),%rcx
  669d3c:	00 
  669d3d:	48 85 c9             	test   %rcx,%rcx
  669d40:	0f 84 ba 00 00 00    	je     669e00 <<gpui_canvas::text::planner::Planner>::shape+0x1130>
  669d46:	8b bc 24 38 07 00 00 	mov    0x738(%rsp),%edi
  669d4d:	8b b4 24 90 07 00 00 	mov    0x790(%rsp),%esi
  669d54:	8b 94 24 94 07 00 00 	mov    0x794(%rsp),%edx
  669d5b:	48 8b 41 58          	mov    0x58(%rcx),%rax
  669d5f:	48 39 f8             	cmp    %rdi,%rax
  669d62:	0f 86 d3 25 00 00    	jbe    66c33b <<gpui_canvas::text::planner::Planner>::shape+0x366b>
  669d68:	48 8b 41 50          	mov    0x50(%rcx),%rax
  669d6c:	48 8d 3c ff          	lea    (%rdi,%rdi,8),%rdi
  669d70:	48 c1 e7 04          	shl    $0x4,%rdi
  669d74:	0f 10 41 68          	movups 0x68(%rcx),%xmm0
  669d78:	0f 10 89 80 00 00 00 	movups 0x80(%rcx),%xmm1
  669d7f:	0f 10 91 98 00 00 00 	movups 0x98(%rcx),%xmm2
  669d86:	0f 11 84 24 10 07 00 	movups %xmm0,0x710(%rsp)
  669d8d:	00 
  669d8e:	0f 11 8c 24 20 07 00 	movups %xmm1,0x720(%rsp)
  669d95:	00 
  669d96:	0f 11 94 24 30 07 00 	movups %xmm2,0x730(%rsp)
  669d9d:	00 
  669d9e:	48 8b 44 38 50       	mov    0x50(%rax,%rdi,1),%rax
  669da3:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
  669daa:	00 
  669dab:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  669db2:	00 
  669db3:	ff 15 b7 02 12 00    	call   *0x1202b7(%rip)        # 78a070 <_DYNAMIC+0x5c0>
  669db9:	48 89 c3             	mov    %rax,%rbx
  669dbc:	ba 48 02 00 00       	mov    $0x248,%edx
  669dc1:	4c 89 7c 24 60       	mov    %r15,0x60(%rsp)
  669dc6:	4c 8d bc 24 10 07 00 	lea    0x710(%rsp),%r15
  669dcd:	00 
  669dce:	4c 89 ff             	mov    %r15,%rdi
  669dd1:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
  669dd8:	00 
  669dd9:	ff 15 a1 ff 11 00    	call   *0x11ffa1(%rip)        # 789d80 <memcpy@GLIBC_2.14>
  669ddf:	4c 89 ff             	mov    %r15,%rdi
  669de2:	4c 8b 7c 24 60       	mov    0x60(%rsp),%r15
  669de7:	48 89 de             	mov    %rbx,%rsi
  669dea:	e8 a1 a5 01 00       	call   684390 <<core::iter::adapters::map::Map<core::iter::adapters::filter::Filter<core::iter::adapters::flatten::FlatMap<core::iter::adapters::filter_map::FilterMap<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}>, <parley::layout::line::Line<()>>::runs::{closure#0}>, parley::layout::run::Clusters<()>, gpui_canvas::text::planner::freeze_line::{closure#0}>, gpui_canvas::text::planner::freeze_line::{closure#1}>, gpui_canvas::text::planner::freeze_line::{closure#2}> as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::traits::iterator::Iterator::min_by::fold<usize, <usize as core::cmp::Ord>::cmp>::{closure#0}>>
  669def:	4c 39 f0             	cmp    %r14,%rax
  669df2:	4c 0f 42 f0          	cmovb  %rax,%r14
  669df6:	48 8b 9c 24 00 01 00 	mov    0x100(%rsp),%rbx
  669dfd:	00 
  669dfe:	eb 1a                	jmp    669e1a <<gpui_canvas::text::planner::Planner>::shape+0x114a>
  669e00:	80 bc 24 00 07 00 00 	cmpb   $0x2,0x700(%rsp)
  669e07:	02 
  669e08:	c6 84 24 f0 05 00 00 	movb   $0x2,0x5f0(%rsp)
  669e0f:	02 
  669e10:	48 8b 9c 24 00 01 00 	mov    0x100(%rsp),%rbx
  669e17:	00 
  669e18:	75 36                	jne    669e50 <<gpui_canvas::text::planner::Planner>::shape+0x1180>
  669e1a:	4d 39 f7             	cmp    %r14,%r15
  669e1d:	0f 87 67 1e 00 00    	ja     66bc8a <<gpui_canvas::text::planner::Planner>::shape+0x2fba>
  669e23:	4d 85 ff             	test   %r15,%r15
  669e26:	0f 84 a0 00 00 00    	je     669ecc <<gpui_canvas::text::planner::Planner>::shape+0x11fc>
  669e2c:	4c 3b bc 24 10 01 00 	cmp    0x110(%rsp),%r15
  669e33:	00 
  669e34:	0f 83 8c 00 00 00    	jae    669ec6 <<gpui_canvas::text::planner::Planner>::shape+0x11f6>
  669e3a:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  669e3f:	42 80 3c 38 bf       	cmpb   $0xbf,(%rax,%r15,1)
  669e44:	0f 8f 82 00 00 00    	jg     669ecc <<gpui_canvas::text::planner::Planner>::shape+0x11fc>
  669e4a:	e9 3b 1e 00 00       	jmp    66bc8a <<gpui_canvas::text::planner::Planner>::shape+0x2fba>
  669e4f:	90                   	nop
  669e50:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  669e57:	00 
  669e58:	48 8d b4 24 f8 05 00 	lea    0x5f8(%rsp),%rsi
  669e5f:	00 
  669e60:	e8 ab 9a 01 00       	call   683910 <<parley::layout::run::Clusters<()> as core::iter::traits::iterator::Iterator>::next>
  669e65:	48 8b 8c 24 10 07 00 	mov    0x710(%rsp),%rcx
  669e6c:	00 
  669e6d:	48 85 c9             	test   %rcx,%rcx
  669e70:	74 a8                	je     669e1a <<gpui_canvas::text::planner::Planner>::shape+0x114a>
  669e72:	8b bc 24 38 07 00 00 	mov    0x738(%rsp),%edi
  669e79:	48 8b 41 58          	mov    0x58(%rcx),%rax
  669e7d:	48 39 f8             	cmp    %rdi,%rax
  669e80:	0f 86 32 24 00 00    	jbe    66c2b8 <<gpui_canvas::text::planner::Planner>::shape+0x35e8>
  669e86:	8b b4 24 90 07 00 00 	mov    0x790(%rsp),%esi
  669e8d:	8b 94 24 94 07 00 00 	mov    0x794(%rsp),%edx
  669e94:	4c 8b 41 70          	mov    0x70(%rcx),%r8
  669e98:	39 f2                	cmp    %esi,%edx
  669e9a:	0f 82 fb 22 00 00    	jb     66c19b <<gpui_canvas::text::planner::Planner>::shape+0x34cb>
  669ea0:	49 39 d0             	cmp    %rdx,%r8
  669ea3:	0f 82 f2 22 00 00    	jb     66c19b <<gpui_canvas::text::planner::Planner>::shape+0x34cb>
  669ea9:	39 f2                	cmp    %esi,%edx
  669eab:	0f 84 18 24 00 00    	je     66c2c9 <<gpui_canvas::text::planner::Planner>::shape+0x35f9>
  669eb1:	4c 8b 41 68          	mov    0x68(%rcx),%r8
  669eb5:	4c 8d 0c 76          	lea    (%rsi,%rsi,2),%r9
  669eb9:	43 80 7c 88 07 06    	cmpb   $0x6,0x7(%r8,%r9,4)
  669ebf:	75 8f                	jne    669e50 <<gpui_canvas::text::planner::Planner>::shape+0x1180>
  669ec1:	e9 99 fe ff ff       	jmp    669d5f <<gpui_canvas::text::planner::Planner>::shape+0x108f>
  669ec6:	0f 85 be 1d 00 00    	jne    66bc8a <<gpui_canvas::text::planner::Planner>::shape+0x2fba>
  669ecc:	4d 85 f6             	test   %r14,%r14
  669ecf:	74 21                	je     669ef2 <<gpui_canvas::text::planner::Planner>::shape+0x1222>
  669ed1:	4c 3b b4 24 10 01 00 	cmp    0x110(%rsp),%r14
  669ed8:	00 
  669ed9:	73 11                	jae    669eec <<gpui_canvas::text::planner::Planner>::shape+0x121c>
  669edb:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  669ee0:	42 80 3c 30 c0       	cmpb   $0xc0,(%rax,%r14,1)
  669ee5:	7d 0b                	jge    669ef2 <<gpui_canvas::text::planner::Planner>::shape+0x1222>
  669ee7:	e9 9e 1d 00 00       	jmp    66bc8a <<gpui_canvas::text::planner::Planner>::shape+0x2fba>
  669eec:	0f 85 98 1d 00 00    	jne    66bc8a <<gpui_canvas::text::planner::Planner>::shape+0x2fba>
  669ef2:	0f 57 c0             	xorps  %xmm0,%xmm0
  669ef5:	48 39 eb             	cmp    %rbp,%rbx
  669ef8:	74 0d                	je     669f07 <<gpui_canvas::text::planner::Planner>::shape+0x1237>
  669efa:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  669f01:	00 
  669f02:	f3 0f 10 40 30       	movss  0x30(%rax),%xmm0
  669f07:	f3 0f 11 44 24 60    	movss  %xmm0,0x60(%rsp)
  669f0d:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  669f14:	00 
  669f15:	f3 0f 10 48 40       	movss  0x40(%rax),%xmm1
  669f1a:	f3 0f 10 40 44       	movss  0x44(%rax),%xmm0
  669f1f:	0f 29 8c 24 90 02 00 	movaps %xmm1,0x290(%rsp)
  669f26:	00 
  669f27:	f3 0f 5d 48 48       	minss  0x48(%rax),%xmm1
  669f2c:	0f 29 8c 24 a0 01 00 	movaps %xmm1,0x1a0(%rsp)
  669f33:	00 
  669f34:	0f 29 84 24 d0 01 00 	movaps %xmm0,0x1d0(%rsp)
  669f3b:	00 
  669f3c:	f3 0f 5f 40 4c       	maxss  0x4c(%rax),%xmm0
  669f41:	0f 29 84 24 20 01 00 	movaps %xmm0,0x120(%rsp)
  669f48:	00 
  669f49:	f3 0f 10 40 24       	movss  0x24(%rax),%xmm0
  669f4e:	f3 0f 58 44 24 1c    	addss  0x1c(%rsp),%xmm0
  669f54:	f3 0f 11 44 24 08    	movss  %xmm0,0x8(%rsp)
  669f5a:	48 8b 9c 24 78 01 00 	mov    0x178(%rsp),%rbx
  669f61:	00 
  669f62:	48 3b 9c 24 68 01 00 	cmp    0x168(%rsp),%rbx
  669f69:	00 
  669f6a:	75 0e                	jne    669f7a <<gpui_canvas::text::planner::Planner>::shape+0x12aa>
  669f6c:	48 8d bc 24 68 01 00 	lea    0x168(%rsp),%rdi
  669f73:	00 
  669f74:	ff 15 3e 00 12 00    	call   *0x12003e(%rip)        # 789fb8 <_DYNAMIC+0x508>
  669f7a:	41 01 ef             	add    %ebp,%r15d
  669f7d:	41 01 ee             	add    %ebp,%r14d
  669f80:	0f 28 94 24 a0 01 00 	movaps 0x1a0(%rsp),%xmm2
  669f87:	00 
  669f88:	0f 28 c2             	movaps %xmm2,%xmm0
  669f8b:	f3 0f c2 c2 03       	cmpunordss %xmm2,%xmm0
  669f90:	0f 28 c8             	movaps %xmm0,%xmm1
  669f93:	0f 55 ca             	andnps %xmm2,%xmm1
  669f96:	0f 54 84 24 90 02 00 	andps  0x290(%rsp),%xmm0
  669f9d:	00 
  669f9e:	0f 56 c1             	orps   %xmm1,%xmm0
  669fa1:	f3 0f 10 4c 24 1c    	movss  0x1c(%rsp),%xmm1
  669fa7:	f3 0f 58 c8          	addss  %xmm0,%xmm1
  669fab:	0f 28 a4 24 20 01 00 	movaps 0x120(%rsp),%xmm4
  669fb2:	00 
  669fb3:	0f 28 d4             	movaps %xmm4,%xmm2
  669fb6:	f3 0f c2 d4 03       	cmpunordss %xmm4,%xmm2
  669fbb:	0f 28 da             	movaps %xmm2,%xmm3
  669fbe:	0f 55 dc             	andnps %xmm4,%xmm3
  669fc1:	0f 54 94 24 d0 01 00 	andps  0x1d0(%rsp),%xmm2
  669fc8:	00 
  669fc9:	0f 56 d3             	orps   %xmm3,%xmm2
  669fcc:	f3 0f 5c d0          	subss  %xmm0,%xmm2
  669fd0:	48 8b 84 24 70 01 00 	mov    0x170(%rsp),%rax
  669fd7:	00 
  669fd8:	48 8d 0c 5b          	lea    (%rbx,%rbx,2),%rcx
  669fdc:	44 89 3c c8          	mov    %r15d,(%rax,%rcx,8)
  669fe0:	44 89 74 c8 04       	mov    %r14d,0x4(%rax,%rcx,8)
  669fe5:	f3 0f 11 4c c8 08    	movss  %xmm1,0x8(%rax,%rcx,8)
  669feb:	f3 0f 11 54 c8 0c    	movss  %xmm2,0xc(%rax,%rcx,8)
  669ff1:	f3 0f 10 44 24 08    	movss  0x8(%rsp),%xmm0
  669ff7:	f3 0f 11 44 c8 10    	movss  %xmm0,0x10(%rax,%rcx,8)
  669ffd:	f3 0f 10 44 24 60    	movss  0x60(%rsp),%xmm0
  66a003:	f3 0f 11 44 c8 14    	movss  %xmm0,0x14(%rax,%rcx,8)
  66a009:	48 ff c3             	inc    %rbx
  66a00c:	48 89 9c 24 78 01 00 	mov    %rbx,0x178(%rsp)
  66a013:	00 
  66a014:	44 89 b4 24 18 02 00 	mov    %r14d,0x218(%rsp)
  66a01b:	00 
  66a01c:	8b 4c 24 78          	mov    0x78(%rsp),%ecx
  66a020:	48 c7 84 24 10 07 00 	movq   $0x0,0x710(%rsp)
  66a027:	00 00 00 00 00 
  66a02c:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  66a031:	48 89 84 24 18 07 00 	mov    %rax,0x718(%rsp)
  66a038:	00 
  66a039:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  66a040:	00 
  66a041:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
  66a048:	00 
  66a049:	48 83 c0 70          	add    $0x70,%rax
  66a04d:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
  66a054:	00 
  66a055:	89 8c 24 28 07 00 00 	mov    %ecx,0x728(%rsp)
  66a05c:	ff c1                	inc    %ecx
  66a05e:	89 4c 24 78          	mov    %ecx,0x78(%rsp)
  66a062:	c6 84 24 d0 07 00 00 	movb   $0x2,0x7d0(%rsp)
  66a069:	02 
  66a06a:	c7 84 24 d8 07 00 00 	movl   $0x0,0x7d8(%rsp)
  66a071:	00 00 00 00 
  66a075:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
  66a07c:	00 
  66a07d:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
  66a084:	00 
  66a085:	e8 76 af 01 00       	call   685000 <<parley::layout::line::GlyphRunIter<()> as core::iter::traits::iterator::Iterator>::next>
  66a08a:	83 bc 24 40 03 00 00 	cmpl   $0x1,0x340(%rsp)
  66a091:	01 
  66a092:	0f 85 4a 0f 00 00    	jne    66afe2 <<gpui_canvas::text::planner::Planner>::shape+0x2312>
  66a098:	48 8b 84 24 48 03 00 	mov    0x348(%rsp),%rax
  66a09f:	00 
  66a0a0:	48 85 c0             	test   %rax,%rax
  66a0a3:	0f 84 d1 1b 00 00    	je     66bc7a <<gpui_canvas::text::planner::Planner>::shape+0x2faa>
  66a0a9:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
  66a0b0:	00 
  66a0b1:	41 0f 10 45 00       	movups 0x0(%r13),%xmm0
  66a0b6:	41 0f 10 4d 10       	movups 0x10(%r13),%xmm1
  66a0bb:	41 0f 10 55 20       	movups 0x20(%r13),%xmm2
  66a0c0:	41 0f 10 5d 30       	movups 0x30(%r13),%xmm3
  66a0c5:	48 8d 8c 24 a0 03 00 	lea    0x3a0(%rsp),%rcx
  66a0cc:	00 
  66a0cd:	0f 11 59 30          	movups %xmm3,0x30(%rcx)
  66a0d1:	0f 11 51 20          	movups %xmm2,0x20(%rcx)
  66a0d5:	0f 11 49 10          	movups %xmm1,0x10(%rcx)
  66a0d9:	0f 11 01             	movups %xmm0,(%rcx)
  66a0dc:	4c 8b 9c 24 a0 03 00 	mov    0x3a0(%rsp),%r11
  66a0e3:	00 
  66a0e4:	49 8b 4b 30          	mov    0x30(%r11),%rcx
  66a0e8:	49 8b 73 38          	mov    0x38(%r11),%rsi
  66a0ec:	48 89 f2             	mov    %rsi,%rdx
  66a0ef:	48 29 ca             	sub    %rcx,%rdx
  66a0f2:	40 0f 92 c7          	setb   %dil
  66a0f6:	48 3b b0 d0 00 00 00 	cmp    0xd0(%rax),%rsi
  66a0fd:	40 0f 97 c6          	seta   %sil
  66a101:	48 01 c9             	add    %rcx,%rcx
  66a104:	48 03 88 c8 00 00 00 	add    0xc8(%rax),%rcx
  66a10b:	40 08 fe             	or     %dil,%sil
  66a10e:	40 84 f6             	test   %sil,%sil
  66a111:	be 00 00 00 00       	mov    $0x0,%esi
  66a116:	48 0f 45 d6          	cmovne %rsi,%rdx
  66a11a:	be 02 00 00 00       	mov    $0x2,%esi
  66a11f:	48 0f 45 ce          	cmovne %rsi,%rcx
  66a123:	48 01 d2             	add    %rdx,%rdx
  66a126:	31 f6                	xor    %esi,%esi
  66a128:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  66a12f:	00 
  66a130:	48 39 f2             	cmp    %rsi,%rdx
  66a133:	74 10                	je     66a145 <<gpui_canvas::text::planner::Planner>::shape+0x1475>
  66a135:	66 83 3c 31 00       	cmpw   $0x0,(%rcx,%rsi,1)
  66a13a:	48 8d 76 02          	lea    0x2(%rsi),%rsi
  66a13e:	74 f0                	je     66a130 <<gpui_canvas::text::planner::Planner>::shape+0x1460>
  66a140:	e9 77 17 00 00       	jmp    66b8bc <<gpui_canvas::text::planner::Planner>::shape+0x2bec>
  66a145:	49 8b 4b 40          	mov    0x40(%r11),%rcx
  66a149:	48 3b 88 b8 00 00 00 	cmp    0xb8(%rax),%rcx
  66a150:	0f 83 d4 20 00 00    	jae    66c22a <<gpui_canvas::text::planner::Planner>::shape+0x355a>
  66a156:	48 c1 e1 06          	shl    $0x6,%rcx
  66a15a:	48 03 88 b0 00 00 00 	add    0xb0(%rax),%rcx
  66a161:	48 8b 34 24          	mov    (%rsp),%rsi
  66a165:	83 3e 01             	cmpl   $0x1,(%rsi)
  66a168:	75 0f                	jne    66a179 <<gpui_canvas::text::planner::Planner>::shape+0x14a9>
  66a16a:	48 8b 56 08          	mov    0x8(%rsi),%rdx
  66a16e:	48 3b 51 10          	cmp    0x10(%rcx),%rdx
  66a172:	75 05                	jne    66a179 <<gpui_canvas::text::planner::Planner>::shape+0x14a9>
  66a174:	45 31 c0             	xor    %r8d,%r8d
  66a177:	eb 4c                	jmp    66a1c5 <<gpui_canvas::text::planner::Planner>::shape+0x14f5>
  66a179:	83 7e 10 01          	cmpl   $0x1,0x10(%rsi)
  66a17d:	75 10                	jne    66a18f <<gpui_canvas::text::planner::Planner>::shape+0x14bf>
  66a17f:	48 8b 56 18          	mov    0x18(%rsi),%rdx
  66a183:	41 b8 01 00 00 00    	mov    $0x1,%r8d
  66a189:	48 3b 51 10          	cmp    0x10(%rcx),%rdx
  66a18d:	74 1e                	je     66a1ad <<gpui_canvas::text::planner::Planner>::shape+0x14dd>
  66a18f:	83 7e 20 01          	cmpl   $0x1,0x20(%rsi)
  66a193:	0f 85 0f 1b 00 00    	jne    66bca8 <<gpui_canvas::text::planner::Planner>::shape+0x2fd8>
  66a199:	48 8b 56 28          	mov    0x28(%rsi),%rdx
  66a19d:	41 b8 02 00 00 00    	mov    $0x2,%r8d
  66a1a3:	48 3b 51 10          	cmp    0x10(%rcx),%rdx
  66a1a7:	0f 85 fb 1a 00 00    	jne    66bca8 <<gpui_canvas::text::planner::Planner>::shape+0x2fd8>
  66a1ad:	41 8d 48 ff          	lea    -0x1(%r8),%ecx
  66a1b1:	48 8b 94 24 08 02 00 	mov    0x208(%rsp),%rdx
  66a1b8:	00 
  66a1b9:	48 0f ab ca          	bts    %rcx,%rdx
  66a1bd:	48 89 94 24 08 02 00 	mov    %rdx,0x208(%rsp)
  66a1c4:	00 
  66a1c5:	8b bc 24 c0 03 00 00 	mov    0x3c0(%rsp),%edi
  66a1cc:	48 8b 70 58          	mov    0x58(%rax),%rsi
  66a1d0:	48 39 fe             	cmp    %rdi,%rsi
  66a1d3:	0f 86 17 21 00 00    	jbe    66c2f0 <<gpui_canvas::text::planner::Planner>::shape+0x3620>
  66a1d9:	48 8b 94 24 b0 03 00 	mov    0x3b0(%rsp),%rdx
  66a1e0:	00 
  66a1e1:	48 85 d2             	test   %rdx,%rdx
  66a1e4:	4c 89 84 24 60 02 00 	mov    %r8,0x260(%rsp)
  66a1eb:	00 
  66a1ec:	48 89 94 24 e8 02 00 	mov    %rdx,0x2e8(%rsp)
  66a1f3:	00 
  66a1f4:	74 0a                	je     66a200 <<gpui_canvas::text::planner::Planner>::shape+0x1530>
  66a1f6:	48 8d 4a 18          	lea    0x18(%rdx),%rcx
  66a1fa:	48 83 c2 1c          	add    $0x1c,%rdx
  66a1fe:	eb 1b                	jmp    66a21b <<gpui_canvas::text::planner::Planner>::shape+0x154b>
  66a200:	48 8b 48 50          	mov    0x50(%rax),%rcx
  66a204:	48 8d 34 ff          	lea    (%rdi,%rdi,8),%rsi
  66a208:	48 c1 e6 04          	shl    $0x4,%rsi
  66a20c:	48 8d 14 31          	lea    (%rcx,%rsi,1),%rdx
  66a210:	48 83 c2 54          	add    $0x54,%rdx
  66a214:	48 01 f1             	add    %rsi,%rcx
  66a217:	48 83 c1 50          	add    $0x50,%rcx
  66a21b:	48 8b b4 24 f8 00 00 	mov    0xf8(%rsp),%rsi
  66a222:	00 
  66a223:	48 89 b4 24 f0 02 00 	mov    %rsi,0x2f0(%rsp)
  66a22a:	00 
  66a22b:	48 8b 70 68          	mov    0x68(%rax),%rsi
  66a22f:	48 8b 78 70          	mov    0x70(%rax),%rdi
  66a233:	4c 8b 80 80 00 00 00 	mov    0x80(%rax),%r8
  66a23a:	4c 8b 88 88 00 00 00 	mov    0x88(%rax),%r9
  66a241:	4c 8b 90 98 00 00 00 	mov    0x98(%rax),%r10
  66a248:	48 8b 80 a0 00 00 00 	mov    0xa0(%rax),%rax
  66a24f:	8b 12                	mov    (%rdx),%edx
  66a251:	8b 09                	mov    (%rcx),%ecx
  66a253:	4c 89 9c 24 48 02 00 	mov    %r11,0x248(%rsp)
  66a25a:	00 
  66a25b:	45 0f b6 9b 8c 00 00 	movzbl 0x8c(%r11),%r11d
  66a262:	00 
  66a263:	41 80 e3 01          	and    $0x1,%r11b
  66a267:	89 d3                	mov    %edx,%ebx
  66a269:	29 cb                	sub    %ecx,%ebx
  66a26b:	48 c7 84 24 c0 04 00 	movq   $0x0,0x4c0(%rsp)
  66a272:	00 00 00 00 00 
  66a277:	48 c7 84 24 e0 04 00 	movq   $0x0,0x4e0(%rsp)
  66a27e:	00 00 00 00 00 
  66a283:	c7 84 24 00 05 00 00 	movl   $0x0,0x500(%rsp)
  66a28a:	00 00 00 00 
  66a28e:	89 9c 24 04 05 00 00 	mov    %ebx,0x504(%rsp)
  66a295:	48 89 b4 24 08 05 00 	mov    %rsi,0x508(%rsp)
  66a29c:	00 
  66a29d:	48 89 bc 24 10 05 00 	mov    %rdi,0x510(%rsp)
  66a2a4:	00 
  66a2a5:	4c 89 84 24 18 05 00 	mov    %r8,0x518(%rsp)
  66a2ac:	00 
  66a2ad:	4c 89 8c 24 20 05 00 	mov    %r9,0x520(%rsp)
  66a2b4:	00 
  66a2b5:	4c 89 94 24 28 05 00 	mov    %r10,0x528(%rsp)
  66a2bc:	00 
  66a2bd:	48 89 84 24 30 05 00 	mov    %rax,0x530(%rsp)
  66a2c4:	00 
  66a2c5:	89 8c 24 38 05 00 00 	mov    %ecx,0x538(%rsp)
  66a2cc:	89 94 24 3c 05 00 00 	mov    %edx,0x53c(%rsp)
  66a2d3:	89 8c 24 40 05 00 00 	mov    %ecx,0x540(%rsp)
  66a2da:	89 94 24 44 05 00 00 	mov    %edx,0x544(%rsp)
  66a2e1:	44 88 9c 24 48 05 00 	mov    %r11b,0x548(%rsp)
  66a2e8:	00 
  66a2e9:	f2 0f 10 84 24 d0 03 	movsd  0x3d0(%rsp),%xmm0
  66a2f0:	00 00 
  66a2f2:	0f 29 84 24 e0 03 00 	movaps %xmm0,0x3e0(%rsp)
  66a2f9:	00 
  66a2fa:	8b 94 24 c8 03 00 00 	mov    0x3c8(%rsp),%edx
  66a301:	8b 8c 24 cc 03 00 00 	mov    0x3cc(%rsp),%ecx
  66a308:	48 8d bc 24 f8 03 00 	lea    0x3f8(%rsp),%rdi
  66a30f:	00 
  66a310:	48 8d b4 24 98 03 00 	lea    0x398(%rsp),%rsi
  66a317:	00 
  66a318:	e8 23 6c 01 00       	call   680f40 <<parley::layout::run::Run<()>>::glyphs_in>
  66a31d:	0f 28 94 24 e0 03 00 	movaps 0x3e0(%rsp),%xmm2
  66a324:	00 
  66a325:	0f 13 94 24 90 04 00 	movlps %xmm2,0x490(%rsp)
  66a32c:	00 
  66a32d:	48 8b 9c 24 f8 03 00 	mov    0x3f8(%rsp),%rbx
  66a334:	00 
  66a335:	48 8b 84 24 00 04 00 	mov    0x400(%rsp),%rax
  66a33c:	00 
  66a33d:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  66a344:	00 
  66a345:	0f b6 84 24 08 04 00 	movzbl 0x408(%rsp),%eax
  66a34c:	00 
  66a34d:	8b 8c 24 0c 04 00 00 	mov    0x40c(%rsp),%ecx
  66a354:	89 8c 24 bc 01 00 00 	mov    %ecx,0x1bc(%rsp)
  66a35b:	f2 0f 10 84 24 10 04 	movsd  0x410(%rsp),%xmm0
  66a362:	00 00 
  66a364:	0f 29 84 24 30 02 00 	movaps %xmm0,0x230(%rsp)
  66a36b:	00 
  66a36c:	f3 0f 10 84 24 18 04 	movss  0x418(%rsp),%xmm0
  66a373:	00 00 
  66a375:	f3 0f 11 84 24 b8 01 	movss  %xmm0,0x1b8(%rsp)
  66a37c:	00 00 
  66a37e:	48 8b 8c 24 20 04 00 	mov    0x420(%rsp),%rcx
  66a385:	00 
  66a386:	48 89 8c 24 68 02 00 	mov    %rcx,0x268(%rsp)
  66a38d:	00 
  66a38e:	48 8b 8c 24 28 04 00 	mov    0x428(%rsp),%rcx
  66a395:	00 
  66a396:	48 89 8c 24 00 02 00 	mov    %rcx,0x200(%rsp)
  66a39d:	00 
  66a39e:	48 8b 94 24 30 04 00 	mov    0x430(%rsp),%rdx
  66a3a5:	00 
  66a3a6:	4c 8b b4 24 38 04 00 	mov    0x438(%rsp),%r14
  66a3ad:	00 
  66a3ae:	48 8b 8c 24 40 04 00 	mov    0x440(%rsp),%rcx
  66a3b5:	00 
  66a3b6:	48 89 8c 24 78 02 00 	mov    %rcx,0x278(%rsp)
  66a3bd:	00 
  66a3be:	48 8b 8c 24 48 04 00 	mov    0x448(%rsp),%rcx
  66a3c5:	00 
  66a3c6:	48 89 8c 24 40 01 00 	mov    %rcx,0x140(%rsp)
  66a3cd:	00 
  66a3ce:	8b 8c 24 50 04 00 00 	mov    0x450(%rsp),%ecx
  66a3d5:	48 89 8c 24 f0 01 00 	mov    %rcx,0x1f0(%rsp)
  66a3dc:	00 
  66a3dd:	8b 8c 24 54 04 00 00 	mov    0x454(%rsp),%ecx
  66a3e4:	48 89 8c 24 f8 01 00 	mov    %rcx,0x1f8(%rsp)
  66a3eb:	00 
  66a3ec:	8b 8c 24 58 04 00 00 	mov    0x458(%rsp),%ecx
  66a3f3:	48 89 8c 24 20 01 00 	mov    %rcx,0x120(%rsp)
  66a3fa:	00 
  66a3fb:	44 8b bc 24 5c 04 00 	mov    0x45c(%rsp),%r15d
  66a402:	00 
  66a403:	f3 0f 10 84 24 60 04 	movss  0x460(%rsp),%xmm0
  66a40a:	00 00 
  66a40c:	f3 0f 11 84 24 c0 01 	movss  %xmm0,0x1c0(%rsp)
  66a413:	00 00 
  66a415:	f3 0f 10 84 24 64 04 	movss  0x464(%rsp),%xmm0
  66a41c:	00 00 
  66a41e:	f3 0f 11 44 24 58    	movss  %xmm0,0x58(%rsp)
  66a424:	48 8b 8c 24 68 04 00 	mov    0x468(%rsp),%rcx
  66a42b:	00 
  66a42c:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
  66a431:	f3 0f 10 84 24 80 04 	movss  0x480(%rsp),%xmm0
  66a438:	00 00 
  66a43a:	f3 0f 10 8c 24 7c 04 	movss  0x47c(%rsp),%xmm1
  66a441:	00 00 
  66a443:	f3 0f 11 84 24 28 02 	movss  %xmm0,0x228(%rsp)
  66a44a:	00 00 
  66a44c:	f3 0f 58 c8          	addss  %xmm0,%xmm1
  66a450:	f3 0f 10 84 24 84 04 	movss  0x484(%rsp),%xmm0
  66a457:	00 00 
  66a459:	f3 0f 11 8c 24 24 02 	movss  %xmm1,0x224(%rsp)
  66a460:	00 00 
  66a462:	f3 0f 58 c1          	addss  %xmm1,%xmm0
  66a466:	f3 0f 11 84 24 1c 02 	movss  %xmm0,0x21c(%rsp)
  66a46d:	00 00 
  66a46f:	0f 28 c2             	movaps %xmm2,%xmm0
  66a472:	0f b6 8c 24 8c 04 00 	movzbl 0x48c(%rsp),%ecx
  66a479:	00 
  66a47a:	88 8c 24 90 02 00 00 	mov    %cl,0x290(%rsp)
  66a481:	48 8b 8c 24 70 04 00 	mov    0x470(%rsp),%rcx
  66a488:	00 
  66a489:	48 89 8c 24 38 01 00 	mov    %rcx,0x138(%rsp)
  66a490:	00 
  66a491:	8b 8c 24 78 04 00 00 	mov    0x478(%rsp),%ecx
  66a498:	89 8c 24 dc 00 00 00 	mov    %ecx,0xdc(%rsp)
  66a49f:	8b 8c 24 88 04 00 00 	mov    0x488(%rsp),%ecx
  66a4a6:	89 8c 24 20 02 00 00 	mov    %ecx,0x220(%rsp)
  66a4ad:	48 8d 4a 16          	lea    0x16(%rdx),%rcx
  66a4b1:	48 89 8c 24 50 02 00 	mov    %rcx,0x250(%rsp)
  66a4b8:	00 
  66a4b9:	48 89 94 24 d0 01 00 	mov    %rdx,0x1d0(%rsp)
  66a4c0:	00 
  66a4c1:	48 8d 4a 2e          	lea    0x2e(%rdx),%rcx
  66a4c5:	48 89 8c 24 00 03 00 	mov    %rcx,0x300(%rsp)
  66a4cc:	00 
  66a4cd:	4c 89 b4 24 e8 01 00 	mov    %r14,0x1e8(%rsp)
  66a4d4:	00 
  66a4d5:	eb 6e                	jmp    66a545 <<gpui_canvas::text::planner::Planner>::shape+0x1875>
  66a4d7:	03 6c 24 30          	add    0x30(%rsp),%ebp
  66a4db:	0f 28 8c 24 a0 01 00 	movaps 0x1a0(%rsp),%xmm1
  66a4e2:	00 
  66a4e3:	f3 0f 58 4c 24 1c    	addss  0x1c(%rsp),%xmm1
  66a4e9:	48 8b 84 24 f0 00 00 	mov    0xf0(%rsp),%rax
  66a4f0:	00 
  66a4f1:	4c 89 f1             	mov    %r14,%rcx
  66a4f4:	48 c1 e1 04          	shl    $0x4,%rcx
  66a4f8:	89 2c 08             	mov    %ebp,(%rax,%rcx,1)
  66a4fb:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  66a501:	f3 0f 11 44 08 04    	movss  %xmm0,0x4(%rax,%rcx,1)
  66a507:	f3 0f 11 4c 08 08    	movss  %xmm1,0x8(%rax,%rcx,1)
  66a50d:	8b 54 24 5c          	mov    0x5c(%rsp),%edx
  66a511:	66 89 54 08 0c       	mov    %dx,0xc(%rax,%rcx,1)
  66a516:	48 8b 94 24 60 02 00 	mov    0x260(%rsp),%rdx
  66a51d:	00 
  66a51e:	88 54 08 0e          	mov    %dl,0xe(%rax,%rcx,1)
  66a522:	c6 44 08 0f 00       	movb   $0x0,0xf(%rax,%rcx,1)
  66a527:	49 ff c6             	inc    %r14
  66a52a:	4c 89 b4 24 f8 00 00 	mov    %r14,0xf8(%rsp)
  66a531:	00 
  66a532:	31 c0                	xor    %eax,%eax
  66a534:	4c 8b b4 24 e8 01 00 	mov    0x1e8(%rsp),%r14
  66a53b:	00 
  66a53c:	f3 0f 10 84 24 c4 01 	movss  0x1c4(%rsp),%xmm0
  66a543:	00 00 
  66a545:	f3 0f 11 44 24 0c    	movss  %xmm0,0xc(%rsp)
  66a54b:	a8 01                	test   $0x1,%al
  66a54d:	74 61                	je     66a5b0 <<gpui_canvas::text::planner::Planner>::shape+0x18e0>
  66a54f:	f3 0f 10 84 24 b8 01 	movss  0x1b8(%rsp),%xmm0
  66a556:	00 00 
  66a558:	f3 0f 11 44 24 08    	movss  %xmm0,0x8(%rsp)
  66a55e:	8b 84 24 bc 01 00 00 	mov    0x1bc(%rsp),%eax
  66a565:	89 44 24 5c          	mov    %eax,0x5c(%rsp)
  66a569:	0f 28 84 24 30 02 00 	movaps 0x230(%rsp),%xmm0
  66a570:	00 
  66a571:	0f 29 84 24 a0 01 00 	movaps %xmm0,0x1a0(%rsp)
  66a578:	00 
  66a579:	83 bc 24 dc 00 00 00 	cmpl   $0x0,0xdc(%rsp)
  66a580:	00 
  66a581:	74 71                	je     66a5f4 <<gpui_canvas::text::planner::Planner>::shape+0x1924>
  66a583:	48 83 7c 24 60 00    	cmpq   $0x0,0x60(%rsp)
  66a589:	74 7c                	je     66a607 <<gpui_canvas::text::planner::Planner>::shape+0x1937>
  66a58b:	0f 28 84 24 a0 01 00 	movaps 0x1a0(%rsp),%xmm0
  66a592:	00 
  66a593:	f3 0f 11 84 24 d8 00 	movss  %xmm0,0xd8(%rsp)
  66a59a:	00 00 
  66a59c:	e9 94 00 00 00       	jmp    66a635 <<gpui_canvas::text::planner::Planner>::shape+0x1965>
  66a5a1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  66a5a8:	0f 1f 84 00 00 00 00 
  66a5af:	00 
  66a5b0:	48 3b 9c 24 c0 00 00 	cmp    0xc0(%rsp),%rbx
  66a5b7:	00 
  66a5b8:	0f 84 3d 01 00 00    	je     66a6fb <<gpui_canvas::text::planner::Planner>::shape+0x1a2b>
  66a5be:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  66a5c3:	8b 03                	mov    (%rbx),%eax
  66a5c5:	89 44 24 5c          	mov    %eax,0x5c(%rsp)
  66a5c9:	f2 0f 10 43 04       	movsd  0x4(%rbx),%xmm0
  66a5ce:	0f 29 84 24 a0 01 00 	movaps %xmm0,0x1a0(%rsp)
  66a5d5:	00 
  66a5d6:	f3 0f 10 43 0c       	movss  0xc(%rbx),%xmm0
  66a5db:	f3 0f 11 44 24 08    	movss  %xmm0,0x8(%rsp)
  66a5e1:	48 83 c3 10          	add    $0x10,%rbx
  66a5e5:	48 89 54 24 60       	mov    %rdx,0x60(%rsp)
  66a5ea:	83 bc 24 dc 00 00 00 	cmpl   $0x0,0xdc(%rsp)
  66a5f1:	00 
  66a5f2:	75 8f                	jne    66a583 <<gpui_canvas::text::planner::Planner>::shape+0x18b3>
  66a5f4:	0f 28 84 24 a0 01 00 	movaps 0x1a0(%rsp),%xmm0
  66a5fb:	00 
  66a5fc:	f3 0f 11 84 24 d8 00 	movss  %xmm0,0xd8(%rsp)
  66a603:	00 00 
  66a605:	eb 5f                	jmp    66a666 <<gpui_canvas::text::planner::Planner>::shape+0x1996>
  66a607:	f3 0f 10 84 24 c0 01 	movss  0x1c0(%rsp),%xmm0
  66a60e:	00 00 
  66a610:	0f 28 c8             	movaps %xmm0,%xmm1
  66a613:	f3 0f 58 8c 24 a0 01 	addss  0x1a0(%rsp),%xmm1
  66a61a:	00 00 
  66a61c:	f3 0f 11 8c 24 d8 00 	movss  %xmm1,0xd8(%rsp)
  66a623:	00 00 
  66a625:	f3 0f 10 4c 24 08    	movss  0x8(%rsp),%xmm1
  66a62b:	f3 0f 58 c8          	addss  %xmm0,%xmm1
  66a62f:	f3 0f 11 4c 24 08    	movss  %xmm1,0x8(%rsp)
  66a635:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  66a63a:	48 ff c2             	inc    %rdx
  66a63d:	48 8b 84 24 38 01 00 	mov    0x138(%rsp),%rax
  66a644:	00 
  66a645:	48 89 54 24 60       	mov    %rdx,0x60(%rsp)
  66a64a:	48 39 c2             	cmp    %rax,%rdx
  66a64d:	75 17                	jne    66a666 <<gpui_canvas::text::planner::Planner>::shape+0x1996>
  66a64f:	f3 0f 10 44 24 08    	movss  0x8(%rsp),%xmm0
  66a655:	f3 0f 58 44 24 58    	addss  0x58(%rsp),%xmm0
  66a65b:	f3 0f 11 44 24 08    	movss  %xmm0,0x8(%rsp)
  66a661:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  66a666:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
  66a66d:	00 
  66a66e:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
  66a675:	00 
  66a676:	e8 95 26 00 00       	call   66cd10 <<core::iter::adapters::flatten::FlattenCompat<core::iter::adapters::map::Map<core::ops::range::Range<u32>, <parley::layout::run::Run<()>>::glyph_source_ranges::{closure#0}>, core::iter::sources::repeat_n::RepeatN<core::ops::range::Range<usize>>> as core::iter::traits::iterator::Iterator>::next>
  66a67b:	83 bc 24 88 00 00 00 	cmpl   $0x1,0x88(%rsp)
  66a682:	01 
  66a683:	0f 85 e0 15 00 00    	jne    66bc69 <<gpui_canvas::text::planner::Planner>::shape+0x2f99>
  66a689:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  66a68f:	f3 0f 58 44 24 08    	addss  0x8(%rsp),%xmm0
  66a695:	31 c0                	xor    %eax,%eax
  66a697:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  66a69c:	48 39 8c 24 00 01 00 	cmp    %rcx,0x100(%rsp)
  66a6a3:	00 
  66a6a4:	0f 84 9b fe ff ff    	je     66a545 <<gpui_canvas::text::planner::Planner>::shape+0x1875>
  66a6aa:	f3 0f 11 84 24 c4 01 	movss  %xmm0,0x1c4(%rsp)
  66a6b1:	00 00 
  66a6b3:	4c 8b 8c 24 90 00 00 	mov    0x90(%rsp),%r9
  66a6ba:	00 
  66a6bb:	48 8b ac 24 98 00 00 	mov    0x98(%rsp),%rbp
  66a6c2:	00 
  66a6c3:	49 39 e9             	cmp    %rbp,%r9
  66a6c6:	48 8b 8c 24 10 01 00 	mov    0x110(%rsp),%rcx
  66a6cd:	00 
  66a6ce:	0f 87 85 15 00 00    	ja     66bc59 <<gpui_canvas::text::planner::Planner>::shape+0x2f89>
  66a6d4:	4d 85 c9             	test   %r9,%r9
  66a6d7:	0f 84 f7 04 00 00    	je     66abd4 <<gpui_canvas::text::planner::Planner>::shape+0x1f04>
  66a6dd:	49 39 c9             	cmp    %rcx,%r9
  66a6e0:	0f 83 e8 04 00 00    	jae    66abce <<gpui_canvas::text::planner::Planner>::shape+0x1efe>
  66a6e6:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  66a6eb:	42 80 3c 08 bf       	cmpb   $0xbf,(%rax,%r9,1)
  66a6f0:	0f 8f de 04 00 00    	jg     66abd4 <<gpui_canvas::text::planner::Planner>::shape+0x1f04>
  66a6f6:	e9 5e 15 00 00       	jmp    66bc59 <<gpui_canvas::text::planner::Planner>::shape+0x2f89>
  66a6fb:	48 89 9c 24 c0 00 00 	mov    %rbx,0xc0(%rsp)
  66a702:	00 
  66a703:	f6 84 24 90 02 00 00 	testb  $0x1,0x290(%rsp)
  66a70a:	01 
  66a70b:	74 19                	je     66a726 <<gpui_canvas::text::planner::Planner>::shape+0x1a56>
  66a70d:	4c 89 fa             	mov    %r15,%rdx
  66a710:	48 8b 8c 24 20 01 00 	mov    0x120(%rsp),%rcx
  66a717:	00 
  66a718:	39 d1                	cmp    %edx,%ecx
  66a71a:	0f 83 3d 01 00 00    	jae    66a85d <<gpui_canvas::text::planner::Planner>::shape+0x1b8d>
  66a720:	ff ca                	dec    %edx
  66a722:	89 d0                	mov    %edx,%eax
  66a724:	eb 19                	jmp    66a73f <<gpui_canvas::text::planner::Planner>::shape+0x1a6f>
  66a726:	4c 89 fa             	mov    %r15,%rdx
  66a729:	48 8b ac 24 20 01 00 	mov    0x120(%rsp),%rbp
  66a730:	00 
  66a731:	39 d5                	cmp    %edx,%ebp
  66a733:	0f 83 3f 01 00 00    	jae    66a878 <<gpui_canvas::text::planner::Planner>::shape+0x1ba8>
  66a739:	8d 4d 01             	lea    0x1(%rbp),%ecx
  66a73c:	48 89 e8             	mov    %rbp,%rax
  66a73f:	89 c7                	mov    %eax,%edi
  66a741:	49 39 fe             	cmp    %rdi,%r14
  66a744:	0f 86 29 1b 00 00    	jbe    66c273 <<gpui_canvas::text::planner::Planner>::shape+0x35a3>
  66a74a:	49 89 d7             	mov    %rdx,%r15
  66a74d:	48 8d 04 7f          	lea    (%rdi,%rdi,2),%rax
  66a751:	48 8b 94 24 d0 01 00 	mov    0x1d0(%rsp),%rdx
  66a758:	00 
  66a759:	8b 5c c2 08          	mov    0x8(%rdx,%rax,8),%ebx
  66a75d:	f6 44 c2 17 01       	testb  $0x1,0x17(%rdx,%rax,8)
  66a762:	0f 85 63 05 00 00    	jne    66accb <<gpui_canvas::text::planner::Planner>::shape+0x1ffb>
  66a768:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
  66a76c:	8b 50 0c             	mov    0xc(%rax),%edx
  66a76f:	48 8d 34 1a          	lea    (%rdx,%rbx,1),%rsi
  66a773:	48 3b b4 24 40 01 00 	cmp    0x140(%rsp),%rsi
  66a77a:	00 
  66a77b:	0f 87 27 17 00 00    	ja     66bea8 <<gpui_canvas::text::planner::Planner>::shape+0x31d8>
  66a781:	48 c1 e3 04          	shl    $0x4,%rbx
  66a785:	48 03 9c 24 78 02 00 	add    0x278(%rsp),%rbx
  66a78c:	00 
  66a78d:	48 89 d0             	mov    %rdx,%rax
  66a790:	48 c1 e0 04          	shl    $0x4,%rax
  66a794:	48 01 d8             	add    %rbx,%rax
  66a797:	0f 57 c0             	xorps  %xmm0,%xmm0
  66a79a:	0f 29 84 24 30 02 00 	movaps %xmm0,0x230(%rsp)
  66a7a1:	00 
  66a7a2:	48 85 d2             	test   %rdx,%rdx
  66a7a5:	0f 85 bf 06 00 00    	jne    66ae6a <<gpui_canvas::text::planner::Planner>::shape+0x219a>
  66a7ab:	89 ca                	mov    %ecx,%edx
  66a7ad:	48 89 94 24 20 01 00 	mov    %rdx,0x120(%rsp)
  66a7b4:	00 
  66a7b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  66a7bc:	00 00 00 00 
  66a7c0:	f6 84 24 90 02 00 00 	testb  $0x1,0x290(%rsp)
  66a7c7:	01 
  66a7c8:	74 16                	je     66a7e0 <<gpui_canvas::text::planner::Planner>::shape+0x1b10>
  66a7ca:	44 39 f9             	cmp    %r15d,%ecx
  66a7cd:	0f 83 c4 00 00 00    	jae    66a897 <<gpui_canvas::text::planner::Planner>::shape+0x1bc7>
  66a7d3:	41 ff cf             	dec    %r15d
  66a7d6:	4c 89 f8             	mov    %r15,%rax
  66a7d9:	89 ca                	mov    %ecx,%edx
  66a7db:	89 c1                	mov    %eax,%ecx
  66a7dd:	eb 19                	jmp    66a7f8 <<gpui_canvas::text::planner::Planner>::shape+0x1b28>
  66a7df:	90                   	nop
  66a7e0:	4c 89 fa             	mov    %r15,%rdx
  66a7e3:	39 d1                	cmp    %edx,%ecx
  66a7e5:	0f 83 5c 01 00 00    	jae    66a947 <<gpui_canvas::text::planner::Planner>::shape+0x1c77>
  66a7eb:	8d 41 01             	lea    0x1(%rcx),%eax
  66a7ee:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
  66a7f5:	00 
  66a7f6:	89 c2                	mov    %eax,%edx
  66a7f8:	89 cf                	mov    %ecx,%edi
  66a7fa:	49 39 fe             	cmp    %rdi,%r14
  66a7fd:	0f 86 70 1a 00 00    	jbe    66c273 <<gpui_canvas::text::planner::Planner>::shape+0x35a3>
  66a803:	48 8d 04 7f          	lea    (%rdi,%rdi,2),%rax
  66a807:	48 8b 8c 24 d0 01 00 	mov    0x1d0(%rsp),%rcx
  66a80e:	00 
  66a80f:	8b 5c c1 08          	mov    0x8(%rcx,%rax,8),%ebx
  66a813:	f6 44 c1 17 01       	testb  $0x1,0x17(%rcx,%rax,8)
  66a818:	0f 85 a5 04 00 00    	jne    66acc3 <<gpui_canvas::text::planner::Planner>::shape+0x1ff3>
  66a81e:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
  66a822:	8b 78 0c             	mov    0xc(%rax),%edi
  66a825:	48 8d 34 1f          	lea    (%rdi,%rbx,1),%rsi
  66a829:	48 3b b4 24 40 01 00 	cmp    0x140(%rsp),%rsi
  66a830:	00 
  66a831:	0f 87 71 16 00 00    	ja     66bea8 <<gpui_canvas::text::planner::Planner>::shape+0x31d8>
  66a837:	48 c1 e3 04          	shl    $0x4,%rbx
  66a83b:	48 03 9c 24 78 02 00 	add    0x278(%rsp),%rbx
  66a842:	00 
  66a843:	48 89 f8             	mov    %rdi,%rax
  66a846:	48 c1 e0 04          	shl    $0x4,%rax
  66a84a:	48 01 d8             	add    %rbx,%rax
  66a84d:	89 d1                	mov    %edx,%ecx
  66a84f:	48 85 ff             	test   %rdi,%rdi
  66a852:	0f 84 68 ff ff ff    	je     66a7c0 <<gpui_canvas::text::planner::Planner>::shape+0x1af0>
  66a858:	e9 df 04 00 00       	jmp    66ad3c <<gpui_canvas::text::planner::Planner>::shape+0x206c>
  66a85d:	48 89 d8             	mov    %rbx,%rax
  66a860:	3b 8c 24 f0 01 00 00 	cmp    0x1f0(%rsp),%ecx
  66a867:	0f 95 c2             	setne  %dl
  66a86a:	84 94 24 dc 00 00 00 	test   %dl,0xdc(%rsp)
  66a871:	75 4e                	jne    66a8c1 <<gpui_canvas::text::planner::Planner>::shape+0x1bf1>
  66a873:	e9 0c 06 00 00       	jmp    66ae84 <<gpui_canvas::text::planner::Planner>::shape+0x21b4>
  66a878:	48 89 d8             	mov    %rbx,%rax
  66a87b:	3b 94 24 f8 01 00 00 	cmp    0x1f8(%rsp),%edx
  66a882:	0f 95 c1             	setne  %cl
  66a885:	84 8c 24 dc 00 00 00 	test   %cl,0xdc(%rsp)
  66a88c:	0f 85 df 00 00 00    	jne    66a971 <<gpui_canvas::text::planner::Planner>::shape+0x1ca1>
  66a892:	e9 ed 05 00 00       	jmp    66ae84 <<gpui_canvas::text::planner::Planner>::shape+0x21b4>
  66a897:	0f 57 c0             	xorps  %xmm0,%xmm0
  66a89a:	0f 29 84 24 30 02 00 	movaps %xmm0,0x230(%rsp)
  66a8a1:	00 
  66a8a2:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  66a8a9:	00 
  66a8aa:	3b 8c 24 f0 01 00 00 	cmp    0x1f0(%rsp),%ecx
  66a8b1:	0f 95 c2             	setne  %dl
  66a8b4:	84 94 24 dc 00 00 00 	test   %dl,0xdc(%rsp)
  66a8bb:	0f 84 c3 05 00 00    	je     66ae84 <<gpui_canvas::text::planner::Planner>::shape+0x21b4>
  66a8c1:	8d 79 ff             	lea    -0x1(%rcx),%edi
  66a8c4:	49 39 fe             	cmp    %rdi,%r14
  66a8c7:	0f 86 47 1a 00 00    	jbe    66c314 <<gpui_canvas::text::planner::Planner>::shape+0x3644>
  66a8cd:	3b bc 24 f0 01 00 00 	cmp    0x1f0(%rsp),%edi
  66a8d4:	76 48                	jbe    66a91e <<gpui_canvas::text::planner::Planner>::shape+0x1c4e>
  66a8d6:	48 8d 14 7f          	lea    (%rdi,%rdi,2),%rdx
  66a8da:	48 8b b4 24 50 02 00 	mov    0x250(%rsp),%rsi
  66a8e1:	00 
  66a8e2:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
  66a8e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  66a8ed:	00 00 00 
  66a8f0:	49 39 fe             	cmp    %rdi,%r14
  66a8f3:	0f 86 9b 19 00 00    	jbe    66c294 <<gpui_canvas::text::planner::Planner>::shape+0x35c4>
  66a8f9:	f6 42 01 02          	testb  $0x2,0x1(%rdx)
  66a8fd:	75 1f                	jne    66a91e <<gpui_canvas::text::planner::Planner>::shape+0x1c4e>
  66a8ff:	48 ff cf             	dec    %rdi
  66a902:	48 83 c2 e8          	add    $0xffffffffffffffe8,%rdx
  66a906:	39 bc 24 f0 01 00 00 	cmp    %edi,0x1f0(%rsp)
  66a90d:	72 e1                	jb     66a8f0 <<gpui_canvas::text::planner::Planner>::shape+0x1c20>
  66a90f:	48 8b 94 24 f0 01 00 	mov    0x1f0(%rsp),%rdx
  66a916:	00 
  66a917:	48 89 d7             	mov    %rdx,%rdi
  66a91a:	89 d5                	mov    %edx,%ebp
  66a91c:	eb 02                	jmp    66a920 <<gpui_canvas::text::planner::Planner>::shape+0x1c50>
  66a91e:	89 fd                	mov    %edi,%ebp
  66a920:	49 39 fe             	cmp    %rdi,%r14
  66a923:	0f 86 f7 19 00 00    	jbe    66c320 <<gpui_canvas::text::planner::Planner>::shape+0x3650>
  66a929:	48 89 ac 24 20 01 00 	mov    %rbp,0x120(%rsp)
  66a930:	00 
  66a931:	89 ca                	mov    %ecx,%edx
  66a933:	48 ff ca             	dec    %rdx
  66a936:	4c 39 f2             	cmp    %r14,%rdx
  66a939:	0f 83 ed 19 00 00    	jae    66c32c <<gpui_canvas::text::planner::Planner>::shape+0x365c>
  66a93f:	41 89 cf             	mov    %ecx,%r15d
  66a942:	e9 a8 00 00 00       	jmp    66a9ef <<gpui_canvas::text::planner::Planner>::shape+0x1d1f>
  66a947:	0f 57 c0             	xorps  %xmm0,%xmm0
  66a94a:	0f 29 84 24 30 02 00 	movaps %xmm0,0x230(%rsp)
  66a951:	00 
  66a952:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  66a959:	00 
  66a95a:	3b 94 24 f8 01 00 00 	cmp    0x1f8(%rsp),%edx
  66a961:	0f 95 c1             	setne  %cl
  66a964:	84 8c 24 dc 00 00 00 	test   %cl,0xdc(%rsp)
  66a96b:	0f 84 13 05 00 00    	je     66ae84 <<gpui_canvas::text::planner::Planner>::shape+0x21b4>
  66a971:	49 89 d0             	mov    %rdx,%r8
  66a974:	48 89 d1             	mov    %rdx,%rcx
  66a977:	89 cf                	mov    %ecx,%edi
  66a979:	49 39 fe             	cmp    %rdi,%r14
  66a97c:	0f 86 7d 19 00 00    	jbe    66c2ff <<gpui_canvas::text::planner::Planner>::shape+0x362f>
  66a982:	44 8d 79 01          	lea    0x1(%rcx),%r15d
  66a986:	44 3b bc 24 f8 01 00 	cmp    0x1f8(%rsp),%r15d
  66a98d:	00 
  66a98e:	73 48                	jae    66a9d8 <<gpui_canvas::text::planner::Planner>::shape+0x1d08>
  66a990:	44 89 fa             	mov    %r15d,%edx
  66a993:	48 8d 0c 52          	lea    (%rdx,%rdx,2),%rcx
  66a997:	48 8b b4 24 50 02 00 	mov    0x250(%rsp),%rsi
  66a99e:	00 
  66a99f:	48 8d 34 ce          	lea    (%rsi,%rcx,8),%rsi
  66a9a3:	49 89 d7             	mov    %rdx,%r15
  66a9a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  66a9ad:	00 00 00 
  66a9b0:	4d 39 fe             	cmp    %r15,%r14
  66a9b3:	0f 86 c3 18 00 00    	jbe    66c27c <<gpui_canvas::text::planner::Planner>::shape+0x35ac>
  66a9b9:	f6 46 01 02          	testb  $0x2,0x1(%rsi)
  66a9bd:	75 19                	jne    66a9d8 <<gpui_canvas::text::planner::Planner>::shape+0x1d08>
  66a9bf:	49 ff c7             	inc    %r15
  66a9c2:	48 83 c6 18          	add    $0x18,%rsi
  66a9c6:	4c 39 bc 24 f8 01 00 	cmp    %r15,0x1f8(%rsp)
  66a9cd:	00 
  66a9ce:	75 e0                	jne    66a9b0 <<gpui_canvas::text::planner::Planner>::shape+0x1ce0>
  66a9d0:	4c 8b bc 24 f8 01 00 	mov    0x1f8(%rsp),%r15
  66a9d7:	00 
  66a9d8:	44 89 fa             	mov    %r15d,%edx
  66a9db:	48 ff ca             	dec    %rdx
  66a9de:	4c 39 f2             	cmp    %r14,%rdx
  66a9e1:	0f 83 21 19 00 00    	jae    66c308 <<gpui_canvas::text::planner::Planner>::shape+0x3638>
  66a9e7:	4c 89 84 24 20 01 00 	mov    %r8,0x120(%rsp)
  66a9ee:	00 
  66a9ef:	48 83 bc 24 68 02 00 	cmpq   $0x0,0x268(%rsp)
  66a9f6:	00 00 
  66a9f8:	0f 84 86 04 00 00    	je     66ae84 <<gpui_canvas::text::planner::Planner>::shape+0x21b4>
  66a9fe:	48 8d 0c 7f          	lea    (%rdi,%rdi,2),%rcx
  66aa02:	48 8b b4 24 d0 01 00 	mov    0x1d0(%rsp),%rsi
  66aa09:	00 
  66aa0a:	8b 0c ce             	mov    (%rsi,%rcx,8),%ecx
  66aa0d:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
  66aa11:	8b 74 d6 04          	mov    0x4(%rsi,%rdx,8),%esi
  66aa15:	39 ce                	cmp    %ecx,%esi
  66aa17:	0f 82 b3 17 00 00    	jb     66c1d0 <<gpui_canvas::text::planner::Planner>::shape+0x3500>
  66aa1d:	48 39 b4 24 00 02 00 	cmp    %rsi,0x200(%rsp)
  66aa24:	00 
  66aa25:	0f 82 a5 17 00 00    	jb     66c1d0 <<gpui_canvas::text::planner::Planner>::shape+0x3500>
  66aa2b:	39 ce                	cmp    %ecx,%esi
  66aa2d:	0f 84 ad 18 00 00    	je     66c2e0 <<gpui_canvas::text::planner::Planner>::shape+0x3610>
  66aa33:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  66aa37:	48 8b 94 24 68 02 00 	mov    0x268(%rsp),%rdx
  66aa3e:	00 
  66aa3f:	0f b6 4c 8a 07       	movzbl 0x7(%rdx,%rcx,4),%ecx
  66aa44:	8d 51 ff             	lea    -0x1(%rcx),%edx
  66aa47:	83 fa 02             	cmp    $0x2,%edx
  66aa4a:	73 26                	jae    66aa72 <<gpui_canvas::text::planner::Planner>::shape+0x1da2>
  66aa4c:	f3 0f 10 84 24 24 02 	movss  0x224(%rsp),%xmm0
  66aa53:	00 00 
  66aa55:	f3 0f 11 44 24 58    	movss  %xmm0,0x58(%rsp)
  66aa5b:	4c 89 fa             	mov    %r15,%rdx
  66aa5e:	3b 94 24 20 02 00 00 	cmp    0x220(%rsp),%edx
  66aa65:	77 2b                	ja     66aa92 <<gpui_canvas::text::planner::Planner>::shape+0x1dc2>
  66aa67:	f3 0f 10 84 24 1c 02 	movss  0x21c(%rsp),%xmm0
  66aa6e:	00 00 
  66aa70:	eb 1a                	jmp    66aa8c <<gpui_canvas::text::planner::Planner>::shape+0x1dbc>
  66aa72:	f3 0f 10 84 24 28 02 	movss  0x228(%rsp),%xmm0
  66aa79:	00 00 
  66aa7b:	f3 0f 11 44 24 58    	movss  %xmm0,0x58(%rsp)
  66aa81:	83 f9 06             	cmp    $0x6,%ecx
  66aa84:	4c 89 fa             	mov    %r15,%rdx
  66aa87:	75 09                	jne    66aa92 <<gpui_canvas::text::planner::Planner>::shape+0x1dc2>
  66aa89:	0f 57 c0             	xorps  %xmm0,%xmm0
  66aa8c:	f3 0f 11 44 24 58    	movss  %xmm0,0x58(%rsp)
  66aa92:	89 d6                	mov    %edx,%esi
  66aa94:	49 39 f6             	cmp    %rsi,%r14
  66aa97:	0f 92 c1             	setb   %cl
  66aa9a:	3b 94 24 20 01 00 00 	cmp    0x120(%rsp),%edx
  66aaa1:	0f 82 0e 01 00 00    	jb     66abb5 <<gpui_canvas::text::planner::Planner>::shape+0x1ee5>
  66aaa7:	48 8b bc 24 20 01 00 	mov    0x120(%rsp),%rdi
  66aaae:	00 
  66aaaf:	89 fa                	mov    %edi,%edx
  66aab1:	84 c9                	test   %cl,%cl
  66aab3:	0f 85 36 17 00 00    	jne    66c1ef <<gpui_canvas::text::planner::Planner>::shape+0x351f>
  66aab9:	44 39 ff             	cmp    %r15d,%edi
  66aabc:	75 11                	jne    66aacf <<gpui_canvas::text::planner::Planner>::shape+0x1dff>
  66aabe:	48 c7 84 24 38 01 00 	movq   $0x0,0x138(%rsp)
  66aac5:	00 00 00 00 00 
  66aaca:	e9 bd 00 00 00       	jmp    66ab8c <<gpui_canvas::text::planner::Planner>::shape+0x1ebc>
  66aacf:	48 8d 0c d5 00 00 00 	lea    0x0(,%rdx,8),%rcx
  66aad6:	00 
  66aad7:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  66aadb:	48 8d 7e ff          	lea    -0x1(%rsi),%rdi
  66aadf:	48 39 d7             	cmp    %rdx,%rdi
  66aae2:	75 10                	jne    66aaf4 <<gpui_canvas::text::planner::Planner>::shape+0x1e24>
  66aae4:	31 d2                	xor    %edx,%edx
  66aae6:	48 c7 84 24 38 01 00 	movq   $0x0,0x138(%rsp)
  66aaed:	00 00 00 00 00 
  66aaf2:	eb 67                	jmp    66ab5b <<gpui_canvas::text::planner::Planner>::shape+0x1e8b>
  66aaf4:	48 29 d6             	sub    %rdx,%rsi
  66aaf7:	48 89 f7             	mov    %rsi,%rdi
  66aafa:	48 83 e7 fe          	and    $0xfffffffffffffffe,%rdi
  66aafe:	48 8b 94 24 00 03 00 	mov    0x300(%rsp),%rdx
  66ab05:	00 
  66ab06:	4c 8d 04 0a          	lea    (%rdx,%rcx,1),%r8
  66ab0a:	31 d2                	xor    %edx,%edx
  66ab0c:	45 31 d2             	xor    %r10d,%r10d
  66ab0f:	41 bb 01 00 00 00    	mov    $0x1,%r11d
  66ab15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  66ab1c:	00 00 00 00 
  66ab20:	45 8b 48 de          	mov    -0x22(%r8),%r9d
  66ab24:	41 f6 40 e9 01       	testb  $0x1,-0x17(%r8)
  66ab29:	4d 0f 45 cb          	cmovne %r11,%r9
  66ab2d:	4d 01 d1             	add    %r10,%r9
  66ab30:	41 f6 40 01 01       	testb  $0x1,0x1(%r8)
  66ab35:	45 8b 50 f6          	mov    -0xa(%r8),%r10d
  66ab39:	4d 0f 45 d3          	cmovne %r11,%r10
  66ab3d:	4d 01 ca             	add    %r9,%r10
  66ab40:	48 83 c2 02          	add    $0x2,%rdx
  66ab44:	49 83 c0 30          	add    $0x30,%r8
  66ab48:	48 39 d7             	cmp    %rdx,%rdi
  66ab4b:	75 d3                	jne    66ab20 <<gpui_canvas::text::planner::Planner>::shape+0x1e50>
  66ab4d:	4c 89 94 24 38 01 00 	mov    %r10,0x138(%rsp)
  66ab54:	00 
  66ab55:	40 f6 c6 01          	test   $0x1,%sil
  66ab59:	74 31                	je     66ab8c <<gpui_canvas::text::planner::Planner>::shape+0x1ebc>
  66ab5b:	48 8b b4 24 38 01 00 	mov    0x138(%rsp),%rsi
  66ab62:	00 
  66ab63:	48 03 8c 24 d0 01 00 	add    0x1d0(%rsp),%rcx
  66ab6a:	00 
  66ab6b:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
  66ab6f:	f6 44 d1 17 01       	testb  $0x1,0x17(%rcx,%rdx,8)
  66ab74:	8b 54 d1 0c          	mov    0xc(%rcx,%rdx,8),%edx
  66ab78:	b9 01 00 00 00       	mov    $0x1,%ecx
  66ab7d:	48 0f 45 d1          	cmovne %rcx,%rdx
  66ab81:	48 01 f2             	add    %rsi,%rdx
  66ab84:	48 89 94 24 38 01 00 	mov    %rdx,0x138(%rsp)
  66ab8b:	00 
  66ab8c:	0f 57 c0             	xorps  %xmm0,%xmm0
  66ab8f:	f3 0f 11 84 24 c0 01 	movss  %xmm0,0x1c0(%rsp)
  66ab96:	00 00 
  66ab98:	b9 00 00 00 00       	mov    $0x0,%ecx
  66ab9d:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
  66aba2:	ba 00 00 00 00       	mov    $0x0,%edx
  66aba7:	48 39 c3             	cmp    %rax,%rbx
  66abaa:	0f 84 53 fb ff ff    	je     66a703 <<gpui_canvas::text::planner::Planner>::shape+0x1a33>
  66abb0:	e9 0e fa ff ff       	jmp    66a5c3 <<gpui_canvas::text::planner::Planner>::shape+0x18f3>
  66abb5:	b1 01                	mov    $0x1,%cl
  66abb7:	48 8b bc 24 20 01 00 	mov    0x120(%rsp),%rdi
  66abbe:	00 
  66abbf:	89 fa                	mov    %edi,%edx
  66abc1:	84 c9                	test   %cl,%cl
  66abc3:	0f 84 f0 fe ff ff    	je     66aab9 <<gpui_canvas::text::planner::Planner>::shape+0x1de9>
  66abc9:	e9 21 16 00 00       	jmp    66c1ef <<gpui_canvas::text::planner::Planner>::shape+0x351f>
  66abce:	0f 85 85 10 00 00    	jne    66bc59 <<gpui_canvas::text::planner::Planner>::shape+0x2f89>
  66abd4:	48 85 ed             	test   %rbp,%rbp
  66abd7:	0f 94 c2             	sete   %dl
  66abda:	74 1b                	je     66abf7 <<gpui_canvas::text::planner::Planner>::shape+0x1f27>
  66abdc:	48 39 cd             	cmp    %rcx,%rbp
  66abdf:	73 10                	jae    66abf1 <<gpui_canvas::text::planner::Planner>::shape+0x1f21>
  66abe1:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  66abe6:	80 3c 28 c0          	cmpb   $0xc0,(%rax,%rbp,1)
  66abea:	7d 0b                	jge    66abf7 <<gpui_canvas::text::planner::Planner>::shape+0x1f27>
  66abec:	e9 68 10 00 00       	jmp    66bc59 <<gpui_canvas::text::planner::Planner>::shape+0x2f89>
  66abf1:	0f 85 62 10 00 00    	jne    66bc59 <<gpui_canvas::text::planner::Planner>::shape+0x2f89>
  66abf7:	83 7c 24 5c 00       	cmpl   $0x0,0x5c(%rsp)
  66abfc:	0f 84 9a 00 00 00    	je     66ac9c <<gpui_canvas::text::planner::Planner>::shape+0x1fcc>
  66ac02:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  66ac08:	f3 0f 58 84 24 d8 00 	addss  0xd8(%rsp),%xmm0
  66ac0f:	00 00 
  66ac11:	f3 0f 11 44 24 0c    	movss  %xmm0,0xc(%rsp)
  66ac17:	66 0f 7e c1          	movd   %xmm0,%ecx
  66ac1b:	0f 28 84 24 a0 01 00 	movaps 0x1a0(%rsp),%xmm0
  66ac22:	00 
  66ac23:	0f 58 84 24 e0 03 00 	addps  0x3e0(%rsp),%xmm0
  66ac2a:	00 
  66ac2b:	0f c6 c0 55          	shufps $0x55,%xmm0,%xmm0
  66ac2f:	0f 29 84 24 a0 01 00 	movaps %xmm0,0x1a0(%rsp)
  66ac36:	00 
  66ac37:	66 0f 7e c0          	movd   %xmm0,%eax
  66ac3b:	81 e1 ff ff ff 7f    	and    $0x7fffffff,%ecx
  66ac41:	25 ff ff ff 7f       	and    $0x7fffffff,%eax
  66ac46:	3d 00 00 80 7f       	cmp    $0x7f800000,%eax
  66ac4b:	0f 9d c0             	setge  %al
  66ac4e:	81 f9 ff ff 7f 7f    	cmp    $0x7f7fffff,%ecx
  66ac54:	0f 8f 20 10 00 00    	jg     66bc7a <<gpui_canvas::text::planner::Planner>::shape+0x2faa>
  66ac5a:	84 c0                	test   %al,%al
  66ac5c:	0f 85 18 10 00 00    	jne    66bc7a <<gpui_canvas::text::planner::Planner>::shape+0x2faa>
  66ac62:	81 7c 24 5c ff ff 00 	cmpl   $0xffff,0x5c(%rsp)
  66ac69:	00 
  66ac6a:	0f 87 e9 0f 00 00    	ja     66bc59 <<gpui_canvas::text::planner::Planner>::shape+0x2f89>
  66ac70:	4c 89 cd             	mov    %r9,%rbp
  66ac73:	4c 8b b4 24 f8 00 00 	mov    0xf8(%rsp),%r14
  66ac7a:	00 
  66ac7b:	4c 3b b4 24 e8 00 00 	cmp    0xe8(%rsp),%r14
  66ac82:	00 
  66ac83:	0f 85 4e f8 ff ff    	jne    66a4d7 <<gpui_canvas::text::planner::Planner>::shape+0x1807>
  66ac89:	48 8d bc 24 e8 00 00 	lea    0xe8(%rsp),%rdi
  66ac90:	00 
  66ac91:	ff 15 a9 f2 11 00    	call   *0x11f2a9(%rip)        # 789f40 <_DYNAMIC+0x490>
  66ac97:	e9 3b f8 ff ff       	jmp    66a4d7 <<gpui_canvas::text::planner::Planner>::shape+0x1807>
  66ac9c:	4d 85 c9             	test   %r9,%r9
  66ac9f:	0f 84 af 00 00 00    	je     66ad54 <<gpui_canvas::text::planner::Planner>::shape+0x2084>
  66aca5:	49 39 c9             	cmp    %rcx,%r9
  66aca8:	0f 83 a0 00 00 00    	jae    66ad4e <<gpui_canvas::text::planner::Planner>::shape+0x207e>
  66acae:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  66acb3:	42 80 3c 08 bf       	cmpb   $0xbf,(%rax,%r9,1)
  66acb8:	0f 8f 96 00 00 00    	jg     66ad54 <<gpui_canvas::text::planner::Planner>::shape+0x2084>
  66acbe:	e9 63 10 00 00       	jmp    66bd26 <<gpui_canvas::text::planner::Planner>::shape+0x3056>
  66acc3:	48 8b 8c 24 20 01 00 	mov    0x120(%rsp),%rcx
  66acca:	00 
  66accb:	89 da                	mov    %ebx,%edx
  66accd:	48 8d 04 7f          	lea    (%rdi,%rdi,2),%rax
  66acd1:	48 8b b4 24 d0 01 00 	mov    0x1d0(%rsp),%rsi
  66acd8:	00 
  66acd9:	f3 0f 10 44 c6 10    	movss  0x10(%rsi,%rax,8),%xmm0
  66acdf:	0f 57 c9             	xorps  %xmm1,%xmm1
  66ace2:	0f 29 8c 24 a0 01 00 	movaps %xmm1,0x1a0(%rsp)
  66ace9:	00 
  66acea:	bb 04 00 00 00       	mov    $0x4,%ebx
  66acef:	b8 04 00 00 00       	mov    $0x4,%eax
  66acf4:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  66acfb:	00 
  66acfc:	48 89 8c 24 20 01 00 	mov    %rcx,0x120(%rsp)
  66ad03:	00 
  66ad04:	f3 0f 11 84 24 b8 01 	movss  %xmm0,0x1b8(%rsp)
  66ad0b:	00 00 
  66ad0d:	f3 0f 11 44 24 08    	movss  %xmm0,0x8(%rsp)
  66ad13:	89 94 24 bc 01 00 00 	mov    %edx,0x1bc(%rsp)
  66ad1a:	89 54 24 5c          	mov    %edx,0x5c(%rsp)
  66ad1e:	0f 57 c0             	xorps  %xmm0,%xmm0
  66ad21:	0f 29 84 24 30 02 00 	movaps %xmm0,0x230(%rsp)
  66ad28:	00 
  66ad29:	83 bc 24 dc 00 00 00 	cmpl   $0x0,0xdc(%rsp)
  66ad30:	00 
  66ad31:	0f 85 4c f8 ff ff    	jne    66a583 <<gpui_canvas::text::planner::Planner>::shape+0x18b3>
  66ad37:	e9 b8 f8 ff ff       	jmp    66a5f4 <<gpui_canvas::text::planner::Planner>::shape+0x1924>
  66ad3c:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  66ad41:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  66ad48:	00 
  66ad49:	e9 75 f8 ff ff       	jmp    66a5c3 <<gpui_canvas::text::planner::Planner>::shape+0x18f3>
  66ad4e:	0f 85 d2 0f 00 00    	jne    66bd26 <<gpui_canvas::text::planner::Planner>::shape+0x3056>
  66ad54:	48 85 ed             	test   %rbp,%rbp
  66ad57:	4c 89 8c 24 f8 02 00 	mov    %r9,0x2f8(%rsp)
  66ad5e:	00 
  66ad5f:	74 1b                	je     66ad7c <<gpui_canvas::text::planner::Planner>::shape+0x20ac>
  66ad61:	48 39 cd             	cmp    %rcx,%rbp
  66ad64:	73 10                	jae    66ad76 <<gpui_canvas::text::planner::Planner>::shape+0x20a6>
  66ad66:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  66ad6b:	80 3c 28 c0          	cmpb   $0xc0,(%rax,%rbp,1)
  66ad6f:	7d 0b                	jge    66ad7c <<gpui_canvas::text::planner::Planner>::shape+0x20ac>
  66ad71:	e9 b6 0f 00 00       	jmp    66bd2c <<gpui_canvas::text::planner::Planner>::shape+0x305c>
  66ad76:	0f 85 b0 0f 00 00    	jne    66bd2c <<gpui_canvas::text::planner::Planner>::shape+0x305c>
  66ad7c:	89 54 24 0c          	mov    %edx,0xc(%rsp)
  66ad80:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  66ad85:	4e 8d 34 08          	lea    (%rax,%r9,1),%r14
  66ad89:	48 01 e8             	add    %rbp,%rax
  66ad8c:	48 89 84 24 a0 01 00 	mov    %rax,0x1a0(%rsp)
  66ad93:	00 
  66ad94:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  66ad9b:	00 00 00 00 00 
  66ada0:	4c 3b b4 24 a0 01 00 	cmp    0x1a0(%rsp),%r14
  66ada7:	00 
  66ada8:	0f 84 8c 00 00 00    	je     66ae3a <<gpui_canvas::text::planner::Planner>::shape+0x216a>
  66adae:	41 0f b6 36          	movzbl (%r14),%esi
  66adb2:	40 84 f6             	test   %sil,%sil
  66adb5:	78 09                	js     66adc0 <<gpui_canvas::text::planner::Planner>::shape+0x20f0>
  66adb7:	49 ff c6             	inc    %r14
  66adba:	eb 64                	jmp    66ae20 <<gpui_canvas::text::planner::Planner>::shape+0x2150>
  66adbc:	0f 1f 40 00          	nopl   0x0(%rax)
  66adc0:	89 f0                	mov    %esi,%eax
  66adc2:	83 e0 1f             	and    $0x1f,%eax
  66adc5:	41 0f b6 56 01       	movzbl 0x1(%r14),%edx
  66adca:	83 e2 3f             	and    $0x3f,%edx
  66adcd:	40 80 fe df          	cmp    $0xdf,%sil
  66add1:	76 2e                	jbe    66ae01 <<gpui_canvas::text::planner::Planner>::shape+0x2131>
  66add3:	41 0f b6 4e 02       	movzbl 0x2(%r14),%ecx
  66add8:	c1 e2 06             	shl    $0x6,%edx
  66addb:	83 e1 3f             	and    $0x3f,%ecx
  66adde:	09 d1                	or     %edx,%ecx
  66ade0:	40 80 fe f0          	cmp    $0xf0,%sil
  66ade4:	72 28                	jb     66ae0e <<gpui_canvas::text::planner::Planner>::shape+0x213e>
  66ade6:	41 0f b6 76 03       	movzbl 0x3(%r14),%esi
  66adeb:	49 83 c6 04          	add    $0x4,%r14
  66adef:	83 e0 07             	and    $0x7,%eax
  66adf2:	c1 e0 12             	shl    $0x12,%eax
  66adf5:	c1 e1 06             	shl    $0x6,%ecx
  66adf8:	83 e6 3f             	and    $0x3f,%esi
  66adfb:	09 ce                	or     %ecx,%esi
  66adfd:	09 c6                	or     %eax,%esi
  66adff:	eb 1f                	jmp    66ae20 <<gpui_canvas::text::planner::Planner>::shape+0x2150>
  66ae01:	49 83 c6 02          	add    $0x2,%r14
  66ae05:	c1 e0 06             	shl    $0x6,%eax
  66ae08:	09 d0                	or     %edx,%eax
  66ae0a:	89 c6                	mov    %eax,%esi
  66ae0c:	eb 12                	jmp    66ae20 <<gpui_canvas::text::planner::Planner>::shape+0x2150>
  66ae0e:	49 83 c6 03          	add    $0x3,%r14
  66ae12:	c1 e0 0c             	shl    $0xc,%eax
  66ae15:	09 c1                	or     %eax,%ecx
  66ae17:	89 ce                	mov    %ecx,%esi
  66ae19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  66ae20:	48 8d 3d d9 42 11 00 	lea    0x1142d9(%rip),%rdi        # 77f100 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0x30>
  66ae27:	ff 15 3b f2 11 00    	call   *0x11f23b(%rip)        # 78a068 <_DYNAMIC+0x5b8>
  66ae2d:	84 c0                	test   %al,%al
  66ae2f:	0f 85 6b ff ff ff    	jne    66ada0 <<gpui_canvas::text::planner::Planner>::shape+0x20d0>
  66ae35:	e9 fa 0e 00 00       	jmp    66bd34 <<gpui_canvas::text::planner::Planner>::shape+0x3064>
  66ae3a:	31 c0                	xor    %eax,%eax
  66ae3c:	0f 57 c0             	xorps  %xmm0,%xmm0
  66ae3f:	f3 0f 10 4c 24 08    	movss  0x8(%rsp),%xmm1
  66ae45:	0f 2e c8             	ucomiss %xmm0,%xmm1
  66ae48:	4c 8b b4 24 e8 01 00 	mov    0x1e8(%rsp),%r14
  66ae4f:	00 
  66ae50:	f3 0f 10 84 24 c4 01 	movss  0x1c4(%rsp),%xmm0
  66ae57:	00 00 
  66ae59:	0f 85 d5 0e 00 00    	jne    66bd34 <<gpui_canvas::text::planner::Planner>::shape+0x3064>
  66ae5f:	0f 8b e0 f6 ff ff    	jnp    66a545 <<gpui_canvas::text::planner::Planner>::shape+0x1875>
  66ae65:	e9 ca 0e 00 00       	jmp    66bd34 <<gpui_canvas::text::planner::Planner>::shape+0x3064>
  66ae6a:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  66ae6f:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  66ae76:	00 
  66ae77:	48 89 8c 24 20 01 00 	mov    %rcx,0x120(%rsp)
  66ae7e:	00 
  66ae7f:	e9 3f f7 ff ff       	jmp    66a5c3 <<gpui_canvas::text::planner::Planner>::shape+0x18f3>
  66ae84:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
  66ae8b:	00 
  66ae8c:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
  66ae93:	00 
  66ae94:	e8 77 1e 00 00       	call   66cd10 <<core::iter::adapters::flatten::FlattenCompat<core::iter::adapters::map::Map<core::ops::range::Range<u32>, <parley::layout::run::Run<()>>::glyph_source_ranges::{closure#0}>, core::iter::sources::repeat_n::RepeatN<core::ops::range::Range<usize>>> as core::iter::traits::iterator::Iterator>::next>
  66ae99:	48 83 bc 24 88 00 00 	cmpq   $0x0,0x88(%rsp)
  66aea0:	00 00 
  66aea2:	0f 85 b1 0d 00 00    	jne    66bc59 <<gpui_canvas::text::planner::Planner>::shape+0x2f89>
  66aea8:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
  66aeaf:	00 
  66aeb0:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  66aeb4:	0f 84 bb f1 ff ff    	je     66a075 <<gpui_canvas::text::planner::Planner>::shape+0x13a5>
  66aeba:	48 8b 8c 24 00 01 00 	mov    0x100(%rsp),%rcx
  66aec1:	00 
  66aec2:	48 3b 4c 24 30       	cmp    0x30(%rsp),%rcx
  66aec7:	48 8b 8c 24 10 01 00 	mov    0x110(%rsp),%rcx
  66aece:	00 
  66aecf:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  66aed4:	75 0f                	jne    66aee5 <<gpui_canvas::text::planner::Planner>::shape+0x2215>
  66aed6:	31 db                	xor    %ebx,%ebx
  66aed8:	45 31 f6             	xor    %r14d,%r14d
  66aedb:	48 8b b4 24 48 02 00 	mov    0x248(%rsp),%rsi
  66aee2:	00 
  66aee3:	eb 6d                	jmp    66af52 <<gpui_canvas::text::planner::Planner>::shape+0x2282>
  66aee5:	48 8b bc 24 e8 02 00 	mov    0x2e8(%rsp),%rdi
  66aeec:	00 
  66aeed:	48 85 ff             	test   %rdi,%rdi
  66aef0:	48 8b b4 24 48 02 00 	mov    0x248(%rsp),%rsi
  66aef7:	00 
  66aef8:	48 0f 44 fe          	cmove  %rsi,%rdi
  66aefc:	48 8b 1f             	mov    (%rdi),%rbx
  66aeff:	4c 8b 77 08          	mov    0x8(%rdi),%r14
  66af03:	4c 39 f3             	cmp    %r14,%rbx
  66af06:	0f 87 4d 0d 00 00    	ja     66bc59 <<gpui_canvas::text::planner::Planner>::shape+0x2f89>
  66af0c:	48 85 db             	test   %rbx,%rbx
  66af0f:	74 10                	je     66af21 <<gpui_canvas::text::planner::Planner>::shape+0x2251>
  66af11:	48 39 cb             	cmp    %rcx,%rbx
  66af14:	73 0f                	jae    66af25 <<gpui_canvas::text::planner::Planner>::shape+0x2255>
  66af16:	80 3c 1a bf          	cmpb   $0xbf,(%rdx,%rbx,1)
  66af1a:	7f 12                	jg     66af2e <<gpui_canvas::text::planner::Planner>::shape+0x225e>
  66af1c:	e9 38 0d 00 00       	jmp    66bc59 <<gpui_canvas::text::planner::Planner>::shape+0x2f89>
  66af21:	31 db                	xor    %ebx,%ebx
  66af23:	eb 09                	jmp    66af2e <<gpui_canvas::text::planner::Planner>::shape+0x225e>
  66af25:	48 89 cb             	mov    %rcx,%rbx
  66af28:	0f 85 2b 0d 00 00    	jne    66bc59 <<gpui_canvas::text::planner::Planner>::shape+0x2f89>
  66af2e:	4d 85 f6             	test   %r14,%r14
  66af31:	74 11                	je     66af44 <<gpui_canvas::text::planner::Planner>::shape+0x2274>
  66af33:	49 39 ce             	cmp    %rcx,%r14
  66af36:	73 11                	jae    66af49 <<gpui_canvas::text::planner::Planner>::shape+0x2279>
  66af38:	42 80 3c 32 c0       	cmpb   $0xc0,(%rdx,%r14,1)
  66af3d:	7d 13                	jge    66af52 <<gpui_canvas::text::planner::Planner>::shape+0x2282>
  66af3f:	e9 15 0d 00 00       	jmp    66bc59 <<gpui_canvas::text::planner::Planner>::shape+0x2f89>
  66af44:	45 31 f6             	xor    %r14d,%r14d
  66af47:	eb 09                	jmp    66af52 <<gpui_canvas::text::planner::Planner>::shape+0x2282>
  66af49:	49 89 ce             	mov    %rcx,%r14
  66af4c:	0f 85 07 0d 00 00    	jne    66bc59 <<gpui_canvas::text::planner::Planner>::shape+0x2f89>
  66af52:	8b 8c 24 f8 00 00 00 	mov    0xf8(%rsp),%ecx
  66af59:	89 4c 24 60          	mov    %ecx,0x60(%rsp)
  66af5d:	0f b6 ae 8c 00 00 00 	movzbl 0x8c(%rsi),%ebp
  66af64:	4c 8b bc 24 60 01 00 	mov    0x160(%rsp),%r15
  66af6b:	00 
  66af6c:	49 39 c7             	cmp    %rax,%r15
  66af6f:	75 0e                	jne    66af7f <<gpui_canvas::text::planner::Planner>::shape+0x22af>
  66af71:	48 8d bc 24 50 01 00 	lea    0x150(%rsp),%rdi
  66af78:	00 
  66af79:	ff 15 d1 ef 11 00    	call   *0x11efd1(%rip)        # 789f50 <_DYNAMIC+0x4a0>
  66af7f:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  66af84:	01 c3                	add    %eax,%ebx
  66af86:	41 01 c6             	add    %eax,%r14d
  66af89:	40 80 e5 01          	and    $0x1,%bpl
  66af8d:	48 8b 84 24 58 01 00 	mov    0x158(%rsp),%rax
  66af94:	00 
  66af95:	4b 8d 0c 7f          	lea    (%r15,%r15,2),%rcx
  66af99:	89 1c c8             	mov    %ebx,(%rax,%rcx,8)
  66af9c:	44 89 74 c8 04       	mov    %r14d,0x4(%rax,%rcx,8)
  66afa1:	48 8b 94 24 f0 02 00 	mov    0x2f0(%rsp),%rdx
  66afa8:	00 
  66afa9:	89 54 c8 08          	mov    %edx,0x8(%rax,%rcx,8)
  66afad:	8b 54 24 60          	mov    0x60(%rsp),%edx
  66afb1:	89 54 c8 0c          	mov    %edx,0xc(%rax,%rcx,8)
  66afb5:	48 8b 94 24 58 02 00 	mov    0x258(%rsp),%rdx
  66afbc:	00 
  66afbd:	89 54 c8 10          	mov    %edx,0x10(%rax,%rcx,8)
  66afc1:	48 8b 94 24 60 02 00 	mov    0x260(%rsp),%rdx
  66afc8:	00 
  66afc9:	88 54 c8 14          	mov    %dl,0x14(%rax,%rcx,8)
  66afcd:	40 88 6c c8 15       	mov    %bpl,0x15(%rax,%rcx,8)
  66afd2:	49 ff c7             	inc    %r15
  66afd5:	4c 89 bc 24 60 01 00 	mov    %r15,0x160(%rsp)
  66afdc:	00 
  66afdd:	e9 93 f0 ff ff       	jmp    66a075 <<gpui_canvas::text::planner::Planner>::shape+0x13a5>
  66afe2:	48 8b 84 24 08 03 00 	mov    0x308(%rsp),%rax
  66afe9:	00 
  66afea:	48 39 84 24 c8 00 00 	cmp    %rax,0xc8(%rsp)
  66aff1:	00 
  66aff2:	48 8b 6c 24 30       	mov    0x30(%rsp),%rbp
  66aff7:	48 8b 9c 24 00 01 00 	mov    0x100(%rsp),%rbx
  66affe:	00 
  66afff:	0f 85 02 ec ff ff    	jne    669c07 <<gpui_canvas::text::planner::Planner>::shape+0xf37>
  66b005:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  66b00c:	00 ff 
  66b00e:	0f 84 d9 06 00 00    	je     66b6ed <<gpui_canvas::text::planner::Planner>::shape+0x2a1d>
  66b014:	48 83 bc 24 80 01 00 	cmpq   $0xffffffffffffffff,0x180(%rsp)
  66b01b:	00 ff 
  66b01d:	0f 84 ca 06 00 00    	je     66b6ed <<gpui_canvas::text::planner::Planner>::shape+0x2a1d>
  66b023:	48 89 ac 24 88 00 00 	mov    %rbp,0x88(%rsp)
  66b02a:	00 
  66b02b:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
  66b031:	f3 0f 11 84 24 e0 00 	movss  %xmm0,0xe0(%rsp)
  66b038:	00 00 
  66b03a:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  66b03f:	48 89 84 24 40 03 00 	mov    %rax,0x340(%rsp)
  66b046:	00 
  66b047:	48 8d 84 24 e0 00 00 	lea    0xe0(%rsp),%rax
  66b04e:	00 
  66b04f:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
  66b056:	00 
  66b057:	48 8d 84 24 88 00 00 	lea    0x88(%rsp),%rax
  66b05e:	00 
  66b05f:	48 89 84 24 50 03 00 	mov    %rax,0x350(%rsp)
  66b066:	00 
  66b067:	48 8d 84 24 80 01 00 	lea    0x180(%rsp),%rax
  66b06e:	00 
  66b06f:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
  66b076:	00 
  66b077:	48 03 9c 24 48 01 00 	add    0x148(%rsp),%rbx
  66b07e:	00 
  66b07f:	48 c7 84 24 10 07 00 	movq   $0x0,0x710(%rsp)
  66b086:	00 00 00 00 00 
  66b08b:	48 c7 84 24 18 07 00 	movq   $0x8,0x718(%rsp)
  66b092:	00 08 00 00 00 
  66b097:	48 c7 84 24 20 07 00 	movq   $0x0,0x720(%rsp)
  66b09e:	00 00 00 00 00 
  66b0a3:	c7 84 24 30 07 00 00 	movl   $0xffffffff,0x730(%rsp)
  66b0aa:	ff ff ff ff 
  66b0ae:	4c 8b 7c 24 10       	mov    0x10(%rsp),%r15
  66b0b3:	4c 89 bc 24 38 07 00 	mov    %r15,0x738(%rsp)
  66b0ba:	00 
  66b0bb:	48 89 9c 24 40 07 00 	mov    %rbx,0x740(%rsp)
  66b0c2:	00 
  66b0c3:	48 c7 84 24 48 07 00 	movq   $0x0,0x748(%rsp)
  66b0ca:	00 00 00 00 00 
  66b0cf:	48 8d 05 9a 41 11 00 	lea    0x11419a(%rip),%rax        # 77f270 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0x1a0>
  66b0d6:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
  66b0dd:	00 
  66b0de:	48 8d 05 eb b7 ff ff 	lea    -0x4815(%rip),%rax        # 6668d0 <icu_segmenter::rule_segmenter_v1::empty_handle_complex::<icu_segmenter::scaffold::Utf8>>
  66b0e5:	48 89 84 24 58 07 00 	mov    %rax,0x758(%rsp)
  66b0ec:	00 
  66b0ed:	4c 8b b4 24 10 01 00 	mov    0x110(%rsp),%r14
  66b0f4:	00 
  66b0f5:	4c 89 b4 24 60 07 00 	mov    %r14,0x760(%rsp)
  66b0fc:	00 
  66b0fd:	48 c7 84 24 68 07 00 	movq   $0x0,0x768(%rsp)
  66b104:	00 00 00 00 00 
  66b109:	48 c7 84 24 98 07 00 	movq   $0x0,0x798(%rsp)
  66b110:	00 00 00 00 00 
  66b115:	c6 84 24 a0 07 00 00 	movb   $0x0,0x7a0(%rsp)
  66b11c:	00 
  66b11d:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  66b124:	00 
  66b125:	e8 46 6a 00 00       	call   671b70 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  66b12a:	48 83 f8 01          	cmp    $0x1,%rax
  66b12e:	0f 85 9b 01 00 00    	jne    66b2cf <<gpui_canvas::text::planner::Planner>::shape+0x25ff>
  66b134:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  66b13b:	00 
  66b13c:	e8 2f 6a 00 00       	call   671b70 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  66b141:	48 83 f8 01          	cmp    $0x1,%rax
  66b145:	0f 85 84 01 00 00    	jne    66b2cf <<gpui_canvas::text::planner::Planner>::shape+0x25ff>
  66b14b:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  66b152:	00 
  66b153:	e8 18 6a 00 00       	call   671b70 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  66b158:	48 83 f8 01          	cmp    $0x1,%rax
  66b15c:	0f 85 6d 01 00 00    	jne    66b2cf <<gpui_canvas::text::planner::Planner>::shape+0x25ff>
  66b162:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  66b169:	00 
  66b16a:	e8 01 6a 00 00       	call   671b70 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  66b16f:	48 83 f8 01          	cmp    $0x1,%rax
  66b173:	0f 85 56 01 00 00    	jne    66b2cf <<gpui_canvas::text::planner::Planner>::shape+0x25ff>
  66b179:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  66b180:	00 
  66b181:	e8 ea 69 00 00       	call   671b70 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  66b186:	48 83 f8 01          	cmp    $0x1,%rax
  66b18a:	0f 85 3f 01 00 00    	jne    66b2cf <<gpui_canvas::text::planner::Planner>::shape+0x25ff>
  66b190:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  66b197:	00 
  66b198:	e8 d3 69 00 00       	call   671b70 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  66b19d:	48 83 f8 01          	cmp    $0x1,%rax
  66b1a1:	0f 85 28 01 00 00    	jne    66b2cf <<gpui_canvas::text::planner::Planner>::shape+0x25ff>
  66b1a7:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  66b1ae:	00 
  66b1af:	e8 bc 69 00 00       	call   671b70 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  66b1b4:	48 83 f8 01          	cmp    $0x1,%rax
  66b1b8:	0f 85 11 01 00 00    	jne    66b2cf <<gpui_canvas::text::planner::Planner>::shape+0x25ff>
  66b1be:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  66b1c5:	00 
  66b1c6:	e8 a5 69 00 00       	call   671b70 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  66b1cb:	a8 01                	test   $0x1,%al
  66b1cd:	0f 84 fc 00 00 00    	je     66b2cf <<gpui_canvas::text::planner::Planner>::shape+0x25ff>
  66b1d3:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  66b1da:	00 
  66b1db:	e8 90 69 00 00       	call   671b70 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  66b1e0:	48 83 f8 01          	cmp    $0x1,%rax
  66b1e4:	0f 85 e5 00 00 00    	jne    66b2cf <<gpui_canvas::text::planner::Planner>::shape+0x25ff>
  66b1ea:	48 8b b4 24 10 07 00 	mov    0x710(%rsp),%rsi
  66b1f1:	00 
  66b1f2:	48 85 f6             	test   %rsi,%rsi
  66b1f5:	74 17                	je     66b20e <<gpui_canvas::text::planner::Planner>::shape+0x253e>
  66b1f7:	48 8b bc 24 18 07 00 	mov    0x718(%rsp),%rdi
  66b1fe:	00 
  66b1ff:	48 c1 e6 03          	shl    $0x3,%rsi
  66b203:	ba 08 00 00 00       	mov    $0x8,%edx
  66b208:	ff 15 da ea 11 00    	call   *0x11eada(%rip)        # 789ce8 <_DYNAMIC+0x238>
  66b20e:	48 c7 84 24 10 07 00 	movq   $0x0,0x710(%rsp)
  66b215:	00 00 00 00 00 
  66b21a:	48 c7 84 24 18 07 00 	movq   $0x8,0x718(%rsp)
  66b221:	00 08 00 00 00 
  66b226:	48 c7 84 24 20 07 00 	movq   $0x0,0x720(%rsp)
  66b22d:	00 00 00 00 00 
  66b232:	c7 84 24 30 07 00 00 	movl   $0xffffffff,0x730(%rsp)
  66b239:	ff ff ff ff 
  66b23d:	4c 89 bc 24 38 07 00 	mov    %r15,0x738(%rsp)
  66b244:	00 
  66b245:	48 89 9c 24 40 07 00 	mov    %rbx,0x740(%rsp)
  66b24c:	00 
  66b24d:	48 c7 84 24 48 07 00 	movq   $0x0,0x748(%rsp)
  66b254:	00 00 00 00 00 
  66b259:	48 8d 05 10 40 11 00 	lea    0x114010(%rip),%rax        # 77f270 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0x1a0>
  66b260:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
  66b267:	00 
  66b268:	48 8d 05 61 b6 ff ff 	lea    -0x499f(%rip),%rax        # 6668d0 <icu_segmenter::rule_segmenter_v1::empty_handle_complex::<icu_segmenter::scaffold::Utf8>>
  66b26f:	48 89 84 24 58 07 00 	mov    %rax,0x758(%rsp)
  66b276:	00 
  66b277:	4c 89 b4 24 60 07 00 	mov    %r14,0x760(%rsp)
  66b27e:	00 
  66b27f:	48 c7 84 24 68 07 00 	movq   $0x0,0x768(%rsp)
  66b286:	00 00 00 00 00 
  66b28b:	48 c7 84 24 98 07 00 	movq   $0x0,0x798(%rsp)
  66b292:	00 00 00 00 00 
  66b297:	c6 84 24 a0 07 00 00 	movb   $0x0,0x7a0(%rsp)
  66b29e:	00 
  66b29f:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  66b2a4:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
  66b2ab:	00 
  66b2ac:	f3 0f 10 05 18 25 9b 	movss  -0x64dae8(%rip),%xmm0        # 1d7cc <GCC_except_table0+0x24>
  66b2b3:	ff 
  66b2b4:	48 8d 94 24 40 03 00 	lea    0x340(%rsp),%rdx
  66b2bb:	00 
  66b2bc:	e8 5f b3 00 00       	call   676620 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>>
  66b2c1:	83 f8 ff             	cmp    $0xffffffff,%eax
  66b2c4:	0f 84 23 04 00 00    	je     66b6ed <<gpui_canvas::text::planner::Planner>::shape+0x2a1d>
  66b2ca:	e9 6d 0f 00 00       	jmp    66c23c <<gpui_canvas::text::planner::Planner>::shape+0x356c>
  66b2cf:	48 8b b4 24 10 07 00 	mov    0x710(%rsp),%rsi
  66b2d6:	00 
  66b2d7:	48 85 f6             	test   %rsi,%rsi
  66b2da:	74 17                	je     66b2f3 <<gpui_canvas::text::planner::Planner>::shape+0x2623>
  66b2dc:	48 8b bc 24 18 07 00 	mov    0x718(%rsp),%rdi
  66b2e3:	00 
  66b2e4:	48 c1 e6 03          	shl    $0x3,%rsi
  66b2e8:	ba 08 00 00 00       	mov    $0x8,%edx
  66b2ed:	ff 15 f5 e9 11 00    	call   *0x11e9f5(%rip)        # 789ce8 <_DYNAMIC+0x238>
  66b2f3:	48 c7 84 24 10 07 00 	movq   $0x0,0x710(%rsp)
  66b2fa:	00 00 00 00 00 
  66b2ff:	48 c7 84 24 18 07 00 	movq   $0x8,0x718(%rsp)
  66b306:	00 08 00 00 00 
  66b30b:	48 c7 84 24 20 07 00 	movq   $0x0,0x720(%rsp)
  66b312:	00 00 00 00 00 
  66b317:	c7 84 24 30 07 00 00 	movl   $0xffffffff,0x730(%rsp)
  66b31e:	ff ff ff ff 
  66b322:	4c 89 bc 24 38 07 00 	mov    %r15,0x738(%rsp)
  66b329:	00 
  66b32a:	48 89 9c 24 40 07 00 	mov    %rbx,0x740(%rsp)
  66b331:	00 
  66b332:	48 c7 84 24 48 07 00 	movq   $0x0,0x748(%rsp)
  66b339:	00 00 00 00 00 
  66b33e:	48 8d 05 2b 3f 11 00 	lea    0x113f2b(%rip),%rax        # 77f270 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0x1a0>
  66b345:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
  66b34c:	00 
  66b34d:	48 8d 05 7c b5 ff ff 	lea    -0x4a84(%rip),%rax        # 6668d0 <icu_segmenter::rule_segmenter_v1::empty_handle_complex::<icu_segmenter::scaffold::Utf8>>
  66b354:	48 89 84 24 58 07 00 	mov    %rax,0x758(%rsp)
  66b35b:	00 
  66b35c:	4c 89 b4 24 60 07 00 	mov    %r14,0x760(%rsp)
  66b363:	00 
  66b364:	48 c7 84 24 68 07 00 	movq   $0x0,0x768(%rsp)
  66b36b:	00 00 00 00 00 
  66b370:	48 c7 84 24 98 07 00 	movq   $0x0,0x798(%rsp)
  66b377:	00 00 00 00 00 
  66b37c:	c6 84 24 a0 07 00 00 	movb   $0x0,0x7a0(%rsp)
  66b383:	00 
  66b384:	eb 42                	jmp    66b3c8 <<gpui_canvas::text::planner::Planner>::shape+0x26f8>
  66b386:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  66b38d:	00 00 00 
  66b390:	0f 28 84 24 00 01 00 	movaps 0x100(%rsp),%xmm0
  66b397:	00 
  66b398:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
  66b39d:	48 8b 84 24 88 01 00 	mov    0x188(%rsp),%rax
  66b3a4:	00 
  66b3a5:	48 8d 0c 5b          	lea    (%rbx,%rbx,2),%rcx
  66b3a9:	44 89 3c 88          	mov    %r15d,(%rax,%rcx,4)
  66b3ad:	0f 28 44 24 30       	movaps 0x30(%rsp),%xmm0
  66b3b2:	f3 0f 11 44 88 04    	movss  %xmm0,0x4(%rax,%rcx,4)
  66b3b8:	40 88 6c 88 08       	mov    %bpl,0x8(%rax,%rcx,4)
  66b3bd:	48 ff c3             	inc    %rbx
  66b3c0:	48 89 9c 24 90 01 00 	mov    %rbx,0x190(%rsp)
  66b3c7:	00 
  66b3c8:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  66b3cf:	00 
  66b3d0:	e8 9b 67 00 00       	call   671b70 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  66b3d5:	48 83 f8 01          	cmp    $0x1,%rax
  66b3d9:	0f 85 ea 02 00 00    	jne    66b6c9 <<gpui_canvas::text::planner::Planner>::shape+0x29f9>
  66b3df:	49 89 d6             	mov    %rdx,%r14
  66b3e2:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  66b3e7:	48 89 d6             	mov    %rdx,%rsi
  66b3ea:	ba 01 00 00 00       	mov    $0x1,%edx
  66b3ef:	e8 fc 37 01 00       	call   67ebf0 <<parley::editing::cursor::Cursor>::from_byte_index::<()>>
  66b3f4:	48 89 c3             	mov    %rax,%rbx
  66b3f7:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
  66b3fe:	00 
  66b3ff:	80 e2 01             	and    $0x1,%dl
  66b402:	88 94 24 a0 03 00 00 	mov    %dl,0x3a0(%rsp)
  66b409:	4c 39 f0             	cmp    %r14,%rax
  66b40c:	0f 85 ae 00 00 00    	jne    66b4c0 <<gpui_canvas::text::planner::Planner>::shape+0x27f0>
  66b412:	48 8d bc 24 c0 04 00 	lea    0x4c0(%rsp),%rdi
  66b419:	00 
  66b41a:	48 8d b4 24 98 03 00 	lea    0x398(%rsp),%rsi
  66b421:	00 
  66b422:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  66b427:	f3 0f 10 05 9d 23 9b 	movss  -0x64dc63(%rip),%xmm0        # 1d7cc <GCC_except_table0+0x24>
  66b42e:	ff 
  66b42f:	e8 7c 38 01 00       	call   67ecb0 <<parley::editing::cursor::Cursor>::geometry::<()>>
  66b434:	f3 0f 10 84 24 e0 00 	movss  0xe0(%rsp),%xmm0
  66b43b:	00 00 
  66b43d:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
  66b441:	f2 0f 58 84 24 c8 04 	addsd  0x4c8(%rsp),%xmm0
  66b448:	00 00 
  66b44a:	66 0f 28 8c 24 c0 04 	movapd 0x4c0(%rsp),%xmm1
  66b451:	00 00 
  66b453:	66 0f 28 94 24 d0 04 	movapd 0x4d0(%rsp),%xmm2
  66b45a:	00 00 
  66b45c:	66 0f 5c d1          	subpd  %xmm1,%xmm2
  66b460:	66 0f 14 c8          	unpcklpd %xmm0,%xmm1
  66b464:	66 0f 5a c9          	cvtpd2ps %xmm1,%xmm1
  66b468:	66 0f 5a d2          	cvtpd2ps %xmm2,%xmm2
  66b46c:	66 0f 29 4c 24 30    	movapd %xmm1,0x30(%rsp)
  66b472:	66 0f 29 94 24 10 01 	movapd %xmm2,0x110(%rsp)
  66b479:	00 00 
  66b47b:	66 0f 14 ca          	unpcklpd %xmm2,%xmm1
  66b47f:	66 0f 54 0d 79 a0 9b 	andpd  -0x645f87(%rip),%xmm1        # 25500 <anon.1508e9dce0c1a49d095b8c30671814b4.0.llvm.16300762181250184790+0x7e0>
  66b486:	ff 
  66b487:	66 0f 66 0d 41 9a 9b 	pcmpgtd -0x6465bf(%rip),%xmm1        # 24ed0 <anon.1508e9dce0c1a49d095b8c30671814b4.0.llvm.16300762181250184790+0x1b0>
  66b48e:	ff 
  66b48f:	0f 50 c1             	movmskps %xmm1,%eax
  66b492:	85 c0                	test   %eax,%eax
  66b494:	0f 85 73 07 00 00    	jne    66bc0d <<gpui_canvas::text::planner::Planner>::shape+0x2f3d>
  66b49a:	f2 0f 5a c0          	cvtsd2ss %xmm0,%xmm0
  66b49e:	f3 0f 11 44 24 10    	movss  %xmm0,0x10(%rsp)
  66b4a4:	0f 28 84 24 10 01 00 	movaps 0x110(%rsp),%xmm0
  66b4ab:	00 
  66b4ac:	0f c6 c0 55          	shufps $0x55,%xmm0,%xmm0
  66b4b0:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
  66b4b5:	eb 09                	jmp    66b4c0 <<gpui_canvas::text::planner::Planner>::shape+0x27f0>
  66b4b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  66b4be:	00 00 
  66b4c0:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  66b4c5:	4c 89 f6             	mov    %r14,%rsi
  66b4c8:	31 d2                	xor    %edx,%edx
  66b4ca:	e8 21 37 01 00       	call   67ebf0 <<parley::editing::cursor::Cursor>::from_byte_index::<()>>
  66b4cf:	48 89 c5             	mov    %rax,%rbp
  66b4d2:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
  66b4d9:	00 
  66b4da:	80 e2 01             	and    $0x1,%dl
  66b4dd:	88 94 24 a0 03 00 00 	mov    %dl,0x3a0(%rsp)
  66b4e4:	4c 39 f0             	cmp    %r14,%rax
  66b4e7:	0f 85 23 01 00 00    	jne    66b610 <<gpui_canvas::text::planner::Planner>::shape+0x2940>
  66b4ed:	48 8d bc 24 c0 04 00 	lea    0x4c0(%rsp),%rdi
  66b4f4:	00 
  66b4f5:	48 8d b4 24 98 03 00 	lea    0x398(%rsp),%rsi
  66b4fc:	00 
  66b4fd:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  66b502:	f3 0f 10 05 c2 22 9b 	movss  -0x64dd3e(%rip),%xmm0        # 1d7cc <GCC_except_table0+0x24>
  66b509:	ff 
  66b50a:	e8 a1 37 01 00       	call   67ecb0 <<parley::editing::cursor::Cursor>::geometry::<()>>
  66b50f:	f3 0f 10 84 24 e0 00 	movss  0xe0(%rsp),%xmm0
  66b516:	00 00 
  66b518:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
  66b51c:	f2 0f 58 84 24 c8 04 	addsd  0x4c8(%rsp),%xmm0
  66b523:	00 00 
  66b525:	66 0f 28 8c 24 c0 04 	movapd 0x4c0(%rsp),%xmm1
  66b52c:	00 00 
  66b52e:	66 0f 28 94 24 d0 04 	movapd 0x4d0(%rsp),%xmm2
  66b535:	00 00 
  66b537:	66 0f 5c d1          	subpd  %xmm1,%xmm2
  66b53b:	66 0f 14 c8          	unpcklpd %xmm0,%xmm1
  66b53f:	66 0f 5a c9          	cvtpd2ps %xmm1,%xmm1
  66b543:	66 0f 5a c2          	cvtpd2ps %xmm2,%xmm0
  66b547:	66 0f 14 c8          	unpcklpd %xmm0,%xmm1
  66b54b:	66 0f 29 8c 24 00 01 	movapd %xmm1,0x100(%rsp)
  66b552:	00 00 
  66b554:	66 0f 28 c1          	movapd %xmm1,%xmm0
  66b558:	66 0f 54 05 a0 9f 9b 	andpd  -0x646060(%rip),%xmm0        # 25500 <anon.1508e9dce0c1a49d095b8c30671814b4.0.llvm.16300762181250184790+0x7e0>
  66b55f:	ff 
  66b560:	66 0f 66 05 68 99 9b 	pcmpgtd -0x646698(%rip),%xmm0        # 24ed0 <anon.1508e9dce0c1a49d095b8c30671814b4.0.llvm.16300762181250184790+0x1b0>
  66b567:	ff 
  66b568:	0f 50 c0             	movmskps %xmm0,%eax
  66b56b:	85 c0                	test   %eax,%eax
  66b56d:	0f 85 9a 06 00 00    	jne    66bc0d <<gpui_canvas::text::planner::Planner>::shape+0x2f3d>
  66b573:	44 8b bc 24 88 00 00 	mov    0x88(%rsp),%r15d
  66b57a:	00 
  66b57b:	45 01 f7             	add    %r14d,%r15d
  66b57e:	4c 39 f3             	cmp    %r14,%rbx
  66b581:	0f 85 09 01 00 00    	jne    66b690 <<gpui_canvas::text::planner::Planner>::shape+0x29c0>
  66b587:	0f 28 44 24 30       	movaps 0x30(%rsp),%xmm0
  66b58c:	0f 28 8c 24 00 01 00 	movaps 0x100(%rsp),%xmm1
  66b593:	00 
  66b594:	0f 2e c1             	ucomiss %xmm1,%xmm0
  66b597:	0f 85 87 00 00 00    	jne    66b624 <<gpui_canvas::text::planner::Planner>::shape+0x2954>
  66b59d:	0f 8a 81 00 00 00    	jp     66b624 <<gpui_canvas::text::planner::Planner>::shape+0x2954>
  66b5a3:	0f 28 c1             	movaps %xmm1,%xmm0
  66b5a6:	0f c6 c1 55          	shufps $0x55,%xmm1,%xmm0
  66b5aa:	f3 0f 10 54 24 10    	movss  0x10(%rsp),%xmm2
  66b5b0:	0f 2e d0             	ucomiss %xmm0,%xmm2
  66b5b3:	75 6f                	jne    66b624 <<gpui_canvas::text::planner::Planner>::shape+0x2954>
  66b5b5:	7a 6d                	jp     66b624 <<gpui_canvas::text::planner::Planner>::shape+0x2954>
  66b5b7:	0f 28 c1             	movaps %xmm1,%xmm0
  66b5ba:	66 0f 15 c1          	unpckhpd %xmm1,%xmm0
  66b5be:	0f 28 94 24 10 01 00 	movaps 0x110(%rsp),%xmm2
  66b5c5:	00 
  66b5c6:	0f 2e d0             	ucomiss %xmm0,%xmm2
  66b5c9:	75 59                	jne    66b624 <<gpui_canvas::text::planner::Planner>::shape+0x2954>
  66b5cb:	7a 57                	jp     66b624 <<gpui_canvas::text::planner::Planner>::shape+0x2954>
  66b5cd:	0f 28 c1             	movaps %xmm1,%xmm0
  66b5d0:	0f c6 c1 ff          	shufps $0xff,%xmm1,%xmm0
  66b5d4:	0f 28 4c 24 60       	movaps 0x60(%rsp),%xmm1
  66b5d9:	0f 2e c8             	ucomiss %xmm0,%xmm1
  66b5dc:	75 46                	jne    66b624 <<gpui_canvas::text::planner::Planner>::shape+0x2954>
  66b5de:	7a 44                	jp     66b624 <<gpui_canvas::text::planner::Planner>::shape+0x2954>
  66b5e0:	48 8b 9c 24 90 01 00 	mov    0x190(%rsp),%rbx
  66b5e7:	00 
  66b5e8:	40 b5 03             	mov    $0x3,%bpl
  66b5eb:	48 3b 9c 24 80 01 00 	cmp    0x180(%rsp),%rbx
  66b5f2:	00 
  66b5f3:	0f 85 a4 fd ff ff    	jne    66b39d <<gpui_canvas::text::planner::Planner>::shape+0x26cd>
  66b5f9:	48 8d bc 24 80 01 00 	lea    0x180(%rsp),%rdi
  66b600:	00 
  66b601:	ff 15 51 e9 11 00    	call   *0x11e951(%rip)        # 789f58 <_DYNAMIC+0x4a8>
  66b607:	e9 91 fd ff ff       	jmp    66b39d <<gpui_canvas::text::planner::Planner>::shape+0x26cd>
  66b60c:	0f 1f 40 00          	nopl   0x0(%rax)
  66b610:	4c 39 f3             	cmp    %r14,%rbx
  66b613:	0f 85 af fd ff ff    	jne    66b3c8 <<gpui_canvas::text::planner::Planner>::shape+0x26f8>
  66b619:	44 8b bc 24 88 00 00 	mov    0x88(%rsp),%r15d
  66b620:	00 
  66b621:	45 01 f7             	add    %r14d,%r15d
  66b624:	48 8b 9c 24 90 01 00 	mov    0x190(%rsp),%rbx
  66b62b:	00 
  66b62c:	48 3b 9c 24 80 01 00 	cmp    0x180(%rsp),%rbx
  66b633:	00 
  66b634:	75 0e                	jne    66b644 <<gpui_canvas::text::planner::Planner>::shape+0x2974>
  66b636:	48 8d bc 24 80 01 00 	lea    0x180(%rsp),%rdi
  66b63d:	00 
  66b63e:	ff 15 14 e9 11 00    	call   *0x11e914(%rip)        # 789f58 <_DYNAMIC+0x4a8>
  66b644:	48 8b 84 24 88 01 00 	mov    0x188(%rsp),%rax
  66b64b:	00 
  66b64c:	48 8d 0c 5b          	lea    (%rbx,%rbx,2),%rcx
  66b650:	44 89 3c 88          	mov    %r15d,(%rax,%rcx,4)
  66b654:	0f 28 44 24 30       	movaps 0x30(%rsp),%xmm0
  66b659:	f3 0f 11 44 88 04    	movss  %xmm0,0x4(%rax,%rcx,4)
  66b65f:	c6 44 88 08 01       	movb   $0x1,0x8(%rax,%rcx,4)
  66b664:	48 ff c3             	inc    %rbx
  66b667:	48 89 9c 24 90 01 00 	mov    %rbx,0x190(%rsp)
  66b66e:	00 
  66b66f:	4c 39 f5             	cmp    %r14,%rbp
  66b672:	0f 85 50 fd ff ff    	jne    66b3c8 <<gpui_canvas::text::planner::Planner>::shape+0x26f8>
  66b678:	40 b5 02             	mov    $0x2,%bpl
  66b67b:	48 3b 9c 24 80 01 00 	cmp    0x180(%rsp),%rbx
  66b682:	00 
  66b683:	0f 85 07 fd ff ff    	jne    66b390 <<gpui_canvas::text::planner::Planner>::shape+0x26c0>
  66b689:	eb 1e                	jmp    66b6a9 <<gpui_canvas::text::planner::Planner>::shape+0x29d9>
  66b68b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  66b690:	48 8b 9c 24 90 01 00 	mov    0x190(%rsp),%rbx
  66b697:	00 
  66b698:	40 b5 02             	mov    $0x2,%bpl
  66b69b:	48 3b 9c 24 80 01 00 	cmp    0x180(%rsp),%rbx
  66b6a2:	00 
  66b6a3:	0f 85 e7 fc ff ff    	jne    66b390 <<gpui_canvas::text::planner::Planner>::shape+0x26c0>
  66b6a9:	48 8d bc 24 80 01 00 	lea    0x180(%rsp),%rdi
  66b6b0:	00 
  66b6b1:	ff 15 a1 e8 11 00    	call   *0x11e8a1(%rip)        # 789f58 <_DYNAMIC+0x4a8>
  66b6b7:	0f 28 84 24 00 01 00 	movaps 0x100(%rsp),%xmm0
  66b6be:	00 
  66b6bf:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
  66b6c4:	e9 d4 fc ff ff       	jmp    66b39d <<gpui_canvas::text::planner::Planner>::shape+0x26cd>
  66b6c9:	48 8b b4 24 10 07 00 	mov    0x710(%rsp),%rsi
  66b6d0:	00 
  66b6d1:	48 85 f6             	test   %rsi,%rsi
  66b6d4:	74 17                	je     66b6ed <<gpui_canvas::text::planner::Planner>::shape+0x2a1d>
  66b6d6:	48 8b bc 24 18 07 00 	mov    0x718(%rsp),%rdi
  66b6dd:	00 
  66b6de:	48 c1 e6 03          	shl    $0x3,%rsi
  66b6e2:	ba 08 00 00 00       	mov    $0x8,%edx
  66b6e7:	ff 15 fb e5 11 00    	call   *0x11e5fb(%rip)        # 789ce8 <_DYNAMIC+0x238>
  66b6ed:	0f 28 9c 24 80 02 00 	movaps 0x280(%rsp),%xmm3
  66b6f4:	00 
  66b6f5:	0f 28 c3             	movaps %xmm3,%xmm0
  66b6f8:	f3 0f 5f 84 24 d4 00 	maxss  0xd4(%rsp),%xmm0
  66b6ff:	00 00 
  66b701:	0f 28 c8             	movaps %xmm0,%xmm1
  66b704:	f3 0f c2 c8 03       	cmpunordss %xmm0,%xmm1
  66b709:	0f 28 d1             	movaps %xmm1,%xmm2
  66b70c:	0f 55 d0             	andnps %xmm0,%xmm2
  66b70f:	0f 54 cb             	andps  %xmm3,%xmm1
  66b712:	0f 56 ca             	orps   %xmm2,%xmm1
  66b715:	0f 29 8c 24 80 02 00 	movaps %xmm1,0x280(%rsp)
  66b71c:	00 
  66b71d:	48 8b 04 24          	mov    (%rsp),%rax
  66b721:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
  66b727:	f3 0f 58 80 30 0a 00 	addss  0xa30(%rax),%xmm0
  66b72e:	00 
  66b72f:	f3 0f 11 44 24 1c    	movss  %xmm0,0x1c(%rsp)
  66b735:	80 7c 24 4c 00       	cmpb   $0x0,0x4c(%rsp)
  66b73a:	48 8b 84 24 20 03 00 	mov    0x320(%rsp),%rax
  66b741:	00 
  66b742:	8b b4 24 80 00 00 00 	mov    0x80(%rsp),%esi
  66b749:	48 8b 94 24 18 03 00 	mov    0x318(%rsp),%rdx
  66b750:	00 
  66b751:	0f 84 d1 db ff ff    	je     669328 <<gpui_canvas::text::planner::Planner>::shape+0x658>
  66b757:	e9 6c 05 00 00       	jmp    66bcc8 <<gpui_canvas::text::planner::Planner>::shape+0x2ff8>
  66b75c:	48 8b 0c 24          	mov    (%rsp),%rcx
  66b760:	48 8b 81 d8 09 00 00 	mov    0x9d8(%rcx),%rax
  66b767:	48 6b 89 e0 09 00 00 	imul   $0x70,0x9e0(%rcx),%rcx
  66b76e:	70 
  66b76f:	48 01 c1             	add    %rax,%rcx
  66b772:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
  66b779:	00 
  66b77a:	48 89 8c 24 18 07 00 	mov    %rcx,0x718(%rsp)
  66b781:	00 
  66b782:	48 c7 84 24 20 07 00 	movq   $0x0,0x720(%rsp)
  66b789:	00 00 00 00 00 
  66b78e:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  66b793:	48 89 84 24 28 07 00 	mov    %rax,0x728(%rsp)
  66b79a:	00 
  66b79b:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  66b7a2:	00 
  66b7a3:	31 f6                	xor    %esi,%esi
  66b7a5:	48 8d 94 24 e7 00 00 	lea    0xe7(%rsp),%rdx
  66b7ac:	00 
  66b7ad:	e8 5e 88 01 00       	call   684010 <<core::iter::adapters::map::Map<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineData>>, <parley::layout::layout::Layout<()>>::lines::{closure#0}>, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#3}> as core::iter::traits::iterator::Iterator>::fold::<usize, <core::iter::adapters::flatten::FlattenCompat<_, _>>::iter_fold::flatten<core::iter::adapters::filter_map::FilterMap<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}>, <parley::layout::line::Line<()>>::runs::{closure#0}>, usize, <core::iter::adapters::flatten::FlattenCompat<_, _> as core::iter::traits::iterator::Iterator>::count::count<core::iter::adapters::filter_map::FilterMap<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}>, <parley::layout::line::Line<()>>::runs::{closure#0}>>>::{closure#0}>>
  66b7b2:	48 83 f8 02          	cmp    $0x2,%rax
  66b7b6:	0f 82 17 e2 ff ff    	jb     6699d3 <<gpui_canvas::text::planner::Planner>::shape+0xd03>
  66b7bc:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
  66b7c3:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  66b7ca:	00 ff 
  66b7cc:	0f 84 84 e1 ff ff    	je     669956 <<gpui_canvas::text::planner::Planner>::shape+0xc86>
  66b7d2:	e9 fc e1 ff ff       	jmp    6699d3 <<gpui_canvas::text::planner::Planner>::shape+0xd03>
  66b7d7:	c7 84 24 80 00 00 00 	movl   $0xffffffff,0x80(%rsp)
  66b7de:	ff ff ff ff 
  66b7e2:	e9 ac dd ff ff       	jmp    669593 <<gpui_canvas::text::planner::Planner>::shape+0x8c3>
  66b7e7:	44 89 d2             	mov    %r10d,%edx
  66b7ea:	83 e2 1f             	and    $0x1f,%edx
  66b7ed:	41 0f b6 79 01       	movzbl 0x1(%r9),%edi
  66b7f2:	83 e7 3f             	and    $0x3f,%edi
  66b7f5:	41 80 fa df          	cmp    $0xdf,%r10b
  66b7f9:	76 31                	jbe    66b82c <<gpui_canvas::text::planner::Planner>::shape+0x2b5c>
  66b7fb:	41 0f b6 71 02       	movzbl 0x2(%r9),%esi
  66b800:	c1 e7 06             	shl    $0x6,%edi
  66b803:	83 e6 3f             	and    $0x3f,%esi
  66b806:	09 fe                	or     %edi,%esi
  66b808:	41 80 fa f0          	cmp    $0xf0,%r10b
  66b80c:	72 2c                	jb     66b83a <<gpui_canvas::text::planner::Planner>::shape+0x2b6a>
  66b80e:	49 8d 59 04          	lea    0x4(%r9),%rbx
  66b812:	45 0f b6 51 03       	movzbl 0x3(%r9),%r10d
  66b817:	83 e2 07             	and    $0x7,%edx
  66b81a:	c1 e2 12             	shl    $0x12,%edx
  66b81d:	c1 e6 06             	shl    $0x6,%esi
  66b820:	41 83 e2 3f          	and    $0x3f,%r10d
  66b824:	41 09 f2             	or     %esi,%r10d
  66b827:	41 09 d2             	or     %edx,%r10d
  66b82a:	eb 1a                	jmp    66b846 <<gpui_canvas::text::planner::Planner>::shape+0x2b76>
  66b82c:	49 8d 59 02          	lea    0x2(%r9),%rbx
  66b830:	c1 e2 06             	shl    $0x6,%edx
  66b833:	09 fa                	or     %edi,%edx
  66b835:	41 89 d2             	mov    %edx,%r10d
  66b838:	eb 0c                	jmp    66b846 <<gpui_canvas::text::planner::Planner>::shape+0x2b76>
  66b83a:	49 8d 59 03          	lea    0x3(%r9),%rbx
  66b83e:	c1 e2 0c             	shl    $0xc,%edx
  66b841:	09 d6                	or     %edx,%esi
  66b843:	41 89 f2             	mov    %esi,%r10d
  66b846:	49 8d 50 02          	lea    0x2(%r8),%rdx
  66b84a:	4c 89 c1             	mov    %r8,%rcx
  66b84d:	48 89 c6             	mov    %rax,%rsi
  66b850:	4c 29 ce             	sub    %r9,%rsi
  66b853:	48 01 de             	add    %rbx,%rsi
  66b856:	41 83 fa 0a          	cmp    $0xa,%r10d
  66b85a:	bf fe ff ff ff       	mov    $0xfffffffe,%edi
  66b85f:	44 0f 44 d7          	cmove  %edi,%r10d
  66b863:	44 89 94 24 80 00 00 	mov    %r10d,0x80(%rsp)
  66b86a:	00 
  66b86b:	4c 0f 44 da          	cmove  %rdx,%r11
  66b86f:	c7 44 24 4c 00 00 00 	movl   $0x0,0x4c(%rsp)
  66b876:	00 
  66b877:	48 89 84 24 10 03 00 	mov    %rax,0x310(%rsp)
  66b87e:	00 
  66b87f:	48 89 f0             	mov    %rsi,%rax
  66b882:	4c 89 de             	mov    %r11,%rsi
  66b885:	48 89 5c 24 28       	mov    %rbx,0x28(%rsp)
  66b88a:	e9 0f dd ff ff       	jmp    66959e <<gpui_canvas::text::planner::Planner>::shape+0x8ce>
  66b88f:	b9 04 00 00 00       	mov    $0x4,%ecx
  66b894:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  66b89a:	48 8d bc 24 e8 00 00 	lea    0xe8(%rsp),%rdi
  66b8a1:	00 
  66b8a2:	48 89 da             	mov    %rbx,%rdx
  66b8a5:	e8 a6 85 ff ff       	call   663e50 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  66b8aa:	e9 88 e2 ff ff       	jmp    669b37 <<gpui_canvas::text::planner::Planner>::shape+0xe67>
  66b8af:	c7 84 24 90 00 00 00 	movl   $0x7,0x90(%rsp)
  66b8b6:	07 00 00 00 
  66b8ba:	eb 0b                	jmp    66b8c7 <<gpui_canvas::text::planner::Planner>::shape+0x2bf7>
  66b8bc:	c7 84 24 90 00 00 00 	movl   $0x4,0x90(%rsp)
  66b8c3:	04 00 00 00 
  66b8c7:	48 c7 84 24 88 00 00 	movq   $0xffffffffffffffff,0x88(%rsp)
  66b8ce:	00 ff ff ff ff 
  66b8d3:	4c 8b 2c 24          	mov    (%rsp),%r13
  66b8d7:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
  66b8de:	00 
  66b8df:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  66b8e3:	74 76                	je     66b95b <<gpui_canvas::text::planner::Planner>::shape+0x2c8b>
  66b8e5:	48 85 c0             	test   %rax,%rax
  66b8e8:	74 1b                	je     66b905 <<gpui_canvas::text::planner::Planner>::shape+0x2c35>
  66b8ea:	48 8b bc 24 58 01 00 	mov    0x158(%rsp),%rdi
  66b8f1:	00 
  66b8f2:	48 c1 e0 03          	shl    $0x3,%rax
  66b8f6:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  66b8fa:	ba 04 00 00 00       	mov    $0x4,%edx
  66b8ff:	ff 15 e3 e3 11 00    	call   *0x11e3e3(%rip)        # 789ce8 <_DYNAMIC+0x238>
  66b905:	48 8b 84 24 68 01 00 	mov    0x168(%rsp),%rax
  66b90c:	00 
  66b90d:	48 85 c0             	test   %rax,%rax
  66b910:	74 1b                	je     66b92d <<gpui_canvas::text::planner::Planner>::shape+0x2c5d>
  66b912:	48 8b bc 24 70 01 00 	mov    0x170(%rsp),%rdi
  66b919:	00 
  66b91a:	48 c1 e0 03          	shl    $0x3,%rax
  66b91e:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  66b922:	ba 04 00 00 00       	mov    $0x4,%edx
  66b927:	ff 15 bb e3 11 00    	call   *0x11e3bb(%rip)        # 789ce8 <_DYNAMIC+0x238>
  66b92d:	48 8b 84 24 80 01 00 	mov    0x180(%rsp),%rax
  66b934:	00 
  66b935:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  66b939:	74 20                	je     66b95b <<gpui_canvas::text::planner::Planner>::shape+0x2c8b>
  66b93b:	48 85 c0             	test   %rax,%rax
  66b93e:	74 1b                	je     66b95b <<gpui_canvas::text::planner::Planner>::shape+0x2c8b>
  66b940:	48 8b bc 24 88 01 00 	mov    0x188(%rsp),%rdi
  66b947:	00 
  66b948:	48 c1 e0 02          	shl    $0x2,%rax
  66b94c:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  66b950:	ba 04 00 00 00       	mov    $0x4,%edx
  66b955:	ff 15 8d e3 11 00    	call   *0x11e38d(%rip)        # 789ce8 <_DYNAMIC+0x238>
  66b95b:	48 8b b4 24 e8 00 00 	mov    0xe8(%rsp),%rsi
  66b962:	00 
  66b963:	48 85 f6             	test   %rsi,%rsi
  66b966:	74 17                	je     66b97f <<gpui_canvas::text::planner::Planner>::shape+0x2caf>
  66b968:	48 8b bc 24 f0 00 00 	mov    0xf0(%rsp),%rdi
  66b96f:	00 
  66b970:	48 c1 e6 04          	shl    $0x4,%rsi
  66b974:	ba 04 00 00 00       	mov    $0x4,%edx
  66b979:	ff 15 69 e3 11 00    	call   *0x11e369(%rip)        # 789ce8 <_DYNAMIC+0x238>
  66b97f:	48 8b b4 24 a0 02 00 	mov    0x2a0(%rsp),%rsi
  66b986:	00 
  66b987:	48 83 fe fd          	cmp    $0xfffffffffffffffd,%rsi
  66b98b:	77 18                	ja     66b9a5 <<gpui_canvas::text::planner::Planner>::shape+0x2cd5>
  66b98d:	48 85 f6             	test   %rsi,%rsi
  66b990:	74 13                	je     66b9a5 <<gpui_canvas::text::planner::Planner>::shape+0x2cd5>
  66b992:	48 8b bc 24 a8 02 00 	mov    0x2a8(%rsp),%rdi
  66b999:	00 
  66b99a:	ba 01 00 00 00       	mov    $0x1,%edx
  66b99f:	ff 15 43 e3 11 00    	call   *0x11e343(%rip)        # 789ce8 <_DYNAMIC+0x238>
  66b9a5:	48 8b b4 24 b8 02 00 	mov    0x2b8(%rsp),%rsi
  66b9ac:	00 
  66b9ad:	48 83 fe fd          	cmp    $0xfffffffffffffffd,%rsi
  66b9b1:	77 18                	ja     66b9cb <<gpui_canvas::text::planner::Planner>::shape+0x2cfb>
  66b9b3:	48 85 f6             	test   %rsi,%rsi
  66b9b6:	74 13                	je     66b9cb <<gpui_canvas::text::planner::Planner>::shape+0x2cfb>
  66b9b8:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
  66b9bf:	00 
  66b9c0:	ba 01 00 00 00       	mov    $0x1,%edx
  66b9c5:	ff 15 1d e3 11 00    	call   *0x11e31d(%rip)        # 789ce8 <_DYNAMIC+0x238>
  66b9cb:	48 8b b4 24 d0 02 00 	mov    0x2d0(%rsp),%rsi
  66b9d2:	00 
  66b9d3:	48 83 fe fd          	cmp    $0xfffffffffffffffd,%rsi
  66b9d7:	77 18                	ja     66b9f1 <<gpui_canvas::text::planner::Planner>::shape+0x2d21>
  66b9d9:	48 85 f6             	test   %rsi,%rsi
  66b9dc:	74 13                	je     66b9f1 <<gpui_canvas::text::planner::Planner>::shape+0x2d21>
  66b9de:	48 8b bc 24 d8 02 00 	mov    0x2d8(%rsp),%rdi
  66b9e5:	00 
  66b9e6:	ba 01 00 00 00       	mov    $0x1,%edx
  66b9eb:	ff 15 f7 e2 11 00    	call   *0x11e2f7(%rip)        # 789ce8 <_DYNAMIC+0x238>
  66b9f1:	49 8d bd c8 08 00 00 	lea    0x8c8(%r13),%rdi
  66b9f8:	e8 33 b7 ff ff       	call   667130 <core::ptr::drop_glue::<parley::layout::layout::Layout<()>>>
  66b9fd:	49 c7 85 c8 08 00 00 	movq   $0x0,0x8c8(%r13)
  66ba04:	00 00 00 00 
  66ba08:	49 c7 85 d0 08 00 00 	movq   $0x4,0x8d0(%r13)
  66ba0f:	04 00 00 00 
  66ba13:	0f 57 c0             	xorps  %xmm0,%xmm0
  66ba16:	41 0f 11 85 d8 08 00 	movups %xmm0,0x8d8(%r13)
  66ba1d:	00 
  66ba1e:	49 c7 85 e8 08 00 00 	movq   $0x4,0x8e8(%r13)
  66ba25:	04 00 00 00 
  66ba29:	41 0f 11 85 f0 08 00 	movups %xmm0,0x8f0(%r13)
  66ba30:	00 
  66ba31:	49 c7 85 00 09 00 00 	movq   $0x8,0x900(%r13)
  66ba38:	08 00 00 00 
  66ba3c:	41 0f 11 85 08 09 00 	movups %xmm0,0x908(%r13)
  66ba43:	00 
  66ba44:	49 c7 85 18 09 00 00 	movq   $0x8,0x918(%r13)
  66ba4b:	08 00 00 00 
  66ba4f:	41 0f 11 85 20 09 00 	movups %xmm0,0x920(%r13)
  66ba56:	00 
  66ba57:	49 c7 85 30 09 00 00 	movq   $0x4,0x930(%r13)
  66ba5e:	04 00 00 00 
  66ba62:	41 0f 11 85 38 09 00 	movups %xmm0,0x938(%r13)
  66ba69:	00 
  66ba6a:	49 c7 85 48 09 00 00 	movq   $0x4,0x948(%r13)
  66ba71:	04 00 00 00 
  66ba75:	41 0f 11 85 50 09 00 	movups %xmm0,0x950(%r13)
  66ba7c:	00 
  66ba7d:	49 c7 85 60 09 00 00 	movq   $0x4,0x960(%r13)
  66ba84:	04 00 00 00 
  66ba88:	41 0f 11 85 68 09 00 	movups %xmm0,0x968(%r13)
  66ba8f:	00 
  66ba90:	49 c7 85 78 09 00 00 	movq   $0x8,0x978(%r13)
  66ba97:	08 00 00 00 
  66ba9b:	41 0f 11 85 80 09 00 	movups %xmm0,0x980(%r13)
  66baa2:	00 
  66baa3:	49 c7 85 90 09 00 00 	movq   $0x2,0x990(%r13)
  66baaa:	02 00 00 00 
  66baae:	41 0f 11 85 98 09 00 	movups %xmm0,0x998(%r13)
  66bab5:	00 
  66bab6:	49 c7 85 a8 09 00 00 	movq   $0x4,0x9a8(%r13)
  66babd:	04 00 00 00 
  66bac1:	41 0f 11 85 b0 09 00 	movups %xmm0,0x9b0(%r13)
  66bac8:	00 
  66bac9:	49 c7 85 c0 09 00 00 	movq   $0x8,0x9c0(%r13)
  66bad0:	08 00 00 00 
  66bad4:	41 0f 11 85 c8 09 00 	movups %xmm0,0x9c8(%r13)
  66badb:	00 
  66badc:	49 c7 85 d8 09 00 00 	movq   $0x8,0x9d8(%r13)
  66bae3:	08 00 00 00 
  66bae7:	41 0f 11 85 e0 09 00 	movups %xmm0,0x9e0(%r13)
  66baee:	00 
  66baef:	49 c7 85 f0 09 00 00 	movq   $0x8,0x9f0(%r13)
  66baf6:	08 00 00 00 
  66bafa:	41 0f 11 85 f8 09 00 	movups %xmm0,0x9f8(%r13)
  66bb01:	00 
  66bb02:	49 c7 85 08 0a 00 00 	movq   $0x4,0xa08(%r13)
  66bb09:	04 00 00 00 
  66bb0d:	41 0f 11 85 10 0a 00 	movups %xmm0,0xa10(%r13)
  66bb14:	00 
  66bb15:	41 c7 85 20 0a 00 00 	movl   $0x3f800000,0xa20(%r13)
  66bb1c:	00 00 80 3f 
  66bb20:	41 0f 11 85 24 0a 00 	movups %xmm0,0xa24(%r13)
  66bb27:	00 
  66bb28:	49 c7 85 32 0a 00 00 	movq   $0x0,0xa32(%r13)
  66bb2f:	00 00 00 00 
  66bb33:	66 41 c7 85 3a 0a 00 	movw   $0xff01,0xa3a(%r13)
  66bb3a:	00 01 ff 
  66bb3d:	41 c6 85 3c 0a 00 00 	movb   $0x0,0xa3c(%r13)
  66bb44:	00 
  66bb45:	48 8b 8c 24 b8 00 00 	mov    0xb8(%rsp),%rcx
  66bb4c:	00 
  66bb4d:	48 8b 84 24 38 03 00 	mov    0x338(%rsp),%rax
  66bb54:	00 
  66bb55:	48 89 48 30          	mov    %rcx,0x30(%rax)
  66bb59:	0f 10 84 24 88 00 00 	movups 0x88(%rsp),%xmm0
  66bb60:	00 
  66bb61:	0f 10 8c 24 98 00 00 	movups 0x98(%rsp),%xmm1
  66bb68:	00 
  66bb69:	0f 10 94 24 a8 00 00 	movups 0xa8(%rsp),%xmm2
  66bb70:	00 
  66bb71:	0f 11 50 20          	movups %xmm2,0x20(%rax)
  66bb75:	0f 11 48 10          	movups %xmm1,0x10(%rax)
  66bb79:	0f 11 00             	movups %xmm0,(%rax)
  66bb7c:	48 81 c4 e8 11 00 00 	add    $0x11e8,%rsp
  66bb83:	5b                   	pop    %rbx
  66bb84:	41 5c                	pop    %r12
  66bb86:	41 5d                	pop    %r13
  66bb88:	41 5e                	pop    %r14
  66bb8a:	41 5f                	pop    %r15
  66bb8c:	5d                   	pop    %rbp
  66bb8d:	c3                   	ret
  66bb8e:	48 8d 35 a3 11 12 00 	lea    0x1211a3(%rip),%rsi        # 78cd38 <gpui_canvas::text::HEBREW_FONT>
  66bb95:	48 8d 15 a8 4a 9f ff 	lea    -0x60b558(%rip),%rdx        # 60644 <gpui_canvas::text::HEBREW_BYTES>
  66bb9c:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  66bba3:	00 
  66bba4:	b9 14 69 00 00       	mov    $0x6914,%ecx
  66bba9:	45 31 c0             	xor    %r8d,%r8d
  66bbac:	e8 2f 83 ff ff       	call   663ee0 <<gpui_canvas::text::FontFace>::shared_static>
  66bbb1:	80 bc 24 10 07 00 00 	cmpb   $0x0,0x710(%rsp)
  66bbb8:	00 
  66bbb9:	0f 85 02 d5 ff ff    	jne    6690c1 <<gpui_canvas::text::planner::Planner>::shape+0x3f1>
  66bbbf:	44 89 fd             	mov    %r15d,%ebp
  66bbc2:	49 8d 9d 50 0a 00 00 	lea    0xa50(%r13),%rbx
  66bbc9:	4c 8b bc 24 18 07 00 	mov    0x718(%rsp),%r15
  66bbd0:	00 
  66bbd1:	48 8b 03             	mov    (%rbx),%rax
  66bbd4:	48 85 c0             	test   %rax,%rax
  66bbd7:	74 0f                	je     66bbe8 <<gpui_canvas::text::planner::Planner>::shape+0x2f18>
  66bbd9:	f0 48 ff 08          	lock decq (%rax)
  66bbdd:	75 09                	jne    66bbe8 <<gpui_canvas::text::planner::Planner>::shape+0x2f18>
  66bbdf:	48 89 df             	mov    %rbx,%rdi
  66bbe2:	ff 15 28 e1 11 00    	call   *0x11e128(%rip)        # 789d10 <_DYNAMIC+0x260>
  66bbe8:	4d 89 bd 50 0a 00 00 	mov    %r15,0xa50(%r13)
  66bbef:	be 02 00 00 00       	mov    $0x2,%esi
  66bbf4:	4c 89 ef             	mov    %r13,%rdi
  66bbf7:	e8 a4 0b 00 00       	call   66c7a0 <<gpui_canvas::text::planner::Planner>::register>
  66bbfc:	83 f8 ff             	cmp    $0xffffffff,%eax
  66bbff:	41 89 ef             	mov    %ebp,%r15d
  66bc02:	0f 85 18 d5 ff ff    	jne    669120 <<gpui_canvas::text::planner::Planner>::shape+0x450>
  66bc08:	e9 52 d5 ff ff       	jmp    66915f <<gpui_canvas::text::planner::Planner>::shape+0x48f>
  66bc0d:	48 8b b4 24 10 07 00 	mov    0x710(%rsp),%rsi
  66bc14:	00 
  66bc15:	48 85 f6             	test   %rsi,%rsi
  66bc18:	74 17                	je     66bc31 <<gpui_canvas::text::planner::Planner>::shape+0x2f61>
  66bc1a:	48 8b bc 24 18 07 00 	mov    0x718(%rsp),%rdi
  66bc21:	00 
  66bc22:	48 c1 e6 03          	shl    $0x3,%rsi
  66bc26:	ba 08 00 00 00       	mov    $0x8,%edx
  66bc2b:	ff 15 b7 e0 11 00    	call   *0x11e0b7(%rip)        # 789ce8 <_DYNAMIC+0x238>
  66bc31:	b8 01 00 00 00       	mov    $0x1,%eax
  66bc36:	4c 8b 2c 24          	mov    (%rsp),%r13
  66bc3a:	89 84 24 90 00 00 00 	mov    %eax,0x90(%rsp)
  66bc41:	89 94 24 94 00 00 00 	mov    %edx,0x94(%rsp)
  66bc48:	48 c7 84 24 88 00 00 	movq   $0xffffffffffffffff,0x88(%rsp)
  66bc4f:	00 ff ff ff ff 
  66bc54:	e9 7e fc ff ff       	jmp    66b8d7 <<gpui_canvas::text::planner::Planner>::shape+0x2c07>
  66bc59:	c7 84 24 90 00 00 00 	movl   $0x3,0x90(%rsp)
  66bc60:	03 00 00 00 
  66bc64:	e9 5e fc ff ff       	jmp    66b8c7 <<gpui_canvas::text::planner::Planner>::shape+0x2bf7>
  66bc69:	48 c7 84 24 90 00 00 	movq   $0x3,0x90(%rsp)
  66bc70:	00 03 00 00 00 
  66bc75:	e9 4d fc ff ff       	jmp    66b8c7 <<gpui_canvas::text::planner::Planner>::shape+0x2bf7>
  66bc7a:	c7 84 24 90 00 00 00 	movl   $0x1,0x90(%rsp)
  66bc81:	01 00 00 00 
  66bc85:	e9 3d fc ff ff       	jmp    66b8c7 <<gpui_canvas::text::planner::Planner>::shape+0x2bf7>
  66bc8a:	c7 84 24 90 00 00 00 	movl   $0x3,0x90(%rsp)
  66bc91:	03 00 00 00 
  66bc95:	8b 84 24 18 02 00 00 	mov    0x218(%rsp),%eax
  66bc9c:	89 84 24 94 00 00 00 	mov    %eax,0x94(%rsp)
  66bca3:	e9 1f fc ff ff       	jmp    66b8c7 <<gpui_canvas::text::planner::Planner>::shape+0x2bf7>
  66bca8:	48 c7 84 24 90 00 00 	movq   $0xc,0x90(%rsp)
  66bcaf:	00 0c 00 00 00 
  66bcb4:	48 c7 84 24 88 00 00 	movq   $0xffffffffffffffff,0x88(%rsp)
  66bcbb:	00 ff ff ff ff 
  66bcc0:	49 89 f5             	mov    %rsi,%r13
  66bcc3:	e9 0f fc ff ff       	jmp    66b8d7 <<gpui_canvas::text::planner::Planner>::shape+0x2c07>
  66bcc8:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  66bccf:	00 ff 
  66bcd1:	4c 8b 2c 24          	mov    (%rsp),%r13
  66bcd5:	0f 84 4a 01 00 00    	je     66be25 <<gpui_canvas::text::planner::Planner>::shape+0x3155>
  66bcdb:	48 8b 84 24 80 01 00 	mov    0x180(%rsp),%rax
  66bce2:	00 
  66bce3:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  66bce7:	0f 84 1b 03 00 00    	je     66c008 <<gpui_canvas::text::planner::Planner>::shape+0x3338>
  66bced:	48 8b b4 24 90 01 00 	mov    0x190(%rsp),%rsi
  66bcf4:	00 
  66bcf5:	48 39 f0             	cmp    %rsi,%rax
  66bcf8:	0f 86 0a 03 00 00    	jbe    66c008 <<gpui_canvas::text::planner::Planner>::shape+0x3338>
  66bcfe:	48 8d bc 24 80 01 00 	lea    0x180(%rsp),%rdi
  66bd05:	00 
  66bd06:	e8 e5 0c 00 00       	call   66c9f0 <<alloc::raw_vec::RawVecInner>::shrink>
  66bd0b:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  66bd0f:	0f 84 f3 02 00 00    	je     66c008 <<gpui_canvas::text::planner::Planner>::shape+0x3338>
  66bd15:	48 89 c7             	mov    %rax,%rdi
  66bd18:	48 89 d6             	mov    %rdx,%rsi
  66bd1b:	ff 15 df e0 11 00    	call   *0x11e0df(%rip)        # 789e00 <_DYNAMIC+0x350>
  66bd21:	e9 25 06 00 00       	jmp    66c34b <<gpui_canvas::text::planner::Planner>::shape+0x367b>
  66bd26:	4c 8b 2c 24          	mov    (%rsp),%r13
  66bd2a:	eb 25                	jmp    66bd51 <<gpui_canvas::text::planner::Planner>::shape+0x3081>
  66bd2c:	c7 44 24 0c 00 00 00 	movl   $0x0,0xc(%rsp)
  66bd33:	00 
  66bd34:	4c 8b 8c 24 f8 02 00 	mov    0x2f8(%rsp),%r9
  66bd3b:	00 
  66bd3c:	4d 85 c9             	test   %r9,%r9
  66bd3f:	74 23                	je     66bd64 <<gpui_canvas::text::planner::Planner>::shape+0x3094>
  66bd41:	4c 8b 2c 24          	mov    (%rsp),%r13
  66bd45:	48 8b 8c 24 10 01 00 	mov    0x110(%rsp),%rcx
  66bd4c:	00 
  66bd4d:	8b 54 24 0c          	mov    0xc(%rsp),%edx
  66bd51:	49 39 c9             	cmp    %rcx,%r9
  66bd54:	73 23                	jae    66bd79 <<gpui_canvas::text::planner::Planner>::shape+0x30a9>
  66bd56:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  66bd5b:	42 80 3c 08 bf       	cmpb   $0xbf,(%rax,%r9,1)
  66bd60:	7f 1c                	jg     66bd7e <<gpui_canvas::text::planner::Planner>::shape+0x30ae>
  66bd62:	eb 4c                	jmp    66bdb0 <<gpui_canvas::text::planner::Planner>::shape+0x30e0>
  66bd64:	45 31 c9             	xor    %r9d,%r9d
  66bd67:	4c 8b 2c 24          	mov    (%rsp),%r13
  66bd6b:	48 8b 8c 24 10 01 00 	mov    0x110(%rsp),%rcx
  66bd72:	00 
  66bd73:	8b 54 24 0c          	mov    0xc(%rsp),%edx
  66bd77:	eb 05                	jmp    66bd7e <<gpui_canvas::text::planner::Planner>::shape+0x30ae>
  66bd79:	49 89 c9             	mov    %rcx,%r9
  66bd7c:	75 32                	jne    66bdb0 <<gpui_canvas::text::planner::Planner>::shape+0x30e0>
  66bd7e:	84 d2                	test   %dl,%dl
  66bd80:	74 1a                	je     66bd9c <<gpui_canvas::text::planner::Planner>::shape+0x30cc>
  66bd82:	4c 39 cd             	cmp    %r9,%rbp
  66bd85:	74 29                	je     66bdb0 <<gpui_canvas::text::planner::Planner>::shape+0x30e0>
  66bd87:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
  66bd8c:	43 0f b6 0c 08       	movzbl (%r8,%r9,1),%ecx
  66bd91:	84 c9                	test   %cl,%cl
  66bd93:	78 44                	js     66bdd9 <<gpui_canvas::text::planner::Planner>::shape+0x3109>
  66bd95:	b8 0b 00 00 00       	mov    $0xb,%eax
  66bd9a:	eb 1e                	jmp    66bdba <<gpui_canvas::text::planner::Planner>::shape+0x30ea>
  66bd9c:	48 39 cd             	cmp    %rcx,%rbp
  66bd9f:	73 0d                	jae    66bdae <<gpui_canvas::text::planner::Planner>::shape+0x30de>
  66bda1:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  66bda6:	80 3c 28 bf          	cmpb   $0xbf,(%rax,%rbp,1)
  66bdaa:	7f d6                	jg     66bd82 <<gpui_canvas::text::planner::Planner>::shape+0x30b2>
  66bdac:	eb 02                	jmp    66bdb0 <<gpui_canvas::text::planner::Planner>::shape+0x30e0>
  66bdae:	74 d2                	je     66bd82 <<gpui_canvas::text::planner::Planner>::shape+0x30b2>
  66bdb0:	b8 03 00 00 00       	mov    $0x3,%eax
  66bdb5:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
  66bdba:	89 84 24 90 00 00 00 	mov    %eax,0x90(%rsp)
  66bdc1:	89 8c 24 94 00 00 00 	mov    %ecx,0x94(%rsp)
  66bdc8:	48 c7 84 24 88 00 00 	movq   $0xffffffffffffffff,0x88(%rsp)
  66bdcf:	00 ff ff ff ff 
  66bdd4:	e9 fe fa ff ff       	jmp    66b8d7 <<gpui_canvas::text::planner::Planner>::shape+0x2c07>
  66bdd9:	89 ca                	mov    %ecx,%edx
  66bddb:	83 e2 1f             	and    $0x1f,%edx
  66bdde:	43 0f b6 7c 08 01    	movzbl 0x1(%r8,%r9,1),%edi
  66bde4:	83 e7 3f             	and    $0x3f,%edi
  66bde7:	b8 0b 00 00 00       	mov    $0xb,%eax
  66bdec:	80 f9 df             	cmp    $0xdf,%cl
  66bdef:	76 2b                	jbe    66be1c <<gpui_canvas::text::planner::Planner>::shape+0x314c>
  66bdf1:	43 0f b6 74 08 02    	movzbl 0x2(%r8,%r9,1),%esi
  66bdf7:	c1 e7 06             	shl    $0x6,%edi
  66bdfa:	83 e6 3f             	and    $0x3f,%esi
  66bdfd:	09 fe                	or     %edi,%esi
  66bdff:	80 f9 f0             	cmp    $0xf0,%cl
  66be02:	72 7a                	jb     66be7e <<gpui_canvas::text::planner::Planner>::shape+0x31ae>
  66be04:	43 0f b6 4c 08 03    	movzbl 0x3(%r8,%r9,1),%ecx
  66be0a:	83 e2 07             	and    $0x7,%edx
  66be0d:	c1 e2 12             	shl    $0x12,%edx
  66be10:	c1 e6 06             	shl    $0x6,%esi
  66be13:	83 e1 3f             	and    $0x3f,%ecx
  66be16:	09 f1                	or     %esi,%ecx
  66be18:	09 d1                	or     %edx,%ecx
  66be1a:	eb 9e                	jmp    66bdba <<gpui_canvas::text::planner::Planner>::shape+0x30ea>
  66be1c:	c1 e2 06             	shl    $0x6,%edx
  66be1f:	09 fa                	or     %edi,%edx
  66be21:	89 d1                	mov    %edx,%ecx
  66be23:	eb 95                	jmp    66bdba <<gpui_canvas::text::planner::Planner>::shape+0x30ea>
  66be25:	48 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%rax
  66be2c:	00 
  66be2d:	48 85 c0             	test   %rax,%rax
  66be30:	0f 84 b6 00 00 00    	je     66beec <<gpui_canvas::text::planner::Planner>::shape+0x321c>
  66be36:	48 8b 8c 24 f0 00 00 	mov    0xf0(%rsp),%rcx
  66be3d:	00 
  66be3e:	48 c1 e0 04          	shl    $0x4,%rax
  66be42:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
  66be47:	2b 54 01 f0          	sub    -0x10(%rcx,%rax,1),%edx
  66be4b:	0f 83 a8 00 00 00    	jae    66bef9 <<gpui_canvas::text::planner::Planner>::shape+0x3229>
  66be51:	c7 84 24 90 00 00 00 	movl   $0x3,0x90(%rsp)
  66be58:	03 00 00 00 
  66be5c:	48 c7 84 24 88 00 00 	movq   $0xffffffffffffffff,0x88(%rsp)
  66be63:	00 ff ff ff ff 
  66be68:	48 8b b4 24 e8 00 00 	mov    0xe8(%rsp),%rsi
  66be6f:	00 
  66be70:	48 85 f6             	test   %rsi,%rsi
  66be73:	0f 85 ef fa ff ff    	jne    66b968 <<gpui_canvas::text::planner::Planner>::shape+0x2c98>
  66be79:	e9 01 fb ff ff       	jmp    66b97f <<gpui_canvas::text::planner::Planner>::shape+0x2caf>
  66be7e:	c1 e2 0c             	shl    $0xc,%edx
  66be81:	09 d6                	or     %edx,%esi
  66be83:	89 f1                	mov    %esi,%ecx
  66be85:	e9 30 ff ff ff       	jmp    66bdba <<gpui_canvas::text::planner::Planner>::shape+0x30ea>
  66be8a:	48 8d 3d 97 25 bf ff 	lea    -0x40da69(%rip),%rdi        # 25e428 <anon.bed1e15ea09922136a836d7820f2c1fc.5.llvm.1182798584467922838>
  66be91:	48 8d 15 98 45 11 00 	lea    0x114598(%rip),%rdx        # 780430 <anon.bed1e15ea09922136a836d7820f2c1fc.6.llvm.1182798584467922838>
  66be98:	be ad 00 00 00       	mov    $0xad,%esi
  66be9d:	ff 15 3d df 11 00    	call   *0x11df3d(%rip)        # 789de0 <_DYNAMIC+0x330>
  66bea3:	e9 a3 04 00 00       	jmp    66c34b <<gpui_canvas::text::planner::Planner>::shape+0x367b>
  66bea8:	48 8d 0d a1 32 11 00 	lea    0x1132a1(%rip),%rcx        # 77f150 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0x80>
  66beaf:	48 89 df             	mov    %rbx,%rdi
  66beb2:	48 8b 94 24 40 01 00 	mov    0x140(%rsp),%rdx
  66beb9:	00 
  66beba:	ff 15 48 e1 11 00    	call   *0x11e148(%rip)        # 78a008 <_DYNAMIC+0x558>
  66bec0:	e9 86 04 00 00       	jmp    66c34b <<gpui_canvas::text::planner::Planner>::shape+0x367b>
  66bec5:	41 bc 03 00 00 00    	mov    $0x3,%r12d
  66becb:	8b 44 24 08          	mov    0x8(%rsp),%eax
  66becf:	41 89 c7             	mov    %eax,%r15d
  66bed2:	e9 4f d2 ff ff       	jmp    669126 <<gpui_canvas::text::planner::Planner>::shape+0x456>
  66bed7:	41 bc 03 00 00 00    	mov    $0x3,%r12d
  66bedd:	8b 84 24 d0 01 00 00 	mov    0x1d0(%rsp),%eax
  66bee4:	41 89 c7             	mov    %eax,%r15d
  66bee7:	e9 3a d2 ff ff       	jmp    669126 <<gpui_canvas::text::planner::Planner>::shape+0x456>
  66beec:	48 83 7c 24 50 00    	cmpq   $0x0,0x50(%rsp)
  66bef2:	75 11                	jne    66bf05 <<gpui_canvas::text::planner::Planner>::shape+0x3235>
  66bef4:	e9 0f 01 00 00       	jmp    66c008 <<gpui_canvas::text::planner::Planner>::shape+0x3338>
  66bef9:	81 fa ff 00 00 00    	cmp    $0xff,%edx
  66beff:	0f 86 b1 02 00 00    	jbe    66c1b6 <<gpui_canvas::text::planner::Planner>::shape+0x34e6>
  66bf05:	bf 04 00 00 00       	mov    $0x4,%edi
  66bf0a:	be 18 00 00 00       	mov    $0x18,%esi
  66bf0f:	e8 ac 0d 00 00       	call   66ccc0 <alloc::boxed::box_new_uninit>
  66bf14:	48 89 c3             	mov    %rax,%rbx
  66bf17:	8b 84 24 f8 00 00 00 	mov    0xf8(%rsp),%eax
  66bf1e:	c7 03 00 00 00 00    	movl   $0x0,(%rbx)
  66bf24:	4c 8b 7c 24 50       	mov    0x50(%rsp),%r15
  66bf29:	44 89 7b 04          	mov    %r15d,0x4(%rbx)
  66bf2d:	c7 43 08 00 00 00 00 	movl   $0x0,0x8(%rbx)
  66bf34:	89 43 0c             	mov    %eax,0xc(%rbx)
  66bf37:	c7 43 10 00 00 00 00 	movl   $0x0,0x10(%rbx)
  66bf3e:	66 c7 43 14 00 00    	movw   $0x0,0x14(%rbx)
  66bf44:	bf 04 00 00 00       	mov    $0x4,%edi
  66bf49:	be 18 00 00 00       	mov    $0x18,%esi
  66bf4e:	e8 6d 0d 00 00       	call   66ccc0 <alloc::boxed::box_new_uninit>
  66bf53:	49 89 c6             	mov    %rax,%r14
  66bf56:	c7 00 00 00 00 00    	movl   $0x0,(%rax)
  66bf5c:	44 89 78 04          	mov    %r15d,0x4(%rax)
  66bf60:	c7 40 08 00 00 00 00 	movl   $0x0,0x8(%rax)
  66bf67:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
  66bf6d:	f3 0f 11 40 0c       	movss  %xmm0,0xc(%rax)
  66bf72:	f3 0f 10 44 24 7c    	movss  0x7c(%rsp),%xmm0
  66bf78:	f3 0f 11 40 10       	movss  %xmm0,0x10(%rax)
  66bf7d:	0f 28 84 24 80 02 00 	movaps 0x280(%rsp),%xmm0
  66bf84:	00 
  66bf85:	f3 0f 11 40 14       	movss  %xmm0,0x14(%rax)
  66bf8a:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  66bf91:	00 ff 
  66bf93:	74 0d                	je     66bfa2 <<gpui_canvas::text::planner::Planner>::shape+0x32d2>
  66bf95:	48 8d bc 24 50 01 00 	lea    0x150(%rsp),%rdi
  66bf9c:	00 
  66bf9d:	e8 be c2 ff ff       	call   668260 <core::ptr::drop_glue::<gpui_canvas::text::layout::TextGeometry>>
  66bfa2:	48 c7 84 24 50 01 00 	movq   $0x1,0x150(%rsp)
  66bfa9:	00 01 00 00 00 
  66bfae:	48 89 9c 24 58 01 00 	mov    %rbx,0x158(%rsp)
  66bfb5:	00 
  66bfb6:	48 c7 84 24 60 01 00 	movq   $0x1,0x160(%rsp)
  66bfbd:	00 01 00 00 00 
  66bfc2:	48 c7 84 24 68 01 00 	movq   $0x1,0x168(%rsp)
  66bfc9:	00 01 00 00 00 
  66bfce:	4c 89 b4 24 70 01 00 	mov    %r14,0x170(%rsp)
  66bfd5:	00 
  66bfd6:	48 c7 84 24 78 01 00 	movq   $0x1,0x178(%rsp)
  66bfdd:	00 01 00 00 00 
  66bfe2:	48 c7 84 24 80 01 00 	movq   $0xffffffffffffffff,0x180(%rsp)
  66bfe9:	00 ff ff ff ff 
  66bfee:	44 89 bc 24 98 01 00 	mov    %r15d,0x198(%rsp)
  66bff5:	00 
  66bff6:	f3 0f 10 84 24 84 00 	movss  0x84(%rsp),%xmm0
  66bffd:	00 00 
  66bfff:	f3 0f 11 84 24 9c 01 	movss  %xmm0,0x19c(%rsp)
  66c006:	00 00 
  66c008:	4c 8b bc 24 e8 00 00 	mov    0xe8(%rsp),%r15
  66c00f:	00 
  66c010:	48 8b 9c 24 f0 00 00 	mov    0xf0(%rsp),%rbx
  66c017:	00 
  66c018:	4c 8b b4 24 f8 00 00 	mov    0xf8(%rsp),%r14
  66c01f:	00 
  66c020:	4c 89 ef             	mov    %r13,%rdi
  66c023:	48 8b b4 24 08 02 00 	mov    0x208(%rsp),%rsi
  66c02a:	00 
  66c02b:	e8 30 06 00 00       	call   66c660 <<gpui_canvas::text::planner::Planner>::font_set>
  66c030:	49 89 c4             	mov    %rax,%r12
  66c033:	48 89 84 24 c0 04 00 	mov    %rax,0x4c0(%rsp)
  66c03a:	00 
  66c03b:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
  66c042:	00 
  66c043:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  66c047:	0f 84 c7 00 00 00    	je     66c114 <<gpui_canvas::text::planner::Planner>::shape+0x3444>
  66c04d:	48 8d 94 24 58 01 00 	lea    0x158(%rsp),%rdx
  66c054:	00 
  66c055:	48 8b 4a 40          	mov    0x40(%rdx),%rcx
  66c059:	48 89 8c 24 68 07 00 	mov    %rcx,0x768(%rsp)
  66c060:	00 
  66c061:	0f 10 02             	movups (%rdx),%xmm0
  66c064:	0f 10 4a 10          	movups 0x10(%rdx),%xmm1
  66c068:	0f 10 52 20          	movups 0x20(%rdx),%xmm2
  66c06c:	0f 10 5a 30          	movups 0x30(%rdx),%xmm3
  66c070:	0f 11 9c 24 58 07 00 	movups %xmm3,0x758(%rsp)
  66c077:	00 
  66c078:	0f 11 94 24 48 07 00 	movups %xmm2,0x748(%rsp)
  66c07f:	00 
  66c080:	0f 11 8c 24 38 07 00 	movups %xmm1,0x738(%rsp)
  66c087:	00 
  66c088:	0f 11 84 24 28 07 00 	movups %xmm0,0x728(%rsp)
  66c08f:	00 
  66c090:	48 c7 84 24 10 07 00 	movq   $0x1,0x710(%rsp)
  66c097:	00 01 00 00 00 
  66c09c:	48 c7 84 24 18 07 00 	movq   $0x1,0x718(%rsp)
  66c0a3:	00 01 00 00 00 
  66c0a8:	4c 8d ac 24 20 07 00 	lea    0x720(%rsp),%r13
  66c0af:	00 
  66c0b0:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
  66c0b7:	00 
  66c0b8:	bf 08 00 00 00       	mov    $0x8,%edi
  66c0bd:	be 60 00 00 00       	mov    $0x60,%esi
  66c0c2:	e8 f9 0b 00 00       	call   66ccc0 <alloc::boxed::box_new_uninit>
  66c0c7:	0f 10 84 24 60 07 00 	movups 0x760(%rsp),%xmm0
  66c0ce:	00 
  66c0cf:	0f 11 40 50          	movups %xmm0,0x50(%rax)
  66c0d3:	0f 10 84 24 50 07 00 	movups 0x750(%rsp),%xmm0
  66c0da:	00 
  66c0db:	0f 11 40 40          	movups %xmm0,0x40(%rax)
  66c0df:	0f 10 84 24 10 07 00 	movups 0x710(%rsp),%xmm0
  66c0e6:	00 
  66c0e7:	0f 10 8c 24 20 07 00 	movups 0x720(%rsp),%xmm1
  66c0ee:	00 
  66c0ef:	0f 10 94 24 30 07 00 	movups 0x730(%rsp),%xmm2
  66c0f6:	00 
  66c0f7:	0f 10 9c 24 40 07 00 	movups 0x740(%rsp),%xmm3
  66c0fe:	00 
  66c0ff:	0f 11 58 30          	movups %xmm3,0x30(%rax)
  66c103:	0f 11 50 20          	movups %xmm2,0x20(%rax)
  66c107:	0f 11 48 10          	movups %xmm1,0x10(%rax)
  66c10b:	0f 11 00             	movups %xmm0,(%rax)
  66c10e:	4c 8b 2c 24          	mov    (%rsp),%r13
  66c112:	eb 02                	jmp    66c116 <<gpui_canvas::text::planner::Planner>::shape+0x3446>
  66c114:	31 c0                	xor    %eax,%eax
  66c116:	4c 89 bc 24 88 00 00 	mov    %r15,0x88(%rsp)
  66c11d:	00 
  66c11e:	48 89 9c 24 90 00 00 	mov    %rbx,0x90(%rsp)
  66c125:	00 
  66c126:	4c 89 b4 24 98 00 00 	mov    %r14,0x98(%rsp)
  66c12d:	00 
  66c12e:	4c 89 a4 24 a0 00 00 	mov    %r12,0xa0(%rsp)
  66c135:	00 
  66c136:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
  66c13d:	00 
  66c13e:	0f 28 84 24 80 02 00 	movaps 0x280(%rsp),%xmm0
  66c145:	00 
  66c146:	f3 0f 11 84 24 b0 00 	movss  %xmm0,0xb0(%rsp)
  66c14d:	00 00 
  66c14f:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
  66c155:	f3 0f 11 84 24 b4 00 	movss  %xmm0,0xb4(%rsp)
  66c15c:	00 00 
  66c15e:	f3 0f 10 44 24 7c    	movss  0x7c(%rsp),%xmm0
  66c164:	f3 0f 11 84 24 b8 00 	movss  %xmm0,0xb8(%rsp)
  66c16b:	00 00 
  66c16d:	f3 0f 10 84 24 84 00 	movss  0x84(%rsp),%xmm0
  66c174:	00 00 
  66c176:	f3 0f 11 84 24 bc 00 	movss  %xmm0,0xbc(%rsp)
  66c17d:	00 00 
  66c17f:	48 8d bc 24 a0 02 00 	lea    0x2a0(%rsp),%rdi
  66c186:	00 
  66c187:	e8 b4 a8 ff ff       	call   666a40 <core::ptr::drop_glue::<[parlance::font_family::FontFamilyName; 3]>>
  66c18c:	49 83 ff ff          	cmp    $0xffffffffffffffff,%r15
  66c190:	0f 85 af f9 ff ff    	jne    66bb45 <<gpui_canvas::text::planner::Planner>::shape+0x2e75>
  66c196:	e9 56 f8 ff ff       	jmp    66b9f1 <<gpui_canvas::text::planner::Planner>::shape+0x2d21>
  66c19b:	48 8d 0d 1e 37 11 00 	lea    0x11371e(%rip),%rcx        # 77f8c0 <anon.078e2e963a048095b6b8e4da3cd13e67.23.llvm.9964956014867501821>
  66c1a2:	48 89 f7             	mov    %rsi,%rdi
  66c1a5:	48 89 d6             	mov    %rdx,%rsi
  66c1a8:	4c 89 c2             	mov    %r8,%rdx
  66c1ab:	ff 15 57 de 11 00    	call   *0x11de57(%rip)        # 78a008 <_DYNAMIC+0x558>
  66c1b1:	e9 95 01 00 00       	jmp    66c34b <<gpui_canvas::text::planner::Planner>::shape+0x367b>
  66c1b6:	48 01 c1             	add    %rax,%rcx
  66c1b9:	88 51 ff             	mov    %dl,-0x1(%rcx)
  66c1bc:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  66c1c3:	00 ff 
  66c1c5:	0f 85 10 fb ff ff    	jne    66bcdb <<gpui_canvas::text::planner::Planner>::shape+0x300b>
  66c1cb:	e9 38 fe ff ff       	jmp    66c008 <<gpui_canvas::text::planner::Planner>::shape+0x3338>
  66c1d0:	48 89 cb             	mov    %rcx,%rbx
  66c1d3:	48 8b 84 24 00 02 00 	mov    0x200(%rsp),%rax
  66c1da:	00 
  66c1db:	48 89 84 24 40 01 00 	mov    %rax,0x140(%rsp)
  66c1e2:	00 
  66c1e3:	48 8d 0d 6e 30 11 00 	lea    0x11306e(%rip),%rcx        # 77f258 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0x188>
  66c1ea:	e9 c0 fc ff ff       	jmp    66beaf <<gpui_canvas::text::planner::Planner>::shape+0x31df>
  66c1ef:	48 89 d3             	mov    %rdx,%rbx
  66c1f2:	4c 89 b4 24 40 01 00 	mov    %r14,0x140(%rsp)
  66c1f9:	00 
  66c1fa:	48 8d 0d 1f 2f 11 00 	lea    0x112f1f(%rip),%rcx        # 77f120 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0x50>
  66c201:	e9 a9 fc ff ff       	jmp    66beaf <<gpui_canvas::text::planner::Planner>::shape+0x31df>
  66c206:	48 8d 0d a3 40 11 00 	lea    0x1140a3(%rip),%rcx        # 7802b0 <anon.c85b311aa65b1c615d2dfba884aacc4b.17.llvm.6911206892222571341>
  66c20d:	ff 15 f5 dd 11 00    	call   *0x11ddf5(%rip)        # 78a008 <_DYNAMIC+0x558>
  66c213:	e9 33 01 00 00       	jmp    66c34b <<gpui_canvas::text::planner::Planner>::shape+0x367b>
  66c218:	48 8d 0d 91 40 11 00 	lea    0x114091(%rip),%rcx        # 7802b0 <anon.c85b311aa65b1c615d2dfba884aacc4b.17.llvm.6911206892222571341>
  66c21f:	ff 15 e3 dd 11 00    	call   *0x11dde3(%rip)        # 78a008 <_DYNAMIC+0x558>
  66c225:	e9 21 01 00 00       	jmp    66c34b <<gpui_canvas::text::planner::Planner>::shape+0x367b>
  66c22a:	48 8d 3d ef 3c 11 00 	lea    0x113cef(%rip),%rdi        # 77ff20 <anon.8910945c9b008592b86f990050da00b9.41.llvm.9241406763855203124>
  66c231:	ff 15 b1 db 11 00    	call   *0x11dbb1(%rip)        # 789de8 <_DYNAMIC+0x338>
  66c237:	e9 0f 01 00 00       	jmp    66c34b <<gpui_canvas::text::planner::Planner>::shape+0x367b>
  66c23c:	83 f8 fe             	cmp    $0xfffffffe,%eax
  66c23f:	0f 85 f1 f9 ff ff    	jne    66bc36 <<gpui_canvas::text::planner::Planner>::shape+0x2f66>
  66c245:	b8 03 00 00 00       	mov    $0x3,%eax
  66c24a:	e9 e7 f9 ff ff       	jmp    66bc36 <<gpui_canvas::text::planner::Planner>::shape+0x2f66>
  66c24f:	4c 8d 05 42 2f 11 00 	lea    0x112f42(%rip),%r8        # 77f198 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0xc8>
  66c256:	48 8b bc 24 48 01 00 	mov    0x148(%rsp),%rdi
  66c25d:	00 
  66c25e:	48 8b 74 24 50       	mov    0x50(%rsp),%rsi
  66c263:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
  66c268:	ff 15 0a de 11 00    	call   *0x11de0a(%rip)        # 78a078 <_DYNAMIC+0x5c8>
  66c26e:	e9 d8 00 00 00       	jmp    66c34b <<gpui_canvas::text::planner::Planner>::shape+0x367b>
  66c273:	48 8d 05 be 2e 11 00 	lea    0x112ebe(%rip),%rax        # 77f138 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0x68>
  66c27a:	eb 1f                	jmp    66c29b <<gpui_canvas::text::planner::Planner>::shape+0x35cb>
  66c27c:	49 39 d6             	cmp    %rdx,%r14
  66c27f:	49 0f 47 d6          	cmova  %r14,%rdx
  66c283:	48 8d 05 9e 30 11 00 	lea    0x11309e(%rip),%rax        # 77f328 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0x258>
  66c28a:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  66c28f:	48 89 d7             	mov    %rdx,%rdi
  66c292:	eb 0c                	jmp    66c2a0 <<gpui_canvas::text::planner::Planner>::shape+0x35d0>
  66c294:	48 8d 05 5d 2f 11 00 	lea    0x112f5d(%rip),%rax        # 77f1f8 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0x128>
  66c29b:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  66c2a0:	48 8b b4 24 e8 01 00 	mov    0x1e8(%rsp),%rsi
  66c2a7:	00 
  66c2a8:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
  66c2ad:	ff 15 5d db 11 00    	call   *0x11db5d(%rip)        # 789e10 <_DYNAMIC+0x360>
  66c2b3:	e9 93 00 00 00       	jmp    66c34b <<gpui_canvas::text::planner::Planner>::shape+0x367b>
  66c2b8:	48 8d 0d 49 36 11 00 	lea    0x113649(%rip),%rcx        # 77f908 <anon.078e2e963a048095b6b8e4da3cd13e67.28.llvm.9964956014867501821>
  66c2bf:	48 89 8c 24 70 02 00 	mov    %rcx,0x270(%rsp)
  66c2c6:	00 
  66c2c7:	eb 04                	jmp    66c2cd <<gpui_canvas::text::planner::Planner>::shape+0x35fd>
  66c2c9:	31 ff                	xor    %edi,%edi
  66c2cb:	31 c0                	xor    %eax,%eax
  66c2cd:	48 89 c6             	mov    %rax,%rsi
  66c2d0:	48 8b 94 24 70 02 00 	mov    0x270(%rsp),%rdx
  66c2d7:	00 
  66c2d8:	ff 15 32 db 11 00    	call   *0x11db32(%rip)        # 789e10 <_DYNAMIC+0x360>
  66c2de:	eb 6b                	jmp    66c34b <<gpui_canvas::text::planner::Planner>::shape+0x367b>
  66c2e0:	31 ff                	xor    %edi,%edi
  66c2e2:	48 c7 84 24 e8 01 00 	movq   $0x0,0x1e8(%rsp)
  66c2e9:	00 00 00 00 00 
  66c2ee:	eb b0                	jmp    66c2a0 <<gpui_canvas::text::planner::Planner>::shape+0x35d0>
  66c2f0:	48 8d 15 99 3e 11 00 	lea    0x113e99(%rip),%rdx        # 780190 <anon.8910945c9b008592b86f990050da00b9.70.llvm.9241406763855203124>
  66c2f7:	ff 15 13 db 11 00    	call   *0x11db13(%rip)        # 789e10 <_DYNAMIC+0x360>
  66c2fd:	eb 4c                	jmp    66c34b <<gpui_canvas::text::planner::Planner>::shape+0x367b>
  66c2ff:	48 8d 05 0a 30 11 00 	lea    0x11300a(%rip),%rax        # 77f310 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0x240>
  66c306:	eb 93                	jmp    66c29b <<gpui_canvas::text::planner::Planner>::shape+0x35cb>
  66c308:	48 89 d7             	mov    %rdx,%rdi
  66c30b:	48 8d 05 2e 30 11 00 	lea    0x11302e(%rip),%rax        # 77f340 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0x270>
  66c312:	eb 87                	jmp    66c29b <<gpui_canvas::text::planner::Planner>::shape+0x35cb>
  66c314:	48 8d 05 c5 2e 11 00 	lea    0x112ec5(%rip),%rax        # 77f1e0 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0x110>
  66c31b:	e9 7b ff ff ff       	jmp    66c29b <<gpui_canvas::text::planner::Planner>::shape+0x35cb>
  66c320:	48 8d 05 e9 2e 11 00 	lea    0x112ee9(%rip),%rax        # 77f210 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0x140>
  66c327:	e9 6f ff ff ff       	jmp    66c29b <<gpui_canvas::text::planner::Planner>::shape+0x35cb>
  66c32c:	48 89 d7             	mov    %rdx,%rdi
  66c32f:	48 8d 05 f2 2e 11 00 	lea    0x112ef2(%rip),%rax        # 77f228 <anon.2c46a9959e2f71f263d4170cfeb3791b.3.llvm.869905948497522356+0x158>
  66c336:	e9 60 ff ff ff       	jmp    66c29b <<gpui_canvas::text::planner::Planner>::shape+0x35cb>
  66c33b:	48 8d 15 c6 35 11 00 	lea    0x1135c6(%rip),%rdx        # 77f908 <anon.078e2e963a048095b6b8e4da3cd13e67.28.llvm.9964956014867501821>
  66c342:	48 89 c6             	mov    %rax,%rsi
  66c345:	ff 15 c5 da 11 00    	call   *0x11dac5(%rip)        # 789e10 <_DYNAMIC+0x360>
  66c34b:	0f 0b                	ud2
  66c34d:	49 89 c6             	mov    %rax,%r14
  66c350:	be 18 00 00 00       	mov    $0x18,%esi
  66c355:	ba 04 00 00 00       	mov    $0x4,%edx
  66c35a:	48 89 df             	mov    %rbx,%rdi
  66c35d:	ff 15 85 d9 11 00    	call   *0x11d985(%rip)        # 789ce8 <_DYNAMIC+0x238>
  66c363:	e9 9a 02 00 00       	jmp    66c602 <<gpui_canvas::text::planner::Planner>::shape+0x3932>
  66c368:	49 89 c6             	mov    %rax,%r14
  66c36b:	4c 89 ef             	mov    %r13,%rdi
  66c36e:	e8 ed be ff ff       	call   668260 <core::ptr::drop_glue::<gpui_canvas::text::layout::TextGeometry>>
  66c373:	f0 49 ff 0c 24       	lock decq (%r12)
  66c378:	75 0e                	jne    66c388 <<gpui_canvas::text::planner::Planner>::shape+0x36b8>
  66c37a:	48 8d bc 24 c0 04 00 	lea    0x4c0(%rsp),%rdi
  66c381:	00 
  66c382:	ff 15 78 d9 11 00    	call   *0x11d978(%rip)        # 789d00 <_DYNAMIC+0x250>
  66c388:	31 ed                	xor    %ebp,%ebp
  66c38a:	eb 0c                	jmp    66c398 <<gpui_canvas::text::planner::Planner>::shape+0x36c8>
  66c38c:	ff 15 76 d9 11 00    	call   *0x11d976(%rip)        # 789d08 <_DYNAMIC+0x258>
  66c392:	49 89 c6             	mov    %rax,%r14
  66c395:	40 b5 01             	mov    $0x1,%bpl
  66c398:	4d 85 ff             	test   %r15,%r15
  66c39b:	74 15                	je     66c3b2 <<gpui_canvas::text::planner::Planner>::shape+0x36e2>
  66c39d:	49 c1 e7 04          	shl    $0x4,%r15
  66c3a1:	ba 04 00 00 00       	mov    $0x4,%edx
  66c3a6:	48 89 df             	mov    %rbx,%rdi
  66c3a9:	4c 89 fe             	mov    %r15,%rsi
  66c3ac:	ff 15 36 d9 11 00    	call   *0x11d936(%rip)        # 789ce8 <_DYNAMIC+0x238>
  66c3b2:	40 84 ed             	test   %bpl,%bpl
  66c3b5:	0f 84 89 02 00 00    	je     66c644 <<gpui_canvas::text::planner::Planner>::shape+0x3974>
  66c3bb:	31 db                	xor    %ebx,%ebx
  66c3bd:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  66c3c4:	00 ff 
  66c3c6:	0f 84 fb 01 00 00    	je     66c5c7 <<gpui_canvas::text::planner::Planner>::shape+0x38f7>
  66c3cc:	e9 3e 02 00 00       	jmp    66c60f <<gpui_canvas::text::planner::Planner>::shape+0x393f>
  66c3d1:	49 89 c6             	mov    %rax,%r14
  66c3d4:	4c 89 3b             	mov    %r15,(%rbx)
  66c3d7:	4c 89 f7             	mov    %r14,%rdi
  66c3da:	e8 31 19 11 00       	call   77dd10 <_Unwind_Resume@plt>
  66c3df:	e9 1b 02 00 00       	jmp    66c5ff <<gpui_canvas::text::planner::Planner>::shape+0x392f>
  66c3e4:	e9 16 02 00 00       	jmp    66c5ff <<gpui_canvas::text::planner::Planner>::shape+0x392f>
  66c3e9:	e9 11 02 00 00       	jmp    66c5ff <<gpui_canvas::text::planner::Planner>::shape+0x392f>
  66c3ee:	e9 b7 01 00 00       	jmp    66c5aa <<gpui_canvas::text::planner::Planner>::shape+0x38da>
  66c3f3:	e9 07 02 00 00       	jmp    66c5ff <<gpui_canvas::text::planner::Planner>::shape+0x392f>
  66c3f8:	e9 02 02 00 00       	jmp    66c5ff <<gpui_canvas::text::planner::Planner>::shape+0x392f>
  66c3fd:	e9 fd 01 00 00       	jmp    66c5ff <<gpui_canvas::text::planner::Planner>::shape+0x392f>
  66c402:	e9 a3 01 00 00       	jmp    66c5aa <<gpui_canvas::text::planner::Planner>::shape+0x38da>
  66c407:	e9 f3 01 00 00       	jmp    66c5ff <<gpui_canvas::text::planner::Planner>::shape+0x392f>
  66c40c:	49 89 c6             	mov    %rax,%r14
  66c40f:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  66c416:	00 
  66c417:	e8 74 3e 00 00       	call   670290 <core::ptr::drop_glue::<parley::style::StyleProperty<()>>>
  66c41c:	e9 e1 01 00 00       	jmp    66c602 <<gpui_canvas::text::planner::Planner>::shape+0x3932>
  66c421:	ff 15 e1 d8 11 00    	call   *0x11d8e1(%rip)        # 789d08 <_DYNAMIC+0x258>
  66c427:	49 89 c6             	mov    %rax,%r14
  66c42a:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  66c431:	00 
  66c432:	e8 59 3e 00 00       	call   670290 <core::ptr::drop_glue::<parley::style::StyleProperty<()>>>
  66c437:	e9 c6 01 00 00       	jmp    66c602 <<gpui_canvas::text::planner::Planner>::shape+0x3932>
  66c43c:	ff 15 c6 d8 11 00    	call   *0x11d8c6(%rip)        # 789d08 <_DYNAMIC+0x258>
  66c442:	49 89 c6             	mov    %rax,%r14
  66c445:	49 c7 85 c8 08 00 00 	movq   $0x0,0x8c8(%r13)
  66c44c:	00 00 00 00 
  66c450:	49 c7 85 d0 08 00 00 	movq   $0x4,0x8d0(%r13)
  66c457:	04 00 00 00 
  66c45b:	0f 57 c0             	xorps  %xmm0,%xmm0
  66c45e:	41 0f 11 85 d8 08 00 	movups %xmm0,0x8d8(%r13)
  66c465:	00 
  66c466:	49 c7 85 e8 08 00 00 	movq   $0x4,0x8e8(%r13)
  66c46d:	04 00 00 00 
  66c471:	41 0f 11 85 f0 08 00 	movups %xmm0,0x8f0(%r13)
  66c478:	00 
  66c479:	49 c7 85 00 09 00 00 	movq   $0x8,0x900(%r13)
  66c480:	08 00 00 00 
  66c484:	41 0f 11 85 08 09 00 	movups %xmm0,0x908(%r13)
  66c48b:	00 
  66c48c:	49 c7 85 18 09 00 00 	movq   $0x8,0x918(%r13)
  66c493:	08 00 00 00 
  66c497:	41 0f 11 85 20 09 00 	movups %xmm0,0x920(%r13)
  66c49e:	00 
  66c49f:	49 c7 85 30 09 00 00 	movq   $0x4,0x930(%r13)
  66c4a6:	04 00 00 00 
  66c4aa:	41 0f 11 85 38 09 00 	movups %xmm0,0x938(%r13)
  66c4b1:	00 
  66c4b2:	49 c7 85 48 09 00 00 	movq   $0x4,0x948(%r13)
  66c4b9:	04 00 00 00 
  66c4bd:	41 0f 11 85 50 09 00 	movups %xmm0,0x950(%r13)
  66c4c4:	00 
  66c4c5:	49 c7 85 60 09 00 00 	movq   $0x4,0x960(%r13)
  66c4cc:	04 00 00 00 
  66c4d0:	41 0f 11 85 68 09 00 	movups %xmm0,0x968(%r13)
  66c4d7:	00 
  66c4d8:	49 c7 85 78 09 00 00 	movq   $0x8,0x978(%r13)
  66c4df:	08 00 00 00 
  66c4e3:	41 0f 11 85 80 09 00 	movups %xmm0,0x980(%r13)
  66c4ea:	00 
  66c4eb:	49 c7 85 90 09 00 00 	movq   $0x2,0x990(%r13)
  66c4f2:	02 00 00 00 
  66c4f6:	41 0f 11 85 98 09 00 	movups %xmm0,0x998(%r13)
  66c4fd:	00 
  66c4fe:	49 c7 85 a8 09 00 00 	movq   $0x4,0x9a8(%r13)
  66c505:	04 00 00 00 
  66c509:	41 0f 11 85 b0 09 00 	movups %xmm0,0x9b0(%r13)
  66c510:	00 
  66c511:	49 c7 85 c0 09 00 00 	movq   $0x8,0x9c0(%r13)
  66c518:	08 00 00 00 
  66c51c:	41 0f 11 85 c8 09 00 	movups %xmm0,0x9c8(%r13)
  66c523:	00 
  66c524:	49 c7 85 d8 09 00 00 	movq   $0x8,0x9d8(%r13)
  66c52b:	08 00 00 00 
  66c52f:	41 0f 11 85 e0 09 00 	movups %xmm0,0x9e0(%r13)
  66c536:	00 
  66c537:	49 c7 85 f0 09 00 00 	movq   $0x8,0x9f0(%r13)
  66c53e:	08 00 00 00 
  66c542:	41 0f 11 85 f8 09 00 	movups %xmm0,0x9f8(%r13)
  66c549:	00 
  66c54a:	49 c7 85 08 0a 00 00 	movq   $0x4,0xa08(%r13)
  66c551:	04 00 00 00 
  66c555:	41 0f 11 85 10 0a 00 	movups %xmm0,0xa10(%r13)
  66c55c:	00 
  66c55d:	41 c7 85 20 0a 00 00 	movl   $0x3f800000,0xa20(%r13)
  66c564:	00 00 80 3f 
  66c568:	41 0f 11 85 24 0a 00 	movups %xmm0,0xa24(%r13)
  66c56f:	00 
  66c570:	49 c7 85 32 0a 00 00 	movq   $0x0,0xa32(%r13)
  66c577:	00 00 00 00 
  66c57b:	66 41 c7 85 3a 0a 00 	movw   $0xff01,0xa3a(%r13)
  66c582:	00 01 ff 
  66c585:	41 c6 85 3c 0a 00 00 	movb   $0x0,0xa3c(%r13)
  66c58c:	00 
  66c58d:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
  66c594:	00 
  66c595:	e8 b6 a5 ff ff       	call   666b50 <core::ptr::drop_glue::<core::result::Result<gpui_canvas::text::TextLayout, gpui_canvas::Error>>>
  66c59a:	4c 89 f7             	mov    %r14,%rdi
  66c59d:	e8 6e 17 11 00       	call   77dd10 <_Unwind_Resume@plt>
  66c5a2:	ff 15 60 d7 11 00    	call   *0x11d760(%rip)        # 789d08 <_DYNAMIC+0x258>
  66c5a8:	eb 55                	jmp    66c5ff <<gpui_canvas::text::planner::Planner>::shape+0x392f>
  66c5aa:	49 89 c6             	mov    %rax,%r14
  66c5ad:	48 8b b4 24 10 07 00 	mov    0x710(%rsp),%rsi
  66c5b4:	00 
  66c5b5:	b3 01                	mov    $0x1,%bl
  66c5b7:	48 85 f6             	test   %rsi,%rsi
  66c5ba:	75 11                	jne    66c5cd <<gpui_canvas::text::planner::Planner>::shape+0x38fd>
  66c5bc:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  66c5c3:	00 ff 
  66c5c5:	75 48                	jne    66c60f <<gpui_canvas::text::planner::Planner>::shape+0x393f>
  66c5c7:	84 db                	test   %bl,%bl
  66c5c9:	75 55                	jne    66c620 <<gpui_canvas::text::planner::Planner>::shape+0x3950>
  66c5cb:	eb 77                	jmp    66c644 <<gpui_canvas::text::planner::Planner>::shape+0x3974>
  66c5cd:	48 8b bc 24 18 07 00 	mov    0x718(%rsp),%rdi
  66c5d4:	00 
  66c5d5:	48 c1 e6 03          	shl    $0x3,%rsi
  66c5d9:	ba 08 00 00 00       	mov    $0x8,%edx
  66c5de:	ff 15 04 d7 11 00    	call   *0x11d704(%rip)        # 789ce8 <_DYNAMIC+0x238>
  66c5e4:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  66c5eb:	00 ff 
  66c5ed:	74 d8                	je     66c5c7 <<gpui_canvas::text::planner::Planner>::shape+0x38f7>
  66c5ef:	eb 1e                	jmp    66c60f <<gpui_canvas::text::planner::Planner>::shape+0x393f>
  66c5f1:	eb 0c                	jmp    66c5ff <<gpui_canvas::text::planner::Planner>::shape+0x392f>
  66c5f3:	eb 0a                	jmp    66c5ff <<gpui_canvas::text::planner::Planner>::shape+0x392f>
  66c5f5:	eb 08                	jmp    66c5ff <<gpui_canvas::text::planner::Planner>::shape+0x392f>
  66c5f7:	eb 06                	jmp    66c5ff <<gpui_canvas::text::planner::Planner>::shape+0x392f>
  66c5f9:	eb 04                	jmp    66c5ff <<gpui_canvas::text::planner::Planner>::shape+0x392f>
  66c5fb:	eb 02                	jmp    66c5ff <<gpui_canvas::text::planner::Planner>::shape+0x392f>
  66c5fd:	eb 00                	jmp    66c5ff <<gpui_canvas::text::planner::Planner>::shape+0x392f>
  66c5ff:	49 89 c6             	mov    %rax,%r14
  66c602:	b3 01                	mov    $0x1,%bl
  66c604:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  66c60b:	00 ff 
  66c60d:	74 b8                	je     66c5c7 <<gpui_canvas::text::planner::Planner>::shape+0x38f7>
  66c60f:	48 8d bc 24 50 01 00 	lea    0x150(%rsp),%rdi
  66c616:	00 
  66c617:	e8 44 bc ff ff       	call   668260 <core::ptr::drop_glue::<gpui_canvas::text::layout::TextGeometry>>
  66c61c:	84 db                	test   %bl,%bl
  66c61e:	74 24                	je     66c644 <<gpui_canvas::text::planner::Planner>::shape+0x3974>
  66c620:	48 8b b4 24 e8 00 00 	mov    0xe8(%rsp),%rsi
  66c627:	00 
  66c628:	48 85 f6             	test   %rsi,%rsi
  66c62b:	74 17                	je     66c644 <<gpui_canvas::text::planner::Planner>::shape+0x3974>
  66c62d:	48 8b bc 24 f0 00 00 	mov    0xf0(%rsp),%rdi
  66c634:	00 
  66c635:	48 c1 e6 04          	shl    $0x4,%rsi
  66c639:	ba 04 00 00 00       	mov    $0x4,%edx
  66c63e:	ff 15 a4 d6 11 00    	call   *0x11d6a4(%rip)        # 789ce8 <_DYNAMIC+0x238>
  66c644:	48 8d bc 24 a0 02 00 	lea    0x2a0(%rsp),%rdi
  66c64b:	00 
  66c64c:	e8 ef a3 ff ff       	call   666a40 <core::ptr::drop_glue::<[parlance::font_family::FontFamilyName; 3]>>
  66c651:	4c 89 f7             	mov    %r14,%rdi
  66c654:	e8 b7 16 11 00       	call   77dd10 <_Unwind_Resume@plt>
