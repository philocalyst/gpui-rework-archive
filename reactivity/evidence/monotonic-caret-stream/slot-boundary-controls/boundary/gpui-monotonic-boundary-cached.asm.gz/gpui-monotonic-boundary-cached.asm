
/tmp/gpui-monotonic-control-bin/stream-boundary:     file format elf64-x86-64


Disassembly of section .text:

00000000006718e0 <parley::editing::geometry::cached_pair::<()>>:
  6718e0:	55                   	push   %rbp
  6718e1:	41 57                	push   %r15
  6718e3:	41 56                	push   %r14
  6718e5:	41 55                	push   %r13
  6718e7:	41 54                	push   %r12
  6718e9:	53                   	push   %rbx
  6718ea:	48 81 ec d8 01 00 00 	sub    $0x1d8,%rsp
  6718f1:	49 89 f6             	mov    %rsi,%r14
  6718f4:	48 89 fb             	mov    %rdi,%rbx
  6718f7:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  6718fc:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
  671901:	4d 85 c0             	test   %r8,%r8
  671904:	74 4a                	je     671950 <parley::editing::geometry::cached_pair::<()>+0x70>
  671906:	41 8b 00             	mov    (%r8),%eax
  671909:	49 39 86 18 01 00 00 	cmp    %rax,0x118(%r14)
  671910:	76 3e                	jbe    671950 <parley::editing::geometry::cached_pair::<()>+0x70>
  671912:	41 8b 70 04          	mov    0x4(%r8),%esi
  671916:	4c 6b c8 70          	imul   $0x70,%rax,%r9
  67191a:	4d 8b 96 10 01 00 00 	mov    0x110(%r14),%r10
  671921:	4b 8b 7c 0a 10       	mov    0x10(%r10,%r9,1),%rdi
  671926:	48 01 f7             	add    %rsi,%rdi
  671929:	4b 3b 7c 0a 18       	cmp    0x18(%r10,%r9,1),%rdi
  67192e:	73 20                	jae    671950 <parley::editing::geometry::cached_pair::<()>+0x70>
  671930:	49 3b be 30 01 00 00 	cmp    0x130(%r14),%rdi
  671937:	73 17                	jae    671950 <parley::editing::geometry::cached_pair::<()>+0x70>
  671939:	4d 8b 8e 28 01 00 00 	mov    0x128(%r14),%r9
  671940:	48 8d 3c bf          	lea    (%rdi,%rdi,4),%rdi
  671944:	41 80 7c f9 21 00    	cmpb   $0x0,0x21(%r9,%rdi,8)
  67194a:	0f 84 e7 01 00 00    	je     671b37 <parley::editing::geometry::cached_pair::<()>+0x257>
  671950:	48 c7 84 24 48 01 00 	movq   $0x0,0x148(%rsp)
  671957:	00 00 00 00 00 
  67195c:	49 8b 86 50 01 00 00 	mov    0x150(%r14),%rax
  671963:	40 b5 01             	mov    $0x1,%bpl
  671966:	45 31 ff             	xor    %r15d,%r15d
  671969:	48 39 d0             	cmp    %rdx,%rax
  67196c:	0f 85 0a 03 00 00    	jne    671c7c <parley::editing::geometry::cached_pair::<()>+0x39c>
  671972:	48 85 c9             	test   %rcx,%rcx
  671975:	f3 0f 11 44 24 0c    	movss  %xmm0,0xc(%rsp)
  67197b:	74 48                	je     6719c5 <parley::editing::geometry::cached_pair::<()>+0xe5>
  67197d:	8b 01                	mov    (%rcx),%eax
  67197f:	49 39 86 18 01 00 00 	cmp    %rax,0x118(%r14)
  671986:	76 3d                	jbe    6719c5 <parley::editing::geometry::cached_pair::<()>+0xe5>
  671988:	8b 71 04             	mov    0x4(%rcx),%esi
  67198b:	4c 6b c0 70          	imul   $0x70,%rax,%r8
  67198f:	4d 8b 8e 10 01 00 00 	mov    0x110(%r14),%r9
  671996:	4b 8b 7c 01 10       	mov    0x10(%r9,%r8,1),%rdi
  67199b:	48 01 f7             	add    %rsi,%rdi
  67199e:	4b 3b 7c 01 18       	cmp    0x18(%r9,%r8,1),%rdi
  6719a3:	73 20                	jae    6719c5 <parley::editing::geometry::cached_pair::<()>+0xe5>
  6719a5:	49 3b be 30 01 00 00 	cmp    0x130(%r14),%rdi
  6719ac:	73 17                	jae    6719c5 <parley::editing::geometry::cached_pair::<()>+0xe5>
  6719ae:	4d 8b 86 28 01 00 00 	mov    0x128(%r14),%r8
  6719b5:	48 8d 3c bf          	lea    (%rdi,%rdi,4),%rdi
  6719b9:	41 80 7c f8 21 00    	cmpb   $0x0,0x21(%r8,%rdi,8)
  6719bf:	0f 84 d3 02 00 00    	je     671c98 <parley::editing::geometry::cached_pair::<()>+0x3b8>
  6719c5:	48 c7 84 24 b8 00 00 	movq   $0x0,0xb8(%rsp)
  6719cc:	00 00 00 00 00 
  6719d1:	45 31 e4             	xor    %r12d,%r12d
  6719d4:	48 89 54 24 60       	mov    %rdx,0x60(%rsp)
  6719d9:	40 88 6c 24 68       	mov    %bpl,0x68(%rsp)
  6719de:	4c 89 64 24 20       	mov    %r12,0x20(%rsp)
  6719e3:	4c 89 7c 24 28       	mov    %r15,0x28(%rsp)
  6719e8:	48 8d bc 24 98 00 00 	lea    0x98(%rsp),%rdi
  6719ef:	00 
  6719f0:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
  6719f5:	48 8d 4c 24 20       	lea    0x20(%rsp),%rcx
  6719fa:	4c 8d 44 24 10       	lea    0x10(%rsp),%r8
  6719ff:	4c 8d 4c 24 18       	lea    0x18(%rsp),%r9
  671a04:	49 89 d5             	mov    %rdx,%r13
  671a07:	4c 89 f2             	mov    %r14,%rdx
  671a0a:	e8 51 c0 00 00       	call   67da60 <<parley::editing::cursor::Cursor>::geometry_with::<(), parley::editing::geometry::cached_pair<()>::{closure#2}::{closure#0}>>
  671a0f:	4d 85 ed             	test   %r13,%r13
  671a12:	0f 84 bb 00 00 00    	je     671ad3 <parley::editing::geometry::cached_pair::<()>+0x1f3>
  671a18:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  671a1f:	00 
  671a20:	48 85 c0             	test   %rax,%rax
  671a23:	0f 84 aa 00 00 00    	je     671ad3 <parley::editing::geometry::cached_pair::<()>+0x1f3>
  671a29:	8b bc 24 70 01 00 00 	mov    0x170(%rsp),%edi
  671a30:	48 8b 70 58          	mov    0x58(%rax),%rsi
  671a34:	48 39 fe             	cmp    %rdi,%rsi
  671a37:	0f 86 ef 02 00 00    	jbe    671d2c <parley::editing::geometry::cached_pair::<()>+0x44c>
  671a3d:	48 8b 48 50          	mov    0x50(%rax),%rcx
  671a41:	48 8d 14 ff          	lea    (%rdi,%rdi,8),%rdx
  671a45:	48 c1 e2 04          	shl    $0x4,%rdx
  671a49:	0f 10 40 68          	movups 0x68(%rax),%xmm0
  671a4d:	0f 10 88 80 00 00 00 	movups 0x80(%rax),%xmm1
  671a54:	0f 10 90 98 00 00 00 	movups 0x98(%rax),%xmm2
  671a5b:	0f 11 44 24 20       	movups %xmm0,0x20(%rsp)
  671a60:	0f 11 4c 24 30       	movups %xmm1,0x30(%rsp)
  671a65:	0f 11 54 24 40       	movups %xmm2,0x40(%rsp)
  671a6a:	48 8b 44 11 50       	mov    0x50(%rcx,%rdx,1),%rax
  671a6f:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  671a74:	8b b4 24 c8 01 00 00 	mov    0x1c8(%rsp),%esi
  671a7b:	8b 94 24 cc 01 00 00 	mov    0x1cc(%rsp),%edx
  671a82:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
  671a87:	ff 15 33 97 11 00    	call   *0x119733(%rip)        # 78b1c0 <_DYNAMIC+0x5d8>
  671a8d:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
  671a94:	00 
  671a95:	c6 84 24 90 00 00 00 	movb   $0x0,0x90(%rsp)
  671a9c:	00 
  671a9d:	4c 89 64 24 20       	mov    %r12,0x20(%rsp)
  671aa2:	4c 89 7c 24 28       	mov    %r15,0x28(%rsp)
  671aa7:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
  671aac:	48 8d b4 24 88 00 00 	lea    0x88(%rsp),%rsi
  671ab3:	00 
  671ab4:	48 8d 4c 24 20       	lea    0x20(%rsp),%rcx
  671ab9:	4c 8d 44 24 10       	lea    0x10(%rsp),%r8
  671abe:	4c 8d 4c 24 18       	lea    0x18(%rsp),%r9
  671ac3:	4c 89 f2             	mov    %r14,%rdx
  671ac6:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  671acc:	e8 8f bf 00 00       	call   67da60 <<parley::editing::cursor::Cursor>::geometry_with::<(), parley::editing::geometry::cached_pair<()>::{closure#2}::{closure#0}>>
  671ad1:	eb 1a                	jmp    671aed <parley::editing::geometry::cached_pair::<()>+0x20d>
  671ad3:	0f 10 84 24 98 00 00 	movups 0x98(%rsp),%xmm0
  671ada:	00 
  671adb:	0f 10 8c 24 a8 00 00 	movups 0xa8(%rsp),%xmm1
  671ae2:	00 
  671ae3:	0f 29 4c 24 70       	movaps %xmm1,0x70(%rsp)
  671ae8:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
  671aed:	0f 10 84 24 98 00 00 	movups 0x98(%rsp),%xmm0
  671af4:	00 
  671af5:	0f 10 8c 24 a8 00 00 	movups 0xa8(%rsp),%xmm1
  671afc:	00 
  671afd:	0f 29 4c 24 30       	movaps %xmm1,0x30(%rsp)
  671b02:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
  671b07:	0f 28 54 24 60       	movaps 0x60(%rsp),%xmm2
  671b0c:	0f 28 5c 24 70       	movaps 0x70(%rsp),%xmm3
  671b11:	0f 29 54 24 40       	movaps %xmm2,0x40(%rsp)
  671b16:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
  671b1b:	0f 11 5b 38          	movups %xmm3,0x38(%rbx)
  671b1f:	0f 11 53 28          	movups %xmm2,0x28(%rbx)
  671b23:	0f 11 4b 18          	movups %xmm1,0x18(%rbx)
  671b27:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
  671b2b:	48 c7 03 01 00 00 00 	movq   $0x1,(%rbx)
  671b32:	e9 4c 01 00 00       	jmp    671c83 <parley::editing::geometry::cached_pair::<()>+0x3a3>
  671b37:	4d 8d 0c f9          	lea    (%r9,%rdi,8),%r9
  671b3b:	49 8b 79 10          	mov    0x10(%r9),%rdi
  671b3f:	49 3b 7e 58          	cmp    0x58(%r14),%rdi
  671b43:	0f 83 07 fe ff ff    	jae    671950 <parley::editing::geometry::cached_pair::<()>+0x70>
  671b49:	49 3b be e8 00 00 00 	cmp    0xe8(%r14),%rdi
  671b50:	0f 83 fa fd ff ff    	jae    671950 <parley::editing::geometry::cached_pair::<()>+0x70>
  671b56:	4c 8d 14 ff          	lea    (%rdi,%rdi,8),%r10
  671b5a:	49 c1 e2 04          	shl    $0x4,%r10
  671b5e:	4d 03 56 50          	add    0x50(%r14),%r10
  671b62:	4c 8d 1c bf          	lea    (%rdi,%rdi,4),%r11
  671b66:	49 c1 e3 04          	shl    $0x4,%r11
  671b6a:	4d 03 9e e0 00 00 00 	add    0xe0(%r14),%r11
  671b71:	4c 89 b4 24 b8 00 00 	mov    %r14,0xb8(%rsp)
  671b78:	00 
  671b79:	4c 89 94 24 c0 00 00 	mov    %r10,0xc0(%rsp)
  671b80:	00 
  671b81:	4c 89 9c 24 c8 00 00 	mov    %r11,0xc8(%rsp)
  671b88:	00 
  671b89:	4c 89 8c 24 d0 00 00 	mov    %r9,0xd0(%rsp)
  671b90:	00 
  671b91:	89 84 24 d8 00 00 00 	mov    %eax,0xd8(%rsp)
  671b98:	89 b4 24 dc 00 00 00 	mov    %esi,0xdc(%rsp)
  671b9f:	89 bc 24 e0 00 00 00 	mov    %edi,0xe0(%rsp)
  671ba6:	41 8b 40 08          	mov    0x8(%r8),%eax
  671baa:	4c 8d bc 24 48 01 00 	lea    0x148(%rsp),%r15
  671bb1:	00 
  671bb2:	48 8d b4 24 b8 00 00 	lea    0xb8(%rsp),%rsi
  671bb9:	00 
  671bba:	4c 89 ff             	mov    %r15,%rdi
  671bbd:	49 89 d4             	mov    %rdx,%r12
  671bc0:	89 c2                	mov    %eax,%edx
  671bc2:	49 89 cd             	mov    %rcx,%r13
  671bc5:	f3 0f 11 44 24 0c    	movss  %xmm0,0xc(%rsp)
  671bcb:	e8 30 e2 00 00       	call   67fe00 <<parley::layout::run::Run<()>>::cluster_containing_char>
  671bd0:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  671bd6:	4c 89 e9             	mov    %r13,%rcx
  671bd9:	4c 89 e2             	mov    %r12,%rdx
  671bdc:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  671be3:	00 
  671be4:	48 85 c0             	test   %rax,%rax
  671be7:	0f 84 6f fd ff ff    	je     67195c <parley::editing::geometry::cached_pair::<()>+0x7c>
  671bed:	8b bc 24 70 01 00 00 	mov    0x170(%rsp),%edi
  671bf4:	48 8b 70 58          	mov    0x58(%rax),%rsi
  671bf8:	48 39 fe             	cmp    %rdi,%rsi
  671bfb:	0f 86 2b 01 00 00    	jbe    671d2c <parley::editing::geometry::cached_pair::<()>+0x44c>
  671c01:	48 8b 48 50          	mov    0x50(%rax),%rcx
  671c05:	48 8d 14 ff          	lea    (%rdi,%rdi,8),%rdx
  671c09:	48 c1 e2 04          	shl    $0x4,%rdx
  671c0d:	0f 10 40 68          	movups 0x68(%rax),%xmm0
  671c11:	0f 10 88 80 00 00 00 	movups 0x80(%rax),%xmm1
  671c18:	0f 10 90 98 00 00 00 	movups 0x98(%rax),%xmm2
  671c1f:	0f 11 84 24 b8 00 00 	movups %xmm0,0xb8(%rsp)
  671c26:	00 
  671c27:	0f 11 8c 24 c8 00 00 	movups %xmm1,0xc8(%rsp)
  671c2e:	00 
  671c2f:	0f 11 94 24 d8 00 00 	movups %xmm2,0xd8(%rsp)
  671c36:	00 
  671c37:	48 8b 44 11 50       	mov    0x50(%rcx,%rdx,1),%rax
  671c3c:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
  671c43:	00 
  671c44:	8b b4 24 c8 01 00 00 	mov    0x1c8(%rsp),%esi
  671c4b:	8b 94 24 cc 01 00 00 	mov    0x1cc(%rsp),%edx
  671c52:	48 8d bc 24 b8 00 00 	lea    0xb8(%rsp),%rdi
  671c59:	00 
  671c5a:	ff 15 60 95 11 00    	call   *0x119560(%rip)        # 78b1c0 <_DYNAMIC+0x5d8>
  671c60:	48 85 c0             	test   %rax,%rax
  671c63:	40 0f 95 c5          	setne  %bpl
  671c67:	4c 89 e2             	mov    %r12,%rdx
  671c6a:	4c 89 e9             	mov    %r13,%rcx
  671c6d:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  671c73:	48 39 d0             	cmp    %rdx,%rax
  671c76:	0f 84 f6 fc ff ff    	je     671972 <parley::editing::geometry::cached_pair::<()>+0x92>
  671c7c:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
  671c83:	48 89 d8             	mov    %rbx,%rax
  671c86:	48 81 c4 d8 01 00 00 	add    $0x1d8,%rsp
  671c8d:	5b                   	pop    %rbx
  671c8e:	41 5c                	pop    %r12
  671c90:	41 5d                	pop    %r13
  671c92:	41 5e                	pop    %r14
  671c94:	41 5f                	pop    %r15
  671c96:	5d                   	pop    %rbp
  671c97:	c3                   	ret
  671c98:	4d 8d 04 f8          	lea    (%r8,%rdi,8),%r8
  671c9c:	49 8b 78 10          	mov    0x10(%r8),%rdi
  671ca0:	49 3b 7e 58          	cmp    0x58(%r14),%rdi
  671ca4:	0f 83 1b fd ff ff    	jae    6719c5 <parley::editing::geometry::cached_pair::<()>+0xe5>
  671caa:	49 3b be e8 00 00 00 	cmp    0xe8(%r14),%rdi
  671cb1:	0f 83 0e fd ff ff    	jae    6719c5 <parley::editing::geometry::cached_pair::<()>+0xe5>
  671cb7:	4c 8d 0c ff          	lea    (%rdi,%rdi,8),%r9
  671cbb:	49 c1 e1 04          	shl    $0x4,%r9
  671cbf:	4d 03 4e 50          	add    0x50(%r14),%r9
  671cc3:	4c 8d 14 bf          	lea    (%rdi,%rdi,4),%r10
  671cc7:	49 c1 e2 04          	shl    $0x4,%r10
  671ccb:	4d 03 96 e0 00 00 00 	add    0xe0(%r14),%r10
  671cd2:	4c 89 74 24 20       	mov    %r14,0x20(%rsp)
  671cd7:	4c 89 4c 24 28       	mov    %r9,0x28(%rsp)
  671cdc:	4c 89 54 24 30       	mov    %r10,0x30(%rsp)
  671ce1:	4c 89 44 24 38       	mov    %r8,0x38(%rsp)
  671ce6:	89 44 24 40          	mov    %eax,0x40(%rsp)
  671cea:	89 74 24 44          	mov    %esi,0x44(%rsp)
  671cee:	89 7c 24 48          	mov    %edi,0x48(%rsp)
  671cf2:	8b 41 08             	mov    0x8(%rcx),%eax
  671cf5:	4c 8d a4 24 b8 00 00 	lea    0xb8(%rsp),%r12
  671cfc:	00 
  671cfd:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
  671d02:	4c 89 e7             	mov    %r12,%rdi
  671d05:	49 89 d5             	mov    %rdx,%r13
  671d08:	89 c2                	mov    %eax,%edx
  671d0a:	e8 f1 e0 00 00       	call   67fe00 <<parley::layout::run::Run<()>>::cluster_containing_char>
  671d0f:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  671d15:	4c 89 ea             	mov    %r13,%rdx
  671d18:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  671d1f:	00 
  671d20:	48 85 c0             	test   %rax,%rax
  671d23:	4c 0f 44 e0          	cmove  %rax,%r12
  671d27:	e9 a8 fc ff ff       	jmp    6719d4 <parley::editing::geometry::cached_pair::<()>+0xf4>
  671d2c:	48 8d 15 95 e8 10 00 	lea    0x10e895(%rip),%rdx        # 7805c8 <anon.bf1b5ed00d96edcfb74556a573b7af11.42.llvm.12998622219056141688>
  671d33:	ff 15 0f 92 11 00    	call   *0x11920f(%rip)        # 78af48 <_DYNAMIC+0x360>
