
/tmp/gpui-monotonic-control-bin/stream-boundary:     file format elf64-x86-64


Disassembly of section .text:

000000000066f850 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>>:
  66f850:	55                   	push   %rbp
  66f851:	41 57                	push   %r15
  66f853:	41 56                	push   %r14
  66f855:	41 55                	push   %r13
  66f857:	41 54                	push   %r12
  66f859:	53                   	push   %rbx
  66f85a:	48 81 ec 08 08 00 00 	sub    $0x808,%rsp
  66f861:	48 89 f5             	mov    %rsi,%rbp
  66f864:	49 89 fd             	mov    %rdi,%r13
  66f867:	48 8b 87 50 01 00 00 	mov    0x150(%rdi),%rax
  66f86e:	48 89 84 24 f0 00 00 	mov    %rax,0xf0(%rsp)
  66f875:	00 
  66f876:	48 c1 e8 20          	shr    $0x20,%rax
  66f87a:	74 12                	je     66f88e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x3e>
  66f87c:	4c 89 ef             	mov    %r13,%rdi
  66f87f:	48 89 ee             	mov    %rbp,%rsi
  66f882:	e8 a9 28 00 00       	call   672130 <parley::editing::geometry::visit_indexed::<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>>
  66f887:	89 c3                	mov    %eax,%ebx
  66f889:	e9 b5 19 00 00       	jmp    671243 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19f3>
  66f88e:	f3 0f 11 44 24 1c    	movss  %xmm0,0x1c(%rsp)
  66f894:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
  66f899:	bb fe ff ff ff       	mov    $0xfffffffe,%ebx
  66f89e:	41 83 7d 74 00       	cmpl   $0x0,0x74(%r13)
  66f8a3:	0f 85 7e 19 00 00    	jne    671227 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19d7>
  66f8a9:	49 8b 95 18 01 00 00 	mov    0x118(%r13),%rdx
  66f8b0:	48 89 d0             	mov    %rdx,%rax
  66f8b3:	48 c1 e8 20          	shr    $0x20,%rax
  66f8b7:	0f 85 6a 19 00 00    	jne    671227 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19d7>
  66f8bd:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  66f8c2:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
  66f8c9:	00 
  66f8ca:	48 c7 84 24 00 01 00 	movq   $0x0,0x100(%rsp)
  66f8d1:	00 00 00 00 00 
  66f8d6:	48 c7 84 24 08 01 00 	movq   $0x4,0x108(%rsp)
  66f8dd:	00 04 00 00 00 
  66f8e2:	48 c7 84 24 10 01 00 	movq   $0x0,0x110(%rsp)
  66f8e9:	00 00 00 00 00 
  66f8ee:	49 8b 8d 10 01 00 00 	mov    0x110(%r13),%rcx
  66f8f5:	48 6b c2 70          	imul   $0x70,%rdx,%rax
  66f8f9:	48 89 4c 24 68       	mov    %rcx,0x68(%rsp)
  66f8fe:	48 01 c8             	add    %rcx,%rax
  66f901:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
  66f908:	00 
  66f909:	48 85 d2             	test   %rdx,%rdx
  66f90c:	48 89 6c 24 20       	mov    %rbp,0x20(%rsp)
  66f911:	4c 89 6c 24 28       	mov    %r13,0x28(%rsp)
  66f916:	48 89 94 24 b8 00 00 	mov    %rdx,0xb8(%rsp)
  66f91d:	00 
  66f91e:	0f 84 7b 03 00 00    	je     66fc9f <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x44f>
  66f924:	49 8b 85 30 01 00 00 	mov    0x130(%r13),%rax
  66f92b:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
  66f932:	00 
  66f933:	49 8b 85 28 01 00 00 	mov    0x128(%r13),%rax
  66f93a:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
  66f93f:	49 8b 45 50          	mov    0x50(%r13),%rax
  66f943:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
  66f94a:	00 
  66f94b:	49 8b 45 58          	mov    0x58(%r13),%rax
  66f94f:	49 8b 8d e8 00 00 00 	mov    0xe8(%r13),%rcx
  66f956:	48 39 c8             	cmp    %rcx,%rax
  66f959:	48 0f 42 c8          	cmovb  %rax,%rcx
  66f95d:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  66f962:	49 8b 85 e0 00 00 00 	mov    0xe0(%r13),%rax
  66f969:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
  66f970:	00 
  66f971:	48 83 bc 24 f0 00 00 	cmpq   $0x0,0xf0(%rsp)
  66f978:	00 00 
  66f97a:	48 8b 5c 24 50       	mov    0x50(%rsp),%rbx
  66f97f:	0f 84 5e 03 00 00    	je     66fce3 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x493>
  66f985:	48 c7 44 24 48 00 00 	movq   $0x0,0x48(%rsp)
  66f98c:	00 00 
  66f98e:	4c 8d bc 24 b0 03 00 	lea    0x3b0(%rsp),%r15
  66f995:	00 
  66f996:	4c 8d a4 24 f8 00 00 	lea    0xf8(%rsp),%r12
  66f99d:	00 
  66f99e:	4c 8d 8c 24 00 01 00 	lea    0x100(%rsp),%r9
  66f9a5:	00 
  66f9a6:	45 31 f6             	xor    %r14d,%r14d
  66f9a9:	48 c7 44 24 38 00 00 	movq   $0x0,0x38(%rsp)
  66f9b0:	00 00 
  66f9b2:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  66f9b7:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
  66f9be:	00 00 
  66f9c0:	eb 34                	jmp    66f9f6 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a6>
  66f9c2:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
  66f9c7:	48 89 d0             	mov    %rdx,%rax
  66f9ca:	8b 8c 24 c0 00 00 00 	mov    0xc0(%rsp),%ecx
  66f9d1:	48 89 4c 24 40       	mov    %rcx,0x40(%rsp)
  66f9d6:	48 3b 94 24 20 01 00 	cmp    0x120(%rsp),%rdx
  66f9dd:	00 
  66f9de:	4c 8b 6c 24 28       	mov    0x28(%rsp),%r13
  66f9e3:	4c 8b 74 24 60       	mov    0x60(%rsp),%r14
  66f9e8:	4c 8d 8c 24 00 01 00 	lea    0x100(%rsp),%r9
  66f9ef:	00 
  66f9f0:	0f 84 ac 02 00 00    	je     66fca2 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x452>
  66f9f6:	48 8b 50 10          	mov    0x10(%rax),%rdx
  66f9fa:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  66fa01:	00 
  66fa02:	48 8b 48 18          	mov    0x18(%rax),%rcx
  66fa06:	4c 89 ff             	mov    %r15,%rdi
  66fa09:	4c 89 ee             	mov    %r13,%rsi
  66fa0c:	4d 89 e0             	mov    %r12,%r8
  66fa0f:	e8 2c 23 00 00       	call   671d40 <parley::editing::geometry::source_runs::<()>>
  66fa14:	4c 8b ac 24 b8 03 00 	mov    0x3b8(%rsp),%r13
  66fa1b:	00 
  66fa1c:	4d 85 ed             	test   %r13,%r13
  66fa1f:	0f 84 44 17 00 00    	je     671169 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1919>
  66fa25:	4c 89 74 24 60       	mov    %r14,0x60(%rsp)
  66fa2a:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  66fa31:	00 
  66fa32:	48 83 c0 70          	add    $0x70,%rax
  66fa36:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  66fa3b:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  66fa40:	ff c0                	inc    %eax
  66fa42:	89 84 24 c0 00 00 00 	mov    %eax,0xc0(%rsp)
  66fa49:	48 8b 84 24 c0 03 00 	mov    0x3c0(%rsp),%rax
  66fa50:	00 
  66fa51:	4c 8d 34 c5 00 00 00 	lea    0x0(,%rax,8),%r14
  66fa58:	00 
  66fa59:	4d 01 ee             	add    %r13,%r14
  66fa5c:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
  66fa61:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  66fa68:	0f 1f 84 00 00 00 00 
  66fa6f:	00 
  66fa70:	4d 39 f5             	cmp    %r14,%r13
  66fa73:	0f 84 49 ff ff ff    	je     66f9c2 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x172>
  66fa79:	41 8b 45 00          	mov    0x0(%r13),%eax
  66fa7d:	49 83 c5 08          	add    $0x8,%r13
  66fa81:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
  66fa86:	48 39 c8             	cmp    %rcx,%rax
  66fa89:	74 e5                	je     66fa70 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x220>
  66fa8b:	48 8b b4 24 a0 00 00 	mov    0xa0(%rsp),%rsi
  66fa92:	00 
  66fa93:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
  66fa97:	48 01 c1             	add    %rax,%rcx
  66fa9a:	bb fe ff ff ff       	mov    $0xfffffffe,%ebx
  66fa9f:	40 b7 01             	mov    $0x1,%dil
  66faa2:	48 3b 4e 18          	cmp    0x18(%rsi),%rcx
  66faa6:	0f 83 4c 17 00 00    	jae    6711f8 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19a8>
  66faac:	48 3b 8c 24 98 00 00 	cmp    0x98(%rsp),%rcx
  66fab3:	00 
  66fab4:	0f 83 3e 17 00 00    	jae    6711f8 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19a8>
  66faba:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
  66fabe:	80 7c ca 21 00       	cmpb   $0x0,0x21(%rdx,%rcx,8)
  66fac3:	0f 85 2f 17 00 00    	jne    6711f8 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19a8>
  66fac9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
  66facd:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
  66fad1:	48 3b 4c 24 10       	cmp    0x10(%rsp),%rcx
  66fad6:	0f 83 1c 17 00 00    	jae    6711f8 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19a8>
  66fadc:	4c 8d 24 c9          	lea    (%rcx,%rcx,8),%r12
  66fae0:	49 c1 e4 04          	shl    $0x4,%r12
  66fae4:	4c 03 a4 24 d0 00 00 	add    0xd0(%rsp),%r12
  66faeb:	00 
  66faec:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
  66faf0:	48 c1 e6 04          	shl    $0x4,%rsi
  66faf4:	48 03 b4 24 c8 00 00 	add    0xc8(%rsp),%rsi
  66fafb:	00 
  66fafc:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
  66fb01:	48 89 bc 24 b0 03 00 	mov    %rdi,0x3b0(%rsp)
  66fb08:	00 
  66fb09:	4c 89 a4 24 b8 03 00 	mov    %r12,0x3b8(%rsp)
  66fb10:	00 
  66fb11:	48 89 b4 24 c0 03 00 	mov    %rsi,0x3c0(%rsp)
  66fb18:	00 
  66fb19:	48 89 94 24 c8 03 00 	mov    %rdx,0x3c8(%rsp)
  66fb20:	00 
  66fb21:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
  66fb26:	89 94 24 d0 03 00 00 	mov    %edx,0x3d0(%rsp)
  66fb2d:	89 84 24 d4 03 00 00 	mov    %eax,0x3d4(%rsp)
  66fb34:	89 8c 24 d8 03 00 00 	mov    %ecx,0x3d8(%rsp)
  66fb3b:	48 8d 9c 24 f8 06 00 	lea    0x6f8(%rsp),%rbx
  66fb42:	00 
  66fb43:	48 89 df             	mov    %rbx,%rdi
  66fb46:	4c 89 fe             	mov    %r15,%rsi
  66fb49:	31 d2                	xor    %edx,%edx
  66fb4b:	e8 c0 0b 01 00       	call   680710 <<parley::layout::run::Clusters<()>>::new>
  66fb50:	ba 10 01 00 00       	mov    $0x110,%edx
  66fb55:	4c 89 ff             	mov    %r15,%rdi
  66fb58:	48 89 de             	mov    %rbx,%rsi
  66fb5b:	ff 15 57 b3 11 00    	call   *0x11b357(%rip)        # 78aeb8 <memcpy@GLIBC_2.14>
  66fb61:	45 31 ff             	xor    %r15d,%r15d
  66fb64:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  66fb6b:	00 00 00 00 00 
  66fb70:	48 8b 5c 24 50       	mov    0x50(%rsp),%rbx
  66fb75:	48 8d bc 24 80 02 00 	lea    0x280(%rsp),%rdi
  66fb7c:	00 
  66fb7d:	48 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%rsi
  66fb84:	00 
  66fb85:	e8 f6 33 01 00       	call   682f80 <<parley::layout::run::Clusters<()> as core::iter::traits::iterator::Iterator>::next>
  66fb8a:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  66fb8f:	4a 8d 2c 38          	lea    (%rax,%r15,1),%rbp
  66fb93:	48 8b 84 24 80 02 00 	mov    0x280(%rsp),%rax
  66fb9a:	00 
  66fb9b:	48 85 c0             	test   %rax,%rax
  66fb9e:	0f 84 b9 00 00 00    	je     66fc5d <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x40d>
  66fba4:	8b bc 24 a8 02 00 00 	mov    0x2a8(%rsp),%edi
  66fbab:	48 8b 70 58          	mov    0x58(%rax),%rsi
  66fbaf:	48 39 fe             	cmp    %rdi,%rsi
  66fbb2:	0f 86 f7 1a 00 00    	jbe    6716af <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1e5f>
  66fbb8:	8b b4 24 00 03 00 00 	mov    0x300(%rsp),%esi
  66fbbf:	8b 94 24 04 03 00 00 	mov    0x304(%rsp),%edx
  66fbc6:	48 8b 48 50          	mov    0x50(%rax),%rcx
  66fbca:	48 8d 3c ff          	lea    (%rdi,%rdi,8),%rdi
  66fbce:	48 c1 e7 04          	shl    $0x4,%rdi
  66fbd2:	0f 10 40 68          	movups 0x68(%rax),%xmm0
  66fbd6:	0f 10 88 80 00 00 00 	movups 0x80(%rax),%xmm1
  66fbdd:	0f 10 90 98 00 00 00 	movups 0x98(%rax),%xmm2
  66fbe4:	0f 11 84 24 e8 05 00 	movups %xmm0,0x5e8(%rsp)
  66fbeb:	00 
  66fbec:	0f 11 8c 24 f8 05 00 	movups %xmm1,0x5f8(%rsp)
  66fbf3:	00 
  66fbf4:	0f 11 94 24 08 06 00 	movups %xmm2,0x608(%rsp)
  66fbfb:	00 
  66fbfc:	48 8b 44 39 50       	mov    0x50(%rcx,%rdi,1),%rax
  66fc01:	48 89 84 24 18 06 00 	mov    %rax,0x618(%rsp)
  66fc08:	00 
  66fc09:	48 8d bc 24 e8 05 00 	lea    0x5e8(%rsp),%rdi
  66fc10:	00 
  66fc11:	ff 15 a9 b5 11 00    	call   *0x11b5a9(%rip)        # 78b1c0 <_DYNAMIC+0x5d8>
  66fc17:	bb fe ff ff ff       	mov    $0xfffffffe,%ebx
  66fc1c:	40 b7 01             	mov    $0x1,%dil
  66fc1f:	48 39 d0             	cmp    %rdx,%rax
  66fc22:	0f 87 cb 15 00 00    	ja     6711f3 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19a3>
  66fc28:	48 3b 94 24 f0 00 00 	cmp    0xf0(%rsp),%rdx
  66fc2f:	00 
  66fc30:	0f 87 bd 15 00 00    	ja     6711f3 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19a3>
  66fc36:	48 39 d0             	cmp    %rdx,%rax
  66fc39:	73 10                	jae    66fc4b <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x3fb>
  66fc3b:	48 3b 44 24 48       	cmp    0x48(%rsp),%rax
  66fc40:	48 89 54 24 48       	mov    %rdx,0x48(%rsp)
  66fc45:	0f 82 7a 15 00 00    	jb     6711c5 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1975>
  66fc4b:	48 c1 ed 20          	shr    $0x20,%rbp
  66fc4f:	0f 85 9e 15 00 00    	jne    6711f3 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19a3>
  66fc55:	49 ff c7             	inc    %r15
  66fc58:	e9 13 ff ff ff       	jmp    66fb70 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x320>
  66fc5d:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  66fc62:	49 39 c7             	cmp    %rax,%r15
  66fc65:	4c 0f 46 f8          	cmovbe %rax,%r15
  66fc69:	41 f6 84 24 8c 00 00 	testb  $0x1,0x8c(%r12)
  66fc70:	00 01 
  66fc72:	49 0f 45 c7          	cmovne %r15,%rax
  66fc76:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  66fc7b:	48 89 6c 24 38       	mov    %rbp,0x38(%rsp)
  66fc80:	48 8b 6c 24 20       	mov    0x20(%rsp),%rbp
  66fc85:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
  66fc8a:	4c 8d bc 24 b0 03 00 	lea    0x3b0(%rsp),%r15
  66fc91:	00 
  66fc92:	4c 8d a4 24 f8 00 00 	lea    0xf8(%rsp),%r12
  66fc99:	00 
  66fc9a:	e9 d1 fd ff ff       	jmp    66fa70 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x220>
  66fc9f:	45 31 f6             	xor    %r14d,%r14d
  66fca2:	4a 8d 1c b5 00 00 00 	lea    0x0(,%r14,4),%rbx
  66fca9:	00 
  66fcaa:	4c 89 f0             	mov    %r14,%rax
  66fcad:	48 c1 e8 3e          	shr    $0x3e,%rax
  66fcb1:	0f 95 c0             	setne  %al
  66fcb4:	48 b9 fc ff ff ff ff 	movabs $0x7ffffffffffffffc,%rcx
  66fcbb:	ff ff 7f 
  66fcbe:	48 39 cb             	cmp    %rcx,%rbx
  66fcc1:	0f 97 c1             	seta   %cl
  66fcc4:	08 c1                	or     %al,%cl
  66fcc6:	0f 84 40 02 00 00    	je     66ff0c <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x6bc>
  66fccc:	45 31 f6             	xor    %r14d,%r14d
  66fccf:	41 b7 01             	mov    $0x1,%r15b
  66fcd2:	4c 89 f7             	mov    %r14,%rdi
  66fcd5:	48 89 de             	mov    %rbx,%rsi
  66fcd8:	ff 15 5a b2 11 00    	call   *0x11b25a(%rip)        # 78af38 <_DYNAMIC+0x350>
  66fcde:	e9 b7 1a 00 00       	jmp    67179a <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f4a>
  66fce3:	45 31 f6             	xor    %r14d,%r14d
  66fce6:	41 bc ff ff ff ff    	mov    $0xffffffff,%r12d
  66fcec:	48 c7 44 24 70 00 00 	movq   $0x0,0x70(%rsp)
  66fcf3:	00 00 
  66fcf5:	4c 8b 7c 24 68       	mov    0x68(%rsp),%r15
  66fcfa:	48 c7 44 24 38 00 00 	movq   $0x0,0x38(%rsp)
  66fd01:	00 00 
  66fd03:	eb 27                	jmp    66fd2c <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x4dc>
  66fd05:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
  66fd0a:	49 89 cf             	mov    %rcx,%r15
  66fd0d:	8b 84 24 a0 00 00 00 	mov    0xa0(%rsp),%eax
  66fd14:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  66fd19:	48 3b 8c 24 20 01 00 	cmp    0x120(%rsp),%rcx
  66fd20:	00 
  66fd21:	4c 8b 6c 24 28       	mov    0x28(%rsp),%r13
  66fd26:	0f 84 76 ff ff ff    	je     66fca2 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x452>
  66fd2c:	49 8b 57 10          	mov    0x10(%r15),%rdx
  66fd30:	49 8b 4f 18          	mov    0x18(%r15),%rcx
  66fd34:	48 8d bc 24 b0 03 00 	lea    0x3b0(%rsp),%rdi
  66fd3b:	00 
  66fd3c:	4c 89 ee             	mov    %r13,%rsi
  66fd3f:	4c 8d 84 24 f8 00 00 	lea    0xf8(%rsp),%r8
  66fd46:	00 
  66fd47:	4c 8d 8c 24 00 01 00 	lea    0x100(%rsp),%r9
  66fd4e:	00 
  66fd4f:	e8 ec 1f 00 00       	call   671d40 <parley::editing::geometry::source_runs::<()>>
  66fd54:	4c 8b ac 24 b8 03 00 	mov    0x3b8(%rsp),%r13
  66fd5b:	00 
  66fd5c:	4d 85 ed             	test   %r13,%r13
  66fd5f:	0f 84 04 14 00 00    	je     671169 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1919>
  66fd65:	4c 89 7c 24 40       	mov    %r15,0x40(%rsp)
  66fd6a:	49 8d 47 70          	lea    0x70(%r15),%rax
  66fd6e:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  66fd73:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  66fd78:	ff c0                	inc    %eax
  66fd7a:	89 84 24 a0 00 00 00 	mov    %eax,0xa0(%rsp)
  66fd81:	48 8b 84 24 c0 03 00 	mov    0x3c0(%rsp),%rax
  66fd88:	00 
  66fd89:	4c 8d 3c c5 00 00 00 	lea    0x0(,%rax,8),%r15
  66fd90:	00 
  66fd91:	4d 01 ef             	add    %r13,%r15
  66fd94:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  66fd9b:	00 00 00 00 00 
  66fda0:	4d 39 fd             	cmp    %r15,%r13
  66fda3:	0f 84 5c ff ff ff    	je     66fd05 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x4b5>
  66fda9:	41 8b 45 00          	mov    0x0(%r13),%eax
  66fdad:	49 83 c5 08          	add    $0x8,%r13
  66fdb1:	4c 39 e0             	cmp    %r12,%rax
  66fdb4:	74 ea                	je     66fda0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x550>
  66fdb6:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
  66fdbb:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
  66fdbf:	48 01 c1             	add    %rax,%rcx
  66fdc2:	bb fe ff ff ff       	mov    $0xfffffffe,%ebx
  66fdc7:	40 b7 01             	mov    $0x1,%dil
  66fdca:	48 3b 4a 18          	cmp    0x18(%rdx),%rcx
  66fdce:	0f 83 24 14 00 00    	jae    6711f8 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19a8>
  66fdd4:	48 3b 8c 24 98 00 00 	cmp    0x98(%rsp),%rcx
  66fddb:	00 
  66fddc:	0f 83 16 14 00 00    	jae    6711f8 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19a8>
  66fde2:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
  66fde6:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
  66fdeb:	80 7c ca 21 00       	cmpb   $0x0,0x21(%rdx,%rcx,8)
  66fdf0:	0f 85 02 14 00 00    	jne    6711f8 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19a8>
  66fdf6:	4c 89 74 24 60       	mov    %r14,0x60(%rsp)
  66fdfb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
  66fdff:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
  66fe03:	48 3b 4c 24 10       	cmp    0x10(%rsp),%rcx
  66fe08:	0f 83 ea 13 00 00    	jae    6711f8 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19a8>
  66fe0e:	48 8d 1c c9          	lea    (%rcx,%rcx,8),%rbx
  66fe12:	48 c1 e3 04          	shl    $0x4,%rbx
  66fe16:	48 03 9c 24 d0 00 00 	add    0xd0(%rsp),%rbx
  66fe1d:	00 
  66fe1e:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
  66fe22:	48 c1 e6 04          	shl    $0x4,%rsi
  66fe26:	48 03 b4 24 c8 00 00 	add    0xc8(%rsp),%rsi
  66fe2d:	00 
  66fe2e:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
  66fe33:	48 89 bc 24 b0 03 00 	mov    %rdi,0x3b0(%rsp)
  66fe3a:	00 
  66fe3b:	48 89 9c 24 b8 03 00 	mov    %rbx,0x3b8(%rsp)
  66fe42:	00 
  66fe43:	48 89 b4 24 c0 03 00 	mov    %rsi,0x3c0(%rsp)
  66fe4a:	00 
  66fe4b:	48 89 94 24 c8 03 00 	mov    %rdx,0x3c8(%rsp)
  66fe52:	00 
  66fe53:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
  66fe58:	89 94 24 d0 03 00 00 	mov    %edx,0x3d0(%rsp)
  66fe5f:	89 84 24 d4 03 00 00 	mov    %eax,0x3d4(%rsp)
  66fe66:	89 8c 24 d8 03 00 00 	mov    %ecx,0x3d8(%rsp)
  66fe6d:	48 8d ac 24 f8 06 00 	lea    0x6f8(%rsp),%rbp
  66fe74:	00 
  66fe75:	48 89 ef             	mov    %rbp,%rdi
  66fe78:	4c 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%r14
  66fe7f:	00 
  66fe80:	4c 89 f6             	mov    %r14,%rsi
  66fe83:	31 d2                	xor    %edx,%edx
  66fe85:	e8 86 08 01 00       	call   680710 <<parley::layout::run::Clusters<()>>::new>
  66fe8a:	ba 10 01 00 00       	mov    $0x110,%edx
  66fe8f:	4c 89 f7             	mov    %r14,%rdi
  66fe92:	48 89 ee             	mov    %rbp,%rsi
  66fe95:	ff 15 1d b0 11 00    	call   *0x11b01d(%rip)        # 78aeb8 <memcpy@GLIBC_2.14>
  66fe9b:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  66fea0:	4c 8d 70 01          	lea    0x1(%rax),%r14
  66fea4:	31 ed                	xor    %ebp,%ebp
  66fea6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  66fead:	00 00 00 
  66feb0:	48 8d bc 24 80 02 00 	lea    0x280(%rsp),%rdi
  66feb7:	00 
  66feb8:	48 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%rsi
  66febf:	00 
  66fec0:	e8 bb 30 01 00       	call   682f80 <<parley::layout::run::Clusters<()> as core::iter::traits::iterator::Iterator>::next>
  66fec5:	48 83 bc 24 80 02 00 	cmpq   $0x0,0x280(%rsp)
  66fecc:	00 00 
  66fece:	74 0e                	je     66fede <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x68e>
  66fed0:	49 39 ee             	cmp    %rbp,%r14
  66fed3:	0f 84 12 13 00 00    	je     6711eb <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x199b>
  66fed9:	48 ff cd             	dec    %rbp
  66fedc:	eb d2                	jmp    66feb0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x660>
  66fede:	48 29 6c 24 70       	sub    %rbp,0x70(%rsp)
  66fee3:	48 f7 dd             	neg    %rbp
  66fee6:	4c 8b 74 24 60       	mov    0x60(%rsp),%r14
  66feeb:	4c 39 f5             	cmp    %r14,%rbp
  66feee:	49 0f 46 ee          	cmovbe %r14,%rbp
  66fef2:	f6 83 8c 00 00 00 01 	testb  $0x1,0x8c(%rbx)
  66fef9:	4c 0f 45 f5          	cmovne %rbp,%r14
  66fefd:	48 8b 6c 24 20       	mov    0x20(%rsp),%rbp
  66ff02:	48 8b 5c 24 50       	mov    0x50(%rsp),%rbx
  66ff07:	e9 94 fe ff ff       	jmp    66fda0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x550>
  66ff0c:	48 85 db             	test   %rbx,%rbx
  66ff0f:	74 2f                	je     66ff40 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x6f0>
  66ff11:	4d 89 f4             	mov    %r14,%r12
  66ff14:	ff 15 96 af 11 00    	call   *0x11af96(%rip)        # 78aeb0 <_DYNAMIC+0x2c8>
  66ff1a:	41 be 04 00 00 00    	mov    $0x4,%r14d
  66ff20:	be 04 00 00 00       	mov    $0x4,%esi
  66ff25:	48 89 df             	mov    %rbx,%rdi
  66ff28:	ff 15 ea ae 11 00    	call   *0x11aeea(%rip)        # 78ae18 <_DYNAMIC+0x230>
  66ff2e:	48 85 c0             	test   %rax,%rax
  66ff31:	4c 8b bc 24 b8 00 00 	mov    0xb8(%rsp),%r15
  66ff38:	00 
  66ff39:	75 15                	jne    66ff50 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x700>
  66ff3b:	e9 8f fd ff ff       	jmp    66fccf <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x47f>
  66ff40:	b8 04 00 00 00       	mov    $0x4,%eax
  66ff45:	45 31 e4             	xor    %r12d,%r12d
  66ff48:	4c 8b bc 24 b8 00 00 	mov    0xb8(%rsp),%r15
  66ff4f:	00 
  66ff50:	4c 89 a4 24 d8 00 00 	mov    %r12,0xd8(%rsp)
  66ff57:	00 
  66ff58:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
  66ff5f:	00 
  66ff60:	48 c7 84 24 e8 00 00 	movq   $0x0,0xe8(%rsp)
  66ff67:	00 00 00 00 00 
  66ff6c:	48 8d bc 24 e8 01 00 	lea    0x1e8(%rsp),%rdi
  66ff73:	00 
  66ff74:	ba 98 00 00 00       	mov    $0x98,%edx
  66ff79:	48 89 ee             	mov    %rbp,%rsi
  66ff7c:	ff 15 36 af 11 00    	call   *0x11af36(%rip)        # 78aeb8 <memcpy@GLIBC_2.14>
  66ff82:	48 c7 84 24 d8 01 00 	movq   $0x2,0x1d8(%rsp)
  66ff89:	00 02 00 00 00 
  66ff8e:	c7 84 24 3c 01 00 00 	movl   $0x0,0x13c(%rsp)
  66ff95:	00 00 00 00 
  66ff99:	4d 85 ff             	test   %r15,%r15
  66ff9c:	0f 84 40 11 00 00    	je     6710e2 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1892>
  66ffa2:	49 8b 85 30 01 00 00 	mov    0x130(%r13),%rax
  66ffa9:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  66ffae:	49 8b 85 28 01 00 00 	mov    0x128(%r13),%rax
  66ffb5:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
  66ffbc:	00 
  66ffbd:	49 8b 45 58          	mov    0x58(%r13),%rax
  66ffc1:	49 8b 8d e8 00 00 00 	mov    0xe8(%r13),%rcx
  66ffc8:	48 39 c8             	cmp    %rcx,%rax
  66ffcb:	48 89 8c 24 a0 01 00 	mov    %rcx,0x1a0(%rsp)
  66ffd2:	00 
  66ffd3:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
  66ffda:	00 
  66ffdb:	48 0f 42 c8          	cmovb  %rax,%rcx
  66ffdf:	48 89 8c 24 90 03 00 	mov    %rcx,0x390(%rsp)
  66ffe6:	00 
  66ffe7:	49 8b 85 e0 00 00 00 	mov    0xe0(%r13),%rax
  66ffee:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
  66fff5:	00 
  66fff6:	49 8b 45 50          	mov    0x50(%r13),%rax
  66fffa:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
  670001:	00 
  670002:	49 8b 45 38          	mov    0x38(%r13),%rax
  670006:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
  67000d:	00 
  67000e:	49 8b 45 40          	mov    0x40(%r13),%rax
  670012:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  670019:	00 
  67001a:	48 8d 05 87 04 11 00 	lea    0x110487(%rip),%rax        # 7804a8 <anon.9a0de72a7eba2b0cb10eb2c5cf6d915d.1.llvm.15750432251718107962+0x2c0>
  670021:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
  670028:	00 
  670029:	48 8d 05 38 05 11 00 	lea    0x110538(%rip),%rax        # 780568 <anon.bf1b5ed00d96edcfb74556a573b7af11.35.llvm.12998622219056141688>
  670030:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  670035:	31 db                	xor    %ebx,%ebx
  670037:	48 c7 84 24 a8 00 00 	movq   $0x0,0xa8(%rsp)
  67003e:	00 00 00 00 00 
  670043:	48 c7 44 24 70 00 00 	movq   $0x0,0x70(%rsp)
  67004a:	00 00 
  67004c:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  670051:	eb 25                	jmp    670078 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x828>
  670053:	48 8b 94 24 a0 03 00 	mov    0x3a0(%rsp),%rdx
  67005a:	00 
  67005b:	48 89 d0             	mov    %rdx,%rax
  67005e:	8b 8c 24 38 01 00 00 	mov    0x138(%rsp),%ecx
  670065:	48 89 4c 24 70       	mov    %rcx,0x70(%rsp)
  67006a:	48 3b 94 24 20 01 00 	cmp    0x120(%rsp),%rdx
  670071:	00 
  670072:	0f 84 77 12 00 00    	je     6712ef <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a9f>
  670078:	48 8b 50 10          	mov    0x10(%rax),%rdx
  67007c:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
  670081:	48 8b 48 18          	mov    0x18(%rax),%rcx
  670085:	48 8d bc 24 b0 03 00 	lea    0x3b0(%rsp),%rdi
  67008c:	00 
  67008d:	4c 89 ee             	mov    %r13,%rsi
  670090:	4c 8d 84 24 f8 00 00 	lea    0xf8(%rsp),%r8
  670097:	00 
  670098:	4c 8d 8c 24 00 01 00 	lea    0x100(%rsp),%r9
  67009f:	00 
  6700a0:	e8 9b 1c 00 00       	call   671d40 <parley::editing::geometry::source_runs::<()>>
  6700a5:	48 8b ac 24 b8 03 00 	mov    0x3b8(%rsp),%rbp
  6700ac:	00 
  6700ad:	48 85 ed             	test   %rbp,%rbp
  6700b0:	0f 84 ca 15 00 00    	je     671680 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1e30>
  6700b6:	48 89 9c 24 88 00 00 	mov    %rbx,0x88(%rsp)
  6700bd:	00 
  6700be:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  6700c3:	48 8b 78 10          	mov    0x10(%rax),%rdi
  6700c7:	48 8b 70 18          	mov    0x18(%rax),%rsi
  6700cb:	48 39 fe             	cmp    %rdi,%rsi
  6700ce:	0f 82 95 15 00 00    	jb     671669 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1e19>
  6700d4:	48 3b 74 24 10       	cmp    0x10(%rsp),%rsi
  6700d9:	0f 87 8a 15 00 00    	ja     671669 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1e19>
  6700df:	48 8b 9c 24 c0 03 00 	mov    0x3c0(%rsp),%rbx
  6700e6:	00 
  6700e7:	48 39 f7             	cmp    %rsi,%rdi
  6700ea:	0f 85 6b 0e 00 00    	jne    670f5b <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x170b>
  6700f0:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  6700f5:	48 83 c0 70          	add    $0x70,%rax
  6700f9:	48 89 84 24 a0 03 00 	mov    %rax,0x3a0(%rsp)
  670100:	00 
  670101:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  670106:	ff c0                	inc    %eax
  670108:	89 84 24 38 01 00 00 	mov    %eax,0x138(%rsp)
  67010f:	4c 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%r10
  670116:	00 
  670117:	49 01 ea             	add    %rbp,%r10
  67011a:	4c 8d b4 24 b8 03 00 	lea    0x3b8(%rsp),%r14
  670121:	00 
  670122:	4c 8d bc 24 b0 02 00 	lea    0x2b0(%rsp),%r15
  670129:	00 
  67012a:	4c 8d a4 24 00 03 00 	lea    0x300(%rsp),%r12
  670131:	00 
  670132:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
  670137:	48 8b 9c 24 88 00 00 	mov    0x88(%rsp),%rbx
  67013e:	00 
  67013f:	90                   	nop
  670140:	4c 39 d5             	cmp    %r10,%rbp
  670143:	0f 84 0a ff ff ff    	je     670053 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x803>
  670149:	8b 45 00             	mov    0x0(%rbp),%eax
  67014c:	48 83 c5 08          	add    $0x8,%rbp
  670150:	48 39 c8             	cmp    %rcx,%rax
  670153:	74 eb                	je     670140 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x8f0>
  670155:	48 8b 54 24 68       	mov    0x68(%rsp),%rdx
  67015a:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
  67015e:	48 01 c1             	add    %rax,%rcx
  670161:	48 3b 4a 18          	cmp    0x18(%rdx),%rcx
  670165:	0f 83 21 16 00 00    	jae    67178c <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f3c>
  67016b:	48 3b 4c 24 10       	cmp    0x10(%rsp),%rcx
  670170:	0f 83 16 16 00 00    	jae    67178c <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f3c>
  670176:	48 8d 14 89          	lea    (%rcx,%rcx,4),%rdx
  67017a:	48 8b b4 24 98 00 00 	mov    0x98(%rsp),%rsi
  670181:	00 
  670182:	48 8b 4c d6 10       	mov    0x10(%rsi,%rdx,8),%rcx
  670187:	80 7c d6 21 01       	cmpb   $0x1,0x21(%rsi,%rdx,8)
  67018c:	0f 84 d8 15 00 00    	je     67176a <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f1a>
  670192:	48 3b 8c 24 90 03 00 	cmp    0x390(%rsp),%rcx
  670199:	00 
  67019a:	0f 83 ec 15 00 00    	jae    67178c <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f3c>
  6701a0:	f3 0f 10 45 fc       	movss  -0x4(%rbp),%xmm0
  6701a5:	f3 0f 11 44 24 38    	movss  %xmm0,0x38(%rsp)
  6701ab:	48 8b b4 24 98 00 00 	mov    0x98(%rsp),%rsi
  6701b2:	00 
  6701b3:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
  6701b7:	48 8d 34 c9          	lea    (%rcx,%rcx,8),%rsi
  6701bb:	48 c1 e6 04          	shl    $0x4,%rsi
  6701bf:	4c 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%r9
  6701c6:	00 
  6701c7:	49 8d 3c 31          	lea    (%r9,%rsi,1),%rdi
  6701cb:	4c 8d 04 89          	lea    (%rcx,%rcx,4),%r8
  6701cf:	49 c1 e0 04          	shl    $0x4,%r8
  6701d3:	4c 03 84 24 d0 00 00 	add    0xd0(%rsp),%r8
  6701da:	00 
  6701db:	4c 89 ac 24 a8 01 00 	mov    %r13,0x1a8(%rsp)
  6701e2:	00 
  6701e3:	48 89 bc 24 b0 01 00 	mov    %rdi,0x1b0(%rsp)
  6701ea:	00 
  6701eb:	4c 89 84 24 b8 01 00 	mov    %r8,0x1b8(%rsp)
  6701f2:	00 
  6701f3:	48 89 94 24 c0 01 00 	mov    %rdx,0x1c0(%rsp)
  6701fa:	00 
  6701fb:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
  670200:	89 94 24 c8 01 00 00 	mov    %edx,0x1c8(%rsp)
  670207:	89 84 24 cc 01 00 00 	mov    %eax,0x1cc(%rsp)
  67020e:	89 8c 24 d0 01 00 00 	mov    %ecx,0x1d0(%rsp)
  670215:	48 c7 84 24 e8 00 00 	movq   $0x0,0xe8(%rsp)
  67021c:	00 00 00 00 00 
  670221:	41 0f b6 84 31 8c 00 	movzbl 0x8c(%r9,%rsi,1),%eax
  670228:	00 00 
  67022a:	88 84 24 a0 00 00 00 	mov    %al,0xa0(%rsp)
  670231:	a8 01                	test   $0x1,%al
  670233:	4c 89 94 24 98 03 00 	mov    %r10,0x398(%rsp)
  67023a:	00 
  67023b:	0f 85 2b 0b 00 00    	jne    670d6c <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x151c>
  670241:	4c 8d ac 24 80 02 00 	lea    0x280(%rsp),%r13
  670248:	00 
  670249:	4c 89 ef             	mov    %r13,%rdi
  67024c:	48 8d b4 24 a8 01 00 	lea    0x1a8(%rsp),%rsi
  670253:	00 
  670254:	31 d2                	xor    %edx,%edx
  670256:	e8 b5 04 01 00       	call   680710 <<parley::layout::run::Clusters<()>>::new>
  67025b:	ba 10 01 00 00       	mov    $0x110,%edx
  670260:	4c 89 f7             	mov    %r14,%rdi
  670263:	4c 89 ee             	mov    %r13,%rsi
  670266:	ff 15 4c ac 11 00    	call   *0x11ac4c(%rip)        # 78aeb8 <memcpy@GLIBC_2.14>
  67026c:	48 c7 84 24 b0 03 00 	movq   $0x0,0x3b0(%rsp)
  670273:	00 00 00 00 00 
  670278:	0f b6 84 24 3c 01 00 	movzbl 0x13c(%rsp),%eax
  67027f:	00 
  670280:	88 44 24 0f          	mov    %al,0xf(%rsp)
  670284:	0f 57 c0             	xorps  %xmm0,%xmm0
  670287:	f3 0f 11 84 24 90 00 	movss  %xmm0,0x90(%rsp)
  67028e:	00 00 
  670290:	48 c7 84 24 b0 00 00 	movq   $0x0,0xb0(%rsp)
  670297:	00 00 00 00 00 
  67029c:	c7 44 24 5c 00 00 00 	movl   $0x0,0x5c(%rsp)
  6702a3:	00 
  6702a4:	4c 89 ef             	mov    %r13,%rdi
  6702a7:	4c 89 f6             	mov    %r14,%rsi
  6702aa:	e8 d1 2c 01 00       	call   682f80 <<parley::layout::run::Clusters<()> as core::iter::traits::iterator::Iterator>::next>
  6702af:	4c 8b b4 24 80 02 00 	mov    0x280(%rsp),%r14
  6702b6:	00 
  6702b7:	4d 85 f6             	test   %r14,%r14
  6702ba:	0f 84 9a 0a 00 00    	je     670d5a <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x150a>
  6702c0:	ba 88 00 00 00       	mov    $0x88,%edx
  6702c5:	4c 8d a4 24 60 05 00 	lea    0x560(%rsp),%r12
  6702cc:	00 
  6702cd:	4c 89 e7             	mov    %r12,%rdi
  6702d0:	48 8d b4 24 88 02 00 	lea    0x288(%rsp),%rsi
  6702d7:	00 
  6702d8:	48 8b 1d d9 ab 11 00 	mov    0x11abd9(%rip),%rbx        # 78aeb8 <memcpy@GLIBC_2.14>
  6702df:	ff d3                	call   *%rbx
  6702e1:	4c 8b bc 24 b0 03 00 	mov    0x3b0(%rsp),%r15
  6702e8:	00 
  6702e9:	49 8d 47 01          	lea    0x1(%r15),%rax
  6702ed:	48 89 84 24 b0 03 00 	mov    %rax,0x3b0(%rsp)
  6702f4:	00 
  6702f5:	4c 89 b4 24 d0 04 00 	mov    %r14,0x4d0(%rsp)
  6702fc:	00 
  6702fd:	ba 88 00 00 00       	mov    $0x88,%edx
  670302:	48 8d bc 24 d8 04 00 	lea    0x4d8(%rsp),%rdi
  670309:	00 
  67030a:	4c 89 e6             	mov    %r12,%rsi
  67030d:	ff d3                	call   *%rbx
  67030f:	44 8b ac 24 f8 04 00 	mov    0x4f8(%rsp),%r13d
  670316:	00 
  670317:	49 8b 46 58          	mov    0x58(%r14),%rax
  67031b:	4c 39 e8             	cmp    %r13,%rax
  67031e:	0f 86 7a 13 00 00    	jbe    67169e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1e4e>
  670324:	49 8b 46 50          	mov    0x50(%r14),%rax
  670328:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
  67032f:	00 
  670330:	4c 01 e9             	add    %r13,%rcx
  670333:	48 c1 e1 04          	shl    $0x4,%rcx
  670337:	41 0f 10 46 68       	movups 0x68(%r14),%xmm0
  67033c:	41 0f 10 8e 80 00 00 	movups 0x80(%r14),%xmm1
  670343:	00 
  670344:	41 0f 10 96 98 00 00 	movups 0x98(%r14),%xmm2
  67034b:	00 
  67034c:	0f 11 84 24 80 02 00 	movups %xmm0,0x280(%rsp)
  670353:	00 
  670354:	0f 11 8c 24 90 02 00 	movups %xmm1,0x290(%rsp)
  67035b:	00 
  67035c:	0f 11 94 24 a0 02 00 	movups %xmm2,0x2a0(%rsp)
  670363:	00 
  670364:	48 8b 44 08 50       	mov    0x50(%rax,%rcx,1),%rax
  670369:	48 89 84 24 b0 02 00 	mov    %rax,0x2b0(%rsp)
  670370:	00 
  670371:	8b 9c 24 50 05 00 00 	mov    0x550(%rsp),%ebx
  670378:	44 8b a4 24 54 05 00 	mov    0x554(%rsp),%r12d
  67037f:	00 
  670380:	48 8d bc 24 80 02 00 	lea    0x280(%rsp),%rdi
  670387:	00 
  670388:	89 de                	mov    %ebx,%esi
  67038a:	44 89 e2             	mov    %r12d,%edx
  67038d:	ff 15 2d ae 11 00    	call   *0x11ae2d(%rip)        # 78b1c0 <_DYNAMIC+0x5d8>
  670393:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  670398:	48 89 54 24 48       	mov    %rdx,0x48(%rsp)
  67039d:	f6 84 24 a0 00 00 00 	testb  $0x1,0xa0(%rsp)
  6703a4:	01 
  6703a5:	75 39                	jne    6703e0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xb90>
  6703a7:	48 83 bc 24 e8 04 00 	cmpq   $0x0,0x4e8(%rsp)
  6703ae:	00 00 
  6703b0:	74 67                	je     670419 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xbc9>
  6703b2:	8b 84 24 f0 04 00 00 	mov    0x4f0(%rsp),%eax
  6703b9:	49 8b 8e 18 01 00 00 	mov    0x118(%r14),%rcx
  6703c0:	48 39 c1             	cmp    %rax,%rcx
  6703c3:	0f 86 6a 13 00 00    	jbe    671733 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ee3>
  6703c9:	49 8b 8e 10 01 00 00 	mov    0x110(%r14),%rcx
  6703d0:	48 6b c0 70          	imul   $0x70,%rax,%rax
  6703d4:	f3 0f 10 44 01 50    	movss  0x50(%rcx,%rax,1),%xmm0
  6703da:	8b 44 01 54          	mov    0x54(%rcx,%rax,1),%eax
  6703de:	eb 41                	jmp    670421 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xbd1>
  6703e0:	48 8b 84 24 e8 00 00 	mov    0xe8(%rsp),%rax
  6703e7:	00 
  6703e8:	49 f7 d7             	not    %r15
  6703eb:	49 01 c7             	add    %rax,%r15
  6703ee:	0f 83 2e 13 00 00    	jae    671722 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ed2>
  6703f4:	48 8b 84 24 e0 00 00 	mov    0xe0(%rsp),%rax
  6703fb:	00 
  6703fc:	f3 42 0f 10 04 b8    	movss  (%rax,%r15,4),%xmm0
  670402:	f3 0f 11 44 24 78    	movss  %xmm0,0x78(%rsp)
  670408:	f3 0f 10 84 24 90 00 	movss  0x90(%rsp),%xmm0
  67040f:	00 00 
  670411:	f3 0f 11 44 24 40    	movss  %xmm0,0x40(%rsp)
  670417:	eb 7a                	jmp    670493 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xc43>
  670419:	0f 57 c0             	xorps  %xmm0,%xmm0
  67041c:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  670421:	48 8b 8c 24 d8 04 00 	mov    0x4d8(%rsp),%rcx
  670428:	00 
  670429:	48 8b 94 24 e0 04 00 	mov    0x4e0(%rsp),%rdx
  670430:	00 
  670431:	f2 0f 10 4a 44       	movsd  0x44(%rdx),%xmm1
  670436:	f2 0f 11 8c 24 80 02 	movsd  %xmm1,0x280(%rsp)
  67043d:	00 00 
  67043f:	f3 0f 11 84 24 88 02 	movss  %xmm0,0x288(%rsp)
  670446:	00 00 
  670448:	89 84 24 8c 02 00 00 	mov    %eax,0x28c(%rsp)
  67044f:	0f b6 89 8c 00 00 00 	movzbl 0x8c(%rcx),%ecx
  670456:	83 e1 01             	and    $0x1,%ecx
  670459:	48 8d bc 24 80 02 00 	lea    0x280(%rsp),%rdi
  670460:	00 
  670461:	48 8d b4 24 00 05 00 	lea    0x500(%rsp),%rsi
  670468:	00 
  670469:	48 8d 94 24 50 05 00 	lea    0x550(%rsp),%rdx
  670470:	00 
  670471:	ff 15 01 ae 11 00    	call   *0x11ae01(%rip)        # 78b278 <_DYNAMIC+0x690>
  670477:	f3 0f 10 4c 24 38    	movss  0x38(%rsp),%xmm1
  67047d:	f3 0f 58 c1          	addss  %xmm1,%xmm0
  670481:	f3 0f 11 4c 24 40    	movss  %xmm1,0x40(%rsp)
  670487:	f3 0f 11 4c 24 78    	movss  %xmm1,0x78(%rsp)
  67048d:	f3 0f 11 44 24 38    	movss  %xmm0,0x38(%rsp)
  670493:	48 83 bc 24 f0 00 00 	cmpq   $0x0,0xf0(%rsp)
  67049a:	00 00 
  67049c:	74 22                	je     6704c0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xc70>
  67049e:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  6704a3:	48 3b 44 24 48       	cmp    0x48(%rsp),%rax
  6704a8:	0f 82 43 02 00 00    	jb     6706f1 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xea1>
  6704ae:	eb 10                	jmp    6704c0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xc70>
  6704b0:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  6704b5:	48 3b 44 24 48       	cmp    0x48(%rsp),%rax
  6704ba:	0f 82 29 02 00 00    	jb     6706e9 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xe99>
  6704c0:	48 8d bc 24 80 02 00 	lea    0x280(%rsp),%rdi
  6704c7:	00 
  6704c8:	48 8d b4 24 b8 03 00 	lea    0x3b8(%rsp),%rsi
  6704cf:	00 
  6704d0:	e8 ab 2a 01 00       	call   682f80 <<parley::layout::run::Clusters<()> as core::iter::traits::iterator::Iterator>::next>
  6704d5:	4c 8b b4 24 80 02 00 	mov    0x280(%rsp),%r14
  6704dc:	00 
  6704dd:	4d 85 f6             	test   %r14,%r14
  6704e0:	0f 84 74 08 00 00    	je     670d5a <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x150a>
  6704e6:	ba 88 00 00 00       	mov    $0x88,%edx
  6704eb:	4c 8d a4 24 60 05 00 	lea    0x560(%rsp),%r12
  6704f2:	00 
  6704f3:	4c 89 e7             	mov    %r12,%rdi
  6704f6:	48 8d b4 24 88 02 00 	lea    0x288(%rsp),%rsi
  6704fd:	00 
  6704fe:	48 8b 1d b3 a9 11 00 	mov    0x11a9b3(%rip),%rbx        # 78aeb8 <memcpy@GLIBC_2.14>
  670505:	ff d3                	call   *%rbx
  670507:	4c 8b bc 24 b0 03 00 	mov    0x3b0(%rsp),%r15
  67050e:	00 
  67050f:	49 8d 47 01          	lea    0x1(%r15),%rax
  670513:	48 89 84 24 b0 03 00 	mov    %rax,0x3b0(%rsp)
  67051a:	00 
  67051b:	4c 89 b4 24 d0 04 00 	mov    %r14,0x4d0(%rsp)
  670522:	00 
  670523:	ba 88 00 00 00       	mov    $0x88,%edx
  670528:	48 8d bc 24 d8 04 00 	lea    0x4d8(%rsp),%rdi
  67052f:	00 
  670530:	4c 89 e6             	mov    %r12,%rsi
  670533:	ff d3                	call   *%rbx
  670535:	44 8b ac 24 f8 04 00 	mov    0x4f8(%rsp),%r13d
  67053c:	00 
  67053d:	49 8b 46 58          	mov    0x58(%r14),%rax
  670541:	4c 39 e8             	cmp    %r13,%rax
  670544:	0f 86 54 11 00 00    	jbe    67169e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1e4e>
  67054a:	49 8b 46 50          	mov    0x50(%r14),%rax
  67054e:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
  670555:	00 
  670556:	4c 01 e9             	add    %r13,%rcx
  670559:	48 c1 e1 04          	shl    $0x4,%rcx
  67055d:	41 0f 10 46 68       	movups 0x68(%r14),%xmm0
  670562:	41 0f 10 8e 80 00 00 	movups 0x80(%r14),%xmm1
  670569:	00 
  67056a:	41 0f 10 96 98 00 00 	movups 0x98(%r14),%xmm2
  670571:	00 
  670572:	0f 11 84 24 80 02 00 	movups %xmm0,0x280(%rsp)
  670579:	00 
  67057a:	0f 11 8c 24 90 02 00 	movups %xmm1,0x290(%rsp)
  670581:	00 
  670582:	0f 11 94 24 a0 02 00 	movups %xmm2,0x2a0(%rsp)
  670589:	00 
  67058a:	48 8b 44 08 50       	mov    0x50(%rax,%rcx,1),%rax
  67058f:	48 89 84 24 b0 02 00 	mov    %rax,0x2b0(%rsp)
  670596:	00 
  670597:	8b 9c 24 50 05 00 00 	mov    0x550(%rsp),%ebx
  67059e:	44 8b a4 24 54 05 00 	mov    0x554(%rsp),%r12d
  6705a5:	00 
  6705a6:	48 8d bc 24 80 02 00 	lea    0x280(%rsp),%rdi
  6705ad:	00 
  6705ae:	89 de                	mov    %ebx,%esi
  6705b0:	44 89 e2             	mov    %r12d,%edx
  6705b3:	ff 15 07 ac 11 00    	call   *0x11ac07(%rip)        # 78b1c0 <_DYNAMIC+0x5d8>
  6705b9:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  6705be:	48 89 54 24 48       	mov    %rdx,0x48(%rsp)
  6705c3:	f6 84 24 a0 00 00 00 	testb  $0x1,0xa0(%rsp)
  6705ca:	01 
  6705cb:	75 43                	jne    670610 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xdc0>
  6705cd:	48 83 bc 24 e8 04 00 	cmpq   $0x0,0x4e8(%rsp)
  6705d4:	00 00 
  6705d6:	0f 84 7f 00 00 00    	je     67065b <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xe0b>
  6705dc:	8b 84 24 f0 04 00 00 	mov    0x4f0(%rsp),%eax
  6705e3:	49 8b 8e 18 01 00 00 	mov    0x118(%r14),%rcx
  6705ea:	48 39 c1             	cmp    %rax,%rcx
  6705ed:	0f 86 40 11 00 00    	jbe    671733 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ee3>
  6705f3:	49 8b 8e 10 01 00 00 	mov    0x110(%r14),%rcx
  6705fa:	48 6b c0 70          	imul   $0x70,%rax,%rax
  6705fe:	f3 0f 10 44 01 50    	movss  0x50(%rcx,%rax,1),%xmm0
  670604:	8b 44 01 54          	mov    0x54(%rcx,%rax,1),%eax
  670608:	eb 59                	jmp    670663 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xe13>
  67060a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  670610:	48 8b 84 24 e8 00 00 	mov    0xe8(%rsp),%rax
  670617:	00 
  670618:	49 f7 d7             	not    %r15
  67061b:	49 01 c7             	add    %rax,%r15
  67061e:	0f 83 fe 10 00 00    	jae    671722 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ed2>
  670624:	48 8b 84 24 e0 00 00 	mov    0xe0(%rsp),%rax
  67062b:	00 
  67062c:	f3 42 0f 10 04 b8    	movss  (%rax,%r15,4),%xmm0
  670632:	f3 0f 11 44 24 78    	movss  %xmm0,0x78(%rsp)
  670638:	f3 0f 10 84 24 90 00 	movss  0x90(%rsp),%xmm0
  67063f:	00 00 
  670641:	f3 0f 11 44 24 40    	movss  %xmm0,0x40(%rsp)
  670647:	48 83 bc 24 f0 00 00 	cmpq   $0x0,0xf0(%rsp)
  67064e:	00 00 
  670650:	0f 85 5a fe ff ff    	jne    6704b0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xc60>
  670656:	e9 65 fe ff ff       	jmp    6704c0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xc70>
  67065b:	0f 57 c0             	xorps  %xmm0,%xmm0
  67065e:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  670663:	48 8b 8c 24 d8 04 00 	mov    0x4d8(%rsp),%rcx
  67066a:	00 
  67066b:	48 8b 94 24 e0 04 00 	mov    0x4e0(%rsp),%rdx
  670672:	00 
  670673:	f2 0f 10 4a 44       	movsd  0x44(%rdx),%xmm1
  670678:	f2 0f 11 8c 24 80 02 	movsd  %xmm1,0x280(%rsp)
  67067f:	00 00 
  670681:	f3 0f 11 84 24 88 02 	movss  %xmm0,0x288(%rsp)
  670688:	00 00 
  67068a:	89 84 24 8c 02 00 00 	mov    %eax,0x28c(%rsp)
  670691:	0f b6 89 8c 00 00 00 	movzbl 0x8c(%rcx),%ecx
  670698:	83 e1 01             	and    $0x1,%ecx
  67069b:	48 8d bc 24 80 02 00 	lea    0x280(%rsp),%rdi
  6706a2:	00 
  6706a3:	48 8d b4 24 00 05 00 	lea    0x500(%rsp),%rsi
  6706aa:	00 
  6706ab:	48 8d 94 24 50 05 00 	lea    0x550(%rsp),%rdx
  6706b2:	00 
  6706b3:	ff 15 bf ab 11 00    	call   *0x11abbf(%rip)        # 78b278 <_DYNAMIC+0x690>
  6706b9:	f3 0f 10 4c 24 38    	movss  0x38(%rsp),%xmm1
  6706bf:	f3 0f 58 c1          	addss  %xmm1,%xmm0
  6706c3:	f3 0f 11 4c 24 40    	movss  %xmm1,0x40(%rsp)
  6706c9:	f3 0f 11 4c 24 78    	movss  %xmm1,0x78(%rsp)
  6706cf:	f3 0f 11 44 24 38    	movss  %xmm0,0x38(%rsp)
  6706d5:	48 83 bc 24 f0 00 00 	cmpq   $0x0,0xf0(%rsp)
  6706dc:	00 00 
  6706de:	0f 85 cc fd ff ff    	jne    6704b0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xc60>
  6706e4:	e9 d7 fd ff ff       	jmp    6704c0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xc70>
  6706e9:	c7 44 24 5c 00 00 00 	movl   $0x0,0x5c(%rsp)
  6706f0:	00 
  6706f1:	48 8b 84 24 f0 04 00 	mov    0x4f0(%rsp),%rax
  6706f8:	00 
  6706f9:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
  670700:	00 
  670701:	89 9c 24 30 01 00 00 	mov    %ebx,0x130(%rsp)
  670708:	f3 0f 10 44 24 78    	movss  0x78(%rsp),%xmm0
  67070e:	f3 0f 11 84 24 34 01 	movss  %xmm0,0x134(%rsp)
  670715:	00 00 
  670717:	48 8b 84 24 d8 01 00 	mov    0x1d8(%rsp),%rax
  67071e:	00 
  67071f:	48 83 f8 02          	cmp    $0x2,%rax
  670723:	75 22                	jne    670747 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xef7>
  670725:	48 8d bc 24 e8 01 00 	lea    0x1e8(%rsp),%rdi
  67072c:	00 
  67072d:	e8 5e 7a 01 00       	call   688190 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  670732:	49 89 d7             	mov    %rdx,%r15
  670735:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
  67073c:	00 
  67073d:	48 89 94 24 e0 01 00 	mov    %rdx,0x1e0(%rsp)
  670744:	00 
  670745:	eb 08                	jmp    67074f <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xeff>
  670747:	4c 8b bc 24 e0 01 00 	mov    0x1e0(%rsp),%r15
  67074e:	00 
  67074f:	89 d9                	mov    %ebx,%ecx
  670751:	48 89 8c 24 90 00 00 	mov    %rcx,0x90(%rsp)
  670758:	00 
  670759:	44 89 e1             	mov    %r12d,%ecx
  67075c:	48 89 8c 24 18 01 00 	mov    %rcx,0x118(%rsp)
  670763:	00 
  670764:	48 83 f8 01          	cmp    $0x1,%rax
  670768:	0f 85 97 01 00 00    	jne    670905 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x10b5>
  67076e:	4c 3b 7c 24 48       	cmp    0x48(%rsp),%r15
  670773:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
  67077a:	00 
  67077b:	0f 83 27 05 00 00    	jae    670ca8 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1458>
  670781:	48 83 f9 01          	cmp    $0x1,%rcx
  670785:	75 0e                	jne    670795 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xf45>
  670787:	4c 3b bc 24 80 00 00 	cmp    0x80(%rsp),%r15
  67078e:	00 
  67078f:	0f 82 f3 09 00 00    	jb     671188 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1938>
  670795:	f3 0f 10 4c 24 40    	movss  0x40(%rsp),%xmm1
  67079b:	0f 57 c0             	xorps  %xmm0,%xmm0
  67079e:	f3 0f 5a c1          	cvtss2sd %xmm1,%xmm0
  6707a2:	f2 0f 11 84 24 88 00 	movsd  %xmm0,0x88(%rsp)
  6707a9:	00 00 
  6707ab:	f3 0f 58 4c 24 1c    	addss  0x1c(%rsp),%xmm1
  6707b1:	0f 57 c0             	xorps  %xmm0,%xmm0
  6707b4:	f3 0f 5a c1          	cvtss2sd %xmm1,%xmm0
  6707b8:	f2 0f 11 84 24 80 00 	movsd  %xmm0,0x80(%rsp)
  6707bf:	00 00 
  6707c1:	48 c7 84 24 d8 01 00 	movq   $0x2,0x1d8(%rsp)
  6707c8:	00 02 00 00 00 
  6707cd:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  6707d2:	49 39 d7             	cmp    %rdx,%r15
  6707d5:	0f 85 37 01 00 00    	jne    670912 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x10c2>
  6707db:	48 39 94 24 b0 00 00 	cmp    %rdx,0xb0(%rsp)
  6707e2:	00 
  6707e3:	0f 94 c0             	sete   %al
  6707e6:	22 44 24 5c          	and    0x5c(%rsp),%al
  6707ea:	4c 8d 84 24 28 01 00 	lea    0x128(%rsp),%r8
  6707f1:	00 
  6707f2:	3c 01                	cmp    $0x1,%al
  6707f4:	0f 85 32 01 00 00    	jne    67092c <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x10dc>
  6707fa:	49 8b 46 58          	mov    0x58(%r14),%rax
  6707fe:	4c 39 e8             	cmp    %r13,%rax
  670801:	0f 86 97 0e 00 00    	jbe    67169e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1e4e>
  670807:	49 8b 56 70          	mov    0x70(%r14),%rdx
  67080b:	48 8b bc 24 90 00 00 	mov    0x90(%rsp),%rdi
  670812:	00 
  670813:	48 8b b4 24 18 01 00 	mov    0x118(%rsp),%rsi
  67081a:	00 
  67081b:	39 fe                	cmp    %edi,%esi
  67081d:	0f 82 34 0e 00 00    	jb     671657 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1e07>
  670823:	48 39 f2             	cmp    %rsi,%rdx
  670826:	0f 82 2b 0e 00 00    	jb     671657 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1e07>
  67082c:	39 fe                	cmp    %edi,%esi
  67082e:	0f 84 28 0f 00 00    	je     67175c <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f0c>
  670834:	49 8b 46 68          	mov    0x68(%r14),%rax
  670838:	48 8d 0c 7f          	lea    (%rdi,%rdi,2),%rcx
  67083c:	80 7c 88 07 06       	cmpb   $0x6,0x7(%rax,%rcx,4)
  670841:	48 8b 94 24 b0 00 00 	mov    0xb0(%rsp),%rdx
  670848:	00 
  670849:	0f 84 dd 00 00 00    	je     67092c <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x10dc>
  67084f:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  670854:	f3 0f 10 40 40       	movss  0x40(%rax),%xmm0
  670859:	f3 0f 10 48 44       	movss  0x44(%rax),%xmm1
  67085e:	0f 28 d0             	movaps %xmm0,%xmm2
  670861:	f3 0f 5d 50 48       	minss  0x48(%rax),%xmm2
  670866:	0f 28 da             	movaps %xmm2,%xmm3
  670869:	f3 0f c2 da 03       	cmpunordss %xmm2,%xmm3
  67086e:	0f 28 e3             	movaps %xmm3,%xmm4
  670871:	0f 55 e2             	andnps %xmm2,%xmm4
  670874:	0f 54 d8             	andps  %xmm0,%xmm3
  670877:	0f 56 dc             	orps   %xmm4,%xmm3
  67087a:	0f 57 c0             	xorps  %xmm0,%xmm0
  67087d:	f3 0f 5a c3          	cvtss2sd %xmm3,%xmm0
  670881:	0f 28 d1             	movaps %xmm1,%xmm2
  670884:	f3 0f 5f 50 4c       	maxss  0x4c(%rax),%xmm2
  670889:	0f 28 da             	movaps %xmm2,%xmm3
  67088c:	f3 0f c2 da 03       	cmpunordss %xmm2,%xmm3
  670891:	0f 28 e3             	movaps %xmm3,%xmm4
  670894:	0f 55 e2             	andnps %xmm2,%xmm4
  670897:	0f 54 d9             	andps  %xmm1,%xmm3
  67089a:	0f 56 dc             	orps   %xmm4,%xmm3
  67089d:	0f 57 c9             	xorps  %xmm1,%xmm1
  6708a0:	f3 0f 5a cb          	cvtss2sd %xmm3,%xmm1
  6708a4:	f2 0f 10 94 24 88 00 	movsd  0x88(%rsp),%xmm2
  6708ab:	00 00 
  6708ad:	f2 0f 11 94 24 58 01 	movsd  %xmm2,0x158(%rsp)
  6708b4:	00 00 
  6708b6:	f2 0f 11 84 24 60 01 	movsd  %xmm0,0x160(%rsp)
  6708bd:	00 00 
  6708bf:	f2 0f 10 9c 24 80 00 	movsd  0x80(%rsp),%xmm3
  6708c6:	00 00 
  6708c8:	f2 0f 11 9c 24 68 01 	movsd  %xmm3,0x168(%rsp)
  6708cf:	00 00 
  6708d1:	f2 0f 11 8c 24 70 01 	movsd  %xmm1,0x170(%rsp)
  6708d8:	00 00 
  6708da:	f2 0f 11 94 24 78 01 	movsd  %xmm2,0x178(%rsp)
  6708e1:	00 00 
  6708e3:	f2 0f 11 84 24 80 01 	movsd  %xmm0,0x180(%rsp)
  6708ea:	00 00 
  6708ec:	f2 0f 11 9c 24 88 01 	movsd  %xmm3,0x188(%rsp)
  6708f3:	00 00 
  6708f5:	f2 0f 11 8c 24 90 01 	movsd  %xmm1,0x190(%rsp)
  6708fc:	00 00 
  6708fe:	b8 01 00 00 00       	mov    $0x1,%eax
  670903:	eb 1d                	jmp    670922 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x10d2>
  670905:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
  67090c:	00 
  67090d:	e9 96 03 00 00       	jmp    670ca8 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1458>
  670912:	4c 89 fa             	mov    %r15,%rdx
  670915:	41 b8 00 00 00 00    	mov    $0x0,%r8d
  67091b:	b8 00 00 00 00       	mov    $0x0,%eax
  670920:	76 0a                	jbe    67092c <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x10dc>
  670922:	48 89 84 24 50 01 00 	mov    %rax,0x150(%rsp)
  670929:	00 
  67092a:	eb 40                	jmp    67096c <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x111c>
  67092c:	48 39 94 24 a8 00 00 	cmp    %rdx,0xa8(%rsp)
  670933:	00 
  670934:	b9 00 00 00 00       	mov    $0x0,%ecx
  670939:	48 8d 84 24 40 01 00 	lea    0x140(%rsp),%rax
  670940:	00 
  670941:	48 0f 44 c8          	cmove  %rax,%rcx
  670945:	f6 44 24 0f 01       	testb  $0x1,0xf(%rsp)
  67094a:	b8 00 00 00 00       	mov    $0x0,%eax
  67094f:	48 0f 44 c8          	cmove  %rax,%rcx
  670953:	48 8d bc 24 50 01 00 	lea    0x150(%rsp),%rdi
  67095a:	00 
  67095b:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  670960:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
  670966:	ff 15 54 a6 11 00    	call   *0x11a654(%rip)        # 78afc0 <_DYNAMIC+0x3d8>
  67096c:	4c 89 bc 24 80 02 00 	mov    %r15,0x280(%rsp)
  670973:	00 
  670974:	48 8b 84 24 90 01 00 	mov    0x190(%rsp),%rax
  67097b:	00 
  67097c:	48 8d 94 24 88 02 00 	lea    0x288(%rsp),%rdx
  670983:	00 
  670984:	48 89 42 40          	mov    %rax,0x40(%rdx)
  670988:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
  67098f:	00 
  670990:	48 8b 8c 24 58 01 00 	mov    0x158(%rsp),%rcx
  670997:	00 
  670998:	0f 10 84 24 60 01 00 	movups 0x160(%rsp),%xmm0
  67099f:	00 
  6709a0:	0f 10 8c 24 70 01 00 	movups 0x170(%rsp),%xmm1
  6709a7:	00 
  6709a8:	0f 10 94 24 80 01 00 	movups 0x180(%rsp),%xmm2
  6709af:	00 
  6709b0:	0f 11 52 30          	movups %xmm2,0x30(%rdx)
  6709b4:	0f 11 4a 20          	movups %xmm1,0x20(%rdx)
  6709b8:	0f 11 42 10          	movups %xmm0,0x10(%rdx)
  6709bc:	48 89 02             	mov    %rax,(%rdx)
  6709bf:	48 89 4a 08          	mov    %rcx,0x8(%rdx)
  6709c3:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
  6709c8:	4c 89 fe             	mov    %r15,%rsi
  6709cb:	e8 f0 24 00 00       	call   672ec0 <gpui_canvas::text::planner::append_carets::{closure#1}>
  6709d0:	89 c3                	mov    %eax,%ebx
  6709d2:	83 f8 ff             	cmp    $0xffffffff,%eax
  6709d5:	0f 85 07 09 00 00    	jne    6712e2 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a92>
  6709db:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  6709e0:	48 39 8c 24 b0 00 00 	cmp    %rcx,0xb0(%rsp)
  6709e7:	00 
  6709e8:	0f 94 c0             	sete   %al
  6709eb:	8b 54 24 5c          	mov    0x5c(%rsp),%edx
  6709ef:	20 c2                	and    %al,%dl
  6709f1:	89 54 24 5c          	mov    %edx,0x5c(%rsp)
  6709f5:	48 39 8c 24 a8 00 00 	cmp    %rcx,0xa8(%rsp)
  6709fc:	00 
  6709fd:	b9 00 00 00 00       	mov    $0x0,%ecx
  670a02:	48 8d 84 24 40 01 00 	lea    0x140(%rsp),%rax
  670a09:	00 
  670a0a:	48 0f 44 c8          	cmove  %rax,%rcx
  670a0e:	f6 44 24 0f 01       	testb  $0x1,0xf(%rsp)
  670a13:	b8 00 00 00 00       	mov    $0x0,%eax
  670a18:	48 0f 44 c8          	cmove  %rax,%rcx
  670a1c:	48 89 4c 24 40       	mov    %rcx,0x40(%rsp)
  670a21:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  670a28:	0f 1f 84 00 00 00 00 
  670a2f:	00 
  670a30:	48 8b 84 24 d8 01 00 	mov    0x1d8(%rsp),%rax
  670a37:	00 
  670a38:	48 83 f8 02          	cmp    $0x2,%rax
  670a3c:	75 22                	jne    670a60 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1210>
  670a3e:	48 8d bc 24 e8 01 00 	lea    0x1e8(%rsp),%rdi
  670a45:	00 
  670a46:	e8 45 77 01 00       	call   688190 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  670a4b:	49 89 d4             	mov    %rdx,%r12
  670a4e:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
  670a55:	00 
  670a56:	48 89 94 24 e0 01 00 	mov    %rdx,0x1e0(%rsp)
  670a5d:	00 
  670a5e:	eb 08                	jmp    670a68 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1218>
  670a60:	4c 8b a4 24 e0 01 00 	mov    0x1e0(%rsp),%r12
  670a67:	00 
  670a68:	b9 01 00 00 00       	mov    $0x1,%ecx
  670a6d:	48 83 f8 01          	cmp    $0x1,%rax
  670a71:	0f 85 29 02 00 00    	jne    670ca0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1450>
  670a77:	4c 3b 64 24 48       	cmp    0x48(%rsp),%r12
  670a7c:	0f 83 1e 02 00 00    	jae    670ca0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1450>
  670a82:	4d 39 fc             	cmp    %r15,%r12
  670a85:	0f 82 fd 06 00 00    	jb     671188 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1938>
  670a8b:	48 c7 84 24 d8 01 00 	movq   $0x2,0x1d8(%rsp)
  670a92:	00 02 00 00 00 
  670a97:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  670a9c:	49 39 d4             	cmp    %rdx,%r12
  670a9f:	0f 85 30 01 00 00    	jne    670bd5 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1385>
  670aa5:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
  670aaa:	4c 8d 84 24 28 01 00 	lea    0x128(%rsp),%r8
  670ab1:	00 
  670ab2:	80 7c 24 5c 00       	cmpb   $0x0,0x5c(%rsp)
  670ab7:	0f 84 53 01 00 00    	je     670c10 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x13c0>
  670abd:	49 8b 46 58          	mov    0x58(%r14),%rax
  670ac1:	4c 39 e8             	cmp    %r13,%rax
  670ac4:	0f 86 d4 0b 00 00    	jbe    67169e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1e4e>
  670aca:	49 8b 56 70          	mov    0x70(%r14),%rdx
  670ace:	48 8b bc 24 90 00 00 	mov    0x90(%rsp),%rdi
  670ad5:	00 
  670ad6:	48 8b b4 24 18 01 00 	mov    0x118(%rsp),%rsi
  670add:	00 
  670ade:	39 fe                	cmp    %edi,%esi
  670ae0:	0f 82 71 0b 00 00    	jb     671657 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1e07>
  670ae6:	48 39 f2             	cmp    %rsi,%rdx
  670ae9:	0f 82 68 0b 00 00    	jb     671657 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1e07>
  670aef:	39 fe                	cmp    %edi,%esi
  670af1:	0f 84 65 0c 00 00    	je     67175c <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f0c>
  670af7:	49 8b 46 68          	mov    0x68(%r14),%rax
  670afb:	48 8d 0c 7f          	lea    (%rdi,%rdi,2),%rcx
  670aff:	80 7c 88 07 06       	cmpb   $0x6,0x7(%rax,%rcx,4)
  670b04:	48 8b 94 24 b0 00 00 	mov    0xb0(%rsp),%rdx
  670b0b:	00 
  670b0c:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
  670b11:	0f 84 f9 00 00 00    	je     670c10 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x13c0>
  670b17:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  670b1c:	f3 0f 10 40 40       	movss  0x40(%rax),%xmm0
  670b21:	f3 0f 10 48 44       	movss  0x44(%rax),%xmm1
  670b26:	0f 28 d0             	movaps %xmm0,%xmm2
  670b29:	f3 0f 5d 50 48       	minss  0x48(%rax),%xmm2
  670b2e:	0f 28 da             	movaps %xmm2,%xmm3
  670b31:	f3 0f c2 da 03       	cmpunordss %xmm2,%xmm3
  670b36:	0f 28 e3             	movaps %xmm3,%xmm4
  670b39:	0f 55 e2             	andnps %xmm2,%xmm4
  670b3c:	0f 54 d8             	andps  %xmm0,%xmm3
  670b3f:	0f 56 dc             	orps   %xmm4,%xmm3
  670b42:	0f 57 c0             	xorps  %xmm0,%xmm0
  670b45:	f3 0f 5a c3          	cvtss2sd %xmm3,%xmm0
  670b49:	0f 28 d1             	movaps %xmm1,%xmm2
  670b4c:	f3 0f 5f 50 4c       	maxss  0x4c(%rax),%xmm2
  670b51:	0f 28 da             	movaps %xmm2,%xmm3
  670b54:	f3 0f c2 da 03       	cmpunordss %xmm2,%xmm3
  670b59:	0f 28 e3             	movaps %xmm3,%xmm4
  670b5c:	0f 55 e2             	andnps %xmm2,%xmm4
  670b5f:	0f 54 d9             	andps  %xmm1,%xmm3
  670b62:	0f 56 dc             	orps   %xmm4,%xmm3
  670b65:	0f 57 c9             	xorps  %xmm1,%xmm1
  670b68:	f3 0f 5a cb          	cvtss2sd %xmm3,%xmm1
  670b6c:	f2 0f 10 94 24 88 00 	movsd  0x88(%rsp),%xmm2
  670b73:	00 00 
  670b75:	f2 0f 11 94 24 58 01 	movsd  %xmm2,0x158(%rsp)
  670b7c:	00 00 
  670b7e:	f2 0f 11 84 24 60 01 	movsd  %xmm0,0x160(%rsp)
  670b85:	00 00 
  670b87:	f2 0f 10 9c 24 80 00 	movsd  0x80(%rsp),%xmm3
  670b8e:	00 00 
  670b90:	f2 0f 11 9c 24 68 01 	movsd  %xmm3,0x168(%rsp)
  670b97:	00 00 
  670b99:	f2 0f 11 8c 24 70 01 	movsd  %xmm1,0x170(%rsp)
  670ba0:	00 00 
  670ba2:	f2 0f 11 94 24 78 01 	movsd  %xmm2,0x178(%rsp)
  670ba9:	00 00 
  670bab:	f2 0f 11 84 24 80 01 	movsd  %xmm0,0x180(%rsp)
  670bb2:	00 00 
  670bb4:	f2 0f 11 9c 24 88 01 	movsd  %xmm3,0x188(%rsp)
  670bbb:	00 00 
  670bbd:	f2 0f 11 8c 24 90 01 	movsd  %xmm1,0x190(%rsp)
  670bc4:	00 00 
  670bc6:	b8 01 00 00 00       	mov    $0x1,%eax
  670bcb:	48 89 84 24 50 01 00 	mov    %rax,0x150(%rsp)
  670bd2:	00 
  670bd3:	eb 54                	jmp    670c29 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x13d9>
  670bd5:	76 0c                	jbe    670be3 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1393>
  670bd7:	31 c0                	xor    %eax,%eax
  670bd9:	48 89 84 24 50 01 00 	mov    %rax,0x150(%rsp)
  670be0:	00 
  670be1:	eb 46                	jmp    670c29 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x13d9>
  670be3:	4c 39 a4 24 a8 00 00 	cmp    %r12,0xa8(%rsp)
  670bea:	00 
  670beb:	b9 00 00 00 00       	mov    $0x0,%ecx
  670bf0:	48 8d 84 24 40 01 00 	lea    0x140(%rsp),%rax
  670bf7:	00 
  670bf8:	48 0f 44 c8          	cmove  %rax,%rcx
  670bfc:	f6 44 24 0f 01       	testb  $0x1,0xf(%rsp)
  670c01:	b8 00 00 00 00       	mov    $0x0,%eax
  670c06:	48 0f 44 c8          	cmove  %rax,%rcx
  670c0a:	4c 89 e2             	mov    %r12,%rdx
  670c0d:	45 31 c0             	xor    %r8d,%r8d
  670c10:	48 8d bc 24 50 01 00 	lea    0x150(%rsp),%rdi
  670c17:	00 
  670c18:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  670c1d:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
  670c23:	ff 15 97 a3 11 00    	call   *0x11a397(%rip)        # 78afc0 <_DYNAMIC+0x3d8>
  670c29:	4c 89 a4 24 80 02 00 	mov    %r12,0x280(%rsp)
  670c30:	00 
  670c31:	48 8b 84 24 90 01 00 	mov    0x190(%rsp),%rax
  670c38:	00 
  670c39:	48 8d 94 24 88 02 00 	lea    0x288(%rsp),%rdx
  670c40:	00 
  670c41:	48 89 42 40          	mov    %rax,0x40(%rdx)
  670c45:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
  670c4c:	00 
  670c4d:	48 8b 8c 24 58 01 00 	mov    0x158(%rsp),%rcx
  670c54:	00 
  670c55:	0f 10 84 24 60 01 00 	movups 0x160(%rsp),%xmm0
  670c5c:	00 
  670c5d:	0f 10 8c 24 70 01 00 	movups 0x170(%rsp),%xmm1
  670c64:	00 
  670c65:	0f 10 94 24 80 01 00 	movups 0x180(%rsp),%xmm2
  670c6c:	00 
  670c6d:	0f 11 52 30          	movups %xmm2,0x30(%rdx)
  670c71:	0f 11 4a 20          	movups %xmm1,0x20(%rdx)
  670c75:	0f 11 42 10          	movups %xmm0,0x10(%rdx)
  670c79:	48 89 02             	mov    %rax,(%rdx)
  670c7c:	48 89 4a 08          	mov    %rcx,0x8(%rdx)
  670c80:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
  670c85:	4c 89 e6             	mov    %r12,%rsi
  670c88:	e8 33 22 00 00       	call   672ec0 <gpui_canvas::text::planner::append_carets::{closure#1}>
  670c8d:	89 c3                	mov    %eax,%ebx
  670c8f:	4d 89 e7             	mov    %r12,%r15
  670c92:	83 f8 ff             	cmp    $0xffffffff,%eax
  670c95:	0f 84 95 fd ff ff    	je     670a30 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x11e0>
  670c9b:	e9 42 06 00 00       	jmp    6712e2 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a92>
  670ca0:	4c 89 bc 24 80 00 00 	mov    %r15,0x80(%rsp)
  670ca7:	00 
  670ca8:	49 8b 46 58          	mov    0x58(%r14),%rax
  670cac:	4c 39 e8             	cmp    %r13,%rax
  670caf:	0f 86 e9 09 00 00    	jbe    67169e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1e4e>
  670cb5:	49 8b 56 70          	mov    0x70(%r14),%rdx
  670cb9:	48 8b bc 24 90 00 00 	mov    0x90(%rsp),%rdi
  670cc0:	00 
  670cc1:	48 8b b4 24 18 01 00 	mov    0x118(%rsp),%rsi
  670cc8:	00 
  670cc9:	39 fe                	cmp    %edi,%esi
  670ccb:	0f 82 86 09 00 00    	jb     671657 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1e07>
  670cd1:	48 39 f2             	cmp    %rsi,%rdx
  670cd4:	0f 82 7d 09 00 00    	jb     671657 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1e07>
  670cda:	48 89 8c 24 88 00 00 	mov    %rcx,0x88(%rsp)
  670ce1:	00 
  670ce2:	39 fe                	cmp    %edi,%esi
  670ce4:	0f 84 72 0a 00 00    	je     67175c <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f0c>
  670cea:	49 8b 46 68          	mov    0x68(%r14),%rax
  670cee:	48 8d 0c 7f          	lea    (%rdi,%rdi,2),%rcx
  670cf2:	80 7c 88 07 06       	cmpb   $0x6,0x7(%rax,%rcx,4)
  670cf7:	0f 95 c0             	setne  %al
  670cfa:	89 44 24 5c          	mov    %eax,0x5c(%rsp)
  670cfe:	0f 10 84 24 28 01 00 	movups 0x128(%rsp),%xmm0
  670d05:	00 
  670d06:	48 8d 84 24 40 01 00 	lea    0x140(%rsp),%rax
  670d0d:	00 
  670d0e:	0f 11 00             	movups %xmm0,(%rax)
  670d11:	c7 84 24 3c 01 00 00 	movl   $0x1,0x13c(%rsp)
  670d18:	01 00 00 00 
  670d1c:	c6 44 24 0f 01       	movb   $0x1,0xf(%rsp)
  670d21:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
  670d26:	48 89 8c 24 a8 00 00 	mov    %rcx,0xa8(%rsp)
  670d2d:	00 
  670d2e:	f3 0f 10 44 24 78    	movss  0x78(%rsp),%xmm0
  670d34:	f3 0f 11 84 24 90 00 	movss  %xmm0,0x90(%rsp)
  670d3b:	00 00 
  670d3d:	48 89 8c 24 b0 00 00 	mov    %rcx,0xb0(%rsp)
  670d44:	00 
  670d45:	4c 8d b4 24 b8 03 00 	lea    0x3b8(%rsp),%r14
  670d4c:	00 
  670d4d:	4c 8d ac 24 80 02 00 	lea    0x280(%rsp),%r13
  670d54:	00 
  670d55:	e9 4a f5 ff ff       	jmp    6702a4 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0xa54>
  670d5a:	4c 8b 6c 24 28       	mov    0x28(%rsp),%r13
  670d5f:	4c 8b 94 24 98 03 00 	mov    0x398(%rsp),%r10
  670d66:	00 
  670d67:	e9 ae f3 ff ff       	jmp    67011a <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x8ca>
  670d6c:	48 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%rax
  670d73:	00 
  670d74:	48 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%rcx
  670d7b:	00 
  670d7c:	48 8b 94 24 b8 01 00 	mov    0x1b8(%rsp),%rdx
  670d83:	00 
  670d84:	48 8b b4 24 c0 01 00 	mov    0x1c0(%rsp),%rsi
  670d8b:	00 
  670d8c:	8b bc 24 c8 01 00 00 	mov    0x1c8(%rsp),%edi
  670d93:	89 bc 24 d0 03 00 00 	mov    %edi,0x3d0(%rsp)
  670d9a:	8b bc 24 cc 01 00 00 	mov    0x1cc(%rsp),%edi
  670da1:	89 bc 24 d4 03 00 00 	mov    %edi,0x3d4(%rsp)
  670da8:	8b bc 24 d0 01 00 00 	mov    0x1d0(%rsp),%edi
  670daf:	89 bc 24 d8 03 00 00 	mov    %edi,0x3d8(%rsp)
  670db6:	8b bc 24 d4 01 00 00 	mov    0x1d4(%rsp),%edi
  670dbd:	89 bc 24 dc 03 00 00 	mov    %edi,0x3dc(%rsp)
  670dc4:	48 89 94 24 c0 03 00 	mov    %rdx,0x3c0(%rsp)
  670dcb:	00 
  670dcc:	48 89 b4 24 c8 03 00 	mov    %rsi,0x3c8(%rsp)
  670dd3:	00 
  670dd4:	48 89 84 24 b0 03 00 	mov    %rax,0x3b0(%rsp)
  670ddb:	00 
  670ddc:	48 89 8c 24 b8 03 00 	mov    %rcx,0x3b8(%rsp)
  670de3:	00 
  670de4:	48 8d bc 24 e8 05 00 	lea    0x5e8(%rsp),%rdi
  670deb:	00 
  670dec:	48 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%rsi
  670df3:	00 
  670df4:	ba 01 00 00 00       	mov    $0x1,%edx
  670df9:	e8 12 f9 00 00       	call   680710 <<parley::layout::run::Clusters<()>>::new>
  670dfe:	4c 8d ac 24 80 02 00 	lea    0x280(%rsp),%r13
  670e05:	00 
  670e06:	ba 10 01 00 00       	mov    $0x110,%edx
  670e0b:	48 8d bc 24 b0 03 00 	lea    0x3b0(%rsp),%rdi
  670e12:	00 
  670e13:	48 8d b4 24 e8 05 00 	lea    0x5e8(%rsp),%rsi
  670e1a:	00 
  670e1b:	ff 15 97 a0 11 00    	call   *0x11a097(%rip)        # 78aeb8 <memcpy@GLIBC_2.14>
  670e21:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  670e28:	0f 1f 84 00 00 00 00 
  670e2f:	00 
  670e30:	48 8d bc 24 d0 04 00 	lea    0x4d0(%rsp),%rdi
  670e37:	00 
  670e38:	48 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%rsi
  670e3f:	00 
  670e40:	e8 3b 21 01 00       	call   682f80 <<parley::layout::run::Clusters<()> as core::iter::traits::iterator::Iterator>::next>
  670e45:	48 83 bc 24 d0 04 00 	cmpq   $0x0,0x4d0(%rsp)
  670e4c:	00 00 
  670e4e:	0f 84 f5 f3 ff ff    	je     670249 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x9f9>
  670e54:	ba 90 00 00 00       	mov    $0x90,%edx
  670e59:	4c 89 ef             	mov    %r13,%rdi
  670e5c:	48 8d b4 24 d0 04 00 	lea    0x4d0(%rsp),%rsi
  670e63:	00 
  670e64:	ff 15 4e a0 11 00    	call   *0x11a04e(%rip)        # 78aeb8 <memcpy@GLIBC_2.14>
  670e6a:	48 8b 9c 24 e8 00 00 	mov    0xe8(%rsp),%rbx
  670e71:	00 
  670e72:	48 3b 9c 24 d8 00 00 	cmp    0xd8(%rsp),%rbx
  670e79:	00 
  670e7a:	75 0e                	jne    670e8a <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x163a>
  670e7c:	48 8d bc 24 d8 00 00 	lea    0xd8(%rsp),%rdi
  670e83:	00 
  670e84:	ff 15 36 a2 11 00    	call   *0x11a236(%rip)        # 78b0c0 <_DYNAMIC+0x4d8>
  670e8a:	48 8b 84 24 e0 00 00 	mov    0xe0(%rsp),%rax
  670e91:	00 
  670e92:	f3 0f 10 44 24 38    	movss  0x38(%rsp),%xmm0
  670e98:	f3 0f 11 04 98       	movss  %xmm0,(%rax,%rbx,4)
  670e9d:	48 ff c3             	inc    %rbx
  670ea0:	48 89 9c 24 e8 00 00 	mov    %rbx,0xe8(%rsp)
  670ea7:	00 
  670ea8:	48 83 bc 24 98 02 00 	cmpq   $0x0,0x298(%rsp)
  670eaf:	00 00 
  670eb1:	74 3f                	je     670ef2 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x16a2>
  670eb3:	48 8b 84 24 80 02 00 	mov    0x280(%rsp),%rax
  670eba:	00 
  670ebb:	44 8b ac 24 a0 02 00 	mov    0x2a0(%rsp),%r13d
  670ec2:	00 
  670ec3:	48 8b 88 18 01 00 00 	mov    0x118(%rax),%rcx
  670eca:	4c 39 e9             	cmp    %r13,%rcx
  670ecd:	0f 86 63 08 00 00    	jbe    671736 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ee6>
  670ed3:	48 8b 80 10 01 00 00 	mov    0x110(%rax),%rax
  670eda:	49 6b cd 70          	imul   $0x70,%r13,%rcx
  670ede:	f3 0f 10 44 08 50    	movss  0x50(%rax,%rcx,1),%xmm0
  670ee4:	8b 44 08 54          	mov    0x54(%rax,%rcx,1),%eax
  670ee8:	4c 8d ac 24 80 02 00 	lea    0x280(%rsp),%r13
  670eef:	00 
  670ef0:	eb 08                	jmp    670efa <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x16aa>
  670ef2:	0f 57 c0             	xorps  %xmm0,%xmm0
  670ef5:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  670efa:	48 8b 8c 24 88 02 00 	mov    0x288(%rsp),%rcx
  670f01:	00 
  670f02:	48 8b 94 24 90 02 00 	mov    0x290(%rsp),%rdx
  670f09:	00 
  670f0a:	f2 0f 10 4a 44       	movsd  0x44(%rdx),%xmm1
  670f0f:	f2 0f 11 8c 24 60 05 	movsd  %xmm1,0x560(%rsp)
  670f16:	00 00 
  670f18:	f3 0f 11 84 24 68 05 	movss  %xmm0,0x568(%rsp)
  670f1f:	00 00 
  670f21:	89 84 24 6c 05 00 00 	mov    %eax,0x56c(%rsp)
  670f28:	0f b6 89 8c 00 00 00 	movzbl 0x8c(%rcx),%ecx
  670f2f:	83 e1 01             	and    $0x1,%ecx
  670f32:	48 8d bc 24 60 05 00 	lea    0x560(%rsp),%rdi
  670f39:	00 
  670f3a:	4c 89 fe             	mov    %r15,%rsi
  670f3d:	4c 89 e2             	mov    %r12,%rdx
  670f40:	ff 15 32 a3 11 00    	call   *0x11a332(%rip)        # 78b278 <_DYNAMIC+0x690>
  670f46:	f3 0f 10 4c 24 38    	movss  0x38(%rsp),%xmm1
  670f4c:	f3 0f 58 c8          	addss  %xmm0,%xmm1
  670f50:	f3 0f 11 4c 24 38    	movss  %xmm1,0x38(%rsp)
  670f56:	e9 d5 fe ff ff       	jmp    670e30 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x15e0>
  670f5b:	48 8b 84 24 b0 03 00 	mov    0x3b0(%rsp),%rax
  670f62:	00 
  670f63:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  670f68:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  670f6d:	f3 0f 10 48 28       	movss  0x28(%rax),%xmm1
  670f72:	48 c1 e7 03          	shl    $0x3,%rdi
  670f76:	48 8d 04 bf          	lea    (%rdi,%rdi,4),%rax
  670f7a:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
  670f81:	00 
  670f82:	4c 8d 3c 01          	lea    (%rcx,%rax,1),%r15
  670f86:	48 c1 e6 03          	shl    $0x3,%rsi
  670f8a:	4c 8d 24 b6          	lea    (%rsi,%rsi,4),%r12
  670f8e:	49 29 c4             	sub    %rax,%r12
  670f91:	45 31 f6             	xor    %r14d,%r14d
  670f94:	eb 1f                	jmp    670fb5 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1765>
  670f96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  670f9d:	00 00 00 
  670fa0:	49 83 c7 28          	add    $0x28,%r15
  670fa4:	f3 0f 58 c8          	addss  %xmm0,%xmm1
  670fa8:	49 ff c6             	inc    %r14
  670fab:	49 83 c4 d8          	add    $0xffffffffffffffd8,%r12
  670faf:	0f 84 3b f1 ff ff    	je     6700f0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x8a0>
  670fb5:	4d 8b 6f 10          	mov    0x10(%r15),%r13
  670fb9:	41 80 7f 21 01       	cmpb   $0x1,0x21(%r15)
  670fbe:	75 30                	jne    670ff0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x17a0>
  670fc0:	4c 3b ac 24 c0 00 00 	cmp    0xc0(%rsp),%r13
  670fc7:	00 
  670fc8:	0f 83 09 07 00 00    	jae    6716d7 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1e87>
  670fce:	49 6b c5 38          	imul   $0x38,%r13,%rax
  670fd2:	48 8b 8c 24 a8 03 00 	mov    0x3a8(%rsp),%rcx
  670fd9:	00 
  670fda:	f3 0f 10 44 01 24    	movss  0x24(%rcx,%rax,1),%xmm0
  670fe0:	4c 8b 6c 24 28       	mov    0x28(%rsp),%r13
  670fe5:	eb b9                	jmp    670fa0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1750>
  670fe7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  670fee:	00 00 
  670ff0:	4c 3b ac 24 b8 00 00 	cmp    0xb8(%rsp),%r13
  670ff7:	00 
  670ff8:	0f 83 ef 06 00 00    	jae    6716ed <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1e9d>
  670ffe:	4c 3b ac 24 a0 01 00 	cmp    0x1a0(%rsp),%r13
  671005:	00 
  671006:	0f 83 f7 06 00 00    	jae    671703 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1eb3>
  67100c:	4a 8d 04 ed 00 00 00 	lea    0x0(,%r13,8),%rax
  671013:	00 
  671014:	4c 01 e8             	add    %r13,%rax
  671017:	48 c1 e0 04          	shl    $0x4,%rax
  67101b:	48 03 84 24 c8 00 00 	add    0xc8(%rsp),%rax
  671022:	00 
  671023:	4a 8d 0c ad 00 00 00 	lea    0x0(,%r13,4),%rcx
  67102a:	00 
  67102b:	4c 01 e9             	add    %r13,%rcx
  67102e:	48 c1 e1 04          	shl    $0x4,%rcx
  671032:	48 03 8c 24 d0 00 00 	add    0xd0(%rsp),%rcx
  671039:	00 
  67103a:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
  67103f:	48 89 94 24 b0 03 00 	mov    %rdx,0x3b0(%rsp)
  671046:	00 
  671047:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
  67104e:	00 
  67104f:	48 89 8c 24 c0 03 00 	mov    %rcx,0x3c0(%rsp)
  671056:	00 
  671057:	4c 89 bc 24 c8 03 00 	mov    %r15,0x3c8(%rsp)
  67105e:	00 
  67105f:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  671064:	89 84 24 d0 03 00 00 	mov    %eax,0x3d0(%rsp)
  67106b:	44 89 b4 24 d4 03 00 	mov    %r14d,0x3d4(%rsp)
  671072:	00 
  671073:	44 89 ac 24 d8 03 00 	mov    %r13d,0x3d8(%rsp)
  67107a:	00 
  67107b:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  671080:	4c 8b 68 10          	mov    0x10(%rax),%r13
  671084:	4d 01 f5             	add    %r14,%r13
  671087:	4c 3b 6c 24 10       	cmp    0x10(%rsp),%r13
  67108c:	0f 83 87 06 00 00    	jae    671719 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ec9>
  671092:	4a 8d 04 ad 00 00 00 	lea    0x0(,%r13,4),%rax
  671099:	00 
  67109a:	4c 01 e8             	add    %r13,%rax
  67109d:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
  6710a4:	00 
  6710a5:	4c 8b 6c c1 10       	mov    0x10(%rcx,%rax,8),%r13
  6710aa:	4c 2b 6c 24 48       	sub    0x48(%rsp),%r13
  6710af:	49 39 dd             	cmp    %rbx,%r13
  6710b2:	0f 83 11 06 00 00    	jae    6716c9 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1e79>
  6710b8:	f3 0f 11 4c 24 38    	movss  %xmm1,0x38(%rsp)
  6710be:	f3 42 0f 11 4c ed 04 	movss  %xmm1,0x4(%rbp,%r13,8)
  6710c5:	48 8d bc 24 b0 03 00 	lea    0x3b0(%rsp),%rdi
  6710cc:	00 
  6710cd:	e8 7e f1 00 00       	call   680250 <<parley::layout::run::Run<()>>::advance>
  6710d2:	4c 8b 6c 24 28       	mov    0x28(%rsp),%r13
  6710d7:	f3 0f 10 4c 24 38    	movss  0x38(%rsp),%xmm1
  6710dd:	e9 be fe ff ff       	jmp    670fa0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1750>
  6710e2:	4c 8d b4 24 b8 03 00 	lea    0x3b8(%rsp),%r14
  6710e9:	00 
  6710ea:	31 db                	xor    %ebx,%ebx
  6710ec:	48 8d bc 24 e8 01 00 	lea    0x1e8(%rsp),%rdi
  6710f3:	00 
  6710f4:	e8 97 70 01 00       	call   688190 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  6710f9:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
  671100:	00 
  671101:	48 89 94 24 e0 01 00 	mov    %rdx,0x1e0(%rsp)
  671108:	00 
  671109:	48 83 f8 01          	cmp    $0x1,%rax
  67110d:	0f 85 bd 04 00 00    	jne    6715d0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1d80>
  671113:	4d 89 f5             	mov    %r14,%r13
  671116:	4c 8b b4 24 e0 01 00 	mov    0x1e0(%rsp),%r14
  67111d:	00 
  67111e:	4c 3b b4 24 80 00 00 	cmp    0x80(%rsp),%r14
  671125:	00 
  671126:	0f 92 c0             	setb   %al
  671129:	84 c3                	test   %al,%bl
  67112b:	0f 84 26 01 00 00    	je     671257 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a07>
  671131:	48 8d 9c 24 b0 03 00 	lea    0x3b0(%rsp),%rbx
  671138:	00 
  671139:	48 8d b4 24 d8 01 00 	lea    0x1d8(%rsp),%rsi
  671140:	00 
  671141:	ba a8 00 00 00       	mov    $0xa8,%edx
  671146:	48 89 df             	mov    %rbx,%rdi
  671149:	ff 15 69 9d 11 00    	call   *0x119d69(%rip)        # 78aeb8 <memcpy@GLIBC_2.14>
  67114f:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
  671154:	48 89 de             	mov    %rbx,%rsi
  671157:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
  67115d:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
  671162:	e8 99 0d 00 00       	call   671f00 <parley::editing::geometry::visit_direct::<(), gpui_canvas::Error, core::iter::adapters::peekable::Peekable<icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>>, gpui_canvas::text::planner::append_carets::{closure#1}>>
  671167:	eb 55                	jmp    6711be <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x196e>
  671169:	45 31 ff             	xor    %r15d,%r15d
  67116c:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
  671171:	48 89 ee             	mov    %rbp,%rsi
  671174:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
  67117a:	48 89 da             	mov    %rbx,%rdx
  67117d:	e8 ae 0f 00 00       	call   672130 <parley::editing::geometry::visit_indexed::<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>>
  671182:	89 c3                	mov    %eax,%ebx
  671184:	31 ff                	xor    %edi,%edi
  671186:	eb 70                	jmp    6711f8 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19a8>
  671188:	48 8d 9c 24 80 02 00 	lea    0x280(%rsp),%rbx
  67118f:	00 
  671190:	48 8d b4 24 d8 01 00 	lea    0x1d8(%rsp),%rsi
  671197:	00 
  671198:	ba a8 00 00 00       	mov    $0xa8,%edx
  67119d:	48 89 df             	mov    %rbx,%rdi
  6711a0:	ff 15 12 9d 11 00    	call   *0x119d12(%rip)        # 78aeb8 <memcpy@GLIBC_2.14>
  6711a6:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
  6711ab:	48 89 de             	mov    %rbx,%rsi
  6711ae:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
  6711b4:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
  6711b9:	e8 42 0d 00 00       	call   671f00 <parley::editing::geometry::visit_direct::<(), gpui_canvas::Error, core::iter::adapters::peekable::Peekable<icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>>, gpui_canvas::text::planner::append_carets::{closure#1}>>
  6711be:	89 c3                	mov    %eax,%ebx
  6711c0:	e9 34 04 00 00       	jmp    6715f9 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1da9>
  6711c5:	45 31 ff             	xor    %r15d,%r15d
  6711c8:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
  6711cd:	48 8b 6c 24 20       	mov    0x20(%rsp),%rbp
  6711d2:	48 89 ee             	mov    %rbp,%rsi
  6711d5:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
  6711db:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
  6711e0:	e8 4b 0f 00 00       	call   672130 <parley::editing::geometry::visit_indexed::<(), gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>>
  6711e5:	89 c3                	mov    %eax,%ebx
  6711e7:	31 ff                	xor    %edi,%edi
  6711e9:	eb 08                	jmp    6711f3 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19a3>
  6711eb:	bb fe ff ff ff       	mov    $0xfffffffe,%ebx
  6711f0:	40 b7 01             	mov    $0x1,%dil
  6711f3:	48 8b 6c 24 20       	mov    0x20(%rsp),%rbp
  6711f8:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
  6711ff:	00 
  671200:	48 85 f6             	test   %rsi,%rsi
  671203:	74 1d                	je     671222 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19d2>
  671205:	41 89 fe             	mov    %edi,%r14d
  671208:	48 8b bc 24 08 01 00 	mov    0x108(%rsp),%rdi
  67120f:	00 
  671210:	48 c1 e6 03          	shl    $0x3,%rsi
  671214:	ba 04 00 00 00       	mov    $0x4,%edx
  671219:	ff 15 01 9c 11 00    	call   *0x119c01(%rip)        # 78ae20 <_DYNAMIC+0x238>
  67121f:	44 89 f7             	mov    %r14d,%edi
  671222:	40 84 ff             	test   %dil,%dil
  671225:	74 1c                	je     671243 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19f3>
  671227:	48 8b 75 00          	mov    0x0(%rbp),%rsi
  67122b:	48 85 f6             	test   %rsi,%rsi
  67122e:	74 13                	je     671243 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19f3>
  671230:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
  671234:	48 c1 e6 03          	shl    $0x3,%rsi
  671238:	ba 08 00 00 00       	mov    $0x8,%edx
  67123d:	ff 15 dd 9b 11 00    	call   *0x119bdd(%rip)        # 78ae20 <_DYNAMIC+0x238>
  671243:	89 d8                	mov    %ebx,%eax
  671245:	48 81 c4 08 08 00 00 	add    $0x808,%rsp
  67124c:	5b                   	pop    %rbx
  67124d:	41 5c                	pop    %r12
  67124f:	41 5d                	pop    %r13
  671251:	41 5e                	pop    %r14
  671253:	41 5f                	pop    %r15
  671255:	5d                   	pop    %rbp
  671256:	c3                   	ret
  671257:	48 c7 84 24 d8 01 00 	movq   $0x2,0x1d8(%rsp)
  67125e:	00 02 00 00 00 
  671263:	48 8d bc 24 80 02 00 	lea    0x280(%rsp),%rdi
  67126a:	00 
  67126b:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  671270:	4c 89 f2             	mov    %r14,%rdx
  671273:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
  671279:	31 c9                	xor    %ecx,%ecx
  67127b:	45 31 c0             	xor    %r8d,%r8d
  67127e:	ff 15 3c 9d 11 00    	call   *0x119d3c(%rip)        # 78afc0 <_DYNAMIC+0x3d8>
  671284:	4c 89 ea             	mov    %r13,%rdx
  671287:	4c 89 b4 24 b0 03 00 	mov    %r14,0x3b0(%rsp)
  67128e:	00 
  67128f:	48 8b 84 24 c0 02 00 	mov    0x2c0(%rsp),%rax
  671296:	00 
  671297:	48 89 42 40          	mov    %rax,0x40(%rdx)
  67129b:	0f 10 84 24 80 02 00 	movups 0x280(%rsp),%xmm0
  6712a2:	00 
  6712a3:	0f 10 8c 24 90 02 00 	movups 0x290(%rsp),%xmm1
  6712aa:	00 
  6712ab:	0f 10 94 24 a0 02 00 	movups 0x2a0(%rsp),%xmm2
  6712b2:	00 
  6712b3:	0f 10 9c 24 b0 02 00 	movups 0x2b0(%rsp),%xmm3
  6712ba:	00 
  6712bb:	0f 11 5a 30          	movups %xmm3,0x30(%rdx)
  6712bf:	0f 11 52 20          	movups %xmm2,0x20(%rdx)
  6712c3:	0f 11 4a 10          	movups %xmm1,0x10(%rdx)
  6712c7:	0f 11 02             	movups %xmm0,(%rdx)
  6712ca:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
  6712cf:	4c 89 f6             	mov    %r14,%rsi
  6712d2:	e8 e9 1b 00 00       	call   672ec0 <gpui_canvas::text::planner::append_carets::{closure#1}>
  6712d7:	89 c3                	mov    %eax,%ebx
  6712d9:	83 f8 ff             	cmp    $0xffffffff,%eax
  6712dc:	0f 84 0d 02 00 00    	je     6714ef <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1c9f>
  6712e2:	48 8b b4 24 e8 01 00 	mov    0x1e8(%rsp),%rsi
  6712e9:	00 
  6712ea:	e9 ee 02 00 00       	jmp    6715dd <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1d8d>
  6712ef:	8b 8c 24 3c 01 00 00 	mov    0x13c(%rsp),%ecx
  6712f6:	48 8b 84 24 d8 01 00 	mov    0x1d8(%rsp),%rax
  6712fd:	00 
  6712fe:	f6 c1 01             	test   $0x1,%cl
  671301:	0f 84 3d 03 00 00    	je     671644 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1df4>
  671307:	83 f8 02             	cmp    $0x2,%eax
  67130a:	48 8b 6c 24 20       	mov    0x20(%rsp),%rbp
  67130f:	75 1d                	jne    67132e <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ade>
  671311:	48 8d bc 24 e8 01 00 	lea    0x1e8(%rsp),%rdi
  671318:	00 
  671319:	e8 72 6e 01 00       	call   688190 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  67131e:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
  671325:	00 
  671326:	48 89 94 24 e0 01 00 	mov    %rdx,0x1e0(%rsp)
  67132d:	00 
  67132e:	48 83 f8 01          	cmp    $0x1,%rax
  671332:	0f 85 98 02 00 00    	jne    6715d0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1d80>
  671338:	4c 8b b4 24 e0 01 00 	mov    0x1e0(%rsp),%r14
  67133f:	00 
  671340:	4c 3b b4 24 80 00 00 	cmp    0x80(%rsp),%r14
  671347:	00 
  671348:	0f 92 c0             	setb   %al
  67134b:	84 c3                	test   %al,%bl
  67134d:	0f 85 de fd ff ff    	jne    671131 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18e1>
  671353:	48 c7 84 24 d8 01 00 	movq   $0x2,0x1d8(%rsp)
  67135a:	00 02 00 00 00 
  67135f:	31 c9                	xor    %ecx,%ecx
  671361:	4c 39 b4 24 a8 00 00 	cmp    %r14,0xa8(%rsp)
  671368:	00 
  671369:	48 8d 84 24 40 01 00 	lea    0x140(%rsp),%rax
  671370:	00 
  671371:	48 0f 44 c8          	cmove  %rax,%rcx
  671375:	48 8d bc 24 80 02 00 	lea    0x280(%rsp),%rdi
  67137c:	00 
  67137d:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  671382:	4c 89 f2             	mov    %r14,%rdx
  671385:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
  67138b:	45 31 c0             	xor    %r8d,%r8d
  67138e:	ff 15 2c 9c 11 00    	call   *0x119c2c(%rip)        # 78afc0 <_DYNAMIC+0x3d8>
  671394:	48 8d 94 24 b8 03 00 	lea    0x3b8(%rsp),%rdx
  67139b:	00 
  67139c:	4c 89 b4 24 b0 03 00 	mov    %r14,0x3b0(%rsp)
  6713a3:	00 
  6713a4:	48 8b 84 24 c0 02 00 	mov    0x2c0(%rsp),%rax
  6713ab:	00 
  6713ac:	48 89 42 40          	mov    %rax,0x40(%rdx)
  6713b0:	0f 10 84 24 80 02 00 	movups 0x280(%rsp),%xmm0
  6713b7:	00 
  6713b8:	0f 10 8c 24 90 02 00 	movups 0x290(%rsp),%xmm1
  6713bf:	00 
  6713c0:	0f 10 94 24 a0 02 00 	movups 0x2a0(%rsp),%xmm2
  6713c7:	00 
  6713c8:	0f 10 9c 24 b0 02 00 	movups 0x2b0(%rsp),%xmm3
  6713cf:	00 
  6713d0:	0f 11 5a 30          	movups %xmm3,0x30(%rdx)
  6713d4:	0f 11 52 20          	movups %xmm2,0x20(%rdx)
  6713d8:	0f 11 4a 10          	movups %xmm1,0x10(%rdx)
  6713dc:	0f 11 02             	movups %xmm0,(%rdx)
  6713df:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
  6713e4:	4c 89 f6             	mov    %r14,%rsi
  6713e7:	e8 d4 1a 00 00       	call   672ec0 <gpui_canvas::text::planner::append_carets::{closure#1}>
  6713ec:	89 c3                	mov    %eax,%ebx
  6713ee:	83 f8 ff             	cmp    $0xffffffff,%eax
  6713f1:	0f 85 eb fe ff ff    	jne    6712e2 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a92>
  6713f7:	4c 8d bc 24 80 02 00 	lea    0x280(%rsp),%r15
  6713fe:	00 
  6713ff:	48 8b 84 24 d8 01 00 	mov    0x1d8(%rsp),%rax
  671406:	00 
  671407:	48 83 f8 02          	cmp    $0x2,%rax
  67140b:	75 1d                	jne    67142a <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1bda>
  67140d:	48 8d bc 24 e8 01 00 	lea    0x1e8(%rsp),%rdi
  671414:	00 
  671415:	e8 76 6d 01 00       	call   688190 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  67141a:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
  671421:	00 
  671422:	48 89 94 24 e0 01 00 	mov    %rdx,0x1e0(%rsp)
  671429:	00 
  67142a:	48 83 f8 01          	cmp    $0x1,%rax
  67142e:	0f 85 9c 01 00 00    	jne    6715d0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1d80>
  671434:	4c 8b a4 24 e0 01 00 	mov    0x1e0(%rsp),%r12
  67143b:	00 
  67143c:	4d 39 f4             	cmp    %r14,%r12
  67143f:	0f 82 ec fc ff ff    	jb     671131 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18e1>
  671445:	48 c7 84 24 d8 01 00 	movq   $0x2,0x1d8(%rsp)
  67144c:	00 02 00 00 00 
  671451:	4c 39 a4 24 a8 00 00 	cmp    %r12,0xa8(%rsp)
  671458:	00 
  671459:	b9 00 00 00 00       	mov    $0x0,%ecx
  67145e:	48 8d 84 24 40 01 00 	lea    0x140(%rsp),%rax
  671465:	00 
  671466:	48 0f 44 c8          	cmove  %rax,%rcx
  67146a:	4c 89 ff             	mov    %r15,%rdi
  67146d:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  671472:	4c 89 e2             	mov    %r12,%rdx
  671475:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
  67147b:	45 31 c0             	xor    %r8d,%r8d
  67147e:	ff 15 3c 9b 11 00    	call   *0x119b3c(%rip)        # 78afc0 <_DYNAMIC+0x3d8>
  671484:	4c 89 a4 24 b0 03 00 	mov    %r12,0x3b0(%rsp)
  67148b:	00 
  67148c:	48 8b 84 24 c0 02 00 	mov    0x2c0(%rsp),%rax
  671493:	00 
  671494:	48 8d 94 24 b8 03 00 	lea    0x3b8(%rsp),%rdx
  67149b:	00 
  67149c:	48 89 42 40          	mov    %rax,0x40(%rdx)
  6714a0:	0f 10 84 24 80 02 00 	movups 0x280(%rsp),%xmm0
  6714a7:	00 
  6714a8:	0f 10 8c 24 90 02 00 	movups 0x290(%rsp),%xmm1
  6714af:	00 
  6714b0:	0f 10 94 24 a0 02 00 	movups 0x2a0(%rsp),%xmm2
  6714b7:	00 
  6714b8:	0f 10 9c 24 b0 02 00 	movups 0x2b0(%rsp),%xmm3
  6714bf:	00 
  6714c0:	0f 11 5a 30          	movups %xmm3,0x30(%rdx)
  6714c4:	0f 11 52 20          	movups %xmm2,0x20(%rdx)
  6714c8:	0f 11 4a 10          	movups %xmm1,0x10(%rdx)
  6714cc:	0f 11 02             	movups %xmm0,(%rdx)
  6714cf:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
  6714d4:	4c 89 e6             	mov    %r12,%rsi
  6714d7:	e8 e4 19 00 00       	call   672ec0 <gpui_canvas::text::planner::append_carets::{closure#1}>
  6714dc:	89 c3                	mov    %eax,%ebx
  6714de:	4d 89 e6             	mov    %r12,%r14
  6714e1:	83 f8 ff             	cmp    $0xffffffff,%eax
  6714e4:	0f 84 15 ff ff ff    	je     6713ff <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1baf>
  6714ea:	e9 f3 fd ff ff       	jmp    6712e2 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a92>
  6714ef:	4c 8d bc 24 80 02 00 	lea    0x280(%rsp),%r15
  6714f6:	00 
  6714f7:	48 8b 84 24 d8 01 00 	mov    0x1d8(%rsp),%rax
  6714fe:	00 
  6714ff:	48 83 f8 02          	cmp    $0x2,%rax
  671503:	75 1d                	jne    671522 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1cd2>
  671505:	48 8d bc 24 e8 01 00 	lea    0x1e8(%rsp),%rdi
  67150c:	00 
  67150d:	e8 7e 6c 01 00       	call   688190 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  671512:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
  671519:	00 
  67151a:	48 89 94 24 e0 01 00 	mov    %rdx,0x1e0(%rsp)
  671521:	00 
  671522:	48 83 f8 01          	cmp    $0x1,%rax
  671526:	0f 85 a4 00 00 00    	jne    6715d0 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1d80>
  67152c:	4c 8b a4 24 e0 01 00 	mov    0x1e0(%rsp),%r12
  671533:	00 
  671534:	4d 39 f4             	cmp    %r14,%r12
  671537:	0f 82 f4 fb ff ff    	jb     671131 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18e1>
  67153d:	48 c7 84 24 d8 01 00 	movq   $0x2,0x1d8(%rsp)
  671544:	00 02 00 00 00 
  671549:	4c 89 ff             	mov    %r15,%rdi
  67154c:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  671551:	4c 89 e2             	mov    %r12,%rdx
  671554:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
  67155a:	31 c9                	xor    %ecx,%ecx
  67155c:	45 31 c0             	xor    %r8d,%r8d
  67155f:	ff 15 5b 9a 11 00    	call   *0x119a5b(%rip)        # 78afc0 <_DYNAMIC+0x3d8>
  671565:	4c 89 a4 24 b0 03 00 	mov    %r12,0x3b0(%rsp)
  67156c:	00 
  67156d:	48 8b 84 24 c0 02 00 	mov    0x2c0(%rsp),%rax
  671574:	00 
  671575:	4c 89 ea             	mov    %r13,%rdx
  671578:	49 89 45 40          	mov    %rax,0x40(%r13)
  67157c:	0f 10 84 24 80 02 00 	movups 0x280(%rsp),%xmm0
  671583:	00 
  671584:	0f 10 8c 24 90 02 00 	movups 0x290(%rsp),%xmm1
  67158b:	00 
  67158c:	0f 10 94 24 a0 02 00 	movups 0x2a0(%rsp),%xmm2
  671593:	00 
  671594:	0f 10 9c 24 b0 02 00 	movups 0x2b0(%rsp),%xmm3
  67159b:	00 
  67159c:	41 0f 11 5d 30       	movups %xmm3,0x30(%r13)
  6715a1:	41 0f 11 55 20       	movups %xmm2,0x20(%r13)
  6715a6:	41 0f 11 4d 10       	movups %xmm1,0x10(%r13)
  6715ab:	41 0f 11 45 00       	movups %xmm0,0x0(%r13)
  6715b0:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
  6715b5:	4c 89 e6             	mov    %r12,%rsi
  6715b8:	e8 03 19 00 00       	call   672ec0 <gpui_canvas::text::planner::append_carets::{closure#1}>
  6715bd:	89 c3                	mov    %eax,%ebx
  6715bf:	4d 89 e6             	mov    %r12,%r14
  6715c2:	83 f8 ff             	cmp    $0xffffffff,%eax
  6715c5:	0f 84 2c ff ff ff    	je     6714f7 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ca7>
  6715cb:	e9 12 fd ff ff       	jmp    6712e2 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1a92>
  6715d0:	48 8b b4 24 e8 01 00 	mov    0x1e8(%rsp),%rsi
  6715d7:	00 
  6715d8:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
  6715dd:	48 85 f6             	test   %rsi,%rsi
  6715e0:	74 17                	je     6715f9 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1da9>
  6715e2:	48 8b bc 24 f0 01 00 	mov    0x1f0(%rsp),%rdi
  6715e9:	00 
  6715ea:	48 c1 e6 03          	shl    $0x3,%rsi
  6715ee:	ba 08 00 00 00       	mov    $0x8,%edx
  6715f3:	ff 15 27 98 11 00    	call   *0x119827(%rip)        # 78ae20 <_DYNAMIC+0x238>
  6715f9:	48 8b b4 24 d8 00 00 	mov    0xd8(%rsp),%rsi
  671600:	00 
  671601:	48 85 f6             	test   %rsi,%rsi
  671604:	74 17                	je     67161d <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1dcd>
  671606:	48 8b bc 24 e0 00 00 	mov    0xe0(%rsp),%rdi
  67160d:	00 
  67160e:	48 c1 e6 02          	shl    $0x2,%rsi
  671612:	ba 04 00 00 00       	mov    $0x4,%edx
  671617:	ff 15 03 98 11 00    	call   *0x119803(%rip)        # 78ae20 <_DYNAMIC+0x238>
  67161d:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
  671624:	00 
  671625:	48 85 f6             	test   %rsi,%rsi
  671628:	0f 84 15 fc ff ff    	je     671243 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19f3>
  67162e:	48 8b bc 24 08 01 00 	mov    0x108(%rsp),%rdi
  671635:	00 
  671636:	48 c1 e6 03          	shl    $0x3,%rsi
  67163a:	ba 04 00 00 00       	mov    $0x4,%edx
  67163f:	e9 f9 fb ff ff       	jmp    67123d <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x19ed>
  671644:	83 f8 02             	cmp    $0x2,%eax
  671647:	48 8b 6c 24 20       	mov    0x20(%rsp),%rbp
  67164c:	0f 84 9a fa ff ff    	je     6710ec <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x189c>
  671652:	e9 b2 fa ff ff       	jmp    671109 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x18b9>
  671657:	48 8d 0d 22 ef 10 00 	lea    0x10ef22(%rip),%rcx        # 780580 <anon.bf1b5ed00d96edcfb74556a573b7af11.37.llvm.12998622219056141688>
  67165e:	ff 15 dc 9a 11 00    	call   *0x119adc(%rip)        # 78b140 <_DYNAMIC+0x558>
  671664:	e9 31 01 00 00       	jmp    67179a <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f4a>
  671669:	48 8d 0d b8 f0 10 00 	lea    0x10f0b8(%rip),%rcx        # 780728 <anon.31a57d2255aad4ccd38042eb5d4e33a5.19.llvm.6090246580605116548>
  671670:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  671675:	ff 15 c5 9a 11 00    	call   *0x119ac5(%rip)        # 78b140 <_DYNAMIC+0x558>
  67167b:	e9 1a 01 00 00       	jmp    67179a <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f4a>
  671680:	48 8d 3d c5 c6 be ff 	lea    -0x41393b(%rip),%rdi        # 25dd4c <anon.36bd7b0a5b007c0902ea727b9a62c719.4.llvm.11794051326003872033+0x296c>
  671687:	48 8d 15 02 ee 10 00 	lea    0x10ee02(%rip),%rdx        # 780490 <anon.9a0de72a7eba2b0cb10eb2c5cf6d915d.1.llvm.15750432251718107962+0x2a8>
  67168e:	be 21 00 00 00       	mov    $0x21,%esi
  671693:	ff 15 2f 9a 11 00    	call   *0x119a2f(%rip)        # 78b0c8 <_DYNAMIC+0x4e0>
  671699:	e9 fc 00 00 00       	jmp    67179a <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f4a>
  67169e:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6716a3:	48 8d 05 1e ef 10 00 	lea    0x10ef1e(%rip),%rax        # 7805c8 <anon.bf1b5ed00d96edcfb74556a573b7af11.42.llvm.12998622219056141688>
  6716aa:	e9 93 00 00 00       	jmp    671742 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ef2>
  6716af:	41 b7 01             	mov    $0x1,%r15b
  6716b2:	48 8d 15 0f ef 10 00 	lea    0x10ef0f(%rip),%rdx        # 7805c8 <anon.bf1b5ed00d96edcfb74556a573b7af11.42.llvm.12998622219056141688>
  6716b9:	48 8b 6c 24 20       	mov    0x20(%rsp),%rbp
  6716be:	ff 15 84 98 11 00    	call   *0x119884(%rip)        # 78af48 <_DYNAMIC+0x360>
  6716c4:	e9 d1 00 00 00       	jmp    67179a <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f4a>
  6716c9:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
  6716ce:	48 8d 05 33 ee 10 00 	lea    0x10ee33(%rip),%rax        # 780508 <anon.9a0de72a7eba2b0cb10eb2c5cf6d915d.1.llvm.15750432251718107962+0x320>
  6716d5:	eb 6b                	jmp    671742 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ef2>
  6716d7:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
  6716de:	00 
  6716df:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6716e4:	48 8d 05 65 ee 10 00 	lea    0x10ee65(%rip),%rax        # 780550 <anon.9a0de72a7eba2b0cb10eb2c5cf6d915d.1.llvm.15750432251718107962+0x368>
  6716eb:	eb 55                	jmp    671742 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ef2>
  6716ed:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  6716f4:	00 
  6716f5:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6716fa:	48 8d 05 1f ee 10 00 	lea    0x10ee1f(%rip),%rax        # 780520 <anon.9a0de72a7eba2b0cb10eb2c5cf6d915d.1.llvm.15750432251718107962+0x338>
  671701:	eb 3f                	jmp    671742 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ef2>
  671703:	48 8b 84 24 a0 01 00 	mov    0x1a0(%rsp),%rax
  67170a:	00 
  67170b:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  671710:	48 8d 05 21 ee 10 00 	lea    0x10ee21(%rip),%rax        # 780538 <anon.9a0de72a7eba2b0cb10eb2c5cf6d915d.1.llvm.15750432251718107962+0x350>
  671717:	eb 29                	jmp    671742 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ef2>
  671719:	48 8d 05 d0 ed 10 00 	lea    0x10edd0(%rip),%rax        # 7804f0 <anon.9a0de72a7eba2b0cb10eb2c5cf6d915d.1.llvm.15750432251718107962+0x308>
  671720:	eb 20                	jmp    671742 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ef2>
  671722:	4d 89 fd             	mov    %r15,%r13
  671725:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  67172a:	48 8d 05 8f ed 10 00 	lea    0x10ed8f(%rip),%rax        # 7804c0 <anon.9a0de72a7eba2b0cb10eb2c5cf6d915d.1.llvm.15750432251718107962+0x2d8>
  671731:	eb 0f                	jmp    671742 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ef2>
  671733:	49 89 c5             	mov    %rax,%r13
  671736:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  67173b:	48 8d 05 6e ee 10 00 	lea    0x10ee6e(%rip),%rax        # 7805b0 <anon.bf1b5ed00d96edcfb74556a573b7af11.40.llvm.12998622219056141688>
  671742:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  671747:	4c 89 ef             	mov    %r13,%rdi
  67174a:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  67174f:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
  671754:	ff 15 ee 97 11 00    	call   *0x1197ee(%rip)        # 78af48 <_DYNAMIC+0x360>
  67175a:	eb 3e                	jmp    67179a <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f4a>
  67175c:	45 31 ed             	xor    %r13d,%r13d
  67175f:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  671766:	00 00 
  671768:	eb dd                	jmp    671747 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ef7>
  67176a:	48 3b 8c 24 c0 00 00 	cmp    0xc0(%rsp),%rcx
  671771:	00 
  671772:	48 8d 05 5f ed 10 00 	lea    0x10ed5f(%rip),%rax        # 7804d8 <anon.9a0de72a7eba2b0cb10eb2c5cf6d915d.1.llvm.15750432251718107962+0x2f0>
  671779:	48 8d 0d 28 ed 10 00 	lea    0x10ed28(%rip),%rcx        # 7804a8 <anon.9a0de72a7eba2b0cb10eb2c5cf6d915d.1.llvm.15750432251718107962+0x2c0>
  671780:	48 0f 42 c8          	cmovb  %rax,%rcx
  671784:	48 89 8c 24 98 01 00 	mov    %rcx,0x198(%rsp)
  67178b:	00 
  67178c:	48 8b bc 24 98 01 00 	mov    0x198(%rsp),%rdi
  671793:	00 
  671794:	ff 15 86 97 11 00    	call   *0x119786(%rip)        # 78af20 <_DYNAMIC+0x338>
  67179a:	0f 0b                	ud2
  67179c:	48 89 c3             	mov    %rax,%rbx
  67179f:	eb 50                	jmp    6717f1 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1fa1>
  6717a1:	48 89 c3             	mov    %rax,%rbx
  6717a4:	eb 4b                	jmp    6717f1 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1fa1>
  6717a6:	48 89 c3             	mov    %rax,%rbx
  6717a9:	48 8b 6c 24 20       	mov    0x20(%rsp),%rbp
  6717ae:	eb 65                	jmp    671815 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1fc5>
  6717b0:	48 89 c3             	mov    %rax,%rbx
  6717b3:	eb 3c                	jmp    6717f1 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1fa1>
  6717b5:	48 89 c3             	mov    %rax,%rbx
  6717b8:	eb 37                	jmp    6717f1 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1fa1>
  6717ba:	eb 2d                	jmp    6717e9 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f99>
  6717bc:	eb 2b                	jmp    6717e9 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f99>
  6717be:	eb 08                	jmp    6717c8 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f78>
  6717c0:	eb 27                	jmp    6717e9 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f99>
  6717c2:	eb 04                	jmp    6717c8 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f78>
  6717c4:	eb 14                	jmp    6717da <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f8a>
  6717c6:	eb 21                	jmp    6717e9 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f99>
  6717c8:	48 89 c3             	mov    %rax,%rbx
  6717cb:	41 b7 01             	mov    $0x1,%r15b
  6717ce:	eb 76                	jmp    671846 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ff6>
  6717d0:	eb 17                	jmp    6717e9 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f99>
  6717d2:	eb 15                	jmp    6717e9 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f99>
  6717d4:	eb 04                	jmp    6717da <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f8a>
  6717d6:	eb 11                	jmp    6717e9 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f99>
  6717d8:	eb 0f                	jmp    6717e9 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f99>
  6717da:	48 89 c3             	mov    %rax,%rbx
  6717dd:	41 b7 01             	mov    $0x1,%r15b
  6717e0:	48 8b 6c 24 20       	mov    0x20(%rsp),%rbp
  6717e5:	eb 5f                	jmp    671846 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ff6>
  6717e7:	eb 00                	jmp    6717e9 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1f99>
  6717e9:	48 89 c3             	mov    %rax,%rbx
  6717ec:	48 8b 6c 24 20       	mov    0x20(%rsp),%rbp
  6717f1:	48 8b b4 24 e8 01 00 	mov    0x1e8(%rsp),%rsi
  6717f8:	00 
  6717f9:	48 85 f6             	test   %rsi,%rsi
  6717fc:	74 17                	je     671815 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1fc5>
  6717fe:	48 8b bc 24 f0 01 00 	mov    0x1f0(%rsp),%rdi
  671805:	00 
  671806:	48 c1 e6 03          	shl    $0x3,%rsi
  67180a:	ba 08 00 00 00       	mov    $0x8,%edx
  67180f:	ff 15 0b 96 11 00    	call   *0x11960b(%rip)        # 78ae20 <_DYNAMIC+0x238>
  671815:	48 8b b4 24 d8 00 00 	mov    0xd8(%rsp),%rsi
  67181c:	00 
  67181d:	48 85 f6             	test   %rsi,%rsi
  671820:	75 05                	jne    671827 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1fd7>
  671822:	45 31 ff             	xor    %r15d,%r15d
  671825:	eb 1f                	jmp    671846 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ff6>
  671827:	48 8b bc 24 e0 00 00 	mov    0xe0(%rsp),%rdi
  67182e:	00 
  67182f:	48 c1 e6 02          	shl    $0x2,%rsi
  671833:	ba 04 00 00 00       	mov    $0x4,%edx
  671838:	ff 15 e2 95 11 00    	call   *0x1195e2(%rip)        # 78ae20 <_DYNAMIC+0x238>
  67183e:	45 31 ff             	xor    %r15d,%r15d
  671841:	eb 03                	jmp    671846 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x1ff6>
  671843:	48 89 c3             	mov    %rax,%rbx
  671846:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
  67184d:	00 
  67184e:	48 85 f6             	test   %rsi,%rsi
  671851:	74 17                	je     67186a <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x201a>
  671853:	48 8b bc 24 08 01 00 	mov    0x108(%rsp),%rdi
  67185a:	00 
  67185b:	48 c1 e6 03          	shl    $0x3,%rsi
  67185f:	ba 04 00 00 00       	mov    $0x4,%edx
  671864:	ff 15 b6 95 11 00    	call   *0x1195b6(%rip)        # 78ae20 <_DYNAMIC+0x238>
  67186a:	45 84 ff             	test   %r15b,%r15b
  67186d:	74 1c                	je     67188b <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x203b>
  67186f:	48 8b 75 00          	mov    0x0(%rbp),%rsi
  671873:	48 85 f6             	test   %rsi,%rsi
  671876:	74 13                	je     67188b <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>+0x203b>
  671878:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
  67187c:	48 c1 e6 03          	shl    $0x3,%rsi
  671880:	ba 08 00 00 00       	mov    $0x8,%edx
  671885:	ff 15 95 95 11 00    	call   *0x119595(%rip)        # 78ae20 <_DYNAMIC+0x238>
  67188b:	48 89 df             	mov    %rbx,%rdi
  67188e:	e8 9d d5 10 00       	call   77ee30 <_Unwind_Resume@plt>
