
/tmp/gpui-monotonic-control-bin/stream-boundary:     file format elf64-x86-64


Disassembly of section .text:

0000000000673060 <<parley::editing::geometry::CursorGeometry<()>>::boundary_geometries>:
  673060:	55                   	push   %rbp
  673061:	41 57                	push   %r15
  673063:	41 56                	push   %r14
  673065:	41 55                	push   %r13
  673067:	41 54                	push   %r12
  673069:	53                   	push   %rbx
  67306a:	48 81 ec 08 02 00 00 	sub    $0x208,%rsp
  673071:	f3 0f 11 44 24 0c    	movss  %xmm0,0xc(%rsp)
  673077:	49 89 d5             	mov    %rdx,%r13
  67307a:	49 89 f6             	mov    %rsi,%r14
  67307d:	48 89 fb             	mov    %rdi,%rbx
  673080:	48 8d bc 24 e8 00 00 	lea    0xe8(%rsp),%rdi
  673087:	00 
  673088:	e8 e3 02 00 00       	call   673370 <<parley::editing::geometry::CursorGeometry<()>>::cluster>
  67308d:	49 8b 6e 30          	mov    0x30(%r14),%rbp
  673091:	4c 8b bc 24 e8 00 00 	mov    0xe8(%rsp),%r15
  673098:	00 
  673099:	4d 85 ff             	test   %r15,%r15
  67309c:	0f 84 c4 01 00 00    	je     673266 <<parley::editing::geometry::CursorGeometry<()>>::boundary_geometries+0x206>
  6730a2:	8b bc 24 10 01 00 00 	mov    0x110(%rsp),%edi
  6730a9:	49 8b 77 58          	mov    0x58(%r15),%rsi
  6730ad:	48 39 fe             	cmp    %rdi,%rsi
  6730b0:	0f 86 a3 02 00 00    	jbe    673359 <<parley::editing::geometry::CursorGeometry<()>>::boundary_geometries+0x2f9>
  6730b6:	49 8b 47 50          	mov    0x50(%r15),%rax
  6730ba:	48 8d 0c ff          	lea    (%rdi,%rdi,8),%rcx
  6730be:	48 c1 e1 04          	shl    $0x4,%rcx
  6730c2:	41 0f 10 47 68       	movups 0x68(%r15),%xmm0
  6730c7:	41 0f 10 8f 80 00 00 	movups 0x80(%r15),%xmm1
  6730ce:	00 
  6730cf:	41 0f 10 97 98 00 00 	movups 0x98(%r15),%xmm2
  6730d6:	00 
  6730d7:	0f 11 84 24 78 01 00 	movups %xmm0,0x178(%rsp)
  6730de:	00 
  6730df:	0f 11 8c 24 88 01 00 	movups %xmm1,0x188(%rsp)
  6730e6:	00 
  6730e7:	0f 11 94 24 98 01 00 	movups %xmm2,0x198(%rsp)
  6730ee:	00 
  6730ef:	48 8b 44 08 50       	mov    0x50(%rax,%rcx,1),%rax
  6730f4:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
  6730fb:	00 
  6730fc:	8b b4 24 68 01 00 00 	mov    0x168(%rsp),%esi
  673103:	8b 94 24 6c 01 00 00 	mov    0x16c(%rsp),%edx
  67310a:	48 8d bc 24 78 01 00 	lea    0x178(%rsp),%rdi
  673111:	00 
  673112:	ff 15 a8 80 11 00    	call   *0x1180a8(%rip)        # 78b1c0 <_DYNAMIC+0x5d8>
  673118:	48 85 c0             	test   %rax,%rax
  67311b:	41 0f 95 c4          	setne  %r12b
  67311f:	4c 39 e8             	cmp    %r13,%rax
  673122:	0f 85 51 01 00 00    	jne    673279 <<parley::editing::geometry::CursorGeometry<()>>::boundary_geometries+0x219>
  673128:	4d 85 ed             	test   %r13,%r13
  67312b:	0f 84 54 01 00 00    	je     673285 <<parley::editing::geometry::CursorGeometry<()>>::boundary_geometries+0x225>
  673131:	49 8d 55 ff          	lea    -0x1(%r13),%rdx
  673135:	48 89 6c 24 10       	mov    %rbp,0x10(%rsp)
  67313a:	48 8d ac 24 78 01 00 	lea    0x178(%rsp),%rbp
  673141:	00 
  673142:	48 89 ef             	mov    %rbp,%rdi
  673145:	4c 89 f6             	mov    %r14,%rsi
  673148:	e8 23 02 00 00       	call   673370 <<parley::editing::geometry::CursorGeometry<()>>::cluster>
  67314d:	48 8b 84 24 78 01 00 	mov    0x178(%rsp),%rax
  673154:	00 
  673155:	48 85 c0             	test   %rax,%rax
  673158:	48 0f 44 e8          	cmove  %rax,%rbp
  67315c:	4d 85 ff             	test   %r15,%r15
  67315f:	48 8d 84 24 e8 00 00 	lea    0xe8(%rsp),%rax
  673166:	00 
  673167:	49 0f 44 c7          	cmove  %r15,%rax
  67316b:	4c 89 6c 24 18       	mov    %r13,0x18(%rsp)
  673170:	44 88 64 24 20       	mov    %r12b,0x20(%rsp)
  673175:	48 89 ac 24 a0 00 00 	mov    %rbp,0xa0(%rsp)
  67317c:	00 
  67317d:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
  673184:	00 
  673185:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
  67318a:	48 8d 74 24 18       	lea    0x18(%rsp),%rsi
  67318f:	48 8d 8c 24 a0 00 00 	lea    0xa0(%rsp),%rcx
  673196:	00 
  673197:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  67319c:	49 89 d4             	mov    %rdx,%r12
  67319f:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  6731a5:	4d 89 f0             	mov    %r14,%r8
  6731a8:	e8 63 ac 00 00       	call   67de10 <<parley::editing::cursor::Cursor>::geometry_with::<(), <parley::editing::geometry::CursorGeometry<()>>::boundary_geometries::{closure#1}::{closure#0}>>
  6731ad:	4d 85 ff             	test   %r15,%r15
  6731b0:	0f 84 23 01 00 00    	je     6732d9 <<parley::editing::geometry::CursorGeometry<()>>::boundary_geometries+0x279>
  6731b6:	48 8b 84 24 e8 00 00 	mov    0xe8(%rsp),%rax
  6731bd:	00 
  6731be:	8b bc 24 10 01 00 00 	mov    0x110(%rsp),%edi
  6731c5:	48 8b 70 58          	mov    0x58(%rax),%rsi
  6731c9:	48 39 fe             	cmp    %rdi,%rsi
  6731cc:	0f 86 87 01 00 00    	jbe    673359 <<parley::editing::geometry::CursorGeometry<()>>::boundary_geometries+0x2f9>
  6731d2:	48 8b 48 50          	mov    0x50(%rax),%rcx
  6731d6:	48 8d 14 ff          	lea    (%rdi,%rdi,8),%rdx
  6731da:	48 c1 e2 04          	shl    $0x4,%rdx
  6731de:	0f 10 40 68          	movups 0x68(%rax),%xmm0
  6731e2:	0f 10 88 80 00 00 00 	movups 0x80(%rax),%xmm1
  6731e9:	0f 10 90 98 00 00 00 	movups 0x98(%rax),%xmm2
  6731f0:	0f 11 44 24 18       	movups %xmm0,0x18(%rsp)
  6731f5:	0f 11 4c 24 28       	movups %xmm1,0x28(%rsp)
  6731fa:	0f 11 54 24 38       	movups %xmm2,0x38(%rsp)
  6731ff:	48 8b 44 11 50       	mov    0x50(%rcx,%rdx,1),%rax
  673204:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  673209:	8b b4 24 68 01 00 00 	mov    0x168(%rsp),%esi
  673210:	8b 94 24 6c 01 00 00 	mov    0x16c(%rsp),%edx
  673217:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
  67321c:	ff 15 9e 7f 11 00    	call   *0x117f9e(%rip)        # 78b1c0 <_DYNAMIC+0x5d8>
  673222:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  673227:	c6 44 24 78 00       	movb   $0x0,0x78(%rsp)
  67322c:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
  673231:	48 8d 84 24 e8 00 00 	lea    0xe8(%rsp),%rax
  673238:	00 
  673239:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  67323e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
  673245:	00 
  673246:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
  67324b:	48 8d 4c 24 18       	lea    0x18(%rsp),%rcx
  673250:	4c 89 e2             	mov    %r12,%rdx
  673253:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  673259:	4d 89 f0             	mov    %r14,%r8
  67325c:	e8 af ab 00 00       	call   67de10 <<parley::editing::cursor::Cursor>::geometry_with::<(), <parley::editing::geometry::CursorGeometry<()>>::boundary_geometries::{closure#1}::{closure#0}>>
  673261:	e9 8d 00 00 00       	jmp    6732f3 <<parley::editing::geometry::CursorGeometry<()>>::boundary_geometries+0x293>
  673266:	48 8b 85 50 01 00 00 	mov    0x150(%rbp),%rax
  67326d:	41 b4 01             	mov    $0x1,%r12b
  673270:	4c 39 e8             	cmp    %r13,%rax
  673273:	0f 84 af fe ff ff    	je     673128 <<parley::editing::geometry::CursorGeometry<()>>::boundary_geometries+0xc8>
  673279:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
  673280:	e9 bf 00 00 00       	jmp    673344 <<parley::editing::geometry::CursorGeometry<()>>::boundary_geometries+0x2e4>
  673285:	4d 85 ff             	test   %r15,%r15
  673288:	48 8d 84 24 e8 00 00 	lea    0xe8(%rsp),%rax
  67328f:	00 
  673290:	49 0f 44 c7          	cmove  %r15,%rax
  673294:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
  67329b:	00 00 
  67329d:	44 88 64 24 20       	mov    %r12b,0x20(%rsp)
  6732a2:	48 c7 84 24 78 01 00 	movq   $0x0,0x178(%rsp)
  6732a9:	00 00 00 00 00 
  6732ae:	48 89 84 24 80 01 00 	mov    %rax,0x180(%rsp)
  6732b5:	00 
  6732b6:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
  6732bb:	48 8d 74 24 18       	lea    0x18(%rsp),%rsi
  6732c0:	48 8d 8c 24 78 01 00 	lea    0x178(%rsp),%rcx
  6732c7:	00 
  6732c8:	48 89 ea             	mov    %rbp,%rdx
  6732cb:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  6732d1:	4d 89 f0             	mov    %r14,%r8
  6732d4:	e8 37 ab 00 00       	call   67de10 <<parley::editing::cursor::Cursor>::geometry_with::<(), <parley::editing::geometry::CursorGeometry<()>>::boundary_geometries::{closure#1}::{closure#0}>>
  6732d9:	0f 10 44 24 50       	movups 0x50(%rsp),%xmm0
  6732de:	0f 10 4c 24 60       	movups 0x60(%rsp),%xmm1
  6732e3:	0f 29 8c 24 90 00 00 	movaps %xmm1,0x90(%rsp)
  6732ea:	00 
  6732eb:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
  6732f2:	00 
  6732f3:	0f 10 44 24 50       	movups 0x50(%rsp),%xmm0
  6732f8:	0f 10 4c 24 60       	movups 0x60(%rsp),%xmm1
  6732fd:	0f 29 8c 24 b0 00 00 	movaps %xmm1,0xb0(%rsp)
  673304:	00 
  673305:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
  67330c:	00 
  67330d:	0f 28 94 24 80 00 00 	movaps 0x80(%rsp),%xmm2
  673314:	00 
  673315:	0f 28 9c 24 90 00 00 	movaps 0x90(%rsp),%xmm3
  67331c:	00 
  67331d:	0f 29 94 24 c0 00 00 	movaps %xmm2,0xc0(%rsp)
  673324:	00 
  673325:	0f 29 9c 24 d0 00 00 	movaps %xmm3,0xd0(%rsp)
  67332c:	00 
  67332d:	0f 11 5b 38          	movups %xmm3,0x38(%rbx)
  673331:	0f 11 53 28          	movups %xmm2,0x28(%rbx)
  673335:	0f 11 4b 18          	movups %xmm1,0x18(%rbx)
  673339:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
  67333d:	48 c7 03 01 00 00 00 	movq   $0x1,(%rbx)
  673344:	48 89 d8             	mov    %rbx,%rax
  673347:	48 81 c4 08 02 00 00 	add    $0x208,%rsp
  67334e:	5b                   	pop    %rbx
  67334f:	41 5c                	pop    %r12
  673351:	41 5d                	pop    %r13
  673353:	41 5e                	pop    %r14
  673355:	41 5f                	pop    %r15
  673357:	5d                   	pop    %rbp
  673358:	c3                   	ret
  673359:	48 8d 15 68 d2 10 00 	lea    0x10d268(%rip),%rdx        # 7805c8 <anon.bf1b5ed00d96edcfb74556a573b7af11.42.llvm.12998622219056141688>
  673360:	ff 15 e2 7b 11 00    	call   *0x117be2(%rip)        # 78af48 <_DYNAMIC+0x360>
