
/tmp/gpui-monotonic-control-bin/stream-boundary:     file format elf64-x86-64


Disassembly of section .text:

000000000066ac90 <<gpui_canvas::text::planner::Planner>::shape>:
  66ac90:	55                   	push   %rbp
  66ac91:	41 57                	push   %r15
  66ac93:	41 56                	push   %r14
  66ac95:	41 55                	push   %r13
  66ac97:	41 54                	push   %r12
  66ac99:	53                   	push   %rbx
  66ac9a:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
  66aca1:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
  66aca8:	00 
  66aca9:	48 81 ec e8 01 00 00 	sub    $0x1e8,%rsp
  66acb0:	44 89 8c 24 2c 02 00 	mov    %r9d,0x22c(%rsp)
  66acb7:	00 
  66acb8:	f3 0f 11 8c 24 cc 01 	movss  %xmm1,0x1cc(%rsp)
  66acbf:	00 00 
  66acc1:	44 89 84 24 c8 01 00 	mov    %r8d,0x1c8(%rsp)
  66acc8:	00 
  66acc9:	f3 0f 11 84 24 84 00 	movss  %xmm0,0x84(%rsp)
  66acd0:	00 00 
  66acd2:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
  66acd7:	49 89 f5             	mov    %rsi,%r13
  66acda:	48 89 bc 24 38 03 00 	mov    %rdi,0x338(%rsp)
  66ace1:	00 
  66ace2:	4c 8d 24 0a          	lea    (%rdx,%rcx,1),%r12
  66ace6:	48 85 c9             	test   %rcx,%rcx
  66ace9:	48 89 34 24          	mov    %rsi,(%rsp)
  66aced:	48 89 94 24 48 01 00 	mov    %rdx,0x148(%rsp)
  66acf4:	00 
  66acf5:	4c 89 a4 24 b0 01 00 	mov    %r12,0x1b0(%rsp)
  66acfc:	00 
  66acfd:	0f 84 90 03 00 00    	je     66b093 <<gpui_canvas::text::planner::Planner>::shape+0x403>
  66ad03:	49 8d 85 78 0a 00 00 	lea    0xa78(%r13),%rax
  66ad0a:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  66ad0f:	48 8d b4 24 ec 0c 00 	lea    0xcec(%rsp),%rsi
  66ad16:	00 
  66ad17:	49 8d 45 38          	lea    0x38(%r13),%rax
  66ad1b:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  66ad20:	49 8d 45 3c          	lea    0x3c(%r13),%rax
  66ad24:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  66ad2b:	00 
  66ad2c:	49 8d 45 58          	lea    0x58(%r13),%rax
  66ad30:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
  66ad37:	00 
  66ad38:	49 8d 45 5c          	lea    0x5c(%r13),%rax
  66ad3c:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  66ad41:	45 31 ff             	xor    %r15d,%r15d
  66ad44:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  66ad4b:	00 
  66ad4c:	4c 8b 05 b5 02 12 00 	mov    0x1202b5(%rip),%r8        # 78b008 <_DYNAMIC+0x420>
  66ad53:	49 89 d6             	mov    %rdx,%r14
  66ad56:	44 89 7c 24 30       	mov    %r15d,0x30(%rsp)
  66ad5b:	eb 1c                	jmp    66ad79 <<gpui_canvas::text::planner::Planner>::shape+0xe9>
  66ad5d:	0f 1f 00             	nopl   (%rax)
  66ad60:	41 8d 87 d8 df ff ff 	lea    -0x2028(%r15),%eax
  66ad67:	83 f8 02             	cmp    $0x2,%eax
  66ad6a:	0f 83 e1 00 00 00    	jae    66ae51 <<gpui_canvas::text::planner::Planner>::shape+0x1c1>
  66ad70:	4d 39 e6             	cmp    %r12,%r14
  66ad73:	0f 84 ba 02 00 00    	je     66b033 <<gpui_canvas::text::planner::Planner>::shape+0x3a3>
  66ad79:	45 0f b6 3e          	movzbl (%r14),%r15d
  66ad7d:	45 84 ff             	test   %r15b,%r15b
  66ad80:	78 1e                	js     66ada0 <<gpui_canvas::text::planner::Planner>::shape+0x110>
  66ad82:	49 ff c6             	inc    %r14
  66ad85:	41 81 ff 27 20 00 00 	cmp    $0x2027,%r15d
  66ad8c:	0f 8e 9e 00 00 00    	jle    66ae30 <<gpui_canvas::text::planner::Planner>::shape+0x1a0>
  66ad92:	eb cc                	jmp    66ad60 <<gpui_canvas::text::planner::Planner>::shape+0xd0>
  66ad94:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  66ad9b:	00 00 00 00 00 
  66ada0:	44 89 f8             	mov    %r15d,%eax
  66ada3:	83 e0 1f             	and    $0x1f,%eax
  66ada6:	41 0f b6 56 01       	movzbl 0x1(%r14),%edx
  66adab:	83 e2 3f             	and    $0x3f,%edx
  66adae:	41 80 ff df          	cmp    $0xdf,%r15b
  66adb2:	76 3d                	jbe    66adf1 <<gpui_canvas::text::planner::Planner>::shape+0x161>
  66adb4:	41 0f b6 4e 02       	movzbl 0x2(%r14),%ecx
  66adb9:	c1 e2 06             	shl    $0x6,%edx
  66adbc:	83 e1 3f             	and    $0x3f,%ecx
  66adbf:	09 d1                	or     %edx,%ecx
  66adc1:	41 80 ff f0          	cmp    $0xf0,%r15b
  66adc5:	72 44                	jb     66ae0b <<gpui_canvas::text::planner::Planner>::shape+0x17b>
  66adc7:	45 0f b6 7e 03       	movzbl 0x3(%r14),%r15d
  66adcc:	49 83 c6 04          	add    $0x4,%r14
  66add0:	83 e0 07             	and    $0x7,%eax
  66add3:	c1 e0 12             	shl    $0x12,%eax
  66add6:	c1 e1 06             	shl    $0x6,%ecx
  66add9:	41 83 e7 3f          	and    $0x3f,%r15d
  66addd:	41 09 cf             	or     %ecx,%r15d
  66ade0:	41 09 c7             	or     %eax,%r15d
  66ade3:	41 81 ff 27 20 00 00 	cmp    $0x2027,%r15d
  66adea:	7e 44                	jle    66ae30 <<gpui_canvas::text::planner::Planner>::shape+0x1a0>
  66adec:	e9 6f ff ff ff       	jmp    66ad60 <<gpui_canvas::text::planner::Planner>::shape+0xd0>
  66adf1:	49 83 c6 02          	add    $0x2,%r14
  66adf5:	c1 e0 06             	shl    $0x6,%eax
  66adf8:	09 d0                	or     %edx,%eax
  66adfa:	41 89 c7             	mov    %eax,%r15d
  66adfd:	41 81 ff 27 20 00 00 	cmp    $0x2027,%r15d
  66ae04:	7e 2a                	jle    66ae30 <<gpui_canvas::text::planner::Planner>::shape+0x1a0>
  66ae06:	e9 55 ff ff ff       	jmp    66ad60 <<gpui_canvas::text::planner::Planner>::shape+0xd0>
  66ae0b:	49 83 c6 03          	add    $0x3,%r14
  66ae0f:	c1 e0 0c             	shl    $0xc,%eax
  66ae12:	09 c1                	or     %eax,%ecx
  66ae14:	41 89 cf             	mov    %ecx,%r15d
  66ae17:	41 81 ff 27 20 00 00 	cmp    $0x2027,%r15d
  66ae1e:	0f 8f 3c ff ff ff    	jg     66ad60 <<gpui_canvas::text::planner::Planner>::shape+0xd0>
  66ae24:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  66ae2b:	00 00 00 00 00 
  66ae30:	41 83 ff 0a          	cmp    $0xa,%r15d
  66ae34:	0f 84 36 ff ff ff    	je     66ad70 <<gpui_canvas::text::planner::Planner>::shape+0xe0>
  66ae3a:	41 83 ff 0d          	cmp    $0xd,%r15d
  66ae3e:	0f 84 2c ff ff ff    	je     66ad70 <<gpui_canvas::text::planner::Planner>::shape+0xe0>
  66ae44:	41 81 ff 85 00 00 00 	cmp    $0x85,%r15d
  66ae4b:	0f 84 1f ff ff ff    	je     66ad70 <<gpui_canvas::text::planner::Planner>::shape+0xe0>
  66ae51:	49 89 fd             	mov    %rdi,%r13
  66ae54:	48 8d 3d ad 53 11 00 	lea    0x1153ad(%rip),%rdi        # 780208 <anon.9a0de72a7eba2b0cb10eb2c5cf6d915d.1.llvm.15750432251718107962+0x20>
  66ae5b:	48 89 f3             	mov    %rsi,%rbx
  66ae5e:	44 89 fe             	mov    %r15d,%esi
  66ae61:	4c 89 c5             	mov    %r8,%rbp
  66ae64:	ff 15 4e 03 12 00    	call   *0x12034e(%rip)        # 78b1b8 <_DYNAMIC+0x5d0>
  66ae6a:	49 89 e8             	mov    %rbp,%r8
  66ae6d:	4c 89 ef             	mov    %r13,%rdi
  66ae70:	48 89 de             	mov    %rbx,%rsi
  66ae73:	84 c0                	test   %al,%al
  66ae75:	0f 85 f5 fe ff ff    	jne    66ad70 <<gpui_canvas::text::planner::Planner>::shape+0xe0>
  66ae7b:	41 bc 0a 00 00 00    	mov    $0xa,%r12d
  66ae81:	41 83 ff 20          	cmp    $0x20,%r15d
  66ae85:	0f 82 5b 02 00 00    	jb     66b0e6 <<gpui_canvas::text::planner::Planner>::shape+0x456>
  66ae8b:	41 8d 47 81          	lea    -0x7f(%r15),%eax
  66ae8f:	83 f8 21             	cmp    $0x21,%eax
  66ae92:	0f 82 4e 02 00 00    	jb     66b0e6 <<gpui_canvas::text::planner::Planner>::shape+0x456>
  66ae98:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  66ae9d:	44 89 fe             	mov    %r15d,%esi
  66aea0:	e8 cb 3b 00 00       	call   66ea70 <<gpui_canvas::text::planner::Cmap>::glyph_index>
  66aea5:	49 89 e8             	mov    %rbp,%r8
  66aea8:	4c 89 ef             	mov    %r13,%rdi
  66aeab:	a8 01                	test   $0x1,%al
  66aead:	4c 8b a4 24 b0 01 00 	mov    0x1b0(%rsp),%r12
  66aeb4:	00 
  66aeb5:	74 0c                	je     66aec3 <<gpui_canvas::text::planner::Planner>::shape+0x233>
  66aeb7:	48 89 de             	mov    %rbx,%rsi
  66aeba:	66 85 d2             	test   %dx,%dx
  66aebd:	0f 85 ad fe ff ff    	jne    66ad70 <<gpui_canvas::text::planner::Planner>::shape+0xe0>
  66aec3:	48 8b 0c 24          	mov    (%rsp),%rcx
  66aec7:	48 8b 81 40 0a 00 00 	mov    0xa40(%rcx),%rax
  66aece:	41 bc 0b 00 00 00    	mov    $0xb,%r12d
  66aed4:	80 78 38 01          	cmpb   $0x1,0x38(%rax)
  66aed8:	0f 85 08 02 00 00    	jne    66b0e6 <<gpui_canvas::text::planner::Planner>::shape+0x456>
  66aede:	48 83 79 30 00       	cmpq   $0x0,0x30(%rcx)
  66aee3:	0f 85 e9 00 00 00    	jne    66afd2 <<gpui_canvas::text::planner::Planner>::shape+0x342>
  66aee9:	ba 48 ab 03 00       	mov    $0x3ab48,%edx
  66aeee:	48 8d 35 47 ac 9b ff 	lea    -0x6453b9(%rip),%rsi        # 25b3c <gpui_canvas::text::ARABIC_BYTES>
  66aef5:	31 c9                	xor    %ecx,%ecx
  66aef7:	41 ff d0             	call   *%r8
  66aefa:	83 bc 24 10 07 00 00 	cmpl   $0xffffffff,0x710(%rsp)
  66af01:	ff 
  66af02:	0f 84 8d 2f 00 00    	je     66de95 <<gpui_canvas::text::planner::Planner>::shape+0x3205>
  66af08:	8b 84 24 e8 0c 00 00 	mov    0xce8(%rsp),%eax
  66af0f:	89 44 24 08          	mov    %eax,0x8(%rsp)
  66af13:	0f 10 03             	movups (%rbx),%xmm0
  66af16:	0f 10 4b 0c          	movups 0xc(%rbx),%xmm1
  66af1a:	0f 29 84 24 c0 04 00 	movaps %xmm0,0x4c0(%rsp)
  66af21:	00 
  66af22:	0f 11 8c 24 cc 04 00 	movups %xmm1,0x4cc(%rsp)
  66af29:	00 
  66af2a:	ba 14 69 00 00       	mov    $0x6914,%edx
  66af2f:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  66af36:	00 
  66af37:	48 8d 35 46 57 9f ff 	lea    -0x60a8ba(%rip),%rsi        # 60684 <gpui_canvas::text::HEBREW_BYTES>
  66af3e:	31 c9                	xor    %ecx,%ecx
  66af40:	ff 15 c2 00 12 00    	call   *0x1200c2(%rip)        # 78b008 <_DYNAMIC+0x420>
  66af46:	83 bc 24 10 07 00 00 	cmpl   $0xffffffff,0x710(%rsp)
  66af4d:	ff 
  66af4e:	0f 84 53 2f 00 00    	je     66dea7 <<gpui_canvas::text::planner::Planner>::shape+0x3217>
  66af54:	8b 94 24 e8 0c 00 00 	mov    0xce8(%rsp),%edx
  66af5b:	48 8d 84 24 ec 0c 00 	lea    0xcec(%rsp),%rax
  66af62:	00 
  66af63:	0f 10 00             	movups (%rax),%xmm0
  66af66:	0f 10 48 0c          	movups 0xc(%rax),%xmm1
  66af6a:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
  66af71:	00 
  66af72:	0f 11 8c 24 4c 03 00 	movups %xmm1,0x34c(%rsp)
  66af79:	00 
  66af7a:	48 8b 04 24          	mov    (%rsp),%rax
  66af7e:	48 c7 40 30 01 00 00 	movq   $0x1,0x30(%rax)
  66af85:	00 
  66af86:	8b 4c 24 08          	mov    0x8(%rsp),%ecx
  66af8a:	89 48 38             	mov    %ecx,0x38(%rax)
  66af8d:	0f 10 84 24 cc 04 00 	movups 0x4cc(%rsp),%xmm0
  66af94:	00 
  66af95:	48 8b 8c 24 00 01 00 	mov    0x100(%rsp),%rcx
  66af9c:	00 
  66af9d:	0f 11 41 0c          	movups %xmm0,0xc(%rcx)
  66afa1:	0f 28 84 24 c0 04 00 	movaps 0x4c0(%rsp),%xmm0
  66afa8:	00 
  66afa9:	0f 11 01             	movups %xmm0,(%rcx)
  66afac:	89 94 24 d0 01 00 00 	mov    %edx,0x1d0(%rsp)
  66afb3:	89 50 58             	mov    %edx,0x58(%rax)
  66afb6:	0f 10 84 24 4c 03 00 	movups 0x34c(%rsp),%xmm0
  66afbd:	00 
  66afbe:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  66afc3:	0f 11 40 0c          	movups %xmm0,0xc(%rax)
  66afc7:	0f 28 84 24 40 03 00 	movaps 0x340(%rsp),%xmm0
  66afce:	00 
  66afcf:	0f 11 00             	movups %xmm0,(%rax)
  66afd2:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
  66afd7:	44 89 fe             	mov    %r15d,%esi
  66afda:	e8 91 3a 00 00       	call   66ea70 <<gpui_canvas::text::planner::Cmap>::glyph_index>
  66afdf:	66 85 d2             	test   %dx,%dx
  66afe2:	0f 95 c1             	setne  %cl
  66afe5:	20 c1                	and    %al,%cl
  66afe7:	88 4c 24 60          	mov    %cl,0x60(%rsp)
  66afeb:	48 8b bc 24 10 01 00 	mov    0x110(%rsp),%rdi
  66aff2:	00 
  66aff3:	44 89 fe             	mov    %r15d,%esi
  66aff6:	e8 75 3a 00 00       	call   66ea70 <<gpui_canvas::text::planner::Cmap>::glyph_index>
  66affb:	66 85 d2             	test   %dx,%dx
  66affe:	0f 95 c1             	setne  %cl
  66b001:	20 c1                	and    %al,%cl
  66b003:	00 c9                	add    %cl,%cl
  66b005:	0a 4c 24 60          	or     0x60(%rsp),%cl
  66b009:	0f 84 d7 00 00 00    	je     66b0e6 <<gpui_canvas::text::planner::Planner>::shape+0x456>
  66b00f:	44 8b 7c 24 30       	mov    0x30(%rsp),%r15d
  66b014:	41 08 cf             	or     %cl,%r15b
  66b017:	4c 8b a4 24 b0 01 00 	mov    0x1b0(%rsp),%r12
  66b01e:	00 
  66b01f:	4d 39 e6             	cmp    %r12,%r14
  66b022:	48 89 de             	mov    %rbx,%rsi
  66b025:	4c 89 ef             	mov    %r13,%rdi
  66b028:	49 89 e8             	mov    %rbp,%r8
  66b02b:	0f 85 25 fd ff ff    	jne    66ad56 <<gpui_canvas::text::planner::Planner>::shape+0xc6>
  66b031:	eb 05                	jmp    66b038 <<gpui_canvas::text::planner::Planner>::shape+0x3a8>
  66b033:	44 8b 7c 24 30       	mov    0x30(%rsp),%r15d
  66b038:	41 f6 c7 01          	test   $0x1,%r15b
  66b03c:	4c 8b 2c 24          	mov    (%rsp),%r13
  66b040:	0f 84 c5 00 00 00    	je     66b10b <<gpui_canvas::text::planner::Planner>::shape+0x47b>
  66b046:	49 83 bd 48 0a 00 00 	cmpq   $0x0,0xa48(%r13)
  66b04d:	00 
  66b04e:	0f 85 b7 00 00 00    	jne    66b10b <<gpui_canvas::text::planner::Planner>::shape+0x47b>
  66b054:	48 8d 35 0d 2e 12 00 	lea    0x122e0d(%rip),%rsi        # 78de68 <gpui_canvas::text::ARABIC_FONT>
  66b05b:	48 8d 15 da aa 9b ff 	lea    -0x645526(%rip),%rdx        # 25b3c <gpui_canvas::text::ARABIC_BYTES>
  66b062:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  66b069:	00 
  66b06a:	b9 48 ab 03 00       	mov    $0x3ab48,%ecx
  66b06f:	45 31 c0             	xor    %r8d,%r8d
  66b072:	e8 b9 8f ff ff       	call   664030 <<gpui_canvas::text::FontFace>::shared_static>
  66b077:	83 bc 24 10 07 00 00 	cmpl   $0x1,0x710(%rsp)
  66b07e:	01 
  66b07f:	75 1a                	jne    66b09b <<gpui_canvas::text::planner::Planner>::shape+0x40b>
  66b081:	44 8b a4 24 14 07 00 	mov    0x714(%rsp),%r12d
  66b088:	00 
  66b089:	44 8b bc 24 18 07 00 	mov    0x718(%rsp),%r15d
  66b090:	00 
  66b091:	eb 53                	jmp    66b0e6 <<gpui_canvas::text::planner::Planner>::shape+0x456>
  66b093:	45 31 ff             	xor    %r15d,%r15d
  66b096:	e9 84 00 00 00       	jmp    66b11f <<gpui_canvas::text::planner::Planner>::shape+0x48f>
  66b09b:	44 89 fd             	mov    %r15d,%ebp
  66b09e:	49 8d 9d 48 0a 00 00 	lea    0xa48(%r13),%rbx
  66b0a5:	4c 8b bc 24 18 07 00 	mov    0x718(%rsp),%r15
  66b0ac:	00 
  66b0ad:	48 8b 03             	mov    (%rbx),%rax
  66b0b0:	48 85 c0             	test   %rax,%rax
  66b0b3:	74 0f                	je     66b0c4 <<gpui_canvas::text::planner::Planner>::shape+0x434>
  66b0b5:	f0 48 ff 08          	lock decq (%rax)
  66b0b9:	75 09                	jne    66b0c4 <<gpui_canvas::text::planner::Planner>::shape+0x434>
  66b0bb:	48 89 df             	mov    %rbx,%rdi
  66b0be:	ff 15 84 fd 11 00    	call   *0x11fd84(%rip)        # 78ae48 <_DYNAMIC+0x260>
  66b0c4:	4d 89 bd 48 0a 00 00 	mov    %r15,0xa48(%r13)
  66b0cb:	be 01 00 00 00       	mov    $0x1,%esi
  66b0d0:	4c 89 ef             	mov    %r13,%rdi
  66b0d3:	e8 98 36 00 00       	call   66e770 <<gpui_canvas::text::planner::Planner>::register>
  66b0d8:	83 f8 ff             	cmp    $0xffffffff,%eax
  66b0db:	41 89 ef             	mov    %ebp,%r15d
  66b0de:	74 2b                	je     66b10b <<gpui_canvas::text::planner::Planner>::shape+0x47b>
  66b0e0:	41 89 c4             	mov    %eax,%r12d
  66b0e3:	45 31 ff             	xor    %r15d,%r15d
  66b0e6:	44 89 a4 24 90 00 00 	mov    %r12d,0x90(%rsp)
  66b0ed:	00 
  66b0ee:	44 89 bc 24 94 00 00 	mov    %r15d,0x94(%rsp)
  66b0f5:	00 
  66b0f6:	48 c7 84 24 88 00 00 	movq   $0xffffffffffffffff,0x88(%rsp)
  66b0fd:	00 ff ff ff ff 
  66b102:	4c 8b 2c 24          	mov    (%rsp),%r13
  66b106:	e9 b6 28 00 00       	jmp    66d9c1 <<gpui_canvas::text::planner::Planner>::shape+0x2d31>
  66b10b:	41 f6 c7 02          	test   $0x2,%r15b
  66b10f:	74 0e                	je     66b11f <<gpui_canvas::text::planner::Planner>::shape+0x48f>
  66b111:	49 83 bd 50 0a 00 00 	cmpq   $0x0,0xa50(%r13)
  66b118:	00 
  66b119:	0f 84 3f 2a 00 00    	je     66db5e <<gpui_canvas::text::planner::Planner>::shape+0x2ece>
  66b11f:	48 c7 84 24 a0 02 00 	movq   $0xffffffffffffffff,0x2a0(%rsp)
  66b126:	00 ff ff ff ff 
  66b12b:	48 8d 05 74 03 bf ff 	lea    -0x40fc8c(%rip),%rax        # 25b4a6 <anon.36bd7b0a5b007c0902ea727b9a62c719.4.llvm.11794051326003872033+0xc6>
  66b132:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
  66b139:	00 
  66b13a:	48 c7 84 24 b0 02 00 	movq   $0xc,0x2b0(%rsp)
  66b141:	00 0c 00 00 00 
  66b146:	48 c7 84 24 b8 02 00 	movq   $0xffffffffffffffff,0x2b8(%rsp)
  66b14d:	00 ff ff ff ff 
  66b152:	48 8d 05 59 03 bf ff 	lea    -0x40fca7(%rip),%rax        # 25b4b2 <anon.36bd7b0a5b007c0902ea727b9a62c719.4.llvm.11794051326003872033+0xd2>
  66b159:	48 89 84 24 c0 02 00 	mov    %rax,0x2c0(%rsp)
  66b160:	00 
  66b161:	48 c7 84 24 c8 02 00 	movq   $0x11,0x2c8(%rsp)
  66b168:	00 11 00 00 00 
  66b16d:	48 c7 84 24 d0 02 00 	movq   $0xffffffffffffffff,0x2d0(%rsp)
  66b174:	00 ff ff ff ff 
  66b179:	48 8d 1d 43 03 bf ff 	lea    -0x40fcbd(%rip),%rbx        # 25b4c3 <anon.36bd7b0a5b007c0902ea727b9a62c719.4.llvm.11794051326003872033+0xe3>
  66b180:	48 89 9c 24 d8 02 00 	mov    %rbx,0x2d8(%rsp)
  66b187:	00 
  66b188:	48 c7 84 24 e0 02 00 	movq   $0x11,0x2e0(%rsp)
  66b18f:	00 11 00 00 00 
  66b194:	41 f6 c7 01          	test   $0x1,%r15b
  66b198:	75 1d                	jne    66b1b7 <<gpui_canvas::text::planner::Planner>::shape+0x527>
  66b19a:	4c 8d b4 24 b8 02 00 	lea    0x2b8(%rsp),%r14
  66b1a1:	00 
  66b1a2:	b8 01 00 00 00       	mov    $0x1,%eax
  66b1a7:	48 89 84 24 10 02 00 	mov    %rax,0x210(%rsp)
  66b1ae:	00 
  66b1af:	41 f6 c7 02          	test   $0x2,%r15b
  66b1b3:	75 25                	jne    66b1da <<gpui_canvas::text::planner::Planner>::shape+0x54a>
  66b1b5:	eb 5b                	jmp    66b212 <<gpui_canvas::text::planner::Planner>::shape+0x582>
  66b1b7:	4c 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%r14
  66b1be:	00 
  66b1bf:	48 89 84 24 c0 02 00 	mov    %rax,0x2c0(%rsp)
  66b1c6:	00 
  66b1c7:	b8 02 00 00 00       	mov    $0x2,%eax
  66b1cc:	48 89 84 24 10 02 00 	mov    %rax,0x210(%rsp)
  66b1d3:	00 
  66b1d4:	41 f6 c7 02          	test   $0x2,%r15b
  66b1d8:	74 38                	je     66b212 <<gpui_canvas::text::planner::Planner>::shape+0x582>
  66b1da:	49 8b 36             	mov    (%r14),%rsi
  66b1dd:	48 83 fe fd          	cmp    $0xfffffffffffffffd,%rsi
  66b1e1:	77 14                	ja     66b1f7 <<gpui_canvas::text::planner::Planner>::shape+0x567>
  66b1e3:	48 85 f6             	test   %rsi,%rsi
  66b1e6:	74 0f                	je     66b1f7 <<gpui_canvas::text::planner::Planner>::shape+0x567>
  66b1e8:	49 8b 7e 08          	mov    0x8(%r14),%rdi
  66b1ec:	ba 01 00 00 00       	mov    $0x1,%edx
  66b1f1:	ff 15 29 fc 11 00    	call   *0x11fc29(%rip)        # 78ae20 <_DYNAMIC+0x238>
  66b1f7:	49 c7 06 ff ff ff ff 	movq   $0xffffffffffffffff,(%r14)
  66b1fe:	49 89 5e 08          	mov    %rbx,0x8(%r14)
  66b202:	49 c7 46 10 11 00 00 	movq   $0x11,0x10(%r14)
  66b209:	00 
  66b20a:	48 ff 84 24 10 02 00 	incq   0x210(%rsp)
  66b211:	00 
  66b212:	48 c7 84 24 e8 00 00 	movq   $0x0,0xe8(%rsp)
  66b219:	00 00 00 00 00 
  66b21e:	48 c7 84 24 f0 00 00 	movq   $0x4,0xf0(%rsp)
  66b225:	00 04 00 00 00 
  66b22a:	48 c7 84 24 f8 00 00 	movq   $0x0,0xf8(%rsp)
  66b231:	00 00 00 00 00 
  66b236:	48 c7 84 24 50 01 00 	movq   $0xffffffffffffffff,0x150(%rsp)
  66b23d:	00 ff ff ff ff 
  66b242:	f6 84 24 c8 01 00 00 	testb  $0x1,0x1c8(%rsp)
  66b249:	01 
  66b24a:	75 11                	jne    66b25d <<gpui_canvas::text::planner::Planner>::shape+0x5cd>
  66b24c:	f3 0f 10 05 38 26 9b 	movss  -0x64d9c8(%rip),%xmm0        # 1d88c <GCC_except_table0+0x8c>
  66b253:	ff 
  66b254:	f3 0f 11 84 24 cc 01 	movss  %xmm0,0x1cc(%rsp)
  66b25b:	00 00 
  66b25d:	49 8d 45 78          	lea    0x78(%r13),%rax
  66b261:	48 89 84 24 30 03 00 	mov    %rax,0x330(%rsp)
  66b268:	00 
  66b269:	49 8d 85 38 06 00 00 	lea    0x638(%r13),%rax
  66b270:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
  66b277:	00 
  66b278:	49 8d 85 c8 08 00 00 	lea    0x8c8(%r13),%rax
  66b27f:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  66b284:	4c 8d ac 24 50 03 00 	lea    0x350(%rsp),%r13
  66b28b:	00 
  66b28c:	0f 57 c0             	xorps  %xmm0,%xmm0
  66b28f:	0f 29 84 24 80 02 00 	movaps %xmm0,0x280(%rsp)
  66b296:	00 
  66b297:	f3 0f 11 44 24 1c    	movss  %xmm0,0x1c(%rsp)
  66b29d:	f3 0f 11 44 24 7c    	movss  %xmm0,0x7c(%rsp)
  66b2a3:	4c 8d a4 24 c8 04 00 	lea    0x4c8(%rsp),%r12
  66b2aa:	00 
  66b2ab:	48 8d 05 96 50 11 00 	lea    0x115096(%rip),%rax        # 780348 <anon.9a0de72a7eba2b0cb10eb2c5cf6d915d.1.llvm.15750432251718107962+0x160>
  66b2b2:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  66b2b7:	48 8d 05 aa 52 11 00 	lea    0x1152aa(%rip),%rax        # 780568 <anon.bf1b5ed00d96edcfb74556a573b7af11.35.llvm.12998622219056141688>
  66b2be:	48 89 84 24 70 02 00 	mov    %rax,0x270(%rsp)
  66b2c5:	00 
  66b2c6:	48 c7 84 24 08 02 00 	movq   $0x0,0x208(%rsp)
  66b2cd:	00 00 00 00 00 
  66b2d2:	31 d2                	xor    %edx,%edx
  66b2d4:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  66b2db:	00 
  66b2dc:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  66b2e1:	31 c0                	xor    %eax,%eax
  66b2e3:	be fe ff ff ff       	mov    $0xfffffffe,%esi
  66b2e8:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
  66b2ed:	83 fe fe             	cmp    $0xfffffffe,%esi
  66b2f0:	75 2e                	jne    66b320 <<gpui_canvas::text::planner::Planner>::shape+0x690>
  66b2f2:	4c 8b 4c 24 28       	mov    0x28(%rsp),%r9
  66b2f7:	4c 3b 8c 24 b0 01 00 	cmp    0x1b0(%rsp),%r9
  66b2fe:	00 
  66b2ff:	74 33                	je     66b334 <<gpui_canvas::text::planner::Planner>::shape+0x6a4>
  66b301:	41 0f b6 09          	movzbl (%r9),%ecx
  66b305:	84 c9                	test   %cl,%cl
  66b307:	78 46                	js     66b34f <<gpui_canvas::text::planner::Planner>::shape+0x6bf>
  66b309:	49 8d 51 01          	lea    0x1(%r9),%rdx
  66b30d:	e9 9a 00 00 00       	jmp    66b3ac <<gpui_canvas::text::planner::Planner>::shape+0x71c>
  66b312:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  66b319:	1f 84 00 00 00 00 00 
  66b320:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
  66b325:	89 f1                	mov    %esi,%ecx
  66b327:	4c 8b 84 24 10 03 00 	mov    0x310(%rsp),%r8
  66b32e:	00 
  66b32f:	e9 81 00 00 00       	jmp    66b3b5 <<gpui_canvas::text::planner::Planner>::shape+0x725>
  66b334:	c7 84 24 80 00 00 00 	movl   $0xfffffffe,0x80(%rsp)
  66b33b:	fe ff ff ff 
  66b33f:	b1 01                	mov    $0x1,%cl
  66b341:	89 4c 24 4c          	mov    %ecx,0x4c(%rsp)
  66b345:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
  66b34a:	e9 d7 01 00 00       	jmp    66b526 <<gpui_canvas::text::planner::Planner>::shape+0x896>
  66b34f:	49 89 c0             	mov    %rax,%r8
  66b352:	89 c8                	mov    %ecx,%eax
  66b354:	83 e0 1f             	and    $0x1f,%eax
  66b357:	41 0f b6 79 01       	movzbl 0x1(%r9),%edi
  66b35c:	83 e7 3f             	and    $0x3f,%edi
  66b35f:	80 f9 e0             	cmp    $0xe0,%cl
  66b362:	72 2d                	jb     66b391 <<gpui_canvas::text::planner::Planner>::shape+0x701>
  66b364:	41 0f b6 71 02       	movzbl 0x2(%r9),%esi
  66b369:	c1 e7 06             	shl    $0x6,%edi
  66b36c:	83 e6 3f             	and    $0x3f,%esi
  66b36f:	09 fe                	or     %edi,%esi
  66b371:	80 f9 f0             	cmp    $0xf0,%cl
  66b374:	72 28                	jb     66b39e <<gpui_canvas::text::planner::Planner>::shape+0x70e>
  66b376:	49 8d 51 04          	lea    0x4(%r9),%rdx
  66b37a:	41 0f b6 49 03       	movzbl 0x3(%r9),%ecx
  66b37f:	83 e0 07             	and    $0x7,%eax
  66b382:	c1 e0 12             	shl    $0x12,%eax
  66b385:	c1 e6 06             	shl    $0x6,%esi
  66b388:	83 e1 3f             	and    $0x3f,%ecx
  66b38b:	09 f1                	or     %esi,%ecx
  66b38d:	09 c1                	or     %eax,%ecx
  66b38f:	eb 18                	jmp    66b3a9 <<gpui_canvas::text::planner::Planner>::shape+0x719>
  66b391:	49 8d 51 02          	lea    0x2(%r9),%rdx
  66b395:	c1 e0 06             	shl    $0x6,%eax
  66b398:	09 f8                	or     %edi,%eax
  66b39a:	89 c1                	mov    %eax,%ecx
  66b39c:	eb 0b                	jmp    66b3a9 <<gpui_canvas::text::planner::Planner>::shape+0x719>
  66b39e:	49 8d 51 03          	lea    0x3(%r9),%rdx
  66b3a2:	c1 e0 0c             	shl    $0xc,%eax
  66b3a5:	09 c6                	or     %eax,%esi
  66b3a7:	89 f1                	mov    %esi,%ecx
  66b3a9:	4c 89 c0             	mov    %r8,%rax
  66b3ac:	49 89 c0             	mov    %rax,%r8
  66b3af:	4c 29 c8             	sub    %r9,%rax
  66b3b2:	48 01 d0             	add    %rdx,%rax
  66b3b5:	c7 84 24 80 00 00 00 	movl   $0xfffffffe,0x80(%rsp)
  66b3bc:	fe ff ff ff 
  66b3c0:	40 b6 01             	mov    $0x1,%sil
  66b3c3:	89 74 24 4c          	mov    %esi,0x4c(%rsp)
  66b3c7:	83 f9 0c             	cmp    $0xc,%ecx
  66b3ca:	7e 24                	jle    66b3f0 <<gpui_canvas::text::planner::Planner>::shape+0x760>
  66b3cc:	83 f9 0d             	cmp    $0xd,%ecx
  66b3cf:	0f 84 5b 01 00 00    	je     66b530 <<gpui_canvas::text::planner::Planner>::shape+0x8a0>
  66b3d5:	81 f9 85 00 00 00    	cmp    $0x85,%ecx
  66b3db:	74 21                	je     66b3fe <<gpui_canvas::text::planner::Planner>::shape+0x76e>
  66b3dd:	81 f9 29 20 00 00    	cmp    $0x2029,%ecx
  66b3e3:	74 19                	je     66b3fe <<gpui_canvas::text::planner::Planner>::shape+0x76e>
  66b3e5:	e9 83 00 00 00       	jmp    66b46d <<gpui_canvas::text::planner::Planner>::shape+0x7dd>
  66b3ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  66b3f0:	83 f9 ff             	cmp    $0xffffffff,%ecx
  66b3f3:	0f 84 23 01 00 00    	je     66b51c <<gpui_canvas::text::planner::Planner>::shape+0x88c>
  66b3f9:	83 f9 0a             	cmp    $0xa,%ecx
  66b3fc:	75 6f                	jne    66b46d <<gpui_canvas::text::planner::Planner>::shape+0x7dd>
  66b3fe:	48 89 54 24 28       	mov    %rdx,0x28(%rsp)
  66b403:	81 f9 80 00 00 00    	cmp    $0x80,%ecx
  66b409:	0f 83 32 01 00 00    	jae    66b541 <<gpui_canvas::text::planner::Planner>::shape+0x8b1>
  66b40f:	49 8d 70 01          	lea    0x1(%r8),%rsi
  66b413:	83 f9 0d             	cmp    $0xd,%ecx
  66b416:	0f 85 37 01 00 00    	jne    66b553 <<gpui_canvas::text::planner::Planner>::shape+0x8c3>
  66b41c:	4c 8b 4c 24 28       	mov    0x28(%rsp),%r9
  66b421:	4c 3b 8c 24 b0 01 00 	cmp    0x1b0(%rsp),%r9
  66b428:	00 
  66b429:	0f 84 78 23 00 00    	je     66d7a7 <<gpui_canvas::text::planner::Planner>::shape+0x2b17>
  66b42f:	45 0f b6 11          	movzbl (%r9),%r10d
  66b433:	49 89 f3             	mov    %rsi,%r11
  66b436:	45 84 d2             	test   %r10b,%r10b
  66b439:	0f 88 78 23 00 00    	js     66d7b7 <<gpui_canvas::text::planner::Planner>::shape+0x2b27>
  66b43f:	49 8d 59 01          	lea    0x1(%r9),%rbx
  66b443:	e9 ce 23 00 00       	jmp    66d816 <<gpui_canvas::text::planner::Planner>::shape+0x2b86>
  66b448:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  66b44f:	00 
  66b450:	81 f9 29 20 00 00    	cmp    $0x2029,%ecx
  66b456:	0f 84 d9 00 00 00    	je     66b535 <<gpui_canvas::text::planner::Planner>::shape+0x8a5>
  66b45c:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
  66b461:	81 f9 85 00 00 00    	cmp    $0x85,%ecx
  66b467:	0f 84 c8 00 00 00    	je     66b535 <<gpui_canvas::text::planner::Planner>::shape+0x8a5>
  66b46d:	48 3b 94 24 b0 01 00 	cmp    0x1b0(%rsp),%rdx
  66b474:	00 
  66b475:	0f 84 a1 00 00 00    	je     66b51c <<gpui_canvas::text::planner::Planner>::shape+0x88c>
  66b47b:	49 89 c0             	mov    %rax,%r8
  66b47e:	0f b6 0a             	movzbl (%rdx),%ecx
  66b481:	84 c9                	test   %cl,%cl
  66b483:	78 0b                	js     66b490 <<gpui_canvas::text::planner::Planner>::shape+0x800>
  66b485:	48 8d 42 01          	lea    0x1(%rdx),%rax
  66b489:	eb 65                	jmp    66b4f0 <<gpui_canvas::text::planner::Planner>::shape+0x860>
  66b48b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  66b490:	89 c8                	mov    %ecx,%eax
  66b492:	83 e0 1f             	and    $0x1f,%eax
  66b495:	0f b6 7a 01          	movzbl 0x1(%rdx),%edi
  66b499:	83 e7 3f             	and    $0x3f,%edi
  66b49c:	80 f9 df             	cmp    $0xdf,%cl
  66b49f:	76 2e                	jbe    66b4cf <<gpui_canvas::text::planner::Planner>::shape+0x83f>
  66b4a1:	0f b6 72 02          	movzbl 0x2(%rdx),%esi
  66b4a5:	c1 e7 06             	shl    $0x6,%edi
  66b4a8:	83 e6 3f             	and    $0x3f,%esi
  66b4ab:	09 fe                	or     %edi,%esi
  66b4ad:	80 f9 f0             	cmp    $0xf0,%cl
  66b4b0:	72 2d                	jb     66b4df <<gpui_canvas::text::planner::Planner>::shape+0x84f>
  66b4b2:	48 8d 7a 04          	lea    0x4(%rdx),%rdi
  66b4b6:	0f b6 4a 03          	movzbl 0x3(%rdx),%ecx
  66b4ba:	83 e0 07             	and    $0x7,%eax
  66b4bd:	c1 e0 12             	shl    $0x12,%eax
  66b4c0:	c1 e6 06             	shl    $0x6,%esi
  66b4c3:	83 e1 3f             	and    $0x3f,%ecx
  66b4c6:	09 f1                	or     %esi,%ecx
  66b4c8:	09 c1                	or     %eax,%ecx
  66b4ca:	48 89 f8             	mov    %rdi,%rax
  66b4cd:	eb 21                	jmp    66b4f0 <<gpui_canvas::text::planner::Planner>::shape+0x860>
  66b4cf:	48 8d 72 02          	lea    0x2(%rdx),%rsi
  66b4d3:	c1 e0 06             	shl    $0x6,%eax
  66b4d6:	09 f8                	or     %edi,%eax
  66b4d8:	89 c1                	mov    %eax,%ecx
  66b4da:	48 89 f0             	mov    %rsi,%rax
  66b4dd:	eb 11                	jmp    66b4f0 <<gpui_canvas::text::planner::Planner>::shape+0x860>
  66b4df:	48 8d 4a 03          	lea    0x3(%rdx),%rcx
  66b4e3:	c1 e0 0c             	shl    $0xc,%eax
  66b4e6:	09 c6                	or     %eax,%esi
  66b4e8:	48 89 c8             	mov    %rcx,%rax
  66b4eb:	89 f1                	mov    %esi,%ecx
  66b4ed:	0f 1f 00             	nopl   (%rax)
  66b4f0:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  66b4f5:	48 29 d0             	sub    %rdx,%rax
  66b4f8:	4c 01 c0             	add    %r8,%rax
  66b4fb:	81 f9 84 00 00 00    	cmp    $0x84,%ecx
  66b501:	0f 8f 49 ff ff ff    	jg     66b450 <<gpui_canvas::text::planner::Planner>::shape+0x7c0>
  66b507:	83 f9 0a             	cmp    $0xa,%ecx
  66b50a:	74 29                	je     66b535 <<gpui_canvas::text::planner::Planner>::shape+0x8a5>
  66b50c:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
  66b511:	83 f9 0d             	cmp    $0xd,%ecx
  66b514:	0f 85 53 ff ff ff    	jne    66b46d <<gpui_canvas::text::planner::Planner>::shape+0x7dd>
  66b51a:	eb 19                	jmp    66b535 <<gpui_canvas::text::planner::Planner>::shape+0x8a5>
  66b51c:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
  66b521:	48 89 54 24 28       	mov    %rdx,0x28(%rsp)
  66b526:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  66b52b:	48 89 fe             	mov    %rdi,%rsi
  66b52e:	eb 33                	jmp    66b563 <<gpui_canvas::text::planner::Planner>::shape+0x8d3>
  66b530:	48 89 54 24 28       	mov    %rdx,0x28(%rsp)
  66b535:	81 f9 80 00 00 00    	cmp    $0x80,%ecx
  66b53b:	0f 82 ce fe ff ff    	jb     66b40f <<gpui_canvas::text::planner::Planner>::shape+0x77f>
  66b541:	81 f9 00 08 00 00    	cmp    $0x800,%ecx
  66b547:	be 03 00 00 00       	mov    $0x3,%esi
  66b54c:	48 83 de 00          	sbb    $0x0,%rsi
  66b550:	4c 01 c6             	add    %r8,%rsi
  66b553:	c7 44 24 4c 00 00 00 	movl   $0x0,0x4c(%rsp)
  66b55a:	00 
  66b55b:	4c 89 c1             	mov    %r8,%rcx
  66b55e:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  66b563:	48 89 ca             	mov    %rcx,%rdx
  66b566:	48 29 fa             	sub    %rdi,%rdx
  66b569:	48 89 94 24 10 01 00 	mov    %rdx,0x110(%rsp)
  66b570:	00 
  66b571:	0f 82 a8 2c 00 00    	jb     66e21f <<gpui_canvas::text::planner::Planner>::shape+0x358f>
  66b577:	48 83 7c 24 30 00    	cmpq   $0x0,0x30(%rsp)
  66b57d:	48 89 84 24 20 03 00 	mov    %rax,0x320(%rsp)
  66b584:	00 
  66b585:	74 2f                	je     66b5b6 <<gpui_canvas::text::planner::Planner>::shape+0x926>
  66b587:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
  66b58c:	48 3b 54 24 50       	cmp    0x50(%rsp),%rdx
  66b591:	73 1d                	jae    66b5b0 <<gpui_canvas::text::planner::Planner>::shape+0x920>
  66b593:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  66b59a:	00 
  66b59b:	80 3c 10 bf          	cmpb   $0xbf,(%rax,%rdx,1)
  66b59f:	7f 15                	jg     66b5b6 <<gpui_canvas::text::planner::Planner>::shape+0x926>
  66b5a1:	e9 79 2c 00 00       	jmp    66e21f <<gpui_canvas::text::planner::Planner>::shape+0x358f>
  66b5a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  66b5ad:	00 00 00 
  66b5b0:	0f 85 69 2c 00 00    	jne    66e21f <<gpui_canvas::text::planner::Planner>::shape+0x358f>
  66b5b6:	48 85 c9             	test   %rcx,%rcx
  66b5b9:	74 2b                	je     66b5e6 <<gpui_canvas::text::planner::Planner>::shape+0x956>
  66b5bb:	48 3b 4c 24 50       	cmp    0x50(%rsp),%rcx
  66b5c0:	73 1e                	jae    66b5e0 <<gpui_canvas::text::planner::Planner>::shape+0x950>
  66b5c2:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  66b5c9:	00 
  66b5ca:	80 3c 08 c0          	cmpb   $0xc0,(%rax,%rcx,1)
  66b5ce:	7d 16                	jge    66b5e6 <<gpui_canvas::text::planner::Planner>::shape+0x956>
  66b5d0:	e9 4a 2c 00 00       	jmp    66e21f <<gpui_canvas::text::planner::Planner>::shape+0x358f>
  66b5d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  66b5dc:	00 00 00 00 
  66b5e0:	0f 85 39 2c 00 00    	jne    66e21f <<gpui_canvas::text::planner::Planner>::shape+0x358f>
  66b5e6:	48 89 8c 24 00 01 00 	mov    %rcx,0x100(%rsp)
  66b5ed:	00 
  66b5ee:	48 89 b4 24 18 03 00 	mov    %rsi,0x318(%rsp)
  66b5f5:	00 
  66b5f6:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  66b5fd:	00 
  66b5fe:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  66b603:	48 01 c1             	add    %rax,%rcx
  66b606:	48 8d bc 24 98 04 00 	lea    0x498(%rsp),%rdi
  66b60d:	00 
  66b60e:	48 8b b4 24 30 03 00 	mov    0x330(%rsp),%rsi
  66b615:	00 
  66b616:	48 8b 94 24 28 03 00 	mov    0x328(%rsp),%rdx
  66b61d:	00 
  66b61e:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  66b623:	4c 8b 84 24 10 01 00 	mov    0x110(%rsp),%r8
  66b62a:	00 
  66b62b:	f3 0f 10 05 e9 21 9b 	movss  -0x64de17(%rip),%xmm0        # 1d81c <GCC_except_table0+0x1c>
  66b632:	ff 
  66b633:	45 31 c9             	xor    %r9d,%r9d
  66b636:	e8 45 8f ff ff       	call   664580 <<parley::context::LayoutContext<()>>::ranged_builder>
  66b63b:	48 8d bc 24 98 04 00 	lea    0x498(%rsp),%rdi
  66b642:	00 
  66b643:	48 8d b4 24 a0 02 00 	lea    0x2a0(%rsp),%rsi
  66b64a:	00 
  66b64b:	48 8b 94 24 10 02 00 	mov    0x210(%rsp),%rdx
  66b652:	00 
  66b653:	e8 f8 b0 01 00       	call   686750 <<parley::builder::RangedBuilder<()>>::push_default::<&[parlance::font_family::FontFamilyName]>>
  66b658:	4c 8b bc 24 98 04 00 	mov    0x498(%rsp),%r15
  66b65f:	00 
  66b660:	48 8b 9c 24 a0 04 00 	mov    0x4a0(%rsp),%rbx
  66b667:	00 
  66b668:	49 8d b7 30 02 00 00 	lea    0x230(%r15),%rsi
  66b66f:	c6 84 24 10 07 00 00 	movb   $0x1,0x710(%rsp)
  66b676:	01 
  66b677:	f3 0f 10 84 24 84 00 	movss  0x84(%rsp),%xmm0
  66b67e:	00 00 
  66b680:	f3 0f 11 84 24 14 07 	movss  %xmm0,0x714(%rsp)
  66b687:	00 00 
  66b689:	f3 0f 10 84 24 b8 04 	movss  0x4b8(%rsp),%xmm0
  66b690:	00 00 
  66b692:	48 8d bc 24 c0 04 00 	lea    0x4c0(%rsp),%rdi
  66b699:	00 
  66b69a:	48 89 f5             	mov    %rsi,%rbp
  66b69d:	48 89 da             	mov    %rbx,%rdx
  66b6a0:	4c 8d b4 24 10 07 00 	lea    0x710(%rsp),%r14
  66b6a7:	00 
  66b6a8:	4c 89 f1             	mov    %r14,%rcx
  66b6ab:	f3 0f 11 44 24 60    	movss  %xmm0,0x60(%rsp)
  66b6b1:	e8 6a 83 00 00       	call   673a20 <<parley::resolve::ResolveContext>::resolve_property::<()>>
  66b6b6:	4c 89 f7             	mov    %r14,%rdi
  66b6b9:	e8 42 b1 01 00       	call   686800 <core::ptr::drop_glue::<parley::style::StyleProperty<()>>>
  66b6be:	49 83 bf 20 05 00 00 	cmpq   $0xffffffffffffffff,0x520(%r15)
  66b6c5:	ff 
  66b6c6:	0f 84 8e 27 00 00    	je     66de5a <<gpui_canvas::text::planner::Planner>::shape+0x31ca>
  66b6cc:	4d 8d b7 98 04 00 00 	lea    0x498(%r15),%r14
  66b6d3:	4c 89 f7             	mov    %r14,%rdi
  66b6d6:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
  66b6dd:	00 
  66b6de:	e8 dd 88 00 00       	call   673fc0 <<parley::resolve::ResolvedStyle<()>>::apply>
  66b6e3:	66 c7 84 24 10 07 00 	movw   $0x117,0x710(%rsp)
  66b6ea:	00 17 01 
  66b6ed:	48 8d bc 24 c0 04 00 	lea    0x4c0(%rsp),%rdi
  66b6f4:	00 
  66b6f5:	48 89 ee             	mov    %rbp,%rsi
  66b6f8:	48 89 da             	mov    %rbx,%rdx
  66b6fb:	48 8d 9c 24 10 07 00 	lea    0x710(%rsp),%rbx
  66b702:	00 
  66b703:	48 89 d9             	mov    %rbx,%rcx
  66b706:	f3 0f 10 44 24 60    	movss  0x60(%rsp),%xmm0
  66b70c:	e8 0f 83 00 00       	call   673a20 <<parley::resolve::ResolveContext>::resolve_property::<()>>
  66b711:	48 89 df             	mov    %rbx,%rdi
  66b714:	e8 e7 b0 01 00       	call   686800 <core::ptr::drop_glue::<parley::style::StyleProperty<()>>>
  66b719:	49 83 bf 20 05 00 00 	cmpq   $0xffffffffffffffff,0x520(%r15)
  66b720:	ff 
  66b721:	0f 84 33 27 00 00    	je     66de5a <<gpui_canvas::text::planner::Planner>::shape+0x31ca>
  66b727:	4c 89 f7             	mov    %r14,%rdi
  66b72a:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
  66b731:	00 
  66b732:	e8 89 88 00 00       	call   673fc0 <<parley::resolve::ResolvedStyle<()>>::apply>
  66b737:	48 8d bc 24 98 04 00 	lea    0x498(%rsp),%rdi
  66b73e:	00 
  66b73f:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  66b744:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  66b749:	48 8b 8c 24 10 01 00 	mov    0x110(%rsp),%rcx
  66b750:	00 
  66b751:	e8 6a a9 01 00       	call   6860c0 <<parley::builder::RangedBuilder<()>>::build_into::<&str>>
  66b756:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  66b75d:	00 
  66b75e:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  66b763:	e8 18 75 01 00       	call   682c80 <<parley::layout::line_break::BreakLines<()>>::new>
  66b768:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  66b76f:	00 
  66b770:	f3 0f 10 84 24 cc 01 	movss  0x1cc(%rsp),%xmm0
  66b777:	00 00 
  66b779:	e8 e2 65 01 00       	call   681d60 <<parley::layout::line_break::BreakLines<()>>::break_remaining>
  66b77e:	80 bc 24 2c 02 00 00 	cmpb   $0x0,0x22c(%rsp)
  66b785:	00 
  66b786:	74 18                	je     66b7a0 <<gpui_canvas::text::planner::Planner>::shape+0xb10>
  66b788:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  66b78f:	00 ff 
  66b791:	0f 85 0c 02 00 00    	jne    66b9a3 <<gpui_canvas::text::planner::Planner>::shape+0xd13>
  66b797:	31 c0                	xor    %eax,%eax
  66b799:	e9 88 01 00 00       	jmp    66b926 <<gpui_canvas::text::planner::Planner>::shape+0xc96>
  66b79e:	66 90                	xchg   %ax,%ax
  66b7a0:	48 83 7c 24 30 00    	cmpq   $0x0,0x30(%rsp)
  66b7a6:	48 8b 84 24 00 01 00 	mov    0x100(%rsp),%rax
  66b7ad:	00 
  66b7ae:	0f 85 5c 01 00 00    	jne    66b910 <<gpui_canvas::text::planner::Planner>::shape+0xc80>
  66b7b4:	48 3b 44 24 50       	cmp    0x50(%rsp),%rax
  66b7b9:	0f 85 51 01 00 00    	jne    66b910 <<gpui_canvas::text::planner::Planner>::shape+0xc80>
  66b7bf:	48 8b 04 24          	mov    (%rsp),%rax
  66b7c3:	48 83 b8 e0 09 00 00 	cmpq   $0x1,0x9e0(%rax)
  66b7ca:	01 
  66b7cb:	0f 85 3f 01 00 00    	jne    66b910 <<gpui_canvas::text::planner::Planner>::shape+0xc80>
  66b7d1:	48 8b 14 24          	mov    (%rsp),%rdx
  66b7d5:	48 8b 82 d8 09 00 00 	mov    0x9d8(%rdx),%rax
  66b7dc:	48 8d 48 70          	lea    0x70(%rax),%rcx
  66b7e0:	48 89 8c 24 18 07 00 	mov    %rcx,0x718(%rsp)
  66b7e7:	00 
  66b7e8:	48 c7 84 24 20 07 00 	movq   $0x0,0x720(%rsp)
  66b7ef:	00 00 00 00 00 
  66b7f4:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  66b7f9:	48 89 b4 24 28 07 00 	mov    %rsi,0x728(%rsp)
  66b800:	00 
  66b801:	48 c7 84 24 58 07 00 	movq   $0x0,0x758(%rsp)
  66b808:	00 00 00 00 00 
  66b80d:	48 89 94 24 c0 04 00 	mov    %rdx,0x4c0(%rsp)
  66b814:	00 
  66b815:	48 c7 84 24 30 07 00 	movq   $0x0,0x730(%rsp)
  66b81c:	00 00 00 00 00 
  66b821:	48 89 8c 24 10 07 00 	mov    %rcx,0x710(%rsp)
  66b828:	00 
  66b829:	48 8b 78 10          	mov    0x10(%rax),%rdi
  66b82d:	48 8b 70 18          	mov    0x18(%rax),%rsi
  66b831:	48 8b 92 f8 09 00 00 	mov    0x9f8(%rdx),%rdx
  66b838:	48 39 fe             	cmp    %rdi,%rsi
  66b83b:	0f 82 95 29 00 00    	jb     66e1d6 <<gpui_canvas::text::planner::Planner>::shape+0x3546>
  66b841:	48 39 d6             	cmp    %rdx,%rsi
  66b844:	0f 87 8c 29 00 00    	ja     66e1d6 <<gpui_canvas::text::planner::Planner>::shape+0x3546>
  66b84a:	48 8b 04 24          	mov    (%rsp),%rax
  66b84e:	48 8b 80 f0 09 00 00 	mov    0x9f0(%rax),%rax
  66b855:	48 8d 0c bf          	lea    (%rdi,%rdi,4),%rcx
  66b859:	48 8d 0c c8          	lea    (%rax,%rcx,8),%rcx
  66b85d:	48 8d 14 b6          	lea    (%rsi,%rsi,4),%rdx
  66b861:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
  66b865:	48 89 8c 24 30 07 00 	mov    %rcx,0x730(%rsp)
  66b86c:	00 
  66b86d:	48 89 84 24 38 07 00 	mov    %rax,0x738(%rsp)
  66b874:	00 
  66b875:	48 c7 84 24 40 07 00 	movq   $0x0,0x740(%rsp)
  66b87c:	00 00 00 00 00 
  66b881:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  66b886:	48 89 84 24 48 07 00 	mov    %rax,0x748(%rsp)
  66b88d:	00 
  66b88e:	c7 84 24 50 07 00 00 	movl   $0x0,0x750(%rsp)
  66b895:	00 00 00 00 
  66b899:	48 8d bc 24 30 07 00 	lea    0x730(%rsp),%rdi
  66b8a0:	00 
  66b8a1:	48 8d b4 24 58 07 00 	lea    0x758(%rsp),%rsi
  66b8a8:	00 
  66b8a9:	48 8d 94 24 c0 04 00 	lea    0x4c0(%rsp),%rdx
  66b8b0:	00 
  66b8b1:	e8 7a b3 00 00       	call   676c30 <<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}> as core::iter::traits::iterator::Iterator>::try_fold::<(), core::iter::adapters::filter_map::filter_map_try_fold<parley::layout::line::LineItem<()>, parley::layout::run::Run<()>, (), core::ops::control_flow::ControlFlow<()>, <parley::layout::line::Line<()>>::runs::{closure#0}, &mut core::iter::traits::iterator::Iterator::all::check<parley::layout::run::Run<()>, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#2}>::{closure#0}>::{closure#0}, core::ops::control_flow::ControlFlow<()>>>
  66b8b6:	48 c7 84 24 20 07 00 	movq   $0x1,0x720(%rsp)
  66b8bd:	00 01 00 00 00 
  66b8c2:	84 c0                	test   %al,%al
  66b8c4:	75 4a                	jne    66b910 <<gpui_canvas::text::planner::Planner>::shape+0xc80>
  66b8c6:	48 c7 84 24 30 07 00 	movq   $0x0,0x730(%rsp)
  66b8cd:	00 00 00 00 00 
  66b8d2:	48 83 bc 24 58 07 00 	cmpq   $0x0,0x758(%rsp)
  66b8d9:	00 00 
  66b8db:	0f 84 4b 1e 00 00    	je     66d72c <<gpui_canvas::text::planner::Planner>::shape+0x2a9c>
  66b8e1:	48 8d bc 24 58 07 00 	lea    0x758(%rsp),%rdi
  66b8e8:	00 
  66b8e9:	48 8d b4 24 80 07 00 	lea    0x780(%rsp),%rsi
  66b8f0:	00 
  66b8f1:	48 8d 94 24 c0 04 00 	lea    0x4c0(%rsp),%rdx
  66b8f8:	00 
  66b8f9:	e8 32 b3 00 00       	call   676c30 <<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}> as core::iter::traits::iterator::Iterator>::try_fold::<(), core::iter::adapters::filter_map::filter_map_try_fold<parley::layout::line::LineItem<()>, parley::layout::run::Run<()>, (), core::ops::control_flow::ControlFlow<()>, <parley::layout::line::Line<()>>::runs::{closure#0}, &mut core::iter::traits::iterator::Iterator::all::check<parley::layout::run::Run<()>, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#2}>::{closure#0}>::{closure#0}, core::ops::control_flow::ControlFlow<()>>>
  66b8fe:	84 c0                	test   %al,%al
  66b900:	0f 84 26 1e 00 00    	je     66d72c <<gpui_canvas::text::planner::Planner>::shape+0x2a9c>
  66b906:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  66b90d:	00 00 00 
  66b910:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  66b917:	00 ff 
  66b919:	0f 85 84 00 00 00    	jne    66b9a3 <<gpui_canvas::text::planner::Planner>::shape+0xd13>
  66b91f:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
  66b926:	48 c7 84 24 50 01 00 	movq   $0x0,0x150(%rsp)
  66b92d:	00 00 00 00 00 
  66b932:	48 c7 84 24 58 01 00 	movq   $0x4,0x158(%rsp)
  66b939:	00 04 00 00 00 
  66b93e:	48 8d 8c 24 58 01 00 	lea    0x158(%rsp),%rcx
  66b945:	00 
  66b946:	0f 57 c0             	xorps  %xmm0,%xmm0
  66b949:	0f 11 41 08          	movups %xmm0,0x8(%rcx)
  66b94d:	48 c7 84 24 70 01 00 	movq   $0x4,0x170(%rsp)
  66b954:	00 04 00 00 00 
  66b959:	48 c7 84 24 78 01 00 	movq   $0x0,0x178(%rsp)
  66b960:	00 00 00 00 00 
  66b965:	48 89 84 24 80 01 00 	mov    %rax,0x180(%rsp)
  66b96c:	00 
  66b96d:	48 c7 84 24 88 01 00 	movq   $0x4,0x188(%rsp)
  66b974:	00 04 00 00 00 
  66b979:	48 c7 84 24 90 01 00 	movq   $0x0,0x190(%rsp)
  66b980:	00 00 00 00 00 
  66b985:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  66b98a:	89 84 24 98 01 00 00 	mov    %eax,0x198(%rsp)
  66b991:	f3 0f 10 84 24 84 00 	movss  0x84(%rsp),%xmm0
  66b998:	00 00 
  66b99a:	f3 0f 11 84 24 9c 01 	movss  %xmm0,0x19c(%rsp)
  66b9a1:	00 00 
  66b9a3:	48 8b 04 24          	mov    (%rsp),%rax
  66b9a7:	4c 8b b0 e0 09 00 00 	mov    0x9e0(%rax),%r14
  66b9ae:	4d 85 f6             	test   %r14,%r14
  66b9b1:	0f 84 09 01 00 00    	je     66bac0 <<gpui_canvas::text::planner::Planner>::shape+0xe30>
  66b9b7:	48 8b a8 d8 09 00 00 	mov    0x9d8(%rax),%rbp
  66b9be:	45 31 ff             	xor    %r15d,%r15d
  66b9c1:	31 db                	xor    %ebx,%ebx
  66b9c3:	eb 17                	jmp    66b9dc <<gpui_canvas::text::planner::Planner>::shape+0xd4c>
  66b9c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  66b9cc:	00 00 00 00 
  66b9d0:	49 ff c7             	inc    %r15
  66b9d3:	4d 39 f7             	cmp    %r14,%r15
  66b9d6:	0f 84 e6 00 00 00    	je     66bac2 <<gpui_canvas::text::planner::Planner>::shape+0xe32>
  66b9dc:	49 6b c7 70          	imul   $0x70,%r15,%rax
  66b9e0:	48 01 e8             	add    %rbp,%rax
  66b9e3:	48 89 9c 24 10 07 00 	mov    %rbx,0x710(%rsp)
  66b9ea:	00 
  66b9eb:	48 c7 84 24 18 07 00 	movq   $0x0,0x718(%rsp)
  66b9f2:	00 00 00 00 00 
  66b9f7:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
  66b9fc:	48 89 8c 24 20 07 00 	mov    %rcx,0x720(%rsp)
  66ba03:	00 
  66ba04:	48 89 84 24 28 07 00 	mov    %rax,0x728(%rsp)
  66ba0b:	00 
  66ba0c:	44 89 bc 24 30 07 00 	mov    %r15d,0x730(%rsp)
  66ba13:	00 
  66ba14:	c6 84 24 d8 07 00 00 	movb   $0x2,0x7d8(%rsp)
  66ba1b:	02 
  66ba1c:	c7 84 24 e0 07 00 00 	movl   $0x0,0x7e0(%rsp)
  66ba23:	00 00 00 00 
  66ba27:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
  66ba2e:	00 
  66ba2f:	48 8d b4 24 18 07 00 	lea    0x718(%rsp),%rsi
  66ba36:	00 
  66ba37:	e8 44 bc 00 00       	call   677680 <<parley::layout::line::GlyphRunIter<()> as core::iter::traits::iterator::Iterator>::next>
  66ba3c:	83 bc 24 40 03 00 00 	cmpl   $0x1,0x340(%rsp)
  66ba43:	01 
  66ba44:	75 8a                	jne    66b9d0 <<gpui_canvas::text::planner::Planner>::shape+0xd40>
  66ba46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  66ba4d:	00 00 00 
  66ba50:	49 8b 45 38          	mov    0x38(%r13),%rax
  66ba54:	49 89 44 24 40       	mov    %rax,0x40(%r12)
  66ba59:	41 0f 10 45 f8       	movups -0x8(%r13),%xmm0
  66ba5e:	41 0f 10 4d 08       	movups 0x8(%r13),%xmm1
  66ba63:	41 0f 10 55 18       	movups 0x18(%r13),%xmm2
  66ba68:	41 0f 10 5d 28       	movups 0x28(%r13),%xmm3
  66ba6d:	41 0f 11 5c 24 30    	movups %xmm3,0x30(%r12)
  66ba73:	41 0f 11 54 24 20    	movups %xmm2,0x20(%r12)
  66ba79:	41 0f 11 4c 24 10    	movups %xmm1,0x10(%r12)
  66ba7f:	41 0f 11 04 24       	movups %xmm0,(%r12)
  66ba84:	48 89 9c 24 c0 04 00 	mov    %rbx,0x4c0(%rsp)
  66ba8b:	00 
  66ba8c:	48 89 de             	mov    %rbx,%rsi
  66ba8f:	4c 89 e2             	mov    %r12,%rdx
  66ba92:	e8 a9 b7 00 00       	call   677240 <<&mut core::iter::adapters::map::map_fold<parley::layout::line::PositionedLayoutItem<()>, usize, usize, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#5}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineData>>, <parley::layout::layout::Layout<()>>::lines::{closure#0}>, parley::layout::line::GlyphRunIter<()>, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#4}>, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#5}>>::{closure#0}>::{closure#0} as core::ops::function::FnMut<(usize, parley::layout::line::PositionedLayoutItem<()>)>>::call_mut>
  66ba97:	48 89 c3             	mov    %rax,%rbx
  66ba9a:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
  66baa1:	00 
  66baa2:	48 8d b4 24 18 07 00 	lea    0x718(%rsp),%rsi
  66baa9:	00 
  66baaa:	e8 d1 bb 00 00       	call   677680 <<parley::layout::line::GlyphRunIter<()> as core::iter::traits::iterator::Iterator>::next>
  66baaf:	80 bc 24 40 03 00 00 	cmpb   $0x0,0x340(%rsp)
  66bab6:	00 
  66bab7:	75 97                	jne    66ba50 <<gpui_canvas::text::planner::Planner>::shape+0xdc0>
  66bab9:	e9 12 ff ff ff       	jmp    66b9d0 <<gpui_canvas::text::planner::Planner>::shape+0xd40>
  66babe:	66 90                	xchg   %ax,%ax
  66bac0:	31 db                	xor    %ebx,%ebx
  66bac2:	48 8b b4 24 f8 00 00 	mov    0xf8(%rsp),%rsi
  66bac9:	00 
  66baca:	48 89 f0             	mov    %rsi,%rax
  66bacd:	48 01 d8             	add    %rbx,%rax
  66bad0:	0f 92 c1             	setb   %cl
  66bad3:	48 3d 01 80 00 00    	cmp    $0x8001,%rax
  66bad9:	0f 93 c0             	setae  %al
  66badc:	08 c8                	or     %cl,%al
  66bade:	0f 85 9b 1d 00 00    	jne    66d87f <<gpui_canvas::text::planner::Planner>::shape+0x2bef>
  66bae4:	48 8b 6c 24 30       	mov    0x30(%rsp),%rbp
  66bae9:	48 39 ac 24 00 01 00 	cmp    %rbp,0x100(%rsp)
  66baf0:	00 
  66baf1:	74 14                	je     66bb07 <<gpui_canvas::text::planner::Planner>::shape+0xe77>
  66baf3:	48 8b 84 24 e8 00 00 	mov    0xe8(%rsp),%rax
  66bafa:	00 
  66bafb:	48 29 f0             	sub    %rsi,%rax
  66bafe:	48 39 c3             	cmp    %rax,%rbx
  66bb01:	0f 87 58 1d 00 00    	ja     66d85f <<gpui_canvas::text::planner::Planner>::shape+0x2bcf>
  66bb07:	48 85 ed             	test   %rbp,%rbp
  66bb0a:	48 8b 9c 24 00 01 00 	mov    0x100(%rsp),%rbx
  66bb11:	00 
  66bb12:	74 26                	je     66bb3a <<gpui_canvas::text::planner::Planner>::shape+0xeaa>
  66bb14:	0f 57 c0             	xorps  %xmm0,%xmm0
  66bb17:	f3 0f 11 84 24 d4 00 	movss  %xmm0,0xd4(%rsp)
  66bb1e:	00 00 
  66bb20:	48 39 eb             	cmp    %rbp,%rbx
  66bb23:	75 4b                	jne    66bb70 <<gpui_canvas::text::planner::Planner>::shape+0xee0>
  66bb25:	48 8b 0c 24          	mov    (%rsp),%rcx
  66bb29:	48 8b 81 e0 09 00 00 	mov    0x9e0(%rcx),%rax
  66bb30:	48 85 c0             	test   %rax,%rax
  66bb33:	75 7c                	jne    66bbb1 <<gpui_canvas::text::planner::Planner>::shape+0xf21>
  66bb35:	e9 9b 14 00 00       	jmp    66cfd5 <<gpui_canvas::text::planner::Planner>::shape+0x2345>
  66bb3a:	48 8b 04 24          	mov    (%rsp),%rax
  66bb3e:	48 83 b8 e0 09 00 00 	cmpq   $0x0,0x9e0(%rax)
  66bb45:	00 
  66bb46:	74 0e                	je     66bb56 <<gpui_canvas::text::planner::Planner>::shape+0xec6>
  66bb48:	48 8b 80 d8 09 00 00 	mov    0x9d8(%rax),%rax
  66bb4f:	f3 0f 10 40 24       	movss  0x24(%rax),%xmm0
  66bb54:	eb 03                	jmp    66bb59 <<gpui_canvas::text::planner::Planner>::shape+0xec9>
  66bb56:	0f 57 c0             	xorps  %xmm0,%xmm0
  66bb59:	f3 0f 11 44 24 7c    	movss  %xmm0,0x7c(%rsp)
  66bb5f:	0f 57 c0             	xorps  %xmm0,%xmm0
  66bb62:	f3 0f 11 84 24 d4 00 	movss  %xmm0,0xd4(%rsp)
  66bb69:	00 00 
  66bb6b:	48 39 eb             	cmp    %rbp,%rbx
  66bb6e:	74 b5                	je     66bb25 <<gpui_canvas::text::planner::Planner>::shape+0xe95>
  66bb70:	83 bc 24 c8 01 00 00 	cmpl   $0x0,0x1c8(%rsp)
  66bb77:	00 
  66bb78:	74 0e                	je     66bb88 <<gpui_canvas::text::planner::Planner>::shape+0xef8>
  66bb7a:	48 8b 04 24          	mov    (%rsp),%rax
  66bb7e:	f3 0f 10 80 28 0a 00 	movss  0xa28(%rax),%xmm0
  66bb85:	00 
  66bb86:	eb 0c                	jmp    66bb94 <<gpui_canvas::text::planner::Planner>::shape+0xf04>
  66bb88:	48 8b 04 24          	mov    (%rsp),%rax
  66bb8c:	f3 0f 10 80 2c 0a 00 	movss  0xa2c(%rax),%xmm0
  66bb93:	00 
  66bb94:	f3 0f 11 84 24 d4 00 	movss  %xmm0,0xd4(%rsp)
  66bb9b:	00 00 
  66bb9d:	48 8b 0c 24          	mov    (%rsp),%rcx
  66bba1:	48 8b 81 e0 09 00 00 	mov    0x9e0(%rcx),%rax
  66bba8:	48 85 c0             	test   %rax,%rax
  66bbab:	0f 84 24 14 00 00    	je     66cfd5 <<gpui_canvas::text::planner::Planner>::shape+0x2345>
  66bbb1:	48 8b 89 d8 09 00 00 	mov    0x9d8(%rcx),%rcx
  66bbb8:	48 6b c0 70          	imul   $0x70,%rax,%rax
  66bbbc:	48 89 8c 24 c8 00 00 	mov    %rcx,0xc8(%rsp)
  66bbc3:	00 
  66bbc4:	48 01 c8             	add    %rcx,%rax
  66bbc7:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
  66bbce:	00 
  66bbcf:	c7 44 24 78 00 00 00 	movl   $0x0,0x78(%rsp)
  66bbd6:	00 
  66bbd7:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  66bbde:	00 ff 
  66bbe0:	74 2e                	je     66bc10 <<gpui_canvas::text::planner::Planner>::shape+0xf80>
  66bbe2:	48 39 eb             	cmp    %rbp,%rbx
  66bbe5:	75 3c                	jne    66bc23 <<gpui_canvas::text::planner::Planner>::shape+0xf93>
  66bbe7:	45 31 f6             	xor    %r14d,%r14d
  66bbea:	45 31 ff             	xor    %r15d,%r15d
  66bbed:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  66bbf4:	00 
  66bbf5:	48 8b 8c 24 78 01 00 	mov    0x178(%rsp),%rcx
  66bbfc:	00 
  66bbfd:	48 89 8c 24 58 02 00 	mov    %rcx,0x258(%rsp)
  66bc04:	00 
  66bc05:	80 78 68 02          	cmpb   $0x2,0x68(%rax)
  66bc09:	74 41                	je     66bc4c <<gpui_canvas::text::planner::Planner>::shape+0xfbc>
  66bc0b:	e9 da 01 00 00       	jmp    66bdea <<gpui_canvas::text::planner::Planner>::shape+0x115a>
  66bc10:	8b 4c 24 78          	mov    0x78(%rsp),%ecx
  66bc14:	89 c8                	mov    %ecx,%eax
  66bc16:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
  66bc1d:	00 
  66bc1e:	e9 cd 03 00 00       	jmp    66bff0 <<gpui_canvas::text::planner::Planner>::shape+0x1360>
  66bc23:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  66bc2a:	00 
  66bc2b:	4c 8b 38             	mov    (%rax),%r15
  66bc2e:	4c 8b 70 08          	mov    0x8(%rax),%r14
  66bc32:	48 8b 8c 24 78 01 00 	mov    0x178(%rsp),%rcx
  66bc39:	00 
  66bc3a:	48 89 8c 24 58 02 00 	mov    %rcx,0x258(%rsp)
  66bc41:	00 
  66bc42:	80 78 68 02          	cmpb   $0x2,0x68(%rax)
  66bc46:	0f 85 9e 01 00 00    	jne    66bdea <<gpui_canvas::text::planner::Planner>::shape+0x115a>
  66bc4c:	48 8b 78 10          	mov    0x10(%rax),%rdi
  66bc50:	48 8b 70 18          	mov    0x18(%rax),%rsi
  66bc54:	48 8b 04 24          	mov    (%rsp),%rax
  66bc58:	48 8b 90 f8 09 00 00 	mov    0x9f8(%rax),%rdx
  66bc5f:	48 39 fe             	cmp    %rdi,%rsi
  66bc62:	0f 82 80 25 00 00    	jb     66e1e8 <<gpui_canvas::text::planner::Planner>::shape+0x3558>
  66bc68:	48 39 d6             	cmp    %rdx,%rsi
  66bc6b:	0f 87 77 25 00 00    	ja     66e1e8 <<gpui_canvas::text::planner::Planner>::shape+0x3558>
  66bc71:	48 8b 04 24          	mov    (%rsp),%rax
  66bc75:	48 8b 80 f0 09 00 00 	mov    0x9f0(%rax),%rax
  66bc7c:	48 8d 0c bf          	lea    (%rdi,%rdi,4),%rcx
  66bc80:	48 8d 0c c8          	lea    (%rax,%rcx,8),%rcx
  66bc84:	48 8d 14 b6          	lea    (%rsi,%rsi,4),%rdx
  66bc88:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
  66bc8c:	48 89 8c 24 c0 04 00 	mov    %rcx,0x4c0(%rsp)
  66bc93:	00 
  66bc94:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
  66bc9b:	00 
  66bc9c:	48 c7 84 24 d0 04 00 	movq   $0x0,0x4d0(%rsp)
  66bca3:	00 00 00 00 00 
  66bca8:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  66bcad:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
  66bcb4:	00 
  66bcb5:	8b 44 24 78          	mov    0x78(%rsp),%eax
  66bcb9:	89 84 24 e0 04 00 00 	mov    %eax,0x4e0(%rsp)
  66bcc0:	c6 84 24 00 07 00 00 	movb   $0x2,0x700(%rsp)
  66bcc7:	02 
  66bcc8:	48 8d 84 24 08 07 00 	lea    0x708(%rsp),%rax
  66bccf:	00 
  66bcd0:	48 89 84 24 40 03 00 	mov    %rax,0x340(%rsp)
  66bcd7:	00 
  66bcd8:	c6 84 24 f0 05 00 00 	movb   $0x2,0x5f0(%rsp)
  66bcdf:	02 
  66bce0:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  66bce7:	00 
  66bce8:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
  66bcef:	00 
  66bcf0:	48 8d 94 24 40 03 00 	lea    0x340(%rsp),%rdx
  66bcf7:	00 
  66bcf8:	48 8d 8c 24 e8 04 00 	lea    0x4e8(%rsp),%rcx
  66bcff:	00 
  66bd00:	e8 fb a7 00 00       	call   676500 <<core::iter::adapters::map::Map<core::iter::adapters::filter_map::FilterMap<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}>, <parley::layout::line::Line<()>>::runs::{closure#0}>, gpui_canvas::text::planner::freeze_line::{closure#0}> as core::iter::traits::iterator::Iterator>::try_fold::<(), <core::iter::adapters::flatten::FlattenCompat<_, _>>::iter_try_fold::flatten<parley::layout::run::Clusters<()>, (), core::ops::control_flow::ControlFlow<parley::layout::cluster::Cluster<()>>, <core::iter::adapters::flatten::FlattenCompat<_, _> as core::iter::traits::iterator::Iterator>::try_fold::flatten<parley::layout::run::Clusters<()>, (), core::ops::control_flow::ControlFlow<parley::layout::cluster::Cluster<()>>, core::iter::traits::iterator::Iterator::find::check<parley::layout::cluster::Cluster<()>, &mut gpui_canvas::text::planner::freeze_line::{closure#1}>::{closure#0}>::{closure#0}>::{closure#0}, core::ops::control_flow::ControlFlow<parley::layout::cluster::Cluster<()>>>>
  66bd05:	48 8b 8c 24 10 07 00 	mov    0x710(%rsp),%rcx
  66bd0c:	00 
  66bd0d:	48 85 c9             	test   %rcx,%rcx
  66bd10:	0f 84 ba 00 00 00    	je     66bdd0 <<gpui_canvas::text::planner::Planner>::shape+0x1140>
  66bd16:	8b bc 24 38 07 00 00 	mov    0x738(%rsp),%edi
  66bd1d:	8b b4 24 90 07 00 00 	mov    0x790(%rsp),%esi
  66bd24:	8b 94 24 94 07 00 00 	mov    0x794(%rsp),%edx
  66bd2b:	48 8b 41 58          	mov    0x58(%rcx),%rax
  66bd2f:	48 39 f8             	cmp    %rdi,%rax
  66bd32:	0f 86 d3 25 00 00    	jbe    66e30b <<gpui_canvas::text::planner::Planner>::shape+0x367b>
  66bd38:	48 8b 41 50          	mov    0x50(%rcx),%rax
  66bd3c:	48 8d 3c ff          	lea    (%rdi,%rdi,8),%rdi
  66bd40:	48 c1 e7 04          	shl    $0x4,%rdi
  66bd44:	0f 10 41 68          	movups 0x68(%rcx),%xmm0
  66bd48:	0f 10 89 80 00 00 00 	movups 0x80(%rcx),%xmm1
  66bd4f:	0f 10 91 98 00 00 00 	movups 0x98(%rcx),%xmm2
  66bd56:	0f 11 84 24 10 07 00 	movups %xmm0,0x710(%rsp)
  66bd5d:	00 
  66bd5e:	0f 11 8c 24 20 07 00 	movups %xmm1,0x720(%rsp)
  66bd65:	00 
  66bd66:	0f 11 94 24 30 07 00 	movups %xmm2,0x730(%rsp)
  66bd6d:	00 
  66bd6e:	48 8b 44 38 50       	mov    0x50(%rax,%rdi,1),%rax
  66bd73:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
  66bd7a:	00 
  66bd7b:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  66bd82:	00 
  66bd83:	ff 15 37 f4 11 00    	call   *0x11f437(%rip)        # 78b1c0 <_DYNAMIC+0x5d8>
  66bd89:	48 89 c3             	mov    %rax,%rbx
  66bd8c:	ba 48 02 00 00       	mov    $0x248,%edx
  66bd91:	4c 89 7c 24 60       	mov    %r15,0x60(%rsp)
  66bd96:	4c 8d bc 24 10 07 00 	lea    0x710(%rsp),%r15
  66bd9d:	00 
  66bd9e:	4c 89 ff             	mov    %r15,%rdi
  66bda1:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
  66bda8:	00 
  66bda9:	ff 15 09 f1 11 00    	call   *0x11f109(%rip)        # 78aeb8 <memcpy@GLIBC_2.14>
  66bdaf:	4c 89 ff             	mov    %r15,%rdi
  66bdb2:	4c 8b 7c 24 60       	mov    0x60(%rsp),%r15
  66bdb7:	48 89 de             	mov    %rbx,%rsi
  66bdba:	e8 e1 a9 00 00       	call   6767a0 <<core::iter::adapters::map::Map<core::iter::adapters::filter::Filter<core::iter::adapters::flatten::FlatMap<core::iter::adapters::filter_map::FilterMap<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}>, <parley::layout::line::Line<()>>::runs::{closure#0}>, parley::layout::run::Clusters<()>, gpui_canvas::text::planner::freeze_line::{closure#0}>, gpui_canvas::text::planner::freeze_line::{closure#1}>, gpui_canvas::text::planner::freeze_line::{closure#2}> as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::traits::iterator::Iterator::min_by::fold<usize, <usize as core::cmp::Ord>::cmp>::{closure#0}>>
  66bdbf:	4c 39 f0             	cmp    %r14,%rax
  66bdc2:	4c 0f 42 f0          	cmovb  %rax,%r14
  66bdc6:	48 8b 9c 24 00 01 00 	mov    0x100(%rsp),%rbx
  66bdcd:	00 
  66bdce:	eb 1a                	jmp    66bdea <<gpui_canvas::text::planner::Planner>::shape+0x115a>
  66bdd0:	80 bc 24 00 07 00 00 	cmpb   $0x2,0x700(%rsp)
  66bdd7:	02 
  66bdd8:	c6 84 24 f0 05 00 00 	movb   $0x2,0x5f0(%rsp)
  66bddf:	02 
  66bde0:	48 8b 9c 24 00 01 00 	mov    0x100(%rsp),%rbx
  66bde7:	00 
  66bde8:	75 36                	jne    66be20 <<gpui_canvas::text::planner::Planner>::shape+0x1190>
  66bdea:	4d 39 f7             	cmp    %r14,%r15
  66bded:	0f 87 67 1e 00 00    	ja     66dc5a <<gpui_canvas::text::planner::Planner>::shape+0x2fca>
  66bdf3:	4d 85 ff             	test   %r15,%r15
  66bdf6:	0f 84 a0 00 00 00    	je     66be9c <<gpui_canvas::text::planner::Planner>::shape+0x120c>
  66bdfc:	4c 3b bc 24 10 01 00 	cmp    0x110(%rsp),%r15
  66be03:	00 
  66be04:	0f 83 8c 00 00 00    	jae    66be96 <<gpui_canvas::text::planner::Planner>::shape+0x1206>
  66be0a:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  66be0f:	42 80 3c 38 bf       	cmpb   $0xbf,(%rax,%r15,1)
  66be14:	0f 8f 82 00 00 00    	jg     66be9c <<gpui_canvas::text::planner::Planner>::shape+0x120c>
  66be1a:	e9 3b 1e 00 00       	jmp    66dc5a <<gpui_canvas::text::planner::Planner>::shape+0x2fca>
  66be1f:	90                   	nop
  66be20:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  66be27:	00 
  66be28:	48 8d b4 24 f8 05 00 	lea    0x5f8(%rsp),%rsi
  66be2f:	00 
  66be30:	e8 4b 71 01 00       	call   682f80 <<parley::layout::run::Clusters<()> as core::iter::traits::iterator::Iterator>::next>
  66be35:	48 8b 8c 24 10 07 00 	mov    0x710(%rsp),%rcx
  66be3c:	00 
  66be3d:	48 85 c9             	test   %rcx,%rcx
  66be40:	74 a8                	je     66bdea <<gpui_canvas::text::planner::Planner>::shape+0x115a>
  66be42:	8b bc 24 38 07 00 00 	mov    0x738(%rsp),%edi
  66be49:	48 8b 41 58          	mov    0x58(%rcx),%rax
  66be4d:	48 39 f8             	cmp    %rdi,%rax
  66be50:	0f 86 32 24 00 00    	jbe    66e288 <<gpui_canvas::text::planner::Planner>::shape+0x35f8>
  66be56:	8b b4 24 90 07 00 00 	mov    0x790(%rsp),%esi
  66be5d:	8b 94 24 94 07 00 00 	mov    0x794(%rsp),%edx
  66be64:	4c 8b 41 70          	mov    0x70(%rcx),%r8
  66be68:	39 f2                	cmp    %esi,%edx
  66be6a:	0f 82 fb 22 00 00    	jb     66e16b <<gpui_canvas::text::planner::Planner>::shape+0x34db>
  66be70:	49 39 d0             	cmp    %rdx,%r8
  66be73:	0f 82 f2 22 00 00    	jb     66e16b <<gpui_canvas::text::planner::Planner>::shape+0x34db>
  66be79:	39 f2                	cmp    %esi,%edx
  66be7b:	0f 84 18 24 00 00    	je     66e299 <<gpui_canvas::text::planner::Planner>::shape+0x3609>
  66be81:	4c 8b 41 68          	mov    0x68(%rcx),%r8
  66be85:	4c 8d 0c 76          	lea    (%rsi,%rsi,2),%r9
  66be89:	43 80 7c 88 07 06    	cmpb   $0x6,0x7(%r8,%r9,4)
  66be8f:	75 8f                	jne    66be20 <<gpui_canvas::text::planner::Planner>::shape+0x1190>
  66be91:	e9 99 fe ff ff       	jmp    66bd2f <<gpui_canvas::text::planner::Planner>::shape+0x109f>
  66be96:	0f 85 be 1d 00 00    	jne    66dc5a <<gpui_canvas::text::planner::Planner>::shape+0x2fca>
  66be9c:	4d 85 f6             	test   %r14,%r14
  66be9f:	74 21                	je     66bec2 <<gpui_canvas::text::planner::Planner>::shape+0x1232>
  66bea1:	4c 3b b4 24 10 01 00 	cmp    0x110(%rsp),%r14
  66bea8:	00 
  66bea9:	73 11                	jae    66bebc <<gpui_canvas::text::planner::Planner>::shape+0x122c>
  66beab:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  66beb0:	42 80 3c 30 c0       	cmpb   $0xc0,(%rax,%r14,1)
  66beb5:	7d 0b                	jge    66bec2 <<gpui_canvas::text::planner::Planner>::shape+0x1232>
  66beb7:	e9 9e 1d 00 00       	jmp    66dc5a <<gpui_canvas::text::planner::Planner>::shape+0x2fca>
  66bebc:	0f 85 98 1d 00 00    	jne    66dc5a <<gpui_canvas::text::planner::Planner>::shape+0x2fca>
  66bec2:	0f 57 c0             	xorps  %xmm0,%xmm0
  66bec5:	48 39 eb             	cmp    %rbp,%rbx
  66bec8:	74 0d                	je     66bed7 <<gpui_canvas::text::planner::Planner>::shape+0x1247>
  66beca:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  66bed1:	00 
  66bed2:	f3 0f 10 40 30       	movss  0x30(%rax),%xmm0
  66bed7:	f3 0f 11 44 24 60    	movss  %xmm0,0x60(%rsp)
  66bedd:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  66bee4:	00 
  66bee5:	f3 0f 10 48 40       	movss  0x40(%rax),%xmm1
  66beea:	f3 0f 10 40 44       	movss  0x44(%rax),%xmm0
  66beef:	0f 29 8c 24 90 02 00 	movaps %xmm1,0x290(%rsp)
  66bef6:	00 
  66bef7:	f3 0f 5d 48 48       	minss  0x48(%rax),%xmm1
  66befc:	0f 29 8c 24 a0 01 00 	movaps %xmm1,0x1a0(%rsp)
  66bf03:	00 
  66bf04:	0f 29 84 24 d0 01 00 	movaps %xmm0,0x1d0(%rsp)
  66bf0b:	00 
  66bf0c:	f3 0f 5f 40 4c       	maxss  0x4c(%rax),%xmm0
  66bf11:	0f 29 84 24 20 01 00 	movaps %xmm0,0x120(%rsp)
  66bf18:	00 
  66bf19:	f3 0f 10 40 24       	movss  0x24(%rax),%xmm0
  66bf1e:	f3 0f 58 44 24 1c    	addss  0x1c(%rsp),%xmm0
  66bf24:	f3 0f 11 44 24 08    	movss  %xmm0,0x8(%rsp)
  66bf2a:	48 8b 9c 24 78 01 00 	mov    0x178(%rsp),%rbx
  66bf31:	00 
  66bf32:	48 3b 9c 24 68 01 00 	cmp    0x168(%rsp),%rbx
  66bf39:	00 
  66bf3a:	75 0e                	jne    66bf4a <<gpui_canvas::text::planner::Planner>::shape+0x12ba>
  66bf3c:	48 8d bc 24 68 01 00 	lea    0x168(%rsp),%rdi
  66bf43:	00 
  66bf44:	ff 15 b6 f1 11 00    	call   *0x11f1b6(%rip)        # 78b100 <_DYNAMIC+0x518>
  66bf4a:	41 01 ef             	add    %ebp,%r15d
  66bf4d:	41 01 ee             	add    %ebp,%r14d
  66bf50:	0f 28 94 24 a0 01 00 	movaps 0x1a0(%rsp),%xmm2
  66bf57:	00 
  66bf58:	0f 28 c2             	movaps %xmm2,%xmm0
  66bf5b:	f3 0f c2 c2 03       	cmpunordss %xmm2,%xmm0
  66bf60:	0f 28 c8             	movaps %xmm0,%xmm1
  66bf63:	0f 55 ca             	andnps %xmm2,%xmm1
  66bf66:	0f 54 84 24 90 02 00 	andps  0x290(%rsp),%xmm0
  66bf6d:	00 
  66bf6e:	0f 56 c1             	orps   %xmm1,%xmm0
  66bf71:	f3 0f 10 4c 24 1c    	movss  0x1c(%rsp),%xmm1
  66bf77:	f3 0f 58 c8          	addss  %xmm0,%xmm1
  66bf7b:	0f 28 a4 24 20 01 00 	movaps 0x120(%rsp),%xmm4
  66bf82:	00 
  66bf83:	0f 28 d4             	movaps %xmm4,%xmm2
  66bf86:	f3 0f c2 d4 03       	cmpunordss %xmm4,%xmm2
  66bf8b:	0f 28 da             	movaps %xmm2,%xmm3
  66bf8e:	0f 55 dc             	andnps %xmm4,%xmm3
  66bf91:	0f 54 94 24 d0 01 00 	andps  0x1d0(%rsp),%xmm2
  66bf98:	00 
  66bf99:	0f 56 d3             	orps   %xmm3,%xmm2
  66bf9c:	f3 0f 5c d0          	subss  %xmm0,%xmm2
  66bfa0:	48 8b 84 24 70 01 00 	mov    0x170(%rsp),%rax
  66bfa7:	00 
  66bfa8:	48 8d 0c 5b          	lea    (%rbx,%rbx,2),%rcx
  66bfac:	44 89 3c c8          	mov    %r15d,(%rax,%rcx,8)
  66bfb0:	44 89 74 c8 04       	mov    %r14d,0x4(%rax,%rcx,8)
  66bfb5:	f3 0f 11 4c c8 08    	movss  %xmm1,0x8(%rax,%rcx,8)
  66bfbb:	f3 0f 11 54 c8 0c    	movss  %xmm2,0xc(%rax,%rcx,8)
  66bfc1:	f3 0f 10 44 24 08    	movss  0x8(%rsp),%xmm0
  66bfc7:	f3 0f 11 44 c8 10    	movss  %xmm0,0x10(%rax,%rcx,8)
  66bfcd:	f3 0f 10 44 24 60    	movss  0x60(%rsp),%xmm0
  66bfd3:	f3 0f 11 44 c8 14    	movss  %xmm0,0x14(%rax,%rcx,8)
  66bfd9:	48 ff c3             	inc    %rbx
  66bfdc:	48 89 9c 24 78 01 00 	mov    %rbx,0x178(%rsp)
  66bfe3:	00 
  66bfe4:	44 89 b4 24 18 02 00 	mov    %r14d,0x218(%rsp)
  66bfeb:	00 
  66bfec:	8b 4c 24 78          	mov    0x78(%rsp),%ecx
  66bff0:	48 c7 84 24 10 07 00 	movq   $0x0,0x710(%rsp)
  66bff7:	00 00 00 00 00 
  66bffc:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  66c001:	48 89 84 24 18 07 00 	mov    %rax,0x718(%rsp)
  66c008:	00 
  66c009:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  66c010:	00 
  66c011:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
  66c018:	00 
  66c019:	48 83 c0 70          	add    $0x70,%rax
  66c01d:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
  66c024:	00 
  66c025:	89 8c 24 28 07 00 00 	mov    %ecx,0x728(%rsp)
  66c02c:	ff c1                	inc    %ecx
  66c02e:	89 4c 24 78          	mov    %ecx,0x78(%rsp)
  66c032:	c6 84 24 d0 07 00 00 	movb   $0x2,0x7d0(%rsp)
  66c039:	02 
  66c03a:	c7 84 24 d8 07 00 00 	movl   $0x0,0x7d8(%rsp)
  66c041:	00 00 00 00 
  66c045:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
  66c04c:	00 
  66c04d:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
  66c054:	00 
  66c055:	e8 26 b6 00 00       	call   677680 <<parley::layout::line::GlyphRunIter<()> as core::iter::traits::iterator::Iterator>::next>
  66c05a:	83 bc 24 40 03 00 00 	cmpl   $0x1,0x340(%rsp)
  66c061:	01 
  66c062:	0f 85 4a 0f 00 00    	jne    66cfb2 <<gpui_canvas::text::planner::Planner>::shape+0x2322>
  66c068:	48 8b 84 24 48 03 00 	mov    0x348(%rsp),%rax
  66c06f:	00 
  66c070:	48 85 c0             	test   %rax,%rax
  66c073:	0f 84 d1 1b 00 00    	je     66dc4a <<gpui_canvas::text::planner::Planner>::shape+0x2fba>
  66c079:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
  66c080:	00 
  66c081:	41 0f 10 45 00       	movups 0x0(%r13),%xmm0
  66c086:	41 0f 10 4d 10       	movups 0x10(%r13),%xmm1
  66c08b:	41 0f 10 55 20       	movups 0x20(%r13),%xmm2
  66c090:	41 0f 10 5d 30       	movups 0x30(%r13),%xmm3
  66c095:	48 8d 8c 24 a0 03 00 	lea    0x3a0(%rsp),%rcx
  66c09c:	00 
  66c09d:	0f 11 59 30          	movups %xmm3,0x30(%rcx)
  66c0a1:	0f 11 51 20          	movups %xmm2,0x20(%rcx)
  66c0a5:	0f 11 49 10          	movups %xmm1,0x10(%rcx)
  66c0a9:	0f 11 01             	movups %xmm0,(%rcx)
  66c0ac:	4c 8b 9c 24 a0 03 00 	mov    0x3a0(%rsp),%r11
  66c0b3:	00 
  66c0b4:	49 8b 4b 30          	mov    0x30(%r11),%rcx
  66c0b8:	49 8b 73 38          	mov    0x38(%r11),%rsi
  66c0bc:	48 89 f2             	mov    %rsi,%rdx
  66c0bf:	48 29 ca             	sub    %rcx,%rdx
  66c0c2:	40 0f 92 c7          	setb   %dil
  66c0c6:	48 3b b0 d0 00 00 00 	cmp    0xd0(%rax),%rsi
  66c0cd:	40 0f 97 c6          	seta   %sil
  66c0d1:	48 01 c9             	add    %rcx,%rcx
  66c0d4:	48 03 88 c8 00 00 00 	add    0xc8(%rax),%rcx
  66c0db:	40 08 fe             	or     %dil,%sil
  66c0de:	40 84 f6             	test   %sil,%sil
  66c0e1:	be 00 00 00 00       	mov    $0x0,%esi
  66c0e6:	48 0f 45 d6          	cmovne %rsi,%rdx
  66c0ea:	be 02 00 00 00       	mov    $0x2,%esi
  66c0ef:	48 0f 45 ce          	cmovne %rsi,%rcx
  66c0f3:	48 01 d2             	add    %rdx,%rdx
  66c0f6:	31 f6                	xor    %esi,%esi
  66c0f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  66c0ff:	00 
  66c100:	48 39 f2             	cmp    %rsi,%rdx
  66c103:	74 10                	je     66c115 <<gpui_canvas::text::planner::Planner>::shape+0x1485>
  66c105:	66 83 3c 31 00       	cmpw   $0x0,(%rcx,%rsi,1)
  66c10a:	48 8d 76 02          	lea    0x2(%rsi),%rsi
  66c10e:	74 f0                	je     66c100 <<gpui_canvas::text::planner::Planner>::shape+0x1470>
  66c110:	e9 77 17 00 00       	jmp    66d88c <<gpui_canvas::text::planner::Planner>::shape+0x2bfc>
  66c115:	49 8b 4b 40          	mov    0x40(%r11),%rcx
  66c119:	48 3b 88 b8 00 00 00 	cmp    0xb8(%rax),%rcx
  66c120:	0f 83 d4 20 00 00    	jae    66e1fa <<gpui_canvas::text::planner::Planner>::shape+0x356a>
  66c126:	48 c1 e1 06          	shl    $0x6,%rcx
  66c12a:	48 03 88 b0 00 00 00 	add    0xb0(%rax),%rcx
  66c131:	48 8b 34 24          	mov    (%rsp),%rsi
  66c135:	83 3e 01             	cmpl   $0x1,(%rsi)
  66c138:	75 0f                	jne    66c149 <<gpui_canvas::text::planner::Planner>::shape+0x14b9>
  66c13a:	48 8b 56 08          	mov    0x8(%rsi),%rdx
  66c13e:	48 3b 51 10          	cmp    0x10(%rcx),%rdx
  66c142:	75 05                	jne    66c149 <<gpui_canvas::text::planner::Planner>::shape+0x14b9>
  66c144:	45 31 c0             	xor    %r8d,%r8d
  66c147:	eb 4c                	jmp    66c195 <<gpui_canvas::text::planner::Planner>::shape+0x1505>
  66c149:	83 7e 10 01          	cmpl   $0x1,0x10(%rsi)
  66c14d:	75 10                	jne    66c15f <<gpui_canvas::text::planner::Planner>::shape+0x14cf>
  66c14f:	48 8b 56 18          	mov    0x18(%rsi),%rdx
  66c153:	41 b8 01 00 00 00    	mov    $0x1,%r8d
  66c159:	48 3b 51 10          	cmp    0x10(%rcx),%rdx
  66c15d:	74 1e                	je     66c17d <<gpui_canvas::text::planner::Planner>::shape+0x14ed>
  66c15f:	83 7e 20 01          	cmpl   $0x1,0x20(%rsi)
  66c163:	0f 85 0f 1b 00 00    	jne    66dc78 <<gpui_canvas::text::planner::Planner>::shape+0x2fe8>
  66c169:	48 8b 56 28          	mov    0x28(%rsi),%rdx
  66c16d:	41 b8 02 00 00 00    	mov    $0x2,%r8d
  66c173:	48 3b 51 10          	cmp    0x10(%rcx),%rdx
  66c177:	0f 85 fb 1a 00 00    	jne    66dc78 <<gpui_canvas::text::planner::Planner>::shape+0x2fe8>
  66c17d:	41 8d 48 ff          	lea    -0x1(%r8),%ecx
  66c181:	48 8b 94 24 08 02 00 	mov    0x208(%rsp),%rdx
  66c188:	00 
  66c189:	48 0f ab ca          	bts    %rcx,%rdx
  66c18d:	48 89 94 24 08 02 00 	mov    %rdx,0x208(%rsp)
  66c194:	00 
  66c195:	8b bc 24 c0 03 00 00 	mov    0x3c0(%rsp),%edi
  66c19c:	48 8b 70 58          	mov    0x58(%rax),%rsi
  66c1a0:	48 39 fe             	cmp    %rdi,%rsi
  66c1a3:	0f 86 17 21 00 00    	jbe    66e2c0 <<gpui_canvas::text::planner::Planner>::shape+0x3630>
  66c1a9:	48 8b 94 24 b0 03 00 	mov    0x3b0(%rsp),%rdx
  66c1b0:	00 
  66c1b1:	48 85 d2             	test   %rdx,%rdx
  66c1b4:	4c 89 84 24 60 02 00 	mov    %r8,0x260(%rsp)
  66c1bb:	00 
  66c1bc:	48 89 94 24 e8 02 00 	mov    %rdx,0x2e8(%rsp)
  66c1c3:	00 
  66c1c4:	74 0a                	je     66c1d0 <<gpui_canvas::text::planner::Planner>::shape+0x1540>
  66c1c6:	48 8d 4a 18          	lea    0x18(%rdx),%rcx
  66c1ca:	48 83 c2 1c          	add    $0x1c,%rdx
  66c1ce:	eb 1b                	jmp    66c1eb <<gpui_canvas::text::planner::Planner>::shape+0x155b>
  66c1d0:	48 8b 48 50          	mov    0x50(%rax),%rcx
  66c1d4:	48 8d 34 ff          	lea    (%rdi,%rdi,8),%rsi
  66c1d8:	48 c1 e6 04          	shl    $0x4,%rsi
  66c1dc:	48 8d 14 31          	lea    (%rcx,%rsi,1),%rdx
  66c1e0:	48 83 c2 54          	add    $0x54,%rdx
  66c1e4:	48 01 f1             	add    %rsi,%rcx
  66c1e7:	48 83 c1 50          	add    $0x50,%rcx
  66c1eb:	48 8b b4 24 f8 00 00 	mov    0xf8(%rsp),%rsi
  66c1f2:	00 
  66c1f3:	48 89 b4 24 f0 02 00 	mov    %rsi,0x2f0(%rsp)
  66c1fa:	00 
  66c1fb:	48 8b 70 68          	mov    0x68(%rax),%rsi
  66c1ff:	48 8b 78 70          	mov    0x70(%rax),%rdi
  66c203:	4c 8b 80 80 00 00 00 	mov    0x80(%rax),%r8
  66c20a:	4c 8b 88 88 00 00 00 	mov    0x88(%rax),%r9
  66c211:	4c 8b 90 98 00 00 00 	mov    0x98(%rax),%r10
  66c218:	48 8b 80 a0 00 00 00 	mov    0xa0(%rax),%rax
  66c21f:	8b 12                	mov    (%rdx),%edx
  66c221:	8b 09                	mov    (%rcx),%ecx
  66c223:	4c 89 9c 24 48 02 00 	mov    %r11,0x248(%rsp)
  66c22a:	00 
  66c22b:	45 0f b6 9b 8c 00 00 	movzbl 0x8c(%r11),%r11d
  66c232:	00 
  66c233:	41 80 e3 01          	and    $0x1,%r11b
  66c237:	89 d3                	mov    %edx,%ebx
  66c239:	29 cb                	sub    %ecx,%ebx
  66c23b:	48 c7 84 24 c0 04 00 	movq   $0x0,0x4c0(%rsp)
  66c242:	00 00 00 00 00 
  66c247:	48 c7 84 24 e0 04 00 	movq   $0x0,0x4e0(%rsp)
  66c24e:	00 00 00 00 00 
  66c253:	c7 84 24 00 05 00 00 	movl   $0x0,0x500(%rsp)
  66c25a:	00 00 00 00 
  66c25e:	89 9c 24 04 05 00 00 	mov    %ebx,0x504(%rsp)
  66c265:	48 89 b4 24 08 05 00 	mov    %rsi,0x508(%rsp)
  66c26c:	00 
  66c26d:	48 89 bc 24 10 05 00 	mov    %rdi,0x510(%rsp)
  66c274:	00 
  66c275:	4c 89 84 24 18 05 00 	mov    %r8,0x518(%rsp)
  66c27c:	00 
  66c27d:	4c 89 8c 24 20 05 00 	mov    %r9,0x520(%rsp)
  66c284:	00 
  66c285:	4c 89 94 24 28 05 00 	mov    %r10,0x528(%rsp)
  66c28c:	00 
  66c28d:	48 89 84 24 30 05 00 	mov    %rax,0x530(%rsp)
  66c294:	00 
  66c295:	89 8c 24 38 05 00 00 	mov    %ecx,0x538(%rsp)
  66c29c:	89 94 24 3c 05 00 00 	mov    %edx,0x53c(%rsp)
  66c2a3:	89 8c 24 40 05 00 00 	mov    %ecx,0x540(%rsp)
  66c2aa:	89 94 24 44 05 00 00 	mov    %edx,0x544(%rsp)
  66c2b1:	44 88 9c 24 48 05 00 	mov    %r11b,0x548(%rsp)
  66c2b8:	00 
  66c2b9:	f2 0f 10 84 24 d0 03 	movsd  0x3d0(%rsp),%xmm0
  66c2c0:	00 00 
  66c2c2:	0f 29 84 24 e0 03 00 	movaps %xmm0,0x3e0(%rsp)
  66c2c9:	00 
  66c2ca:	8b 94 24 c8 03 00 00 	mov    0x3c8(%rsp),%edx
  66c2d1:	8b 8c 24 cc 03 00 00 	mov    0x3cc(%rsp),%ecx
  66c2d8:	48 8d bc 24 f8 03 00 	lea    0x3f8(%rsp),%rdi
  66c2df:	00 
  66c2e0:	48 8d b4 24 98 03 00 	lea    0x398(%rsp),%rsi
  66c2e7:	00 
  66c2e8:	e8 b3 42 01 00       	call   6805a0 <<parley::layout::run::Run<()>>::glyphs_in>
  66c2ed:	0f 28 94 24 e0 03 00 	movaps 0x3e0(%rsp),%xmm2
  66c2f4:	00 
  66c2f5:	0f 13 94 24 90 04 00 	movlps %xmm2,0x490(%rsp)
  66c2fc:	00 
  66c2fd:	48 8b 9c 24 f8 03 00 	mov    0x3f8(%rsp),%rbx
  66c304:	00 
  66c305:	48 8b 84 24 00 04 00 	mov    0x400(%rsp),%rax
  66c30c:	00 
  66c30d:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  66c314:	00 
  66c315:	0f b6 84 24 08 04 00 	movzbl 0x408(%rsp),%eax
  66c31c:	00 
  66c31d:	8b 8c 24 0c 04 00 00 	mov    0x40c(%rsp),%ecx
  66c324:	89 8c 24 bc 01 00 00 	mov    %ecx,0x1bc(%rsp)
  66c32b:	f2 0f 10 84 24 10 04 	movsd  0x410(%rsp),%xmm0
  66c332:	00 00 
  66c334:	0f 29 84 24 30 02 00 	movaps %xmm0,0x230(%rsp)
  66c33b:	00 
  66c33c:	f3 0f 10 84 24 18 04 	movss  0x418(%rsp),%xmm0
  66c343:	00 00 
  66c345:	f3 0f 11 84 24 b8 01 	movss  %xmm0,0x1b8(%rsp)
  66c34c:	00 00 
  66c34e:	48 8b 8c 24 20 04 00 	mov    0x420(%rsp),%rcx
  66c355:	00 
  66c356:	48 89 8c 24 68 02 00 	mov    %rcx,0x268(%rsp)
  66c35d:	00 
  66c35e:	48 8b 8c 24 28 04 00 	mov    0x428(%rsp),%rcx
  66c365:	00 
  66c366:	48 89 8c 24 00 02 00 	mov    %rcx,0x200(%rsp)
  66c36d:	00 
  66c36e:	48 8b 94 24 30 04 00 	mov    0x430(%rsp),%rdx
  66c375:	00 
  66c376:	4c 8b b4 24 38 04 00 	mov    0x438(%rsp),%r14
  66c37d:	00 
  66c37e:	48 8b 8c 24 40 04 00 	mov    0x440(%rsp),%rcx
  66c385:	00 
  66c386:	48 89 8c 24 78 02 00 	mov    %rcx,0x278(%rsp)
  66c38d:	00 
  66c38e:	48 8b 8c 24 48 04 00 	mov    0x448(%rsp),%rcx
  66c395:	00 
  66c396:	48 89 8c 24 40 01 00 	mov    %rcx,0x140(%rsp)
  66c39d:	00 
  66c39e:	8b 8c 24 50 04 00 00 	mov    0x450(%rsp),%ecx
  66c3a5:	48 89 8c 24 f0 01 00 	mov    %rcx,0x1f0(%rsp)
  66c3ac:	00 
  66c3ad:	8b 8c 24 54 04 00 00 	mov    0x454(%rsp),%ecx
  66c3b4:	48 89 8c 24 f8 01 00 	mov    %rcx,0x1f8(%rsp)
  66c3bb:	00 
  66c3bc:	8b 8c 24 58 04 00 00 	mov    0x458(%rsp),%ecx
  66c3c3:	48 89 8c 24 20 01 00 	mov    %rcx,0x120(%rsp)
  66c3ca:	00 
  66c3cb:	44 8b bc 24 5c 04 00 	mov    0x45c(%rsp),%r15d
  66c3d2:	00 
  66c3d3:	f3 0f 10 84 24 60 04 	movss  0x460(%rsp),%xmm0
  66c3da:	00 00 
  66c3dc:	f3 0f 11 84 24 c0 01 	movss  %xmm0,0x1c0(%rsp)
  66c3e3:	00 00 
  66c3e5:	f3 0f 10 84 24 64 04 	movss  0x464(%rsp),%xmm0
  66c3ec:	00 00 
  66c3ee:	f3 0f 11 44 24 58    	movss  %xmm0,0x58(%rsp)
  66c3f4:	48 8b 8c 24 68 04 00 	mov    0x468(%rsp),%rcx
  66c3fb:	00 
  66c3fc:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
  66c401:	f3 0f 10 84 24 80 04 	movss  0x480(%rsp),%xmm0
  66c408:	00 00 
  66c40a:	f3 0f 10 8c 24 7c 04 	movss  0x47c(%rsp),%xmm1
  66c411:	00 00 
  66c413:	f3 0f 11 84 24 28 02 	movss  %xmm0,0x228(%rsp)
  66c41a:	00 00 
  66c41c:	f3 0f 58 c8          	addss  %xmm0,%xmm1
  66c420:	f3 0f 10 84 24 84 04 	movss  0x484(%rsp),%xmm0
  66c427:	00 00 
  66c429:	f3 0f 11 8c 24 24 02 	movss  %xmm1,0x224(%rsp)
  66c430:	00 00 
  66c432:	f3 0f 58 c1          	addss  %xmm1,%xmm0
  66c436:	f3 0f 11 84 24 1c 02 	movss  %xmm0,0x21c(%rsp)
  66c43d:	00 00 
  66c43f:	0f 28 c2             	movaps %xmm2,%xmm0
  66c442:	0f b6 8c 24 8c 04 00 	movzbl 0x48c(%rsp),%ecx
  66c449:	00 
  66c44a:	88 8c 24 90 02 00 00 	mov    %cl,0x290(%rsp)
  66c451:	48 8b 8c 24 70 04 00 	mov    0x470(%rsp),%rcx
  66c458:	00 
  66c459:	48 89 8c 24 38 01 00 	mov    %rcx,0x138(%rsp)
  66c460:	00 
  66c461:	8b 8c 24 78 04 00 00 	mov    0x478(%rsp),%ecx
  66c468:	89 8c 24 dc 00 00 00 	mov    %ecx,0xdc(%rsp)
  66c46f:	8b 8c 24 88 04 00 00 	mov    0x488(%rsp),%ecx
  66c476:	89 8c 24 20 02 00 00 	mov    %ecx,0x220(%rsp)
  66c47d:	48 8d 4a 16          	lea    0x16(%rdx),%rcx
  66c481:	48 89 8c 24 50 02 00 	mov    %rcx,0x250(%rsp)
  66c488:	00 
  66c489:	48 89 94 24 d0 01 00 	mov    %rdx,0x1d0(%rsp)
  66c490:	00 
  66c491:	48 8d 4a 2e          	lea    0x2e(%rdx),%rcx
  66c495:	48 89 8c 24 00 03 00 	mov    %rcx,0x300(%rsp)
  66c49c:	00 
  66c49d:	4c 89 b4 24 e8 01 00 	mov    %r14,0x1e8(%rsp)
  66c4a4:	00 
  66c4a5:	eb 6e                	jmp    66c515 <<gpui_canvas::text::planner::Planner>::shape+0x1885>
  66c4a7:	03 6c 24 30          	add    0x30(%rsp),%ebp
  66c4ab:	0f 28 8c 24 a0 01 00 	movaps 0x1a0(%rsp),%xmm1
  66c4b2:	00 
  66c4b3:	f3 0f 58 4c 24 1c    	addss  0x1c(%rsp),%xmm1
  66c4b9:	48 8b 84 24 f0 00 00 	mov    0xf0(%rsp),%rax
  66c4c0:	00 
  66c4c1:	4c 89 f1             	mov    %r14,%rcx
  66c4c4:	48 c1 e1 04          	shl    $0x4,%rcx
  66c4c8:	89 2c 08             	mov    %ebp,(%rax,%rcx,1)
  66c4cb:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  66c4d1:	f3 0f 11 44 08 04    	movss  %xmm0,0x4(%rax,%rcx,1)
  66c4d7:	f3 0f 11 4c 08 08    	movss  %xmm1,0x8(%rax,%rcx,1)
  66c4dd:	8b 54 24 5c          	mov    0x5c(%rsp),%edx
  66c4e1:	66 89 54 08 0c       	mov    %dx,0xc(%rax,%rcx,1)
  66c4e6:	48 8b 94 24 60 02 00 	mov    0x260(%rsp),%rdx
  66c4ed:	00 
  66c4ee:	88 54 08 0e          	mov    %dl,0xe(%rax,%rcx,1)
  66c4f2:	c6 44 08 0f 00       	movb   $0x0,0xf(%rax,%rcx,1)
  66c4f7:	49 ff c6             	inc    %r14
  66c4fa:	4c 89 b4 24 f8 00 00 	mov    %r14,0xf8(%rsp)
  66c501:	00 
  66c502:	31 c0                	xor    %eax,%eax
  66c504:	4c 8b b4 24 e8 01 00 	mov    0x1e8(%rsp),%r14
  66c50b:	00 
  66c50c:	f3 0f 10 84 24 c4 01 	movss  0x1c4(%rsp),%xmm0
  66c513:	00 00 
  66c515:	f3 0f 11 44 24 0c    	movss  %xmm0,0xc(%rsp)
  66c51b:	a8 01                	test   $0x1,%al
  66c51d:	74 61                	je     66c580 <<gpui_canvas::text::planner::Planner>::shape+0x18f0>
  66c51f:	f3 0f 10 84 24 b8 01 	movss  0x1b8(%rsp),%xmm0
  66c526:	00 00 
  66c528:	f3 0f 11 44 24 08    	movss  %xmm0,0x8(%rsp)
  66c52e:	8b 84 24 bc 01 00 00 	mov    0x1bc(%rsp),%eax
  66c535:	89 44 24 5c          	mov    %eax,0x5c(%rsp)
  66c539:	0f 28 84 24 30 02 00 	movaps 0x230(%rsp),%xmm0
  66c540:	00 
  66c541:	0f 29 84 24 a0 01 00 	movaps %xmm0,0x1a0(%rsp)
  66c548:	00 
  66c549:	83 bc 24 dc 00 00 00 	cmpl   $0x0,0xdc(%rsp)
  66c550:	00 
  66c551:	74 71                	je     66c5c4 <<gpui_canvas::text::planner::Planner>::shape+0x1934>
  66c553:	48 83 7c 24 60 00    	cmpq   $0x0,0x60(%rsp)
  66c559:	74 7c                	je     66c5d7 <<gpui_canvas::text::planner::Planner>::shape+0x1947>
  66c55b:	0f 28 84 24 a0 01 00 	movaps 0x1a0(%rsp),%xmm0
  66c562:	00 
  66c563:	f3 0f 11 84 24 d8 00 	movss  %xmm0,0xd8(%rsp)
  66c56a:	00 00 
  66c56c:	e9 94 00 00 00       	jmp    66c605 <<gpui_canvas::text::planner::Planner>::shape+0x1975>
  66c571:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  66c578:	0f 1f 84 00 00 00 00 
  66c57f:	00 
  66c580:	48 3b 9c 24 c0 00 00 	cmp    0xc0(%rsp),%rbx
  66c587:	00 
  66c588:	0f 84 3d 01 00 00    	je     66c6cb <<gpui_canvas::text::planner::Planner>::shape+0x1a3b>
  66c58e:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  66c593:	8b 03                	mov    (%rbx),%eax
  66c595:	89 44 24 5c          	mov    %eax,0x5c(%rsp)
  66c599:	f2 0f 10 43 04       	movsd  0x4(%rbx),%xmm0
  66c59e:	0f 29 84 24 a0 01 00 	movaps %xmm0,0x1a0(%rsp)
  66c5a5:	00 
  66c5a6:	f3 0f 10 43 0c       	movss  0xc(%rbx),%xmm0
  66c5ab:	f3 0f 11 44 24 08    	movss  %xmm0,0x8(%rsp)
  66c5b1:	48 83 c3 10          	add    $0x10,%rbx
  66c5b5:	48 89 54 24 60       	mov    %rdx,0x60(%rsp)
  66c5ba:	83 bc 24 dc 00 00 00 	cmpl   $0x0,0xdc(%rsp)
  66c5c1:	00 
  66c5c2:	75 8f                	jne    66c553 <<gpui_canvas::text::planner::Planner>::shape+0x18c3>
  66c5c4:	0f 28 84 24 a0 01 00 	movaps 0x1a0(%rsp),%xmm0
  66c5cb:	00 
  66c5cc:	f3 0f 11 84 24 d8 00 	movss  %xmm0,0xd8(%rsp)
  66c5d3:	00 00 
  66c5d5:	eb 5f                	jmp    66c636 <<gpui_canvas::text::planner::Planner>::shape+0x19a6>
  66c5d7:	f3 0f 10 84 24 c0 01 	movss  0x1c0(%rsp),%xmm0
  66c5de:	00 00 
  66c5e0:	0f 28 c8             	movaps %xmm0,%xmm1
  66c5e3:	f3 0f 58 8c 24 a0 01 	addss  0x1a0(%rsp),%xmm1
  66c5ea:	00 00 
  66c5ec:	f3 0f 11 8c 24 d8 00 	movss  %xmm1,0xd8(%rsp)
  66c5f3:	00 00 
  66c5f5:	f3 0f 10 4c 24 08    	movss  0x8(%rsp),%xmm1
  66c5fb:	f3 0f 58 c8          	addss  %xmm0,%xmm1
  66c5ff:	f3 0f 11 4c 24 08    	movss  %xmm1,0x8(%rsp)
  66c605:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  66c60a:	48 ff c2             	inc    %rdx
  66c60d:	48 8b 84 24 38 01 00 	mov    0x138(%rsp),%rax
  66c614:	00 
  66c615:	48 89 54 24 60       	mov    %rdx,0x60(%rsp)
  66c61a:	48 39 c2             	cmp    %rax,%rdx
  66c61d:	75 17                	jne    66c636 <<gpui_canvas::text::planner::Planner>::shape+0x19a6>
  66c61f:	f3 0f 10 44 24 08    	movss  0x8(%rsp),%xmm0
  66c625:	f3 0f 58 44 24 58    	addss  0x58(%rsp),%xmm0
  66c62b:	f3 0f 11 44 24 08    	movss  %xmm0,0x8(%rsp)
  66c631:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  66c636:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
  66c63d:	00 
  66c63e:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
  66c645:	00 
  66c646:	e8 95 26 00 00       	call   66ece0 <<core::iter::adapters::flatten::FlattenCompat<core::iter::adapters::map::Map<core::ops::range::Range<u32>, <parley::layout::run::Run<()>>::glyph_source_ranges::{closure#0}>, core::iter::sources::repeat_n::RepeatN<core::ops::range::Range<usize>>> as core::iter::traits::iterator::Iterator>::next>
  66c64b:	83 bc 24 88 00 00 00 	cmpl   $0x1,0x88(%rsp)
  66c652:	01 
  66c653:	0f 85 e0 15 00 00    	jne    66dc39 <<gpui_canvas::text::planner::Planner>::shape+0x2fa9>
  66c659:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  66c65f:	f3 0f 58 44 24 08    	addss  0x8(%rsp),%xmm0
  66c665:	31 c0                	xor    %eax,%eax
  66c667:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  66c66c:	48 39 8c 24 00 01 00 	cmp    %rcx,0x100(%rsp)
  66c673:	00 
  66c674:	0f 84 9b fe ff ff    	je     66c515 <<gpui_canvas::text::planner::Planner>::shape+0x1885>
  66c67a:	f3 0f 11 84 24 c4 01 	movss  %xmm0,0x1c4(%rsp)
  66c681:	00 00 
  66c683:	4c 8b 8c 24 90 00 00 	mov    0x90(%rsp),%r9
  66c68a:	00 
  66c68b:	48 8b ac 24 98 00 00 	mov    0x98(%rsp),%rbp
  66c692:	00 
  66c693:	49 39 e9             	cmp    %rbp,%r9
  66c696:	48 8b 8c 24 10 01 00 	mov    0x110(%rsp),%rcx
  66c69d:	00 
  66c69e:	0f 87 85 15 00 00    	ja     66dc29 <<gpui_canvas::text::planner::Planner>::shape+0x2f99>
  66c6a4:	4d 85 c9             	test   %r9,%r9
  66c6a7:	0f 84 f7 04 00 00    	je     66cba4 <<gpui_canvas::text::planner::Planner>::shape+0x1f14>
  66c6ad:	49 39 c9             	cmp    %rcx,%r9
  66c6b0:	0f 83 e8 04 00 00    	jae    66cb9e <<gpui_canvas::text::planner::Planner>::shape+0x1f0e>
  66c6b6:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  66c6bb:	42 80 3c 08 bf       	cmpb   $0xbf,(%rax,%r9,1)
  66c6c0:	0f 8f de 04 00 00    	jg     66cba4 <<gpui_canvas::text::planner::Planner>::shape+0x1f14>
  66c6c6:	e9 5e 15 00 00       	jmp    66dc29 <<gpui_canvas::text::planner::Planner>::shape+0x2f99>
  66c6cb:	48 89 9c 24 c0 00 00 	mov    %rbx,0xc0(%rsp)
  66c6d2:	00 
  66c6d3:	f6 84 24 90 02 00 00 	testb  $0x1,0x290(%rsp)
  66c6da:	01 
  66c6db:	74 19                	je     66c6f6 <<gpui_canvas::text::planner::Planner>::shape+0x1a66>
  66c6dd:	4c 89 fa             	mov    %r15,%rdx
  66c6e0:	48 8b 8c 24 20 01 00 	mov    0x120(%rsp),%rcx
  66c6e7:	00 
  66c6e8:	39 d1                	cmp    %edx,%ecx
  66c6ea:	0f 83 3d 01 00 00    	jae    66c82d <<gpui_canvas::text::planner::Planner>::shape+0x1b9d>
  66c6f0:	ff ca                	dec    %edx
  66c6f2:	89 d0                	mov    %edx,%eax
  66c6f4:	eb 19                	jmp    66c70f <<gpui_canvas::text::planner::Planner>::shape+0x1a7f>
  66c6f6:	4c 89 fa             	mov    %r15,%rdx
  66c6f9:	48 8b ac 24 20 01 00 	mov    0x120(%rsp),%rbp
  66c700:	00 
  66c701:	39 d5                	cmp    %edx,%ebp
  66c703:	0f 83 3f 01 00 00    	jae    66c848 <<gpui_canvas::text::planner::Planner>::shape+0x1bb8>
  66c709:	8d 4d 01             	lea    0x1(%rbp),%ecx
  66c70c:	48 89 e8             	mov    %rbp,%rax
  66c70f:	89 c7                	mov    %eax,%edi
  66c711:	49 39 fe             	cmp    %rdi,%r14
  66c714:	0f 86 29 1b 00 00    	jbe    66e243 <<gpui_canvas::text::planner::Planner>::shape+0x35b3>
  66c71a:	49 89 d7             	mov    %rdx,%r15
  66c71d:	48 8d 04 7f          	lea    (%rdi,%rdi,2),%rax
  66c721:	48 8b 94 24 d0 01 00 	mov    0x1d0(%rsp),%rdx
  66c728:	00 
  66c729:	8b 5c c2 08          	mov    0x8(%rdx,%rax,8),%ebx
  66c72d:	f6 44 c2 17 01       	testb  $0x1,0x17(%rdx,%rax,8)
  66c732:	0f 85 63 05 00 00    	jne    66cc9b <<gpui_canvas::text::planner::Planner>::shape+0x200b>
  66c738:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
  66c73c:	8b 50 0c             	mov    0xc(%rax),%edx
  66c73f:	48 8d 34 1a          	lea    (%rdx,%rbx,1),%rsi
  66c743:	48 3b b4 24 40 01 00 	cmp    0x140(%rsp),%rsi
  66c74a:	00 
  66c74b:	0f 87 27 17 00 00    	ja     66de78 <<gpui_canvas::text::planner::Planner>::shape+0x31e8>
  66c751:	48 c1 e3 04          	shl    $0x4,%rbx
  66c755:	48 03 9c 24 78 02 00 	add    0x278(%rsp),%rbx
  66c75c:	00 
  66c75d:	48 89 d0             	mov    %rdx,%rax
  66c760:	48 c1 e0 04          	shl    $0x4,%rax
  66c764:	48 01 d8             	add    %rbx,%rax
  66c767:	0f 57 c0             	xorps  %xmm0,%xmm0
  66c76a:	0f 29 84 24 30 02 00 	movaps %xmm0,0x230(%rsp)
  66c771:	00 
  66c772:	48 85 d2             	test   %rdx,%rdx
  66c775:	0f 85 bf 06 00 00    	jne    66ce3a <<gpui_canvas::text::planner::Planner>::shape+0x21aa>
  66c77b:	89 ca                	mov    %ecx,%edx
  66c77d:	48 89 94 24 20 01 00 	mov    %rdx,0x120(%rsp)
  66c784:	00 
  66c785:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  66c78c:	00 00 00 00 
  66c790:	f6 84 24 90 02 00 00 	testb  $0x1,0x290(%rsp)
  66c797:	01 
  66c798:	74 16                	je     66c7b0 <<gpui_canvas::text::planner::Planner>::shape+0x1b20>
  66c79a:	44 39 f9             	cmp    %r15d,%ecx
  66c79d:	0f 83 c4 00 00 00    	jae    66c867 <<gpui_canvas::text::planner::Planner>::shape+0x1bd7>
  66c7a3:	41 ff cf             	dec    %r15d
  66c7a6:	4c 89 f8             	mov    %r15,%rax
  66c7a9:	89 ca                	mov    %ecx,%edx
  66c7ab:	89 c1                	mov    %eax,%ecx
  66c7ad:	eb 19                	jmp    66c7c8 <<gpui_canvas::text::planner::Planner>::shape+0x1b38>
  66c7af:	90                   	nop
  66c7b0:	4c 89 fa             	mov    %r15,%rdx
  66c7b3:	39 d1                	cmp    %edx,%ecx
  66c7b5:	0f 83 5c 01 00 00    	jae    66c917 <<gpui_canvas::text::planner::Planner>::shape+0x1c87>
  66c7bb:	8d 41 01             	lea    0x1(%rcx),%eax
  66c7be:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
  66c7c5:	00 
  66c7c6:	89 c2                	mov    %eax,%edx
  66c7c8:	89 cf                	mov    %ecx,%edi
  66c7ca:	49 39 fe             	cmp    %rdi,%r14
  66c7cd:	0f 86 70 1a 00 00    	jbe    66e243 <<gpui_canvas::text::planner::Planner>::shape+0x35b3>
  66c7d3:	48 8d 04 7f          	lea    (%rdi,%rdi,2),%rax
  66c7d7:	48 8b 8c 24 d0 01 00 	mov    0x1d0(%rsp),%rcx
  66c7de:	00 
  66c7df:	8b 5c c1 08          	mov    0x8(%rcx,%rax,8),%ebx
  66c7e3:	f6 44 c1 17 01       	testb  $0x1,0x17(%rcx,%rax,8)
  66c7e8:	0f 85 a5 04 00 00    	jne    66cc93 <<gpui_canvas::text::planner::Planner>::shape+0x2003>
  66c7ee:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
  66c7f2:	8b 78 0c             	mov    0xc(%rax),%edi
  66c7f5:	48 8d 34 1f          	lea    (%rdi,%rbx,1),%rsi
  66c7f9:	48 3b b4 24 40 01 00 	cmp    0x140(%rsp),%rsi
  66c800:	00 
  66c801:	0f 87 71 16 00 00    	ja     66de78 <<gpui_canvas::text::planner::Planner>::shape+0x31e8>
  66c807:	48 c1 e3 04          	shl    $0x4,%rbx
  66c80b:	48 03 9c 24 78 02 00 	add    0x278(%rsp),%rbx
  66c812:	00 
  66c813:	48 89 f8             	mov    %rdi,%rax
  66c816:	48 c1 e0 04          	shl    $0x4,%rax
  66c81a:	48 01 d8             	add    %rbx,%rax
  66c81d:	89 d1                	mov    %edx,%ecx
  66c81f:	48 85 ff             	test   %rdi,%rdi
  66c822:	0f 84 68 ff ff ff    	je     66c790 <<gpui_canvas::text::planner::Planner>::shape+0x1b00>
  66c828:	e9 df 04 00 00       	jmp    66cd0c <<gpui_canvas::text::planner::Planner>::shape+0x207c>
  66c82d:	48 89 d8             	mov    %rbx,%rax
  66c830:	3b 8c 24 f0 01 00 00 	cmp    0x1f0(%rsp),%ecx
  66c837:	0f 95 c2             	setne  %dl
  66c83a:	84 94 24 dc 00 00 00 	test   %dl,0xdc(%rsp)
  66c841:	75 4e                	jne    66c891 <<gpui_canvas::text::planner::Planner>::shape+0x1c01>
  66c843:	e9 0c 06 00 00       	jmp    66ce54 <<gpui_canvas::text::planner::Planner>::shape+0x21c4>
  66c848:	48 89 d8             	mov    %rbx,%rax
  66c84b:	3b 94 24 f8 01 00 00 	cmp    0x1f8(%rsp),%edx
  66c852:	0f 95 c1             	setne  %cl
  66c855:	84 8c 24 dc 00 00 00 	test   %cl,0xdc(%rsp)
  66c85c:	0f 85 df 00 00 00    	jne    66c941 <<gpui_canvas::text::planner::Planner>::shape+0x1cb1>
  66c862:	e9 ed 05 00 00       	jmp    66ce54 <<gpui_canvas::text::planner::Planner>::shape+0x21c4>
  66c867:	0f 57 c0             	xorps  %xmm0,%xmm0
  66c86a:	0f 29 84 24 30 02 00 	movaps %xmm0,0x230(%rsp)
  66c871:	00 
  66c872:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  66c879:	00 
  66c87a:	3b 8c 24 f0 01 00 00 	cmp    0x1f0(%rsp),%ecx
  66c881:	0f 95 c2             	setne  %dl
  66c884:	84 94 24 dc 00 00 00 	test   %dl,0xdc(%rsp)
  66c88b:	0f 84 c3 05 00 00    	je     66ce54 <<gpui_canvas::text::planner::Planner>::shape+0x21c4>
  66c891:	8d 79 ff             	lea    -0x1(%rcx),%edi
  66c894:	49 39 fe             	cmp    %rdi,%r14
  66c897:	0f 86 47 1a 00 00    	jbe    66e2e4 <<gpui_canvas::text::planner::Planner>::shape+0x3654>
  66c89d:	3b bc 24 f0 01 00 00 	cmp    0x1f0(%rsp),%edi
  66c8a4:	76 48                	jbe    66c8ee <<gpui_canvas::text::planner::Planner>::shape+0x1c5e>
  66c8a6:	48 8d 14 7f          	lea    (%rdi,%rdi,2),%rdx
  66c8aa:	48 8b b4 24 50 02 00 	mov    0x250(%rsp),%rsi
  66c8b1:	00 
  66c8b2:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
  66c8b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  66c8bd:	00 00 00 
  66c8c0:	49 39 fe             	cmp    %rdi,%r14
  66c8c3:	0f 86 9b 19 00 00    	jbe    66e264 <<gpui_canvas::text::planner::Planner>::shape+0x35d4>
  66c8c9:	f6 42 01 02          	testb  $0x2,0x1(%rdx)
  66c8cd:	75 1f                	jne    66c8ee <<gpui_canvas::text::planner::Planner>::shape+0x1c5e>
  66c8cf:	48 ff cf             	dec    %rdi
  66c8d2:	48 83 c2 e8          	add    $0xffffffffffffffe8,%rdx
  66c8d6:	39 bc 24 f0 01 00 00 	cmp    %edi,0x1f0(%rsp)
  66c8dd:	72 e1                	jb     66c8c0 <<gpui_canvas::text::planner::Planner>::shape+0x1c30>
  66c8df:	48 8b 94 24 f0 01 00 	mov    0x1f0(%rsp),%rdx
  66c8e6:	00 
  66c8e7:	48 89 d7             	mov    %rdx,%rdi
  66c8ea:	89 d5                	mov    %edx,%ebp
  66c8ec:	eb 02                	jmp    66c8f0 <<gpui_canvas::text::planner::Planner>::shape+0x1c60>
  66c8ee:	89 fd                	mov    %edi,%ebp
  66c8f0:	49 39 fe             	cmp    %rdi,%r14
  66c8f3:	0f 86 f7 19 00 00    	jbe    66e2f0 <<gpui_canvas::text::planner::Planner>::shape+0x3660>
  66c8f9:	48 89 ac 24 20 01 00 	mov    %rbp,0x120(%rsp)
  66c900:	00 
  66c901:	89 ca                	mov    %ecx,%edx
  66c903:	48 ff ca             	dec    %rdx
  66c906:	4c 39 f2             	cmp    %r14,%rdx
  66c909:	0f 83 ed 19 00 00    	jae    66e2fc <<gpui_canvas::text::planner::Planner>::shape+0x366c>
  66c90f:	41 89 cf             	mov    %ecx,%r15d
  66c912:	e9 a8 00 00 00       	jmp    66c9bf <<gpui_canvas::text::planner::Planner>::shape+0x1d2f>
  66c917:	0f 57 c0             	xorps  %xmm0,%xmm0
  66c91a:	0f 29 84 24 30 02 00 	movaps %xmm0,0x230(%rsp)
  66c921:	00 
  66c922:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  66c929:	00 
  66c92a:	3b 94 24 f8 01 00 00 	cmp    0x1f8(%rsp),%edx
  66c931:	0f 95 c1             	setne  %cl
  66c934:	84 8c 24 dc 00 00 00 	test   %cl,0xdc(%rsp)
  66c93b:	0f 84 13 05 00 00    	je     66ce54 <<gpui_canvas::text::planner::Planner>::shape+0x21c4>
  66c941:	49 89 d0             	mov    %rdx,%r8
  66c944:	48 89 d1             	mov    %rdx,%rcx
  66c947:	89 cf                	mov    %ecx,%edi
  66c949:	49 39 fe             	cmp    %rdi,%r14
  66c94c:	0f 86 7d 19 00 00    	jbe    66e2cf <<gpui_canvas::text::planner::Planner>::shape+0x363f>
  66c952:	44 8d 79 01          	lea    0x1(%rcx),%r15d
  66c956:	44 3b bc 24 f8 01 00 	cmp    0x1f8(%rsp),%r15d
  66c95d:	00 
  66c95e:	73 48                	jae    66c9a8 <<gpui_canvas::text::planner::Planner>::shape+0x1d18>
  66c960:	44 89 fa             	mov    %r15d,%edx
  66c963:	48 8d 0c 52          	lea    (%rdx,%rdx,2),%rcx
  66c967:	48 8b b4 24 50 02 00 	mov    0x250(%rsp),%rsi
  66c96e:	00 
  66c96f:	48 8d 34 ce          	lea    (%rsi,%rcx,8),%rsi
  66c973:	49 89 d7             	mov    %rdx,%r15
  66c976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  66c97d:	00 00 00 
  66c980:	4d 39 fe             	cmp    %r15,%r14
  66c983:	0f 86 c3 18 00 00    	jbe    66e24c <<gpui_canvas::text::planner::Planner>::shape+0x35bc>
  66c989:	f6 46 01 02          	testb  $0x2,0x1(%rsi)
  66c98d:	75 19                	jne    66c9a8 <<gpui_canvas::text::planner::Planner>::shape+0x1d18>
  66c98f:	49 ff c7             	inc    %r15
  66c992:	48 83 c6 18          	add    $0x18,%rsi
  66c996:	4c 39 bc 24 f8 01 00 	cmp    %r15,0x1f8(%rsp)
  66c99d:	00 
  66c99e:	75 e0                	jne    66c980 <<gpui_canvas::text::planner::Planner>::shape+0x1cf0>
  66c9a0:	4c 8b bc 24 f8 01 00 	mov    0x1f8(%rsp),%r15
  66c9a7:	00 
  66c9a8:	44 89 fa             	mov    %r15d,%edx
  66c9ab:	48 ff ca             	dec    %rdx
  66c9ae:	4c 39 f2             	cmp    %r14,%rdx
  66c9b1:	0f 83 21 19 00 00    	jae    66e2d8 <<gpui_canvas::text::planner::Planner>::shape+0x3648>
  66c9b7:	4c 89 84 24 20 01 00 	mov    %r8,0x120(%rsp)
  66c9be:	00 
  66c9bf:	48 83 bc 24 68 02 00 	cmpq   $0x0,0x268(%rsp)
  66c9c6:	00 00 
  66c9c8:	0f 84 86 04 00 00    	je     66ce54 <<gpui_canvas::text::planner::Planner>::shape+0x21c4>
  66c9ce:	48 8d 0c 7f          	lea    (%rdi,%rdi,2),%rcx
  66c9d2:	48 8b b4 24 d0 01 00 	mov    0x1d0(%rsp),%rsi
  66c9d9:	00 
  66c9da:	8b 0c ce             	mov    (%rsi,%rcx,8),%ecx
  66c9dd:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
  66c9e1:	8b 74 d6 04          	mov    0x4(%rsi,%rdx,8),%esi
  66c9e5:	39 ce                	cmp    %ecx,%esi
  66c9e7:	0f 82 b3 17 00 00    	jb     66e1a0 <<gpui_canvas::text::planner::Planner>::shape+0x3510>
  66c9ed:	48 39 b4 24 00 02 00 	cmp    %rsi,0x200(%rsp)
  66c9f4:	00 
  66c9f5:	0f 82 a5 17 00 00    	jb     66e1a0 <<gpui_canvas::text::planner::Planner>::shape+0x3510>
  66c9fb:	39 ce                	cmp    %ecx,%esi
  66c9fd:	0f 84 ad 18 00 00    	je     66e2b0 <<gpui_canvas::text::planner::Planner>::shape+0x3620>
  66ca03:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  66ca07:	48 8b 94 24 68 02 00 	mov    0x268(%rsp),%rdx
  66ca0e:	00 
  66ca0f:	0f b6 4c 8a 07       	movzbl 0x7(%rdx,%rcx,4),%ecx
  66ca14:	8d 51 ff             	lea    -0x1(%rcx),%edx
  66ca17:	83 fa 02             	cmp    $0x2,%edx
  66ca1a:	73 26                	jae    66ca42 <<gpui_canvas::text::planner::Planner>::shape+0x1db2>
  66ca1c:	f3 0f 10 84 24 24 02 	movss  0x224(%rsp),%xmm0
  66ca23:	00 00 
  66ca25:	f3 0f 11 44 24 58    	movss  %xmm0,0x58(%rsp)
  66ca2b:	4c 89 fa             	mov    %r15,%rdx
  66ca2e:	3b 94 24 20 02 00 00 	cmp    0x220(%rsp),%edx
  66ca35:	77 2b                	ja     66ca62 <<gpui_canvas::text::planner::Planner>::shape+0x1dd2>
  66ca37:	f3 0f 10 84 24 1c 02 	movss  0x21c(%rsp),%xmm0
  66ca3e:	00 00 
  66ca40:	eb 1a                	jmp    66ca5c <<gpui_canvas::text::planner::Planner>::shape+0x1dcc>
  66ca42:	f3 0f 10 84 24 28 02 	movss  0x228(%rsp),%xmm0
  66ca49:	00 00 
  66ca4b:	f3 0f 11 44 24 58    	movss  %xmm0,0x58(%rsp)
  66ca51:	83 f9 06             	cmp    $0x6,%ecx
  66ca54:	4c 89 fa             	mov    %r15,%rdx
  66ca57:	75 09                	jne    66ca62 <<gpui_canvas::text::planner::Planner>::shape+0x1dd2>
  66ca59:	0f 57 c0             	xorps  %xmm0,%xmm0
  66ca5c:	f3 0f 11 44 24 58    	movss  %xmm0,0x58(%rsp)
  66ca62:	89 d6                	mov    %edx,%esi
  66ca64:	49 39 f6             	cmp    %rsi,%r14
  66ca67:	0f 92 c1             	setb   %cl
  66ca6a:	3b 94 24 20 01 00 00 	cmp    0x120(%rsp),%edx
  66ca71:	0f 82 0e 01 00 00    	jb     66cb85 <<gpui_canvas::text::planner::Planner>::shape+0x1ef5>
  66ca77:	48 8b bc 24 20 01 00 	mov    0x120(%rsp),%rdi
  66ca7e:	00 
  66ca7f:	89 fa                	mov    %edi,%edx
  66ca81:	84 c9                	test   %cl,%cl
  66ca83:	0f 85 36 17 00 00    	jne    66e1bf <<gpui_canvas::text::planner::Planner>::shape+0x352f>
  66ca89:	44 39 ff             	cmp    %r15d,%edi
  66ca8c:	75 11                	jne    66ca9f <<gpui_canvas::text::planner::Planner>::shape+0x1e0f>
  66ca8e:	48 c7 84 24 38 01 00 	movq   $0x0,0x138(%rsp)
  66ca95:	00 00 00 00 00 
  66ca9a:	e9 bd 00 00 00       	jmp    66cb5c <<gpui_canvas::text::planner::Planner>::shape+0x1ecc>
  66ca9f:	48 8d 0c d5 00 00 00 	lea    0x0(,%rdx,8),%rcx
  66caa6:	00 
  66caa7:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  66caab:	48 8d 7e ff          	lea    -0x1(%rsi),%rdi
  66caaf:	48 39 d7             	cmp    %rdx,%rdi
  66cab2:	75 10                	jne    66cac4 <<gpui_canvas::text::planner::Planner>::shape+0x1e34>
  66cab4:	31 d2                	xor    %edx,%edx
  66cab6:	48 c7 84 24 38 01 00 	movq   $0x0,0x138(%rsp)
  66cabd:	00 00 00 00 00 
  66cac2:	eb 67                	jmp    66cb2b <<gpui_canvas::text::planner::Planner>::shape+0x1e9b>
  66cac4:	48 29 d6             	sub    %rdx,%rsi
  66cac7:	48 89 f7             	mov    %rsi,%rdi
  66caca:	48 83 e7 fe          	and    $0xfffffffffffffffe,%rdi
  66cace:	48 8b 94 24 00 03 00 	mov    0x300(%rsp),%rdx
  66cad5:	00 
  66cad6:	4c 8d 04 0a          	lea    (%rdx,%rcx,1),%r8
  66cada:	31 d2                	xor    %edx,%edx
  66cadc:	45 31 d2             	xor    %r10d,%r10d
  66cadf:	41 bb 01 00 00 00    	mov    $0x1,%r11d
  66cae5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  66caec:	00 00 00 00 
  66caf0:	45 8b 48 de          	mov    -0x22(%r8),%r9d
  66caf4:	41 f6 40 e9 01       	testb  $0x1,-0x17(%r8)
  66caf9:	4d 0f 45 cb          	cmovne %r11,%r9
  66cafd:	4d 01 d1             	add    %r10,%r9
  66cb00:	41 f6 40 01 01       	testb  $0x1,0x1(%r8)
  66cb05:	45 8b 50 f6          	mov    -0xa(%r8),%r10d
  66cb09:	4d 0f 45 d3          	cmovne %r11,%r10
  66cb0d:	4d 01 ca             	add    %r9,%r10
  66cb10:	48 83 c2 02          	add    $0x2,%rdx
  66cb14:	49 83 c0 30          	add    $0x30,%r8
  66cb18:	48 39 d7             	cmp    %rdx,%rdi
  66cb1b:	75 d3                	jne    66caf0 <<gpui_canvas::text::planner::Planner>::shape+0x1e60>
  66cb1d:	4c 89 94 24 38 01 00 	mov    %r10,0x138(%rsp)
  66cb24:	00 
  66cb25:	40 f6 c6 01          	test   $0x1,%sil
  66cb29:	74 31                	je     66cb5c <<gpui_canvas::text::planner::Planner>::shape+0x1ecc>
  66cb2b:	48 8b b4 24 38 01 00 	mov    0x138(%rsp),%rsi
  66cb32:	00 
  66cb33:	48 03 8c 24 d0 01 00 	add    0x1d0(%rsp),%rcx
  66cb3a:	00 
  66cb3b:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
  66cb3f:	f6 44 d1 17 01       	testb  $0x1,0x17(%rcx,%rdx,8)
  66cb44:	8b 54 d1 0c          	mov    0xc(%rcx,%rdx,8),%edx
  66cb48:	b9 01 00 00 00       	mov    $0x1,%ecx
  66cb4d:	48 0f 45 d1          	cmovne %rcx,%rdx
  66cb51:	48 01 f2             	add    %rsi,%rdx
  66cb54:	48 89 94 24 38 01 00 	mov    %rdx,0x138(%rsp)
  66cb5b:	00 
  66cb5c:	0f 57 c0             	xorps  %xmm0,%xmm0
  66cb5f:	f3 0f 11 84 24 c0 01 	movss  %xmm0,0x1c0(%rsp)
  66cb66:	00 00 
  66cb68:	b9 00 00 00 00       	mov    $0x0,%ecx
  66cb6d:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
  66cb72:	ba 00 00 00 00       	mov    $0x0,%edx
  66cb77:	48 39 c3             	cmp    %rax,%rbx
  66cb7a:	0f 84 53 fb ff ff    	je     66c6d3 <<gpui_canvas::text::planner::Planner>::shape+0x1a43>
  66cb80:	e9 0e fa ff ff       	jmp    66c593 <<gpui_canvas::text::planner::Planner>::shape+0x1903>
  66cb85:	b1 01                	mov    $0x1,%cl
  66cb87:	48 8b bc 24 20 01 00 	mov    0x120(%rsp),%rdi
  66cb8e:	00 
  66cb8f:	89 fa                	mov    %edi,%edx
  66cb91:	84 c9                	test   %cl,%cl
  66cb93:	0f 84 f0 fe ff ff    	je     66ca89 <<gpui_canvas::text::planner::Planner>::shape+0x1df9>
  66cb99:	e9 21 16 00 00       	jmp    66e1bf <<gpui_canvas::text::planner::Planner>::shape+0x352f>
  66cb9e:	0f 85 85 10 00 00    	jne    66dc29 <<gpui_canvas::text::planner::Planner>::shape+0x2f99>
  66cba4:	48 85 ed             	test   %rbp,%rbp
  66cba7:	0f 94 c2             	sete   %dl
  66cbaa:	74 1b                	je     66cbc7 <<gpui_canvas::text::planner::Planner>::shape+0x1f37>
  66cbac:	48 39 cd             	cmp    %rcx,%rbp
  66cbaf:	73 10                	jae    66cbc1 <<gpui_canvas::text::planner::Planner>::shape+0x1f31>
  66cbb1:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  66cbb6:	80 3c 28 c0          	cmpb   $0xc0,(%rax,%rbp,1)
  66cbba:	7d 0b                	jge    66cbc7 <<gpui_canvas::text::planner::Planner>::shape+0x1f37>
  66cbbc:	e9 68 10 00 00       	jmp    66dc29 <<gpui_canvas::text::planner::Planner>::shape+0x2f99>
  66cbc1:	0f 85 62 10 00 00    	jne    66dc29 <<gpui_canvas::text::planner::Planner>::shape+0x2f99>
  66cbc7:	83 7c 24 5c 00       	cmpl   $0x0,0x5c(%rsp)
  66cbcc:	0f 84 9a 00 00 00    	je     66cc6c <<gpui_canvas::text::planner::Planner>::shape+0x1fdc>
  66cbd2:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  66cbd8:	f3 0f 58 84 24 d8 00 	addss  0xd8(%rsp),%xmm0
  66cbdf:	00 00 
  66cbe1:	f3 0f 11 44 24 0c    	movss  %xmm0,0xc(%rsp)
  66cbe7:	66 0f 7e c1          	movd   %xmm0,%ecx
  66cbeb:	0f 28 84 24 a0 01 00 	movaps 0x1a0(%rsp),%xmm0
  66cbf2:	00 
  66cbf3:	0f 58 84 24 e0 03 00 	addps  0x3e0(%rsp),%xmm0
  66cbfa:	00 
  66cbfb:	0f c6 c0 55          	shufps $0x55,%xmm0,%xmm0
  66cbff:	0f 29 84 24 a0 01 00 	movaps %xmm0,0x1a0(%rsp)
  66cc06:	00 
  66cc07:	66 0f 7e c0          	movd   %xmm0,%eax
  66cc0b:	81 e1 ff ff ff 7f    	and    $0x7fffffff,%ecx
  66cc11:	25 ff ff ff 7f       	and    $0x7fffffff,%eax
  66cc16:	3d 00 00 80 7f       	cmp    $0x7f800000,%eax
  66cc1b:	0f 9d c0             	setge  %al
  66cc1e:	81 f9 ff ff 7f 7f    	cmp    $0x7f7fffff,%ecx
  66cc24:	0f 8f 20 10 00 00    	jg     66dc4a <<gpui_canvas::text::planner::Planner>::shape+0x2fba>
  66cc2a:	84 c0                	test   %al,%al
  66cc2c:	0f 85 18 10 00 00    	jne    66dc4a <<gpui_canvas::text::planner::Planner>::shape+0x2fba>
  66cc32:	81 7c 24 5c ff ff 00 	cmpl   $0xffff,0x5c(%rsp)
  66cc39:	00 
  66cc3a:	0f 87 e9 0f 00 00    	ja     66dc29 <<gpui_canvas::text::planner::Planner>::shape+0x2f99>
  66cc40:	4c 89 cd             	mov    %r9,%rbp
  66cc43:	4c 8b b4 24 f8 00 00 	mov    0xf8(%rsp),%r14
  66cc4a:	00 
  66cc4b:	4c 3b b4 24 e8 00 00 	cmp    0xe8(%rsp),%r14
  66cc52:	00 
  66cc53:	0f 85 4e f8 ff ff    	jne    66c4a7 <<gpui_canvas::text::planner::Planner>::shape+0x1817>
  66cc59:	48 8d bc 24 e8 00 00 	lea    0xe8(%rsp),%rdi
  66cc60:	00 
  66cc61:	ff 15 19 e4 11 00    	call   *0x11e419(%rip)        # 78b080 <_DYNAMIC+0x498>
  66cc67:	e9 3b f8 ff ff       	jmp    66c4a7 <<gpui_canvas::text::planner::Planner>::shape+0x1817>
  66cc6c:	4d 85 c9             	test   %r9,%r9
  66cc6f:	0f 84 af 00 00 00    	je     66cd24 <<gpui_canvas::text::planner::Planner>::shape+0x2094>
  66cc75:	49 39 c9             	cmp    %rcx,%r9
  66cc78:	0f 83 a0 00 00 00    	jae    66cd1e <<gpui_canvas::text::planner::Planner>::shape+0x208e>
  66cc7e:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  66cc83:	42 80 3c 08 bf       	cmpb   $0xbf,(%rax,%r9,1)
  66cc88:	0f 8f 96 00 00 00    	jg     66cd24 <<gpui_canvas::text::planner::Planner>::shape+0x2094>
  66cc8e:	e9 63 10 00 00       	jmp    66dcf6 <<gpui_canvas::text::planner::Planner>::shape+0x3066>
  66cc93:	48 8b 8c 24 20 01 00 	mov    0x120(%rsp),%rcx
  66cc9a:	00 
  66cc9b:	89 da                	mov    %ebx,%edx
  66cc9d:	48 8d 04 7f          	lea    (%rdi,%rdi,2),%rax
  66cca1:	48 8b b4 24 d0 01 00 	mov    0x1d0(%rsp),%rsi
  66cca8:	00 
  66cca9:	f3 0f 10 44 c6 10    	movss  0x10(%rsi,%rax,8),%xmm0
  66ccaf:	0f 57 c9             	xorps  %xmm1,%xmm1
  66ccb2:	0f 29 8c 24 a0 01 00 	movaps %xmm1,0x1a0(%rsp)
  66ccb9:	00 
  66ccba:	bb 04 00 00 00       	mov    $0x4,%ebx
  66ccbf:	b8 04 00 00 00       	mov    $0x4,%eax
  66ccc4:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  66cccb:	00 
  66cccc:	48 89 8c 24 20 01 00 	mov    %rcx,0x120(%rsp)
  66ccd3:	00 
  66ccd4:	f3 0f 11 84 24 b8 01 	movss  %xmm0,0x1b8(%rsp)
  66ccdb:	00 00 
  66ccdd:	f3 0f 11 44 24 08    	movss  %xmm0,0x8(%rsp)
  66cce3:	89 94 24 bc 01 00 00 	mov    %edx,0x1bc(%rsp)
  66ccea:	89 54 24 5c          	mov    %edx,0x5c(%rsp)
  66ccee:	0f 57 c0             	xorps  %xmm0,%xmm0
  66ccf1:	0f 29 84 24 30 02 00 	movaps %xmm0,0x230(%rsp)
  66ccf8:	00 
  66ccf9:	83 bc 24 dc 00 00 00 	cmpl   $0x0,0xdc(%rsp)
  66cd00:	00 
  66cd01:	0f 85 4c f8 ff ff    	jne    66c553 <<gpui_canvas::text::planner::Planner>::shape+0x18c3>
  66cd07:	e9 b8 f8 ff ff       	jmp    66c5c4 <<gpui_canvas::text::planner::Planner>::shape+0x1934>
  66cd0c:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  66cd11:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  66cd18:	00 
  66cd19:	e9 75 f8 ff ff       	jmp    66c593 <<gpui_canvas::text::planner::Planner>::shape+0x1903>
  66cd1e:	0f 85 d2 0f 00 00    	jne    66dcf6 <<gpui_canvas::text::planner::Planner>::shape+0x3066>
  66cd24:	48 85 ed             	test   %rbp,%rbp
  66cd27:	4c 89 8c 24 f8 02 00 	mov    %r9,0x2f8(%rsp)
  66cd2e:	00 
  66cd2f:	74 1b                	je     66cd4c <<gpui_canvas::text::planner::Planner>::shape+0x20bc>
  66cd31:	48 39 cd             	cmp    %rcx,%rbp
  66cd34:	73 10                	jae    66cd46 <<gpui_canvas::text::planner::Planner>::shape+0x20b6>
  66cd36:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  66cd3b:	80 3c 28 c0          	cmpb   $0xc0,(%rax,%rbp,1)
  66cd3f:	7d 0b                	jge    66cd4c <<gpui_canvas::text::planner::Planner>::shape+0x20bc>
  66cd41:	e9 b6 0f 00 00       	jmp    66dcfc <<gpui_canvas::text::planner::Planner>::shape+0x306c>
  66cd46:	0f 85 b0 0f 00 00    	jne    66dcfc <<gpui_canvas::text::planner::Planner>::shape+0x306c>
  66cd4c:	89 54 24 0c          	mov    %edx,0xc(%rsp)
  66cd50:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  66cd55:	4e 8d 34 08          	lea    (%rax,%r9,1),%r14
  66cd59:	48 01 e8             	add    %rbp,%rax
  66cd5c:	48 89 84 24 a0 01 00 	mov    %rax,0x1a0(%rsp)
  66cd63:	00 
  66cd64:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  66cd6b:	00 00 00 00 00 
  66cd70:	4c 3b b4 24 a0 01 00 	cmp    0x1a0(%rsp),%r14
  66cd77:	00 
  66cd78:	0f 84 8c 00 00 00    	je     66ce0a <<gpui_canvas::text::planner::Planner>::shape+0x217a>
  66cd7e:	41 0f b6 36          	movzbl (%r14),%esi
  66cd82:	40 84 f6             	test   %sil,%sil
  66cd85:	78 09                	js     66cd90 <<gpui_canvas::text::planner::Planner>::shape+0x2100>
  66cd87:	49 ff c6             	inc    %r14
  66cd8a:	eb 64                	jmp    66cdf0 <<gpui_canvas::text::planner::Planner>::shape+0x2160>
  66cd8c:	0f 1f 40 00          	nopl   0x0(%rax)
  66cd90:	89 f0                	mov    %esi,%eax
  66cd92:	83 e0 1f             	and    $0x1f,%eax
  66cd95:	41 0f b6 56 01       	movzbl 0x1(%r14),%edx
  66cd9a:	83 e2 3f             	and    $0x3f,%edx
  66cd9d:	40 80 fe df          	cmp    $0xdf,%sil
  66cda1:	76 2e                	jbe    66cdd1 <<gpui_canvas::text::planner::Planner>::shape+0x2141>
  66cda3:	41 0f b6 4e 02       	movzbl 0x2(%r14),%ecx
  66cda8:	c1 e2 06             	shl    $0x6,%edx
  66cdab:	83 e1 3f             	and    $0x3f,%ecx
  66cdae:	09 d1                	or     %edx,%ecx
  66cdb0:	40 80 fe f0          	cmp    $0xf0,%sil
  66cdb4:	72 28                	jb     66cdde <<gpui_canvas::text::planner::Planner>::shape+0x214e>
  66cdb6:	41 0f b6 76 03       	movzbl 0x3(%r14),%esi
  66cdbb:	49 83 c6 04          	add    $0x4,%r14
  66cdbf:	83 e0 07             	and    $0x7,%eax
  66cdc2:	c1 e0 12             	shl    $0x12,%eax
  66cdc5:	c1 e1 06             	shl    $0x6,%ecx
  66cdc8:	83 e6 3f             	and    $0x3f,%esi
  66cdcb:	09 ce                	or     %ecx,%esi
  66cdcd:	09 c6                	or     %eax,%esi
  66cdcf:	eb 1f                	jmp    66cdf0 <<gpui_canvas::text::planner::Planner>::shape+0x2160>
  66cdd1:	49 83 c6 02          	add    $0x2,%r14
  66cdd5:	c1 e0 06             	shl    $0x6,%eax
  66cdd8:	09 d0                	or     %edx,%eax
  66cdda:	89 c6                	mov    %eax,%esi
  66cddc:	eb 12                	jmp    66cdf0 <<gpui_canvas::text::planner::Planner>::shape+0x2160>
  66cdde:	49 83 c6 03          	add    $0x3,%r14
  66cde2:	c1 e0 0c             	shl    $0xc,%eax
  66cde5:	09 c1                	or     %eax,%ecx
  66cde7:	89 ce                	mov    %ecx,%esi
  66cde9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  66cdf0:	48 8d 3d 11 34 11 00 	lea    0x113411(%rip),%rdi        # 780208 <anon.9a0de72a7eba2b0cb10eb2c5cf6d915d.1.llvm.15750432251718107962+0x20>
  66cdf7:	ff 15 bb e3 11 00    	call   *0x11e3bb(%rip)        # 78b1b8 <_DYNAMIC+0x5d0>
  66cdfd:	84 c0                	test   %al,%al
  66cdff:	0f 85 6b ff ff ff    	jne    66cd70 <<gpui_canvas::text::planner::Planner>::shape+0x20e0>
  66ce05:	e9 fa 0e 00 00       	jmp    66dd04 <<gpui_canvas::text::planner::Planner>::shape+0x3074>
  66ce0a:	31 c0                	xor    %eax,%eax
  66ce0c:	0f 57 c0             	xorps  %xmm0,%xmm0
  66ce0f:	f3 0f 10 4c 24 08    	movss  0x8(%rsp),%xmm1
  66ce15:	0f 2e c8             	ucomiss %xmm0,%xmm1
  66ce18:	4c 8b b4 24 e8 01 00 	mov    0x1e8(%rsp),%r14
  66ce1f:	00 
  66ce20:	f3 0f 10 84 24 c4 01 	movss  0x1c4(%rsp),%xmm0
  66ce27:	00 00 
  66ce29:	0f 85 d5 0e 00 00    	jne    66dd04 <<gpui_canvas::text::planner::Planner>::shape+0x3074>
  66ce2f:	0f 8b e0 f6 ff ff    	jnp    66c515 <<gpui_canvas::text::planner::Planner>::shape+0x1885>
  66ce35:	e9 ca 0e 00 00       	jmp    66dd04 <<gpui_canvas::text::planner::Planner>::shape+0x3074>
  66ce3a:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  66ce3f:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  66ce46:	00 
  66ce47:	48 89 8c 24 20 01 00 	mov    %rcx,0x120(%rsp)
  66ce4e:	00 
  66ce4f:	e9 3f f7 ff ff       	jmp    66c593 <<gpui_canvas::text::planner::Planner>::shape+0x1903>
  66ce54:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
  66ce5b:	00 
  66ce5c:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
  66ce63:	00 
  66ce64:	e8 77 1e 00 00       	call   66ece0 <<core::iter::adapters::flatten::FlattenCompat<core::iter::adapters::map::Map<core::ops::range::Range<u32>, <parley::layout::run::Run<()>>::glyph_source_ranges::{closure#0}>, core::iter::sources::repeat_n::RepeatN<core::ops::range::Range<usize>>> as core::iter::traits::iterator::Iterator>::next>
  66ce69:	48 83 bc 24 88 00 00 	cmpq   $0x0,0x88(%rsp)
  66ce70:	00 00 
  66ce72:	0f 85 b1 0d 00 00    	jne    66dc29 <<gpui_canvas::text::planner::Planner>::shape+0x2f99>
  66ce78:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
  66ce7f:	00 
  66ce80:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  66ce84:	0f 84 bb f1 ff ff    	je     66c045 <<gpui_canvas::text::planner::Planner>::shape+0x13b5>
  66ce8a:	48 8b 8c 24 00 01 00 	mov    0x100(%rsp),%rcx
  66ce91:	00 
  66ce92:	48 3b 4c 24 30       	cmp    0x30(%rsp),%rcx
  66ce97:	48 8b 8c 24 10 01 00 	mov    0x110(%rsp),%rcx
  66ce9e:	00 
  66ce9f:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  66cea4:	75 0f                	jne    66ceb5 <<gpui_canvas::text::planner::Planner>::shape+0x2225>
  66cea6:	31 db                	xor    %ebx,%ebx
  66cea8:	45 31 f6             	xor    %r14d,%r14d
  66ceab:	48 8b b4 24 48 02 00 	mov    0x248(%rsp),%rsi
  66ceb2:	00 
  66ceb3:	eb 6d                	jmp    66cf22 <<gpui_canvas::text::planner::Planner>::shape+0x2292>
  66ceb5:	48 8b bc 24 e8 02 00 	mov    0x2e8(%rsp),%rdi
  66cebc:	00 
  66cebd:	48 85 ff             	test   %rdi,%rdi
  66cec0:	48 8b b4 24 48 02 00 	mov    0x248(%rsp),%rsi
  66cec7:	00 
  66cec8:	48 0f 44 fe          	cmove  %rsi,%rdi
  66cecc:	48 8b 1f             	mov    (%rdi),%rbx
  66cecf:	4c 8b 77 08          	mov    0x8(%rdi),%r14
  66ced3:	4c 39 f3             	cmp    %r14,%rbx
  66ced6:	0f 87 4d 0d 00 00    	ja     66dc29 <<gpui_canvas::text::planner::Planner>::shape+0x2f99>
  66cedc:	48 85 db             	test   %rbx,%rbx
  66cedf:	74 10                	je     66cef1 <<gpui_canvas::text::planner::Planner>::shape+0x2261>
  66cee1:	48 39 cb             	cmp    %rcx,%rbx
  66cee4:	73 0f                	jae    66cef5 <<gpui_canvas::text::planner::Planner>::shape+0x2265>
  66cee6:	80 3c 1a bf          	cmpb   $0xbf,(%rdx,%rbx,1)
  66ceea:	7f 12                	jg     66cefe <<gpui_canvas::text::planner::Planner>::shape+0x226e>
  66ceec:	e9 38 0d 00 00       	jmp    66dc29 <<gpui_canvas::text::planner::Planner>::shape+0x2f99>
  66cef1:	31 db                	xor    %ebx,%ebx
  66cef3:	eb 09                	jmp    66cefe <<gpui_canvas::text::planner::Planner>::shape+0x226e>
  66cef5:	48 89 cb             	mov    %rcx,%rbx
  66cef8:	0f 85 2b 0d 00 00    	jne    66dc29 <<gpui_canvas::text::planner::Planner>::shape+0x2f99>
  66cefe:	4d 85 f6             	test   %r14,%r14
  66cf01:	74 11                	je     66cf14 <<gpui_canvas::text::planner::Planner>::shape+0x2284>
  66cf03:	49 39 ce             	cmp    %rcx,%r14
  66cf06:	73 11                	jae    66cf19 <<gpui_canvas::text::planner::Planner>::shape+0x2289>
  66cf08:	42 80 3c 32 c0       	cmpb   $0xc0,(%rdx,%r14,1)
  66cf0d:	7d 13                	jge    66cf22 <<gpui_canvas::text::planner::Planner>::shape+0x2292>
  66cf0f:	e9 15 0d 00 00       	jmp    66dc29 <<gpui_canvas::text::planner::Planner>::shape+0x2f99>
  66cf14:	45 31 f6             	xor    %r14d,%r14d
  66cf17:	eb 09                	jmp    66cf22 <<gpui_canvas::text::planner::Planner>::shape+0x2292>
  66cf19:	49 89 ce             	mov    %rcx,%r14
  66cf1c:	0f 85 07 0d 00 00    	jne    66dc29 <<gpui_canvas::text::planner::Planner>::shape+0x2f99>
  66cf22:	8b 8c 24 f8 00 00 00 	mov    0xf8(%rsp),%ecx
  66cf29:	89 4c 24 60          	mov    %ecx,0x60(%rsp)
  66cf2d:	0f b6 ae 8c 00 00 00 	movzbl 0x8c(%rsi),%ebp
  66cf34:	4c 8b bc 24 60 01 00 	mov    0x160(%rsp),%r15
  66cf3b:	00 
  66cf3c:	49 39 c7             	cmp    %rax,%r15
  66cf3f:	75 0e                	jne    66cf4f <<gpui_canvas::text::planner::Planner>::shape+0x22bf>
  66cf41:	48 8d bc 24 50 01 00 	lea    0x150(%rsp),%rdi
  66cf48:	00 
  66cf49:	ff 15 41 e1 11 00    	call   *0x11e141(%rip)        # 78b090 <_DYNAMIC+0x4a8>
  66cf4f:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  66cf54:	01 c3                	add    %eax,%ebx
  66cf56:	41 01 c6             	add    %eax,%r14d
  66cf59:	40 80 e5 01          	and    $0x1,%bpl
  66cf5d:	48 8b 84 24 58 01 00 	mov    0x158(%rsp),%rax
  66cf64:	00 
  66cf65:	4b 8d 0c 7f          	lea    (%r15,%r15,2),%rcx
  66cf69:	89 1c c8             	mov    %ebx,(%rax,%rcx,8)
  66cf6c:	44 89 74 c8 04       	mov    %r14d,0x4(%rax,%rcx,8)
  66cf71:	48 8b 94 24 f0 02 00 	mov    0x2f0(%rsp),%rdx
  66cf78:	00 
  66cf79:	89 54 c8 08          	mov    %edx,0x8(%rax,%rcx,8)
  66cf7d:	8b 54 24 60          	mov    0x60(%rsp),%edx
  66cf81:	89 54 c8 0c          	mov    %edx,0xc(%rax,%rcx,8)
  66cf85:	48 8b 94 24 58 02 00 	mov    0x258(%rsp),%rdx
  66cf8c:	00 
  66cf8d:	89 54 c8 10          	mov    %edx,0x10(%rax,%rcx,8)
  66cf91:	48 8b 94 24 60 02 00 	mov    0x260(%rsp),%rdx
  66cf98:	00 
  66cf99:	88 54 c8 14          	mov    %dl,0x14(%rax,%rcx,8)
  66cf9d:	40 88 6c c8 15       	mov    %bpl,0x15(%rax,%rcx,8)
  66cfa2:	49 ff c7             	inc    %r15
  66cfa5:	4c 89 bc 24 60 01 00 	mov    %r15,0x160(%rsp)
  66cfac:	00 
  66cfad:	e9 93 f0 ff ff       	jmp    66c045 <<gpui_canvas::text::planner::Planner>::shape+0x13b5>
  66cfb2:	48 8b 84 24 08 03 00 	mov    0x308(%rsp),%rax
  66cfb9:	00 
  66cfba:	48 39 84 24 c8 00 00 	cmp    %rax,0xc8(%rsp)
  66cfc1:	00 
  66cfc2:	48 8b 6c 24 30       	mov    0x30(%rsp),%rbp
  66cfc7:	48 8b 9c 24 00 01 00 	mov    0x100(%rsp),%rbx
  66cfce:	00 
  66cfcf:	0f 85 02 ec ff ff    	jne    66bbd7 <<gpui_canvas::text::planner::Planner>::shape+0xf47>
  66cfd5:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  66cfdc:	00 ff 
  66cfde:	0f 84 d9 06 00 00    	je     66d6bd <<gpui_canvas::text::planner::Planner>::shape+0x2a2d>
  66cfe4:	48 83 bc 24 80 01 00 	cmpq   $0xffffffffffffffff,0x180(%rsp)
  66cfeb:	00 ff 
  66cfed:	0f 84 ca 06 00 00    	je     66d6bd <<gpui_canvas::text::planner::Planner>::shape+0x2a2d>
  66cff3:	48 89 ac 24 88 00 00 	mov    %rbp,0x88(%rsp)
  66cffa:	00 
  66cffb:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
  66d001:	f3 0f 11 84 24 e0 00 	movss  %xmm0,0xe0(%rsp)
  66d008:	00 00 
  66d00a:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  66d00f:	48 89 84 24 40 03 00 	mov    %rax,0x340(%rsp)
  66d016:	00 
  66d017:	48 8d 84 24 e0 00 00 	lea    0xe0(%rsp),%rax
  66d01e:	00 
  66d01f:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
  66d026:	00 
  66d027:	48 8d 84 24 88 00 00 	lea    0x88(%rsp),%rax
  66d02e:	00 
  66d02f:	48 89 84 24 50 03 00 	mov    %rax,0x350(%rsp)
  66d036:	00 
  66d037:	48 8d 84 24 80 01 00 	lea    0x180(%rsp),%rax
  66d03e:	00 
  66d03f:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
  66d046:	00 
  66d047:	48 03 9c 24 48 01 00 	add    0x148(%rsp),%rbx
  66d04e:	00 
  66d04f:	48 c7 84 24 10 07 00 	movq   $0x0,0x710(%rsp)
  66d056:	00 00 00 00 00 
  66d05b:	48 c7 84 24 18 07 00 	movq   $0x8,0x718(%rsp)
  66d062:	00 08 00 00 00 
  66d067:	48 c7 84 24 20 07 00 	movq   $0x0,0x720(%rsp)
  66d06e:	00 00 00 00 00 
  66d073:	c7 84 24 30 07 00 00 	movl   $0xffffffff,0x730(%rsp)
  66d07a:	ff ff ff ff 
  66d07e:	4c 8b 7c 24 10       	mov    0x10(%rsp),%r15
  66d083:	4c 89 bc 24 38 07 00 	mov    %r15,0x738(%rsp)
  66d08a:	00 
  66d08b:	48 89 9c 24 40 07 00 	mov    %rbx,0x740(%rsp)
  66d092:	00 
  66d093:	48 c7 84 24 48 07 00 	movq   $0x0,0x748(%rsp)
  66d09a:	00 00 00 00 00 
  66d09f:	48 8d 05 d2 32 11 00 	lea    0x1132d2(%rip),%rax        # 780378 <anon.9a0de72a7eba2b0cb10eb2c5cf6d915d.1.llvm.15750432251718107962+0x190>
  66d0a6:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
  66d0ad:	00 
  66d0ae:	48 8d 05 db b7 ff ff 	lea    -0x4825(%rip),%rax        # 668890 <icu_segmenter::rule_segmenter_v1::empty_handle_complex::<icu_segmenter::scaffold::Utf8>>
  66d0b5:	48 89 84 24 58 07 00 	mov    %rax,0x758(%rsp)
  66d0bc:	00 
  66d0bd:	4c 8b b4 24 10 01 00 	mov    0x110(%rsp),%r14
  66d0c4:	00 
  66d0c5:	4c 89 b4 24 60 07 00 	mov    %r14,0x760(%rsp)
  66d0cc:	00 
  66d0cd:	48 c7 84 24 68 07 00 	movq   $0x0,0x768(%rsp)
  66d0d4:	00 00 00 00 00 
  66d0d9:	48 c7 84 24 98 07 00 	movq   $0x0,0x798(%rsp)
  66d0e0:	00 00 00 00 00 
  66d0e5:	c6 84 24 a0 07 00 00 	movb   $0x0,0x7a0(%rsp)
  66d0ec:	00 
  66d0ed:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  66d0f4:	00 
  66d0f5:	e8 96 b0 01 00       	call   688190 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  66d0fa:	48 83 f8 01          	cmp    $0x1,%rax
  66d0fe:	0f 85 9b 01 00 00    	jne    66d29f <<gpui_canvas::text::planner::Planner>::shape+0x260f>
  66d104:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  66d10b:	00 
  66d10c:	e8 7f b0 01 00       	call   688190 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  66d111:	48 83 f8 01          	cmp    $0x1,%rax
  66d115:	0f 85 84 01 00 00    	jne    66d29f <<gpui_canvas::text::planner::Planner>::shape+0x260f>
  66d11b:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  66d122:	00 
  66d123:	e8 68 b0 01 00       	call   688190 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  66d128:	48 83 f8 01          	cmp    $0x1,%rax
  66d12c:	0f 85 6d 01 00 00    	jne    66d29f <<gpui_canvas::text::planner::Planner>::shape+0x260f>
  66d132:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  66d139:	00 
  66d13a:	e8 51 b0 01 00       	call   688190 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  66d13f:	48 83 f8 01          	cmp    $0x1,%rax
  66d143:	0f 85 56 01 00 00    	jne    66d29f <<gpui_canvas::text::planner::Planner>::shape+0x260f>
  66d149:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  66d150:	00 
  66d151:	e8 3a b0 01 00       	call   688190 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  66d156:	48 83 f8 01          	cmp    $0x1,%rax
  66d15a:	0f 85 3f 01 00 00    	jne    66d29f <<gpui_canvas::text::planner::Planner>::shape+0x260f>
  66d160:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  66d167:	00 
  66d168:	e8 23 b0 01 00       	call   688190 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  66d16d:	48 83 f8 01          	cmp    $0x1,%rax
  66d171:	0f 85 28 01 00 00    	jne    66d29f <<gpui_canvas::text::planner::Planner>::shape+0x260f>
  66d177:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  66d17e:	00 
  66d17f:	e8 0c b0 01 00       	call   688190 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  66d184:	48 83 f8 01          	cmp    $0x1,%rax
  66d188:	0f 85 11 01 00 00    	jne    66d29f <<gpui_canvas::text::planner::Planner>::shape+0x260f>
  66d18e:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  66d195:	00 
  66d196:	e8 f5 af 01 00       	call   688190 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  66d19b:	a8 01                	test   $0x1,%al
  66d19d:	0f 84 fc 00 00 00    	je     66d29f <<gpui_canvas::text::planner::Planner>::shape+0x260f>
  66d1a3:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  66d1aa:	00 
  66d1ab:	e8 e0 af 01 00       	call   688190 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  66d1b0:	48 83 f8 01          	cmp    $0x1,%rax
  66d1b4:	0f 85 e5 00 00 00    	jne    66d29f <<gpui_canvas::text::planner::Planner>::shape+0x260f>
  66d1ba:	48 8b b4 24 10 07 00 	mov    0x710(%rsp),%rsi
  66d1c1:	00 
  66d1c2:	48 85 f6             	test   %rsi,%rsi
  66d1c5:	74 17                	je     66d1de <<gpui_canvas::text::planner::Planner>::shape+0x254e>
  66d1c7:	48 8b bc 24 18 07 00 	mov    0x718(%rsp),%rdi
  66d1ce:	00 
  66d1cf:	48 c1 e6 03          	shl    $0x3,%rsi
  66d1d3:	ba 08 00 00 00       	mov    $0x8,%edx
  66d1d8:	ff 15 42 dc 11 00    	call   *0x11dc42(%rip)        # 78ae20 <_DYNAMIC+0x238>
  66d1de:	48 c7 84 24 10 07 00 	movq   $0x0,0x710(%rsp)
  66d1e5:	00 00 00 00 00 
  66d1ea:	48 c7 84 24 18 07 00 	movq   $0x8,0x718(%rsp)
  66d1f1:	00 08 00 00 00 
  66d1f6:	48 c7 84 24 20 07 00 	movq   $0x0,0x720(%rsp)
  66d1fd:	00 00 00 00 00 
  66d202:	c7 84 24 30 07 00 00 	movl   $0xffffffff,0x730(%rsp)
  66d209:	ff ff ff ff 
  66d20d:	4c 89 bc 24 38 07 00 	mov    %r15,0x738(%rsp)
  66d214:	00 
  66d215:	48 89 9c 24 40 07 00 	mov    %rbx,0x740(%rsp)
  66d21c:	00 
  66d21d:	48 c7 84 24 48 07 00 	movq   $0x0,0x748(%rsp)
  66d224:	00 00 00 00 00 
  66d229:	48 8d 05 48 31 11 00 	lea    0x113148(%rip),%rax        # 780378 <anon.9a0de72a7eba2b0cb10eb2c5cf6d915d.1.llvm.15750432251718107962+0x190>
  66d230:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
  66d237:	00 
  66d238:	48 8d 05 51 b6 ff ff 	lea    -0x49af(%rip),%rax        # 668890 <icu_segmenter::rule_segmenter_v1::empty_handle_complex::<icu_segmenter::scaffold::Utf8>>
  66d23f:	48 89 84 24 58 07 00 	mov    %rax,0x758(%rsp)
  66d246:	00 
  66d247:	4c 89 b4 24 60 07 00 	mov    %r14,0x760(%rsp)
  66d24e:	00 
  66d24f:	48 c7 84 24 68 07 00 	movq   $0x0,0x768(%rsp)
  66d256:	00 00 00 00 00 
  66d25b:	48 c7 84 24 98 07 00 	movq   $0x0,0x798(%rsp)
  66d262:	00 00 00 00 00 
  66d267:	c6 84 24 a0 07 00 00 	movb   $0x0,0x7a0(%rsp)
  66d26e:	00 
  66d26f:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  66d274:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
  66d27b:	00 
  66d27c:	f3 0f 10 05 98 05 9b 	movss  -0x64fa68(%rip),%xmm0        # 1d81c <GCC_except_table0+0x1c>
  66d283:	ff 
  66d284:	48 8d 94 24 40 03 00 	lea    0x340(%rsp),%rdx
  66d28b:	00 
  66d28c:	e8 bf 25 00 00       	call   66f850 <<parley::editing::geometry::CursorGeometry<()>>::try_for_each_pair::<gpui_canvas::Error, icu_segmenter::grapheme::GraphemeClusterBreakIterator<icu_segmenter::scaffold::Utf8>, gpui_canvas::text::planner::append_carets::{closure#1}>>
  66d291:	83 f8 ff             	cmp    $0xffffffff,%eax
  66d294:	0f 84 23 04 00 00    	je     66d6bd <<gpui_canvas::text::planner::Planner>::shape+0x2a2d>
  66d29a:	e9 6d 0f 00 00       	jmp    66e20c <<gpui_canvas::text::planner::Planner>::shape+0x357c>
  66d29f:	48 8b b4 24 10 07 00 	mov    0x710(%rsp),%rsi
  66d2a6:	00 
  66d2a7:	48 85 f6             	test   %rsi,%rsi
  66d2aa:	74 17                	je     66d2c3 <<gpui_canvas::text::planner::Planner>::shape+0x2633>
  66d2ac:	48 8b bc 24 18 07 00 	mov    0x718(%rsp),%rdi
  66d2b3:	00 
  66d2b4:	48 c1 e6 03          	shl    $0x3,%rsi
  66d2b8:	ba 08 00 00 00       	mov    $0x8,%edx
  66d2bd:	ff 15 5d db 11 00    	call   *0x11db5d(%rip)        # 78ae20 <_DYNAMIC+0x238>
  66d2c3:	48 c7 84 24 10 07 00 	movq   $0x0,0x710(%rsp)
  66d2ca:	00 00 00 00 00 
  66d2cf:	48 c7 84 24 18 07 00 	movq   $0x8,0x718(%rsp)
  66d2d6:	00 08 00 00 00 
  66d2db:	48 c7 84 24 20 07 00 	movq   $0x0,0x720(%rsp)
  66d2e2:	00 00 00 00 00 
  66d2e7:	c7 84 24 30 07 00 00 	movl   $0xffffffff,0x730(%rsp)
  66d2ee:	ff ff ff ff 
  66d2f2:	4c 89 bc 24 38 07 00 	mov    %r15,0x738(%rsp)
  66d2f9:	00 
  66d2fa:	48 89 9c 24 40 07 00 	mov    %rbx,0x740(%rsp)
  66d301:	00 
  66d302:	48 c7 84 24 48 07 00 	movq   $0x0,0x748(%rsp)
  66d309:	00 00 00 00 00 
  66d30e:	48 8d 05 63 30 11 00 	lea    0x113063(%rip),%rax        # 780378 <anon.9a0de72a7eba2b0cb10eb2c5cf6d915d.1.llvm.15750432251718107962+0x190>
  66d315:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
  66d31c:	00 
  66d31d:	48 8d 05 6c b5 ff ff 	lea    -0x4a94(%rip),%rax        # 668890 <icu_segmenter::rule_segmenter_v1::empty_handle_complex::<icu_segmenter::scaffold::Utf8>>
  66d324:	48 89 84 24 58 07 00 	mov    %rax,0x758(%rsp)
  66d32b:	00 
  66d32c:	4c 89 b4 24 60 07 00 	mov    %r14,0x760(%rsp)
  66d333:	00 
  66d334:	48 c7 84 24 68 07 00 	movq   $0x0,0x768(%rsp)
  66d33b:	00 00 00 00 00 
  66d340:	48 c7 84 24 98 07 00 	movq   $0x0,0x798(%rsp)
  66d347:	00 00 00 00 00 
  66d34c:	c6 84 24 a0 07 00 00 	movb   $0x0,0x7a0(%rsp)
  66d353:	00 
  66d354:	eb 42                	jmp    66d398 <<gpui_canvas::text::planner::Planner>::shape+0x2708>
  66d356:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  66d35d:	00 00 00 
  66d360:	0f 28 84 24 00 01 00 	movaps 0x100(%rsp),%xmm0
  66d367:	00 
  66d368:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
  66d36d:	48 8b 84 24 88 01 00 	mov    0x188(%rsp),%rax
  66d374:	00 
  66d375:	48 8d 0c 5b          	lea    (%rbx,%rbx,2),%rcx
  66d379:	44 89 3c 88          	mov    %r15d,(%rax,%rcx,4)
  66d37d:	0f 28 44 24 30       	movaps 0x30(%rsp),%xmm0
  66d382:	f3 0f 11 44 88 04    	movss  %xmm0,0x4(%rax,%rcx,4)
  66d388:	40 88 6c 88 08       	mov    %bpl,0x8(%rax,%rcx,4)
  66d38d:	48 ff c3             	inc    %rbx
  66d390:	48 89 9c 24 90 01 00 	mov    %rbx,0x190(%rsp)
  66d397:	00 
  66d398:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  66d39f:	00 
  66d3a0:	e8 eb ad 01 00       	call   688190 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  66d3a5:	48 83 f8 01          	cmp    $0x1,%rax
  66d3a9:	0f 85 ea 02 00 00    	jne    66d699 <<gpui_canvas::text::planner::Planner>::shape+0x2a09>
  66d3af:	49 89 d6             	mov    %rdx,%r14
  66d3b2:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  66d3b7:	48 89 d6             	mov    %rdx,%rsi
  66d3ba:	ba 01 00 00 00       	mov    $0x1,%edx
  66d3bf:	e8 8c 0e 01 00       	call   67e250 <<parley::editing::cursor::Cursor>::from_byte_index::<()>>
  66d3c4:	48 89 c3             	mov    %rax,%rbx
  66d3c7:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
  66d3ce:	00 
  66d3cf:	80 e2 01             	and    $0x1,%dl
  66d3d2:	88 94 24 a0 03 00 00 	mov    %dl,0x3a0(%rsp)
  66d3d9:	4c 39 f0             	cmp    %r14,%rax
  66d3dc:	0f 85 ae 00 00 00    	jne    66d490 <<gpui_canvas::text::planner::Planner>::shape+0x2800>
  66d3e2:	48 8d bc 24 c0 04 00 	lea    0x4c0(%rsp),%rdi
  66d3e9:	00 
  66d3ea:	48 8d b4 24 98 03 00 	lea    0x398(%rsp),%rsi
  66d3f1:	00 
  66d3f2:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  66d3f7:	f3 0f 10 05 1d 04 9b 	movss  -0x64fbe3(%rip),%xmm0        # 1d81c <GCC_except_table0+0x1c>
  66d3fe:	ff 
  66d3ff:	e8 0c 0f 01 00       	call   67e310 <<parley::editing::cursor::Cursor>::geometry::<()>>
  66d404:	f3 0f 10 84 24 e0 00 	movss  0xe0(%rsp),%xmm0
  66d40b:	00 00 
  66d40d:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
  66d411:	f2 0f 58 84 24 c8 04 	addsd  0x4c8(%rsp),%xmm0
  66d418:	00 00 
  66d41a:	66 0f 28 8c 24 c0 04 	movapd 0x4c0(%rsp),%xmm1
  66d421:	00 00 
  66d423:	66 0f 28 94 24 d0 04 	movapd 0x4d0(%rsp),%xmm2
  66d42a:	00 00 
  66d42c:	66 0f 5c d1          	subpd  %xmm1,%xmm2
  66d430:	66 0f 14 c8          	unpcklpd %xmm0,%xmm1
  66d434:	66 0f 5a c9          	cvtpd2ps %xmm1,%xmm1
  66d438:	66 0f 5a d2          	cvtpd2ps %xmm2,%xmm2
  66d43c:	66 0f 29 4c 24 30    	movapd %xmm1,0x30(%rsp)
  66d442:	66 0f 29 94 24 10 01 	movapd %xmm2,0x110(%rsp)
  66d449:	00 00 
  66d44b:	66 0f 14 ca          	unpcklpd %xmm2,%xmm1
  66d44f:	66 0f 54 0d f9 80 9b 	andpd  -0x647f07(%rip),%xmm1        # 25550 <anon.1508e9dce0c1a49d095b8c30671814b4.0.llvm.16300762181250184790+0x7e0>
  66d456:	ff 
  66d457:	66 0f 66 0d c1 7a 9b 	pcmpgtd -0x64853f(%rip),%xmm1        # 24f20 <anon.1508e9dce0c1a49d095b8c30671814b4.0.llvm.16300762181250184790+0x1b0>
  66d45e:	ff 
  66d45f:	0f 50 c1             	movmskps %xmm1,%eax
  66d462:	85 c0                	test   %eax,%eax
  66d464:	0f 85 73 07 00 00    	jne    66dbdd <<gpui_canvas::text::planner::Planner>::shape+0x2f4d>
  66d46a:	f2 0f 5a c0          	cvtsd2ss %xmm0,%xmm0
  66d46e:	f3 0f 11 44 24 10    	movss  %xmm0,0x10(%rsp)
  66d474:	0f 28 84 24 10 01 00 	movaps 0x110(%rsp),%xmm0
  66d47b:	00 
  66d47c:	0f c6 c0 55          	shufps $0x55,%xmm0,%xmm0
  66d480:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
  66d485:	eb 09                	jmp    66d490 <<gpui_canvas::text::planner::Planner>::shape+0x2800>
  66d487:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  66d48e:	00 00 
  66d490:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  66d495:	4c 89 f6             	mov    %r14,%rsi
  66d498:	31 d2                	xor    %edx,%edx
  66d49a:	e8 b1 0d 01 00       	call   67e250 <<parley::editing::cursor::Cursor>::from_byte_index::<()>>
  66d49f:	48 89 c5             	mov    %rax,%rbp
  66d4a2:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
  66d4a9:	00 
  66d4aa:	80 e2 01             	and    $0x1,%dl
  66d4ad:	88 94 24 a0 03 00 00 	mov    %dl,0x3a0(%rsp)
  66d4b4:	4c 39 f0             	cmp    %r14,%rax
  66d4b7:	0f 85 23 01 00 00    	jne    66d5e0 <<gpui_canvas::text::planner::Planner>::shape+0x2950>
  66d4bd:	48 8d bc 24 c0 04 00 	lea    0x4c0(%rsp),%rdi
  66d4c4:	00 
  66d4c5:	48 8d b4 24 98 03 00 	lea    0x398(%rsp),%rsi
  66d4cc:	00 
  66d4cd:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  66d4d2:	f3 0f 10 05 42 03 9b 	movss  -0x64fcbe(%rip),%xmm0        # 1d81c <GCC_except_table0+0x1c>
  66d4d9:	ff 
  66d4da:	e8 31 0e 01 00       	call   67e310 <<parley::editing::cursor::Cursor>::geometry::<()>>
  66d4df:	f3 0f 10 84 24 e0 00 	movss  0xe0(%rsp),%xmm0
  66d4e6:	00 00 
  66d4e8:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
  66d4ec:	f2 0f 58 84 24 c8 04 	addsd  0x4c8(%rsp),%xmm0
  66d4f3:	00 00 
  66d4f5:	66 0f 28 8c 24 c0 04 	movapd 0x4c0(%rsp),%xmm1
  66d4fc:	00 00 
  66d4fe:	66 0f 28 94 24 d0 04 	movapd 0x4d0(%rsp),%xmm2
  66d505:	00 00 
  66d507:	66 0f 5c d1          	subpd  %xmm1,%xmm2
  66d50b:	66 0f 14 c8          	unpcklpd %xmm0,%xmm1
  66d50f:	66 0f 5a c9          	cvtpd2ps %xmm1,%xmm1
  66d513:	66 0f 5a c2          	cvtpd2ps %xmm2,%xmm0
  66d517:	66 0f 14 c8          	unpcklpd %xmm0,%xmm1
  66d51b:	66 0f 29 8c 24 00 01 	movapd %xmm1,0x100(%rsp)
  66d522:	00 00 
  66d524:	66 0f 28 c1          	movapd %xmm1,%xmm0
  66d528:	66 0f 54 05 20 80 9b 	andpd  -0x647fe0(%rip),%xmm0        # 25550 <anon.1508e9dce0c1a49d095b8c30671814b4.0.llvm.16300762181250184790+0x7e0>
  66d52f:	ff 
  66d530:	66 0f 66 05 e8 79 9b 	pcmpgtd -0x648618(%rip),%xmm0        # 24f20 <anon.1508e9dce0c1a49d095b8c30671814b4.0.llvm.16300762181250184790+0x1b0>
  66d537:	ff 
  66d538:	0f 50 c0             	movmskps %xmm0,%eax
  66d53b:	85 c0                	test   %eax,%eax
  66d53d:	0f 85 9a 06 00 00    	jne    66dbdd <<gpui_canvas::text::planner::Planner>::shape+0x2f4d>
  66d543:	44 8b bc 24 88 00 00 	mov    0x88(%rsp),%r15d
  66d54a:	00 
  66d54b:	45 01 f7             	add    %r14d,%r15d
  66d54e:	4c 39 f3             	cmp    %r14,%rbx
  66d551:	0f 85 09 01 00 00    	jne    66d660 <<gpui_canvas::text::planner::Planner>::shape+0x29d0>
  66d557:	0f 28 44 24 30       	movaps 0x30(%rsp),%xmm0
  66d55c:	0f 28 8c 24 00 01 00 	movaps 0x100(%rsp),%xmm1
  66d563:	00 
  66d564:	0f 2e c1             	ucomiss %xmm1,%xmm0
  66d567:	0f 85 87 00 00 00    	jne    66d5f4 <<gpui_canvas::text::planner::Planner>::shape+0x2964>
  66d56d:	0f 8a 81 00 00 00    	jp     66d5f4 <<gpui_canvas::text::planner::Planner>::shape+0x2964>
  66d573:	0f 28 c1             	movaps %xmm1,%xmm0
  66d576:	0f c6 c1 55          	shufps $0x55,%xmm1,%xmm0
  66d57a:	f3 0f 10 54 24 10    	movss  0x10(%rsp),%xmm2
  66d580:	0f 2e d0             	ucomiss %xmm0,%xmm2
  66d583:	75 6f                	jne    66d5f4 <<gpui_canvas::text::planner::Planner>::shape+0x2964>
  66d585:	7a 6d                	jp     66d5f4 <<gpui_canvas::text::planner::Planner>::shape+0x2964>
  66d587:	0f 28 c1             	movaps %xmm1,%xmm0
  66d58a:	66 0f 15 c1          	unpckhpd %xmm1,%xmm0
  66d58e:	0f 28 94 24 10 01 00 	movaps 0x110(%rsp),%xmm2
  66d595:	00 
  66d596:	0f 2e d0             	ucomiss %xmm0,%xmm2
  66d599:	75 59                	jne    66d5f4 <<gpui_canvas::text::planner::Planner>::shape+0x2964>
  66d59b:	7a 57                	jp     66d5f4 <<gpui_canvas::text::planner::Planner>::shape+0x2964>
  66d59d:	0f 28 c1             	movaps %xmm1,%xmm0
  66d5a0:	0f c6 c1 ff          	shufps $0xff,%xmm1,%xmm0
  66d5a4:	0f 28 4c 24 60       	movaps 0x60(%rsp),%xmm1
  66d5a9:	0f 2e c8             	ucomiss %xmm0,%xmm1
  66d5ac:	75 46                	jne    66d5f4 <<gpui_canvas::text::planner::Planner>::shape+0x2964>
  66d5ae:	7a 44                	jp     66d5f4 <<gpui_canvas::text::planner::Planner>::shape+0x2964>
  66d5b0:	48 8b 9c 24 90 01 00 	mov    0x190(%rsp),%rbx
  66d5b7:	00 
  66d5b8:	40 b5 03             	mov    $0x3,%bpl
  66d5bb:	48 3b 9c 24 80 01 00 	cmp    0x180(%rsp),%rbx
  66d5c2:	00 
  66d5c3:	0f 85 a4 fd ff ff    	jne    66d36d <<gpui_canvas::text::planner::Planner>::shape+0x26dd>
  66d5c9:	48 8d bc 24 80 01 00 	lea    0x180(%rsp),%rdi
  66d5d0:	00 
  66d5d1:	ff 15 c1 da 11 00    	call   *0x11dac1(%rip)        # 78b098 <_DYNAMIC+0x4b0>
  66d5d7:	e9 91 fd ff ff       	jmp    66d36d <<gpui_canvas::text::planner::Planner>::shape+0x26dd>
  66d5dc:	0f 1f 40 00          	nopl   0x0(%rax)
  66d5e0:	4c 39 f3             	cmp    %r14,%rbx
  66d5e3:	0f 85 af fd ff ff    	jne    66d398 <<gpui_canvas::text::planner::Planner>::shape+0x2708>
  66d5e9:	44 8b bc 24 88 00 00 	mov    0x88(%rsp),%r15d
  66d5f0:	00 
  66d5f1:	45 01 f7             	add    %r14d,%r15d
  66d5f4:	48 8b 9c 24 90 01 00 	mov    0x190(%rsp),%rbx
  66d5fb:	00 
  66d5fc:	48 3b 9c 24 80 01 00 	cmp    0x180(%rsp),%rbx
  66d603:	00 
  66d604:	75 0e                	jne    66d614 <<gpui_canvas::text::planner::Planner>::shape+0x2984>
  66d606:	48 8d bc 24 80 01 00 	lea    0x180(%rsp),%rdi
  66d60d:	00 
  66d60e:	ff 15 84 da 11 00    	call   *0x11da84(%rip)        # 78b098 <_DYNAMIC+0x4b0>
  66d614:	48 8b 84 24 88 01 00 	mov    0x188(%rsp),%rax
  66d61b:	00 
  66d61c:	48 8d 0c 5b          	lea    (%rbx,%rbx,2),%rcx
  66d620:	44 89 3c 88          	mov    %r15d,(%rax,%rcx,4)
  66d624:	0f 28 44 24 30       	movaps 0x30(%rsp),%xmm0
  66d629:	f3 0f 11 44 88 04    	movss  %xmm0,0x4(%rax,%rcx,4)
  66d62f:	c6 44 88 08 01       	movb   $0x1,0x8(%rax,%rcx,4)
  66d634:	48 ff c3             	inc    %rbx
  66d637:	48 89 9c 24 90 01 00 	mov    %rbx,0x190(%rsp)
  66d63e:	00 
  66d63f:	4c 39 f5             	cmp    %r14,%rbp
  66d642:	0f 85 50 fd ff ff    	jne    66d398 <<gpui_canvas::text::planner::Planner>::shape+0x2708>
  66d648:	40 b5 02             	mov    $0x2,%bpl
  66d64b:	48 3b 9c 24 80 01 00 	cmp    0x180(%rsp),%rbx
  66d652:	00 
  66d653:	0f 85 07 fd ff ff    	jne    66d360 <<gpui_canvas::text::planner::Planner>::shape+0x26d0>
  66d659:	eb 1e                	jmp    66d679 <<gpui_canvas::text::planner::Planner>::shape+0x29e9>
  66d65b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  66d660:	48 8b 9c 24 90 01 00 	mov    0x190(%rsp),%rbx
  66d667:	00 
  66d668:	40 b5 02             	mov    $0x2,%bpl
  66d66b:	48 3b 9c 24 80 01 00 	cmp    0x180(%rsp),%rbx
  66d672:	00 
  66d673:	0f 85 e7 fc ff ff    	jne    66d360 <<gpui_canvas::text::planner::Planner>::shape+0x26d0>
  66d679:	48 8d bc 24 80 01 00 	lea    0x180(%rsp),%rdi
  66d680:	00 
  66d681:	ff 15 11 da 11 00    	call   *0x11da11(%rip)        # 78b098 <_DYNAMIC+0x4b0>
  66d687:	0f 28 84 24 00 01 00 	movaps 0x100(%rsp),%xmm0
  66d68e:	00 
  66d68f:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
  66d694:	e9 d4 fc ff ff       	jmp    66d36d <<gpui_canvas::text::planner::Planner>::shape+0x26dd>
  66d699:	48 8b b4 24 10 07 00 	mov    0x710(%rsp),%rsi
  66d6a0:	00 
  66d6a1:	48 85 f6             	test   %rsi,%rsi
  66d6a4:	74 17                	je     66d6bd <<gpui_canvas::text::planner::Planner>::shape+0x2a2d>
  66d6a6:	48 8b bc 24 18 07 00 	mov    0x718(%rsp),%rdi
  66d6ad:	00 
  66d6ae:	48 c1 e6 03          	shl    $0x3,%rsi
  66d6b2:	ba 08 00 00 00       	mov    $0x8,%edx
  66d6b7:	ff 15 63 d7 11 00    	call   *0x11d763(%rip)        # 78ae20 <_DYNAMIC+0x238>
  66d6bd:	0f 28 9c 24 80 02 00 	movaps 0x280(%rsp),%xmm3
  66d6c4:	00 
  66d6c5:	0f 28 c3             	movaps %xmm3,%xmm0
  66d6c8:	f3 0f 5f 84 24 d4 00 	maxss  0xd4(%rsp),%xmm0
  66d6cf:	00 00 
  66d6d1:	0f 28 c8             	movaps %xmm0,%xmm1
  66d6d4:	f3 0f c2 c8 03       	cmpunordss %xmm0,%xmm1
  66d6d9:	0f 28 d1             	movaps %xmm1,%xmm2
  66d6dc:	0f 55 d0             	andnps %xmm0,%xmm2
  66d6df:	0f 54 cb             	andps  %xmm3,%xmm1
  66d6e2:	0f 56 ca             	orps   %xmm2,%xmm1
  66d6e5:	0f 29 8c 24 80 02 00 	movaps %xmm1,0x280(%rsp)
  66d6ec:	00 
  66d6ed:	48 8b 04 24          	mov    (%rsp),%rax
  66d6f1:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
  66d6f7:	f3 0f 58 80 30 0a 00 	addss  0xa30(%rax),%xmm0
  66d6fe:	00 
  66d6ff:	f3 0f 11 44 24 1c    	movss  %xmm0,0x1c(%rsp)
  66d705:	80 7c 24 4c 00       	cmpb   $0x0,0x4c(%rsp)
  66d70a:	48 8b 84 24 20 03 00 	mov    0x320(%rsp),%rax
  66d711:	00 
  66d712:	8b b4 24 80 00 00 00 	mov    0x80(%rsp),%esi
  66d719:	48 8b 94 24 18 03 00 	mov    0x318(%rsp),%rdx
  66d720:	00 
  66d721:	0f 84 c1 db ff ff    	je     66b2e8 <<gpui_canvas::text::planner::Planner>::shape+0x658>
  66d727:	e9 6c 05 00 00       	jmp    66dc98 <<gpui_canvas::text::planner::Planner>::shape+0x3008>
  66d72c:	48 8b 0c 24          	mov    (%rsp),%rcx
  66d730:	48 8b 81 d8 09 00 00 	mov    0x9d8(%rcx),%rax
  66d737:	48 6b 89 e0 09 00 00 	imul   $0x70,0x9e0(%rcx),%rcx
  66d73e:	70 
  66d73f:	48 01 c1             	add    %rax,%rcx
  66d742:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
  66d749:	00 
  66d74a:	48 89 8c 24 18 07 00 	mov    %rcx,0x718(%rsp)
  66d751:	00 
  66d752:	48 c7 84 24 20 07 00 	movq   $0x0,0x720(%rsp)
  66d759:	00 00 00 00 00 
  66d75e:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  66d763:	48 89 84 24 28 07 00 	mov    %rax,0x728(%rsp)
  66d76a:	00 
  66d76b:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  66d772:	00 
  66d773:	31 f6                	xor    %esi,%esi
  66d775:	48 8d 94 24 e7 00 00 	lea    0xe7(%rsp),%rdx
  66d77c:	00 
  66d77d:	e8 2e 8c 00 00       	call   6763b0 <<core::iter::adapters::map::Map<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineData>>, <parley::layout::layout::Layout<()>>::lines::{closure#0}>, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#3}> as core::iter::traits::iterator::Iterator>::fold::<usize, <core::iter::adapters::flatten::FlattenCompat<_, _>>::iter_fold::flatten<core::iter::adapters::filter_map::FilterMap<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}>, <parley::layout::line::Line<()>>::runs::{closure#0}>, usize, <core::iter::adapters::flatten::FlattenCompat<_, _> as core::iter::traits::iterator::Iterator>::count::count<core::iter::adapters::filter_map::FilterMap<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}>, <parley::layout::line::Line<()>>::runs::{closure#0}>>>::{closure#0}>>
  66d782:	48 83 f8 02          	cmp    $0x2,%rax
  66d786:	0f 82 17 e2 ff ff    	jb     66b9a3 <<gpui_canvas::text::planner::Planner>::shape+0xd13>
  66d78c:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
  66d793:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  66d79a:	00 ff 
  66d79c:	0f 84 84 e1 ff ff    	je     66b926 <<gpui_canvas::text::planner::Planner>::shape+0xc96>
  66d7a2:	e9 fc e1 ff ff       	jmp    66b9a3 <<gpui_canvas::text::planner::Planner>::shape+0xd13>
  66d7a7:	c7 84 24 80 00 00 00 	movl   $0xffffffff,0x80(%rsp)
  66d7ae:	ff ff ff ff 
  66d7b2:	e9 9c dd ff ff       	jmp    66b553 <<gpui_canvas::text::planner::Planner>::shape+0x8c3>
  66d7b7:	44 89 d2             	mov    %r10d,%edx
  66d7ba:	83 e2 1f             	and    $0x1f,%edx
  66d7bd:	41 0f b6 79 01       	movzbl 0x1(%r9),%edi
  66d7c2:	83 e7 3f             	and    $0x3f,%edi
  66d7c5:	41 80 fa df          	cmp    $0xdf,%r10b
  66d7c9:	76 31                	jbe    66d7fc <<gpui_canvas::text::planner::Planner>::shape+0x2b6c>
  66d7cb:	41 0f b6 71 02       	movzbl 0x2(%r9),%esi
  66d7d0:	c1 e7 06             	shl    $0x6,%edi
  66d7d3:	83 e6 3f             	and    $0x3f,%esi
  66d7d6:	09 fe                	or     %edi,%esi
  66d7d8:	41 80 fa f0          	cmp    $0xf0,%r10b
  66d7dc:	72 2c                	jb     66d80a <<gpui_canvas::text::planner::Planner>::shape+0x2b7a>
  66d7de:	49 8d 59 04          	lea    0x4(%r9),%rbx
  66d7e2:	45 0f b6 51 03       	movzbl 0x3(%r9),%r10d
  66d7e7:	83 e2 07             	and    $0x7,%edx
  66d7ea:	c1 e2 12             	shl    $0x12,%edx
  66d7ed:	c1 e6 06             	shl    $0x6,%esi
  66d7f0:	41 83 e2 3f          	and    $0x3f,%r10d
  66d7f4:	41 09 f2             	or     %esi,%r10d
  66d7f7:	41 09 d2             	or     %edx,%r10d
  66d7fa:	eb 1a                	jmp    66d816 <<gpui_canvas::text::planner::Planner>::shape+0x2b86>
  66d7fc:	49 8d 59 02          	lea    0x2(%r9),%rbx
  66d800:	c1 e2 06             	shl    $0x6,%edx
  66d803:	09 fa                	or     %edi,%edx
  66d805:	41 89 d2             	mov    %edx,%r10d
  66d808:	eb 0c                	jmp    66d816 <<gpui_canvas::text::planner::Planner>::shape+0x2b86>
  66d80a:	49 8d 59 03          	lea    0x3(%r9),%rbx
  66d80e:	c1 e2 0c             	shl    $0xc,%edx
  66d811:	09 d6                	or     %edx,%esi
  66d813:	41 89 f2             	mov    %esi,%r10d
  66d816:	49 8d 50 02          	lea    0x2(%r8),%rdx
  66d81a:	4c 89 c1             	mov    %r8,%rcx
  66d81d:	48 89 c6             	mov    %rax,%rsi
  66d820:	4c 29 ce             	sub    %r9,%rsi
  66d823:	48 01 de             	add    %rbx,%rsi
  66d826:	41 83 fa 0a          	cmp    $0xa,%r10d
  66d82a:	bf fe ff ff ff       	mov    $0xfffffffe,%edi
  66d82f:	44 0f 44 d7          	cmove  %edi,%r10d
  66d833:	44 89 94 24 80 00 00 	mov    %r10d,0x80(%rsp)
  66d83a:	00 
  66d83b:	4c 0f 44 da          	cmove  %rdx,%r11
  66d83f:	c7 44 24 4c 00 00 00 	movl   $0x0,0x4c(%rsp)
  66d846:	00 
  66d847:	48 89 84 24 10 03 00 	mov    %rax,0x310(%rsp)
  66d84e:	00 
  66d84f:	48 89 f0             	mov    %rsi,%rax
  66d852:	4c 89 de             	mov    %r11,%rsi
  66d855:	48 89 5c 24 28       	mov    %rbx,0x28(%rsp)
  66d85a:	e9 ff dc ff ff       	jmp    66b55e <<gpui_canvas::text::planner::Planner>::shape+0x8ce>
  66d85f:	b9 04 00 00 00       	mov    $0x4,%ecx
  66d864:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  66d86a:	48 8d bc 24 e8 00 00 	lea    0xe8(%rsp),%rdi
  66d871:	00 
  66d872:	48 89 da             	mov    %rbx,%rdx
  66d875:	e8 26 67 ff ff       	call   663fa0 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  66d87a:	e9 88 e2 ff ff       	jmp    66bb07 <<gpui_canvas::text::planner::Planner>::shape+0xe77>
  66d87f:	c7 84 24 90 00 00 00 	movl   $0x7,0x90(%rsp)
  66d886:	07 00 00 00 
  66d88a:	eb 0b                	jmp    66d897 <<gpui_canvas::text::planner::Planner>::shape+0x2c07>
  66d88c:	c7 84 24 90 00 00 00 	movl   $0x4,0x90(%rsp)
  66d893:	04 00 00 00 
  66d897:	48 c7 84 24 88 00 00 	movq   $0xffffffffffffffff,0x88(%rsp)
  66d89e:	00 ff ff ff ff 
  66d8a3:	4c 8b 2c 24          	mov    (%rsp),%r13
  66d8a7:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
  66d8ae:	00 
  66d8af:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  66d8b3:	74 76                	je     66d92b <<gpui_canvas::text::planner::Planner>::shape+0x2c9b>
  66d8b5:	48 85 c0             	test   %rax,%rax
  66d8b8:	74 1b                	je     66d8d5 <<gpui_canvas::text::planner::Planner>::shape+0x2c45>
  66d8ba:	48 8b bc 24 58 01 00 	mov    0x158(%rsp),%rdi
  66d8c1:	00 
  66d8c2:	48 c1 e0 03          	shl    $0x3,%rax
  66d8c6:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  66d8ca:	ba 04 00 00 00       	mov    $0x4,%edx
  66d8cf:	ff 15 4b d5 11 00    	call   *0x11d54b(%rip)        # 78ae20 <_DYNAMIC+0x238>
  66d8d5:	48 8b 84 24 68 01 00 	mov    0x168(%rsp),%rax
  66d8dc:	00 
  66d8dd:	48 85 c0             	test   %rax,%rax
  66d8e0:	74 1b                	je     66d8fd <<gpui_canvas::text::planner::Planner>::shape+0x2c6d>
  66d8e2:	48 8b bc 24 70 01 00 	mov    0x170(%rsp),%rdi
  66d8e9:	00 
  66d8ea:	48 c1 e0 03          	shl    $0x3,%rax
  66d8ee:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  66d8f2:	ba 04 00 00 00       	mov    $0x4,%edx
  66d8f7:	ff 15 23 d5 11 00    	call   *0x11d523(%rip)        # 78ae20 <_DYNAMIC+0x238>
  66d8fd:	48 8b 84 24 80 01 00 	mov    0x180(%rsp),%rax
  66d904:	00 
  66d905:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  66d909:	74 20                	je     66d92b <<gpui_canvas::text::planner::Planner>::shape+0x2c9b>
  66d90b:	48 85 c0             	test   %rax,%rax
  66d90e:	74 1b                	je     66d92b <<gpui_canvas::text::planner::Planner>::shape+0x2c9b>
  66d910:	48 8b bc 24 88 01 00 	mov    0x188(%rsp),%rdi
  66d917:	00 
  66d918:	48 c1 e0 02          	shl    $0x2,%rax
  66d91c:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  66d920:	ba 04 00 00 00       	mov    $0x4,%edx
  66d925:	ff 15 f5 d4 11 00    	call   *0x11d4f5(%rip)        # 78ae20 <_DYNAMIC+0x238>
  66d92b:	48 8b b4 24 e8 00 00 	mov    0xe8(%rsp),%rsi
  66d932:	00 
  66d933:	48 85 f6             	test   %rsi,%rsi
  66d936:	74 17                	je     66d94f <<gpui_canvas::text::planner::Planner>::shape+0x2cbf>
  66d938:	48 8b bc 24 f0 00 00 	mov    0xf0(%rsp),%rdi
  66d93f:	00 
  66d940:	48 c1 e6 04          	shl    $0x4,%rsi
  66d944:	ba 04 00 00 00       	mov    $0x4,%edx
  66d949:	ff 15 d1 d4 11 00    	call   *0x11d4d1(%rip)        # 78ae20 <_DYNAMIC+0x238>
  66d94f:	48 8b b4 24 a0 02 00 	mov    0x2a0(%rsp),%rsi
  66d956:	00 
  66d957:	48 83 fe fd          	cmp    $0xfffffffffffffffd,%rsi
  66d95b:	77 18                	ja     66d975 <<gpui_canvas::text::planner::Planner>::shape+0x2ce5>
  66d95d:	48 85 f6             	test   %rsi,%rsi
  66d960:	74 13                	je     66d975 <<gpui_canvas::text::planner::Planner>::shape+0x2ce5>
  66d962:	48 8b bc 24 a8 02 00 	mov    0x2a8(%rsp),%rdi
  66d969:	00 
  66d96a:	ba 01 00 00 00       	mov    $0x1,%edx
  66d96f:	ff 15 ab d4 11 00    	call   *0x11d4ab(%rip)        # 78ae20 <_DYNAMIC+0x238>
  66d975:	48 8b b4 24 b8 02 00 	mov    0x2b8(%rsp),%rsi
  66d97c:	00 
  66d97d:	48 83 fe fd          	cmp    $0xfffffffffffffffd,%rsi
  66d981:	77 18                	ja     66d99b <<gpui_canvas::text::planner::Planner>::shape+0x2d0b>
  66d983:	48 85 f6             	test   %rsi,%rsi
  66d986:	74 13                	je     66d99b <<gpui_canvas::text::planner::Planner>::shape+0x2d0b>
  66d988:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
  66d98f:	00 
  66d990:	ba 01 00 00 00       	mov    $0x1,%edx
  66d995:	ff 15 85 d4 11 00    	call   *0x11d485(%rip)        # 78ae20 <_DYNAMIC+0x238>
  66d99b:	48 8b b4 24 d0 02 00 	mov    0x2d0(%rsp),%rsi
  66d9a2:	00 
  66d9a3:	48 83 fe fd          	cmp    $0xfffffffffffffffd,%rsi
  66d9a7:	77 18                	ja     66d9c1 <<gpui_canvas::text::planner::Planner>::shape+0x2d31>
  66d9a9:	48 85 f6             	test   %rsi,%rsi
  66d9ac:	74 13                	je     66d9c1 <<gpui_canvas::text::planner::Planner>::shape+0x2d31>
  66d9ae:	48 8b bc 24 d8 02 00 	mov    0x2d8(%rsp),%rdi
  66d9b5:	00 
  66d9b6:	ba 01 00 00 00       	mov    $0x1,%edx
  66d9bb:	ff 15 5f d4 11 00    	call   *0x11d45f(%rip)        # 78ae20 <_DYNAMIC+0x238>
  66d9c1:	49 8d bd c8 08 00 00 	lea    0x8c8(%r13),%rdi
  66d9c8:	e8 23 b7 ff ff       	call   6690f0 <core::ptr::drop_glue::<parley::layout::layout::Layout<()>>>
  66d9cd:	49 c7 85 c8 08 00 00 	movq   $0x0,0x8c8(%r13)
  66d9d4:	00 00 00 00 
  66d9d8:	49 c7 85 d0 08 00 00 	movq   $0x4,0x8d0(%r13)
  66d9df:	04 00 00 00 
  66d9e3:	0f 57 c0             	xorps  %xmm0,%xmm0
  66d9e6:	41 0f 11 85 d8 08 00 	movups %xmm0,0x8d8(%r13)
  66d9ed:	00 
  66d9ee:	49 c7 85 e8 08 00 00 	movq   $0x4,0x8e8(%r13)
  66d9f5:	04 00 00 00 
  66d9f9:	41 0f 11 85 f0 08 00 	movups %xmm0,0x8f0(%r13)
  66da00:	00 
  66da01:	49 c7 85 00 09 00 00 	movq   $0x8,0x900(%r13)
  66da08:	08 00 00 00 
  66da0c:	41 0f 11 85 08 09 00 	movups %xmm0,0x908(%r13)
  66da13:	00 
  66da14:	49 c7 85 18 09 00 00 	movq   $0x8,0x918(%r13)
  66da1b:	08 00 00 00 
  66da1f:	41 0f 11 85 20 09 00 	movups %xmm0,0x920(%r13)
  66da26:	00 
  66da27:	49 c7 85 30 09 00 00 	movq   $0x4,0x930(%r13)
  66da2e:	04 00 00 00 
  66da32:	41 0f 11 85 38 09 00 	movups %xmm0,0x938(%r13)
  66da39:	00 
  66da3a:	49 c7 85 48 09 00 00 	movq   $0x4,0x948(%r13)
  66da41:	04 00 00 00 
  66da45:	41 0f 11 85 50 09 00 	movups %xmm0,0x950(%r13)
  66da4c:	00 
  66da4d:	49 c7 85 60 09 00 00 	movq   $0x4,0x960(%r13)
  66da54:	04 00 00 00 
  66da58:	41 0f 11 85 68 09 00 	movups %xmm0,0x968(%r13)
  66da5f:	00 
  66da60:	49 c7 85 78 09 00 00 	movq   $0x8,0x978(%r13)
  66da67:	08 00 00 00 
  66da6b:	41 0f 11 85 80 09 00 	movups %xmm0,0x980(%r13)
  66da72:	00 
  66da73:	49 c7 85 90 09 00 00 	movq   $0x2,0x990(%r13)
  66da7a:	02 00 00 00 
  66da7e:	41 0f 11 85 98 09 00 	movups %xmm0,0x998(%r13)
  66da85:	00 
  66da86:	49 c7 85 a8 09 00 00 	movq   $0x4,0x9a8(%r13)
  66da8d:	04 00 00 00 
  66da91:	41 0f 11 85 b0 09 00 	movups %xmm0,0x9b0(%r13)
  66da98:	00 
  66da99:	49 c7 85 c0 09 00 00 	movq   $0x8,0x9c0(%r13)
  66daa0:	08 00 00 00 
  66daa4:	41 0f 11 85 c8 09 00 	movups %xmm0,0x9c8(%r13)
  66daab:	00 
  66daac:	49 c7 85 d8 09 00 00 	movq   $0x8,0x9d8(%r13)
  66dab3:	08 00 00 00 
  66dab7:	41 0f 11 85 e0 09 00 	movups %xmm0,0x9e0(%r13)
  66dabe:	00 
  66dabf:	49 c7 85 f0 09 00 00 	movq   $0x8,0x9f0(%r13)
  66dac6:	08 00 00 00 
  66daca:	41 0f 11 85 f8 09 00 	movups %xmm0,0x9f8(%r13)
  66dad1:	00 
  66dad2:	49 c7 85 08 0a 00 00 	movq   $0x4,0xa08(%r13)
  66dad9:	04 00 00 00 
  66dadd:	41 0f 11 85 10 0a 00 	movups %xmm0,0xa10(%r13)
  66dae4:	00 
  66dae5:	41 c7 85 20 0a 00 00 	movl   $0x3f800000,0xa20(%r13)
  66daec:	00 00 80 3f 
  66daf0:	41 0f 11 85 24 0a 00 	movups %xmm0,0xa24(%r13)
  66daf7:	00 
  66daf8:	49 c7 85 32 0a 00 00 	movq   $0x0,0xa32(%r13)
  66daff:	00 00 00 00 
  66db03:	66 41 c7 85 3a 0a 00 	movw   $0xff01,0xa3a(%r13)
  66db0a:	00 01 ff 
  66db0d:	41 c6 85 3c 0a 00 00 	movb   $0x0,0xa3c(%r13)
  66db14:	00 
  66db15:	48 8b 8c 24 b8 00 00 	mov    0xb8(%rsp),%rcx
  66db1c:	00 
  66db1d:	48 8b 84 24 38 03 00 	mov    0x338(%rsp),%rax
  66db24:	00 
  66db25:	48 89 48 30          	mov    %rcx,0x30(%rax)
  66db29:	0f 10 84 24 88 00 00 	movups 0x88(%rsp),%xmm0
  66db30:	00 
  66db31:	0f 10 8c 24 98 00 00 	movups 0x98(%rsp),%xmm1
  66db38:	00 
  66db39:	0f 10 94 24 a8 00 00 	movups 0xa8(%rsp),%xmm2
  66db40:	00 
  66db41:	0f 11 50 20          	movups %xmm2,0x20(%rax)
  66db45:	0f 11 48 10          	movups %xmm1,0x10(%rax)
  66db49:	0f 11 00             	movups %xmm0,(%rax)
  66db4c:	48 81 c4 e8 11 00 00 	add    $0x11e8,%rsp
  66db53:	5b                   	pop    %rbx
  66db54:	41 5c                	pop    %r12
  66db56:	41 5d                	pop    %r13
  66db58:	41 5e                	pop    %r14
  66db5a:	41 5f                	pop    %r15
  66db5c:	5d                   	pop    %rbp
  66db5d:	c3                   	ret
  66db5e:	48 8d 35 13 03 12 00 	lea    0x120313(%rip),%rsi        # 78de78 <gpui_canvas::text::HEBREW_FONT>
  66db65:	48 8d 15 18 2b 9f ff 	lea    -0x60d4e8(%rip),%rdx        # 60684 <gpui_canvas::text::HEBREW_BYTES>
  66db6c:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  66db73:	00 
  66db74:	b9 14 69 00 00       	mov    $0x6914,%ecx
  66db79:	45 31 c0             	xor    %r8d,%r8d
  66db7c:	e8 af 64 ff ff       	call   664030 <<gpui_canvas::text::FontFace>::shared_static>
  66db81:	80 bc 24 10 07 00 00 	cmpb   $0x0,0x710(%rsp)
  66db88:	00 
  66db89:	0f 85 f2 d4 ff ff    	jne    66b081 <<gpui_canvas::text::planner::Planner>::shape+0x3f1>
  66db8f:	44 89 fd             	mov    %r15d,%ebp
  66db92:	49 8d 9d 50 0a 00 00 	lea    0xa50(%r13),%rbx
  66db99:	4c 8b bc 24 18 07 00 	mov    0x718(%rsp),%r15
  66dba0:	00 
  66dba1:	48 8b 03             	mov    (%rbx),%rax
  66dba4:	48 85 c0             	test   %rax,%rax
  66dba7:	74 0f                	je     66dbb8 <<gpui_canvas::text::planner::Planner>::shape+0x2f28>
  66dba9:	f0 48 ff 08          	lock decq (%rax)
  66dbad:	75 09                	jne    66dbb8 <<gpui_canvas::text::planner::Planner>::shape+0x2f28>
  66dbaf:	48 89 df             	mov    %rbx,%rdi
  66dbb2:	ff 15 90 d2 11 00    	call   *0x11d290(%rip)        # 78ae48 <_DYNAMIC+0x260>
  66dbb8:	4d 89 bd 50 0a 00 00 	mov    %r15,0xa50(%r13)
  66dbbf:	be 02 00 00 00       	mov    $0x2,%esi
  66dbc4:	4c 89 ef             	mov    %r13,%rdi
  66dbc7:	e8 a4 0b 00 00       	call   66e770 <<gpui_canvas::text::planner::Planner>::register>
  66dbcc:	83 f8 ff             	cmp    $0xffffffff,%eax
  66dbcf:	41 89 ef             	mov    %ebp,%r15d
  66dbd2:	0f 85 08 d5 ff ff    	jne    66b0e0 <<gpui_canvas::text::planner::Planner>::shape+0x450>
  66dbd8:	e9 42 d5 ff ff       	jmp    66b11f <<gpui_canvas::text::planner::Planner>::shape+0x48f>
  66dbdd:	48 8b b4 24 10 07 00 	mov    0x710(%rsp),%rsi
  66dbe4:	00 
  66dbe5:	48 85 f6             	test   %rsi,%rsi
  66dbe8:	74 17                	je     66dc01 <<gpui_canvas::text::planner::Planner>::shape+0x2f71>
  66dbea:	48 8b bc 24 18 07 00 	mov    0x718(%rsp),%rdi
  66dbf1:	00 
  66dbf2:	48 c1 e6 03          	shl    $0x3,%rsi
  66dbf6:	ba 08 00 00 00       	mov    $0x8,%edx
  66dbfb:	ff 15 1f d2 11 00    	call   *0x11d21f(%rip)        # 78ae20 <_DYNAMIC+0x238>
  66dc01:	b8 01 00 00 00       	mov    $0x1,%eax
  66dc06:	4c 8b 2c 24          	mov    (%rsp),%r13
  66dc0a:	89 84 24 90 00 00 00 	mov    %eax,0x90(%rsp)
  66dc11:	89 94 24 94 00 00 00 	mov    %edx,0x94(%rsp)
  66dc18:	48 c7 84 24 88 00 00 	movq   $0xffffffffffffffff,0x88(%rsp)
  66dc1f:	00 ff ff ff ff 
  66dc24:	e9 7e fc ff ff       	jmp    66d8a7 <<gpui_canvas::text::planner::Planner>::shape+0x2c17>
  66dc29:	c7 84 24 90 00 00 00 	movl   $0x3,0x90(%rsp)
  66dc30:	03 00 00 00 
  66dc34:	e9 5e fc ff ff       	jmp    66d897 <<gpui_canvas::text::planner::Planner>::shape+0x2c07>
  66dc39:	48 c7 84 24 90 00 00 	movq   $0x3,0x90(%rsp)
  66dc40:	00 03 00 00 00 
  66dc45:	e9 4d fc ff ff       	jmp    66d897 <<gpui_canvas::text::planner::Planner>::shape+0x2c07>
  66dc4a:	c7 84 24 90 00 00 00 	movl   $0x1,0x90(%rsp)
  66dc51:	01 00 00 00 
  66dc55:	e9 3d fc ff ff       	jmp    66d897 <<gpui_canvas::text::planner::Planner>::shape+0x2c07>
  66dc5a:	c7 84 24 90 00 00 00 	movl   $0x3,0x90(%rsp)
  66dc61:	03 00 00 00 
  66dc65:	8b 84 24 18 02 00 00 	mov    0x218(%rsp),%eax
  66dc6c:	89 84 24 94 00 00 00 	mov    %eax,0x94(%rsp)
  66dc73:	e9 1f fc ff ff       	jmp    66d897 <<gpui_canvas::text::planner::Planner>::shape+0x2c07>
  66dc78:	48 c7 84 24 90 00 00 	movq   $0xc,0x90(%rsp)
  66dc7f:	00 0c 00 00 00 
  66dc84:	48 c7 84 24 88 00 00 	movq   $0xffffffffffffffff,0x88(%rsp)
  66dc8b:	00 ff ff ff ff 
  66dc90:	49 89 f5             	mov    %rsi,%r13
  66dc93:	e9 0f fc ff ff       	jmp    66d8a7 <<gpui_canvas::text::planner::Planner>::shape+0x2c17>
  66dc98:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  66dc9f:	00 ff 
  66dca1:	4c 8b 2c 24          	mov    (%rsp),%r13
  66dca5:	0f 84 4a 01 00 00    	je     66ddf5 <<gpui_canvas::text::planner::Planner>::shape+0x3165>
  66dcab:	48 8b 84 24 80 01 00 	mov    0x180(%rsp),%rax
  66dcb2:	00 
  66dcb3:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  66dcb7:	0f 84 1b 03 00 00    	je     66dfd8 <<gpui_canvas::text::planner::Planner>::shape+0x3348>
  66dcbd:	48 8b b4 24 90 01 00 	mov    0x190(%rsp),%rsi
  66dcc4:	00 
  66dcc5:	48 39 f0             	cmp    %rsi,%rax
  66dcc8:	0f 86 0a 03 00 00    	jbe    66dfd8 <<gpui_canvas::text::planner::Planner>::shape+0x3348>
  66dcce:	48 8d bc 24 80 01 00 	lea    0x180(%rsp),%rdi
  66dcd5:	00 
  66dcd6:	e8 e5 0c 00 00       	call   66e9c0 <<alloc::raw_vec::RawVecInner>::shrink>
  66dcdb:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  66dcdf:	0f 84 f3 02 00 00    	je     66dfd8 <<gpui_canvas::text::planner::Planner>::shape+0x3348>
  66dce5:	48 89 c7             	mov    %rax,%rdi
  66dce8:	48 89 d6             	mov    %rdx,%rsi
  66dceb:	ff 15 47 d2 11 00    	call   *0x11d247(%rip)        # 78af38 <_DYNAMIC+0x350>
  66dcf1:	e9 25 06 00 00       	jmp    66e31b <<gpui_canvas::text::planner::Planner>::shape+0x368b>
  66dcf6:	4c 8b 2c 24          	mov    (%rsp),%r13
  66dcfa:	eb 25                	jmp    66dd21 <<gpui_canvas::text::planner::Planner>::shape+0x3091>
  66dcfc:	c7 44 24 0c 00 00 00 	movl   $0x0,0xc(%rsp)
  66dd03:	00 
  66dd04:	4c 8b 8c 24 f8 02 00 	mov    0x2f8(%rsp),%r9
  66dd0b:	00 
  66dd0c:	4d 85 c9             	test   %r9,%r9
  66dd0f:	74 23                	je     66dd34 <<gpui_canvas::text::planner::Planner>::shape+0x30a4>
  66dd11:	4c 8b 2c 24          	mov    (%rsp),%r13
  66dd15:	48 8b 8c 24 10 01 00 	mov    0x110(%rsp),%rcx
  66dd1c:	00 
  66dd1d:	8b 54 24 0c          	mov    0xc(%rsp),%edx
  66dd21:	49 39 c9             	cmp    %rcx,%r9
  66dd24:	73 23                	jae    66dd49 <<gpui_canvas::text::planner::Planner>::shape+0x30b9>
  66dd26:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  66dd2b:	42 80 3c 08 bf       	cmpb   $0xbf,(%rax,%r9,1)
  66dd30:	7f 1c                	jg     66dd4e <<gpui_canvas::text::planner::Planner>::shape+0x30be>
  66dd32:	eb 4c                	jmp    66dd80 <<gpui_canvas::text::planner::Planner>::shape+0x30f0>
  66dd34:	45 31 c9             	xor    %r9d,%r9d
  66dd37:	4c 8b 2c 24          	mov    (%rsp),%r13
  66dd3b:	48 8b 8c 24 10 01 00 	mov    0x110(%rsp),%rcx
  66dd42:	00 
  66dd43:	8b 54 24 0c          	mov    0xc(%rsp),%edx
  66dd47:	eb 05                	jmp    66dd4e <<gpui_canvas::text::planner::Planner>::shape+0x30be>
  66dd49:	49 89 c9             	mov    %rcx,%r9
  66dd4c:	75 32                	jne    66dd80 <<gpui_canvas::text::planner::Planner>::shape+0x30f0>
  66dd4e:	84 d2                	test   %dl,%dl
  66dd50:	74 1a                	je     66dd6c <<gpui_canvas::text::planner::Planner>::shape+0x30dc>
  66dd52:	4c 39 cd             	cmp    %r9,%rbp
  66dd55:	74 29                	je     66dd80 <<gpui_canvas::text::planner::Planner>::shape+0x30f0>
  66dd57:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
  66dd5c:	43 0f b6 0c 08       	movzbl (%r8,%r9,1),%ecx
  66dd61:	84 c9                	test   %cl,%cl
  66dd63:	78 44                	js     66dda9 <<gpui_canvas::text::planner::Planner>::shape+0x3119>
  66dd65:	b8 0b 00 00 00       	mov    $0xb,%eax
  66dd6a:	eb 1e                	jmp    66dd8a <<gpui_canvas::text::planner::Planner>::shape+0x30fa>
  66dd6c:	48 39 cd             	cmp    %rcx,%rbp
  66dd6f:	73 0d                	jae    66dd7e <<gpui_canvas::text::planner::Planner>::shape+0x30ee>
  66dd71:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  66dd76:	80 3c 28 bf          	cmpb   $0xbf,(%rax,%rbp,1)
  66dd7a:	7f d6                	jg     66dd52 <<gpui_canvas::text::planner::Planner>::shape+0x30c2>
  66dd7c:	eb 02                	jmp    66dd80 <<gpui_canvas::text::planner::Planner>::shape+0x30f0>
  66dd7e:	74 d2                	je     66dd52 <<gpui_canvas::text::planner::Planner>::shape+0x30c2>
  66dd80:	b8 03 00 00 00       	mov    $0x3,%eax
  66dd85:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
  66dd8a:	89 84 24 90 00 00 00 	mov    %eax,0x90(%rsp)
  66dd91:	89 8c 24 94 00 00 00 	mov    %ecx,0x94(%rsp)
  66dd98:	48 c7 84 24 88 00 00 	movq   $0xffffffffffffffff,0x88(%rsp)
  66dd9f:	00 ff ff ff ff 
  66dda4:	e9 fe fa ff ff       	jmp    66d8a7 <<gpui_canvas::text::planner::Planner>::shape+0x2c17>
  66dda9:	89 ca                	mov    %ecx,%edx
  66ddab:	83 e2 1f             	and    $0x1f,%edx
  66ddae:	43 0f b6 7c 08 01    	movzbl 0x1(%r8,%r9,1),%edi
  66ddb4:	83 e7 3f             	and    $0x3f,%edi
  66ddb7:	b8 0b 00 00 00       	mov    $0xb,%eax
  66ddbc:	80 f9 df             	cmp    $0xdf,%cl
  66ddbf:	76 2b                	jbe    66ddec <<gpui_canvas::text::planner::Planner>::shape+0x315c>
  66ddc1:	43 0f b6 74 08 02    	movzbl 0x2(%r8,%r9,1),%esi
  66ddc7:	c1 e7 06             	shl    $0x6,%edi
  66ddca:	83 e6 3f             	and    $0x3f,%esi
  66ddcd:	09 fe                	or     %edi,%esi
  66ddcf:	80 f9 f0             	cmp    $0xf0,%cl
  66ddd2:	72 7a                	jb     66de4e <<gpui_canvas::text::planner::Planner>::shape+0x31be>
  66ddd4:	43 0f b6 4c 08 03    	movzbl 0x3(%r8,%r9,1),%ecx
  66ddda:	83 e2 07             	and    $0x7,%edx
  66dddd:	c1 e2 12             	shl    $0x12,%edx
  66dde0:	c1 e6 06             	shl    $0x6,%esi
  66dde3:	83 e1 3f             	and    $0x3f,%ecx
  66dde6:	09 f1                	or     %esi,%ecx
  66dde8:	09 d1                	or     %edx,%ecx
  66ddea:	eb 9e                	jmp    66dd8a <<gpui_canvas::text::planner::Planner>::shape+0x30fa>
  66ddec:	c1 e2 06             	shl    $0x6,%edx
  66ddef:	09 fa                	or     %edi,%edx
  66ddf1:	89 d1                	mov    %edx,%ecx
  66ddf3:	eb 95                	jmp    66dd8a <<gpui_canvas::text::planner::Planner>::shape+0x30fa>
  66ddf5:	48 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%rax
  66ddfc:	00 
  66ddfd:	48 85 c0             	test   %rax,%rax
  66de00:	0f 84 b6 00 00 00    	je     66debc <<gpui_canvas::text::planner::Planner>::shape+0x322c>
  66de06:	48 8b 8c 24 f0 00 00 	mov    0xf0(%rsp),%rcx
  66de0d:	00 
  66de0e:	48 c1 e0 04          	shl    $0x4,%rax
  66de12:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
  66de17:	2b 54 01 f0          	sub    -0x10(%rcx,%rax,1),%edx
  66de1b:	0f 83 a8 00 00 00    	jae    66dec9 <<gpui_canvas::text::planner::Planner>::shape+0x3239>
  66de21:	c7 84 24 90 00 00 00 	movl   $0x3,0x90(%rsp)
  66de28:	03 00 00 00 
  66de2c:	48 c7 84 24 88 00 00 	movq   $0xffffffffffffffff,0x88(%rsp)
  66de33:	00 ff ff ff ff 
  66de38:	48 8b b4 24 e8 00 00 	mov    0xe8(%rsp),%rsi
  66de3f:	00 
  66de40:	48 85 f6             	test   %rsi,%rsi
  66de43:	0f 85 ef fa ff ff    	jne    66d938 <<gpui_canvas::text::planner::Planner>::shape+0x2ca8>
  66de49:	e9 01 fb ff ff       	jmp    66d94f <<gpui_canvas::text::planner::Planner>::shape+0x2cbf>
  66de4e:	c1 e2 0c             	shl    $0xc,%edx
  66de51:	09 d6                	or     %edx,%esi
  66de53:	89 f1                	mov    %esi,%ecx
  66de55:	e9 30 ff ff ff       	jmp    66dd8a <<gpui_canvas::text::planner::Planner>::shape+0x30fa>
  66de5a:	48 8d 3d c7 01 bf ff 	lea    -0x40fe39(%rip),%rdi        # 25e028 <anon.644d4d4a3d990e1ee377937a18c5c2e2.4.llvm.5582240029561959794>
  66de61:	48 8d 15 70 2a 11 00 	lea    0x112a70(%rip),%rdx        # 7808d8 <anon.644d4d4a3d990e1ee377937a18c5c2e2.5.llvm.5582240029561959794>
  66de68:	be ad 00 00 00       	mov    $0xad,%esi
  66de6d:	ff 15 a5 d0 11 00    	call   *0x11d0a5(%rip)        # 78af18 <_DYNAMIC+0x330>
  66de73:	e9 a3 04 00 00       	jmp    66e31b <<gpui_canvas::text::planner::Planner>::shape+0x368b>
  66de78:	48 8d 0d d9 23 11 00 	lea    0x1123d9(%rip),%rcx        # 780258 <anon.9a0de72a7eba2b0cb10eb2c5cf6d915d.1.llvm.15750432251718107962+0x70>
  66de7f:	48 89 df             	mov    %rbx,%rdi
  66de82:	48 8b 94 24 40 01 00 	mov    0x140(%rsp),%rdx
  66de89:	00 
  66de8a:	ff 15 b0 d2 11 00    	call   *0x11d2b0(%rip)        # 78b140 <_DYNAMIC+0x558>
  66de90:	e9 86 04 00 00       	jmp    66e31b <<gpui_canvas::text::planner::Planner>::shape+0x368b>
  66de95:	41 bc 03 00 00 00    	mov    $0x3,%r12d
  66de9b:	8b 44 24 08          	mov    0x8(%rsp),%eax
  66de9f:	41 89 c7             	mov    %eax,%r15d
  66dea2:	e9 3f d2 ff ff       	jmp    66b0e6 <<gpui_canvas::text::planner::Planner>::shape+0x456>
  66dea7:	41 bc 03 00 00 00    	mov    $0x3,%r12d
  66dead:	8b 84 24 d0 01 00 00 	mov    0x1d0(%rsp),%eax
  66deb4:	41 89 c7             	mov    %eax,%r15d
  66deb7:	e9 2a d2 ff ff       	jmp    66b0e6 <<gpui_canvas::text::planner::Planner>::shape+0x456>
  66debc:	48 83 7c 24 50 00    	cmpq   $0x0,0x50(%rsp)
  66dec2:	75 11                	jne    66ded5 <<gpui_canvas::text::planner::Planner>::shape+0x3245>
  66dec4:	e9 0f 01 00 00       	jmp    66dfd8 <<gpui_canvas::text::planner::Planner>::shape+0x3348>
  66dec9:	81 fa ff 00 00 00    	cmp    $0xff,%edx
  66decf:	0f 86 b1 02 00 00    	jbe    66e186 <<gpui_canvas::text::planner::Planner>::shape+0x34f6>
  66ded5:	bf 04 00 00 00       	mov    $0x4,%edi
  66deda:	be 18 00 00 00       	mov    $0x18,%esi
  66dedf:	e8 ac 0d 00 00       	call   66ec90 <alloc::boxed::box_new_uninit>
  66dee4:	48 89 c3             	mov    %rax,%rbx
  66dee7:	8b 84 24 f8 00 00 00 	mov    0xf8(%rsp),%eax
  66deee:	c7 03 00 00 00 00    	movl   $0x0,(%rbx)
  66def4:	4c 8b 7c 24 50       	mov    0x50(%rsp),%r15
  66def9:	44 89 7b 04          	mov    %r15d,0x4(%rbx)
  66defd:	c7 43 08 00 00 00 00 	movl   $0x0,0x8(%rbx)
  66df04:	89 43 0c             	mov    %eax,0xc(%rbx)
  66df07:	c7 43 10 00 00 00 00 	movl   $0x0,0x10(%rbx)
  66df0e:	66 c7 43 14 00 00    	movw   $0x0,0x14(%rbx)
  66df14:	bf 04 00 00 00       	mov    $0x4,%edi
  66df19:	be 18 00 00 00       	mov    $0x18,%esi
  66df1e:	e8 6d 0d 00 00       	call   66ec90 <alloc::boxed::box_new_uninit>
  66df23:	49 89 c6             	mov    %rax,%r14
  66df26:	c7 00 00 00 00 00    	movl   $0x0,(%rax)
  66df2c:	44 89 78 04          	mov    %r15d,0x4(%rax)
  66df30:	c7 40 08 00 00 00 00 	movl   $0x0,0x8(%rax)
  66df37:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
  66df3d:	f3 0f 11 40 0c       	movss  %xmm0,0xc(%rax)
  66df42:	f3 0f 10 44 24 7c    	movss  0x7c(%rsp),%xmm0
  66df48:	f3 0f 11 40 10       	movss  %xmm0,0x10(%rax)
  66df4d:	0f 28 84 24 80 02 00 	movaps 0x280(%rsp),%xmm0
  66df54:	00 
  66df55:	f3 0f 11 40 14       	movss  %xmm0,0x14(%rax)
  66df5a:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  66df61:	00 ff 
  66df63:	74 0d                	je     66df72 <<gpui_canvas::text::planner::Planner>::shape+0x32e2>
  66df65:	48 8d bc 24 50 01 00 	lea    0x150(%rsp),%rdi
  66df6c:	00 
  66df6d:	e8 ae c2 ff ff       	call   66a220 <core::ptr::drop_glue::<gpui_canvas::text::layout::TextGeometry>>
  66df72:	48 c7 84 24 50 01 00 	movq   $0x1,0x150(%rsp)
  66df79:	00 01 00 00 00 
  66df7e:	48 89 9c 24 58 01 00 	mov    %rbx,0x158(%rsp)
  66df85:	00 
  66df86:	48 c7 84 24 60 01 00 	movq   $0x1,0x160(%rsp)
  66df8d:	00 01 00 00 00 
  66df92:	48 c7 84 24 68 01 00 	movq   $0x1,0x168(%rsp)
  66df99:	00 01 00 00 00 
  66df9e:	4c 89 b4 24 70 01 00 	mov    %r14,0x170(%rsp)
  66dfa5:	00 
  66dfa6:	48 c7 84 24 78 01 00 	movq   $0x1,0x178(%rsp)
  66dfad:	00 01 00 00 00 
  66dfb2:	48 c7 84 24 80 01 00 	movq   $0xffffffffffffffff,0x180(%rsp)
  66dfb9:	00 ff ff ff ff 
  66dfbe:	44 89 bc 24 98 01 00 	mov    %r15d,0x198(%rsp)
  66dfc5:	00 
  66dfc6:	f3 0f 10 84 24 84 00 	movss  0x84(%rsp),%xmm0
  66dfcd:	00 00 
  66dfcf:	f3 0f 11 84 24 9c 01 	movss  %xmm0,0x19c(%rsp)
  66dfd6:	00 00 
  66dfd8:	4c 8b bc 24 e8 00 00 	mov    0xe8(%rsp),%r15
  66dfdf:	00 
  66dfe0:	48 8b 9c 24 f0 00 00 	mov    0xf0(%rsp),%rbx
  66dfe7:	00 
  66dfe8:	4c 8b b4 24 f8 00 00 	mov    0xf8(%rsp),%r14
  66dfef:	00 
  66dff0:	4c 89 ef             	mov    %r13,%rdi
  66dff3:	48 8b b4 24 08 02 00 	mov    0x208(%rsp),%rsi
  66dffa:	00 
  66dffb:	e8 30 06 00 00       	call   66e630 <<gpui_canvas::text::planner::Planner>::font_set>
  66e000:	49 89 c4             	mov    %rax,%r12
  66e003:	48 89 84 24 c0 04 00 	mov    %rax,0x4c0(%rsp)
  66e00a:	00 
  66e00b:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
  66e012:	00 
  66e013:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  66e017:	0f 84 c7 00 00 00    	je     66e0e4 <<gpui_canvas::text::planner::Planner>::shape+0x3454>
  66e01d:	48 8d 94 24 58 01 00 	lea    0x158(%rsp),%rdx
  66e024:	00 
  66e025:	48 8b 4a 40          	mov    0x40(%rdx),%rcx
  66e029:	48 89 8c 24 68 07 00 	mov    %rcx,0x768(%rsp)
  66e030:	00 
  66e031:	0f 10 02             	movups (%rdx),%xmm0
  66e034:	0f 10 4a 10          	movups 0x10(%rdx),%xmm1
  66e038:	0f 10 52 20          	movups 0x20(%rdx),%xmm2
  66e03c:	0f 10 5a 30          	movups 0x30(%rdx),%xmm3
  66e040:	0f 11 9c 24 58 07 00 	movups %xmm3,0x758(%rsp)
  66e047:	00 
  66e048:	0f 11 94 24 48 07 00 	movups %xmm2,0x748(%rsp)
  66e04f:	00 
  66e050:	0f 11 8c 24 38 07 00 	movups %xmm1,0x738(%rsp)
  66e057:	00 
  66e058:	0f 11 84 24 28 07 00 	movups %xmm0,0x728(%rsp)
  66e05f:	00 
  66e060:	48 c7 84 24 10 07 00 	movq   $0x1,0x710(%rsp)
  66e067:	00 01 00 00 00 
  66e06c:	48 c7 84 24 18 07 00 	movq   $0x1,0x718(%rsp)
  66e073:	00 01 00 00 00 
  66e078:	4c 8d ac 24 20 07 00 	lea    0x720(%rsp),%r13
  66e07f:	00 
  66e080:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
  66e087:	00 
  66e088:	bf 08 00 00 00       	mov    $0x8,%edi
  66e08d:	be 60 00 00 00       	mov    $0x60,%esi
  66e092:	e8 f9 0b 00 00       	call   66ec90 <alloc::boxed::box_new_uninit>
  66e097:	0f 10 84 24 60 07 00 	movups 0x760(%rsp),%xmm0
  66e09e:	00 
  66e09f:	0f 11 40 50          	movups %xmm0,0x50(%rax)
  66e0a3:	0f 10 84 24 50 07 00 	movups 0x750(%rsp),%xmm0
  66e0aa:	00 
  66e0ab:	0f 11 40 40          	movups %xmm0,0x40(%rax)
  66e0af:	0f 10 84 24 10 07 00 	movups 0x710(%rsp),%xmm0
  66e0b6:	00 
  66e0b7:	0f 10 8c 24 20 07 00 	movups 0x720(%rsp),%xmm1
  66e0be:	00 
  66e0bf:	0f 10 94 24 30 07 00 	movups 0x730(%rsp),%xmm2
  66e0c6:	00 
  66e0c7:	0f 10 9c 24 40 07 00 	movups 0x740(%rsp),%xmm3
  66e0ce:	00 
  66e0cf:	0f 11 58 30          	movups %xmm3,0x30(%rax)
  66e0d3:	0f 11 50 20          	movups %xmm2,0x20(%rax)
  66e0d7:	0f 11 48 10          	movups %xmm1,0x10(%rax)
  66e0db:	0f 11 00             	movups %xmm0,(%rax)
  66e0de:	4c 8b 2c 24          	mov    (%rsp),%r13
  66e0e2:	eb 02                	jmp    66e0e6 <<gpui_canvas::text::planner::Planner>::shape+0x3456>
  66e0e4:	31 c0                	xor    %eax,%eax
  66e0e6:	4c 89 bc 24 88 00 00 	mov    %r15,0x88(%rsp)
  66e0ed:	00 
  66e0ee:	48 89 9c 24 90 00 00 	mov    %rbx,0x90(%rsp)
  66e0f5:	00 
  66e0f6:	4c 89 b4 24 98 00 00 	mov    %r14,0x98(%rsp)
  66e0fd:	00 
  66e0fe:	4c 89 a4 24 a0 00 00 	mov    %r12,0xa0(%rsp)
  66e105:	00 
  66e106:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
  66e10d:	00 
  66e10e:	0f 28 84 24 80 02 00 	movaps 0x280(%rsp),%xmm0
  66e115:	00 
  66e116:	f3 0f 11 84 24 b0 00 	movss  %xmm0,0xb0(%rsp)
  66e11d:	00 00 
  66e11f:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
  66e125:	f3 0f 11 84 24 b4 00 	movss  %xmm0,0xb4(%rsp)
  66e12c:	00 00 
  66e12e:	f3 0f 10 44 24 7c    	movss  0x7c(%rsp),%xmm0
  66e134:	f3 0f 11 84 24 b8 00 	movss  %xmm0,0xb8(%rsp)
  66e13b:	00 00 
  66e13d:	f3 0f 10 84 24 84 00 	movss  0x84(%rsp),%xmm0
  66e144:	00 00 
  66e146:	f3 0f 11 84 24 bc 00 	movss  %xmm0,0xbc(%rsp)
  66e14d:	00 00 
  66e14f:	48 8d bc 24 a0 02 00 	lea    0x2a0(%rsp),%rdi
  66e156:	00 
  66e157:	e8 a4 a8 ff ff       	call   668a00 <core::ptr::drop_glue::<[parlance::font_family::FontFamilyName; 3]>>
  66e15c:	49 83 ff ff          	cmp    $0xffffffffffffffff,%r15
  66e160:	0f 85 af f9 ff ff    	jne    66db15 <<gpui_canvas::text::planner::Planner>::shape+0x2e85>
  66e166:	e9 56 f8 ff ff       	jmp    66d9c1 <<gpui_canvas::text::planner::Planner>::shape+0x2d31>
  66e16b:	48 8d 0d 0e 24 11 00 	lea    0x11240e(%rip),%rcx        # 780580 <anon.bf1b5ed00d96edcfb74556a573b7af11.37.llvm.12998622219056141688>
  66e172:	48 89 f7             	mov    %rsi,%rdi
  66e175:	48 89 d6             	mov    %rdx,%rsi
  66e178:	4c 89 c2             	mov    %r8,%rdx
  66e17b:	ff 15 bf cf 11 00    	call   *0x11cfbf(%rip)        # 78b140 <_DYNAMIC+0x558>
  66e181:	e9 95 01 00 00       	jmp    66e31b <<gpui_canvas::text::planner::Planner>::shape+0x368b>
  66e186:	48 01 c1             	add    %rax,%rcx
  66e189:	88 51 ff             	mov    %dl,-0x1(%rcx)
  66e18c:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  66e193:	00 ff 
  66e195:	0f 85 10 fb ff ff    	jne    66dcab <<gpui_canvas::text::planner::Planner>::shape+0x301b>
  66e19b:	e9 38 fe ff ff       	jmp    66dfd8 <<gpui_canvas::text::planner::Planner>::shape+0x3348>
  66e1a0:	48 89 cb             	mov    %rcx,%rbx
  66e1a3:	48 8b 84 24 00 02 00 	mov    0x200(%rsp),%rax
  66e1aa:	00 
  66e1ab:	48 89 84 24 40 01 00 	mov    %rax,0x140(%rsp)
  66e1b2:	00 
  66e1b3:	48 8d 0d a6 21 11 00 	lea    0x1121a6(%rip),%rcx        # 780360 <anon.9a0de72a7eba2b0cb10eb2c5cf6d915d.1.llvm.15750432251718107962+0x178>
  66e1ba:	e9 c0 fc ff ff       	jmp    66de7f <<gpui_canvas::text::planner::Planner>::shape+0x31ef>
  66e1bf:	48 89 d3             	mov    %rdx,%rbx
  66e1c2:	4c 89 b4 24 40 01 00 	mov    %r14,0x140(%rsp)
  66e1c9:	00 
  66e1ca:	48 8d 0d 57 20 11 00 	lea    0x112057(%rip),%rcx        # 780228 <anon.9a0de72a7eba2b0cb10eb2c5cf6d915d.1.llvm.15750432251718107962+0x40>
  66e1d1:	e9 a9 fc ff ff       	jmp    66de7f <<gpui_canvas::text::planner::Planner>::shape+0x31ef>
  66e1d6:	48 8d 0d 4b 25 11 00 	lea    0x11254b(%rip),%rcx        # 780728 <anon.31a57d2255aad4ccd38042eb5d4e33a5.19.llvm.6090246580605116548>
  66e1dd:	ff 15 5d cf 11 00    	call   *0x11cf5d(%rip)        # 78b140 <_DYNAMIC+0x558>
  66e1e3:	e9 33 01 00 00       	jmp    66e31b <<gpui_canvas::text::planner::Planner>::shape+0x368b>
  66e1e8:	48 8d 0d 39 25 11 00 	lea    0x112539(%rip),%rcx        # 780728 <anon.31a57d2255aad4ccd38042eb5d4e33a5.19.llvm.6090246580605116548>
  66e1ef:	ff 15 4b cf 11 00    	call   *0x11cf4b(%rip)        # 78b140 <_DYNAMIC+0x558>
  66e1f5:	e9 21 01 00 00       	jmp    66e31b <<gpui_canvas::text::planner::Planner>::shape+0x368b>
  66e1fa:	48 8d 3d a7 2d 11 00 	lea    0x112da7(%rip),%rdi        # 780fa8 <anon.14afa313d7e478525b4e47a786e25a5c.45.llvm.5064344213933224292>
  66e201:	ff 15 19 cd 11 00    	call   *0x11cd19(%rip)        # 78af20 <_DYNAMIC+0x338>
  66e207:	e9 0f 01 00 00       	jmp    66e31b <<gpui_canvas::text::planner::Planner>::shape+0x368b>
  66e20c:	83 f8 fe             	cmp    $0xfffffffe,%eax
  66e20f:	0f 85 f1 f9 ff ff    	jne    66dc06 <<gpui_canvas::text::planner::Planner>::shape+0x2f76>
  66e215:	b8 03 00 00 00       	mov    $0x3,%eax
  66e21a:	e9 e7 f9 ff ff       	jmp    66dc06 <<gpui_canvas::text::planner::Planner>::shape+0x2f76>
  66e21f:	4c 8d 05 7a 20 11 00 	lea    0x11207a(%rip),%r8        # 7802a0 <anon.9a0de72a7eba2b0cb10eb2c5cf6d915d.1.llvm.15750432251718107962+0xb8>
  66e226:	48 8b bc 24 48 01 00 	mov    0x148(%rsp),%rdi
  66e22d:	00 
  66e22e:	48 8b 74 24 50       	mov    0x50(%rsp),%rsi
  66e233:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
  66e238:	ff 15 8a cf 11 00    	call   *0x11cf8a(%rip)        # 78b1c8 <_DYNAMIC+0x5e0>
  66e23e:	e9 d8 00 00 00       	jmp    66e31b <<gpui_canvas::text::planner::Planner>::shape+0x368b>
  66e243:	48 8d 05 f6 1f 11 00 	lea    0x111ff6(%rip),%rax        # 780240 <anon.9a0de72a7eba2b0cb10eb2c5cf6d915d.1.llvm.15750432251718107962+0x58>
  66e24a:	eb 1f                	jmp    66e26b <<gpui_canvas::text::planner::Planner>::shape+0x35db>
  66e24c:	49 39 d6             	cmp    %rdx,%r14
  66e24f:	49 0f 47 d6          	cmova  %r14,%rdx
  66e253:	48 8d 05 d6 21 11 00 	lea    0x1121d6(%rip),%rax        # 780430 <anon.9a0de72a7eba2b0cb10eb2c5cf6d915d.1.llvm.15750432251718107962+0x248>
  66e25a:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  66e25f:	48 89 d7             	mov    %rdx,%rdi
  66e262:	eb 0c                	jmp    66e270 <<gpui_canvas::text::planner::Planner>::shape+0x35e0>
  66e264:	48 8d 05 95 20 11 00 	lea    0x112095(%rip),%rax        # 780300 <anon.9a0de72a7eba2b0cb10eb2c5cf6d915d.1.llvm.15750432251718107962+0x118>
  66e26b:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  66e270:	48 8b b4 24 e8 01 00 	mov    0x1e8(%rsp),%rsi
  66e277:	00 
  66e278:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
  66e27d:	ff 15 c5 cc 11 00    	call   *0x11ccc5(%rip)        # 78af48 <_DYNAMIC+0x360>
  66e283:	e9 93 00 00 00       	jmp    66e31b <<gpui_canvas::text::planner::Planner>::shape+0x368b>
  66e288:	48 8d 0d 39 23 11 00 	lea    0x112339(%rip),%rcx        # 7805c8 <anon.bf1b5ed00d96edcfb74556a573b7af11.42.llvm.12998622219056141688>
  66e28f:	48 89 8c 24 70 02 00 	mov    %rcx,0x270(%rsp)
  66e296:	00 
  66e297:	eb 04                	jmp    66e29d <<gpui_canvas::text::planner::Planner>::shape+0x360d>
  66e299:	31 ff                	xor    %edi,%edi
  66e29b:	31 c0                	xor    %eax,%eax
  66e29d:	48 89 c6             	mov    %rax,%rsi
  66e2a0:	48 8b 94 24 70 02 00 	mov    0x270(%rsp),%rdx
  66e2a7:	00 
  66e2a8:	ff 15 9a cc 11 00    	call   *0x11cc9a(%rip)        # 78af48 <_DYNAMIC+0x360>
  66e2ae:	eb 6b                	jmp    66e31b <<gpui_canvas::text::planner::Planner>::shape+0x368b>
  66e2b0:	31 ff                	xor    %edi,%edi
  66e2b2:	48 c7 84 24 e8 01 00 	movq   $0x0,0x1e8(%rsp)
  66e2b9:	00 00 00 00 00 
  66e2be:	eb b0                	jmp    66e270 <<gpui_canvas::text::planner::Planner>::shape+0x35e0>
  66e2c0:	48 8d 15 51 2f 11 00 	lea    0x112f51(%rip),%rdx        # 781218 <anon.14afa313d7e478525b4e47a786e25a5c.74.llvm.5064344213933224292>
  66e2c7:	ff 15 7b cc 11 00    	call   *0x11cc7b(%rip)        # 78af48 <_DYNAMIC+0x360>
  66e2cd:	eb 4c                	jmp    66e31b <<gpui_canvas::text::planner::Planner>::shape+0x368b>
  66e2cf:	48 8d 05 42 21 11 00 	lea    0x112142(%rip),%rax        # 780418 <anon.9a0de72a7eba2b0cb10eb2c5cf6d915d.1.llvm.15750432251718107962+0x230>
  66e2d6:	eb 93                	jmp    66e26b <<gpui_canvas::text::planner::Planner>::shape+0x35db>
  66e2d8:	48 89 d7             	mov    %rdx,%rdi
  66e2db:	48 8d 05 66 21 11 00 	lea    0x112166(%rip),%rax        # 780448 <anon.9a0de72a7eba2b0cb10eb2c5cf6d915d.1.llvm.15750432251718107962+0x260>
  66e2e2:	eb 87                	jmp    66e26b <<gpui_canvas::text::planner::Planner>::shape+0x35db>
  66e2e4:	48 8d 05 fd 1f 11 00 	lea    0x111ffd(%rip),%rax        # 7802e8 <anon.9a0de72a7eba2b0cb10eb2c5cf6d915d.1.llvm.15750432251718107962+0x100>
  66e2eb:	e9 7b ff ff ff       	jmp    66e26b <<gpui_canvas::text::planner::Planner>::shape+0x35db>
  66e2f0:	48 8d 05 21 20 11 00 	lea    0x112021(%rip),%rax        # 780318 <anon.9a0de72a7eba2b0cb10eb2c5cf6d915d.1.llvm.15750432251718107962+0x130>
  66e2f7:	e9 6f ff ff ff       	jmp    66e26b <<gpui_canvas::text::planner::Planner>::shape+0x35db>
  66e2fc:	48 89 d7             	mov    %rdx,%rdi
  66e2ff:	48 8d 05 2a 20 11 00 	lea    0x11202a(%rip),%rax        # 780330 <anon.9a0de72a7eba2b0cb10eb2c5cf6d915d.1.llvm.15750432251718107962+0x148>
  66e306:	e9 60 ff ff ff       	jmp    66e26b <<gpui_canvas::text::planner::Planner>::shape+0x35db>
  66e30b:	48 8d 15 b6 22 11 00 	lea    0x1122b6(%rip),%rdx        # 7805c8 <anon.bf1b5ed00d96edcfb74556a573b7af11.42.llvm.12998622219056141688>
  66e312:	48 89 c6             	mov    %rax,%rsi
  66e315:	ff 15 2d cc 11 00    	call   *0x11cc2d(%rip)        # 78af48 <_DYNAMIC+0x360>
  66e31b:	0f 0b                	ud2
  66e31d:	49 89 c6             	mov    %rax,%r14
  66e320:	be 18 00 00 00       	mov    $0x18,%esi
  66e325:	ba 04 00 00 00       	mov    $0x4,%edx
  66e32a:	48 89 df             	mov    %rbx,%rdi
  66e32d:	ff 15 ed ca 11 00    	call   *0x11caed(%rip)        # 78ae20 <_DYNAMIC+0x238>
  66e333:	e9 9a 02 00 00       	jmp    66e5d2 <<gpui_canvas::text::planner::Planner>::shape+0x3942>
  66e338:	49 89 c6             	mov    %rax,%r14
  66e33b:	4c 89 ef             	mov    %r13,%rdi
  66e33e:	e8 dd be ff ff       	call   66a220 <core::ptr::drop_glue::<gpui_canvas::text::layout::TextGeometry>>
  66e343:	f0 49 ff 0c 24       	lock decq (%r12)
  66e348:	75 0e                	jne    66e358 <<gpui_canvas::text::planner::Planner>::shape+0x36c8>
  66e34a:	48 8d bc 24 c0 04 00 	lea    0x4c0(%rsp),%rdi
  66e351:	00 
  66e352:	ff 15 e0 ca 11 00    	call   *0x11cae0(%rip)        # 78ae38 <_DYNAMIC+0x250>
  66e358:	31 ed                	xor    %ebp,%ebp
  66e35a:	eb 0c                	jmp    66e368 <<gpui_canvas::text::planner::Planner>::shape+0x36d8>
  66e35c:	ff 15 de ca 11 00    	call   *0x11cade(%rip)        # 78ae40 <_DYNAMIC+0x258>
  66e362:	49 89 c6             	mov    %rax,%r14
  66e365:	40 b5 01             	mov    $0x1,%bpl
  66e368:	4d 85 ff             	test   %r15,%r15
  66e36b:	74 15                	je     66e382 <<gpui_canvas::text::planner::Planner>::shape+0x36f2>
  66e36d:	49 c1 e7 04          	shl    $0x4,%r15
  66e371:	ba 04 00 00 00       	mov    $0x4,%edx
  66e376:	48 89 df             	mov    %rbx,%rdi
  66e379:	4c 89 fe             	mov    %r15,%rsi
  66e37c:	ff 15 9e ca 11 00    	call   *0x11ca9e(%rip)        # 78ae20 <_DYNAMIC+0x238>
  66e382:	40 84 ed             	test   %bpl,%bpl
  66e385:	0f 84 89 02 00 00    	je     66e614 <<gpui_canvas::text::planner::Planner>::shape+0x3984>
  66e38b:	31 db                	xor    %ebx,%ebx
  66e38d:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  66e394:	00 ff 
  66e396:	0f 84 fb 01 00 00    	je     66e597 <<gpui_canvas::text::planner::Planner>::shape+0x3907>
  66e39c:	e9 3e 02 00 00       	jmp    66e5df <<gpui_canvas::text::planner::Planner>::shape+0x394f>
  66e3a1:	49 89 c6             	mov    %rax,%r14
  66e3a4:	4c 89 3b             	mov    %r15,(%rbx)
  66e3a7:	4c 89 f7             	mov    %r14,%rdi
  66e3aa:	e8 81 0a 11 00       	call   77ee30 <_Unwind_Resume@plt>
  66e3af:	e9 1b 02 00 00       	jmp    66e5cf <<gpui_canvas::text::planner::Planner>::shape+0x393f>
  66e3b4:	e9 16 02 00 00       	jmp    66e5cf <<gpui_canvas::text::planner::Planner>::shape+0x393f>
  66e3b9:	e9 11 02 00 00       	jmp    66e5cf <<gpui_canvas::text::planner::Planner>::shape+0x393f>
  66e3be:	e9 b7 01 00 00       	jmp    66e57a <<gpui_canvas::text::planner::Planner>::shape+0x38ea>
  66e3c3:	e9 07 02 00 00       	jmp    66e5cf <<gpui_canvas::text::planner::Planner>::shape+0x393f>
  66e3c8:	e9 02 02 00 00       	jmp    66e5cf <<gpui_canvas::text::planner::Planner>::shape+0x393f>
  66e3cd:	e9 fd 01 00 00       	jmp    66e5cf <<gpui_canvas::text::planner::Planner>::shape+0x393f>
  66e3d2:	e9 a3 01 00 00       	jmp    66e57a <<gpui_canvas::text::planner::Planner>::shape+0x38ea>
  66e3d7:	e9 f3 01 00 00       	jmp    66e5cf <<gpui_canvas::text::planner::Planner>::shape+0x393f>
  66e3dc:	49 89 c6             	mov    %rax,%r14
  66e3df:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  66e3e6:	00 
  66e3e7:	e8 14 84 01 00       	call   686800 <core::ptr::drop_glue::<parley::style::StyleProperty<()>>>
  66e3ec:	e9 e1 01 00 00       	jmp    66e5d2 <<gpui_canvas::text::planner::Planner>::shape+0x3942>
  66e3f1:	ff 15 49 ca 11 00    	call   *0x11ca49(%rip)        # 78ae40 <_DYNAMIC+0x258>
  66e3f7:	49 89 c6             	mov    %rax,%r14
  66e3fa:	48 8d bc 24 10 07 00 	lea    0x710(%rsp),%rdi
  66e401:	00 
  66e402:	e8 f9 83 01 00       	call   686800 <core::ptr::drop_glue::<parley::style::StyleProperty<()>>>
  66e407:	e9 c6 01 00 00       	jmp    66e5d2 <<gpui_canvas::text::planner::Planner>::shape+0x3942>
  66e40c:	ff 15 2e ca 11 00    	call   *0x11ca2e(%rip)        # 78ae40 <_DYNAMIC+0x258>
  66e412:	49 89 c6             	mov    %rax,%r14
  66e415:	49 c7 85 c8 08 00 00 	movq   $0x0,0x8c8(%r13)
  66e41c:	00 00 00 00 
  66e420:	49 c7 85 d0 08 00 00 	movq   $0x4,0x8d0(%r13)
  66e427:	04 00 00 00 
  66e42b:	0f 57 c0             	xorps  %xmm0,%xmm0
  66e42e:	41 0f 11 85 d8 08 00 	movups %xmm0,0x8d8(%r13)
  66e435:	00 
  66e436:	49 c7 85 e8 08 00 00 	movq   $0x4,0x8e8(%r13)
  66e43d:	04 00 00 00 
  66e441:	41 0f 11 85 f0 08 00 	movups %xmm0,0x8f0(%r13)
  66e448:	00 
  66e449:	49 c7 85 00 09 00 00 	movq   $0x8,0x900(%r13)
  66e450:	08 00 00 00 
  66e454:	41 0f 11 85 08 09 00 	movups %xmm0,0x908(%r13)
  66e45b:	00 
  66e45c:	49 c7 85 18 09 00 00 	movq   $0x8,0x918(%r13)
  66e463:	08 00 00 00 
  66e467:	41 0f 11 85 20 09 00 	movups %xmm0,0x920(%r13)
  66e46e:	00 
  66e46f:	49 c7 85 30 09 00 00 	movq   $0x4,0x930(%r13)
  66e476:	04 00 00 00 
  66e47a:	41 0f 11 85 38 09 00 	movups %xmm0,0x938(%r13)
  66e481:	00 
  66e482:	49 c7 85 48 09 00 00 	movq   $0x4,0x948(%r13)
  66e489:	04 00 00 00 
  66e48d:	41 0f 11 85 50 09 00 	movups %xmm0,0x950(%r13)
  66e494:	00 
  66e495:	49 c7 85 60 09 00 00 	movq   $0x4,0x960(%r13)
  66e49c:	04 00 00 00 
  66e4a0:	41 0f 11 85 68 09 00 	movups %xmm0,0x968(%r13)
  66e4a7:	00 
  66e4a8:	49 c7 85 78 09 00 00 	movq   $0x8,0x978(%r13)
  66e4af:	08 00 00 00 
  66e4b3:	41 0f 11 85 80 09 00 	movups %xmm0,0x980(%r13)
  66e4ba:	00 
  66e4bb:	49 c7 85 90 09 00 00 	movq   $0x2,0x990(%r13)
  66e4c2:	02 00 00 00 
  66e4c6:	41 0f 11 85 98 09 00 	movups %xmm0,0x998(%r13)
  66e4cd:	00 
  66e4ce:	49 c7 85 a8 09 00 00 	movq   $0x4,0x9a8(%r13)
  66e4d5:	04 00 00 00 
  66e4d9:	41 0f 11 85 b0 09 00 	movups %xmm0,0x9b0(%r13)
  66e4e0:	00 
  66e4e1:	49 c7 85 c0 09 00 00 	movq   $0x8,0x9c0(%r13)
  66e4e8:	08 00 00 00 
  66e4ec:	41 0f 11 85 c8 09 00 	movups %xmm0,0x9c8(%r13)
  66e4f3:	00 
  66e4f4:	49 c7 85 d8 09 00 00 	movq   $0x8,0x9d8(%r13)
  66e4fb:	08 00 00 00 
  66e4ff:	41 0f 11 85 e0 09 00 	movups %xmm0,0x9e0(%r13)
  66e506:	00 
  66e507:	49 c7 85 f0 09 00 00 	movq   $0x8,0x9f0(%r13)
  66e50e:	08 00 00 00 
  66e512:	41 0f 11 85 f8 09 00 	movups %xmm0,0x9f8(%r13)
  66e519:	00 
  66e51a:	49 c7 85 08 0a 00 00 	movq   $0x4,0xa08(%r13)
  66e521:	04 00 00 00 
  66e525:	41 0f 11 85 10 0a 00 	movups %xmm0,0xa10(%r13)
  66e52c:	00 
  66e52d:	41 c7 85 20 0a 00 00 	movl   $0x3f800000,0xa20(%r13)
  66e534:	00 00 80 3f 
  66e538:	41 0f 11 85 24 0a 00 	movups %xmm0,0xa24(%r13)
  66e53f:	00 
  66e540:	49 c7 85 32 0a 00 00 	movq   $0x0,0xa32(%r13)
  66e547:	00 00 00 00 
  66e54b:	66 41 c7 85 3a 0a 00 	movw   $0xff01,0xa3a(%r13)
  66e552:	00 01 ff 
  66e555:	41 c6 85 3c 0a 00 00 	movb   $0x0,0xa3c(%r13)
  66e55c:	00 
  66e55d:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
  66e564:	00 
  66e565:	e8 a6 a5 ff ff       	call   668b10 <core::ptr::drop_glue::<core::result::Result<gpui_canvas::text::TextLayout, gpui_canvas::Error>>>
  66e56a:	4c 89 f7             	mov    %r14,%rdi
  66e56d:	e8 be 08 11 00       	call   77ee30 <_Unwind_Resume@plt>
  66e572:	ff 15 c8 c8 11 00    	call   *0x11c8c8(%rip)        # 78ae40 <_DYNAMIC+0x258>
  66e578:	eb 55                	jmp    66e5cf <<gpui_canvas::text::planner::Planner>::shape+0x393f>
  66e57a:	49 89 c6             	mov    %rax,%r14
  66e57d:	48 8b b4 24 10 07 00 	mov    0x710(%rsp),%rsi
  66e584:	00 
  66e585:	b3 01                	mov    $0x1,%bl
  66e587:	48 85 f6             	test   %rsi,%rsi
  66e58a:	75 11                	jne    66e59d <<gpui_canvas::text::planner::Planner>::shape+0x390d>
  66e58c:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  66e593:	00 ff 
  66e595:	75 48                	jne    66e5df <<gpui_canvas::text::planner::Planner>::shape+0x394f>
  66e597:	84 db                	test   %bl,%bl
  66e599:	75 55                	jne    66e5f0 <<gpui_canvas::text::planner::Planner>::shape+0x3960>
  66e59b:	eb 77                	jmp    66e614 <<gpui_canvas::text::planner::Planner>::shape+0x3984>
  66e59d:	48 8b bc 24 18 07 00 	mov    0x718(%rsp),%rdi
  66e5a4:	00 
  66e5a5:	48 c1 e6 03          	shl    $0x3,%rsi
  66e5a9:	ba 08 00 00 00       	mov    $0x8,%edx
  66e5ae:	ff 15 6c c8 11 00    	call   *0x11c86c(%rip)        # 78ae20 <_DYNAMIC+0x238>
  66e5b4:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  66e5bb:	00 ff 
  66e5bd:	74 d8                	je     66e597 <<gpui_canvas::text::planner::Planner>::shape+0x3907>
  66e5bf:	eb 1e                	jmp    66e5df <<gpui_canvas::text::planner::Planner>::shape+0x394f>
  66e5c1:	eb 0c                	jmp    66e5cf <<gpui_canvas::text::planner::Planner>::shape+0x393f>
  66e5c3:	eb 0a                	jmp    66e5cf <<gpui_canvas::text::planner::Planner>::shape+0x393f>
  66e5c5:	eb 08                	jmp    66e5cf <<gpui_canvas::text::planner::Planner>::shape+0x393f>
  66e5c7:	eb 06                	jmp    66e5cf <<gpui_canvas::text::planner::Planner>::shape+0x393f>
  66e5c9:	eb 04                	jmp    66e5cf <<gpui_canvas::text::planner::Planner>::shape+0x393f>
  66e5cb:	eb 02                	jmp    66e5cf <<gpui_canvas::text::planner::Planner>::shape+0x393f>
  66e5cd:	eb 00                	jmp    66e5cf <<gpui_canvas::text::planner::Planner>::shape+0x393f>
  66e5cf:	49 89 c6             	mov    %rax,%r14
  66e5d2:	b3 01                	mov    $0x1,%bl
  66e5d4:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  66e5db:	00 ff 
  66e5dd:	74 b8                	je     66e597 <<gpui_canvas::text::planner::Planner>::shape+0x3907>
  66e5df:	48 8d bc 24 50 01 00 	lea    0x150(%rsp),%rdi
  66e5e6:	00 
  66e5e7:	e8 34 bc ff ff       	call   66a220 <core::ptr::drop_glue::<gpui_canvas::text::layout::TextGeometry>>
  66e5ec:	84 db                	test   %bl,%bl
  66e5ee:	74 24                	je     66e614 <<gpui_canvas::text::planner::Planner>::shape+0x3984>
  66e5f0:	48 8b b4 24 e8 00 00 	mov    0xe8(%rsp),%rsi
  66e5f7:	00 
  66e5f8:	48 85 f6             	test   %rsi,%rsi
  66e5fb:	74 17                	je     66e614 <<gpui_canvas::text::planner::Planner>::shape+0x3984>
  66e5fd:	48 8b bc 24 f0 00 00 	mov    0xf0(%rsp),%rdi
  66e604:	00 
  66e605:	48 c1 e6 04          	shl    $0x4,%rsi
  66e609:	ba 04 00 00 00       	mov    $0x4,%edx
  66e60e:	ff 15 0c c8 11 00    	call   *0x11c80c(%rip)        # 78ae20 <_DYNAMIC+0x238>
  66e614:	48 8d bc 24 a0 02 00 	lea    0x2a0(%rsp),%rdi
  66e61b:	00 
  66e61c:	e8 df a3 ff ff       	call   668a00 <core::ptr::drop_glue::<[parlance::font_family::FontFamilyName; 3]>>
  66e621:	4c 89 f7             	mov    %r14,%rdi
  66e624:	e8 07 08 11 00       	call   77ee30 <_Unwind_Resume@plt>
