
/tmp/gpui-a11y-owner-channel-captures/release-baseline/empty:     file format elf64-x86-64


Disassembly of section .text:

00000000009e46e0 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>>:
  9e46e0:	push   %rbp
  9e46e1:	push   %r15
  9e46e3:	push   %r14
  9e46e5:	push   %r13
  9e46e7:	push   %r12
  9e46e9:	push   %rbx
  9e46ea:	sub    $0x2b8,%rsp
  9e46f1:	mov    %rdx,%r15
  9e46f4:	mov    %rsi,%r14
  9e46f7:	mov    %rdi,%rbx
  9e46fa:	mov    0xa0(%rsi),%rax
  9e4701:	mov    0x40(%rax),%r12
  9e4705:	mov    %r12d,%edx
  9e4708:	and    $0x1,%edx
  9e470b:	lea    0x90(%rsp),%rdi
  9e4713:	mov    %r15,%rsi
  9e4716:	call   9bffe0 <<gpui::runtime::Win<empty::Empty>>::accessibility_observe>
  9e471b:	cmpl   $0xfffffffe,0x90(%rsp)
  9e4723:	jne    9e4770 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x90>
  9e4725:	test   $0x1,%r12b
  9e4729:	je     9e47a1 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xc1>
  9e472b:	mov    (%r15),%rax
  9e472e:	test   %rax,%rax
  9e4731:	je     9e47c4 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xe4>
  9e4737:	mov    $0xe,%ecx
  9e473c:	cmpb   $0x0,0x72e(%rax)
  9e4743:	jne    9e47c9 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xe9>
  9e4749:	mov    0x5e0(%rax),%rcx
  9e4750:	shr    $0x3e,%rcx
  9e4754:	mov    $0x1e,%ecx
  9e4759:	jne    9e47c9 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xe9>
  9e475b:	mov    0x670(%rax),%r13
  9e4762:	test   %r13,%r13
  9e4765:	je     9e47e1 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x101>
  9e4767:	mov    0x5b0(%rax),%rbp
  9e476e:	jmp    9e47e3 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x103>
  9e4770:	mov    0xc0(%rsp),%rax
  9e4778:	mov    %rax,0x30(%rbx)
  9e477c:	movups 0x90(%rsp),%xmm0
  9e4784:	movups 0xa0(%rsp),%xmm1
  9e478c:	movups 0xb0(%rsp),%xmm2
  9e4794:	movups %xmm2,0x20(%rbx)
  9e4798:	movups %xmm1,0x10(%rbx)
  9e479c:	movups %xmm0,(%rbx)
  9e479f:	jmp    9e47cc <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xec>
  9e47a1:	lea    0x28(%r14),%rdi
  9e47a5:	call   *0xb4868d(%rip)        # 152ce38 <_DYNAMIC+0xaf8>
  9e47ab:	movb   $0x2,0x80(%r14)
  9e47b3:	movb   $0x1,0xa8(%r14)
  9e47bb:	movq   $0xfffffffffffffffe,(%rbx)
  9e47c2:	jmp    9e47cc <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xec>
  9e47c4:	mov    $0xd,%ecx
  9e47c9:	mov    %rcx,(%rbx)
  9e47cc:	mov    %rbx,%rax
  9e47cf:	add    $0x2b8,%rsp
  9e47d6:	pop    %rbx
  9e47d7:	pop    %r12
  9e47d9:	pop    %r13
  9e47db:	pop    %r14
  9e47dd:	pop    %r15
  9e47df:	pop    %rbp
  9e47e0:	ret
  9e47e1:	xor    %ebp,%ebp
  9e47e3:	mov    0x668(%rax),%r12
  9e47ea:	movzbl 0x72c(%rax),%ecx
  9e47f1:	mov    0x5e8(%rax),%r8
  9e47f8:	mov    0x5f0(%rax),%r9
  9e47ff:	mov    0x680(%rax),%r10
  9e4806:	mov    %rbp,0x238(%rsp)
  9e480e:	mov    %r13,0x240(%rsp)
  9e4816:	mov    %r12,0x248(%rsp)
  9e481e:	mov    %r8,0x250(%rsp)
  9e4826:	mov    %r9,0x258(%rsp)
  9e482e:	mov    %r10,0x260(%rsp)
  9e4836:	mov    %cl,0x268(%rsp)
  9e483d:	test   %cl,%cl
  9e483f:	je     9e4b2a <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x44a>
  9e4845:	movabs $0x3fffffffffffffff,%r11
  9e484f:	mov    0xa0(%r14),%rax
  9e4856:	xor    %ecx,%ecx
  9e4858:	xchg   %cl,0x52(%rax)
  9e485b:	test   %cl,%cl
  9e485d:	je     9e4869 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x189>
  9e485f:	movb   $0x1,0xa8(%r14)
  9e4867:	jmp    9e4875 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x195>
  9e4869:	movzbl 0xa8(%r14),%eax
  9e4871:	cmp    $0x1,%al
  9e4873:	jne    9e48d2 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x1f2>
  9e4875:	movb   $0x1,0xf(%rsp)
  9e487a:	movq   $0x0,0x1a8(%rsp)
  9e4886:	mov    (%r15),%rsi
  9e4889:	test   %rsi,%rsi
  9e488c:	je     9e48a1 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x1c1>
  9e488e:	cmpb   $0x0,0x72e(%rsi)
  9e4895:	je     9e48ab <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x1cb>
  9e4897:	mov    $0xe,%eax
  9e489c:	jmp    9e49b9 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x2d9>
  9e48a1:	mov    $0xd,%eax
  9e48a6:	jmp    9e49b9 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x2d9>
  9e48ab:	mov    0x5b0(%rsi),%rcx
  9e48b2:	mov    0x48(%r14),%rax
  9e48b6:	test   %rax,%rax
  9e48b9:	je     9e4995 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x2b5>
  9e48bf:	cmp    %rcx,%rax
  9e48c2:	je     9e4995 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x2b5>
  9e48c8:	mov    $0x11,%eax
  9e48cd:	jmp    9e49b9 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x2d9>
  9e48d2:	cmpb   $0x2,0x80(%r14)
  9e48da:	jne    9e49e8 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x308>
  9e48e0:	movb   $0x1,0xf(%rsp)
  9e48e5:	lea    0x50(%r14),%rcx
  9e48e9:	mov    %rcx,0x90(%rsp)
  9e48f1:	mov    %r15,0x98(%rsp)
  9e48f9:	lea    0x238(%rsp),%rcx
  9e4901:	mov    %rcx,0xa0(%rsp)
  9e4909:	test   %al,%al
  9e490b:	jne    9e487a <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x19a>
  9e4911:	lea    0x90(%rsp),%rdi
  9e4919:	mov    %r8,0x150(%rsp)
  9e4921:	mov    %r9,0x148(%rsp)
  9e4929:	mov    %r10,0x140(%rsp)
  9e4931:	call   9e7e40 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>::{closure#2}>
  9e4936:	movabs $0x3fffffffffffffff,%r11
  9e4940:	mov    0x140(%rsp),%r10
  9e4948:	mov    0x148(%rsp),%r9
  9e4950:	mov    0x150(%rsp),%r8
  9e4958:	mov    %rax,0x1a8(%rsp)
  9e4960:	mov    %rdx,0x1b0(%rsp)
  9e4968:	test   %rax,%rax
  9e496b:	je     9e4886 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x1a6>
  9e4971:	mov    (%r15),%rsi
  9e4974:	test   %rsi,%rsi
  9e4977:	je     9e4c23 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x543>
  9e497d:	cmpb   $0x0,0x72e(%rsi)
  9e4984:	je     9e4c2e <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x54e>
  9e498a:	mov    $0xe,%r11d
  9e4990:	jmp    9e4ddc <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x6fc>
  9e4995:	mov    $0x12,%eax
  9e499a:	cmpb   $0x1,0x72c(%rsi)
  9e49a1:	jne    9e49b1 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x2d1>
  9e49a3:	mov    $0x1e,%eax
  9e49a8:	cmp    %r11,0x5e0(%rsi)
  9e49af:	jbe    9e4a25 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x345>
  9e49b1:	movzbl 0xa0(%rsp),%ecx
  9e49b9:	movups 0x29f(%rsp),%xmm0
  9e49c1:	movups %xmm0,0x28(%rbx)
  9e49c5:	movaps 0x280(%rsp),%xmm0
  9e49cd:	movaps 0x290(%rsp),%xmm1
  9e49d5:	movups %xmm1,0x19(%rbx)
  9e49d9:	movups %xmm0,0x9(%rbx)
  9e49dd:	mov    %rax,(%rbx)
  9e49e0:	mov    %cl,0x8(%rbx)
  9e49e3:	jmp    9e47cc <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xec>
  9e49e8:	mov    0x50(%r14),%rsi
  9e49ec:	mov    0x60(%r14),%rdx
  9e49f0:	mov    0x78(%r14),%rcx
  9e49f4:	mov    0x238(%rsp),%rdi
  9e49fc:	test   %rsi,%rsi
  9e49ff:	je     9e4ad0 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x3f0>
  9e4a05:	cmp    %rdi,%rsi
  9e4a08:	jne    9e48e0 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x200>
  9e4a0e:	mov    0x240(%rsp),%rsi
  9e4a16:	cmp    %rsi,0x58(%r14)
  9e4a1a:	je     9e4ad9 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x3f9>
  9e4a20:	jmp    9e48e0 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x200>
  9e4a25:	mov    %rcx,0x10(%rsp)
  9e4a2a:	mov    %r10,0x140(%rsp)
  9e4a32:	mov    %r9,0x148(%rsp)
  9e4a3a:	mov    %r8,0x150(%rsp)
  9e4a42:	lea    0x90(%rsp),%rdi
  9e4a4a:	call   9eb990 <<gpui::runtime::query::Context>::new::<empty::Empty>>
  9e4a4f:	mov    0x90(%rsp),%rdx
  9e4a57:	mov    0x98(%rsp),%rax
  9e4a5f:	movzbl 0xa0(%rsp),%ecx
  9e4a67:	movups 0xa1(%rsp),%xmm0
  9e4a6f:	movaps %xmm0,0x30(%rsp)
  9e4a74:	movups 0xb1(%rsp),%xmm0
  9e4a7c:	movaps %xmm0,0x40(%rsp)
  9e4a81:	movups 0xc0(%rsp),%xmm0
  9e4a89:	movups %xmm0,0x4f(%rsp)
  9e4a8e:	cmp    $0x2,%rdx
  9e4a92:	jne    9e4b36 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x456>
  9e4a98:	movaps 0x30(%rsp),%xmm0
  9e4a9d:	movaps 0x40(%rsp),%xmm1
  9e4aa2:	movaps %xmm0,0x280(%rsp)
  9e4aaa:	movaps %xmm1,0x290(%rsp)
  9e4ab2:	movups 0x4f(%rsp),%xmm0
  9e4ab7:	movups %xmm0,0x29f(%rsp)
  9e4abf:	cmp    $0xfffffffffffffffe,%rax
  9e4ac3:	jne    9e49b9 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x2d9>
  9e4ac9:	mov    $0x1,%al
  9e4acb:	jmp    9e4eef <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x80f>
  9e4ad0:	test   %rdi,%rdi
  9e4ad3:	jne    9e48e0 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x200>
  9e4ad9:	cmp    0x248(%rsp),%rdx
  9e4ae1:	jne    9e48e0 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x200>
  9e4ae7:	cmp    0x260(%rsp),%rcx
  9e4aef:	setne  0xf(%rsp)
  9e4af4:	jne    9e48e5 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x205>
  9e4afa:	mov    0x68(%r14),%rcx
  9e4afe:	mov    0x250(%rsp),%rax
  9e4b06:	test   %rcx,%rcx
  9e4b09:	je     9e4ec0 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x7e0>
  9e4b0f:	cmp    %rax,%rcx
  9e4b12:	jne    9e4ec9 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x7e9>
  9e4b18:	mov    0x258(%rsp),%rax
  9e4b20:	cmp    %rax,0x70(%r14)
  9e4b24:	jne    9e4ec9 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x7e9>
  9e4b2a:	movq   $0xfffffffffffffffe,(%rbx)
  9e4b31:	jmp    9e47cc <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xec>
  9e4b36:	mov    %rbp,0x128(%rsp)
  9e4b3e:	mov    %r13,0x130(%rsp)
  9e4b46:	movups 0xd0(%rsp),%xmm0
  9e4b4e:	movups 0xe0(%rsp),%xmm1
  9e4b56:	movups 0xf0(%rsp),%xmm2
  9e4b5e:	movups 0x100(%rsp),%xmm3
  9e4b66:	movups %xmm3,0x228(%rsp)
  9e4b6e:	movups %xmm2,0x218(%rsp)
  9e4b76:	movups %xmm1,0x208(%rsp)
  9e4b7e:	movups %xmm0,0x1f8(%rsp)
  9e4b86:	mov    %rax,0x1c0(%rsp)
  9e4b8e:	mov    %cl,0x1c8(%rsp)
  9e4b95:	movaps 0x30(%rsp),%xmm0
  9e4b9a:	movaps 0x40(%rsp),%xmm1
  9e4b9f:	movups %xmm0,0x1c9(%rsp)
  9e4ba7:	movups %xmm1,0x1d9(%rsp)
  9e4baf:	movups 0x4f(%rsp),%xmm0
  9e4bb4:	movups %xmm0,0x1e8(%rsp)
  9e4bbc:	mov    %rdx,0x1b8(%rsp)
  9e4bc4:	mov    0x1f0(%rsp),%rbp
  9e4bcc:	test   %rbp,%rbp
  9e4bcf:	mov    %r12,0x120(%rsp)
  9e4bd7:	je     9e4d0c <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x62c>
  9e4bdd:	xor    %r12d,%r12d
  9e4be0:	xor    %r13d,%r13d
  9e4be3:	lea    0x1b8(%rsp),%rdi
  9e4beb:	mov    %r12,%rsi
  9e4bee:	call   *0xb48234(%rip)        # 152ce28 <_DYNAMIC+0xae8>
  9e4bf4:	cmp    $0x1,%rax
  9e4bf8:	sbb    $0xffffffffffffffff,%r13
  9e4bfc:	inc    %r12
  9e4bff:	cmp    %r12,%rbp
  9e4c02:	jne    9e4be3 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x503>
  9e4c04:	imul   $0x38,%r13,%rsi
  9e4c08:	movabs $0x249249249249249,%rax
  9e4c12:	cmp    %rax,%r13
  9e4c15:	jbe    9e51a9 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xac9>
  9e4c1b:	xor    %edi,%edi
  9e4c1d:	call   *0xb47a4d(%rip)        # 152c670 <_DYNAMIC+0x330>
  9e4c23:	mov    $0xd,%r11d
  9e4c29:	jmp    9e4ddc <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x6fc>
  9e4c2e:	mov    0x48(%r14),%rcx
  9e4c32:	cmp    0x5b0(%rsi),%rcx
  9e4c39:	jne    9e4dd6 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x6f6>
  9e4c3f:	mov    %rdx,0x88(%rsp)
  9e4c47:	mov    %rax,0x138(%rsp)
  9e4c4f:	mov    %r12,0x120(%rsp)
  9e4c57:	lea    0x90(%rsp),%rdi
  9e4c5f:	mov    %r15,%rsi
  9e4c62:	call   9bc770 <<gpui::runtime::Win<empty::Empty>>::accessibility_sheet>
  9e4c67:	mov    0x90(%rsp),%rax
  9e4c6f:	mov    0x98(%rsp),%r11
  9e4c77:	mov    0xa0(%rsp),%rcx
  9e4c7f:	mov    %rcx,0x10(%rsp)
  9e4c84:	mov    0xa8(%rsp),%r9
  9e4c8c:	mov    0xb0(%rsp),%edi
  9e4c93:	movzbl 0xb4(%rsp),%r10d
  9e4c9c:	movzwl 0xb5(%rsp),%ecx
  9e4ca4:	mov    %cx,0x30(%rsp)
  9e4ca9:	movzbl 0xb7(%rsp),%ecx
  9e4cb1:	mov    %cl,0x32(%rsp)
  9e4cb5:	mov    0xb8(%rsp),%r12
  9e4cbd:	mov    0xc0(%rsp),%rcx
  9e4cc5:	mov    %rcx,0x80(%rsp)
  9e4ccd:	mov    0xc8(%rsp),%rcx
  9e4cd5:	mov    %rcx,0x28(%rsp)
  9e4cda:	cmp    $0x2,%rax
  9e4cde:	mov    %r13,0x130(%rsp)
  9e4ce6:	mov    %rbp,0x128(%rsp)
  9e4cee:	jne    9e4f4d <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x86d>
  9e4cf4:	movzwl 0x30(%rsp),%eax
  9e4cf9:	mov    %ax,0x18(%rsp)
  9e4cfe:	movzbl 0x32(%rsp),%eax
  9e4d03:	mov    %al,0x1a(%rsp)
  9e4d07:	jmp    9e534f <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xc6f>
  9e4d0c:	mov    $0x8,%eax
  9e4d11:	xor    %r13d,%r13d
  9e4d14:	xor    %ecx,%ecx
  9e4d16:	lea    0x28(%r14),%r12
  9e4d1a:	mov    %rcx,0x30(%rsp)
  9e4d1f:	mov    %rax,0x38(%rsp)
  9e4d24:	movq   $0x0,0x40(%rsp)
  9e4d2d:	cmp    0x38(%r14),%r13
  9e4d31:	mov    0x40(%r14),%rax
  9e4d35:	setne  0x22(%rsp)
  9e4d3a:	mov    %rax,0x18(%rsp)
  9e4d3f:	movb   $0x0,0x24(%rsp)
  9e4d44:	mov    %r15,0x90(%rsp)
  9e4d4c:	mov    %r12,0x98(%rsp)
  9e4d54:	lea    0x22(%rsp),%rax
  9e4d59:	mov    %rax,0xa0(%rsp)
  9e4d61:	lea    0x18(%rsp),%rax
  9e4d66:	mov    %rax,0xa8(%rsp)
  9e4d6e:	lea    0x24(%rsp),%rax
  9e4d73:	mov    %rax,0xb0(%rsp)
  9e4d7b:	lea    0x30(%rsp),%rax
  9e4d80:	mov    %rax,0xb8(%rsp)
  9e4d88:	lea    0x1b8(%rsp),%rdi
  9e4d90:	lea    0x90(%rsp),%rsi
  9e4d98:	call   9ec170 <<gpui::runtime::query::SemanticSheet>::visit::<<gpui::native::accessibility::text::Cohort>::refresh<empty::Empty, ()>::{closure#2}>>
  9e4d9d:	cmpb   $0x0,0x24(%rsp)
  9e4da2:	je     9e4e19 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x739>
  9e4da4:	lea    0x30(%rsp),%rdi
  9e4da9:	call   a33020 <<alloc::vec::Vec<gpui::native::accessibility::text::Input> as core::ops::drop::Drop>::drop>
  9e4dae:	mov    0x30(%rsp),%rax
  9e4db3:	test   %rax,%rax
  9e4db6:	je     9e4dcc <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x6ec>
  9e4db8:	mov    0x38(%rsp),%rdi
  9e4dbd:	imul   $0x38,%rax,%rsi
  9e4dc1:	mov    $0x8,%edx
  9e4dc6:	call   *0xb477c4(%rip)        # 152c590 <_DYNAMIC+0x250>
  9e4dcc:	mov    $0x1e,%eax
  9e4dd1:	jmp    9e49b9 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x2d9>
  9e4dd6:	mov    $0x11,%r11d
  9e4ddc:	movzbl 0x1a(%rsp),%eax
  9e4de1:	mov    %al,0x26(%rsp)
  9e4de5:	movzwl 0x18(%rsp),%ecx
  9e4dea:	mov    %cx,0x24(%rsp)
  9e4def:	mov    %al,0x1f(%rbx)
  9e4df2:	mov    %cx,0x1d(%rbx)
  9e4df6:	mov    %r11,(%rbx)
  9e4df9:	mov    %r8,0x8(%rbx)
  9e4dfd:	mov    %r9,0x10(%rbx)
  9e4e01:	mov    %edi,0x18(%rbx)
  9e4e04:	mov    %r10b,0x1c(%rbx)
  9e4e08:	mov    %r12,0x20(%rbx)
  9e4e0c:	mov    %rsi,0x28(%rbx)
  9e4e10:	mov    %rdx,0x30(%rbx)
  9e4e14:	jmp    9e47cc <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xec>
  9e4e19:	mov    0x38(%rsp),%rdi
  9e4e1e:	mov    0x40(%rsp),%rsi
  9e4e23:	lea    0x23(%rsp),%rax
  9e4e28:	mov    %rax,0x90(%rsp)
  9e4e30:	cmp    $0x2,%rsi
  9e4e34:	jae    9e5a8e <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x13ae>
  9e4e3a:	mov    0x40(%rsp),%rax
  9e4e3f:	mov    %rax,0xa0(%rsp)
  9e4e47:	movups 0x30(%rsp),%xmm0
  9e4e4c:	movaps %xmm0,0x90(%rsp)
  9e4e54:	mov    %r12,%rdi
  9e4e57:	call   a33020 <<alloc::vec::Vec<gpui::native::accessibility::text::Input> as core::ops::drop::Drop>::drop>
  9e4e5c:	mov    (%r12),%rax
  9e4e60:	test   %rax,%rax
  9e4e63:	je     9e4e78 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x798>
  9e4e65:	mov    0x30(%r14),%rdi
  9e4e69:	imul   $0x38,%rax,%rsi
  9e4e6d:	mov    $0x8,%edx
  9e4e72:	call   *0xb47718(%rip)        # 152c590 <_DYNAMIC+0x250>
  9e4e78:	mov    0xa0(%rsp),%rax
  9e4e80:	mov    %rax,0x10(%r12)
  9e4e85:	movaps 0x90(%rsp),%xmm0
  9e4e8d:	movups %xmm0,(%r12)
  9e4e92:	mov    0x18(%rsp),%rax
  9e4e97:	mov    %rax,0x40(%r14)
  9e4e9b:	mov    0x10(%rsp),%rax
  9e4ea0:	mov    %rax,0x48(%r14)
  9e4ea4:	mov    0x130(%rsp),%r13
  9e4eac:	mov    0x128(%rsp),%rbp
  9e4eb4:	mov    0x120(%rsp),%r12
  9e4ebc:	mov    $0x1,%al
  9e4ebe:	jmp    9e4eef <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x80f>
  9e4ec0:	test   %rax,%rax
  9e4ec3:	je     9e4b2a <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x44a>
  9e4ec9:	mov    %r10,0x140(%rsp)
  9e4ed1:	mov    %r9,0x148(%rsp)
  9e4ed9:	mov    %r8,0x150(%rsp)
  9e4ee1:	movq   $0x0,0x1a8(%rsp)
  9e4eed:	xor    %eax,%eax
  9e4eef:	movq   $0x0,0x158(%rsp)
  9e4efb:	movq   $0x4,0x160(%rsp)
  9e4f07:	movq   $0x0,0x168(%rsp)
  9e4f13:	movw   $0x100,0x180(%rsp)
  9e4f1d:	xorps  %xmm0,%xmm0
  9e4f20:	movups %xmm0,0x170(%rsp)
  9e4f28:	movq   $0x0,0x10(%rsp)
  9e4f31:	test   %al,%al
  9e4f33:	je     9e5418 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xd38>
  9e4f39:	lea    0x28(%r14),%rdi
  9e4f3d:	call   *0xb47efd(%rip)        # 152ce40 <_DYNAMIC+0xb00>
  9e4f43:	mov    %rax,0x28(%rsp)
  9e4f48:	jmp    9e5428 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xd48>
  9e4f4d:	movups 0xd0(%rsp),%xmm0
  9e4f55:	movups 0xe0(%rsp),%xmm1
  9e4f5d:	movups 0xf0(%rsp),%xmm2
  9e4f65:	movups 0x100(%rsp),%xmm3
  9e4f6d:	movups %xmm3,0x228(%rsp)
  9e4f75:	movups %xmm2,0x218(%rsp)
  9e4f7d:	movups %xmm1,0x208(%rsp)
  9e4f85:	movups %xmm0,0x1f8(%rsp)
  9e4f8d:	mov    %r11,0x1c0(%rsp)
  9e4f95:	mov    0x10(%rsp),%rcx
  9e4f9a:	mov    %rcx,0x1c8(%rsp)
  9e4fa2:	mov    %r9,0x1d0(%rsp)
  9e4faa:	mov    %edi,0x1d8(%rsp)
  9e4fb1:	mov    %r10b,0x1dc(%rsp)
  9e4fb9:	movzwl 0x30(%rsp),%ecx
  9e4fbe:	mov    %cx,0x1dd(%rsp)
  9e4fc6:	movzbl 0x32(%rsp),%ecx
  9e4fcb:	mov    %cl,0x1df(%rsp)
  9e4fd2:	mov    %r12,0x1e0(%rsp)
  9e4fda:	mov    %rax,0x1b8(%rsp)
  9e4fe2:	mov    0x80(%rsp),%rax
  9e4fea:	mov    %rax,0x1e8(%rsp)
  9e4ff2:	mov    0x28(%rsp),%rax
  9e4ff7:	mov    %rax,0x1f0(%rsp)
  9e4fff:	mov    0x40(%r14),%r12
  9e5003:	movq   $0x0,0x30(%rsp)
  9e500c:	movq   $0x4,0x38(%rsp)
  9e5015:	movq   $0x0,0x40(%rsp)
  9e501e:	movw   $0x100,0x58(%rsp)
  9e5025:	mov    %r12,0x48(%rsp)
  9e502a:	mov    %r12,0x50(%rsp)
  9e502f:	cmpq   $0x0,0x88(%rsp)
  9e5038:	je     9e51de <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xafe>
  9e503e:	mov    0x88(%rsp),%rcx
  9e5046:	shl    $0x2,%rcx
  9e504a:	mov    0x30(%r14),%rax
  9e504e:	mov    %rax,0x10(%rsp)
  9e5053:	mov    0x38(%r14),%rax
  9e5057:	mov    %rax,0x70(%rsp)
  9e505c:	xor    %r13d,%r13d
  9e505f:	mov    %r12,0x78(%rsp)
  9e5064:	mov    %r12,0x118(%rsp)
  9e506c:	mov    0x138(%rsp),%rax
  9e5074:	mov    %rcx,0x88(%rsp)
  9e507c:	jmp    9e50d9 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x9f9>
  9e507e:	xor    %edx,%edx
  9e5080:	mov    0x118(%rsp),%rcx
  9e5088:	add    %rcx,%rax
  9e508b:	lea    (%rdx,%rax,1),%r12
  9e508f:	inc    %r12
  9e5092:	cmp    %rcx,%r12
  9e5095:	jb     9e5a84 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x13a4>
  9e509b:	movq   $0x1e,0x90(%rsp)
  9e50a7:	lea    0x90(%rsp),%rdi
  9e50af:	call   9e7940 <core::ptr::drop_glue::<gpui::runtime::Error>>
  9e50b4:	mov    %r12,0x118(%rsp)
  9e50bc:	mov    0x138(%rsp),%rax
  9e50c4:	mov    0x88(%rsp),%rcx
  9e50cc:	add    $0x4,%r13
  9e50d0:	cmp    %r13,%rcx
  9e50d3:	je     9e52ca <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xbea>
  9e50d9:	mov    (%rax,%r13,1),%r12d
  9e50dd:	cmp    %r12,0x28(%rsp)
  9e50e2:	jbe    9e520e <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xb2e>
  9e50e8:	movq   $0x11,0x90(%rsp)
  9e50f4:	lea    0x90(%rsp),%rbp
  9e50fc:	mov    %rbp,%rdi
  9e50ff:	call   9e7940 <core::ptr::drop_glue::<gpui::runtime::Error>>
  9e5104:	mov    %rbp,%rdi
  9e5107:	mov    0x10(%rsp),%rsi
  9e510c:	mov    0x70(%rsp),%rdx
  9e5111:	mov    %r15,%rcx
  9e5114:	lea    0x1b8(%rsp),%r8
  9e511c:	mov    %r12,%r9
  9e511f:	call   9e3eb0 <<gpui::native::accessibility::text::Cohort>::replacement::<empty::Empty, ()>>
  9e5124:	mov    0x90(%rsp),%rax
  9e512c:	cmp    $0xfffffffffffffffe,%rax
  9e5130:	jne    9e5233 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xb53>
  9e5136:	movzbl 0xac(%rsp),%edx
  9e513e:	cmp    $0x2,%dl
  9e5141:	je     9e50bc <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x9dc>
  9e5147:	shl    $0x6,%r12
  9e514b:	mov    0x80(%rsp),%rax
  9e5153:	lea    (%rax,%r12,1),%rcx
  9e5157:	mov    $0x1,%sil
  9e515a:	cmpb   $0x4,0x3d(%rax,%r12,1)
  9e5160:	jne    9e516b <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xa8b>
  9e5162:	cmpq   $0x0,0x28(%rcx)
  9e5167:	sete   %sil
  9e516b:	mov    0xa8(%rsp),%eax
  9e5172:	cmpq   $0x0,0xa0(%rsp)
  9e517b:	setne  %dil
  9e517f:	or     %sil,%dil
  9e5182:	and    %dil,0x59(%rsp)
  9e5187:	cmp    $0x1,%dl
  9e518a:	jne    9e507e <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x99e>
  9e5190:	cmpb   $0x4,0x3d(%rcx)
  9e5194:	jne    9e507e <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x99e>
  9e519a:	xor    %edx,%edx
  9e519c:	cmpq   $0x0,0x28(%rcx)
  9e51a1:	setne  %dl
  9e51a4:	jmp    9e5080 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x9a0>
  9e51a9:	test   %rsi,%rsi
  9e51ac:	je     9e5204 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xb24>
  9e51ae:	mov    %rsi,%r12
  9e51b1:	call   *0xb473c9(%rip)        # 152c580 <_DYNAMIC+0x240>
  9e51b7:	mov    $0x8,%esi
  9e51bc:	mov    %r12,%rdi
  9e51bf:	call   *0xb473c3(%rip)        # 152c588 <_DYNAMIC+0x248>
  9e51c5:	mov    $0x8,%edi
  9e51ca:	mov    %r12,%rsi
  9e51cd:	test   %rax,%rax
  9e51d0:	je     9e4c1d <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x53d>
  9e51d6:	mov    %r13,%rcx
  9e51d9:	jmp    9e4d16 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x636>
  9e51de:	xor    %ebp,%ebp
  9e51e0:	mov    $0x4,%eax
  9e51e5:	mov    %rax,0x78(%rsp)
  9e51ea:	mov    %r12,%rcx
  9e51ed:	movq   $0x0,0x70(%rsp)
  9e51f6:	movq   $0x0,0x10(%rsp)
  9e51ff:	jmp    9e5309 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xc29>
  9e5204:	mov    $0x8,%eax
  9e5209:	jmp    9e4d14 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x634>
  9e520e:	mov    $0x11,%eax
  9e5213:	mov    %rax,0x110(%rsp)
  9e521b:	mov    %rax,0x70(%rsp)
  9e5220:	mov    0x30(%rsp),%rsi
  9e5225:	test   %rsi,%rsi
  9e5228:	jne    9e52b4 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xbd4>
  9e522e:	jmp    9e533a <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xc5a>
  9e5233:	mov    %rax,0x110(%rsp)
  9e523b:	mov    0x98(%rsp),%rax
  9e5243:	mov    %rax,0x10(%rsp)
  9e5248:	mov    0xa0(%rsp),%rax
  9e5250:	mov    %rax,0x78(%rsp)
  9e5255:	mov    0xa8(%rsp),%eax
  9e525c:	mov    %rax,0x70(%rsp)
  9e5261:	movzbl 0xac(%rsp),%ebp
  9e5269:	lea    0xad(%rsp),%rcx
  9e5271:	movzwl (%rcx),%eax
  9e5274:	mov    %ax,0x18(%rsp)
  9e5279:	movzbl 0x2(%rcx),%eax
  9e527d:	mov    %al,0x1a(%rsp)
  9e5281:	mov    0xb0(%rsp),%r12
  9e5289:	mov    0xb8(%rsp),%rax
  9e5291:	mov    %rax,0x80(%rsp)
  9e5299:	mov    0xc0(%rsp),%rax
  9e52a1:	mov    %rax,0x28(%rsp)
  9e52a6:	mov    0x30(%rsp),%rsi
  9e52ab:	test   %rsi,%rsi
  9e52ae:	je     9e533a <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xc5a>
  9e52b4:	mov    0x38(%rsp),%rdi
  9e52b9:	shl    $0x2,%rsi
  9e52bd:	mov    $0x4,%edx
  9e52c2:	call   *0xb472c8(%rip)        # 152c590 <_DYNAMIC+0x250>
  9e52c8:	jmp    9e533a <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xc5a>
  9e52ca:	mov    0x78(%rsp),%rax
  9e52cf:	cmp    %rax,0x118(%rsp)
  9e52d7:	jne    9e56d5 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xff5>
  9e52dd:	mov    0x30(%rsp),%rax
  9e52e2:	mov    %rax,0x10(%rsp)
  9e52e7:	mov    0x38(%rsp),%rax
  9e52ec:	mov    %rax,0x78(%rsp)
  9e52f1:	mov    0x40(%rsp),%eax
  9e52f5:	mov    %rax,0x70(%rsp)
  9e52fa:	movzbl 0x44(%rsp),%ebp
  9e52ff:	mov    0x48(%rsp),%r12
  9e5304:	mov    0x50(%rsp),%rcx
  9e5309:	movzbl 0x47(%rsp),%eax
  9e530e:	mov    %al,0x1a(%rsp)
  9e5312:	movzwl 0x45(%rsp),%eax
  9e5317:	mov    %ax,0x18(%rsp)
  9e531c:	movq   $0xfffffffffffffffe,0x110(%rsp)
  9e5328:	mov    0x58(%rsp),%rax
  9e532d:	mov    %rax,0x28(%rsp)
  9e5332:	mov    %rcx,0x80(%rsp)
  9e533a:	mov    0x70(%rsp),%rdi
  9e533f:	mov    0x78(%rsp),%r9
  9e5344:	mov    %rbp,%r10
  9e5347:	mov    0x110(%rsp),%r11
  9e534f:	cmp    $0xfffffffffffffffe,%r11
  9e5353:	mov    0x28(%rsp),%rdx
  9e5358:	mov    0x80(%rsp),%rsi
  9e5360:	mov    0x10(%rsp),%r8
  9e5365:	jne    9e4ddc <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x6fc>
  9e536b:	movzbl 0x1a(%rsp),%eax
  9e5370:	movzwl 0x18(%rsp),%ecx
  9e5375:	mov    %cx,0x16d(%rsp)
  9e537d:	mov    %al,0x16f(%rsp)
  9e5384:	mov    %r8,0x10(%rsp)
  9e5389:	mov    %r8,0x158(%rsp)
  9e5391:	mov    %r9,0x160(%rsp)
  9e5399:	mov    %edi,0x168(%rsp)
  9e53a0:	mov    %r10b,0x16c(%rsp)
  9e53a8:	mov    %r12,0x170(%rsp)
  9e53b0:	mov    %rsi,0x178(%rsp)
  9e53b8:	mov    %rdx,0x180(%rsp)
  9e53c0:	cmpq   $0x0,0x1a8(%rsp)
  9e53c9:	je     9e53f3 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xd13>
  9e53cb:	mov    %rdx,%rax
  9e53ce:	shr    $0x8,%eax
  9e53d1:	and    $0x1,%eax
  9e53d4:	mov    %rax,0x28(%rsp)
  9e53d9:	mov    0x130(%rsp),%r13
  9e53e1:	mov    0x128(%rsp),%rbp
  9e53e9:	mov    0x120(%rsp),%r12
  9e53f1:	jmp    9e5428 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xd48>
  9e53f3:	movzbl 0xf(%rsp),%eax
  9e53f8:	mov    0x130(%rsp),%r13
  9e5400:	mov    0x128(%rsp),%rbp
  9e5408:	mov    0x120(%rsp),%r12
  9e5410:	test   %al,%al
  9e5412:	jne    9e4f39 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x859>
  9e5418:	cmpb   $0x0,0xa8(%r14)
  9e5420:	sete   %al
  9e5423:	mov    %rax,0x28(%rsp)
  9e5428:	mov    (%r15),%rsi
  9e542b:	test   %rsi,%rsi
  9e542e:	je     9e565b <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xf7b>
  9e5434:	mov    $0xe,%eax
  9e5439:	cmpb   $0x0,0x72e(%rsi)
  9e5440:	jne    9e5660 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xf80>
  9e5446:	mov    $0x12,%eax
  9e544b:	cmpb   $0x1,0x72c(%rsi)
  9e5452:	jne    9e5660 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xf80>
  9e5458:	mov    $0x1e,%eax
  9e545d:	movabs $0x3fffffffffffffff,%rcx
  9e5467:	cmp    %rcx,0x5e0(%rsi)
  9e546e:	ja     9e5660 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xf80>
  9e5474:	lea    0x90(%rsp),%rdi
  9e547c:	call   9eb990 <<gpui::runtime::query::Context>::new::<empty::Empty>>
  9e5481:	mov    0x90(%rsp),%rax
  9e5489:	cmp    $0x2,%rax
  9e548d:	je     9e5668 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xf88>
  9e5493:	mov    0xc8(%rsp),%rcx
  9e549b:	mov    %rcx,0x60(%rsp)
  9e54a0:	movups 0x98(%rsp),%xmm0
  9e54a8:	movups 0xa8(%rsp),%xmm1
  9e54b0:	movups 0xb8(%rsp),%xmm2
  9e54b8:	movaps %xmm2,0x50(%rsp)
  9e54bd:	movaps %xmm1,0x40(%rsp)
  9e54c2:	movaps %xmm0,0x30(%rsp)
  9e54c7:	movups 0xd0(%rsp),%xmm3
  9e54cf:	movups %xmm3,0x1f8(%rsp)
  9e54d7:	movups 0xe0(%rsp),%xmm3
  9e54df:	movups %xmm3,0x208(%rsp)
  9e54e7:	movups 0xf0(%rsp),%xmm3
  9e54ef:	movups %xmm3,0x218(%rsp)
  9e54f7:	movups 0x100(%rsp),%xmm3
  9e54ff:	movups %xmm3,0x228(%rsp)
  9e5507:	mov    %rcx,0x1f0(%rsp)
  9e550f:	movups %xmm2,0x1e0(%rsp)
  9e5517:	movups %xmm1,0x1d0(%rsp)
  9e551f:	movups %xmm0,0x1c0(%rsp)
  9e5527:	mov    %rax,0x1b8(%rsp)
  9e552f:	movb   $0x0,0x30(%rsp)
  9e5534:	lea    0x180(%rsp),%rax
  9e553c:	lea    0x170(%rsp),%rcx
  9e5544:	lea    0x10(%r14),%rdx
  9e5548:	lea    0x28(%r14),%rsi
  9e554c:	lea    0x1a8(%rsp),%rdi
  9e5554:	mov    %rdi,0x90(%rsp)
  9e555c:	lea    0x158(%rsp),%rdi
  9e5564:	mov    %rdi,0x98(%rsp)
  9e556c:	mov    %rax,0xa0(%rsp)
  9e5574:	mov    %rcx,0xa8(%rsp)
  9e557c:	lea    0x1b8(%rsp),%rax
  9e5584:	mov    %rax,0xb0(%rsp)
  9e558c:	mov    %rdx,0xb8(%rsp)
  9e5594:	mov    %rsi,0xc0(%rsp)
  9e559c:	lea    0xf(%rsp),%rax
  9e55a1:	mov    %rax,0xc8(%rsp)
  9e55a9:	lea    0x238(%rsp),%rax
  9e55b1:	mov    %rax,0xd0(%rsp)
  9e55b9:	lea    0x30(%rsp),%rax
  9e55be:	mov    %rax,0xd8(%rsp)
  9e55c6:	lea    0x88(%r14),%rdi
  9e55cd:	lea    0x90(%rsp),%rsi
  9e55d5:	call   9ffd50 <<accesskit_unix::adapter::Adapter>::update_if_active::<<gpui::native::accessibility::Bridge>::sync<empty::Empty, ()>::{closure#3}>>
  9e55da:	cmpb   $0x0,0x30(%rsp)
  9e55df:	je     9e564a <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xf6a>
  9e55e1:	mov    0xa0(%r14),%rcx
  9e55e8:	mov    0x48(%rcx),%rax
  9e55ec:	cmp    $0xffffffffffffffff,%rax
  9e55f0:	je     9e59a5 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x12c5>
  9e55f6:	lea    0x1(%rax),%rdx
  9e55fa:	lock cmpxchg %rdx,0x48(%rcx)
  9e5600:	jne    9e55ec <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xf0c>
  9e5602:	mov    %rbp,0x50(%r14)
  9e5606:	mov    %r13,0x58(%r14)
  9e560a:	mov    %r12,0x60(%r14)
  9e560e:	mov    0x150(%rsp),%rax
  9e5616:	mov    %rax,0x68(%r14)
  9e561a:	mov    0x148(%rsp),%rax
  9e5622:	mov    %rax,0x70(%r14)
  9e5626:	mov    0x140(%rsp),%rax
  9e562e:	mov    %rax,0x78(%r14)
  9e5632:	movb   $0x1,0x80(%r14)
  9e563a:	mov    0x28(%rsp),%rax
  9e563f:	xor    $0x1,%al
  9e5641:	add    %al,%al
  9e5643:	mov    %al,0xa8(%r14)
  9e564a:	movq   $0xfffffffffffffffe,(%rbx)
  9e5651:	mov    0x158(%rsp),%rsi
  9e5659:	jmp    9e56b0 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xfd0>
  9e565b:	mov    $0xd,%eax
  9e5660:	mov    %rax,0x98(%rsp)
  9e5668:	mov    0xc8(%rsp),%rax
  9e5670:	mov    %rax,0x60(%rsp)
  9e5675:	movups 0x98(%rsp),%xmm0
  9e567d:	movups 0xa8(%rsp),%xmm1
  9e5685:	movups 0xb8(%rsp),%xmm2
  9e568d:	movaps %xmm2,0x50(%rsp)
  9e5692:	movaps %xmm1,0x40(%rsp)
  9e5697:	movaps %xmm0,0x30(%rsp)
  9e569c:	mov    %rax,0x30(%rbx)
  9e56a0:	movups %xmm2,0x20(%rbx)
  9e56a4:	movups %xmm1,0x10(%rbx)
  9e56a8:	movups %xmm0,(%rbx)
  9e56ab:	mov    0x10(%rsp),%rsi
  9e56b0:	test   %rsi,%rsi
  9e56b3:	je     9e47cc <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xec>
  9e56b9:	mov    0x160(%rsp),%rdi
  9e56c1:	shl    $0x2,%rsi
  9e56c5:	mov    $0x4,%edx
  9e56ca:	call   *0xb46ec0(%rip)        # 152c590 <_DYNAMIC+0x250>
  9e56d0:	jmp    9e47cc <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xec>
  9e56d5:	xor    %ecx,%ecx
  9e56d7:	lea    0xad49e2(%rip),%rax        # 14ba0c0 <anon.22b410f5f50bcdcdab7a6d64ae00c059.1.llvm.14574195959755080497+0x48>
  9e56de:	mov    %rax,0x198(%rsp)
  9e56e6:	movabs $0x8000000000000000,%rax
  9e56f0:	inc    %rax
  9e56f3:	mov    %rax,0x270(%rsp)
  9e56fb:	lea    0xad4a1e(%rip),%rax        # 14ba120 <anon.22b410f5f50bcdcdab7a6d64ae00c059.1.llvm.14574195959755080497+0xa8>
  9e5702:	mov    %rax,0x190(%rsp)
  9e570a:	lea    -0x8529f1(%rip),%rax        # 192d20 <anon.5e2c2cd338f183f0185d3116c074ef00.75.llvm.4553572696083558104+0x3448>
  9e5711:	mov    %rax,0x188(%rsp)
  9e5719:	jmp    9e5742 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x1062>
  9e571b:	mov    %r12,0x0(%r13)
  9e571f:	mov    0x70(%rsp),%rax
  9e5724:	mov    %eax,0x30(%r13)
  9e5728:	mov    0x278(%rsp),%rcx
  9e5730:	add    $0x4,%rcx
  9e5734:	cmp    %rcx,0x88(%rsp)
  9e573c:	je     9e5a23 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x1343>
  9e5742:	mov    0x138(%rsp),%rax
  9e574a:	mov    %rcx,0x278(%rsp)
  9e5752:	mov    (%rax,%rcx,1),%r9d
  9e5756:	cmp    %r9,0x28(%rsp)
  9e575b:	jbe    9e5ac5 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x13e5>
  9e5761:	mov    0x30(%r14),%rsi
  9e5765:	mov    0x38(%r14),%r12
  9e5769:	lea    0x90(%rsp),%rdi
  9e5771:	mov    %rsi,%r13
  9e5774:	mov    %r12,%rdx
  9e5777:	mov    %r15,%rcx
  9e577a:	lea    0x1b8(%rsp),%r8
  9e5782:	mov    %r9,0x1a0(%rsp)
  9e578a:	call   9e3eb0 <<gpui::native::accessibility::text::Cohort>::replacement::<empty::Empty, ()>>
  9e578f:	mov    0x90(%rsp),%rsi
  9e5797:	mov    0x98(%rsp),%rax
  9e579f:	mov    %rax,0x10(%rsp)
  9e57a4:	mov    0xa0(%rsp),%rax
  9e57ac:	mov    %rax,0x78(%rsp)
  9e57b1:	mov    0xa8(%rsp),%eax
  9e57b8:	mov    %rax,0x70(%rsp)
  9e57bd:	movzbl 0xac(%rsp),%edx
  9e57c5:	lea    0xad(%rsp),%rcx
  9e57cd:	movzwl (%rcx),%eax
  9e57d0:	mov    %ax,0x280(%rsp)
  9e57d8:	movzbl 0x2(%rcx),%eax
  9e57dc:	mov    %al,0x282(%rsp)
  9e57e3:	mov    %rsi,0x110(%rsp)
  9e57eb:	cmp    $0xfffffffffffffffe,%rsi
  9e57ef:	jne    9e59cf <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x12ef>
  9e57f5:	cmp    $0x2,%dl
  9e57f8:	je     9e5728 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x1048>
  9e57fe:	cmp    %r12,0x10(%rsp)
  9e5803:	jae    9e5b6f <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x148f>
  9e5809:	mov    %rdx,%rcx
  9e580c:	imul   $0x38,0x10(%rsp),%rax
  9e5812:	mov    %r13,%rdx
  9e5815:	add    %rax,%rdx
  9e5818:	test   $0x1,%cl
  9e581b:	je     9e592d <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x124d>
  9e5821:	mov    0x78(%rsp),%rax
  9e5826:	mov    %rdx,%r13
  9e5829:	mov    %rax,0x10(%rdx)
  9e582d:	mov    0x1a0(%rsp),%rax
  9e5835:	shl    $0x6,%rax
  9e5839:	mov    0x80(%rsp),%rcx
  9e5841:	lea    (%rcx,%rax,1),%rbp
  9e5845:	cmpb   $0x4,0x3d(%rcx,%rax,1)
  9e584a:	jne    9e5887 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x11a7>
  9e584c:	mov    0x28(%rbp),%r12
  9e5850:	test   %r12,%r12
  9e5853:	je     9e5887 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x11a7>
  9e5855:	testb  $0x1,(%r12)
  9e585a:	jne    9e588a <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x11aa>
  9e585c:	mov    0x8(%r12),%rax
  9e5861:	test   $0x1,%al
  9e5863:	jne    9e588a <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x11aa>
  9e5865:	mov    $0x2,%eax
  9e586a:	lock xadd %rax,0x8(%r12)
  9e5871:	and    0x270(%rsp),%rax
  9e5879:	neg    %rax
  9e587c:	jno    9e588a <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x11aa>
  9e587e:	lock orq $0x1,0x8(%r12)
  9e5885:	jmp    9e588a <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x11aa>
  9e5887:	xor    %r12d,%r12d
  9e588a:	mov    0x18(%r13),%rdi
  9e588e:	test   %rdi,%rdi
  9e5891:	je     9e58af <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x11cf>
  9e5893:	testb  $0x1,(%rdi)
  9e5896:	jne    9e58af <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x11cf>
  9e5898:	mov    0x8(%rdi),%rax
  9e589c:	test   $0x1,%al
  9e589e:	jne    9e58af <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x11cf>
  9e58a0:	lea    0x8(%rdi),%rax
  9e58a4:	lock subq $0x2,(%rax)
  9e58a9:	je     9e5996 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x12b6>
  9e58af:	mov    %r12,0x18(%r13)
  9e58b3:	test   %r12,%r12
  9e58b6:	je     9e58d0 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x11f0>
  9e58b8:	mov    0x40(%r14),%rax
  9e58bc:	cmp    $0xffffffffffffffff,%rax
  9e58c0:	je     9e5ad8 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x13f8>
  9e58c6:	lea    0x1(%rax),%rcx
  9e58ca:	mov    %rcx,0x40(%r14)
  9e58ce:	jmp    9e58d2 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x11f2>
  9e58d0:	xor    %eax,%eax
  9e58d2:	mov    %r13,%rdx
  9e58d5:	mov    %rax,0x20(%r13)
  9e58d9:	cmpb   $0x4,0x3d(%rbp)
  9e58dd:	jne    9e592d <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x124d>
  9e58df:	cmpq   $0x0,0x28(%rbp)
  9e58e4:	je     9e592d <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x124d>
  9e58e6:	mov    0x38(%rbp),%r12d
  9e58ea:	mov    $0x1ffff,%eax
  9e58ef:	and    %eax,%r12d
  9e58f2:	cmp    $0x1ffff,%r12d
  9e58f9:	jne    9e5902 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x1222>
  9e58fb:	movb   $0x1,0x58(%rsp)
  9e5900:	jmp    9e592a <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x124a>
  9e5902:	mov    0x40(%rsp),%rbp
  9e5907:	cmp    0x30(%rsp),%rbp
  9e590c:	jne    9e5919 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x1239>
  9e590e:	lea    0x30(%rsp),%rdi
  9e5913:	call   *0xb4719f(%rip)        # 152cab8 <_DYNAMIC+0x778>
  9e5919:	mov    0x38(%rsp),%rax
  9e591e:	mov    %r12d,(%rax,%rbp,4)
  9e5922:	inc    %rbp
  9e5925:	mov    %rbp,0x40(%rsp)
  9e592a:	mov    %r13,%rdx
  9e592d:	mov    0x40(%r14),%rcx
  9e5931:	mov    %rcx,0x28(%rdx)
  9e5935:	mov    0x70(%rsp),%rax
  9e593a:	inc    %rax
  9e593d:	add    %rcx,%rax
  9e5940:	jb     9e5aaf <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x13cf>
  9e5946:	mov    %rdx,%r13
  9e5949:	mov    %rax,0x40(%r14)
  9e594d:	lea    0x1b8(%rsp),%rdi
  9e5955:	mov    0x1a0(%rsp),%rsi
  9e595d:	call   *0xb474c5(%rip)        # 152ce28 <_DYNAMIC+0xae8>
  9e5963:	test   %rax,%rax
  9e5966:	je     9e5ab6 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x13d6>
  9e596c:	mov    (%rax),%r12
  9e596f:	lock incq (%r12)
  9e5974:	jle    9e5b84 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x14a4>
  9e597a:	mov    0x0(%r13),%rax
  9e597e:	lock decq (%rax)
  9e5982:	jne    9e571b <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x103b>
  9e5988:	mov    %r13,%rdi
  9e598b:	call   *0xb46c6f(%rip)        # 152c600 <_DYNAMIC+0x2c0>
  9e5991:	jmp    9e571b <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x103b>
  9e5996:	mov    0x8(%rdi),%rax
  9e599a:	call   *0xb46c38(%rip)        # 152c5d8 <_DYNAMIC+0x298>
  9e59a0:	jmp    9e58af <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x11cf>
  9e59a5:	mov    0xa0(%r14),%rdi
  9e59ac:	add    $0x10,%rdi
  9e59b0:	call   *0xb47492(%rip)        # 152ce48 <_DYNAMIC+0xb08>
  9e59b6:	movq   $0x2a,(%rbx)
  9e59bd:	mov    0x158(%rsp),%rax
  9e59c5:	mov    %rax,0x10(%rsp)
  9e59ca:	jmp    9e56ab <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xfcb>
  9e59cf:	mov    %rdx,%rbp
  9e59d2:	mov    0xb0(%rsp),%r12
  9e59da:	mov    0xb8(%rsp),%rax
  9e59e2:	mov    %rax,0x80(%rsp)
  9e59ea:	mov    0xc0(%rsp),%rax
  9e59f2:	mov    %rax,0x28(%rsp)
  9e59f7:	movzwl 0x280(%rsp),%eax
  9e59ff:	mov    %ax,0x18(%rsp)
  9e5a04:	movzbl 0x282(%rsp),%eax
  9e5a0c:	mov    %al,0x1a(%rsp)
  9e5a10:	mov    0x30(%rsp),%rsi
  9e5a15:	test   %rsi,%rsi
  9e5a18:	jne    9e52b4 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xbd4>
  9e5a1e:	jmp    9e533a <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xc5a>
  9e5a23:	mov    0x118(%rsp),%rax
  9e5a2b:	mov    %rax,0x50(%rsp)
  9e5a30:	mov    0x40(%rsp),%rsi
  9e5a35:	cmp    $0x2,%rsi
  9e5a39:	jae    9e5b13 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x1433>
  9e5a3f:	lea    0x30(%rsp),%rdi
  9e5a44:	call   a2f3a0 <<alloc::vec::Vec<u32>>::dedup_by::<<alloc::vec::Vec<u32>>::dedup::{closure#0}>>
  9e5a49:	mov    0x30(%rsp),%r8
  9e5a4e:	mov    0x38(%rsp),%r9
  9e5a53:	mov    0x40(%rsp),%edi
  9e5a57:	movzbl 0x44(%rsp),%r10d
  9e5a5d:	movzwl 0x45(%rsp),%eax
  9e5a62:	mov    %ax,0x18(%rsp)
  9e5a67:	movzbl 0x47(%rsp),%eax
  9e5a6c:	mov    %al,0x1a(%rsp)
  9e5a70:	mov    0x48(%rsp),%r12
  9e5a75:	mov    0x50(%rsp),%rsi
  9e5a7a:	mov    0x58(%rsp),%rdx
  9e5a7f:	jmp    9e536b <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xc8b>
  9e5a84:	mov    $0x1e,%eax
  9e5a89:	jmp    9e5213 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xb33>
  9e5a8e:	cmp    $0x15,%rsi
  9e5a92:	jae    9e5b86 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x14a6>
  9e5a98:	lea    0x90(%rsp),%rcx
  9e5aa0:	mov    $0x1,%edx
  9e5aa5:	call   9fda80 <core::slice::sort::shared::smallsort::insertion_sort_shift_left::<gpui::native::accessibility::text::Input, <[gpui::native::accessibility::text::Input]>::sort_unstable_by_key<u64, <gpui::native::accessibility::text::Cohort>::refresh<empty::Empty, ()>::{closure#3}>::{closure#0}>>
  9e5aaa:	jmp    9e4e3a <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x75a>
  9e5aaf:	mov    $0x22,%esi
  9e5ab4:	jmp    9e5afb <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x141b>
  9e5ab6:	lea    0xad464b(%rip),%rax        # 14ba108 <anon.22b410f5f50bcdcdab7a6d64ae00c059.1.llvm.14574195959755080497+0x90>
  9e5abd:	mov    %rax,0x198(%rsp)
  9e5ac5:	mov    0x198(%rsp),%rdi
  9e5acd:	call   *0xb46ae5(%rip)        # 152c5b8 <_DYNAMIC+0x278>
  9e5ad3:	jmp    9e5b84 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x14a4>
  9e5ad8:	mov    $0x1b,%esi
  9e5add:	lea    -0x852ddf(%rip),%rax        # 192d05 <anon.5e2c2cd338f183f0185d3116c074ef00.75.llvm.4553572696083558104+0x342d>
  9e5ae4:	mov    %rax,0x188(%rsp)
  9e5aec:	lea    0xad45fd(%rip),%rax        # 14ba0f0 <anon.22b410f5f50bcdcdab7a6d64ae00c059.1.llvm.14574195959755080497+0x78>
  9e5af3:	mov    %rax,0x190(%rsp)
  9e5afb:	mov    0x188(%rsp),%rdi
  9e5b03:	mov    0x190(%rsp),%rdx
  9e5b0b:	call   *0xb46b9f(%rip)        # 152c6b0 <_DYNAMIC+0x370>
  9e5b11:	jmp    9e5b84 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x14a4>
  9e5b13:	mov    0x38(%rsp),%rdi
  9e5b18:	cmp    $0x15,%rsi
  9e5b1c:	jae    9e5b98 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x14b8>
  9e5b1e:	lea    (%rdi,%rsi,4),%rax
  9e5b22:	lea    0x4(%rdi),%rcx
  9e5b26:	mov    $0x4,%edx
  9e5b2b:	jmp    9e5b44 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x1464>
  9e5b2d:	mov    %rdi,%r8
  9e5b30:	mov    %esi,(%r8)
  9e5b33:	add    $0x4,%rcx
  9e5b37:	add    $0x4,%rdx
  9e5b3b:	cmp    %rax,%rcx
  9e5b3e:	je     9e5a3f <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x135f>
  9e5b44:	mov    -0x4(%rcx),%r9d
  9e5b48:	mov    (%rcx),%esi
  9e5b4a:	cmp    %r9d,%esi
  9e5b4d:	jae    9e5b33 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x1453>
  9e5b4f:	mov    %rdx,%r8
  9e5b52:	mov    %r9d,(%rdi,%r8,1)
  9e5b56:	cmp    $0x4,%r8
  9e5b5a:	je     9e5b2d <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x144d>
  9e5b5c:	mov    -0x8(%rdi,%r8,1),%r9d
  9e5b61:	add    $0xfffffffffffffffc,%r8
  9e5b65:	cmp    %r9d,%esi
  9e5b68:	jb     9e5b52 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x1472>
  9e5b6a:	add    %rdi,%r8
  9e5b6d:	jmp    9e5b30 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x1450>
  9e5b6f:	lea    0xad4562(%rip),%rdx        # 14ba0d8 <anon.22b410f5f50bcdcdab7a6d64ae00c059.1.llvm.14574195959755080497+0x60>
  9e5b76:	mov    0x10(%rsp),%rdi
  9e5b7b:	mov    %r12,%rsi
  9e5b7e:	call   *0xb46ae4(%rip)        # 152c668 <_DYNAMIC+0x328>
  9e5b84:	ud2
  9e5b86:	lea    0x90(%rsp),%rdx
  9e5b8e:	call   a18960 <core::slice::sort::unstable::ipnsort::<gpui::native::accessibility::text::Input, <[gpui::native::accessibility::text::Input]>::sort_unstable_by_key<u64, <gpui::native::accessibility::text::Cohort>::refresh<empty::Empty, ()>::{closure#3}>::{closure#0}>>
  9e5b93:	jmp    9e4e3a <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x75a>
  9e5b98:	lea    0x23(%rsp),%rdx
  9e5b9d:	call   *0xb472ad(%rip)        # 152ce50 <_DYNAMIC+0xb10>
  9e5ba3:	jmp    9e5a3f <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x135f>
  9e5ba8:	mov    %rax,%rbx
  9e5bab:	mov    %r12,0x18(%r13)
  9e5baf:	jmp    9e5c60 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x1580>
  9e5bb4:	mov    %rax,%rbx
  9e5bb7:	mov    %r12,0x0(%r13)
  9e5bbb:	jmp    9e5c60 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x1580>
  9e5bc0:	mov    %rax,%rbx
  9e5bc3:	mov    (%r12),%rax
  9e5bc7:	test   %rax,%rax
  9e5bca:	je     9e5bdf <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x14ff>
  9e5bcc:	mov    0x30(%r14),%rdi
  9e5bd0:	imul   $0x38,%rax,%rsi
  9e5bd4:	mov    $0x8,%edx
  9e5bd9:	call   *0xb469b1(%rip)        # 152c590 <_DYNAMIC+0x250>
  9e5bdf:	mov    0xa0(%rsp),%rax
  9e5be7:	mov    %rax,0x10(%r12)
  9e5bec:	movaps 0x90(%rsp),%xmm0
  9e5bf4:	movups %xmm0,(%r12)
  9e5bf9:	mov    %rbx,%rdi
  9e5bfc:	call   14b6fa0 <_Unwind_Resume@plt>
  9e5c01:	mov    %rax,%rbx
  9e5c04:	mov    0x30(%rsp),%rax
  9e5c09:	test   %rax,%rax
  9e5c0c:	je     9e5c6a <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x158a>
  9e5c0e:	mov    0x38(%rsp),%rdi
  9e5c13:	imul   $0x38,%rax,%rsi
  9e5c17:	mov    $0x8,%edx
  9e5c1c:	call   *0xb4696e(%rip)        # 152c590 <_DYNAMIC+0x250>
  9e5c22:	mov    %rbx,%rdi
  9e5c25:	call   14b6fa0 <_Unwind_Resume@plt>
  9e5c2a:	jmp    9e5c5d <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x157d>
  9e5c2c:	mov    %rax,%rbx
  9e5c2f:	lea    0x30(%rsp),%rdi
  9e5c34:	call   9e7100 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::native::accessibility::text::Input>>>
  9e5c39:	jmp    9e5c6a <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x158a>
  9e5c3b:	call   *0xb46987(%rip)        # 152c5c8 <_DYNAMIC+0x288>
  9e5c41:	mov    %rax,%rbx
  9e5c44:	mov    0x158(%rsp),%rsi
  9e5c4c:	test   %rsi,%rsi
  9e5c4f:	je     9e5c6a <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x158a>
  9e5c51:	mov    0x160(%rsp),%rdi
  9e5c59:	jmp    9e5c77 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x1597>
  9e5c5b:	jmp    9e5c5d <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x157d>
  9e5c5d:	mov    %rax,%rbx
  9e5c60:	mov    0x30(%rsp),%rsi
  9e5c65:	test   %rsi,%rsi
  9e5c68:	jne    9e5c72 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x1592>
  9e5c6a:	mov    %rbx,%rdi
  9e5c6d:	call   14b6fa0 <_Unwind_Resume@plt>
  9e5c72:	mov    0x38(%rsp),%rdi
  9e5c77:	shl    $0x2,%rsi
  9e5c7b:	mov    $0x4,%edx
  9e5c80:	call   *0xb4690a(%rip)        # 152c590 <_DYNAMIC+0x250>
  9e5c86:	mov    %rbx,%rdi
  9e5c89:	call   14b6fa0 <_Unwind_Resume@plt>


/tmp/gpui-a11y-owner-channel-captures/release-baseline/empty:     file format elf64-x86-64


Disassembly of section .text:

00000000009e5c90 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>>:
  9e5c90:	push   %rbp
  9e5c91:	push   %r15
  9e5c93:	push   %r14
  9e5c95:	push   %r13
  9e5c97:	push   %r12
  9e5c99:	push   %rbx
  9e5c9a:	sub    $0x558,%rsp
  9e5ca1:	mov    %rdi,%rbx
  9e5ca4:	cmpb   $0x2,0x80(%rsi)
  9e5cab:	jne    9e5d5c <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0xcc>
  9e5cb1:	movq   $0xfffffffffffffffd,(%rbx)
  9e5cb8:	movq   $0xfffffffffffffffd,0x38(%rbx)
  9e5cc0:	movq   $0xfffffffffffffffd,0x70(%rbx)
  9e5cc8:	movq   $0xfffffffffffffffd,0xa8(%rbx)
  9e5cd3:	movq   $0xfffffffffffffffd,0xe0(%rbx)
  9e5cde:	movq   $0xfffffffffffffffd,0x118(%rbx)
  9e5ce9:	movq   $0xfffffffffffffffd,0x150(%rbx)
  9e5cf4:	movq   $0xfffffffffffffffd,0x188(%rbx)
  9e5cff:	movq   $0xfffffffffffffffd,0x1c0(%rbx)
  9e5d0a:	movq   $0xfffffffffffffffd,0x1f8(%rbx)
  9e5d15:	movq   $0xfffffffffffffffd,0x230(%rbx)
  9e5d20:	movq   $0xfffffffffffffffd,0x268(%rbx)
  9e5d2b:	movq   $0xfffffffffffffffd,0x2a0(%rbx)
  9e5d36:	movq   $0xfffffffffffffffd,0x2d8(%rbx)
  9e5d41:	movq   $0xfffffffffffffffd,0x310(%rbx)
  9e5d4c:	movq   $0xfffffffffffffffd,0x348(%rbx)
  9e5d57:	jmp    9e6853 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0xbc3>
  9e5d5c:	mov    %rsi,%r15
  9e5d5f:	mov    0xa0(%rsi),%r14
  9e5d66:	movzbl 0x51(%r14),%eax
  9e5d6b:	test   %al,%al
  9e5d6d:	je     9e5d88 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0xf8>
  9e5d6f:	movb   $0x1,0x50(%r14)
  9e5d74:	movq   $0x2a,0x8(%rbx)
  9e5d7c:	movq   $0xfffffffffffffffc,(%rbx)
  9e5d83:	jmp    9e6853 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0xbc3>
  9e5d88:	mov    %rdx,0x78(%rsp)
  9e5d8d:	lea    0x28(%r15),%rax
  9e5d91:	mov    %rax,0x118(%rsp)
  9e5d99:	lea    0x10(%r14),%rax
  9e5d9d:	mov    %rax,0x138(%rsp)
  9e5da5:	movq   $0xfffffffffffffffd,0x1d8(%rsp)
  9e5db1:	movq   $0xfffffffffffffffd,0x210(%rsp)
  9e5dbd:	movq   $0xfffffffffffffffd,0x248(%rsp)
  9e5dc9:	movq   $0xfffffffffffffffd,0x280(%rsp)
  9e5dd5:	movq   $0xfffffffffffffffd,0x2b8(%rsp)
  9e5de1:	movq   $0xfffffffffffffffd,0x2f0(%rsp)
  9e5ded:	movq   $0xfffffffffffffffd,0x328(%rsp)
  9e5df9:	movq   $0xfffffffffffffffd,0x360(%rsp)
  9e5e05:	movq   $0xfffffffffffffffd,0x398(%rsp)
  9e5e11:	movq   $0xfffffffffffffffd,0x3d0(%rsp)
  9e5e1d:	movq   $0xfffffffffffffffd,0x408(%rsp)
  9e5e29:	movq   $0xfffffffffffffffd,0x440(%rsp)
  9e5e35:	movq   $0xfffffffffffffffd,0x478(%rsp)
  9e5e41:	movq   $0xfffffffffffffffd,0x4b0(%rsp)
  9e5e4d:	movq   $0xfffffffffffffffd,0x4e8(%rsp)
  9e5e59:	movq   $0xfffffffffffffffd,0x520(%rsp)
  9e5e65:	mov    0x30(%r15),%r12
  9e5e69:	mov    0x48(%r15),%rax
  9e5e6d:	mov    %rax,0x10(%rsp)
  9e5e72:	imul   $0x38,0x38(%r15),%rax
  9e5e77:	mov    %rax,0x140(%rsp)
  9e5e7f:	xor    %ebp,%ebp
  9e5e81:	lea    0x30(%rsp),%r13
  9e5e86:	mov    %r15,0x148(%rsp)
  9e5e8e:	mov    %r14,0x120(%rsp)
  9e5e96:	mov    %r12,0xd8(%rsp)
  9e5e9e:	jmp    9e5f3f <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x2af>
  9e5ea3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  9e5eb0:	mov    0x60(%rsp),%rax
  9e5eb5:	mov    %rax,0x30(%r14)
  9e5eb9:	movaps 0x30(%rsp),%xmm0
  9e5ebe:	movaps 0x40(%rsp),%xmm1
  9e5ec3:	mov    0x50(%rsp),%eax
  9e5ec7:	mov    %eax,0x20(%r14)
  9e5ecb:	movzbl 0x54(%rsp),%eax
  9e5ed0:	mov    %al,0x24(%r14)
  9e5ed4:	movzwl 0x55(%rsp),%eax
  9e5ed9:	mov    %ax,0x25(%r14)
  9e5ede:	movzbl 0x57(%rsp),%eax
  9e5ee3:	mov    %al,0x27(%r14)
  9e5ee7:	mov    0x58(%rsp),%eax
  9e5eeb:	mov    %eax,0x28(%r14)
  9e5eef:	movzbl 0x5c(%rsp),%eax
  9e5ef4:	mov    %al,0x2c(%r14)
  9e5ef8:	movzwl 0x5d(%rsp),%eax
  9e5efd:	mov    %ax,0x2d(%r14)
  9e5f02:	movzbl 0x5f(%rsp),%eax
  9e5f07:	mov    %al,0x2f(%r14)
  9e5f0b:	movups %xmm1,0x10(%r14)
  9e5f10:	movups %xmm0,(%r14)
  9e5f14:	mov    0x120(%rsp),%r14
  9e5f1c:	lea    0x30(%rsp),%r13
  9e5f21:	add    $0x38,%rbp
  9e5f25:	lea    0x190(%rsp),%rdi
  9e5f2d:	call   9e7a00 <core::ptr::drop_glue::<gpui::native::accessibility::Queued>>
  9e5f32:	cmp    $0x380,%rbp
  9e5f39:	je     9e682f <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0xb9f>
  9e5f3f:	mov    %r13,%rdi
  9e5f42:	mov    %r15,%rsi
  9e5f45:	call   a04bf0 <<std::sync::mpmc::Receiver<gpui::native::accessibility::Queued>>::try_recv>
  9e5f4a:	cmpb   $0xff,0x30(%rsp)
  9e5f4f:	je     9e683d <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0xbad>
  9e5f55:	movups 0x30(%rsp),%xmm0
  9e5f5a:	movups 0x40(%rsp),%xmm1
  9e5f5f:	movdqu 0x50(%rsp),%xmm2
  9e5f65:	movdqa %xmm2,0x1b0(%rsp)
  9e5f6e:	movaps %xmm1,0x1a0(%rsp)
  9e5f76:	movaps %xmm0,0x190(%rsp)
  9e5f7e:	mov    0x40(%r14),%rax
  9e5f82:	cmp    %rax,0x1b0(%rsp)
  9e5f8a:	jne    9e5f21 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x291>
  9e5f8c:	mov    %r13,%rdi
  9e5f8f:	lea    0x190(%rsp),%rsi
  9e5f97:	mov    0x118(%rsp),%rdx
  9e5f9f:	call   *0xb46eb3(%rip)        # 152ce58 <_DYNAMIC+0xb18>
  9e5fa5:	mov    0x30(%rsp),%rax
  9e5faa:	mov    0x38(%rsp),%r13
  9e5faf:	movups 0x40(%rsp),%xmm0
  9e5fb4:	movsd  0x50(%rsp),%xmm1
  9e5fba:	mov    0x58(%rsp),%r15d
  9e5fbf:	movzbl 0x5c(%rsp),%esi
  9e5fc4:	lea    0x5d(%rsp),%rdx
  9e5fc9:	movzwl (%rdx),%ecx
  9e5fcc:	mov    %cx,0x80(%rsp)
  9e5fd4:	movzbl 0x2(%rdx),%ecx
  9e5fd8:	mov    %cl,0x82(%rsp)
  9e5fdf:	cmp    $0xfffffffffffffffe,%rax
  9e5fe3:	jne    9e6060 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x3d0>
  9e5fe5:	movaps %xmm1,0x1c0(%rsp)
  9e5fed:	movaps %xmm0,0xe0(%rsp)
  9e5ff5:	movzwl 0x80(%rsp),%eax
  9e5ffd:	mov    %ax,0x2c(%rsp)
  9e6002:	movzbl 0x82(%rsp),%eax
  9e600a:	mov    %al,0x2e(%rsp)
  9e600e:	test   %r13,%r13
  9e6011:	jns    9e602d <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x39d>
  9e6013:	mov    0x120(%rsp),%rax
  9e601b:	mov    0x48(%rax),%rax
  9e601f:	cmp    %rax,0x1b8(%rsp)
  9e6027:	jne    9e62a6 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x616>
  9e602d:	mov    0x78(%rsp),%rax
  9e6032:	mov    (%rax),%r14
  9e6035:	test   %r14,%r14
  9e6038:	je     9e60c2 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x432>
  9e603e:	mov    %sil,0x7(%rsp)
  9e6043:	mov    $0xe,%esi
  9e6048:	cmpb   $0x0,0x72e(%r14)
  9e6050:	je     9e60ce <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x43e>
  9e6052:	mov    0x8(%rsp),%rax
  9e6057:	jmp    9e613e <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x4ae>
  9e605c:	nopl   0x0(%rax)
  9e6060:	mov    0x60(%rsp),%rcx
  9e6065:	movzbl 0x82(%rsp),%edx
  9e606d:	mov    %esi,%edi
  9e606f:	lea    0xcd(%rsp),%rsi
  9e6077:	mov    %dl,0x2(%rsi)
  9e607a:	movzwl 0x80(%rsp),%edx
  9e6082:	mov    %dx,(%rsi)
  9e6085:	mov    %rax,0xa0(%rsp)
  9e608d:	mov    %r13,0xa8(%rsp)
  9e6095:	movups %xmm0,0xb0(%rsp)
  9e609d:	movlps %xmm1,0xc0(%rsp)
  9e60a5:	mov    %r15d,0xc8(%rsp)
  9e60ad:	mov    %dil,0xcc(%rsp)
  9e60b5:	mov    %rcx,0xd0(%rsp)
  9e60bd:	jmp    9e6180 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x4f0>
  9e60c2:	mov    $0xd,%esi
  9e60c7:	mov    0x8(%rsp),%rax
  9e60cc:	jmp    9e613e <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x4ae>
  9e60ce:	mov    0x5b0(%r14),%rax
  9e60d5:	mov    $0x11,%esi
  9e60da:	mov    %rax,0x8(%rsp)
  9e60df:	cmp    %rax,0x10(%rsp)
  9e60e4:	jne    9e6134 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x4a4>
  9e60e6:	test   %r13,%r13
  9e60e9:	js     9e62b7 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x627>
  9e60ef:	setne  %al
  9e60f2:	test   $0x1,%r13b
  9e60f6:	sete   %cl
  9e60f9:	test   %cl,%al
  9e60fb:	je     9e612a <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x49a>
  9e60fd:	shr    $1,%r13
  9e6100:	mov    0x118(%rsp),%rdi
  9e6108:	mov    %r13,%rsi
  9e610b:	call   *0xb46d4f(%rip)        # 152ce60 <_DYNAMIC+0xb20>
  9e6111:	test   %rax,%rax
  9e6114:	mov    $0x11,%esi
  9e6119:	je     9e63d0 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x740>
  9e611f:	cmpq   $0x0,0x18(%rax)
  9e6124:	je     9e63d0 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x740>
  9e612a:	mov    0x10(%rsp),%rax
  9e612f:	mov    %rax,0x8(%rsp)
  9e6134:	mov    0x20(%rsp),%rax
  9e6139:	mov    0x18(%rsp),%rdx
  9e613e:	movaps 0xf0(%rsp),%xmm0
  9e6146:	movaps 0x100(%rsp),%xmm1
  9e614e:	lea    0xcd(%rsp),%rcx
  9e6156:	movups %xmm1,-0x5(%rcx)
  9e615a:	movups %xmm0,-0x15(%rcx)
  9e615e:	mov    %rsi,0xa0(%rsp)
  9e6166:	mov    %rax,0xa8(%rsp)
  9e616e:	mov    %rdx,0x18(%rsp)
  9e6173:	mov    %rdx,0xb0(%rsp)
  9e617b:	mov    %rax,0x20(%rsp)
  9e6180:	lea    (%rsp,%rbp,1),%r14
  9e6184:	add    $0x1d8,%r14
  9e618b:	mov    0xa0(%rsp),%rax
  9e6193:	mov    0xa8(%rsp),%rcx
  9e619b:	mov    0xb0(%rsp),%rdx
  9e61a3:	mov    0xb8(%rsp),%rsi
  9e61ab:	mov    0xc0(%rsp),%edi
  9e61b2:	movzbl 0xc4(%rsp),%r8d
  9e61bb:	movzwl 0xc5(%rsp),%r9d
  9e61c4:	movzbl 0xc7(%rsp),%r10d
  9e61cd:	mov    0xc8(%rsp),%r11d
  9e61d5:	movzbl 0xcc(%rsp),%r15d
  9e61de:	movzwl 0xcd(%rsp),%r12d
  9e61e7:	movzbl 0xcf(%rsp),%r13d
  9e61f0:	mov    %rax,0x30(%rsp)
  9e61f5:	mov    %rcx,0x38(%rsp)
  9e61fa:	mov    %rdx,0x40(%rsp)
  9e61ff:	mov    %rsi,0x48(%rsp)
  9e6204:	mov    %edi,0x50(%rsp)
  9e6208:	mov    %r8b,0x54(%rsp)
  9e620d:	mov    %r9w,0x55(%rsp)
  9e6213:	mov    %r10b,0x57(%rsp)
  9e6218:	mov    %r11d,0x58(%rsp)
  9e621d:	mov    %r15b,0x5c(%rsp)
  9e6222:	mov    %r12w,0x5d(%rsp)
  9e6228:	mov    %r13b,0x5f(%rsp)
  9e622d:	mov    0xd0(%rsp),%rax
  9e6235:	mov    %rax,0x60(%rsp)
  9e623a:	mov    (%r14),%rcx
  9e623d:	cmp    $0xffffffffffffffff,%rcx
  9e6241:	mov    0x148(%rsp),%r15
  9e6249:	jl     9e5eb0 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x220>
  9e624f:	sub    $0xd,%rcx
  9e6253:	mov    $0x14,%eax
  9e6258:	cmovl  %rax,%rcx
  9e625c:	cmp    $0x19,%rcx
  9e6260:	je     9e627f <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x5ef>
  9e6262:	mov    $0x18,%eax
  9e6267:	cmp    $0x14,%rcx
  9e626b:	jne    9e5eb0 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x220>
  9e6271:	mov    (%r14,%rax,1),%rsi
  9e6275:	test   %rsi,%rsi
  9e6278:	jne    9e6291 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x601>
  9e627a:	jmp    9e5eb0 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x220>
  9e627f:	mov    $0x8,%eax
  9e6284:	mov    (%r14,%rax,1),%rsi
  9e6288:	test   %rsi,%rsi
  9e628b:	je     9e5eb0 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x220>
  9e6291:	mov    0x8(%r14,%rax,1),%rdi
  9e6296:	mov    $0x1,%edx
  9e629b:	call   *0xb462ef(%rip)        # 152c590 <_DYNAMIC+0x250>
  9e62a1:	jmp    9e5eb0 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x220>
  9e62a6:	movq   $0x11,0xa0(%rsp)
  9e62b2:	jmp    9e6180 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x4f0>
  9e62b7:	lea    0x5b0(%r14),%rcx
  9e62be:	xor    %r12d,%r12d
  9e62c1:	mov    0xd8(%rsp),%rax
  9e62c9:	nopl   0x0(%rax)
  9e62d0:	cmp    %r12,0x140(%rsp)
  9e62d8:	je     9e612a <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x49a>
  9e62de:	add    $0x38,%r12
  9e62e2:	cmp    %r13,0x20(%rax)
  9e62e6:	lea    0x38(%rax),%rax
  9e62ea:	jne    9e62d0 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x640>
  9e62ec:	mov    0xd8(%rsp),%rax
  9e62f4:	mov    -0x30(%rax,%r12,1),%rsi
  9e62f9:	test   %rsi,%rsi
  9e62fc:	je     9e6405 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x775>
  9e6302:	mov    %rcx,%r13
  9e6305:	mov    %rcx,%rdi
  9e6308:	call   *0xb463ba(%rip)        # 152c6c8 <_DYNAMIC+0x388>
  9e630e:	mov    %rax,0x70(%rsp)
  9e6313:	mov    %rdx,0x68(%rsp)
  9e6318:	mov    $0x11,%esi
  9e631d:	mov    0x70(%rsp),%rax
  9e6322:	cmp    0x0(%r13),%rax
  9e6326:	jne    9e64ef <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x85f>
  9e632c:	lea    0x30(%rsp),%rdi
  9e6331:	mov    %r14,%rsi
  9e6334:	mov    0x68(%rsp),%rdx
  9e6339:	call   9d1570 <<gpui::runtime::Runtime<empty::Empty>>::resolve_identity>
  9e633e:	mov    0x30(%rsp),%rsi
  9e6343:	cmp    $0xfffffffffffffffe,%rsi
  9e6347:	jne    9e64f6 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x866>
  9e634d:	lea    0x30(%rsp),%rdi
  9e6352:	mov    0x78(%rsp),%rsi
  9e6357:	mov    0x70(%rsp),%rdx
  9e635c:	mov    0x68(%rsp),%rcx
  9e6361:	call   9bafc0 <<gpui::runtime::Win<empty::Empty>>::accessibility_input>
  9e6366:	mov    0x30(%rsp),%rsi
  9e636b:	mov    0x38(%rsp),%rax
  9e6370:	mov    0x40(%rsp),%rcx
  9e6375:	cmp    $0xfffffffffffffffe,%rsi
  9e6379:	jne    9e65fe <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x96e>
  9e637f:	mov    $0x11,%esi
  9e6384:	mov    0xd8(%rsp),%rdx
  9e638c:	cmp    %rax,-0x28(%rdx,%r12,1)
  9e6391:	jne    9e612a <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x49a>
  9e6397:	mov    -0x20(%rdx,%r12,1),%rax
  9e639c:	test   %rax,%rax
  9e639f:	je     9e6868 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0xbd8>
  9e63a5:	mov    (%rcx),%rcx
  9e63a8:	cmp    %rcx,%rax
  9e63ab:	jne    9e612a <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x49a>
  9e63b1:	mov    (%rcx),%rcx
  9e63b4:	xor    (%rax),%rcx
  9e63b7:	cmp    $0x2,%rcx
  9e63bb:	jae    9e612a <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x49a>
  9e63c1:	mov    0x68(%rsp),%r12
  9e63c6:	mov    0x70(%rsp),%r13
  9e63cb:	jmp    9e6470 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x7e0>
  9e63d0:	mov    0x78(%rsp),%rax
  9e63d5:	mov    (%rax),%r14
  9e63d8:	test   %r14,%r14
  9e63db:	je     9e63f6 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x766>
  9e63dd:	mov    $0xe,%esi
  9e63e2:	cmpb   $0x0,0x72e(%r14)
  9e63ea:	je     9e6414 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x784>
  9e63ec:	mov    0x18(%rsp),%rdx
  9e63f1:	jmp    9e65ea <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x95a>
  9e63f6:	mov    $0xd,%esi
  9e63fb:	mov    0x18(%rsp),%rdx
  9e6400:	jmp    9e65ea <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x95a>
  9e6405:	mov    $0x11,%esi
  9e640a:	mov    0x68(%rsp),%rax
  9e640f:	jmp    9e6552 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x8c2>
  9e6414:	lea    0x5b0(%r14),%r12
  9e641b:	mov    %r12,%rdi
  9e641e:	mov    %r13,%rsi
  9e6421:	call   *0xb462a1(%rip)        # 152c6c8 <_DYNAMIC+0x388>
  9e6427:	mov    %rax,0x20(%rsp)
  9e642c:	mov    %rdx,0x18(%rsp)
  9e6431:	mov    $0x11,%esi
  9e6436:	mov    0x20(%rsp),%rax
  9e643b:	cmp    (%r12),%rax
  9e643f:	jne    9e64f1 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x861>
  9e6445:	lea    0x30(%rsp),%rdi
  9e644a:	mov    %r14,%rsi
  9e644d:	mov    0x18(%rsp),%rdx
  9e6452:	call   9d1570 <<gpui::runtime::Runtime<empty::Empty>>::resolve_identity>
  9e6457:	mov    0x30(%rsp),%rsi
  9e645c:	cmp    $0xfffffffffffffffe,%rsi
  9e6460:	jne    9e658e <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x8fe>
  9e6466:	mov    0x18(%rsp),%r12
  9e646b:	mov    0x20(%rsp),%r13
  9e6470:	movzbl 0x7(%rsp),%edx
  9e6475:	mov    %edx,%eax
  9e6477:	sub    $0x2,%al
  9e6479:	movzbl %al,%r14d
  9e647d:	mov    $0x6,%eax
  9e6482:	cmovb  %eax,%r14d
  9e6486:	lea    -0x7(%r14),%eax
  9e648a:	cmp    $0x2,%al
  9e648c:	jae    9e662d <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x99d>
  9e6492:	lea    0x30(%rsp),%rdi
  9e6497:	mov    0x78(%rsp),%rsi
  9e649c:	mov    %r13,%rdx
  9e649f:	mov    %r12,%rcx
  9e64a2:	call   9bc7f0 <<gpui::runtime::Win<empty::Empty>>::accessibility_viewport_transform>
  9e64a7:	mov    0x30(%rsp),%rax
  9e64ac:	movss  0x38(%rsp),%xmm0
  9e64b2:	cmp    $0xfffffffffffffffe,%rax
  9e64b6:	jne    9e66d1 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0xa41>
  9e64bc:	movss  0x44(%rsp),%xmm1
  9e64c2:	cmp    $0x7,%r14b
  9e64c6:	je     9e67a2 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0xb12>
  9e64cc:	unpcklps %xmm1,%xmm0
  9e64cf:	cvtps2pd %xmm0,%xmm0
  9e64d2:	movapd 0xe0(%rsp),%xmm1
  9e64db:	divpd  %xmm0,%xmm1
  9e64df:	movapd %xmm1,0xe0(%rsp)
  9e64e8:	mov    $0xa,%dl
  9e64ea:	jmp    9e6646 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x9b6>
  9e64ef:	jmp    9e652a <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x89a>
  9e64f1:	jmp    9e65c2 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x932>
  9e64f6:	mov    0x38(%rsp),%rax
  9e64fb:	mov    %rax,0x70(%rsp)
  9e6500:	mov    0x40(%rsp),%rax
  9e6505:	mov    %rax,0x130(%rsp)
  9e650d:	lea    0x5d(%rsp),%rax
  9e6512:	movups -0x15(%rax),%xmm0
  9e6516:	movups -0x5(%rax),%xmm1
  9e651a:	movaps %xmm0,0x80(%rsp)
  9e6522:	movaps %xmm1,0x90(%rsp)
  9e652a:	movaps 0x80(%rsp),%xmm0
  9e6532:	movaps 0x90(%rsp),%xmm1
  9e653a:	movaps %xmm1,0x160(%rsp)
  9e6542:	movaps %xmm0,0x150(%rsp)
  9e654a:	mov    0x130(%rsp),%rax
  9e6552:	movaps 0x150(%rsp),%xmm0
  9e655a:	movaps 0x160(%rsp),%xmm1
  9e6562:	movaps %xmm0,0xf0(%rsp)
  9e656a:	movaps %xmm1,0x100(%rsp)
  9e6572:	mov    0x10(%rsp),%rcx
  9e6577:	mov    %rcx,0x8(%rsp)
  9e657c:	mov    %rax,0x68(%rsp)
  9e6581:	mov    %rax,%rdx
  9e6584:	mov    0x70(%rsp),%rax
  9e6589:	jmp    9e613e <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x4ae>
  9e658e:	mov    0x38(%rsp),%rax
  9e6593:	mov    %rax,0x20(%rsp)
  9e6598:	mov    0x40(%rsp),%rax
  9e659d:	mov    %rax,0x128(%rsp)
  9e65a5:	lea    0x5d(%rsp),%rax
  9e65aa:	movups -0x15(%rax),%xmm0
  9e65ae:	movups -0x5(%rax),%xmm1
  9e65b2:	movaps %xmm0,0x80(%rsp)
  9e65ba:	movaps %xmm1,0x90(%rsp)
  9e65c2:	movaps 0x80(%rsp),%xmm0
  9e65ca:	movaps 0x90(%rsp),%xmm1
  9e65d2:	movaps %xmm1,0x100(%rsp)
  9e65da:	movaps %xmm0,0xf0(%rsp)
  9e65e2:	mov    0x128(%rsp),%rdx
  9e65ea:	mov    0x10(%rsp),%rax
  9e65ef:	mov    %rax,0x8(%rsp)
  9e65f4:	mov    0x20(%rsp),%rax
  9e65f9:	jmp    9e613e <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x4ae>
  9e65fe:	lea    0x5d(%rsp),%rdx
  9e6603:	movups -0x15(%rdx),%xmm0
  9e6607:	movups -0x5(%rdx),%xmm1
  9e660b:	movaps %xmm1,0x100(%rsp)
  9e6613:	movaps %xmm0,0xf0(%rsp)
  9e661b:	mov    0x10(%rsp),%rdx
  9e6620:	mov    %rdx,0x8(%rsp)
  9e6625:	mov    %rcx,%rdx
  9e6628:	jmp    9e613e <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x4ae>
  9e662d:	movzbl 0x2e(%rsp),%eax
  9e6632:	mov    %al,0x82(%rsp)
  9e6639:	movzwl 0x2c(%rsp),%eax
  9e663e:	mov    %ax,0x80(%rsp)
  9e6646:	movzbl 0x82(%rsp),%eax
  9e664e:	mov    %al,0xf2(%rsp)
  9e6655:	movzwl 0x80(%rsp),%ecx
  9e665d:	mov    %cx,0xf0(%rsp)
  9e6665:	movaps 0xe0(%rsp),%xmm0
  9e666d:	movaps %xmm0,0x170(%rsp)
  9e6675:	movaps 0x1c0(%rsp),%xmm0
  9e667d:	movlps %xmm0,0x180(%rsp)
  9e6685:	mov    %r15d,0x188(%rsp)
  9e668d:	mov    %dl,0x18c(%rsp)
  9e6694:	lea    0x18d(%rsp),%rdx
  9e669c:	mov    %al,0x2(%rdx)
  9e669f:	mov    %cx,(%rdx)
  9e66a2:	lea    0xa0(%rsp),%rdi
  9e66aa:	mov    0x78(%rsp),%rsi
  9e66af:	mov    %r13,%rdx
  9e66b2:	mov    %r12,%rcx
  9e66b5:	lea    0x170(%rsp),%r8
  9e66bd:	call   9b8f00 <<gpui::runtime::Win<empty::Empty>>::perform>
  9e66c2:	mov    0x10(%rsp),%rax
  9e66c7:	mov    %rax,0x8(%rsp)
  9e66cc:	jmp    9e6180 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x4f0>
  9e66d1:	movss  0x3c(%rsp),%xmm1
  9e66d7:	mov    0x50(%rsp),%ecx
  9e66db:	movzbl 0x54(%rsp),%edx
  9e66e0:	lea    0x5d(%rsp),%rsi
  9e66e5:	movups -0x8(%rsi),%xmm2
  9e66e9:	movaps %xmm2,0x80(%rsp)
  9e66f1:	mov    0x7(%rsi),%esi
  9e66f4:	mov    %esi,0x8f(%rsp)
  9e66fb:	movdqu 0x40(%rsp),%xmm2
  9e6701:	movss  %xmm0,0x150(%rsp)
  9e670a:	movss  %xmm1,0x154(%rsp)
  9e6713:	movsd  0x150(%rsp),%xmm0
  9e671c:	movzbl 0x82(%rsp),%esi
  9e6724:	mov    %sil,0xf2(%rsp)
  9e672c:	movzwl 0x80(%rsp),%esi
  9e6734:	mov    %si,0xf0(%rsp)
  9e673c:	lea    0x83(%rsp),%rsi
  9e6744:	movups (%rsi),%xmm1
  9e6747:	lea    0xcd(%rsp),%rdi
  9e674f:	movups %xmm1,-0x5(%rdi)
  9e6753:	movzbl 0xf2(%rsp),%esi
  9e675b:	mov    %sil,-0x6(%rdi)
  9e675f:	movzwl 0xf0(%rsp),%esi
  9e6767:	mov    %si,-0x8(%rdi)
  9e676b:	mov    %rax,0xa0(%rsp)
  9e6773:	movsd  %xmm0,0xa8(%rsp)
  9e677c:	movdqu %xmm2,0xb0(%rsp)
  9e6785:	mov    %ecx,0xc0(%rsp)
  9e678c:	mov    %dl,0xc4(%rsp)
  9e6793:	mov    0x10(%rsp),%rax
  9e6798:	mov    %rax,0x8(%rsp)
  9e679d:	jmp    9e6180 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x4f0>
  9e67a2:	movdqa 0xe0(%rsp),%xmm2
  9e67ab:	movd   %xmm2,%eax
  9e67af:	movzbl %ah,%eax
  9e67b2:	lea    -0x853aed(%rip),%rcx        # 192ccc <anon.5e2c2cd338f183f0185d3116c074ef00.75.llvm.4553572696083558104+0x33f4>
  9e67b9:	movslq (%rcx,%rax,4),%rax
  9e67bd:	add    %rcx,%rax
  9e67c0:	jmp    *%rax
  9e67c2:	xorps  %xmm0,%xmm0
  9e67c5:	ucomiss %xmm1,%xmm0
  9e67c8:	jbe    9e6806 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0xb76>
  9e67ca:	mov    $0x100,%eax
  9e67cf:	jmp    9e6808 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0xb78>
  9e67d1:	mov    $0x200,%eax
  9e67d6:	xorps  %xmm1,%xmm1
  9e67d9:	ucomiss %xmm0,%xmm1
  9e67dc:	jbe    9e6808 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0xb78>
  9e67de:	mov    $0x300,%eax
  9e67e3:	jmp    9e6808 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0xb78>
  9e67e5:	mov    $0x300,%eax
  9e67ea:	xorps  %xmm1,%xmm1
  9e67ed:	ucomiss %xmm0,%xmm1
  9e67f0:	jbe    9e6808 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0xb78>
  9e67f2:	mov    $0x200,%eax
  9e67f7:	jmp    9e6808 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0xb78>
  9e67f9:	mov    $0x100,%eax
  9e67fe:	xorps  %xmm0,%xmm0
  9e6801:	ucomiss %xmm1,%xmm0
  9e6804:	jbe    9e6808 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0xb78>
  9e6806:	xor    %eax,%eax
  9e6808:	movdqa 0xe0(%rsp),%xmm0
  9e6811:	movq   %xmm0,%rcx
  9e6816:	movzbl %cl,%ecx
  9e6819:	or     %ecx,%eax
  9e681b:	movd   %eax,%xmm0
  9e681f:	movdqa %xmm0,0xe0(%rsp)
  9e6828:	mov    $0x9,%dl
  9e682a:	jmp    9e6646 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x9b6>
  9e682f:	mov    0x138(%rsp),%rdi
  9e6837:	call   *0xb4662b(%rip)        # 152ce68 <_DYNAMIC+0xb28>
  9e683d:	lea    0x1d8(%rsp),%rsi
  9e6845:	mov    $0x380,%edx
  9e684a:	mov    %rbx,%rdi
  9e684d:	call   *0xb45d4d(%rip)        # 152c5a0 <memcpy@GLIBC_2.14>
  9e6853:	mov    %rbx,%rax
  9e6856:	add    $0x558,%rsp
  9e685d:	pop    %rbx
  9e685e:	pop    %r12
  9e6860:	pop    %r13
  9e6862:	pop    %r14
  9e6864:	pop    %r15
  9e6866:	pop    %rbp
  9e6867:	ret
  9e6868:	lea    0xad38c9(%rip),%rdi        # 14ba138 <anon.22b410f5f50bcdcdab7a6d64ae00c059.1.llvm.14574195959755080497+0xc0>
  9e686f:	call   *0xb45d43(%rip)        # 152c5b8 <_DYNAMIC+0x278>
  9e6875:	ud2
  9e6877:	jmp    9e68a0 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0xc10>
  9e6879:	jmp    9e687b <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0xbeb>
  9e687b:	mov    %rax,%rbx
  9e687e:	lea    0x190(%rsp),%rdi
  9e6886:	call   9e7a00 <core::ptr::drop_glue::<gpui::native::accessibility::Queued>>
  9e688b:	lea    0x1d8(%rsp),%rdi
  9e6893:	call   9e68c0 <core::ptr::drop_glue::<[core::option::Option<core::result::Result<gpui::runtime::Commit, gpui::runtime::Error>>; 16]>>
  9e6898:	mov    %rbx,%rdi
  9e689b:	call   14b6fa0 <_Unwind_Resume@plt>
  9e68a0:	mov    %rax,%rbx
  9e68a3:	lea    0x1d8(%rsp),%rdi
  9e68ab:	call   9e68c0 <core::ptr::drop_glue::<[core::option::Option<core::result::Result<gpui::runtime::Commit, gpui::runtime::Error>>; 16]>>
  9e68b0:	mov    %rbx,%rdi
  9e68b3:	call   14b6fa0 <_Unwind_Resume@plt>


/tmp/gpui-a11y-owner-channel-captures/release-baseline/empty:     file format elf64-x86-64


Disassembly of section .text:

00000000009e7e40 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>::{closure#2}>:
  9e7e40:	mov    (%rdi),%rax
  9e7e43:	movzbl 0x30(%rax),%ecx
  9e7e47:	cmp    $0x2,%cl
  9e7e4a:	jne    9e7e4f <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>::{closure#2}+0xf>
  9e7e4c:	xor    %eax,%eax
  9e7e4e:	ret
  9e7e4f:	sub    $0x78,%rsp
  9e7e53:	mov    0x8(%rdi),%rdx
  9e7e57:	mov    0x10(%rdi),%rsi
  9e7e5b:	movups (%rax),%xmm0
  9e7e5e:	movups 0x10(%rax),%xmm1
  9e7e62:	movups 0x20(%rax),%xmm2
  9e7e66:	movaps %xmm2,0x60(%rsp)
  9e7e6b:	movaps %xmm1,0x50(%rsp)
  9e7e70:	movaps %xmm0,0x40(%rsp)
  9e7e75:	mov    %cl,0x70(%rsp)
  9e7e79:	mov    0x31(%rax),%edi
  9e7e7c:	mov    0x34(%rax),%eax
  9e7e7f:	mov    %edi,0x71(%rsp)
  9e7e83:	mov    %eax,0x74(%rsp)
  9e7e87:	mov    0x30(%rsi),%rax
  9e7e8b:	mov    %rax,0x30(%rsp)
  9e7e90:	movups (%rsi),%xmm0
  9e7e93:	movups 0x10(%rsi),%xmm1
  9e7e97:	movups 0x20(%rsi),%xmm2
  9e7e9b:	movaps %xmm2,0x20(%rsp)
  9e7ea0:	movaps %xmm1,0x10(%rsp)
  9e7ea5:	movaps %xmm0,(%rsp)
  9e7ea9:	mov    (%rdx),%rsi
  9e7eac:	test   %rsi,%rsi
  9e7eaf:	je     9e7f52 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>::{closure#2}+0x112>
  9e7eb5:	xor    %eax,%eax
  9e7eb7:	cmpb   $0x1,0x72c(%rsi)
  9e7ebe:	jne    9e7f54 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>::{closure#2}+0x114>
  9e7ec4:	test   $0x1,%cl
  9e7ec7:	je     9e7f54 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>::{closure#2}+0x114>
  9e7ecd:	testb  $0x1,0x30(%rsp)
  9e7ed2:	je     9e7f20 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>::{closure#2}+0xe0>
  9e7ed4:	mov    0x668(%rsi),%rdx
  9e7edb:	mov    0x670(%rsi),%r11
  9e7ee2:	mov    0x680(%rsi),%rdi
  9e7ee9:	lea    0x5b0(%rsi),%rcx
  9e7ef0:	mov    (%rsp),%r9
  9e7ef4:	mov    0x10(%rsp),%r10
  9e7ef9:	mov    0x28(%rsp),%r8
  9e7efe:	test   %r11,%r11
  9e7f01:	je     9e7f25 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>::{closure#2}+0xe5>
  9e7f03:	xor    %eax,%eax
  9e7f05:	test   %r9,%r9
  9e7f08:	je     9e7f54 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>::{closure#2}+0x114>
  9e7f0a:	cmp    %r9,(%rcx)
  9e7f0d:	jne    9e7f54 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>::{closure#2}+0x114>
  9e7f0f:	cmp    0x8(%rsp),%r11
  9e7f14:	jne    9e7f54 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>::{closure#2}+0x114>
  9e7f16:	cmp    %r10,%rdx
  9e7f19:	jne    9e7f54 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>::{closure#2}+0x114>
  9e7f1b:	cmp    %r8,%rdi
  9e7f1e:	je     9e7f33 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>::{closure#2}+0xf3>
  9e7f20:	add    $0x78,%rsp
  9e7f24:	ret
  9e7f25:	xor    %r10,%rdx
  9e7f28:	or     %rdx,%r9
  9e7f2b:	xor    %r8,%rdi
  9e7f2e:	or     %r9,%rdi
  9e7f31:	jne    9e7f52 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>::{closure#2}+0x112>
  9e7f33:	mov    0x678(%rsi),%rdi
  9e7f3a:	test   %rdi,%rdi
  9e7f3d:	je     9e7f52 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>::{closure#2}+0x112>
  9e7f3f:	lea    0x40(%rsp),%rsi
  9e7f44:	mov    %rsp,%rdx
  9e7f47:	call   *0xb4498b(%rip)        # 152c8d8 <_DYNAMIC+0x598>
  9e7f4d:	add    $0x78,%rsp
  9e7f51:	ret
  9e7f52:	xor    %eax,%eax
  9e7f54:	add    $0x78,%rsp
  9e7f58:	ret


/tmp/gpui-a11y-owner-channel-captures/release-baseline/empty:     file format elf64-x86-64


Disassembly of section .text:

0000000000a16d30 <empty::main>:
  a16d30:	push   %r14
  a16d32:	push   %rbx
  a16d33:	sub    $0x98,%rsp
  a16d3a:	mov    %rdi,%rbx
  a16d3d:	call   *0xb1583d(%rip)        # 152c580 <_DYNAMIC+0x240>
  a16d43:	mov    $0x4,%edi
  a16d48:	mov    $0x1,%esi
  a16d4d:	call   *0xb15835(%rip)        # 152c588 <_DYNAMIC+0x248>
  a16d53:	test   %rax,%rax
  a16d56:	je     a16dc8 <empty::main+0x98>
  a16d58:	movl   $0x49555047,(%rax)
  a16d5e:	movq   $0x4,0x8(%rsp)
  a16d67:	mov    %rax,0x10(%rsp)
  a16d6c:	movq   $0x4,0x18(%rsp)
  a16d75:	movabs $0x25800000320,%rax
  a16d7f:	mov    %rax,0x20(%rsp)
  a16d84:	movq   $0x0,0x28(%rsp)
  a16d8d:	movq   $0x0,0x38(%rsp)
  a16d96:	movw   $0x0,0x48(%rsp)
  a16d9d:	lea    0x50(%rsp),%r14
  a16da2:	lea    0x8(%rsp),%rsi
  a16da7:	mov    %r14,%rdi
  a16daa:	call   a20590 <empty::renderer::configure::<empty::Empty>>
  a16daf:	mov    %rbx,%rdi
  a16db2:	mov    %r14,%rsi
  a16db5:	call   a1ff00 <<gpui::application::Application>::run_window::<empty::Empty, ()>>
  a16dba:	mov    %rbx,%rax
  a16dbd:	add    $0x98,%rsp
  a16dc4:	pop    %rbx
  a16dc5:	pop    %r14
  a16dc7:	ret
  a16dc8:	mov    $0x1,%edi
  a16dcd:	mov    $0x4,%esi
  a16dd2:	call   *0xb15898(%rip)        # 152c670 <_DYNAMIC+0x330>


/tmp/gpui-a11y-owner-channel-captures/release-baseline/empty:     file format elf64-x86-64


Disassembly of section .text:

0000000000a38ca0 <<gpui::native::NativeHost<empty::Empty>>::present_cpu>:
  a38ca0:	push   %rbp
  a38ca1:	push   %r15
  a38ca3:	push   %r14
  a38ca5:	push   %r13
  a38ca7:	push   %r12
  a38ca9:	push   %rbx
  a38caa:	sub    $0xe8,%rsp
  a38cb1:	testb  $0x1,0x188(%rsi)
  a38cb8:	je     a391d1 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x531>
  a38cbe:	mov    %rsi,%r14
  a38cc1:	cmpq   $0x0,0x1d8(%rsi)
  a38cc9:	je     a39318 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x678>
  a38ccf:	cmpb   $0x0,(%r14)
  a38cd3:	je     a39331 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x691>
  a38cd9:	mov    %edx,%ebp
  a38cdb:	mov    %rdi,%rbx
  a38cde:	lea    0x8(%r14),%r12
  a38ce2:	mov    %rsp,%rdi
  a38ce5:	mov    %r12,%rsi
  a38ce8:	call   9ad6a0 <<gpui::runtime::Win<empty::Empty>>::with_scene::<core::result::Result<core::option::Option<(u32, gpui::runtime::PresentationToken)>, gpui_canvas::Error>, <gpui::native::NativeHost<empty::Empty>>::present_cpu::{closure#0}>>
  a38ced:	mov    (%rsp),%rdx
  a38cf1:	mov    0x8(%rsp),%ecx
  a38cf5:	mov    0xc(%rsp),%eax
  a38cf9:	mov    0x10(%rsp),%r13d
  a38cfe:	cmp    $0xfffffffffffffffe,%rdx
  a38d02:	jne    a38d1d <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x7d>
  a38d04:	test   $0x1,%cl
  a38d07:	je     a38d49 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0xa9>
  a38d09:	movq   $0x23,0x8(%rbx)
  a38d11:	mov    %eax,0x10(%rbx)
  a38d14:	mov    %r13d,0x14(%rbx)
  a38d18:	jmp    a392ff <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x65f>
  a38d1d:	mov    0x14(%rsp),%esi
  a38d21:	movups 0x28(%rsp),%xmm0
  a38d26:	movups %xmm0,0x30(%rbx)
  a38d2a:	movups 0x18(%rsp),%xmm0
  a38d2f:	mov    %rdx,0x8(%rbx)
  a38d33:	mov    %ecx,0x10(%rbx)
  a38d36:	mov    %eax,0x14(%rbx)
  a38d39:	mov    %r13d,0x18(%rbx)
  a38d3d:	mov    %esi,0x1c(%rbx)
  a38d40:	movups %xmm0,0x20(%rbx)
  a38d44:	jmp    a392ff <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x65f>
  a38d49:	lea    0x18a(%r14),%r15
  a38d50:	mov    0x18(%rsp),%rax
  a38d55:	mov    %rax,0xc0(%rsp)
  a38d5d:	test   %rax,%rax
  a38d60:	je     a38e3e <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x19e>
  a38d66:	mov    0x20(%rsp),%rax
  a38d6b:	mov    %rax,0x38(%rsp)
  a38d70:	call   a38b90 <<winit::window::Window>::pre_present_notify>
  a38d75:	cmp    $0x1000000,%r13d
  a38d7c:	jae    a38ec2 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x222>
  a38d82:	mov    0x1a8(%r14),%rsi
  a38d89:	lea    0x80(%rsp),%rdi
  a38d91:	mov    %r13d,%edx
  a38d94:	call   a2bdd0 <<softbuffer::backends::x11::X11Impl<alloc::sync::Arc<winit::window::Window>, alloc::sync::Arc<winit::window::Window>> as softbuffer::backend_interface::SurfaceInterface<alloc::sync::Arc<winit::window::Window>, alloc::sync::Arc<winit::window::Window>>>::present_solid>
  a38d99:	cmpl   $0xffffffff,0x80(%rsp)
  a38da1:	jne    a38f2d <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x28d>
  a38da7:	cmpb   $0x1,0x84(%rsp)
  a38daf:	jne    a38e3e <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x19e>
  a38db5:	mov    (%r12),%rsi
  a38db9:	test   %rsi,%rsi
  a38dbc:	je     a392c2 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x622>
  a38dc2:	mov    $0xe,%eax
  a38dc7:	cmpb   $0x1,0x72e(%rsi)
  a38dce:	je     a392d0 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x630>
  a38dd4:	mov    %rsp,%rdi
  a38dd7:	mov    0xc0(%rsp),%rdx
  a38ddf:	mov    0x38(%rsp),%rcx
  a38de4:	call   9c3020 <<gpui::runtime::Runtime<empty::Empty>>::acknowledge>
  a38de9:	mov    (%rsp),%rax
  a38ded:	lea    0x8(%rsp),%rcx
  a38df2:	cmp    $0xfffffffffffffffe,%rax
  a38df6:	jne    a392d5 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x635>
  a38dfc:	movups (%rcx),%xmm0
  a38dff:	movups 0x10(%rcx),%xmm1
  a38e03:	movups 0x20(%rcx),%xmm2
  a38e07:	movaps %xmm2,0x60(%rsp)
  a38e0c:	movaps %xmm1,0x50(%rsp)
  a38e11:	movaps %xmm0,0x40(%rsp)
  a38e16:	movups %xmm2,0x28(%rbx)
  a38e1a:	movups %xmm1,0x18(%rbx)
  a38e1e:	movups %xmm0,0x8(%rbx)
  a38e22:	xorps  %xmm0,%xmm0
  a38e25:	movups %xmm0,0x9(%r15)
  a38e2a:	movups %xmm0,(%r15)
  a38e2e:	movb   $0x0,0x38(%rbx)
  a38e32:	movq   $0x0,(%rbx)
  a38e39:	jmp    a39306 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x666>
  a38e3e:	mov    0x1a8(%r14),%rsi
  a38e45:	mov    %rsp,%rdi
  a38e48:	call   a2b610 <<softbuffer::backends::x11::X11Impl<alloc::sync::Arc<winit::window::Window>, alloc::sync::Arc<winit::window::Window>> as softbuffer::backend_interface::SurfaceInterface<alloc::sync::Arc<winit::window::Window>, alloc::sync::Arc<winit::window::Window>>>::buffer_mut>
  a38e4d:	mov    (%rsp),%eax
  a38e50:	cmp    $0xffffffff,%eax
  a38e53:	je     a38fce <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x32e>
  a38e59:	mov    0x4(%rsp),%ecx
  a38e5d:	mov    0x8(%rsp),%rdx
  a38e62:	mov    0x30(%rsp),%rsi
  a38e67:	mov    %rsi,0x70(%rsp)
  a38e6c:	movups 0x20(%rsp),%xmm0
  a38e71:	movups %xmm0,0x60(%rsp)
  a38e76:	movups 0x10(%rsp),%xmm0
  a38e7b:	movups %xmm0,0x50(%rsp)
  a38e80:	mov    %eax,0x40(%rsp)
  a38e84:	mov    %ecx,0x44(%rsp)
  a38e88:	mov    %rdx,0x48(%rsp)
  a38e8d:	mov    %rsp,%rdi
  a38e90:	lea    0x40(%rsp),%rsi
  a38e95:	call   a38060 <gpui::native::platform::<softbuffer::error::SoftBufferError>>
  a38e9a:	movups (%rsp),%xmm0
  a38e9e:	movups 0x10(%rsp),%xmm1
  a38ea3:	movups 0x20(%rsp),%xmm2
  a38ea8:	movups %xmm1,0x18(%rbx)
  a38eac:	movups %xmm2,0x28(%rbx)
  a38eb0:	mov    0x30(%rsp),%rax
  a38eb5:	mov    %rax,0x38(%rbx)
  a38eb9:	movups %xmm0,0x8(%rbx)
  a38ebd:	jmp    a392ff <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x65f>
  a38ec2:	call   *0xaf36b8(%rip)        # 152c580 <_DYNAMIC+0x240>
  a38ec8:	mov    $0x1e,%edi
  a38ecd:	mov    $0x1,%esi
  a38ed2:	call   *0xaf36b0(%rip)        # 152c588 <_DYNAMIC+0x248>
  a38ed8:	test   %rax,%rax
  a38edb:	je     a3938b <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x6eb>
  a38ee1:	movups -0x8a16d6(%rip),%xmm0        # 197812 <anon.3dc55358d894c5b53264aaf2d0c32b03.62.llvm.10171937222764603197+0xe>
  a38ee8:	movups %xmm0,0xe(%rax)
  a38eec:	movups -0x8a16ef(%rip),%xmm0        # 197804 <anon.3dc55358d894c5b53264aaf2d0c32b03.62.llvm.10171937222764603197>
  a38ef3:	movups %xmm0,(%rax)
  a38ef6:	movl   $0x17,0x80(%rsp)
  a38f01:	movq   $0x1e,0x88(%rsp)
  a38f0d:	mov    %rax,0x90(%rsp)
  a38f15:	movq   $0x1e,0x98(%rsp)
  a38f21:	movq   $0x0,0xa0(%rsp)
  a38f2d:	mov    0xb0(%rsp),%rax
  a38f35:	mov    %rax,0x70(%rsp)
  a38f3a:	mov    0x80(%rsp),%eax
  a38f41:	mov    0x84(%rsp),%ecx
  a38f48:	mov    0x88(%rsp),%rdx
  a38f50:	mov    0x90(%rsp),%rsi
  a38f58:	mov    0x98(%rsp),%rdi
  a38f60:	mov    0xa0(%rsp),%r8
  a38f68:	mov    %r8,0x60(%rsp)
  a38f6d:	mov    0xa8(%rsp),%r8
  a38f75:	mov    %r8,0x68(%rsp)
  a38f7a:	mov    %rsi,0x50(%rsp)
  a38f7f:	mov    %rdi,0x58(%rsp)
  a38f84:	mov    %eax,0x40(%rsp)
  a38f88:	mov    %ecx,0x44(%rsp)
  a38f8c:	mov    %rdx,0x48(%rsp)
  a38f91:	mov    %rsp,%rdi
  a38f94:	lea    0x40(%rsp),%rsi
  a38f99:	call   a38060 <gpui::native::platform::<softbuffer::error::SoftBufferError>>
  a38f9e:	mov    (%rsp),%rax
  a38fa2:	movzbl 0x8(%rsp),%ecx
  a38fa7:	movups 0x28(%rsp),%xmm0
  a38fac:	movups %xmm0,0x30(%rbx)
  a38fb0:	movups 0x19(%rsp),%xmm0
  a38fb5:	movups %xmm0,0x21(%rbx)
  a38fb9:	movups 0x9(%rsp),%xmm0
  a38fbe:	movups %xmm0,0x11(%rbx)
  a38fc2:	mov    %rax,0x8(%rbx)
  a38fc6:	mov    %cl,0x10(%rbx)
  a38fc9:	jmp    a392ff <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x65f>
  a38fce:	mov    0x8(%rsp),%r13
  a38fd3:	movzbl 0x50(%r13),%eax
  a38fd8:	cmpl   $0x2,0x0(%r13)
  a38fdd:	jne    a38ff3 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x353>
  a38fdf:	mov    0x10(%r13),%rcx
  a38fe3:	mov    %rcx,0x78(%rsp)
  a38fe8:	mov    0x18(%r13),%rcx
  a38fec:	mov    %rcx,0x38(%rsp)
  a38ff1:	jmp    a39043 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x3a3>
  a38ff3:	mov    0x10(%r13),%rcx
  a38ff7:	test   %rcx,%rcx
  a38ffa:	je     a39030 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x390>
  a38ffc:	mov    0x18(%r13),%rdx
  a39000:	mov    0x20(%r13),%rsi
  a39004:	cmp    %rdx,%rsi
  a39007:	ja     a3934a <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x6aa>
  a3900d:	test   $0x3,%cl
  a39010:	jne    a3939b <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x6fb>
  a39016:	test   $0x3,%sil
  a3901a:	jne    a393b2 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x712>
  a39020:	mov    %rcx,0x78(%rsp)
  a39025:	shr    $0x2,%rsi
  a39029:	mov    %rsi,0x38(%rsp)
  a3902e:	jmp    a39043 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x3a3>
  a39030:	mov    $0x4,%ecx
  a39035:	mov    %rcx,0x78(%rsp)
  a3903a:	movq   $0x0,0x38(%rsp)
  a39043:	movzbl %al,%edx
  a39046:	mov    %rsp,%rdi
  a39049:	mov    %r15,%rsi
  a3904c:	call   *0xaf4576(%rip)        # 152d5c8 <_DYNAMIC+0x1288>
  a39052:	mov    (%r12),%r14
  a39056:	test   %r14,%r14
  a39059:	je     a3906f <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x3cf>
  a3905b:	cmpb   $0x0,0x72e(%r14)
  a39063:	je     a3907b <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x3db>
  a39065:	mov    $0xe,%eax
  a3906a:	jmp    a3911c <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x47c>
  a3906f:	mov    $0xd,%eax
  a39074:	xor    %edx,%edx
  a39076:	jmp    a3911c <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x47c>
  a3907b:	mov    0x690(%r14),%rax
  a39082:	test   %rax,%rax
  a39085:	je     a3909a <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x3fa>
  a39087:	cmpq   $0xffffffffffffffff,0x588(%r14)
  a3908f:	je     a390a1 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x401>
  a39091:	mov    0x5a0(%r14),%rsi
  a39098:	jmp    a390a3 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x403>
  a3909a:	mov    $0x14,%eax
  a3909f:	jmp    a3911c <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x47c>
  a390a1:	xor    %esi,%esi
  a390a3:	mov    %rax,0xe0(%rsp)
  a390ab:	mov    0x698(%r14),%rax
  a390b2:	mov    %rax,0xd8(%rsp)
  a390ba:	cmpw   $0x1,(%rsp)
  a390bf:	mov    %rsi,0xb8(%rsp)
  a390c7:	jne    a390d3 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x433>
  a390c9:	cmpb   $0x0,0x72d(%r14)
  a390d1:	je     a390e8 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x448>
  a390d3:	mov    %r14,%rdi
  a390d6:	mov    0x78(%rsp),%rsi
  a390db:	mov    0x38(%rsp),%rdx
  a390e0:	call   *0xaf384a(%rip)        # 152c930 <_DYNAMIC+0x5f0>
  a390e6:	jmp    a39109 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x469>
  a390e8:	mov    0x2(%rsp),%rdi
  a390ed:	call   *0xaf36cd(%rip)        # 152c7c0 <_DYNAMIC+0x480>
  a390f3:	mov    %r14,%rdi
  a390f6:	mov    0x78(%rsp),%rsi
  a390fb:	mov    0x38(%rsp),%rdx
  a39100:	mov    %rax,%rcx
  a39103:	call   *0xaf382f(%rip)        # 152c938 <_DYNAMIC+0x5f8>
  a39109:	cmp    $0xffffffff,%eax
  a3910c:	je     a39129 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x489>
  a3910e:	mov    %eax,%eax
  a39110:	shl    $0x20,%rdx
  a39114:	or     %rax,%rdx
  a39117:	mov    $0x23,%eax
  a3911c:	mov    %rax,0x8(%rbx)
  a39120:	mov    %rdx,0x10(%rbx)
  a39124:	jmp    a392ff <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x65f>
  a39129:	mov    0xc0(%rsp),%r14
  a39131:	test   %r14,%r14
  a39134:	jne    a3913b <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x49b>
  a39136:	call   a38b90 <<winit::window::Window>::pre_present_notify>
  a3913b:	test   %bpl,%bpl
  a3913e:	je     a39152 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x4b2>
  a39140:	lea    0x40(%rsp),%rdi
  a39145:	mov    %r13,%rsi
  a39148:	call   a2e420 <<softbuffer::backends::x11::BufferImpl<alloc::sync::Arc<winit::window::Window>, alloc::sync::Arc<winit::window::Window>> as softbuffer::backend_interface::BufferInterface>::present>
  a3914d:	jmp    a391fe <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x55e>
  a39152:	lea    0x80(%rsp),%rdi
  a3915a:	mov    0xb8(%rsp),%rsi
  a39162:	call   *0xaf4468(%rip)        # 152d5d0 <_DYNAMIC+0x1290>
  a39168:	cmpb   $0x0,0x80(%rsp)
  a39170:	je     a391ea <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x54a>
  a39172:	mov    0x84(%rsp),%eax
  a39179:	mov    0x8c(%rsp),%ecx
  a39180:	sub    %eax,%ecx
  a39182:	je     a39359 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x6b9>
  a39188:	mov    0x88(%rsp),%edx
  a3918f:	mov    0x90(%rsp),%esi
  a39196:	sub    %edx,%esi
  a39198:	je     a39372 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x6d2>
  a3919e:	mov    %ecx,0xc8(%rsp)
  a391a5:	mov    %esi,0xcc(%rsp)
  a391ac:	mov    %eax,0xd0(%rsp)
  a391b3:	mov    %edx,0xd4(%rsp)
  a391ba:	lea    0x40(%rsp),%rdi
  a391bf:	lea    0xc8(%rsp),%rdx
  a391c7:	mov    $0x1,%ecx
  a391cc:	mov    %r13,%rsi
  a391cf:	jmp    a391f9 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x559>
  a391d1:	lea    -0x8a02dd(%rip),%rdi        # 198efb <anon.7cc7c74d1b8f8dfb5e74abfe8b727cdb.77.llvm.18220644203745900989+0x707>
  a391d8:	lea    0xa83151(%rip),%rdx        # 14bc330 <anon.f48bbd6ee32d24e1254dac28089ef4b7.8.llvm.17379179981059708172+0x150>
  a391df:	mov    $0xb7,%esi
  a391e4:	call   *0xaf33e6(%rip)        # 152c5d0 <_DYNAMIC+0x290>
  a391ea:	lea    0x40(%rsp),%rdi
  a391ef:	mov    $0x4,%edx
  a391f4:	mov    %r13,%rsi
  a391f7:	xor    %ecx,%ecx
  a391f9:	call   a2da10 <<softbuffer::backends::x11::BufferImpl<alloc::sync::Arc<winit::window::Window>, alloc::sync::Arc<winit::window::Window>> as softbuffer::backend_interface::BufferInterface>::present_with_damage>
  a391fe:	cmpl   $0xffffffff,0x40(%rsp)
  a39203:	je     a3923d <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x59d>
  a39205:	mov    0x70(%rsp),%rax
  a3920a:	mov    %rax,0x30(%rsp)
  a3920f:	movups 0x40(%rsp),%xmm0
  a39214:	movups 0x50(%rsp),%xmm1
  a39219:	movups 0x60(%rsp),%xmm2
  a3921e:	movaps %xmm2,0x20(%rsp)
  a39223:	movaps %xmm1,0x10(%rsp)
  a39228:	movaps %xmm0,(%rsp)
  a3922c:	lea    0x8(%rbx),%rdi
  a39230:	mov    %rsp,%rsi
  a39233:	call   a38060 <gpui::native::platform::<softbuffer::error::SoftBufferError>>
  a39238:	jmp    a392ff <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x65f>
  a3923d:	mov    (%r12),%rsi
  a39241:	test   %rsi,%rsi
  a39244:	je     a392c2 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x622>
  a39246:	mov    $0xe,%eax
  a3924b:	cmpb   $0x1,0x72e(%rsi)
  a39252:	je     a392d0 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x630>
  a39254:	mov    %rsp,%rdi
  a39257:	mov    0xe0(%rsp),%rdx
  a3925f:	mov    0xd8(%rsp),%rcx
  a39267:	call   9c3020 <<gpui::runtime::Runtime<empty::Empty>>::acknowledge>
  a3926c:	mov    (%rsp),%rax
  a39270:	lea    0x8(%rsp),%rcx
  a39275:	cmp    $0xfffffffffffffffe,%rax
  a39279:	jne    a392d5 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x635>
  a3927b:	movups (%rcx),%xmm0
  a3927e:	movups 0x10(%rcx),%xmm1
  a39282:	movups 0x20(%rcx),%xmm2
  a39286:	movaps %xmm2,0x60(%rsp)
  a3928b:	movaps %xmm1,0x50(%rsp)
  a39290:	movaps %xmm0,0x40(%rsp)
  a39295:	movups %xmm2,0x28(%rbx)
  a39299:	movups %xmm1,0x18(%rbx)
  a3929d:	movups %xmm0,0x8(%rbx)
  a392a1:	mov    %r15,%rdi
  a392a4:	mov    0xb8(%rsp),%rsi
  a392ac:	call   *0xaf4326(%rip)        # 152d5d8 <_DYNAMIC+0x1298>
  a392b2:	test   %r14,%r14
  a392b5:	sete   0x38(%rbx)
  a392b9:	movq   $0x0,(%rbx)
  a392c0:	jmp    a39306 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x666>
  a392c2:	movq   $0x0,0x8(%rsp)
  a392cb:	mov    $0xd,%eax
  a392d0:	lea    0x8(%rsp),%rcx
  a392d5:	movups (%rcx),%xmm0
  a392d8:	movups 0x10(%rcx),%xmm1
  a392dc:	movups 0x20(%rcx),%xmm2
  a392e0:	movaps %xmm2,0x60(%rsp)
  a392e5:	movaps %xmm1,0x50(%rsp)
  a392ea:	movaps %xmm0,0x40(%rsp)
  a392ef:	movups %xmm2,0x30(%rbx)
  a392f3:	movups %xmm1,0x20(%rbx)
  a392f7:	movups %xmm0,0x10(%rbx)
  a392fb:	mov    %rax,0x8(%rbx)
  a392ff:	movq   $0x1,(%rbx)
  a39306:	add    $0xe8,%rsp
  a3930d:	pop    %rbx
  a3930e:	pop    %r12
  a39310:	pop    %r13
  a39312:	pop    %r14
  a39314:	pop    %r15
  a39316:	pop    %rbp
  a39317:	ret
  a39318:	lea    -0x8a045b(%rip),%rdi        # 198ec4 <anon.7cc7c74d1b8f8dfb5e74abfe8b727cdb.77.llvm.18220644203745900989+0x6d0>
  a3931f:	lea    0xa82faa(%rip),%rdx        # 14bc2d0 <anon.f48bbd6ee32d24e1254dac28089ef4b7.8.llvm.17379179981059708172+0xf0>
  a39326:	mov    $0x14,%esi
  a3932b:	call   *0xaf337f(%rip)        # 152c6b0 <_DYNAMIC+0x370>
  a39331:	lea    -0x8a0460(%rip),%rdi        # 198ed8 <anon.7cc7c74d1b8f8dfb5e74abfe8b727cdb.77.llvm.18220644203745900989+0x6e4>
  a39338:	lea    0xa82fa9(%rip),%rdx        # 14bc2e8 <anon.f48bbd6ee32d24e1254dac28089ef4b7.8.llvm.17379179981059708172+0x108>
  a3933f:	mov    $0x14,%esi
  a39344:	call   *0xaf3366(%rip)        # 152c6b0 <_DYNAMIC+0x370>
  a3934a:	lea    0xa82f2f(%rip),%rcx        # 14bc280 <anon.f48bbd6ee32d24e1254dac28089ef4b7.8.llvm.17379179981059708172+0xa0>
  a39351:	xor    %edi,%edi
  a39353:	call   *0xaf3267(%rip)        # 152c5c0 <_DYNAMIC+0x280>
  a39359:	lea    -0x8a0474(%rip),%rdi        # 198eec <anon.7cc7c74d1b8f8dfb5e74abfe8b727cdb.77.llvm.18220644203745900989+0x6f8>
  a39360:	lea    0xa82f99(%rip),%rdx        # 14bc300 <anon.f48bbd6ee32d24e1254dac28089ef4b7.8.llvm.17379179981059708172+0x120>
  a39367:	mov    $0xf,%esi
  a3936c:	call   *0xaf333e(%rip)        # 152c6b0 <_DYNAMIC+0x370>
  a39372:	lea    -0x8a048d(%rip),%rdi        # 198eec <anon.7cc7c74d1b8f8dfb5e74abfe8b727cdb.77.llvm.18220644203745900989+0x6f8>
  a39379:	lea    0xa82f98(%rip),%rdx        # 14bc318 <anon.f48bbd6ee32d24e1254dac28089ef4b7.8.llvm.17379179981059708172+0x138>
  a39380:	mov    $0xf,%esi
  a39385:	call   *0xaf3325(%rip)        # 152c6b0 <_DYNAMIC+0x370>
  a3938b:	mov    $0x1,%edi
  a39390:	mov    $0x1e,%esi
  a39395:	call   *0xaf32d5(%rip)        # 152c670 <_DYNAMIC+0x330>
  a3939b:	xor    %eax,%eax
  a3939d:	movzbl %al,%edx
  a393a0:	lea    -0x8a04f1(%rip),%rdi        # 198eb6 <anon.7cc7c74d1b8f8dfb5e74abfe8b727cdb.77.llvm.18220644203745900989+0x6c2>
  a393a7:	mov    $0xe,%esi
  a393ac:	call   *0xaf422e(%rip)        # 152d5e0 <_DYNAMIC+0x12a0>
  a393b2:	mov    $0x1,%al
  a393b4:	movzbl %al,%edx
  a393b7:	lea    -0x8a0508(%rip),%rdi        # 198eb6 <anon.7cc7c74d1b8f8dfb5e74abfe8b727cdb.77.llvm.18220644203745900989+0x6c2>
  a393be:	mov    $0xe,%esi
  a393c3:	call   *0xaf4217(%rip)        # 152d5e0 <_DYNAMIC+0x12a0>


/tmp/gpui-a11y-owner-channel-captures/release-baseline/empty:     file format elf64-x86-64


Disassembly of section .text:

0000000000a393d0 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade>:
  a393d0:	push   %rbp
  a393d1:	push   %r15
  a393d3:	push   %r14
  a393d5:	push   %r13
  a393d7:	push   %r12
  a393d9:	push   %rbx
  a393da:	sub    $0x248,%rsp
  a393e1:	mov    %rdi,%rbx
  a393e4:	cmpl   $0xffffffff,0xe0(%rsi)
  a393eb:	je     a3948b <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0xbb>
  a393f1:	mov    %rsi,%r15
  a393f4:	mov    0x1d8(%rsi),%rax
  a393fb:	test   %rax,%rax
  a393fe:	je     a39b18 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x748>
  a39404:	lock incq (%rax)
  a39408:	jle    a39b4a <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x77a>
  a3940e:	mov    %rax,0x8(%rsp)
  a39413:	cmpl   $0xffffffff,0xc0(%r15)
  a3941b:	je     a3949b <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0xcb>
  a3941d:	mov    0xd8(%r15),%r14
  a39424:	lock incq (%r14)
  a39428:	jle    a39b4a <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x77a>
  a3942e:	mov    %r14,0x1f0(%rsp)
  a39436:	mov    0xc0(%r15),%rax
  a3943d:	mov    0xc8(%r15),%rcx
  a39444:	test   %rax,%rax
  a39447:	je     a396ab <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x2db>
  a3944d:	cmp    $0x1,%eax
  a39450:	jne    a396c4 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x2f4>
  a39456:	lock incq 0x180(%rcx)
  a3945e:	jle    a396b9 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x2e9>
  a39464:	mov    0xd0(%r15),%rdx
  a3946b:	lock incq (%rdx)
  a3946f:	jle    a39b4a <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x77a>
  a39475:	mov    %rax,0x30(%rsp)
  a3947a:	mov    %rcx,0x38(%rsp)
  a3947f:	mov    %rdx,0x40(%rsp)
  a39484:	mov    %r14,0x48(%rsp)
  a39489:	jmp    a394a4 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0xd4>
  a3948b:	movb   $0x0,0x8(%rbx)
  a3948f:	movq   $0xfffffffffffffffe,(%rbx)
  a39496:	jmp    a39699 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x2c9>
  a3949b:	movq   $0xffffffffffffffff,0x30(%rsp)
  a394a4:	lea    0xe0(%r15),%r12
  a394ab:	lea    0x130(%rsp),%rdi
  a394b3:	lea    0x8(%rsp),%rdx
  a394b8:	lea    0x30(%rsp),%rcx
  a394bd:	mov    %r12,%rsi
  a394c0:	call   *0xaf4122(%rip)        # 152d5e8 <_DYNAMIC+0x12a8>
  a394c6:	mov    0x130(%rsp),%r14
  a394ce:	movabs $0x8000000000000000,%rcx
  a394d8:	xor    %r14,%rcx
  a394db:	test   %r14,%r14
  a394de:	mov    $0x2,%eax
  a394e3:	cmovs  %rcx,%rax
  a394e7:	test   %rax,%rax
  a394ea:	je     a3963d <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x26d>
  a394f0:	cmp    $0x1,%rax
  a394f4:	jne    a3964a <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x27a>
  a394fa:	mov    0x138(%rsp),%r14
  a39502:	mov    0x140(%rsp),%rax
  a3950a:	mov    %r14,0x190(%rsp)
  a39512:	mov    %rax,(%rsp)
  a39516:	mov    %rax,0x198(%rsp)
  a3951e:	mov    %r12,%rdi
  a39521:	call   a34700 <core::ptr::drop_glue::<core::option::Option<gpui::native::upgrade::Upgrade>>>
  a39526:	movq   $0xffffffffffffffff,0xe0(%r15)
  a39531:	mov    %r14,0x18(%rsp)
  a39536:	movb   $0x1,0x205(%r15)
  a3953e:	mov    0x8(%rsp),%rdi
  a39543:	add    $0x10,%rdi
  a39547:	call   a3bc10 <<winit::window::Window>::inner_size>
  a3954c:	cmpl   $0x1,(%r15)
  a39550:	jne    a39b31 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x761>
  a39556:	mov    %eax,%ebp
  a39558:	mov    %edx,%r13d
  a3955b:	mov    (%rsp),%rax
  a3955f:	mov    0x3d8(%rax),%rsi
  a39566:	add    $0x10,%rsi
  a3956a:	lea    0x30(%rsp),%rdi
  a3956f:	call   *0xaf407b(%rip)        # 152d5f0 <_DYNAMIC+0x12b0>
  a39575:	mov    0x30(%rsp),%rsi
  a3957a:	cmp    $0xfffffffffffffffe,%rsi
  a3957e:	je     a396d1 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x301>
  a39584:	cmp    $0xffffffffffffffff,%rsi
  a39588:	je     a3959f <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x1cf>
  a3958a:	test   %rsi,%rsi
  a3958d:	je     a3959f <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x1cf>
  a3958f:	mov    0x38(%rsp),%rdi
  a39594:	mov    $0x1,%edx
  a39599:	call   *0xaf2ff1(%rip)        # 152c590 <_DYNAMIC+0x250>
  a3959f:	mov    $0x2f,%r13d
  a395a5:	mov    %r13,0x30(%rsp)
  a395aa:	movlps %xmm0,0x38(%rsp)
  a395af:	mov    %rbp,0x40(%rsp)
  a395b4:	mov    %rax,0x48(%rsp)
  a395b9:	mov    %r12,0x50(%rsp)
  a395be:	movaps 0x1e0(%rsp),%xmm0
  a395c6:	movups %xmm0,0x58(%rsp)
  a395cb:	mov    (%rsp),%rdi
  a395cf:	call   a34fc0 <core::ptr::drop_glue::<alloc::boxed::Box<gpui::native::GpuSurface>>>
  a395d4:	mov    0x18(%rsp),%rax
  a395d9:	mov    %rax,0x130(%rsp)
  a395e1:	lock decq (%rax)
  a395e5:	jne    a395f5 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x225>
  a395e7:	lea    0x130(%rsp),%rdi
  a395ef:	call   *0xaf38cb(%rip)        # 152cec0 <_DYNAMIC+0xb80>
  a395f5:	lea    0x30(%rsp),%rax
  a395fa:	mov    %rax,0x130(%rsp)
  a39602:	mov    0xaf3fef(%rip),%rax        # 152d5f8 <_DYNAMIC+0x12b8>
  a39609:	mov    %rax,0x138(%rsp)
  a39611:	lea    -0x8d09d7(%rip),%rdi        # 168c41 <anon.4fc0b732051cd9c0c5e7a6e9d819518c.14.llvm.5251204661969696906+0x12d>
  a39618:	lea    0x130(%rsp),%rsi
  a39620:	call   *0xaf3f4a(%rip)        # 152d570 <_DYNAMIC+0x1230>
  a39626:	movb   $0x0,0x8(%rbx)
  a3962a:	movq   $0xfffffffffffffffe,(%rbx)
  a39631:	lea    0x30(%rsp),%rdi
  a39636:	call   a36f00 <core::ptr::drop_glue::<gpui::native::NativeError>>
  a3963b:	jmp    a39683 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x2b3>
  a3963d:	movb   $0x0,0x8(%rbx)
  a39641:	movq   $0xfffffffffffffffe,(%rbx)
  a39648:	jmp    a39683 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x2b3>
  a3964a:	mov    0x138(%rsp),%r15
  a39652:	mov    %r12,%rdi
  a39655:	call   a34700 <core::ptr::drop_glue::<core::option::Option<gpui::native::upgrade::Upgrade>>>
  a3965a:	movq   $0xffffffffffffffff,(%r12)
  a39662:	movb   $0x0,0x8(%rbx)
  a39666:	movq   $0xfffffffffffffffe,(%rbx)
  a3966d:	test   %r14,%r14
  a39670:	je     a39683 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x2b3>
  a39672:	mov    $0x1,%edx
  a39677:	mov    %r15,%rdi
  a3967a:	mov    %r14,%rsi
  a3967d:	call   *0xaf2f0d(%rip)        # 152c590 <_DYNAMIC+0x250>
  a39683:	mov    0x8(%rsp),%rax
  a39688:	lock decq (%rax)
  a3968c:	jne    a39699 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x2c9>
  a3968e:	lea    0x8(%rsp),%rdi
  a39693:	call   *0xaf397f(%rip)        # 152d018 <_DYNAMIC+0xcd8>
  a39699:	add    $0x248,%rsp
  a396a0:	pop    %rbx
  a396a1:	pop    %r12
  a396a3:	pop    %r13
  a396a5:	pop    %r14
  a396a7:	pop    %r15
  a396a9:	pop    %rbp
  a396aa:	ret
  a396ab:	lock incq 0x200(%rcx)
  a396b3:	jg     a39464 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x94>
  a396b9:	call   *0xaf3939(%rip)        # 152cff8 <_DYNAMIC+0xcb8>
  a396bf:	jmp    a39b4a <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x77a>
  a396c4:	lock incq 0x70(%rcx)
  a396c9:	jg     a39464 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x94>
  a396cf:	jmp    a396b9 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x2e9>
  a396d1:	mov    (%rsp),%rax
  a396d5:	lea    0x348(%rax),%r12
  a396dc:	lea    0x30(%rsp),%rdi
  a396e1:	mov    %r12,%rsi
  a396e4:	call   *0xaf3f16(%rip)        # 152d600 <_DYNAMIC+0x12c0>
  a396ea:	mov    0x34(%rsp),%eax
  a396ee:	cmp    %eax,%ebp
  a396f0:	seta   %cl
  a396f3:	cmp    %eax,%r13d
  a396f6:	seta   %al
  a396f9:	or     %cl,%al
  a396fb:	je     a39708 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x338>
  a396fd:	mov    $0x2e,%r13d
  a39703:	jmp    a395a5 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x1d5>
  a39708:	cmp    $0x1,%ebp
  a3970b:	adc    $0x0,%ebp
  a3970e:	cmp    $0x1,%r13d
  a39712:	adc    $0x0,%r13d
  a39716:	mov    (%rsp),%rcx
  a3971a:	mov    0x370(%rcx),%eax
  a39720:	mov    %eax,0x1ac(%rsp)
  a39727:	mov    0x368(%rcx),%rax
  a3972e:	mov    %rax,0x1a4(%rsp)
  a39736:	movl   $0x10,0x1a0(%rsp)
  a39741:	movl   $0x1,0x1b0(%rsp)
  a3974c:	mov    %ebp,0x1b4(%rsp)
  a39753:	mov    %r13d,0x1b8(%rsp)
  a3975b:	movl   $0x2,0x1bc(%rsp)
  a39766:	movl   $0x1,0x1c0(%rsp)
  a39771:	movl   $0x1,0x1c4(%rsp)
  a3977c:	movq   $0x0,0x1c8(%rsp)
  a39788:	movq   $0x4,0x1d0(%rsp)
  a39794:	movq   $0x0,0x1d8(%rsp)
  a397a0:	lea    0x378(%rcx),%r13
  a397a7:	lea    0x1a0(%rsp),%rdx
  a397af:	mov    %r13,%rdi
  a397b2:	mov    %r12,%rsi
  a397b5:	call   *0xaf3e4d(%rip)        # 152d608 <_DYNAMIC+0x12c8>
  a397bb:	lea    0x30(%rsp),%rdi
  a397c0:	mov    %r13,%rsi
  a397c3:	call   *0xaf3e47(%rip)        # 152d610 <_DYNAMIC+0x12d0>
  a397c9:	mov    0x30(%rsp),%rax
  a397ce:	cmp    $0x1,%rax
  a397d2:	je     a39984 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x5b4>
  a397d8:	test   %rax,%rax
  a397db:	jne    a3998e <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x5be>
  a397e1:	movups 0x88(%rsp),%xmm0
  a397e9:	movaps %xmm0,0x180(%rsp)
  a397f1:	movups 0x78(%rsp),%xmm0
  a397f6:	movaps %xmm0,0x170(%rsp)
  a397fe:	movups 0x38(%rsp),%xmm0
  a39803:	movups 0x48(%rsp),%xmm1
  a39808:	movups 0x58(%rsp),%xmm2
  a3980d:	movups 0x68(%rsp),%xmm3
  a39812:	movaps %xmm3,0x160(%rsp)
  a3981a:	movaps %xmm2,0x150(%rsp)
  a39822:	movaps %xmm1,0x140(%rsp)
  a3982a:	movaps %xmm0,0x130(%rsp)
  a39832:	lea    0x138(%rsp),%rsi
  a3983a:	movq   $0x0,0x48(%rsp)
  a39843:	movl   $0xffffffff,0x60(%rsp)
  a3984b:	movl   $0x0,0x30(%rsp)
  a39853:	movabs $0xffffffff00000000,%rax
  a3985d:	mov    %rax,0x58(%rsp)
  a39862:	movq   $0x0,0x6c(%rsp)
  a3986b:	movl   $0x0,0x38(%rsp)
  a39873:	movl   $0x0,0x40(%rsp)
  a3987b:	lea    0x1f0(%rsp),%rdi
  a39883:	lea    0x30(%rsp),%rdx
  a39888:	call   *0xaf3d8a(%rip)        # 152d618 <_DYNAMIC+0x12d8>
  a3988e:	lea    0x8(%r15),%rsi
  a39892:	mov    $0x1,%r12b
  a39895:	lea    0x30(%rsp),%rdi
  a3989a:	lea    0x1f0(%rsp),%rcx
  a398a2:	mov    (%rsp),%rdx
  a398a6:	call   9ad360 <<gpui::runtime::Win<empty::Empty>>::with_paint_scene::<core::result::Result<gpui::runtime::PresentationToken, gpui_gpu::renderer::Error>, <gpui::native::NativeHost<empty::Empty>>::try_upgrade::{closure#0}::{closure#0}>>
  a398ab:	mov    0x30(%rsp),%r13
  a398b0:	mov    0x40(%rsp),%rbp
  a398b5:	movsd  0x38(%rsp),%xmm0
  a398bb:	movaps %xmm0,0x20(%rsp)
  a398c0:	mov    0x48(%rsp),%rax
  a398c5:	mov    %rax,0x10(%rsp)
  a398ca:	mov    0x50(%rsp),%r12
  a398cf:	cmp    $0xfffffffffffffffe,%r13
  a398d3:	jne    a39996 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x5c6>
  a398d9:	mov    $0x2c,%r13d
  a398df:	cmpl   $0xffffffff,0x38(%rsp)
  a398e4:	jne    a399a3 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x5d3>
  a398ea:	mov    $0x1,%r12b
  a398ed:	call   a38b90 <<winit::window::Window>::pre_present_notify>
  a398f2:	mov    (%rsp),%rax
  a398f6:	lea    0x350(%rax),%rdi
  a398fd:	movaps 0x180(%rsp),%xmm0
  a39905:	movaps %xmm0,0x80(%rsp)
  a3990d:	movaps 0x170(%rsp),%xmm0
  a39915:	movaps %xmm0,0x70(%rsp)
  a3991a:	movaps 0x130(%rsp),%xmm0
  a39922:	movaps 0x140(%rsp),%xmm1
  a3992a:	movaps 0x150(%rsp),%xmm2
  a39932:	movaps 0x160(%rsp),%xmm3
  a3993a:	movaps %xmm3,0x60(%rsp)
  a3993f:	movaps %xmm2,0x50(%rsp)
  a39944:	movaps %xmm1,0x40(%rsp)
  a39949:	movaps %xmm0,0x30(%rsp)
  a3994e:	xor    %r12d,%r12d
  a39951:	lea    0x30(%rsp),%rsi
  a39956:	call   *0xaf3cc4(%rip)        # 152d620 <_DYNAMIC+0x12e0>
  a3995c:	lea    0x8(%r15),%rax
  a39960:	mov    (%rax),%rsi
  a39963:	test   %rsi,%rsi
  a39966:	je     a399f7 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x627>
  a3996c:	cmpb   $0x0,0x72e(%rsi)
  a39973:	je     a39a10 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x640>
  a39979:	mov    $0xe,%r13d
  a3997f:	jmp    a39a49 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x679>
  a39984:	lea    0x38(%rsp),%rdi
  a39989:	call   a371a0 <core::ptr::drop_glue::<wgpu::api::surface_texture::SurfaceTexture>>
  a3998e:	mov    $0x2f,%r13d
  a39994:	jmp    a399e8 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x618>
  a39996:	movups 0x58(%rsp),%xmm0
  a3999b:	movaps %xmm0,0x1e0(%rsp)
  a399a3:	mov    0x1f0(%rsp),%rax
  a399ab:	lock decq (%rax)
  a399af:	jne    a399bf <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x5ef>
  a399b1:	lea    0x1f0(%rsp),%rdi
  a399b9:	call   *0xaf34e1(%rip)        # 152cea0 <_DYNAMIC+0xb60>
  a399bf:	mov    0x1f8(%rsp),%rax
  a399c7:	lock decq (%rax)
  a399cb:	jne    a399db <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x60b>
  a399cd:	lea    0x1f8(%rsp),%rdi
  a399d5:	call   *0xaf34bd(%rip)        # 152ce98 <_DYNAMIC+0xb58>
  a399db:	lea    0x130(%rsp),%rdi
  a399e3:	call   a371a0 <core::ptr::drop_glue::<wgpu::api::surface_texture::SurfaceTexture>>
  a399e8:	mov    0x10(%rsp),%rax
  a399ed:	movaps 0x20(%rsp),%xmm0
  a399f2:	jmp    a395a5 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x1d5>
  a399f7:	movq   $0xd,0x30(%rsp)
  a39a00:	xorps  %xmm0,%xmm0
  a39a03:	movaps %xmm0,0x20(%rsp)
  a39a08:	mov    $0xd,%r13d
  a39a0e:	jmp    a39a49 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x679>
  a39a10:	xor    %r12d,%r12d
  a39a13:	lea    0x30(%rsp),%rdi
  a39a18:	mov    %rbp,%rdx
  a39a1b:	mov    0x10(%rsp),%rcx
  a39a20:	call   9c3020 <<gpui::runtime::Runtime<empty::Empty>>::acknowledge>
  a39a25:	mov    0x30(%rsp),%r13
  a39a2a:	mov    0x40(%rsp),%rbp
  a39a2f:	movsd  0x38(%rsp),%xmm0
  a39a35:	movaps %xmm0,0x20(%rsp)
  a39a3a:	mov    0x48(%rsp),%rax
  a39a3f:	mov    %rax,0x10(%rsp)
  a39a44:	mov    0x50(%rsp),%r12
  a39a49:	movups 0x58(%rsp),%xmm0
  a39a4e:	movaps %xmm0,0x1e0(%rsp)
  a39a56:	lea    0x1f0(%rsp),%rdi
  a39a5e:	call   a37130 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  a39a63:	cmp    $0xfffffffffffffffe,%r13
  a39a67:	jne    a399e8 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x618>
  a39a6d:	mov    0x1d0(%r15),%rax
  a39a74:	test   %rax,%rax
  a39a77:	je     a39a8f <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x6bf>
  a39a79:	lock decq (%rax)
  a39a7d:	jne    a39a8f <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x6bf>
  a39a7f:	lea    0x1d0(%r15),%rbp
  a39a86:	mov    %rbp,%rdi
  a39a89:	call   *0xaf3431(%rip)        # 152cec0 <_DYNAMIC+0xb80>
  a39a8f:	mov    %r14,0x1d0(%r15)
  a39a96:	movzwl 0x188(%r15),%eax
  a39a9e:	cmp    $0x2,%eax
  a39aa1:	mov    0x10(%rsp),%r14
  a39aa6:	je     a39ac6 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x6f6>
  a39aa8:	test   %eax,%eax
  a39aaa:	jne    a39aba <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x6ea>
  a39aac:	mov    0x190(%r15),%rdi
  a39ab3:	call   a34fc0 <core::ptr::drop_glue::<alloc::boxed::Box<gpui::native::GpuSurface>>>
  a39ab8:	jmp    a39ac6 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x6f6>
  a39aba:	mov    0x1a8(%r15),%rdi
  a39ac1:	call   a33440 <core::ptr::drop_glue::<softbuffer::Surface<alloc::sync::Arc<winit::window::Window>, alloc::sync::Arc<winit::window::Window>>>>
  a39ac6:	movw   $0x0,0x188(%r15)
  a39ad0:	mov    (%rsp),%rax
  a39ad4:	mov    %rax,0x190(%r15)
  a39adb:	movw   $0x0,0x208(%r15)
  a39ae5:	mov    0x1f0(%r15),%rdi
  a39aec:	test   %rdi,%rdi
  a39aef:	je     a39b0f <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x73f>
  a39af1:	mov    %r14,0x30(%rsp)
  a39af6:	mov    %r12,0x38(%rsp)
  a39afb:	movb   $0x1,0x40(%rsp)
  a39b00:	mov    0x1f8(%r15),%rax
  a39b07:	lea    0x30(%rsp),%rsi
  a39b0c:	call   *0x20(%rax)
  a39b0f:	movb   $0x1,0x8(%rbx)
  a39b13:	jmp    a39641 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x271>
  a39b18:	lea    -0x8a0bc9(%rip),%rdi        # 198f56 <anon.7cc7c74d1b8f8dfb5e74abfe8b727cdb.77.llvm.18220644203745900989+0x762>
  a39b1f:	lea    0xa82822(%rip),%rdx        # 14bc348 <anon.f48bbd6ee32d24e1254dac28089ef4b7.8.llvm.17379179981059708172+0x168>
  a39b26:	mov    $0x14,%esi
  a39b2b:	call   *0xaf2b7f(%rip)        # 152c6b0 <_DYNAMIC+0x370>
  a39b31:	lea    -0x8a0bce(%rip),%rdi        # 198f6a <anon.7cc7c74d1b8f8dfb5e74abfe8b727cdb.77.llvm.18220644203745900989+0x776>
  a39b38:	lea    0xa82821(%rip),%rdx        # 14bc360 <anon.f48bbd6ee32d24e1254dac28089ef4b7.8.llvm.17379179981059708172+0x180>
  a39b3f:	mov    $0x14,%esi
  a39b44:	call   *0xaf2b66(%rip)        # 152c6b0 <_DYNAMIC+0x370>
  a39b4a:	ud2
  a39b4c:	mov    %rax,%rbx
  a39b4f:	mov    %r14,0x0(%rbp)
  a39b53:	xor    %ebp,%ebp
  a39b55:	jmp    a39c6d <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x89d>
  a39b5a:	mov    %rax,%rbx
  a39b5d:	jmp    a39caa <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x8da>
  a39b62:	mov    %rax,%rbx
  a39b65:	movw   $0x0,0x188(%r15)
  a39b6f:	mov    (%rsp),%rax
  a39b73:	mov    %rax,0x190(%r15)
  a39b7a:	jmp    a39caa <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x8da>
  a39b7f:	jmp    a39c67 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x897>
  a39b84:	mov    %rax,%rbx
  a39b87:	mov    0x1f8(%rsp),%rax
  a39b8f:	lock decq (%rax)
  a39b93:	jne    a39bcc <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x7fc>
  a39b95:	lea    0x1f8(%rsp),%rdi
  a39b9d:	call   *0xaf32f5(%rip)        # 152ce98 <_DYNAMIC+0xb58>
  a39ba3:	jmp    a39bcc <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x7fc>
  a39ba5:	call   *0xaf2a1d(%rip)        # 152c5c8 <_DYNAMIC+0x288>
  a39bab:	mov    %rax,%rbx
  a39bae:	jmp    a39bcc <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x7fc>
  a39bb0:	mov    %rax,%rbx
  a39bb3:	lea    0x1f0(%rsp),%rdi
  a39bbb:	call   a37130 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  a39bc0:	mov    $0x1,%bpl
  a39bc3:	test   %r12b,%r12b
  a39bc6:	je     a39c6d <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x89d>
  a39bcc:	mov    $0x1,%bpl
  a39bcf:	lea    0x130(%rsp),%rdi
  a39bd7:	call   a371a0 <core::ptr::drop_glue::<wgpu::api::surface_texture::SurfaceTexture>>
  a39bdc:	jmp    a39c6d <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x89d>
  a39be1:	call   *0xaf29e1(%rip)        # 152c5c8 <_DYNAMIC+0x288>
  a39be7:	jmp    a39c67 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x897>
  a39be9:	mov    %rax,%rbx
  a39bec:	lea    0x30(%rsp),%rdi
  a39bf1:	call   a36f00 <core::ptr::drop_glue::<gpui::native::NativeError>>
  a39bf6:	jmp    a39c7b <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x8ab>
  a39bfb:	mov    %rax,%rbx
  a39bfe:	movq   $0xffffffffffffffff,(%r12)
  a39c06:	test   %r14,%r14
  a39c09:	je     a39caa <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x8da>
  a39c0f:	mov    $0x1,%edx
  a39c14:	mov    %r15,%rdi
  a39c17:	mov    %r14,%rsi
  a39c1a:	call   *0xaf2970(%rip)        # 152c590 <_DYNAMIC+0x250>
  a39c20:	jmp    a39caa <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x8da>
  a39c25:	mov    %rax,%rbx
  a39c28:	movq   $0xffffffffffffffff,(%r12)
  a39c30:	lock decq (%r14)
  a39c34:	jne    a39c44 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x874>
  a39c36:	lea    0x190(%rsp),%rdi
  a39c3e:	call   *0xaf327c(%rip)        # 152cec0 <_DYNAMIC+0xb80>
  a39c44:	mov    0x198(%rsp),%rdi
  a39c4c:	call   a34fc0 <core::ptr::drop_glue::<alloc::boxed::Box<gpui::native::GpuSurface>>>
  a39c51:	jmp    a39caa <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x8da>
  a39c53:	mov    %rax,%rbx
  a39c56:	lea    0x30(%rsp),%rdi
  a39c5b:	call   a36f00 <core::ptr::drop_glue::<gpui::native::NativeError>>
  a39c60:	jmp    a39caa <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x8da>
  a39c62:	mov    %rax,%rbx
  a39c65:	jmp    a39caa <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x8da>
  a39c67:	mov    %rax,%rbx
  a39c6a:	mov    $0x1,%bpl
  a39c6d:	mov    (%rsp),%rdi
  a39c71:	call   a34fc0 <core::ptr::drop_glue::<alloc::boxed::Box<gpui::native::GpuSurface>>>
  a39c76:	test   %bpl,%bpl
  a39c79:	je     a39caa <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x8da>
  a39c7b:	mov    0x18(%rsp),%rax
  a39c80:	lock decq (%rax)
  a39c84:	jne    a39caa <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x8da>
  a39c86:	lea    0x18(%rsp),%rdi
  a39c8b:	call   *0xaf322f(%rip)        # 152cec0 <_DYNAMIC+0xb80>
  a39c91:	jmp    a39caa <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x8da>
  a39c93:	mov    %rax,%rbx
  a39c96:	lock decq (%r14)
  a39c9a:	jne    a39caa <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x8da>
  a39c9c:	lea    0x1f0(%rsp),%rdi
  a39ca4:	call   *0xaf346e(%rip)        # 152d118 <_DYNAMIC+0xdd8>
  a39caa:	mov    0x8(%rsp),%rax
  a39caf:	lock decq (%rax)
  a39cb3:	jne    a39cc0 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x8f0>
  a39cb5:	lea    0x8(%rsp),%rdi
  a39cba:	call   *0xaf3358(%rip)        # 152d018 <_DYNAMIC+0xcd8>
  a39cc0:	mov    %rbx,%rdi
  a39cc3:	call   14b6fa0 <_Unwind_Resume@plt>
  a39cc8:	call   *0xaf28fa(%rip)        # 152c5c8 <_DYNAMIC+0x288>
  a39cce:	call   *0xaf28f4(%rip)        # 152c5c8 <_DYNAMIC+0x288>


/tmp/gpui-a11y-owner-channel-captures/release-baseline/empty:     file format elf64-x86-64


Disassembly of section .text:

0000000000a39ce0 <<gpui::native::NativeHost<empty::Empty>>::input_result>:
  a39ce0:	push   %rbx
  a39ce1:	sub    $0x50,%rsp
  a39ce5:	mov    %rdi,%rbx
  a39ce8:	mov    (%rdx),%rcx
  a39ceb:	cmp    $0xfffffffffffffffe,%rcx
  a39cef:	jne    a39d2f <<gpui::native::NativeHost<empty::Empty>>::input_result+0x4f>
  a39cf1:	cmpq   $0x0,0x8(%rdx)
  a39cf6:	je     a39e03 <<gpui::native::NativeHost<empty::Empty>>::input_result+0x123>
  a39cfc:	cmpb   $0x0,0x204(%rsi)
  a39d03:	jne    a39e03 <<gpui::native::NativeHost<empty::Empty>>::input_result+0x123>
  a39d09:	mov    0x1d8(%rsi),%rdi
  a39d10:	test   %rdi,%rdi
  a39d13:	je     a39e03 <<gpui::native::NativeHost<empty::Empty>>::input_result+0x123>
  a39d19:	add    $0x10,%rdi
  a39d1d:	call   a38a10 <<winit::window::Window>::request_redraw>
  a39d22:	movq   $0xfffffffffffffffe,(%rbx)
  a39d29:	add    $0x50,%rsp
  a39d2d:	pop    %rbx
  a39d2e:	ret
  a39d2f:	sub    $0xd,%rcx
  a39d33:	mov    $0x14,%eax
  a39d38:	cmovge %rcx,%rax
  a39d3c:	cmp    $0x16,%rax
  a39d40:	ja     a39e10 <<gpui::native::NativeHost<empty::Empty>>::input_result+0x130>
  a39d46:	mov    $0x630,%ecx
  a39d4b:	bt     %rax,%rcx
  a39d4f:	jb     a39e03 <<gpui::native::NativeHost<empty::Empty>>::input_result+0x123>
  a39d55:	mov    $0x600008,%ecx
  a39d5a:	bt     %rax,%rcx
  a39d5e:	jae    a39e10 <<gpui::native::NativeHost<empty::Empty>>::input_result+0x130>
  a39d64:	mov    0x30(%rdx),%rax
  a39d68:	mov    %rax,0x40(%rsp)
  a39d6d:	movups (%rdx),%xmm0
  a39d70:	movups 0x10(%rdx),%xmm1
  a39d74:	movups 0x20(%rdx),%xmm2
  a39d78:	movaps %xmm2,0x30(%rsp)
  a39d7d:	movaps %xmm1,0x20(%rsp)
  a39d82:	movaps %xmm0,0x10(%rsp)
  a39d87:	mov    0x1e0(%rsi),%rdi
  a39d8e:	test   %rdi,%rdi
  a39d91:	je     a39da4 <<gpui::native::NativeHost<empty::Empty>>::input_result+0xc4>
  a39d93:	mov    0x1e8(%rsi),%rax
  a39d9a:	lea    0x10(%rsp),%rsi
  a39d9f:	call   *0x20(%rax)
  a39da2:	jmp    a39dc9 <<gpui::native::NativeHost<empty::Empty>>::input_result+0xe9>
  a39da4:	lea    0x10(%rsp),%rax
  a39da9:	mov    %rax,(%rsp)
  a39dad:	mov    0xaf3874(%rip),%rax        # 152d628 <_DYNAMIC+0x12e8>
  a39db4:	mov    %rax,0x8(%rsp)
  a39db9:	lea    -0x8c2f66(%rip),%rdi        # 176e5a <anon.48dd33490292f7cef44ed4fce7549844.8.llvm.6996506099118494405+0x33>
  a39dc0:	mov    %rsp,%rsi
  a39dc3:	call   *0xaf37a7(%rip)        # 152d570 <_DYNAMIC+0x1230>
  a39dc9:	mov    0x10(%rsp),%rcx
  a39dce:	sub    $0xd,%rcx
  a39dd2:	mov    $0x14,%eax
  a39dd7:	cmovge %rcx,%rax
  a39ddb:	cmp    $0x19,%rax
  a39ddf:	je     a39e34 <<gpui::native::NativeHost<empty::Empty>>::input_result+0x154>
  a39de1:	cmp    $0x14,%rax
  a39de5:	jne    a39e03 <<gpui::native::NativeHost<empty::Empty>>::input_result+0x123>
  a39de7:	lea    0x28(%rsp),%rax
  a39dec:	mov    (%rax),%rsi
  a39def:	test   %rsi,%rsi
  a39df2:	je     a39e03 <<gpui::native::NativeHost<empty::Empty>>::input_result+0x123>
  a39df4:	mov    0x8(%rax),%rdi
  a39df8:	mov    $0x1,%edx
  a39dfd:	call   *0xaf278d(%rip)        # 152c590 <_DYNAMIC+0x250>
  a39e03:	movq   $0xfffffffffffffffe,(%rbx)
  a39e0a:	add    $0x50,%rsp
  a39e0e:	pop    %rbx
  a39e0f:	ret
  a39e10:	mov    0x30(%rdx),%rax
  a39e14:	mov    %rax,0x30(%rbx)
  a39e18:	movups (%rdx),%xmm0
  a39e1b:	movups 0x10(%rdx),%xmm1
  a39e1f:	movups 0x20(%rdx),%xmm2
  a39e23:	movups %xmm2,0x20(%rbx)
  a39e27:	movups %xmm1,0x10(%rbx)
  a39e2b:	movups %xmm0,(%rbx)
  a39e2e:	add    $0x50,%rsp
  a39e32:	pop    %rbx
  a39e33:	ret
  a39e34:	lea    0x18(%rsp),%rax
  a39e39:	mov    (%rax),%rsi
  a39e3c:	test   %rsi,%rsi
  a39e3f:	jne    a39df4 <<gpui::native::NativeHost<empty::Empty>>::input_result+0x114>
  a39e41:	jmp    a39e03 <<gpui::native::NativeHost<empty::Empty>>::input_result+0x123>
  a39e43:	mov    %rax,%rbx
  a39e46:	lea    0x10(%rsp),%rdi
  a39e4b:	call   a36fa0 <core::ptr::drop_glue::<gpui::runtime::Error>>
  a39e50:	mov    %rbx,%rdi
  a39e53:	call   14b6fa0 <_Unwind_Resume@plt>


/tmp/gpui-a11y-owner-channel-captures/release-baseline/empty:     file format elf64-x86-64


Disassembly of section .text:

0000000000a39e60 <<gpui::native::NativeHost<empty::Empty>>::retire_window>:
  a39e60:	push   %r15
  a39e62:	push   %r14
  a39e64:	push   %rbx
  a39e65:	mov    %rdi,%rbx
  a39e68:	mov    0x1d8(%rdi),%rdi
  a39e6f:	test   %rdi,%rdi
  a39e72:	je     a39e7f <<gpui::native::NativeHost<empty::Empty>>::retire_window+0x1f>
  a39e74:	add    $0x10,%rdi
  a39e78:	xor    %esi,%esi
  a39e7a:	call   a3bd90 <<winit::window::Window>::set_visible>
  a39e7f:	lea    0xe0(%rbx),%r15
  a39e86:	mov    %r15,%rdi
  a39e89:	call   a34700 <core::ptr::drop_glue::<core::option::Option<gpui::native::upgrade::Upgrade>>>
  a39e8e:	movq   $0xffffffffffffffff,0xe0(%rbx)
  a39e99:	lea    0x10(%rbx),%r15
  a39e9d:	mov    %r15,%rdi
  a39ea0:	call   a345d0 <core::ptr::drop_glue::<core::option::Option<gpui::native::accessibility::Bridge>>>
  a39ea5:	movq   $0xffffffffffffffff,0x10(%rbx)
  a39ead:	mov    (%rbx),%eax
  a39eaf:	mov    0x8(%rbx),%r15
  a39eb3:	movq   $0x0,(%rbx)
  a39eba:	cmp    $0x1,%eax
  a39ebd:	jne    a39ee6 <<gpui::native::NativeHost<empty::Empty>>::retire_window+0x86>
  a39ebf:	test   %r15,%r15
  a39ec2:	je     a39edf <<gpui::native::NativeHost<empty::Empty>>::retire_window+0x7f>
  a39ec4:	mov    %r15,%rdi
  a39ec7:	call   9afbb0 <core::ptr::drop_glue::<gpui::runtime::Runtime<empty::Empty>>>
  a39ecc:	mov    $0x730,%esi
  a39ed1:	mov    $0x8,%edx
  a39ed6:	mov    %r15,%rdi
  a39ed9:	call   *0xaf26b1(%rip)        # 152c590 <_DYNAMIC+0x250>
  a39edf:	xor    %edi,%edi
  a39ee1:	call   a35160 <core::ptr::drop_glue::<gpui::runtime::Win<empty::Empty>>>
  a39ee6:	movzwl 0x188(%rbx),%eax
  a39eed:	cmp    $0x2,%eax
  a39ef0:	je     a39f10 <<gpui::native::NativeHost<empty::Empty>>::retire_window+0xb0>
  a39ef2:	test   %eax,%eax
  a39ef4:	jne    a39f04 <<gpui::native::NativeHost<empty::Empty>>::retire_window+0xa4>
  a39ef6:	mov    0x190(%rbx),%rdi
  a39efd:	call   a34fc0 <core::ptr::drop_glue::<alloc::boxed::Box<gpui::native::GpuSurface>>>
  a39f02:	jmp    a39f10 <<gpui::native::NativeHost<empty::Empty>>::retire_window+0xb0>
  a39f04:	mov    0x1a8(%rbx),%rdi
  a39f0b:	call   a33440 <core::ptr::drop_glue::<softbuffer::Surface<alloc::sync::Arc<winit::window::Window>, alloc::sync::Arc<winit::window::Window>>>>
  a39f10:	movw   $0x2,0x188(%rbx)
  a39f19:	lea    0x1d0(%rbx),%r15
  a39f20:	mov    0x1d0(%rbx),%rax
  a39f27:	test   %rax,%rax
  a39f2a:	je     a39f3b <<gpui::native::NativeHost<empty::Empty>>::retire_window+0xdb>
  a39f2c:	lock decq (%rax)
  a39f30:	jne    a39f3b <<gpui::native::NativeHost<empty::Empty>>::retire_window+0xdb>
  a39f32:	mov    %r15,%rdi
  a39f35:	call   *0xaf2f85(%rip)        # 152cec0 <_DYNAMIC+0xb80>
  a39f3b:	add    $0x1d8,%rbx
  a39f42:	movq   $0x0,(%r15)
  a39f49:	mov    (%rbx),%rax
  a39f4c:	test   %rax,%rax
  a39f4f:	je     a39f60 <<gpui::native::NativeHost<empty::Empty>>::retire_window+0x100>
  a39f51:	lock decq (%rax)
  a39f55:	jne    a39f60 <<gpui::native::NativeHost<empty::Empty>>::retire_window+0x100>
  a39f57:	mov    %rbx,%rdi
  a39f5a:	call   *0xaf30b8(%rip)        # 152d018 <_DYNAMIC+0xcd8>
  a39f60:	movq   $0x0,(%rbx)
  a39f67:	pop    %rbx
  a39f68:	pop    %r14
  a39f6a:	pop    %r15
  a39f6c:	ret
  a39f6d:	movq   $0x0,(%rbx)
  a39f74:	mov    %rax,%rdi
  a39f77:	call   14b6fa0 <_Unwind_Resume@plt>
  a39f7c:	movq   $0x0,(%r15)
  a39f83:	mov    %rax,%rdi
  a39f86:	call   14b6fa0 <_Unwind_Resume@plt>
  a39f8b:	mov    %rax,%r14
  a39f8e:	mov    $0x730,%esi
  a39f93:	mov    $0x8,%edx
  a39f98:	mov    %r15,%rdi
  a39f9b:	call   *0xaf25ef(%rip)        # 152c590 <_DYNAMIC+0x250>
  a39fa1:	xor    %edi,%edi
  a39fa3:	call   a35160 <core::ptr::drop_glue::<gpui::runtime::Win<empty::Empty>>>
  a39fa8:	jmp    a39fbc <<gpui::native::NativeHost<empty::Empty>>::retire_window+0x15c>
  a39faa:	call   *0xaf2618(%rip)        # 152c5c8 <_DYNAMIC+0x288>
  a39fb0:	mov    %rax,%r14
  a39fb3:	movw   $0x2,0x188(%rbx)
  a39fbc:	mov    %r14,%rdi
  a39fbf:	call   14b6fa0 <_Unwind_Resume@plt>
  a39fc4:	movq   $0xffffffffffffffff,(%r15)
  a39fcb:	mov    %rax,%rdi
  a39fce:	call   14b6fa0 <_Unwind_Resume@plt>
  a39fd3:	movq   $0xffffffffffffffff,(%r15)
  a39fda:	mov    %rax,%rdi
  a39fdd:	call   14b6fa0 <_Unwind_Resume@plt>


/tmp/gpui-a11y-owner-channel-captures/release-baseline/empty:     file format elf64-x86-64


Disassembly of section .text:

0000000000a39ff0 <<gpui::native::NativeHost<empty::Empty>>::start_upgrade>:
  a39ff0:	push   %r15
  a39ff2:	push   %r14
  a39ff4:	push   %rbx
  a39ff5:	sub    $0x40,%rsp
  a39ff9:	cmpb   $0x0,0x207(%rdi)
  a3a000:	jne    a3a125 <<gpui::native::NativeHost<empty::Empty>>::start_upgrade+0x135>
  a3a006:	mov    %rdi,%rbx
  a3a009:	cmpb   $0x0,0x206(%rdi)
  a3a010:	jne    a3a125 <<gpui::native::NativeHost<empty::Empty>>::start_upgrade+0x135>
  a3a016:	movb   $0x1,0x206(%rbx)
  a3a01d:	cmpq   $0x0,0x1d8(%rbx)
  a3a025:	je     a3a125 <<gpui::native::NativeHost<empty::Empty>>::start_upgrade+0x135>
  a3a02b:	mov    0xc0(%rbx),%rax
  a3a032:	cmp    $0xffffffffffffffff,%rax
  a3a036:	je     a3a09b <<gpui::native::NativeHost<empty::Empty>>::start_upgrade+0xab>
  a3a038:	mov    0xd8(%rbx),%r15
  a3a03f:	lock incq (%r15)
  a3a043:	jle    a3a143 <<gpui::native::NativeHost<empty::Empty>>::start_upgrade+0x153>
  a3a049:	mov    %r15,(%rsp)
  a3a04d:	mov    0xc8(%rbx),%rcx
  a3a054:	test   %rax,%rax
  a3a057:	je     a3a12f <<gpui::native::NativeHost<empty::Empty>>::start_upgrade+0x13f>
  a3a05d:	cmp    $0x1,%eax
  a3a060:	jne    a3a145 <<gpui::native::NativeHost<empty::Empty>>::start_upgrade+0x155>
  a3a066:	lock incq 0x180(%rcx)
  a3a06e:	jle    a3a13d <<gpui::native::NativeHost<empty::Empty>>::start_upgrade+0x14d>
  a3a074:	mov    0xd0(%rbx),%rdx
  a3a07b:	lock incq (%rdx)
  a3a07f:	jle    a3a143 <<gpui::native::NativeHost<empty::Empty>>::start_upgrade+0x153>
  a3a085:	mov    %rax,0x20(%rsp)
  a3a08a:	mov    %rcx,0x28(%rsp)
  a3a08f:	mov    %rdx,0x30(%rsp)
  a3a094:	mov    %r15,0x38(%rsp)
  a3a099:	jmp    a3a0a4 <<gpui::native::NativeHost<empty::Empty>>::start_upgrade+0xb4>
  a3a09b:	movq   $0xffffffffffffffff,0x20(%rsp)
  a3a0a4:	lea    0x1d8(%rbx),%rsi
  a3a0ab:	lea    0x8(%rsp),%rdi
  a3a0b0:	lea    0x20(%rsp),%rdx
  a3a0b5:	call   *0xaf3575(%rip)        # 152d630 <_DYNAMIC+0x12f0>
  a3a0bb:	mov    0x8(%rsp),%rax
  a3a0c0:	cmp    $0xffffffffffffffff,%rax
  a3a0c4:	je     a3a125 <<gpui::native::NativeHost<empty::Empty>>::start_upgrade+0x135>
  a3a0c6:	cmp    $0xfffffffe,%eax
  a3a0c9:	jne    a3a105 <<gpui::native::NativeHost<empty::Empty>>::start_upgrade+0x115>
  a3a0cb:	mov    0x10(%rsp),%rax
  a3a0d0:	mov    %rax,(%rsp)
  a3a0d4:	mov    %rsp,%rax
  a3a0d7:	mov    %rax,0x20(%rsp)
  a3a0dc:	mov    0xaf3555(%rip),%rax        # 152d638 <_DYNAMIC+0x12f8>
  a3a0e3:	mov    %rax,0x28(%rsp)
  a3a0e8:	lea    -0x8b8111(%rip),%rdi        # 181fde <anon.f14fc1a2f79f716d98413553529a74dd.437.llvm.2503939890947331820+0x26e>
  a3a0ef:	lea    0x20(%rsp),%rsi
  a3a0f4:	call   *0xaf3476(%rip)        # 152d570 <_DYNAMIC+0x1230>
  a3a0fa:	mov    (%rsp),%rdi
  a3a0fe:	call   a37080 <core::ptr::drop_glue::<std::io::error::Error>>
  a3a103:	jmp    a3a125 <<gpui::native::NativeHost<empty::Empty>>::start_upgrade+0x135>
  a3a105:	add    $0xe0,%rbx
  a3a10c:	mov    %rbx,%rdi
  a3a10f:	call   a34700 <core::ptr::drop_glue::<core::option::Option<gpui::native::upgrade::Upgrade>>>
  a3a114:	mov    0x18(%rsp),%rax
  a3a119:	mov    %rax,0x10(%rbx)
  a3a11d:	movups 0x8(%rsp),%xmm0
  a3a122:	movups %xmm0,(%rbx)
  a3a125:	add    $0x40,%rsp
  a3a129:	pop    %rbx
  a3a12a:	pop    %r14
  a3a12c:	pop    %r15
  a3a12e:	ret
  a3a12f:	lock incq 0x200(%rcx)
  a3a137:	jg     a3a074 <<gpui::native::NativeHost<empty::Empty>>::start_upgrade+0x84>
  a3a13d:	call   *0xaf2eb5(%rip)        # 152cff8 <_DYNAMIC+0xcb8>
  a3a143:	ud2
  a3a145:	lock incq 0x70(%rcx)
  a3a14a:	jg     a3a074 <<gpui::native::NativeHost<empty::Empty>>::start_upgrade+0x84>
  a3a150:	jmp    a3a13d <<gpui::native::NativeHost<empty::Empty>>::start_upgrade+0x14d>
  a3a152:	mov    %rax,%r14
  a3a155:	mov    0x18(%rsp),%rax
  a3a15a:	mov    %rax,0x10(%rbx)
  a3a15e:	movups 0x8(%rsp),%xmm0
  a3a163:	movups %xmm0,(%rbx)
  a3a166:	mov    %r14,%rdi
  a3a169:	call   14b6fa0 <_Unwind_Resume@plt>
  a3a16e:	mov    %rax,%r14
  a3a171:	mov    (%rsp),%rdi
  a3a175:	call   a37080 <core::ptr::drop_glue::<std::io::error::Error>>
  a3a17a:	jmp    a3a194 <<gpui::native::NativeHost<empty::Empty>>::start_upgrade+0x1a4>
  a3a17c:	call   *0xaf2446(%rip)        # 152c5c8 <_DYNAMIC+0x288>
  a3a182:	mov    %rax,%r14
  a3a185:	lock decq (%r15)
  a3a189:	jne    a3a194 <<gpui::native::NativeHost<empty::Empty>>::start_upgrade+0x1a4>
  a3a18b:	mov    %rsp,%rdi
  a3a18e:	call   *0xaf2f84(%rip)        # 152d118 <_DYNAMIC+0xdd8>
  a3a194:	mov    %r14,%rdi
  a3a197:	call   14b6fa0 <_Unwind_Resume@plt>
  a3a19c:	call   *0xaf2426(%rip)        # 152c5c8 <_DYNAMIC+0x288>


/tmp/gpui-a11y-owner-channel-captures/release-baseline/empty:     file format elf64-x86-64


Disassembly of section .text:

0000000000a3a1b0 <<gpui::native::NativeHost<empty::Empty>>::create_surface>:
  a3a1b0:	push   %rbp
  a3a1b1:	push   %r15
  a3a1b3:	push   %r14
  a3a1b5:	push   %r13
  a3a1b7:	push   %r12
  a3a1b9:	push   %rbx
  a3a1ba:	sub    $0xa48,%rsp
  a3a1c1:	mov    %rdi,%rbx
  a3a1c4:	mov    0x1d8(%rsi),%r15
  a3a1cb:	test   %r15,%r15
  a3a1ce:	je     a3a414 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x264>
  a3a1d4:	mov    %rsi,%r14
  a3a1d7:	cmpb   $0x1,0x207(%rsi)
  a3a1de:	jne    a3a420 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x270>
  a3a1e4:	cmpq   $0x0,0x1d0(%r14)
  a3a1ec:	jne    a3a254 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0xa4>
  a3a1ee:	lock incq (%r15)
  a3a1f2:	jle    a3aa7b <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x8cb>
  a3a1f8:	mov    %r15,0x140(%rsp)
  a3a200:	call   *0xaf237a(%rip)        # 152c580 <_DYNAMIC+0x240>
  a3a206:	mov    $0x8,%edi
  a3a20b:	mov    $0x8,%esi
  a3a210:	call   *0xaf2372(%rip)        # 152c588 <_DYNAMIC+0x248>
  a3a216:	test   %rax,%rax
  a3a219:	je     a3aa0b <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x85b>
  a3a21f:	mov    %r15,(%rax)
  a3a222:	lea    0xa81f47(%rip),%rdx        # 14bc170 <anon.f48bbd6ee32d24e1254dac28089ef4b7.0.llvm.17379179981059708172+0x48>
  a3a229:	lea    0x140(%rsp),%r15
  a3a231:	mov    %r15,%rdi
  a3a234:	mov    %rax,%rsi
  a3a237:	call   *0xaf3403(%rip)        # 152d640 <_DYNAMIC+0x1300>
  a3a23d:	mov    %r15,%rdi
  a3a240:	call   *0xaf3402(%rip)        # 152d648 <_DYNAMIC+0x1308>
  a3a246:	mov    %rax,0x1d0(%r14)
  a3a24d:	mov    0x1d8(%r14),%r15
  a3a254:	lock incq (%r15)
  a3a258:	jle    a3aa7b <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x8cb>
  a3a25e:	lea    0x1d0(%r14),%r15
  a3a265:	mov    0x1d8(%r14),%rdx
  a3a26c:	lea    0x140(%rsp),%rdi
  a3a274:	mov    %r15,%rsi
  a3a277:	call   a00630 <<wgpu::api::instance::Instance>::create_surface::<alloc::sync::Arc<winit::window::Window>>>
  a3a27c:	mov    0x140(%rsp),%rax
  a3a284:	test   %rax,%rax
  a3a287:	je     a3a43c <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x28c>
  a3a28d:	mov    0x148(%rsp),%rcx
  a3a295:	movups 0x150(%rsp),%xmm0
  a3a29d:	movaps %xmm0,0x40(%rsp)
  a3a2a2:	mov    0x160(%rsp),%rdx
  a3a2aa:	movups 0x168(%rsp),%xmm1
  a3a2b2:	movups %xmm1,0xe8(%rsp)
  a3a2ba:	mov    0x178(%rsp),%rsi
  a3a2c2:	mov    %rsi,0xf8(%rsp)
  a3a2ca:	movups 0x180(%rsp),%xmm1
  a3a2d2:	movups %xmm1,0x100(%rsp)
  a3a2da:	movups 0x190(%rsp),%xmm1
  a3a2e2:	movups %xmm1,0x110(%rsp)
  a3a2ea:	movaps %xmm0,0x120(%rsp)
  a3a2f2:	mov    %rdx,0x130(%rsp)
  a3a2fa:	mov    %rdx,0xe0(%rsp)
  a3a302:	movups %xmm0,0xd0(%rsp)
  a3a30a:	mov    %rax,0xc0(%rsp)
  a3a312:	mov    %rcx,0xc8(%rsp)
  a3a31a:	movl   $0x0,0x10(%rsp)
  a3a322:	movb   $0x0,0x14(%rsp)
  a3a327:	lea    0xc0(%rsp),%rax
  a3a32f:	mov    %rax,0x18(%rsp)
  a3a334:	movb   $0x0,0x20(%rsp)
  a3a339:	lea    0x140(%rsp),%rdi
  a3a341:	lea    0x10(%rsp),%rdx
  a3a346:	mov    %r15,%rsi
  a3a349:	call   *0xaf3301(%rip)        # 152d650 <_DYNAMIC+0x1310>
  a3a34f:	lea    0x6d0(%rsp),%rdi
  a3a357:	lea    0x140(%rsp),%rsi
  a3a35f:	call   a0e5b0 <pollster::block_on::<<wgpu::api::instance::Instance>::request_adapter::{closure#0}>>
  a3a364:	cmpl   $0x1,0x6d0(%rsp)
  a3a36c:	jne    a3a536 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x386>
  a3a372:	movups 0x6d4(%rsp),%xmm0
  a3a37a:	movups 0x6e0(%rsp),%xmm1
  a3a382:	movups %xmm1,0x14c(%rsp)
  a3a38a:	movaps %xmm0,0x140(%rsp)
  a3a392:	movq   $0x0,0x58(%rsp)
  a3a39b:	movq   $0x1,0x60(%rsp)
  a3a3a4:	movq   $0x0,0x68(%rsp)
  a3a3ad:	movq   $0x60000020,0x540(%rsp)
  a3a3b9:	lea    0x58(%rsp),%rax
  a3a3be:	mov    %rax,0x530(%rsp)
  a3a3c6:	lea    0xa82063(%rip),%rax        # 14bc430 <anon.f48bbd6ee32d24e1254dac28089ef4b7.58.llvm.17379179981059708172>
  a3a3cd:	mov    %rax,0x538(%rsp)
  a3a3d5:	lea    0x140(%rsp),%rdi
  a3a3dd:	lea    0x530(%rsp),%rsi
  a3a3e5:	call   *0xaf326d(%rip)        # 152d658 <_DYNAMIC+0x1318>
  a3a3eb:	test   %al,%al
  a3a3ed:	jne    a3aa44 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x894>
  a3a3f3:	lea    0x60(%rsp),%rax
  a3a3f8:	mov    0x58(%rsp),%rcx
  a3a3fd:	movups (%rax),%xmm0
  a3a400:	movups %xmm0,0x10(%rbx)
  a3a404:	movq   $0x2d,(%rbx)
  a3a40b:	mov    %rcx,0x8(%rbx)
  a3a40f:	jmp    a3a657 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x4a7>
  a3a414:	movq   $0xfffffffffffffffe,(%rbx)
  a3a41b:	jmp    a3a6af <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x4ff>
  a3a420:	mov    %rbx,%rdi
  a3a423:	mov    %r14,%rsi
  a3a426:	add    $0xa48,%rsp
  a3a42d:	pop    %rbx
  a3a42e:	pop    %r12
  a3a430:	pop    %r13
  a3a432:	pop    %r14
  a3a434:	pop    %r15
  a3a436:	pop    %rbp
  a3a437:	jmp    a3abb0 <<gpui::native::NativeHost<empty::Empty>>::create_cpu_surface>
  a3a43c:	movups 0x148(%rsp),%xmm0
  a3a444:	movups 0x158(%rsp),%xmm1
  a3a44c:	movups 0x168(%rsp),%xmm2
  a3a454:	movaps %xmm2,0x6f0(%rsp)
  a3a45c:	movaps %xmm1,0x6e0(%rsp)
  a3a464:	movaps %xmm0,0x6d0(%rsp)
  a3a46c:	movq   $0x0,0x58(%rsp)
  a3a475:	movq   $0x1,0x60(%rsp)
  a3a47e:	movq   $0x0,0x68(%rsp)
  a3a487:	movq   $0x60000020,0x540(%rsp)
  a3a493:	lea    0x58(%rsp),%rax
  a3a498:	mov    %rax,0x530(%rsp)
  a3a4a0:	lea    0xa81f89(%rip),%rax        # 14bc430 <anon.f48bbd6ee32d24e1254dac28089ef4b7.58.llvm.17379179981059708172>
  a3a4a7:	mov    %rax,0x538(%rsp)
  a3a4af:	lea    0x6d0(%rsp),%rdi
  a3a4b7:	lea    0x530(%rsp),%rsi
  a3a4bf:	call   *0xaf319b(%rip)        # 152d660 <_DYNAMIC+0x1320>
  a3a4c5:	test   %al,%al
  a3a4c7:	jne    a3aa1d <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x86d>
  a3a4cd:	mov    0x68(%rsp),%rax
  a3a4d2:	mov    %rax,0x20(%rsp)
  a3a4d7:	movups 0x58(%rsp),%xmm0
  a3a4dc:	movaps %xmm0,0x10(%rsp)
  a3a4e1:	movzbl 0x6d0(%rsp),%eax
  a3a4e9:	lea    -0x3(%rax),%rdx
  a3a4ed:	xor    %ecx,%ecx
  a3a4ef:	cmp    $0x4,%rax
  a3a4f3:	cmovae %rdx,%rcx
  a3a4f7:	cmp    $0x1,%rcx
  a3a4fb:	je     a3a666 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x4b6>
  a3a501:	test   %rcx,%rcx
  a3a504:	jne    a3a686 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x4d6>
  a3a50a:	cmp    $0x1,%al
  a3a50c:	jne    a3a686 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x4d6>
  a3a512:	lea    0x6d8(%rsp),%rdi
  a3a51a:	lea    0x6f8(%rsp),%rsi
  a3a522:	mov    $0x30,%edx
  a3a527:	mov    $0x10,%ecx
  a3a52c:	call   a0a930 <<hashbrown::raw::RawTableInner>::drop_inner_table::<(wgpu_types::backend::Backend, wgpu_hal::InstanceError), hashbrown::alloc::inner::Global>>
  a3a531:	jmp    a3a686 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x4d6>
  a3a536:	mov    0x6d8(%rsp),%rax
  a3a53e:	mov    %rax,0x40(%rsp)
  a3a543:	lea    0x58(%rsp),%rdi
  a3a548:	lea    0xc0(%rsp),%rsi
  a3a550:	lea    0x40(%rsp),%r13
  a3a555:	mov    %r13,%rdx
  a3a558:	call   *0xaf310a(%rip)        # 152d668 <_DYNAMIC+0x1328>
  a3a55e:	mov    0x60(%rsp),%r15
  a3a563:	mov    0x68(%rsp),%rax
  a3a568:	test   %rax,%rax
  a3a56b:	je     a3a5b4 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x404>
  a3a56d:	shl    $0x2,%rax
  a3a571:	lea    (%rax,%rax,2),%rax
  a3a575:	xor    %ecx,%ecx
  a3a577:	nopw   0x0(%rax,%rax,1)
  a3a580:	cmpl   $0x1b,(%r15,%rcx,1)
  a3a585:	je     a3a6c1 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x511>
  a3a58b:	add    $0xc,%rcx
  a3a58f:	cmp    %rcx,%rax
  a3a592:	jne    a3a580 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x3d0>
  a3a594:	xor    %ecx,%ecx
  a3a596:	cs nopw 0x0(%rax,%rax,1)
  a3a5a0:	cmpl   $0x16,(%r15,%rcx,1)
  a3a5a5:	je     a3a6c8 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x518>
  a3a5ab:	add    $0xc,%rcx
  a3a5af:	cmp    %rcx,%rax
  a3a5b2:	jne    a3a5a0 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x3f0>
  a3a5b4:	movq   $0x2e,(%rbx)
  a3a5bb:	mov    0x58(%rsp),%rax
  a3a5c0:	test   %rax,%rax
  a3a5c3:	je     a3a5db <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x42b>
  a3a5c5:	shl    $0x2,%rax
  a3a5c9:	lea    (%rax,%rax,2),%rsi
  a3a5cd:	mov    $0x4,%edx
  a3a5d2:	mov    %r15,%rdi
  a3a5d5:	call   *0xaf1fb5(%rip)        # 152c590 <_DYNAMIC+0x250>
  a3a5db:	mov    0x70(%rsp),%rsi
  a3a5e0:	test   %rsi,%rsi
  a3a5e3:	je     a3a5f9 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x449>
  a3a5e5:	mov    0x78(%rsp),%rdi
  a3a5ea:	shl    $0x4,%rsi
  a3a5ee:	mov    $0x4,%edx
  a3a5f3:	call   *0xaf1f97(%rip)        # 152c590 <_DYNAMIC+0x250>
  a3a5f9:	mov    0x88(%rsp),%rsi
  a3a601:	test   %rsi,%rsi
  a3a604:	je     a3a61d <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x46d>
  a3a606:	mov    0x90(%rsp),%rdi
  a3a60e:	shl    $0x2,%rsi
  a3a612:	mov    $0x4,%edx
  a3a617:	call   *0xaf1f73(%rip)        # 152c590 <_DYNAMIC+0x250>
  a3a61d:	mov    0xa0(%rsp),%rsi
  a3a625:	test   %rsi,%rsi
  a3a628:	je     a3a641 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x491>
  a3a62a:	mov    0xa8(%rsp),%rdi
  a3a632:	shl    $0x2,%rsi
  a3a636:	mov    $0x4,%edx
  a3a63b:	call   *0xaf1f4f(%rip)        # 152c590 <_DYNAMIC+0x250>
  a3a641:	mov    0x40(%rsp),%rax
  a3a646:	lock decq (%rax)
  a3a64a:	jne    a3a657 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x4a7>
  a3a64c:	lea    0x40(%rsp),%rdi
  a3a651:	call   *0xaf2871(%rip)        # 152cec8 <_DYNAMIC+0xb88>
  a3a657:	lea    0xc0(%rsp),%rdi
  a3a65f:	call   a37280 <core::ptr::drop_glue::<wgpu::api::surface::Surface>>
  a3a664:	jmp    a3a6af <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x4ff>
  a3a666:	mov    0x6d8(%rsp),%rsi
  a3a66e:	test   %rsi,%rsi
  a3a671:	je     a3a686 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x4d6>
  a3a673:	mov    0x6e0(%rsp),%rdi
  a3a67b:	mov    $0x1,%edx
  a3a680:	call   *0xaf1f0a(%rip)        # 152c590 <_DYNAMIC+0x250>
  a3a686:	mov    0x20(%rsp),%rax
  a3a68b:	movaps 0x10(%rsp),%xmm0
  a3a690:	movaps %xmm0,0x120(%rsp)
  a3a698:	mov    %rax,0x130(%rsp)
  a3a6a0:	mov    %rax,0x18(%rbx)
  a3a6a4:	movups %xmm0,0x8(%rbx)
  a3a6a8:	movq   $0x2d,(%rbx)
  a3a6af:	add    $0xa48,%rsp
  a3a6b6:	pop    %rbx
  a3a6b7:	pop    %r12
  a3a6b9:	pop    %r13
  a3a6bb:	pop    %r14
  a3a6bd:	pop    %r15
  a3a6bf:	pop    %rbp
  a3a6c0:	ret
  a3a6c1:	mov    $0x1b,%ebp
  a3a6c6:	jmp    a3a6cd <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x51d>
  a3a6c8:	mov    $0x16,%ebp
  a3a6cd:	movq   $0x2e,0x140(%rsp)
  a3a6d9:	lea    0x140(%rsp),%rdi
  a3a6e1:	call   a36f00 <core::ptr::drop_glue::<gpui::native::NativeError>>
  a3a6e6:	mov    0xa8(%rsp),%r12
  a3a6ee:	mov    0xb0(%rsp),%rax
  a3a6f6:	shl    $0x2,%rax
  a3a6fa:	xor    %ecx,%ecx
  a3a6fc:	nopl   0x0(%rax)
  a3a700:	cmp    %rcx,%rax
  a3a703:	je     a3a5b4 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x404>
  a3a709:	cmpl   $0x1,(%r12,%rcx,1)
  a3a70e:	lea    0x4(%rcx),%rcx
  a3a712:	jne    a3a700 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x550>
  a3a714:	mov    %r13,0x530(%rsp)
  a3a71c:	mov    %ebp,0x6c0(%rsp)
  a3a723:	movb   $0x0,0x6cc(%rsp)
  a3a72b:	lea    0x140(%rsp),%rdi
  a3a733:	lea    0x530(%rsp),%rsi
  a3a73b:	call   a0d410 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>>
  a3a740:	mov    0x140(%rsp),%r13
  a3a748:	movups 0x148(%rsp),%xmm0
  a3a750:	movaps %xmm0,0x10(%rsp)
  a3a755:	movups 0x158(%rsp),%xmm0
  a3a75d:	movaps %xmm0,0x20(%rsp)
  a3a762:	cmp    $0xffffffffffffffff,%r13
  a3a766:	je     a3a7e5 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x635>
  a3a768:	lea    0x168(%rsp),%rsi
  a3a770:	lea    0x6f8(%rsp),%rdi
  a3a778:	mov    $0x350,%edx
  a3a77d:	call   *0xaf1e1d(%rip)        # 152c5a0 <memcpy@GLIBC_2.14>
  a3a783:	movaps 0x10(%rsp),%xmm0
  a3a788:	movaps 0x20(%rsp),%xmm1
  a3a78d:	movups %xmm0,0x6d8(%rsp)
  a3a795:	movups %xmm1,0x6e8(%rsp)
  a3a79d:	mov    %r13,0x6d0(%rsp)
  a3a7a5:	cmpl   $0xffffffff,0xc0(%r14)
  a3a7ad:	je     a3a811 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x661>
  a3a7af:	lea    0xc0(%r14),%rsi
  a3a7b6:	lea    0x140(%rsp),%rdi
  a3a7be:	call   a3c2f0 <<gpui_reactivity_host::native::Wake as core::clone::Clone>::clone>
  a3a7c3:	movups 0x140(%rsp),%xmm0
  a3a7cb:	movups 0x150(%rsp),%xmm1
  a3a7d3:	movaps %xmm1,0x540(%rsp)
  a3a7db:	movaps %xmm0,0x530(%rsp)
  a3a7e3:	jmp    a3a81d <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x66d>
  a3a7e5:	movaps 0x10(%rsp),%xmm0
  a3a7ea:	movaps 0x20(%rsp),%xmm1
  a3a7ef:	movups %xmm1,0x18(%rbx)
  a3a7f3:	movups %xmm0,0x8(%rbx)
  a3a7f7:	movq   $0x2c,(%rbx)
  a3a7fe:	mov    0x58(%rsp),%rax
  a3a803:	test   %rax,%rax
  a3a806:	jne    a3a5c5 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x415>
  a3a80c:	jmp    a3a5db <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x42b>
  a3a811:	movq   $0xffffffffffffffff,0x530(%rsp)
  a3a81d:	lea    0xa18(%rsp),%rdi
  a3a825:	lea    0x530(%rsp),%rsi
  a3a82d:	call   *0xaf2e3d(%rip)        # 152d670 <_DYNAMIC+0x1330>
  a3a833:	mov    %rax,%rbp
  a3a836:	mov    %rax,0x10(%rsp)
  a3a83b:	mov    0x1d8(%r14),%rdi
  a3a842:	add    $0x10,%rdi
  a3a846:	call   a3bc10 <<winit::window::Window>::inner_size>
  a3a84b:	mov    %eax,0x3c(%rsp)
  a3a84f:	mov    %edx,%r13d
  a3a852:	movups 0x110(%rsp),%xmm0
  a3a85a:	movups %xmm0,0x508(%rsp)
  a3a862:	movups 0x100(%rsp),%xmm0
  a3a86a:	movups %xmm0,0x4f8(%rsp)
  a3a872:	movups 0xc0(%rsp),%xmm0
  a3a87a:	movups 0xd0(%rsp),%xmm1
  a3a882:	movups 0xe0(%rsp),%xmm2
  a3a88a:	movups 0xf0(%rsp),%xmm3
  a3a892:	movups %xmm3,0x4e8(%rsp)
  a3a89a:	movups %xmm2,0x4d8(%rsp)
  a3a8a2:	movups %xmm1,0x4c8(%rsp)
  a3a8aa:	movups %xmm0,0x4b8(%rsp)
  a3a8b2:	lea    0x140(%rsp),%rdi
  a3a8ba:	lea    0x6d0(%rsp),%rsi
  a3a8c2:	mov    $0x378,%edx
  a3a8c7:	call   *0xaf1cd3(%rip)        # 152c5a0 <memcpy@GLIBC_2.14>
  a3a8cd:	mov    %rbp,0x518(%rsp)
  a3a8d5:	movq   $0x0,0x520(%rsp)
  a3a8e1:	call   *0xaf1c99(%rip)        # 152c580 <_DYNAMIC+0x240>
  a3a8e7:	mov    $0x3f0,%edi
  a3a8ec:	mov    $0x8,%esi
  a3a8f1:	call   *0xaf1c91(%rip)        # 152c588 <_DYNAMIC+0x248>
  a3a8f7:	test   %rax,%rax
  a3a8fa:	je     a3aa6b <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x8bb>
  a3a900:	mov    %rax,%rbp
  a3a903:	lea    0x140(%rsp),%rsi
  a3a90b:	mov    $0x3f0,%edx
  a3a910:	mov    %rax,%rdi
  a3a913:	call   *0xaf1c87(%rip)        # 152c5a0 <memcpy@GLIBC_2.14>
  a3a919:	movzwl 0x188(%r14),%eax
  a3a921:	cmp    $0x2,%eax
  a3a924:	je     a3a944 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x794>
  a3a926:	test   %eax,%eax
  a3a928:	jne    a3a938 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x788>
  a3a92a:	mov    0x190(%r14),%rdi
  a3a931:	call   a34fc0 <core::ptr::drop_glue::<alloc::boxed::Box<gpui::native::GpuSurface>>>
  a3a936:	jmp    a3a944 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x794>
  a3a938:	mov    0x1a8(%r14),%rdi
  a3a93f:	call   a33440 <core::ptr::drop_glue::<softbuffer::Surface<alloc::sync::Arc<winit::window::Window>, alloc::sync::Arc<winit::window::Window>>>>
  a3a944:	movw   $0x0,0x188(%r14)
  a3a94e:	mov    %rbp,0x190(%r14)
  a3a955:	shl    $0x20,%r13
  a3a959:	mov    0x3c(%rsp),%edx
  a3a95d:	or     %r13,%rdx
  a3a960:	mov    %rbx,%rdi
  a3a963:	mov    %r14,%rsi
  a3a966:	call   a3b930 <<gpui::native::NativeHost<empty::Empty>>::resize>
  a3a96b:	mov    0x58(%rsp),%rax
  a3a970:	test   %rax,%rax
  a3a973:	je     a3a98b <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x7db>
  a3a975:	shl    $0x2,%rax
  a3a979:	lea    (%rax,%rax,2),%rsi
  a3a97d:	mov    $0x4,%edx
  a3a982:	mov    %r15,%rdi
  a3a985:	call   *0xaf1c05(%rip)        # 152c590 <_DYNAMIC+0x250>
  a3a98b:	mov    0x70(%rsp),%rsi
  a3a990:	test   %rsi,%rsi
  a3a993:	je     a3a9a9 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x7f9>
  a3a995:	mov    0x78(%rsp),%rdi
  a3a99a:	shl    $0x4,%rsi
  a3a99e:	mov    $0x4,%edx
  a3a9a3:	call   *0xaf1be7(%rip)        # 152c590 <_DYNAMIC+0x250>
  a3a9a9:	mov    0x88(%rsp),%rsi
  a3a9b1:	test   %rsi,%rsi
  a3a9b4:	je     a3a9cd <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x81d>
  a3a9b6:	mov    0x90(%rsp),%rdi
  a3a9be:	shl    $0x2,%rsi
  a3a9c2:	mov    $0x4,%edx
  a3a9c7:	call   *0xaf1bc3(%rip)        # 152c590 <_DYNAMIC+0x250>
  a3a9cd:	mov    0xa0(%rsp),%rsi
  a3a9d5:	test   %rsi,%rsi
  a3a9d8:	je     a3a9ec <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x83c>
  a3a9da:	shl    $0x2,%rsi
  a3a9de:	mov    $0x4,%edx
  a3a9e3:	mov    %r12,%rdi
  a3a9e6:	call   *0xaf1ba4(%rip)        # 152c590 <_DYNAMIC+0x250>
  a3a9ec:	mov    0x40(%rsp),%rax
  a3a9f1:	lock decq (%rax)
  a3a9f5:	jne    a3a6af <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x4ff>
  a3a9fb:	lea    0x40(%rsp),%rdi
  a3aa00:	call   *0xaf24c2(%rip)        # 152cec8 <_DYNAMIC+0xb88>
  a3aa06:	jmp    a3a6af <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x4ff>
  a3aa0b:	mov    $0x8,%edi
  a3aa10:	mov    $0x8,%esi
  a3aa15:	call   *0xaf1b8d(%rip)        # 152c5a8 <_DYNAMIC+0x268>
  a3aa1b:	jmp    a3aa7b <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x8cb>
  a3aa1d:	lea    -0x8a1a60(%rip),%rdi        # 198fc4 <anon.f48bbd6ee32d24e1254dac28089ef4b7.59.llvm.17379179981059708172>
  a3aa24:	lea    0xa817b5(%rip),%rcx        # 14bc1e0 <anon.f48bbd6ee32d24e1254dac28089ef4b7.8.llvm.17379179981059708172>
  a3aa2b:	lea    0xa81a2e(%rip),%r8        # 14bc460 <anon.f48bbd6ee32d24e1254dac28089ef4b7.61.llvm.17379179981059708172>
  a3aa32:	lea    0xf(%rsp),%rdx
  a3aa37:	mov    $0x37,%esi
  a3aa3c:	call   *0xaf1c76(%rip)        # 152c6b8 <_DYNAMIC+0x378>
  a3aa42:	jmp    a3aa7b <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x8cb>
  a3aa44:	lea    -0x8a1a87(%rip),%rdi        # 198fc4 <anon.f48bbd6ee32d24e1254dac28089ef4b7.59.llvm.17379179981059708172>
  a3aa4b:	lea    0xa8178e(%rip),%rcx        # 14bc1e0 <anon.f48bbd6ee32d24e1254dac28089ef4b7.8.llvm.17379179981059708172>
  a3aa52:	lea    0xa81a07(%rip),%r8        # 14bc460 <anon.f48bbd6ee32d24e1254dac28089ef4b7.61.llvm.17379179981059708172>
  a3aa59:	lea    0xf(%rsp),%rdx
  a3aa5e:	mov    $0x37,%esi
  a3aa63:	call   *0xaf1c4f(%rip)        # 152c6b8 <_DYNAMIC+0x378>
  a3aa69:	jmp    a3aa7b <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x8cb>
  a3aa6b:	mov    $0x8,%edi
  a3aa70:	mov    $0x3f0,%esi
  a3aa75:	call   *0xaf1b2d(%rip)        # 152c5a8 <_DYNAMIC+0x268>
  a3aa7b:	ud2
  a3aa7d:	mov    %rax,%rbx
  a3aa80:	movw   $0x0,0x188(%r14)
  a3aa8a:	mov    %rbp,0x190(%r14)
  a3aa91:	jmp    a3aae9 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x939>
  a3aa93:	mov    %rax,%rbx
  a3aa96:	jmp    a3aae9 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x939>
  a3aa98:	mov    %rax,%rbx
  a3aa9b:	lock decq 0x0(%rbp)
  a3aaa0:	jne    a3aaba <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x90a>
  a3aaa2:	lea    0x10(%rsp),%rdi
  a3aaa7:	call   *0xaf267b(%rip)        # 152d128 <_DYNAMIC+0xde8>
  a3aaad:	jmp    a3aaba <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x90a>
  a3aaaf:	mov    %rax,%rbx
  a3aab2:	mov    $0x1,%bpl
  a3aab5:	jmp    a3aaeb <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x93b>
  a3aab7:	mov    %rax,%rbx
  a3aaba:	mov    $0x1,%bpl
  a3aabd:	lea    0x6d0(%rsp),%rdi
  a3aac5:	call   a367f0 <core::ptr::drop_glue::<gpui_gpu::renderer::Renderer>>
  a3aaca:	jmp    a3aaeb <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x93b>
  a3aacc:	mov    %rax,%rbx
  a3aacf:	mov    $0x1,%bpl
  a3aad2:	jmp    a3aaf5 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x945>
  a3aad4:	mov    %rax,%rbx
  a3aad7:	jmp    a3ab38 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x988>
  a3aad9:	mov    %rax,%rbx
  a3aadc:	lea    0x140(%rsp),%rdi
  a3aae4:	call   a36e70 <core::ptr::drop_glue::<gpui::native::GpuSurface>>
  a3aae9:	xor    %ebp,%ebp
  a3aaeb:	lea    0x58(%rsp),%rdi
  a3aaf0:	call   a35ae0 <core::ptr::drop_glue::<wgpu_types::surface::SurfaceCapabilities>>
  a3aaf5:	mov    0x40(%rsp),%rax
  a3aafa:	lock decq (%rax)
  a3aafe:	jne    a3ab0b <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x95b>
  a3ab00:	lea    0x40(%rsp),%rdi
  a3ab05:	call   *0xaf23bd(%rip)        # 152cec8 <_DYNAMIC+0xb88>
  a3ab0b:	test   %bpl,%bpl
  a3ab0e:	jne    a3ab38 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x988>
  a3ab10:	jmp    a3ab96 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x9e6>
  a3ab15:	call   *0xaf1aad(%rip)        # 152c5c8 <_DYNAMIC+0x288>
  a3ab1b:	mov    %rax,%rbx
  a3ab1e:	mov    0x58(%rsp),%rsi
  a3ab23:	test   %rsi,%rsi
  a3ab26:	je     a3ab38 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x988>
  a3ab28:	mov    0x60(%rsp),%rdi
  a3ab2d:	mov    $0x1,%edx
  a3ab32:	call   *0xaf1a58(%rip)        # 152c590 <_DYNAMIC+0x250>
  a3ab38:	lea    0xc0(%rsp),%rdi
  a3ab40:	call   a37280 <core::ptr::drop_glue::<wgpu::api::surface::Surface>>
  a3ab45:	jmp    a3ab96 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x9e6>
  a3ab47:	call   *0xaf1a7b(%rip)        # 152c5c8 <_DYNAMIC+0x288>
  a3ab4d:	mov    %rax,%rbx
  a3ab50:	lock decq (%r15)
  a3ab54:	jne    a3ab96 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x9e6>
  a3ab56:	lea    0x140(%rsp),%rdi
  a3ab5e:	call   *0xaf24b4(%rip)        # 152d018 <_DYNAMIC+0xcd8>
  a3ab64:	jmp    a3ab96 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x9e6>
  a3ab66:	call   *0xaf1a5c(%rip)        # 152c5c8 <_DYNAMIC+0x288>
  a3ab6c:	mov    %rax,%rbx
  a3ab6f:	mov    0x58(%rsp),%rsi
  a3ab74:	test   %rsi,%rsi
  a3ab77:	je     a3ab89 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x9d9>
  a3ab79:	mov    0x60(%rsp),%rdi
  a3ab7e:	mov    $0x1,%edx
  a3ab83:	call   *0xaf1a07(%rip)        # 152c590 <_DYNAMIC+0x250>
  a3ab89:	lea    0x6d0(%rsp),%rdi
  a3ab91:	call   a37220 <core::ptr::drop_glue::<wgpu::api::surface::CreateSurfaceError>>
  a3ab96:	mov    %rbx,%rdi
  a3ab99:	call   14b6fa0 <_Unwind_Resume@plt>
  a3ab9e:	call   *0xaf1a24(%rip)        # 152c5c8 <_DYNAMIC+0x288>


/tmp/gpui-a11y-owner-channel-captures/release-baseline/empty:     file format elf64-x86-64


Disassembly of section .text:

0000000000a3abb0 <<gpui::native::NativeHost<empty::Empty>>::create_cpu_surface>:
  a3abb0:	push   %rbp
  a3abb1:	push   %r15
  a3abb3:	push   %r14
  a3abb5:	push   %r12
  a3abb7:	push   %rbx
  a3abb8:	sub    $0xb0,%rsp
  a3abbf:	mov    %rdi,%rbx
  a3abc2:	movl   $0xffffffff,0x180(%rsi)
  a3abcc:	movb   $0x0,0x209(%rsi)
  a3abd3:	mov    0x1d8(%rsi),%r12
  a3abda:	test   %r12,%r12
  a3abdd:	je     a3ac7c <<gpui::native::NativeHost<empty::Empty>>::create_cpu_surface+0xcc>
  a3abe3:	mov    %rsi,%r14
  a3abe6:	lea    0x10(%r12),%rdi
  a3abeb:	call   a3bc10 <<winit::window::Window>::inner_size>
  a3abf0:	lock incq (%r12)
  a3abf5:	jle    a3ada2 <<gpui::native::NativeHost<empty::Empty>>::create_cpu_surface+0x1f2>
  a3abfb:	mov    %eax,%ebp
  a3abfd:	mov    %edx,%r15d
  a3ac00:	lea    0x8(%rsp),%rdi
  a3ac05:	mov    %r12,%rsi
  a3ac08:	call   a16de0 <<softbuffer::Context<alloc::sync::Arc<winit::window::Window>>>::new>
  a3ac0d:	cmpl   $0xffffffff,0x8(%rsp)
  a3ac12:	je     a3ac88 <<gpui::native::NativeHost<empty::Empty>>::create_cpu_surface+0xd8>
  a3ac14:	mov    0x38(%rsp),%rax
  a3ac19:	mov    %rax,0x70(%rsp)
  a3ac1e:	movups 0x8(%rsp),%xmm0
  a3ac23:	movups 0x18(%rsp),%xmm1
  a3ac28:	movups 0x28(%rsp),%xmm2
  a3ac2d:	movaps %xmm2,0x60(%rsp)
  a3ac32:	movaps %xmm1,0x50(%rsp)
  a3ac37:	movaps %xmm0,0x40(%rsp)
  a3ac3c:	lea    0x78(%rsp),%rdi
  a3ac41:	lea    0x40(%rsp),%rsi
  a3ac46:	call   a38060 <gpui::native::platform::<softbuffer::error::SoftBufferError>>
  a3ac4b:	movups 0x78(%rsp),%xmm0
  a3ac50:	movups 0x88(%rsp),%xmm1
  a3ac58:	movups 0x98(%rsp),%xmm2
  a3ac60:	movups %xmm1,0x10(%rbx)
  a3ac64:	movups %xmm2,0x20(%rbx)
  a3ac68:	mov    0xa8(%rsp),%rax
  a3ac70:	mov    %rax,0x30(%rbx)
  a3ac74:	movups %xmm0,(%rbx)
  a3ac77:	jmp    a3ad92 <<gpui::native::NativeHost<empty::Empty>>::create_cpu_surface+0x1e2>
  a3ac7c:	movq   $0xfffffffffffffffe,(%rbx)
  a3ac83:	jmp    a3ad92 <<gpui::native::NativeHost<empty::Empty>>::create_cpu_surface+0x1e2>
  a3ac88:	mov    0x10(%rsp),%rax
  a3ac8d:	mov    %rax,(%rsp)
  a3ac91:	lock incq (%r12)
  a3ac96:	jle    a3ada2 <<gpui::native::NativeHost<empty::Empty>>::create_cpu_surface+0x1f2>
  a3ac9c:	lea    0x8(%rsp),%rdi
  a3aca1:	mov    %rsp,%rsi
  a3aca4:	mov    %r12,%rdx
  a3aca7:	call   a17550 <<softbuffer::Surface<alloc::sync::Arc<winit::window::Window>, alloc::sync::Arc<winit::window::Window>>>::new>
  a3acac:	cmpl   $0xffffffff,0x8(%rsp)
  a3acb1:	je     a3ad18 <<gpui::native::NativeHost<empty::Empty>>::create_cpu_surface+0x168>
  a3acb3:	mov    0x38(%rsp),%rax
  a3acb8:	mov    %rax,0x70(%rsp)
  a3acbd:	movups 0x8(%rsp),%xmm0
  a3acc2:	movups 0x18(%rsp),%xmm1
  a3acc7:	movups 0x28(%rsp),%xmm2
  a3accc:	movaps %xmm2,0x60(%rsp)
  a3acd1:	movaps %xmm1,0x50(%rsp)
  a3acd6:	movaps %xmm0,0x40(%rsp)
  a3acdb:	lea    0x78(%rsp),%rdi
  a3ace0:	lea    0x40(%rsp),%rsi
  a3ace5:	call   a38060 <gpui::native::platform::<softbuffer::error::SoftBufferError>>
  a3acea:	movups 0x78(%rsp),%xmm0
  a3acef:	movups 0x88(%rsp),%xmm1
  a3acf7:	movups 0x98(%rsp),%xmm2
  a3acff:	movups %xmm1,0x10(%rbx)
  a3ad03:	movups %xmm2,0x20(%rbx)
  a3ad07:	mov    0xa8(%rsp),%rax
  a3ad0f:	mov    %rax,0x30(%rbx)
  a3ad13:	movups %xmm0,(%rbx)
  a3ad16:	jmp    a3ad80 <<gpui::native::NativeHost<empty::Empty>>::create_cpu_surface+0x1d0>
  a3ad18:	mov    0x10(%rsp),%r12
  a3ad1d:	movzwl 0x188(%r14),%eax
  a3ad25:	cmp    $0x2,%eax
  a3ad28:	je     a3ad48 <<gpui::native::NativeHost<empty::Empty>>::create_cpu_surface+0x198>
  a3ad2a:	test   %eax,%eax
  a3ad2c:	jne    a3ad3c <<gpui::native::NativeHost<empty::Empty>>::create_cpu_surface+0x18c>
  a3ad2e:	mov    0x190(%r14),%rdi
  a3ad35:	call   a34fc0 <core::ptr::drop_glue::<alloc::boxed::Box<gpui::native::GpuSurface>>>
  a3ad3a:	jmp    a3ad48 <<gpui::native::NativeHost<empty::Empty>>::create_cpu_surface+0x198>
  a3ad3c:	mov    0x1a8(%r14),%rdi
  a3ad43:	call   a33440 <core::ptr::drop_glue::<softbuffer::Surface<alloc::sync::Arc<winit::window::Window>, alloc::sync::Arc<winit::window::Window>>>>
  a3ad48:	movw   $0x1,0x188(%r14)
  a3ad52:	xorps  %xmm0,%xmm0
  a3ad55:	movups %xmm0,0x18a(%r14)
  a3ad5d:	movups %xmm0,0x193(%r14)
  a3ad65:	mov    %r12,0x1a8(%r14)
  a3ad6c:	shl    $0x20,%r15
  a3ad70:	mov    %ebp,%edx
  a3ad72:	or     %r15,%rdx
  a3ad75:	mov    %rbx,%rdi
  a3ad78:	mov    %r14,%rsi
  a3ad7b:	call   a3b930 <<gpui::native::NativeHost<empty::Empty>>::resize>
  a3ad80:	mov    (%rsp),%rax
  a3ad84:	lock decq (%rax)
  a3ad88:	jne    a3ad92 <<gpui::native::NativeHost<empty::Empty>>::create_cpu_surface+0x1e2>
  a3ad8a:	mov    %rsp,%rdi
  a3ad8d:	call   a178f0 <<alloc::sync::Arc<softbuffer::backends::x11::X11DisplayImpl<alloc::sync::Arc<winit::window::Window>>>>::drop_slow>
  a3ad92:	add    $0xb0,%rsp
  a3ad99:	pop    %rbx
  a3ad9a:	pop    %r12
  a3ad9c:	pop    %r14
  a3ad9e:	pop    %r15
  a3ada0:	pop    %rbp
  a3ada1:	ret
  a3ada2:	ud2
  a3ada4:	mov    %rax,%rbx
  a3ada7:	movw   $0x1,0x188(%r14)
  a3adb1:	xorps  %xmm0,%xmm0
  a3adb4:	movups %xmm0,0x18a(%r14)
  a3adbc:	movups %xmm0,0x193(%r14)
  a3adc4:	mov    %r12,0x1a8(%r14)
  a3adcb:	jmp    a3add0 <<gpui::native::NativeHost<empty::Empty>>::create_cpu_surface+0x220>
  a3adcd:	mov    %rax,%rbx
  a3add0:	mov    (%rsp),%rax
  a3add4:	lock decq (%rax)
  a3add8:	jne    a3ade2 <<gpui::native::NativeHost<empty::Empty>>::create_cpu_surface+0x232>
  a3adda:	mov    %rsp,%rdi
  a3addd:	call   a178f0 <<alloc::sync::Arc<softbuffer::backends::x11::X11DisplayImpl<alloc::sync::Arc<winit::window::Window>>>>::drop_slow>
  a3ade2:	mov    %rbx,%rdi
  a3ade5:	call   14b6fa0 <_Unwind_Resume@plt>
  a3adea:	call   *0xaf17d8(%rip)        # 152c5c8 <_DYNAMIC+0x288>


/tmp/gpui-a11y-owner-channel-captures/release-baseline/empty:     file format elf64-x86-64


Disassembly of section .text:

0000000000a3adf0 <<gpui::native::NativeHost<empty::Empty>>::redraw>:
  a3adf0:	push   %rbp
  a3adf1:	push   %r15
  a3adf3:	push   %r14
  a3adf5:	push   %r13
  a3adf7:	push   %r12
  a3adf9:	push   %rbx
  a3adfa:	sub    $0x188,%rsp
  a3ae01:	mov    %rsi,%r14
  a3ae04:	mov    %rdi,%rbx
  a3ae07:	mov    0x1d8(%rsi),%rdi
  a3ae0e:	test   %rdi,%rdi
  a3ae11:	je     a3ae29 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x39>
  a3ae13:	add    $0x10,%rdi
  a3ae17:	call   *0xaf285b(%rip)        # 152d678 <_DYNAMIC+0x1338>
  a3ae1d:	cmp    $0x1,%al
  a3ae1f:	je     a3ae29 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x39>
  a3ae21:	movb   $0x1,0x205(%r14)
  a3ae29:	mov    0x180(%r14),%ebp
  a3ae30:	cmp    $0xffffffff,%ebp
  a3ae33:	je     a3ae56 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x66>
  a3ae35:	mov    0x178(%r14),%r15
  a3ae3c:	call   *0xaf220e(%rip)        # 152d050 <_DYNAMIC+0xd10>
  a3ae42:	cmp    %rax,%r15
  a3ae45:	jne    a3ae50 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x60>
  a3ae47:	cmp    %edx,%ebp
  a3ae49:	jbe    a3ae56 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x66>
  a3ae4b:	jmp    a3b078 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x288>
  a3ae50:	jg     a3b078 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x288>
  a3ae56:	movl   $0xffffffff,0x180(%r14)
  a3ae61:	mov    0x1d8(%r14),%rdi
  a3ae68:	test   %rdi,%rdi
  a3ae6b:	je     a3b078 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x288>
  a3ae71:	add    $0x10,%rdi
  a3ae75:	call   a3bc10 <<winit::window::Window>::inner_size>
  a3ae7a:	test   %eax,%eax
  a3ae7c:	je     a3b070 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x280>
  a3ae82:	mov    %edx,%r15d
  a3ae85:	test   %edx,%edx
  a3ae87:	je     a3b070 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x280>
  a3ae8d:	cmpb   $0x0,0x204(%r14)
  a3ae95:	jne    a3b070 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x280>
  a3ae9b:	mov    %eax,%r13d
  a3ae9e:	mov    0x1d8(%r14),%r12
  a3aea5:	test   %r12,%r12
  a3aea8:	je     a3afd0 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x1e0>
  a3aeae:	mov    0xaf22f3(%rip),%rax        # 152d1a8 <_DYNAMIC+0xe68>
  a3aeb5:	mov    (%rax),%rax
  a3aeb8:	cmp    $0x1,%rax
  a3aebc:	ja     a3af3c <<gpui::native::NativeHost<empty::Empty>>::redraw+0x14c>
  a3aebe:	mov    0xaf27bb(%rip),%rbp        # 152d680 <_DYNAMIC+0x1340>
  a3aec5:	movzbl 0x10(%rbp),%eax
  a3aec9:	movzbl %al,%ecx
  a3aecc:	lea    -0x1(%rcx),%edx
  a3aecf:	cmp    $0x2,%edx
  a3aed2:	jae    a3af34 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x144>
  a3aed4:	mov    0x0(%rbp),%rdi
  a3aed8:	movzbl %al,%esi
  a3aedb:	call   *0xaf22d7(%rip)        # 152d1b8 <_DYNAMIC+0xe78>
  a3aee1:	test   %al,%al
  a3aee3:	je     a3af3c <<gpui::native::NativeHost<empty::Empty>>::redraw+0x14c>
  a3aee5:	mov    0x0(%rbp),%rsi
  a3aee9:	lea    0x30(%rsi),%rax
  a3aeed:	movq   $0x1,(%rsp)
  a3aef5:	movq   $0x8,0x8(%rsp)
  a3aefe:	movq   $0x0,0x10(%rsp)
  a3af07:	mov    %rax,0x18(%rsp)
  a3af0c:	lea    0x60(%rsp),%rdi
  a3af11:	mov    %rsp,%rdx
  a3af14:	call   *0xaf2376(%rip)        # 152d290 <_DYNAMIC+0xf50>
  a3af1a:	cmpq   $0x2,0x60(%rsp)
  a3af20:	je     a3af51 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x161>
  a3af22:	lea    0x78(%rsp),%rsi
  a3af27:	lea    0x60(%rsp),%rdi
  a3af2c:	call   *0xaf2366(%rip)        # 152d298 <_DYNAMIC+0xf58>
  a3af32:	jmp    a3af51 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x161>
  a3af34:	test   %ecx,%ecx
  a3af36:	jne    a3b80e <<gpui::native::NativeHost<empty::Empty>>::redraw+0xa1e>
  a3af3c:	movq   $0x2,0x60(%rsp)
  a3af45:	movq   $0x0,0x80(%rsp)
  a3af51:	mov    0x80(%rsp),%rax
  a3af59:	mov    %rax,0x20(%rsp)
  a3af5e:	mov    0x60(%rsp),%rax
  a3af63:	mov    0x68(%rsp),%rcx
  a3af68:	movups 0x70(%rsp),%xmm0
  a3af6d:	movaps %xmm0,0x10(%rsp)
  a3af72:	mov    %rax,(%rsp)
  a3af76:	mov    %rcx,0x8(%rsp)
  a3af7b:	mov    0x10(%r12),%rdi
  a3af80:	add    $0x10,%rdi
  a3af84:	call   *0xaf1cc6(%rip)        # 152cc50 <_DYNAMIC+0x910>
  a3af8a:	mov    %rax,%r12
  a3af8d:	movzbl 0x284(%rax),%ebp
  a3af94:	test   $0x1,%dl
  a3af97:	jne    a3afaf <<gpui::native::NativeHost<empty::Empty>>::redraw+0x1bf>
  a3af99:	mov    0xaf1cc0(%rip),%rax        # 152cc60 <_DYNAMIC+0x920>
  a3afa0:	mov    (%rax),%rax
  a3afa3:	shl    $1,%rax
  a3afa6:	test   %rax,%rax
  a3afa9:	jne    a3b7f5 <<gpui::native::NativeHost<empty::Empty>>::redraw+0xa05>
  a3afaf:	xor    %eax,%eax
  a3afb1:	xchg   %eax,(%r12)
  a3afb5:	cmp    $0x2,%eax
  a3afb8:	je     a3b7e7 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x9f7>
  a3afbe:	mov    %rsp,%rdi
  a3afc1:	call   a36d90 <core::ptr::drop_glue::<tracing::span::EnteredSpan>>
  a3afc6:	cmp    $0x1,%bpl
  a3afca:	jne    a3b070 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x280>
  a3afd0:	lea    0x188(%r14),%r12
  a3afd7:	movzwl 0x188(%r14),%eax
  a3afdf:	cmp    $0x1,%ax
  a3afe3:	jne    a3b091 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x2a1>
  a3afe9:	lea    0x60(%rsp),%rdi
  a3afee:	mov    %r14,%rsi
  a3aff1:	call   a393d0 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade>
  a3aff6:	mov    0x60(%rsp),%rcx
  a3affb:	movzbl 0x68(%rsp),%eax
  a3b000:	cmp    $0xfffffffffffffffe,%rcx
  a3b004:	jne    a3b356 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x566>
  a3b00a:	test   $0x1,%al
  a3b00c:	jne    a3b078 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x288>
  a3b00e:	movzwl (%r12),%eax
  a3b013:	cmp    $0x1,%ax
  a3b017:	jne    a3b091 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x2a1>
  a3b019:	movzbl 0x205(%r14),%ebp
  a3b021:	movzbl %bpl,%edx
  a3b025:	lea    0x60(%rsp),%rdi
  a3b02a:	mov    %r14,%rsi
  a3b02d:	call   a38ca0 <<gpui::native::NativeHost<empty::Empty>>::present_cpu>
  a3b032:	cmpb   $0x0,0x60(%rsp)
  a3b037:	je     a3b4ab <<gpui::native::NativeHost<empty::Empty>>::redraw+0x6bb>
  a3b03d:	mov    0x98(%rsp),%rax
  a3b045:	mov    %rax,0x30(%rbx)
  a3b049:	movups 0x68(%rsp),%xmm0
  a3b04e:	movups 0x78(%rsp),%xmm1
  a3b053:	movups 0x88(%rsp),%xmm2
  a3b05b:	movups %xmm2,0x20(%rbx)
  a3b05f:	movups %xmm1,0x10(%rbx)
  a3b063:	movups %xmm0,(%rbx)
  a3b066:	movb   $0x1,0x205(%r14)
  a3b06e:	jmp    a3b07f <<gpui::native::NativeHost<empty::Empty>>::redraw+0x28f>
  a3b070:	movb   $0x1,0x205(%r14)
  a3b078:	movq   $0xfffffffffffffffe,(%rbx)
  a3b07f:	add    $0x188,%rsp
  a3b086:	pop    %rbx
  a3b087:	pop    %r12
  a3b089:	pop    %r13
  a3b08b:	pop    %r14
  a3b08d:	pop    %r15
  a3b08f:	pop    %rbp
  a3b090:	ret
  a3b091:	cmp    $0x2,%ax
  a3b095:	sete   %cl
  a3b098:	or     %cl,%al
  a3b09a:	test   $0x1,%al
  a3b09c:	jne    a3b078 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x288>
  a3b09e:	lea    0xe0(%r14),%rax
  a3b0a5:	mov    %rax,0xc8(%rsp)
  a3b0ad:	lea    0x1d0(%r14),%rbp
  a3b0b4:	shl    $0x20,%r15
  a3b0b8:	mov    %r13d,%r13d
  a3b0bb:	or     %r15,%r13
  a3b0be:	lea    0x68(%rsp),%r15
  a3b0c3:	mov    $0x378,%esi
  a3b0c8:	add    0x190(%r14),%rsi
  a3b0cf:	lea    0x60(%rsp),%rdi
  a3b0d4:	call   *0xaf2536(%rip)        # 152d610 <_DYNAMIC+0x12d0>
  a3b0da:	mov    0x60(%rsp),%rax
  a3b0df:	lea    -0x8a245e(%rip),%rcx        # 198c88 <anon.7cc7c74d1b8f8dfb5e74abfe8b727cdb.77.llvm.18220644203745900989+0x494>
  a3b0e6:	movslq (%rcx,%rax,4),%rax
  a3b0ea:	add    %rcx,%rax
  a3b0ed:	jmp    *%rax
  a3b0ef:	movups 0x50(%r15),%xmm0
  a3b0f4:	movaps %xmm0,0x120(%rsp)
  a3b0fc:	movups 0x40(%r15),%xmm0
  a3b101:	movaps %xmm0,0x110(%rsp)
  a3b109:	movups (%r15),%xmm0
  a3b10d:	movups 0x10(%r15),%xmm1
  a3b112:	movups 0x20(%r15),%xmm2
  a3b117:	movups 0x30(%r15),%xmm3
  a3b11c:	movaps %xmm3,0x100(%rsp)
  a3b124:	movaps %xmm2,0xf0(%rsp)
  a3b12c:	movaps %xmm1,0xe0(%rsp)
  a3b134:	movaps %xmm0,0xd0(%rsp)
  a3b13c:	cmpb   $0x0,(%r14)
  a3b140:	je     a3b828 <<gpui::native::NativeHost<empty::Empty>>::redraw+0xa38>
  a3b146:	lea    0xd8(%rsp),%rsi
  a3b14e:	movq   $0x0,0x18(%rsp)
  a3b157:	movl   $0xffffffff,0x30(%rsp)
  a3b15f:	movl   $0x0,(%rsp)
  a3b166:	movabs $0xffffffff00000000,%rax
  a3b170:	mov    %rax,0x28(%rsp)
  a3b175:	movq   $0x0,0x3c(%rsp)
  a3b17e:	movl   $0x0,0x8(%rsp)
  a3b186:	movl   $0x0,0x10(%rsp)
  a3b18e:	lea    0x130(%rsp),%rdi
  a3b196:	mov    %rsp,%rdx
  a3b199:	call   *0xaf2479(%rip)        # 152d618 <_DYNAMIC+0x12d8>
  a3b19f:	mov    0x190(%r14),%rdx
  a3b1a6:	mov    %rsp,%rdi
  a3b1a9:	lea    0x130(%rsp),%rcx
  a3b1b1:	lea    0x8(%r14),%rsi
  a3b1b5:	call   9ad360 <<gpui::runtime::Win<empty::Empty>>::with_paint_scene::<core::result::Result<gpui::runtime::PresentationToken, gpui_gpu::renderer::Error>, <gpui::native::NativeHost<empty::Empty>>::try_upgrade::{closure#0}::{closure#0}>>
  a3b1ba:	mov    (%rsp),%rax
  a3b1be:	movsd  0x8(%rsp),%xmm0
  a3b1c4:	mov    0x10(%rsp),%r13
  a3b1c9:	movups 0x18(%rsp),%xmm1
  a3b1ce:	cmp    $0xfffffffffffffffe,%rax
  a3b1d2:	jne    a3b4fd <<gpui::native::NativeHost<empty::Empty>>::redraw+0x70d>
  a3b1d8:	mov    0x8(%rsp),%ecx
  a3b1dc:	cmp    $0xffffffff,%ecx
  a3b1df:	je     a3b6a5 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x8b5>
  a3b1e5:	mov    $0x2c,%eax
  a3b1ea:	cmp    $0x5,%ecx
  a3b1ed:	jb     a3b506 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x716>
  a3b1f3:	cmpb   $0x0,0x207(%r14)
  a3b1fb:	jne    a3b506 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x716>
  a3b201:	mov    0x180(%rsp),%rax
  a3b209:	mov    %rax,0x50(%rsp)
  a3b20e:	movups 0x170(%rsp),%xmm0
  a3b216:	movaps %xmm0,0x40(%rsp)
  a3b21b:	movups 0x130(%rsp),%xmm0
  a3b223:	movups 0x140(%rsp),%xmm1
  a3b22b:	movups 0x150(%rsp),%xmm2
  a3b233:	movups 0x160(%rsp),%xmm3
  a3b23b:	movaps %xmm3,0x30(%rsp)
  a3b240:	movaps %xmm2,0x20(%rsp)
  a3b245:	movaps %xmm1,0x10(%rsp)
  a3b24a:	movaps %xmm0,(%rsp)
  a3b24e:	mov    %rsp,%rdi
  a3b251:	call   a37130 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  a3b256:	movaps 0x120(%rsp),%xmm0
  a3b25e:	movaps %xmm0,0x50(%rsp)
  a3b263:	movaps 0x110(%rsp),%xmm0
  a3b26b:	movaps %xmm0,0x40(%rsp)
  a3b270:	movaps 0xd0(%rsp),%xmm0
  a3b278:	movaps 0xe0(%rsp),%xmm1
  a3b280:	movaps 0xf0(%rsp),%xmm2
  a3b288:	movaps 0x100(%rsp),%xmm3
  a3b290:	movaps %xmm3,0x30(%rsp)
  a3b295:	movaps %xmm2,0x20(%rsp)
  a3b29a:	movaps %xmm1,0x10(%rsp)
  a3b29f:	movaps %xmm0,(%rsp)
  a3b2a3:	mov    %rsp,%rdi
  a3b2a6:	call   a371a0 <core::ptr::drop_glue::<wgpu::api::surface_texture::SurfaceTexture>>
  a3b2ab:	lea    0x8(%r14),%rax
  a3b2af:	mov    (%rax),%rax
  a3b2b2:	test   %rax,%rax
  a3b2b5:	je     a3b540 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x750>
  a3b2bb:	mov    $0xe,%ecx
  a3b2c0:	cmpb   $0x0,0x72e(%rax)
  a3b2c7:	jne    a3b545 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x755>
  a3b2cd:	movb   $0x0,0x72c(%rax)
  a3b2d4:	mov    %r12,%rdi
  a3b2d7:	call   a344d0 <core::ptr::drop_glue::<core::option::Option<gpui::native::Graphics>>>
  a3b2dc:	movw   $0x2,(%r12)
  a3b2e3:	mov    0x0(%rbp),%rax
  a3b2e7:	test   %rax,%rax
  a3b2ea:	je     a3b2fb <<gpui::native::NativeHost<empty::Empty>>::redraw+0x50b>
  a3b2ec:	lock decq (%rax)
  a3b2f0:	jne    a3b2fb <<gpui::native::NativeHost<empty::Empty>>::redraw+0x50b>
  a3b2f2:	mov    %rbp,%rdi
  a3b2f5:	call   *0xaf1bc5(%rip)        # 152cec0 <_DYNAMIC+0xb80>
  a3b2fb:	movq   $0x0,0x0(%rbp)
  a3b303:	lea    0xe0(%r14),%r12
  a3b30a:	mov    %r12,%rdi
  a3b30d:	call   a34700 <core::ptr::drop_glue::<core::option::Option<gpui::native::upgrade::Upgrade>>>
  a3b312:	movq   $0xffffffffffffffff,0xe0(%r14)
  a3b31d:	movb   $0x1,0x206(%r14)
  a3b325:	mov    %rsp,%rdi
  a3b328:	mov    %r14,%rsi
  a3b32b:	call   a3abb0 <<gpui::native::NativeHost<empty::Empty>>::create_cpu_surface>
  a3b330:	cmpl   $0xfffffffe,(%rsp)
  a3b334:	jne    a3b66a <<gpui::native::NativeHost<empty::Empty>>::redraw+0x87a>
  a3b33a:	mov    %rbx,%rdi
  a3b33d:	mov    %r14,%rsi
  a3b340:	call   a3adf0 <<gpui::native::NativeHost<empty::Empty>>::redraw>
  a3b345:	cmpq   $0x1,0x60(%rsp)
  a3b34b:	jne    a3b07f <<gpui::native::NativeHost<empty::Empty>>::redraw+0x28f>
  a3b351:	jmp    a3b698 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x8a8>
  a3b356:	movups 0x69(%rsp),%xmm0
  a3b35b:	movups 0x79(%rsp),%xmm1
  a3b360:	movups 0x88(%rsp),%xmm2
  a3b368:	movups %xmm2,0x28(%rbx)
  a3b36c:	movups %xmm1,0x19(%rbx)
  a3b370:	movups %xmm0,0x9(%rbx)
  a3b374:	mov    %rcx,(%rbx)
  a3b377:	mov    %al,0x8(%rbx)
  a3b37a:	jmp    a3b07f <<gpui::native::NativeHost<empty::Empty>>::redraw+0x28f>
  a3b37f:	movups 0x50(%r15),%xmm0
  a3b384:	movaps %xmm0,0x50(%rsp)
  a3b389:	movups 0x40(%r15),%xmm0
  a3b38e:	movaps %xmm0,0x40(%rsp)
  a3b393:	movups (%r15),%xmm0
  a3b397:	movups 0x10(%r15),%xmm1
  a3b39c:	movups 0x20(%r15),%xmm2
  a3b3a1:	movups 0x30(%r15),%xmm3
  a3b3a6:	movaps %xmm3,0x30(%rsp)
  a3b3ab:	movaps %xmm2,0x20(%rsp)
  a3b3b0:	movaps %xmm1,0x10(%rsp)
  a3b3b5:	movaps %xmm0,(%rsp)
  a3b3b9:	mov    %rsp,%rdi
  a3b3bc:	call   a371a0 <core::ptr::drop_glue::<wgpu::api::surface_texture::SurfaceTexture>>
  a3b3c1:	mov    %rsp,%rdi
  a3b3c4:	mov    %r14,%rsi
  a3b3c7:	mov    %r13,%rdx
  a3b3ca:	call   a3b930 <<gpui::native::NativeHost<empty::Empty>>::resize>
  a3b3cf:	cmpl   $0xfffffffe,(%rsp)
  a3b3d3:	je     a3b58c <<gpui::native::NativeHost<empty::Empty>>::redraw+0x79c>
  a3b3d9:	mov    0x30(%rsp),%rax
  a3b3de:	mov    %rax,0x30(%rbx)
  a3b3e2:	movups (%rsp),%xmm0
  a3b3e6:	movups 0x10(%rsp),%xmm1
  a3b3eb:	movups 0x20(%rsp),%xmm2
  a3b3f0:	movups %xmm2,0x20(%rbx)
  a3b3f4:	movups %xmm1,0x10(%rbx)
  a3b3f8:	movups %xmm0,(%rbx)
  a3b3fb:	jmp    a3b07f <<gpui::native::NativeHost<empty::Empty>>::redraw+0x28f>
  a3b400:	mov    %rsp,%rdi
  a3b403:	mov    %r14,%rsi
  a3b406:	mov    %r13,%rdx
  a3b409:	call   a3b930 <<gpui::native::NativeHost<empty::Empty>>::resize>
  a3b40e:	jmp    a3b582 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x792>
  a3b413:	cmpl   $0x1,(%r14)
  a3b417:	jne    a3b442 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x652>
  a3b419:	lea    0x8(%r14),%rax
  a3b41d:	mov    (%rax),%rax
  a3b420:	test   %rax,%rax
  a3b423:	je     a3b540 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x750>
  a3b429:	mov    $0xe,%ecx
  a3b42e:	cmpb   $0x0,0x72e(%rax)
  a3b435:	jne    a3b545 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x755>
  a3b43b:	movb   $0x0,0x72c(%rax)
  a3b442:	lea    0xe0(%r14),%rdi
  a3b449:	call   a34700 <core::ptr::drop_glue::<core::option::Option<gpui::native::upgrade::Upgrade>>>
  a3b44e:	movq   $0xffffffffffffffff,0xe0(%r14)
  a3b459:	movb   $0x0,0x206(%r14)
  a3b461:	mov    0x1d0(%r14),%rax
  a3b468:	test   %rax,%rax
  a3b46b:	je     a3b47c <<gpui::native::NativeHost<empty::Empty>>::redraw+0x68c>
  a3b46d:	lock decq (%rax)
  a3b471:	jne    a3b47c <<gpui::native::NativeHost<empty::Empty>>::redraw+0x68c>
  a3b473:	mov    %rbp,%rdi
  a3b476:	call   *0xaf1a44(%rip)        # 152cec0 <_DYNAMIC+0xb80>
  a3b47c:	movq   $0x0,0x0(%rbp)
  a3b484:	movzwl (%r12),%eax
  a3b489:	cmp    $0x2,%eax
  a3b48c:	je     a3b56d <<gpui::native::NativeHost<empty::Empty>>::redraw+0x77d>
  a3b492:	test   %eax,%eax
  a3b494:	jne    a3b561 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x771>
  a3b49a:	mov    0x190(%r14),%rdi
  a3b4a1:	call   a34fc0 <core::ptr::drop_glue::<alloc::boxed::Box<gpui::native::GpuSurface>>>
  a3b4a6:	jmp    a3b56d <<gpui::native::NativeHost<empty::Empty>>::redraw+0x77d>
  a3b4ab:	test   %bpl,%bpl
  a3b4ae:	je     a3b4b8 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x6c8>
  a3b4b0:	movb   $0x0,0x205(%r14)
  a3b4b8:	movzbl 0x98(%rsp),%ebp
  a3b4c0:	mov    0x1f0(%r14),%rdi
  a3b4c7:	test   %rdi,%rdi
  a3b4ca:	je     a3b4e7 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x6f7>
  a3b4cc:	movups 0x78(%rsp),%xmm0
  a3b4d1:	mov    0x1f8(%r14),%rax
  a3b4d8:	movaps %xmm0,(%rsp)
  a3b4dc:	movb   $0x0,0x10(%rsp)
  a3b4e1:	mov    %rsp,%rsi
  a3b4e4:	call   *0x20(%rax)
  a3b4e7:	test   %bpl,%bpl
  a3b4ea:	je     a3b078 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x288>
  a3b4f0:	mov    %r14,%rdi
  a3b4f3:	call   a39ff0 <<gpui::native::NativeHost<empty::Empty>>::start_upgrade>
  a3b4f8:	jmp    a3b078 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x288>
  a3b4fd:	movups 0x28(%rsp),%xmm2
  a3b502:	movups %xmm2,0x28(%rbx)
  a3b506:	movlps %xmm0,0x8(%rbx)
  a3b50a:	mov    %r13,0x10(%rbx)
  a3b50e:	movups %xmm1,0x18(%rbx)
  a3b512:	mov    %rax,(%rbx)
  a3b515:	lea    0x130(%rsp),%rdi
  a3b51d:	call   a37130 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  a3b522:	lea    0xd0(%rsp),%rdi
  a3b52a:	call   a371a0 <core::ptr::drop_glue::<wgpu::api::surface_texture::SurfaceTexture>>
  a3b52f:	cmpq   $0x1,0x60(%rsp)
  a3b535:	jne    a3b07f <<gpui::native::NativeHost<empty::Empty>>::redraw+0x28f>
  a3b53b:	jmp    a3b698 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x8a8>
  a3b540:	mov    $0xd,%ecx
  a3b545:	mov    %rcx,(%rbx)
  a3b548:	movq   $0x0,0x8(%rbx)
  a3b550:	cmpq   $0x1,0x60(%rsp)
  a3b556:	jne    a3b07f <<gpui::native::NativeHost<empty::Empty>>::redraw+0x28f>
  a3b55c:	jmp    a3b698 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x8a8>
  a3b561:	mov    0x1a8(%r14),%rdi
  a3b568:	call   a33440 <core::ptr::drop_glue::<softbuffer::Surface<alloc::sync::Arc<winit::window::Window>, alloc::sync::Arc<winit::window::Window>>>>
  a3b56d:	movw   $0x2,0x188(%r14)
  a3b577:	mov    %rsp,%rdi
  a3b57a:	mov    %r14,%rsi
  a3b57d:	call   a3a1b0 <<gpui::native::NativeHost<empty::Empty>>::create_surface>
  a3b582:	cmpl   $0xfffffffe,(%rsp)
  a3b586:	jne    a3b66a <<gpui::native::NativeHost<empty::Empty>>::redraw+0x87a>
  a3b58c:	movzwl (%r12),%eax
  a3b591:	cmp    $0x2,%ax
  a3b595:	sete   %cl
  a3b598:	or     %cl,%al
  a3b59a:	test   $0x1,%al
  a3b59c:	jne    a3b078 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x288>
  a3b5a2:	mov    $0x378,%esi
  a3b5a7:	add    0x190(%r14),%rsi
  a3b5ae:	lea    0x60(%rsp),%rdi
  a3b5b3:	call   *0xaf2057(%rip)        # 152d610 <_DYNAMIC+0x12d0>
  a3b5b9:	mov    0x60(%rsp),%rax
  a3b5be:	lea    -0x8a2921(%rip),%rcx        # 198ca4 <anon.7cc7c74d1b8f8dfb5e74abfe8b727cdb.77.llvm.18220644203745900989+0x4b0>
  a3b5c5:	movslq (%rcx,%rax,4),%rax
  a3b5c9:	add    %rcx,%rax
  a3b5cc:	jmp    *%rax
  a3b5ce:	movzbl 0x209(%r14),%r12d
  a3b5d6:	cmp    $0x3,%r12
  a3b5da:	jae    a3b655 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x865>
  a3b5dc:	lea    -0x8a2663(%rip),%r13        # 198f80 <anon.7cc7c74d1b8f8dfb5e74abfe8b727cdb.77.llvm.18220644203745900989+0x78c>
  a3b5e3:	lea    0x1(%r12),%eax
  a3b5e8:	mov    %al,0x209(%r14)
  a3b5ef:	call   *0xaf1a5b(%rip)        # 152d050 <_DYNAMIC+0xd10>
  a3b5f5:	mov    %rax,%rdi
  a3b5f8:	mov    %edx,%esi
  a3b5fa:	mov    0x0(%r13,%r12,8),%rcx
  a3b5ff:	mov    %rcx,%rax
  a3b602:	shr    $0x3,%rax
  a3b606:	movabs $0x20c49ba5e353f7cf,%rdx
  a3b610:	mul    %rdx
  a3b613:	shr    $0x4,%rdx
  a3b617:	imul   $0x3e8,%edx,%eax
  a3b61d:	sub    %eax,%ecx
  a3b61f:	imul   $0xf4240,%ecx,%ecx
  a3b625:	lea    0xa80d7c(%rip),%r8        # 14bc3a8 <anon.f48bbd6ee32d24e1254dac28089ef4b7.8.llvm.17379179981059708172+0x1c8>
  a3b62c:	call   *0xaf2056(%rip)        # 152d688 <_DYNAMIC+0x1348>
  a3b632:	mov    %rax,0x178(%r14)
  a3b639:	mov    %edx,0x180(%r14)
  a3b640:	movq   $0xfffffffffffffffe,(%rbx)
  a3b647:	cmpq   $0x1,0x60(%rsp)
  a3b64d:	jne    a3b07f <<gpui::native::NativeHost<empty::Empty>>::redraw+0x28f>
  a3b653:	jmp    a3b698 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x8a8>
  a3b655:	movq   $0x2f,(%rbx)
  a3b65c:	cmpq   $0x1,0x60(%rsp)
  a3b662:	jne    a3b07f <<gpui::native::NativeHost<empty::Empty>>::redraw+0x28f>
  a3b668:	jmp    a3b698 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x8a8>
  a3b66a:	mov    0x30(%rsp),%rax
  a3b66f:	mov    %rax,0x30(%rbx)
  a3b673:	movups (%rsp),%xmm0
  a3b677:	movups 0x10(%rsp),%xmm1
  a3b67c:	movups 0x20(%rsp),%xmm2
  a3b681:	movups %xmm2,0x20(%rbx)
  a3b685:	movups %xmm1,0x10(%rbx)
  a3b689:	movups %xmm0,(%rbx)
  a3b68c:	cmpq   $0x1,0x60(%rsp)
  a3b692:	jne    a3b07f <<gpui::native::NativeHost<empty::Empty>>::redraw+0x28f>
  a3b698:	mov    %r15,%rdi
  a3b69b:	call   a371a0 <core::ptr::drop_glue::<wgpu::api::surface_texture::SurfaceTexture>>
  a3b6a0:	jmp    a3b07f <<gpui::native::NativeHost<empty::Empty>>::redraw+0x28f>
  a3b6a5:	cmpq   $0x0,0x1d8(%r14)
  a3b6ad:	je     a3b843 <<gpui::native::NativeHost<empty::Empty>>::redraw+0xa53>
  a3b6b3:	mov    0x18(%rsp),%r12
  a3b6b8:	mov    $0x1,%bpl
  a3b6bb:	call   a38b90 <<winit::window::Window>::pre_present_notify>
  a3b6c0:	mov    $0x350,%edi
  a3b6c5:	add    0x190(%r14),%rdi
  a3b6cc:	movaps 0x120(%rsp),%xmm0
  a3b6d4:	movaps %xmm0,0x50(%rsp)
  a3b6d9:	movaps 0x110(%rsp),%xmm0
  a3b6e1:	movaps %xmm0,0x40(%rsp)
  a3b6e6:	movaps 0xd0(%rsp),%xmm0
  a3b6ee:	movaps 0xe0(%rsp),%xmm1
  a3b6f6:	movaps 0xf0(%rsp),%xmm2
  a3b6fe:	movaps 0x100(%rsp),%xmm3
  a3b706:	movaps %xmm3,0x30(%rsp)
  a3b70b:	movaps %xmm2,0x20(%rsp)
  a3b710:	movaps %xmm1,0x10(%rsp)
  a3b715:	movaps %xmm0,(%rsp)
  a3b719:	xor    %ebp,%ebp
  a3b71b:	mov    %rsp,%rsi
  a3b71e:	call   *0xaf1efc(%rip)        # 152d620 <_DYNAMIC+0x12e0>
  a3b724:	lea    0x8(%r14),%rax
  a3b728:	mov    (%rax),%rsi
  a3b72b:	test   %rsi,%rsi
  a3b72e:	je     a3b794 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x9a4>
  a3b730:	mov    $0xe,%eax
  a3b735:	cmpb   $0x0,0x72e(%rsi)
  a3b73c:	jne    a3b7a2 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x9b2>
  a3b73e:	xor    %ebp,%ebp
  a3b740:	mov    %rsp,%rdi
  a3b743:	mov    %r13,%rdx
  a3b746:	mov    %r12,%rcx
  a3b749:	call   9c3020 <<gpui::runtime::Runtime<empty::Empty>>::acknowledge>
  a3b74e:	mov    (%rsp),%rax
  a3b752:	cmp    $0xfffffffffffffffe,%rax
  a3b756:	jne    a3b7a2 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x9b2>
  a3b758:	mov    0x1f0(%r14),%rdi
  a3b75f:	test   %rdi,%rdi
  a3b762:	je     a3b781 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x991>
  a3b764:	movups 0x18(%rsp),%xmm0
  a3b769:	mov    0x1f8(%r14),%rax
  a3b770:	movaps %xmm0,(%rsp)
  a3b774:	movb   $0x1,0x10(%rsp)
  a3b779:	xor    %ebp,%ebp
  a3b77b:	mov    %rsp,%rsi
  a3b77e:	call   *0x20(%rax)
  a3b781:	movw   $0x0,0x208(%r14)
  a3b78b:	movq   $0xfffffffffffffffe,(%rbx)
  a3b792:	jmp    a3b7c9 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x9d9>
  a3b794:	movq   $0x0,0x8(%rsp)
  a3b79d:	mov    $0xd,%eax
  a3b7a2:	mov    0x8(%rsp),%rcx
  a3b7a7:	mov    %rcx,0x8(%rbx)
  a3b7ab:	mov    0x10(%rsp),%rcx
  a3b7b0:	mov    %rcx,0x10(%rbx)
  a3b7b4:	movups 0x28(%rsp),%xmm0
  a3b7b9:	movups %xmm0,0x28(%rbx)
  a3b7bd:	movups 0x18(%rsp),%xmm0
  a3b7c2:	mov    %rax,(%rbx)
  a3b7c5:	movups %xmm0,0x18(%rbx)
  a3b7c9:	lea    0x130(%rsp),%rdi
  a3b7d1:	call   a37130 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  a3b7d6:	cmpq   $0x1,0x60(%rsp)
  a3b7dc:	jne    a3b07f <<gpui::native::NativeHost<empty::Empty>>::redraw+0x28f>
  a3b7e2:	jmp    a3b698 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x8a8>
  a3b7e7:	mov    %r12,%rdi
  a3b7ea:	call   *0xaf1498(%rip)        # 152cc88 <_DYNAMIC+0x948>
  a3b7f0:	jmp    a3afbe <<gpui::native::NativeHost<empty::Empty>>::redraw+0x1ce>
  a3b7f5:	call   *0xaf1495(%rip)        # 152cc90 <_DYNAMIC+0x950>
  a3b7fb:	test   %al,%al
  a3b7fd:	jne    a3afaf <<gpui::native::NativeHost<empty::Empty>>::redraw+0x1bf>
  a3b803:	movb   $0x1,0x4(%r12)
  a3b809:	jmp    a3afaf <<gpui::native::NativeHost<empty::Empty>>::redraw+0x1bf>
  a3b80e:	mov    0xaf1e6b(%rip),%rdi        # 152d680 <_DYNAMIC+0x1340>
  a3b815:	call   *0xaf19bd(%rip)        # 152d1d8 <_DYNAMIC+0xe98>
  a3b81b:	test   %al,%al
  a3b81d:	jne    a3aed4 <<gpui::native::NativeHost<empty::Empty>>::redraw+0xe4>
  a3b823:	jmp    a3af3c <<gpui::native::NativeHost<empty::Empty>>::redraw+0x14c>
  a3b828:	lea    -0x8a2957(%rip),%rdi        # 198ed8 <anon.7cc7c74d1b8f8dfb5e74abfe8b727cdb.77.llvm.18220644203745900989+0x6e4>
  a3b82f:	lea    0xa80b42(%rip),%rdx        # 14bc378 <anon.f48bbd6ee32d24e1254dac28089ef4b7.8.llvm.17379179981059708172+0x198>
  a3b836:	mov    $0x14,%esi
  a3b83b:	call   *0xaf0e6f(%rip)        # 152c6b0 <_DYNAMIC+0x370>
  a3b841:	jmp    a3b853 <<gpui::native::NativeHost<empty::Empty>>::redraw+0xa63>
  a3b843:	mov    $0x1,%bpl
  a3b846:	lea    0xa80b43(%rip),%rdi        # 14bc390 <anon.f48bbd6ee32d24e1254dac28089ef4b7.8.llvm.17379179981059708172+0x1b0>
  a3b84d:	call   *0xaf0d65(%rip)        # 152c5b8 <_DYNAMIC+0x278>
  a3b853:	ud2
  a3b855:	movq   $0x0,0x0(%rbp)
  a3b85d:	mov    %rax,%rdi
  a3b860:	call   14b6fa0 <_Unwind_Resume@plt>
  a3b865:	movq   $0xffffffffffffffff,(%r12)
  a3b86d:	mov    %rax,%rdi
  a3b870:	call   14b6fa0 <_Unwind_Resume@plt>
  a3b875:	movw   $0x2,(%r12)
  a3b87c:	mov    %rax,%rdi
  a3b87f:	call   14b6fa0 <_Unwind_Resume@plt>
  a3b884:	jmp    a3b909 <<gpui::native::NativeHost<empty::Empty>>::redraw+0xb19>
  a3b889:	movq   $0x0,0x0(%rbp)
  a3b891:	mov    %rax,%rdi
  a3b894:	call   14b6fa0 <_Unwind_Resume@plt>
  a3b899:	movw   $0x2,(%r12)
  a3b8a0:	mov    %rax,%rdi
  a3b8a3:	call   14b6fa0 <_Unwind_Resume@plt>
  a3b8a8:	mov    %rax,%rbx
  a3b8ab:	mov    0xc8(%rsp),%rax
  a3b8b3:	movq   $0xffffffffffffffff,(%rax)
  a3b8ba:	mov    %rbx,%rdi
  a3b8bd:	call   14b6fa0 <_Unwind_Resume@plt>
  a3b8c2:	mov    %rax,%rbx
  a3b8c5:	mov    $0x1,%bpl
  a3b8c8:	jmp    a3b8f5 <<gpui::native::NativeHost<empty::Empty>>::redraw+0xb05>
  a3b8ca:	mov    %rax,%rbx
  a3b8cd:	lea    0x60(%rsp),%rdi
  a3b8d2:	call   a36e10 <core::ptr::drop_glue::<tracing::span::Span>>
  a3b8d7:	jmp    a3b919 <<gpui::native::NativeHost<empty::Empty>>::redraw+0xb29>
  a3b8d9:	call   *0xaf0ce9(%rip)        # 152c5c8 <_DYNAMIC+0x288>
  a3b8df:	mov    %rax,%rbx
  a3b8e2:	mov    %rsp,%rdi
  a3b8e5:	call   a36d90 <core::ptr::drop_glue::<tracing::span::EnteredSpan>>
  a3b8ea:	jmp    a3b919 <<gpui::native::NativeHost<empty::Empty>>::redraw+0xb29>
  a3b8ec:	call   *0xaf0cd6(%rip)        # 152c5c8 <_DYNAMIC+0x288>
  a3b8f2:	mov    %rax,%rbx
  a3b8f5:	lea    0x130(%rsp),%rdi
  a3b8fd:	call   a37130 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  a3b902:	test   %bpl,%bpl
  a3b905:	jne    a3b90c <<gpui::native::NativeHost<empty::Empty>>::redraw+0xb1c>
  a3b907:	jmp    a3b919 <<gpui::native::NativeHost<empty::Empty>>::redraw+0xb29>
  a3b909:	mov    %rax,%rbx
  a3b90c:	lea    0xd0(%rsp),%rdi
  a3b914:	call   a371a0 <core::ptr::drop_glue::<wgpu::api::surface_texture::SurfaceTexture>>
  a3b919:	mov    %rbx,%rdi
  a3b91c:	call   14b6fa0 <_Unwind_Resume@plt>
  a3b921:	call   *0xaf0ca1(%rip)        # 152c5c8 <_DYNAMIC+0x288>


/tmp/gpui-a11y-owner-channel-captures/release-baseline/empty:     file format elf64-x86-64


Disassembly of section .text:

0000000000a3b930 <<gpui::native::NativeHost<empty::Empty>>::resize>:
  a3b930:	push   %rbp
  a3b931:	push   %r15
  a3b933:	push   %r14
  a3b935:	push   %r13
  a3b937:	push   %r12
  a3b939:	push   %rbx
  a3b93a:	sub    $0x138,%rsp
  a3b941:	mov    %rdx,%r15
  a3b944:	mov    %rdi,%rbx
  a3b947:	movb   $0x1,0x205(%rsi)
  a3b94e:	mov    $0xffffffff,%eax
  a3b953:	mov    %rax,0x1b0(%rsi)
  a3b95a:	movq   $0x0,0x1b8(%rsi)
  a3b965:	test   %r15d,%r15d
  a3b968:	je     a3bbae <<gpui::native::NativeHost<empty::Empty>>::resize+0x27e>
  a3b96e:	mov    %r15,%r12
  a3b971:	shr    $0x20,%r12
  a3b975:	je     a3bbae <<gpui::native::NativeHost<empty::Empty>>::resize+0x27e>
  a3b97b:	mov    %rsi,%r14
  a3b97e:	movzwl 0x188(%rsi),%ebp
  a3b985:	cmp    $0x2,%bp
  a3b989:	sete   %al
  a3b98c:	mov    %ebp,%ecx
  a3b98e:	or     %al,%cl
  a3b990:	test   $0x1,%cl
  a3b993:	je     a3ba8b <<gpui::native::NativeHost<empty::Empty>>::resize+0x15b>
  a3b999:	lea    0x8(%r14),%r13
  a3b99d:	cmpb   $0x0,(%r14)
  a3b9a1:	je     a3b9e7 <<gpui::native::NativeHost<empty::Empty>>::resize+0xb7>
  a3b9a3:	mov    0x1d8(%r14),%rdi
  a3b9aa:	test   %rdi,%rdi
  a3b9ad:	je     a3bbf8 <<gpui::native::NativeHost<empty::Empty>>::resize+0x2c8>
  a3b9b3:	add    $0x10,%rdi
  a3b9b7:	call   a38880 <<winit::window::Window>::scale_factor>
  a3b9bc:	cvtsd2ss %xmm0,%xmm0
  a3b9c0:	lea    0x40(%rsp),%rdi
  a3b9c5:	mov    %r13,%rsi
  a3b9c8:	mov    %r15,%rdx
  a3b9cb:	call   9c2490 <<gpui::runtime::Win<empty::Empty>>::resize_scaled>
  a3b9d0:	mov    0x40(%rsp),%rax
  a3b9d5:	cmp    $0xfffffffffffffffe,%rax
  a3b9d9:	jne    a3bad9 <<gpui::native::NativeHost<empty::Empty>>::resize+0x1a9>
  a3b9df:	movzwl 0x188(%r14),%ebp
  a3b9e7:	cmp    $0x2,%bp
  a3b9eb:	je     a3bb8f <<gpui::native::NativeHost<empty::Empty>>::resize+0x25f>
  a3b9f1:	cmpb   $0x0,(%r14)
  a3b9f5:	je     a3ba25 <<gpui::native::NativeHost<empty::Empty>>::resize+0xf5>
  a3b9f7:	mov    0x0(%r13),%rax
  a3b9fb:	test   %rax,%rax
  a3b9fe:	je     a3bbc7 <<gpui::native::NativeHost<empty::Empty>>::resize+0x297>
  a3ba04:	mov    $0xe,%ecx
  a3ba09:	cmpb   $0x0,0x72e(%rax)
  a3ba10:	jne    a3bbcc <<gpui::native::NativeHost<empty::Empty>>::resize+0x29c>
  a3ba16:	movb   $0x0,0x72c(%rax)
  a3ba1d:	movzwl 0x188(%r14),%ebp
  a3ba25:	test   $0x1,%bpl
  a3ba29:	je     a3bb12 <<gpui::native::NativeHost<empty::Empty>>::resize+0x1e2>
  a3ba2f:	mov    0x1a8(%r14),%rsi
  a3ba36:	lea    0x8(%rsp),%rdi
  a3ba3b:	mov    %r15d,%edx
  a3ba3e:	mov    %r12d,%ecx
  a3ba41:	call   a2d720 <<softbuffer::backends::x11::X11Impl<alloc::sync::Arc<winit::window::Window>, alloc::sync::Arc<winit::window::Window>> as softbuffer::backend_interface::SurfaceInterface<alloc::sync::Arc<winit::window::Window>, alloc::sync::Arc<winit::window::Window>>>::resize>
  a3ba46:	cmpl   $0xffffffff,0x8(%rsp)
  a3ba4b:	je     a3bbd9 <<gpui::native::NativeHost<empty::Empty>>::resize+0x2a9>
  a3ba51:	mov    0x38(%rsp),%rax
  a3ba56:	mov    %rax,0x70(%rsp)
  a3ba5b:	movups 0x8(%rsp),%xmm0
  a3ba60:	movups 0x18(%rsp),%xmm1
  a3ba65:	movups 0x28(%rsp),%xmm2
  a3ba6a:	movaps %xmm2,0x60(%rsp)
  a3ba6f:	movaps %xmm1,0x50(%rsp)
  a3ba74:	movaps %xmm0,0x40(%rsp)
  a3ba79:	lea    0x40(%rsp),%rsi
  a3ba7e:	mov    %rbx,%rdi
  a3ba81:	call   a38060 <gpui::native::platform::<softbuffer::error::SoftBufferError>>
  a3ba86:	jmp    a3bbb5 <<gpui::native::NativeHost<empty::Empty>>::resize+0x285>
  a3ba8b:	mov    $0x348,%esi
  a3ba90:	add    0x190(%r14),%rsi
  a3ba97:	lea    0x40(%rsp),%rdi
  a3ba9c:	call   *0xaf1b5e(%rip)        # 152d600 <_DYNAMIC+0x12c0>
  a3baa2:	mov    0x44(%rsp),%eax
  a3baa6:	cmp    %r15d,%eax
  a3baa9:	setb   %cl
  a3baac:	cmp    %r12d,%eax
  a3baaf:	setb   %al
  a3bab2:	or     %cl,%al
  a3bab4:	jne    a3bacd <<gpui::native::NativeHost<empty::Empty>>::resize+0x19d>
  a3bab6:	mov    %r15d,%eax
  a3bab9:	mov    %r12,%rcx
  a3babc:	imul   %rax,%rcx
  a3bac0:	cmp    $0x1000001,%rcx
  a3bac7:	jb     a3b999 <<gpui::native::NativeHost<empty::Empty>>::resize+0x69>
  a3bacd:	movq   $0x1e,(%rbx)
  a3bad4:	jmp    a3bbb5 <<gpui::native::NativeHost<empty::Empty>>::resize+0x285>
  a3bad9:	mov    0x68(%rsp),%rcx
  a3bade:	movzbl 0x70(%rsp),%edx
  a3bae3:	mov    0x74(%rsp),%esi
  a3bae7:	mov    %esi,0x34(%rbx)
  a3baea:	mov    0x71(%rsp),%esi
  a3baee:	mov    %esi,0x31(%rbx)
  a3baf1:	movups 0x48(%rsp),%xmm0
  a3baf6:	movups 0x58(%rsp),%xmm1
  a3bafb:	mov    %rax,(%rbx)
  a3bafe:	movups %xmm0,0x8(%rbx)
  a3bb02:	movups %xmm1,0x18(%rbx)
  a3bb06:	mov    %rcx,0x28(%rbx)
  a3bb0a:	mov    %dl,0x30(%rbx)
  a3bb0d:	jmp    a3bbb5 <<gpui::native::NativeHost<empty::Empty>>::resize+0x285>
  a3bb12:	mov    0x190(%r14),%rsi
  a3bb19:	mov    0x370(%rsi),%eax
  a3bb1f:	mov    %eax,0x4c(%rsp)
  a3bb23:	mov    0x368(%rsi),%rax
  a3bb2a:	mov    %rax,0x44(%rsp)
  a3bb2f:	movl   $0x10,0x40(%rsp)
  a3bb37:	movl   $0x1,0x50(%rsp)
  a3bb3f:	mov    %r15,0x54(%rsp)
  a3bb44:	movabs $0x100000002,%rax
  a3bb4e:	mov    %rax,0x5c(%rsp)
  a3bb53:	movl   $0x1,0x64(%rsp)
  a3bb5b:	movq   $0x0,0x68(%rsp)
  a3bb64:	movq   $0x4,0x70(%rsp)
  a3bb6d:	movq   $0x0,0x78(%rsp)
  a3bb76:	lea    0x378(%rsi),%rdi
  a3bb7d:	add    $0x348,%rsi
  a3bb84:	lea    0x40(%rsp),%rdx
  a3bb89:	call   *0xaf1a79(%rip)        # 152d608 <_DYNAMIC+0x12c8>
  a3bb8f:	cmpb   $0x0,0x204(%r14)
  a3bb97:	jne    a3bbae <<gpui::native::NativeHost<empty::Empty>>::resize+0x27e>
  a3bb99:	mov    0x1d8(%r14),%rdi
  a3bba0:	test   %rdi,%rdi
  a3bba3:	je     a3bbae <<gpui::native::NativeHost<empty::Empty>>::resize+0x27e>
  a3bba5:	add    $0x10,%rdi
  a3bba9:	call   a38a10 <<winit::window::Window>::request_redraw>
  a3bbae:	movq   $0xfffffffffffffffe,(%rbx)
  a3bbb5:	add    $0x138,%rsp
  a3bbbc:	pop    %rbx
  a3bbbd:	pop    %r12
  a3bbbf:	pop    %r13
  a3bbc1:	pop    %r14
  a3bbc3:	pop    %r15
  a3bbc5:	pop    %rbp
  a3bbc6:	ret
  a3bbc7:	mov    $0xd,%ecx
  a3bbcc:	mov    %rcx,(%rbx)
  a3bbcf:	movq   $0x0,0x8(%rbx)
  a3bbd7:	jmp    a3bbb5 <<gpui::native::NativeHost<empty::Empty>>::resize+0x285>
  a3bbd9:	xorps  %xmm0,%xmm0
  a3bbdc:	movups %xmm0,0x193(%r14)
  a3bbe4:	movups %xmm0,0x18a(%r14)
  a3bbec:	cmpb   $0x0,0x204(%r14)
  a3bbf4:	je     a3bb99 <<gpui::native::NativeHost<empty::Empty>>::resize+0x269>
  a3bbf6:	jmp    a3bbae <<gpui::native::NativeHost<empty::Empty>>::resize+0x27e>
  a3bbf8:	lea    0xa807c1(%rip),%rdi        # 14bc3c0 <anon.f48bbd6ee32d24e1254dac28089ef4b7.8.llvm.17379179981059708172+0x1e0>
  a3bbff:	call   *0xaf09b3(%rip)        # 152c5b8 <_DYNAMIC+0x278>


/tmp/gpui-a11y-owner-channel-captures/release-baseline/empty:     file format elf64-x86-64


Disassembly of section .text:

0000000000a3c690 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch>:
  a3c690:	push   %rbp
  a3c691:	push   %r15
  a3c693:	push   %r14
  a3c695:	push   %r13
  a3c697:	push   %r12
  a3c699:	push   %rbx
  a3c69a:	sub    $0xb88,%rsp
  a3c6a1:	mov    %rsi,%rbx
  a3c6a4:	mov    %rdi,%r14
  a3c6a7:	mov    (%rdx),%rax
  a3c6aa:	xor    %r13d,%r13d
  a3c6ad:	sub    $0x3,%rax
  a3c6b1:	cmovae %rax,%r13
  a3c6b5:	cmp    $0x2,%r13
  a3c6b9:	je     a3c8b6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x226>
  a3c6bf:	cmp    $0x8,%r13
  a3c6c3:	jne    a3c6d2 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x42>
  a3c6c5:	mov    %r14,%rdi
  a3c6c8:	call   a39e60 <<gpui::native::NativeHost<empty::Empty>>::retire_window>
  a3c6cd:	jmp    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3c6d2:	lea    0x188(%r14),%r12
  a3c6d9:	cmpw   $0x2,0x188(%r14)
  a3c6e2:	je     a3c869 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1d9>
  a3c6e8:	lea    0x250(%rsp),%rdi
  a3c6f0:	mov    %r12,%rsi
  a3c6f3:	mov    %rdx,%rbp
  a3c6f6:	call   *0xaf0fb4(%rip)        # 152d6b0 <_DYNAMIC+0x1370>
  a3c6fc:	mov    %rbp,%rdx
  a3c6ff:	mov    0x250(%rsp),%rax
  a3c707:	cmp    $0xfffffffffffffffe,%rax
  a3c70b:	je     a3c869 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1d9>
  a3c711:	cmp    $0xffffffffffffffff,%rax
  a3c715:	jne    a3c733 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xa3>
  a3c717:	cmpb   $0x0,0x208(%r14)
  a3c71f:	je     a3c7ab <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x11b>
  a3c725:	movq   $0x2f,0x1e8(%rsp)
  a3c731:	jmp    a3c757 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xc7>
  a3c733:	movups 0x258(%rsp),%xmm0
  a3c73b:	movups %xmm0,0x1f8(%rsp)
  a3c743:	movq   $0x30,0x1e8(%rsp)
  a3c74f:	mov    %rax,0x1f0(%rsp)
  a3c757:	lea    0xf8(%r14),%r15
  a3c75e:	cmpl   $0xfffffffe,0xf8(%r14)
  a3c766:	je     a3c770 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xe0>
  a3c768:	mov    %r15,%rdi
  a3c76b:	call   a36f00 <core::ptr::drop_glue::<gpui::native::NativeError>>
  a3c770:	mov    0x218(%rsp),%rax
  a3c778:	mov    %rax,0x30(%r15)
  a3c77c:	movupd 0x1e8(%rsp),%xmm0
  a3c785:	movupd 0x1f8(%rsp),%xmm1
  a3c78e:	movups 0x208(%rsp),%xmm2
  a3c796:	movups %xmm2,0x20(%r15)
  a3c79b:	movupd %xmm1,0x10(%r15)
  a3c7a1:	movupd %xmm0,(%r15)
  a3c7a6:	jmp    a3dc7d <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x15ed>
  a3c7ab:	mov    $0x1,%al
  a3c7ad:	cmpb   $0x0,(%r14)
  a3c7b1:	je     a3c7e4 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154>
  a3c7b3:	mov    0x8(%r14),%rax
  a3c7b7:	test   %rax,%rax
  a3c7ba:	je     a3cfa8 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x918>
  a3c7c0:	mov    $0xe,%r15d
  a3c7c6:	cmpb   $0x0,0x72e(%rax)
  a3c7cd:	jne    a3cfae <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x91e>
  a3c7d3:	movb   $0x0,0x72c(%rax)
  a3c7da:	movzbl 0x208(%r14),%eax
  a3c7e2:	inc    %al
  a3c7e4:	mov    %al,0x208(%r14)
  a3c7eb:	lea    0xe0(%r14),%r15
  a3c7f2:	mov    %r15,%rdi
  a3c7f5:	call   a34700 <core::ptr::drop_glue::<core::option::Option<gpui::native::upgrade::Upgrade>>>
  a3c7fa:	movq   $0xffffffffffffffff,0xe0(%r14)
  a3c805:	movb   $0x0,0x206(%r14)
  a3c80d:	lea    0x1d0(%r14),%r15
  a3c814:	mov    0x1d0(%r14),%rax
  a3c81b:	test   %rax,%rax
  a3c81e:	je     a3c82f <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x19f>
  a3c820:	lock decq (%rax)
  a3c824:	jne    a3c82f <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x19f>
  a3c826:	mov    %r15,%rdi
  a3c829:	call   *0xaf0691(%rip)        # 152cec0 <_DYNAMIC+0xb80>
  a3c82f:	movq   $0x0,(%r15)
  a3c836:	mov    %r12,%rdi
  a3c839:	call   a344d0 <core::ptr::drop_glue::<core::option::Option<gpui::native::Graphics>>>
  a3c83e:	movw   $0x2,0x188(%r14)
  a3c848:	lea    0x1e8(%rsp),%rdi
  a3c850:	mov    %r14,%rsi
  a3c853:	call   a3a1b0 <<gpui::native::NativeHost<empty::Empty>>::create_surface>
  a3c858:	cmpl   $0xfffffffe,0x1e8(%rsp)
  a3c860:	mov    %rbp,%rdx
  a3c863:	jne    a3c757 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xc7>
  a3c869:	cmp    $0x6,%r13
  a3c86d:	ja     a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3c873:	lea    -0x8a3bba(%rip),%rax        # 198cc0 <anon.7cc7c74d1b8f8dfb5e74abfe8b727cdb.77.llvm.18220644203745900989+0x4cc>
  a3c87a:	movslq (%rax,%r13,4),%rcx
  a3c87e:	add    %rax,%rcx
  a3c881:	jmp    *%rcx
  a3c883:	mov    0x180(%r14),%ebp
  a3c88a:	cmp    $0xffffffff,%ebp
  a3c88d:	je     a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3c893:	mov    0x178(%r14),%r15
  a3c89a:	call   *0xaf07b0(%rip)        # 152d050 <_DYNAMIC+0xd10>
  a3c8a0:	cmp    %rax,%r15
  a3c8a3:	jne    a3cead <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x81d>
  a3c8a9:	cmp    %edx,%ebp
  a3c8ab:	jbe    a3ceb3 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x823>
  a3c8b1:	jmp    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3c8b6:	movb   $0x1,0x205(%r14)
  a3c8be:	mov    $0xffffffff,%eax
  a3c8c3:	mov    %rax,0x1b0(%r14)
  a3c8ca:	movq   $0x0,0x1b8(%r14)
  a3c8d5:	mov    0x1d8(%r14),%rdi
  a3c8dc:	test   %rdi,%rdi
  a3c8df:	je     a3c8ec <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x25c>
  a3c8e1:	add    $0x10,%rdi
  a3c8e5:	xor    %esi,%esi
  a3c8e7:	call   a3bd90 <<winit::window::Window>::set_visible>
  a3c8ec:	lea    0xe0(%r14),%r15
  a3c8f3:	mov    %r15,%rdi
  a3c8f6:	call   a34700 <core::ptr::drop_glue::<core::option::Option<gpui::native::upgrade::Upgrade>>>
  a3c8fb:	movq   $0xffffffffffffffff,0xe0(%r14)
  a3c906:	movb   $0x0,0x206(%r14)
  a3c90e:	mov    0x1d0(%r14),%rax
  a3c915:	test   %rax,%rax
  a3c918:	je     a3c930 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x2a0>
  a3c91a:	lock decq (%rax)
  a3c91e:	jne    a3c930 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x2a0>
  a3c920:	lea    0x1d0(%r14),%r15
  a3c927:	mov    %r15,%rdi
  a3c92a:	call   *0xaf0590(%rip)        # 152cec0 <_DYNAMIC+0xb80>
  a3c930:	movq   $0x0,0x1d0(%r14)
  a3c93b:	movzwl 0x188(%r14),%eax
  a3c943:	cmp    $0x2,%eax
  a3c946:	je     a3c966 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x2d6>
  a3c948:	test   %eax,%eax
  a3c94a:	jne    a3c95a <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x2ca>
  a3c94c:	mov    0x190(%r14),%rdi
  a3c953:	call   a34fc0 <core::ptr::drop_glue::<alloc::boxed::Box<gpui::native::GpuSurface>>>
  a3c958:	jmp    a3c966 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x2d6>
  a3c95a:	mov    0x1a8(%r14),%rdi
  a3c961:	call   a33440 <core::ptr::drop_glue::<softbuffer::Surface<alloc::sync::Arc<winit::window::Window>, alloc::sync::Arc<winit::window::Window>>>>
  a3c966:	movw   $0x2,0x188(%r14)
  a3c970:	cmpl   $0x1,(%r14)
  a3c974:	jne    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3c97a:	mov    0x8(%r14),%rax
  a3c97e:	test   %rax,%rax
  a3c981:	je     a3c993 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x303>
  a3c983:	cmpb   $0x0,0x72e(%rax)
  a3c98a:	je     a3c9f6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x366>
  a3c98c:	mov    $0xe,%ebp
  a3c991:	jmp    a3c998 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x308>
  a3c993:	mov    $0xd,%ebp
  a3c998:	xor    %r13d,%r13d
  a3c99b:	cmpl   $0xfffffffe,0xf8(%r14)
  a3c9a3:	je     a3c9b1 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x321>
  a3c9a5:	lea    0xf8(%r14),%rdi
  a3c9ac:	call   a36f00 <core::ptr::drop_glue::<gpui::native::NativeError>>
  a3c9b1:	mov    %rbp,0xf8(%r14)
  a3c9b8:	mov    %r13,0x100(%r14)
  a3c9bf:	mov    %r12,0x108(%r14)
  a3c9c6:	mov    %r15,0x110(%r14)
  a3c9cd:	movapd 0x10(%rsp),%xmm0
  a3c9d3:	movupd %xmm0,0x118(%r14)
  a3c9dc:	mov    0x20(%rsp),%rax
  a3c9e1:	mov    %rax,0x128(%r14)
  a3c9e8:	mov    %rbx,%rdi
  a3c9eb:	call   *0xaf0cc7(%rip)        # 152d6b8 <_DYNAMIC+0x1378>
  a3c9f1:	jmp    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3c9f6:	movb   $0x0,0x72c(%rax)
  a3c9fd:	jmp    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3ca02:	mov    0x130(%r14),%rax
  a3ca09:	movq   $0xffffffffffffffff,0x130(%r14)
  a3ca14:	cmp    $0xffffffffffffffff,%rax
  a3ca18:	je     a3d4ad <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xe1d>
  a3ca1e:	mov    %rax,0x68(%rsp)
  a3ca23:	mov    %rax,0x70(%rsp)
  a3ca28:	movupd 0x138(%r14),%xmm0
  a3ca31:	movupd 0x148(%r14),%xmm1
  a3ca3a:	movups 0x158(%r14),%xmm2
  a3ca42:	movups 0x168(%r14),%xmm3
  a3ca4a:	movupd %xmm0,0x78(%rsp)
  a3ca50:	movupd %xmm1,0x88(%rsp)
  a3ca59:	movups %xmm2,0x98(%rsp)
  a3ca61:	movups %xmm3,0xa8(%rsp)
  a3ca69:	lea    0xb8(%rsp),%rdi
  a3ca71:	lea    0x70(%rsp),%rsi
  a3ca76:	call   *0xaf01dc(%rip)        # 152cc58 <_DYNAMIC+0x918>
  a3ca7c:	mov    0x90(%rsp),%rbp
  a3ca84:	mov    0x98(%rsp),%rax
  a3ca8c:	mov    %rax,0x8(%rsp)
  a3ca91:	mov    0x1e0(%r14),%r13
  a3ca98:	test   %r13,%r13
  a3ca9b:	je     a3cac7 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x437>
  a3ca9d:	mov    0x1e8(%r14),%r15
  a3caa4:	mov    (%r15),%rax
  a3caa7:	test   %rax,%rax
  a3caaa:	je     a3cab1 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x421>
  a3caac:	mov    %r13,%rdi
  a3caaf:	call   *%rax
  a3cab1:	mov    0x8(%r15),%rsi
  a3cab5:	test   %rsi,%rsi
  a3cab8:	je     a3cac7 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x437>
  a3caba:	mov    0x10(%r15),%rdx
  a3cabe:	mov    %r13,%rdi
  a3cac1:	call   *0xaefac9(%rip)        # 152c590 <_DYNAMIC+0x250>
  a3cac7:	mov    %rbp,0x1e0(%r14)
  a3cace:	mov    0x8(%rsp),%rax
  a3cad3:	mov    %rax,0x1e8(%r14)
  a3cada:	mov    0xa0(%rsp),%rbp
  a3cae2:	mov    0xa8(%rsp),%rax
  a3caea:	mov    %rax,0x8(%rsp)
  a3caef:	mov    0x1f0(%r14),%r13
  a3caf6:	test   %r13,%r13
  a3caf9:	je     a3cb25 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x495>
  a3cafb:	mov    0x1f8(%r14),%r15
  a3cb02:	mov    (%r15),%rax
  a3cb05:	test   %rax,%rax
  a3cb08:	je     a3cb0f <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x47f>
  a3cb0a:	mov    %r13,%rdi
  a3cb0d:	call   *%rax
  a3cb0f:	mov    0x8(%r15),%rsi
  a3cb13:	test   %rsi,%rsi
  a3cb16:	je     a3cb25 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x495>
  a3cb18:	mov    0x10(%r15),%rdx
  a3cb1c:	mov    %r13,%rdi
  a3cb1f:	call   *0xaefa6b(%rip)        # 152c590 <_DYNAMIC+0x250>
  a3cb25:	mov    %rbp,0x1f0(%r14)
  a3cb2c:	mov    0x8(%rsp),%rax
  a3cb31:	mov    %rax,0x1f8(%r14)
  a3cb38:	call   *0xaefa42(%rip)        # 152c580 <_DYNAMIC+0x240>
  a3cb3e:	movq   $0xfffffffffffffffd,0x100(%rsp)
  a3cb4a:	lea    0x250(%rsp),%rdi
  a3cb52:	call   *0xaf0b68(%rip)        # 152d6c0 <_DYNAMIC+0x1380>
  a3cb58:	lea    0x8d0(%rsp),%rdi
  a3cb60:	lea    0x100(%rsp),%r13
  a3cb68:	mov    0xaefa31(%rip),%r15        # 152c5a0 <memcpy@GLIBC_2.14>
  a3cb6f:	mov    $0x90,%edx
  a3cb74:	mov    %r13,%rsi
  a3cb77:	call   *%r15
  a3cb7a:	lea    0x818(%rsp),%rdi
  a3cb82:	lea    0x250(%rsp),%rsi
  a3cb8a:	mov    $0x98,%edx
  a3cb8f:	call   *%r15
  a3cb92:	movups 0x78(%rsp),%xmm0
  a3cb97:	mov    0x68(%rsp),%rax
  a3cb9c:	mov    %rax,0x800(%rsp)
  a3cba4:	movups %xmm0,0x808(%rsp)
  a3cbac:	movq   $0xffffffffffffffff,0x8b0(%rsp)
  a3cbb8:	movl   $0x1,0x960(%rsp)
  a3cbc3:	movsd  0x88(%rsp),%xmm0
  a3cbcc:	xorpd  %xmm1,%xmm1
  a3cbd0:	unpcklps %xmm1,%xmm0
  a3cbd3:	movapd -0x8b016b(%rip),%xmm1        # 18ca70 <anon.89c1a9733c414c7e4e56fa7f22cdc6b9.309.llvm.3311541718473421078+0x8c0>
  a3cbdb:	orpd   %xmm1,%xmm0
  a3cbdf:	subpd  %xmm1,%xmm0
  a3cbe3:	movupd %xmm0,0x968(%rsp)
  a3cbec:	movl   $0x2,0x978(%rsp)
  a3cbf7:	movl   $0x2,0x990(%rsp)
  a3cc02:	movl   $0x2,0x9a8(%rsp)
  a3cc0d:	movl   $0x2,0x9c0(%rsp)
  a3cc18:	movl   $0xffffffff,0x9d8(%rsp)
  a3cc23:	movw   $0x0,0x9f0(%rsp)
  a3cc2d:	movl   $0x7,0xa00(%rsp)
  a3cc38:	movw   $0x102,0xa0c(%rsp)
  a3cc42:	movabs $0x100010000000001,%rax
  a3cc4c:	mov    %rax,0xa04(%rsp)
  a3cc54:	mov    0xaf054d(%rip),%rax        # 152d1a8 <_DYNAMIC+0xe68>
  a3cc5b:	mov    (%rax),%rax
  a3cc5e:	cmp    $0x2,%rax
  a3cc62:	jae    a3d0c9 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xa39>
  a3cc68:	mov    0xaf0a59(%rip),%r15        # 152d6c8 <_DYNAMIC+0x1388>
  a3cc6f:	movzbl 0x10(%r15),%eax
  a3cc74:	movzbl %al,%ecx
  a3cc77:	lea    -0x1(%rcx),%edx
  a3cc7a:	cmp    $0x2,%edx
  a3cc7d:	jae    a3d0c1 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xa31>
  a3cc83:	mov    (%r15),%rdi
  a3cc86:	movzbl %al,%esi
  a3cc89:	call   *0xaf0529(%rip)        # 152d1b8 <_DYNAMIC+0xe78>
  a3cc8f:	test   %al,%al
  a3cc91:	je     a3d0c9 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xa39>
  a3cc97:	mov    (%r15),%rsi
  a3cc9a:	lea    0x30(%rsi),%rax
  a3cc9e:	lea    0x800(%rsp),%rcx
  a3cca6:	mov    %rcx,0xd0(%rsp)
  a3ccae:	lea    0xd0(%rsp),%rcx
  a3ccb6:	mov    %rcx,0x100(%rsp)
  a3ccbe:	lea    0xa7f5d3(%rip),%rcx        # 14bc298 <anon.f48bbd6ee32d24e1254dac28089ef4b7.8.llvm.17379179981059708172+0xb8>
  a3ccc5:	mov    %rcx,0x108(%rsp)
  a3cccd:	movq   $0x1,0x250(%rsp)
  a3ccd9:	mov    %r13,0x258(%rsp)
  a3cce1:	movq   $0x1,0x260(%rsp)
  a3cced:	mov    %rax,0x268(%rsp)
  a3ccf5:	lea    0x40(%rsp),%rdi
  a3ccfa:	lea    0x250(%rsp),%rdx
  a3cd02:	call   *0xaf0588(%rip)        # 152d290 <_DYNAMIC+0xf50>
  a3cd08:	cmpq   $0x2,0x40(%rsp)
  a3cd0e:	je     a3d0db <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xa4b>
  a3cd14:	lea    0x58(%rsp),%rsi
  a3cd19:	lea    0x40(%rsp),%rdi
  a3cd1e:	call   *0xaf0574(%rip)        # 152d298 <_DYNAMIC+0xf58>
  a3cd24:	jmp    a3d0db <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xa4b>
  a3cd29:	mov    0x178(%r14),%rax
  a3cd30:	mov    0x180(%r14),%ecx
  a3cd37:	testb  $0x1,0x204(%r14)
  a3cd3f:	mov    $0x3b9aca01,%edx
  a3cd44:	mov    %ecx,%esi
  a3cd46:	cmovne %edx,%esi
  a3cd49:	cmp    $0xffffffff,%ecx
  a3cd4c:	cmove  %edx,%esi
  a3cd4f:	mov    %rax,0x68(%rbx)
  a3cd53:	mov    %esi,0x70(%rbx)
  a3cd56:	jmp    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3cd5b:	mov    0x1d8(%r14),%r12
  a3cd62:	test   %r12,%r12
  a3cd65:	je     a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3cd6b:	mov    %rdx,%r15
  a3cd6e:	mov    0xaf0433(%rip),%rax        # 152d1a8 <_DYNAMIC+0xe68>
  a3cd75:	mov    (%rax),%rax
  a3cd78:	cmp    $0x1,%rax
  a3cd7c:	ja     a3cfe3 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x953>
  a3cd82:	mov    0xaf0947(%rip),%r13        # 152d6d0 <_DYNAMIC+0x1390>
  a3cd89:	movzbl 0x10(%r13),%eax
  a3cd8e:	movzbl %al,%ecx
  a3cd91:	lea    -0x1(%rcx),%edx
  a3cd94:	cmp    $0x2,%edx
  a3cd97:	jae    a3cfdb <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x94b>
  a3cd9d:	mov    0x0(%r13),%rdi
  a3cda1:	movzbl %al,%esi
  a3cda4:	call   *0xaf040e(%rip)        # 152d1b8 <_DYNAMIC+0xe78>
  a3cdaa:	test   %al,%al
  a3cdac:	je     a3cfe3 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x953>
  a3cdb2:	mov    0x0(%r13),%rsi
  a3cdb6:	lea    0x30(%rsi),%rax
  a3cdba:	movq   $0x1,0x800(%rsp)
  a3cdc6:	movq   $0x8,0x808(%rsp)
  a3cdd2:	movq   $0x0,0x810(%rsp)
  a3cdde:	mov    %rax,0x818(%rsp)
  a3cde6:	lea    0x250(%rsp),%rdi
  a3cdee:	lea    0x800(%rsp),%rdx
  a3cdf6:	call   *0xaf0494(%rip)        # 152d290 <_DYNAMIC+0xf50>
  a3cdfc:	cmpq   $0x2,0x250(%rsp)
  a3ce05:	je     a3cffb <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x96b>
  a3ce0b:	lea    0x268(%rsp),%rsi
  a3ce13:	lea    0x250(%rsp),%rdi
  a3ce1b:	call   *0xaf0477(%rip)        # 152d298 <_DYNAMIC+0xf58>
  a3ce21:	jmp    a3cffb <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x96b>
  a3ce26:	cmpl   $0xffffffff,0x10(%r14)
  a3ce2b:	setne  %cl
  a3ce2e:	mov    (%r14),%rax
  a3ce31:	test   %al,%cl
  a3ce33:	je     a3d54b <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xebb>
  a3ce39:	lea    0x10(%r14),%r15
  a3ce3d:	lea    0x8(%r14),%rdx
  a3ce41:	lea    0x800(%rsp),%rdi
  a3ce49:	mov    %r15,%rsi
  a3ce4c:	call   9e5c90 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>>
  a3ce51:	cmpl   $0xfffffffc,0x800(%rsp)
  a3ce59:	jne    a3cec3 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x833>
  a3ce5b:	mov    %r15,%rdi
  a3ce5e:	call   a345d0 <core::ptr::drop_glue::<core::option::Option<gpui::native::accessibility::Bridge>>>
  a3ce63:	lea    0x808(%rsp),%r12
  a3ce6b:	movq   $0xffffffffffffffff,0x10(%r14)
  a3ce73:	lea    0xf8(%r14),%r15
  a3ce7a:	cmpl   $0xfffffffe,0xf8(%r14)
  a3ce82:	je     a3ce8c <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x7fc>
  a3ce84:	mov    %r15,%rdi
  a3ce87:	call   a36f00 <core::ptr::drop_glue::<gpui::native::NativeError>>
  a3ce8c:	mov    0x30(%r12),%rax
  a3ce91:	mov    %rax,0x30(%r15)
  a3ce95:	movupd (%r12),%xmm0
  a3ce9b:	movupd 0x10(%r12),%xmm1
  a3cea2:	movups 0x20(%r12),%xmm2
  a3cea8:	jmp    a3c796 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x106>
  a3cead:	jg     a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3ceb3:	movl   $0xffffffff,0x180(%r14)
  a3cebe:	jmp    a3dbbf <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x152f>
  a3cec3:	lea    0x268(%rsp),%rdi
  a3cecb:	lea    0x800(%rsp),%rsi
  a3ced3:	mov    $0x380,%edx
  a3ced8:	call   *0xaef6c2(%rip)        # 152c5a0 <memcpy@GLIBC_2.14>
  a3cede:	movq   $0x1,0x250(%rsp)
  a3ceea:	movq   $0x10,0x260(%rsp)
  a3cef6:	movq   $0xfffffffffffffffc,0x5e8(%rsp)
  a3cf02:	movq   $0xfffffffffffffffc,0x620(%rsp)
  a3cf0e:	lea    0x108(%rsp),%rbp
  a3cf16:	lea    0x270(%rsp),%r15
  a3cf1e:	xor    %r13d,%r13d
  a3cf21:	lea    0x100(%rsp),%r12
  a3cf29:	mov    -0x8(%r15),%rax
  a3cf2d:	cmp    $0xfffffffffffffffd,%rax
  a3cf31:	je     a3cf84 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x8f4>
  a3cf33:	cmp    $0xfffffffffffffffc,%rax
  a3cf37:	je     a3d530 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xea0>
  a3cf3d:	movupd (%r15),%xmm0
  a3cf42:	movupd 0x10(%r15),%xmm1
  a3cf48:	movups 0x20(%r15),%xmm2
  a3cf4d:	movups %xmm2,0x20(%rbp)
  a3cf51:	movupd %xmm1,0x10(%rbp)
  a3cf56:	movupd %xmm0,0x0(%rbp)
  a3cf5b:	mov    %rax,0x100(%rsp)
  a3cf63:	lea    0x6b0(%rsp),%rdi
  a3cf6b:	mov    %r14,%rsi
  a3cf6e:	mov    %r12,%rdx
  a3cf71:	call   a39ce0 <<gpui::native::NativeHost<empty::Empty>>::input_result>
  a3cf76:	cmpl   $0xfffffffe,0x6b0(%rsp)
  a3cf7e:	jne    a3d63b <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xfab>
  a3cf84:	cmp    $0xf,%r13
  a3cf88:	je     a3cf9d <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x90d>
  a3cf8a:	add    $0x38,%r15
  a3cf8e:	inc    %r13
  a3cf91:	mov    -0x8(%r15),%rax
  a3cf95:	cmp    $0xfffffffffffffffd,%rax
  a3cf99:	jne    a3cf33 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x8a3>
  a3cf9b:	jmp    a3cf84 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x8f4>
  a3cf9d:	mov    $0x10,%r13d
  a3cfa3:	jmp    a3d533 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xea3>
  a3cfa8:	mov    $0xd,%r15d
  a3cfae:	cmpl   $0xfffffffe,0xf8(%r14)
  a3cfb6:	je     a3cfc4 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x934>
  a3cfb8:	lea    0xf8(%r14),%rdi
  a3cfbf:	call   a36f00 <core::ptr::drop_glue::<gpui::native::NativeError>>
  a3cfc4:	mov    %r15,0xf8(%r14)
  a3cfcb:	movq   $0x0,0x100(%r14)
  a3cfd6:	jmp    a3dc7d <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x15ed>
  a3cfdb:	test   %ecx,%ecx
  a3cfdd:	jne    a3e01d <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x198d>
  a3cfe3:	movq   $0x2,0x250(%rsp)
  a3cfef:	movq   $0x0,0x270(%rsp)
  a3cffb:	mov    0x270(%rsp),%rax
  a3d003:	mov    %rax,0x820(%rsp)
  a3d00b:	mov    0x250(%rsp),%rax
  a3d013:	mov    0x258(%rsp),%rcx
  a3d01b:	movupd 0x260(%rsp),%xmm0
  a3d024:	movapd %xmm0,0x810(%rsp)
  a3d02d:	mov    %rax,0x800(%rsp)
  a3d035:	mov    %rcx,0x808(%rsp)
  a3d03d:	mov    0x10(%r12),%rax
  a3d042:	mov    0x310(%rax),%r12d
  a3d049:	lea    0x800(%rsp),%rdi
  a3d051:	call   a36d90 <core::ptr::drop_glue::<tracing::span::EnteredSpan>>
  a3d056:	cmp    %r12,0x10(%r15)
  a3d05a:	jne    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3d060:	mov    0x8(%r15),%r15
  a3d064:	cmpl   $0xffffffff,0x10(%r14)
  a3d069:	je     a3d088 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x9f8>
  a3d06b:	mov    0x1d8(%r14),%rsi
  a3d072:	test   %rsi,%rsi
  a3d075:	je     a3d088 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x9f8>
  a3d077:	lea    0x10(%r14),%rdi
  a3d07b:	add    $0x10,%rsi
  a3d07f:	mov    %r15,%rdx
  a3d082:	call   *0xaf0650(%rip)        # 152d6d8 <_DYNAMIC+0x1398>
  a3d088:	movzwl (%r15),%eax
  a3d08c:	mov    %eax,%ecx
  a3d08e:	sub    $0x4,%cx
  a3d092:	mov    $0x9,%edx
  a3d097:	cmovae %ecx,%edx
  a3d09a:	movzwl %dx,%ecx
  a3d09d:	dec    %ecx
  a3d09f:	cmp    $0x1a,%ecx
  a3d0a2:	ja     a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3d0a8:	lea    -0x8a43d3(%rip),%rdx        # 198cdc <anon.7cc7c74d1b8f8dfb5e74abfe8b727cdb.77.llvm.18220644203745900989+0x4e8>
  a3d0af:	movslq (%rdx,%rcx,4),%rcx
  a3d0b3:	add    %rdx,%rcx
  a3d0b6:	jmp    *%rcx
  a3d0b8:	mov    0x4(%r15),%rdx
  a3d0bc:	jmp    a3d803 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1173>
  a3d0c1:	test   %ecx,%ecx
  a3d0c3:	jne    a3e037 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x19a7>
  a3d0c9:	movq   $0x2,0x40(%rsp)
  a3d0d2:	movq   $0x0,0x60(%rsp)
  a3d0db:	mov    0x60(%rsp),%rax
  a3d0e0:	mov    %rax,0xf0(%rsp)
  a3d0e8:	mov    0x40(%rsp),%rax
  a3d0ed:	mov    0x48(%rsp),%rcx
  a3d0f2:	movupd 0x50(%rsp),%xmm0
  a3d0f8:	movapd %xmm0,0xe0(%rsp)
  a3d101:	mov    %rax,0xd0(%rsp)
  a3d109:	mov    %rcx,0xd8(%rsp)
  a3d111:	lea    0x250(%rsp),%r13
  a3d119:	lea    0x800(%rsp),%rsi
  a3d121:	mov    $0x210,%edx
  a3d126:	mov    %r13,%rdi
  a3d129:	call   *0xaef471(%rip)        # 152c5a0 <memcpy@GLIBC_2.14>
  a3d12f:	lea    0x100(%rsp),%rdi
  a3d137:	mov    %rbx,%rsi
  a3d13a:	mov    %r13,%rdx
  a3d13d:	call   *0xaf059d(%rip)        # 152d6e0 <_DYNAMIC+0x13a0>
  a3d143:	mov    0x100(%rsp),%r15
  a3d14b:	cmp    $0xffffffffffffffff,%r15
  a3d14f:	je     a3d185 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xaf5>
  a3d151:	mov    0x130(%rsp),%rax
  a3d159:	mov    %rax,0x240(%rsp)
  a3d161:	movupd 0x110(%rsp),%xmm0
  a3d16a:	movupd 0x120(%rsp),%xmm1
  a3d173:	movapd %xmm1,0x230(%rsp)
  a3d17c:	movapd %xmm0,0x220(%rsp)
  a3d185:	mov    0x108(%rsp),%r13
  a3d18d:	lea    0xd0(%rsp),%rdi
  a3d195:	call   a36d90 <core::ptr::drop_glue::<tracing::span::EnteredSpan>>
  a3d19a:	cmp    $0xffffffffffffffff,%r15
  a3d19e:	je     a3d293 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xc03>
  a3d1a4:	mov    %r15,0x250(%rsp)
  a3d1ac:	mov    %r13,0x258(%rsp)
  a3d1b4:	movapd 0x220(%rsp),%xmm0
  a3d1bd:	movapd 0x230(%rsp),%xmm1
  a3d1c6:	movupd %xmm0,0x260(%rsp)
  a3d1cf:	movupd %xmm1,0x270(%rsp)
  a3d1d8:	mov    0x240(%rsp),%rax
  a3d1e0:	mov    %rax,0x280(%rsp)
  a3d1e8:	movq   $0x0,0x40(%rsp)
  a3d1f1:	movq   $0x1,0x48(%rsp)
  a3d1fa:	movq   $0x0,0x50(%rsp)
  a3d203:	movq   $0x60000020,0x110(%rsp)
  a3d20f:	lea    0x40(%rsp),%rax
  a3d214:	mov    %rax,0x100(%rsp)
  a3d21c:	lea    0xa7f20d(%rip),%rax        # 14bc430 <anon.f48bbd6ee32d24e1254dac28089ef4b7.58.llvm.17379179981059708172>
  a3d223:	mov    %rax,0x108(%rsp)
  a3d22b:	lea    0x250(%rsp),%rdi
  a3d233:	lea    0x100(%rsp),%rsi
  a3d23b:	call   *0xaf04a7(%rip)        # 152d6e8 <_DYNAMIC+0x13a8>
  a3d241:	test   %al,%al
  a3d243:	jne    a3df82 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x18f2>
  a3d249:	mov    0x40(%rsp),%r13
  a3d24e:	mov    0x48(%rsp),%r12
  a3d253:	mov    0x50(%rsp),%r15
  a3d258:	lea    0x250(%rsp),%rdi
  a3d260:	call   a36000 <core::ptr::drop_glue::<winit::error::OsError>>
  a3d265:	mov    $0x2d,%ebp
  a3d26a:	mov    0xb8(%rsp),%rsi
  a3d272:	test   %rsi,%rsi
  a3d275:	je     a3c99b <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x30b>
  a3d27b:	mov    0xc0(%rsp),%rdi
  a3d283:	mov    $0x1,%edx
  a3d288:	call   *0xaef302(%rip)        # 152c590 <_DYNAMIC+0x250>
  a3d28e:	jmp    a3c99b <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x30b>
  a3d293:	movq   $0x1,0x250(%rsp)
  a3d29f:	movq   $0x1,0x258(%rsp)
  a3d2ab:	mov    %r13,0x260(%rsp)
  a3d2b3:	call   *0xaef2c7(%rip)        # 152c580 <_DYNAMIC+0x240>
  a3d2b9:	mov    $0x18,%edi
  a3d2be:	mov    $0x8,%esi
  a3d2c3:	call   *0xaef2bf(%rip)        # 152c588 <_DYNAMIC+0x248>
  a3d2c9:	test   %rax,%rax
  a3d2cc:	je     a3dfc5 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1935>
  a3d2d2:	mov    %rax,%rcx
  a3d2d5:	mov    0x260(%rsp),%rdx
  a3d2dd:	mov    %rdx,0x10(%rax)
  a3d2e1:	movups 0x250(%rsp),%xmm0
  a3d2e9:	movups %xmm0,(%rax)
  a3d2ec:	add    $0x10,%rax
  a3d2f0:	mov    %rcx,0x30(%rsp)
  a3d2f5:	mov    %rax,%rdi
  a3d2f8:	call   a3bc10 <<winit::window::Window>::inner_size>
  a3d2fd:	cmp    $0x1,%eax
  a3d300:	adc    $0x0,%eax
  a3d303:	cmp    $0x1,%edx
  a3d306:	adc    $0x0,%edx
  a3d309:	mov    %eax,0x110(%rsp)
  a3d310:	mov    %edx,0x114(%rsp)
  a3d317:	movl   $0x0,0x100(%rsp)
  a3d322:	movl   $0x434b0000,0x108(%rsp)
  a3d32d:	movw   $0x0,0x10c(%rsp)
  a3d337:	mov    0x30(%rsp),%rdi
  a3d33c:	add    $0x10,%rdi
  a3d340:	call   a38880 <<winit::window::Window>::scale_factor>
  a3d345:	cvtsd2ss %xmm0,%xmm0
  a3d349:	movzbl 0xb0(%rsp),%edx
  a3d351:	lea    0x250(%rsp),%rdi
  a3d359:	lea    0x100(%rsp),%rsi
  a3d361:	call   9c2780 <<gpui::runtime::Win<empty::Empty>>::recording_lanes>
  a3d366:	mov    0x250(%rsp),%rbp
  a3d36e:	mov    0x258(%rsp),%r13
  a3d376:	cmp    $0xfffffffffffffffe,%rbp
  a3d37a:	jne    a3d501 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xe71>
  a3d380:	mov    0xc0(%r14),%rax
  a3d387:	cmp    $0xffffffffffffffff,%rax
  a3d38b:	sete   %bpl
  a3d38f:	cmp    $0xffffffff,%eax
  a3d392:	je     a3d758 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x10c8>
  a3d398:	mov    %ebp,0x8(%rsp)
  a3d39c:	mov    0x30(%rsp),%rbp
  a3d3a1:	mov    0xd8(%r14),%r15
  a3d3a8:	lock incq (%r15)
  a3d3ac:	jle    a3e079 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x19e9>
  a3d3b2:	lea    0xc0(%r14),%rsi
  a3d3b9:	mov    %r15,0xd0(%rsp)
  a3d3c1:	lea    0x40(%rsp),%rdi
  a3d3c6:	call   a449f0 <<winit::platform_impl::linux::x11::WakeSender<()> as core::clone::Clone>::clone>
  a3d3cb:	add    $0x10,%rbp
  a3d3cf:	movups 0x40(%rsp),%xmm0
  a3d3d4:	mov    0x50(%rsp),%rax
  a3d3d9:	movups %xmm0,0x690(%rsp)
  a3d3e1:	mov    %rax,0x6a0(%rsp)
  a3d3e9:	mov    %r15,0x6a8(%rsp)
  a3d3f1:	mov    0xc8(%rsp),%rax
  a3d3f9:	mov    %rax,0x50(%rsp)
  a3d3fe:	movups 0xb8(%rsp),%xmm0
  a3d406:	movaps %xmm0,0x40(%rsp)
  a3d40b:	lea    0x250(%rsp),%rdi
  a3d413:	lea    0x690(%rsp),%rcx
  a3d41b:	lea    0x40(%rsp),%r8
  a3d420:	mov    %rbx,%rsi
  a3d423:	mov    %rbp,%rdx
  a3d426:	call   *0xaf02c4(%rip)        # 152d6f0 <_DYNAMIC+0x13b0>
  a3d42c:	lea    0x100(%rsp),%rdi
  a3d434:	lea    0x250(%rsp),%rsi
  a3d43c:	mov    $0xb0,%edx
  a3d441:	call   *0xaef159(%rip)        # 152c5a0 <memcpy@GLIBC_2.14>
  a3d447:	lea    0x10(%r14),%rbp
  a3d44b:	mov    %rbp,%rdi
  a3d44e:	call   a345d0 <core::ptr::drop_glue::<core::option::Option<gpui::native::accessibility::Bridge>>>
  a3d453:	lea    0x100(%rsp),%rsi
  a3d45b:	mov    $0xb0,%edx
  a3d460:	mov    %rbp,%rdi
  a3d463:	call   *0xaef137(%rip)        # 152c5a0 <memcpy@GLIBC_2.14>
  a3d469:	cmpq   $0x0,(%r14)
  a3d46d:	je     a3d478 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xde8>
  a3d46f:	mov    0x8(%r14),%rdi
  a3d473:	call   a35160 <core::ptr::drop_glue::<gpui::runtime::Win<empty::Empty>>>
  a3d478:	movq   $0x1,(%r14)
  a3d47f:	mov    %r13,0x8(%r14)
  a3d483:	mov    0x30(%rsp),%r13
  a3d488:	lea    0x1d8(%r14),%r15
  a3d48f:	mov    0x1d8(%r14),%rax
  a3d496:	test   %rax,%rax
  a3d499:	je     a3d4aa <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xe1a>
  a3d49b:	lock decq (%rax)
  a3d49f:	jne    a3d4aa <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xe1a>
  a3d4a1:	mov    %r15,%rdi
  a3d4a4:	call   *0xaefb6e(%rip)        # 152d018 <_DYNAMIC+0xcd8>
  a3d4aa:	mov    %r13,(%r15)
  a3d4ad:	cmpw   $0x2,(%r12)
  a3d4b3:	jne    a3d4d7 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xe47>
  a3d4b5:	lea    0x250(%rsp),%rdi
  a3d4bd:	mov    %r14,%rsi
  a3d4c0:	call   a3a1b0 <<gpui::native::NativeHost<empty::Empty>>::create_surface>
  a3d4c5:	mov    0x250(%rsp),%rbp
  a3d4cd:	cmp    $0xfffffffffffffffe,%rbp
  a3d4d1:	jne    a3de48 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x17b8>
  a3d4d7:	mov    0x1d8(%r14),%rdi
  a3d4de:	test   %rdi,%rdi
  a3d4e1:	je     a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3d4e7:	add    $0x10,%rdi
  a3d4eb:	mov    $0x1,%esi
  a3d4f0:	call   a3bd90 <<winit::window::Window>::set_visible>
  a3d4f5:	mov    0x1d8(%r14),%rdi
  a3d4fc:	jmp    a3dbd5 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1545>
  a3d501:	mov    0x260(%rsp),%r12
  a3d509:	mov    0x268(%rsp),%r15
  a3d511:	movups 0x270(%rsp),%xmm0
  a3d519:	movaps %xmm0,0x10(%rsp)
  a3d51e:	mov    0x280(%rsp),%rax
  a3d526:	mov    %rax,0x20(%rsp)
  a3d52b:	jmp    a3d7c2 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1132>
  a3d530:	inc    %r13
  a3d533:	mov    %r13,0x258(%rsp)
  a3d53b:	lea    0x250(%rsp),%rdi
  a3d543:	call   a35850 <core::ptr::drop_glue::<core::iter::adapters::flatten::Flatten<core::array::iter::IntoIter<core::option::Option<core::result::Result<gpui::runtime::Commit, gpui::runtime::Error>>, 16>>>>
  a3d548:	mov    (%r14),%rax
  a3d54b:	test   $0x1,%al
  a3d54d:	je     a3dbb5 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1525>
  a3d553:	mov    0x8(%r14),%rax
  a3d557:	test   %rax,%rax
  a3d55a:	je     a3dfac <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x191c>
  a3d560:	lea    0x8(%r14),%rsi
  a3d564:	mov    0x660(%rax),%r15
  a3d56b:	lea    0x250(%rsp),%rdi
  a3d573:	mov    $0x40,%edx
  a3d578:	call   9b79d0 <<gpui::runtime::Win<empty::Empty>>::deliver_ready>
  a3d57d:	mov    0x250(%rsp),%rax
  a3d585:	cmp    $0xffffffffffffffff,%rax
  a3d589:	je     a3d5f6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xf66>
  a3d58b:	cmp    $0x2,%eax
  a3d58e:	je     a3d5ad <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xf1d>
  a3d590:	cmp    %r15,0x260(%rsp)
  a3d598:	jbe    a3d5ad <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xf1d>
  a3d59a:	mov    0x298(%rsp),%eax
  a3d5a1:	and    $0xfffffffe,%eax
  a3d5a4:	cmp    $0xe,%eax
  a3d5a7:	jne    a3d6b0 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1020>
  a3d5ad:	mov    0x2c8(%rsp),%rax
  a3d5b5:	mov    %rax,0x1e0(%rsp)
  a3d5bd:	movupd 0x298(%rsp),%xmm0
  a3d5c6:	movupd 0x2a8(%rsp),%xmm1
  a3d5cf:	movups 0x2b8(%rsp),%xmm2
  a3d5d7:	movaps %xmm2,0x1d0(%rsp)
  a3d5df:	movapd %xmm1,0x1c0(%rsp)
  a3d5e8:	movapd %xmm0,0x1b0(%rsp)
  a3d5f1:	jmp    a3db8f <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x14ff>
  a3d5f6:	movupd 0x258(%rsp),%xmm0
  a3d5ff:	movupd 0x268(%rsp),%xmm1
  a3d608:	movups 0x278(%rsp),%xmm2
  a3d610:	movups %xmm2,0x1d8(%rsp)
  a3d618:	movupd %xmm1,0x1c8(%rsp)
  a3d621:	movupd %xmm0,0x1b8(%rsp)
  a3d62a:	movq   $0xfffffffffffffffe,0x1b0(%rsp)
  a3d636:	jmp    a3db8f <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x14ff>
  a3d63b:	inc    %r13
  a3d63e:	mov    %r13,0x258(%rsp)
  a3d646:	lea    0xf8(%r14),%r15
  a3d64d:	cmpl   $0xfffffffe,0xf8(%r14)
  a3d655:	je     a3d65f <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xfcf>
  a3d657:	mov    %r15,%rdi
  a3d65a:	call   a36f00 <core::ptr::drop_glue::<gpui::native::NativeError>>
  a3d65f:	mov    0x6e0(%rsp),%rax
  a3d667:	mov    %rax,0x30(%r15)
  a3d66b:	movupd 0x6b0(%rsp),%xmm0
  a3d674:	movupd 0x6c0(%rsp),%xmm1
  a3d67d:	movups 0x6d0(%rsp),%xmm2
  a3d685:	movups %xmm2,0x20(%r15)
  a3d68a:	movupd %xmm1,0x10(%r15)
  a3d690:	movupd %xmm0,(%r15)
  a3d695:	mov    %rbx,%rdi
  a3d698:	call   *0xaf001a(%rip)        # 152d6b8 <_DYNAMIC+0x1378>
  a3d69e:	lea    0x250(%rsp),%rdi
  a3d6a6:	call   a35850 <core::ptr::drop_glue::<core::iter::adapters::flatten::Flatten<core::array::iter::IntoIter<core::option::Option<core::result::Result<gpui::runtime::Commit, gpui::runtime::Error>>, 16>>>>
  a3d6ab:	jmp    a3dc86 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x15f6>
  a3d6b0:	lea    0x298(%rsp),%rax
  a3d6b8:	mov    0x30(%rax),%rcx
  a3d6bc:	mov    %rcx,0xa0(%rsp)
  a3d6c4:	movups (%rax),%xmm0
  a3d6c7:	movups 0x10(%rax),%xmm1
  a3d6cb:	movups 0x20(%rax),%xmm2
  a3d6cf:	movaps %xmm2,0x90(%rsp)
  a3d6d7:	movaps %xmm1,0x80(%rsp)
  a3d6df:	movaps %xmm0,0x70(%rsp)
  a3d6e4:	mov    0x290(%rsp),%rax
  a3d6ec:	mov    %rax,0x840(%rsp)
  a3d6f4:	movups 0x250(%rsp),%xmm0
  a3d6fc:	movups 0x260(%rsp),%xmm1
  a3d704:	movups 0x270(%rsp),%xmm2
  a3d70c:	movups 0x280(%rsp),%xmm3
  a3d714:	movaps %xmm3,0x830(%rsp)
  a3d71c:	movaps %xmm2,0x820(%rsp)
  a3d724:	movaps %xmm1,0x810(%rsp)
  a3d72c:	movaps %xmm0,0x800(%rsp)
  a3d734:	mov    0x1e0(%r14),%rdi
  a3d73b:	test   %rdi,%rdi
  a3d73e:	je     a3dabe <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x142e>
  a3d744:	mov    0x1e8(%r14),%rax
  a3d74b:	lea    0x70(%rsp),%rsi
  a3d750:	call   *0x20(%rax)
  a3d753:	jmp    a3db45 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x14b5>
  a3d758:	call   *0xaeee22(%rip)        # 152c580 <_DYNAMIC+0x240>
  a3d75e:	mov    $0x35,%r15d
  a3d764:	mov    $0x35,%edi
  a3d769:	mov    $0x1,%esi
  a3d76e:	call   *0xaeee14(%rip)        # 152c588 <_DYNAMIC+0x248>
  a3d774:	test   %rax,%rax
  a3d777:	je     a3e065 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x19d5>
  a3d77d:	mov    %rax,%r12
  a3d780:	movups -0x8a49d3(%rip),%xmm0        # 198db4 <anon.7cc7c74d1b8f8dfb5e74abfe8b727cdb.77.llvm.18220644203745900989+0x5c0>
  a3d787:	movups %xmm0,0x20(%rax)
  a3d78b:	movups -0x8a49ee(%rip),%xmm0        # 198da4 <anon.7cc7c74d1b8f8dfb5e74abfe8b727cdb.77.llvm.18220644203745900989+0x5b0>
  a3d792:	movups %xmm0,0x10(%rax)
  a3d796:	movups -0x8a4a09(%rip),%xmm0        # 198d94 <anon.7cc7c74d1b8f8dfb5e74abfe8b727cdb.77.llvm.18220644203745900989+0x5a0>
  a3d79d:	movups %xmm0,(%rax)
  a3d7a0:	movabs $0x656b617720726576,%rax
  a3d7aa:	mov    %rax,0x2d(%r12)
  a3d7af:	mov    $0x2d,%ebp
  a3d7b4:	mov    %r13,%rdi
  a3d7b7:	call   a35160 <core::ptr::drop_glue::<gpui::runtime::Win<empty::Empty>>>
  a3d7bc:	mov    $0x35,%r13d
  a3d7c2:	mov    0x30(%rsp),%rax
  a3d7c7:	lock decq (%rax)
  a3d7cb:	jne    a3d26a <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xbda>
  a3d7d1:	lea    0x30(%rsp),%rdi
  a3d7d6:	call   *0xaef83c(%rip)        # 152d018 <_DYNAMIC+0xcd8>
  a3d7dc:	jmp    a3d26a <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xbda>
  a3d7e1:	mov    0x1d8(%r14),%rdi
  a3d7e8:	test   %rdi,%rdi
  a3d7eb:	je     a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3d7f1:	add    $0x10,%rdi
  a3d7f5:	call   a3bc10 <<winit::window::Window>::inner_size>
  a3d7fa:	shl    $0x20,%rdx
  a3d7fe:	mov    %eax,%eax
  a3d800:	or     %rax,%rdx
  a3d803:	lea    0x250(%rsp),%rdi
  a3d80b:	mov    %r14,%rsi
  a3d80e:	call   a3b930 <<gpui::native::NativeHost<empty::Empty>>::resize>
  a3d813:	jmp    a3de36 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x17a6>
  a3d818:	cmpb   $0x0,0x82(%r15)
  a3d820:	jne    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3d826:	cmpb   $0x0,0x78(%r15)
  a3d82b:	jne    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3d831:	movzbl 0x60(%r15),%esi
  a3d836:	cmp    $0xff,%rsi
  a3d83d:	je     a3de05 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1775>
  a3d843:	lea    -0x17(%rsi),%rdx
  a3d847:	xor    %ecx,%ecx
  a3d849:	cmp    $0x18,%sil
  a3d84d:	cmovae %rdx,%rcx
  a3d851:	test   %rcx,%rcx
  a3d854:	je     a3de81 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x17f1>
  a3d85a:	cmp    $0x1,%ecx
  a3d85d:	jne    a3de91 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1801>
  a3d863:	mov    0x68(%r15),%rcx
  a3d867:	mov    0x70(%r15),%rsi
  a3d86b:	jmp    a3de9d <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x180d>
  a3d870:	lea    0x250(%rsp),%rdi
  a3d878:	mov    %r14,%rsi
  a3d87b:	call   a3adf0 <<gpui::native::NativeHost<empty::Empty>>::redraw>
  a3d880:	jmp    a3de36 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x17a6>
  a3d885:	mov    0x4(%r15),%eax
  a3d889:	mov    %eax,0x200(%r14)
  a3d890:	jmp    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3d895:	movb   $0x1,0x205(%r14)
  a3d89d:	movzbl 0x2(%r15),%eax
  a3d8a2:	mov    %al,0x204(%r14)
  a3d8a9:	test   %al,%al
  a3d8ab:	jne    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3d8b1:	mov    0x1d8(%r14),%rdi
  a3d8b8:	test   %rdi,%rdi
  a3d8bb:	jne    a3dbd5 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1545>
  a3d8c1:	jmp    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3d8c6:	cmpb   $0x0,0x2(%r15)
  a3d8cb:	jne    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3d8d1:	mov    $0xffffffff,%eax
  a3d8d6:	mov    %rax,0x1b0(%r14)
  a3d8dd:	movq   $0x0,0x1b8(%r14)
  a3d8e8:	cmpl   $0x1,(%r14)
  a3d8ec:	jne    a3d927 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1297>
  a3d8ee:	lea    0x8(%r14),%rsi
  a3d8f2:	lea    0x800(%rsp),%r15
  a3d8fa:	mov    %r15,%rdi
  a3d8fd:	call   9b9490 <<gpui::runtime::Win<empty::Empty>>::clear_focus>
  a3d902:	lea    0x250(%rsp),%rdi
  a3d90a:	mov    %r14,%rsi
  a3d90d:	mov    %r15,%rdx
  a3d910:	call   a39ce0 <<gpui::native::NativeHost<empty::Empty>>::input_result>
  a3d915:	mov    0x250(%rsp),%rbp
  a3d91d:	cmp    $0xfffffffffffffffe,%rbp
  a3d921:	jne    a3de48 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x17b8>
  a3d927:	movl   $0x0,0x200(%r14)
  a3d932:	jmp    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3d937:	mov    %r14,%rdi
  a3d93a:	call   a39e60 <<gpui::native::NativeHost<empty::Empty>>::retire_window>
  a3d93f:	jmp    a3c9e8 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x358>
  a3d944:	mov    $0xffffffff,%eax
  a3d949:	mov    %rax,0x1b0(%r14)
  a3d950:	movq   $0x0,0x1b8(%r14)
  a3d95b:	jmp    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3d960:	cmpl   $0x1,(%r14)
  a3d964:	jne    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3d96a:	movupd 0x8(%r15),%xmm0
  a3d970:	cvtpd2ps %xmm0,%xmm0
  a3d974:	lea    0x8(%r14),%rsi
  a3d978:	lea    0x1b0(%r14),%rdx
  a3d97f:	movl   $0x0,0x800(%rsp)
  a3d98a:	movlpd %xmm0,0x804(%rsp)
  a3d993:	lea    0x720(%rsp),%rdi
  a3d99b:	lea    0x800(%rsp),%rcx
  a3d9a3:	call   9b94e0 <<gpui::runtime::Win<empty::Empty>>::pointer_event>
  a3d9a8:	mov    0x720(%rsp),%rax
  a3d9b0:	cmp    $0xfffffffffffffffe,%rax
  a3d9b4:	jne    a3ddb3 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1723>
  a3d9ba:	cmpq   $0x0,0x748(%rsp)
  a3d9c3:	jne    a3ddca <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x173a>
  a3d9c9:	jmp    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3d9ce:	cmpl   $0x1,(%r14)
  a3d9d2:	jne    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3d9d8:	lea    0x8(%r14),%rsi
  a3d9dc:	lea    0x1b0(%r14),%rdx
  a3d9e3:	movl   $0x1,0x800(%rsp)
  a3d9ee:	lea    0x758(%rsp),%rdi
  a3d9f6:	lea    0x800(%rsp),%rcx
  a3d9fe:	call   9b94e0 <<gpui::runtime::Win<empty::Empty>>::pointer_event>
  a3da03:	mov    0x758(%rsp),%rax
  a3da0b:	cmp    $0xfffffffffffffffe,%rax
  a3da0f:	jne    a3dddc <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x174c>
  a3da15:	cmpq   $0x0,0x780(%rsp)
  a3da1e:	jne    a3ddf3 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1763>
  a3da24:	jmp    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3da29:	cmpw   $0x0,0x2(%r15)
  a3da2f:	jne    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3da35:	cmpl   $0x1,(%r14)
  a3da39:	jne    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3da3f:	cmpb   $0x1,0x8(%r15)
  a3da44:	mov    $0x3,%eax
  a3da49:	sbb    $0x0,%eax
  a3da4c:	lea    0x8(%r14),%rsi
  a3da50:	lea    0x1b0(%r14),%rdx
  a3da57:	mov    %eax,0x800(%rsp)
  a3da5e:	lea    0x7c8(%rsp),%rdi
  a3da66:	lea    0x800(%rsp),%rcx
  a3da6e:	call   9b94e0 <<gpui::runtime::Win<empty::Empty>>::pointer_event>
  a3da73:	mov    0x7c8(%rsp),%rax
  a3da7b:	cmp    $0xfffffffffffffffe,%rax
  a3da7f:	je     a3de1e <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x178e>
  a3da85:	cmp    $0x19,%eax
  a3da88:	jne    a3de1e <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x178e>
  a3da8e:	lea    0x7c8(%rsp),%rdi
  a3da96:	call   a36fa0 <core::ptr::drop_glue::<gpui::runtime::Error>>
  a3da9b:	jmp    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3daa0:	mov    0x1d8(%r14),%rdi
  a3daa7:	test   %rdi,%rdi
  a3daaa:	je     a3dcdc <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x164c>
  a3dab0:	add    $0x10,%rdi
  a3dab4:	call   a38880 <<winit::window::Window>::scale_factor>
  a3dab9:	jmp    a3dce4 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1654>
  a3dabe:	lea    0x838(%rsp),%rax
  a3dac6:	lea    0x810(%rsp),%rcx
  a3dace:	lea    0x818(%rsp),%rdx
  a3dad6:	mov    %rax,0x100(%rsp)
  a3dade:	mov    0xaef0bb(%rip),%rax        # 152cba0 <_DYNAMIC+0x860>
  a3dae5:	mov    %rax,0x108(%rsp)
  a3daed:	mov    %rcx,0x110(%rsp)
  a3daf5:	mov    0xaeedbc(%rip),%rax        # 152c8b8 <_DYNAMIC+0x578>
  a3dafc:	mov    %rax,0x118(%rsp)
  a3db04:	mov    %rdx,0x120(%rsp)
  a3db0c:	mov    %rax,0x128(%rsp)
  a3db14:	lea    0x70(%rsp),%rax
  a3db19:	mov    %rax,0x130(%rsp)
  a3db21:	mov    0xaefb00(%rip),%rax        # 152d628 <_DYNAMIC+0x12e8>
  a3db28:	mov    %rax,0x138(%rsp)
  a3db30:	lea    -0x8d2eac(%rip),%rdi        # 16ac8b <anon.2277df3ceaea8d4be421179083a68ea6.39.llvm.213539347725472506+0x12e>
  a3db37:	lea    0x100(%rsp),%rsi
  a3db3f:	call   *0xaefa2b(%rip)        # 152d570 <_DYNAMIC+0x1230>
  a3db45:	movapd 0x800(%rsp),%xmm0
  a3db4e:	movapd 0x810(%rsp),%xmm1
  a3db57:	movaps 0x820(%rsp),%xmm2
  a3db5f:	movups %xmm2,0x1d8(%rsp)
  a3db67:	movupd %xmm1,0x1c8(%rsp)
  a3db70:	movupd %xmm0,0x1b8(%rsp)
  a3db79:	movq   $0xfffffffffffffffe,0x1b0(%rsp)
  a3db85:	lea    0x70(%rsp),%rdi
  a3db8a:	call   a36fa0 <core::ptr::drop_glue::<gpui::runtime::Error>>
  a3db8f:	lea    0x6e8(%rsp),%rdi
  a3db97:	lea    0x1b0(%rsp),%rdx
  a3db9f:	mov    %r14,%rsi
  a3dba2:	call   a39ce0 <<gpui::native::NativeHost<empty::Empty>>::input_result>
  a3dba7:	cmpl   $0xfffffffe,0x6e8(%rsp)
  a3dbaf:	jne    a3dc98 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1608>
  a3dbb5:	cmpl   $0xffffffff,0xe0(%r14)
  a3dbbd:	je     a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3dbbf:	mov    0x1d8(%r14),%rdi
  a3dbc6:	test   %rdi,%rdi
  a3dbc9:	sete   %al
  a3dbcc:	or     0x204(%r14),%al
  a3dbd3:	jne    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3dbd5:	add    $0x10,%rdi
  a3dbd9:	call   a38a10 <<winit::window::Window>::request_redraw>
  a3dbde:	cmpl   $0xfffffffe,0xf8(%r14)
  a3dbe6:	jne    a3dc86 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x15f6>
  a3dbec:	cmpl   $0xffffffff,0x10(%r14)
  a3dbf1:	je     a3dc86 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x15f6>
  a3dbf7:	cmpb   $0x0,(%r14)
  a3dbfb:	je     a3dc86 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x15f6>
  a3dc01:	lea    0x10(%r14),%r15
  a3dc05:	lea    0x8(%r14),%rdx
  a3dc09:	lea    0x658(%rsp),%rdi
  a3dc11:	mov    %r15,%rsi
  a3dc14:	call   9e46e0 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>>
  a3dc19:	cmpl   $0xfffffffe,0x658(%rsp)
  a3dc21:	je     a3dc86 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x15f6>
  a3dc23:	mov    %r15,%rdi
  a3dc26:	call   a345d0 <core::ptr::drop_glue::<core::option::Option<gpui::native::accessibility::Bridge>>>
  a3dc2b:	add    $0xf8,%r14
  a3dc32:	movq   $0xffffffffffffffff,(%r15)
  a3dc39:	cmpl   $0xfffffffe,(%r14)
  a3dc3d:	je     a3dc47 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x15b7>
  a3dc3f:	mov    %r14,%rdi
  a3dc42:	call   a36f00 <core::ptr::drop_glue::<gpui::native::NativeError>>
  a3dc47:	mov    0x688(%rsp),%rax
  a3dc4f:	mov    %rax,0x30(%r14)
  a3dc53:	movupd 0x658(%rsp),%xmm0
  a3dc5c:	movupd 0x668(%rsp),%xmm1
  a3dc65:	movups 0x678(%rsp),%xmm2
  a3dc6d:	movups %xmm2,0x20(%r14)
  a3dc72:	movupd %xmm1,0x10(%r14)
  a3dc78:	movupd %xmm0,(%r14)
  a3dc7d:	mov    %rbx,%rdi
  a3dc80:	call   *0xaefa32(%rip)        # 152d6b8 <_DYNAMIC+0x1378>
  a3dc86:	add    $0xb88,%rsp
  a3dc8d:	pop    %rbx
  a3dc8e:	pop    %r12
  a3dc90:	pop    %r13
  a3dc92:	pop    %r14
  a3dc94:	pop    %r15
  a3dc96:	pop    %rbp
  a3dc97:	ret
  a3dc98:	lea    0xf8(%r14),%r15
  a3dc9f:	cmpl   $0xfffffffe,0xf8(%r14)
  a3dca7:	je     a3dcb1 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1621>
  a3dca9:	mov    %r15,%rdi
  a3dcac:	call   a36f00 <core::ptr::drop_glue::<gpui::native::NativeError>>
  a3dcb1:	mov    0x718(%rsp),%rax
  a3dcb9:	mov    %rax,0x30(%r15)
  a3dcbd:	movupd 0x6e8(%rsp),%xmm0
  a3dcc6:	movupd 0x6f8(%rsp),%xmm1
  a3dccf:	movups 0x708(%rsp),%xmm2
  a3dcd7:	jmp    a3c796 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x106>
  a3dcdc:	movsd  -0x8af2ec(%rip),%xmm0        # 18e9f8 <anon.822e710a3ac147487bb68930a699e853.84.llvm.7311037932848680773+0x20>
  a3dce4:	cmpb   $0x0,0x8(%r15)
  a3dce9:	je     a3dd03 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1673>
  a3dceb:	movupd 0x10(%r15),%xmm1
  a3dcf1:	xorpd  -0x8b0899(%rip),%xmm1        # 18d460 <anon.822e710a3ac147487bb68930a699e853.89.llvm.7311037932848680773+0xd0>
  a3dcf9:	unpcklpd %xmm0,%xmm0
  a3dcfd:	divpd  %xmm0,%xmm1
  a3dd01:	jmp    a3dd10 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1680>
  a3dd03:	cvtps2pd 0xc(%r15),%xmm1
  a3dd08:	mulpd  -0x8b2180(%rip),%xmm1        # 18bb90 <anon.5ee778dbc9410921a725c4c57b32111b.58.llvm.8966071514708437312+0x120>
  a3dd10:	movq   %xmm1,%rax
  a3dd15:	movabs $0x7fffffffffffffff,%rcx
  a3dd1f:	and    %rcx,%rax
  a3dd22:	movabs $0x7fefffffffffffff,%rdx
  a3dd2c:	cmp    %rdx,%rax
  a3dd2f:	setg   %al
  a3dd32:	movdqa %xmm1,%xmm0
  a3dd36:	punpckhqdq %xmm1,%xmm0
  a3dd3a:	movq   %xmm0,%rsi
  a3dd3f:	and    %rcx,%rsi
  a3dd42:	cmp    %rdx,%rsi
  a3dd45:	setg   %cl
  a3dd48:	or     %al,%cl
  a3dd4a:	jne    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3dd50:	cmpl   $0x1,(%r14)
  a3dd54:	jne    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3dd5a:	lea    0x8(%r14),%rsi
  a3dd5e:	lea    0x1b0(%r14),%rdx
  a3dd65:	movl   $0x4,0x800(%rsp)
  a3dd70:	movupd %xmm1,0x808(%rsp)
  a3dd79:	lea    0x790(%rsp),%rdi
  a3dd81:	lea    0x800(%rsp),%rcx
  a3dd89:	call   9b94e0 <<gpui::runtime::Win<empty::Empty>>::pointer_event>
  a3dd8e:	mov    0x790(%rsp),%rax
  a3dd96:	cmp    $0xfffffffffffffffe,%rax
  a3dd9a:	je     a3de0c <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x177c>
  a3dd9c:	cmp    $0x19,%eax
  a3dd9f:	jne    a3de0c <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x177c>
  a3dda1:	lea    0x790(%rsp),%rdi
  a3dda9:	call   a36fa0 <core::ptr::drop_glue::<gpui::runtime::Error>>
  a3ddae:	jmp    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3ddb3:	cmp    $0x19,%eax
  a3ddb6:	jne    a3ddca <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x173a>
  a3ddb8:	lea    0x720(%rsp),%rdi
  a3ddc0:	call   a36fa0 <core::ptr::drop_glue::<gpui::runtime::Error>>
  a3ddc5:	jmp    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3ddca:	lea    0x250(%rsp),%rdi
  a3ddd2:	lea    0x720(%rsp),%rdx
  a3ddda:	jmp    a3de2e <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x179e>
  a3dddc:	cmp    $0x19,%eax
  a3dddf:	jne    a3ddf3 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1763>
  a3dde1:	lea    0x758(%rsp),%rdi
  a3dde9:	call   a36fa0 <core::ptr::drop_glue::<gpui::runtime::Error>>
  a3ddee:	jmp    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3ddf3:	lea    0x250(%rsp),%rdi
  a3ddfb:	lea    0x758(%rsp),%rdx
  a3de03:	jmp    a3de2e <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x179e>
  a3de05:	xor    %ecx,%ecx
  a3de07:	jmp    a3de9d <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x180d>
  a3de0c:	lea    0x250(%rsp),%rdi
  a3de14:	lea    0x790(%rsp),%rdx
  a3de1c:	jmp    a3de2e <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x179e>
  a3de1e:	lea    0x250(%rsp),%rdi
  a3de26:	lea    0x7c8(%rsp),%rdx
  a3de2e:	mov    %r14,%rsi
  a3de31:	call   a39ce0 <<gpui::native::NativeHost<empty::Empty>>::input_result>
  a3de36:	mov    0x250(%rsp),%rbp
  a3de3e:	cmp    $0xfffffffffffffffe,%rbp
  a3de42:	je     a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3de48:	mov    0x258(%rsp),%r13
  a3de50:	mov    0x260(%rsp),%r12
  a3de58:	mov    0x268(%rsp),%r15
  a3de60:	movupd 0x270(%rsp),%xmm0
  a3de69:	movapd %xmm0,0x10(%rsp)
  a3de6f:	mov    0x280(%rsp),%rax
  a3de77:	mov    %rax,0x20(%rsp)
  a3de7c:	jmp    a3c99b <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x30b>
  a3de81:	cmp    $0x18,%sil
  a3de85:	jae    a3e051 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x19c1>
  a3de8b:	lea    0x61(%r15),%rcx
  a3de8f:	jmp    a3de9d <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x180d>
  a3de91:	mov    0x68(%r15),%rcx
  a3de95:	mov    0x70(%r15),%rsi
  a3de99:	add    $0x10,%rcx
  a3de9d:	mov    0x200(%r14),%edx
  a3dea4:	test   $0x820,%edx
  a3deaa:	jne    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3deb0:	cmpl   $0x1,(%r14)
  a3deb4:	jne    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3deba:	test   %ax,%ax
  a3debd:	je     a3df5a <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x18ca>
  a3dec3:	test   %rcx,%rcx
  a3dec6:	je     a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3decc:	mov    %rcx,0x108(%rsp)
  a3ded4:	mov    %rsi,0x110(%rsp)
  a3dedc:	xor    %eax,%eax
  a3dede:	lea    0x8(%r14),%rsi
  a3dee2:	mov    %al,0x100(%rsp)
  a3dee9:	lea    0x250(%rsp),%r15
  a3def1:	lea    0x100(%rsp),%rdx
  a3def9:	mov    %r15,%rdi
  a3defc:	call   9ba170 <<gpui::runtime::Win<empty::Empty>>::key>
  a3df01:	lea    0x800(%rsp),%rdi
  a3df09:	mov    %r14,%rsi
  a3df0c:	mov    %r15,%rdx
  a3df0f:	call   a39ce0 <<gpui::native::NativeHost<empty::Empty>>::input_result>
  a3df14:	mov    0x800(%rsp),%rbp
  a3df1c:	cmp    $0xfffffffffffffffe,%rbp
  a3df20:	je     a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3df26:	mov    0x808(%rsp),%r13
  a3df2e:	mov    0x810(%rsp),%r12
  a3df36:	mov    0x818(%rsp),%r15
  a3df3e:	movupd 0x820(%rsp),%xmm0
  a3df47:	movapd %xmm0,0x10(%rsp)
  a3df4d:	mov    0x830(%rsp),%rax
  a3df55:	jmp    a3de77 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x17e7>
  a3df5a:	movzwl 0x2(%r15),%eax
  a3df5f:	add    $0xfffffff2,%eax
  a3df62:	cmp    $0xb,%eax
  a3df65:	ja     a3dec3 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1833>
  a3df6b:	lea    -0x8a522a(%rip),%rdi        # 198d48 <anon.7cc7c74d1b8f8dfb5e74abfe8b727cdb.77.llvm.18220644203745900989+0x554>
  a3df72:	movslq (%rdi,%rax,4),%rax
  a3df76:	add    %rdi,%rax
  a3df79:	jmp    *%rax
  a3df7b:	mov    $0x6,%al
  a3df7d:	jmp    a3dede <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x184e>
  a3df82:	lea    -0x8a4fc5(%rip),%rdi        # 198fc4 <anon.f48bbd6ee32d24e1254dac28089ef4b7.59.llvm.17379179981059708172>
  a3df89:	lea    0xa7e250(%rip),%rcx        # 14bc1e0 <anon.f48bbd6ee32d24e1254dac28089ef4b7.8.llvm.17379179981059708172>
  a3df90:	lea    0xa7e4c9(%rip),%r8        # 14bc460 <anon.f48bbd6ee32d24e1254dac28089ef4b7.61.llvm.17379179981059708172>
  a3df97:	lea    0x3f(%rsp),%rdx
  a3df9c:	mov    $0x37,%esi
  a3dfa1:	call   *0xaee711(%rip)        # 152c6b8 <_DYNAMIC+0x378>
  a3dfa7:	jmp    a3e079 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x19e9>
  a3dfac:	lea    -0x8ae6db(%rip),%rdi        # 18f8d8 <anon.5e2c2cd338f183f0185d3116c074ef00.75.llvm.4553572696083558104>
  a3dfb3:	lea    0xa7ab26(%rip),%rdx        # 14b8ae0 <anon.5e2c2cd338f183f0185d3116c074ef00.76.llvm.4553572696083558104>
  a3dfba:	mov    $0x14,%esi
  a3dfbf:	call   *0xaee6eb(%rip)        # 152c6b0 <_DYNAMIC+0x370>
  a3dfc5:	mov    $0x8,%edi
  a3dfca:	mov    $0x18,%esi
  a3dfcf:	call   *0xaee5d3(%rip)        # 152c5a8 <_DYNAMIC+0x268>
  a3dfd5:	jmp    a3e079 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x19e9>
  a3dfda:	mov    $0x7,%al
  a3dfdc:	jmp    a3dede <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x184e>
  a3dfe1:	mov    $0x1,%al
  a3dfe3:	jmp    a3dede <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x184e>
  a3dfe8:	test   $0x4,%dl
  a3dfeb:	sete   %al
  a3dfee:	xor    $0x5,%al
  a3dff0:	jmp    a3dede <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x184e>
  a3dff5:	shr    $0x2,%dl
  a3dff8:	and    $0x1,%dl
  a3dffb:	mov    %dl,0x101(%rsp)
  a3e002:	mov    $0x2,%al
  a3e004:	jmp    a3dede <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x184e>
  a3e009:	shr    $0x2,%dl
  a3e00c:	and    $0x1,%dl
  a3e00f:	mov    %dl,0x101(%rsp)
  a3e016:	mov    $0x3,%al
  a3e018:	jmp    a3dede <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x184e>
  a3e01d:	mov    0xaef6ac(%rip),%rdi        # 152d6d0 <_DYNAMIC+0x1390>
  a3e024:	call   *0xaef1ae(%rip)        # 152d1d8 <_DYNAMIC+0xe98>
  a3e02a:	test   %al,%al
  a3e02c:	jne    a3cd9d <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x70d>
  a3e032:	jmp    a3cfe3 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x953>
  a3e037:	mov    0xaef68a(%rip),%rdi        # 152d6c8 <_DYNAMIC+0x1388>
  a3e03e:	call   *0xaef194(%rip)        # 152d1d8 <_DYNAMIC+0xe98>
  a3e044:	test   %al,%al
  a3e046:	jne    a3cc83 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x5f3>
  a3e04c:	jmp    a3d0c9 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xa39>
  a3e051:	lea    0xa7e3a0(%rip),%rcx        # 14bc3f8 <anon.f48bbd6ee32d24e1254dac28089ef4b7.8.llvm.17379179981059708172+0x218>
  a3e058:	mov    $0x17,%edx
  a3e05d:	xor    %edi,%edi
  a3e05f:	call   *0xaee55b(%rip)        # 152c5c0 <_DYNAMIC+0x280>
  a3e065:	mov    %ebp,0x8(%rsp)
  a3e069:	mov    $0x1,%edi
  a3e06e:	mov    $0x35,%esi
  a3e073:	call   *0xaee5f7(%rip)        # 152c670 <_DYNAMIC+0x330>
  a3e079:	ud2
  a3e07b:	mov    %r13,(%r15)
  a3e07e:	mov    %rax,%rdi
  a3e081:	call   14b6fa0 <_Unwind_Resume@plt>
  a3e086:	mov    %rax,%rbx
  a3e089:	movq   $0x1,(%r14)
  a3e090:	mov    %r13,0x8(%r14)
  a3e094:	movl   $0x0,0x8(%rsp)
  a3e09c:	jmp    a3e230 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1ba0>
  a3e0a1:	mov    %rax,%rbx
  a3e0a4:	lea    0x40(%rsp),%rdi
  a3e0a9:	call   a36e10 <core::ptr::drop_glue::<tracing::span::Span>>
  a3e0ae:	jmp    a3e1f4 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1b64>
  a3e0b3:	call   *0xaee50f(%rip)        # 152c5c8 <_DYNAMIC+0x288>
  a3e0b9:	mov    %rax,%rbx
  a3e0bc:	lea    0x250(%rsp),%rdi
  a3e0c4:	call   a36e10 <core::ptr::drop_glue::<tracing::span::Span>>
  a3e0c9:	jmp    a3e3e0 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1d50>
  a3e0ce:	call   *0xaee4f4(%rip)        # 152c5c8 <_DYNAMIC+0x288>
  a3e0d4:	mov    %rax,%rbx
  a3e0d7:	lea    0x70(%rsp),%rdi
  a3e0dc:	call   a36fa0 <core::ptr::drop_glue::<gpui::runtime::Error>>
  a3e0e1:	mov    %rbx,%rdi
  a3e0e4:	call   14b6fa0 <_Unwind_Resume@plt>
  a3e0e9:	mov    %rax,%rbx
  a3e0ec:	lea    0x250(%rsp),%rdi
  a3e0f4:	call   a35850 <core::ptr::drop_glue::<core::iter::adapters::flatten::Flatten<core::array::iter::IntoIter<core::option::Option<core::result::Result<gpui::runtime::Commit, gpui::runtime::Error>>, 16>>>>
  a3e0f9:	mov    %rbx,%rdi
  a3e0fc:	call   14b6fa0 <_Unwind_Resume@plt>
  a3e101:	mov    %rax,%rbx
  a3e104:	lea    0x100(%rsp),%rsi
  a3e10c:	mov    $0xb0,%edx
  a3e111:	mov    %rbp,%rdi
  a3e114:	call   *0xaee486(%rip)        # 152c5a0 <memcpy@GLIBC_2.14>
  a3e11a:	movl   $0x0,0x8(%rsp)
  a3e122:	jmp    a3e14c <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1abc>
  a3e124:	mov    %rax,%rbx
  a3e127:	lock decq (%r15)
  a3e12b:	mov    $0x1,%al
  a3e12d:	mov    %eax,0x8(%rsp)
  a3e131:	jne    a3e14c <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1abc>
  a3e133:	lea    0xd0(%rsp),%rdi
  a3e13b:	call   *0xaeefd7(%rip)        # 152d118 <_DYNAMIC+0xdd8>
  a3e141:	jmp    a3e14c <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1abc>
  a3e143:	call   *0xaee47f(%rip)        # 152c5c8 <_DYNAMIC+0x288>
  a3e149:	mov    %rax,%rbx
  a3e14c:	mov    %r13,%rdi
  a3e14f:	call   a35160 <core::ptr::drop_glue::<gpui::runtime::Win<empty::Empty>>>
  a3e154:	jmp    a3e230 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1ba0>
  a3e159:	movq   $0x0,(%r15)
  a3e160:	mov    %rax,%rdi
  a3e163:	call   14b6fa0 <_Unwind_Resume@plt>
  a3e168:	mov    %rax,%rbx
  a3e16b:	mov    0x8(%r15),%rsi
  a3e16f:	test   %rsi,%rsi
  a3e172:	je     a3e181 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1af1>
  a3e174:	mov    0x10(%r15),%rdx
  a3e178:	mov    %r13,%rdi
  a3e17b:	call   *0xaee40f(%rip)        # 152c590 <_DYNAMIC+0x250>
  a3e181:	mov    %rbp,0x1f0(%r14)
  a3e188:	mov    0x8(%rsp),%rax
  a3e18d:	mov    %rax,0x1f8(%r14)
  a3e194:	jmp    a3e281 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1bf1>
  a3e199:	mov    %rax,%rbx
  a3e19c:	mov    0x8(%r15),%rsi
  a3e1a0:	test   %rsi,%rsi
  a3e1a3:	je     a3e1b2 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1b22>
  a3e1a5:	mov    0x10(%r15),%rdx
  a3e1a9:	mov    %r13,%rdi
  a3e1ac:	call   *0xaee3de(%rip)        # 152c590 <_DYNAMIC+0x250>
  a3e1b2:	mov    %rbp,0x1e0(%r14)
  a3e1b9:	mov    0x8(%rsp),%rax
  a3e1be:	mov    %rax,0x1e8(%r14)
  a3e1c5:	mov    $0x1,%bpl
  a3e1c8:	mov    $0x1,%r14b
  a3e1cb:	jmp    a3e360 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1cd0>
  a3e1d0:	mov    %rax,%rbx
  a3e1d3:	movq   $0xffffffffffffffff,(%r15)
  a3e1da:	lea    0x808(%rsp),%rdi
  a3e1e2:	call   a36f00 <core::ptr::drop_glue::<gpui::native::NativeError>>
  a3e1e7:	mov    %rbx,%rdi
  a3e1ea:	call   14b6fa0 <_Unwind_Resume@plt>
  a3e1ef:	jmp    a3e227 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1b97>
  a3e1f1:	mov    %rax,%rbx
  a3e1f4:	lea    0x800(%rsp),%rdi
  a3e1fc:	call   a36080 <core::ptr::drop_glue::<winit::window::WindowAttributes>>
  a3e201:	jmp    a3e35b <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1ccb>
  a3e206:	mov    %rax,%rbx
  a3e209:	movw   $0x2,(%r12)
  a3e210:	mov    %rbx,%rdi
  a3e213:	call   14b6fa0 <_Unwind_Resume@plt>
  a3e218:	movq   $0xffffffffffffffff,(%r15)
  a3e21f:	mov    %rax,%rdi
  a3e222:	call   14b6fa0 <_Unwind_Resume@plt>
  a3e227:	mov    %rax,%rbx
  a3e22a:	mov    $0x1,%al
  a3e22c:	mov    %eax,0x8(%rsp)
  a3e230:	mov    0x30(%rsp),%rax
  a3e235:	lock decq (%rax)
  a3e239:	jne    a3e246 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1bb6>
  a3e23b:	lea    0x30(%rsp),%rdi
  a3e240:	call   *0xaeedd2(%rip)        # 152d018 <_DYNAMIC+0xcd8>
  a3e246:	cmpb   $0x0,0x8(%rsp)
  a3e24b:	jne    a3e35b <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1ccb>
  a3e251:	jmp    a3e3e0 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1d50>
  a3e256:	mov    %rax,%rbx
  a3e259:	lea    0xd0(%rsp),%rdi
  a3e261:	call   a36d90 <core::ptr::drop_glue::<tracing::span::EnteredSpan>>
  a3e266:	jmp    a3e35b <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1ccb>
  a3e26b:	call   *0xaee357(%rip)        # 152c5c8 <_DYNAMIC+0x288>
  a3e271:	mov    %rax,%rbx
  a3e274:	lea    0x100(%rsp),%rdi
  a3e27c:	call   a34380 <core::ptr::drop_glue::<core::option::Option<winit::window::Fullscreen>>>
  a3e281:	mov    $0x1,%r14b
  a3e284:	xor    %ebp,%ebp
  a3e286:	jmp    a3e360 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1cd0>
  a3e28b:	call   *0xaee337(%rip)        # 152c5c8 <_DYNAMIC+0x288>
  a3e291:	mov    %rax,%rbx
  a3e294:	mov    $0x1,%r14b
  a3e297:	mov    $0x1,%bpl
  a3e29a:	jmp    a3e38f <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1cff>
  a3e29f:	mov    %rax,%rbx
  a3e2a2:	jmp    a3e35b <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1ccb>
  a3e2a7:	mov    %rax,%rbx
  a3e2aa:	inc    %r13
  a3e2ad:	mov    %r13,0x258(%rsp)
  a3e2b5:	lea    0x250(%rsp),%rdi
  a3e2bd:	call   a35850 <core::ptr::drop_glue::<core::iter::adapters::flatten::Flatten<core::array::iter::IntoIter<core::option::Option<core::result::Result<gpui::runtime::Commit, gpui::runtime::Error>>, 16>>>>
  a3e2c2:	mov    %rbx,%rdi
  a3e2c5:	call   14b6fa0 <_Unwind_Resume@plt>
  a3e2ca:	mov    %rax,%rbx
  a3e2cd:	movq   $0xffffffffffffffff,(%r15)
  a3e2d4:	lea    0x658(%rsp),%rdi
  a3e2dc:	call   a36f00 <core::ptr::drop_glue::<gpui::native::NativeError>>
  a3e2e1:	mov    %rbx,%rdi
  a3e2e4:	call   14b6fa0 <_Unwind_Resume@plt>
  a3e2e9:	movq   $0x0,(%r15)
  a3e2f0:	mov    %rax,%rdi
  a3e2f3:	call   14b6fa0 <_Unwind_Resume@plt>
  a3e2f8:	movw   $0x2,0x188(%r14)
  a3e302:	mov    %rax,%rdi
  a3e305:	call   14b6fa0 <_Unwind_Resume@plt>
  a3e30a:	movq   $0xffffffffffffffff,(%r15)
  a3e311:	mov    %rax,%rdi
  a3e314:	call   14b6fa0 <_Unwind_Resume@plt>
  a3e319:	mov    %rax,%rbx
  a3e31c:	lea    0x250(%rsp),%rdi
  a3e324:	call   a34f40 <core::ptr::drop_glue::<alloc::sync::ArcInner<winit::window::Window>>>
  a3e329:	jmp    a3e35b <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1ccb>
  a3e32b:	call   *0xaee297(%rip)        # 152c5c8 <_DYNAMIC+0x288>
  a3e331:	mov    %rax,%rbx
  a3e334:	mov    0x40(%rsp),%rsi
  a3e339:	test   %rsi,%rsi
  a3e33c:	je     a3e34e <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1cbe>
  a3e33e:	mov    0x48(%rsp),%rdi
  a3e343:	mov    $0x1,%edx
  a3e348:	call   *0xaee242(%rip)        # 152c590 <_DYNAMIC+0x250>
  a3e34e:	lea    0x250(%rsp),%rdi
  a3e356:	call   a36000 <core::ptr::drop_glue::<winit::error::OsError>>
  a3e35b:	xor    %ebp,%ebp
  a3e35d:	xor    %r14d,%r14d
  a3e360:	mov    0xb8(%rsp),%rsi
  a3e368:	test   %rsi,%rsi
  a3e36b:	jne    a3e374 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1ce4>
  a3e36d:	test   %r14b,%r14b
  a3e370:	jne    a3e38c <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1cfc>
  a3e372:	jmp    a3e3c6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1d36>
  a3e374:	mov    0xc0(%rsp),%rdi
  a3e37c:	mov    $0x1,%edx
  a3e381:	call   *0xaee209(%rip)        # 152c590 <_DYNAMIC+0x250>
  a3e387:	test   %r14b,%r14b
  a3e38a:	je     a3e3c6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1d36>
  a3e38c:	xor    %r14d,%r14d
  a3e38f:	cmpq   $0x0,0x68(%rsp)
  a3e395:	je     a3e3ac <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1d1c>
  a3e397:	mov    0x78(%rsp),%rdi
  a3e39c:	mov    $0x1,%edx
  a3e3a1:	mov    0x68(%rsp),%rsi
  a3e3a6:	call   *0xaee1e4(%rip)        # 152c590 <_DYNAMIC+0x250>
  a3e3ac:	test   %r14b,%r14b
  a3e3af:	je     a3e3c6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1d36>
  a3e3b1:	mov    0x90(%rsp),%rdi
  a3e3b9:	mov    0x98(%rsp),%rsi
  a3e3c1:	call   a33630 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<dyn for<'a> core::ops::function::FnMut<(&'a gpui::runtime::Error,), Output = ()>>>>>
  a3e3c6:	test   %bpl,%bpl
  a3e3c9:	je     a3e3e0 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1d50>
  a3e3cb:	mov    0xa0(%rsp),%rdi
  a3e3d3:	mov    0xa8(%rsp),%rsi
  a3e3db:	call   a33630 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<dyn for<'a> core::ops::function::FnMut<(&'a gpui::runtime::Error,), Output = ()>>>>>
  a3e3e0:	mov    %rbx,%rdi
  a3e3e3:	call   14b6fa0 <_Unwind_Resume@plt>
  a3e3e8:	call   *0xaee1da(%rip)        # 152c5c8 <_DYNAMIC+0x288>
  a3e3ee:	call   *0xaee1d4(%rip)        # 152c5c8 <_DYNAMIC+0x288>


/tmp/gpui-a11y-owner-channel-captures/release-baseline/empty:     file format elf64-x86-64


Disassembly of section .text:

0000000000a522e0 <std::sync::mpmc::sync_channel::<gpui::native::accessibility::Queued>>:
  a522e0:	push   %rbp
  a522e1:	mov    %rsp,%rbp
  a522e4:	push   %r15
  a522e6:	push   %r14
  a522e8:	push   %r12
  a522ea:	push   %rbx
  a522eb:	and    $0xffffffffffffff80,%rsp
  a522ef:	sub    $0x300,%rsp
  a522f6:	mov    %rdi,%rbx
  a522f9:	test   %rsi,%rsi
  a522fc:	je     a52470 <std::sync::mpmc::sync_channel::<gpui::native::accessibility::Queued>+0x190>
  a52302:	bsr    %rsi,%rcx
  a52306:	not    %ecx
  a52308:	mov    $0xffffffffffffffff,%rax
  a5230f:	shr    %cl,%rax
  a52312:	inc    %rax
  a52315:	cmp    $0xffffffffffffffff,%rsi
  a52319:	mov    $0x1,%r15d
  a5231f:	cmovne %rax,%r15
  a52323:	lea    (%r15,%r15,1),%r12
  a52327:	xor    %edi,%edi
  a52329:	mov    %rsi,%r14
  a5232c:	call   a71d80 <<alloc::boxed::Box<[std::sync::mpmc::array::Slot<gpui::native::accessibility::Queued>]> as core::iter::traits::collect::FromIterator<std::sync::mpmc::array::Slot<gpui::native::accessibility::Queued>>>::from_iter::<core::iter::adapters::map::Map<core::ops::range::Range<usize>, <std::sync::mpmc::array::Channel<gpui::native::accessibility::Queued>>::with_capacity::{closure#0}>>>
  a52331:	movq   $0x0,(%rsp)
  a52339:	movq   $0x0,0x80(%rsp)
  a52345:	mov    %rax,0x198(%rsp)
  a5234d:	mov    %rdx,0x1a0(%rsp)
  a52355:	mov    %r14,0x180(%rsp)
  a5235d:	mov    %r12,0x188(%rsp)
  a52365:	mov    %r15,0x190(%rsp)
  a5236d:	movl   $0x0,0x100(%rsp)
  a52378:	movb   $0x0,0x104(%rsp)
  a52380:	movq   $0x0,0x108(%rsp)
  a5238c:	movq   $0x8,0x110(%rsp)
  a52398:	xorps  %xmm0,%xmm0
  a5239b:	movups %xmm0,0x118(%rsp)
  a523a3:	movq   $0x8,0x128(%rsp)
  a523af:	movq   $0x0,0x130(%rsp)
  a523bb:	movb   $0x1,0x138(%rsp)
  a523c3:	movl   $0x0,0x140(%rsp)
  a523ce:	movb   $0x0,0x144(%rsp)
  a523d6:	movq   $0x0,0x148(%rsp)
  a523e2:	movq   $0x8,0x150(%rsp)
  a523ee:	movups %xmm0,0x158(%rsp)
  a523f6:	movq   $0x8,0x168(%rsp)
  a52402:	movq   $0x0,0x170(%rsp)
  a5240e:	movb   $0x1,0x178(%rsp)
  a52416:	movq   $0x1,0x200(%rsp)
  a52422:	movq   $0x1,0x208(%rsp)
  a5242e:	movb   $0x0,0x210(%rsp)
  a52436:	call   *0xada144(%rip)        # 152c580 <_DYNAMIC+0x240>
  a5243c:	mov    $0x280,%edi
  a52441:	mov    $0x80,%esi
  a52446:	call   *0xada13c(%rip)        # 152c588 <_DYNAMIC+0x248>
  a5244c:	test   %rax,%rax
  a5244f:	je     a52536 <std::sync::mpmc::sync_channel::<gpui::native::accessibility::Queued>+0x256>
  a52455:	mov    %rax,%r14
  a52458:	mov    %rsp,%rsi
  a5245b:	mov    $0x280,%edx
  a52460:	mov    %rax,%rdi
  a52463:	call   *0xada137(%rip)        # 152c5a0 <memcpy@GLIBC_2.14>
  a52469:	xor    %eax,%eax
  a5246b:	jmp    a52517 <std::sync::mpmc::sync_channel::<gpui::native::accessibility::Queued>+0x237>
  a52470:	movq   $0x1,0x70(%rsp)
  a52479:	movq   $0x1,0x78(%rsp)
  a52482:	movb   $0x0,0x80(%rsp)
  a5248a:	movl   $0x0,(%rsp)
  a52491:	movb   $0x0,0x4(%rsp)
  a52496:	movq   $0x0,0x8(%rsp)
  a5249f:	movq   $0x8,0x10(%rsp)
  a524a8:	xorps  %xmm0,%xmm0
  a524ab:	movups %xmm0,0x18(%rsp)
  a524b0:	movq   $0x8,0x28(%rsp)
  a524b9:	movups %xmm0,0x30(%rsp)
  a524be:	movq   $0x8,0x40(%rsp)
  a524c7:	movups %xmm0,0x48(%rsp)
  a524cc:	movq   $0x8,0x58(%rsp)
  a524d5:	movq   $0x0,0x60(%rsp)
  a524de:	movb   $0x0,0x68(%rsp)
  a524e3:	call   *0xada097(%rip)        # 152c580 <_DYNAMIC+0x240>
  a524e9:	mov    $0x88,%edi
  a524ee:	mov    $0x8,%esi
  a524f3:	call   *0xada08f(%rip)        # 152c588 <_DYNAMIC+0x248>
  a524f9:	test   %rax,%rax
  a524fc:	je     a52548 <std::sync::mpmc::sync_channel::<gpui::native::accessibility::Queued>+0x268>
  a524fe:	mov    %rax,%r14
  a52501:	mov    %rsp,%rsi
  a52504:	mov    $0x88,%edx
  a52509:	mov    %rax,%rdi
  a5250c:	call   *0xada08e(%rip)        # 152c5a0 <memcpy@GLIBC_2.14>
  a52512:	mov    $0x2,%eax
  a52517:	mov    %rax,(%rbx)
  a5251a:	mov    %r14,0x8(%rbx)
  a5251e:	mov    %rax,0x10(%rbx)
  a52522:	mov    %r14,0x18(%rbx)
  a52526:	mov    %rbx,%rax
  a52529:	lea    -0x20(%rbp),%rsp
  a5252d:	pop    %rbx
  a5252e:	pop    %r12
  a52530:	pop    %r14
  a52532:	pop    %r15
  a52534:	pop    %rbp
  a52535:	ret
  a52536:	mov    $0x80,%edi
  a5253b:	mov    $0x280,%esi
  a52540:	call   *0xada062(%rip)        # 152c5a8 <_DYNAMIC+0x268>
  a52546:	jmp    a52558 <std::sync::mpmc::sync_channel::<gpui::native::accessibility::Queued>+0x278>
  a52548:	mov    $0x8,%edi
  a5254d:	mov    $0x88,%esi
  a52552:	call   *0xada050(%rip)        # 152c5a8 <_DYNAMIC+0x268>
  a52558:	ud2
  a5255a:	mov    %rax,%rbx
  a5255d:	mov    %rsp,%rdi
  a52560:	call   a50830 <core::ptr::drop_glue::<std::sync::mpmc::counter::Counter<std::sync::mpmc::zero::Channel<gpui::native::accessibility::Queued>>>>
  a52565:	jmp    a52578 <std::sync::mpmc::sync_channel::<gpui::native::accessibility::Queued>+0x298>
  a52567:	call   *0xada05b(%rip)        # 152c5c8 <_DYNAMIC+0x288>
  a5256d:	mov    %rax,%rbx
  a52570:	mov    %rsp,%rdi
  a52573:	call   a50870 <core::ptr::drop_glue::<std::sync::mpmc::counter::Counter<std::sync::mpmc::array::Channel<gpui::native::accessibility::Queued>>>>
  a52578:	mov    %rbx,%rdi
  a5257b:	call   14b6fa0 <_Unwind_Resume@plt>
  a52580:	call   *0xada042(%rip)        # 152c5c8 <_DYNAMIC+0x288>


/tmp/gpui-a11y-owner-channel-captures/release-baseline/empty:     file format elf64-x86-64


Disassembly of section .text:

0000000000a58360 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>>:
  a58360:	push   %rbp
  a58361:	push   %r15
  a58363:	push   %r14
  a58365:	push   %r13
  a58367:	push   %r12
  a58369:	push   %rbx
  a5836a:	sub    $0xe8,%rsp
  a58371:	mov    %rdx,%r14
  a58374:	mov    %rdi,%rbx
  a58377:	mov    %rcx,0x8(%rsp)
  a5837c:	mov    %r8,0x10(%rsp)
  a58381:	mov    %r9,0x18(%rsp)
  a58386:	mov    0xad4e1b(%rip),%rax        # 152d1a8 <_DYNAMIC+0xe68>
  a5838d:	mov    (%rax),%rax
  a58390:	cmp    $0x1,%rax
  a58394:	ja     a5841a <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0xba>
  a5839a:	mov    0xad52df(%rip),%r15        # 152d680 <_DYNAMIC+0x1340>
  a583a1:	movzbl 0x10(%r15),%eax
  a583a6:	movzbl %al,%ecx
  a583a9:	lea    -0x1(%rcx),%edx
  a583ac:	cmp    $0x2,%edx
  a583af:	jae    a58412 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0xb2>
  a583b1:	mov    (%r15),%rdi
  a583b4:	movzbl %al,%esi
  a583b7:	call   *0xad4dfb(%rip)        # 152d1b8 <_DYNAMIC+0xe78>
  a583bd:	test   %al,%al
  a583bf:	je     a5841a <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0xba>
  a583c1:	mov    (%r15),%rsi
  a583c4:	lea    0x30(%rsi),%rax
  a583c8:	movq   $0x1,0x20(%rsp)
  a583d1:	movq   $0x8,0x28(%rsp)
  a583da:	movq   $0x0,0x30(%rsp)
  a583e3:	mov    %rax,0x38(%rsp)
  a583e8:	lea    0x50(%rsp),%rdi
  a583ed:	lea    0x20(%rsp),%rdx
  a583f2:	call   *0xad4e98(%rip)        # 152d290 <_DYNAMIC+0xf50>
  a583f8:	cmpq   $0x2,0x50(%rsp)
  a583fe:	je     a5842c <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0xcc>
  a58400:	lea    0x68(%rsp),%rsi
  a58405:	lea    0x50(%rsp),%rdi
  a5840a:	call   *0xad4e88(%rip)        # 152d298 <_DYNAMIC+0xf58>
  a58410:	jmp    a5842c <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0xcc>
  a58412:	test   %ecx,%ecx
  a58414:	jne    a58778 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x418>
  a5841a:	movq   $0x2,0x50(%rsp)
  a58423:	movq   $0x0,0x70(%rsp)
  a5842c:	mov    0x70(%rsp),%rax
  a58431:	mov    %rax,0x40(%rsp)
  a58436:	mov    0x50(%rsp),%rax
  a5843b:	mov    0x58(%rsp),%rcx
  a58440:	movups 0x60(%rsp),%xmm0
  a58445:	movaps %xmm0,0x30(%rsp)
  a5844a:	mov    %rax,0x20(%rsp)
  a5844f:	mov    %rcx,0x28(%rsp)
  a58454:	mov    (%r14),%rdi
  a58457:	add    $0x10,%rdi
  a5845b:	call   *0xad47ef(%rip)        # 152cc50 <_DYNAMIC+0x910>
  a58461:	mov    %rax,%r14
  a58464:	movzbl 0x284(%rax),%ebp
  a5846b:	test   $0x1,%dl
  a5846e:	jne    a58486 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x126>
  a58470:	mov    0xad47e9(%rip),%rax        # 152cc60 <_DYNAMIC+0x920>
  a58477:	mov    (%rax),%rax
  a5847a:	shl    $1,%rax
  a5847d:	test   %rax,%rax
  a58480:	jne    a58745 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x3e5>
  a58486:	xor    %eax,%eax
  a58488:	xchg   %eax,(%r14)
  a5848b:	cmp    $0x2,%eax
  a5848e:	je     a586ea <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x38a>
  a58494:	lea    0x20(%rsp),%rdi
  a58499:	call   a59d90 <core::ptr::drop_glue::<tracing::span::EnteredSpan>>
  a5849e:	cmp    $0x1,%bpl
  a584a2:	je     a5875d <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x3fd>
  a584a8:	mov    0x8(%rsp),%r13
  a584ad:	mov    0x10(%rsp),%r15
  a584b2:	mov    0x18(%rsp),%r12
  a584b7:	mov    %r13,0xc0(%rsp)
  a584bf:	mov    %r15,0xc8(%rsp)
  a584c7:	mov    %r12,0xd0(%rsp)
  a584cf:	mov    0xad5532(%rip),%rax        # 152da08 <_DYNAMIC+0x16c8>
  a584d6:	mov    $0x1,%ebp
  a584db:	lock xadd %rbp,(%rax)
  a584e0:	call   *0xad552a(%rip)        # 152da10 <_DYNAMIC+0x16d0>
  a584e6:	mov    %rax,%r14
  a584e9:	mov    %rax,0xe0(%rsp)
  a584f1:	movq   $0x1,0x50(%rsp)
  a584fa:	movq   $0x1,0x58(%rsp)
  a58503:	movq   $0x0,0x60(%rsp)
  a5850c:	mov    %r15,0x68(%rsp)
  a58511:	call   *0xad4069(%rip)        # 152c580 <_DYNAMIC+0x240>
  a58517:	mov    $0x20,%edi
  a5851c:	mov    $0x8,%esi
  a58521:	call   *0xad4061(%rip)        # 152c588 <_DYNAMIC+0x248>
  a58527:	test   %rax,%rax
  a5852a:	je     a586f8 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x398>
  a58530:	movups 0x50(%rsp),%xmm0
  a58535:	movups 0x60(%rsp),%xmm1
  a5853a:	movups %xmm1,0x10(%rax)
  a5853e:	movups %xmm0,(%rax)
  a58541:	movq   $0x1,0x50(%rsp)
  a5854a:	movq   $0x1,0x58(%rsp)
  a58553:	movl   $0x0,0x60(%rsp)
  a5855b:	movb   $0x0,0x64(%rsp)
  a58560:	movw   $0x0,0x68(%rsp)
  a58567:	xorps  %xmm0,%xmm0
  a5856a:	movups %xmm0,0x70(%rsp)
  a5856f:	movups %xmm0,0x80(%rsp)
  a58577:	movups %xmm0,0x90(%rsp)
  a5857f:	movups %xmm0,0xa0(%rsp)
  a58587:	mov    %rax,0xb0(%rsp)
  a5858f:	lea    0xa65aaa(%rip),%rax        # 14be040 <anon.d8e877c12684b56d46474ea7cc3f8d5e.41.llvm.8388421502909551150+0xd8>
  a58596:	mov    %rax,0xb8(%rsp)
  a5859e:	call   *0xad3fdc(%rip)        # 152c580 <_DYNAMIC+0x240>
  a585a4:	mov    $0x70,%edi
  a585a9:	mov    $0x8,%esi
  a585ae:	call   *0xad3fd4(%rip)        # 152c588 <_DYNAMIC+0x248>
  a585b4:	test   %rax,%rax
  a585b7:	je     a5870f <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x3af>
  a585bd:	mov    %rax,%r15
  a585c0:	movups 0xb0(%rsp),%xmm0
  a585c8:	movups %xmm0,0x60(%rax)
  a585cc:	movups 0xa0(%rsp),%xmm0
  a585d4:	movups %xmm0,0x50(%rax)
  a585d8:	movups 0x90(%rsp),%xmm0
  a585e0:	movups %xmm0,0x40(%rax)
  a585e4:	movups 0x50(%rsp),%xmm0
  a585e9:	movups 0x60(%rsp),%xmm1
  a585ee:	movups 0x70(%rsp),%xmm2
  a585f3:	movups 0x80(%rsp),%xmm3
  a585fb:	movups %xmm3,0x30(%rax)
  a585ff:	movups %xmm2,0x20(%rax)
  a58603:	movups %xmm1,0x10(%rax)
  a58607:	movups %xmm0,(%rax)
  a5860a:	mov    %rax,0xd8(%rsp)
  a58612:	lock incq (%rax)
  a58616:	jle    a58776 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x416>
  a5861c:	mov    %r14,0x20(%rsp)
  a58621:	mov    %rbp,0x30(%rsp)
  a58626:	mov    %r15,0x28(%rsp)
  a5862b:	mov    %r13,0x50(%rsp)
  a58630:	call   *0xad3f4a(%rip)        # 152c580 <_DYNAMIC+0x240>
  a58636:	mov    $0x8,%edi
  a5863b:	mov    $0x8,%esi
  a58640:	call   *0xad3f42(%rip)        # 152c588 <_DYNAMIC+0x248>
  a58646:	mov    %rax,%r14
  a58649:	test   %rax,%rax
  a5864c:	je     a58721 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x3c1>
  a58652:	mov    %r13,(%r14)
  a58655:	mov    %r12,0x50(%rsp)
  a5865a:	call   *0xad3f20(%rip)        # 152c580 <_DYNAMIC+0x240>
  a58660:	mov    $0x8,%edi
  a58665:	mov    $0x8,%esi
  a5866a:	call   *0xad3f18(%rip)        # 152c588 <_DYNAMIC+0x248>
  a58670:	test   %rax,%rax
  a58673:	je     a58733 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x3d3>
  a58679:	mov    %r12,(%rax)
  a5867c:	mov    %rbp,0x80(%rsp)
  a58684:	mov    %r14,0x58(%rsp)
  a58689:	lea    0xa659d0(%rip),%rcx        # 14be060 <anon.d8e877c12684b56d46474ea7cc3f8d5e.41.llvm.8388421502909551150+0xf8>
  a58690:	mov    %rcx,0x60(%rsp)
  a58695:	mov    %rax,0x68(%rsp)
  a5869a:	lea    0xa659df(%rip),%rax        # 14be080 <anon.d8e877c12684b56d46474ea7cc3f8d5e.41.llvm.8388421502909551150+0x118>
  a586a1:	mov    %rax,0x70(%rsp)
  a586a6:	mov    %r15,0x78(%rsp)
  a586ab:	movq   $0x6,0x50(%rsp)
  a586b4:	lea    0x20(%rsp),%rdi
  a586b9:	lea    0x50(%rsp),%rsi
  a586be:	call   *0xad5354(%rip)        # 152da18 <_DYNAMIC+0x16d8>
  a586c4:	mov    0x30(%rsp),%rax
  a586c9:	mov    %rax,0x10(%rbx)
  a586cd:	movups 0x20(%rsp),%xmm0
  a586d2:	movups %xmm0,(%rbx)
  a586d5:	mov    %rbx,%rax
  a586d8:	add    $0xe8,%rsp
  a586df:	pop    %rbx
  a586e0:	pop    %r12
  a586e2:	pop    %r13
  a586e4:	pop    %r14
  a586e6:	pop    %r15
  a586e8:	pop    %rbp
  a586e9:	ret
  a586ea:	mov    %r14,%rdi
  a586ed:	call   *0xad4595(%rip)        # 152cc88 <_DYNAMIC+0x948>
  a586f3:	jmp    a58494 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x134>
  a586f8:	lea    0x68(%rsp),%r14
  a586fd:	mov    $0x8,%edi
  a58702:	mov    $0x20,%esi
  a58707:	call   *0xad3e9b(%rip)        # 152c5a8 <_DYNAMIC+0x268>
  a5870d:	jmp    a58776 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x416>
  a5870f:	mov    $0x8,%edi
  a58714:	mov    $0x70,%esi
  a58719:	call   *0xad3e89(%rip)        # 152c5a8 <_DYNAMIC+0x268>
  a5871f:	jmp    a58776 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x416>
  a58721:	mov    $0x8,%edi
  a58726:	mov    $0x8,%esi
  a5872b:	call   *0xad3e77(%rip)        # 152c5a8 <_DYNAMIC+0x268>
  a58731:	jmp    a58776 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x416>
  a58733:	mov    $0x8,%edi
  a58738:	mov    $0x8,%esi
  a5873d:	call   *0xad3e65(%rip)        # 152c5a8 <_DYNAMIC+0x268>
  a58743:	jmp    a58776 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x416>
  a58745:	call   *0xad4545(%rip)        # 152cc90 <_DYNAMIC+0x950>
  a5874b:	test   %al,%al
  a5874d:	jne    a58486 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x126>
  a58753:	movb   $0x1,0x4(%r14)
  a58758:	jmp    a58486 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x126>
  a5875d:	lea    -0x8be468(%rip),%rdi        # 19a2fc <anon.ea0b98c4b1bc155e44426204743c94d4.12.llvm.6377898250299125797+0x194>
  a58764:	lea    0xa658bd(%rip),%rdx        # 14be028 <anon.d8e877c12684b56d46474ea7cc3f8d5e.41.llvm.8388421502909551150+0xc0>
  a5876b:	mov    $0xd3,%esi
  a58770:	call   *0xad3e5a(%rip)        # 152c5d0 <_DYNAMIC+0x290>
  a58776:	ud2
  a58778:	mov    0xad4f01(%rip),%rdi        # 152d680 <_DYNAMIC+0x1340>
  a5877f:	call   *0xad4a53(%rip)        # 152d1d8 <_DYNAMIC+0xe98>
  a58785:	test   %al,%al
  a58787:	jne    a583b1 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x51>
  a5878d:	jmp    a5841a <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0xba>
  a58792:	mov    %rax,%rbx
  a58795:	lea    0x50(%rsp),%rdi
  a5879a:	call   a59e10 <core::ptr::drop_glue::<tracing::span::Span>>
  a5879f:	jmp    a587d7 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x477>
  a587a1:	call   *0xad3e21(%rip)        # 152c5c8 <_DYNAMIC+0x288>
  a587a7:	mov    %rax,%rbx
  a587aa:	xor    %ebp,%ebp
  a587ac:	jmp    a58868 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x508>
  a587b1:	mov    %rax,%rbx
  a587b4:	mov    $0x1,%bpl
  a587b7:	mov    $0x1,%r14b
  a587ba:	jmp    a588e0 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x580>
  a587bf:	mov    %rax,%rbx
  a587c2:	lea    0x20(%rsp),%rdi
  a587c7:	call   a59d90 <core::ptr::drop_glue::<tracing::span::EnteredSpan>>
  a587cc:	jmp    a587d7 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x477>
  a587ce:	call   *0xad3df4(%rip)        # 152c5c8 <_DYNAMIC+0x288>
  a587d4:	mov    %rax,%rbx
  a587d7:	mov    0x18(%rsp),%rax
  a587dc:	lock decq (%rax)
  a587e0:	jne    a587ed <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x48d>
  a587e2:	lea    0x18(%rsp),%rdi
  a587e7:	call   *0xad494b(%rip)        # 152d138 <_DYNAMIC+0xdf8>
  a587ed:	mov    0x10(%rsp),%rax
  a587f2:	lock decq (%rax)
  a587f6:	jne    a58803 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x4a3>
  a587f8:	lea    0x10(%rsp),%rdi
  a587fd:	call   *0xad4935(%rip)        # 152d138 <_DYNAMIC+0xdf8>
  a58803:	mov    0x8(%rsp),%rax
  a58808:	lock decq (%rax)
  a5880c:	jne    a5893e <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x5de>
  a58812:	lea    0x8(%rsp),%rdi
  a58817:	call   *0xad491b(%rip)        # 152d138 <_DYNAMIC+0xdf8>
  a5881d:	jmp    a5893e <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x5de>
  a58822:	call   *0xad3da0(%rip)        # 152c5c8 <_DYNAMIC+0x288>
  a58828:	mov    %rax,%rbx
  a5882b:	lock decq (%r12)
  a58830:	jne    a5883d <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x4dd>
  a58832:	lea    0x50(%rsp),%rdi
  a58837:	call   *0xad48fb(%rip)        # 152d138 <_DYNAMIC+0xdf8>
  a5883d:	mov    %r14,%rdi
  a58840:	call   a59200 <core::ptr::drop_glue::<alloc::boxed::Box<dyn accesskit::ActivationHandler + core::marker::Send>>>
  a58845:	mov    $0x1,%bpl
  a58848:	jmp    a58868 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x508>
  a5884a:	call   *0xad3d78(%rip)        # 152c5c8 <_DYNAMIC+0x288>
  a58850:	mov    %rax,%rbx
  a58853:	lock decq 0x0(%r13)
  a58858:	mov    $0x1,%bpl
  a5885b:	jne    a58868 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x508>
  a5885d:	lea    0x50(%rsp),%rdi
  a58862:	call   *0xad48d0(%rip)        # 152d138 <_DYNAMIC+0xdf8>
  a58868:	lea    0x20(%rsp),%rdi
  a5886d:	call   a594f0 <core::ptr::drop_glue::<accesskit_unix::adapter::Adapter>>
  a58872:	test   %bpl,%bpl
  a58875:	je     a58893 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x533>
  a58877:	mov    0xd8(%rsp),%rax
  a5887f:	lock decq (%rax)
  a58883:	jne    a58893 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x533>
  a58885:	lea    0xd8(%rsp),%rdi
  a5888d:	call   *0xad48cd(%rip)        # 152d160 <_DYNAMIC+0xe20>
  a58893:	test   %r14,%r14
  a58896:	jne    a5893e <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x5de>
  a5889c:	xor    %ebp,%ebp
  a5889e:	jmp    a588dd <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x57d>
  a588a0:	call   *0xad3d22(%rip)        # 152c5c8 <_DYNAMIC+0x288>
  a588a6:	mov    %rax,%rbx
  a588a9:	lea    0x50(%rsp),%rdi
  a588ae:	call   a59100 <core::ptr::drop_glue::<alloc::sync::ArcInner<std::sync::poison::mutex::Mutex<accesskit_unix::adapter::AdapterState>>>>
  a588b3:	jmp    a588cd <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x56d>
  a588b5:	call   *0xad3d0d(%rip)        # 152c5c8 <_DYNAMIC+0x288>
  a588bb:	mov    %rax,%rbx
  a588be:	lock decq (%r15)
  a588c2:	jne    a588cd <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x56d>
  a588c4:	mov    %r14,%rdi
  a588c7:	call   *0xad486b(%rip)        # 152d138 <_DYNAMIC+0xdf8>
  a588cd:	lea    0xe0(%rsp),%rdi
  a588d5:	call   a58ed0 <core::ptr::drop_glue::<async_channel::Sender<accesskit_unix::adapter::Message>>>
  a588da:	mov    $0x1,%bpl
  a588dd:	xor    %r14d,%r14d
  a588e0:	mov    0xd0(%rsp),%rax
  a588e8:	lock decq (%rax)
  a588ec:	jne    a588fc <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x59c>
  a588ee:	lea    0xd0(%rsp),%rdi
  a588f6:	call   *0xad483c(%rip)        # 152d138 <_DYNAMIC+0xdf8>
  a588fc:	test   %r14b,%r14b
  a588ff:	je     a5891d <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x5bd>
  a58901:	mov    0xc8(%rsp),%rax
  a58909:	lock decq (%rax)
  a5890d:	jne    a5891d <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x5bd>
  a5890f:	lea    0xc8(%rsp),%rdi
  a58917:	call   *0xad481b(%rip)        # 152d138 <_DYNAMIC+0xdf8>
  a5891d:	test   %bpl,%bpl
  a58920:	je     a5893e <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x5de>
  a58922:	mov    0xc0(%rsp),%rax
  a5892a:	lock decq (%rax)
  a5892e:	jne    a5893e <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x5de>
  a58930:	lea    0xc0(%rsp),%rdi
  a58938:	call   *0xad47fa(%rip)        # 152d138 <_DYNAMIC+0xdf8>
  a5893e:	mov    %rbx,%rdi
  a58941:	call   14b6fa0 <_Unwind_Resume@plt>
  a58946:	call   *0xad3c7c(%rip)        # 152c5c8 <_DYNAMIC+0x288>
  a5894c:	call   *0xad3c76(%rip)        # 152c5c8 <_DYNAMIC+0x288>


/tmp/gpui-a11y-owner-channel-captures/release-baseline/empty:     file format elf64-x86-64


Disassembly of section .text:

0000000000a65d80 <<gpui::native::accessibility::Bridge>::process_event>:
  a65d80:	add    $0x88,%rdi
  a65d87:	jmp    *0xac7d6b(%rip)        # 152daf8 <_DYNAMIC+0x17b8>


/tmp/gpui-a11y-owner-channel-captures/release-baseline/empty:     file format elf64-x86-64


Disassembly of section .text:

0000000000a65d90 <<gpui::native::accessibility::Bridge>::new>:
  a65d90:	push   %rbp
  a65d91:	push   %r15
  a65d93:	push   %r14
  a65d95:	push   %r13
  a65d97:	push   %r12
  a65d99:	push   %rbx
  a65d9a:	sub    $0x98,%rsp
  a65da1:	mov    %r8,(%rsp)
  a65da5:	mov    %rcx,%r13
  a65da8:	mov    %rdx,%r15
  a65dab:	mov    %rsi,%r12
  a65dae:	mov    %rdi,%r14
  a65db1:	movups (%rcx),%xmm0
  a65db4:	movups 0x10(%rcx),%xmm1
  a65db8:	movaps %xmm1,0x80(%rsp)
  a65dc0:	movaps %xmm0,0x70(%rsp)
  a65dc5:	lea    0x18(%rsp),%rdi
  a65dca:	mov    $0x40,%esi
  a65dcf:	call   a522e0 <std::sync::mpmc::sync_channel::<gpui::native::accessibility::Queued>>
  a65dd4:	movups 0x18(%rsp),%xmm0
  a65dd9:	mov    0x28(%rsp),%rbp
  a65dde:	mov    0x30(%rsp),%rbx
  a65de3:	mov    %rbp,0x8(%rsp)
  a65de8:	mov    %rbx,0x10(%rsp)
  a65ded:	movups 0x0(%r13),%xmm1
  a65df2:	movups 0x10(%r13),%xmm2
  a65df7:	movups %xmm2,0x48(%rsp)
  a65dfc:	movups %xmm1,0x38(%rsp)
  a65e01:	movq   $0x1,0x18(%rsp)
  a65e0a:	movq   $0x1,0x20(%rsp)
  a65e13:	movups %xmm0,0x28(%rsp)
  a65e18:	xorps  %xmm0,%xmm0
  a65e1b:	movups %xmm0,0x58(%rsp)
  a65e20:	movl   $0x0,0x67(%rsp)
  a65e28:	call   *0xac6752(%rip)        # 152c580 <_DYNAMIC+0x240>
  a65e2e:	mov    $0x58,%edi
  a65e33:	mov    $0x8,%esi
  a65e38:	call   *0xac674a(%rip)        # 152c588 <_DYNAMIC+0x248>
  a65e3e:	test   %rax,%rax
  a65e41:	je     a65f5c <<gpui::native::accessibility::Bridge>::new+0x1cc>
  a65e47:	mov    %rax,%r13
  a65e4a:	mov    0x68(%rsp),%rax
  a65e4f:	mov    %rax,0x50(%r13)
  a65e53:	movups 0x58(%rsp),%xmm0
  a65e58:	movups %xmm0,0x40(%r13)
  a65e5d:	movups 0x18(%rsp),%xmm0
  a65e62:	movups 0x28(%rsp),%xmm1
  a65e67:	movups 0x38(%rsp),%xmm2
  a65e6c:	movups 0x48(%rsp),%xmm3
  a65e71:	movups %xmm3,0x30(%r13)
  a65e76:	movups %xmm2,0x20(%r13)
  a65e7b:	movups %xmm1,0x10(%r13)
  a65e80:	movups %xmm0,0x0(%r13)
  a65e85:	mov    %r13,0x8(%rsp)
  a65e8a:	mov    %rbp,0x70(%rsp)
  a65e8f:	mov    %rbx,0x78(%rsp)
  a65e94:	lock incq 0x0(%r13)
  a65e99:	jle    a65f71 <<gpui::native::accessibility::Bridge>::new+0x1e1>
  a65e9f:	lock incq 0x0(%r13)
  a65ea4:	jle    a65f71 <<gpui::native::accessibility::Bridge>::new+0x1e1>
  a65eaa:	lock incq 0x0(%r13)
  a65eaf:	jle    a65f71 <<gpui::native::accessibility::Bridge>::new+0x1e1>
  a65eb5:	lea    0x18(%rsp),%rdi
  a65eba:	mov    %r12,%rsi
  a65ebd:	mov    %r15,%rdx
  a65ec0:	mov    %r13,%rcx
  a65ec3:	mov    %r13,%r8
  a65ec6:	mov    %r13,%r9
  a65ec9:	call   a58360 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>>
  a65ece:	mov    (%rsp),%rcx
  a65ed2:	mov    0x10(%rcx),%rax
  a65ed6:	mov    %rax,0x20(%r14)
  a65eda:	movups (%rcx),%xmm0
  a65edd:	movups %xmm0,0x10(%r14)
  a65ee2:	movups 0x18(%rsp),%xmm0
  a65ee7:	movups %xmm0,0x88(%r14)
  a65eef:	mov    0x28(%rsp),%rax
  a65ef4:	mov    %rax,0x98(%r14)
  a65efb:	mov    %rbp,(%r14)
  a65efe:	mov    %rbx,0x8(%r14)
  a65f02:	mov    %r13,0xa0(%r14)
  a65f09:	movb   $0x2,0x80(%r14)
  a65f11:	movb   $0x1,0xa8(%r14)
  a65f19:	movq   $0x0,0x28(%r14)
  a65f21:	movq   $0x8,0x30(%r14)
  a65f29:	movq   $0x0,0x38(%r14)
  a65f31:	movabs $0x8000000000000000,%rax
  a65f3b:	mov    %rax,0x40(%r14)
  a65f3f:	movq   $0x0,0x48(%r14)
  a65f47:	mov    %r14,%rax
  a65f4a:	add    $0x98,%rsp
  a65f51:	pop    %rbx
  a65f52:	pop    %r12
  a65f54:	pop    %r13
  a65f56:	pop    %r14
  a65f58:	pop    %r15
  a65f5a:	pop    %rbp
  a65f5b:	ret
  a65f5c:	lea    0x28(%rsp),%r15
  a65f61:	mov    $0x8,%edi
  a65f66:	mov    $0x58,%esi
  a65f6b:	call   *0xac6637(%rip)        # 152c5a8 <_DYNAMIC+0x268>
  a65f71:	ud2
  a65f73:	mov    %rax,%r14
  a65f76:	lea    0x70(%rsp),%rdi
  a65f7b:	call   a55990 <<std::sync::mpmc::Receiver<gpui::native::accessibility::Queued> as core::ops::drop::Drop>::drop>
  a65f80:	lock decq 0x0(%r13)
  a65f85:	jne    a65f98 <<gpui::native::accessibility::Bridge>::new+0x208>
  a65f87:	lea    0x8(%rsp),%rdi
  a65f8c:	call   *0xac71a6(%rip)        # 152d138 <_DYNAMIC+0xdf8>
  a65f92:	mov    (%rsp),%rbx
  a65f96:	jmp    a65fd0 <<gpui::native::accessibility::Bridge>::new+0x240>
  a65f98:	mov    (%rsp),%rbx
  a65f9c:	jmp    a65fd0 <<gpui::native::accessibility::Bridge>::new+0x240>
  a65f9e:	call   *0xac6624(%rip)        # 152c5c8 <_DYNAMIC+0x288>
  a65fa4:	mov    %rax,%r14
  a65fa7:	lea    0x70(%rsp),%rdi
  a65fac:	call   a65060 <core::ptr::drop_glue::<core::option::Option<gpui_reactivity_host::native::Wake>>>
  a65fb1:	mov    (%rsp),%rbx
  a65fb5:	jmp    a65fd0 <<gpui::native::accessibility::Bridge>::new+0x240>
  a65fb7:	mov    %rax,%r14
  a65fba:	mov    %r15,%rdi
  a65fbd:	call   a65590 <core::ptr::drop_glue::<gpui::native::accessibility::Shared>>
  a65fc2:	mov    (%rsp),%rbx
  a65fc6:	lea    0x8(%rsp),%rdi
  a65fcb:	call   a55990 <<std::sync::mpmc::Receiver<gpui::native::accessibility::Queued> as core::ops::drop::Drop>::drop>
  a65fd0:	mov    (%rbx),%rsi
  a65fd3:	test   %rsi,%rsi
  a65fd6:	je     a65fe7 <<gpui::native::accessibility::Bridge>::new+0x257>
  a65fd8:	mov    0x8(%rbx),%rdi
  a65fdc:	mov    $0x1,%edx
  a65fe1:	call   *0xac65a9(%rip)        # 152c590 <_DYNAMIC+0x250>
  a65fe7:	mov    %r14,%rdi
  a65fea:	call   14b6fa0 <_Unwind_Resume@plt>
  a65fef:	call   *0xac65d3(%rip)        # 152c5c8 <_DYNAMIC+0x288>
  a65ff5:	call   *0xac65cd(%rip)        # 152c5c8 <_DYNAMIC+0x288>


/tmp/gpui-a11y-owner-channel-captures/release-baseline/empty:     file format elf64-x86-64


Disassembly of section .text:

0000000000a681c0 <<gpui::native::accessibility::Ingress as accesskit::ActivationHandler>::request_initial_tree>:
  a681c0:	push   %rbx
  a681c1:	mov    %rdi,%rbx
  a681c4:	mov    (%rsi),%rdi
  a681c7:	movzbl 0x50(%rdi),%eax
  a681cb:	test   %al,%al
  a681cd:	je     a681db <<gpui::native::accessibility::Ingress as accesskit::ActivationHandler>::request_initial_tree+0x1b>
  a681cf:	movq   $0xffffffffffffffff,(%rbx)
  a681d6:	mov    %rbx,%rax
  a681d9:	pop    %rbx
  a681da:	ret
  a681db:	mov    0x40(%rdi),%rax
  a681df:	nop
  a681e0:	mov    %rax,%rcx
  a681e3:	or     $0x1,%rcx
  a681e7:	lock cmpxchg %rcx,0x40(%rdi)
  a681ed:	jne    a681e0 <<gpui::native::accessibility::Ingress as accesskit::ActivationHandler>::request_initial_tree+0x20>
  a681ef:	movb   $0x1,0x52(%rdi)
  a681f3:	cmpl   $0xffffffff,0x20(%rdi)
  a681f7:	je     a681cf <<gpui::native::accessibility::Ingress as accesskit::ActivationHandler>::request_initial_tree+0xf>
  a681f9:	add    $0x20,%rdi
  a681fd:	call   *0xac5855(%rip)        # 152da58 <_DYNAMIC+0x1718>
  a68203:	movq   $0xffffffffffffffff,(%rbx)
  a6820a:	mov    %rbx,%rax
  a6820d:	pop    %rbx
  a6820e:	ret


/tmp/gpui-a11y-owner-channel-captures/release-baseline/empty:     file format elf64-x86-64


Disassembly of section .text:

0000000000a68330 <<gpui::native::accessibility::Ingress as accesskit::DeactivationHandler>::deactivate_accessibility>:
  a68330:	push   %rbx
  a68331:	mov    (%rdi),%rbx
  a68334:	mov    0x40(%rbx),%rax
  a68338:	nopl   0x0(%rax,%rax,1)
  a68340:	cmp    $0xffffffffffffffff,%rax
  a68344:	je     a68358 <<gpui::native::accessibility::Ingress as accesskit::DeactivationHandler>::deactivate_accessibility+0x28>
  a68346:	mov    %eax,%ecx
  a68348:	and    $0x1,%ecx
  a6834b:	add    %rax,%rcx
  a6834e:	lock cmpxchg %rcx,0x40(%rbx)
  a68354:	jne    a68340 <<gpui::native::accessibility::Ingress as accesskit::DeactivationHandler>::deactivate_accessibility+0x10>
  a68356:	jmp    a6836c <<gpui::native::accessibility::Ingress as accesskit::DeactivationHandler>::deactivate_accessibility+0x3c>
  a68358:	movb   $0x1,0x51(%rbx)
  a6835c:	cmpl   $0xffffffff,0x20(%rbx)
  a68360:	je     a6836c <<gpui::native::accessibility::Ingress as accesskit::DeactivationHandler>::deactivate_accessibility+0x3c>
  a68362:	lea    0x20(%rbx),%rdi
  a68366:	call   *0xac56ec(%rip)        # 152da58 <_DYNAMIC+0x1718>
  a6836c:	cmpl   $0xffffffff,0x20(%rbx)
  a68370:	je     a68380 <<gpui::native::accessibility::Ingress as accesskit::DeactivationHandler>::deactivate_accessibility+0x50>
  a68372:	add    $0x20,%rbx
  a68376:	mov    %rbx,%rdi
  a68379:	pop    %rbx
  a6837a:	jmp    *0xac56d8(%rip)        # 152da58 <_DYNAMIC+0x1718>
  a68380:	pop    %rbx
  a68381:	ret


/tmp/gpui-a11y-owner-channel-captures/release-baseline/empty:     file format elf64-x86-64


Disassembly of section .text:

0000000000a68390 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action>:
  a68390:	push   %rbp
  a68391:	push   %r15
  a68393:	push   %r14
  a68395:	push   %r13
  a68397:	push   %r12
  a68399:	push   %rbx
  a6839a:	sub    $0x78,%rsp
  a6839e:	mov    (%rdi),%r14
  a683a1:	mov    0x40(%r14),%r12
  a683a5:	movzbl 0x50(%r14),%eax
  a683aa:	test   %al,%al
  a683ac:	jne    a683ed <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x5d>
  a683ae:	mov    %r12d,%eax
  a683b1:	and    $0x1,%eax
  a683b4:	je     a683ed <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x5d>
  a683b6:	mov    0x30(%rsi),%rax
  a683ba:	or     0x28(%rsi),%rax
  a683be:	jne    a683ed <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x5d>
  a683c0:	mov    0x38(%rsi),%r13
  a683c4:	movzbl 0x40(%rsi),%ecx
  a683c8:	mov    (%rsi),%eax
  a683ca:	mov    0x8(%rsi),%rbx
  a683ce:	mov    0x10(%rsi),%r15
  a683d2:	test   %ecx,%ecx
  a683d4:	je     a68440 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0xb0>
  a683d6:	cmp    $0x1,%ecx
  a683d9:	je     a68433 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0xa3>
  a683db:	cmp    $0x2,%ecx
  a683de:	jne    a6845c <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0xcc>
  a683e0:	cmp    $0xffffffff,%eax
  a683e3:	jne    a68449 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0xb9>
  a683e5:	mov    $0x2,%bpl
  a683e8:	jmp    a6851e <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x18e>
  a683ed:	mov    (%rsi),%eax
  a683ef:	cmp    $0xffffffff,%eax
  a683f2:	je     a685fa <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x26a>
  a683f8:	lea    -0x2(%rax),%ecx
  a683fb:	cmp    $0x6,%ecx
  a683fe:	jb     a685fa <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x26a>
  a68404:	test   %eax,%eax
  a68406:	je     a685fa <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x26a>
  a6840c:	cmp    $0x1,%eax
  a6840f:	jne    a684a9 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x119>
  a68415:	mov    0x10(%rsi),%rax
  a68419:	test   %rax,%rax
  a6841c:	je     a685fa <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x26a>
  a68422:	mov    0x8(%rsi),%rdi
  a68426:	mov    $0x1,%edx
  a6842b:	mov    %rax,%rsi
  a6842e:	jmp    a685c2 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x232>
  a68433:	cmp    $0xffffffff,%eax
  a68436:	jne    a68449 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0xb9>
  a68438:	mov    $0x1,%bpl
  a6843b:	jmp    a6851e <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x18e>
  a68440:	cmp    $0xffffffff,%eax
  a68443:	je     a6851c <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x18c>
  a68449:	cmp    $0x1,%eax
  a6844c:	je     a685b2 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x222>
  a68452:	cmp    $0x8,%eax
  a68455:	je     a684ad <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x11d>
  a68457:	jmp    a685fa <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x26a>
  a6845c:	cmp    $0x1,%eax
  a6845f:	je     a685aa <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x21a>
  a68465:	cmp    $0x7,%eax
  a68468:	je     a684d6 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x146>
  a6846a:	cmp    $0x8,%eax
  a6846d:	jne    a685d6 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x246>
  a68473:	lea    -0xb(%rcx),%eax
  a68476:	cmp    $0x4,%eax
  a68479:	jb     a684ad <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x11d>
  a6847b:	cmp    $0xa,%ecx
  a6847e:	jne    a684ad <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x11d>
  a68480:	cmpq   $0x10001,0x8(%rbx)
  a68488:	jb     a686cd <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x33d>
  a6848e:	movb   $0x1,0x51(%r14)
  a68493:	cmpl   $0xffffffff,0x20(%r14)
  a68498:	je     a684ad <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x11d>
  a6849a:	add    $0x20,%r14
  a6849e:	mov    %r14,%rdi
  a684a1:	call   *0xac55b1(%rip)        # 152da58 <_DYNAMIC+0x1718>
  a684a7:	jmp    a684ad <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x11d>
  a684a9:	mov    0x8(%rsi),%rbx
  a684ad:	mov    0x8(%rbx),%rsi
  a684b1:	test   %rsi,%rsi
  a684b4:	je     a684c4 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x134>
  a684b6:	mov    (%rbx),%rdi
  a684b9:	mov    $0x1,%edx
  a684be:	call   *0xac40cc(%rip)        # 152c590 <_DYNAMIC+0x250>
  a684c4:	mov    $0x30,%esi
  a684c9:	mov    $0x8,%edx
  a684ce:	mov    %rbx,%rdi
  a684d1:	jmp    a685c2 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x232>
  a684d6:	cmp    $0x12,%ecx
  a684d9:	jne    a685fa <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x26a>
  a684df:	mov    %rsi,%rbp
  a684e2:	call   *0xac4098(%rip)        # 152c580 <_DYNAMIC+0x240>
  a684e8:	mov    $0x20,%edi
  a684ed:	mov    $0x8,%esi
  a684f2:	call   *0xac4090(%rip)        # 152c588 <_DYNAMIC+0x248>
  a684f8:	test   %rax,%rax
  a684fb:	je     a68726 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x396>
  a68501:	add    $0x18,%rbp
  a68505:	mov    %rbx,(%rax)
  a68508:	mov    %r15,0x8(%rax)
  a6850c:	movups 0x0(%rbp),%xmm0
  a68510:	movups %xmm0,0x10(%rax)
  a68514:	mov    $0x4,%bpl
  a68517:	mov    %rax,%rbx
  a6851a:	jmp    a6851e <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x18e>
  a6851c:	xor    %ebp,%ebp
  a6851e:	mov    0x48(%r14),%rax
  a68522:	mov    %r12,0x30(%rsp)
  a68527:	mov    %rax,0x38(%rsp)
  a6852c:	mov    %bpl,0x10(%rsp)
  a68531:	mov    %sil,0x11(%rsp)
  a68536:	mov    %dl,0x12(%rsp)
  a6853a:	mov    %r13,0x18(%rsp)
  a6853f:	mov    %rbx,0x20(%rsp)
  a68544:	mov    %r15,0x28(%rsp)
  a68549:	lea    0x10(%r14),%rsi
  a6854d:	lea    0x40(%rsp),%rdi
  a68552:	lea    0x10(%rsp),%rdx
  a68557:	call   a531f0 <<std::sync::mpmc::Sender<gpui::native::accessibility::Queued>>::try_send>
  a6855c:	mov    0x40(%rsp),%rax
  a68561:	test   %rax,%rax
  a68564:	je     a68585 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x1f5>
  a68566:	cmp    $0x2,%eax
  a68569:	jne    a6859e <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x20e>
  a6856b:	cmpl   $0xffffffff,0x20(%r14)
  a68570:	je     a685fa <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x26a>
  a68576:	add    $0x20,%r14
  a6857a:	mov    %r14,%rdi
  a6857d:	call   *0xac54d5(%rip)        # 152da58 <_DYNAMIC+0x1718>
  a68583:	jmp    a685fa <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x26a>
  a68585:	movb   $0x1,0x51(%r14)
  a6858a:	cmpl   $0xffffffff,0x20(%r14)
  a6858f:	je     a6859e <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x20e>
  a68591:	add    $0x20,%r14
  a68595:	mov    %r14,%rdi
  a68598:	call   *0xac54ba(%rip)        # 152da58 <_DYNAMIC+0x1718>
  a6859e:	lea    0x48(%rsp),%rdi
  a685a3:	call   a65630 <core::ptr::drop_glue::<gpui::native::accessibility::Command>>
  a685a8:	jmp    a685fa <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x26a>
  a685aa:	lea    -0xb(%rcx),%eax
  a685ad:	cmp    $0x4,%eax
  a685b0:	jae    a68609 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x279>
  a685b2:	test   %r15,%r15
  a685b5:	je     a685fa <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x26a>
  a685b7:	mov    $0x1,%edx
  a685bc:	mov    %rbx,%rdi
  a685bf:	mov    %r15,%rsi
  a685c2:	add    $0x78,%rsp
  a685c6:	pop    %rbx
  a685c7:	pop    %r12
  a685c9:	pop    %r13
  a685cb:	pop    %r14
  a685cd:	pop    %r15
  a685cf:	pop    %rbp
  a685d0:	jmp    *0xac3fba(%rip)        # 152c590 <_DYNAMIC+0x250>
  a685d6:	lea    -0xb(%rcx),%edx
  a685d9:	cmp    $0x4,%edx
  a685dc:	jae    a6863e <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x2ae>
  a685de:	lea    0x1(%rax),%edx
  a685e1:	cmp    $0x7,%edx
  a685e4:	ja     a684ad <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x11d>
  a685ea:	lea    -0x8c73f9(%rip),%rsi        # 1a11f8 <anon.e428ae78b0e0f39a29f34f7b379b57db.14.llvm.8900818267130919580+0xfc>
  a685f1:	movslq (%rsi,%rdx,4),%rdx
  a685f5:	add    %rsi,%rdx
  a685f8:	jmp    *%rdx
  a685fa:	add    $0x78,%rsp
  a685fe:	pop    %rbx
  a685ff:	pop    %r12
  a68601:	pop    %r13
  a68603:	pop    %r14
  a68605:	pop    %r15
  a68607:	pop    %rbp
  a68608:	ret
  a68609:	cmp    $0xa,%ecx
  a6860c:	je     a68613 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x283>
  a6860e:	cmp    $0x14,%ecx
  a68611:	jne    a685b2 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x222>
  a68613:	cmp    $0x10000,%r15
  a6861a:	jbe    a686ba <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x32a>
  a68620:	movb   $0x1,0x51(%r14)
  a68625:	cmpl   $0xffffffff,0x20(%r14)
  a6862a:	je     a685b7 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x227>
  a6862c:	add    $0x20,%r14
  a68630:	mov    %r14,%rdi
  a68633:	call   *0xac541f(%rip)        # 152da58 <_DYNAMIC+0x1718>
  a68639:	jmp    a685b7 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x227>
  a6863e:	cmp    $0xf,%ecx
  a68641:	je     a68697 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x307>
  a68643:	cmp    $0x11,%ecx
  a68646:	jne    a68449 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0xb9>
  a6864c:	cmp    $0x1,%eax
  a6864f:	je     a685b2 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x222>
  a68655:	cmp    $0x6,%eax
  a68658:	jne    a68452 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0xc2>
  a6865e:	movabs $0x7fffffffffffffff,%rax
  a68668:	mov    %rbx,%rcx
  a6866b:	and    %rax,%rcx
  a6866e:	movabs $0x7fefffffffffffff,%rdx
  a68678:	cmp    %rdx,%rcx
  a6867b:	setg   %cl
  a6867e:	and    %r15,%rax
  a68681:	cmp    %rdx,%rax
  a68684:	setg   %al
  a68687:	or     %cl,%al
  a68689:	jne    a685fa <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x26a>
  a6868f:	mov    $0x8,%bpl
  a68692:	jmp    a6851e <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x18e>
  a68697:	inc    %eax
  a68699:	cmp    $0x9,%eax
  a6869c:	ja     a685fa <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x26a>
  a686a2:	lea    -0x8c74d9(%rip),%rcx        # 1a11d0 <anon.e428ae78b0e0f39a29f34f7b379b57db.14.llvm.8900818267130919580+0xd4>
  a686a9:	movslq (%rcx,%rax,4),%rax
  a686ad:	add    %rcx,%rax
  a686b0:	jmp    *%rax
  a686b2:	mov    $0x9,%bpl
  a686b5:	jmp    a6851e <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x18e>
  a686ba:	xor    %eax,%eax
  a686bc:	cmp    $0x14,%ecx
  a686bf:	setne  %al
  a686c2:	lea    (%rax,%rax,2),%ebp
  a686c5:	add    $0x3,%ebp
  a686c8:	jmp    a6851e <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x18e>
  a686cd:	mov    $0x5,%bpl
  a686d0:	jmp    a6851e <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x18e>
  a686d5:	mov    %ebx,%edx
  a686d7:	jmp    a686db <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x34b>
  a686d9:	mov    $0x1,%dl
  a686db:	add    $0xf5,%cl
  a686de:	movzbl %cl,%ecx
  a686e1:	shl    $0x3,%ecx
  a686e4:	mov    $0x30201,%esi
  a686e9:	shr    %cl,%esi
  a686eb:	mov    $0x7,%bpl
  a686ee:	cmp    $0xffffffff,%eax
  a686f1:	je     a68721 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x391>
  a686f3:	cmp    $0x1,%eax
  a686f6:	setne  %al
  a686f9:	test   %r15,%r15
  a686fc:	sete   %cl
  a686ff:	or     %al,%cl
  a68701:	jne    a68721 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x391>
  a68703:	mov    %dl,0xf(%rsp)
  a68707:	mov    $0x1,%edx
  a6870c:	mov    %rbx,%rdi
  a6870f:	mov    %esi,%ebx
  a68711:	mov    %r15,%rsi
  a68714:	call   *0xac3e76(%rip)        # 152c590 <_DYNAMIC+0x250>
  a6871a:	mov    %ebx,%esi
  a6871c:	movzbl 0xf(%rsp),%edx
  a68721:	jmp    a6851e <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x18e>
  a68726:	mov    $0x8,%edi
  a6872b:	mov    $0x20,%esi
  a68730:	call   *0xac3e72(%rip)        # 152c5a8 <_DYNAMIC+0x268>
  a68736:	mov    %rax,%r14
  a68739:	mov    %rbx,%rdi
  a6873c:	call   a65150 <core::ptr::drop_glue::<alloc::boxed::Box<accesskit::TextReplacement>>>
  a68741:	mov    %r14,%rdi
  a68744:	call   14b6fa0 <_Unwind_Resume@plt>
  a68749:	mov    %rax,%r14
  a6874c:	mov    $0x1,%edx
  a68751:	mov    %rbx,%rdi
  a68754:	mov    %r15,%rsi
  a68757:	call   *0xac3e33(%rip)        # 152c590 <_DYNAMIC+0x250>
  a6875d:	mov    %r14,%rdi
  a68760:	call   14b6fa0 <_Unwind_Resume@plt>
  a68765:	mov    %rax,%r14
  a68768:	lea    0x48(%rsp),%rdi
  a6876d:	call   a65630 <core::ptr::drop_glue::<gpui::native::accessibility::Command>>
  a68772:	mov    %r14,%rdi
  a68775:	call   14b6fa0 <_Unwind_Resume@plt>
