
/tmp/gpui-a11y-owner-channel-captures/release-baseline/empty:     file format elf64-x86-64


Disassembly of section .text:

0000000000a3c690 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch>:
  a3c690:	push   %rbp
  a3c691:	push   %r15
  a3c693:	push   %r14
  a3c695:	push   %r13
  a3c697:	push   %r12
  a3c699:	push   %rbx
  a3c69a:	sub    $0xb88,%rsp
  a3c6a1:	mov    %rsi,%rbx
  a3c6a4:	mov    %rdi,%r14
  a3c6a7:	mov    (%rdx),%rax
  a3c6aa:	xor    %r13d,%r13d
  a3c6ad:	sub    $0x3,%rax
  a3c6b1:	cmovae %rax,%r13
  a3c6b5:	cmp    $0x2,%r13
  a3c6b9:	je     a3c8b6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x226>
  a3c6bf:	cmp    $0x8,%r13
  a3c6c3:	jne    a3c6d2 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x42>
  a3c6c5:	mov    %r14,%rdi
  a3c6c8:	call   a39e60 <<gpui::native::NativeHost<empty::Empty>>::retire_window>
  a3c6cd:	jmp    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3c6d2:	lea    0x188(%r14),%r12
  a3c6d9:	cmpw   $0x2,0x188(%r14)
  a3c6e2:	je     a3c869 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1d9>
  a3c6e8:	lea    0x250(%rsp),%rdi
  a3c6f0:	mov    %r12,%rsi
  a3c6f3:	mov    %rdx,%rbp
  a3c6f6:	call   *0xaf0fb4(%rip)        # 152d6b0 <_DYNAMIC+0x1370>
  a3c6fc:	mov    %rbp,%rdx
  a3c6ff:	mov    0x250(%rsp),%rax
  a3c707:	cmp    $0xfffffffffffffffe,%rax
  a3c70b:	je     a3c869 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1d9>
  a3c711:	cmp    $0xffffffffffffffff,%rax
  a3c715:	jne    a3c733 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xa3>
  a3c717:	cmpb   $0x0,0x208(%r14)
  a3c71f:	je     a3c7ab <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x11b>
  a3c725:	movq   $0x2f,0x1e8(%rsp)
  a3c731:	jmp    a3c757 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xc7>
  a3c733:	movups 0x258(%rsp),%xmm0
  a3c73b:	movups %xmm0,0x1f8(%rsp)
  a3c743:	movq   $0x30,0x1e8(%rsp)
  a3c74f:	mov    %rax,0x1f0(%rsp)
  a3c757:	lea    0xf8(%r14),%r15
  a3c75e:	cmpl   $0xfffffffe,0xf8(%r14)
  a3c766:	je     a3c770 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xe0>
  a3c768:	mov    %r15,%rdi
  a3c76b:	call   a36f00 <core::ptr::drop_glue::<gpui::native::NativeError>>
  a3c770:	mov    0x218(%rsp),%rax
  a3c778:	mov    %rax,0x30(%r15)
  a3c77c:	movupd 0x1e8(%rsp),%xmm0
  a3c785:	movupd 0x1f8(%rsp),%xmm1
  a3c78e:	movups 0x208(%rsp),%xmm2
  a3c796:	movups %xmm2,0x20(%r15)
  a3c79b:	movupd %xmm1,0x10(%r15)
  a3c7a1:	movupd %xmm0,(%r15)
  a3c7a6:	jmp    a3dc7d <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x15ed>
  a3c7ab:	mov    $0x1,%al
  a3c7ad:	cmpb   $0x0,(%r14)
  a3c7b1:	je     a3c7e4 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154>
  a3c7b3:	mov    0x8(%r14),%rax
  a3c7b7:	test   %rax,%rax
  a3c7ba:	je     a3cfa8 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x918>
  a3c7c0:	mov    $0xe,%r15d
  a3c7c6:	cmpb   $0x0,0x72e(%rax)
  a3c7cd:	jne    a3cfae <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x91e>
  a3c7d3:	movb   $0x0,0x72c(%rax)
  a3c7da:	movzbl 0x208(%r14),%eax
  a3c7e2:	inc    %al
  a3c7e4:	mov    %al,0x208(%r14)
  a3c7eb:	lea    0xe0(%r14),%r15
  a3c7f2:	mov    %r15,%rdi
  a3c7f5:	call   a34700 <core::ptr::drop_glue::<core::option::Option<gpui::native::upgrade::Upgrade>>>
  a3c7fa:	movq   $0xffffffffffffffff,0xe0(%r14)
  a3c805:	movb   $0x0,0x206(%r14)
  a3c80d:	lea    0x1d0(%r14),%r15
  a3c814:	mov    0x1d0(%r14),%rax
  a3c81b:	test   %rax,%rax
  a3c81e:	je     a3c82f <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x19f>
  a3c820:	lock decq (%rax)
  a3c824:	jne    a3c82f <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x19f>
  a3c826:	mov    %r15,%rdi
  a3c829:	call   *0xaf0691(%rip)        # 152cec0 <_DYNAMIC+0xb80>
  a3c82f:	movq   $0x0,(%r15)
  a3c836:	mov    %r12,%rdi
  a3c839:	call   a344d0 <core::ptr::drop_glue::<core::option::Option<gpui::native::Graphics>>>
  a3c83e:	movw   $0x2,0x188(%r14)
  a3c848:	lea    0x1e8(%rsp),%rdi
  a3c850:	mov    %r14,%rsi
  a3c853:	call   a3a1b0 <<gpui::native::NativeHost<empty::Empty>>::create_surface>
  a3c858:	cmpl   $0xfffffffe,0x1e8(%rsp)
  a3c860:	mov    %rbp,%rdx
  a3c863:	jne    a3c757 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xc7>
  a3c869:	cmp    $0x6,%r13
  a3c86d:	ja     a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3c873:	lea    -0x8a3bba(%rip),%rax        # 198cc0 <anon.7cc7c74d1b8f8dfb5e74abfe8b727cdb.77.llvm.18220644203745900989+0x4cc>
  a3c87a:	movslq (%rax,%r13,4),%rcx
  a3c87e:	add    %rax,%rcx
  a3c881:	jmp    *%rcx
  a3c883:	mov    0x180(%r14),%ebp
  a3c88a:	cmp    $0xffffffff,%ebp
  a3c88d:	je     a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3c893:	mov    0x178(%r14),%r15
  a3c89a:	call   *0xaf07b0(%rip)        # 152d050 <_DYNAMIC+0xd10>
  a3c8a0:	cmp    %rax,%r15
  a3c8a3:	jne    a3cead <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x81d>
  a3c8a9:	cmp    %edx,%ebp
  a3c8ab:	jbe    a3ceb3 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x823>
  a3c8b1:	jmp    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3c8b6:	movb   $0x1,0x205(%r14)
  a3c8be:	mov    $0xffffffff,%eax
  a3c8c3:	mov    %rax,0x1b0(%r14)
  a3c8ca:	movq   $0x0,0x1b8(%r14)
  a3c8d5:	mov    0x1d8(%r14),%rdi
  a3c8dc:	test   %rdi,%rdi
  a3c8df:	je     a3c8ec <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x25c>
  a3c8e1:	add    $0x10,%rdi
  a3c8e5:	xor    %esi,%esi
  a3c8e7:	call   a3bd90 <<winit::window::Window>::set_visible>
  a3c8ec:	lea    0xe0(%r14),%r15
  a3c8f3:	mov    %r15,%rdi
  a3c8f6:	call   a34700 <core::ptr::drop_glue::<core::option::Option<gpui::native::upgrade::Upgrade>>>
  a3c8fb:	movq   $0xffffffffffffffff,0xe0(%r14)
  a3c906:	movb   $0x0,0x206(%r14)
  a3c90e:	mov    0x1d0(%r14),%rax
  a3c915:	test   %rax,%rax
  a3c918:	je     a3c930 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x2a0>
  a3c91a:	lock decq (%rax)
  a3c91e:	jne    a3c930 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x2a0>
  a3c920:	lea    0x1d0(%r14),%r15
  a3c927:	mov    %r15,%rdi
  a3c92a:	call   *0xaf0590(%rip)        # 152cec0 <_DYNAMIC+0xb80>
  a3c930:	movq   $0x0,0x1d0(%r14)
  a3c93b:	movzwl 0x188(%r14),%eax
  a3c943:	cmp    $0x2,%eax
  a3c946:	je     a3c966 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x2d6>
  a3c948:	test   %eax,%eax
  a3c94a:	jne    a3c95a <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x2ca>
  a3c94c:	mov    0x190(%r14),%rdi
  a3c953:	call   a34fc0 <core::ptr::drop_glue::<alloc::boxed::Box<gpui::native::GpuSurface>>>
  a3c958:	jmp    a3c966 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x2d6>
  a3c95a:	mov    0x1a8(%r14),%rdi
  a3c961:	call   a33440 <core::ptr::drop_glue::<softbuffer::Surface<alloc::sync::Arc<winit::window::Window>, alloc::sync::Arc<winit::window::Window>>>>
  a3c966:	movw   $0x2,0x188(%r14)
  a3c970:	cmpl   $0x1,(%r14)
  a3c974:	jne    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3c97a:	mov    0x8(%r14),%rax
  a3c97e:	test   %rax,%rax
  a3c981:	je     a3c993 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x303>
  a3c983:	cmpb   $0x0,0x72e(%rax)
  a3c98a:	je     a3c9f6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x366>
  a3c98c:	mov    $0xe,%ebp
  a3c991:	jmp    a3c998 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x308>
  a3c993:	mov    $0xd,%ebp
  a3c998:	xor    %r13d,%r13d
  a3c99b:	cmpl   $0xfffffffe,0xf8(%r14)
  a3c9a3:	je     a3c9b1 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x321>
  a3c9a5:	lea    0xf8(%r14),%rdi
  a3c9ac:	call   a36f00 <core::ptr::drop_glue::<gpui::native::NativeError>>
  a3c9b1:	mov    %rbp,0xf8(%r14)
  a3c9b8:	mov    %r13,0x100(%r14)
  a3c9bf:	mov    %r12,0x108(%r14)
  a3c9c6:	mov    %r15,0x110(%r14)
  a3c9cd:	movapd 0x10(%rsp),%xmm0
  a3c9d3:	movupd %xmm0,0x118(%r14)
  a3c9dc:	mov    0x20(%rsp),%rax
  a3c9e1:	mov    %rax,0x128(%r14)
  a3c9e8:	mov    %rbx,%rdi
  a3c9eb:	call   *0xaf0cc7(%rip)        # 152d6b8 <_DYNAMIC+0x1378>
  a3c9f1:	jmp    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3c9f6:	movb   $0x0,0x72c(%rax)
  a3c9fd:	jmp    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3ca02:	mov    0x130(%r14),%rax
  a3ca09:	movq   $0xffffffffffffffff,0x130(%r14)
  a3ca14:	cmp    $0xffffffffffffffff,%rax
  a3ca18:	je     a3d4ad <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xe1d>
  a3ca1e:	mov    %rax,0x68(%rsp)
  a3ca23:	mov    %rax,0x70(%rsp)
  a3ca28:	movupd 0x138(%r14),%xmm0
  a3ca31:	movupd 0x148(%r14),%xmm1
  a3ca3a:	movups 0x158(%r14),%xmm2
  a3ca42:	movups 0x168(%r14),%xmm3
  a3ca4a:	movupd %xmm0,0x78(%rsp)
  a3ca50:	movupd %xmm1,0x88(%rsp)
  a3ca59:	movups %xmm2,0x98(%rsp)
  a3ca61:	movups %xmm3,0xa8(%rsp)
  a3ca69:	lea    0xb8(%rsp),%rdi
  a3ca71:	lea    0x70(%rsp),%rsi
  a3ca76:	call   *0xaf01dc(%rip)        # 152cc58 <_DYNAMIC+0x918>
  a3ca7c:	mov    0x90(%rsp),%rbp
  a3ca84:	mov    0x98(%rsp),%rax
  a3ca8c:	mov    %rax,0x8(%rsp)
  a3ca91:	mov    0x1e0(%r14),%r13
  a3ca98:	test   %r13,%r13
  a3ca9b:	je     a3cac7 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x437>
  a3ca9d:	mov    0x1e8(%r14),%r15
  a3caa4:	mov    (%r15),%rax
  a3caa7:	test   %rax,%rax
  a3caaa:	je     a3cab1 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x421>
  a3caac:	mov    %r13,%rdi
  a3caaf:	call   *%rax
  a3cab1:	mov    0x8(%r15),%rsi
  a3cab5:	test   %rsi,%rsi
  a3cab8:	je     a3cac7 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x437>
  a3caba:	mov    0x10(%r15),%rdx
  a3cabe:	mov    %r13,%rdi
  a3cac1:	call   *0xaefac9(%rip)        # 152c590 <_DYNAMIC+0x250>
  a3cac7:	mov    %rbp,0x1e0(%r14)
  a3cace:	mov    0x8(%rsp),%rax
  a3cad3:	mov    %rax,0x1e8(%r14)
  a3cada:	mov    0xa0(%rsp),%rbp
  a3cae2:	mov    0xa8(%rsp),%rax
  a3caea:	mov    %rax,0x8(%rsp)
  a3caef:	mov    0x1f0(%r14),%r13
  a3caf6:	test   %r13,%r13
  a3caf9:	je     a3cb25 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x495>
  a3cafb:	mov    0x1f8(%r14),%r15
  a3cb02:	mov    (%r15),%rax
  a3cb05:	test   %rax,%rax
  a3cb08:	je     a3cb0f <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x47f>
  a3cb0a:	mov    %r13,%rdi
  a3cb0d:	call   *%rax
  a3cb0f:	mov    0x8(%r15),%rsi
  a3cb13:	test   %rsi,%rsi
  a3cb16:	je     a3cb25 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x495>
  a3cb18:	mov    0x10(%r15),%rdx
  a3cb1c:	mov    %r13,%rdi
  a3cb1f:	call   *0xaefa6b(%rip)        # 152c590 <_DYNAMIC+0x250>
  a3cb25:	mov    %rbp,0x1f0(%r14)
  a3cb2c:	mov    0x8(%rsp),%rax
  a3cb31:	mov    %rax,0x1f8(%r14)
  a3cb38:	call   *0xaefa42(%rip)        # 152c580 <_DYNAMIC+0x240>
  a3cb3e:	movq   $0xfffffffffffffffd,0x100(%rsp)
  a3cb4a:	lea    0x250(%rsp),%rdi
  a3cb52:	call   *0xaf0b68(%rip)        # 152d6c0 <_DYNAMIC+0x1380>
  a3cb58:	lea    0x8d0(%rsp),%rdi
  a3cb60:	lea    0x100(%rsp),%r13
  a3cb68:	mov    0xaefa31(%rip),%r15        # 152c5a0 <memcpy@GLIBC_2.14>
  a3cb6f:	mov    $0x90,%edx
  a3cb74:	mov    %r13,%rsi
  a3cb77:	call   *%r15
  a3cb7a:	lea    0x818(%rsp),%rdi
  a3cb82:	lea    0x250(%rsp),%rsi
  a3cb8a:	mov    $0x98,%edx
  a3cb8f:	call   *%r15
  a3cb92:	movups 0x78(%rsp),%xmm0
  a3cb97:	mov    0x68(%rsp),%rax
  a3cb9c:	mov    %rax,0x800(%rsp)
  a3cba4:	movups %xmm0,0x808(%rsp)
  a3cbac:	movq   $0xffffffffffffffff,0x8b0(%rsp)
  a3cbb8:	movl   $0x1,0x960(%rsp)
  a3cbc3:	movsd  0x88(%rsp),%xmm0
  a3cbcc:	xorpd  %xmm1,%xmm1
  a3cbd0:	unpcklps %xmm1,%xmm0
  a3cbd3:	movapd -0x8b016b(%rip),%xmm1        # 18ca70 <anon.89c1a9733c414c7e4e56fa7f22cdc6b9.309.llvm.3311541718473421078+0x8c0>
  a3cbdb:	orpd   %xmm1,%xmm0
  a3cbdf:	subpd  %xmm1,%xmm0
  a3cbe3:	movupd %xmm0,0x968(%rsp)
  a3cbec:	movl   $0x2,0x978(%rsp)
  a3cbf7:	movl   $0x2,0x990(%rsp)
  a3cc02:	movl   $0x2,0x9a8(%rsp)
  a3cc0d:	movl   $0x2,0x9c0(%rsp)
  a3cc18:	movl   $0xffffffff,0x9d8(%rsp)
  a3cc23:	movw   $0x0,0x9f0(%rsp)
  a3cc2d:	movl   $0x7,0xa00(%rsp)
  a3cc38:	movw   $0x102,0xa0c(%rsp)
  a3cc42:	movabs $0x100010000000001,%rax
  a3cc4c:	mov    %rax,0xa04(%rsp)
  a3cc54:	mov    0xaf054d(%rip),%rax        # 152d1a8 <_DYNAMIC+0xe68>
  a3cc5b:	mov    (%rax),%rax
  a3cc5e:	cmp    $0x2,%rax
  a3cc62:	jae    a3d0c9 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xa39>
  a3cc68:	mov    0xaf0a59(%rip),%r15        # 152d6c8 <_DYNAMIC+0x1388>
  a3cc6f:	movzbl 0x10(%r15),%eax
  a3cc74:	movzbl %al,%ecx
  a3cc77:	lea    -0x1(%rcx),%edx
  a3cc7a:	cmp    $0x2,%edx
  a3cc7d:	jae    a3d0c1 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xa31>
  a3cc83:	mov    (%r15),%rdi
  a3cc86:	movzbl %al,%esi
  a3cc89:	call   *0xaf0529(%rip)        # 152d1b8 <_DYNAMIC+0xe78>
  a3cc8f:	test   %al,%al
  a3cc91:	je     a3d0c9 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xa39>
  a3cc97:	mov    (%r15),%rsi
  a3cc9a:	lea    0x30(%rsi),%rax
  a3cc9e:	lea    0x800(%rsp),%rcx
  a3cca6:	mov    %rcx,0xd0(%rsp)
  a3ccae:	lea    0xd0(%rsp),%rcx
  a3ccb6:	mov    %rcx,0x100(%rsp)
  a3ccbe:	lea    0xa7f5d3(%rip),%rcx        # 14bc298 <anon.f48bbd6ee32d24e1254dac28089ef4b7.8.llvm.17379179981059708172+0xb8>
  a3ccc5:	mov    %rcx,0x108(%rsp)
  a3cccd:	movq   $0x1,0x250(%rsp)
  a3ccd9:	mov    %r13,0x258(%rsp)
  a3cce1:	movq   $0x1,0x260(%rsp)
  a3cced:	mov    %rax,0x268(%rsp)
  a3ccf5:	lea    0x40(%rsp),%rdi
  a3ccfa:	lea    0x250(%rsp),%rdx
  a3cd02:	call   *0xaf0588(%rip)        # 152d290 <_DYNAMIC+0xf50>
  a3cd08:	cmpq   $0x2,0x40(%rsp)
  a3cd0e:	je     a3d0db <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xa4b>
  a3cd14:	lea    0x58(%rsp),%rsi
  a3cd19:	lea    0x40(%rsp),%rdi
  a3cd1e:	call   *0xaf0574(%rip)        # 152d298 <_DYNAMIC+0xf58>
  a3cd24:	jmp    a3d0db <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xa4b>
  a3cd29:	mov    0x178(%r14),%rax
  a3cd30:	mov    0x180(%r14),%ecx
  a3cd37:	testb  $0x1,0x204(%r14)
  a3cd3f:	mov    $0x3b9aca01,%edx
  a3cd44:	mov    %ecx,%esi
  a3cd46:	cmovne %edx,%esi
  a3cd49:	cmp    $0xffffffff,%ecx
  a3cd4c:	cmove  %edx,%esi
  a3cd4f:	mov    %rax,0x68(%rbx)
  a3cd53:	mov    %esi,0x70(%rbx)
  a3cd56:	jmp    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3cd5b:	mov    0x1d8(%r14),%r12
  a3cd62:	test   %r12,%r12
  a3cd65:	je     a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3cd6b:	mov    %rdx,%r15
  a3cd6e:	mov    0xaf0433(%rip),%rax        # 152d1a8 <_DYNAMIC+0xe68>
  a3cd75:	mov    (%rax),%rax
  a3cd78:	cmp    $0x1,%rax
  a3cd7c:	ja     a3cfe3 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x953>
  a3cd82:	mov    0xaf0947(%rip),%r13        # 152d6d0 <_DYNAMIC+0x1390>
  a3cd89:	movzbl 0x10(%r13),%eax
  a3cd8e:	movzbl %al,%ecx
  a3cd91:	lea    -0x1(%rcx),%edx
  a3cd94:	cmp    $0x2,%edx
  a3cd97:	jae    a3cfdb <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x94b>
  a3cd9d:	mov    0x0(%r13),%rdi
  a3cda1:	movzbl %al,%esi
  a3cda4:	call   *0xaf040e(%rip)        # 152d1b8 <_DYNAMIC+0xe78>
  a3cdaa:	test   %al,%al
  a3cdac:	je     a3cfe3 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x953>
  a3cdb2:	mov    0x0(%r13),%rsi
  a3cdb6:	lea    0x30(%rsi),%rax
  a3cdba:	movq   $0x1,0x800(%rsp)
  a3cdc6:	movq   $0x8,0x808(%rsp)
  a3cdd2:	movq   $0x0,0x810(%rsp)
  a3cdde:	mov    %rax,0x818(%rsp)
  a3cde6:	lea    0x250(%rsp),%rdi
  a3cdee:	lea    0x800(%rsp),%rdx
  a3cdf6:	call   *0xaf0494(%rip)        # 152d290 <_DYNAMIC+0xf50>
  a3cdfc:	cmpq   $0x2,0x250(%rsp)
  a3ce05:	je     a3cffb <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x96b>
  a3ce0b:	lea    0x268(%rsp),%rsi
  a3ce13:	lea    0x250(%rsp),%rdi
  a3ce1b:	call   *0xaf0477(%rip)        # 152d298 <_DYNAMIC+0xf58>
  a3ce21:	jmp    a3cffb <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x96b>
  a3ce26:	cmpl   $0xffffffff,0x10(%r14)
  a3ce2b:	setne  %cl
  a3ce2e:	mov    (%r14),%rax
  a3ce31:	test   %al,%cl
  a3ce33:	je     a3d54b <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xebb>
  a3ce39:	lea    0x10(%r14),%r15
  a3ce3d:	lea    0x8(%r14),%rdx
  a3ce41:	lea    0x800(%rsp),%rdi
  a3ce49:	mov    %r15,%rsi
  a3ce4c:	call   9e5c90 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>>
  a3ce51:	cmpl   $0xfffffffc,0x800(%rsp)
  a3ce59:	jne    a3cec3 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x833>
  a3ce5b:	mov    %r15,%rdi
  a3ce5e:	call   a345d0 <core::ptr::drop_glue::<core::option::Option<gpui::native::accessibility::Bridge>>>
  a3ce63:	lea    0x808(%rsp),%r12
  a3ce6b:	movq   $0xffffffffffffffff,0x10(%r14)
  a3ce73:	lea    0xf8(%r14),%r15
  a3ce7a:	cmpl   $0xfffffffe,0xf8(%r14)
  a3ce82:	je     a3ce8c <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x7fc>
  a3ce84:	mov    %r15,%rdi
  a3ce87:	call   a36f00 <core::ptr::drop_glue::<gpui::native::NativeError>>
  a3ce8c:	mov    0x30(%r12),%rax
  a3ce91:	mov    %rax,0x30(%r15)
  a3ce95:	movupd (%r12),%xmm0
  a3ce9b:	movupd 0x10(%r12),%xmm1
  a3cea2:	movups 0x20(%r12),%xmm2
  a3cea8:	jmp    a3c796 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x106>
  a3cead:	jg     a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3ceb3:	movl   $0xffffffff,0x180(%r14)
  a3cebe:	jmp    a3dbbf <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x152f>
  a3cec3:	lea    0x268(%rsp),%rdi
  a3cecb:	lea    0x800(%rsp),%rsi
  a3ced3:	mov    $0x380,%edx
  a3ced8:	call   *0xaef6c2(%rip)        # 152c5a0 <memcpy@GLIBC_2.14>
  a3cede:	movq   $0x1,0x250(%rsp)
  a3ceea:	movq   $0x10,0x260(%rsp)
  a3cef6:	movq   $0xfffffffffffffffc,0x5e8(%rsp)
  a3cf02:	movq   $0xfffffffffffffffc,0x620(%rsp)
  a3cf0e:	lea    0x108(%rsp),%rbp
  a3cf16:	lea    0x270(%rsp),%r15
  a3cf1e:	xor    %r13d,%r13d
  a3cf21:	lea    0x100(%rsp),%r12
  a3cf29:	mov    -0x8(%r15),%rax
  a3cf2d:	cmp    $0xfffffffffffffffd,%rax
  a3cf31:	je     a3cf84 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x8f4>
  a3cf33:	cmp    $0xfffffffffffffffc,%rax
  a3cf37:	je     a3d530 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xea0>
  a3cf3d:	movupd (%r15),%xmm0
  a3cf42:	movupd 0x10(%r15),%xmm1
  a3cf48:	movups 0x20(%r15),%xmm2
  a3cf4d:	movups %xmm2,0x20(%rbp)
  a3cf51:	movupd %xmm1,0x10(%rbp)
  a3cf56:	movupd %xmm0,0x0(%rbp)
  a3cf5b:	mov    %rax,0x100(%rsp)
  a3cf63:	lea    0x6b0(%rsp),%rdi
  a3cf6b:	mov    %r14,%rsi
  a3cf6e:	mov    %r12,%rdx
  a3cf71:	call   a39ce0 <<gpui::native::NativeHost<empty::Empty>>::input_result>
  a3cf76:	cmpl   $0xfffffffe,0x6b0(%rsp)
  a3cf7e:	jne    a3d63b <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xfab>
  a3cf84:	cmp    $0xf,%r13
  a3cf88:	je     a3cf9d <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x90d>
  a3cf8a:	add    $0x38,%r15
  a3cf8e:	inc    %r13
  a3cf91:	mov    -0x8(%r15),%rax
  a3cf95:	cmp    $0xfffffffffffffffd,%rax
  a3cf99:	jne    a3cf33 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x8a3>
  a3cf9b:	jmp    a3cf84 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x8f4>
  a3cf9d:	mov    $0x10,%r13d
  a3cfa3:	jmp    a3d533 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xea3>
  a3cfa8:	mov    $0xd,%r15d
  a3cfae:	cmpl   $0xfffffffe,0xf8(%r14)
  a3cfb6:	je     a3cfc4 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x934>
  a3cfb8:	lea    0xf8(%r14),%rdi
  a3cfbf:	call   a36f00 <core::ptr::drop_glue::<gpui::native::NativeError>>
  a3cfc4:	mov    %r15,0xf8(%r14)
  a3cfcb:	movq   $0x0,0x100(%r14)
  a3cfd6:	jmp    a3dc7d <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x15ed>
  a3cfdb:	test   %ecx,%ecx
  a3cfdd:	jne    a3e01d <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x198d>
  a3cfe3:	movq   $0x2,0x250(%rsp)
  a3cfef:	movq   $0x0,0x270(%rsp)
  a3cffb:	mov    0x270(%rsp),%rax
  a3d003:	mov    %rax,0x820(%rsp)
  a3d00b:	mov    0x250(%rsp),%rax
  a3d013:	mov    0x258(%rsp),%rcx
  a3d01b:	movupd 0x260(%rsp),%xmm0
  a3d024:	movapd %xmm0,0x810(%rsp)
  a3d02d:	mov    %rax,0x800(%rsp)
  a3d035:	mov    %rcx,0x808(%rsp)
  a3d03d:	mov    0x10(%r12),%rax
  a3d042:	mov    0x310(%rax),%r12d
  a3d049:	lea    0x800(%rsp),%rdi
  a3d051:	call   a36d90 <core::ptr::drop_glue::<tracing::span::EnteredSpan>>
  a3d056:	cmp    %r12,0x10(%r15)
  a3d05a:	jne    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3d060:	mov    0x8(%r15),%r15
  a3d064:	cmpl   $0xffffffff,0x10(%r14)
  a3d069:	je     a3d088 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x9f8>
  a3d06b:	mov    0x1d8(%r14),%rsi
  a3d072:	test   %rsi,%rsi
  a3d075:	je     a3d088 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x9f8>
  a3d077:	lea    0x10(%r14),%rdi
  a3d07b:	add    $0x10,%rsi
  a3d07f:	mov    %r15,%rdx
  a3d082:	call   *0xaf0650(%rip)        # 152d6d8 <_DYNAMIC+0x1398>
  a3d088:	movzwl (%r15),%eax
  a3d08c:	mov    %eax,%ecx
  a3d08e:	sub    $0x4,%cx
  a3d092:	mov    $0x9,%edx
  a3d097:	cmovae %ecx,%edx
  a3d09a:	movzwl %dx,%ecx
  a3d09d:	dec    %ecx
  a3d09f:	cmp    $0x1a,%ecx
  a3d0a2:	ja     a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3d0a8:	lea    -0x8a43d3(%rip),%rdx        # 198cdc <anon.7cc7c74d1b8f8dfb5e74abfe8b727cdb.77.llvm.18220644203745900989+0x4e8>
  a3d0af:	movslq (%rdx,%rcx,4),%rcx
  a3d0b3:	add    %rdx,%rcx
  a3d0b6:	jmp    *%rcx
  a3d0b8:	mov    0x4(%r15),%rdx
  a3d0bc:	jmp    a3d803 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1173>
  a3d0c1:	test   %ecx,%ecx
  a3d0c3:	jne    a3e037 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x19a7>
  a3d0c9:	movq   $0x2,0x40(%rsp)
  a3d0d2:	movq   $0x0,0x60(%rsp)
  a3d0db:	mov    0x60(%rsp),%rax
  a3d0e0:	mov    %rax,0xf0(%rsp)
  a3d0e8:	mov    0x40(%rsp),%rax
  a3d0ed:	mov    0x48(%rsp),%rcx
  a3d0f2:	movupd 0x50(%rsp),%xmm0
  a3d0f8:	movapd %xmm0,0xe0(%rsp)
  a3d101:	mov    %rax,0xd0(%rsp)
  a3d109:	mov    %rcx,0xd8(%rsp)
  a3d111:	lea    0x250(%rsp),%r13
  a3d119:	lea    0x800(%rsp),%rsi
  a3d121:	mov    $0x210,%edx
  a3d126:	mov    %r13,%rdi
  a3d129:	call   *0xaef471(%rip)        # 152c5a0 <memcpy@GLIBC_2.14>
  a3d12f:	lea    0x100(%rsp),%rdi
  a3d137:	mov    %rbx,%rsi
  a3d13a:	mov    %r13,%rdx
  a3d13d:	call   *0xaf059d(%rip)        # 152d6e0 <_DYNAMIC+0x13a0>
  a3d143:	mov    0x100(%rsp),%r15
  a3d14b:	cmp    $0xffffffffffffffff,%r15
  a3d14f:	je     a3d185 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xaf5>
  a3d151:	mov    0x130(%rsp),%rax
  a3d159:	mov    %rax,0x240(%rsp)
  a3d161:	movupd 0x110(%rsp),%xmm0
  a3d16a:	movupd 0x120(%rsp),%xmm1
  a3d173:	movapd %xmm1,0x230(%rsp)
  a3d17c:	movapd %xmm0,0x220(%rsp)
  a3d185:	mov    0x108(%rsp),%r13
  a3d18d:	lea    0xd0(%rsp),%rdi
  a3d195:	call   a36d90 <core::ptr::drop_glue::<tracing::span::EnteredSpan>>
  a3d19a:	cmp    $0xffffffffffffffff,%r15
  a3d19e:	je     a3d293 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xc03>
  a3d1a4:	mov    %r15,0x250(%rsp)
  a3d1ac:	mov    %r13,0x258(%rsp)
  a3d1b4:	movapd 0x220(%rsp),%xmm0
  a3d1bd:	movapd 0x230(%rsp),%xmm1
  a3d1c6:	movupd %xmm0,0x260(%rsp)
  a3d1cf:	movupd %xmm1,0x270(%rsp)
  a3d1d8:	mov    0x240(%rsp),%rax
  a3d1e0:	mov    %rax,0x280(%rsp)
  a3d1e8:	movq   $0x0,0x40(%rsp)
  a3d1f1:	movq   $0x1,0x48(%rsp)
  a3d1fa:	movq   $0x0,0x50(%rsp)
  a3d203:	movq   $0x60000020,0x110(%rsp)
  a3d20f:	lea    0x40(%rsp),%rax
  a3d214:	mov    %rax,0x100(%rsp)
  a3d21c:	lea    0xa7f20d(%rip),%rax        # 14bc430 <anon.f48bbd6ee32d24e1254dac28089ef4b7.58.llvm.17379179981059708172>
  a3d223:	mov    %rax,0x108(%rsp)
  a3d22b:	lea    0x250(%rsp),%rdi
  a3d233:	lea    0x100(%rsp),%rsi
  a3d23b:	call   *0xaf04a7(%rip)        # 152d6e8 <_DYNAMIC+0x13a8>
  a3d241:	test   %al,%al
  a3d243:	jne    a3df82 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x18f2>
  a3d249:	mov    0x40(%rsp),%r13
  a3d24e:	mov    0x48(%rsp),%r12
  a3d253:	mov    0x50(%rsp),%r15
  a3d258:	lea    0x250(%rsp),%rdi
  a3d260:	call   a36000 <core::ptr::drop_glue::<winit::error::OsError>>
  a3d265:	mov    $0x2d,%ebp
  a3d26a:	mov    0xb8(%rsp),%rsi
  a3d272:	test   %rsi,%rsi
  a3d275:	je     a3c99b <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x30b>
  a3d27b:	mov    0xc0(%rsp),%rdi
  a3d283:	mov    $0x1,%edx
  a3d288:	call   *0xaef302(%rip)        # 152c590 <_DYNAMIC+0x250>
  a3d28e:	jmp    a3c99b <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x30b>
  a3d293:	movq   $0x1,0x250(%rsp)
  a3d29f:	movq   $0x1,0x258(%rsp)
  a3d2ab:	mov    %r13,0x260(%rsp)
  a3d2b3:	call   *0xaef2c7(%rip)        # 152c580 <_DYNAMIC+0x240>
  a3d2b9:	mov    $0x18,%edi
  a3d2be:	mov    $0x8,%esi
  a3d2c3:	call   *0xaef2bf(%rip)        # 152c588 <_DYNAMIC+0x248>
  a3d2c9:	test   %rax,%rax
  a3d2cc:	je     a3dfc5 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1935>
  a3d2d2:	mov    %rax,%rcx
  a3d2d5:	mov    0x260(%rsp),%rdx
  a3d2dd:	mov    %rdx,0x10(%rax)
  a3d2e1:	movups 0x250(%rsp),%xmm0
  a3d2e9:	movups %xmm0,(%rax)
  a3d2ec:	add    $0x10,%rax
  a3d2f0:	mov    %rcx,0x30(%rsp)
  a3d2f5:	mov    %rax,%rdi
  a3d2f8:	call   a3bc10 <<winit::window::Window>::inner_size>
  a3d2fd:	cmp    $0x1,%eax
  a3d300:	adc    $0x0,%eax
  a3d303:	cmp    $0x1,%edx
  a3d306:	adc    $0x0,%edx
  a3d309:	mov    %eax,0x110(%rsp)
  a3d310:	mov    %edx,0x114(%rsp)
  a3d317:	movl   $0x0,0x100(%rsp)
  a3d322:	movl   $0x434b0000,0x108(%rsp)
  a3d32d:	movw   $0x0,0x10c(%rsp)
  a3d337:	mov    0x30(%rsp),%rdi
  a3d33c:	add    $0x10,%rdi
  a3d340:	call   a38880 <<winit::window::Window>::scale_factor>
  a3d345:	cvtsd2ss %xmm0,%xmm0
  a3d349:	movzbl 0xb0(%rsp),%edx
  a3d351:	lea    0x250(%rsp),%rdi
  a3d359:	lea    0x100(%rsp),%rsi
  a3d361:	call   9c2780 <<gpui::runtime::Win<empty::Empty>>::recording_lanes>
  a3d366:	mov    0x250(%rsp),%rbp
  a3d36e:	mov    0x258(%rsp),%r13
  a3d376:	cmp    $0xfffffffffffffffe,%rbp
  a3d37a:	jne    a3d501 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xe71>
  a3d380:	mov    0xc0(%r14),%rax
  a3d387:	cmp    $0xffffffffffffffff,%rax
  a3d38b:	sete   %bpl
  a3d38f:	cmp    $0xffffffff,%eax
  a3d392:	je     a3d758 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x10c8>
  a3d398:	mov    %ebp,0x8(%rsp)
  a3d39c:	mov    0x30(%rsp),%rbp
  a3d3a1:	mov    0xd8(%r14),%r15
  a3d3a8:	lock incq (%r15)
  a3d3ac:	jle    a3e079 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x19e9>
  a3d3b2:	lea    0xc0(%r14),%rsi
  a3d3b9:	mov    %r15,0xd0(%rsp)
  a3d3c1:	lea    0x40(%rsp),%rdi
  a3d3c6:	call   a449f0 <<winit::platform_impl::linux::x11::WakeSender<()> as core::clone::Clone>::clone>
  a3d3cb:	add    $0x10,%rbp
  a3d3cf:	movups 0x40(%rsp),%xmm0
  a3d3d4:	mov    0x50(%rsp),%rax
  a3d3d9:	movups %xmm0,0x690(%rsp)
  a3d3e1:	mov    %rax,0x6a0(%rsp)
  a3d3e9:	mov    %r15,0x6a8(%rsp)
  a3d3f1:	mov    0xc8(%rsp),%rax
  a3d3f9:	mov    %rax,0x50(%rsp)
  a3d3fe:	movups 0xb8(%rsp),%xmm0
  a3d406:	movaps %xmm0,0x40(%rsp)
  a3d40b:	lea    0x250(%rsp),%rdi
  a3d413:	lea    0x690(%rsp),%rcx
  a3d41b:	lea    0x40(%rsp),%r8
  a3d420:	mov    %rbx,%rsi
  a3d423:	mov    %rbp,%rdx
  a3d426:	call   *0xaf02c4(%rip)        # 152d6f0 <_DYNAMIC+0x13b0>
  a3d42c:	lea    0x100(%rsp),%rdi
  a3d434:	lea    0x250(%rsp),%rsi
  a3d43c:	mov    $0xb0,%edx
  a3d441:	call   *0xaef159(%rip)        # 152c5a0 <memcpy@GLIBC_2.14>
  a3d447:	lea    0x10(%r14),%rbp
  a3d44b:	mov    %rbp,%rdi
  a3d44e:	call   a345d0 <core::ptr::drop_glue::<core::option::Option<gpui::native::accessibility::Bridge>>>
  a3d453:	lea    0x100(%rsp),%rsi
  a3d45b:	mov    $0xb0,%edx
  a3d460:	mov    %rbp,%rdi
  a3d463:	call   *0xaef137(%rip)        # 152c5a0 <memcpy@GLIBC_2.14>
  a3d469:	cmpq   $0x0,(%r14)
  a3d46d:	je     a3d478 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xde8>
  a3d46f:	mov    0x8(%r14),%rdi
  a3d473:	call   a35160 <core::ptr::drop_glue::<gpui::runtime::Win<empty::Empty>>>
  a3d478:	movq   $0x1,(%r14)
  a3d47f:	mov    %r13,0x8(%r14)
  a3d483:	mov    0x30(%rsp),%r13
  a3d488:	lea    0x1d8(%r14),%r15
  a3d48f:	mov    0x1d8(%r14),%rax
  a3d496:	test   %rax,%rax
  a3d499:	je     a3d4aa <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xe1a>
  a3d49b:	lock decq (%rax)
  a3d49f:	jne    a3d4aa <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xe1a>
  a3d4a1:	mov    %r15,%rdi
  a3d4a4:	call   *0xaefb6e(%rip)        # 152d018 <_DYNAMIC+0xcd8>
  a3d4aa:	mov    %r13,(%r15)
  a3d4ad:	cmpw   $0x2,(%r12)
  a3d4b3:	jne    a3d4d7 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xe47>
  a3d4b5:	lea    0x250(%rsp),%rdi
  a3d4bd:	mov    %r14,%rsi
  a3d4c0:	call   a3a1b0 <<gpui::native::NativeHost<empty::Empty>>::create_surface>
  a3d4c5:	mov    0x250(%rsp),%rbp
  a3d4cd:	cmp    $0xfffffffffffffffe,%rbp
  a3d4d1:	jne    a3de48 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x17b8>
  a3d4d7:	mov    0x1d8(%r14),%rdi
  a3d4de:	test   %rdi,%rdi
  a3d4e1:	je     a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3d4e7:	add    $0x10,%rdi
  a3d4eb:	mov    $0x1,%esi
  a3d4f0:	call   a3bd90 <<winit::window::Window>::set_visible>
  a3d4f5:	mov    0x1d8(%r14),%rdi
  a3d4fc:	jmp    a3dbd5 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1545>
  a3d501:	mov    0x260(%rsp),%r12
  a3d509:	mov    0x268(%rsp),%r15
  a3d511:	movups 0x270(%rsp),%xmm0
  a3d519:	movaps %xmm0,0x10(%rsp)
  a3d51e:	mov    0x280(%rsp),%rax
  a3d526:	mov    %rax,0x20(%rsp)
  a3d52b:	jmp    a3d7c2 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1132>
  a3d530:	inc    %r13
  a3d533:	mov    %r13,0x258(%rsp)
  a3d53b:	lea    0x250(%rsp),%rdi
  a3d543:	call   a35850 <core::ptr::drop_glue::<core::iter::adapters::flatten::Flatten<core::array::iter::IntoIter<core::option::Option<core::result::Result<gpui::runtime::Commit, gpui::runtime::Error>>, 16>>>>
  a3d548:	mov    (%r14),%rax
  a3d54b:	test   $0x1,%al
  a3d54d:	je     a3dbb5 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1525>
  a3d553:	mov    0x8(%r14),%rax
  a3d557:	test   %rax,%rax
  a3d55a:	je     a3dfac <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x191c>
  a3d560:	lea    0x8(%r14),%rsi
  a3d564:	mov    0x660(%rax),%r15
  a3d56b:	lea    0x250(%rsp),%rdi
  a3d573:	mov    $0x40,%edx
  a3d578:	call   9b79d0 <<gpui::runtime::Win<empty::Empty>>::deliver_ready>
  a3d57d:	mov    0x250(%rsp),%rax
  a3d585:	cmp    $0xffffffffffffffff,%rax
  a3d589:	je     a3d5f6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xf66>
  a3d58b:	cmp    $0x2,%eax
  a3d58e:	je     a3d5ad <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xf1d>
  a3d590:	cmp    %r15,0x260(%rsp)
  a3d598:	jbe    a3d5ad <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xf1d>
  a3d59a:	mov    0x298(%rsp),%eax
  a3d5a1:	and    $0xfffffffe,%eax
  a3d5a4:	cmp    $0xe,%eax
  a3d5a7:	jne    a3d6b0 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1020>
  a3d5ad:	mov    0x2c8(%rsp),%rax
  a3d5b5:	mov    %rax,0x1e0(%rsp)
  a3d5bd:	movupd 0x298(%rsp),%xmm0
  a3d5c6:	movupd 0x2a8(%rsp),%xmm1
  a3d5cf:	movups 0x2b8(%rsp),%xmm2
  a3d5d7:	movaps %xmm2,0x1d0(%rsp)
  a3d5df:	movapd %xmm1,0x1c0(%rsp)
  a3d5e8:	movapd %xmm0,0x1b0(%rsp)
  a3d5f1:	jmp    a3db8f <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x14ff>
  a3d5f6:	movupd 0x258(%rsp),%xmm0
  a3d5ff:	movupd 0x268(%rsp),%xmm1
  a3d608:	movups 0x278(%rsp),%xmm2
  a3d610:	movups %xmm2,0x1d8(%rsp)
  a3d618:	movupd %xmm1,0x1c8(%rsp)
  a3d621:	movupd %xmm0,0x1b8(%rsp)
  a3d62a:	movq   $0xfffffffffffffffe,0x1b0(%rsp)
  a3d636:	jmp    a3db8f <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x14ff>
  a3d63b:	inc    %r13
  a3d63e:	mov    %r13,0x258(%rsp)
  a3d646:	lea    0xf8(%r14),%r15
  a3d64d:	cmpl   $0xfffffffe,0xf8(%r14)
  a3d655:	je     a3d65f <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xfcf>
  a3d657:	mov    %r15,%rdi
  a3d65a:	call   a36f00 <core::ptr::drop_glue::<gpui::native::NativeError>>
  a3d65f:	mov    0x6e0(%rsp),%rax
  a3d667:	mov    %rax,0x30(%r15)
  a3d66b:	movupd 0x6b0(%rsp),%xmm0
  a3d674:	movupd 0x6c0(%rsp),%xmm1
  a3d67d:	movups 0x6d0(%rsp),%xmm2
  a3d685:	movups %xmm2,0x20(%r15)
  a3d68a:	movupd %xmm1,0x10(%r15)
  a3d690:	movupd %xmm0,(%r15)
  a3d695:	mov    %rbx,%rdi
  a3d698:	call   *0xaf001a(%rip)        # 152d6b8 <_DYNAMIC+0x1378>
  a3d69e:	lea    0x250(%rsp),%rdi
  a3d6a6:	call   a35850 <core::ptr::drop_glue::<core::iter::adapters::flatten::Flatten<core::array::iter::IntoIter<core::option::Option<core::result::Result<gpui::runtime::Commit, gpui::runtime::Error>>, 16>>>>
  a3d6ab:	jmp    a3dc86 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x15f6>
  a3d6b0:	lea    0x298(%rsp),%rax
  a3d6b8:	mov    0x30(%rax),%rcx
  a3d6bc:	mov    %rcx,0xa0(%rsp)
  a3d6c4:	movups (%rax),%xmm0
  a3d6c7:	movups 0x10(%rax),%xmm1
  a3d6cb:	movups 0x20(%rax),%xmm2
  a3d6cf:	movaps %xmm2,0x90(%rsp)
  a3d6d7:	movaps %xmm1,0x80(%rsp)
  a3d6df:	movaps %xmm0,0x70(%rsp)
  a3d6e4:	mov    0x290(%rsp),%rax
  a3d6ec:	mov    %rax,0x840(%rsp)
  a3d6f4:	movups 0x250(%rsp),%xmm0
  a3d6fc:	movups 0x260(%rsp),%xmm1
  a3d704:	movups 0x270(%rsp),%xmm2
  a3d70c:	movups 0x280(%rsp),%xmm3
  a3d714:	movaps %xmm3,0x830(%rsp)
  a3d71c:	movaps %xmm2,0x820(%rsp)
  a3d724:	movaps %xmm1,0x810(%rsp)
  a3d72c:	movaps %xmm0,0x800(%rsp)
  a3d734:	mov    0x1e0(%r14),%rdi
  a3d73b:	test   %rdi,%rdi
  a3d73e:	je     a3dabe <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x142e>
  a3d744:	mov    0x1e8(%r14),%rax
  a3d74b:	lea    0x70(%rsp),%rsi
  a3d750:	call   *0x20(%rax)
  a3d753:	jmp    a3db45 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x14b5>
  a3d758:	call   *0xaeee22(%rip)        # 152c580 <_DYNAMIC+0x240>
  a3d75e:	mov    $0x35,%r15d
  a3d764:	mov    $0x35,%edi
  a3d769:	mov    $0x1,%esi
  a3d76e:	call   *0xaeee14(%rip)        # 152c588 <_DYNAMIC+0x248>
  a3d774:	test   %rax,%rax
  a3d777:	je     a3e065 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x19d5>
  a3d77d:	mov    %rax,%r12
  a3d780:	movups -0x8a49d3(%rip),%xmm0        # 198db4 <anon.7cc7c74d1b8f8dfb5e74abfe8b727cdb.77.llvm.18220644203745900989+0x5c0>
  a3d787:	movups %xmm0,0x20(%rax)
  a3d78b:	movups -0x8a49ee(%rip),%xmm0        # 198da4 <anon.7cc7c74d1b8f8dfb5e74abfe8b727cdb.77.llvm.18220644203745900989+0x5b0>
  a3d792:	movups %xmm0,0x10(%rax)
  a3d796:	movups -0x8a4a09(%rip),%xmm0        # 198d94 <anon.7cc7c74d1b8f8dfb5e74abfe8b727cdb.77.llvm.18220644203745900989+0x5a0>
  a3d79d:	movups %xmm0,(%rax)
  a3d7a0:	movabs $0x656b617720726576,%rax
  a3d7aa:	mov    %rax,0x2d(%r12)
  a3d7af:	mov    $0x2d,%ebp
  a3d7b4:	mov    %r13,%rdi
  a3d7b7:	call   a35160 <core::ptr::drop_glue::<gpui::runtime::Win<empty::Empty>>>
  a3d7bc:	mov    $0x35,%r13d
  a3d7c2:	mov    0x30(%rsp),%rax
  a3d7c7:	lock decq (%rax)
  a3d7cb:	jne    a3d26a <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xbda>
  a3d7d1:	lea    0x30(%rsp),%rdi
  a3d7d6:	call   *0xaef83c(%rip)        # 152d018 <_DYNAMIC+0xcd8>
  a3d7dc:	jmp    a3d26a <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xbda>
  a3d7e1:	mov    0x1d8(%r14),%rdi
  a3d7e8:	test   %rdi,%rdi
  a3d7eb:	je     a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3d7f1:	add    $0x10,%rdi
  a3d7f5:	call   a3bc10 <<winit::window::Window>::inner_size>
  a3d7fa:	shl    $0x20,%rdx
  a3d7fe:	mov    %eax,%eax
  a3d800:	or     %rax,%rdx
  a3d803:	lea    0x250(%rsp),%rdi
  a3d80b:	mov    %r14,%rsi
  a3d80e:	call   a3b930 <<gpui::native::NativeHost<empty::Empty>>::resize>
  a3d813:	jmp    a3de36 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x17a6>
  a3d818:	cmpb   $0x0,0x82(%r15)
  a3d820:	jne    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3d826:	cmpb   $0x0,0x78(%r15)
  a3d82b:	jne    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3d831:	movzbl 0x60(%r15),%esi
  a3d836:	cmp    $0xff,%rsi
  a3d83d:	je     a3de05 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1775>
  a3d843:	lea    -0x17(%rsi),%rdx
  a3d847:	xor    %ecx,%ecx
  a3d849:	cmp    $0x18,%sil
  a3d84d:	cmovae %rdx,%rcx
  a3d851:	test   %rcx,%rcx
  a3d854:	je     a3de81 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x17f1>
  a3d85a:	cmp    $0x1,%ecx
  a3d85d:	jne    a3de91 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1801>
  a3d863:	mov    0x68(%r15),%rcx
  a3d867:	mov    0x70(%r15),%rsi
  a3d86b:	jmp    a3de9d <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x180d>
  a3d870:	lea    0x250(%rsp),%rdi
  a3d878:	mov    %r14,%rsi
  a3d87b:	call   a3adf0 <<gpui::native::NativeHost<empty::Empty>>::redraw>
  a3d880:	jmp    a3de36 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x17a6>
  a3d885:	mov    0x4(%r15),%eax
  a3d889:	mov    %eax,0x200(%r14)
  a3d890:	jmp    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3d895:	movb   $0x1,0x205(%r14)
  a3d89d:	movzbl 0x2(%r15),%eax
  a3d8a2:	mov    %al,0x204(%r14)
  a3d8a9:	test   %al,%al
  a3d8ab:	jne    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3d8b1:	mov    0x1d8(%r14),%rdi
  a3d8b8:	test   %rdi,%rdi
  a3d8bb:	jne    a3dbd5 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1545>
  a3d8c1:	jmp    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3d8c6:	cmpb   $0x0,0x2(%r15)
  a3d8cb:	jne    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3d8d1:	mov    $0xffffffff,%eax
  a3d8d6:	mov    %rax,0x1b0(%r14)
  a3d8dd:	movq   $0x0,0x1b8(%r14)
  a3d8e8:	cmpl   $0x1,(%r14)
  a3d8ec:	jne    a3d927 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1297>
  a3d8ee:	lea    0x8(%r14),%rsi
  a3d8f2:	lea    0x800(%rsp),%r15
  a3d8fa:	mov    %r15,%rdi
  a3d8fd:	call   9b9490 <<gpui::runtime::Win<empty::Empty>>::clear_focus>
  a3d902:	lea    0x250(%rsp),%rdi
  a3d90a:	mov    %r14,%rsi
  a3d90d:	mov    %r15,%rdx
  a3d910:	call   a39ce0 <<gpui::native::NativeHost<empty::Empty>>::input_result>
  a3d915:	mov    0x250(%rsp),%rbp
  a3d91d:	cmp    $0xfffffffffffffffe,%rbp
  a3d921:	jne    a3de48 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x17b8>
  a3d927:	movl   $0x0,0x200(%r14)
  a3d932:	jmp    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3d937:	mov    %r14,%rdi
  a3d93a:	call   a39e60 <<gpui::native::NativeHost<empty::Empty>>::retire_window>
  a3d93f:	jmp    a3c9e8 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x358>
  a3d944:	mov    $0xffffffff,%eax
  a3d949:	mov    %rax,0x1b0(%r14)
  a3d950:	movq   $0x0,0x1b8(%r14)
  a3d95b:	jmp    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3d960:	cmpl   $0x1,(%r14)
  a3d964:	jne    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3d96a:	movupd 0x8(%r15),%xmm0
  a3d970:	cvtpd2ps %xmm0,%xmm0
  a3d974:	lea    0x8(%r14),%rsi
  a3d978:	lea    0x1b0(%r14),%rdx
  a3d97f:	movl   $0x0,0x800(%rsp)
  a3d98a:	movlpd %xmm0,0x804(%rsp)
  a3d993:	lea    0x720(%rsp),%rdi
  a3d99b:	lea    0x800(%rsp),%rcx
  a3d9a3:	call   9b94e0 <<gpui::runtime::Win<empty::Empty>>::pointer_event>
  a3d9a8:	mov    0x720(%rsp),%rax
  a3d9b0:	cmp    $0xfffffffffffffffe,%rax
  a3d9b4:	jne    a3ddb3 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1723>
  a3d9ba:	cmpq   $0x0,0x748(%rsp)
  a3d9c3:	jne    a3ddca <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x173a>
  a3d9c9:	jmp    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3d9ce:	cmpl   $0x1,(%r14)
  a3d9d2:	jne    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3d9d8:	lea    0x8(%r14),%rsi
  a3d9dc:	lea    0x1b0(%r14),%rdx
  a3d9e3:	movl   $0x1,0x800(%rsp)
  a3d9ee:	lea    0x758(%rsp),%rdi
  a3d9f6:	lea    0x800(%rsp),%rcx
  a3d9fe:	call   9b94e0 <<gpui::runtime::Win<empty::Empty>>::pointer_event>
  a3da03:	mov    0x758(%rsp),%rax
  a3da0b:	cmp    $0xfffffffffffffffe,%rax
  a3da0f:	jne    a3dddc <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x174c>
  a3da15:	cmpq   $0x0,0x780(%rsp)
  a3da1e:	jne    a3ddf3 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1763>
  a3da24:	jmp    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3da29:	cmpw   $0x0,0x2(%r15)
  a3da2f:	jne    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3da35:	cmpl   $0x1,(%r14)
  a3da39:	jne    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3da3f:	cmpb   $0x1,0x8(%r15)
  a3da44:	mov    $0x3,%eax
  a3da49:	sbb    $0x0,%eax
  a3da4c:	lea    0x8(%r14),%rsi
  a3da50:	lea    0x1b0(%r14),%rdx
  a3da57:	mov    %eax,0x800(%rsp)
  a3da5e:	lea    0x7c8(%rsp),%rdi
  a3da66:	lea    0x800(%rsp),%rcx
  a3da6e:	call   9b94e0 <<gpui::runtime::Win<empty::Empty>>::pointer_event>
  a3da73:	mov    0x7c8(%rsp),%rax
  a3da7b:	cmp    $0xfffffffffffffffe,%rax
  a3da7f:	je     a3de1e <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x178e>
  a3da85:	cmp    $0x19,%eax
  a3da88:	jne    a3de1e <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x178e>
  a3da8e:	lea    0x7c8(%rsp),%rdi
  a3da96:	call   a36fa0 <core::ptr::drop_glue::<gpui::runtime::Error>>
  a3da9b:	jmp    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3daa0:	mov    0x1d8(%r14),%rdi
  a3daa7:	test   %rdi,%rdi
  a3daaa:	je     a3dcdc <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x164c>
  a3dab0:	add    $0x10,%rdi
  a3dab4:	call   a38880 <<winit::window::Window>::scale_factor>
  a3dab9:	jmp    a3dce4 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1654>
  a3dabe:	lea    0x838(%rsp),%rax
  a3dac6:	lea    0x810(%rsp),%rcx
  a3dace:	lea    0x818(%rsp),%rdx
  a3dad6:	mov    %rax,0x100(%rsp)
  a3dade:	mov    0xaef0bb(%rip),%rax        # 152cba0 <_DYNAMIC+0x860>
  a3dae5:	mov    %rax,0x108(%rsp)
  a3daed:	mov    %rcx,0x110(%rsp)
  a3daf5:	mov    0xaeedbc(%rip),%rax        # 152c8b8 <_DYNAMIC+0x578>
  a3dafc:	mov    %rax,0x118(%rsp)
  a3db04:	mov    %rdx,0x120(%rsp)
  a3db0c:	mov    %rax,0x128(%rsp)
  a3db14:	lea    0x70(%rsp),%rax
  a3db19:	mov    %rax,0x130(%rsp)
  a3db21:	mov    0xaefb00(%rip),%rax        # 152d628 <_DYNAMIC+0x12e8>
  a3db28:	mov    %rax,0x138(%rsp)
  a3db30:	lea    -0x8d2eac(%rip),%rdi        # 16ac8b <anon.2277df3ceaea8d4be421179083a68ea6.39.llvm.213539347725472506+0x12e>
  a3db37:	lea    0x100(%rsp),%rsi
  a3db3f:	call   *0xaefa2b(%rip)        # 152d570 <_DYNAMIC+0x1230>
  a3db45:	movapd 0x800(%rsp),%xmm0
  a3db4e:	movapd 0x810(%rsp),%xmm1
  a3db57:	movaps 0x820(%rsp),%xmm2
  a3db5f:	movups %xmm2,0x1d8(%rsp)
  a3db67:	movupd %xmm1,0x1c8(%rsp)
  a3db70:	movupd %xmm0,0x1b8(%rsp)
  a3db79:	movq   $0xfffffffffffffffe,0x1b0(%rsp)
  a3db85:	lea    0x70(%rsp),%rdi
  a3db8a:	call   a36fa0 <core::ptr::drop_glue::<gpui::runtime::Error>>
  a3db8f:	lea    0x6e8(%rsp),%rdi
  a3db97:	lea    0x1b0(%rsp),%rdx
  a3db9f:	mov    %r14,%rsi
  a3dba2:	call   a39ce0 <<gpui::native::NativeHost<empty::Empty>>::input_result>
  a3dba7:	cmpl   $0xfffffffe,0x6e8(%rsp)
  a3dbaf:	jne    a3dc98 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1608>
  a3dbb5:	cmpl   $0xffffffff,0xe0(%r14)
  a3dbbd:	je     a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3dbbf:	mov    0x1d8(%r14),%rdi
  a3dbc6:	test   %rdi,%rdi
  a3dbc9:	sete   %al
  a3dbcc:	or     0x204(%r14),%al
  a3dbd3:	jne    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3dbd5:	add    $0x10,%rdi
  a3dbd9:	call   a38a10 <<winit::window::Window>::request_redraw>
  a3dbde:	cmpl   $0xfffffffe,0xf8(%r14)
  a3dbe6:	jne    a3dc86 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x15f6>
  a3dbec:	cmpl   $0xffffffff,0x10(%r14)
  a3dbf1:	je     a3dc86 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x15f6>
  a3dbf7:	cmpb   $0x0,(%r14)
  a3dbfb:	je     a3dc86 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x15f6>
  a3dc01:	lea    0x10(%r14),%r15
  a3dc05:	lea    0x8(%r14),%rdx
  a3dc09:	lea    0x658(%rsp),%rdi
  a3dc11:	mov    %r15,%rsi
  a3dc14:	call   9e46e0 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>>
  a3dc19:	cmpl   $0xfffffffe,0x658(%rsp)
  a3dc21:	je     a3dc86 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x15f6>
  a3dc23:	mov    %r15,%rdi
  a3dc26:	call   a345d0 <core::ptr::drop_glue::<core::option::Option<gpui::native::accessibility::Bridge>>>
  a3dc2b:	add    $0xf8,%r14
  a3dc32:	movq   $0xffffffffffffffff,(%r15)
  a3dc39:	cmpl   $0xfffffffe,(%r14)
  a3dc3d:	je     a3dc47 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x15b7>
  a3dc3f:	mov    %r14,%rdi
  a3dc42:	call   a36f00 <core::ptr::drop_glue::<gpui::native::NativeError>>
  a3dc47:	mov    0x688(%rsp),%rax
  a3dc4f:	mov    %rax,0x30(%r14)
  a3dc53:	movupd 0x658(%rsp),%xmm0
  a3dc5c:	movupd 0x668(%rsp),%xmm1
  a3dc65:	movups 0x678(%rsp),%xmm2
  a3dc6d:	movups %xmm2,0x20(%r14)
  a3dc72:	movupd %xmm1,0x10(%r14)
  a3dc78:	movupd %xmm0,(%r14)
  a3dc7d:	mov    %rbx,%rdi
  a3dc80:	call   *0xaefa32(%rip)        # 152d6b8 <_DYNAMIC+0x1378>
  a3dc86:	add    $0xb88,%rsp
  a3dc8d:	pop    %rbx
  a3dc8e:	pop    %r12
  a3dc90:	pop    %r13
  a3dc92:	pop    %r14
  a3dc94:	pop    %r15
  a3dc96:	pop    %rbp
  a3dc97:	ret
  a3dc98:	lea    0xf8(%r14),%r15
  a3dc9f:	cmpl   $0xfffffffe,0xf8(%r14)
  a3dca7:	je     a3dcb1 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1621>
  a3dca9:	mov    %r15,%rdi
  a3dcac:	call   a36f00 <core::ptr::drop_glue::<gpui::native::NativeError>>
  a3dcb1:	mov    0x718(%rsp),%rax
  a3dcb9:	mov    %rax,0x30(%r15)
  a3dcbd:	movupd 0x6e8(%rsp),%xmm0
  a3dcc6:	movupd 0x6f8(%rsp),%xmm1
  a3dccf:	movups 0x708(%rsp),%xmm2
  a3dcd7:	jmp    a3c796 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x106>
  a3dcdc:	movsd  -0x8af2ec(%rip),%xmm0        # 18e9f8 <anon.822e710a3ac147487bb68930a699e853.84.llvm.7311037932848680773+0x20>
  a3dce4:	cmpb   $0x0,0x8(%r15)
  a3dce9:	je     a3dd03 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1673>
  a3dceb:	movupd 0x10(%r15),%xmm1
  a3dcf1:	xorpd  -0x8b0899(%rip),%xmm1        # 18d460 <anon.822e710a3ac147487bb68930a699e853.89.llvm.7311037932848680773+0xd0>
  a3dcf9:	unpcklpd %xmm0,%xmm0
  a3dcfd:	divpd  %xmm0,%xmm1
  a3dd01:	jmp    a3dd10 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1680>
  a3dd03:	cvtps2pd 0xc(%r15),%xmm1
  a3dd08:	mulpd  -0x8b2180(%rip),%xmm1        # 18bb90 <anon.5ee778dbc9410921a725c4c57b32111b.58.llvm.8966071514708437312+0x120>
  a3dd10:	movq   %xmm1,%rax
  a3dd15:	movabs $0x7fffffffffffffff,%rcx
  a3dd1f:	and    %rcx,%rax
  a3dd22:	movabs $0x7fefffffffffffff,%rdx
  a3dd2c:	cmp    %rdx,%rax
  a3dd2f:	setg   %al
  a3dd32:	movdqa %xmm1,%xmm0
  a3dd36:	punpckhqdq %xmm1,%xmm0
  a3dd3a:	movq   %xmm0,%rsi
  a3dd3f:	and    %rcx,%rsi
  a3dd42:	cmp    %rdx,%rsi
  a3dd45:	setg   %cl
  a3dd48:	or     %al,%cl
  a3dd4a:	jne    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3dd50:	cmpl   $0x1,(%r14)
  a3dd54:	jne    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3dd5a:	lea    0x8(%r14),%rsi
  a3dd5e:	lea    0x1b0(%r14),%rdx
  a3dd65:	movl   $0x4,0x800(%rsp)
  a3dd70:	movupd %xmm1,0x808(%rsp)
  a3dd79:	lea    0x790(%rsp),%rdi
  a3dd81:	lea    0x800(%rsp),%rcx
  a3dd89:	call   9b94e0 <<gpui::runtime::Win<empty::Empty>>::pointer_event>
  a3dd8e:	mov    0x790(%rsp),%rax
  a3dd96:	cmp    $0xfffffffffffffffe,%rax
  a3dd9a:	je     a3de0c <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x177c>
  a3dd9c:	cmp    $0x19,%eax
  a3dd9f:	jne    a3de0c <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x177c>
  a3dda1:	lea    0x790(%rsp),%rdi
  a3dda9:	call   a36fa0 <core::ptr::drop_glue::<gpui::runtime::Error>>
  a3ddae:	jmp    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3ddb3:	cmp    $0x19,%eax
  a3ddb6:	jne    a3ddca <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x173a>
  a3ddb8:	lea    0x720(%rsp),%rdi
  a3ddc0:	call   a36fa0 <core::ptr::drop_glue::<gpui::runtime::Error>>
  a3ddc5:	jmp    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3ddca:	lea    0x250(%rsp),%rdi
  a3ddd2:	lea    0x720(%rsp),%rdx
  a3ddda:	jmp    a3de2e <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x179e>
  a3dddc:	cmp    $0x19,%eax
  a3dddf:	jne    a3ddf3 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1763>
  a3dde1:	lea    0x758(%rsp),%rdi
  a3dde9:	call   a36fa0 <core::ptr::drop_glue::<gpui::runtime::Error>>
  a3ddee:	jmp    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3ddf3:	lea    0x250(%rsp),%rdi
  a3ddfb:	lea    0x758(%rsp),%rdx
  a3de03:	jmp    a3de2e <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x179e>
  a3de05:	xor    %ecx,%ecx
  a3de07:	jmp    a3de9d <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x180d>
  a3de0c:	lea    0x250(%rsp),%rdi
  a3de14:	lea    0x790(%rsp),%rdx
  a3de1c:	jmp    a3de2e <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x179e>
  a3de1e:	lea    0x250(%rsp),%rdi
  a3de26:	lea    0x7c8(%rsp),%rdx
  a3de2e:	mov    %r14,%rsi
  a3de31:	call   a39ce0 <<gpui::native::NativeHost<empty::Empty>>::input_result>
  a3de36:	mov    0x250(%rsp),%rbp
  a3de3e:	cmp    $0xfffffffffffffffe,%rbp
  a3de42:	je     a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3de48:	mov    0x258(%rsp),%r13
  a3de50:	mov    0x260(%rsp),%r12
  a3de58:	mov    0x268(%rsp),%r15
  a3de60:	movupd 0x270(%rsp),%xmm0
  a3de69:	movapd %xmm0,0x10(%rsp)
  a3de6f:	mov    0x280(%rsp),%rax
  a3de77:	mov    %rax,0x20(%rsp)
  a3de7c:	jmp    a3c99b <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x30b>
  a3de81:	cmp    $0x18,%sil
  a3de85:	jae    a3e051 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x19c1>
  a3de8b:	lea    0x61(%r15),%rcx
  a3de8f:	jmp    a3de9d <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x180d>
  a3de91:	mov    0x68(%r15),%rcx
  a3de95:	mov    0x70(%r15),%rsi
  a3de99:	add    $0x10,%rcx
  a3de9d:	mov    0x200(%r14),%edx
  a3dea4:	test   $0x820,%edx
  a3deaa:	jne    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3deb0:	cmpl   $0x1,(%r14)
  a3deb4:	jne    a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3deba:	test   %ax,%ax
  a3debd:	je     a3df5a <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x18ca>
  a3dec3:	test   %rcx,%rcx
  a3dec6:	je     a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3decc:	mov    %rcx,0x108(%rsp)
  a3ded4:	mov    %rsi,0x110(%rsp)
  a3dedc:	xor    %eax,%eax
  a3dede:	lea    0x8(%r14),%rsi
  a3dee2:	mov    %al,0x100(%rsp)
  a3dee9:	lea    0x250(%rsp),%r15
  a3def1:	lea    0x100(%rsp),%rdx
  a3def9:	mov    %r15,%rdi
  a3defc:	call   9ba170 <<gpui::runtime::Win<empty::Empty>>::key>
  a3df01:	lea    0x800(%rsp),%rdi
  a3df09:	mov    %r14,%rsi
  a3df0c:	mov    %r15,%rdx
  a3df0f:	call   a39ce0 <<gpui::native::NativeHost<empty::Empty>>::input_result>
  a3df14:	mov    0x800(%rsp),%rbp
  a3df1c:	cmp    $0xfffffffffffffffe,%rbp
  a3df20:	je     a3dbde <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154e>
  a3df26:	mov    0x808(%rsp),%r13
  a3df2e:	mov    0x810(%rsp),%r12
  a3df36:	mov    0x818(%rsp),%r15
  a3df3e:	movupd 0x820(%rsp),%xmm0
  a3df47:	movapd %xmm0,0x10(%rsp)
  a3df4d:	mov    0x830(%rsp),%rax
  a3df55:	jmp    a3de77 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x17e7>
  a3df5a:	movzwl 0x2(%r15),%eax
  a3df5f:	add    $0xfffffff2,%eax
  a3df62:	cmp    $0xb,%eax
  a3df65:	ja     a3dec3 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1833>
  a3df6b:	lea    -0x8a522a(%rip),%rdi        # 198d48 <anon.7cc7c74d1b8f8dfb5e74abfe8b727cdb.77.llvm.18220644203745900989+0x554>
  a3df72:	movslq (%rdi,%rax,4),%rax
  a3df76:	add    %rdi,%rax
  a3df79:	jmp    *%rax
  a3df7b:	mov    $0x6,%al
  a3df7d:	jmp    a3dede <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x184e>
  a3df82:	lea    -0x8a4fc5(%rip),%rdi        # 198fc4 <anon.f48bbd6ee32d24e1254dac28089ef4b7.59.llvm.17379179981059708172>
  a3df89:	lea    0xa7e250(%rip),%rcx        # 14bc1e0 <anon.f48bbd6ee32d24e1254dac28089ef4b7.8.llvm.17379179981059708172>
  a3df90:	lea    0xa7e4c9(%rip),%r8        # 14bc460 <anon.f48bbd6ee32d24e1254dac28089ef4b7.61.llvm.17379179981059708172>
  a3df97:	lea    0x3f(%rsp),%rdx
  a3df9c:	mov    $0x37,%esi
  a3dfa1:	call   *0xaee711(%rip)        # 152c6b8 <_DYNAMIC+0x378>
  a3dfa7:	jmp    a3e079 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x19e9>
  a3dfac:	lea    -0x8ae6db(%rip),%rdi        # 18f8d8 <anon.5e2c2cd338f183f0185d3116c074ef00.75.llvm.4553572696083558104>
  a3dfb3:	lea    0xa7ab26(%rip),%rdx        # 14b8ae0 <anon.5e2c2cd338f183f0185d3116c074ef00.76.llvm.4553572696083558104>
  a3dfba:	mov    $0x14,%esi
  a3dfbf:	call   *0xaee6eb(%rip)        # 152c6b0 <_DYNAMIC+0x370>
  a3dfc5:	mov    $0x8,%edi
  a3dfca:	mov    $0x18,%esi
  a3dfcf:	call   *0xaee5d3(%rip)        # 152c5a8 <_DYNAMIC+0x268>
  a3dfd5:	jmp    a3e079 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x19e9>
  a3dfda:	mov    $0x7,%al
  a3dfdc:	jmp    a3dede <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x184e>
  a3dfe1:	mov    $0x1,%al
  a3dfe3:	jmp    a3dede <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x184e>
  a3dfe8:	test   $0x4,%dl
  a3dfeb:	sete   %al
  a3dfee:	xor    $0x5,%al
  a3dff0:	jmp    a3dede <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x184e>
  a3dff5:	shr    $0x2,%dl
  a3dff8:	and    $0x1,%dl
  a3dffb:	mov    %dl,0x101(%rsp)
  a3e002:	mov    $0x2,%al
  a3e004:	jmp    a3dede <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x184e>
  a3e009:	shr    $0x2,%dl
  a3e00c:	and    $0x1,%dl
  a3e00f:	mov    %dl,0x101(%rsp)
  a3e016:	mov    $0x3,%al
  a3e018:	jmp    a3dede <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x184e>
  a3e01d:	mov    0xaef6ac(%rip),%rdi        # 152d6d0 <_DYNAMIC+0x1390>
  a3e024:	call   *0xaef1ae(%rip)        # 152d1d8 <_DYNAMIC+0xe98>
  a3e02a:	test   %al,%al
  a3e02c:	jne    a3cd9d <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x70d>
  a3e032:	jmp    a3cfe3 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x953>
  a3e037:	mov    0xaef68a(%rip),%rdi        # 152d6c8 <_DYNAMIC+0x1388>
  a3e03e:	call   *0xaef194(%rip)        # 152d1d8 <_DYNAMIC+0xe98>
  a3e044:	test   %al,%al
  a3e046:	jne    a3cc83 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x5f3>
  a3e04c:	jmp    a3d0c9 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xa39>
  a3e051:	lea    0xa7e3a0(%rip),%rcx        # 14bc3f8 <anon.f48bbd6ee32d24e1254dac28089ef4b7.8.llvm.17379179981059708172+0x218>
  a3e058:	mov    $0x17,%edx
  a3e05d:	xor    %edi,%edi
  a3e05f:	call   *0xaee55b(%rip)        # 152c5c0 <_DYNAMIC+0x280>
  a3e065:	mov    %ebp,0x8(%rsp)
  a3e069:	mov    $0x1,%edi
  a3e06e:	mov    $0x35,%esi
  a3e073:	call   *0xaee5f7(%rip)        # 152c670 <_DYNAMIC+0x330>
  a3e079:	ud2
  a3e07b:	mov    %r13,(%r15)
  a3e07e:	mov    %rax,%rdi
  a3e081:	call   14b6fa0 <_Unwind_Resume@plt>
  a3e086:	mov    %rax,%rbx
  a3e089:	movq   $0x1,(%r14)
  a3e090:	mov    %r13,0x8(%r14)
  a3e094:	movl   $0x0,0x8(%rsp)
  a3e09c:	jmp    a3e230 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1ba0>
  a3e0a1:	mov    %rax,%rbx
  a3e0a4:	lea    0x40(%rsp),%rdi
  a3e0a9:	call   a36e10 <core::ptr::drop_glue::<tracing::span::Span>>
  a3e0ae:	jmp    a3e1f4 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1b64>
  a3e0b3:	call   *0xaee50f(%rip)        # 152c5c8 <_DYNAMIC+0x288>
  a3e0b9:	mov    %rax,%rbx
  a3e0bc:	lea    0x250(%rsp),%rdi
  a3e0c4:	call   a36e10 <core::ptr::drop_glue::<tracing::span::Span>>
  a3e0c9:	jmp    a3e3e0 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1d50>
  a3e0ce:	call   *0xaee4f4(%rip)        # 152c5c8 <_DYNAMIC+0x288>
  a3e0d4:	mov    %rax,%rbx
  a3e0d7:	lea    0x70(%rsp),%rdi
  a3e0dc:	call   a36fa0 <core::ptr::drop_glue::<gpui::runtime::Error>>
  a3e0e1:	mov    %rbx,%rdi
  a3e0e4:	call   14b6fa0 <_Unwind_Resume@plt>
  a3e0e9:	mov    %rax,%rbx
  a3e0ec:	lea    0x250(%rsp),%rdi
  a3e0f4:	call   a35850 <core::ptr::drop_glue::<core::iter::adapters::flatten::Flatten<core::array::iter::IntoIter<core::option::Option<core::result::Result<gpui::runtime::Commit, gpui::runtime::Error>>, 16>>>>
  a3e0f9:	mov    %rbx,%rdi
  a3e0fc:	call   14b6fa0 <_Unwind_Resume@plt>
  a3e101:	mov    %rax,%rbx
  a3e104:	lea    0x100(%rsp),%rsi
  a3e10c:	mov    $0xb0,%edx
  a3e111:	mov    %rbp,%rdi
  a3e114:	call   *0xaee486(%rip)        # 152c5a0 <memcpy@GLIBC_2.14>
  a3e11a:	movl   $0x0,0x8(%rsp)
  a3e122:	jmp    a3e14c <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1abc>
  a3e124:	mov    %rax,%rbx
  a3e127:	lock decq (%r15)
  a3e12b:	mov    $0x1,%al
  a3e12d:	mov    %eax,0x8(%rsp)
  a3e131:	jne    a3e14c <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1abc>
  a3e133:	lea    0xd0(%rsp),%rdi
  a3e13b:	call   *0xaeefd7(%rip)        # 152d118 <_DYNAMIC+0xdd8>
  a3e141:	jmp    a3e14c <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1abc>
  a3e143:	call   *0xaee47f(%rip)        # 152c5c8 <_DYNAMIC+0x288>
  a3e149:	mov    %rax,%rbx
  a3e14c:	mov    %r13,%rdi
  a3e14f:	call   a35160 <core::ptr::drop_glue::<gpui::runtime::Win<empty::Empty>>>
  a3e154:	jmp    a3e230 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1ba0>
  a3e159:	movq   $0x0,(%r15)
  a3e160:	mov    %rax,%rdi
  a3e163:	call   14b6fa0 <_Unwind_Resume@plt>
  a3e168:	mov    %rax,%rbx
  a3e16b:	mov    0x8(%r15),%rsi
  a3e16f:	test   %rsi,%rsi
  a3e172:	je     a3e181 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1af1>
  a3e174:	mov    0x10(%r15),%rdx
  a3e178:	mov    %r13,%rdi
  a3e17b:	call   *0xaee40f(%rip)        # 152c590 <_DYNAMIC+0x250>
  a3e181:	mov    %rbp,0x1f0(%r14)
  a3e188:	mov    0x8(%rsp),%rax
  a3e18d:	mov    %rax,0x1f8(%r14)
  a3e194:	jmp    a3e281 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1bf1>
  a3e199:	mov    %rax,%rbx
  a3e19c:	mov    0x8(%r15),%rsi
  a3e1a0:	test   %rsi,%rsi
  a3e1a3:	je     a3e1b2 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1b22>
  a3e1a5:	mov    0x10(%r15),%rdx
  a3e1a9:	mov    %r13,%rdi
  a3e1ac:	call   *0xaee3de(%rip)        # 152c590 <_DYNAMIC+0x250>
  a3e1b2:	mov    %rbp,0x1e0(%r14)
  a3e1b9:	mov    0x8(%rsp),%rax
  a3e1be:	mov    %rax,0x1e8(%r14)
  a3e1c5:	mov    $0x1,%bpl
  a3e1c8:	mov    $0x1,%r14b
  a3e1cb:	jmp    a3e360 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1cd0>
  a3e1d0:	mov    %rax,%rbx
  a3e1d3:	movq   $0xffffffffffffffff,(%r15)
  a3e1da:	lea    0x808(%rsp),%rdi
  a3e1e2:	call   a36f00 <core::ptr::drop_glue::<gpui::native::NativeError>>
  a3e1e7:	mov    %rbx,%rdi
  a3e1ea:	call   14b6fa0 <_Unwind_Resume@plt>
  a3e1ef:	jmp    a3e227 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1b97>
  a3e1f1:	mov    %rax,%rbx
  a3e1f4:	lea    0x800(%rsp),%rdi
  a3e1fc:	call   a36080 <core::ptr::drop_glue::<winit::window::WindowAttributes>>
  a3e201:	jmp    a3e35b <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1ccb>
  a3e206:	mov    %rax,%rbx
  a3e209:	movw   $0x2,(%r12)
  a3e210:	mov    %rbx,%rdi
  a3e213:	call   14b6fa0 <_Unwind_Resume@plt>
  a3e218:	movq   $0xffffffffffffffff,(%r15)
  a3e21f:	mov    %rax,%rdi
  a3e222:	call   14b6fa0 <_Unwind_Resume@plt>
  a3e227:	mov    %rax,%rbx
  a3e22a:	mov    $0x1,%al
  a3e22c:	mov    %eax,0x8(%rsp)
  a3e230:	mov    0x30(%rsp),%rax
  a3e235:	lock decq (%rax)
  a3e239:	jne    a3e246 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1bb6>
  a3e23b:	lea    0x30(%rsp),%rdi
  a3e240:	call   *0xaeedd2(%rip)        # 152d018 <_DYNAMIC+0xcd8>
  a3e246:	cmpb   $0x0,0x8(%rsp)
  a3e24b:	jne    a3e35b <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1ccb>
  a3e251:	jmp    a3e3e0 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1d50>
  a3e256:	mov    %rax,%rbx
  a3e259:	lea    0xd0(%rsp),%rdi
  a3e261:	call   a36d90 <core::ptr::drop_glue::<tracing::span::EnteredSpan>>
  a3e266:	jmp    a3e35b <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1ccb>
  a3e26b:	call   *0xaee357(%rip)        # 152c5c8 <_DYNAMIC+0x288>
  a3e271:	mov    %rax,%rbx
  a3e274:	lea    0x100(%rsp),%rdi
  a3e27c:	call   a34380 <core::ptr::drop_glue::<core::option::Option<winit::window::Fullscreen>>>
  a3e281:	mov    $0x1,%r14b
  a3e284:	xor    %ebp,%ebp
  a3e286:	jmp    a3e360 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1cd0>
  a3e28b:	call   *0xaee337(%rip)        # 152c5c8 <_DYNAMIC+0x288>
  a3e291:	mov    %rax,%rbx
  a3e294:	mov    $0x1,%r14b
  a3e297:	mov    $0x1,%bpl
  a3e29a:	jmp    a3e38f <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1cff>
  a3e29f:	mov    %rax,%rbx
  a3e2a2:	jmp    a3e35b <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1ccb>
  a3e2a7:	mov    %rax,%rbx
  a3e2aa:	inc    %r13
  a3e2ad:	mov    %r13,0x258(%rsp)
  a3e2b5:	lea    0x250(%rsp),%rdi
  a3e2bd:	call   a35850 <core::ptr::drop_glue::<core::iter::adapters::flatten::Flatten<core::array::iter::IntoIter<core::option::Option<core::result::Result<gpui::runtime::Commit, gpui::runtime::Error>>, 16>>>>
  a3e2c2:	mov    %rbx,%rdi
  a3e2c5:	call   14b6fa0 <_Unwind_Resume@plt>
  a3e2ca:	mov    %rax,%rbx
  a3e2cd:	movq   $0xffffffffffffffff,(%r15)
  a3e2d4:	lea    0x658(%rsp),%rdi
  a3e2dc:	call   a36f00 <core::ptr::drop_glue::<gpui::native::NativeError>>
  a3e2e1:	mov    %rbx,%rdi
  a3e2e4:	call   14b6fa0 <_Unwind_Resume@plt>
  a3e2e9:	movq   $0x0,(%r15)
  a3e2f0:	mov    %rax,%rdi
  a3e2f3:	call   14b6fa0 <_Unwind_Resume@plt>
  a3e2f8:	movw   $0x2,0x188(%r14)
  a3e302:	mov    %rax,%rdi
  a3e305:	call   14b6fa0 <_Unwind_Resume@plt>
  a3e30a:	movq   $0xffffffffffffffff,(%r15)
  a3e311:	mov    %rax,%rdi
  a3e314:	call   14b6fa0 <_Unwind_Resume@plt>
  a3e319:	mov    %rax,%rbx
  a3e31c:	lea    0x250(%rsp),%rdi
  a3e324:	call   a34f40 <core::ptr::drop_glue::<alloc::sync::ArcInner<winit::window::Window>>>
  a3e329:	jmp    a3e35b <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1ccb>
  a3e32b:	call   *0xaee297(%rip)        # 152c5c8 <_DYNAMIC+0x288>
  a3e331:	mov    %rax,%rbx
  a3e334:	mov    0x40(%rsp),%rsi
  a3e339:	test   %rsi,%rsi
  a3e33c:	je     a3e34e <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1cbe>
  a3e33e:	mov    0x48(%rsp),%rdi
  a3e343:	mov    $0x1,%edx
  a3e348:	call   *0xaee242(%rip)        # 152c590 <_DYNAMIC+0x250>
  a3e34e:	lea    0x250(%rsp),%rdi
  a3e356:	call   a36000 <core::ptr::drop_glue::<winit::error::OsError>>
  a3e35b:	xor    %ebp,%ebp
  a3e35d:	xor    %r14d,%r14d
  a3e360:	mov    0xb8(%rsp),%rsi
  a3e368:	test   %rsi,%rsi
  a3e36b:	jne    a3e374 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1ce4>
  a3e36d:	test   %r14b,%r14b
  a3e370:	jne    a3e38c <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1cfc>
  a3e372:	jmp    a3e3c6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1d36>
  a3e374:	mov    0xc0(%rsp),%rdi
  a3e37c:	mov    $0x1,%edx
  a3e381:	call   *0xaee209(%rip)        # 152c590 <_DYNAMIC+0x250>
  a3e387:	test   %r14b,%r14b
  a3e38a:	je     a3e3c6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1d36>
  a3e38c:	xor    %r14d,%r14d
  a3e38f:	cmpq   $0x0,0x68(%rsp)
  a3e395:	je     a3e3ac <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1d1c>
  a3e397:	mov    0x78(%rsp),%rdi
  a3e39c:	mov    $0x1,%edx
  a3e3a1:	mov    0x68(%rsp),%rsi
  a3e3a6:	call   *0xaee1e4(%rip)        # 152c590 <_DYNAMIC+0x250>
  a3e3ac:	test   %r14b,%r14b
  a3e3af:	je     a3e3c6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1d36>
  a3e3b1:	mov    0x90(%rsp),%rdi
  a3e3b9:	mov    0x98(%rsp),%rsi
  a3e3c1:	call   a33630 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<dyn for<'a> core::ops::function::FnMut<(&'a gpui::runtime::Error,), Output = ()>>>>>
  a3e3c6:	test   %bpl,%bpl
  a3e3c9:	je     a3e3e0 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1d50>
  a3e3cb:	mov    0xa0(%rsp),%rdi
  a3e3d3:	mov    0xa8(%rsp),%rsi
  a3e3db:	call   a33630 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<dyn for<'a> core::ops::function::FnMut<(&'a gpui::runtime::Error,), Output = ()>>>>>
  a3e3e0:	mov    %rbx,%rdi
  a3e3e3:	call   14b6fa0 <_Unwind_Resume@plt>
  a3e3e8:	call   *0xaee1da(%rip)        # 152c5c8 <_DYNAMIC+0x288>
  a3e3ee:	call   *0xaee1d4(%rip)        # 152c5c8 <_DYNAMIC+0x288>
