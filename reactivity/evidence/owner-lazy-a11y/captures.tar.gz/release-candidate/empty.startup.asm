
/tmp/gpui-a11y-owner-channel-captures/release-candidate/empty:     file format elf64-x86-64


Disassembly of section .text:

00000000009e48d0 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>>:
  9e48d0:	push   %rbp
  9e48d1:	push   %r15
  9e48d3:	push   %r14
  9e48d5:	push   %r13
  9e48d7:	push   %r12
  9e48d9:	push   %rbx
  9e48da:	sub    $0x2b8,%rsp
  9e48e1:	mov    %rdx,%r15
  9e48e4:	mov    %rsi,%r14
  9e48e7:	mov    %rdi,%rbx
  9e48ea:	mov    0xa0(%rsi),%rax
  9e48f1:	mov    0x48(%rax),%r12
  9e48f5:	mov    %r12d,%edx
  9e48f8:	and    $0x1,%edx
  9e48fb:	lea    0x90(%rsp),%rdi
  9e4903:	mov    %r15,%rsi
  9e4906:	call   9c01d0 <<gpui::runtime::Win<empty::Empty>>::accessibility_observe>
  9e490b:	cmpl   $0xfffffffe,0x90(%rsp)
  9e4913:	jne    9e4960 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x90>
  9e4915:	test   $0x1,%r12b
  9e4919:	je     9e4991 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xc1>
  9e491b:	mov    (%r15),%rax
  9e491e:	test   %rax,%rax
  9e4921:	je     9e49b4 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xe4>
  9e4927:	mov    $0xe,%ecx
  9e492c:	cmpb   $0x0,0x72e(%rax)
  9e4933:	jne    9e49b9 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xe9>
  9e4939:	mov    0x5e0(%rax),%rcx
  9e4940:	shr    $0x3e,%rcx
  9e4944:	mov    $0x1e,%ecx
  9e4949:	jne    9e49b9 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xe9>
  9e494b:	mov    0x670(%rax),%r13
  9e4952:	test   %r13,%r13
  9e4955:	je     9e49d1 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x101>
  9e4957:	mov    0x5b0(%rax),%rbp
  9e495e:	jmp    9e49d3 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x103>
  9e4960:	mov    0xc0(%rsp),%rax
  9e4968:	mov    %rax,0x30(%rbx)
  9e496c:	movups 0x90(%rsp),%xmm0
  9e4974:	movups 0xa0(%rsp),%xmm1
  9e497c:	movups 0xb0(%rsp),%xmm2
  9e4984:	movups %xmm2,0x20(%rbx)
  9e4988:	movups %xmm1,0x10(%rbx)
  9e498c:	movups %xmm0,(%rbx)
  9e498f:	jmp    9e49bc <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xec>
  9e4991:	lea    0x28(%r14),%rdi
  9e4995:	call   *0xb486f5(%rip)        # 152d090 <_DYNAMIC+0xaf8>
  9e499b:	movb   $0x2,0x80(%r14)
  9e49a3:	movb   $0x1,0xa8(%r14)
  9e49ab:	movq   $0xfffffffffffffffe,(%rbx)
  9e49b2:	jmp    9e49bc <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xec>
  9e49b4:	mov    $0xd,%ecx
  9e49b9:	mov    %rcx,(%rbx)
  9e49bc:	mov    %rbx,%rax
  9e49bf:	add    $0x2b8,%rsp
  9e49c6:	pop    %rbx
  9e49c7:	pop    %r12
  9e49c9:	pop    %r13
  9e49cb:	pop    %r14
  9e49cd:	pop    %r15
  9e49cf:	pop    %rbp
  9e49d0:	ret
  9e49d1:	xor    %ebp,%ebp
  9e49d3:	mov    0x668(%rax),%r12
  9e49da:	movzbl 0x72c(%rax),%ecx
  9e49e1:	mov    0x5e8(%rax),%r8
  9e49e8:	mov    0x5f0(%rax),%r9
  9e49ef:	mov    0x680(%rax),%r10
  9e49f6:	mov    %rbp,0x238(%rsp)
  9e49fe:	mov    %r13,0x240(%rsp)
  9e4a06:	mov    %r12,0x248(%rsp)
  9e4a0e:	mov    %r8,0x250(%rsp)
  9e4a16:	mov    %r9,0x258(%rsp)
  9e4a1e:	mov    %r10,0x260(%rsp)
  9e4a26:	mov    %cl,0x268(%rsp)
  9e4a2d:	test   %cl,%cl
  9e4a2f:	je     9e4d1a <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x44a>
  9e4a35:	movabs $0x3fffffffffffffff,%r11
  9e4a3f:	mov    0xa0(%r14),%rax
  9e4a46:	xor    %ecx,%ecx
  9e4a48:	xchg   %cl,0x52(%rax)
  9e4a4b:	test   %cl,%cl
  9e4a4d:	je     9e4a59 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x189>
  9e4a4f:	movb   $0x1,0xa8(%r14)
  9e4a57:	jmp    9e4a65 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x195>
  9e4a59:	movzbl 0xa8(%r14),%eax
  9e4a61:	cmp    $0x1,%al
  9e4a63:	jne    9e4ac2 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x1f2>
  9e4a65:	movb   $0x1,0xf(%rsp)
  9e4a6a:	movq   $0x0,0x1a8(%rsp)
  9e4a76:	mov    (%r15),%rsi
  9e4a79:	test   %rsi,%rsi
  9e4a7c:	je     9e4a91 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x1c1>
  9e4a7e:	cmpb   $0x0,0x72e(%rsi)
  9e4a85:	je     9e4a9b <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x1cb>
  9e4a87:	mov    $0xe,%eax
  9e4a8c:	jmp    9e4ba9 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x2d9>
  9e4a91:	mov    $0xd,%eax
  9e4a96:	jmp    9e4ba9 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x2d9>
  9e4a9b:	mov    0x5b0(%rsi),%rcx
  9e4aa2:	mov    0x48(%r14),%rax
  9e4aa6:	test   %rax,%rax
  9e4aa9:	je     9e4b85 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x2b5>
  9e4aaf:	cmp    %rcx,%rax
  9e4ab2:	je     9e4b85 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x2b5>
  9e4ab8:	mov    $0x11,%eax
  9e4abd:	jmp    9e4ba9 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x2d9>
  9e4ac2:	cmpb   $0x2,0x80(%r14)
  9e4aca:	jne    9e4bd8 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x308>
  9e4ad0:	movb   $0x1,0xf(%rsp)
  9e4ad5:	lea    0x50(%r14),%rcx
  9e4ad9:	mov    %rcx,0x90(%rsp)
  9e4ae1:	mov    %r15,0x98(%rsp)
  9e4ae9:	lea    0x238(%rsp),%rcx
  9e4af1:	mov    %rcx,0xa0(%rsp)
  9e4af9:	test   %al,%al
  9e4afb:	jne    9e4a6a <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x19a>
  9e4b01:	lea    0x90(%rsp),%rdi
  9e4b09:	mov    %r8,0x150(%rsp)
  9e4b11:	mov    %r9,0x148(%rsp)
  9e4b19:	mov    %r10,0x140(%rsp)
  9e4b21:	call   9e8010 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>::{closure#2}>
  9e4b26:	movabs $0x3fffffffffffffff,%r11
  9e4b30:	mov    0x140(%rsp),%r10
  9e4b38:	mov    0x148(%rsp),%r9
  9e4b40:	mov    0x150(%rsp),%r8
  9e4b48:	mov    %rax,0x1a8(%rsp)
  9e4b50:	mov    %rdx,0x1b0(%rsp)
  9e4b58:	test   %rax,%rax
  9e4b5b:	je     9e4a76 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x1a6>
  9e4b61:	mov    (%r15),%rsi
  9e4b64:	test   %rsi,%rsi
  9e4b67:	je     9e4e13 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x543>
  9e4b6d:	cmpb   $0x0,0x72e(%rsi)
  9e4b74:	je     9e4e1e <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x54e>
  9e4b7a:	mov    $0xe,%r11d
  9e4b80:	jmp    9e4fd1 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x701>
  9e4b85:	mov    $0x12,%eax
  9e4b8a:	cmpb   $0x1,0x72c(%rsi)
  9e4b91:	jne    9e4ba1 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x2d1>
  9e4b93:	mov    $0x1e,%eax
  9e4b98:	cmp    %r11,0x5e0(%rsi)
  9e4b9f:	jbe    9e4c15 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x345>
  9e4ba1:	movzbl 0xa0(%rsp),%ecx
  9e4ba9:	movups 0x29f(%rsp),%xmm0
  9e4bb1:	movups %xmm0,0x28(%rbx)
  9e4bb5:	movaps 0x280(%rsp),%xmm0
  9e4bbd:	movaps 0x290(%rsp),%xmm1
  9e4bc5:	movups %xmm1,0x19(%rbx)
  9e4bc9:	movups %xmm0,0x9(%rbx)
  9e4bcd:	mov    %rax,(%rbx)
  9e4bd0:	mov    %cl,0x8(%rbx)
  9e4bd3:	jmp    9e49bc <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xec>
  9e4bd8:	mov    0x50(%r14),%rsi
  9e4bdc:	mov    0x60(%r14),%rdx
  9e4be0:	mov    0x78(%r14),%rcx
  9e4be4:	mov    0x238(%rsp),%rdi
  9e4bec:	test   %rsi,%rsi
  9e4bef:	je     9e4cc0 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x3f0>
  9e4bf5:	cmp    %rdi,%rsi
  9e4bf8:	jne    9e4ad0 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x200>
  9e4bfe:	mov    0x240(%rsp),%rsi
  9e4c06:	cmp    %rsi,0x58(%r14)
  9e4c0a:	je     9e4cc9 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x3f9>
  9e4c10:	jmp    9e4ad0 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x200>
  9e4c15:	mov    %rcx,0x10(%rsp)
  9e4c1a:	mov    %r10,0x140(%rsp)
  9e4c22:	mov    %r9,0x148(%rsp)
  9e4c2a:	mov    %r8,0x150(%rsp)
  9e4c32:	lea    0x90(%rsp),%rdi
  9e4c3a:	call   9ebba0 <<gpui::runtime::query::Context>::new::<empty::Empty>>
  9e4c3f:	mov    0x90(%rsp),%rdx
  9e4c47:	mov    0x98(%rsp),%rax
  9e4c4f:	movzbl 0xa0(%rsp),%ecx
  9e4c57:	movups 0xa1(%rsp),%xmm0
  9e4c5f:	movaps %xmm0,0x40(%rsp)
  9e4c64:	movups 0xb1(%rsp),%xmm0
  9e4c6c:	movaps %xmm0,0x50(%rsp)
  9e4c71:	movups 0xc0(%rsp),%xmm0
  9e4c79:	movups %xmm0,0x5f(%rsp)
  9e4c7e:	cmp    $0x2,%rdx
  9e4c82:	jne    9e4d26 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x456>
  9e4c88:	movaps 0x40(%rsp),%xmm0
  9e4c8d:	movaps 0x50(%rsp),%xmm1
  9e4c92:	movaps %xmm0,0x280(%rsp)
  9e4c9a:	movaps %xmm1,0x290(%rsp)
  9e4ca2:	movups 0x5f(%rsp),%xmm0
  9e4ca7:	movups %xmm0,0x29f(%rsp)
  9e4caf:	cmp    $0xfffffffffffffffe,%rax
  9e4cb3:	jne    9e4ba9 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x2d9>
  9e4cb9:	mov    $0x1,%al
  9e4cbb:	jmp    9e50e4 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x814>
  9e4cc0:	test   %rdi,%rdi
  9e4cc3:	jne    9e4ad0 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x200>
  9e4cc9:	cmp    0x248(%rsp),%rdx
  9e4cd1:	jne    9e4ad0 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x200>
  9e4cd7:	cmp    0x260(%rsp),%rcx
  9e4cdf:	setne  0xf(%rsp)
  9e4ce4:	jne    9e4ad5 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x205>
  9e4cea:	mov    0x68(%r14),%rcx
  9e4cee:	mov    0x250(%rsp),%rax
  9e4cf6:	test   %rcx,%rcx
  9e4cf9:	je     9e50b5 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x7e5>
  9e4cff:	cmp    %rax,%rcx
  9e4d02:	jne    9e50be <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x7ee>
  9e4d08:	mov    0x258(%rsp),%rax
  9e4d10:	cmp    %rax,0x70(%r14)
  9e4d14:	jne    9e50be <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x7ee>
  9e4d1a:	movq   $0xfffffffffffffffe,(%rbx)
  9e4d21:	jmp    9e49bc <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xec>
  9e4d26:	mov    %rbp,0x128(%rsp)
  9e4d2e:	mov    %r13,0x130(%rsp)
  9e4d36:	movups 0xd0(%rsp),%xmm0
  9e4d3e:	movups 0xe0(%rsp),%xmm1
  9e4d46:	movups 0xf0(%rsp),%xmm2
  9e4d4e:	movups 0x100(%rsp),%xmm3
  9e4d56:	movups %xmm3,0x228(%rsp)
  9e4d5e:	movups %xmm2,0x218(%rsp)
  9e4d66:	movups %xmm1,0x208(%rsp)
  9e4d6e:	movups %xmm0,0x1f8(%rsp)
  9e4d76:	mov    %rax,0x1c0(%rsp)
  9e4d7e:	mov    %cl,0x1c8(%rsp)
  9e4d85:	movaps 0x40(%rsp),%xmm0
  9e4d8a:	movaps 0x50(%rsp),%xmm1
  9e4d8f:	movups %xmm0,0x1c9(%rsp)
  9e4d97:	movups %xmm1,0x1d9(%rsp)
  9e4d9f:	movups 0x5f(%rsp),%xmm0
  9e4da4:	movups %xmm0,0x1e8(%rsp)
  9e4dac:	mov    %rdx,0x1b8(%rsp)
  9e4db4:	mov    0x1f0(%rsp),%rbp
  9e4dbc:	test   %rbp,%rbp
  9e4dbf:	mov    %r12,0x120(%rsp)
  9e4dc7:	je     9e4f01 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x631>
  9e4dcd:	xor    %r12d,%r12d
  9e4dd0:	xor    %r13d,%r13d
  9e4dd3:	lea    0x1b8(%rsp),%rdi
  9e4ddb:	mov    %r12,%rsi
  9e4dde:	call   *0xb4829c(%rip)        # 152d080 <_DYNAMIC+0xae8>
  9e4de4:	cmp    $0x1,%rax
  9e4de8:	sbb    $0xffffffffffffffff,%r13
  9e4dec:	inc    %r12
  9e4def:	cmp    %r12,%rbp
  9e4df2:	jne    9e4dd3 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x503>
  9e4df4:	imul   $0x38,%r13,%rsi
  9e4df8:	movabs $0x249249249249249,%rax
  9e4e02:	cmp    %rax,%r13
  9e4e05:	jbe    9e53ad <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xadd>
  9e4e0b:	xor    %edi,%edi
  9e4e0d:	call   *0xb47ab5(%rip)        # 152c8c8 <_DYNAMIC+0x330>
  9e4e13:	mov    $0xd,%r11d
  9e4e19:	jmp    9e4fd1 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x701>
  9e4e1e:	mov    0x48(%r14),%rcx
  9e4e22:	cmp    0x5b0(%rsi),%rcx
  9e4e29:	jne    9e4fcb <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x6fb>
  9e4e2f:	mov    %rdx,0x88(%rsp)
  9e4e37:	mov    %rax,0x138(%rsp)
  9e4e3f:	mov    %r12,0x120(%rsp)
  9e4e47:	lea    0x90(%rsp),%rdi
  9e4e4f:	mov    %r15,%rsi
  9e4e52:	call   9bc960 <<gpui::runtime::Win<empty::Empty>>::accessibility_sheet>
  9e4e57:	mov    0x90(%rsp),%rax
  9e4e5f:	mov    0x98(%rsp),%r11
  9e4e67:	mov    0xa0(%rsp),%rcx
  9e4e6f:	mov    %rcx,0x10(%rsp)
  9e4e74:	mov    0xa8(%rsp),%rcx
  9e4e7c:	mov    %rcx,0x28(%rsp)
  9e4e81:	mov    0xb0(%rsp),%edi
  9e4e88:	movzbl 0xb4(%rsp),%r10d
  9e4e91:	movzwl 0xb5(%rsp),%ecx
  9e4e99:	mov    %cx,0x40(%rsp)
  9e4e9e:	movzbl 0xb7(%rsp),%ecx
  9e4ea6:	mov    %cl,0x42(%rsp)
  9e4eaa:	mov    0xb8(%rsp),%r12
  9e4eb2:	mov    0xc0(%rsp),%rcx
  9e4eba:	mov    %rcx,0x80(%rsp)
  9e4ec2:	mov    0xc8(%rsp),%rcx
  9e4eca:	mov    %rcx,0x38(%rsp)
  9e4ecf:	cmp    $0x2,%rax
  9e4ed3:	mov    %r13,0x130(%rsp)
  9e4edb:	mov    %rbp,0x128(%rsp)
  9e4ee3:	jne    9e514c <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x87c>
  9e4ee9:	movzwl 0x40(%rsp),%eax
  9e4eee:	mov    %ax,0x18(%rsp)
  9e4ef3:	movzbl 0x42(%rsp),%eax
  9e4ef8:	mov    %al,0x1a(%rsp)
  9e4efc:	jmp    9e554e <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xc7e>
  9e4f01:	mov    $0x8,%eax
  9e4f06:	xor    %r13d,%r13d
  9e4f09:	xor    %ecx,%ecx
  9e4f0b:	lea    0x28(%r14),%r12
  9e4f0f:	mov    %rcx,0x40(%rsp)
  9e4f14:	mov    %rax,0x48(%rsp)
  9e4f19:	movq   $0x0,0x50(%rsp)
  9e4f22:	cmp    0x38(%r14),%r13
  9e4f26:	mov    0x40(%r14),%rax
  9e4f2a:	setne  0x26(%rsp)
  9e4f2f:	mov    %rax,0x18(%rsp)
  9e4f34:	movb   $0x0,0x34(%rsp)
  9e4f39:	mov    %r15,0x90(%rsp)
  9e4f41:	mov    %r12,0x98(%rsp)
  9e4f49:	lea    0x26(%rsp),%rax
  9e4f4e:	mov    %rax,0xa0(%rsp)
  9e4f56:	lea    0x18(%rsp),%rax
  9e4f5b:	mov    %rax,0xa8(%rsp)
  9e4f63:	lea    0x34(%rsp),%rax
  9e4f68:	mov    %rax,0xb0(%rsp)
  9e4f70:	lea    0x40(%rsp),%rax
  9e4f75:	mov    %rax,0xb8(%rsp)
  9e4f7d:	lea    0x1b8(%rsp),%rdi
  9e4f85:	lea    0x90(%rsp),%rsi
  9e4f8d:	call   9ec380 <<gpui::runtime::query::SemanticSheet>::visit::<<gpui::native::accessibility::text::Cohort>::refresh<empty::Empty, ()>::{closure#2}>>
  9e4f92:	cmpb   $0x0,0x34(%rsp)
  9e4f97:	je     9e500e <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x73e>
  9e4f99:	lea    0x40(%rsp),%rdi
  9e4f9e:	call   a03d70 <<alloc::vec::Vec<gpui::native::accessibility::text::Input> as core::ops::drop::Drop>::drop>
  9e4fa3:	mov    0x40(%rsp),%rax
  9e4fa8:	test   %rax,%rax
  9e4fab:	je     9e4fc1 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x6f1>
  9e4fad:	mov    0x48(%rsp),%rdi
  9e4fb2:	imul   $0x38,%rax,%rsi
  9e4fb6:	mov    $0x8,%edx
  9e4fbb:	call   *0xb47827(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  9e4fc1:	mov    $0x1e,%eax
  9e4fc6:	jmp    9e4ba9 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x2d9>
  9e4fcb:	mov    $0x11,%r11d
  9e4fd1:	movzbl 0x1a(%rsp),%eax
  9e4fd6:	mov    %al,0x36(%rsp)
  9e4fda:	movzwl 0x18(%rsp),%ecx
  9e4fdf:	mov    %cx,0x34(%rsp)
  9e4fe4:	mov    %al,0x1f(%rbx)
  9e4fe7:	mov    %cx,0x1d(%rbx)
  9e4feb:	mov    %r11,(%rbx)
  9e4fee:	mov    %r9,0x8(%rbx)
  9e4ff2:	mov    %r8,0x10(%rbx)
  9e4ff6:	mov    %edi,0x18(%rbx)
  9e4ff9:	mov    %r10b,0x1c(%rbx)
  9e4ffd:	mov    %r12,0x20(%rbx)
  9e5001:	mov    %rsi,0x28(%rbx)
  9e5005:	mov    %rdx,0x30(%rbx)
  9e5009:	jmp    9e49bc <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xec>
  9e500e:	mov    0x48(%rsp),%rdi
  9e5013:	mov    0x50(%rsp),%rsi
  9e5018:	lea    0x27(%rsp),%rax
  9e501d:	mov    %rax,0x90(%rsp)
  9e5025:	cmp    $0x2,%rsi
  9e5029:	jae    9e5c7b <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x13ab>
  9e502f:	mov    0x50(%rsp),%rax
  9e5034:	mov    %rax,0xa0(%rsp)
  9e503c:	movups 0x40(%rsp),%xmm0
  9e5041:	movaps %xmm0,0x90(%rsp)
  9e5049:	mov    %r12,%rdi
  9e504c:	call   a03d70 <<alloc::vec::Vec<gpui::native::accessibility::text::Input> as core::ops::drop::Drop>::drop>
  9e5051:	mov    (%r12),%rax
  9e5055:	test   %rax,%rax
  9e5058:	je     9e506d <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x79d>
  9e505a:	mov    0x30(%r14),%rdi
  9e505e:	imul   $0x38,%rax,%rsi
  9e5062:	mov    $0x8,%edx
  9e5067:	call   *0xb4777b(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  9e506d:	mov    0xa0(%rsp),%rax
  9e5075:	mov    %rax,0x10(%r12)
  9e507a:	movaps 0x90(%rsp),%xmm0
  9e5082:	movups %xmm0,(%r12)
  9e5087:	mov    0x18(%rsp),%rax
  9e508c:	mov    %rax,0x40(%r14)
  9e5090:	mov    0x10(%rsp),%rax
  9e5095:	mov    %rax,0x48(%r14)
  9e5099:	mov    0x130(%rsp),%r13
  9e50a1:	mov    0x128(%rsp),%rbp
  9e50a9:	mov    0x120(%rsp),%r12
  9e50b1:	mov    $0x1,%al
  9e50b3:	jmp    9e50e4 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x814>
  9e50b5:	test   %rax,%rax
  9e50b8:	je     9e4d1a <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x44a>
  9e50be:	mov    %r10,0x140(%rsp)
  9e50c6:	mov    %r9,0x148(%rsp)
  9e50ce:	mov    %r8,0x150(%rsp)
  9e50d6:	movq   $0x0,0x1a8(%rsp)
  9e50e2:	xor    %eax,%eax
  9e50e4:	movq   $0x0,0x158(%rsp)
  9e50f0:	movq   $0x4,0x160(%rsp)
  9e50fc:	movq   $0x0,0x168(%rsp)
  9e5108:	movw   $0x100,0x180(%rsp)
  9e5112:	xorps  %xmm0,%xmm0
  9e5115:	movups %xmm0,0x170(%rsp)
  9e511d:	mov    $0x4,%ecx
  9e5122:	mov    %rcx,0x28(%rsp)
  9e5127:	movq   $0x0,0x10(%rsp)
  9e5130:	test   %al,%al
  9e5132:	je     9e5621 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xd51>
  9e5138:	lea    0x28(%r14),%rdi
  9e513c:	call   *0xb47f56(%rip)        # 152d098 <_DYNAMIC+0xb00>
  9e5142:	mov    %rax,0x38(%rsp)
  9e5147:	jmp    9e5631 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xd61>
  9e514c:	movups 0xd0(%rsp),%xmm0
  9e5154:	movups 0xe0(%rsp),%xmm1
  9e515c:	movups 0xf0(%rsp),%xmm2
  9e5164:	movups 0x100(%rsp),%xmm3
  9e516c:	movups %xmm3,0x228(%rsp)
  9e5174:	movups %xmm2,0x218(%rsp)
  9e517c:	movups %xmm1,0x208(%rsp)
  9e5184:	movups %xmm0,0x1f8(%rsp)
  9e518c:	mov    %r11,0x1c0(%rsp)
  9e5194:	mov    0x10(%rsp),%rcx
  9e5199:	mov    %rcx,0x1c8(%rsp)
  9e51a1:	mov    0x28(%rsp),%rcx
  9e51a6:	mov    %rcx,0x1d0(%rsp)
  9e51ae:	mov    %edi,0x1d8(%rsp)
  9e51b5:	mov    %r10b,0x1dc(%rsp)
  9e51bd:	movzwl 0x40(%rsp),%ecx
  9e51c2:	mov    %cx,0x1dd(%rsp)
  9e51ca:	movzbl 0x42(%rsp),%ecx
  9e51cf:	mov    %cl,0x1df(%rsp)
  9e51d6:	mov    %r12,0x1e0(%rsp)
  9e51de:	mov    %rax,0x1b8(%rsp)
  9e51e6:	mov    0x80(%rsp),%rax
  9e51ee:	mov    %rax,0x1e8(%rsp)
  9e51f6:	mov    0x38(%rsp),%rax
  9e51fb:	mov    %rax,0x1f0(%rsp)
  9e5203:	mov    0x40(%r14),%r12
  9e5207:	movq   $0x0,0x40(%rsp)
  9e5210:	movq   $0x4,0x48(%rsp)
  9e5219:	movq   $0x0,0x50(%rsp)
  9e5222:	movw   $0x100,0x68(%rsp)
  9e5229:	mov    %r12,0x58(%rsp)
  9e522e:	mov    %r12,0x60(%rsp)
  9e5233:	cmpq   $0x0,0x88(%rsp)
  9e523c:	je     9e53e2 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xb12>
  9e5242:	mov    0x88(%rsp),%rcx
  9e524a:	shl    $0x2,%rcx
  9e524e:	mov    0x30(%r14),%rax
  9e5252:	mov    %rax,0x10(%rsp)
  9e5257:	mov    0x38(%r14),%rax
  9e525b:	mov    %rax,0x28(%rsp)
  9e5260:	xor    %r13d,%r13d
  9e5263:	mov    %r12,0x78(%rsp)
  9e5268:	mov    %r12,0x118(%rsp)
  9e5270:	mov    0x138(%rsp),%rax
  9e5278:	mov    %rcx,0x88(%rsp)
  9e5280:	jmp    9e52dd <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xa0d>
  9e5282:	xor    %edx,%edx
  9e5284:	mov    0x118(%rsp),%rcx
  9e528c:	add    %rcx,%rax
  9e528f:	lea    (%rdx,%rax,1),%r12
  9e5293:	inc    %r12
  9e5296:	cmp    %rcx,%r12
  9e5299:	jb     9e5c71 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x13a1>
  9e529f:	movq   $0x1e,0x90(%rsp)
  9e52ab:	lea    0x90(%rsp),%rdi
  9e52b3:	call   9e7b10 <core::ptr::drop_glue::<gpui::runtime::Error>>
  9e52b8:	mov    %r12,0x118(%rsp)
  9e52c0:	mov    0x138(%rsp),%rax
  9e52c8:	mov    0x88(%rsp),%rcx
  9e52d0:	add    $0x4,%r13
  9e52d4:	cmp    %r13,%rcx
  9e52d7:	je     9e54ce <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xbfe>
  9e52dd:	mov    (%rax,%r13,1),%r12d
  9e52e1:	cmp    %r12,0x38(%rsp)
  9e52e6:	jbe    9e5412 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xb42>
  9e52ec:	movq   $0x11,0x90(%rsp)
  9e52f8:	lea    0x90(%rsp),%rbp
  9e5300:	mov    %rbp,%rdi
  9e5303:	call   9e7b10 <core::ptr::drop_glue::<gpui::runtime::Error>>
  9e5308:	mov    %rbp,%rdi
  9e530b:	mov    0x10(%rsp),%rsi
  9e5310:	mov    0x28(%rsp),%rdx
  9e5315:	mov    %r15,%rcx
  9e5318:	lea    0x1b8(%rsp),%r8
  9e5320:	mov    %r12,%r9
  9e5323:	call   9e40a0 <<gpui::native::accessibility::text::Cohort>::replacement::<empty::Empty, ()>>
  9e5328:	mov    0x90(%rsp),%rax
  9e5330:	cmp    $0xfffffffffffffffe,%rax
  9e5334:	jne    9e5437 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xb67>
  9e533a:	movzbl 0xac(%rsp),%edx
  9e5342:	cmp    $0x2,%dl
  9e5345:	je     9e52c0 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x9f0>
  9e534b:	shl    $0x6,%r12
  9e534f:	mov    0x80(%rsp),%rax
  9e5357:	lea    (%rax,%r12,1),%rcx
  9e535b:	mov    $0x1,%sil
  9e535e:	cmpb   $0x4,0x3d(%rax,%r12,1)
  9e5364:	jne    9e536f <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xa9f>
  9e5366:	cmpq   $0x0,0x28(%rcx)
  9e536b:	sete   %sil
  9e536f:	mov    0xa8(%rsp),%eax
  9e5376:	cmpq   $0x0,0xa0(%rsp)
  9e537f:	setne  %dil
  9e5383:	or     %sil,%dil
  9e5386:	and    %dil,0x69(%rsp)
  9e538b:	cmp    $0x1,%dl
  9e538e:	jne    9e5282 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x9b2>
  9e5394:	cmpb   $0x4,0x3d(%rcx)
  9e5398:	jne    9e5282 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x9b2>
  9e539e:	xor    %edx,%edx
  9e53a0:	cmpq   $0x0,0x28(%rcx)
  9e53a5:	setne  %dl
  9e53a8:	jmp    9e5284 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x9b4>
  9e53ad:	test   %rsi,%rsi
  9e53b0:	je     9e5408 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xb38>
  9e53b2:	mov    %rsi,%r12
  9e53b5:	call   *0xb4741d(%rip)        # 152c7d8 <_DYNAMIC+0x240>
  9e53bb:	mov    $0x8,%esi
  9e53c0:	mov    %r12,%rdi
  9e53c3:	call   *0xb47417(%rip)        # 152c7e0 <_DYNAMIC+0x248>
  9e53c9:	mov    $0x8,%edi
  9e53ce:	mov    %r12,%rsi
  9e53d1:	test   %rax,%rax
  9e53d4:	je     9e4e0d <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x53d>
  9e53da:	mov    %r13,%rcx
  9e53dd:	jmp    9e4f0b <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x63b>
  9e53e2:	xor    %ebp,%ebp
  9e53e4:	mov    $0x4,%eax
  9e53e9:	mov    %rax,0x28(%rsp)
  9e53ee:	mov    %r12,%rcx
  9e53f1:	movq   $0x0,0x78(%rsp)
  9e53fa:	movq   $0x0,0x10(%rsp)
  9e5403:	jmp    9e550d <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xc3d>
  9e5408:	mov    $0x8,%eax
  9e540d:	jmp    9e4f09 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x639>
  9e5412:	mov    $0x11,%eax
  9e5417:	mov    %rax,0x110(%rsp)
  9e541f:	mov    %rax,0x78(%rsp)
  9e5424:	mov    0x40(%rsp),%rsi
  9e5429:	test   %rsi,%rsi
  9e542c:	jne    9e54b8 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xbe8>
  9e5432:	jmp    9e553e <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xc6e>
  9e5437:	mov    %rax,0x110(%rsp)
  9e543f:	mov    0x98(%rsp),%rax
  9e5447:	mov    %rax,0x10(%rsp)
  9e544c:	mov    0xa0(%rsp),%rax
  9e5454:	mov    %rax,0x28(%rsp)
  9e5459:	mov    0xa8(%rsp),%eax
  9e5460:	mov    %rax,0x78(%rsp)
  9e5465:	movzbl 0xac(%rsp),%ebp
  9e546d:	lea    0xad(%rsp),%rcx
  9e5475:	movzwl (%rcx),%eax
  9e5478:	mov    %ax,0x18(%rsp)
  9e547d:	movzbl 0x2(%rcx),%eax
  9e5481:	mov    %al,0x1a(%rsp)
  9e5485:	mov    0xb0(%rsp),%r12
  9e548d:	mov    0xb8(%rsp),%rax
  9e5495:	mov    %rax,0x80(%rsp)
  9e549d:	mov    0xc0(%rsp),%rax
  9e54a5:	mov    %rax,0x38(%rsp)
  9e54aa:	mov    0x40(%rsp),%rsi
  9e54af:	test   %rsi,%rsi
  9e54b2:	je     9e553e <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xc6e>
  9e54b8:	mov    0x48(%rsp),%rdi
  9e54bd:	shl    $0x2,%rsi
  9e54c1:	mov    $0x4,%edx
  9e54c6:	call   *0xb4731c(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  9e54cc:	jmp    9e553e <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xc6e>
  9e54ce:	mov    0x78(%rsp),%rax
  9e54d3:	cmp    %rax,0x118(%rsp)
  9e54db:	jne    9e58ec <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x101c>
  9e54e1:	mov    0x40(%rsp),%rax
  9e54e6:	mov    %rax,0x10(%rsp)
  9e54eb:	mov    0x48(%rsp),%rax
  9e54f0:	mov    %rax,0x28(%rsp)
  9e54f5:	mov    0x50(%rsp),%eax
  9e54f9:	mov    %rax,0x78(%rsp)
  9e54fe:	movzbl 0x54(%rsp),%ebp
  9e5503:	mov    0x58(%rsp),%r12
  9e5508:	mov    0x60(%rsp),%rcx
  9e550d:	movzbl 0x57(%rsp),%eax
  9e5512:	mov    %al,0x1a(%rsp)
  9e5516:	movzwl 0x55(%rsp),%eax
  9e551b:	mov    %ax,0x18(%rsp)
  9e5520:	movq   $0xfffffffffffffffe,0x110(%rsp)
  9e552c:	mov    0x68(%rsp),%rax
  9e5531:	mov    %rax,0x38(%rsp)
  9e5536:	mov    %rcx,0x80(%rsp)
  9e553e:	mov    0x78(%rsp),%rdi
  9e5543:	mov    %rbp,%r10
  9e5546:	mov    0x110(%rsp),%r11
  9e554e:	cmp    $0xfffffffffffffffe,%r11
  9e5552:	mov    0x38(%rsp),%rdx
  9e5557:	mov    0x80(%rsp),%rsi
  9e555f:	mov    0x28(%rsp),%r8
  9e5564:	mov    0x10(%rsp),%r9
  9e5569:	jne    9e4fd1 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x701>
  9e556f:	movzbl 0x1a(%rsp),%eax
  9e5574:	movzwl 0x18(%rsp),%ecx
  9e5579:	mov    %cx,0x16d(%rsp)
  9e5581:	mov    %al,0x16f(%rsp)
  9e5588:	mov    %r9,0x10(%rsp)
  9e558d:	mov    %r9,0x158(%rsp)
  9e5595:	mov    %r8,0x28(%rsp)
  9e559a:	mov    %r8,0x160(%rsp)
  9e55a2:	mov    %edi,0x168(%rsp)
  9e55a9:	mov    %r10b,0x16c(%rsp)
  9e55b1:	mov    %r12,0x170(%rsp)
  9e55b9:	mov    %rsi,0x178(%rsp)
  9e55c1:	mov    %rdx,0x180(%rsp)
  9e55c9:	cmpq   $0x0,0x1a8(%rsp)
  9e55d2:	je     9e55fc <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xd2c>
  9e55d4:	mov    %rdx,%rax
  9e55d7:	shr    $0x8,%eax
  9e55da:	and    $0x1,%eax
  9e55dd:	mov    %rax,0x38(%rsp)
  9e55e2:	mov    0x130(%rsp),%r13
  9e55ea:	mov    0x128(%rsp),%rbp
  9e55f2:	mov    0x120(%rsp),%r12
  9e55fa:	jmp    9e5631 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xd61>
  9e55fc:	movzbl 0xf(%rsp),%eax
  9e5601:	mov    0x130(%rsp),%r13
  9e5609:	mov    0x128(%rsp),%rbp
  9e5611:	mov    0x120(%rsp),%r12
  9e5619:	test   %al,%al
  9e561b:	jne    9e5138 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x868>
  9e5621:	cmpb   $0x0,0xa8(%r14)
  9e5629:	sete   %al
  9e562c:	mov    %rax,0x38(%rsp)
  9e5631:	mov    (%r15),%rsi
  9e5634:	test   %rsi,%rsi
  9e5637:	je     9e5875 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xfa5>
  9e563d:	mov    $0xe,%eax
  9e5642:	cmpb   $0x0,0x72e(%rsi)
  9e5649:	mov    0x28(%rsp),%rdi
  9e564e:	jne    9e587f <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xfaf>
  9e5654:	mov    $0x12,%eax
  9e5659:	cmpb   $0x1,0x72c(%rsi)
  9e5660:	jne    9e587f <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xfaf>
  9e5666:	mov    $0x1e,%eax
  9e566b:	movabs $0x3fffffffffffffff,%rcx
  9e5675:	cmp    %rcx,0x5e0(%rsi)
  9e567c:	ja     9e587f <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xfaf>
  9e5682:	lea    0x90(%rsp),%rdi
  9e568a:	call   9ebba0 <<gpui::runtime::query::Context>::new::<empty::Empty>>
  9e568f:	mov    0x90(%rsp),%rcx
  9e5697:	cmp    $0x2,%rcx
  9e569b:	mov    0x28(%rsp),%rdi
  9e56a0:	je     9e5887 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xfb7>
  9e56a6:	lea    0xa0(%r14),%rax
  9e56ad:	mov    0xc8(%rsp),%rdx
  9e56b5:	mov    %rdx,0x70(%rsp)
  9e56ba:	movups 0x98(%rsp),%xmm0
  9e56c2:	movups 0xa8(%rsp),%xmm1
  9e56ca:	movups 0xb8(%rsp),%xmm2
  9e56d2:	movaps %xmm2,0x60(%rsp)
  9e56d7:	movaps %xmm1,0x50(%rsp)
  9e56dc:	movaps %xmm0,0x40(%rsp)
  9e56e1:	movups 0xd0(%rsp),%xmm3
  9e56e9:	movups %xmm3,0x1f8(%rsp)
  9e56f1:	movups 0xe0(%rsp),%xmm3
  9e56f9:	movups %xmm3,0x208(%rsp)
  9e5701:	movups 0xf0(%rsp),%xmm3
  9e5709:	movups %xmm3,0x218(%rsp)
  9e5711:	movups 0x100(%rsp),%xmm3
  9e5719:	movups %xmm3,0x228(%rsp)
  9e5721:	mov    %rdx,0x1f0(%rsp)
  9e5729:	movups %xmm2,0x1e0(%rsp)
  9e5731:	movups %xmm1,0x1d0(%rsp)
  9e5739:	movups %xmm0,0x1c0(%rsp)
  9e5741:	mov    %rcx,0x1b8(%rsp)
  9e5749:	movb   $0x0,0x40(%rsp)
  9e574e:	lea    0x180(%rsp),%rcx
  9e5756:	lea    0x170(%rsp),%rdx
  9e575e:	lea    0x10(%r14),%rsi
  9e5762:	lea    0x28(%r14),%rdi
  9e5766:	lea    0x1a8(%rsp),%r8
  9e576e:	mov    %r8,0x90(%rsp)
  9e5776:	lea    0x158(%rsp),%r8
  9e577e:	mov    %r8,0x98(%rsp)
  9e5786:	mov    %rcx,0xa0(%rsp)
  9e578e:	mov    %rdx,0xa8(%rsp)
  9e5796:	lea    0x1b8(%rsp),%rcx
  9e579e:	mov    %rcx,0xb0(%rsp)
  9e57a6:	mov    %rsi,0xb8(%rsp)
  9e57ae:	mov    %rdi,0xc0(%rsp)
  9e57b6:	lea    0xf(%rsp),%rcx
  9e57bb:	mov    %rcx,0xc8(%rsp)
  9e57c3:	lea    0x238(%rsp),%rcx
  9e57cb:	mov    %rcx,0xd0(%rsp)
  9e57d3:	mov    %rax,0xd8(%rsp)
  9e57db:	mov    %r14,0xe0(%rsp)
  9e57e3:	lea    0x40(%rsp),%rax
  9e57e8:	mov    %rax,0xe8(%rsp)
  9e57f0:	lea    0x88(%r14),%rdi
  9e57f7:	lea    0x90(%rsp),%rsi
  9e57ff:	call   a0b9b0 <<accesskit_unix::adapter::Adapter>::update_if_active::<<gpui::native::accessibility::Bridge>::sync<empty::Empty, ()>::{closure#3}>>
  9e5804:	cmpb   $0x0,0x40(%rsp)
  9e5809:	je     9e5853 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xf83>
  9e580b:	mov    %rbp,0x50(%r14)
  9e580f:	mov    %r13,0x58(%r14)
  9e5813:	mov    %r12,0x60(%r14)
  9e5817:	mov    0x150(%rsp),%rax
  9e581f:	mov    %rax,0x68(%r14)
  9e5823:	mov    0x148(%rsp),%rax
  9e582b:	mov    %rax,0x70(%r14)
  9e582f:	mov    0x140(%rsp),%rax
  9e5837:	mov    %rax,0x78(%r14)
  9e583b:	movb   $0x1,0x80(%r14)
  9e5843:	mov    0x38(%rsp),%rax
  9e5848:	xor    $0x1,%al
  9e584a:	add    %al,%al
  9e584c:	mov    %al,0xa8(%r14)
  9e5853:	movq   $0xfffffffffffffffe,(%rbx)
  9e585a:	mov    0x158(%rsp),%rsi
  9e5862:	test   %rsi,%rsi
  9e5865:	je     9e49bc <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xec>
  9e586b:	mov    0x160(%rsp),%rdi
  9e5873:	jmp    9e58d8 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x1008>
  9e5875:	mov    $0xd,%eax
  9e587a:	mov    0x28(%rsp),%rdi
  9e587f:	mov    %rax,0x98(%rsp)
  9e5887:	mov    0xc8(%rsp),%rax
  9e588f:	mov    %rax,0x70(%rsp)
  9e5894:	movups 0x98(%rsp),%xmm0
  9e589c:	movups 0xa8(%rsp),%xmm1
  9e58a4:	movups 0xb8(%rsp),%xmm2
  9e58ac:	movaps %xmm2,0x60(%rsp)
  9e58b1:	movaps %xmm1,0x50(%rsp)
  9e58b6:	movaps %xmm0,0x40(%rsp)
  9e58bb:	mov    %rax,0x30(%rbx)
  9e58bf:	movups %xmm2,0x20(%rbx)
  9e58c3:	movups %xmm1,0x10(%rbx)
  9e58c7:	movups %xmm0,(%rbx)
  9e58ca:	mov    0x10(%rsp),%rsi
  9e58cf:	test   %rsi,%rsi
  9e58d2:	je     9e49bc <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xec>
  9e58d8:	shl    $0x2,%rsi
  9e58dc:	mov    $0x4,%edx
  9e58e1:	call   *0xb46f01(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  9e58e7:	jmp    9e49bc <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xec>
  9e58ec:	xor    %ecx,%ecx
  9e58ee:	lea    0xad495b(%rip),%rax        # 14ba250 <anon.22b410f5f50bcdcdab7a6d64ae00c059.1.llvm.15728315378587307982+0x48>
  9e58f5:	mov    %rax,0x198(%rsp)
  9e58fd:	movabs $0x8000000000000000,%rax
  9e5907:	inc    %rax
  9e590a:	mov    %rax,0x270(%rsp)
  9e5912:	lea    0xad4997(%rip),%rax        # 14ba2b0 <anon.22b410f5f50bcdcdab7a6d64ae00c059.1.llvm.15728315378587307982+0xa8>
  9e5919:	mov    %rax,0x190(%rsp)
  9e5921:	lea    -0x852b08(%rip),%rax        # 192e20 <anon.5e2c2cd338f183f0185d3116c074ef00.75.llvm.4553572696083558104+0x3448>
  9e5928:	mov    %rax,0x188(%rsp)
  9e5930:	jmp    9e5959 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x1089>
  9e5932:	mov    %r12,0x0(%r13)
  9e5936:	mov    0x78(%rsp),%rax
  9e593b:	mov    %eax,0x30(%r13)
  9e593f:	mov    0x278(%rsp),%rcx
  9e5947:	add    $0x4,%rcx
  9e594b:	cmp    %rcx,0x88(%rsp)
  9e5953:	je     9e5c10 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x1340>
  9e5959:	mov    0x138(%rsp),%rax
  9e5961:	mov    %rcx,0x278(%rsp)
  9e5969:	mov    (%rax,%rcx,1),%r9d
  9e596d:	cmp    %r9,0x38(%rsp)
  9e5972:	jbe    9e5cb2 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x13e2>
  9e5978:	mov    0x30(%r14),%rsi
  9e597c:	mov    0x38(%r14),%r12
  9e5980:	lea    0x90(%rsp),%rdi
  9e5988:	mov    %rsi,%r13
  9e598b:	mov    %r12,%rdx
  9e598e:	mov    %r15,%rcx
  9e5991:	lea    0x1b8(%rsp),%r8
  9e5999:	mov    %r9,0x1a0(%rsp)
  9e59a1:	call   9e40a0 <<gpui::native::accessibility::text::Cohort>::replacement::<empty::Empty, ()>>
  9e59a6:	mov    0x90(%rsp),%rsi
  9e59ae:	mov    0x98(%rsp),%rax
  9e59b6:	mov    %rax,0x10(%rsp)
  9e59bb:	mov    0xa0(%rsp),%rax
  9e59c3:	mov    %rax,0x28(%rsp)
  9e59c8:	mov    0xa8(%rsp),%eax
  9e59cf:	mov    %rax,0x78(%rsp)
  9e59d4:	movzbl 0xac(%rsp),%edx
  9e59dc:	lea    0xad(%rsp),%rcx
  9e59e4:	movzwl (%rcx),%eax
  9e59e7:	mov    %ax,0x280(%rsp)
  9e59ef:	movzbl 0x2(%rcx),%eax
  9e59f3:	mov    %al,0x282(%rsp)
  9e59fa:	mov    %rsi,0x110(%rsp)
  9e5a02:	cmp    $0xfffffffffffffffe,%rsi
  9e5a06:	jne    9e5bbc <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x12ec>
  9e5a0c:	cmp    $0x2,%dl
  9e5a0f:	je     9e593f <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x106f>
  9e5a15:	cmp    %r12,0x10(%rsp)
  9e5a1a:	jae    9e5d5c <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x148c>
  9e5a20:	mov    %rdx,%rcx
  9e5a23:	imul   $0x38,0x10(%rsp),%rax
  9e5a29:	mov    %r13,%rdx
  9e5a2c:	add    %rax,%rdx
  9e5a2f:	test   $0x1,%cl
  9e5a32:	je     9e5b44 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x1274>
  9e5a38:	mov    0x28(%rsp),%rax
  9e5a3d:	mov    %rdx,%r13
  9e5a40:	mov    %rax,0x10(%rdx)
  9e5a44:	mov    0x1a0(%rsp),%rax
  9e5a4c:	shl    $0x6,%rax
  9e5a50:	mov    0x80(%rsp),%rcx
  9e5a58:	lea    (%rcx,%rax,1),%rbp
  9e5a5c:	cmpb   $0x4,0x3d(%rcx,%rax,1)
  9e5a61:	jne    9e5a9e <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x11ce>
  9e5a63:	mov    0x28(%rbp),%r12
  9e5a67:	test   %r12,%r12
  9e5a6a:	je     9e5a9e <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x11ce>
  9e5a6c:	testb  $0x1,(%r12)
  9e5a71:	jne    9e5aa1 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x11d1>
  9e5a73:	mov    0x8(%r12),%rax
  9e5a78:	test   $0x1,%al
  9e5a7a:	jne    9e5aa1 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x11d1>
  9e5a7c:	mov    $0x2,%eax
  9e5a81:	lock xadd %rax,0x8(%r12)
  9e5a88:	and    0x270(%rsp),%rax
  9e5a90:	neg    %rax
  9e5a93:	jno    9e5aa1 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x11d1>
  9e5a95:	lock orq $0x1,0x8(%r12)
  9e5a9c:	jmp    9e5aa1 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x11d1>
  9e5a9e:	xor    %r12d,%r12d
  9e5aa1:	mov    0x18(%r13),%rdi
  9e5aa5:	test   %rdi,%rdi
  9e5aa8:	je     9e5ac6 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x11f6>
  9e5aaa:	testb  $0x1,(%rdi)
  9e5aad:	jne    9e5ac6 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x11f6>
  9e5aaf:	mov    0x8(%rdi),%rax
  9e5ab3:	test   $0x1,%al
  9e5ab5:	jne    9e5ac6 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x11f6>
  9e5ab7:	lea    0x8(%rdi),%rax
  9e5abb:	lock subq $0x2,(%rax)
  9e5ac0:	je     9e5bad <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x12dd>
  9e5ac6:	mov    %r12,0x18(%r13)
  9e5aca:	test   %r12,%r12
  9e5acd:	je     9e5ae7 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x1217>
  9e5acf:	mov    0x40(%r14),%rax
  9e5ad3:	cmp    $0xffffffffffffffff,%rax
  9e5ad7:	je     9e5cc5 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x13f5>
  9e5add:	lea    0x1(%rax),%rcx
  9e5ae1:	mov    %rcx,0x40(%r14)
  9e5ae5:	jmp    9e5ae9 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x1219>
  9e5ae7:	xor    %eax,%eax
  9e5ae9:	mov    %r13,%rdx
  9e5aec:	mov    %rax,0x20(%r13)
  9e5af0:	cmpb   $0x4,0x3d(%rbp)
  9e5af4:	jne    9e5b44 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x1274>
  9e5af6:	cmpq   $0x0,0x28(%rbp)
  9e5afb:	je     9e5b44 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x1274>
  9e5afd:	mov    0x38(%rbp),%r12d
  9e5b01:	mov    $0x1ffff,%eax
  9e5b06:	and    %eax,%r12d
  9e5b09:	cmp    $0x1ffff,%r12d
  9e5b10:	jne    9e5b19 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x1249>
  9e5b12:	movb   $0x1,0x68(%rsp)
  9e5b17:	jmp    9e5b41 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x1271>
  9e5b19:	mov    0x50(%rsp),%rbp
  9e5b1e:	cmp    0x40(%rsp),%rbp
  9e5b23:	jne    9e5b30 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x1260>
  9e5b25:	lea    0x40(%rsp),%rdi
  9e5b2a:	call   *0xb471e0(%rip)        # 152cd10 <_DYNAMIC+0x778>
  9e5b30:	mov    0x48(%rsp),%rax
  9e5b35:	mov    %r12d,(%rax,%rbp,4)
  9e5b39:	inc    %rbp
  9e5b3c:	mov    %rbp,0x50(%rsp)
  9e5b41:	mov    %r13,%rdx
  9e5b44:	mov    0x40(%r14),%rcx
  9e5b48:	mov    %rcx,0x28(%rdx)
  9e5b4c:	mov    0x78(%rsp),%rax
  9e5b51:	inc    %rax
  9e5b54:	add    %rcx,%rax
  9e5b57:	jb     9e5c9c <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x13cc>
  9e5b5d:	mov    %rdx,%r13
  9e5b60:	mov    %rax,0x40(%r14)
  9e5b64:	lea    0x1b8(%rsp),%rdi
  9e5b6c:	mov    0x1a0(%rsp),%rsi
  9e5b74:	call   *0xb47506(%rip)        # 152d080 <_DYNAMIC+0xae8>
  9e5b7a:	test   %rax,%rax
  9e5b7d:	je     9e5ca3 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x13d3>
  9e5b83:	mov    (%rax),%r12
  9e5b86:	lock incq (%r12)
  9e5b8b:	jle    9e5d71 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x14a1>
  9e5b91:	mov    0x0(%r13),%rax
  9e5b95:	lock decq (%rax)
  9e5b99:	jne    9e5932 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x1062>
  9e5b9f:	mov    %r13,%rdi
  9e5ba2:	call   *0xb46cb0(%rip)        # 152c858 <_DYNAMIC+0x2c0>
  9e5ba8:	jmp    9e5932 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x1062>
  9e5bad:	mov    0x8(%rdi),%rax
  9e5bb1:	call   *0xb46c79(%rip)        # 152c830 <_DYNAMIC+0x298>
  9e5bb7:	jmp    9e5ac6 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x11f6>
  9e5bbc:	mov    %rdx,%rbp
  9e5bbf:	mov    0xb0(%rsp),%r12
  9e5bc7:	mov    0xb8(%rsp),%rax
  9e5bcf:	mov    %rax,0x80(%rsp)
  9e5bd7:	mov    0xc0(%rsp),%rax
  9e5bdf:	mov    %rax,0x38(%rsp)
  9e5be4:	movzwl 0x280(%rsp),%eax
  9e5bec:	mov    %ax,0x18(%rsp)
  9e5bf1:	movzbl 0x282(%rsp),%eax
  9e5bf9:	mov    %al,0x1a(%rsp)
  9e5bfd:	mov    0x40(%rsp),%rsi
  9e5c02:	test   %rsi,%rsi
  9e5c05:	jne    9e54b8 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xbe8>
  9e5c0b:	jmp    9e553e <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xc6e>
  9e5c10:	mov    0x118(%rsp),%rax
  9e5c18:	mov    %rax,0x60(%rsp)
  9e5c1d:	mov    0x50(%rsp),%rsi
  9e5c22:	cmp    $0x2,%rsi
  9e5c26:	jae    9e5d00 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x1430>
  9e5c2c:	lea    0x40(%rsp),%rdi
  9e5c31:	call   9fff60 <<alloc::vec::Vec<u32>>::dedup_by::<<alloc::vec::Vec<u32>>::dedup::{closure#0}>>
  9e5c36:	mov    0x40(%rsp),%r9
  9e5c3b:	mov    0x48(%rsp),%r8
  9e5c40:	mov    0x50(%rsp),%edi
  9e5c44:	movzbl 0x54(%rsp),%r10d
  9e5c4a:	movzwl 0x55(%rsp),%eax
  9e5c4f:	mov    %ax,0x18(%rsp)
  9e5c54:	movzbl 0x57(%rsp),%eax
  9e5c59:	mov    %al,0x1a(%rsp)
  9e5c5d:	mov    0x58(%rsp),%r12
  9e5c62:	mov    0x60(%rsp),%rsi
  9e5c67:	mov    0x68(%rsp),%rdx
  9e5c6c:	jmp    9e556f <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xc9f>
  9e5c71:	mov    $0x1e,%eax
  9e5c76:	jmp    9e5417 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0xb47>
  9e5c7b:	cmp    $0x15,%rsi
  9e5c7f:	jae    9e5d73 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x14a3>
  9e5c85:	lea    0x90(%rsp),%rcx
  9e5c8d:	mov    $0x1,%edx
  9e5c92:	call   9fdc90 <core::slice::sort::shared::smallsort::insertion_sort_shift_left::<gpui::native::accessibility::text::Input, <[gpui::native::accessibility::text::Input]>::sort_unstable_by_key<u64, <gpui::native::accessibility::text::Cohort>::refresh<empty::Empty, ()>::{closure#3}>::{closure#0}>>
  9e5c97:	jmp    9e502f <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x75f>
  9e5c9c:	mov    $0x22,%esi
  9e5ca1:	jmp    9e5ce8 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x1418>
  9e5ca3:	lea    0xad45ee(%rip),%rax        # 14ba298 <anon.22b410f5f50bcdcdab7a6d64ae00c059.1.llvm.15728315378587307982+0x90>
  9e5caa:	mov    %rax,0x198(%rsp)
  9e5cb2:	mov    0x198(%rsp),%rdi
  9e5cba:	call   *0xb46b50(%rip)        # 152c810 <_DYNAMIC+0x278>
  9e5cc0:	jmp    9e5d71 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x14a1>
  9e5cc5:	mov    $0x1b,%esi
  9e5cca:	lea    -0x852ecc(%rip),%rax        # 192e05 <anon.5e2c2cd338f183f0185d3116c074ef00.75.llvm.4553572696083558104+0x342d>
  9e5cd1:	mov    %rax,0x188(%rsp)
  9e5cd9:	lea    0xad45a0(%rip),%rax        # 14ba280 <anon.22b410f5f50bcdcdab7a6d64ae00c059.1.llvm.15728315378587307982+0x78>
  9e5ce0:	mov    %rax,0x190(%rsp)
  9e5ce8:	mov    0x188(%rsp),%rdi
  9e5cf0:	mov    0x190(%rsp),%rdx
  9e5cf8:	call   *0xb46c0a(%rip)        # 152c908 <_DYNAMIC+0x370>
  9e5cfe:	jmp    9e5d71 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x14a1>
  9e5d00:	mov    0x48(%rsp),%rdi
  9e5d05:	cmp    $0x15,%rsi
  9e5d09:	jae    9e5d85 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x14b5>
  9e5d0b:	lea    (%rdi,%rsi,4),%rax
  9e5d0f:	lea    0x4(%rdi),%rcx
  9e5d13:	mov    $0x4,%edx
  9e5d18:	jmp    9e5d31 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x1461>
  9e5d1a:	mov    %rdi,%r8
  9e5d1d:	mov    %esi,(%r8)
  9e5d20:	add    $0x4,%rcx
  9e5d24:	add    $0x4,%rdx
  9e5d28:	cmp    %rax,%rcx
  9e5d2b:	je     9e5c2c <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x135c>
  9e5d31:	mov    -0x4(%rcx),%r9d
  9e5d35:	mov    (%rcx),%esi
  9e5d37:	cmp    %r9d,%esi
  9e5d3a:	jae    9e5d20 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x1450>
  9e5d3c:	mov    %rdx,%r8
  9e5d3f:	mov    %r9d,(%rdi,%r8,1)
  9e5d43:	cmp    $0x4,%r8
  9e5d47:	je     9e5d1a <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x144a>
  9e5d49:	mov    -0x8(%rdi,%r8,1),%r9d
  9e5d4e:	add    $0xfffffffffffffffc,%r8
  9e5d52:	cmp    %r9d,%esi
  9e5d55:	jb     9e5d3f <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x146f>
  9e5d57:	add    %rdi,%r8
  9e5d5a:	jmp    9e5d1d <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x144d>
  9e5d5c:	lea    0xad4505(%rip),%rdx        # 14ba268 <anon.22b410f5f50bcdcdab7a6d64ae00c059.1.llvm.15728315378587307982+0x60>
  9e5d63:	mov    0x10(%rsp),%rdi
  9e5d68:	mov    %r12,%rsi
  9e5d6b:	call   *0xb46b4f(%rip)        # 152c8c0 <_DYNAMIC+0x328>
  9e5d71:	ud2
  9e5d73:	lea    0x90(%rsp),%rdx
  9e5d7b:	call   a15c20 <core::slice::sort::unstable::ipnsort::<gpui::native::accessibility::text::Input, <[gpui::native::accessibility::text::Input]>::sort_unstable_by_key<u64, <gpui::native::accessibility::text::Cohort>::refresh<empty::Empty, ()>::{closure#3}>::{closure#0}>>
  9e5d80:	jmp    9e502f <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x75f>
  9e5d85:	lea    0x27(%rsp),%rdx
  9e5d8a:	call   *0xb47310(%rip)        # 152d0a0 <_DYNAMIC+0xb08>
  9e5d90:	jmp    9e5c2c <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x135c>
  9e5d95:	mov    %rax,%rbx
  9e5d98:	mov    %r12,0x18(%r13)
  9e5d9c:	jmp    9e5e4d <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x157d>
  9e5da1:	mov    %rax,%rbx
  9e5da4:	mov    %r12,0x0(%r13)
  9e5da8:	jmp    9e5e4d <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x157d>
  9e5dad:	mov    %rax,%rbx
  9e5db0:	mov    (%r12),%rax
  9e5db4:	test   %rax,%rax
  9e5db7:	je     9e5dcc <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x14fc>
  9e5db9:	mov    0x30(%r14),%rdi
  9e5dbd:	imul   $0x38,%rax,%rsi
  9e5dc1:	mov    $0x8,%edx
  9e5dc6:	call   *0xb46a1c(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  9e5dcc:	mov    0xa0(%rsp),%rax
  9e5dd4:	mov    %rax,0x10(%r12)
  9e5dd9:	movaps 0x90(%rsp),%xmm0
  9e5de1:	movups %xmm0,(%r12)
  9e5de6:	mov    %rbx,%rdi
  9e5de9:	call   14b7130 <_Unwind_Resume@plt>
  9e5dee:	mov    %rax,%rbx
  9e5df1:	mov    0x40(%rsp),%rax
  9e5df6:	test   %rax,%rax
  9e5df9:	je     9e5e57 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x1587>
  9e5dfb:	mov    0x48(%rsp),%rdi
  9e5e00:	imul   $0x38,%rax,%rsi
  9e5e04:	mov    $0x8,%edx
  9e5e09:	call   *0xb469d9(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  9e5e0f:	mov    %rbx,%rdi
  9e5e12:	call   14b7130 <_Unwind_Resume@plt>
  9e5e17:	jmp    9e5e4a <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x157a>
  9e5e19:	mov    %rax,%rbx
  9e5e1c:	lea    0x40(%rsp),%rdi
  9e5e21:	call   9e72d0 <core::ptr::drop_glue::<alloc::vec::Vec<gpui::native::accessibility::text::Input>>>
  9e5e26:	jmp    9e5e57 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x1587>
  9e5e28:	call   *0xb469f2(%rip)        # 152c820 <_DYNAMIC+0x288>
  9e5e2e:	mov    %rax,%rbx
  9e5e31:	mov    0x158(%rsp),%rsi
  9e5e39:	test   %rsi,%rsi
  9e5e3c:	je     9e5e57 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x1587>
  9e5e3e:	mov    0x160(%rsp),%rdi
  9e5e46:	jmp    9e5e64 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x1594>
  9e5e48:	jmp    9e5e4a <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x157a>
  9e5e4a:	mov    %rax,%rbx
  9e5e4d:	mov    0x40(%rsp),%rsi
  9e5e52:	test   %rsi,%rsi
  9e5e55:	jne    9e5e5f <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>+0x158f>
  9e5e57:	mov    %rbx,%rdi
  9e5e5a:	call   14b7130 <_Unwind_Resume@plt>
  9e5e5f:	mov    0x48(%rsp),%rdi
  9e5e64:	shl    $0x2,%rsi
  9e5e68:	mov    $0x4,%edx
  9e5e6d:	call   *0xb46975(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  9e5e73:	mov    %rbx,%rdi
  9e5e76:	call   14b7130 <_Unwind_Resume@plt>


/tmp/gpui-a11y-owner-channel-captures/release-candidate/empty:     file format elf64-x86-64


Disassembly of section .text:

00000000009e5e80 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>>:
  9e5e80:	push   %rbp
  9e5e81:	push   %r15
  9e5e83:	push   %r14
  9e5e85:	push   %r13
  9e5e87:	push   %r12
  9e5e89:	push   %rbx
  9e5e8a:	sub    $0x568,%rsp
  9e5e91:	mov    %rdi,%rbx
  9e5e94:	cmpb   $0x2,0x80(%rsi)
  9e5e9b:	jne    9e5f4c <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0xcc>
  9e5ea1:	movq   $0xfffffffffffffffd,(%rbx)
  9e5ea8:	movq   $0xfffffffffffffffd,0x38(%rbx)
  9e5eb0:	movq   $0xfffffffffffffffd,0x70(%rbx)
  9e5eb8:	movq   $0xfffffffffffffffd,0xa8(%rbx)
  9e5ec3:	movq   $0xfffffffffffffffd,0xe0(%rbx)
  9e5ece:	movq   $0xfffffffffffffffd,0x118(%rbx)
  9e5ed9:	movq   $0xfffffffffffffffd,0x150(%rbx)
  9e5ee4:	movq   $0xfffffffffffffffd,0x188(%rbx)
  9e5eef:	movq   $0xfffffffffffffffd,0x1c0(%rbx)
  9e5efa:	movq   $0xfffffffffffffffd,0x1f8(%rbx)
  9e5f05:	movq   $0xfffffffffffffffd,0x230(%rbx)
  9e5f10:	movq   $0xfffffffffffffffd,0x268(%rbx)
  9e5f1b:	movq   $0xfffffffffffffffd,0x2a0(%rbx)
  9e5f26:	movq   $0xfffffffffffffffd,0x2d8(%rbx)
  9e5f31:	movq   $0xfffffffffffffffd,0x310(%rbx)
  9e5f3c:	movq   $0xfffffffffffffffd,0x348(%rbx)
  9e5f47:	jmp    9e6a12 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0xb92>
  9e5f4c:	mov    %rsi,%r15
  9e5f4f:	cmpl   $0xffffffff,(%rsi)
  9e5f52:	je     9e6a27 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0xba7>
  9e5f58:	mov    0xa0(%r15),%r14
  9e5f5f:	movzbl 0x51(%r14),%eax
  9e5f64:	test   %al,%al
  9e5f66:	je     9e5f81 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x101>
  9e5f68:	movb   $0x1,0x50(%r14)
  9e5f6d:	movq   $0x2a,0x8(%rbx)
  9e5f75:	movq   $0xfffffffffffffffc,(%rbx)
  9e5f7c:	jmp    9e6a12 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0xb92>
  9e5f81:	mov    %rdx,0x78(%rsp)
  9e5f86:	lea    0x28(%r15),%rax
  9e5f8a:	mov    %rax,0x128(%rsp)
  9e5f92:	lea    0x10(%r14),%rax
  9e5f96:	mov    %rax,0x140(%rsp)
  9e5f9e:	movq   $0xfffffffffffffffd,0x1e8(%rsp)
  9e5faa:	movq   $0xfffffffffffffffd,0x220(%rsp)
  9e5fb6:	movq   $0xfffffffffffffffd,0x258(%rsp)
  9e5fc2:	movq   $0xfffffffffffffffd,0x290(%rsp)
  9e5fce:	movq   $0xfffffffffffffffd,0x2c8(%rsp)
  9e5fda:	movq   $0xfffffffffffffffd,0x300(%rsp)
  9e5fe6:	movq   $0xfffffffffffffffd,0x338(%rsp)
  9e5ff2:	movq   $0xfffffffffffffffd,0x370(%rsp)
  9e5ffe:	movq   $0xfffffffffffffffd,0x3a8(%rsp)
  9e600a:	movq   $0xfffffffffffffffd,0x3e0(%rsp)
  9e6016:	movq   $0xfffffffffffffffd,0x418(%rsp)
  9e6022:	movq   $0xfffffffffffffffd,0x450(%rsp)
  9e602e:	movq   $0xfffffffffffffffd,0x488(%rsp)
  9e603a:	movq   $0xfffffffffffffffd,0x4c0(%rsp)
  9e6046:	movq   $0xfffffffffffffffd,0x4f8(%rsp)
  9e6052:	movq   $0xfffffffffffffffd,0x530(%rsp)
  9e605e:	mov    0x30(%r15),%r12
  9e6062:	mov    0x48(%r15),%rax
  9e6066:	mov    %rax,0x18(%rsp)
  9e606b:	imul   $0x38,0x38(%r15),%rax
  9e6070:	mov    %rax,0x148(%rsp)
  9e6078:	xor    %ebp,%ebp
  9e607a:	lea    0x30(%rsp),%r13
  9e607f:	mov    %r15,0x158(%rsp)
  9e6087:	mov    %r14,0x150(%rsp)
  9e608f:	mov    %r12,0xe8(%rsp)
  9e6097:	jmp    9e612f <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x2af>
  9e609c:	nopl   0x0(%rax)
  9e60a0:	mov    0x60(%rsp),%rax
  9e60a5:	mov    %rax,0x30(%r14)
  9e60a9:	movaps 0x30(%rsp),%xmm0
  9e60ae:	movaps 0x40(%rsp),%xmm1
  9e60b3:	mov    0x50(%rsp),%eax
  9e60b7:	mov    %eax,0x20(%r14)
  9e60bb:	movzbl 0x54(%rsp),%eax
  9e60c0:	mov    %al,0x24(%r14)
  9e60c4:	movzwl 0x55(%rsp),%eax
  9e60c9:	mov    %ax,0x25(%r14)
  9e60ce:	movzbl 0x57(%rsp),%eax
  9e60d3:	mov    %al,0x27(%r14)
  9e60d7:	mov    0x58(%rsp),%eax
  9e60db:	mov    %eax,0x28(%r14)
  9e60df:	movzbl 0x5c(%rsp),%eax
  9e60e4:	mov    %al,0x2c(%r14)
  9e60e8:	movzwl 0x5d(%rsp),%eax
  9e60ed:	mov    %ax,0x2d(%r14)
  9e60f2:	movzbl 0x5f(%rsp),%eax
  9e60f7:	mov    %al,0x2f(%r14)
  9e60fb:	movups %xmm1,0x10(%r14)
  9e6100:	movups %xmm0,(%r14)
  9e6104:	mov    0x150(%rsp),%r14
  9e610c:	lea    0x30(%rsp),%r13
  9e6111:	add    $0x38,%rbp
  9e6115:	lea    0x1a0(%rsp),%rdi
  9e611d:	call   9e7bd0 <core::ptr::drop_glue::<gpui::native::accessibility::Queued>>
  9e6122:	cmp    $0x380,%rbp
  9e6129:	je     9e69ee <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0xb6e>
  9e612f:	mov    %r13,%rdi
  9e6132:	mov    %r15,%rsi
  9e6135:	call   a10790 <<std::sync::mpmc::Receiver<gpui::native::accessibility::Queued>>::try_recv>
  9e613a:	cmpb   $0xff,0x30(%rsp)
  9e613f:	je     9e69fc <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0xb7c>
  9e6145:	mov    0x50(%rsp),%rax
  9e614a:	mov    %rax,0x1c0(%rsp)
  9e6152:	movups 0x30(%rsp),%xmm0
  9e6157:	movups 0x40(%rsp),%xmm1
  9e615c:	movaps %xmm1,0x1b0(%rsp)
  9e6164:	movaps %xmm0,0x1a0(%rsp)
  9e616c:	mov    0x48(%r14),%rcx
  9e6170:	cmp    %rcx,%rax
  9e6173:	jne    9e6111 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x291>
  9e6175:	mov    %r13,%rdi
  9e6178:	lea    0x1a0(%rsp),%rsi
  9e6180:	mov    0x128(%rsp),%rdx
  9e6188:	call   *0xb46f1a(%rip)        # 152d0a8 <_DYNAMIC+0xb10>
  9e618e:	mov    0x30(%rsp),%rax
  9e6193:	mov    0x38(%rsp),%r13
  9e6198:	movups 0x40(%rsp),%xmm0
  9e619d:	movsd  0x50(%rsp),%xmm1
  9e61a3:	mov    0x58(%rsp),%r15d
  9e61a8:	movzbl 0x5c(%rsp),%esi
  9e61ad:	lea    0x5d(%rsp),%rdx
  9e61b2:	movzwl (%rdx),%ecx
  9e61b5:	mov    %cx,0x80(%rsp)
  9e61bd:	movzbl 0x2(%rdx),%ecx
  9e61c1:	mov    %cl,0x82(%rsp)
  9e61c8:	cmp    $0xfffffffffffffffe,%rax
  9e61cc:	jne    9e6230 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x3b0>
  9e61ce:	movaps %xmm1,0x1d0(%rsp)
  9e61d6:	movaps %xmm0,0xf0(%rsp)
  9e61de:	movzwl 0x80(%rsp),%eax
  9e61e6:	mov    %ax,0x2c(%rsp)
  9e61eb:	movzbl 0x82(%rsp),%eax
  9e61f3:	mov    %al,0x2e(%rsp)
  9e61f7:	mov    0x78(%rsp),%rax
  9e61fc:	mov    (%rax),%r14
  9e61ff:	test   %r14,%r14
  9e6202:	je     9e6292 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x412>
  9e6208:	mov    %sil,0xf(%rsp)
  9e620d:	mov    $0xe,%esi
  9e6212:	cmpb   $0x0,0x72e(%r14)
  9e621a:	je     9e629e <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x41e>
  9e6220:	mov    0x10(%rsp),%rax
  9e6225:	jmp    9e6309 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x489>
  9e622a:	nopw   0x0(%rax,%rax,1)
  9e6230:	mov    0x60(%rsp),%rcx
  9e6235:	movzbl 0x82(%rsp),%edx
  9e623d:	mov    %esi,%edi
  9e623f:	lea    0xdd(%rsp),%rsi
  9e6247:	mov    %dl,0x2(%rsi)
  9e624a:	movzwl 0x80(%rsp),%edx
  9e6252:	mov    %dx,(%rsi)
  9e6255:	mov    %rax,0xb0(%rsp)
  9e625d:	mov    %r13,0xb8(%rsp)
  9e6265:	movups %xmm0,0xc0(%rsp)
  9e626d:	movlps %xmm1,0xd0(%rsp)
  9e6275:	mov    %r15d,0xd8(%rsp)
  9e627d:	mov    %dil,0xdc(%rsp)
  9e6285:	mov    %rcx,0xe0(%rsp)
  9e628d:	jmp    9e6346 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x4c6>
  9e6292:	mov    $0xd,%esi
  9e6297:	mov    0x10(%rsp),%rax
  9e629c:	jmp    9e6309 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x489>
  9e629e:	mov    0x5b0(%r14),%rax
  9e62a5:	mov    $0x11,%esi
  9e62aa:	mov    %rax,0x10(%rsp)
  9e62af:	cmp    %rax,0x18(%rsp)
  9e62b4:	jne    9e6304 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x484>
  9e62b6:	test   %r13,%r13
  9e62b9:	js     9e646c <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x5ec>
  9e62bf:	setne  %al
  9e62c2:	test   $0x1,%r13b
  9e62c6:	sete   %cl
  9e62c9:	test   %cl,%al
  9e62cb:	je     9e62fa <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x47a>
  9e62cd:	shr    $1,%r13
  9e62d0:	mov    0x128(%rsp),%rdi
  9e62d8:	mov    %r13,%rsi
  9e62db:	call   *0xb46dcf(%rip)        # 152d0b0 <_DYNAMIC+0xb18>
  9e62e1:	test   %rax,%rax
  9e62e4:	mov    $0x11,%esi
  9e62e9:	je     9e6580 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x700>
  9e62ef:	cmpq   $0x0,0x18(%rax)
  9e62f4:	je     9e6580 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x700>
  9e62fa:	mov    0x18(%rsp),%rax
  9e62ff:	mov    %rax,0x10(%rsp)
  9e6304:	mov    0x20(%rsp),%rdx
  9e6309:	movaps 0x100(%rsp),%xmm0
  9e6311:	movaps 0x110(%rsp),%xmm1
  9e6319:	lea    0xdd(%rsp),%rcx
  9e6321:	movups %xmm1,-0x5(%rcx)
  9e6325:	movups %xmm0,-0x15(%rcx)
  9e6329:	mov    %rsi,0xb0(%rsp)
  9e6331:	mov    %rax,0xb8(%rsp)
  9e6339:	mov    %rdx,0x20(%rsp)
  9e633e:	mov    %rdx,0xc0(%rsp)
  9e6346:	lea    (%rsp,%rbp,1),%r14
  9e634a:	add    $0x1e8,%r14
  9e6351:	mov    0xb0(%rsp),%rax
  9e6359:	mov    0xb8(%rsp),%rcx
  9e6361:	mov    0xc0(%rsp),%rdx
  9e6369:	mov    0xc8(%rsp),%rsi
  9e6371:	mov    0xd0(%rsp),%edi
  9e6378:	movzbl 0xd4(%rsp),%r8d
  9e6381:	movzwl 0xd5(%rsp),%r9d
  9e638a:	movzbl 0xd7(%rsp),%r10d
  9e6393:	mov    0xd8(%rsp),%r11d
  9e639b:	movzbl 0xdc(%rsp),%r15d
  9e63a4:	movzwl 0xdd(%rsp),%r12d
  9e63ad:	movzbl 0xdf(%rsp),%r13d
  9e63b6:	mov    %rax,0x30(%rsp)
  9e63bb:	mov    %rcx,0x38(%rsp)
  9e63c0:	mov    %rdx,0x40(%rsp)
  9e63c5:	mov    %rsi,0x48(%rsp)
  9e63ca:	mov    %edi,0x50(%rsp)
  9e63ce:	mov    %r8b,0x54(%rsp)
  9e63d3:	mov    %r9w,0x55(%rsp)
  9e63d9:	mov    %r10b,0x57(%rsp)
  9e63de:	mov    %r11d,0x58(%rsp)
  9e63e3:	mov    %r15b,0x5c(%rsp)
  9e63e8:	mov    %r12w,0x5d(%rsp)
  9e63ee:	mov    %r13b,0x5f(%rsp)
  9e63f3:	mov    0xe0(%rsp),%rax
  9e63fb:	mov    %rax,0x60(%rsp)
  9e6400:	mov    (%r14),%rcx
  9e6403:	cmp    $0xffffffffffffffff,%rcx
  9e6407:	mov    0x158(%rsp),%r15
  9e640f:	jl     9e60a0 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x220>
  9e6415:	sub    $0xd,%rcx
  9e6419:	mov    $0x14,%eax
  9e641e:	cmovl  %rax,%rcx
  9e6422:	cmp    $0x19,%rcx
  9e6426:	je     9e6445 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x5c5>
  9e6428:	mov    $0x18,%eax
  9e642d:	cmp    $0x14,%rcx
  9e6431:	jne    9e60a0 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x220>
  9e6437:	mov    (%r14,%rax,1),%rsi
  9e643b:	test   %rsi,%rsi
  9e643e:	jne    9e6457 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x5d7>
  9e6440:	jmp    9e60a0 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x220>
  9e6445:	mov    $0x8,%eax
  9e644a:	mov    (%r14,%rax,1),%rsi
  9e644e:	test   %rsi,%rsi
  9e6451:	je     9e60a0 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x220>
  9e6457:	mov    0x8(%r14,%rax,1),%rdi
  9e645c:	mov    $0x1,%edx
  9e6461:	call   *0xb46381(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  9e6467:	jmp    9e60a0 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x220>
  9e646c:	lea    0x5b0(%r14),%rcx
  9e6473:	xor    %r12d,%r12d
  9e6476:	mov    0xe8(%rsp),%rax
  9e647e:	xchg   %ax,%ax
  9e6480:	cmp    %r12,0x148(%rsp)
  9e6488:	je     9e62fa <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x47a>
  9e648e:	add    $0x38,%r12
  9e6492:	cmp    %r13,0x20(%rax)
  9e6496:	lea    0x38(%rax),%rax
  9e649a:	jne    9e6480 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x600>
  9e649c:	mov    0xe8(%rsp),%rax
  9e64a4:	mov    -0x30(%rax,%r12,1),%rsi
  9e64a9:	test   %rsi,%rsi
  9e64ac:	je     9e65b5 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x735>
  9e64b2:	mov    %rcx,%r13
  9e64b5:	mov    %rcx,%rdi
  9e64b8:	call   *0xb46462(%rip)        # 152c920 <_DYNAMIC+0x388>
  9e64be:	mov    %rax,0x70(%rsp)
  9e64c3:	mov    %rdx,0x68(%rsp)
  9e64c8:	mov    $0x11,%esi
  9e64cd:	mov    0x70(%rsp),%rax
  9e64d2:	cmp    0x0(%r13),%rax
  9e64d6:	jne    9e66a8 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x828>
  9e64dc:	lea    0x30(%rsp),%rdi
  9e64e1:	mov    %r14,%rsi
  9e64e4:	mov    0x68(%rsp),%rdx
  9e64e9:	call   9d1760 <<gpui::runtime::Runtime<empty::Empty>>::resolve_identity>
  9e64ee:	mov    0x30(%rsp),%rsi
  9e64f3:	cmp    $0xfffffffffffffffe,%rsi
  9e64f7:	jne    9e66af <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x82f>
  9e64fd:	lea    0x30(%rsp),%rdi
  9e6502:	mov    0x78(%rsp),%rsi
  9e6507:	mov    0x70(%rsp),%rdx
  9e650c:	mov    0x68(%rsp),%rcx
  9e6511:	call   9bb1b0 <<gpui::runtime::Win<empty::Empty>>::accessibility_input>
  9e6516:	mov    0x30(%rsp),%rsi
  9e651b:	mov    0x38(%rsp),%rax
  9e6520:	mov    0x40(%rsp),%rcx
  9e6525:	cmp    $0xfffffffffffffffe,%rsi
  9e6529:	jne    9e67bd <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x93d>
  9e652f:	mov    $0x11,%esi
  9e6534:	mov    0xe8(%rsp),%rdx
  9e653c:	cmp    %rax,-0x28(%rdx,%r12,1)
  9e6541:	jne    9e62fa <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x47a>
  9e6547:	mov    -0x20(%rdx,%r12,1),%rax
  9e654c:	test   %rax,%rax
  9e654f:	je     9e6a40 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0xbc0>
  9e6555:	mov    (%rcx),%rcx
  9e6558:	cmp    %rcx,%rax
  9e655b:	jne    9e62fa <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x47a>
  9e6561:	mov    (%rcx),%rcx
  9e6564:	xor    (%rax),%rcx
  9e6567:	cmp    $0x2,%rcx
  9e656b:	jae    9e62fa <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x47a>
  9e6571:	mov    0x68(%rsp),%r12
  9e6576:	mov    0x70(%rsp),%r13
  9e657b:	jmp    9e6629 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x7a9>
  9e6580:	mov    0x78(%rsp),%rax
  9e6585:	mov    (%rax),%r14
  9e6588:	test   %r14,%r14
  9e658b:	je     9e65a6 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x726>
  9e658d:	mov    $0xe,%esi
  9e6592:	cmpb   $0x0,0x72e(%r14)
  9e659a:	je     9e65c4 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x744>
  9e659c:	mov    0x20(%rsp),%rdx
  9e65a1:	jmp    9e67a6 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x926>
  9e65a6:	mov    $0xd,%esi
  9e65ab:	mov    0x20(%rsp),%rdx
  9e65b0:	jmp    9e67a6 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x926>
  9e65b5:	mov    $0x11,%esi
  9e65ba:	mov    0x68(%rsp),%rax
  9e65bf:	jmp    9e670b <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x88b>
  9e65c4:	lea    0x5b0(%r14),%r12
  9e65cb:	mov    %r12,%rdi
  9e65ce:	mov    %r13,%rsi
  9e65d1:	call   *0xb46349(%rip)        # 152c920 <_DYNAMIC+0x388>
  9e65d7:	mov    %rax,0xa8(%rsp)
  9e65df:	mov    %rdx,0x20(%rsp)
  9e65e4:	mov    $0x11,%esi
  9e65e9:	mov    0xa8(%rsp),%rax
  9e65f1:	cmp    (%r12),%rax
  9e65f5:	jne    9e66aa <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x82a>
  9e65fb:	lea    0x30(%rsp),%rdi
  9e6600:	mov    %r14,%rsi
  9e6603:	mov    0x20(%rsp),%rdx
  9e6608:	call   9d1760 <<gpui::runtime::Runtime<empty::Empty>>::resolve_identity>
  9e660d:	mov    0x30(%rsp),%rsi
  9e6612:	cmp    $0xfffffffffffffffe,%rsi
  9e6616:	jne    9e6747 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x8c7>
  9e661c:	mov    0x20(%rsp),%r12
  9e6621:	mov    0xa8(%rsp),%r13
  9e6629:	movzbl 0xf(%rsp),%edx
  9e662e:	mov    %edx,%eax
  9e6630:	sub    $0x2,%al
  9e6632:	movzbl %al,%r14d
  9e6636:	mov    $0x6,%eax
  9e663b:	cmovb  %eax,%r14d
  9e663f:	lea    -0x7(%r14),%eax
  9e6643:	cmp    $0x2,%al
  9e6645:	jae    9e67ec <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x96c>
  9e664b:	lea    0x30(%rsp),%rdi
  9e6650:	mov    0x78(%rsp),%rsi
  9e6655:	mov    %r13,%rdx
  9e6658:	mov    %r12,%rcx
  9e665b:	call   9bc9e0 <<gpui::runtime::Win<empty::Empty>>::accessibility_viewport_transform>
  9e6660:	mov    0x30(%rsp),%rax
  9e6665:	movss  0x38(%rsp),%xmm0
  9e666b:	cmp    $0xfffffffffffffffe,%rax
  9e666f:	jne    9e6890 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0xa10>
  9e6675:	movss  0x44(%rsp),%xmm1
  9e667b:	cmp    $0x7,%r14b
  9e667f:	je     9e6961 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0xae1>
  9e6685:	unpcklps %xmm1,%xmm0
  9e6688:	cvtps2pd %xmm0,%xmm0
  9e668b:	movapd 0xf0(%rsp),%xmm1
  9e6694:	divpd  %xmm0,%xmm1
  9e6698:	movapd %xmm1,0xf0(%rsp)
  9e66a1:	mov    $0xa,%dl
  9e66a3:	jmp    9e6805 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x985>
  9e66a8:	jmp    9e66e3 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x863>
  9e66aa:	jmp    9e677e <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x8fe>
  9e66af:	mov    0x38(%rsp),%rax
  9e66b4:	mov    %rax,0x70(%rsp)
  9e66b9:	mov    0x40(%rsp),%rax
  9e66be:	mov    %rax,0x138(%rsp)
  9e66c6:	lea    0x5d(%rsp),%rax
  9e66cb:	movups -0x15(%rax),%xmm0
  9e66cf:	movups -0x5(%rax),%xmm1
  9e66d3:	movaps %xmm0,0x80(%rsp)
  9e66db:	movaps %xmm1,0x90(%rsp)
  9e66e3:	movaps 0x80(%rsp),%xmm0
  9e66eb:	movaps 0x90(%rsp),%xmm1
  9e66f3:	movaps %xmm1,0x170(%rsp)
  9e66fb:	movaps %xmm0,0x160(%rsp)
  9e6703:	mov    0x138(%rsp),%rax
  9e670b:	movaps 0x160(%rsp),%xmm0
  9e6713:	movaps 0x170(%rsp),%xmm1
  9e671b:	movaps %xmm0,0x100(%rsp)
  9e6723:	movaps %xmm1,0x110(%rsp)
  9e672b:	mov    0x18(%rsp),%rcx
  9e6730:	mov    %rcx,0x10(%rsp)
  9e6735:	mov    %rax,0x68(%rsp)
  9e673a:	mov    %rax,%rdx
  9e673d:	mov    0x70(%rsp),%rax
  9e6742:	jmp    9e6309 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x489>
  9e6747:	mov    0x38(%rsp),%rax
  9e674c:	mov    %rax,0xa8(%rsp)
  9e6754:	mov    0x40(%rsp),%rax
  9e6759:	mov    %rax,0x130(%rsp)
  9e6761:	lea    0x5d(%rsp),%rax
  9e6766:	movups -0x15(%rax),%xmm0
  9e676a:	movups -0x5(%rax),%xmm1
  9e676e:	movaps %xmm0,0x80(%rsp)
  9e6776:	movaps %xmm1,0x90(%rsp)
  9e677e:	movaps 0x80(%rsp),%xmm0
  9e6786:	movaps 0x90(%rsp),%xmm1
  9e678e:	movaps %xmm1,0x110(%rsp)
  9e6796:	movaps %xmm0,0x100(%rsp)
  9e679e:	mov    0x130(%rsp),%rdx
  9e67a6:	mov    0x18(%rsp),%rax
  9e67ab:	mov    %rax,0x10(%rsp)
  9e67b0:	mov    0xa8(%rsp),%rax
  9e67b8:	jmp    9e6309 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x489>
  9e67bd:	lea    0x5d(%rsp),%rdx
  9e67c2:	movups -0x15(%rdx),%xmm0
  9e67c6:	movups -0x5(%rdx),%xmm1
  9e67ca:	movaps %xmm1,0x110(%rsp)
  9e67d2:	movaps %xmm0,0x100(%rsp)
  9e67da:	mov    0x18(%rsp),%rdx
  9e67df:	mov    %rdx,0x10(%rsp)
  9e67e4:	mov    %rcx,%rdx
  9e67e7:	jmp    9e6309 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x489>
  9e67ec:	movzbl 0x2e(%rsp),%eax
  9e67f1:	mov    %al,0x82(%rsp)
  9e67f8:	movzwl 0x2c(%rsp),%eax
  9e67fd:	mov    %ax,0x80(%rsp)
  9e6805:	movzbl 0x82(%rsp),%eax
  9e680d:	mov    %al,0x102(%rsp)
  9e6814:	movzwl 0x80(%rsp),%ecx
  9e681c:	mov    %cx,0x100(%rsp)
  9e6824:	movaps 0xf0(%rsp),%xmm0
  9e682c:	movaps %xmm0,0x180(%rsp)
  9e6834:	movaps 0x1d0(%rsp),%xmm0
  9e683c:	movlps %xmm0,0x190(%rsp)
  9e6844:	mov    %r15d,0x198(%rsp)
  9e684c:	mov    %dl,0x19c(%rsp)
  9e6853:	lea    0x19d(%rsp),%rdx
  9e685b:	mov    %al,0x2(%rdx)
  9e685e:	mov    %cx,(%rdx)
  9e6861:	lea    0xb0(%rsp),%rdi
  9e6869:	mov    0x78(%rsp),%rsi
  9e686e:	mov    %r13,%rdx
  9e6871:	mov    %r12,%rcx
  9e6874:	lea    0x180(%rsp),%r8
  9e687c:	call   9b90f0 <<gpui::runtime::Win<empty::Empty>>::perform>
  9e6881:	mov    0x18(%rsp),%rax
  9e6886:	mov    %rax,0x10(%rsp)
  9e688b:	jmp    9e6346 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x4c6>
  9e6890:	movss  0x3c(%rsp),%xmm1
  9e6896:	mov    0x50(%rsp),%ecx
  9e689a:	movzbl 0x54(%rsp),%edx
  9e689f:	lea    0x5d(%rsp),%rsi
  9e68a4:	movups -0x8(%rsi),%xmm2
  9e68a8:	movaps %xmm2,0x80(%rsp)
  9e68b0:	mov    0x7(%rsi),%esi
  9e68b3:	mov    %esi,0x8f(%rsp)
  9e68ba:	movdqu 0x40(%rsp),%xmm2
  9e68c0:	movss  %xmm0,0x160(%rsp)
  9e68c9:	movss  %xmm1,0x164(%rsp)
  9e68d2:	movsd  0x160(%rsp),%xmm0
  9e68db:	movzbl 0x82(%rsp),%esi
  9e68e3:	mov    %sil,0x102(%rsp)
  9e68eb:	movzwl 0x80(%rsp),%esi
  9e68f3:	mov    %si,0x100(%rsp)
  9e68fb:	lea    0x83(%rsp),%rsi
  9e6903:	movups (%rsi),%xmm1
  9e6906:	lea    0xdd(%rsp),%rdi
  9e690e:	movups %xmm1,-0x5(%rdi)
  9e6912:	movzbl 0x102(%rsp),%esi
  9e691a:	mov    %sil,-0x6(%rdi)
  9e691e:	movzwl 0x100(%rsp),%esi
  9e6926:	mov    %si,-0x8(%rdi)
  9e692a:	mov    %rax,0xb0(%rsp)
  9e6932:	movsd  %xmm0,0xb8(%rsp)
  9e693b:	movdqu %xmm2,0xc0(%rsp)
  9e6944:	mov    %ecx,0xd0(%rsp)
  9e694b:	mov    %dl,0xd4(%rsp)
  9e6952:	mov    0x18(%rsp),%rax
  9e6957:	mov    %rax,0x10(%rsp)
  9e695c:	jmp    9e6346 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x4c6>
  9e6961:	movdqa 0xf0(%rsp),%xmm2
  9e696a:	movd   %xmm2,%eax
  9e696e:	movzbl %ah,%eax
  9e6971:	lea    -0x853bac(%rip),%rcx        # 192dcc <anon.5e2c2cd338f183f0185d3116c074ef00.75.llvm.4553572696083558104+0x33f4>
  9e6978:	movslq (%rcx,%rax,4),%rax
  9e697c:	add    %rcx,%rax
  9e697f:	jmp    *%rax
  9e6981:	xorps  %xmm0,%xmm0
  9e6984:	ucomiss %xmm1,%xmm0
  9e6987:	jbe    9e69c5 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0xb45>
  9e6989:	mov    $0x100,%eax
  9e698e:	jmp    9e69c7 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0xb47>
  9e6990:	mov    $0x200,%eax
  9e6995:	xorps  %xmm1,%xmm1
  9e6998:	ucomiss %xmm0,%xmm1
  9e699b:	jbe    9e69c7 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0xb47>
  9e699d:	mov    $0x300,%eax
  9e69a2:	jmp    9e69c7 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0xb47>
  9e69a4:	mov    $0x300,%eax
  9e69a9:	xorps  %xmm1,%xmm1
  9e69ac:	ucomiss %xmm0,%xmm1
  9e69af:	jbe    9e69c7 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0xb47>
  9e69b1:	mov    $0x200,%eax
  9e69b6:	jmp    9e69c7 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0xb47>
  9e69b8:	mov    $0x100,%eax
  9e69bd:	xorps  %xmm0,%xmm0
  9e69c0:	ucomiss %xmm1,%xmm0
  9e69c3:	jbe    9e69c7 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0xb47>
  9e69c5:	xor    %eax,%eax
  9e69c7:	movdqa 0xf0(%rsp),%xmm0
  9e69d0:	movq   %xmm0,%rcx
  9e69d5:	movzbl %cl,%ecx
  9e69d8:	or     %ecx,%eax
  9e69da:	movd   %eax,%xmm0
  9e69de:	movdqa %xmm0,0xf0(%rsp)
  9e69e7:	mov    $0x9,%dl
  9e69e9:	jmp    9e6805 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0x985>
  9e69ee:	mov    0x140(%rsp),%rdi
  9e69f6:	call   *0xb466bc(%rip)        # 152d0b8 <_DYNAMIC+0xb20>
  9e69fc:	lea    0x1e8(%rsp),%rsi
  9e6a04:	mov    $0x380,%edx
  9e6a09:	mov    %rbx,%rdi
  9e6a0c:	call   *0xb45de6(%rip)        # 152c7f8 <memcpy@GLIBC_2.14>
  9e6a12:	mov    %rbx,%rax
  9e6a15:	add    $0x568,%rsp
  9e6a1c:	pop    %rbx
  9e6a1d:	pop    %r12
  9e6a1f:	pop    %r13
  9e6a21:	pop    %r14
  9e6a23:	pop    %r15
  9e6a25:	pop    %rbp
  9e6a26:	ret
  9e6a27:	lea    -0x853bec(%rip),%rdi        # 192e42 <anon.5e2c2cd338f183f0185d3116c074ef00.75.llvm.4553572696083558104+0x346a>
  9e6a2e:	lea    0xad38ab(%rip),%rdx        # 14ba2e0 <anon.22b410f5f50bcdcdab7a6d64ae00c059.1.llvm.15728315378587307982+0xd8>
  9e6a35:	mov    $0x21,%esi
  9e6a3a:	call   *0xb45ec8(%rip)        # 152c908 <_DYNAMIC+0x370>
  9e6a40:	lea    0xad3881(%rip),%rdi        # 14ba2c8 <anon.22b410f5f50bcdcdab7a6d64ae00c059.1.llvm.15728315378587307982+0xc0>
  9e6a47:	call   *0xb45dc3(%rip)        # 152c810 <_DYNAMIC+0x278>
  9e6a4d:	ud2
  9e6a4f:	jmp    9e6a78 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0xbf8>
  9e6a51:	jmp    9e6a53 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>+0xbd3>
  9e6a53:	mov    %rax,%rbx
  9e6a56:	lea    0x1a0(%rsp),%rdi
  9e6a5e:	call   9e7bd0 <core::ptr::drop_glue::<gpui::native::accessibility::Queued>>
  9e6a63:	lea    0x1e8(%rsp),%rdi
  9e6a6b:	call   9e6a90 <core::ptr::drop_glue::<[core::option::Option<core::result::Result<gpui::runtime::Commit, gpui::runtime::Error>>; 16]>>
  9e6a70:	mov    %rbx,%rdi
  9e6a73:	call   14b7130 <_Unwind_Resume@plt>
  9e6a78:	mov    %rax,%rbx
  9e6a7b:	lea    0x1e8(%rsp),%rdi
  9e6a83:	call   9e6a90 <core::ptr::drop_glue::<[core::option::Option<core::result::Result<gpui::runtime::Commit, gpui::runtime::Error>>; 16]>>
  9e6a88:	mov    %rbx,%rdi
  9e6a8b:	call   14b7130 <_Unwind_Resume@plt>


/tmp/gpui-a11y-owner-channel-captures/release-candidate/empty:     file format elf64-x86-64


Disassembly of section .text:

00000000009e8010 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>::{closure#2}>:
  9e8010:	mov    (%rdi),%rax
  9e8013:	movzbl 0x30(%rax),%ecx
  9e8017:	cmp    $0x2,%cl
  9e801a:	jne    9e801f <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>::{closure#2}+0xf>
  9e801c:	xor    %eax,%eax
  9e801e:	ret
  9e801f:	sub    $0x78,%rsp
  9e8023:	mov    0x8(%rdi),%rdx
  9e8027:	mov    0x10(%rdi),%rsi
  9e802b:	movups (%rax),%xmm0
  9e802e:	movups 0x10(%rax),%xmm1
  9e8032:	movups 0x20(%rax),%xmm2
  9e8036:	movaps %xmm2,0x60(%rsp)
  9e803b:	movaps %xmm1,0x50(%rsp)
  9e8040:	movaps %xmm0,0x40(%rsp)
  9e8045:	mov    %cl,0x70(%rsp)
  9e8049:	mov    0x31(%rax),%edi
  9e804c:	mov    0x34(%rax),%eax
  9e804f:	mov    %edi,0x71(%rsp)
  9e8053:	mov    %eax,0x74(%rsp)
  9e8057:	mov    0x30(%rsi),%rax
  9e805b:	mov    %rax,0x30(%rsp)
  9e8060:	movups (%rsi),%xmm0
  9e8063:	movups 0x10(%rsi),%xmm1
  9e8067:	movups 0x20(%rsi),%xmm2
  9e806b:	movaps %xmm2,0x20(%rsp)
  9e8070:	movaps %xmm1,0x10(%rsp)
  9e8075:	movaps %xmm0,(%rsp)
  9e8079:	mov    (%rdx),%rsi
  9e807c:	test   %rsi,%rsi
  9e807f:	je     9e8122 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>::{closure#2}+0x112>
  9e8085:	xor    %eax,%eax
  9e8087:	cmpb   $0x1,0x72c(%rsi)
  9e808e:	jne    9e8124 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>::{closure#2}+0x114>
  9e8094:	test   $0x1,%cl
  9e8097:	je     9e8124 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>::{closure#2}+0x114>
  9e809d:	testb  $0x1,0x30(%rsp)
  9e80a2:	je     9e80f0 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>::{closure#2}+0xe0>
  9e80a4:	mov    0x668(%rsi),%rdx
  9e80ab:	mov    0x670(%rsi),%r11
  9e80b2:	mov    0x680(%rsi),%rdi
  9e80b9:	lea    0x5b0(%rsi),%rcx
  9e80c0:	mov    (%rsp),%r9
  9e80c4:	mov    0x10(%rsp),%r10
  9e80c9:	mov    0x28(%rsp),%r8
  9e80ce:	test   %r11,%r11
  9e80d1:	je     9e80f5 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>::{closure#2}+0xe5>
  9e80d3:	xor    %eax,%eax
  9e80d5:	test   %r9,%r9
  9e80d8:	je     9e8124 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>::{closure#2}+0x114>
  9e80da:	cmp    %r9,(%rcx)
  9e80dd:	jne    9e8124 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>::{closure#2}+0x114>
  9e80df:	cmp    0x8(%rsp),%r11
  9e80e4:	jne    9e8124 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>::{closure#2}+0x114>
  9e80e6:	cmp    %r10,%rdx
  9e80e9:	jne    9e8124 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>::{closure#2}+0x114>
  9e80eb:	cmp    %r8,%rdi
  9e80ee:	je     9e8103 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>::{closure#2}+0xf3>
  9e80f0:	add    $0x78,%rsp
  9e80f4:	ret
  9e80f5:	xor    %r10,%rdx
  9e80f8:	or     %rdx,%r9
  9e80fb:	xor    %r8,%rdi
  9e80fe:	or     %r9,%rdi
  9e8101:	jne    9e8122 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>::{closure#2}+0x112>
  9e8103:	mov    0x678(%rsi),%rdi
  9e810a:	test   %rdi,%rdi
  9e810d:	je     9e8122 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>::{closure#2}+0x112>
  9e810f:	lea    0x40(%rsp),%rsi
  9e8114:	mov    %rsp,%rdx
  9e8117:	call   *0xb44a13(%rip)        # 152cb30 <_DYNAMIC+0x598>
  9e811d:	add    $0x78,%rsp
  9e8121:	ret
  9e8122:	xor    %eax,%eax
  9e8124:	add    $0x78,%rsp
  9e8128:	ret


/tmp/gpui-a11y-owner-channel-captures/release-candidate/empty:     file format elf64-x86-64


Disassembly of section .text:

0000000000a0e1c0 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>::{closure#3}>:
  a0e1c0:	push   %r14
  a0e1c2:	push   %rbx
  a0e1c3:	sub    $0xa8,%rsp
  a0e1ca:	mov    %rsi,%r14
  a0e1cd:	mov    %rdi,%rbx
  a0e1d0:	mov    (%rsi),%rax
  a0e1d3:	mov    (%rax),%rdx
  a0e1d6:	test   %rdx,%rdx
  a0e1d9:	je     a0e211 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>::{closure#3}+0x51>
  a0e1db:	mov    0x10(%r14),%rcx
  a0e1df:	testb  $0x1,(%rcx)
  a0e1e2:	jne    a0e211 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>::{closure#3}+0x51>
  a0e1e4:	mov    0x8(%rax),%rcx
  a0e1e8:	mov    0x20(%r14),%rsi
  a0e1ec:	mov    0x8(%r14),%rax
  a0e1f0:	mov    0x8(%rax),%r8
  a0e1f4:	mov    0x10(%rax),%r9
  a0e1f8:	lea    0x8(%rsp),%rdi
  a0e1fd:	push   0x18(%r14)
  a0e201:	push   0x30(%r14)
  a0e205:	call   *0xb1f275(%rip)        # 152d480 <_DYNAMIC+0xee8>
  a0e20b:	add    $0x10,%rsp
  a0e20f:	jmp    a0e27f <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>::{closure#3}+0xbf>
  a0e211:	mov    0x20(%r14),%rsi
  a0e215:	mov    0x38(%r14),%rax
  a0e219:	cmpb   $0x0,(%rax)
  a0e21c:	je     a0e270 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>::{closure#3}+0xb0>
  a0e21e:	mov    0x40(%r14),%rax
  a0e222:	mov    0x30(%rax),%rcx
  a0e226:	mov    %rcx,0xa0(%rsp)
  a0e22e:	movups (%rax),%xmm0
  a0e231:	movups 0x10(%rax),%xmm1
  a0e235:	movups 0x20(%rax),%xmm2
  a0e239:	movaps %xmm2,0x90(%rsp)
  a0e241:	movaps %xmm1,0x80(%rsp)
  a0e249:	movaps %xmm0,0x70(%rsp)
  a0e24e:	mov    0x28(%r14),%rax
  a0e252:	mov    0x30(%r14),%r9
  a0e256:	mov    0x8(%rax),%rcx
  a0e25a:	mov    0x10(%rax),%r8
  a0e25e:	lea    0x8(%rsp),%rdi
  a0e263:	lea    0x70(%rsp),%rdx
  a0e268:	call   *0xb1f21a(%rip)        # 152d488 <_DYNAMIC+0xef0>
  a0e26e:	jmp    a0e27f <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>::{closure#3}+0xbf>
  a0e270:	mov    0x30(%r14),%rdx
  a0e274:	lea    0x8(%rsp),%rdi
  a0e279:	call   *0xb1f211(%rip)        # 152d490 <_DYNAMIC+0xef8>
  a0e27f:	mov    0x48(%r14),%rdi
  a0e283:	mov    0x50(%r14),%rsi
  a0e287:	call   *0xb1f20b(%rip)        # 152d498 <_DYNAMIC+0xf00>
  a0e28d:	mov    0x58(%r14),%rax
  a0e291:	movb   $0x1,(%rax)
  a0e294:	mov    0x68(%rsp),%rax
  a0e299:	mov    %rax,0x60(%rbx)
  a0e29d:	movups 0x58(%rsp),%xmm0
  a0e2a2:	movups %xmm0,0x50(%rbx)
  a0e2a6:	movups 0x48(%rsp),%xmm0
  a0e2ab:	movups %xmm0,0x40(%rbx)
  a0e2af:	movups 0x8(%rsp),%xmm0
  a0e2b4:	movups 0x18(%rsp),%xmm1
  a0e2b9:	movups 0x28(%rsp),%xmm2
  a0e2be:	movups 0x38(%rsp),%xmm3
  a0e2c3:	movups %xmm3,0x30(%rbx)
  a0e2c7:	movups %xmm2,0x20(%rbx)
  a0e2cb:	movups %xmm1,0x10(%rbx)
  a0e2cf:	movups %xmm0,(%rbx)
  a0e2d2:	add    $0xa8,%rsp
  a0e2d9:	pop    %rbx
  a0e2da:	pop    %r14
  a0e2dc:	ret
  a0e2dd:	mov    %rax,%rbx
  a0e2e0:	lea    0x8(%rsp),%rdi
  a0e2e5:	call   a0cd40 <core::ptr::drop_glue::<accesskit::TreeUpdate>>
  a0e2ea:	mov    %rbx,%rdi
  a0e2ed:	call   14b7130 <_Unwind_Resume@plt>
  a0e2f2:	call   *0xb1e528(%rip)        # 152c820 <_DYNAMIC+0x288>


/tmp/gpui-a11y-owner-channel-captures/release-candidate/empty:     file format elf64-x86-64


Disassembly of section .text:

0000000000a1d7c0 <empty::main>:
  a1d7c0:	push   %r14
  a1d7c2:	push   %rbx
  a1d7c3:	sub    $0x98,%rsp
  a1d7ca:	mov    %rdi,%rbx
  a1d7cd:	call   *0xb0f005(%rip)        # 152c7d8 <_DYNAMIC+0x240>
  a1d7d3:	mov    $0x4,%edi
  a1d7d8:	mov    $0x1,%esi
  a1d7dd:	call   *0xb0effd(%rip)        # 152c7e0 <_DYNAMIC+0x248>
  a1d7e3:	test   %rax,%rax
  a1d7e6:	je     a1d858 <empty::main+0x98>
  a1d7e8:	movl   $0x49555047,(%rax)
  a1d7ee:	movq   $0x4,0x8(%rsp)
  a1d7f7:	mov    %rax,0x10(%rsp)
  a1d7fc:	movq   $0x4,0x18(%rsp)
  a1d805:	movabs $0x25800000320,%rax
  a1d80f:	mov    %rax,0x20(%rsp)
  a1d814:	movq   $0x0,0x28(%rsp)
  a1d81d:	movq   $0x0,0x38(%rsp)
  a1d826:	movw   $0x0,0x48(%rsp)
  a1d82d:	lea    0x50(%rsp),%r14
  a1d832:	lea    0x8(%rsp),%rsi
  a1d837:	mov    %r14,%rdi
  a1d83a:	call   a41770 <empty::renderer::configure::<empty::Empty>>
  a1d83f:	mov    %rbx,%rdi
  a1d842:	mov    %r14,%rsi
  a1d845:	call   a410e0 <<gpui::application::Application>::run_window::<empty::Empty, ()>>
  a1d84a:	mov    %rbx,%rax
  a1d84d:	add    $0x98,%rsp
  a1d854:	pop    %rbx
  a1d855:	pop    %r14
  a1d857:	ret
  a1d858:	mov    $0x1,%edi
  a1d85d:	mov    $0x4,%esi
  a1d862:	call   *0xb0f060(%rip)        # 152c8c8 <_DYNAMIC+0x330>


/tmp/gpui-a11y-owner-channel-captures/release-candidate/empty:     file format elf64-x86-64


Disassembly of section .text:

0000000000a2aa20 <<gpui::native::NativeHost<empty::Empty>>::present_cpu>:
  a2aa20:	push   %rbp
  a2aa21:	push   %r15
  a2aa23:	push   %r14
  a2aa25:	push   %r13
  a2aa27:	push   %r12
  a2aa29:	push   %rbx
  a2aa2a:	sub    $0xe8,%rsp
  a2aa31:	testb  $0x1,0x188(%rsi)
  a2aa38:	je     a2af51 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x531>
  a2aa3e:	mov    %rsi,%r14
  a2aa41:	cmpq   $0x0,0x1d8(%rsi)
  a2aa49:	je     a2b098 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x678>
  a2aa4f:	cmpb   $0x0,(%r14)
  a2aa53:	je     a2b0b1 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x691>
  a2aa59:	mov    %edx,%ebp
  a2aa5b:	mov    %rdi,%rbx
  a2aa5e:	lea    0x8(%r14),%r12
  a2aa62:	mov    %rsp,%rdi
  a2aa65:	mov    %r12,%rsi
  a2aa68:	call   9ad890 <<gpui::runtime::Win<empty::Empty>>::with_scene::<core::result::Result<core::option::Option<(u32, gpui::runtime::PresentationToken)>, gpui_canvas::Error>, <gpui::native::NativeHost<empty::Empty>>::present_cpu::{closure#0}>>
  a2aa6d:	mov    (%rsp),%rdx
  a2aa71:	mov    0x8(%rsp),%ecx
  a2aa75:	mov    0xc(%rsp),%eax
  a2aa79:	mov    0x10(%rsp),%r13d
  a2aa7e:	cmp    $0xfffffffffffffffe,%rdx
  a2aa82:	jne    a2aa9d <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x7d>
  a2aa84:	test   $0x1,%cl
  a2aa87:	je     a2aac9 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0xa9>
  a2aa89:	movq   $0x23,0x8(%rbx)
  a2aa91:	mov    %eax,0x10(%rbx)
  a2aa94:	mov    %r13d,0x14(%rbx)
  a2aa98:	jmp    a2b07f <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x65f>
  a2aa9d:	mov    0x14(%rsp),%esi
  a2aaa1:	movups 0x28(%rsp),%xmm0
  a2aaa6:	movups %xmm0,0x30(%rbx)
  a2aaaa:	movups 0x18(%rsp),%xmm0
  a2aaaf:	mov    %rdx,0x8(%rbx)
  a2aab3:	mov    %ecx,0x10(%rbx)
  a2aab6:	mov    %eax,0x14(%rbx)
  a2aab9:	mov    %r13d,0x18(%rbx)
  a2aabd:	mov    %esi,0x1c(%rbx)
  a2aac0:	movups %xmm0,0x20(%rbx)
  a2aac4:	jmp    a2b07f <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x65f>
  a2aac9:	lea    0x18a(%r14),%r15
  a2aad0:	mov    0x18(%rsp),%rax
  a2aad5:	mov    %rax,0xc0(%rsp)
  a2aadd:	test   %rax,%rax
  a2aae0:	je     a2abbe <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x19e>
  a2aae6:	mov    0x20(%rsp),%rax
  a2aaeb:	mov    %rax,0x38(%rsp)
  a2aaf0:	call   a2a910 <<winit::window::Window>::pre_present_notify>
  a2aaf5:	cmp    $0x1000000,%r13d
  a2aafc:	jae    a2ac42 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x222>
  a2ab02:	mov    0x1a8(%r14),%rsi
  a2ab09:	lea    0x80(%rsp),%rdi
  a2ab11:	mov    %r13d,%edx
  a2ab14:	call   a08350 <<softbuffer::backends::x11::X11Impl<alloc::sync::Arc<winit::window::Window>, alloc::sync::Arc<winit::window::Window>> as softbuffer::backend_interface::SurfaceInterface<alloc::sync::Arc<winit::window::Window>, alloc::sync::Arc<winit::window::Window>>>::present_solid>
  a2ab19:	cmpl   $0xffffffff,0x80(%rsp)
  a2ab21:	jne    a2acad <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x28d>
  a2ab27:	cmpb   $0x1,0x84(%rsp)
  a2ab2f:	jne    a2abbe <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x19e>
  a2ab35:	mov    (%r12),%rsi
  a2ab39:	test   %rsi,%rsi
  a2ab3c:	je     a2b042 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x622>
  a2ab42:	mov    $0xe,%eax
  a2ab47:	cmpb   $0x1,0x72e(%rsi)
  a2ab4e:	je     a2b050 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x630>
  a2ab54:	mov    %rsp,%rdi
  a2ab57:	mov    0xc0(%rsp),%rdx
  a2ab5f:	mov    0x38(%rsp),%rcx
  a2ab64:	call   9c3210 <<gpui::runtime::Runtime<empty::Empty>>::acknowledge>
  a2ab69:	mov    (%rsp),%rax
  a2ab6d:	lea    0x8(%rsp),%rcx
  a2ab72:	cmp    $0xfffffffffffffffe,%rax
  a2ab76:	jne    a2b055 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x635>
  a2ab7c:	movups (%rcx),%xmm0
  a2ab7f:	movups 0x10(%rcx),%xmm1
  a2ab83:	movups 0x20(%rcx),%xmm2
  a2ab87:	movaps %xmm2,0x60(%rsp)
  a2ab8c:	movaps %xmm1,0x50(%rsp)
  a2ab91:	movaps %xmm0,0x40(%rsp)
  a2ab96:	movups %xmm2,0x28(%rbx)
  a2ab9a:	movups %xmm1,0x18(%rbx)
  a2ab9e:	movups %xmm0,0x8(%rbx)
  a2aba2:	xorps  %xmm0,%xmm0
  a2aba5:	movups %xmm0,0x9(%r15)
  a2abaa:	movups %xmm0,(%r15)
  a2abae:	movb   $0x0,0x38(%rbx)
  a2abb2:	movq   $0x0,(%rbx)
  a2abb9:	jmp    a2b086 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x666>
  a2abbe:	mov    0x1a8(%r14),%rsi
  a2abc5:	mov    %rsp,%rdi
  a2abc8:	call   a07b90 <<softbuffer::backends::x11::X11Impl<alloc::sync::Arc<winit::window::Window>, alloc::sync::Arc<winit::window::Window>> as softbuffer::backend_interface::SurfaceInterface<alloc::sync::Arc<winit::window::Window>, alloc::sync::Arc<winit::window::Window>>>::buffer_mut>
  a2abcd:	mov    (%rsp),%eax
  a2abd0:	cmp    $0xffffffff,%eax
  a2abd3:	je     a2ad4e <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x32e>
  a2abd9:	mov    0x4(%rsp),%ecx
  a2abdd:	mov    0x8(%rsp),%rdx
  a2abe2:	mov    0x30(%rsp),%rsi
  a2abe7:	mov    %rsi,0x70(%rsp)
  a2abec:	movups 0x20(%rsp),%xmm0
  a2abf1:	movups %xmm0,0x60(%rsp)
  a2abf6:	movups 0x10(%rsp),%xmm0
  a2abfb:	movups %xmm0,0x50(%rsp)
  a2ac00:	mov    %eax,0x40(%rsp)
  a2ac04:	mov    %ecx,0x44(%rsp)
  a2ac08:	mov    %rdx,0x48(%rsp)
  a2ac0d:	mov    %rsp,%rdi
  a2ac10:	lea    0x40(%rsp),%rsi
  a2ac15:	call   a29de0 <gpui::native::platform::<softbuffer::error::SoftBufferError>>
  a2ac1a:	movups (%rsp),%xmm0
  a2ac1e:	movups 0x10(%rsp),%xmm1
  a2ac23:	movups 0x20(%rsp),%xmm2
  a2ac28:	movups %xmm1,0x18(%rbx)
  a2ac2c:	movups %xmm2,0x28(%rbx)
  a2ac30:	mov    0x30(%rsp),%rax
  a2ac35:	mov    %rax,0x38(%rbx)
  a2ac39:	movups %xmm0,0x8(%rbx)
  a2ac3d:	jmp    a2b07f <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x65f>
  a2ac42:	call   *0xb01b90(%rip)        # 152c7d8 <_DYNAMIC+0x240>
  a2ac48:	mov    $0x1e,%edi
  a2ac4d:	mov    $0x1,%esi
  a2ac52:	call   *0xb01b88(%rip)        # 152c7e0 <_DYNAMIC+0x248>
  a2ac58:	test   %rax,%rax
  a2ac5b:	je     a2b10b <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x6eb>
  a2ac61:	movups -0x891862(%rip),%xmm0        # 199406 <anon.8ab91c69c891d30a22081c9a52c90deb.61.llvm.12414315633404053764+0xe>
  a2ac68:	movups %xmm0,0xe(%rax)
  a2ac6c:	movups -0x89187b(%rip),%xmm0        # 1993f8 <anon.8ab91c69c891d30a22081c9a52c90deb.61.llvm.12414315633404053764>
  a2ac73:	movups %xmm0,(%rax)
  a2ac76:	movl   $0x17,0x80(%rsp)
  a2ac81:	movq   $0x1e,0x88(%rsp)
  a2ac8d:	mov    %rax,0x90(%rsp)
  a2ac95:	movq   $0x1e,0x98(%rsp)
  a2aca1:	movq   $0x0,0xa0(%rsp)
  a2acad:	mov    0xb0(%rsp),%rax
  a2acb5:	mov    %rax,0x70(%rsp)
  a2acba:	mov    0x80(%rsp),%eax
  a2acc1:	mov    0x84(%rsp),%ecx
  a2acc8:	mov    0x88(%rsp),%rdx
  a2acd0:	mov    0x90(%rsp),%rsi
  a2acd8:	mov    0x98(%rsp),%rdi
  a2ace0:	mov    0xa0(%rsp),%r8
  a2ace8:	mov    %r8,0x60(%rsp)
  a2aced:	mov    0xa8(%rsp),%r8
  a2acf5:	mov    %r8,0x68(%rsp)
  a2acfa:	mov    %rsi,0x50(%rsp)
  a2acff:	mov    %rdi,0x58(%rsp)
  a2ad04:	mov    %eax,0x40(%rsp)
  a2ad08:	mov    %ecx,0x44(%rsp)
  a2ad0c:	mov    %rdx,0x48(%rsp)
  a2ad11:	mov    %rsp,%rdi
  a2ad14:	lea    0x40(%rsp),%rsi
  a2ad19:	call   a29de0 <gpui::native::platform::<softbuffer::error::SoftBufferError>>
  a2ad1e:	mov    (%rsp),%rax
  a2ad22:	movzbl 0x8(%rsp),%ecx
  a2ad27:	movups 0x28(%rsp),%xmm0
  a2ad2c:	movups %xmm0,0x30(%rbx)
  a2ad30:	movups 0x19(%rsp),%xmm0
  a2ad35:	movups %xmm0,0x21(%rbx)
  a2ad39:	movups 0x9(%rsp),%xmm0
  a2ad3e:	movups %xmm0,0x11(%rbx)
  a2ad42:	mov    %rax,0x8(%rbx)
  a2ad46:	mov    %cl,0x10(%rbx)
  a2ad49:	jmp    a2b07f <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x65f>
  a2ad4e:	mov    0x8(%rsp),%r13
  a2ad53:	movzbl 0x50(%r13),%eax
  a2ad58:	cmpl   $0x2,0x0(%r13)
  a2ad5d:	jne    a2ad73 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x353>
  a2ad5f:	mov    0x10(%r13),%rcx
  a2ad63:	mov    %rcx,0x78(%rsp)
  a2ad68:	mov    0x18(%r13),%rcx
  a2ad6c:	mov    %rcx,0x38(%rsp)
  a2ad71:	jmp    a2adc3 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x3a3>
  a2ad73:	mov    0x10(%r13),%rcx
  a2ad77:	test   %rcx,%rcx
  a2ad7a:	je     a2adb0 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x390>
  a2ad7c:	mov    0x18(%r13),%rdx
  a2ad80:	mov    0x20(%r13),%rsi
  a2ad84:	cmp    %rdx,%rsi
  a2ad87:	ja     a2b0ca <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x6aa>
  a2ad8d:	test   $0x3,%cl
  a2ad90:	jne    a2b11b <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x6fb>
  a2ad96:	test   $0x3,%sil
  a2ad9a:	jne    a2b132 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x712>
  a2ada0:	mov    %rcx,0x78(%rsp)
  a2ada5:	shr    $0x2,%rsi
  a2ada9:	mov    %rsi,0x38(%rsp)
  a2adae:	jmp    a2adc3 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x3a3>
  a2adb0:	mov    $0x4,%ecx
  a2adb5:	mov    %rcx,0x78(%rsp)
  a2adba:	movq   $0x0,0x38(%rsp)
  a2adc3:	movzbl %al,%edx
  a2adc6:	mov    %rsp,%rdi
  a2adc9:	mov    %r15,%rsi
  a2adcc:	call   *0xb02aee(%rip)        # 152d8c0 <_DYNAMIC+0x1328>
  a2add2:	mov    (%r12),%r14
  a2add6:	test   %r14,%r14
  a2add9:	je     a2adef <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x3cf>
  a2addb:	cmpb   $0x0,0x72e(%r14)
  a2ade3:	je     a2adfb <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x3db>
  a2ade5:	mov    $0xe,%eax
  a2adea:	jmp    a2ae9c <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x47c>
  a2adef:	mov    $0xd,%eax
  a2adf4:	xor    %edx,%edx
  a2adf6:	jmp    a2ae9c <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x47c>
  a2adfb:	mov    0x690(%r14),%rax
  a2ae02:	test   %rax,%rax
  a2ae05:	je     a2ae1a <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x3fa>
  a2ae07:	cmpq   $0xffffffffffffffff,0x588(%r14)
  a2ae0f:	je     a2ae21 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x401>
  a2ae11:	mov    0x5a0(%r14),%rsi
  a2ae18:	jmp    a2ae23 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x403>
  a2ae1a:	mov    $0x14,%eax
  a2ae1f:	jmp    a2ae9c <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x47c>
  a2ae21:	xor    %esi,%esi
  a2ae23:	mov    %rax,0xe0(%rsp)
  a2ae2b:	mov    0x698(%r14),%rax
  a2ae32:	mov    %rax,0xd8(%rsp)
  a2ae3a:	cmpw   $0x1,(%rsp)
  a2ae3f:	mov    %rsi,0xb8(%rsp)
  a2ae47:	jne    a2ae53 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x433>
  a2ae49:	cmpb   $0x0,0x72d(%r14)
  a2ae51:	je     a2ae68 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x448>
  a2ae53:	mov    %r14,%rdi
  a2ae56:	mov    0x78(%rsp),%rsi
  a2ae5b:	mov    0x38(%rsp),%rdx
  a2ae60:	call   *0xb01d22(%rip)        # 152cb88 <_DYNAMIC+0x5f0>
  a2ae66:	jmp    a2ae89 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x469>
  a2ae68:	mov    0x2(%rsp),%rdi
  a2ae6d:	call   *0xb01ba5(%rip)        # 152ca18 <_DYNAMIC+0x480>
  a2ae73:	mov    %r14,%rdi
  a2ae76:	mov    0x78(%rsp),%rsi
  a2ae7b:	mov    0x38(%rsp),%rdx
  a2ae80:	mov    %rax,%rcx
  a2ae83:	call   *0xb01d07(%rip)        # 152cb90 <_DYNAMIC+0x5f8>
  a2ae89:	cmp    $0xffffffff,%eax
  a2ae8c:	je     a2aea9 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x489>
  a2ae8e:	mov    %eax,%eax
  a2ae90:	shl    $0x20,%rdx
  a2ae94:	or     %rax,%rdx
  a2ae97:	mov    $0x23,%eax
  a2ae9c:	mov    %rax,0x8(%rbx)
  a2aea0:	mov    %rdx,0x10(%rbx)
  a2aea4:	jmp    a2b07f <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x65f>
  a2aea9:	mov    0xc0(%rsp),%r14
  a2aeb1:	test   %r14,%r14
  a2aeb4:	jne    a2aebb <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x49b>
  a2aeb6:	call   a2a910 <<winit::window::Window>::pre_present_notify>
  a2aebb:	test   %bpl,%bpl
  a2aebe:	je     a2aed2 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x4b2>
  a2aec0:	lea    0x40(%rsp),%rdi
  a2aec5:	mov    %r13,%rsi
  a2aec8:	call   a0a9a0 <<softbuffer::backends::x11::BufferImpl<alloc::sync::Arc<winit::window::Window>, alloc::sync::Arc<winit::window::Window>> as softbuffer::backend_interface::BufferInterface>::present>
  a2aecd:	jmp    a2af7e <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x55e>
  a2aed2:	lea    0x80(%rsp),%rdi
  a2aeda:	mov    0xb8(%rsp),%rsi
  a2aee2:	call   *0xb029e0(%rip)        # 152d8c8 <_DYNAMIC+0x1330>
  a2aee8:	cmpb   $0x0,0x80(%rsp)
  a2aef0:	je     a2af6a <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x54a>
  a2aef2:	mov    0x84(%rsp),%eax
  a2aef9:	mov    0x8c(%rsp),%ecx
  a2af00:	sub    %eax,%ecx
  a2af02:	je     a2b0d9 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x6b9>
  a2af08:	mov    0x88(%rsp),%edx
  a2af0f:	mov    0x90(%rsp),%esi
  a2af16:	sub    %edx,%esi
  a2af18:	je     a2b0f2 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x6d2>
  a2af1e:	mov    %ecx,0xc8(%rsp)
  a2af25:	mov    %esi,0xcc(%rsp)
  a2af2c:	mov    %eax,0xd0(%rsp)
  a2af33:	mov    %edx,0xd4(%rsp)
  a2af3a:	lea    0x40(%rsp),%rdi
  a2af3f:	lea    0xc8(%rsp),%rdx
  a2af47:	mov    $0x1,%ecx
  a2af4c:	mov    %r13,%rsi
  a2af4f:	jmp    a2af79 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x559>
  a2af51:	lea    -0x895d05(%rip),%rdi        # 195253 <anon.41931c7f01a0f669fcd75d8bc79f57d6.412.llvm.13234298307199123836+0x341>
  a2af58:	lea    0xa91ef9(%rip),%rdx        # 14bce58 <anon.fff2d4355c6109bc0e8af2445443084d.8.llvm.4725208967334239140+0x150>
  a2af5f:	mov    $0xb7,%esi
  a2af64:	call   *0xb018be(%rip)        # 152c828 <_DYNAMIC+0x290>
  a2af6a:	lea    0x40(%rsp),%rdi
  a2af6f:	mov    $0x4,%edx
  a2af74:	mov    %r13,%rsi
  a2af77:	xor    %ecx,%ecx
  a2af79:	call   a09f90 <<softbuffer::backends::x11::BufferImpl<alloc::sync::Arc<winit::window::Window>, alloc::sync::Arc<winit::window::Window>> as softbuffer::backend_interface::BufferInterface>::present_with_damage>
  a2af7e:	cmpl   $0xffffffff,0x40(%rsp)
  a2af83:	je     a2afbd <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x59d>
  a2af85:	mov    0x70(%rsp),%rax
  a2af8a:	mov    %rax,0x30(%rsp)
  a2af8f:	movups 0x40(%rsp),%xmm0
  a2af94:	movups 0x50(%rsp),%xmm1
  a2af99:	movups 0x60(%rsp),%xmm2
  a2af9e:	movaps %xmm2,0x20(%rsp)
  a2afa3:	movaps %xmm1,0x10(%rsp)
  a2afa8:	movaps %xmm0,(%rsp)
  a2afac:	lea    0x8(%rbx),%rdi
  a2afb0:	mov    %rsp,%rsi
  a2afb3:	call   a29de0 <gpui::native::platform::<softbuffer::error::SoftBufferError>>
  a2afb8:	jmp    a2b07f <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x65f>
  a2afbd:	mov    (%r12),%rsi
  a2afc1:	test   %rsi,%rsi
  a2afc4:	je     a2b042 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x622>
  a2afc6:	mov    $0xe,%eax
  a2afcb:	cmpb   $0x1,0x72e(%rsi)
  a2afd2:	je     a2b050 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x630>
  a2afd4:	mov    %rsp,%rdi
  a2afd7:	mov    0xe0(%rsp),%rdx
  a2afdf:	mov    0xd8(%rsp),%rcx
  a2afe7:	call   9c3210 <<gpui::runtime::Runtime<empty::Empty>>::acknowledge>
  a2afec:	mov    (%rsp),%rax
  a2aff0:	lea    0x8(%rsp),%rcx
  a2aff5:	cmp    $0xfffffffffffffffe,%rax
  a2aff9:	jne    a2b055 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x635>
  a2affb:	movups (%rcx),%xmm0
  a2affe:	movups 0x10(%rcx),%xmm1
  a2b002:	movups 0x20(%rcx),%xmm2
  a2b006:	movaps %xmm2,0x60(%rsp)
  a2b00b:	movaps %xmm1,0x50(%rsp)
  a2b010:	movaps %xmm0,0x40(%rsp)
  a2b015:	movups %xmm2,0x28(%rbx)
  a2b019:	movups %xmm1,0x18(%rbx)
  a2b01d:	movups %xmm0,0x8(%rbx)
  a2b021:	mov    %r15,%rdi
  a2b024:	mov    0xb8(%rsp),%rsi
  a2b02c:	call   *0xb0289e(%rip)        # 152d8d0 <_DYNAMIC+0x1338>
  a2b032:	test   %r14,%r14
  a2b035:	sete   0x38(%rbx)
  a2b039:	movq   $0x0,(%rbx)
  a2b040:	jmp    a2b086 <<gpui::native::NativeHost<empty::Empty>>::present_cpu+0x666>
  a2b042:	movq   $0x0,0x8(%rsp)
  a2b04b:	mov    $0xd,%eax
  a2b050:	lea    0x8(%rsp),%rcx
  a2b055:	movups (%rcx),%xmm0
  a2b058:	movups 0x10(%rcx),%xmm1
  a2b05c:	movups 0x20(%rcx),%xmm2
  a2b060:	movaps %xmm2,0x60(%rsp)
  a2b065:	movaps %xmm1,0x50(%rsp)
  a2b06a:	movaps %xmm0,0x40(%rsp)
  a2b06f:	movups %xmm2,0x30(%rbx)
  a2b073:	movups %xmm1,0x20(%rbx)
  a2b077:	movups %xmm0,0x10(%rbx)
  a2b07b:	mov    %rax,0x8(%rbx)
  a2b07f:	movq   $0x1,(%rbx)
  a2b086:	add    $0xe8,%rsp
  a2b08d:	pop    %rbx
  a2b08e:	pop    %r12
  a2b090:	pop    %r13
  a2b092:	pop    %r14
  a2b094:	pop    %r15
  a2b096:	pop    %rbp
  a2b097:	ret
  a2b098:	lea    -0x895e83(%rip),%rdi        # 19521c <anon.41931c7f01a0f669fcd75d8bc79f57d6.412.llvm.13234298307199123836+0x30a>
  a2b09f:	lea    0xa91d52(%rip),%rdx        # 14bcdf8 <anon.fff2d4355c6109bc0e8af2445443084d.8.llvm.4725208967334239140+0xf0>
  a2b0a6:	mov    $0x14,%esi
  a2b0ab:	call   *0xb01857(%rip)        # 152c908 <_DYNAMIC+0x370>
  a2b0b1:	lea    -0x895e88(%rip),%rdi        # 195230 <anon.41931c7f01a0f669fcd75d8bc79f57d6.412.llvm.13234298307199123836+0x31e>
  a2b0b8:	lea    0xa91d51(%rip),%rdx        # 14bce10 <anon.fff2d4355c6109bc0e8af2445443084d.8.llvm.4725208967334239140+0x108>
  a2b0bf:	mov    $0x14,%esi
  a2b0c4:	call   *0xb0183e(%rip)        # 152c908 <_DYNAMIC+0x370>
  a2b0ca:	lea    0xa91cd7(%rip),%rcx        # 14bcda8 <anon.fff2d4355c6109bc0e8af2445443084d.8.llvm.4725208967334239140+0xa0>
  a2b0d1:	xor    %edi,%edi
  a2b0d3:	call   *0xb0173f(%rip)        # 152c818 <_DYNAMIC+0x280>
  a2b0d9:	lea    -0x895e9c(%rip),%rdi        # 195244 <anon.41931c7f01a0f669fcd75d8bc79f57d6.412.llvm.13234298307199123836+0x332>
  a2b0e0:	lea    0xa91d41(%rip),%rdx        # 14bce28 <anon.fff2d4355c6109bc0e8af2445443084d.8.llvm.4725208967334239140+0x120>
  a2b0e7:	mov    $0xf,%esi
  a2b0ec:	call   *0xb01816(%rip)        # 152c908 <_DYNAMIC+0x370>
  a2b0f2:	lea    -0x895eb5(%rip),%rdi        # 195244 <anon.41931c7f01a0f669fcd75d8bc79f57d6.412.llvm.13234298307199123836+0x332>
  a2b0f9:	lea    0xa91d40(%rip),%rdx        # 14bce40 <anon.fff2d4355c6109bc0e8af2445443084d.8.llvm.4725208967334239140+0x138>
  a2b100:	mov    $0xf,%esi
  a2b105:	call   *0xb017fd(%rip)        # 152c908 <_DYNAMIC+0x370>
  a2b10b:	mov    $0x1,%edi
  a2b110:	mov    $0x1e,%esi
  a2b115:	call   *0xb017ad(%rip)        # 152c8c8 <_DYNAMIC+0x330>
  a2b11b:	xor    %eax,%eax
  a2b11d:	movzbl %al,%edx
  a2b120:	lea    -0x895f19(%rip),%rdi        # 19520e <anon.41931c7f01a0f669fcd75d8bc79f57d6.412.llvm.13234298307199123836+0x2fc>
  a2b127:	mov    $0xe,%esi
  a2b12c:	call   *0xb027a6(%rip)        # 152d8d8 <_DYNAMIC+0x1340>
  a2b132:	mov    $0x1,%al
  a2b134:	movzbl %al,%edx
  a2b137:	lea    -0x895f30(%rip),%rdi        # 19520e <anon.41931c7f01a0f669fcd75d8bc79f57d6.412.llvm.13234298307199123836+0x2fc>
  a2b13e:	mov    $0xe,%esi
  a2b143:	call   *0xb0278f(%rip)        # 152d8d8 <_DYNAMIC+0x1340>


/tmp/gpui-a11y-owner-channel-captures/release-candidate/empty:     file format elf64-x86-64


Disassembly of section .text:

0000000000a2b150 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade>:
  a2b150:	push   %rbp
  a2b151:	push   %r15
  a2b153:	push   %r14
  a2b155:	push   %r13
  a2b157:	push   %r12
  a2b159:	push   %rbx
  a2b15a:	sub    $0x248,%rsp
  a2b161:	mov    %rdi,%rbx
  a2b164:	cmpl   $0xffffffff,0x30(%rsi)
  a2b168:	je     a2b1f9 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0xa9>
  a2b16e:	mov    %rsi,%r15
  a2b171:	mov    0x1d8(%rsi),%rax
  a2b178:	test   %rax,%rax
  a2b17b:	je     a2b880 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x730>
  a2b181:	lock incq (%rax)
  a2b185:	jle    a2b8b2 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x762>
  a2b18b:	mov    %rax,0x8(%rsp)
  a2b190:	cmpl   $0xffffffff,0x10(%r15)
  a2b195:	je     a2b209 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0xb9>
  a2b197:	mov    0x28(%r15),%r14
  a2b19b:	lock incq (%r14)
  a2b19f:	jle    a2b8b2 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x762>
  a2b1a5:	mov    %r14,0x1f0(%rsp)
  a2b1ad:	mov    0x10(%r15),%rax
  a2b1b1:	mov    0x18(%r15),%rcx
  a2b1b5:	test   %rax,%rax
  a2b1b8:	je     a2b413 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x2c3>
  a2b1be:	cmp    $0x1,%eax
  a2b1c1:	jne    a2b42c <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x2dc>
  a2b1c7:	lock incq 0x180(%rcx)
  a2b1cf:	jle    a2b421 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x2d1>
  a2b1d5:	mov    0x20(%r15),%rdx
  a2b1d9:	lock incq (%rdx)
  a2b1dd:	jle    a2b8b2 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x762>
  a2b1e3:	mov    %rax,0x30(%rsp)
  a2b1e8:	mov    %rcx,0x38(%rsp)
  a2b1ed:	mov    %rdx,0x40(%rsp)
  a2b1f2:	mov    %r14,0x48(%rsp)
  a2b1f7:	jmp    a2b212 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0xc2>
  a2b1f9:	movb   $0x0,0x8(%rbx)
  a2b1fd:	movq   $0xfffffffffffffffe,(%rbx)
  a2b204:	jmp    a2b401 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x2b1>
  a2b209:	movq   $0xffffffffffffffff,0x30(%rsp)
  a2b212:	lea    0x30(%r15),%r12
  a2b216:	lea    0x130(%rsp),%rdi
  a2b21e:	lea    0x8(%rsp),%rdx
  a2b223:	lea    0x30(%rsp),%rcx
  a2b228:	mov    %r12,%rsi
  a2b22b:	call   *0xb026af(%rip)        # 152d8e0 <_DYNAMIC+0x1348>
  a2b231:	mov    0x130(%rsp),%r14
  a2b239:	movabs $0x8000000000000000,%rcx
  a2b243:	xor    %r14,%rcx
  a2b246:	test   %r14,%r14
  a2b249:	mov    $0x2,%eax
  a2b24e:	cmovs  %rcx,%rax
  a2b252:	test   %rax,%rax
  a2b255:	je     a2b3a5 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x255>
  a2b25b:	cmp    $0x1,%rax
  a2b25f:	jne    a2b3b2 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x262>
  a2b265:	mov    0x138(%rsp),%r14
  a2b26d:	mov    0x140(%rsp),%rax
  a2b275:	mov    %r14,0x190(%rsp)
  a2b27d:	mov    %rax,(%rsp)
  a2b281:	mov    %rax,0x198(%rsp)
  a2b289:	mov    %r12,%rdi
  a2b28c:	call   a26480 <core::ptr::drop_glue::<core::option::Option<gpui::native::upgrade::Upgrade>>>
  a2b291:	movq   $0xffffffffffffffff,0x30(%r15)
  a2b299:	mov    %r14,0x18(%rsp)
  a2b29e:	movb   $0x1,0x205(%r15)
  a2b2a6:	mov    0x8(%rsp),%rdi
  a2b2ab:	add    $0x10,%rdi
  a2b2af:	call   a2d930 <<winit::window::Window>::inner_size>
  a2b2b4:	cmpl   $0x1,(%r15)
  a2b2b8:	jne    a2b899 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x749>
  a2b2be:	mov    %eax,%ebp
  a2b2c0:	mov    %edx,%r13d
  a2b2c3:	mov    (%rsp),%rax
  a2b2c7:	mov    0x3d8(%rax),%rsi
  a2b2ce:	add    $0x10,%rsi
  a2b2d2:	lea    0x30(%rsp),%rdi
  a2b2d7:	call   *0xb0260b(%rip)        # 152d8e8 <_DYNAMIC+0x1350>
  a2b2dd:	mov    0x30(%rsp),%rsi
  a2b2e2:	cmp    $0xfffffffffffffffe,%rsi
  a2b2e6:	je     a2b439 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x2e9>
  a2b2ec:	cmp    $0xffffffffffffffff,%rsi
  a2b2f0:	je     a2b307 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x1b7>
  a2b2f2:	test   %rsi,%rsi
  a2b2f5:	je     a2b307 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x1b7>
  a2b2f7:	mov    0x38(%rsp),%rdi
  a2b2fc:	mov    $0x1,%edx
  a2b301:	call   *0xb014e1(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  a2b307:	mov    $0x2f,%r13d
  a2b30d:	mov    %r13,0x30(%rsp)
  a2b312:	movlps %xmm0,0x38(%rsp)
  a2b317:	mov    %rbp,0x40(%rsp)
  a2b31c:	mov    %rax,0x48(%rsp)
  a2b321:	mov    %r12,0x50(%rsp)
  a2b326:	movaps 0x1e0(%rsp),%xmm0
  a2b32e:	movups %xmm0,0x58(%rsp)
  a2b333:	mov    (%rsp),%rdi
  a2b337:	call   a26d40 <core::ptr::drop_glue::<alloc::boxed::Box<gpui::native::GpuSurface>>>
  a2b33c:	mov    0x18(%rsp),%rax
  a2b341:	mov    %rax,0x130(%rsp)
  a2b349:	lock decq (%rax)
  a2b34d:	jne    a2b35d <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x20d>
  a2b34f:	lea    0x130(%rsp),%rdi
  a2b357:	call   *0xb01db3(%rip)        # 152d110 <_DYNAMIC+0xb78>
  a2b35d:	lea    0x30(%rsp),%rax
  a2b362:	mov    %rax,0x130(%rsp)
  a2b36a:	mov    0xb0257f(%rip),%rax        # 152d8f0 <_DYNAMIC+0x1358>
  a2b371:	mov    %rax,0x138(%rsp)
  a2b379:	lea    -0x8c2623(%rip),%rdi        # 168d5d <anon.41931c7f01a0f669fcd75d8bc79f57d6.134.llvm.13234298307199123836+0x5d>
  a2b380:	lea    0x130(%rsp),%rsi
  a2b388:	call   *0xb024d2(%rip)        # 152d860 <_DYNAMIC+0x12c8>
  a2b38e:	movb   $0x0,0x8(%rbx)
  a2b392:	movq   $0xfffffffffffffffe,(%rbx)
  a2b399:	lea    0x30(%rsp),%rdi
  a2b39e:	call   a28c80 <core::ptr::drop_glue::<gpui::native::NativeError>>
  a2b3a3:	jmp    a2b3eb <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x29b>
  a2b3a5:	movb   $0x0,0x8(%rbx)
  a2b3a9:	movq   $0xfffffffffffffffe,(%rbx)
  a2b3b0:	jmp    a2b3eb <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x29b>
  a2b3b2:	mov    0x138(%rsp),%r15
  a2b3ba:	mov    %r12,%rdi
  a2b3bd:	call   a26480 <core::ptr::drop_glue::<core::option::Option<gpui::native::upgrade::Upgrade>>>
  a2b3c2:	movq   $0xffffffffffffffff,(%r12)
  a2b3ca:	movb   $0x0,0x8(%rbx)
  a2b3ce:	movq   $0xfffffffffffffffe,(%rbx)
  a2b3d5:	test   %r14,%r14
  a2b3d8:	je     a2b3eb <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x29b>
  a2b3da:	mov    $0x1,%edx
  a2b3df:	mov    %r15,%rdi
  a2b3e2:	mov    %r14,%rsi
  a2b3e5:	call   *0xb013fd(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  a2b3eb:	mov    0x8(%rsp),%rax
  a2b3f0:	lock decq (%rax)
  a2b3f4:	jne    a2b401 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x2b1>
  a2b3f6:	lea    0x8(%rsp),%rdi
  a2b3fb:	call   *0xb01f7f(%rip)        # 152d380 <_DYNAMIC+0xde8>
  a2b401:	add    $0x248,%rsp
  a2b408:	pop    %rbx
  a2b409:	pop    %r12
  a2b40b:	pop    %r13
  a2b40d:	pop    %r14
  a2b40f:	pop    %r15
  a2b411:	pop    %rbp
  a2b412:	ret
  a2b413:	lock incq 0x200(%rcx)
  a2b41b:	jg     a2b1d5 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x85>
  a2b421:	call   *0xb01f09(%rip)        # 152d330 <_DYNAMIC+0xd98>
  a2b427:	jmp    a2b8b2 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x762>
  a2b42c:	lock incq 0x70(%rcx)
  a2b431:	jg     a2b1d5 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x85>
  a2b437:	jmp    a2b421 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x2d1>
  a2b439:	mov    (%rsp),%rax
  a2b43d:	lea    0x348(%rax),%r12
  a2b444:	lea    0x30(%rsp),%rdi
  a2b449:	mov    %r12,%rsi
  a2b44c:	call   *0xb024a6(%rip)        # 152d8f8 <_DYNAMIC+0x1360>
  a2b452:	mov    0x34(%rsp),%eax
  a2b456:	cmp    %eax,%ebp
  a2b458:	seta   %cl
  a2b45b:	cmp    %eax,%r13d
  a2b45e:	seta   %al
  a2b461:	or     %cl,%al
  a2b463:	je     a2b470 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x320>
  a2b465:	mov    $0x2e,%r13d
  a2b46b:	jmp    a2b30d <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x1bd>
  a2b470:	cmp    $0x1,%ebp
  a2b473:	adc    $0x0,%ebp
  a2b476:	cmp    $0x1,%r13d
  a2b47a:	adc    $0x0,%r13d
  a2b47e:	mov    (%rsp),%rcx
  a2b482:	mov    0x370(%rcx),%eax
  a2b488:	mov    %eax,0x1ac(%rsp)
  a2b48f:	mov    0x368(%rcx),%rax
  a2b496:	mov    %rax,0x1a4(%rsp)
  a2b49e:	movl   $0x10,0x1a0(%rsp)
  a2b4a9:	movl   $0x1,0x1b0(%rsp)
  a2b4b4:	mov    %ebp,0x1b4(%rsp)
  a2b4bb:	mov    %r13d,0x1b8(%rsp)
  a2b4c3:	movl   $0x2,0x1bc(%rsp)
  a2b4ce:	movl   $0x1,0x1c0(%rsp)
  a2b4d9:	movl   $0x1,0x1c4(%rsp)
  a2b4e4:	movq   $0x0,0x1c8(%rsp)
  a2b4f0:	movq   $0x4,0x1d0(%rsp)
  a2b4fc:	movq   $0x0,0x1d8(%rsp)
  a2b508:	lea    0x378(%rcx),%r13
  a2b50f:	lea    0x1a0(%rsp),%rdx
  a2b517:	mov    %r13,%rdi
  a2b51a:	mov    %r12,%rsi
  a2b51d:	call   *0xb023dd(%rip)        # 152d900 <_DYNAMIC+0x1368>
  a2b523:	lea    0x30(%rsp),%rdi
  a2b528:	mov    %r13,%rsi
  a2b52b:	call   *0xb023d7(%rip)        # 152d908 <_DYNAMIC+0x1370>
  a2b531:	mov    0x30(%rsp),%rax
  a2b536:	cmp    $0x1,%rax
  a2b53a:	je     a2b6ec <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x59c>
  a2b540:	test   %rax,%rax
  a2b543:	jne    a2b6f6 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x5a6>
  a2b549:	movups 0x88(%rsp),%xmm0
  a2b551:	movaps %xmm0,0x180(%rsp)
  a2b559:	movups 0x78(%rsp),%xmm0
  a2b55e:	movaps %xmm0,0x170(%rsp)
  a2b566:	movups 0x38(%rsp),%xmm0
  a2b56b:	movups 0x48(%rsp),%xmm1
  a2b570:	movups 0x58(%rsp),%xmm2
  a2b575:	movups 0x68(%rsp),%xmm3
  a2b57a:	movaps %xmm3,0x160(%rsp)
  a2b582:	movaps %xmm2,0x150(%rsp)
  a2b58a:	movaps %xmm1,0x140(%rsp)
  a2b592:	movaps %xmm0,0x130(%rsp)
  a2b59a:	lea    0x138(%rsp),%rsi
  a2b5a2:	movq   $0x0,0x48(%rsp)
  a2b5ab:	movl   $0xffffffff,0x60(%rsp)
  a2b5b3:	movl   $0x0,0x30(%rsp)
  a2b5bb:	movabs $0xffffffff00000000,%rax
  a2b5c5:	mov    %rax,0x58(%rsp)
  a2b5ca:	movq   $0x0,0x6c(%rsp)
  a2b5d3:	movl   $0x0,0x38(%rsp)
  a2b5db:	movl   $0x0,0x40(%rsp)
  a2b5e3:	lea    0x1f0(%rsp),%rdi
  a2b5eb:	lea    0x30(%rsp),%rdx
  a2b5f0:	call   *0xb0231a(%rip)        # 152d910 <_DYNAMIC+0x1378>
  a2b5f6:	lea    0x8(%r15),%rsi
  a2b5fa:	mov    $0x1,%r12b
  a2b5fd:	lea    0x30(%rsp),%rdi
  a2b602:	lea    0x1f0(%rsp),%rcx
  a2b60a:	mov    (%rsp),%rdx
  a2b60e:	call   9ad550 <<gpui::runtime::Win<empty::Empty>>::with_paint_scene::<core::result::Result<gpui::runtime::PresentationToken, gpui_gpu::renderer::Error>, <gpui::native::NativeHost<empty::Empty>>::try_upgrade::{closure#0}::{closure#0}>>
  a2b613:	mov    0x30(%rsp),%r13
  a2b618:	mov    0x40(%rsp),%rbp
  a2b61d:	movsd  0x38(%rsp),%xmm0
  a2b623:	movaps %xmm0,0x20(%rsp)
  a2b628:	mov    0x48(%rsp),%rax
  a2b62d:	mov    %rax,0x10(%rsp)
  a2b632:	mov    0x50(%rsp),%r12
  a2b637:	cmp    $0xfffffffffffffffe,%r13
  a2b63b:	jne    a2b6fe <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x5ae>
  a2b641:	mov    $0x2c,%r13d
  a2b647:	cmpl   $0xffffffff,0x38(%rsp)
  a2b64c:	jne    a2b70b <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x5bb>
  a2b652:	mov    $0x1,%r12b
  a2b655:	call   a2a910 <<winit::window::Window>::pre_present_notify>
  a2b65a:	mov    (%rsp),%rax
  a2b65e:	lea    0x350(%rax),%rdi
  a2b665:	movaps 0x180(%rsp),%xmm0
  a2b66d:	movaps %xmm0,0x80(%rsp)
  a2b675:	movaps 0x170(%rsp),%xmm0
  a2b67d:	movaps %xmm0,0x70(%rsp)
  a2b682:	movaps 0x130(%rsp),%xmm0
  a2b68a:	movaps 0x140(%rsp),%xmm1
  a2b692:	movaps 0x150(%rsp),%xmm2
  a2b69a:	movaps 0x160(%rsp),%xmm3
  a2b6a2:	movaps %xmm3,0x60(%rsp)
  a2b6a7:	movaps %xmm2,0x50(%rsp)
  a2b6ac:	movaps %xmm1,0x40(%rsp)
  a2b6b1:	movaps %xmm0,0x30(%rsp)
  a2b6b6:	xor    %r12d,%r12d
  a2b6b9:	lea    0x30(%rsp),%rsi
  a2b6be:	call   *0xb02254(%rip)        # 152d918 <_DYNAMIC+0x1380>
  a2b6c4:	lea    0x8(%r15),%rax
  a2b6c8:	mov    (%rax),%rsi
  a2b6cb:	test   %rsi,%rsi
  a2b6ce:	je     a2b75f <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x60f>
  a2b6d4:	cmpb   $0x0,0x72e(%rsi)
  a2b6db:	je     a2b778 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x628>
  a2b6e1:	mov    $0xe,%r13d
  a2b6e7:	jmp    a2b7b1 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x661>
  a2b6ec:	lea    0x38(%rsp),%rdi
  a2b6f1:	call   a28f20 <core::ptr::drop_glue::<wgpu::api::surface_texture::SurfaceTexture>>
  a2b6f6:	mov    $0x2f,%r13d
  a2b6fc:	jmp    a2b750 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x600>
  a2b6fe:	movups 0x58(%rsp),%xmm0
  a2b703:	movaps %xmm0,0x1e0(%rsp)
  a2b70b:	mov    0x1f0(%rsp),%rax
  a2b713:	lock decq (%rax)
  a2b717:	jne    a2b727 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x5d7>
  a2b719:	lea    0x1f0(%rsp),%rdi
  a2b721:	call   *0xb019c9(%rip)        # 152d0f0 <_DYNAMIC+0xb58>
  a2b727:	mov    0x1f8(%rsp),%rax
  a2b72f:	lock decq (%rax)
  a2b733:	jne    a2b743 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x5f3>
  a2b735:	lea    0x1f8(%rsp),%rdi
  a2b73d:	call   *0xb019a5(%rip)        # 152d0e8 <_DYNAMIC+0xb50>
  a2b743:	lea    0x130(%rsp),%rdi
  a2b74b:	call   a28f20 <core::ptr::drop_glue::<wgpu::api::surface_texture::SurfaceTexture>>
  a2b750:	mov    0x10(%rsp),%rax
  a2b755:	movaps 0x20(%rsp),%xmm0
  a2b75a:	jmp    a2b30d <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x1bd>
  a2b75f:	movq   $0xd,0x30(%rsp)
  a2b768:	xorps  %xmm0,%xmm0
  a2b76b:	movaps %xmm0,0x20(%rsp)
  a2b770:	mov    $0xd,%r13d
  a2b776:	jmp    a2b7b1 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x661>
  a2b778:	xor    %r12d,%r12d
  a2b77b:	lea    0x30(%rsp),%rdi
  a2b780:	mov    %rbp,%rdx
  a2b783:	mov    0x10(%rsp),%rcx
  a2b788:	call   9c3210 <<gpui::runtime::Runtime<empty::Empty>>::acknowledge>
  a2b78d:	mov    0x30(%rsp),%r13
  a2b792:	mov    0x40(%rsp),%rbp
  a2b797:	movsd  0x38(%rsp),%xmm0
  a2b79d:	movaps %xmm0,0x20(%rsp)
  a2b7a2:	mov    0x48(%rsp),%rax
  a2b7a7:	mov    %rax,0x10(%rsp)
  a2b7ac:	mov    0x50(%rsp),%r12
  a2b7b1:	movups 0x58(%rsp),%xmm0
  a2b7b6:	movaps %xmm0,0x1e0(%rsp)
  a2b7be:	lea    0x1f0(%rsp),%rdi
  a2b7c6:	call   a28eb0 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  a2b7cb:	cmp    $0xfffffffffffffffe,%r13
  a2b7cf:	jne    a2b750 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x600>
  a2b7d5:	mov    0x1d0(%r15),%rax
  a2b7dc:	test   %rax,%rax
  a2b7df:	je     a2b7f7 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x6a7>
  a2b7e1:	lock decq (%rax)
  a2b7e5:	jne    a2b7f7 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x6a7>
  a2b7e7:	lea    0x1d0(%r15),%rbp
  a2b7ee:	mov    %rbp,%rdi
  a2b7f1:	call   *0xb01919(%rip)        # 152d110 <_DYNAMIC+0xb78>
  a2b7f7:	mov    %r14,0x1d0(%r15)
  a2b7fe:	movzwl 0x188(%r15),%eax
  a2b806:	cmp    $0x2,%eax
  a2b809:	mov    0x10(%rsp),%r14
  a2b80e:	je     a2b82e <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x6de>
  a2b810:	test   %eax,%eax
  a2b812:	jne    a2b822 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x6d2>
  a2b814:	mov    0x190(%r15),%rdi
  a2b81b:	call   a26d40 <core::ptr::drop_glue::<alloc::boxed::Box<gpui::native::GpuSurface>>>
  a2b820:	jmp    a2b82e <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x6de>
  a2b822:	mov    0x1a8(%r15),%rdi
  a2b829:	call   a251b0 <core::ptr::drop_glue::<softbuffer::Surface<alloc::sync::Arc<winit::window::Window>, alloc::sync::Arc<winit::window::Window>>>>
  a2b82e:	movw   $0x0,0x188(%r15)
  a2b838:	mov    (%rsp),%rax
  a2b83c:	mov    %rax,0x190(%r15)
  a2b843:	movw   $0x0,0x208(%r15)
  a2b84d:	mov    0x1f0(%r15),%rdi
  a2b854:	test   %rdi,%rdi
  a2b857:	je     a2b877 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x727>
  a2b859:	mov    %r14,0x30(%rsp)
  a2b85e:	mov    %r12,0x38(%rsp)
  a2b863:	movb   $0x1,0x40(%rsp)
  a2b868:	mov    0x1f8(%r15),%rax
  a2b86f:	lea    0x30(%rsp),%rsi
  a2b874:	call   *0x20(%rax)
  a2b877:	movb   $0x1,0x8(%rbx)
  a2b87b:	jmp    a2b3a9 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x259>
  a2b880:	lea    -0x8965d9(%rip),%rdi        # 1952ae <anon.41931c7f01a0f669fcd75d8bc79f57d6.412.llvm.13234298307199123836+0x39c>
  a2b887:	lea    0xa915e2(%rip),%rdx        # 14bce70 <anon.fff2d4355c6109bc0e8af2445443084d.8.llvm.4725208967334239140+0x168>
  a2b88e:	mov    $0x14,%esi
  a2b893:	call   *0xb0106f(%rip)        # 152c908 <_DYNAMIC+0x370>
  a2b899:	lea    -0x8965de(%rip),%rdi        # 1952c2 <anon.41931c7f01a0f669fcd75d8bc79f57d6.412.llvm.13234298307199123836+0x3b0>
  a2b8a0:	lea    0xa915e1(%rip),%rdx        # 14bce88 <anon.fff2d4355c6109bc0e8af2445443084d.8.llvm.4725208967334239140+0x180>
  a2b8a7:	mov    $0x14,%esi
  a2b8ac:	call   *0xb01056(%rip)        # 152c908 <_DYNAMIC+0x370>
  a2b8b2:	ud2
  a2b8b4:	mov    %rax,%rbx
  a2b8b7:	mov    %r14,0x0(%rbp)
  a2b8bb:	xor    %ebp,%ebp
  a2b8bd:	jmp    a2b9d5 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x885>
  a2b8c2:	mov    %rax,%rbx
  a2b8c5:	jmp    a2ba12 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x8c2>
  a2b8ca:	mov    %rax,%rbx
  a2b8cd:	movw   $0x0,0x188(%r15)
  a2b8d7:	mov    (%rsp),%rax
  a2b8db:	mov    %rax,0x190(%r15)
  a2b8e2:	jmp    a2ba12 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x8c2>
  a2b8e7:	jmp    a2b9cf <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x87f>
  a2b8ec:	mov    %rax,%rbx
  a2b8ef:	mov    0x1f8(%rsp),%rax
  a2b8f7:	lock decq (%rax)
  a2b8fb:	jne    a2b934 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x7e4>
  a2b8fd:	lea    0x1f8(%rsp),%rdi
  a2b905:	call   *0xb017dd(%rip)        # 152d0e8 <_DYNAMIC+0xb50>
  a2b90b:	jmp    a2b934 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x7e4>
  a2b90d:	call   *0xb00f0d(%rip)        # 152c820 <_DYNAMIC+0x288>
  a2b913:	mov    %rax,%rbx
  a2b916:	jmp    a2b934 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x7e4>
  a2b918:	mov    %rax,%rbx
  a2b91b:	lea    0x1f0(%rsp),%rdi
  a2b923:	call   a28eb0 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  a2b928:	mov    $0x1,%bpl
  a2b92b:	test   %r12b,%r12b
  a2b92e:	je     a2b9d5 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x885>
  a2b934:	mov    $0x1,%bpl
  a2b937:	lea    0x130(%rsp),%rdi
  a2b93f:	call   a28f20 <core::ptr::drop_glue::<wgpu::api::surface_texture::SurfaceTexture>>
  a2b944:	jmp    a2b9d5 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x885>
  a2b949:	call   *0xb00ed1(%rip)        # 152c820 <_DYNAMIC+0x288>
  a2b94f:	jmp    a2b9cf <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x87f>
  a2b951:	mov    %rax,%rbx
  a2b954:	lea    0x30(%rsp),%rdi
  a2b959:	call   a28c80 <core::ptr::drop_glue::<gpui::native::NativeError>>
  a2b95e:	jmp    a2b9e3 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x893>
  a2b963:	mov    %rax,%rbx
  a2b966:	movq   $0xffffffffffffffff,(%r12)
  a2b96e:	test   %r14,%r14
  a2b971:	je     a2ba12 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x8c2>
  a2b977:	mov    $0x1,%edx
  a2b97c:	mov    %r15,%rdi
  a2b97f:	mov    %r14,%rsi
  a2b982:	call   *0xb00e60(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  a2b988:	jmp    a2ba12 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x8c2>
  a2b98d:	mov    %rax,%rbx
  a2b990:	movq   $0xffffffffffffffff,(%r12)
  a2b998:	lock decq (%r14)
  a2b99c:	jne    a2b9ac <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x85c>
  a2b99e:	lea    0x190(%rsp),%rdi
  a2b9a6:	call   *0xb01764(%rip)        # 152d110 <_DYNAMIC+0xb78>
  a2b9ac:	mov    0x198(%rsp),%rdi
  a2b9b4:	call   a26d40 <core::ptr::drop_glue::<alloc::boxed::Box<gpui::native::GpuSurface>>>
  a2b9b9:	jmp    a2ba12 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x8c2>
  a2b9bb:	mov    %rax,%rbx
  a2b9be:	lea    0x30(%rsp),%rdi
  a2b9c3:	call   a28c80 <core::ptr::drop_glue::<gpui::native::NativeError>>
  a2b9c8:	jmp    a2ba12 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x8c2>
  a2b9ca:	mov    %rax,%rbx
  a2b9cd:	jmp    a2ba12 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x8c2>
  a2b9cf:	mov    %rax,%rbx
  a2b9d2:	mov    $0x1,%bpl
  a2b9d5:	mov    (%rsp),%rdi
  a2b9d9:	call   a26d40 <core::ptr::drop_glue::<alloc::boxed::Box<gpui::native::GpuSurface>>>
  a2b9de:	test   %bpl,%bpl
  a2b9e1:	je     a2ba12 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x8c2>
  a2b9e3:	mov    0x18(%rsp),%rax
  a2b9e8:	lock decq (%rax)
  a2b9ec:	jne    a2ba12 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x8c2>
  a2b9ee:	lea    0x18(%rsp),%rdi
  a2b9f3:	call   *0xb01717(%rip)        # 152d110 <_DYNAMIC+0xb78>
  a2b9f9:	jmp    a2ba12 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x8c2>
  a2b9fb:	mov    %rax,%rbx
  a2b9fe:	lock decq (%r14)
  a2ba02:	jne    a2ba12 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x8c2>
  a2ba04:	lea    0x1f0(%rsp),%rdi
  a2ba0c:	call   *0xb01f0e(%rip)        # 152d920 <_DYNAMIC+0x1388>
  a2ba12:	mov    0x8(%rsp),%rax
  a2ba17:	lock decq (%rax)
  a2ba1b:	jne    a2ba28 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade+0x8d8>
  a2ba1d:	lea    0x8(%rsp),%rdi
  a2ba22:	call   *0xb01958(%rip)        # 152d380 <_DYNAMIC+0xde8>
  a2ba28:	mov    %rbx,%rdi
  a2ba2b:	call   14b7130 <_Unwind_Resume@plt>
  a2ba30:	call   *0xb00dea(%rip)        # 152c820 <_DYNAMIC+0x288>
  a2ba36:	call   *0xb00de4(%rip)        # 152c820 <_DYNAMIC+0x288>


/tmp/gpui-a11y-owner-channel-captures/release-candidate/empty:     file format elf64-x86-64


Disassembly of section .text:

0000000000a2ba40 <<gpui::native::NativeHost<empty::Empty>>::input_result>:
  a2ba40:	push   %rbx
  a2ba41:	sub    $0x50,%rsp
  a2ba45:	mov    %rdi,%rbx
  a2ba48:	mov    (%rdx),%rcx
  a2ba4b:	cmp    $0xfffffffffffffffe,%rcx
  a2ba4f:	jne    a2ba8f <<gpui::native::NativeHost<empty::Empty>>::input_result+0x4f>
  a2ba51:	cmpq   $0x0,0x8(%rdx)
  a2ba56:	je     a2bb63 <<gpui::native::NativeHost<empty::Empty>>::input_result+0x123>
  a2ba5c:	cmpb   $0x0,0x204(%rsi)
  a2ba63:	jne    a2bb63 <<gpui::native::NativeHost<empty::Empty>>::input_result+0x123>
  a2ba69:	mov    0x1d8(%rsi),%rdi
  a2ba70:	test   %rdi,%rdi
  a2ba73:	je     a2bb63 <<gpui::native::NativeHost<empty::Empty>>::input_result+0x123>
  a2ba79:	add    $0x10,%rdi
  a2ba7d:	call   a2a790 <<winit::window::Window>::request_redraw>
  a2ba82:	movq   $0xfffffffffffffffe,(%rbx)
  a2ba89:	add    $0x50,%rsp
  a2ba8d:	pop    %rbx
  a2ba8e:	ret
  a2ba8f:	sub    $0xd,%rcx
  a2ba93:	mov    $0x14,%eax
  a2ba98:	cmovge %rcx,%rax
  a2ba9c:	cmp    $0x16,%rax
  a2baa0:	ja     a2bb70 <<gpui::native::NativeHost<empty::Empty>>::input_result+0x130>
  a2baa6:	mov    $0x630,%ecx
  a2baab:	bt     %rax,%rcx
  a2baaf:	jb     a2bb63 <<gpui::native::NativeHost<empty::Empty>>::input_result+0x123>
  a2bab5:	mov    $0x600008,%ecx
  a2baba:	bt     %rax,%rcx
  a2babe:	jae    a2bb70 <<gpui::native::NativeHost<empty::Empty>>::input_result+0x130>
  a2bac4:	mov    0x30(%rdx),%rax
  a2bac8:	mov    %rax,0x40(%rsp)
  a2bacd:	movups (%rdx),%xmm0
  a2bad0:	movups 0x10(%rdx),%xmm1
  a2bad4:	movups 0x20(%rdx),%xmm2
  a2bad8:	movaps %xmm2,0x30(%rsp)
  a2badd:	movaps %xmm1,0x20(%rsp)
  a2bae2:	movaps %xmm0,0x10(%rsp)
  a2bae7:	mov    0x1e0(%rsi),%rdi
  a2baee:	test   %rdi,%rdi
  a2baf1:	je     a2bb04 <<gpui::native::NativeHost<empty::Empty>>::input_result+0xc4>
  a2baf3:	mov    0x1e8(%rsi),%rax
  a2bafa:	lea    0x10(%rsp),%rsi
  a2baff:	call   *0x20(%rax)
  a2bb02:	jmp    a2bb29 <<gpui::native::NativeHost<empty::Empty>>::input_result+0xe9>
  a2bb04:	lea    0x10(%rsp),%rax
  a2bb09:	mov    %rax,(%rsp)
  a2bb0d:	mov    0xb01e14(%rip),%rax        # 152d928 <_DYNAMIC+0x1390>
  a2bb14:	mov    %rax,0x8(%rsp)
  a2bb19:	lea    -0x8b4bc6(%rip),%rdi        # 176f5a <anon.48dd33490292f7cef44ed4fce7549844.8.llvm.6996506099118494405+0x33>
  a2bb20:	mov    %rsp,%rsi
  a2bb23:	call   *0xb01d37(%rip)        # 152d860 <_DYNAMIC+0x12c8>
  a2bb29:	mov    0x10(%rsp),%rcx
  a2bb2e:	sub    $0xd,%rcx
  a2bb32:	mov    $0x14,%eax
  a2bb37:	cmovge %rcx,%rax
  a2bb3b:	cmp    $0x19,%rax
  a2bb3f:	je     a2bb94 <<gpui::native::NativeHost<empty::Empty>>::input_result+0x154>
  a2bb41:	cmp    $0x14,%rax
  a2bb45:	jne    a2bb63 <<gpui::native::NativeHost<empty::Empty>>::input_result+0x123>
  a2bb47:	lea    0x28(%rsp),%rax
  a2bb4c:	mov    (%rax),%rsi
  a2bb4f:	test   %rsi,%rsi
  a2bb52:	je     a2bb63 <<gpui::native::NativeHost<empty::Empty>>::input_result+0x123>
  a2bb54:	mov    0x8(%rax),%rdi
  a2bb58:	mov    $0x1,%edx
  a2bb5d:	call   *0xb00c85(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  a2bb63:	movq   $0xfffffffffffffffe,(%rbx)
  a2bb6a:	add    $0x50,%rsp
  a2bb6e:	pop    %rbx
  a2bb6f:	ret
  a2bb70:	mov    0x30(%rdx),%rax
  a2bb74:	mov    %rax,0x30(%rbx)
  a2bb78:	movups (%rdx),%xmm0
  a2bb7b:	movups 0x10(%rdx),%xmm1
  a2bb7f:	movups 0x20(%rdx),%xmm2
  a2bb83:	movups %xmm2,0x20(%rbx)
  a2bb87:	movups %xmm1,0x10(%rbx)
  a2bb8b:	movups %xmm0,(%rbx)
  a2bb8e:	add    $0x50,%rsp
  a2bb92:	pop    %rbx
  a2bb93:	ret
  a2bb94:	lea    0x18(%rsp),%rax
  a2bb99:	mov    (%rax),%rsi
  a2bb9c:	test   %rsi,%rsi
  a2bb9f:	jne    a2bb54 <<gpui::native::NativeHost<empty::Empty>>::input_result+0x114>
  a2bba1:	jmp    a2bb63 <<gpui::native::NativeHost<empty::Empty>>::input_result+0x123>
  a2bba3:	mov    %rax,%rbx
  a2bba6:	lea    0x10(%rsp),%rdi
  a2bbab:	call   a28d20 <core::ptr::drop_glue::<gpui::runtime::Error>>
  a2bbb0:	mov    %rbx,%rdi
  a2bbb3:	call   14b7130 <_Unwind_Resume@plt>


/tmp/gpui-a11y-owner-channel-captures/release-candidate/empty:     file format elf64-x86-64


Disassembly of section .text:

0000000000a2bbc0 <<gpui::native::NativeHost<empty::Empty>>::retire_window>:
  a2bbc0:	push   %r15
  a2bbc2:	push   %r14
  a2bbc4:	push   %rbx
  a2bbc5:	mov    %rdi,%rbx
  a2bbc8:	mov    0x1d8(%rdi),%rdi
  a2bbcf:	test   %rdi,%rdi
  a2bbd2:	je     a2bbdf <<gpui::native::NativeHost<empty::Empty>>::retire_window+0x1f>
  a2bbd4:	add    $0x10,%rdi
  a2bbd8:	xor    %esi,%esi
  a2bbda:	call   a2dab0 <<winit::window::Window>::set_visible>
  a2bbdf:	lea    0x30(%rbx),%r15
  a2bbe3:	mov    %r15,%rdi
  a2bbe6:	call   a26480 <core::ptr::drop_glue::<core::option::Option<gpui::native::upgrade::Upgrade>>>
  a2bbeb:	movq   $0xffffffffffffffff,0x30(%rbx)
  a2bbf3:	lea    0x48(%rbx),%r15
  a2bbf7:	mov    %r15,%rdi
  a2bbfa:	call   a26340 <core::ptr::drop_glue::<core::option::Option<gpui::native::accessibility::Bridge>>>
  a2bbff:	movq   $0xfffffffffffffffe,0x48(%rbx)
  a2bc07:	mov    (%rbx),%eax
  a2bc09:	mov    0x8(%rbx),%r15
  a2bc0d:	movq   $0x0,(%rbx)
  a2bc14:	cmp    $0x1,%eax
  a2bc17:	jne    a2bc40 <<gpui::native::NativeHost<empty::Empty>>::retire_window+0x80>
  a2bc19:	test   %r15,%r15
  a2bc1c:	je     a2bc39 <<gpui::native::NativeHost<empty::Empty>>::retire_window+0x79>
  a2bc1e:	mov    %r15,%rdi
  a2bc21:	call   9afda0 <core::ptr::drop_glue::<gpui::runtime::Runtime<empty::Empty>>>
  a2bc26:	mov    $0x730,%esi
  a2bc2b:	mov    $0x8,%edx
  a2bc30:	mov    %r15,%rdi
  a2bc33:	call   *0xb00baf(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  a2bc39:	xor    %edi,%edi
  a2bc3b:	call   a26ee0 <core::ptr::drop_glue::<gpui::runtime::Win<empty::Empty>>>
  a2bc40:	movzwl 0x188(%rbx),%eax
  a2bc47:	cmp    $0x2,%eax
  a2bc4a:	je     a2bc6a <<gpui::native::NativeHost<empty::Empty>>::retire_window+0xaa>
  a2bc4c:	test   %eax,%eax
  a2bc4e:	jne    a2bc5e <<gpui::native::NativeHost<empty::Empty>>::retire_window+0x9e>
  a2bc50:	mov    0x190(%rbx),%rdi
  a2bc57:	call   a26d40 <core::ptr::drop_glue::<alloc::boxed::Box<gpui::native::GpuSurface>>>
  a2bc5c:	jmp    a2bc6a <<gpui::native::NativeHost<empty::Empty>>::retire_window+0xaa>
  a2bc5e:	mov    0x1a8(%rbx),%rdi
  a2bc65:	call   a251b0 <core::ptr::drop_glue::<softbuffer::Surface<alloc::sync::Arc<winit::window::Window>, alloc::sync::Arc<winit::window::Window>>>>
  a2bc6a:	movw   $0x2,0x188(%rbx)
  a2bc73:	lea    0x1d0(%rbx),%r15
  a2bc7a:	mov    0x1d0(%rbx),%rax
  a2bc81:	test   %rax,%rax
  a2bc84:	je     a2bc95 <<gpui::native::NativeHost<empty::Empty>>::retire_window+0xd5>
  a2bc86:	lock decq (%rax)
  a2bc8a:	jne    a2bc95 <<gpui::native::NativeHost<empty::Empty>>::retire_window+0xd5>
  a2bc8c:	mov    %r15,%rdi
  a2bc8f:	call   *0xb0147b(%rip)        # 152d110 <_DYNAMIC+0xb78>
  a2bc95:	add    $0x1d8,%rbx
  a2bc9c:	movq   $0x0,(%r15)
  a2bca3:	mov    (%rbx),%rax
  a2bca6:	test   %rax,%rax
  a2bca9:	je     a2bcba <<gpui::native::NativeHost<empty::Empty>>::retire_window+0xfa>
  a2bcab:	lock decq (%rax)
  a2bcaf:	jne    a2bcba <<gpui::native::NativeHost<empty::Empty>>::retire_window+0xfa>
  a2bcb1:	mov    %rbx,%rdi
  a2bcb4:	call   *0xb016c6(%rip)        # 152d380 <_DYNAMIC+0xde8>
  a2bcba:	movq   $0x0,(%rbx)
  a2bcc1:	pop    %rbx
  a2bcc2:	pop    %r14
  a2bcc4:	pop    %r15
  a2bcc6:	ret
  a2bcc7:	movq   $0x0,(%rbx)
  a2bcce:	mov    %rax,%rdi
  a2bcd1:	call   14b7130 <_Unwind_Resume@plt>
  a2bcd6:	movq   $0x0,(%r15)
  a2bcdd:	mov    %rax,%rdi
  a2bce0:	call   14b7130 <_Unwind_Resume@plt>
  a2bce5:	mov    %rax,%r14
  a2bce8:	mov    $0x730,%esi
  a2bced:	mov    $0x8,%edx
  a2bcf2:	mov    %r15,%rdi
  a2bcf5:	call   *0xb00aed(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  a2bcfb:	xor    %edi,%edi
  a2bcfd:	call   a26ee0 <core::ptr::drop_glue::<gpui::runtime::Win<empty::Empty>>>
  a2bd02:	jmp    a2bd34 <<gpui::native::NativeHost<empty::Empty>>::retire_window+0x174>
  a2bd04:	call   *0xb00b16(%rip)        # 152c820 <_DYNAMIC+0x288>
  a2bd0a:	movw   $0x2,0x188(%rbx)
  a2bd13:	mov    %rax,%rdi
  a2bd16:	call   14b7130 <_Unwind_Resume@plt>
  a2bd1b:	movq   $0xfffffffffffffffe,(%r15)
  a2bd22:	mov    %rax,%rdi
  a2bd25:	call   14b7130 <_Unwind_Resume@plt>
  a2bd2a:	mov    %rax,%r14
  a2bd2d:	movq   $0xffffffffffffffff,(%r15)
  a2bd34:	mov    %r14,%rdi
  a2bd37:	call   14b7130 <_Unwind_Resume@plt>


/tmp/gpui-a11y-owner-channel-captures/release-candidate/empty:     file format elf64-x86-64


Disassembly of section .text:

0000000000a2bd40 <<gpui::native::NativeHost<empty::Empty>>::start_upgrade>:
  a2bd40:	push   %r15
  a2bd42:	push   %r14
  a2bd44:	push   %rbx
  a2bd45:	sub    $0x40,%rsp
  a2bd49:	cmpb   $0x0,0x207(%rdi)
  a2bd50:	jne    a2be66 <<gpui::native::NativeHost<empty::Empty>>::start_upgrade+0x126>
  a2bd56:	mov    %rdi,%rbx
  a2bd59:	cmpb   $0x0,0x206(%rdi)
  a2bd60:	jne    a2be66 <<gpui::native::NativeHost<empty::Empty>>::start_upgrade+0x126>
  a2bd66:	movb   $0x1,0x206(%rbx)
  a2bd6d:	cmpq   $0x0,0x1d8(%rbx)
  a2bd75:	je     a2be66 <<gpui::native::NativeHost<empty::Empty>>::start_upgrade+0x126>
  a2bd7b:	mov    0x10(%rbx),%rax
  a2bd7f:	cmp    $0xffffffffffffffff,%rax
  a2bd83:	je     a2bddf <<gpui::native::NativeHost<empty::Empty>>::start_upgrade+0x9f>
  a2bd85:	mov    0x28(%rbx),%r15
  a2bd89:	lock incq (%r15)
  a2bd8d:	jle    a2be84 <<gpui::native::NativeHost<empty::Empty>>::start_upgrade+0x144>
  a2bd93:	mov    %r15,(%rsp)
  a2bd97:	mov    0x18(%rbx),%rcx
  a2bd9b:	test   %rax,%rax
  a2bd9e:	je     a2be70 <<gpui::native::NativeHost<empty::Empty>>::start_upgrade+0x130>
  a2bda4:	cmp    $0x1,%eax
  a2bda7:	jne    a2be86 <<gpui::native::NativeHost<empty::Empty>>::start_upgrade+0x146>
  a2bdad:	lock incq 0x180(%rcx)
  a2bdb5:	jle    a2be7e <<gpui::native::NativeHost<empty::Empty>>::start_upgrade+0x13e>
  a2bdbb:	mov    0x20(%rbx),%rdx
  a2bdbf:	lock incq (%rdx)
  a2bdc3:	jle    a2be84 <<gpui::native::NativeHost<empty::Empty>>::start_upgrade+0x144>
  a2bdc9:	mov    %rax,0x20(%rsp)
  a2bdce:	mov    %rcx,0x28(%rsp)
  a2bdd3:	mov    %rdx,0x30(%rsp)
  a2bdd8:	mov    %r15,0x38(%rsp)
  a2bddd:	jmp    a2bde8 <<gpui::native::NativeHost<empty::Empty>>::start_upgrade+0xa8>
  a2bddf:	movq   $0xffffffffffffffff,0x20(%rsp)
  a2bde8:	lea    0x1d8(%rbx),%rsi
  a2bdef:	lea    0x8(%rsp),%rdi
  a2bdf4:	lea    0x20(%rsp),%rdx
  a2bdf9:	call   *0xb01b31(%rip)        # 152d930 <_DYNAMIC+0x1398>
  a2bdff:	mov    0x8(%rsp),%rax
  a2be04:	cmp    $0xffffffffffffffff,%rax
  a2be08:	je     a2be66 <<gpui::native::NativeHost<empty::Empty>>::start_upgrade+0x126>
  a2be0a:	cmp    $0xfffffffe,%eax
  a2be0d:	jne    a2be49 <<gpui::native::NativeHost<empty::Empty>>::start_upgrade+0x109>
  a2be0f:	mov    0x10(%rsp),%rax
  a2be14:	mov    %rax,(%rsp)
  a2be18:	mov    %rsp,%rax
  a2be1b:	mov    %rax,0x20(%rsp)
  a2be20:	mov    0xb019a1(%rip),%rax        # 152d7c8 <_DYNAMIC+0x1230>
  a2be27:	mov    %rax,0x28(%rsp)
  a2be2c:	lea    -0x8a9d81(%rip),%rdi        # 1820b2 <anon.f14fc1a2f79f716d98413553529a74dd.437.llvm.2503939890947331820+0x242>
  a2be33:	lea    0x20(%rsp),%rsi
  a2be38:	call   *0xb01a22(%rip)        # 152d860 <_DYNAMIC+0x12c8>
  a2be3e:	mov    (%rsp),%rdi
  a2be42:	call   a28e00 <core::ptr::drop_glue::<std::io::error::Error>>
  a2be47:	jmp    a2be66 <<gpui::native::NativeHost<empty::Empty>>::start_upgrade+0x126>
  a2be49:	add    $0x30,%rbx
  a2be4d:	mov    %rbx,%rdi
  a2be50:	call   a26480 <core::ptr::drop_glue::<core::option::Option<gpui::native::upgrade::Upgrade>>>
  a2be55:	mov    0x18(%rsp),%rax
  a2be5a:	mov    %rax,0x10(%rbx)
  a2be5e:	movups 0x8(%rsp),%xmm0
  a2be63:	movups %xmm0,(%rbx)
  a2be66:	add    $0x40,%rsp
  a2be6a:	pop    %rbx
  a2be6b:	pop    %r14
  a2be6d:	pop    %r15
  a2be6f:	ret
  a2be70:	lock incq 0x200(%rcx)
  a2be78:	jg     a2bdbb <<gpui::native::NativeHost<empty::Empty>>::start_upgrade+0x7b>
  a2be7e:	call   *0xb014ac(%rip)        # 152d330 <_DYNAMIC+0xd98>
  a2be84:	ud2
  a2be86:	lock incq 0x70(%rcx)
  a2be8b:	jg     a2bdbb <<gpui::native::NativeHost<empty::Empty>>::start_upgrade+0x7b>
  a2be91:	jmp    a2be7e <<gpui::native::NativeHost<empty::Empty>>::start_upgrade+0x13e>
  a2be93:	mov    %rax,%r14
  a2be96:	mov    0x18(%rsp),%rax
  a2be9b:	mov    %rax,0x10(%rbx)
  a2be9f:	movups 0x8(%rsp),%xmm0
  a2bea4:	movups %xmm0,(%rbx)
  a2bea7:	mov    %r14,%rdi
  a2beaa:	call   14b7130 <_Unwind_Resume@plt>
  a2beaf:	mov    %rax,%r14
  a2beb2:	mov    (%rsp),%rdi
  a2beb6:	call   a28e00 <core::ptr::drop_glue::<std::io::error::Error>>
  a2bebb:	jmp    a2bed5 <<gpui::native::NativeHost<empty::Empty>>::start_upgrade+0x195>
  a2bebd:	call   *0xb0095d(%rip)        # 152c820 <_DYNAMIC+0x288>
  a2bec3:	mov    %rax,%r14
  a2bec6:	lock decq (%r15)
  a2beca:	jne    a2bed5 <<gpui::native::NativeHost<empty::Empty>>::start_upgrade+0x195>
  a2becc:	mov    %rsp,%rdi
  a2becf:	call   *0xb01a4b(%rip)        # 152d920 <_DYNAMIC+0x1388>
  a2bed5:	mov    %r14,%rdi
  a2bed8:	call   14b7130 <_Unwind_Resume@plt>
  a2bedd:	call   *0xb0093d(%rip)        # 152c820 <_DYNAMIC+0x288>


/tmp/gpui-a11y-owner-channel-captures/release-candidate/empty:     file format elf64-x86-64


Disassembly of section .text:

0000000000a2bef0 <<gpui::native::NativeHost<empty::Empty>>::create_surface>:
  a2bef0:	push   %rbp
  a2bef1:	push   %r15
  a2bef3:	push   %r14
  a2bef5:	push   %r13
  a2bef7:	push   %r12
  a2bef9:	push   %rbx
  a2befa:	sub    $0xa48,%rsp
  a2bf01:	mov    %rdi,%rbx
  a2bf04:	mov    0x1d8(%rsi),%r15
  a2bf0b:	test   %r15,%r15
  a2bf0e:	je     a2c154 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x264>
  a2bf14:	mov    %rsi,%r14
  a2bf17:	cmpb   $0x1,0x207(%rsi)
  a2bf1e:	jne    a2c160 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x270>
  a2bf24:	cmpq   $0x0,0x1d0(%r14)
  a2bf2c:	jne    a2bf94 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0xa4>
  a2bf2e:	lock incq (%r15)
  a2bf32:	jle    a2c7b5 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x8c5>
  a2bf38:	mov    %r15,0x140(%rsp)
  a2bf40:	call   *0xb00892(%rip)        # 152c7d8 <_DYNAMIC+0x240>
  a2bf46:	mov    $0x8,%edi
  a2bf4b:	mov    $0x8,%esi
  a2bf50:	call   *0xb0088a(%rip)        # 152c7e0 <_DYNAMIC+0x248>
  a2bf56:	test   %rax,%rax
  a2bf59:	je     a2c745 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x855>
  a2bf5f:	mov    %r15,(%rax)
  a2bf62:	lea    0xa90d2f(%rip),%rdx        # 14bcc98 <anon.fff2d4355c6109bc0e8af2445443084d.0.llvm.4725208967334239140+0x48>
  a2bf69:	lea    0x140(%rsp),%r15
  a2bf71:	mov    %r15,%rdi
  a2bf74:	mov    %rax,%rsi
  a2bf77:	call   *0xb019bb(%rip)        # 152d938 <_DYNAMIC+0x13a0>
  a2bf7d:	mov    %r15,%rdi
  a2bf80:	call   *0xb019ba(%rip)        # 152d940 <_DYNAMIC+0x13a8>
  a2bf86:	mov    %rax,0x1d0(%r14)
  a2bf8d:	mov    0x1d8(%r14),%r15
  a2bf94:	lock incq (%r15)
  a2bf98:	jle    a2c7b5 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x8c5>
  a2bf9e:	lea    0x1d0(%r14),%r15
  a2bfa5:	mov    0x1d8(%r14),%rdx
  a2bfac:	lea    0x140(%rsp),%rdi
  a2bfb4:	mov    %r15,%rsi
  a2bfb7:	call   a0c090 <<wgpu::api::instance::Instance>::create_surface::<alloc::sync::Arc<winit::window::Window>>>
  a2bfbc:	mov    0x140(%rsp),%rax
  a2bfc4:	test   %rax,%rax
  a2bfc7:	je     a2c17c <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x28c>
  a2bfcd:	mov    0x148(%rsp),%rcx
  a2bfd5:	movups 0x150(%rsp),%xmm0
  a2bfdd:	movaps %xmm0,0x40(%rsp)
  a2bfe2:	mov    0x160(%rsp),%rdx
  a2bfea:	movups 0x168(%rsp),%xmm1
  a2bff2:	movups %xmm1,0xe8(%rsp)
  a2bffa:	mov    0x178(%rsp),%rsi
  a2c002:	mov    %rsi,0xf8(%rsp)
  a2c00a:	movups 0x180(%rsp),%xmm1
  a2c012:	movups %xmm1,0x100(%rsp)
  a2c01a:	movups 0x190(%rsp),%xmm1
  a2c022:	movups %xmm1,0x110(%rsp)
  a2c02a:	movaps %xmm0,0x120(%rsp)
  a2c032:	mov    %rdx,0x130(%rsp)
  a2c03a:	mov    %rdx,0xe0(%rsp)
  a2c042:	movups %xmm0,0xd0(%rsp)
  a2c04a:	mov    %rax,0xc0(%rsp)
  a2c052:	mov    %rcx,0xc8(%rsp)
  a2c05a:	movl   $0x0,0x10(%rsp)
  a2c062:	movb   $0x0,0x14(%rsp)
  a2c067:	lea    0xc0(%rsp),%rax
  a2c06f:	mov    %rax,0x18(%rsp)
  a2c074:	movb   $0x0,0x20(%rsp)
  a2c079:	lea    0x140(%rsp),%rdi
  a2c081:	lea    0x10(%rsp),%rdx
  a2c086:	mov    %r15,%rsi
  a2c089:	call   *0xb018b9(%rip)        # 152d948 <_DYNAMIC+0x13b0>
  a2c08f:	lea    0x6d0(%rsp),%rdi
  a2c097:	lea    0x140(%rsp),%rsi
  a2c09f:	call   a314a0 <pollster::block_on::<<wgpu::api::instance::Instance>::request_adapter::{closure#0}>>
  a2c0a4:	cmpl   $0x1,0x6d0(%rsp)
  a2c0ac:	jne    a2c276 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x386>
  a2c0b2:	movups 0x6d4(%rsp),%xmm0
  a2c0ba:	movups 0x6e0(%rsp),%xmm1
  a2c0c2:	movups %xmm1,0x14c(%rsp)
  a2c0ca:	movaps %xmm0,0x140(%rsp)
  a2c0d2:	movq   $0x0,0x58(%rsp)
  a2c0db:	movq   $0x1,0x60(%rsp)
  a2c0e4:	movq   $0x0,0x68(%rsp)
  a2c0ed:	movq   $0x60000020,0x540(%rsp)
  a2c0f9:	lea    0x58(%rsp),%rax
  a2c0fe:	mov    %rax,0x530(%rsp)
  a2c106:	lea    0xa90e4b(%rip),%rax        # 14bcf58 <anon.fff2d4355c6109bc0e8af2445443084d.57.llvm.4725208967334239140>
  a2c10d:	mov    %rax,0x538(%rsp)
  a2c115:	lea    0x140(%rsp),%rdi
  a2c11d:	lea    0x530(%rsp),%rsi
  a2c125:	call   *0xb01825(%rip)        # 152d950 <_DYNAMIC+0x13b8>
  a2c12b:	test   %al,%al
  a2c12d:	jne    a2c77e <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x88e>
  a2c133:	lea    0x60(%rsp),%rax
  a2c138:	mov    0x58(%rsp),%rcx
  a2c13d:	movups (%rax),%xmm0
  a2c140:	movups %xmm0,0x10(%rbx)
  a2c144:	movq   $0x2d,(%rbx)
  a2c14b:	mov    %rcx,0x8(%rbx)
  a2c14f:	jmp    a2c397 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x4a7>
  a2c154:	movq   $0xfffffffffffffffe,(%rbx)
  a2c15b:	jmp    a2c3ef <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x4ff>
  a2c160:	mov    %rbx,%rdi
  a2c163:	mov    %r14,%rsi
  a2c166:	add    $0xa48,%rsp
  a2c16d:	pop    %rbx
  a2c16e:	pop    %r12
  a2c170:	pop    %r13
  a2c172:	pop    %r14
  a2c174:	pop    %r15
  a2c176:	pop    %rbp
  a2c177:	jmp    a2c8e0 <<gpui::native::NativeHost<empty::Empty>>::create_cpu_surface>
  a2c17c:	movups 0x148(%rsp),%xmm0
  a2c184:	movups 0x158(%rsp),%xmm1
  a2c18c:	movups 0x168(%rsp),%xmm2
  a2c194:	movaps %xmm2,0x6f0(%rsp)
  a2c19c:	movaps %xmm1,0x6e0(%rsp)
  a2c1a4:	movaps %xmm0,0x6d0(%rsp)
  a2c1ac:	movq   $0x0,0x58(%rsp)
  a2c1b5:	movq   $0x1,0x60(%rsp)
  a2c1be:	movq   $0x0,0x68(%rsp)
  a2c1c7:	movq   $0x60000020,0x540(%rsp)
  a2c1d3:	lea    0x58(%rsp),%rax
  a2c1d8:	mov    %rax,0x530(%rsp)
  a2c1e0:	lea    0xa90d71(%rip),%rax        # 14bcf58 <anon.fff2d4355c6109bc0e8af2445443084d.57.llvm.4725208967334239140>
  a2c1e7:	mov    %rax,0x538(%rsp)
  a2c1ef:	lea    0x6d0(%rsp),%rdi
  a2c1f7:	lea    0x530(%rsp),%rsi
  a2c1ff:	call   *0xb01753(%rip)        # 152d958 <_DYNAMIC+0x13c0>
  a2c205:	test   %al,%al
  a2c207:	jne    a2c757 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x867>
  a2c20d:	mov    0x68(%rsp),%rax
  a2c212:	mov    %rax,0x20(%rsp)
  a2c217:	movups 0x58(%rsp),%xmm0
  a2c21c:	movaps %xmm0,0x10(%rsp)
  a2c221:	movzbl 0x6d0(%rsp),%eax
  a2c229:	lea    -0x3(%rax),%rdx
  a2c22d:	xor    %ecx,%ecx
  a2c22f:	cmp    $0x4,%rax
  a2c233:	cmovae %rdx,%rcx
  a2c237:	cmp    $0x1,%rcx
  a2c23b:	je     a2c3a6 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x4b6>
  a2c241:	test   %rcx,%rcx
  a2c244:	jne    a2c3c6 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x4d6>
  a2c24a:	cmp    $0x1,%al
  a2c24c:	jne    a2c3c6 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x4d6>
  a2c252:	lea    0x6d8(%rsp),%rdi
  a2c25a:	lea    0x6f8(%rsp),%rsi
  a2c262:	mov    $0x30,%edx
  a2c267:	mov    $0x10,%ecx
  a2c26c:	call   a3c040 <<hashbrown::raw::RawTableInner>::drop_inner_table::<(wgpu_types::backend::Backend, wgpu_hal::InstanceError), hashbrown::alloc::inner::Global>>
  a2c271:	jmp    a2c3c6 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x4d6>
  a2c276:	mov    0x6d8(%rsp),%rax
  a2c27e:	mov    %rax,0x40(%rsp)
  a2c283:	lea    0x58(%rsp),%rdi
  a2c288:	lea    0xc0(%rsp),%rsi
  a2c290:	lea    0x40(%rsp),%r13
  a2c295:	mov    %r13,%rdx
  a2c298:	call   *0xb016c2(%rip)        # 152d960 <_DYNAMIC+0x13c8>
  a2c29e:	mov    0x60(%rsp),%r15
  a2c2a3:	mov    0x68(%rsp),%rax
  a2c2a8:	test   %rax,%rax
  a2c2ab:	je     a2c2f4 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x404>
  a2c2ad:	shl    $0x2,%rax
  a2c2b1:	lea    (%rax,%rax,2),%rax
  a2c2b5:	xor    %ecx,%ecx
  a2c2b7:	nopw   0x0(%rax,%rax,1)
  a2c2c0:	cmpl   $0x1b,(%r15,%rcx,1)
  a2c2c5:	je     a2c401 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x511>
  a2c2cb:	add    $0xc,%rcx
  a2c2cf:	cmp    %rcx,%rax
  a2c2d2:	jne    a2c2c0 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x3d0>
  a2c2d4:	xor    %ecx,%ecx
  a2c2d6:	cs nopw 0x0(%rax,%rax,1)
  a2c2e0:	cmpl   $0x16,(%r15,%rcx,1)
  a2c2e5:	je     a2c408 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x518>
  a2c2eb:	add    $0xc,%rcx
  a2c2ef:	cmp    %rcx,%rax
  a2c2f2:	jne    a2c2e0 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x3f0>
  a2c2f4:	movq   $0x2e,(%rbx)
  a2c2fb:	mov    0x58(%rsp),%rax
  a2c300:	test   %rax,%rax
  a2c303:	je     a2c31b <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x42b>
  a2c305:	shl    $0x2,%rax
  a2c309:	lea    (%rax,%rax,2),%rsi
  a2c30d:	mov    $0x4,%edx
  a2c312:	mov    %r15,%rdi
  a2c315:	call   *0xb004cd(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  a2c31b:	mov    0x70(%rsp),%rsi
  a2c320:	test   %rsi,%rsi
  a2c323:	je     a2c339 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x449>
  a2c325:	mov    0x78(%rsp),%rdi
  a2c32a:	shl    $0x4,%rsi
  a2c32e:	mov    $0x4,%edx
  a2c333:	call   *0xb004af(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  a2c339:	mov    0x88(%rsp),%rsi
  a2c341:	test   %rsi,%rsi
  a2c344:	je     a2c35d <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x46d>
  a2c346:	mov    0x90(%rsp),%rdi
  a2c34e:	shl    $0x2,%rsi
  a2c352:	mov    $0x4,%edx
  a2c357:	call   *0xb0048b(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  a2c35d:	mov    0xa0(%rsp),%rsi
  a2c365:	test   %rsi,%rsi
  a2c368:	je     a2c381 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x491>
  a2c36a:	mov    0xa8(%rsp),%rdi
  a2c372:	shl    $0x2,%rsi
  a2c376:	mov    $0x4,%edx
  a2c37b:	call   *0xb00467(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  a2c381:	mov    0x40(%rsp),%rax
  a2c386:	lock decq (%rax)
  a2c38a:	jne    a2c397 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x4a7>
  a2c38c:	lea    0x40(%rsp),%rdi
  a2c391:	call   *0xb00d81(%rip)        # 152d118 <_DYNAMIC+0xb80>
  a2c397:	lea    0xc0(%rsp),%rdi
  a2c39f:	call   a29000 <core::ptr::drop_glue::<wgpu::api::surface::Surface>>
  a2c3a4:	jmp    a2c3ef <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x4ff>
  a2c3a6:	mov    0x6d8(%rsp),%rsi
  a2c3ae:	test   %rsi,%rsi
  a2c3b1:	je     a2c3c6 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x4d6>
  a2c3b3:	mov    0x6e0(%rsp),%rdi
  a2c3bb:	mov    $0x1,%edx
  a2c3c0:	call   *0xb00422(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  a2c3c6:	mov    0x20(%rsp),%rax
  a2c3cb:	movaps 0x10(%rsp),%xmm0
  a2c3d0:	movaps %xmm0,0x120(%rsp)
  a2c3d8:	mov    %rax,0x130(%rsp)
  a2c3e0:	mov    %rax,0x18(%rbx)
  a2c3e4:	movups %xmm0,0x8(%rbx)
  a2c3e8:	movq   $0x2d,(%rbx)
  a2c3ef:	add    $0xa48,%rsp
  a2c3f6:	pop    %rbx
  a2c3f7:	pop    %r12
  a2c3f9:	pop    %r13
  a2c3fb:	pop    %r14
  a2c3fd:	pop    %r15
  a2c3ff:	pop    %rbp
  a2c400:	ret
  a2c401:	mov    $0x1b,%ebp
  a2c406:	jmp    a2c40d <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x51d>
  a2c408:	mov    $0x16,%ebp
  a2c40d:	movq   $0x2e,0x140(%rsp)
  a2c419:	lea    0x140(%rsp),%rdi
  a2c421:	call   a28c80 <core::ptr::drop_glue::<gpui::native::NativeError>>
  a2c426:	mov    0xa8(%rsp),%r12
  a2c42e:	mov    0xb0(%rsp),%rax
  a2c436:	shl    $0x2,%rax
  a2c43a:	xor    %ecx,%ecx
  a2c43c:	nopl   0x0(%rax)
  a2c440:	cmp    %rcx,%rax
  a2c443:	je     a2c2f4 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x404>
  a2c449:	cmpl   $0x1,(%r12,%rcx,1)
  a2c44e:	lea    0x4(%rcx),%rcx
  a2c452:	jne    a2c440 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x550>
  a2c454:	mov    %r13,0x530(%rsp)
  a2c45c:	mov    %ebp,0x6c0(%rsp)
  a2c463:	movb   $0x0,0x6cc(%rsp)
  a2c46b:	lea    0x140(%rsp),%rdi
  a2c473:	lea    0x530(%rsp),%rsi
  a2c47b:	call   a30300 <pollster::block_on::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>>
  a2c480:	mov    0x140(%rsp),%r13
  a2c488:	movups 0x148(%rsp),%xmm0
  a2c490:	movaps %xmm0,0x10(%rsp)
  a2c495:	movups 0x158(%rsp),%xmm0
  a2c49d:	movaps %xmm0,0x20(%rsp)
  a2c4a2:	cmp    $0xffffffffffffffff,%r13
  a2c4a6:	je     a2c51f <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x62f>
  a2c4a8:	lea    0x168(%rsp),%rsi
  a2c4b0:	lea    0x6f8(%rsp),%rdi
  a2c4b8:	mov    $0x350,%edx
  a2c4bd:	call   *0xb00335(%rip)        # 152c7f8 <memcpy@GLIBC_2.14>
  a2c4c3:	movaps 0x10(%rsp),%xmm0
  a2c4c8:	movaps 0x20(%rsp),%xmm1
  a2c4cd:	movups %xmm0,0x6d8(%rsp)
  a2c4d5:	movups %xmm1,0x6e8(%rsp)
  a2c4dd:	mov    %r13,0x6d0(%rsp)
  a2c4e5:	cmpl   $0xffffffff,0x10(%r14)
  a2c4ea:	je     a2c54b <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x65b>
  a2c4ec:	lea    0x10(%r14),%rsi
  a2c4f0:	lea    0x140(%rsp),%rdi
  a2c4f8:	call   a2e010 <<gpui_reactivity_host::native::Wake as core::clone::Clone>::clone>
  a2c4fd:	movups 0x140(%rsp),%xmm0
  a2c505:	movups 0x150(%rsp),%xmm1
  a2c50d:	movaps %xmm1,0x540(%rsp)
  a2c515:	movaps %xmm0,0x530(%rsp)
  a2c51d:	jmp    a2c557 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x667>
  a2c51f:	movaps 0x10(%rsp),%xmm0
  a2c524:	movaps 0x20(%rsp),%xmm1
  a2c529:	movups %xmm1,0x18(%rbx)
  a2c52d:	movups %xmm0,0x8(%rbx)
  a2c531:	movq   $0x2c,(%rbx)
  a2c538:	mov    0x58(%rsp),%rax
  a2c53d:	test   %rax,%rax
  a2c540:	jne    a2c305 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x415>
  a2c546:	jmp    a2c31b <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x42b>
  a2c54b:	movq   $0xffffffffffffffff,0x530(%rsp)
  a2c557:	lea    0xa18(%rsp),%rdi
  a2c55f:	lea    0x530(%rsp),%rsi
  a2c567:	call   *0xb013fb(%rip)        # 152d968 <_DYNAMIC+0x13d0>
  a2c56d:	mov    %rax,%rbp
  a2c570:	mov    %rax,0x10(%rsp)
  a2c575:	mov    0x1d8(%r14),%rdi
  a2c57c:	add    $0x10,%rdi
  a2c580:	call   a2d930 <<winit::window::Window>::inner_size>
  a2c585:	mov    %eax,0x3c(%rsp)
  a2c589:	mov    %edx,%r13d
  a2c58c:	movups 0x110(%rsp),%xmm0
  a2c594:	movups %xmm0,0x508(%rsp)
  a2c59c:	movups 0x100(%rsp),%xmm0
  a2c5a4:	movups %xmm0,0x4f8(%rsp)
  a2c5ac:	movups 0xc0(%rsp),%xmm0
  a2c5b4:	movups 0xd0(%rsp),%xmm1
  a2c5bc:	movups 0xe0(%rsp),%xmm2
  a2c5c4:	movups 0xf0(%rsp),%xmm3
  a2c5cc:	movups %xmm3,0x4e8(%rsp)
  a2c5d4:	movups %xmm2,0x4d8(%rsp)
  a2c5dc:	movups %xmm1,0x4c8(%rsp)
  a2c5e4:	movups %xmm0,0x4b8(%rsp)
  a2c5ec:	lea    0x140(%rsp),%rdi
  a2c5f4:	lea    0x6d0(%rsp),%rsi
  a2c5fc:	mov    $0x378,%edx
  a2c601:	call   *0xb001f1(%rip)        # 152c7f8 <memcpy@GLIBC_2.14>
  a2c607:	mov    %rbp,0x518(%rsp)
  a2c60f:	movq   $0x0,0x520(%rsp)
  a2c61b:	call   *0xb001b7(%rip)        # 152c7d8 <_DYNAMIC+0x240>
  a2c621:	mov    $0x3f0,%edi
  a2c626:	mov    $0x8,%esi
  a2c62b:	call   *0xb001af(%rip)        # 152c7e0 <_DYNAMIC+0x248>
  a2c631:	test   %rax,%rax
  a2c634:	je     a2c7a5 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x8b5>
  a2c63a:	mov    %rax,%rbp
  a2c63d:	lea    0x140(%rsp),%rsi
  a2c645:	mov    $0x3f0,%edx
  a2c64a:	mov    %rax,%rdi
  a2c64d:	call   *0xb001a5(%rip)        # 152c7f8 <memcpy@GLIBC_2.14>
  a2c653:	movzwl 0x188(%r14),%eax
  a2c65b:	cmp    $0x2,%eax
  a2c65e:	je     a2c67e <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x78e>
  a2c660:	test   %eax,%eax
  a2c662:	jne    a2c672 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x782>
  a2c664:	mov    0x190(%r14),%rdi
  a2c66b:	call   a26d40 <core::ptr::drop_glue::<alloc::boxed::Box<gpui::native::GpuSurface>>>
  a2c670:	jmp    a2c67e <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x78e>
  a2c672:	mov    0x1a8(%r14),%rdi
  a2c679:	call   a251b0 <core::ptr::drop_glue::<softbuffer::Surface<alloc::sync::Arc<winit::window::Window>, alloc::sync::Arc<winit::window::Window>>>>
  a2c67e:	movw   $0x0,0x188(%r14)
  a2c688:	mov    %rbp,0x190(%r14)
  a2c68f:	shl    $0x20,%r13
  a2c693:	mov    0x3c(%rsp),%edx
  a2c697:	or     %r13,%rdx
  a2c69a:	mov    %rbx,%rdi
  a2c69d:	mov    %r14,%rsi
  a2c6a0:	call   a2d650 <<gpui::native::NativeHost<empty::Empty>>::resize>
  a2c6a5:	mov    0x58(%rsp),%rax
  a2c6aa:	test   %rax,%rax
  a2c6ad:	je     a2c6c5 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x7d5>
  a2c6af:	shl    $0x2,%rax
  a2c6b3:	lea    (%rax,%rax,2),%rsi
  a2c6b7:	mov    $0x4,%edx
  a2c6bc:	mov    %r15,%rdi
  a2c6bf:	call   *0xb00123(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  a2c6c5:	mov    0x70(%rsp),%rsi
  a2c6ca:	test   %rsi,%rsi
  a2c6cd:	je     a2c6e3 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x7f3>
  a2c6cf:	mov    0x78(%rsp),%rdi
  a2c6d4:	shl    $0x4,%rsi
  a2c6d8:	mov    $0x4,%edx
  a2c6dd:	call   *0xb00105(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  a2c6e3:	mov    0x88(%rsp),%rsi
  a2c6eb:	test   %rsi,%rsi
  a2c6ee:	je     a2c707 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x817>
  a2c6f0:	mov    0x90(%rsp),%rdi
  a2c6f8:	shl    $0x2,%rsi
  a2c6fc:	mov    $0x4,%edx
  a2c701:	call   *0xb000e1(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  a2c707:	mov    0xa0(%rsp),%rsi
  a2c70f:	test   %rsi,%rsi
  a2c712:	je     a2c726 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x836>
  a2c714:	shl    $0x2,%rsi
  a2c718:	mov    $0x4,%edx
  a2c71d:	mov    %r12,%rdi
  a2c720:	call   *0xb000c2(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  a2c726:	mov    0x40(%rsp),%rax
  a2c72b:	lock decq (%rax)
  a2c72f:	jne    a2c3ef <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x4ff>
  a2c735:	lea    0x40(%rsp),%rdi
  a2c73a:	call   *0xb009d8(%rip)        # 152d118 <_DYNAMIC+0xb80>
  a2c740:	jmp    a2c3ef <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x4ff>
  a2c745:	mov    $0x8,%edi
  a2c74a:	mov    $0x8,%esi
  a2c74f:	call   *0xb000ab(%rip)        # 152c800 <_DYNAMIC+0x268>
  a2c755:	jmp    a2c7b5 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x8c5>
  a2c757:	lea    -0x89744e(%rip),%rdi        # 195310 <anon.fff2d4355c6109bc0e8af2445443084d.58.llvm.4725208967334239140>
  a2c75e:	lea    0xa905a3(%rip),%rcx        # 14bcd08 <anon.fff2d4355c6109bc0e8af2445443084d.8.llvm.4725208967334239140>
  a2c765:	lea    0xa9081c(%rip),%r8        # 14bcf88 <anon.fff2d4355c6109bc0e8af2445443084d.60.llvm.4725208967334239140>
  a2c76c:	lea    0xf(%rsp),%rdx
  a2c771:	mov    $0x37,%esi
  a2c776:	call   *0xb00194(%rip)        # 152c910 <_DYNAMIC+0x378>
  a2c77c:	jmp    a2c7b5 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x8c5>
  a2c77e:	lea    -0x897475(%rip),%rdi        # 195310 <anon.fff2d4355c6109bc0e8af2445443084d.58.llvm.4725208967334239140>
  a2c785:	lea    0xa9057c(%rip),%rcx        # 14bcd08 <anon.fff2d4355c6109bc0e8af2445443084d.8.llvm.4725208967334239140>
  a2c78c:	lea    0xa907f5(%rip),%r8        # 14bcf88 <anon.fff2d4355c6109bc0e8af2445443084d.60.llvm.4725208967334239140>
  a2c793:	lea    0xf(%rsp),%rdx
  a2c798:	mov    $0x37,%esi
  a2c79d:	call   *0xb0016d(%rip)        # 152c910 <_DYNAMIC+0x378>
  a2c7a3:	jmp    a2c7b5 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x8c5>
  a2c7a5:	mov    $0x8,%edi
  a2c7aa:	mov    $0x3f0,%esi
  a2c7af:	call   *0xb0004b(%rip)        # 152c800 <_DYNAMIC+0x268>
  a2c7b5:	ud2
  a2c7b7:	mov    %rax,%rbx
  a2c7ba:	movw   $0x0,0x188(%r14)
  a2c7c4:	mov    %rbp,0x190(%r14)
  a2c7cb:	jmp    a2c823 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x933>
  a2c7cd:	mov    %rax,%rbx
  a2c7d0:	jmp    a2c823 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x933>
  a2c7d2:	mov    %rax,%rbx
  a2c7d5:	lock decq 0x0(%rbp)
  a2c7da:	jne    a2c7f4 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x904>
  a2c7dc:	lea    0x10(%rsp),%rdi
  a2c7e1:	call   *0xb01021(%rip)        # 152d808 <_DYNAMIC+0x1270>
  a2c7e7:	jmp    a2c7f4 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x904>
  a2c7e9:	mov    %rax,%rbx
  a2c7ec:	mov    $0x1,%bpl
  a2c7ef:	jmp    a2c825 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x935>
  a2c7f1:	mov    %rax,%rbx
  a2c7f4:	mov    $0x1,%bpl
  a2c7f7:	lea    0x6d0(%rsp),%rdi
  a2c7ff:	call   a28570 <core::ptr::drop_glue::<gpui_gpu::renderer::Renderer>>
  a2c804:	jmp    a2c825 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x935>
  a2c806:	mov    %rax,%rbx
  a2c809:	mov    $0x1,%bpl
  a2c80c:	jmp    a2c82f <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x93f>
  a2c80e:	mov    %rax,%rbx
  a2c811:	jmp    a2c872 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x982>
  a2c813:	mov    %rax,%rbx
  a2c816:	lea    0x140(%rsp),%rdi
  a2c81e:	call   a28bf0 <core::ptr::drop_glue::<gpui::native::GpuSurface>>
  a2c823:	xor    %ebp,%ebp
  a2c825:	lea    0x58(%rsp),%rdi
  a2c82a:	call   a27860 <core::ptr::drop_glue::<wgpu_types::surface::SurfaceCapabilities>>
  a2c82f:	mov    0x40(%rsp),%rax
  a2c834:	lock decq (%rax)
  a2c838:	jne    a2c845 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x955>
  a2c83a:	lea    0x40(%rsp),%rdi
  a2c83f:	call   *0xb008d3(%rip)        # 152d118 <_DYNAMIC+0xb80>
  a2c845:	test   %bpl,%bpl
  a2c848:	jne    a2c872 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x982>
  a2c84a:	jmp    a2c8d0 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x9e0>
  a2c84f:	call   *0xafffcb(%rip)        # 152c820 <_DYNAMIC+0x288>
  a2c855:	mov    %rax,%rbx
  a2c858:	mov    0x58(%rsp),%rsi
  a2c85d:	test   %rsi,%rsi
  a2c860:	je     a2c872 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x982>
  a2c862:	mov    0x60(%rsp),%rdi
  a2c867:	mov    $0x1,%edx
  a2c86c:	call   *0xafff76(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  a2c872:	lea    0xc0(%rsp),%rdi
  a2c87a:	call   a29000 <core::ptr::drop_glue::<wgpu::api::surface::Surface>>
  a2c87f:	jmp    a2c8d0 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x9e0>
  a2c881:	call   *0xafff99(%rip)        # 152c820 <_DYNAMIC+0x288>
  a2c887:	mov    %rax,%rbx
  a2c88a:	lock decq (%r15)
  a2c88e:	jne    a2c8d0 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x9e0>
  a2c890:	lea    0x140(%rsp),%rdi
  a2c898:	call   *0xb00ae2(%rip)        # 152d380 <_DYNAMIC+0xde8>
  a2c89e:	jmp    a2c8d0 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x9e0>
  a2c8a0:	call   *0xafff7a(%rip)        # 152c820 <_DYNAMIC+0x288>
  a2c8a6:	mov    %rax,%rbx
  a2c8a9:	mov    0x58(%rsp),%rsi
  a2c8ae:	test   %rsi,%rsi
  a2c8b1:	je     a2c8c3 <<gpui::native::NativeHost<empty::Empty>>::create_surface+0x9d3>
  a2c8b3:	mov    0x60(%rsp),%rdi
  a2c8b8:	mov    $0x1,%edx
  a2c8bd:	call   *0xafff25(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  a2c8c3:	lea    0x6d0(%rsp),%rdi
  a2c8cb:	call   a28fa0 <core::ptr::drop_glue::<wgpu::api::surface::CreateSurfaceError>>
  a2c8d0:	mov    %rbx,%rdi
  a2c8d3:	call   14b7130 <_Unwind_Resume@plt>
  a2c8d8:	call   *0xafff42(%rip)        # 152c820 <_DYNAMIC+0x288>


/tmp/gpui-a11y-owner-channel-captures/release-candidate/empty:     file format elf64-x86-64


Disassembly of section .text:

0000000000a2c8e0 <<gpui::native::NativeHost<empty::Empty>>::create_cpu_surface>:
  a2c8e0:	push   %rbp
  a2c8e1:	push   %r15
  a2c8e3:	push   %r14
  a2c8e5:	push   %r12
  a2c8e7:	push   %rbx
  a2c8e8:	sub    $0xb0,%rsp
  a2c8ef:	mov    %rdi,%rbx
  a2c8f2:	movl   $0xffffffff,0x180(%rsi)
  a2c8fc:	movb   $0x0,0x209(%rsi)
  a2c903:	mov    0x1d8(%rsi),%r12
  a2c90a:	test   %r12,%r12
  a2c90d:	je     a2c9ac <<gpui::native::NativeHost<empty::Empty>>::create_cpu_surface+0xcc>
  a2c913:	mov    %rsi,%r14
  a2c916:	lea    0x10(%r12),%rdi
  a2c91b:	call   a2d930 <<winit::window::Window>::inner_size>
  a2c920:	lock incq (%r12)
  a2c925:	jle    a2cad2 <<gpui::native::NativeHost<empty::Empty>>::create_cpu_surface+0x1f2>
  a2c92b:	mov    %eax,%ebp
  a2c92d:	mov    %edx,%r15d
  a2c930:	lea    0x8(%rsp),%rdi
  a2c935:	mov    %r12,%rsi
  a2c938:	call   a39bd0 <<softbuffer::Context<alloc::sync::Arc<winit::window::Window>>>::new>
  a2c93d:	cmpl   $0xffffffff,0x8(%rsp)
  a2c942:	je     a2c9b8 <<gpui::native::NativeHost<empty::Empty>>::create_cpu_surface+0xd8>
  a2c944:	mov    0x38(%rsp),%rax
  a2c949:	mov    %rax,0x70(%rsp)
  a2c94e:	movups 0x8(%rsp),%xmm0
  a2c953:	movups 0x18(%rsp),%xmm1
  a2c958:	movups 0x28(%rsp),%xmm2
  a2c95d:	movaps %xmm2,0x60(%rsp)
  a2c962:	movaps %xmm1,0x50(%rsp)
  a2c967:	movaps %xmm0,0x40(%rsp)
  a2c96c:	lea    0x78(%rsp),%rdi
  a2c971:	lea    0x40(%rsp),%rsi
  a2c976:	call   a29de0 <gpui::native::platform::<softbuffer::error::SoftBufferError>>
  a2c97b:	movups 0x78(%rsp),%xmm0
  a2c980:	movups 0x88(%rsp),%xmm1
  a2c988:	movups 0x98(%rsp),%xmm2
  a2c990:	movups %xmm1,0x10(%rbx)
  a2c994:	movups %xmm2,0x20(%rbx)
  a2c998:	mov    0xa8(%rsp),%rax
  a2c9a0:	mov    %rax,0x30(%rbx)
  a2c9a4:	movups %xmm0,(%rbx)
  a2c9a7:	jmp    a2cac2 <<gpui::native::NativeHost<empty::Empty>>::create_cpu_surface+0x1e2>
  a2c9ac:	movq   $0xfffffffffffffffe,(%rbx)
  a2c9b3:	jmp    a2cac2 <<gpui::native::NativeHost<empty::Empty>>::create_cpu_surface+0x1e2>
  a2c9b8:	mov    0x10(%rsp),%rax
  a2c9bd:	mov    %rax,(%rsp)
  a2c9c1:	lock incq (%r12)
  a2c9c6:	jle    a2cad2 <<gpui::native::NativeHost<empty::Empty>>::create_cpu_surface+0x1f2>
  a2c9cc:	lea    0x8(%rsp),%rdi
  a2c9d1:	mov    %rsp,%rsi
  a2c9d4:	mov    %r12,%rdx
  a2c9d7:	call   a3a340 <<softbuffer::Surface<alloc::sync::Arc<winit::window::Window>, alloc::sync::Arc<winit::window::Window>>>::new>
  a2c9dc:	cmpl   $0xffffffff,0x8(%rsp)
  a2c9e1:	je     a2ca48 <<gpui::native::NativeHost<empty::Empty>>::create_cpu_surface+0x168>
  a2c9e3:	mov    0x38(%rsp),%rax
  a2c9e8:	mov    %rax,0x70(%rsp)
  a2c9ed:	movups 0x8(%rsp),%xmm0
  a2c9f2:	movups 0x18(%rsp),%xmm1
  a2c9f7:	movups 0x28(%rsp),%xmm2
  a2c9fc:	movaps %xmm2,0x60(%rsp)
  a2ca01:	movaps %xmm1,0x50(%rsp)
  a2ca06:	movaps %xmm0,0x40(%rsp)
  a2ca0b:	lea    0x78(%rsp),%rdi
  a2ca10:	lea    0x40(%rsp),%rsi
  a2ca15:	call   a29de0 <gpui::native::platform::<softbuffer::error::SoftBufferError>>
  a2ca1a:	movups 0x78(%rsp),%xmm0
  a2ca1f:	movups 0x88(%rsp),%xmm1
  a2ca27:	movups 0x98(%rsp),%xmm2
  a2ca2f:	movups %xmm1,0x10(%rbx)
  a2ca33:	movups %xmm2,0x20(%rbx)
  a2ca37:	mov    0xa8(%rsp),%rax
  a2ca3f:	mov    %rax,0x30(%rbx)
  a2ca43:	movups %xmm0,(%rbx)
  a2ca46:	jmp    a2cab0 <<gpui::native::NativeHost<empty::Empty>>::create_cpu_surface+0x1d0>
  a2ca48:	mov    0x10(%rsp),%r12
  a2ca4d:	movzwl 0x188(%r14),%eax
  a2ca55:	cmp    $0x2,%eax
  a2ca58:	je     a2ca78 <<gpui::native::NativeHost<empty::Empty>>::create_cpu_surface+0x198>
  a2ca5a:	test   %eax,%eax
  a2ca5c:	jne    a2ca6c <<gpui::native::NativeHost<empty::Empty>>::create_cpu_surface+0x18c>
  a2ca5e:	mov    0x190(%r14),%rdi
  a2ca65:	call   a26d40 <core::ptr::drop_glue::<alloc::boxed::Box<gpui::native::GpuSurface>>>
  a2ca6a:	jmp    a2ca78 <<gpui::native::NativeHost<empty::Empty>>::create_cpu_surface+0x198>
  a2ca6c:	mov    0x1a8(%r14),%rdi
  a2ca73:	call   a251b0 <core::ptr::drop_glue::<softbuffer::Surface<alloc::sync::Arc<winit::window::Window>, alloc::sync::Arc<winit::window::Window>>>>
  a2ca78:	movw   $0x1,0x188(%r14)
  a2ca82:	xorps  %xmm0,%xmm0
  a2ca85:	movups %xmm0,0x18a(%r14)
  a2ca8d:	movups %xmm0,0x193(%r14)
  a2ca95:	mov    %r12,0x1a8(%r14)
  a2ca9c:	shl    $0x20,%r15
  a2caa0:	mov    %ebp,%edx
  a2caa2:	or     %r15,%rdx
  a2caa5:	mov    %rbx,%rdi
  a2caa8:	mov    %r14,%rsi
  a2caab:	call   a2d650 <<gpui::native::NativeHost<empty::Empty>>::resize>
  a2cab0:	mov    (%rsp),%rax
  a2cab4:	lock decq (%rax)
  a2cab8:	jne    a2cac2 <<gpui::native::NativeHost<empty::Empty>>::create_cpu_surface+0x1e2>
  a2caba:	mov    %rsp,%rdi
  a2cabd:	call   a3a6e0 <<alloc::sync::Arc<softbuffer::backends::x11::X11DisplayImpl<alloc::sync::Arc<winit::window::Window>>>>::drop_slow>
  a2cac2:	add    $0xb0,%rsp
  a2cac9:	pop    %rbx
  a2caca:	pop    %r12
  a2cacc:	pop    %r14
  a2cace:	pop    %r15
  a2cad0:	pop    %rbp
  a2cad1:	ret
  a2cad2:	ud2
  a2cad4:	mov    %rax,%rbx
  a2cad7:	movw   $0x1,0x188(%r14)
  a2cae1:	xorps  %xmm0,%xmm0
  a2cae4:	movups %xmm0,0x18a(%r14)
  a2caec:	movups %xmm0,0x193(%r14)
  a2caf4:	mov    %r12,0x1a8(%r14)
  a2cafb:	jmp    a2cb00 <<gpui::native::NativeHost<empty::Empty>>::create_cpu_surface+0x220>
  a2cafd:	mov    %rax,%rbx
  a2cb00:	mov    (%rsp),%rax
  a2cb04:	lock decq (%rax)
  a2cb08:	jne    a2cb12 <<gpui::native::NativeHost<empty::Empty>>::create_cpu_surface+0x232>
  a2cb0a:	mov    %rsp,%rdi
  a2cb0d:	call   a3a6e0 <<alloc::sync::Arc<softbuffer::backends::x11::X11DisplayImpl<alloc::sync::Arc<winit::window::Window>>>>::drop_slow>
  a2cb12:	mov    %rbx,%rdi
  a2cb15:	call   14b7130 <_Unwind_Resume@plt>
  a2cb1a:	call   *0xaffd00(%rip)        # 152c820 <_DYNAMIC+0x288>


/tmp/gpui-a11y-owner-channel-captures/release-candidate/empty:     file format elf64-x86-64


Disassembly of section .text:

0000000000a2cb20 <<gpui::native::NativeHost<empty::Empty>>::redraw>:
  a2cb20:	push   %rbp
  a2cb21:	push   %r15
  a2cb23:	push   %r14
  a2cb25:	push   %r13
  a2cb27:	push   %r12
  a2cb29:	push   %rbx
  a2cb2a:	sub    $0x188,%rsp
  a2cb31:	mov    %rsi,%r14
  a2cb34:	mov    %rdi,%rbx
  a2cb37:	mov    0x1d8(%rsi),%rdi
  a2cb3e:	test   %rdi,%rdi
  a2cb41:	je     a2cb59 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x39>
  a2cb43:	add    $0x10,%rdi
  a2cb47:	call   *0xb00e23(%rip)        # 152d970 <_DYNAMIC+0x13d8>
  a2cb4d:	cmp    $0x1,%al
  a2cb4f:	je     a2cb59 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x39>
  a2cb51:	movb   $0x1,0x205(%r14)
  a2cb59:	mov    0x180(%r14),%ebp
  a2cb60:	cmp    $0xffffffff,%ebp
  a2cb63:	je     a2cb86 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x66>
  a2cb65:	mov    0x178(%r14),%r15
  a2cb6c:	call   *0xb00936(%rip)        # 152d4a8 <_DYNAMIC+0xf10>
  a2cb72:	cmp    %rax,%r15
  a2cb75:	jne    a2cb80 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x60>
  a2cb77:	cmp    %edx,%ebp
  a2cb79:	jbe    a2cb86 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x66>
  a2cb7b:	jmp    a2cda8 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x288>
  a2cb80:	jg     a2cda8 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x288>
  a2cb86:	movl   $0xffffffff,0x180(%r14)
  a2cb91:	mov    0x1d8(%r14),%rdi
  a2cb98:	test   %rdi,%rdi
  a2cb9b:	je     a2cda8 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x288>
  a2cba1:	add    $0x10,%rdi
  a2cba5:	call   a2d930 <<winit::window::Window>::inner_size>
  a2cbaa:	test   %eax,%eax
  a2cbac:	je     a2cda0 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x280>
  a2cbb2:	mov    %edx,%r15d
  a2cbb5:	test   %edx,%edx
  a2cbb7:	je     a2cda0 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x280>
  a2cbbd:	cmpb   $0x0,0x204(%r14)
  a2cbc5:	jne    a2cda0 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x280>
  a2cbcb:	mov    %eax,%r13d
  a2cbce:	mov    0x1d8(%r14),%r12
  a2cbd5:	test   %r12,%r12
  a2cbd8:	je     a2cd00 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x1e0>
  a2cbde:	mov    0xb006fb(%rip),%rax        # 152d2e0 <_DYNAMIC+0xd48>
  a2cbe5:	mov    (%rax),%rax
  a2cbe8:	cmp    $0x1,%rax
  a2cbec:	ja     a2cc6c <<gpui::native::NativeHost<empty::Empty>>::redraw+0x14c>
  a2cbee:	mov    0xb00d83(%rip),%rbp        # 152d978 <_DYNAMIC+0x13e0>
  a2cbf5:	movzbl 0x10(%rbp),%eax
  a2cbf9:	movzbl %al,%ecx
  a2cbfc:	lea    -0x1(%rcx),%edx
  a2cbff:	cmp    $0x2,%edx
  a2cc02:	jae    a2cc64 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x144>
  a2cc04:	mov    0x0(%rbp),%rdi
  a2cc08:	movzbl %al,%esi
  a2cc0b:	call   *0xb006df(%rip)        # 152d2f0 <_DYNAMIC+0xd58>
  a2cc11:	test   %al,%al
  a2cc13:	je     a2cc6c <<gpui::native::NativeHost<empty::Empty>>::redraw+0x14c>
  a2cc15:	mov    0x0(%rbp),%rsi
  a2cc19:	lea    0x30(%rsi),%rax
  a2cc1d:	movq   $0x1,(%rsp)
  a2cc25:	movq   $0x8,0x8(%rsp)
  a2cc2e:	movq   $0x0,0x10(%rsp)
  a2cc37:	mov    %rax,0x18(%rsp)
  a2cc3c:	lea    0x60(%rsp),%rdi
  a2cc41:	mov    %rsp,%rdx
  a2cc44:	call   *0xb00c56(%rip)        # 152d8a0 <_DYNAMIC+0x1308>
  a2cc4a:	cmpq   $0x2,0x60(%rsp)
  a2cc50:	je     a2cc81 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x161>
  a2cc52:	lea    0x78(%rsp),%rsi
  a2cc57:	lea    0x60(%rsp),%rdi
  a2cc5c:	call   *0xb00c46(%rip)        # 152d8a8 <_DYNAMIC+0x1310>
  a2cc62:	jmp    a2cc81 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x161>
  a2cc64:	test   %ecx,%ecx
  a2cc66:	jne    a2d52f <<gpui::native::NativeHost<empty::Empty>>::redraw+0xa0f>
  a2cc6c:	movq   $0x2,0x60(%rsp)
  a2cc75:	movq   $0x0,0x80(%rsp)
  a2cc81:	mov    0x80(%rsp),%rax
  a2cc89:	mov    %rax,0x20(%rsp)
  a2cc8e:	mov    0x60(%rsp),%rax
  a2cc93:	mov    0x68(%rsp),%rcx
  a2cc98:	movups 0x70(%rsp),%xmm0
  a2cc9d:	movaps %xmm0,0x10(%rsp)
  a2cca2:	mov    %rax,(%rsp)
  a2cca6:	mov    %rcx,0x8(%rsp)
  a2ccab:	mov    0x10(%r12),%rdi
  a2ccb0:	add    $0x10,%rdi
  a2ccb4:	call   *0xb001ee(%rip)        # 152cea8 <_DYNAMIC+0x910>
  a2ccba:	mov    %rax,%r12
  a2ccbd:	movzbl 0x284(%rax),%ebp
  a2ccc4:	test   $0x1,%dl
  a2ccc7:	jne    a2ccdf <<gpui::native::NativeHost<empty::Empty>>::redraw+0x1bf>
  a2ccc9:	mov    0xb001e8(%rip),%rax        # 152ceb8 <_DYNAMIC+0x920>
  a2ccd0:	mov    (%rax),%rax
  a2ccd3:	shl    $1,%rax
  a2ccd6:	test   %rax,%rax
  a2ccd9:	jne    a2d516 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x9f6>
  a2ccdf:	xor    %eax,%eax
  a2cce1:	xchg   %eax,(%r12)
  a2cce5:	cmp    $0x2,%eax
  a2cce8:	je     a2d508 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x9e8>
  a2ccee:	mov    %rsp,%rdi
  a2ccf1:	call   a28b10 <core::ptr::drop_glue::<tracing::span::EnteredSpan>>
  a2ccf6:	cmp    $0x1,%bpl
  a2ccfa:	jne    a2cda0 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x280>
  a2cd00:	lea    0x188(%r14),%r12
  a2cd07:	movzwl 0x188(%r14),%eax
  a2cd0f:	cmp    $0x1,%ax
  a2cd13:	jne    a2cdc1 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x2a1>
  a2cd19:	lea    0x60(%rsp),%rdi
  a2cd1e:	mov    %r14,%rsi
  a2cd21:	call   a2b150 <<gpui::native::NativeHost<empty::Empty>>::try_upgrade>
  a2cd26:	mov    0x60(%rsp),%rcx
  a2cd2b:	movzbl 0x68(%rsp),%eax
  a2cd30:	cmp    $0xfffffffffffffffe,%rcx
  a2cd34:	jne    a2d07d <<gpui::native::NativeHost<empty::Empty>>::redraw+0x55d>
  a2cd3a:	test   $0x1,%al
  a2cd3c:	jne    a2cda8 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x288>
  a2cd3e:	movzwl (%r12),%eax
  a2cd43:	cmp    $0x1,%ax
  a2cd47:	jne    a2cdc1 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x2a1>
  a2cd49:	movzbl 0x205(%r14),%ebp
  a2cd51:	movzbl %bpl,%edx
  a2cd55:	lea    0x60(%rsp),%rdi
  a2cd5a:	mov    %r14,%rsi
  a2cd5d:	call   a2aa20 <<gpui::native::NativeHost<empty::Empty>>::present_cpu>
  a2cd62:	cmpb   $0x0,0x60(%rsp)
  a2cd67:	je     a2d1cc <<gpui::native::NativeHost<empty::Empty>>::redraw+0x6ac>
  a2cd6d:	mov    0x98(%rsp),%rax
  a2cd75:	mov    %rax,0x30(%rbx)
  a2cd79:	movups 0x68(%rsp),%xmm0
  a2cd7e:	movups 0x78(%rsp),%xmm1
  a2cd83:	movups 0x88(%rsp),%xmm2
  a2cd8b:	movups %xmm2,0x20(%rbx)
  a2cd8f:	movups %xmm1,0x10(%rbx)
  a2cd93:	movups %xmm0,(%rbx)
  a2cd96:	movb   $0x1,0x205(%r14)
  a2cd9e:	jmp    a2cdaf <<gpui::native::NativeHost<empty::Empty>>::redraw+0x28f>
  a2cda0:	movb   $0x1,0x205(%r14)
  a2cda8:	movq   $0xfffffffffffffffe,(%rbx)
  a2cdaf:	add    $0x188,%rsp
  a2cdb6:	pop    %rbx
  a2cdb7:	pop    %r12
  a2cdb9:	pop    %r13
  a2cdbb:	pop    %r14
  a2cdbd:	pop    %r15
  a2cdbf:	pop    %rbp
  a2cdc0:	ret
  a2cdc1:	cmp    $0x2,%ax
  a2cdc5:	sete   %cl
  a2cdc8:	or     %cl,%al
  a2cdca:	test   $0x1,%al
  a2cdcc:	jne    a2cda8 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x288>
  a2cdce:	lea    0x30(%r14),%rax
  a2cdd2:	mov    %rax,0xc8(%rsp)
  a2cdda:	lea    0x1d0(%r14),%rbp
  a2cde1:	shl    $0x20,%r15
  a2cde5:	mov    %r13d,%r13d
  a2cde8:	or     %r15,%r13
  a2cdeb:	lea    0x68(%rsp),%r15
  a2cdf0:	mov    $0x378,%esi
  a2cdf5:	add    0x190(%r14),%rsi
  a2cdfc:	lea    0x60(%rsp),%rdi
  a2ce01:	call   *0xb00b01(%rip)        # 152d908 <_DYNAMIC+0x1370>
  a2ce07:	mov    0x60(%rsp),%rax
  a2ce0c:	lea    -0x897e47(%rip),%rcx        # 194fcc <anon.41931c7f01a0f669fcd75d8bc79f57d6.412.llvm.13234298307199123836+0xba>
  a2ce13:	movslq (%rcx,%rax,4),%rax
  a2ce17:	add    %rcx,%rax
  a2ce1a:	jmp    *%rax
  a2ce1c:	movups 0x50(%r15),%xmm0
  a2ce21:	movaps %xmm0,0x120(%rsp)
  a2ce29:	movups 0x40(%r15),%xmm0
  a2ce2e:	movaps %xmm0,0x110(%rsp)
  a2ce36:	movups (%r15),%xmm0
  a2ce3a:	movups 0x10(%r15),%xmm1
  a2ce3f:	movups 0x20(%r15),%xmm2
  a2ce44:	movups 0x30(%r15),%xmm3
  a2ce49:	movaps %xmm3,0x100(%rsp)
  a2ce51:	movaps %xmm2,0xf0(%rsp)
  a2ce59:	movaps %xmm1,0xe0(%rsp)
  a2ce61:	movaps %xmm0,0xd0(%rsp)
  a2ce69:	cmpb   $0x0,(%r14)
  a2ce6d:	je     a2d549 <<gpui::native::NativeHost<empty::Empty>>::redraw+0xa29>
  a2ce73:	lea    0xd8(%rsp),%rsi
  a2ce7b:	movq   $0x0,0x18(%rsp)
  a2ce84:	movl   $0xffffffff,0x30(%rsp)
  a2ce8c:	movl   $0x0,(%rsp)
  a2ce93:	movabs $0xffffffff00000000,%rax
  a2ce9d:	mov    %rax,0x28(%rsp)
  a2cea2:	movq   $0x0,0x3c(%rsp)
  a2ceab:	movl   $0x0,0x8(%rsp)
  a2ceb3:	movl   $0x0,0x10(%rsp)
  a2cebb:	lea    0x130(%rsp),%rdi
  a2cec3:	mov    %rsp,%rdx
  a2cec6:	call   *0xb00a44(%rip)        # 152d910 <_DYNAMIC+0x1378>
  a2cecc:	mov    0x190(%r14),%rdx
  a2ced3:	mov    %rsp,%rdi
  a2ced6:	lea    0x130(%rsp),%rcx
  a2cede:	lea    0x8(%r14),%rsi
  a2cee2:	call   9ad550 <<gpui::runtime::Win<empty::Empty>>::with_paint_scene::<core::result::Result<gpui::runtime::PresentationToken, gpui_gpu::renderer::Error>, <gpui::native::NativeHost<empty::Empty>>::try_upgrade::{closure#0}::{closure#0}>>
  a2cee7:	mov    (%rsp),%rax
  a2ceeb:	movsd  0x8(%rsp),%xmm0
  a2cef1:	mov    0x10(%rsp),%r13
  a2cef6:	movups 0x18(%rsp),%xmm1
  a2cefb:	cmp    $0xfffffffffffffffe,%rax
  a2ceff:	jne    a2d21e <<gpui::native::NativeHost<empty::Empty>>::redraw+0x6fe>
  a2cf05:	mov    0x8(%rsp),%ecx
  a2cf09:	cmp    $0xffffffff,%ecx
  a2cf0c:	je     a2d3c6 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x8a6>
  a2cf12:	mov    $0x2c,%eax
  a2cf17:	cmp    $0x5,%ecx
  a2cf1a:	jb     a2d227 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x707>
  a2cf20:	cmpb   $0x0,0x207(%r14)
  a2cf28:	jne    a2d227 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x707>
  a2cf2e:	mov    0x180(%rsp),%rax
  a2cf36:	mov    %rax,0x50(%rsp)
  a2cf3b:	movups 0x170(%rsp),%xmm0
  a2cf43:	movaps %xmm0,0x40(%rsp)
  a2cf48:	movups 0x130(%rsp),%xmm0
  a2cf50:	movups 0x140(%rsp),%xmm1
  a2cf58:	movups 0x150(%rsp),%xmm2
  a2cf60:	movups 0x160(%rsp),%xmm3
  a2cf68:	movaps %xmm3,0x30(%rsp)
  a2cf6d:	movaps %xmm2,0x20(%rsp)
  a2cf72:	movaps %xmm1,0x10(%rsp)
  a2cf77:	movaps %xmm0,(%rsp)
  a2cf7b:	mov    %rsp,%rdi
  a2cf7e:	call   a28eb0 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  a2cf83:	movaps 0x120(%rsp),%xmm0
  a2cf8b:	movaps %xmm0,0x50(%rsp)
  a2cf90:	movaps 0x110(%rsp),%xmm0
  a2cf98:	movaps %xmm0,0x40(%rsp)
  a2cf9d:	movaps 0xd0(%rsp),%xmm0
  a2cfa5:	movaps 0xe0(%rsp),%xmm1
  a2cfad:	movaps 0xf0(%rsp),%xmm2
  a2cfb5:	movaps 0x100(%rsp),%xmm3
  a2cfbd:	movaps %xmm3,0x30(%rsp)
  a2cfc2:	movaps %xmm2,0x20(%rsp)
  a2cfc7:	movaps %xmm1,0x10(%rsp)
  a2cfcc:	movaps %xmm0,(%rsp)
  a2cfd0:	mov    %rsp,%rdi
  a2cfd3:	call   a28f20 <core::ptr::drop_glue::<wgpu::api::surface_texture::SurfaceTexture>>
  a2cfd8:	lea    0x8(%r14),%rax
  a2cfdc:	mov    (%rax),%rax
  a2cfdf:	test   %rax,%rax
  a2cfe2:	je     a2d261 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x741>
  a2cfe8:	mov    $0xe,%ecx
  a2cfed:	cmpb   $0x0,0x72e(%rax)
  a2cff4:	jne    a2d266 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x746>
  a2cffa:	movb   $0x0,0x72c(%rax)
  a2d001:	mov    %r12,%rdi
  a2d004:	call   a26240 <core::ptr::drop_glue::<core::option::Option<gpui::native::Graphics>>>
  a2d009:	movw   $0x2,(%r12)
  a2d010:	mov    0x0(%rbp),%rax
  a2d014:	test   %rax,%rax
  a2d017:	je     a2d028 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x508>
  a2d019:	lock decq (%rax)
  a2d01d:	jne    a2d028 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x508>
  a2d01f:	mov    %rbp,%rdi
  a2d022:	call   *0xb000e8(%rip)        # 152d110 <_DYNAMIC+0xb78>
  a2d028:	movq   $0x0,0x0(%rbp)
  a2d030:	lea    0x30(%r14),%r12
  a2d034:	mov    %r12,%rdi
  a2d037:	call   a26480 <core::ptr::drop_glue::<core::option::Option<gpui::native::upgrade::Upgrade>>>
  a2d03c:	movq   $0xffffffffffffffff,0x30(%r14)
  a2d044:	movb   $0x1,0x206(%r14)
  a2d04c:	mov    %rsp,%rdi
  a2d04f:	mov    %r14,%rsi
  a2d052:	call   a2c8e0 <<gpui::native::NativeHost<empty::Empty>>::create_cpu_surface>
  a2d057:	cmpl   $0xfffffffe,(%rsp)
  a2d05b:	jne    a2d38b <<gpui::native::NativeHost<empty::Empty>>::redraw+0x86b>
  a2d061:	mov    %rbx,%rdi
  a2d064:	mov    %r14,%rsi
  a2d067:	call   a2cb20 <<gpui::native::NativeHost<empty::Empty>>::redraw>
  a2d06c:	cmpq   $0x1,0x60(%rsp)
  a2d072:	jne    a2cdaf <<gpui::native::NativeHost<empty::Empty>>::redraw+0x28f>
  a2d078:	jmp    a2d3b9 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x899>
  a2d07d:	movups 0x69(%rsp),%xmm0
  a2d082:	movups 0x79(%rsp),%xmm1
  a2d087:	movups 0x88(%rsp),%xmm2
  a2d08f:	movups %xmm2,0x28(%rbx)
  a2d093:	movups %xmm1,0x19(%rbx)
  a2d097:	movups %xmm0,0x9(%rbx)
  a2d09b:	mov    %rcx,(%rbx)
  a2d09e:	mov    %al,0x8(%rbx)
  a2d0a1:	jmp    a2cdaf <<gpui::native::NativeHost<empty::Empty>>::redraw+0x28f>
  a2d0a6:	movups 0x50(%r15),%xmm0
  a2d0ab:	movaps %xmm0,0x50(%rsp)
  a2d0b0:	movups 0x40(%r15),%xmm0
  a2d0b5:	movaps %xmm0,0x40(%rsp)
  a2d0ba:	movups (%r15),%xmm0
  a2d0be:	movups 0x10(%r15),%xmm1
  a2d0c3:	movups 0x20(%r15),%xmm2
  a2d0c8:	movups 0x30(%r15),%xmm3
  a2d0cd:	movaps %xmm3,0x30(%rsp)
  a2d0d2:	movaps %xmm2,0x20(%rsp)
  a2d0d7:	movaps %xmm1,0x10(%rsp)
  a2d0dc:	movaps %xmm0,(%rsp)
  a2d0e0:	mov    %rsp,%rdi
  a2d0e3:	call   a28f20 <core::ptr::drop_glue::<wgpu::api::surface_texture::SurfaceTexture>>
  a2d0e8:	mov    %rsp,%rdi
  a2d0eb:	mov    %r14,%rsi
  a2d0ee:	mov    %r13,%rdx
  a2d0f1:	call   a2d650 <<gpui::native::NativeHost<empty::Empty>>::resize>
  a2d0f6:	cmpl   $0xfffffffe,(%rsp)
  a2d0fa:	je     a2d2ad <<gpui::native::NativeHost<empty::Empty>>::redraw+0x78d>
  a2d100:	mov    0x30(%rsp),%rax
  a2d105:	mov    %rax,0x30(%rbx)
  a2d109:	movups (%rsp),%xmm0
  a2d10d:	movups 0x10(%rsp),%xmm1
  a2d112:	movups 0x20(%rsp),%xmm2
  a2d117:	movups %xmm2,0x20(%rbx)
  a2d11b:	movups %xmm1,0x10(%rbx)
  a2d11f:	movups %xmm0,(%rbx)
  a2d122:	jmp    a2cdaf <<gpui::native::NativeHost<empty::Empty>>::redraw+0x28f>
  a2d127:	mov    %rsp,%rdi
  a2d12a:	mov    %r14,%rsi
  a2d12d:	mov    %r13,%rdx
  a2d130:	call   a2d650 <<gpui::native::NativeHost<empty::Empty>>::resize>
  a2d135:	jmp    a2d2a3 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x783>
  a2d13a:	cmpl   $0x1,(%r14)
  a2d13e:	jne    a2d169 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x649>
  a2d140:	lea    0x8(%r14),%rax
  a2d144:	mov    (%rax),%rax
  a2d147:	test   %rax,%rax
  a2d14a:	je     a2d261 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x741>
  a2d150:	mov    $0xe,%ecx
  a2d155:	cmpb   $0x0,0x72e(%rax)
  a2d15c:	jne    a2d266 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x746>
  a2d162:	movb   $0x0,0x72c(%rax)
  a2d169:	lea    0x30(%r14),%rdi
  a2d16d:	call   a26480 <core::ptr::drop_glue::<core::option::Option<gpui::native::upgrade::Upgrade>>>
  a2d172:	movq   $0xffffffffffffffff,0x30(%r14)
  a2d17a:	movb   $0x0,0x206(%r14)
  a2d182:	mov    0x1d0(%r14),%rax
  a2d189:	test   %rax,%rax
  a2d18c:	je     a2d19d <<gpui::native::NativeHost<empty::Empty>>::redraw+0x67d>
  a2d18e:	lock decq (%rax)
  a2d192:	jne    a2d19d <<gpui::native::NativeHost<empty::Empty>>::redraw+0x67d>
  a2d194:	mov    %rbp,%rdi
  a2d197:	call   *0xafff73(%rip)        # 152d110 <_DYNAMIC+0xb78>
  a2d19d:	movq   $0x0,0x0(%rbp)
  a2d1a5:	movzwl (%r12),%eax
  a2d1aa:	cmp    $0x2,%eax
  a2d1ad:	je     a2d28e <<gpui::native::NativeHost<empty::Empty>>::redraw+0x76e>
  a2d1b3:	test   %eax,%eax
  a2d1b5:	jne    a2d282 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x762>
  a2d1bb:	mov    0x190(%r14),%rdi
  a2d1c2:	call   a26d40 <core::ptr::drop_glue::<alloc::boxed::Box<gpui::native::GpuSurface>>>
  a2d1c7:	jmp    a2d28e <<gpui::native::NativeHost<empty::Empty>>::redraw+0x76e>
  a2d1cc:	test   %bpl,%bpl
  a2d1cf:	je     a2d1d9 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x6b9>
  a2d1d1:	movb   $0x0,0x205(%r14)
  a2d1d9:	movzbl 0x98(%rsp),%ebp
  a2d1e1:	mov    0x1f0(%r14),%rdi
  a2d1e8:	test   %rdi,%rdi
  a2d1eb:	je     a2d208 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x6e8>
  a2d1ed:	movups 0x78(%rsp),%xmm0
  a2d1f2:	mov    0x1f8(%r14),%rax
  a2d1f9:	movaps %xmm0,(%rsp)
  a2d1fd:	movb   $0x0,0x10(%rsp)
  a2d202:	mov    %rsp,%rsi
  a2d205:	call   *0x20(%rax)
  a2d208:	test   %bpl,%bpl
  a2d20b:	je     a2cda8 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x288>
  a2d211:	mov    %r14,%rdi
  a2d214:	call   a2bd40 <<gpui::native::NativeHost<empty::Empty>>::start_upgrade>
  a2d219:	jmp    a2cda8 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x288>
  a2d21e:	movups 0x28(%rsp),%xmm2
  a2d223:	movups %xmm2,0x28(%rbx)
  a2d227:	movlps %xmm0,0x8(%rbx)
  a2d22b:	mov    %r13,0x10(%rbx)
  a2d22f:	movups %xmm1,0x18(%rbx)
  a2d233:	mov    %rax,(%rbx)
  a2d236:	lea    0x130(%rsp),%rdi
  a2d23e:	call   a28eb0 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  a2d243:	lea    0xd0(%rsp),%rdi
  a2d24b:	call   a28f20 <core::ptr::drop_glue::<wgpu::api::surface_texture::SurfaceTexture>>
  a2d250:	cmpq   $0x1,0x60(%rsp)
  a2d256:	jne    a2cdaf <<gpui::native::NativeHost<empty::Empty>>::redraw+0x28f>
  a2d25c:	jmp    a2d3b9 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x899>
  a2d261:	mov    $0xd,%ecx
  a2d266:	mov    %rcx,(%rbx)
  a2d269:	movq   $0x0,0x8(%rbx)
  a2d271:	cmpq   $0x1,0x60(%rsp)
  a2d277:	jne    a2cdaf <<gpui::native::NativeHost<empty::Empty>>::redraw+0x28f>
  a2d27d:	jmp    a2d3b9 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x899>
  a2d282:	mov    0x1a8(%r14),%rdi
  a2d289:	call   a251b0 <core::ptr::drop_glue::<softbuffer::Surface<alloc::sync::Arc<winit::window::Window>, alloc::sync::Arc<winit::window::Window>>>>
  a2d28e:	movw   $0x2,0x188(%r14)
  a2d298:	mov    %rsp,%rdi
  a2d29b:	mov    %r14,%rsi
  a2d29e:	call   a2bef0 <<gpui::native::NativeHost<empty::Empty>>::create_surface>
  a2d2a3:	cmpl   $0xfffffffe,(%rsp)
  a2d2a7:	jne    a2d38b <<gpui::native::NativeHost<empty::Empty>>::redraw+0x86b>
  a2d2ad:	movzwl (%r12),%eax
  a2d2b2:	cmp    $0x2,%ax
  a2d2b6:	sete   %cl
  a2d2b9:	or     %cl,%al
  a2d2bb:	test   $0x1,%al
  a2d2bd:	jne    a2cda8 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x288>
  a2d2c3:	mov    $0x378,%esi
  a2d2c8:	add    0x190(%r14),%rsi
  a2d2cf:	lea    0x60(%rsp),%rdi
  a2d2d4:	call   *0xb0062e(%rip)        # 152d908 <_DYNAMIC+0x1370>
  a2d2da:	mov    0x60(%rsp),%rax
  a2d2df:	lea    -0x8982fe(%rip),%rcx        # 194fe8 <anon.41931c7f01a0f669fcd75d8bc79f57d6.412.llvm.13234298307199123836+0xd6>
  a2d2e6:	movslq (%rcx,%rax,4),%rax
  a2d2ea:	add    %rcx,%rax
  a2d2ed:	jmp    *%rax
  a2d2ef:	movzbl 0x209(%r14),%r12d
  a2d2f7:	cmp    $0x3,%r12
  a2d2fb:	jae    a2d376 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x856>
  a2d2fd:	lea    -0x89802c(%rip),%r13        # 1952d8 <anon.41931c7f01a0f669fcd75d8bc79f57d6.412.llvm.13234298307199123836+0x3c6>
  a2d304:	lea    0x1(%r12),%eax
  a2d309:	mov    %al,0x209(%r14)
  a2d310:	call   *0xb00192(%rip)        # 152d4a8 <_DYNAMIC+0xf10>
  a2d316:	mov    %rax,%rdi
  a2d319:	mov    %edx,%esi
  a2d31b:	mov    0x0(%r13,%r12,8),%rcx
  a2d320:	mov    %rcx,%rax
  a2d323:	shr    $0x3,%rax
  a2d327:	movabs $0x20c49ba5e353f7cf,%rdx
  a2d331:	mul    %rdx
  a2d334:	shr    $0x4,%rdx
  a2d338:	imul   $0x3e8,%edx,%eax
  a2d33e:	sub    %eax,%ecx
  a2d340:	imul   $0xf4240,%ecx,%ecx
  a2d346:	lea    0xa8fb83(%rip),%r8        # 14bced0 <anon.fff2d4355c6109bc0e8af2445443084d.8.llvm.4725208967334239140+0x1c8>
  a2d34d:	call   *0xb0062d(%rip)        # 152d980 <_DYNAMIC+0x13e8>
  a2d353:	mov    %rax,0x178(%r14)
  a2d35a:	mov    %edx,0x180(%r14)
  a2d361:	movq   $0xfffffffffffffffe,(%rbx)
  a2d368:	cmpq   $0x1,0x60(%rsp)
  a2d36e:	jne    a2cdaf <<gpui::native::NativeHost<empty::Empty>>::redraw+0x28f>
  a2d374:	jmp    a2d3b9 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x899>
  a2d376:	movq   $0x2f,(%rbx)
  a2d37d:	cmpq   $0x1,0x60(%rsp)
  a2d383:	jne    a2cdaf <<gpui::native::NativeHost<empty::Empty>>::redraw+0x28f>
  a2d389:	jmp    a2d3b9 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x899>
  a2d38b:	mov    0x30(%rsp),%rax
  a2d390:	mov    %rax,0x30(%rbx)
  a2d394:	movups (%rsp),%xmm0
  a2d398:	movups 0x10(%rsp),%xmm1
  a2d39d:	movups 0x20(%rsp),%xmm2
  a2d3a2:	movups %xmm2,0x20(%rbx)
  a2d3a6:	movups %xmm1,0x10(%rbx)
  a2d3aa:	movups %xmm0,(%rbx)
  a2d3ad:	cmpq   $0x1,0x60(%rsp)
  a2d3b3:	jne    a2cdaf <<gpui::native::NativeHost<empty::Empty>>::redraw+0x28f>
  a2d3b9:	mov    %r15,%rdi
  a2d3bc:	call   a28f20 <core::ptr::drop_glue::<wgpu::api::surface_texture::SurfaceTexture>>
  a2d3c1:	jmp    a2cdaf <<gpui::native::NativeHost<empty::Empty>>::redraw+0x28f>
  a2d3c6:	cmpq   $0x0,0x1d8(%r14)
  a2d3ce:	je     a2d564 <<gpui::native::NativeHost<empty::Empty>>::redraw+0xa44>
  a2d3d4:	mov    0x18(%rsp),%r12
  a2d3d9:	mov    $0x1,%bpl
  a2d3dc:	call   a2a910 <<winit::window::Window>::pre_present_notify>
  a2d3e1:	mov    $0x350,%edi
  a2d3e6:	add    0x190(%r14),%rdi
  a2d3ed:	movaps 0x120(%rsp),%xmm0
  a2d3f5:	movaps %xmm0,0x50(%rsp)
  a2d3fa:	movaps 0x110(%rsp),%xmm0
  a2d402:	movaps %xmm0,0x40(%rsp)
  a2d407:	movaps 0xd0(%rsp),%xmm0
  a2d40f:	movaps 0xe0(%rsp),%xmm1
  a2d417:	movaps 0xf0(%rsp),%xmm2
  a2d41f:	movaps 0x100(%rsp),%xmm3
  a2d427:	movaps %xmm3,0x30(%rsp)
  a2d42c:	movaps %xmm2,0x20(%rsp)
  a2d431:	movaps %xmm1,0x10(%rsp)
  a2d436:	movaps %xmm0,(%rsp)
  a2d43a:	xor    %ebp,%ebp
  a2d43c:	mov    %rsp,%rsi
  a2d43f:	call   *0xb004d3(%rip)        # 152d918 <_DYNAMIC+0x1380>
  a2d445:	lea    0x8(%r14),%rax
  a2d449:	mov    (%rax),%rsi
  a2d44c:	test   %rsi,%rsi
  a2d44f:	je     a2d4b5 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x995>
  a2d451:	mov    $0xe,%eax
  a2d456:	cmpb   $0x0,0x72e(%rsi)
  a2d45d:	jne    a2d4c3 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x9a3>
  a2d45f:	xor    %ebp,%ebp
  a2d461:	mov    %rsp,%rdi
  a2d464:	mov    %r13,%rdx
  a2d467:	mov    %r12,%rcx
  a2d46a:	call   9c3210 <<gpui::runtime::Runtime<empty::Empty>>::acknowledge>
  a2d46f:	mov    (%rsp),%rax
  a2d473:	cmp    $0xfffffffffffffffe,%rax
  a2d477:	jne    a2d4c3 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x9a3>
  a2d479:	mov    0x1f0(%r14),%rdi
  a2d480:	test   %rdi,%rdi
  a2d483:	je     a2d4a2 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x982>
  a2d485:	movups 0x18(%rsp),%xmm0
  a2d48a:	mov    0x1f8(%r14),%rax
  a2d491:	movaps %xmm0,(%rsp)
  a2d495:	movb   $0x1,0x10(%rsp)
  a2d49a:	xor    %ebp,%ebp
  a2d49c:	mov    %rsp,%rsi
  a2d49f:	call   *0x20(%rax)
  a2d4a2:	movw   $0x0,0x208(%r14)
  a2d4ac:	movq   $0xfffffffffffffffe,(%rbx)
  a2d4b3:	jmp    a2d4ea <<gpui::native::NativeHost<empty::Empty>>::redraw+0x9ca>
  a2d4b5:	movq   $0x0,0x8(%rsp)
  a2d4be:	mov    $0xd,%eax
  a2d4c3:	mov    0x8(%rsp),%rcx
  a2d4c8:	mov    %rcx,0x8(%rbx)
  a2d4cc:	mov    0x10(%rsp),%rcx
  a2d4d1:	mov    %rcx,0x10(%rbx)
  a2d4d5:	movups 0x28(%rsp),%xmm0
  a2d4da:	movups %xmm0,0x28(%rbx)
  a2d4de:	movups 0x18(%rsp),%xmm0
  a2d4e3:	mov    %rax,(%rbx)
  a2d4e6:	movups %xmm0,0x18(%rbx)
  a2d4ea:	lea    0x130(%rsp),%rdi
  a2d4f2:	call   a28eb0 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  a2d4f7:	cmpq   $0x1,0x60(%rsp)
  a2d4fd:	jne    a2cdaf <<gpui::native::NativeHost<empty::Empty>>::redraw+0x28f>
  a2d503:	jmp    a2d3b9 <<gpui::native::NativeHost<empty::Empty>>::redraw+0x899>
  a2d508:	mov    %r12,%rdi
  a2d50b:	call   *0xaff9cf(%rip)        # 152cee0 <_DYNAMIC+0x948>
  a2d511:	jmp    a2ccee <<gpui::native::NativeHost<empty::Empty>>::redraw+0x1ce>
  a2d516:	call   *0xaff9cc(%rip)        # 152cee8 <_DYNAMIC+0x950>
  a2d51c:	test   %al,%al
  a2d51e:	jne    a2ccdf <<gpui::native::NativeHost<empty::Empty>>::redraw+0x1bf>
  a2d524:	movb   $0x1,0x4(%r12)
  a2d52a:	jmp    a2ccdf <<gpui::native::NativeHost<empty::Empty>>::redraw+0x1bf>
  a2d52f:	mov    0xb00442(%rip),%rdi        # 152d978 <_DYNAMIC+0x13e0>
  a2d536:	call   *0xaffdc4(%rip)        # 152d300 <_DYNAMIC+0xd68>
  a2d53c:	test   %al,%al
  a2d53e:	jne    a2cc04 <<gpui::native::NativeHost<empty::Empty>>::redraw+0xe4>
  a2d544:	jmp    a2cc6c <<gpui::native::NativeHost<empty::Empty>>::redraw+0x14c>
  a2d549:	lea    -0x898320(%rip),%rdi        # 195230 <anon.41931c7f01a0f669fcd75d8bc79f57d6.412.llvm.13234298307199123836+0x31e>
  a2d550:	lea    0xa8f949(%rip),%rdx        # 14bcea0 <anon.fff2d4355c6109bc0e8af2445443084d.8.llvm.4725208967334239140+0x198>
  a2d557:	mov    $0x14,%esi
  a2d55c:	call   *0xaff3a6(%rip)        # 152c908 <_DYNAMIC+0x370>
  a2d562:	jmp    a2d574 <<gpui::native::NativeHost<empty::Empty>>::redraw+0xa54>
  a2d564:	mov    $0x1,%bpl
  a2d567:	lea    0xa8f94a(%rip),%rdi        # 14bceb8 <anon.fff2d4355c6109bc0e8af2445443084d.8.llvm.4725208967334239140+0x1b0>
  a2d56e:	call   *0xaff29c(%rip)        # 152c810 <_DYNAMIC+0x278>
  a2d574:	ud2
  a2d576:	movq   $0x0,0x0(%rbp)
  a2d57e:	mov    %rax,%rdi
  a2d581:	call   14b7130 <_Unwind_Resume@plt>
  a2d586:	movq   $0xffffffffffffffff,(%r12)
  a2d58e:	mov    %rax,%rdi
  a2d591:	call   14b7130 <_Unwind_Resume@plt>
  a2d596:	movw   $0x2,(%r12)
  a2d59d:	mov    %rax,%rdi
  a2d5a0:	call   14b7130 <_Unwind_Resume@plt>
  a2d5a5:	jmp    a2d62a <<gpui::native::NativeHost<empty::Empty>>::redraw+0xb0a>
  a2d5aa:	movq   $0x0,0x0(%rbp)
  a2d5b2:	mov    %rax,%rdi
  a2d5b5:	call   14b7130 <_Unwind_Resume@plt>
  a2d5ba:	movw   $0x2,(%r12)
  a2d5c1:	mov    %rax,%rdi
  a2d5c4:	call   14b7130 <_Unwind_Resume@plt>
  a2d5c9:	mov    %rax,%rbx
  a2d5cc:	mov    0xc8(%rsp),%rax
  a2d5d4:	movq   $0xffffffffffffffff,(%rax)
  a2d5db:	mov    %rbx,%rdi
  a2d5de:	call   14b7130 <_Unwind_Resume@plt>
  a2d5e3:	mov    %rax,%rbx
  a2d5e6:	mov    $0x1,%bpl
  a2d5e9:	jmp    a2d616 <<gpui::native::NativeHost<empty::Empty>>::redraw+0xaf6>
  a2d5eb:	mov    %rax,%rbx
  a2d5ee:	lea    0x60(%rsp),%rdi
  a2d5f3:	call   a28b90 <core::ptr::drop_glue::<tracing::span::Span>>
  a2d5f8:	jmp    a2d63a <<gpui::native::NativeHost<empty::Empty>>::redraw+0xb1a>
  a2d5fa:	call   *0xaff220(%rip)        # 152c820 <_DYNAMIC+0x288>
  a2d600:	mov    %rax,%rbx
  a2d603:	mov    %rsp,%rdi
  a2d606:	call   a28b10 <core::ptr::drop_glue::<tracing::span::EnteredSpan>>
  a2d60b:	jmp    a2d63a <<gpui::native::NativeHost<empty::Empty>>::redraw+0xb1a>
  a2d60d:	call   *0xaff20d(%rip)        # 152c820 <_DYNAMIC+0x288>
  a2d613:	mov    %rax,%rbx
  a2d616:	lea    0x130(%rsp),%rdi
  a2d61e:	call   a28eb0 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  a2d623:	test   %bpl,%bpl
  a2d626:	jne    a2d62d <<gpui::native::NativeHost<empty::Empty>>::redraw+0xb0d>
  a2d628:	jmp    a2d63a <<gpui::native::NativeHost<empty::Empty>>::redraw+0xb1a>
  a2d62a:	mov    %rax,%rbx
  a2d62d:	lea    0xd0(%rsp),%rdi
  a2d635:	call   a28f20 <core::ptr::drop_glue::<wgpu::api::surface_texture::SurfaceTexture>>
  a2d63a:	mov    %rbx,%rdi
  a2d63d:	call   14b7130 <_Unwind_Resume@plt>
  a2d642:	call   *0xaff1d8(%rip)        # 152c820 <_DYNAMIC+0x288>


/tmp/gpui-a11y-owner-channel-captures/release-candidate/empty:     file format elf64-x86-64


Disassembly of section .text:

0000000000a2d650 <<gpui::native::NativeHost<empty::Empty>>::resize>:
  a2d650:	push   %rbp
  a2d651:	push   %r15
  a2d653:	push   %r14
  a2d655:	push   %r13
  a2d657:	push   %r12
  a2d659:	push   %rbx
  a2d65a:	sub    $0x138,%rsp
  a2d661:	mov    %rdx,%r15
  a2d664:	mov    %rdi,%rbx
  a2d667:	movb   $0x1,0x205(%rsi)
  a2d66e:	mov    $0xffffffff,%eax
  a2d673:	mov    %rax,0x1b0(%rsi)
  a2d67a:	movq   $0x0,0x1b8(%rsi)
  a2d685:	test   %r15d,%r15d
  a2d688:	je     a2d8ce <<gpui::native::NativeHost<empty::Empty>>::resize+0x27e>
  a2d68e:	mov    %r15,%r12
  a2d691:	shr    $0x20,%r12
  a2d695:	je     a2d8ce <<gpui::native::NativeHost<empty::Empty>>::resize+0x27e>
  a2d69b:	mov    %rsi,%r14
  a2d69e:	movzwl 0x188(%rsi),%ebp
  a2d6a5:	cmp    $0x2,%bp
  a2d6a9:	sete   %al
  a2d6ac:	mov    %ebp,%ecx
  a2d6ae:	or     %al,%cl
  a2d6b0:	test   $0x1,%cl
  a2d6b3:	je     a2d7ab <<gpui::native::NativeHost<empty::Empty>>::resize+0x15b>
  a2d6b9:	lea    0x8(%r14),%r13
  a2d6bd:	cmpb   $0x0,(%r14)
  a2d6c1:	je     a2d707 <<gpui::native::NativeHost<empty::Empty>>::resize+0xb7>
  a2d6c3:	mov    0x1d8(%r14),%rdi
  a2d6ca:	test   %rdi,%rdi
  a2d6cd:	je     a2d918 <<gpui::native::NativeHost<empty::Empty>>::resize+0x2c8>
  a2d6d3:	add    $0x10,%rdi
  a2d6d7:	call   a2a600 <<winit::window::Window>::scale_factor>
  a2d6dc:	cvtsd2ss %xmm0,%xmm0
  a2d6e0:	lea    0x40(%rsp),%rdi
  a2d6e5:	mov    %r13,%rsi
  a2d6e8:	mov    %r15,%rdx
  a2d6eb:	call   9c2680 <<gpui::runtime::Win<empty::Empty>>::resize_scaled>
  a2d6f0:	mov    0x40(%rsp),%rax
  a2d6f5:	cmp    $0xfffffffffffffffe,%rax
  a2d6f9:	jne    a2d7f9 <<gpui::native::NativeHost<empty::Empty>>::resize+0x1a9>
  a2d6ff:	movzwl 0x188(%r14),%ebp
  a2d707:	cmp    $0x2,%bp
  a2d70b:	je     a2d8af <<gpui::native::NativeHost<empty::Empty>>::resize+0x25f>
  a2d711:	cmpb   $0x0,(%r14)
  a2d715:	je     a2d745 <<gpui::native::NativeHost<empty::Empty>>::resize+0xf5>
  a2d717:	mov    0x0(%r13),%rax
  a2d71b:	test   %rax,%rax
  a2d71e:	je     a2d8e7 <<gpui::native::NativeHost<empty::Empty>>::resize+0x297>
  a2d724:	mov    $0xe,%ecx
  a2d729:	cmpb   $0x0,0x72e(%rax)
  a2d730:	jne    a2d8ec <<gpui::native::NativeHost<empty::Empty>>::resize+0x29c>
  a2d736:	movb   $0x0,0x72c(%rax)
  a2d73d:	movzwl 0x188(%r14),%ebp
  a2d745:	test   $0x1,%bpl
  a2d749:	je     a2d832 <<gpui::native::NativeHost<empty::Empty>>::resize+0x1e2>
  a2d74f:	mov    0x1a8(%r14),%rsi
  a2d756:	lea    0x8(%rsp),%rdi
  a2d75b:	mov    %r15d,%edx
  a2d75e:	mov    %r12d,%ecx
  a2d761:	call   a09ca0 <<softbuffer::backends::x11::X11Impl<alloc::sync::Arc<winit::window::Window>, alloc::sync::Arc<winit::window::Window>> as softbuffer::backend_interface::SurfaceInterface<alloc::sync::Arc<winit::window::Window>, alloc::sync::Arc<winit::window::Window>>>::resize>
  a2d766:	cmpl   $0xffffffff,0x8(%rsp)
  a2d76b:	je     a2d8f9 <<gpui::native::NativeHost<empty::Empty>>::resize+0x2a9>
  a2d771:	mov    0x38(%rsp),%rax
  a2d776:	mov    %rax,0x70(%rsp)
  a2d77b:	movups 0x8(%rsp),%xmm0
  a2d780:	movups 0x18(%rsp),%xmm1
  a2d785:	movups 0x28(%rsp),%xmm2
  a2d78a:	movaps %xmm2,0x60(%rsp)
  a2d78f:	movaps %xmm1,0x50(%rsp)
  a2d794:	movaps %xmm0,0x40(%rsp)
  a2d799:	lea    0x40(%rsp),%rsi
  a2d79e:	mov    %rbx,%rdi
  a2d7a1:	call   a29de0 <gpui::native::platform::<softbuffer::error::SoftBufferError>>
  a2d7a6:	jmp    a2d8d5 <<gpui::native::NativeHost<empty::Empty>>::resize+0x285>
  a2d7ab:	mov    $0x348,%esi
  a2d7b0:	add    0x190(%r14),%rsi
  a2d7b7:	lea    0x40(%rsp),%rdi
  a2d7bc:	call   *0xb00136(%rip)        # 152d8f8 <_DYNAMIC+0x1360>
  a2d7c2:	mov    0x44(%rsp),%eax
  a2d7c6:	cmp    %r15d,%eax
  a2d7c9:	setb   %cl
  a2d7cc:	cmp    %r12d,%eax
  a2d7cf:	setb   %al
  a2d7d2:	or     %cl,%al
  a2d7d4:	jne    a2d7ed <<gpui::native::NativeHost<empty::Empty>>::resize+0x19d>
  a2d7d6:	mov    %r15d,%eax
  a2d7d9:	mov    %r12,%rcx
  a2d7dc:	imul   %rax,%rcx
  a2d7e0:	cmp    $0x1000001,%rcx
  a2d7e7:	jb     a2d6b9 <<gpui::native::NativeHost<empty::Empty>>::resize+0x69>
  a2d7ed:	movq   $0x1e,(%rbx)
  a2d7f4:	jmp    a2d8d5 <<gpui::native::NativeHost<empty::Empty>>::resize+0x285>
  a2d7f9:	mov    0x68(%rsp),%rcx
  a2d7fe:	movzbl 0x70(%rsp),%edx
  a2d803:	mov    0x74(%rsp),%esi
  a2d807:	mov    %esi,0x34(%rbx)
  a2d80a:	mov    0x71(%rsp),%esi
  a2d80e:	mov    %esi,0x31(%rbx)
  a2d811:	movups 0x48(%rsp),%xmm0
  a2d816:	movups 0x58(%rsp),%xmm1
  a2d81b:	mov    %rax,(%rbx)
  a2d81e:	movups %xmm0,0x8(%rbx)
  a2d822:	movups %xmm1,0x18(%rbx)
  a2d826:	mov    %rcx,0x28(%rbx)
  a2d82a:	mov    %dl,0x30(%rbx)
  a2d82d:	jmp    a2d8d5 <<gpui::native::NativeHost<empty::Empty>>::resize+0x285>
  a2d832:	mov    0x190(%r14),%rsi
  a2d839:	mov    0x370(%rsi),%eax
  a2d83f:	mov    %eax,0x4c(%rsp)
  a2d843:	mov    0x368(%rsi),%rax
  a2d84a:	mov    %rax,0x44(%rsp)
  a2d84f:	movl   $0x10,0x40(%rsp)
  a2d857:	movl   $0x1,0x50(%rsp)
  a2d85f:	mov    %r15,0x54(%rsp)
  a2d864:	movabs $0x100000002,%rax
  a2d86e:	mov    %rax,0x5c(%rsp)
  a2d873:	movl   $0x1,0x64(%rsp)
  a2d87b:	movq   $0x0,0x68(%rsp)
  a2d884:	movq   $0x4,0x70(%rsp)
  a2d88d:	movq   $0x0,0x78(%rsp)
  a2d896:	lea    0x378(%rsi),%rdi
  a2d89d:	add    $0x348,%rsi
  a2d8a4:	lea    0x40(%rsp),%rdx
  a2d8a9:	call   *0xb00051(%rip)        # 152d900 <_DYNAMIC+0x1368>
  a2d8af:	cmpb   $0x0,0x204(%r14)
  a2d8b7:	jne    a2d8ce <<gpui::native::NativeHost<empty::Empty>>::resize+0x27e>
  a2d8b9:	mov    0x1d8(%r14),%rdi
  a2d8c0:	test   %rdi,%rdi
  a2d8c3:	je     a2d8ce <<gpui::native::NativeHost<empty::Empty>>::resize+0x27e>
  a2d8c5:	add    $0x10,%rdi
  a2d8c9:	call   a2a790 <<winit::window::Window>::request_redraw>
  a2d8ce:	movq   $0xfffffffffffffffe,(%rbx)
  a2d8d5:	add    $0x138,%rsp
  a2d8dc:	pop    %rbx
  a2d8dd:	pop    %r12
  a2d8df:	pop    %r13
  a2d8e1:	pop    %r14
  a2d8e3:	pop    %r15
  a2d8e5:	pop    %rbp
  a2d8e6:	ret
  a2d8e7:	mov    $0xd,%ecx
  a2d8ec:	mov    %rcx,(%rbx)
  a2d8ef:	movq   $0x0,0x8(%rbx)
  a2d8f7:	jmp    a2d8d5 <<gpui::native::NativeHost<empty::Empty>>::resize+0x285>
  a2d8f9:	xorps  %xmm0,%xmm0
  a2d8fc:	movups %xmm0,0x193(%r14)
  a2d904:	movups %xmm0,0x18a(%r14)
  a2d90c:	cmpb   $0x0,0x204(%r14)
  a2d914:	je     a2d8b9 <<gpui::native::NativeHost<empty::Empty>>::resize+0x269>
  a2d916:	jmp    a2d8ce <<gpui::native::NativeHost<empty::Empty>>::resize+0x27e>
  a2d918:	lea    0xa8f5c9(%rip),%rdi        # 14bcee8 <anon.fff2d4355c6109bc0e8af2445443084d.8.llvm.4725208967334239140+0x1e0>
  a2d91f:	call   *0xafeeeb(%rip)        # 152c810 <_DYNAMIC+0x278>


/tmp/gpui-a11y-owner-channel-captures/release-candidate/empty:     file format elf64-x86-64


Disassembly of section .text:

0000000000a2e3a0 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch>:
  a2e3a0:	push   %rbp
  a2e3a1:	push   %r15
  a2e3a3:	push   %r14
  a2e3a5:	push   %r13
  a2e3a7:	push   %r12
  a2e3a9:	push   %rbx
  a2e3aa:	sub    $0xb88,%rsp
  a2e3b1:	mov    %rsi,%rbx
  a2e3b4:	mov    %rdi,%r14
  a2e3b7:	mov    (%rdx),%rax
  a2e3ba:	xor    %r13d,%r13d
  a2e3bd:	sub    $0x3,%rax
  a2e3c1:	cmovae %rax,%r13
  a2e3c5:	cmp    $0x2,%r13
  a2e3c9:	je     a2e5c0 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x220>
  a2e3cf:	cmp    $0x8,%r13
  a2e3d3:	jne    a2e3e2 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x42>
  a2e3d5:	mov    %r14,%rdi
  a2e3d8:	call   a2bbc0 <<gpui::native::NativeHost<empty::Empty>>::retire_window>
  a2e3dd:	jmp    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2e3e2:	lea    0x188(%r14),%r12
  a2e3e9:	cmpw   $0x2,0x188(%r14)
  a2e3f2:	je     a2e573 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1d3>
  a2e3f8:	lea    0x250(%rsp),%rdi
  a2e400:	mov    %r12,%rsi
  a2e403:	mov    %rdx,%rbp
  a2e406:	call   *0xaff5a4(%rip)        # 152d9b0 <_DYNAMIC+0x1418>
  a2e40c:	mov    %rbp,%rdx
  a2e40f:	mov    0x250(%rsp),%rax
  a2e417:	cmp    $0xfffffffffffffffe,%rax
  a2e41b:	je     a2e573 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1d3>
  a2e421:	cmp    $0xffffffffffffffff,%rax
  a2e425:	jne    a2e443 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xa3>
  a2e427:	cmpb   $0x0,0x208(%r14)
  a2e42f:	je     a2e4bb <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x11b>
  a2e435:	movq   $0x2f,0x1e8(%rsp)
  a2e441:	jmp    a2e467 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xc7>
  a2e443:	movups 0x258(%rsp),%xmm0
  a2e44b:	movups %xmm0,0x1f8(%rsp)
  a2e453:	movq   $0x30,0x1e8(%rsp)
  a2e45f:	mov    %rax,0x1f0(%rsp)
  a2e467:	lea    0xf8(%r14),%r15
  a2e46e:	cmpl   $0xfffffffe,0xf8(%r14)
  a2e476:	je     a2e480 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xe0>
  a2e478:	mov    %r15,%rdi
  a2e47b:	call   a28c80 <core::ptr::drop_glue::<gpui::native::NativeError>>
  a2e480:	mov    0x218(%rsp),%rax
  a2e488:	mov    %rax,0x30(%r15)
  a2e48c:	movupd 0x1e8(%rsp),%xmm0
  a2e495:	movupd 0x1f8(%rsp),%xmm1
  a2e49e:	movups 0x208(%rsp),%xmm2
  a2e4a6:	movups %xmm2,0x20(%r15)
  a2e4ab:	movupd %xmm1,0x10(%r15)
  a2e4b1:	movupd %xmm0,(%r15)
  a2e4b6:	jmp    a2f975 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x15d5>
  a2e4bb:	mov    $0x1,%al
  a2e4bd:	cmpb   $0x0,(%r14)
  a2e4c1:	je     a2e4f4 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154>
  a2e4c3:	mov    0x8(%r14),%rax
  a2e4c7:	test   %rax,%rax
  a2e4ca:	je     a2ecac <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x90c>
  a2e4d0:	mov    $0xe,%r15d
  a2e4d6:	cmpb   $0x0,0x72e(%rax)
  a2e4dd:	jne    a2ecb2 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x912>
  a2e4e3:	movb   $0x0,0x72c(%rax)
  a2e4ea:	movzbl 0x208(%r14),%eax
  a2e4f2:	inc    %al
  a2e4f4:	mov    %al,0x208(%r14)
  a2e4fb:	lea    0x30(%r14),%r15
  a2e4ff:	mov    %r15,%rdi
  a2e502:	call   a26480 <core::ptr::drop_glue::<core::option::Option<gpui::native::upgrade::Upgrade>>>
  a2e507:	movq   $0xffffffffffffffff,0x30(%r14)
  a2e50f:	movb   $0x0,0x206(%r14)
  a2e517:	lea    0x1d0(%r14),%r15
  a2e51e:	mov    0x1d0(%r14),%rax
  a2e525:	test   %rax,%rax
  a2e528:	je     a2e539 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x199>
  a2e52a:	lock decq (%rax)
  a2e52e:	jne    a2e539 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x199>
  a2e530:	mov    %r15,%rdi
  a2e533:	call   *0xafebd7(%rip)        # 152d110 <_DYNAMIC+0xb78>
  a2e539:	movq   $0x0,(%r15)
  a2e540:	mov    %r12,%rdi
  a2e543:	call   a26240 <core::ptr::drop_glue::<core::option::Option<gpui::native::Graphics>>>
  a2e548:	movw   $0x2,0x188(%r14)
  a2e552:	lea    0x1e8(%rsp),%rdi
  a2e55a:	mov    %r14,%rsi
  a2e55d:	call   a2bef0 <<gpui::native::NativeHost<empty::Empty>>::create_surface>
  a2e562:	cmpl   $0xfffffffe,0x1e8(%rsp)
  a2e56a:	mov    %rbp,%rdx
  a2e56d:	jne    a2e467 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xc7>
  a2e573:	cmp    $0x6,%r13
  a2e577:	ja     a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2e57d:	lea    -0x89956c(%rip),%rax        # 195018 <anon.41931c7f01a0f669fcd75d8bc79f57d6.412.llvm.13234298307199123836+0x106>
  a2e584:	movslq (%rax,%r13,4),%rcx
  a2e588:	add    %rax,%rcx
  a2e58b:	jmp    *%rcx
  a2e58d:	mov    0x180(%r14),%ebp
  a2e594:	cmp    $0xffffffff,%ebp
  a2e597:	je     a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2e59d:	mov    0x178(%r14),%r15
  a2e5a4:	call   *0xafeefe(%rip)        # 152d4a8 <_DYNAMIC+0xf10>
  a2e5aa:	cmp    %rax,%r15
  a2e5ad:	jne    a2ebb1 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x811>
  a2e5b3:	cmp    %edx,%ebp
  a2e5b5:	jbe    a2ebb7 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x817>
  a2e5bb:	jmp    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2e5c0:	movb   $0x1,0x205(%r14)
  a2e5c8:	mov    $0xffffffff,%eax
  a2e5cd:	mov    %rax,0x1b0(%r14)
  a2e5d4:	movq   $0x0,0x1b8(%r14)
  a2e5df:	mov    0x1d8(%r14),%rdi
  a2e5e6:	test   %rdi,%rdi
  a2e5e9:	je     a2e5f6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x256>
  a2e5eb:	add    $0x10,%rdi
  a2e5ef:	xor    %esi,%esi
  a2e5f1:	call   a2dab0 <<winit::window::Window>::set_visible>
  a2e5f6:	lea    0x30(%r14),%r15
  a2e5fa:	mov    %r15,%rdi
  a2e5fd:	call   a26480 <core::ptr::drop_glue::<core::option::Option<gpui::native::upgrade::Upgrade>>>
  a2e602:	movq   $0xffffffffffffffff,0x30(%r14)
  a2e60a:	movb   $0x0,0x206(%r14)
  a2e612:	mov    0x1d0(%r14),%rax
  a2e619:	test   %rax,%rax
  a2e61c:	je     a2e634 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x294>
  a2e61e:	lock decq (%rax)
  a2e622:	jne    a2e634 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x294>
  a2e624:	lea    0x1d0(%r14),%r15
  a2e62b:	mov    %r15,%rdi
  a2e62e:	call   *0xafeadc(%rip)        # 152d110 <_DYNAMIC+0xb78>
  a2e634:	movq   $0x0,0x1d0(%r14)
  a2e63f:	movzwl 0x188(%r14),%eax
  a2e647:	cmp    $0x2,%eax
  a2e64a:	je     a2e66a <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x2ca>
  a2e64c:	test   %eax,%eax
  a2e64e:	jne    a2e65e <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x2be>
  a2e650:	mov    0x190(%r14),%rdi
  a2e657:	call   a26d40 <core::ptr::drop_glue::<alloc::boxed::Box<gpui::native::GpuSurface>>>
  a2e65c:	jmp    a2e66a <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x2ca>
  a2e65e:	mov    0x1a8(%r14),%rdi
  a2e665:	call   a251b0 <core::ptr::drop_glue::<softbuffer::Surface<alloc::sync::Arc<winit::window::Window>, alloc::sync::Arc<winit::window::Window>>>>
  a2e66a:	movw   $0x2,0x188(%r14)
  a2e674:	cmpl   $0x1,(%r14)
  a2e678:	jne    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2e67e:	mov    0x8(%r14),%rax
  a2e682:	test   %rax,%rax
  a2e685:	je     a2e697 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x2f7>
  a2e687:	cmpb   $0x0,0x72e(%rax)
  a2e68e:	je     a2e6fa <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x35a>
  a2e690:	mov    $0xe,%ebp
  a2e695:	jmp    a2e69c <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x2fc>
  a2e697:	mov    $0xd,%ebp
  a2e69c:	xor    %r13d,%r13d
  a2e69f:	cmpl   $0xfffffffe,0xf8(%r14)
  a2e6a7:	je     a2e6b5 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x315>
  a2e6a9:	lea    0xf8(%r14),%rdi
  a2e6b0:	call   a28c80 <core::ptr::drop_glue::<gpui::native::NativeError>>
  a2e6b5:	mov    %rbp,0xf8(%r14)
  a2e6bc:	mov    %r13,0x100(%r14)
  a2e6c3:	mov    %r12,0x108(%r14)
  a2e6ca:	mov    %r15,0x110(%r14)
  a2e6d1:	movapd 0x10(%rsp),%xmm0
  a2e6d7:	movupd %xmm0,0x118(%r14)
  a2e6e0:	mov    0x20(%rsp),%rax
  a2e6e5:	mov    %rax,0x128(%r14)
  a2e6ec:	mov    %rbx,%rdi
  a2e6ef:	call   *0xaff2c3(%rip)        # 152d9b8 <_DYNAMIC+0x1420>
  a2e6f5:	jmp    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2e6fa:	movb   $0x0,0x72c(%rax)
  a2e701:	jmp    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2e706:	mov    0x130(%r14),%rax
  a2e70d:	movq   $0xffffffffffffffff,0x130(%r14)
  a2e718:	cmp    $0xffffffffffffffff,%rax
  a2e71c:	je     a2f1a8 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xe08>
  a2e722:	mov    %rax,0x68(%rsp)
  a2e727:	mov    %rax,0x70(%rsp)
  a2e72c:	movupd 0x138(%r14),%xmm0
  a2e735:	movupd 0x148(%r14),%xmm1
  a2e73e:	movups 0x158(%r14),%xmm2
  a2e746:	movups 0x168(%r14),%xmm3
  a2e74e:	movupd %xmm0,0x78(%rsp)
  a2e754:	movupd %xmm1,0x88(%rsp)
  a2e75d:	movups %xmm2,0x98(%rsp)
  a2e765:	movups %xmm3,0xa8(%rsp)
  a2e76d:	lea    0xb8(%rsp),%rdi
  a2e775:	lea    0x70(%rsp),%rsi
  a2e77a:	call   *0xafe730(%rip)        # 152ceb0 <_DYNAMIC+0x918>
  a2e780:	mov    0x90(%rsp),%rbp
  a2e788:	mov    0x98(%rsp),%rax
  a2e790:	mov    %rax,0x8(%rsp)
  a2e795:	mov    0x1e0(%r14),%r13
  a2e79c:	test   %r13,%r13
  a2e79f:	je     a2e7cb <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x42b>
  a2e7a1:	mov    0x1e8(%r14),%r15
  a2e7a8:	mov    (%r15),%rax
  a2e7ab:	test   %rax,%rax
  a2e7ae:	je     a2e7b5 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x415>
  a2e7b0:	mov    %r13,%rdi
  a2e7b3:	call   *%rax
  a2e7b5:	mov    0x8(%r15),%rsi
  a2e7b9:	test   %rsi,%rsi
  a2e7bc:	je     a2e7cb <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x42b>
  a2e7be:	mov    0x10(%r15),%rdx
  a2e7c2:	mov    %r13,%rdi
  a2e7c5:	call   *0xafe01d(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  a2e7cb:	mov    %rbp,0x1e0(%r14)
  a2e7d2:	mov    0x8(%rsp),%rax
  a2e7d7:	mov    %rax,0x1e8(%r14)
  a2e7de:	mov    0xa0(%rsp),%rbp
  a2e7e6:	mov    0xa8(%rsp),%rax
  a2e7ee:	mov    %rax,0x8(%rsp)
  a2e7f3:	mov    0x1f0(%r14),%r13
  a2e7fa:	test   %r13,%r13
  a2e7fd:	je     a2e829 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x489>
  a2e7ff:	mov    0x1f8(%r14),%r15
  a2e806:	mov    (%r15),%rax
  a2e809:	test   %rax,%rax
  a2e80c:	je     a2e813 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x473>
  a2e80e:	mov    %r13,%rdi
  a2e811:	call   *%rax
  a2e813:	mov    0x8(%r15),%rsi
  a2e817:	test   %rsi,%rsi
  a2e81a:	je     a2e829 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x489>
  a2e81c:	mov    0x10(%r15),%rdx
  a2e820:	mov    %r13,%rdi
  a2e823:	call   *0xafdfbf(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  a2e829:	mov    %rbp,0x1f0(%r14)
  a2e830:	mov    0x8(%rsp),%rax
  a2e835:	mov    %rax,0x1f8(%r14)
  a2e83c:	call   *0xafdf96(%rip)        # 152c7d8 <_DYNAMIC+0x240>
  a2e842:	movq   $0xfffffffffffffffd,0x100(%rsp)
  a2e84e:	lea    0x250(%rsp),%rdi
  a2e856:	call   *0xaff164(%rip)        # 152d9c0 <_DYNAMIC+0x1428>
  a2e85c:	lea    0x8d0(%rsp),%rdi
  a2e864:	lea    0x100(%rsp),%r13
  a2e86c:	mov    0xafdf85(%rip),%r15        # 152c7f8 <memcpy@GLIBC_2.14>
  a2e873:	mov    $0x90,%edx
  a2e878:	mov    %r13,%rsi
  a2e87b:	call   *%r15
  a2e87e:	lea    0x818(%rsp),%rdi
  a2e886:	lea    0x250(%rsp),%rsi
  a2e88e:	mov    $0x98,%edx
  a2e893:	call   *%r15
  a2e896:	movups 0x78(%rsp),%xmm0
  a2e89b:	mov    0x68(%rsp),%rax
  a2e8a0:	mov    %rax,0x800(%rsp)
  a2e8a8:	movups %xmm0,0x808(%rsp)
  a2e8b0:	movq   $0xffffffffffffffff,0x8b0(%rsp)
  a2e8bc:	movl   $0x1,0x960(%rsp)
  a2e8c7:	movsd  0x88(%rsp),%xmm0
  a2e8d0:	xorpd  %xmm1,%xmm1
  a2e8d4:	unpcklps %xmm1,%xmm0
  a2e8d7:	movapd -0x8a1d6f(%rip),%xmm1        # 18cb70 <anon.89c1a9733c414c7e4e56fa7f22cdc6b9.309.llvm.3311541718473421078+0x8c0>
  a2e8df:	orpd   %xmm1,%xmm0
  a2e8e3:	subpd  %xmm1,%xmm0
  a2e8e7:	movupd %xmm0,0x968(%rsp)
  a2e8f0:	movl   $0x2,0x978(%rsp)
  a2e8fb:	movl   $0x2,0x990(%rsp)
  a2e906:	movl   $0x2,0x9a8(%rsp)
  a2e911:	movl   $0x2,0x9c0(%rsp)
  a2e91c:	movl   $0xffffffff,0x9d8(%rsp)
  a2e927:	movw   $0x0,0x9f0(%rsp)
  a2e931:	movl   $0x7,0xa00(%rsp)
  a2e93c:	movw   $0x102,0xa0c(%rsp)
  a2e946:	movabs $0x100010000000001,%rax
  a2e950:	mov    %rax,0xa04(%rsp)
  a2e958:	mov    0xafe981(%rip),%rax        # 152d2e0 <_DYNAMIC+0xd48>
  a2e95f:	mov    (%rax),%rax
  a2e962:	cmp    $0x2,%rax
  a2e966:	jae    a2edcd <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xa2d>
  a2e96c:	mov    0xaff055(%rip),%r15        # 152d9c8 <_DYNAMIC+0x1430>
  a2e973:	movzbl 0x10(%r15),%eax
  a2e978:	movzbl %al,%ecx
  a2e97b:	lea    -0x1(%rcx),%edx
  a2e97e:	cmp    $0x2,%edx
  a2e981:	jae    a2edc5 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xa25>
  a2e987:	mov    (%r15),%rdi
  a2e98a:	movzbl %al,%esi
  a2e98d:	call   *0xafe95d(%rip)        # 152d2f0 <_DYNAMIC+0xd58>
  a2e993:	test   %al,%al
  a2e995:	je     a2edcd <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xa2d>
  a2e99b:	mov    (%r15),%rsi
  a2e99e:	lea    0x30(%rsi),%rax
  a2e9a2:	lea    0x800(%rsp),%rcx
  a2e9aa:	mov    %rcx,0xd0(%rsp)
  a2e9b2:	lea    0xd0(%rsp),%rcx
  a2e9ba:	mov    %rcx,0x100(%rsp)
  a2e9c2:	lea    0xa8e3f7(%rip),%rcx        # 14bcdc0 <anon.fff2d4355c6109bc0e8af2445443084d.8.llvm.4725208967334239140+0xb8>
  a2e9c9:	mov    %rcx,0x108(%rsp)
  a2e9d1:	movq   $0x1,0x250(%rsp)
  a2e9dd:	mov    %r13,0x258(%rsp)
  a2e9e5:	movq   $0x1,0x260(%rsp)
  a2e9f1:	mov    %rax,0x268(%rsp)
  a2e9f9:	lea    0x40(%rsp),%rdi
  a2e9fe:	lea    0x250(%rsp),%rdx
  a2ea06:	call   *0xafee94(%rip)        # 152d8a0 <_DYNAMIC+0x1308>
  a2ea0c:	cmpq   $0x2,0x40(%rsp)
  a2ea12:	je     a2eddf <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xa3f>
  a2ea18:	lea    0x58(%rsp),%rsi
  a2ea1d:	lea    0x40(%rsp),%rdi
  a2ea22:	call   *0xafee80(%rip)        # 152d8a8 <_DYNAMIC+0x1310>
  a2ea28:	jmp    a2eddf <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xa3f>
  a2ea2d:	mov    0x178(%r14),%rax
  a2ea34:	mov    0x180(%r14),%ecx
  a2ea3b:	testb  $0x1,0x204(%r14)
  a2ea43:	mov    $0x3b9aca01,%edx
  a2ea48:	mov    %ecx,%esi
  a2ea4a:	cmovne %edx,%esi
  a2ea4d:	cmp    $0xffffffff,%ecx
  a2ea50:	cmove  %edx,%esi
  a2ea53:	mov    %rax,0x68(%rbx)
  a2ea57:	mov    %esi,0x70(%rbx)
  a2ea5a:	jmp    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2ea5f:	mov    0x1d8(%r14),%r12
  a2ea66:	test   %r12,%r12
  a2ea69:	je     a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2ea6f:	mov    %rdx,%r15
  a2ea72:	mov    0xafe867(%rip),%rax        # 152d2e0 <_DYNAMIC+0xd48>
  a2ea79:	mov    (%rax),%rax
  a2ea7c:	cmp    $0x1,%rax
  a2ea80:	ja     a2ece7 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x947>
  a2ea86:	mov    0xafef43(%rip),%r13        # 152d9d0 <_DYNAMIC+0x1438>
  a2ea8d:	movzbl 0x10(%r13),%eax
  a2ea92:	movzbl %al,%ecx
  a2ea95:	lea    -0x1(%rcx),%edx
  a2ea98:	cmp    $0x2,%edx
  a2ea9b:	jae    a2ecdf <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x93f>
  a2eaa1:	mov    0x0(%r13),%rdi
  a2eaa5:	movzbl %al,%esi
  a2eaa8:	call   *0xafe842(%rip)        # 152d2f0 <_DYNAMIC+0xd58>
  a2eaae:	test   %al,%al
  a2eab0:	je     a2ece7 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x947>
  a2eab6:	mov    0x0(%r13),%rsi
  a2eaba:	lea    0x30(%rsi),%rax
  a2eabe:	movq   $0x1,0x800(%rsp)
  a2eaca:	movq   $0x8,0x808(%rsp)
  a2ead6:	movq   $0x0,0x810(%rsp)
  a2eae2:	mov    %rax,0x818(%rsp)
  a2eaea:	lea    0x250(%rsp),%rdi
  a2eaf2:	lea    0x800(%rsp),%rdx
  a2eafa:	call   *0xafeda0(%rip)        # 152d8a0 <_DYNAMIC+0x1308>
  a2eb00:	cmpq   $0x2,0x250(%rsp)
  a2eb09:	je     a2ecff <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x95f>
  a2eb0f:	lea    0x268(%rsp),%rsi
  a2eb17:	lea    0x250(%rsp),%rdi
  a2eb1f:	call   *0xafed83(%rip)        # 152d8a8 <_DYNAMIC+0x1310>
  a2eb25:	jmp    a2ecff <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x95f>
  a2eb2a:	cmpl   $0xfffffffe,0x48(%r14)
  a2eb2f:	setne  %cl
  a2eb32:	mov    (%r14),%rax
  a2eb35:	test   %al,%cl
  a2eb37:	je     a2f246 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xea6>
  a2eb3d:	lea    0x48(%r14),%r15
  a2eb41:	lea    0x8(%r14),%rdx
  a2eb45:	lea    0x800(%rsp),%rdi
  a2eb4d:	mov    %r15,%rsi
  a2eb50:	call   9e5e80 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>>
  a2eb55:	cmpl   $0xfffffffc,0x800(%rsp)
  a2eb5d:	jne    a2ebc7 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x827>
  a2eb5f:	mov    %r15,%rdi
  a2eb62:	call   a26340 <core::ptr::drop_glue::<core::option::Option<gpui::native::accessibility::Bridge>>>
  a2eb67:	lea    0x808(%rsp),%r12
  a2eb6f:	movq   $0xfffffffffffffffe,0x48(%r14)
  a2eb77:	lea    0xf8(%r14),%r15
  a2eb7e:	cmpl   $0xfffffffe,0xf8(%r14)
  a2eb86:	je     a2eb90 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x7f0>
  a2eb88:	mov    %r15,%rdi
  a2eb8b:	call   a28c80 <core::ptr::drop_glue::<gpui::native::NativeError>>
  a2eb90:	mov    0x30(%r12),%rax
  a2eb95:	mov    %rax,0x30(%r15)
  a2eb99:	movupd (%r12),%xmm0
  a2eb9f:	movupd 0x10(%r12),%xmm1
  a2eba6:	movups 0x20(%r12),%xmm2
  a2ebac:	jmp    a2e4a6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x106>
  a2ebb1:	jg     a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2ebb7:	movl   $0xffffffff,0x180(%r14)
  a2ebc2:	jmp    a2f8b7 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1517>
  a2ebc7:	lea    0x268(%rsp),%rdi
  a2ebcf:	lea    0x800(%rsp),%rsi
  a2ebd7:	mov    $0x380,%edx
  a2ebdc:	call   *0xafdc16(%rip)        # 152c7f8 <memcpy@GLIBC_2.14>
  a2ebe2:	movq   $0x1,0x250(%rsp)
  a2ebee:	movq   $0x10,0x260(%rsp)
  a2ebfa:	movq   $0xfffffffffffffffc,0x5e8(%rsp)
  a2ec06:	movq   $0xfffffffffffffffc,0x620(%rsp)
  a2ec12:	lea    0x108(%rsp),%rbp
  a2ec1a:	lea    0x270(%rsp),%r15
  a2ec22:	xor    %r13d,%r13d
  a2ec25:	lea    0x100(%rsp),%r12
  a2ec2d:	mov    -0x8(%r15),%rax
  a2ec31:	cmp    $0xfffffffffffffffd,%rax
  a2ec35:	je     a2ec88 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x8e8>
  a2ec37:	cmp    $0xfffffffffffffffc,%rax
  a2ec3b:	je     a2f22b <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xe8b>
  a2ec41:	movupd (%r15),%xmm0
  a2ec46:	movupd 0x10(%r15),%xmm1
  a2ec4c:	movups 0x20(%r15),%xmm2
  a2ec51:	movups %xmm2,0x20(%rbp)
  a2ec55:	movupd %xmm1,0x10(%rbp)
  a2ec5a:	movupd %xmm0,0x0(%rbp)
  a2ec5f:	mov    %rax,0x100(%rsp)
  a2ec67:	lea    0x6b0(%rsp),%rdi
  a2ec6f:	mov    %r14,%rsi
  a2ec72:	mov    %r12,%rdx
  a2ec75:	call   a2ba40 <<gpui::native::NativeHost<empty::Empty>>::input_result>
  a2ec7a:	cmpl   $0xfffffffe,0x6b0(%rsp)
  a2ec82:	jne    a2f336 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xf96>
  a2ec88:	cmp    $0xf,%r13
  a2ec8c:	je     a2eca1 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x901>
  a2ec8e:	add    $0x38,%r15
  a2ec92:	inc    %r13
  a2ec95:	mov    -0x8(%r15),%rax
  a2ec99:	cmp    $0xfffffffffffffffd,%rax
  a2ec9d:	jne    a2ec37 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x897>
  a2ec9f:	jmp    a2ec88 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x8e8>
  a2eca1:	mov    $0x10,%r13d
  a2eca7:	jmp    a2f22e <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xe8e>
  a2ecac:	mov    $0xd,%r15d
  a2ecb2:	cmpl   $0xfffffffe,0xf8(%r14)
  a2ecba:	je     a2ecc8 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x928>
  a2ecbc:	lea    0xf8(%r14),%rdi
  a2ecc3:	call   a28c80 <core::ptr::drop_glue::<gpui::native::NativeError>>
  a2ecc8:	mov    %r15,0xf8(%r14)
  a2eccf:	movq   $0x0,0x100(%r14)
  a2ecda:	jmp    a2f975 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x15d5>
  a2ecdf:	test   %ecx,%ecx
  a2ece1:	jne    a2fd15 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1975>
  a2ece7:	movq   $0x2,0x250(%rsp)
  a2ecf3:	movq   $0x0,0x270(%rsp)
  a2ecff:	mov    0x270(%rsp),%rax
  a2ed07:	mov    %rax,0x820(%rsp)
  a2ed0f:	mov    0x250(%rsp),%rax
  a2ed17:	mov    0x258(%rsp),%rcx
  a2ed1f:	movupd 0x260(%rsp),%xmm0
  a2ed28:	movapd %xmm0,0x810(%rsp)
  a2ed31:	mov    %rax,0x800(%rsp)
  a2ed39:	mov    %rcx,0x808(%rsp)
  a2ed41:	mov    0x10(%r12),%rax
  a2ed46:	mov    0x310(%rax),%r12d
  a2ed4d:	lea    0x800(%rsp),%rdi
  a2ed55:	call   a28b10 <core::ptr::drop_glue::<tracing::span::EnteredSpan>>
  a2ed5a:	cmp    %r12,0x10(%r15)
  a2ed5e:	jne    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2ed64:	mov    0x8(%r15),%r15
  a2ed68:	cmpl   $0xfffffffe,0x48(%r14)
  a2ed6d:	je     a2ed8c <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x9ec>
  a2ed6f:	mov    0x1d8(%r14),%rsi
  a2ed76:	test   %rsi,%rsi
  a2ed79:	je     a2ed8c <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x9ec>
  a2ed7b:	lea    0x48(%r14),%rdi
  a2ed7f:	add    $0x10,%rsi
  a2ed83:	mov    %r15,%rdx
  a2ed86:	call   *0xafec4c(%rip)        # 152d9d8 <_DYNAMIC+0x1440>
  a2ed8c:	movzwl (%r15),%eax
  a2ed90:	mov    %eax,%ecx
  a2ed92:	sub    $0x4,%cx
  a2ed96:	mov    $0x9,%edx
  a2ed9b:	cmovae %ecx,%edx
  a2ed9e:	movzwl %dx,%ecx
  a2eda1:	dec    %ecx
  a2eda3:	cmp    $0x1a,%ecx
  a2eda6:	ja     a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2edac:	lea    -0x899d7f(%rip),%rdx        # 195034 <anon.41931c7f01a0f669fcd75d8bc79f57d6.412.llvm.13234298307199123836+0x122>
  a2edb3:	movslq (%rdx,%rcx,4),%rcx
  a2edb7:	add    %rdx,%rcx
  a2edba:	jmp    *%rcx
  a2edbc:	mov    0x4(%r15),%rdx
  a2edc0:	jmp    a2f4fe <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x115e>
  a2edc5:	test   %ecx,%ecx
  a2edc7:	jne    a2fd2f <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x198f>
  a2edcd:	movq   $0x2,0x40(%rsp)
  a2edd6:	movq   $0x0,0x60(%rsp)
  a2eddf:	mov    0x60(%rsp),%rax
  a2ede4:	mov    %rax,0xf0(%rsp)
  a2edec:	mov    0x40(%rsp),%rax
  a2edf1:	mov    0x48(%rsp),%rcx
  a2edf6:	movupd 0x50(%rsp),%xmm0
  a2edfc:	movapd %xmm0,0xe0(%rsp)
  a2ee05:	mov    %rax,0xd0(%rsp)
  a2ee0d:	mov    %rcx,0xd8(%rsp)
  a2ee15:	lea    0x250(%rsp),%r13
  a2ee1d:	lea    0x800(%rsp),%rsi
  a2ee25:	mov    $0x210,%edx
  a2ee2a:	mov    %r13,%rdi
  a2ee2d:	call   *0xafd9c5(%rip)        # 152c7f8 <memcpy@GLIBC_2.14>
  a2ee33:	lea    0x100(%rsp),%rdi
  a2ee3b:	mov    %rbx,%rsi
  a2ee3e:	mov    %r13,%rdx
  a2ee41:	call   *0xafeb99(%rip)        # 152d9e0 <_DYNAMIC+0x1448>
  a2ee47:	mov    0x100(%rsp),%r15
  a2ee4f:	cmp    $0xffffffffffffffff,%r15
  a2ee53:	je     a2ee89 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xae9>
  a2ee55:	mov    0x130(%rsp),%rax
  a2ee5d:	mov    %rax,0x240(%rsp)
  a2ee65:	movupd 0x110(%rsp),%xmm0
  a2ee6e:	movupd 0x120(%rsp),%xmm1
  a2ee77:	movapd %xmm1,0x230(%rsp)
  a2ee80:	movapd %xmm0,0x220(%rsp)
  a2ee89:	mov    0x108(%rsp),%r13
  a2ee91:	lea    0xd0(%rsp),%rdi
  a2ee99:	call   a28b10 <core::ptr::drop_glue::<tracing::span::EnteredSpan>>
  a2ee9e:	cmp    $0xffffffffffffffff,%r15
  a2eea2:	je     a2ef97 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xbf7>
  a2eea8:	mov    %r15,0x250(%rsp)
  a2eeb0:	mov    %r13,0x258(%rsp)
  a2eeb8:	movapd 0x220(%rsp),%xmm0
  a2eec1:	movapd 0x230(%rsp),%xmm1
  a2eeca:	movupd %xmm0,0x260(%rsp)
  a2eed3:	movupd %xmm1,0x270(%rsp)
  a2eedc:	mov    0x240(%rsp),%rax
  a2eee4:	mov    %rax,0x280(%rsp)
  a2eeec:	movq   $0x0,0x40(%rsp)
  a2eef5:	movq   $0x1,0x48(%rsp)
  a2eefe:	movq   $0x0,0x50(%rsp)
  a2ef07:	movq   $0x60000020,0x110(%rsp)
  a2ef13:	lea    0x40(%rsp),%rax
  a2ef18:	mov    %rax,0x100(%rsp)
  a2ef20:	lea    0xa8e031(%rip),%rax        # 14bcf58 <anon.fff2d4355c6109bc0e8af2445443084d.57.llvm.4725208967334239140>
  a2ef27:	mov    %rax,0x108(%rsp)
  a2ef2f:	lea    0x250(%rsp),%rdi
  a2ef37:	lea    0x100(%rsp),%rsi
  a2ef3f:	call   *0xafeaa3(%rip)        # 152d9e8 <_DYNAMIC+0x1450>
  a2ef45:	test   %al,%al
  a2ef47:	jne    a2fc7a <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x18da>
  a2ef4d:	mov    0x40(%rsp),%r13
  a2ef52:	mov    0x48(%rsp),%r12
  a2ef57:	mov    0x50(%rsp),%r15
  a2ef5c:	lea    0x250(%rsp),%rdi
  a2ef64:	call   a27d80 <core::ptr::drop_glue::<winit::error::OsError>>
  a2ef69:	mov    $0x2d,%ebp
  a2ef6e:	mov    0xb8(%rsp),%rsi
  a2ef76:	test   %rsi,%rsi
  a2ef79:	je     a2e69f <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x2ff>
  a2ef7f:	mov    0xc0(%rsp),%rdi
  a2ef87:	mov    $0x1,%edx
  a2ef8c:	call   *0xafd856(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  a2ef92:	jmp    a2e69f <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x2ff>
  a2ef97:	movq   $0x1,0x250(%rsp)
  a2efa3:	movq   $0x1,0x258(%rsp)
  a2efaf:	mov    %r13,0x260(%rsp)
  a2efb7:	call   *0xafd81b(%rip)        # 152c7d8 <_DYNAMIC+0x240>
  a2efbd:	mov    $0x18,%edi
  a2efc2:	mov    $0x8,%esi
  a2efc7:	call   *0xafd813(%rip)        # 152c7e0 <_DYNAMIC+0x248>
  a2efcd:	test   %rax,%rax
  a2efd0:	je     a2fcbd <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x191d>
  a2efd6:	mov    %rax,%rcx
  a2efd9:	mov    0x260(%rsp),%rdx
  a2efe1:	mov    %rdx,0x10(%rax)
  a2efe5:	movups 0x250(%rsp),%xmm0
  a2efed:	movups %xmm0,(%rax)
  a2eff0:	add    $0x10,%rax
  a2eff4:	mov    %rcx,0x30(%rsp)
  a2eff9:	mov    %rax,%rdi
  a2effc:	call   a2d930 <<winit::window::Window>::inner_size>
  a2f001:	cmp    $0x1,%eax
  a2f004:	adc    $0x0,%eax
  a2f007:	cmp    $0x1,%edx
  a2f00a:	adc    $0x0,%edx
  a2f00d:	mov    %eax,0x110(%rsp)
  a2f014:	mov    %edx,0x114(%rsp)
  a2f01b:	movl   $0x0,0x100(%rsp)
  a2f026:	movl   $0x434b0000,0x108(%rsp)
  a2f031:	movw   $0x0,0x10c(%rsp)
  a2f03b:	mov    0x30(%rsp),%rdi
  a2f040:	add    $0x10,%rdi
  a2f044:	call   a2a600 <<winit::window::Window>::scale_factor>
  a2f049:	cvtsd2ss %xmm0,%xmm0
  a2f04d:	movzbl 0xb0(%rsp),%edx
  a2f055:	lea    0x250(%rsp),%rdi
  a2f05d:	lea    0x100(%rsp),%rsi
  a2f065:	call   9c2970 <<gpui::runtime::Win<empty::Empty>>::recording_lanes>
  a2f06a:	mov    0x250(%rsp),%rbp
  a2f072:	mov    0x258(%rsp),%r13
  a2f07a:	cmp    $0xfffffffffffffffe,%rbp
  a2f07e:	jne    a2f1fc <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xe5c>
  a2f084:	mov    0x10(%r14),%rax
  a2f088:	cmp    $0xffffffffffffffff,%rax
  a2f08c:	sete   %bpl
  a2f090:	cmp    $0xffffffff,%eax
  a2f093:	je     a2f453 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x10b3>
  a2f099:	mov    %ebp,0x8(%rsp)
  a2f09d:	mov    0x30(%rsp),%rbp
  a2f0a2:	mov    0x28(%r14),%r15
  a2f0a6:	lock incq (%r15)
  a2f0aa:	jle    a2fd71 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x19d1>
  a2f0b0:	lea    0x10(%r14),%rsi
  a2f0b4:	mov    %r15,0xd0(%rsp)
  a2f0bc:	lea    0x40(%rsp),%rdi
  a2f0c1:	call   a20db0 <<winit::platform_impl::linux::x11::WakeSender<()> as core::clone::Clone>::clone>
  a2f0c6:	add    $0x10,%rbp
  a2f0ca:	movups 0x40(%rsp),%xmm0
  a2f0cf:	mov    0x50(%rsp),%rax
  a2f0d4:	movups %xmm0,0x690(%rsp)
  a2f0dc:	mov    %rax,0x6a0(%rsp)
  a2f0e4:	mov    %r15,0x6a8(%rsp)
  a2f0ec:	mov    0xc8(%rsp),%rax
  a2f0f4:	mov    %rax,0x50(%rsp)
  a2f0f9:	movups 0xb8(%rsp),%xmm0
  a2f101:	movaps %xmm0,0x40(%rsp)
  a2f106:	lea    0x250(%rsp),%rdi
  a2f10e:	lea    0x690(%rsp),%rcx
  a2f116:	lea    0x40(%rsp),%r8
  a2f11b:	mov    %rbx,%rsi
  a2f11e:	mov    %rbp,%rdx
  a2f121:	call   *0xafe8c9(%rip)        # 152d9f0 <_DYNAMIC+0x1458>
  a2f127:	lea    0x100(%rsp),%rdi
  a2f12f:	lea    0x250(%rsp),%rsi
  a2f137:	mov    $0xb0,%edx
  a2f13c:	call   *0xafd6b6(%rip)        # 152c7f8 <memcpy@GLIBC_2.14>
  a2f142:	lea    0x48(%r14),%rbp
  a2f146:	mov    %rbp,%rdi
  a2f149:	call   a26340 <core::ptr::drop_glue::<core::option::Option<gpui::native::accessibility::Bridge>>>
  a2f14e:	lea    0x100(%rsp),%rsi
  a2f156:	mov    $0xb0,%edx
  a2f15b:	mov    %rbp,%rdi
  a2f15e:	call   *0xafd694(%rip)        # 152c7f8 <memcpy@GLIBC_2.14>
  a2f164:	cmpq   $0x0,(%r14)
  a2f168:	je     a2f173 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xdd3>
  a2f16a:	mov    0x8(%r14),%rdi
  a2f16e:	call   a26ee0 <core::ptr::drop_glue::<gpui::runtime::Win<empty::Empty>>>
  a2f173:	movq   $0x1,(%r14)
  a2f17a:	mov    %r13,0x8(%r14)
  a2f17e:	mov    0x30(%rsp),%r13
  a2f183:	lea    0x1d8(%r14),%r15
  a2f18a:	mov    0x1d8(%r14),%rax
  a2f191:	test   %rax,%rax
  a2f194:	je     a2f1a5 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xe05>
  a2f196:	lock decq (%rax)
  a2f19a:	jne    a2f1a5 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xe05>
  a2f19c:	mov    %r15,%rdi
  a2f19f:	call   *0xafe1db(%rip)        # 152d380 <_DYNAMIC+0xde8>
  a2f1a5:	mov    %r13,(%r15)
  a2f1a8:	cmpw   $0x2,(%r12)
  a2f1ae:	jne    a2f1d2 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xe32>
  a2f1b0:	lea    0x250(%rsp),%rdi
  a2f1b8:	mov    %r14,%rsi
  a2f1bb:	call   a2bef0 <<gpui::native::NativeHost<empty::Empty>>::create_surface>
  a2f1c0:	mov    0x250(%rsp),%rbp
  a2f1c8:	cmp    $0xfffffffffffffffe,%rbp
  a2f1cc:	jne    a2fb40 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x17a0>
  a2f1d2:	mov    0x1d8(%r14),%rdi
  a2f1d9:	test   %rdi,%rdi
  a2f1dc:	je     a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2f1e2:	add    $0x10,%rdi
  a2f1e6:	mov    $0x1,%esi
  a2f1eb:	call   a2dab0 <<winit::window::Window>::set_visible>
  a2f1f0:	mov    0x1d8(%r14),%rdi
  a2f1f7:	jmp    a2f8cd <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x152d>
  a2f1fc:	mov    0x260(%rsp),%r12
  a2f204:	mov    0x268(%rsp),%r15
  a2f20c:	movups 0x270(%rsp),%xmm0
  a2f214:	movaps %xmm0,0x10(%rsp)
  a2f219:	mov    0x280(%rsp),%rax
  a2f221:	mov    %rax,0x20(%rsp)
  a2f226:	jmp    a2f4bd <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x111d>
  a2f22b:	inc    %r13
  a2f22e:	mov    %r13,0x258(%rsp)
  a2f236:	lea    0x250(%rsp),%rdi
  a2f23e:	call   a275d0 <core::ptr::drop_glue::<core::iter::adapters::flatten::Flatten<core::array::iter::IntoIter<core::option::Option<core::result::Result<gpui::runtime::Commit, gpui::runtime::Error>>, 16>>>>
  a2f243:	mov    (%r14),%rax
  a2f246:	test   $0x1,%al
  a2f248:	je     a2f8b0 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1510>
  a2f24e:	mov    0x8(%r14),%rax
  a2f252:	test   %rax,%rax
  a2f255:	je     a2fca4 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1904>
  a2f25b:	lea    0x8(%r14),%rsi
  a2f25f:	mov    0x660(%rax),%r15
  a2f266:	lea    0x250(%rsp),%rdi
  a2f26e:	mov    $0x40,%edx
  a2f273:	call   9b7bc0 <<gpui::runtime::Win<empty::Empty>>::deliver_ready>
  a2f278:	mov    0x250(%rsp),%rax
  a2f280:	cmp    $0xffffffffffffffff,%rax
  a2f284:	je     a2f2f1 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xf51>
  a2f286:	cmp    $0x2,%eax
  a2f289:	je     a2f2a8 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xf08>
  a2f28b:	cmp    %r15,0x260(%rsp)
  a2f293:	jbe    a2f2a8 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xf08>
  a2f295:	mov    0x298(%rsp),%eax
  a2f29c:	and    $0xfffffffe,%eax
  a2f29f:	cmp    $0xe,%eax
  a2f2a2:	jne    a2f3ab <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x100b>
  a2f2a8:	mov    0x2c8(%rsp),%rax
  a2f2b0:	mov    %rax,0x1e0(%rsp)
  a2f2b8:	movupd 0x298(%rsp),%xmm0
  a2f2c1:	movupd 0x2a8(%rsp),%xmm1
  a2f2ca:	movups 0x2b8(%rsp),%xmm2
  a2f2d2:	movaps %xmm2,0x1d0(%rsp)
  a2f2da:	movapd %xmm1,0x1c0(%rsp)
  a2f2e3:	movapd %xmm0,0x1b0(%rsp)
  a2f2ec:	jmp    a2f88a <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x14ea>
  a2f2f1:	movupd 0x258(%rsp),%xmm0
  a2f2fa:	movupd 0x268(%rsp),%xmm1
  a2f303:	movups 0x278(%rsp),%xmm2
  a2f30b:	movups %xmm2,0x1d8(%rsp)
  a2f313:	movupd %xmm1,0x1c8(%rsp)
  a2f31c:	movupd %xmm0,0x1b8(%rsp)
  a2f325:	movq   $0xfffffffffffffffe,0x1b0(%rsp)
  a2f331:	jmp    a2f88a <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x14ea>
  a2f336:	inc    %r13
  a2f339:	mov    %r13,0x258(%rsp)
  a2f341:	lea    0xf8(%r14),%r15
  a2f348:	cmpl   $0xfffffffe,0xf8(%r14)
  a2f350:	je     a2f35a <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xfba>
  a2f352:	mov    %r15,%rdi
  a2f355:	call   a28c80 <core::ptr::drop_glue::<gpui::native::NativeError>>
  a2f35a:	mov    0x6e0(%rsp),%rax
  a2f362:	mov    %rax,0x30(%r15)
  a2f366:	movupd 0x6b0(%rsp),%xmm0
  a2f36f:	movupd 0x6c0(%rsp),%xmm1
  a2f378:	movups 0x6d0(%rsp),%xmm2
  a2f380:	movups %xmm2,0x20(%r15)
  a2f385:	movupd %xmm1,0x10(%r15)
  a2f38b:	movupd %xmm0,(%r15)
  a2f390:	mov    %rbx,%rdi
  a2f393:	call   *0xafe61f(%rip)        # 152d9b8 <_DYNAMIC+0x1420>
  a2f399:	lea    0x250(%rsp),%rdi
  a2f3a1:	call   a275d0 <core::ptr::drop_glue::<core::iter::adapters::flatten::Flatten<core::array::iter::IntoIter<core::option::Option<core::result::Result<gpui::runtime::Commit, gpui::runtime::Error>>, 16>>>>
  a2f3a6:	jmp    a2f97e <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x15de>
  a2f3ab:	lea    0x298(%rsp),%rax
  a2f3b3:	mov    0x30(%rax),%rcx
  a2f3b7:	mov    %rcx,0xa0(%rsp)
  a2f3bf:	movups (%rax),%xmm0
  a2f3c2:	movups 0x10(%rax),%xmm1
  a2f3c6:	movups 0x20(%rax),%xmm2
  a2f3ca:	movaps %xmm2,0x90(%rsp)
  a2f3d2:	movaps %xmm1,0x80(%rsp)
  a2f3da:	movaps %xmm0,0x70(%rsp)
  a2f3df:	mov    0x290(%rsp),%rax
  a2f3e7:	mov    %rax,0x840(%rsp)
  a2f3ef:	movups 0x250(%rsp),%xmm0
  a2f3f7:	movups 0x260(%rsp),%xmm1
  a2f3ff:	movups 0x270(%rsp),%xmm2
  a2f407:	movups 0x280(%rsp),%xmm3
  a2f40f:	movaps %xmm3,0x830(%rsp)
  a2f417:	movaps %xmm2,0x820(%rsp)
  a2f41f:	movaps %xmm1,0x810(%rsp)
  a2f427:	movaps %xmm0,0x800(%rsp)
  a2f42f:	mov    0x1e0(%r14),%rdi
  a2f436:	test   %rdi,%rdi
  a2f439:	je     a2f7b9 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1419>
  a2f43f:	mov    0x1e8(%r14),%rax
  a2f446:	lea    0x70(%rsp),%rsi
  a2f44b:	call   *0x20(%rax)
  a2f44e:	jmp    a2f840 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x14a0>
  a2f453:	call   *0xafd37f(%rip)        # 152c7d8 <_DYNAMIC+0x240>
  a2f459:	mov    $0x35,%r15d
  a2f45f:	mov    $0x35,%edi
  a2f464:	mov    $0x1,%esi
  a2f469:	call   *0xafd371(%rip)        # 152c7e0 <_DYNAMIC+0x248>
  a2f46f:	test   %rax,%rax
  a2f472:	je     a2fd5d <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x19bd>
  a2f478:	mov    %rax,%r12
  a2f47b:	movups -0x89a376(%rip),%xmm0        # 19510c <anon.41931c7f01a0f669fcd75d8bc79f57d6.412.llvm.13234298307199123836+0x1fa>
  a2f482:	movups %xmm0,0x20(%rax)
  a2f486:	movups -0x89a391(%rip),%xmm0        # 1950fc <anon.41931c7f01a0f669fcd75d8bc79f57d6.412.llvm.13234298307199123836+0x1ea>
  a2f48d:	movups %xmm0,0x10(%rax)
  a2f491:	movups -0x89a3ac(%rip),%xmm0        # 1950ec <anon.41931c7f01a0f669fcd75d8bc79f57d6.412.llvm.13234298307199123836+0x1da>
  a2f498:	movups %xmm0,(%rax)
  a2f49b:	movabs $0x656b617720726576,%rax
  a2f4a5:	mov    %rax,0x2d(%r12)
  a2f4aa:	mov    $0x2d,%ebp
  a2f4af:	mov    %r13,%rdi
  a2f4b2:	call   a26ee0 <core::ptr::drop_glue::<gpui::runtime::Win<empty::Empty>>>
  a2f4b7:	mov    $0x35,%r13d
  a2f4bd:	mov    0x30(%rsp),%rax
  a2f4c2:	lock decq (%rax)
  a2f4c6:	jne    a2ef6e <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xbce>
  a2f4cc:	lea    0x30(%rsp),%rdi
  a2f4d1:	call   *0xafdea9(%rip)        # 152d380 <_DYNAMIC+0xde8>
  a2f4d7:	jmp    a2ef6e <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xbce>
  a2f4dc:	mov    0x1d8(%r14),%rdi
  a2f4e3:	test   %rdi,%rdi
  a2f4e6:	je     a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2f4ec:	add    $0x10,%rdi
  a2f4f0:	call   a2d930 <<winit::window::Window>::inner_size>
  a2f4f5:	shl    $0x20,%rdx
  a2f4f9:	mov    %eax,%eax
  a2f4fb:	or     %rax,%rdx
  a2f4fe:	lea    0x250(%rsp),%rdi
  a2f506:	mov    %r14,%rsi
  a2f509:	call   a2d650 <<gpui::native::NativeHost<empty::Empty>>::resize>
  a2f50e:	jmp    a2fb2e <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x178e>
  a2f513:	cmpb   $0x0,0x82(%r15)
  a2f51b:	jne    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2f521:	cmpb   $0x0,0x78(%r15)
  a2f526:	jne    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2f52c:	movzbl 0x60(%r15),%esi
  a2f531:	cmp    $0xff,%rsi
  a2f538:	je     a2fafd <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x175d>
  a2f53e:	lea    -0x17(%rsi),%rdx
  a2f542:	xor    %ecx,%ecx
  a2f544:	cmp    $0x18,%sil
  a2f548:	cmovae %rdx,%rcx
  a2f54c:	test   %rcx,%rcx
  a2f54f:	je     a2fb79 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x17d9>
  a2f555:	cmp    $0x1,%ecx
  a2f558:	jne    a2fb89 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x17e9>
  a2f55e:	mov    0x68(%r15),%rcx
  a2f562:	mov    0x70(%r15),%rsi
  a2f566:	jmp    a2fb95 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x17f5>
  a2f56b:	lea    0x250(%rsp),%rdi
  a2f573:	mov    %r14,%rsi
  a2f576:	call   a2cb20 <<gpui::native::NativeHost<empty::Empty>>::redraw>
  a2f57b:	jmp    a2fb2e <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x178e>
  a2f580:	mov    0x4(%r15),%eax
  a2f584:	mov    %eax,0x200(%r14)
  a2f58b:	jmp    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2f590:	movb   $0x1,0x205(%r14)
  a2f598:	movzbl 0x2(%r15),%eax
  a2f59d:	mov    %al,0x204(%r14)
  a2f5a4:	test   %al,%al
  a2f5a6:	jne    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2f5ac:	mov    0x1d8(%r14),%rdi
  a2f5b3:	test   %rdi,%rdi
  a2f5b6:	jne    a2f8cd <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x152d>
  a2f5bc:	jmp    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2f5c1:	cmpb   $0x0,0x2(%r15)
  a2f5c6:	jne    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2f5cc:	mov    $0xffffffff,%eax
  a2f5d1:	mov    %rax,0x1b0(%r14)
  a2f5d8:	movq   $0x0,0x1b8(%r14)
  a2f5e3:	cmpl   $0x1,(%r14)
  a2f5e7:	jne    a2f622 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1282>
  a2f5e9:	lea    0x8(%r14),%rsi
  a2f5ed:	lea    0x800(%rsp),%r15
  a2f5f5:	mov    %r15,%rdi
  a2f5f8:	call   9b9680 <<gpui::runtime::Win<empty::Empty>>::clear_focus>
  a2f5fd:	lea    0x250(%rsp),%rdi
  a2f605:	mov    %r14,%rsi
  a2f608:	mov    %r15,%rdx
  a2f60b:	call   a2ba40 <<gpui::native::NativeHost<empty::Empty>>::input_result>
  a2f610:	mov    0x250(%rsp),%rbp
  a2f618:	cmp    $0xfffffffffffffffe,%rbp
  a2f61c:	jne    a2fb40 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x17a0>
  a2f622:	movl   $0x0,0x200(%r14)
  a2f62d:	jmp    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2f632:	mov    %r14,%rdi
  a2f635:	call   a2bbc0 <<gpui::native::NativeHost<empty::Empty>>::retire_window>
  a2f63a:	jmp    a2e6ec <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x34c>
  a2f63f:	mov    $0xffffffff,%eax
  a2f644:	mov    %rax,0x1b0(%r14)
  a2f64b:	movq   $0x0,0x1b8(%r14)
  a2f656:	jmp    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2f65b:	cmpl   $0x1,(%r14)
  a2f65f:	jne    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2f665:	movupd 0x8(%r15),%xmm0
  a2f66b:	cvtpd2ps %xmm0,%xmm0
  a2f66f:	lea    0x8(%r14),%rsi
  a2f673:	lea    0x1b0(%r14),%rdx
  a2f67a:	movl   $0x0,0x800(%rsp)
  a2f685:	movlpd %xmm0,0x804(%rsp)
  a2f68e:	lea    0x720(%rsp),%rdi
  a2f696:	lea    0x800(%rsp),%rcx
  a2f69e:	call   9b96d0 <<gpui::runtime::Win<empty::Empty>>::pointer_event>
  a2f6a3:	mov    0x720(%rsp),%rax
  a2f6ab:	cmp    $0xfffffffffffffffe,%rax
  a2f6af:	jne    a2faab <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x170b>
  a2f6b5:	cmpq   $0x0,0x748(%rsp)
  a2f6be:	jne    a2fac2 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1722>
  a2f6c4:	jmp    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2f6c9:	cmpl   $0x1,(%r14)
  a2f6cd:	jne    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2f6d3:	lea    0x8(%r14),%rsi
  a2f6d7:	lea    0x1b0(%r14),%rdx
  a2f6de:	movl   $0x1,0x800(%rsp)
  a2f6e9:	lea    0x758(%rsp),%rdi
  a2f6f1:	lea    0x800(%rsp),%rcx
  a2f6f9:	call   9b96d0 <<gpui::runtime::Win<empty::Empty>>::pointer_event>
  a2f6fe:	mov    0x758(%rsp),%rax
  a2f706:	cmp    $0xfffffffffffffffe,%rax
  a2f70a:	jne    a2fad4 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1734>
  a2f710:	cmpq   $0x0,0x780(%rsp)
  a2f719:	jne    a2faeb <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x174b>
  a2f71f:	jmp    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2f724:	cmpw   $0x0,0x2(%r15)
  a2f72a:	jne    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2f730:	cmpl   $0x1,(%r14)
  a2f734:	jne    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2f73a:	cmpb   $0x1,0x8(%r15)
  a2f73f:	mov    $0x3,%eax
  a2f744:	sbb    $0x0,%eax
  a2f747:	lea    0x8(%r14),%rsi
  a2f74b:	lea    0x1b0(%r14),%rdx
  a2f752:	mov    %eax,0x800(%rsp)
  a2f759:	lea    0x7c8(%rsp),%rdi
  a2f761:	lea    0x800(%rsp),%rcx
  a2f769:	call   9b96d0 <<gpui::runtime::Win<empty::Empty>>::pointer_event>
  a2f76e:	mov    0x7c8(%rsp),%rax
  a2f776:	cmp    $0xfffffffffffffffe,%rax
  a2f77a:	je     a2fb16 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1776>
  a2f780:	cmp    $0x19,%eax
  a2f783:	jne    a2fb16 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1776>
  a2f789:	lea    0x7c8(%rsp),%rdi
  a2f791:	call   a28d20 <core::ptr::drop_glue::<gpui::runtime::Error>>
  a2f796:	jmp    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2f79b:	mov    0x1d8(%r14),%rdi
  a2f7a2:	test   %rdi,%rdi
  a2f7a5:	je     a2f9d4 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1634>
  a2f7ab:	add    $0x10,%rdi
  a2f7af:	call   a2a600 <<winit::window::Window>::scale_factor>
  a2f7b4:	jmp    a2f9dc <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x163c>
  a2f7b9:	lea    0x838(%rsp),%rax
  a2f7c1:	lea    0x810(%rsp),%rcx
  a2f7c9:	lea    0x818(%rsp),%rdx
  a2f7d1:	mov    %rax,0x100(%rsp)
  a2f7d9:	mov    0xafd618(%rip),%rax        # 152cdf8 <_DYNAMIC+0x860>
  a2f7e0:	mov    %rax,0x108(%rsp)
  a2f7e8:	mov    %rcx,0x110(%rsp)
  a2f7f0:	mov    0xafd319(%rip),%rax        # 152cb10 <_DYNAMIC+0x578>
  a2f7f7:	mov    %rax,0x118(%rsp)
  a2f7ff:	mov    %rdx,0x120(%rsp)
  a2f807:	mov    %rax,0x128(%rsp)
  a2f80f:	lea    0x70(%rsp),%rax
  a2f814:	mov    %rax,0x130(%rsp)
  a2f81c:	mov    0xafe105(%rip),%rax        # 152d928 <_DYNAMIC+0x1390>
  a2f823:	mov    %rax,0x138(%rsp)
  a2f82b:	lea    -0x8c4b4e(%rip),%rdi        # 16ace4 <anon.2277df3ceaea8d4be421179083a68ea6.39.llvm.213539347725472506+0x87>
  a2f832:	lea    0x100(%rsp),%rsi
  a2f83a:	call   *0xafe020(%rip)        # 152d860 <_DYNAMIC+0x12c8>
  a2f840:	movapd 0x800(%rsp),%xmm0
  a2f849:	movapd 0x810(%rsp),%xmm1
  a2f852:	movaps 0x820(%rsp),%xmm2
  a2f85a:	movups %xmm2,0x1d8(%rsp)
  a2f862:	movupd %xmm1,0x1c8(%rsp)
  a2f86b:	movupd %xmm0,0x1b8(%rsp)
  a2f874:	movq   $0xfffffffffffffffe,0x1b0(%rsp)
  a2f880:	lea    0x70(%rsp),%rdi
  a2f885:	call   a28d20 <core::ptr::drop_glue::<gpui::runtime::Error>>
  a2f88a:	lea    0x6e8(%rsp),%rdi
  a2f892:	lea    0x1b0(%rsp),%rdx
  a2f89a:	mov    %r14,%rsi
  a2f89d:	call   a2ba40 <<gpui::native::NativeHost<empty::Empty>>::input_result>
  a2f8a2:	cmpl   $0xfffffffe,0x6e8(%rsp)
  a2f8aa:	jne    a2f990 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x15f0>
  a2f8b0:	cmpl   $0xffffffff,0x30(%r14)
  a2f8b5:	je     a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2f8b7:	mov    0x1d8(%r14),%rdi
  a2f8be:	test   %rdi,%rdi
  a2f8c1:	sete   %al
  a2f8c4:	or     0x204(%r14),%al
  a2f8cb:	jne    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2f8cd:	add    $0x10,%rdi
  a2f8d1:	call   a2a790 <<winit::window::Window>::request_redraw>
  a2f8d6:	cmpl   $0xfffffffe,0xf8(%r14)
  a2f8de:	jne    a2f97e <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x15de>
  a2f8e4:	cmpl   $0xfffffffe,0x48(%r14)
  a2f8e9:	je     a2f97e <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x15de>
  a2f8ef:	cmpb   $0x0,(%r14)
  a2f8f3:	je     a2f97e <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x15de>
  a2f8f9:	lea    0x48(%r14),%r15
  a2f8fd:	lea    0x8(%r14),%rdx
  a2f901:	lea    0x658(%rsp),%rdi
  a2f909:	mov    %r15,%rsi
  a2f90c:	call   9e48d0 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>>
  a2f911:	cmpl   $0xfffffffe,0x658(%rsp)
  a2f919:	je     a2f97e <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x15de>
  a2f91b:	mov    %r15,%rdi
  a2f91e:	call   a26340 <core::ptr::drop_glue::<core::option::Option<gpui::native::accessibility::Bridge>>>
  a2f923:	add    $0xf8,%r14
  a2f92a:	movq   $0xfffffffffffffffe,(%r15)
  a2f931:	cmpl   $0xfffffffe,(%r14)
  a2f935:	je     a2f93f <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x159f>
  a2f937:	mov    %r14,%rdi
  a2f93a:	call   a28c80 <core::ptr::drop_glue::<gpui::native::NativeError>>
  a2f93f:	mov    0x688(%rsp),%rax
  a2f947:	mov    %rax,0x30(%r14)
  a2f94b:	movupd 0x658(%rsp),%xmm0
  a2f954:	movupd 0x668(%rsp),%xmm1
  a2f95d:	movups 0x678(%rsp),%xmm2
  a2f965:	movups %xmm2,0x20(%r14)
  a2f96a:	movupd %xmm1,0x10(%r14)
  a2f970:	movupd %xmm0,(%r14)
  a2f975:	mov    %rbx,%rdi
  a2f978:	call   *0xafe03a(%rip)        # 152d9b8 <_DYNAMIC+0x1420>
  a2f97e:	add    $0xb88,%rsp
  a2f985:	pop    %rbx
  a2f986:	pop    %r12
  a2f988:	pop    %r13
  a2f98a:	pop    %r14
  a2f98c:	pop    %r15
  a2f98e:	pop    %rbp
  a2f98f:	ret
  a2f990:	lea    0xf8(%r14),%r15
  a2f997:	cmpl   $0xfffffffe,0xf8(%r14)
  a2f99f:	je     a2f9a9 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1609>
  a2f9a1:	mov    %r15,%rdi
  a2f9a4:	call   a28c80 <core::ptr::drop_glue::<gpui::native::NativeError>>
  a2f9a9:	mov    0x718(%rsp),%rax
  a2f9b1:	mov    %rax,0x30(%r15)
  a2f9b5:	movupd 0x6e8(%rsp),%xmm0
  a2f9be:	movupd 0x6f8(%rsp),%xmm1
  a2f9c7:	movups 0x708(%rsp),%xmm2
  a2f9cf:	jmp    a2e4a6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x106>
  a2f9d4:	movsd  -0x8a0ee4(%rip),%xmm0        # 18eaf8 <anon.822e710a3ac147487bb68930a699e853.84.llvm.7311037932848680773+0x20>
  a2f9dc:	cmpb   $0x0,0x8(%r15)
  a2f9e1:	je     a2f9fb <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x165b>
  a2f9e3:	movupd 0x10(%r15),%xmm1
  a2f9e9:	xorpd  -0x8a2491(%rip),%xmm1        # 18d560 <anon.822e710a3ac147487bb68930a699e853.89.llvm.7311037932848680773+0xd0>
  a2f9f1:	unpcklpd %xmm0,%xmm0
  a2f9f5:	divpd  %xmm0,%xmm1
  a2f9f9:	jmp    a2fa08 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1668>
  a2f9fb:	cvtps2pd 0xc(%r15),%xmm1
  a2fa00:	mulpd  -0x8a3d68(%rip),%xmm1        # 18bca0 <anon.5ee778dbc9410921a725c4c57b32111b.58.llvm.8966071514708437312+0x130>
  a2fa08:	movq   %xmm1,%rax
  a2fa0d:	movabs $0x7fffffffffffffff,%rcx
  a2fa17:	and    %rcx,%rax
  a2fa1a:	movabs $0x7fefffffffffffff,%rdx
  a2fa24:	cmp    %rdx,%rax
  a2fa27:	setg   %al
  a2fa2a:	movdqa %xmm1,%xmm0
  a2fa2e:	punpckhqdq %xmm1,%xmm0
  a2fa32:	movq   %xmm0,%rsi
  a2fa37:	and    %rcx,%rsi
  a2fa3a:	cmp    %rdx,%rsi
  a2fa3d:	setg   %cl
  a2fa40:	or     %al,%cl
  a2fa42:	jne    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2fa48:	cmpl   $0x1,(%r14)
  a2fa4c:	jne    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2fa52:	lea    0x8(%r14),%rsi
  a2fa56:	lea    0x1b0(%r14),%rdx
  a2fa5d:	movl   $0x4,0x800(%rsp)
  a2fa68:	movupd %xmm1,0x808(%rsp)
  a2fa71:	lea    0x790(%rsp),%rdi
  a2fa79:	lea    0x800(%rsp),%rcx
  a2fa81:	call   9b96d0 <<gpui::runtime::Win<empty::Empty>>::pointer_event>
  a2fa86:	mov    0x790(%rsp),%rax
  a2fa8e:	cmp    $0xfffffffffffffffe,%rax
  a2fa92:	je     a2fb04 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1764>
  a2fa94:	cmp    $0x19,%eax
  a2fa97:	jne    a2fb04 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1764>
  a2fa99:	lea    0x790(%rsp),%rdi
  a2faa1:	call   a28d20 <core::ptr::drop_glue::<gpui::runtime::Error>>
  a2faa6:	jmp    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2faab:	cmp    $0x19,%eax
  a2faae:	jne    a2fac2 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1722>
  a2fab0:	lea    0x720(%rsp),%rdi
  a2fab8:	call   a28d20 <core::ptr::drop_glue::<gpui::runtime::Error>>
  a2fabd:	jmp    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2fac2:	lea    0x250(%rsp),%rdi
  a2faca:	lea    0x720(%rsp),%rdx
  a2fad2:	jmp    a2fb26 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1786>
  a2fad4:	cmp    $0x19,%eax
  a2fad7:	jne    a2faeb <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x174b>
  a2fad9:	lea    0x758(%rsp),%rdi
  a2fae1:	call   a28d20 <core::ptr::drop_glue::<gpui::runtime::Error>>
  a2fae6:	jmp    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2faeb:	lea    0x250(%rsp),%rdi
  a2faf3:	lea    0x758(%rsp),%rdx
  a2fafb:	jmp    a2fb26 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1786>
  a2fafd:	xor    %ecx,%ecx
  a2faff:	jmp    a2fb95 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x17f5>
  a2fb04:	lea    0x250(%rsp),%rdi
  a2fb0c:	lea    0x790(%rsp),%rdx
  a2fb14:	jmp    a2fb26 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1786>
  a2fb16:	lea    0x250(%rsp),%rdi
  a2fb1e:	lea    0x7c8(%rsp),%rdx
  a2fb26:	mov    %r14,%rsi
  a2fb29:	call   a2ba40 <<gpui::native::NativeHost<empty::Empty>>::input_result>
  a2fb2e:	mov    0x250(%rsp),%rbp
  a2fb36:	cmp    $0xfffffffffffffffe,%rbp
  a2fb3a:	je     a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2fb40:	mov    0x258(%rsp),%r13
  a2fb48:	mov    0x260(%rsp),%r12
  a2fb50:	mov    0x268(%rsp),%r15
  a2fb58:	movupd 0x270(%rsp),%xmm0
  a2fb61:	movapd %xmm0,0x10(%rsp)
  a2fb67:	mov    0x280(%rsp),%rax
  a2fb6f:	mov    %rax,0x20(%rsp)
  a2fb74:	jmp    a2e69f <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x2ff>
  a2fb79:	cmp    $0x18,%sil
  a2fb7d:	jae    a2fd49 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x19a9>
  a2fb83:	lea    0x61(%r15),%rcx
  a2fb87:	jmp    a2fb95 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x17f5>
  a2fb89:	mov    0x68(%r15),%rcx
  a2fb8d:	mov    0x70(%r15),%rsi
  a2fb91:	add    $0x10,%rcx
  a2fb95:	mov    0x200(%r14),%edx
  a2fb9c:	test   $0x820,%edx
  a2fba2:	jne    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2fba8:	cmpl   $0x1,(%r14)
  a2fbac:	jne    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2fbb2:	test   %ax,%ax
  a2fbb5:	je     a2fc52 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x18b2>
  a2fbbb:	test   %rcx,%rcx
  a2fbbe:	je     a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2fbc4:	mov    %rcx,0x108(%rsp)
  a2fbcc:	mov    %rsi,0x110(%rsp)
  a2fbd4:	xor    %eax,%eax
  a2fbd6:	lea    0x8(%r14),%rsi
  a2fbda:	mov    %al,0x100(%rsp)
  a2fbe1:	lea    0x250(%rsp),%r15
  a2fbe9:	lea    0x100(%rsp),%rdx
  a2fbf1:	mov    %r15,%rdi
  a2fbf4:	call   9ba360 <<gpui::runtime::Win<empty::Empty>>::key>
  a2fbf9:	lea    0x800(%rsp),%rdi
  a2fc01:	mov    %r14,%rsi
  a2fc04:	mov    %r15,%rdx
  a2fc07:	call   a2ba40 <<gpui::native::NativeHost<empty::Empty>>::input_result>
  a2fc0c:	mov    0x800(%rsp),%rbp
  a2fc14:	cmp    $0xfffffffffffffffe,%rbp
  a2fc18:	je     a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2fc1e:	mov    0x808(%rsp),%r13
  a2fc26:	mov    0x810(%rsp),%r12
  a2fc2e:	mov    0x818(%rsp),%r15
  a2fc36:	movupd 0x820(%rsp),%xmm0
  a2fc3f:	movapd %xmm0,0x10(%rsp)
  a2fc45:	mov    0x830(%rsp),%rax
  a2fc4d:	jmp    a2fb6f <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x17cf>
  a2fc52:	movzwl 0x2(%r15),%eax
  a2fc57:	add    $0xfffffff2,%eax
  a2fc5a:	cmp    $0xb,%eax
  a2fc5d:	ja     a2fbbb <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x181b>
  a2fc63:	lea    -0x89abca(%rip),%rdi        # 1950a0 <anon.41931c7f01a0f669fcd75d8bc79f57d6.412.llvm.13234298307199123836+0x18e>
  a2fc6a:	movslq (%rdi,%rax,4),%rax
  a2fc6e:	add    %rdi,%rax
  a2fc71:	jmp    *%rax
  a2fc73:	mov    $0x6,%al
  a2fc75:	jmp    a2fbd6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1836>
  a2fc7a:	lea    -0x89a971(%rip),%rdi        # 195310 <anon.fff2d4355c6109bc0e8af2445443084d.58.llvm.4725208967334239140>
  a2fc81:	lea    0xa8d080(%rip),%rcx        # 14bcd08 <anon.fff2d4355c6109bc0e8af2445443084d.8.llvm.4725208967334239140>
  a2fc88:	lea    0xa8d2f9(%rip),%r8        # 14bcf88 <anon.fff2d4355c6109bc0e8af2445443084d.60.llvm.4725208967334239140>
  a2fc8f:	lea    0x3f(%rsp),%rdx
  a2fc94:	mov    $0x37,%esi
  a2fc99:	call   *0xafcc71(%rip)        # 152c910 <_DYNAMIC+0x378>
  a2fc9f:	jmp    a2fd71 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x19d1>
  a2fca4:	lea    -0x8a02d3(%rip),%rdi        # 18f9d8 <anon.5e2c2cd338f183f0185d3116c074ef00.75.llvm.4553572696083558104>
  a2fcab:	lea    0xa88fbe(%rip),%rdx        # 14b8c70 <anon.5e2c2cd338f183f0185d3116c074ef00.76.llvm.4553572696083558104>
  a2fcb2:	mov    $0x14,%esi
  a2fcb7:	call   *0xafcc4b(%rip)        # 152c908 <_DYNAMIC+0x370>
  a2fcbd:	mov    $0x8,%edi
  a2fcc2:	mov    $0x18,%esi
  a2fcc7:	call   *0xafcb33(%rip)        # 152c800 <_DYNAMIC+0x268>
  a2fccd:	jmp    a2fd71 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x19d1>
  a2fcd2:	mov    $0x7,%al
  a2fcd4:	jmp    a2fbd6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1836>
  a2fcd9:	mov    $0x1,%al
  a2fcdb:	jmp    a2fbd6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1836>
  a2fce0:	test   $0x4,%dl
  a2fce3:	sete   %al
  a2fce6:	xor    $0x5,%al
  a2fce8:	jmp    a2fbd6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1836>
  a2fced:	shr    $0x2,%dl
  a2fcf0:	and    $0x1,%dl
  a2fcf3:	mov    %dl,0x101(%rsp)
  a2fcfa:	mov    $0x2,%al
  a2fcfc:	jmp    a2fbd6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1836>
  a2fd01:	shr    $0x2,%dl
  a2fd04:	and    $0x1,%dl
  a2fd07:	mov    %dl,0x101(%rsp)
  a2fd0e:	mov    $0x3,%al
  a2fd10:	jmp    a2fbd6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1836>
  a2fd15:	mov    0xafdcb4(%rip),%rdi        # 152d9d0 <_DYNAMIC+0x1438>
  a2fd1c:	call   *0xafd5de(%rip)        # 152d300 <_DYNAMIC+0xd68>
  a2fd22:	test   %al,%al
  a2fd24:	jne    a2eaa1 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x701>
  a2fd2a:	jmp    a2ece7 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x947>
  a2fd2f:	mov    0xafdc92(%rip),%rdi        # 152d9c8 <_DYNAMIC+0x1430>
  a2fd36:	call   *0xafd5c4(%rip)        # 152d300 <_DYNAMIC+0xd68>
  a2fd3c:	test   %al,%al
  a2fd3e:	jne    a2e987 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x5e7>
  a2fd44:	jmp    a2edcd <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xa2d>
  a2fd49:	lea    0xa8d1d0(%rip),%rcx        # 14bcf20 <anon.fff2d4355c6109bc0e8af2445443084d.8.llvm.4725208967334239140+0x218>
  a2fd50:	mov    $0x17,%edx
  a2fd55:	xor    %edi,%edi
  a2fd57:	call   *0xafcabb(%rip)        # 152c818 <_DYNAMIC+0x280>
  a2fd5d:	mov    %ebp,0x8(%rsp)
  a2fd61:	mov    $0x1,%edi
  a2fd66:	mov    $0x35,%esi
  a2fd6b:	call   *0xafcb57(%rip)        # 152c8c8 <_DYNAMIC+0x330>
  a2fd71:	ud2
  a2fd73:	mov    %r13,(%r15)
  a2fd76:	mov    %rax,%rdi
  a2fd79:	call   14b7130 <_Unwind_Resume@plt>
  a2fd7e:	mov    %rax,%rbx
  a2fd81:	movq   $0x1,(%r14)
  a2fd88:	mov    %r13,0x8(%r14)
  a2fd8c:	movl   $0x0,0x8(%rsp)
  a2fd94:	jmp    a2ff28 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1b88>
  a2fd99:	mov    %rax,%rbx
  a2fd9c:	lea    0x40(%rsp),%rdi
  a2fda1:	call   a28b90 <core::ptr::drop_glue::<tracing::span::Span>>
  a2fda6:	jmp    a2feec <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1b4c>
  a2fdab:	call   *0xafca6f(%rip)        # 152c820 <_DYNAMIC+0x288>
  a2fdb1:	mov    %rax,%rbx
  a2fdb4:	lea    0x250(%rsp),%rdi
  a2fdbc:	call   a28b90 <core::ptr::drop_glue::<tracing::span::Span>>
  a2fdc1:	jmp    a300d8 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1d38>
  a2fdc6:	call   *0xafca54(%rip)        # 152c820 <_DYNAMIC+0x288>
  a2fdcc:	mov    %rax,%rbx
  a2fdcf:	lea    0x70(%rsp),%rdi
  a2fdd4:	call   a28d20 <core::ptr::drop_glue::<gpui::runtime::Error>>
  a2fdd9:	mov    %rbx,%rdi
  a2fddc:	call   14b7130 <_Unwind_Resume@plt>
  a2fde1:	mov    %rax,%rbx
  a2fde4:	lea    0x250(%rsp),%rdi
  a2fdec:	call   a275d0 <core::ptr::drop_glue::<core::iter::adapters::flatten::Flatten<core::array::iter::IntoIter<core::option::Option<core::result::Result<gpui::runtime::Commit, gpui::runtime::Error>>, 16>>>>
  a2fdf1:	mov    %rbx,%rdi
  a2fdf4:	call   14b7130 <_Unwind_Resume@plt>
  a2fdf9:	mov    %rax,%rbx
  a2fdfc:	lea    0x100(%rsp),%rsi
  a2fe04:	mov    $0xb0,%edx
  a2fe09:	mov    %rbp,%rdi
  a2fe0c:	call   *0xafc9e6(%rip)        # 152c7f8 <memcpy@GLIBC_2.14>
  a2fe12:	movl   $0x0,0x8(%rsp)
  a2fe1a:	jmp    a2fe44 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1aa4>
  a2fe1c:	mov    %rax,%rbx
  a2fe1f:	lock decq (%r15)
  a2fe23:	mov    $0x1,%al
  a2fe25:	mov    %eax,0x8(%rsp)
  a2fe29:	jne    a2fe44 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1aa4>
  a2fe2b:	lea    0xd0(%rsp),%rdi
  a2fe33:	call   *0xafdae7(%rip)        # 152d920 <_DYNAMIC+0x1388>
  a2fe39:	jmp    a2fe44 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1aa4>
  a2fe3b:	call   *0xafc9df(%rip)        # 152c820 <_DYNAMIC+0x288>
  a2fe41:	mov    %rax,%rbx
  a2fe44:	mov    %r13,%rdi
  a2fe47:	call   a26ee0 <core::ptr::drop_glue::<gpui::runtime::Win<empty::Empty>>>
  a2fe4c:	jmp    a2ff28 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1b88>
  a2fe51:	movq   $0x0,(%r15)
  a2fe58:	mov    %rax,%rdi
  a2fe5b:	call   14b7130 <_Unwind_Resume@plt>
  a2fe60:	mov    %rax,%rbx
  a2fe63:	mov    0x8(%r15),%rsi
  a2fe67:	test   %rsi,%rsi
  a2fe6a:	je     a2fe79 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1ad9>
  a2fe6c:	mov    0x10(%r15),%rdx
  a2fe70:	mov    %r13,%rdi
  a2fe73:	call   *0xafc96f(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  a2fe79:	mov    %rbp,0x1f0(%r14)
  a2fe80:	mov    0x8(%rsp),%rax
  a2fe85:	mov    %rax,0x1f8(%r14)
  a2fe8c:	jmp    a2ff79 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1bd9>
  a2fe91:	mov    %rax,%rbx
  a2fe94:	mov    0x8(%r15),%rsi
  a2fe98:	test   %rsi,%rsi
  a2fe9b:	je     a2feaa <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1b0a>
  a2fe9d:	mov    0x10(%r15),%rdx
  a2fea1:	mov    %r13,%rdi
  a2fea4:	call   *0xafc93e(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  a2feaa:	mov    %rbp,0x1e0(%r14)
  a2feb1:	mov    0x8(%rsp),%rax
  a2feb6:	mov    %rax,0x1e8(%r14)
  a2febd:	mov    $0x1,%bpl
  a2fec0:	mov    $0x1,%r14b
  a2fec3:	jmp    a30058 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1cb8>
  a2fec8:	mov    %rax,%rbx
  a2fecb:	movq   $0xfffffffffffffffe,(%r15)
  a2fed2:	lea    0x808(%rsp),%rdi
  a2feda:	call   a28c80 <core::ptr::drop_glue::<gpui::native::NativeError>>
  a2fedf:	mov    %rbx,%rdi
  a2fee2:	call   14b7130 <_Unwind_Resume@plt>
  a2fee7:	jmp    a2ff1f <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1b7f>
  a2fee9:	mov    %rax,%rbx
  a2feec:	lea    0x800(%rsp),%rdi
  a2fef4:	call   a27e00 <core::ptr::drop_glue::<winit::window::WindowAttributes>>
  a2fef9:	jmp    a30053 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1cb3>
  a2fefe:	mov    %rax,%rbx
  a2ff01:	movw   $0x2,(%r12)
  a2ff08:	mov    %rbx,%rdi
  a2ff0b:	call   14b7130 <_Unwind_Resume@plt>
  a2ff10:	movq   $0xffffffffffffffff,(%r15)
  a2ff17:	mov    %rax,%rdi
  a2ff1a:	call   14b7130 <_Unwind_Resume@plt>
  a2ff1f:	mov    %rax,%rbx
  a2ff22:	mov    $0x1,%al
  a2ff24:	mov    %eax,0x8(%rsp)
  a2ff28:	mov    0x30(%rsp),%rax
  a2ff2d:	lock decq (%rax)
  a2ff31:	jne    a2ff3e <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1b9e>
  a2ff33:	lea    0x30(%rsp),%rdi
  a2ff38:	call   *0xafd442(%rip)        # 152d380 <_DYNAMIC+0xde8>
  a2ff3e:	cmpb   $0x0,0x8(%rsp)
  a2ff43:	jne    a30053 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1cb3>
  a2ff49:	jmp    a300d8 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1d38>
  a2ff4e:	mov    %rax,%rbx
  a2ff51:	lea    0xd0(%rsp),%rdi
  a2ff59:	call   a28b10 <core::ptr::drop_glue::<tracing::span::EnteredSpan>>
  a2ff5e:	jmp    a30053 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1cb3>
  a2ff63:	call   *0xafc8b7(%rip)        # 152c820 <_DYNAMIC+0x288>
  a2ff69:	mov    %rax,%rbx
  a2ff6c:	lea    0x100(%rsp),%rdi
  a2ff74:	call   a260f0 <core::ptr::drop_glue::<core::option::Option<winit::window::Fullscreen>>>
  a2ff79:	mov    $0x1,%r14b
  a2ff7c:	xor    %ebp,%ebp
  a2ff7e:	jmp    a30058 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1cb8>
  a2ff83:	call   *0xafc897(%rip)        # 152c820 <_DYNAMIC+0x288>
  a2ff89:	mov    %rax,%rbx
  a2ff8c:	mov    $0x1,%r14b
  a2ff8f:	mov    $0x1,%bpl
  a2ff92:	jmp    a30087 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1ce7>
  a2ff97:	mov    %rax,%rbx
  a2ff9a:	jmp    a30053 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1cb3>
  a2ff9f:	mov    %rax,%rbx
  a2ffa2:	inc    %r13
  a2ffa5:	mov    %r13,0x258(%rsp)
  a2ffad:	lea    0x250(%rsp),%rdi
  a2ffb5:	call   a275d0 <core::ptr::drop_glue::<core::iter::adapters::flatten::Flatten<core::array::iter::IntoIter<core::option::Option<core::result::Result<gpui::runtime::Commit, gpui::runtime::Error>>, 16>>>>
  a2ffba:	mov    %rbx,%rdi
  a2ffbd:	call   14b7130 <_Unwind_Resume@plt>
  a2ffc2:	mov    %rax,%rbx
  a2ffc5:	movq   $0xfffffffffffffffe,(%r15)
  a2ffcc:	lea    0x658(%rsp),%rdi
  a2ffd4:	call   a28c80 <core::ptr::drop_glue::<gpui::native::NativeError>>
  a2ffd9:	mov    %rbx,%rdi
  a2ffdc:	call   14b7130 <_Unwind_Resume@plt>
  a2ffe1:	movq   $0x0,(%r15)
  a2ffe8:	mov    %rax,%rdi
  a2ffeb:	call   14b7130 <_Unwind_Resume@plt>
  a2fff0:	movw   $0x2,0x188(%r14)
  a2fffa:	mov    %rax,%rdi
  a2fffd:	call   14b7130 <_Unwind_Resume@plt>
  a30002:	movq   $0xffffffffffffffff,(%r15)
  a30009:	mov    %rax,%rdi
  a3000c:	call   14b7130 <_Unwind_Resume@plt>
  a30011:	mov    %rax,%rbx
  a30014:	lea    0x250(%rsp),%rdi
  a3001c:	call   a26cc0 <core::ptr::drop_glue::<alloc::sync::ArcInner<winit::window::Window>>>
  a30021:	jmp    a30053 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1cb3>
  a30023:	call   *0xafc7f7(%rip)        # 152c820 <_DYNAMIC+0x288>
  a30029:	mov    %rax,%rbx
  a3002c:	mov    0x40(%rsp),%rsi
  a30031:	test   %rsi,%rsi
  a30034:	je     a30046 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1ca6>
  a30036:	mov    0x48(%rsp),%rdi
  a3003b:	mov    $0x1,%edx
  a30040:	call   *0xafc7a2(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  a30046:	lea    0x250(%rsp),%rdi
  a3004e:	call   a27d80 <core::ptr::drop_glue::<winit::error::OsError>>
  a30053:	xor    %ebp,%ebp
  a30055:	xor    %r14d,%r14d
  a30058:	mov    0xb8(%rsp),%rsi
  a30060:	test   %rsi,%rsi
  a30063:	jne    a3006c <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1ccc>
  a30065:	test   %r14b,%r14b
  a30068:	jne    a30084 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1ce4>
  a3006a:	jmp    a300be <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1d1e>
  a3006c:	mov    0xc0(%rsp),%rdi
  a30074:	mov    $0x1,%edx
  a30079:	call   *0xafc769(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  a3007f:	test   %r14b,%r14b
  a30082:	je     a300be <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1d1e>
  a30084:	xor    %r14d,%r14d
  a30087:	cmpq   $0x0,0x68(%rsp)
  a3008d:	je     a300a4 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1d04>
  a3008f:	mov    0x78(%rsp),%rdi
  a30094:	mov    $0x1,%edx
  a30099:	mov    0x68(%rsp),%rsi
  a3009e:	call   *0xafc744(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  a300a4:	test   %r14b,%r14b
  a300a7:	je     a300be <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1d1e>
  a300a9:	mov    0x90(%rsp),%rdi
  a300b1:	mov    0x98(%rsp),%rsi
  a300b9:	call   a253a0 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<dyn for<'a> core::ops::function::FnMut<(&'a gpui::runtime::Error,), Output = ()>>>>>
  a300be:	test   %bpl,%bpl
  a300c1:	je     a300d8 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1d38>
  a300c3:	mov    0xa0(%rsp),%rdi
  a300cb:	mov    0xa8(%rsp),%rsi
  a300d3:	call   a253a0 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<dyn for<'a> core::ops::function::FnMut<(&'a gpui::runtime::Error,), Output = ()>>>>>
  a300d8:	mov    %rbx,%rdi
  a300db:	call   14b7130 <_Unwind_Resume@plt>
  a300e0:	call   *0xafc73a(%rip)        # 152c820 <_DYNAMIC+0x288>
  a300e6:	call   *0xafc734(%rip)        # 152c820 <_DYNAMIC+0x288>


/tmp/gpui-a11y-owner-channel-captures/release-candidate/empty:     file format elf64-x86-64


Disassembly of section .text:

0000000000a48ce0 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>>:
  a48ce0:	push   %rbp
  a48ce1:	push   %r15
  a48ce3:	push   %r14
  a48ce5:	push   %r13
  a48ce7:	push   %r12
  a48ce9:	push   %rbx
  a48cea:	sub    $0xe8,%rsp
  a48cf1:	mov    %rdx,%r14
  a48cf4:	mov    %rdi,%rbx
  a48cf7:	mov    %rcx,0x8(%rsp)
  a48cfc:	mov    %r8,0x10(%rsp)
  a48d01:	mov    %r9,0x18(%rsp)
  a48d06:	mov    0xae45d3(%rip),%rax        # 152d2e0 <_DYNAMIC+0xd48>
  a48d0d:	mov    (%rax),%rax
  a48d10:	cmp    $0x1,%rax
  a48d14:	ja     a48d9a <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0xba>
  a48d1a:	mov    0xae4c57(%rip),%r15        # 152d978 <_DYNAMIC+0x13e0>
  a48d21:	movzbl 0x10(%r15),%eax
  a48d26:	movzbl %al,%ecx
  a48d29:	lea    -0x1(%rcx),%edx
  a48d2c:	cmp    $0x2,%edx
  a48d2f:	jae    a48d92 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0xb2>
  a48d31:	mov    (%r15),%rdi
  a48d34:	movzbl %al,%esi
  a48d37:	call   *0xae45b3(%rip)        # 152d2f0 <_DYNAMIC+0xd58>
  a48d3d:	test   %al,%al
  a48d3f:	je     a48d9a <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0xba>
  a48d41:	mov    (%r15),%rsi
  a48d44:	lea    0x30(%rsi),%rax
  a48d48:	movq   $0x1,0x20(%rsp)
  a48d51:	movq   $0x8,0x28(%rsp)
  a48d5a:	movq   $0x0,0x30(%rsp)
  a48d63:	mov    %rax,0x38(%rsp)
  a48d68:	lea    0x50(%rsp),%rdi
  a48d6d:	lea    0x20(%rsp),%rdx
  a48d72:	call   *0xae4b28(%rip)        # 152d8a0 <_DYNAMIC+0x1308>
  a48d78:	cmpq   $0x2,0x50(%rsp)
  a48d7e:	je     a48dac <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0xcc>
  a48d80:	lea    0x68(%rsp),%rsi
  a48d85:	lea    0x50(%rsp),%rdi
  a48d8a:	call   *0xae4b18(%rip)        # 152d8a8 <_DYNAMIC+0x1310>
  a48d90:	jmp    a48dac <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0xcc>
  a48d92:	test   %ecx,%ecx
  a48d94:	jne    a490f8 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x418>
  a48d9a:	movq   $0x2,0x50(%rsp)
  a48da3:	movq   $0x0,0x70(%rsp)
  a48dac:	mov    0x70(%rsp),%rax
  a48db1:	mov    %rax,0x40(%rsp)
  a48db6:	mov    0x50(%rsp),%rax
  a48dbb:	mov    0x58(%rsp),%rcx
  a48dc0:	movups 0x60(%rsp),%xmm0
  a48dc5:	movaps %xmm0,0x30(%rsp)
  a48dca:	mov    %rax,0x20(%rsp)
  a48dcf:	mov    %rcx,0x28(%rsp)
  a48dd4:	mov    (%r14),%rdi
  a48dd7:	add    $0x10,%rdi
  a48ddb:	call   *0xae40c7(%rip)        # 152cea8 <_DYNAMIC+0x910>
  a48de1:	mov    %rax,%r14
  a48de4:	movzbl 0x284(%rax),%ebp
  a48deb:	test   $0x1,%dl
  a48dee:	jne    a48e06 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x126>
  a48df0:	mov    0xae40c1(%rip),%rax        # 152ceb8 <_DYNAMIC+0x920>
  a48df7:	mov    (%rax),%rax
  a48dfa:	shl    $1,%rax
  a48dfd:	test   %rax,%rax
  a48e00:	jne    a490c5 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x3e5>
  a48e06:	xor    %eax,%eax
  a48e08:	xchg   %eax,(%r14)
  a48e0b:	cmp    $0x2,%eax
  a48e0e:	je     a4906a <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x38a>
  a48e14:	lea    0x20(%rsp),%rdi
  a48e19:	call   a4a7a0 <core::ptr::drop_glue::<tracing::span::EnteredSpan>>
  a48e1e:	cmp    $0x1,%bpl
  a48e22:	je     a490dd <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x3fd>
  a48e28:	mov    0x8(%rsp),%r13
  a48e2d:	mov    0x10(%rsp),%r15
  a48e32:	mov    0x18(%rsp),%r12
  a48e37:	mov    %r13,0xc0(%rsp)
  a48e3f:	mov    %r15,0xc8(%rsp)
  a48e47:	mov    %r12,0xd0(%rsp)
  a48e4f:	mov    0xae4d3a(%rip),%rax        # 152db90 <_DYNAMIC+0x15f8>
  a48e56:	mov    $0x1,%ebp
  a48e5b:	lock xadd %rbp,(%rax)
  a48e60:	call   *0xae4d32(%rip)        # 152db98 <_DYNAMIC+0x1600>
  a48e66:	mov    %rax,%r14
  a48e69:	mov    %rax,0xe0(%rsp)
  a48e71:	movq   $0x1,0x50(%rsp)
  a48e7a:	movq   $0x1,0x58(%rsp)
  a48e83:	movq   $0x0,0x60(%rsp)
  a48e8c:	mov    %r15,0x68(%rsp)
  a48e91:	call   *0xae3941(%rip)        # 152c7d8 <_DYNAMIC+0x240>
  a48e97:	mov    $0x20,%edi
  a48e9c:	mov    $0x8,%esi
  a48ea1:	call   *0xae3939(%rip)        # 152c7e0 <_DYNAMIC+0x248>
  a48ea7:	test   %rax,%rax
  a48eaa:	je     a49078 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x398>
  a48eb0:	movups 0x50(%rsp),%xmm0
  a48eb5:	movups 0x60(%rsp),%xmm1
  a48eba:	movups %xmm1,0x10(%rax)
  a48ebe:	movups %xmm0,(%rax)
  a48ec1:	movq   $0x1,0x50(%rsp)
  a48eca:	movq   $0x1,0x58(%rsp)
  a48ed3:	movl   $0x0,0x60(%rsp)
  a48edb:	movb   $0x0,0x64(%rsp)
  a48ee0:	movw   $0x0,0x68(%rsp)
  a48ee7:	xorps  %xmm0,%xmm0
  a48eea:	movups %xmm0,0x70(%rsp)
  a48eef:	movups %xmm0,0x80(%rsp)
  a48ef7:	movups %xmm0,0x90(%rsp)
  a48eff:	movups %xmm0,0xa0(%rsp)
  a48f07:	mov    %rax,0xb0(%rsp)
  a48f0f:	lea    0xa74dc2(%rip),%rax        # 14bdcd8 <anon.f147fac593ac46ed110847a884bcb8dd.57.llvm.11273863535497774694+0x2b8>
  a48f16:	mov    %rax,0xb8(%rsp)
  a48f1e:	call   *0xae38b4(%rip)        # 152c7d8 <_DYNAMIC+0x240>
  a48f24:	mov    $0x70,%edi
  a48f29:	mov    $0x8,%esi
  a48f2e:	call   *0xae38ac(%rip)        # 152c7e0 <_DYNAMIC+0x248>
  a48f34:	test   %rax,%rax
  a48f37:	je     a4908f <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x3af>
  a48f3d:	mov    %rax,%r15
  a48f40:	movups 0xb0(%rsp),%xmm0
  a48f48:	movups %xmm0,0x60(%rax)
  a48f4c:	movups 0xa0(%rsp),%xmm0
  a48f54:	movups %xmm0,0x50(%rax)
  a48f58:	movups 0x90(%rsp),%xmm0
  a48f60:	movups %xmm0,0x40(%rax)
  a48f64:	movups 0x50(%rsp),%xmm0
  a48f69:	movups 0x60(%rsp),%xmm1
  a48f6e:	movups 0x70(%rsp),%xmm2
  a48f73:	movups 0x80(%rsp),%xmm3
  a48f7b:	movups %xmm3,0x30(%rax)
  a48f7f:	movups %xmm2,0x20(%rax)
  a48f83:	movups %xmm1,0x10(%rax)
  a48f87:	movups %xmm0,(%rax)
  a48f8a:	mov    %rax,0xd8(%rsp)
  a48f92:	lock incq (%rax)
  a48f96:	jle    a490f6 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x416>
  a48f9c:	mov    %r14,0x20(%rsp)
  a48fa1:	mov    %rbp,0x30(%rsp)
  a48fa6:	mov    %r15,0x28(%rsp)
  a48fab:	mov    %r13,0x50(%rsp)
  a48fb0:	call   *0xae3822(%rip)        # 152c7d8 <_DYNAMIC+0x240>
  a48fb6:	mov    $0x8,%edi
  a48fbb:	mov    $0x8,%esi
  a48fc0:	call   *0xae381a(%rip)        # 152c7e0 <_DYNAMIC+0x248>
  a48fc6:	mov    %rax,%r14
  a48fc9:	test   %rax,%rax
  a48fcc:	je     a490a1 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x3c1>
  a48fd2:	mov    %r13,(%r14)
  a48fd5:	mov    %r12,0x50(%rsp)
  a48fda:	call   *0xae37f8(%rip)        # 152c7d8 <_DYNAMIC+0x240>
  a48fe0:	mov    $0x8,%edi
  a48fe5:	mov    $0x8,%esi
  a48fea:	call   *0xae37f0(%rip)        # 152c7e0 <_DYNAMIC+0x248>
  a48ff0:	test   %rax,%rax
  a48ff3:	je     a490b3 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x3d3>
  a48ff9:	mov    %r12,(%rax)
  a48ffc:	mov    %rbp,0x80(%rsp)
  a49004:	mov    %r14,0x58(%rsp)
  a49009:	lea    0xa74ce8(%rip),%rcx        # 14bdcf8 <anon.f147fac593ac46ed110847a884bcb8dd.57.llvm.11273863535497774694+0x2d8>
  a49010:	mov    %rcx,0x60(%rsp)
  a49015:	mov    %rax,0x68(%rsp)
  a4901a:	lea    0xa74cf7(%rip),%rax        # 14bdd18 <anon.f147fac593ac46ed110847a884bcb8dd.57.llvm.11273863535497774694+0x2f8>
  a49021:	mov    %rax,0x70(%rsp)
  a49026:	mov    %r15,0x78(%rsp)
  a4902b:	movq   $0x6,0x50(%rsp)
  a49034:	lea    0x20(%rsp),%rdi
  a49039:	lea    0x50(%rsp),%rsi
  a4903e:	call   *0xae4b5c(%rip)        # 152dba0 <_DYNAMIC+0x1608>
  a49044:	mov    0x30(%rsp),%rax
  a49049:	mov    %rax,0x10(%rbx)
  a4904d:	movups 0x20(%rsp),%xmm0
  a49052:	movups %xmm0,(%rbx)
  a49055:	mov    %rbx,%rax
  a49058:	add    $0xe8,%rsp
  a4905f:	pop    %rbx
  a49060:	pop    %r12
  a49062:	pop    %r13
  a49064:	pop    %r14
  a49066:	pop    %r15
  a49068:	pop    %rbp
  a49069:	ret
  a4906a:	mov    %r14,%rdi
  a4906d:	call   *0xae3e6d(%rip)        # 152cee0 <_DYNAMIC+0x948>
  a49073:	jmp    a48e14 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x134>
  a49078:	lea    0x68(%rsp),%r14
  a4907d:	mov    $0x8,%edi
  a49082:	mov    $0x20,%esi
  a49087:	call   *0xae3773(%rip)        # 152c800 <_DYNAMIC+0x268>
  a4908d:	jmp    a490f6 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x416>
  a4908f:	mov    $0x8,%edi
  a49094:	mov    $0x70,%esi
  a49099:	call   *0xae3761(%rip)        # 152c800 <_DYNAMIC+0x268>
  a4909f:	jmp    a490f6 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x416>
  a490a1:	mov    $0x8,%edi
  a490a6:	mov    $0x8,%esi
  a490ab:	call   *0xae374f(%rip)        # 152c800 <_DYNAMIC+0x268>
  a490b1:	jmp    a490f6 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x416>
  a490b3:	mov    $0x8,%edi
  a490b8:	mov    $0x8,%esi
  a490bd:	call   *0xae373d(%rip)        # 152c800 <_DYNAMIC+0x268>
  a490c3:	jmp    a490f6 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x416>
  a490c5:	call   *0xae3e1d(%rip)        # 152cee8 <_DYNAMIC+0x950>
  a490cb:	test   %al,%al
  a490cd:	jne    a48e06 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x126>
  a490d3:	movb   $0x1,0x4(%r14)
  a490d8:	jmp    a48e06 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x126>
  a490dd:	lea    -0x8aef3c(%rip),%rdi        # 19a1a8 <anon.f147fac593ac46ed110847a884bcb8dd.14.llvm.11273863535497774694+0x4b9>
  a490e4:	lea    0xa74bd5(%rip),%rdx        # 14bdcc0 <anon.f147fac593ac46ed110847a884bcb8dd.57.llvm.11273863535497774694+0x2a0>
  a490eb:	mov    $0xd3,%esi
  a490f0:	call   *0xae3732(%rip)        # 152c828 <_DYNAMIC+0x290>
  a490f6:	ud2
  a490f8:	mov    0xae4879(%rip),%rdi        # 152d978 <_DYNAMIC+0x13e0>
  a490ff:	call   *0xae41fb(%rip)        # 152d300 <_DYNAMIC+0xd68>
  a49105:	test   %al,%al
  a49107:	jne    a48d31 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x51>
  a4910d:	jmp    a48d9a <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0xba>
  a49112:	mov    %rax,%rbx
  a49115:	lea    0x50(%rsp),%rdi
  a4911a:	call   a4a820 <core::ptr::drop_glue::<tracing::span::Span>>
  a4911f:	jmp    a49157 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x477>
  a49121:	call   *0xae36f9(%rip)        # 152c820 <_DYNAMIC+0x288>
  a49127:	mov    %rax,%rbx
  a4912a:	xor    %ebp,%ebp
  a4912c:	jmp    a491e8 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x508>
  a49131:	mov    %rax,%rbx
  a49134:	mov    $0x1,%bpl
  a49137:	mov    $0x1,%r14b
  a4913a:	jmp    a49260 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x580>
  a4913f:	mov    %rax,%rbx
  a49142:	lea    0x20(%rsp),%rdi
  a49147:	call   a4a7a0 <core::ptr::drop_glue::<tracing::span::EnteredSpan>>
  a4914c:	jmp    a49157 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x477>
  a4914e:	call   *0xae36cc(%rip)        # 152c820 <_DYNAMIC+0x288>
  a49154:	mov    %rax,%rbx
  a49157:	mov    0x18(%rsp),%rax
  a4915c:	lock decq (%rax)
  a49160:	jne    a4916d <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x48d>
  a49162:	lea    0x18(%rsp),%rdi
  a49167:	call   *0xae4673(%rip)        # 152d7e0 <_DYNAMIC+0x1248>
  a4916d:	mov    0x10(%rsp),%rax
  a49172:	lock decq (%rax)
  a49176:	jne    a49183 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x4a3>
  a49178:	lea    0x10(%rsp),%rdi
  a4917d:	call   *0xae465d(%rip)        # 152d7e0 <_DYNAMIC+0x1248>
  a49183:	mov    0x8(%rsp),%rax
  a49188:	lock decq (%rax)
  a4918c:	jne    a492be <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x5de>
  a49192:	lea    0x8(%rsp),%rdi
  a49197:	call   *0xae4643(%rip)        # 152d7e0 <_DYNAMIC+0x1248>
  a4919d:	jmp    a492be <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x5de>
  a491a2:	call   *0xae3678(%rip)        # 152c820 <_DYNAMIC+0x288>
  a491a8:	mov    %rax,%rbx
  a491ab:	lock decq (%r12)
  a491b0:	jne    a491bd <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x4dd>
  a491b2:	lea    0x50(%rsp),%rdi
  a491b7:	call   *0xae4623(%rip)        # 152d7e0 <_DYNAMIC+0x1248>
  a491bd:	mov    %r14,%rdi
  a491c0:	call   a49c10 <core::ptr::drop_glue::<alloc::boxed::Box<dyn accesskit::ActivationHandler + core::marker::Send>>>
  a491c5:	mov    $0x1,%bpl
  a491c8:	jmp    a491e8 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x508>
  a491ca:	call   *0xae3650(%rip)        # 152c820 <_DYNAMIC+0x288>
  a491d0:	mov    %rax,%rbx
  a491d3:	lock decq 0x0(%r13)
  a491d8:	mov    $0x1,%bpl
  a491db:	jne    a491e8 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x508>
  a491dd:	lea    0x50(%rsp),%rdi
  a491e2:	call   *0xae45f8(%rip)        # 152d7e0 <_DYNAMIC+0x1248>
  a491e8:	lea    0x20(%rsp),%rdi
  a491ed:	call   a49f00 <core::ptr::drop_glue::<accesskit_unix::adapter::Adapter>>
  a491f2:	test   %bpl,%bpl
  a491f5:	je     a49213 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x533>
  a491f7:	mov    0xd8(%rsp),%rax
  a491ff:	lock decq (%rax)
  a49203:	jne    a49213 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x533>
  a49205:	lea    0xd8(%rsp),%rdi
  a4920d:	call   *0xae4605(%rip)        # 152d818 <_DYNAMIC+0x1280>
  a49213:	test   %r14,%r14
  a49216:	jne    a492be <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x5de>
  a4921c:	xor    %ebp,%ebp
  a4921e:	jmp    a4925d <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x57d>
  a49220:	call   *0xae35fa(%rip)        # 152c820 <_DYNAMIC+0x288>
  a49226:	mov    %rax,%rbx
  a49229:	lea    0x50(%rsp),%rdi
  a4922e:	call   a49b10 <core::ptr::drop_glue::<alloc::sync::ArcInner<std::sync::poison::mutex::Mutex<accesskit_unix::adapter::AdapterState>>>>
  a49233:	jmp    a4924d <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x56d>
  a49235:	call   *0xae35e5(%rip)        # 152c820 <_DYNAMIC+0x288>
  a4923b:	mov    %rax,%rbx
  a4923e:	lock decq (%r15)
  a49242:	jne    a4924d <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x56d>
  a49244:	mov    %r14,%rdi
  a49247:	call   *0xae4593(%rip)        # 152d7e0 <_DYNAMIC+0x1248>
  a4924d:	lea    0xe0(%rsp),%rdi
  a49255:	call   a498e0 <core::ptr::drop_glue::<async_channel::Sender<accesskit_unix::adapter::Message>>>
  a4925a:	mov    $0x1,%bpl
  a4925d:	xor    %r14d,%r14d
  a49260:	mov    0xd0(%rsp),%rax
  a49268:	lock decq (%rax)
  a4926c:	jne    a4927c <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x59c>
  a4926e:	lea    0xd0(%rsp),%rdi
  a49276:	call   *0xae4564(%rip)        # 152d7e0 <_DYNAMIC+0x1248>
  a4927c:	test   %r14b,%r14b
  a4927f:	je     a4929d <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x5bd>
  a49281:	mov    0xc8(%rsp),%rax
  a49289:	lock decq (%rax)
  a4928d:	jne    a4929d <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x5bd>
  a4928f:	lea    0xc8(%rsp),%rdi
  a49297:	call   *0xae4543(%rip)        # 152d7e0 <_DYNAMIC+0x1248>
  a4929d:	test   %bpl,%bpl
  a492a0:	je     a492be <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x5de>
  a492a2:	mov    0xc0(%rsp),%rax
  a492aa:	lock decq (%rax)
  a492ae:	jne    a492be <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>+0x5de>
  a492b0:	lea    0xc0(%rsp),%rdi
  a492b8:	call   *0xae4522(%rip)        # 152d7e0 <_DYNAMIC+0x1248>
  a492be:	mov    %rbx,%rdi
  a492c1:	call   14b7130 <_Unwind_Resume@plt>
  a492c6:	call   *0xae3554(%rip)        # 152c820 <_DYNAMIC+0x288>
  a492cc:	call   *0xae354e(%rip)        # 152c820 <_DYNAMIC+0x288>


/tmp/gpui-a11y-owner-channel-captures/release-candidate/empty:     file format elf64-x86-64


Disassembly of section .text:

0000000000a6c310 <<gpui::native::accessibility::Ingress>::prepare_publication>:
  a6c310:	mov    (%rdi),%rdi
  a6c313:	mov    0x40(%rdi),%eax
  a6c316:	test   %eax,%eax
  a6c318:	jne    a6c31b <<gpui::native::accessibility::Ingress>::prepare_publication+0xb>
  a6c31a:	ret
  a6c31b:	add    $0x30,%rdi
  a6c31f:	jmp    a6b10a <<std::sync::once_lock::OnceLock<std::sync::mpsc::SyncSender<gpui::native::accessibility::Queued>>>::initialize::<<std::sync::once_lock::OnceLock<std::sync::mpsc::SyncSender<gpui::native::accessibility::Queued>>>::get_or_init<<gpui::native::accessibility::Ingress>::prepare_publication::{closure#0}>::{closure#0}, !>>


/tmp/gpui-a11y-owner-channel-captures/release-candidate/empty:     file format elf64-x86-64


Disassembly of section .text:

0000000000a6c5b0 <<gpui::native::accessibility::Bridge>::process_event>:
  a6c5b0:	add    $0x88,%rdi
  a6c5b7:	jmp    *0xac17cb(%rip)        # 152dd88 <_DYNAMIC+0x17f0>


/tmp/gpui-a11y-owner-channel-captures/release-candidate/empty:     file format elf64-x86-64


Disassembly of section .text:

0000000000a6c5c0 <<gpui::native::accessibility::Bridge>::new>:
  a6c5c0:	push   %r15
  a6c5c2:	push   %r14
  a6c5c4:	push   %r13
  a6c5c6:	push   %r12
  a6c5c8:	push   %rbx
  a6c5c9:	sub    $0x60,%rsp
  a6c5cd:	mov    %r8,%rbx
  a6c5d0:	mov    %rdx,%r12
  a6c5d3:	mov    %rsi,%r13
  a6c5d6:	mov    %rdi,%r14
  a6c5d9:	movq   $0x1,0x8(%rsp)
  a6c5e2:	movq   $0x1,0x10(%rsp)
  a6c5eb:	movups (%rcx),%xmm0
  a6c5ee:	movups 0x10(%rcx),%xmm1
  a6c5f2:	movups %xmm0,0x18(%rsp)
  a6c5f7:	movups %xmm1,0x28(%rsp)
  a6c5fc:	movl   $0x3,0x48(%rsp)
  a6c604:	movq   $0x0,0x50(%rsp)
  a6c60d:	movl   $0x0,0x57(%rsp)
  a6c615:	call   *0xac01bd(%rip)        # 152c7d8 <_DYNAMIC+0x240>
  a6c61b:	mov    $0x58,%edi
  a6c620:	mov    $0x8,%esi
  a6c625:	call   *0xac01b5(%rip)        # 152c7e0 <_DYNAMIC+0x248>
  a6c62b:	test   %rax,%rax
  a6c62e:	je     a6c732 <<gpui::native::accessibility::Bridge>::new+0x172>
  a6c634:	mov    %rax,%r15
  a6c637:	mov    0x58(%rsp),%rax
  a6c63c:	mov    %rax,0x50(%r15)
  a6c640:	movups 0x48(%rsp),%xmm0
  a6c645:	movups %xmm0,0x40(%r15)
  a6c64a:	movups 0x8(%rsp),%xmm0
  a6c64f:	movups 0x18(%rsp),%xmm1
  a6c654:	movups 0x28(%rsp),%xmm2
  a6c659:	movups 0x38(%rsp),%xmm3
  a6c65e:	movups %xmm3,0x30(%r15)
  a6c663:	movups %xmm2,0x20(%r15)
  a6c668:	movups %xmm1,0x10(%r15)
  a6c66d:	movups %xmm0,(%r15)
  a6c671:	mov    %r15,(%rsp)
  a6c675:	lock incq (%r15)
  a6c679:	jle    a6c747 <<gpui::native::accessibility::Bridge>::new+0x187>
  a6c67f:	lock incq (%r15)
  a6c683:	jle    a6c747 <<gpui::native::accessibility::Bridge>::new+0x187>
  a6c689:	lock incq (%r15)
  a6c68d:	jle    a6c747 <<gpui::native::accessibility::Bridge>::new+0x187>
  a6c693:	lea    0x8(%rsp),%rdi
  a6c698:	mov    %r13,%rsi
  a6c69b:	mov    %r12,%rdx
  a6c69e:	mov    %r15,%rcx
  a6c6a1:	mov    %r15,%r8
  a6c6a4:	mov    %r15,%r9
  a6c6a7:	call   a48ce0 <<accesskit_winit::Adapter>::with_direct_handlers::<gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress, gpui::native::accessibility::Ingress>>
  a6c6ac:	mov    0x10(%rbx),%rax
  a6c6b0:	mov    %rax,0x20(%r14)
  a6c6b4:	movups (%rbx),%xmm0
  a6c6b7:	movups %xmm0,0x10(%r14)
  a6c6bc:	movups 0x8(%rsp),%xmm0
  a6c6c1:	movups %xmm0,0x88(%r14)
  a6c6c9:	mov    0x18(%rsp),%rax
  a6c6ce:	mov    %rax,0x98(%r14)
  a6c6d5:	movq   $0xffffffffffffffff,(%r14)
  a6c6dc:	mov    %r15,0xa0(%r14)
  a6c6e3:	movb   $0x2,0x80(%r14)
  a6c6eb:	movb   $0x1,0xa8(%r14)
  a6c6f3:	movq   $0x0,0x28(%r14)
  a6c6fb:	movq   $0x8,0x30(%r14)
  a6c703:	movq   $0x0,0x38(%r14)
  a6c70b:	movabs $0x8000000000000000,%rax
  a6c715:	mov    %rax,0x40(%r14)
  a6c719:	movq   $0x0,0x48(%r14)
  a6c721:	mov    %r14,%rax
  a6c724:	add    $0x60,%rsp
  a6c728:	pop    %rbx
  a6c729:	pop    %r12
  a6c72b:	pop    %r13
  a6c72d:	pop    %r14
  a6c72f:	pop    %r15
  a6c731:	ret
  a6c732:	lea    0x18(%rsp),%r15
  a6c737:	mov    $0x8,%edi
  a6c73c:	mov    $0x58,%esi
  a6c741:	call   *0xac00b9(%rip)        # 152c800 <_DYNAMIC+0x268>
  a6c747:	ud2
  a6c749:	mov    %rax,%r14
  a6c74c:	lock decq (%r15)
  a6c750:	jne    a6c76e <<gpui::native::accessibility::Bridge>::new+0x1ae>
  a6c752:	mov    %rsp,%rdi
  a6c755:	call   *0xac1085(%rip)        # 152d7e0 <_DYNAMIC+0x1248>
  a6c75b:	jmp    a6c76e <<gpui::native::accessibility::Bridge>::new+0x1ae>
  a6c75d:	call   *0xac00bd(%rip)        # 152c820 <_DYNAMIC+0x288>
  a6c763:	mov    %rax,%r14
  a6c766:	mov    %r15,%rdi
  a6c769:	call   a6bc10 <core::ptr::drop_glue::<gpui::native::accessibility::Shared>>
  a6c76e:	mov    (%rbx),%rsi
  a6c771:	test   %rsi,%rsi
  a6c774:	je     a6c785 <<gpui::native::accessibility::Bridge>::new+0x1c5>
  a6c776:	mov    0x8(%rbx),%rdi
  a6c77a:	mov    $0x1,%edx
  a6c77f:	call   *0xac0063(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  a6c785:	mov    %r14,%rdi
  a6c788:	call   14b7130 <_Unwind_Resume@plt>
  a6c78d:	call   *0xac008d(%rip)        # 152c820 <_DYNAMIC+0x288>


/tmp/gpui-a11y-owner-channel-captures/release-candidate/empty:     file format elf64-x86-64


Disassembly of section .text:

0000000000a6e950 <<gpui::native::accessibility::Ingress as accesskit::ActivationHandler>::request_initial_tree>:
  a6e950:	push   %rbx
  a6e951:	mov    %rdi,%rbx
  a6e954:	mov    (%rsi),%rdi
  a6e957:	movzbl 0x50(%rdi),%eax
  a6e95b:	test   %al,%al
  a6e95d:	je     a6e96b <<gpui::native::accessibility::Ingress as accesskit::ActivationHandler>::request_initial_tree+0x1b>
  a6e95f:	movq   $0xffffffffffffffff,(%rbx)
  a6e966:	mov    %rbx,%rax
  a6e969:	pop    %rbx
  a6e96a:	ret
  a6e96b:	mov    0x48(%rdi),%rax
  a6e96f:	nop
  a6e970:	mov    %rax,%rcx
  a6e973:	or     $0x1,%rcx
  a6e977:	lock cmpxchg %rcx,0x48(%rdi)
  a6e97d:	jne    a6e970 <<gpui::native::accessibility::Ingress as accesskit::ActivationHandler>::request_initial_tree+0x20>
  a6e97f:	movb   $0x1,0x52(%rdi)
  a6e983:	cmpl   $0xffffffff,0x10(%rdi)
  a6e987:	je     a6e95f <<gpui::native::accessibility::Ingress as accesskit::ActivationHandler>::request_initial_tree+0xf>
  a6e989:	add    $0x10,%rdi
  a6e98d:	call   *0xabf2ed(%rip)        # 152dc80 <_DYNAMIC+0x16e8>
  a6e993:	movq   $0xffffffffffffffff,(%rbx)
  a6e99a:	mov    %rbx,%rax
  a6e99d:	pop    %rbx
  a6e99e:	ret


/tmp/gpui-a11y-owner-channel-captures/release-candidate/empty:     file format elf64-x86-64


Disassembly of section .text:

0000000000a6ead0 <<gpui::native::accessibility::Ingress as accesskit::DeactivationHandler>::deactivate_accessibility>:
  a6ead0:	push   %rbx
  a6ead1:	mov    (%rdi),%rcx
  a6ead4:	lea    0x10(%rcx),%rbx
  a6ead8:	mov    0x48(%rcx),%rax
  a6eadc:	nopl   0x0(%rax)
  a6eae0:	cmp    $0xffffffffffffffff,%rax
  a6eae4:	je     a6eafe <<gpui::native::accessibility::Ingress as accesskit::DeactivationHandler>::deactivate_accessibility+0x2e>
  a6eae6:	mov    %eax,%edx
  a6eae8:	and    $0x1,%edx
  a6eaeb:	add    %rax,%rdx
  a6eaee:	lock cmpxchg %rdx,0x48(%rcx)
  a6eaf4:	jne    a6eae0 <<gpui::native::accessibility::Ingress as accesskit::DeactivationHandler>::deactivate_accessibility+0x10>
  a6eaf6:	cmpq   $0xffffffffffffffff,(%rbx)
  a6eafa:	jne    a6eb17 <<gpui::native::accessibility::Ingress as accesskit::DeactivationHandler>::deactivate_accessibility+0x47>
  a6eafc:	jmp    a6eb21 <<gpui::native::accessibility::Ingress as accesskit::DeactivationHandler>::deactivate_accessibility+0x51>
  a6eafe:	movb   $0x1,0x51(%rcx)
  a6eb02:	cmpl   $0xffffffff,0x10(%rcx)
  a6eb06:	je     a6eb21 <<gpui::native::accessibility::Ingress as accesskit::DeactivationHandler>::deactivate_accessibility+0x51>
  a6eb08:	mov    %rbx,%rdi
  a6eb0b:	call   *0xabf16f(%rip)        # 152dc80 <_DYNAMIC+0x16e8>
  a6eb11:	cmpq   $0xffffffffffffffff,(%rbx)
  a6eb15:	je     a6eb21 <<gpui::native::accessibility::Ingress as accesskit::DeactivationHandler>::deactivate_accessibility+0x51>
  a6eb17:	mov    %rbx,%rdi
  a6eb1a:	pop    %rbx
  a6eb1b:	jmp    *0xabf15f(%rip)        # 152dc80 <_DYNAMIC+0x16e8>
  a6eb21:	pop    %rbx
  a6eb22:	ret


/tmp/gpui-a11y-owner-channel-captures/release-candidate/empty:     file format elf64-x86-64


Disassembly of section .text:

0000000000a6eb30 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action>:
  a6eb30:	push   %rbp
  a6eb31:	push   %r15
  a6eb33:	push   %r14
  a6eb35:	push   %r13
  a6eb37:	push   %r12
  a6eb39:	push   %rbx
  a6eb3a:	sub    $0x68,%rsp
  a6eb3e:	mov    (%rdi),%r14
  a6eb41:	mov    0x48(%r14),%r12
  a6eb45:	movzbl 0x50(%r14),%eax
  a6eb4a:	test   %al,%al
  a6eb4c:	jne    a6eb68 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x38>
  a6eb4e:	mov    %r12d,%eax
  a6eb51:	and    $0x1,%eax
  a6eb54:	je     a6eb68 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x38>
  a6eb56:	mov    0x30(%rsi),%rax
  a6eb5a:	or     0x28(%rsi),%rax
  a6eb5e:	jne    a6eb68 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x38>
  a6eb60:	mov    0x40(%r14),%eax
  a6eb64:	test   %eax,%eax
  a6eb66:	je     a6eb86 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x56>
  a6eb68:	mov    (%rsi),%eax
  a6eb6a:	cmp    $0xffffffff,%eax
  a6eb6d:	je     a6eb77 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x47>
  a6eb6f:	lea    -0x2(%rax),%ecx
  a6eb72:	cmp    $0x6,%ecx
  a6eb75:	jae    a6ebb7 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x87>
  a6eb77:	add    $0x68,%rsp
  a6eb7b:	pop    %rbx
  a6eb7c:	pop    %r12
  a6eb7e:	pop    %r13
  a6eb80:	pop    %r14
  a6eb82:	pop    %r15
  a6eb84:	pop    %rbp
  a6eb85:	ret
  a6eb86:	mov    0x38(%rsi),%r13
  a6eb8a:	movzbl 0x40(%rsi),%ecx
  a6eb8e:	mov    (%rsi),%eax
  a6eb90:	mov    0x8(%rsi),%rbx
  a6eb94:	mov    0x10(%rsi),%r15
  a6eb98:	test   %ecx,%ecx
  a6eb9a:	je     a6ebed <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0xbd>
  a6eb9c:	cmp    $0x1,%ecx
  a6eb9f:	je     a6ebe0 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0xb0>
  a6eba1:	cmp    $0x2,%ecx
  a6eba4:	jne    a6ec31 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x101>
  a6ebaa:	cmp    $0xffffffff,%eax
  a6ebad:	jne    a6ebf6 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0xc6>
  a6ebaf:	mov    $0x2,%bpl
  a6ebb2:	jmp    a6ecc0 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x190>
  a6ebb7:	test   %eax,%eax
  a6ebb9:	je     a6eb77 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x47>
  a6ebbb:	cmp    $0x1,%eax
  a6ebbe:	jne    a6ebda <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0xaa>
  a6ebc0:	mov    0x10(%rsi),%rax
  a6ebc4:	test   %rax,%rax
  a6ebc7:	je     a6eb77 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x47>
  a6ebc9:	mov    0x8(%rsi),%rdi
  a6ebcd:	mov    $0x1,%edx
  a6ebd2:	mov    %rax,%rsi
  a6ebd5:	jmp    a6ed4a <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x21a>
  a6ebda:	mov    0x8(%rsi),%rbx
  a6ebde:	jmp    a6ec08 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0xd8>
  a6ebe0:	cmp    $0xffffffff,%eax
  a6ebe3:	jne    a6ebf6 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0xc6>
  a6ebe5:	mov    $0x1,%bpl
  a6ebe8:	jmp    a6ecc0 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x190>
  a6ebed:	cmp    $0xffffffff,%eax
  a6ebf0:	je     a6ecbe <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x18e>
  a6ebf6:	cmp    $0x1,%eax
  a6ebf9:	je     a6ed36 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x206>
  a6ebff:	cmp    $0x8,%eax
  a6ec02:	jne    a6eb77 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x47>
  a6ec08:	mov    0x8(%rbx),%rsi
  a6ec0c:	test   %rsi,%rsi
  a6ec0f:	je     a6ec1f <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0xef>
  a6ec11:	mov    (%rbx),%rdi
  a6ec14:	mov    $0x1,%edx
  a6ec19:	call   *0xabdbc9(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  a6ec1f:	mov    $0x30,%esi
  a6ec24:	mov    $0x8,%edx
  a6ec29:	mov    %rbx,%rdi
  a6ec2c:	jmp    a6ed4a <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x21a>
  a6ec31:	cmp    $0x1,%eax
  a6ec34:	je     a6ed2e <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x1fe>
  a6ec3a:	cmp    $0x7,%eax
  a6ec3d:	je     a6ec92 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x162>
  a6ec3f:	cmp    $0x8,%eax
  a6ec42:	jne    a6ed5e <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x22e>
  a6ec48:	lea    -0xb(%rcx),%eax
  a6ec4b:	cmp    $0x4,%eax
  a6ec4e:	jb     a6ec08 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0xd8>
  a6ec50:	cmp    $0xa,%ecx
  a6ec53:	jne    a6ec08 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0xd8>
  a6ec55:	cmpq   $0x10001,0x8(%rbx)
  a6ec5d:	jb     a6ee4a <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x31a>
  a6ec63:	movb   $0x1,0x51(%r14)
  a6ec68:	cmpl   $0xffffffff,0x10(%r14)
  a6ec6d:	je     a6ec7c <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x14c>
  a6ec6f:	add    $0x10,%r14
  a6ec73:	mov    %r14,%rdi
  a6ec76:	call   *0xabf004(%rip)        # 152dc80 <_DYNAMIC+0x16e8>
  a6ec7c:	mov    %rbx,%rdi
  a6ec7f:	add    $0x68,%rsp
  a6ec83:	pop    %rbx
  a6ec84:	pop    %r12
  a6ec86:	pop    %r13
  a6ec88:	pop    %r14
  a6ec8a:	pop    %r15
  a6ec8c:	pop    %rbp
  a6ec8d:	jmp    a6b7d0 <core::ptr::drop_glue::<alloc::boxed::Box<accesskit::TextReplacement>>>
  a6ec92:	cmp    $0x12,%ecx
  a6ec95:	jne    a6eb77 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x47>
  a6ec9b:	add    $0x18,%rsi
  a6ec9f:	mov    %rsi,%rbp
  a6eca2:	call   a6d000 <alloc::boxed::box_new_uninit>
  a6eca7:	mov    %rbx,(%rax)
  a6ecaa:	mov    %r15,0x8(%rax)
  a6ecae:	movups 0x0(%rbp),%xmm0
  a6ecb2:	movups %xmm0,0x10(%rax)
  a6ecb6:	mov    $0x4,%bpl
  a6ecb9:	mov    %rax,%rbx
  a6ecbc:	jmp    a6ecc0 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x190>
  a6ecbe:	xor    %ebp,%ebp
  a6ecc0:	lea    0x30(%r14),%rsi
  a6ecc4:	mov    %r12,0x30(%rsp)
  a6ecc9:	mov    %bpl,0x10(%rsp)
  a6ecce:	mov    %dil,0x11(%rsp)
  a6ecd3:	mov    %dl,0x12(%rsp)
  a6ecd7:	mov    %r13,0x18(%rsp)
  a6ecdc:	mov    %rbx,0x20(%rsp)
  a6ece1:	mov    %r15,0x28(%rsp)
  a6ece6:	lea    0x38(%rsp),%rdi
  a6eceb:	lea    0x10(%rsp),%rdx
  a6ecf0:	call   a7df90 <<std::sync::mpmc::Sender<gpui::native::accessibility::Queued>>::try_send>
  a6ecf5:	mov    0x38(%rsp),%rax
  a6ecfa:	test   %rax,%rax
  a6ecfd:	je     a6ed06 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x1d6>
  a6ecff:	cmp    $0x2,%eax
  a6ed02:	je     a6ed0b <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x1db>
  a6ed04:	jmp    a6ed1f <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x1ef>
  a6ed06:	movb   $0x1,0x51(%r14)
  a6ed0b:	cmpl   $0xffffffff,0x10(%r14)
  a6ed10:	je     a6ed1f <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x1ef>
  a6ed12:	add    $0x10,%r14
  a6ed16:	mov    %r14,%rdi
  a6ed19:	call   *0xabef61(%rip)        # 152dc80 <_DYNAMIC+0x16e8>
  a6ed1f:	lea    0x38(%rsp),%rdi
  a6ed24:	call   a6b6d0 <core::ptr::drop_glue::<core::result::Result<(), std::sync::mpsc::TrySendError<gpui::native::accessibility::Queued>>>>
  a6ed29:	jmp    a6eb77 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x47>
  a6ed2e:	lea    -0xb(%rcx),%eax
  a6ed31:	cmp    $0x4,%eax
  a6ed34:	jae    a6ed89 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x259>
  a6ed36:	test   %r15,%r15
  a6ed39:	je     a6eb77 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x47>
  a6ed3f:	mov    $0x1,%edx
  a6ed44:	mov    %rbx,%rdi
  a6ed47:	mov    %r15,%rsi
  a6ed4a:	add    $0x68,%rsp
  a6ed4e:	pop    %rbx
  a6ed4f:	pop    %r12
  a6ed51:	pop    %r13
  a6ed53:	pop    %r14
  a6ed55:	pop    %r15
  a6ed57:	pop    %rbp
  a6ed58:	jmp    *0xabda8a(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  a6ed5e:	lea    -0xb(%rcx),%edx
  a6ed61:	cmp    $0x4,%edx
  a6ed64:	jae    a6edbb <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x28b>
  a6ed66:	lea    0x1(%rax),%edx
  a6ed69:	cmp    $0x7,%edx
  a6ed6c:	ja     a6ec08 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0xd8>
  a6ed72:	lea    -0x8cd3dd(%rip),%rsi        # 1a199c <anon.1bb0d8e1e7bafdb7dc9ab2d3852d0956.0.llvm.7199433445418989520+0x548>
  a6ed79:	movslq (%rsi,%rdx,4),%rdx
  a6ed7d:	add    %rsi,%rdx
  a6ed80:	jmp    *%rdx
  a6ed82:	mov    $0x1,%dl
  a6ed84:	jmp    a6ee54 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x324>
  a6ed89:	cmp    $0xa,%ecx
  a6ed8c:	je     a6ed93 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x263>
  a6ed8e:	cmp    $0x14,%ecx
  a6ed91:	jne    a6ed36 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x206>
  a6ed93:	cmp    $0x10000,%r15
  a6ed9a:	jbe    a6ee37 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x307>
  a6eda0:	movb   $0x1,0x51(%r14)
  a6eda5:	cmpl   $0xffffffff,0x10(%r14)
  a6edaa:	je     a6ed3f <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x20f>
  a6edac:	add    $0x10,%r14
  a6edb0:	mov    %r14,%rdi
  a6edb3:	call   *0xabeec7(%rip)        # 152dc80 <_DYNAMIC+0x16e8>
  a6edb9:	jmp    a6ed3f <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x20f>
  a6edbb:	cmp    $0xf,%ecx
  a6edbe:	je     a6ee14 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x2e4>
  a6edc0:	cmp    $0x11,%ecx
  a6edc3:	jne    a6ebf6 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0xc6>
  a6edc9:	cmp    $0x1,%eax
  a6edcc:	je     a6ed36 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x206>
  a6edd2:	cmp    $0x6,%eax
  a6edd5:	jne    a6ebff <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0xcf>
  a6eddb:	movabs $0x7fffffffffffffff,%rax
  a6ede5:	mov    %rbx,%rcx
  a6ede8:	and    %rax,%rcx
  a6edeb:	movabs $0x7fefffffffffffff,%rdx
  a6edf5:	cmp    %rdx,%rcx
  a6edf8:	setg   %cl
  a6edfb:	and    %r15,%rax
  a6edfe:	cmp    %rdx,%rax
  a6ee01:	setg   %al
  a6ee04:	or     %cl,%al
  a6ee06:	jne    a6eb77 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x47>
  a6ee0c:	mov    $0x8,%bpl
  a6ee0f:	jmp    a6ecc0 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x190>
  a6ee14:	inc    %eax
  a6ee16:	cmp    $0x9,%eax
  a6ee19:	ja     a6eb77 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x47>
  a6ee1f:	lea    -0x8cd4b2(%rip),%rcx        # 1a1974 <anon.1bb0d8e1e7bafdb7dc9ab2d3852d0956.0.llvm.7199433445418989520+0x520>
  a6ee26:	movslq (%rcx,%rax,4),%rax
  a6ee2a:	add    %rcx,%rax
  a6ee2d:	jmp    *%rax
  a6ee2f:	mov    $0x9,%bpl
  a6ee32:	jmp    a6ecc0 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x190>
  a6ee37:	xor    %eax,%eax
  a6ee39:	cmp    $0x14,%ecx
  a6ee3c:	setne  %al
  a6ee3f:	lea    (%rax,%rax,2),%ebp
  a6ee42:	add    $0x3,%ebp
  a6ee45:	jmp    a6ecc0 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x190>
  a6ee4a:	mov    $0x5,%bpl
  a6ee4d:	jmp    a6ecc0 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x190>
  a6ee52:	mov    %ebx,%edx
  a6ee54:	add    $0xf5,%cl
  a6ee57:	movzbl %cl,%ecx
  a6ee5a:	shl    $0x3,%ecx
  a6ee5d:	mov    $0x30201,%edi
  a6ee62:	shr    %cl,%edi
  a6ee64:	mov    $0x7,%bpl
  a6ee67:	cmp    $0xffffffff,%eax
  a6ee6a:	je     a6ee9e <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x36e>
  a6ee6c:	cmp    $0x1,%eax
  a6ee6f:	setne  %al
  a6ee72:	test   %r15,%r15
  a6ee75:	sete   %cl
  a6ee78:	or     %al,%cl
  a6ee7a:	jne    a6ee9e <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x36e>
  a6ee7c:	mov    %dl,0xb(%rsp)
  a6ee80:	mov    $0x1,%edx
  a6ee85:	mov    %edi,0xc(%rsp)
  a6ee89:	mov    %rbx,%rdi
  a6ee8c:	mov    %r15,%rsi
  a6ee8f:	call   *0xabd953(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  a6ee95:	mov    0xc(%rsp),%edi
  a6ee99:	movzbl 0xb(%rsp),%edx
  a6ee9e:	jmp    a6ecc0 <<gpui::native::accessibility::Ingress as accesskit::ActionHandler>::do_action+0x190>
  a6eea3:	mov    %rax,%r14
  a6eea6:	mov    %rbx,%rdi
  a6eea9:	call   a6b7d0 <core::ptr::drop_glue::<alloc::boxed::Box<accesskit::TextReplacement>>>
  a6eeae:	mov    %r14,%rdi
  a6eeb1:	call   14b7130 <_Unwind_Resume@plt>
  a6eeb6:	mov    %rax,%r14
  a6eeb9:	mov    $0x1,%edx
  a6eebe:	mov    %rbx,%rdi
  a6eec1:	mov    %r15,%rsi
  a6eec4:	call   *0xabd91e(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  a6eeca:	mov    %r14,%rdi
  a6eecd:	call   14b7130 <_Unwind_Resume@plt>
  a6eed2:	mov    %rax,%r14
  a6eed5:	lea    0x38(%rsp),%rdi
  a6eeda:	call   a6b6d0 <core::ptr::drop_glue::<core::result::Result<(), std::sync::mpsc::TrySendError<gpui::native::accessibility::Queued>>>>
  a6eedf:	mov    %r14,%rdi
  a6eee2:	call   14b7130 <_Unwind_Resume@plt>


/tmp/gpui-a11y-owner-channel-captures/release-candidate/empty:     file format elf64-x86-64


Disassembly of section .text:

0000000000a7d140 <std::sync::mpmc::sync_channel::<gpui::native::accessibility::Queued>>:
  a7d140:	push   %rbp
  a7d141:	mov    %rsp,%rbp
  a7d144:	push   %r15
  a7d146:	push   %r14
  a7d148:	push   %r12
  a7d14a:	push   %rbx
  a7d14b:	and    $0xffffffffffffff80,%rsp
  a7d14f:	sub    $0x300,%rsp
  a7d156:	mov    %rdi,%rbx
  a7d159:	test   %rsi,%rsi
  a7d15c:	je     a7d2d0 <std::sync::mpmc::sync_channel::<gpui::native::accessibility::Queued>+0x190>
  a7d162:	bsr    %rsi,%rcx
  a7d166:	not    %ecx
  a7d168:	mov    $0xffffffffffffffff,%rax
  a7d16f:	shr    %cl,%rax
  a7d172:	inc    %rax
  a7d175:	cmp    $0xffffffffffffffff,%rsi
  a7d179:	mov    $0x1,%r15d
  a7d17f:	cmovne %rax,%r15
  a7d183:	lea    (%r15,%r15,1),%r12
  a7d187:	xor    %edi,%edi
  a7d189:	mov    %rsi,%r14
  a7d18c:	call   a67ae0 <<alloc::boxed::Box<[std::sync::mpmc::array::Slot<gpui::native::accessibility::Queued>]> as core::iter::traits::collect::FromIterator<std::sync::mpmc::array::Slot<gpui::native::accessibility::Queued>>>::from_iter::<core::iter::adapters::map::Map<core::ops::range::Range<usize>, <std::sync::mpmc::array::Channel<gpui::native::accessibility::Queued>>::with_capacity::{closure#0}>>>
  a7d191:	movq   $0x0,(%rsp)
  a7d199:	movq   $0x0,0x80(%rsp)
  a7d1a5:	mov    %rax,0x198(%rsp)
  a7d1ad:	mov    %rdx,0x1a0(%rsp)
  a7d1b5:	mov    %r14,0x180(%rsp)
  a7d1bd:	mov    %r12,0x188(%rsp)
  a7d1c5:	mov    %r15,0x190(%rsp)
  a7d1cd:	movl   $0x0,0x100(%rsp)
  a7d1d8:	movb   $0x0,0x104(%rsp)
  a7d1e0:	movq   $0x0,0x108(%rsp)
  a7d1ec:	movq   $0x8,0x110(%rsp)
  a7d1f8:	xorps  %xmm0,%xmm0
  a7d1fb:	movups %xmm0,0x118(%rsp)
  a7d203:	movq   $0x8,0x128(%rsp)
  a7d20f:	movq   $0x0,0x130(%rsp)
  a7d21b:	movb   $0x1,0x138(%rsp)
  a7d223:	movl   $0x0,0x140(%rsp)
  a7d22e:	movb   $0x0,0x144(%rsp)
  a7d236:	movq   $0x0,0x148(%rsp)
  a7d242:	movq   $0x8,0x150(%rsp)
  a7d24e:	movups %xmm0,0x158(%rsp)
  a7d256:	movq   $0x8,0x168(%rsp)
  a7d262:	movq   $0x0,0x170(%rsp)
  a7d26e:	movb   $0x1,0x178(%rsp)
  a7d276:	movq   $0x1,0x200(%rsp)
  a7d282:	movq   $0x1,0x208(%rsp)
  a7d28e:	movb   $0x0,0x210(%rsp)
  a7d296:	call   *0xaaf53c(%rip)        # 152c7d8 <_DYNAMIC+0x240>
  a7d29c:	mov    $0x280,%edi
  a7d2a1:	mov    $0x80,%esi
  a7d2a6:	call   *0xaaf534(%rip)        # 152c7e0 <_DYNAMIC+0x248>
  a7d2ac:	test   %rax,%rax
  a7d2af:	je     a7d396 <std::sync::mpmc::sync_channel::<gpui::native::accessibility::Queued>+0x256>
  a7d2b5:	mov    %rax,%r14
  a7d2b8:	mov    %rsp,%rsi
  a7d2bb:	mov    $0x280,%edx
  a7d2c0:	mov    %rax,%rdi
  a7d2c3:	call   *0xaaf52f(%rip)        # 152c7f8 <memcpy@GLIBC_2.14>
  a7d2c9:	xor    %eax,%eax
  a7d2cb:	jmp    a7d377 <std::sync::mpmc::sync_channel::<gpui::native::accessibility::Queued>+0x237>
  a7d2d0:	movq   $0x1,0x70(%rsp)
  a7d2d9:	movq   $0x1,0x78(%rsp)
  a7d2e2:	movb   $0x0,0x80(%rsp)
  a7d2ea:	movl   $0x0,(%rsp)
  a7d2f1:	movb   $0x0,0x4(%rsp)
  a7d2f6:	movq   $0x0,0x8(%rsp)
  a7d2ff:	movq   $0x8,0x10(%rsp)
  a7d308:	xorps  %xmm0,%xmm0
  a7d30b:	movups %xmm0,0x18(%rsp)
  a7d310:	movq   $0x8,0x28(%rsp)
  a7d319:	movups %xmm0,0x30(%rsp)
  a7d31e:	movq   $0x8,0x40(%rsp)
  a7d327:	movups %xmm0,0x48(%rsp)
  a7d32c:	movq   $0x8,0x58(%rsp)
  a7d335:	movq   $0x0,0x60(%rsp)
  a7d33e:	movb   $0x0,0x68(%rsp)
  a7d343:	call   *0xaaf48f(%rip)        # 152c7d8 <_DYNAMIC+0x240>
  a7d349:	mov    $0x88,%edi
  a7d34e:	mov    $0x8,%esi
  a7d353:	call   *0xaaf487(%rip)        # 152c7e0 <_DYNAMIC+0x248>
  a7d359:	test   %rax,%rax
  a7d35c:	je     a7d3a8 <std::sync::mpmc::sync_channel::<gpui::native::accessibility::Queued>+0x268>
  a7d35e:	mov    %rax,%r14
  a7d361:	mov    %rsp,%rsi
  a7d364:	mov    $0x88,%edx
  a7d369:	mov    %rax,%rdi
  a7d36c:	call   *0xaaf486(%rip)        # 152c7f8 <memcpy@GLIBC_2.14>
  a7d372:	mov    $0x2,%eax
  a7d377:	mov    %rax,(%rbx)
  a7d37a:	mov    %r14,0x8(%rbx)
  a7d37e:	mov    %rax,0x10(%rbx)
  a7d382:	mov    %r14,0x18(%rbx)
  a7d386:	mov    %rbx,%rax
  a7d389:	lea    -0x20(%rbp),%rsp
  a7d38d:	pop    %rbx
  a7d38e:	pop    %r12
  a7d390:	pop    %r14
  a7d392:	pop    %r15
  a7d394:	pop    %rbp
  a7d395:	ret
  a7d396:	mov    $0x80,%edi
  a7d39b:	mov    $0x280,%esi
  a7d3a0:	call   *0xaaf45a(%rip)        # 152c800 <_DYNAMIC+0x268>
  a7d3a6:	jmp    a7d3b8 <std::sync::mpmc::sync_channel::<gpui::native::accessibility::Queued>+0x278>
  a7d3a8:	mov    $0x8,%edi
  a7d3ad:	mov    $0x88,%esi
  a7d3b2:	call   *0xaaf448(%rip)        # 152c800 <_DYNAMIC+0x268>
  a7d3b8:	ud2
  a7d3ba:	mov    %rax,%rbx
  a7d3bd:	mov    %rsp,%rdi
  a7d3c0:	call   a7b6e0 <core::ptr::drop_glue::<std::sync::mpmc::counter::Counter<std::sync::mpmc::zero::Channel<gpui::native::accessibility::Queued>>>>
  a7d3c5:	jmp    a7d3d8 <std::sync::mpmc::sync_channel::<gpui::native::accessibility::Queued>+0x298>
  a7d3c7:	call   *0xaaf453(%rip)        # 152c820 <_DYNAMIC+0x288>
  a7d3cd:	mov    %rax,%rbx
  a7d3d0:	mov    %rsp,%rdi
  a7d3d3:	call   a7b720 <core::ptr::drop_glue::<std::sync::mpmc::counter::Counter<std::sync::mpmc::array::Channel<gpui::native::accessibility::Queued>>>>
  a7d3d8:	mov    %rbx,%rdi
  a7d3db:	call   14b7130 <_Unwind_Resume@plt>
  a7d3e0:	call   *0xaaf43a(%rip)        # 152c820 <_DYNAMIC+0x288>
