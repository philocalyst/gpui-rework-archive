
/tmp/gpui-a11y-owner-channel-captures/release-candidate/empty:     file format elf64-x86-64


Disassembly of section .text:

0000000000a2e3a0 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch>:
  a2e3a0:	push   %rbp
  a2e3a1:	push   %r15
  a2e3a3:	push   %r14
  a2e3a5:	push   %r13
  a2e3a7:	push   %r12
  a2e3a9:	push   %rbx
  a2e3aa:	sub    $0xb88,%rsp
  a2e3b1:	mov    %rsi,%rbx
  a2e3b4:	mov    %rdi,%r14
  a2e3b7:	mov    (%rdx),%rax
  a2e3ba:	xor    %r13d,%r13d
  a2e3bd:	sub    $0x3,%rax
  a2e3c1:	cmovae %rax,%r13
  a2e3c5:	cmp    $0x2,%r13
  a2e3c9:	je     a2e5c0 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x220>
  a2e3cf:	cmp    $0x8,%r13
  a2e3d3:	jne    a2e3e2 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x42>
  a2e3d5:	mov    %r14,%rdi
  a2e3d8:	call   a2bbc0 <<gpui::native::NativeHost<empty::Empty>>::retire_window>
  a2e3dd:	jmp    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2e3e2:	lea    0x188(%r14),%r12
  a2e3e9:	cmpw   $0x2,0x188(%r14)
  a2e3f2:	je     a2e573 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1d3>
  a2e3f8:	lea    0x250(%rsp),%rdi
  a2e400:	mov    %r12,%rsi
  a2e403:	mov    %rdx,%rbp
  a2e406:	call   *0xaff5a4(%rip)        # 152d9b0 <_DYNAMIC+0x1418>
  a2e40c:	mov    %rbp,%rdx
  a2e40f:	mov    0x250(%rsp),%rax
  a2e417:	cmp    $0xfffffffffffffffe,%rax
  a2e41b:	je     a2e573 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1d3>
  a2e421:	cmp    $0xffffffffffffffff,%rax
  a2e425:	jne    a2e443 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xa3>
  a2e427:	cmpb   $0x0,0x208(%r14)
  a2e42f:	je     a2e4bb <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x11b>
  a2e435:	movq   $0x2f,0x1e8(%rsp)
  a2e441:	jmp    a2e467 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xc7>
  a2e443:	movups 0x258(%rsp),%xmm0
  a2e44b:	movups %xmm0,0x1f8(%rsp)
  a2e453:	movq   $0x30,0x1e8(%rsp)
  a2e45f:	mov    %rax,0x1f0(%rsp)
  a2e467:	lea    0xf8(%r14),%r15
  a2e46e:	cmpl   $0xfffffffe,0xf8(%r14)
  a2e476:	je     a2e480 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xe0>
  a2e478:	mov    %r15,%rdi
  a2e47b:	call   a28c80 <core::ptr::drop_glue::<gpui::native::NativeError>>
  a2e480:	mov    0x218(%rsp),%rax
  a2e488:	mov    %rax,0x30(%r15)
  a2e48c:	movupd 0x1e8(%rsp),%xmm0
  a2e495:	movupd 0x1f8(%rsp),%xmm1
  a2e49e:	movups 0x208(%rsp),%xmm2
  a2e4a6:	movups %xmm2,0x20(%r15)
  a2e4ab:	movupd %xmm1,0x10(%r15)
  a2e4b1:	movupd %xmm0,(%r15)
  a2e4b6:	jmp    a2f975 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x15d5>
  a2e4bb:	mov    $0x1,%al
  a2e4bd:	cmpb   $0x0,(%r14)
  a2e4c1:	je     a2e4f4 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x154>
  a2e4c3:	mov    0x8(%r14),%rax
  a2e4c7:	test   %rax,%rax
  a2e4ca:	je     a2ecac <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x90c>
  a2e4d0:	mov    $0xe,%r15d
  a2e4d6:	cmpb   $0x0,0x72e(%rax)
  a2e4dd:	jne    a2ecb2 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x912>
  a2e4e3:	movb   $0x0,0x72c(%rax)
  a2e4ea:	movzbl 0x208(%r14),%eax
  a2e4f2:	inc    %al
  a2e4f4:	mov    %al,0x208(%r14)
  a2e4fb:	lea    0x30(%r14),%r15
  a2e4ff:	mov    %r15,%rdi
  a2e502:	call   a26480 <core::ptr::drop_glue::<core::option::Option<gpui::native::upgrade::Upgrade>>>
  a2e507:	movq   $0xffffffffffffffff,0x30(%r14)
  a2e50f:	movb   $0x0,0x206(%r14)
  a2e517:	lea    0x1d0(%r14),%r15
  a2e51e:	mov    0x1d0(%r14),%rax
  a2e525:	test   %rax,%rax
  a2e528:	je     a2e539 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x199>
  a2e52a:	lock decq (%rax)
  a2e52e:	jne    a2e539 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x199>
  a2e530:	mov    %r15,%rdi
  a2e533:	call   *0xafebd7(%rip)        # 152d110 <_DYNAMIC+0xb78>
  a2e539:	movq   $0x0,(%r15)
  a2e540:	mov    %r12,%rdi
  a2e543:	call   a26240 <core::ptr::drop_glue::<core::option::Option<gpui::native::Graphics>>>
  a2e548:	movw   $0x2,0x188(%r14)
  a2e552:	lea    0x1e8(%rsp),%rdi
  a2e55a:	mov    %r14,%rsi
  a2e55d:	call   a2bef0 <<gpui::native::NativeHost<empty::Empty>>::create_surface>
  a2e562:	cmpl   $0xfffffffe,0x1e8(%rsp)
  a2e56a:	mov    %rbp,%rdx
  a2e56d:	jne    a2e467 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xc7>
  a2e573:	cmp    $0x6,%r13
  a2e577:	ja     a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2e57d:	lea    -0x89956c(%rip),%rax        # 195018 <anon.41931c7f01a0f669fcd75d8bc79f57d6.412.llvm.13234298307199123836+0x106>
  a2e584:	movslq (%rax,%r13,4),%rcx
  a2e588:	add    %rax,%rcx
  a2e58b:	jmp    *%rcx
  a2e58d:	mov    0x180(%r14),%ebp
  a2e594:	cmp    $0xffffffff,%ebp
  a2e597:	je     a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2e59d:	mov    0x178(%r14),%r15
  a2e5a4:	call   *0xafeefe(%rip)        # 152d4a8 <_DYNAMIC+0xf10>
  a2e5aa:	cmp    %rax,%r15
  a2e5ad:	jne    a2ebb1 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x811>
  a2e5b3:	cmp    %edx,%ebp
  a2e5b5:	jbe    a2ebb7 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x817>
  a2e5bb:	jmp    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2e5c0:	movb   $0x1,0x205(%r14)
  a2e5c8:	mov    $0xffffffff,%eax
  a2e5cd:	mov    %rax,0x1b0(%r14)
  a2e5d4:	movq   $0x0,0x1b8(%r14)
  a2e5df:	mov    0x1d8(%r14),%rdi
  a2e5e6:	test   %rdi,%rdi
  a2e5e9:	je     a2e5f6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x256>
  a2e5eb:	add    $0x10,%rdi
  a2e5ef:	xor    %esi,%esi
  a2e5f1:	call   a2dab0 <<winit::window::Window>::set_visible>
  a2e5f6:	lea    0x30(%r14),%r15
  a2e5fa:	mov    %r15,%rdi
  a2e5fd:	call   a26480 <core::ptr::drop_glue::<core::option::Option<gpui::native::upgrade::Upgrade>>>
  a2e602:	movq   $0xffffffffffffffff,0x30(%r14)
  a2e60a:	movb   $0x0,0x206(%r14)
  a2e612:	mov    0x1d0(%r14),%rax
  a2e619:	test   %rax,%rax
  a2e61c:	je     a2e634 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x294>
  a2e61e:	lock decq (%rax)
  a2e622:	jne    a2e634 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x294>
  a2e624:	lea    0x1d0(%r14),%r15
  a2e62b:	mov    %r15,%rdi
  a2e62e:	call   *0xafeadc(%rip)        # 152d110 <_DYNAMIC+0xb78>
  a2e634:	movq   $0x0,0x1d0(%r14)
  a2e63f:	movzwl 0x188(%r14),%eax
  a2e647:	cmp    $0x2,%eax
  a2e64a:	je     a2e66a <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x2ca>
  a2e64c:	test   %eax,%eax
  a2e64e:	jne    a2e65e <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x2be>
  a2e650:	mov    0x190(%r14),%rdi
  a2e657:	call   a26d40 <core::ptr::drop_glue::<alloc::boxed::Box<gpui::native::GpuSurface>>>
  a2e65c:	jmp    a2e66a <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x2ca>
  a2e65e:	mov    0x1a8(%r14),%rdi
  a2e665:	call   a251b0 <core::ptr::drop_glue::<softbuffer::Surface<alloc::sync::Arc<winit::window::Window>, alloc::sync::Arc<winit::window::Window>>>>
  a2e66a:	movw   $0x2,0x188(%r14)
  a2e674:	cmpl   $0x1,(%r14)
  a2e678:	jne    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2e67e:	mov    0x8(%r14),%rax
  a2e682:	test   %rax,%rax
  a2e685:	je     a2e697 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x2f7>
  a2e687:	cmpb   $0x0,0x72e(%rax)
  a2e68e:	je     a2e6fa <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x35a>
  a2e690:	mov    $0xe,%ebp
  a2e695:	jmp    a2e69c <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x2fc>
  a2e697:	mov    $0xd,%ebp
  a2e69c:	xor    %r13d,%r13d
  a2e69f:	cmpl   $0xfffffffe,0xf8(%r14)
  a2e6a7:	je     a2e6b5 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x315>
  a2e6a9:	lea    0xf8(%r14),%rdi
  a2e6b0:	call   a28c80 <core::ptr::drop_glue::<gpui::native::NativeError>>
  a2e6b5:	mov    %rbp,0xf8(%r14)
  a2e6bc:	mov    %r13,0x100(%r14)
  a2e6c3:	mov    %r12,0x108(%r14)
  a2e6ca:	mov    %r15,0x110(%r14)
  a2e6d1:	movapd 0x10(%rsp),%xmm0
  a2e6d7:	movupd %xmm0,0x118(%r14)
  a2e6e0:	mov    0x20(%rsp),%rax
  a2e6e5:	mov    %rax,0x128(%r14)
  a2e6ec:	mov    %rbx,%rdi
  a2e6ef:	call   *0xaff2c3(%rip)        # 152d9b8 <_DYNAMIC+0x1420>
  a2e6f5:	jmp    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2e6fa:	movb   $0x0,0x72c(%rax)
  a2e701:	jmp    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2e706:	mov    0x130(%r14),%rax
  a2e70d:	movq   $0xffffffffffffffff,0x130(%r14)
  a2e718:	cmp    $0xffffffffffffffff,%rax
  a2e71c:	je     a2f1a8 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xe08>
  a2e722:	mov    %rax,0x68(%rsp)
  a2e727:	mov    %rax,0x70(%rsp)
  a2e72c:	movupd 0x138(%r14),%xmm0
  a2e735:	movupd 0x148(%r14),%xmm1
  a2e73e:	movups 0x158(%r14),%xmm2
  a2e746:	movups 0x168(%r14),%xmm3
  a2e74e:	movupd %xmm0,0x78(%rsp)
  a2e754:	movupd %xmm1,0x88(%rsp)
  a2e75d:	movups %xmm2,0x98(%rsp)
  a2e765:	movups %xmm3,0xa8(%rsp)
  a2e76d:	lea    0xb8(%rsp),%rdi
  a2e775:	lea    0x70(%rsp),%rsi
  a2e77a:	call   *0xafe730(%rip)        # 152ceb0 <_DYNAMIC+0x918>
  a2e780:	mov    0x90(%rsp),%rbp
  a2e788:	mov    0x98(%rsp),%rax
  a2e790:	mov    %rax,0x8(%rsp)
  a2e795:	mov    0x1e0(%r14),%r13
  a2e79c:	test   %r13,%r13
  a2e79f:	je     a2e7cb <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x42b>
  a2e7a1:	mov    0x1e8(%r14),%r15
  a2e7a8:	mov    (%r15),%rax
  a2e7ab:	test   %rax,%rax
  a2e7ae:	je     a2e7b5 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x415>
  a2e7b0:	mov    %r13,%rdi
  a2e7b3:	call   *%rax
  a2e7b5:	mov    0x8(%r15),%rsi
  a2e7b9:	test   %rsi,%rsi
  a2e7bc:	je     a2e7cb <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x42b>
  a2e7be:	mov    0x10(%r15),%rdx
  a2e7c2:	mov    %r13,%rdi
  a2e7c5:	call   *0xafe01d(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  a2e7cb:	mov    %rbp,0x1e0(%r14)
  a2e7d2:	mov    0x8(%rsp),%rax
  a2e7d7:	mov    %rax,0x1e8(%r14)
  a2e7de:	mov    0xa0(%rsp),%rbp
  a2e7e6:	mov    0xa8(%rsp),%rax
  a2e7ee:	mov    %rax,0x8(%rsp)
  a2e7f3:	mov    0x1f0(%r14),%r13
  a2e7fa:	test   %r13,%r13
  a2e7fd:	je     a2e829 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x489>
  a2e7ff:	mov    0x1f8(%r14),%r15
  a2e806:	mov    (%r15),%rax
  a2e809:	test   %rax,%rax
  a2e80c:	je     a2e813 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x473>
  a2e80e:	mov    %r13,%rdi
  a2e811:	call   *%rax
  a2e813:	mov    0x8(%r15),%rsi
  a2e817:	test   %rsi,%rsi
  a2e81a:	je     a2e829 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x489>
  a2e81c:	mov    0x10(%r15),%rdx
  a2e820:	mov    %r13,%rdi
  a2e823:	call   *0xafdfbf(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  a2e829:	mov    %rbp,0x1f0(%r14)
  a2e830:	mov    0x8(%rsp),%rax
  a2e835:	mov    %rax,0x1f8(%r14)
  a2e83c:	call   *0xafdf96(%rip)        # 152c7d8 <_DYNAMIC+0x240>
  a2e842:	movq   $0xfffffffffffffffd,0x100(%rsp)
  a2e84e:	lea    0x250(%rsp),%rdi
  a2e856:	call   *0xaff164(%rip)        # 152d9c0 <_DYNAMIC+0x1428>
  a2e85c:	lea    0x8d0(%rsp),%rdi
  a2e864:	lea    0x100(%rsp),%r13
  a2e86c:	mov    0xafdf85(%rip),%r15        # 152c7f8 <memcpy@GLIBC_2.14>
  a2e873:	mov    $0x90,%edx
  a2e878:	mov    %r13,%rsi
  a2e87b:	call   *%r15
  a2e87e:	lea    0x818(%rsp),%rdi
  a2e886:	lea    0x250(%rsp),%rsi
  a2e88e:	mov    $0x98,%edx
  a2e893:	call   *%r15
  a2e896:	movups 0x78(%rsp),%xmm0
  a2e89b:	mov    0x68(%rsp),%rax
  a2e8a0:	mov    %rax,0x800(%rsp)
  a2e8a8:	movups %xmm0,0x808(%rsp)
  a2e8b0:	movq   $0xffffffffffffffff,0x8b0(%rsp)
  a2e8bc:	movl   $0x1,0x960(%rsp)
  a2e8c7:	movsd  0x88(%rsp),%xmm0
  a2e8d0:	xorpd  %xmm1,%xmm1
  a2e8d4:	unpcklps %xmm1,%xmm0
  a2e8d7:	movapd -0x8a1d6f(%rip),%xmm1        # 18cb70 <anon.89c1a9733c414c7e4e56fa7f22cdc6b9.309.llvm.3311541718473421078+0x8c0>
  a2e8df:	orpd   %xmm1,%xmm0
  a2e8e3:	subpd  %xmm1,%xmm0
  a2e8e7:	movupd %xmm0,0x968(%rsp)
  a2e8f0:	movl   $0x2,0x978(%rsp)
  a2e8fb:	movl   $0x2,0x990(%rsp)
  a2e906:	movl   $0x2,0x9a8(%rsp)
  a2e911:	movl   $0x2,0x9c0(%rsp)
  a2e91c:	movl   $0xffffffff,0x9d8(%rsp)
  a2e927:	movw   $0x0,0x9f0(%rsp)
  a2e931:	movl   $0x7,0xa00(%rsp)
  a2e93c:	movw   $0x102,0xa0c(%rsp)
  a2e946:	movabs $0x100010000000001,%rax
  a2e950:	mov    %rax,0xa04(%rsp)
  a2e958:	mov    0xafe981(%rip),%rax        # 152d2e0 <_DYNAMIC+0xd48>
  a2e95f:	mov    (%rax),%rax
  a2e962:	cmp    $0x2,%rax
  a2e966:	jae    a2edcd <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xa2d>
  a2e96c:	mov    0xaff055(%rip),%r15        # 152d9c8 <_DYNAMIC+0x1430>
  a2e973:	movzbl 0x10(%r15),%eax
  a2e978:	movzbl %al,%ecx
  a2e97b:	lea    -0x1(%rcx),%edx
  a2e97e:	cmp    $0x2,%edx
  a2e981:	jae    a2edc5 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xa25>
  a2e987:	mov    (%r15),%rdi
  a2e98a:	movzbl %al,%esi
  a2e98d:	call   *0xafe95d(%rip)        # 152d2f0 <_DYNAMIC+0xd58>
  a2e993:	test   %al,%al
  a2e995:	je     a2edcd <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xa2d>
  a2e99b:	mov    (%r15),%rsi
  a2e99e:	lea    0x30(%rsi),%rax
  a2e9a2:	lea    0x800(%rsp),%rcx
  a2e9aa:	mov    %rcx,0xd0(%rsp)
  a2e9b2:	lea    0xd0(%rsp),%rcx
  a2e9ba:	mov    %rcx,0x100(%rsp)
  a2e9c2:	lea    0xa8e3f7(%rip),%rcx        # 14bcdc0 <anon.fff2d4355c6109bc0e8af2445443084d.8.llvm.4725208967334239140+0xb8>
  a2e9c9:	mov    %rcx,0x108(%rsp)
  a2e9d1:	movq   $0x1,0x250(%rsp)
  a2e9dd:	mov    %r13,0x258(%rsp)
  a2e9e5:	movq   $0x1,0x260(%rsp)
  a2e9f1:	mov    %rax,0x268(%rsp)
  a2e9f9:	lea    0x40(%rsp),%rdi
  a2e9fe:	lea    0x250(%rsp),%rdx
  a2ea06:	call   *0xafee94(%rip)        # 152d8a0 <_DYNAMIC+0x1308>
  a2ea0c:	cmpq   $0x2,0x40(%rsp)
  a2ea12:	je     a2eddf <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xa3f>
  a2ea18:	lea    0x58(%rsp),%rsi
  a2ea1d:	lea    0x40(%rsp),%rdi
  a2ea22:	call   *0xafee80(%rip)        # 152d8a8 <_DYNAMIC+0x1310>
  a2ea28:	jmp    a2eddf <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xa3f>
  a2ea2d:	mov    0x178(%r14),%rax
  a2ea34:	mov    0x180(%r14),%ecx
  a2ea3b:	testb  $0x1,0x204(%r14)
  a2ea43:	mov    $0x3b9aca01,%edx
  a2ea48:	mov    %ecx,%esi
  a2ea4a:	cmovne %edx,%esi
  a2ea4d:	cmp    $0xffffffff,%ecx
  a2ea50:	cmove  %edx,%esi
  a2ea53:	mov    %rax,0x68(%rbx)
  a2ea57:	mov    %esi,0x70(%rbx)
  a2ea5a:	jmp    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2ea5f:	mov    0x1d8(%r14),%r12
  a2ea66:	test   %r12,%r12
  a2ea69:	je     a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2ea6f:	mov    %rdx,%r15
  a2ea72:	mov    0xafe867(%rip),%rax        # 152d2e0 <_DYNAMIC+0xd48>
  a2ea79:	mov    (%rax),%rax
  a2ea7c:	cmp    $0x1,%rax
  a2ea80:	ja     a2ece7 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x947>
  a2ea86:	mov    0xafef43(%rip),%r13        # 152d9d0 <_DYNAMIC+0x1438>
  a2ea8d:	movzbl 0x10(%r13),%eax
  a2ea92:	movzbl %al,%ecx
  a2ea95:	lea    -0x1(%rcx),%edx
  a2ea98:	cmp    $0x2,%edx
  a2ea9b:	jae    a2ecdf <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x93f>
  a2eaa1:	mov    0x0(%r13),%rdi
  a2eaa5:	movzbl %al,%esi
  a2eaa8:	call   *0xafe842(%rip)        # 152d2f0 <_DYNAMIC+0xd58>
  a2eaae:	test   %al,%al
  a2eab0:	je     a2ece7 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x947>
  a2eab6:	mov    0x0(%r13),%rsi
  a2eaba:	lea    0x30(%rsi),%rax
  a2eabe:	movq   $0x1,0x800(%rsp)
  a2eaca:	movq   $0x8,0x808(%rsp)
  a2ead6:	movq   $0x0,0x810(%rsp)
  a2eae2:	mov    %rax,0x818(%rsp)
  a2eaea:	lea    0x250(%rsp),%rdi
  a2eaf2:	lea    0x800(%rsp),%rdx
  a2eafa:	call   *0xafeda0(%rip)        # 152d8a0 <_DYNAMIC+0x1308>
  a2eb00:	cmpq   $0x2,0x250(%rsp)
  a2eb09:	je     a2ecff <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x95f>
  a2eb0f:	lea    0x268(%rsp),%rsi
  a2eb17:	lea    0x250(%rsp),%rdi
  a2eb1f:	call   *0xafed83(%rip)        # 152d8a8 <_DYNAMIC+0x1310>
  a2eb25:	jmp    a2ecff <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x95f>
  a2eb2a:	cmpl   $0xfffffffe,0x48(%r14)
  a2eb2f:	setne  %cl
  a2eb32:	mov    (%r14),%rax
  a2eb35:	test   %al,%cl
  a2eb37:	je     a2f246 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xea6>
  a2eb3d:	lea    0x48(%r14),%r15
  a2eb41:	lea    0x8(%r14),%rdx
  a2eb45:	lea    0x800(%rsp),%rdi
  a2eb4d:	mov    %r15,%rsi
  a2eb50:	call   9e5e80 <<gpui::native::accessibility::Bridge>::drain::<empty::Empty, ()>>
  a2eb55:	cmpl   $0xfffffffc,0x800(%rsp)
  a2eb5d:	jne    a2ebc7 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x827>
  a2eb5f:	mov    %r15,%rdi
  a2eb62:	call   a26340 <core::ptr::drop_glue::<core::option::Option<gpui::native::accessibility::Bridge>>>
  a2eb67:	lea    0x808(%rsp),%r12
  a2eb6f:	movq   $0xfffffffffffffffe,0x48(%r14)
  a2eb77:	lea    0xf8(%r14),%r15
  a2eb7e:	cmpl   $0xfffffffe,0xf8(%r14)
  a2eb86:	je     a2eb90 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x7f0>
  a2eb88:	mov    %r15,%rdi
  a2eb8b:	call   a28c80 <core::ptr::drop_glue::<gpui::native::NativeError>>
  a2eb90:	mov    0x30(%r12),%rax
  a2eb95:	mov    %rax,0x30(%r15)
  a2eb99:	movupd (%r12),%xmm0
  a2eb9f:	movupd 0x10(%r12),%xmm1
  a2eba6:	movups 0x20(%r12),%xmm2
  a2ebac:	jmp    a2e4a6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x106>
  a2ebb1:	jg     a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2ebb7:	movl   $0xffffffff,0x180(%r14)
  a2ebc2:	jmp    a2f8b7 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1517>
  a2ebc7:	lea    0x268(%rsp),%rdi
  a2ebcf:	lea    0x800(%rsp),%rsi
  a2ebd7:	mov    $0x380,%edx
  a2ebdc:	call   *0xafdc16(%rip)        # 152c7f8 <memcpy@GLIBC_2.14>
  a2ebe2:	movq   $0x1,0x250(%rsp)
  a2ebee:	movq   $0x10,0x260(%rsp)
  a2ebfa:	movq   $0xfffffffffffffffc,0x5e8(%rsp)
  a2ec06:	movq   $0xfffffffffffffffc,0x620(%rsp)
  a2ec12:	lea    0x108(%rsp),%rbp
  a2ec1a:	lea    0x270(%rsp),%r15
  a2ec22:	xor    %r13d,%r13d
  a2ec25:	lea    0x100(%rsp),%r12
  a2ec2d:	mov    -0x8(%r15),%rax
  a2ec31:	cmp    $0xfffffffffffffffd,%rax
  a2ec35:	je     a2ec88 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x8e8>
  a2ec37:	cmp    $0xfffffffffffffffc,%rax
  a2ec3b:	je     a2f22b <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xe8b>
  a2ec41:	movupd (%r15),%xmm0
  a2ec46:	movupd 0x10(%r15),%xmm1
  a2ec4c:	movups 0x20(%r15),%xmm2
  a2ec51:	movups %xmm2,0x20(%rbp)
  a2ec55:	movupd %xmm1,0x10(%rbp)
  a2ec5a:	movupd %xmm0,0x0(%rbp)
  a2ec5f:	mov    %rax,0x100(%rsp)
  a2ec67:	lea    0x6b0(%rsp),%rdi
  a2ec6f:	mov    %r14,%rsi
  a2ec72:	mov    %r12,%rdx
  a2ec75:	call   a2ba40 <<gpui::native::NativeHost<empty::Empty>>::input_result>
  a2ec7a:	cmpl   $0xfffffffe,0x6b0(%rsp)
  a2ec82:	jne    a2f336 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xf96>
  a2ec88:	cmp    $0xf,%r13
  a2ec8c:	je     a2eca1 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x901>
  a2ec8e:	add    $0x38,%r15
  a2ec92:	inc    %r13
  a2ec95:	mov    -0x8(%r15),%rax
  a2ec99:	cmp    $0xfffffffffffffffd,%rax
  a2ec9d:	jne    a2ec37 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x897>
  a2ec9f:	jmp    a2ec88 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x8e8>
  a2eca1:	mov    $0x10,%r13d
  a2eca7:	jmp    a2f22e <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xe8e>
  a2ecac:	mov    $0xd,%r15d
  a2ecb2:	cmpl   $0xfffffffe,0xf8(%r14)
  a2ecba:	je     a2ecc8 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x928>
  a2ecbc:	lea    0xf8(%r14),%rdi
  a2ecc3:	call   a28c80 <core::ptr::drop_glue::<gpui::native::NativeError>>
  a2ecc8:	mov    %r15,0xf8(%r14)
  a2eccf:	movq   $0x0,0x100(%r14)
  a2ecda:	jmp    a2f975 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x15d5>
  a2ecdf:	test   %ecx,%ecx
  a2ece1:	jne    a2fd15 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1975>
  a2ece7:	movq   $0x2,0x250(%rsp)
  a2ecf3:	movq   $0x0,0x270(%rsp)
  a2ecff:	mov    0x270(%rsp),%rax
  a2ed07:	mov    %rax,0x820(%rsp)
  a2ed0f:	mov    0x250(%rsp),%rax
  a2ed17:	mov    0x258(%rsp),%rcx
  a2ed1f:	movupd 0x260(%rsp),%xmm0
  a2ed28:	movapd %xmm0,0x810(%rsp)
  a2ed31:	mov    %rax,0x800(%rsp)
  a2ed39:	mov    %rcx,0x808(%rsp)
  a2ed41:	mov    0x10(%r12),%rax
  a2ed46:	mov    0x310(%rax),%r12d
  a2ed4d:	lea    0x800(%rsp),%rdi
  a2ed55:	call   a28b10 <core::ptr::drop_glue::<tracing::span::EnteredSpan>>
  a2ed5a:	cmp    %r12,0x10(%r15)
  a2ed5e:	jne    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2ed64:	mov    0x8(%r15),%r15
  a2ed68:	cmpl   $0xfffffffe,0x48(%r14)
  a2ed6d:	je     a2ed8c <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x9ec>
  a2ed6f:	mov    0x1d8(%r14),%rsi
  a2ed76:	test   %rsi,%rsi
  a2ed79:	je     a2ed8c <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x9ec>
  a2ed7b:	lea    0x48(%r14),%rdi
  a2ed7f:	add    $0x10,%rsi
  a2ed83:	mov    %r15,%rdx
  a2ed86:	call   *0xafec4c(%rip)        # 152d9d8 <_DYNAMIC+0x1440>
  a2ed8c:	movzwl (%r15),%eax
  a2ed90:	mov    %eax,%ecx
  a2ed92:	sub    $0x4,%cx
  a2ed96:	mov    $0x9,%edx
  a2ed9b:	cmovae %ecx,%edx
  a2ed9e:	movzwl %dx,%ecx
  a2eda1:	dec    %ecx
  a2eda3:	cmp    $0x1a,%ecx
  a2eda6:	ja     a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2edac:	lea    -0x899d7f(%rip),%rdx        # 195034 <anon.41931c7f01a0f669fcd75d8bc79f57d6.412.llvm.13234298307199123836+0x122>
  a2edb3:	movslq (%rdx,%rcx,4),%rcx
  a2edb7:	add    %rdx,%rcx
  a2edba:	jmp    *%rcx
  a2edbc:	mov    0x4(%r15),%rdx
  a2edc0:	jmp    a2f4fe <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x115e>
  a2edc5:	test   %ecx,%ecx
  a2edc7:	jne    a2fd2f <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x198f>
  a2edcd:	movq   $0x2,0x40(%rsp)
  a2edd6:	movq   $0x0,0x60(%rsp)
  a2eddf:	mov    0x60(%rsp),%rax
  a2ede4:	mov    %rax,0xf0(%rsp)
  a2edec:	mov    0x40(%rsp),%rax
  a2edf1:	mov    0x48(%rsp),%rcx
  a2edf6:	movupd 0x50(%rsp),%xmm0
  a2edfc:	movapd %xmm0,0xe0(%rsp)
  a2ee05:	mov    %rax,0xd0(%rsp)
  a2ee0d:	mov    %rcx,0xd8(%rsp)
  a2ee15:	lea    0x250(%rsp),%r13
  a2ee1d:	lea    0x800(%rsp),%rsi
  a2ee25:	mov    $0x210,%edx
  a2ee2a:	mov    %r13,%rdi
  a2ee2d:	call   *0xafd9c5(%rip)        # 152c7f8 <memcpy@GLIBC_2.14>
  a2ee33:	lea    0x100(%rsp),%rdi
  a2ee3b:	mov    %rbx,%rsi
  a2ee3e:	mov    %r13,%rdx
  a2ee41:	call   *0xafeb99(%rip)        # 152d9e0 <_DYNAMIC+0x1448>
  a2ee47:	mov    0x100(%rsp),%r15
  a2ee4f:	cmp    $0xffffffffffffffff,%r15
  a2ee53:	je     a2ee89 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xae9>
  a2ee55:	mov    0x130(%rsp),%rax
  a2ee5d:	mov    %rax,0x240(%rsp)
  a2ee65:	movupd 0x110(%rsp),%xmm0
  a2ee6e:	movupd 0x120(%rsp),%xmm1
  a2ee77:	movapd %xmm1,0x230(%rsp)
  a2ee80:	movapd %xmm0,0x220(%rsp)
  a2ee89:	mov    0x108(%rsp),%r13
  a2ee91:	lea    0xd0(%rsp),%rdi
  a2ee99:	call   a28b10 <core::ptr::drop_glue::<tracing::span::EnteredSpan>>
  a2ee9e:	cmp    $0xffffffffffffffff,%r15
  a2eea2:	je     a2ef97 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xbf7>
  a2eea8:	mov    %r15,0x250(%rsp)
  a2eeb0:	mov    %r13,0x258(%rsp)
  a2eeb8:	movapd 0x220(%rsp),%xmm0
  a2eec1:	movapd 0x230(%rsp),%xmm1
  a2eeca:	movupd %xmm0,0x260(%rsp)
  a2eed3:	movupd %xmm1,0x270(%rsp)
  a2eedc:	mov    0x240(%rsp),%rax
  a2eee4:	mov    %rax,0x280(%rsp)
  a2eeec:	movq   $0x0,0x40(%rsp)
  a2eef5:	movq   $0x1,0x48(%rsp)
  a2eefe:	movq   $0x0,0x50(%rsp)
  a2ef07:	movq   $0x60000020,0x110(%rsp)
  a2ef13:	lea    0x40(%rsp),%rax
  a2ef18:	mov    %rax,0x100(%rsp)
  a2ef20:	lea    0xa8e031(%rip),%rax        # 14bcf58 <anon.fff2d4355c6109bc0e8af2445443084d.57.llvm.4725208967334239140>
  a2ef27:	mov    %rax,0x108(%rsp)
  a2ef2f:	lea    0x250(%rsp),%rdi
  a2ef37:	lea    0x100(%rsp),%rsi
  a2ef3f:	call   *0xafeaa3(%rip)        # 152d9e8 <_DYNAMIC+0x1450>
  a2ef45:	test   %al,%al
  a2ef47:	jne    a2fc7a <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x18da>
  a2ef4d:	mov    0x40(%rsp),%r13
  a2ef52:	mov    0x48(%rsp),%r12
  a2ef57:	mov    0x50(%rsp),%r15
  a2ef5c:	lea    0x250(%rsp),%rdi
  a2ef64:	call   a27d80 <core::ptr::drop_glue::<winit::error::OsError>>
  a2ef69:	mov    $0x2d,%ebp
  a2ef6e:	mov    0xb8(%rsp),%rsi
  a2ef76:	test   %rsi,%rsi
  a2ef79:	je     a2e69f <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x2ff>
  a2ef7f:	mov    0xc0(%rsp),%rdi
  a2ef87:	mov    $0x1,%edx
  a2ef8c:	call   *0xafd856(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  a2ef92:	jmp    a2e69f <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x2ff>
  a2ef97:	movq   $0x1,0x250(%rsp)
  a2efa3:	movq   $0x1,0x258(%rsp)
  a2efaf:	mov    %r13,0x260(%rsp)
  a2efb7:	call   *0xafd81b(%rip)        # 152c7d8 <_DYNAMIC+0x240>
  a2efbd:	mov    $0x18,%edi
  a2efc2:	mov    $0x8,%esi
  a2efc7:	call   *0xafd813(%rip)        # 152c7e0 <_DYNAMIC+0x248>
  a2efcd:	test   %rax,%rax
  a2efd0:	je     a2fcbd <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x191d>
  a2efd6:	mov    %rax,%rcx
  a2efd9:	mov    0x260(%rsp),%rdx
  a2efe1:	mov    %rdx,0x10(%rax)
  a2efe5:	movups 0x250(%rsp),%xmm0
  a2efed:	movups %xmm0,(%rax)
  a2eff0:	add    $0x10,%rax
  a2eff4:	mov    %rcx,0x30(%rsp)
  a2eff9:	mov    %rax,%rdi
  a2effc:	call   a2d930 <<winit::window::Window>::inner_size>
  a2f001:	cmp    $0x1,%eax
  a2f004:	adc    $0x0,%eax
  a2f007:	cmp    $0x1,%edx
  a2f00a:	adc    $0x0,%edx
  a2f00d:	mov    %eax,0x110(%rsp)
  a2f014:	mov    %edx,0x114(%rsp)
  a2f01b:	movl   $0x0,0x100(%rsp)
  a2f026:	movl   $0x434b0000,0x108(%rsp)
  a2f031:	movw   $0x0,0x10c(%rsp)
  a2f03b:	mov    0x30(%rsp),%rdi
  a2f040:	add    $0x10,%rdi
  a2f044:	call   a2a600 <<winit::window::Window>::scale_factor>
  a2f049:	cvtsd2ss %xmm0,%xmm0
  a2f04d:	movzbl 0xb0(%rsp),%edx
  a2f055:	lea    0x250(%rsp),%rdi
  a2f05d:	lea    0x100(%rsp),%rsi
  a2f065:	call   9c2970 <<gpui::runtime::Win<empty::Empty>>::recording_lanes>
  a2f06a:	mov    0x250(%rsp),%rbp
  a2f072:	mov    0x258(%rsp),%r13
  a2f07a:	cmp    $0xfffffffffffffffe,%rbp
  a2f07e:	jne    a2f1fc <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xe5c>
  a2f084:	mov    0x10(%r14),%rax
  a2f088:	cmp    $0xffffffffffffffff,%rax
  a2f08c:	sete   %bpl
  a2f090:	cmp    $0xffffffff,%eax
  a2f093:	je     a2f453 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x10b3>
  a2f099:	mov    %ebp,0x8(%rsp)
  a2f09d:	mov    0x30(%rsp),%rbp
  a2f0a2:	mov    0x28(%r14),%r15
  a2f0a6:	lock incq (%r15)
  a2f0aa:	jle    a2fd71 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x19d1>
  a2f0b0:	lea    0x10(%r14),%rsi
  a2f0b4:	mov    %r15,0xd0(%rsp)
  a2f0bc:	lea    0x40(%rsp),%rdi
  a2f0c1:	call   a20db0 <<winit::platform_impl::linux::x11::WakeSender<()> as core::clone::Clone>::clone>
  a2f0c6:	add    $0x10,%rbp
  a2f0ca:	movups 0x40(%rsp),%xmm0
  a2f0cf:	mov    0x50(%rsp),%rax
  a2f0d4:	movups %xmm0,0x690(%rsp)
  a2f0dc:	mov    %rax,0x6a0(%rsp)
  a2f0e4:	mov    %r15,0x6a8(%rsp)
  a2f0ec:	mov    0xc8(%rsp),%rax
  a2f0f4:	mov    %rax,0x50(%rsp)
  a2f0f9:	movups 0xb8(%rsp),%xmm0
  a2f101:	movaps %xmm0,0x40(%rsp)
  a2f106:	lea    0x250(%rsp),%rdi
  a2f10e:	lea    0x690(%rsp),%rcx
  a2f116:	lea    0x40(%rsp),%r8
  a2f11b:	mov    %rbx,%rsi
  a2f11e:	mov    %rbp,%rdx
  a2f121:	call   *0xafe8c9(%rip)        # 152d9f0 <_DYNAMIC+0x1458>
  a2f127:	lea    0x100(%rsp),%rdi
  a2f12f:	lea    0x250(%rsp),%rsi
  a2f137:	mov    $0xb0,%edx
  a2f13c:	call   *0xafd6b6(%rip)        # 152c7f8 <memcpy@GLIBC_2.14>
  a2f142:	lea    0x48(%r14),%rbp
  a2f146:	mov    %rbp,%rdi
  a2f149:	call   a26340 <core::ptr::drop_glue::<core::option::Option<gpui::native::accessibility::Bridge>>>
  a2f14e:	lea    0x100(%rsp),%rsi
  a2f156:	mov    $0xb0,%edx
  a2f15b:	mov    %rbp,%rdi
  a2f15e:	call   *0xafd694(%rip)        # 152c7f8 <memcpy@GLIBC_2.14>
  a2f164:	cmpq   $0x0,(%r14)
  a2f168:	je     a2f173 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xdd3>
  a2f16a:	mov    0x8(%r14),%rdi
  a2f16e:	call   a26ee0 <core::ptr::drop_glue::<gpui::runtime::Win<empty::Empty>>>
  a2f173:	movq   $0x1,(%r14)
  a2f17a:	mov    %r13,0x8(%r14)
  a2f17e:	mov    0x30(%rsp),%r13
  a2f183:	lea    0x1d8(%r14),%r15
  a2f18a:	mov    0x1d8(%r14),%rax
  a2f191:	test   %rax,%rax
  a2f194:	je     a2f1a5 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xe05>
  a2f196:	lock decq (%rax)
  a2f19a:	jne    a2f1a5 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xe05>
  a2f19c:	mov    %r15,%rdi
  a2f19f:	call   *0xafe1db(%rip)        # 152d380 <_DYNAMIC+0xde8>
  a2f1a5:	mov    %r13,(%r15)
  a2f1a8:	cmpw   $0x2,(%r12)
  a2f1ae:	jne    a2f1d2 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xe32>
  a2f1b0:	lea    0x250(%rsp),%rdi
  a2f1b8:	mov    %r14,%rsi
  a2f1bb:	call   a2bef0 <<gpui::native::NativeHost<empty::Empty>>::create_surface>
  a2f1c0:	mov    0x250(%rsp),%rbp
  a2f1c8:	cmp    $0xfffffffffffffffe,%rbp
  a2f1cc:	jne    a2fb40 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x17a0>
  a2f1d2:	mov    0x1d8(%r14),%rdi
  a2f1d9:	test   %rdi,%rdi
  a2f1dc:	je     a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2f1e2:	add    $0x10,%rdi
  a2f1e6:	mov    $0x1,%esi
  a2f1eb:	call   a2dab0 <<winit::window::Window>::set_visible>
  a2f1f0:	mov    0x1d8(%r14),%rdi
  a2f1f7:	jmp    a2f8cd <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x152d>
  a2f1fc:	mov    0x260(%rsp),%r12
  a2f204:	mov    0x268(%rsp),%r15
  a2f20c:	movups 0x270(%rsp),%xmm0
  a2f214:	movaps %xmm0,0x10(%rsp)
  a2f219:	mov    0x280(%rsp),%rax
  a2f221:	mov    %rax,0x20(%rsp)
  a2f226:	jmp    a2f4bd <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x111d>
  a2f22b:	inc    %r13
  a2f22e:	mov    %r13,0x258(%rsp)
  a2f236:	lea    0x250(%rsp),%rdi
  a2f23e:	call   a275d0 <core::ptr::drop_glue::<core::iter::adapters::flatten::Flatten<core::array::iter::IntoIter<core::option::Option<core::result::Result<gpui::runtime::Commit, gpui::runtime::Error>>, 16>>>>
  a2f243:	mov    (%r14),%rax
  a2f246:	test   $0x1,%al
  a2f248:	je     a2f8b0 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1510>
  a2f24e:	mov    0x8(%r14),%rax
  a2f252:	test   %rax,%rax
  a2f255:	je     a2fca4 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1904>
  a2f25b:	lea    0x8(%r14),%rsi
  a2f25f:	mov    0x660(%rax),%r15
  a2f266:	lea    0x250(%rsp),%rdi
  a2f26e:	mov    $0x40,%edx
  a2f273:	call   9b7bc0 <<gpui::runtime::Win<empty::Empty>>::deliver_ready>
  a2f278:	mov    0x250(%rsp),%rax
  a2f280:	cmp    $0xffffffffffffffff,%rax
  a2f284:	je     a2f2f1 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xf51>
  a2f286:	cmp    $0x2,%eax
  a2f289:	je     a2f2a8 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xf08>
  a2f28b:	cmp    %r15,0x260(%rsp)
  a2f293:	jbe    a2f2a8 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xf08>
  a2f295:	mov    0x298(%rsp),%eax
  a2f29c:	and    $0xfffffffe,%eax
  a2f29f:	cmp    $0xe,%eax
  a2f2a2:	jne    a2f3ab <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x100b>
  a2f2a8:	mov    0x2c8(%rsp),%rax
  a2f2b0:	mov    %rax,0x1e0(%rsp)
  a2f2b8:	movupd 0x298(%rsp),%xmm0
  a2f2c1:	movupd 0x2a8(%rsp),%xmm1
  a2f2ca:	movups 0x2b8(%rsp),%xmm2
  a2f2d2:	movaps %xmm2,0x1d0(%rsp)
  a2f2da:	movapd %xmm1,0x1c0(%rsp)
  a2f2e3:	movapd %xmm0,0x1b0(%rsp)
  a2f2ec:	jmp    a2f88a <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x14ea>
  a2f2f1:	movupd 0x258(%rsp),%xmm0
  a2f2fa:	movupd 0x268(%rsp),%xmm1
  a2f303:	movups 0x278(%rsp),%xmm2
  a2f30b:	movups %xmm2,0x1d8(%rsp)
  a2f313:	movupd %xmm1,0x1c8(%rsp)
  a2f31c:	movupd %xmm0,0x1b8(%rsp)
  a2f325:	movq   $0xfffffffffffffffe,0x1b0(%rsp)
  a2f331:	jmp    a2f88a <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x14ea>
  a2f336:	inc    %r13
  a2f339:	mov    %r13,0x258(%rsp)
  a2f341:	lea    0xf8(%r14),%r15
  a2f348:	cmpl   $0xfffffffe,0xf8(%r14)
  a2f350:	je     a2f35a <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xfba>
  a2f352:	mov    %r15,%rdi
  a2f355:	call   a28c80 <core::ptr::drop_glue::<gpui::native::NativeError>>
  a2f35a:	mov    0x6e0(%rsp),%rax
  a2f362:	mov    %rax,0x30(%r15)
  a2f366:	movupd 0x6b0(%rsp),%xmm0
  a2f36f:	movupd 0x6c0(%rsp),%xmm1
  a2f378:	movups 0x6d0(%rsp),%xmm2
  a2f380:	movups %xmm2,0x20(%r15)
  a2f385:	movupd %xmm1,0x10(%r15)
  a2f38b:	movupd %xmm0,(%r15)
  a2f390:	mov    %rbx,%rdi
  a2f393:	call   *0xafe61f(%rip)        # 152d9b8 <_DYNAMIC+0x1420>
  a2f399:	lea    0x250(%rsp),%rdi
  a2f3a1:	call   a275d0 <core::ptr::drop_glue::<core::iter::adapters::flatten::Flatten<core::array::iter::IntoIter<core::option::Option<core::result::Result<gpui::runtime::Commit, gpui::runtime::Error>>, 16>>>>
  a2f3a6:	jmp    a2f97e <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x15de>
  a2f3ab:	lea    0x298(%rsp),%rax
  a2f3b3:	mov    0x30(%rax),%rcx
  a2f3b7:	mov    %rcx,0xa0(%rsp)
  a2f3bf:	movups (%rax),%xmm0
  a2f3c2:	movups 0x10(%rax),%xmm1
  a2f3c6:	movups 0x20(%rax),%xmm2
  a2f3ca:	movaps %xmm2,0x90(%rsp)
  a2f3d2:	movaps %xmm1,0x80(%rsp)
  a2f3da:	movaps %xmm0,0x70(%rsp)
  a2f3df:	mov    0x290(%rsp),%rax
  a2f3e7:	mov    %rax,0x840(%rsp)
  a2f3ef:	movups 0x250(%rsp),%xmm0
  a2f3f7:	movups 0x260(%rsp),%xmm1
  a2f3ff:	movups 0x270(%rsp),%xmm2
  a2f407:	movups 0x280(%rsp),%xmm3
  a2f40f:	movaps %xmm3,0x830(%rsp)
  a2f417:	movaps %xmm2,0x820(%rsp)
  a2f41f:	movaps %xmm1,0x810(%rsp)
  a2f427:	movaps %xmm0,0x800(%rsp)
  a2f42f:	mov    0x1e0(%r14),%rdi
  a2f436:	test   %rdi,%rdi
  a2f439:	je     a2f7b9 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1419>
  a2f43f:	mov    0x1e8(%r14),%rax
  a2f446:	lea    0x70(%rsp),%rsi
  a2f44b:	call   *0x20(%rax)
  a2f44e:	jmp    a2f840 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x14a0>
  a2f453:	call   *0xafd37f(%rip)        # 152c7d8 <_DYNAMIC+0x240>
  a2f459:	mov    $0x35,%r15d
  a2f45f:	mov    $0x35,%edi
  a2f464:	mov    $0x1,%esi
  a2f469:	call   *0xafd371(%rip)        # 152c7e0 <_DYNAMIC+0x248>
  a2f46f:	test   %rax,%rax
  a2f472:	je     a2fd5d <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x19bd>
  a2f478:	mov    %rax,%r12
  a2f47b:	movups -0x89a376(%rip),%xmm0        # 19510c <anon.41931c7f01a0f669fcd75d8bc79f57d6.412.llvm.13234298307199123836+0x1fa>
  a2f482:	movups %xmm0,0x20(%rax)
  a2f486:	movups -0x89a391(%rip),%xmm0        # 1950fc <anon.41931c7f01a0f669fcd75d8bc79f57d6.412.llvm.13234298307199123836+0x1ea>
  a2f48d:	movups %xmm0,0x10(%rax)
  a2f491:	movups -0x89a3ac(%rip),%xmm0        # 1950ec <anon.41931c7f01a0f669fcd75d8bc79f57d6.412.llvm.13234298307199123836+0x1da>
  a2f498:	movups %xmm0,(%rax)
  a2f49b:	movabs $0x656b617720726576,%rax
  a2f4a5:	mov    %rax,0x2d(%r12)
  a2f4aa:	mov    $0x2d,%ebp
  a2f4af:	mov    %r13,%rdi
  a2f4b2:	call   a26ee0 <core::ptr::drop_glue::<gpui::runtime::Win<empty::Empty>>>
  a2f4b7:	mov    $0x35,%r13d
  a2f4bd:	mov    0x30(%rsp),%rax
  a2f4c2:	lock decq (%rax)
  a2f4c6:	jne    a2ef6e <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xbce>
  a2f4cc:	lea    0x30(%rsp),%rdi
  a2f4d1:	call   *0xafdea9(%rip)        # 152d380 <_DYNAMIC+0xde8>
  a2f4d7:	jmp    a2ef6e <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xbce>
  a2f4dc:	mov    0x1d8(%r14),%rdi
  a2f4e3:	test   %rdi,%rdi
  a2f4e6:	je     a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2f4ec:	add    $0x10,%rdi
  a2f4f0:	call   a2d930 <<winit::window::Window>::inner_size>
  a2f4f5:	shl    $0x20,%rdx
  a2f4f9:	mov    %eax,%eax
  a2f4fb:	or     %rax,%rdx
  a2f4fe:	lea    0x250(%rsp),%rdi
  a2f506:	mov    %r14,%rsi
  a2f509:	call   a2d650 <<gpui::native::NativeHost<empty::Empty>>::resize>
  a2f50e:	jmp    a2fb2e <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x178e>
  a2f513:	cmpb   $0x0,0x82(%r15)
  a2f51b:	jne    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2f521:	cmpb   $0x0,0x78(%r15)
  a2f526:	jne    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2f52c:	movzbl 0x60(%r15),%esi
  a2f531:	cmp    $0xff,%rsi
  a2f538:	je     a2fafd <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x175d>
  a2f53e:	lea    -0x17(%rsi),%rdx
  a2f542:	xor    %ecx,%ecx
  a2f544:	cmp    $0x18,%sil
  a2f548:	cmovae %rdx,%rcx
  a2f54c:	test   %rcx,%rcx
  a2f54f:	je     a2fb79 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x17d9>
  a2f555:	cmp    $0x1,%ecx
  a2f558:	jne    a2fb89 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x17e9>
  a2f55e:	mov    0x68(%r15),%rcx
  a2f562:	mov    0x70(%r15),%rsi
  a2f566:	jmp    a2fb95 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x17f5>
  a2f56b:	lea    0x250(%rsp),%rdi
  a2f573:	mov    %r14,%rsi
  a2f576:	call   a2cb20 <<gpui::native::NativeHost<empty::Empty>>::redraw>
  a2f57b:	jmp    a2fb2e <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x178e>
  a2f580:	mov    0x4(%r15),%eax
  a2f584:	mov    %eax,0x200(%r14)
  a2f58b:	jmp    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2f590:	movb   $0x1,0x205(%r14)
  a2f598:	movzbl 0x2(%r15),%eax
  a2f59d:	mov    %al,0x204(%r14)
  a2f5a4:	test   %al,%al
  a2f5a6:	jne    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2f5ac:	mov    0x1d8(%r14),%rdi
  a2f5b3:	test   %rdi,%rdi
  a2f5b6:	jne    a2f8cd <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x152d>
  a2f5bc:	jmp    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2f5c1:	cmpb   $0x0,0x2(%r15)
  a2f5c6:	jne    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2f5cc:	mov    $0xffffffff,%eax
  a2f5d1:	mov    %rax,0x1b0(%r14)
  a2f5d8:	movq   $0x0,0x1b8(%r14)
  a2f5e3:	cmpl   $0x1,(%r14)
  a2f5e7:	jne    a2f622 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1282>
  a2f5e9:	lea    0x8(%r14),%rsi
  a2f5ed:	lea    0x800(%rsp),%r15
  a2f5f5:	mov    %r15,%rdi
  a2f5f8:	call   9b9680 <<gpui::runtime::Win<empty::Empty>>::clear_focus>
  a2f5fd:	lea    0x250(%rsp),%rdi
  a2f605:	mov    %r14,%rsi
  a2f608:	mov    %r15,%rdx
  a2f60b:	call   a2ba40 <<gpui::native::NativeHost<empty::Empty>>::input_result>
  a2f610:	mov    0x250(%rsp),%rbp
  a2f618:	cmp    $0xfffffffffffffffe,%rbp
  a2f61c:	jne    a2fb40 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x17a0>
  a2f622:	movl   $0x0,0x200(%r14)
  a2f62d:	jmp    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2f632:	mov    %r14,%rdi
  a2f635:	call   a2bbc0 <<gpui::native::NativeHost<empty::Empty>>::retire_window>
  a2f63a:	jmp    a2e6ec <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x34c>
  a2f63f:	mov    $0xffffffff,%eax
  a2f644:	mov    %rax,0x1b0(%r14)
  a2f64b:	movq   $0x0,0x1b8(%r14)
  a2f656:	jmp    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2f65b:	cmpl   $0x1,(%r14)
  a2f65f:	jne    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2f665:	movupd 0x8(%r15),%xmm0
  a2f66b:	cvtpd2ps %xmm0,%xmm0
  a2f66f:	lea    0x8(%r14),%rsi
  a2f673:	lea    0x1b0(%r14),%rdx
  a2f67a:	movl   $0x0,0x800(%rsp)
  a2f685:	movlpd %xmm0,0x804(%rsp)
  a2f68e:	lea    0x720(%rsp),%rdi
  a2f696:	lea    0x800(%rsp),%rcx
  a2f69e:	call   9b96d0 <<gpui::runtime::Win<empty::Empty>>::pointer_event>
  a2f6a3:	mov    0x720(%rsp),%rax
  a2f6ab:	cmp    $0xfffffffffffffffe,%rax
  a2f6af:	jne    a2faab <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x170b>
  a2f6b5:	cmpq   $0x0,0x748(%rsp)
  a2f6be:	jne    a2fac2 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1722>
  a2f6c4:	jmp    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2f6c9:	cmpl   $0x1,(%r14)
  a2f6cd:	jne    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2f6d3:	lea    0x8(%r14),%rsi
  a2f6d7:	lea    0x1b0(%r14),%rdx
  a2f6de:	movl   $0x1,0x800(%rsp)
  a2f6e9:	lea    0x758(%rsp),%rdi
  a2f6f1:	lea    0x800(%rsp),%rcx
  a2f6f9:	call   9b96d0 <<gpui::runtime::Win<empty::Empty>>::pointer_event>
  a2f6fe:	mov    0x758(%rsp),%rax
  a2f706:	cmp    $0xfffffffffffffffe,%rax
  a2f70a:	jne    a2fad4 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1734>
  a2f710:	cmpq   $0x0,0x780(%rsp)
  a2f719:	jne    a2faeb <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x174b>
  a2f71f:	jmp    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2f724:	cmpw   $0x0,0x2(%r15)
  a2f72a:	jne    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2f730:	cmpl   $0x1,(%r14)
  a2f734:	jne    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2f73a:	cmpb   $0x1,0x8(%r15)
  a2f73f:	mov    $0x3,%eax
  a2f744:	sbb    $0x0,%eax
  a2f747:	lea    0x8(%r14),%rsi
  a2f74b:	lea    0x1b0(%r14),%rdx
  a2f752:	mov    %eax,0x800(%rsp)
  a2f759:	lea    0x7c8(%rsp),%rdi
  a2f761:	lea    0x800(%rsp),%rcx
  a2f769:	call   9b96d0 <<gpui::runtime::Win<empty::Empty>>::pointer_event>
  a2f76e:	mov    0x7c8(%rsp),%rax
  a2f776:	cmp    $0xfffffffffffffffe,%rax
  a2f77a:	je     a2fb16 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1776>
  a2f780:	cmp    $0x19,%eax
  a2f783:	jne    a2fb16 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1776>
  a2f789:	lea    0x7c8(%rsp),%rdi
  a2f791:	call   a28d20 <core::ptr::drop_glue::<gpui::runtime::Error>>
  a2f796:	jmp    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2f79b:	mov    0x1d8(%r14),%rdi
  a2f7a2:	test   %rdi,%rdi
  a2f7a5:	je     a2f9d4 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1634>
  a2f7ab:	add    $0x10,%rdi
  a2f7af:	call   a2a600 <<winit::window::Window>::scale_factor>
  a2f7b4:	jmp    a2f9dc <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x163c>
  a2f7b9:	lea    0x838(%rsp),%rax
  a2f7c1:	lea    0x810(%rsp),%rcx
  a2f7c9:	lea    0x818(%rsp),%rdx
  a2f7d1:	mov    %rax,0x100(%rsp)
  a2f7d9:	mov    0xafd618(%rip),%rax        # 152cdf8 <_DYNAMIC+0x860>
  a2f7e0:	mov    %rax,0x108(%rsp)
  a2f7e8:	mov    %rcx,0x110(%rsp)
  a2f7f0:	mov    0xafd319(%rip),%rax        # 152cb10 <_DYNAMIC+0x578>
  a2f7f7:	mov    %rax,0x118(%rsp)
  a2f7ff:	mov    %rdx,0x120(%rsp)
  a2f807:	mov    %rax,0x128(%rsp)
  a2f80f:	lea    0x70(%rsp),%rax
  a2f814:	mov    %rax,0x130(%rsp)
  a2f81c:	mov    0xafe105(%rip),%rax        # 152d928 <_DYNAMIC+0x1390>
  a2f823:	mov    %rax,0x138(%rsp)
  a2f82b:	lea    -0x8c4b4e(%rip),%rdi        # 16ace4 <anon.2277df3ceaea8d4be421179083a68ea6.39.llvm.213539347725472506+0x87>
  a2f832:	lea    0x100(%rsp),%rsi
  a2f83a:	call   *0xafe020(%rip)        # 152d860 <_DYNAMIC+0x12c8>
  a2f840:	movapd 0x800(%rsp),%xmm0
  a2f849:	movapd 0x810(%rsp),%xmm1
  a2f852:	movaps 0x820(%rsp),%xmm2
  a2f85a:	movups %xmm2,0x1d8(%rsp)
  a2f862:	movupd %xmm1,0x1c8(%rsp)
  a2f86b:	movupd %xmm0,0x1b8(%rsp)
  a2f874:	movq   $0xfffffffffffffffe,0x1b0(%rsp)
  a2f880:	lea    0x70(%rsp),%rdi
  a2f885:	call   a28d20 <core::ptr::drop_glue::<gpui::runtime::Error>>
  a2f88a:	lea    0x6e8(%rsp),%rdi
  a2f892:	lea    0x1b0(%rsp),%rdx
  a2f89a:	mov    %r14,%rsi
  a2f89d:	call   a2ba40 <<gpui::native::NativeHost<empty::Empty>>::input_result>
  a2f8a2:	cmpl   $0xfffffffe,0x6e8(%rsp)
  a2f8aa:	jne    a2f990 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x15f0>
  a2f8b0:	cmpl   $0xffffffff,0x30(%r14)
  a2f8b5:	je     a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2f8b7:	mov    0x1d8(%r14),%rdi
  a2f8be:	test   %rdi,%rdi
  a2f8c1:	sete   %al
  a2f8c4:	or     0x204(%r14),%al
  a2f8cb:	jne    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2f8cd:	add    $0x10,%rdi
  a2f8d1:	call   a2a790 <<winit::window::Window>::request_redraw>
  a2f8d6:	cmpl   $0xfffffffe,0xf8(%r14)
  a2f8de:	jne    a2f97e <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x15de>
  a2f8e4:	cmpl   $0xfffffffe,0x48(%r14)
  a2f8e9:	je     a2f97e <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x15de>
  a2f8ef:	cmpb   $0x0,(%r14)
  a2f8f3:	je     a2f97e <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x15de>
  a2f8f9:	lea    0x48(%r14),%r15
  a2f8fd:	lea    0x8(%r14),%rdx
  a2f901:	lea    0x658(%rsp),%rdi
  a2f909:	mov    %r15,%rsi
  a2f90c:	call   9e48d0 <<gpui::native::accessibility::Bridge>::sync::<empty::Empty, ()>>
  a2f911:	cmpl   $0xfffffffe,0x658(%rsp)
  a2f919:	je     a2f97e <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x15de>
  a2f91b:	mov    %r15,%rdi
  a2f91e:	call   a26340 <core::ptr::drop_glue::<core::option::Option<gpui::native::accessibility::Bridge>>>
  a2f923:	add    $0xf8,%r14
  a2f92a:	movq   $0xfffffffffffffffe,(%r15)
  a2f931:	cmpl   $0xfffffffe,(%r14)
  a2f935:	je     a2f93f <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x159f>
  a2f937:	mov    %r14,%rdi
  a2f93a:	call   a28c80 <core::ptr::drop_glue::<gpui::native::NativeError>>
  a2f93f:	mov    0x688(%rsp),%rax
  a2f947:	mov    %rax,0x30(%r14)
  a2f94b:	movupd 0x658(%rsp),%xmm0
  a2f954:	movupd 0x668(%rsp),%xmm1
  a2f95d:	movups 0x678(%rsp),%xmm2
  a2f965:	movups %xmm2,0x20(%r14)
  a2f96a:	movupd %xmm1,0x10(%r14)
  a2f970:	movupd %xmm0,(%r14)
  a2f975:	mov    %rbx,%rdi
  a2f978:	call   *0xafe03a(%rip)        # 152d9b8 <_DYNAMIC+0x1420>
  a2f97e:	add    $0xb88,%rsp
  a2f985:	pop    %rbx
  a2f986:	pop    %r12
  a2f988:	pop    %r13
  a2f98a:	pop    %r14
  a2f98c:	pop    %r15
  a2f98e:	pop    %rbp
  a2f98f:	ret
  a2f990:	lea    0xf8(%r14),%r15
  a2f997:	cmpl   $0xfffffffe,0xf8(%r14)
  a2f99f:	je     a2f9a9 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1609>
  a2f9a1:	mov    %r15,%rdi
  a2f9a4:	call   a28c80 <core::ptr::drop_glue::<gpui::native::NativeError>>
  a2f9a9:	mov    0x718(%rsp),%rax
  a2f9b1:	mov    %rax,0x30(%r15)
  a2f9b5:	movupd 0x6e8(%rsp),%xmm0
  a2f9be:	movupd 0x6f8(%rsp),%xmm1
  a2f9c7:	movups 0x708(%rsp),%xmm2
  a2f9cf:	jmp    a2e4a6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x106>
  a2f9d4:	movsd  -0x8a0ee4(%rip),%xmm0        # 18eaf8 <anon.822e710a3ac147487bb68930a699e853.84.llvm.7311037932848680773+0x20>
  a2f9dc:	cmpb   $0x0,0x8(%r15)
  a2f9e1:	je     a2f9fb <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x165b>
  a2f9e3:	movupd 0x10(%r15),%xmm1
  a2f9e9:	xorpd  -0x8a2491(%rip),%xmm1        # 18d560 <anon.822e710a3ac147487bb68930a699e853.89.llvm.7311037932848680773+0xd0>
  a2f9f1:	unpcklpd %xmm0,%xmm0
  a2f9f5:	divpd  %xmm0,%xmm1
  a2f9f9:	jmp    a2fa08 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1668>
  a2f9fb:	cvtps2pd 0xc(%r15),%xmm1
  a2fa00:	mulpd  -0x8a3d68(%rip),%xmm1        # 18bca0 <anon.5ee778dbc9410921a725c4c57b32111b.58.llvm.8966071514708437312+0x130>
  a2fa08:	movq   %xmm1,%rax
  a2fa0d:	movabs $0x7fffffffffffffff,%rcx
  a2fa17:	and    %rcx,%rax
  a2fa1a:	movabs $0x7fefffffffffffff,%rdx
  a2fa24:	cmp    %rdx,%rax
  a2fa27:	setg   %al
  a2fa2a:	movdqa %xmm1,%xmm0
  a2fa2e:	punpckhqdq %xmm1,%xmm0
  a2fa32:	movq   %xmm0,%rsi
  a2fa37:	and    %rcx,%rsi
  a2fa3a:	cmp    %rdx,%rsi
  a2fa3d:	setg   %cl
  a2fa40:	or     %al,%cl
  a2fa42:	jne    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2fa48:	cmpl   $0x1,(%r14)
  a2fa4c:	jne    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2fa52:	lea    0x8(%r14),%rsi
  a2fa56:	lea    0x1b0(%r14),%rdx
  a2fa5d:	movl   $0x4,0x800(%rsp)
  a2fa68:	movupd %xmm1,0x808(%rsp)
  a2fa71:	lea    0x790(%rsp),%rdi
  a2fa79:	lea    0x800(%rsp),%rcx
  a2fa81:	call   9b96d0 <<gpui::runtime::Win<empty::Empty>>::pointer_event>
  a2fa86:	mov    0x790(%rsp),%rax
  a2fa8e:	cmp    $0xfffffffffffffffe,%rax
  a2fa92:	je     a2fb04 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1764>
  a2fa94:	cmp    $0x19,%eax
  a2fa97:	jne    a2fb04 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1764>
  a2fa99:	lea    0x790(%rsp),%rdi
  a2faa1:	call   a28d20 <core::ptr::drop_glue::<gpui::runtime::Error>>
  a2faa6:	jmp    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2faab:	cmp    $0x19,%eax
  a2faae:	jne    a2fac2 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1722>
  a2fab0:	lea    0x720(%rsp),%rdi
  a2fab8:	call   a28d20 <core::ptr::drop_glue::<gpui::runtime::Error>>
  a2fabd:	jmp    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2fac2:	lea    0x250(%rsp),%rdi
  a2faca:	lea    0x720(%rsp),%rdx
  a2fad2:	jmp    a2fb26 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1786>
  a2fad4:	cmp    $0x19,%eax
  a2fad7:	jne    a2faeb <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x174b>
  a2fad9:	lea    0x758(%rsp),%rdi
  a2fae1:	call   a28d20 <core::ptr::drop_glue::<gpui::runtime::Error>>
  a2fae6:	jmp    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2faeb:	lea    0x250(%rsp),%rdi
  a2faf3:	lea    0x758(%rsp),%rdx
  a2fafb:	jmp    a2fb26 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1786>
  a2fafd:	xor    %ecx,%ecx
  a2faff:	jmp    a2fb95 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x17f5>
  a2fb04:	lea    0x250(%rsp),%rdi
  a2fb0c:	lea    0x790(%rsp),%rdx
  a2fb14:	jmp    a2fb26 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1786>
  a2fb16:	lea    0x250(%rsp),%rdi
  a2fb1e:	lea    0x7c8(%rsp),%rdx
  a2fb26:	mov    %r14,%rsi
  a2fb29:	call   a2ba40 <<gpui::native::NativeHost<empty::Empty>>::input_result>
  a2fb2e:	mov    0x250(%rsp),%rbp
  a2fb36:	cmp    $0xfffffffffffffffe,%rbp
  a2fb3a:	je     a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2fb40:	mov    0x258(%rsp),%r13
  a2fb48:	mov    0x260(%rsp),%r12
  a2fb50:	mov    0x268(%rsp),%r15
  a2fb58:	movupd 0x270(%rsp),%xmm0
  a2fb61:	movapd %xmm0,0x10(%rsp)
  a2fb67:	mov    0x280(%rsp),%rax
  a2fb6f:	mov    %rax,0x20(%rsp)
  a2fb74:	jmp    a2e69f <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x2ff>
  a2fb79:	cmp    $0x18,%sil
  a2fb7d:	jae    a2fd49 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x19a9>
  a2fb83:	lea    0x61(%r15),%rcx
  a2fb87:	jmp    a2fb95 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x17f5>
  a2fb89:	mov    0x68(%r15),%rcx
  a2fb8d:	mov    0x70(%r15),%rsi
  a2fb91:	add    $0x10,%rcx
  a2fb95:	mov    0x200(%r14),%edx
  a2fb9c:	test   $0x820,%edx
  a2fba2:	jne    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2fba8:	cmpl   $0x1,(%r14)
  a2fbac:	jne    a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2fbb2:	test   %ax,%ax
  a2fbb5:	je     a2fc52 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x18b2>
  a2fbbb:	test   %rcx,%rcx
  a2fbbe:	je     a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2fbc4:	mov    %rcx,0x108(%rsp)
  a2fbcc:	mov    %rsi,0x110(%rsp)
  a2fbd4:	xor    %eax,%eax
  a2fbd6:	lea    0x8(%r14),%rsi
  a2fbda:	mov    %al,0x100(%rsp)
  a2fbe1:	lea    0x250(%rsp),%r15
  a2fbe9:	lea    0x100(%rsp),%rdx
  a2fbf1:	mov    %r15,%rdi
  a2fbf4:	call   9ba360 <<gpui::runtime::Win<empty::Empty>>::key>
  a2fbf9:	lea    0x800(%rsp),%rdi
  a2fc01:	mov    %r14,%rsi
  a2fc04:	mov    %r15,%rdx
  a2fc07:	call   a2ba40 <<gpui::native::NativeHost<empty::Empty>>::input_result>
  a2fc0c:	mov    0x800(%rsp),%rbp
  a2fc14:	cmp    $0xfffffffffffffffe,%rbp
  a2fc18:	je     a2f8d6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1536>
  a2fc1e:	mov    0x808(%rsp),%r13
  a2fc26:	mov    0x810(%rsp),%r12
  a2fc2e:	mov    0x818(%rsp),%r15
  a2fc36:	movupd 0x820(%rsp),%xmm0
  a2fc3f:	movapd %xmm0,0x10(%rsp)
  a2fc45:	mov    0x830(%rsp),%rax
  a2fc4d:	jmp    a2fb6f <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x17cf>
  a2fc52:	movzwl 0x2(%r15),%eax
  a2fc57:	add    $0xfffffff2,%eax
  a2fc5a:	cmp    $0xb,%eax
  a2fc5d:	ja     a2fbbb <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x181b>
  a2fc63:	lea    -0x89abca(%rip),%rdi        # 1950a0 <anon.41931c7f01a0f669fcd75d8bc79f57d6.412.llvm.13234298307199123836+0x18e>
  a2fc6a:	movslq (%rdi,%rax,4),%rax
  a2fc6e:	add    %rdi,%rax
  a2fc71:	jmp    *%rax
  a2fc73:	mov    $0x6,%al
  a2fc75:	jmp    a2fbd6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1836>
  a2fc7a:	lea    -0x89a971(%rip),%rdi        # 195310 <anon.fff2d4355c6109bc0e8af2445443084d.58.llvm.4725208967334239140>
  a2fc81:	lea    0xa8d080(%rip),%rcx        # 14bcd08 <anon.fff2d4355c6109bc0e8af2445443084d.8.llvm.4725208967334239140>
  a2fc88:	lea    0xa8d2f9(%rip),%r8        # 14bcf88 <anon.fff2d4355c6109bc0e8af2445443084d.60.llvm.4725208967334239140>
  a2fc8f:	lea    0x3f(%rsp),%rdx
  a2fc94:	mov    $0x37,%esi
  a2fc99:	call   *0xafcc71(%rip)        # 152c910 <_DYNAMIC+0x378>
  a2fc9f:	jmp    a2fd71 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x19d1>
  a2fca4:	lea    -0x8a02d3(%rip),%rdi        # 18f9d8 <anon.5e2c2cd338f183f0185d3116c074ef00.75.llvm.4553572696083558104>
  a2fcab:	lea    0xa88fbe(%rip),%rdx        # 14b8c70 <anon.5e2c2cd338f183f0185d3116c074ef00.76.llvm.4553572696083558104>
  a2fcb2:	mov    $0x14,%esi
  a2fcb7:	call   *0xafcc4b(%rip)        # 152c908 <_DYNAMIC+0x370>
  a2fcbd:	mov    $0x8,%edi
  a2fcc2:	mov    $0x18,%esi
  a2fcc7:	call   *0xafcb33(%rip)        # 152c800 <_DYNAMIC+0x268>
  a2fccd:	jmp    a2fd71 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x19d1>
  a2fcd2:	mov    $0x7,%al
  a2fcd4:	jmp    a2fbd6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1836>
  a2fcd9:	mov    $0x1,%al
  a2fcdb:	jmp    a2fbd6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1836>
  a2fce0:	test   $0x4,%dl
  a2fce3:	sete   %al
  a2fce6:	xor    $0x5,%al
  a2fce8:	jmp    a2fbd6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1836>
  a2fced:	shr    $0x2,%dl
  a2fcf0:	and    $0x1,%dl
  a2fcf3:	mov    %dl,0x101(%rsp)
  a2fcfa:	mov    $0x2,%al
  a2fcfc:	jmp    a2fbd6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1836>
  a2fd01:	shr    $0x2,%dl
  a2fd04:	and    $0x1,%dl
  a2fd07:	mov    %dl,0x101(%rsp)
  a2fd0e:	mov    $0x3,%al
  a2fd10:	jmp    a2fbd6 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1836>
  a2fd15:	mov    0xafdcb4(%rip),%rdi        # 152d9d0 <_DYNAMIC+0x1438>
  a2fd1c:	call   *0xafd5de(%rip)        # 152d300 <_DYNAMIC+0xd68>
  a2fd22:	test   %al,%al
  a2fd24:	jne    a2eaa1 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x701>
  a2fd2a:	jmp    a2ece7 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x947>
  a2fd2f:	mov    0xafdc92(%rip),%rdi        # 152d9c8 <_DYNAMIC+0x1430>
  a2fd36:	call   *0xafd5c4(%rip)        # 152d300 <_DYNAMIC+0xd68>
  a2fd3c:	test   %al,%al
  a2fd3e:	jne    a2e987 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x5e7>
  a2fd44:	jmp    a2edcd <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0xa2d>
  a2fd49:	lea    0xa8d1d0(%rip),%rcx        # 14bcf20 <anon.fff2d4355c6109bc0e8af2445443084d.8.llvm.4725208967334239140+0x218>
  a2fd50:	mov    $0x17,%edx
  a2fd55:	xor    %edi,%edi
  a2fd57:	call   *0xafcabb(%rip)        # 152c818 <_DYNAMIC+0x280>
  a2fd5d:	mov    %ebp,0x8(%rsp)
  a2fd61:	mov    $0x1,%edi
  a2fd66:	mov    $0x35,%esi
  a2fd6b:	call   *0xafcb57(%rip)        # 152c8c8 <_DYNAMIC+0x330>
  a2fd71:	ud2
  a2fd73:	mov    %r13,(%r15)
  a2fd76:	mov    %rax,%rdi
  a2fd79:	call   14b7130 <_Unwind_Resume@plt>
  a2fd7e:	mov    %rax,%rbx
  a2fd81:	movq   $0x1,(%r14)
  a2fd88:	mov    %r13,0x8(%r14)
  a2fd8c:	movl   $0x0,0x8(%rsp)
  a2fd94:	jmp    a2ff28 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1b88>
  a2fd99:	mov    %rax,%rbx
  a2fd9c:	lea    0x40(%rsp),%rdi
  a2fda1:	call   a28b90 <core::ptr::drop_glue::<tracing::span::Span>>
  a2fda6:	jmp    a2feec <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1b4c>
  a2fdab:	call   *0xafca6f(%rip)        # 152c820 <_DYNAMIC+0x288>
  a2fdb1:	mov    %rax,%rbx
  a2fdb4:	lea    0x250(%rsp),%rdi
  a2fdbc:	call   a28b90 <core::ptr::drop_glue::<tracing::span::Span>>
  a2fdc1:	jmp    a300d8 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1d38>
  a2fdc6:	call   *0xafca54(%rip)        # 152c820 <_DYNAMIC+0x288>
  a2fdcc:	mov    %rax,%rbx
  a2fdcf:	lea    0x70(%rsp),%rdi
  a2fdd4:	call   a28d20 <core::ptr::drop_glue::<gpui::runtime::Error>>
  a2fdd9:	mov    %rbx,%rdi
  a2fddc:	call   14b7130 <_Unwind_Resume@plt>
  a2fde1:	mov    %rax,%rbx
  a2fde4:	lea    0x250(%rsp),%rdi
  a2fdec:	call   a275d0 <core::ptr::drop_glue::<core::iter::adapters::flatten::Flatten<core::array::iter::IntoIter<core::option::Option<core::result::Result<gpui::runtime::Commit, gpui::runtime::Error>>, 16>>>>
  a2fdf1:	mov    %rbx,%rdi
  a2fdf4:	call   14b7130 <_Unwind_Resume@plt>
  a2fdf9:	mov    %rax,%rbx
  a2fdfc:	lea    0x100(%rsp),%rsi
  a2fe04:	mov    $0xb0,%edx
  a2fe09:	mov    %rbp,%rdi
  a2fe0c:	call   *0xafc9e6(%rip)        # 152c7f8 <memcpy@GLIBC_2.14>
  a2fe12:	movl   $0x0,0x8(%rsp)
  a2fe1a:	jmp    a2fe44 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1aa4>
  a2fe1c:	mov    %rax,%rbx
  a2fe1f:	lock decq (%r15)
  a2fe23:	mov    $0x1,%al
  a2fe25:	mov    %eax,0x8(%rsp)
  a2fe29:	jne    a2fe44 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1aa4>
  a2fe2b:	lea    0xd0(%rsp),%rdi
  a2fe33:	call   *0xafdae7(%rip)        # 152d920 <_DYNAMIC+0x1388>
  a2fe39:	jmp    a2fe44 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1aa4>
  a2fe3b:	call   *0xafc9df(%rip)        # 152c820 <_DYNAMIC+0x288>
  a2fe41:	mov    %rax,%rbx
  a2fe44:	mov    %r13,%rdi
  a2fe47:	call   a26ee0 <core::ptr::drop_glue::<gpui::runtime::Win<empty::Empty>>>
  a2fe4c:	jmp    a2ff28 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1b88>
  a2fe51:	movq   $0x0,(%r15)
  a2fe58:	mov    %rax,%rdi
  a2fe5b:	call   14b7130 <_Unwind_Resume@plt>
  a2fe60:	mov    %rax,%rbx
  a2fe63:	mov    0x8(%r15),%rsi
  a2fe67:	test   %rsi,%rsi
  a2fe6a:	je     a2fe79 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1ad9>
  a2fe6c:	mov    0x10(%r15),%rdx
  a2fe70:	mov    %r13,%rdi
  a2fe73:	call   *0xafc96f(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  a2fe79:	mov    %rbp,0x1f0(%r14)
  a2fe80:	mov    0x8(%rsp),%rax
  a2fe85:	mov    %rax,0x1f8(%r14)
  a2fe8c:	jmp    a2ff79 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1bd9>
  a2fe91:	mov    %rax,%rbx
  a2fe94:	mov    0x8(%r15),%rsi
  a2fe98:	test   %rsi,%rsi
  a2fe9b:	je     a2feaa <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1b0a>
  a2fe9d:	mov    0x10(%r15),%rdx
  a2fea1:	mov    %r13,%rdi
  a2fea4:	call   *0xafc93e(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  a2feaa:	mov    %rbp,0x1e0(%r14)
  a2feb1:	mov    0x8(%rsp),%rax
  a2feb6:	mov    %rax,0x1e8(%r14)
  a2febd:	mov    $0x1,%bpl
  a2fec0:	mov    $0x1,%r14b
  a2fec3:	jmp    a30058 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1cb8>
  a2fec8:	mov    %rax,%rbx
  a2fecb:	movq   $0xfffffffffffffffe,(%r15)
  a2fed2:	lea    0x808(%rsp),%rdi
  a2feda:	call   a28c80 <core::ptr::drop_glue::<gpui::native::NativeError>>
  a2fedf:	mov    %rbx,%rdi
  a2fee2:	call   14b7130 <_Unwind_Resume@plt>
  a2fee7:	jmp    a2ff1f <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1b7f>
  a2fee9:	mov    %rax,%rbx
  a2feec:	lea    0x800(%rsp),%rdi
  a2fef4:	call   a27e00 <core::ptr::drop_glue::<winit::window::WindowAttributes>>
  a2fef9:	jmp    a30053 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1cb3>
  a2fefe:	mov    %rax,%rbx
  a2ff01:	movw   $0x2,(%r12)
  a2ff08:	mov    %rbx,%rdi
  a2ff0b:	call   14b7130 <_Unwind_Resume@plt>
  a2ff10:	movq   $0xffffffffffffffff,(%r15)
  a2ff17:	mov    %rax,%rdi
  a2ff1a:	call   14b7130 <_Unwind_Resume@plt>
  a2ff1f:	mov    %rax,%rbx
  a2ff22:	mov    $0x1,%al
  a2ff24:	mov    %eax,0x8(%rsp)
  a2ff28:	mov    0x30(%rsp),%rax
  a2ff2d:	lock decq (%rax)
  a2ff31:	jne    a2ff3e <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1b9e>
  a2ff33:	lea    0x30(%rsp),%rdi
  a2ff38:	call   *0xafd442(%rip)        # 152d380 <_DYNAMIC+0xde8>
  a2ff3e:	cmpb   $0x0,0x8(%rsp)
  a2ff43:	jne    a30053 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1cb3>
  a2ff49:	jmp    a300d8 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1d38>
  a2ff4e:	mov    %rax,%rbx
  a2ff51:	lea    0xd0(%rsp),%rdi
  a2ff59:	call   a28b10 <core::ptr::drop_glue::<tracing::span::EnteredSpan>>
  a2ff5e:	jmp    a30053 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1cb3>
  a2ff63:	call   *0xafc8b7(%rip)        # 152c820 <_DYNAMIC+0x288>
  a2ff69:	mov    %rax,%rbx
  a2ff6c:	lea    0x100(%rsp),%rdi
  a2ff74:	call   a260f0 <core::ptr::drop_glue::<core::option::Option<winit::window::Fullscreen>>>
  a2ff79:	mov    $0x1,%r14b
  a2ff7c:	xor    %ebp,%ebp
  a2ff7e:	jmp    a30058 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1cb8>
  a2ff83:	call   *0xafc897(%rip)        # 152c820 <_DYNAMIC+0x288>
  a2ff89:	mov    %rax,%rbx
  a2ff8c:	mov    $0x1,%r14b
  a2ff8f:	mov    $0x1,%bpl
  a2ff92:	jmp    a30087 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1ce7>
  a2ff97:	mov    %rax,%rbx
  a2ff9a:	jmp    a30053 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1cb3>
  a2ff9f:	mov    %rax,%rbx
  a2ffa2:	inc    %r13
  a2ffa5:	mov    %r13,0x258(%rsp)
  a2ffad:	lea    0x250(%rsp),%rdi
  a2ffb5:	call   a275d0 <core::ptr::drop_glue::<core::iter::adapters::flatten::Flatten<core::array::iter::IntoIter<core::option::Option<core::result::Result<gpui::runtime::Commit, gpui::runtime::Error>>, 16>>>>
  a2ffba:	mov    %rbx,%rdi
  a2ffbd:	call   14b7130 <_Unwind_Resume@plt>
  a2ffc2:	mov    %rax,%rbx
  a2ffc5:	movq   $0xfffffffffffffffe,(%r15)
  a2ffcc:	lea    0x658(%rsp),%rdi
  a2ffd4:	call   a28c80 <core::ptr::drop_glue::<gpui::native::NativeError>>
  a2ffd9:	mov    %rbx,%rdi
  a2ffdc:	call   14b7130 <_Unwind_Resume@plt>
  a2ffe1:	movq   $0x0,(%r15)
  a2ffe8:	mov    %rax,%rdi
  a2ffeb:	call   14b7130 <_Unwind_Resume@plt>
  a2fff0:	movw   $0x2,0x188(%r14)
  a2fffa:	mov    %rax,%rdi
  a2fffd:	call   14b7130 <_Unwind_Resume@plt>
  a30002:	movq   $0xffffffffffffffff,(%r15)
  a30009:	mov    %rax,%rdi
  a3000c:	call   14b7130 <_Unwind_Resume@plt>
  a30011:	mov    %rax,%rbx
  a30014:	lea    0x250(%rsp),%rdi
  a3001c:	call   a26cc0 <core::ptr::drop_glue::<alloc::sync::ArcInner<winit::window::Window>>>
  a30021:	jmp    a30053 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1cb3>
  a30023:	call   *0xafc7f7(%rip)        # 152c820 <_DYNAMIC+0x288>
  a30029:	mov    %rax,%rbx
  a3002c:	mov    0x40(%rsp),%rsi
  a30031:	test   %rsi,%rsi
  a30034:	je     a30046 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1ca6>
  a30036:	mov    0x48(%rsp),%rdi
  a3003b:	mov    $0x1,%edx
  a30040:	call   *0xafc7a2(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  a30046:	lea    0x250(%rsp),%rdi
  a3004e:	call   a27d80 <core::ptr::drop_glue::<winit::error::OsError>>
  a30053:	xor    %ebp,%ebp
  a30055:	xor    %r14d,%r14d
  a30058:	mov    0xb8(%rsp),%rsi
  a30060:	test   %rsi,%rsi
  a30063:	jne    a3006c <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1ccc>
  a30065:	test   %r14b,%r14b
  a30068:	jne    a30084 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1ce4>
  a3006a:	jmp    a300be <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1d1e>
  a3006c:	mov    0xc0(%rsp),%rdi
  a30074:	mov    $0x1,%edx
  a30079:	call   *0xafc769(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  a3007f:	test   %r14b,%r14b
  a30082:	je     a300be <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1d1e>
  a30084:	xor    %r14d,%r14d
  a30087:	cmpq   $0x0,0x68(%rsp)
  a3008d:	je     a300a4 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1d04>
  a3008f:	mov    0x78(%rsp),%rdi
  a30094:	mov    $0x1,%edx
  a30099:	mov    0x68(%rsp),%rsi
  a3009e:	call   *0xafc744(%rip)        # 152c7e8 <_DYNAMIC+0x250>
  a300a4:	test   %r14b,%r14b
  a300a7:	je     a300be <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1d1e>
  a300a9:	mov    0x90(%rsp),%rdi
  a300b1:	mov    0x98(%rsp),%rsi
  a300b9:	call   a253a0 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<dyn for<'a> core::ops::function::FnMut<(&'a gpui::runtime::Error,), Output = ()>>>>>
  a300be:	test   %bpl,%bpl
  a300c1:	je     a300d8 <<gpui::native::NativeHost<empty::Empty> as gpui_reactivity_host::native::Host>::dispatch+0x1d38>
  a300c3:	mov    0xa0(%rsp),%rdi
  a300cb:	mov    0xa8(%rsp),%rsi
  a300d3:	call   a253a0 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<dyn for<'a> core::ops::function::FnMut<(&'a gpui::runtime::Error,), Output = ()>>>>>
  a300d8:	mov    %rbx,%rdi
  a300db:	call   14b7130 <_Unwind_Resume@plt>
  a300e0:	call   *0xafc73a(%rip)        # 152c820 <_DYNAMIC+0x288>
  a300e6:	call   *0xafc734(%rip)        # 152c820 <_DYNAMIC+0x288>
