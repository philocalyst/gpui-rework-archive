"""Real AT-SPI Registry replay on the frozen ordinary native test consumer."""
import json,os,pathlib,subprocess,time
out=pathlib.Path('/tmp/gpui-a11y-owner-channel-captures/native-failure-second/registry')
out.mkdir(exist_ok=True)
env=dict(os.environ,DISPLAY=':244',GSETTINGS_BACKEND='memory')
paths='/nix/store/4g39rajyrxqn3na1kd4pykdigsr82af5-at-spi2-core-2.60.6/libexec/'
processes=[]
with (out/'services.log').open('w') as services:
    try:
        processes.append(subprocess.Popen(['/nix/store/iw8dx6lhrkdc5wzszjzqzl677y68y88r-xvfb-21.1.24/bin/Xvfb',':244','-screen','0','1024x768x24','-nolisten','tcp'],stdout=services,stderr=services,env=env))
        for _ in range(100):
            if pathlib.Path('/tmp/.X11-unix/X244').exists():break
            assert processes[0].poll() is None
            time.sleep(.05)
        assert pathlib.Path('/tmp/.X11-unix/X244').exists()
        processes.append(subprocess.Popen([paths+'at-spi-bus-launcher','--launch-immediately','--a11y=0'],stdout=services,stderr=services,env=env))
        for _ in range(100):
            ready=subprocess.run(['busctl','--user','--timeout=1','call','org.a11y.Bus','/org/a11y/bus','org.a11y.Bus','GetAddress'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            if ready.returncode==0:break
            time.sleep(.05)
        assert ready.returncode==0
        binary='/tmp/gpui-a11y-owner-channel-captures/native-failure-second/gpui-tests'
        name='native::accessibility::linux_tests::failure::native_atspi_failed_source_keeps_old_p_and_public_action_repairs'
        with (out/'client.log').open('w') as log:
            result=subprocess.run([binary,name,'--exact','--ignored','--nocapture','--test-threads=1'],env=env,stdout=log,stderr=log,timeout=90)
        (out/'result.json').write_text(json.dumps({'test':name,'exit':result.returncode},indent=2)+'\n')
        assert result.returncode==0
    finally:
        for process in reversed(processes):process.terminate()
        for process in reversed(processes):
            try:process.wait(timeout=10)
            except subprocess.TimeoutExpired:process.kill();process.wait()
