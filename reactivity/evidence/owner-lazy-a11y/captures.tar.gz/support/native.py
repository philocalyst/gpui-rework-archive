"""Actual native adapters/actions; isolated private test transport and X11."""
import hashlib,json,os,pathlib,shutil,subprocess,time
root=pathlib.Path('/tmp/gpui-a11y-owner-channel-sol')
out=pathlib.Path('/tmp/gpui-a11y-owner-channel-captures/native-157')
out.mkdir(exist_ok=True)
binary=out/'gpui-native-tests'
shutil.copy2('/tmp/gpui-a11y-owner-channel-target/debug/deps/gpui-e5c9359d761e98c0',binary)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest={'binary_sha256_before':sha(binary),'source_head':subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD']).decode().strip(),'tests':[]}
private_display=':243'
xvfb='/nix/store/iw8dx6lhrkdc5wzszjzqzl677y68y88r-xvfb-21.1.24/bin/Xvfb'
dbus='/nix/store/8snmq54bp5d5vp5dihgn7xr53hayx629-dbus-1.16.2/bin/dbus-run-session'
env=dict(os.environ,DISPLAY=private_display)
with (out/'xvfb.log').open('w') as log:
    display=subprocess.Popen([xvfb,private_display,'-screen','0','1024x768x24','-nolisten','tcp'],stdout=log,stderr=log)
    try:
        for _ in range(100):
            if pathlib.Path('/tmp/.X11-unix/X243').exists():break
            assert display.poll() is None,'Xvfb exited'
            time.sleep(.05)
        assert pathlib.Path('/tmp/.X11-unix/X243').exists()
        names=[
            'native::accessibility::linux_tests::native_atspi_late_service_owner_replacement_and_destroy',
            'native::accessibility::linux_tests::checkbox::native_atspi_checkbox_action_state_and_events',
            'native::accessibility::linux_tests::native_accessible_profile_without_session_bus_still_presents',
        ]
        for index,name in enumerate(names):
            child_env=env.copy()
            command=[str(binary),name,'--exact','--ignored','--nocapture','--test-threads=1']
            if index==2:
                child_env['DBUS_SESSION_BUS_ADDRESS']='unix:path=/tmp/gpui-no-session-bus'
            else:command=[dbus,'--',*command]
            with (out/(str(index)+'.log')).open('w') as output:
                result=subprocess.run(command,cwd=root,env=child_env,stdout=output,stderr=output,timeout=90)
            manifest['tests'].append({'name':name,'exit':result.returncode})
            assert result.returncode==0,(name,result.returncode)
    finally:
        display.terminate()
        try:display.wait(timeout=10)
        except subprocess.TimeoutExpired:display.kill();display.wait()
        manifest['binary_sha256_after']=sha(binary)
        (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
        assert manifest['binary_sha256_before']==manifest['binary_sha256_after']
