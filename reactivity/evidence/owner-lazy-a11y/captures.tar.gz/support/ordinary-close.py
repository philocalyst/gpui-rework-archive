"""Real public empty Window, provider publication, WM_DELETE_WINDOW. No timing."""
import ctypes,hashlib,json,os,pathlib,subprocess,time
cap=pathlib.Path('/tmp/gpui-a11y-owner-channel-captures')
artifact=json.loads((cap/'release-candidate/artifacts.json').read_text())[0]
binary=pathlib.Path(artifact['frozen_binary'])
out=cap/'ordinary-close';out.mkdir(exist_ok=True)
env=dict(os.environ,DISPLAY=':245',GSETTINGS_BACKEND='memory')
processes=[]
def wait(check):
 end=time.monotonic()+30
 while time.monotonic()<end:
  result=check()
  if result:return result
  time.sleep(.02)
 raise AssertionError('ordinary public window/provider readiness watchdog')
def bus(address,destination,path,interface,member,*args):
 result=subprocess.run(['busctl','--json=short','--address='+address,'call',destination,path,interface,member,*args],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
 return json.loads(result.stdout)['data'] if result.returncode==0 else None
with (out/'services.log').open('w') as log:
 try:
  processes.append(subprocess.Popen(['/nix/store/iw8dx6lhrkdc5wzszjzqzl677y68y88r-xvfb-21.1.24/bin/Xvfb',':245','-screen','0','1024x768x24','-nolisten','tcp'],stdout=log,stderr=log,env=env))
  wait(lambda:pathlib.Path('/tmp/.X11-unix/X245').exists())
  processes.append(subprocess.Popen(['/nix/store/4g39rajyrxqn3na1kd4pykdigsr82af5-at-spi2-core-2.60.6/libexec/at-spi-bus-launcher','--launch-immediately','--a11y=1'],stdout=log,stderr=log,env=env))
  session=os.environ['DBUS_SESSION_BUS_ADDRESS']
  address=wait(lambda:bus(session,'org.a11y.Bus','/org/a11y/bus','org.a11y.Bus','GetAddress'))[0]
  with (out/'application.log').open('w') as app_log:
   app=subprocess.Popen([str(binary),'--cpu'],stdout=app_log,stderr=app_log,env=env);processes.append(app)
   tool='/nix/store/qvckv6m6ycsa8f26w0f20mzk5w4v9ciq-xdotool-4.20260303.1/bin/xdotool'
   def mapped():
    result=subprocess.run([tool,'search','--onlyvisible','--pid',str(app.pid)],env=env,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,text=True)
    return int(result.stdout.splitlines()[0]) if result.returncode==0 else None
   window=wait(mapped)
   def provider():
    roots=bus(address,'org.a11y.atspi.Registry','/org/a11y/atspi/accessible/root','org.a11y.atspi.Accessible','GetChildren')
    if not roots:return None
    for name,path in roots[0]:
     children=bus(address,name,path,'org.a11y.atspi.Accessible','GetChildren')
     if children and children[0]:return children[0]
    return None
   published=wait(provider)
   class Message(ctypes.Structure):
    _fields_=[('kind',ctypes.c_int),('serial',ctypes.c_ulong),('send_event',ctypes.c_int),('display',ctypes.c_void_p),('window',ctypes.c_ulong),('message_type',ctypes.c_ulong),('format',ctypes.c_int),('data',ctypes.c_long*5)]
   class Event(ctypes.Union):_fields_=[('message',Message),('padding',ctypes.c_long*24)]
   x11=ctypes.CDLL('libX11.so.6')
   x11.XOpenDisplay.argtypes=[ctypes.c_char_p];x11.XOpenDisplay.restype=ctypes.c_void_p
   x11.XInternAtom.argtypes=[ctypes.c_void_p,ctypes.c_char_p,ctypes.c_int];x11.XInternAtom.restype=ctypes.c_ulong
   x11.XSendEvent.argtypes=[ctypes.c_void_p,ctypes.c_ulong,ctypes.c_int,ctypes.c_long,ctypes.POINTER(Event)]
   x11.XFlush.argtypes=[ctypes.c_void_p];x11.XCloseDisplay.argtypes=[ctypes.c_void_p]
   display=x11.XOpenDisplay(env['DISPLAY'].encode());assert display
   event=Event();event.message=Message(33,0,1,display,window,x11.XInternAtom(display,b'WM_PROTOCOLS',0),32,(ctypes.c_long*5)(x11.XInternAtom(display,b'WM_DELETE_WINDOW',0),0,0,0,0))
   assert x11.XSendEvent(display,window,0,0,ctypes.byref(event))
   x11.XFlush(display);x11.XCloseDisplay(display)
   result=app.wait(timeout=15);assert result==0,result
  assert 'panicked' not in (out/'application.log').read_text()
  (out/'result.json').write_text(json.dumps({'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'window':window,'published_provider_windows':published,'protocol':'WM_DELETE_WINDOW','exit':result},indent=2)+'\n')
 finally:
  for process in reversed(processes):
   if process.poll() is None:process.terminate()
  for process in reversed(processes):
   try:process.wait(timeout=10)
   except subprocess.TimeoutExpired:process.kill();process.wait()
