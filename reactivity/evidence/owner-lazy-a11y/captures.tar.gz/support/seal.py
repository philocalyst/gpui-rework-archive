"""Freeze source-qualified allocation/function controls; binaries stay external."""
import gzip,hashlib,json,pathlib,re,subprocess,tarfile
root=pathlib.Path('/tmp/gpui-a11y-owner-channel-sol')
cap=pathlib.Path('/tmp/gpui-a11y-owner-channel-captures')
out=root/'reactivity/evidence/owner-lazy-a11y';out.mkdir(parents=True,exist_ok=True)
def git(*args):return subprocess.check_output(['git','-C',str(root),*args])
def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def load(path):return json.loads((cap/path).read_text())
def ledger(path,marker):
 text=(cap/path).read_text();body=re.search(marker+r'.*?AllocationInfo \{([^}]+)\}',text)[1]
 return {k:int(v) for k,v in re.findall(r'(\w+): (\d+)',body)}
def types(path):
 text=(cap/path).read_text();names=['gpui::native::NativeHost<Empty>','gpui::Window<Empty>','gpui::Win<Empty>',
 'std::option::Option<gpui::Win<Empty>>','gpui::native::accessibility::Bridge','std::option::Option<gpui::native::accessibility::Bridge>',
 'gpui::native::accessibility::Shared','gpui::native::accessibility::Queued','gpui::native::accessibility::text::Cohort']
 return {name:int(re.search('type: `'+re.escape(name)+r'`: (\d+) bytes',text)[1]) for name in names}
base=load('release-baseline/empty.elf.json');final=load('release-candidate/empty.elf.json')
summary={
 'shipping':git('rev-parse','157b995e7e').decode().strip(),
 'tests':git('rev-parse','112c27e728').decode().strip(),
 'base':git('rev-parse','7a5e1619a2').decode().strip(),
 'intermediate_queue_only_shipping':git('rev-parse','b2440d0745').decode().strip(),
 'intermediate_tests':git('rev-parse','aa47c1e7d1').decode().strip(),
 'scope':'Owner-lazy native action transport and exact cohort authority, no public API/dependency/vendor/unsafe changes.',
 'core_lines':{'baseline':load('base-core.json')['core_non_test_code_lines'],'candidate':load('157-core.json')['core_non_test_code_lines']},
 'gates':{
  'default_alltargets':{'passed':534,'ignored':10,'harnesses':71,'tests_source':'f180681fbdf4322c0cfc214ca75e2001f31dec01'},
  'native_library':{'passed':215,'ignored':26,'tests_source':'f180681fbdf4322c0cfc214ca75e2001f31dec01'},
  'final_accessibility':{'passed':54,'ignored':6,'tests_source':git('rev-parse','69b442fa3b').decode().strip()},
  'native_alltargets_strict':'PASS including final test-only ABA addition',
  'apple_native_library':'PASS','msvc_native_library':'PASS',
  'native_private_registry_clients':load('native-157/manifest.json'),
  'native_real_registry':load('registry-157-corrected/result.json'),
  'public_ordinary_wm_close':load('ordinary-close/result.json'),
  'actual_failed_L_old_P_public_repair':load('native-failure-third/registry/result.json')},
 'cross_actual_flags':{t:load(t+'-fingerprints.json') for t in ['aarch64-apple-darwin','x86_64-pc-windows-msvc']},
 'production_layouts':{'baseline':types('production-consumer-layout-baseline.txt'),'candidate':types('production-consumer-layout-candidate.txt')},
 'cfgtest_owner_allocations_original_paths':{label:ledger('debug-'+label+'/owner.log','COLD_WHOLE_OWNER') for label in ['baseline','candidate']},
 'cfgtest_owner_allocations_same_execution_path':{label:ledger('runtime-fixed-'+label+'/owner.log','COLD_WHOLE_OWNER') for label in ['baseline','candidate']},
 'installed_transport':{label:ledger('debug-'+label+'/carriers.log','INSTALLED_TRANSPORT') for label in ['baseline','candidate']},
 'sections':{'baseline':base['sections'],'candidate':final['sections'],'delta':{k:final['sections'][k]-v for k,v in base['sections'].items()}},
 'dispatch_clock_calls':{'baseline':len(base['instant_now_calls']),'candidate':len(final['instant_now_calls'])},
 'costs_and_limits':[
  'NativeHost method frames unchanged; Bridge drain1416→1432 even on unpublished WorkReady; constructor200→136.',
  'Factory borrowed capture80→96B; active update closure312code/frame184; first-init helper73/frame40 plus closure170/frame88, no summed peak claim.',
  'Linked text−96B, rodata+128B, data.rel.ro+200B; total those sections+232B.',
  'No AT cold transport4224B/twoalloc removed; installed transport512B smaller; whole opening peak90734B unchanged in matched cfgtest fixture.',
  'No timing, RSS, process memory, hardware/foreign runtime or aggregate stack high-water claim.',
  'TestBridge208 contains32B cfgtest counters. Production Bridge176. TestTodos model and nested instrumentation affect its Host/Window sizes.',
  'SourceTween74 remains frozen and unadopted; no animation/schema/keyed-row foundation changes included.']}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
source='reactivity/crates/gpui/src/native/accessibility.rs'
(out/'shipping.patch').write_bytes(git('diff','7a5e1619a2','157b995e7e','--',source))
tests=['reactivity/crates/gpui/src/native/accessibility/'+name for name in ['tests.rs','selection_tests.rs','linux_tests.rs','linux_tests/failure.rs']]
(out/'tests.patch').write_bytes(git('diff','7a5e1619a2','112c27e728','--',*tests))
(out/'authority.md').write_bytes((cap/'support/authority.md').read_bytes())
(out/'codegen-diff.json').write_bytes((cap/'codegen-diff.json').read_bytes())
for label,data in [('baseline',base),('candidate',final)]:
 (cap/f'release-{label}/gpui-frames.json').write_text(json.dumps(data['all_gpui_frames'],indent=2)+'\n')
manifest=[];archive=[]
for p in sorted(cap.rglob('*')):
 if not p.is_file() or '__pycache__' in p.parts or p.name in ('seal.log','draft.md'):continue
 relative=p.relative_to(cap).as_posix()
 with p.open('rb') as f:elf=f.read(4)==b'\x7fELF'
 include=not elf and not relative.endswith('.elf.json')
 manifest.append({'path':relative,'bytes':p.stat().st_size,'sha256':digest(p),'archived':include})
 if include:archive.append(p)
(out/'capture-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with (out/'captures.tar.gz').open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as zipped:
  with tarfile.open(fileobj=zipped,mode='w') as tar:
   for p in archive:tar.add(p,arcname=p.relative_to(cap).as_posix(),recursive=False)
print('archive',out,'bytes',(out/'captures.tar.gz').stat().st_size,'files',len(archive),'external',sum(not m['archived'] for m in manifest))
