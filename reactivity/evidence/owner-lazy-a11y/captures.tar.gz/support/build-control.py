"""One matched NONSHIPPING control build; no automatic queued next stage."""
import hashlib,json,os,pathlib,shutil,subprocess,sys
label,kind=sys.argv[1:]
assert label in ('baseline','candidate') and kind in ('debug','release')
root=pathlib.Path('/tmp/gpui-a11y-owner-channel-control-sol')
cap=pathlib.Path('/tmp/gpui-a11y-owner-channel-captures')
out=cap/(kind+'-'+label);out.mkdir(exist_ok=True)
assert not os.environ.get('RUSTFLAGS') and not os.environ.get('CARGO_ENCODED_RUSTFLAGS')
assert os.environ['CARGO_TARGET_DIR']=='/tmp/gpui-a11y-owner-channel-target'
assert os.environ['CARGO_BUILD_JOBS']=='1'
assert not subprocess.check_output(['git','-C',str(root),'status','--porcelain'])
source='7a5e1619a2' if label=='baseline' else '157b995e7e'
relative='reactivity/crates/gpui/src/native/accessibility.rs'
assert (root/relative).read_bytes()==subprocess.check_output(['git','-C',str(root),'show',source+':'+relative])
fixture={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in [
 'reactivity/crates/gpui/examples/empty.rs',
 'reactivity/crates/gpui/examples/support/renderer.rs',
 'reactivity/crates/gpui/src/native/accessibility/linux_tests.rs',
 'reactivity/crates/gpui/src/native/accessibility/selection_tests.rs',
 '.cargo/config.toml','reactivity/Cargo.toml','reactivity/Cargo.lock']}
(out/'fixture.json').write_text(json.dumps(fixture,indent=2)+'\n')
python=sys.executable
with (out/'guard-before.json').open('w') as log:
 subprocess.run([python,str(cap/'support/guard.py'),str(root)],stdout=log,check=True)
(out/'rustc.txt').write_bytes(subprocess.check_output(['rustc','-Vv']))
command=['cargo','test','--offline','--locked','-p','gpui','--features','x11','--lib','--no-run','--message-format=json']
if kind=='release':
 with (out/'clean.log').open('w') as log:
  subprocess.run(['cargo','clean','-p','gpui','--release'],cwd=root/'reactivity',stdout=log,stderr=log,check=True)
 command=['cargo','build','--offline','--locked','-p','gpui','--features','x11','--release','--config',str(cap/'support/stack-metadata.toml'),'--example','empty','--message-format=json']
(out/'command.json').write_text(json.dumps(command)+'\n')
with (out/'cargo.jsonl').open('w') as log,(out/'cargo.log').open('w') as errors:
 subprocess.run(command,cwd=root/'reactivity',stdout=log,stderr=errors,check=True)
artifacts=[]
for line in (out/'cargo.jsonl').read_text().splitlines():
 row=json.loads(line)
 if row.get('reason')=='compiler-artifact' and row.get('executable'):
  assert not row['fresh'],row
  path=pathlib.Path(row['executable']);dest=out/path.name
  shutil.copy2(path,dest);row['frozen_binary']=str(dest)
  row['sha256']=hashlib.sha256(dest.read_bytes()).hexdigest();artifacts.append(row)
assert len(artifacts)==1,artifacts
(out/'artifacts.json').write_text(json.dumps(artifacts,indent=2)+'\n')
profile=pathlib.Path(os.environ['CARGO_TARGET_DIR'])/kind
fingerprints=out/'fingerprints';fingerprints.mkdir(exist_ok=True)
for path in profile.glob('.fingerprint/gpui-*/*.json'):
 shutil.copy2(path,fingerprints/(path.parent.name+'-'+path.name))
with (out/'guard-after.json').open('w') as log:
 subprocess.run([python,str(cap/'support/guard.py'),str(root)],stdout=log,check=True)
assert (out/'guard-before.json').read_bytes()==(out/'guard-after.json').read_bytes()
(out/'status').write_text('0\n')
