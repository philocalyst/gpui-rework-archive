"""Read frozen static call/frame evidence; not a stack-peak measurement."""
import json,pathlib,re,struct,subprocess,sys
binary=pathlib.Path(sys.argv[1]);report=json.loads(binary.with_suffix('.elf.json').read_text())
data=binary.read_bytes();head=struct.unpack_from('<16sHHIQQQIHHHHHH',data)
sections=[struct.unpack_from('<IIQQQQIIQQ',data,head[6]+i*head[11]) for i in range(head[12])]
s=sections[head[13]];strings=data[s[4]:s[4]+s[5]]
byname={strings[s[0]:strings.index(0,s[0])].decode():s for s in sections};relocations={}
s=byname.get('.rela.dyn')
if s:
 for offset in range(s[4],s[4]+s[5],s[9]):
  address,info,addend=struct.unpack_from('<QQq',data,offset)
  if info&0xffffffff==8:relocations[address]=addend
symbols={s['address']:s['normalized_name'] for s in report['symbols']}
def selected(n):
 return (n.startswith('<gpui::native::NativeHost<empty::Empty>') or
  n.startswith('<gpui::native::accessibility::Bridge>') or
  n.startswith('<gpui::native::accessibility::Ingress>') or
  n.startswith('<gpui::native::accessibility::Ingress as ') or
  n.startswith('<accesskit_winit::Adapter>::with_direct_handlers') or
  n.startswith('std::sync::mpmc::sync_channel::<gpui::native::accessibility::Queued>') or
  'OnceLock<std::sync::mpmc::Sender<gpui::native::accessibility::Queued>>' in n or
  n.startswith('gpui::native::run_window') or n=='empty::main')
rows=[];dumps=[];objdump='/nix/store/ddk8rvjihg4vhh1k6x9rc65y1zb1kx34-binutils-2.46/bin/objdump'
for f in report['all_frames']:
 if not selected(f['normalized_name']):continue
 start=f['address'];stop=start+f['code_bytes']
 assembly=subprocess.check_output([objdump,'-d','--no-show-raw-insn','--demangle=rust',f'--start-address={start}',f'--stop-address={stop}',str(binary)],text=True)
 calls=[]
 for line in assembly.splitlines():
  if not re.search(r'\bcall\b',line):continue
  target=re.search(r'# ([0-9a-f]+)',line)
  name=symbols.get(relocations.get(int(target[1],16))) if target else None
  calls.append({'instruction':line.strip(),'resolved_got':name})
 rows.append({**f,'calls':calls});dumps.append(assembly)
binary.with_suffix('.startup.asm').write_text('\n'.join(dumps))
binary.with_suffix('.startup.json').write_text(json.dumps({'sections':report['sections'],'functions':rows,'limits':'Static compiler frame sizes and instructions; not aggregate stack high-water or timing.'},indent=2)+'\n')
for f in rows:
 print(f['code_bytes'],f['stack_bytes'],f['normalized_name'])
