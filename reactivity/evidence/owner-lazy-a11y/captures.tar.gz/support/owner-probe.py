"""NONSHIPPING owner-thread allocations, not timing or process/RSS accounting."""
import json,os,pathlib,subprocess,sys,time
label=sys.argv[1];assert label in ('baseline','candidate')
cap=pathlib.Path('/tmp/gpui-a11y-owner-channel-captures')
out=cap/('debug-'+label)
binary=json.loads((out/'artifacts.json').read_text())[0]['frozen_binary']
env=dict(os.environ,DISPLAY=':243',DBUS_SESSION_BUS_ADDRESS='unix:path=/tmp/gpui-no-session-bus')
with (out/'xvfb.log').open('w') as output:
 display=subprocess.Popen(['/nix/store/iw8dx6lhrkdc5wzszjzqzl677y68y88r-xvfb-21.1.24/bin/Xvfb',':243','-screen','0','1024x768x24','-nolisten','tcp'],stdout=output,stderr=output,env=env)
 try:
  for _ in range(100):
   if pathlib.Path('/tmp/.X11-unix/X243').exists():break
   assert display.poll() is None
   time.sleep(.05)
  assert pathlib.Path('/tmp/.X11-unix/X243').exists()
  cases=[('carriers','native::accessibility::selection_tests::owner_carrier_layouts_and_transport_allocation',False),
         ('owner','native::accessibility::linux_tests::native_accessible_profile_without_session_bus_still_presents',True)]
  for name,case,ignored in cases:
   command=[binary,case,'--exact','--nocapture','--test-threads=1']
   if ignored:command.append('--ignored')
   with (out/(name+'.log')).open('w') as log:
    result=subprocess.run(command,env=env,stdout=log,stderr=log,timeout=90)
   assert result.returncode==0,(name,result.returncode)
 finally:
  display.terminate()
  try:display.wait(timeout=10)
  except subprocess.TimeoutExpired:display.kill();display.wait()
