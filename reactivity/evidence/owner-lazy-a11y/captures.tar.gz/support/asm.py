import importlib.util,json,pathlib,re,struct,subprocess,sys
helper=pathlib.Path(__file__).with_name('elf.py');spec=importlib.util.spec_from_file_location('elf_probe',helper);elf=importlib.util.module_from_spec(spec);spec.loader.exec_module(elf)
for argument in sys.argv[1:]:
 path=pathlib.Path(argument);result=elf.inspect(path);data=path.read_bytes();header=struct.unpack_from('<16sHHIQQQIHHHHHH',data)
 sections=[struct.unpack_from('<IIQQQQIIQQ',data,header[6]+i*header[11]) for i in range(header[12])]
 table=sections[header[13]];names=data[table[4]:table[4]+table[5]]
 section_by_name={names[s[0]:names.index(0,s[0])].decode():s for s in sections};relocations={}
 if '.rela.dyn' in section_by_name:
  section=section_by_name['.rela.dyn']
  for offset in range(section[4],section[4]+section[5],section[9]):
   address,info,addend=struct.unpack_from('<QQq',data,offset)
   if info&0xffffffff==8:relocations[address]=addend
 symbol_names={f['address']:f['normalized_name'] for f in result['symbols']}
 disassemblies=[];calls=[]
 for function in result['selected']:
  if 'NativeHost' not in function['normalized_name'] or 'dispatch' not in function['normalized_name']:continue
  start=function['address'];stop=start+function['code_bytes']
  assembly=subprocess.check_output([elf.BIN+'objdump','-d','--no-show-raw-insn','--demangle=rust',f'--start-address={start}',f'--stop-address={stop}',str(path)],text=True)
  disassemblies.append(assembly)
  for line in assembly.splitlines():
   if not re.search(r'\bcall\b',line):continue
   target=re.search(r'# ([0-9a-f]+)',line)
   name=symbol_names.get(relocations.get(int(target[1],16))) if target else None
   calls.append({'caller':function['normalized_name'],'instruction':line.strip(),'resolved_relative_got':name})
 path.with_suffix('.dispatch.asm').write_text('\n'.join(disassemblies))
 result['dispatch_calls']=calls
 result['instant_now_calls']=[c for c in calls if re.search(r'Instant.*::now', (c['resolved_relative_got'] or '')+' '+c['instruction'])]
 path.with_suffix('.elf.json').write_text(json.dumps(result,indent=2)+'\n')
 print(path,result['sections'],'dispatch clock calls',len(result['instant_now_calls']))
