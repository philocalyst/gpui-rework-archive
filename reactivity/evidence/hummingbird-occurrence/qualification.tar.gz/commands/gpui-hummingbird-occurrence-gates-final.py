from pathlib import Path
import hashlib,json,os,re,subprocess,time
root=Path('/root/gpui-ce3');app=root/'reactivity/ports/hummingbird'
out=Path('/tmp/gpui-hummingbird-occurrence-gates-final');out.mkdir(exist_ok=False)
git=['git','-c','safe.directory=/root/gpui-ce3','-C',str(root)]
paths=[root/os.fsdecode(p) for p in subprocess.check_output(git+['ls-files','-z','reactivity','.cargo']).split(b'\0') if p]
paths=[p for p in paths if p.is_file() and p.suffix in {'.rs','.toml','.lock','.wgsl'} and '/evidence/' not in str(p) and '/benchmarks/' not in str(p)]
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def inputs():return {str(p.relative_to(root)):digest(p) for p in paths}
guard=inputs();(out/'inputs.json').write_text(json.dumps(guard,indent=2)+'\n')
assert os.environ.get('RUSTFLAGS') is None and os.environ.get('CARGO_ENCODED_RUSTFLAGS') is None
assert digest(root/'.cargo/config.toml')=='46b48c4505d0c06d229d14f1a819ea294ce2e81ed2c870aefae812dd9e36d295'
commands=[
 ('default',['cargo','test','--offline','--locked','--all-targets','--message-format=json']),
 ('native',['cargo','test','--offline','--locked','--all-targets','--features','native','--message-format=json']),
 ('strict-default',['cargo','clippy','--offline','--locked','--all-targets','--','-D','warnings']),
 ('strict-native',['cargo','clippy','--offline','--locked','--all-targets','--features','native','--','-D','warnings']),
 ('headless',['cargo','run','--offline','--locked','--','--headless']),
 ('format',['rustfmt','--check','--edition','2024','src/queue_playback.rs','tests/queue_playback.rs'])]
report={'base':subprocess.check_output(git+['rev-parse','HEAD'],text=True).strip(),'guard_scope':'tracked Rust/TOML/lock/WGSL under reactivity and .cargo, excluding evidence/benchmarks; not a complete external build-input inventory','guard_count':len(guard),'rustflags_environment':None,'build_jobs':os.environ['CARGO_BUILD_JOBS'],'commands':[]}
(out/'source.patch').write_bytes(subprocess.check_output(git+['diff','--','reactivity/ports/hummingbird/src/queue_playback.rs','reactivity/ports/hummingbird/tests/queue_playback.rs']))
(out/'rustc.txt').write_bytes(subprocess.check_output(['rustc','-Vv']))
for name,cmd in commands:
    assert inputs()==guard,'input changed before '+name
    started=time.monotonic()
    with (out/(name+'.log')).open('wb') as log:
        result=subprocess.run(cmd,cwd=app,stdout=log,stderr=subprocess.STDOUT,timeout=1800)
    raw=(out/(name+'.log')).read_text()
    row={'name':name,'command':cmd,'returncode':result.returncode,'workflow_seconds':round(time.monotonic()-started,3)}
    if name in {'default','native'}:
        groups=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',raw)
        row['result_groups']=len(groups);row['passed']=sum(int(x[0]) for x in groups);row['ignored']=sum(int(x[2]) for x in groups)
        assert row['passed']==35 and row['ignored']==0,row
        artifacts=[]
        for line in raw.splitlines():
            if line.startswith('{'):
                try:r=json.loads(line)
                except json.JSONDecodeError:continue
                if r.get('reason')=='compiler-artifact':artifacts.append(r)
        (out/(name+'-artifacts.json')).write_text(json.dumps(artifacts,indent=2)+'\n')
    report['commands'].append(row)
    (out/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
    assert result.returncode==0,row
    assert inputs()==guard,'input changed after '+name
    print(json.dumps(row),flush=True)
report['final_inputs_match']=True
(out/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
