from pathlib import Path
import sys,subprocess,tempfile,json,hashlib
root=Path('/root/gpui-ce3');sys.path.insert(0,str(root/'reactivity/tools'))
import inventory,core_lines
helper=root/'reactivity/tools/inventory-rust/target/release/inventory-rust'
tokei=Path('/nix/store/4m90mv0fyihsdrnidw8gkgmx6zvd5vqm-tokei-15.0.0/bin/tokei')
git=['git','-c','safe.directory=/root/gpui-ce3','-C',str(root)]
paths=[p.decode() for p in subprocess.check_output(git+['ls-tree','-rz','--name-only','91d2aac60ded476aa3f3bbfc00ae4a6cc0cc8787','reactivity/ports/hummingbird/src']).split(b'\0') if p.endswith(b'.rs')]
def count(baseline):
    rows=[(p,subprocess.check_output(git+['show','91d2aac60ded476aa3f3bbfc00ae4a6cc0cc8787:'+p]) if baseline else (root/p).read_bytes(),'Rust') for p in paths]
    parsed=inventory.rust_analysis(rows,helper);files={}
    with tempfile.TemporaryDirectory(prefix='hb-occurrence-lines-') as d:
        stage=Path(d)
        for p,data,_ in rows:
            part=parsed[p];dest=stage/p;dest.parent.mkdir(parents=True,exist_ok=True)
            dest.write_text(core_lines.without_tests(data.decode(),part['test_ranges']))
            files[p]={'sha256':hashlib.sha256(data).hexdigest(),'unclassified':part.get('unclassified',[])}
        stats=json.loads(subprocess.check_output([str(tokei),'--no-ignore','--files','--output','json',str(stage)],text=True))
        for item in stats['Rust']['reports']:
            p=Path(item['name']).relative_to(stage).as_posix();files[p]['code_lines']=item['stats']['code']
    return {'application_non_test_code_lines':sum(v['code_lines'] for v in files.values()),'files':files}
result={'scope':'Compiled Hummingbird application src, all feature branches, excluding tests/comments/blanks/docs; outside the six core libraries','baseline':count(True),'candidate':count(False),'core':'No core library source changed; qualified 8c17 count remains30,599','helper_sha256':hashlib.sha256(helper.read_bytes()).hexdigest(),'tokei_sha256':hashlib.sha256(tokei.read_bytes()).hexdigest()}
Path('/tmp/gpui-hummingbird-occurrence-count.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k]['application_non_test_code_lines'] for k in ['baseline','candidate']}))
