from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path('/root/gpui-ce3')
app=root/'reactivity/ports/hummingbird'
out=Path('/tmp/gpui-hummingbird-occurrence-control')
out.mkdir(exist_ok=False)
source=app/'src/queue_playback.rs'
tests=app/'tests/queue_playback.rs'
git=['git','-c','safe.directory=/root/gpui-ce3','-C',str(root)]
candidate=source.read_bytes()
baseline=subprocess.check_output(git+['show','91d2aac60ded476aa3f3bbfc00ae4a6cc0cc8787:reactivity/ports/hummingbird/src/queue_playback.rs'])
(out/'candidate.rs').write_bytes(candidate)
(out/'baseline.rs').write_bytes(baseline)
(out/'public-tests.rs').write_bytes(tests.read_bytes())
(out/'source.patch').write_bytes(subprocess.check_output(git+['diff','--','reactivity/ports/hummingbird/src/queue_playback.rs','reactivity/ports/hummingbird/tests/queue_playback.rs']))
(out/'rustc.txt').write_bytes(subprocess.check_output(['rustc','-Vv']))
paths=subprocess.check_output(git+['ls-files','-z','reactivity',' .cargo']).split(b'\0')
inputs=[root/os.fsdecode(p) for p in paths if p and Path(os.fsdecode(p)).suffix in {'.rs','.toml','.lock','.wgsl'} and b'/evidence/' not in p and b'/benchmarks/' not in p]
inputs.append(root/'.cargo/config.toml')
def hashes():return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs if p.is_file()}
guard=hashes()
(out/'candidate-inputs.json').write_text(json.dumps(guard,indent=2)+'\n')
result=None
try:
    source.write_bytes(baseline)
    with (out/'baseline.log').open('wb') as log:
        result=subprocess.run(['cargo','test','--offline','--locked','--test','queue_playback','--','--nocapture'],cwd=app,stdout=log,stderr=subprocess.STDOUT,timeout=300)
finally:
    assert source.read_bytes()==baseline,'baseline source changed during control'
    source.write_bytes(candidate)
    assert hashes()==guard,'candidate input restore mismatch'
raw=(out/'baseline.log').read_text()
assert result is not None and result.returncode==101,(result.returncode if result else None)
assert '7 passed; 2 failed' in raw,raw[-1500:]
for name in ['queued_eos_survives_lookahead_edits_and_uses_the_latest_live_successor','repeat_shuffle_and_keep_current_clear_preserve_a_queued_eos']:
    assert f'test {name} ... FAILED' in raw,name
summary={'baseline_pin':'91d2aac60ded476aa3f3bbfc00ae4a6cc0cc8787','baseline_returncode':result.returncode,'expected_failures':2,'other_public_cases_passed':7,'restored_input_guards':len(guard),'source_sha256':hashlib.sha256(candidate).hexdigest(),'baseline_source_sha256':hashlib.sha256(baseline).hexdigest(),'tests_sha256':hashlib.sha256(tests.read_bytes()).hexdigest(),'limits':'Behavior regression control only, no native/decoder/timing/RSS claim.'}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))
