from pathlib import Path
r=Path('/root/gpui-boolean-cohort-sol-20261024/reactivity/crates/gpui/src/native')
p=r/'accessibility/linux_tests.rs';s=p.read_text().replace('mod checkbox;','mod checkbox;\nmod invalid;',1);p.write_text(s)
p=r/'accessibility/linux_tests/checkbox.rs';s=p.read_text().replace('checkbox proof','input validation proof').replace('Keep this preference','Validation input').replace('CHECK_TITLE','VALIDATION_TITLE').replace('CHECK_NAME','VALIDATION_NAME')
a=s.index('#[derive(Default)]');b=s.index('async fn checked(',a)
s=s[:a]+'''struct Check { invalid:crate::Signal<bool>,value:crate::Signal<String> }
impl Default for Check {fn default()->Self {Self {invalid:crate::Signal::new(false),value:crate::Signal::new("Draft".into())}}}
impl Check {
    const INVALID:crate::Source<Self,bool>=crate::Source::new(crate::FieldId::new(1),"invalid",|m|&m.invalid,|m|&mut m.invalid);
    const VALUE:crate::Source<Self,String>=crate::Source::new(crate::FieldId::new(2),"value",|m|&m.value,|m|&mut m.value);
}
impl View for Check {
    fn sources()->crate::Sources<Self> {crate::Sources::new().direct(Self::INVALID).direct(Self::VALUE)}
    fn view(&self)->crate::El<'_> {
        use crate::BoolInput;
        let binding=crate::BoolBinding::new(&self.invalid);let state=binding.state();
        binding.attach(crate::column((
            crate::div().bg(state.select(crate::Color::BLACK,crate::Color::WHITE)).p(1)
                .child(crate::text_input(&self.value).name(VALIDATION_NAME).invalid(state).w(220).h(32)),
            crate::button("Toggle validation").w(220).h(32).on_click(Self::INVALID.update(|v|*v=!*v)),
        )))
    }
}
''' +s[b:]
s=s.replace('async fn checked(','async fn invalid(').replace('// AT-SPI State::Checked is bit4 in the protocol\'s two-word state set.','// AT-SPI InvalidEntry is bit36 in the protocol\'s two-word state set.').replace('Ok(states[0] & (1 << 4) != 0)','Ok(states[1] & (1 << 4) != 0)')
s=s.replace('    let node = named(&session, vec![window], VALIDATION_NAME)','    let command=named(&session,vec![window.clone()],"Toggle validation").await.ok_or("validation command missing")?;\n    let node = named(&session, vec![window], VALIDATION_NAME)')
s=s.replace('    // AT-SPI Role::CheckBox is protocol value7.\n    assert_eq!(accessible.call::<_, _, u32>("GetRole", &()).await?, 7);','    let interfaces:Vec<String>=accessible.call("GetInterfaces",&()).await?;\n    assert!(interfaces.iter().any(|name|name=="org.a11y.atspi.EditableText"));')
s=s.replace('checked(&session','invalid(&session').replace('proxy(&session, &node, "org.a11y.atspi.Action")','proxy(&session, &command, "org.a11y.atspi.Action")').replace('if kind == "checked"','if kind == "invalid-entry"').replace('GPUI_NATIVE_CHECKBOX role=7 action=DoAction(0) checked={expected} StateChanged:checked={}','GPUI_NATIVE_INVALID input=EditableText action=DoAction(0) invalid={expected} StateChanged:invalid-entry={}')
s=s.replace('            assert_eq!(owner.root().unwrap().calls, 2);\n            assert!(!owner.root().unwrap().checked);','            assert!(!*owner.root().unwrap().invalid);')
s=s.replace('                    assert_eq!(part.role(), Role::CheckBox);\n                    assert_eq!(part.checked(), Some(false));','                    if part.role()==Role::TextInput { assert!(!part.invalid()); assert!(!part.disabled()); }')
s=s.replace('native_atspi_checkbox_action_state_and_events','native_atspi_invalid_input_state_and_events').replace('checkbox native deadline','input validation native deadline').replace('actual checkbox AT-SPI client failed','actual invalid-input AT-SPI client failed')
(r/'accessibility/linux_tests/invalid.rs').write_text(s)
p=r/'accessibility.rs';s=p.read_text().replace('mod geometry_tests;','mod geometry_tests;\n#[cfg(test)]\nmod invalid_tests;',1);p.write_text(s)
