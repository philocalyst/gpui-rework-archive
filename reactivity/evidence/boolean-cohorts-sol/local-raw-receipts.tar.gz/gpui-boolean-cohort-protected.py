from pathlib import Path
import json,hashlib,subprocess,tomllib
root=Path('/root/gpui-boolean-cohort-sol-20261024');base='957cf9d0865e9fd30a7e3d4ba4dea2e8aa97221c'
protected=set(json.loads(Path('/tmp/gpui-component-review-protected-closure.json').read_text())['files_byte_identical'])
protected.update(['reactivity/crates/gpui/Cargo.toml','reactivity/crates/gpui/src/remote.rs','reactivity/crates/gpui/tests/inbox_storage.rs','reactivity/ports/hummingbird/Cargo.lock'])
protected.update(n for n in subprocess.check_output(['git','-C',str(root),'ls-tree','-r','--name-only',base,'reactivity/crates/ownership-lab'],text=True).splitlines())
records={}
for name in sorted(protected):
 expected=subprocess.check_output(['git','-C',str(root),'show',base+':'+name]);actual=(root/name).read_bytes();assert actual==expected,name
 records[name]=hashlib.sha256(actual).hexdigest()
lock=tomllib.loads((root/'reactivity/Cargo.lock').read_text());pkgs={x['name']:x for x in lock['package'] if x['name'] in ['gpui','gpui-component']}
assert 'parking_lot' in pkgs['gpui']['dependencies'];assert pkgs['gpui-component']['dependencies']==['allocation-counter','gpui']
Path('/tmp/gpui-boolean-cohort-protected.json').write_text(json.dumps(dict(parent=base,files_byte_identical=records,lock_edges=pkgs),indent=2)+'\n')
print('protected exact files',len(records),'both lock edges retained')
