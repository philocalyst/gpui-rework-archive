from pathlib import Path
r=Path('/root/gpui-boolean-cohort-sol-20261024/reactivity/crates')
p=r/'gpui/src/style_port.rs';s=p.read_text().replace('            Self::Deferred(_) => unreachable!("boolean bindings resolved before scalar admission"),\n','');p.write_text(s)
p=r/'component/tests/boolean_cohorts.rs';s=p.read_text().replace('    ack(&mut w);\n    assert!(!invalid(&w, input));\n}', '    ack(&mut w);\n    let repaired=w.query().name("Title").one().unwrap();\n    assert_ne!(repaired,input,"recovery retires the invalid logical incarnation");\n    assert!(!invalid(&w, repaired));\n}',1);p.write_text(s)
