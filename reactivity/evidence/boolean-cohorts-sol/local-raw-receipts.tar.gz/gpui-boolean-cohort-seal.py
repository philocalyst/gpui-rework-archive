from pathlib import Path
import hashlib,json,shutil,tarfile
work=Path('/root/gpui-boolean-cohort-sol-20261024');out=work/'reactivity/evidence/boolean-cohorts-sol';out.mkdir(exist_ok=True)
files=sorted(p for p in Path('/tmp').glob('gpui-boolean-cohort-*') if p.is_file() and p.suffix in ('.log','.json','.jsonl','.py','.txt','.png'))
with tarfile.open(out/'local-raw-receipts.tar.gz','w:gz') as archive:
 for p in files:archive.add(p,arcname=p.name)
for name in ['inventory.json','protected.json','costs-10.log','party-costs-10.log','codegen.json','native-capture.json','native-capture-11.log','mutant-run.log']:
 p=Path('/tmp/gpui-boolean-cohort-'+name)
 if p.exists():shutil.copy2(p,out/name)
for name in ['before-11.json','after-11.json','after-12.json']:
 p=Path('/tmp/gpui-boolean-cohort-'+name)
 if p.exists():shutil.copy2(p,out/name)
for p in Path('/tmp').glob('gpui-boolean-cohort-halloween-native-*.png'):shutil.copy2(p,out/p.name.replace('gpui-boolean-cohort-',''))
a=Path('/root/gpui-boolean-cohort-sol-artifacts-20261024');manifests={}
for p in sorted(a.glob('*/manifest.json')):
 records=json.loads(p.read_text());
 for record in records:
  q=Path(record['frozen']);assert q.exists() and hashlib.sha256(q.read_bytes()).hexdigest()==record['sha256']
 manifests[str(p.parent)]=records
(out/'actual-frozen-executables.json').write_text(json.dumps(manifests,indent=2)+'\n')
for d in ['public-layout','public-layout-baseline']:
 p=Path('/tmp/gpui-boolean-cohort-'+d)
 if p.exists():shutil.copytree(p,out/d,dirs_exist_ok=True)
(out/'local-raw-receipts.sha256').write_text(hashlib.sha256((out/'local-raw-receipts.tar.gz').read_bytes()).hexdigest()+'  local-raw-receipts.tar.gz\n')
print(len(files),sum(p.stat().st_size for p in files),out)
