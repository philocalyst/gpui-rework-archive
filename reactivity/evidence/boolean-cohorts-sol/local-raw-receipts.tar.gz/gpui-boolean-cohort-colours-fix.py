from pathlib import Path
r=Path('/root/gpui-boolean-cohort-sol-20261024/reactivity/crates/gpui/src')
p=r/'runtime/styles/colours.rs';s=p.read_text().replace('    ports: Vec<Binding>,','    ports: Vec<Binding>,\n    has_selectors: bool,',1).replace('        self.bank.literal(color).0','        self.has_selectors = true;\n        self.bank.literal(color).0',1).replace('        self.bank.sources.is_empty()','        self.bank.sources.is_empty() && !self.has_selectors',1)
a=s.index('    pub(in crate::runtime) fn retain_standalone(');b=s.index('    pub(in crate::runtime) fn capture(',a);s=s[:a]+s[b:]
a=s.index('    pub(in crate::runtime) fn contribution(',s.index('impl Bound {'))
s=s[:a]+'''    pub(in crate::runtime) fn select_color(&mut self,index:usize,id:crate::property::PropertyId,code:u32,explicit:bool,count:usize) {
        use crate::property::PropertyId;
        assert!(code<SOURCE);
        let mut record=self.records.get(index);
        let old=record.effective;
        if id==PropertyId::Foreground {
            record.declared.fg=Slot(code);
            if !explicit {record.effective.fg=Slot(code);}
        } else {
            assert_eq!(id,PropertyId::Background);
            record.declared.bg=Slot(code);
            if !explicit {record.effective.bg=Slot(code);}
        }
        self.bank.change_users(old,record.effective);
        self.records.set(index,record,count);
    }
''' +s[a:];p.write_text(s)
p=r/'runtime/styles.rs';s=p.read_text().replace('    pub(super) fn color_contribution(','''    pub(super) fn select_color(&mut self,index:usize,id:crate::property::PropertyId,code:u32,explicit:bool,count:usize) {
        let Self::Colors(values)=self else {unreachable!("selected palette owns color bank")};
        values.select_color(index,id,code,explicit,count);
    }
    pub(super) fn color_contribution(''',1);p.write_text(s)
p=r/'runtime.rs';s=p.read_text()
a=s.index('        for group in boolean_groups {');b=s.index('        for (&field, ports) in &mut fanout {',a);block=s[a:b];s=s[:a]+s[b:]
a=s.index('        for draft in mapped_ports {');s=s[:a]+block+s[a:]
s=s.replace('if !matches!(fanout.get(&field), Some(Fanout::Mapped(_)))','if !matches!(fanout.get(&field), Some(Fanout::Mapped(_) | Fanout::Boolean(_)))',1)
s=s.replace('if let Fanout::Mapped(mapped) = entry {\n                    mapped.codec = draft.signal.codec();\n                }','match entry.plain_mut() {\n                    Fanout::Mapped(mapped)=>mapped.codec=draft.signal.codec(),\n                    Fanout::General {codec,..}=>*codec=draft.signal.codec(),\n                    _=>unreachable!("description has not frozen color fanouts"),\n                }',1)
s=s.replace('if let Fanout::Mapped(mapped) = entry {\n                        mapped.codec = codec;\n                    }','match entry.plain_mut() {\n                        Fanout::Mapped(mapped)=>mapped.codec=codec,\n                        Fanout::General {codec:current,..}=>*current=codec,\n                        _=>unreachable!("description has not frozen color fanouts"),\n                    }',1)
s=s.replace('        color_discovery.retain_standalone(&fanout);\n','')
s=s.replace('        for (destination, mapped_value, color) in fanout.all_destinations() {\n            let mapped_value', '''        for (destination, mapped_value, color) in fanout.all_destinations() {
            let selected=match mapped_value {Some(crate::style_port::Scalar::ColorSlot(code))=>Some(code),_=>None};
            let mapped_value''',1)
s=s.replace('                        let changed = !styles::exact_eq(&before, &after);\n                        if changed {','''                        let changed = !styles::exact_eq(&before, &after);
                        if let Some(code)=selected {
                            self.styles.select_color(index,id,code,matches!(self.overrides.contribution(identity,id),Contribution::Set(_)),self.nodes.len());
                        }
                        if changed {''',1)
s=s.replace('                            if color == 0 {\n                                self.styles.set','                            if color == 0 && selected.is_none() {\n                                self.styles.set',1)
p.write_text(s)
p=Path('/root/gpui-boolean-cohort-sol-20261024/reactivity/vendor/accesskit_atspi_common/src/node.rs');s=p.read_text().replace('if state.invalid().is_some()','if state.data().invalid().is_some()',1);p.write_text(s)
