from pathlib import Path
import sys,json,hashlib,shutil,subprocess
source=sys.argv[1];name=sys.argv[2];records=[]
root=Path('/root/gpui-boolean-cohort-sol-artifacts-20261024');root.mkdir(exist_ok=True)
out=root/(name+'-'+source[:10]);out.mkdir(exist_ok=True)
for line in Path(sys.argv[3]).read_text().splitlines():
 if not line.startswith('{'):continue
 try:x=json.loads(line)
 except json.JSONDecodeError:continue
 if x.get('reason')!='compiler-artifact' or not x.get('executable'):continue
 p=Path(x['executable']);q=out/(x['target']['name']+'-'+p.name)
 if not p.exists():continue
 shutil.copy2(p,q);q.chmod(0o555)
 records.append(dict(name=x['target']['name'],source=source,original=str(p),frozen=str(q),bytes=q.stat().st_size,sha256=hashlib.sha256(q.read_bytes()).hexdigest(),fresh=x.get('fresh'),package=x['package_id']))
(out/'manifest.json').write_text(json.dumps(records,indent=2)+'\n')
print(str(out),len(records))
