from pathlib import Path
import json,subprocess
root=Path('/tmp/gpui-boolean-cohort-public-layout-baseline');root.mkdir(exist_ok=True)
rows=[]
for l in Path('/tmp/gpui-component-review-full-1.jsonl').read_text().splitlines():
 if l.startswith('{'):
  x=json.loads(l)
  if x.get('reason')=='compiler-artifact':rows.append(x)
lib=next(x for x in rows if x['target']['name']=='gpui' and x['target']['kind']==['lib'] and not x['profile']['test'])
rlib=next(n for n in lib['filenames'] if n.endswith('.rmeta'))
source=root/'probe.rs';source.write_text("fn main() { println!(\"BASELINE_LAYOUT ColorInput={} PropInputBool={} PropInputColor={} El={} Style={}\", size_of::<gpui::ColorInput<'_>>(), size_of::<gpui::PropInput<'_,bool>>(), size_of::<gpui::PropInput<'_,gpui::Color>>(), size_of::<gpui::El<'_>>(), size_of::<gpui::Style>()); }\n")
args=['/tmp/gpui-nightly-2026-10-23/bin/rustc','--edition=2024',str(source),'--extern','gpui='+rlib,'--emit=llvm-ir','-Zprint-type-sizes','-o',str(root/'probe.ll')]
for path in sorted({str(Path(n).parent) for x in rows for n in x.get('filenames',[]) if n.endswith(('.rlib','.rmeta','.so','.dylib'))}):args+=['-L','dependency='+path]
r=subprocess.run(args,capture_output=True,text=True);(root/'compile.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stderr
(root/'result.txt').write_text(r.stdout+r.stderr);print('\n'.join(x for x in r.stdout.splitlines() if any(n in x for n in ['ColorInput','BoolColors','BoolBinding','BoolState','PropInput'])))
(root/'command.json').write_text(json.dumps(args,indent=2)+'\n')
