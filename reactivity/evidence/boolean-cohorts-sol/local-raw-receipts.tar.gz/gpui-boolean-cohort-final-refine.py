from pathlib import Path
r=Path('/root/gpui-boolean-cohort-sol-20261024/reactivity/crates/gpui/src')
p=r/'style_port.rs';s=p.read_text().replace('            Self::Deferred(_) => {\n                unreachable!("boolean bindings resolved before scalar admission")\n            }\n','').replace('            Self::Deferred(_) => unreachable!("boolean bindings resolved before recipe lowering"),\n','');p.write_text(s)
p=r/'style_port/boolean.rs';s=p.read_text()
s=s.replace("pub struct BoolState<'a> {\n    input: PropInput<'a, bool>,\n    id: u64,\n}","pub struct BoolState<'a> {\n    id: u64,\n    literal: bool,\n    borrow: std::marker::PhantomData<&'a ()>,\n}")
s=s.replace('''        BoolState {
            input: self.input,
            id: self.id,
        }''','''        BoolState {
            id: self.input.boolean_id().unwrap_or(self.id),
            literal: self.input.literal().unwrap_or(false),
            borrow: std::marker::PhantomData,
        }''',1)
s=s.replace('            return self.input;','            return self.literal.into_prop();',1)
a=s.index('pub(crate) enum Pending<');b=s.index('\n#[cfg(test)]',a)
s=s[:a]+'''/// Inline records are collected without an intermediate enum-sized queue.
/// Forward members (for example an input frame before its control) are resolved
/// only after the complete ordinary description has supplied its owners.
#[derive(Default)]
pub(crate) struct Description<'a> { groups:Vec<GroupDraft<'a>>, forward:Vec<MemberDraft> }
impl<'a> Description<'a> {
    pub fn append(&mut self,records:Vec<Record<'a>>,node:u32)->Result<(),crate::Error> {
        for record in records {
            match record {
                Record::Owner {id,signal,recipe}=>{
                    if self.groups.iter().any(|group|group.id==id) {return Err(crate::Error::BooleanBinding);}
                    self.groups.push(GroupDraft {id,signal,recipe,value:false,members:Vec::new()});
                },
                Record::Member {id,sink,colors}=>{
                    let member=MemberDraft {id,node,sink,colors};
                    if let Some(group)=self.groups.iter_mut().find(|group|group.id==id) {group.members.push(member);}
                    else {self.forward.push(member);}
                }
            }
        }
        Ok(())
    }
    pub fn finish(mut self)->Result<Vec<GroupDraft<'a>>,crate::Error> {
        for member in self.forward {
            self.groups.iter_mut().find(|group|group.id==member.id).ok_or(crate::Error::BooleanBinding)?.members.push(member);
        }
        self.groups.retain(|group|!group.members.is_empty());
        for group in &mut self.groups {
            let Scalar::Value(PropertyValue::Flag(value))=group.recipe.scalar(group.signal.as_any())? else {return Err(crate::Error::MapInput)};
            group.value=value;
        }
        Ok(self.groups)
    }
}
''' +s[b:]
# Public misuse checks concern real source typing and unforgeable membership.
s=s.replace('pub struct BoolBinding<\'a>', '''///
/// ```compile_fail
/// let text=gpui::Signal::new(String::from("value"));
/// let binding=gpui::BoolBinding::new(&text);
/// ```
pub struct BoolBinding<'a>''',1)
s=s.replace('#[derive(Clone, Copy)]\npub struct BoolState', '''///
/// ```compile_fail
/// let forged=gpui::BoolState { id:1, literal:false, borrow:std::marker::PhantomData };
/// ```
#[derive(Clone, Copy)]
pub struct BoolState''',1)
p.write_text(s)
p=r/'element.rs';s=p.read_text().replace('let mut boolean_pending = Vec::new();','let mut boolean_description = crate::style_port::boolean::Description::default();',1).replace('boolean_pending.extend(boolean.into_iter().map(|record| record.pending(index)));','boolean_description.append(boolean,index)?;',1).replace('let boolean_groups = crate::style_port::boolean::resolve(boolean_pending)?;','let boolean_groups = boolean_description.finish()?;',1);p.write_text(s)
p=Path('/root/gpui-boolean-cohort-sol-20261024/reactivity/crates/component/tests/boolean_cohorts.rs');s=p.read_text();old='''    assert_eq!(
        w.property(frame, BACKGROUND).unwrap().solid(),
        Some(w.root().unwrap().theme.danger())
    );
    w.set(Form::NUMBER, 2.0).unwrap();''';new='''    // Ordinary inspector property access requires a valid logical owner; P
    // remains readable through its acknowledged semantic sheet after failure.
    assert!(matches!(w.property(frame,BACKGROUND),Err(Error::StaleTarget)));
    w.set(Form::NUMBER, 2.0).unwrap();''';assert old in s;s=s.replace(old,new,1);p.write_text(s)
