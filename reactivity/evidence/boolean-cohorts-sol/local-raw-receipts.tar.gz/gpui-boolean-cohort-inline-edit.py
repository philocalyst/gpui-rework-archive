from pathlib import Path
r=Path('/root/gpui-boolean-cohort-sol-20261024/reactivity/crates/gpui/src')
p=r/'style_port.rs';s=p.read_text().replace('pub(crate) use boolean::{GroupDraft as BooleanDraft, Pending as BooleanPending};','pub(crate) use boolean::GroupDraft as BooleanDraft;\nmod bindings;\npub(crate) use bindings::MapBindings;')
for row in ['    BoolOwner(Box<boolean::Owner>),\n','    BoolColor(Box<boolean::Choice>),\n','    BoolFlag(u64),\n','    BoolSingle(Box<boolean::Single>),\n','    pub const BOOLEAN_OWNER: Self = Self(0xffff);\n']:s=s.replace(row,'')
s=s.replace('    Selection(OwnedMapOperand<\'a>),','    Selection(OwnedMapOperand<\'a>),\n    Boolean(BoolColors<\'a>),',1)
s=s.replace("Boolean { id: u64, signal: &'a dyn ErasedSignal }","Boolean { id: u64 }")
# rustfmt expanded Operand variant
s=s.replace("    Boolean {\n        id: u64,\n        signal: &'a dyn ErasedSignal,\n    },","    Boolean { id: u64 },")
p.write_text(s)
p=r/'semantic.rs';s=p.read_text().replace("pub mapped: Vec<crate::style_port::MapBinding<'a>>","pub mapped: crate::style_port::MapBindings<'a>",1).replace("bindings: Vec<crate::style_port::MapBinding<'a>>","bindings: crate::style_port::MapBindings<'a>",1)
s=s.replace('!bindings.iter().any(|binding| binding.sink == property)','!bindings.contains(property)',1)
s=s.replace('            && property != crate::style_port::Sink::BOOLEAN_OWNER\n            && let Some(binding) = bindings.iter_mut().find(|binding| binding.sink == property)','            && let Some(binding) = bindings.mapped_mut(property)',1)
s=s.replace('        if property != crate::style_port::Sink::BOOLEAN_OWNER {\n            self.unbind(property);\n        }','        self.unbind(property);',1)
s=s.replace('                bindings: Vec::new(),\n                background: None,','                bindings: Default::default(),\n                background: None,')
a=s.index('        // Exact growth avoids a minimum-four allocation for one cold binding.');b=s.index('    pub fn unbind(',a)
s=s[:a]+'''        bindings.push_map(crate::style_port::MapBinding { sink: property, operand });
    }
    pub fn bind_boolean(&mut self, record: crate::style_port::boolean::Record<'a>) {
        if matches!(self,Self::Control {..}) { self.control_base().bind_boolean(record); return; }
        if let Some(sink)=record.sink() {self.unbind(sink);}
        if !matches!(self,Self::Mapped {..}) {
            let previous=std::mem::replace(self,Self::Semantic(Annotations::default()));
            let base=(!previous.empty() && !matches!(&previous,Self::Semantic(s) if s.is_empty())).then(||Box::new(previous));
            *self=Self::Mapped {bindings:Default::default(),background:None,base};
        }
        let Self::Mapped {bindings,..}=self else {unreachable!()};
        bindings.push_boolean(record);
    }
'''+s[b:]
s=s.replace('            bindings.retain(|binding| binding.sink != property);\n            if bindings.is_empty() {\n                *bindings = Vec::new();\n            }','            bindings.unbind(property);',1)
p.write_text(s)
p=r/'element.rs';s=p.read_text()
s=s.replace('} else if let Some(operand) = clipped.boolean_member() {','} else if let Some(id) = clipped.boolean_id() {',1).replace('.bind_map(PropertyId::Clip.into(), operand);','.bind_boolean(crate::style_port::boolean::Record::Member {id,sink:PropertyId::Clip.into(),colors:None});',1)
a=s.index('    pub(crate) fn bind_boolean_owner(');b=s.index('    fn control_input(',a)
s=s[:a]+'''    pub(crate) fn bind_boolean(&mut self, record: crate::style_port::boolean::Record<'a>) {
        self.extra.get_or_insert_with(|| Box::new(crate::semantic::ElementExtra::Semantic(Default::default())))
            .bind_boolean(record);
    }
'''+s[b:]
a=s.index('        } else if let Some(operand) = input.boolean_member()');b=s.index('        } else if let Some(signal) = input.signal()',a)
s=s[:a]+'''        } else if let Some(id) = input.boolean_id() {
            self.bind_boolean(crate::style_port::boolean::Record::Member {id,sink,colors:None});
'''+s[b:]
# Undo extra brace duplicated by else splice above if any handled formatted parser.
a=s.index('            for binding in mapped {');b=s.index('                let value = binding.sink.admit',a)
s=s[:a]+'''            let (mapped, boolean)=mapped.into_parts();
            boolean_pending.extend(boolean.into_iter().map(|record|record.pending(index)));
            for binding in mapped {
'''+s[b:]
# Generic bool properties such as Wrap are real members too.
s=s.replace('                let map = input.mapped().expect("sealed mapped input");','''                if let Some(id)=input.boolean_id() {
                    self.bind_boolean(crate::style_port::boolean::Record::Member {id,sink:property.into(),colors:None});
                    return;
                }
                let map = input.mapped().expect("sealed mapped input");''',1)
# color_operand is shared by background and foreground.
s=s.replace('            ColorOperand::Selection(operand) => {','''            ColorOperand::Boolean(selection) => {
                let binding=crate::BoolBinding::new(selection.input);
                let state=binding.state().into_prop();
                let id=state.boolean_id().expect("dynamic boolean palette");
                self=binding.attach(self);
                self.bind_boolean(crate::style_port::boolean::Record::Member {id,sink:property.into(),colors:Some(selection.colors)});
            }
            ColorOperand::Selection(operand) => {''',1)
p.write_text(s)
p=r/'runtime/accessibility.rs';s=p.read_text().replace('            || previous.disabled != next.disabled','            || previous.disabled != next.disabled\n            || previous.invalid != next.invalid',1);p.write_text(s)
p=r/'runtime.rs';s=p.read_text().replace('output.destination.property()\n                        == Some(crate::property::PropertyId::Clip)','output.destination.property().is_some_and(|id| id.value_kind()==crate::property::ValueKind::Flag)')
p.write_text(s)
