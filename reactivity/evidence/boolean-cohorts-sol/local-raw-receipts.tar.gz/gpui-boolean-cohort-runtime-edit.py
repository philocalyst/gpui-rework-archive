from pathlib import Path
r=Path('/root/gpui-boolean-cohort-sol-20261024/reactivity/crates/gpui/src')
p=r/'runtime.rs';s=p.read_text()
s=s.replace('    MapInput,','    MapInput,\n    /// A boolean destination escaped, duplicated, or lost its declared owner.\n    BooleanBinding,',1)
s=s.replace('    const BITS: u32 = 24;','    const BITS: u32 = 25;',1).replace('Content::BITS - 2 - 4','Content::BITS - 3 - 4',1)
s=s.replace('    const FLAGS: u32 = Self::DISABLED | Self::OWN_DISABLED;','    const INVALID: u32 = 1 << 24;\n    const FLAGS: u32 = Self::DISABLED | Self::OWN_DISABLED | Self::INVALID;\n    fn invalid(self) -> bool { self.0 & Self::INVALID != 0 }\n    fn with_invalid(self, invalid: bool) -> Self {\n        Self((self.0 & !Self::INVALID) | (u32::from(invalid) * Self::INVALID))\n    }',1)
s=s.replace('enum Fanout {','struct BooleanRecipe { recipe: crate::style_port::Recipe, value: bool }\nstruct BooleanOutput { destination: Destination, group: u32, colors: [u32; 2] }\nstruct BooleanFanout { base: Fanout, groups: Vec<BooleanRecipe>, outputs: Vec<BooleanOutput> }\nenum Fanout {',1)
s=s.replace('    Mapped(Box<MappedFanout>),','    Mapped(Box<MappedFanout>),\n    Boolean(Box<BooleanFanout>),',1)
s=s.replace('            Self::Mapped(mapped) => mapped.codec,','            Self::Mapped(mapped) => mapped.codec,\n            Self::Boolean(group) => group.base.codec(),',1)
s=s.replace('            Self::Mapped(mapped) => &mapped.destinations,','            Self::Mapped(mapped) => &mapped.destinations,\n            Self::Boolean(group) => group.base.destinations(),',1)
s=s.replace('            Self::Mapped(mapped) => &mut mapped.destinations,','            Self::Mapped(mapped) => &mut mapped.destinations,\n            Self::Boolean(group) => group.base.destinations_mut(),',1)
s=s.replace('    #[inline(never)]\n    fn map(','''    fn plain_mut(&mut self) -> &mut Self {
        if let Self::Boolean(group)=self { &mut group.base } else { self }
    }
    fn plain(&self) -> &Self {
        if let Self::Boolean(group)=self { &group.base } else { self }
    }
    fn boolean(&mut self, draft: crate::style_port::BooleanDraft<'_>, colors: &mut styles::ColorDiscovery) -> Result<(),Error> {
        let recipe=draft.recipe.lower(|color| colors.literal_code(color))?;
        if !matches!(self,Self::Boolean(_)) {
            let base=std::mem::replace(self,Self::new(TextCodec::for_style::<bool>()));
            *self=Self::Boolean(Box::new(BooleanFanout {base, groups:Vec::new(),outputs:Vec::new()}));
        }
        let Self::Boolean(fanout)=self else {unreachable!()};
        let index=u32::try_from(fanout.groups.len()).map_err(|_|Error::ResourceLimit)?;
        fanout.groups.push(BooleanRecipe {recipe,value:draft.value});
        for member in draft.members {
            let palette=if let Some(palette)=member.colors {
                for color in palette { crate::property::FOREGROUND.validate(&color)?; }
                palette.map(|color|colors.literal_code(color))
            } else {[0,0]};
            fanout.outputs.push(BooleanOutput {destination:Destination::sink(member.node as usize,member.sink),group:index,colors:palette});
        }
        Ok(())
    }
    #[inline(never)]
    fn map(''',1)
s=s.replace('        let value = draft.value;\n        let recipe', '        if let Self::Boolean(group)=self { return group.base.map(draft,colors); }\n        let value = draft.value;\n        let recipe',1)
s=s.replace('        let mut needs = crate::source::Needs {','''        if let Self::Boolean(fanout)=self {
            let frozen=fanout.base.freeze(source,field,styles)?;
            // Freeze each declared computation once, before any destination is
            // compared or changed. Palette endpoints were admitted at mount.
            for group in &mut fanout.groups {
                let Some(crate::style_port::Scalar::Value(crate::property::PropertyValue::Flag(value)))=group.recipe.call(source) else {return Err(Error::MapInput)};
                group.value=value;
            }
            return Ok(frozen);
        }
        let mut needs = crate::source::Needs {''',1)
s=s.replace('        self.destinations_mut()\n            .sort_unstable_by_key', '''        if let Self::Boolean(group)=self {
            group.base.finish_description(field,drafts,colors);
            group.outputs.sort_unstable_by_key(|output|output.destination.packed());
            group.groups.shrink_to_fit();
            group.outputs.shrink_to_fit();
            return true;
        }
        self.destinations_mut()
            .sort_unstable_by_key''',1)
a=s.index('    fn all_destinations(');b=s.index('\n    #[cfg(test)]\n    fn destination_bytes',a)
s=s[:a]+'''    fn all_destinations(
        &self,
    ) -> impl Iterator<Item = (Destination, Option<crate::style_port::Scalar>, u32)> + '_ {
        let base=self.plain();
        let (mut records, mut values, direct_color) = match base {
            Self::Mapped(mapped) => (mapped.records.as_slice(),mapped.values.as_slice(),mapped.direct_color),
            _ => (&[][..], &[][..], 0),
        };
        let mut direct=base.destinations();
        let (groups,mut outputs)=match self {
            Self::Boolean(group)=>(group.groups.as_slice(),group.outputs.as_slice()),
            _=>(&[][..],&[][..]),
        };
        std::iter::from_fn(move || {
            let d=direct.first().map(|destination|destination.packed()).unwrap_or(u32::MAX);
            let m=records.first().map(|record|record.destination.packed()).unwrap_or(u32::MAX);
            let c=outputs.first().map(|output|output.destination.packed()).unwrap_or(u32::MAX);
            if d==u32::MAX && m==u32::MAX && c==u32::MAX {return None;}
            if d<m && d<c {
                let (&destination,rest)=direct.split_first()?;direct=rest;
                Some((destination,None,direct_color))
            } else if m<c {
                let (record,rest)=records.split_first()?;
                let (value,remaining)=values.split_first()?;records=rest;values=remaining;
                Some((record.destination,Some(crate::style_port::Scalar::Value(*value)),record.color))
            } else {
                let (output,rest)=outputs.split_first()?;outputs=rest;
                let value=groups[output.group as usize].value;
                let scalar=if output.destination.control().is_some() {
                    crate::style_port::Scalar::Value(crate::property::PropertyValue::Flag(value))
                } else { crate::style_port::Scalar::ColorSlot(output.colors[usize::from(value)]) };
                Some((output.destination,Some(scalar),0))
            }
        })
    }
''' +s[b:]
s=s.replace('            Self::Color(_) => 0,','            Self::Color(_) => 0,\n            Self::Boolean(group) => size_of::<BooleanFanout>() + group.base.destination_bytes()\n                + group.groups.capacity()*size_of::<BooleanRecipe>()\n                + group.outputs.capacity()*size_of::<BooleanOutput>(),',1)
s=s.replace('    disabled: bool,\n    actions: Actions,','    disabled: bool,\n    invalid: bool,\n    actions: Actions,',1)
s=s.replace('            mapped_ports,\n        } = inspector::description','            mapped_ports,\n            boolean_groups,\n        } = inspector::description',1)
# Add cohorts after ordinary ports/annotation resolution, avoiding altering direct colour discovery.
s=s.replace('        for (&field, ports) in &mut fanout {','''        for group in boolean_groups {
            let field=self.sources.resolve(&self.model,group.signal)?;
            if let Some(field)=field {
                fanout.entry(field).or_insert_with(||Fanout::new(TextCodec::for_style::<bool>()))
                    .boolean(group,&mut color_discovery)?;
            } else if let Some(member)=group.members.iter().find(|member|member.sink.property().is_none()) {
                return Err(Error::UnregisteredControl {node:member.node as usize});
            }
        }
        for (&field, ports) in &mut fanout {''',1)
# Revoke field-wide source-colour special case when a cohort shares its field.
s=s.replace('        color_discovery.capture(&fanout);','        color_discovery.retain_standalone(&fanout);\n        color_discovery.capture(&fanout);',1)
s=s.replace('        for (destination, mapped_value, color) in fanout.all_destinations() {','''        for (destination, mapped_value, color) in fanout.all_destinations() {
            let mapped_value=mapped_value.map(|scalar|self.styles.resolve_scalar(scalar));''',1)
s=s.replace('                    mapped_value.unwrap_or_else(|| match frozen.style {\n                        Some(crate::style_port::Scalar::Value(value)) => value,','                    mapped_value.unwrap_or_else(|| frozen.style.expect("admitted bool source"))\n                    .narrow(crate::property::PropertyId::ClipChildren)?\n                /* match frozen.style {\n                        Some(crate::style_port::Scalar::Value(value)) => value,',1)
# Replace entire malformed let block with canonical scalar admission by sink.
a=s.index('                let crate::property::PropertyValue::Flag(value) =',s.index('for (destination, mapped_value, color) in fanout.all_destinations()'))
b=s.index('                let before = node.content;',a)
s=s[:a]+'''                let crate::property::PropertyValue::Flag(value)=control.admit(
                    mapped_value.unwrap_or_else(||frozen.style.expect("admitted bool source"))
                )? else {unreachable!("admitted bool sink")};
'''+s[b:]
s=s.replace('                } else {\n                    before.with_own_disabled(value)\n                };','                } else if control == crate::style_port::Sink::INVALID {\n                    before.with_invalid(value)\n                } else {\n                    before.with_own_disabled(value)\n                };',1)
s=s.replace('                    Some(value) => value,\n                    None => frozen.style.expect("style codec requested").admit(id)?,','                    Some(value) => value.admit(id)?,\n                    None => frozen.style.expect("style codec requested").admit(id)?,',1)
s=s.replace('        if let Fanout::Mapped(mapped) = fanout\n            && let ColorPatch::Candidate(change) =','        let compound=matches!(fanout,Fanout::Boolean(_));\n        if let Fanout::Mapped(mapped) = fanout.plain_mut()\n            && let ColorPatch::Candidate(change) =',1).replace('mapped.publish_colors(&mut self.styles, frozen.style, eligible)','mapped.publish_colors(&mut self.styles, frozen.style, eligible && !compound)',1)
s=s.replace('                disabled: node.content.disabled(),','                disabled: node.content.disabled(),\n                invalid: node.content.invalid(),',1)
# Content construction receives intrinsic invalid state without changing identities.
s=s.replace('.with_own_disabled(draft.disabled)', '.with_invalid(draft.invalid).with_own_disabled(draft.disabled)')
p.write_text(s)
p=r/'runtime/styles/colours.rs';s=p.read_text().replace('    pub(in crate::runtime) fn capture(&mut self, fanout:', '''    pub(in crate::runtime) fn retain_standalone(&mut self, fanout: &BTreeMap<FieldId, Fanout>) {
        // Compound fields need ordinary per-destination base publication, not a
        // field-wide colour slot that would replace their semantic fanout.
        self.fields.retain(|field,_| !matches!(fanout[field],Fanout::Boolean(_)));
    }
    pub(in crate::runtime) fn capture(&mut self, fanout:''',1);p.write_text(s)
p=r/'runtime/query.rs';s=p.read_text().replace('    pub fn actions(self) -> Actions {','    /// Input validation state from the acknowledged presentation. This is\n    /// independent of focus, editability, and an application\'s color policy.\n    pub fn invalid(self) -> bool { self.node().invalid }\n    pub fn actions(self) -> Actions {',1);p.write_text(s)
p=r/'runtime/query/serialize.rs';s=p.read_text().replace('20 + usize::from','21 + usize::from',1).replace('        node.serialize_field("disabled", &self.disabled())?;','        node.serialize_field("disabled", &self.disabled())?;\n        node.serialize_field("invalid", &self.invalid())?;',1);p.write_text(s)
p=r/'native/accessibility.rs';s=p.read_text().replace('    if part.disabled() {','    if part.invalid() { node.set_invalid(accesskit::Invalid::True); }\n    if part.disabled() {',1);p.write_text(s)
