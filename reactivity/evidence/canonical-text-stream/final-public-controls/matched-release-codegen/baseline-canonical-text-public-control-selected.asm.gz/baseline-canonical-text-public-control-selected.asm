
<core::option::Option<alloc::vec::Vec<gpui::runtime::geometry::Record>>>::or_else::<<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::present_inner::{closure#42}> bytes=105 frame=0

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000073d440 <_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime8geometry6RecordEE7or_elseNCNvMsu_B1i_INtB1i_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersE_0EB2E_>:
  73d440:	cmpq   $0xffffffffffffffff,(%rsi)
  73d444:	je     73d46f <_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime8geometry6RecordEE7or_elseNCNvMsu_B1i_INtB1i_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersE_0EB2E_+0x2f>
  73d446:	mov    0x10(%rsi),%rax
  73d44a:	mov    %rax,0x10(%rdi)
  73d44e:	movups (%rsi),%xmm0
  73d451:	movups %xmm0,(%rdi)
  73d454:	mov    (%rdx),%rsi
  73d457:	test   %rsi,%rsi
  73d45a:	je     73d48a <_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime8geometry6RecordEE7or_elseNCNvMsu_B1i_INtB1i_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersE_0EB2E_+0x4a>
  73d45c:	mov    0x8(%rdx),%rdi
  73d460:	shl    $0x4,%rsi
  73d464:	mov    $0x4,%edx
  73d469:	jmp    *0x37cc41(%rip)        # aba0b0 <_DYNAMIC+0x240>
  73d46f:	mov    (%rdx),%rsi
  73d472:	mov    0x8(%rdx),%rax
  73d476:	mov    0x10(%rdx),%rcx
  73d47a:	test   %rcx,%rcx
  73d47d:	je     73d48b <_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime8geometry6RecordEE7or_elseNCNvMsu_B1i_INtB1i_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersE_0EB2E_+0x4b>
  73d47f:	mov    %rsi,(%rdi)
  73d482:	mov    %rax,0x8(%rdi)
  73d486:	mov    %rcx,0x10(%rdi)
  73d48a:	ret
  73d48b:	movq   $0xffffffffffffffff,(%rdi)
  73d492:	test   %rsi,%rsi
  73d495:	je     73d48a <_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime8geometry6RecordEE7or_elseNCNvMsu_B1i_INtB1i_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersE_0EB2E_+0x4a>
  73d497:	shl    $0x4,%rsi
  73d49b:	mov    $0x4,%edx
  73d4a0:	mov    %rax,%rdi
  73d4a3:	jmp    *0x37cc07(%rip)        # aba0b0 <_DYNAMIC+0x240>

<gpui::runtime::RuntimeMut<canonical_text_public_control::Editor, ()>>::operation_with_editing::<<gpui::runtime::RuntimeMut<canonical_text_public_control::Editor, ()>>::replace_input::{closure#2}> bytes=974 frame=280

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000073da10 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_>:
  73da10:	push   %rbp
  73da11:	push   %r15
  73da13:	push   %r14
  73da15:	push   %r13
  73da17:	push   %r12
  73da19:	push   %rbx
  73da1a:	sub    $0xe8,%rsp
  73da21:	mov    %rdi,%rbx
  73da24:	mov    (%rsi),%r14
  73da27:	mov    $0xe,%eax
  73da2c:	cmpb   $0x0,0x76e(%r14)
  73da34:	je     73da65 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x55>
  73da36:	mov    %rax,(%rbx)
  73da39:	mov    (%rcx),%rsi
  73da3c:	test   %rsi,%rsi
  73da3f:	je     73dd25 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x315>
  73da45:	mov    0x8(%rcx),%rdi
  73da49:	mov    $0x1,%edx
  73da4e:	add    $0xe8,%rsp
  73da55:	pop    %rbx
  73da56:	pop    %r12
  73da58:	pop    %r13
  73da5a:	pop    %r14
  73da5c:	pop    %r15
  73da5e:	pop    %rbp
  73da5f:	jmp    *0x37c64b(%rip)        # aba0b0 <_DYNAMIC+0x240>
  73da65:	mov    0x6a0(%r14),%r9
  73da6c:	inc    %r9
  73da6f:	je     73dd37 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x327>
  73da75:	mov    (%rcx),%r11
  73da78:	mov    0x8(%rcx),%r10
  73da7c:	mov    0x10(%rcx),%r13
  73da80:	mov    0x18(%rcx),%r12
  73da84:	mov    0x20(%rcx),%r15
  73da88:	mov    0x228(%r14),%rax
  73da8f:	lea    0x230(%r14),%rcx
  73da96:	cmp    $0xffffffffffffffff,%rax
  73da9a:	lea    0x88(%rsp),%rdi
  73daa2:	cmovne %rcx,%rdi
  73daa6:	movups (%rdi),%xmm0
  73daa9:	movaps %xmm0,0xd0(%rsp)
  73dab1:	je     73db14 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x104>
  73dab3:	movaps 0xd0(%rsp),%xmm0
  73dabb:	movups %xmm0,0x48(%rsp)
  73dac0:	mov    %rax,0x40(%rsp)
  73dac5:	mov    %r11,0x58(%rsp)
  73daca:	mov    %r10,0x60(%rsp)
  73dacf:	mov    %r13,0x68(%rsp)
  73dad4:	mov    %r12,0x70(%rsp)
  73dad9:	mov    0x40(%rsp),%rax
  73dade:	cmp    $0xfffffffffffffffe,%rax
  73dae2:	jne    73dcb2 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x2a2>
  73dae8:	mov    %r9,0x6a0(%r14)
  73daef:	incq   0x700(%r14)
  73daf6:	movq   $0x0,0x758(%r14)
  73db01:	mov    %rbx,%rdi
  73db04:	mov    %r8,%rcx
  73db07:	xor    %r8d,%r8d
  73db0a:	call   7677a0 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB4_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE20after_source_changedBW_>
  73db0f:	jmp    73dd25 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x315>
  73db14:	mov    %r13,0x38(%rsp)
  73db19:	mov    %r15,0x78(%rsp)
  73db1e:	mov    %r11,0x8(%rsp)
  73db23:	mov    %r10,0x10(%rsp)
  73db28:	mov    %r9,0x18(%rsp)
  73db2d:	mov    %rsi,0x20(%rsp)
  73db32:	mov    %rdx,0x28(%rsp)
  73db37:	mov    %r8,0x30(%rsp)
  73db3c:	cmp    $0x1,%r12d
  73db40:	jne    73dbd0 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x1c0>
  73db46:	mov    0x248(%r14),%r15
  73db4d:	mov    0x250(%r14),%r13
  73db54:	shl    $0x4,%r13
  73db58:	xor    %ebp,%ebp
  73db5a:	nopw   0x0(%rax,%rax,1)
  73db60:	cmp    %rbp,%r13
  73db63:	je     73dc5e <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x24e>
  73db69:	mov    (%r15,%rbp,1),%rdi
  73db6d:	mov    0x8(%r15,%rbp,1),%rax
  73db72:	call   *0x18(%rax)
  73db75:	add    $0x10,%rbp
  73db79:	cmp    %r12,%rax
  73db7c:	jne    73db60 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x150>
  73db7e:	mov    -0x10(%r15,%rbp,1),%rsi
  73db83:	mov    -0x8(%r15,%rbp,1),%rax
  73db88:	mov    0x8(%rsp),%rcx
  73db8d:	mov    %rcx,0x80(%rsp)
  73db95:	mov    0x10(%rsp),%rcx
  73db9a:	mov    %rcx,0x88(%rsp)
  73dba2:	mov    0x38(%rsp),%rcx
  73dba7:	mov    %rcx,0x90(%rsp)
  73dbaf:	lea    0x40(%rsp),%rdi
  73dbb4:	lea    0x80(%rsp),%rcx
  73dbbc:	lea    0x290(%r14),%rdx
  73dbc3:	mov    0x78(%rsp),%r8
  73dbc8:	call   *0x40(%rax)
  73dbcb:	jmp    73dc8f <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x27f>
  73dbd0:	mov    0x278(%r14),%r15
  73dbd7:	mov    0x280(%r14),%rbp
  73dbde:	shl    $0x4,%rbp
  73dbe2:	xor    %r13d,%r13d
  73dbe5:	data16 cs nopw 0x0(%rax,%rax,1)
  73dbf0:	cmp    %r13,%rbp
  73dbf3:	je     73dc5e <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x24e>
  73dbf5:	mov    (%r15,%r13,1),%rdi
  73dbf9:	mov    0x8(%r15,%r13,1),%rax
  73dbfe:	mov    %r12,%rsi
  73dc01:	call   *0x30(%rax)
  73dc04:	add    $0x10,%r13
  73dc08:	test   %al,%al
  73dc0a:	je     73dbf0 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x1e0>
  73dc0c:	mov    -0x10(%r15,%r13,1),%rsi
  73dc11:	mov    -0x8(%r15,%r13,1),%rax
  73dc16:	mov    0x8(%rsp),%rcx
  73dc1b:	mov    %rcx,0x80(%rsp)
  73dc23:	mov    0x10(%rsp),%rcx
  73dc28:	mov    %rcx,0x88(%rsp)
  73dc30:	mov    0x38(%rsp),%rcx
  73dc35:	mov    %rcx,0x90(%rsp)
  73dc3d:	lea    0x40(%rsp),%rdi
  73dc42:	lea    0x80(%rsp),%r8
  73dc4a:	lea    0x290(%r14),%rdx
  73dc51:	mov    %r12,%rcx
  73dc54:	mov    0x78(%rsp),%r9
  73dc59:	call   *0x70(%rax)
  73dc5c:	jmp    73dc8f <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x27f>
  73dc5e:	movq   $0xb,0x40(%rsp)
  73dc67:	mov    %r12,0x48(%rsp)
  73dc6c:	mov    0x8(%rsp),%rax
  73dc71:	mov    %rax,0x58(%rsp)
  73dc76:	mov    0x10(%rsp),%rax
  73dc7b:	mov    %rax,0x60(%rsp)
  73dc80:	mov    0x38(%rsp),%rax
  73dc85:	mov    %rax,0x68(%rsp)
  73dc8a:	mov    %r12,0x70(%rsp)
  73dc8f:	mov    0x30(%rsp),%r8
  73dc94:	mov    0x28(%rsp),%rdx
  73dc99:	mov    0x20(%rsp),%rsi
  73dc9e:	mov    0x18(%rsp),%r9
  73dca3:	mov    0x40(%rsp),%rax
  73dca8:	cmp    $0xfffffffffffffffe,%rax
  73dcac:	je     73dae8 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0xd8>
  73dcb2:	mov    0x48(%rsp),%rcx
  73dcb7:	movups 0x50(%rsp),%xmm0
  73dcbc:	movups 0x60(%rsp),%xmm1
  73dcc1:	mov    0x70(%rsp),%rdx
  73dcc6:	mov    %rcx,0xa0(%rsp)
  73dcce:	movups %xmm0,0xa8(%rsp)
  73dcd6:	movups %xmm1,0xb8(%rsp)
  73dcde:	mov    %rdx,0xc8(%rsp)
  73dce6:	movups 0xb0(%rsp),%xmm0
  73dcee:	movups %xmm0,0x18(%rbx)
  73dcf2:	mov    0xc0(%rsp),%rcx
  73dcfa:	mov    %rcx,0x28(%rbx)
  73dcfe:	mov    0xc8(%rsp),%rcx
  73dd06:	mov    %rcx,0x30(%rbx)
  73dd0a:	mov    0xa0(%rsp),%rcx
  73dd12:	mov    %rcx,0x8(%rbx)
  73dd16:	mov    0xa8(%rsp),%rcx
  73dd1e:	mov    %rcx,0x10(%rbx)
  73dd22:	mov    %rax,(%rbx)
  73dd25:	add    $0xe8,%rsp
  73dd2c:	pop    %rbx
  73dd2d:	pop    %r12
  73dd2f:	pop    %r13
  73dd31:	pop    %r14
  73dd33:	pop    %r15
  73dd35:	pop    %rbp
  73dd36:	ret
  73dd37:	mov    $0x1f,%eax
  73dd3c:	mov    %rax,(%rbx)
  73dd3f:	mov    (%rcx),%rsi
  73dd42:	test   %rsi,%rsi
  73dd45:	jne    73da45 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x35>
  73dd4b:	jmp    73dd25 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x315>
  73dd4d:	mov    %rax,%r12
  73dd50:	jmp    73dd74 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x364>
  73dd52:	jmp    73dd54 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x344>
  73dd54:	mov    %rax,%r12
  73dd57:	cmpq   $0x0,0x8(%rsp)
  73dd5d:	je     73dd74 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x364>
  73dd5f:	mov    $0x1,%edx
  73dd64:	mov    0x10(%rsp),%rdi
  73dd69:	mov    0x8(%rsp),%rsi
  73dd6e:	call   *0x37c33c(%rip)        # aba0b0 <_DYNAMIC+0x240>
  73dd74:	mov    %r12,%rdi
  73dd77:	call   *0x37c38b(%rip)        # aba108 <_DYNAMIC+0x298>
  73dd7d:	mov    %rax,0xa0(%rsp)
  73dd85:	mov    %rdx,0xa8(%rsp)
  73dd8d:	movq   $0xfffffffffffffffd,0x98(%rsp)
  73dd99:	mov    %r14,%rdi
  73dd9c:	call   78d7d0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE6poisonBO_>
  73dda1:	movq   $0xf,(%rbx)
  73dda8:	lea    0x98(%rsp),%rdi
  73ddb0:	call   746320 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultIBC_NtNtNtCslbxve4rcJus_4gpui7runtime5paint12PatchOutcomeNtB15_5ErrorEINtNtCscdodAO9FK5_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECs9C2G9YFESsD_29canonical_text_public_control>
  73ddb5:	jmp    73dd25 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x315>
  73ddba:	mov    %rax,%rbx
  73ddbd:	lea    0x98(%rsp),%rdi
  73ddc5:	call   746320 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultIBC_NtNtNtCslbxve4rcJus_4gpui7runtime5paint12PatchOutcomeNtB15_5ErrorEINtNtCscdodAO9FK5_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECs9C2G9YFESsD_29canonical_text_public_control>
  73ddca:	mov    %rbx,%rdi
  73ddcd:	call   a98590 <_Unwind_Resume@plt>
  73ddd2:	call   *0x37c300(%rip)        # aba0d8 <_DYNAMIC+0x268>
  73ddd8:	call   *0x37c332(%rip)        # aba110 <_DYNAMIC+0x2a0>

<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::present_inner::{closure#30}> bytes=1753 frame=424

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000073f5d0 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_>:
  73f5d0:	push   %rbp
  73f5d1:	push   %r15
  73f5d3:	push   %r14
  73f5d5:	push   %r13
  73f5d7:	push   %r12
  73f5d9:	push   %rbx
  73f5da:	sub    $0x178,%rsp
  73f5e1:	test   %rdi,%rdi
  73f5e4:	je     73fba9 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x5d9>
  73f5ea:	mov    %rsi,%rbx
  73f5ed:	mov    %rdi,%r12
  73f5f0:	lea    0x10(%rdi),%r15
  73f5f4:	mov    (%rdx),%r14
  73f5f7:	mov    0x8(%rdx),%r13
  73f5fb:	mov    0x10(%rdx),%rax
  73f5ff:	mov    %rax,0x70(%rsp)
  73f604:	mov    0x18(%rdx),%rax
  73f608:	mov    %rax,0x68(%rsp)
  73f60d:	mov    0x20(%rdx),%rax
  73f611:	mov    %rax,0x78(%rsp)
  73f616:	mov    0x28(%rdx),%rbp
  73f61a:	mov    %r15,%rdi
  73f61d:	call   *0x37ab0d(%rip)        # aba130 <_DYNAMIC+0x2c0>
  73f623:	test   %al,%al
  73f625:	je     73fba9 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x5d9>
  73f62b:	mov    (%rbx),%esi
  73f62d:	mov    0x8(%rbx),%eax
  73f630:	cmp    %esi,%eax
  73f632:	je     73fbad <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x5dd>
  73f638:	mov    %esi,%edx
  73f63a:	cmova  %eax,%edx
  73f63d:	cmovb  %eax,%esi
  73f640:	mov    %r15,%rdi
  73f643:	call   *0x37aaef(%rip)        # aba138 <_DYNAMIC+0x2c8>
  73f649:	mov    %rdx,%rcx
  73f64c:	movss  0x5c(%r12),%xmm0
  73f653:	mulss  -0x67d183(%rip),%xmm0        # c24d8 <GCC_except_table0+0x10c>
  73f65b:	lea    0xb0(%rsp),%r12
  73f663:	mov    %r12,%rdi
  73f666:	mov    %r15,%rsi
  73f669:	mov    %rax,%rdx
  73f66c:	call   *0x37aace(%rip)        # aba140 <_DYNAMIC+0x2d0>
  73f672:	lea    0x30(%rsp),%rdi
  73f677:	mov    %r12,%rsi
  73f67a:	call   798540 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control>
  73f67f:	cmpq   $0x0,0x30(%rsp)
  73f685:	je     73fbad <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x5dd>
  73f68b:	movq   $0x0,0x28(%rsp)
  73f694:	mov    %r14,0x18(%rsp)
  73f699:	mov    %r13,0x10(%rsp)
  73f69e:	mov    %rbp,0x8(%rsp)
  73f6a3:	movss  %xmm1,0x4(%rsp)
  73f6a9:	movaps %xmm3,%xmm0
  73f6ac:	mov    0xe8(%rsp),%rbp
  73f6b4:	movss  0xf0(%rsp),%xmm1
  73f6bd:	movss  %xmm1,0x80(%rsp)
  73f6c6:	mov    0xb0(%rsp),%r14
  73f6ce:	mov    0xb8(%rsp),%r13
  73f6d6:	mov    0xd0(%rsp),%rbx
  73f6de:	mov    0xc8(%rsp),%r15
  73f6e6:	mov    0xc0(%rsp),%r12
  73f6ee:	movaps %xmm2,0xa0(%rsp)
  73f6f6:	movaps %xmm0,0x90(%rsp)
  73f6fe:	xchg   %ax,%ax
  73f700:	lea    0x140(%rsp),%rdi
  73f708:	mov    %rbp,%rsi
  73f70b:	movss  0x80(%rsp),%xmm0
  73f714:	lea    0x30(%rsp),%rdx
  73f719:	call   75d540 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control>
  73f71e:	cmpb   $0x2,0x144(%rsp)
  73f726:	jne    73f905 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x335>
  73f72c:	mov    %r13,%rax
  73f72f:	cmp    $0x1,%r13
  73f733:	movaps 0xa0(%rsp),%xmm2
  73f73b:	movaps 0x90(%rsp),%xmm0
  73f743:	je     73f774 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x1a4>
  73f745:	test   %r13,%r13
  73f748:	je     73fbc1 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x5f1>
  73f74e:	mov    (%r14),%ecx
  73f751:	lea    0xc(%r14),%rdx
  73f755:	lea    0x1(%r13),%rsi
  73f759:	mov    $0x1,%eax
  73f75e:	xchg   %ax,%ax
  73f760:	cmp    (%rdx),%ecx
  73f762:	jne    73f774 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x1a4>
  73f764:	inc    %rax
  73f767:	add    $0xc,%rdx
  73f76b:	dec    %rsi
  73f76e:	cmp    $0x2,%rsi
  73f772:	ja     73f760 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x190>
  73f774:	sub    %rax,%r13
  73f777:	jb     73fc90 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x6c0>
  73f77d:	mov    %r13,0xb8(%rsp)
  73f785:	test   %rbx,%rbx
  73f788:	jne    73f830 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x260>
  73f78e:	mov    %r15,%rcx
  73f791:	cmp    $0x1,%r15
  73f795:	je     73f7d4 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x204>
  73f797:	test   %r15,%r15
  73f79a:	je     73fbc1 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x5f1>
  73f7a0:	mov    (%r12),%edx
  73f7a4:	lea    0xc(%r12),%rsi
  73f7a9:	lea    0x1(%r15),%rdi
  73f7ad:	mov    $0x1,%ecx
  73f7b2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  73f7c0:	cmp    (%rsi),%edx
  73f7c2:	jne    73f7d4 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x204>
  73f7c4:	inc    %rcx
  73f7c7:	add    $0xc,%rsi
  73f7cb:	dec    %rdi
  73f7ce:	cmp    $0x2,%rdi
  73f7d2:	ja     73f7c0 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x1f0>
  73f7d4:	sub    %rcx,%r15
  73f7d7:	jb     73fc90 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x6c0>
  73f7dd:	lea    (%rcx,%rcx,2),%rdx
  73f7e1:	lea    (%r12,%rdx,4),%rdx
  73f7e5:	mov    %rdx,0xc0(%rsp)
  73f7ed:	mov    %r15,0xc8(%rsp)
  73f7f5:	test   %r12,%r12
  73f7f8:	je     73fbc1 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x5f1>
  73f7fe:	lea    (%rax,%rax,2),%rsi
  73f802:	mov    %r14,0x30(%rsp)
  73f807:	mov    %rax,0x38(%rsp)
  73f80c:	mov    %r12,0x40(%rsp)
  73f811:	mov    %rcx,0x48(%rsp)
  73f816:	mov    %rdx,%r12
  73f819:	mov    $0x0,%ebx
  73f81e:	test   %r14,%r14
  73f821:	lea    (%r14,%rsi,4),%r14
  73f825:	jne    73f700 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x130>
  73f82b:	jmp    73fbc1 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x5f1>
  73f830:	movq   $0x0,0xd0(%rsp)
  73f83c:	mov    %r12,%rsi
  73f83f:	mov    %r15,%rdx
  73f842:	mov    %r15,%rdi
  73f845:	cmp    $0x1,%r15
  73f849:	je     73f878 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x2a8>
  73f84b:	test   %rdx,%rdx
  73f84e:	je     73fbc1 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x5f1>
  73f854:	mov    (%rsi),%ecx
  73f856:	lea    0xc(%rsi),%r8
  73f85a:	lea    0x1(%rdx),%r9
  73f85e:	mov    $0x1,%edi
  73f863:	cmp    (%r8),%ecx
  73f866:	jne    73f878 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x2a8>
  73f868:	inc    %rdi
  73f86b:	add    $0xc,%r8
  73f86f:	dec    %r9
  73f872:	cmp    $0x2,%r9
  73f876:	ja     73f863 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x293>
  73f878:	mov    %rdx,%r15
  73f87b:	sub    %rdi,%r15
  73f87e:	jb     73fc90 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x6c0>
  73f884:	lea    (%rdi,%rdi,2),%r9
  73f888:	lea    (%rsi,%r9,4),%r12
  73f88c:	dec    %rbx
  73f88f:	jne    73f83c <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x26c>
  73f891:	mov    %r12,0xc0(%rsp)
  73f899:	mov    %r15,0xc8(%rsp)
  73f8a1:	mov    %r15,%rcx
  73f8a4:	cmp    $0x1,%r15
  73f8a8:	je     73f8df <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x30f>
  73f8aa:	test   %r15,%r15
  73f8ad:	je     73fbc1 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x5f1>
  73f8b3:	mov    (%r12),%r8d
  73f8b7:	lea    (%rsi,%r9,4),%rsi
  73f8bb:	add    $0xc,%rsi
  73f8bf:	sub    %rdi,%rdx
  73f8c2:	inc    %rdx
  73f8c5:	mov    $0x1,%ecx
  73f8ca:	cmp    (%rsi),%r8d
  73f8cd:	jne    73f8df <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x30f>
  73f8cf:	inc    %rcx
  73f8d2:	add    $0xc,%rsi
  73f8d6:	dec    %rdx
  73f8d9:	cmp    $0x2,%rdx
  73f8dd:	ja     73f8ca <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x2fa>
  73f8df:	sub    %rcx,%r15
  73f8e2:	jb     73fc90 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x6c0>
  73f8e8:	lea    (%rcx,%rcx,2),%rdx
  73f8ec:	lea    (%r12,%rdx,4),%rdx
  73f8f0:	mov    %rdx,0xc0(%rsp)
  73f8f8:	mov    %r15,0xc8(%rsp)
  73f900:	jmp    73f7fe <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x22e>
  73f905:	mov    %r14,0xb0(%rsp)
  73f90d:	movss  0x158(%rsp),%xmm3
  73f916:	xorps  %xmm0,%xmm0
  73f919:	ucomiss %xmm0,%xmm3
  73f91c:	jne    73f934 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x364>
  73f91e:	jp     73f934 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x364>
  73f920:	mov    0x18(%rsp),%r14
  73f925:	mov    0x10(%rsp),%r13
  73f92a:	mov    0x8(%rsp),%rbp
  73f92f:	jmp    73fa22 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x452>
  73f934:	movsd  0x150(%rsp),%xmm5
  73f93d:	movss  0x15c(%rsp),%xmm6
  73f946:	mov    0x160(%rsp),%rbx
  73f94e:	movaps %xmm5,%xmm7
  73f951:	shufps $0x55,%xmm5,%xmm7
  73f955:	testb  $0x1,0x28(%rsp)
  73f95a:	mov    0x18(%rsp),%r14
  73f95f:	mov    0x10(%rsp),%r13
  73f964:	mov    0x8(%rsp),%rbp
  73f969:	movaps 0xa0(%rsp),%xmm2
  73f971:	movaps 0x90(%rsp),%xmm4
  73f979:	je     73fb32 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x562>
  73f97f:	mov    0x118(%rsp),%rax
  73f987:	cmp    %rbx,%rax
  73f98a:	jne    73fa5a <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x48a>
  73f990:	movaps 0x100(%rsp),%xmm0
  73f998:	ucomiss %xmm7,%xmm0
  73f99b:	jne    73fa5a <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x48a>
  73f9a1:	jp     73fa5a <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x48a>
  73f9a7:	movss  0x4(%rsp),%xmm0
  73f9ad:	ucomiss %xmm6,%xmm0
  73f9b0:	jne    73fa5a <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x48a>
  73f9b6:	jp     73fa5a <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x48a>
  73f9bc:	movaps %xmm5,%xmm0
  73f9bf:	addss  %xmm3,%xmm0
  73f9c3:	ucomiss %xmm4,%xmm0
  73f9c6:	jb     73fa57 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x487>
  73f9cc:	movaps %xmm2,%xmm1
  73f9cf:	addss  %xmm4,%xmm1
  73f9d3:	ucomiss %xmm5,%xmm1
  73f9d6:	jb     73fa57 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x487>
  73f9d8:	movaps %xmm1,%xmm2
  73f9db:	maxss  %xmm0,%xmm2
  73f9df:	movaps %xmm2,%xmm3
  73f9e2:	cmpunordss %xmm2,%xmm3
  73f9e7:	movaps %xmm3,%xmm0
  73f9ea:	andnps %xmm2,%xmm0
  73f9ed:	andps  %xmm1,%xmm3
  73f9f0:	orps   %xmm0,%xmm3
  73f9f3:	movaps %xmm4,%xmm0
  73f9f6:	minss  %xmm5,%xmm0
  73f9fa:	movaps %xmm0,%xmm1
  73f9fd:	cmpunordss %xmm0,%xmm1
  73fa02:	movaps %xmm1,%xmm2
  73fa05:	andnps %xmm0,%xmm2
  73fa08:	andps  %xmm4,%xmm1
  73fa0b:	orps   %xmm2,%xmm1
  73fa0e:	subss  %xmm1,%xmm3
  73fa12:	movaps %xmm3,0xa0(%rsp)
  73fa1a:	movaps %xmm1,0x90(%rsp)
  73fa22:	lea    0x30(%rsp),%rdi
  73fa27:	lea    0xb0(%rsp),%rsi
  73fa2f:	call   798540 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control>
  73fa34:	cmpq   $0x0,0x30(%rsp)
  73fa3a:	mov    $0x1,%al
  73fa3c:	movaps 0xa0(%rsp),%xmm2
  73fa44:	movaps 0x90(%rsp),%xmm0
  73fa4c:	jne    73f6ac <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0xdc>
  73fa52:	jmp    73fbd2 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x602>
  73fa57:	mov    %rax,%rbx
  73fa5a:	movaps %xmm7,0x130(%rsp)
  73fa62:	movss  %xmm6,0x20(%rsp)
  73fa68:	movss  %xmm3,0x24(%rsp)
  73fa6e:	movaps %xmm5,0x80(%rsp)
  73fa76:	cmpl   $0xffffffff,(%r14)
  73fa7a:	jne    73fb4e <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x57e>
  73fa80:	unpcklps 0x100(%rsp),%xmm4
  73fa88:	mov    0x68(%rsp),%rax
  73fa8d:	movss  (%rax),%xmm0
  73fa91:	mov    0x70(%rsp),%rax
  73fa96:	movss  (%rax),%xmm1
  73fa9a:	unpcklps %xmm0,%xmm1
  73fa9d:	addps  %xmm4,%xmm1
  73faa0:	movlps %xmm1,0x120(%rsp)
  73faa8:	movss  %xmm2,0x128(%rsp)
  73fab1:	movss  0x4(%rsp),%xmm0
  73fab7:	movss  %xmm0,0x12c(%rsp)
  73fac0:	mov    0x78(%rsp),%rcx
  73fac5:	mov    0x10(%rcx),%rax
  73fac9:	mov    %rax,0x150(%rsp)
  73fad1:	movups (%rcx),%xmm0
  73fad4:	movaps %xmm0,0x140(%rsp)
  73fadc:	movups 0x0(%rbp),%xmm0
  73fae0:	movaps %xmm0,0x50(%rsp)
  73fae5:	lea    0x30(%rsp),%r15
  73faea:	mov    %r15,%rdi
  73faed:	mov    $0x46,%esi
  73faf2:	mov    $0x82,%edx
  73faf7:	mov    $0xf0,%ecx
  73fafc:	mov    $0x60,%r8d
  73fb02:	call   *0x37a640(%rip)        # aba148 <_DYNAMIC+0x2d8>
  73fb08:	mov    %r13,%rdi
  73fb0b:	lea    0x120(%rsp),%rsi
  73fb13:	lea    0x140(%rsp),%rdx
  73fb1b:	lea    0x50(%rsp),%rcx
  73fb20:	mov    %r15,%r8
  73fb23:	call   *0x37a627(%rip)        # aba150 <_DYNAMIC+0x2e0>
  73fb29:	mov    %eax,(%r14)
  73fb2c:	mov    %edx,0x4(%r14)
  73fb30:	jmp    73fb4e <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x57e>
  73fb32:	movaps %xmm7,0x130(%rsp)
  73fb3a:	movss  %xmm6,0x20(%rsp)
  73fb40:	movss  %xmm3,0x24(%rsp)
  73fb46:	movaps %xmm5,0x80(%rsp)
  73fb4e:	lea    0x30(%rsp),%rdi
  73fb53:	lea    0xb0(%rsp),%rsi
  73fb5b:	call   798540 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control>
  73fb60:	cmpq   $0x0,0x30(%rsp)
  73fb66:	mov    $0x1,%al
  73fb68:	mov    %rax,0x28(%rsp)
  73fb6d:	mov    %rbx,0x118(%rsp)
  73fb75:	movaps 0x130(%rsp),%xmm0
  73fb7d:	movaps %xmm0,0x100(%rsp)
  73fb85:	movaps 0x80(%rsp),%xmm3
  73fb8d:	movss  0x24(%rsp),%xmm2
  73fb93:	movss  0x20(%rsp),%xmm1
  73fb99:	jne    73f6a3 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0xd3>
  73fb9f:	movss  %xmm1,0x4(%rsp)
  73fba5:	mov    $0x1,%al
  73fba7:	jmp    73fbe4 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x614>
  73fba9:	xor    %eax,%eax
  73fbab:	jmp    73fbaf <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x5df>
  73fbad:	mov    $0x1,%al
  73fbaf:	add    $0x178,%rsp
  73fbb6:	pop    %rbx
  73fbb7:	pop    %r12
  73fbb9:	pop    %r13
  73fbbb:	pop    %r14
  73fbbd:	pop    %r15
  73fbbf:	pop    %rbp
  73fbc0:	ret
  73fbc1:	mov    $0x1,%al
  73fbc3:	mov    0x18(%rsp),%r14
  73fbc8:	mov    0x10(%rsp),%r13
  73fbcd:	mov    0x8(%rsp),%rbp
  73fbd2:	testb  $0x1,0x28(%rsp)
  73fbd7:	je     73fbaf <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x5df>
  73fbd9:	unpcklps 0x100(%rsp),%xmm0
  73fbe1:	movaps %xmm0,%xmm3
  73fbe4:	cmpl   $0xffffffff,(%r14)
  73fbe8:	jne    73fbaf <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x5df>
  73fbea:	mov    0x68(%rsp),%rax
  73fbef:	movss  (%rax),%xmm0
  73fbf3:	mov    0x70(%rsp),%rax
  73fbf8:	movss  (%rax),%xmm1
  73fbfc:	unpcklps %xmm0,%xmm1
  73fbff:	addps  %xmm1,%xmm3
  73fc02:	movlps %xmm3,0x50(%rsp)
  73fc07:	movss  %xmm2,0x58(%rsp)
  73fc0d:	movss  0x4(%rsp),%xmm0
  73fc13:	movss  %xmm0,0x5c(%rsp)
  73fc19:	mov    0x78(%rsp),%rcx
  73fc1e:	mov    0x10(%rcx),%rax
  73fc22:	mov    %rax,0xc0(%rsp)
  73fc2a:	movups (%rcx),%xmm0
  73fc2d:	movaps %xmm0,0xb0(%rsp)
  73fc35:	movups 0x0(%rbp),%xmm0
  73fc39:	movaps %xmm0,0x30(%rsp)
  73fc3e:	lea    0x140(%rsp),%r15
  73fc46:	mov    %r15,%rdi
  73fc49:	mov    $0x46,%esi
  73fc4e:	mov    $0x82,%edx
  73fc53:	mov    $0xf0,%ecx
  73fc58:	mov    $0x60,%r8d
  73fc5e:	call   *0x37a4e4(%rip)        # aba148 <_DYNAMIC+0x2d8>
  73fc64:	lea    0x50(%rsp),%rsi
  73fc69:	lea    0xb0(%rsp),%rdx
  73fc71:	lea    0x30(%rsp),%rcx
  73fc76:	mov    %r13,%rdi
  73fc79:	mov    %r15,%r8
  73fc7c:	call   *0x37a4ce(%rip)        # aba150 <_DYNAMIC+0x2e0>
  73fc82:	mov    %eax,(%r14)
  73fc85:	mov    $0x1,%al
  73fc87:	mov    %edx,0x4(%r14)
  73fc8b:	jmp    73fbaf <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x5df>
  73fc90:	lea    -0x67003e(%rip),%rdi        # cfc59 <GCC_except_table0+0xd88d>
  73fc97:	lea    0x35c022(%rip),%rdx        # a9bcc0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2378>
  73fc9e:	mov    $0x13,%esi
  73fca3:	call   *0x37a43f(%rip)        # aba0e8 <_DYNAMIC+0x278>

<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::present_inner::{closure#44}> bytes=1391 frame=120

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000073fd10 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_>:
  73fd10:	push   %rbp
  73fd11:	push   %r15
  73fd13:	push   %r14
  73fd15:	push   %r13
  73fd17:	push   %r12
  73fd19:	push   %rbx
  73fd1a:	sub    $0x48,%rsp
  73fd1e:	mov    %rdx,0x10(%rsp)
  73fd23:	mov    %rdi,0x18(%rsp)
  73fd28:	mov    0x10(%rsi),%rbx
  73fd2c:	test   %rbx,%rbx
  73fd2f:	mov    %rsi,0x8(%rsp)
  73fd34:	je     73fd79 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x69>
  73fd36:	mov    0x8(%rsi),%rbp
  73fd3a:	lea    -0x1(%rbx),%r15
  73fd3e:	mov    $0x28,%r13d
  73fd44:	xor    %r14d,%r14d
  73fd47:	nopw   0x0(%rax,%rax,1)
  73fd50:	mov    -0x28(%rbp,%r13,1),%rsi
  73fd55:	mov    0x10(%rsp),%rdi
  73fd5a:	call   75e1a0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_>
  73fd5f:	test   $0x1,%al
  73fd61:	je     73fd7e <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x6e>
  73fd63:	mov    %edx,-0x4(%rbp,%r13,1)
  73fd68:	inc    %r14
  73fd6b:	add    $0x28,%r13
  73fd6f:	cmp    %r14,%rbx
  73fd72:	jne    73fd50 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x40>
  73fd74:	mov    %rbx,%r14
  73fd77:	jmp    73fde1 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0xd1>
  73fd79:	xor    %r14d,%r14d
  73fd7c:	jmp    73fde1 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0xd1>
  73fd7e:	lea    0x1(%r14),%rax
  73fd82:	cmp    %rbx,%rax
  73fd85:	jae    73fde1 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0xd1>
  73fd87:	sub    %r14,%r15
  73fd8a:	jmp    73fd99 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x89>
  73fd8c:	nopl   0x0(%rax)
  73fd90:	add    $0x28,%r13
  73fd94:	dec    %r15
  73fd97:	je     73fde1 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0xd1>
  73fd99:	mov    %rbp,%r12
  73fd9c:	add    %r13,%r12
  73fd9f:	mov    0x0(%rbp,%r13,1),%rsi
  73fda4:	mov    0x10(%rsp),%rdi
  73fda9:	call   75e1a0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_>
  73fdae:	cmp    $0x1,%rax
  73fdb2:	jne    73fd90 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x80>
  73fdb4:	mov    %edx,0x24(%rbp,%r13,1)
  73fdb9:	lea    (%r14,%r14,4),%rax
  73fdbd:	mov    0x20(%r12),%rcx
  73fdc2:	mov    %rcx,0x20(%rbp,%rax,8)
  73fdc7:	movups (%r12),%xmm0
  73fdcc:	movups 0x10(%r12),%xmm1
  73fdd2:	movups %xmm1,0x10(%rbp,%rax,8)
  73fdd7:	movups %xmm0,0x0(%rbp,%rax,8)
  73fddc:	inc    %r14
  73fddf:	jmp    73fd90 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x80>
  73fde1:	mov    0x8(%rsp),%rax
  73fde6:	mov    0x28(%rax),%rbp
  73fdea:	test   %rbp,%rbp
  73fded:	mov    %r14,0x20(%rsp)
  73fdf2:	je     73fe39 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x129>
  73fdf4:	mov    0x20(%rax),%r13
  73fdf8:	lea    -0x1(%rbp),%r15
  73fdfc:	mov    $0x40,%ebx
  73fe01:	xor    %r12d,%r12d
  73fe04:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  73fe10:	mov    -0x10(%r13,%rbx,1),%rsi
  73fe15:	mov    0x10(%rsp),%rdi
  73fe1a:	call   75e1a0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_>
  73fe1f:	test   $0x1,%al
  73fe21:	je     73fe3e <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x12e>
  73fe23:	mov    %edx,-0x8(%r13,%rbx,1)
  73fe28:	inc    %r12
  73fe2b:	add    $0x40,%rbx
  73fe2f:	cmp    %r12,%rbp
  73fe32:	jne    73fe10 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x100>
  73fe34:	mov    %rbp,%r12
  73fe37:	jmp    73feb1 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x1a1>
  73fe39:	xor    %r12d,%r12d
  73fe3c:	jmp    73feb1 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x1a1>
  73fe3e:	lea    0x1(%r12),%rax
  73fe43:	cmp    %rbp,%rax
  73fe46:	jae    73feb1 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x1a1>
  73fe48:	sub    %r12,%r15
  73fe4b:	jmp    73fe5c <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x14c>
  73fe4d:	nopl   (%rax)
  73fe50:	mov    %r14,%rbp
  73fe53:	add    $0x40,%rbx
  73fe57:	dec    %r15
  73fe5a:	je     73feb1 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x1a1>
  73fe5c:	mov    %rbp,%r14
  73fe5f:	lea    (%rbx,%r13,1),%rbp
  73fe63:	mov    0x30(%r13,%rbx,1),%rsi
  73fe68:	mov    0x10(%rsp),%rdi
  73fe6d:	call   75e1a0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_>
  73fe72:	cmp    $0x1,%rax
  73fe76:	jne    73fe50 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x140>
  73fe78:	mov    %edx,0x38(%r13,%rbx,1)
  73fe7d:	mov    %r12,%rax
  73fe80:	shl    $0x6,%rax
  73fe84:	movups 0x0(%rbp),%xmm0
  73fe88:	movups 0x10(%rbp),%xmm1
  73fe8c:	movups 0x20(%rbp),%xmm2
  73fe90:	movups 0x30(%rbp),%xmm3
  73fe94:	movups %xmm3,0x30(%r13,%rax,1)
  73fe9a:	movups %xmm2,0x20(%r13,%rax,1)
  73fea0:	movups %xmm1,0x10(%r13,%rax,1)
  73fea6:	movups %xmm0,0x0(%r13,%rax,1)
  73feac:	inc    %r12
  73feaf:	jmp    73fe50 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x140>
  73feb1:	mov    0x20(%rsp),%r14
  73feb6:	test   %r14,%r14
  73feb9:	je     73ff20 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x210>
  73febb:	test   %r12,%r12
  73febe:	je     73ff7a <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x26a>
  73fec4:	mov    0x8(%rsp),%rcx
  73fec9:	mov    (%rcx),%rax
  73fecc:	mov    0x8(%rcx),%rbx
  73fed0:	cmp    %r14,%rax
  73fed3:	jbe    73ffd3 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x2c3>
  73fed9:	shl    $0x3,%rax
  73fedd:	lea    (%rax,%rax,4),%r13
  73fee1:	lea    0x0(,%r14,8),%rax
  73fee9:	lea    (%rax,%rax,4),%rbp
  73feed:	mov    $0x8,%edx
  73fef2:	mov    %rbx,%rdi
  73fef5:	mov    %r13,%rsi
  73fef8:	mov    %rbp,%rcx
  73fefb:	call   *0x37a257(%rip)        # aba158 <_DYNAMIC+0x2e8>
  73ff01:	mov    %rax,%r15
  73ff04:	test   %rax,%rax
  73ff07:	jne    73ffd6 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x2c6>
  73ff0d:	mov    $0x8,%edi
  73ff12:	mov    %rbp,%rsi
  73ff15:	call   *0x37a245(%rip)        # aba160 <_DYNAMIC+0x2f0>
  73ff1b:	jmp    74013e <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x42e>
  73ff20:	test   %r12,%r12
  73ff23:	je     74007b <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x36b>
  73ff29:	mov    0x8(%rsp),%r14
  73ff2e:	mov    0x18(%r14),%r15
  73ff32:	mov    0x20(%r14),%rbx
  73ff36:	cmp    %r12,%r15
  73ff39:	jbe    740094 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x384>
  73ff3f:	shl    $0x6,%r15
  73ff43:	mov    %r12,%r13
  73ff46:	shl    $0x6,%r13
  73ff4a:	mov    $0x8,%edx
  73ff4f:	mov    %rbx,%rdi
  73ff52:	mov    %r15,%rsi
  73ff55:	mov    %r13,%rcx
  73ff58:	call   *0x37a1fa(%rip)        # aba158 <_DYNAMIC+0x2e8>
  73ff5e:	test   %rax,%rax
  73ff61:	jne    740097 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x387>
  73ff67:	mov    $0x8,%edi
  73ff6c:	mov    %r13,%rsi
  73ff6f:	call   *0x37a1eb(%rip)        # aba160 <_DYNAMIC+0x2f0>
  73ff75:	jmp    74013e <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x42e>
  73ff7a:	mov    0x8(%rsp),%rcx
  73ff7f:	mov    (%rcx),%rax
  73ff82:	mov    0x8(%rcx),%r15
  73ff86:	cmp    %r14,%rax
  73ff89:	jbe    7400fa <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x3ea>
  73ff8f:	shl    $0x3,%rax
  73ff93:	lea    (%rax,%rax,4),%r12
  73ff97:	lea    0x0(,%r14,8),%rax
  73ff9f:	lea    (%rax,%rax,4),%r13
  73ffa3:	mov    $0x8,%edx
  73ffa8:	mov    %r15,%rdi
  73ffab:	mov    %r12,%rsi
  73ffae:	mov    %r13,%rcx
  73ffb1:	call   *0x37a1a1(%rip)        # aba158 <_DYNAMIC+0x2e8>
  73ffb7:	test   %rax,%rax
  73ffba:	jne    7400fd <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x3ed>
  73ffc0:	mov    $0x8,%edi
  73ffc5:	mov    %r13,%rsi
  73ffc8:	call   *0x37a192(%rip)        # aba160 <_DYNAMIC+0x2f0>
  73ffce:	jmp    74013e <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x42e>
  73ffd3:	mov    %rbx,%r15
  73ffd6:	mov    0x8(%rsp),%rax
  73ffdb:	mov    0x18(%rax),%rbp
  73ffdf:	mov    0x20(%rax),%rbx
  73ffe3:	cmp    %r12,%rbp
  73ffe6:	jbe    74001f <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x30f>
  73ffe8:	shl    $0x6,%rbp
  73ffec:	mov    %r12,%r13
  73ffef:	shl    $0x6,%r13
  73fff3:	mov    $0x8,%edx
  73fff8:	mov    %rbx,%rdi
  73fffb:	mov    %rbp,%rsi
  73fffe:	mov    %r13,%rcx
  740001:	call   *0x37a151(%rip)        # aba158 <_DYNAMIC+0x2e8>
  740007:	test   %rax,%rax
  74000a:	jne    740022 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x312>
  74000c:	mov    $0x8,%edi
  740011:	mov    %r13,%rsi
  740014:	call   *0x37a146(%rip)        # aba160 <_DYNAMIC+0x2f0>
  74001a:	jmp    74013e <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x42e>
  74001f:	mov    %rbx,%rax
  740022:	mov    %r15,0x28(%rsp)
  740027:	mov    %r14,0x30(%rsp)
  74002c:	mov    %rax,0x38(%rsp)
  740031:	mov    %r12,0x40(%rsp)
  740036:	call   *0x37a07c(%rip)        # aba0b8 <_DYNAMIC+0x248>
  74003c:	mov    $0x20,%edi
  740041:	mov    $0x8,%esi
  740046:	call   *0x37a074(%rip)        # aba0c0 <_DYNAMIC+0x250>
  74004c:	test   %rax,%rax
  74004f:	je     74012e <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x41e>
  740055:	movups 0x28(%rsp),%xmm0
  74005a:	movups 0x38(%rsp),%xmm1
  74005f:	movups %xmm1,0x10(%rax)
  740063:	movups %xmm0,(%rax)
  740066:	mov    0x18(%rsp),%rcx
  74006b:	mov    %rax,0x8(%rcx)
  74006f:	movq   $0x3,(%rcx)
  740076:	jmp    74011f <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x40f>
  74007b:	xor    %eax,%eax
  74007d:	mov    0x8(%rsp),%r14
  740082:	mov    0x18(%rsp),%rcx
  740087:	mov    %rax,(%rcx)
  74008a:	mov    (%r14),%rax
  74008d:	test   %rax,%rax
  740090:	jne    7400b4 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x3a4>
  740092:	jmp    7400cb <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x3bb>
  740094:	mov    %rbx,%rax
  740097:	mov    0x18(%rsp),%rcx
  74009c:	mov    %rax,0x8(%rcx)
  7400a0:	mov    %r12,0x10(%rcx)
  7400a4:	mov    $0x2,%eax
  7400a9:	mov    %rax,(%rcx)
  7400ac:	mov    (%r14),%rax
  7400af:	test   %rax,%rax
  7400b2:	je     7400cb <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x3bb>
  7400b4:	mov    0x8(%r14),%rdi
  7400b8:	shl    $0x3,%rax
  7400bc:	lea    (%rax,%rax,4),%rsi
  7400c0:	mov    $0x8,%edx
  7400c5:	call   *0x379fe5(%rip)        # aba0b0 <_DYNAMIC+0x240>
  7400cb:	test   %r12,%r12
  7400ce:	jne    74011f <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x40f>
  7400d0:	mov    0x18(%r14),%rsi
  7400d4:	test   %rsi,%rsi
  7400d7:	je     74011f <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x40f>
  7400d9:	mov    0x20(%r14),%rdi
  7400dd:	shl    $0x6,%rsi
  7400e1:	mov    $0x8,%edx
  7400e6:	add    $0x48,%rsp
  7400ea:	pop    %rbx
  7400eb:	pop    %r12
  7400ed:	pop    %r13
  7400ef:	pop    %r14
  7400f1:	pop    %r15
  7400f3:	pop    %rbp
  7400f4:	jmp    *0x379fb6(%rip)        # aba0b0 <_DYNAMIC+0x240>
  7400fa:	mov    %r15,%rax
  7400fd:	mov    0x18(%rsp),%rcx
  740102:	mov    %rax,0x8(%rcx)
  740106:	mov    %r14,0x10(%rcx)
  74010a:	movq   $0x1,(%rcx)
  740111:	mov    0x8(%rsp),%r14
  740116:	mov    0x18(%r14),%rsi
  74011a:	test   %rsi,%rsi
  74011d:	jne    7400d9 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x3c9>
  74011f:	add    $0x48,%rsp
  740123:	pop    %rbx
  740124:	pop    %r12
  740126:	pop    %r13
  740128:	pop    %r14
  74012a:	pop    %r15
  74012c:	pop    %rbp
  74012d:	ret
  74012e:	mov    $0x8,%edi
  740133:	mov    $0x20,%esi
  740138:	call   *0x379f8a(%rip)        # aba0c8 <_DYNAMIC+0x258>
  74013e:	ud2
  740140:	mov    %rax,%r14
  740143:	mov    $0x8,%edx
  740148:	mov    %r15,%rdi
  74014b:	mov    %r12,%rsi
  74014e:	jmp    7401ae <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x49e>
  740150:	mov    %rax,0x10(%rsp)
  740155:	mov    $0x8,%edx
  74015a:	mov    %rbx,%rdi
  74015d:	mov    %r15,%rsi
  740160:	call   *0x379f4a(%rip)        # aba0b0 <_DYNAMIC+0x240>
  740166:	xor    %ebx,%ebx
  740168:	jmp    74020a <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x4fa>
  74016d:	mov    %rax,%r13
  740170:	mov    0x379f39(%rip),%r12        # aba0b0 <_DYNAMIC+0x240>
  740177:	mov    $0x8,%edx
  74017c:	mov    %rbx,%rdi
  74017f:	mov    %rbp,%rsi
  740182:	call   *%r12
  740185:	shl    $0x3,%r14
  740189:	lea    (%r14,%r14,4),%rsi
  74018d:	mov    $0x8,%edx
  740192:	mov    %r15,%rdi
  740195:	call   *%r12
  740198:	mov    %r13,%rdi
  74019b:	call   a98590 <_Unwind_Resume@plt>
  7401a0:	mov    %rax,%r14
  7401a3:	mov    $0x8,%edx
  7401a8:	mov    %rbx,%rdi
  7401ab:	mov    %r13,%rsi
  7401ae:	call   *0x379efc(%rip)        # aba0b0 <_DYNAMIC+0x240>
  7401b4:	jmp    74023c <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x52c>
  7401b9:	mov    %rax,0x10(%rsp)
  7401be:	shl    $0x6,%r12
  7401c2:	add    %r12,%r13
  7401c5:	shl    $0x6,%r14
  7401c9:	sub    %rbx,%r14
  7401cc:	mov    %r13,%rdi
  7401cf:	mov    %rbp,%rsi
  7401d2:	mov    %r14,%rdx
  7401d5:	jmp    7401f9 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x4e9>
  7401d7:	mov    %rax,0x10(%rsp)
  7401dc:	lea    (%r14,%r14,4),%rax
  7401e0:	lea    0x0(,%rax,8),%rdi
  7401e8:	add    %rbp,%rdi
  7401eb:	shl    $0x3,%rbx
  7401ef:	lea    (%rbx,%rbx,4),%rdx
  7401f3:	sub    %r13,%rdx
  7401f6:	mov    %r12,%rsi
  7401f9:	call   *0x379f21(%rip)        # aba120 <memmove@GLIBC_2.2.5>
  7401ff:	jmp    740208 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x4f8>
  740201:	jmp    740203 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x4f3>
  740203:	mov    %rax,0x10(%rsp)
  740208:	mov    $0x1,%bl
  74020a:	mov    0x8(%rsp),%rax
  74020f:	mov    (%rax),%rax
  740212:	test   %rax,%rax
  740215:	je     740233 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x523>
  740217:	mov    0x8(%rsp),%rcx
  74021c:	mov    0x8(%rcx),%rdi
  740220:	shl    $0x3,%rax
  740224:	lea    (%rax,%rax,4),%rsi
  740228:	mov    $0x8,%edx
  74022d:	call   *0x379e7d(%rip)        # aba0b0 <_DYNAMIC+0x240>
  740233:	test   %bl,%bl
  740235:	mov    0x10(%rsp),%r14
  74023a:	je     740277 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x567>
  74023c:	mov    0x8(%rsp),%rax
  740241:	mov    0x18(%rax),%rsi
  740245:	test   %rsi,%rsi
  740248:	je     740277 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x567>
  74024a:	mov    0x8(%rsp),%rax
  74024f:	mov    0x20(%rax),%rdi
  740253:	shl    $0x6,%rsi
  740257:	mov    $0x8,%edx
  74025c:	call   *0x379e4e(%rip)        # aba0b0 <_DYNAMIC+0x240>
  740262:	mov    %r14,%rdi
  740265:	call   a98590 <_Unwind_Resume@plt>
  74026a:	mov    %rax,%r14
  74026d:	lea    0x28(%rsp),%rdi
  740272:	call   74e920 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime6scroll7ColumnsECs9C2G9YFESsD_29canonical_text_public_control>
  740277:	mov    %r14,%rdi
  74027a:	call   a98590 <_Unwind_Resume@plt>

core::panicking::assert_failed::<gpui_canvas::text::layout::TextPosition, gpui_canvas::text::layout::TextPosition> bytes=50 frame=40

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000074f553 <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextPositionBM_ECs9C2G9YFESsD_29canonical_text_public_control>:
  74f553:	sub    $0x28,%rsp
  74f557:	lea    0x18(%rsp),%rax
  74f55c:	mov    %rdi,(%rax)
  74f55f:	lea    0x20(%rsp),%rcx
  74f564:	mov    %rsi,(%rcx)
  74f567:	mov    %rdx,0x8(%rsp)
  74f56c:	lea    0x34a69d(%rip),%rdx        # a99c10 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2c8>
  74f573:	push   $0x1
  74f575:	pop    %rdi
  74f576:	mov    %rax,%rsi
  74f579:	mov    %rdx,%r8
  74f57c:	xor    %r9d,%r9d
  74f57f:	call   *0x36acb3(%rip)        # aba238 <_DYNAMIC+0x3c8>

core::panicking::assert_failed::<gpui_canvas::text::layout::TextSelection, gpui_canvas::text::layout::TextSelection> bytes=56 frame=40

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000074f585 <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout13TextSelectionBM_ECs9C2G9YFESsD_29canonical_text_public_control>:
  74f585:	sub    $0x28,%rsp
  74f589:	lea    0x18(%rsp),%rax
  74f58e:	mov    %rdi,(%rax)
  74f591:	lea    0x20(%rsp),%rcx
  74f596:	mov    %rsi,(%rcx)
  74f599:	lea    0x34b0f8(%rip),%rdx        # a9a698 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xd50>
  74f5a0:	mov    %rdx,0x8(%rsp)
  74f5a5:	lea    0x34a684(%rip),%rdx        # a99c30 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2e8>
  74f5ac:	xor    %edi,%edi
  74f5ae:	mov    %rax,%rsi
  74f5b1:	mov    %rdx,%r8
  74f5b4:	xor    %r9d,%r9d
  74f5b7:	call   *0x36ac7b(%rip)        # aba238 <_DYNAMIC+0x3c8>

core::panicking::assert_failed::<(alloc::string::String, gpui_canvas::text::layout::TextSelection, *const gpui_canvas::text::layout::TextGeometry, u64), (alloc::string::String, gpui_canvas::text::layout::TextSelection, *const gpui_canvas::text::layout::TextGeometry, u64)> bytes=56 frame=40

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000074f636 <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedTNtNtCscdodAO9FK5_5alloc6string6StringNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout13TextSelectionPNtB1q_12TextGeometryyEBM_ECs9C2G9YFESsD_29canonical_text_public_control>:
  74f636:	sub    $0x28,%rsp
  74f63a:	lea    0x18(%rsp),%rax
  74f63f:	mov    %rdi,(%rax)
  74f642:	lea    0x20(%rsp),%rcx
  74f647:	mov    %rsi,(%rcx)
  74f64a:	lea    0x34afff(%rip),%rdx        # a9a650 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xd08>
  74f651:	mov    %rdx,0x8(%rsp)
  74f656:	lea    0x34a633(%rip),%rdx        # a99c90 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x348>
  74f65d:	xor    %edi,%edi
  74f65f:	mov    %rax,%rsi
  74f662:	mov    %rdx,%r8
  74f665:	xor    %r9d,%r9d
  74f668:	call   *0x36abca(%rip)        # aba238 <_DYNAMIC+0x3c8>

core::panicking::assert_failed::<(*const gpui_canvas::text::layout::TextGeometry, u64), (*const gpui_canvas::text::layout::TextGeometry, u64)> bytes=56 frame=40

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000074f66e <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedTPNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryyEBM_ECs9C2G9YFESsD_29canonical_text_public_control>:
  74f66e:	sub    $0x28,%rsp
  74f672:	lea    0x18(%rsp),%rax
  74f677:	mov    %rdi,(%rax)
  74f67a:	lea    0x20(%rsp),%rcx
  74f67f:	mov    %rsi,(%rcx)
  74f682:	lea    0x34b027(%rip),%rdx        # a9a6b0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xd68>
  74f689:	mov    %rdx,0x8(%rsp)
  74f68e:	lea    0x34a61b(%rip),%rdx        # a99cb0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x368>
  74f695:	xor    %edi,%edi
  74f697:	mov    %rax,%rsi
  74f69a:	mov    %rdx,%r8
  74f69d:	xor    %r9d,%r9d
  74f6a0:	call   *0x36ab92(%rip)        # aba238 <_DYNAMIC+0x3c8>

canonical_text_public_control::old_p_oracle::{closure#0} bytes=800 frame=296

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075cb40 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_>:
  75cb40:	push   %rbp
  75cb41:	push   %r15
  75cb43:	push   %r14
  75cb45:	push   %r13
  75cb47:	push   %r12
  75cb49:	push   %rbx
  75cb4a:	sub    $0xf8,%rsp
  75cb51:	test   %rsi,%rsi
  75cb54:	je     75cdb8 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x278>
  75cb5a:	cmpb   $0x0,0x76e(%rsi)
  75cb61:	jne    75cdbf <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x27f>
  75cb67:	cmpb   $0x1,0x76c(%rsi)
  75cb6e:	jne    75cdc6 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x286>
  75cb74:	mov    %rdi,%r14
  75cb77:	mov    $0xffffffffffffffff,%rbx
  75cb7e:	lea    0x78(%rsp),%rdi
  75cb83:	call   73dde0 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime5queryNtB3_7Context3newNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEBX_>
  75cb88:	mov    %r14,0x38(%rsp)
  75cb8d:	mov    0xb0(%rsp),%rax
  75cb95:	mov    %rax,0x48(%rsp)
  75cb9a:	test   %rax,%rax
  75cb9d:	je     75cdab <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x26b>
  75cba3:	movq   $0xffffffffffffffff,0x8(%rsp)
  75cbac:	mov    $0x3d,%ebx
  75cbb1:	xor    %ebp,%ebp
  75cbb3:	jmp    75cbd8 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x98>
  75cbb5:	data16 cs nopw 0x0(%rax,%rax,1)
  75cbc0:	mov    %r14,%r13
  75cbc3:	inc    %rbp
  75cbc6:	add    $0x40,%rbx
  75cbca:	mov    %r13,%r14
  75cbcd:	cmp    %rbp,0x48(%rsp)
  75cbd2:	je     75ccf6 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x1b6>
  75cbd8:	mov    0xb0(%rsp),%rsi
  75cbe0:	cmp    %rsi,%rbp
  75cbe3:	jae    75cd6b <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x22b>
  75cbe9:	mov    0xa8(%rsp),%rax
  75cbf1:	cmpb   $0x4,(%rax,%rbx,1)
  75cbf5:	jne    75cbc0 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x80>
  75cbf7:	mov    -0x15(%rax,%rbx,1),%r15
  75cbfc:	test   %r15,%r15
  75cbff:	je     75cd82 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x242>
  75cc05:	mov    (%r15),%r12
  75cc08:	shr    $1,%r12
  75cc0b:	je     75cc42 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x102>
  75cc0d:	call   *0x35d4a5(%rip)        # aba0b8 <_DYNAMIC+0x248>
  75cc13:	mov    $0x1,%esi
  75cc18:	mov    %r12,%rdi
  75cc1b:	call   *0x35d49f(%rip)        # aba0c0 <_DYNAMIC+0x250>
  75cc21:	test   %rax,%rax
  75cc24:	je     75cd96 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x256>
  75cc2a:	mov    %rax,%r13
  75cc2d:	add    $0x10,%r15
  75cc31:	mov    %rax,%rdi
  75cc34:	mov    %r15,%rsi
  75cc37:	mov    %r12,%rdx
  75cc3a:	call   *0x35d490(%rip)        # aba0d0 <memcpy@GLIBC_2.14>
  75cc40:	jmp    75cc48 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x108>
  75cc42:	mov    $0x1,%r13d
  75cc48:	lea    0x18(%rsp),%rdi
  75cc4d:	lea    0x78(%rsp),%rsi
  75cc52:	mov    %rbp,%rdx
  75cc55:	call   *0x35d655(%rip)        # aba2b0 <_DYNAMIC+0x440>
  75cc5b:	cmpb   $0x2,0x24(%rsp)
  75cc60:	je     75cd42 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x202>
  75cc66:	movups 0x18(%rsp),%xmm0
  75cc6b:	movaps %xmm0,0x60(%rsp)
  75cc70:	lea    0x18(%rsp),%rdi
  75cc75:	lea    0x78(%rsp),%rsi
  75cc7a:	mov    %rbp,%rdx
  75cc7d:	call   *0x35d635(%rip)        # aba2b8 <_DYNAMIC+0x448>
  75cc83:	cmpq   $0x0,0x18(%rsp)
  75cc89:	je     75cd4b <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x20b>
  75cc8f:	mov    0x28(%rsp),%rax
  75cc94:	mov    %rax,0x40(%rsp)
  75cc99:	lea    0x18(%rsp),%rdi
  75cc9e:	lea    0x78(%rsp),%rsi
  75cca3:	mov    %rbp,%rdx
  75cca6:	call   *0x35d60c(%rip)        # aba2b8 <_DYNAMIC+0x448>
  75ccac:	cmpq   $0x0,0x18(%rsp)
  75ccb2:	je     75cd54 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x214>
  75ccb8:	mov    0x28(%rsp),%rdi
  75ccbd:	call   760260 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript>
  75ccc2:	mov    %rax,%r15
  75ccc5:	movaps 0x60(%rsp),%xmm0
  75ccca:	movaps %xmm0,0x50(%rsp)
  75cccf:	mov    0x8(%rsp),%rsi
  75ccd4:	test   %rsi,%rsi
  75ccd7:	jle    75cce7 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x1a7>
  75ccd9:	mov    $0x1,%edx
  75ccde:	mov    %r14,%rdi
  75cce1:	call   *0x35d3c9(%rip)        # aba0b0 <_DYNAMIC+0x240>
  75cce7:	mov    %r13,0x10(%rsp)
  75ccec:	mov    %r12,0x8(%rsp)
  75ccf1:	jmp    75cbc3 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x83>
  75ccf6:	mov    0x8(%rsp),%rax
  75ccfb:	cmp    $0xffffffffffffffff,%rax
  75ccff:	je     75cdab <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x26b>
  75cd05:	mov    0x38(%rsp),%rcx
  75cd0a:	mov    %rax,(%rcx)
  75cd0d:	mov    0x10(%rsp),%rax
  75cd12:	mov    %rax,0x8(%rcx)
  75cd16:	mov    %r12,0x10(%rcx)
  75cd1a:	movaps 0x50(%rsp),%xmm0
  75cd1f:	movups %xmm0,0x18(%rcx)
  75cd23:	mov    0x40(%rsp),%rax
  75cd28:	mov    %rax,0x28(%rcx)
  75cd2c:	mov    %r15,0x30(%rcx)
  75cd30:	add    $0xf8,%rsp
  75cd37:	pop    %rbx
  75cd38:	pop    %r12
  75cd3a:	pop    %r13
  75cd3c:	pop    %r14
  75cd3e:	pop    %r15
  75cd40:	pop    %rbp
  75cd41:	ret
  75cd42:	lea    0x33d14f(%rip),%rdi        # a99e98 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x550>
  75cd49:	jmp    75cd5b <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x21b>
  75cd4b:	lea    0x33d15e(%rip),%rdi        # a99eb0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x568>
  75cd52:	jmp    75cd5b <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x21b>
  75cd54:	lea    0x33d16d(%rip),%rdi        # a99ec8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x580>
  75cd5b:	mov    0x8(%rsp),%rbx
  75cd60:	call   *0x35d40a(%rip)        # aba170 <_DYNAMIC+0x300>
  75cd66:	jmp    75ce01 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x2c1>
  75cd6b:	lea    0x33d0f6(%rip),%rdx        # a99e68 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x520>
  75cd72:	mov    %rbp,%rdi
  75cd75:	mov    0x8(%rsp),%rbx
  75cd7a:	call   *0x35d360(%rip)        # aba0e0 <_DYNAMIC+0x270>
  75cd80:	jmp    75ce01 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x2c1>
  75cd82:	lea    0x33d0f7(%rip),%rdi        # a99e80 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x538>
  75cd89:	mov    0x8(%rsp),%rbx
  75cd8e:	call   *0x35d3dc(%rip)        # aba170 <_DYNAMIC+0x300>
  75cd94:	jmp    75ce01 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x2c1>
  75cd96:	mov    $0x1,%edi
  75cd9b:	mov    %r12,%rsi
  75cd9e:	mov    0x8(%rsp),%rbx
  75cda3:	call   *0x35d3b7(%rip)        # aba160 <_DYNAMIC+0x2f0>
  75cda9:	jmp    75ce01 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x2c1>
  75cdab:	lea    0x33d176(%rip),%rdi        # a99f28 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x5e0>
  75cdb2:	call   *0x35d3b8(%rip)        # aba170 <_DYNAMIC+0x300>
  75cdb8:	mov    $0xd,%eax
  75cdbd:	jmp    75cdcb <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x28b>
  75cdbf:	mov    $0xe,%eax
  75cdc4:	jmp    75cdcb <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x28b>
  75cdc6:	mov    $0x12,%eax
  75cdcb:	mov    %rax,0x78(%rsp)
  75cdd0:	movq   $0x0,0x80(%rsp)
  75cddc:	lea    -0x68d181(%rip),%rdi        # cfc62 <GCC_except_table0+0xd896>
  75cde3:	lea    0x33dd76(%rip),%rcx        # a9ab60 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1218>
  75cdea:	lea    0x33d11f(%rip),%r8        # a99f10 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x5c8>
  75cdf1:	lea    0x78(%rsp),%rdx
  75cdf6:	mov    $0x2b,%esi
  75cdfb:	call   *0x35d37f(%rip)        # aba180 <_DYNAMIC+0x310>
  75ce01:	ud2
  75ce03:	mov    %rax,%r14
  75ce06:	lea    0x78(%rsp),%rdi
  75ce0b:	call   74d7d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  75ce10:	mov    %r14,%rdi
  75ce13:	call   a98590 <_Unwind_Resume@plt>
  75ce18:	mov    %rax,%r14
  75ce1b:	jmp    75ce40 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x300>
  75ce1d:	mov    %rax,%r14
  75ce20:	mov    0x8(%rsp),%rbx
  75ce25:	jmp    75ce2a <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x2ea>
  75ce27:	mov    %rax,%r14
  75ce2a:	test   %r12,%r12
  75ce2d:	je     75ce40 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x300>
  75ce2f:	mov    $0x1,%edx
  75ce34:	mov    %r13,%rdi
  75ce37:	mov    %r12,%rsi
  75ce3a:	call   *0x35d270(%rip)        # aba0b0 <_DYNAMIC+0x240>
  75ce40:	mov    0x10(%rsp),%rdi
  75ce45:	test   %rbx,%rbx
  75ce48:	jle    75ce58 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x318>
  75ce4a:	mov    $0x1,%edx
  75ce4f:	mov    %rbx,%rsi
  75ce52:	call   *0x35d258(%rip)        # aba0b0 <_DYNAMIC+0x240>
  75ce58:	mov    %r14,%rdi
  75ce5b:	call   a98590 <_Unwind_Resume@plt>

<gpui_canvas::text::layout::TextGeometry>::intervals::{closure#1} bytes=753 frame=104

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075d540 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control>:
  75d540:	push   %rbp
  75d541:	push   %r15
  75d543:	push   %r14
  75d545:	push   %r13
  75d547:	push   %r12
  75d549:	push   %rbx
  75d54a:	sub    $0x38,%rsp
  75d54e:	mov    (%rdx),%r15
  75d551:	mov    0x8(%rdx),%rcx
  75d555:	mov    0x10(%rdx),%r13
  75d559:	mov    0x18(%rdx),%rax
  75d55d:	shl    $0x2,%rcx
  75d561:	lea    (%rcx,%rcx,2),%rcx
  75d565:	xor    %edx,%edx
  75d567:	nopw   0x0(%rax,%rax,1)
  75d570:	cmp    %rdx,%rcx
  75d573:	je     75d66e <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x12e>
  75d579:	lea    0xc(%rdx),%r12
  75d57d:	testb  $0x2,0x8(%r15,%rdx,1)
  75d583:	mov    %r12,%rdx
  75d586:	je     75d570 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x30>
  75d588:	shl    $0x2,%rax
  75d58c:	lea    (%rax,%rax,2),%rax
  75d590:	xor    %ecx,%ecx
  75d592:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  75d5a0:	cmp    %rcx,%rax
  75d5a3:	je     75d66e <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x12e>
  75d5a9:	lea    0xc(%rcx),%r14
  75d5ad:	testb  $0x1,0x8(%r13,%rcx,1)
  75d5b3:	mov    %r14,%rcx
  75d5b6:	je     75d5a0 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x60>
  75d5b8:	movaps %xmm0,0x20(%rsp)
  75d5bd:	mov    %rdi,%rbx
  75d5c0:	mov    -0xc(%r15,%r12,1),%eax
  75d5c5:	mov    %rsi,%rdi
  75d5c8:	mov    %rsi,%rbp
  75d5cb:	mov    %eax,0xc(%rsp)
  75d5cf:	mov    %eax,%esi
  75d5d1:	mov    $0x1,%edx
  75d5d6:	call   *0x35cd04(%rip)        # aba2e0 <_DYNAMIC+0x470>
  75d5dc:	mov    0x28(%rbp),%rsi
  75d5e0:	cmp    %rsi,%rax
  75d5e3:	jae    75d811 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x2d1>
  75d5e9:	mov    %rbp,%rdi
  75d5ec:	mov    -0xc(%r13,%r14,1),%r10d
  75d5f1:	mov    0x20(%rbp),%rcx
  75d5f5:	lea    (%rax,%rax,2),%r8
  75d5f9:	mov    0x4(%rcx,%r8,8),%r11d
  75d5fe:	test   %rax,%rax
  75d601:	mov    %rbx,%rdx
  75d604:	movaps 0x20(%rsp),%xmm5
  75d609:	je     75d677 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x137>
  75d60b:	cmpl   $0x0,0xc(%rsp)
  75d610:	je     75d677 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x137>
  75d612:	movzbl -0x4(%r15,%r12,1),%r9d
  75d618:	and    $0x1,%r9b
  75d61c:	je     75d677 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x137>
  75d61e:	lea    (%rcx,%r8,8),%r8
  75d622:	mov    %rax,%rcx
  75d625:	mov    0xc(%rsp),%r9d
  75d62a:	cmp    %r9d,-0x14(%r8)
  75d62e:	jne    75d67a <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x13a>
  75d630:	mov    0xc(%rsp),%esi
  75d634:	xor    %edx,%edx
  75d636:	mov    %rax,0x18(%rsp)
  75d63b:	mov    %r10d,0x14(%rsp)
  75d640:	mov    %r11d,0x10(%rsp)
  75d645:	call   *0x35cc95(%rip)        # aba2e0 <_DYNAMIC+0x470>
  75d64b:	mov    0x10(%rsp),%r11d
  75d650:	mov    0x14(%rsp),%r10d
  75d655:	movaps 0x20(%rsp),%xmm5
  75d65a:	mov    %rbp,%rdi
  75d65d:	mov    %rbx,%rdx
  75d660:	mov    %rax,%rcx
  75d663:	mov    0x18(%rsp),%rax
  75d668:	mov    0x28(%rbp),%rsi
  75d66c:	jmp    75d67a <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x13a>
  75d66e:	movb   $0x2,0x4(%rdi)
  75d672:	jmp    75d7e3 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x2a3>
  75d677:	mov    %rax,%rcx
  75d67a:	cmp    %rsi,%rcx
  75d67d:	jae    75d821 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x2e1>
  75d683:	lea    (%rcx,%rcx,2),%rcx
  75d687:	shl    $0x3,%rcx
  75d68b:	add    0x20(%rdi),%rcx
  75d68f:	movss  -0x8(%r15,%r12,1),%xmm0
  75d696:	movss  -0x8(%r13,%r14,1),%xmm1
  75d69d:	cmp    %r11d,%r10d
  75d6a0:	ja     75d6b5 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x175>
  75d6a2:	ucomiss %xmm1,%xmm0
  75d6a5:	jne    75d6a9 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x169>
  75d6a7:	jnp    75d6b5 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x175>
  75d6a9:	ucomiss %xmm0,%xmm1
  75d6ac:	setbe  %sil
  75d6b0:	jmp    75d771 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x231>
  75d6b5:	mov    %r11d,%r14d
  75d6b8:	mov    %r10d,%ebp
  75d6bb:	mov    0x8(%rdi),%rsi
  75d6bf:	mov    0x10(%rdi),%rdi
  75d6c3:	mov    %rdi,%r8
  75d6c6:	test   %rdi,%rdi
  75d6c9:	je     75d712 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x1d2>
  75d6cb:	xor    %r8d,%r8d
  75d6ce:	cmp    $0x1,%rdi
  75d6d2:	je     75d702 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x1c2>
  75d6d4:	mov    %rdi,%r9
  75d6d7:	nopw   0x0(%rax,%rax,1)
  75d6e0:	mov    %r9,%r10
  75d6e3:	shr    $1,%r10
  75d6e6:	lea    (%r10,%r8,1),%r11
  75d6ea:	lea    (%r11,%r11,2),%rbx
  75d6ee:	mov    0x10(%rsi,%rbx,8),%ebx
  75d6f2:	cmp    %rbx,%rax
  75d6f5:	cmova  %r11,%r8
  75d6f9:	sub    %r10,%r9
  75d6fc:	cmp    $0x1,%r9
  75d700:	ja     75d6e0 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x1a0>
  75d702:	lea    (%r8,%r8,2),%r9
  75d706:	mov    0x10(%rsi,%r9,8),%r9d
  75d70b:	cmp    %rax,%r9
  75d70e:	adc    $0x0,%r8
  75d712:	shl    $0x3,%r8
  75d716:	lea    (%r8,%r8,2),%r8
  75d71a:	lea    (%rsi,%r8,1),%r10
  75d71e:	mov    -0xc(%r15,%r12,1),%r9d
  75d723:	shl    $0x3,%rdi
  75d727:	lea    (%rdi,%rdi,2),%rdi
  75d72b:	nopl   0x0(%rax,%rax,1)
  75d730:	cmp    %r8,%rdi
  75d733:	je     75d7f2 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x2b2>
  75d739:	mov    %r10,%r11
  75d73c:	mov    0x10(%r10),%r10d
  75d740:	cmp    %r10,%rax
  75d743:	jne    75d7f2 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x2b2>
  75d749:	lea    0x18(%r11),%r10
  75d74d:	add    $0x18,%r8
  75d751:	cmp    %r9d,(%r11)
  75d754:	ja     75d730 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x1f0>
  75d756:	cmp    0x4(%r11),%r9d
  75d75a:	ja     75d730 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x1f0>
  75d75c:	movzbl -0x3(%rsi,%r8,1),%esi
  75d762:	mov    %ebp,%r10d
  75d765:	mov    %r14d,%r11d
  75d768:	cmp    %r14d,%ebp
  75d76b:	ja     75d803 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x2c3>
  75d771:	movaps %xmm0,%xmm3
  75d774:	minss  %xmm1,%xmm3
  75d778:	movaps %xmm3,%xmm2
  75d77b:	cmpunordss %xmm3,%xmm2
  75d780:	movaps %xmm2,%xmm4
  75d783:	andnps %xmm3,%xmm4
  75d786:	andps  %xmm0,%xmm2
  75d789:	orps   %xmm4,%xmm2
  75d78c:	movaps %xmm1,%xmm5
  75d78f:	subss  %xmm0,%xmm5
  75d793:	andps  -0x69a2fa(%rip),%xmm5        # c34a0 <GCC_except_table0+0x10d4>
  75d79a:	cmp    %r11d,%r10d
  75d79d:	movss  0x8(%rcx),%xmm3
  75d7a2:	movss  0xc(%rcx),%xmm4
  75d7a7:	mov    0xc(%rsp),%ecx
  75d7ab:	mov    %ecx,(%rdx)
  75d7ad:	movb   $0x1,0x4(%rdx)
  75d7b1:	mov    %r10d,0x8(%rdx)
  75d7b5:	movb   $0x0,0xc(%rdx)
  75d7b9:	movss  %xmm2,0x10(%rdx)
  75d7be:	movss  %xmm3,0x14(%rdx)
  75d7c3:	movss  %xmm5,0x18(%rdx)
  75d7c8:	movss  %xmm4,0x1c(%rdx)
  75d7cd:	mov    %rax,0x20(%rdx)
  75d7d1:	movss  %xmm0,0x28(%rdx)
  75d7d6:	movss  %xmm1,0x2c(%rdx)
  75d7db:	seta   0x30(%rdx)
  75d7df:	mov    %sil,0x31(%rdx)
  75d7e3:	add    $0x38,%rsp
  75d7e7:	pop    %rbx
  75d7e8:	pop    %r12
  75d7ea:	pop    %r13
  75d7ec:	pop    %r14
  75d7ee:	pop    %r15
  75d7f0:	pop    %rbp
  75d7f1:	ret
  75d7f2:	xor    %esi,%esi
  75d7f4:	mov    %ebp,%r10d
  75d7f7:	mov    %r14d,%r11d
  75d7fa:	cmp    %r14d,%ebp
  75d7fd:	jbe    75d771 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x231>
  75d803:	movaps %xmm0,%xmm2
  75d806:	test   %sil,%sil
  75d809:	je     75d79a <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x25a>
  75d80b:	subss  %xmm5,%xmm2
  75d80f:	jmp    75d79a <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x25a>
  75d811:	lea    0x33c8f0(%rip),%rdx        # a9a108 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x7c0>
  75d818:	mov    %rax,%rdi
  75d81b:	call   *0x35c8bf(%rip)        # aba0e0 <_DYNAMIC+0x270>
  75d821:	lea    0x33c8f8(%rip),%rdx        # a9a120 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x7d8>
  75d828:	mov    %rcx,%rdi
  75d82b:	call   *0x35c8af(%rip)        # aba0e0 <_DYNAMIC+0x270>

<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::present_inner::{closure#9} bytes=1503 frame=248

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075d840 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_>:
  75d840:	push   %rbp
  75d841:	push   %r15
  75d843:	push   %r14
  75d845:	push   %r13
  75d847:	push   %r12
  75d849:	push   %rbx
  75d84a:	sub    $0xc8,%rsp
  75d851:	mov    %rcx,%r14
  75d854:	mov    %rsi,%r15
  75d857:	mov    (%rcx),%ecx
  75d859:	mov    0x10(%r14),%ebx
  75d85d:	test   %ebx,%ebx
  75d85f:	je     75d883 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x43>
  75d861:	cmp    $0x1,%ebx
  75d864:	jne    75da5a <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x21a>
  75d86a:	movss  -0x69b22a(%rip),%xmm0        # c2648 <GCC_except_table0+0x27c>
  75d872:	mov    %ebx,%ebp
  75d874:	movss  0x4(%r14),%xmm1
  75d87a:	movaps %xmm1,%xmm2
  75d87d:	test   %ecx,%ecx
  75d87f:	je     75d89b <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x5b>
  75d881:	jmp    75d89e <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x5e>
  75d883:	movss  0x14(%r14),%xmm0
  75d889:	mov    $0x1,%ebp
  75d88e:	movss  0x4(%r14),%xmm1
  75d894:	movaps %xmm1,%xmm2
  75d897:	test   %ecx,%ecx
  75d899:	jne    75d89e <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x5e>
  75d89b:	movaps %xmm0,%xmm2
  75d89e:	mov    $0x1,%eax
  75d8a3:	cmovne %eax,%ebp
  75d8a6:	mov    (%r15),%rax
  75d8a9:	mov    0x10(%rax),%rsi
  75d8ad:	test   %rsi,%rsi
  75d8b0:	je     75dd81 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x541>
  75d8b6:	mov    %ecx,0x1c(%rsp)
  75d8ba:	mov    %rdi,0x10(%rsp)
  75d8bf:	mov    0x8(%rax),%rax
  75d8c3:	mov    (%rdx),%rcx
  75d8c6:	cmp    $0x1,%rsi
  75d8ca:	jne    75d991 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x151>
  75d8d0:	xor    %r12d,%r12d
  75d8d3:	mov    %r12,%rdi
  75d8d6:	shl    $0x4,%rdi
  75d8da:	mov    (%rax,%rdi,1),%r8
  75d8de:	cmp    %rcx,%r8
  75d8e1:	seta   %sil
  75d8e5:	sbb    $0x0,%sil
  75d8e9:	cmp    %rcx,%r8
  75d8ec:	jne    75d913 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0xd3>
  75d8ee:	add    %rdi,%rax
  75d8f1:	mov    0x8(%rax),%ecx
  75d8f4:	mov    0x8(%rdx),%edi
  75d8f7:	cmp    %edi,%ecx
  75d8f9:	seta   %sil
  75d8fd:	sbb    $0x0,%sil
  75d901:	cmp    %edi,%ecx
  75d903:	jne    75d913 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0xd3>
  75d905:	mov    0xc(%rax),%eax
  75d908:	cmp    0xc(%rdx),%eax
  75d90b:	seta   %sil
  75d90f:	sbb    $0x0,%sil
  75d913:	test   %sil,%sil
  75d916:	jne    75dd86 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x546>
  75d91c:	movss  %xmm2,0x8(%rsp)
  75d922:	movss  %xmm1,0xc(%rsp)
  75d928:	mov    0x8(%r15),%rax
  75d92c:	mov    0x10(%rax),%rsi
  75d930:	cmp    %rsi,%r12
  75d933:	jae    75ddbc <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x57c>
  75d939:	mov    0x8(%rax),%rax
  75d93d:	lea    (%r12,%r12,4),%rcx
  75d941:	mov    0x20(%rax,%rcx,8),%r13d
  75d946:	mov    %r13d,%edi
  75d949:	call   *0x35c999(%rip)        # aba2e8 <_DYNAMIC+0x478>
  75d94f:	cmp    $0x2,%dl
  75d952:	jne    75d9e9 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x1a9>
  75d958:	mov    0x18(%r15),%rdx
  75d95c:	cmpq   $0x0,(%rdx)
  75d960:	je     75dd35 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x4f5>
  75d966:	mov    %r13d,%eax
  75d969:	and    $0xf,%eax
  75d96c:	cmp    $0x9,%eax
  75d96f:	ja     75dd68 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x528>
  75d975:	cmp    $0x6,%eax
  75d978:	je     75d984 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x144>
  75d97a:	shr    $0x4,%r13d
  75d97e:	jne    75da89 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x249>
  75d984:	lea    0x33c8e5(%rip),%rdi        # a9a270 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x928>
  75d98b:	call   *0x35c7df(%rip)        # aba170 <_DYNAMIC+0x300>
  75d991:	mov    0x8(%rdx),%edi
  75d994:	mov    0xc(%rdx),%r8d
  75d998:	xor    %r9d,%r9d
  75d99b:	jmp    75d9b7 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x177>
  75d99d:	nopl   (%rax)
  75d9a0:	test   %r13b,%r13b
  75d9a3:	cmovne %r9,%r12
  75d9a7:	sub    %r10,%rsi
  75d9aa:	mov    %r12,%r9
  75d9ad:	cmp    $0x1,%rsi
  75d9b1:	jbe    75d8d3 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x93>
  75d9b7:	mov    %rsi,%r10
  75d9ba:	shr    $1,%r10
  75d9bd:	lea    (%r10,%r9,1),%r12
  75d9c1:	mov    %r12,%r11
  75d9c4:	shl    $0x4,%r11
  75d9c8:	cmp    %rcx,(%rax,%r11,1)
  75d9cc:	seta   %r13b
  75d9d0:	jne    75d9a0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x160>
  75d9d2:	add    %rax,%r11
  75d9d5:	cmp    %edi,0x8(%r11)
  75d9d9:	seta   %r13b
  75d9dd:	jne    75d9a0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x160>
  75d9df:	cmp    %r8d,0xc(%r11)
  75d9e3:	seta   %r13b
  75d9e7:	jmp    75d9a0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x160>
  75d9e9:	mov    0x10(%r15),%rcx
  75d9ed:	mov    (%rcx),%rcx
  75d9f0:	test   %rcx,%rcx
  75d9f3:	je     75dd4e <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x50e>
  75d9f9:	mov    %eax,%edi
  75d9fb:	mov    0x10(%rcx),%rsi
  75d9ff:	cmp    %rdi,%rsi
  75da02:	jbe    75ddcc <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x58c>
  75da08:	mov    0x8(%rcx),%rax
  75da0c:	mov    (%rax,%rdi,8),%rax
  75da10:	mov    0x30(%rax),%ecx
  75da13:	mov    0x34(%rax),%eax
  75da16:	xorps  %xmm0,%xmm0
  75da19:	cvtsi2ss %rcx,%xmm0
  75da1e:	xorps  %xmm1,%xmm1
  75da21:	cvtsi2ss %rax,%xmm1
  75da26:	movaps %xmm0,%xmm2
  75da29:	divss  %xmm1,%xmm2
  75da2d:	movzbl 0x8(%r14),%ecx
  75da32:	movss  0xc(%r14),%xmm3
  75da38:	cmpb   $0x0,0x1c(%rsp)
  75da3d:	mov    0x10(%rsp),%rax
  75da42:	je     75da72 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x232>
  75da44:	test   %cl,%cl
  75da46:	je     75db1c <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x2dc>
  75da4c:	movss  0xc(%rsp),%xmm0
  75da52:	movaps %xmm3,%xmm1
  75da55:	jmp    75db29 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x2e9>
  75da5a:	xor    %ebp,%ebp
  75da5c:	movss  0x4(%r14),%xmm1
  75da62:	movaps %xmm1,%xmm2
  75da65:	test   %ecx,%ecx
  75da67:	je     75d89b <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x5b>
  75da6d:	jmp    75d89e <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x5e>
  75da72:	test   %cl,%cl
  75da74:	je     75db29 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x2e9>
  75da7a:	mulss  %xmm3,%xmm2
  75da7e:	movaps %xmm2,%xmm0
  75da81:	movaps %xmm3,%xmm1
  75da84:	jmp    75db29 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x2e9>
  75da89:	mov    0x20(%r15),%rax
  75da8d:	mov    0x10(%rax),%rsi
  75da91:	dec    %r13d
  75da94:	cmp    %r13,%rsi
  75da97:	jbe    75ddd9 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x599>
  75da9d:	mov    0x8(%rax),%rsi
  75daa1:	lea    0x0(%r13,%r13,4),%r13
  75daa6:	shl    $0x4,%r13
  75daaa:	cmpq   $0xfffffffffffffffe,(%rsi,%r13,1)
  75daaf:	je     75dd5b <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x51b>
  75dab5:	mov    0x28(%r15),%rcx
  75dab9:	mov    (%rcx),%rax
  75dabc:	lea    -0x699b03(%rip),%rdi        # c3fc0 <GCC_except_table0+0x1bf4>
  75dac3:	movslq (%rdi,%rax,4),%rax
  75dac7:	add    %rdi,%rax
  75daca:	jmp    *%rax
  75dacc:	movups -0x699637(%rip),%xmm0        # c449c <GCC_except_table0+0x20d0>
  75dad3:	movaps %xmm0,0x60(%rsp)
  75dad8:	movups -0x699653(%rip),%xmm0        # c448c <GCC_except_table0+0x20c0>
  75dadf:	movaps %xmm0,0x50(%rsp)
  75dae4:	movups -0x69966f(%rip),%xmm0        # c447c <GCC_except_table0+0x20b0>
  75daeb:	movaps %xmm0,0x40(%rsp)
  75daf0:	movups -0x69968b(%rip),%xmm0        # c446c <GCC_except_table0+0x20a0>
  75daf7:	movaps %xmm0,0x30(%rsp)
  75dafc:	movups -0x6996a7(%rip),%xmm0        # c445c <GCC_except_table0+0x2090>
  75db03:	movaps %xmm0,0x20(%rsp)
  75db08:	movabs $0x3000100000000,%rax
  75db12:	mov    %rax,0x70(%rsp)
  75db17:	jmp    75dbf2 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x3b2>
  75db1c:	movss  0xc(%rsp),%xmm0
  75db22:	movaps %xmm0,%xmm1
  75db25:	divss  %xmm2,%xmm1
  75db29:	movss  %xmm0,0x10(%rax)
  75db2e:	movss  %xmm1,0x14(%rax)
  75db33:	xorps  %xmm0,%xmm0
  75db36:	movups %xmm0,(%rax)
  75db39:	jmp    75dd23 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x4e3>
  75db3e:	mov    0x20(%rcx),%rax
  75db42:	cmp    %rax,%r12
  75db45:	jae    75dde9 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x5a9>
  75db4b:	mov    0x10(%rcx),%rax
  75db4f:	mov    0x18(%rcx),%rdi
  75db53:	movzbl (%rdi,%r12,1),%edi
  75db58:	cmp    %rdi,%rax
  75db5b:	jbe    75de0f <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x5cf>
  75db61:	mov    0x8(%rcx),%rax
  75db65:	imul   $0x58,%rdi,%rcx
  75db69:	jmp    75dbb7 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x377>
  75db6b:	mov    0x8(%rcx),%rax
  75db6f:	lea    0x20(%rsp),%rdi
  75db74:	mov    %rsi,0x88(%rsp)
  75db7c:	mov    %rax,%rsi
  75db7f:	mov    %rdx,0x80(%rsp)
  75db87:	mov    %r12,%rdx
  75db8a:	call   *0x35c6d0(%rip)        # aba260 <_DYNAMIC+0x3f0>
  75db90:	mov    0x88(%rsp),%rsi
  75db98:	mov    0x80(%rsp),%rdx
  75dba0:	jmp    75dbf2 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x3b2>
  75dba2:	mov    0x18(%rcx),%rax
  75dba6:	cmp    %rax,%r12
  75dba9:	jae    75ddfc <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x5bc>
  75dbaf:	mov    0x10(%rcx),%rax
  75dbb3:	imul   $0x58,%r12,%rcx
  75dbb7:	mov    0x50(%rax,%rcx,1),%rdi
  75dbbc:	mov    %rdi,0x70(%rsp)
  75dbc1:	movups 0x40(%rax,%rcx,1),%xmm0
  75dbc6:	movaps %xmm0,0x60(%rsp)
  75dbcb:	movups (%rax,%rcx,1),%xmm0
  75dbcf:	movups 0x10(%rax,%rcx,1),%xmm1
  75dbd4:	movups 0x20(%rax,%rcx,1),%xmm2
  75dbd9:	movups 0x30(%rax,%rcx,1),%xmm3
  75dbde:	movaps %xmm3,0x50(%rsp)
  75dbe3:	movaps %xmm2,0x40(%rsp)
  75dbe8:	movaps %xmm1,0x30(%rsp)
  75dbed:	movaps %xmm0,0x20(%rsp)
  75dbf2:	mov    0x10(%rsp),%r12
  75dbf7:	movss  0x8(%rsp),%xmm1
  75dbfd:	add    %r13,%rsi
  75dc00:	movss  0x38(%rsp),%xmm0
  75dc06:	test   %ebx,%ebx
  75dc08:	sete   %al
  75dc0b:	mov    0x1c(%rsp),%ebx
  75dc0f:	or     %bl,%al
  75dc11:	movzbl %al,%r8d
  75dc15:	lea    0x90(%rsp),%rdi
  75dc1d:	mov    %ebp,%ecx
  75dc1f:	call   *0x35c6cb(%rip)        # aba2f0 <_DYNAMIC+0x480>
  75dc25:	cmpl   $0xfffffffe,0x90(%rsp)
  75dc2d:	jne    75dc92 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x452>
  75dc2f:	mov    0x98(%rsp),%rax
  75dc37:	movss  0x30(%rax),%xmm0
  75dc3c:	test   %bl,%bl
  75dc3e:	movss  0xc(%rsp),%xmm2
  75dc44:	jne    75dc4b <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x40b>
  75dc46:	movss  0x28(%rax),%xmm2
  75dc4b:	add    $0x2c,%rax
  75dc4f:	lea    0xc(%r14),%rcx
  75dc53:	cmpb   $0x0,0x8(%r14)
  75dc58:	cmove  %rax,%rcx
  75dc5c:	movss  (%rcx),%xmm1
  75dc60:	movss  %xmm2,0x10(%r12)
  75dc67:	movss  %xmm1,0x14(%r12)
  75dc6e:	movl   $0x1,(%r12)
  75dc76:	movss  %xmm0,0x4(%r12)
  75dc7d:	movl   $0x1,0x8(%r12)
  75dc86:	movss  %xmm0,0xc(%r12)
  75dc8d:	jmp    75dd20 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x4e0>
  75dc92:	mov    0x30(%r15),%rbx
  75dc96:	mov    (%rbx),%rax
  75dc99:	cmp    $0xfffffffffffffffe,%rax
  75dc9d:	je     75dce0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x4a0>
  75dc9f:	sub    $0xd,%rax
  75dca3:	mov    $0x14,%ecx
  75dca8:	cmovge %rax,%rcx
  75dcac:	cmp    $0x14,%rcx
  75dcb0:	je     75dcc3 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x483>
  75dcb2:	cmp    $0x19,%rcx
  75dcb6:	jne    75dce0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x4a0>
  75dcb8:	mov    0x8(%rbx),%rsi
  75dcbc:	mov    $0x10,%eax
  75dcc1:	jmp    75dccc <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x48c>
  75dcc3:	mov    0x18(%rbx),%rsi
  75dcc7:	mov    $0x20,%eax
  75dccc:	test   %rsi,%rsi
  75dccf:	je     75dce0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x4a0>
  75dcd1:	mov    (%rbx,%rax,1),%rdi
  75dcd5:	mov    $0x1,%edx
  75dcda:	call   *0x35c3d0(%rip)        # aba0b0 <_DYNAMIC+0x240>
  75dce0:	mov    0xc0(%rsp),%rax
  75dce8:	mov    %rax,0x30(%rbx)
  75dcec:	movups 0x90(%rsp),%xmm0
  75dcf4:	movups 0xa0(%rsp),%xmm1
  75dcfc:	movups 0xb0(%rsp),%xmm2
  75dd04:	movups %xmm2,0x20(%rbx)
  75dd08:	movups %xmm1,0x10(%rbx)
  75dd0c:	movups %xmm0,(%rbx)
  75dd0f:	xorps  %xmm0,%xmm0
  75dd12:	movups %xmm0,(%r12)
  75dd17:	movq   $0x0,0x10(%r12)
  75dd20:	mov    %r12,%rax
  75dd23:	add    $0xc8,%rsp
  75dd2a:	pop    %rbx
  75dd2b:	pop    %r12
  75dd2d:	pop    %r13
  75dd2f:	pop    %r14
  75dd31:	pop    %r15
  75dd33:	pop    %rbp
  75dd34:	ret
  75dd35:	lea    -0x68e383(%rip),%rdi        # cf9b9 <GCC_except_table0+0xd5ed>
  75dd3c:	lea    0x33c515(%rip),%rdx        # a9a258 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x910>
  75dd43:	mov    $0x28,%esi
  75dd48:	call   *0x35c43a(%rip)        # aba188 <_DYNAMIC+0x318>
  75dd4e:	lea    0x33c4d3(%rip),%rdi        # a9a228 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x8e0>
  75dd55:	call   *0x35c415(%rip)        # aba170 <_DYNAMIC+0x300>
  75dd5b:	lea    0x33c41e(%rip),%rdi        # a9a180 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x838>
  75dd62:	call   *0x35c408(%rip)        # aba170 <_DYNAMIC+0x300>
  75dd68:	lea    -0x68b427(%rip),%rdi        # d2948 <GCC_except_table0+0x1057c>
  75dd6f:	lea    0x33d67a(%rip),%rdx        # a9b3f0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1aa8>
  75dd76:	mov    $0x83,%esi
  75dd7b:	call   *0x35c367(%rip)        # aba0e8 <_DYNAMIC+0x278>
  75dd81:	xor    %r12d,%r12d
  75dd84:	jmp    75dd92 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x552>
  75dd86:	xor    %eax,%eax
  75dd88:	cmp    $0xff,%sil
  75dd8c:	sete   %al
  75dd8f:	add    %rax,%r12
  75dd92:	mov    %r12,0x20(%rsp)
  75dd97:	lea    -0x68e419(%rip),%rdi        # cf985 <GCC_except_table0+0xd5b9>
  75dd9e:	lea    0x33ce9b(%rip),%rcx        # a9ac40 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x12f8>
  75dda5:	lea    0x33c44c(%rip),%r8        # a9a1f8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x8b0>
  75ddac:	lea    0x20(%rsp),%rdx
  75ddb1:	mov    $0x34,%esi
  75ddb6:	call   *0x35c3c4(%rip)        # aba180 <_DYNAMIC+0x310>
  75ddbc:	lea    0x33c44d(%rip),%rdx        # a9a210 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x8c8>
  75ddc3:	mov    %r12,%rdi
  75ddc6:	call   *0x35c314(%rip)        # aba0e0 <_DYNAMIC+0x270>
  75ddcc:	lea    0x33c46d(%rip),%rdx        # a9a240 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x8f8>
  75ddd3:	call   *0x35c307(%rip)        # aba0e0 <_DYNAMIC+0x270>
  75ddd9:	lea    0x33c388(%rip),%rdx        # a9a168 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x820>
  75dde0:	mov    %r13,%rdi
  75dde3:	call   *0x35c2f7(%rip)        # aba0e0 <_DYNAMIC+0x270>
  75dde9:	lea    0x33cf30(%rip),%rdx        # a9ad20 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x13d8>
  75ddf0:	mov    %r12,%rdi
  75ddf3:	mov    %rax,%rsi
  75ddf6:	call   *0x35c2e4(%rip)        # aba0e0 <_DYNAMIC+0x270>
  75ddfc:	lea    0x33cf05(%rip),%rdx        # a9ad08 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x13c0>
  75de03:	mov    %r12,%rdi
  75de06:	mov    %rax,%rsi
  75de09:	call   *0x35c2d1(%rip)        # aba0e0 <_DYNAMIC+0x270>
  75de0f:	lea    0x33cf22(%rip),%rdx        # a9ad38 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x13f0>
  75de16:	mov    %rax,%rsi
  75de19:	call   *0x35c2c1(%rip)        # aba0e0 <_DYNAMIC+0x270>

<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::present_inner::{closure#41} bytes=884 frame=136

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075de20 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_>:
  75de20:	push   %rbp
  75de21:	push   %r15
  75de23:	push   %r14
  75de25:	push   %r13
  75de27:	push   %r12
  75de29:	push   %rbx
  75de2a:	sub    $0x58,%rsp
  75de2e:	mov    (%rsi),%rax
  75de31:	mov    0x10(%rax),%rcx
  75de35:	mov    %rcx,0x10(%rsp)
  75de3a:	movups (%rax),%xmm0
  75de3d:	movaps %xmm0,(%rsp)
  75de41:	movq   $0x0,(%rax)
  75de48:	movq   $0x4,0x8(%rax)
  75de50:	movq   $0x0,0x10(%rax)
  75de58:	mov    0x8(%rsi),%r13
  75de5c:	mov    0x10(%rsi),%rbp
  75de60:	mov    0x18(%rsi),%rax
  75de64:	mov    %rax,0x30(%rsp)
  75de69:	mov    0x20(%rsi),%rax
  75de6d:	mov    %rax,0x28(%rsp)
  75de72:	mov    0x8(%rdx),%r12
  75de76:	mov    0x10(%rdx),%rbx
  75de7a:	mov    (%rsp),%r15
  75de7e:	mov    0x10(%rsp),%rsi
  75de83:	mov    %r15,%rax
  75de86:	sub    %rsi,%rax
  75de89:	cmp    %rax,%rbx
  75de8c:	mov    %rdi,0x38(%rsp)
  75de91:	ja     75e0fe <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x2de>
  75de97:	test   %rbx,%rbx
  75de9a:	je     75e0da <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x2ba>
  75dea0:	shl    $0x4,%rbx
  75dea4:	add    %r12,%rbx
  75dea7:	mov    %rsp,%rdi
  75deaa:	jmp    75dee9 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc9>
  75deac:	mov    0x8(%rsp),%rax
  75deb1:	mov    %rsi,%rcx
  75deb4:	shl    $0x4,%rcx
  75deb8:	movl   $0x7fc00000,(%rax,%rcx,1)
  75debf:	mov    %r15d,0x4(%rax,%rcx,1)
  75dec4:	mov    %r14,0x8(%rax,%rcx,1)
  75dec9:	inc    %rsi
  75decc:	mov    %rsi,0x10(%rsp)
  75ded1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  75dee0:	cmp    %rbx,%r12
  75dee3:	je     75e0da <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x2ba>
  75dee9:	mov    %r12,%rax
  75deec:	add    $0x10,%r12
  75def0:	mov    0x8(%rax),%r15d
  75def4:	test   %r15d,%r15d
  75def7:	je     75dee0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75def9:	mov    (%rax),%r14
  75defc:	cmpb   $0x1,0x0(%r13)
  75df01:	jne    75e057 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x237>
  75df07:	mov    0x0(%rbp),%rax
  75df0b:	test   %rax,%rax
  75df0e:	je     75dfc0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x1a0>
  75df14:	cmp    $0x1,%eax
  75df17:	jne    75dfe0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x1c0>
  75df1d:	mov    0x10(%rbp),%rcx
  75df21:	test   %rcx,%rcx
  75df24:	je     75dee0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75df26:	mov    0x8(%rbp),%rax
  75df2a:	xor    %edx,%edx
  75df2c:	cmp    $0x1,%rcx
  75df30:	je     75df64 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x144>
  75df32:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  75df40:	mov    %rdx,%r9
  75df43:	mov    %rcx,%r10
  75df46:	shr    $1,%r10
  75df49:	add    %r10,%rdx
  75df4c:	mov    %rdx,%r8
  75df4f:	shl    $0x4,%r8
  75df53:	cmp    %r14,(%rax,%r8,1)
  75df57:	cmova  %r9,%rdx
  75df5b:	sub    %r10,%rcx
  75df5e:	cmp    $0x1,%rcx
  75df62:	ja     75df40 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x120>
  75df64:	mov    %rdx,%rcx
  75df67:	shl    $0x4,%rcx
  75df6b:	xor    %r8d,%r8d
  75df6e:	cmp    %r14,(%rax,%rcx,1)
  75df72:	setbe  %r8b
  75df76:	add    %rdx,%r8
  75df79:	je     75dee0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75df7f:	shl    $0x4,%r8
  75df83:	mov    %r14,%rcx
  75df86:	sub    -0x10(%rax,%r8,1),%rcx
  75df8b:	mov    -0x4(%rax,%r8,1),%edx
  75df90:	cmp    %rdx,%rcx
  75df93:	jae    75dee0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75df99:	add    %r8,%rax
  75df9c:	mov    -0x8(%rax),%eax
  75df9f:	add    %rax,%rcx
  75dfa2:	mov    0x30(%rsp),%rax
  75dfa7:	cmp    0x10(%rax),%rcx
  75dfab:	jae    75dee0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75dfb1:	jmp    75e016 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x1f6>
  75dfb3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  75dfc0:	mov    %r14,%rcx
  75dfc3:	sub    0x8(%rbp),%rcx
  75dfc7:	jb     75dee0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75dfcd:	cmp    0x10(%rbp),%rcx
  75dfd1:	jae    75dee0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75dfd7:	jmp    75e007 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x1e7>
  75dfd9:	nopl   0x0(%rax)
  75dfe0:	mov    0x10(%rbp),%rcx
  75dfe4:	test   %rcx,%rcx
  75dfe7:	je     75dee0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75dfed:	mov    0x8(%rbp),%rax
  75dff1:	cmp    $0x1,%rcx
  75dff5:	jne    75e088 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x268>
  75dffb:	cmp    %r14,(%rax)
  75dffe:	jne    75dee0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75e004:	mov    0x8(%rax),%ecx
  75e007:	mov    0x30(%rsp),%rax
  75e00c:	cmp    0x10(%rax),%rcx
  75e010:	jae    75dee0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75e016:	mov    0x30(%rsp),%rax
  75e01b:	mov    0x8(%rax),%rax
  75e01f:	mov    (%rax,%rcx,4),%eax
  75e022:	mov    $0xffffffff,%ecx
  75e027:	cmp    %rcx,%rax
  75e02a:	je     75dee0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75e030:	mov    0x28(%rsp),%rcx
  75e035:	cmp    %rax,0x10(%rcx)
  75e039:	jbe    75dee0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75e03f:	mov    0x28(%rsp),%rcx
  75e044:	mov    0x8(%rcx),%rcx
  75e048:	shl    $0x6,%rax
  75e04c:	cmp    %r14,0x20(%rcx,%rax,1)
  75e051:	jne    75dee0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75e057:	cmp    (%rsp),%rsi
  75e05b:	jne    75deac <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x8c>
  75e061:	mov    $0x1,%edx
  75e066:	mov    $0x4,%ecx
  75e06b:	mov    $0x10,%r8d
  75e071:	mov    %rsi,0x20(%rsp)
  75e076:	call   75b3b0 <_RINvNvMs2_NtCscdodAO9FK5_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs9C2G9YFESsD_29canonical_text_public_control>
  75e07b:	mov    %rsp,%rdi
  75e07e:	mov    0x20(%rsp),%rsi
  75e083:	jmp    75deac <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x8c>
  75e088:	xor    %edx,%edx
  75e08a:	nopw   0x0(%rax,%rax,1)
  75e090:	mov    %rdx,%r9
  75e093:	mov    %rcx,%r10
  75e096:	shr    $1,%r10
  75e099:	add    %r10,%rdx
  75e09c:	lea    (%rdx,%rdx,2),%r8
  75e0a0:	cmp    %r14,(%rax,%r8,4)
  75e0a4:	cmova  %r9,%rdx
  75e0a8:	sub    %r10,%rcx
  75e0ab:	cmp    $0x1,%rcx
  75e0af:	ja     75e090 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x270>
  75e0b1:	lea    (%rdx,%rdx,2),%rcx
  75e0b5:	cmp    %r14,(%rax,%rcx,4)
  75e0b9:	jne    75dee0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75e0bf:	lea    (%rax,%rcx,4),%rax
  75e0c3:	mov    0x8(%rax),%ecx
  75e0c6:	mov    0x30(%rsp),%rax
  75e0cb:	cmp    0x10(%rax),%rcx
  75e0cf:	jae    75dee0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75e0d5:	jmp    75e016 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x1f6>
  75e0da:	mov    0x10(%rsp),%rax
  75e0df:	mov    0x38(%rsp),%rcx
  75e0e4:	mov    %rax,0x10(%rcx)
  75e0e8:	movaps (%rsp),%xmm0
  75e0ec:	movups %xmm0,(%rcx)
  75e0ef:	add    $0x58,%rsp
  75e0f3:	pop    %rbx
  75e0f4:	pop    %r12
  75e0f6:	pop    %r13
  75e0f8:	pop    %r14
  75e0fa:	pop    %r15
  75e0fc:	pop    %rbp
  75e0fd:	ret
  75e0fe:	mov    %rsi,0x20(%rsp)
  75e103:	mov    %rsi,%rax
  75e106:	add    %rbx,%rax
  75e109:	jb     75e14e <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x32e>
  75e10b:	mov    0x8(%rsp),%rdx
  75e110:	lea    0x40(%rsp),%rdi
  75e115:	mov    $0x4,%r8d
  75e11b:	mov    $0x10,%r9d
  75e121:	mov    %r15,%rsi
  75e124:	mov    %rax,%r14
  75e127:	mov    %rax,%rcx
  75e12a:	call   772d90 <_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs9C2G9YFESsD_29canonical_text_public_control>
  75e12f:	cmpl   $0x1,0x40(%rsp)
  75e134:	je     75e158 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x338>
  75e136:	mov    0x48(%rsp),%rax
  75e13b:	mov    %rax,0x8(%rsp)
  75e140:	mov    %r14,(%rsp)
  75e144:	mov    0x20(%rsp),%rsi
  75e149:	jmp    75dea0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x80>
  75e14e:	xor    %edi,%edi
  75e150:	call   *0x35c00a(%rip)        # aba160 <_DYNAMIC+0x2f0>
  75e156:	ud2
  75e158:	mov    0x48(%rsp),%rdi
  75e15d:	mov    0x50(%rsp),%rsi
  75e162:	jmp    75e150 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x330>
  75e164:	mov    %rax,%rbx
  75e167:	mov    (%rsp),%r15
  75e16b:	jmp    75e170 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x350>
  75e16d:	mov    %rax,%rbx
  75e170:	test   %r15,%r15
  75e173:	je     75e18c <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x36c>
  75e175:	mov    0x8(%rsp),%rdi
  75e17a:	shl    $0x4,%r15
  75e17e:	mov    $0x4,%edx
  75e183:	mov    %r15,%rsi
  75e186:	call   *0x35bf24(%rip)        # aba0b0 <_DYNAMIC+0x240>
  75e18c:	mov    %rbx,%rdi
  75e18f:	call   a98590 <_Unwind_Resume@plt>

<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::present_inner::{closure#44} bytes=415 frame=8

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075e1a0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_>:
  75e1a0:	push   %rax
  75e1a1:	mov    (%rdi),%rdx
  75e1a4:	mov    (%rdx),%rax
  75e1a7:	test   %rax,%rax
  75e1aa:	je     75e1f6 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x56>
  75e1ac:	cmp    $0x1,%eax
  75e1af:	jne    75e212 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x72>
  75e1b1:	mov    0x8(%rdx),%rcx
  75e1b5:	mov    0x10(%rdx),%rdx
  75e1b9:	cmp    $0x1,%rdx
  75e1bd:	je     75e268 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0xc8>
  75e1c3:	test   %rdx,%rdx
  75e1c6:	je     75e310 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x170>
  75e1cc:	xor    %eax,%eax
  75e1ce:	xchg   %ax,%ax
  75e1d0:	mov    %rax,%r8
  75e1d3:	mov    %rdx,%r9
  75e1d6:	shr    $1,%r9
  75e1d9:	add    %r9,%rax
  75e1dc:	mov    %rax,%r10
  75e1df:	shl    $0x4,%r10
  75e1e3:	cmp    %rsi,(%rcx,%r10,1)
  75e1e7:	cmova  %r8,%rax
  75e1eb:	sub    %r9,%rdx
  75e1ee:	cmp    $0x1,%rdx
  75e1f2:	ja     75e1d0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x30>
  75e1f4:	jmp    75e26a <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0xca>
  75e1f6:	mov    %rsi,%rax
  75e1f9:	sub    0x8(%rdx),%rax
  75e1fd:	jb     75e310 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x170>
  75e203:	cmp    0x10(%rdx),%rax
  75e207:	jb     75e2a2 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x102>
  75e20d:	jmp    75e310 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x170>
  75e212:	mov    0x8(%rdx),%rax
  75e216:	mov    0x10(%rdx),%rcx
  75e21a:	cmp    $0x1,%rcx
  75e21e:	je     75e2e8 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x148>
  75e224:	test   %rcx,%rcx
  75e227:	je     75e310 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x170>
  75e22d:	xor    %edx,%edx
  75e22f:	nop
  75e230:	mov    %rdx,%r8
  75e233:	mov    %rcx,%r9
  75e236:	shr    $1,%r9
  75e239:	add    %r9,%rdx
  75e23c:	lea    (%rdx,%rdx,2),%r10
  75e240:	cmp    %rsi,(%rax,%r10,4)
  75e244:	cmova  %r8,%rdx
  75e248:	sub    %r9,%rcx
  75e24b:	cmp    $0x1,%rcx
  75e24f:	ja     75e230 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x90>
  75e251:	lea    (%rdx,%rdx,2),%rcx
  75e255:	cmp    %rsi,(%rax,%rcx,4)
  75e259:	jne    75e310 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x170>
  75e25f:	lea    (%rax,%rcx,4),%rax
  75e263:	jmp    75e2ed <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x14d>
  75e268:	xor    %eax,%eax
  75e26a:	mov    %rax,%r8
  75e26d:	shl    $0x4,%r8
  75e271:	xor    %edx,%edx
  75e273:	cmp    %rsi,(%rcx,%r8,1)
  75e277:	setbe  %dl
  75e27a:	add    %rax,%rdx
  75e27d:	je     75e310 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x170>
  75e283:	shl    $0x4,%rdx
  75e287:	mov    %rsi,%rax
  75e28a:	sub    -0x10(%rcx,%rdx,1),%rax
  75e28f:	mov    -0x4(%rcx,%rdx,1),%r8d
  75e294:	cmp    %r8,%rax
  75e297:	jae    75e310 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x170>
  75e299:	add    %rdx,%rcx
  75e29c:	mov    -0x8(%rcx),%ecx
  75e29f:	add    %rcx,%rax
  75e2a2:	mov    0x8(%rdi),%rdx
  75e2a6:	mov    0x10(%rdx),%rcx
  75e2aa:	cmp    %rcx,%rax
  75e2ad:	jae    75e2fd <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x15d>
  75e2af:	mov    0x8(%rdx),%rcx
  75e2b3:	mov    (%rcx,%rax,4),%edx
  75e2b6:	mov    $0xffffffff,%eax
  75e2bb:	cmp    %rax,%rdx
  75e2be:	je     75e2e4 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x144>
  75e2c0:	mov    0x10(%rdi),%rcx
  75e2c4:	mov    0x10(%rcx),%rax
  75e2c8:	cmp    %rdx,%rax
  75e2cb:	jbe    75e329 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x189>
  75e2cd:	mov    0x8(%rcx),%rcx
  75e2d1:	mov    %rdx,%rdi
  75e2d4:	shl    $0x6,%rdi
  75e2d8:	xor    %eax,%eax
  75e2da:	cmp    %rsi,0x20(%rcx,%rdi,1)
  75e2df:	sete   %al
  75e2e2:	pop    %rcx
  75e2e3:	ret
  75e2e4:	xor    %eax,%eax
  75e2e6:	pop    %rcx
  75e2e7:	ret
  75e2e8:	cmp    %rsi,(%rax)
  75e2eb:	jne    75e310 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x170>
  75e2ed:	mov    0x8(%rax),%eax
  75e2f0:	mov    0x8(%rdi),%rdx
  75e2f4:	mov    0x10(%rdx),%rcx
  75e2f8:	cmp    %rcx,%rax
  75e2fb:	jb     75e2af <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x10f>
  75e2fd:	lea    0x33bf84(%rip),%rdx        # a9a288 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x940>
  75e304:	mov    %rax,%rdi
  75e307:	mov    %rcx,%rsi
  75e30a:	call   *0x35bdd0(%rip)        # aba0e0 <_DYNAMIC+0x270>
  75e310:	lea    -0x68ea9f(%rip),%rdi        # cf878 <GCC_except_table0+0xd4ac>
  75e317:	lea    0x33b9ca(%rip),%rdx        # a99ce8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x3a0>
  75e31e:	mov    $0x15,%esi
  75e323:	call   *0x35be5f(%rip)        # aba188 <_DYNAMIC+0x318>
  75e329:	lea    0x33bbc8(%rip),%rcx        # a99ef8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x5b0>
  75e330:	mov    %rdx,%rdi
  75e333:	mov    %rax,%rsi
  75e336:	mov    %rcx,%rdx
  75e339:	call   *0x35bda1(%rip)        # aba0e0 <_DYNAMIC+0x270>

<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::present_inner::{closure#15} bytes=130 frame=8

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075e340 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_>:
  75e340:	push   %rax
  75e341:	cmp    %rsi,%rdx
  75e344:	jae    75e3af <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_+0x6f>
  75e346:	lea    (%rdx,%rdx,4),%rax
  75e34a:	mov    0x20(%rdi,%rax,8),%eax
  75e34e:	and    $0xf,%eax
  75e351:	cmp    $0x9,%eax
  75e354:	ja     75e396 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_+0x56>
  75e356:	lea    -0x69a38d(%rip),%rcx        # c3fd0 <GCC_except_table0+0x1c04>
  75e35d:	movslq (%rcx,%rax,4),%rax
  75e361:	add    %rcx,%rax
  75e364:	jmp    *%rax
  75e366:	mov    $0x8,%al
  75e368:	jmp    75e388 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_+0x48>
  75e36a:	mov    $0x4,%al
  75e36c:	jmp    75e388 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_+0x48>
  75e36e:	mov    $0x2,%al
  75e370:	jmp    75e388 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_+0x48>
  75e372:	mov    $0x3,%al
  75e374:	jmp    75e388 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_+0x48>
  75e376:	mov    $0x7,%al
  75e378:	jmp    75e388 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_+0x48>
  75e37a:	xor    %eax,%eax
  75e37c:	jmp    75e388 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_+0x48>
  75e37e:	mov    $0x1,%al
  75e380:	jmp    75e388 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_+0x48>
  75e382:	mov    $0x5,%al
  75e384:	jmp    75e388 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_+0x48>
  75e386:	mov    $0x6,%al
  75e388:	cmp    $0x4,%al
  75e38a:	sete   %cl
  75e38d:	cmp    $0x7,%al
  75e38f:	sete   %al
  75e392:	or     %cl,%al
  75e394:	pop    %rcx
  75e395:	ret
  75e396:	lea    -0x68ba55(%rip),%rdi        # d2948 <GCC_except_table0+0x1057c>
  75e39d:	lea    0x33d04c(%rip),%rdx        # a9b3f0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1aa8>
  75e3a4:	mov    $0x83,%esi
  75e3a9:	call   *0x35bd39(%rip)        # aba0e8 <_DYNAMIC+0x278>
  75e3af:	lea    0x33beea(%rip),%rax        # a9a2a0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x958>
  75e3b6:	mov    %rdx,%rdi
  75e3b9:	mov    %rax,%rdx
  75e3bc:	call   *0x35bd1e(%rip)        # aba0e0 <_DYNAMIC+0x270>

<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::present_inner::{closure#25} bytes=143 frame=24

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075e3d0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersn_0BQ_>:
  75e3d0:	push   %r14
  75e3d2:	push   %rbx
  75e3d3:	push   %rax
  75e3d4:	mov    %rdx,%rbx
  75e3d7:	and    $0xf,%esi
  75e3da:	cmp    $0x7,%esi
  75e3dd:	jb     75e3e7 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersn_0BQ_+0x17>
  75e3df:	lea    -0x8(%rsi),%eax
  75e3e2:	cmp    $0x2,%eax
  75e3e5:	jae    75e40d <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersn_0BQ_+0x3d>
  75e3e7:	mov    0x30(%rbx),%rax
  75e3eb:	mov    %rax,0x30(%rdi)
  75e3ef:	movups (%rbx),%xmm0
  75e3f2:	movups 0x10(%rbx),%xmm1
  75e3f6:	movups 0x20(%rbx),%xmm2
  75e3fa:	movups %xmm2,0x20(%rdi)
  75e3fe:	movups %xmm1,0x10(%rdi)
  75e402:	movups %xmm0,(%rdi)
  75e405:	add    $0x8,%rsp
  75e409:	pop    %rbx
  75e40a:	pop    %r14
  75e40c:	ret
  75e40d:	cmp    $0x7,%esi
  75e410:	jne    75e431 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersn_0BQ_+0x61>
  75e412:	cmpl   $0x27,(%rbx)
  75e415:	jne    75e3e7 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersn_0BQ_+0x17>
  75e417:	cmpq   $0xb,0x8(%rbx)
  75e41c:	jne    75e3e7 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersn_0BQ_+0x17>
  75e41e:	movb   $0x5,0x8(%rdi)
  75e422:	movq   $0x28,(%rdi)
  75e429:	add    $0x8,%rsp
  75e42d:	pop    %rbx
  75e42e:	pop    %r14
  75e430:	ret
  75e431:	lea    -0x68baf0(%rip),%rdi        # d2948 <GCC_except_table0+0x1057c>
  75e438:	lea    0x33cfb1(%rip),%rdx        # a9b3f0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1aa8>
  75e43f:	mov    $0x83,%esi
  75e444:	call   *0x35bc9e(%rip)        # aba0e8 <_DYNAMIC+0x278>
  75e44a:	ud2
  75e44c:	mov    %rax,%r14
  75e44f:	mov    %rbx,%rdi
  75e452:	call   74d7d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  75e457:	mov    %r14,%rdi
  75e45a:	call   a98590 <_Unwind_Resume@plt>

<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::present_inner::{closure#26} bytes=61 frame=72

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075e460 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerso_0BQ_>:
  75e460:	sub    $0x48,%rsp
  75e464:	cvtps2pd (%rdx),%xmm0
  75e467:	cvtps2pd 0x8(%rdx),%xmm1
  75e46b:	movaps %xmm0,0x10(%rsp)
  75e470:	movaps %xmm1,0x20(%rsp)
  75e475:	cvtps2pd 0x10(%rdx),%xmm0
  75e479:	movaps %xmm0,0x30(%rsp)
  75e47e:	movb   $0x0,0x40(%rsp)
  75e483:	movups (%rsi),%xmm0
  75e486:	movaps %xmm0,(%rsp)
  75e48a:	lea    0x10(%rsp),%rsi
  75e48f:	mov    %rsp,%rdx
  75e492:	call   *0x35be60(%rip)        # aba2f8 <_DYNAMIC+0x488>
  75e498:	add    $0x48,%rsp
  75e49c:	ret

<<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::present_inner::{closure#9} as core::ops::function::FnOnce<(gpui_reactivity_core::tree::NodeId, cephal::tree::traits::MeasureInput)>>::call_once::{shim:vtable#0} bytes=57 frame=56

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075ef90 <_RNSNvYNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtBc_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0INtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceTNtNtCscO85OU7Wpt0_20gpui_reactivity_core4tree6NodeIdNtNtNtCs2M7EwM6HstD_6cephal4tree6traits12MeasureInputEE9call_once6vtableBV_>:
  75ef90:	push   %rbx
  75ef91:	sub    $0x30,%rsp
  75ef95:	mov    %rdi,%rbx
  75ef98:	lea    0x10(%rsp),%rax
  75ef9d:	movups (%rcx),%xmm0
  75efa0:	movups 0x10(%rcx),%xmm1
  75efa4:	movaps %xmm1,0x20(%rsp)
  75efa9:	movaps %xmm0,0x10(%rsp)
  75efae:	movups (%rdx),%xmm0
  75efb1:	movaps %xmm0,(%rsp)
  75efb5:	mov    %rsp,%rdx
  75efb8:	mov    %rax,%rcx
  75efbb:	call   75d840 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_>
  75efc0:	mov    %rbx,%rax
  75efc3:	add    $0x30,%rsp
  75efc7:	pop    %rbx
  75efc8:	ret

canonical_text_public_control::owner_drag bytes=1426 frame=280

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075efd0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag>:
  75efd0:	push   %rbp
  75efd1:	push   %r15
  75efd3:	push   %r14
  75efd5:	push   %r13
  75efd7:	push   %r12
  75efd9:	push   %rbx
  75efda:	sub    $0xe8,%rsp
  75efe1:	movss  %xmm1,0x8(%rsp)
  75efe7:	movss  %xmm0,0x94(%rsp)
  75eff0:	mov    (%rdi),%r15
  75eff3:	test   %r15,%r15
  75eff6:	je     75f350 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x380>
  75effc:	cmpb   $0x0,0x76e(%r15)
  75f004:	jne    75f357 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x387>
  75f00a:	cmpb   $0x1,0x76a(%r15)
  75f012:	jne    75f35e <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x38e>
  75f018:	mov    %rsi,0xb0(%rsp)
  75f020:	mov    %rdi,0x98(%rsp)
  75f028:	mov    0x5c0(%r15),%rbp
  75f02f:	mov    $0x1a,%eax
  75f034:	mov    %rax,0x88(%rsp)
  75f03c:	test   %rbp,%rbp
  75f03f:	je     75f36b <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x39b>
  75f045:	mov    0x5b8(%r15),%r14
  75f04c:	shl    $0x6,%rbp
  75f050:	lea    0x1e8(%r15),%r12
  75f057:	xor    %ebx,%ebx
  75f059:	mov    0x35b108(%rip),%r13        # aba168 <_DYNAMIC+0x2f8>
  75f060:	jmp    75f07d <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0xad>
  75f062:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  75f070:	add    $0x40,%rbx
  75f074:	cmp    %rbx,%rbp
  75f077:	je     75f36b <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x39b>
  75f07d:	cmpb   $0x4,0x3d(%r14,%rbx,1)
  75f083:	jne    75f070 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0xa0>
  75f085:	mov    0x20(%r14,%rbx,1),%rsi
  75f08a:	mov    %r12,%rdi
  75f08d:	call   *%r13
  75f090:	test   %al,%al
  75f092:	je     75f070 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0xa0>
  75f094:	mov    0x20(%r14,%rbx,1),%rsi
  75f099:	lea    0x5f0(%r15),%rdi
  75f0a0:	call   *0x35b26a(%rip)        # aba310 <_DYNAMIC+0x4a0>
  75f0a6:	cmpb   $0x0,0x76e(%r15)
  75f0ae:	jne    75f3ae <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x3de>
  75f0b4:	mov    %rdx,%rcx
  75f0b7:	lea    0x10(%rsp),%rdi
  75f0bc:	mov    %r15,%rsi
  75f0bf:	mov    %rax,%rdx
  75f0c2:	call   76ae10 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11input_indexBY_>
  75f0c7:	mov    0x10(%rsp),%rax
  75f0cc:	mov    0x18(%rsp),%rdx
  75f0d1:	cmp    $0xfffffffffffffffe,%rax
  75f0d5:	mov    0x98(%rsp),%rbx
  75f0dd:	jne    75f3b9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x3e9>
  75f0e3:	lea    0x50(%rsp),%rdi
  75f0e8:	mov    %r15,%rsi
  75f0eb:	call   76af50 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE12selection_atBY_>
  75f0f0:	cmpq   $0xfffffffffffffffe,0x50(%rsp)
  75f0f6:	jne    75f3e4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x414>
  75f0fc:	movups 0x58(%rsp),%xmm0
  75f101:	movaps %xmm0,0xa0(%rsp)
  75f109:	movss  0x94(%rsp),%xmm0
  75f112:	movss  %xmm0,0x14(%rsp)
  75f118:	movss  0x8(%rsp),%xmm0
  75f11e:	movss  %xmm0,0x18(%rsp)
  75f124:	movl   $0x0,0x10(%rsp)
  75f12c:	lea    0x50(%rsp),%rdi
  75f131:	lea    0x10(%rsp),%rcx
  75f136:	mov    %rbx,%rsi
  75f139:	mov    0xb0(%rsp),%rdx
  75f141:	call   76d910 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_>
  75f146:	cmpl   $0xfffffffe,0x50(%rsp)
  75f14b:	jne    75f2df <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x30f>
  75f151:	mov    (%rbx),%rsi
  75f154:	lea    0xb8(%rsp),%rdi
  75f15c:	call   760ba0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack>
  75f161:	mov    (%rbx),%r14
  75f164:	test   %r14,%r14
  75f167:	je     75f446 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x476>
  75f16d:	cmpb   $0x0,0x76e(%r14)
  75f175:	jne    75f44d <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x47d>
  75f17b:	cmpb   $0x1,0x76a(%r14)
  75f183:	jne    75f454 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x484>
  75f189:	mov    0x5c0(%r14),%rbp
  75f190:	mov    $0x1a,%eax
  75f195:	mov    %rax,0x8(%rsp)
  75f19a:	test   %rbp,%rbp
  75f19d:	je     75f45e <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x48e>
  75f1a3:	mov    0x5b8(%r14),%r12
  75f1aa:	shl    $0x6,%rbp
  75f1ae:	lea    0x1e8(%r14),%r15
  75f1b5:	xor    %ebx,%ebx
  75f1b7:	jmp    75f1cd <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x1fd>
  75f1b9:	nopl   0x0(%rax)
  75f1c0:	add    $0x40,%rbx
  75f1c4:	cmp    %rbx,%rbp
  75f1c7:	je     75f45e <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x48e>
  75f1cd:	cmpb   $0x4,0x3d(%r12,%rbx,1)
  75f1d3:	jne    75f1c0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x1f0>
  75f1d5:	mov    0x20(%r12,%rbx,1),%rsi
  75f1da:	mov    %r15,%rdi
  75f1dd:	call   *%r13
  75f1e0:	test   %al,%al
  75f1e2:	je     75f1c0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x1f0>
  75f1e4:	mov    0x20(%r12,%rbx,1),%rsi
  75f1e9:	add    $0x5f0,%r14
  75f1f0:	mov    %r14,%rdi
  75f1f3:	call   *0x35b117(%rip)        # aba310 <_DYNAMIC+0x4a0>
  75f1f9:	mov    %rdx,%rcx
  75f1fc:	mov    0x98(%rsp),%rdx
  75f204:	mov    (%rdx),%rbx
  75f207:	test   %rbx,%rbx
  75f20a:	je     75f49e <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x4ce>
  75f210:	cmpb   $0x0,0x76e(%rbx)
  75f217:	jne    75f4b2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x4e2>
  75f21d:	lea    0x10(%rsp),%rdi
  75f222:	mov    %rbx,%rsi
  75f225:	mov    %rax,%rdx
  75f228:	call   76ae10 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11input_indexBY_>
  75f22d:	mov    0x10(%rsp),%rax
  75f232:	mov    0x18(%rsp),%rdx
  75f237:	cmp    $0xfffffffffffffffe,%rax
  75f23b:	jne    75f4bd <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x4ed>
  75f241:	lea    0x50(%rsp),%rdi
  75f246:	mov    %rbx,%rsi
  75f249:	call   76af50 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE12selection_atBY_>
  75f24e:	cmpq   $0xfffffffffffffffe,0x50(%rsp)
  75f254:	jne    75f4e8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x518>
  75f25a:	movups 0x58(%rsp),%xmm0
  75f25f:	movaps %xmm0,0x10(%rsp)
  75f264:	movzbl 0x1c(%rsp),%ecx
  75f269:	cmp    0xac(%rsp),%cl
  75f270:	mov    0x18(%rsp),%edx
  75f274:	sete   %al
  75f277:	cmp    0xa8(%rsp),%edx
  75f27e:	je     75f282 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x2b2>
  75f280:	xor    %eax,%eax
  75f282:	test   %al,%al
  75f284:	jne    75f337 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x367>
  75f28a:	mov    0xd0(%rsp),%rsi
  75f292:	xor    0xc8(%rsp),%rsi
  75f29a:	movabs $0x100000001b3,%rdi
  75f2a4:	imul   %rdi,%rsi
  75f2a8:	mov    0x10(%rsp),%eax
  75f2ac:	xor    %rsi,%rax
  75f2af:	movzbl 0x14(%rsp),%esi
  75f2b4:	imul   %rdi,%rax
  75f2b8:	xor    %rsi,%rax
  75f2bb:	imul   %rdi,%rax
  75f2bf:	xor    %rdx,%rax
  75f2c2:	imul   %rdi,%rax
  75f2c6:	xor    %rcx,%rax
  75f2c9:	imul   %rdi,%rax
  75f2cd:	add    $0xe8,%rsp
  75f2d4:	pop    %rbx
  75f2d5:	pop    %r12
  75f2d7:	pop    %r13
  75f2d9:	pop    %r14
  75f2db:	pop    %r15
  75f2dd:	pop    %rbp
  75f2de:	ret
  75f2df:	mov    0x80(%rsp),%rax
  75f2e7:	mov    %rax,0x40(%rsp)
  75f2ec:	movups 0x50(%rsp),%xmm0
  75f2f1:	movups 0x60(%rsp),%xmm1
  75f2f6:	movups 0x70(%rsp),%xmm2
  75f2fb:	movaps %xmm2,0x30(%rsp)
  75f300:	movaps %xmm1,0x20(%rsp)
  75f305:	movaps %xmm0,0x10(%rsp)
  75f30a:	lea    -0x68f6af(%rip),%rdi        # cfc62 <GCC_except_table0+0xd896>
  75f311:	lea    0x33b848(%rip),%rcx        # a9ab60 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1218>
  75f318:	lea    0x33b1d9(%rip),%r8        # a9a4f8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xbb0>
  75f31f:	lea    0x10(%rsp),%rbx
  75f324:	mov    $0x2b,%esi
  75f329:	mov    %rbx,%rdx
  75f32c:	call   *0x35ae4e(%rip)        # aba180 <_DYNAMIC+0x310>
  75f332:	jmp    75f545 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x575>
  75f337:	lea    0x18(%rsp),%rdi
  75f33c:	lea    0xa8(%rsp),%rsi
  75f344:	lea    0x33b1dd(%rip),%rdx        # a9a528 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xbe0>
  75f34b:	call   74f553 <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextPositionBM_ECs9C2G9YFESsD_29canonical_text_public_control>
  75f350:	mov    $0xd,%eax
  75f355:	jmp    75f363 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x393>
  75f357:	mov    $0xe,%eax
  75f35c:	jmp    75f363 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x393>
  75f35e:	mov    $0x12,%eax
  75f363:	mov    %rax,0x88(%rsp)
  75f36b:	mov    0x88(%rsp),%rax
  75f373:	mov    %rax,0x10(%rsp)
  75f378:	movq   $0x0,0x18(%rsp)
  75f381:	lea    -0x68f9a7(%rip),%rdi        # cf9e1 <GCC_except_table0+0xd615>
  75f388:	lea    0x33b7d1(%rip),%rcx        # a9ab60 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1218>
  75f38f:	lea    0x33b132(%rip),%r8        # a9a4c8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xb80>
  75f396:	lea    0x10(%rsp),%rbx
  75f39b:	mov    $0x2a,%esi
  75f3a0:	mov    %rbx,%rdx
  75f3a3:	call   *0x35add7(%rip)        # aba180 <_DYNAMIC+0x310>
  75f3a9:	jmp    75f545 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x575>
  75f3ae:	movq   $0xe,0x50(%rsp)
  75f3b7:	jmp    75f3e4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x414>
  75f3b9:	mov    0x40(%rsp),%rcx
  75f3be:	mov    %rcx,0x80(%rsp)
  75f3c6:	movups 0x20(%rsp),%xmm0
  75f3cb:	movups 0x30(%rsp),%xmm1
  75f3d0:	movups %xmm1,0x70(%rsp)
  75f3d5:	movups %xmm0,0x60(%rsp)
  75f3da:	mov    %rax,0x50(%rsp)
  75f3df:	mov    %rdx,0x58(%rsp)
  75f3e4:	mov    0x80(%rsp),%rax
  75f3ec:	mov    %rax,0x40(%rsp)
  75f3f1:	mov    0x50(%rsp),%rax
  75f3f6:	mov    0x58(%rsp),%rcx
  75f3fb:	movups 0x60(%rsp),%xmm0
  75f400:	movups 0x70(%rsp),%xmm1
  75f405:	movaps %xmm1,0x30(%rsp)
  75f40a:	movaps %xmm0,0x20(%rsp)
  75f40f:	mov    %rax,0x10(%rsp)
  75f414:	mov    %rcx,0x18(%rsp)
  75f419:	lea    -0x68f7be(%rip),%rdi        # cfc62 <GCC_except_table0+0xd896>
  75f420:	lea    0x33b739(%rip),%rcx        # a9ab60 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1218>
  75f427:	lea    0x33b0b2(%rip),%r8        # a9a4e0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xb98>
  75f42e:	lea    0x10(%rsp),%rbx
  75f433:	mov    $0x2b,%esi
  75f438:	mov    %rbx,%rdx
  75f43b:	call   *0x35ad3f(%rip)        # aba180 <_DYNAMIC+0x310>
  75f441:	jmp    75f545 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x575>
  75f446:	mov    $0xd,%eax
  75f44b:	jmp    75f459 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x489>
  75f44d:	mov    $0xe,%eax
  75f452:	jmp    75f459 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x489>
  75f454:	mov    $0x12,%eax
  75f459:	mov    %rax,0x8(%rsp)
  75f45e:	mov    0x8(%rsp),%rax
  75f463:	mov    %rax,0x10(%rsp)
  75f468:	movq   $0x0,0x18(%rsp)
  75f471:	lea    -0x68fa97(%rip),%rdi        # cf9e1 <GCC_except_table0+0xd615>
  75f478:	lea    0x33b6e1(%rip),%rcx        # a9ab60 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1218>
  75f47f:	lea    0x33b042(%rip),%r8        # a9a4c8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xb80>
  75f486:	lea    0x10(%rsp),%rbx
  75f48b:	mov    $0x2a,%esi
  75f490:	mov    %rbx,%rdx
  75f493:	call   *0x35ace7(%rip)        # aba180 <_DYNAMIC+0x310>
  75f499:	jmp    75f545 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x575>
  75f49e:	movq   $0xd,0x50(%rsp)
  75f4a7:	movq   $0x0,0x58(%rsp)
  75f4b0:	jmp    75f4e8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x518>
  75f4b2:	movq   $0xe,0x50(%rsp)
  75f4bb:	jmp    75f4e8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x518>
  75f4bd:	mov    0x40(%rsp),%rcx
  75f4c2:	mov    %rcx,0x80(%rsp)
  75f4ca:	movups 0x20(%rsp),%xmm0
  75f4cf:	movups 0x30(%rsp),%xmm1
  75f4d4:	movups %xmm1,0x70(%rsp)
  75f4d9:	movups %xmm0,0x60(%rsp)
  75f4de:	mov    %rax,0x50(%rsp)
  75f4e3:	mov    %rdx,0x58(%rsp)
  75f4e8:	mov    0x80(%rsp),%rax
  75f4f0:	mov    %rax,0x40(%rsp)
  75f4f5:	mov    0x50(%rsp),%rax
  75f4fa:	mov    0x58(%rsp),%rcx
  75f4ff:	movups 0x60(%rsp),%xmm0
  75f504:	movups 0x70(%rsp),%xmm1
  75f509:	movaps %xmm1,0x30(%rsp)
  75f50e:	movaps %xmm0,0x20(%rsp)
  75f513:	mov    %rax,0x10(%rsp)
  75f518:	mov    %rcx,0x18(%rsp)
  75f51d:	lea    -0x68f8c2(%rip),%rdi        # cfc62 <GCC_except_table0+0xd896>
  75f524:	lea    0x33b635(%rip),%rcx        # a9ab60 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1218>
  75f52b:	lea    0x33afde(%rip),%r8        # a9a510 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xbc8>
  75f532:	lea    0x10(%rsp),%rbx
  75f537:	mov    $0x2b,%esi
  75f53c:	mov    %rbx,%rdx
  75f53f:	call   *0x35ac3b(%rip)        # aba180 <_DYNAMIC+0x310>
  75f545:	ud2
  75f547:	jmp    75f54f <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x57f>
  75f549:	jmp    75f54f <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x57f>
  75f54b:	jmp    75f54f <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x57f>
  75f54d:	jmp    75f54f <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x57f>
  75f54f:	mov    %rax,%r14
  75f552:	mov    %rbx,%rdi
  75f555:	call   74d7d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  75f55a:	mov    %r14,%rdi
  75f55d:	call   a98590 <_Unwind_Resume@plt>

canonical_text_public_control::owner_arrow bytes=1422 frame=248

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075f570 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow>:
  75f570:	push   %rbp
  75f571:	push   %r15
  75f573:	push   %r14
  75f575:	push   %r13
  75f577:	push   %r12
  75f579:	push   %rbx
  75f57a:	sub    $0xc8,%rsp
  75f581:	mov    (%rdi),%rbx
  75f584:	test   %rbx,%rbx
  75f587:	je     75f881 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x311>
  75f58d:	cmpb   $0x0,0x76e(%rbx)
  75f594:	jne    75f888 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x318>
  75f59a:	cmpb   $0x1,0x76a(%rbx)
  75f5a1:	jne    75f88f <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x31f>
  75f5a7:	mov    %esi,0x38(%rsp)
  75f5ab:	mov    0x5c0(%rbx),%r12
  75f5b2:	mov    $0x1a,%eax
  75f5b7:	mov    %rax,0x78(%rsp)
  75f5bc:	test   %r12,%r12
  75f5bf:	je     75f899 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x329>
  75f5c5:	mov    0x5b8(%rbx),%r13
  75f5cc:	shl    $0x6,%r12
  75f5d0:	lea    0x1e8(%rbx),%r14
  75f5d7:	xor    %r15d,%r15d
  75f5da:	mov    0x35ab87(%rip),%rbp        # aba168 <_DYNAMIC+0x2f8>
  75f5e1:	jmp    75f5fd <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x8d>
  75f5e3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  75f5f0:	add    $0x40,%r15
  75f5f4:	cmp    %r15,%r12
  75f5f7:	je     75f899 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x329>
  75f5fd:	cmpb   $0x4,0x3d(%r13,%r15,1)
  75f603:	jne    75f5f0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x80>
  75f605:	mov    0x20(%r13,%r15,1),%rsi
  75f60a:	mov    %r14,%rdi
  75f60d:	call   *%rbp
  75f60f:	test   %al,%al
  75f611:	je     75f5f0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x80>
  75f613:	mov    0x20(%r13,%r15,1),%rsi
  75f618:	lea    0x5f0(%rbx),%rdi
  75f61f:	call   *0x35aceb(%rip)        # aba310 <_DYNAMIC+0x4a0>
  75f625:	cmpb   $0x0,0x76e(%rbx)
  75f62c:	jne    75f8d6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x366>
  75f632:	mov    %rdx,%rcx
  75f635:	mov    %rsp,%rdi
  75f638:	mov    %rbx,%rsi
  75f63b:	mov    %rax,%rdx
  75f63e:	call   76ae10 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11input_indexBY_>
  75f643:	mov    (%rsp),%rax
  75f647:	mov    0x8(%rsp),%rdx
  75f64c:	cmp    $0xfffffffffffffffe,%rax
  75f650:	jne    75f8e1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x371>
  75f656:	lea    0x40(%rsp),%rdi
  75f65b:	mov    %rbx,%rsi
  75f65e:	call   76af50 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE12selection_atBY_>
  75f663:	cmpq   $0xfffffffffffffffe,0x40(%rsp)
  75f669:	jne    75f909 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x399>
  75f66f:	movups 0x48(%rsp),%xmm0
  75f674:	movaps %xmm0,0x80(%rsp)
  75f67c:	cmpb   $0x1,0x76e(%rbx)
  75f683:	je     75f965 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x3f5>
  75f689:	movq   $0x0,0x758(%rbx)
  75f694:	mov    0x628(%rbx),%r12
  75f69b:	test   %r12,%r12
  75f69e:	je     75f72c <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x1bc>
  75f6a4:	cmp    0x5f0(%rbx),%r12
  75f6ab:	jne    75fa50 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x4e0>
  75f6b1:	mov    0x630(%rbx),%r13
  75f6b8:	mov    %rsp,%rdi
  75f6bb:	mov    %rbx,%rsi
  75f6be:	mov    %r13,%rdx
  75f6c1:	call   78d180 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE16resolve_identityBO_>
  75f6c6:	mov    (%rsp),%rax
  75f6ca:	mov    0x8(%rsp),%rdi
  75f6cf:	cmp    $0xfffffffffffffffe,%rax
  75f6d3:	jne    75fa55 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x4e5>
  75f6d9:	mov    0x2e0(%rbx),%rsi
  75f6e0:	cmp    %rsi,%rdi
  75f6e3:	jae    75fad6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x566>
  75f6e9:	mov    0x2d8(%rbx),%rax
  75f6f0:	lea    (%rdi,%rdi,4),%rcx
  75f6f4:	mov    0x20(%rax,%rcx,8),%edi
  75f6f8:	call   776560 <_RNvMsh_NtCslbxve4rcJus_4gpui7runtimeNtB5_4Node4kind>
  75f6fd:	cmp    $0x4,%al
  75f6ff:	jne    75f72c <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x1bc>
  75f701:	movzbl 0x38(%rsp),%r8d
  75f707:	lea    0x40(%rsp),%rdi
  75f70c:	mov    %rbx,%rsi
  75f70f:	mov    %r12,%rdx
  75f712:	mov    %r13,%rcx
  75f715:	mov    $0x1,%r9d
  75f71b:	call   7703b0 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE14move_selectionB12_>
  75f720:	cmpq   $0xfffffffffffffffe,0x40(%rsp)
  75f726:	jne    75fa7d <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x50d>
  75f72c:	lea    0x98(%rsp),%rdi
  75f734:	mov    %rbx,%rsi
  75f737:	call   760ba0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack>
  75f73c:	cmpb   $0x0,0x76e(%rbx)
  75f743:	jne    75f973 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x403>
  75f749:	cmpb   $0x1,0x76a(%rbx)
  75f750:	jne    75f97a <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x40a>
  75f756:	mov    0x5c0(%rbx),%r13
  75f75d:	mov    $0x1a,%eax
  75f762:	mov    %rax,0x38(%rsp)
  75f767:	test   %r13,%r13
  75f76a:	je     75f984 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x414>
  75f770:	mov    0x5b8(%rbx),%r15
  75f777:	shl    $0x6,%r13
  75f77b:	xor    %r12d,%r12d
  75f77e:	jmp    75f78d <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x21d>
  75f780:	add    $0x40,%r12
  75f784:	cmp    %r12,%r13
  75f787:	je     75f984 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x414>
  75f78d:	cmpb   $0x4,0x3d(%r15,%r12,1)
  75f793:	jne    75f780 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x210>
  75f795:	mov    0x20(%r15,%r12,1),%rsi
  75f79a:	mov    %r14,%rdi
  75f79d:	call   *%rbp
  75f79f:	test   %al,%al
  75f7a1:	je     75f780 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x210>
  75f7a3:	mov    0x20(%r15,%r12,1),%rsi
  75f7a8:	lea    0x5f0(%rbx),%rdi
  75f7af:	call   *0x35ab5b(%rip)        # aba310 <_DYNAMIC+0x4a0>
  75f7b5:	cmpb   $0x0,0x76e(%rbx)
  75f7bc:	jne    75f9c1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x451>
  75f7c2:	mov    %rdx,%rcx
  75f7c5:	mov    %rsp,%rdi
  75f7c8:	mov    %rbx,%rsi
  75f7cb:	mov    %rax,%rdx
  75f7ce:	call   76ae10 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11input_indexBY_>
  75f7d3:	mov    (%rsp),%rax
  75f7d7:	mov    0x8(%rsp),%rdx
  75f7dc:	cmp    $0xfffffffffffffffe,%rax
  75f7e0:	jne    75f9cc <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x45c>
  75f7e6:	lea    0x40(%rsp),%rdi
  75f7eb:	mov    %rbx,%rsi
  75f7ee:	call   76af50 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE12selection_atBY_>
  75f7f3:	cmpq   $0xfffffffffffffffe,0x40(%rsp)
  75f7f9:	jne    75f9f4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x484>
  75f7ff:	movups 0x48(%rsp),%xmm0
  75f804:	movaps %xmm0,(%rsp)
  75f808:	movzbl 0xc(%rsp),%ecx
  75f80d:	cmp    0x8c(%rsp),%cl
  75f814:	mov    0x8(%rsp),%edx
  75f818:	sete   %al
  75f81b:	cmp    0x88(%rsp),%edx
  75f822:	je     75f826 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x2b6>
  75f824:	xor    %eax,%eax
  75f826:	test   %al,%al
  75f828:	jne    75f868 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x2f8>
  75f82a:	mov    0xb0(%rsp),%rax
  75f832:	xor    0xa8(%rsp),%rax
  75f83a:	movabs $0x100000001b3,%rsi
  75f844:	imul   %rsi,%rax
  75f848:	xor    %rdx,%rax
  75f84b:	imul   %rsi,%rax
  75f84f:	xor    %rcx,%rax
  75f852:	imul   %rsi,%rax
  75f856:	add    $0xc8,%rsp
  75f85d:	pop    %rbx
  75f85e:	pop    %r12
  75f860:	pop    %r13
  75f862:	pop    %r14
  75f864:	pop    %r15
  75f866:	pop    %rbp
  75f867:	ret
  75f868:	lea    0x8(%rsp),%rdi
  75f86d:	lea    0x88(%rsp),%rsi
  75f875:	lea    0x33ad0c(%rip),%rdx        # a9a588 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xc40>
  75f87c:	call   74f553 <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextPositionBM_ECs9C2G9YFESsD_29canonical_text_public_control>
  75f881:	mov    $0xd,%eax
  75f886:	jmp    75f894 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x324>
  75f888:	mov    $0xe,%eax
  75f88d:	jmp    75f894 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x324>
  75f88f:	mov    $0x12,%eax
  75f894:	mov    %rax,0x78(%rsp)
  75f899:	mov    0x78(%rsp),%rax
  75f89e:	mov    %rax,(%rsp)
  75f8a2:	movq   $0x0,0x8(%rsp)
  75f8ab:	lea    -0x68fed1(%rip),%rdi        # cf9e1 <GCC_except_table0+0xd615>
  75f8b2:	lea    0x33b2a7(%rip),%rcx        # a9ab60 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1218>
  75f8b9:	lea    0x33ac08(%rip),%r8        # a9a4c8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xb80>
  75f8c0:	mov    %rsp,%rbx
  75f8c3:	mov    $0x2a,%esi
  75f8c8:	mov    %rbx,%rdx
  75f8cb:	call   *0x35a8af(%rip)        # aba180 <_DYNAMIC+0x310>
  75f8d1:	jmp    75fad4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x564>
  75f8d6:	movq   $0xe,0x40(%rsp)
  75f8df:	jmp    75f909 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x399>
  75f8e1:	mov    0x30(%rsp),%rcx
  75f8e6:	mov    %rcx,0x70(%rsp)
  75f8eb:	movups 0x10(%rsp),%xmm0
  75f8f0:	movups 0x20(%rsp),%xmm1
  75f8f5:	movups %xmm1,0x60(%rsp)
  75f8fa:	movups %xmm0,0x50(%rsp)
  75f8ff:	mov    %rax,0x40(%rsp)
  75f904:	mov    %rdx,0x48(%rsp)
  75f909:	mov    0x70(%rsp),%rax
  75f90e:	mov    %rax,0x30(%rsp)
  75f913:	mov    0x40(%rsp),%rax
  75f918:	mov    0x48(%rsp),%rcx
  75f91d:	movups 0x50(%rsp),%xmm0
  75f922:	movups 0x60(%rsp),%xmm1
  75f927:	movaps %xmm1,0x20(%rsp)
  75f92c:	movaps %xmm0,0x10(%rsp)
  75f931:	mov    %rax,(%rsp)
  75f935:	mov    %rcx,0x8(%rsp)
  75f93a:	lea    -0x68fcdf(%rip),%rdi        # cfc62 <GCC_except_table0+0xd896>
  75f941:	lea    0x33b218(%rip),%rcx        # a9ab60 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1218>
  75f948:	lea    0x33abf1(%rip),%r8        # a9a540 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xbf8>
  75f94f:	mov    %rsp,%rbx
  75f952:	mov    $0x2b,%esi
  75f957:	mov    %rbx,%rdx
  75f95a:	call   *0x35a820(%rip)        # aba180 <_DYNAMIC+0x310>
  75f960:	jmp    75fad4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x564>
  75f965:	movq   $0xe,0x40(%rsp)
  75f96e:	jmp    75fa7d <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x50d>
  75f973:	mov    $0xe,%eax
  75f978:	jmp    75f97f <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x40f>
  75f97a:	mov    $0x12,%eax
  75f97f:	mov    %rax,0x38(%rsp)
  75f984:	mov    0x38(%rsp),%rax
  75f989:	mov    %rax,(%rsp)
  75f98d:	movq   $0x0,0x8(%rsp)
  75f996:	lea    -0x68ffbc(%rip),%rdi        # cf9e1 <GCC_except_table0+0xd615>
  75f99d:	lea    0x33b1bc(%rip),%rcx        # a9ab60 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1218>
  75f9a4:	lea    0x33ab1d(%rip),%r8        # a9a4c8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xb80>
  75f9ab:	mov    %rsp,%rbx
  75f9ae:	mov    $0x2a,%esi
  75f9b3:	mov    %rbx,%rdx
  75f9b6:	call   *0x35a7c4(%rip)        # aba180 <_DYNAMIC+0x310>
  75f9bc:	jmp    75fad4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x564>
  75f9c1:	movq   $0xe,0x40(%rsp)
  75f9ca:	jmp    75f9f4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x484>
  75f9cc:	mov    0x30(%rsp),%rcx
  75f9d1:	mov    %rcx,0x70(%rsp)
  75f9d6:	movups 0x10(%rsp),%xmm0
  75f9db:	movups 0x20(%rsp),%xmm1
  75f9e0:	movups %xmm1,0x60(%rsp)
  75f9e5:	movups %xmm0,0x50(%rsp)
  75f9ea:	mov    %rax,0x40(%rsp)
  75f9ef:	mov    %rdx,0x48(%rsp)
  75f9f4:	mov    0x70(%rsp),%rax
  75f9f9:	mov    %rax,0x30(%rsp)
  75f9fe:	mov    0x40(%rsp),%rax
  75fa03:	mov    0x48(%rsp),%rcx
  75fa08:	movups 0x50(%rsp),%xmm0
  75fa0d:	movups 0x60(%rsp),%xmm1
  75fa12:	movaps %xmm1,0x20(%rsp)
  75fa17:	movaps %xmm0,0x10(%rsp)
  75fa1c:	mov    %rax,(%rsp)
  75fa20:	mov    %rcx,0x8(%rsp)
  75fa25:	lea    -0x68fdca(%rip),%rdi        # cfc62 <GCC_except_table0+0xd896>
  75fa2c:	lea    0x33b12d(%rip),%rcx        # a9ab60 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1218>
  75fa33:	lea    0x33ab36(%rip),%r8        # a9a570 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xc28>
  75fa3a:	mov    %rsp,%rbx
  75fa3d:	mov    $0x2b,%esi
  75fa42:	mov    %rbx,%rdx
  75fa45:	call   *0x35a735(%rip)        # aba180 <_DYNAMIC+0x310>
  75fa4b:	jmp    75fad4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x564>
  75fa50:	mov    $0x11,%eax
  75fa55:	mov    0x30(%rsp),%rcx
  75fa5a:	mov    %rcx,0x70(%rsp)
  75fa5f:	movups 0x10(%rsp),%xmm0
  75fa64:	movups 0x20(%rsp),%xmm1
  75fa69:	movups %xmm1,0x60(%rsp)
  75fa6e:	movups %xmm0,0x50(%rsp)
  75fa73:	mov    %rax,0x40(%rsp)
  75fa78:	mov    %rdi,0x48(%rsp)
  75fa7d:	mov    0x70(%rsp),%rax
  75fa82:	mov    %rax,0x30(%rsp)
  75fa87:	mov    0x40(%rsp),%rax
  75fa8c:	mov    0x48(%rsp),%rcx
  75fa91:	movups 0x50(%rsp),%xmm0
  75fa96:	movups 0x60(%rsp),%xmm1
  75fa9b:	movaps %xmm1,0x20(%rsp)
  75faa0:	movaps %xmm0,0x10(%rsp)
  75faa5:	mov    %rax,(%rsp)
  75faa9:	mov    %rcx,0x8(%rsp)
  75faae:	lea    -0x68fe53(%rip),%rdi        # cfc62 <GCC_except_table0+0xd896>
  75fab5:	lea    0x33b0a4(%rip),%rcx        # a9ab60 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1218>
  75fabc:	lea    0x33aa95(%rip),%r8        # a9a558 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xc10>
  75fac3:	mov    %rsp,%rbx
  75fac6:	mov    $0x2b,%esi
  75facb:	mov    %rbx,%rdx
  75face:	call   *0x35a6ac(%rip)        # aba180 <_DYNAMIC+0x310>
  75fad4:	ud2
  75fad6:	lea    0x33b57b(%rip),%rdx        # a9b058 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1710>
  75fadd:	call   *0x35a5fd(%rip)        # aba0e0 <_DYNAMIC+0x270>
  75fae3:	jmp    75faeb <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x57b>
  75fae5:	jmp    75faeb <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x57b>
  75fae7:	jmp    75faeb <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x57b>
  75fae9:	jmp    75faeb <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x57b>
  75faeb:	mov    %rax,%r14
  75faee:	mov    %rbx,%rdi
  75faf1:	call   74d7d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  75faf6:	mov    %r14,%rdi
  75faf9:	call   a98590 <_Unwind_Resume@plt>

canonical_text_public_control::query_visual bytes=142 frame=40

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075fb00 <_RNvCs9C2G9YFESsD_29canonical_text_public_control12query_visual>:
  75fb00:	push   %rbp
  75fb01:	push   %r15
  75fb03:	push   %r14
  75fb05:	push   %r12
  75fb07:	push   %rbx
  75fb08:	mov    %edx,%r15d
  75fb0b:	mov    %esi,%r14d
  75fb0e:	mov    %rdi,%r12
  75fb11:	call   *0x35a801(%rip)        # aba318 <_DYNAMIC+0x4a8>
  75fb17:	cmp    $0x2,%dl
  75fb1a:	je     75fb74 <_RNvCs9C2G9YFESsD_29canonical_text_public_control12query_visual+0x74>
  75fb1c:	mov    %eax,%ebx
  75fb1e:	mov    %edx,%ebp
  75fb20:	movzbl %r15b,%edx
  75fb24:	mov    %r12,%rdi
  75fb27:	mov    %r14d,%esi
  75fb2a:	call   *0x35a7f0(%rip)        # aba320 <_DYNAMIC+0x4b0>
  75fb30:	cmp    $0x2,%dl
  75fb33:	je     75fb81 <_RNvCs9C2G9YFESsD_29canonical_text_public_control12query_visual+0x81>
  75fb35:	xor    $0x1,%ebx
  75fb38:	movabs $0x100000001b3,%rcx
  75fb42:	imul   %rcx,%rbx
  75fb46:	and    $0x1,%bpl
  75fb4a:	movzbl %bpl,%esi
  75fb4e:	xor    %rbx,%rsi
  75fb51:	imul   %rcx,%rsi
  75fb55:	mov    %eax,%edi
  75fb57:	xor    %rsi,%rdi
  75fb5a:	imul   %rcx,%rdi
  75fb5e:	and    $0x1,%dl
  75fb61:	movzbl %dl,%eax
  75fb64:	xor    %rdi,%rax
  75fb67:	imul   %rcx,%rax
  75fb6b:	pop    %rbx
  75fb6c:	pop    %r12
  75fb6e:	pop    %r14
  75fb70:	pop    %r15
  75fb72:	pop    %rbp
  75fb73:	ret
  75fb74:	lea    0x33abed(%rip),%rdi        # a9a768 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xe20>
  75fb7b:	call   *0x35a5ef(%rip)        # aba170 <_DYNAMIC+0x300>
  75fb81:	lea    0x33abf8(%rip),%rdi        # a9a780 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xe38>
  75fb88:	call   *0x35a5e2(%rip)        # aba170 <_DYNAMIC+0x300>

canonical_text_public_control::owner_prepare bytes=1380 frame=280

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075fb90 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare>:
  75fb90:	push   %rbp
  75fb91:	push   %r15
  75fb93:	push   %r14
  75fb95:	push   %r13
  75fb97:	push   %r12
  75fb99:	push   %rbx
  75fb9a:	sub    $0xe8,%rsp
  75fba1:	mov    %rdi,%r14
  75fba4:	test   %esi,%esi
  75fba6:	jne    75fbae <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x1e>
  75fba8:	pxor   %xmm0,%xmm0
  75fbac:	jmp    75fbb6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x26>
  75fbae:	movd   -0x69d76e(%rip),%xmm0        # c2448 <GCC_except_table0+0x7c>
  75fbb6:	movd   %xmm0,(%rsp)
  75fbbb:	mov    (%r14),%rbx
  75fbbe:	test   %rbx,%rbx
  75fbc1:	je     75feac <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x31c>
  75fbc7:	lea    0x8(%r14),%rax
  75fbcb:	mov    %rbx,0xd8(%rsp)
  75fbd3:	mov    %rax,0xe0(%rsp)
  75fbdb:	cmpb   $0x0,0x76e(%rbx)
  75fbe2:	jne    75fee2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x352>
  75fbe8:	mov    0x6a0(%rbx),%rax
  75fbef:	mov    %rax,0xd0(%rsp)
  75fbf7:	movabs $0x200000001,%r15
  75fc01:	mov    0x248(%rbx),%rbp
  75fc08:	mov    0x250(%rbx),%r12
  75fc0f:	shl    $0x4,%r12
  75fc13:	xor    %r13d,%r13d
  75fc16:	cs nopw 0x0(%rax,%rax,1)
  75fc20:	cmp    %r13,%r12
  75fc23:	je     75fe5d <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x2cd>
  75fc29:	mov    0x0(%rbp,%r13,1),%rdi
  75fc2e:	mov    0x8(%rbp,%r13,1),%rax
  75fc33:	call   *0x18(%rax)
  75fc36:	add    $0x10,%r13
  75fc3a:	cmp    %r15,%rax
  75fc3d:	jne    75fc20 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x90>
  75fc3f:	mov    -0x10(%rbp,%r13,1),%rdi
  75fc44:	mov    -0x8(%rbp,%r13,1),%rax
  75fc49:	lea    0x290(%rbx),%rsi
  75fc50:	call   *0x28(%rax)
  75fc53:	mov    %rax,%rdi
  75fc56:	mov    %rdx,%rax
  75fc59:	lea    0x33b5f0(%rip),%rdx        # a9b250 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1908>
  75fc60:	lea    0x2b0(%rbx),%rsi
  75fc67:	call   *0x20(%rax)
  75fc6a:	mov    %r15,0x18(%rsp)
  75fc6f:	mov    0x18(%rsp),%rcx
  75fc74:	mov    %rcx,0xb0(%rsp)
  75fc7c:	mov    0x20(%rsp),%rcx
  75fc81:	mov    %rcx,0xb8(%rsp)
  75fc89:	test   %al,%al
  75fc8b:	je     75feed <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x35d>
  75fc91:	movq   $0x0,0xb0(%rsp)
  75fc9d:	cmpb   $0x0,0x76e(%rbx)
  75fca4:	jne    75fef4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x364>
  75fcaa:	mov    0x6a0(%rbx),%rax
  75fcb1:	inc    %rax
  75fcb4:	je     75fd75 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x1e5>
  75fcba:	mov    0x2c8(%rbx),%ecx
  75fcc0:	cmp    $0xffffffff,%ecx
  75fcc3:	je     75fe42 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x2b2>
  75fcc9:	inc    %ecx
  75fccb:	mov    %ecx,0x2c8(%rbx)
  75fcd1:	movaps -0x69c158(%rip),%xmm0        # c3b80 <GCC_except_table0+0x17b4>
  75fcd8:	movups %xmm0,0x2b0(%rbx)
  75fcdf:	movss  (%rsp),%xmm0
  75fce4:	movss  %xmm0,0x2c0(%rbx)
  75fcec:	movl   $0x0,0x2c4(%rbx)
  75fcf6:	mov    %rax,0x6a0(%rbx)
  75fcfd:	incq   0x700(%rbx)
  75fd04:	movq   $0x0,0x758(%rbx)
  75fd0f:	lea    0x78(%rsp),%rdi
  75fd14:	lea    0xd8(%rsp),%rsi
  75fd1c:	lea    0xb0(%rsp),%rcx
  75fd24:	mov    %r15,%rdx
  75fd27:	xor    %r8d,%r8d
  75fd2a:	call   7677a0 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB4_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE20after_source_changedBW_>
  75fd2f:	mov    0x78(%rsp),%r12
  75fd34:	cmp    $0xfffffffffffffffe,%r12
  75fd38:	jne    75feff <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x36f>
  75fd3e:	mov    (%r14),%rsi
  75fd41:	lea    0x10(%rsp),%rdi
  75fd46:	call   760ba0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack>
  75fd4b:	mov    0x28(%rsp),%rcx
  75fd50:	xor    0x20(%rsp),%rcx
  75fd55:	movabs $0x100000001b3,%rax
  75fd5f:	imul   %rcx,%rax
  75fd63:	add    $0xe8,%rsp
  75fd6a:	pop    %rbx
  75fd6b:	pop    %r12
  75fd6d:	pop    %r13
  75fd6f:	pop    %r14
  75fd71:	pop    %r15
  75fd73:	pop    %rbp
  75fd74:	ret
  75fd75:	mov    $0x1f,%r12d
  75fd7b:	mov    0x88(%rsp),%r14
  75fd83:	mov    0x90(%rsp),%rbx
  75fd8b:	movd   (%rsp),%xmm0
  75fd90:	movd   %xmm0,%ecx
  75fd94:	mov    %ecx,%r9d
  75fd97:	shr    $0x8,%r9d
  75fd9b:	movabs $0x3f80000000000000,%rsi
  75fda5:	mov    $0x3f800000,%edx
  75fdaa:	mov    $0x2,%r10d
  75fdb0:	pxor   %xmm0,%xmm0
  75fdb4:	mov    %r10,0x10(%rsp)
  75fdb9:	mov    %r12,0x18(%rsp)
  75fdbe:	mov    %rax,0x20(%rsp)
  75fdc3:	mov    %r14,0x28(%rsp)
  75fdc8:	mov    %rbx,0x30(%rsp)
  75fdcd:	mov    %r11b,0x38(%rsp)
  75fdd2:	mov    0x8(%rsp),%eax
  75fdd6:	mov    0xb(%rsp),%r10d
  75fddb:	mov    %eax,0x39(%rsp)
  75fddf:	mov    %r10d,0x3c(%rsp)
  75fde4:	mov    %r13,0x40(%rsp)
  75fde9:	mov    %r15,0x48(%rsp)
  75fdee:	mov    %rdx,0x50(%rsp)
  75fdf3:	mov    %rsi,0x58(%rsp)
  75fdf8:	mov    %cl,0x60(%rsp)
  75fdfc:	mov    %r9w,0x61(%rsp)
  75fe02:	shr    $0x10,%r9d
  75fe06:	mov    %r9b,0x63(%rsp)
  75fe0b:	movd   %xmm0,0x64(%rsp)
  75fe11:	mov    %rdi,0x68(%rsp)
  75fe16:	mov    %r8,0x70(%rsp)
  75fe1b:	lea    -0x6901c0(%rip),%rdi        # cfc62 <GCC_except_table0+0xd896>
  75fe22:	lea    0x33ad97(%rip),%rcx        # a9abc0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1278>
  75fe29:	lea    0x33a990(%rip),%r8        # a9a7c0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xe78>
  75fe30:	lea    0x10(%rsp),%rdx
  75fe35:	mov    $0x2b,%esi
  75fe3a:	call   *0x35a340(%rip)        # aba180 <_DYNAMIC+0x310>
  75fe40:	jmp    75fe5b <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x2cb>
  75fe42:	lea    -0x68d12f(%rip),%rdi        # d2d1a <GCC_except_table0+0x1094e>
  75fe49:	lea    0x33be88(%rip),%rdx        # a9bcd8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2390>
  75fe50:	mov    $0x19,%esi
  75fe55:	call   *0x35a32d(%rip)        # aba188 <_DYNAMIC+0x318>
  75fe5b:	ud2
  75fe5d:	mov    %r15,0x18(%rsp)
  75fe62:	mov    0x18(%rsp),%rax
  75fe67:	mov    %rax,0xb0(%rsp)
  75fe6f:	mov    0x20(%rsp),%rax
  75fe74:	mov    %rax,0xb8(%rsp)
  75fe7c:	mov    $0xb,%eax
  75fe81:	mov    0xb0(%rsp),%rcx
  75fe89:	mov    %rcx,0x88(%rsp)
  75fe91:	mov    0xb8(%rsp),%rcx
  75fe99:	mov    %rcx,0x90(%rsp)
  75fea1:	mov    $0x20,%r12d
  75fea7:	jmp    75fd7b <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x1eb>
  75feac:	movd   (%rsp),%xmm0
  75feb1:	movd   %xmm0,%ecx
  75feb5:	mov    %ecx,%r9d
  75feb8:	shr    $0x8,%r9d
  75febc:	movabs $0x3f80000000000000,%rsi
  75fec6:	mov    $0x3f800000,%edx
  75fecb:	pxor   %xmm0,%xmm0
  75fecf:	mov    $0xd,%r12d
  75fed5:	mov    $0x2,%r10d
  75fedb:	xor    %eax,%eax
  75fedd:	jmp    75fdb4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x224>
  75fee2:	mov    $0xe,%r12d
  75fee8:	jmp    75fd8b <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x1fb>
  75feed:	mov    $0xa,%eax
  75fef2:	jmp    75fe81 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x2f1>
  75fef4:	mov    $0xe,%r12d
  75fefa:	jmp    75fd7b <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x1eb>
  75feff:	mov    0x80(%rsp),%rax
  75ff07:	mov    %rax,(%rsp)
  75ff0b:	mov    0x88(%rsp),%rdx
  75ff13:	movzbl 0x98(%rsp),%ecx
  75ff1b:	mov    0xa0(%rsp),%rdi
  75ff23:	mov    0xa8(%rsp),%r8
  75ff2b:	mov    0x90(%rsp),%rsi
  75ff33:	mov    0x6a0(%rbx),%rax
  75ff3a:	cmp    0xd0(%rsp),%rax
  75ff42:	jne    75ff79 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x3e9>
  75ff44:	lea    0x99(%rsp),%rax
  75ff4c:	mov    (%rax),%r9d
  75ff4f:	mov    0x3(%rax),%eax
  75ff52:	mov    %eax,0xb(%rsp)
  75ff56:	mov    %r9d,0x8(%rsp)
  75ff5b:	mov    $0x4,%r10d
  75ff61:	mov    %r8,%r15
  75ff64:	mov    %rdi,%r13
  75ff67:	mov    %ecx,%r11d
  75ff6a:	mov    %rsi,%rbx
  75ff6d:	mov    %rdx,%r14
  75ff70:	mov    (%rsp),%rax
  75ff74:	jmp    75fdb4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x224>
  75ff79:	movzbl 0x76c(%rbx),%r11d
  75ff81:	cmpq   $0x0,0x6d0(%rbx)
  75ff89:	je     75ff9a <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x40a>
  75ff8b:	test   %r11b,%r11b
  75ff8e:	je     75ff9f <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x40f>
  75ff90:	cmpq   $0xffffffffffffffff,0x5c8(%rbx)
  75ff98:	jne    75ff9f <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x40f>
  75ff9a:	xor    %r10d,%r10d
  75ff9d:	jmp    75ffac <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x41c>
  75ff9f:	mov    0x6e0(%rbx),%rbp
  75ffa6:	mov    $0x1,%r10d
  75ffac:	mov    0x6a8(%rbx),%r14
  75ffb3:	mov    0x758(%rbx),%rbx
  75ffba:	movzbl 0x9b(%rsp),%r15d
  75ffc3:	shl    $0x10,%r15d
  75ffc7:	movzwl 0x99(%rsp),%r9d
  75ffd0:	or     %r15d,%r9d
  75ffd3:	movd   0x9c(%rsp),%xmm0
  75ffdc:	mov    (%rsp),%r15
  75ffe0:	mov    %r12,%r13
  75ffe3:	mov    %rbp,%r12
  75ffe6:	jmp    75fdb4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x224>
  75ffeb:	jmp    75ffed <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x45d>
  75ffed:	mov    %rax,%rdi
  75fff0:	call   *0x35a112(%rip)        # aba108 <_DYNAMIC+0x298>
  75fff6:	mov    %rax,%r14
  75fff9:	mov    %rdx,%r15
  75fffc:	mov    %rax,0x18(%rsp)
  760001:	mov    %rdx,0x20(%rsp)
  760006:	movq   $0xfffffffffffffffe,0x10(%rsp)
  76000f:	mov    %rbx,%rdi
  760012:	call   78d7d0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE6poisonBO_>
  760017:	mov    (%r15),%rax
  76001a:	test   %rax,%rax
  76001d:	je     760024 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x494>
  76001f:	mov    %r14,%rdi
  760022:	call   *%rax
  760024:	mov    0x8(%r15),%rsi
  760028:	mov    $0xf,%r12d
  76002e:	test   %rsi,%rsi
  760031:	je     75fd7b <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x1eb>
  760037:	mov    0x10(%r15),%rdx
  76003b:	mov    %r14,%rdi
  76003e:	call   *0x35a06c(%rip)        # aba0b0 <_DYNAMIC+0x240>
  760044:	jmp    75fd7b <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x1eb>
  760049:	mov    %rax,%rbx
  76004c:	mov    0x8(%r15),%rsi
  760050:	test   %rsi,%rsi
  760053:	je     7600cb <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x53b>
  760055:	mov    0x10(%r15),%rdx
  760059:	mov    %r14,%rdi
  76005c:	call   *0x35a04e(%rip)        # aba0b0 <_DYNAMIC+0x240>
  760062:	mov    %rbx,%rdi
  760065:	call   a98590 <_Unwind_Resume@plt>
  76006a:	mov    %rax,%rbx
  76006d:	lea    0x10(%rsp),%rdi
  760072:	call   7462b0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultIBC_NtNtCslbxve4rcJus_4gpui7element9AdmissionNtNtB15_6source9BindErrorEINtNtCscdodAO9FK5_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECs9C2G9YFESsD_29canonical_text_public_control>
  760077:	jmp    7600cb <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x53b>
  760079:	call   *0x35a059(%rip)        # aba0d8 <_DYNAMIC+0x268>
  76007f:	call   *0x35a08b(%rip)        # aba110 <_DYNAMIC+0x2a0>
  760085:	mov    %rax,%rdi
  760088:	call   *0x35a07a(%rip)        # aba108 <_DYNAMIC+0x298>
  76008e:	mov    %rax,0x18(%rsp)
  760093:	mov    %rdx,0x20(%rsp)
  760098:	movq   $0xfffffffffffffffd,0x10(%rsp)
  7600a1:	mov    %rbx,%rdi
  7600a4:	call   78d7d0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE6poisonBO_>
  7600a9:	lea    0x10(%rsp),%rdi
  7600ae:	call   746320 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultIBC_NtNtNtCslbxve4rcJus_4gpui7runtime5paint12PatchOutcomeNtB15_5ErrorEINtNtCscdodAO9FK5_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECs9C2G9YFESsD_29canonical_text_public_control>
  7600b3:	mov    $0xf,%r12d
  7600b9:	jmp    75fd7b <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x1eb>
  7600be:	mov    %rax,%rbx
  7600c1:	lea    0x10(%rsp),%rdi
  7600c6:	call   746320 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultIBC_NtNtNtCslbxve4rcJus_4gpui7runtime5paint12PatchOutcomeNtB15_5ErrorEINtNtCscdodAO9FK5_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECs9C2G9YFESsD_29canonical_text_public_control>
  7600cb:	mov    %rbx,%rdi
  7600ce:	call   a98590 <_Unwind_Resume@plt>
  7600d3:	call   *0x359fff(%rip)        # aba0d8 <_DYNAMIC+0x268>
  7600d9:	call   *0x35a031(%rip)        # aba110 <_DYNAMIC+0x2a0>
  7600df:	mov    %rax,%rbx
  7600e2:	lea    0x10(%rsp),%rdi
  7600e7:	call   7485b0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui7runtime8SetErrorNtNtCscO85OU7Wpt0_20gpui_reactivity_core8geometry6AffineEECs9C2G9YFESsD_29canonical_text_public_control>
  7600ec:	mov    %rbx,%rdi
  7600ef:	call   a98590 <_Unwind_Resume@plt>

canonical_text_public_control::owner_reshape bytes=340 frame=248

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000760100 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_reshape>:
  760100:	push   %r15
  760102:	push   %r14
  760104:	push   %r13
  760106:	push   %r12
  760108:	push   %rbx
  760109:	sub    $0xd0,%rsp
  760110:	mov    %rdx,%r14
  760113:	test   %rdx,%rdx
  760116:	jns    760127 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_reshape+0x27>
  760118:	xor    %r13d,%r13d
  76011b:	mov    %r13,%rdi
  76011e:	mov    %r14,%rsi
  760121:	call   *0x35a039(%rip)        # aba160 <_DYNAMIC+0x2f0>
  760127:	mov    %rdi,%rbx
  76012a:	je     760162 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_reshape+0x62>
  76012c:	mov    %rsi,%r12
  76012f:	call   *0x359f83(%rip)        # aba0b8 <_DYNAMIC+0x248>
  760135:	mov    $0x1,%r13d
  76013b:	mov    $0x1,%esi
  760140:	mov    %r14,%rdi
  760143:	call   *0x359f77(%rip)        # aba0c0 <_DYNAMIC+0x250>
  760149:	test   %rax,%rax
  76014c:	je     76011b <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_reshape+0x1b>
  76014e:	mov    %rax,%r15
  760151:	mov    %rax,%rdi
  760154:	mov    %r12,%rsi
  760157:	mov    %r14,%rdx
  76015a:	call   *0x359f70(%rip)        # aba0d0 <memcpy@GLIBC_2.14>
  760160:	jmp    760168 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_reshape+0x68>
  760162:	mov    $0x1,%r15d
  760168:	mov    %r14,(%rsp)
  76016c:	mov    %r15,0x8(%rsp)
  760171:	mov    %r14,0x10(%rsp)
  760176:	lea    0x33a54b(%rip),%rdx        # a9a6c8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xd80>
  76017d:	lea    0x68(%rsp),%rdi
  760182:	mov    %rsp,%rcx
  760185:	mov    %rbx,%rsi
  760188:	call   744a80 <_RINvMst_NtCslbxve4rcJus_4gpui7runtimeINtB6_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE3setNtNtCscdodAO9FK5_5alloc6string6StringEBL_>
  76018d:	cmpl   $0xffffffff,0x68(%rsp)
  760192:	jne    7601c8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_reshape+0xc8>
  760194:	mov    (%rbx),%rsi
  760197:	mov    %rsp,%rdi
  76019a:	call   760ba0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack>
  76019f:	mov    0x18(%rsp),%rcx
  7601a4:	xor    0x10(%rsp),%rcx
  7601a9:	movabs $0x100000001b3,%rax
  7601b3:	imul   %rcx,%rax
  7601b7:	add    $0xd0,%rsp
  7601be:	pop    %rbx
  7601bf:	pop    %r12
  7601c1:	pop    %r13
  7601c3:	pop    %r14
  7601c5:	pop    %r15
  7601c7:	ret
  7601c8:	mov    0xc8(%rsp),%rax
  7601d0:	mov    %rax,0x60(%rsp)
  7601d5:	movups 0xb8(%rsp),%xmm0
  7601dd:	movaps %xmm0,0x50(%rsp)
  7601e2:	movups 0xa8(%rsp),%xmm0
  7601ea:	movaps %xmm0,0x40(%rsp)
  7601ef:	movups 0x68(%rsp),%xmm0
  7601f4:	movups 0x78(%rsp),%xmm1
  7601f9:	movups 0x88(%rsp),%xmm2
  760201:	movups 0x98(%rsp),%xmm3
  760209:	movaps %xmm3,0x30(%rsp)
  76020e:	movaps %xmm2,0x20(%rsp)
  760213:	movaps %xmm1,0x10(%rsp)
  760218:	movaps %xmm0,(%rsp)
  76021c:	lea    -0x6905c1(%rip),%rdi        # cfc62 <GCC_except_table0+0xd896>
  760223:	lea    0x33a9b6(%rip),%rcx        # a9abe0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1298>
  76022a:	lea    0x33a5a7(%rip),%r8        # a9a7d8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xe90>
  760231:	mov    %rsp,%rdx
  760234:	mov    $0x2b,%esi
  760239:	call   *0x359f41(%rip)        # aba180 <_DYNAMIC+0x310>
  76023f:	ud2
  760241:	mov    %rax,%rbx
  760244:	mov    %rsp,%rdi
  760247:	call   748670 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui7runtime8SetErrorNtNtCscdodAO9FK5_5alloc6string6StringEECs9C2G9YFESsD_29canonical_text_public_control>
  76024c:	mov    %rbx,%rdi
  76024f:	call   a98590 <_Unwind_Resume@plt>

canonical_text_public_control::map_transcript bytes=880 frame=312

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000760260 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript>:
  760260:	push   %rbp
  760261:	push   %r15
  760263:	push   %r14
  760265:	push   %r13
  760267:	push   %r12
  760269:	push   %rbx
  76026a:	sub    $0x108,%rsp
  760271:	mov    %rdi,%rsi
  760274:	lea    0xc0(%rsp),%rdi
  76027c:	call   *0x35a0a6(%rip)        # aba328 <_DYNAMIC+0x4b8>
  760282:	mov    0x100(%rsp),%rax
  76028a:	mov    %rax,0x50(%rsp)
  76028f:	movups 0xc0(%rsp),%xmm0
  760297:	movups 0xd0(%rsp),%xmm1
  76029f:	movups 0xe0(%rsp),%xmm2
  7602a7:	movups 0xf0(%rsp),%xmm3
  7602af:	movaps %xmm3,0x40(%rsp)
  7602b4:	movaps %xmm2,0x30(%rsp)
  7602b9:	movaps %xmm1,0x20(%rsp)
  7602be:	movaps %xmm0,0x10(%rsp)
  7602c3:	lea    0x60(%rsp),%rdi
  7602c8:	lea    0x10(%rsp),%rsi
  7602cd:	call   798540 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control>
  7602d2:	cmpq   $0x0,0x60(%rsp)
  7602d8:	je     76059d <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x33d>
  7602de:	mov    $0x1,%ebx
  7602e3:	mov    0x48(%rsp),%rax
  7602e8:	mov    %rax,0x80(%rsp)
  7602f0:	movss  0x50(%rsp),%xmm0
  7602f6:	movss  %xmm0,0xc(%rsp)
  7602fc:	mov    0x10(%rsp),%r12
  760301:	mov    0x18(%rsp),%rbp
  760306:	mov    0x30(%rsp),%r13
  76030b:	mov    0x28(%rsp),%r14
  760310:	mov    0x20(%rsp),%r15
  760315:	data16 cs nopw 0x0(%rax,%rax,1)
  760320:	lea    0x88(%rsp),%rdi
  760328:	mov    0x80(%rsp),%rsi
  760330:	movss  0xc(%rsp),%xmm0
  760336:	lea    0x60(%rsp),%rdx
  76033b:	call   75d540 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control>
  760340:	cmpb   $0x2,0x8c(%rsp)
  760348:	jne    760510 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x2b0>
  76034e:	mov    %rbp,%rax
  760351:	cmp    $0x1,%rbp
  760355:	je     760394 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x134>
  760357:	test   %rbp,%rbp
  76035a:	je     7605a2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x342>
  760360:	mov    (%r12),%ecx
  760364:	lea    0xc(%r12),%rdx
  760369:	lea    0x1(%rbp),%rsi
  76036d:	mov    $0x1,%eax
  760372:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  760380:	cmp    (%rdx),%ecx
  760382:	jne    760394 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x134>
  760384:	inc    %rax
  760387:	add    $0xc,%rdx
  76038b:	dec    %rsi
  76038e:	cmp    $0x2,%rsi
  760392:	ja     760380 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x120>
  760394:	sub    %rax,%rbp
  760397:	jb     7605b7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x357>
  76039d:	mov    %rbp,0x18(%rsp)
  7603a2:	test   %r13,%r13
  7603a5:	jne    76043b <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x1db>
  7603ab:	mov    %r14,%rcx
  7603ae:	cmp    $0x1,%r14
  7603b2:	je     7603e4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x184>
  7603b4:	test   %r14,%r14
  7603b7:	je     7605a2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x342>
  7603bd:	mov    (%r15),%edx
  7603c0:	lea    0xc(%r15),%rsi
  7603c4:	lea    0x1(%r14),%rdi
  7603c8:	mov    $0x1,%ecx
  7603cd:	nopl   (%rax)
  7603d0:	cmp    (%rsi),%edx
  7603d2:	jne    7603e4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x184>
  7603d4:	inc    %rcx
  7603d7:	add    $0xc,%rsi
  7603db:	dec    %rdi
  7603de:	cmp    $0x2,%rdi
  7603e2:	ja     7603d0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x170>
  7603e4:	sub    %rcx,%r14
  7603e7:	jb     7605b7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x357>
  7603ed:	lea    (%rcx,%rcx,2),%rdx
  7603f1:	lea    (%r15,%rdx,4),%rdx
  7603f5:	mov    %rdx,0x20(%rsp)
  7603fa:	mov    %r14,0x28(%rsp)
  7603ff:	test   %r15,%r15
  760402:	je     7605a2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x342>
  760408:	lea    (%rax,%rax,2),%rsi
  76040c:	mov    %r12,0x60(%rsp)
  760411:	mov    %rax,0x68(%rsp)
  760416:	mov    %r15,0x70(%rsp)
  76041b:	mov    %rcx,0x78(%rsp)
  760420:	mov    %rdx,%r15
  760423:	mov    $0x0,%r13d
  760429:	test   %r12,%r12
  76042c:	lea    (%r12,%rsi,4),%r12
  760430:	jne    760320 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0xc0>
  760436:	jmp    7605a2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x342>
  76043b:	movq   $0x0,0x30(%rsp)
  760444:	mov    %r15,%rsi
  760447:	mov    %r14,%rdx
  76044a:	mov    %r14,%rdi
  76044d:	cmp    $0x1,%r14
  760451:	je     760485 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x225>
  760453:	test   %rdx,%rdx
  760456:	je     7605a2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x342>
  76045c:	mov    (%rsi),%ecx
  76045e:	lea    0xc(%rsi),%r8
  760462:	lea    0x1(%rdx),%r9
  760466:	mov    $0x1,%edi
  76046b:	nopl   0x0(%rax,%rax,1)
  760470:	cmp    (%r8),%ecx
  760473:	jne    760485 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x225>
  760475:	inc    %rdi
  760478:	add    $0xc,%r8
  76047c:	dec    %r9
  76047f:	cmp    $0x2,%r9
  760483:	ja     760470 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x210>
  760485:	mov    %rdx,%r14
  760488:	sub    %rdi,%r14
  76048b:	jb     7605b7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x357>
  760491:	lea    (%rdi,%rdi,2),%r9
  760495:	lea    (%rsi,%r9,4),%r15
  760499:	dec    %r13
  76049c:	jne    760444 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x1e4>
  76049e:	mov    %r15,0x20(%rsp)
  7604a3:	mov    %r14,0x28(%rsp)
  7604a8:	mov    %r14,%rcx
  7604ab:	cmp    $0x1,%r14
  7604af:	je     7604e5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x285>
  7604b1:	test   %r14,%r14
  7604b4:	je     7605a2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x342>
  7604ba:	mov    (%r15),%r8d
  7604bd:	lea    (%rsi,%r9,4),%rsi
  7604c1:	add    $0xc,%rsi
  7604c5:	sub    %rdi,%rdx
  7604c8:	inc    %rdx
  7604cb:	mov    $0x1,%ecx
  7604d0:	cmp    (%rsi),%r8d
  7604d3:	jne    7604e5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x285>
  7604d5:	inc    %rcx
  7604d8:	add    $0xc,%rsi
  7604dc:	dec    %rdx
  7604df:	cmp    $0x2,%rdx
  7604e3:	ja     7604d0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x270>
  7604e5:	sub    %rcx,%r14
  7604e8:	jb     7605b7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x357>
  7604ee:	lea    (%rcx,%rcx,2),%rdx
  7604f2:	lea    (%r15,%rdx,4),%rdx
  7604f6:	mov    %rdx,0x20(%rsp)
  7604fb:	mov    %r14,0x28(%rsp)
  760500:	jmp    760408 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x1a8>
  760505:	data16 cs nopw 0x0(%rax,%rax,1)
  760510:	mov    %r12,0x10(%rsp)
  760515:	mov    0x88(%rsp),%eax
  76051c:	mov    0x90(%rsp),%ecx
  760523:	mov    0x98(%rsp),%edx
  76052a:	mov    0x9c(%rsp),%esi
  760531:	mov    0xa0(%rsp),%edi
  760538:	mov    0xa4(%rsp),%r8d
  760540:	xor    %rax,%rbx
  760543:	movabs $0x100000001b3,%rax
  76054d:	imul   %rax,%rbx
  760551:	xor    %rcx,%rbx
  760554:	imul   %rax,%rbx
  760558:	xor    0xa8(%rsp),%rbx
  760560:	imul   %rax,%rbx
  760564:	xor    %rdx,%rbx
  760567:	imul   %rax,%rbx
  76056b:	xor    %rsi,%rbx
  76056e:	imul   %rax,%rbx
  760572:	xor    %rdi,%rbx
  760575:	imul   %rax,%rbx
  760579:	xor    %r8,%rbx
  76057c:	imul   %rax,%rbx
  760580:	lea    0x60(%rsp),%rdi
  760585:	lea    0x10(%rsp),%rsi
  76058a:	call   798540 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control>
  76058f:	cmpq   $0x0,0x60(%rsp)
  760595:	jne    7602e3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x83>
  76059b:	jmp    7605a2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x342>
  76059d:	mov    $0x1,%ebx
  7605a2:	mov    %rbx,%rax
  7605a5:	add    $0x108,%rsp
  7605ac:	pop    %rbx
  7605ad:	pop    %r12
  7605af:	pop    %r13
  7605b1:	pop    %r14
  7605b3:	pop    %r15
  7605b5:	pop    %rbp
  7605b6:	ret
  7605b7:	lea    -0x690965(%rip),%rdi        # cfc59 <GCC_except_table0+0xd88d>
  7605be:	lea    0x33b6fb(%rip),%rdx        # a9bcc0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2378>
  7605c5:	mov    $0x13,%esi
  7605ca:	call   *0x359b18(%rip)        # aba0e8 <_DYNAMIC+0x278>

canonical_text_public_control::query_selection bytes=1484 frame=312

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007605d0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection>:
  7605d0:	push   %rbp
  7605d1:	push   %r15
  7605d3:	push   %r14
  7605d5:	push   %r13
  7605d7:	push   %r12
  7605d9:	push   %rbx
  7605da:	sub    $0x108,%rsp
  7605e1:	mov    %rsi,%rbx
  7605e4:	mov    %rdi,%r14
  7605e7:	call   *0x359b43(%rip)        # aba130 <_DYNAMIC+0x2c0>
  7605ed:	test   %al,%al
  7605ef:	je     760b83 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x5b3>
  7605f5:	mov    (%rbx),%esi
  7605f7:	mov    0x8(%rbx),%eax
  7605fa:	mov    $0x1,%ebx
  7605ff:	cmp    %esi,%eax
  760601:	je     760b55 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x585>
  760607:	mov    %esi,%edx
  760609:	cmova  %eax,%edx
  76060c:	cmovb  %eax,%esi
  76060f:	mov    %r14,%rdi
  760612:	call   *0x359b20(%rip)        # aba138 <_DYNAMIC+0x2c8>
  760618:	mov    %rdx,%rcx
  76061b:	movss  0x4c(%r14),%xmm0
  760621:	mulss  -0x69e151(%rip),%xmm0        # c24d8 <GCC_except_table0+0x10c>
  760629:	lea    0x88(%rsp),%r15
  760631:	mov    %r15,%rdi
  760634:	mov    %r14,%rsi
  760637:	mov    %rax,%rdx
  76063a:	call   *0x359b00(%rip)        # aba140 <_DYNAMIC+0x2d0>
  760640:	lea    0x68(%rsp),%rdi
  760645:	mov    %r15,%rsi
  760648:	call   798540 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control>
  76064d:	cmpq   $0x0,0x68(%rsp)
  760653:	je     760b55 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x585>
  760659:	mov    $0x1,%ebx
  76065e:	movq   $0x0,0x48(%rsp)
  760667:	mov    $0x1,%eax
  76066c:	mov    %rax,0x40(%rsp)
  760671:	movss  %xmm3,0x10(%rsp)
  760677:	movss  %xmm0,0xc(%rsp)
  76067d:	movaps %xmm2,%xmm0
  760680:	movaps %xmm1,0x30(%rsp)
  760685:	mov    %rbx,0x18(%rsp)
  76068a:	mov    0xc0(%rsp),%r13
  760692:	movss  0xc8(%rsp),%xmm1
  76069b:	movss  %xmm1,0x14(%rsp)
  7606a1:	mov    0x88(%rsp),%rbp
  7606a9:	mov    0x90(%rsp),%r12
  7606b1:	mov    0xa8(%rsp),%rbx
  7606b9:	mov    0xa0(%rsp),%r14
  7606c1:	mov    0x98(%rsp),%r15
  7606c9:	movaps %xmm0,0x50(%rsp)
  7606ce:	xchg   %ax,%ax
  7606d0:	lea    0xd0(%rsp),%rdi
  7606d8:	mov    %r13,%rsi
  7606db:	movss  0x14(%rsp),%xmm0
  7606e1:	lea    0x68(%rsp),%rdx
  7606e6:	call   75d540 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control>
  7606eb:	cmpb   $0x2,0xd4(%rsp)
  7606f3:	jne    7608d1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x301>
  7606f9:	mov    %r12,%rax
  7606fc:	cmp    $0x1,%r12
  760700:	movaps 0x50(%rsp),%xmm0
  760705:	je     760744 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x174>
  760707:	test   %r12,%r12
  76070a:	je     760af4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x524>
  760710:	mov    0x0(%rbp),%ecx
  760713:	lea    0xc(%rbp),%rdx
  760717:	lea    0x1(%r12),%rsi
  76071c:	mov    $0x1,%eax
  760721:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  760730:	cmp    (%rdx),%ecx
  760732:	jne    760744 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x174>
  760734:	inc    %rax
  760737:	add    $0xc,%rdx
  76073b:	dec    %rsi
  76073e:	cmp    $0x2,%rsi
  760742:	ja     760730 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x160>
  760744:	sub    %rax,%r12
  760747:	jb     760b6a <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x59a>
  76074d:	mov    %r12,0x90(%rsp)
  760755:	test   %rbx,%rbx
  760758:	jne    7607f4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x224>
  76075e:	mov    %r14,%rcx
  760761:	cmp    $0x1,%r14
  760765:	je     760794 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x1c4>
  760767:	test   %r14,%r14
  76076a:	je     760af4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x524>
  760770:	mov    (%r15),%edx
  760773:	lea    0xc(%r15),%rsi
  760777:	lea    0x1(%r14),%rdi
  76077b:	mov    $0x1,%ecx
  760780:	cmp    (%rsi),%edx
  760782:	jne    760794 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x1c4>
  760784:	inc    %rcx
  760787:	add    $0xc,%rsi
  76078b:	dec    %rdi
  76078e:	cmp    $0x2,%rdi
  760792:	ja     760780 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x1b0>
  760794:	sub    %rcx,%r14
  760797:	jb     760b6a <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x59a>
  76079d:	lea    (%rcx,%rcx,2),%rdx
  7607a1:	lea    (%r15,%rdx,4),%rdx
  7607a5:	mov    %rdx,0x98(%rsp)
  7607ad:	mov    %r14,0xa0(%rsp)
  7607b5:	test   %r15,%r15
  7607b8:	je     760af4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x524>
  7607be:	lea    (%rax,%rax,2),%rsi
  7607c2:	mov    %rbp,0x68(%rsp)
  7607c7:	mov    %rax,0x70(%rsp)
  7607cc:	mov    %r15,0x78(%rsp)
  7607d1:	mov    %rcx,0x80(%rsp)
  7607d9:	mov    %rdx,%r15
  7607dc:	mov    $0x0,%ebx
  7607e1:	test   %rbp,%rbp
  7607e4:	lea    0x0(%rbp,%rsi,4),%rbp
  7607e9:	jne    7606d0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x100>
  7607ef:	jmp    760af4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x524>
  7607f4:	movq   $0x0,0xa8(%rsp)
  760800:	mov    %r15,%rsi
  760803:	mov    %r14,%rdx
  760806:	mov    %r14,%rdi
  760809:	cmp    $0x1,%r14
  76080d:	je     760845 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x275>
  76080f:	test   %rdx,%rdx
  760812:	je     760af4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x524>
  760818:	mov    (%rsi),%ecx
  76081a:	lea    0xc(%rsi),%r8
  76081e:	lea    0x1(%rdx),%r9
  760822:	mov    $0x1,%edi
  760827:	nopw   0x0(%rax,%rax,1)
  760830:	cmp    (%r8),%ecx
  760833:	jne    760845 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x275>
  760835:	inc    %rdi
  760838:	add    $0xc,%r8
  76083c:	dec    %r9
  76083f:	cmp    $0x2,%r9
  760843:	ja     760830 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x260>
  760845:	mov    %rdx,%r14
  760848:	sub    %rdi,%r14
  76084b:	jb     760b6a <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x59a>
  760851:	lea    (%rdi,%rdi,2),%r9
  760855:	lea    (%rsi,%r9,4),%r15
  760859:	dec    %rbx
  76085c:	jne    760800 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x230>
  76085e:	mov    %r15,0x98(%rsp)
  760866:	mov    %r14,0xa0(%rsp)
  76086e:	mov    %r14,%rcx
  760871:	cmp    $0x1,%r14
  760875:	je     7608ab <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x2db>
  760877:	test   %r14,%r14
  76087a:	je     760af4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x524>
  760880:	mov    (%r15),%r8d
  760883:	lea    (%rsi,%r9,4),%rsi
  760887:	add    $0xc,%rsi
  76088b:	sub    %rdi,%rdx
  76088e:	inc    %rdx
  760891:	mov    $0x1,%ecx
  760896:	cmp    (%rsi),%r8d
  760899:	jne    7608ab <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x2db>
  76089b:	inc    %rcx
  76089e:	add    $0xc,%rsi
  7608a2:	dec    %rdx
  7608a5:	cmp    $0x2,%rdx
  7608a9:	ja     760896 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x2c6>
  7608ab:	sub    %rcx,%r14
  7608ae:	jb     760b6a <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x59a>
  7608b4:	lea    (%rcx,%rcx,2),%rdx
  7608b8:	lea    (%r15,%rdx,4),%rdx
  7608bc:	mov    %rdx,0x98(%rsp)
  7608c4:	mov    %r14,0xa0(%rsp)
  7608cc:	jmp    7607be <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x1ee>
  7608d1:	mov    %rbp,0x88(%rsp)
  7608d9:	movss  0xe8(%rsp),%xmm2
  7608e2:	xorps  %xmm0,%xmm0
  7608e5:	ucomiss %xmm0,%xmm2
  7608e8:	jne    7608f6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x326>
  7608ea:	jp     7608f6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x326>
  7608ec:	mov    0x18(%rsp),%rbx
  7608f1:	jmp    7609d6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x406>
  7608f6:	movss  0xe0(%rsp),%xmm5
  7608ff:	movss  0xe4(%rsp),%xmm6
  760908:	movss  0xec(%rsp),%xmm3
  760911:	mov    0xf0(%rsp),%rax
  760919:	testb  $0x1,0x48(%rsp)
  76091e:	mov    0x18(%rsp),%rbx
  760923:	movaps 0x30(%rsp),%xmm0
  760928:	je     7609fe <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x42e>
  76092e:	cmp    %rax,0x20(%rsp)
  760933:	jne    760a31 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x461>
  760939:	movss  0x10(%rsp),%xmm0
  76093f:	ucomiss %xmm6,%xmm0
  760942:	jne    760a2c <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x45c>
  760948:	jp     760a2c <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x45c>
  76094e:	movss  0xc(%rsp),%xmm0
  760954:	ucomiss %xmm3,%xmm0
  760957:	movaps 0x30(%rsp),%xmm0
  76095c:	jne    760a31 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x461>
  760962:	jp     760a31 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x461>
  760968:	movaps %xmm5,%xmm1
  76096b:	addss  %xmm2,%xmm1
  76096f:	ucomiss %xmm0,%xmm1
  760972:	jb     760a20 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x450>
  760978:	movaps %xmm0,%xmm4
  76097b:	movaps 0x50(%rsp),%xmm0
  760980:	addss  %xmm4,%xmm0
  760984:	ucomiss %xmm5,%xmm0
  760987:	mov    0x20(%rsp),%rax
  76098c:	jb     760a27 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x457>
  760992:	movaps %xmm0,%xmm2
  760995:	maxss  %xmm1,%xmm2
  760999:	movaps %xmm2,%xmm3
  76099c:	cmpunordss %xmm2,%xmm3
  7609a1:	movaps %xmm3,%xmm1
  7609a4:	andnps %xmm2,%xmm1
  7609a7:	andps  %xmm0,%xmm3
  7609aa:	orps   %xmm1,%xmm3
  7609ad:	movaps %xmm4,%xmm0
  7609b0:	minss  %xmm5,%xmm0
  7609b4:	movaps %xmm0,%xmm1
  7609b7:	cmpunordss %xmm0,%xmm1
  7609bc:	movaps %xmm1,%xmm2
  7609bf:	andnps %xmm0,%xmm2
  7609c2:	andps  %xmm4,%xmm1
  7609c5:	orps   %xmm2,%xmm1
  7609c8:	subss  %xmm1,%xmm3
  7609cc:	movaps %xmm3,0x50(%rsp)
  7609d1:	movaps %xmm1,0x30(%rsp)
  7609d6:	lea    0x68(%rsp),%rdi
  7609db:	lea    0x88(%rsp),%rsi
  7609e3:	call   798540 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control>
  7609e8:	cmpq   $0x0,0x68(%rsp)
  7609ee:	movaps 0x50(%rsp),%xmm0
  7609f3:	jne    76068a <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0xba>
  7609f9:	jmp    760af9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x529>
  7609fe:	movss  %xmm6,0x28(%rsp)
  760a04:	movss  %xmm3,0x2c(%rsp)
  760a0a:	movss  %xmm2,0x30(%rsp)
  760a10:	movss  %xmm5,0x14(%rsp)
  760a16:	mov    %rax,0x20(%rsp)
  760a1b:	jmp    760aa9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x4d9>
  760a20:	mov    0x20(%rsp),%rax
  760a25:	jmp    760a31 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x461>
  760a27:	movaps %xmm4,%xmm0
  760a2a:	jmp    760a31 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x461>
  760a2c:	movaps 0x30(%rsp),%xmm0
  760a31:	movss  %xmm6,0x28(%rsp)
  760a37:	movss  %xmm3,0x2c(%rsp)
  760a3d:	movss  %xmm2,0x30(%rsp)
  760a43:	movss  %xmm5,0x14(%rsp)
  760a49:	movd   %xmm0,%ecx
  760a4d:	movd   0x10(%rsp),%xmm0
  760a53:	movd   %xmm0,%edx
  760a57:	movdqa 0x50(%rsp),%xmm0
  760a5d:	movd   %xmm0,%esi
  760a61:	movd   0xc(%rsp),%xmm0
  760a67:	movd   %xmm0,%ebx
  760a6b:	mov    0x40(%rsp),%rdi
  760a70:	xor    %rcx,%rdi
  760a73:	movabs $0x100000001b3,%rcx
  760a7d:	imul   %rcx,%rdi
  760a81:	xor    %rdi,%rdx
  760a84:	imul   %rcx,%rdx
  760a88:	xor    %rdx,%rsi
  760a8b:	imul   %rcx,%rsi
  760a8f:	xor    %rsi,%rbx
  760a92:	imul   %rcx,%rbx
  760a96:	xor    0x20(%rsp),%rbx
  760a9b:	imul   %rcx,%rbx
  760a9f:	mov    %rax,0x20(%rsp)
  760aa4:	mov    %rbx,0x40(%rsp)
  760aa9:	lea    0x68(%rsp),%rdi
  760aae:	lea    0x88(%rsp),%rsi
  760ab6:	call   798540 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control>
  760abb:	mov    $0x1,%al
  760abd:	mov    %rax,0x48(%rsp)
  760ac2:	cmpq   $0x0,0x68(%rsp)
  760ac8:	movss  0x14(%rsp),%xmm1
  760ace:	movss  0x30(%rsp),%xmm2
  760ad4:	movss  0x2c(%rsp),%xmm0
  760ada:	movss  0x28(%rsp),%xmm3
  760ae0:	jne    760671 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0xa1>
  760ae6:	movss  %xmm0,0xc(%rsp)
  760aec:	movss  %xmm3,0x10(%rsp)
  760af2:	jmp    760b08 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x538>
  760af4:	mov    0x18(%rsp),%rbx
  760af9:	movaps %xmm0,%xmm2
  760afc:	movaps 0x30(%rsp),%xmm1
  760b01:	testb  $0x1,0x48(%rsp)
  760b06:	je     760b55 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x585>
  760b08:	movd   %xmm1,%eax
  760b0c:	movd   0x10(%rsp),%xmm0
  760b12:	movd   %xmm0,%ecx
  760b16:	movd   %xmm2,%edx
  760b1a:	movd   0xc(%rsp),%xmm0
  760b20:	movd   %xmm0,%ebx
  760b24:	xor    0x40(%rsp),%rax
  760b29:	movabs $0x100000001b3,%rsi
  760b33:	imul   %rsi,%rax
  760b37:	xor    %rax,%rcx
  760b3a:	imul   %rsi,%rcx
  760b3e:	xor    %rcx,%rdx
  760b41:	imul   %rsi,%rdx
  760b45:	xor    %rdx,%rbx
  760b48:	imul   %rsi,%rbx
  760b4c:	xor    0x20(%rsp),%rbx
  760b51:	imul   %rsi,%rbx
  760b55:	mov    %rbx,%rax
  760b58:	add    $0x108,%rsp
  760b5f:	pop    %rbx
  760b60:	pop    %r12
  760b62:	pop    %r13
  760b64:	pop    %r14
  760b66:	pop    %r15
  760b68:	pop    %rbp
  760b69:	ret
  760b6a:	lea    -0x690f18(%rip),%rdi        # cfc59 <GCC_except_table0+0xd88d>
  760b71:	lea    0x33b148(%rip),%rdx        # a9bcc0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2378>
  760b78:	mov    $0x13,%esi
  760b7d:	call   *0x359565(%rip)        # aba0e8 <_DYNAMIC+0x278>
  760b83:	lea    -0x6910f6(%rip),%rdi        # cfa94 <GCC_except_table0+0xd6c8>
  760b8a:	lea    0x339c5f(%rip),%rdx        # a9a7f0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xea8>
  760b91:	mov    $0x73,%esi
  760b96:	call   *0x35958c(%rip)        # aba128 <_DYNAMIC+0x2b8>

canonical_text_public_control::ack bytes=358 frame=136

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000760ba0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack>:
  760ba0:	push   %r14
  760ba2:	push   %rbx
  760ba3:	sub    $0x78,%rsp
  760ba7:	test   %rsi,%rsi
  760baa:	je     760c54 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack+0xb4>
  760bb0:	cmpb   $0x0,0x76e(%rsi)
  760bb7:	jne    760c5b <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack+0xbb>
  760bbd:	mov    0x6d0(%rsi),%rdx
  760bc4:	test   %rdx,%rdx
  760bc7:	je     760c62 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack+0xc2>
  760bcd:	mov    %rdi,%rbx
  760bd0:	mov    0x6d8(%rsi),%rcx
  760bd7:	lea    0x8(%rsp),%rdi
  760bdc:	call   77ba20 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_>
  760be1:	cmpq   $0xfffffffffffffffe,0x8(%rsp)
  760be7:	jne    760c9f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack+0xff>
  760bed:	movups 0x10(%rsp),%xmm0
  760bf2:	movups 0x20(%rsp),%xmm1
  760bf7:	movups 0x30(%rsp),%xmm2
  760bfc:	movups %xmm2,0x20(%rbx)
  760c00:	movups %xmm1,0x10(%rbx)
  760c04:	movups %xmm0,(%rbx)
  760c07:	cmpb   $0x0,0x28(%rbx)
  760c0b:	je     760c1f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack+0x7f>
  760c0d:	mov    0x10(%rbx),%rax
  760c11:	cmp    0x18(%rbx),%rax
  760c15:	jne    760c38 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack+0x98>
  760c17:	add    $0x78,%rsp
  760c1b:	pop    %rbx
  760c1c:	pop    %r14
  760c1e:	ret
  760c1f:	lea    -0x69111f(%rip),%rdi        # cfb07 <GCC_except_table0+0xd73b>
  760c26:	lea    0x339c0b(%rip),%rdx        # a9a838 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xef0>
  760c2d:	mov    $0x2b,%esi
  760c32:	call   *0x3594f0(%rip)        # aba128 <_DYNAMIC+0x2b8>
  760c38:	lea    0x10(%rbx),%rsi
  760c3c:	add    $0x18,%rbx
  760c40:	lea    0x339c09(%rip),%r9        # a9a850 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xf08>
  760c47:	xor    %edi,%edi
  760c49:	mov    %rbx,%rdx
  760c4c:	xor    %ecx,%ecx
  760c4e:	call   *0x3596dc(%rip)        # aba330 <_DYNAMIC+0x4c0>
  760c54:	mov    $0xd,%eax
  760c59:	jmp    760c67 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack+0xc7>
  760c5b:	mov    $0xe,%eax
  760c60:	jmp    760c67 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack+0xc7>
  760c62:	mov    $0x14,%eax
  760c67:	mov    %rax,0x40(%rsp)
  760c6c:	movq   $0x0,0x48(%rsp)
  760c75:	lea    -0x69101a(%rip),%rdi        # cfc62 <GCC_except_table0+0xd896>
  760c7c:	lea    0x339edd(%rip),%rcx        # a9ab60 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1218>
  760c83:	lea    0x339b7e(%rip),%r8        # a9a808 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xec0>
  760c8a:	lea    0x40(%rsp),%rbx
  760c8f:	mov    $0x2b,%esi
  760c94:	mov    %rbx,%rdx
  760c97:	call   *0x3594e3(%rip)        # aba180 <_DYNAMIC+0x310>
  760c9d:	jmp    760cef <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack+0x14f>
  760c9f:	mov    0x38(%rsp),%rax
  760ca4:	mov    %rax,0x70(%rsp)
  760ca9:	movups 0x8(%rsp),%xmm0
  760cae:	movups 0x18(%rsp),%xmm1
  760cb3:	movups 0x28(%rsp),%xmm2
  760cb8:	movaps %xmm2,0x60(%rsp)
  760cbd:	movaps %xmm1,0x50(%rsp)
  760cc2:	movaps %xmm0,0x40(%rsp)
  760cc7:	lea    -0x69106c(%rip),%rdi        # cfc62 <GCC_except_table0+0xd896>
  760cce:	lea    0x339e8b(%rip),%rcx        # a9ab60 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1218>
  760cd5:	lea    0x339b44(%rip),%r8        # a9a820 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xed8>
  760cdc:	lea    0x40(%rsp),%rbx
  760ce1:	mov    $0x2b,%esi
  760ce6:	mov    %rbx,%rdx
  760ce9:	call   *0x359491(%rip)        # aba180 <_DYNAMIC+0x310>
  760cef:	ud2
  760cf1:	jmp    760cf3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack+0x153>
  760cf3:	mov    %rax,%r14
  760cf6:	mov    %rbx,%rdi
  760cf9:	call   74d7d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  760cfe:	mov    %r14,%rdi
  760d01:	call   a98590 <_Unwind_Resume@plt>

canonical_text_public_control::run bytes=10177 frame=904

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000760d10 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run>:
  760d10:	push   %rbp
  760d11:	push   %r15
  760d13:	push   %r14
  760d15:	push   %r13
  760d17:	push   %r12
  760d19:	push   %rbx
  760d1a:	sub    $0x358,%rsp
  760d21:	mov    %rdi,0x2d8(%rsp)
  760d29:	mov    %rsi,0x2f0(%rsp)
  760d31:	mov    %rdx,0x2f8(%rsp)
  760d39:	mov    %rcx,0x2b8(%rsp)
  760d41:	mov    %r8,0x2c0(%rsp)
  760d49:	mov    %r9,0x148(%rsp)
  760d51:	test   %r9,%r9
  760d54:	je     762c82 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1f72>
  760d5a:	lea    0x288(%rsp),%rbx
  760d62:	mov    %rbx,%rdi
  760d65:	mov    %rsi,0x2c8(%rsp)
  760d6d:	mov    %rdx,0x140(%rsp)
  760d75:	call   766310 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source>
  760d7a:	lea    0x150(%rsp),%rdi
  760d82:	mov    %rbx,%rsi
  760d85:	call   *0x3595ad(%rip)        # aba338 <_DYNAMIC+0x4c8>
  760d8b:	cmpq   $0x0,0x298(%rsp)
  760d94:	je     760e2f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x11f>
  760d9a:	mov    0x290(%rsp),%rcx
  760da2:	movzbl (%rcx),%edi
  760da5:	mov    $0x1,%esi
  760daa:	test   %dil,%dil
  760dad:	js     7614a1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x791>
  760db3:	mov    0x160(%rsp),%rdx
  760dbb:	mov    %rdx,%rax
  760dbe:	sub    %rsi,%rax
  760dc1:	jb     762d3c <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x202c>
  760dc7:	mov    0x158(%rsp),%rcx
  760dcf:	jbe    760ddb <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xcb>
  760dd1:	cmpb   $0xc0,(%rcx,%rsi,1)
  760dd5:	jl     762d75 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2065>
  760ddb:	movq   $0x0,0x160(%rsp)
  760de7:	mov    %rcx,0x20(%rsp)
  760dec:	add    %rsi,%rcx
  760def:	mov    %rcx,0x28(%rsp)
  760df4:	lea    0x150(%rsp),%rcx
  760dfc:	mov    %rcx,0x30(%rsp)
  760e01:	mov    %rsi,0x38(%rsp)
  760e06:	mov    %rax,0x40(%rsp)
  760e0b:	lea    -0x6912c5(%rip),%rax        # cfb4d <GCC_except_table0+0xd781>
  760e12:	mov    %rax,0x48(%rsp)
  760e17:	lea    -0x6912d0(%rip),%rax        # cfb4e <GCC_except_table0+0xd782>
  760e1e:	mov    %rax,0x50(%rsp)
  760e23:	lea    0x20(%rsp),%rdi
  760e28:	call   7490c0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtCscdodAO9FK5_5alloc3vec6splice6SpliceNtNtNtB4_3str4iter5BytesEECs9C2G9YFESsD_29canonical_text_public_control>
  760e2d:	jmp    760e5c <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x14c>
  760e2f:	mov    0x160(%rsp),%rbx
  760e37:	cmp    %rbx,0x150(%rsp)
  760e3f:	je     762d50 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2040>
  760e45:	mov    0x158(%rsp),%rax
  760e4d:	movb   $0x62,(%rax,%rbx,1)
  760e51:	inc    %rbx
  760e54:	mov    %rbx,0x160(%rsp)
  760e5c:	lea    0x2a0(%rsp),%rdi
  760e64:	lea    0x288(%rsp),%rsi
  760e6c:	call   *0x3594c6(%rip)        # aba338 <_DYNAMIC+0x4c8>
  760e72:	mov    $0x1,%bpl
  760e75:	lea    0x20(%rsp),%rdi
  760e7a:	call   *0x3594c0(%rip)        # aba340 <_DYNAMIC+0x4d0>
  760e80:	cmpl   $0x1,0x20(%rsp)
  760e85:	je     762c9b <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1f8b>
  760e8b:	mov    0x28(%rsp),%rax
  760e90:	mov    %rax,0x168(%rsp)
  760e98:	lea    0x168(%rsp),%rax
  760ea0:	mov    %rax,0xb0(%rsp)
  760ea8:	movq   $0x0,0xb8(%rsp)
  760eb4:	mov    0x290(%rsp),%rdx
  760ebc:	mov    0x298(%rsp),%rcx
  760ec4:	lea    0x20(%rsp),%rdi
  760ec9:	lea    0xb0(%rsp),%rsi
  760ed1:	movss  -0x69e9fd(%rip),%xmm0        # c24dc <GCC_except_table0+0x110>
  760ed9:	movss  -0x69ea25(%rip),%xmm1        # c24bc <GCC_except_table0+0xf0>
  760ee1:	mov    $0x1,%r8d
  760ee7:	call   *0x35945b(%rip)        # aba348 <_DYNAMIC+0x4d8>
  760eed:	cmpq   $0xffffffffffffffff,0x20(%rsp)
  760ef3:	je     762cd5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1fc5>
  760ef9:	mov    0x50(%rsp),%rax
  760efe:	mov    %rax,0x350(%rsp)
  760f06:	movups 0x20(%rsp),%xmm0
  760f0b:	movups 0x30(%rsp),%xmm1
  760f10:	movups 0x40(%rsp),%xmm2
  760f15:	movaps %xmm2,0x340(%rsp)
  760f1d:	movaps %xmm1,0x330(%rsp)
  760f25:	movaps %xmm0,0x320(%rsp)
  760f2d:	mov    0xb8(%rsp),%rdi
  760f35:	call   74cd40 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text10TextShaperECs9C2G9YFESsD_29canonical_text_public_control>
  760f3a:	mov    0x340(%rsp),%rsi
  760f42:	test   %rsi,%rsi
  760f45:	je     762d0f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1fff>
  760f4b:	add    $0x10,%rsi
  760f4f:	lea    0xb0(%rsp),%rdi
  760f57:	mov    %rsi,0x138(%rsp)
  760f5f:	call   *0x3593c3(%rip)        # aba328 <_DYNAMIC+0x4b8>
  760f65:	mov    0xe8(%rsp),%rbx
  760f6d:	movss  0xf0(%rsp),%xmm0
  760f76:	movss  %xmm0,0x10(%rsp)
  760f7c:	lea    0x190(%rsp),%rdi
  760f84:	lea    0xb0(%rsp),%rsi
  760f8c:	call   798540 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control>
  760f91:	cmpq   $0x0,0x190(%rsp)
  760f9a:	je     760ff5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2e5>
  760f9c:	lea    0x20(%rsp),%r14
  760fa1:	lea    0x190(%rsp),%r15
  760fa9:	lea    0xb0(%rsp),%r12
  760fb1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  760fc0:	mov    %r14,%rdi
  760fc3:	mov    %rbx,%rsi
  760fc6:	movss  0x10(%rsp),%xmm0
  760fcc:	mov    %r15,%rdx
  760fcf:	call   75d540 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control>
  760fd4:	movzbl 0x24(%rsp),%ebp
  760fd9:	cmp    $0x2,%bpl
  760fdd:	jne    761029 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x319>
  760fdf:	mov    %r15,%rdi
  760fe2:	mov    %r12,%rsi
  760fe5:	call   798540 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control>
  760fea:	cmpq   $0x0,0x190(%rsp)
  760ff3:	jne    760fc0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2b0>
  760ff5:	mov    $0x4,%eax
  760ffa:	mov    %rax,0x118(%rsp)
  761002:	mov    $0x8,%eax
  761007:	mov    %rax,0x128(%rsp)
  76100f:	movq   $0x0,0x1d0(%rsp)
  76101b:	movq   $0x0,0x18(%rsp)
  761024:	jmp    761621 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x911>
  761029:	mov    0x20(%rsp),%ebx
  76102d:	mov    0x54(%rsp),%eax
  761031:	mov    %eax,0x22f(%rsp)
  761038:	movups 0x45(%rsp),%xmm0
  76103d:	movaps %xmm0,0x220(%rsp)
  761045:	movups 0x35(%rsp),%xmm0
  76104a:	movaps %xmm0,0x210(%rsp)
  761052:	movups 0x25(%rsp),%xmm0
  761057:	movaps %xmm0,0x200(%rsp)
  76105f:	call   *0x359053(%rip)        # aba0b8 <_DYNAMIC+0x248>
  761065:	mov    $0xe0,%edi
  76106a:	mov    $0x8,%esi
  76106f:	call   *0x35904b(%rip)        # aba0c0 <_DYNAMIC+0x250>
  761075:	test   %rax,%rax
  761078:	je     7630be <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x23ae>
  76107e:	mov    %rax,%r14
  761081:	mov    0x22f(%rsp),%eax
  761088:	mov    %eax,0x34(%r14)
  76108c:	movaps 0x200(%rsp),%xmm0
  761094:	movaps 0x210(%rsp),%xmm1
  76109c:	movaps 0x220(%rsp),%xmm2
  7610a4:	movups %xmm2,0x25(%r14)
  7610a9:	movups %xmm1,0x15(%r14)
  7610ae:	movups %xmm0,0x5(%r14)
  7610b3:	mov    %ebx,(%r14)
  7610b6:	mov    %bpl,0x4(%r14)
  7610ba:	movq   $0x4,0x170(%rsp)
  7610c6:	mov    %r14,0x178(%rsp)
  7610ce:	movq   $0x1,0x180(%rsp)
  7610da:	mov    0xf0(%rsp),%rax
  7610e2:	mov    %rax,0x60(%rsp)
  7610e7:	movups 0xb0(%rsp),%xmm0
  7610ef:	movups 0xc0(%rsp),%xmm1
  7610f7:	movups 0xd0(%rsp),%xmm2
  7610ff:	movups 0xe0(%rsp),%xmm3
  761107:	movaps %xmm3,0x50(%rsp)
  76110c:	movaps %xmm2,0x40(%rsp)
  761111:	movaps %xmm1,0x30(%rsp)
  761116:	movaps %xmm0,0x20(%rsp)
  76111b:	mov    0x58(%rsp),%rax
  761120:	mov    %rax,0x10(%rsp)
  761125:	movss  0x60(%rsp),%xmm0
  76112b:	movss  %xmm0,0xa8(%rsp)
  761134:	lea    0x250(%rsp),%rdi
  76113c:	lea    0x20(%rsp),%rsi
  761141:	call   798540 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control>
  761146:	cmpq   $0x0,0x250(%rsp)
  76114f:	je     7614f5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x7e5>
  761155:	mov    $0x1,%eax
  76115a:	mov    %rax,0x18(%rsp)
  76115f:	mov    %r14,0x120(%rsp)
  761167:	mov    0x20(%rsp),%r12
  76116c:	mov    0x28(%rsp),%r13
  761171:	mov    0x40(%rsp),%rbp
  761176:	mov    0x38(%rsp),%r14
  76117b:	mov    0x30(%rsp),%r15
  761180:	mov    %rbp,0x110(%rsp)
  761188:	nopl   0x0(%rax,%rax,1)
  761190:	lea    0x200(%rsp),%rdi
  761198:	mov    0x10(%rsp),%rsi
  76119d:	movss  0xa8(%rsp),%xmm0
  7611a6:	lea    0x250(%rsp),%rdx
  7611ae:	call   75d540 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control>
  7611b3:	movzbl 0x204(%rsp),%ebx
  7611bb:	cmp    $0x2,%bl
  7611be:	jne    76137e <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x66e>
  7611c4:	mov    %r13,%rax
  7611c7:	cmp    $0x1,%r13
  7611cb:	je     761204 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x4f4>
  7611cd:	test   %r13,%r13
  7611d0:	je     7614ff <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x7ef>
  7611d6:	mov    (%r12),%ecx
  7611da:	lea    0xc(%r12),%rdx
  7611df:	lea    0x1(%r13),%rsi
  7611e3:	mov    $0x1,%eax
  7611e8:	nopl   0x0(%rax,%rax,1)
  7611f0:	cmp    (%rdx),%ecx
  7611f2:	jne    761204 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x4f4>
  7611f4:	inc    %rax
  7611f7:	add    $0xc,%rdx
  7611fb:	dec    %rsi
  7611fe:	cmp    $0x2,%rsi
  761202:	ja     7611f0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x4e0>
  761204:	sub    %rax,%r13
  761207:	jb     762c2f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1f1f>
  76120d:	test   %rbp,%rbp
  761210:	jne    7612b6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x5a6>
  761216:	mov    %r14,%rcx
  761219:	cmp    $0x1,%r14
  76121d:	je     761254 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x544>
  76121f:	test   %r14,%r14
  761222:	je     7614ff <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x7ef>
  761228:	mov    (%r15),%edx
  76122b:	lea    0xc(%r15),%rsi
  76122f:	lea    0x1(%r14),%rdi
  761233:	mov    $0x1,%ecx
  761238:	nopl   0x0(%rax,%rax,1)
  761240:	cmp    (%rsi),%edx
  761242:	jne    761254 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x544>
  761244:	inc    %rcx
  761247:	add    $0xc,%rsi
  76124b:	dec    %rdi
  76124e:	cmp    $0x2,%rdi
  761252:	ja     761240 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x530>
  761254:	sub    %rcx,%r14
  761257:	jb     762c2f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1f1f>
  76125d:	lea    (%rcx,%rcx,2),%rdx
  761261:	lea    (%r15,%rdx,4),%rdx
  761265:	mov    %rdx,0x30(%rsp)
  76126a:	mov    %r14,0x38(%rsp)
  76126f:	test   %r15,%r15
  761272:	je     7614ff <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x7ef>
  761278:	lea    (%rax,%rax,2),%rsi
  76127c:	mov    %r12,0x250(%rsp)
  761284:	mov    %rax,0x258(%rsp)
  76128c:	mov    %r15,0x260(%rsp)
  761294:	mov    %rcx,0x268(%rsp)
  76129c:	mov    %rdx,%r15
  76129f:	mov    $0x0,%ebp
  7612a4:	test   %r12,%r12
  7612a7:	lea    (%r12,%rsi,4),%r12
  7612ab:	jne    761190 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x480>
  7612b1:	jmp    7614ff <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x7ef>
  7612b6:	mov    %r14,%rdx
  7612b9:	mov    %r15,%rsi
  7612bc:	mov    %r14,%rdi
  7612bf:	cmp    $0x1,%r14
  7612c3:	je     7612f2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x5e2>
  7612c5:	test   %rdx,%rdx
  7612c8:	je     7614ff <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x7ef>
  7612ce:	mov    (%rsi),%ecx
  7612d0:	lea    0xc(%rsi),%r8
  7612d4:	lea    0x1(%rdx),%r9
  7612d8:	mov    $0x1,%edi
  7612dd:	cmp    (%r8),%ecx
  7612e0:	jne    7612f2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x5e2>
  7612e2:	inc    %rdi
  7612e5:	add    $0xc,%r8
  7612e9:	dec    %r9
  7612ec:	cmp    $0x2,%r9
  7612f0:	ja     7612dd <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x5cd>
  7612f2:	mov    %rdx,%r14
  7612f5:	sub    %rdi,%r14
  7612f8:	jb     762c2f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1f1f>
  7612fe:	lea    (%rdi,%rdi,2),%r9
  761302:	lea    (%rsi,%r9,4),%r15
  761306:	dec    %rbp
  761309:	jne    7612b6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x5a6>
  76130b:	mov    %r15,0x30(%rsp)
  761310:	mov    %r14,0x38(%rsp)
  761315:	mov    %r14,%rcx
  761318:	cmp    $0x1,%r14
  76131c:	je     761352 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x642>
  76131e:	test   %r14,%r14
  761321:	je     7614ff <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x7ef>
  761327:	mov    (%r15),%r8d
  76132a:	lea    (%rsi,%r9,4),%rsi
  76132e:	add    $0xc,%rsi
  761332:	sub    %rdi,%rdx
  761335:	inc    %rdx
  761338:	mov    $0x1,%ecx
  76133d:	cmp    (%rsi),%r8d
  761340:	jne    761352 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x642>
  761342:	inc    %rcx
  761345:	add    $0xc,%rsi
  761349:	dec    %rdx
  76134c:	cmp    $0x2,%rdx
  761350:	ja     76133d <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x62d>
  761352:	sub    %rcx,%r14
  761355:	jb     762c2f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1f1f>
  76135b:	lea    (%rcx,%rcx,2),%rdx
  76135f:	lea    (%r15,%rdx,4),%rdx
  761363:	mov    %rdx,0x30(%rsp)
  761368:	mov    %r14,0x38(%rsp)
  76136d:	movq   $0x0,0x110(%rsp)
  761379:	jmp    761278 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x568>
  76137e:	mov    %r12,0x20(%rsp)
  761383:	mov    %r13,0x28(%rsp)
  761388:	mov    0x110(%rsp),%rax
  761390:	mov    %rax,0x40(%rsp)
  761395:	mov    0x200(%rsp),%ebp
  76139c:	lea    0x205(%rsp),%rax
  7613a4:	movups (%rax),%xmm0
  7613a7:	movups 0x10(%rax),%xmm1
  7613ab:	movups 0x20(%rax),%xmm2
  7613af:	movaps %xmm0,0x190(%rsp)
  7613b7:	movaps %xmm1,0x1a0(%rsp)
  7613bf:	movaps %xmm2,0x1b0(%rsp)
  7613c7:	mov    0x2f(%rax),%eax
  7613ca:	mov    %eax,0x1bf(%rsp)
  7613d1:	mov    0x18(%rsp),%rsi
  7613d6:	cmp    0x170(%rsp),%rsi
  7613de:	mov    0x120(%rsp),%r14
  7613e6:	jne    761412 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x702>
  7613e8:	mov    $0x1,%edx
  7613ed:	mov    $0x8,%ecx
  7613f2:	mov    $0x38,%r8d
  7613f8:	lea    0x170(%rsp),%rdi
  761400:	call   75b3b0 <_RINvNvMs2_NtCscdodAO9FK5_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs9C2G9YFESsD_29canonical_text_public_control>
  761405:	mov    0x178(%rsp),%r14
  76140d:	mov    0x18(%rsp),%rsi
  761412:	imul   $0x38,%rsi,%rax
  761416:	mov    %ebp,(%r14,%rax,1)
  76141a:	mov    %bl,0x4(%r14,%rax,1)
  76141f:	movaps 0x190(%rsp),%xmm0
  761427:	movaps 0x1a0(%rsp),%xmm1
  76142f:	movaps 0x1b0(%rsp),%xmm2
  761437:	movups %xmm0,0x5(%r14,%rax,1)
  76143d:	movups %xmm1,0x15(%r14,%rax,1)
  761443:	movups %xmm2,0x25(%r14,%rax,1)
  761449:	mov    0x1bf(%rsp),%ecx
  761450:	mov    %ecx,0x34(%r14,%rax,1)
  761455:	inc    %rsi
  761458:	mov    %rsi,0x18(%rsp)
  76145d:	mov    %rsi,0x180(%rsp)
  761465:	mov    0x58(%rsp),%rax
  76146a:	mov    %rax,0x10(%rsp)
  76146f:	movss  0x60(%rsp),%xmm0
  761475:	movss  %xmm0,0xa8(%rsp)
  76147e:	lea    0x250(%rsp),%rdi
  761486:	lea    0x20(%rsp),%rsi
  76148b:	call   798540 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control>
  761490:	cmpq   $0x0,0x250(%rsp)
  761499:	jne    76115f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x44f>
  76149f:	jmp    7614ff <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x7ef>
  7614a1:	mov    %edi,%eax
  7614a3:	and    $0x1f,%eax
  7614a6:	movzbl 0x1(%rcx),%r8d
  7614ab:	and    $0x3f,%r8d
  7614af:	cmp    $0xe0,%dil
  7614b3:	jb     762a68 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1d58>
  7614b9:	movzbl 0x2(%rcx),%edx
  7614bd:	shl    $0x6,%r8d
  7614c1:	and    $0x3f,%edx
  7614c4:	or     %r8d,%edx
  7614c7:	cmp    $0xf0,%dil
  7614cb:	jb     762bf3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1ee3>
  7614d1:	movzbl 0x3(%rcx),%ecx
  7614d5:	and    $0x7,%eax
  7614d8:	shl    $0x12,%eax
  7614db:	shl    $0x6,%edx
  7614de:	and    $0x3f,%ecx
  7614e1:	or     %edx,%ecx
  7614e3:	or     %ecx,%eax
  7614e5:	cmp    $0x80,%eax
  7614ea:	jae    762c03 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1ef3>
  7614f0:	jmp    760db3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xa3>
  7614f5:	mov    $0x1,%eax
  7614fa:	mov    %rax,0x18(%rsp)
  7614ff:	mov    0x170(%rsp),%rax
  761507:	mov    %rax,0x1d0(%rsp)
  76150f:	mov    0x178(%rsp),%rax
  761517:	mov    %rax,0x128(%rsp)
  76151f:	mov    0x18(%rsp),%r14
  761524:	lea    0x0(,%r14,4),%rbx
  76152c:	call   *0x358b86(%rip)        # aba0b8 <_DYNAMIC+0x248>
  761532:	mov    $0x4,%esi
  761537:	mov    %rbx,%rdi
  76153a:	call   *0x358b80(%rip)        # aba0c0 <_DYNAMIC+0x250>
  761540:	mov    %rax,0x118(%rsp)
  761548:	test   %rax,%rax
  76154b:	je     7630d3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x23c3>
  761551:	cmp    $0x8,%r14
  761555:	jae    76155e <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x84e>
  761557:	xor    %eax,%eax
  761559:	jmp    7615e8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x8d8>
  76155e:	mov    %r14,%rax
  761561:	and    $0xfffffffffffffff8,%rax
  761565:	xor    %ecx,%ecx
  761567:	mov    0x128(%rsp),%rdx
  76156f:	mov    0x118(%rsp),%rsi
  761577:	nopw   0x0(%rax,%rax,1)
  761580:	movss  0xa8(%rdx),%xmm0
  761588:	movss  0x70(%rdx),%xmm1
  76158d:	unpcklps %xmm0,%xmm1
  761590:	movss  0x38(%rdx),%xmm0
  761595:	movss  (%rdx),%xmm2
  761599:	unpcklps %xmm0,%xmm2
  76159c:	movlhps %xmm1,%xmm2
  76159f:	movss  0x188(%rdx),%xmm0
  7615a7:	movss  0x150(%rdx),%xmm1
  7615af:	unpcklps %xmm0,%xmm1
  7615b2:	movss  0x118(%rdx),%xmm0
  7615ba:	movss  0xe0(%rdx),%xmm3
  7615c2:	unpcklps %xmm0,%xmm3
  7615c5:	movlhps %xmm1,%xmm3
  7615c8:	movups %xmm2,(%rsi,%rcx,4)
  7615cc:	movups %xmm3,0x10(%rsi,%rcx,4)
  7615d1:	add    $0x8,%rcx
  7615d5:	add    $0x1c0,%rdx
  7615dc:	cmp    %rcx,%rax
  7615df:	jne    761580 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x870>
  7615e1:	cmp    %rax,0x18(%rsp)
  7615e6:	je     761621 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x911>
  7615e8:	imul   $0x38,%rax,%rcx
  7615ec:	add    0x128(%rsp),%rcx
  7615f4:	mov    0x18(%rsp),%rsi
  7615f9:	mov    0x118(%rsp),%rdi
  761601:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  761610:	mov    (%rcx),%edx
  761612:	mov    %edx,(%rdi,%rax,4)
  761615:	inc    %rax
  761618:	add    $0x38,%rcx
  76161c:	cmp    %rax,%rsi
  76161f:	jne    761610 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x900>
  761621:	lea    0x288(%rsp),%rdi
  761629:	call   765810 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount>
  76162e:	mov    %rax,%rbx
  761631:	mov    %rax,0x8(%rsp)
  761636:	cmpb   $0x0,0x76e(%rax)
  76163d:	jne    762fe6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x22d6>
  761643:	cmpb   $0x1,0x76a(%rbx)
  76164a:	jne    762fed <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x22dd>
  761650:	mov    0x5c0(%rbx),%r12
  761657:	mov    $0x1a,%eax
  76165c:	mov    %rax,0x10(%rsp)
  761661:	test   %r12,%r12
  761664:	je     762ff7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x22e7>
  76166a:	mov    0x5b8(%rbx),%r13
  761671:	shl    $0x6,%r12
  761675:	lea    0x1e8(%rbx),%r14
  76167c:	xor    %ebp,%ebp
  76167e:	mov    0x358ae3(%rip),%r15        # aba168 <_DYNAMIC+0x2f8>
  761685:	jmp    76169d <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x98d>
  761687:	nopw   0x0(%rax,%rax,1)
  761690:	add    $0x40,%rbp
  761694:	cmp    %rbp,%r12
  761697:	je     762ff7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x22e7>
  76169d:	cmpb   $0x4,0x3d(%r13,%rbp,1)
  7616a3:	jne    761690 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x980>
  7616a5:	mov    0x20(%r13,%rbp,1),%rsi
  7616aa:	mov    %r14,%rdi
  7616ad:	call   *%r15
  7616b0:	test   %al,%al
  7616b2:	je     761690 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x980>
  7616b4:	mov    0x20(%r13,%rbp,1),%rsi
  7616b9:	add    $0x5f0,%rbx
  7616c0:	mov    %rbx,%rdi
  7616c3:	call   *0x358c47(%rip)        # aba310 <_DYNAMIC+0x4a0>
  7616c9:	mov    %rax,0x1c8(%rsp)
  7616d1:	mov    %rdx,0x2d0(%rsp)
  7616d9:	mov    0x8(%rsp),%rsi
  7616de:	movq   $0x0,0x1d8(%rsp)
  7616ea:	movq   $0x4,0x1e0(%rsp)
  7616f6:	movq   $0x0,0x1e8(%rsp)
  761702:	test   %rsi,%rsi
  761705:	je     76302b <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x231b>
  76170b:	cmpb   $0x0,0x76e(%rsi)
  761712:	jne    763032 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2322>
  761718:	cmpb   $0x1,0x76c(%rsi)
  76171f:	jne    763039 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2329>
  761725:	lea    0x20(%rsp),%rdi
  76172a:	call   73dde0 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime5queryNtB3_7Context3newNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEBX_>
  76172f:	mov    0x58(%rsp),%rax
  761734:	mov    %rax,0x110(%rsp)
  76173c:	test   %rax,%rax
  76173f:	je     761cdd <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xfcd>
  761745:	mov    $0x4,%eax
  76174a:	mov    %rax,0x108(%rsp)
  761752:	movq   $0x0,0xa0(%rsp)
  76175e:	xor    %ebp,%ebp
  761760:	jmp    761781 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xa71>
  761762:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  761770:	inc    %rbp
  761773:	cmp    0x110(%rsp),%rbp
  76177b:	je     761cbe <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xfae>
  761781:	mov    0x58(%rsp),%rsi
  761786:	cmp    %rsi,%rbp
  761789:	jae    762efa <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x21ea>
  76178f:	mov    0x50(%rsp),%rax
  761794:	mov    %rbp,%rcx
  761797:	shl    $0x6,%rcx
  76179b:	cmpb   $0x4,0x3d(%rax,%rcx,1)
  7617a0:	jne    761770 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xa60>
  7617a2:	lea    0xb0(%rsp),%rdi
  7617aa:	lea    0x20(%rsp),%rsi
  7617af:	mov    %rbp,%rdx
  7617b2:	call   *0x358b00(%rip)        # aba2b8 <_DYNAMIC+0x448>
  7617b8:	cmpq   $0x0,0xb0(%rsp)
  7617c1:	je     762c26 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1f16>
  7617c7:	movups 0xb0(%rsp),%xmm0
  7617cf:	movaps %xmm0,0x2e0(%rsp)
  7617d7:	mov    0xc0(%rsp),%rsi
  7617df:	mov    0xc8(%rsp),%rax
  7617e7:	mov    %rax,0x130(%rsp)
  7617ef:	lea    0x200(%rsp),%rdi
  7617f7:	mov    %rsi,0x120(%rsp)
  7617ff:	call   *0x358b23(%rip)        # aba328 <_DYNAMIC+0x4b8>
  761805:	mov    0x240(%rsp),%rax
  76180d:	mov    %rax,0xf0(%rsp)
  761815:	movups 0x200(%rsp),%xmm0
  76181d:	movups 0x210(%rsp),%xmm1
  761825:	movups 0x220(%rsp),%xmm2
  76182d:	movups 0x230(%rsp),%xmm3
  761835:	movaps %xmm3,0xe0(%rsp)
  76183d:	movaps %xmm2,0xd0(%rsp)
  761845:	movaps %xmm1,0xc0(%rsp)
  76184d:	movaps %xmm0,0xb0(%rsp)
  761855:	mov    0xe8(%rsp),%rax
  76185d:	mov    %rax,0x10(%rsp)
  761862:	mov    $0x2,%eax
  761867:	movss  0xf0(%rsp),%xmm0
  761870:	movss  %xmm0,0xa8(%rsp)
  761879:	dec    %rax
  76187c:	mov    %rax,0xf8(%rsp)
  761884:	lea    0x170(%rsp),%rdi
  76188c:	lea    0xb0(%rsp),%rsi
  761894:	call   798540 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control>
  761899:	cmpq   $0x0,0x170(%rsp)
  7618a2:	je     761770 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xa60>
  7618a8:	mov    0xb0(%rsp),%rbx
  7618b0:	mov    0xb8(%rsp),%r14
  7618b8:	mov    0xd0(%rsp),%r13
  7618c0:	mov    0xc8(%rsp),%r15
  7618c8:	mov    0xc0(%rsp),%r12
  7618d0:	lea    0x190(%rsp),%rdi
  7618d8:	mov    0x10(%rsp),%rsi
  7618dd:	movss  0xa8(%rsp),%xmm0
  7618e6:	lea    0x170(%rsp),%rdx
  7618ee:	call   75d540 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control>
  7618f3:	cmpb   $0x2,0x194(%rsp)
  7618fb:	je     76190b <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xbfb>
  7618fd:	testb  $0x1,0x1c0(%rsp)
  761905:	je     761b00 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xdf0>
  76190b:	mov    %r14,%rax
  76190e:	cmp    $0x1,%r14
  761912:	je     761944 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xc34>
  761914:	test   %r14,%r14
  761917:	je     761770 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xa60>
  76191d:	mov    (%rbx),%ecx
  76191f:	lea    0xc(%rbx),%rdx
  761923:	lea    0x1(%r14),%rsi
  761927:	mov    $0x1,%eax
  76192c:	nopl   0x0(%rax)
  761930:	cmp    (%rdx),%ecx
  761932:	jne    761944 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xc34>
  761934:	inc    %rax
  761937:	add    $0xc,%rdx
  76193b:	dec    %rsi
  76193e:	cmp    $0x2,%rsi
  761942:	ja     761930 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xc20>
  761944:	sub    %rax,%r14
  761947:	jb     762a7e <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1d6e>
  76194d:	mov    %r14,0xb8(%rsp)
  761955:	test   %r13,%r13
  761958:	jne    761a0d <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xcfd>
  76195e:	mov    %r15,%rcx
  761961:	cmp    $0x1,%r15
  761965:	je     7619a4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xc94>
  761967:	test   %r15,%r15
  76196a:	je     761770 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xa60>
  761970:	mov    (%r12),%edx
  761974:	lea    0xc(%r12),%rsi
  761979:	lea    0x1(%r15),%rdi
  76197d:	mov    $0x1,%ecx
  761982:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  761990:	cmp    (%rsi),%edx
  761992:	jne    7619a4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xc94>
  761994:	inc    %rcx
  761997:	add    $0xc,%rsi
  76199b:	dec    %rdi
  76199e:	cmp    $0x2,%rdi
  7619a2:	ja     761990 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xc80>
  7619a4:	sub    %rcx,%r15
  7619a7:	jb     762a7e <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1d6e>
  7619ad:	lea    (%rcx,%rcx,2),%rdx
  7619b1:	lea    (%r12,%rdx,4),%rdx
  7619b5:	mov    %rdx,0xc0(%rsp)
  7619bd:	mov    %r15,0xc8(%rsp)
  7619c5:	test   %r12,%r12
  7619c8:	je     761770 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xa60>
  7619ce:	lea    (%rax,%rax,2),%rsi
  7619d2:	mov    %rbx,0x170(%rsp)
  7619da:	mov    %rax,0x178(%rsp)
  7619e2:	mov    %r12,0x180(%rsp)
  7619ea:	mov    %rcx,0x188(%rsp)
  7619f2:	mov    %rdx,%r12
  7619f5:	mov    $0x0,%r13d
  7619fb:	test   %rbx,%rbx
  7619fe:	lea    (%rbx,%rsi,4),%rbx
  761a02:	jne    7618d0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xbc0>
  761a08:	jmp    761770 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xa60>
  761a0d:	movq   $0x0,0xd0(%rsp)
  761a19:	nopl   0x0(%rax)
  761a20:	mov    %r12,%rsi
  761a23:	mov    %r15,%rdx
  761a26:	mov    %r15,%rdi
  761a29:	cmp    $0x1,%r15
  761a2d:	je     761a65 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xd55>
  761a2f:	test   %rdx,%rdx
  761a32:	je     761770 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xa60>
  761a38:	mov    (%rsi),%ecx
  761a3a:	lea    0xc(%rsi),%r8
  761a3e:	lea    0x1(%rdx),%r9
  761a42:	mov    $0x1,%edi
  761a47:	nopw   0x0(%rax,%rax,1)
  761a50:	cmp    (%r8),%ecx
  761a53:	jne    761a65 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xd55>
  761a55:	inc    %rdi
  761a58:	add    $0xc,%r8
  761a5c:	dec    %r9
  761a5f:	cmp    $0x2,%r9
  761a63:	ja     761a50 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xd40>
  761a65:	mov    %rdx,%r15
  761a68:	sub    %rdi,%r15
  761a6b:	jb     762a7e <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1d6e>
  761a71:	lea    (%rdi,%rdi,2),%r9
  761a75:	lea    (%rsi,%r9,4),%r12
  761a79:	dec    %r13
  761a7c:	jne    761a20 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xd10>
  761a7e:	mov    %r12,0xc0(%rsp)
  761a86:	mov    %r15,0xc8(%rsp)
  761a8e:	mov    %r15,%rcx
  761a91:	cmp    $0x1,%r15
  761a95:	je     761ad5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xdc5>
  761a97:	test   %r15,%r15
  761a9a:	je     761770 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xa60>
  761aa0:	mov    (%r12),%r8d
  761aa4:	lea    (%rsi,%r9,4),%rsi
  761aa8:	add    $0xc,%rsi
  761aac:	sub    %rdi,%rdx
  761aaf:	inc    %rdx
  761ab2:	mov    $0x1,%ecx
  761ab7:	nopw   0x0(%rax,%rax,1)
  761ac0:	cmp    (%rsi),%r8d
  761ac3:	jne    761ad5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xdc5>
  761ac5:	inc    %rcx
  761ac8:	add    $0xc,%rsi
  761acc:	dec    %rdx
  761acf:	cmp    $0x2,%rdx
  761ad3:	ja     761ac0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xdb0>
  761ad5:	sub    %rcx,%r15
  761ad8:	jb     762a7e <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1d6e>
  761ade:	lea    (%rcx,%rcx,2),%rdx
  761ae2:	lea    (%r12,%rdx,4),%rdx
  761ae6:	mov    %rdx,0xc0(%rsp)
  761aee:	mov    %r15,0xc8(%rsp)
  761af6:	jmp    7619ce <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xcbe>
  761afb:	nopl   0x0(%rax,%rax,1)
  761b00:	mov    %rbx,0xb0(%rsp)
  761b08:	lea    0x195(%rsp),%rax
  761b10:	movups (%rax),%xmm0
  761b13:	movups 0x10(%rax),%xmm1
  761b17:	movups 0x1b(%rax),%xmm2
  761b1b:	movaps %xmm0,0x250(%rsp)
  761b23:	movaps %xmm1,0x260(%rsp)
  761b2b:	movups %xmm2,0x26b(%rsp)
  761b33:	lea    0x258(%rsp),%rax
  761b3b:	movups (%rax),%xmm0
  761b3e:	movaps %xmm0,0x300(%rsp)
  761b46:	mov    0xf(%rax),%eax
  761b49:	mov    %eax,0x30f(%rsp)
  761b50:	lea    0x303(%rsp),%rax
  761b58:	movups (%rax),%xmm0
  761b5b:	movaps %xmm0,0x170(%rsp)
  761b63:	movaps 0x2e0(%rsp),%xmm0
  761b6b:	movaps %xmm0,0x190(%rsp)
  761b73:	mov    0x120(%rsp),%rax
  761b7b:	mov    %rax,0x1a0(%rsp)
  761b83:	mov    0x130(%rsp),%rax
  761b8b:	mov    %rax,0x1a8(%rsp)
  761b93:	lea    0x250(%rsp),%rdi
  761b9b:	lea    0x190(%rsp),%rsi
  761ba3:	lea    0x170(%rsp),%rdx
  761bab:	call   *0x35879f(%rip)        # aba350 <_DYNAMIC+0x4e0>
  761bb1:	cmpb   $0x0,0x250(%rsp)
  761bb9:	je     762c4d <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1f3d>
  761bbf:	movsd  0x254(%rsp),%xmm1
  761bc8:	movsd  0x25c(%rsp),%xmm0
  761bd1:	mulps  -0x69e508(%rip),%xmm0        # c36d0 <GCC_except_table0+0x1304>
  761bd8:	addps  %xmm1,%xmm0
  761bdb:	movaps %xmm0,%xmm1
  761bde:	shufps $0x55,%xmm0,%xmm1
  761be2:	movaps 0x2e0(%rsp),%xmm2
  761bea:	movaps %xmm2,0x190(%rsp)
  761bf2:	mov    0x120(%rsp),%rax
  761bfa:	mov    %rax,0x1a0(%rsp)
  761c02:	mov    0x130(%rsp),%rax
  761c0a:	mov    %rax,0x1a8(%rsp)
  761c12:	lea    0x190(%rsp),%rdi
  761c1a:	movaps %xmm0,0x1f0(%rsp)
  761c22:	call   *0x358730(%rip)        # aba358 <_DYNAMIC+0x4e8>
  761c28:	mov    %edx,%r14d
  761c2b:	cmp    $0x2,%dl
  761c2e:	je     762c56 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1f46>
  761c34:	mov    %eax,%ebx
  761c36:	mov    0xa0(%rsp),%rax
  761c3e:	cmp    0x1d8(%rsp),%rax
  761c46:	jne    761c65 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xf55>
  761c48:	lea    0x1d8(%rsp),%rdi
  761c50:	call   7729a0 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtCscO85OU7Wpt0_20gpui_reactivity_core8geometry4RectE8grow_oneCs9C2G9YFESsD_29canonical_text_public_control>
  761c55:	mov    0x1e0(%rsp),%rax
  761c5d:	mov    %rax,0x108(%rsp)
  761c65:	and    $0x1,%r14b
  761c69:	mov    0xa0(%rsp),%rcx
  761c71:	mov    %rcx,%rax
  761c74:	shl    $0x4,%rax
  761c78:	mov    0x108(%rsp),%rdx
  761c80:	movaps 0x1f0(%rsp),%xmm0
  761c88:	movlps %xmm0,(%rdx,%rax,1)
  761c8c:	mov    %ebx,0x8(%rdx,%rax,1)
  761c90:	mov    %r14b,0xc(%rdx,%rax,1)
  761c95:	inc    %rcx
  761c98:	mov    %rcx,0xa0(%rsp)
  761ca0:	mov    %rcx,0x1e8(%rsp)
  761ca8:	mov    0xf8(%rsp),%rax
  761cb0:	test   %rax,%rax
  761cb3:	jne    761879 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xb69>
  761cb9:	jmp    761770 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xa60>
  761cbe:	mov    0x1d8(%rsp),%rax
  761cc6:	mov    %rax,0x120(%rsp)
  761cce:	mov    0x1e0(%rsp),%rax
  761cd6:	mov    %rax,0x10(%rsp)
  761cdb:	jmp    761cff <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xfef>
  761cdd:	mov    $0x4,%eax
  761ce2:	mov    %rax,0x10(%rsp)
  761ce7:	movq   $0x0,0xa0(%rsp)
  761cf3:	movq   $0x0,0x120(%rsp)
  761cff:	mov    $0xffffffff,%eax
  761d04:	mov    %rax,0x190(%rsp)
  761d0c:	movq   $0x0,0x198(%rsp)
  761d18:	mov    0x138(%rsp),%rdi
  761d20:	xor    %esi,%esi
  761d22:	mov    $0x1,%edx
  761d27:	call   *0x3585eb(%rip)        # aba318 <_DYNAMIC+0x4a8>
  761d2d:	mov    %edx,%ebx
  761d2f:	cmp    $0x2,%dl
  761d32:	je     762d21 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2011>
  761d38:	test   %eax,%eax
  761d3a:	sete   0xa8(%rsp)
  761d42:	mov    0x2b8(%rsp),%r15
  761d4a:	mov    0x2c0(%rsp),%r12
  761d52:	cmp    $0x4,%r12
  761d56:	je     761e64 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1154>
  761d5c:	cmp    $0x5,%r12
  761d60:	jne    761f30 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1220>
  761d66:	mov    $0x6f727261,%eax
  761d6b:	xor    (%r15),%eax
  761d6e:	movzbl 0x4(%r15),%ecx
  761d73:	xor    $0x77,%ecx
  761d76:	or     %eax,%ecx
  761d78:	jne    761e0f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x10ff>
  761d7e:	cmpq   $0x5,0x140(%rsp)
  761d87:	jne    761da7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1097>
  761d89:	mov    $0x74706d65,%eax
  761d8e:	mov    0x2c8(%rsp),%rcx
  761d96:	xor    (%rcx),%eax
  761d98:	movzbl 0x4(%rcx),%ecx
  761d9c:	xor    $0x79,%ecx
  761d9f:	or     %eax,%ecx
  761da1:	je     762ecf <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x21bf>
  761da7:	movl   $0x0,0x20(%rsp)
  761daf:	movb   $0x1,0x24(%rsp)
  761db4:	movl   $0x0,0x28(%rsp)
  761dbc:	movb   $0x1,0x2c(%rsp)
  761dc1:	mov    0x8(%rsp),%rsi
  761dc6:	test   %rsi,%rsi
  761dc9:	je     7630e6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x23d6>
  761dcf:	lea    0xb0(%rsp),%rdi
  761dd7:	lea    0x20(%rsp),%r8
  761ddc:	mov    0x1c8(%rsp),%rdx
  761de4:	mov    0x2d0(%rsp),%rcx
  761dec:	call   76fb30 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE12select_inputB12_>
  761df1:	cmpq   $0xfffffffffffffffe,0xb0(%rsp)
  761dfa:	jne    7630fe <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x23ee>
  761e00:	mov    0x8(%rsp),%rsi
  761e05:	lea    0x20(%rsp),%rdi
  761e0a:	call   760ba0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack>
  761e0f:	movl   $0x0,0x108(%rsp)
  761e1a:	mov    0x8(%rsp),%rax
  761e1f:	test   %rax,%rax
  761e22:	jne    761f49 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1239>
  761e28:	movq   $0xd,0x20(%rsp)
  761e31:	movq   $0x0,0x28(%rsp)
  761e3a:	lea    -0x6921df(%rip),%rdi        # cfc62 <GCC_except_table0+0xd896>
  761e41:	lea    0x338d18(%rip),%rcx        # a9ab60 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1218>
  761e48:	lea    0x338b01(%rip),%r8        # a9a950 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1008>
  761e4f:	lea    0x20(%rsp),%rdx
  761e54:	mov    $0x2b,%esi
  761e59:	call   *0x358321(%rip)        # aba180 <_DYNAMIC+0x310>
  761e5f:	jmp    7631ac <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x249c>
  761e64:	mov    $0x1,%al
  761e66:	mov    %eax,0x108(%rsp)
  761e6d:	cmpl   $0x67617264,(%r15)
  761e74:	jne    761f3b <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x122b>
  761e7a:	mov    0xa0(%rsp),%rax
  761e82:	mov    %rax,0x20(%rsp)
  761e87:	cmp    $0x2,%rax
  761e8b:	jne    762d93 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2083>
  761e91:	mov    0x10(%rsp),%rcx
  761e96:	mov    0x8(%rcx),%eax
  761e99:	cmp    0x18(%rcx),%eax
  761e9c:	jne    761eab <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x119b>
  761e9e:	movzbl 0xc(%rcx),%eax
  761ea2:	cmp    0x1c(%rcx),%al
  761ea5:	je     762ee1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x21d1>
  761eab:	movsd  (%rcx),%xmm0
  761eaf:	movsd  %xmm0,0x24(%rsp)
  761eb5:	movl   $0x0,0x20(%rsp)
  761ebd:	lea    0xb0(%rsp),%rdi
  761ec5:	lea    0x8(%rsp),%rsi
  761eca:	lea    0x190(%rsp),%rdx
  761ed2:	lea    0x20(%rsp),%rcx
  761ed7:	call   76d910 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_>
  761edc:	cmpl   $0xfffffffe,0xb0(%rsp)
  761ee4:	jne    762db5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x20a5>
  761eea:	movl   $0x2,0x20(%rsp)
  761ef2:	lea    0xb0(%rsp),%rdi
  761efa:	lea    0x8(%rsp),%rsi
  761eff:	lea    0x190(%rsp),%rdx
  761f07:	lea    0x20(%rsp),%rcx
  761f0c:	call   76d910 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_>
  761f11:	cmpl   $0xfffffffe,0xb0(%rsp)
  761f19:	jne    762e13 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2103>
  761f1f:	mov    0x8(%rsp),%rsi
  761f24:	lea    0x20(%rsp),%rdi
  761f29:	call   760ba0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack>
  761f2e:	jmp    761f3b <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x122b>
  761f30:	movl   $0x0,0x108(%rsp)
  761f3b:	mov    0x8(%rsp),%rax
  761f40:	test   %rax,%rax
  761f43:	je     761e28 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1118>
  761f49:	xorps  %xmm0,%xmm0
  761f4c:	movups %xmm0,0x740(%rax)
  761f53:	movups %xmm0,0x730(%rax)
  761f5a:	movups %xmm0,0x720(%rax)
  761f61:	movups %xmm0,0x710(%rax)
  761f68:	movups %xmm0,0x700(%rax)
  761f6f:	movups %xmm0,0x6f0(%rax)
  761f76:	movq   $0x0,0x750(%rax)
  761f81:	cmpb   $0x0,0x390(%rsp)
  761f89:	je     761fa2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1292>
  761f8b:	call   *0x3583cf(%rip)        # aba360 <_DYNAMIC+0x4f0>
  761f91:	mov    %rax,0x1c8(%rsp)
  761f99:	mov    %edx,0x1f0(%rsp)
  761fa0:	jmp    761fad <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x129d>
  761fa2:	movl   $0xffffffff,0x1f0(%rsp)
  761fad:	mov    0x18(%rsp),%r14
  761fb2:	cmp    $0x1,%r14
  761fb6:	adc    $0x0,%r14
  761fba:	mov    0xa0(%rsp),%rax
  761fc2:	cmp    $0x1,%rax
  761fc6:	adc    $0x0,%rax
  761fca:	mov    %rax,0x110(%rsp)
  761fd2:	mov    %r12,0x130(%rsp)
  761fda:	lea    -0x3(%r12),%rbp
  761fdf:	cmp    $0x7,%rbp
  761fe3:	setb   %al
  761fe6:	mov    $0x5f,%dl
  761fe8:	mov    %ebp,%ecx
  761fea:	shr    %cl,%dl
  761fec:	and    %al,%dl
  761fee:	cmp    $0x1,%dl
  761ff1:	je     76202a <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x131a>
  761ff3:	lea    0x2b8(%rsp),%rax
  761ffb:	mov    %rax,0x20(%rsp)
  762000:	lea    0x34c29(%rip),%rax        # 796c30 <_RNvXs1i_NtCs4NRVxsYgnAr_4core3fmtReNtB6_7Display3fmtCs9C2G9YFESsD_29canonical_text_public_control>
  762007:	mov    %rax,0x28(%rsp)
  76200c:	lea    -0x698690(%rip),%rdi        # c9983 <GCC_except_table0+0x75b7>
  762013:	lea    0x3389ae(%rip),%rdx        # a9a9c8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1080>
  76201a:	lea    0x20(%rsp),%rsi
  76201f:	call   *0x3580c3(%rip)        # aba0e8 <_DYNAMIC+0x278>
  762025:	jmp    7631ac <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x249c>
  76202a:	and    %bl,0xa8(%rsp)
  762031:	mov    0x18(%rsp),%rax
  762036:	shr    $1,%rax
  762039:	mov    %rax,0x140(%rsp)
  762041:	mov    $0x1,%r12d
  762047:	xor    %ebx,%ebx
  762049:	lea    0x20(%rsp),%r13
  76204e:	jmp    7620b0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x13a0>
  762050:	lea    0x4c79(%rip),%rax        # 766cd0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9query_hit>
  762057:	mov    %rax,0x20(%rsp)
  76205c:	mov    0x20(%rsp),%rcx
  762061:	mov    0x138(%rsp),%rax
  762069:	mov    %rax,0x20(%rsp)
  76206e:	mov    0x20(%rsp),%rdi
  762073:	movlps %xmm0,0x20(%rsp)
  762078:	movsd  0x20(%rsp),%xmm0
  76207e:	movaps %xmm0,%xmm1
  762081:	shufps $0x55,%xmm0,%xmm1
  762085:	call   *%rcx
  762087:	inc    %rbx
  76208a:	mov    %rax,0x20(%rsp)
  76208f:	xor    0x20(%rsp),%r12
  762094:	movabs $0x100000001b3,%rax
  76209e:	imul   %rax,%r12
  7620a2:	cmp    %rbx,0x148(%rsp)
  7620aa:	je     762526 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1816>
  7620b0:	cmp    $0x6,%rbp
  7620b4:	ja     7620fd <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x13ed>
  7620b6:	lea    -0x69e0c5(%rip),%rcx        # c3ff8 <GCC_except_table0+0x1c2c>
  7620bd:	movslq (%rcx,%rbp,4),%rax
  7620c1:	add    %rcx,%rax
  7620c4:	jmp    *%rax
  7620c6:	movzwl (%r15),%eax
  7620ca:	xor    $0x6968,%eax
  7620cf:	movzbl 0x2(%r15),%ecx
  7620d4:	xor    $0x74,%ecx
  7620d7:	or     %ax,%cx
  7620da:	jne    761ff3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x12e3>
  7620e0:	mov    %rbx,%rax
  7620e3:	or     %r14,%rax
  7620e6:	shr    $0x20,%rax
  7620ea:	je     762474 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1764>
  7620f0:	mov    %rbx,%rax
  7620f3:	xor    %edx,%edx
  7620f5:	div    %r14
  7620f8:	jmp    76247b <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x176b>
  7620fd:	mov    (%r15),%eax
  762100:	mov    $0x70657270,%ecx
  762105:	xor    %ecx,%eax
  762107:	mov    0x3(%r15),%ecx
  76210b:	mov    $0x65726170,%edx
  762110:	xor    %edx,%ecx
  762112:	or     %eax,%ecx
  762114:	je     76239b <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x168b>
  76211a:	mov    (%r15),%eax
  76211d:	mov    $0x68736572,%ecx
  762122:	xor    %ecx,%eax
  762124:	mov    0x3(%r15),%ecx
  762128:	mov    $0x65706168,%edx
  76212d:	xor    %edx,%ecx
  76212f:	or     %eax,%ecx
  762131:	jne    761ff3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x12e3>
  762137:	lea    -0x203e(%rip),%rax        # 760100 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_reshape>
  76213e:	mov    %rax,0x20(%rsp)
  762143:	mov    0x20(%rsp),%rax
  762148:	lea    0x8(%rsp),%rcx
  76214d:	mov    %rcx,0x20(%rsp)
  762152:	mov    0x20(%rsp),%rdi
  762157:	test   $0x1,%bl
  76215a:	lea    0x2a8(%rsp),%rcx
  762162:	lea    0x158(%rsp),%rdx
  76216a:	cmove  %rdx,%rcx
  76216e:	mov    (%rcx),%rcx
  762171:	lea    0x2b0(%rsp),%rdx
  762179:	lea    0x160(%rsp),%rsi
  762181:	cmove  %rsi,%rdx
  762185:	mov    (%rdx),%rdx
  762188:	mov    %rcx,0x20(%rsp)
  76218d:	mov    %rdx,0x28(%rsp)
  762192:	mov    0x20(%rsp),%rsi
  762197:	mov    0x28(%rsp),%rdx
  76219c:	call   *%rax
  76219e:	jmp    762087 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1377>
  7621a3:	mov    (%r15),%eax
  7621a6:	mov    $0x6f727261,%ecx
  7621ab:	xor    %ecx,%eax
  7621ad:	movzbl 0x4(%r15),%ecx
  7621b2:	xor    $0x77,%ecx
  7621b5:	or     %eax,%ecx
  7621b7:	jne    761ff3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x12e3>
  7621bd:	lea    -0x2c54(%rip),%rax        # 75f570 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow>
  7621c4:	mov    %rax,0x20(%rsp)
  7621c9:	mov    0x20(%rsp),%rax
  7621ce:	lea    0x8(%rsp),%rcx
  7621d3:	mov    %rcx,0x20(%rsp)
  7621d8:	mov    0x20(%rsp),%rdi
  7621dd:	test   $0x1,%bl
  7621e0:	sete   %cl
  7621e3:	xor    0xa8(%rsp),%cl
  7621ea:	mov    %cl,0x20(%rsp)
  7621ee:	jmp    7623c6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x16b6>
  7621f3:	cmpl   $0x67617264,(%r15)
  7621fa:	jne    761ff3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x12e3>
  762200:	lea    -0x3237(%rip),%rax        # 75efd0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag>
  762207:	mov    %rax,0x20(%rsp)
  76220c:	mov    0x20(%rsp),%rcx
  762211:	lea    0x8(%rsp),%rax
  762216:	mov    %rax,0x20(%rsp)
  76221b:	mov    0x20(%rsp),%rdi
  762220:	lea    0x190(%rsp),%rax
  762228:	mov    %rax,0x20(%rsp)
  76222d:	mov    %ebx,%eax
  76222f:	not    %eax
  762231:	and    $0x1,%eax
  762234:	cmp    0xa0(%rsp),%rax
  76223c:	jae    762fc9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x22b9>
  762242:	mov    0x20(%rsp),%rsi
  762247:	shl    $0x4,%eax
  76224a:	mov    0x10(%rsp),%rdx
  76224f:	movsd  (%rdx,%rax,1),%xmm0
  762254:	movsd  %xmm0,0x20(%rsp)
  76225a:	movss  0x20(%rsp),%xmm0
  762260:	movss  0x24(%rsp),%xmm1
  762266:	call   *%rcx
  762268:	jmp    762087 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1377>
  76226d:	mov    (%r15),%eax
  762270:	mov    $0x75736976,%ecx
  762275:	xor    %ecx,%eax
  762277:	movzwl 0x4(%r15),%ecx
  76227c:	xor    $0x6c61,%ecx
  762282:	or     %eax,%ecx
  762284:	jne    761ff3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x12e3>
  76228a:	lea    -0x2791(%rip),%rax        # 75fb00 <_RNvCs9C2G9YFESsD_29canonical_text_public_control12query_visual>
  762291:	mov    %rax,0x20(%rsp)
  762296:	mov    0x20(%rsp),%rcx
  76229b:	mov    0x138(%rsp),%rax
  7622a3:	mov    %rax,0x20(%rsp)
  7622a8:	mov    0x20(%rsp),%rdi
  7622ad:	mov    %rbx,%rax
  7622b0:	or     %r14,%rax
  7622b3:	shr    $0x20,%rax
  7622b7:	je     7624c1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x17b1>
  7622bd:	mov    %rbx,%rax
  7622c0:	xor    %edx,%edx
  7622c2:	div    %r14
  7622c5:	xor    %eax,%eax
  7622c7:	cmp    0x18(%rsp),%rdx
  7622cc:	jae    7622d9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x15c9>
  7622ce:	mov    0x118(%rsp),%rax
  7622d6:	mov    (%rax,%rdx,4),%eax
  7622d9:	mov    %eax,0x20(%rsp)
  7622dd:	movb   $0x1,0x24(%rsp)
  7622e2:	mov    0x20(%rsp),%esi
  7622e6:	movzbl 0x24(%rsp),%edx
  7622eb:	call   *%rcx
  7622ed:	jmp    762087 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1377>
  7622f2:	mov    (%r15),%rax
  7622f5:	movabs $0x6f697463656c6573,%rcx
  7622ff:	xor    %rcx,%rax
  762302:	movzbl 0x8(%r15),%ecx
  762307:	xor    $0x6e,%rcx
  76230b:	or     %rax,%rcx
  76230e:	je     7623d5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x16c5>
  762314:	mov    (%r15),%rax
  762317:	movabs $0x69682d72656e776f,%rcx
  762321:	xor    %rcx,%rax
  762324:	movzbl 0x8(%r15),%ecx
  762329:	xor    $0x74,%rcx
  76232d:	or     %rax,%rcx
  762330:	jne    761ff3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x12e3>
  762336:	lea    0x47f3(%rip),%rax        # 766b30 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit>
  76233d:	mov    %rax,0x20(%rsp)
  762342:	mov    0x20(%rsp),%rcx
  762347:	lea    0x8(%rsp),%rax
  76234c:	mov    %rax,0x20(%rsp)
  762351:	mov    0x20(%rsp),%rdi
  762356:	mov    %rbx,%rax
  762359:	mov    0x110(%rsp),%rsi
  762361:	or     %rsi,%rax
  762364:	shr    $0x20,%rax
  762368:	je     7624da <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x17ca>
  76236e:	mov    %rbx,%rax
  762371:	xor    %edx,%edx
  762373:	div    %rsi
  762376:	xorps  %xmm0,%xmm0
  762379:	cmp    0xa0(%rsp),%rdx
  762381:	jae    762391 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1681>
  762383:	shl    $0x4,%rdx
  762387:	mov    0x10(%rsp),%rax
  76238c:	movsd  (%rax,%rdx,1),%xmm0
  762391:	movlps %xmm0,0x20(%rsp)
  762396:	jmp    762078 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1368>
  76239b:	lea    -0x2812(%rip),%rax        # 75fb90 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare>
  7623a2:	mov    %rax,0x20(%rsp)
  7623a7:	mov    0x20(%rsp),%rax
  7623ac:	lea    0x8(%rsp),%rcx
  7623b1:	mov    %rcx,0x20(%rsp)
  7623b6:	mov    0x20(%rsp),%rdi
  7623bb:	mov    %ebx,%ecx
  7623bd:	not    %cl
  7623bf:	and    $0x1,%cl
  7623c2:	mov    %cl,0x20(%rsp)
  7623c6:	movzbl 0x20(%rsp),%ecx
  7623cb:	movzbl %cl,%esi
  7623ce:	call   *%rax
  7623d0:	jmp    762087 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1377>
  7623d5:	lea    -0x1e0c(%rip),%rax        # 7605d0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection>
  7623dc:	mov    %rax,0x20(%rsp)
  7623e1:	mov    0x20(%rsp),%rcx
  7623e6:	mov    0x138(%rsp),%rax
  7623ee:	mov    %rax,0x20(%rsp)
  7623f3:	mov    0x20(%rsp),%rdi
  7623f8:	mov    %rbx,%rax
  7623fb:	or     %r14,%rax
  7623fe:	shr    $0x20,%rax
  762402:	je     7624f6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x17e6>
  762408:	mov    %rbx,%rax
  76240b:	xor    %edx,%edx
  76240d:	div    %r14
  762410:	xor    %esi,%esi
  762412:	cmp    0x18(%rsp),%rdx
  762417:	jae    762424 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1714>
  762419:	mov    0x118(%rsp),%rax
  762421:	mov    (%rax,%rdx,4),%esi
  762424:	mov    0x140(%rsp),%rax
  76242c:	add    %rbx,%rax
  76242f:	mov    %rax,%rdx
  762432:	or     %r14,%rdx
  762435:	shr    $0x20,%rdx
  762439:	je     76250f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x17ff>
  76243f:	xor    %edx,%edx
  762441:	div    %r14
  762444:	xor    %eax,%eax
  762446:	cmp    0x18(%rsp),%rdx
  76244b:	jae    762458 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1748>
  76244d:	mov    0x118(%rsp),%rax
  762455:	mov    (%rax,%rdx,4),%eax
  762458:	mov    %esi,0x20(%rsp)
  76245c:	movb   $0x1,0x24(%rsp)
  762461:	mov    %eax,0x28(%rsp)
  762465:	movb   $0x1,0x2c(%rsp)
  76246a:	mov    %r13,%rsi
  76246d:	call   *%rcx
  76246f:	jmp    762087 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1377>
  762474:	mov    %ebx,%eax
  762476:	xor    %edx,%edx
  762478:	div    %r14d
  76247b:	cmpq   $0x0,0x128(%rsp)
  762484:	sete   %al
  762487:	cmp    0x18(%rsp),%rdx
  76248c:	setae  %cl
  76248f:	or     %al,%cl
  762491:	xorps  %xmm0,%xmm0
  762494:	jne    762050 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1340>
  76249a:	imul   $0x38,%rdx,%rax
  76249e:	mov    0x128(%rsp),%rcx
  7624a6:	movsd  0x10(%rcx,%rax,1),%xmm1
  7624ac:	movsd  0x18(%rcx,%rax,1),%xmm0
  7624b2:	mulps  -0x69ede9(%rip),%xmm0        # c36d0 <GCC_except_table0+0x1304>
  7624b9:	addps  %xmm1,%xmm0
  7624bc:	jmp    762050 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1340>
  7624c1:	mov    %ebx,%eax
  7624c3:	xor    %edx,%edx
  7624c5:	div    %r14d
  7624c8:	xor    %eax,%eax
  7624ca:	cmp    0x18(%rsp),%rdx
  7624cf:	jae    7622d9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x15c9>
  7624d5:	jmp    7622ce <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x15be>
  7624da:	mov    %ebx,%eax
  7624dc:	xor    %edx,%edx
  7624de:	div    %esi
  7624e0:	xorps  %xmm0,%xmm0
  7624e3:	cmp    0xa0(%rsp),%rdx
  7624eb:	jb     762383 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1673>
  7624f1:	jmp    762391 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1681>
  7624f6:	mov    %ebx,%eax
  7624f8:	xor    %edx,%edx
  7624fa:	div    %r14d
  7624fd:	xor    %esi,%esi
  7624ff:	cmp    0x18(%rsp),%rdx
  762504:	jb     762419 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1709>
  76250a:	jmp    762424 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1714>
  76250f:	xor    %edx,%edx
  762511:	div    %r14d
  762514:	xor    %eax,%eax
  762516:	cmp    0x18(%rsp),%rdx
  76251b:	jb     76244d <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x173d>
  762521:	jmp    762458 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1748>
  762526:	mov    0x1f0(%rsp),%eax
  76252d:	cmp    $0xffffffff,%eax
  762530:	je     762581 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1871>
  762532:	mov    0x1c8(%rsp),%rcx
  76253a:	mov    %rcx,0x20(%rsp)
  76253f:	mov    %eax,0x28(%rsp)
  762543:	lea    0x20(%rsp),%rdi
  762548:	call   *0x357e1a(%rip)        # aba368 <_DYNAMIC+0x4f8>
  76254e:	mov    0x130(%rsp),%rsi
  762556:	mov    %edx,%ecx
  762558:	mov    $0x3b9aca00,%edx
  76255d:	mul    %rdx
  762560:	mov    %ecx,%ecx
  762562:	add    %rax,%rcx
  762565:	mov    %rcx,0xa8(%rsp)
  76256d:	adc    $0x0,%rdx
  762571:	mov    %rdx,0x110(%rsp)
  762579:	cmp    $0x7,%rsi
  76257d:	je     7625a7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1897>
  76257f:	jmp    7625c0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x18b0>
  762581:	movq   $0x0,0xa8(%rsp)
  76258d:	movq   $0x0,0x110(%rsp)
  762599:	mov    0x130(%rsp),%rsi
  7625a1:	cmp    $0x7,%rsi
  7625a5:	jne    7625c0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x18b0>
  7625a7:	mov    $0x68736572,%eax
  7625ac:	xor    (%r15),%eax
  7625af:	mov    $0x65706168,%ecx
  7625b4:	xor    0x3(%r15),%ecx
  7625b8:	or     %eax,%ecx
  7625ba:	je     762a9c <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1d8c>
  7625c0:	cmpb   $0x0,0x108(%rsp)
  7625c8:	je     762617 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1907>
  7625ca:	cmpl   $0x67617264,(%r15)
  7625d1:	jne    762617 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1907>
  7625d3:	movl   $0x3,0x20(%rsp)
  7625db:	lea    0xb0(%rsp),%rdi
  7625e3:	lea    0x8(%rsp),%rsi
  7625e8:	lea    0x190(%rsp),%rdx
  7625f0:	lea    0x20(%rsp),%rcx
  7625f5:	call   76d910 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_>
  7625fa:	cmpl   $0xfffffffe,0xb0(%rsp)
  762602:	jne    762e71 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2161>
  762608:	mov    0x8(%rsp),%rsi
  76260d:	lea    0x20(%rsp),%rdi
  762612:	call   760ba0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack>
  762617:	mov    0x8(%rsp),%rax
  76261c:	test   %rax,%rax
  76261f:	je     763082 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2372>
  762625:	mov    0x6f0(%rax),%rcx
  76262c:	mov    0x6f8(%rax),%r15
  762633:	mov    0x700(%rax),%r14
  76263a:	mov    0x708(%rax),%rbx
  762641:	mov    0x710(%rax),%rbp
  762648:	mov    0x718(%rax),%r13
  76264f:	mov    0x720(%rax),%rdx
  762656:	mov    %rdx,0x130(%rsp)
  76265e:	mov    0x728(%rax),%rdx
  762665:	mov    %rdx,0x148(%rsp)
  76266d:	mov    0x730(%rax),%rdx
  762674:	mov    %rdx,0xa0(%rsp)
  76267c:	mov    0x738(%rax),%rdx
  762683:	mov    %rdx,0x138(%rsp)
  76268b:	mov    0x740(%rax),%rdx
  762692:	mov    %rdx,0x1f0(%rsp)
  76269a:	mov    0x748(%rax),%rdx
  7626a1:	mov    %rdx,0x108(%rsp)
  7626a9:	mov    0x750(%rax),%rax
  7626b0:	mov    %rax,0x140(%rsp)
  7626b8:	movq   $0xffffffffffffffff,0xb0(%rsp)
  7626c4:	movq   $0x0,0xc8(%rsp)
  7626d0:	movq   $0x0,0xd8(%rsp)
  7626dc:	lea    -0x692e2e(%rip),%rsi        # cf8b5 <GCC_except_table0+0xd4e9>
  7626e3:	lea    0xb0(%rsp),%rdi
  7626eb:	mov    $0xc,%edx
  7626f0:	call   75c940 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  7626f5:	test   %rax,%rax
  7626f8:	jne    762f0f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x21ff>
  7626fe:	lea    -0x692e44(%rip),%rsi        # cf8c1 <GCC_except_table0+0xd4f5>
  762705:	lea    0xb0(%rsp),%rdi
  76270d:	mov    $0xc,%edx
  762712:	mov    %r15,%rcx
  762715:	call   75c940 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  76271a:	test   %rax,%rax
  76271d:	jne    762f0f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x21ff>
  762723:	lea    -0x692e5d(%rip),%rsi        # cf8cd <GCC_except_table0+0xd501>
  76272a:	lea    0xb0(%rsp),%rdi
  762732:	mov    $0x11,%edx
  762737:	mov    %r14,%rcx
  76273a:	call   75c940 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  76273f:	test   %rax,%rax
  762742:	jne    762f0f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x21ff>
  762748:	lea    -0x692e71(%rip),%rsi        # cf8de <GCC_except_table0+0xd512>
  76274f:	lea    0xb0(%rsp),%rdi
  762757:	mov    $0xc,%edx
  76275c:	mov    %rbx,%rcx
  76275f:	call   75c940 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  762764:	test   %rax,%rax
  762767:	jne    762f0f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x21ff>
  76276d:	lea    -0x692e8a(%rip),%rsi        # cf8ea <GCC_except_table0+0xd51e>
  762774:	lea    0xb0(%rsp),%rdi
  76277c:	mov    $0x14,%edx
  762781:	mov    %rbp,%rcx
  762784:	call   75c940 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  762789:	test   %rax,%rax
  76278c:	jne    762f0f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x21ff>
  762792:	lea    -0x692e9b(%rip),%rsi        # cf8fe <GCC_except_table0+0xd532>
  762799:	lea    0xb0(%rsp),%rdi
  7627a1:	mov    $0xf,%edx
  7627a6:	mov    %r13,%rcx
  7627a9:	call   75c940 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  7627ae:	test   %rax,%rax
  7627b1:	jne    762f0f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x21ff>
  7627b7:	lea    -0x692eb1(%rip),%rsi        # cf90d <GCC_except_table0+0xd541>
  7627be:	lea    0xb0(%rsp),%rdi
  7627c6:	mov    $0x11,%edx
  7627cb:	mov    0x130(%rsp),%rcx
  7627d3:	call   75c940 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  7627d8:	test   %rax,%rax
  7627db:	jne    762f0f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x21ff>
  7627e1:	lea    -0x692eca(%rip),%rsi        # cf91e <GCC_except_table0+0xd552>
  7627e8:	lea    0xb0(%rsp),%rdi
  7627f0:	mov    $0xb,%edx
  7627f5:	mov    0x148(%rsp),%rcx
  7627fd:	call   75c940 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  762802:	test   %rax,%rax
  762805:	jne    762f0f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x21ff>
  76280b:	lea    -0x692ee9(%rip),%rsi        # cf929 <GCC_except_table0+0xd55d>
  762812:	lea    0xb0(%rsp),%rdi
  76281a:	mov    $0xd,%edx
  76281f:	mov    0xa0(%rsp),%rcx
  762827:	call   75c940 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  76282c:	test   %rax,%rax
  76282f:	jne    762f0f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x21ff>
  762835:	lea    -0x692f06(%rip),%rsi        # cf936 <GCC_except_table0+0xd56a>
  76283c:	lea    0xb0(%rsp),%rdi
  762844:	mov    $0xd,%edx
  762849:	mov    0x138(%rsp),%rcx
  762851:	call   75c940 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  762856:	test   %rax,%rax
  762859:	jne    762f0f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x21ff>
  76285f:	lea    -0x692f23(%rip),%rsi        # cf943 <GCC_except_table0+0xd577>
  762866:	lea    0xb0(%rsp),%rdi
  76286e:	mov    $0xc,%edx
  762873:	mov    0x1f0(%rsp),%rcx
  76287b:	call   75c940 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  762880:	test   %rax,%rax
  762883:	jne    762f0f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x21ff>
  762889:	lea    -0x692f41(%rip),%rsi        # cf94f <GCC_except_table0+0xd583>
  762890:	lea    0xb0(%rsp),%rdi
  762898:	mov    $0xd,%edx
  76289d:	mov    0x108(%rsp),%rcx
  7628a5:	call   75c940 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  7628aa:	test   %rax,%rax
  7628ad:	jne    762f0f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x21ff>
  7628b3:	lea    -0x692f5e(%rip),%rsi        # cf95c <GCC_except_table0+0xd590>
  7628ba:	lea    0xb0(%rsp),%rdi
  7628c2:	mov    $0xe,%edx
  7628c7:	mov    0x140(%rsp),%rcx
  7628cf:	call   75c940 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  7628d4:	test   %rax,%rax
  7628d7:	jne    762f0f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x21ff>
  7628dd:	movups 0xb0(%rsp),%xmm0
  7628e5:	movups 0xc0(%rsp),%xmm1
  7628ed:	movups 0xd0(%rsp),%xmm2
  7628f5:	movaps %xmm2,0x40(%rsp)
  7628fa:	movaps %xmm1,0x30(%rsp)
  7628ff:	movaps %xmm0,0x20(%rsp)
  762904:	lea    0x200(%rsp),%rdi
  76290c:	lea    0x20(%rsp),%rsi
  762911:	call   *0x357a59(%rip)        # aba370 <_DYNAMIC+0x500>
  762917:	cmpb   $0xff,0x200(%rsp)
  76291f:	je     7631c6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x24b6>
  762925:	movups 0x200(%rsp),%xmm0
  76292d:	movups 0x210(%rsp),%xmm1
  762935:	mov    0x2d8(%rsp),%rax
  76293d:	movups %xmm1,0x28(%rax)
  762941:	movups %xmm0,0x18(%rax)
  762945:	mov    %r12,0x10(%rax)
  762949:	mov    0x110(%rsp),%rcx
  762951:	mov    %rcx,0x8(%rax)
  762955:	mov    0xa8(%rsp),%rcx
  76295d:	mov    %rcx,(%rax)
  762960:	mov    0x120(%rsp),%rsi
  762968:	test   %rsi,%rsi
  76296b:	mov    0x10(%rsp),%rdi
  762970:	je     762981 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1c71>
  762972:	shl    $0x4,%rsi
  762976:	mov    $0x4,%edx
  76297b:	call   *0x35772f(%rip)        # aba0b0 <_DYNAMIC+0x240>
  762981:	mov    0x8(%rsp),%r14
  762986:	test   %r14,%r14
  762989:	je     7629a6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1c96>
  76298b:	mov    %r14,%rdi
  76298e:	call   747fc0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui7runtime7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEEB1h_>
  762993:	mov    $0x770,%esi
  762998:	mov    $0x8,%edx
  76299d:	mov    %r14,%rdi
  7629a0:	call   *0x35770a(%rip)        # aba0b0 <_DYNAMIC+0x240>
  7629a6:	mov    0x18(%rsp),%rsi
  7629ab:	test   %rsi,%rsi
  7629ae:	je     7629c7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1cb7>
  7629b0:	shl    $0x2,%rsi
  7629b4:	mov    $0x4,%edx
  7629b9:	mov    0x118(%rsp),%rdi
  7629c1:	call   *0x3576e9(%rip)        # aba0b0 <_DYNAMIC+0x240>
  7629c7:	mov    0x1d0(%rsp),%rax
  7629cf:	test   %rax,%rax
  7629d2:	je     7629eb <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1cdb>
  7629d4:	imul   $0x38,%rax,%rsi
  7629d8:	mov    $0x8,%edx
  7629dd:	mov    0x128(%rsp),%rdi
  7629e5:	call   *0x3576c5(%rip)        # aba0b0 <_DYNAMIC+0x240>
  7629eb:	lea    0x320(%rsp),%rdi
  7629f3:	call   74ccb0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text10TextLayoutECs9C2G9YFESsD_29canonical_text_public_control>
  7629f8:	mov    0x168(%rsp),%rax
  762a00:	lock decq (%rax)
  762a04:	jne    762a16 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1d06>
  762a06:	xor    %ebp,%ebp
  762a08:	lea    0x168(%rsp),%rdi
  762a10:	call   *0x35778a(%rip)        # aba1a0 <_DYNAMIC+0x330>
  762a16:	mov    0x2a0(%rsp),%rsi
  762a1e:	test   %rsi,%rsi
  762a21:	je     762a36 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1d26>
  762a23:	mov    0x2a8(%rsp),%rdi
  762a2b:	mov    $0x1,%edx
  762a30:	call   *0x35767a(%rip)        # aba0b0 <_DYNAMIC+0x240>
  762a36:	mov    0x150(%rsp),%rsi
  762a3e:	test   %rsi,%rsi
  762a41:	je     762a56 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1d46>
  762a43:	mov    0x158(%rsp),%rdi
  762a4b:	mov    $0x1,%edx
  762a50:	call   *0x35765a(%rip)        # aba0b0 <_DYNAMIC+0x240>
  762a56:	add    $0x358,%rsp
  762a5d:	pop    %rbx
  762a5e:	pop    %r12
  762a60:	pop    %r13
  762a62:	pop    %r14
  762a64:	pop    %r15
  762a66:	pop    %rbp
  762a67:	ret
  762a68:	shl    $0x6,%eax
  762a6b:	or     %r8d,%eax
  762a6e:	cmp    $0x80,%eax
  762a73:	jae    762c03 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1ef3>
  762a79:	jmp    760db3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xa3>
  762a7e:	lea    -0x692e2c(%rip),%rdi        # cfc59 <GCC_except_table0+0xd88d>
  762a85:	lea    0x339234(%rip),%rdx        # a9bcc0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2378>
  762a8c:	mov    $0x13,%esi
  762a91:	call   *0x357651(%rip)        # aba0e8 <_DYNAMIC+0x278>
  762a97:	jmp    7631ac <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x249c>
  762a9c:	testb  $0x1,0x148(%rsp)
  762aa4:	lea    0x150(%rsp),%rax
  762aac:	lea    0x2a0(%rsp),%rcx
  762ab4:	cmove  %rcx,%rax
  762ab8:	mov    %rax,0x200(%rsp)
  762ac0:	mov    0x8(%rsp),%rsi
  762ac5:	test   %rsi,%rsi
  762ac8:	je     763166 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2456>
  762ace:	cmpb   $0x0,0x76e(%rsi)
  762ad5:	jne    76316d <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x245d>
  762adb:	cmpb   $0x1,0x76c(%rsi)
  762ae2:	jne    763174 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2464>
  762ae8:	lea    0x20(%rsp),%rdi
  762aed:	call   73dde0 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime5queryNtB3_7Context3newNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEBX_>
  762af2:	mov    0x58(%rsp),%rbx
  762af7:	test   %rbx,%rbx
  762afa:	je     7625c0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x18b0>
  762b00:	mov    0x50(%rsp),%rbp
  762b05:	add    $0x3d,%rbp
  762b09:	xor    %r14d,%r14d
  762b0c:	mov    %r12,%r13
  762b0f:	jmp    762b47 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1e37>
  762b11:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  762b20:	mov    %rax,%r12
  762b23:	xor    %r13,%r12
  762b26:	movabs $0x100000001b3,%rax
  762b30:	imul   %rax,%r12
  762b34:	mov    %r12,%r13
  762b37:	inc    %r14
  762b3a:	add    $0x40,%rbp
  762b3e:	cmp    %r14,%rbx
  762b41:	je     7625c0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x18b0>
  762b47:	cmpb   $0x4,0x0(%rbp)
  762b4b:	jne    762b37 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1e27>
  762b4d:	mov    -0x15(%rbp),%rdi
  762b51:	test   %rdi,%rdi
  762b54:	je     763076 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2366>
  762b5a:	mov    (%rdi),%rdx
  762b5d:	shr    $1,%rdx
  762b60:	add    $0x10,%rdi
  762b64:	mov    0x148(%rsp),%rcx
  762b6c:	test   $0x1,%cl
  762b6f:	mov    %rdi,0xb0(%rsp)
  762b77:	mov    %rdx,0xb8(%rsp)
  762b7f:	lea    0x150(%rsp),%rsi
  762b87:	mov    %rsi,%rax
  762b8a:	lea    0x2a0(%rsp),%r8
  762b92:	cmove  %r8,%rax
  762b96:	cmp    0x10(%rax),%rdx
  762b9a:	jne    762c68 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1f58>
  762ba0:	test   $0x1,%cl
  762ba3:	mov    %rsi,%rax
  762ba6:	cmove  %r8,%rax
  762baa:	mov    0x8(%rax),%rsi
  762bae:	call   *0x3577c4(%rip)        # aba378 <bcmp@GLIBC_2.2.5>
  762bb4:	test   %eax,%eax
  762bb6:	jne    762c68 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1f58>
  762bbc:	lea    0xb0(%rsp),%rdi
  762bc4:	lea    0x20(%rsp),%rsi
  762bc9:	mov    %r14,%rdx
  762bcc:	call   *0x3576e6(%rip)        # aba2b8 <_DYNAMIC+0x448>
  762bd2:	cmpq   $0x0,0xb0(%rsp)
  762bdb:	je     762d2a <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x201a>
  762be1:	mov    0xc0(%rsp),%rdi
  762be9:	call   760260 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript>
  762bee:	jmp    762b20 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1e10>
  762bf3:	shl    $0xc,%eax
  762bf6:	or     %edx,%eax
  762bf8:	cmp    $0x80,%eax
  762bfd:	jb     760db3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xa3>
  762c03:	mov    $0x2,%esi
  762c08:	cmp    $0x800,%eax
  762c0d:	jb     760db3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xa3>
  762c13:	cmp    $0x10000,%eax
  762c18:	mov    $0x4,%esi
  762c1d:	sbb    $0x0,%rsi
  762c21:	jmp    760db3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xa3>
  762c26:	lea    0x33735b(%rip),%rdi        # a99f88 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x640>
  762c2d:	jmp    762c5d <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1f4d>
  762c2f:	lea    -0x692fdd(%rip),%rdi        # cfc59 <GCC_except_table0+0xd88d>
  762c36:	lea    0x339083(%rip),%rdx        # a9bcc0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2378>
  762c3d:	mov    $0x13,%esi
  762c42:	call   *0x3574a0(%rip)        # aba0e8 <_DYNAMIC+0x278>
  762c48:	jmp    7631ac <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x249c>
  762c4d:	lea    0x33734c(%rip),%rdi        # a99fa0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x658>
  762c54:	jmp    762c5d <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1f4d>
  762c56:	lea    0x33735b(%rip),%rdi        # a99fb8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x670>
  762c5d:	call   *0x35750d(%rip)        # aba170 <_DYNAMIC+0x300>
  762c63:	jmp    7631ac <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x249c>
  762c68:	lea    0xb0(%rsp),%rdi
  762c70:	lea    0x200(%rsp),%rsi
  762c78:	call   74f5fa <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedReRNtNtCscdodAO9FK5_5alloc6string6StringECs9C2G9YFESsD_29canonical_text_public_control>
  762c7d:	jmp    7631ac <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x249c>
  762c82:	lea    -0x693157(%rip),%rdi        # cfb32 <GCC_except_table0+0xd766>
  762c89:	lea    0x337bd8(%rip),%rdx        # a9a868 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xf20>
  762c90:	mov    $0x1b,%esi
  762c95:	call   *0x35748d(%rip)        # aba128 <_DYNAMIC+0x2b8>
  762c9b:	mov    0x24(%rsp),%rax
  762ca0:	mov    %rax,0xb0(%rsp)
  762ca8:	lea    -0x69304d(%rip),%rdi        # cfc62 <GCC_except_table0+0xd896>
  762caf:	lea    0x337eea(%rip),%rcx        # a9aba0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1258>
  762cb6:	lea    0x337bdb(%rip),%r8        # a9a898 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xf50>
  762cbd:	lea    0xb0(%rsp),%rdx
  762cc5:	mov    $0x2b,%esi
  762cca:	call   *0x3574b0(%rip)        # aba180 <_DYNAMIC+0x310>
  762cd0:	jmp    7631ac <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x249c>
  762cd5:	mov    0x28(%rsp),%rax
  762cda:	mov    %rax,0x200(%rsp)
  762ce2:	lea    -0x693087(%rip),%rdi        # cfc62 <GCC_except_table0+0xd896>
  762ce9:	lea    0x337eb0(%rip),%rcx        # a9aba0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1258>
  762cf0:	lea    0x337bb9(%rip),%r8        # a9a8b0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xf68>
  762cf7:	lea    0x200(%rsp),%rdx
  762cff:	mov    $0x2b,%esi
  762d04:	call   *0x357476(%rip)        # aba180 <_DYNAMIC+0x310>
  762d0a:	jmp    7631ac <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x249c>
  762d0f:	lea    0x337bb2(%rip),%rdi        # a9a8c8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xf80>
  762d16:	call   *0x357454(%rip)        # aba170 <_DYNAMIC+0x300>
  762d1c:	jmp    7631ac <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x249c>
  762d21:	lea    0x337bb8(%rip),%rdi        # a9a8e0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xf98>
  762d28:	jmp    762d31 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2021>
  762d2a:	lea    0x33723f(%rip),%rdi        # a99f70 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x628>
  762d31:	call   *0x357439(%rip)        # aba170 <_DYNAMIC+0x300>
  762d37:	jmp    7631ac <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x249c>
  762d3c:	lea    0x338c0d(%rip),%rcx        # a9b950 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2008>
  762d43:	xor    %edi,%edi
  762d45:	call   *0x3573b5(%rip)        # aba100 <_DYNAMIC+0x290>
  762d4b:	jmp    7631ac <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x249c>
  762d50:	lea    0x150(%rsp),%rdi
  762d58:	mov    $0x1,%edx
  762d5d:	mov    $0x1,%ecx
  762d62:	mov    $0x1,%r8d
  762d68:	mov    %rbx,%rsi
  762d6b:	call   75b3b0 <_RINvNvMs2_NtCscdodAO9FK5_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs9C2G9YFESsD_29canonical_text_public_control>
  762d70:	jmp    760e45 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x135>
  762d75:	lea    -0x69e94b(%rip),%rdi        # c4431 <GCC_except_table0+0x2065>
  762d7c:	lea    0x337afd(%rip),%rdx        # a9a880 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xf38>
  762d83:	mov    $0x57,%esi
  762d88:	call   *0x35735a(%rip)        # aba0e8 <_DYNAMIC+0x278>
  762d8e:	jmp    7631ac <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x249c>
  762d93:	lea    -0x69efaa(%rip),%rdx        # c3df0 <GCC_except_table0+0x1a24>
  762d9a:	lea    0x337c6f(%rip),%r9        # a9aa10 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x10c8>
  762da1:	lea    0x20(%rsp),%rsi
  762da6:	xor    %edi,%edi
  762da8:	xor    %ecx,%ecx
  762daa:	call   *0x3575d0(%rip)        # aba380 <_DYNAMIC+0x510>
  762db0:	jmp    7631ac <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x249c>
  762db5:	mov    0xe0(%rsp),%rax
  762dbd:	mov    %rax,0x50(%rsp)
  762dc2:	movups 0xb0(%rsp),%xmm0
  762dca:	movups 0xc0(%rsp),%xmm1
  762dd2:	movups 0xd0(%rsp),%xmm2
  762dda:	movaps %xmm2,0x40(%rsp)
  762ddf:	movaps %xmm1,0x30(%rsp)
  762de4:	movaps %xmm0,0x20(%rsp)
  762de9:	lea    -0x69318e(%rip),%rdi        # cfc62 <GCC_except_table0+0xd896>
  762df0:	lea    0x337d69(%rip),%rcx        # a9ab60 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1218>
  762df7:	lea    0x337b22(%rip),%r8        # a9a920 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xfd8>
  762dfe:	lea    0x20(%rsp),%rdx
  762e03:	mov    $0x2b,%esi
  762e08:	call   *0x357372(%rip)        # aba180 <_DYNAMIC+0x310>
  762e0e:	jmp    7631ac <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x249c>
  762e13:	mov    0xe0(%rsp),%rax
  762e1b:	mov    %rax,0x50(%rsp)
  762e20:	movups 0xb0(%rsp),%xmm0
  762e28:	movups 0xc0(%rsp),%xmm1
  762e30:	movups 0xd0(%rsp),%xmm2
  762e38:	movaps %xmm2,0x40(%rsp)
  762e3d:	movaps %xmm1,0x30(%rsp)
  762e42:	movaps %xmm0,0x20(%rsp)
  762e47:	lea    -0x6931ec(%rip),%rdi        # cfc62 <GCC_except_table0+0xd896>
  762e4e:	lea    0x337d0b(%rip),%rcx        # a9ab60 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1218>
  762e55:	lea    0x337adc(%rip),%r8        # a9a938 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xff0>
  762e5c:	lea    0x20(%rsp),%rdx
  762e61:	mov    $0x2b,%esi
  762e66:	call   *0x357314(%rip)        # aba180 <_DYNAMIC+0x310>
  762e6c:	jmp    7631ac <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x249c>
  762e71:	mov    0xe0(%rsp),%rax
  762e79:	mov    %rax,0x50(%rsp)
  762e7e:	movups 0xb0(%rsp),%xmm0
  762e86:	movups 0xc0(%rsp),%xmm1
  762e8e:	movups 0xd0(%rsp),%xmm2
  762e96:	movaps %xmm2,0x40(%rsp)
  762e9b:	movaps %xmm1,0x30(%rsp)
  762ea0:	movaps %xmm0,0x20(%rsp)
  762ea5:	lea    -0x69324a(%rip),%rdi        # cfc62 <GCC_except_table0+0xd896>
  762eac:	lea    0x337cad(%rip),%rcx        # a9ab60 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1218>
  762eb3:	lea    0x337ac6(%rip),%r8        # a9a980 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1038>
  762eba:	lea    0x20(%rsp),%rdx
  762ebf:	mov    $0x2b,%esi
  762ec4:	call   *0x3572b6(%rip)        # aba180 <_DYNAMIC+0x310>
  762eca:	jmp    7631ac <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x249c>
  762ecf:	lea    0x2f0(%rsp),%rdi
  762ed7:	call   74f5bd <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedReBM_ECs9C2G9YFESsD_29canonical_text_public_control>
  762edc:	jmp    7631ac <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x249c>
  762ee1:	lea    0x8(%rcx),%rdi
  762ee5:	lea    0x18(%rcx),%rsi
  762ee9:	lea    0x337b08(%rip),%rdx        # a9a9f8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x10b0>
  762ef0:	call   74f553 <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextPositionBM_ECs9C2G9YFESsD_29canonical_text_public_control>
  762ef5:	jmp    7631ac <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x249c>
  762efa:	lea    0x336f67(%rip),%rdx        # a99e68 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x520>
  762f01:	mov    %rbp,%rdi
  762f04:	call   *0x3571d6(%rip)        # aba0e0 <_DYNAMIC+0x270>
  762f0a:	jmp    7631ac <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x249c>
  762f0f:	mov    %rax,%rbx
  762f12:	mov    %rax,0x208(%rsp)
  762f1a:	movb   $0xff,0x200(%rsp)
  762f22:	mov    0xc8(%rsp),%rcx
  762f2a:	test   %rcx,%rcx
  762f2d:	jne    762f35 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2225>
  762f2f:	xor    %ecx,%ecx
  762f31:	xor    %eax,%eax
  762f33:	jmp    762f70 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2260>
  762f35:	mov    0xd0(%rsp),%rdx
  762f3d:	mov    0xd8(%rsp),%rax
  762f45:	movq   $0x0,0x28(%rsp)
  762f4e:	mov    %rcx,0x30(%rsp)
  762f53:	mov    %rdx,0x38(%rsp)
  762f58:	movq   $0x0,0x48(%rsp)
  762f61:	mov    %rcx,0x50(%rsp)
  762f66:	mov    %rdx,0x58(%rsp)
  762f6b:	mov    $0x1,%ecx
  762f70:	mov    %rcx,0x20(%rsp)
  762f75:	mov    %rcx,0x40(%rsp)
  762f7a:	mov    %rax,0x60(%rsp)
  762f7f:	lea    0x20(%rsp),%rdi
  762f84:	call   74ad50 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtCscdodAO9FK5_5alloc11collections5btree3map8IntoIterNtNtBK_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueEECs9C2G9YFESsD_29canonical_text_public_control>
  762f89:	mov    0xb0(%rsp),%rsi
  762f91:	test   %rsi,%rsi
  762f94:	jg     7631ae <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x249e>
  762f9a:	mov    %rbx,0x20(%rsp)
  762f9f:	lea    -0x693344(%rip),%rdi        # cfc62 <GCC_except_table0+0xd896>
  762fa6:	lea    0x337bd3(%rip),%rcx        # a9ab80 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1238>
  762fad:	lea    0x3379fc(%rip),%r8        # a9a9b0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1068>
  762fb4:	lea    0x20(%rsp),%rdx
  762fb9:	mov    $0x2b,%esi
  762fbe:	call   *0x3571bc(%rip)        # aba180 <_DYNAMIC+0x310>
  762fc4:	jmp    7631ac <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x249c>
  762fc9:	lea    0x337a10(%rip),%rdx        # a9a9e0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1098>
  762fd0:	mov    %rax,%rdi
  762fd3:	mov    0xa0(%rsp),%rsi
  762fdb:	call   *0x3570ff(%rip)        # aba0e0 <_DYNAMIC+0x270>
  762fe1:	jmp    7631ac <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x249c>
  762fe6:	mov    $0xe,%eax
  762feb:	jmp    762ff2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x22e2>
  762fed:	mov    $0x12,%eax
  762ff2:	mov    %rax,0x10(%rsp)
  762ff7:	mov    0x10(%rsp),%rax
  762ffc:	mov    %rax,0x20(%rsp)
  763001:	lea    -0x693627(%rip),%rdi        # cf9e1 <GCC_except_table0+0xd615>
  763008:	lea    0x337b51(%rip),%rcx        # a9ab60 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1218>
  76300f:	lea    0x3374b2(%rip),%r8        # a9a4c8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xb80>
  763016:	lea    0x20(%rsp),%rdx
  76301b:	mov    $0x2a,%esi
  763020:	call   *0x35715a(%rip)        # aba180 <_DYNAMIC+0x310>
  763026:	jmp    7631ac <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x249c>
  76302b:	mov    $0xd,%eax
  763030:	jmp    76303e <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x232e>
  763032:	mov    $0xe,%eax
  763037:	jmp    76303e <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x232e>
  763039:	mov    $0x12,%eax
  76303e:	mov    %rax,0x20(%rsp)
  763043:	movq   $0x0,0x28(%rsp)
  76304c:	lea    -0x6933f1(%rip),%rdi        # cfc62 <GCC_except_table0+0xd896>
  763053:	lea    0x337b06(%rip),%rcx        # a9ab60 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1218>
  76305a:	lea    0x337a87(%rip),%r8        # a9aae8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x11a0>
  763061:	lea    0x20(%rsp),%rdx
  763066:	mov    $0x2b,%esi
  76306b:	call   *0x35710f(%rip)        # aba180 <_DYNAMIC+0x310>
  763071:	jmp    7631ac <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x249c>
  763076:	lea    0x336ec3(%rip),%rdi        # a99f40 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x5f8>
  76307d:	jmp    762d31 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2021>
  763082:	movq   $0xd,0x20(%rsp)
  76308b:	movq   $0x0,0x28(%rsp)
  763094:	lea    -0x693541(%rip),%rdi        # cfb5a <GCC_except_table0+0xd78e>
  76309b:	lea    0x337abe(%rip),%rcx        # a9ab60 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1218>
  7630a2:	lea    0x3378ef(%rip),%r8        # a9a998 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1050>
  7630a9:	lea    0x20(%rsp),%rdx
  7630ae:	mov    $0x24,%esi
  7630b3:	call   *0x3570c7(%rip)        # aba180 <_DYNAMIC+0x310>
  7630b9:	jmp    7631ac <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x249c>
  7630be:	mov    $0x8,%edi
  7630c3:	mov    $0xe0,%esi
  7630c8:	call   *0x357092(%rip)        # aba160 <_DYNAMIC+0x2f0>
  7630ce:	jmp    7631ac <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x249c>
  7630d3:	mov    $0x4,%edi
  7630d8:	mov    %rbx,%rsi
  7630db:	call   *0x35707f(%rip)        # aba160 <_DYNAMIC+0x2f0>
  7630e1:	jmp    7631ac <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x249c>
  7630e6:	movq   $0xd,0xb0(%rsp)
  7630f2:	movq   $0x0,0xb8(%rsp)
  7630fe:	mov    0xe0(%rsp),%rax
  763106:	mov    %rax,0x50(%rsp)
  76310b:	mov    0xb0(%rsp),%rax
  763113:	mov    0xb8(%rsp),%rcx
  76311b:	movups 0xc0(%rsp),%xmm0
  763123:	movups 0xd0(%rsp),%xmm1
  76312b:	movaps %xmm1,0x40(%rsp)
  763130:	movaps %xmm0,0x30(%rsp)
  763135:	mov    %rax,0x20(%rsp)
  76313a:	mov    %rcx,0x28(%rsp)
  76313f:	lea    -0x6934e4(%rip),%rdi        # cfc62 <GCC_except_table0+0xd896>
  763146:	lea    0x337a13(%rip),%rcx        # a9ab60 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1218>
  76314d:	lea    0x3377b4(%rip),%r8        # a9a908 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xfc0>
  763154:	lea    0x20(%rsp),%rdx
  763159:	mov    $0x2b,%esi
  76315e:	call   *0x35701c(%rip)        # aba180 <_DYNAMIC+0x310>
  763164:	jmp    7631ac <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x249c>
  763166:	mov    $0xd,%eax
  76316b:	jmp    763179 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2469>
  76316d:	mov    $0xe,%eax
  763172:	jmp    763179 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2469>
  763174:	mov    $0x12,%eax
  763179:	mov    %rax,0x20(%rsp)
  76317e:	movq   $0x0,0x28(%rsp)
  763187:	lea    -0x69352c(%rip),%rdi        # cfc62 <GCC_except_table0+0xd896>
  76318e:	lea    0x3379cb(%rip),%rcx        # a9ab60 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1218>
  763195:	lea    0x3377cc(%rip),%r8        # a9a968 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1020>
  76319c:	lea    0x20(%rsp),%rdx
  7631a1:	mov    $0x2b,%esi
  7631a6:	call   *0x356fd4(%rip)        # aba180 <_DYNAMIC+0x310>
  7631ac:	ud2
  7631ae:	mov    0xb8(%rsp),%rdi
  7631b6:	mov    $0x1,%edx
  7631bb:	call   *0x356eef(%rip)        # aba0b0 <_DYNAMIC+0x240>
  7631c1:	jmp    762f9a <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x228a>
  7631c6:	mov    0x208(%rsp),%rbx
  7631ce:	jmp    762f9a <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x228a>
  7631d3:	jmp    763323 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2613>
  7631d8:	jmp    7632c7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x25b7>
  7631dd:	jmp    7632c7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x25b7>
  7631e2:	mov    %rax,%rbx
  7631e5:	jmp    7633a9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2699>
  7631ea:	mov    %rax,%rbx
  7631ed:	mov    $0x1,%bpl
  7631f0:	mov    0x1d0(%rsp),%rax
  7631f8:	test   %rax,%rax
  7631fb:	jne    7633fd <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x26ed>
  763201:	jmp    763414 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2704>
  763206:	mov    %rax,%rbx
  763209:	xor    %ebp,%ebp
  76320b:	jmp    763421 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2711>
  763210:	jmp    7632c7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x25b7>
  763215:	jmp    7632c7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x25b7>
  76321a:	jmp    7632bb <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x25ab>
  76321f:	mov    %rax,%rbx
  763222:	jmp    7633bc <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x26ac>
  763227:	mov    %rax,%rbx
  76322a:	jmp    763482 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2772>
  76322f:	jmp    763373 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2663>
  763234:	jmp    763323 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2613>
  763239:	mov    %rax,%rbx
  76323c:	mov    0xb0(%rsp),%rsi
  763244:	test   %rsi,%rsi
  763247:	jle    763376 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2666>
  76324d:	mov    0xb8(%rsp),%rdi
  763255:	mov    $0x1,%edx
  76325a:	call   *0x356e50(%rip)        # aba0b0 <_DYNAMIC+0x240>
  763260:	jmp    763376 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2666>
  763265:	mov    %rax,%rbx
  763268:	lea    0x20(%rsp),%rdi
  76326d:	call   74ca70 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5error5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  763272:	jmp    763376 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2666>
  763277:	call   *0x356e5b(%rip)        # aba0d8 <_DYNAMIC+0x268>
  76327d:	mov    %rax,%rbx
  763280:	lea    0x20(%rsp),%rdi
  763285:	call   74d7d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  76328a:	jmp    763353 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2643>
  76328f:	mov    %rax,%rbx
  763292:	lea    0xb0(%rsp),%rdi
  76329a:	call   74e1f0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCscl5MXVnO7Zx_10serde_json5value3ser12SerializeMapECs9C2G9YFESsD_29canonical_text_public_control>
  76329f:	jmp    763376 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2666>
  7632a4:	call   *0x356e2e(%rip)        # aba0d8 <_DYNAMIC+0x268>
  7632aa:	jmp    763373 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2663>
  7632af:	jmp    763350 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2640>
  7632b4:	jmp    763350 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2640>
  7632b9:	jmp    763318 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2608>
  7632bb:	mov    %rax,%rbx
  7632be:	jmp    763397 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2687>
  7632c3:	jmp    7632c7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x25b7>
  7632c5:	jmp    7632c7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x25b7>
  7632c7:	mov    %rax,%rbx
  7632ca:	lea    0x20(%rsp),%rdi
  7632cf:	call   74d7d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  7632d4:	jmp    763376 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2666>
  7632d9:	mov    %rax,%rbx
  7632dc:	lea    0x20(%rsp),%rdi
  7632e1:	call   74d7d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  7632e6:	jmp    763397 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2687>
  7632eb:	jmp    763350 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2640>
  7632ed:	mov    %rax,%rbx
  7632f0:	mov    $0x1,%bpl
  7632f3:	jmp    76345d <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x274d>
  7632f8:	mov    %rax,%rbx
  7632fb:	mov    0xb8(%rsp),%rdi
  763303:	call   74cd40 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text10TextShaperECs9C2G9YFESsD_29canonical_text_public_control>
  763308:	mov    $0x1,%bpl
  76330b:	jmp    763421 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2711>
  763310:	mov    %rax,%rbx
  763313:	jmp    76343d <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x272d>
  763318:	mov    %rax,%rbx
  76331b:	mov    $0x1,%bpl
  76331e:	jmp    763414 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2704>
  763323:	mov    %rax,%rbx
  763326:	mov    0x170(%rsp),%rax
  76332e:	mov    $0x1,%bpl
  763331:	test   %rax,%rax
  763334:	je     763414 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2704>
  76333a:	mov    0x178(%rsp),%rdi
  763342:	imul   $0x38,%rax,%rsi
  763346:	mov    $0x8,%edx
  76334b:	jmp    76340e <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x26fe>
  763350:	mov    %rax,%rbx
  763353:	mov    0x1d8(%rsp),%rsi
  76335b:	test   %rsi,%rsi
  76335e:	je     763397 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2687>
  763360:	mov    0x1e0(%rsp),%rdi
  763368:	shl    $0x4,%rsi
  76336c:	mov    $0x4,%edx
  763371:	jmp    763391 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2681>
  763373:	mov    %rax,%rbx
  763376:	mov    0x120(%rsp),%rsi
  76337e:	test   %rsi,%rsi
  763381:	je     763397 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2687>
  763383:	shl    $0x4,%rsi
  763387:	mov    $0x4,%edx
  76338c:	mov    0x10(%rsp),%rdi
  763391:	call   *0x356d19(%rip)        # aba0b0 <_DYNAMIC+0x240>
  763397:	mov    0x8(%rsp),%r14
  76339c:	test   %r14,%r14
  76339f:	je     7633bc <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x26ac>
  7633a1:	mov    %r14,%rdi
  7633a4:	call   747fc0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui7runtime7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEEB1h_>
  7633a9:	mov    $0x770,%esi
  7633ae:	mov    $0x8,%edx
  7633b3:	mov    %r14,%rdi
  7633b6:	call   *0x356cf4(%rip)        # aba0b0 <_DYNAMIC+0x240>
  7633bc:	mov    0x18(%rsp),%rsi
  7633c1:	test   %rsi,%rsi
  7633c4:	jne    7633d7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x26c7>
  7633c6:	xor    %ebp,%ebp
  7633c8:	mov    0x1d0(%rsp),%rax
  7633d0:	test   %rax,%rax
  7633d3:	jne    7633fd <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x26ed>
  7633d5:	jmp    763414 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2704>
  7633d7:	shl    $0x2,%rsi
  7633db:	mov    $0x4,%edx
  7633e0:	mov    0x118(%rsp),%rdi
  7633e8:	call   *0x356cc2(%rip)        # aba0b0 <_DYNAMIC+0x240>
  7633ee:	xor    %ebp,%ebp
  7633f0:	mov    0x1d0(%rsp),%rax
  7633f8:	test   %rax,%rax
  7633fb:	je     763414 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2704>
  7633fd:	imul   $0x38,%rax,%rsi
  763401:	mov    $0x8,%edx
  763406:	mov    0x128(%rsp),%rdi
  76340e:	call   *0x356c9c(%rip)        # aba0b0 <_DYNAMIC+0x240>
  763414:	lea    0x320(%rsp),%rdi
  76341c:	call   74ccb0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text10TextLayoutECs9C2G9YFESsD_29canonical_text_public_control>
  763421:	mov    0x168(%rsp),%rax
  763429:	lock decq (%rax)
  76342d:	jne    76343d <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x272d>
  76342f:	lea    0x168(%rsp),%rdi
  763437:	call   *0x356d63(%rip)        # aba1a0 <_DYNAMIC+0x330>
  76343d:	mov    0x2a0(%rsp),%rsi
  763445:	test   %rsi,%rsi
  763448:	je     76345d <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x274d>
  76344a:	mov    0x2a8(%rsp),%rdi
  763452:	mov    $0x1,%edx
  763457:	call   *0x356c53(%rip)        # aba0b0 <_DYNAMIC+0x240>
  76345d:	mov    0x150(%rsp),%rsi
  763465:	test   %rsi,%rsi
  763468:	je     76347d <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x276d>
  76346a:	mov    0x158(%rsp),%rdi
  763472:	mov    $0x1,%edx
  763477:	call   *0x356c33(%rip)        # aba0b0 <_DYNAMIC+0x240>
  76347d:	test   %bpl,%bpl
  763480:	je     76348f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x277f>
  763482:	mov    0x288(%rsp),%rsi
  76348a:	test   %rsi,%rsi
  76348d:	jne    763497 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2787>
  76348f:	mov    %rbx,%rdi
  763492:	call   a98590 <_Unwind_Resume@plt>
  763497:	mov    0x290(%rsp),%rdi
  76349f:	mov    $0x1,%edx
  7634a4:	call   *0x356c06(%rip)        # aba0b0 <_DYNAMIC+0x240>
  7634aa:	mov    %rbx,%rdi
  7634ad:	call   a98590 <_Unwind_Resume@plt>
  7634b2:	mov    $0x770,%esi
  7634b7:	mov    $0x8,%edx
  7634bc:	mov    %r14,%rdi
  7634bf:	call   *0x356beb(%rip)        # aba0b0 <_DYNAMIC+0x240>
  7634c5:	call   *0x356c0d(%rip)        # aba0d8 <_DYNAMIC+0x268>
  7634cb:	call   *0x356c07(%rip)        # aba0d8 <_DYNAMIC+0x268>

canonical_text_public_control::main bytes=9007 frame=760

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007634e0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main>:
  7634e0:	push   %rbp
  7634e1:	push   %r15
  7634e3:	push   %r14
  7634e5:	push   %r13
  7634e7:	push   %r12
  7634e9:	push   %rbx
  7634ea:	sub    $0x2c8,%rsp
  7634f1:	lea    0x60(%rsp),%rbx
  7634f6:	mov    %rbx,%rdi
  7634f9:	call   *0x356e89(%rip)        # aba388 <_DYNAMIC+0x518>
  7634ff:	movq   $0x0,0x80(%rsp)
  76350b:	lea    0x150(%rsp),%rdi
  763513:	mov    $0x1,%edx
  763518:	mov    %rbx,%rsi
  76351b:	call   799920 <_RNvYNtNtCs2AWtUsOyxgP_3std3env4ArgsNtNtNtNtCs4NRVxsYgnAr_4core4iter6traits8iterator8Iterator3nthCs9C2G9YFESsD_29canonical_text_public_control>
  763520:	mov    0x150(%rsp),%rax
  763528:	mov    %rax,0x18(%rsp)
  76352d:	cmp    $0xffffffffffffffff,%rax
  763531:	je     76519c <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1cbc>
  763537:	mov    0x158(%rsp),%rbx
  76353f:	mov    0x78(%rsp),%rax
  763544:	sub    0x68(%rsp),%rax
  763549:	shr    $0x3,%rax
  76354d:	movabs $0xaaaaaaaaaaaaaaab,%rcx
  763557:	imul   %rcx,%rax
  76355b:	xor    %r14d,%r14d
  76355e:	sub    0x80(%rsp),%rax
  763566:	cmovb  %r14,%rax
  76356a:	cmp    $0x4,%rax
  76356e:	mov    $0x3,%r12d
  763574:	cmovae %rax,%r12
  763578:	lea    0x8(,%r12,8),%rcx
  763580:	lea    (%rcx,%rcx,2),%r15
  763584:	movabs $0x555555555555554,%rcx
  76358e:	cmp    %rcx,%rax
  763591:	jbe    7635a4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xc4>
  763593:	mov    %r14,%rdi
  763596:	mov    %r15,%rsi
  763599:	call   *0x356bc1(%rip)        # aba160 <_DYNAMIC+0x2f0>
  76359f:	jmp    765284 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  7635a4:	mov    0x160(%rsp),%rbp
  7635ac:	test   %r15,%r15
  7635af:	je     7635d8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xf8>
  7635b1:	call   *0x356b01(%rip)        # aba0b8 <_DYNAMIC+0x248>
  7635b7:	mov    $0x8,%r14d
  7635bd:	mov    $0x8,%esi
  7635c2:	mov    %r15,%rdi
  7635c5:	call   *0x356af5(%rip)        # aba0c0 <_DYNAMIC+0x250>
  7635cb:	test   %rax,%rax
  7635ce:	je     763593 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xb3>
  7635d0:	mov    %rax,%r13
  7635d3:	inc    %r12
  7635d6:	jmp    7635e1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x101>
  7635d8:	mov    $0x8,%r13d
  7635de:	xor    %r12d,%r12d
  7635e1:	mov    0x18(%rsp),%rax
  7635e6:	mov    %rax,0x0(%r13)
  7635ea:	mov    %rbx,0x8(%r13)
  7635ee:	mov    %rbp,0x10(%r13)
  7635f2:	mov    %r12,0x28(%rsp)
  7635f7:	mov    %r13,0x30(%rsp)
  7635fc:	movq   $0x1,0x38(%rsp)
  763605:	mov    0x80(%rsp),%rax
  76360d:	mov    %rax,0x170(%rsp)
  763615:	movups 0x60(%rsp),%xmm0
  76361a:	movups 0x70(%rsp),%xmm1
  76361f:	movaps %xmm1,0x160(%rsp)
  763627:	movaps %xmm0,0x150(%rsp)
  76362f:	mov    $0x1,%ebx
  763634:	mov    $0x28,%r15d
  76363a:	jmp    76367b <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x19b>
  76363c:	nopl   0x0(%rax)
  763640:	inc    %rdx
  763643:	mov    $0x8,%ecx
  763648:	mov    $0x18,%r8d
  76364e:	lea    0x28(%rsp),%rdi
  763653:	mov    %rbx,%rsi
  763656:	call   75b3b0 <_RINvNvMs2_NtCscdodAO9FK5_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs9C2G9YFESsD_29canonical_text_public_control>
  76365b:	mov    0x30(%rsp),%r13
  763660:	mov    %r14,-0x10(%r13,%r15,1)
  763665:	mov    %rbp,-0x8(%r13,%r15,1)
  76366a:	mov    %r12,0x0(%r13,%r15,1)
  76366f:	inc    %rbx
  763672:	mov    %rbx,0x38(%rsp)
  763677:	add    $0x18,%r15
  76367b:	mov    0x170(%rsp),%rdx
  763683:	test   %rdx,%rdx
  763686:	jne    7636fa <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x21a>
  763688:	lea    0x1f0(%rsp),%rdi
  763690:	lea    0x150(%rsp),%rsi
  763698:	call   *0x356cf2(%rip)        # aba390 <_DYNAMIC+0x520>
  76369e:	mov    0x1f0(%rsp),%r14
  7636a6:	cmp    $0xffffffffffffffff,%r14
  7636aa:	je     76371d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x23d>
  7636ac:	mov    0x1f8(%rsp),%rbp
  7636b4:	mov    0x200(%rsp),%r12
  7636bc:	cmp    0x28(%rsp),%rbx
  7636c1:	jne    763660 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x180>
  7636c3:	mov    0x168(%rsp),%rdx
  7636cb:	sub    0x158(%rsp),%rdx
  7636d3:	shr    $0x3,%rdx
  7636d7:	movabs $0xaaaaaaaaaaaaaaab,%rax
  7636e1:	imul   %rax,%rdx
  7636e5:	sub    0x170(%rsp),%rdx
  7636ed:	jae    763640 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x160>
  7636f3:	xor    %edx,%edx
  7636f5:	jmp    763640 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x160>
  7636fa:	movq   $0x0,0x170(%rsp)
  763706:	lea    0x1f0(%rsp),%rdi
  76370e:	lea    0x150(%rsp),%rsi
  763716:	call   799920 <_RNvYNtNtCs2AWtUsOyxgP_3std3env4ArgsNtNtNtNtCs4NRVxsYgnAr_4core4iter6traits8iterator8Iterator3nthCs9C2G9YFESsD_29canonical_text_public_control>
  76371b:	jmp    76369e <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1be>
  76371d:	mov    0x158(%rsp),%r15
  763725:	mov    0x168(%rsp),%rcx
  76372d:	mov    %rcx,%rax
  763730:	sub    %r15,%rax
  763733:	movabs $0xaaaaaaaaaaaaaaab,%rdx
  76373d:	mul    %rdx
  763740:	cmp    %r15,%rcx
  763743:	je     76377f <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x29f>
  763745:	mov    %rdx,%r14
  763748:	shr    $0x4,%r14
  76374c:	add    $0x8,%r15
  763750:	mov    0x356959(%rip),%r12        # aba0b0 <_DYNAMIC+0x240>
  763757:	jmp    763769 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x289>
  763759:	nopl   0x0(%rax)
  763760:	add    $0x18,%r15
  763764:	dec    %r14
  763767:	je     76377f <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x29f>
  763769:	mov    -0x8(%r15),%rsi
  76376d:	test   %rsi,%rsi
  763770:	je     763760 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x280>
  763772:	mov    (%r15),%rdi
  763775:	mov    $0x1,%edx
  76377a:	call   *%r12
  76377d:	jmp    763760 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x280>
  76377f:	mov    0x160(%rsp),%rax
  763787:	test   %rax,%rax
  76378a:	je     7637a7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2c7>
  76378c:	mov    0x150(%rsp),%rdi
  763794:	shl    $0x3,%rax
  763798:	lea    (%rax,%rax,2),%rsi
  76379c:	mov    $0x8,%edx
  7637a1:	call   *0x356909(%rip)        # aba0b0 <_DYNAMIC+0x240>
  7637a7:	mov    0x28(%rsp),%rax
  7637ac:	mov    %rax,0x280(%rsp)
  7637b4:	mov    0x30(%rsp),%rcx
  7637b9:	mov    0x8(%rcx),%rax
  7637bd:	mov    %rcx,0x20(%rsp)
  7637c2:	mov    0x10(%rcx),%rcx
  7637c6:	cmp    $0x6,%rcx
  7637ca:	jne    763df1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x911>
  7637d0:	mov    $0x6361726f,%ecx
  7637d5:	xor    (%rax),%ecx
  7637d7:	movzwl 0x4(%rax),%eax
  7637db:	xor    $0x656c,%eax
  7637e0:	or     %ecx,%eax
  7637e2:	jne    7651f8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1d18>
  7637e8:	movq   $0x0,0x150(%rsp)
  7637f4:	movq   $0x8,0x158(%rsp)
  763800:	movups 0x336d99(%rip),%xmm0        # a9a5a0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xc58>
  763807:	movups %xmm0,0x160(%rsp)
  76380f:	movups 0x336d9a(%rip),%xmm0        # a9a5b0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xc68>
  763816:	movups %xmm0,0x170(%rsp)
  76381e:	movups 0x336d9b(%rip),%xmm0        # a9a5c0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xc78>
  763825:	movups %xmm0,0x180(%rsp)
  76382d:	movups 0x336d9c(%rip),%xmm0        # a9a5d0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xc88>
  763834:	movups %xmm0,0x190(%rsp)
  76383c:	movups 0x336d9d(%rip),%xmm0        # a9a5e0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xc98>
  763843:	movups %xmm0,0x1a0(%rsp)
  76384b:	movups 0x336d9e(%rip),%xmm0        # a9a5f0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xca8>
  763852:	movups %xmm0,0x1b0(%rsp)
  76385a:	movups 0x336d9f(%rip),%xmm0        # a9a600 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xcb8>
  763861:	movups %xmm0,0x1c0(%rsp)
  763869:	movups 0x336da0(%rip),%xmm0        # a9a610 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xcc8>
  763870:	movups %xmm0,0x1d0(%rsp)
  763878:	mov    $0x1,%r14d
  76387e:	lea    0x2a8(%rsp),%r15
  763886:	lea    0x60(%rsp),%rbp
  76388b:	xor    %r12d,%r12d
  76388e:	jmp    7638d3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x3f3>
  763890:	mov    $0x770,%esi
  763895:	mov    $0x8,%edx
  76389a:	mov    %r14,%rdi
  76389d:	call   *0x35680d(%rip)        # aba0b0 <_DYNAMIC+0x240>
  7638a3:	mov    0xf0(%rsp),%r14
  7638ab:	xor    %r12,%r14
  7638ae:	movabs $0x100000001b3,%rax
  7638b8:	imul   %rax,%r14
  7638bc:	mov    %r13,0x2a0(%rsp)
  7638c4:	mov    0x10(%rsp),%r12
  7638c9:	cmp    $0x8,%r12
  7638cd:	je     763e44 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x964>
  7638d3:	mov    %r12,%rax
  7638d6:	shl    $0x4,%rax
  7638da:	lea    0x160(%rsp),%rcx
  7638e2:	mov    (%rcx,%rax,1),%rsi
  7638e6:	mov    0x8(%rcx,%rax,1),%rdx
  7638eb:	mov    %r15,%rdi
  7638ee:	call   766310 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source>
  7638f3:	mov    %rbp,%rdi
  7638f6:	mov    %r15,%rsi
  7638f9:	call   *0x356a39(%rip)        # aba338 <_DYNAMIC+0x4c8>
  7638ff:	mov    %rbp,%rdi
  763902:	call   765810 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount>
  763907:	mov    %rax,%r13
  76390a:	mov    %rax,0x260(%rsp)
  763912:	cmpb   $0x0,0x76e(%rax)
  763919:	jne    764fa9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ac9>
  76391f:	cmpb   $0x1,0x76a(%r13)
  763927:	jne    764fa2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ac2>
  76392d:	mov    %r14,0xf0(%rsp)
  763935:	mov    0x5c0(%r13),%r15
  76393c:	mov    $0x1a,%eax
  763941:	mov    %rax,0x1e8(%rsp)
  763949:	test   %r15,%r15
  76394c:	je     764fb6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ad6>
  763952:	inc    %r12
  763955:	mov    %r12,0x10(%rsp)
  76395a:	mov    0x5b8(%r13),%rbp
  763961:	shl    $0x6,%r15
  763965:	lea    0x1e8(%r13),%r14
  76396c:	xor    %r12d,%r12d
  76396f:	jmp    76398d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x4ad>
  763971:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  763980:	add    $0x40,%r12
  763984:	cmp    %r12,%r15
  763987:	je     764fb6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ad6>
  76398d:	cmpb   $0x4,0x3d(%rbp,%r12,1)
  763993:	jne    763980 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x4a0>
  763995:	mov    0x20(%rbp,%r12,1),%rsi
  76399a:	mov    %r14,%rdi
  76399d:	call   *0x3567c5(%rip)        # aba168 <_DYNAMIC+0x2f8>
  7639a3:	test   %al,%al
  7639a5:	je     763980 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x4a0>
  7639a7:	mov    0x20(%rbp,%r12,1),%rsi
  7639ac:	add    $0x5f0,%r13
  7639b3:	mov    %r13,%rdi
  7639b6:	call   *0x356954(%rip)        # aba310 <_DYNAMIC+0x4a0>
  7639bc:	mov    %rax,%r14
  7639bf:	mov    %rdx,%r12
  7639c2:	mov    0x260(%rsp),%rsi
  7639ca:	lea    0x100(%rsp),%rdi
  7639d2:	call   75cb40 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_>
  7639d7:	mov    0x2b8(%rsp),%rax
  7639df:	mov    %rax,%rcx
  7639e2:	shr    $0x20,%rcx
  7639e6:	lea    0x2a8(%rsp),%r15
  7639ee:	lea    0x60(%rsp),%rbp
  7639f3:	jne    764d6b <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x188b>
  7639f9:	movl   $0x0,0x60(%rsp)
  763a01:	movb   $0x1,0x64(%rsp)
  763a06:	mov    %eax,0x68(%rsp)
  763a0a:	movb   $0x1,0x6c(%rsp)
  763a0f:	mov    0x260(%rsp),%rsi
  763a17:	test   %rsi,%rsi
  763a1a:	je     765004 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1b24>
  763a20:	lea    0x1f0(%rsp),%rdi
  763a28:	mov    %r14,0x18(%rsp)
  763a2d:	mov    %r14,%rdx
  763a30:	mov    %r12,0xf8(%rsp)
  763a38:	mov    %r12,%rcx
  763a3b:	mov    %rbp,%r8
  763a3e:	call   76fb30 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE12select_inputB12_>
  763a43:	cmpq   $0xfffffffffffffffe,0x1f0(%rsp)
  763a4c:	jne    76501c <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1b3c>
  763a52:	mov    0x260(%rsp),%rax
  763a5a:	test   %rax,%rax
  763a5d:	je     76508d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1bad>
  763a63:	cmpb   $0x0,0x76e(%rax)
  763a6a:	jne    7650a0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1bc0>
  763a70:	mov    0x6d0(%rax),%r13
  763a77:	test   %r13,%r13
  763a7a:	je     7650a7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1bc7>
  763a80:	mov    0x6d8(%rax),%r12
  763a87:	mov    %rax,0x28(%rsp)
  763a8c:	lea    0x268(%rsp),%rax
  763a94:	mov    %rax,0x30(%rsp)
  763a99:	movb   $0x2,0x1fc(%rsp)
  763aa1:	movq   $0x3,(%rsp)
  763aa9:	mov    %rbp,%rdi
  763aac:	lea    0x28(%rsp),%rsi
  763ab1:	mov    0x18(%rsp),%rdx
  763ab6:	mov    0xf8(%rsp),%rcx
  763abe:	lea    0x1f0(%rsp),%r8
  763ac6:	lea    -0x694090(%rip),%r9        # cfa3d <GCC_except_table0+0xd671>
  763acd:	call   76fd60 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_>
  763ad2:	mov    0x60(%rsp),%rax
  763ad7:	cmp    $0xfffffffffffffffe,%rax
  763adb:	je     764f73 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1a93>
  763ae1:	cmp    $0x23,%eax
  763ae4:	jne    764f73 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1a93>
  763aea:	mov    0x260(%rsp),%rsi
  763af2:	mov    %rbp,%rdi
  763af5:	call   75cb40 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_>
  763afa:	mov    0x70(%rsp),%rdx
  763aff:	cmp    0x110(%rsp),%rdx
  763b07:	jne    764d26 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1846>
  763b0d:	mov    0x108(%rsp),%rsi
  763b15:	mov    0x68(%rsp),%r14
  763b1a:	mov    %r14,%rdi
  763b1d:	call   *0x356855(%rip)        # aba378 <bcmp@GLIBC_2.2.5>
  763b23:	test   %eax,%eax
  763b25:	jne    764d26 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1846>
  763b2b:	mov    0x78(%rsp),%eax
  763b2f:	cmp    0x118(%rsp),%eax
  763b36:	jne    764d26 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1846>
  763b3c:	movzbl 0x7c(%rsp),%eax
  763b41:	cmp    0x11c(%rsp),%al
  763b48:	jne    764d26 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1846>
  763b4e:	mov    0x80(%rsp),%eax
  763b55:	cmp    0x120(%rsp),%eax
  763b5c:	jne    764d26 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1846>
  763b62:	movzbl 0x84(%rsp),%eax
  763b6a:	cmp    0x124(%rsp),%al
  763b71:	jne    764d26 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1846>
  763b77:	mov    0x88(%rsp),%rax
  763b7f:	cmp    0x128(%rsp),%rax
  763b87:	jne    764d26 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1846>
  763b8d:	mov    0x90(%rsp),%rax
  763b95:	cmp    0x130(%rsp),%rax
  763b9d:	jne    764d26 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1846>
  763ba3:	mov    0x60(%rsp),%rsi
  763ba8:	test   %rsi,%rsi
  763bab:	je     763bbb <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x6db>
  763bad:	mov    $0x1,%edx
  763bb2:	mov    %r14,%rdi
  763bb5:	call   *0x3564f5(%rip)        # aba0b0 <_DYNAMIC+0x240>
  763bbb:	mov    0x260(%rsp),%rsi
  763bc3:	test   %rsi,%rsi
  763bc6:	je     7650f2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1c12>
  763bcc:	cmpb   $0x0,0x76e(%rsi)
  763bd3:	jne    76510c <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1c2c>
  763bd9:	lea    0x1f0(%rsp),%rdi
  763be1:	mov    %r13,%rdx
  763be4:	mov    %r12,%rcx
  763be7:	call   77ba20 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_>
  763bec:	cmpq   $0xfffffffffffffffe,0x1f0(%rsp)
  763bf5:	jne    765118 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1c38>
  763bfb:	mov    0x260(%rsp),%rsi
  763c03:	lea    0x28(%rsp),%rdi
  763c08:	call   75cb40 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_>
  763c0d:	mov    0x38(%rsp),%r14
  763c12:	cmp    0x2b8(%rsp),%r14
  763c1a:	jne    764d3d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x185d>
  763c20:	mov    0x2b0(%rsp),%rsi
  763c28:	mov    0x30(%rsp),%rdi
  763c2d:	mov    %r14,%rdx
  763c30:	call   *0x356742(%rip)        # aba378 <bcmp@GLIBC_2.2.5>
  763c36:	test   %eax,%eax
  763c38:	jne    764d3d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x185d>
  763c3e:	mov    %r14,%rax
  763c41:	shr    $0x20,%rax
  763c45:	jne    764d7d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x189d>
  763c4b:	movl   $0x0,0x60(%rsp)
  763c53:	movb   $0x1,0x64(%rsp)
  763c58:	mov    %r14d,0x68(%rsp)
  763c5d:	movb   $0x1,0x6c(%rsp)
  763c62:	cmpl   $0x0,0x40(%rsp)
  763c67:	jne    763db7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x8d7>
  763c6d:	movzbl 0x44(%rsp),%eax
  763c72:	cmp    %r14d,0x48(%rsp)
  763c77:	sete   %cl
  763c7a:	test   %al,%al
  763c7c:	je     763dc9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x8e9>
  763c82:	test   %cl,%cl
  763c84:	je     763dd3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x8f3>
  763c8a:	movzbl 0x4c(%rsp),%eax
  763c8f:	test   %al,%al
  763c91:	je     763ddd <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x8fd>
  763c97:	mov    %r12,0x8(%rsp)
  763c9c:	mov    0x50(%rsp),%rcx
  763ca1:	mov    0x58(%rsp),%r12
  763ca6:	mov    %rcx,0x1f0(%rsp)
  763cae:	mov    %r12,0x1f8(%rsp)
  763cb6:	mov    0x128(%rsp),%rdx
  763cbe:	mov    0x130(%rsp),%rax
  763cc6:	mov    %rdx,0x60(%rsp)
  763ccb:	mov    %rax,0x68(%rsp)
  763cd0:	cmp    %rdx,%rcx
  763cd3:	jne    764d54 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1874>
  763cd9:	cmp    %rax,%r12
  763cdc:	jne    764d54 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1874>
  763ce2:	lea    0x1f0(%rsp),%rdi
  763cea:	lea    0x260(%rsp),%rsi
  763cf2:	lea    0x3369cf(%rip),%rdx        # a9a6c8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xd80>
  763cf9:	mov    %r15,%rcx
  763cfc:	call   744a80 <_RINvMst_NtCslbxve4rcJus_4gpui7runtimeINtB6_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE3setNtNtCscdodAO9FK5_5alloc6string6StringEBL_>
  763d01:	cmpl   $0xffffffff,0x1f0(%rsp)
  763d09:	jne    764d8f <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x18af>
  763d0f:	mov    0x260(%rsp),%rsi
  763d17:	mov    %rbp,%rdi
  763d1a:	call   760ba0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack>
  763d1f:	mov    0x260(%rsp),%rsi
  763d27:	mov    %rbp,%rdi
  763d2a:	call   75cb40 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_>
  763d2f:	mov    0x90(%rsp),%rax
  763d37:	cmp    0x130(%rsp),%rax
  763d3f:	jne    764e23 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1943>
  763d45:	mov    0x60(%rsp),%rsi
  763d4a:	test   %rsi,%rsi
  763d4d:	je     763d5f <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x87f>
  763d4f:	mov    0x68(%rsp),%rdi
  763d54:	mov    $0x1,%edx
  763d59:	call   *0x356351(%rip)        # aba0b0 <_DYNAMIC+0x240>
  763d5f:	mov    0x28(%rsp),%rsi
  763d64:	test   %rsi,%rsi
  763d67:	je     763d79 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x899>
  763d69:	mov    0x30(%rsp),%rdi
  763d6e:	mov    $0x1,%edx
  763d73:	call   *0x356337(%rip)        # aba0b0 <_DYNAMIC+0x240>
  763d79:	mov    0x100(%rsp),%rsi
  763d81:	test   %rsi,%rsi
  763d84:	je     763d99 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x8b9>
  763d86:	mov    0x108(%rsp),%rdi
  763d8e:	mov    $0x1,%edx
  763d93:	call   *0x356317(%rip)        # aba0b0 <_DYNAMIC+0x240>
  763d99:	mov    0x260(%rsp),%r14
  763da1:	test   %r14,%r14
  763da4:	je     7638a3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x3c3>
  763daa:	mov    %r14,%rdi
  763dad:	call   747fc0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui7runtime7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEEB1h_>
  763db2:	jmp    763890 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x3b0>
  763db7:	xor    %eax,%eax
  763db9:	cmp    %r14d,0x48(%rsp)
  763dbe:	sete   %cl
  763dc1:	test   %al,%al
  763dc3:	jne    763c82 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x7a2>
  763dc9:	xor    %ecx,%ecx
  763dcb:	test   %cl,%cl
  763dcd:	jne    763c8a <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x7aa>
  763dd3:	xor    %eax,%eax
  763dd5:	test   %al,%al
  763dd7:	jne    763c97 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x7b7>
  763ddd:	lea    0x60(%rsp),%rsi
  763de2:	lea    0x40(%rsp),%rdi
  763de7:	call   74f585 <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout13TextSelectionBM_ECs9C2G9YFESsD_29canonical_text_public_control>
  763dec:	jmp    765284 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  763df1:	cmp    $0x7,%rcx
  763df5:	jne    7651f8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1d18>
  763dfb:	mov    $0x7361656d,%ecx
  763e00:	xor    (%rax),%ecx
  763e02:	mov    $0x65727573,%edx
  763e07:	xor    0x3(%rax),%edx
  763e0a:	or     %ecx,%edx
  763e0c:	jne    7651f8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1d18>
  763e12:	cmp    $0x3,%rbx
  763e16:	jbe    76524f <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1d6f>
  763e1c:	mov    0x20(%rsp),%rax
  763e21:	mov    0x50(%rax),%rcx
  763e25:	mov    0x58(%rax),%rsi
  763e29:	cmp    $0x1,%rsi
  763e2d:	je     76462b <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x114b>
  763e33:	test   %rsi,%rsi
  763e36:	je     765286 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da6>
  763e3c:	movzbl (%rcx),%edx
  763e3f:	jmp    764642 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1162>
  763e44:	mov    %r14,0x60(%rsp)
  763e49:	mov    %rbp,0x150(%rsp)
  763e51:	mov    0x356540(%rip),%rax        # aba398 <_DYNAMIC+0x528>
  763e58:	mov    %rax,0x158(%rsp)
  763e60:	lea    -0x69a0c4(%rip),%rdi        # c9da3 <GCC_except_table0+0x79d7>
  763e67:	lea    0x150(%rsp),%rsi
  763e6f:	call   *0x35652b(%rip)        # aba3a0 <_DYNAMIC+0x530>
  763e75:	movq   $0x0,0x60(%rsp)
  763e7e:	movq   $0x8,0x68(%rsp)
  763e87:	movups 0x336712(%rip),%xmm0        # a9a5a0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xc58>
  763e8e:	movups %xmm0,0x70(%rsp)
  763e93:	movups 0x336716(%rip),%xmm0        # a9a5b0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xc68>
  763e9a:	movups %xmm0,0x80(%rsp)
  763ea2:	movups 0x336717(%rip),%xmm0        # a9a5c0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xc78>
  763ea9:	movups %xmm0,0x90(%rsp)
  763eb1:	movups 0x336718(%rip),%xmm0        # a9a5d0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xc88>
  763eb8:	movups %xmm0,0xa0(%rsp)
  763ec0:	movups 0x336719(%rip),%xmm0        # a9a5e0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xc98>
  763ec7:	movups %xmm0,0xb0(%rsp)
  763ecf:	movups 0x33671a(%rip),%xmm0        # a9a5f0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xca8>
  763ed6:	movups %xmm0,0xc0(%rsp)
  763ede:	movups 0x33671b(%rip),%xmm0        # a9a600 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xcb8>
  763ee5:	movups %xmm0,0xd0(%rsp)
  763eed:	movups 0x33671c(%rip),%xmm0        # a9a610 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xcc8>
  763ef4:	movups %xmm0,0xe0(%rsp)
  763efc:	xor    %eax,%eax
  763efe:	lea    0x1f0(%rsp),%r12
  763f06:	jmp    763f1f <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xa3f>
  763f08:	nopl   0x0(%rax,%rax,1)
  763f10:	mov    0x8(%rsp),%rax
  763f15:	cmp    $0x8,%rax
  763f19:	je     764cba <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x17da>
  763f1f:	lea    0x1(%rax),%rcx
  763f23:	mov    %rcx,0x8(%rsp)
  763f28:	shl    $0x4,%rax
  763f2c:	lea    0x70(%rsp),%rcx
  763f31:	mov    (%rcx,%rax,1),%rdx
  763f35:	mov    %rdx,0x18(%rsp)
  763f3a:	mov    0x8(%rcx,%rax,1),%r13
  763f3f:	movq   $0x0,0x150(%rsp)
  763f4b:	movq   $0x8,0x158(%rsp)
  763f57:	lea    -0x6943e0(%rip),%rax        # cfb7e <GCC_except_table0+0xd7b2>
  763f5e:	mov    %rax,0x160(%rsp)
  763f66:	movq   $0x3,0x168(%rsp)
  763f72:	lea    -0x6943f8(%rip),%rax        # cfb81 <GCC_except_table0+0xd7b5>
  763f79:	mov    %rax,0x170(%rsp)
  763f81:	movq   $0x9,0x178(%rsp)
  763f8d:	lea    -0x69440a(%rip),%rax        # cfb8a <GCC_except_table0+0xd7be>
  763f94:	mov    %rax,0x180(%rsp)
  763f9c:	movq   $0x6,0x188(%rsp)
  763fa8:	lea    -0x69441f(%rip),%rax        # cfb90 <GCC_except_table0+0xd7c4>
  763faf:	mov    %rax,0x190(%rsp)
  763fb7:	movq   $0x9,0x198(%rsp)
  763fc3:	lea    -0x694431(%rip),%rax        # cfb99 <GCC_except_table0+0xd7cd>
  763fca:	mov    %rax,0x1a0(%rsp)
  763fd2:	movq   $0x7,0x1a8(%rsp)
  763fde:	lea    -0x694492(%rip),%rax        # cfb53 <GCC_except_table0+0xd787>
  763fe5:	mov    %rax,0x1b0(%rsp)
  763fed:	movq   $0x7,0x1b8(%rsp)
  763ff9:	lea    -0x6944b2(%rip),%rax        # cfb4e <GCC_except_table0+0xd782>
  764000:	mov    %rax,0x1c0(%rsp)
  764008:	movq   $0x5,0x1c8(%rsp)
  764014:	lea    -0x6a1ba7(%rip),%rax        # c2474 <GCC_except_table0+0xa8>
  76401b:	mov    %rax,0x1d0(%rsp)
  764023:	movq   $0x4,0x1d8(%rsp)
  76402f:	mov    $0x1,%r15d
  764035:	lea    0x168(%rsp),%rbp
  76403d:	mov    %r13,0xf0(%rsp)
  764045:	jmp    764069 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xb89>
  764047:	nopw   0x0(%rax,%rax,1)
  764050:	mov    0xf8(%rsp),%rbp
  764058:	add    $0x10,%rbp
  76405c:	inc    %r15
  76405f:	cmp    $0x9,%r15
  764063:	je     763f10 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xa30>
  764069:	mov    -0x8(%rbp),%r8
  76406d:	mov    %rbp,0xf8(%rsp)
  764075:	mov    0x0(%rbp),%r14
  764079:	cmp    $0x4,%r13
  76407d:	je     764120 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xc40>
  764083:	cmp    $0x5,%r13
  764087:	je     7640d0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xbf0>
  764089:	cmp    $0xd,%r13
  76408d:	jne    764149 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xc69>
  764093:	mov    0x18(%rsp),%rdx
  764098:	mov    (%rdx),%rcx
  76409b:	movabs $0x6172672d676e6f6c,%rax
  7640a5:	xor    %rax,%rcx
  7640a8:	mov    0x5(%rdx),%rdx
  7640ac:	movabs $0x656d656870617267,%rax
  7640b6:	xor    %rax,%rdx
  7640b9:	xor    %eax,%eax
  7640bb:	or     %rcx,%rdx
  7640be:	setne  %cl
  7640c1:	cmp    $0x4,%r14
  7640c5:	je     764136 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xc56>
  7640c7:	jmp    764149 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xc69>
  7640cc:	nopl   0x0(%rax)
  7640d0:	mov    0x18(%rsp),%rdx
  7640d5:	mov    (%rdx),%ecx
  7640d7:	mov    $0x74706d65,%eax
  7640dc:	xor    %eax,%ecx
  7640de:	movzbl 0x4(%rdx),%edx
  7640e2:	xor    $0x79,%edx
  7640e5:	xor    %eax,%eax
  7640e7:	or     %ecx,%edx
  7640e9:	setne  %al
  7640ec:	cmp    $0x5,%r14
  7640f0:	jne    76461c <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x113c>
  7640f6:	test   %eax,%eax
  7640f8:	jne    76461c <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x113c>
  7640fe:	mov    (%r8),%eax
  764101:	mov    $0x6f727261,%ecx
  764106:	xor    %ecx,%eax
  764108:	movzbl 0x4(%r8),%ecx
  76410d:	xor    $0x77,%ecx
  764110:	or     %eax,%ecx
  764112:	jne    764149 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xc69>
  764114:	jmp    764050 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xb70>
  764119:	nopl   0x0(%rax)
  764120:	xor    %eax,%eax
  764122:	mov    0x18(%rsp),%rcx
  764127:	cmpl   $0x796e6974,(%rcx)
  76412d:	setne  %cl
  764130:	cmp    $0x4,%r14
  764134:	jne    764149 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xc69>
  764136:	mov    %cl,%al
  764138:	test   %eax,%eax
  76413a:	jne    764149 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xc69>
  76413c:	cmpl   $0x67617264,(%r8)
  764143:	je     764050 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xb70>
  764149:	movl   $0x0,(%rsp)
  764150:	mov    $0x4,%r9d
  764156:	mov    %r12,%rdi
  764159:	mov    0x18(%rsp),%rsi
  76415e:	mov    %r13,%rdx
  764161:	mov    %r8,%rbp
  764164:	mov    %r8,%rcx
  764167:	mov    %r14,%r8
  76416a:	call   760d10 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run>
  76416f:	mov    %r15,0x10(%rsp)
  764174:	mov    0x200(%rsp),%rax
  76417c:	mov    %rax,0x1e8(%rsp)
  764184:	lea    0x208(%rsp),%rax
  76418c:	movups (%rax),%xmm0
  76418f:	movups 0x10(%rax),%xmm1
  764193:	movaps %xmm1,0x270(%rsp)
  76419b:	movaps %xmm0,0x260(%rsp)
  7641a3:	movq   $0x0,0x288(%rsp)
  7641af:	movq   $0x0,0x298(%rsp)
  7641bb:	call   *0x355ef7(%rip)        # aba0b8 <_DYNAMIC+0x248>
  7641c1:	mov    $0x4,%r15d
  7641c7:	mov    $0x4,%edi
  7641cc:	mov    $0x1,%esi
  7641d1:	call   *0x355ee9(%rip)        # aba0c0 <_DYNAMIC+0x250>
  7641d7:	test   %rax,%rax
  7641da:	je     764e87 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x19a7>
  7641e0:	mov    %rax,%r13
  7641e3:	movl   $0x65736163,(%rax)
  7641e9:	movq   $0x4,0x138(%rsp)
  7641f5:	mov    %rax,0x140(%rsp)
  7641fd:	movq   $0x4,0x148(%rsp)
  764209:	mov    0xf0(%rsp),%r12
  764211:	test   %r12,%r12
  764214:	je     764250 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xd70>
  764216:	call   *0x355e9c(%rip)        # aba0b8 <_DYNAMIC+0x248>
  76421c:	mov    $0x1,%esi
  764221:	mov    %r12,%rdi
  764224:	call   *0x355e96(%rip)        # aba0c0 <_DYNAMIC+0x250>
  76422a:	test   %rax,%rax
  76422d:	je     764f49 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1a69>
  764233:	mov    %rax,%r15
  764236:	mov    %rax,%rdi
  764239:	mov    0x18(%rsp),%rsi
  76423e:	mov    %r12,%rdx
  764241:	call   *0x355e89(%rip)        # aba0d0 <memcpy@GLIBC_2.14>
  764247:	jmp    764256 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xd76>
  764249:	nopl   0x0(%rax)
  764250:	mov    $0x1,%r15d
  764256:	movb   $0x3,0x28(%rsp)
  76425b:	mov    %r12,0x30(%rsp)
  764260:	mov    %r15,0x38(%rsp)
  764265:	mov    %r12,0x40(%rsp)
  76426a:	lea    0x100(%rsp),%rdi
  764272:	lea    0x288(%rsp),%rsi
  76427a:	lea    0x138(%rsp),%rdx
  764282:	lea    0x28(%rsp),%rcx
  764287:	call   776790 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  76428c:	cmpb   $0xff,0x100(%rsp)
  764294:	je     7642a3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xdc3>
  764296:	lea    0x100(%rsp),%rdi
  76429e:	call   74cb60 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  7642a3:	call   *0x355e0f(%rip)        # aba0b8 <_DYNAMIC+0x248>
  7642a9:	mov    $0x9,%r15d
  7642af:	mov    $0x9,%edi
  7642b4:	mov    $0x1,%esi
  7642b9:	call   *0x355e01(%rip)        # aba0c0 <_DYNAMIC+0x250>
  7642bf:	test   %rax,%rax
  7642c2:	je     764e87 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x19a7>
  7642c8:	movabs $0x6f6974617265706f,%rcx
  7642d2:	mov    %rcx,(%rax)
  7642d5:	movb   $0x6e,0x8(%rax)
  7642d9:	movq   $0x9,0x138(%rsp)
  7642e5:	mov    %rax,0x140(%rsp)
  7642ed:	movq   $0x9,0x148(%rsp)
  7642f9:	test   %r14,%r14
  7642fc:	je     764340 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xe60>
  7642fe:	mov    %rax,%r13
  764301:	call   *0x355db1(%rip)        # aba0b8 <_DYNAMIC+0x248>
  764307:	mov    $0x1,%esi
  76430c:	mov    %r14,%rdi
  76430f:	call   *0x355dab(%rip)        # aba0c0 <_DYNAMIC+0x250>
  764315:	test   %rax,%rax
  764318:	je     764f1f <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1a3f>
  76431e:	mov    %rax,%r15
  764321:	mov    %rax,%rdi
  764324:	mov    %rbp,%rsi
  764327:	mov    %r14,%rdx
  76432a:	call   *0x355da0(%rip)        # aba0d0 <memcpy@GLIBC_2.14>
  764330:	jmp    764346 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xe66>
  764332:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  764340:	mov    $0x1,%r15d
  764346:	movb   $0x3,0x28(%rsp)
  76434b:	mov    %r14,0x30(%rsp)
  764350:	mov    %r15,0x38(%rsp)
  764355:	mov    %r14,0x40(%rsp)
  76435a:	lea    0x100(%rsp),%rdi
  764362:	lea    0x288(%rsp),%rsi
  76436a:	lea    0x138(%rsp),%rdx
  764372:	lea    0x28(%rsp),%rcx
  764377:	call   776790 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  76437c:	cmpb   $0xff,0x100(%rsp)
  764384:	je     764393 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xeb3>
  764386:	lea    0x100(%rsp),%rdi
  76438e:	call   74cb60 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  764393:	call   *0x355d1f(%rip)        # aba0b8 <_DYNAMIC+0x248>
  764399:	mov    $0x5,%r15d
  76439f:	mov    $0x5,%edi
  7643a4:	mov    $0x1,%esi
  7643a9:	call   *0x355d11(%rip)        # aba0c0 <_DYNAMIC+0x250>
  7643af:	test   %rax,%rax
  7643b2:	je     764e87 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x19a7>
  7643b8:	movb   $0x74,0x4(%rax)
  7643bc:	movl   $0x6e756f63,(%rax)
  7643c2:	movq   $0x5,0x138(%rsp)
  7643ce:	mov    %rax,0x140(%rsp)
  7643d6:	movq   $0x5,0x148(%rsp)
  7643e2:	movb   $0x2,0x28(%rsp)
  7643e7:	movq   $0x0,0x30(%rsp)
  7643f0:	movq   $0x4,0x38(%rsp)
  7643f9:	lea    0x100(%rsp),%rdi
  764401:	lea    0x288(%rsp),%rsi
  764409:	lea    0x138(%rsp),%rdx
  764411:	lea    0x28(%rsp),%rcx
  764416:	call   776790 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  76441b:	cmpb   $0xff,0x100(%rsp)
  764423:	je     764432 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xf52>
  764425:	lea    0x100(%rsp),%rdi
  76442d:	call   74cb60 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  764432:	call   *0x355c80(%rip)        # aba0b8 <_DYNAMIC+0x248>
  764438:	mov    $0x8,%r15d
  76443e:	mov    $0x8,%edi
  764443:	mov    $0x1,%esi
  764448:	call   *0x355c72(%rip)        # aba0c0 <_DYNAMIC+0x250>
  76444e:	test   %rax,%rax
  764451:	je     764e87 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x19a7>
  764457:	movabs $0x6d75736b63656863,%rcx
  764461:	mov    %rcx,(%rax)
  764464:	movq   $0x8,0x138(%rsp)
  764470:	mov    %rax,0x140(%rsp)
  764478:	movq   $0x8,0x148(%rsp)
  764484:	movb   $0x2,0x28(%rsp)
  764489:	movq   $0x0,0x30(%rsp)
  764492:	mov    0x1e8(%rsp),%rax
  76449a:	mov    %rax,0x38(%rsp)
  76449f:	lea    0x100(%rsp),%rdi
  7644a7:	lea    0x288(%rsp),%rsi
  7644af:	lea    0x138(%rsp),%rdx
  7644b7:	lea    0x28(%rsp),%rcx
  7644bc:	call   776790 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  7644c1:	cmpb   $0xff,0x100(%rsp)
  7644c9:	je     7644d8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xff8>
  7644cb:	lea    0x100(%rsp),%rdi
  7644d3:	call   74cb60 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  7644d8:	call   *0x355bda(%rip)        # aba0b8 <_DYNAMIC+0x248>
  7644de:	mov    $0x8,%r15d
  7644e4:	mov    $0x8,%edi
  7644e9:	mov    $0x1,%esi
  7644ee:	call   *0x355bcc(%rip)        # aba0c0 <_DYNAMIC+0x250>
  7644f4:	test   %rax,%rax
  7644f7:	je     764e87 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x19a7>
  7644fd:	mov    %rax,%r14
  764500:	movabs $0x737265746e756f63,%rax
  76450a:	mov    %rax,(%r14)
  76450d:	movq   $0x8,0x138(%rsp)
  764519:	mov    %r14,0x140(%rsp)
  764521:	movq   $0x8,0x148(%rsp)
  76452d:	lea    0x28(%rsp),%rdi
  764532:	lea    0x260(%rsp),%rsi
  76453a:	call   75b430 <_RINvXNtNtCscl5MXVnO7Zx_10serde_json5value3serNtB5_5ValueNtNtCs8znKHa7cbRS_10serde_core3ser9Serialize9serializeNtB3_10SerializerECs9C2G9YFESsD_29canonical_text_public_control>
  76453f:	cmpb   $0xff,0x28(%rsp)
  764544:	je     7646e3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1203>
  76454a:	movups 0x28(%rsp),%xmm0
  76454f:	movups 0x38(%rsp),%xmm1
  764554:	movaps %xmm1,0x110(%rsp)
  76455c:	movaps %xmm0,0x100(%rsp)
  764564:	lea    0x28(%rsp),%rdi
  764569:	lea    0x288(%rsp),%rsi
  764571:	lea    0x138(%rsp),%rdx
  764579:	lea    0x100(%rsp),%rcx
  764581:	call   776790 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  764586:	cmpb   $0xff,0x28(%rsp)
  76458b:	je     764597 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x10b7>
  76458d:	lea    0x28(%rsp),%rdi
  764592:	call   74cb60 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  764597:	mov    0x298(%rsp),%rax
  76459f:	lea    0x2b0(%rsp),%rcx
  7645a7:	mov    %rax,0x10(%rcx)
  7645ab:	movups 0x288(%rsp),%xmm0
  7645b3:	movups %xmm0,(%rcx)
  7645b6:	movb   $0x5,0x2a8(%rsp)
  7645be:	lea    0x2a8(%rsp),%r14
  7645c6:	mov    %r14,0x1f0(%rsp)
  7645ce:	mov    0x355dd3(%rip),%rax        # aba3a8 <_DYNAMIC+0x538>
  7645d5:	mov    %rax,0x1f8(%rsp)
  7645dd:	lea    -0x69f8c2(%rip),%rdi        # c4d22 <GCC_except_table0+0x2956>
  7645e4:	lea    0x1f0(%rsp),%r12
  7645ec:	mov    %r12,%rsi
  7645ef:	call   *0x355dab(%rip)        # aba3a0 <_DYNAMIC+0x530>
  7645f5:	mov    %r14,%rdi
  7645f8:	mov    0x10(%rsp),%r15
  7645fd:	call   74cb60 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  764602:	mov    0xf0(%rsp),%r13
  76460a:	lea    0x260(%rsp),%rdi
  764612:	call   74cb60 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  764617:	jmp    764050 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xb70>
  76461c:	cmp    $0x4,%r14
  764620:	je     764138 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xc58>
  764626:	jmp    764149 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xc69>
  76462b:	movzbl (%rcx),%edx
  76462e:	mov    $0x1,%al
  764630:	cmp    $0x2b,%edx
  764633:	je     764e53 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1973>
  764639:	cmp    $0x2d,%edx
  76463c:	je     764e53 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1973>
  764642:	xor    %eax,%eax
  764644:	cmp    $0x2b,%dl
  764647:	sete   %al
  76464a:	mov    %rsi,%rdx
  76464d:	sub    %rax,%rdx
  764650:	add    %rax,%rcx
  764653:	neg    %rax
  764656:	cmp    $0x11,%rdx
  76465a:	jae    76469a <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x11ba>
  76465c:	test   %rdx,%rdx
  76465f:	je     764734 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1254>
  764665:	add    %rax,%rsi
  764668:	neg    %rsi
  76466b:	xor    %eax,%eax
  76466d:	xor    %edx,%edx
  76466f:	nop
  764670:	movzbl (%rcx,%rdx,1),%edi
  764674:	add    $0xffffffd0,%edi
  764677:	cmp    $0x9,%edi
  76467a:	ja     764f9b <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1abb>
  764680:	lea    (%rax,%rax,4),%rax
  764684:	mov    %edi,%edi
  764686:	lea    (%rdi,%rax,2),%rax
  76468a:	inc    %rdx
  76468d:	mov    %rsi,%rdi
  764690:	add    %rdx,%rdi
  764693:	jne    764670 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1190>
  764695:	jmp    764736 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1256>
  76469a:	add    %rax,%rsi
  76469d:	neg    %rsi
  7646a0:	xor    %eax,%eax
  7646a2:	mov    $0xa,%edi
  7646a7:	xor    %r8d,%r8d
  7646aa:	nopw   0x0(%rax,%rax,1)
  7646b0:	mov    %rsi,%rdx
  7646b3:	add    %r8,%rdx
  7646b6:	je     764736 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1256>
  7646b8:	mul    %rdi
  7646bb:	movzbl (%rcx,%r8,1),%edx
  7646c0:	jo     764e49 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1969>
  7646c6:	add    $0xffffffd0,%edx
  7646c9:	cmp    $0xa,%edx
  7646cc:	jae    764f9b <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1abb>
  7646d2:	mov    %edx,%edx
  7646d4:	inc    %r8
  7646d7:	add    %rdx,%rax
  7646da:	jae    7646b0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x11d0>
  7646dc:	mov    $0x2,%al
  7646de:	jmp    764e53 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1973>
  7646e3:	mov    0x8(%rsp),%rax
  7646e8:	mov    %rax,0x60(%rsp)
  7646ed:	mov    0x10(%rsp),%rax
  7646f2:	mov    %rax,0x150(%rsp)
  7646fa:	mov    0x30(%rsp),%rax
  7646ff:	mov    %rax,0x100(%rsp)
  764707:	lea    -0x694aac(%rip),%rdi        # cfc62 <GCC_except_table0+0xd896>
  76470e:	lea    0x33646b(%rip),%rcx        # a9ab80 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1238>
  764715:	lea    0x336384(%rip),%r8        # a9aaa0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1158>
  76471c:	lea    0x100(%rsp),%rdx
  764724:	mov    $0x2b,%esi
  764729:	call   *0x355a51(%rip)        # aba180 <_DYNAMIC+0x310>
  76472f:	jmp    765284 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  764734:	xor    %eax,%eax
  764736:	mov    0x20(%rsp),%rdi
  76473b:	mov    0x20(%rdi),%rsi
  76473f:	mov    0x28(%rdi),%rdx
  764743:	mov    0x38(%rdi),%rcx
  764747:	mov    0x40(%rdi),%r8
  76474b:	movl   $0x1,(%rsp)
  764752:	lea    0x150(%rsp),%rdi
  76475a:	mov    %rax,%r15
  76475d:	mov    %rax,%r9
  764760:	call   760d10 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run>
  764765:	mov    0x160(%rsp),%rax
  76476d:	mov    %rax,0x18(%rsp)
  764772:	mov    0x150(%rsp),%rax
  76477a:	mov    %rax,0xf8(%rsp)
  764782:	mov    0x158(%rsp),%rax
  76478a:	mov    %rax,0xf0(%rsp)
  764792:	movups 0x178(%rsp),%xmm0
  76479a:	movaps %xmm0,0x200(%rsp)
  7647a2:	movups 0x168(%rsp),%xmm0
  7647aa:	movaps %xmm0,0x1f0(%rsp)
  7647b2:	movq   $0x0,0x100(%rsp)
  7647be:	movq   $0x0,0x110(%rsp)
  7647ca:	call   *0x3558e8(%rip)        # aba0b8 <_DYNAMIC+0x248>
  7647d0:	mov    $0x4,%r13d
  7647d6:	mov    $0x1,%ebp
  7647db:	mov    $0x4,%edi
  7647e0:	mov    $0x1,%esi
  7647e5:	call   *0x3558d5(%rip)        # aba0c0 <_DYNAMIC+0x250>
  7647eb:	test   %rax,%rax
  7647ee:	je     765189 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ca9>
  7647f4:	movl   $0x65736163,(%rax)
  7647fa:	movq   $0x4,0x28(%rsp)
  764803:	mov    %rax,0x30(%rsp)
  764808:	movq   $0x4,0x38(%rsp)
  764811:	mov    0x20(%rsp),%rcx
  764816:	mov    0x28(%rcx),%r12
  76481a:	test   %r12,%r12
  76481d:	je     76485a <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x137a>
  76481f:	mov    %rax,%r13
  764822:	mov    0x20(%rsp),%rax
  764827:	mov    0x20(%rax),%r14
  76482b:	call   *0x355887(%rip)        # aba0b8 <_DYNAMIC+0x248>
  764831:	mov    $0x1,%esi
  764836:	mov    %r12,%rdi
  764839:	call   *0x355881(%rip)        # aba0c0 <_DYNAMIC+0x250>
  76483f:	test   %rax,%rax
  764842:	je     765266 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1d86>
  764848:	mov    %rax,%rbp
  76484b:	mov    %rax,%rdi
  76484e:	mov    %r14,%rsi
  764851:	mov    %r12,%rdx
  764854:	call   *0x355876(%rip)        # aba0d0 <memcpy@GLIBC_2.14>
  76485a:	movb   $0x3,0x150(%rsp)
  764862:	mov    %r12,0x158(%rsp)
  76486a:	mov    %rbp,0x160(%rsp)
  764872:	mov    %r12,0x168(%rsp)
  76487a:	lea    0x60(%rsp),%rdi
  76487f:	lea    0x100(%rsp),%rsi
  764887:	lea    0x28(%rsp),%rdx
  76488c:	lea    0x150(%rsp),%rcx
  764894:	call   776790 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  764899:	cmpb   $0xff,0x60(%rsp)
  76489e:	je     7648aa <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x13ca>
  7648a0:	lea    0x60(%rsp),%rdi
  7648a5:	call   74cb60 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  7648aa:	call   *0x355808(%rip)        # aba0b8 <_DYNAMIC+0x248>
  7648b0:	mov    $0x9,%r13d
  7648b6:	mov    $0x1,%r12d
  7648bc:	mov    $0x9,%edi
  7648c1:	mov    $0x1,%esi
  7648c6:	call   *0x3557f4(%rip)        # aba0c0 <_DYNAMIC+0x250>
  7648cc:	test   %rax,%rax
  7648cf:	je     765189 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ca9>
  7648d5:	movabs $0x6f6974617265706f,%rcx
  7648df:	mov    %rcx,(%rax)
  7648e2:	movb   $0x6e,0x8(%rax)
  7648e6:	movq   $0x9,0x28(%rsp)
  7648ef:	mov    %rax,0x30(%rsp)
  7648f4:	movq   $0x9,0x38(%rsp)
  7648fd:	mov    0x20(%rsp),%rcx
  764902:	mov    0x40(%rcx),%r13
  764906:	test   %r13,%r13
  764909:	je     764946 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1466>
  76490b:	mov    %rax,%rbp
  76490e:	mov    0x20(%rsp),%rax
  764913:	mov    0x38(%rax),%r14
  764917:	call   *0x35579b(%rip)        # aba0b8 <_DYNAMIC+0x248>
  76491d:	mov    $0x1,%esi
  764922:	mov    %r13,%rdi
  764925:	call   *0x355795(%rip)        # aba0c0 <_DYNAMIC+0x250>
  76492b:	test   %rax,%rax
  76492e:	je     765276 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1d96>
  764934:	mov    %rax,%r12
  764937:	mov    %rax,%rdi
  76493a:	mov    %r14,%rsi
  76493d:	mov    %r13,%rdx
  764940:	call   *0x35578a(%rip)        # aba0d0 <memcpy@GLIBC_2.14>
  764946:	movb   $0x3,0x150(%rsp)
  76494e:	mov    %r13,0x158(%rsp)
  764956:	mov    %r12,0x160(%rsp)
  76495e:	mov    %r13,0x168(%rsp)
  764966:	lea    0x60(%rsp),%rdi
  76496b:	lea    0x100(%rsp),%rsi
  764973:	lea    0x28(%rsp),%rdx
  764978:	lea    0x150(%rsp),%rcx
  764980:	call   776790 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  764985:	cmpb   $0xff,0x60(%rsp)
  76498a:	je     764996 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x14b6>
  76498c:	lea    0x60(%rsp),%rdi
  764991:	call   74cb60 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  764996:	call   *0x35571c(%rip)        # aba0b8 <_DYNAMIC+0x248>
  76499c:	mov    $0x5,%r13d
  7649a2:	mov    $0x5,%edi
  7649a7:	mov    $0x1,%esi
  7649ac:	call   *0x35570e(%rip)        # aba0c0 <_DYNAMIC+0x250>
  7649b2:	test   %rax,%rax
  7649b5:	je     765189 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ca9>
  7649bb:	movb   $0x74,0x4(%rax)
  7649bf:	movl   $0x6e756f63,(%rax)
  7649c5:	movq   $0x5,0x28(%rsp)
  7649ce:	mov    %rax,0x30(%rsp)
  7649d3:	movq   $0x5,0x38(%rsp)
  7649dc:	movb   $0x2,0x150(%rsp)
  7649e4:	movq   $0x0,0x158(%rsp)
  7649f0:	mov    %r15,0x160(%rsp)
  7649f8:	lea    0x60(%rsp),%rdi
  7649fd:	lea    0x100(%rsp),%rsi
  764a05:	lea    0x28(%rsp),%rdx
  764a0a:	lea    0x150(%rsp),%rcx
  764a12:	call   776790 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  764a17:	cmpb   $0xff,0x60(%rsp)
  764a1c:	je     764a28 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1548>
  764a1e:	lea    0x60(%rsp),%rdi
  764a23:	call   74cb60 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  764a28:	call   *0x35568a(%rip)        # aba0b8 <_DYNAMIC+0x248>
  764a2e:	mov    $0x8,%r13d
  764a34:	mov    $0x8,%edi
  764a39:	mov    $0x1,%esi
  764a3e:	call   *0x35567c(%rip)        # aba0c0 <_DYNAMIC+0x250>
  764a44:	test   %rax,%rax
  764a47:	je     765189 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ca9>
  764a4d:	movabs $0x6d75736b63656863,%rcx
  764a57:	mov    %rcx,(%rax)
  764a5a:	movq   $0x8,0x28(%rsp)
  764a63:	mov    %rax,0x30(%rsp)
  764a68:	movq   $0x8,0x38(%rsp)
  764a71:	movb   $0x2,0x150(%rsp)
  764a79:	movq   $0x0,0x158(%rsp)
  764a85:	mov    0x18(%rsp),%rax
  764a8a:	mov    %rax,0x160(%rsp)
  764a92:	lea    0x60(%rsp),%rdi
  764a97:	lea    0x100(%rsp),%rsi
  764a9f:	lea    0x28(%rsp),%rdx
  764aa4:	lea    0x150(%rsp),%rcx
  764aac:	call   776790 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  764ab1:	cmpb   $0xff,0x60(%rsp)
  764ab6:	je     764ac2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x15e2>
  764ab8:	lea    0x60(%rsp),%rdi
  764abd:	call   74cb60 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  764ac2:	call   *0x3555f0(%rip)        # aba0b8 <_DYNAMIC+0x248>
  764ac8:	mov    $0xa,%r13d
  764ace:	mov    $0xa,%edi
  764ad3:	mov    $0x1,%esi
  764ad8:	call   *0x3555e2(%rip)        # aba0c0 <_DYNAMIC+0x250>
  764ade:	test   %rax,%rax
  764ae1:	je     765189 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ca9>
  764ae7:	mov    %rax,%r12
  764aea:	movabs $0x5f64657370616c65,%rax
  764af4:	mov    %rax,(%r12)
  764af8:	movw   $0x736e,0x8(%r12)
  764b00:	movq   $0xa,0x28(%rsp)
  764b09:	mov    %r12,0x30(%rsp)
  764b0e:	movq   $0xa,0x38(%rsp)
  764b17:	lea    0x150(%rsp),%rdi
  764b1f:	mov    0xf8(%rsp),%rsi
  764b27:	mov    0xf0(%rsp),%rdx
  764b2f:	call   *0x35587b(%rip)        # aba3b0 <_DYNAMIC+0x540>
  764b35:	cmpb   $0xff,0x150(%rsp)
  764b3d:	je     764eb1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x19d1>
  764b43:	movups 0x150(%rsp),%xmm0
  764b4b:	movups 0x160(%rsp),%xmm1
  764b53:	movaps %xmm1,0x70(%rsp)
  764b58:	movaps %xmm0,0x60(%rsp)
  764b5d:	lea    0x150(%rsp),%rdi
  764b65:	lea    0x100(%rsp),%rsi
  764b6d:	lea    0x28(%rsp),%rdx
  764b72:	lea    0x60(%rsp),%rcx
  764b77:	call   776790 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  764b7c:	cmpb   $0xff,0x150(%rsp)
  764b84:	je     764b93 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x16b3>
  764b86:	lea    0x150(%rsp),%rdi
  764b8e:	call   74cb60 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  764b93:	call   *0x35551f(%rip)        # aba0b8 <_DYNAMIC+0x248>
  764b99:	mov    $0x8,%r13d
  764b9f:	mov    $0x8,%edi
  764ba4:	mov    $0x1,%esi
  764ba9:	call   *0x355511(%rip)        # aba0c0 <_DYNAMIC+0x250>
  764baf:	test   %rax,%rax
  764bb2:	je     765189 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ca9>
  764bb8:	mov    %rax,%r14
  764bbb:	movabs $0x737265746e756f63,%rax
  764bc5:	mov    %rax,(%r14)
  764bc8:	movq   $0x8,0x28(%rsp)
  764bd1:	mov    %r14,0x30(%rsp)
  764bd6:	movq   $0x8,0x38(%rsp)
  764bdf:	lea    0x150(%rsp),%rdi
  764be7:	lea    0x1f0(%rsp),%rsi
  764bef:	call   75b430 <_RINvXNtNtCscl5MXVnO7Zx_10serde_json5value3serNtB5_5ValueNtNtCs8znKHa7cbRS_10serde_core3ser9Serialize9serializeNtB3_10SerializerECs9C2G9YFESsD_29canonical_text_public_control>
  764bf4:	cmpb   $0xff,0x150(%rsp)
  764bfc:	je     764ee8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1a08>
  764c02:	movups 0x150(%rsp),%xmm0
  764c0a:	movups 0x160(%rsp),%xmm1
  764c12:	movaps %xmm1,0x70(%rsp)
  764c17:	movaps %xmm0,0x60(%rsp)
  764c1c:	lea    0x150(%rsp),%r14
  764c24:	lea    0x100(%rsp),%rsi
  764c2c:	lea    0x28(%rsp),%rdx
  764c31:	lea    0x60(%rsp),%rcx
  764c36:	mov    %r14,%rdi
  764c39:	call   776790 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  764c3e:	cmpb   $0xff,0x150(%rsp)
  764c46:	je     764c55 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1775>
  764c48:	lea    0x150(%rsp),%rdi
  764c50:	call   74cb60 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  764c55:	movups 0x100(%rsp),%xmm0
  764c5d:	movups %xmm0,0x158(%rsp)
  764c65:	mov    0x110(%rsp),%rax
  764c6d:	mov    %rax,0x168(%rsp)
  764c75:	movb   $0x5,0x150(%rsp)
  764c7d:	mov    %r14,0x60(%rsp)
  764c82:	mov    0x35571f(%rip),%rax        # aba3a8 <_DYNAMIC+0x538>
  764c89:	mov    %rax,0x68(%rsp)
  764c8e:	lea    -0x69ff73(%rip),%rdi        # c4d22 <GCC_except_table0+0x2956>
  764c95:	lea    0x60(%rsp),%rsi
  764c9a:	call   *0x355700(%rip)        # aba3a0 <_DYNAMIC+0x530>
  764ca0:	lea    0x150(%rsp),%rdi
  764ca8:	call   74cb60 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  764cad:	lea    0x1f0(%rsp),%rdi
  764cb5:	call   74cb60 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  764cba:	mov    0x20(%rsp),%rax
  764cbf:	lea    0x8(%rax),%r14
  764cc3:	mov    0x3553e6(%rip),%r15        # aba0b0 <_DYNAMIC+0x240>
  764cca:	jmp    764cd9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x17f9>
  764ccc:	nopl   0x0(%rax)
  764cd0:	add    $0x18,%r14
  764cd4:	dec    %rbx
  764cd7:	je     764cef <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x180f>
  764cd9:	mov    -0x8(%r14),%rsi
  764cdd:	test   %rsi,%rsi
  764ce0:	je     764cd0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x17f0>
  764ce2:	mov    (%r14),%rdi
  764ce5:	mov    $0x1,%edx
  764cea:	call   *%r15
  764ced:	jmp    764cd0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x17f0>
  764cef:	mov    0x280(%rsp),%rax
  764cf7:	test   %rax,%rax
  764cfa:	je     764d14 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1834>
  764cfc:	shl    $0x3,%rax
  764d00:	lea    (%rax,%rax,2),%rsi
  764d04:	mov    $0x8,%edx
  764d09:	mov    0x20(%rsp),%rdi
  764d0e:	call   *0x35539c(%rip)        # aba0b0 <_DYNAMIC+0x240>
  764d14:	add    $0x2c8,%rsp
  764d1b:	pop    %rbx
  764d1c:	pop    %r12
  764d1e:	pop    %r13
  764d20:	pop    %r14
  764d22:	pop    %r15
  764d24:	pop    %rbp
  764d25:	ret
  764d26:	lea    0x60(%rsp),%rdi
  764d2b:	lea    0x100(%rsp),%rsi
  764d33:	call   74f636 <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedTNtNtCscdodAO9FK5_5alloc6string6StringNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout13TextSelectionPNtB1q_12TextGeometryyEBM_ECs9C2G9YFESsD_29canonical_text_public_control>
  764d38:	jmp    765284 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  764d3d:	lea    0x28(%rsp),%rdi
  764d42:	lea    0x2a8(%rsp),%rsi
  764d4a:	call   74f51b <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedNtNtCscdodAO9FK5_5alloc6string6StringBM_ECs9C2G9YFESsD_29canonical_text_public_control>
  764d4f:	jmp    765284 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  764d54:	lea    0x1f0(%rsp),%rdi
  764d5c:	lea    0x60(%rsp),%rsi
  764d61:	call   74f66e <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedTPNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryyEBM_ECs9C2G9YFESsD_29canonical_text_public_control>
  764d66:	jmp    765284 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  764d6b:	lea    0x3359de(%rip),%rdi        # a9a750 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xe08>
  764d72:	call   *0x3553f8(%rip)        # aba170 <_DYNAMIC+0x300>
  764d78:	jmp    765284 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  764d7d:	lea    0x33599c(%rip),%rdi        # a9a720 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xdd8>
  764d84:	call   *0x3553e6(%rip)        # aba170 <_DYNAMIC+0x300>
  764d8a:	jmp    765284 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  764d8f:	mov    0x250(%rsp),%rax
  764d97:	mov    %rax,0xc0(%rsp)
  764d9f:	movups 0x240(%rsp),%xmm0
  764da7:	movaps %xmm0,0xb0(%rsp)
  764daf:	movups 0x230(%rsp),%xmm0
  764db7:	movaps %xmm0,0xa0(%rsp)
  764dbf:	movups 0x1f0(%rsp),%xmm0
  764dc7:	movups 0x200(%rsp),%xmm1
  764dcf:	movups 0x210(%rsp),%xmm2
  764dd7:	movups 0x220(%rsp),%xmm3
  764ddf:	movaps %xmm3,0x90(%rsp)
  764de7:	movaps %xmm2,0x80(%rsp)
  764def:	movaps %xmm1,0x70(%rsp)
  764df4:	movaps %xmm0,0x60(%rsp)
  764df9:	lea    -0x69519e(%rip),%rdi        # cfc62 <GCC_except_table0+0xd896>
  764e00:	lea    0x335dd9(%rip),%rcx        # a9abe0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1298>
  764e07:	lea    0x3358e2(%rip),%r8        # a9a6f0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xda8>
  764e0e:	lea    0x60(%rsp),%rdx
  764e13:	mov    $0x2b,%esi
  764e18:	call   *0x355362(%rip)        # aba180 <_DYNAMIC+0x310>
  764e1e:	jmp    765284 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  764e23:	lea    0x3358de(%rip),%r9        # a9a708 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xdc0>
  764e2a:	xor    %edi,%edi
  764e2c:	lea    0x90(%rsp),%rsi
  764e34:	lea    0x130(%rsp),%rdx
  764e3c:	xor    %ecx,%ecx
  764e3e:	call   *0x3554ec(%rip)        # aba330 <_DYNAMIC+0x4c0>
  764e44:	jmp    765284 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  764e49:	add    $0xd0,%dl
  764e4c:	xor    %eax,%eax
  764e4e:	cmp    $0xa,%dl
  764e51:	adc    $0x1,%al
  764e53:	mov    %al,0x150(%rsp)
  764e5a:	lea    -0x6951ff(%rip),%rdi        # cfc62 <GCC_except_table0+0xd896>
  764e61:	lea    0x335db8(%rip),%rcx        # a9ac20 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x12d8>
  764e68:	lea    0x335c01(%rip),%r8        # a9aa70 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1128>
  764e6f:	lea    0x150(%rsp),%rdx
  764e77:	mov    $0x2b,%esi
  764e7c:	call   *0x3552fe(%rip)        # aba180 <_DYNAMIC+0x310>
  764e82:	jmp    765284 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  764e87:	mov    0x8(%rsp),%rax
  764e8c:	mov    %rax,0x60(%rsp)
  764e91:	mov    0x10(%rsp),%rax
  764e96:	mov    %rax,0x150(%rsp)
  764e9e:	mov    $0x1,%edi
  764ea3:	mov    %r15,%rsi
  764ea6:	call   *0x3552b4(%rip)        # aba160 <_DYNAMIC+0x2f0>
  764eac:	jmp    765284 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  764eb1:	mov    0x158(%rsp),%rax
  764eb9:	mov    %rax,0x60(%rsp)
  764ebe:	lea    -0x695263(%rip),%rdi        # cfc62 <GCC_except_table0+0xd896>
  764ec5:	lea    0x335cb4(%rip),%rcx        # a9ab80 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1238>
  764ecc:	lea    0x335bb5(%rip),%r8        # a9aa88 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1140>
  764ed3:	lea    0x60(%rsp),%rdx
  764ed8:	mov    $0x2b,%esi
  764edd:	call   *0x35529d(%rip)        # aba180 <_DYNAMIC+0x310>
  764ee3:	jmp    765284 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  764ee8:	mov    0x158(%rsp),%rax
  764ef0:	mov    %rax,0x60(%rsp)
  764ef5:	lea    -0x69529a(%rip),%rdi        # cfc62 <GCC_except_table0+0xd896>
  764efc:	lea    0x335c7d(%rip),%rcx        # a9ab80 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1238>
  764f03:	lea    0x335b7e(%rip),%r8        # a9aa88 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1140>
  764f0a:	lea    0x60(%rsp),%rdx
  764f0f:	mov    $0x2b,%esi
  764f14:	call   *0x355266(%rip)        # aba180 <_DYNAMIC+0x310>
  764f1a:	jmp    765284 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  764f1f:	mov    0x8(%rsp),%rax
  764f24:	mov    %rax,0x60(%rsp)
  764f29:	mov    0x10(%rsp),%rax
  764f2e:	mov    %rax,0x150(%rsp)
  764f36:	mov    $0x1,%edi
  764f3b:	mov    %r14,%rsi
  764f3e:	call   *0x35521c(%rip)        # aba160 <_DYNAMIC+0x2f0>
  764f44:	jmp    765284 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  764f49:	mov    0x8(%rsp),%rax
  764f4e:	mov    %rax,0x60(%rsp)
  764f53:	mov    0x10(%rsp),%rax
  764f58:	mov    %rax,0x150(%rsp)
  764f60:	mov    $0x1,%edi
  764f65:	mov    %r12,%rsi
  764f68:	call   *0x3551f2(%rip)        # aba160 <_DYNAMIC+0x2f0>
  764f6e:	jmp    765284 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  764f73:	lea    0x60(%rsp),%rdi
  764f78:	call   746440 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultNtNtCslbxve4rcJus_4gpui7runtime6CommitNtBZ_5ErrorEECs9C2G9YFESsD_29canonical_text_public_control>
  764f7d:	lea    -0x695544(%rip),%rdi        # cfa40 <GCC_except_table0+0xd674>
  764f84:	lea    0x3357ad(%rip),%rdx        # a9a738 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xdf0>
  764f8b:	mov    $0x4e,%esi
  764f90:	call   *0x355192(%rip)        # aba128 <_DYNAMIC+0x2b8>
  764f96:	jmp    765284 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  764f9b:	mov    $0x1,%al
  764f9d:	jmp    764e53 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1973>
  764fa2:	mov    $0x12,%eax
  764fa7:	jmp    764fae <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ace>
  764fa9:	mov    $0xe,%eax
  764fae:	mov    %rax,0x1e8(%rsp)
  764fb6:	mov    0x1e8(%rsp),%rax
  764fbe:	mov    %rax,0x60(%rsp)
  764fc3:	mov    0x18(%rsp),%rax
  764fc8:	mov    %rax,0x68(%rsp)
  764fcd:	mov    0xf8(%rsp),%rax
  764fd5:	mov    %rax,0x70(%rsp)
  764fda:	lea    -0x695600(%rip),%rdi        # cf9e1 <GCC_except_table0+0xd615>
  764fe1:	lea    0x335b78(%rip),%rcx        # a9ab60 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1218>
  764fe8:	lea    0x3354d9(%rip),%r8        # a9a4c8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xb80>
  764fef:	lea    0x60(%rsp),%rdx
  764ff4:	mov    $0x2a,%esi
  764ff9:	call   *0x355181(%rip)        # aba180 <_DYNAMIC+0x310>
  764fff:	jmp    765284 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  765004:	movq   $0xd,0x1f0(%rsp)
  765010:	movq   $0x0,0x1f8(%rsp)
  76501c:	mov    0x220(%rsp),%rax
  765024:	mov    %rax,0x90(%rsp)
  76502c:	mov    0x1f0(%rsp),%rax
  765034:	mov    0x1f8(%rsp),%rcx
  76503c:	movups 0x200(%rsp),%xmm0
  765044:	movups 0x210(%rsp),%xmm1
  76504c:	movaps %xmm1,0x80(%rsp)
  765054:	movaps %xmm0,0x70(%rsp)
  765059:	mov    %rax,0x60(%rsp)
  76505e:	mov    %rcx,0x68(%rsp)
  765063:	lea    -0x695408(%rip),%rdi        # cfc62 <GCC_except_table0+0xd896>
  76506a:	lea    0x335aef(%rip),%rcx        # a9ab60 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1218>
  765071:	lea    0x3355a8(%rip),%r8        # a9a620 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xcd8>
  765078:	lea    0x60(%rsp),%rdx
  76507d:	mov    $0x2b,%esi
  765082:	call   *0x3550f8(%rip)        # aba180 <_DYNAMIC+0x310>
  765088:	jmp    765284 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  76508d:	mov    $0xd,%eax
  765092:	movq   $0x0,0x2a0(%rsp)
  76509e:	jmp    7650ac <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1bcc>
  7650a0:	mov    $0xe,%eax
  7650a5:	jmp    7650ac <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1bcc>
  7650a7:	mov    $0x14,%eax
  7650ac:	mov    %rax,0x60(%rsp)
  7650b1:	mov    0x2a0(%rsp),%rax
  7650b9:	mov    %rax,0x68(%rsp)
  7650be:	mov    0x8(%rsp),%rax
  7650c3:	mov    %rax,0x70(%rsp)
  7650c8:	lea    -0x69546d(%rip),%rdi        # cfc62 <GCC_except_table0+0xd896>
  7650cf:	lea    0x335a8a(%rip),%rcx        # a9ab60 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1218>
  7650d6:	lea    0x33555b(%rip),%r8        # a9a638 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xcf0>
  7650dd:	lea    0x60(%rsp),%rdx
  7650e2:	mov    $0x2b,%esi
  7650e7:	call   *0x355093(%rip)        # aba180 <_DYNAMIC+0x310>
  7650ed:	jmp    765284 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  7650f2:	movq   $0xd,0x1f0(%rsp)
  7650fe:	movq   $0x0,0x1f8(%rsp)
  76510a:	jmp    765118 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1c38>
  76510c:	movq   $0xe,0x1f0(%rsp)
  765118:	mov    0x220(%rsp),%rax
  765120:	mov    %rax,0x90(%rsp)
  765128:	mov    0x1f0(%rsp),%rax
  765130:	mov    0x1f8(%rsp),%rcx
  765138:	movups 0x200(%rsp),%xmm0
  765140:	movups 0x210(%rsp),%xmm1
  765148:	movaps %xmm1,0x80(%rsp)
  765150:	movaps %xmm0,0x70(%rsp)
  765155:	mov    %rax,0x60(%rsp)
  76515a:	mov    %rcx,0x68(%rsp)
  76515f:	lea    -0x695504(%rip),%rdi        # cfc62 <GCC_except_table0+0xd896>
  765166:	lea    0x3359f3(%rip),%rcx        # a9ab60 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1218>
  76516d:	lea    0x3354f4(%rip),%r8        # a9a668 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xd20>
  765174:	lea    0x60(%rsp),%rdx
  765179:	mov    $0x2b,%esi
  76517e:	call   *0x354ffc(%rip)        # aba180 <_DYNAMIC+0x310>
  765184:	jmp    765284 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  765189:	mov    $0x1,%edi
  76518e:	mov    %r13,%rsi
  765191:	call   *0x354fc9(%rip)        # aba160 <_DYNAMIC+0x2f0>
  765197:	jmp    765284 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  76519c:	mov    0x68(%rsp),%r14
  7651a1:	mov    0x78(%rsp),%rcx
  7651a6:	mov    %rcx,%rax
  7651a9:	sub    %r14,%rax
  7651ac:	movabs $0xaaaaaaaaaaaaaaab,%rdx
  7651b6:	mul    %rdx
  7651b9:	cmp    %r14,%rcx
  7651bc:	jne    765213 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1d33>
  7651be:	mov    0x70(%rsp),%rax
  7651c3:	test   %rax,%rax
  7651c6:	je     7651e0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1d00>
  7651c8:	mov    0x60(%rsp),%rdi
  7651cd:	shl    $0x3,%rax
  7651d1:	lea    (%rax,%rax,2),%rsi
  7651d5:	mov    $0x8,%edx
  7651da:	call   *0x354ed0(%rip)        # aba0b0 <_DYNAMIC+0x240>
  7651e0:	mov    $0x8,%eax
  7651e5:	mov    %rax,0x20(%rsp)
  7651ea:	movq   $0x0,0x280(%rsp)
  7651f6:	xor    %ebx,%ebx
  7651f8:	lea    -0x69565f(%rip),%rdi        # cfba0 <GCC_except_table0+0xd7d4>
  7651ff:	lea    0x33583a(%rip),%rdx        # a9aa40 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x10f8>
  765206:	mov    $0x5d,%esi
  76520b:	call   *0x354ed7(%rip)        # aba0e8 <_DYNAMIC+0x278>
  765211:	jmp    765284 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  765213:	mov    %rdx,%rbx
  765216:	shr    $0x4,%rbx
  76521a:	add    $0x8,%r14
  76521e:	mov    0x354e8b(%rip),%r15        # aba0b0 <_DYNAMIC+0x240>
  765225:	jmp    765239 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1d59>
  765227:	nopw   0x0(%rax,%rax,1)
  765230:	add    $0x18,%r14
  765234:	dec    %rbx
  765237:	je     7651be <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1cde>
  765239:	mov    -0x8(%r14),%rsi
  76523d:	test   %rsi,%rsi
  765240:	je     765230 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1d50>
  765242:	mov    (%r14),%rdi
  765245:	mov    $0x1,%edx
  76524a:	call   *%r15
  76524d:	jmp    765230 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1d50>
  76524f:	lea    0x335802(%rip),%rdx        # a9aa58 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1110>
  765256:	mov    $0x3,%edi
  76525b:	mov    %rbx,%rsi
  76525e:	call   *0x354e7c(%rip)        # aba0e0 <_DYNAMIC+0x270>
  765264:	jmp    765284 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  765266:	mov    $0x1,%edi
  76526b:	mov    %r12,%rsi
  76526e:	call   *0x354eec(%rip)        # aba160 <_DYNAMIC+0x2f0>
  765274:	jmp    765284 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  765276:	mov    $0x1,%edi
  76527b:	mov    %r13,%rsi
  76527e:	call   *0x354edc(%rip)        # aba160 <_DYNAMIC+0x2f0>
  765284:	ud2
  765286:	xor    %eax,%eax
  765288:	jmp    764e53 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1973>
  76528d:	mov    %rax,%r15
  765290:	mov    $0x9,%esi
  765295:	mov    $0x1,%edx
  76529a:	mov    %rbp,%rdi
  76529d:	jmp    765490 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1fb0>
  7652a2:	mov    %rax,%r15
  7652a5:	mov    $0x4,%esi
  7652aa:	mov    $0x1,%edx
  7652af:	mov    %r13,%rdi
  7652b2:	jmp    765490 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1fb0>
  7652b7:	mov    %rax,%r15
  7652ba:	jmp    7654a3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1fc3>
  7652bf:	mov    %rax,%r15
  7652c2:	lea    0x150(%rsp),%rdi
  7652ca:	call   74cb60 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  7652cf:	jmp    7654a3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1fc3>
  7652d4:	mov    %rax,%r15
  7652d7:	jmp    765496 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1fb6>
  7652dc:	mov    %rax,%r15
  7652df:	jmp    765461 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1f81>
  7652e4:	mov    %rax,%r15
  7652e7:	jmp    765496 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1fb6>
  7652ec:	mov    %rax,%r15
  7652ef:	jmp    765483 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1fa3>
  7652f4:	mov    %rax,%r15
  7652f7:	jmp    765496 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1fb6>
  7652fc:	mov    %rax,%r15
  7652ff:	jmp    765496 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1fb6>
  765304:	mov    %rax,%r15
  765307:	jmp    765496 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1fb6>
  76530c:	mov    %rax,%r15
  76530f:	jmp    765496 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1fb6>
  765314:	mov    %rax,%r15
  765317:	jmp    76577a <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x229a>
  76531c:	mov    %rax,%r15
  76531f:	jmp    765496 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1fb6>
  765324:	mov    %rax,%r15
  765327:	mov    $0x770,%esi
  76532c:	mov    $0x8,%edx
  765331:	mov    %r14,%rdi
  765334:	jmp    765642 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2162>
  765339:	jmp    76539a <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1eba>
  76533b:	mov    %rax,%r15
  76533e:	jmp    76571b <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x223b>
  765343:	mov    %rax,%r15
  765346:	test   %r14,%r14
  765349:	je     765373 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1e93>
  76534b:	mov    $0x1,%edx
  765350:	mov    %rbp,%rdi
  765353:	mov    %r14,%rsi
  765356:	call   *0x354d54(%rip)        # aba0b0 <_DYNAMIC+0x240>
  76535c:	jmp    765373 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1e93>
  76535e:	jmp    76539a <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1eba>
  765360:	mov    %rax,%r15
  765363:	jmp    76554c <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x206c>
  765368:	mov    %rax,%r15
  76536b:	jmp    765624 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2144>
  765370:	mov    %rax,%r15
  765373:	lea    0x150(%rsp),%rdi
  76537b:	call   749a30 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtB4_4iter8adapters4skip4SkipNtNtCs2AWtUsOyxgP_3std3env4ArgsEECs9C2G9YFESsD_29canonical_text_public_control>
  765380:	lea    0x28(%rsp),%rdi
  765385:	call   747060 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtBG_6string6StringEECs9C2G9YFESsD_29canonical_text_public_control>
  76538a:	mov    %r15,%rdi
  76538d:	call   a98590 <_Unwind_Resume@plt>
  765392:	mov    %rax,%r15
  765395:	jmp    765588 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x20a8>
  76539a:	mov    %rax,%r15
  76539d:	lea    0x60(%rsp),%rdi
  7653a2:	call   74d7d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  7653a7:	mov    $0x1,%bpl
  7653aa:	jmp    7655d3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x20f3>
  7653af:	jmp    76558c <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x20ac>
  7653b4:	mov    %rax,%r15
  7653b7:	mov    $0x4,%esi
  7653bc:	jmp    7653c6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ee6>
  7653be:	mov    %rax,%r15
  7653c1:	mov    $0x9,%esi
  7653c6:	mov    $0x1,%edx
  7653cb:	mov    %r13,%rdi
  7653ce:	jmp    765683 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x21a3>
  7653d3:	mov    %r15,%rcx
  7653d6:	mov    %rax,%r15
  7653d9:	mov    0x8(%rsp),%rax
  7653de:	mov    %rax,0x60(%rsp)
  7653e3:	mov    %rcx,0x150(%rsp)
  7653eb:	jmp    76570e <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x222e>
  7653f0:	jmp    765520 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2040>
  7653f5:	mov    %rax,%r15
  7653f8:	mov    0x8(%rsp),%rax
  7653fd:	mov    %rax,0x60(%rsp)
  765402:	mov    0x10(%rsp),%rax
  765407:	mov    %rax,0x150(%rsp)
  76540f:	lea    0x2a8(%rsp),%rdi
  765417:	call   74cb60 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  76541c:	jmp    76570e <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x222e>
  765421:	jmp    765520 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2040>
  765426:	mov    %rax,%r15
  765429:	mov    0x8(%rsp),%rax
  76542e:	mov    %rax,0x60(%rsp)
  765433:	mov    0x10(%rsp),%rax
  765438:	mov    %rax,0x150(%rsp)
  765440:	jmp    765676 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2196>
  765445:	jmp    765520 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2040>
  76544a:	jmp    765520 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2040>
  76544f:	jmp    765520 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2040>
  765454:	mov    %rax,%r15
  765457:	lea    0x60(%rsp),%rdi
  76545c:	call   74ca70 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5error5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  765461:	mov    $0x8,%esi
  765466:	mov    $0x1,%edx
  76546b:	mov    %r14,%rdi
  76546e:	jmp    765490 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1fb0>
  765470:	call   *0x354c62(%rip)        # aba0d8 <_DYNAMIC+0x268>
  765476:	mov    %rax,%r15
  765479:	lea    0x60(%rsp),%rdi
  76547e:	call   74ca70 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5error5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  765483:	mov    $0xa,%esi
  765488:	mov    $0x1,%edx
  76548d:	mov    %r12,%rdi
  765490:	call   *0x354c1a(%rip)        # aba0b0 <_DYNAMIC+0x240>
  765496:	lea    0x100(%rsp),%rdi
  76549e:	call   747d90 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscl5MXVnO7Zx_10serde_json3map3MapNtNtCscdodAO9FK5_5alloc6string6StringNtNtBG_5value5ValueEECs9C2G9YFESsD_29canonical_text_public_control>
  7654a3:	lea    0x1f0(%rsp),%rdi
  7654ab:	call   74cb60 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  7654b0:	jmp    76571b <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x223b>
  7654b5:	call   *0x354c1d(%rip)        # aba0d8 <_DYNAMIC+0x268>
  7654bb:	mov    %rax,%r15
  7654be:	jmp    76554c <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x206c>
  7654c3:	mov    %r15,%rcx
  7654c6:	mov    %rax,%r15
  7654c9:	mov    0x8(%rsp),%rax
  7654ce:	mov    %rax,0x60(%rsp)
  7654d3:	mov    %rcx,0x150(%rsp)
  7654db:	jmp    76571b <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x223b>
  7654e0:	mov    %rax,%r15
  7654e3:	cmpq   $0xffffffffffffffff,0x18(%rsp)
  7654e9:	jne    76571b <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x223b>
  7654ef:	mov    0x280(%rsp),%rax
  7654f7:	test   %rax,%rax
  7654fa:	je     7657a6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x22c6>
  765500:	shl    $0x3,%rax
  765504:	lea    (%rax,%rax,2),%rsi
  765508:	mov    $0x8,%edx
  76550d:	mov    0x20(%rsp),%rdi
  765512:	call   *0x354b98(%rip)        # aba0b0 <_DYNAMIC+0x240>
  765518:	mov    %r15,%rdi
  76551b:	call   a98590 <_Unwind_Resume@plt>
  765520:	mov    %rax,%r15
  765523:	mov    0x8(%rsp),%rax
  765528:	mov    %rax,0x60(%rsp)
  76552d:	mov    0x10(%rsp),%rax
  765532:	mov    %rax,0x150(%rsp)
  76553a:	jmp    765689 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x21a9>
  76553f:	mov    %rax,%r15
  765542:	lea    0x60(%rsp),%rdi
  765547:	call   74d7d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  76554c:	mov    $0x1,%bpl
  76554f:	jmp    7655f3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2113>
  765554:	mov    %rax,%r15
  765557:	jmp    765689 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x21a9>
  76555c:	mov    %rax,%r15
  76555f:	mov    0x60(%rsp),%rsi
  765564:	test   %rsi,%rsi
  765567:	je     765588 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x20a8>
  765569:	mov    0x68(%rsp),%rdi
  76556e:	mov    $0x1,%edx
  765573:	call   *0x354b37(%rip)        # aba0b0 <_DYNAMIC+0x240>
  765579:	jmp    765588 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x20a8>
  76557b:	mov    %rax,%r15
  76557e:	lea    0x60(%rsp),%rdi
  765583:	call   748670 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui7runtime8SetErrorNtNtCscdodAO9FK5_5alloc6string6StringEECs9C2G9YFESsD_29canonical_text_public_control>
  765588:	xor    %ebp,%ebp
  76558a:	jmp    7655b9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x20d9>
  76558c:	mov    %rax,%r15
  76558f:	mov    $0x1,%bpl
  765592:	jmp    7655d3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x20f3>
  765594:	mov    %rax,%r15
  765597:	jmp    76571b <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x223b>
  76559c:	mov    %rax,%r15
  76559f:	mov    0x60(%rsp),%rsi
  7655a4:	mov    $0x1,%bpl
  7655a7:	test   %rsi,%rsi
  7655aa:	je     7655d3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x20f3>
  7655ac:	mov    0x68(%rsp),%rdi
  7655b1:	jmp    7655c8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x20e8>
  7655b3:	mov    %rax,%r15
  7655b6:	mov    $0x1,%bpl
  7655b9:	mov    0x28(%rsp),%rsi
  7655be:	test   %rsi,%rsi
  7655c1:	je     7655d3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x20f3>
  7655c3:	mov    0x30(%rsp),%rdi
  7655c8:	mov    $0x1,%edx
  7655cd:	call   *0x354add(%rip)        # aba0b0 <_DYNAMIC+0x240>
  7655d3:	mov    0x100(%rsp),%rsi
  7655db:	test   %rsi,%rsi
  7655de:	je     7655f3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2113>
  7655e0:	mov    0x108(%rsp),%rdi
  7655e8:	mov    $0x1,%edx
  7655ed:	call   *0x354abd(%rip)        # aba0b0 <_DYNAMIC+0x240>
  7655f3:	mov    0x260(%rsp),%r14
  7655fb:	test   %r14,%r14
  7655fe:	je     76561b <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x213b>
  765600:	mov    %r14,%rdi
  765603:	call   747fc0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui7runtime7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEEB1h_>
  765608:	mov    $0x770,%esi
  76560d:	mov    $0x8,%edx
  765612:	mov    %r14,%rdi
  765615:	call   *0x354a95(%rip)        # aba0b0 <_DYNAMIC+0x240>
  76561b:	test   %bpl,%bpl
  76561e:	je     76571b <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x223b>
  765624:	mov    0x2a8(%rsp),%rsi
  76562c:	test   %rsi,%rsi
  76562f:	je     76571b <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x223b>
  765635:	mov    0x2b0(%rsp),%rdi
  76563d:	mov    $0x1,%edx
  765642:	call   *0x354a68(%rip)        # aba0b0 <_DYNAMIC+0x240>
  765648:	jmp    76571b <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x223b>
  76564d:	mov    $0x770,%esi
  765652:	mov    $0x8,%edx
  765657:	mov    %r14,%rdi
  76565a:	call   *0x354a50(%rip)        # aba0b0 <_DYNAMIC+0x240>
  765660:	call   *0x354a72(%rip)        # aba0d8 <_DYNAMIC+0x268>
  765666:	mov    %rax,%r15
  765669:	lea    0x100(%rsp),%rdi
  765671:	call   74ca70 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5error5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  765676:	mov    $0x8,%esi
  76567b:	mov    $0x1,%edx
  765680:	mov    %r14,%rdi
  765683:	call   *0x354a27(%rip)        # aba0b0 <_DYNAMIC+0x240>
  765689:	mov    0x288(%rsp),%rcx
  765691:	test   %rcx,%rcx
  765694:	jne    76569c <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x21bc>
  765696:	xor    %ecx,%ecx
  765698:	xor    %eax,%eax
  76569a:	jmp    7656e9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2209>
  76569c:	mov    0x290(%rsp),%rdx
  7656a4:	mov    0x298(%rsp),%rax
  7656ac:	movq   $0x0,0x1f8(%rsp)
  7656b8:	mov    %rcx,0x200(%rsp)
  7656c0:	mov    %rdx,0x208(%rsp)
  7656c8:	movq   $0x0,0x218(%rsp)
  7656d4:	mov    %rcx,0x220(%rsp)
  7656dc:	mov    %rdx,0x228(%rsp)
  7656e4:	mov    $0x1,%ecx
  7656e9:	mov    %rcx,0x1f0(%rsp)
  7656f1:	mov    %rcx,0x210(%rsp)
  7656f9:	mov    %rax,0x230(%rsp)
  765701:	lea    0x1f0(%rsp),%rdi
  765709:	call   74ad50 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtCscdodAO9FK5_5alloc11collections5btree3map8IntoIterNtNtBK_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueEECs9C2G9YFESsD_29canonical_text_public_control>
  76570e:	lea    0x260(%rsp),%rdi
  765716:	call   74cb60 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  76571b:	mov    0x20(%rsp),%rax
  765720:	lea    0x8(%rax),%r14
  765724:	mov    0x354985(%rip),%r12        # aba0b0 <_DYNAMIC+0x240>
  76572b:	jmp    76573d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x225d>
  76572d:	nopl   (%rax)
  765730:	add    $0x18,%r14
  765734:	dec    %rbx
  765737:	je     7654ef <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x200f>
  76573d:	mov    -0x8(%r14),%rsi
  765741:	test   %rsi,%rsi
  765744:	je     765730 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2250>
  765746:	mov    (%r14),%rdi
  765749:	mov    $0x1,%edx
  76574e:	call   *%r12
  765751:	jmp    765730 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2250>
  765753:	call   *0x35497f(%rip)        # aba0d8 <_DYNAMIC+0x268>
  765759:	call   *0x354979(%rip)        # aba0d8 <_DYNAMIC+0x268>
  76575f:	mov    %rax,%r15
  765762:	mov    0x18(%rsp),%rsi
  765767:	test   %rsi,%rsi
  76576a:	je     76577a <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x229a>
  76576c:	mov    $0x1,%edx
  765771:	mov    %rbx,%rdi
  765774:	call   *0x354936(%rip)        # aba0b0 <_DYNAMIC+0x240>
  76577a:	mov    0x68(%rsp),%r14
  76577f:	mov    0x78(%rsp),%rcx
  765784:	mov    %rcx,%rax
  765787:	sub    %r14,%rax
  76578a:	movabs $0xaaaaaaaaaaaaaaab,%rdx
  765794:	mul    %rdx
  765797:	cmp    %r14,%rcx
  76579a:	jne    7657ae <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x22ce>
  76579c:	mov    0x70(%rsp),%rax
  7657a1:	test   %rax,%rax
  7657a4:	jne    7657ef <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x230f>
  7657a6:	mov    %r15,%rdi
  7657a9:	call   a98590 <_Unwind_Resume@plt>
  7657ae:	mov    %rdx,%rbx
  7657b1:	shr    $0x4,%rbx
  7657b5:	add    $0x8,%r14
  7657b9:	mov    0x3548f0(%rip),%r12        # aba0b0 <_DYNAMIC+0x240>
  7657c0:	jmp    7657d9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x22f9>
  7657c2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  7657d0:	add    $0x18,%r14
  7657d4:	dec    %rbx
  7657d7:	je     76579c <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x22bc>
  7657d9:	mov    -0x8(%r14),%rsi
  7657dd:	test   %rsi,%rsi
  7657e0:	je     7657d0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x22f0>
  7657e2:	mov    (%r14),%rdi
  7657e5:	mov    $0x1,%edx
  7657ea:	call   *%r12
  7657ed:	jmp    7657d0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x22f0>
  7657ef:	mov    0x60(%rsp),%rdi
  7657f4:	shl    $0x3,%rax
  7657f8:	lea    (%rax,%rax,2),%rsi
  7657fc:	mov    $0x8,%edx
  765801:	call   *0x3548a9(%rip)        # aba0b0 <_DYNAMIC+0x240>
  765807:	mov    %r15,%rdi
  76580a:	call   a98590 <_Unwind_Resume@plt>

canonical_text_public_control::mount bytes=2801 frame=3384

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000765810 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount>:
  765810:	push   %rbp
  765811:	push   %r15
  765813:	push   %r14
  765815:	push   %r13
  765817:	push   %r12
  765819:	push   %rbx
  76581a:	sub    $0xd08,%rsp
  765821:	mov    (%rdi),%rax
  765824:	mov    %rax,0x10(%rsp)
  765829:	mov    0x8(%rdi),%r14
  76582d:	mov    0x10(%rdi),%rbx
  765831:	movups -0x695c68(%rip),%xmm0        # cfbd0 <GCC_except_table0+0xd804>
  765838:	movups %xmm0,0xf8(%rsp)
  765840:	movq   $0x0,0x108(%rsp)
  76584c:	lea    0x3b0(%rsp),%rdi
  765854:	movabs $0x104000001a4,%r15
  76585e:	movss  -0x6a341e(%rip),%xmm0        # c2448 <GCC_except_table0+0x7c>
  765866:	mov    %r15,%rsi
  765869:	call   *0x354b49(%rip)        # aba3b8 <_DYNAMIC+0x548>
  76586f:	mov    0x3b0(%rsp),%r13
  765877:	cmp    $0xfffffffffffffffe,%r13
  76587b:	jne    765f52 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x742>
  765881:	lea    0x3b0(%rsp),%rdi
  765889:	call   7976d0 <_RNvXs_Cs9C2G9YFESsD_29canonical_text_public_controlNtB4_6EditorNtCslbxve4rcJus_4gpui4View7sources>
  76588e:	mov    0x3b0(%rsp),%rax
  765896:	movups 0x408(%rsp),%xmm0
  76589e:	movaps %xmm0,0x150(%rsp)
  7658a6:	movups 0x3f8(%rsp),%xmm0
  7658ae:	movaps %xmm0,0x140(%rsp)
  7658b6:	movups 0x3e8(%rsp),%xmm0
  7658be:	movaps %xmm0,0x130(%rsp)
  7658c6:	movups 0x3d8(%rsp),%xmm0
  7658ce:	movaps %xmm0,0x120(%rsp)
  7658d6:	movups 0x3c8(%rsp),%xmm1
  7658de:	movaps %xmm1,0x110(%rsp)
  7658e6:	movups 0x3b8(%rsp),%xmm2
  7658ee:	movups %xmm1,0xa0(%rsp)
  7658f6:	movups %xmm0,0xb0(%rsp)
  7658fe:	mov    0x130(%rsp),%rcx
  765906:	mov    %rcx,0xc0(%rsp)
  76590e:	mov    0x158(%rsp),%rcx
  765916:	mov    %rcx,0xe8(%rsp)
  76591e:	movups 0x148(%rsp),%xmm0
  765926:	movups %xmm0,0xd8(%rsp)
  76592e:	movups 0x138(%rsp),%xmm0
  765936:	movups %xmm0,0xc8(%rsp)
  76593e:	mov    %rax,0x88(%rsp)
  765946:	movups %xmm2,0x90(%rsp)
  76594e:	movl   $0x0,0x110(%rsp)
  765959:	movl   $0x434b0000,0x118(%rsp)
  765964:	movw   $0x0,0x11c(%rsp)
  76596e:	lea    0x3b0(%rsp),%rdi
  765976:	lea    0x110(%rsp),%rcx
  76597e:	mov    $0x1a4,%esi
  765983:	mov    $0x104,%edx
  765988:	call   *0x354a32(%rip)        # aba3c0 <_DYNAMIC+0x550>
  76598e:	mov    0x3b0(%rsp),%r13
  765996:	mov    0x3b8(%rsp),%ebp
  76599d:	mov    0x3bc(%rsp),%r12d
  7659a5:	cmp    $0x2,%r13
  7659a9:	je     765f9f <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x78f>
  7659af:	lea    0x3c0(%rsp),%rsi
  7659b7:	lea    0xb30(%rsp),%rdi
  7659bf:	mov    $0x1d8,%edx
  7659c4:	call   *0x354706(%rip)        # aba0d0 <memcpy@GLIBC_2.14>
  7659ca:	mov    %r13,0xb20(%rsp)
  7659d2:	mov    %ebp,0xb28(%rsp)
  7659d9:	mov    %r12d,0xb2c(%rsp)
  7659e1:	call   *0x3549e1(%rip)        # aba3c8 <_DYNAMIC+0x558>
  7659e7:	mov    %rax,%r12
  7659ea:	lea    0x110(%rsp),%rdi
  7659f2:	call   *0x3549d8(%rip)        # aba3d0 <_DYNAMIC+0x560>
  7659f8:	mov    %rbx,0x650(%rsp)
  765a00:	movl   $0x0,0x658(%rsp)
  765a0b:	movups 0xf4(%rsp),%xmm0
  765a13:	movups 0x100(%rsp),%xmm1
  765a1b:	movups %xmm0,0x65c(%rsp)
  765a23:	movups %xmm1,0x668(%rsp)
  765a2b:	movl   $0x0,0x678(%rsp)
  765a36:	movups 0x88(%rsp),%xmm0
  765a3e:	movups 0x98(%rsp),%xmm1
  765a46:	movups 0xa8(%rsp),%xmm2
  765a4e:	movups 0xb8(%rsp),%xmm3
  765a56:	movups %xmm0,0x5d8(%rsp)
  765a5e:	movups %xmm1,0x5e8(%rsp)
  765a66:	movups %xmm2,0x5f8(%rsp)
  765a6e:	movups %xmm3,0x608(%rsp)
  765a76:	movups 0xc8(%rsp),%xmm0
  765a7e:	movups %xmm0,0x618(%rsp)
  765a86:	movups 0xd8(%rsp),%xmm0
  765a8e:	movups %xmm0,0x628(%rsp)
  765a96:	mov    0xe8(%rsp),%rax
  765a9e:	mov    %rax,0x638(%rsp)
  765aa6:	lea    0x6b0(%rsp),%rdi
  765aae:	lea    0x110(%rsp),%rsi
  765ab6:	mov    0x354613(%rip),%rbx        # aba0d0 <memcpy@GLIBC_2.14>
  765abd:	mov    $0x298,%edx
  765ac2:	call   *%rbx
  765ac4:	lea    0x3b0(%rsp),%rdi
  765acc:	lea    0xb20(%rsp),%rsi
  765ad4:	mov    $0x1e8,%edx
  765ad9:	call   *%rbx
  765adb:	mov    0x10(%rsp),%rax
  765ae0:	mov    %rax,0x640(%rsp)
  765ae8:	mov    %r14,0x648(%rsp)
  765af0:	movq   $0x0,0x680(%rsp)
  765afc:	movq   $0x8,0x688(%rsp)
  765b08:	xorps  %xmm0,%xmm0
  765b0b:	movups %xmm0,0x690(%rsp)
  765b13:	movq   $0x8,0x6a0(%rsp)
  765b1f:	movq   $0x0,0x6a8(%rsp)
  765b2b:	movq   $0x0,0x9c8(%rsp)
  765b37:	movups %xmm0,0x598(%rsp)
  765b3f:	movups %xmm0,0x5a8(%rsp)
  765b47:	movups %xmm0,0x9b0(%rsp)
  765b4f:	movq   $0x1,0x9d0(%rsp)
  765b5b:	movq   $0x0,0x9d8(%rsp)
  765b67:	mov    %r12,0x9a0(%rsp)
  765b6f:	movq   $0x0,0x9e8(%rsp)
  765b7b:	movq   $0x0,0xa30(%rsp)
  765b87:	movups %xmm0,0x9f8(%rsp)
  765b8f:	movq   $0x0,0xa08(%rsp)
  765b9b:	movups %xmm0,0xa18(%rsp)
  765ba3:	movq   $0x0,0x948(%rsp)
  765baf:	movq   $0x8,0x950(%rsp)
  765bbb:	movups %xmm0,0x958(%rsp)
  765bc3:	movq   $0x0,0xa38(%rsp)
  765bcf:	movq   $0x0,0xa48(%rsp)
  765bdb:	movl   $0x1000101,0xb18(%rsp)
  765be6:	movw   $0x0,0xb1c(%rsp)
  765bf0:	movups %xmm0,0xa50(%rsp)
  765bf8:	movups %xmm0,0xa60(%rsp)
  765c00:	movq   $0x0,0xa70(%rsp)
  765c0c:	mov    %r15,0xa78(%rsp)
  765c14:	movsd  -0x6a2c3c(%rip),%xmm1        # c2fe0 <GCC_except_table0+0xc14>
  765c1c:	movsd  %xmm1,0xb10(%rsp)
  765c25:	movq   $0x1,0x9a8(%rsp)
  765c31:	movq   $0xffffffffffffffff,0x978(%rsp)
  765c3d:	movq   $0x0,0xa80(%rsp)
  765c49:	movq   $0x0,0xa90(%rsp)
  765c55:	movq   $0x8,0x968(%rsp)
  765c61:	movq   $0x0,0x970(%rsp)
  765c6d:	movb   $0x0,0xb1e(%rsp)
  765c75:	movups %xmm0,0xaf8(%rsp)
  765c7d:	movups %xmm0,0xae8(%rsp)
  765c85:	movups %xmm0,0xad8(%rsp)
  765c8d:	movups %xmm0,0xac8(%rsp)
  765c95:	movups %xmm0,0xab8(%rsp)
  765c9d:	movups %xmm0,0xaa8(%rsp)
  765ca5:	movups %xmm0,0xa98(%rsp)
  765cad:	movq   $0x0,0xb08(%rsp)
  765cb9:	call   *0x3543f9(%rip)        # aba0b8 <_DYNAMIC+0x248>
  765cbf:	mov    $0x770,%edi
  765cc4:	mov    $0x8,%esi
  765cc9:	call   *0x3543f1(%rip)        # aba0c0 <_DYNAMIC+0x250>
  765ccf:	test   %rax,%rax
  765cd2:	je     765edd <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x6cd>
  765cd8:	mov    %rax,%rbx
  765cdb:	lea    0x3b0(%rsp),%rsi
  765ce3:	mov    $0x770,%edx
  765ce8:	mov    %rax,%rdi
  765ceb:	call   *0x3543df(%rip)        # aba0d0 <memcpy@GLIBC_2.14>
  765cf1:	mov    %rbx,0x20(%rsp)
  765cf6:	lea    0x28(%rsp),%rdx
  765cfb:	movq   $0x0,(%rsp)
  765d03:	lea    0x28(%rsp),%rdi
  765d08:	mov    $0x8,%r8d
  765d0e:	mov    %rbx,%rsi
  765d11:	mov    $0x1,%ecx
  765d16:	xor    %r9d,%r9d
  765d19:	call   769c60 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB4_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE21describe_with_changedBW_>
  765d1e:	mov    0x28(%rsp),%r13
  765d23:	cmp    $0xfffffffffffffffe,%r13
  765d27:	jne    765ef2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x6e2>
  765d2d:	lea    0x28(%rsp),%rdi
  765d32:	mov    %rbx,%rsi
  765d35:	call   78d8e0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE7presentBO_>
  765d3a:	mov    0x28(%rsp),%r13
  765d3f:	cmp    $0xfffffffffffffffe,%r13
  765d43:	jne    765ef2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x6e2>
  765d49:	mov    0x20(%rsp),%rbx
  765d4e:	lea    0x3b0(%rsp),%rdi
  765d56:	mov    %rbx,%rsi
  765d59:	call   760ba0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack>
  765d5e:	test   %rbx,%rbx
  765d61:	je     765fb7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x7a7>
  765d67:	cmpb   $0x0,0x76e(%rbx)
  765d6e:	jne    765fbe <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x7ae>
  765d74:	cmpb   $0x1,0x76a(%rbx)
  765d7b:	jne    765fc5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x7b5>
  765d81:	mov    0x5c0(%rbx),%r12
  765d88:	mov    $0x1a,%eax
  765d8d:	mov    %rax,0x10(%rsp)
  765d92:	test   %r12,%r12
  765d95:	je     765fcf <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x7bf>
  765d9b:	mov    0x5b8(%rbx),%r13
  765da2:	shl    $0x6,%r12
  765da6:	lea    0x1e8(%rbx),%r14
  765dad:	xor    %ebp,%ebp
  765daf:	mov    0x3543b2(%rip),%r15        # aba168 <_DYNAMIC+0x2f8>
  765db6:	jmp    765dcd <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x5bd>
  765db8:	nopl   0x0(%rax,%rax,1)
  765dc0:	add    $0x40,%rbp
  765dc4:	cmp    %rbp,%r12
  765dc7:	je     765fcf <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x7bf>
  765dcd:	cmpb   $0x4,0x3d(%r13,%rbp,1)
  765dd3:	jne    765dc0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x5b0>
  765dd5:	mov    0x20(%r13,%rbp,1),%rsi
  765dda:	mov    %r14,%rdi
  765ddd:	call   *%r15
  765de0:	test   %al,%al
  765de2:	je     765dc0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x5b0>
  765de4:	mov    0x20(%r13,%rbp,1),%rsi
  765de9:	lea    0x5f0(%rbx),%r12
  765df0:	mov    %r12,%rdi
  765df3:	call   *0x354517(%rip)        # aba310 <_DYNAMIC+0x4a0>
  765df9:	cmpb   $0x0,0x76e(%rbx)
  765e00:	jne    766015 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x805>
  765e06:	mov    %rax,%r14
  765e09:	cmp    (%r12),%rax
  765e0d:	jne    76601c <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x80c>
  765e13:	mov    %rdx,%r15
  765e16:	mov    0x628(%rbx),%r12
  765e1d:	mov    0x630(%rbx),%r13
  765e24:	lea    0x3b0(%rsp),%rdi
  765e2c:	mov    %rbx,%rsi
  765e2f:	call   78d180 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE16resolve_identityBO_>
  765e34:	mov    0x3b0(%rsp),%rax
  765e3c:	mov    0x3b8(%rsp),%rdi
  765e44:	cmp    $0xfffffffffffffffe,%rax
  765e48:	jne    766023 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x813>
  765e4e:	mov    0x2e0(%rbx),%rsi
  765e55:	cmp    %rsi,%rdi
  765e58:	jae    766059 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x849>
  765e5e:	lea    (%rdi,%rdi,4),%rdi
  765e62:	shl    $0x3,%rdi
  765e66:	add    0x2d8(%rbx),%rdi
  765e6d:	call   *0x354565(%rip)        # aba3d8 <_DYNAMIC+0x568>
  765e73:	test   %al,%al
  765e75:	je     76606b <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x85b>
  765e7b:	mov    %r14,0x628(%rbx)
  765e82:	mov    %r15,0x630(%rbx)
  765e89:	movq   $0x0,0x758(%rbx)
  765e94:	lea    0x110(%rsp),%rdi
  765e9c:	mov    %rbx,%rsi
  765e9f:	mov    %r12,%rdx
  765ea2:	mov    %r13,%rcx
  765ea5:	call   770db0 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE20publish_focus_changeB12_>
  765eaa:	cmpl   $0xfffffffe,0x110(%rsp)
  765eb2:	jne    7660b3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x8a3>
  765eb8:	lea    0x3b0(%rsp),%rdi
  765ec0:	mov    %rbx,%rsi
  765ec3:	call   760ba0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack>
  765ec8:	mov    %rbx,%rax
  765ecb:	add    $0xd08,%rsp
  765ed2:	pop    %rbx
  765ed3:	pop    %r12
  765ed5:	pop    %r13
  765ed7:	pop    %r14
  765ed9:	pop    %r15
  765edb:	pop    %rbp
  765edc:	ret
  765edd:	mov    $0x8,%edi
  765ee2:	mov    $0x770,%esi
  765ee7:	call   *0x3541db(%rip)        # aba0c8 <_DYNAMIC+0x258>
  765eed:	jmp    766222 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xa12>
  765ef2:	mov    0x30(%rsp),%rbp
  765ef7:	movups 0x38(%rsp),%xmm0
  765efc:	movaps %xmm0,0x70(%rsp)
  765f01:	movups 0x48(%rsp),%xmm0
  765f06:	movaps %xmm0,0x60(%rsp)
  765f0b:	movzbl 0x58(%rsp),%r15d
  765f11:	mov    0x59(%rsp),%eax
  765f15:	mov    %eax,0x18(%rsp)
  765f19:	mov    0x5c(%rsp),%eax
  765f1d:	mov    %eax,0x1b(%rsp)
  765f21:	mov    0x20(%rsp),%rbx
  765f26:	test   %rbx,%rbx
  765f29:	je     765f46 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x736>
  765f2b:	mov    %rbx,%rdi
  765f2e:	call   747fc0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui7runtime7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEEB1h_>
  765f33:	mov    $0x770,%esi
  765f38:	mov    $0x8,%edx
  765f3d:	mov    %rbx,%rdi
  765f40:	call   *0x35416a(%rip)        # aba0b0 <_DYNAMIC+0x240>
  765f46:	mov    %rbp,%r12
  765f49:	shr    $0x20,%r12
  765f4d:	jmp    7661a9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x999>
  765f52:	mov    0x3b8(%rsp),%rbp
  765f5a:	mov    %rbp,%r12
  765f5d:	shr    $0x20,%r12
  765f61:	movups 0x3c0(%rsp),%xmm0
  765f69:	movaps %xmm0,0x70(%rsp)
  765f6e:	movups 0x3d0(%rsp),%xmm0
  765f76:	movaps %xmm0,0x60(%rsp)
  765f7b:	movzbl 0x3e0(%rsp),%r15d
  765f84:	mov    0x3e1(%rsp),%eax
  765f8b:	mov    %eax,0x18(%rsp)
  765f8f:	mov    0x3e4(%rsp),%eax
  765f96:	mov    %eax,0x1b(%rsp)
  765f9a:	jmp    76618e <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x97e>
  765f9f:	lea    0x88(%rsp),%rdi
  765fa7:	call   747e10 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui6source7SourcesNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEEB1g_>
  765fac:	mov    $0x23,%r13d
  765fb2:	jmp    76618e <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x97e>
  765fb7:	mov    $0xd,%eax
  765fbc:	jmp    765fca <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x7ba>
  765fbe:	mov    $0xe,%eax
  765fc3:	jmp    765fca <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x7ba>
  765fc5:	mov    $0x12,%eax
  765fca:	mov    %rax,0x10(%rsp)
  765fcf:	mov    0x10(%rsp),%rax
  765fd4:	mov    %rax,0x3b0(%rsp)
  765fdc:	movq   $0x0,0x3b8(%rsp)
  765fe8:	lea    -0x69660e(%rip),%rdi        # cf9e1 <GCC_except_table0+0xd615>
  765fef:	lea    0x334b6a(%rip),%rcx        # a9ab60 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1218>
  765ff6:	lea    0x3344cb(%rip),%r8        # a9a4c8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xb80>
  765ffd:	lea    0x3b0(%rsp),%rdx
  766005:	mov    $0x2a,%esi
  76600a:	call   *0x354170(%rip)        # aba180 <_DYNAMIC+0x310>
  766010:	jmp    766222 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xa12>
  766015:	mov    $0xe,%eax
  76601a:	jmp    766070 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x860>
  76601c:	mov    $0x11,%eax
  766021:	jmp    76603b <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x82b>
  766023:	movups 0x3c0(%rsp),%xmm0
  76602b:	movups 0x3d0(%rsp),%xmm1
  766033:	movzbl 0x3e0(%rsp),%ecx
  76603b:	mov    0x3e1(%rsp),%edx
  766042:	mov    0x3e4(%rsp),%esi
  766049:	mov    %esi,0xb23(%rsp)
  766050:	mov    %edx,0xb20(%rsp)
  766057:	jmp    766070 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x860>
  766059:	lea    0x335040(%rip),%rdx        # a9b0a0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1758>
  766060:	call   *0x35407a(%rip)        # aba0e0 <_DYNAMIC+0x270>
  766066:	jmp    766222 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xa12>
  76606b:	mov    $0x16,%eax
  766070:	mov    %rax,0x110(%rsp)
  766078:	mov    %rdi,0x118(%rsp)
  766080:	movups %xmm0,0x120(%rsp)
  766088:	movups %xmm1,0x130(%rsp)
  766090:	mov    %cl,0x140(%rsp)
  766097:	mov    0xb20(%rsp),%eax
  76609e:	mov    0xb23(%rsp),%ecx
  7660a5:	mov    %eax,0x141(%rsp)
  7660ac:	mov    %ecx,0x144(%rsp)
  7660b3:	mov    0x140(%rsp),%rax
  7660bb:	mov    %rax,0x3e0(%rsp)
  7660c3:	mov    0x110(%rsp),%rax
  7660cb:	mov    0x118(%rsp),%rcx
  7660d3:	movups 0x120(%rsp),%xmm0
  7660db:	movups 0x130(%rsp),%xmm1
  7660e3:	movaps %xmm1,0x3d0(%rsp)
  7660eb:	movaps %xmm0,0x3c0(%rsp)
  7660f3:	mov    %rax,0x3b0(%rsp)
  7660fb:	mov    %rcx,0x3b8(%rsp)
  766103:	lea    -0x6964a8(%rip),%rdi        # cfc62 <GCC_except_table0+0xd896>
  76610a:	lea    0x334a4f(%rip),%rcx        # a9ab60 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1218>
  766111:	lea    0x3349b8(%rip),%r8        # a9aad0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1188>
  766118:	lea    0x3b0(%rsp),%rdx
  766120:	mov    $0x2b,%esi
  766125:	call   *0x354055(%rip)        # aba180 <_DYNAMIC+0x310>
  76612b:	jmp    766222 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xa12>
  766130:	mov    %rax,%r15
  766133:	mov    $0x770,%esi
  766138:	mov    $0x8,%edx
  76613d:	mov    %rbx,%rdi
  766140:	call   *0x353f6a(%rip)        # aba0b0 <_DYNAMIC+0x240>
  766146:	mov    %r15,%rdi
  766149:	call   a98590 <_Unwind_Resume@plt>
  76614e:	mov    %rax,%r15
  766151:	jmp    76626c <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xa5c>
  766156:	mov    %rax,%rdi
  766159:	call   *0x353fa9(%rip)        # aba108 <_DYNAMIC+0x298>
  76615f:	mov    %rax,%r12
  766162:	mov    %rdx,%r13
  766165:	mov    (%rdx),%rax
  766168:	test   %rax,%rax
  76616b:	je     766172 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x962>
  76616d:	mov    %r12,%rdi
  766170:	call   *%rax
  766172:	mov    0x8(%r13),%rsi
  766176:	test   %rsi,%rsi
  766179:	je     766188 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x978>
  76617b:	mov    0x10(%r13),%rdx
  76617f:	mov    %r12,%rdi
  766182:	call   *0x353f28(%rip)        # aba0b0 <_DYNAMIC+0x240>
  766188:	mov    $0xf,%r13d
  76618e:	cmpq   $0x0,0x10(%rsp)
  766194:	je     7661a9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x999>
  766196:	mov    $0x1,%edx
  76619b:	mov    %r14,%rdi
  76619e:	mov    0x10(%rsp),%rsi
  7661a3:	call   *0x353f07(%rip)        # aba0b0 <_DYNAMIC+0x240>
  7661a9:	mov    %r13,0x110(%rsp)
  7661b1:	shl    $0x20,%r12
  7661b5:	mov    %ebp,%eax
  7661b7:	or     %r12,%rax
  7661ba:	mov    %rax,0x118(%rsp)
  7661c2:	movaps 0x70(%rsp),%xmm0
  7661c7:	movups %xmm0,0x120(%rsp)
  7661cf:	movaps 0x60(%rsp),%xmm0
  7661d4:	movups %xmm0,0x130(%rsp)
  7661dc:	mov    %r15b,0x140(%rsp)
  7661e4:	mov    0x18(%rsp),%eax
  7661e8:	mov    0x1b(%rsp),%ecx
  7661ec:	mov    %eax,0x141(%rsp)
  7661f3:	mov    %ecx,0x144(%rsp)
  7661fa:	lea    -0x69659f(%rip),%rdi        # cfc62 <GCC_except_table0+0xd896>
  766201:	lea    0x334958(%rip),%rcx        # a9ab60 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1218>
  766208:	lea    0x3348a9(%rip),%r8        # a9aab8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1170>
  76620f:	lea    0x110(%rsp),%rdx
  766217:	mov    $0x2b,%esi
  76621c:	call   *0x353f5e(%rip)        # aba180 <_DYNAMIC+0x310>
  766222:	ud2
  766224:	mov    %rax,%r15
  766227:	mov    0x8(%r13),%rsi
  76622b:	test   %rsi,%rsi
  76622e:	je     766279 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xa69>
  766230:	mov    0x10(%r13),%rdx
  766234:	mov    %r12,%rdi
  766237:	call   *0x353e73(%rip)        # aba0b0 <_DYNAMIC+0x240>
  76623d:	jmp    766279 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xa69>
  76623f:	call   *0x353ecb(%rip)        # aba110 <_DYNAMIC+0x2a0>
  766245:	mov    %rax,%r15
  766248:	jmp    766279 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xa69>
  76624a:	mov    %rax,%r15
  76624d:	mov    0x20(%rsp),%rdi
  766252:	call   747f60 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui7runtime3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEEB1d_>
  766257:	jmp    7662f3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xae3>
  76625c:	mov    %rax,%r15
  76625f:	lea    0xb20(%rsp),%rdi
  766267:	call   74d2e0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas6canvas6CanvasECs9C2G9YFESsD_29canonical_text_public_control>
  76626c:	lea    0x88(%rsp),%rdi
  766274:	call   747e10 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui6source7SourcesNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEEB1g_>
  766279:	cmpq   $0x0,0x10(%rsp)
  76627f:	je     7662f3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xae3>
  766281:	mov    $0x1,%edx
  766286:	mov    %r14,%rdi
  766289:	mov    0x10(%rsp),%rsi
  76628e:	call   *0x353e1c(%rip)        # aba0b0 <_DYNAMIC+0x240>
  766294:	mov    %r15,%rdi
  766297:	call   a98590 <_Unwind_Resume@plt>
  76629c:	call   *0x353e36(%rip)        # aba0d8 <_DYNAMIC+0x268>
  7662a2:	mov    %rax,%r15
  7662a5:	lea    0x110(%rsp),%rdi
  7662ad:	call   74d7d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  7662b2:	mov    %r15,%rdi
  7662b5:	call   a98590 <_Unwind_Resume@plt>
  7662ba:	jmp    7662c3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xab3>
  7662bc:	jmp    7662be <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xaae>
  7662be:	mov    %rax,%r15
  7662c1:	jmp    7662d3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xac3>
  7662c3:	mov    %rax,%r15
  7662c6:	lea    0x3b0(%rsp),%rdi
  7662ce:	call   74d7d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  7662d3:	mov    %rbx,%rdi
  7662d6:	call   747f60 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui7runtime3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEEB1d_>
  7662db:	jmp    7662f3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xae3>
  7662dd:	call   *0x353df5(%rip)        # aba0d8 <_DYNAMIC+0x268>
  7662e3:	mov    %rax,%r15
  7662e6:	lea    0x3b0(%rsp),%rdi
  7662ee:	call   747fc0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui7runtime7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEEB1h_>
  7662f3:	mov    %r15,%rdi
  7662f6:	call   a98590 <_Unwind_Resume@plt>
  7662fb:	call   *0x353dd7(%rip)        # aba0d8 <_DYNAMIC+0x268>

canonical_text_public_control::source bytes=2078 frame=88

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000766310 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source>:
  766310:	push   %r15
  766312:	push   %r14
  766314:	push   %rbx
  766315:	sub    $0x40,%rsp
  766319:	mov    %rsi,0x20(%rsp)
  76631e:	mov    %rdx,0x28(%rsp)
  766323:	lea    -0x3(%rdx),%rax
  766327:	cmp    $0xa,%rax
  76632b:	ja     766a6a <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x75a>
  766331:	mov    %rdi,%rbx
  766334:	lea    -0x6a2327(%rip),%rcx        # c4014 <GCC_except_table0+0x1c48>
  76633b:	movslq (%rcx,%rax,4),%rax
  76633f:	add    %rcx,%rax
  766342:	jmp    *%rax
  766344:	lea    -0x69692c(%rip),%rax        # cfa1f <GCC_except_table0+0xd653>
  76634b:	mov    %rsi,%rdi
  76634e:	mov    %rax,%rsi
  766351:	call   *0x354021(%rip)        # aba378 <bcmp@GLIBC_2.2.5>
  766357:	test   %eax,%eax
  766359:	jne    766a6a <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x75a>
  76635f:	call   *0x353d53(%rip)        # aba0b8 <_DYNAMIC+0x248>
  766365:	mov    $0x1b80,%edi
  76636a:	mov    $0x1,%esi
  76636f:	call   *0x353d4b(%rip)        # aba0c0 <_DYNAMIC+0x250>
  766375:	test   %rax,%rax
  766378:	je     766a99 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x789>
  76637e:	mov    %rax,%r14
  766381:	movups -0x69675e(%rip),%xmm0        # cfc2a <GCC_except_table0+0xd85e>
  766388:	movups %xmm0,0x20(%rax)
  76638c:	movabs $0x20aad7a9d7a8d7a7,%rax
  766396:	mov    %rax,0x2f(%r14)
  76639a:	movups -0x696787(%rip),%xmm1        # cfc1a <GCC_except_table0+0xd84e>
  7663a1:	movups %xmm1,0x10(%r14)
  7663a6:	movups -0x6967a3(%rip),%xmm2        # cfc0a <GCC_except_table0+0xd83e>
  7663ad:	movups %xmm2,(%r14)
  7663b1:	movups %xmm2,0x37(%r14)
  7663b6:	movups %xmm1,0x47(%r14)
  7663bb:	movups %xmm0,0x57(%r14)
  7663c0:	mov    %rax,0x66(%r14)
  7663c4:	movups %xmm2,0x6e(%r14)
  7663c9:	movups %xmm1,0x7e(%r14)
  7663ce:	movups 0x20(%r14),%xmm0
  7663d3:	movups %xmm0,0x8e(%r14)
  7663db:	movups 0x30(%r14),%xmm0
  7663e0:	movups %xmm0,0x9e(%r14)
  7663e8:	movups 0x40(%r14),%xmm0
  7663ed:	movups %xmm0,0xae(%r14)
  7663f5:	movups 0x50(%r14),%xmm0
  7663fa:	movups %xmm0,0xbe(%r14)
  766402:	mov    0x5e(%r14),%rax
  766406:	mov    %rax,0xcc(%r14)
  76640d:	mov    0x66(%r14),%rax
  766411:	mov    %rax,0xd4(%r14)
  766418:	lea    0xdc(%r14),%rdi
  76641f:	mov    0x353caa(%rip),%r15        # aba0d0 <memcpy@GLIBC_2.14>
  766426:	mov    $0xdc,%edx
  76642b:	mov    %r14,%rsi
  76642e:	call   *%r15
  766431:	lea    0x1b8(%r14),%rdi
  766438:	mov    $0x1b8,%edx
  76643d:	mov    %r14,%rsi
  766440:	call   *%r15
  766443:	lea    0x370(%r14),%rdi
  76644a:	mov    $0x370,%edx
  76644f:	mov    %r14,%rsi
  766452:	call   *%r15
  766455:	lea    0x6e0(%r14),%rdi
  76645c:	mov    $0x6e0,%edx
  766461:	mov    %r14,%rsi
  766464:	call   *%r15
  766467:	mov    %r14,%rdi
  76646a:	add    $0xdc0,%rdi
  766471:	mov    $0xdc0,%edx
  766476:	mov    %r14,%rsi
  766479:	call   *%r15
  76647c:	movq   $0x1b80,(%rbx)
  766483:	mov    %r14,0x8(%rbx)
  766487:	movq   $0x1b80,0x10(%rbx)
  76648f:	jmp    766a60 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x750>
  766494:	mov    $0x74706d65,%eax
  766499:	xor    (%rsi),%eax
  76649b:	movzbl 0x4(%rsi),%ecx
  76649f:	xor    $0x79,%ecx
  7664a2:	or     %eax,%ecx
  7664a4:	je     7669fd <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x6ed>
  7664aa:	mov    $0x6562616c,%eax
  7664af:	xor    (%rsi),%eax
  7664b1:	movzbl 0x4(%rsi),%ecx
  7664b5:	xor    $0x6c,%ecx
  7664b8:	or     %eax,%ecx
  7664ba:	je     766a16 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x706>
  7664c0:	lea    -0x696aa5(%rip),%rax        # cfa22 <GCC_except_table0+0xd656>
  7664c7:	mov    %rsi,%rdi
  7664ca:	mov    %rax,%rsi
  7664cd:	call   *0x353ea5(%rip)        # aba378 <bcmp@GLIBC_2.2.5>
  7664d3:	test   %eax,%eax
  7664d5:	jne    766a6a <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x75a>
  7664db:	call   *0x353bd7(%rip)        # aba0b8 <_DYNAMIC+0x248>
  7664e1:	mov    $0x880,%edi
  7664e6:	mov    $0x1,%esi
  7664eb:	call   *0x353bcf(%rip)        # aba0c0 <_DYNAMIC+0x250>
  7664f1:	test   %rax,%rax
  7664f4:	je     766ae9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x7d9>
  7664fa:	mov    %rax,%r14
  7664fd:	movups -0x69690c(%rip),%xmm0        # cfbf8 <GCC_except_table0+0xd82c>
  766504:	movups %xmm0,0x10(%rax)
  766508:	movups -0x696927(%rip),%xmm1        # cfbe8 <GCC_except_table0+0xd81c>
  76650f:	movups %xmm1,(%rax)
  766512:	movw   $0xa0d,0x20(%rax)
  766518:	movups %xmm1,0x22(%rax)
  76651c:	movups %xmm0,0x32(%rax)
  766520:	movw   $0xa0d,0x42(%rax)
  766526:	movups %xmm1,0x44(%rax)
  76652a:	movups %xmm0,0x54(%rax)
  76652e:	movzwl 0x20(%rax),%eax
  766532:	mov    %ax,0x64(%r14)
  766537:	mov    0x22(%r14),%rax
  76653b:	mov    %rax,0x66(%r14)
  76653f:	mov    0x2a(%r14),%eax
  766543:	mov    %eax,0x6e(%r14)
  766547:	movzwl 0x2e(%r14),%eax
  76654c:	mov    %ax,0x72(%r14)
  766551:	movups 0x30(%r14),%xmm0
  766556:	movups %xmm0,0x74(%r14)
  76655b:	mov    0x40(%r14),%eax
  76655f:	mov    %eax,0x84(%r14)
  766566:	lea    0x88(%r14),%rdi
  76656d:	mov    0x353b5c(%rip),%r15        # aba0d0 <memcpy@GLIBC_2.14>
  766574:	mov    $0x88,%edx
  766579:	mov    %r14,%rsi
  76657c:	call   *%r15
  76657f:	lea    0x110(%r14),%rdi
  766586:	mov    $0x110,%edx
  76658b:	mov    %r14,%rsi
  76658e:	call   *%r15
  766591:	lea    0x220(%r14),%rdi
  766598:	mov    $0x220,%edx
  76659d:	mov    %r14,%rsi
  7665a0:	call   *%r15
  7665a3:	mov    %r14,%rdi
  7665a6:	add    $0x440,%rdi
  7665ad:	mov    $0x440,%edx
  7665b2:	mov    %r14,%rsi
  7665b5:	call   *%r15
  7665b8:	movq   $0x880,(%rbx)
  7665bf:	mov    %r14,0x8(%rbx)
  7665c3:	movq   $0x880,0x10(%rbx)
  7665cb:	jmp    766a60 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x750>
  7665d0:	cmpl   $0x796e6974,(%rsi)
  7665d6:	jne    766a6a <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x75a>
  7665dc:	call   *0x353ad6(%rip)        # aba0b8 <_DYNAMIC+0x248>
  7665e2:	mov    $0x1,%edi
  7665e7:	mov    $0x1,%esi
  7665ec:	call   *0x353ace(%rip)        # aba0c0 <_DYNAMIC+0x250>
  7665f2:	test   %rax,%rax
  7665f5:	je     766aa9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x799>
  7665fb:	movb   $0x61,(%rax)
  7665fe:	movq   $0x1,(%rbx)
  766605:	mov    %rax,0x8(%rbx)
  766609:	movq   $0x1,0x10(%rbx)
  766611:	jmp    766a60 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x750>
  766616:	lea    -0x696bf6(%rip),%rax        # cfa27 <GCC_except_table0+0xd65b>
  76661d:	mov    %rsi,%rdi
  766620:	mov    %rax,%rsi
  766623:	call   *0x353d4f(%rip)        # aba378 <bcmp@GLIBC_2.2.5>
  766629:	test   %eax,%eax
  76662b:	jne    766a6a <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x75a>
  766631:	call   *0x353a81(%rip)        # aba0b8 <_DYNAMIC+0x248>
  766637:	mov    $0x580,%edi
  76663c:	mov    $0x1,%esi
  766641:	call   *0x353a79(%rip)        # aba0c0 <_DYNAMIC+0x250>
  766647:	test   %rax,%rax
  76664a:	je     766ab9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x7a9>
  766650:	mov    %rax,%r14
  766653:	movabs $0x616c0aa880e20a0d,%rax
  76665d:	mov    %rax,(%r14)
  766660:	movl   $0xa747361,0x7(%r14)
  766668:	mov    %rax,0xb(%r14)
  76666c:	movl   $0xa747361,0x12(%r14)
  766674:	movups (%r14),%xmm0
  766678:	movups %xmm0,0x16(%r14)
  76667d:	mov    0xe(%r14),%rax
  766681:	mov    %rax,0x24(%r14)
  766685:	movups %xmm0,0x2c(%r14)
  76668a:	movups 0x10(%r14),%xmm1
  76668f:	movups %xmm1,0x3c(%r14)
  766694:	mov    0x1c(%r14),%rax
  766698:	mov    %rax,0x48(%r14)
  76669c:	mov    0x24(%r14),%rax
  7666a0:	mov    %rax,0x50(%r14)
  7666a4:	movups %xmm0,0x58(%r14)
  7666a9:	movups %xmm1,0x68(%r14)
  7666ae:	mov    0x20(%r14),%eax
  7666b2:	mov    %eax,0x78(%r14)
  7666b6:	mov    0x24(%r14),%rax
  7666ba:	mov    %rax,0x7c(%r14)
  7666be:	mov    0x2c(%r14),%eax
  7666c2:	mov    %eax,0x84(%r14)
  7666c9:	movups 0x30(%r14),%xmm0
  7666ce:	movups %xmm0,0x88(%r14)
  7666d6:	mov    0x40(%r14),%rax
  7666da:	mov    %rax,0x98(%r14)
  7666e1:	mov    0x48(%r14),%rax
  7666e5:	mov    %rax,0xa0(%r14)
  7666ec:	mov    0x50(%r14),%rax
  7666f0:	mov    %rax,0xa8(%r14)
  7666f7:	lea    0xb0(%r14),%rdi
  7666fe:	mov    0x3539cb(%rip),%r15        # aba0d0 <memcpy@GLIBC_2.14>
  766705:	mov    $0xb0,%edx
  76670a:	mov    %r14,%rsi
  76670d:	call   *%r15
  766710:	lea    0x160(%r14),%rdi
  766717:	mov    $0x160,%edx
  76671c:	mov    %r14,%rsi
  76671f:	call   *%r15
  766722:	mov    %r14,%rdi
  766725:	add    $0x2c0,%rdi
  76672c:	mov    $0x2c0,%edx
  766731:	mov    %r14,%rsi
  766734:	call   *%r15
  766737:	movq   $0x580,(%rbx)
  76673e:	mov    %r14,0x8(%rbx)
  766742:	movq   $0x580,0x10(%rbx)
  76674a:	jmp    766a60 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x750>
  76674f:	movabs $0x3364657070617277,%rax
  766759:	xor    (%rsi),%rax
  76675c:	movzwl 0x8(%rsi),%ecx
  766760:	xor    $0x6b32,%rcx
  766767:	or     %rax,%rcx
  76676a:	jne    766a6a <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x75a>
  766770:	call   *0x353942(%rip)        # aba0b8 <_DYNAMIC+0x248>
  766776:	mov    $0x8000,%edi
  76677b:	mov    $0x1,%esi
  766780:	call   *0x35393a(%rip)        # aba0c0 <_DYNAMIC+0x250>
  766786:	test   %rax,%rax
  766789:	je     766ac9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x7b9>
  76678f:	mov    %rax,%r14
  766792:	movabs $0x6161616161616161,%rax
  76679c:	mov    %rax,(%r14)
  76679f:	mov    %rax,0x8(%r14)
  7667a3:	movups (%r14),%xmm0
  7667a7:	movups %xmm0,0x10(%r14)
  7667ac:	movups %xmm0,0x20(%r14)
  7667b1:	movups %xmm0,0x30(%r14)
  7667b6:	movups %xmm0,0x40(%r14)
  7667bb:	movups %xmm0,0x50(%r14)
  7667c0:	movups %xmm0,0x60(%r14)
  7667c5:	movups %xmm0,0x70(%r14)
  7667ca:	movups %xmm0,0xa0(%r14)
  7667d2:	movups %xmm0,0xe0(%r14)
  7667da:	movups %xmm0,0xb0(%r14)
  7667e2:	movups %xmm0,0xf0(%r14)
  7667ea:	movups %xmm0,0xd0(%r14)
  7667f2:	movups %xmm0,0xc0(%r14)
  7667fa:	movups %xmm0,0x90(%r14)
  766802:	movups %xmm0,0x80(%r14)
  76680a:	lea    0x100(%r14),%rdi
  766811:	mov    0x3538b8(%rip),%r15        # aba0d0 <memcpy@GLIBC_2.14>
  766818:	mov    $0x100,%edx
  76681d:	mov    %r14,%rsi
  766820:	call   *%r15
  766823:	lea    0x200(%r14),%rdi
  76682a:	mov    $0x200,%edx
  76682f:	mov    %r14,%rsi
  766832:	call   *%r15
  766835:	lea    0x400(%r14),%rdi
  76683c:	mov    $0x400,%edx
  766841:	mov    %r14,%rsi
  766844:	call   *%r15
  766847:	lea    0x800(%r14),%rdi
  76684e:	mov    $0x800,%edx
  766853:	mov    %r14,%rsi
  766856:	call   *%r15
  766859:	lea    0x1000(%r14),%rdi
  766860:	mov    $0x1000,%edx
  766865:	mov    %r14,%rsi
  766868:	call   *%r15
  76686b:	lea    0x2000(%r14),%rdi
  766872:	mov    $0x2000,%edx
  766877:	mov    %r14,%rsi
  76687a:	call   *%r15
  76687d:	mov    %r14,%rdi
  766880:	add    $0x4000,%rdi
  766887:	mov    $0x4000,%edx
  76688c:	mov    %r14,%rsi
  76688f:	call   *%r15
  766892:	movq   $0x8000,(%rbx)
  766899:	mov    %r14,0x8(%rbx)
  76689d:	movq   $0x8000,0x10(%rbx)
  7668a5:	jmp    766a60 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x750>
  7668aa:	lea    -0x696e81(%rip),%rax        # cfa30 <GCC_except_table0+0xd664>
  7668b1:	mov    %rsi,%rdi
  7668b4:	mov    %rax,%rsi
  7668b7:	call   *0x353abb(%rip)        # aba378 <bcmp@GLIBC_2.2.5>
  7668bd:	test   %eax,%eax
  7668bf:	jne    766a6a <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x75a>
  7668c5:	call   *0x3537ed(%rip)        # aba0b8 <_DYNAMIC+0x248>
  7668cb:	mov    $0x800,%edi
  7668d0:	mov    $0x1,%esi
  7668d5:	call   *0x3537e5(%rip)        # aba0c0 <_DYNAMIC+0x250>
  7668db:	test   %rax,%rax
  7668de:	je     766ad9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x7c9>
  7668e4:	mov    %rax,%r14
  7668e7:	movabs $0x81cc81cc81cc81cc,%rax
  7668f1:	mov    %rax,(%r14)
  7668f4:	mov    %rax,0x8(%r14)
  7668f8:	movups (%r14),%xmm0
  7668fc:	movups %xmm0,0x10(%r14)
  766901:	movups %xmm0,0x20(%r14)
  766906:	movups %xmm0,0x30(%r14)
  76690b:	movups %xmm0,0x40(%r14)
  766910:	movups %xmm0,0x50(%r14)
  766915:	movups %xmm0,0x60(%r14)
  76691a:	movups %xmm0,0x70(%r14)
  76691f:	movups %xmm0,0x80(%r14)
  766927:	movups %xmm0,0xf0(%r14)
  76692f:	movups %xmm0,0xe0(%r14)
  766937:	movups %xmm0,0xd0(%r14)
  76693f:	movups %xmm0,0xc0(%r14)
  766947:	movups %xmm0,0xb0(%r14)
  76694f:	movups %xmm0,0xa0(%r14)
  766957:	movups %xmm0,0x90(%r14)
  76695f:	lea    0x100(%r14),%rdi
  766966:	mov    0x353763(%rip),%r15        # aba0d0 <memcpy@GLIBC_2.14>
  76696d:	mov    $0x100,%edx
  766972:	mov    %r14,%rsi
  766975:	call   *%r15
  766978:	lea    0x200(%r14),%rdi
  76697f:	mov    $0x200,%edx
  766984:	mov    %r14,%rsi
  766987:	call   *%r15
  76698a:	mov    %r14,%rdi
  76698d:	add    $0x400,%rdi
  766994:	mov    $0x400,%edx
  766999:	mov    %r14,%rsi
  76699c:	call   *%r15
  76699f:	movq   $0x800,0x8(%rsp)
  7669a8:	mov    %r14,0x10(%rsp)
  7669ad:	movq   $0x800,0x18(%rsp)
  7669b6:	lea    0x8(%rsp),%rax
  7669bb:	mov    %rax,0x30(%rsp)
  7669c0:	lea    0x322a9(%rip),%rax        # 798c70 <_RNvXsq_NtCscdodAO9FK5_5alloc6stringNtB5_6StringNtNtCs4NRVxsYgnAr_4core3fmt7Display3fmt>
  7669c7:	mov    %rax,0x38(%rsp)
  7669cc:	lea    -0x6a1822(%rip),%rsi        # c51b1 <GCC_except_table0+0x2de5>
  7669d3:	lea    0x30(%rsp),%rdx
  7669d8:	mov    %rbx,%rdi
  7669db:	call   *0x3539ff(%rip)        # aba3e0 <_DYNAMIC+0x570>
  7669e1:	mov    0x8(%rsp),%rsi
  7669e6:	test   %rsi,%rsi
  7669e9:	je     766a60 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x750>
  7669eb:	mov    0x10(%rsp),%rdi
  7669f0:	mov    $0x1,%edx
  7669f5:	call   *0x3536b5(%rip)        # aba0b0 <_DYNAMIC+0x240>
  7669fb:	jmp    766a60 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x750>
  7669fd:	movq   $0x0,(%rbx)
  766a04:	movq   $0x1,0x8(%rbx)
  766a0c:	movq   $0x0,0x10(%rbx)
  766a14:	jmp    766a60 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x750>
  766a16:	call   *0x35369c(%rip)        # aba0b8 <_DYNAMIC+0x248>
  766a1c:	mov    $0x17,%edi
  766a21:	mov    $0x1,%esi
  766a26:	call   *0x353694(%rip)        # aba0c0 <_DYNAMIC+0x250>
  766a2c:	test   %rax,%rax
  766a2f:	je     766af9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x7e9>
  766a35:	movups -0x696dfa(%rip),%xmm0        # cfc42 <GCC_except_table0+0xd876>
  766a3c:	movups %xmm0,(%rax)
  766a3f:	movabs $0x92d791d790d72081,%rcx
  766a49:	mov    %rcx,0xf(%rax)
  766a4d:	movq   $0x17,(%rbx)
  766a54:	mov    %rax,0x8(%rbx)
  766a58:	movq   $0x17,0x10(%rbx)
  766a60:	add    $0x40,%rsp
  766a64:	pop    %rbx
  766a65:	pop    %r14
  766a67:	pop    %r15
  766a69:	ret
  766a6a:	lea    0x20(%rsp),%rax
  766a6f:	mov    %rax,0x8(%rsp)
  766a74:	lea    0x301b5(%rip),%rax        # 796c30 <_RNvXs1i_NtCs4NRVxsYgnAr_4core3fmtReNtB6_7Display3fmtCs9C2G9YFESsD_29canonical_text_public_control>
  766a7b:	mov    %rax,0x10(%rsp)
  766a80:	lea    -0x69f96b(%rip),%rdi        # c711c <GCC_except_table0+0x4d50>
  766a87:	lea    0x334072(%rip),%rdx        # a9ab00 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x11b8>
  766a8e:	lea    0x8(%rsp),%rsi
  766a93:	call   *0x35364f(%rip)        # aba0e8 <_DYNAMIC+0x278>
  766a99:	mov    $0x1,%edi
  766a9e:	mov    $0x1b80,%esi
  766aa3:	call   *0x3536b7(%rip)        # aba160 <_DYNAMIC+0x2f0>
  766aa9:	mov    $0x1,%edi
  766aae:	mov    $0x1,%esi
  766ab3:	call   *0x3536a7(%rip)        # aba160 <_DYNAMIC+0x2f0>
  766ab9:	mov    $0x1,%edi
  766abe:	mov    $0x580,%esi
  766ac3:	call   *0x353697(%rip)        # aba160 <_DYNAMIC+0x2f0>
  766ac9:	mov    $0x1,%edi
  766ace:	mov    $0x8000,%esi
  766ad3:	call   *0x353687(%rip)        # aba160 <_DYNAMIC+0x2f0>
  766ad9:	mov    $0x1,%edi
  766ade:	mov    $0x800,%esi
  766ae3:	call   *0x353677(%rip)        # aba160 <_DYNAMIC+0x2f0>
  766ae9:	mov    $0x1,%edi
  766aee:	mov    $0x880,%esi
  766af3:	call   *0x353667(%rip)        # aba160 <_DYNAMIC+0x2f0>
  766af9:	mov    $0x1,%edi
  766afe:	mov    $0x17,%esi
  766b03:	call   *0x353657(%rip)        # aba160 <_DYNAMIC+0x2f0>
  766b09:	mov    %rax,%rbx
  766b0c:	mov    0x8(%rsp),%rsi
  766b11:	test   %rsi,%rsi
  766b14:	je     766b26 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x816>
  766b16:	mov    0x10(%rsp),%rdi
  766b1b:	mov    $0x1,%edx
  766b20:	call   *0x35358a(%rip)        # aba0b0 <_DYNAMIC+0x240>
  766b26:	mov    %rbx,%rdi
  766b29:	call   a98590 <_Unwind_Resume@plt>

canonical_text_public_control::owner_hit bytes=416 frame=264

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000766b30 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit>:
  766b30:	push   %rbp
  766b31:	push   %r15
  766b33:	push   %r14
  766b35:	push   %r13
  766b37:	push   %r12
  766b39:	push   %rbx
  766b3a:	sub    $0xd8,%rsp
  766b41:	mov    (%rdi),%rsi
  766b44:	test   %rsi,%rsi
  766b47:	je     766c73 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit+0x143>
  766b4d:	cmpb   $0x0,0x76e(%rsi)
  766b54:	jne    766c7a <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit+0x14a>
  766b5a:	movss  %xmm0,0x8(%rsp)
  766b60:	movss  %xmm1,0xc(%rsp)
  766b66:	cmpb   $0x1,0x76c(%rsi)
  766b6d:	jne    766c81 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit+0x151>
  766b73:	lea    0x58(%rsp),%rdi
  766b78:	call   73dde0 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime5queryNtB3_7Context3newNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEBX_>
  766b7d:	mov    0x90(%rsp),%r13
  766b85:	test   %r13,%r13
  766b88:	je     766c52 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit+0x122>
  766b8e:	movabs $0x100000001b3,%rbp
  766b98:	mov    0x88(%rsp),%rbx
  766ba0:	add    $0x3d,%rbx
  766ba4:	xor    %eax,%eax
  766ba6:	lea    0x58(%rsp),%r14
  766bab:	xor    %r12d,%r12d
  766bae:	jmp    766bf3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit+0xc3>
  766bb0:	xor    $0x1,%eax
  766bb3:	imul   %rbp,%rax
  766bb7:	and    $0x1,%dl
  766bba:	movzbl %dl,%r15d
  766bbe:	xor    %rax,%r15
  766bc1:	imul   %rbp,%r15
  766bc5:	mov    %r14,%rdi
  766bc8:	mov    %r12,%rsi
  766bcb:	movss  0x8(%rsp),%xmm0
  766bd1:	movss  0xc(%rsp),%xmm1
  766bd7:	call   *0x35380b(%rip)        # aba3e8 <_DYNAMIC+0x578>
  766bdd:	movzbl %al,%eax
  766be0:	xor    %r15,%rax
  766be3:	imul   %rbp,%rax
  766be7:	inc    %r12
  766bea:	add    $0x40,%rbx
  766bee:	cmp    %r12,%r13
  766bf1:	je     766c54 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit+0x124>
  766bf3:	cmpb   $0x4,(%rbx)
  766bf6:	jne    766be7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit+0xb7>
  766bf8:	lea    0x10(%rsp),%rdi
  766bfd:	mov    %r14,%rsi
  766c00:	mov    %r12,%rdx
  766c03:	call   *0x3536af(%rip)        # aba2b8 <_DYNAMIC+0x448>
  766c09:	cmpq   $0x0,0x10(%rsp)
  766c0f:	je     766c66 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit+0x136>
  766c11:	movups 0x10(%rsp),%xmm0
  766c16:	movups 0x20(%rsp),%xmm1
  766c1b:	movaps %xmm1,0x40(%rsp)
  766c20:	movaps %xmm0,0x30(%rsp)
  766c25:	lea    0x30(%rsp),%rdi
  766c2a:	movss  0x8(%rsp),%xmm0
  766c30:	movss  0xc(%rsp),%xmm1
  766c36:	call   *0x35371c(%rip)        # aba358 <_DYNAMIC+0x4e8>
  766c3c:	cmp    $0x2,%dl
  766c3f:	jne    766bb0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit+0x80>
  766c45:	lea    0x33339c(%rip),%rdi        # a99fe8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x6a0>
  766c4c:	call   *0x35351e(%rip)        # aba170 <_DYNAMIC+0x300>
  766c52:	xor    %eax,%eax
  766c54:	add    $0xd8,%rsp
  766c5b:	pop    %rbx
  766c5c:	pop    %r12
  766c5e:	pop    %r13
  766c60:	pop    %r14
  766c62:	pop    %r15
  766c64:	pop    %rbp
  766c65:	ret
  766c66:	lea    0x333363(%rip),%rdi        # a99fd0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x688>
  766c6d:	call   *0x3534fd(%rip)        # aba170 <_DYNAMIC+0x300>
  766c73:	mov    $0xd,%eax
  766c78:	jmp    766c86 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit+0x156>
  766c7a:	mov    $0xe,%eax
  766c7f:	jmp    766c86 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit+0x156>
  766c81:	mov    $0x12,%eax
  766c86:	mov    %rax,0x58(%rsp)
  766c8b:	movq   $0x0,0x60(%rsp)
  766c94:	lea    -0x697039(%rip),%rdi        # cfc62 <GCC_except_table0+0xd896>
  766c9b:	lea    0x333ebe(%rip),%rcx        # a9ab60 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1218>
  766ca2:	lea    0x333e6f(%rip),%r8        # a9ab18 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x11d0>
  766ca9:	lea    0x58(%rsp),%rdx
  766cae:	mov    $0x2b,%esi
  766cb3:	call   *0x3534c7(%rip)        # aba180 <_DYNAMIC+0x310>
  766cb9:	ud2
  766cbb:	mov    %rax,%rbx
  766cbe:	lea    0x58(%rsp),%rdi
  766cc3:	call   74d7d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  766cc8:	mov    %rbx,%rdi
  766ccb:	call   a98590 <_Unwind_Resume@plt>

canonical_text_public_control::query_hit bytes=181 frame=88

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000766cd0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9query_hit>:
  766cd0:	push   %r15
  766cd2:	push   %r14
  766cd4:	push   %rbx
  766cd5:	sub    $0x40,%rsp
  766cd9:	mov    %rdi,%r14
  766cdc:	movss  %xmm0,(%rsp)
  766ce1:	movss  %xmm1,0x4(%rsp)
  766ce7:	call   *0x353703(%rip)        # aba3f0 <_DYNAMIC+0x580>
  766ced:	cmp    $0x2,%dl
  766cf0:	je     766d78 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9query_hit+0xa8>
  766cf6:	movabs $0x100000001b3,%r15
  766d00:	xor    $0x1,%eax
  766d03:	imul   %r15,%rax
  766d07:	and    $0x1,%dl
  766d0a:	movzbl %dl,%ebx
  766d0d:	xor    %rax,%rbx
  766d10:	imul   %r15,%rbx
  766d14:	lea    0x8(%rsp),%rdi
  766d19:	mov    %r14,%rsi
  766d1c:	movss  (%rsp),%xmm0
  766d21:	movss  0x4(%rsp),%xmm1
  766d27:	call   *0x3536cb(%rip)        # aba3f8 <_DYNAMIC+0x588>
  766d2d:	cmpb   $0x2,0xc(%rsp)
  766d32:	je     766d6b <_RNvCs9C2G9YFESsD_29canonical_text_public_control9query_hit+0x9b>
  766d34:	mov    0x8(%rsp),%eax
  766d38:	mov    0x18(%rsp),%ecx
  766d3c:	mov    0x1c(%rsp),%edx
  766d40:	mov    0x20(%rsp),%esi
  766d44:	mov    0x24(%rsp),%edi
  766d48:	xor    %rax,%rbx
  766d4b:	imul   %r15,%rbx
  766d4f:	xor    %rcx,%rbx
  766d52:	imul   %r15,%rbx
  766d56:	xor    %rdx,%rbx
  766d59:	imul   %r15,%rbx
  766d5d:	xor    %rsi,%rbx
  766d60:	imul   %r15,%rbx
  766d64:	xor    %rdi,%rbx
  766d67:	imul   %r15,%rbx
  766d6b:	mov    %rbx,%rax
  766d6e:	add    $0x40,%rsp
  766d72:	pop    %rbx
  766d73:	pop    %r14
  766d75:	pop    %r15
  766d77:	ret
  766d78:	lea    0x333db1(%rip),%rdi        # a9ab30 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x11e8>
  766d7f:	call   *0x3533eb(%rip)        # aba170 <_DYNAMIC+0x300>

<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::interaction_layout bytes=1471 frame=280

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000076bc90 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_>:
  76bc90:	push   %rbp
  76bc91:	push   %r15
  76bc93:	push   %r14
  76bc95:	push   %r13
  76bc97:	push   %r12
  76bc99:	push   %rbx
  76bc9a:	sub    $0xe8,%rsp
  76bca1:	mov    %rdx,%r14
  76bca4:	mov    %rsi,%r15
  76bca7:	mov    0x2e0(%rsi),%rsi
  76bcae:	cmp    %rsi,%rdx
  76bcb1:	jae    76c1ab <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x51b>
  76bcb7:	mov    0x2d8(%r15),%rax
  76bcbe:	lea    (%r14,%r14,4),%rcx
  76bcc2:	mov    0x20(%rax,%rcx,8),%ebx
  76bcc6:	mov    %ebx,%eax
  76bcc8:	and    $0xf,%eax
  76bccb:	cmp    $0x9,%eax
  76bcce:	ja     76c192 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x502>
  76bcd4:	mov    %rdi,%r12
  76bcd7:	cmp    $0x6,%eax
  76bcda:	je     76c0ce <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x43e>
  76bce0:	shr    $0x4,%ebx
  76bce3:	lea    0x2f0(%r15),%r13
  76bcea:	lea    0x2f8(%r15),%rax
  76bcf1:	sub    $0x1,%ebx
  76bcf4:	mov    %rax,0x28(%rsp)
  76bcf9:	jae    76bd6c <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0xdc>
  76bcfb:	mov    $0xffffffff,%ebx
  76bd00:	mov    $0x1,%bpl
  76bd03:	mov    0x5a8(%r15),%rsi
  76bd0a:	cmp    %rsi,%r14
  76bd0d:	jae    76bef1 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x261>
  76bd13:	mov    0x5a0(%r15),%rax
  76bd1a:	lea    0x300(%r15),%rsi
  76bd21:	mov    %r14,%rcx
  76bd24:	shl    $0x4,%rcx
  76bd28:	movups (%rax,%rcx,1),%xmm0
  76bd2c:	movaps %xmm0,0x40(%rsp)
  76bd31:	lea    0x80(%rsp),%rdi
  76bd39:	lea    0x40(%rsp),%rdx
  76bd3e:	call   *0x34e50c(%rip)        # aba250 <_DYNAMIC+0x3e0>
  76bd44:	cmpb   $0x0,0x80(%rsp)
  76bd4c:	je     76be02 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x172>
  76bd52:	movzbl 0x81(%rsp),%eax
  76bd5a:	movq   $0x22,(%r12)
  76bd62:	mov    %al,0x8(%r12)
  76bd67:	jmp    76c0bc <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x42c>
  76bd6c:	mov    %r13,0x10(%rsp)
  76bd71:	mov    %r12,0x18(%rsp)
  76bd76:	mov    0x2f8(%r15),%r13
  76bd7d:	mov    %ebx,%edi
  76bd7f:	cmp    %rdi,%r13
  76bd82:	jbe    76c1bb <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x52b>
  76bd88:	mov    0x2f0(%r15),%rbp
  76bd8f:	lea    (%rdi,%rdi,4),%r12
  76bd93:	shl    $0x4,%r12
  76bd97:	mov    0x0(%rbp,%r12,1),%rax
  76bd9c:	cmp    $0xffffffffffffffff,%rax
  76bda0:	je     76bed3 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x243>
  76bda6:	cmp    $0xfffffffffffffffe,%rax
  76bdaa:	je     76c0ff <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x46f>
  76bdb0:	mov    %rdi,0x20(%rsp)
  76bdb5:	lea    0x40(%rsp),%rdi
  76bdba:	xor    %esi,%esi
  76bdbc:	call   *0x34e726(%rip)        # aba4e8 <_DYNAMIC+0x678>
  76bdc2:	cmpl   $0xfffffffe,0x40(%rsp)
  76bdc7:	jne    76c134 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x4a4>
  76bdcd:	add    %r12,%rbp
  76bdd0:	mov    0x48(%rsp),%edx
  76bdd4:	movzbl 0x4c(%rsp),%ecx
  76bdd9:	lea    0x80(%rsp),%rdi
  76bde1:	mov    %rbp,%rsi
  76bde4:	call   *0x34e706(%rip)        # aba4f0 <_DYNAMIC+0x680>
  76bdea:	cmpb   $0x0,0x80(%rsp)
  76bdf2:	je     76bed3 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x243>
  76bdf8:	mov    0x18(%rsp),%r12
  76bdfd:	jmp    76c026 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x396>
  76be02:	mov    0x6e8(%r15),%rax
  76be09:	test   %rax,%rax
  76be0c:	je     76c0e6 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x456>
  76be12:	mov    0x30(%rax),%rax
  76be16:	test   %rax,%rax
  76be19:	je     76c0e6 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x456>
  76be1f:	movss  0xcc(%rsp),%xmm1
  76be28:	subss  0xa4(%rsp),%xmm1
  76be31:	subss  0xa8(%rsp),%xmm1
  76be3a:	subss  0x94(%rsp),%xmm1
  76be43:	subss  0x98(%rsp),%xmm1
  76be4c:	subss  0xd4(%rsp),%xmm1
  76be55:	lock incq (%rax)
  76be59:	jle    76c1ff <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x56f>
  76be5f:	mov    %rax,0x8(%rsp)
  76be64:	test   %bpl,%bpl
  76be67:	jne    76c10c <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x47c>
  76be6d:	mov    0x28(%rsp),%rbp
  76be72:	mov    0x0(%rbp),%rsi
  76be76:	mov    %ebx,%edi
  76be78:	cmp    %rdi,%rsi
  76be7b:	jbe    76c1cb <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x53b>
  76be81:	mov    0x0(%r13),%rsi
  76be85:	lea    (%rdi,%rdi,4),%rbx
  76be89:	shl    $0x4,%rbx
  76be8d:	cmpq   $0xfffffffffffffffe,(%rsi,%rbx,1)
  76be92:	je     76c115 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x485>
  76be98:	lea    0x8(%rsp),%rax
  76be9d:	mov    %rax,0x30(%rsp)
  76bea2:	movq   $0x0,0x38(%rsp)
  76beab:	mov    0x200(%r15),%rax
  76beb2:	lea    -0x6a7e21(%rip),%rcx        # c4098 <GCC_except_table0+0x1ccc>
  76beb9:	movslq (%rcx,%rax,4),%rax
  76bebd:	add    %rcx,%rax
  76bec0:	mov    %rdi,0x20(%rsp)
  76bec5:	jmp    *%rax
  76bec7:	lea    -0x6a7a72(%rip),%rax        # c445c <GCC_except_table0+0x2090>
  76bece:	jmp    76bf84 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x2f4>
  76bed3:	xor    %ebp,%ebp
  76bed5:	mov    0x18(%rsp),%r12
  76beda:	lea    0x2f0(%r15),%r13
  76bee1:	mov    0x5a8(%r15),%rsi
  76bee8:	cmp    %rsi,%r14
  76beeb:	jb     76bd13 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x83>
  76bef1:	lea    0x32efc8(%rip),%rdx        # a9aec0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1578>
  76bef8:	mov    %r14,%rdi
  76befb:	call   *0x34e1df(%rip)        # aba0e0 <_DYNAMIC+0x270>
  76bf01:	mov    0x220(%r15),%rax
  76bf08:	cmp    %rax,%r14
  76bf0b:	jae    76c1da <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x54a>
  76bf11:	mov    0x210(%r15),%rax
  76bf18:	mov    0x218(%r15),%rcx
  76bf1f:	movzbl (%rcx,%r14,1),%r14d
  76bf24:	cmp    %r14,%rax
  76bf27:	jbe    76c1ec <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x55c>
  76bf2d:	imul   $0x58,%r14,%rax
  76bf31:	add    0x208(%r15),%rax
  76bf38:	jmp    76bf84 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x2f4>
  76bf3a:	mov    0x208(%r15),%rax
  76bf41:	lea    0x80(%rsp),%rdi
  76bf49:	mov    %rsi,%r15
  76bf4c:	mov    %rax,%rsi
  76bf4f:	mov    %r14,%rdx
  76bf52:	movss  %xmm1,0x10(%rsp)
  76bf58:	call   *0x34e302(%rip)        # aba260 <_DYNAMIC+0x3f0>
  76bf5e:	movss  0x10(%rsp),%xmm1
  76bf64:	mov    %r15,%rsi
  76bf67:	jmp    76bfcb <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x33b>
  76bf69:	mov    0x218(%r15),%rax
  76bf70:	cmp    %rax,%r14
  76bf73:	jae    76c1e3 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x553>
  76bf79:	imul   $0x58,%r14,%rax
  76bf7d:	add    0x210(%r15),%rax
  76bf84:	mov    0x50(%rax),%rcx
  76bf88:	mov    %rcx,0xd0(%rsp)
  76bf90:	movups 0x40(%rax),%xmm0
  76bf94:	movaps %xmm0,0xc0(%rsp)
  76bf9c:	movups (%rax),%xmm0
  76bf9f:	movups 0x10(%rax),%xmm4
  76bfa3:	movups 0x20(%rax),%xmm2
  76bfa7:	movups 0x30(%rax),%xmm3
  76bfab:	movaps %xmm3,0xb0(%rsp)
  76bfb3:	movaps %xmm2,0xa0(%rsp)
  76bfbb:	movaps %xmm4,0x90(%rsp)
  76bfc3:	movaps %xmm0,0x80(%rsp)
  76bfcb:	add    %rbx,%rsi
  76bfce:	movss  0x98(%rsp),%xmm0
  76bfd7:	lea    0x40(%rsp),%rdi
  76bfdc:	lea    0x30(%rsp),%rdx
  76bfe1:	mov    $0x1,%ecx
  76bfe6:	mov    $0x1,%r8d
  76bfec:	call   *0x34e2fe(%rip)        # aba2f0 <_DYNAMIC+0x480>
  76bff2:	mov    0x40(%rsp),%rax
  76bff7:	cmp    $0xfffffffffffffffe,%rax
  76bffb:	jne    76c06e <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x3de>
  76bffd:	mov    0x38(%rsp),%rdi
  76c002:	call   74cd40 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text10TextShaperECs9C2G9YFESsD_29canonical_text_public_control>
  76c007:	mov    %r13,0x10(%rsp)
  76c00c:	mov    0x8(%rsp),%rax
  76c011:	lock decq (%rax)
  76c015:	jne    76c022 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x392>
  76c017:	lea    0x8(%rsp),%rdi
  76c01c:	call   *0x34e17e(%rip)        # aba1a0 <_DYNAMIC+0x330>
  76c022:	mov    0x0(%rbp),%r13
  76c026:	mov    0x20(%rsp),%rdi
  76c02b:	cmp    %rdi,%r13
  76c02e:	jbe    76c1bb <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x52b>
  76c034:	mov    0x10(%rsp),%rax
  76c039:	mov    (%rax),%rax
  76c03c:	lea    (%rdi,%rdi,4),%rcx
  76c040:	shl    $0x4,%rcx
  76c044:	mov    (%rax,%rcx,1),%rdx
  76c048:	cmp    $0xfffffffffffffffe,%rdx
  76c04c:	je     76c0ff <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x46f>
  76c052:	cmp    $0xffffffffffffffff,%rdx
  76c056:	je     76c127 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x497>
  76c05c:	add    %rcx,%rax
  76c05f:	mov    %rax,0x8(%r12)
  76c064:	movq   $0xfffffffffffffffe,(%r12)
  76c06c:	jmp    76c0bc <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x42c>
  76c06e:	mov    0x48(%rsp),%rcx
  76c073:	mov    0x70(%rsp),%rdx
  76c078:	mov    %rdx,0x30(%r12)
  76c07d:	movups 0x60(%rsp),%xmm0
  76c082:	movups %xmm0,0x20(%r12)
  76c088:	movups 0x50(%rsp),%xmm0
  76c08d:	movups %xmm0,0x10(%r12)
  76c093:	mov    %rax,(%r12)
  76c097:	mov    %rcx,0x8(%r12)
  76c09c:	mov    0x38(%rsp),%rdi
  76c0a1:	call   74cd40 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text10TextShaperECs9C2G9YFESsD_29canonical_text_public_control>
  76c0a6:	mov    0x8(%rsp),%rax
  76c0ab:	lock decq (%rax)
  76c0af:	jne    76c0bc <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x42c>
  76c0b1:	lea    0x8(%rsp),%rdi
  76c0b6:	call   *0x34e0e4(%rip)        # aba1a0 <_DYNAMIC+0x330>
  76c0bc:	add    $0xe8,%rsp
  76c0c3:	pop    %rbx
  76c0c4:	pop    %r12
  76c0c6:	pop    %r13
  76c0c8:	pop    %r14
  76c0ca:	pop    %r15
  76c0cc:	pop    %rbp
  76c0cd:	ret
  76c0ce:	lea    0x2f0(%r15),%r13
  76c0d5:	lea    0x2f8(%r15),%rax
  76c0dc:	mov    %rax,0x28(%rsp)
  76c0e1:	jmp    76bcfb <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x6b>
  76c0e6:	lea    -0x699a51(%rip),%rdi        # d269c <GCC_except_table0+0x102d0>
  76c0ed:	lea    0x32ede4(%rip),%rdx        # a9aed8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1590>
  76c0f4:	mov    $0x2c,%esi
  76c0f9:	call   *0x34e089(%rip)        # aba188 <_DYNAMIC+0x318>
  76c0ff:	lea    0x32e04a(%rip),%rdi        # a9a150 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x808>
  76c106:	call   *0x34e064(%rip)        # aba170 <_DYNAMIC+0x300>
  76c10c:	lea    0x32eddd(%rip),%rdi        # a9aef0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x15a8>
  76c113:	jmp    76c11c <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x48c>
  76c115:	lea    0x32e064(%rip),%rdi        # a9a180 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x838>
  76c11c:	call   *0x34e04e(%rip)        # aba170 <_DYNAMIC+0x300>
  76c122:	jmp    76c1ff <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x56f>
  76c127:	lea    0x32edda(%rip),%rdi        # a9af08 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x15c0>
  76c12e:	call   *0x34e03c(%rip)        # aba170 <_DYNAMIC+0x300>
  76c134:	mov    0x70(%rsp),%rax
  76c139:	mov    %rax,0xb0(%rsp)
  76c141:	movups 0x40(%rsp),%xmm0
  76c146:	movups 0x50(%rsp),%xmm1
  76c14b:	movups 0x60(%rsp),%xmm2
  76c150:	movaps %xmm2,0xa0(%rsp)
  76c158:	movaps %xmm1,0x90(%rsp)
  76c160:	movaps %xmm0,0x80(%rsp)
  76c168:	lea    -0x69c50d(%rip),%rdi        # cfc62 <GCC_except_table0+0xd896>
  76c16f:	lea    0x32e9ea(%rip),%rcx        # a9ab60 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1218>
  76c176:	lea    0x32ed2b(%rip),%r8        # a9aea8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1560>
  76c17d:	lea    0x80(%rsp),%rdx
  76c185:	mov    $0x2b,%esi
  76c18a:	call   *0x34dff0(%rip)        # aba180 <_DYNAMIC+0x310>
  76c190:	jmp    76c1ff <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x56f>
  76c192:	lea    -0x699851(%rip),%rdi        # d2948 <GCC_except_table0+0x1057c>
  76c199:	lea    0x32f250(%rip),%rdx        # a9b3f0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1aa8>
  76c1a0:	mov    $0x83,%esi
  76c1a5:	call   *0x34df3d(%rip)        # aba0e8 <_DYNAMIC+0x278>
  76c1ab:	lea    0x32ecde(%rip),%rdx        # a9ae90 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1548>
  76c1b2:	mov    %r14,%rdi
  76c1b5:	call   *0x34df25(%rip)        # aba0e0 <_DYNAMIC+0x270>
  76c1bb:	lea    0x32df76(%rip),%rdx        # a9a138 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x7f0>
  76c1c2:	mov    %r13,%rsi
  76c1c5:	call   *0x34df15(%rip)        # aba0e0 <_DYNAMIC+0x270>
  76c1cb:	lea    0x32df96(%rip),%rdx        # a9a168 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x820>
  76c1d2:	call   *0x34df08(%rip)        # aba0e0 <_DYNAMIC+0x270>
  76c1d8:	jmp    76c1ff <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x56f>
  76c1da:	lea    0x32eb3f(%rip),%rdx        # a9ad20 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x13d8>
  76c1e1:	jmp    76c1f3 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x563>
  76c1e3:	lea    0x32eb1e(%rip),%rdx        # a9ad08 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x13c0>
  76c1ea:	jmp    76c1f3 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x563>
  76c1ec:	lea    0x32eb45(%rip),%rdx        # a9ad38 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x13f0>
  76c1f3:	mov    %r14,%rdi
  76c1f6:	mov    %rax,%rsi
  76c1f9:	call   *0x34dee1(%rip)        # aba0e0 <_DYNAMIC+0x270>
  76c1ff:	ud2
  76c201:	mov    %rax,%rbx
  76c204:	mov    0x38(%rsp),%rdi
  76c209:	call   74cd40 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text10TextShaperECs9C2G9YFESsD_29canonical_text_public_control>
  76c20e:	jmp    76c22b <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x59b>
  76c210:	mov    %rax,%rbx
  76c213:	lea    0x80(%rsp),%rdi
  76c21b:	call   74d7d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  76c220:	mov    %rbx,%rdi
  76c223:	call   a98590 <_Unwind_Resume@plt>
  76c228:	mov    %rax,%rbx
  76c22b:	mov    0x8(%rsp),%rax
  76c230:	lock decq (%rax)
  76c234:	jne    76c241 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x5b1>
  76c236:	lea    0x8(%rsp),%rdi
  76c23b:	call   *0x34df5f(%rip)        # aba1a0 <_DYNAMIC+0x330>
  76c241:	mov    %rbx,%rdi
  76c244:	call   a98590 <_Unwind_Resume@plt>
  76c249:	call   *0x34de89(%rip)        # aba0d8 <_DYNAMIC+0x268>

<gpui::runtime::Win<canonical_text_public_control::Editor>>::pointer_event bytes=3204 frame=296

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000076d910 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_>:
  76d910:	push   %rbp
  76d911:	push   %r15
  76d913:	push   %r14
  76d915:	push   %r13
  76d917:	push   %r12
  76d919:	push   %rbx
  76d91a:	sub    $0xf8,%rsp
  76d921:	mov    %rdx,%r14
  76d924:	mov    %rdi,%rbx
  76d927:	mov    (%rcx),%ebp
  76d929:	test   %ebp,%ebp
  76d92b:	je     76d960 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x50>
  76d92d:	mov    0x8(%r14),%r12
  76d931:	mov    0x10(%r14),%r13
  76d935:	mov    0x18(%r14),%rax
  76d939:	movq   $0x0,0x8(%r14)
  76d941:	lea    -0x1(%rbp),%edx
  76d944:	lea    -0x6a98a3(%rip),%rdi        # c40a8 <GCC_except_table0+0x1cdc>
  76d94b:	movslq (%rdi,%rdx,4),%rdx
  76d94f:	add    %rdi,%rdx
  76d952:	jmp    *%rdx
  76d954:	movl   $0xffffffff,(%r14)
  76d95b:	jmp    76db21 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x211>
  76d960:	movd   0x4(%rcx),%xmm1
  76d965:	movd   0x8(%rcx),%xmm0
  76d96a:	movd   %xmm1,%eax
  76d96e:	movd   %xmm0,%ecx
  76d972:	mov    %eax,%edx
  76d974:	and    $0x7fffffff,%edx
  76d97a:	cmp    $0x7f800000,%edx
  76d980:	setge  %dl
  76d983:	and    $0x7fffffff,%ecx
  76d989:	cmp    $0x7f800000,%ecx
  76d98f:	setge  %cl
  76d992:	or     %dl,%cl
  76d994:	je     76d9ad <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x9d>
  76d996:	movl   $0xffffffff,(%r14)
  76d99d:	movq   $0x0,0x8(%r14)
  76d9a5:	xor    %r12d,%r12d
  76d9a8:	jmp    76db21 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x211>
  76d9ad:	inc    %eax
  76d9af:	je     76e519 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xc09>
  76d9b5:	mov    %eax,(%r14)
  76d9b8:	movd   %xmm0,0x4(%r14)
  76d9be:	xor    %r12d,%r12d
  76d9c1:	jmp    76db21 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x211>
  76d9c6:	mov    (%r14),%r15d
  76d9c9:	cmp    $0xffffffff,%r15d
  76d9cd:	je     76db21 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x211>
  76d9d3:	mov    %rsi,%r13
  76d9d6:	movups 0x8(%rcx),%xmm0
  76d9da:	movss  0x4(%r14),%xmm1
  76d9e0:	movss  %xmm1,0x58(%rsp)
  76d9e6:	movaps %xmm0,%xmm1
  76d9e9:	unpckhpd %xmm0,%xmm1
  76d9ed:	lea    0x10(%rsp),%rdi
  76d9f2:	movaps %xmm0,0x60(%rsp)
  76d9f7:	call   *0x34cafb(%rip)        # aba4f8 <_DYNAMIC+0x688>
  76d9fd:	cmpl   $0xfffffffe,0x10(%rsp)
  76da02:	jne    76dd7e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x46e>
  76da08:	mov    0x0(%r13),%r14
  76da0c:	test   %r14,%r14
  76da0f:	je     76db53 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x243>
  76da15:	cmpb   $0x1,0x76e(%r14)
  76da1d:	je     76db47 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x237>
  76da23:	cmpb   $0x1,0x76a(%r14)
  76da2b:	jne    76df0e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76da31:	cmpb   $0x0,0x76b(%r14)
  76da39:	jne    76df0e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76da3f:	cmpb   $0x0,0x76c(%r14)
  76da47:	je     76df0e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76da4d:	cmpq   $0xffffffffffffffff,0x5c8(%r14)
  76da55:	jne    76df0e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76da5b:	mov    0x6a0(%r14),%rax
  76da62:	cmp    0x6a8(%r14),%rax
  76da69:	jne    76df0e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76da6f:	mov    0x6c0(%r14),%rax
  76da76:	cmp    %rax,0x6c8(%r14)
  76da7d:	jne    76df0e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76da83:	movss  0x760(%r14),%xmm0
  76da8c:	ucomiss 0x764(%r14),%xmm0
  76da94:	jne    76df0e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76da9a:	jp     76df0e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76daa0:	mov    %eax,%ecx
  76daa2:	cvtsi2ss %rcx,%xmm2
  76daa7:	dec    %r15d
  76daaa:	shr    $0x20,%rax
  76daae:	mov    %eax,%eax
  76dab0:	xorps  %xmm1,%xmm1
  76dab3:	cvtsi2ss %rax,%xmm1
  76dab8:	movd   %r15d,%xmm0
  76dabd:	movq   $0x0,0x10(%rsp)
  76dac6:	movss  %xmm2,0x18(%rsp)
  76dacc:	movss  %xmm1,0x1c(%rsp)
  76dad2:	lea    0x10(%rsp),%rdi
  76dad7:	movd   %xmm0,0x54(%rsp)
  76dadd:	movss  0x58(%rsp),%xmm1
  76dae3:	call   *0x34ca17(%rip)        # aba500 <_DYNAMIC+0x690>
  76dae9:	test   %al,%al
  76daeb:	je     76e50d <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xbfd>
  76daf1:	mov    0x650(%r14),%rax
  76daf8:	test   %rax,%rax
  76dafb:	je     76e343 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xa33>
  76db01:	mov    0x100(%rax),%rsi
  76db08:	test   %rsi,%rsi
  76db0b:	je     76e343 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xa33>
  76db11:	lea    0x70(%rsp),%rdi
  76db16:	call   *0x34c5fc(%rip)        # aba118 <_DYNAMIC+0x2a8>
  76db1c:	jmp    76e356 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xa46>
  76db21:	mov    (%rsi),%r15
  76db24:	test   %r15,%r15
  76db27:	je     76db53 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x243>
  76db29:	add    $0x8,%rsi
  76db2d:	mov    %r15,0xb0(%rsp)
  76db35:	mov    %rsi,0xb8(%rsp)
  76db3d:	cmpb   $0x1,0x76e(%r15)
  76db45:	jne    76db67 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x257>
  76db47:	movq   $0xe,(%rbx)
  76db4e:	jmp    76df15 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76db53:	movq   $0xd,(%rbx)
  76db5a:	movq   $0x0,0x8(%rbx)
  76db62:	jmp    76df15 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76db67:	movq   $0x0,0x758(%r15)
  76db72:	cmp    $0x3,%ebp
  76db75:	je     76dd48 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x438>
  76db7b:	cmp    $0x2,%ebp
  76db7e:	je     76dc94 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x384>
  76db84:	test   %ebp,%ebp
  76db86:	jne    76ddc1 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4b1>
  76db8c:	mov    0x650(%r15),%rax
  76db93:	test   %rax,%rax
  76db96:	je     76dbae <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x29e>
  76db98:	mov    0xd8(%rax),%rax
  76db9f:	test   %rax,%rax
  76dba2:	je     76dbae <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x29e>
  76dba4:	cmpb   $0x0,0x12(%rax)
  76dba8:	jne    76ddc1 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4b1>
  76dbae:	mov    0x8(%r14),%r12
  76dbb2:	test   %r12,%r12
  76dbb5:	je     76ddc1 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4b1>
  76dbbb:	cmp    0x5f0(%r15),%r12
  76dbc2:	jne    76dda6 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x496>
  76dbc8:	mov    0x10(%r14),%r13
  76dbcc:	lea    0x70(%rsp),%rdi
  76dbd1:	mov    %r15,%rsi
  76dbd4:	mov    %r13,%rdx
  76dbd7:	call   78d180 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE16resolve_identityBO_>
  76dbdc:	cmpq   $0xfffffffffffffffe,0x70(%rsp)
  76dbe2:	jne    76ddaf <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x49f>
  76dbe8:	mov    0x78(%rsp),%rdi
  76dbed:	mov    0x2e0(%r15),%rsi
  76dbf4:	cmp    %rsi,%rdi
  76dbf7:	jae    76e532 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xc22>
  76dbfd:	mov    0x2d8(%r15),%rax
  76dc04:	lea    (%rdi,%rdi,4),%rcx
  76dc08:	mov    0x20(%rax,%rcx,8),%edi
  76dc0c:	call   776560 <_RNvMsh_NtCslbxve4rcJus_4gpui7runtimeNtB5_4Node4kind>
  76dc11:	cmp    $0x4,%al
  76dc13:	jne    76df27 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x617>
  76dc19:	mov    (%r14),%eax
  76dc1c:	cmp    $0xffffffff,%eax
  76dc1f:	je     76e541 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xc31>
  76dc25:	movd   0x4(%r14),%xmm1
  76dc2b:	dec    %eax
  76dc2d:	movd   %eax,%xmm0
  76dc31:	lea    0x10(%rsp),%rdi
  76dc36:	mov    %r15,%rsi
  76dc39:	mov    %r12,%rdx
  76dc3c:	mov    %r13,%rcx
  76dc3f:	mov    $0x1,%r8d
  76dc45:	call   770790 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE14select_pointerB12_>
  76dc4a:	mov    0x10(%rsp),%rax
  76dc4f:	cmp    $0xfffffffffffffffe,%rax
  76dc53:	je     76dc62 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x352>
  76dc55:	cmp    $0x11,%eax
  76dc58:	jne    76dc62 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x352>
  76dc5a:	movq   $0x0,0x8(%r14)
  76dc62:	mov    0x40(%rsp),%rax
  76dc67:	mov    %rax,0x30(%rbx)
  76dc6b:	movups 0x10(%rsp),%xmm0
  76dc70:	movups 0x20(%rsp),%xmm1
  76dc75:	movups 0x30(%rsp),%xmm2
  76dc7a:	movups %xmm2,0x20(%rbx)
  76dc7e:	movups %xmm1,0x10(%rbx)
  76dc82:	movups %xmm0,(%rbx)
  76dc85:	lea    0x70(%rsp),%rdi
  76dc8a:	call   746440 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultNtNtCslbxve4rcJus_4gpui7runtime6CommitNtBZ_5ErrorEECs9C2G9YFESsD_29canonical_text_public_control>
  76dc8f:	jmp    76df15 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76dc94:	test   %r12,%r12
  76dc97:	sete   %cl
  76dc9a:	cmpb   $0x1,0x76a(%r15)
  76dca2:	jne    76df0e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76dca8:	cmpb   $0x0,0x76b(%r15)
  76dcb0:	jne    76df0e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76dcb6:	cmpb   $0x0,0x76c(%r15)
  76dcbe:	je     76df0e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76dcc4:	cmpq   $0xffffffffffffffff,0x5c8(%r15)
  76dccc:	jne    76df0e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76dcd2:	mov    0x6a0(%r15),%rax
  76dcd9:	cmp    0x6a8(%r15),%rax
  76dce0:	jne    76df0e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76dce6:	mov    0x6c8(%r15),%rax
  76dced:	cmp    0x6c0(%r15),%rax
  76dcf4:	jne    76df0e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76dcfa:	movss  0x760(%r15),%xmm0
  76dd03:	ucomiss 0x764(%r15),%xmm0
  76dd0b:	jne    76df0e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76dd11:	jp     76df0e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76dd17:	mov    (%r14),%eax
  76dd1a:	cmp    $0xffffffff,%eax
  76dd1d:	mov    %rax,0x58(%rsp)
  76dd22:	mov    %ecx,0x54(%rsp)
  76dd26:	je     76df36 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x626>
  76dd2c:	movss  0x4(%r14),%xmm0
  76dd32:	dec    %eax
  76dd34:	mov    %eax,0x14(%rsp)
  76dd38:	movss  %xmm0,0x18(%rsp)
  76dd3e:	mov    $0x1,%eax
  76dd43:	jmp    76df38 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x628>
  76dd48:	test   %r12,%r12
  76dd4b:	je     76ddc1 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4b1>
  76dd4d:	mov    (%r14),%ecx
  76dd50:	cmp    $0xffffffff,%ecx
  76dd53:	mov    %rcx,0x58(%rsp)
  76dd58:	je     76de1f <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x50f>
  76dd5e:	movss  0x4(%r14),%xmm1
  76dd64:	dec    %ecx
  76dd66:	mov    %ecx,0x74(%rsp)
  76dd6a:	movss  %xmm1,0x78(%rsp)
  76dd70:	movd   %ecx,%xmm0
  76dd74:	mov    $0x1,%ecx
  76dd79:	jmp    76de21 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x511>
  76dd7e:	mov    0x40(%rsp),%rax
  76dd83:	mov    %rax,0x30(%rbx)
  76dd87:	movups 0x10(%rsp),%xmm0
  76dd8c:	movups 0x20(%rsp),%xmm1
  76dd91:	movups 0x30(%rsp),%xmm2
  76dd96:	movups %xmm2,0x20(%rbx)
  76dd9a:	movups %xmm1,0x10(%rbx)
  76dd9e:	movups %xmm0,(%rbx)
  76dda1:	jmp    76df15 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76dda6:	movq   $0x11,0x70(%rsp)
  76ddaf:	lea    0x70(%rsp),%rdi
  76ddb4:	call   746440 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultNtNtCslbxve4rcJus_4gpui7runtime6CommitNtBZ_5ErrorEECs9C2G9YFESsD_29canonical_text_public_control>
  76ddb9:	movq   $0x0,0x8(%r14)
  76ddc1:	movups 0x6a0(%r15),%xmm0
  76ddc9:	movzbl 0x76c(%r15),%eax
  76ddd1:	cmpq   $0x0,0x6d0(%r15)
  76ddd9:	je     76dde9 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4d9>
  76dddb:	test   %al,%al
  76dddd:	je     76dded <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4dd>
  76dddf:	cmpq   $0xffffffffffffffff,0x5c8(%r15)
  76dde7:	jne    76dded <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4dd>
  76dde9:	xor    %ecx,%ecx
  76ddeb:	jmp    76ddf9 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4e9>
  76dded:	mov    0x6e0(%r15),%rdx
  76ddf4:	mov    $0x1,%ecx
  76ddf9:	mov    0x758(%r15),%rsi
  76de00:	mov    %rcx,0x8(%rbx)
  76de04:	mov    %rdx,0x10(%rbx)
  76de08:	movups %xmm0,0x18(%rbx)
  76de0c:	mov    %rsi,0x28(%rbx)
  76de10:	mov    %al,0x30(%rbx)
  76de13:	movq   $0xfffffffffffffffe,(%rbx)
  76de1a:	jmp    76df15 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76de1f:	xor    %ecx,%ecx
  76de21:	mov    %ecx,0x70(%rsp)
  76de25:	movzbl 0x76b(%r15),%edx
  76de2d:	xor    $0x1,%dl
  76de30:	and    0x76a(%r15),%dl
  76de37:	and    0x76c(%r15),%dl
  76de3e:	mov    0x5c8(%r15),%rsi
  76de45:	cmp    $0xffffffffffffffff,%rsi
  76de49:	sete   %dil
  76de4d:	and    %dl,%dil
  76de50:	cmp    $0x1,%dil
  76de54:	jne    76ded2 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5c2>
  76de56:	mov    0x6a0(%r15),%rax
  76de5d:	cmp    0x6a8(%r15),%rax
  76de64:	jne    76df0e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76de6a:	mov    0x6c8(%r15),%rax
  76de71:	cmp    0x6c0(%r15),%rax
  76de78:	jne    76df0e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76de7e:	movss  0x760(%r15),%xmm2
  76de87:	ucomiss 0x764(%r15),%xmm2
  76de8f:	jne    76df0e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76de91:	jp     76df0e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76de93:	test   %ecx,%ecx
  76de95:	je     76e040 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x730>
  76de9b:	mov    0x650(%r15),%rax
  76dea2:	test   %rax,%rax
  76dea5:	je     76e018 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x708>
  76deab:	mov    0xd8(%rax),%rax
  76deb2:	test   %rax,%rax
  76deb5:	je     76e018 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x708>
  76debb:	cmpb   $0x0,0x12(%rax)
  76debf:	je     76e018 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x708>
  76dec5:	mov    %r15,%rdi
  76dec8:	call   771060 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime9inspectorINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE14inspector_pickB10_>
  76decd:	jmp    76e034 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x724>
  76ded2:	cmp    $0xffffffffffffffff,%rsi
  76ded6:	sete   %cl
  76ded9:	movq   $0x12,0x10(%rsp)
  76dee2:	xor    $0x1,%dl
  76dee5:	or     %cl,%dl
  76dee7:	jne    76df0e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76dee9:	mov    0x6c8(%r15),%rcx
  76def0:	cmp    0x6c0(%r15),%rcx
  76def7:	jne    76df0e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76def9:	movss  0x760(%r15),%xmm0
  76df02:	ucomiss 0x764(%r15),%xmm0
  76df0a:	jne    76df0e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76df0c:	jnp    76df5c <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x64c>
  76df0e:	movq   $0x12,(%rbx)
  76df15:	add    $0xf8,%rsp
  76df1c:	pop    %rbx
  76df1d:	pop    %r12
  76df1f:	pop    %r13
  76df21:	pop    %r14
  76df23:	pop    %r15
  76df25:	pop    %rbp
  76df26:	ret
  76df27:	lea    0x70(%rsp),%rdi
  76df2c:	call   746440 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultNtNtCslbxve4rcJus_4gpui7runtime6CommitNtBZ_5ErrorEECs9C2G9YFESsD_29canonical_text_public_control>
  76df31:	jmp    76ddc1 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4b1>
  76df36:	xor    %eax,%eax
  76df38:	mov    %eax,0x10(%rsp)
  76df3c:	lea    0x10(%rsp),%rsi
  76df41:	mov    %r15,%rdi
  76df44:	call   76f420 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11pointer_hitBW_>
  76df49:	mov    %rax,0x60(%rsp)
  76df4e:	mov    %rdx,0x8(%rsp)
  76df53:	mov    0x54(%rsp),%ecx
  76df57:	jmp    76e04b <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x73b>
  76df5c:	mov    0x6a8(%r15),%rcx
  76df63:	cmp    $0xffffffffffffffff,%rcx
  76df67:	je     76df0e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76df69:	inc    %rcx
  76df6c:	mov    0x6a0(%r15),%rdx
  76df73:	cmp    %rdx,%rcx
  76df76:	jne    76df0e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76df78:	cmp    %rdx,0x6e0(%r15)
  76df7f:	jne    76df0e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76df81:	test   %rax,%rax
  76df84:	je     76df0e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76df86:	cmpq   $0x0,0x6d0(%r15)
  76df8e:	je     76df0e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76df94:	cmp    %rax,0x6d8(%r15)
  76df9b:	jne    76df0e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76dfa1:	cmp    0x5f0(%r15),%r12
  76dfa8:	jne    76df0e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76dfae:	lea    0x70(%rsp),%rsi
  76dfb3:	mov    %r15,%rdi
  76dfb6:	call   76f420 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11pointer_hitBW_>
  76dfbb:	mov    %rax,0x60(%rsp)
  76dfc0:	mov    %rdx,0x8(%rsp)
  76dfc5:	mov    0x650(%r15),%rax
  76dfcc:	test   %rax,%rax
  76dfcf:	je     76e00c <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x6fc>
  76dfd1:	cmpq   $0x0,0xd8(%rax)
  76dfd9:	je     76e00c <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x6fc>
  76dfdb:	cmp    %r12,0x60(%rsp)
  76dfe0:	jne    76df0e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76dfe6:	cmp    %r13,0x8(%rsp)
  76dfeb:	jne    76df0e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76dff1:	lea    0x70(%rsp),%rcx
  76dff6:	mov    %r15,%rdi
  76dff9:	mov    %r12,%rsi
  76dffc:	mov    %r13,%rdx
  76dfff:	call   76f550 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE19inspector_focus_hitBW_>
  76e004:	test   %al,%al
  76e006:	je     76df0e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76e00c:	lea    0x10(%rsp),%rdi
  76e011:	call   74d7d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  76e016:	jmp    76e049 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x739>
  76e018:	mov    %r15,%rdi
  76e01b:	call   78d460 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE3hitBO_>
  76e020:	test   $0x1,%al
  76e022:	je     76e040 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x730>
  76e024:	lea    0x5f0(%r15),%rdi
  76e02b:	mov    %rdx,%rsi
  76e02e:	call   *0x34c2dc(%rip)        # aba310 <_DYNAMIC+0x4a0>
  76e034:	mov    %rax,0x60(%rsp)
  76e039:	mov    %rdx,0x8(%rsp)
  76e03e:	jmp    76e049 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x739>
  76e040:	movq   $0x0,0x60(%rsp)
  76e049:	xor    %ecx,%ecx
  76e04b:	mov    0x650(%r15),%rax
  76e052:	test   %rax,%rax
  76e055:	je     76e069 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x759>
  76e057:	mov    0xd8(%rax),%rax
  76e05e:	test   %rax,%rax
  76e061:	je     76e069 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x759>
  76e063:	movzbl 0x12(%rax),%eax
  76e067:	jmp    76e06b <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x75b>
  76e069:	xor    %eax,%eax
  76e06b:	cmp    $0x2,%ebp
  76e06e:	jne    76e15c <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x84c>
  76e074:	mov    0x628(%r15),%rdx
  76e07b:	mov    0x630(%r15),%rcx
  76e082:	mov    0x60(%rsp),%rbp
  76e087:	test   %rbp,%rbp
  76e08a:	sete   %sil
  76e08e:	or     %al,%sil
  76e091:	test   $0x1,%sil
  76e095:	je     76e1a4 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x894>
  76e09b:	movq   $0x0,0x628(%r15)
  76e0a6:	lea    0x10(%rsp),%rdi
  76e0ab:	mov    %r15,%rsi
  76e0ae:	call   770db0 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE20publish_focus_changeB12_>
  76e0b3:	mov    0x10(%rsp),%rax
  76e0b8:	movups 0x18(%rsp),%xmm0
  76e0bd:	movaps %xmm0,0x70(%rsp)
  76e0c2:	movups 0x28(%rsp),%xmm0
  76e0c7:	movaps %xmm0,0x80(%rsp)
  76e0cf:	movups 0x38(%rsp),%xmm0
  76e0d4:	movaps %xmm0,0x90(%rsp)
  76e0dc:	cmp    $0xfffffffffffffffe,%rax
  76e0e0:	jne    76e295 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x985>
  76e0e6:	movaps 0x70(%rsp),%xmm0
  76e0eb:	movaps 0x80(%rsp),%xmm1
  76e0f3:	movaps 0x90(%rsp),%xmm2
  76e0fb:	movaps %xmm2,0xe0(%rsp)
  76e103:	movaps %xmm1,0xd0(%rsp)
  76e10b:	movaps %xmm0,0xc0(%rsp)
  76e113:	cmpq   $0xffffffffffffffff,0x5c8(%r15)
  76e11b:	je     76e2ea <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x9da>
  76e121:	mov    0x6a8(%r15),%rax
  76e128:	cmp    $0xffffffffffffffff,%rax
  76e12c:	je     76e2ea <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x9da>
  76e132:	inc    %rax
  76e135:	cmp    0x6a0(%r15),%rax
  76e13c:	jne    76e2ea <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x9da>
  76e142:	cmpq   $0x0,0x6d0(%r15)
  76e14a:	je     76e2ea <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x9da>
  76e150:	mov    0x6d8(%r15),%rax
  76e157:	jmp    76e2ec <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x9dc>
  76e15c:	test   %cl,%cl
  76e15e:	mov    0x60(%rsp),%rcx
  76e163:	jne    76ddc1 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4b1>
  76e169:	test   %rcx,%rcx
  76e16c:	je     76ddc1 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4b1>
  76e172:	cmp    %rcx,%r12
  76e175:	jne    76ddc1 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4b1>
  76e17b:	cmp    0x8(%rsp),%r13
  76e180:	jne    76ddc1 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4b1>
  76e186:	test   %al,%al
  76e188:	je     76e328 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xa18>
  76e18e:	mov    %rbx,%rdi
  76e191:	mov    %r15,%rsi
  76e194:	mov    %r12,%rdx
  76e197:	mov    %r13,%rcx
  76e19a:	call   773b80 <_RNvMs4_NtNtCslbxve4rcJus_4gpui7runtime9inspectorINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE16inspector_selectB14_>
  76e19f:	jmp    76df15 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76e1a4:	cmp    0x5f0(%r15),%rbp
  76e1ab:	jne    76e2be <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x9ae>
  76e1b1:	mov    %rcx,%r12
  76e1b4:	mov    %rdx,%r13
  76e1b7:	lea    0x10(%rsp),%rdi
  76e1bc:	mov    %r15,%rsi
  76e1bf:	mov    0x8(%rsp),%rdx
  76e1c4:	call   78d180 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE16resolve_identityBO_>
  76e1c9:	mov    0x10(%rsp),%rax
  76e1ce:	mov    0x18(%rsp),%rdi
  76e1d3:	cmp    $0xfffffffffffffffe,%rax
  76e1d7:	jne    76e2c3 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x9b3>
  76e1dd:	mov    0x2e0(%r15),%rsi
  76e1e4:	cmp    %rsi,%rdi
  76e1e7:	jae    76e550 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xc40>
  76e1ed:	mov    0x2d8(%r15),%rax
  76e1f4:	lea    (%rdi,%rdi,4),%rcx
  76e1f8:	mov    0x20(%rax,%rcx,8),%edi
  76e1fc:	call   776560 <_RNvMsh_NtCslbxve4rcJus_4gpui7runtimeNtB5_4Node4kind>
  76e201:	cmp    $0x4,%al
  76e203:	jne    76e41d <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xb0d>
  76e209:	mov    0x58(%rsp),%rax
  76e20e:	cmp    $0xffffffff,%eax
  76e211:	je     76e55d <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xc4d>
  76e217:	movss  0x4(%r14),%xmm1
  76e21d:	dec    %eax
  76e21f:	movd   %eax,%xmm0
  76e223:	lea    0x10(%rsp),%rdi
  76e228:	mov    %r15,%rsi
  76e22b:	mov    %rbp,%rdx
  76e22e:	mov    0x8(%rsp),%r15
  76e233:	mov    %r15,%rcx
  76e236:	xor    %r8d,%r8d
  76e239:	call   770790 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE14select_pointerB12_>
  76e23e:	mov    0x10(%rsp),%rax
  76e243:	movups 0x38(%rsp),%xmm0
  76e248:	movaps %xmm0,0x90(%rsp)
  76e250:	movdqu 0x28(%rsp),%xmm1
  76e256:	movdqa %xmm1,0x80(%rsp)
  76e25f:	movups 0x18(%rsp),%xmm2
  76e264:	movaps %xmm2,0x70(%rsp)
  76e269:	movups %xmm0,0x28(%rbx)
  76e26d:	movdqu %xmm1,0x18(%rbx)
  76e272:	movups %xmm2,0x8(%rbx)
  76e276:	cmp    $0xfffffffffffffffe,%rax
  76e27a:	jne    76e491 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xb81>
  76e280:	mov    %rbp,0x8(%r14)
  76e284:	mov    %r15,0x10(%r14)
  76e288:	movq   $0x0,0x18(%r14)
  76e290:	jmp    76de13 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x503>
  76e295:	movaps 0x70(%rsp),%xmm0
  76e29a:	movaps 0x80(%rsp),%xmm1
  76e2a2:	movaps 0x90(%rsp),%xmm2
  76e2aa:	movups %xmm2,0x28(%rbx)
  76e2ae:	movups %xmm1,0x18(%rbx)
  76e2b2:	movups %xmm0,0x8(%rbx)
  76e2b6:	mov    %rax,(%rbx)
  76e2b9:	jmp    76df15 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76e2be:	mov    $0x11,%eax
  76e2c3:	mov    0x40(%rsp),%rcx
  76e2c8:	mov    %rcx,0x30(%rbx)
  76e2cc:	movups 0x20(%rsp),%xmm0
  76e2d1:	movups 0x30(%rsp),%xmm1
  76e2d6:	movups %xmm1,0x20(%rbx)
  76e2da:	movups %xmm0,0x10(%rbx)
  76e2de:	mov    %rax,(%rbx)
  76e2e1:	mov    %rdi,0x8(%rbx)
  76e2e5:	jmp    76df15 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76e2ea:	xor    %eax,%eax
  76e2ec:	mov    %rbp,0x8(%r14)
  76e2f0:	mov    0x8(%rsp),%rcx
  76e2f5:	mov    %rcx,0x10(%r14)
  76e2f9:	mov    %rax,0x18(%r14)
  76e2fd:	movaps 0xc0(%rsp),%xmm0
  76e305:	movdqa 0xd0(%rsp),%xmm1
  76e30e:	movaps 0xe0(%rsp),%xmm2
  76e316:	movups %xmm2,0x28(%rbx)
  76e31a:	movdqu %xmm1,0x18(%rbx)
  76e31f:	movups %xmm0,0x8(%rbx)
  76e323:	jmp    76de13 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x503>
  76e328:	lea    0xb0(%rsp),%rsi
  76e330:	mov    %rbx,%rdi
  76e333:	mov    %r12,%rdx
  76e336:	mov    %r13,%rcx
  76e339:	call   76a290 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB4_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE8activateBW_>
  76e33e:	jmp    76df15 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76e343:	movq   $0x4,0x70(%rsp)
  76e34c:	pxor   %xmm0,%xmm0
  76e350:	movdqu %xmm0,0x78(%rsp)
  76e356:	mov    0x5c0(%r14),%rax
  76e35d:	mov    %rax,0x8(%rsp)
  76e362:	test   %rax,%rax
  76e365:	je     76e50d <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xbfd>
  76e36b:	mov    0x5b8(%r14),%rbp
  76e372:	mov    0x8(%rsp),%rax
  76e377:	mov    %rax,%r15
  76e37a:	shl    $0x6,%r15
  76e37e:	lea    -0x1(%rax),%r12
  76e382:	jmp    76e3e8 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xad8>
  76e384:	mov    0x80(%rsp),%rax
  76e38c:	mov    %rax,0x20(%rsp)
  76e391:	movups 0x70(%rsp),%xmm0
  76e396:	movaps %xmm0,0x10(%rsp)
  76e39b:	mov    0x650(%r14),%rax
  76e3a2:	test   %rax,%rax
  76e3a5:	je     76e419 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xb09>
  76e3a7:	cmpq   $0x0,(%rax)
  76e3ab:	setne  %al
  76e3ae:	movzbl %al,%ecx
  76e3b1:	mov    %rbp,%rdi
  76e3b4:	mov    0x8(%rsp),%rsi
  76e3b9:	lea    0x10(%rsp),%rdx
  76e3be:	mov    %r12,%r8
  76e3c1:	movd   0x54(%rsp),%xmm0
  76e3c7:	movss  0x58(%rsp),%xmm1
  76e3cd:	call   *0x34c135(%rip)        # aba508 <_DYNAMIC+0x698>
  76e3d3:	test   %al,%al
  76e3d5:	jne    76e499 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xb89>
  76e3db:	dec    %r12
  76e3de:	add    $0xffffffffffffffc0,%r15
  76e3e2:	je     76e50d <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xbfd>
  76e3e8:	cmpb   $0x0,-0x2(%rbp,%r15,1)
  76e3ee:	jne    76e384 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xa74>
  76e3f0:	movzbl -0x3(%rbp,%r15,1),%eax
  76e3f6:	sub    $0x2,%al
  76e3f8:	movzbl %al,%eax
  76e3fb:	mov    $0x8,%ecx
  76e400:	cmovb  %ecx,%eax
  76e403:	cmp    $0x7,%al
  76e405:	je     76e384 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xa74>
  76e40b:	movzbl %al,%eax
  76e40e:	cmp    $0x4,%eax
  76e411:	je     76e384 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xa74>
  76e417:	jmp    76e3db <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xacb>
  76e419:	xor    %eax,%eax
  76e41b:	jmp    76e3ae <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xa9e>
  76e41d:	lea    0x10(%rsp),%rdi
  76e422:	mov    %r15,%rsi
  76e425:	mov    %rbp,%rdx
  76e428:	mov    0x8(%rsp),%rcx
  76e42d:	call   76f9e0 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE5focusBW_>
  76e432:	mov    0x10(%rsp),%rax
  76e437:	cmp    $0xfffffffffffffffe,%rax
  76e43b:	jne    76e448 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xb38>
  76e43d:	mov    %r13,%rdx
  76e440:	mov    %r12,%rcx
  76e443:	jmp    76e0a6 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x796>
  76e448:	mov    0x38(%rsp),%rcx
  76e44d:	movzbl 0x40(%rsp),%edx
  76e452:	mov    0x41(%rsp),%esi
  76e456:	mov    %esi,0x70(%rsp)
  76e45a:	mov    0x44(%rsp),%esi
  76e45e:	mov    %esi,0x73(%rsp)
  76e462:	movups 0x18(%rsp),%xmm0
  76e467:	movups 0x28(%rsp),%xmm1
  76e46c:	mov    0x70(%rsp),%esi
  76e470:	mov    0x73(%rsp),%edi
  76e474:	mov    %edi,0x34(%rbx)
  76e477:	mov    %esi,0x31(%rbx)
  76e47a:	mov    %rax,(%rbx)
  76e47d:	movups %xmm0,0x8(%rbx)
  76e481:	movups %xmm1,0x18(%rbx)
  76e485:	mov    %rcx,0x28(%rbx)
  76e489:	mov    %dl,0x30(%rbx)
  76e48c:	jmp    76df15 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76e491:	mov    %rax,(%rbx)
  76e494:	jmp    76df15 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76e499:	movq   $0x19,0x10(%rsp)
  76e4a2:	lea    0x10(%rsp),%rdi
  76e4a7:	call   74d7d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  76e4ac:	mov    %r12,0xb8(%rsp)
  76e4b4:	movq   $0x1,0xb0(%rsp)
  76e4c0:	lea    0xb0(%rsp),%rdi
  76e4c8:	mov    %r14,%rsi
  76e4cb:	mov    %r14,%rdx
  76e4ce:	call   75ca70 <_RINvYINtNtNtNtCs4NRVxsYgnAr_4core4iter7sources7from_fn6FromFnNCNvMs6_NtNtCslbxve4rcJus_4gpui7runtime6scrollINtB17_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE12scroll_at_2ds0_0ENtNtNtBa_6traits8iterator8Iterator8try_folduNCINvNvB34_3any5checkjNCBZ_s1_0E0INtNtNtBc_3ops12control_flow11ControlFlowuEEB1U_>
  76e4d3:	test   %al,%al
  76e4d5:	je     76e50d <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xbfd>
  76e4d7:	movq   $0x1,0x18(%rsp)
  76e4e0:	mov    %r12,0x20(%rsp)
  76e4e5:	movaps 0x60(%rsp),%xmm0
  76e4ea:	movups %xmm0,0x28(%rsp)
  76e4ef:	movq   $0x3,0x10(%rsp)
  76e4f8:	lea    0x10(%rsp),%rdx
  76e4fd:	mov    %rbx,%rdi
  76e500:	mov    %r13,%rsi
  76e503:	call   7754a0 <_RNvMs6_NtNtCslbxve4rcJus_4gpui7runtime6scrollINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE17apply_scroll_planBT_>
  76e508:	jmp    76df15 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76e50d:	movq   $0x19,(%rbx)
  76e514:	jmp    76df15 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76e519:	lea    -0x69bd6f(%rip),%rdi        # d27b1 <GCC_except_table0+0x103e5>
  76e520:	lea    0x32cab9(%rip),%rdx        # a9afe0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1698>
  76e527:	mov    $0x22,%esi
  76e52c:	call   *0x34bc56(%rip)        # aba188 <_DYNAMIC+0x318>
  76e532:	lea    0x32cabf(%rip),%rdx        # a9aff8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x16b0>
  76e539:	call   *0x34bba1(%rip)        # aba0e0 <_DYNAMIC+0x270>
  76e53f:	jmp    76e54e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xc3e>
  76e541:	lea    0x32cac8(%rip),%rdi        # a9b010 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x16c8>
  76e548:	call   *0x34bc22(%rip)        # aba170 <_DYNAMIC+0x300>
  76e54e:	ud2
  76e550:	lea    0x32cad1(%rip),%rdx        # a9b028 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x16e0>
  76e557:	call   *0x34bb83(%rip)        # aba0e0 <_DYNAMIC+0x270>
  76e55d:	lea    0x32cadc(%rip),%rdi        # a9b040 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x16f8>
  76e564:	call   *0x34bc06(%rip)        # aba170 <_DYNAMIC+0x300>
  76e56a:	mov    %rax,%rbx
  76e56d:	lea    0x10(%rsp),%rdi
  76e572:	call   74d7d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  76e577:	mov    %rbx,%rdi
  76e57a:	call   a98590 <_Unwind_Resume@plt>
  76e57f:	mov    %rax,%rbx
  76e582:	lea    0x70(%rsp),%rdi
  76e587:	call   746440 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultNtNtCslbxve4rcJus_4gpui7runtime6CommitNtBZ_5ErrorEECs9C2G9YFESsD_29canonical_text_public_control>
  76e58c:	mov    %rbx,%rdi
  76e58f:	call   a98590 <_Unwind_Resume@plt>

<gpui::runtime::RuntimeMut<canonical_text_public_control::Editor, ()>>::replace_input bytes=1615 frame=248

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000076fd60 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_>:
  76fd60:	push   %rbp
  76fd61:	push   %r15
  76fd63:	push   %r14
  76fd65:	push   %r13
  76fd67:	push   %r12
  76fd69:	push   %rbx
  76fd6a:	sub    $0xc8,%rsp
  76fd71:	mov    %rdi,%rbx
  76fd74:	mov    (%rsi),%r13
  76fd77:	cmpb   $0x1,0x76e(%r13)
  76fd7f:	jne    76fd8d <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x2d>
  76fd81:	movq   $0xe,(%rbx)
  76fd88:	jmp    7701e8 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x488>
  76fd8d:	mov    %r8,%rbp
  76fd90:	mov    %r9,0x90(%rsp)
  76fd98:	mov    %rsi,0x98(%rsp)
  76fda0:	lea    0x30(%rsp),%rdi
  76fda5:	mov    %r13,%rsi
  76fda8:	call   76ae10 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11input_indexBY_>
  76fdad:	mov    0x30(%rsp),%rax
  76fdb2:	mov    0x38(%rsp),%rdx
  76fdb7:	cmp    $0xfffffffffffffffe,%rax
  76fdbb:	jne    76feb7 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x157>
  76fdc1:	mov    0x2e0(%r13),%rsi
  76fdc8:	cmp    %rsi,%rdx
  76fdcb:	jae    7702d3 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x573>
  76fdd1:	mov    0x2d8(%r13),%rcx
  76fdd8:	lea    (%rdx,%rdx,4),%r8
  76fddc:	mov    0x20(%rcx,%r8,8),%edi
  76fde1:	mov    %edi,%eax
  76fde3:	and    $0xf,%eax
  76fde6:	cmp    $0x9,%eax
  76fde9:	ja     770281 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x521>
  76fdef:	cmp    $0x6,%eax
  76fdf2:	je     7701fa <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x49a>
  76fdf8:	shr    $0x4,%edi
  76fdfb:	je     7701fa <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x49a>
  76fe01:	mov    0x2f8(%r13),%rsi
  76fe08:	dec    %edi
  76fe0a:	cmp    %rdi,%rsi
  76fe0d:	jbe    7702e6 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x586>
  76fe13:	mov    0x2f0(%r13),%rax
  76fe1a:	lea    (%rdi,%rdi,4),%rsi
  76fe1e:	shl    $0x4,%rsi
  76fe22:	cmpq   $0xfffffffffffffffe,(%rax,%rsi,1)
  76fe27:	je     770267 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x507>
  76fe2d:	add    %rsi,%rax
  76fe30:	mov    0x48(%rax),%r12
  76fe34:	test   %r12,%r12
  76fe37:	je     770274 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x514>
  76fe3d:	mov    0x608(%r13),%rax
  76fe44:	test   %rax,%rax
  76fe47:	je     7702ba <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x55a>
  76fe4d:	mov    (%rcx,%r8,8),%r14
  76fe51:	mov    0x610(%r13),%rcx
  76fe58:	movzwl 0x1c2(%rax),%edi
  76fe5f:	mov    %edi,%r9d
  76fe62:	shl    $0x5,%r9d
  76fe66:	mov    $0xffffffffffffffff,%rsi
  76fe6d:	xor    %r8d,%r8d
  76fe70:	cmp    %r8,%r9
  76fe73:	je     76fea0 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x140>
  76fe75:	cmp    0x170(%rax,%rsi,8),%r12
  76fe7d:	seta   %r10b
  76fe81:	sbb    $0x0,%r10b
  76fe85:	add    $0x20,%r8
  76fe89:	inc    %rsi
  76fe8c:	cmp    $0x1,%r10b
  76fe90:	je     76fe70 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x110>
  76fe92:	movzbl %r10b,%edi
  76fe96:	test   %edi,%edi
  76fe98:	je     76fee0 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x180>
  76fe9a:	jmp    76fea3 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x143>
  76fe9c:	nopl   0x0(%rax)
  76fea0:	mov    %rdi,%rsi
  76fea3:	sub    $0x1,%rcx
  76fea7:	jb     7702ba <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x55a>
  76fead:	mov    0x1c8(%rax,%rsi,8),%rax
  76feb5:	jmp    76fe58 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0xf8>
  76feb7:	mov    0x60(%rsp),%rcx
  76febc:	mov    %rcx,0x30(%rbx)
  76fec0:	movdqu 0x40(%rsp),%xmm0
  76fec6:	movups 0x50(%rsp),%xmm1
  76fecb:	movups %xmm1,0x20(%rbx)
  76fecf:	movdqu %xmm0,0x10(%rbx)
  76fed4:	mov    %rax,(%rbx)
  76fed7:	mov    %rdx,0x8(%rbx)
  76fedb:	jmp    7701e8 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x488>
  76fee0:	cmpq   $0xffffffffffffffff,-0x20(%rax,%r8,1)
  76fee6:	je     76fefe <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x19e>
  76fee8:	mov    -0x8(%rax,%r8,1),%r15
  76feed:	cmpb   $0x2,0xc(%rbp)
  76fef1:	je     76ff0b <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x1ab>
  76fef3:	movups 0x0(%rbp),%xmm0
  76fef7:	movups %xmm0,0x38(%rsp)
  76fefc:	jmp    76ff27 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x1c7>
  76fefe:	lea    0x32b51b(%rip),%r15        # a9b420 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1ad8>
  76ff05:	cmpb   $0x2,0xc(%rbp)
  76ff09:	jne    76fef3 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x193>
  76ff0b:	lea    0x30(%rsp),%rdi
  76ff10:	mov    %r13,%rsi
  76ff13:	call   76af50 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE12selection_atBY_>
  76ff18:	mov    0x30(%rsp),%rax
  76ff1d:	cmp    $0xfffffffffffffffe,%rax
  76ff21:	jne    7701ca <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x46a>
  76ff27:	mov    %r15,0x28(%rsp)
  76ff2c:	mov    %r14,0x88(%rsp)
  76ff34:	movdqu 0x38(%rsp),%xmm0
  76ff3a:	movdqa %xmm0,0xa0(%rsp)
  76ff43:	cmp    $0x1,%r12d
  76ff47:	jne    76ffa3 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x243>
  76ff49:	mov    0x248(%r13),%rbp
  76ff50:	mov    0x250(%r13),%r14
  76ff57:	shl    $0x4,%r14
  76ff5b:	xor    %r15d,%r15d
  76ff5e:	xchg   %ax,%ax
  76ff60:	cmp    %r15,%r14
  76ff63:	je     770194 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x434>
  76ff69:	mov    0x0(%rbp,%r15,1),%rdi
  76ff6e:	mov    0x8(%rbp,%r15,1),%rax
  76ff73:	call   *0x18(%rax)
  76ff76:	add    $0x10,%r15
  76ff7a:	cmp    %r12,%rax
  76ff7d:	jne    76ff60 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x200>
  76ff7f:	mov    -0x10(%rbp,%r15,1),%rdi
  76ff84:	mov    -0x8(%rbp,%r15,1),%rax
  76ff89:	lea    0x290(%r13),%rsi
  76ff90:	call   *0x28(%rax)
  76ff93:	mov    0x28(%rsp),%r15
  76ff98:	mov    %rax,%r14
  76ff9b:	mov    %rdx,%rbp
  76ff9e:	jmp    770027 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x2c7>
  76ffa3:	mov    0x278(%r13),%rbp
  76ffaa:	mov    0x280(%r13),%r14
  76ffb1:	shl    $0x4,%r14
  76ffb5:	xor    %r15d,%r15d
  76ffb8:	nopl   0x0(%rax,%rax,1)
  76ffc0:	cmp    %r15,%r14
  76ffc3:	je     770194 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x434>
  76ffc9:	mov    0x0(%rbp,%r15,1),%rdi
  76ffce:	mov    0x8(%rbp,%r15,1),%rax
  76ffd3:	mov    %r12,%rsi
  76ffd6:	call   *0x30(%rax)
  76ffd9:	add    $0x10,%r15
  76ffdd:	test   %al,%al
  76ffdf:	je     76ffc0 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x260>
  76ffe1:	mov    -0x10(%rbp,%r15,1),%rsi
  76ffe6:	mov    -0x8(%rbp,%r15,1),%rax
  76ffeb:	lea    0xb0(%rsp),%rdi
  76fff3:	lea    0x290(%r13),%rdx
  76fffa:	mov    %r12,%rcx
  76fffd:	call   *0x58(%rax)
  770000:	mov    0x28(%rsp),%r15
  770005:	mov    0xb0(%rsp),%rax
  77000d:	mov    0xb8(%rsp),%r14
  770015:	mov    0xc0(%rsp),%rbp
  77001d:	cmp    $0xffffffffffffffff,%rax
  770021:	jne    77019c <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x43c>
  770027:	mov    %r14,%rdi
  77002a:	call   *0x18(%rbp)
  77002d:	mov    %rdx,%rcx
  770030:	lea    0x30(%rsp),%rdi
  770035:	mov    %r15,%rsi
  770038:	mov    %rax,%rdx
  77003b:	mov    %r12,%r8
  77003e:	call   *0x34a504(%rip)        # aba548 <_DYNAMIC+0x6d8>
  770044:	mov    0x38(%rsp),%rax
  770049:	mov    0x40(%rsp),%r14
  77004e:	mov    0x48(%rsp),%rbp
  770053:	cmpb   $0x0,0x30(%rsp)
  770058:	jne    77019c <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x43c>
  77005e:	cmp    $0xffffffffffffffff,%rax
  770062:	je     770207 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x4a7>
  770068:	mov    %rax,0x10(%rsp)
  77006d:	mov    %r14,0x18(%rsp)
  770072:	mov    %rbp,0x80(%rsp)
  77007a:	mov    0x10(%rsp),%rax
  77007f:	mov    %rax,0x70(%rsp)
  770084:	mov    0x18(%rsp),%rax
  770089:	mov    %rax,0x78(%rsp)
  77008e:	mov    0x78(%rsp),%r14
  770093:	movdqa 0xa0(%rsp),%xmm0
  77009c:	movdqa %xmm0,0x30(%rsp)
  7700a2:	lea    0x30(%rsp),%rdx
  7700a7:	mov    %r14,%rdi
  7700aa:	mov    %rbp,%rsi
  7700ad:	call   *0x34a48d(%rip)        # aba540 <_DYNAMIC+0x6d0>
  7700b3:	mov    $0x18,%ecx
  7700b8:	test   %al,%al
  7700ba:	je     77029f <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x53f>
  7700c0:	movdqa 0xa0(%rsp),%xmm0
  7700c9:	movd   %xmm0,%r13d
  7700ce:	pshufd $0xee,%xmm0,%xmm0
  7700d3:	movd   %xmm0,%eax
  7700d7:	cmp    %r13,%rax
  7700da:	mov    %r13,%rbp
  7700dd:	cmovb  %rax,%rbp
  7700e1:	mov    %rbp,%r15
  7700e4:	mov    0x100(%rsp),%rcx
  7700ec:	add    %rcx,%r15
  7700ef:	jb     77029a <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x53a>
  7700f5:	cmp    %r13,%rax
  7700f8:	cmova  %rax,%r13
  7700fc:	movq   $0x1e,0x30(%rsp)
  770105:	lea    0x30(%rsp),%rdi
  77010a:	call   74d7d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  77010f:	lea    0x70(%rsp),%rdi
  770114:	mov    %rbp,%rsi
  770117:	mov    %r13,%rdx
  77011a:	mov    0x90(%rsp),%rcx
  770122:	mov    0x100(%rsp),%r8
  77012a:	call   73d920 <_RINvMNtCscdodAO9FK5_5alloc6stringNtB3_6String13replace_rangeINtNtNtCs4NRVxsYgnAr_4core3ops5range5RangejEECs9C2G9YFESsD_29canonical_text_public_control>
  77012f:	mov    0x88(%rsp),%rax
  770137:	mov    %rax,0x10(%rsp)
  77013c:	mov    %r12,0x20(%rsp)
  770141:	mov    %r15,0x18(%rsp)
  770146:	movq   $0x1,0x8(%rsp)
  77014f:	mov    %r12,0x48(%rsp)
  770154:	movaps 0x70(%rsp),%xmm0
  770159:	movaps %xmm0,0x30(%rsp)
  77015e:	mov    0x80(%rsp),%rax
  770166:	mov    %rax,0x40(%rsp)
  77016b:	mov    0x28(%rsp),%rax
  770170:	mov    %rax,0x50(%rsp)
  770175:	lea    0x30(%rsp),%rcx
  77017a:	lea    0x8(%rsp),%r8
  77017f:	mov    %rbx,%rdi
  770182:	mov    0x98(%rsp),%rsi
  77018a:	mov    %r12,%rdx
  77018d:	call   73da10 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_>
  770192:	jmp    7701e8 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x488>
  770194:	mov    $0xb,%eax
  770199:	mov    %r12,%r14
  77019c:	mov    %rax,0x10(%rsp)
  7701a1:	mov    %r14,0x18(%rsp)
  7701a6:	mov    %rbp,0x20(%rsp)
  7701ab:	mov    %rbp,0x18(%rbx)
  7701af:	mov    0x10(%rsp),%rax
  7701b4:	mov    %rax,0x8(%rbx)
  7701b8:	mov    0x18(%rsp),%rax
  7701bd:	mov    %rax,0x10(%rbx)
  7701c1:	movq   $0x20,(%rbx)
  7701c8:	jmp    7701e8 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x488>
  7701ca:	movups 0x48(%rsp),%xmm0
  7701cf:	movups 0x58(%rsp),%xmm1
  7701d4:	movups %xmm1,0x28(%rbx)
  7701d8:	movups %xmm0,0x18(%rbx)
  7701dc:	movups 0x38(%rsp),%xmm0
  7701e1:	mov    %rax,(%rbx)
  7701e4:	movups %xmm0,0x8(%rbx)
  7701e8:	add    $0xc8,%rsp
  7701ef:	pop    %rbx
  7701f0:	pop    %r12
  7701f2:	pop    %r13
  7701f4:	pop    %r14
  7701f6:	pop    %r15
  7701f8:	pop    %rbp
  7701f9:	ret
  7701fa:	lea    0x32aeff(%rip),%rdi        # a9b100 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x17b8>
  770201:	call   *0x349f69(%rip)        # aba170 <_DYNAMIC+0x300>
  770207:	test   %rbp,%rbp
  77020a:	jns    77021d <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x4bd>
  77020c:	xor    %r15d,%r15d
  77020f:	mov    %r15,%rdi
  770212:	mov    %rbp,%rsi
  770215:	call   *0x349f45(%rip)        # aba160 <_DYNAMIC+0x2f0>
  77021b:	ud2
  77021d:	je     770258 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x4f8>
  77021f:	call   *0x349e93(%rip)        # aba0b8 <_DYNAMIC+0x248>
  770225:	mov    $0x1,%r15d
  77022b:	mov    $0x1,%esi
  770230:	mov    %rbp,%rdi
  770233:	call   *0x349e87(%rip)        # aba0c0 <_DYNAMIC+0x250>
  770239:	test   %rax,%rax
  77023c:	je     77020f <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x4af>
  77023e:	mov    %rax,%rdi
  770241:	mov    %r14,%rsi
  770244:	mov    %rbp,%rdx
  770247:	mov    %rax,%r14
  77024a:	call   *0x349e80(%rip)        # aba0d0 <memcpy@GLIBC_2.14>
  770250:	mov    %rbp,%rax
  770253:	jmp    770068 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x308>
  770258:	mov    $0x1,%r14d
  77025e:	xor    %eax,%eax
  770260:	xor    %ebp,%ebp
  770262:	jmp    770068 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x308>
  770267:	lea    0x329ee2(%rip),%rdi        # a9a150 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x808>
  77026e:	call   *0x349efc(%rip)        # aba170 <_DYNAMIC+0x300>
  770274:	lea    0x32ae9d(%rip),%rdi        # a9b118 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x17d0>
  77027b:	call   *0x349eef(%rip)        # aba170 <_DYNAMIC+0x300>
  770281:	lea    -0x69d940(%rip),%rdi        # d2948 <GCC_except_table0+0x1057c>
  770288:	lea    0x32b161(%rip),%rdx        # a9b3f0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1aa8>
  77028f:	mov    $0x83,%esi
  770294:	call   *0x349e4e(%rip)        # aba0e8 <_DYNAMIC+0x278>
  77029a:	mov    $0x1e,%ecx
  77029f:	mov    %rcx,(%rbx)
  7702a2:	mov    0x70(%rsp),%rsi
  7702a7:	test   %rsi,%rsi
  7702aa:	je     7701e8 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x488>
  7702b0:	mov    $0x1,%edx
  7702b5:	jmp    77036b <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x60b>
  7702ba:	lea    -0x69daee(%rip),%rdi        # d27d3 <GCC_except_table0+0x10407>
  7702c1:	lea    0x32ae68(%rip),%rdx        # a9b130 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x17e8>
  7702c8:	mov    $0x16,%esi
  7702cd:	call   *0x349eb5(%rip)        # aba188 <_DYNAMIC+0x318>
  7702d3:	lea    0x32ae0e(%rip),%rax        # a9b0e8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x17a0>
  7702da:	mov    %rdx,%rdi
  7702dd:	mov    %rax,%rdx
  7702e0:	call   *0x349dfa(%rip)        # aba0e0 <_DYNAMIC+0x270>
  7702e6:	lea    0x329e4b(%rip),%rdx        # a9a138 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x7f0>
  7702ed:	call   *0x349ded(%rip)        # aba0e0 <_DYNAMIC+0x270>
  7702f3:	mov    %rax,%rbx
  7702f6:	mov    0x70(%rsp),%rsi
  7702fb:	test   %rsi,%rsi
  7702fe:	je     770310 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x5b0>
  770300:	mov    0x78(%rsp),%rdi
  770305:	mov    $0x1,%edx
  77030a:	call   *0x349da0(%rip)        # aba0b0 <_DYNAMIC+0x240>
  770310:	mov    %rbx,%rdi
  770313:	call   a98590 <_Unwind_Resume@plt>
  770318:	jmp    77031c <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x5bc>
  77031a:	jmp    77031c <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x5bc>
  77031c:	mov    %rax,%rdi
  77031f:	call   *0x349de3(%rip)        # aba108 <_DYNAMIC+0x298>
  770325:	mov    %rax,%r14
  770328:	mov    %rdx,%r15
  77032b:	mov    %rax,0x10(%rsp)
  770330:	mov    %rdx,0x18(%rsp)
  770335:	movq   $0x2,0x8(%rsp)
  77033e:	mov    %r13,%rdi
  770341:	call   78d7d0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE6poisonBO_>
  770346:	movq   $0xf,(%rbx)
  77034d:	mov    (%r15),%rax
  770350:	test   %rax,%rax
  770353:	je     77035a <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x5fa>
  770355:	mov    %r14,%rdi
  770358:	call   *%rax
  77035a:	mov    0x8(%r15),%rsi
  77035e:	test   %rsi,%rsi
  770361:	je     7701e8 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x488>
  770367:	mov    0x10(%r15),%rdx
  77036b:	mov    %r14,%rdi
  77036e:	call   *0x349d3c(%rip)        # aba0b0 <_DYNAMIC+0x240>
  770374:	jmp    7701e8 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x488>
  770379:	mov    %rax,%rbx
  77037c:	mov    0x8(%r15),%rsi
  770380:	test   %rsi,%rsi
  770383:	je     770310 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x5b0>
  770385:	mov    0x10(%r15),%rdx
  770389:	mov    %r14,%rdi
  77038c:	jmp    77030a <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x5aa>
  770391:	mov    %rax,%rbx
  770394:	lea    0x8(%rsp),%rdi
  770399:	call   746220 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultIBC_NtNtCscdodAO9FK5_5alloc6string6StringNtNtCslbxve4rcJus_4gpui6source9BindErrorEINtNtB15_5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECs9C2G9YFESsD_29canonical_text_public_control>
  77039e:	jmp    770310 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x5b0>
  7703a3:	call   *0x349d2f(%rip)        # aba0d8 <_DYNAMIC+0x268>
  7703a9:	call   *0x349d61(%rip)        # aba110 <_DYNAMIC+0x2a0>

<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::acknowledge bytes=1581 frame=200

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000077ba20 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_>:
  77ba20:	push   %r15
  77ba22:	push   %r14
  77ba24:	push   %r13
  77ba26:	push   %r12
  77ba28:	push   %rbx
  77ba29:	sub    $0xa0,%rsp
  77ba30:	mov    %rdi,%r14
  77ba33:	cmp    %rdx,0x6d0(%rsi)
  77ba3a:	jne    77bd7e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x35e>
  77ba40:	mov    %rcx,%r15
  77ba43:	mov    %rsi,%rbx
  77ba46:	cmp    %rcx,0x6d8(%rsi)
  77ba4d:	jne    77bd7e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x35e>
  77ba53:	lea    0x600(%rbx),%rdi
  77ba5a:	mov    %r15,%rsi
  77ba5d:	call   *0x33eb8d(%rip)        # aba5f0 <_DYNAMIC+0x780>
  77ba63:	mov    0x5e8(%rbx),%rax
  77ba6a:	mov    %rax,0x30(%rsp)
  77ba6f:	movdqu 0x5c8(%rbx),%xmm0
  77ba77:	movdqu 0x5d8(%rbx),%xmm1
  77ba7f:	movdqa %xmm0,0x10(%rsp)
  77ba85:	movq   $0xffffffffffffffff,0x5c8(%rbx)
  77ba90:	movzbl 0x76c(%rbx),%eax
  77ba97:	xor    $0x1,%rax
  77ba9b:	cmpq   $0xffffffffffffffff,0x10(%rsp)
  77baa1:	movdqa %xmm1,0x20(%rsp)
  77baa7:	mov    $0x1,%r13d
  77baad:	cmove  %rax,%r13
  77bab1:	je     77bb59 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x139>
  77bab7:	movdqa 0x30(%rsp),%xmm0
  77babd:	movss  0x34(%rsp),%xmm2
  77bac3:	movd   %xmm0,%eax
  77bac7:	pand   -0x6b7fbf(%rip),%xmm0        # c3b10 <GCC_except_table0+0x1744>
  77bacf:	pxor   %xmm1,%xmm1
  77bad3:	punpcklwd %xmm1,%xmm0
  77bad7:	movq   %xmm0,0x6c0(%rbx)
  77badf:	test   %ax,%ax
  77bae2:	js     77bd8a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x36a>
  77bae8:	movss  %xmm2,0xc(%rsp)
  77baee:	lea    0x5b0(%rbx),%r12
  77baf5:	mov    %r12,%rdi
  77baf8:	call   7474b0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCslbxve4rcJus_4gpui7runtime9PresentedEECs9C2G9YFESsD_29canonical_text_public_control>
  77bafd:	mov    0x20(%rsp),%rax
  77bb02:	mov    %rax,0x10(%r12)
  77bb07:	movaps 0x10(%rsp),%xmm0
  77bb0c:	movups %xmm0,(%r12)
  77bb11:	mov    0x6e8(%rbx),%rdi
  77bb18:	test   %rdi,%rdi
  77bb1b:	je     77bb23 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x103>
  77bb1d:	call   *0x33ead5(%rip)        # aba5f8 <_DYNAMIC+0x788>
  77bb23:	mov    0x650(%rbx),%rax
  77bb2a:	test   %rax,%rax
  77bb2d:	je     77bb4b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x12b>
  77bb2f:	mov    0xe0(%rax),%rax
  77bb36:	test   %rax,%rax
  77bb39:	je     77bb4b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x12b>
  77bb3b:	mov    0x50(%rax),%rcx
  77bb3f:	mov    %rcx,0x38(%rax)
  77bb43:	movups 0x40(%rax),%xmm0
  77bb47:	movups %xmm0,0x28(%rax)
  77bb4b:	movd   0xc(%rsp),%xmm0
  77bb51:	movd   %xmm0,0x764(%rbx)
  77bb59:	mov    0x650(%rbx),%rax
  77bb60:	test   %rax,%rax
  77bb63:	je     77bdac <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77bb69:	mov    0x60(%rax),%r12
  77bb6d:	movq   $0xffffffffffffffff,0x60(%rax)
  77bb75:	cmp    $0xffffffffffffffff,%r12
  77bb79:	je     77bc1d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x1fd>
  77bb7f:	mov    0xb8(%rax),%rcx
  77bb86:	mov    %rcx,0x90(%rsp)
  77bb8e:	movups 0xa8(%rax),%xmm0
  77bb95:	movaps %xmm0,0x80(%rsp)
  77bb9d:	movups 0x68(%rax),%xmm0
  77bba1:	movups 0x78(%rax),%xmm1
  77bba5:	movups 0x88(%rax),%xmm2
  77bbac:	movups 0x98(%rax),%xmm3
  77bbb3:	movaps %xmm3,0x70(%rsp)
  77bbb8:	movaps %xmm2,0x60(%rsp)
  77bbbd:	movaps %xmm1,0x50(%rsp)
  77bbc2:	movaps %xmm0,0x40(%rsp)
  77bbc7:	mov    0x650(%rbx),%rdi
  77bbce:	call   74ec60 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime8metadata5SheetECs9C2G9YFESsD_29canonical_text_public_control>
  77bbd3:	mov    0x650(%rbx),%rax
  77bbda:	mov    %r12,(%rax)
  77bbdd:	movaps 0x40(%rsp),%xmm0
  77bbe2:	movdqa 0x50(%rsp),%xmm1
  77bbe8:	movaps 0x60(%rsp),%xmm2
  77bbed:	movaps 0x70(%rsp),%xmm3
  77bbf2:	movups %xmm0,0x8(%rax)
  77bbf6:	movdqu %xmm1,0x18(%rax)
  77bbfb:	movups %xmm2,0x28(%rax)
  77bbff:	movups %xmm3,0x38(%rax)
  77bc03:	movdqa 0x80(%rsp),%xmm0
  77bc0c:	movdqu %xmm0,0x48(%rax)
  77bc11:	mov    0x90(%rsp),%rcx
  77bc19:	mov    %rcx,0x58(%rax)
  77bc1d:	mov    0x650(%rbx),%r12
  77bc24:	test   %r12,%r12
  77bc27:	je     77bdac <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77bc2d:	mov    0x100(%r12),%rdi
  77bc35:	test   %rdi,%rdi
  77bc38:	je     77bc89 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x269>
  77bc3a:	call   *0x33e9c0(%rip)        # aba600 <_DYNAMIC+0x790>
  77bc40:	mov    0x100(%r12),%rax
  77bc48:	cmpq   $0x0,0x10(%rax)
  77bc4d:	jne    77bc89 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x269>
  77bc4f:	cmpq   $0x0,0x58(%rax)
  77bc54:	jne    77bc89 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x269>
  77bc56:	cmpq   $0x0,0x28(%rax)
  77bc5b:	jne    77bc89 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x269>
  77bc5d:	cmpq   $0xffffffffffffffff,0x30(%rax)
  77bc62:	jne    77bc89 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x269>
  77bc64:	mov    0x650(%rbx),%rax
  77bc6b:	mov    0x100(%rax),%rdi
  77bc72:	call   745e80 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionINtNtCscdodAO9FK5_5alloc5boxed3BoxNtNtNtCslbxve4rcJus_4gpui7runtime8geometry8GeometryEEECs9C2G9YFESsD_29canonical_text_public_control>
  77bc77:	mov    0x650(%rbx),%rax
  77bc7e:	movq   $0x0,0x100(%rax)
  77bc89:	mov    0x650(%rbx),%r12
  77bc90:	test   %r12,%r12
  77bc93:	je     77bdac <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77bc99:	mov    0xe0(%r12),%rdi
  77bca1:	test   %rdi,%rdi
  77bca4:	je     77bcea <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x2ca>
  77bca6:	cmpb   $0x2,0x24(%rdi)
  77bcaa:	jne    77bcea <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x2ca>
  77bcac:	cmpb   $0x2,0x3c(%rdi)
  77bcb0:	jne    77bcea <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x2ca>
  77bcb2:	cmpb   $0x2,0x54(%rdi)
  77bcb6:	jne    77bcea <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x2ca>
  77bcb8:	mov    $0x58,%esi
  77bcbd:	mov    $0x8,%edx
  77bcc2:	call   *0x33e3e8(%rip)        # aba0b0 <_DYNAMIC+0x240>
  77bcc8:	mov    0x650(%rbx),%rax
  77bccf:	movq   $0x0,0xe0(%rax)
  77bcda:	mov    0x650(%rbx),%r12
  77bce1:	test   %r12,%r12
  77bce4:	je     77bdac <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77bcea:	cmpq   $0x0,0xd8(%r12)
  77bcf3:	jne    77bdac <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77bcf9:	cmpq   $0x0,0xe0(%r12)
  77bd02:	jne    77bdac <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77bd08:	cmpq   $0x0,0x100(%r12)
  77bd11:	jne    77bdac <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77bd17:	cmpq   $0x0,0xd0(%r12)
  77bd20:	jne    77bdac <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77bd26:	cmpq   $0x0,0xf8(%r12)
  77bd2f:	jne    77bdac <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77bd31:	mov    0x60(%r12),%rax
  77bd36:	cmp    $0xffffffff,%eax
  77bd39:	jne    77bdac <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77bd3b:	cmpq   $0x0,0x28(%r12)
  77bd41:	jne    77bdac <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77bd43:	mov    (%r12),%rax
  77bd47:	or     0x40(%r12),%rax
  77bd4c:	jne    77bdac <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77bd4e:	cmpq   $0x0,0x58(%r12)
  77bd54:	jne    77bdac <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77bd56:	mov    %r12,%rdi
  77bd59:	call   74ed00 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime8metadata8MetadataECs9C2G9YFESsD_29canonical_text_public_control>
  77bd5e:	mov    $0x108,%esi
  77bd63:	mov    $0x8,%edx
  77bd68:	mov    %r12,%rdi
  77bd6b:	call   *0x33e33f(%rip)        # aba0b0 <_DYNAMIC+0x240>
  77bd71:	movq   $0x0,0x650(%rbx)
  77bd7c:	jmp    77bdac <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77bd7e:	movq   $0x15,(%r14)
  77bd85:	jmp    77bf60 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x540>
  77bd8a:	movss  %xmm2,0x764(%rbx)
  77bd92:	lea    0x10(%rsp),%rdi
  77bd97:	call   7474b0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCslbxve4rcJus_4gpui7runtime9PresentedEECs9C2G9YFESsD_29canonical_text_public_control>
  77bd9c:	mov    0x650(%rbx),%rax
  77bda3:	test   %rax,%rax
  77bda6:	jne    77bb69 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x149>
  77bdac:	mov    0x6e8(%rbx),%rdi
  77bdb3:	test   %rdi,%rdi
  77bdb6:	je     77bddd <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x3bd>
  77bdb8:	cmpq   $0x0,0x30(%rdi)
  77bdbd:	jne    77bddd <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x3bd>
  77bdbf:	cmpq   $0x0,0x10(%rdi)
  77bdc4:	jne    77bddd <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x3bd>
  77bdc6:	cmpq   $0xffffffffffffffff,0x18(%rdi)
  77bdcb:	jne    77bddd <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x3bd>
  77bdcd:	call   745d10 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionINtNtCscdodAO9FK5_5alloc5boxed3BoxNtNtNtCslbxve4rcJus_4gpui7runtime13text_geometry13TextResourcesEEECs9C2G9YFESsD_29canonical_text_public_control>
  77bdd2:	movq   $0x0,0x6e8(%rbx)
  77bddd:	mov    0x628(%rbx),%rax
  77bde4:	test   %rax,%rax
  77bde7:	je     77be8f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x46f>
  77bded:	cmp    0x5f0(%rbx),%rax
  77bdf4:	jne    77be84 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x464>
  77bdfa:	mov    0x630(%rbx),%rdx
  77be01:	lea    0x40(%rsp),%rdi
  77be06:	mov    %rbx,%rsi
  77be09:	call   78d180 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE16resolve_identityBO_>
  77be0e:	mov    0x40(%rsp),%rax
  77be13:	mov    0x48(%rsp),%rsi
  77be18:	cmp    $0xfffffffffffffffe,%rax
  77be1c:	jne    77be49 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x429>
  77be1e:	mov    0x2e0(%rbx),%rax
  77be25:	cmp    %rax,%rsi
  77be28:	jae    77bf71 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x551>
  77be2e:	lea    (%rsi,%rsi,4),%rdi
  77be32:	shl    $0x3,%rdi
  77be36:	add    0x2d8(%rbx),%rdi
  77be3d:	call   *0x33e595(%rip)        # aba3d8 <_DYNAMIC+0x568>
  77be43:	test   %al,%al
  77be45:	je     77be84 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x464>
  77be47:	jmp    77be8f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x46f>
  77be49:	cmp    $0xd,%rax
  77be4d:	jl     77be67 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x447>
  77be4f:	cmp    $0x21,%rax
  77be53:	je     77be67 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x447>
  77be55:	cmp    $0x26,%rax
  77be59:	jne    77be84 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x464>
  77be5b:	test   %rsi,%rsi
  77be5e:	je     77be84 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x464>
  77be60:	lea    0x50(%rsp),%rax
  77be65:	jmp    77be76 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x456>
  77be67:	mov    0x58(%rsp),%rsi
  77be6c:	test   %rsi,%rsi
  77be6f:	je     77be84 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x464>
  77be71:	lea    0x60(%rsp),%rax
  77be76:	mov    (%rax),%rdi
  77be79:	mov    $0x1,%edx
  77be7e:	call   *0x33e22c(%rip)        # aba0b0 <_DYNAMIC+0x240>
  77be84:	movq   $0x0,0x628(%rbx)
  77be8f:	mov    0x6e0(%rbx),%rax
  77be96:	mov    %rax,0x6a8(%rbx)
  77be9d:	mov    %r15,0x6b0(%rbx)
  77bea4:	mov    0x6b8(%rbx),%rcx
  77beab:	test   %rcx,%rcx
  77beae:	je     77bf02 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x4e2>
  77beb0:	mov    0x6c0(%rbx),%rdx
  77beb7:	cmpb   $0x0,0x59(%rcx)
  77bebb:	je     77bed3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x4b3>
  77bebd:	cmp    %r15,0x30(%rcx)
  77bec1:	jne    77bee5 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x4c5>
  77bec3:	cmp    %rax,0x38(%rcx)
  77bec7:	jne    77bee5 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x4c5>
  77bec9:	cmp    %rdx,0x40(%rcx)
  77becd:	sete   %sil
  77bed1:	jmp    77bee7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x4c7>
  77bed3:	cmp    %rax,0x38(%rcx)
  77bed7:	jne    77bee5 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x4c5>
  77bed9:	cmp    %r15,0x30(%rcx)
  77bedd:	jne    77bee5 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x4c5>
  77bedf:	cmp    %rdx,0x40(%rcx)
  77bee3:	je     77bf02 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x4e2>
  77bee5:	xor    %esi,%esi
  77bee7:	and    %sil,0x58(%rcx)
  77beeb:	movb   $0x0,0x59(%rcx)
  77beef:	mov    %r15,0x30(%rcx)
  77bef3:	mov    %rax,0x38(%rcx)
  77bef7:	mov    %rdx,0x40(%rcx)
  77befb:	mov    0x6a8(%rbx),%rax
  77bf02:	movb   $0x1,0x76c(%rbx)
  77bf09:	add    %r13,0x738(%rbx)
  77bf10:	mov    0x6a0(%rbx),%rcx
  77bf17:	cmpq   $0x0,0x6d0(%rbx)
  77bf1f:	je     77bf37 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x517>
  77bf21:	mov    0x6e0(%rbx),%rsi
  77bf28:	xor    %edx,%edx
  77bf2a:	cmpq   $0xffffffffffffffff,0x5c8(%rbx)
  77bf32:	setne  %dl
  77bf35:	jmp    77bf39 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x519>
  77bf37:	xor    %edx,%edx
  77bf39:	mov    0x758(%rbx),%rdi
  77bf40:	mov    %rdx,0x8(%r14)
  77bf44:	mov    %rsi,0x10(%r14)
  77bf48:	mov    %rcx,0x18(%r14)
  77bf4c:	mov    %rax,0x20(%r14)
  77bf50:	mov    %rdi,0x28(%r14)
  77bf54:	movb   $0x1,0x30(%r14)
  77bf59:	movq   $0xfffffffffffffffe,(%r14)
  77bf60:	add    $0xa0,%rsp
  77bf67:	pop    %rbx
  77bf68:	pop    %r12
  77bf6a:	pop    %r13
  77bf6c:	pop    %r14
  77bf6e:	pop    %r15
  77bf70:	ret
  77bf71:	lea    0x31e130(%rip),%rdx        # a9a0a8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x760>
  77bf78:	mov    %rsi,%rdi
  77bf7b:	mov    %rax,%rsi
  77bf7e:	call   *0x33e15c(%rip)        # aba0e0 <_DYNAMIC+0x270>
  77bf84:	mov    %rax,%r14
  77bf87:	mov    $0x108,%esi
  77bf8c:	mov    $0x8,%edx
  77bf91:	mov    %r12,%rdi
  77bf94:	call   *0x33e116(%rip)        # aba0b0 <_DYNAMIC+0x240>
  77bf9a:	movq   $0x0,0x650(%rbx)
  77bfa5:	mov    %r14,%rdi
  77bfa8:	call   a98590 <_Unwind_Resume@plt>
  77bfad:	mov    %rax,%r14
  77bfb0:	mov    0x650(%rbx),%rax
  77bfb7:	movq   $0x0,0x100(%rax)
  77bfc2:	mov    %r14,%rdi
  77bfc5:	call   a98590 <_Unwind_Resume@plt>
  77bfca:	movq   $0x0,0x6e8(%rbx)
  77bfd5:	mov    %rax,%rdi
  77bfd8:	call   a98590 <_Unwind_Resume@plt>
  77bfdd:	mov    %rax,%r14
  77bfe0:	mov    0x650(%rbx),%rax
  77bfe7:	mov    %r12,(%rax)
  77bfea:	movaps 0x40(%rsp),%xmm0
  77bfef:	movaps 0x50(%rsp),%xmm1
  77bff4:	movaps 0x60(%rsp),%xmm2
  77bff9:	movaps 0x70(%rsp),%xmm3
  77bffe:	movups %xmm0,0x8(%rax)
  77c002:	movups %xmm1,0x18(%rax)
  77c006:	movups %xmm2,0x28(%rax)
  77c00a:	movups %xmm3,0x38(%rax)
  77c00e:	movaps 0x80(%rsp),%xmm0
  77c016:	movups %xmm0,0x48(%rax)
  77c01a:	mov    0x90(%rsp),%rcx
  77c022:	mov    %rcx,0x58(%rax)
  77c026:	mov    %r14,%rdi
  77c029:	call   a98590 <_Unwind_Resume@plt>
  77c02e:	mov    %rax,%r14
  77c031:	mov    0x20(%rsp),%rax
  77c036:	mov    %rax,0x10(%r12)
  77c03b:	movaps 0x10(%rsp),%xmm0
  77c040:	movups %xmm0,(%r12)
  77c045:	mov    %r14,%rdi
  77c048:	call   a98590 <_Unwind_Resume@plt>

<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::present_inner bytes=22621 frame=3768

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000077c050 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_>:
  77c050:	push   %rbp
  77c051:	push   %r15
  77c053:	push   %r14
  77c055:	push   %r13
  77c057:	push   %r12
  77c059:	push   %rbx
  77c05a:	sub    $0xe88,%rsp
  77c061:	mov    %rdi,0x48(%rsp)
  77c066:	mov    0x5f8(%rsi),%rax
  77c06d:	mov    %rax,0x260(%rsp)
  77c075:	inc    %rax
  77c078:	je     780a3a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x49ea>
  77c07e:	mov    %rsi,%r13
  77c081:	mov    %rax,0x8b0(%rsp)
  77c089:	mov    0x5f0(%rsi),%rax
  77c090:	mov    %rax,0x680(%rsp)
  77c098:	mov    0x6c8(%rsi),%rsi
  77c09f:	mov    %rsi,%r14
  77c0a2:	shr    $0x20,%r14
  77c0a6:	movss  0x760(%r13),%xmm0
  77c0af:	movss  %xmm0,0x9c(%rsp)
  77c0b8:	mov    0x1a8(%r13),%eax
  77c0bf:	mov    0x1b0(%r13),%rcx
  77c0c6:	shl    $0x20,%rcx
  77c0ca:	or     %rax,%rcx
  77c0cd:	cmp    %rcx,%rsi
  77c0d0:	jne    77c0f8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xa8>
  77c0d2:	mov    %rsi,%r15
  77c0d5:	movq   $0x2,0xca0(%rsp)
  77c0e1:	mov    $0x2,%ebx
  77c0e6:	cmp    $0xffff,%r15d
  77c0ed:	jbe    77c19a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x14a>
  77c0f3:	jmp    77c1ab <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x15b>
  77c0f8:	movups 0x138(%r13),%xmm0
  77c100:	movaps %xmm0,0x970(%rsp)
  77c108:	lea    0x390(%rsp),%rdi
  77c110:	lea    0x970(%rsp),%rcx
  77c118:	mov    %rsi,%r15
  77c11b:	mov    %r14,%r12
  77c11e:	mov    %r14d,%edx
  77c121:	call   *0x33e299(%rip)        # aba3c0 <_DYNAMIC+0x550>
  77c127:	mov    0x390(%rsp),%rbx
  77c12f:	mov    0x398(%rsp),%r14d
  77c137:	mov    0x39c(%rsp),%ebp
  77c13e:	cmp    $0x2,%rbx
  77c142:	jne    77c15c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x10c>
  77c144:	mov    0x48(%rsp),%rax
  77c149:	movq   $0x23,(%rax)
  77c150:	mov    %r14d,0x8(%rax)
  77c154:	mov    %ebp,0xc(%rax)
  77c157:	jmp    77d891 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1841>
  77c15c:	lea    0x3a0(%rsp),%rsi
  77c164:	lea    0xcb0(%rsp),%rdi
  77c16c:	mov    $0x1d8,%edx
  77c171:	call   *0x33df59(%rip)        # aba0d0 <memcpy@GLIBC_2.14>
  77c177:	mov    %rbx,0xca0(%rsp)
  77c17f:	mov    %r14d,0xca8(%rsp)
  77c187:	mov    %ebp,0xcac(%rsp)
  77c18e:	mov    %r12,%r14
  77c191:	cmp    $0xffff,%r15d
  77c198:	ja     77c1ab <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x15b>
  77c19a:	mov    %r15,0xf8(%rsp)
  77c1a2:	mov    %r15,%rax
  77c1a5:	shr    $0x30,%rax
  77c1a9:	je     77c1cc <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17c>
  77c1ab:	mov    0x48(%rsp),%rax
  77c1b0:	movq   $0x23,(%rax)
  77c1b7:	movl   $0x0,0x8(%rax)
  77c1be:	cmp    $0x2,%ebx
  77c1c1:	jne    77d884 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1834>
  77c1c7:	jmp    77d891 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1841>
  77c1cc:	cmpq   $0x0,0x2f8(%r13)
  77c1d4:	mov    %r13,0x40(%rsp)
  77c1d9:	je     77c1ee <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x19e>
  77c1db:	mov    0x6e8(%r13),%rax
  77c1e2:	test   %rax,%rax
  77c1e5:	je     77c203 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1b3>
  77c1e7:	cmpq   $0x0,0x30(%rax)
  77c1ec:	je     77c250 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x200>
  77c1ee:	mov    0x6e8(%r13),%rax
  77c1f5:	test   %rax,%rax
  77c1f8:	jne    77c345 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2f5>
  77c1fe:	jmp    77c3a2 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x352>
  77c203:	call   *0x33deaf(%rip)        # aba0b8 <_DYNAMIC+0x248>
  77c209:	mov    $0x78,%edi
  77c20e:	mov    $0x8,%esi
  77c213:	call   *0x33dea7(%rip)        # aba0c0 <_DYNAMIC+0x250>
  77c219:	test   %rax,%rax
  77c21c:	je     780e57 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4e07>
  77c222:	movq   $0x0,(%rax)
  77c229:	movq   $0x8,0x8(%rax)
  77c231:	movq   $0x0,0x10(%rax)
  77c239:	movq   $0xffffffffffffffff,0x18(%rax)
  77c241:	movq   $0x0,0x30(%rax)
  77c249:	mov    %rax,0x6e8(%r13)
  77c250:	mov    %r14,%rbx
  77c253:	mov    $0x1,%bpl
  77c256:	lea    0x390(%rsp),%rdi
  77c25e:	call   *0x33e3a4(%rip)        # aba608 <_DYNAMIC+0x798>
  77c264:	mov    0x390(%rsp),%r12
  77c26c:	mov    0x398(%rsp),%r14d
  77c274:	mov    0x39c(%rsp),%ebp
  77c27b:	test   %r12,%r12
  77c27e:	je     77d79d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x174d>
  77c284:	mov    0x3d0(%rsp),%rax
  77c28c:	mov    %rax,0x9a0(%rsp)
  77c294:	movups 0x3a0(%rsp),%xmm0
  77c29c:	movups 0x3b0(%rsp),%xmm1
  77c2a4:	movups 0x3c0(%rsp),%xmm2
  77c2ac:	movaps %xmm2,0x990(%rsp)
  77c2b4:	movaps %xmm1,0x980(%rsp)
  77c2bc:	movaps %xmm0,0x970(%rsp)
  77c2c4:	mov    0x6e8(%r13),%r15
  77c2cb:	mov    0x30(%r15),%rax
  77c2cf:	test   %rax,%rax
  77c2d2:	je     77c2f7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2a7>
  77c2d4:	lock decq (%rax)
  77c2d8:	jne    77c2e4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x294>
  77c2da:	lea    0x30(%r15),%rdi
  77c2de:	call   *0x33debc(%rip)        # aba1a0 <_DYNAMIC+0x330>
  77c2e4:	add    $0x38,%r15
  77c2e8:	mov    %r15,%rdi
  77c2eb:	call   74cf90 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text11RasterCacheECs9C2G9YFESsD_29canonical_text_public_control>
  77c2f0:	mov    0x6e8(%r13),%r15
  77c2f7:	mov    %r12,0x30(%r15)
  77c2fb:	mov    %r14d,0x38(%r15)
  77c2ff:	mov    %ebp,0x3c(%r15)
  77c303:	movaps 0x970(%rsp),%xmm0
  77c30b:	movaps 0x980(%rsp),%xmm1
  77c313:	movaps 0x990(%rsp),%xmm2
  77c31b:	movups %xmm0,0x40(%r15)
  77c320:	movups %xmm1,0x50(%r15)
  77c325:	movups %xmm2,0x60(%r15)
  77c32a:	mov    0x9a0(%rsp),%rax
  77c332:	mov    %rax,0x70(%r15)
  77c336:	mov    %rbx,%r14
  77c339:	mov    0x6e8(%r13),%rax
  77c340:	test   %rax,%rax
  77c343:	je     77c3a2 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x352>
  77c345:	mov    0x30(%rax),%rax
  77c349:	test   %rax,%rax
  77c34c:	je     77c3a2 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x352>
  77c34e:	lock incq (%rax)
  77c352:	jle    7811d8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  77c358:	mov    %rax,0xd0(%rsp)
  77c360:	movq   $0x0,0x200(%rsp)
  77c36c:	movq   $0x8,0x208(%rsp)
  77c378:	movq   $0x0,0x210(%rsp)
  77c384:	lea    0xd0(%rsp),%rax
  77c38c:	mov    %rax,0x1c0(%rsp)
  77c394:	movq   $0x0,0x1c8(%rsp)
  77c3a0:	jmp    77c3de <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x38e>
  77c3a2:	movq   $0x0,0xd0(%rsp)
  77c3ae:	movq   $0x0,0x200(%rsp)
  77c3ba:	movq   $0x8,0x208(%rsp)
  77c3c6:	movq   $0x0,0x210(%rsp)
  77c3d2:	movq   $0x0,0x1c0(%rsp)
  77c3de:	lea    0x778(%rsp),%rdi
  77c3e6:	mov    %r13,%rsi
  77c3e9:	call   76b520 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE16active_selectionBY_>
  77c3ee:	lea    0x390(%rsp),%rdi
  77c3f6:	mov    %r13,%rsi
  77c3f9:	call   76b520 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE16active_selectionBY_>
  77c3fe:	movzbl 0x3a4(%rsp),%eax
  77c406:	mov    %al,0x57(%rsp)
  77c40a:	cmp    $0x2,%al
  77c40c:	je     77c45e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x40e>
  77c40e:	mov    0x390(%rsp),%rax
  77c416:	mov    %rax,0x678(%rsp)
  77c41e:	test   %rax,%rax
  77c421:	je     780e39 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4de9>
  77c427:	mov    0x3a0(%rsp),%eax
  77c42e:	mov    %eax,0x2f0(%rsp)
  77c435:	mov    0x398(%rsp),%rax
  77c43d:	mov    %rax,0x2e8(%rsp)
  77c445:	movzwl 0x3a5(%rsp),%eax
  77c44d:	mov    %ax,0x7a(%rsp)
  77c452:	movzbl 0x3a7(%rsp),%eax
  77c45a:	mov    %al,0x7c(%rsp)
  77c45e:	lea    0x300(%r13),%rax
  77c465:	mov    %rax,0x58(%rsp)
  77c46a:	cmpb   $0x0,0x768(%r13)
  77c472:	mov    %r14,0x2e0(%rsp)
  77c47a:	jne    77c7c2 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x772>
  77c480:	cmpb   $0x0,0x769(%r13)
  77c488:	jne    77c7c2 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x772>
  77c48e:	cmpb   $0x0,0x590(%r13)
  77c496:	jne    77c7c2 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x772>
  77c49c:	mov    0x658(%r13),%rax
  77c4a3:	mov    0x668(%r13),%r15
  77c4aa:	test   %rax,%rax
  77c4ad:	setne  %cl
  77c4b0:	test   %r15,%r15
  77c4b3:	setne  %dl
  77c4b6:	and    %cl,%dl
  77c4b8:	cmp    $0x1,%dl
  77c4bb:	jne    77cd24 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xcd4>
  77c4c1:	mov    0x660(%r13),%r14
  77c4c8:	lea    0x1e8(%r13),%rcx
  77c4cf:	mov    %rcx,0x30(%rsp)
  77c4d4:	lea    0x688(%r13),%rcx
  77c4db:	mov    %rcx,0x38(%rsp)
  77c4e0:	xor    %ebx,%ebx
  77c4e2:	lea    0x31efd7(%rip),%rcx        # a9b4c0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1b78>
  77c4e9:	mov    %rcx,0x80(%rsp)
  77c4f1:	jmp    77c520 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4d0>
  77c4f3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  77c500:	mov    0x38(%rsp),%rdi
  77c505:	mov    %rbp,%rsi
  77c508:	call   77afd0 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapyNtNtB7_7set_val9SetValZSTE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  77c50d:	mov    $0x0,%eax
  77c512:	dec    %r15
  77c515:	mov    0x40(%rsp),%r13
  77c51a:	je     77cd24 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xcd4>
  77c520:	test   %rbx,%rbx
  77c523:	je     77c540 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4f0>
  77c525:	movzwl 0x58a(%rbx),%ecx
  77c52c:	cmp    %rcx,%r14
  77c52f:	jae    77c5f0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5a0>
  77c535:	mov    %rbx,%rcx
  77c538:	mov    %r14,%rdx
  77c53b:	jmp    77c616 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5c6>
  77c540:	test   %r14,%r14
  77c543:	je     77c57d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x52d>
  77c545:	mov    %r14,%rcx
  77c548:	mov    %rax,%rbx
  77c54b:	and    $0x7,%rcx
  77c54f:	je     77c582 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x532>
  77c551:	xor    %edx,%edx
  77c553:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  77c560:	mov    0x590(%rbx),%rbx
  77c567:	inc    %rdx
  77c56a:	cmp    %rdx,%rcx
  77c56d:	jne    77c560 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x510>
  77c56f:	mov    %r14,%rax
  77c572:	sub    %rdx,%rax
  77c575:	cmp    $0x8,%r14
  77c579:	jae    77c590 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x540>
  77c57b:	jmp    77c5ce <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57e>
  77c57d:	mov    %rax,%rbx
  77c580:	jmp    77c5ce <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57e>
  77c582:	mov    %r14,%rax
  77c585:	cmp    $0x8,%r14
  77c589:	jb     77c5ce <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57e>
  77c58b:	nopl   0x0(%rax,%rax,1)
  77c590:	mov    0x590(%rbx),%rcx
  77c597:	mov    0x590(%rcx),%rcx
  77c59e:	mov    0x590(%rcx),%rcx
  77c5a5:	mov    0x590(%rcx),%rcx
  77c5ac:	mov    0x590(%rcx),%rcx
  77c5b3:	mov    0x590(%rcx),%rcx
  77c5ba:	mov    0x590(%rcx),%rcx
  77c5c1:	mov    0x590(%rcx),%rbx
  77c5c8:	add    $0xfffffffffffffff8,%rax
  77c5cc:	jne    77c590 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x540>
  77c5ce:	xor    %eax,%eax
  77c5d0:	xor    %r14d,%r14d
  77c5d3:	movzwl 0x58a(%rbx),%ecx
  77c5da:	cmp    %rcx,%r14
  77c5dd:	jb     77c535 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4e5>
  77c5e3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  77c5f0:	mov    0x580(%rbx),%rcx
  77c5f7:	test   %rcx,%rcx
  77c5fa:	je     780e6f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4e1f>
  77c600:	inc    %rax
  77c603:	movzwl 0x588(%rbx),%edx
  77c60a:	mov    %rcx,%rbx
  77c60d:	cmp    0x58a(%rcx),%dx
  77c614:	jae    77c5f0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5a0>
  77c616:	test   %rax,%rax
  77c619:	je     77c6b0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x660>
  77c61f:	lea    (%rcx,%rdx,8),%rsi
  77c623:	add    $0x598,%rsi
  77c62a:	mov    %rax,%rdi
  77c62d:	and    $0x7,%rdi
  77c631:	je     77c7b0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x760>
  77c637:	xor    %r8d,%r8d
  77c63a:	nopw   0x0(%rax,%rax,1)
  77c640:	mov    (%rsi),%rbx
  77c643:	lea    0x590(%rbx),%rsi
  77c64a:	inc    %r8
  77c64d:	cmp    %r8,%rdi
  77c650:	jne    77c640 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5f0>
  77c652:	mov    %rax,%rdi
  77c655:	sub    %r8,%rdi
  77c658:	cmp    $0x8,%rax
  77c65c:	jb     77c6a1 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x651>
  77c65e:	xchg   %ax,%ax
  77c660:	mov    (%rsi),%rax
  77c663:	mov    0x590(%rax),%rax
  77c66a:	mov    0x590(%rax),%rax
  77c671:	mov    0x590(%rax),%rax
  77c678:	mov    0x590(%rax),%rax
  77c67f:	mov    0x590(%rax),%rax
  77c686:	mov    0x590(%rax),%rax
  77c68d:	mov    0x590(%rax),%rbx
  77c694:	lea    0x590(%rbx),%rsi
  77c69b:	add    $0xfffffffffffffff8,%rdi
  77c69f:	jne    77c660 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x610>
  77c6a1:	xor    %r14d,%r14d
  77c6a4:	jmp    77c6b7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x667>
  77c6a6:	cs nopw 0x0(%rax,%rax,1)
  77c6b0:	lea    0x1(%rdx),%r14
  77c6b4:	mov    %rcx,%rbx
  77c6b7:	imul   $0x70,%rdx,%rax
  77c6bb:	shl    $0x4,%rdx
  77c6bf:	lea    (%rcx,%rax,1),%rdi
  77c6c3:	add    $0xb0,%rdi
  77c6ca:	mov    (%rcx,%rdx,1),%rsi
  77c6ce:	mov    0x8(%rcx,%rdx,1),%rdx
  77c6d3:	call   *0x33db6f(%rip)        # aba248 <_DYNAMIC+0x3d8>
  77c6d9:	mov    %rax,%rbp
  77c6dc:	mov    0x30(%rsp),%rdi
  77c6e1:	mov    %rax,%rsi
  77c6e4:	call   776080 <_RNvMs_NtNtCslbxve4rcJus_4gpui7runtime14identity_indexNtB4_13IdentityIndex8required>
  77c6e9:	mov    %rax,%r12
  77c6ec:	mov    0x40(%rsp),%rax
  77c6f1:	mov    0x2e0(%rax),%r13
  77c6f8:	cmp    %r13,%r12
  77c6fb:	jae    781067 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5017>
  77c701:	mov    0x2d8(%rax),%rcx
  77c708:	lea    (%r12,%r12,4),%rax
  77c70c:	mov    0x18(%rcx,%rax,8),%r12d
  77c711:	mov    $0xffffffff,%eax
  77c716:	cmp    %rax,%r12
  77c719:	je     77c50d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4bd>
  77c71f:	cmp    %r12,%r13
  77c722:	jbe    780fc9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4f79>
  77c728:	mov    0x38(%rsp),%rax
  77c72d:	mov    (%rax),%rax
  77c730:	test   %rax,%rax
  77c733:	je     77c50d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4bd>
  77c739:	lea    (%r12,%r12,4),%rdx
  77c73d:	mov    (%rcx,%rdx,8),%rcx
  77c741:	mov    0x40(%rsp),%rdx
  77c746:	mov    0x690(%rdx),%rdx
  77c74d:	movzwl 0x62(%rax),%edi
  77c751:	mov    %edi,%r8d
  77c754:	shl    $0x3,%r8d
  77c758:	mov    $0xffffffffffffffff,%rsi
  77c75f:	nop
  77c760:	test   %r8,%r8
  77c763:	je     77c790 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x740>
  77c765:	cmp    0x10(%rax,%rsi,8),%rcx
  77c76a:	seta   %r9b
  77c76e:	sbb    $0x0,%r9b
  77c772:	inc    %rsi
  77c775:	add    $0xfffffffffffffff8,%r8
  77c779:	cmp    $0x1,%r9b
  77c77d:	je     77c760 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x710>
  77c77f:	movzbl %r9b,%edi
  77c783:	test   %edi,%edi
  77c785:	je     77c500 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4b0>
  77c78b:	jmp    77c793 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x743>
  77c78d:	nopl   (%rax)
  77c790:	mov    %rdi,%rsi
  77c793:	sub    $0x1,%rdx
  77c797:	jb     77c50d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4bd>
  77c79d:	mov    0x68(%rax,%rsi,8),%rax
  77c7a2:	jmp    77c74d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x6fd>
  77c7a4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  77c7b0:	mov    %rax,%rdi
  77c7b3:	cmp    $0x8,%rax
  77c7b7:	jae    77c660 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x610>
  77c7bd:	jmp    77c6a1 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x651>
  77c7c2:	lea    0x390(%rsp),%rdi
  77c7ca:	call   *0x33dc00(%rip)        # aba3d0 <_DYNAMIC+0x560>
  77c7d0:	lea    0x300(%r13),%r14
  77c7d7:	mov    %r14,%rdi
  77c7da:	call   74c510 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscO85OU7Wpt0_20gpui_reactivity_core6layout10LayoutTreeECs9C2G9YFESsD_29canonical_text_public_control>
  77c7df:	lea    0x390(%rsp),%rsi
  77c7e7:	mov    $0x298,%edx
  77c7ec:	mov    %r14,%rdi
  77c7ef:	call   *0x33d8db(%rip)        # aba0d0 <memcpy@GLIBC_2.14>
  77c7f5:	movq   $0x0,0x5a8(%r13)
  77c800:	mov    0x2e0(%r13),%rax
  77c807:	test   %rax,%rax
  77c80a:	je     77d2f6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x12a6>
  77c810:	mov    0x40(%rsp),%rcx
  77c815:	lea    0x598(%rcx),%rdx
  77c81c:	mov    %rdx,0x38(%rsp)
  77c821:	mov    0x2d8(%rcx),%rbx
  77c828:	lea    (%rax,%rax,4),%rax
  77c82c:	lea    (%rbx,%rax,8),%rax
  77c830:	mov    %rax,0x30(%rsp)
  77c835:	xor    %r13d,%r13d
  77c838:	lea    -0x6b870b(%rip),%r14        # c4134 <GCC_except_table0+0x1d68>
  77c83f:	lea    0x31d982(%rip),%rax        # a9a1c8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x880>
  77c846:	mov    %rax,0x80(%rsp)
  77c84e:	xor    %ebp,%ebp
  77c850:	jmp    77c89b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x84b>
  77c852:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  77c860:	add    $0x28,%rbx
  77c864:	inc    %rbp
  77c867:	mov    0x40(%rsp),%rdx
  77c86c:	mov    0x5a0(%rdx),%rax
  77c873:	mov    %r13,%rcx
  77c876:	shl    $0x4,%rcx
  77c87a:	movaps 0x950(%rsp),%xmm0
  77c882:	movups %xmm0,(%rax,%rcx,1)
  77c886:	inc    %r13
  77c889:	mov    %r13,0x5a8(%rdx)
  77c890:	cmp    0x30(%rsp),%rbx
  77c895:	je     77d2f6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x12a6>
  77c89b:	mov    0x18(%rbx),%r12d
  77c89f:	mov    $0xffffffff,%eax
  77c8a4:	cmp    %rax,%r12
  77c8a7:	je     77c8e0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x890>
  77c8a9:	cmp    %r12,%r13
  77c8ac:	jbe    781067 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5017>
  77c8b2:	mov    0x40(%rsp),%rax
  77c8b7:	mov    0x5a0(%rax),%rax
  77c8be:	mov    %r12,%rcx
  77c8c1:	shl    $0x4,%rcx
  77c8c5:	movups (%rax,%rcx,1),%xmm0
  77c8c9:	lea    0xc68(%rsp),%rax
  77c8d1:	movups %xmm0,(%rax)
  77c8d4:	mov    $0x1,%eax
  77c8d9:	jmp    77c8e2 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x892>
  77c8db:	nopl   0x0(%rax,%rax,1)
  77c8e0:	xor    %eax,%eax
  77c8e2:	mov    %rax,0xc60(%rsp)
  77c8ea:	mov    0x20(%rbx),%eax
  77c8ed:	and    $0xf,%eax
  77c8f0:	cmp    $0xa,%eax
  77c8f3:	jae    780e1b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4dcb>
  77c8f9:	lea    -0x6a975f(%rip),%rcx        # d31a1 <GCC_except_table0+0x10dd5>
  77c900:	movzbl (%rax,%rcx,1),%r15d
  77c905:	mov    0x40(%rsp),%rcx
  77c90a:	mov    0x200(%rcx),%rax
  77c911:	movslq (%r14,%rax,4),%rax
  77c915:	add    %r14,%rax
  77c918:	jmp    *%rax
  77c91a:	movups -0x6b8485(%rip),%xmm0        # c449c <GCC_except_table0+0x20d0>
  77c921:	movaps %xmm0,0x9b0(%rsp)
  77c929:	movups -0x6b84a4(%rip),%xmm0        # c448c <GCC_except_table0+0x20c0>
  77c930:	movaps %xmm0,0x9a0(%rsp)
  77c938:	movups -0x6b84c3(%rip),%xmm0        # c447c <GCC_except_table0+0x20b0>
  77c93f:	movaps %xmm0,0x990(%rsp)
  77c947:	movups -0x6b84e2(%rip),%xmm0        # c446c <GCC_except_table0+0x20a0>
  77c94e:	movaps %xmm0,0x980(%rsp)
  77c956:	movups -0x6b8501(%rip),%xmm0        # c445c <GCC_except_table0+0x2090>
  77c95d:	movaps %xmm0,0x970(%rsp)
  77c965:	movabs $0x3000100000000,%rax
  77c96f:	mov    %rax,0x9c0(%rsp)
  77c977:	cmp    $0xffffffff,%r12d
  77c97b:	jne    77ca11 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x9c1>
  77c981:	jmp    77cac8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xa78>
  77c986:	mov    0x220(%rcx),%r13
  77c98d:	cmp    %r13,%rbp
  77c990:	jae    78101d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4fcd>
  77c996:	mov    0x210(%rcx),%r13
  77c99d:	mov    0x218(%rcx),%rax
  77c9a4:	movzbl (%rax,%rbp,1),%eax
  77c9a8:	cmp    %rax,%r13
  77c9ab:	jbe    781029 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4fd9>
  77c9b1:	mov    0x208(%rcx),%rcx
  77c9b8:	imul   $0x58,%rax,%rax
  77c9bc:	mov    0x50(%rcx,%rax,1),%rdx
  77c9c1:	mov    %rdx,0x9c0(%rsp)
  77c9c9:	movups 0x40(%rcx,%rax,1),%xmm0
  77c9ce:	movaps %xmm0,0x9b0(%rsp)
  77c9d6:	movups (%rcx,%rax,1),%xmm0
  77c9da:	movups 0x10(%rcx,%rax,1),%xmm1
  77c9df:	movups 0x20(%rcx,%rax,1),%xmm2
  77c9e4:	movupd 0x30(%rcx,%rax,1),%xmm3
  77c9ea:	jmp    77ca9d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xa4d>
  77c9ef:	mov    0x208(%rcx),%rsi
  77c9f6:	lea    0x970(%rsp),%rdi
  77c9fe:	mov    %rbp,%rdx
  77ca01:	call   *0x33d859(%rip)        # aba260 <_DYNAMIC+0x3f0>
  77ca07:	cmp    $0xffffffff,%r12d
  77ca0b:	je     77cac8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xa78>
  77ca11:	mov    0x40(%rsp),%rdx
  77ca16:	mov    0x200(%rdx),%rax
  77ca1d:	lea    -0x6b88e0(%rip),%rsi        # c4144 <GCC_except_table0+0x1d78>
  77ca24:	movslq (%rsi,%rax,4),%rcx
  77ca28:	add    %rsi,%rcx
  77ca2b:	lea    -0x6b85d6(%rip),%rax        # c445c <GCC_except_table0+0x2090>
  77ca32:	jmp    *%rcx
  77ca34:	mov    0x218(%rdx),%r13
  77ca3b:	cmp    %r12,%r13
  77ca3e:	jbe    781014 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4fc4>
  77ca44:	imul   $0x58,%r12,%rax
  77ca48:	add    0x210(%rdx),%rax
  77ca4f:	jmp    77cb1e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xace>
  77ca54:	mov    0x218(%rcx),%r13
  77ca5b:	cmp    %r13,%rbp
  77ca5e:	jae    78102e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4fde>
  77ca64:	mov    0x210(%rcx),%rax
  77ca6b:	imul   $0x58,%rbp,%rcx
  77ca6f:	mov    0x50(%rax,%rcx,1),%rdx
  77ca74:	mov    %rdx,0x9c0(%rsp)
  77ca7c:	movups 0x40(%rax,%rcx,1),%xmm0
  77ca81:	movaps %xmm0,0x9b0(%rsp)
  77ca89:	movups (%rax,%rcx,1),%xmm0
  77ca8d:	movups 0x10(%rax,%rcx,1),%xmm1
  77ca92:	movups 0x20(%rax,%rcx,1),%xmm2
  77ca97:	movupd 0x30(%rax,%rcx,1),%xmm3
  77ca9d:	movapd %xmm3,0x9a0(%rsp)
  77caa6:	movaps %xmm2,0x990(%rsp)
  77caae:	movaps %xmm1,0x980(%rsp)
  77cab6:	movaps %xmm0,0x970(%rsp)
  77cabe:	cmp    $0xffffffff,%r12d
  77cac2:	jne    77ca11 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x9c1>
  77cac8:	mov    $0x2,%al
  77caca:	mov    0x40(%rsp),%rdx
  77cacf:	mov    0x670(%rdx),%r8
  77cad6:	test   %r8,%r8
  77cad9:	jne    77cb9e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xb4e>
  77cadf:	jmp    77cc30 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xbe0>
  77cae4:	mov    0x220(%rdx),%r13
  77caeb:	cmp    %r12,%r13
  77caee:	jbe    78100b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4fbb>
  77caf4:	mov    %rdx,%rcx
  77caf7:	mov    0x210(%rdx),%r13
  77cafe:	mov    0x218(%rdx),%rax
  77cb05:	movzbl (%rax,%r12,1),%r12d
  77cb0a:	cmp    %r12,%r13
  77cb0d:	jbe    781058 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5008>
  77cb13:	imul   $0x58,%r12,%rax
  77cb17:	add    0x208(%rcx),%rax
  77cb1e:	mov    0x50(%rax),%rcx
  77cb22:	mov    %rcx,0x3e0(%rsp)
  77cb2a:	movups 0x40(%rax),%xmm0
  77cb2e:	movaps %xmm0,0x3d0(%rsp)
  77cb36:	movups (%rax),%xmm0
  77cb39:	movups 0x10(%rax),%xmm1
  77cb3d:	movups 0x20(%rax),%xmm2
  77cb41:	movupd 0x30(%rax),%xmm3
  77cb46:	movapd %xmm3,0x3c0(%rsp)
  77cb4f:	movaps %xmm2,0x3b0(%rsp)
  77cb57:	movaps %xmm1,0x3a0(%rsp)
  77cb5f:	movaps %xmm0,0x390(%rsp)
  77cb67:	jmp    77cb81 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xb31>
  77cb69:	mov    0x208(%rdx),%rsi
  77cb70:	lea    0x390(%rsp),%rdi
  77cb78:	mov    %r12,%rdx
  77cb7b:	call   *0x33d6df(%rip)        # aba260 <_DYNAMIC+0x3f0>
  77cb81:	movzbl 0x3e4(%rsp),%eax
  77cb89:	mov    0x40(%rsp),%rdx
  77cb8e:	mov    0x670(%rdx),%r8
  77cb95:	test   %r8,%r8
  77cb98:	je     77cc30 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xbe0>
  77cb9e:	mov    (%rbx),%rcx
  77cba1:	mov    0x678(%rdx),%rdx
  77cba8:	movzwl 0x1c2(%r8),%edi
  77cbb0:	mov    %edi,%r10d
  77cbb3:	shl    $0x5,%r10d
  77cbb7:	mov    $0xffffffffffffffff,%rsi
  77cbbe:	xor    %r9d,%r9d
  77cbc1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  77cbd0:	mov    %r10,%r11
  77cbd3:	add    %r9,%r11
  77cbd6:	je     77cc00 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xbb0>
  77cbd8:	cmp    0x170(%r8,%rsi,8),%rcx
  77cbe0:	seta   %r11b
  77cbe4:	sbb    $0x0,%r11b
  77cbe8:	add    $0xffffffffffffffe0,%r9
  77cbec:	inc    %rsi
  77cbef:	cmp    $0x1,%r11b
  77cbf3:	je     77cbd0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xb80>
  77cbf5:	movzbl %r11b,%edi
  77cbf9:	test   %edi,%edi
  77cbfb:	jne    77cc03 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xbb3>
  77cbfd:	jmp    77cc20 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xbd0>
  77cbff:	nop
  77cc00:	mov    %rdi,%rsi
  77cc03:	sub    $0x1,%rdx
  77cc07:	jb     77cc30 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xbe0>
  77cc09:	mov    0x1c8(%r8,%rsi,8),%r8
  77cc11:	jmp    77cba8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xb58>
  77cc13:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  77cc20:	sub    %r9,%r8
  77cc23:	add    $0xffffffffffffffe0,%r8
  77cc27:	jmp    77cc33 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xbe3>
  77cc29:	nopl   0x0(%rax)
  77cc30:	xor    %r8d,%r8d
  77cc33:	movzbl %r15b,%esi
  77cc37:	movzbl %al,%ecx
  77cc3a:	lea    0x390(%rsp),%rdi
  77cc42:	lea    0x970(%rsp),%rdx
  77cc4a:	call   *0x33d9c0(%rip)        # aba610 <_DYNAMIC+0x7a0>
  77cc50:	lea    0x810(%rsp),%rdi
  77cc58:	mov    0x58(%rsp),%rsi
  77cc5d:	lea    0xc60(%rsp),%rdx
  77cc65:	xor    %ecx,%ecx
  77cc67:	lea    0x390(%rsp),%r8
  77cc6f:	call   *0x33d9a3(%rip)        # aba618 <_DYNAMIC+0x7a8>
  77cc75:	cmpb   $0x0,0x810(%rsp)
  77cc7d:	jne    77d80d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17bd>
  77cc83:	lea    0x818(%rsp),%rax
  77cc8b:	movups (%rax),%xmm0
  77cc8e:	lea    0x316(%rsp),%rax
  77cc96:	movups %xmm0,(%rax)
  77cc99:	movups (%rax),%xmm0
  77cc9c:	movaps %xmm0,0x950(%rsp)
  77cca4:	mov    0x20(%rbx),%ecx
  77cca7:	mov    %ecx,%eax
  77cca9:	and    $0xf,%eax
  77ccac:	cmp    $0x9,%eax
  77ccaf:	ja     780e1b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4dcb>
  77ccb5:	cmp    $0x6,%eax
  77ccb8:	je     77ccca <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xc7a>
  77ccba:	cmp    $0x10,%ecx
  77ccbd:	setae  %cl
  77ccc0:	cmp    $0x6,%eax
  77ccc3:	sete   %al
  77ccc6:	or     %cl,%al
  77ccc8:	je     77ccfc <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xcac>
  77ccca:	movaps 0x950(%rsp),%xmm0
  77ccd2:	movaps %xmm0,0x390(%rsp)
  77ccda:	mov    0x58(%rsp),%rdi
  77ccdf:	lea    0x390(%rsp),%rsi
  77cce7:	mov    0x33d932(%rip),%rdx        # aba620 <_DYNAMIC+0x7b0>
  77ccee:	call   *0x33d934(%rip)        # aba628 <_DYNAMIC+0x7b8>
  77ccf4:	test   $0x1,%al
  77ccf6:	jne    77d7fc <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17ac>
  77ccfc:	mov    0x40(%rsp),%rax
  77cd01:	mov    0x5a8(%rax),%r13
  77cd08:	cmp    0x598(%rax),%r13
  77cd0f:	jne    77c860 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x810>
  77cd15:	mov    0x38(%rsp),%rdi
  77cd1a:	call   7727e0 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecAINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtCslbxve4rcJus_4gpui6source7FieldIdEj2_E8grow_oneCs9C2G9YFESsD_29canonical_text_public_control>
  77cd1f:	jmp    77c860 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x810>
  77cd24:	mov    0x688(%r13),%rax
  77cd2b:	mov    0x698(%r13),%rdi
  77cd32:	test   %rax,%rax
  77cd35:	setne  %cl
  77cd38:	test   %rdi,%rdi
  77cd3b:	setne  %dl
  77cd3e:	and    %cl,%dl
  77cd40:	cmp    $0x1,%dl
  77cd43:	jne    77d2f6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x12a6>
  77cd49:	mov    0x40(%rsp),%rcx
  77cd4e:	mov    0x690(%rcx),%rbx
  77cd55:	add    $0x1e8,%rcx
  77cd5c:	mov    %rcx,0xc0(%rsp)
  77cd64:	xor    %ebp,%ebp
  77cd66:	lea    0x31e70b(%rip),%rcx        # a9b478 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1b30>
  77cd6d:	mov    %rcx,0x80(%rsp)
  77cd75:	data16 cs nopw 0x0(%rax,%rax,1)
  77cd80:	test   %rbp,%rbp
  77cd83:	je     77cd9f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xd4f>
  77cd85:	mov    0x40(%rsp),%r14
  77cd8a:	movzwl 0x62(%rbp),%ecx
  77cd8e:	cmp    %rcx,%rbx
  77cd91:	jae    77ce30 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xde0>
  77cd97:	mov    %rbp,%r15
  77cd9a:	jmp    77ce4e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xdfe>
  77cd9f:	test   %rbx,%rbx
  77cda2:	mov    0x40(%rsp),%r14
  77cda7:	je     77cdda <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xd8a>
  77cda9:	mov    %rbx,%rcx
  77cdac:	mov    %rax,%rbp
  77cdaf:	and    $0x7,%rcx
  77cdb3:	je     77cddf <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xd8f>
  77cdb5:	xor    %edx,%edx
  77cdb7:	nopw   0x0(%rax,%rax,1)
  77cdc0:	mov    0x68(%rbp),%rbp
  77cdc4:	inc    %rdx
  77cdc7:	cmp    %rdx,%rcx
  77cdca:	jne    77cdc0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xd70>
  77cdcc:	mov    %rbx,%rax
  77cdcf:	sub    %rdx,%rax
  77cdd2:	cmp    $0x8,%rbx
  77cdd6:	jae    77cdf0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xda0>
  77cdd8:	jmp    77ce16 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xdc6>
  77cdda:	mov    %rax,%rbp
  77cddd:	jmp    77ce16 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xdc6>
  77cddf:	mov    %rbx,%rax
  77cde2:	cmp    $0x8,%rbx
  77cde6:	jb     77ce16 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xdc6>
  77cde8:	nopl   0x0(%rax,%rax,1)
  77cdf0:	mov    0x68(%rbp),%rcx
  77cdf4:	mov    0x68(%rcx),%rcx
  77cdf8:	mov    0x68(%rcx),%rcx
  77cdfc:	mov    0x68(%rcx),%rcx
  77ce00:	mov    0x68(%rcx),%rcx
  77ce04:	mov    0x68(%rcx),%rcx
  77ce08:	mov    0x68(%rcx),%rcx
  77ce0c:	mov    0x68(%rcx),%rbp
  77ce10:	add    $0xfffffffffffffff8,%rax
  77ce14:	jne    77cdf0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xda0>
  77ce16:	xor    %eax,%eax
  77ce18:	xor    %ebx,%ebx
  77ce1a:	movzwl 0x62(%rbp),%ecx
  77ce1e:	cmp    %rcx,%rbx
  77ce21:	jb     77cd97 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xd47>
  77ce27:	nopw   0x0(%rax,%rax,1)
  77ce30:	mov    0x0(%rbp),%r15
  77ce34:	test   %r15,%r15
  77ce37:	je     780ebb <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4e6b>
  77ce3d:	inc    %rax
  77ce40:	movzwl 0x60(%rbp),%ebx
  77ce44:	mov    %r15,%rbp
  77ce47:	cmp    0x62(%r15),%bx
  77ce4c:	jae    77ce30 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xde0>
  77ce4e:	test   %rax,%rax
  77ce51:	mov    %rdi,0x38(%rsp)
  77ce56:	je     77cec7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xe77>
  77ce58:	lea    (%r15,%rbx,8),%rcx
  77ce5c:	add    $0x70,%rcx
  77ce60:	mov    %rax,%rdx
  77ce63:	and    $0x7,%rdx
  77ce67:	je     77d116 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x10c6>
  77ce6d:	xor    %esi,%esi
  77ce6f:	nop
  77ce70:	mov    (%rcx),%rbp
  77ce73:	lea    0x68(%rbp),%rcx
  77ce77:	inc    %rsi
  77ce7a:	cmp    %rsi,%rdx
  77ce7d:	jne    77ce70 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xe20>
  77ce7f:	mov    %rax,%rdx
  77ce82:	sub    %rsi,%rdx
  77ce85:	cmp    $0x8,%rax
  77ce89:	jb     77ceb9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xe69>
  77ce8b:	nopl   0x0(%rax,%rax,1)
  77ce90:	mov    (%rcx),%rax
  77ce93:	mov    0x68(%rax),%rax
  77ce97:	mov    0x68(%rax),%rax
  77ce9b:	mov    0x68(%rax),%rax
  77ce9f:	mov    0x68(%rax),%rax
  77cea3:	mov    0x68(%rax),%rax
  77cea7:	mov    0x68(%rax),%rax
  77ceab:	mov    0x68(%rax),%rbp
  77ceaf:	lea    0x68(%rbp),%rcx
  77ceb3:	add    $0xfffffffffffffff8,%rdx
  77ceb7:	jne    77ce90 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xe40>
  77ceb9:	movq   $0x0,0xa8(%rsp)
  77cec5:	jmp    77ced6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xe86>
  77cec7:	lea    0x1(%rbx),%rax
  77cecb:	mov    %rax,0xa8(%rsp)
  77ced3:	mov    %r15,%rbp
  77ced6:	mov    0x8(%r15,%rbx,8),%rsi
  77cedb:	mov    0xc0(%rsp),%rdi
  77cee3:	call   776080 <_RNvMs_NtNtCslbxve4rcJus_4gpui7runtime14identity_indexNtB4_13IdentityIndex8required>
  77cee8:	mov    %rax,%r12
  77ceeb:	mov    0x5a8(%r14),%r13
  77cef2:	cmp    %r13,%rax
  77cef5:	jae    781067 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5017>
  77cefb:	mov    0x5a0(%r14),%rax
  77cf02:	mov    %r12,%rcx
  77cf05:	shl    $0x4,%rcx
  77cf09:	movups (%rax,%rcx,1),%xmm0
  77cf0d:	movaps %xmm0,0x310(%rsp)
  77cf15:	mov    0x2e0(%r14),%r13
  77cf1c:	cmp    %r13,%r12
  77cf1f:	jae    780ff9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4fa9>
  77cf25:	mov    0x2d8(%r14),%rax
  77cf2c:	lea    (%r12,%r12,4),%rsi
  77cf30:	mov    0x20(%rax,%rsi,8),%eax
  77cf34:	and    $0xf,%eax
  77cf37:	cmp    $0xa,%eax
  77cf3a:	jae    780e1b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4dcb>
  77cf40:	lea    -0x6a9da6(%rip),%rcx        # d31a1 <GCC_except_table0+0x10dd5>
  77cf47:	movzbl (%rax,%rcx,1),%eax
  77cf4b:	mov    %al,0x30(%rsp)
  77cf4f:	mov    0x40(%rsp),%r14
  77cf54:	mov    0x200(%r14),%rax
  77cf5b:	lea    -0x6b8e4e(%rip),%rcx        # c4114 <GCC_except_table0+0x1d48>
  77cf62:	movslq (%rcx,%rax,4),%rax
  77cf66:	add    %rcx,%rax
  77cf69:	jmp    *%rax
  77cf6b:	movups -0x6b8ad6(%rip),%xmm0        # c449c <GCC_except_table0+0x20d0>
  77cf72:	movaps %xmm0,0x9b0(%rsp)
  77cf7a:	movups -0x6b8af5(%rip),%xmm0        # c448c <GCC_except_table0+0x20c0>
  77cf81:	movaps %xmm0,0x9a0(%rsp)
  77cf89:	movups -0x6b8b14(%rip),%xmm0        # c447c <GCC_except_table0+0x20b0>
  77cf90:	movaps %xmm0,0x990(%rsp)
  77cf98:	movups -0x6b8b33(%rip),%xmm0        # c446c <GCC_except_table0+0x20a0>
  77cf9f:	movaps %xmm0,0x980(%rsp)
  77cfa7:	movups -0x6b8b52(%rip),%xmm0        # c445c <GCC_except_table0+0x2090>
  77cfae:	movaps %xmm0,0x970(%rsp)
  77cfb6:	movabs $0x3000100000000,%rax
  77cfc0:	mov    %rax,0x9c0(%rsp)
  77cfc8:	jmp    77d095 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1045>
  77cfcd:	mov    0x220(%r14),%rax
  77cfd4:	cmp    %rax,%r12
  77cfd7:	jae    781046 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4ff6>
  77cfdd:	mov    0x210(%r14),%rax
  77cfe4:	mov    0x218(%r14),%rcx
  77cfeb:	movzbl (%rcx,%r12,1),%ecx
  77cff0:	cmp    %rcx,%rax
  77cff3:	jbe    781052 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5002>
  77cff9:	mov    0x208(%r14),%rax
  77d000:	imul   $0x58,%rcx,%rcx
  77d004:	jmp    77d046 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xff6>
  77d006:	mov    0x208(%r14),%rsi
  77d00d:	lea    0x970(%rsp),%rdi
  77d015:	mov    %r12,%rdx
  77d018:	call   *0x33d242(%rip)        # aba260 <_DYNAMIC+0x3f0>
  77d01e:	mov    0x2e0(%r14),%r13
  77d025:	lea    (%r12,%r12,4),%rsi
  77d029:	jmp    77d095 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1045>
  77d02b:	mov    0x218(%r14),%rax
  77d032:	cmp    %rax,%r12
  77d035:	jae    78103a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4fea>
  77d03b:	mov    0x210(%r14),%rax
  77d042:	imul   $0x58,%r12,%rcx
  77d046:	mov    0x50(%rax,%rcx,1),%rdx
  77d04b:	mov    %rdx,0x9c0(%rsp)
  77d053:	movups 0x40(%rax,%rcx,1),%xmm0
  77d058:	movaps %xmm0,0x9b0(%rsp)
  77d060:	movups (%rax,%rcx,1),%xmm0
  77d064:	movups 0x10(%rax,%rcx,1),%xmm1
  77d069:	movups 0x20(%rax,%rcx,1),%xmm2
  77d06e:	movupd 0x30(%rax,%rcx,1),%xmm3
  77d074:	movapd %xmm3,0x9a0(%rsp)
  77d07d:	movaps %xmm2,0x990(%rsp)
  77d085:	movaps %xmm1,0x980(%rsp)
  77d08d:	movaps %xmm0,0x970(%rsp)
  77d095:	cmp    %r13,%r12
  77d098:	jae    781002 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4fb2>
  77d09e:	mov    0x40(%rsp),%r13
  77d0a3:	mov    0x2d8(%r13),%rax
  77d0aa:	mov    0x18(%rax,%rsi,8),%r12d
  77d0af:	mov    $0xffffffff,%eax
  77d0b4:	cmp    %rax,%r12
  77d0b7:	je     77d0f7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x10a7>
  77d0b9:	mov    0x200(%r13),%rax
  77d0c0:	lea    -0x6b8fa3(%rip),%rdx        # c4124 <GCC_except_table0+0x1d58>
  77d0c7:	movslq (%rdx,%rax,4),%rcx
  77d0cb:	add    %rdx,%rcx
  77d0ce:	lea    -0x6b8c79(%rip),%rax        # c445c <GCC_except_table0+0x2090>
  77d0d5:	jmp    *%rcx
  77d0d7:	mov    %r13,%rcx
  77d0da:	mov    0x218(%r13),%r13
  77d0e1:	cmp    %r12,%r13
  77d0e4:	jbe    781014 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4fc4>
  77d0ea:	imul   $0x58,%r12,%rax
  77d0ee:	add    0x210(%rcx),%rax
  77d0f5:	jmp    77d162 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1112>
  77d0f7:	mov    $0x2,%al
  77d0f9:	mov    0x670(%r13),%r8
  77d100:	test   %r8,%r8
  77d103:	jne    77d1e0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1190>
  77d109:	xor    %r8d,%r8d
  77d10c:	movzbl 0x30(%rsp),%ebx
  77d111:	jmp    77d267 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1217>
  77d116:	mov    %rax,%rdx
  77d119:	cmp    $0x8,%rax
  77d11d:	jae    77ce90 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xe40>
  77d123:	jmp    77ceb9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xe69>
  77d128:	mov    %r13,%rcx
  77d12b:	mov    0x220(%r13),%r13
  77d132:	cmp    %r12,%r13
  77d135:	jbe    78100b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4fbb>
  77d13b:	mov    0x210(%rcx),%r13
  77d142:	mov    0x218(%rcx),%rax
  77d149:	movzbl (%rax,%r12,1),%r12d
  77d14e:	cmp    %r12,%r13
  77d151:	jbe    781058 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5008>
  77d157:	imul   $0x58,%r12,%rax
  77d15b:	add    0x208(%rcx),%rax
  77d162:	mov    %rcx,%r13
  77d165:	mov    0x50(%rax),%rcx
  77d169:	mov    %rcx,0x3e0(%rsp)
  77d171:	movups 0x40(%rax),%xmm0
  77d175:	movaps %xmm0,0x3d0(%rsp)
  77d17d:	movups (%rax),%xmm0
  77d180:	movups 0x10(%rax),%xmm1
  77d184:	movups 0x20(%rax),%xmm2
  77d188:	movupd 0x30(%rax),%xmm3
  77d18d:	movapd %xmm3,0x3c0(%rsp)
  77d196:	movaps %xmm2,0x3b0(%rsp)
  77d19e:	movaps %xmm1,0x3a0(%rsp)
  77d1a6:	movaps %xmm0,0x390(%rsp)
  77d1ae:	jmp    77d1c8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1178>
  77d1b0:	mov    0x208(%r13),%rsi
  77d1b7:	lea    0x390(%rsp),%rdi
  77d1bf:	mov    %r12,%rdx
  77d1c2:	call   *0x33d098(%rip)        # aba260 <_DYNAMIC+0x3f0>
  77d1c8:	movzbl 0x3e4(%rsp),%eax
  77d1d0:	mov    0x670(%r13),%r8
  77d1d7:	test   %r8,%r8
  77d1da:	je     77d109 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x10b9>
  77d1e0:	mov    0x8(%r15,%rbx,8),%rcx
  77d1e5:	mov    0x678(%r13),%rdx
  77d1ec:	movzbl 0x30(%rsp),%ebx
  77d1f1:	movzwl 0x1c2(%r8),%edi
  77d1f9:	mov    %edi,%r10d
  77d1fc:	shl    $0x5,%r10d
  77d200:	mov    $0xffffffffffffffff,%rsi
  77d207:	xor    %r9d,%r9d
  77d20a:	nopw   0x0(%rax,%rax,1)
  77d210:	mov    %r10,%r11
  77d213:	add    %r9,%r11
  77d216:	je     77d240 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x11f0>
  77d218:	cmp    0x170(%r8,%rsi,8),%rcx
  77d220:	seta   %r11b
  77d224:	sbb    $0x0,%r11b
  77d228:	add    $0xffffffffffffffe0,%r9
  77d22c:	inc    %rsi
  77d22f:	cmp    $0x1,%r11b
  77d233:	je     77d210 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x11c0>
  77d235:	movzbl %r11b,%edi
  77d239:	test   %edi,%edi
  77d23b:	jne    77d243 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x11f3>
  77d23d:	jmp    77d260 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1210>
  77d23f:	nop
  77d240:	mov    %rdi,%rsi
  77d243:	sub    $0x1,%rdx
  77d247:	jb     77d2ee <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x129e>
  77d24d:	mov    0x1c8(%r8,%rsi,8),%r8
  77d255:	jmp    77d1f1 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x11a1>
  77d257:	nopw   0x0(%rax,%rax,1)
  77d260:	sub    %r9,%r8
  77d263:	add    $0xffffffffffffffe0,%r8
  77d267:	movzbl %bl,%esi
  77d26a:	movzbl %al,%ecx
  77d26d:	lea    0x390(%rsp),%rdi
  77d275:	lea    0x970(%rsp),%rdx
  77d27d:	call   *0x33d38d(%rip)        # aba610 <_DYNAMIC+0x7a0>
  77d283:	movaps 0x310(%rsp),%xmm0
  77d28b:	movaps %xmm0,0x810(%rsp)
  77d293:	mov    0x58(%rsp),%rdi
  77d298:	lea    0x810(%rsp),%rsi
  77d2a0:	lea    0x390(%rsp),%rdx
  77d2a8:	call   *0x33d382(%rip)        # aba630 <_DYNAMIC+0x7c0>
  77d2ae:	test   $0x1,%al
  77d2b0:	jne    77d7fc <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17ac>
  77d2b6:	mov    0x58(%rsp),%rdi
  77d2bb:	lea    0x310(%rsp),%rsi
  77d2c3:	call   *0x33d2bf(%rip)        # aba588 <_DYNAMIC+0x718>
  77d2c9:	cmp    $0xff,%al
  77d2cb:	jne    77d815 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17c5>
  77d2d1:	mov    $0x0,%eax
  77d2d6:	mov    0x38(%rsp),%rdi
  77d2db:	dec    %rdi
  77d2de:	mov    0xa8(%rsp),%rbx
  77d2e6:	jne    77cd80 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xd30>
  77d2ec:	jmp    77d2f6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x12a6>
  77d2ee:	xor    %r8d,%r8d
  77d2f1:	jmp    77d267 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1217>
  77d2f6:	mov    0x40(%rsp),%r15
  77d2fb:	lea    0x2e8(%r15),%rax
  77d302:	mov    0x558(%r15),%r14
  77d309:	mov    0x578(%r15),%rbx
  77d310:	lea    0x598(%r15),%rcx
  77d317:	movq   $0xfffffffffffffffe,0x7c8(%rsp)
  77d323:	lea    0x2d0(%r15),%rdx
  77d32a:	lea    0x200(%r15),%rsi
  77d331:	lea    0x600(%r15),%r13
  77d338:	mov    %rcx,0xbe8(%rsp)
  77d340:	mov    %rdx,0xbf0(%rsp)
  77d348:	mov    %r13,0xbf8(%rsp)
  77d350:	lea    0x1c0(%rsp),%rcx
  77d358:	mov    %rcx,0xc00(%rsp)
  77d360:	mov    %rax,0xc08(%rsp)
  77d368:	mov    %rsi,0xa8(%rsp)
  77d370:	mov    %rsi,0xc10(%rsp)
  77d378:	lea    0x7c8(%rsp),%rax
  77d380:	mov    %rax,0xc18(%rsp)
  77d388:	cmpq   $0x0,0x5a8(%r15)
  77d390:	je     781080 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5030>
  77d396:	mov    0x5a0(%r15),%rax
  77d39d:	movups (%rax),%xmm0
  77d3a0:	movaps %xmm0,0x970(%rsp)
  77d3a8:	xorps  %xmm0,%xmm0
  77d3ab:	cvtsi2ssl 0xf8(%rsp),%xmm0
  77d3b4:	movaps %xmm0,0xc0(%rsp)
  77d3bc:	cvtsi2ssl 0x2e0(%rsp),%xmm1
  77d3c5:	movss  0x9c(%rsp),%xmm2
  77d3ce:	divss  %xmm2,%xmm0
  77d3d2:	movaps %xmm1,0x80(%rsp)
  77d3da:	divss  %xmm2,%xmm1
  77d3de:	movl   $0x0,0x390(%rsp)
  77d3e9:	movss  %xmm0,0x394(%rsp)
  77d3f2:	movl   $0x0,0x398(%rsp)
  77d3fd:	movss  %xmm1,0x39c(%rsp)
  77d406:	mov    $0x1,%r12b
  77d409:	lea    0x31e0e0(%rip),%r8        # a9b4f0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1ba8>
  77d410:	lea    0x970(%rsp),%rsi
  77d418:	lea    0x390(%rsp),%rdx
  77d420:	lea    0xbe8(%rsp),%rcx
  77d428:	mov    $0x1,%bpl
  77d42b:	mov    0x58(%rsp),%rdi
  77d430:	call   *0x33d202(%rip)        # aba638 <_DYNAMIC+0x7c8>
  77d436:	test   $0x1,%al
  77d438:	je     77d4a0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1450>
  77d43a:	mov    0x48(%rsp),%rax
  77d43f:	movq   $0x22,(%rax)
  77d446:	mov    %dl,0x8(%rax)
  77d449:	mov    0x7c8(%rsp),%rax
  77d451:	mov    $0x1,%r12b
  77d454:	mov    $0x1,%bpl
  77d457:	cmp    $0xfffffffffffffffe,%rax
  77d45b:	je     77d82a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17da>
  77d461:	sub    $0xd,%rax
  77d465:	mov    $0x14,%ecx
  77d46a:	cmovge %rax,%rcx
  77d46e:	cmp    $0x14,%rcx
  77d472:	je     77d8dc <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x188c>
  77d478:	cmp    $0x19,%rcx
  77d47c:	jne    77d82a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17da>
  77d482:	mov    0x7d0(%rsp),%rsi
  77d48a:	test   %rsi,%rsi
  77d48d:	je     77d82a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17da>
  77d493:	lea    0x7d8(%rsp),%rax
  77d49b:	jmp    77d8f5 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x18a5>
  77d4a0:	mov    0x558(%r15),%rax
  77d4a7:	sub    %r14,%rax
  77d4aa:	mov    0x578(%r15),%rcx
  77d4b1:	add    %rax,0x728(%r15)
  77d4b8:	sub    %rbx,%rcx
  77d4bb:	add    %rcx,0x730(%r15)
  77d4c2:	cmpl   $0xfffffffe,0x7c8(%rsp)
  77d4ca:	jne    77d7c6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1776>
  77d4d0:	lea    0x390(%rsp),%rdi
  77d4d8:	mov    $0x1,%bpl
  77d4db:	mov    %r15,%rsi
  77d4de:	mov    $0x1,%edx
  77d4e3:	call   771300 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime9inspectorINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE17refresh_inspectorB10_>
  77d4e8:	cmpl   $0xfffffffe,0x390(%rsp)
  77d4f0:	jne    77d8a3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1853>
  77d4f6:	mov    0x2e0(%r15),%rsi
  77d4fd:	lea    0x390(%rsp),%rdi
  77d505:	mov    $0x8,%ecx
  77d50a:	mov    $0x40,%r8d
  77d510:	xor    %edx,%edx
  77d512:	call   772e40 <_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCs9C2G9YFESsD_29canonical_text_public_control>
  77d517:	mov    0x398(%rsp),%rdi
  77d51f:	cmpl   $0x1,0x390(%rsp)
  77d527:	je     780eed <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4e9d>
  77d52d:	mov    0x3a0(%rsp),%rax
  77d535:	mov    %rdi,0x140(%rsp)
  77d53d:	mov    %rax,0x148(%rsp)
  77d545:	movq   $0x0,0x150(%rsp)
  77d551:	movq   $0x0,0x268(%rsp)
  77d55d:	movq   $0x4,0x270(%rsp)
  77d569:	movq   $0x0,0x278(%rsp)
  77d575:	mov    0x2e0(%r15),%rsi
  77d57c:	lea    0x390(%rsp),%rdi
  77d584:	mov    $0x8,%ecx
  77d589:	mov    $0x38,%r8d
  77d58f:	xor    %edx,%edx
  77d591:	call   772e40 <_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCs9C2G9YFESsD_29canonical_text_public_control>
  77d596:	mov    0x398(%rsp),%rdi
  77d59e:	cmpb   $0x0,0x390(%rsp)
  77d5a6:	jne    780f03 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4eb3>
  77d5ac:	mov    0x3a0(%rsp),%rax
  77d5b4:	mov    %rdi,0x1d8(%rsp)
  77d5bc:	mov    %rax,0x1e0(%rsp)
  77d5c4:	movq   $0x0,0x1e8(%rsp)
  77d5d0:	mov    0x668(%r15),%rbx
  77d5d7:	test   %rbx,%rbx
  77d5da:	setne  0x2f(%rsp)
  77d5df:	je     77d5e8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1598>
  77d5e1:	mov    0x2e0(%r15),%rbx
  77d5e8:	lea    0x390(%rsp),%rdi
  77d5f0:	mov    $0x4,%ecx
  77d5f5:	mov    $0x10,%r8d
  77d5fb:	mov    %rbx,%rsi
  77d5fe:	xor    %edx,%edx
  77d600:	call   772e40 <_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCs9C2G9YFESsD_29canonical_text_public_control>
  77d605:	mov    0x398(%rsp),%rdi
  77d60d:	cmpb   $0x0,0x390(%rsp)
  77d615:	jne    780f16 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4ec6>
  77d61b:	mov    0x3a0(%rsp),%rax
  77d623:	mov    %rdi,0x218(%rsp)
  77d62b:	mov    %rax,0x220(%rsp)
  77d633:	movq   $0x0,0x228(%rsp)
  77d63f:	lea    0x390(%rsp),%rdi
  77d647:	mov    $0x4,%ecx
  77d64c:	mov    $0x10,%r8d
  77d652:	mov    %rbx,%rsi
  77d655:	xor    %edx,%edx
  77d657:	call   772e40 <_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCs9C2G9YFESsD_29canonical_text_public_control>
  77d65c:	mov    0x398(%rsp),%rdi
  77d664:	cmpb   $0x0,0x390(%rsp)
  77d66c:	jne    780f29 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4ed9>
  77d672:	mov    0x3a0(%rsp),%rax
  77d67a:	mov    %rdi,0x230(%rsp)
  77d682:	mov    %rax,0x238(%rsp)
  77d68a:	movq   $0x0,0x240(%rsp)
  77d696:	lea    0x390(%rsp),%rdi
  77d69e:	mov    $0x1,%ecx
  77d6a3:	mov    $0x1,%r8d
  77d6a9:	mov    %rbx,%rsi
  77d6ac:	xor    %edx,%edx
  77d6ae:	call   772e40 <_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCs9C2G9YFESsD_29canonical_text_public_control>
  77d6b3:	mov    0x398(%rsp),%rdi
  77d6bb:	cmpb   $0x0,0x390(%rsp)
  77d6c3:	jne    780f3c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4eec>
  77d6c9:	mov    0x3a0(%rsp),%rax
  77d6d1:	mov    %rdi,0x158(%rsp)
  77d6d9:	mov    %rax,0x160(%rsp)
  77d6e1:	movq   $0x0,0x168(%rsp)
  77d6ed:	lea    0x390(%rsp),%rdi
  77d6f5:	mov    $0x4,%ecx
  77d6fa:	mov    $0x4,%r8d
  77d700:	mov    %rbx,%rsi
  77d703:	xor    %edx,%edx
  77d705:	call   772e40 <_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCs9C2G9YFESsD_29canonical_text_public_control>
  77d70a:	mov    0x398(%rsp),%rdi
  77d712:	cmpb   $0x0,0x390(%rsp)
  77d71a:	jne    780f4f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4eff>
  77d720:	mov    %r13,0x2d8(%rsp)
  77d728:	mov    0x3a0(%rsp),%rax
  77d730:	mov    %rdi,0x100(%rsp)
  77d738:	mov    %rax,0x108(%rsp)
  77d740:	movq   $0x0,0x110(%rsp)
  77d74c:	movq   $0x0,0x6a8(%rsp)
  77d758:	movq   $0x0,0x6b8(%rsp)
  77d764:	mov    0x650(%r15),%rcx
  77d76b:	test   %rcx,%rcx
  77d76e:	je     77d908 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x18b8>
  77d774:	mov    0x2e0(%r15),%rsi
  77d77b:	mov    0x680(%r15),%rdx
  77d782:	mov    $0x1,%r12b
  77d785:	lea    0x810(%rsp),%rdi
  77d78d:	mov    $0x1,%r13b
  77d790:	mov    $0x1,%bpl
  77d793:	call   75ce60 <_RNCNvMs1_NtNtCslbxve4rcJus_4gpui7runtime8metadataINtB9_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE14metadata_sheet0B11_>
  77d798:	jmp    77d914 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x18c4>
  77d79d:	mov    0x48(%rsp),%rax
  77d7a2:	movq   $0x23,(%rax)
  77d7a9:	mov    %r14d,0x8(%rax)
  77d7ad:	mov    %ebp,0xc(%rax)
  77d7b0:	mov    0xca0(%rsp),%rbx
  77d7b8:	cmp    $0x2,%ebx
  77d7bb:	jne    77d884 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1834>
  77d7c1:	jmp    77d891 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1841>
  77d7c6:	mov    0x7f8(%rsp),%rax
  77d7ce:	mov    0x48(%rsp),%rcx
  77d7d3:	mov    %rax,0x30(%rcx)
  77d7d7:	movups 0x7c8(%rsp),%xmm0
  77d7df:	movups 0x7d8(%rsp),%xmm1
  77d7e7:	movups 0x7e8(%rsp),%xmm2
  77d7ef:	movups %xmm2,0x20(%rcx)
  77d7f3:	movups %xmm1,0x10(%rcx)
  77d7f7:	movups %xmm0,(%rcx)
  77d7fa:	jmp    77d824 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17d4>
  77d7fc:	mov    0x48(%rsp),%rax
  77d801:	movq   $0x22,(%rax)
  77d808:	mov    %dl,0x8(%rax)
  77d80b:	jmp    77d824 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17d4>
  77d80d:	movzbl 0x811(%rsp),%eax
  77d815:	mov    0x48(%rsp),%rcx
  77d81a:	movq   $0x22,(%rcx)
  77d821:	mov    %al,0x8(%rcx)
  77d824:	mov    $0x1,%r12b
  77d827:	mov    $0x1,%bpl
  77d82a:	cmpq   $0x0,0x1c0(%rsp)
  77d833:	je     77d842 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17f2>
  77d835:	mov    0x1c8(%rsp),%rdi
  77d83d:	call   74cd40 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text10TextShaperECs9C2G9YFESsD_29canonical_text_public_control>
  77d842:	test   %r12b,%r12b
  77d845:	je     77d854 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1804>
  77d847:	lea    0x200(%rsp),%rdi
  77d84f:	call   747910 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime13text_geometry5EntryEECs9C2G9YFESsD_29canonical_text_public_control>
  77d854:	mov    0xd0(%rsp),%rax
  77d85c:	test   %rax,%rax
  77d85f:	je     77d875 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1825>
  77d861:	lock decq (%rax)
  77d865:	jne    77d875 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1825>
  77d867:	lea    0xd0(%rsp),%rdi
  77d86f:	call   *0x33c92b(%rip)        # aba1a0 <_DYNAMIC+0x330>
  77d875:	cmpl   $0x2,0xca0(%rsp)
  77d87d:	je     77d891 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1841>
  77d87f:	test   %bpl,%bpl
  77d882:	je     77d891 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1841>
  77d884:	lea    0xca0(%rsp),%rdi
  77d88c:	call   74d2e0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas6canvas6CanvasECs9C2G9YFESsD_29canonical_text_public_control>
  77d891:	add    $0xe88,%rsp
  77d898:	pop    %rbx
  77d899:	pop    %r12
  77d89b:	pop    %r13
  77d89d:	pop    %r14
  77d89f:	pop    %r15
  77d8a1:	pop    %rbp
  77d8a2:	ret
  77d8a3:	mov    0x3c0(%rsp),%rax
  77d8ab:	mov    0x48(%rsp),%rcx
  77d8b0:	mov    %rax,0x30(%rcx)
  77d8b4:	movups 0x390(%rsp),%xmm0
  77d8bc:	movups 0x3a0(%rsp),%xmm1
  77d8c4:	movups 0x3b0(%rsp),%xmm2
  77d8cc:	movups %xmm2,0x20(%rcx)
  77d8d0:	movups %xmm1,0x10(%rcx)
  77d8d4:	movups %xmm0,(%rcx)
  77d8d7:	jmp    77d449 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x13f9>
  77d8dc:	mov    0x7e0(%rsp),%rsi
  77d8e4:	test   %rsi,%rsi
  77d8e7:	je     77d82a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17da>
  77d8ed:	lea    0x7e8(%rsp),%rax
  77d8f5:	mov    (%rax),%rdi
  77d8f8:	mov    $0x1,%edx
  77d8fd:	call   *0x33c7ad(%rip)        # aba0b0 <_DYNAMIC+0x240>
  77d903:	jmp    77d82a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17da>
  77d908:	movq   $0xffffffffffffffff,0x810(%rsp)
  77d914:	mov    0x2d8(%rsp),%rax
  77d91c:	mov    (%rax),%rsi
  77d91f:	test   %rsi,%rsi
  77d922:	je     77d9f0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x19a0>
  77d928:	mov    $0x1,%r12b
  77d92b:	lea    0x390(%rsp),%rdi
  77d933:	mov    $0x1,%bl
  77d935:	mov    $0x1,%r15b
  77d938:	mov    $0x1,%bpl
  77d93b:	call   *0x33ccff(%rip)        # aba640 <_DYNAMIC+0x7d0>
  77d941:	mov    0xf8(%rsp),%r13
  77d949:	mov    0x390(%rsp),%rax
  77d951:	mov    0x398(%rsp),%rsi
  77d959:	movups 0x3a0(%rsp),%xmm0
  77d961:	movaps %xmm0,0x310(%rsp)
  77d969:	movups 0x3b0(%rsp),%xmm1
  77d971:	movaps %xmm1,0x970(%rsp)
  77d979:	mov    0x3c0(%rsp),%rcx
  77d981:	mov    %rcx,0x980(%rsp)
  77d989:	movaps %xmm0,0x790(%rsp)
  77d991:	cmp    $0xfffffffffffffffe,%rax
  77d995:	mov    0x40(%rsp),%r12
  77d99a:	je     77da04 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x19b4>
  77d99c:	mov    0x980(%rsp),%rcx
  77d9a4:	mov    0x48(%rsp),%rdx
  77d9a9:	mov    %rcx,0x30(%rdx)
  77d9ad:	movaps 0x970(%rsp),%xmm0
  77d9b5:	movups %xmm0,0x20(%rdx)
  77d9b9:	movaps 0x790(%rsp),%xmm0
  77d9c1:	movaps %xmm0,0x180(%rsp)
  77d9c9:	movups %xmm0,0x10(%rdx)
  77d9cd:	mov    %rax,(%rdx)
  77d9d0:	mov    %rsi,0x8(%rdx)
  77d9d4:	mov    $0x1,%r12b
  77d9d7:	cmpl   $0xffffffff,0x810(%rsp)
  77d9df:	mov    $0x1,%r13b
  77d9e2:	mov    $0x1,%bpl
  77d9e5:	jne    780d04 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4cb4>
  77d9eb:	jmp    780d11 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4cc1>
  77d9f0:	mov    $0xffffffffffffffff,%rsi
  77d9f7:	mov    0x40(%rsp),%r12
  77d9fc:	mov    0xf8(%rsp),%r13
  77da04:	movaps 0x790(%rsp),%xmm0
  77da0c:	movups %xmm0,0x8c0(%rsp)
  77da14:	mov    %rsi,0x258(%rsp)
  77da1c:	mov    %rsi,0x8b8(%rsp)
  77da24:	cmpb   $0x0,0x2f(%rsp)
  77da29:	je     77dac3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1a73>
  77da2f:	lea    0x390(%rsp),%rdi
  77da37:	lea    0x1d8(%rsp),%rdx
  77da3f:	lea    0x100(%rsp),%rcx
  77da47:	mov    %r12,%rsi
  77da4a:	call   74fdd0 <_RINvNtNtCslbxve4rcJus_4gpui7runtime6scroll8geometryNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEBP_>
  77da4f:	mov    0x390(%rsp),%rax
  77da57:	movups 0x398(%rsp),%xmm0
  77da5f:	movaps %xmm0,0x970(%rsp)
  77da67:	movups 0x3a8(%rsp),%xmm0
  77da6f:	movaps %xmm0,0x980(%rsp)
  77da77:	movups 0x3b8(%rsp),%xmm0
  77da7f:	movaps %xmm0,0x990(%rsp)
  77da87:	cmp    $0xfffffffffffffffe,%rax
  77da8b:	jne    77fd9e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3d4e>
  77da91:	movaps 0x970(%rsp),%xmm0
  77da99:	movaps 0x980(%rsp),%xmm1
  77daa1:	movaps 0x990(%rsp),%xmm2
  77daa9:	movaps %xmm2,0x6e0(%rsp)
  77dab1:	movaps %xmm1,0x6d0(%rsp)
  77dab9:	movaps %xmm0,0x6c0(%rsp)
  77dac1:	jmp    77dafe <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1aae>
  77dac3:	movq   $0x0,0x6c0(%rsp)
  77dacf:	movq   $0x8,0x6c8(%rsp)
  77dadb:	xorps  %xmm0,%xmm0
  77dade:	movups %xmm0,0x6d0(%rsp)
  77dae6:	movq   $0x8,0x6e0(%rsp)
  77daf2:	movq   $0x0,0x6e8(%rsp)
  77dafe:	mov    0x6a8(%r12),%r15
  77db06:	mov    0x6b0(%r12),%r14
  77db0e:	mov    0x6c0(%r12),%rbx
  77db16:	lea    0xc78(%rsp),%rdi
  77db1e:	mov    %r12,%rsi
  77db21:	call   771140 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime9inspectorINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE17inspector_displayB10_>
  77db26:	lea    0x650(%r12),%rax
  77db2e:	mov    %rax,0xf0(%rsp)
  77db36:	mov    (%rax),%rax
  77db39:	test   %rax,%rax
  77db3c:	je     77db5a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1b0a>
  77db3e:	mov    0x100(%rax),%rsi
  77db45:	test   %rsi,%rsi
  77db48:	je     77db5a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1b0a>
  77db4a:	lea    0xb98(%rsp),%rdi
  77db52:	call   *0x33c5c0(%rip)        # aba118 <_DYNAMIC+0x2a8>
  77db58:	jmp    77db71 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1b21>
  77db5a:	movq   $0x4,0xb98(%rsp)
  77db66:	xorps  %xmm0,%xmm0
  77db69:	movups %xmm0,0xba0(%rsp)
  77db71:	mov    0x6b8(%r12),%rax
  77db79:	test   %rax,%rax
  77db7c:	je     77dbb0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1b60>
  77db7e:	mov    %r14,0x18(%rax)
  77db82:	mov    %r15,0x20(%rax)
  77db86:	mov    %rbx,0x28(%rax)
  77db8a:	movq   $0x0,0x10(%rax)
  77db92:	movw   $0x100,0x58(%rax)
  77db98:	test   %r14,%r14
  77db9b:	setne  %dl
  77db9e:	cmp    %r13,%rbx
  77dba1:	sete   %cl
  77dba4:	and    %dl,%cl
  77dba6:	mov    %rax,0x688(%rsp)
  77dbae:	jmp    77dbb2 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1b62>
  77dbb0:	mov    $0x2,%cl
  77dbb2:	mov    %cl,0x690(%rsp)
  77dbb9:	mov    0xa8(%rsp),%rdi
  77dbc1:	call   *0x33ca81(%rip)        # aba648 <_DYNAMIC+0x7d8>
  77dbc7:	movzbl 0xc78(%rsp),%eax
  77dbcf:	movq   $0xffffffffffffffff,0x670(%rsp)
  77dbdb:	mov    %al,0x7f(%rsp)
  77dbdf:	test   %al,%al
  77dbe1:	je     77dbf3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1ba3>
  77dbe3:	mov    0xc80(%rsp),%rax
  77dbeb:	mov    %rax,0x670(%rsp)
  77dbf3:	cmpl   $0x2,0xca0(%rsp)
  77dbfb:	lea    0xca0(%rsp),%rsi
  77dc03:	cmove  %r12,%rsi
  77dc07:	lea    0x970(%rsp),%rdi
  77dc0f:	call   *0x33ca3b(%rip)        # aba650 <_DYNAMIC+0x7e0>
  77dc15:	movups -0x6bb51c(%rip),%xmm0        # c2700 <GCC_except_table0+0x334>
  77dc1c:	movaps %xmm0,0x390(%rsp)
  77dc24:	lea    0x970(%rsp),%rdi
  77dc2c:	lea    0x390(%rsp),%rsi
  77dc34:	call   *0x33ca1e(%rip)        # aba658 <_DYNAMIC+0x7e8>
  77dc3a:	incq   0x740(%r12)
  77dc42:	mov    0x2e0(%r12),%rax
  77dc4a:	mov    %rax,0x660(%rsp)
  77dc52:	test   %rax,%rax
  77dc55:	je     77fc7b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3c2b>
  77dc5b:	movss  0x9c(%rsp),%xmm0
  77dc64:	cvtss2sd %xmm0,%xmm0
  77dc68:	movsd  %xmm0,0x890(%rsp)
  77dc71:	movaps 0xc0(%rsp),%xmm0
  77dc79:	unpcklps 0x80(%rsp),%xmm0
  77dc81:	movaps %xmm0,0x800(%rsp)
  77dc89:	lea    0x31d8a0(%rip),%rax        # a9b530 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1be8>
  77dc90:	mov    %rax,0x658(%rsp)
  77dc98:	movabs $0x8000000000000000,%rax
  77dca2:	inc    %rax
  77dca5:	mov    %rax,0x888(%rsp)
  77dcad:	lea    0x31d894(%rip),%rax        # a9b548 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1c00>
  77dcb4:	mov    %rax,0xa0(%rsp)
  77dcbc:	lea    0x180(%rsp),%r15
  77dcc4:	lea    0x31c575(%rip),%rax        # a9a240 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x8f8>
  77dccb:	mov    %rax,0x650(%rsp)
  77dcd3:	lea    0x31c686(%rip),%rax        # a9a360 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xa18>
  77dcda:	mov    %rax,0x648(%rsp)
  77dce2:	lea    0x31d8ef(%rip),%rax        # a9b5d8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1c90>
  77dce9:	mov    %rax,0x248(%rsp)
  77dcf1:	lea    -0x6ab351(%rip),%rax        # d29a7 <GCC_except_table0+0x105db>
  77dcf8:	mov    %rax,0x250(%rsp)
  77dd00:	xor    %ecx,%ecx
  77dd02:	lea    0x0(,%rcx,8),%rax
  77dd0a:	lea    (%rax,%rax,4),%r13
  77dd0e:	imul   $0x58,%rcx,%rax
  77dd12:	mov    %rax,0x668(%rsp)
  77dd1a:	mov    %rcx,%rsi
  77dd1d:	shl    $0x4,%rsi
  77dd21:	mov    %rcx,%rdx
  77dd24:	jmp    77dd55 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1d05>
  77dd26:	add    $0x28,%r13
  77dd2a:	addq   $0x58,0x668(%rsp)
  77dd33:	mov    0x8a8(%rsp),%rsi
  77dd3b:	add    $0x10,%rsi
  77dd3f:	mov    0x8a0(%rsp),%rdx
  77dd47:	cmp    0x660(%rsp),%rdx
  77dd4f:	jae    77fc7b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3c2b>
  77dd55:	cmp    %rdx,0x670(%rsp)
  77dd5d:	mov    %rdx,0x38(%rsp)
  77dd62:	jne    77dde8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1d98>
  77dd68:	cmpb   $0x0,0x7f(%rsp)
  77dd6d:	je     780ea8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4e58>
  77dd73:	mov    %rsi,%rbx
  77dd76:	mov    0x148(%rsp),%rdx
  77dd7e:	mov    0x150(%rsp),%rcx
  77dd86:	mov    0x270(%rsp),%r8
  77dd8e:	mov    0x278(%rsp),%r9
  77dd96:	mov    0x40(%rsp),%rax
  77dd9b:	movups 0x2f0(%rax),%xmm0
  77dda2:	movups 0x5a0(%rax),%xmm1
  77dda9:	movups %xmm1,0x18(%rsp)
  77ddae:	mov    0x58(%rsp),%rax
  77ddb3:	mov    %rax,0x10(%rsp)
  77ddb8:	movups %xmm0,(%rsp)
  77ddbc:	lea    0x390(%rsp),%rdi
  77ddc4:	lea    0xc80(%rsp),%rsi
  77ddcc:	call   *0x33c88e(%rip)        # aba660 <_DYNAMIC+0x7f0>
  77ddd2:	cmpl   $0xfffffffe,0x390(%rsp)
  77ddda:	jne    780ad0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4a80>
  77dde0:	mov    0x38(%rsp),%rdx
  77dde5:	mov    %rbx,%rsi
  77dde8:	mov    0x40(%rsp),%rcx
  77dded:	mov    0x5a8(%rcx),%rax
  77ddf4:	cmp    %rax,%rdx
  77ddf7:	jae    7811a0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5150>
  77ddfd:	mov    0x5a0(%rcx),%rax
  77de04:	mov    %rsi,0x8a8(%rsp)
  77de0c:	movups (%rax,%rsi,1),%xmm0
  77de10:	movaps %xmm0,0x310(%rsp)
  77de18:	lea    0x390(%rsp),%rdi
  77de20:	mov    0x58(%rsp),%rsi
  77de25:	lea    0x310(%rsp),%rdx
  77de2d:	call   *0x33c41d(%rip)        # aba250 <_DYNAMIC+0x3e0>
  77de33:	cmpb   $0x0,0x390(%rsp)
  77de3b:	jne    780a1e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x49ce>
  77de41:	mov    0x38(%rsp),%rdx
  77de46:	lea    0x1(%rdx),%rcx
  77de4a:	mov    0x40(%rsp),%rax
  77de4f:	mov    0x2e0(%rax),%rsi
  77de56:	mov    %rcx,0x8a0(%rsp)
  77de5e:	cmp    %rsi,%rcx
  77de61:	jae    77de8b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1e3b>
  77de63:	mov    0x2d8(%rax),%rax
  77de6a:	mov    0x40(%rax,%r13,1),%eax
  77de6f:	mov    $0xffffffff,%ecx
  77de74:	cmp    %rcx,%rax
  77de77:	setne  %cl
  77de7a:	cmp    %rax,%rdx
  77de7d:	sete   %al
  77de80:	and    %cl,%al
  77de82:	mov    %eax,0x1d4(%rsp)
  77de89:	jmp    77de96 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1e46>
  77de8b:	movl   $0x0,0x1d4(%rsp)
  77de96:	movsd  0x3d4(%rsp),%xmm0
  77de9f:	movaps %xmm0,0x940(%rsp)
  77dea7:	movsd  0x3dc(%rsp),%xmm0
  77deb0:	movaps %xmm0,0x630(%rsp)
  77deb8:	movups 0x3a4(%rsp),%xmm0
  77dec0:	movaps %xmm0,0x930(%rsp)
  77dec8:	movss  0x3a8(%rsp),%xmm0
  77ded1:	movss  %xmm0,0x30c(%rsp)
  77deda:	movups 0x3b4(%rsp),%xmm0
  77dee2:	movaps %xmm0,0x2c0(%rsp)
  77deea:	movss  0x3bc(%rsp),%xmm0
  77def3:	movaps %xmm0,0x910(%rsp)
  77defb:	movss  0x3b8(%rsp),%xmm0
  77df04:	movss  %xmm0,0x308(%rsp)
  77df0d:	movsd  0x3e4(%rsp),%xmm0
  77df16:	movaps %xmm0,0x920(%rsp)
  77df1e:	mov    0xa8(%rsp),%rax
  77df26:	mov    (%rax),%rax
  77df29:	lea    -0x6b9ddc(%rip),%rcx        # c4154 <GCC_except_table0+0x1d88>
  77df30:	movslq (%rcx,%rax,4),%rax
  77df34:	add    %rcx,%rax
  77df37:	jmp    *%rax
  77df39:	movups -0x6b9aa4(%rip),%xmm0        # c449c <GCC_except_table0+0x20d0>
  77df40:	movaps %xmm0,0x350(%rsp)
  77df48:	movups -0x6b9ac3(%rip),%xmm0        # c448c <GCC_except_table0+0x20c0>
  77df4f:	movaps %xmm0,0x340(%rsp)
  77df57:	movups -0x6b9ae2(%rip),%xmm0        # c447c <GCC_except_table0+0x20b0>
  77df5e:	movaps %xmm0,0x330(%rsp)
  77df66:	movups -0x6b9b01(%rip),%xmm0        # c446c <GCC_except_table0+0x20a0>
  77df6d:	movaps %xmm0,0x320(%rsp)
  77df75:	movups -0x6b9b20(%rip),%xmm0        # c445c <GCC_except_table0+0x2090>
  77df7c:	movaps %xmm0,0x310(%rsp)
  77df84:	movabs $0x3000100000000,%rax
  77df8e:	mov    %rax,0x360(%rsp)
  77df96:	jmp    77e0b0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2060>
  77df9b:	mov    0x40(%rsp),%rdx
  77dfa0:	mov    0x220(%rdx),%rax
  77dfa7:	mov    0x38(%rsp),%rdi
  77dfac:	cmp    %rax,%rdi
  77dfaf:	jae    78116c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x511c>
  77dfb5:	mov    0x210(%rdx),%rax
  77dfbc:	mov    0x218(%rdx),%rcx
  77dfc3:	movzbl (%rcx,%rdi,1),%ecx
  77dfc7:	cmp    %rcx,%rax
  77dfca:	jbe    781175 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5125>
  77dfd0:	mov    0x208(%rdx),%rax
  77dfd7:	imul   $0x58,%rcx,%rcx
  77dfdb:	mov    0x50(%rax,%rcx,1),%rdx
  77dfe0:	mov    %rdx,0x360(%rsp)
  77dfe8:	movups 0x40(%rax,%rcx,1),%xmm0
  77dfed:	movaps %xmm0,0x350(%rsp)
  77dff5:	movups (%rax,%rcx,1),%xmm0
  77dff9:	movups 0x10(%rax,%rcx,1),%xmm1
  77dffe:	movups 0x20(%rax,%rcx,1),%xmm2
  77e003:	movupd 0x30(%rax,%rcx,1),%xmm3
  77e009:	jmp    77e08f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x203f>
  77e00e:	mov    0x40(%rsp),%rax
  77e013:	mov    0x208(%rax),%rsi
  77e01a:	lea    0x310(%rsp),%rdi
  77e022:	mov    0x38(%rsp),%rdx
  77e027:	call   *0x33c233(%rip)        # aba260 <_DYNAMIC+0x3f0>
  77e02d:	mov    0x40(%rsp),%rax
  77e032:	mov    0x2e0(%rax),%rsi
  77e039:	jmp    77e0b0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2060>
  77e03b:	mov    0x40(%rsp),%rcx
  77e040:	mov    0x218(%rcx),%rax
  77e047:	cmp    %rax,0x38(%rsp)
  77e04c:	jae    781183 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5133>
  77e052:	mov    0x210(%rcx),%rax
  77e059:	mov    0x668(%rsp),%rdx
  77e061:	mov    0x50(%rax,%rdx,1),%rcx
  77e066:	mov    %rcx,0x360(%rsp)
  77e06e:	movups 0x40(%rax,%rdx,1),%xmm0
  77e073:	movaps %xmm0,0x350(%rsp)
  77e07b:	movups (%rax,%rdx,1),%xmm0
  77e07f:	movups 0x10(%rax,%rdx,1),%xmm1
  77e084:	movups 0x20(%rax,%rdx,1),%xmm2
  77e089:	movupd 0x30(%rax,%rdx,1),%xmm3
  77e08f:	movapd %xmm3,0x340(%rsp)
  77e098:	movaps %xmm2,0x330(%rsp)
  77e0a0:	movaps %xmm1,0x320(%rsp)
  77e0a8:	movaps %xmm0,0x310(%rsp)
  77e0b0:	cmp    %rsi,0x38(%rsp)
  77e0b5:	jae    7810dd <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x508d>
  77e0bb:	mov    0x40(%rsp),%rax
  77e0c0:	mov    0x2d8(%rax),%rdi
  77e0c7:	mov    0x18(%rdi,%r13,1),%edx
  77e0cc:	mov    $0xffffffff,%eax
  77e0d1:	cmp    %rax,%rdx
  77e0d4:	je     77e0f0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x20a0>
  77e0d6:	call   75e340 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_>
  77e0db:	mov    %eax,0xbc(%rsp)
  77e0e2:	mov    0x40(%rsp),%rax
  77e0e7:	mov    0x2e0(%rax),%rsi
  77e0ee:	jmp    77e0fb <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x20ab>
  77e0f0:	movl   $0x0,0xbc(%rsp)
  77e0fb:	cmp    %rsi,0x38(%rsp)
  77e100:	jae    7810ec <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x509c>
  77e106:	mov    0x40(%rsp),%rax
  77e10b:	mov    0x2d8(%rax),%rax
  77e112:	mov    0x18(%rax,%r13,1),%ebx
  77e117:	mov    $0xffffffff,%ecx
  77e11c:	cmp    %rcx,%rbx
  77e11f:	je     77e13a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x20ea>
  77e121:	cmp    %rbx,%rsi
  77e124:	jbe    78110a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x50ba>
  77e12a:	lea    (%rbx,%rbx,4),%rcx
  77e12e:	mov    (%rax,%rcx,8),%rcx
  77e132:	mov    %rcx,0x898(%rsp)
  77e13a:	mov    0xf0(%rsp),%rcx
  77e142:	mov    (%rcx),%rcx
  77e145:	xorps  %xmm0,%xmm0
  77e148:	movss  %xmm0,0x74(%rsp)
  77e14e:	test   %rcx,%rcx
  77e151:	je     77e17b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x212b>
  77e153:	mov    0x100(%rcx),%rdi
  77e15a:	test   %rdi,%rdi
  77e15d:	je     77e17b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x212b>
  77e15f:	mov    (%rax,%r13,1),%rsi
  77e163:	call   *0x33c457(%rip)        # aba5c0 <_DYNAMIC+0x750>
  77e169:	movss  %xmm0,0x74(%rsp)
  77e16f:	mov    0x40(%rsp),%rax
  77e174:	mov    0x2e0(%rax),%rsi
  77e17b:	cmp    %rsi,0x38(%rsp)
  77e180:	jae    7810fb <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x50ab>
  77e186:	mov    0x40(%rsp),%rax
  77e18b:	mov    0x2d8(%rax),%rax
  77e192:	mov    %rax,0x30(%rsp)
  77e197:	mov    0x18(%rax,%r13,1),%ecx
  77e19c:	mov    $0xffffffff,%eax
  77e1a1:	cmp    %rax,%rcx
  77e1a4:	je     77e2c0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2270>
  77e1aa:	mov    0x1e8(%rsp),%rax
  77e1b2:	cmp    %rcx,%rax
  77e1b5:	jbe    78111b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x50cb>
  77e1bb:	imul   $0x38,%rcx,%rax
  77e1bf:	mov    0x1e0(%rsp),%rcx
  77e1c7:	movups (%rcx,%rax,1),%xmm0
  77e1cb:	movaps %xmm0,0x60(%rsp)
  77e1d0:	movups 0x10(%rcx,%rax,1),%xmm0
  77e1d5:	movaps %xmm0,0xe0(%rsp)
  77e1dd:	movups 0x20(%rcx,%rax,1),%xmm0
  77e1e2:	movaps %xmm0,0x280(%rsp)
  77e1ea:	movzbl 0x30(%rcx,%rax,1),%ebp
  77e1ef:	mov    0x31(%rcx,%rax,1),%edx
  77e1f3:	mov    %edx,0x180(%rsp)
  77e1fa:	mov    0x34(%rcx,%rax,1),%eax
  77e1fe:	mov    %eax,0x183(%rsp)
  77e205:	cmp    $0xffffffff,%ebx
  77e208:	je     780e99 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4e49>
  77e20e:	lea    0x390(%rsp),%rdi
  77e216:	lea    0x6c0(%rsp),%rsi
  77e21e:	mov    0x898(%rsp),%rdx
  77e226:	call   *0x33c43c(%rip)        # aba668 <_DYNAMIC+0x7f8>
  77e22c:	cmpl   $0x1,0x390(%rsp)
  77e234:	jne    77e2f4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x22a4>
  77e23a:	movq   0x398(%rsp),%xmm0
  77e243:	movq   0x3a0(%rsp),%xmm1
  77e24c:	movq   %xmm0,%rax
  77e251:	movq   %xmm1,%rcx
  77e256:	movabs $0x7fffffffffffffff,%rdx
  77e260:	and    %rdx,%rax
  77e263:	movabs $0x7fefffffffffffff,%rsi
  77e26d:	cmp    %rsi,%rax
  77e270:	setg   %al
  77e273:	and    %rdx,%rcx
  77e276:	cmp    %rsi,%rcx
  77e279:	setg   %cl
  77e27c:	or     %al,%cl
  77e27e:	or     %bpl,%cl
  77e281:	and    $0x1,%cl
  77e284:	punpcklqdq %xmm1,%xmm1
  77e288:	pxor   -0x6baa20(%rip),%xmm1        # c3870 <GCC_except_table0+0x14a4>
  77e290:	movapd 0xe0(%rsp),%xmm3
  77e299:	mulpd  %xmm3,%xmm1
  77e29d:	punpcklqdq %xmm0,%xmm0
  77e2a1:	movapd 0x60(%rsp),%xmm2
  77e2a7:	mulpd  %xmm2,%xmm0
  77e2ab:	subpd  %xmm0,%xmm1
  77e2af:	movapd 0x280(%rsp),%xmm0
  77e2b8:	addpd  %xmm1,%xmm0
  77e2bc:	mov    %ecx,%ebp
  77e2be:	jmp    77e327 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x22d7>
  77e2c0:	movsd  0x890(%rsp),%xmm0
  77e2c9:	movsd  %xmm0,0x790(%rsp)
  77e2d2:	lea    0x7c1(%rsp),%rax
  77e2da:	xorps  %xmm1,%xmm1
  77e2dd:	movups %xmm1,-0x29(%rax)
  77e2e1:	movsd  %xmm0,0x7a8(%rsp)
  77e2ea:	movaps %xmm1,-0x11(%rax)
  77e2ee:	movb   $0x0,-0x1(%rax)
  77e2f2:	jmp    77e34a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x22fa>
  77e2f4:	mov    0x180(%rsp),%eax
  77e2fb:	mov    0x183(%rsp),%ecx
  77e302:	lea    0x7c1(%rsp),%rdx
  77e30a:	mov    %ecx,0x3(%rdx)
  77e30d:	mov    %eax,(%rdx)
  77e30f:	movapd 0x60(%rsp),%xmm2
  77e315:	movapd 0xe0(%rsp),%xmm3
  77e31e:	movapd 0x280(%rsp),%xmm0
  77e327:	movapd %xmm2,0x790(%rsp)
  77e330:	movapd %xmm3,0x7a0(%rsp)
  77e339:	movapd %xmm0,0x7b0(%rsp)
  77e342:	mov    %bpl,0x7c0(%rsp)
  77e34a:	movaps -0x6ba7d1(%rip),%xmm0        # c3b80 <GCC_except_table0+0x17b4>
  77e351:	movaps %xmm0,0x180(%rsp)
  77e359:	movaps 0x940(%rsp),%xmm0
  77e361:	movlps %xmm0,0x190(%rsp)
  77e369:	lea    0x390(%rsp),%rdi
  77e371:	lea    0x790(%rsp),%rsi
  77e379:	mov    %r15,%rdx
  77e37c:	call   *0x33bed6(%rip)        # aba258 <_DYNAMIC+0x3e8>
  77e382:	lea    0xbb0(%rsp),%rdi
  77e38a:	lea    0x390(%rsp),%rsi
  77e392:	lea    0x34c(%rsp),%rdx
  77e39a:	call   *0x33beb8(%rip)        # aba258 <_DYNAMIC+0x3e8>
  77e3a0:	mov    0x1e8(%rsp),%rbx
  77e3a8:	cmp    0x1d8(%rsp),%rbx
  77e3b0:	jne    77e3bf <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x236f>
  77e3b2:	lea    0x1d8(%rsp),%rdi
  77e3ba:	call   772930 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtCscO85OU7Wpt0_20gpui_reactivity_core8geometry15CoordinateSpaceE8grow_oneCs9C2G9YFESsD_29canonical_text_public_control>
  77e3bf:	mov    0x1e0(%rsp),%rax
  77e3c7:	imul   $0x38,%rbx,%rcx
  77e3cb:	mov    0xbe0(%rsp),%rdx
  77e3d3:	mov    %rdx,0x30(%rax,%rcx,1)
  77e3d8:	movups 0xbb0(%rsp),%xmm0
  77e3e0:	movups 0xbc0(%rsp),%xmm1
  77e3e8:	movups 0xbd0(%rsp),%xmm2
  77e3f0:	movups %xmm2,0x20(%rax,%rcx,1)
  77e3f5:	movups %xmm1,0x10(%rax,%rcx,1)
  77e3fa:	movups %xmm0,(%rax,%rcx,1)
  77e3fe:	inc    %rbx
  77e401:	mov    %rbx,0x1e8(%rsp)
  77e409:	movups 0xbb0(%rsp),%xmm0
  77e411:	movaps %xmm0,0xe0(%rsp)
  77e419:	movups 0xbc0(%rsp),%xmm0
  77e421:	movaps %xmm0,0x280(%rsp)
  77e429:	movups 0xbd0(%rsp),%xmm0
  77e431:	movaps %xmm0,0x60(%rsp)
  77e436:	lea    0xbb0(%rsp),%rdi
  77e43e:	call   *0x33c22c(%rip)        # aba670 <_DYNAMIC+0x800>
  77e444:	xor    %ebx,%ebx
  77e446:	test   %al,%al
  77e448:	je     77e573 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2523>
  77e44e:	cvtpd2ps 0x280(%rsp),%xmm0
  77e457:	cvtpd2ps 0xe0(%rsp),%xmm1
  77e460:	cvtpd2ps 0x60(%rsp),%xmm2
  77e466:	unpcklpd %xmm0,%xmm1
  77e46a:	movd   %xmm1,%eax
  77e46e:	and    $0x7fffffff,%eax
  77e473:	movapd %xmm1,%xmm0
  77e477:	shufps $0x55,%xmm1,%xmm0
  77e47b:	movd   %xmm0,%ecx
  77e47f:	and    $0x7fffffff,%ecx
  77e485:	cmp    $0x7f800000,%ecx
  77e48b:	setge  %cl
  77e48e:	movdqa %xmm1,%xmm0
  77e492:	punpckhqdq %xmm1,%xmm0
  77e496:	movd   %xmm0,%edx
  77e49a:	and    $0x7fffffff,%edx
  77e4a0:	cmp    $0x7f800000,%edx
  77e4a6:	setge  %dl
  77e4a9:	movaps %xmm1,%xmm0
  77e4ac:	shufps $0xff,%xmm1,%xmm0
  77e4b0:	movd   %xmm0,%esi
  77e4b4:	and    $0x7fffffff,%esi
  77e4ba:	cmp    $0x7f800000,%esi
  77e4c0:	setge  %sil
  77e4c4:	movd   %xmm2,%edi
  77e4c8:	and    $0x7fffffff,%edi
  77e4ce:	cmp    $0x7f800000,%edi
  77e4d4:	setge  %dil
  77e4d8:	movapd %xmm2,%xmm0
  77e4dc:	shufps $0x55,%xmm2,%xmm0
  77e4e0:	movd   %xmm0,%r8d
  77e4e5:	and    $0x7fffffff,%r8d
  77e4ec:	cmp    $0x7f800000,%r8d
  77e4f3:	setl   %r8b
  77e4f7:	cmp    $0x7f7fffff,%eax
  77e4fc:	mov    0x30(%rsp),%r9
  77e501:	jg     77e578 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2528>
  77e503:	test   %cl,%cl
  77e505:	jne    77e578 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2528>
  77e507:	test   %dl,%dl
  77e509:	jne    77e578 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2528>
  77e50b:	test   %sil,%sil
  77e50e:	jne    77e578 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2528>
  77e510:	test   %dil,%dil
  77e513:	jne    77e578 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2528>
  77e515:	test   %r8b,%r8b
  77e518:	je     77e578 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2528>
  77e51a:	movaps %xmm1,0x60(%rsp)
  77e51f:	movaps %xmm1,0x390(%rsp)
  77e527:	movaps %xmm2,0xe0(%rsp)
  77e52f:	movlpd %xmm2,0x3a0(%rsp)
  77e538:	lea    0x390(%rsp),%rdi
  77e540:	call   *0x33c132(%rip)        # aba678 <_DYNAMIC+0x808>
  77e546:	test   %al,%al
  77e548:	mov    0x30(%rsp),%r9
  77e54d:	je     77e578 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2528>
  77e54f:	movaps 0x60(%rsp),%xmm0
  77e554:	movups %xmm0,0x2a8(%rsp)
  77e55c:	movaps 0xe0(%rsp),%xmm0
  77e564:	movlps %xmm0,0x2b8(%rsp)
  77e56c:	mov    $0x1,%ebx
  77e571:	jmp    77e578 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2528>
  77e573:	mov    0x30(%rsp),%r9
  77e578:	mov    %ebx,0x2a4(%rsp)
  77e57f:	xorps  %xmm0,%xmm0
  77e582:	unpcklpd 0x630(%rsp),%xmm0
  77e58b:	movups %xmm0,0x698(%rsp)
  77e593:	cmpb   $0x0,0x2f(%rsp)
  77e598:	je     77e638 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x25e8>
  77e59e:	mov    0x18(%r9,%r13,1),%edx
  77e5a3:	mov    $0xffffffff,%eax
  77e5a8:	cmp    %rax,%rdx
  77e5ab:	je     77e67e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x262e>
  77e5b1:	mov    0x228(%rsp),%rax
  77e5b9:	cmp    %rdx,%rax
  77e5bc:	jbe    781129 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x50d9>
  77e5c2:	mov    0x220(%rsp),%rax
  77e5ca:	mov    %rdx,%rcx
  77e5cd:	shl    $0x4,%rcx
  77e5d1:	movsd  (%rax,%rcx,1),%xmm1
  77e5d6:	movsd  0x8(%rax,%rcx,1),%xmm2
  77e5dc:	movq   $0x0,0x390(%rsp)
  77e5e8:	movaps 0xc0(%rsp),%xmm0
  77e5f0:	movss  %xmm0,0x398(%rsp)
  77e5f9:	movaps 0x80(%rsp),%xmm0
  77e601:	movss  %xmm0,0x39c(%rsp)
  77e60a:	mov    0x240(%rsp),%rax
  77e612:	cmp    %rdx,%rax
  77e615:	jbe    781137 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x50e7>
  77e61b:	movaps %xmm2,0x280(%rsp)
  77e623:	movaps %xmm1,0xe0(%rsp)
  77e62b:	add    0x238(%rsp),%rcx
  77e633:	jmp    77e6cf <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x267f>
  77e638:	movq   $0x0,0x1b0(%rsp)
  77e644:	movaps 0xc0(%rsp),%xmm0
  77e64c:	movss  %xmm0,0x1b8(%rsp)
  77e655:	movaps 0x80(%rsp),%xmm0
  77e65d:	movss  %xmm0,0x1bc(%rsp)
  77e666:	xorps  %xmm0,%xmm0
  77e669:	movl   $0x0,0x60(%rsp)
  77e671:	movaps 0x800(%rsp),%xmm1
  77e679:	jmp    77e756 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2706>
  77e67e:	movq   $0x0,0x390(%rsp)
  77e68a:	movaps 0xc0(%rsp),%xmm0
  77e692:	movss  %xmm0,0x398(%rsp)
  77e69b:	movaps 0x80(%rsp),%xmm0
  77e6a3:	movss  %xmm0,0x39c(%rsp)
  77e6ac:	xorps  %xmm0,%xmm0
  77e6af:	movaps %xmm0,0xe0(%rsp)
  77e6b7:	lea    0x390(%rsp),%rcx
  77e6bf:	movaps 0x800(%rsp),%xmm0
  77e6c7:	movaps %xmm0,0x280(%rsp)
  77e6cf:	movups (%rcx),%xmm0
  77e6d2:	movaps %xmm0,0x1b0(%rsp)
  77e6da:	mov    0x20(%r9,%r13,1),%edi
  77e6df:	call   776560 <_RNvMsh_NtCslbxve4rcJus_4gpui7runtimeNtB5_4Node4kind>
  77e6e4:	mov    $0x1,%cl
  77e6e6:	mov    %ecx,0x60(%rsp)
  77e6ea:	cmp    $0x7,%al
  77e6ec:	jne    77e705 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x26b5>
  77e6ee:	mov    0x30(%rsp),%r9
  77e6f3:	movaps 0xe0(%rsp),%xmm0
  77e6fb:	movaps 0x280(%rsp),%xmm1
  77e703:	jmp    77e756 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2706>
  77e705:	mov    0x30(%rsp),%r9
  77e70a:	mov    0x18(%r9,%r13,1),%ecx
  77e70f:	mov    $0xffffffff,%eax
  77e714:	cmp    %rax,%rcx
  77e717:	movaps 0xe0(%rsp),%xmm0
  77e71f:	movaps 0x280(%rsp),%xmm1
  77e727:	je     77e74e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x26fe>
  77e729:	mov    0x168(%rsp),%rax
  77e731:	cmp    %rcx,%rax
  77e734:	jbe    78118c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x513c>
  77e73a:	mov    0x160(%rsp),%rax
  77e742:	movzbl (%rax,%rcx,1),%eax
  77e746:	and    $0x1,%al
  77e748:	mov    %eax,0x60(%rsp)
  77e74c:	jmp    77e756 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2706>
  77e74e:	movl   $0x0,0x60(%rsp)
  77e756:	movlhps %xmm1,%xmm0
  77e759:	movups %xmm0,0x170(%rsp)
  77e761:	mov    0x20(%r9,%r13,1),%eax
  77e766:	and    $0xf,%eax
  77e769:	cmp    $0x7,%eax
  77e76c:	jb     77e77a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x272a>
  77e76e:	lea    -0x8(%rax),%ecx
  77e771:	cmp    $0x2,%ecx
  77e774:	jae    77f2d4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3284>
  77e77a:	mov    0x18(%r9,%r13,1),%ecx
  77e77f:	xor    %r12d,%r12d
  77e782:	mov    $0xffffffff,%edx
  77e787:	cmp    %rdx,%rcx
  77e78a:	je     77e7aa <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x275a>
  77e78c:	cmp    %rcx,0x168(%rsp)
  77e794:	jbe    77e7aa <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x275a>
  77e796:	mov    0x160(%rsp),%rdx
  77e79e:	movzbl (%rdx,%rcx,1),%r12d
  77e7a3:	and    $0x2,%r12b
  77e7a7:	shr    $1,%r12b
  77e7aa:	cmpb   $0x0,0x2f(%rsp)
  77e7af:	je     77e7fd <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x27ad>
  77e7b1:	mov    0x168(%rsp),%r14
  77e7b9:	cmp    0x158(%rsp),%r14
  77e7c1:	jne    77e7d1 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2781>
  77e7c3:	lea    0x158(%rsp),%rdi
  77e7cb:	call   *0x33beaf(%rip)        # aba680 <_DYNAMIC+0x810>
  77e7d1:	lea    (%r12,%r12,1),%eax
  77e7d5:	add    0x60(%rsp),%al
  77e7d9:	mov    0x160(%rsp),%rcx
  77e7e1:	mov    %al,(%rcx,%r14,1)
  77e7e5:	inc    %r14
  77e7e8:	mov    %r14,0x168(%rsp)
  77e7f0:	mov    0x30(%rsp),%rax
  77e7f5:	mov    0x20(%rax,%r13,1),%eax
  77e7fa:	and    $0xf,%eax
  77e7fd:	cmp    $0x9,%eax
  77e800:	ja     780f82 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4f32>
  77e806:	mov    $0x34f,%ecx
  77e80b:	bt     %eax,%ecx
  77e80e:	jb     77e88e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x283e>
  77e810:	movups 0x170(%rsp),%xmm0
  77e818:	movaps %xmm0,0x180(%rsp)
  77e820:	movups 0x698(%rsp),%xmm0
  77e828:	movaps %xmm0,0x390(%rsp)
  77e830:	lea    0x8d0(%rsp),%rdi
  77e838:	mov    %r15,%rsi
  77e83b:	lea    0x1b0(%rsp),%rdx
  77e843:	lea    0x2a4(%rsp),%rcx
  77e84b:	lea    0x390(%rsp),%r8
  77e853:	mov    0xf8(%rsp),%r9
  77e85b:	call   *0x33be27(%rip)        # aba688 <_DYNAMIC+0x818>
  77e861:	cmpl   $0xfffffffe,0x8d0(%rsp)
  77e869:	jne    780b09 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4ab9>
  77e86f:	lea    0x8d8(%rsp),%rax
  77e877:	movups (%rax),%xmm0
  77e87a:	movaps %xmm0,0x170(%rsp)
  77e882:	movups 0x10(%rax),%xmm0
  77e886:	movaps %xmm0,0x1b0(%rsp)
  77e88e:	cmpb   $0x0,0x2f(%rsp)
  77e893:	je     77e933 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x28e3>
  77e899:	movaps 0x170(%rsp),%xmm0
  77e8a1:	movaps %xmm0,0x390(%rsp)
  77e8a9:	mov    0x228(%rsp),%r14
  77e8b1:	cmp    0x218(%rsp),%r14
  77e8b9:	jne    77e8c8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2878>
  77e8bb:	lea    0x218(%rsp),%rdi
  77e8c3:	call   7729a0 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtCscO85OU7Wpt0_20gpui_reactivity_core8geometry4RectE8grow_oneCs9C2G9YFESsD_29canonical_text_public_control>
  77e8c8:	mov    0x220(%rsp),%rax
  77e8d0:	mov    %r14,%rcx
  77e8d3:	shl    $0x4,%rcx
  77e8d7:	movaps 0x390(%rsp),%xmm0
  77e8df:	movups %xmm0,(%rax,%rcx,1)
  77e8e3:	inc    %r14
  77e8e6:	mov    %r14,0x228(%rsp)
  77e8ee:	mov    0x240(%rsp),%r14
  77e8f6:	cmp    0x230(%rsp),%r14
  77e8fe:	jne    77e90d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x28bd>
  77e900:	lea    0x230(%rsp),%rdi
  77e908:	call   7729a0 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtCscO85OU7Wpt0_20gpui_reactivity_core8geometry4RectE8grow_oneCs9C2G9YFESsD_29canonical_text_public_control>
  77e90d:	mov    0x238(%rsp),%rax
  77e915:	mov    %r14,%rcx
  77e918:	shl    $0x4,%rcx
  77e91c:	movaps 0x1b0(%rsp),%xmm0
  77e924:	movups %xmm0,(%rax,%rcx,1)
  77e928:	inc    %r14
  77e92b:	mov    %r14,0x240(%rsp)
  77e933:	test   %ebx,%ebx
  77e935:	je     77e96b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x291b>
  77e937:	lea    0x390(%rsp),%rdi
  77e93f:	lea    0x698(%rsp),%rsi
  77e947:	lea    0x2a8(%rsp),%rdx
  77e94f:	call   75e460 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerso_0BQ_>
  77e954:	cmpl   $0x1,0x390(%rsp)
  77e95c:	jne    77e96b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x291b>
  77e95e:	lea    0x394(%rsp),%rax
  77e966:	movups (%rax),%xmm0
  77e969:	jmp    77e96e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x291e>
  77e96b:	xorps  %xmm0,%xmm0
  77e96e:	movaps %xmm0,0x6f0(%rsp)
  77e976:	mov    0x60(%rsp),%eax
  77e97a:	or     %r12b,%al
  77e97d:	cmp    $0x1,%al
  77e97f:	je     77e994 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2944>
  77e981:	mov    0x30(%rsp),%rax
  77e986:	mov    0x20(%rax,%r13,1),%edi
  77e98b:	call   776560 <_RNvMsh_NtCslbxve4rcJus_4gpui7runtimeNtB5_4Node4kind>
  77e990:	cmp    $0x6,%al
  77e992:	jne    77e9b4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2964>
  77e994:	lea    0x290(%rsp),%rdi
  77e99c:	lea    0x6f0(%rsp),%rsi
  77e9a4:	lea    0x1b0(%rsp),%rdx
  77e9ac:	call   *0x33bcde(%rip)        # aba690 <_DYNAMIC+0x820>
  77e9b2:	jmp    77ea21 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x29d1>
  77e9b4:	movsd  0x6f0(%rsp),%xmm0
  77e9bd:	movsd  0x6f8(%rsp),%xmm1
  77e9c6:	movaps %xmm0,%xmm2
  77e9c9:	addps  %xmm0,%xmm1
  77e9cc:	xorps  %xmm4,%xmm4
  77e9cf:	maxps  %xmm4,%xmm0
  77e9d2:	movaps %xmm0,%xmm3
  77e9d5:	cmpunordps %xmm0,%xmm3
  77e9d9:	andps  %xmm3,%xmm2
  77e9dc:	andnps %xmm0,%xmm3
  77e9df:	orps   %xmm2,%xmm3
  77e9e2:	movaps %xmm1,%xmm0
  77e9e5:	minps  0x800(%rsp),%xmm0
  77e9ed:	movaps %xmm0,%xmm2
  77e9f0:	cmpunordps %xmm0,%xmm2
  77e9f4:	andps  %xmm2,%xmm1
  77e9f7:	andnps %xmm0,%xmm2
  77e9fa:	orps   %xmm1,%xmm2
  77e9fd:	subps  %xmm3,%xmm2
  77ea00:	movaps %xmm2,%xmm0
  77ea03:	maxps  %xmm4,%xmm0
  77ea06:	movaps %xmm0,%xmm1
  77ea09:	cmpunordps %xmm0,%xmm1
  77ea0d:	andps  %xmm1,%xmm2
  77ea10:	andnps %xmm0,%xmm1
  77ea13:	orps   %xmm2,%xmm1
  77ea16:	movlhps %xmm1,%xmm3
  77ea19:	movups %xmm3,0x290(%rsp)
  77ea21:	test   %r12b,%r12b
  77ea24:	mov    0x30(%rsp),%rsi
  77ea29:	je     77ea58 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2a08>
  77ea2b:	movss  0x298(%rsp),%xmm0
  77ea34:	xor    %ebp,%ebp
  77ea36:	xorps  %xmm1,%xmm1
  77ea39:	ucomiss %xmm1,%xmm0
  77ea3c:	jne    77ea44 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x29f4>
  77ea3e:	jnp    77ecc5 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2c75>
  77ea44:	movss  0x29c(%rsp),%xmm0
  77ea4d:	ucomiss %xmm1,%xmm0
  77ea50:	jne    77ea58 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2a08>
  77ea52:	jnp    77ecc5 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2c75>
  77ea58:	mov    0x348(%rsp),%eax
  77ea5f:	mov    $0x3fffffff,%ecx
  77ea64:	and    %ecx,%eax
  77ea66:	cmp    $0x3f800001,%eax
  77ea6b:	mov    $0x80000000,%ecx
  77ea70:	cmove  %ecx,%eax
  77ea73:	movd   %eax,%xmm0
  77ea77:	xorps  %xmm1,%xmm1
  77ea7a:	ucomiss %xmm1,%xmm0
  77ea7d:	jbe    77eb5e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2b0e>
  77ea83:	movl   $0x1,0x398(%rsp)
  77ea8e:	movq   $0x23,0x390(%rsp)
  77ea9a:	test   %bl,%bl
  77ea9c:	je     780a4b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x49fb>
  77eaa2:	lea    0x390(%rsp),%rbx
  77eaaa:	mov    %rbx,%rdi
  77eaad:	call   74d7d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  77eab2:	lea    0x2a8(%rsp),%rax
  77eaba:	movups (%rax),%xmm0
  77eabd:	movaps %xmm0,0xb60(%rsp)
  77eac5:	mov    0x10(%rax),%rax
  77eac9:	mov    %rax,0xb70(%rsp)
  77ead1:	mov    %rbx,%rdi
  77ead4:	mov    0xa8(%rsp),%rsi
  77eadc:	mov    0x38(%rsp),%rdx
  77eae1:	xor    %ecx,%ecx
  77eae3:	call   *0x33bbaf(%rip)        # aba698 <_DYNAMIC+0x828>
  77eae9:	mov    0x3a0(%rsp),%r9
  77eaf1:	test   %r9,%r9
  77eaf4:	je     77ec51 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2c01>
  77eafa:	movups 0x390(%rsp),%xmm0
  77eb02:	movaps %xmm0,0x370(%rsp)
  77eb0a:	movaps 0x170(%rsp),%xmm0
  77eb12:	movaps %xmm0,0x120(%rsp)
  77eb1a:	movups 0x698(%rsp),%xmm0
  77eb22:	movaps %xmm0,0x180(%rsp)
  77eb2a:	lea    0x970(%rsp),%rdi
  77eb32:	mov    %r15,%rsi
  77eb35:	movss  0x74(%rsp),%xmm0
  77eb3b:	lea    0xb60(%rsp),%rdx
  77eb43:	lea    0x120(%rsp),%rcx
  77eb4b:	lea    0x370(%rsp),%r8
  77eb53:	call   *0x33bb47(%rip)        # aba6a0 <_DYNAMIC+0x830>
  77eb59:	jmp    77ec3e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2bee>
  77eb5e:	cmpq   $0x0,0x8(%rsi,%r13,1)
  77eb64:	jne    77eb80 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2b30>
  77eb66:	mov    0x20(%rsi,%r13,1),%edi
  77eb6b:	call   776560 <_RNvMsh_NtCslbxve4rcJus_4gpui7runtimeNtB5_4Node4kind>
  77eb70:	mov    $0x1,%bpl
  77eb73:	cmp    $0x4,%al
  77eb75:	mov    0x30(%rsp),%rsi
  77eb7a:	jne    77ecc5 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2c75>
  77eb80:	movl   $0x1,0x398(%rsp)
  77eb8b:	movq   $0x23,0x390(%rsp)
  77eb97:	test   %bl,%bl
  77eb99:	je     780a4b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x49fb>
  77eb9f:	lea    0x390(%rsp),%rbx
  77eba7:	mov    %rbx,%rdi
  77ebaa:	call   74d7d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  77ebaf:	lea    0x2a8(%rsp),%rcx
  77ebb7:	movups (%rcx),%xmm0
  77ebba:	movaps %xmm0,0x120(%rsp)
  77ebc2:	mov    0x10(%rcx),%rax
  77ebc6:	mov    %rax,0x130(%rsp)
  77ebce:	movups (%rcx),%xmm0
  77ebd1:	movaps %xmm0,0xc20(%rsp)
  77ebd9:	mov    0x10(%rcx),%rax
  77ebdd:	mov    %rax,0xc30(%rsp)
  77ebe5:	movaps 0x170(%rsp),%xmm0
  77ebed:	movaps %xmm0,0x370(%rsp)
  77ebf5:	movups 0x698(%rsp),%xmm0
  77ebfd:	movaps %xmm0,0x180(%rsp)
  77ec05:	movups -0x6bb20c(%rip),%xmm0        # c3a00 <GCC_except_table0+0x1634>
  77ec0c:	movaps %xmm0,0x390(%rsp)
  77ec14:	lea    0x970(%rsp),%rdi
  77ec1c:	mov    %r15,%rsi
  77ec1f:	movss  0x74(%rsp),%xmm0
  77ec25:	lea    0xc20(%rsp),%rdx
  77ec2d:	lea    0x370(%rsp),%rcx
  77ec35:	mov    %rbx,%r8
  77ec38:	call   *0x33ba6a(%rip)        # aba6a8 <_DYNAMIC+0x838>
  77ec3e:	cmp    $0xffffffff,%eax
  77ec41:	jne    780a84 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4a34>
  77ec47:	mov    $0x1,%bpl
  77ec4a:	mov    0x30(%rsp),%rsi
  77ec4f:	jmp    77ecc5 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2c75>
  77ec51:	movaps 0x170(%rsp),%xmm0
  77ec59:	movaps %xmm0,0x120(%rsp)
  77ec61:	lea    0x34c(%rsp),%rax
  77ec69:	movups -0x10(%rax),%xmm0
  77ec6d:	movaps %xmm0,0x180(%rsp)
  77ec75:	movups 0x698(%rsp),%xmm0
  77ec7d:	movaps %xmm0,0x390(%rsp)
  77ec85:	lea    0x970(%rsp),%rdi
  77ec8d:	lea    0x390(%rsp),%rsi
  77ec95:	movss  0x74(%rsp),%xmm0
  77ec9b:	lea    0xb60(%rsp),%rdx
  77eca3:	lea    0x120(%rsp),%rcx
  77ecab:	mov    %r15,%r8
  77ecae:	call   *0x33b9f4(%rip)        # aba6a8 <_DYNAMIC+0x838>
  77ecb4:	mov    $0x1,%bpl
  77ecb7:	cmp    $0xffffffff,%eax
  77ecba:	mov    0x30(%rsp),%rsi
  77ecbf:	jne    780a84 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4a34>
  77ecc5:	mov    0x20(%rsi,%r13,1),%edi
  77ecca:	mov    %edi,%eax
  77eccc:	and    $0xf,%eax
  77eccf:	cmp    $0x9,%eax
  77ecd2:	ja     780f82 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4f32>
  77ecd8:	cmp    $0x6,%eax
  77ecdb:	je     77f2e5 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3295>
  77ece1:	shr    $0x4,%edi
  77ece4:	dec    %edi
  77ece6:	mov    0x40(%rsp),%rax
  77eceb:	mov    0x2f0(%rax),%rsi
  77ecf2:	mov    0x2f8(%rax),%rdx
  77ecf9:	call   776450 <_RNvMsf_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSlot7get_mut>
  77ecfe:	test   %rax,%rax
  77ed01:	je     77f0ee <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x309e>
  77ed07:	lea    0x34c(%rsp),%rcx
  77ed0f:	movups -0x20(%rcx),%xmm0
  77ed13:	movaps %xmm0,0x960(%rsp)
  77ed1b:	mov    0x40(%rsp),%rcx
  77ed20:	mov    0x6e8(%rcx),%rbx
  77ed27:	mov    $0x1e,%esi
  77ed2c:	test   %rbx,%rbx
  77ed2f:	mov    0x30(%rsp),%rdx
  77ed34:	je     780e81 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4e31>
  77ed3a:	cmpq   $0x0,0x30(%rbx)
  77ed3f:	je     780e81 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4e31>
  77ed45:	movzbl 0x78c(%rsp),%ecx
  77ed4d:	movb   $0x2,0xe0(%rsp)
  77ed55:	cmp    $0x2,%cl
  77ed58:	je     77edcc <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2d7c>
  77ed5a:	mov    (%rdx,%r13,1),%rdx
  77ed5e:	cmp    %rdx,0x778(%rsp)
  77ed66:	jne    77edcc <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2d7c>
  77ed68:	mov    0x788(%rsp),%edx
  77ed6f:	mov    %edx,0x1d0(%rsp)
  77ed76:	movzbl 0x784(%rsp),%edx
  77ed7e:	mov    %dl,0x7e(%rsp)
  77ed82:	mov    0x780(%rsp),%edx
  77ed89:	mov    %edx,0x11c(%rsp)
  77ed90:	lea    0x785(%rsp),%rdi
  77ed98:	movzwl (%rdi),%edx
  77ed9b:	mov    %dx,0xb8(%rsp)
  77eda3:	movzbl 0x2(%rdi),%edx
  77eda7:	mov    %dl,0xba(%rsp)
  77edae:	movzwl 0x8(%rdi),%edx
  77edb2:	mov    %dx,0xb4(%rsp)
  77edba:	movzbl 0xa(%rdi),%edx
  77edbe:	mov    %dl,0xb6(%rsp)
  77edc5:	mov    %cl,0xe0(%rsp)
  77edcc:	cmpq   $0x0,0x1c0(%rsp)
  77edd5:	je     780ecd <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4e7d>
  77eddb:	movss  0x328(%rsp),%xmm0
  77ede4:	movaps 0x630(%rsp),%xmm1
  77edec:	subss  0x2c0(%rsp),%xmm1
  77edf5:	subss  0x308(%rsp),%xmm1
  77edfe:	subss  0x930(%rsp),%xmm1
  77ee07:	subss  0x30c(%rsp),%xmm1
  77ee10:	subss  0x920(%rsp),%xmm1
  77ee19:	lea    0x390(%rsp),%rdi
  77ee21:	mov    %rax,%rsi
  77ee24:	lea    0x1c0(%rsp),%rdx
  77ee2c:	mov    $0x1,%ecx
  77ee31:	mov    $0x1,%r8d
  77ee37:	call   *0x33b4b3(%rip)        # aba2f0 <_DYNAMIC+0x480>
  77ee3d:	mov    %r15,%r14
  77ee40:	mov    0x390(%rsp),%rax
  77ee48:	mov    0x398(%rsp),%r15
  77ee50:	cmp    $0xfffffffffffffffe,%rax
  77ee54:	jne    780a9b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4a4b>
  77ee5a:	movaps 0x2c0(%rsp),%xmm0
  77ee62:	movss  %xmm0,0xd8(%rsp)
  77ee6b:	movaps 0x910(%rsp),%xmm0
  77ee73:	movss  %xmm0,0xdc(%rsp)
  77ee7c:	mov    0x20(%r15),%rax
  77ee80:	test   %rax,%rax
  77ee83:	je     780f62 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4f12>
  77ee89:	lock incq (%rax)
  77ee8d:	jle    7811d8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  77ee93:	movsd  0xd8(%rsp),%xmm0
  77ee9c:	movsd  %xmm0,0x2f8(%rsp)
  77eea5:	mov    %rax,0x300(%rsp)
  77eead:	test   %bpl,%bpl
  77eeb0:	je     77f336 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x32e6>
  77eeb6:	testb  $0x1,0x2a4(%rsp)
  77eebe:	movl   $0x1,0x398(%rsp)
  77eec9:	movq   $0x23,0x390(%rsp)
  77eed5:	je     780bc3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4b73>
  77eedb:	lea    0x390(%rsp),%rdi
  77eee3:	call   74d7d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  77eee8:	lea    0x2a8(%rsp),%rcx
  77eef0:	movups (%rcx),%xmm0
  77eef3:	movaps %xmm0,0xb80(%rsp)
  77eefb:	mov    0x10(%rcx),%rax
  77eeff:	mov    %rax,0xb90(%rsp)
  77ef07:	movups (%rcx),%xmm0
  77ef0a:	movaps %xmm0,0x370(%rsp)
  77ef12:	mov    0x10(%rcx),%rax
  77ef16:	mov    %rax,0x380(%rsp)
  77ef1e:	cmpb   $0x2,0xe0(%rsp)
  77ef26:	je     77f02f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2fdf>
  77ef2c:	mov    0x11c(%rsp),%eax
  77ef33:	mov    %eax,0x180(%rsp)
  77ef3a:	movzbl 0x7e(%rsp),%eax
  77ef3f:	mov    %al,0x184(%rsp)
  77ef46:	movzbl 0xba(%rsp),%eax
  77ef4e:	lea    0x185(%rsp),%rcx
  77ef56:	mov    %al,0x2(%rcx)
  77ef59:	movzwl 0xb8(%rsp),%eax
  77ef61:	mov    %ax,(%rcx)
  77ef64:	mov    0x1d0(%rsp),%eax
  77ef6b:	mov    %eax,0x188(%rsp)
  77ef72:	movzbl 0xe0(%rsp),%eax
  77ef7a:	mov    %al,0x18c(%rsp)
  77ef81:	movzbl 0xb6(%rsp),%eax
  77ef89:	mov    %al,0xa(%rcx)
  77ef8c:	movzwl 0xb4(%rsp),%eax
  77ef94:	mov    %ax,0x8(%rcx)
  77ef98:	movl   $0xffffffff,0x120(%rsp)
  77efa3:	lea    0x120(%rsp),%rax
  77efab:	mov    %rax,0x390(%rsp)
  77efb3:	lea    0x970(%rsp),%rax
  77efbb:	mov    %rax,0x398(%rsp)
  77efc3:	lea    0xd8(%rsp),%rax
  77efcb:	mov    %rax,0x3a0(%rsp)
  77efd3:	lea    0xdc(%rsp),%rax
  77efdb:	mov    %rax,0x3a8(%rsp)
  77efe3:	lea    0x370(%rsp),%rax
  77efeb:	mov    %rax,0x3b0(%rsp)
  77eff3:	lea    0x170(%rsp),%rax
  77effb:	mov    %rax,0x3b8(%rsp)
  77f003:	mov    0x20(%r15),%rdi
  77f007:	mov    %r14,%rsi
  77f00a:	lea    0x390(%rsp),%rdx
  77f012:	call   73f5d0 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_>
  77f017:	test   %al,%al
  77f019:	je     780c67 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c17>
  77f01f:	mov    0x120(%rsp),%eax
  77f026:	cmp    $0xffffffff,%eax
  77f029:	jne    780c75 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c25>
  77f02f:	mov    %r14,%rdi
  77f032:	mov    0xa8(%rsp),%rsi
  77f03a:	mov    0x38(%rsp),%rdx
  77f03f:	mov    $0x1,%ecx
  77f044:	call   *0x33b64e(%rip)        # aba698 <_DYNAMIC+0x828>
  77f04a:	add    $0x30,%rbx
  77f04e:	mov    0x190(%rsp),%rax
  77f056:	test   %rax,%rax
  77f059:	je     77f0ff <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x30af>
  77f05f:	movups 0x180(%rsp),%xmm0
  77f067:	movaps %xmm0,0x700(%rsp)
  77f06f:	movaps 0x170(%rsp),%xmm0
  77f077:	movaps %xmm0,0x120(%rsp)
  77f07f:	movss  0xd8(%rsp),%xmm0
  77f088:	movss  0xdc(%rsp),%xmm1
  77f091:	lea    0x2a8(%rsp),%rdx
  77f099:	mov    0x10(%rdx),%rcx
  77f09d:	mov    %rcx,0x3a0(%rsp)
  77f0a5:	movups (%rdx),%xmm2
  77f0a8:	movaps %xmm2,0x390(%rsp)
  77f0b0:	mov    %rax,(%rsp)
  77f0b4:	lea    0x970(%rsp),%rdi
  77f0bc:	mov    %rbx,%rsi
  77f0bf:	mov    %r15,%rdx
  77f0c2:	lea    0x390(%rsp),%rcx
  77f0ca:	lea    0x120(%rsp),%r8
  77f0d2:	lea    0x700(%rsp),%r9
  77f0da:	movss  0x9c(%rsp),%xmm2
  77f0e3:	call   *0x33b5c7(%rip)        # aba6b0 <_DYNAMIC+0x840>
  77f0e9:	jmp    77f180 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3130>
  77f0ee:	movq   $0x0,0x1f8(%rsp)
  77f0fa:	jmp    77f359 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3309>
  77f0ff:	movaps 0x170(%rsp),%xmm0
  77f107:	movaps %xmm0,0x120(%rsp)
  77f10f:	movss  0xd8(%rsp),%xmm0
  77f118:	movss  0xdc(%rsp),%xmm1
  77f121:	lea    0x2a8(%rsp),%rcx
  77f129:	mov    0x10(%rcx),%rax
  77f12d:	mov    %rax,0x3a0(%rsp)
  77f135:	movups (%rcx),%xmm2
  77f138:	movaps %xmm2,0x390(%rsp)
  77f140:	movaps 0x960(%rsp),%xmm2
  77f148:	movaps %xmm2,0x180(%rsp)
  77f150:	lea    0x970(%rsp),%rdi
  77f158:	mov    %rbx,%rsi
  77f15b:	mov    %r15,%rdx
  77f15e:	lea    0x390(%rsp),%rcx
  77f166:	lea    0x120(%rsp),%r8
  77f16e:	mov    %r14,%r9
  77f171:	movss  0x9c(%rsp),%xmm2
  77f17a:	call   *0x33b538(%rip)        # aba6b8 <_DYNAMIC+0x848>
  77f180:	cmp    $0xffffffff,%eax
  77f183:	jne    780bac <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4b5c>
  77f189:	cmpb   $0x2,0xe0(%rsp)
  77f191:	je     77f336 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x32e6>
  77f197:	mov    0x11c(%rsp),%eax
  77f19e:	cmp    0x1d0(%rsp),%eax
  77f1a5:	jne    77f336 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x32e6>
  77f1ab:	mov    0x40(%rsp),%rax
  77f1b0:	mov    0x628(%rax),%rax
  77f1b7:	test   %rax,%rax
  77f1ba:	je     77f336 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x32e6>
  77f1c0:	mov    0x40(%rsp),%rcx
  77f1c5:	cmp    0x5f0(%rcx),%rax
  77f1cc:	jne    77f336 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x32e6>
  77f1d2:	mov    0x30(%rsp),%rax
  77f1d7:	mov    (%rax,%r13,1),%rax
  77f1db:	mov    0x40(%rsp),%rcx
  77f1e0:	cmp    %rax,0x630(%rcx)
  77f1e7:	jne    77f336 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x32e6>
  77f1ed:	movzbl 0xe0(%rsp),%ecx
  77f1f5:	mov    %r14,%rdi
  77f1f8:	mov    %r15,%rsi
  77f1fb:	mov    0x11c(%rsp),%edx
  77f202:	call   *0x33b2e8(%rip)        # aba4f0 <_DYNAMIC+0x680>
  77f208:	movq   $0x18,0x390(%rsp)
  77f214:	cmpl   $0x1,0x180(%rsp)
  77f21c:	jne    780c67 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c17>
  77f222:	lea    0x390(%rsp),%rbx
  77f22a:	mov    %rbx,%rdi
  77f22d:	call   74d7d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  77f232:	movsd  0x184(%rsp),%xmm0
  77f23b:	movaps 0x2c0(%rsp),%xmm1
  77f243:	unpcklps 0x910(%rsp),%xmm1
  77f24b:	addps  %xmm0,%xmm1
  77f24e:	movhps 0x18c(%rsp),%xmm1
  77f256:	movups %xmm1,0x700(%rsp)
  77f25e:	mov    %rbx,%rdi
  77f261:	mov    0xa8(%rsp),%rsi
  77f269:	mov    0x38(%rsp),%rdx
  77f26e:	mov    $0x1,%ecx
  77f273:	call   *0x33b41f(%rip)        # aba698 <_DYNAMIC+0x828>
  77f279:	mov    0x3a0(%rsp),%r9
  77f281:	test   %r9,%r9
  77f284:	je     77f2ef <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x329f>
  77f286:	movups 0x390(%rsp),%xmm0
  77f28e:	movaps %xmm0,0x120(%rsp)
  77f296:	movaps 0x170(%rsp),%xmm0
  77f29e:	movaps %xmm0,0x180(%rsp)
  77f2a6:	xorps  %xmm0,%xmm0
  77f2a9:	lea    0x970(%rsp),%rdi
  77f2b1:	lea    0x700(%rsp),%rsi
  77f2b9:	lea    0xb80(%rsp),%rdx
  77f2c1:	mov    %r14,%rcx
  77f2c4:	lea    0x120(%rsp),%r8
  77f2cc:	call   *0x33b3ce(%rip)        # aba6a0 <_DYNAMIC+0x830>
  77f2d2:	jmp    77f32d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x32dd>
  77f2d4:	mov    $0x1,%r12b
  77f2d7:	cmp    $0x7,%eax
  77f2da:	je     77e7aa <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x275a>
  77f2e0:	jmp    780f82 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4f32>
  77f2e5:	mov    $0xffffffff,%edi
  77f2ea:	jmp    77ece6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2c96>
  77f2ef:	movaps 0x170(%rsp),%xmm0
  77f2f7:	movaps %xmm0,0x390(%rsp)
  77f2ff:	lea    0x970(%rsp),%rdi
  77f307:	lea    0x700(%rsp),%rsi
  77f30f:	lea    0xb80(%rsp),%rdx
  77f317:	lea    0x390(%rsp),%rcx
  77f31f:	lea    0x960(%rsp),%r8
  77f327:	call   *0x33ae23(%rip)        # aba150 <_DYNAMIC+0x2e0>
  77f32d:	cmp    $0xffffffff,%eax
  77f330:	jne    780bac <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4b5c>
  77f336:	mov    0x2f8(%rsp),%rax
  77f33e:	mov    %rax,0x1f0(%rsp)
  77f346:	mov    0x300(%rsp),%rax
  77f34e:	mov    %rax,0x1f8(%rsp)
  77f356:	mov    %r14,%r15
  77f359:	mov    0x30(%rsp),%r14
  77f35e:	test   %bpl,%bpl
  77f361:	je     77f4ba <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x346a>
  77f367:	mov    0x20(%r14,%r13,1),%edi
  77f36c:	call   *0x33af76(%rip)        # aba2e8 <_DYNAMIC+0x478>
  77f372:	mov    %edx,%ebp
  77f374:	cmp    $0x2,%dl
  77f377:	je     77f4ba <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x346a>
  77f37d:	mov    0x2d8(%rsp),%rcx
  77f385:	mov    (%rcx),%rcx
  77f388:	test   %rcx,%rcx
  77f38b:	je     780fa0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4f50>
  77f391:	mov    0x10(%rcx),%rsi
  77f395:	mov    %eax,%ebx
  77f397:	cmp    %rbx,%rsi
  77f39a:	jbe    781154 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5104>
  77f3a0:	mov    0x8(%rcx),%rax
  77f3a4:	movaps 0x930(%rsp),%xmm4
  77f3ac:	movaps %xmm4,%xmm0
  77f3af:	shufps $0xe8,%xmm4,%xmm0
  77f3b3:	movaps 0x940(%rsp),%xmm3
  77f3bb:	addps  %xmm0,%xmm3
  77f3be:	movaps 0x2c0(%rsp),%xmm5
  77f3c6:	movaps %xmm5,%xmm1
  77f3c9:	shufps $0xe8,%xmm5,%xmm1
  77f3cd:	addps  %xmm1,%xmm3
  77f3d0:	movaps 0x630(%rsp),%xmm2
  77f3d8:	subps  %xmm1,%xmm2
  77f3db:	shufps $0xed,%xmm5,%xmm5
  77f3df:	subps  %xmm5,%xmm2
  77f3e2:	subps  %xmm0,%xmm2
  77f3e5:	shufps $0xed,%xmm4,%xmm4
  77f3e9:	subps  %xmm4,%xmm2
  77f3ec:	subps  0x920(%rsp),%xmm2
  77f3f4:	movlhps %xmm2,%xmm3
  77f3f7:	movups %xmm3,0x370(%rsp)
  77f3ff:	testb  $0x1,0x2a4(%rsp)
  77f407:	movl   $0x1,0x398(%rsp)
  77f412:	movq   $0x23,0x390(%rsp)
  77f41e:	je     780bfc <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4bac>
  77f424:	lea    (%rax,%rbx,8),%rbx
  77f428:	lea    0x390(%rsp),%r14
  77f430:	mov    %r14,%rdi
  77f433:	call   74d7d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  77f438:	lea    0x2a8(%rsp),%rcx
  77f440:	movups (%rcx),%xmm0
  77f443:	movaps %xmm0,0x120(%rsp)
  77f44b:	mov    0x10(%rcx),%rax
  77f44f:	mov    %rax,0x130(%rsp)
  77f457:	movups (%rcx),%xmm0
  77f45a:	movaps %xmm0,0xc40(%rsp)
  77f462:	mov    0x10(%rcx),%rax
  77f466:	mov    %rax,0xc50(%rsp)
  77f46e:	movaps 0x170(%rsp),%xmm0
  77f476:	movaps %xmm0,0x390(%rsp)
  77f47e:	movzbl %bpl,%r9d
  77f482:	lea    0x970(%rsp),%rdi
  77f48a:	mov    %rbx,%rsi
  77f48d:	lea    0x370(%rsp),%rdx
  77f495:	lea    0xc40(%rsp),%rcx
  77f49d:	mov    %r14,%r8
  77f4a0:	mov    0x30(%rsp),%r14
  77f4a5:	movss  0x74(%rsp),%xmm0
  77f4ab:	call   *0x33b20f(%rip)        # aba6c0 <_DYNAMIC+0x850>
  77f4b1:	cmp    $0xffffffff,%eax
  77f4b4:	jne    780c32 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4be2>
  77f4ba:	mov    0x18(%r14,%r13,1),%ebx
  77f4bf:	cmpb   $0x0,0x2f(%rsp)
  77f4c4:	je     77f4ee <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x349e>
  77f4c6:	cmp    $0xffffffff,%ebx
  77f4c9:	je     77f4e9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3499>
  77f4cb:	mov    0x110(%rsp),%rsi
  77f4d3:	cmp    %rbx,%rsi
  77f4d6:	jbe    781145 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x50f5>
  77f4dc:	mov    0x108(%rsp),%rax
  77f4e4:	mov    (%rax,%rbx,4),%ebx
  77f4e7:	jmp    77f4ee <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x349e>
  77f4e9:	mov    $0xffffffff,%ebx
  77f4ee:	cmpb   $0x0,0x60(%rsp)
  77f4f3:	je     77f5df <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x358f>
  77f4f9:	movss  0x298(%rsp),%xmm0
  77f502:	xorps  %xmm1,%xmm1
  77f505:	ucomiss %xmm1,%xmm0
  77f508:	jne    77f50c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x34bc>
  77f50a:	jnp    77f524 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x34d4>
  77f50c:	movss  0x29c(%rsp),%xmm0
  77f515:	ucomiss %xmm1,%xmm0
  77f518:	jne    77f5df <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x358f>
  77f51e:	jp     77f5df <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x358f>
  77f524:	cmpb   $0x0,0x1d4(%rsp)
  77f52c:	je     77f556 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3506>
  77f52e:	movss  0x1b8(%rsp),%xmm0
  77f537:	ucomiss %xmm1,%xmm0
  77f53a:	jne    77f53e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x34ee>
  77f53c:	jnp    77f556 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3506>
  77f53e:	movss  0x1bc(%rsp),%xmm0
  77f547:	ucomiss %xmm1,%xmm0
  77f54a:	jne    77f5df <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x358f>
  77f550:	jp     77f5df <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x358f>
  77f556:	test   %r12b,%r12b
  77f559:	je     77f57b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x352b>
  77f55b:	movss  0x1b8(%rsp),%xmm0
  77f564:	ucomiss %xmm1,%xmm0
  77f567:	jne    77f56b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x351b>
  77f569:	jnp    77f57b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x352b>
  77f56b:	movss  0x1bc(%rsp),%xmm0
  77f574:	ucomiss %xmm1,%xmm0
  77f577:	jne    77f5df <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x358f>
  77f579:	jp     77f5df <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x358f>
  77f57b:	mov    0x110(%rsp),%r14
  77f583:	cmp    0x100(%rsp),%r14
  77f58b:	jne    77f59a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x354a>
  77f58d:	lea    0x100(%rsp),%rdi
  77f595:	call   772c40 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtCslbxve4rcJus_4gpui7runtime6ParentE8grow_oneCs9C2G9YFESsD_29canonical_text_public_control>
  77f59a:	mov    0x108(%rsp),%rax
  77f5a2:	mov    %ebx,(%rax,%r14,4)
  77f5a6:	inc    %r14
  77f5a9:	mov    %r14,0x110(%rsp)
  77f5b1:	mov    0x1f8(%rsp),%rax
  77f5b9:	test   %rax,%rax
  77f5bc:	je     77dd26 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1cd6>
  77f5c2:	lock decq (%rax)
  77f5c6:	jne    77dd26 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1cd6>
  77f5cc:	lea    0x1f8(%rsp),%rdi
  77f5d4:	call   *0x33abf6(%rip)        # aba1d0 <_DYNAMIC+0x360>
  77f5da:	jmp    77dd26 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1cd6>
  77f5df:	mov    0x20(%r14,%r13,1),%edi
  77f5e4:	mov    $0x1,%r12b
  77f5e7:	call   776560 <_RNvMsh_NtCslbxve4rcJus_4gpui7runtimeNtB5_4Node4kind>
  77f5ec:	cmp    $0x7,%al
  77f5ee:	jne    77f609 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x35b9>
  77f5f0:	mov    0x30(%rsp),%rax
  77f5f5:	mov    (%rax,%r13,1),%rsi
  77f5f9:	mov    $0x1,%r12b
  77f5fc:	lea    0x6a8(%rsp),%rdi
  77f604:	call   77afd0 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapyNtNtB7_7set_val9SetValZSTE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  77f609:	cmpb   $0x0,0x2f(%rsp)
  77f60e:	je     77f661 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3611>
  77f610:	mov    0x150(%rsp),%rsi
  77f618:	mov    $0x1,%edi
  77f61d:	mov    $0x1,%r12b
  77f620:	call   *0x33aaca(%rip)        # aba0f0 <_DYNAMIC+0x280>
  77f626:	mov    %eax,%ebp
  77f628:	mov    0x110(%rsp),%r14
  77f630:	cmp    0x100(%rsp),%r14
  77f638:	jne    77f64a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x35fa>
  77f63a:	mov    $0x1,%r12b
  77f63d:	lea    0x100(%rsp),%rdi
  77f645:	call   772c40 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtCslbxve4rcJus_4gpui7runtime6ParentE8grow_oneCs9C2G9YFESsD_29canonical_text_public_control>
  77f64a:	mov    0x108(%rsp),%rax
  77f652:	mov    %ebp,(%rax,%r14,4)
  77f656:	inc    %r14
  77f659:	mov    %r14,0x110(%rsp)
  77f661:	movss  0x298(%rsp),%xmm0
  77f66a:	xor    %edx,%edx
  77f66c:	xorps  %xmm1,%xmm1
  77f66f:	ucomiss %xmm1,%xmm0
  77f672:	jne    77f67a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x362a>
  77f674:	jnp    77f701 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x36b1>
  77f67a:	movss  0x29c(%rsp),%xmm0
  77f683:	ucomiss %xmm1,%xmm0
  77f686:	mov    $0x0,%ebp
  77f68b:	mov    0x30(%rsp),%rsi
  77f690:	jne    77f694 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3644>
  77f692:	jnp    77f703 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x36b3>
  77f694:	mov    0x20(%rsi,%r13,1),%edi
  77f699:	mov    %edi,%eax
  77f69b:	and    $0xf,%eax
  77f69e:	cmp    $0x9,%eax
  77f6a1:	ja     7810ba <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x506a>
  77f6a7:	cmp    $0x6,%eax
  77f6aa:	je     77f6b4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3664>
  77f6ac:	mov    $0x1,%bpl
  77f6af:	cmp    $0xf,%edi
  77f6b2:	ja     77f703 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x36b3>
  77f6b4:	mov    0x348(%rsp),%eax
  77f6bb:	mov    $0x3fffffff,%ecx
  77f6c0:	and    %ecx,%eax
  77f6c2:	cmp    $0x3f800001,%eax
  77f6c7:	mov    $0x80000000,%ecx
  77f6cc:	cmove  %ecx,%eax
  77f6cf:	movd   %eax,%xmm0
  77f6d3:	mov    $0x1,%bpl
  77f6d6:	ucomiss %xmm1,%xmm0
  77f6d9:	ja     77f703 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x36b3>
  77f6db:	cmpq   $0x0,0x8(%rsi,%r13,1)
  77f6e1:	jne    77f703 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x36b3>
  77f6e3:	mov    $0x1,%r12b
  77f6e6:	call   776560 <_RNvMsh_NtCslbxve4rcJus_4gpui7runtimeNtB5_4Node4kind>
  77f6eb:	lea    -0x4(%rax),%ecx
  77f6ee:	cmp    $0x2,%al
  77f6f0:	setae  %al
  77f6f3:	test   $0xfb,%cl
  77f6f6:	sete   %bpl
  77f6fa:	and    %al,%bpl
  77f6fd:	xor    %edx,%edx
  77f6ff:	jmp    77f703 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x36b3>
  77f701:	xor    %ebp,%ebp
  77f703:	mov    0x150(%rsp),%rax
  77f70b:	test   %rax,%rax
  77f70e:	je     77f725 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x36d5>
  77f710:	mov    0x148(%rsp),%rcx
  77f718:	shl    $0x6,%rax
  77f71c:	mov    -0x8(%rcx,%rax,1),%ecx
  77f720:	mov    $0x1,%edx
  77f725:	mov    %ebp,%eax
  77f727:	xor    $0x1,%al
  77f729:	movzbl %al,%esi
  77f72c:	mov    $0x1,%r12b
  77f72f:	mov    %ebx,%edi
  77f731:	call   *0x33af91(%rip)        # aba6c8 <_DYNAMIC+0x858>
  77f737:	mov    %eax,0x2c0(%rsp)
  77f73e:	mov    0x1f8(%rsp),%rax
  77f746:	test   %rax,%rax
  77f749:	sete   0x60(%rsp)
  77f74e:	je     77f790 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3740>
  77f750:	mov    0x150(%rsp),%ecx
  77f757:	mov    %ecx,0x3a0(%rsp)
  77f75e:	movsd  0x1f0(%rsp),%xmm0
  77f767:	movsd  %xmm0,0x398(%rsp)
  77f770:	mov    %rax,0x390(%rsp)
  77f778:	xor    %r12d,%r12d
  77f77b:	lea    0x200(%rsp),%rdi
  77f783:	lea    0x390(%rsp),%rsi
  77f78b:	call   775e90 <_RNvMsF_NtCscdodAO9FK5_5alloc3vecINtB5_3VecNtNtNtCslbxve4rcJus_4gpui7runtime13text_geometry5EntryE8push_mutCs9C2G9YFESsD_29canonical_text_public_control>
  77f790:	cmp    $0xffffffff,%ebx
  77f793:	je     77f7c8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3778>
  77f795:	mov    %ebx,%ebx
  77f797:	mov    0x150(%rsp),%rsi
  77f79f:	cmp    %rbx,%rsi
  77f7a2:	jbe    7811c7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5177>
  77f7a8:	mov    0x148(%rsp),%rax
  77f7b0:	shl    $0x6,%rbx
  77f7b4:	mov    0x30(%rax,%rbx,1),%rax
  77f7b9:	mov    %rax,0x394(%rsp)
  77f7c1:	mov    $0x1,%eax
  77f7c6:	jmp    77f7ca <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x377a>
  77f7c8:	xor    %eax,%eax
  77f7ca:	mov    %eax,0x390(%rsp)
  77f7d1:	movzbl 0x60(%rsp),%eax
  77f7d6:	mov    %eax,%r12d
  77f7d9:	lea    0x2a4(%rsp),%rdi
  77f7e1:	lea    0x390(%rsp),%rsi
  77f7e9:	lea    0x268(%rsp),%rdx
  77f7f1:	call   *0x33aed9(%rip)        # aba6d0 <_DYNAMIC+0x860>
  77f7f7:	mov    %rax,%rbx
  77f7fa:	mov    0x30(%rsp),%rax
  77f7ff:	mov    (%rax,%r13,1),%r14
  77f803:	mov    0x20(%rax,%r13,1),%edi
  77f808:	movzbl 0x60(%rsp),%eax
  77f80d:	mov    %eax,%r12d
  77f810:	call   776560 <_RNvMsh_NtCslbxve4rcJus_4gpui7runtimeNtB5_4Node4kind>
  77f815:	mov    %eax,%r15d
  77f818:	mov    0x30(%rsp),%rax
  77f81d:	mov    0x20(%rax,%r13,1),%edi
  77f822:	mov    %edi,%eax
  77f824:	and    $0xf,%eax
  77f827:	cmp    $0x9,%eax
  77f82a:	ja     78109c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x504c>
  77f830:	cmp    $0x6,%eax
  77f833:	je     77fc71 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3c21>
  77f839:	shr    $0x4,%edi
  77f83c:	dec    %edi
  77f83e:	mov    0x40(%rsp),%rax
  77f843:	mov    0x2f0(%rax),%rsi
  77f84a:	mov    0x2f8(%rax),%rdx
  77f851:	movzbl 0x60(%rsp),%eax
  77f856:	mov    %eax,%r12d
  77f859:	call   776400 <_RNvMsf_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSlot3get>
  77f85e:	mov    %ebp,0x74(%rsp)
  77f862:	test   %rax,%rax
  77f865:	je     77f899 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3849>
  77f867:	mov    0x40(%rax),%rbp
  77f86b:	testb  $0x1,0x0(%rbp)
  77f86f:	jne    77f89b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x384b>
  77f871:	mov    0x8(%rbp),%rax
  77f875:	test   $0x1,%al
  77f877:	jne    77f89b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x384b>
  77f879:	mov    $0x2,%eax
  77f87e:	lock xadd %rax,0x8(%rbp)
  77f884:	and    0x888(%rsp),%rax
  77f88c:	neg    %rax
  77f88f:	jno    77f89b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x384b>
  77f891:	lock orq $0x1,0x8(%rbp)
  77f897:	jmp    77f89b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x384b>
  77f899:	xor    %ebp,%ebp
  77f89b:	movdqa 0x630(%rsp),%xmm0
  77f8a4:	movd   %xmm0,%esi
  77f8a8:	shufps $0x55,%xmm0,%xmm0
  77f8ac:	movd   %xmm0,%eax
  77f8b0:	shl    $0x20,%rax
  77f8b4:	or     %rax,%rsi
  77f8b7:	lea    0x180(%rsp),%rdi
  77f8bf:	lea    0x2a4(%rsp),%rdx
  77f8c7:	call   *0x33ae0b(%rip)        # aba6d8 <_DYNAMIC+0x868>
  77f8cd:	mov    0x30(%rsp),%r12
  77f8d2:	mov    0x20(%r12,%r13,1),%edi
  77f8d7:	call   776560 <_RNvMsh_NtCslbxve4rcJus_4gpui7runtimeNtB5_4Node4kind>
  77f8dc:	xor    %esi,%esi
  77f8de:	cmpq   $0x0,0x8(%r12,%r13,1)
  77f8e4:	setne  %sil
  77f8e8:	movzbl %al,%edi
  77f8eb:	call   7761b0 <_RNvMs_NtNtCslbxve4rcJus_4gpui7runtime9semanticsNtB4_7Actions8for_node>
  77f8f0:	mov    0x18(%r12,%r13,1),%ecx
  77f8f5:	mov    $0xffffffff,%edx
  77f8fa:	cmp    %rdx,%rcx
  77f8fd:	je     77f933 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x38e3>
  77f8ff:	cmp    %rcx,0x168(%rsp)
  77f907:	mov    0x2c0(%rsp),%esi
  77f90e:	jbe    77f92a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x38da>
  77f910:	mov    0x160(%rsp),%rdx
  77f918:	cmpb   $0x0,(%rdx,%rcx,1)
  77f91c:	setne  %cl
  77f91f:	mov    0xbc(%rsp),%edx
  77f926:	or     %cl,%dl
  77f928:	jmp    77f941 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x38f1>
  77f92a:	mov    0xbc(%rsp),%edx
  77f931:	jmp    77f941 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x38f1>
  77f933:	mov    0xbc(%rsp),%edx
  77f93a:	mov    0x2c0(%rsp),%esi
  77f941:	movzbl %al,%ecx
  77f944:	or     $0x20,%al
  77f946:	movzbl %al,%eax
  77f949:	test   %dl,%dl
  77f94b:	cmove  %ecx,%eax
  77f94e:	mov    %r14,0x3b0(%rsp)
  77f956:	mov    %esi,0x3c8(%rsp)
  77f95d:	mov    %r15b,0x3cd(%rsp)
  77f965:	mov    %rbp,0x3b8(%rsp)
  77f96d:	movups 0x180(%rsp),%xmm0
  77f975:	movaps %xmm0,0x390(%rsp)
  77f97d:	mov    %rbx,0x3c0(%rsp)
  77f985:	movups 0x290(%rsp),%xmm0
  77f98d:	lea    0x394(%rsp),%rcx
  77f995:	movups %xmm0,0xc(%rcx)
  77f999:	mov    0x74(%rsp),%ecx
  77f99d:	mov    %cl,0x3ce(%rsp)
  77f9a4:	mov    %al,0x3cc(%rsp)
  77f9ab:	movzbl 0x60(%rsp),%eax
  77f9b0:	mov    %eax,%r12d
  77f9b3:	lea    0x140(%rsp),%rdi
  77f9bb:	lea    0x390(%rsp),%rsi
  77f9c3:	call   775e10 <_RNvMsF_NtCscdodAO9FK5_5alloc3vecINtB5_3VecNtNtCslbxve4rcJus_4gpui7runtime9PresentedE8push_mutCs9C2G9YFESsD_29canonical_text_public_control>
  77f9c8:	cmpb   $0x2,0x690(%rsp)
  77f9d0:	je     77fbf4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3ba4>
  77f9d6:	mov    0x150(%rsp),%rsi
  77f9de:	lea    -0x1(%rsi),%rbx
  77f9e2:	mov    0x40(%rsp),%rax
  77f9e7:	cmp    0x5c0(%rax),%rbx
  77f9ee:	jae    77fa31 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x39e1>
  77f9f0:	mov    0x5b8(%rax),%r14
  77f9f7:	movzbl 0x60(%rsp),%eax
  77f9fc:	mov    %eax,%r12d
  77f9ff:	lea    0xb98(%rsp),%rdi
  77fa07:	call   *0x33ab53(%rip)        # aba560 <_DYNAMIC+0x6f0>
  77fa0d:	mov    %rax,0x878(%rsp)
  77fa15:	mov    %rdx,0x880(%rsp)
  77fa1d:	mov    %rbx,%rax
  77fa20:	shl    $0x6,%rax
  77fa24:	add    %rax,%r14
  77fa27:	mov    0x150(%rsp),%rsi
  77fa2f:	jmp    77fa34 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x39e4>
  77fa31:	xor    %r14d,%r14d
  77fa34:	cmp    %rsi,%rbx
  77fa37:	jae    7811b8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5168>
  77fa3d:	mov    %rbx,%rax
  77fa40:	shl    $0x6,%rax
  77fa44:	add    0x148(%rsp),%rax
  77fa4c:	movups 0x270(%rsp),%xmm0
  77fa54:	mov    %r14,0x198(%rsp)
  77fa5c:	mov    0x878(%rsp),%rcx
  77fa64:	mov    %rcx,0x1a0(%rsp)
  77fa6c:	mov    0x880(%rsp),%rcx
  77fa74:	mov    %rcx,0x1a8(%rsp)
  77fa7c:	mov    %rax,0x180(%rsp)
  77fa84:	movups %xmm0,0x188(%rsp)
  77fa8c:	mov    0x40(%rsp),%rcx
  77fa91:	mov    0x650(%rcx),%rax
  77fa98:	mov    %rax,0x120(%rsp)
  77faa0:	mov    0x678(%rsp),%rax
  77faa8:	mov    %rax,0x128(%rsp)
  77fab0:	mov    0x2f0(%rsp),%eax
  77fab7:	lea    0x130(%rsp),%rdx
  77fabf:	mov    %eax,0x8(%rdx)
  77fac2:	mov    0x2e8(%rsp),%rax
  77faca:	mov    %rax,(%rdx)
  77facd:	movzbl 0x57(%rsp),%eax
  77fad2:	mov    %al,0x13c(%rsp)
  77fad9:	movzbl 0x7c(%rsp),%eax
  77fade:	mov    %al,0xf(%rdx)
  77fae1:	movzwl 0x7a(%rsp),%eax
  77fae6:	mov    %ax,0xd(%rdx)
  77faea:	mov    0x6e8(%rcx),%rdi
  77faf1:	test   %rdi,%rdi
  77faf4:	je     77fb0c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3abc>
  77faf6:	movzbl 0x60(%rsp),%eax
  77fafb:	mov    %eax,%r12d
  77fafe:	mov    %rbx,%rsi
  77fb01:	call   *0x33abd9(%rip)        # aba6e0 <_DYNAMIC+0x870>
  77fb07:	mov    %rax,%r15
  77fb0a:	jmp    77fb0f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3abf>
  77fb0c:	xor    %r15d,%r15d
  77fb0f:	mov    0x210(%rsp),%rax
  77fb17:	test   %rax,%rax
  77fb1a:	mov    0x30(%rsp),%rsi
  77fb1f:	je     77fb57 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3b07>
  77fb21:	mov    0x208(%rsp),%rcx
  77fb29:	lea    (%rax,%rax,2),%rdx
  77fb2d:	lea    (%rcx,%rdx,8),%rax
  77fb31:	add    $0xffffffffffffffe8,%rax
  77fb35:	mov    $0x0,%ebp
  77fb3a:	test   %rax,%rax
  77fb3d:	je     77fb59 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3b09>
  77fb3f:	lea    (%rcx,%rdx,8),%rcx
  77fb43:	mov    -0x8(%rcx),%ecx
  77fb46:	cmp    %rcx,%rbx
  77fb49:	mov    $0x0,%ecx
  77fb4e:	cmovne %rcx,%rax
  77fb52:	mov    %rax,%rbp
  77fb55:	jmp    77fb59 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3b09>
  77fb57:	xor    %ebp,%ebp
  77fb59:	mov    (%rsi,%r13,1),%rdx
  77fb5d:	cvtps2pd 0x630(%rsp),%xmm0
  77fb65:	movaps %xmm0,0x370(%rsp)
  77fb6d:	movzbl 0x60(%rsp),%eax
  77fb72:	mov    %eax,%r12d
  77fb75:	lea    0x390(%rsp),%rdi
  77fb7d:	lea    0x6c0(%rsp),%rsi
  77fb85:	lea    0x370(%rsp),%rcx
  77fb8d:	call   *0x33ab55(%rip)        # aba6e8 <_DYNAMIC+0x878>
  77fb93:	mov    0x30(%rsp),%rax
  77fb98:	mov    (%rax,%r13,1),%rdx
  77fb9c:	mov    0x40(%rsp),%rax
  77fba1:	mov    0x670(%rax),%rdi
  77fba8:	mov    0x678(%rax),%rsi
  77fbaf:	call   744a10 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyNtNtNtCslbxve4rcJus_4gpui7runtime4list7ListRowE3getyECs9C2G9YFESsD_29canonical_text_public_control>
  77fbb4:	mov    %rax,0x8(%rsp)
  77fbb9:	lea    0x390(%rsp),%rax
  77fbc1:	mov    %rax,(%rsp)
  77fbc5:	movzbl 0x60(%rsp),%eax
  77fbca:	mov    %eax,%r12d
  77fbcd:	lea    0x688(%rsp),%rdi
  77fbd5:	mov    %rbx,%rsi
  77fbd8:	lea    0x180(%rsp),%rdx
  77fbe0:	mov    %r15,%r8
  77fbe3:	mov    %rbp,%r9
  77fbe6:	lea    0x120(%rsp),%rcx
  77fbee:	call   *0x33aafc(%rip)        # aba6f0 <_DYNAMIC+0x880>
  77fbf4:	cmpl   $0xffffffff,0x810(%rsp)
  77fbfc:	je     77fc51 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3c01>
  77fbfe:	mov    0xf0(%rsp),%rax
  77fc06:	mov    (%rax),%rbx
  77fc09:	test   %rbx,%rbx
  77fc0c:	je     77fc51 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3c01>
  77fc0e:	mov    0x30(%rsp),%rax
  77fc13:	mov    (%rax,%r13,1),%r15
  77fc17:	mov    0x40(%rsp),%rax
  77fc1c:	mov    0x670(%rax),%rdi
  77fc23:	mov    0x678(%rax),%rsi
  77fc2a:	mov    %r15,%rdx
  77fc2d:	call   744a10 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyNtNtNtCslbxve4rcJus_4gpui7runtime4list7ListRowE3getyECs9C2G9YFESsD_29canonical_text_public_control>
  77fc32:	movzbl 0x60(%rsp),%ecx
  77fc37:	mov    %ecx,%r12d
  77fc3a:	lea    0x810(%rsp),%rdi
  77fc42:	mov    %rbx,%rsi
  77fc45:	mov    %r15,%rdx
  77fc48:	mov    %rax,%rcx
  77fc4b:	call   *0x33a8bf(%rip)        # aba510 <_DYNAMIC+0x6a0>
  77fc51:	mov    0x38(%rsp),%rcx
  77fc56:	inc    %rcx
  77fc59:	cmp    0x660(%rsp),%rcx
  77fc61:	lea    0x180(%rsp),%r15
  77fc69:	jb     77dd02 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1cb2>
  77fc6f:	jmp    77fc7b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3c2b>
  77fc71:	mov    $0xffffffff,%edi
  77fc76:	jmp    77f83e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x37ee>
  77fc7b:	cmpl   $0xffffffff,0x810(%rsp)
  77fc83:	mov    0x40(%rsp),%r14
  77fc88:	mov    0xf8(%rsp),%rbx
  77fc90:	je     77fca0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3c50>
  77fc92:	lea    0x810(%rsp),%rdi
  77fc9a:	call   *0x33a878(%rip)        # aba518 <_DYNAMIC+0x6a8>
  77fca0:	movzbl 0x690(%rsp),%eax
  77fca8:	cmp    $0x2,%al
  77fcaa:	je     77fcfb <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3cab>
  77fcac:	mov    0x688(%rsp),%rdi
  77fcb4:	mov    0x6a0(%r14),%rcx
  77fcbb:	mov    0x260(%rsp),%rdx
  77fcc3:	mov    %rdx,0x390(%rsp)
  77fccb:	mov    %rcx,0x398(%rsp)
  77fcd3:	mov    %rbx,0x3a0(%rsp)
  77fcdb:	mov    0x5c0(%r14),%rcx
  77fce2:	mov    0x150(%rsp),%r8
  77fcea:	movzbl %al,%esi
  77fced:	lea    0x390(%rsp),%rdx
  77fcf5:	call   *0x33a825(%rip)        # aba520 <_DYNAMIC+0x6b0>
  77fcfb:	lea    0x1e8(%r14),%rbx
  77fd02:	mov    0x650(%r14),%rax
  77fd09:	test   %rax,%rax
  77fd0c:	je     77fdec <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3d9c>
  77fd12:	mov    0x100(%rax),%rdx
  77fd19:	lea    0x268(%rsp),%rax
  77fd21:	mov    %rax,0x390(%rsp)
  77fd29:	lea    0x2f(%rsp),%rax
  77fd2e:	mov    %rax,0x398(%rsp)
  77fd36:	mov    %rbx,0x3a0(%rsp)
  77fd3e:	lea    0x100(%rsp),%rax
  77fd46:	mov    %rax,0x3a8(%rsp)
  77fd4e:	lea    0x140(%rsp),%rax
  77fd56:	mov    %rax,0x3b0(%rsp)
  77fd5e:	test   %rdx,%rdx
  77fd61:	je     77fdec <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3d9c>
  77fd67:	lea    0x310(%rsp),%rdi
  77fd6f:	lea    0x390(%rsp),%rsi
  77fd77:	call   75de20 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_>
  77fd7c:	mov    0x320(%rsp),%rax
  77fd84:	mov    %rax,0x7a0(%rsp)
  77fd8c:	movups 0x310(%rsp),%xmm0
  77fd94:	movaps %xmm0,0x790(%rsp)
  77fd9c:	jmp    77fdf8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3da8>
  77fd9e:	movaps 0x970(%rsp),%xmm0
  77fda6:	movaps 0x980(%rsp),%xmm1
  77fdae:	movaps 0x990(%rsp),%xmm2
  77fdb6:	mov    0x48(%rsp),%rcx
  77fdbb:	movups %xmm2,0x28(%rcx)
  77fdbf:	movups %xmm1,0x18(%rcx)
  77fdc3:	movups %xmm0,0x8(%rcx)
  77fdc7:	mov    %rax,(%rcx)
  77fdca:	mov    $0x1,%r12b
  77fdcd:	mov    $0x1,%bl
  77fdcf:	mov    $0x1,%r13b
  77fdd2:	mov    $0x1,%bpl
  77fdd5:	mov    $0x1,%r15b
  77fdd8:	cmpq   $0xffffffffffffffff,0x258(%rsp)
  77fde1:	jne    780ce6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c96>
  77fde7:	jmp    780cf6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4ca6>
  77fdec:	movq   $0xffffffffffffffff,0x790(%rsp)
  77fdf8:	mov    %rbx,0x60(%rsp)
  77fdfd:	mov    0x278(%rsp),%rax
  77fe05:	mov    %rax,0x3a0(%rsp)
  77fe0d:	movups 0x268(%rsp),%xmm0
  77fe15:	movaps %xmm0,0x390(%rsp)
  77fe1d:	lea    0x180(%rsp),%rdi
  77fe25:	lea    0x790(%rsp),%rsi
  77fe2d:	lea    0x390(%rsp),%rdx
  77fe35:	call   73d440 <_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime8geometry6RecordEE7or_elseNCNvMsu_B1i_INtB1i_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersE_0EB2E_>
  77fe3a:	cmpb   $0x0,0x76d(%r14)
  77fe42:	je     77fe9f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3e4f>
  77fe44:	lea    0x390(%rsp),%rbx
  77fe4c:	lea    0x970(%rsp),%rsi
  77fe54:	mov    $0x1f0,%edx
  77fe59:	mov    %rbx,%rdi
  77fe5c:	call   *0x33a26e(%rip)        # aba0d0 <memcpy@GLIBC_2.14>
  77fe62:	mov    $0x1,%al
  77fe64:	mov    %eax,0x58(%rsp)
  77fe68:	mov    $0x1,%r12b
  77fe6b:	mov    $0x1,%al
  77fe6d:	mov    %eax,0x38(%rsp)
  77fe71:	mov    $0x1,%al
  77fe73:	mov    %eax,0x30(%rsp)
  77fe77:	mov    $0x1,%r15b
  77fe7a:	mov    $0x1,%bpl
  77fe7d:	movb   $0x1,0xc0(%rsp)
  77fe85:	mov    %rbx,%rdi
  77fe88:	call   *0x33a86a(%rip)        # aba6f8 <_DYNAMIC+0x888>
  77fe8e:	movq   $0x0,0x80(%rsp)
  77fe9a:	jmp    77ff32 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3ee2>
  77fe9f:	lea    0x390(%rsp),%rbx
  77fea7:	lea    0x970(%rsp),%rsi
  77feaf:	mov    $0x1f0,%edx
  77feb4:	mov    %rbx,%rdi
  77feb7:	call   *0x33a213(%rip)        # aba0d0 <memcpy@GLIBC_2.14>
  77febd:	mov    $0x1,%al
  77febf:	mov    %eax,0x58(%rsp)
  77fec3:	mov    $0x1,%r12b
  77fec6:	mov    $0x1,%al
  77fec8:	mov    %eax,0x38(%rsp)
  77fecc:	mov    $0x1,%al
  77fece:	mov    %eax,0x30(%rsp)
  77fed2:	mov    $0x1,%r15b
  77fed5:	mov    $0x1,%bpl
  77fed8:	movb   $0x1,0xc0(%rsp)
  77fee0:	mov    %rbx,%rdi
  77fee3:	call   *0x33a817(%rip)        # aba700 <_DYNAMIC+0x890>
  77fee9:	cmpq   $0xffffffffffffffff,0x5c8(%r14)
  77fef1:	je     77fefc <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3eac>
  77fef3:	mov    0x5e0(%r14),%rsi
  77fefa:	jmp    77fefe <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3eae>
  77fefc:	xor    %esi,%esi
  77fefe:	mov    $0x1,%cl
  77ff00:	mov    %ecx,0x58(%rsp)
  77ff04:	mov    $0x1,%r12b
  77ff07:	mov    $0x1,%cl
  77ff09:	mov    %ecx,0x38(%rsp)
  77ff0d:	mov    $0x1,%cl
  77ff0f:	mov    %ecx,0x30(%rsp)
  77ff13:	mov    $0x1,%r15b
  77ff16:	mov    $0x1,%bpl
  77ff19:	movb   $0x1,0xc0(%rsp)
  77ff21:	mov    %rax,%rdi
  77ff24:	call   *0x33a596(%rip)        # aba4c0 <_DYNAMIC+0x650>
  77ff2a:	mov    %rax,0x80(%rsp)
  77ff32:	mov    0x658(%r14),%rax
  77ff39:	mov    0x668(%r14),%r12
  77ff40:	test   %rax,%rax
  77ff43:	setne  %cl
  77ff46:	test   %r12,%r12
  77ff49:	setne  %dl
  77ff4c:	test   %dl,%cl
  77ff4e:	je     78013e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x40ee>
  77ff54:	mov    0x40(%rsp),%rcx
  77ff59:	mov    0x660(%rcx),%r13
  77ff60:	xor    %r14d,%r14d
  77ff63:	lea    0x390(%rsp),%rbx
  77ff6b:	lea    0x6c0(%rsp),%r15
  77ff73:	jmp    77ff83 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3f33>
  77ff75:	mov    $0x0,%eax
  77ff7a:	dec    %r12
  77ff7d:	je     78013e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x40ee>
  77ff83:	test   %r14,%r14
  77ff86:	jne    780008 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3fb8>
  77ff8c:	test   %r13,%r13
  77ff8f:	je     77ffb7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3f67>
  77ff91:	mov    %r13,%rcx
  77ff94:	mov    %rax,%r14
  77ff97:	and    $0x7,%rcx
  77ff9b:	je     77ffbc <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3f6c>
  77ff9d:	xor    %edx,%edx
  77ff9f:	nop
  77ffa0:	mov    0x590(%r14),%r14
  77ffa7:	inc    %rdx
  77ffaa:	cmp    %rdx,%rcx
  77ffad:	jne    77ffa0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3f50>
  77ffaf:	mov    %r13,%rax
  77ffb2:	sub    %rdx,%rax
  77ffb5:	jmp    77ffbf <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3f6f>
  77ffb7:	mov    %rax,%r14
  77ffba:	jmp    780003 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3fb3>
  77ffbc:	mov    %r13,%rax
  77ffbf:	cmp    $0x8,%r13
  77ffc3:	jb     780003 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3fb3>
  77ffc5:	mov    0x590(%r14),%rcx
  77ffcc:	mov    0x590(%rcx),%rcx
  77ffd3:	mov    0x590(%rcx),%rcx
  77ffda:	mov    0x590(%rcx),%rcx
  77ffe1:	mov    0x590(%rcx),%rcx
  77ffe8:	mov    0x590(%rcx),%rcx
  77ffef:	mov    0x590(%rcx),%rcx
  77fff6:	mov    0x590(%rcx),%r14
  77fffd:	add    $0xfffffffffffffff8,%rax
  780001:	jne    77ffc5 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3f75>
  780003:	xor    %r13d,%r13d
  780006:	xor    %eax,%eax
  780008:	movzwl 0x58a(%r14),%ecx
  780010:	cmp    %rcx,%r13
  780013:	jae    780020 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3fd0>
  780015:	mov    %r13,%rdx
  780018:	mov    %r14,%rcx
  78001b:	jmp    780047 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3ff7>
  78001d:	nopl   (%rax)
  780020:	mov    0x580(%r14),%rcx
  780027:	test   %rcx,%rcx
  78002a:	je     780fd5 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4f85>
  780030:	inc    %rax
  780033:	movzwl 0x588(%r14),%edx
  78003b:	mov    %rcx,%r14
  78003e:	cmp    0x58a(%rcx),%dx
  780045:	jae    780020 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3fd0>
  780047:	test   %rax,%rax
  78004a:	je     78008a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x403a>
  78004c:	lea    (%rcx,%rdx,8),%rsi
  780050:	add    $0x598,%rsi
  780057:	mov    %rax,%rdi
  78005a:	and    $0x7,%rdi
  78005e:	je     780093 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4043>
  780060:	xor    %r8d,%r8d
  780063:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  780070:	mov    (%rsi),%r14
  780073:	lea    0x590(%r14),%rsi
  78007a:	inc    %r8
  78007d:	cmp    %r8,%rdi
  780080:	jne    780070 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4020>
  780082:	mov    %rax,%rdi
  780085:	sub    %r8,%rdi
  780088:	jmp    780096 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4046>
  78008a:	lea    0x1(%rdx),%r13
  78008e:	mov    %rcx,%r14
  780091:	jmp    7800e4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4094>
  780093:	mov    %rax,%rdi
  780096:	cmp    $0x8,%rax
  78009a:	jb     7800e1 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4091>
  78009c:	nopl   0x0(%rax)
  7800a0:	mov    (%rsi),%rax
  7800a3:	mov    0x590(%rax),%rax
  7800aa:	mov    0x590(%rax),%rax
  7800b1:	mov    0x590(%rax),%rax
  7800b8:	mov    0x590(%rax),%rax
  7800bf:	mov    0x590(%rax),%rax
  7800c6:	mov    0x590(%rax),%rax
  7800cd:	mov    0x590(%rax),%r14
  7800d4:	lea    0x590(%r14),%rsi
  7800db:	add    $0xfffffffffffffff8,%rdi
  7800df:	jne    7800a0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4050>
  7800e1:	xor    %r13d,%r13d
  7800e4:	mov    %rdx,%rax
  7800e7:	shl    $0x4,%rax
  7800eb:	cmpl   $0x1,(%rcx,%rax,1)
  7800ef:	jne    77ff75 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3f25>
  7800f5:	imul   $0x70,%rdx,%rdx
  7800f9:	lea    (%rcx,%rdx,1),%rbp
  7800fd:	add    $0xb0,%rbp
  780104:	cmpl   $0x2,0x0(%rbp)
  780108:	jne    77ff75 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3f25>
  78010e:	mov    0x8(%rcx,%rax,1),%rdx
  780113:	mov    %rbx,%rdi
  780116:	mov    %r15,%rsi
  780119:	call   *0x33a549(%rip)        # aba668 <_DYNAMIC+0x7f8>
  78011f:	cmpl   $0x1,0x390(%rsp)
  780127:	jne    77ff75 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3f25>
  78012d:	movups 0x398(%rsp),%xmm0
  780135:	movups %xmm0,0x8(%rbp)
  780139:	jmp    77ff75 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3f25>
  78013e:	mov    0x40(%rsp),%r13
  780143:	mov    0x670(%r13),%r8
  78014a:	mov    0x680(%r13),%rax
  780151:	test   %r8,%r8
  780154:	setne  %cl
  780157:	test   %rax,%rax
  78015a:	setne  %dl
  78015d:	test   %dl,%cl
  78015f:	mov    0xf0(%rsp),%rbx
  780167:	je     78038d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x433d>
  78016d:	mov    0x678(%r13),%rsi
  780174:	xor    %ecx,%ecx
  780176:	jmp    7801a0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4150>
  780178:	mov    $0x1,%r8b
  78017b:	mov    0xf0(%rsp),%rbx
  780183:	dec    %rax
  780186:	shl    $0x5,%rdi
  78018a:	add    %rdi,%rdx
  78018d:	mov    %r8b,0x1c(%rdx)
  780191:	mov    $0x0,%r8d
  780197:	test   %rax,%rax
  78019a:	je     78038d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x433d>
  7801a0:	test   %rcx,%rcx
  7801a3:	jne    780228 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x41d8>
  7801a9:	test   %rsi,%rsi
  7801ac:	je     7801d7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4187>
  7801ae:	mov    %rsi,%rdx
  7801b1:	mov    %r8,%rcx
  7801b4:	and    $0x7,%rdx
  7801b8:	je     7801dc <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x418c>
  7801ba:	xor    %edi,%edi
  7801bc:	nopl   0x0(%rax)
  7801c0:	mov    0x1c8(%rcx),%rcx
  7801c7:	inc    %rdi
  7801ca:	cmp    %rdi,%rdx
  7801cd:	jne    7801c0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4170>
  7801cf:	mov    %rsi,%rdx
  7801d2:	sub    %rdi,%rdx
  7801d5:	jmp    7801df <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x418f>
  7801d7:	mov    %r8,%rcx
  7801da:	jmp    780223 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x41d3>
  7801dc:	mov    %rsi,%rdx
  7801df:	cmp    $0x8,%rsi
  7801e3:	jb     780223 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x41d3>
  7801e5:	mov    0x1c8(%rcx),%rcx
  7801ec:	mov    0x1c8(%rcx),%rcx
  7801f3:	mov    0x1c8(%rcx),%rcx
  7801fa:	mov    0x1c8(%rcx),%rcx
  780201:	mov    0x1c8(%rcx),%rcx
  780208:	mov    0x1c8(%rcx),%rcx
  78020f:	mov    0x1c8(%rcx),%rcx
  780216:	mov    0x1c8(%rcx),%rcx
  78021d:	add    $0xfffffffffffffff8,%rdx
  780221:	jne    7801e5 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4195>
  780223:	xor    %esi,%esi
  780225:	xor    %r8d,%r8d
  780228:	movzwl 0x1c2(%rcx),%edx
  78022f:	cmp    %rdx,%rsi
  780232:	jae    780240 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x41f0>
  780234:	mov    %rsi,%rdi
  780237:	mov    %rcx,%rdx
  78023a:	jmp    780266 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4216>
  78023c:	nopl   0x0(%rax)
  780240:	mov    0x160(%rcx),%rdx
  780247:	test   %rdx,%rdx
  78024a:	je     780fe7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4f97>
  780250:	inc    %r8
  780253:	movzwl 0x1c0(%rcx),%edi
  78025a:	mov    %rdx,%rcx
  78025d:	cmp    0x1c2(%rdx),%di
  780264:	jae    780240 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x41f0>
  780266:	test   %r8,%r8
  780269:	je     7802aa <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x425a>
  78026b:	lea    (%rdx,%rdi,8),%rsi
  78026f:	add    $0x1d0,%rsi
  780276:	mov    %r8,%r9
  780279:	and    $0x7,%r9
  78027d:	je     7802b3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4263>
  78027f:	xor    %r10d,%r10d
  780282:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  780290:	mov    (%rsi),%rcx
  780293:	lea    0x1c8(%rcx),%rsi
  78029a:	inc    %r10
  78029d:	cmp    %r10,%r9
  7802a0:	jne    780290 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4240>
  7802a2:	mov    %r8,%r9
  7802a5:	sub    %r10,%r9
  7802a8:	jmp    7802b6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4266>
  7802aa:	lea    0x1(%rdi),%rsi
  7802ae:	mov    %rdx,%rcx
  7802b1:	jmp    780303 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x42b3>
  7802b3:	mov    %r8,%r9
  7802b6:	cmp    $0x8,%r8
  7802ba:	jb     780301 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x42b1>
  7802bc:	nopl   0x0(%rax)
  7802c0:	mov    (%rsi),%rcx
  7802c3:	mov    0x1c8(%rcx),%rcx
  7802ca:	mov    0x1c8(%rcx),%rcx
  7802d1:	mov    0x1c8(%rcx),%rcx
  7802d8:	mov    0x1c8(%rcx),%rcx
  7802df:	mov    0x1c8(%rcx),%rcx
  7802e6:	mov    0x1c8(%rcx),%rcx
  7802ed:	mov    0x1c8(%rcx),%rcx
  7802f4:	lea    0x1c8(%rcx),%rsi
  7802fb:	add    $0xfffffffffffffff8,%r9
  7802ff:	jne    7802c0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4270>
  780301:	xor    %esi,%esi
  780303:	mov    0x6a8(%rsp),%r8
  78030b:	test   %r8,%r8
  78030e:	je     780385 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4335>
  780310:	mov    0x168(%rdx,%rdi,8),%r9
  780318:	mov    0x6b0(%rsp),%r10
  780320:	movzwl 0x62(%r8),%ebx
  780325:	mov    %ebx,%r14d
  780328:	shl    $0x3,%r14d
  78032c:	mov    $0xffffffffffffffff,%r11
  780333:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  780340:	test   %r14,%r14
  780343:	je     78036d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x431d>
  780345:	cmp    0x10(%r8,%r11,8),%r9
  78034a:	seta   %bpl
  78034e:	sbb    $0x0,%bpl
  780352:	inc    %r11
  780355:	add    $0xfffffffffffffff8,%r14
  780359:	cmp    $0x1,%bpl
  78035d:	je     780340 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x42f0>
  78035f:	movzbl %bpl,%ebx
  780363:	test   %ebx,%ebx
  780365:	je     780178 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4128>
  78036b:	jmp    780370 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4320>
  78036d:	mov    %rbx,%r11
  780370:	mov    0xf0(%rsp),%rbx
  780378:	sub    $0x1,%r10
  78037c:	jb     780385 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4335>
  78037e:	mov    0x68(%r8,%r11,8),%r8
  780383:	jmp    780320 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x42d0>
  780385:	xor    %r8d,%r8d
  780388:	jmp    780183 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4133>
  78038d:	cmpl   $0x2,0xca0(%rsp)
  780395:	mov    $0x1,%bpl
  780398:	je     7803d5 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4385>
  78039a:	lea    0x390(%rsp),%rdi
  7803a2:	lea    0xca0(%rsp),%rsi
  7803aa:	mov    $0x1e8,%edx
  7803af:	call   *0x339d1b(%rip)        # aba0d0 <memcpy@GLIBC_2.14>
  7803b5:	mov    %r13,%rdi
  7803b8:	call   74d2e0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas6canvas6CanvasECs9C2G9YFESsD_29canonical_text_public_control>
  7803bd:	lea    0x390(%rsp),%rsi
  7803c5:	mov    $0x1e8,%edx
  7803ca:	mov    %r13,%rdi
  7803cd:	call   *0x339cfd(%rip)        # aba0d0 <memcpy@GLIBC_2.14>
  7803d3:	xor    %ebp,%ebp
  7803d5:	mov    $0x1,%al
  7803d7:	mov    %eax,0x58(%rsp)
  7803db:	cmpl   $0xffffffff,0x810(%rsp)
  7803e3:	mov    $0x1,%al
  7803e5:	mov    %eax,0x30(%rsp)
  7803e9:	je     780588 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4538>
  7803ef:	movups 0x860(%rsp),%xmm0
  7803f7:	movaps %xmm0,0x760(%rsp)
  7803ff:	movups 0x850(%rsp),%xmm0
  780407:	movaps %xmm0,0x750(%rsp)
  78040f:	movups 0x810(%rsp),%xmm0
  780417:	movups 0x820(%rsp),%xmm1
  78041f:	movups 0x830(%rsp),%xmm2
  780427:	movupd 0x840(%rsp),%xmm3
  780430:	movapd %xmm3,0x740(%rsp)
  780439:	movaps %xmm2,0x730(%rsp)
  780441:	movaps %xmm1,0x720(%rsp)
  780449:	movaps %xmm0,0x710(%rsp)
  780451:	cmpq   $0x0,(%rbx)
  780455:	je     780559 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4509>
  78045b:	mov    0x60(%rsp),%rax
  780460:	mov    %rax,0x390(%rsp)
  780468:	lea    0x100(%rsp),%rax
  780470:	mov    %rax,0x398(%rsp)
  780478:	lea    0x140(%rsp),%rax
  780480:	mov    %rax,0x3a0(%rsp)
  780488:	lea    0x310(%rsp),%rdi
  780490:	lea    0x6c0(%rsp),%rsi
  780498:	lea    0x390(%rsp),%rdx
  7804a0:	call   73fd10 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_>
  7804a5:	lea    0x710(%rsp),%rdi
  7804ad:	call   74e870 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime6scroll14ViewportColumnECs9C2G9YFESsD_29canonical_text_public_control>
  7804b2:	mov    0x320(%rsp),%rax
  7804ba:	mov    %rax,0x720(%rsp)
  7804c2:	movups 0x310(%rsp),%xmm0
  7804ca:	movaps %xmm0,0x710(%rsp)
  7804d2:	mov    (%rbx),%rdi
  7804d5:	cmpl   $0xffffffff,0x60(%rdi)
  7804d9:	je     7804e7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4497>
  7804db:	add    $0x60,%rdi
  7804df:	call   74ec60 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime8metadata5SheetECs9C2G9YFESsD_29canonical_text_public_control>
  7804e4:	mov    (%rbx),%rdi
  7804e7:	movaps 0x760(%rsp),%xmm0
  7804ef:	movups %xmm0,0xb0(%rdi)
  7804f6:	movaps 0x750(%rsp),%xmm0
  7804fe:	movups %xmm0,0xa0(%rdi)
  780505:	movaps 0x710(%rsp),%xmm0
  78050d:	mov    0x720(%rsp),%rax
  780515:	mov    0x728(%rsp),%rcx
  78051d:	movaps 0x730(%rsp),%xmm1
  780525:	movaps 0x740(%rsp),%xmm2
  78052d:	movups %xmm2,0x90(%rdi)
  780534:	movups %xmm1,0x80(%rdi)
  78053b:	mov    %rax,0x70(%rdi)
  78053f:	mov    %rcx,0x78(%rdi)
  780543:	movups %xmm0,0x60(%rdi)
  780547:	movl   $0x0,0x58(%rsp)
  78054f:	movl   $0x0,0x30(%rsp)
  780557:	jmp    780588 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4538>
  780559:	mov    $0x1,%al
  78055b:	mov    %eax,0x58(%rsp)
  78055f:	movl   $0x0,0x30(%rsp)
  780567:	lea    0x710(%rsp),%rdi
  78056f:	mov    $0x1,%r12b
  780572:	mov    $0x1,%al
  780574:	mov    %eax,0x38(%rsp)
  780578:	mov    $0x1,%r15b
  78057b:	movb   $0x1,0xc0(%rsp)
  780583:	call   74ec60 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime8metadata5SheetECs9C2G9YFESsD_29canonical_text_public_control>
  780588:	mov    0x180(%rsp),%r15
  780590:	cmp    $0xffffffffffffffff,%r15
  780594:	sete   0xc0(%rsp)
  78059c:	je     7805ff <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x45af>
  78059e:	mov    0x188(%rsp),%r13
  7805a6:	mov    0x190(%rsp),%r14
  7805ae:	mov    %rbx,%rdi
  7805b1:	call   73d650 <_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionINtNtCscdodAO9FK5_5alloc5boxed3BoxNtNtNtCslbxve4rcJus_4gpui7runtime8metadata8MetadataEE18get_or_insert_withNvYBI_NtNtB5_7default7Default7defaultECs9C2G9YFESsD_29canonical_text_public_control>
  7805b6:	mov    %rbx,%rax
  7805b9:	mov    $0x100,%ebx
  7805be:	add    (%rax),%rbx
  7805c1:	mov    %rbx,%rdi
  7805c4:	call   73d4b0 <_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionINtNtCscdodAO9FK5_5alloc5boxed3BoxNtNtNtCslbxve4rcJus_4gpui7runtime8geometry8GeometryEE18get_or_insert_withNvYBI_NtNtB5_7default7Default7defaultECs9C2G9YFESsD_29canonical_text_public_control>
  7805c9:	mov    (%rbx),%rdi
  7805cc:	mov    %r15,0x390(%rsp)
  7805d4:	mov    %r13,0x398(%rsp)
  7805dc:	mov    %r14,0x3a0(%rsp)
  7805e4:	lea    0x390(%rsp),%rsi
  7805ec:	call   *0x33a116(%rip)        # aba708 <_DYNAMIC+0x898>
  7805f2:	mov    0x40(%rsp),%r13
  7805f7:	mov    0xf0(%rsp),%rbx
  7805ff:	cmpq   $0xffffffffffffffff,0x258(%rsp)
  780608:	je     780639 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x45e9>
  78060a:	mov    0x2d8(%rsp),%rax
  780612:	mov    (%rax),%rdi
  780615:	test   %rdi,%rdi
  780618:	je     780fb7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4f67>
  78061e:	lea    0x8b8(%rsp),%rdx
  780626:	mov    0x260(%rsp),%rsi
  78062e:	call   *0x33a0dc(%rip)        # aba710 <_DYNAMIC+0x8a0>
  780634:	xor    %r14d,%r14d
  780637:	jmp    78063c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x45ec>
  780639:	mov    $0x1,%r14b
  78063c:	mov    0xa8(%rsp),%rax
  780644:	cmpl   $0x3,(%rax)
  780647:	jne    780658 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4608>
  780649:	mov    0x208(%r13),%rax
  780650:	movq   $0x0,0x58(%rax)
  780658:	mov    (%rbx),%rax
  78065b:	test   %rax,%rax
  78065e:	je     7806a7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4657>
  780660:	mov    0xe0(%rax),%rax
  780667:	test   %rax,%rax
  78066a:	je     7806a7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4657>
  78066c:	mov    0x678(%rsp),%rcx
  780674:	mov    %rcx,0x40(%rax)
  780678:	mov    0x2e8(%rsp),%rcx
  780680:	mov    %rcx,0x48(%rax)
  780684:	mov    0x2f0(%rsp),%ecx
  78068b:	mov    %ecx,0x50(%rax)
  78068e:	movzbl 0x57(%rsp),%ecx
  780693:	mov    %cl,0x54(%rax)
  780696:	movzwl 0x7a(%rsp),%ecx
  78069b:	mov    %cx,0x55(%rax)
  78069f:	movzbl 0x7c(%rsp),%ecx
  7806a4:	mov    %cl,0x57(%rax)
  7806a7:	mov    0x6e8(%r13),%rdi
  7806ae:	test   %rdi,%rdi
  7806b1:	mov    %r14d,0x38(%rsp)
  7806b6:	je     7806ec <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x469c>
  7806b8:	cmpq   $0xffffffffffffffff,0x18(%rdi)
  7806bd:	je     7806cf <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x467f>
  7806bf:	add    $0x18,%rdi
  7806c3:	call   747910 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime13text_geometry5EntryEECs9C2G9YFESsD_29canonical_text_public_control>
  7806c8:	mov    0x6e8(%r13),%rdi
  7806cf:	mov    0x210(%rsp),%rax
  7806d7:	mov    %rax,0x28(%rdi)
  7806db:	movups 0x200(%rsp),%xmm0
  7806e3:	movups %xmm0,0x18(%rdi)
  7806e7:	xor    %r12d,%r12d
  7806ea:	jmp    7806ef <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x469f>
  7806ec:	mov    $0x1,%r12b
  7806ef:	mov    0x150(%rsp),%rax
  7806f7:	mov    %rax,0x3a0(%rsp)
  7806ff:	movups 0x140(%rsp),%xmm0
  780707:	movaps %xmm0,0x390(%rsp)
  78070f:	lea    0x5c8(%r13),%r15
  780716:	cmpq   $0xffffffffffffffff,0x5c8(%r13)
  78071e:	je     780728 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x46d8>
  780720:	mov    %r15,%rdi
  780723:	call   7474b0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCslbxve4rcJus_4gpui7runtime9PresentedEECs9C2G9YFESsD_29canonical_text_public_control>
  780728:	mov    0x3a0(%rsp),%rax
  780730:	mov    %rax,0x10(%r15)
  780734:	movaps 0x390(%rsp),%xmm0
  78073c:	movups %xmm0,(%r15)
  780740:	mov    0x80(%rsp),%rax
  780748:	mov    %rax,0x5e0(%r13)
  78074f:	mov    0xf8(%rsp),%rax
  780757:	mov    %ax,0x5e8(%r13)
  78075f:	mov    0x2e0(%rsp),%rax
  780767:	mov    %ax,0x5ea(%r13)
  78076f:	movss  0x9c(%rsp),%xmm0
  780778:	movss  %xmm0,0x5ec(%r13)
  780781:	xor    %r15d,%r15d
  780784:	mov    %r13,%rdi
  780787:	call   76f480 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11prune_focusBW_>
  78078c:	mov    0x680(%rsp),%rax
  780794:	mov    %rax,0x6d0(%r13)
  78079b:	mov    0x260(%rsp),%rax
  7807a3:	mov    %rax,0x6d8(%r13)
  7807aa:	mov    0x6a0(%r13),%rax
  7807b1:	mov    0x6e8(%r13),%rdi
  7807b8:	mov    %rax,0x6e0(%r13)
  7807bf:	mov    0x8b0(%rsp),%rax
  7807c7:	mov    %rax,0x5f8(%r13)
  7807ce:	cmpq   $0x0,0x2f8(%r13)
  7807d6:	setne  %al
  7807d9:	test   %rdi,%rdi
  7807dc:	sete   %cl
  7807df:	or     %al,%cl
  7807e1:	cmp    $0x1,%cl
  7807e4:	je     7807fe <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x47ae>
  7807e6:	add    $0x30,%rdi
  7807ea:	call   745fc0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtCsghYClfd3M9V_11gpui_canvas4text10TextSystemEECs9C2G9YFESsD_29canonical_text_public_control>
  7807ef:	mov    0x6e8(%r13),%rax
  7807f6:	movq   $0x0,0x30(%rax)
  7807fe:	movb   $0x0,0x76b(%r13)
  780806:	movw   $0x0,0x768(%r13)
  780810:	lea    0x688(%r13),%rdi
  780817:	xor    %r15d,%r15d
  78081a:	call   776590 <_RNvMsh_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapyNtNtB7_7set_val9SetValZSTE5clearCs9C2G9YFESsD_29canonical_text_public_control>
  78081f:	cmpb   $0x0,0x76d(%r13)
  780827:	je     78085e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x480e>
  780829:	xor    %r15d,%r15d
  78082c:	lea    0x390(%rsp),%rdi
  780834:	mov    %r13,%rsi
  780837:	mov    0x680(%rsp),%rdx
  78083f:	mov    0x260(%rsp),%rcx
  780847:	call   77ba20 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_>
  78084c:	mov    0x390(%rsp),%rax
  780854:	cmp    $0xfffffffffffffffe,%rax
  780858:	jne    780996 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4946>
  78085e:	mov    0x48(%rsp),%rax
  780863:	movq   $0xfffffffffffffffe,(%rax)
  78086a:	cmpb   $0x0,0x58(%rsp)
  78086f:	je     78087e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x482e>
  780871:	lea    0x6c0(%rsp),%rdi
  780879:	call   74e820 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime6scroll13ViewportBuildECs9C2G9YFESsD_29canonical_text_public_control>
  78087e:	xor    %r13d,%r13d
  780881:	lea    0x6a8(%rsp),%rdi
  780889:	call   74aec0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtCscdodAO9FK5_5alloc11collections5btree3set8BTreeSetNtNtCslbxve4rcJus_4gpui4list6ListIdEECs9C2G9YFESsD_29canonical_text_public_control>
  78088e:	mov    0x100(%rsp),%rsi
  780896:	test   %rsi,%rsi
  780899:	je     7808b2 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4862>
  78089b:	mov    0x108(%rsp),%rdi
  7808a3:	shl    $0x2,%rsi
  7808a7:	mov    $0x4,%edx
  7808ac:	call   *0x3397fe(%rip)        # aba0b0 <_DYNAMIC+0x240>
  7808b2:	mov    0x158(%rsp),%rsi
  7808ba:	test   %rsi,%rsi
  7808bd:	je     7808d2 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4882>
  7808bf:	mov    0x160(%rsp),%rdi
  7808c7:	mov    $0x1,%edx
  7808cc:	call   *0x3397de(%rip)        # aba0b0 <_DYNAMIC+0x240>
  7808d2:	mov    0x230(%rsp),%rsi
  7808da:	test   %rsi,%rsi
  7808dd:	je     7808f6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x48a6>
  7808df:	mov    0x238(%rsp),%rdi
  7808e7:	shl    $0x4,%rsi
  7808eb:	mov    $0x4,%edx
  7808f0:	call   *0x3397ba(%rip)        # aba0b0 <_DYNAMIC+0x240>
  7808f6:	mov    0x218(%rsp),%rsi
  7808fe:	test   %rsi,%rsi
  780901:	je     78091a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x48ca>
  780903:	mov    0x220(%rsp),%rdi
  78090b:	shl    $0x4,%rsi
  78090f:	mov    $0x4,%edx
  780914:	call   *0x339796(%rip)        # aba0b0 <_DYNAMIC+0x240>
  78091a:	mov    0x1d8(%rsp),%rax
  780922:	test   %rax,%rax
  780925:	je     78093e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x48ee>
  780927:	mov    0x1e0(%rsp),%rdi
  78092f:	imul   $0x38,%rax,%rsi
  780933:	mov    $0x8,%edx
  780938:	call   *0x339772(%rip)        # aba0b0 <_DYNAMIC+0x240>
  78093e:	cmpq   $0x0,0x1c0(%rsp)
  780947:	je     780956 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4906>
  780949:	mov    0x1c8(%rsp),%rdi
  780951:	call   74cd40 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text10TextShaperECs9C2G9YFESsD_29canonical_text_public_control>
  780956:	test   %r12b,%r12b
  780959:	je     780968 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4918>
  78095b:	lea    0x200(%rsp),%rdi
  780963:	call   747910 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime13text_geometry5EntryEECs9C2G9YFESsD_29canonical_text_public_control>
  780968:	mov    0xd0(%rsp),%rax
  780970:	test   %rax,%rax
  780973:	je     77d891 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1841>
  780979:	lock decq (%rax)
  78097d:	jne    77d891 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1841>
  780983:	lea    0xd0(%rsp),%rdi
  78098b:	call   *0x33980f(%rip)        # aba1a0 <_DYNAMIC+0x330>
  780991:	jmp    77d891 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1841>
  780996:	mov    0x3b8(%rsp),%rcx
  78099e:	movzbl 0x3c0(%rsp),%edx
  7809a6:	mov    0x3c1(%rsp),%esi
  7809ad:	mov    %esi,0x310(%rsp)
  7809b4:	mov    0x3c4(%rsp),%esi
  7809bb:	mov    %esi,0x313(%rsp)
  7809c2:	movups 0x398(%rsp),%xmm0
  7809ca:	movups 0x3a8(%rsp),%xmm1
  7809d2:	mov    0x310(%rsp),%esi
  7809d9:	mov    0x313(%rsp),%edi
  7809e0:	mov    0x48(%rsp),%r8
  7809e5:	mov    %edi,0x34(%r8)
  7809e9:	mov    %esi,0x31(%r8)
  7809ed:	mov    %rax,(%r8)
  7809f0:	movups %xmm0,0x8(%r8)
  7809f5:	movups %xmm1,0x18(%r8)
  7809fa:	mov    %rcx,0x28(%r8)
  7809fe:	mov    %dl,0x30(%r8)
  780a02:	xor    %r13d,%r13d
  780a05:	cmpb   $0x0,0x58(%rsp)
  780a0a:	mov    0x30(%rsp),%ebx
  780a0e:	mov    0x38(%rsp),%r14d
  780a13:	jne    780cc5 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c75>
  780a19:	jmp    780cd2 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c82>
  780a1e:	movzbl 0x391(%rsp),%eax
  780a26:	mov    0x48(%rsp),%rcx
  780a2b:	movq   $0x22,(%rcx)
  780a32:	mov    %al,0x8(%rcx)
  780a35:	jmp    780caa <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c5a>
  780a3a:	mov    0x48(%rsp),%rax
  780a3f:	movq   $0x1f,(%rax)
  780a46:	jmp    77d891 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1841>
  780a4b:	lea    0x394(%rsp),%rcx
  780a53:	mov    0x14(%rcx),%rax
  780a57:	movups 0x4(%rcx),%xmm0
  780a5b:	movaps %xmm0,0x120(%rsp)
  780a63:	mov    %rax,0x130(%rsp)
  780a6b:	mov    0x48(%rsp),%rcx
  780a70:	mov    %rax,0x18(%rcx)
  780a74:	movups %xmm0,0x8(%rcx)
  780a78:	movq   $0x23,(%rcx)
  780a7f:	jmp    780caa <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c5a>
  780a84:	mov    0x48(%rsp),%rcx
  780a89:	movq   $0x23,(%rcx)
  780a90:	mov    %eax,0x8(%rcx)
  780a93:	mov    %edx,0xc(%rcx)
  780a96:	jmp    780caa <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c5a>
  780a9b:	mov    0x3c0(%rsp),%rcx
  780aa3:	mov    0x48(%rsp),%rdx
  780aa8:	mov    %rcx,0x30(%rdx)
  780aac:	movups 0x3a0(%rsp),%xmm0
  780ab4:	movups 0x3b0(%rsp),%xmm1
  780abc:	movups %xmm1,0x20(%rdx)
  780ac0:	movups %xmm0,0x10(%rdx)
  780ac4:	mov    %rax,(%rdx)
  780ac7:	mov    %r15,0x8(%rdx)
  780acb:	jmp    780caa <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c5a>
  780ad0:	mov    0x3c0(%rsp),%rax
  780ad8:	mov    0x48(%rsp),%rcx
  780add:	mov    %rax,0x30(%rcx)
  780ae1:	movups 0x390(%rsp),%xmm0
  780ae9:	movups 0x3a0(%rsp),%xmm1
  780af1:	movups 0x3b0(%rsp),%xmm2
  780af9:	movups %xmm2,0x20(%rcx)
  780afd:	movups %xmm1,0x10(%rcx)
  780b01:	movups %xmm0,(%rcx)
  780b04:	jmp    780caa <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c5a>
  780b09:	mov    0x30(%rsp),%rax
  780b0e:	mov    0x20(%rax,%r13,1),%esi
  780b13:	lea    0x390(%rsp),%rdi
  780b1b:	lea    0x8d0(%rsp),%rdx
  780b23:	call   75e3d0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersn_0BQ_>
  780b28:	mov    0x3c0(%rsp),%rax
  780b30:	mov    %rax,0x900(%rsp)
  780b38:	movups 0x390(%rsp),%xmm0
  780b40:	movups 0x3a0(%rsp),%xmm1
  780b48:	movups 0x3b0(%rsp),%xmm2
  780b50:	movaps %xmm2,0x8f0(%rsp)
  780b58:	movaps %xmm1,0x8e0(%rsp)
  780b60:	movaps %xmm0,0x8d0(%rsp)
  780b68:	mov    0x8d0(%rsp),%rax
  780b70:	mov    0x8f8(%rsp),%rcx
  780b78:	mov    0x48(%rsp),%rdx
  780b7d:	mov    %rcx,0x28(%rdx)
  780b81:	mov    0x900(%rsp),%rcx
  780b89:	mov    %rcx,0x30(%rdx)
  780b8d:	lea    0x8d8(%rsp),%rcx
  780b95:	movups (%rcx),%xmm0
  780b98:	movups 0x10(%rcx),%xmm1
  780b9c:	movups %xmm0,0x8(%rdx)
  780ba0:	movups %xmm1,0x18(%rdx)
  780ba4:	mov    %rax,(%rdx)
  780ba7:	jmp    780caa <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c5a>
  780bac:	mov    0x48(%rsp),%rcx
  780bb1:	movq   $0x23,(%rcx)
  780bb8:	mov    %eax,0x8(%rcx)
  780bbb:	mov    %edx,0xc(%rcx)
  780bbe:	jmp    780c8e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c3e>
  780bc3:	lea    0x394(%rsp),%rcx
  780bcb:	mov    0x14(%rcx),%rax
  780bcf:	movups 0x4(%rcx),%xmm0
  780bd3:	movaps %xmm0,0x120(%rsp)
  780bdb:	mov    %rax,0x130(%rsp)
  780be3:	mov    0x48(%rsp),%rcx
  780be8:	mov    %rax,0x18(%rcx)
  780bec:	movups %xmm0,0x8(%rcx)
  780bf0:	movq   $0x23,(%rcx)
  780bf7:	jmp    780c8e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c3e>
  780bfc:	lea    0x394(%rsp),%rcx
  780c04:	mov    0x14(%rcx),%rax
  780c08:	movups 0x4(%rcx),%xmm0
  780c0c:	movaps %xmm0,0x120(%rsp)
  780c14:	mov    %rax,0x130(%rsp)
  780c1c:	mov    0x48(%rsp),%rcx
  780c21:	mov    %rax,0x18(%rcx)
  780c25:	movups %xmm0,0x8(%rcx)
  780c29:	movq   $0x23,(%rcx)
  780c30:	jmp    780c44 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4bf4>
  780c32:	mov    0x48(%rsp),%rcx
  780c37:	movq   $0x23,(%rcx)
  780c3e:	mov    %eax,0x8(%rcx)
  780c41:	mov    %edx,0xc(%rcx)
  780c44:	mov    0x1f8(%rsp),%rax
  780c4c:	test   %rax,%rax
  780c4f:	je     780caa <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c5a>
  780c51:	lock decq (%rax)
  780c55:	jne    780caa <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c5a>
  780c57:	lea    0x1f8(%rsp),%rdi
  780c5f:	call   *0x33956b(%rip)        # aba1d0 <_DYNAMIC+0x360>
  780c65:	jmp    780caa <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c5a>
  780c67:	mov    0x48(%rsp),%rax
  780c6c:	movq   $0x18,(%rax)
  780c73:	jmp    780c8e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c3e>
  780c75:	mov    0x124(%rsp),%ecx
  780c7c:	mov    0x48(%rsp),%rdx
  780c81:	movq   $0x23,(%rdx)
  780c88:	mov    %eax,0x8(%rdx)
  780c8b:	mov    %ecx,0xc(%rdx)
  780c8e:	mov    0x300(%rsp),%rax
  780c96:	lock decq (%rax)
  780c9a:	jne    780caa <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c5a>
  780c9c:	lea    0x300(%rsp),%rdi
  780ca4:	call   *0x339526(%rip)        # aba1d0 <_DYNAMIC+0x360>
  780caa:	lea    0x970(%rsp),%rdi
  780cb2:	call   74d2e0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas6canvas6CanvasECs9C2G9YFESsD_29canonical_text_public_control>
  780cb7:	mov    $0x1,%r12b
  780cba:	mov    $0x1,%r14b
  780cbd:	mov    $0x1,%bl
  780cbf:	mov    $0x1,%r13b
  780cc2:	mov    $0x1,%bpl
  780cc5:	lea    0x6c0(%rsp),%rdi
  780ccd:	call   74e820 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime6scroll13ViewportBuildECs9C2G9YFESsD_29canonical_text_public_control>
  780cd2:	cmpq   $0xffffffffffffffff,0x258(%rsp)
  780cdb:	setne  %al
  780cde:	mov    %r13d,%r15d
  780ce1:	test   %r14b,%al
  780ce4:	je     780cf6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4ca6>
  780ce6:	lea    0x8b8(%rsp),%rdi
  780cee:	call   7470f0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCsghYClfd3M9V_11gpui_canvas5image5ImageEECs9C2G9YFESsD_29canonical_text_public_control>
  780cf3:	mov    %r15d,%r13d
  780cf6:	cmpl   $0xffffffff,0x810(%rsp)
  780cfe:	je     780d11 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4cc1>
  780d00:	test   %bl,%bl
  780d02:	je     780d11 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4cc1>
  780d04:	lea    0x810(%rsp),%rdi
  780d0c:	call   74ec60 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime8metadata5SheetECs9C2G9YFESsD_29canonical_text_public_control>
  780d11:	lea    0x6a8(%rsp),%rdi
  780d19:	call   74aec0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtCscdodAO9FK5_5alloc11collections5btree3set8BTreeSetNtNtCslbxve4rcJus_4gpui4list6ListIdEECs9C2G9YFESsD_29canonical_text_public_control>
  780d1e:	mov    0x100(%rsp),%rsi
  780d26:	test   %rsi,%rsi
  780d29:	je     780d42 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4cf2>
  780d2b:	mov    0x108(%rsp),%rdi
  780d33:	shl    $0x2,%rsi
  780d37:	mov    $0x4,%edx
  780d3c:	call   *0x33936e(%rip)        # aba0b0 <_DYNAMIC+0x240>
  780d42:	mov    0x158(%rsp),%rsi
  780d4a:	test   %rsi,%rsi
  780d4d:	je     780d62 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4d12>
  780d4f:	mov    0x160(%rsp),%rdi
  780d57:	mov    $0x1,%edx
  780d5c:	call   *0x33934e(%rip)        # aba0b0 <_DYNAMIC+0x240>
  780d62:	mov    0x230(%rsp),%rsi
  780d6a:	test   %rsi,%rsi
  780d6d:	je     780d86 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4d36>
  780d6f:	mov    0x238(%rsp),%rdi
  780d77:	shl    $0x4,%rsi
  780d7b:	mov    $0x4,%edx
  780d80:	call   *0x33932a(%rip)        # aba0b0 <_DYNAMIC+0x240>
  780d86:	mov    0x218(%rsp),%rsi
  780d8e:	test   %rsi,%rsi
  780d91:	je     780daa <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4d5a>
  780d93:	mov    0x220(%rsp),%rdi
  780d9b:	shl    $0x4,%rsi
  780d9f:	mov    $0x4,%edx
  780da4:	call   *0x339306(%rip)        # aba0b0 <_DYNAMIC+0x240>
  780daa:	mov    0x1d8(%rsp),%rax
  780db2:	test   %rax,%rax
  780db5:	je     780dce <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4d7e>
  780db7:	mov    0x1e0(%rsp),%rdi
  780dbf:	imul   $0x38,%rax,%rsi
  780dc3:	mov    $0x8,%edx
  780dc8:	call   *0x3392e2(%rip)        # aba0b0 <_DYNAMIC+0x240>
  780dce:	test   %r13b,%r13b
  780dd1:	je     780e04 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4db4>
  780dd3:	mov    0x268(%rsp),%rsi
  780ddb:	test   %rsi,%rsi
  780dde:	je     780df7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4da7>
  780de0:	mov    0x270(%rsp),%rdi
  780de8:	shl    $0x4,%rsi
  780dec:	mov    $0x4,%edx
  780df1:	call   *0x3392b9(%rip)        # aba0b0 <_DYNAMIC+0x240>
  780df7:	lea    0x140(%rsp),%rdi
  780dff:	call   7474b0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCslbxve4rcJus_4gpui7runtime9PresentedEECs9C2G9YFESsD_29canonical_text_public_control>
  780e04:	mov    0x7c8(%rsp),%rax
  780e0c:	cmp    $0xfffffffffffffffe,%rax
  780e10:	jne    77d461 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1411>
  780e16:	jmp    77d82a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17da>
  780e1b:	lea    -0x6ae4da(%rip),%rdi        # d2948 <GCC_except_table0+0x1057c>
  780e22:	lea    0x31a5c7(%rip),%rdx        # a9b3f0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1aa8>
  780e29:	mov    $0x83,%esi
  780e2e:	call   *0x3392b4(%rip)        # aba0e8 <_DYNAMIC+0x278>
  780e34:	jmp    7811d8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  780e39:	lea    -0x6ae778(%rip),%rdi        # d26c8 <GCC_except_table0+0x102fc>
  780e40:	lea    0x31a0d9(%rip),%rdx        # a9af20 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x15d8>
  780e47:	mov    $0x1c,%esi
  780e4c:	call   *0x339336(%rip)        # aba188 <_DYNAMIC+0x318>
  780e52:	jmp    7811d8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  780e57:	mov    $0x1,%bpl
  780e5a:	mov    $0x8,%edi
  780e5f:	mov    $0x78,%esi
  780e64:	call   *0x33925e(%rip)        # aba0c8 <_DYNAMIC+0x258>
  780e6a:	jmp    7811d8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  780e6f:	lea    0x319322(%rip),%rdi        # a9a198 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x850>
  780e76:	call   *0x3392f4(%rip)        # aba170 <_DYNAMIC+0x300>
  780e7c:	jmp    7811d8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  780e81:	lea    -0x6ae4ff(%rip),%rax        # d2989 <GCC_except_table0+0x105bd>
  780e88:	mov    %rax,0x250(%rsp)
  780e90:	lea    0x31a711(%rip),%rax        # a9b5a8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1c60>
  780e97:	jmp    780ee3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4e93>
  780e99:	lea    0x319448(%rip),%rax        # a9a2e8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x9a0>
  780ea0:	mov    %rax,0x658(%rsp)
  780ea8:	mov    0x658(%rsp),%rdi
  780eb0:	call   *0x3392ba(%rip)        # aba170 <_DYNAMIC+0x300>
  780eb6:	jmp    7811d8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  780ebb:	lea    0x3192d6(%rip),%rdi        # a9a198 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x850>
  780ec2:	call   *0x3392a8(%rip)        # aba170 <_DYNAMIC+0x300>
  780ec8:	jmp    7811d8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  780ecd:	lea    -0x6ae54b(%rip),%rax        # d2989 <GCC_except_table0+0x105bd>
  780ed4:	mov    %rax,0x250(%rsp)
  780edc:	lea    0x31a6dd(%rip),%rax        # a9b5c0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1c78>
  780ee3:	mov    %rax,0x248(%rsp)
  780eeb:	jmp    780f67 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4f17>
  780eed:	mov    0x3a0(%rsp),%rsi
  780ef5:	mov    $0x1,%bpl
  780ef8:	call   *0x339262(%rip)        # aba160 <_DYNAMIC+0x2f0>
  780efe:	jmp    7811d8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  780f03:	mov    0x3a0(%rsp),%rsi
  780f0b:	call   *0x33924f(%rip)        # aba160 <_DYNAMIC+0x2f0>
  780f11:	jmp    7811d8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  780f16:	mov    0x3a0(%rsp),%rsi
  780f1e:	call   *0x33923c(%rip)        # aba160 <_DYNAMIC+0x2f0>
  780f24:	jmp    7811d8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  780f29:	mov    0x3a0(%rsp),%rsi
  780f31:	call   *0x339229(%rip)        # aba160 <_DYNAMIC+0x2f0>
  780f37:	jmp    7811d8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  780f3c:	mov    0x3a0(%rsp),%rsi
  780f44:	call   *0x339216(%rip)        # aba160 <_DYNAMIC+0x2f0>
  780f4a:	jmp    7811d8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  780f4f:	mov    0x3a0(%rsp),%rsi
  780f57:	call   *0x339203(%rip)        # aba160 <_DYNAMIC+0x2f0>
  780f5d:	jmp    7811d8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  780f62:	mov    $0x1f,%esi
  780f67:	mov    0x250(%rsp),%rdi
  780f6f:	mov    0x248(%rsp),%rdx
  780f77:	call   *0x33920b(%rip)        # aba188 <_DYNAMIC+0x318>
  780f7d:	jmp    7811d8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  780f82:	lea    -0x6ae641(%rip),%rdi        # d2948 <GCC_except_table0+0x1057c>
  780f89:	lea    0x31a460(%rip),%rdx        # a9b3f0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1aa8>
  780f90:	mov    $0x83,%esi
  780f95:	call   *0x33914d(%rip)        # aba0e8 <_DYNAMIC+0x278>
  780f9b:	jmp    7811d8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  780fa0:	movb   $0x1,0x60(%rsp)
  780fa5:	lea    0x31a644(%rip),%rdi        # a9b5f0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1ca8>
  780fac:	call   *0x3391be(%rip)        # aba170 <_DYNAMIC+0x300>
  780fb2:	jmp    7811d8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  780fb7:	lea    0x31a55a(%rip),%rdi        # a9b518 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1bd0>
  780fbe:	call   *0x3391ac(%rip)        # aba170 <_DYNAMIC+0x300>
  780fc4:	jmp    7811d8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  780fc9:	lea    0x319210(%rip),%rax        # a9a1e0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x898>
  780fd0:	jmp    78105f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x500f>
  780fd5:	lea    0x3191d4(%rip),%rdi        # a9a1b0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x868>
  780fdc:	call   *0x33918e(%rip)        # aba170 <_DYNAMIC+0x300>
  780fe2:	jmp    7811d8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  780fe7:	lea    0x3191c2(%rip),%rdi        # a9a1b0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x868>
  780fee:	call   *0x33917c(%rip)        # aba170 <_DYNAMIC+0x300>
  780ff4:	jmp    7811d8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  780ff9:	lea    0x31a490(%rip),%rax        # a9b490 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1b48>
  781000:	jmp    78105f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x500f>
  781002:	lea    0x31a49f(%rip),%rax        # a9b4a8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1b60>
  781009:	jmp    78105f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x500f>
  78100b:	lea    0x319d0e(%rip),%rax        # a9ad20 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x13d8>
  781012:	jmp    78105f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x500f>
  781014:	lea    0x319ced(%rip),%rax        # a9ad08 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x13c0>
  78101b:	jmp    78105f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x500f>
  78101d:	mov    %rbp,%r12
  781020:	lea    0x319cf9(%rip),%rax        # a9ad20 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x13d8>
  781027:	jmp    78105f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x500f>
  781029:	mov    %rax,%r12
  78102c:	jmp    781058 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5008>
  78102e:	mov    %rbp,%r12
  781031:	lea    0x319cd0(%rip),%rax        # a9ad08 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x13c0>
  781038:	jmp    78105f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x500f>
  78103a:	mov    %rax,%r13
  78103d:	lea    0x319cc4(%rip),%rax        # a9ad08 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x13c0>
  781044:	jmp    78105f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x500f>
  781046:	mov    %rax,%r13
  781049:	lea    0x319cd0(%rip),%rax        # a9ad20 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x13d8>
  781050:	jmp    78105f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x500f>
  781052:	mov    %rcx,%r12
  781055:	mov    %rax,%r13
  781058:	lea    0x319cd9(%rip),%rax        # a9ad38 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x13f0>
  78105f:	mov    %rax,0x80(%rsp)
  781067:	mov    %r12,%rdi
  78106a:	mov    %r13,%rsi
  78106d:	mov    0x80(%rsp),%rdx
  781075:	call   *0x339065(%rip)        # aba0e0 <_DYNAMIC+0x270>
  78107b:	jmp    7811d8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  781080:	mov    $0x1,%r12b
  781083:	lea    0x31a44e(%rip),%rdx        # a9b4d8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1b90>
  78108a:	mov    $0x1,%bpl
  78108d:	xor    %edi,%edi
  78108f:	xor    %esi,%esi
  781091:	call   *0x339049(%rip)        # aba0e0 <_DYNAMIC+0x270>
  781097:	jmp    7811d8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  78109c:	lea    -0x6ae75b(%rip),%rdi        # d2948 <GCC_except_table0+0x1057c>
  7810a3:	lea    0x31a346(%rip),%rdx        # a9b3f0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1aa8>
  7810aa:	mov    $0x83,%esi
  7810af:	call   *0x339033(%rip)        # aba0e8 <_DYNAMIC+0x278>
  7810b5:	jmp    7811d8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  7810ba:	movb   $0x1,0x60(%rsp)
  7810bf:	lea    -0x6ae77e(%rip),%rdi        # d2948 <GCC_except_table0+0x1057c>
  7810c6:	lea    0x31a323(%rip),%rdx        # a9b3f0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1aa8>
  7810cd:	mov    $0x83,%esi
  7810d2:	call   *0x339010(%rip)        # aba0e8 <_DYNAMIC+0x278>
  7810d8:	jmp    7811d8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  7810dd:	mov    %rsi,%rax
  7810e0:	lea    0x31a479(%rip),%rcx        # a9b560 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1c18>
  7810e7:	jmp    781198 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5148>
  7810ec:	mov    %rsi,%rax
  7810ef:	lea    0x31a482(%rip),%rcx        # a9b578 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1c30>
  7810f6:	jmp    781198 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5148>
  7810fb:	mov    %rsi,%rax
  7810fe:	lea    0x31a48b(%rip),%rcx        # a9b590 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1c48>
  781105:	jmp    781198 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5148>
  78110a:	mov    %rbx,0x38(%rsp)
  78110f:	mov    %rsi,%rax
  781112:	lea    0x31919f(%rip),%rcx        # a9a2b8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x970>
  781119:	jmp    781198 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5148>
  78111b:	mov    %rcx,0x38(%rsp)
  781120:	lea    0x3191a9(%rip),%rcx        # a9a2d0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x988>
  781127:	jmp    781198 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5148>
  781129:	mov    %rdx,0x38(%rsp)
  78112e:	lea    0x3191cb(%rip),%rcx        # a9a300 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x9b8>
  781135:	jmp    781198 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5148>
  781137:	mov    %rdx,0x38(%rsp)
  78113c:	lea    0x3191d5(%rip),%rcx        # a9a318 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x9d0>
  781143:	jmp    781198 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5148>
  781145:	lea    0x3191fc(%rip),%rax        # a9a348 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xa00>
  78114c:	mov    %rax,0x650(%rsp)
  781154:	movb   $0x1,0x60(%rsp)
  781159:	mov    %rbx,%rdi
  78115c:	mov    0x650(%rsp),%rdx
  781164:	call   *0x338f76(%rip)        # aba0e0 <_DYNAMIC+0x270>
  78116a:	jmp    7811d8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  78116c:	lea    0x319bad(%rip),%rcx        # a9ad20 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x13d8>
  781173:	jmp    781198 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5148>
  781175:	mov    %rcx,0x38(%rsp)
  78117a:	lea    0x319bb7(%rip),%rcx        # a9ad38 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x13f0>
  781181:	jmp    781198 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5148>
  781183:	lea    0x319b7e(%rip),%rcx        # a9ad08 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x13c0>
  78118a:	jmp    781198 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5148>
  78118c:	mov    %rcx,0x38(%rsp)
  781191:	lea    0x319198(%rip),%rcx        # a9a330 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x9e8>
  781198:	mov    %rcx,0xa0(%rsp)
  7811a0:	mov    0x38(%rsp),%rdi
  7811a5:	mov    %rax,%rsi
  7811a8:	mov    0xa0(%rsp),%rdx
  7811b0:	call   *0x338f2a(%rip)        # aba0e0 <_DYNAMIC+0x270>
  7811b6:	jmp    7811d8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  7811b8:	lea    0x31a449(%rip),%rax        # a9b608 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1cc0>
  7811bf:	mov    %rax,0x648(%rsp)
  7811c7:	mov    %rbx,%rdi
  7811ca:	mov    0x648(%rsp),%rdx
  7811d2:	call   *0x338f08(%rip)        # aba0e0 <_DYNAMIC+0x270>
  7811d8:	ud2
  7811da:	mov    %rbx,%rcx
  7811dd:	mov    %rax,%rbx
  7811e0:	mov    (%rcx),%rax
  7811e3:	movaps 0x760(%rsp),%xmm0
  7811eb:	movups %xmm0,0xb0(%rax)
  7811f2:	movaps 0x750(%rsp),%xmm0
  7811fa:	movups %xmm0,0xa0(%rax)
  781201:	movaps 0x710(%rsp),%xmm0
  781209:	movaps 0x720(%rsp),%xmm1
  781211:	movaps 0x730(%rsp),%xmm2
  781219:	movapd 0x740(%rsp),%xmm3
  781222:	movupd %xmm3,0x90(%rax)
  78122a:	movups %xmm2,0x80(%rax)
  781231:	movups %xmm1,0x70(%rax)
  781235:	movups %xmm0,0x60(%rax)
  781239:	jmp    7812ba <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x526a>
  78123b:	mov    %rax,%rbx
  78123e:	mov    0x6e8(%r13),%rax
  781245:	mov    0x210(%rsp),%rcx
  78124d:	mov    %rcx,0x28(%rax)
  781251:	movups 0x200(%rsp),%xmm0
  781259:	movups %xmm0,0x18(%rax)
  78125d:	mov    $0x1,%r15b
  781260:	xor    %r12d,%r12d
  781263:	jmp    781594 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5544>
  781268:	mov    %rax,%rbx
  78126b:	lea    0x728(%rsp),%rdi
  781273:	call   747ae0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime8metadata8TextSlotEECs9C2G9YFESsD_29canonical_text_public_control>
  781278:	lea    0x740(%rsp),%rdi
  781280:	call   747ae0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime8metadata8TextSlotEECs9C2G9YFESsD_29canonical_text_public_control>
  781285:	lea    0x710(%rsp),%rdi
  78128d:	call   74e870 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime6scroll14ViewportColumnECs9C2G9YFESsD_29canonical_text_public_control>
  781292:	mov    0x758(%rsp),%rax
  78129a:	test   %rax,%rax
  78129d:	je     7812ba <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x526a>
  78129f:	mov    0x760(%rsp),%rdi
  7812a7:	shl    $0x3,%rax
  7812ab:	lea    (%rax,%rax,2),%rsi
  7812af:	mov    $0x8,%edx
  7812b4:	call   *0x338df6(%rip)        # aba0b0 <_DYNAMIC+0x240>
  7812ba:	mov    $0x1,%r12b
  7812bd:	movl   $0x0,0x58(%rsp)
  7812c5:	mov    $0x1,%al
  7812c7:	mov    %eax,0x38(%rsp)
  7812cb:	movl   $0x0,0x30(%rsp)
  7812d3:	mov    $0x1,%r15b
  7812d6:	jmp    781449 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x53f9>
  7812db:	mov    %rax,%rbx
  7812de:	mov    0x6e8(%r13),%rax
  7812e5:	movq   $0x0,0x30(%rax)
  7812ed:	xor    %r15d,%r15d
  7812f0:	jmp    781594 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5544>
  7812f5:	mov    %rax,%rbx
  7812f8:	lea    0x390(%rsp),%rsi
  781300:	mov    $0x1e8,%edx
  781305:	mov    %r13,%rdi
  781308:	call   *0x338dc2(%rip)        # aba0d0 <memcpy@GLIBC_2.14>
  78130e:	mov    $0x1,%al
  781310:	mov    %eax,0x58(%rsp)
  781314:	xor    %ebp,%ebp
  781316:	mov    $0x1,%r12b
  781319:	mov    $0x1,%al
  78131b:	mov    %eax,0x38(%rsp)
  78131f:	mov    $0x1,%al
  781321:	mov    %eax,0x30(%rsp)
  781325:	mov    $0x1,%r15b
  781328:	jmp    781449 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x53f9>
  78132d:	mov    %rax,%rbx
  781330:	jmp    781586 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5536>
  781335:	mov    %rax,%rbx
  781338:	mov    0x3a0(%rsp),%rax
  781340:	mov    %rax,0x10(%r15)
  781344:	movaps 0x390(%rsp),%xmm0
  78134c:	movups %xmm0,(%r15)
  781350:	mov    0x80(%rsp),%rax
  781358:	mov    %rax,0x5e0(%r13)
  78135f:	mov    0xf8(%rsp),%rax
  781367:	mov    %ax,0x5e8(%r13)
  78136f:	mov    0x2e0(%rsp),%rax
  781377:	mov    %ax,0x5ea(%r13)
  78137f:	movss  0x9c(%rsp),%xmm0
  781388:	movss  %xmm0,0x5ec(%r13)
  781391:	xor    %r15d,%r15d
  781394:	jmp    781594 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5544>
  781399:	mov    %rax,%rbx
  78139c:	mov    $0x1,%r12b
  78139f:	jmp    7813d1 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5381>
  7813a1:	mov    %rax,%rbx
  7813a4:	mov    %rbp,%rdi
  7813a7:	call   746020 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtCslbxve4rcJus_4gpui11shared_text10SharedTextEECs9C2G9YFESsD_29canonical_text_public_control>
  7813ac:	jmp    781600 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x55b0>
  7813b1:	mov    %rax,%rbx
  7813b4:	mov    $0x1,%r12b
  7813b7:	test   %r15,%r15
  7813ba:	je     7813d1 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5381>
  7813bc:	shl    $0x4,%r15
  7813c0:	mov    $0x4,%edx
  7813c5:	mov    %r13,%rdi
  7813c8:	mov    %r15,%rsi
  7813cb:	call   *0x338cdf(%rip)        # aba0b0 <_DYNAMIC+0x240>
  7813d1:	mov    $0x1,%al
  7813d3:	mov    %eax,0x38(%rsp)
  7813d7:	mov    $0x1,%r15b
  7813da:	xor    %r13d,%r13d
  7813dd:	cmpb   $0x0,0x58(%rsp)
  7813e2:	je     7815df <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x558f>
  7813e8:	jmp    7816d4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5684>
  7813ed:	mov    %rax,%rbx
  7813f0:	mov    $0x1,%r12b
  7813f3:	mov    $0x1,%al
  7813f5:	mov    %eax,0x38(%rsp)
  7813f9:	mov    $0x1,%al
  7813fb:	mov    %eax,0x30(%rsp)
  7813ff:	mov    $0x1,%r13b
  781402:	mov    $0x1,%r15b
  781405:	mov    $0x1,%bpl
  781408:	cmpq   $0xffffffffffffffff,0x258(%rsp)
  781411:	jne    7816ec <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x569c>
  781417:	jmp    781700 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x56b0>
  78141c:	mov    %ebx,0x30(%rsp)
  781420:	mov    %rax,%rbx
  781423:	mov    %r15d,%r13d
  781426:	jmp    781700 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x56b0>
  78142b:	mov    %rax,%rbx
  78142e:	mov    $0x1,%al
  781430:	mov    %eax,0x58(%rsp)
  781434:	mov    $0x1,%r12b
  781437:	mov    $0x1,%al
  781439:	mov    %eax,0x38(%rsp)
  78143d:	mov    $0x1,%al
  78143f:	mov    %eax,0x30(%rsp)
  781443:	mov    $0x1,%r15b
  781446:	mov    $0x1,%bpl
  781449:	movb   $0x1,0xc0(%rsp)
  781451:	jmp    781594 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5544>
  781456:	mov    %rax,%rbx
  781459:	mov    %r13d,%r15d
  78145c:	jmp    78172b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x56db>
  781461:	mov    %rax,%rbx
  781464:	jmp    781594 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5544>
  781469:	mov    %rax,%rbx
  78146c:	mov    %r13d,%r15d
  78146f:	jmp    78171e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x56ce>
  781474:	mov    %rax,%rbx
  781477:	add    $0x38,%r15
  78147b:	mov    %r15,%rdi
  78147e:	call   74cf90 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text11RasterCacheECs9C2G9YFESsD_29canonical_text_public_control>
  781483:	jmp    7814f0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x54a0>
  781485:	call   *0x338c4d(%rip)        # aba0d8 <_DYNAMIC+0x268>
  78148b:	mov    %rax,%rbx
  78148e:	mov    0x300(%rsp),%rax
  781496:	lock decq (%rax)
  78149a:	jne    7816af <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x565f>
  7814a0:	lea    0x300(%rsp),%rdi
  7814a8:	call   *0x338d22(%rip)        # aba1d0 <_DYNAMIC+0x360>
  7814ae:	jmp    7816af <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x565f>
  7814b3:	mov    %rax,%rbx
  7814b6:	mov    %r12b,0x60(%rsp)
  7814bb:	jmp    781600 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x55b0>
  7814c0:	mov    %rax,%rbx
  7814c3:	movb   $0x1,0x60(%rsp)
  7814c8:	jmp    781600 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x55b0>
  7814cd:	mov    %rax,%rbx
  7814d0:	mov    $0x1,%bpl
  7814d3:	mov    $0x1,%r15b
  7814d6:	mov    $0x1,%r13b
  7814d9:	mov    $0x1,%al
  7814db:	mov    %eax,0x30(%rsp)
  7814df:	mov    $0x1,%al
  7814e1:	mov    %eax,0x38(%rsp)
  7814e5:	mov    $0x1,%r12b
  7814e8:	jmp    7816d4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5684>
  7814ed:	mov    %rax,%rbx
  7814f0:	mov    0x40(%rsp),%rax
  7814f5:	mov    0x6e8(%rax),%rax
  7814fc:	mov    %r12,0x30(%rax)
  781500:	mov    %r14d,0x38(%rax)
  781504:	mov    %ebp,0x3c(%rax)
  781507:	movaps 0x970(%rsp),%xmm0
  78150f:	movaps 0x980(%rsp),%xmm1
  781517:	movaps 0x990(%rsp),%xmm2
  78151f:	movups %xmm0,0x40(%rax)
  781523:	movups %xmm1,0x50(%rax)
  781527:	movups %xmm2,0x60(%rax)
  78152b:	mov    0x9a0(%rsp),%rcx
  781533:	mov    %rcx,0x70(%rax)
  781537:	mov    $0x1,%bpl
  78153a:	jmp    781883 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5833>
  78153f:	mov    %rax,%rbx
  781542:	jmp    781862 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5812>
  781547:	mov    %rax,%rbx
  78154a:	lea    0x390(%rsp),%rsi
  781552:	mov    $0x298,%edx
  781557:	mov    %r14,%rdi
  78155a:	call   *0x338b70(%rip)        # aba0d0 <memcpy@GLIBC_2.14>
  781560:	jmp    781832 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57e2>
  781565:	mov    %rax,%rbx
  781568:	jmp    781850 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5800>
  78156d:	jmp    7816ac <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x565c>
  781572:	ud2
  781574:	ud2
  781576:	mov    %rax,%rbx
  781579:	lea    0x8b8(%rsp),%rdi
  781581:	call   7470f0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCsghYClfd3M9V_11gpui_canvas5image5ImageEECs9C2G9YFESsD_29canonical_text_public_control>
  781586:	mov    $0x1,%r12b
  781589:	movl   $0x0,0x38(%rsp)
  781591:	mov    $0x1,%r15b
  781594:	mov    0x180(%rsp),%rsi
  78159c:	test   %rsi,%rsi
  78159f:	setg   %al
  7815a2:	test   %al,0xc0(%rsp)
  7815a9:	je     7815d1 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5581>
  7815ab:	mov    0x188(%rsp),%rdi
  7815b3:	shl    $0x4,%rsi
  7815b7:	mov    $0x4,%edx
  7815bc:	call   *0x338aee(%rip)        # aba0b0 <_DYNAMIC+0x240>
  7815c2:	xor    %r13d,%r13d
  7815c5:	cmpb   $0x0,0x58(%rsp)
  7815ca:	je     7815df <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x558f>
  7815cc:	jmp    7816d4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5684>
  7815d1:	xor    %r13d,%r13d
  7815d4:	cmpb   $0x0,0x58(%rsp)
  7815d9:	jne    7816d4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5684>
  7815df:	cmpq   $0xffffffffffffffff,0x258(%rsp)
  7815e8:	jne    7816ec <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x569c>
  7815ee:	jmp    781700 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x56b0>
  7815f3:	jmp    78182f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57df>
  7815f8:	jmp    78182f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57df>
  7815fd:	mov    %rax,%rbx
  781600:	mov    0x1f8(%rsp),%rax
  781608:	test   %rax,%rax
  78160b:	setne  %cl
  78160e:	test   %cl,0x60(%rsp)
  781612:	je     7816af <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x565f>
  781618:	lock decq (%rax)
  78161c:	jne    7816af <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x565f>
  781622:	lea    0x1f8(%rsp),%rdi
  78162a:	call   *0x338ba0(%rip)        # aba1d0 <_DYNAMIC+0x360>
  781630:	jmp    7816af <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x565f>
  781632:	jmp    78182f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57df>
  781637:	mov    %rax,%rbx
  78163a:	mov    $0x1,%r12b
  78163d:	mov    $0x1,%r13b
  781640:	mov    $0x1,%r15b
  781643:	mov    $0x1,%bpl
  781646:	jmp    78174f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x56ff>
  78164b:	mov    %rax,%rbx
  78164e:	mov    $0x1,%r12b
  781651:	mov    $0x1,%r13b
  781654:	mov    $0x1,%r15b
  781657:	mov    $0x1,%bpl
  78165a:	jmp    78176f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x571f>
  78165f:	mov    %rax,%rbx
  781662:	mov    $0x1,%r12b
  781665:	mov    $0x1,%r13b
  781668:	mov    $0x1,%r15b
  78166b:	mov    $0x1,%bpl
  78166e:	jmp    781793 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5743>
  781673:	mov    %rax,%rbx
  781676:	mov    $0x1,%r12b
  781679:	mov    $0x1,%r13b
  78167c:	mov    $0x1,%r15b
  78167f:	mov    $0x1,%bpl
  781682:	jmp    7817b7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5767>
  781687:	mov    %rax,%rbx
  78168a:	mov    $0x1,%bpl
  78168d:	mov    $0x1,%r15b
  781690:	mov    $0x1,%r12b
  781693:	jmp    7817e0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5790>
  781698:	mov    %rax,%rbx
  78169b:	jmp    781816 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57c6>
  7816a0:	ud2
  7816a2:	ud2
  7816a4:	mov    %rax,%rbx
  7816a7:	jmp    781883 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5833>
  7816ac:	mov    %rax,%rbx
  7816af:	mov    $0x1,%bpl
  7816b2:	lea    0x970(%rsp),%rdi
  7816ba:	call   74d2e0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas6canvas6CanvasECs9C2G9YFESsD_29canonical_text_public_control>
  7816bf:	mov    $0x1,%r15b
  7816c2:	mov    $0x1,%r13b
  7816c5:	mov    $0x1,%al
  7816c7:	mov    %eax,0x30(%rsp)
  7816cb:	mov    $0x1,%al
  7816cd:	mov    %eax,0x38(%rsp)
  7816d1:	mov    $0x1,%r12b
  7816d4:	lea    0x6c0(%rsp),%rdi
  7816dc:	call   74e820 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime6scroll13ViewportBuildECs9C2G9YFESsD_29canonical_text_public_control>
  7816e1:	cmpq   $0xffffffffffffffff,0x258(%rsp)
  7816ea:	je     781700 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x56b0>
  7816ec:	cmpb   $0x0,0x38(%rsp)
  7816f1:	je     781700 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x56b0>
  7816f3:	lea    0x8b8(%rsp),%rdi
  7816fb:	call   7470f0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCsghYClfd3M9V_11gpui_canvas5image5ImageEECs9C2G9YFESsD_29canonical_text_public_control>
  781700:	cmpl   $0xffffffff,0x810(%rsp)
  781708:	je     78171e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x56ce>
  78170a:	cmpb   $0x0,0x30(%rsp)
  78170f:	je     78171e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x56ce>
  781711:	lea    0x810(%rsp),%rdi
  781719:	call   74ec60 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime8metadata5SheetECs9C2G9YFESsD_29canonical_text_public_control>
  78171e:	lea    0x6a8(%rsp),%rdi
  781726:	call   74aec0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtCscdodAO9FK5_5alloc11collections5btree3set8BTreeSetNtNtCslbxve4rcJus_4gpui4list6ListIdEECs9C2G9YFESsD_29canonical_text_public_control>
  78172b:	mov    0x100(%rsp),%rsi
  781733:	test   %rsi,%rsi
  781736:	je     78174f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x56ff>
  781738:	mov    0x108(%rsp),%rdi
  781740:	shl    $0x2,%rsi
  781744:	mov    $0x4,%edx
  781749:	call   *0x338961(%rip)        # aba0b0 <_DYNAMIC+0x240>
  78174f:	mov    0x158(%rsp),%rsi
  781757:	test   %rsi,%rsi
  78175a:	je     78176f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x571f>
  78175c:	mov    0x160(%rsp),%rdi
  781764:	mov    $0x1,%edx
  781769:	call   *0x338941(%rip)        # aba0b0 <_DYNAMIC+0x240>
  78176f:	mov    0x230(%rsp),%rsi
  781777:	test   %rsi,%rsi
  78177a:	je     781793 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5743>
  78177c:	mov    0x238(%rsp),%rdi
  781784:	shl    $0x4,%rsi
  781788:	mov    $0x4,%edx
  78178d:	call   *0x33891d(%rip)        # aba0b0 <_DYNAMIC+0x240>
  781793:	mov    0x218(%rsp),%rsi
  78179b:	test   %rsi,%rsi
  78179e:	je     7817b7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5767>
  7817a0:	mov    0x220(%rsp),%rdi
  7817a8:	shl    $0x4,%rsi
  7817ac:	mov    $0x4,%edx
  7817b1:	call   *0x3388f9(%rip)        # aba0b0 <_DYNAMIC+0x240>
  7817b7:	mov    0x1d8(%rsp),%rax
  7817bf:	test   %rax,%rax
  7817c2:	je     7817db <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x578b>
  7817c4:	mov    0x1e0(%rsp),%rdi
  7817cc:	imul   $0x38,%rax,%rsi
  7817d0:	mov    $0x8,%edx
  7817d5:	call   *0x3388d5(%rip)        # aba0b0 <_DYNAMIC+0x240>
  7817db:	test   %r13b,%r13b
  7817de:	je     781804 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57b4>
  7817e0:	mov    0x268(%rsp),%rsi
  7817e8:	test   %rsi,%rsi
  7817eb:	je     781804 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57b4>
  7817ed:	mov    0x270(%rsp),%rdi
  7817f5:	shl    $0x4,%rsi
  7817f9:	mov    $0x4,%edx
  7817fe:	call   *0x3388ac(%rip)        # aba0b0 <_DYNAMIC+0x240>
  781804:	test   %r15b,%r15b
  781807:	je     781816 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57c6>
  781809:	lea    0x140(%rsp),%rdi
  781811:	call   7474b0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCslbxve4rcJus_4gpui7runtime9PresentedEECs9C2G9YFESsD_29canonical_text_public_control>
  781816:	cmpl   $0xfffffffe,0x7c8(%rsp)
  78181e:	je     781838 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57e8>
  781820:	lea    0x7c8(%rsp),%rdi
  781828:	call   74d7d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  78182d:	jmp    781838 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57e8>
  78182f:	mov    %rax,%rbx
  781832:	mov    $0x1,%r12b
  781835:	mov    $0x1,%bpl
  781838:	cmpq   $0x0,0x1c0(%rsp)
  781841:	je     781850 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5800>
  781843:	mov    0x1c8(%rsp),%rdi
  78184b:	call   74cd40 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text10TextShaperECs9C2G9YFESsD_29canonical_text_public_control>
  781850:	test   %r12b,%r12b
  781853:	je     781862 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5812>
  781855:	lea    0x200(%rsp),%rdi
  78185d:	call   747910 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime13text_geometry5EntryEECs9C2G9YFESsD_29canonical_text_public_control>
  781862:	mov    0xd0(%rsp),%rax
  78186a:	test   %rax,%rax
  78186d:	je     781883 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5833>
  78186f:	lock decq (%rax)
  781873:	jne    781883 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5833>
  781875:	lea    0xd0(%rsp),%rdi
  78187d:	call   *0x33891d(%rip)        # aba1a0 <_DYNAMIC+0x330>
  781883:	cmpl   $0x2,0xca0(%rsp)
  78188b:	je     78189f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x584f>
  78188d:	test   %bpl,%bpl
  781890:	je     78189f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x584f>
  781892:	lea    0xca0(%rsp),%rdi
  78189a:	call   74d2e0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas6canvas6CanvasECs9C2G9YFESsD_29canonical_text_public_control>
  78189f:	mov    %rbx,%rdi
  7818a2:	call   a98590 <_Unwind_Resume@plt>
  7818a7:	call   *0x33882b(%rip)        # aba0d8 <_DYNAMIC+0x268>

<&gpui_canvas::text::layout::TextPosition as core::fmt::Debug>::fmt bytes=99 frame=24

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007968e0 <_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextPositionNtB6_5Debug3fmtCs9C2G9YFESsD_29canonical_text_public_control>:
  7968e0:	push   %r14
  7968e2:	push   %rbx
  7968e3:	push   %rax
  7968e4:	mov    %rsi,%rax
  7968e7:	mov    (%rdi),%r9
  7968ea:	lea    0x4(%r9),%rcx
  7968ee:	mov    %rcx,(%rsp)
  7968f2:	sub    $0x8,%rsp
  7968f6:	lea    0x305743(%rip),%r10        # a9c040 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x26f8>
  7968fd:	lea    0x8(%rsp),%r11
  796902:	lea    -0x6d2c11(%rip),%rbx        # c3cf8 <GCC_except_table0+0x192c>
  796909:	lea    0x305710(%rip),%r14        # a9c020 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x26d8>
  796910:	lea    -0x6c38e8(%rip),%rsi        # d302f <GCC_except_table0+0x10c63>
  796917:	lea    -0x6c6e90(%rip),%rcx        # cfa8e <GCC_except_table0+0xd6c2>
  79691e:	mov    $0xc,%edx
  796923:	mov    $0x6,%r8d
  796929:	mov    %rax,%rdi
  79692c:	push   %r10
  79692e:	push   %r11
  796930:	push   $0x8
  796932:	push   %rbx
  796933:	push   %r14
  796935:	call   *0x323f05(%rip)        # aba840 <_DYNAMIC+0x9d0>
  79693b:	add    $0x38,%rsp
  79693f:	pop    %rbx
  796940:	pop    %r14
  796942:	ret

<&gpui_canvas::text::layout::CaretAffinity as core::fmt::Debug>::fmt bytes=46 frame=0

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000796950 <_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout13CaretAffinityNtB6_5Debug3fmtCs9C2G9YFESsD_29canonical_text_public_control>:
  796950:	mov    %rsi,%rax
  796953:	mov    (%rdi),%rcx
  796956:	movzbl (%rcx),%ecx
  796959:	lea    -0x6c399b(%rip),%rdx        # d2fc5 <GCC_except_table0+0x10bf9>
  796960:	lea    -0x6d2b6f(%rip),%rsi        # c3df8 <GCC_except_table0+0x1a2c>
  796967:	test   %ecx,%ecx
  796969:	cmovne %rdx,%rsi
  79696d:	lea    0x8(,%rcx,2),%rdx
  796975:	mov    %rax,%rdi
  796978:	jmp    *0x323eca(%rip)        # aba848 <_DYNAMIC+0x9d8>

<&gpui_canvas::text::layout::TextSelection as core::fmt::Debug>::fmt bytes=99 frame=24

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000796980 <_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout13TextSelectionNtB6_5Debug3fmtCs9C2G9YFESsD_29canonical_text_public_control>:
  796980:	push   %r14
  796982:	push   %rbx
  796983:	push   %rax
  796984:	mov    %rsi,%rax
  796987:	mov    (%rdi),%r9
  79698a:	lea    0x8(%r9),%rcx
  79698e:	mov    %rcx,(%rsp)
  796992:	sub    $0x8,%rsp
  796996:	lea    0x303273(%rip),%r10        # a99c10 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2c8>
  79699d:	lea    0x8(%rsp),%r11
  7969a2:	lea    -0x6c3880(%rip),%rbx        # d3129 <GCC_except_table0+0x10d5d>
  7969a9:	lea    0x3056f0(%rip),%r14        # a9c0a0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2758>
  7969b0:	lea    -0x6c38a1(%rip),%rsi        # d3116 <GCC_except_table0+0x10d4a>
  7969b7:	lea    -0x6c389b(%rip),%rcx        # d3123 <GCC_except_table0+0x10d57>
  7969be:	mov    $0xd,%edx
  7969c3:	mov    $0x6,%r8d
  7969c9:	mov    %rax,%rdi
  7969cc:	push   %r10
  7969ce:	push   %r11
  7969d0:	push   $0x5
  7969d2:	push   %rbx
  7969d3:	push   %r14
  7969d5:	call   *0x323e65(%rip)        # aba840 <_DYNAMIC+0x9d0>
  7969db:	add    $0x38,%rsp
  7969df:	pop    %rbx
  7969e0:	pop    %r14
  7969e2:	ret

<&*const gpui_canvas::text::layout::TextGeometry as core::fmt::Debug>::fmt bytes=12 frame=0

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007969f0 <_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRPNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryNtB6_5Debug3fmtCs9C2G9YFESsD_29canonical_text_public_control>:
  7969f0:	mov    (%rdi),%rax
  7969f3:	mov    (%rax),%rdi
  7969f6:	jmp    *0x323e84(%rip)        # aba880 <_DYNAMIC+0xa10>

<&(alloc::string::String, gpui_canvas::text::layout::TextSelection, *const gpui_canvas::text::layout::TextGeometry, u64) as core::fmt::Debug>::fmt bytes=156 frame=72

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000796a40 <_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRTNtNtCscdodAO9FK5_5alloc6string6StringNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout13TextSelectionPNtB1a_12TextGeometryyENtB6_5Debug3fmtCs9C2G9YFESsD_29canonical_text_public_control>:
  796a40:	push   %r14
  796a42:	push   %rbx
  796a43:	sub    $0x38,%rsp
  796a47:	mov    (%rdi),%r14
  796a4a:	lea    0x20(%rsp),%rbx
  796a4f:	mov    $0x1,%edx
  796a54:	mov    %rbx,%rdi
  796a57:	xor    %ecx,%ecx
  796a59:	call   *0x323e29(%rip)        # aba888 <_DYNAMIC+0xa18>
  796a5f:	mov    %r14,(%rsp)
  796a63:	lea    0x18(%r14),%rax
  796a67:	mov    %rax,0x8(%rsp)
  796a6c:	lea    0x28(%r14),%rax
  796a70:	mov    %rax,0x10(%rsp)
  796a75:	add    $0x30,%r14
  796a79:	mov    %r14,0x18(%rsp)
  796a7e:	lea    0x30316b(%rip),%rdx        # a99bf0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2a8>
  796a85:	mov    0x323e04(%rip),%r14        # aba890 <_DYNAMIC+0xa20>
  796a8c:	mov    %rsp,%rsi
  796a8f:	mov    %rbx,%rdi
  796a92:	call   *%r14
  796a95:	lea    0x303194(%rip),%rdx        # a99c30 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2e8>
  796a9c:	lea    0x8(%rsp),%rsi
  796aa1:	mov    %rbx,%rdi
  796aa4:	call   *%r14
  796aa7:	lea    0x304ffa(%rip),%rdx        # a9baa8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2160>
  796aae:	lea    0x10(%rsp),%rsi
  796ab3:	mov    %rbx,%rdi
  796ab6:	call   *%r14
  796ab9:	lea    0x305008(%rip),%rdx        # a9bac8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2180>
  796ac0:	lea    0x18(%rsp),%rsi
  796ac5:	mov    %rbx,%rdi
  796ac8:	call   *%r14
  796acb:	mov    %rbx,%rdi
  796ace:	call   *0x323dc4(%rip)        # aba898 <_DYNAMIC+0xa28>
  796ad4:	add    $0x38,%rsp
  796ad8:	pop    %rbx
  796ad9:	pop    %r14
  796adb:	ret

<&(*const gpui_canvas::text::layout::TextGeometry, u64) as core::fmt::Debug>::fmt bytes=102 frame=56

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000796ae0 <_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRTPNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryyENtB6_5Debug3fmtCs9C2G9YFESsD_29canonical_text_public_control>:
  796ae0:	push   %r14
  796ae2:	push   %rbx
  796ae3:	sub    $0x28,%rsp
  796ae7:	mov    (%rdi),%r14
  796aea:	lea    0x10(%rsp),%rbx
  796aef:	mov    $0x1,%edx
  796af4:	mov    %rbx,%rdi
  796af7:	xor    %ecx,%ecx
  796af9:	call   *0x323d89(%rip)        # aba888 <_DYNAMIC+0xa18>
  796aff:	mov    %r14,(%rsp)
  796b03:	add    $0x8,%r14
  796b07:	mov    %r14,0x8(%rsp)
  796b0c:	lea    0x304f95(%rip),%rdx        # a9baa8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2160>
  796b13:	mov    0x323d76(%rip),%r14        # aba890 <_DYNAMIC+0xa20>
  796b1a:	mov    %rsp,%rsi
  796b1d:	mov    %rbx,%rdi
  796b20:	call   *%r14
  796b23:	lea    0x304f9e(%rip),%rdx        # a9bac8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2180>
  796b2a:	lea    0x8(%rsp),%rsi
  796b2f:	mov    %rbx,%rdi
  796b32:	call   *%r14
  796b35:	mov    %rbx,%rdi
  796b38:	call   *0x323d5a(%rip)        # aba898 <_DYNAMIC+0xa28>
  796b3e:	add    $0x28,%rsp
  796b42:	pop    %rbx
  796b43:	pop    %r14
  796b45:	ret

<gpui_canvas::text::layout::TextOffset as core::fmt::Debug>::fmt bytes=41 frame=8

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000796df0 <_RNvXs7_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_10TextOffsetNtNtCs4NRVxsYgnAr_4core3fmt5Debug3fmt>:
  796df0:	push   %rax
  796df1:	mov    %rsi,%rax
  796df4:	mov    %rdi,(%rsp)
  796df8:	lea    -0x6c40c5(%rip),%rsi        # d2d3a <GCC_except_table0+0x1096e>
  796dff:	lea    0x304eea(%rip),%r8        # a9bcf0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x23a8>
  796e06:	mov    %rsp,%rcx
  796e09:	mov    $0xa,%edx
  796e0e:	mov    %rax,%rdi
  796e11:	call   *0x323a39(%rip)        # aba850 <_DYNAMIC+0x9e0>
  796e17:	pop    %rcx
  796e18:	ret

<core::iter::adapters::zip::Zip<core::slice::iter::ChunkBy<gpui_canvas::text::layout::Stop, <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#0}>, core::iter::adapters::skip::Skip<core::slice::iter::ChunkBy<gpui_canvas::text::layout::Stop, <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#0}>>> as core::iter::traits::iterator::Iterator>::next bytes=289 frame=24

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000798540 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control>:
  798540:	push   %r15
  798542:	push   %r14
  798544:	push   %rbx
  798545:	mov    0x8(%rsi),%rax
  798549:	test   %rax,%rax
  79854c:	je     798654 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control+0x114>
  798552:	mov    (%rsi),%rbx
  798555:	mov    $0x1,%r14d
  79855b:	cmp    $0x1,%rax
  79855f:	je     798584 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control+0x44>
  798561:	mov    (%rbx),%ecx
  798563:	lea    0xc(%rbx),%rdx
  798567:	lea    0x1(%rax),%r8
  79856b:	nopl   0x0(%rax,%rax,1)
  798570:	cmp    (%rdx),%ecx
  798572:	jne    798584 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control+0x44>
  798574:	inc    %r14
  798577:	add    $0xc,%rdx
  79857b:	dec    %r8
  79857e:	cmp    $0x2,%r8
  798582:	ja     798570 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control+0x30>
  798584:	sub    %r14,%rax
  798587:	jb     79861d <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control+0xdd>
  79858d:	lea    (%r14,%r14,2),%rcx
  798591:	lea    (%rbx,%rcx,4),%rcx
  798595:	mov    %rcx,(%rsi)
  798598:	mov    %rax,0x8(%rsi)
  79859c:	lea    0x10(%rsi),%rax
  7985a0:	mov    0x20(%rsi),%rcx
  7985a4:	test   %rcx,%rcx
  7985a7:	jne    798636 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control+0xf6>
  7985ad:	mov    0x18(%rsi),%rcx
  7985b1:	test   %rcx,%rcx
  7985b4:	je     798601 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control+0xc1>
  7985b6:	mov    (%rax),%rax
  7985b9:	mov    $0x1,%edx
  7985be:	cmp    $0x1,%rcx
  7985c2:	je     7985e5 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control+0xa5>
  7985c4:	mov    (%rax),%r8d
  7985c7:	lea    0xc(%rax),%r9
  7985cb:	lea    0x1(%rcx),%r10
  7985cf:	nop
  7985d0:	cmp    (%r9),%r8d
  7985d3:	jne    7985e5 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control+0xa5>
  7985d5:	inc    %rdx
  7985d8:	add    $0xc,%r9
  7985dc:	dec    %r10
  7985df:	cmp    $0x2,%r10
  7985e3:	ja     7985d0 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control+0x90>
  7985e5:	sub    %rdx,%rcx
  7985e8:	jb     79861d <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control+0xdd>
  7985ea:	lea    (%rdx,%rdx,2),%r8
  7985ee:	lea    (%rax,%r8,4),%r8
  7985f2:	mov    %r8,0x10(%rsi)
  7985f6:	mov    %rcx,0x18(%rsi)
  7985fa:	test   %rax,%rax
  7985fd:	jne    798608 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control+0xc8>
  7985ff:	jmp    798654 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control+0x114>
  798601:	xor    %eax,%eax
  798603:	test   %rax,%rax
  798606:	je     798654 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control+0x114>
  798608:	mov    %rbx,(%rdi)
  79860b:	mov    %r14,0x8(%rdi)
  79860f:	mov    %rax,0x10(%rdi)
  798613:	mov    %rdx,0x18(%rdi)
  798617:	pop    %rbx
  798618:	pop    %r14
  79861a:	pop    %r15
  79861c:	ret
  79861d:	lea    -0x6c89cb(%rip),%rdi        # cfc59 <GCC_except_table0+0xd88d>
  798624:	lea    0x303695(%rip),%rdx        # a9bcc0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2378>
  79862b:	mov    $0x13,%esi
  798630:	call   *0x321ab2(%rip)        # aba0e8 <_DYNAMIC+0x278>
  798636:	movq   $0x0,0x20(%rsi)
  79863e:	mov    %rdi,%r15
  798641:	mov    %rax,%rdi
  798644:	mov    %rcx,%rsi
  798647:	call   799500 <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthCs9C2G9YFESsD_29canonical_text_public_control>
  79864c:	mov    %r15,%rdi
  79864f:	test   %rax,%rax
  798652:	jne    798608 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control+0xc8>
  798654:	movq   $0x0,(%rdi)
  79865b:	pop    %rbx
  79865c:	pop    %r14
  79865e:	pop    %r15
  798660:	ret

<gpui_canvas::text::layout::TextPosition as core::fmt::Debug>::fmt bytes=99 frame=24

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000798960 <_RNvXsn_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextPositionNtNtCs4NRVxsYgnAr_4core3fmt5Debug3fmt>:
  798960:	push   %r14
  798962:	push   %rbx
  798963:	push   %rax
  798964:	mov    %rsi,%rax
  798967:	mov    %rdi,%r9
  79896a:	lea    0x4(%rdi),%rcx
  79896e:	mov    %rcx,(%rsp)
  798972:	sub    $0x8,%rsp
  798976:	lea    0x3036c3(%rip),%r10        # a9c040 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x26f8>
  79897d:	lea    0x8(%rsp),%r11
  798982:	lea    -0x6d4c91(%rip),%rbx        # c3cf8 <GCC_except_table0+0x192c>
  798989:	lea    0x303690(%rip),%r14        # a9c020 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x26d8>
  798990:	lea    -0x6c5968(%rip),%rsi        # d302f <GCC_except_table0+0x10c63>
  798997:	lea    -0x6c8f10(%rip),%rcx        # cfa8e <GCC_except_table0+0xd6c2>
  79899e:	mov    $0xc,%edx
  7989a3:	mov    $0x6,%r8d
  7989a9:	mov    %rax,%rdi
  7989ac:	push   %r10
  7989ae:	push   %r11
  7989b0:	push   $0x8
  7989b2:	push   %rbx
  7989b3:	push   %r14
  7989b5:	call   *0x321e85(%rip)        # aba840 <_DYNAMIC+0x9d0>
  7989bb:	add    $0x38,%rsp
  7989bf:	pop    %rbx
  7989c0:	pop    %r14
  7989c2:	ret

<core::slice::iter::ChunkBy<gpui_canvas::text::layout::Stop, <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#0}> as core::iter::traits::iterator::Iterator>::nth bytes=232 frame=8

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000799500 <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthCs9C2G9YFESsD_29canonical_text_public_control>:
  799500:	push   %rax
  799501:	mov    (%rdi),%rax
  799504:	mov    0x8(%rdi),%r8
  799508:	nopl   0x0(%rax,%rax,1)
  799510:	mov    %r8,%rcx
  799513:	mov    %rax,%r9
  799516:	mov    %r8,%r10
  799519:	cmp    $0x1,%r8
  79951d:	je     799554 <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthCs9C2G9YFESsD_29canonical_text_public_control+0x54>
  79951f:	test   %rcx,%rcx
  799522:	je     7995cb <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthCs9C2G9YFESsD_29canonical_text_public_control+0xcb>
  799528:	mov    (%r9),%eax
  79952b:	lea    0xc(%r9),%rdx
  79952f:	lea    0x1(%rcx),%r8
  799533:	mov    $0x1,%r10d
  799539:	nopl   0x0(%rax)
  799540:	cmp    (%rdx),%eax
  799542:	jne    799554 <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthCs9C2G9YFESsD_29canonical_text_public_control+0x54>
  799544:	inc    %r10
  799547:	add    $0xc,%rdx
  79954b:	dec    %r8
  79954e:	cmp    $0x2,%r8
  799552:	ja     799540 <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthCs9C2G9YFESsD_29canonical_text_public_control+0x40>
  799554:	mov    %rcx,%r8
  799557:	sub    %r10,%r8
  79955a:	jb     7995cf <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthCs9C2G9YFESsD_29canonical_text_public_control+0xcf>
  79955c:	lea    (%r10,%r10,2),%r11
  799560:	lea    (%r9,%r11,4),%rax
  799564:	mov    %rax,(%rdi)
  799567:	mov    %r8,0x8(%rdi)
  79956b:	dec    %rsi
  79956e:	jne    799510 <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthCs9C2G9YFESsD_29canonical_text_public_control+0x10>
  799570:	test   %r8,%r8
  799573:	je     7995cb <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthCs9C2G9YFESsD_29canonical_text_public_control+0xcb>
  799575:	mov    %r8,%rdx
  799578:	cmp    $0x1,%r8
  79957c:	je     7995b5 <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthCs9C2G9YFESsD_29canonical_text_public_control+0xb5>
  79957e:	mov    (%rax),%esi
  799580:	lea    (%r9,%r11,4),%r9
  799584:	add    $0xc,%r9
  799588:	sub    %r10,%rcx
  79958b:	inc    %rcx
  79958e:	mov    $0x1,%edx
  799593:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  7995a0:	cmp    (%r9),%esi
  7995a3:	jne    7995b5 <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthCs9C2G9YFESsD_29canonical_text_public_control+0xb5>
  7995a5:	inc    %rdx
  7995a8:	add    $0xc,%r9
  7995ac:	dec    %rcx
  7995af:	cmp    $0x2,%rcx
  7995b3:	ja     7995a0 <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthCs9C2G9YFESsD_29canonical_text_public_control+0xa0>
  7995b5:	sub    %rdx,%r8
  7995b8:	jb     7995cf <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthCs9C2G9YFESsD_29canonical_text_public_control+0xcf>
  7995ba:	lea    (%rdx,%rdx,2),%rcx
  7995be:	lea    (%rax,%rcx,4),%rcx
  7995c2:	mov    %rcx,(%rdi)
  7995c5:	mov    %r8,0x8(%rdi)
  7995c9:	pop    %rcx
  7995ca:	ret
  7995cb:	xor    %eax,%eax
  7995cd:	pop    %rcx
  7995ce:	ret
  7995cf:	lea    -0x6c997d(%rip),%rdi        # cfc59 <GCC_except_table0+0xd88d>
  7995d6:	lea    0x3026e3(%rip),%rdx        # a9bcc0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2378>
  7995dd:	mov    $0x13,%esi
  7995e2:	call   *0x320b00(%rip)        # aba0e8 <_DYNAMIC+0x278>

<gpui::runtime::text_geometry::TextResources>::acknowledge bytes=336 frame=104

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000079e140 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge>:
  79e140:	push   %rbp
  79e141:	push   %r15
  79e143:	push   %r14
  79e145:	push   %r13
  79e147:	push   %r12
  79e149:	push   %rbx
  79e14a:	sub    $0x38,%rsp
  79e14e:	mov    0x18(%rdi),%rax
  79e152:	movq   $0xffffffffffffffff,0x18(%rdi)
  79e15a:	cmp    $0xffffffffffffffff,%rax
  79e15e:	je     79e206 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0xc6>
  79e164:	mov    %rdi,%rbx
  79e167:	mov    %rax,0x10(%rsp)
  79e16c:	movups 0x20(%rdi),%xmm0
  79e170:	movaps %xmm0,0x20(%rsp)
  79e175:	lea    0x8(%rdi),%rax
  79e179:	mov    %rax,0x8(%rsp)
  79e17e:	mov    0x8(%rdi),%r14
  79e182:	mov    0x10(%rdi),%rax
  79e186:	test   %rax,%rax
  79e189:	je     79e1d3 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0x93>
  79e18b:	mov    $0x1,%r15d
  79e191:	sub    %rax,%r15
  79e194:	mov    $0xffffffffffffffe8,%r13
  79e19b:	xor    %r12d,%r12d
  79e19e:	mov    0x31c02b(%rip),%rbp        # aba1d0 <_DYNAMIC+0x360>
  79e1a5:	jmp    79e1c1 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0x81>
  79e1a7:	nopw   0x0(%rax,%rax,1)
  79e1b0:	add    $0xffffffffffffffe8,%r13
  79e1b4:	inc    %r15
  79e1b7:	add    $0x18,%r12
  79e1bb:	cmp    $0x1,%r15
  79e1bf:	je     79e1d3 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0x93>
  79e1c1:	mov    (%r14,%r12,1),%rax
  79e1c5:	lock decq (%rax)
  79e1c9:	jne    79e1b0 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0x70>
  79e1cb:	lea    (%r14,%r12,1),%rdi
  79e1cf:	call   *%rbp
  79e1d1:	jmp    79e1b0 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0x70>
  79e1d3:	mov    (%rbx),%rax
  79e1d6:	test   %rax,%rax
  79e1d9:	je     79e1f1 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0xb1>
  79e1db:	shl    $0x3,%rax
  79e1df:	lea    (%rax,%rax,2),%rsi
  79e1e3:	mov    $0x8,%edx
  79e1e8:	mov    %r14,%rdi
  79e1eb:	call   *0x31bebf(%rip)        # aba0b0 <_DYNAMIC+0x240>
  79e1f1:	mov    0x10(%rsp),%rax
  79e1f6:	mov    %rax,(%rbx)
  79e1f9:	movaps 0x20(%rsp),%xmm0
  79e1fe:	mov    0x8(%rsp),%rax
  79e203:	movups %xmm0,(%rax)
  79e206:	add    $0x38,%rsp
  79e20a:	pop    %rbx
  79e20b:	pop    %r12
  79e20d:	pop    %r13
  79e20f:	pop    %r14
  79e211:	pop    %r15
  79e213:	pop    %rbp
  79e214:	ret
  79e215:	mov    %rax,0x18(%rsp)
  79e21a:	test   %r15,%r15
  79e21d:	jne    79e25c <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0x11c>
  79e21f:	mov    (%rbx),%rax
  79e222:	test   %rax,%rax
  79e225:	je     79e23d <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0xfd>
  79e227:	shl    $0x3,%rax
  79e22b:	lea    (%rax,%rax,2),%rsi
  79e22f:	mov    $0x8,%edx
  79e234:	mov    %r14,%rdi
  79e237:	call   *0x31be73(%rip)        # aba0b0 <_DYNAMIC+0x240>
  79e23d:	mov    0x10(%rsp),%rax
  79e242:	mov    %rax,(%rbx)
  79e245:	movaps 0x20(%rsp),%xmm0
  79e24a:	mov    0x8(%rsp),%rax
  79e24f:	movups %xmm0,(%rax)
  79e252:	mov    0x18(%rsp),%rdi
  79e257:	call   a98590 <_Unwind_Resume@plt>
  79e25c:	mov    %r14,%r12
  79e25f:	sub    %r13,%r12
  79e262:	neg    %r15
  79e265:	jmp    79e279 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0x139>
  79e267:	nopw   0x0(%rax,%rax,1)
  79e270:	add    $0x18,%r12
  79e274:	dec    %r15
  79e277:	je     79e21f <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0xdf>
  79e279:	mov    (%r12),%rax
  79e27d:	lock decq (%rax)
  79e281:	jne    79e270 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0x130>
  79e283:	mov    %r12,%rdi
  79e286:	call   *%rbp
  79e288:	jmp    79e270 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0x130>
  79e28a:	call   *0x31be48(%rip)        # aba0d8 <_DYNAMIC+0x268>

<gpui::runtime::geometry::Geometry>::acknowledge bytes=76 frame=24

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007a64d0 <_RNvMs4_NtNtCslbxve4rcJus_4gpui7runtime8geometryNtB5_8Geometry11acknowledge>:
  7a64d0:	push   %r15
  7a64d2:	push   %r14
  7a64d4:	push   %rbx
  7a64d5:	mov    0x30(%rdi),%r14
  7a64d9:	movq   $0xffffffffffffffff,0x30(%rdi)
  7a64e1:	cmp    $0xffffffffffffffff,%r14
  7a64e5:	je     7a6516 <_RNvMs4_NtNtCslbxve4rcJus_4gpui7runtime8geometryNtB5_8Geometry11acknowledge+0x46>
  7a64e7:	mov    %rdi,%rbx
  7a64ea:	lea    0x38(%rdi),%r15
  7a64ee:	mov    0x18(%rdi),%rsi
  7a64f2:	test   %rsi,%rsi
  7a64f5:	je     7a650a <_RNvMs4_NtNtCslbxve4rcJus_4gpui7runtime8geometryNtB5_8Geometry11acknowledge+0x3a>
  7a64f7:	mov    0x20(%rbx),%rdi
  7a64fb:	shl    $0x4,%rsi
  7a64ff:	mov    $0x4,%edx
  7a6504:	call   *0x313ba6(%rip)        # aba0b0 <_DYNAMIC+0x240>
  7a650a:	mov    %r14,0x18(%rbx)
  7a650e:	movups (%r15),%xmm0
  7a6512:	movups %xmm0,0x20(%rbx)
  7a6516:	pop    %rbx
  7a6517:	pop    %r14
  7a6519:	pop    %r15
  7a651b:	ret

<gpui::runtime::TextSite>::shape_for bytes=463 frame=168

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007a89e0 <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for>:
  7a89e0:	push   %rbp
  7a89e1:	push   %r15
  7a89e3:	push   %r14
  7a89e5:	push   %r13
  7a89e7:	push   %r12
  7a89e9:	push   %rbx
  7a89ea:	sub    $0x78,%rsp
  7a89ee:	mov    %ecx,%ebp
  7a89f0:	mov    %rsi,%rbx
  7a89f3:	maxss  -0x6e63b3(%rip),%xmm1        # c2648 <GCC_except_table0+0x27c>
  7a89fb:	mov    %rdi,%r14
  7a89fe:	movd   %xmm1,%r12d
  7a8a03:	cmpq   $0xffffffffffffffff,(%rsi)
  7a8a07:	je     7a8a23 <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x43>
  7a8a09:	cmpl   $0x1,0x38(%rbx)
  7a8a0d:	jne    7a8ae9 <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x109>
  7a8a13:	cmp    %r12d,0x3c(%rbx)
  7a8a17:	sete   %al
  7a8a1a:	test   %al,%bpl
  7a8a1d:	jne    7a8af3 <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x113>
  7a8a23:	test   %r8b,%r8b
  7a8a26:	je     7a8a51 <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x71>
  7a8a28:	mov    %r12d,0x8(%rsp)
  7a8a2d:	mov    0x40(%rbx),%rax
  7a8a31:	mov    (%rax),%rcx
  7a8a34:	shr    $1,%rcx
  7a8a37:	add    $0x10,%rax
  7a8a3b:	lea    0x40(%rsp),%rdi
  7a8a40:	mov    %rdx,%rsi
  7a8a43:	mov    %rax,%rdx
  7a8a46:	mov    %ebp,%r8d
  7a8a49:	call   *0x3118f9(%rip)        # aba348 <_DYNAMIC+0x4d8>
  7a8a4f:	jmp    7a8a78 <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x98>
  7a8a51:	mov    %r12d,0x8(%rsp)
  7a8a56:	mov    0x40(%rbx),%rax
  7a8a5a:	mov    (%rax),%rcx
  7a8a5d:	shr    $1,%rcx
  7a8a60:	add    $0x10,%rax
  7a8a64:	lea    0x40(%rsp),%rdi
  7a8a69:	mov    %rdx,%rsi
  7a8a6c:	mov    %rax,%rdx
  7a8a6f:	mov    %ebp,%r8d
  7a8a72:	call   *0x312000(%rip)        # abaa78 <_DYNAMIC+0xc08>
  7a8a78:	mov    0x40(%rsp),%r15
  7a8a7d:	mov    0x48(%rsp),%r13d
  7a8a82:	mov    0x4c(%rsp),%r12d
  7a8a87:	cmp    $0xffffffffffffffff,%r15
  7a8a8b:	je     7a8b49 <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x169>
  7a8a91:	mov    0x70(%rsp),%rax
  7a8a96:	mov    %rax,0x30(%rsp)
  7a8a9b:	movups 0x50(%rsp),%xmm0
  7a8aa0:	movups 0x60(%rsp),%xmm1
  7a8aa5:	movaps %xmm1,0x20(%rsp)
  7a8aaa:	movaps %xmm0,0x10(%rsp)
  7a8aaf:	mov    %rbx,%rdi
  7a8ab2:	call   799fe0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtCslbxve4rcJus_4gpui7runtime6ShapedEEB11_>
  7a8ab7:	mov    %r15,(%rbx)
  7a8aba:	mov    %r13d,0x8(%rbx)
  7a8abe:	mov    %r12d,0xc(%rbx)
  7a8ac2:	movaps 0x10(%rsp),%xmm0
  7a8ac7:	movaps 0x20(%rsp),%xmm1
  7a8acc:	movups %xmm0,0x10(%rbx)
  7a8ad0:	movups %xmm1,0x20(%rbx)
  7a8ad4:	mov    0x30(%rsp),%rax
  7a8ad9:	mov    %rax,0x30(%rbx)
  7a8add:	mov    %ebp,0x38(%rbx)
  7a8ae0:	mov    0x8(%rsp),%eax
  7a8ae4:	mov    %eax,0x3c(%rbx)
  7a8ae7:	jmp    7a8b3c <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x15c>
  7a8ae9:	test   $0x1,%bpl
  7a8aed:	jne    7a8a23 <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x43>
  7a8af3:	test   %r8b,%r8b
  7a8af6:	je     7a8b3c <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x15c>
  7a8af8:	lea    0x40(%rsp),%rdi
  7a8afd:	mov    %rbx,%rsi
  7a8b00:	mov    %rdx,%r15
  7a8b03:	xor    %edx,%edx
  7a8b05:	mov    $0x1,%ecx
  7a8b0a:	movss  %xmm1,0x8(%rsp)
  7a8b10:	movss  %xmm0,0xc(%rsp)
  7a8b16:	call   *0x3119d4(%rip)        # aba4f0 <_DYNAMIC+0x680>
  7a8b1c:	movss  0xc(%rsp),%xmm0
  7a8b22:	movss  0x8(%rsp),%xmm1
  7a8b28:	mov    %r15,%rdx
  7a8b2b:	cmpb   $0x0,0x40(%rsp)
  7a8b30:	je     7a8a28 <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x48>
  7a8b36:	cmpq   $0xffffffffffffffff,(%rbx)
  7a8b3a:	je     7a8b6a <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x18a>
  7a8b3c:	mov    %rbx,0x8(%r14)
  7a8b40:	movq   $0xfffffffffffffffe,(%r14)
  7a8b47:	jmp    7a8b58 <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x178>
  7a8b49:	movq   $0x23,(%r14)
  7a8b50:	mov    %r13d,0x8(%r14)
  7a8b54:	mov    %r12d,0xc(%r14)
  7a8b58:	mov    %r14,%rax
  7a8b5b:	add    $0x78,%rsp
  7a8b5f:	pop    %rbx
  7a8b60:	pop    %r12
  7a8b62:	pop    %r13
  7a8b64:	pop    %r14
  7a8b66:	pop    %r15
  7a8b68:	pop    %rbp
  7a8b69:	ret
  7a8b6a:	lea    0x2f3daf(%rip),%rdi        # a9c920 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2fd8>
  7a8b71:	call   *0x3115f9(%rip)        # aba170 <_DYNAMIC+0x300>
  7a8b77:	mov    %r15,(%rbx)
  7a8b7a:	mov    %r13d,0x8(%rbx)
  7a8b7e:	mov    %r12d,0xc(%rbx)
  7a8b82:	movaps 0x10(%rsp),%xmm0
  7a8b87:	movaps 0x20(%rsp),%xmm1
  7a8b8c:	movups %xmm0,0x10(%rbx)
  7a8b90:	movups %xmm1,0x20(%rbx)
  7a8b94:	mov    0x30(%rsp),%rcx
  7a8b99:	mov    %rcx,0x30(%rbx)
  7a8b9d:	mov    %ebp,0x38(%rbx)
  7a8ba0:	mov    0x8(%rsp),%ecx
  7a8ba4:	mov    %ecx,0x3c(%rbx)
  7a8ba7:	mov    %rax,%rdi
  7a8baa:	call   a98590 <_Unwind_Resume@plt>

gpui::runtime::image::acknowledge bytes=157 frame=40

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007ab050 <_RNvNtNtCslbxve4rcJus_4gpui7runtime5image11acknowledge>:
  7ab050:	push   %r15
  7ab052:	push   %r14
  7ab054:	push   %rbx
  7ab055:	sub    $0x10,%rsp
  7ab059:	mov    (%rdi),%r14
  7ab05c:	test   %r14,%r14
  7ab05f:	je     7ab0bf <_RNvNtNtCslbxve4rcJus_4gpui7runtime5image11acknowledge+0x6f>
  7ab061:	mov    %rdi,%rbx
  7ab064:	mov    0x38(%r14),%r15
  7ab068:	cmp    $0xffffffffffffffff,%r15
  7ab06c:	je     7ab09b <_RNvNtNtCslbxve4rcJus_4gpui7runtime5image11acknowledge+0x4b>
  7ab06e:	cmp    %rsi,0x30(%r14)
  7ab072:	jne    7ab09b <_RNvNtNtCslbxve4rcJus_4gpui7runtime5image11acknowledge+0x4b>
  7ab074:	movups 0x40(%r14),%xmm0
  7ab079:	movaps %xmm0,(%rsp)
  7ab07d:	movq   $0xffffffffffffffff,0x38(%r14)
  7ab085:	lea    0x18(%r14),%rdi
  7ab089:	call   79a110 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCsghYClfd3M9V_11gpui_canvas5image5ImageEECslbxve4rcJus_4gpui>
  7ab08e:	mov    %r15,0x18(%r14)
  7ab092:	movaps (%rsp),%xmm0
  7ab096:	movups %xmm0,0x20(%r14)
  7ab09b:	cmpq   $0x0,0x10(%r14)
  7ab0a0:	jne    7ab0bf <_RNvNtNtCslbxve4rcJus_4gpui7runtime5image11acknowledge+0x6f>
  7ab0a2:	cmpq   $0x0,0x28(%r14)
  7ab0a7:	jne    7ab0bf <_RNvNtNtCslbxve4rcJus_4gpui7runtime5image11acknowledge+0x6f>
  7ab0a9:	cmpq   $0xffffffffffffffff,0x38(%r14)
  7ab0ae:	jne    7ab0bf <_RNvNtNtCslbxve4rcJus_4gpui7runtime5image11acknowledge+0x6f>
  7ab0b0:	mov    %r14,%rdi
  7ab0b3:	call   799e80 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionINtNtCscdodAO9FK5_5alloc5boxed3BoxNtNtNtCslbxve4rcJus_4gpui7runtime5image6ImagesEEEB1B_>
  7ab0b8:	movq   $0x0,(%rbx)
  7ab0bf:	add    $0x10,%rsp
  7ab0c3:	pop    %rbx
  7ab0c4:	pop    %r14
  7ab0c6:	pop    %r15
  7ab0c8:	ret
  7ab0c9:	movq   $0x0,(%rbx)
  7ab0d0:	mov    %rax,%rdi
  7ab0d3:	call   a98590 <_Unwind_Resume@plt>
  7ab0d8:	mov    %r15,0x18(%r14)
  7ab0dc:	movaps (%rsp),%xmm0
  7ab0e0:	movups %xmm0,0x20(%r14)
  7ab0e5:	mov    %rax,%rdi
  7ab0e8:	call   a98590 <_Unwind_Resume@plt>

core::ptr::drop_glue::<core::option::Option<gpui_canvas::text::layout::TextGeometry>> bytes=108 frame=8

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007bbc90 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryEEB13_>:
  7bbc90:	push   %rbx
  7bbc91:	mov    (%rdi),%rax
  7bbc94:	cmp    $0xffffffffffffffff,%rax
  7bbc98:	je     7bbcfa <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryEEB13_+0x6a>
  7bbc9a:	mov    %rdi,%rbx
  7bbc9d:	test   %rax,%rax
  7bbca0:	je     7bbcb9 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryEEB13_+0x29>
  7bbca2:	mov    0x8(%rbx),%rdi
  7bbca6:	shl    $0x3,%rax
  7bbcaa:	lea    (%rax,%rax,2),%rsi
  7bbcae:	mov    $0x4,%edx
  7bbcb3:	call   *0x2fe3f7(%rip)        # aba0b0 <_DYNAMIC+0x240>
  7bbcb9:	mov    0x18(%rbx),%rax
  7bbcbd:	test   %rax,%rax
  7bbcc0:	je     7bbcd9 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryEEB13_+0x49>
  7bbcc2:	mov    0x20(%rbx),%rdi
  7bbcc6:	shl    $0x3,%rax
  7bbcca:	lea    (%rax,%rax,2),%rsi
  7bbcce:	mov    $0x4,%edx
  7bbcd3:	call   *0x2fe3d7(%rip)        # aba0b0 <_DYNAMIC+0x240>
  7bbcd9:	mov    0x30(%rbx),%rax
  7bbcdd:	test   %rax,%rax
  7bbce0:	jle    7bbcfa <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryEEB13_+0x6a>
  7bbce2:	mov    0x38(%rbx),%rdi
  7bbce6:	shl    $0x2,%rax
  7bbcea:	lea    (%rax,%rax,2),%rsi
  7bbcee:	mov    $0x4,%edx
  7bbcf3:	pop    %rbx
  7bbcf4:	jmp    *0x2fe3b6(%rip)        # aba0b0 <_DYNAMIC+0x240>
  7bbcfa:	pop    %rbx
  7bbcfb:	ret

core::ptr::drop_glue::<alloc::sync::ArcInner<gpui_canvas::text::layout::TextGeometry>> bytes=103 frame=8

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007bc9d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc4sync8ArcInnerNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryEEB1j_>:
  7bc9d0:	push   %rbx
  7bc9d1:	mov    %rdi,%rbx
  7bc9d4:	mov    0x10(%rdi),%rax
  7bc9d8:	test   %rax,%rax
  7bc9db:	je     7bc9f4 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc4sync8ArcInnerNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryEEB1j_+0x24>
  7bc9dd:	mov    0x18(%rbx),%rdi
  7bc9e1:	shl    $0x3,%rax
  7bc9e5:	lea    (%rax,%rax,2),%rsi
  7bc9e9:	mov    $0x4,%edx
  7bc9ee:	call   *0x2fd6bc(%rip)        # aba0b0 <_DYNAMIC+0x240>
  7bc9f4:	mov    0x28(%rbx),%rax
  7bc9f8:	test   %rax,%rax
  7bc9fb:	je     7bca14 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc4sync8ArcInnerNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryEEB1j_+0x44>
  7bc9fd:	mov    0x30(%rbx),%rdi
  7bca01:	shl    $0x3,%rax
  7bca05:	lea    (%rax,%rax,2),%rsi
  7bca09:	mov    $0x4,%edx
  7bca0e:	call   *0x2fd69c(%rip)        # aba0b0 <_DYNAMIC+0x240>
  7bca14:	mov    0x40(%rbx),%rax
  7bca18:	test   %rax,%rax
  7bca1b:	jle    7bca35 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc4sync8ArcInnerNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryEEB1j_+0x65>
  7bca1d:	mov    0x48(%rbx),%rdi
  7bca21:	shl    $0x2,%rax
  7bca25:	lea    (%rax,%rax,2),%rsi
  7bca29:	mov    $0x4,%edx
  7bca2e:	pop    %rbx
  7bca2f:	jmp    *0x2fd67b(%rip)        # aba0b0 <_DYNAMIC+0x240>
  7bca35:	pop    %rbx
  7bca36:	ret

<gpui_canvas::text::layout::TextGeometry>::intervals::{closure#1} bytes=791 frame=56

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007c9720 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_>:
  7c9720:	push   %rbp
  7c9721:	push   %r15
  7c9723:	push   %r14
  7c9725:	push   %r13
  7c9727:	push   %r12
  7c9729:	push   %rbx
  7c972a:	push   %rax
  7c972b:	mov    (%rdx),%r9
  7c972e:	mov    0x8(%rdx),%rcx
  7c9732:	mov    0x10(%rdx),%r10
  7c9736:	mov    0x18(%rdx),%rax
  7c973a:	shl    $0x2,%rcx
  7c973e:	lea    (%rcx,%rcx,2),%rcx
  7c9742:	xor    %ebx,%ebx
  7c9744:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  7c9750:	cmp    %rbx,%rcx
  7c9753:	je     7c98c4 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x1a4>
  7c9759:	movzbl 0x8(%r9,%rbx,1),%r11d
  7c975f:	add    $0xc,%rbx
  7c9763:	test   $0x2,%r11b
  7c9767:	je     7c9750 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x30>
  7c9769:	shl    $0x2,%rax
  7c976d:	lea    (%rax,%rax,2),%rax
  7c9771:	xor    %ecx,%ecx
  7c9773:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  7c9780:	cmp    %rcx,%rax
  7c9783:	je     7c98c4 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x1a4>
  7c9789:	lea    0xc(%rcx),%r14
  7c978d:	testb  $0x1,0x8(%r10,%rcx,1)
  7c9793:	mov    %r14,%rcx
  7c9796:	je     7c9780 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x60>
  7c9798:	mov    -0xc(%r9,%rbx,1),%edx
  7c979d:	mov    0x20(%rsi),%r15
  7c97a1:	mov    0x28(%rsi),%rcx
  7c97a5:	mov    %rcx,%rax
  7c97a8:	test   %rcx,%rcx
  7c97ab:	je     7c97f9 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0xd9>
  7c97ad:	xor    %r8d,%r8d
  7c97b0:	cmp    $0x1,%rcx
  7c97b4:	je     7c97e1 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0xc1>
  7c97b6:	mov    %rcx,%rax
  7c97b9:	nopl   0x0(%rax)
  7c97c0:	mov    %r8,%r12
  7c97c3:	mov    %rax,%r13
  7c97c6:	shr    $1,%r13
  7c97c9:	add    %r13,%r8
  7c97cc:	lea    (%r8,%r8,2),%rbp
  7c97d0:	cmp    %edx,(%r15,%rbp,8)
  7c97d4:	cmova  %r12,%r8
  7c97d8:	sub    %r13,%rax
  7c97db:	cmp    $0x1,%rax
  7c97df:	ja     7c97c0 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0xa0>
  7c97e1:	lea    (%r8,%r8,2),%r12
  7c97e5:	xor    %eax,%eax
  7c97e7:	cmp    %edx,(%r15,%r12,8)
  7c97eb:	setbe  %al
  7c97ee:	add    %r8,%rax
  7c97f1:	cmp    $0x1,%rax
  7c97f5:	adc    $0xffffffffffffffff,%rax
  7c97f9:	cmp    %rcx,%rax
  7c97fc:	jae    7c9a11 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x2f1>
  7c9802:	lea    (%rax,%rax,2),%r12
  7c9806:	mov    %rax,%r8
  7c9809:	test   %rax,%rax
  7c980c:	je     7c9883 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x163>
  7c980e:	mov    %rax,%r8
  7c9811:	test   %edx,%edx
  7c9813:	je     7c9883 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x163>
  7c9815:	mov    %rax,%r8
  7c9818:	and    $0x1,%r11b
  7c981c:	je     7c9883 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x163>
  7c981e:	lea    (%r15,%r12,8),%r11
  7c9822:	mov    %rax,%r8
  7c9825:	cmp    %edx,-0x14(%r11)
  7c9829:	jne    7c9883 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x163>
  7c982b:	xor    %r8d,%r8d
  7c982e:	mov    %rcx,%r11
  7c9831:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  7c9840:	mov    %r11,%r13
  7c9843:	shr    $1,%r13
  7c9846:	lea    (%r8,%r13,1),%rbp
  7c984a:	lea    0x0(,%rbp,2),%r12
  7c9852:	add    %rbp,%r12
  7c9855:	cmp    %edx,0x4(%r15,%r12,8)
  7c985a:	cmovb  %rbp,%r8
  7c985e:	sub    %r13,%r11
  7c9861:	cmp    $0x1,%r11
  7c9865:	ja     7c9840 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x120>
  7c9867:	lea    (%r8,%r8,2),%r11
  7c986b:	cmp    %edx,0x4(%r15,%r11,8)
  7c9870:	adc    $0x0,%r8
  7c9874:	lea    -0x1(%rcx),%r11
  7c9878:	cmp    %r8,%r11
  7c987b:	cmovb  %r11,%r8
  7c987f:	lea    (%rax,%rax,2),%r12
  7c9883:	cmp    %rcx,%r8
  7c9886:	jae    7c9a24 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x304>
  7c988c:	mov    -0xc(%r10,%r14,1),%ecx
  7c9891:	mov    0x4(%r15,%r12,8),%r11d
  7c9896:	lea    (%r8,%r8,2),%r8
  7c989a:	lea    (%r15,%r8,8),%r8
  7c989e:	movss  -0x8(%r9,%rbx,1),%xmm1
  7c98a5:	movss  -0x8(%r10,%r14,1),%xmm2
  7c98ac:	cmp    %r11d,%ecx
  7c98af:	ja     7c98cd <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x1ad>
  7c98b1:	ucomiss %xmm2,%xmm1
  7c98b4:	jne    7c98b8 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x198>
  7c98b6:	jnp    7c98cd <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x1ad>
  7c98b8:	ucomiss %xmm1,%xmm2
  7c98bb:	setbe  %sil
  7c98bf:	jmp    7c997a <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x25a>
  7c98c4:	movb   $0x2,0x4(%rdi)
  7c98c8:	jmp    7c99e9 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x2c9>
  7c98cd:	mov    0x8(%rsi),%r9
  7c98d1:	mov    0x10(%rsi),%rsi
  7c98d5:	mov    %rsi,%r10
  7c98d8:	test   %rsi,%rsi
  7c98db:	je     7c9923 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x203>
  7c98dd:	xor    %r10d,%r10d
  7c98e0:	cmp    $0x1,%rsi
  7c98e4:	je     7c9913 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x1f3>
  7c98e6:	mov    %rsi,%rbx
  7c98e9:	nopl   0x0(%rax)
  7c98f0:	mov    %rbx,%r14
  7c98f3:	shr    $1,%r14
  7c98f6:	lea    (%r14,%r10,1),%r15
  7c98fa:	lea    (%r15,%r15,2),%r12
  7c98fe:	mov    0x10(%r9,%r12,8),%r12d
  7c9903:	cmp    %r12,%rax
  7c9906:	cmova  %r15,%r10
  7c990a:	sub    %r14,%rbx
  7c990d:	cmp    $0x1,%rbx
  7c9911:	ja     7c98f0 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x1d0>
  7c9913:	lea    (%r10,%r10,2),%rbx
  7c9917:	mov    0x10(%r9,%rbx,8),%ebx
  7c991c:	cmp    %rax,%rbx
  7c991f:	adc    $0x0,%r10
  7c9923:	shl    $0x3,%r10
  7c9927:	lea    (%r10,%r10,2),%r10
  7c992b:	lea    (%r9,%r10,1),%rbx
  7c992f:	shl    $0x3,%rsi
  7c9933:	lea    (%rsi,%rsi,2),%rsi
  7c9937:	nopw   0x0(%rax,%rax,1)
  7c9940:	cmp    %r10,%rsi
  7c9943:	je     7c99f8 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x2d8>
  7c9949:	mov    %rbx,%r14
  7c994c:	mov    0x10(%rbx),%ebx
  7c994f:	cmp    %rbx,%rax
  7c9952:	jne    7c99f8 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x2d8>
  7c9958:	lea    0x18(%r14),%rbx
  7c995c:	add    $0x18,%r10
  7c9960:	cmp    %edx,(%r14)
  7c9963:	ja     7c9940 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x220>
  7c9965:	cmp    0x4(%r14),%edx
  7c9969:	ja     7c9940 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x220>
  7c996b:	movzbl -0x3(%r9,%r10,1),%esi
  7c9971:	cmp    %r11d,%ecx
  7c9974:	ja     7c9a03 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x2e3>
  7c997a:	movaps %xmm1,%xmm0
  7c997d:	minss  %xmm2,%xmm0
  7c9981:	movaps %xmm0,%xmm3
  7c9984:	cmpunordss %xmm0,%xmm3
  7c9989:	movaps %xmm3,%xmm4
  7c998c:	andnps %xmm0,%xmm4
  7c998f:	andps  %xmm1,%xmm3
  7c9992:	orps   %xmm4,%xmm3
  7c9995:	movaps %xmm2,%xmm0
  7c9998:	subss  %xmm1,%xmm0
  7c999c:	andps  -0x706503(%rip),%xmm0        # c34a0 <GCC_except_table0+0x10d4>
  7c99a3:	cmp    %r11d,%ecx
  7c99a6:	movss  0x8(%r8),%xmm4
  7c99ac:	movss  0xc(%r8),%xmm5
  7c99b2:	mov    %edx,(%rdi)
  7c99b4:	movb   $0x1,0x4(%rdi)
  7c99b8:	mov    %ecx,0x8(%rdi)
  7c99bb:	movb   $0x0,0xc(%rdi)
  7c99bf:	movss  %xmm3,0x10(%rdi)
  7c99c4:	movss  %xmm4,0x14(%rdi)
  7c99c9:	movss  %xmm0,0x18(%rdi)
  7c99ce:	movss  %xmm5,0x1c(%rdi)
  7c99d3:	mov    %rax,0x20(%rdi)
  7c99d7:	movss  %xmm1,0x28(%rdi)
  7c99dc:	movss  %xmm2,0x2c(%rdi)
  7c99e1:	seta   0x30(%rdi)
  7c99e5:	mov    %sil,0x31(%rdi)
  7c99e9:	add    $0x8,%rsp
  7c99ed:	pop    %rbx
  7c99ee:	pop    %r12
  7c99f0:	pop    %r13
  7c99f2:	pop    %r14
  7c99f4:	pop    %r15
  7c99f6:	pop    %rbp
  7c99f7:	ret
  7c99f8:	xor    %esi,%esi
  7c99fa:	cmp    %r11d,%ecx
  7c99fd:	jbe    7c997a <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x25a>
  7c9a03:	movaps %xmm1,%xmm3
  7c9a06:	test   %sil,%sil
  7c9a09:	je     7c99a3 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x283>
  7c9a0b:	subss  %xmm0,%xmm3
  7c9a0f:	jmp    7c99a3 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x283>
  7c9a11:	lea    0x2d4180(%rip),%rdx        # a9db98 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0xf00>
  7c9a18:	mov    %rax,%rdi
  7c9a1b:	mov    %rcx,%rsi
  7c9a1e:	call   *0x2f06bc(%rip)        # aba0e0 <_DYNAMIC+0x270>
  7c9a24:	lea    0x2d4185(%rip),%rdx        # a9dbb0 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0xf18>
  7c9a2b:	mov    %r8,%rdi
  7c9a2e:	mov    %rcx,%rsi
  7c9a31:	call   *0x2f06a9(%rip)        # aba0e0 <_DYNAMIC+0x270>

<gpui_canvas::text::layout::TextGeometry>::grapheme_at bytes=850 frame=376

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007d5820 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at>:
  7d5820:	push   %rbp
  7d5821:	push   %r15
  7d5823:	push   %r14
  7d5825:	push   %r13
  7d5827:	push   %r12
  7d5829:	push   %rbx
  7d582a:	sub    $0x148,%rsp
  7d5831:	mov    %rdi,%rbx
  7d5834:	movd   %xmm1,%eax
  7d5838:	movd   %xmm0,0x4(%rsp)
  7d583e:	movd   %xmm0,%ecx
  7d5842:	and    $0x7fffffff,%ecx
  7d5848:	cmp    $0x7f800000,%ecx
  7d584e:	setge  %cl
  7d5851:	and    $0x7fffffff,%eax
  7d5856:	cmp    $0x7f800000,%eax
  7d585b:	setge  %al
  7d585e:	or     %cl,%al
  7d5860:	cmp    $0x1,%al
  7d5862:	jne    7d586d <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x4d>
  7d5864:	movb   $0x2,0x4(%rbx)
  7d5868:	jmp    7d5b3d <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x31d>
  7d586d:	mov    0x20(%rsi),%rdx
  7d5871:	mov    0x28(%rsi),%rax
  7d5875:	mov    %rax,%r14
  7d5878:	test   %rax,%rax
  7d587b:	je     7d58ce <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0xae>
  7d587d:	xor    %ecx,%ecx
  7d587f:	cmp    $0x1,%rax
  7d5883:	je     7d58b3 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x93>
  7d5885:	mov    %rax,%rdi
  7d5888:	nopl   0x0(%rax,%rax,1)
  7d5890:	mov    %rcx,%r8
  7d5893:	mov    %rdi,%r9
  7d5896:	shr    $1,%r9
  7d5899:	add    %r9,%rcx
  7d589c:	lea    (%rcx,%rcx,2),%r10
  7d58a0:	ucomiss 0x8(%rdx,%r10,8),%xmm1
  7d58a6:	cmovb  %r8,%rcx
  7d58aa:	sub    %r9,%rdi
  7d58ad:	cmp    $0x1,%rdi
  7d58b1:	ja     7d5890 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x70>
  7d58b3:	lea    (%rcx,%rcx,2),%rdi
  7d58b7:	xor    %r14d,%r14d
  7d58ba:	ucomiss 0x8(%rdx,%rdi,8),%xmm1
  7d58bf:	setae  %r14b
  7d58c3:	add    %rcx,%r14
  7d58c6:	cmp    $0x1,%r14
  7d58ca:	adc    $0xffffffffffffffff,%r14
  7d58ce:	mov    %r14,0x8(%rsp)
  7d58d3:	xor    %ecx,%ecx
  7d58d5:	cmpq   $0xffffffffffffffff,0x30(%rsi)
  7d58da:	mov    0x40(%rsi),%r8
  7d58de:	cmovne %r8,%rcx
  7d58e2:	mov    $0x4,%edi
  7d58e7:	cmovne 0x38(%rsi),%rdi
  7d58ec:	cmp    %rax,%r14
  7d58ef:	jae    7d5b5f <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x33f>
  7d58f5:	lea    (%r14,%r14,2),%rax
  7d58f9:	mov    (%rdx,%rax,8),%edx
  7d58fc:	test   %edx,%edx
  7d58fe:	je     7d593d <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x11d>
  7d5900:	mov    %rcx,%rax
  7d5903:	test   %rcx,%rcx
  7d5906:	je     7d593f <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x11f>
  7d5908:	xor    %eax,%eax
  7d590a:	cmp    $0x1,%rcx
  7d590e:	je     7d592f <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x10f>
  7d5910:	mov    %r8,%r9
  7d5913:	shr    $1,%r9
  7d5916:	lea    (%r9,%rax,1),%r10
  7d591a:	lea    (%r10,%r10,2),%r11
  7d591e:	cmp    %edx,(%rdi,%r11,4)
  7d5922:	cmovb  %r10,%rax
  7d5926:	sub    %r9,%r8
  7d5929:	cmp    $0x1,%r8
  7d592d:	ja     7d5910 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0xf0>
  7d592f:	lea    (%rax,%rax,2),%r8
  7d5933:	cmp    %edx,(%rdi,%r8,4)
  7d5937:	adc    $0x0,%rax
  7d593b:	jmp    7d593f <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x11f>
  7d593d:	xor    %eax,%eax
  7d593f:	movss  %xmm1,(%rsp)
  7d5944:	sub    %rax,%rcx
  7d5947:	lea    (%rax,%rax,2),%rax
  7d594b:	lea    (%rdi,%rax,4),%rax
  7d594f:	movss  0x4c(%rsi),%xmm0
  7d5954:	mulss  -0x713484(%rip),%xmm0        # c24d8 <GCC_except_table0+0x10c>
  7d595c:	xorps  %xmm1,%xmm1
  7d595f:	movups %xmm1,0x38(%rsp)
  7d5964:	mov    %rax,0x10(%rsp)
  7d5969:	mov    %rcx,0x18(%rsp)
  7d596e:	mov    %rax,0x20(%rsp)
  7d5973:	mov    %rcx,0x28(%rsp)
  7d5978:	movq   $0x1,0x30(%rsp)
  7d5981:	mov    %rsi,0x48(%rsp)
  7d5986:	movss  %xmm0,0x50(%rsp)
  7d598c:	movb   $0x0,0x68(%rsp)
  7d5991:	mov    %rsi,0x58(%rsp)
  7d5996:	lea    0x8(%rsp),%rax
  7d599b:	mov    %rax,0x60(%rsp)
  7d59a0:	lea    0xf0(%rsp),%rdi
  7d59a8:	lea    0x10(%rsp),%rsi
  7d59ad:	call   7e8130 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextB1u_>
  7d59b2:	cmpq   $0x0,0xf0(%rsp)
  7d59bb:	je     7d5b38 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x318>
  7d59c1:	lea    0x110(%rsp),%r12
  7d59c9:	lea    0xf0(%rsp),%r13
  7d59d1:	lea    0x10(%rsp),%rbp
  7d59d6:	jmp    7d59fa <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x1da>
  7d59d8:	nopl   0x0(%rax,%rax,1)
  7d59e0:	mov    %r13,%rdi
  7d59e3:	mov    %rbp,%rsi
  7d59e6:	call   7e8130 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextB1u_>
  7d59eb:	cmpq   $0x0,0xf0(%rsp)
  7d59f4:	je     7d5b38 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x318>
  7d59fa:	mov    0x48(%rsp),%rsi
  7d59ff:	movss  0x50(%rsp),%xmm0
  7d5a05:	mov    %r12,%rdi
  7d5a08:	mov    %r13,%rdx
  7d5a0b:	call   7c9720 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_>
  7d5a10:	cmpb   $0x2,0x114(%rsp)
  7d5a18:	je     7d59e0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x1c0>
  7d5a1a:	mov    0x140(%rsp),%rax
  7d5a22:	mov    %rax,0xe0(%rsp)
  7d5a2a:	movups 0x110(%rsp),%xmm0
  7d5a32:	movups 0x120(%rsp),%xmm1
  7d5a3a:	movups 0x130(%rsp),%xmm2
  7d5a42:	movaps %xmm2,0xd0(%rsp)
  7d5a4a:	movaps %xmm1,0xc0(%rsp)
  7d5a52:	movaps %xmm0,0xb0(%rsp)
  7d5a5a:	mov    0x58(%rsp),%rax
  7d5a5f:	mov    0x60(%rsp),%rcx
  7d5a64:	mov    (%rcx),%rdi
  7d5a67:	mov    0x28(%rax),%rsi
  7d5a6b:	cmp    %rsi,%rdi
  7d5a6e:	jae    7d5b52 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x332>
  7d5a74:	mov    0xb0(%rsp),%r15d
  7d5a7c:	mov    0x20(%rax),%rax
  7d5a80:	lea    (%rdi,%rdi,2),%rcx
  7d5a84:	cmp    0x4(%rax,%rcx,8),%r15d
  7d5a89:	ja     7d5b38 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x318>
  7d5a8f:	cmp    %r14,0xd0(%rsp)
  7d5a97:	jne    7d59e0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x1c0>
  7d5a9d:	lea    0xc0(%rsp),%rdi
  7d5aa5:	movss  0x4(%rsp),%xmm0
  7d5aab:	movss  (%rsp),%xmm1
  7d5ab0:	call   *0x2e4a4a(%rip)        # aba500 <_DYNAMIC+0x690>
  7d5ab6:	test   %al,%al
  7d5ab8:	je     7d59e0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x1c0>
  7d5abe:	movzbl 0xb4(%rsp),%eax
  7d5ac6:	cmp    $0x2,%al
  7d5ac8:	je     7d59e0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x1c0>
  7d5ace:	lea    0x115(%rsp),%rdx
  7d5ad6:	mov    0x2f(%rdx),%ecx
  7d5ad9:	mov    %ecx,0x9f(%rsp)
  7d5ae0:	movups (%rdx),%xmm0
  7d5ae3:	movups 0x10(%rdx),%xmm1
  7d5ae7:	movups 0x20(%rdx),%xmm2
  7d5aeb:	movaps %xmm2,0x90(%rsp)
  7d5af3:	movaps %xmm1,0x80(%rsp)
  7d5afb:	movaps %xmm0,0x70(%rsp)
  7d5b00:	cmp    $0xff,%al
  7d5b02:	je     7d59e0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x1c0>
  7d5b08:	mov    0x9f(%rsp),%ecx
  7d5b0f:	mov    %ecx,0x34(%rbx)
  7d5b12:	movaps 0x70(%rsp),%xmm0
  7d5b17:	movaps 0x80(%rsp),%xmm1
  7d5b1f:	movaps 0x90(%rsp),%xmm2
  7d5b27:	movups %xmm2,0x25(%rbx)
  7d5b2b:	movups %xmm1,0x15(%rbx)
  7d5b2f:	movups %xmm0,0x5(%rbx)
  7d5b33:	mov    %r15d,(%rbx)
  7d5b36:	jmp    7d5b3a <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x31a>
  7d5b38:	mov    $0x2,%al
  7d5b3a:	mov    %al,0x4(%rbx)
  7d5b3d:	mov    %rbx,%rax
  7d5b40:	add    $0x148,%rsp
  7d5b47:	pop    %rbx
  7d5b48:	pop    %r12
  7d5b4a:	pop    %r13
  7d5b4c:	pop    %r14
  7d5b4e:	pop    %r15
  7d5b50:	pop    %rbp
  7d5b51:	ret
  7d5b52:	lea    0x2c7faf(%rip),%rdx        # a9db08 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0xe70>
  7d5b59:	call   *0x2e4581(%rip)        # aba0e0 <_DYNAMIC+0x270>
  7d5b5f:	lea    0x2c88da(%rip),%rdx        # a9e440 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0x17a8>
  7d5b66:	mov    %r14,%rdi
  7d5b69:	mov    %rax,%rsi
  7d5b6c:	call   *0x2e456e(%rip)        # aba0e0 <_DYNAMIC+0x270>

<gpui_canvas::text::layout::TextGeometry>::move_visual bytes=1691 frame=328

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007d5b80 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual>:
  7d5b80:	push   %rbp
  7d5b81:	push   %r15
  7d5b83:	push   %r14
  7d5b85:	push   %r13
  7d5b87:	push   %r12
  7d5b89:	push   %rbx
  7d5b8a:	sub    $0x118,%rsp
  7d5b91:	mov    %ecx,%r15d
  7d5b94:	mov    %edx,%r14d
  7d5b97:	mov    %esi,%ebp
  7d5b99:	mov    %rdi,%rbx
  7d5b9c:	lea    0x48(%rsp),%rdi
  7d5ba1:	mov    %rbx,%rsi
  7d5ba4:	mov    %ebp,%edx
  7d5ba6:	mov    %r14d,%ecx
  7d5ba9:	call   *0x2e4e61(%rip)        # abaa10 <_DYNAMIC+0xba0>
  7d5baf:	cmpl   $0x1,0x48(%rsp)
  7d5bb4:	jne    7d5c2b <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0xab>
  7d5bb6:	test   %ebp,%ebp
  7d5bb8:	setne  %cl
  7d5bbb:	mov    %r14d,%edx
  7d5bbe:	not    %dl
  7d5bc0:	mov    0x20(%rbx),%rax
  7d5bc4:	mov    0x28(%rbx),%r11
  7d5bc8:	mov    %r11,%rdi
  7d5bcb:	test   %cl,%dl
  7d5bcd:	jne    7d5c32 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0xb2>
  7d5bcf:	test   %r11,%r11
  7d5bd2:	je     7d5c87 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x107>
  7d5bd8:	xor    %ecx,%ecx
  7d5bda:	cmp    $0x1,%r11
  7d5bde:	je     7d5c11 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x91>
  7d5be0:	mov    %r11,%rdx
  7d5be3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  7d5bf0:	mov    %rcx,%rsi
  7d5bf3:	mov    %rdx,%rdi
  7d5bf6:	shr    $1,%rdi
  7d5bf9:	add    %rdi,%rcx
  7d5bfc:	lea    (%rcx,%rcx,2),%r8
  7d5c00:	cmp    %ebp,(%rax,%r8,8)
  7d5c04:	cmova  %rsi,%rcx
  7d5c08:	sub    %rdi,%rdx
  7d5c0b:	cmp    $0x1,%rdx
  7d5c0f:	ja     7d5bf0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x70>
  7d5c11:	lea    (%rcx,%rcx,2),%rdx
  7d5c15:	xor    %edi,%edi
  7d5c17:	cmp    %ebp,(%rax,%rdx,8)
  7d5c1a:	setbe  %dil
  7d5c1e:	add    %rcx,%rdi
  7d5c21:	cmp    $0x1,%rdi
  7d5c25:	adc    $0xffffffffffffffff,%rdi
  7d5c29:	jmp    7d5c87 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x107>
  7d5c2b:	mov    $0x2,%dl
  7d5c2d:	jmp    7d61ea <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x66a>
  7d5c32:	test   %r11,%r11
  7d5c35:	je     7d5c7c <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0xfc>
  7d5c37:	xor    %edi,%edi
  7d5c39:	cmp    $0x1,%r11
  7d5c3d:	je     7d5c70 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0xf0>
  7d5c3f:	mov    %r11,%rcx
  7d5c42:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  7d5c50:	mov    %rcx,%rdx
  7d5c53:	shr    $1,%rdx
  7d5c56:	lea    (%rdx,%rdi,1),%rsi
  7d5c5a:	lea    (%rsi,%rsi,2),%r8
  7d5c5e:	cmp    %ebp,0x4(%rax,%r8,8)
  7d5c63:	cmovb  %rsi,%rdi
  7d5c67:	sub    %rdx,%rcx
  7d5c6a:	cmp    $0x1,%rcx
  7d5c6e:	ja     7d5c50 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0xd0>
  7d5c70:	lea    (%rdi,%rdi,2),%rcx
  7d5c74:	cmp    %ebp,0x4(%rax,%rcx,8)
  7d5c78:	adc    $0x0,%rdi
  7d5c7c:	lea    -0x1(%r11),%rcx
  7d5c80:	cmp    %rdi,%rcx
  7d5c83:	cmovb  %rcx,%rdi
  7d5c87:	movss  0x4c(%rsp),%xmm0
  7d5c8d:	movss  %xmm0,0x18(%rsp)
  7d5c93:	mov    %rdi,0x38(%rsp)
  7d5c98:	xor    %ecx,%ecx
  7d5c9a:	cmpq   $0xffffffffffffffff,0x30(%rbx)
  7d5c9f:	mov    0x40(%rbx),%rsi
  7d5ca3:	cmovne %rsi,%rcx
  7d5ca7:	mov    $0x4,%edx
  7d5cac:	cmovne 0x38(%rbx),%rdx
  7d5cb1:	cmp    %r11,%rdi
  7d5cb4:	jae    7d620b <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x68b>
  7d5cba:	lea    (%rdi,%rdi,2),%rdi
  7d5cbe:	mov    (%rax,%rdi,8),%edi
  7d5cc1:	test   %edi,%edi
  7d5cc3:	mov    %r15d,0x20(%rsp)
  7d5cc8:	je     7d5d0c <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x18c>
  7d5cca:	mov    %rcx,%rax
  7d5ccd:	test   %rcx,%rcx
  7d5cd0:	je     7d5d0e <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x18e>
  7d5cd2:	xor    %eax,%eax
  7d5cd4:	cmp    $0x1,%rcx
  7d5cd8:	je     7d5cff <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x17f>
  7d5cda:	nopw   0x0(%rax,%rax,1)
  7d5ce0:	mov    %rsi,%r8
  7d5ce3:	shr    $1,%r8
  7d5ce6:	lea    (%r8,%rax,1),%r9
  7d5cea:	lea    (%r9,%r9,2),%r10
  7d5cee:	cmp    %edi,(%rdx,%r10,4)
  7d5cf2:	cmovb  %r9,%rax
  7d5cf6:	sub    %r8,%rsi
  7d5cf9:	cmp    $0x1,%rsi
  7d5cfd:	ja     7d5ce0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x160>
  7d5cff:	lea    (%rax,%rax,2),%rsi
  7d5d03:	cmp    %edi,(%rdx,%rsi,4)
  7d5d06:	adc    $0x0,%rax
  7d5d0a:	jmp    7d5d0e <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x18e>
  7d5d0c:	xor    %eax,%eax
  7d5d0e:	sub    %rax,%rcx
  7d5d11:	lea    (%rax,%rax,2),%rax
  7d5d15:	lea    (%rdx,%rax,4),%rax
  7d5d19:	movss  0x4c(%rbx),%xmm0
  7d5d1e:	mulss  -0x71384e(%rip),%xmm0        # c24d8 <GCC_except_table0+0x10c>
  7d5d26:	xorps  %xmm1,%xmm1
  7d5d29:	movups %xmm1,0x78(%rsp)
  7d5d2e:	lea    0x38(%rsp),%rdx
  7d5d33:	mov    %rdx,0x48(%rsp)
  7d5d38:	lea    0x50(%rsp),%rsi
  7d5d3d:	mov    %rax,0x50(%rsp)
  7d5d42:	mov    %rcx,0x58(%rsp)
  7d5d47:	mov    %rax,0x60(%rsp)
  7d5d4c:	mov    %rcx,0x68(%rsp)
  7d5d51:	movq   $0x1,0x70(%rsp)
  7d5d5a:	mov    %rbx,0x88(%rsp)
  7d5d62:	movss  %xmm0,0x90(%rsp)
  7d5d6b:	mov    %rbx,0x98(%rsp)
  7d5d73:	mov    %rdx,0xa0(%rsp)
  7d5d7b:	movb   $0x0,0xa8(%rsp)
  7d5d83:	movss  -0x71381b(%rip),%xmm0        # c2570 <GCC_except_table0+0x1a4>
  7d5d8b:	movss  %xmm0,0x1c(%rsp)
  7d5d91:	mov    $0x2,%al
  7d5d93:	mov    %eax,0x24(%rsp)
  7d5d97:	lea    0xc0(%rsp),%rdi
  7d5d9f:	mov    %rbx,0x30(%rsp)
  7d5da4:	mov    %ebp,0x14(%rsp)
  7d5da8:	mov    %r14d,0x10(%rsp)
  7d5dad:	mov    %r11,0x28(%rsp)
  7d5db2:	call   7e8130 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextB1u_>
  7d5db7:	cmpq   $0x0,0xc0(%rsp)
  7d5dc0:	je     7d614b <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x5cb>
  7d5dc6:	mov    0x88(%rsp),%rax
  7d5dce:	mov    %rax,0xb8(%rsp)
  7d5dd6:	movss  0x90(%rsp),%xmm0
  7d5ddf:	movss  %xmm0,0x44(%rsp)
  7d5de5:	mov    0x50(%rsp),%r14
  7d5dea:	mov    0x58(%rsp),%r13
  7d5def:	mov    0x70(%rsp),%r12
  7d5df4:	mov    0x60(%rsp),%rbp
  7d5df9:	mov    0x98(%rsp),%r15
  7d5e01:	mov    0xa0(%rsp),%rax
  7d5e09:	mov    %rax,0xb0(%rsp)
  7d5e11:	mov    0x68(%rsp),%rbx
  7d5e16:	cs nopw 0x0(%rax,%rax,1)
  7d5e20:	lea    0xe0(%rsp),%rdi
  7d5e28:	mov    0xb8(%rsp),%rsi
  7d5e30:	movss  0x44(%rsp),%xmm0
  7d5e36:	lea    0xc0(%rsp),%rdx
  7d5e3e:	call   7c9720 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_>
  7d5e43:	movzbl 0xe4(%rsp),%eax
  7d5e4b:	cmp    $0x2,%al
  7d5e4d:	je     7d5e9d <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x31d>
  7d5e4f:	mov    0xb0(%rsp),%rcx
  7d5e57:	mov    (%rcx),%rdi
  7d5e5a:	mov    0x28(%r15),%rsi
  7d5e5e:	cmp    %rsi,%rdi
  7d5e61:	jae    7d61fe <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x67e>
  7d5e67:	mov    0xe0(%rsp),%ecx
  7d5e6e:	mov    0x20(%r15),%rdx
  7d5e72:	lea    (%rdi,%rdi,2),%rsi
  7d5e76:	cmp    0x4(%rdx,%rsi,8),%ecx
  7d5e7a:	ja     7d614b <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x5cb>
  7d5e80:	mov    0x100(%rsp),%rdx
  7d5e88:	cmp    0x38(%rsp),%rdx
  7d5e8d:	jne    7d5e9d <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x31d>
  7d5e8f:	testb  $0x1,0x110(%rsp)
  7d5e97:	je     7d606d <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x4ed>
  7d5e9d:	mov    %r13,%rax
  7d5ea0:	cmp    $0x1,%r13
  7d5ea4:	je     7d5ed4 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x354>
  7d5ea6:	test   %r13,%r13
  7d5ea9:	je     7d614b <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x5cb>
  7d5eaf:	mov    (%r14),%ecx
  7d5eb2:	lea    0xc(%r14),%rdx
  7d5eb6:	lea    0x1(%r13),%rsi
  7d5eba:	mov    $0x1,%eax
  7d5ebf:	nop
  7d5ec0:	cmp    (%rdx),%ecx
  7d5ec2:	jne    7d5ed4 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x354>
  7d5ec4:	inc    %rax
  7d5ec7:	add    $0xc,%rdx
  7d5ecb:	dec    %rsi
  7d5ece:	cmp    $0x2,%rsi
  7d5ed2:	ja     7d5ec0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x340>
  7d5ed4:	sub    %rax,%r13
  7d5ed7:	jb     7d61c8 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x648>
  7d5edd:	lea    (%rax,%rax,2),%rcx
  7d5ee1:	lea    (%r14,%rcx,4),%rcx
  7d5ee5:	mov    %rcx,0x50(%rsp)
  7d5eea:	mov    %r13,0x58(%rsp)
  7d5eef:	test   %r12,%r12
  7d5ef2:	jne    7d5f99 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x419>
  7d5ef8:	mov    %rbx,%rdx
  7d5efb:	cmp    $0x1,%rbx
  7d5eff:	je     7d5f34 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x3b4>
  7d5f01:	test   %rbx,%rbx
  7d5f04:	je     7d614b <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x5cb>
  7d5f0a:	mov    0x0(%rbp),%esi
  7d5f0d:	lea    0xc(%rbp),%rdi
  7d5f11:	lea    0x1(%rbx),%r8
  7d5f15:	mov    $0x1,%edx
  7d5f1a:	nopw   0x0(%rax,%rax,1)
  7d5f20:	cmp    (%rdi),%esi
  7d5f22:	jne    7d5f34 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x3b4>
  7d5f24:	inc    %rdx
  7d5f27:	add    $0xc,%rdi
  7d5f2b:	dec    %r8
  7d5f2e:	cmp    $0x2,%r8
  7d5f32:	ja     7d5f20 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x3a0>
  7d5f34:	sub    %rdx,%rbx
  7d5f37:	jb     7d61c8 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x648>
  7d5f3d:	lea    (%rdx,%rdx,2),%rsi
  7d5f41:	lea    0x0(,%rsi,4),%rsi
  7d5f49:	add    %rbp,%rsi
  7d5f4c:	mov    %rsi,0x60(%rsp)
  7d5f51:	mov    %rbx,0x68(%rsp)
  7d5f56:	test   %rbp,%rbp
  7d5f59:	je     7d614b <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x5cb>
  7d5f5f:	mov    %r14,0xc0(%rsp)
  7d5f67:	mov    %rax,0xc8(%rsp)
  7d5f6f:	mov    %rbp,0xd0(%rsp)
  7d5f77:	mov    %rdx,0xd8(%rsp)
  7d5f7f:	mov    %rsi,%rbp
  7d5f82:	mov    $0x0,%r12d
  7d5f88:	test   %r14,%r14
  7d5f8b:	mov    %rcx,%r14
  7d5f8e:	jne    7d5e20 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x2a0>
  7d5f94:	jmp    7d614b <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x5cb>
  7d5f99:	movq   $0x0,0x70(%rsp)
  7d5fa2:	mov    %rbp,%rdi
  7d5fa5:	mov    %rbx,%rsi
  7d5fa8:	mov    %rbx,%r8
  7d5fab:	cmp    $0x1,%rbx
  7d5faf:	je     7d5fe5 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x465>
  7d5fb1:	test   %rsi,%rsi
  7d5fb4:	je     7d614b <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x5cb>
  7d5fba:	mov    (%rdi),%edx
  7d5fbc:	lea    0xc(%rdi),%r9
  7d5fc0:	lea    0x1(%rsi),%r10
  7d5fc4:	mov    $0x1,%r8d
  7d5fca:	nopw   0x0(%rax,%rax,1)
  7d5fd0:	cmp    (%r9),%edx
  7d5fd3:	jne    7d5fe5 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x465>
  7d5fd5:	inc    %r8
  7d5fd8:	add    $0xc,%r9
  7d5fdc:	dec    %r10
  7d5fdf:	cmp    $0x2,%r10
  7d5fe3:	ja     7d5fd0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x450>
  7d5fe5:	mov    %rsi,%rbx
  7d5fe8:	sub    %r8,%rbx
  7d5feb:	jb     7d61c8 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x648>
  7d5ff1:	lea    (%r8,%r8,2),%r10
  7d5ff5:	lea    (%rdi,%r10,4),%rbp
  7d5ff9:	dec    %r12
  7d5ffc:	jne    7d5fa2 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x422>
  7d5ffe:	mov    %rbp,0x60(%rsp)
  7d6003:	mov    %rbx,0x68(%rsp)
  7d6008:	mov    %rbx,%rdx
  7d600b:	cmp    $0x1,%rbx
  7d600f:	je     7d6046 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x4c6>
  7d6011:	test   %rbx,%rbx
  7d6014:	je     7d614b <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x5cb>
  7d601a:	mov    0x0(%rbp),%r9d
  7d601e:	lea    (%rdi,%r10,4),%rdi
  7d6022:	add    $0xc,%rdi
  7d6026:	sub    %r8,%rsi
  7d6029:	inc    %rsi
  7d602c:	mov    $0x1,%edx
  7d6031:	cmp    (%rdi),%r9d
  7d6034:	jne    7d6046 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x4c6>
  7d6036:	inc    %rdx
  7d6039:	add    $0xc,%rdi
  7d603d:	dec    %rsi
  7d6040:	cmp    $0x2,%rsi
  7d6044:	ja     7d6031 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x4b1>
  7d6046:	sub    %rdx,%rbx
  7d6049:	jb     7d61c8 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x648>
  7d604f:	lea    (%rdx,%rdx,2),%rsi
  7d6053:	lea    0x0(,%rsi,4),%rsi
  7d605b:	add    %rbp,%rsi
  7d605e:	mov    %rsi,0x60(%rsp)
  7d6063:	mov    %rbx,0x68(%rsp)
  7d6068:	jmp    7d5f5f <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x3df>
  7d606d:	mov    0x108(%rsp),%rdx
  7d6075:	movd   %edx,%xmm0
  7d6079:	shr    $0x20,%rdx
  7d607d:	movd   %edx,%xmm1
  7d6081:	mov    0x20(%rsp),%esi
  7d6085:	test   %sil,%sil
  7d6088:	je     7d60ad <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x52d>
  7d608a:	movaps %xmm0,%xmm3
  7d608d:	maxss  %xmm1,%xmm3
  7d6091:	movaps %xmm3,%xmm2
  7d6094:	cmpunordss %xmm3,%xmm2
  7d6099:	movaps %xmm2,%xmm4
  7d609c:	andnps %xmm3,%xmm4
  7d609f:	andps  %xmm0,%xmm2
  7d60a2:	orps   %xmm4,%xmm2
  7d60a5:	subss  0x18(%rsp),%xmm2
  7d60ab:	jmp    7d60d3 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x553>
  7d60ad:	movdqa %xmm0,%xmm2
  7d60b1:	minss  %xmm1,%xmm2
  7d60b5:	movaps %xmm2,%xmm3
  7d60b8:	cmpunordss %xmm2,%xmm3
  7d60bd:	movaps %xmm3,%xmm4
  7d60c0:	andnps %xmm2,%xmm4
  7d60c3:	andps  %xmm0,%xmm3
  7d60c6:	orps   %xmm4,%xmm3
  7d60c9:	movss  0x18(%rsp),%xmm2
  7d60cf:	subss  %xmm3,%xmm2
  7d60d3:	mov    0x30(%rsp),%rbx
  7d60d8:	mov    0x14(%rsp),%ebp
  7d60dc:	mov    0x10(%rsp),%r14d
  7d60e1:	mov    0x28(%rsp),%r11
  7d60e6:	mov    0xc(%rsp),%edx
  7d60ea:	xorps  %xmm3,%xmm3
  7d60ed:	ucomiss %xmm3,%xmm2
  7d60f0:	jbe    7d612a <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x5aa>
  7d60f2:	movss  0x1c(%rsp),%xmm3
  7d60f8:	ucomiss %xmm2,%xmm3
  7d60fb:	jbe    7d612a <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x5aa>
  7d60fd:	ucomiss %xmm0,%xmm1
  7d6100:	setbe  %dl
  7d6103:	xor    %sil,%dl
  7d6106:	cmovne 0xe8(%rsp),%ecx
  7d610e:	movzbl 0xec(%rsp),%edx
  7d6116:	movzbl %al,%eax
  7d6119:	cmovne %edx,%eax
  7d611c:	and    $0x1,%al
  7d611e:	mov    %eax,0x24(%rsp)
  7d6122:	movss  %xmm2,0x1c(%rsp)
  7d6128:	mov    %ecx,%edx
  7d612a:	mov    %edx,0xc(%rsp)
  7d612e:	cmpb   $0x0,0xa8(%rsp)
  7d6136:	lea    0x50(%rsp),%rsi
  7d613b:	lea    0xc0(%rsp),%rdi
  7d6143:	je     7d5db2 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x232>
  7d6149:	jmp    7d615e <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x5de>
  7d614b:	mov    0x30(%rsp),%rbx
  7d6150:	mov    0x14(%rsp),%ebp
  7d6154:	mov    0x10(%rsp),%r14d
  7d6159:	mov    0x28(%rsp),%r11
  7d615e:	mov    0x24(%rsp),%edx
  7d6162:	cmp    $0x2,%dl
  7d6165:	jne    7d61c2 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x642>
  7d6167:	mov    0x38(%rsp),%rsi
  7d616c:	cmpb   $0x0,0x20(%rsp)
  7d6171:	je     7d6192 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x612>
  7d6173:	cmp    $0xffffffffffffffff,%rsi
  7d6177:	je     7d61e1 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x661>
  7d6179:	inc    %rsi
  7d617c:	xor    %eax,%eax
  7d617e:	cmp    %r11,%rsi
  7d6181:	setb   %al
  7d6184:	test   $0x1,%al
  7d6186:	je     7d61e7 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x667>
  7d6188:	movss  -0x713bf4(%rip),%xmm0        # c259c <GCC_except_table0+0x1d0>
  7d6190:	jmp    7d61b6 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x636>
  7d6192:	test   %rsi,%rsi
  7d6195:	je     7d61a8 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x628>
  7d6197:	dec    %rsi
  7d619a:	xor    %eax,%eax
  7d619c:	cmp    %r11,%rsi
  7d619f:	setb   %al
  7d61a2:	test   $0x1,%al
  7d61a4:	jne    7d61ae <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x62e>
  7d61a6:	jmp    7d61e7 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x667>
  7d61a8:	xor    %eax,%eax
  7d61aa:	test   $0x1,%al
  7d61ac:	je     7d61e7 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x667>
  7d61ae:	movss  -0x713c5a(%rip),%xmm0        # c255c <GCC_except_table0+0x190>
  7d61b6:	mov    %rbx,%rdi
  7d61b9:	call   7d62e0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line>
  7d61be:	mov    %eax,0xc(%rsp)
  7d61c2:	mov    0xc(%rsp),%ebp
  7d61c6:	jmp    7d61ea <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x66a>
  7d61c8:	lea    -0x4c48a8(%rip),%rdi        # 311927 <_RNvNtCsghYClfd3M9V_11gpui_canvas4text13PRIMARY_BYTES+0x1f463f>
  7d61cf:	lea    0x2c84ca(%rip),%rdx        # a9e6a0 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0x1a08>
  7d61d6:	mov    $0x13,%esi
  7d61db:	call   *0x2e3f07(%rip)        # aba0e8 <_DYNAMIC+0x278>
  7d61e1:	xor    %eax,%eax
  7d61e3:	test   $0x1,%al
  7d61e5:	jne    7d6188 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x608>
  7d61e7:	mov    %r14d,%edx
  7d61ea:	mov    %ebp,%eax
  7d61ec:	add    $0x118,%rsp
  7d61f3:	pop    %rbx
  7d61f4:	pop    %r12
  7d61f6:	pop    %r13
  7d61f8:	pop    %r14
  7d61fa:	pop    %r15
  7d61fc:	pop    %rbp
  7d61fd:	ret
  7d61fe:	lea    0x2c791b(%rip),%rdx        # a9db20 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0xe88>
  7d6205:	call   *0x2e3ed5(%rip)        # aba0e0 <_DYNAMIC+0x270>
  7d620b:	lea    0x2c822e(%rip),%rdx        # a9e440 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0x17a8>
  7d6212:	mov    %r11,%rsi
  7d6215:	call   *0x2e3ec5(%rip)        # aba0e0 <_DYNAMIC+0x270>

<gpui_canvas::text::layout::TextGeometry>::next_visual bytes=10 frame=0

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007d6220 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11next_visual>:
  7d6220:	mov    $0x1,%ecx
  7d6225:	jmp    7d5b80 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual>

<gpui_canvas::text::layout::TextGeometry>::position_at bytes=151 frame=8

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007d6230 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11position_at>:
  7d6230:	movd   %xmm1,%eax
  7d6234:	movd   %xmm0,%ecx
  7d6238:	and    $0x7fffffff,%ecx
  7d623e:	cmp    $0x7f800000,%ecx
  7d6244:	setge  %cl
  7d6247:	and    $0x7fffffff,%eax
  7d624c:	cmp    $0x7f800000,%eax
  7d6251:	setge  %al
  7d6254:	or     %cl,%al
  7d6256:	je     7d625b <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11position_at+0x2b>
  7d6258:	mov    $0x2,%dl
  7d625a:	ret
  7d625b:	push   %rax
  7d625c:	mov    0x28(%rdi),%rsi
  7d6260:	test   %rsi,%rsi
  7d6263:	je     7d62bd <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11position_at+0x8d>
  7d6265:	mov    0x20(%rdi),%rax
  7d6269:	xor    %ecx,%ecx
  7d626b:	cmp    $0x1,%rsi
  7d626f:	je     7d62a3 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11position_at+0x73>
  7d6271:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  7d6280:	mov    %rcx,%rdx
  7d6283:	mov    %rsi,%r8
  7d6286:	shr    $1,%r8
  7d6289:	add    %r8,%rcx
  7d628c:	lea    (%rcx,%rcx,2),%r9
  7d6290:	ucomiss 0x8(%rax,%r9,8),%xmm1
  7d6296:	cmovb  %rdx,%rcx
  7d629a:	sub    %r8,%rsi
  7d629d:	cmp    $0x1,%rsi
  7d62a1:	ja     7d6280 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11position_at+0x50>
  7d62a3:	lea    (%rcx,%rcx,2),%rdx
  7d62a7:	xor    %esi,%esi
  7d62a9:	ucomiss 0x8(%rax,%rdx,8),%xmm1
  7d62ae:	setae  %sil
  7d62b2:	add    %rcx,%rsi
  7d62b5:	cmp    $0x1,%rsi
  7d62b9:	adc    $0xffffffffffffffff,%rsi
  7d62bd:	call   7d62e0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line>
  7d62c2:	add    $0x8,%rsp
  7d62c6:	ret

<gpui_canvas::text::layout::TextGeometry>::previous_visual bytes=7 frame=0

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007d62d0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry15previous_visual>:
  7d62d0:	xor    %ecx,%ecx
  7d62d2:	jmp    7d5b80 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual>

<gpui_canvas::text::layout::TextGeometry>::position_on_line bytes=2185 frame=360

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007d62e0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line>:
  7d62e0:	push   %rbp
  7d62e1:	push   %r15
  7d62e3:	push   %r14
  7d62e5:	push   %r13
  7d62e7:	push   %r12
  7d62e9:	push   %rbx
  7d62ea:	sub    $0x138,%rsp
  7d62f1:	mov    %rsi,0x28(%rsp)
  7d62f6:	cmpq   $0xffffffffffffffff,0x30(%rdi)
  7d62fb:	je     7d6388 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0xa8>
  7d6301:	mov    0x28(%rdi),%rax
  7d6305:	cmp    %rax,%rsi
  7d6308:	jae    7d6b49 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x869>
  7d630e:	mov    %rax,0xe0(%rsp)
  7d6316:	mov    0x38(%rdi),%rax
  7d631a:	mov    0x40(%rdi),%r8
  7d631e:	mov    0x20(%rdi),%rdx
  7d6322:	lea    (%rsi,%rsi,2),%rcx
  7d6326:	mov    %rdx,0xd8(%rsp)
  7d632e:	mov    (%rdx,%rcx,8),%ecx
  7d6331:	test   %ecx,%ecx
  7d6333:	mov    %r8,0x38(%rsp)
  7d6338:	je     7d638f <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0xaf>
  7d633a:	mov    %r8,%r13
  7d633d:	test   %r8,%r8
  7d6340:	je     7d6392 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0xb2>
  7d6342:	xor    %r13d,%r13d
  7d6345:	cmp    $0x1,%r8
  7d6349:	je     7d636f <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x8f>
  7d634b:	mov    %r8,%rdx
  7d634e:	xchg   %ax,%ax
  7d6350:	mov    %rdx,%rsi
  7d6353:	shr    $1,%rsi
  7d6356:	lea    (%rsi,%r13,1),%r8
  7d635a:	lea    (%r8,%r8,2),%r9
  7d635e:	cmp    %ecx,(%rax,%r9,4)
  7d6362:	cmovb  %r8,%r13
  7d6366:	sub    %rsi,%rdx
  7d6369:	cmp    $0x1,%rdx
  7d636d:	ja     7d6350 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x70>
  7d636f:	lea    0x0(,%r13,2),%rdx
  7d6377:	add    %r13,%rdx
  7d637a:	cmp    %ecx,(%rax,%rdx,4)
  7d637d:	adc    $0x0,%r13
  7d6381:	mov    0x38(%rsp),%r8
  7d6386:	jmp    7d6392 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0xb2>
  7d6388:	mov    $0x2,%dl
  7d638a:	jmp    7d687b <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x59b>
  7d638f:	xor    %r13d,%r13d
  7d6392:	movss  %xmm0,0x20(%rsp)
  7d6398:	sub    %r13,%r8
  7d639b:	lea    0x0(,%r13,2),%rcx
  7d63a3:	add    %r13,%rcx
  7d63a6:	movss  0x4c(%rdi),%xmm0
  7d63ab:	mulss  -0x713edb(%rip),%xmm0        # c24d8 <GCC_except_table0+0x10c>
  7d63b3:	lea    (%rax,%rcx,4),%rcx
  7d63b7:	xorps  %xmm1,%xmm1
  7d63ba:	movups %xmm1,0x90(%rsp)
  7d63c2:	lea    0x28(%rsp),%rax
  7d63c7:	mov    %rax,0x60(%rsp)
  7d63cc:	lea    0x68(%rsp),%rsi
  7d63d1:	mov    %rcx,0x68(%rsp)
  7d63d6:	mov    %r8,0x70(%rsp)
  7d63db:	mov    %rcx,0xd0(%rsp)
  7d63e3:	mov    %rcx,0x78(%rsp)
  7d63e8:	mov    %r8,0xc8(%rsp)
  7d63f0:	mov    %r8,0x80(%rsp)
  7d63f8:	movq   $0x1,0x88(%rsp)
  7d6404:	mov    %rdi,0xa0(%rsp)
  7d640c:	movss  %xmm0,0xa8(%rsp)
  7d6415:	mov    %rdi,0xb0(%rsp)
  7d641d:	mov    %rax,0xb8(%rsp)
  7d6425:	movb   $0x0,0xc0(%rsp)
  7d642d:	mov    $0x2,%cl
  7d642f:	lea    0x40(%rsp),%rdi
  7d6434:	mov    $0x2,%dl
  7d6436:	mov    %cl,0xf(%rsp)
  7d643a:	mov    %edx,0x24(%rsp)
  7d643e:	call   7e8130 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextB1u_>
  7d6443:	cmpq   $0x0,0x40(%rsp)
  7d6449:	je     7d6806 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x526>
  7d644f:	mov    0xa0(%rsp),%rax
  7d6457:	mov    %rax,0xf8(%rsp)
  7d645f:	movss  0xa8(%rsp),%xmm0
  7d6468:	movss  %xmm0,0x34(%rsp)
  7d646e:	mov    0x68(%rsp),%r12
  7d6473:	mov    0x70(%rsp),%rbx
  7d6478:	mov    0x88(%rsp),%rbp
  7d6480:	mov    0x78(%rsp),%r15
  7d6485:	mov    0xb0(%rsp),%rax
  7d648d:	mov    %rax,0xf0(%rsp)
  7d6495:	mov    0xb8(%rsp),%rax
  7d649d:	mov    %rax,0xe8(%rsp)
  7d64a5:	mov    0x80(%rsp),%r14
  7d64ad:	nopl   (%rax)
  7d64b0:	lea    0x100(%rsp),%rdi
  7d64b8:	mov    0xf8(%rsp),%rsi
  7d64c0:	movss  0x34(%rsp),%xmm0
  7d64c6:	lea    0x40(%rsp),%rdx
  7d64cb:	call   7c9720 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_>
  7d64d0:	movzbl 0x104(%rsp),%ecx
  7d64d8:	cmp    $0x2,%cl
  7d64db:	je     7d6529 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x249>
  7d64dd:	mov    0xe8(%rsp),%rax
  7d64e5:	mov    (%rax),%rdi
  7d64e8:	mov    0xf0(%rsp),%rax
  7d64f0:	mov    0x28(%rax),%rsi
  7d64f4:	cmp    %rsi,%rdi
  7d64f7:	jae    7d6b3c <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x85c>
  7d64fd:	mov    0x100(%rsp),%esi
  7d6504:	mov    0x20(%rax),%rax
  7d6508:	lea    (%rdi,%rdi,2),%rdx
  7d650c:	cmp    0x4(%rax,%rdx,8),%esi
  7d6510:	ja     7d6806 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x526>
  7d6516:	mov    0x120(%rsp),%rax
  7d651e:	cmp    0x28(%rsp),%rax
  7d6523:	je     7d66eb <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x40b>
  7d6529:	mov    %rbx,%rax
  7d652c:	cmp    $0x1,%rbx
  7d6530:	je     7d6564 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x284>
  7d6532:	test   %rbx,%rbx
  7d6535:	je     7d6806 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x526>
  7d653b:	mov    (%r12),%ecx
  7d653f:	lea    0xc(%r12),%rdx
  7d6544:	lea    0x1(%rbx),%rsi
  7d6548:	mov    $0x1,%eax
  7d654d:	nopl   (%rax)
  7d6550:	cmp    (%rdx),%ecx
  7d6552:	jne    7d6564 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x284>
  7d6554:	inc    %rax
  7d6557:	add    $0xc,%rdx
  7d655b:	dec    %rsi
  7d655e:	cmp    $0x2,%rsi
  7d6562:	ja     7d6550 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x270>
  7d6564:	sub    %rax,%rbx
  7d6567:	jb     7d6ae9 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x809>
  7d656d:	lea    (%rax,%rax,2),%rcx
  7d6571:	lea    (%r12,%rcx,4),%rcx
  7d6575:	mov    %rcx,0x68(%rsp)
  7d657a:	mov    %rbx,0x70(%rsp)
  7d657f:	test   %rbp,%rbp
  7d6582:	jne    7d6618 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x338>
  7d6588:	mov    %r14,%rdx
  7d658b:	cmp    $0x1,%r14
  7d658f:	je     7d65c4 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x2e4>
  7d6591:	test   %r14,%r14
  7d6594:	je     7d6806 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x526>
  7d659a:	mov    (%r15),%esi
  7d659d:	lea    0xc(%r15),%rdi
  7d65a1:	lea    0x1(%r14),%r8
  7d65a5:	mov    $0x1,%edx
  7d65aa:	nopw   0x0(%rax,%rax,1)
  7d65b0:	cmp    (%rdi),%esi
  7d65b2:	jne    7d65c4 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x2e4>
  7d65b4:	inc    %rdx
  7d65b7:	add    $0xc,%rdi
  7d65bb:	dec    %r8
  7d65be:	cmp    $0x2,%r8
  7d65c2:	ja     7d65b0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x2d0>
  7d65c4:	sub    %rdx,%r14
  7d65c7:	jb     7d6ae9 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x809>
  7d65cd:	lea    (%rdx,%rdx,2),%rsi
  7d65d1:	lea    (%r15,%rsi,4),%rsi
  7d65d5:	mov    %rsi,0x78(%rsp)
  7d65da:	mov    %r14,0x80(%rsp)
  7d65e2:	test   %r15,%r15
  7d65e5:	je     7d6806 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x526>
  7d65eb:	mov    %r12,0x40(%rsp)
  7d65f0:	mov    %rax,0x48(%rsp)
  7d65f5:	mov    %r15,0x50(%rsp)
  7d65fa:	mov    %rdx,0x58(%rsp)
  7d65ff:	mov    %rsi,%r15
  7d6602:	mov    $0x0,%ebp
  7d6607:	test   %r12,%r12
  7d660a:	mov    %rcx,%r12
  7d660d:	jne    7d64b0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x1d0>
  7d6613:	jmp    7d6806 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x526>
  7d6618:	movq   $0x0,0x88(%rsp)
  7d6624:	mov    %r15,%rdi
  7d6627:	mov    %r14,%rsi
  7d662a:	mov    %r14,%r8
  7d662d:	cmp    $0x1,%r14
  7d6631:	je     7d6665 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x385>
  7d6633:	test   %rsi,%rsi
  7d6636:	je     7d6806 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x526>
  7d663c:	mov    (%rdi),%edx
  7d663e:	lea    0xc(%rdi),%r9
  7d6642:	lea    0x1(%rsi),%r10
  7d6646:	mov    $0x1,%r8d
  7d664c:	nopl   0x0(%rax)
  7d6650:	cmp    (%r9),%edx
  7d6653:	jne    7d6665 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x385>
  7d6655:	inc    %r8
  7d6658:	add    $0xc,%r9
  7d665c:	dec    %r10
  7d665f:	cmp    $0x2,%r10
  7d6663:	ja     7d6650 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x370>
  7d6665:	mov    %rsi,%r14
  7d6668:	sub    %r8,%r14
  7d666b:	jb     7d6ae9 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x809>
  7d6671:	lea    (%r8,%r8,2),%r10
  7d6675:	lea    (%rdi,%r10,4),%r15
  7d6679:	dec    %rbp
  7d667c:	jne    7d6624 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x344>
  7d667e:	mov    %r15,0x78(%rsp)
  7d6683:	mov    %r14,0x80(%rsp)
  7d668b:	mov    %r14,%rdx
  7d668e:	cmp    $0x1,%r14
  7d6692:	je     7d66c8 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x3e8>
  7d6694:	test   %r14,%r14
  7d6697:	je     7d6806 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x526>
  7d669d:	mov    (%r15),%r9d
  7d66a0:	lea    (%rdi,%r10,4),%rdi
  7d66a4:	add    $0xc,%rdi
  7d66a8:	sub    %r8,%rsi
  7d66ab:	inc    %rsi
  7d66ae:	mov    $0x1,%edx
  7d66b3:	cmp    (%rdi),%r9d
  7d66b6:	jne    7d66c8 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x3e8>
  7d66b8:	inc    %rdx
  7d66bb:	add    $0xc,%rdi
  7d66bf:	dec    %rsi
  7d66c2:	cmp    $0x2,%rsi
  7d66c6:	ja     7d66b3 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x3d3>
  7d66c8:	sub    %rdx,%r14
  7d66cb:	jb     7d6ae9 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x809>
  7d66d1:	lea    (%rdx,%rdx,2),%rsi
  7d66d5:	lea    (%r15,%rsi,4),%rsi
  7d66d9:	mov    %rsi,0x78(%rsp)
  7d66de:	mov    %r14,0x80(%rsp)
  7d66e6:	jmp    7d65eb <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x30b>
  7d66eb:	movss  0x128(%rsp),%xmm1
  7d66f4:	testb  $0x1,0x130(%rsp)
  7d66fc:	je     7d6708 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x428>
  7d66fe:	mov    %esi,%eax
  7d6700:	mov    %ecx,%r9d
  7d6703:	movaps %xmm1,%xmm0
  7d6706:	jmp    7d677c <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x49c>
  7d6708:	mov    0x108(%rsp),%eax
  7d670f:	movzbl 0x10c(%rsp),%edx
  7d6717:	movss  0x12c(%rsp),%xmm0
  7d6720:	and    $0x1,%dl
  7d6723:	movaps %xmm1,%xmm3
  7d6726:	minss  %xmm0,%xmm3
  7d672a:	movaps %xmm3,%xmm2
  7d672d:	cmpunordss %xmm3,%xmm2
  7d6732:	movaps %xmm2,%xmm4
  7d6735:	andnps %xmm3,%xmm4
  7d6738:	andps  %xmm1,%xmm2
  7d673b:	orps   %xmm4,%xmm2
  7d673e:	movaps %xmm1,%xmm3
  7d6741:	maxss  %xmm0,%xmm3
  7d6745:	ucomiss %xmm1,%xmm0
  7d6748:	mov    %esi,%edi
  7d674a:	cmovbe %eax,%edi
  7d674d:	movaps %xmm3,%xmm0
  7d6750:	cmpunordss %xmm3,%xmm0
  7d6755:	movzbl %cl,%r8d
  7d6759:	movzbl %dl,%r9d
  7d675d:	mov    %r8d,%ecx
  7d6760:	cmovbe %r9d,%ecx
  7d6764:	movaps %xmm0,%xmm4
  7d6767:	cmovbe %esi,%eax
  7d676a:	andnps %xmm3,%xmm4
  7d676d:	cmovbe %r8d,%r9d
  7d6771:	andps  %xmm1,%xmm0
  7d6774:	orps   %xmm4,%xmm0
  7d6777:	movaps %xmm2,%xmm1
  7d677a:	mov    %edi,%esi
  7d677c:	mov    0x24(%rsp),%edx
  7d6780:	mov    0x1c(%rsp),%edi
  7d6784:	movss  0x20(%rsp),%xmm2
  7d678a:	ucomiss %xmm2,%xmm1
  7d678d:	jbe    7d67ba <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x4da>
  7d678f:	cmp    $0x2,%dl
  7d6792:	je     7d679f <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x4bf>
  7d6794:	movss  0x14(%rsp),%xmm0
  7d679a:	ucomiss %xmm1,%xmm0
  7d679d:	jbe    7d67ab <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x4cb>
  7d679f:	movss  %xmm1,0x14(%rsp)
  7d67a5:	mov    %esi,0x18(%rsp)
  7d67a9:	mov    %ecx,%edx
  7d67ab:	movss  0x10(%rsp),%xmm0
  7d67b1:	mov    %edi,%eax
  7d67b3:	movzbl 0xf(%rsp),%ecx
  7d67b8:	jmp    7d67dc <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x4fc>
  7d67ba:	ucomiss %xmm0,%xmm2
  7d67bd:	jbe    7d6b0b <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x82b>
  7d67c3:	movzbl 0xf(%rsp),%ecx
  7d67c8:	cmp    $0x2,%cl
  7d67cb:	je     7d67df <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x4ff>
  7d67cd:	ucomiss 0x10(%rsp),%xmm0
  7d67d2:	ja     7d67df <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x4ff>
  7d67d4:	movss  0x10(%rsp),%xmm0
  7d67da:	mov    %edi,%eax
  7d67dc:	mov    %ecx,%r9d
  7d67df:	lea    0x68(%rsp),%rsi
  7d67e4:	lea    0x40(%rsp),%rdi
  7d67e9:	cmpb   $0x0,0xc0(%rsp)
  7d67f1:	mov    %r9d,%ecx
  7d67f4:	mov    %eax,0x1c(%rsp)
  7d67f8:	movss  %xmm0,0x10(%rsp)
  7d67fe:	je     7d6436 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x156>
  7d6804:	jmp    7d681c <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x53c>
  7d6806:	movss  0x10(%rsp),%xmm0
  7d680c:	mov    0x1c(%rsp),%eax
  7d6810:	movzbl 0xf(%rsp),%ecx
  7d6815:	mov    %ecx,%r9d
  7d6818:	mov    0x24(%rsp),%edx
  7d681c:	cmp    $0x2,%r9b
  7d6820:	jne    7d6836 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x556>
  7d6822:	cmp    $0x2,%dl
  7d6825:	mov    0x18(%rsp),%esi
  7d6829:	jne    7d687b <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x59b>
  7d682b:	mov    $0x2,%dl
  7d682d:	cmp    %r13,0x38(%rsp)
  7d6832:	jne    7d688f <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x5af>
  7d6834:	jmp    7d687b <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x59b>
  7d6836:	cmp    $0x2,%dl
  7d6839:	jne    7d6842 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x562>
  7d683b:	mov    %r9d,%edx
  7d683e:	mov    %eax,%esi
  7d6840:	jmp    7d687b <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x59b>
  7d6842:	cvtss2sd %xmm0,%xmm0
  7d6846:	movss  0x14(%rsp),%xmm1
  7d684c:	cvtss2sd %xmm1,%xmm1
  7d6850:	addsd  %xmm0,%xmm1
  7d6854:	mulsd  -0x712acc(%rip),%xmm1        # c3d90 <GCC_except_table0+0x19c4>
  7d685c:	movss  0x20(%rsp),%xmm0
  7d6862:	cvtss2sd %xmm0,%xmm0
  7d6866:	ucomisd %xmm1,%xmm0
  7d686a:	mov    0x18(%rsp),%esi
  7d686e:	cmovbe %eax,%esi
  7d6871:	movzbl %dl,%eax
  7d6874:	movzbl %r9b,%edx
  7d6878:	cmova  %eax,%edx
  7d687b:	mov    %esi,%eax
  7d687d:	add    $0x138,%rsp
  7d6884:	pop    %rbx
  7d6885:	pop    %r12
  7d6887:	pop    %r13
  7d6889:	pop    %r14
  7d688b:	pop    %r15
  7d688d:	pop    %rbp
  7d688e:	ret
  7d688f:	mov    0x28(%rsp),%rdi
  7d6894:	mov    0xe0(%rsp),%rsi
  7d689c:	cmp    %rsi,%rdi
  7d689f:	jae    7d6b5c <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x87c>
  7d68a5:	mov    0xc8(%rsp),%rax
  7d68ad:	lea    (%rax,%rax,2),%rax
  7d68b1:	mov    0xd0(%rsp),%r12
  7d68b9:	lea    (%r12,%rax,4),%rax
  7d68bd:	lea    (%rdi,%rdi,2),%rcx
  7d68c1:	mov    0xd8(%rsp),%r14
  7d68c9:	mov    0x4(%r14,%rcx,8),%ecx
  7d68ce:	lea    -0x1(%rsi),%r15
  7d68d2:	jmp    7d6900 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x620>
  7d68d4:	xor    %ebx,%ebx
  7d68d6:	lea    (%rbx,%rbx,2),%r8
  7d68da:	cmp    %r13d,0x4(%r14,%r8,8)
  7d68df:	adc    $0x0,%rbx
  7d68e3:	cmp    %rbx,%r15
  7d68e6:	cmovb  %r15,%rbx
  7d68ea:	cmp    %rdi,%rbx
  7d68ed:	je     7d6adf <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x7ff>
  7d68f3:	add    $0xc,%r12
  7d68f7:	cmp    %rax,%r12
  7d68fa:	je     7d6834 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x554>
  7d6900:	mov    (%r12),%r13d
  7d6904:	cmp    %ecx,%r13d
  7d6907:	ja     7d6acd <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x7ed>
  7d690d:	movzbl 0x8(%r12),%ebp
  7d6913:	test   %r13d,%r13d
  7d6916:	je     7d6940 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x660>
  7d6918:	test   $0x2,%bpl
  7d691c:	je     7d69b4 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x6d4>
  7d6922:	mov    %rsi,%r9
  7d6925:	test   %rsi,%rsi
  7d6928:	je     7d69ab <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x6cb>
  7d692e:	cmp    $0x1,%rsi
  7d6932:	jne    7d6968 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x688>
  7d6934:	xor    %r8d,%r8d
  7d6937:	jmp    7d6991 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x6b1>
  7d6939:	nopl   0x0(%rax)
  7d6940:	test   $0x2,%bpl
  7d6944:	je     7d6a54 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x774>
  7d694a:	mov    %rsi,%r9
  7d694d:	test   %rsi,%rsi
  7d6950:	je     7d6a4b <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x76b>
  7d6956:	cmp    $0x1,%rsi
  7d695a:	jne    7d6a05 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x725>
  7d6960:	xor    %r8d,%r8d
  7d6963:	jmp    7d6a30 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x750>
  7d6968:	mov    %rsi,%r9
  7d696b:	xor    %r8d,%r8d
  7d696e:	xchg   %ax,%ax
  7d6970:	mov    %r8,%r10
  7d6973:	mov    %r9,%r11
  7d6976:	shr    $1,%r11
  7d6979:	add    %r11,%r8
  7d697c:	lea    (%r8,%r8,2),%rbx
  7d6980:	cmp    %r13d,(%r14,%rbx,8)
  7d6984:	cmova  %r10,%r8
  7d6988:	sub    %r11,%r9
  7d698b:	cmp    $0x1,%r9
  7d698f:	ja     7d6970 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x690>
  7d6991:	lea    (%r8,%r8,2),%r10
  7d6995:	xor    %r9d,%r9d
  7d6998:	cmp    %r13d,(%r14,%r10,8)
  7d699c:	setbe  %r9b
  7d69a0:	add    %r8,%r9
  7d69a3:	cmp    $0x1,%r9
  7d69a7:	adc    $0xffffffffffffffff,%r9
  7d69ab:	cmp    %rdi,%r9
  7d69ae:	je     7d6ad5 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x7f5>
  7d69b4:	test   $0x1,%bpl
  7d69b8:	je     7d68f3 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x613>
  7d69be:	mov    %rsi,%rbx
  7d69c1:	test   %rsi,%rsi
  7d69c4:	je     7d68ea <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x60a>
  7d69ca:	cmp    $0x1,%rsi
  7d69ce:	je     7d68d4 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x5f4>
  7d69d4:	mov    %rsi,%r8
  7d69d7:	xor    %ebx,%ebx
  7d69d9:	nopl   0x0(%rax)
  7d69e0:	mov    %r8,%r9
  7d69e3:	shr    $1,%r9
  7d69e6:	lea    (%r9,%rbx,1),%r10
  7d69ea:	lea    (%r10,%r10,2),%r11
  7d69ee:	cmp    %r13d,0x4(%r14,%r11,8)
  7d69f3:	cmovb  %r10,%rbx
  7d69f7:	sub    %r9,%r8
  7d69fa:	cmp    $0x1,%r8
  7d69fe:	ja     7d69e0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x700>
  7d6a00:	jmp    7d68d6 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x5f6>
  7d6a05:	mov    %rsi,%r9
  7d6a08:	xor    %r8d,%r8d
  7d6a0b:	nopl   0x0(%rax,%rax,1)
  7d6a10:	mov    %r9,%r10
  7d6a13:	shr    $1,%r10
  7d6a16:	lea    (%r10,%r8,1),%r11
  7d6a1a:	lea    (%r11,%r11,2),%rbx
  7d6a1e:	cmpl   $0x0,(%r14,%rbx,8)
  7d6a23:	cmove  %r11,%r8
  7d6a27:	sub    %r10,%r9
  7d6a2a:	cmp    $0x1,%r9
  7d6a2e:	ja     7d6a10 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x730>
  7d6a30:	lea    (%r8,%r8,2),%r10
  7d6a34:	xor    %r9d,%r9d
  7d6a37:	cmpl   $0x0,(%r14,%r10,8)
  7d6a3c:	sete   %r9b
  7d6a40:	add    %r8,%r9
  7d6a43:	cmp    $0x1,%r9
  7d6a47:	adc    $0xffffffffffffffff,%r9
  7d6a4b:	cmp    %rdi,%r9
  7d6a4e:	je     7d6b02 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x822>
  7d6a54:	test   $0x1,%bpl
  7d6a58:	je     7d68f3 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x613>
  7d6a5e:	mov    %rsi,%r8
  7d6a61:	test   %rsi,%rsi
  7d6a64:	je     7d6abb <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x7db>
  7d6a66:	cmp    $0x1,%rsi
  7d6a6a:	jne    7d6a70 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x790>
  7d6a6c:	xor    %ebx,%ebx
  7d6a6e:	jmp    7d6aa0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x7c0>
  7d6a70:	mov    %rsi,%r8
  7d6a73:	xor    %ebx,%ebx
  7d6a75:	data16 cs nopw 0x0(%rax,%rax,1)
  7d6a80:	mov    %r8,%r9
  7d6a83:	shr    $1,%r9
  7d6a86:	lea    (%r9,%rbx,1),%r10
  7d6a8a:	lea    (%r10,%r10,2),%r11
  7d6a8e:	cmpl   $0x0,(%r14,%r11,8)
  7d6a93:	cmove  %r10,%rbx
  7d6a97:	sub    %r9,%r8
  7d6a9a:	cmp    $0x1,%r8
  7d6a9e:	ja     7d6a80 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x7a0>
  7d6aa0:	lea    (%rbx,%rbx,2),%r9
  7d6aa4:	xor    %r8d,%r8d
  7d6aa7:	cmpl   $0x0,(%r14,%r9,8)
  7d6aac:	sete   %r8b
  7d6ab0:	add    %rbx,%r8
  7d6ab3:	cmp    $0x1,%r8
  7d6ab7:	adc    $0xffffffffffffffff,%r8
  7d6abb:	cmp    %rdi,%r8
  7d6abe:	jne    7d68f3 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x613>
  7d6ac4:	xor    %edx,%edx
  7d6ac6:	xor    %esi,%esi
  7d6ac8:	jmp    7d687b <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x59b>
  7d6acd:	mov    %r13d,%esi
  7d6ad0:	jmp    7d687b <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x59b>
  7d6ad5:	mov    $0x1,%dl
  7d6ad7:	mov    %r13d,%esi
  7d6ada:	jmp    7d687b <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x59b>
  7d6adf:	xor    %edx,%edx
  7d6ae1:	mov    %r13d,%esi
  7d6ae4:	jmp    7d687b <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x59b>
  7d6ae9:	lea    -0x4c51c9(%rip),%rdi        # 311927 <_RNvNtCsghYClfd3M9V_11gpui_canvas4text13PRIMARY_BYTES+0x1f463f>
  7d6af0:	lea    0x2c7ba9(%rip),%rdx        # a9e6a0 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0x1a08>
  7d6af7:	mov    $0x13,%esi
  7d6afc:	call   *0x2e35e6(%rip)        # aba0e8 <_DYNAMIC+0x278>
  7d6b02:	xor    %esi,%esi
  7d6b04:	mov    $0x1,%dl
  7d6b06:	jmp    7d687b <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x59b>
  7d6b0b:	cvtss2sd %xmm1,%xmm1
  7d6b0f:	cvtss2sd %xmm0,%xmm0
  7d6b13:	addsd  %xmm1,%xmm0
  7d6b17:	mulsd  -0x712d8f(%rip),%xmm0        # c3d90 <GCC_except_table0+0x19c4>
  7d6b1f:	movss  0x20(%rsp),%xmm1
  7d6b25:	cvtss2sd %xmm1,%xmm1
  7d6b29:	ucomisd %xmm0,%xmm1
  7d6b2d:	cmova  %eax,%esi
  7d6b30:	movzbl %r9b,%eax
  7d6b34:	movzbl %cl,%edx
  7d6b37:	jmp    7d6878 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x598>
  7d6b3c:	lea    0x2c6ff5(%rip),%rdx        # a9db38 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0xea0>
  7d6b43:	call   *0x2e3597(%rip)        # aba0e0 <_DYNAMIC+0x270>
  7d6b49:	lea    0x2c78f0(%rip),%rdx        # a9e440 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0x17a8>
  7d6b50:	mov    %rsi,%rdi
  7d6b53:	mov    %rax,%rsi
  7d6b56:	call   *0x2e3584(%rip)        # aba0e0 <_DYNAMIC+0x270>
  7d6b5c:	lea    0x2c6f15(%rip),%rdx        # a9da78 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0xde0>
  7d6b63:	call   *0x2e3577(%rip)        # aba0e0 <_DYNAMIC+0x270>

<gpui_canvas::text::layout::TextGeometry>::graphemes bytes=78 frame=0

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007d6b70 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry9graphemes>:
  7d6b70:	mov    %rdi,%rax
  7d6b73:	xor    %ecx,%ecx
  7d6b75:	cmpq   $0xffffffffffffffff,0x30(%rsi)
  7d6b7a:	cmovne 0x40(%rsi),%rcx
  7d6b7f:	mov    $0x4,%edx
  7d6b84:	cmovne 0x38(%rsi),%rdx
  7d6b89:	movss  0x4c(%rsi),%xmm0
  7d6b8e:	mulss  -0x7146be(%rip),%xmm0        # c24d8 <GCC_except_table0+0x10c>
  7d6b96:	xorps  %xmm1,%xmm1
  7d6b99:	movups %xmm1,0x28(%rdi)
  7d6b9d:	mov    %rdx,(%rdi)
  7d6ba0:	mov    %rcx,0x8(%rdi)
  7d6ba4:	mov    %rdx,0x10(%rdi)
  7d6ba8:	mov    %rcx,0x18(%rdi)
  7d6bac:	movq   $0x1,0x20(%rdi)
  7d6bb4:	mov    %rsi,0x38(%rdi)
  7d6bb8:	movss  %xmm0,0x40(%rdi)
  7d6bbd:	ret

<alloc::raw_vec::RawVec<gpui_canvas::text::layout::Run>>::grow_one bytes=100 frame=40

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007d9030 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout3RunE8grow_oneBR_>:
  7d9030:	push   %r14
  7d9032:	push   %rbx
  7d9033:	sub    $0x18,%rsp
  7d9037:	mov    %rdi,%rbx
  7d903a:	mov    (%rdi),%rsi
  7d903d:	lea    (%rsi,%rsi,1),%rax
  7d9041:	cmp    $0x5,%rax
  7d9045:	mov    $0x4,%r14d
  7d904b:	cmovae %rax,%r14
  7d904f:	mov    0x8(%rdi),%rdx
  7d9053:	mov    %rsp,%rdi
  7d9056:	mov    $0x4,%r8d
  7d905c:	mov    $0x18,%r9d
  7d9062:	mov    %r14,%rcx
  7d9065:	call   7d9770 <_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsghYClfd3M9V_11gpui_canvas>
  7d906a:	cmpl   $0x1,(%rsp)
  7d906e:	je     7d9084 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout3RunE8grow_oneBR_+0x54>
  7d9070:	mov    0x8(%rsp),%rax
  7d9075:	mov    %rax,0x8(%rbx)
  7d9079:	mov    %r14,(%rbx)
  7d907c:	add    $0x18,%rsp
  7d9080:	pop    %rbx
  7d9081:	pop    %r14
  7d9083:	ret
  7d9084:	mov    0x8(%rsp),%rdi
  7d9089:	mov    0x10(%rsp),%rsi
  7d908e:	call   *0x2e10cc(%rip)        # aba160 <_DYNAMIC+0x2f0>

<alloc::raw_vec::RawVec<gpui_canvas::text::layout::Stop>>::grow_one bytes=100 frame=40

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007d90a0 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopE8grow_oneBR_>:
  7d90a0:	push   %r14
  7d90a2:	push   %rbx
  7d90a3:	sub    $0x18,%rsp
  7d90a7:	mov    %rdi,%rbx
  7d90aa:	mov    (%rdi),%rsi
  7d90ad:	lea    (%rsi,%rsi,1),%rax
  7d90b1:	cmp    $0x5,%rax
  7d90b5:	mov    $0x4,%r14d
  7d90bb:	cmovae %rax,%r14
  7d90bf:	mov    0x8(%rdi),%rdx
  7d90c3:	mov    %rsp,%rdi
  7d90c6:	mov    $0x4,%r8d
  7d90cc:	mov    $0xc,%r9d
  7d90d2:	mov    %r14,%rcx
  7d90d5:	call   7d9770 <_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsghYClfd3M9V_11gpui_canvas>
  7d90da:	cmpl   $0x1,(%rsp)
  7d90de:	je     7d90f4 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopE8grow_oneBR_+0x54>
  7d90e0:	mov    0x8(%rsp),%rax
  7d90e5:	mov    %rax,0x8(%rbx)
  7d90e9:	mov    %r14,(%rbx)
  7d90ec:	add    $0x18,%rsp
  7d90f0:	pop    %rbx
  7d90f1:	pop    %r14
  7d90f3:	ret
  7d90f4:	mov    0x8(%rsp),%rdi
  7d90f9:	mov    0x10(%rsp),%rsi
  7d90fe:	call   *0x2e105c(%rip)        # aba160 <_DYNAMIC+0x2f0>

<gpui_canvas::text::layout::TextGeometry>::caret_bounds bytes=461 frame=24

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007d9470 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds>:
  7d9470:	push   %r14
  7d9472:	push   %rbx
  7d9473:	push   %rax
  7d9474:	cmpq   $0xffffffffffffffff,0x30(%rsi)
  7d9479:	je     7d957a <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x10a>
  7d947f:	mov    0x38(%rsi),%r8
  7d9483:	mov    0x40(%rsi),%rax
  7d9487:	mov    %rax,%r9
  7d948a:	test   %rax,%rax
  7d948d:	je     7d94cb <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x5b>
  7d948f:	xor    %r9d,%r9d
  7d9492:	cmp    $0x1,%rax
  7d9496:	je     7d94bf <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x4f>
  7d9498:	mov    %rax,%r10
  7d949b:	nopl   0x0(%rax,%rax,1)
  7d94a0:	mov    %r10,%r11
  7d94a3:	shr    $1,%r11
  7d94a6:	lea    (%r11,%r9,1),%rbx
  7d94aa:	lea    (%rbx,%rbx,2),%r14
  7d94ae:	cmp    %edx,(%r8,%r14,4)
  7d94b2:	cmovb  %rbx,%r9
  7d94b6:	sub    %r11,%r10
  7d94b9:	cmp    $0x1,%r10
  7d94bd:	ja     7d94a0 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x30>
  7d94bf:	lea    (%r9,%r9,2),%r10
  7d94c3:	cmp    %edx,(%r8,%r10,4)
  7d94c7:	adc    $0x0,%r9
  7d94cb:	inc    %cl
  7d94cd:	shl    $0x2,%r9
  7d94d1:	lea    (%r9,%r9,2),%r9
  7d94d5:	lea    (%r8,%r9,1),%r10
  7d94d9:	shl    $0x2,%rax
  7d94dd:	lea    (%rax,%rax,2),%rax
  7d94e1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  7d94f0:	xor    %r11d,%r11d
  7d94f3:	cmp    %r9,%rax
  7d94f6:	je     7d961f <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x1af>
  7d94fc:	cmp    %edx,(%r10)
  7d94ff:	jne    7d961f <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x1af>
  7d9505:	movzbl 0x8(%r10),%r11d
  7d950a:	add    $0xc,%r10
  7d950e:	add    $0xc,%r9
  7d9512:	test   %cl,%r11b
  7d9515:	je     7d94f0 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x80>
  7d9517:	mov    0x20(%rsi),%rcx
  7d951b:	mov    0x28(%rsi),%rsi
  7d951f:	test   $0x1,%r11b
  7d9523:	je     7d9582 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x112>
  7d9525:	test   %edx,%edx
  7d9527:	je     7d9582 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x112>
  7d9529:	mov    %rsi,%rax
  7d952c:	test   %rsi,%rsi
  7d952f:	je     7d956d <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0xfd>
  7d9531:	xor    %eax,%eax
  7d9533:	cmp    $0x1,%rsi
  7d9537:	je     7d9560 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0xf0>
  7d9539:	mov    %rsi,%r10
  7d953c:	nopl   0x0(%rax)
  7d9540:	mov    %r10,%r11
  7d9543:	shr    $1,%r11
  7d9546:	lea    (%r11,%rax,1),%rbx
  7d954a:	lea    (%rbx,%rbx,2),%r14
  7d954e:	cmp    %edx,0x4(%rcx,%r14,8)
  7d9553:	cmovb  %rbx,%rax
  7d9557:	sub    %r11,%r10
  7d955a:	cmp    $0x1,%r10
  7d955e:	ja     7d9540 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0xd0>
  7d9560:	lea    (%rax,%rax,2),%r10
  7d9564:	cmp    %edx,0x4(%rcx,%r10,8)
  7d9569:	adc    $0x0,%rax
  7d956d:	lea    -0x1(%rsi),%rdx
  7d9571:	cmp    %rax,%rdx
  7d9574:	cmovb  %rdx,%rax
  7d9578:	jmp    7d95d9 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x169>
  7d957a:	xor    %r11d,%r11d
  7d957d:	jmp    7d961f <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x1af>
  7d9582:	mov    %rsi,%rax
  7d9585:	test   %rsi,%rsi
  7d9588:	je     7d95d9 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x169>
  7d958a:	xor    %r10d,%r10d
  7d958d:	cmp    $0x1,%rsi
  7d9591:	je     7d95c1 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x151>
  7d9593:	mov    %rsi,%rax
  7d9596:	cs nopw 0x0(%rax,%rax,1)
  7d95a0:	mov    %r10,%r11
  7d95a3:	mov    %rax,%rbx
  7d95a6:	shr    $1,%rbx
  7d95a9:	add    %rbx,%r10
  7d95ac:	lea    (%r10,%r10,2),%r14
  7d95b0:	cmp    %edx,(%rcx,%r14,8)
  7d95b4:	cmova  %r11,%r10
  7d95b8:	sub    %rbx,%rax
  7d95bb:	cmp    $0x1,%rax
  7d95bf:	ja     7d95a0 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x130>
  7d95c1:	lea    (%r10,%r10,2),%r11
  7d95c5:	xor    %eax,%eax
  7d95c7:	cmp    %edx,(%rcx,%r11,8)
  7d95cb:	setbe  %al
  7d95ce:	add    %r10,%rax
  7d95d1:	cmp    $0x1,%rax
  7d95d5:	adc    $0xffffffffffffffff,%rax
  7d95d9:	cmp    %rsi,%rax
  7d95dc:	jae    7d962d <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x1bd>
  7d95de:	lea    (%rax,%rax,2),%rax
  7d95e2:	movss  -0x8(%r8,%r9,1),%xmm0
  7d95e9:	movss  -0x7171a9(%rip),%xmm1        # c2448 <GCC_except_table0+0x7c>
  7d95f1:	addss  %xmm0,%xmm1
  7d95f5:	subss  %xmm0,%xmm1
  7d95f9:	movss  0x8(%rcx,%rax,8),%xmm2
  7d95ff:	movss  0xc(%rcx,%rax,8),%xmm3
  7d9605:	movss  %xmm0,0x4(%rdi)
  7d960a:	movss  %xmm2,0x8(%rdi)
  7d960f:	movss  %xmm1,0xc(%rdi)
  7d9614:	movss  %xmm3,0x10(%rdi)
  7d9619:	mov    $0x1,%r11d
  7d961f:	mov    %r11d,(%rdi)
  7d9622:	mov    %rdi,%rax
  7d9625:	add    $0x8,%rsp
  7d9629:	pop    %rbx
  7d962a:	pop    %r14
  7d962c:	ret
  7d962d:	lea    0x2c4a4c(%rip),%rdx        # a9e080 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0x13e8>
  7d9634:	mov    %rax,%rdi
  7d9637:	call   *0x2e0aa3(%rip)        # aba0e0 <_DYNAMIC+0x270>

<gpui_canvas::text::layout::TextGeometry>::validates_selection bytes=290 frame=8

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007d9640 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection>:
  7d9640:	cmpq   $0xffffffffffffffff,0x30(%rdi)
  7d9645:	je     7d975f <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0x11f>
  7d964b:	push   %rbx
  7d964c:	mov    (%rsi),%r8d
  7d964f:	movzbl 0x4(%rsi),%r9d
  7d9654:	mov    0x38(%rdi),%rax
  7d9658:	mov    0x40(%rdi),%rcx
  7d965c:	mov    %rcx,%rdx
  7d965f:	test   %rcx,%rcx
  7d9662:	je     7d969b <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0x5b>
  7d9664:	xor    %edx,%edx
  7d9666:	cmp    $0x1,%rcx
  7d966a:	je     7d968f <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0x4f>
  7d966c:	mov    %rcx,%rdi
  7d966f:	nop
  7d9670:	mov    %rdi,%r10
  7d9673:	shr    $1,%r10
  7d9676:	lea    (%r10,%rdx,1),%r11
  7d967a:	lea    (%r11,%r11,2),%rbx
  7d967e:	cmp    %r8d,(%rax,%rbx,4)
  7d9682:	cmovb  %r11,%rdx
  7d9686:	sub    %r10,%rdi
  7d9689:	cmp    $0x1,%rdi
  7d968d:	ja     7d9670 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0x30>
  7d968f:	lea    (%rdx,%rdx,2),%rdi
  7d9693:	cmp    %r8d,(%rax,%rdi,4)
  7d9697:	adc    $0x0,%rdx
  7d969b:	inc    %r9b
  7d969e:	shl    $0x2,%rdx
  7d96a2:	lea    (%rdx,%rdx,2),%r11
  7d96a6:	lea    (%rax,%r11,1),%rdi
  7d96aa:	lea    0x0(,%rcx,4),%rdx
  7d96b2:	lea    (%rdx,%rdx,2),%rdx
  7d96b6:	mov    %rdx,%r10
  7d96b9:	sub    %r11,%r10
  7d96bc:	nopl   0x0(%rax)
  7d96c0:	test   %r10,%r10
  7d96c3:	je     7d975b <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0x11b>
  7d96c9:	cmp    %r8d,(%rdi)
  7d96cc:	jne    7d975b <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0x11b>
  7d96d2:	add    $0xfffffffffffffff4,%r10
  7d96d6:	test   %r9b,0x8(%rdi)
  7d96da:	lea    0xc(%rdi),%rdi
  7d96de:	je     7d96c0 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0x80>
  7d96e0:	mov    0x8(%rsi),%edi
  7d96e3:	movzbl 0xc(%rsi),%esi
  7d96e7:	test   %rcx,%rcx
  7d96ea:	je     7d972d <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0xed>
  7d96ec:	xor    %r8d,%r8d
  7d96ef:	cmp    $0x1,%rcx
  7d96f3:	je     7d971f <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0xdf>
  7d96f5:	data16 cs nopw 0x0(%rax,%rax,1)
  7d9700:	mov    %rcx,%r9
  7d9703:	shr    $1,%r9
  7d9706:	lea    (%r9,%r8,1),%r10
  7d970a:	lea    (%r10,%r10,2),%r11
  7d970e:	cmp    %edi,(%rax,%r11,4)
  7d9712:	cmovb  %r10,%r8
  7d9716:	sub    %r9,%rcx
  7d9719:	cmp    $0x1,%rcx
  7d971d:	ja     7d9700 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0xc0>
  7d971f:	lea    (%r8,%r8,2),%rcx
  7d9723:	cmp    %edi,(%rax,%rcx,4)
  7d9726:	adc    $0x0,%r8
  7d972a:	mov    %r8,%rcx
  7d972d:	inc    %sil
  7d9730:	shl    $0x2,%rcx
  7d9734:	lea    (%rcx,%rcx,2),%rcx
  7d9738:	add    %rcx,%rax
  7d973b:	sub    %rcx,%rdx
  7d973e:	xchg   %ax,%ax
  7d9740:	test   %rdx,%rdx
  7d9743:	je     7d975b <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0x11b>
  7d9745:	cmp    %edi,(%rax)
  7d9747:	jne    7d975b <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0x11b>
  7d9749:	add    $0xfffffffffffffff4,%rdx
  7d974d:	test   %sil,0x8(%rax)
  7d9751:	lea    0xc(%rax),%rax
  7d9755:	je     7d9740 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0x100>
  7d9757:	mov    $0x1,%al
  7d9759:	pop    %rbx
  7d975a:	ret
  7d975b:	xor    %eax,%eax
  7d975d:	pop    %rbx
  7d975e:	ret
  7d975f:	xor    %eax,%eax
  7d9761:	ret

<gpui_canvas::text::layout::TextGeometry>::source_line bytes=183 frame=0

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007dcf70 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry11source_line>:
  7dcf70:	not    %dl
  7dcf72:	test   %esi,%esi
  7dcf74:	setne  %r8b
  7dcf78:	mov    0x20(%rdi),%rcx
  7dcf7c:	mov    0x28(%rdi),%rax
  7dcf80:	test   %r8b,%dl
  7dcf83:	jne    7dcfd9 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry11source_line+0x69>
  7dcf85:	test   %rax,%rax
  7dcf88:	je     7dd026 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry11source_line+0xb6>
  7dcf8e:	xor    %edx,%edx
  7dcf90:	cmp    $0x1,%rax
  7dcf94:	je     7dcfc1 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry11source_line+0x51>
  7dcf96:	cs nopw 0x0(%rax,%rax,1)
  7dcfa0:	mov    %rdx,%rdi
  7dcfa3:	mov    %rax,%r8
  7dcfa6:	shr    $1,%r8
  7dcfa9:	add    %r8,%rdx
  7dcfac:	lea    (%rdx,%rdx,2),%r9
  7dcfb0:	cmp    %esi,(%rcx,%r9,8)
  7dcfb4:	cmova  %rdi,%rdx
  7dcfb8:	sub    %r8,%rax
  7dcfbb:	cmp    $0x1,%rax
  7dcfbf:	ja     7dcfa0 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry11source_line+0x30>
  7dcfc1:	lea    (%rdx,%rdx,2),%rdi
  7dcfc5:	xor    %eax,%eax
  7dcfc7:	cmp    %esi,(%rcx,%rdi,8)
  7dcfca:	setbe  %al
  7dcfcd:	add    %rdx,%rax
  7dcfd0:	cmp    $0x1,%rax
  7dcfd4:	adc    $0xffffffffffffffff,%rax
  7dcfd8:	ret
  7dcfd9:	mov    %rax,%rdx
  7dcfdc:	test   %rax,%rax
  7dcfdf:	je     7dd01c <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry11source_line+0xac>
  7dcfe1:	xor    %edx,%edx
  7dcfe3:	cmp    $0x1,%rax
  7dcfe7:	je     7dd010 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry11source_line+0xa0>
  7dcfe9:	mov    %rax,%rdi
  7dcfec:	nopl   0x0(%rax)
  7dcff0:	mov    %rdi,%r8
  7dcff3:	shr    $1,%r8
  7dcff6:	lea    (%r8,%rdx,1),%r9
  7dcffa:	lea    (%r9,%r9,2),%r10
  7dcffe:	cmp    %esi,0x4(%rcx,%r10,8)
  7dd003:	cmovb  %r9,%rdx
  7dd007:	sub    %r8,%rdi
  7dd00a:	cmp    $0x1,%rdi
  7dd00e:	ja     7dcff0 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry11source_line+0x80>
  7dd010:	lea    (%rdx,%rdx,2),%rdi
  7dd014:	cmp    %esi,0x4(%rcx,%rdi,8)
  7dd018:	adc    $0x0,%rdx
  7dd01c:	dec    %rax
  7dd01f:	cmp    %rdx,%rax
  7dd022:	cmovae %rdx,%rax
  7dd026:	ret

<gpui_canvas::text::layout::TextGeometry>::stops bytes=213 frame=8

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007dd030 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry5stops>:
  7dd030:	push   %rbx
  7dd031:	mov    %edx,%eax
  7dd033:	xor    %edx,%edx
  7dd035:	cmpq   $0xffffffffffffffff,0x30(%rdi)
  7dd03a:	mov    0x40(%rdi),%r8
  7dd03e:	cmovne %r8,%rdx
  7dd042:	mov    $0x4,%ecx
  7dd047:	cmovne 0x38(%rdi),%rcx
  7dd04c:	test   %esi,%esi
  7dd04e:	je     7dd09c <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry5stops+0x6c>
  7dd050:	test   %rdx,%rdx
  7dd053:	je     7dd0ef <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry5stops+0xbf>
  7dd059:	xor    %edi,%edi
  7dd05b:	cmp    $0x1,%rdx
  7dd05f:	je     7dd08e <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry5stops+0x5e>
  7dd061:	mov    %r8,%r9
  7dd064:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  7dd070:	mov    %r9,%r10
  7dd073:	shr    $1,%r10
  7dd076:	lea    (%r10,%rdi,1),%r11
  7dd07a:	lea    (%r11,%r11,2),%rbx
  7dd07e:	cmp    %esi,(%rcx,%rbx,4)
  7dd081:	cmovb  %r11,%rdi
  7dd085:	sub    %r10,%r9
  7dd088:	cmp    $0x1,%r9
  7dd08c:	ja     7dd070 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry5stops+0x40>
  7dd08e:	lea    (%rdi,%rdi,2),%r9
  7dd092:	cmp    %esi,(%rcx,%r9,4)
  7dd096:	adc    $0x0,%rdi
  7dd09a:	jmp    7dd0a8 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry5stops+0x78>
  7dd09c:	xor    %edi,%edi
  7dd09e:	mov    $0x0,%esi
  7dd0a3:	test   %rdx,%rdx
  7dd0a6:	je     7dd0f5 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry5stops+0xc5>
  7dd0a8:	xor    %esi,%esi
  7dd0aa:	cmp    $0x1,%rdx
  7dd0ae:	je     7dd0d1 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry5stops+0xa1>
  7dd0b0:	mov    %rsi,%r9
  7dd0b3:	mov    %r8,%r10
  7dd0b6:	shr    $1,%r10
  7dd0b9:	add    %r10,%rsi
  7dd0bc:	lea    (%rsi,%rsi,2),%r11
  7dd0c0:	cmp    %eax,(%rcx,%r11,4)
  7dd0c4:	cmova  %r9,%rsi
  7dd0c8:	sub    %r10,%r8
  7dd0cb:	cmp    $0x1,%r8
  7dd0cf:	ja     7dd0b0 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry5stops+0x80>
  7dd0d1:	lea    (%rsi,%rsi,2),%r8
  7dd0d5:	cmp    (%rcx,%r8,4),%eax
  7dd0d9:	sbb    $0xffffffffffffffff,%rsi
  7dd0dd:	cmp    %rdi,%rsi
  7dd0e0:	jae    7dd0f5 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry5stops+0xc5>
  7dd0e2:	lea    0x2c133f(%rip),%rcx        # a9e428 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0x1790>
  7dd0e9:	call   *0x2dd011(%rip)        # aba100 <_DYNAMIC+0x290>
  7dd0ef:	mov    %rdx,%rsi
  7dd0f2:	mov    %rdx,%rdi
  7dd0f5:	sub    %rdi,%rsi
  7dd0f8:	lea    (%rdi,%rdi,2),%rax
  7dd0fc:	lea    (%rcx,%rax,4),%rax
  7dd100:	mov    %rsi,%rdx
  7dd103:	pop    %rbx
  7dd104:	ret

<gpui_canvas::text::layout::TextGeometry>::intervals bytes=43 frame=0

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007dd110 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry9intervals>:
  7dd110:	mov    %rdi,%rax
  7dd113:	xorps  %xmm1,%xmm1
  7dd116:	movups %xmm1,0x28(%rdi)
  7dd11a:	mov    %rdx,(%rdi)
  7dd11d:	mov    %rcx,0x8(%rdi)
  7dd121:	mov    %rdx,0x10(%rdi)
  7dd125:	mov    %rcx,0x18(%rdi)
  7dd129:	movq   $0x1,0x20(%rdi)
  7dd131:	mov    %rsi,0x38(%rdi)
  7dd135:	movss  %xmm0,0x40(%rdi)
  7dd13a:	ret

<alloc::sync::Arc<gpui_canvas::text::layout::TextGeometry>>::drop_slow bytes=135 frame=8

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007e26c0 <_RNvMsn_NtCscdodAO9FK5_5alloc4syncINtB5_3ArcNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryE9drop_slowBL_>:
  7e26c0:	push   %rbx
  7e26c1:	mov    (%rdi),%rbx
  7e26c4:	mov    0x10(%rbx),%rax
  7e26c8:	test   %rax,%rax
  7e26cb:	je     7e26e4 <_RNvMsn_NtCscdodAO9FK5_5alloc4syncINtB5_3ArcNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryE9drop_slowBL_+0x24>
  7e26cd:	mov    0x18(%rbx),%rdi
  7e26d1:	shl    $0x3,%rax
  7e26d5:	lea    (%rax,%rax,2),%rsi
  7e26d9:	mov    $0x4,%edx
  7e26de:	call   *0x2d79cc(%rip)        # aba0b0 <_DYNAMIC+0x240>
  7e26e4:	mov    0x28(%rbx),%rax
  7e26e8:	test   %rax,%rax
  7e26eb:	je     7e2704 <_RNvMsn_NtCscdodAO9FK5_5alloc4syncINtB5_3ArcNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryE9drop_slowBL_+0x44>
  7e26ed:	mov    0x30(%rbx),%rdi
  7e26f1:	shl    $0x3,%rax
  7e26f5:	lea    (%rax,%rax,2),%rsi
  7e26f9:	mov    $0x4,%edx
  7e26fe:	call   *0x2d79ac(%rip)        # aba0b0 <_DYNAMIC+0x240>
  7e2704:	mov    0x40(%rbx),%rax
  7e2708:	test   %rax,%rax
  7e270b:	jle    7e2724 <_RNvMsn_NtCscdodAO9FK5_5alloc4syncINtB5_3ArcNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryE9drop_slowBL_+0x64>
  7e270d:	mov    0x48(%rbx),%rdi
  7e2711:	shl    $0x2,%rax
  7e2715:	lea    (%rax,%rax,2),%rsi
  7e2719:	mov    $0x4,%edx
  7e271e:	call   *0x2d798c(%rip)        # aba0b0 <_DYNAMIC+0x240>
  7e2724:	cmp    $0xffffffffffffffff,%rbx
  7e2728:	je     7e2745 <_RNvMsn_NtCscdodAO9FK5_5alloc4syncINtB5_3ArcNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryE9drop_slowBL_+0x85>
  7e272a:	lock decq 0x8(%rbx)
  7e272f:	jne    7e2745 <_RNvMsn_NtCscdodAO9FK5_5alloc4syncINtB5_3ArcNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryE9drop_slowBL_+0x85>
  7e2731:	mov    $0x60,%esi
  7e2736:	mov    $0x8,%edx
  7e273b:	mov    %rbx,%rdi
  7e273e:	pop    %rbx
  7e273f:	jmp    *0x2d796b(%rip)        # aba0b0 <_DYNAMIC+0x240>
  7e2745:	pop    %rbx
  7e2746:	ret

<core::iter::adapters::zip::Zip<core::slice::iter::ChunkBy<gpui_canvas::text::layout::Stop, <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#0}>, core::iter::adapters::skip::Skip<core::slice::iter::ChunkBy<gpui_canvas::text::layout::Stop, <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#0}>>> as core::iter::traits::iterator::Iterator>::next bytes=289 frame=24

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007e8130 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextB1u_>:
  7e8130:	push   %r15
  7e8132:	push   %r14
  7e8134:	push   %rbx
  7e8135:	mov    0x8(%rsi),%rax
  7e8139:	test   %rax,%rax
  7e813c:	je     7e8244 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextB1u_+0x114>
  7e8142:	mov    (%rsi),%rbx
  7e8145:	mov    $0x1,%r14d
  7e814b:	cmp    $0x1,%rax
  7e814f:	je     7e8174 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextB1u_+0x44>
  7e8151:	mov    (%rbx),%ecx
  7e8153:	lea    0xc(%rbx),%rdx
  7e8157:	lea    0x1(%rax),%r8
  7e815b:	nopl   0x0(%rax,%rax,1)
  7e8160:	cmp    (%rdx),%ecx
  7e8162:	jne    7e8174 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextB1u_+0x44>
  7e8164:	inc    %r14
  7e8167:	add    $0xc,%rdx
  7e816b:	dec    %r8
  7e816e:	cmp    $0x2,%r8
  7e8172:	ja     7e8160 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextB1u_+0x30>
  7e8174:	sub    %r14,%rax
  7e8177:	jb     7e820d <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextB1u_+0xdd>
  7e817d:	lea    (%r14,%r14,2),%rcx
  7e8181:	lea    (%rbx,%rcx,4),%rcx
  7e8185:	mov    %rcx,(%rsi)
  7e8188:	mov    %rax,0x8(%rsi)
  7e818c:	lea    0x10(%rsi),%rax
  7e8190:	mov    0x20(%rsi),%rcx
  7e8194:	test   %rcx,%rcx
  7e8197:	jne    7e8226 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextB1u_+0xf6>
  7e819d:	mov    0x18(%rsi),%rcx
  7e81a1:	test   %rcx,%rcx
  7e81a4:	je     7e81f1 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextB1u_+0xc1>
  7e81a6:	mov    (%rax),%rax
  7e81a9:	mov    $0x1,%edx
  7e81ae:	cmp    $0x1,%rcx
  7e81b2:	je     7e81d5 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextB1u_+0xa5>
  7e81b4:	mov    (%rax),%r8d
  7e81b7:	lea    0xc(%rax),%r9
  7e81bb:	lea    0x1(%rcx),%r10
  7e81bf:	nop
  7e81c0:	cmp    (%r9),%r8d
  7e81c3:	jne    7e81d5 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextB1u_+0xa5>
  7e81c5:	inc    %rdx
  7e81c8:	add    $0xc,%r9
  7e81cc:	dec    %r10
  7e81cf:	cmp    $0x2,%r10
  7e81d3:	ja     7e81c0 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextB1u_+0x90>
  7e81d5:	sub    %rdx,%rcx
  7e81d8:	jb     7e820d <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextB1u_+0xdd>
  7e81da:	lea    (%rdx,%rdx,2),%r8
  7e81de:	lea    (%rax,%r8,4),%r8
  7e81e2:	mov    %r8,0x10(%rsi)
  7e81e6:	mov    %rcx,0x18(%rsi)
  7e81ea:	test   %rax,%rax
  7e81ed:	jne    7e81f8 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextB1u_+0xc8>
  7e81ef:	jmp    7e8244 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextB1u_+0x114>
  7e81f1:	xor    %eax,%eax
  7e81f3:	test   %rax,%rax
  7e81f6:	je     7e8244 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextB1u_+0x114>
  7e81f8:	mov    %rbx,(%rdi)
  7e81fb:	mov    %r14,0x8(%rdi)
  7e81ff:	mov    %rax,0x10(%rdi)
  7e8203:	mov    %rdx,0x18(%rdi)
  7e8207:	pop    %rbx
  7e8208:	pop    %r14
  7e820a:	pop    %r15
  7e820c:	ret
  7e820d:	lea    -0x4d68ed(%rip),%rdi        # 311927 <_RNvNtCsghYClfd3M9V_11gpui_canvas4text13PRIMARY_BYTES+0x1f463f>
  7e8214:	lea    0x2b6485(%rip),%rdx        # a9e6a0 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0x1a08>
  7e821b:	mov    $0x13,%esi
  7e8220:	call   *0x2d1ec2(%rip)        # aba0e8 <_DYNAMIC+0x278>
  7e8226:	movq   $0x0,0x20(%rsi)
  7e822e:	mov    %rdi,%r15
  7e8231:	mov    %rax,%rdi
  7e8234:	mov    %rcx,%rsi
  7e8237:	call   7e8b60 <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthBR_>
  7e823c:	mov    %r15,%rdi
  7e823f:	test   %rax,%rax
  7e8242:	jne    7e81f8 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextB1u_+0xc8>
  7e8244:	movq   $0x0,(%rdi)
  7e824b:	pop    %rbx
  7e824c:	pop    %r14
  7e824e:	pop    %r15
  7e8250:	ret

<core::slice::iter::ChunkBy<gpui_canvas::text::layout::Stop, <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#0}> as core::iter::traits::iterator::Iterator>::nth bytes=232 frame=8

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007e8b60 <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthBR_>:
  7e8b60:	push   %rax
  7e8b61:	mov    (%rdi),%rax
  7e8b64:	mov    0x8(%rdi),%r8
  7e8b68:	nopl   0x0(%rax,%rax,1)
  7e8b70:	mov    %r8,%rcx
  7e8b73:	mov    %rax,%r9
  7e8b76:	mov    %r8,%r10
  7e8b79:	cmp    $0x1,%r8
  7e8b7d:	je     7e8bb4 <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthBR_+0x54>
  7e8b7f:	test   %rcx,%rcx
  7e8b82:	je     7e8c2b <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthBR_+0xcb>
  7e8b88:	mov    (%r9),%eax
  7e8b8b:	lea    0xc(%r9),%rdx
  7e8b8f:	lea    0x1(%rcx),%r8
  7e8b93:	mov    $0x1,%r10d
  7e8b99:	nopl   0x0(%rax)
  7e8ba0:	cmp    (%rdx),%eax
  7e8ba2:	jne    7e8bb4 <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthBR_+0x54>
  7e8ba4:	inc    %r10
  7e8ba7:	add    $0xc,%rdx
  7e8bab:	dec    %r8
  7e8bae:	cmp    $0x2,%r8
  7e8bb2:	ja     7e8ba0 <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthBR_+0x40>
  7e8bb4:	mov    %rcx,%r8
  7e8bb7:	sub    %r10,%r8
  7e8bba:	jb     7e8c2f <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthBR_+0xcf>
  7e8bbc:	lea    (%r10,%r10,2),%r11
  7e8bc0:	lea    (%r9,%r11,4),%rax
  7e8bc4:	mov    %rax,(%rdi)
  7e8bc7:	mov    %r8,0x8(%rdi)
  7e8bcb:	dec    %rsi
  7e8bce:	jne    7e8b70 <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthBR_+0x10>
  7e8bd0:	test   %r8,%r8
  7e8bd3:	je     7e8c2b <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthBR_+0xcb>
  7e8bd5:	mov    %r8,%rdx
  7e8bd8:	cmp    $0x1,%r8
  7e8bdc:	je     7e8c15 <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthBR_+0xb5>
  7e8bde:	mov    (%rax),%esi
  7e8be0:	lea    (%r9,%r11,4),%r9
  7e8be4:	add    $0xc,%r9
  7e8be8:	sub    %r10,%rcx
  7e8beb:	inc    %rcx
  7e8bee:	mov    $0x1,%edx
  7e8bf3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  7e8c00:	cmp    (%r9),%esi
  7e8c03:	jne    7e8c15 <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthBR_+0xb5>
  7e8c05:	inc    %rdx
  7e8c08:	add    $0xc,%r9
  7e8c0c:	dec    %rcx
  7e8c0f:	cmp    $0x2,%rcx
  7e8c13:	ja     7e8c00 <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthBR_+0xa0>
  7e8c15:	sub    %rdx,%r8
  7e8c18:	jb     7e8c2f <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthBR_+0xcf>
  7e8c1a:	lea    (%rdx,%rdx,2),%rcx
  7e8c1e:	lea    (%rax,%rcx,4),%rcx
  7e8c22:	mov    %rcx,(%rdi)
  7e8c25:	mov    %r8,0x8(%rdi)
  7e8c29:	pop    %rcx
  7e8c2a:	ret
  7e8c2b:	xor    %eax,%eax
  7e8c2d:	pop    %rcx
  7e8c2e:	ret
  7e8c2f:	lea    -0x4d730f(%rip),%rdi        # 311927 <_RNvNtCsghYClfd3M9V_11gpui_canvas4text13PRIMARY_BYTES+0x1f463f>
  7e8c36:	lea    0x2b5a63(%rip),%rdx        # a9e6a0 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0x1a08>
  7e8c3d:	mov    $0x13,%esi
  7e8c42:	call   *0x2d14a0(%rip)        # aba0e8 <_DYNAMIC+0x278>
