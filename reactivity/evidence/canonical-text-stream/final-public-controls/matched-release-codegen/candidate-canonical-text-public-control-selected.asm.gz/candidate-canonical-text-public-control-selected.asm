
<core::option::Option<alloc::vec::Vec<gpui::runtime::geometry::Record>>>::or_else::<<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::present_inner::{closure#42}> bytes=105 frame=0

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000073d2a0 <_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime8geometry6RecordEE7or_elseNCNvMsu_B1i_INtB1i_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersE_0EB2E_>:
  73d2a0:	cmpq   $0xffffffffffffffff,(%rsi)
  73d2a4:	je     73d2cf <_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime8geometry6RecordEE7or_elseNCNvMsu_B1i_INtB1i_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersE_0EB2E_+0x2f>
  73d2a6:	mov    0x10(%rsi),%rax
  73d2aa:	mov    %rax,0x10(%rdi)
  73d2ae:	movups (%rsi),%xmm0
  73d2b1:	movups %xmm0,(%rdi)
  73d2b4:	mov    (%rdx),%rsi
  73d2b7:	test   %rsi,%rsi
  73d2ba:	je     73d2ea <_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime8geometry6RecordEE7or_elseNCNvMsu_B1i_INtB1i_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersE_0EB2E_+0x4a>
  73d2bc:	mov    0x8(%rdx),%rdi
  73d2c0:	shl    $0x4,%rsi
  73d2c4:	mov    $0x4,%edx
  73d2c9:	jmp    *0x37bbd1(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  73d2cf:	mov    (%rdx),%rsi
  73d2d2:	mov    0x8(%rdx),%rax
  73d2d6:	mov    0x10(%rdx),%rcx
  73d2da:	test   %rcx,%rcx
  73d2dd:	je     73d2eb <_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime8geometry6RecordEE7or_elseNCNvMsu_B1i_INtB1i_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersE_0EB2E_+0x4b>
  73d2df:	mov    %rsi,(%rdi)
  73d2e2:	mov    %rax,0x8(%rdi)
  73d2e6:	mov    %rcx,0x10(%rdi)
  73d2ea:	ret
  73d2eb:	movq   $0xffffffffffffffff,(%rdi)
  73d2f2:	test   %rsi,%rsi
  73d2f5:	je     73d2ea <_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime8geometry6RecordEE7or_elseNCNvMsu_B1i_INtB1i_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersE_0EB2E_+0x4a>
  73d2f7:	shl    $0x4,%rsi
  73d2fb:	mov    $0x4,%edx
  73d300:	mov    %rax,%rdi
  73d303:	jmp    *0x37bb97(%rip)        # ab8ea0 <_DYNAMIC+0x240>

<gpui::runtime::RuntimeMut<canonical_text_public_control::Editor, ()>>::operation_with_editing::<<gpui::runtime::RuntimeMut<canonical_text_public_control::Editor, ()>>::replace_input::{closure#2}> bytes=974 frame=280

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000073d870 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_>:
  73d870:	push   %rbp
  73d871:	push   %r15
  73d873:	push   %r14
  73d875:	push   %r13
  73d877:	push   %r12
  73d879:	push   %rbx
  73d87a:	sub    $0xe8,%rsp
  73d881:	mov    %rdi,%rbx
  73d884:	mov    (%rsi),%r14
  73d887:	mov    $0xe,%eax
  73d88c:	cmpb   $0x0,0x76e(%r14)
  73d894:	je     73d8c5 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x55>
  73d896:	mov    %rax,(%rbx)
  73d899:	mov    (%rcx),%rsi
  73d89c:	test   %rsi,%rsi
  73d89f:	je     73db85 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x315>
  73d8a5:	mov    0x8(%rcx),%rdi
  73d8a9:	mov    $0x1,%edx
  73d8ae:	add    $0xe8,%rsp
  73d8b5:	pop    %rbx
  73d8b6:	pop    %r12
  73d8b8:	pop    %r13
  73d8ba:	pop    %r14
  73d8bc:	pop    %r15
  73d8be:	pop    %rbp
  73d8bf:	jmp    *0x37b5db(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  73d8c5:	mov    0x6a0(%r14),%r9
  73d8cc:	inc    %r9
  73d8cf:	je     73db97 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x327>
  73d8d5:	mov    (%rcx),%r11
  73d8d8:	mov    0x8(%rcx),%r10
  73d8dc:	mov    0x10(%rcx),%r13
  73d8e0:	mov    0x18(%rcx),%r12
  73d8e4:	mov    0x20(%rcx),%r15
  73d8e8:	mov    0x228(%r14),%rax
  73d8ef:	lea    0x230(%r14),%rcx
  73d8f6:	cmp    $0xffffffffffffffff,%rax
  73d8fa:	lea    0x88(%rsp),%rdi
  73d902:	cmovne %rcx,%rdi
  73d906:	movups (%rdi),%xmm0
  73d909:	movaps %xmm0,0xd0(%rsp)
  73d911:	je     73d974 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x104>
  73d913:	movaps 0xd0(%rsp),%xmm0
  73d91b:	movups %xmm0,0x48(%rsp)
  73d920:	mov    %rax,0x40(%rsp)
  73d925:	mov    %r11,0x58(%rsp)
  73d92a:	mov    %r10,0x60(%rsp)
  73d92f:	mov    %r13,0x68(%rsp)
  73d934:	mov    %r12,0x70(%rsp)
  73d939:	mov    0x40(%rsp),%rax
  73d93e:	cmp    $0xfffffffffffffffe,%rax
  73d942:	jne    73db12 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x2a2>
  73d948:	mov    %r9,0x6a0(%r14)
  73d94f:	incq   0x700(%r14)
  73d956:	movq   $0x0,0x758(%r14)
  73d961:	mov    %rbx,%rdi
  73d964:	mov    %r8,%rcx
  73d967:	xor    %r8d,%r8d
  73d96a:	call   766c80 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB4_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE20after_source_changedBW_>
  73d96f:	jmp    73db85 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x315>
  73d974:	mov    %r13,0x38(%rsp)
  73d979:	mov    %r15,0x78(%rsp)
  73d97e:	mov    %r11,0x8(%rsp)
  73d983:	mov    %r10,0x10(%rsp)
  73d988:	mov    %r9,0x18(%rsp)
  73d98d:	mov    %rsi,0x20(%rsp)
  73d992:	mov    %rdx,0x28(%rsp)
  73d997:	mov    %r8,0x30(%rsp)
  73d99c:	cmp    $0x1,%r12d
  73d9a0:	jne    73da30 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x1c0>
  73d9a6:	mov    0x248(%r14),%r15
  73d9ad:	mov    0x250(%r14),%r13
  73d9b4:	shl    $0x4,%r13
  73d9b8:	xor    %ebp,%ebp
  73d9ba:	nopw   0x0(%rax,%rax,1)
  73d9c0:	cmp    %rbp,%r13
  73d9c3:	je     73dabe <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x24e>
  73d9c9:	mov    (%r15,%rbp,1),%rdi
  73d9cd:	mov    0x8(%r15,%rbp,1),%rax
  73d9d2:	call   *0x18(%rax)
  73d9d5:	add    $0x10,%rbp
  73d9d9:	cmp    %r12,%rax
  73d9dc:	jne    73d9c0 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x150>
  73d9de:	mov    -0x10(%r15,%rbp,1),%rsi
  73d9e3:	mov    -0x8(%r15,%rbp,1),%rax
  73d9e8:	mov    0x8(%rsp),%rcx
  73d9ed:	mov    %rcx,0x80(%rsp)
  73d9f5:	mov    0x10(%rsp),%rcx
  73d9fa:	mov    %rcx,0x88(%rsp)
  73da02:	mov    0x38(%rsp),%rcx
  73da07:	mov    %rcx,0x90(%rsp)
  73da0f:	lea    0x40(%rsp),%rdi
  73da14:	lea    0x80(%rsp),%rcx
  73da1c:	lea    0x290(%r14),%rdx
  73da23:	mov    0x78(%rsp),%r8
  73da28:	call   *0x40(%rax)
  73da2b:	jmp    73daef <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x27f>
  73da30:	mov    0x278(%r14),%r15
  73da37:	mov    0x280(%r14),%rbp
  73da3e:	shl    $0x4,%rbp
  73da42:	xor    %r13d,%r13d
  73da45:	data16 cs nopw 0x0(%rax,%rax,1)
  73da50:	cmp    %r13,%rbp
  73da53:	je     73dabe <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x24e>
  73da55:	mov    (%r15,%r13,1),%rdi
  73da59:	mov    0x8(%r15,%r13,1),%rax
  73da5e:	mov    %r12,%rsi
  73da61:	call   *0x30(%rax)
  73da64:	add    $0x10,%r13
  73da68:	test   %al,%al
  73da6a:	je     73da50 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x1e0>
  73da6c:	mov    -0x10(%r15,%r13,1),%rsi
  73da71:	mov    -0x8(%r15,%r13,1),%rax
  73da76:	mov    0x8(%rsp),%rcx
  73da7b:	mov    %rcx,0x80(%rsp)
  73da83:	mov    0x10(%rsp),%rcx
  73da88:	mov    %rcx,0x88(%rsp)
  73da90:	mov    0x38(%rsp),%rcx
  73da95:	mov    %rcx,0x90(%rsp)
  73da9d:	lea    0x40(%rsp),%rdi
  73daa2:	lea    0x80(%rsp),%r8
  73daaa:	lea    0x290(%r14),%rdx
  73dab1:	mov    %r12,%rcx
  73dab4:	mov    0x78(%rsp),%r9
  73dab9:	call   *0x70(%rax)
  73dabc:	jmp    73daef <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x27f>
  73dabe:	movq   $0xb,0x40(%rsp)
  73dac7:	mov    %r12,0x48(%rsp)
  73dacc:	mov    0x8(%rsp),%rax
  73dad1:	mov    %rax,0x58(%rsp)
  73dad6:	mov    0x10(%rsp),%rax
  73dadb:	mov    %rax,0x60(%rsp)
  73dae0:	mov    0x38(%rsp),%rax
  73dae5:	mov    %rax,0x68(%rsp)
  73daea:	mov    %r12,0x70(%rsp)
  73daef:	mov    0x30(%rsp),%r8
  73daf4:	mov    0x28(%rsp),%rdx
  73daf9:	mov    0x20(%rsp),%rsi
  73dafe:	mov    0x18(%rsp),%r9
  73db03:	mov    0x40(%rsp),%rax
  73db08:	cmp    $0xfffffffffffffffe,%rax
  73db0c:	je     73d948 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0xd8>
  73db12:	mov    0x48(%rsp),%rcx
  73db17:	movups 0x50(%rsp),%xmm0
  73db1c:	movups 0x60(%rsp),%xmm1
  73db21:	mov    0x70(%rsp),%rdx
  73db26:	mov    %rcx,0xa0(%rsp)
  73db2e:	movups %xmm0,0xa8(%rsp)
  73db36:	movups %xmm1,0xb8(%rsp)
  73db3e:	mov    %rdx,0xc8(%rsp)
  73db46:	movups 0xb0(%rsp),%xmm0
  73db4e:	movups %xmm0,0x18(%rbx)
  73db52:	mov    0xc0(%rsp),%rcx
  73db5a:	mov    %rcx,0x28(%rbx)
  73db5e:	mov    0xc8(%rsp),%rcx
  73db66:	mov    %rcx,0x30(%rbx)
  73db6a:	mov    0xa0(%rsp),%rcx
  73db72:	mov    %rcx,0x8(%rbx)
  73db76:	mov    0xa8(%rsp),%rcx
  73db7e:	mov    %rcx,0x10(%rbx)
  73db82:	mov    %rax,(%rbx)
  73db85:	add    $0xe8,%rsp
  73db8c:	pop    %rbx
  73db8d:	pop    %r12
  73db8f:	pop    %r13
  73db91:	pop    %r14
  73db93:	pop    %r15
  73db95:	pop    %rbp
  73db96:	ret
  73db97:	mov    $0x1f,%eax
  73db9c:	mov    %rax,(%rbx)
  73db9f:	mov    (%rcx),%rsi
  73dba2:	test   %rsi,%rsi
  73dba5:	jne    73d8a5 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x35>
  73dbab:	jmp    73db85 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x315>
  73dbad:	mov    %rax,%r12
  73dbb0:	jmp    73dbd4 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x364>
  73dbb2:	jmp    73dbb4 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x344>
  73dbb4:	mov    %rax,%r12
  73dbb7:	cmpq   $0x0,0x8(%rsp)
  73dbbd:	je     73dbd4 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x364>
  73dbbf:	mov    $0x1,%edx
  73dbc4:	mov    0x10(%rsp),%rdi
  73dbc9:	mov    0x8(%rsp),%rsi
  73dbce:	call   *0x37b2cc(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  73dbd4:	mov    %r12,%rdi
  73dbd7:	call   *0x37b31b(%rip)        # ab8ef8 <_DYNAMIC+0x298>
  73dbdd:	mov    %rax,0xa0(%rsp)
  73dbe5:	mov    %rdx,0xa8(%rsp)
  73dbed:	movq   $0xfffffffffffffffd,0x98(%rsp)
  73dbf9:	mov    %r14,%rdi
  73dbfc:	call   78cbc0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE6poisonBO_>
  73dc01:	movq   $0xf,(%rbx)
  73dc08:	lea    0x98(%rsp),%rdi
  73dc10:	call   746090 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultIBC_NtNtNtCslbxve4rcJus_4gpui7runtime5paint12PatchOutcomeNtB15_5ErrorEINtNtCscdodAO9FK5_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECs9C2G9YFESsD_29canonical_text_public_control>
  73dc15:	jmp    73db85 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x315>
  73dc1a:	mov    %rax,%rbx
  73dc1d:	lea    0x98(%rsp),%rdi
  73dc25:	call   746090 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultIBC_NtNtNtCslbxve4rcJus_4gpui7runtime5paint12PatchOutcomeNtB15_5ErrorEINtNtCscdodAO9FK5_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECs9C2G9YFESsD_29canonical_text_public_control>
  73dc2a:	mov    %rbx,%rdi
  73dc2d:	call   a97380 <_Unwind_Resume@plt>
  73dc32:	call   *0x37b290(%rip)        # ab8ec8 <_DYNAMIC+0x268>
  73dc38:	call   *0x37b2c2(%rip)        # ab8f00 <_DYNAMIC+0x2a0>

<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::present_inner::{closure#30}> bytes=1513 frame=328

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000073f430 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_>:
  73f430:	push   %rbp
  73f431:	push   %r15
  73f433:	push   %r14
  73f435:	push   %r13
  73f437:	push   %r12
  73f439:	push   %rbx
  73f43a:	sub    $0x118,%rsp
  73f441:	test   %rdi,%rdi
  73f444:	je     73f8e5 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x4b5>
  73f44a:	mov    %rsi,%r12
  73f44d:	mov    %rdi,%r15
  73f450:	lea    0x10(%rdi),%r14
  73f454:	mov    (%rdx),%r13
  73f457:	mov    0x8(%rdx),%rax
  73f45b:	mov    %rax,0x78(%rsp)
  73f460:	mov    0x10(%rdx),%rbp
  73f464:	mov    0x18(%rdx),%rax
  73f468:	mov    %rax,0x68(%rsp)
  73f46d:	mov    0x20(%rdx),%rbx
  73f471:	mov    0x28(%rdx),%rax
  73f475:	mov    %rax,0x70(%rsp)
  73f47a:	mov    %r14,%rdi
  73f47d:	call   *0x379a9d(%rip)        # ab8f20 <_DYNAMIC+0x2c0>
  73f483:	test   %al,%al
  73f485:	je     73f8e5 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x4b5>
  73f48b:	mov    (%r12),%esi
  73f48f:	mov    0x8(%r12),%ecx
  73f494:	mov    $0x1,%al
  73f496:	cmp    %esi,%ecx
  73f498:	je     73f8e7 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x4b7>
  73f49e:	mov    %esi,%edx
  73f4a0:	cmova  %ecx,%edx
  73f4a3:	cmovb  %ecx,%esi
  73f4a6:	mov    %r14,%rdi
  73f4a9:	call   *0x379a79(%rip)        # ab8f28 <_DYNAMIC+0x2c8>
  73f4af:	test   %rax,%rax
  73f4b2:	je     73f9f5 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x5c5>
  73f4b8:	mov    %rdx,%rcx
  73f4bb:	movss  0x5c(%r15),%xmm0
  73f4c1:	mulss  -0x67d071(%rip),%xmm0        # c2458 <GCC_except_table0+0xf0>
  73f4c9:	lea    0xc0(%rsp),%rdi
  73f4d1:	mov    %r14,%rsi
  73f4d4:	mov    %rax,%rdx
  73f4d7:	call   *0x379a53(%rip)        # ab8f30 <_DYNAMIC+0x2d0>
  73f4dd:	mov    0xc8(%rsp),%r10
  73f4e5:	mov    0xd0(%rsp),%rcx
  73f4ed:	cmp    %r10,%rcx
  73f4f0:	mov    $0x1,%al
  73f4f2:	ja     73f8e7 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x4b7>
  73f4f8:	lea    0xd8(%rsp),%rsi
  73f500:	xor    %r12d,%r12d
  73f503:	lea    0x80(%rsp),%r11
  73f50b:	lea    0x100(%rsp),%rdi
  73f513:	test   $0x1,%r12b
  73f517:	je     73f6a6 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x276>
  73f51d:	cmp    $0x1,%rcx
  73f521:	je     73fa02 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x5d2>
  73f527:	mov    0xc0(%rsp),%rdx
  73f52f:	mov    (%rdx),%r9d
  73f532:	add    $0xc,%rdx
  73f536:	jmp    73f550 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x120>
  73f538:	nopl   0x0(%rax,%rax,1)
  73f540:	dec    %r10
  73f543:	add    $0xc,%rdx
  73f547:	cmp    %r10,%rcx
  73f54a:	ja     73f8f9 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x4c9>
  73f550:	mov    %r9d,%r8d
  73f553:	mov    (%rdx),%r9d
  73f556:	cmp    %r9d,%r8d
  73f559:	je     73f540 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x110>
  73f55b:	testb  $0x2,-0x4(%rdx)
  73f55f:	je     73f540 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x110>
  73f561:	testb  $0x1,0x8(%rdx)
  73f565:	je     73f540 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x110>
  73f567:	movaps %xmm3,0x40(%rsp)
  73f56c:	mov    %rdi,%r14
  73f56f:	mov    %rdx,0xc0(%rsp)
  73f577:	dec    %r10
  73f57a:	mov    %r10,0xc8(%rsp)
  73f582:	add    $0xfffffffffffffff4,%rdx
  73f586:	mov    %r11,%rdi
  73f589:	mov    %rsi,%r15
  73f58c:	call   75d2b0 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control>
  73f591:	xorps  %xmm0,%xmm0
  73f594:	movss  0x98(%rsp),%xmm6
  73f59d:	ucomiss %xmm0,%xmm6
  73f5a0:	jne    73f5b6 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x186>
  73f5a2:	jp     73f5b6 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x186>
  73f5a4:	mov    $0x1,%al
  73f5a6:	mov    %r14,%rdi
  73f5a9:	mov    %r15,%rsi
  73f5ac:	movaps 0x40(%rsp),%xmm3
  73f5b1:	jmp    73f680 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x250>
  73f5b6:	movss  0x90(%rsp),%xmm5
  73f5bf:	movss  0x94(%rsp),%xmm7
  73f5c8:	movss  0x9c(%rsp),%xmm8
  73f5d2:	mov    0xa0(%rsp),%rdx
  73f5da:	cmp    %rdx,0x38(%rsp)
  73f5df:	mov    %r14,%rdi
  73f5e2:	movaps 0x40(%rsp),%xmm2
  73f5e7:	jne    73f8cf <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x49f>
  73f5ed:	movaps 0x20(%rsp),%xmm0
  73f5f2:	ucomiss %xmm7,%xmm0
  73f5f5:	mov    $0x1,%al
  73f5f7:	mov    %r15,%rsi
  73f5fa:	movaps 0x10(%rsp),%xmm4
  73f5ff:	jne    73f79d <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x36d>
  73f605:	jp     73f79d <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x36d>
  73f60b:	movss  0xc(%rsp),%xmm0
  73f611:	ucomiss %xmm8,%xmm0
  73f615:	jne    73f79d <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x36d>
  73f61b:	jp     73f79d <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x36d>
  73f621:	movaps %xmm5,%xmm1
  73f624:	addss  %xmm6,%xmm1
  73f628:	ucomiss %xmm4,%xmm1
  73f62b:	jb     73f798 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x368>
  73f631:	movaps %xmm2,%xmm0
  73f634:	addss  %xmm4,%xmm0
  73f638:	ucomiss %xmm5,%xmm0
  73f63b:	jb     73f798 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x368>
  73f641:	movaps %xmm0,%xmm2
  73f644:	maxss  %xmm1,%xmm2
  73f648:	movaps %xmm2,%xmm3
  73f64b:	cmpunordss %xmm2,%xmm3
  73f650:	movaps %xmm3,%xmm1
  73f653:	andnps %xmm2,%xmm1
  73f656:	andps  %xmm0,%xmm3
  73f659:	orps   %xmm1,%xmm3
  73f65c:	movaps %xmm4,%xmm0
  73f65f:	minss  %xmm5,%xmm0
  73f663:	movaps %xmm0,%xmm1
  73f666:	cmpunordss %xmm0,%xmm1
  73f66b:	movaps %xmm1,%xmm2
  73f66e:	andnps %xmm0,%xmm2
  73f671:	andps  %xmm4,%xmm1
  73f674:	orps   %xmm2,%xmm1
  73f677:	subss  %xmm1,%xmm3
  73f67b:	movaps %xmm1,0x10(%rsp)
  73f680:	mov    0xc8(%rsp),%r10
  73f688:	mov    0xd0(%rsp),%rcx
  73f690:	cmp    %r10,%rcx
  73f693:	lea    0x80(%rsp),%r11
  73f69b:	jbe    73f51d <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0xed>
  73f6a1:	jmp    73f9bd <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x58d>
  73f6a6:	cmp    $0x1,%rcx
  73f6aa:	je     73fa02 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x5d2>
  73f6b0:	mov    0xc0(%rsp),%rdx
  73f6b8:	mov    (%rdx),%r9d
  73f6bb:	add    $0xc,%rdx
  73f6bf:	jmp    73f6e0 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x2b0>
  73f6c1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  73f6d0:	dec    %r10
  73f6d3:	add    $0xc,%rdx
  73f6d7:	cmp    %r10,%rcx
  73f6da:	ja     73f8f9 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x4c9>
  73f6e0:	mov    %r9d,%r8d
  73f6e3:	mov    (%rdx),%r9d
  73f6e6:	cmp    %r9d,%r8d
  73f6e9:	je     73f6d0 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x2a0>
  73f6eb:	testb  $0x2,-0x4(%rdx)
  73f6ef:	je     73f6d0 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x2a0>
  73f6f1:	testb  $0x1,0x8(%rdx)
  73f6f5:	je     73f6d0 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x2a0>
  73f6f7:	movaps %xmm3,0x40(%rsp)
  73f6fc:	mov    %rdi,%r14
  73f6ff:	mov    %rdx,0xc0(%rsp)
  73f707:	dec    %r10
  73f70a:	mov    %r10,0xc8(%rsp)
  73f712:	add    $0xfffffffffffffff4,%rdx
  73f716:	mov    %r11,%rdi
  73f719:	mov    %rsi,%r15
  73f71c:	call   75d2b0 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control>
  73f721:	xorps  %xmm0,%xmm0
  73f724:	movss  0x98(%rsp),%xmm6
  73f72d:	ucomiss %xmm0,%xmm6
  73f730:	jne    73f767 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x337>
  73f732:	jp     73f767 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x337>
  73f734:	mov    0xc8(%rsp),%r10
  73f73c:	mov    0xd0(%rsp),%rcx
  73f744:	cmp    %r10,%rcx
  73f747:	mov    $0x1,%al
  73f749:	mov    %r14,%rdi
  73f74c:	mov    %r15,%rsi
  73f74f:	lea    0x80(%rsp),%r11
  73f757:	movaps 0x40(%rsp),%xmm3
  73f75c:	jbe    73f6a6 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x276>
  73f762:	jmp    73f8e7 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x4b7>
  73f767:	movss  0x90(%rsp),%xmm5
  73f770:	movss  0x94(%rsp),%xmm7
  73f779:	movss  0x9c(%rsp),%xmm8
  73f783:	mov    0xa0(%rsp),%rdx
  73f78b:	mov    $0x1,%al
  73f78d:	mov    %r14,%rdi
  73f790:	mov    %r15,%rsi
  73f793:	jmp    73f88d <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x45d>
  73f798:	mov    0x38(%rsp),%rdx
  73f79d:	cmpl   $0xffffffff,0x0(%r13)
  73f7a2:	jne    73f88d <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x45d>
  73f7a8:	unpcklps 0x20(%rsp),%xmm4
  73f7ad:	mov    0x68(%rsp),%rax
  73f7b2:	movss  (%rax),%xmm0
  73f7b6:	movss  0x0(%rbp),%xmm1
  73f7bb:	unpcklps %xmm0,%xmm1
  73f7be:	addps  %xmm4,%xmm1
  73f7c1:	movlps %xmm1,0xf0(%rsp)
  73f7c9:	movss  %xmm2,0xf8(%rsp)
  73f7d2:	movss  0xc(%rsp),%xmm0
  73f7d8:	movss  %xmm0,0xfc(%rsp)
  73f7e1:	mov    0x10(%rbx),%rax
  73f7e5:	mov    %rax,0x90(%rsp)
  73f7ed:	movups (%rbx),%xmm0
  73f7f0:	movaps %xmm0,0x80(%rsp)
  73f7f8:	mov    0x70(%rsp),%rax
  73f7fd:	movups (%rax),%xmm0
  73f800:	movaps %xmm0,0x50(%rsp)
  73f805:	mov    $0x46,%esi
  73f80a:	mov    %rdx,%r12
  73f80d:	mov    $0x82,%edx
  73f812:	mov    $0xf0,%ecx
  73f817:	mov    $0x60,%r8d
  73f81d:	movss  %xmm5,0x40(%rsp)
  73f823:	movss  %xmm6,0x10(%rsp)
  73f829:	movss  %xmm7,0x20(%rsp)
  73f82f:	movss  %xmm8,0xc(%rsp)
  73f836:	call   *0x3796fc(%rip)        # ab8f38 <_DYNAMIC+0x2d8>
  73f83c:	mov    0x78(%rsp),%rdi
  73f841:	lea    0xf0(%rsp),%rsi
  73f849:	lea    0x80(%rsp),%rdx
  73f851:	lea    0x50(%rsp),%rcx
  73f856:	mov    %r14,%r8
  73f859:	call   *0x3796e1(%rip)        # ab8f40 <_DYNAMIC+0x2e0>
  73f85f:	movss  0xc(%rsp),%xmm8
  73f866:	movss  0x20(%rsp),%xmm7
  73f86c:	movss  0x10(%rsp),%xmm6
  73f872:	movss  0x40(%rsp),%xmm5
  73f878:	mov    %r15,%rsi
  73f87b:	mov    %r14,%rdi
  73f87e:	mov    %eax,%ecx
  73f880:	mov    $0x1,%al
  73f882:	mov    %ecx,0x0(%r13)
  73f886:	mov    %edx,0x4(%r13)
  73f88a:	mov    %r12,%rdx
  73f88d:	mov    0xc8(%rsp),%r10
  73f895:	mov    0xd0(%rsp),%rcx
  73f89d:	mov    $0x1,%r12b
  73f8a0:	mov    %rdx,0x38(%rsp)
  73f8a5:	movss  %xmm8,0xc(%rsp)
  73f8ac:	movaps %xmm6,%xmm3
  73f8af:	movaps %xmm7,0x20(%rsp)
  73f8b4:	movaps %xmm5,0x10(%rsp)
  73f8b9:	cmp    %r10,%rcx
  73f8bc:	lea    0x80(%rsp),%r11
  73f8c4:	jbe    73f513 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0xe3>
  73f8ca:	jmp    73f9d1 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x5a1>
  73f8cf:	mov    $0x1,%al
  73f8d1:	mov    %r15,%rsi
  73f8d4:	movaps 0x10(%rsp),%xmm4
  73f8d9:	cmpl   $0xffffffff,0x0(%r13)
  73f8de:	jne    73f88d <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x45d>
  73f8e0:	jmp    73f7a8 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x378>
  73f8e5:	xor    %eax,%eax
  73f8e7:	add    $0x118,%rsp
  73f8ee:	pop    %rbx
  73f8ef:	pop    %r12
  73f8f1:	pop    %r13
  73f8f3:	pop    %r14
  73f8f5:	pop    %r15
  73f8f7:	pop    %rbp
  73f8f8:	ret
  73f8f9:	test   $0x1,%r12b
  73f8fd:	je     73f8e7 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x4b7>
  73f8ff:	cmpl   $0xffffffff,0x0(%r13)
  73f904:	jne    73f8e7 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x4b7>
  73f906:	movaps 0x10(%rsp),%xmm0
  73f90b:	addss  0x0(%rbp),%xmm0
  73f910:	mov    0x68(%rsp),%rax
  73f915:	movaps 0x20(%rsp),%xmm1
  73f91a:	addss  (%rax),%xmm1
  73f91e:	movss  %xmm0,0x50(%rsp)
  73f924:	movss  %xmm1,0x54(%rsp)
  73f92a:	movss  %xmm3,0x58(%rsp)
  73f930:	movss  0xc(%rsp),%xmm0
  73f936:	movss  %xmm0,0x5c(%rsp)
  73f93c:	mov    0x10(%rbx),%rax
  73f940:	mov    %rax,0x90(%rsp)
  73f948:	movups (%rbx),%xmm0
  73f94b:	movaps %xmm0,0x80(%rsp)
  73f953:	mov    0x70(%rsp),%rax
  73f958:	movups (%rax),%xmm0
  73f95b:	movaps %xmm0,0x100(%rsp)
  73f963:	lea    0xc0(%rsp),%r14
  73f96b:	mov    %r14,%rdi
  73f96e:	mov    $0x46,%esi
  73f973:	mov    $0x82,%edx
  73f978:	mov    $0xf0,%ecx
  73f97d:	mov    $0x60,%r8d
  73f983:	call   *0x3795af(%rip)        # ab8f38 <_DYNAMIC+0x2d8>
  73f989:	lea    0x50(%rsp),%rsi
  73f98e:	lea    0x80(%rsp),%rdx
  73f996:	lea    0x100(%rsp),%rcx
  73f99e:	mov    0x78(%rsp),%rdi
  73f9a3:	mov    %r14,%r8
  73f9a6:	call   *0x379594(%rip)        # ab8f40 <_DYNAMIC+0x2e0>
  73f9ac:	mov    %eax,%ecx
  73f9ae:	mov    $0x1,%al
  73f9b0:	mov    %ecx,0x0(%r13)
  73f9b4:	mov    %edx,0x4(%r13)
  73f9b8:	jmp    73f8e7 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x4b7>
  73f9bd:	movaps 0x20(%rsp),%xmm7
  73f9c2:	movss  0xc(%rsp),%xmm8
  73f9c9:	movaps 0x10(%rsp),%xmm5
  73f9ce:	movaps %xmm3,%xmm6
  73f9d1:	movaps %xmm6,%xmm3
  73f9d4:	movaps %xmm5,0x10(%rsp)
  73f9d9:	movss  %xmm8,0xc(%rsp)
  73f9e0:	movaps %xmm7,0x20(%rsp)
  73f9e5:	cmpl   $0xffffffff,0x0(%r13)
  73f9ea:	jne    73f8e7 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x4b7>
  73f9f0:	jmp    73f906 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x4d6>
  73f9f5:	lea    0x358d8c(%rip),%rdi        # a98788 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x50>
  73f9fc:	call   *0x379546(%rip)        # ab8f48 <_DYNAMIC+0x2e8>
  73fa02:	lea    0x359507(%rip),%rdx        # a98f10 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x7d8>
  73fa09:	mov    $0x1,%edi
  73fa0e:	mov    $0x1,%esi
  73fa13:	call   *0x3794b7(%rip)        # ab8ed0 <_DYNAMIC+0x270>

<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::present_inner::{closure#44}> bytes=1391 frame=120

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000073fa80 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_>:
  73fa80:	push   %rbp
  73fa81:	push   %r15
  73fa83:	push   %r14
  73fa85:	push   %r13
  73fa87:	push   %r12
  73fa89:	push   %rbx
  73fa8a:	sub    $0x48,%rsp
  73fa8e:	mov    %rdx,0x10(%rsp)
  73fa93:	mov    %rdi,0x18(%rsp)
  73fa98:	mov    0x10(%rsi),%rbx
  73fa9c:	test   %rbx,%rbx
  73fa9f:	mov    %rsi,0x8(%rsp)
  73faa4:	je     73fae9 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x69>
  73faa6:	mov    0x8(%rsi),%rbp
  73faaa:	lea    -0x1(%rbx),%r15
  73faae:	mov    $0x28,%r13d
  73fab4:	xor    %r14d,%r14d
  73fab7:	nopw   0x0(%rax,%rax,1)
  73fac0:	mov    -0x28(%rbp,%r13,1),%rsi
  73fac5:	mov    0x10(%rsp),%rdi
  73faca:	call   75dea0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_>
  73facf:	test   $0x1,%al
  73fad1:	je     73faee <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x6e>
  73fad3:	mov    %edx,-0x4(%rbp,%r13,1)
  73fad8:	inc    %r14
  73fadb:	add    $0x28,%r13
  73fadf:	cmp    %r14,%rbx
  73fae2:	jne    73fac0 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x40>
  73fae4:	mov    %rbx,%r14
  73fae7:	jmp    73fb51 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0xd1>
  73fae9:	xor    %r14d,%r14d
  73faec:	jmp    73fb51 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0xd1>
  73faee:	lea    0x1(%r14),%rax
  73faf2:	cmp    %rbx,%rax
  73faf5:	jae    73fb51 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0xd1>
  73faf7:	sub    %r14,%r15
  73fafa:	jmp    73fb09 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x89>
  73fafc:	nopl   0x0(%rax)
  73fb00:	add    $0x28,%r13
  73fb04:	dec    %r15
  73fb07:	je     73fb51 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0xd1>
  73fb09:	mov    %rbp,%r12
  73fb0c:	add    %r13,%r12
  73fb0f:	mov    0x0(%rbp,%r13,1),%rsi
  73fb14:	mov    0x10(%rsp),%rdi
  73fb19:	call   75dea0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_>
  73fb1e:	cmp    $0x1,%rax
  73fb22:	jne    73fb00 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x80>
  73fb24:	mov    %edx,0x24(%rbp,%r13,1)
  73fb29:	lea    (%r14,%r14,4),%rax
  73fb2d:	mov    0x20(%r12),%rcx
  73fb32:	mov    %rcx,0x20(%rbp,%rax,8)
  73fb37:	movups (%r12),%xmm0
  73fb3c:	movups 0x10(%r12),%xmm1
  73fb42:	movups %xmm1,0x10(%rbp,%rax,8)
  73fb47:	movups %xmm0,0x0(%rbp,%rax,8)
  73fb4c:	inc    %r14
  73fb4f:	jmp    73fb00 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x80>
  73fb51:	mov    0x8(%rsp),%rax
  73fb56:	mov    0x28(%rax),%rbp
  73fb5a:	test   %rbp,%rbp
  73fb5d:	mov    %r14,0x20(%rsp)
  73fb62:	je     73fba9 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x129>
  73fb64:	mov    0x20(%rax),%r13
  73fb68:	lea    -0x1(%rbp),%r15
  73fb6c:	mov    $0x40,%ebx
  73fb71:	xor    %r12d,%r12d
  73fb74:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  73fb80:	mov    -0x10(%r13,%rbx,1),%rsi
  73fb85:	mov    0x10(%rsp),%rdi
  73fb8a:	call   75dea0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_>
  73fb8f:	test   $0x1,%al
  73fb91:	je     73fbae <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x12e>
  73fb93:	mov    %edx,-0x8(%r13,%rbx,1)
  73fb98:	inc    %r12
  73fb9b:	add    $0x40,%rbx
  73fb9f:	cmp    %r12,%rbp
  73fba2:	jne    73fb80 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x100>
  73fba4:	mov    %rbp,%r12
  73fba7:	jmp    73fc21 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x1a1>
  73fba9:	xor    %r12d,%r12d
  73fbac:	jmp    73fc21 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x1a1>
  73fbae:	lea    0x1(%r12),%rax
  73fbb3:	cmp    %rbp,%rax
  73fbb6:	jae    73fc21 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x1a1>
  73fbb8:	sub    %r12,%r15
  73fbbb:	jmp    73fbcc <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x14c>
  73fbbd:	nopl   (%rax)
  73fbc0:	mov    %r14,%rbp
  73fbc3:	add    $0x40,%rbx
  73fbc7:	dec    %r15
  73fbca:	je     73fc21 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x1a1>
  73fbcc:	mov    %rbp,%r14
  73fbcf:	lea    (%rbx,%r13,1),%rbp
  73fbd3:	mov    0x30(%r13,%rbx,1),%rsi
  73fbd8:	mov    0x10(%rsp),%rdi
  73fbdd:	call   75dea0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_>
  73fbe2:	cmp    $0x1,%rax
  73fbe6:	jne    73fbc0 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x140>
  73fbe8:	mov    %edx,0x38(%r13,%rbx,1)
  73fbed:	mov    %r12,%rax
  73fbf0:	shl    $0x6,%rax
  73fbf4:	movups 0x0(%rbp),%xmm0
  73fbf8:	movups 0x10(%rbp),%xmm1
  73fbfc:	movups 0x20(%rbp),%xmm2
  73fc00:	movups 0x30(%rbp),%xmm3
  73fc04:	movups %xmm3,0x30(%r13,%rax,1)
  73fc0a:	movups %xmm2,0x20(%r13,%rax,1)
  73fc10:	movups %xmm1,0x10(%r13,%rax,1)
  73fc16:	movups %xmm0,0x0(%r13,%rax,1)
  73fc1c:	inc    %r12
  73fc1f:	jmp    73fbc0 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x140>
  73fc21:	mov    0x20(%rsp),%r14
  73fc26:	test   %r14,%r14
  73fc29:	je     73fc90 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x210>
  73fc2b:	test   %r12,%r12
  73fc2e:	je     73fcea <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x26a>
  73fc34:	mov    0x8(%rsp),%rcx
  73fc39:	mov    (%rcx),%rax
  73fc3c:	mov    0x8(%rcx),%rbx
  73fc40:	cmp    %r14,%rax
  73fc43:	jbe    73fd43 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x2c3>
  73fc49:	shl    $0x3,%rax
  73fc4d:	lea    (%rax,%rax,4),%r13
  73fc51:	lea    0x0(,%r14,8),%rax
  73fc59:	lea    (%rax,%rax,4),%rbp
  73fc5d:	mov    $0x8,%edx
  73fc62:	mov    %rbx,%rdi
  73fc65:	mov    %r13,%rsi
  73fc68:	mov    %rbp,%rcx
  73fc6b:	call   *0x3792df(%rip)        # ab8f50 <_DYNAMIC+0x2f0>
  73fc71:	mov    %rax,%r15
  73fc74:	test   %rax,%rax
  73fc77:	jne    73fd46 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x2c6>
  73fc7d:	mov    $0x8,%edi
  73fc82:	mov    %rbp,%rsi
  73fc85:	call   *0x3792cd(%rip)        # ab8f58 <_DYNAMIC+0x2f8>
  73fc8b:	jmp    73feae <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x42e>
  73fc90:	test   %r12,%r12
  73fc93:	je     73fdeb <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x36b>
  73fc99:	mov    0x8(%rsp),%r14
  73fc9e:	mov    0x18(%r14),%r15
  73fca2:	mov    0x20(%r14),%rbx
  73fca6:	cmp    %r12,%r15
  73fca9:	jbe    73fe04 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x384>
  73fcaf:	shl    $0x6,%r15
  73fcb3:	mov    %r12,%r13
  73fcb6:	shl    $0x6,%r13
  73fcba:	mov    $0x8,%edx
  73fcbf:	mov    %rbx,%rdi
  73fcc2:	mov    %r15,%rsi
  73fcc5:	mov    %r13,%rcx
  73fcc8:	call   *0x379282(%rip)        # ab8f50 <_DYNAMIC+0x2f0>
  73fcce:	test   %rax,%rax
  73fcd1:	jne    73fe07 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x387>
  73fcd7:	mov    $0x8,%edi
  73fcdc:	mov    %r13,%rsi
  73fcdf:	call   *0x379273(%rip)        # ab8f58 <_DYNAMIC+0x2f8>
  73fce5:	jmp    73feae <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x42e>
  73fcea:	mov    0x8(%rsp),%rcx
  73fcef:	mov    (%rcx),%rax
  73fcf2:	mov    0x8(%rcx),%r15
  73fcf6:	cmp    %r14,%rax
  73fcf9:	jbe    73fe6a <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x3ea>
  73fcff:	shl    $0x3,%rax
  73fd03:	lea    (%rax,%rax,4),%r12
  73fd07:	lea    0x0(,%r14,8),%rax
  73fd0f:	lea    (%rax,%rax,4),%r13
  73fd13:	mov    $0x8,%edx
  73fd18:	mov    %r15,%rdi
  73fd1b:	mov    %r12,%rsi
  73fd1e:	mov    %r13,%rcx
  73fd21:	call   *0x379229(%rip)        # ab8f50 <_DYNAMIC+0x2f0>
  73fd27:	test   %rax,%rax
  73fd2a:	jne    73fe6d <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x3ed>
  73fd30:	mov    $0x8,%edi
  73fd35:	mov    %r13,%rsi
  73fd38:	call   *0x37921a(%rip)        # ab8f58 <_DYNAMIC+0x2f8>
  73fd3e:	jmp    73feae <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x42e>
  73fd43:	mov    %rbx,%r15
  73fd46:	mov    0x8(%rsp),%rax
  73fd4b:	mov    0x18(%rax),%rbp
  73fd4f:	mov    0x20(%rax),%rbx
  73fd53:	cmp    %r12,%rbp
  73fd56:	jbe    73fd8f <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x30f>
  73fd58:	shl    $0x6,%rbp
  73fd5c:	mov    %r12,%r13
  73fd5f:	shl    $0x6,%r13
  73fd63:	mov    $0x8,%edx
  73fd68:	mov    %rbx,%rdi
  73fd6b:	mov    %rbp,%rsi
  73fd6e:	mov    %r13,%rcx
  73fd71:	call   *0x3791d9(%rip)        # ab8f50 <_DYNAMIC+0x2f0>
  73fd77:	test   %rax,%rax
  73fd7a:	jne    73fd92 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x312>
  73fd7c:	mov    $0x8,%edi
  73fd81:	mov    %r13,%rsi
  73fd84:	call   *0x3791ce(%rip)        # ab8f58 <_DYNAMIC+0x2f8>
  73fd8a:	jmp    73feae <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x42e>
  73fd8f:	mov    %rbx,%rax
  73fd92:	mov    %r15,0x28(%rsp)
  73fd97:	mov    %r14,0x30(%rsp)
  73fd9c:	mov    %rax,0x38(%rsp)
  73fda1:	mov    %r12,0x40(%rsp)
  73fda6:	call   *0x3790fc(%rip)        # ab8ea8 <_DYNAMIC+0x248>
  73fdac:	mov    $0x20,%edi
  73fdb1:	mov    $0x8,%esi
  73fdb6:	call   *0x3790f4(%rip)        # ab8eb0 <_DYNAMIC+0x250>
  73fdbc:	test   %rax,%rax
  73fdbf:	je     73fe9e <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x41e>
  73fdc5:	movups 0x28(%rsp),%xmm0
  73fdca:	movups 0x38(%rsp),%xmm1
  73fdcf:	movups %xmm1,0x10(%rax)
  73fdd3:	movups %xmm0,(%rax)
  73fdd6:	mov    0x18(%rsp),%rcx
  73fddb:	mov    %rax,0x8(%rcx)
  73fddf:	movq   $0x3,(%rcx)
  73fde6:	jmp    73fe8f <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x40f>
  73fdeb:	xor    %eax,%eax
  73fded:	mov    0x8(%rsp),%r14
  73fdf2:	mov    0x18(%rsp),%rcx
  73fdf7:	mov    %rax,(%rcx)
  73fdfa:	mov    (%r14),%rax
  73fdfd:	test   %rax,%rax
  73fe00:	jne    73fe24 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x3a4>
  73fe02:	jmp    73fe3b <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x3bb>
  73fe04:	mov    %rbx,%rax
  73fe07:	mov    0x18(%rsp),%rcx
  73fe0c:	mov    %rax,0x8(%rcx)
  73fe10:	mov    %r12,0x10(%rcx)
  73fe14:	mov    $0x2,%eax
  73fe19:	mov    %rax,(%rcx)
  73fe1c:	mov    (%r14),%rax
  73fe1f:	test   %rax,%rax
  73fe22:	je     73fe3b <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x3bb>
  73fe24:	mov    0x8(%r14),%rdi
  73fe28:	shl    $0x3,%rax
  73fe2c:	lea    (%rax,%rax,4),%rsi
  73fe30:	mov    $0x8,%edx
  73fe35:	call   *0x379065(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  73fe3b:	test   %r12,%r12
  73fe3e:	jne    73fe8f <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x40f>
  73fe40:	mov    0x18(%r14),%rsi
  73fe44:	test   %rsi,%rsi
  73fe47:	je     73fe8f <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x40f>
  73fe49:	mov    0x20(%r14),%rdi
  73fe4d:	shl    $0x6,%rsi
  73fe51:	mov    $0x8,%edx
  73fe56:	add    $0x48,%rsp
  73fe5a:	pop    %rbx
  73fe5b:	pop    %r12
  73fe5d:	pop    %r13
  73fe5f:	pop    %r14
  73fe61:	pop    %r15
  73fe63:	pop    %rbp
  73fe64:	jmp    *0x379036(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  73fe6a:	mov    %r15,%rax
  73fe6d:	mov    0x18(%rsp),%rcx
  73fe72:	mov    %rax,0x8(%rcx)
  73fe76:	mov    %r14,0x10(%rcx)
  73fe7a:	movq   $0x1,(%rcx)
  73fe81:	mov    0x8(%rsp),%r14
  73fe86:	mov    0x18(%r14),%rsi
  73fe8a:	test   %rsi,%rsi
  73fe8d:	jne    73fe49 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x3c9>
  73fe8f:	add    $0x48,%rsp
  73fe93:	pop    %rbx
  73fe94:	pop    %r12
  73fe96:	pop    %r13
  73fe98:	pop    %r14
  73fe9a:	pop    %r15
  73fe9c:	pop    %rbp
  73fe9d:	ret
  73fe9e:	mov    $0x8,%edi
  73fea3:	mov    $0x20,%esi
  73fea8:	call   *0x37900a(%rip)        # ab8eb8 <_DYNAMIC+0x258>
  73feae:	ud2
  73feb0:	mov    %rax,%r14
  73feb3:	mov    $0x8,%edx
  73feb8:	mov    %r15,%rdi
  73febb:	mov    %r12,%rsi
  73febe:	jmp    73ff1e <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x49e>
  73fec0:	mov    %rax,0x10(%rsp)
  73fec5:	mov    $0x8,%edx
  73feca:	mov    %rbx,%rdi
  73fecd:	mov    %r15,%rsi
  73fed0:	call   *0x378fca(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  73fed6:	xor    %ebx,%ebx
  73fed8:	jmp    73ff7a <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x4fa>
  73fedd:	mov    %rax,%r13
  73fee0:	mov    0x378fb9(%rip),%r12        # ab8ea0 <_DYNAMIC+0x240>
  73fee7:	mov    $0x8,%edx
  73feec:	mov    %rbx,%rdi
  73feef:	mov    %rbp,%rsi
  73fef2:	call   *%r12
  73fef5:	shl    $0x3,%r14
  73fef9:	lea    (%r14,%r14,4),%rsi
  73fefd:	mov    $0x8,%edx
  73ff02:	mov    %r15,%rdi
  73ff05:	call   *%r12
  73ff08:	mov    %r13,%rdi
  73ff0b:	call   a97380 <_Unwind_Resume@plt>
  73ff10:	mov    %rax,%r14
  73ff13:	mov    $0x8,%edx
  73ff18:	mov    %rbx,%rdi
  73ff1b:	mov    %r13,%rsi
  73ff1e:	call   *0x378f7c(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  73ff24:	jmp    73ffac <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x52c>
  73ff29:	mov    %rax,0x10(%rsp)
  73ff2e:	shl    $0x6,%r12
  73ff32:	add    %r12,%r13
  73ff35:	shl    $0x6,%r14
  73ff39:	sub    %rbx,%r14
  73ff3c:	mov    %r13,%rdi
  73ff3f:	mov    %rbp,%rsi
  73ff42:	mov    %r14,%rdx
  73ff45:	jmp    73ff69 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x4e9>
  73ff47:	mov    %rax,0x10(%rsp)
  73ff4c:	lea    (%r14,%r14,4),%rax
  73ff50:	lea    0x0(,%rax,8),%rdi
  73ff58:	add    %rbp,%rdi
  73ff5b:	shl    $0x3,%rbx
  73ff5f:	lea    (%rbx,%rbx,4),%rdx
  73ff63:	sub    %r13,%rdx
  73ff66:	mov    %r12,%rsi
  73ff69:	call   *0x378fa1(%rip)        # ab8f10 <memmove@GLIBC_2.2.5>
  73ff6f:	jmp    73ff78 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x4f8>
  73ff71:	jmp    73ff73 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x4f3>
  73ff73:	mov    %rax,0x10(%rsp)
  73ff78:	mov    $0x1,%bl
  73ff7a:	mov    0x8(%rsp),%rax
  73ff7f:	mov    (%rax),%rax
  73ff82:	test   %rax,%rax
  73ff85:	je     73ffa3 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x523>
  73ff87:	mov    0x8(%rsp),%rcx
  73ff8c:	mov    0x8(%rcx),%rdi
  73ff90:	shl    $0x3,%rax
  73ff94:	lea    (%rax,%rax,4),%rsi
  73ff98:	mov    $0x8,%edx
  73ff9d:	call   *0x378efd(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  73ffa3:	test   %bl,%bl
  73ffa5:	mov    0x10(%rsp),%r14
  73ffaa:	je     73ffe7 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x567>
  73ffac:	mov    0x8(%rsp),%rax
  73ffb1:	mov    0x18(%rax),%rsi
  73ffb5:	test   %rsi,%rsi
  73ffb8:	je     73ffe7 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x567>
  73ffba:	mov    0x8(%rsp),%rax
  73ffbf:	mov    0x20(%rax),%rdi
  73ffc3:	shl    $0x6,%rsi
  73ffc7:	mov    $0x8,%edx
  73ffcc:	call   *0x378ece(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  73ffd2:	mov    %r14,%rdi
  73ffd5:	call   a97380 <_Unwind_Resume@plt>
  73ffda:	mov    %rax,%r14
  73ffdd:	lea    0x28(%rsp),%rdi
  73ffe2:	call   74e690 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime6scroll7ColumnsECs9C2G9YFESsD_29canonical_text_public_control>
  73ffe7:	mov    %r14,%rdi
  73ffea:	call   a97380 <_Unwind_Resume@plt>

core::panicking::assert_failed::<gpui_canvas::text::layout::TextPosition, gpui_canvas::text::layout::TextPosition> bytes=50 frame=40

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000074f2c3 <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextPositionBM_ECs9C2G9YFESsD_29canonical_text_public_control>:
  74f2c3:	sub    $0x28,%rsp
  74f2c7:	lea    0x18(%rsp),%rax
  74f2cc:	mov    %rdi,(%rax)
  74f2cf:	lea    0x20(%rsp),%rcx
  74f2d4:	mov    %rsi,(%rcx)
  74f2d7:	mov    %rdx,0x8(%rsp)
  74f2dc:	lea    0x349735(%rip),%rdx        # a98a18 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2e0>
  74f2e3:	push   $0x1
  74f2e5:	pop    %rdi
  74f2e6:	mov    %rax,%rsi
  74f2e9:	mov    %rdx,%r8
  74f2ec:	xor    %r9d,%r9d
  74f2ef:	call   *0x369d33(%rip)        # ab9028 <_DYNAMIC+0x3c8>

core::panicking::assert_failed::<gpui_canvas::text::layout::TextSelection, gpui_canvas::text::layout::TextSelection> bytes=56 frame=40

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000074f2f5 <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout13TextSelectionBM_ECs9C2G9YFESsD_29canonical_text_public_control>:
  74f2f5:	sub    $0x28,%rsp
  74f2f9:	lea    0x18(%rsp),%rax
  74f2fe:	mov    %rdi,(%rax)
  74f301:	lea    0x20(%rsp),%rcx
  74f306:	mov    %rsi,(%rcx)
  74f309:	lea    0x34a1c0(%rip),%rdx        # a994d0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xd98>
  74f310:	mov    %rdx,0x8(%rsp)
  74f315:	lea    0x34971c(%rip),%rdx        # a98a38 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x300>
  74f31c:	xor    %edi,%edi
  74f31e:	mov    %rax,%rsi
  74f321:	mov    %rdx,%r8
  74f324:	xor    %r9d,%r9d
  74f327:	call   *0x369cfb(%rip)        # ab9028 <_DYNAMIC+0x3c8>

core::panicking::assert_failed::<(alloc::string::String, gpui_canvas::text::layout::TextSelection, *const gpui_canvas::text::layout::TextGeometry, u64), (alloc::string::String, gpui_canvas::text::layout::TextSelection, *const gpui_canvas::text::layout::TextGeometry, u64)> bytes=56 frame=40

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000074f3a6 <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedTNtNtCscdodAO9FK5_5alloc6string6StringNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout13TextSelectionPNtB1q_12TextGeometryyEBM_ECs9C2G9YFESsD_29canonical_text_public_control>:
  74f3a6:	sub    $0x28,%rsp
  74f3aa:	lea    0x18(%rsp),%rax
  74f3af:	mov    %rdi,(%rax)
  74f3b2:	lea    0x20(%rsp),%rcx
  74f3b7:	mov    %rsi,(%rcx)
  74f3ba:	lea    0x34a0c7(%rip),%rdx        # a99488 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xd50>
  74f3c1:	mov    %rdx,0x8(%rsp)
  74f3c6:	lea    0x3496cb(%rip),%rdx        # a98a98 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x360>
  74f3cd:	xor    %edi,%edi
  74f3cf:	mov    %rax,%rsi
  74f3d2:	mov    %rdx,%r8
  74f3d5:	xor    %r9d,%r9d
  74f3d8:	call   *0x369c4a(%rip)        # ab9028 <_DYNAMIC+0x3c8>

core::panicking::assert_failed::<(*const gpui_canvas::text::layout::TextGeometry, u64), (*const gpui_canvas::text::layout::TextGeometry, u64)> bytes=56 frame=40

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000074f3de <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedTPNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryyEBM_ECs9C2G9YFESsD_29canonical_text_public_control>:
  74f3de:	sub    $0x28,%rsp
  74f3e2:	lea    0x18(%rsp),%rax
  74f3e7:	mov    %rdi,(%rax)
  74f3ea:	lea    0x20(%rsp),%rcx
  74f3ef:	mov    %rsi,(%rcx)
  74f3f2:	lea    0x34a0ef(%rip),%rdx        # a994e8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xdb0>
  74f3f9:	mov    %rdx,0x8(%rsp)
  74f3fe:	lea    0x3496b3(%rip),%rdx        # a98ab8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x380>
  74f405:	xor    %edi,%edi
  74f407:	mov    %rax,%rsi
  74f40a:	mov    %rdx,%r8
  74f40d:	xor    %r9d,%r9d
  74f410:	call   *0x369c12(%rip)        # ab9028 <_DYNAMIC+0x3c8>

canonical_text_public_control::old_p_oracle::{closure#0} bytes=800 frame=296

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075c8b0 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_>:
  75c8b0:	push   %rbp
  75c8b1:	push   %r15
  75c8b3:	push   %r14
  75c8b5:	push   %r13
  75c8b7:	push   %r12
  75c8b9:	push   %rbx
  75c8ba:	sub    $0xf8,%rsp
  75c8c1:	test   %rsi,%rsi
  75c8c4:	je     75cb28 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x278>
  75c8ca:	cmpb   $0x0,0x76e(%rsi)
  75c8d1:	jne    75cb2f <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x27f>
  75c8d7:	cmpb   $0x1,0x76c(%rsi)
  75c8de:	jne    75cb36 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x286>
  75c8e4:	mov    %rdi,%r14
  75c8e7:	mov    $0xffffffffffffffff,%rbx
  75c8ee:	lea    0x78(%rsp),%rdi
  75c8f3:	call   73dc40 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime5queryNtB3_7Context3newNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEBX_>
  75c8f8:	mov    %r14,0x38(%rsp)
  75c8fd:	mov    0xb0(%rsp),%rax
  75c905:	mov    %rax,0x48(%rsp)
  75c90a:	test   %rax,%rax
  75c90d:	je     75cb1b <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x26b>
  75c913:	movq   $0xffffffffffffffff,0x8(%rsp)
  75c91c:	mov    $0x3d,%ebx
  75c921:	xor    %ebp,%ebp
  75c923:	jmp    75c948 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x98>
  75c925:	data16 cs nopw 0x0(%rax,%rax,1)
  75c930:	mov    %r14,%r13
  75c933:	inc    %rbp
  75c936:	add    $0x40,%rbx
  75c93a:	mov    %r13,%r14
  75c93d:	cmp    %rbp,0x48(%rsp)
  75c942:	je     75ca66 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x1b6>
  75c948:	mov    0xb0(%rsp),%rsi
  75c950:	cmp    %rsi,%rbp
  75c953:	jae    75cadb <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x22b>
  75c959:	mov    0xa8(%rsp),%rax
  75c961:	cmpb   $0x4,(%rax,%rbx,1)
  75c965:	jne    75c930 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x80>
  75c967:	mov    -0x15(%rax,%rbx,1),%r15
  75c96c:	test   %r15,%r15
  75c96f:	je     75caf2 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x242>
  75c975:	mov    (%r15),%r12
  75c978:	shr    $1,%r12
  75c97b:	je     75c9b2 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x102>
  75c97d:	call   *0x35c525(%rip)        # ab8ea8 <_DYNAMIC+0x248>
  75c983:	mov    $0x1,%esi
  75c988:	mov    %r12,%rdi
  75c98b:	call   *0x35c51f(%rip)        # ab8eb0 <_DYNAMIC+0x250>
  75c991:	test   %rax,%rax
  75c994:	je     75cb06 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x256>
  75c99a:	mov    %rax,%r13
  75c99d:	add    $0x10,%r15
  75c9a1:	mov    %rax,%rdi
  75c9a4:	mov    %r15,%rsi
  75c9a7:	mov    %r12,%rdx
  75c9aa:	call   *0x35c510(%rip)        # ab8ec0 <memcpy@GLIBC_2.14>
  75c9b0:	jmp    75c9b8 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x108>
  75c9b2:	mov    $0x1,%r13d
  75c9b8:	lea    0x18(%rsp),%rdi
  75c9bd:	lea    0x78(%rsp),%rsi
  75c9c2:	mov    %rbp,%rdx
  75c9c5:	call   *0x35c6d5(%rip)        # ab90a0 <_DYNAMIC+0x440>
  75c9cb:	cmpb   $0x2,0x24(%rsp)
  75c9d0:	je     75cab2 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x202>
  75c9d6:	movups 0x18(%rsp),%xmm0
  75c9db:	movaps %xmm0,0x60(%rsp)
  75c9e0:	lea    0x18(%rsp),%rdi
  75c9e5:	lea    0x78(%rsp),%rsi
  75c9ea:	mov    %rbp,%rdx
  75c9ed:	call   *0x35c6b5(%rip)        # ab90a8 <_DYNAMIC+0x448>
  75c9f3:	cmpq   $0x0,0x18(%rsp)
  75c9f9:	je     75cabb <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x20b>
  75c9ff:	mov    0x28(%rsp),%rax
  75ca04:	mov    %rax,0x40(%rsp)
  75ca09:	lea    0x18(%rsp),%rdi
  75ca0e:	lea    0x78(%rsp),%rsi
  75ca13:	mov    %rbp,%rdx
  75ca16:	call   *0x35c68c(%rip)        # ab90a8 <_DYNAMIC+0x448>
  75ca1c:	cmpq   $0x0,0x18(%rsp)
  75ca22:	je     75cac4 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x214>
  75ca28:	mov    0x28(%rsp),%rdi
  75ca2d:	call   75ff60 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript>
  75ca32:	mov    %rax,%r15
  75ca35:	movaps 0x60(%rsp),%xmm0
  75ca3a:	movaps %xmm0,0x50(%rsp)
  75ca3f:	mov    0x8(%rsp),%rsi
  75ca44:	test   %rsi,%rsi
  75ca47:	jle    75ca57 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x1a7>
  75ca49:	mov    $0x1,%edx
  75ca4e:	mov    %r14,%rdi
  75ca51:	call   *0x35c449(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  75ca57:	mov    %r13,0x10(%rsp)
  75ca5c:	mov    %r12,0x8(%rsp)
  75ca61:	jmp    75c933 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x83>
  75ca66:	mov    0x8(%rsp),%rax
  75ca6b:	cmp    $0xffffffffffffffff,%rax
  75ca6f:	je     75cb1b <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x26b>
  75ca75:	mov    0x38(%rsp),%rcx
  75ca7a:	mov    %rax,(%rcx)
  75ca7d:	mov    0x10(%rsp),%rax
  75ca82:	mov    %rax,0x8(%rcx)
  75ca86:	mov    %r12,0x10(%rcx)
  75ca8a:	movaps 0x50(%rsp),%xmm0
  75ca8f:	movups %xmm0,0x18(%rcx)
  75ca93:	mov    0x40(%rsp),%rax
  75ca98:	mov    %rax,0x28(%rcx)
  75ca9c:	mov    %r15,0x30(%rcx)
  75caa0:	add    $0xf8,%rsp
  75caa7:	pop    %rbx
  75caa8:	pop    %r12
  75caaa:	pop    %r13
  75caac:	pop    %r14
  75caae:	pop    %r15
  75cab0:	pop    %rbp
  75cab1:	ret
  75cab2:	lea    0x33c1e7(%rip),%rdi        # a98ca0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x568>
  75cab9:	jmp    75cacb <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x21b>
  75cabb:	lea    0x33c1f6(%rip),%rdi        # a98cb8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x580>
  75cac2:	jmp    75cacb <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x21b>
  75cac4:	lea    0x33c205(%rip),%rdi        # a98cd0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x598>
  75cacb:	mov    0x8(%rsp),%rbx
  75cad0:	call   *0x35c472(%rip)        # ab8f48 <_DYNAMIC+0x2e8>
  75cad6:	jmp    75cb71 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x2c1>
  75cadb:	lea    0x33c18e(%rip),%rdx        # a98c70 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x538>
  75cae2:	mov    %rbp,%rdi
  75cae5:	mov    0x8(%rsp),%rbx
  75caea:	call   *0x35c3e0(%rip)        # ab8ed0 <_DYNAMIC+0x270>
  75caf0:	jmp    75cb71 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x2c1>
  75caf2:	lea    0x33c18f(%rip),%rdi        # a98c88 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x550>
  75caf9:	mov    0x8(%rsp),%rbx
  75cafe:	call   *0x35c444(%rip)        # ab8f48 <_DYNAMIC+0x2e8>
  75cb04:	jmp    75cb71 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x2c1>
  75cb06:	mov    $0x1,%edi
  75cb0b:	mov    %r12,%rsi
  75cb0e:	mov    0x8(%rsp),%rbx
  75cb13:	call   *0x35c43f(%rip)        # ab8f58 <_DYNAMIC+0x2f8>
  75cb19:	jmp    75cb71 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x2c1>
  75cb1b:	lea    0x33c20e(%rip),%rdi        # a98d30 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x5f8>
  75cb22:	call   *0x35c420(%rip)        # ab8f48 <_DYNAMIC+0x2e8>
  75cb28:	mov    $0xd,%eax
  75cb2d:	jmp    75cb3b <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x28b>
  75cb2f:	mov    $0xe,%eax
  75cb34:	jmp    75cb3b <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x28b>
  75cb36:	mov    $0x12,%eax
  75cb3b:	mov    %rax,0x78(%rsp)
  75cb40:	movq   $0x0,0x80(%rsp)
  75cb4c:	lea    -0x68cf71(%rip),%rdi        # cfbe2 <GCC_except_table0+0xd87a>
  75cb53:	lea    0x33ce3e(%rip),%rcx        # a99998 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1260>
  75cb5a:	lea    0x33c1b7(%rip),%r8        # a98d18 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x5e0>
  75cb61:	lea    0x78(%rsp),%rdx
  75cb66:	mov    $0x2b,%esi
  75cb6b:	call   *0x35c3ff(%rip)        # ab8f70 <_DYNAMIC+0x310>
  75cb71:	ud2
  75cb73:	mov    %rax,%r14
  75cb76:	lea    0x78(%rsp),%rdi
  75cb7b:	call   74d540 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  75cb80:	mov    %r14,%rdi
  75cb83:	call   a97380 <_Unwind_Resume@plt>
  75cb88:	mov    %rax,%r14
  75cb8b:	jmp    75cbb0 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x300>
  75cb8d:	mov    %rax,%r14
  75cb90:	mov    0x8(%rsp),%rbx
  75cb95:	jmp    75cb9a <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x2ea>
  75cb97:	mov    %rax,%r14
  75cb9a:	test   %r12,%r12
  75cb9d:	je     75cbb0 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x300>
  75cb9f:	mov    $0x1,%edx
  75cba4:	mov    %r13,%rdi
  75cba7:	mov    %r12,%rsi
  75cbaa:	call   *0x35c2f0(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  75cbb0:	mov    0x10(%rsp),%rdi
  75cbb5:	test   %rbx,%rbx
  75cbb8:	jle    75cbc8 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x318>
  75cbba:	mov    $0x1,%edx
  75cbbf:	mov    %rbx,%rsi
  75cbc2:	call   *0x35c2d8(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  75cbc8:	mov    %r14,%rdi
  75cbcb:	call   a97380 <_Unwind_Resume@plt>

<gpui_canvas::text::layout::TextGeometry>::intervals::{closure#3} bytes=649 frame=56

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075d2b0 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control>:
  75d2b0:	push   %rbp
  75d2b1:	push   %r15
  75d2b3:	push   %r14
  75d2b5:	push   %r13
  75d2b7:	push   %r12
  75d2b9:	push   %rbx
  75d2ba:	push   %rax
  75d2bb:	cmp    $0x2,%rcx
  75d2bf:	jb     75d4fc <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x24c>
  75d2c5:	mov    (%rsi),%r14
  75d2c8:	mov    0x8(%rsi),%rbx
  75d2cc:	mov    0x20(%r14),%rax
  75d2d0:	mov    0x28(%r14),%rcx
  75d2d4:	lea    0x1(%rbx),%r9
  75d2d8:	cmp    %rcx,%r9
  75d2db:	jae    75d31d <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x6d>
  75d2dd:	mov    (%rdx),%r8d
  75d2e0:	lea    (%r9,%r9,2),%r10
  75d2e4:	cmp    %r8d,(%rax,%r10,8)
  75d2e8:	ja     75d31d <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x6d>
  75d2ea:	lea    (%rbx,%rbx,2),%r10
  75d2ee:	lea    (%rax,%r10,8),%r11
  75d2f2:	add    $0x30,%r11
  75d2f6:	mov    $0x2,%r10d
  75d2fc:	sub    %rcx,%r10
  75d2ff:	nop
  75d300:	mov    %r9,%rbx
  75d303:	add    %r10,%r9
  75d306:	cmp    $0x1,%r9
  75d30a:	je     75d319 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x69>
  75d30c:	lea    0x1(%rbx),%r9
  75d310:	cmp    %r8d,(%r11)
  75d313:	lea    0x18(%r11),%r11
  75d317:	jbe    75d300 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x50>
  75d319:	mov    %rbx,0x8(%rsi)
  75d31d:	cmp    %rcx,%rbx
  75d320:	jae    75d513 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x263>
  75d326:	mov    0xc(%rdx),%ebp
  75d329:	lea    (%rbx,%rbx,2),%r9
  75d32d:	mov    0x4(%rax,%r9,8),%r15d
  75d332:	testb  $0x1,0x8(%rdx)
  75d336:	jne    75d36c <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0xbc>
  75d338:	mov    %rbx,%rax
  75d33b:	cmp    %rcx,%rax
  75d33e:	jae    75d526 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x276>
  75d344:	mov    0x20(%r14),%rcx
  75d348:	movss  0x4(%rdx),%xmm0
  75d34d:	movss  0x10(%rdx),%xmm1
  75d352:	cmp    %r15d,%ebp
  75d355:	ja     75d3ae <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0xfe>
  75d357:	ucomiss %xmm1,%xmm0
  75d35a:	jne    75d35e <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0xae>
  75d35c:	jnp    75d3ae <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0xfe>
  75d35e:	ucomiss %xmm0,%xmm1
  75d361:	setbe  %r8b
  75d365:	mov    (%rdx),%edx
  75d367:	jmp    75d45b <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x1ab>
  75d36c:	test   %rbx,%rbx
  75d36f:	je     75d338 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x88>
  75d371:	mov    (%rdx),%r8d
  75d374:	test   %r8d,%r8d
  75d377:	je     75d338 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x88>
  75d379:	lea    (%rax,%r9,8),%r9
  75d37d:	mov    %rbx,%rax
  75d380:	cmp    %r8d,-0x14(%r9)
  75d384:	jne    75d33b <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x8b>
  75d386:	mov    %rdi,(%rsp)
  75d38a:	mov    %r14,%rdi
  75d38d:	mov    %rsi,%r13
  75d390:	mov    %r8d,%esi
  75d393:	mov    %rdx,%r12
  75d396:	xor    %edx,%edx
  75d398:	call   *0x35bd32(%rip)        # ab90d0 <_DYNAMIC+0x470>
  75d39e:	mov    %r12,%rdx
  75d3a1:	mov    %r13,%rsi
  75d3a4:	mov    (%rsp),%rdi
  75d3a8:	mov    0x28(%r14),%rcx
  75d3ac:	jmp    75d33b <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x8b>
  75d3ae:	mov    0x8(%r14),%r8
  75d3b2:	mov    0x10(%r14),%r9
  75d3b6:	mov    %r9,%r10
  75d3b9:	test   %r9,%r9
  75d3bc:	je     75d403 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x153>
  75d3be:	xor    %r10d,%r10d
  75d3c1:	cmp    $0x1,%r9
  75d3c5:	je     75d3f3 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x143>
  75d3c7:	mov    %r9,%r11
  75d3ca:	nopw   0x0(%rax,%rax,1)
  75d3d0:	mov    %r11,%r14
  75d3d3:	shr    $1,%r14
  75d3d6:	lea    (%r14,%r10,1),%r12
  75d3da:	lea    (%r12,%r12,2),%r13
  75d3de:	mov    0x10(%r8,%r13,8),%r13d
  75d3e3:	cmp    %r13,%rbx
  75d3e6:	cmova  %r12,%r10
  75d3ea:	sub    %r14,%r11
  75d3ed:	cmp    $0x1,%r11
  75d3f1:	ja     75d3d0 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x120>
  75d3f3:	lea    (%r10,%r10,2),%r11
  75d3f7:	mov    0x10(%r8,%r11,8),%r11d
  75d3fc:	cmp    %rbx,%r11
  75d3ff:	adc    $0x0,%r10
  75d403:	shl    $0x3,%r10
  75d407:	lea    (%r10,%r10,2),%r10
  75d40b:	lea    (%r8,%r10,1),%r11
  75d40f:	mov    (%rdx),%edx
  75d411:	shl    $0x3,%r9
  75d415:	lea    (%r9,%r9,2),%r9
  75d419:	nopl   0x0(%rax)
  75d420:	cmp    %r10,%r9
  75d423:	je     75d4dd <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x22d>
  75d429:	mov    %r11,%r14
  75d42c:	mov    0x10(%r11),%r11d
  75d430:	cmp    %r11,%rbx
  75d433:	jne    75d4dd <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x22d>
  75d439:	lea    0x18(%r14),%r11
  75d43d:	add    $0x18,%r10
  75d441:	cmp    %edx,(%r14)
  75d444:	ja     75d420 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x170>
  75d446:	cmp    0x4(%r14),%edx
  75d44a:	ja     75d420 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x170>
  75d44c:	movzbl -0x3(%r8,%r10,1),%r8d
  75d452:	cmp    %r15d,%ebp
  75d455:	ja     75d4e9 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x239>
  75d45b:	movaps %xmm0,%xmm3
  75d45e:	minss  %xmm1,%xmm3
  75d462:	movaps %xmm3,%xmm2
  75d465:	cmpunordss %xmm3,%xmm2
  75d46a:	movaps %xmm2,%xmm4
  75d46d:	andps  %xmm0,%xmm4
  75d470:	andnps %xmm3,%xmm2
  75d473:	orps   %xmm4,%xmm2
  75d476:	movaps %xmm1,%xmm3
  75d479:	subss  %xmm0,%xmm3
  75d47d:	andps  -0x69a064(%rip),%xmm3        # c3420 <GCC_except_table0+0x10b8>
  75d484:	cmp    %r15d,%ebp
  75d487:	lea    (%rax,%rax,2),%rax
  75d48b:	movss  0x8(%rcx,%rax,8),%xmm4
  75d491:	movss  0xc(%rcx,%rax,8),%xmm5
  75d497:	mov    %edx,(%rdi)
  75d499:	movb   $0x1,0x4(%rdi)
  75d49d:	mov    %ebp,0x8(%rdi)
  75d4a0:	movb   $0x0,0xc(%rdi)
  75d4a4:	movss  %xmm0,0x28(%rdi)
  75d4a9:	movss  %xmm1,0x2c(%rdi)
  75d4ae:	movss  %xmm2,0x10(%rdi)
  75d4b3:	movss  %xmm4,0x14(%rdi)
  75d4b8:	movss  %xmm3,0x18(%rdi)
  75d4bd:	movss  %xmm5,0x1c(%rdi)
  75d4c2:	mov    %rbx,0x20(%rdi)
  75d4c6:	seta   0x30(%rdi)
  75d4ca:	mov    %r8b,0x31(%rdi)
  75d4ce:	add    $0x8,%rsp
  75d4d2:	pop    %rbx
  75d4d3:	pop    %r12
  75d4d5:	pop    %r13
  75d4d7:	pop    %r14
  75d4d9:	pop    %r15
  75d4db:	pop    %rbp
  75d4dc:	ret
  75d4dd:	xor    %r8d,%r8d
  75d4e0:	cmp    %r15d,%ebp
  75d4e3:	jbe    75d45b <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x1ab>
  75d4e9:	movss  0x10(%rsi),%xmm3
  75d4ee:	movaps %xmm0,%xmm2
  75d4f1:	test   %r8b,%r8b
  75d4f4:	je     75d484 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x1d4>
  75d4f6:	subss  %xmm3,%xmm2
  75d4fa:	jmp    75d484 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x1d4>
  75d4fc:	lea    0x33ba25(%rip),%rdx        # a98f28 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x7f0>
  75d503:	mov    $0x1,%edi
  75d508:	mov    $0x1,%esi
  75d50d:	call   *0x35b9bd(%rip)        # ab8ed0 <_DYNAMIC+0x270>
  75d513:	lea    0x33ba26(%rip),%rdx        # a98f40 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x808>
  75d51a:	mov    %rbx,%rdi
  75d51d:	mov    %rcx,%rsi
  75d520:	call   *0x35b9aa(%rip)        # ab8ed0 <_DYNAMIC+0x270>
  75d526:	lea    0x33ba2b(%rip),%rdx        # a98f58 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x820>
  75d52d:	mov    %rax,%rdi
  75d530:	mov    %rcx,%rsi
  75d533:	call   *0x35b997(%rip)        # ab8ed0 <_DYNAMIC+0x270>

<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::present_inner::{closure#9} bytes=1503 frame=248

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075d540 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_>:
  75d540:	push   %rbp
  75d541:	push   %r15
  75d543:	push   %r14
  75d545:	push   %r13
  75d547:	push   %r12
  75d549:	push   %rbx
  75d54a:	sub    $0xc8,%rsp
  75d551:	mov    %rcx,%r14
  75d554:	mov    %rsi,%r15
  75d557:	mov    (%rcx),%ecx
  75d559:	mov    0x10(%r14),%ebx
  75d55d:	test   %ebx,%ebx
  75d55f:	je     75d583 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x43>
  75d561:	cmp    $0x1,%ebx
  75d564:	jne    75d75a <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x21a>
  75d56a:	movss  -0x69afaa(%rip),%xmm0        # c25c8 <GCC_except_table0+0x260>
  75d572:	mov    %ebx,%ebp
  75d574:	movss  0x4(%r14),%xmm1
  75d57a:	movaps %xmm1,%xmm2
  75d57d:	test   %ecx,%ecx
  75d57f:	je     75d59b <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x5b>
  75d581:	jmp    75d59e <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x5e>
  75d583:	movss  0x14(%r14),%xmm0
  75d589:	mov    $0x1,%ebp
  75d58e:	movss  0x4(%r14),%xmm1
  75d594:	movaps %xmm1,%xmm2
  75d597:	test   %ecx,%ecx
  75d599:	jne    75d59e <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x5e>
  75d59b:	movaps %xmm0,%xmm2
  75d59e:	mov    $0x1,%eax
  75d5a3:	cmovne %eax,%ebp
  75d5a6:	mov    (%r15),%rax
  75d5a9:	mov    0x10(%rax),%rsi
  75d5ad:	test   %rsi,%rsi
  75d5b0:	je     75da81 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x541>
  75d5b6:	mov    %ecx,0x1c(%rsp)
  75d5ba:	mov    %rdi,0x10(%rsp)
  75d5bf:	mov    0x8(%rax),%rax
  75d5c3:	mov    (%rdx),%rcx
  75d5c6:	cmp    $0x1,%rsi
  75d5ca:	jne    75d691 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x151>
  75d5d0:	xor    %r12d,%r12d
  75d5d3:	mov    %r12,%rdi
  75d5d6:	shl    $0x4,%rdi
  75d5da:	mov    (%rax,%rdi,1),%r8
  75d5de:	cmp    %rcx,%r8
  75d5e1:	seta   %sil
  75d5e5:	sbb    $0x0,%sil
  75d5e9:	cmp    %rcx,%r8
  75d5ec:	jne    75d613 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0xd3>
  75d5ee:	add    %rdi,%rax
  75d5f1:	mov    0x8(%rax),%ecx
  75d5f4:	mov    0x8(%rdx),%edi
  75d5f7:	cmp    %edi,%ecx
  75d5f9:	seta   %sil
  75d5fd:	sbb    $0x0,%sil
  75d601:	cmp    %edi,%ecx
  75d603:	jne    75d613 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0xd3>
  75d605:	mov    0xc(%rax),%eax
  75d608:	cmp    0xc(%rdx),%eax
  75d60b:	seta   %sil
  75d60f:	sbb    $0x0,%sil
  75d613:	test   %sil,%sil
  75d616:	jne    75da86 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x546>
  75d61c:	movss  %xmm2,0x8(%rsp)
  75d622:	movss  %xmm1,0xc(%rsp)
  75d628:	mov    0x8(%r15),%rax
  75d62c:	mov    0x10(%rax),%rsi
  75d630:	cmp    %rsi,%r12
  75d633:	jae    75dabc <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x57c>
  75d639:	mov    0x8(%rax),%rax
  75d63d:	lea    (%r12,%r12,4),%rcx
  75d641:	mov    0x20(%rax,%rcx,8),%r13d
  75d646:	mov    %r13d,%edi
  75d649:	call   *0x35ba89(%rip)        # ab90d8 <_DYNAMIC+0x478>
  75d64f:	cmp    $0x2,%dl
  75d652:	jne    75d6e9 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x1a9>
  75d658:	mov    0x18(%r15),%rdx
  75d65c:	cmpq   $0x0,(%rdx)
  75d660:	je     75da35 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x4f5>
  75d666:	mov    %r13d,%eax
  75d669:	and    $0xf,%eax
  75d66c:	cmp    $0x9,%eax
  75d66f:	ja     75da68 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x528>
  75d675:	cmp    $0x6,%eax
  75d678:	je     75d684 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x144>
  75d67a:	shr    $0x4,%r13d
  75d67e:	jne    75d789 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x249>
  75d684:	lea    0x33ba1d(%rip),%rdi        # a990a8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x970>
  75d68b:	call   *0x35b8b7(%rip)        # ab8f48 <_DYNAMIC+0x2e8>
  75d691:	mov    0x8(%rdx),%edi
  75d694:	mov    0xc(%rdx),%r8d
  75d698:	xor    %r9d,%r9d
  75d69b:	jmp    75d6b7 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x177>
  75d69d:	nopl   (%rax)
  75d6a0:	test   %r13b,%r13b
  75d6a3:	cmovne %r9,%r12
  75d6a7:	sub    %r10,%rsi
  75d6aa:	mov    %r12,%r9
  75d6ad:	cmp    $0x1,%rsi
  75d6b1:	jbe    75d5d3 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x93>
  75d6b7:	mov    %rsi,%r10
  75d6ba:	shr    $1,%r10
  75d6bd:	lea    (%r10,%r9,1),%r12
  75d6c1:	mov    %r12,%r11
  75d6c4:	shl    $0x4,%r11
  75d6c8:	cmp    %rcx,(%rax,%r11,1)
  75d6cc:	seta   %r13b
  75d6d0:	jne    75d6a0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x160>
  75d6d2:	add    %rax,%r11
  75d6d5:	cmp    %edi,0x8(%r11)
  75d6d9:	seta   %r13b
  75d6dd:	jne    75d6a0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x160>
  75d6df:	cmp    %r8d,0xc(%r11)
  75d6e3:	seta   %r13b
  75d6e7:	jmp    75d6a0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x160>
  75d6e9:	mov    0x10(%r15),%rcx
  75d6ed:	mov    (%rcx),%rcx
  75d6f0:	test   %rcx,%rcx
  75d6f3:	je     75da4e <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x50e>
  75d6f9:	mov    %eax,%edi
  75d6fb:	mov    0x10(%rcx),%rsi
  75d6ff:	cmp    %rdi,%rsi
  75d702:	jbe    75dacc <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x58c>
  75d708:	mov    0x8(%rcx),%rax
  75d70c:	mov    (%rax,%rdi,8),%rax
  75d710:	mov    0x30(%rax),%ecx
  75d713:	mov    0x34(%rax),%eax
  75d716:	xorps  %xmm0,%xmm0
  75d719:	cvtsi2ss %rcx,%xmm0
  75d71e:	xorps  %xmm1,%xmm1
  75d721:	cvtsi2ss %rax,%xmm1
  75d726:	movaps %xmm0,%xmm2
  75d729:	divss  %xmm1,%xmm2
  75d72d:	movzbl 0x8(%r14),%ecx
  75d732:	movss  0xc(%r14),%xmm3
  75d738:	cmpb   $0x0,0x1c(%rsp)
  75d73d:	mov    0x10(%rsp),%rax
  75d742:	je     75d772 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x232>
  75d744:	test   %cl,%cl
  75d746:	je     75d81c <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x2dc>
  75d74c:	movss  0xc(%rsp),%xmm0
  75d752:	movaps %xmm3,%xmm1
  75d755:	jmp    75d829 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x2e9>
  75d75a:	xor    %ebp,%ebp
  75d75c:	movss  0x4(%r14),%xmm1
  75d762:	movaps %xmm1,%xmm2
  75d765:	test   %ecx,%ecx
  75d767:	je     75d59b <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x5b>
  75d76d:	jmp    75d59e <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x5e>
  75d772:	test   %cl,%cl
  75d774:	je     75d829 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x2e9>
  75d77a:	mulss  %xmm3,%xmm2
  75d77e:	movaps %xmm2,%xmm0
  75d781:	movaps %xmm3,%xmm1
  75d784:	jmp    75d829 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x2e9>
  75d789:	mov    0x20(%r15),%rax
  75d78d:	mov    0x10(%rax),%rsi
  75d791:	dec    %r13d
  75d794:	cmp    %r13,%rsi
  75d797:	jbe    75dad9 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x599>
  75d79d:	mov    0x8(%rax),%rsi
  75d7a1:	lea    0x0(%r13,%r13,4),%r13
  75d7a6:	shl    $0x4,%r13
  75d7aa:	cmpq   $0xfffffffffffffffe,(%rsi,%r13,1)
  75d7af:	je     75da5b <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x51b>
  75d7b5:	mov    0x28(%r15),%rcx
  75d7b9:	mov    (%rcx),%rax
  75d7bc:	lea    -0x699883(%rip),%rdi        # c3f40 <GCC_except_table0+0x1bd8>
  75d7c3:	movslq (%rdi,%rax,4),%rax
  75d7c7:	add    %rdi,%rax
  75d7ca:	jmp    *%rax
  75d7cc:	movups -0x6993b7(%rip),%xmm0        # c441c <GCC_except_table0+0x20b4>
  75d7d3:	movaps %xmm0,0x60(%rsp)
  75d7d8:	movups -0x6993d3(%rip),%xmm0        # c440c <GCC_except_table0+0x20a4>
  75d7df:	movaps %xmm0,0x50(%rsp)
  75d7e4:	movups -0x6993ef(%rip),%xmm0        # c43fc <GCC_except_table0+0x2094>
  75d7eb:	movaps %xmm0,0x40(%rsp)
  75d7f0:	movups -0x69940b(%rip),%xmm0        # c43ec <GCC_except_table0+0x2084>
  75d7f7:	movaps %xmm0,0x30(%rsp)
  75d7fc:	movups -0x699427(%rip),%xmm0        # c43dc <GCC_except_table0+0x2074>
  75d803:	movaps %xmm0,0x20(%rsp)
  75d808:	movabs $0x3000100000000,%rax
  75d812:	mov    %rax,0x70(%rsp)
  75d817:	jmp    75d8f2 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x3b2>
  75d81c:	movss  0xc(%rsp),%xmm0
  75d822:	movaps %xmm0,%xmm1
  75d825:	divss  %xmm2,%xmm1
  75d829:	movss  %xmm0,0x10(%rax)
  75d82e:	movss  %xmm1,0x14(%rax)
  75d833:	xorps  %xmm0,%xmm0
  75d836:	movups %xmm0,(%rax)
  75d839:	jmp    75da23 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x4e3>
  75d83e:	mov    0x20(%rcx),%rax
  75d842:	cmp    %rax,%r12
  75d845:	jae    75dae9 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x5a9>
  75d84b:	mov    0x10(%rcx),%rax
  75d84f:	mov    0x18(%rcx),%rdi
  75d853:	movzbl (%rdi,%r12,1),%edi
  75d858:	cmp    %rdi,%rax
  75d85b:	jbe    75db0f <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x5cf>
  75d861:	mov    0x8(%rcx),%rax
  75d865:	imul   $0x58,%rdi,%rcx
  75d869:	jmp    75d8b7 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x377>
  75d86b:	mov    0x8(%rcx),%rax
  75d86f:	lea    0x20(%rsp),%rdi
  75d874:	mov    %rsi,0x88(%rsp)
  75d87c:	mov    %rax,%rsi
  75d87f:	mov    %rdx,0x80(%rsp)
  75d887:	mov    %r12,%rdx
  75d88a:	call   *0x35b7c0(%rip)        # ab9050 <_DYNAMIC+0x3f0>
  75d890:	mov    0x88(%rsp),%rsi
  75d898:	mov    0x80(%rsp),%rdx
  75d8a0:	jmp    75d8f2 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x3b2>
  75d8a2:	mov    0x18(%rcx),%rax
  75d8a6:	cmp    %rax,%r12
  75d8a9:	jae    75dafc <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x5bc>
  75d8af:	mov    0x10(%rcx),%rax
  75d8b3:	imul   $0x58,%r12,%rcx
  75d8b7:	mov    0x50(%rax,%rcx,1),%rdi
  75d8bc:	mov    %rdi,0x70(%rsp)
  75d8c1:	movups 0x40(%rax,%rcx,1),%xmm0
  75d8c6:	movaps %xmm0,0x60(%rsp)
  75d8cb:	movups (%rax,%rcx,1),%xmm0
  75d8cf:	movups 0x10(%rax,%rcx,1),%xmm1
  75d8d4:	movups 0x20(%rax,%rcx,1),%xmm2
  75d8d9:	movups 0x30(%rax,%rcx,1),%xmm3
  75d8de:	movaps %xmm3,0x50(%rsp)
  75d8e3:	movaps %xmm2,0x40(%rsp)
  75d8e8:	movaps %xmm1,0x30(%rsp)
  75d8ed:	movaps %xmm0,0x20(%rsp)
  75d8f2:	mov    0x10(%rsp),%r12
  75d8f7:	movss  0x8(%rsp),%xmm1
  75d8fd:	add    %r13,%rsi
  75d900:	movss  0x38(%rsp),%xmm0
  75d906:	test   %ebx,%ebx
  75d908:	sete   %al
  75d90b:	mov    0x1c(%rsp),%ebx
  75d90f:	or     %bl,%al
  75d911:	movzbl %al,%r8d
  75d915:	lea    0x90(%rsp),%rdi
  75d91d:	mov    %ebp,%ecx
  75d91f:	call   *0x35b7bb(%rip)        # ab90e0 <_DYNAMIC+0x480>
  75d925:	cmpl   $0xfffffffe,0x90(%rsp)
  75d92d:	jne    75d992 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x452>
  75d92f:	mov    0x98(%rsp),%rax
  75d937:	movss  0x30(%rax),%xmm0
  75d93c:	test   %bl,%bl
  75d93e:	movss  0xc(%rsp),%xmm2
  75d944:	jne    75d94b <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x40b>
  75d946:	movss  0x28(%rax),%xmm2
  75d94b:	add    $0x2c,%rax
  75d94f:	lea    0xc(%r14),%rcx
  75d953:	cmpb   $0x0,0x8(%r14)
  75d958:	cmove  %rax,%rcx
  75d95c:	movss  (%rcx),%xmm1
  75d960:	movss  %xmm2,0x10(%r12)
  75d967:	movss  %xmm1,0x14(%r12)
  75d96e:	movl   $0x1,(%r12)
  75d976:	movss  %xmm0,0x4(%r12)
  75d97d:	movl   $0x1,0x8(%r12)
  75d986:	movss  %xmm0,0xc(%r12)
  75d98d:	jmp    75da20 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x4e0>
  75d992:	mov    0x30(%r15),%rbx
  75d996:	mov    (%rbx),%rax
  75d999:	cmp    $0xfffffffffffffffe,%rax
  75d99d:	je     75d9e0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x4a0>
  75d99f:	sub    $0xd,%rax
  75d9a3:	mov    $0x14,%ecx
  75d9a8:	cmovge %rax,%rcx
  75d9ac:	cmp    $0x14,%rcx
  75d9b0:	je     75d9c3 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x483>
  75d9b2:	cmp    $0x19,%rcx
  75d9b6:	jne    75d9e0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x4a0>
  75d9b8:	mov    0x8(%rbx),%rsi
  75d9bc:	mov    $0x10,%eax
  75d9c1:	jmp    75d9cc <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x48c>
  75d9c3:	mov    0x18(%rbx),%rsi
  75d9c7:	mov    $0x20,%eax
  75d9cc:	test   %rsi,%rsi
  75d9cf:	je     75d9e0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x4a0>
  75d9d1:	mov    (%rbx,%rax,1),%rdi
  75d9d5:	mov    $0x1,%edx
  75d9da:	call   *0x35b4c0(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  75d9e0:	mov    0xc0(%rsp),%rax
  75d9e8:	mov    %rax,0x30(%rbx)
  75d9ec:	movups 0x90(%rsp),%xmm0
  75d9f4:	movups 0xa0(%rsp),%xmm1
  75d9fc:	movups 0xb0(%rsp),%xmm2
  75da04:	movups %xmm2,0x20(%rbx)
  75da08:	movups %xmm1,0x10(%rbx)
  75da0c:	movups %xmm0,(%rbx)
  75da0f:	xorps  %xmm0,%xmm0
  75da12:	movups %xmm0,(%r12)
  75da17:	movq   $0x0,0x10(%r12)
  75da20:	mov    %r12,%rax
  75da23:	add    $0xc8,%rsp
  75da2a:	pop    %rbx
  75da2b:	pop    %r12
  75da2d:	pop    %r13
  75da2f:	pop    %r14
  75da31:	pop    %r15
  75da33:	pop    %rbp
  75da34:	ret
  75da35:	lea    -0x68e103(%rip),%rdi        # cf939 <GCC_except_table0+0xd5d1>
  75da3c:	lea    0x33b64d(%rip),%rdx        # a99090 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x958>
  75da43:	mov    $0x28,%esi
  75da48:	call   *0x35b52a(%rip)        # ab8f78 <_DYNAMIC+0x318>
  75da4e:	lea    0x33b60b(%rip),%rdi        # a99060 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x928>
  75da55:	call   *0x35b4ed(%rip)        # ab8f48 <_DYNAMIC+0x2e8>
  75da5b:	lea    0x33b556(%rip),%rdi        # a98fb8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x880>
  75da62:	call   *0x35b4e0(%rip)        # ab8f48 <_DYNAMIC+0x2e8>
  75da68:	lea    -0x68b1a7(%rip),%rdi        # d28c8 <GCC_except_table0+0x10560>
  75da6f:	lea    0x33c79a(%rip),%rdx        # a9a210 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1ad8>
  75da76:	mov    $0x83,%esi
  75da7b:	call   *0x35b457(%rip)        # ab8ed8 <_DYNAMIC+0x278>
  75da81:	xor    %r12d,%r12d
  75da84:	jmp    75da92 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x552>
  75da86:	xor    %eax,%eax
  75da88:	cmp    $0xff,%sil
  75da8c:	sete   %al
  75da8f:	add    %rax,%r12
  75da92:	mov    %r12,0x20(%rsp)
  75da97:	lea    -0x68e199(%rip),%rdi        # cf905 <GCC_except_table0+0xd59d>
  75da9e:	lea    0x33bfd3(%rip),%rcx        # a99a78 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1340>
  75daa5:	lea    0x33b584(%rip),%r8        # a99030 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x8f8>
  75daac:	lea    0x20(%rsp),%rdx
  75dab1:	mov    $0x34,%esi
  75dab6:	call   *0x35b4b4(%rip)        # ab8f70 <_DYNAMIC+0x310>
  75dabc:	lea    0x33b585(%rip),%rdx        # a99048 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x910>
  75dac3:	mov    %r12,%rdi
  75dac6:	call   *0x35b404(%rip)        # ab8ed0 <_DYNAMIC+0x270>
  75dacc:	lea    0x33b5a5(%rip),%rdx        # a99078 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x940>
  75dad3:	call   *0x35b3f7(%rip)        # ab8ed0 <_DYNAMIC+0x270>
  75dad9:	lea    0x33b4c0(%rip),%rdx        # a98fa0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x868>
  75dae0:	mov    %r13,%rdi
  75dae3:	call   *0x35b3e7(%rip)        # ab8ed0 <_DYNAMIC+0x270>
  75dae9:	lea    0x33c068(%rip),%rdx        # a99b58 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1420>
  75daf0:	mov    %r12,%rdi
  75daf3:	mov    %rax,%rsi
  75daf6:	call   *0x35b3d4(%rip)        # ab8ed0 <_DYNAMIC+0x270>
  75dafc:	lea    0x33c03d(%rip),%rdx        # a99b40 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1408>
  75db03:	mov    %r12,%rdi
  75db06:	mov    %rax,%rsi
  75db09:	call   *0x35b3c1(%rip)        # ab8ed0 <_DYNAMIC+0x270>
  75db0f:	lea    0x33c05a(%rip),%rdx        # a99b70 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1438>
  75db16:	mov    %rax,%rsi
  75db19:	call   *0x35b3b1(%rip)        # ab8ed0 <_DYNAMIC+0x270>

<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::present_inner::{closure#41} bytes=884 frame=136

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075db20 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_>:
  75db20:	push   %rbp
  75db21:	push   %r15
  75db23:	push   %r14
  75db25:	push   %r13
  75db27:	push   %r12
  75db29:	push   %rbx
  75db2a:	sub    $0x58,%rsp
  75db2e:	mov    (%rsi),%rax
  75db31:	mov    0x10(%rax),%rcx
  75db35:	mov    %rcx,0x10(%rsp)
  75db3a:	movups (%rax),%xmm0
  75db3d:	movaps %xmm0,(%rsp)
  75db41:	movq   $0x0,(%rax)
  75db48:	movq   $0x4,0x8(%rax)
  75db50:	movq   $0x0,0x10(%rax)
  75db58:	mov    0x8(%rsi),%r13
  75db5c:	mov    0x10(%rsi),%rbp
  75db60:	mov    0x18(%rsi),%rax
  75db64:	mov    %rax,0x30(%rsp)
  75db69:	mov    0x20(%rsi),%rax
  75db6d:	mov    %rax,0x28(%rsp)
  75db72:	mov    0x8(%rdx),%r12
  75db76:	mov    0x10(%rdx),%rbx
  75db7a:	mov    (%rsp),%r15
  75db7e:	mov    0x10(%rsp),%rsi
  75db83:	mov    %r15,%rax
  75db86:	sub    %rsi,%rax
  75db89:	cmp    %rax,%rbx
  75db8c:	mov    %rdi,0x38(%rsp)
  75db91:	ja     75ddfe <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x2de>
  75db97:	test   %rbx,%rbx
  75db9a:	je     75ddda <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x2ba>
  75dba0:	shl    $0x4,%rbx
  75dba4:	add    %r12,%rbx
  75dba7:	mov    %rsp,%rdi
  75dbaa:	jmp    75dbe9 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc9>
  75dbac:	mov    0x8(%rsp),%rax
  75dbb1:	mov    %rsi,%rcx
  75dbb4:	shl    $0x4,%rcx
  75dbb8:	movl   $0x7fc00000,(%rax,%rcx,1)
  75dbbf:	mov    %r15d,0x4(%rax,%rcx,1)
  75dbc4:	mov    %r14,0x8(%rax,%rcx,1)
  75dbc9:	inc    %rsi
  75dbcc:	mov    %rsi,0x10(%rsp)
  75dbd1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  75dbe0:	cmp    %rbx,%r12
  75dbe3:	je     75ddda <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x2ba>
  75dbe9:	mov    %r12,%rax
  75dbec:	add    $0x10,%r12
  75dbf0:	mov    0x8(%rax),%r15d
  75dbf4:	test   %r15d,%r15d
  75dbf7:	je     75dbe0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75dbf9:	mov    (%rax),%r14
  75dbfc:	cmpb   $0x1,0x0(%r13)
  75dc01:	jne    75dd57 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x237>
  75dc07:	mov    0x0(%rbp),%rax
  75dc0b:	test   %rax,%rax
  75dc0e:	je     75dcc0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x1a0>
  75dc14:	cmp    $0x1,%eax
  75dc17:	jne    75dce0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x1c0>
  75dc1d:	mov    0x10(%rbp),%rcx
  75dc21:	test   %rcx,%rcx
  75dc24:	je     75dbe0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75dc26:	mov    0x8(%rbp),%rax
  75dc2a:	xor    %edx,%edx
  75dc2c:	cmp    $0x1,%rcx
  75dc30:	je     75dc64 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x144>
  75dc32:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  75dc40:	mov    %rdx,%r9
  75dc43:	mov    %rcx,%r10
  75dc46:	shr    $1,%r10
  75dc49:	add    %r10,%rdx
  75dc4c:	mov    %rdx,%r8
  75dc4f:	shl    $0x4,%r8
  75dc53:	cmp    %r14,(%rax,%r8,1)
  75dc57:	cmova  %r9,%rdx
  75dc5b:	sub    %r10,%rcx
  75dc5e:	cmp    $0x1,%rcx
  75dc62:	ja     75dc40 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x120>
  75dc64:	mov    %rdx,%rcx
  75dc67:	shl    $0x4,%rcx
  75dc6b:	xor    %r8d,%r8d
  75dc6e:	cmp    %r14,(%rax,%rcx,1)
  75dc72:	setbe  %r8b
  75dc76:	add    %rdx,%r8
  75dc79:	je     75dbe0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75dc7f:	shl    $0x4,%r8
  75dc83:	mov    %r14,%rcx
  75dc86:	sub    -0x10(%rax,%r8,1),%rcx
  75dc8b:	mov    -0x4(%rax,%r8,1),%edx
  75dc90:	cmp    %rdx,%rcx
  75dc93:	jae    75dbe0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75dc99:	add    %r8,%rax
  75dc9c:	mov    -0x8(%rax),%eax
  75dc9f:	add    %rax,%rcx
  75dca2:	mov    0x30(%rsp),%rax
  75dca7:	cmp    0x10(%rax),%rcx
  75dcab:	jae    75dbe0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75dcb1:	jmp    75dd16 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x1f6>
  75dcb3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  75dcc0:	mov    %r14,%rcx
  75dcc3:	sub    0x8(%rbp),%rcx
  75dcc7:	jb     75dbe0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75dccd:	cmp    0x10(%rbp),%rcx
  75dcd1:	jae    75dbe0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75dcd7:	jmp    75dd07 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x1e7>
  75dcd9:	nopl   0x0(%rax)
  75dce0:	mov    0x10(%rbp),%rcx
  75dce4:	test   %rcx,%rcx
  75dce7:	je     75dbe0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75dced:	mov    0x8(%rbp),%rax
  75dcf1:	cmp    $0x1,%rcx
  75dcf5:	jne    75dd88 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x268>
  75dcfb:	cmp    %r14,(%rax)
  75dcfe:	jne    75dbe0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75dd04:	mov    0x8(%rax),%ecx
  75dd07:	mov    0x30(%rsp),%rax
  75dd0c:	cmp    0x10(%rax),%rcx
  75dd10:	jae    75dbe0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75dd16:	mov    0x30(%rsp),%rax
  75dd1b:	mov    0x8(%rax),%rax
  75dd1f:	mov    (%rax,%rcx,4),%eax
  75dd22:	mov    $0xffffffff,%ecx
  75dd27:	cmp    %rcx,%rax
  75dd2a:	je     75dbe0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75dd30:	mov    0x28(%rsp),%rcx
  75dd35:	cmp    %rax,0x10(%rcx)
  75dd39:	jbe    75dbe0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75dd3f:	mov    0x28(%rsp),%rcx
  75dd44:	mov    0x8(%rcx),%rcx
  75dd48:	shl    $0x6,%rax
  75dd4c:	cmp    %r14,0x20(%rcx,%rax,1)
  75dd51:	jne    75dbe0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75dd57:	cmp    (%rsp),%rsi
  75dd5b:	jne    75dbac <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x8c>
  75dd61:	mov    $0x1,%edx
  75dd66:	mov    $0x4,%ecx
  75dd6b:	mov    $0x10,%r8d
  75dd71:	mov    %rsi,0x20(%rsp)
  75dd76:	call   75b120 <_RINvNvMs2_NtCscdodAO9FK5_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs9C2G9YFESsD_29canonical_text_public_control>
  75dd7b:	mov    %rsp,%rdi
  75dd7e:	mov    0x20(%rsp),%rsi
  75dd83:	jmp    75dbac <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x8c>
  75dd88:	xor    %edx,%edx
  75dd8a:	nopw   0x0(%rax,%rax,1)
  75dd90:	mov    %rdx,%r9
  75dd93:	mov    %rcx,%r10
  75dd96:	shr    $1,%r10
  75dd99:	add    %r10,%rdx
  75dd9c:	lea    (%rdx,%rdx,2),%r8
  75dda0:	cmp    %r14,(%rax,%r8,4)
  75dda4:	cmova  %r9,%rdx
  75dda8:	sub    %r10,%rcx
  75ddab:	cmp    $0x1,%rcx
  75ddaf:	ja     75dd90 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x270>
  75ddb1:	lea    (%rdx,%rdx,2),%rcx
  75ddb5:	cmp    %r14,(%rax,%rcx,4)
  75ddb9:	jne    75dbe0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75ddbf:	lea    (%rax,%rcx,4),%rax
  75ddc3:	mov    0x8(%rax),%ecx
  75ddc6:	mov    0x30(%rsp),%rax
  75ddcb:	cmp    0x10(%rax),%rcx
  75ddcf:	jae    75dbe0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75ddd5:	jmp    75dd16 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x1f6>
  75ddda:	mov    0x10(%rsp),%rax
  75dddf:	mov    0x38(%rsp),%rcx
  75dde4:	mov    %rax,0x10(%rcx)
  75dde8:	movaps (%rsp),%xmm0
  75ddec:	movups %xmm0,(%rcx)
  75ddef:	add    $0x58,%rsp
  75ddf3:	pop    %rbx
  75ddf4:	pop    %r12
  75ddf6:	pop    %r13
  75ddf8:	pop    %r14
  75ddfa:	pop    %r15
  75ddfc:	pop    %rbp
  75ddfd:	ret
  75ddfe:	mov    %rsi,0x20(%rsp)
  75de03:	mov    %rsi,%rax
  75de06:	add    %rbx,%rax
  75de09:	jb     75de4e <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x32e>
  75de0b:	mov    0x8(%rsp),%rdx
  75de10:	lea    0x40(%rsp),%rdi
  75de15:	mov    $0x4,%r8d
  75de1b:	mov    $0x10,%r9d
  75de21:	mov    %r15,%rsi
  75de24:	mov    %rax,%r14
  75de27:	mov    %rax,%rcx
  75de2a:	call   772180 <_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs9C2G9YFESsD_29canonical_text_public_control>
  75de2f:	cmpl   $0x1,0x40(%rsp)
  75de34:	je     75de58 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x338>
  75de36:	mov    0x48(%rsp),%rax
  75de3b:	mov    %rax,0x8(%rsp)
  75de40:	mov    %r14,(%rsp)
  75de44:	mov    0x20(%rsp),%rsi
  75de49:	jmp    75dba0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x80>
  75de4e:	xor    %edi,%edi
  75de50:	call   *0x35b102(%rip)        # ab8f58 <_DYNAMIC+0x2f8>
  75de56:	ud2
  75de58:	mov    0x48(%rsp),%rdi
  75de5d:	mov    0x50(%rsp),%rsi
  75de62:	jmp    75de50 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x330>
  75de64:	mov    %rax,%rbx
  75de67:	mov    (%rsp),%r15
  75de6b:	jmp    75de70 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x350>
  75de6d:	mov    %rax,%rbx
  75de70:	test   %r15,%r15
  75de73:	je     75de8c <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x36c>
  75de75:	mov    0x8(%rsp),%rdi
  75de7a:	shl    $0x4,%r15
  75de7e:	mov    $0x4,%edx
  75de83:	mov    %r15,%rsi
  75de86:	call   *0x35b014(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  75de8c:	mov    %rbx,%rdi
  75de8f:	call   a97380 <_Unwind_Resume@plt>

<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::present_inner::{closure#44} bytes=415 frame=8

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075dea0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_>:
  75dea0:	push   %rax
  75dea1:	mov    (%rdi),%rdx
  75dea4:	mov    (%rdx),%rax
  75dea7:	test   %rax,%rax
  75deaa:	je     75def6 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x56>
  75deac:	cmp    $0x1,%eax
  75deaf:	jne    75df12 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x72>
  75deb1:	mov    0x8(%rdx),%rcx
  75deb5:	mov    0x10(%rdx),%rdx
  75deb9:	cmp    $0x1,%rdx
  75debd:	je     75df68 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0xc8>
  75dec3:	test   %rdx,%rdx
  75dec6:	je     75e010 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x170>
  75decc:	xor    %eax,%eax
  75dece:	xchg   %ax,%ax
  75ded0:	mov    %rax,%r8
  75ded3:	mov    %rdx,%r9
  75ded6:	shr    $1,%r9
  75ded9:	add    %r9,%rax
  75dedc:	mov    %rax,%r10
  75dedf:	shl    $0x4,%r10
  75dee3:	cmp    %rsi,(%rcx,%r10,1)
  75dee7:	cmova  %r8,%rax
  75deeb:	sub    %r9,%rdx
  75deee:	cmp    $0x1,%rdx
  75def2:	ja     75ded0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x30>
  75def4:	jmp    75df6a <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0xca>
  75def6:	mov    %rsi,%rax
  75def9:	sub    0x8(%rdx),%rax
  75defd:	jb     75e010 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x170>
  75df03:	cmp    0x10(%rdx),%rax
  75df07:	jb     75dfa2 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x102>
  75df0d:	jmp    75e010 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x170>
  75df12:	mov    0x8(%rdx),%rax
  75df16:	mov    0x10(%rdx),%rcx
  75df1a:	cmp    $0x1,%rcx
  75df1e:	je     75dfe8 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x148>
  75df24:	test   %rcx,%rcx
  75df27:	je     75e010 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x170>
  75df2d:	xor    %edx,%edx
  75df2f:	nop
  75df30:	mov    %rdx,%r8
  75df33:	mov    %rcx,%r9
  75df36:	shr    $1,%r9
  75df39:	add    %r9,%rdx
  75df3c:	lea    (%rdx,%rdx,2),%r10
  75df40:	cmp    %rsi,(%rax,%r10,4)
  75df44:	cmova  %r8,%rdx
  75df48:	sub    %r9,%rcx
  75df4b:	cmp    $0x1,%rcx
  75df4f:	ja     75df30 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x90>
  75df51:	lea    (%rdx,%rdx,2),%rcx
  75df55:	cmp    %rsi,(%rax,%rcx,4)
  75df59:	jne    75e010 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x170>
  75df5f:	lea    (%rax,%rcx,4),%rax
  75df63:	jmp    75dfed <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x14d>
  75df68:	xor    %eax,%eax
  75df6a:	mov    %rax,%r8
  75df6d:	shl    $0x4,%r8
  75df71:	xor    %edx,%edx
  75df73:	cmp    %rsi,(%rcx,%r8,1)
  75df77:	setbe  %dl
  75df7a:	add    %rax,%rdx
  75df7d:	je     75e010 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x170>
  75df83:	shl    $0x4,%rdx
  75df87:	mov    %rsi,%rax
  75df8a:	sub    -0x10(%rcx,%rdx,1),%rax
  75df8f:	mov    -0x4(%rcx,%rdx,1),%r8d
  75df94:	cmp    %r8,%rax
  75df97:	jae    75e010 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x170>
  75df99:	add    %rdx,%rcx
  75df9c:	mov    -0x8(%rcx),%ecx
  75df9f:	add    %rcx,%rax
  75dfa2:	mov    0x8(%rdi),%rdx
  75dfa6:	mov    0x10(%rdx),%rcx
  75dfaa:	cmp    %rcx,%rax
  75dfad:	jae    75dffd <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x15d>
  75dfaf:	mov    0x8(%rdx),%rcx
  75dfb3:	mov    (%rcx,%rax,4),%edx
  75dfb6:	mov    $0xffffffff,%eax
  75dfbb:	cmp    %rax,%rdx
  75dfbe:	je     75dfe4 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x144>
  75dfc0:	mov    0x10(%rdi),%rcx
  75dfc4:	mov    0x10(%rcx),%rax
  75dfc8:	cmp    %rdx,%rax
  75dfcb:	jbe    75e029 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x189>
  75dfcd:	mov    0x8(%rcx),%rcx
  75dfd1:	mov    %rdx,%rdi
  75dfd4:	shl    $0x6,%rdi
  75dfd8:	xor    %eax,%eax
  75dfda:	cmp    %rsi,0x20(%rcx,%rdi,1)
  75dfdf:	sete   %al
  75dfe2:	pop    %rcx
  75dfe3:	ret
  75dfe4:	xor    %eax,%eax
  75dfe6:	pop    %rcx
  75dfe7:	ret
  75dfe8:	cmp    %rsi,(%rax)
  75dfeb:	jne    75e010 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x170>
  75dfed:	mov    0x8(%rax),%eax
  75dff0:	mov    0x8(%rdi),%rdx
  75dff4:	mov    0x10(%rdx),%rcx
  75dff8:	cmp    %rcx,%rax
  75dffb:	jb     75dfaf <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x10f>
  75dffd:	lea    0x33b0bc(%rip),%rdx        # a990c0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x988>
  75e004:	mov    %rax,%rdi
  75e007:	mov    %rcx,%rsi
  75e00a:	call   *0x35aec0(%rip)        # ab8ed0 <_DYNAMIC+0x270>
  75e010:	lea    -0x68e81f(%rip),%rdi        # cf7f8 <GCC_except_table0+0xd490>
  75e017:	lea    0x33aad2(%rip),%rdx        # a98af0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x3b8>
  75e01e:	mov    $0x15,%esi
  75e023:	call   *0x35af4f(%rip)        # ab8f78 <_DYNAMIC+0x318>
  75e029:	lea    0x33acd0(%rip),%rcx        # a98d00 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x5c8>
  75e030:	mov    %rdx,%rdi
  75e033:	mov    %rax,%rsi
  75e036:	mov    %rcx,%rdx
  75e039:	call   *0x35ae91(%rip)        # ab8ed0 <_DYNAMIC+0x270>

<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::present_inner::{closure#15} bytes=130 frame=8

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075e040 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_>:
  75e040:	push   %rax
  75e041:	cmp    %rsi,%rdx
  75e044:	jae    75e0af <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_+0x6f>
  75e046:	lea    (%rdx,%rdx,4),%rax
  75e04a:	mov    0x20(%rdi,%rax,8),%eax
  75e04e:	and    $0xf,%eax
  75e051:	cmp    $0x9,%eax
  75e054:	ja     75e096 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_+0x56>
  75e056:	lea    -0x69a10d(%rip),%rcx        # c3f50 <GCC_except_table0+0x1be8>
  75e05d:	movslq (%rcx,%rax,4),%rax
  75e061:	add    %rcx,%rax
  75e064:	jmp    *%rax
  75e066:	mov    $0x8,%al
  75e068:	jmp    75e088 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_+0x48>
  75e06a:	mov    $0x4,%al
  75e06c:	jmp    75e088 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_+0x48>
  75e06e:	mov    $0x2,%al
  75e070:	jmp    75e088 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_+0x48>
  75e072:	mov    $0x3,%al
  75e074:	jmp    75e088 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_+0x48>
  75e076:	mov    $0x7,%al
  75e078:	jmp    75e088 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_+0x48>
  75e07a:	xor    %eax,%eax
  75e07c:	jmp    75e088 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_+0x48>
  75e07e:	mov    $0x1,%al
  75e080:	jmp    75e088 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_+0x48>
  75e082:	mov    $0x5,%al
  75e084:	jmp    75e088 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_+0x48>
  75e086:	mov    $0x6,%al
  75e088:	cmp    $0x4,%al
  75e08a:	sete   %cl
  75e08d:	cmp    $0x7,%al
  75e08f:	sete   %al
  75e092:	or     %cl,%al
  75e094:	pop    %rcx
  75e095:	ret
  75e096:	lea    -0x68b7d5(%rip),%rdi        # d28c8 <GCC_except_table0+0x10560>
  75e09d:	lea    0x33c16c(%rip),%rdx        # a9a210 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1ad8>
  75e0a4:	mov    $0x83,%esi
  75e0a9:	call   *0x35ae29(%rip)        # ab8ed8 <_DYNAMIC+0x278>
  75e0af:	lea    0x33b022(%rip),%rax        # a990d8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x9a0>
  75e0b6:	mov    %rdx,%rdi
  75e0b9:	mov    %rax,%rdx
  75e0bc:	call   *0x35ae0e(%rip)        # ab8ed0 <_DYNAMIC+0x270>

<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::present_inner::{closure#25} bytes=143 frame=24

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075e0d0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersn_0BQ_>:
  75e0d0:	push   %r14
  75e0d2:	push   %rbx
  75e0d3:	push   %rax
  75e0d4:	mov    %rdx,%rbx
  75e0d7:	and    $0xf,%esi
  75e0da:	cmp    $0x7,%esi
  75e0dd:	jb     75e0e7 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersn_0BQ_+0x17>
  75e0df:	lea    -0x8(%rsi),%eax
  75e0e2:	cmp    $0x2,%eax
  75e0e5:	jae    75e10d <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersn_0BQ_+0x3d>
  75e0e7:	mov    0x30(%rbx),%rax
  75e0eb:	mov    %rax,0x30(%rdi)
  75e0ef:	movups (%rbx),%xmm0
  75e0f2:	movups 0x10(%rbx),%xmm1
  75e0f6:	movups 0x20(%rbx),%xmm2
  75e0fa:	movups %xmm2,0x20(%rdi)
  75e0fe:	movups %xmm1,0x10(%rdi)
  75e102:	movups %xmm0,(%rdi)
  75e105:	add    $0x8,%rsp
  75e109:	pop    %rbx
  75e10a:	pop    %r14
  75e10c:	ret
  75e10d:	cmp    $0x7,%esi
  75e110:	jne    75e131 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersn_0BQ_+0x61>
  75e112:	cmpl   $0x27,(%rbx)
  75e115:	jne    75e0e7 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersn_0BQ_+0x17>
  75e117:	cmpq   $0xb,0x8(%rbx)
  75e11c:	jne    75e0e7 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersn_0BQ_+0x17>
  75e11e:	movb   $0x5,0x8(%rdi)
  75e122:	movq   $0x28,(%rdi)
  75e129:	add    $0x8,%rsp
  75e12d:	pop    %rbx
  75e12e:	pop    %r14
  75e130:	ret
  75e131:	lea    -0x68b870(%rip),%rdi        # d28c8 <GCC_except_table0+0x10560>
  75e138:	lea    0x33c0d1(%rip),%rdx        # a9a210 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1ad8>
  75e13f:	mov    $0x83,%esi
  75e144:	call   *0x35ad8e(%rip)        # ab8ed8 <_DYNAMIC+0x278>
  75e14a:	ud2
  75e14c:	mov    %rax,%r14
  75e14f:	mov    %rbx,%rdi
  75e152:	call   74d540 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  75e157:	mov    %r14,%rdi
  75e15a:	call   a97380 <_Unwind_Resume@plt>

<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::present_inner::{closure#26} bytes=61 frame=72

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075e160 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerso_0BQ_>:
  75e160:	sub    $0x48,%rsp
  75e164:	cvtps2pd (%rdx),%xmm0
  75e167:	cvtps2pd 0x8(%rdx),%xmm1
  75e16b:	movaps %xmm0,0x10(%rsp)
  75e170:	movaps %xmm1,0x20(%rsp)
  75e175:	cvtps2pd 0x10(%rdx),%xmm0
  75e179:	movaps %xmm0,0x30(%rsp)
  75e17e:	movb   $0x0,0x40(%rsp)
  75e183:	movups (%rsi),%xmm0
  75e186:	movaps %xmm0,(%rsp)
  75e18a:	lea    0x10(%rsp),%rsi
  75e18f:	mov    %rsp,%rdx
  75e192:	call   *0x35af50(%rip)        # ab90e8 <_DYNAMIC+0x488>
  75e198:	add    $0x48,%rsp
  75e19c:	ret

<<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::present_inner::{closure#9} as core::ops::function::FnOnce<(gpui_reactivity_core::tree::NodeId, cephal::tree::traits::MeasureInput)>>::call_once::{shim:vtable#0} bytes=57 frame=56

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075ec90 <_RNSNvYNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtBc_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0INtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceTNtNtCscO85OU7Wpt0_20gpui_reactivity_core4tree6NodeIdNtNtNtCs2M7EwM6HstD_6cephal4tree6traits12MeasureInputEE9call_once6vtableBV_>:
  75ec90:	push   %rbx
  75ec91:	sub    $0x30,%rsp
  75ec95:	mov    %rdi,%rbx
  75ec98:	lea    0x10(%rsp),%rax
  75ec9d:	movups (%rcx),%xmm0
  75eca0:	movups 0x10(%rcx),%xmm1
  75eca4:	movaps %xmm1,0x20(%rsp)
  75eca9:	movaps %xmm0,0x10(%rsp)
  75ecae:	movups (%rdx),%xmm0
  75ecb1:	movaps %xmm0,(%rsp)
  75ecb5:	mov    %rsp,%rdx
  75ecb8:	mov    %rax,%rcx
  75ecbb:	call   75d540 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_>
  75ecc0:	mov    %rbx,%rax
  75ecc3:	add    $0x30,%rsp
  75ecc7:	pop    %rbx
  75ecc8:	ret

canonical_text_public_control::owner_drag bytes=1426 frame=280

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075ecd0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag>:
  75ecd0:	push   %rbp
  75ecd1:	push   %r15
  75ecd3:	push   %r14
  75ecd5:	push   %r13
  75ecd7:	push   %r12
  75ecd9:	push   %rbx
  75ecda:	sub    $0xe8,%rsp
  75ece1:	movss  %xmm1,0x8(%rsp)
  75ece7:	movss  %xmm0,0x94(%rsp)
  75ecf0:	mov    (%rdi),%r15
  75ecf3:	test   %r15,%r15
  75ecf6:	je     75f050 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x380>
  75ecfc:	cmpb   $0x0,0x76e(%r15)
  75ed04:	jne    75f057 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x387>
  75ed0a:	cmpb   $0x1,0x76a(%r15)
  75ed12:	jne    75f05e <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x38e>
  75ed18:	mov    %rsi,0xb0(%rsp)
  75ed20:	mov    %rdi,0x98(%rsp)
  75ed28:	mov    0x5c0(%r15),%rbp
  75ed2f:	mov    $0x1a,%eax
  75ed34:	mov    %rax,0x88(%rsp)
  75ed3c:	test   %rbp,%rbp
  75ed3f:	je     75f06b <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x39b>
  75ed45:	mov    0x5b8(%r15),%r14
  75ed4c:	shl    $0x6,%rbp
  75ed50:	lea    0x1e8(%r15),%r12
  75ed57:	xor    %ebx,%ebx
  75ed59:	mov    0x35a200(%rip),%r13        # ab8f60 <_DYNAMIC+0x300>
  75ed60:	jmp    75ed7d <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0xad>
  75ed62:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  75ed70:	add    $0x40,%rbx
  75ed74:	cmp    %rbx,%rbp
  75ed77:	je     75f06b <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x39b>
  75ed7d:	cmpb   $0x4,0x3d(%r14,%rbx,1)
  75ed83:	jne    75ed70 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0xa0>
  75ed85:	mov    0x20(%r14,%rbx,1),%rsi
  75ed8a:	mov    %r12,%rdi
  75ed8d:	call   *%r13
  75ed90:	test   %al,%al
  75ed92:	je     75ed70 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0xa0>
  75ed94:	mov    0x20(%r14,%rbx,1),%rsi
  75ed99:	lea    0x5f0(%r15),%rdi
  75eda0:	call   *0x35a35a(%rip)        # ab9100 <_DYNAMIC+0x4a0>
  75eda6:	cmpb   $0x0,0x76e(%r15)
  75edae:	jne    75f0ae <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x3de>
  75edb4:	mov    %rdx,%rcx
  75edb7:	lea    0x10(%rsp),%rdi
  75edbc:	mov    %r15,%rsi
  75edbf:	mov    %rax,%rdx
  75edc2:	call   76a2f0 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11input_indexBY_>
  75edc7:	mov    0x10(%rsp),%rax
  75edcc:	mov    0x18(%rsp),%rdx
  75edd1:	cmp    $0xfffffffffffffffe,%rax
  75edd5:	mov    0x98(%rsp),%rbx
  75eddd:	jne    75f0b9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x3e9>
  75ede3:	lea    0x50(%rsp),%rdi
  75ede8:	mov    %r15,%rsi
  75edeb:	call   76a430 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE12selection_atBY_>
  75edf0:	cmpq   $0xfffffffffffffffe,0x50(%rsp)
  75edf6:	jne    75f0e4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x414>
  75edfc:	movups 0x58(%rsp),%xmm0
  75ee01:	movaps %xmm0,0xa0(%rsp)
  75ee09:	movss  0x94(%rsp),%xmm0
  75ee12:	movss  %xmm0,0x14(%rsp)
  75ee18:	movss  0x8(%rsp),%xmm0
  75ee1e:	movss  %xmm0,0x18(%rsp)
  75ee24:	movl   $0x0,0x10(%rsp)
  75ee2c:	lea    0x50(%rsp),%rdi
  75ee31:	lea    0x10(%rsp),%rcx
  75ee36:	mov    %rbx,%rsi
  75ee39:	mov    0xb0(%rsp),%rdx
  75ee41:	call   76cd00 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_>
  75ee46:	cmpl   $0xfffffffe,0x50(%rsp)
  75ee4b:	jne    75efdf <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x30f>
  75ee51:	mov    (%rbx),%rsi
  75ee54:	lea    0xb8(%rsp),%rdi
  75ee5c:	call   760520 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack>
  75ee61:	mov    (%rbx),%r14
  75ee64:	test   %r14,%r14
  75ee67:	je     75f146 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x476>
  75ee6d:	cmpb   $0x0,0x76e(%r14)
  75ee75:	jne    75f14d <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x47d>
  75ee7b:	cmpb   $0x1,0x76a(%r14)
  75ee83:	jne    75f154 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x484>
  75ee89:	mov    0x5c0(%r14),%rbp
  75ee90:	mov    $0x1a,%eax
  75ee95:	mov    %rax,0x8(%rsp)
  75ee9a:	test   %rbp,%rbp
  75ee9d:	je     75f15e <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x48e>
  75eea3:	mov    0x5b8(%r14),%r12
  75eeaa:	shl    $0x6,%rbp
  75eeae:	lea    0x1e8(%r14),%r15
  75eeb5:	xor    %ebx,%ebx
  75eeb7:	jmp    75eecd <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x1fd>
  75eeb9:	nopl   0x0(%rax)
  75eec0:	add    $0x40,%rbx
  75eec4:	cmp    %rbx,%rbp
  75eec7:	je     75f15e <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x48e>
  75eecd:	cmpb   $0x4,0x3d(%r12,%rbx,1)
  75eed3:	jne    75eec0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x1f0>
  75eed5:	mov    0x20(%r12,%rbx,1),%rsi
  75eeda:	mov    %r15,%rdi
  75eedd:	call   *%r13
  75eee0:	test   %al,%al
  75eee2:	je     75eec0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x1f0>
  75eee4:	mov    0x20(%r12,%rbx,1),%rsi
  75eee9:	add    $0x5f0,%r14
  75eef0:	mov    %r14,%rdi
  75eef3:	call   *0x35a207(%rip)        # ab9100 <_DYNAMIC+0x4a0>
  75eef9:	mov    %rdx,%rcx
  75eefc:	mov    0x98(%rsp),%rdx
  75ef04:	mov    (%rdx),%rbx
  75ef07:	test   %rbx,%rbx
  75ef0a:	je     75f19e <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x4ce>
  75ef10:	cmpb   $0x0,0x76e(%rbx)
  75ef17:	jne    75f1b2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x4e2>
  75ef1d:	lea    0x10(%rsp),%rdi
  75ef22:	mov    %rbx,%rsi
  75ef25:	mov    %rax,%rdx
  75ef28:	call   76a2f0 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11input_indexBY_>
  75ef2d:	mov    0x10(%rsp),%rax
  75ef32:	mov    0x18(%rsp),%rdx
  75ef37:	cmp    $0xfffffffffffffffe,%rax
  75ef3b:	jne    75f1bd <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x4ed>
  75ef41:	lea    0x50(%rsp),%rdi
  75ef46:	mov    %rbx,%rsi
  75ef49:	call   76a430 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE12selection_atBY_>
  75ef4e:	cmpq   $0xfffffffffffffffe,0x50(%rsp)
  75ef54:	jne    75f1e8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x518>
  75ef5a:	movups 0x58(%rsp),%xmm0
  75ef5f:	movaps %xmm0,0x10(%rsp)
  75ef64:	movzbl 0x1c(%rsp),%ecx
  75ef69:	cmp    0xac(%rsp),%cl
  75ef70:	mov    0x18(%rsp),%edx
  75ef74:	sete   %al
  75ef77:	cmp    0xa8(%rsp),%edx
  75ef7e:	je     75ef82 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x2b2>
  75ef80:	xor    %eax,%eax
  75ef82:	test   %al,%al
  75ef84:	jne    75f037 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x367>
  75ef8a:	mov    0xd0(%rsp),%rsi
  75ef92:	xor    0xc8(%rsp),%rsi
  75ef9a:	movabs $0x100000001b3,%rdi
  75efa4:	imul   %rdi,%rsi
  75efa8:	mov    0x10(%rsp),%eax
  75efac:	xor    %rsi,%rax
  75efaf:	movzbl 0x14(%rsp),%esi
  75efb4:	imul   %rdi,%rax
  75efb8:	xor    %rsi,%rax
  75efbb:	imul   %rdi,%rax
  75efbf:	xor    %rdx,%rax
  75efc2:	imul   %rdi,%rax
  75efc6:	xor    %rcx,%rax
  75efc9:	imul   %rdi,%rax
  75efcd:	add    $0xe8,%rsp
  75efd4:	pop    %rbx
  75efd5:	pop    %r12
  75efd7:	pop    %r13
  75efd9:	pop    %r14
  75efdb:	pop    %r15
  75efdd:	pop    %rbp
  75efde:	ret
  75efdf:	mov    0x80(%rsp),%rax
  75efe7:	mov    %rax,0x40(%rsp)
  75efec:	movups 0x50(%rsp),%xmm0
  75eff1:	movups 0x60(%rsp),%xmm1
  75eff6:	movups 0x70(%rsp),%xmm2
  75effb:	movaps %xmm2,0x30(%rsp)
  75f000:	movaps %xmm1,0x20(%rsp)
  75f005:	movaps %xmm0,0x10(%rsp)
  75f00a:	lea    -0x68f42f(%rip),%rdi        # cfbe2 <GCC_except_table0+0xd87a>
  75f011:	lea    0x33a980(%rip),%rcx        # a99998 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1260>
  75f018:	lea    0x33a311(%rip),%r8        # a99330 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xbf8>
  75f01f:	lea    0x10(%rsp),%rbx
  75f024:	mov    $0x2b,%esi
  75f029:	mov    %rbx,%rdx
  75f02c:	call   *0x359f3e(%rip)        # ab8f70 <_DYNAMIC+0x310>
  75f032:	jmp    75f245 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x575>
  75f037:	lea    0x18(%rsp),%rdi
  75f03c:	lea    0xa8(%rsp),%rsi
  75f044:	lea    0x33a315(%rip),%rdx        # a99360 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xc28>
  75f04b:	call   74f2c3 <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextPositionBM_ECs9C2G9YFESsD_29canonical_text_public_control>
  75f050:	mov    $0xd,%eax
  75f055:	jmp    75f063 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x393>
  75f057:	mov    $0xe,%eax
  75f05c:	jmp    75f063 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x393>
  75f05e:	mov    $0x12,%eax
  75f063:	mov    %rax,0x88(%rsp)
  75f06b:	mov    0x88(%rsp),%rax
  75f073:	mov    %rax,0x10(%rsp)
  75f078:	movq   $0x0,0x18(%rsp)
  75f081:	lea    -0x68f727(%rip),%rdi        # cf961 <GCC_except_table0+0xd5f9>
  75f088:	lea    0x33a909(%rip),%rcx        # a99998 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1260>
  75f08f:	lea    0x33a26a(%rip),%r8        # a99300 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xbc8>
  75f096:	lea    0x10(%rsp),%rbx
  75f09b:	mov    $0x2a,%esi
  75f0a0:	mov    %rbx,%rdx
  75f0a3:	call   *0x359ec7(%rip)        # ab8f70 <_DYNAMIC+0x310>
  75f0a9:	jmp    75f245 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x575>
  75f0ae:	movq   $0xe,0x50(%rsp)
  75f0b7:	jmp    75f0e4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x414>
  75f0b9:	mov    0x40(%rsp),%rcx
  75f0be:	mov    %rcx,0x80(%rsp)
  75f0c6:	movups 0x20(%rsp),%xmm0
  75f0cb:	movups 0x30(%rsp),%xmm1
  75f0d0:	movups %xmm1,0x70(%rsp)
  75f0d5:	movups %xmm0,0x60(%rsp)
  75f0da:	mov    %rax,0x50(%rsp)
  75f0df:	mov    %rdx,0x58(%rsp)
  75f0e4:	mov    0x80(%rsp),%rax
  75f0ec:	mov    %rax,0x40(%rsp)
  75f0f1:	mov    0x50(%rsp),%rax
  75f0f6:	mov    0x58(%rsp),%rcx
  75f0fb:	movups 0x60(%rsp),%xmm0
  75f100:	movups 0x70(%rsp),%xmm1
  75f105:	movaps %xmm1,0x30(%rsp)
  75f10a:	movaps %xmm0,0x20(%rsp)
  75f10f:	mov    %rax,0x10(%rsp)
  75f114:	mov    %rcx,0x18(%rsp)
  75f119:	lea    -0x68f53e(%rip),%rdi        # cfbe2 <GCC_except_table0+0xd87a>
  75f120:	lea    0x33a871(%rip),%rcx        # a99998 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1260>
  75f127:	lea    0x33a1ea(%rip),%r8        # a99318 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xbe0>
  75f12e:	lea    0x10(%rsp),%rbx
  75f133:	mov    $0x2b,%esi
  75f138:	mov    %rbx,%rdx
  75f13b:	call   *0x359e2f(%rip)        # ab8f70 <_DYNAMIC+0x310>
  75f141:	jmp    75f245 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x575>
  75f146:	mov    $0xd,%eax
  75f14b:	jmp    75f159 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x489>
  75f14d:	mov    $0xe,%eax
  75f152:	jmp    75f159 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x489>
  75f154:	mov    $0x12,%eax
  75f159:	mov    %rax,0x8(%rsp)
  75f15e:	mov    0x8(%rsp),%rax
  75f163:	mov    %rax,0x10(%rsp)
  75f168:	movq   $0x0,0x18(%rsp)
  75f171:	lea    -0x68f817(%rip),%rdi        # cf961 <GCC_except_table0+0xd5f9>
  75f178:	lea    0x33a819(%rip),%rcx        # a99998 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1260>
  75f17f:	lea    0x33a17a(%rip),%r8        # a99300 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xbc8>
  75f186:	lea    0x10(%rsp),%rbx
  75f18b:	mov    $0x2a,%esi
  75f190:	mov    %rbx,%rdx
  75f193:	call   *0x359dd7(%rip)        # ab8f70 <_DYNAMIC+0x310>
  75f199:	jmp    75f245 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x575>
  75f19e:	movq   $0xd,0x50(%rsp)
  75f1a7:	movq   $0x0,0x58(%rsp)
  75f1b0:	jmp    75f1e8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x518>
  75f1b2:	movq   $0xe,0x50(%rsp)
  75f1bb:	jmp    75f1e8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x518>
  75f1bd:	mov    0x40(%rsp),%rcx
  75f1c2:	mov    %rcx,0x80(%rsp)
  75f1ca:	movups 0x20(%rsp),%xmm0
  75f1cf:	movups 0x30(%rsp),%xmm1
  75f1d4:	movups %xmm1,0x70(%rsp)
  75f1d9:	movups %xmm0,0x60(%rsp)
  75f1de:	mov    %rax,0x50(%rsp)
  75f1e3:	mov    %rdx,0x58(%rsp)
  75f1e8:	mov    0x80(%rsp),%rax
  75f1f0:	mov    %rax,0x40(%rsp)
  75f1f5:	mov    0x50(%rsp),%rax
  75f1fa:	mov    0x58(%rsp),%rcx
  75f1ff:	movups 0x60(%rsp),%xmm0
  75f204:	movups 0x70(%rsp),%xmm1
  75f209:	movaps %xmm1,0x30(%rsp)
  75f20e:	movaps %xmm0,0x20(%rsp)
  75f213:	mov    %rax,0x10(%rsp)
  75f218:	mov    %rcx,0x18(%rsp)
  75f21d:	lea    -0x68f642(%rip),%rdi        # cfbe2 <GCC_except_table0+0xd87a>
  75f224:	lea    0x33a76d(%rip),%rcx        # a99998 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1260>
  75f22b:	lea    0x33a116(%rip),%r8        # a99348 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xc10>
  75f232:	lea    0x10(%rsp),%rbx
  75f237:	mov    $0x2b,%esi
  75f23c:	mov    %rbx,%rdx
  75f23f:	call   *0x359d2b(%rip)        # ab8f70 <_DYNAMIC+0x310>
  75f245:	ud2
  75f247:	jmp    75f24f <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x57f>
  75f249:	jmp    75f24f <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x57f>
  75f24b:	jmp    75f24f <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x57f>
  75f24d:	jmp    75f24f <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x57f>
  75f24f:	mov    %rax,%r14
  75f252:	mov    %rbx,%rdi
  75f255:	call   74d540 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  75f25a:	mov    %r14,%rdi
  75f25d:	call   a97380 <_Unwind_Resume@plt>

canonical_text_public_control::owner_arrow bytes=1422 frame=248

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075f270 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow>:
  75f270:	push   %rbp
  75f271:	push   %r15
  75f273:	push   %r14
  75f275:	push   %r13
  75f277:	push   %r12
  75f279:	push   %rbx
  75f27a:	sub    $0xc8,%rsp
  75f281:	mov    (%rdi),%rbx
  75f284:	test   %rbx,%rbx
  75f287:	je     75f581 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x311>
  75f28d:	cmpb   $0x0,0x76e(%rbx)
  75f294:	jne    75f588 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x318>
  75f29a:	cmpb   $0x1,0x76a(%rbx)
  75f2a1:	jne    75f58f <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x31f>
  75f2a7:	mov    %esi,0x38(%rsp)
  75f2ab:	mov    0x5c0(%rbx),%r12
  75f2b2:	mov    $0x1a,%eax
  75f2b7:	mov    %rax,0x78(%rsp)
  75f2bc:	test   %r12,%r12
  75f2bf:	je     75f599 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x329>
  75f2c5:	mov    0x5b8(%rbx),%r13
  75f2cc:	shl    $0x6,%r12
  75f2d0:	lea    0x1e8(%rbx),%r14
  75f2d7:	xor    %r15d,%r15d
  75f2da:	mov    0x359c7f(%rip),%rbp        # ab8f60 <_DYNAMIC+0x300>
  75f2e1:	jmp    75f2fd <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x8d>
  75f2e3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  75f2f0:	add    $0x40,%r15
  75f2f4:	cmp    %r15,%r12
  75f2f7:	je     75f599 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x329>
  75f2fd:	cmpb   $0x4,0x3d(%r13,%r15,1)
  75f303:	jne    75f2f0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x80>
  75f305:	mov    0x20(%r13,%r15,1),%rsi
  75f30a:	mov    %r14,%rdi
  75f30d:	call   *%rbp
  75f30f:	test   %al,%al
  75f311:	je     75f2f0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x80>
  75f313:	mov    0x20(%r13,%r15,1),%rsi
  75f318:	lea    0x5f0(%rbx),%rdi
  75f31f:	call   *0x359ddb(%rip)        # ab9100 <_DYNAMIC+0x4a0>
  75f325:	cmpb   $0x0,0x76e(%rbx)
  75f32c:	jne    75f5d6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x366>
  75f332:	mov    %rdx,%rcx
  75f335:	mov    %rsp,%rdi
  75f338:	mov    %rbx,%rsi
  75f33b:	mov    %rax,%rdx
  75f33e:	call   76a2f0 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11input_indexBY_>
  75f343:	mov    (%rsp),%rax
  75f347:	mov    0x8(%rsp),%rdx
  75f34c:	cmp    $0xfffffffffffffffe,%rax
  75f350:	jne    75f5e1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x371>
  75f356:	lea    0x40(%rsp),%rdi
  75f35b:	mov    %rbx,%rsi
  75f35e:	call   76a430 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE12selection_atBY_>
  75f363:	cmpq   $0xfffffffffffffffe,0x40(%rsp)
  75f369:	jne    75f609 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x399>
  75f36f:	movups 0x48(%rsp),%xmm0
  75f374:	movaps %xmm0,0x80(%rsp)
  75f37c:	cmpb   $0x1,0x76e(%rbx)
  75f383:	je     75f665 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x3f5>
  75f389:	movq   $0x0,0x758(%rbx)
  75f394:	mov    0x628(%rbx),%r12
  75f39b:	test   %r12,%r12
  75f39e:	je     75f42c <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x1bc>
  75f3a4:	cmp    0x5f0(%rbx),%r12
  75f3ab:	jne    75f750 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x4e0>
  75f3b1:	mov    0x630(%rbx),%r13
  75f3b8:	mov    %rsp,%rdi
  75f3bb:	mov    %rbx,%rsi
  75f3be:	mov    %r13,%rdx
  75f3c1:	call   78c570 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE16resolve_identityBO_>
  75f3c6:	mov    (%rsp),%rax
  75f3ca:	mov    0x8(%rsp),%rdi
  75f3cf:	cmp    $0xfffffffffffffffe,%rax
  75f3d3:	jne    75f755 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x4e5>
  75f3d9:	mov    0x2e0(%rbx),%rsi
  75f3e0:	cmp    %rsi,%rdi
  75f3e3:	jae    75f7d6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x566>
  75f3e9:	mov    0x2d8(%rbx),%rax
  75f3f0:	lea    (%rdi,%rdi,4),%rcx
  75f3f4:	mov    0x20(%rax,%rcx,8),%edi
  75f3f8:	call   775950 <_RNvMsh_NtCslbxve4rcJus_4gpui7runtimeNtB5_4Node4kind>
  75f3fd:	cmp    $0x4,%al
  75f3ff:	jne    75f42c <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x1bc>
  75f401:	movzbl 0x38(%rsp),%r8d
  75f407:	lea    0x40(%rsp),%rdi
  75f40c:	mov    %rbx,%rsi
  75f40f:	mov    %r12,%rdx
  75f412:	mov    %r13,%rcx
  75f415:	mov    $0x1,%r9d
  75f41b:	call   76f7a0 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE14move_selectionB12_>
  75f420:	cmpq   $0xfffffffffffffffe,0x40(%rsp)
  75f426:	jne    75f77d <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x50d>
  75f42c:	lea    0x98(%rsp),%rdi
  75f434:	mov    %rbx,%rsi
  75f437:	call   760520 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack>
  75f43c:	cmpb   $0x0,0x76e(%rbx)
  75f443:	jne    75f673 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x403>
  75f449:	cmpb   $0x1,0x76a(%rbx)
  75f450:	jne    75f67a <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x40a>
  75f456:	mov    0x5c0(%rbx),%r13
  75f45d:	mov    $0x1a,%eax
  75f462:	mov    %rax,0x38(%rsp)
  75f467:	test   %r13,%r13
  75f46a:	je     75f684 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x414>
  75f470:	mov    0x5b8(%rbx),%r15
  75f477:	shl    $0x6,%r13
  75f47b:	xor    %r12d,%r12d
  75f47e:	jmp    75f48d <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x21d>
  75f480:	add    $0x40,%r12
  75f484:	cmp    %r12,%r13
  75f487:	je     75f684 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x414>
  75f48d:	cmpb   $0x4,0x3d(%r15,%r12,1)
  75f493:	jne    75f480 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x210>
  75f495:	mov    0x20(%r15,%r12,1),%rsi
  75f49a:	mov    %r14,%rdi
  75f49d:	call   *%rbp
  75f49f:	test   %al,%al
  75f4a1:	je     75f480 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x210>
  75f4a3:	mov    0x20(%r15,%r12,1),%rsi
  75f4a8:	lea    0x5f0(%rbx),%rdi
  75f4af:	call   *0x359c4b(%rip)        # ab9100 <_DYNAMIC+0x4a0>
  75f4b5:	cmpb   $0x0,0x76e(%rbx)
  75f4bc:	jne    75f6c1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x451>
  75f4c2:	mov    %rdx,%rcx
  75f4c5:	mov    %rsp,%rdi
  75f4c8:	mov    %rbx,%rsi
  75f4cb:	mov    %rax,%rdx
  75f4ce:	call   76a2f0 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11input_indexBY_>
  75f4d3:	mov    (%rsp),%rax
  75f4d7:	mov    0x8(%rsp),%rdx
  75f4dc:	cmp    $0xfffffffffffffffe,%rax
  75f4e0:	jne    75f6cc <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x45c>
  75f4e6:	lea    0x40(%rsp),%rdi
  75f4eb:	mov    %rbx,%rsi
  75f4ee:	call   76a430 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE12selection_atBY_>
  75f4f3:	cmpq   $0xfffffffffffffffe,0x40(%rsp)
  75f4f9:	jne    75f6f4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x484>
  75f4ff:	movups 0x48(%rsp),%xmm0
  75f504:	movaps %xmm0,(%rsp)
  75f508:	movzbl 0xc(%rsp),%ecx
  75f50d:	cmp    0x8c(%rsp),%cl
  75f514:	mov    0x8(%rsp),%edx
  75f518:	sete   %al
  75f51b:	cmp    0x88(%rsp),%edx
  75f522:	je     75f526 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x2b6>
  75f524:	xor    %eax,%eax
  75f526:	test   %al,%al
  75f528:	jne    75f568 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x2f8>
  75f52a:	mov    0xb0(%rsp),%rax
  75f532:	xor    0xa8(%rsp),%rax
  75f53a:	movabs $0x100000001b3,%rsi
  75f544:	imul   %rsi,%rax
  75f548:	xor    %rdx,%rax
  75f54b:	imul   %rsi,%rax
  75f54f:	xor    %rcx,%rax
  75f552:	imul   %rsi,%rax
  75f556:	add    $0xc8,%rsp
  75f55d:	pop    %rbx
  75f55e:	pop    %r12
  75f560:	pop    %r13
  75f562:	pop    %r14
  75f564:	pop    %r15
  75f566:	pop    %rbp
  75f567:	ret
  75f568:	lea    0x8(%rsp),%rdi
  75f56d:	lea    0x88(%rsp),%rsi
  75f575:	lea    0x339e44(%rip),%rdx        # a993c0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xc88>
  75f57c:	call   74f2c3 <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextPositionBM_ECs9C2G9YFESsD_29canonical_text_public_control>
  75f581:	mov    $0xd,%eax
  75f586:	jmp    75f594 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x324>
  75f588:	mov    $0xe,%eax
  75f58d:	jmp    75f594 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x324>
  75f58f:	mov    $0x12,%eax
  75f594:	mov    %rax,0x78(%rsp)
  75f599:	mov    0x78(%rsp),%rax
  75f59e:	mov    %rax,(%rsp)
  75f5a2:	movq   $0x0,0x8(%rsp)
  75f5ab:	lea    -0x68fc51(%rip),%rdi        # cf961 <GCC_except_table0+0xd5f9>
  75f5b2:	lea    0x33a3df(%rip),%rcx        # a99998 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1260>
  75f5b9:	lea    0x339d40(%rip),%r8        # a99300 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xbc8>
  75f5c0:	mov    %rsp,%rbx
  75f5c3:	mov    $0x2a,%esi
  75f5c8:	mov    %rbx,%rdx
  75f5cb:	call   *0x35999f(%rip)        # ab8f70 <_DYNAMIC+0x310>
  75f5d1:	jmp    75f7d4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x564>
  75f5d6:	movq   $0xe,0x40(%rsp)
  75f5df:	jmp    75f609 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x399>
  75f5e1:	mov    0x30(%rsp),%rcx
  75f5e6:	mov    %rcx,0x70(%rsp)
  75f5eb:	movups 0x10(%rsp),%xmm0
  75f5f0:	movups 0x20(%rsp),%xmm1
  75f5f5:	movups %xmm1,0x60(%rsp)
  75f5fa:	movups %xmm0,0x50(%rsp)
  75f5ff:	mov    %rax,0x40(%rsp)
  75f604:	mov    %rdx,0x48(%rsp)
  75f609:	mov    0x70(%rsp),%rax
  75f60e:	mov    %rax,0x30(%rsp)
  75f613:	mov    0x40(%rsp),%rax
  75f618:	mov    0x48(%rsp),%rcx
  75f61d:	movups 0x50(%rsp),%xmm0
  75f622:	movups 0x60(%rsp),%xmm1
  75f627:	movaps %xmm1,0x20(%rsp)
  75f62c:	movaps %xmm0,0x10(%rsp)
  75f631:	mov    %rax,(%rsp)
  75f635:	mov    %rcx,0x8(%rsp)
  75f63a:	lea    -0x68fa5f(%rip),%rdi        # cfbe2 <GCC_except_table0+0xd87a>
  75f641:	lea    0x33a350(%rip),%rcx        # a99998 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1260>
  75f648:	lea    0x339d29(%rip),%r8        # a99378 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xc40>
  75f64f:	mov    %rsp,%rbx
  75f652:	mov    $0x2b,%esi
  75f657:	mov    %rbx,%rdx
  75f65a:	call   *0x359910(%rip)        # ab8f70 <_DYNAMIC+0x310>
  75f660:	jmp    75f7d4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x564>
  75f665:	movq   $0xe,0x40(%rsp)
  75f66e:	jmp    75f77d <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x50d>
  75f673:	mov    $0xe,%eax
  75f678:	jmp    75f67f <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x40f>
  75f67a:	mov    $0x12,%eax
  75f67f:	mov    %rax,0x38(%rsp)
  75f684:	mov    0x38(%rsp),%rax
  75f689:	mov    %rax,(%rsp)
  75f68d:	movq   $0x0,0x8(%rsp)
  75f696:	lea    -0x68fd3c(%rip),%rdi        # cf961 <GCC_except_table0+0xd5f9>
  75f69d:	lea    0x33a2f4(%rip),%rcx        # a99998 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1260>
  75f6a4:	lea    0x339c55(%rip),%r8        # a99300 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xbc8>
  75f6ab:	mov    %rsp,%rbx
  75f6ae:	mov    $0x2a,%esi
  75f6b3:	mov    %rbx,%rdx
  75f6b6:	call   *0x3598b4(%rip)        # ab8f70 <_DYNAMIC+0x310>
  75f6bc:	jmp    75f7d4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x564>
  75f6c1:	movq   $0xe,0x40(%rsp)
  75f6ca:	jmp    75f6f4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x484>
  75f6cc:	mov    0x30(%rsp),%rcx
  75f6d1:	mov    %rcx,0x70(%rsp)
  75f6d6:	movups 0x10(%rsp),%xmm0
  75f6db:	movups 0x20(%rsp),%xmm1
  75f6e0:	movups %xmm1,0x60(%rsp)
  75f6e5:	movups %xmm0,0x50(%rsp)
  75f6ea:	mov    %rax,0x40(%rsp)
  75f6ef:	mov    %rdx,0x48(%rsp)
  75f6f4:	mov    0x70(%rsp),%rax
  75f6f9:	mov    %rax,0x30(%rsp)
  75f6fe:	mov    0x40(%rsp),%rax
  75f703:	mov    0x48(%rsp),%rcx
  75f708:	movups 0x50(%rsp),%xmm0
  75f70d:	movups 0x60(%rsp),%xmm1
  75f712:	movaps %xmm1,0x20(%rsp)
  75f717:	movaps %xmm0,0x10(%rsp)
  75f71c:	mov    %rax,(%rsp)
  75f720:	mov    %rcx,0x8(%rsp)
  75f725:	lea    -0x68fb4a(%rip),%rdi        # cfbe2 <GCC_except_table0+0xd87a>
  75f72c:	lea    0x33a265(%rip),%rcx        # a99998 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1260>
  75f733:	lea    0x339c6e(%rip),%r8        # a993a8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xc70>
  75f73a:	mov    %rsp,%rbx
  75f73d:	mov    $0x2b,%esi
  75f742:	mov    %rbx,%rdx
  75f745:	call   *0x359825(%rip)        # ab8f70 <_DYNAMIC+0x310>
  75f74b:	jmp    75f7d4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x564>
  75f750:	mov    $0x11,%eax
  75f755:	mov    0x30(%rsp),%rcx
  75f75a:	mov    %rcx,0x70(%rsp)
  75f75f:	movups 0x10(%rsp),%xmm0
  75f764:	movups 0x20(%rsp),%xmm1
  75f769:	movups %xmm1,0x60(%rsp)
  75f76e:	movups %xmm0,0x50(%rsp)
  75f773:	mov    %rax,0x40(%rsp)
  75f778:	mov    %rdi,0x48(%rsp)
  75f77d:	mov    0x70(%rsp),%rax
  75f782:	mov    %rax,0x30(%rsp)
  75f787:	mov    0x40(%rsp),%rax
  75f78c:	mov    0x48(%rsp),%rcx
  75f791:	movups 0x50(%rsp),%xmm0
  75f796:	movups 0x60(%rsp),%xmm1
  75f79b:	movaps %xmm1,0x20(%rsp)
  75f7a0:	movaps %xmm0,0x10(%rsp)
  75f7a5:	mov    %rax,(%rsp)
  75f7a9:	mov    %rcx,0x8(%rsp)
  75f7ae:	lea    -0x68fbd3(%rip),%rdi        # cfbe2 <GCC_except_table0+0xd87a>
  75f7b5:	lea    0x33a1dc(%rip),%rcx        # a99998 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1260>
  75f7bc:	lea    0x339bcd(%rip),%r8        # a99390 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xc58>
  75f7c3:	mov    %rsp,%rbx
  75f7c6:	mov    $0x2b,%esi
  75f7cb:	mov    %rbx,%rdx
  75f7ce:	call   *0x35979c(%rip)        # ab8f70 <_DYNAMIC+0x310>
  75f7d4:	ud2
  75f7d6:	lea    0x33a69b(%rip),%rdx        # a99e78 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1740>
  75f7dd:	call   *0x3596ed(%rip)        # ab8ed0 <_DYNAMIC+0x270>
  75f7e3:	jmp    75f7eb <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x57b>
  75f7e5:	jmp    75f7eb <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x57b>
  75f7e7:	jmp    75f7eb <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x57b>
  75f7e9:	jmp    75f7eb <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x57b>
  75f7eb:	mov    %rax,%r14
  75f7ee:	mov    %rbx,%rdi
  75f7f1:	call   74d540 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  75f7f6:	mov    %r14,%rdi
  75f7f9:	call   a97380 <_Unwind_Resume@plt>

canonical_text_public_control::query_visual bytes=142 frame=40

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075f800 <_RNvCs9C2G9YFESsD_29canonical_text_public_control12query_visual>:
  75f800:	push   %rbp
  75f801:	push   %r15
  75f803:	push   %r14
  75f805:	push   %r12
  75f807:	push   %rbx
  75f808:	mov    %edx,%r15d
  75f80b:	mov    %esi,%r14d
  75f80e:	mov    %rdi,%r12
  75f811:	call   *0x3598f1(%rip)        # ab9108 <_DYNAMIC+0x4a8>
  75f817:	cmp    $0x2,%dl
  75f81a:	je     75f874 <_RNvCs9C2G9YFESsD_29canonical_text_public_control12query_visual+0x74>
  75f81c:	mov    %eax,%ebx
  75f81e:	mov    %edx,%ebp
  75f820:	movzbl %r15b,%edx
  75f824:	mov    %r12,%rdi
  75f827:	mov    %r14d,%esi
  75f82a:	call   *0x3598e0(%rip)        # ab9110 <_DYNAMIC+0x4b0>
  75f830:	cmp    $0x2,%dl
  75f833:	je     75f881 <_RNvCs9C2G9YFESsD_29canonical_text_public_control12query_visual+0x81>
  75f835:	xor    $0x1,%ebx
  75f838:	movabs $0x100000001b3,%rcx
  75f842:	imul   %rcx,%rbx
  75f846:	and    $0x1,%bpl
  75f84a:	movzbl %bpl,%esi
  75f84e:	xor    %rbx,%rsi
  75f851:	imul   %rcx,%rsi
  75f855:	mov    %eax,%edi
  75f857:	xor    %rsi,%rdi
  75f85a:	imul   %rcx,%rdi
  75f85e:	and    $0x1,%dl
  75f861:	movzbl %dl,%eax
  75f864:	xor    %rdi,%rax
  75f867:	imul   %rcx,%rax
  75f86b:	pop    %rbx
  75f86c:	pop    %r12
  75f86e:	pop    %r14
  75f870:	pop    %r15
  75f872:	pop    %rbp
  75f873:	ret
  75f874:	lea    0x339d25(%rip),%rdi        # a995a0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xe68>
  75f87b:	call   *0x3596c7(%rip)        # ab8f48 <_DYNAMIC+0x2e8>
  75f881:	lea    0x339d30(%rip),%rdi        # a995b8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xe80>
  75f888:	call   *0x3596ba(%rip)        # ab8f48 <_DYNAMIC+0x2e8>

canonical_text_public_control::owner_prepare bytes=1380 frame=280

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075f890 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare>:
  75f890:	push   %rbp
  75f891:	push   %r15
  75f893:	push   %r14
  75f895:	push   %r13
  75f897:	push   %r12
  75f899:	push   %rbx
  75f89a:	sub    $0xe8,%rsp
  75f8a1:	mov    %rdi,%r14
  75f8a4:	test   %esi,%esi
  75f8a6:	jne    75f8ae <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x1e>
  75f8a8:	pxor   %xmm0,%xmm0
  75f8ac:	jmp    75f8b6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x26>
  75f8ae:	movd   -0x69d4ee(%rip),%xmm0        # c23c8 <GCC_except_table0+0x60>
  75f8b6:	movd   %xmm0,(%rsp)
  75f8bb:	mov    (%r14),%rbx
  75f8be:	test   %rbx,%rbx
  75f8c1:	je     75fbac <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x31c>
  75f8c7:	lea    0x8(%r14),%rax
  75f8cb:	mov    %rbx,0xd8(%rsp)
  75f8d3:	mov    %rax,0xe0(%rsp)
  75f8db:	cmpb   $0x0,0x76e(%rbx)
  75f8e2:	jne    75fbe2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x352>
  75f8e8:	mov    0x6a0(%rbx),%rax
  75f8ef:	mov    %rax,0xd0(%rsp)
  75f8f7:	movabs $0x200000001,%r15
  75f901:	mov    0x248(%rbx),%rbp
  75f908:	mov    0x250(%rbx),%r12
  75f90f:	shl    $0x4,%r12
  75f913:	xor    %r13d,%r13d
  75f916:	cs nopw 0x0(%rax,%rax,1)
  75f920:	cmp    %r13,%r12
  75f923:	je     75fb5d <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x2cd>
  75f929:	mov    0x0(%rbp,%r13,1),%rdi
  75f92e:	mov    0x8(%rbp,%r13,1),%rax
  75f933:	call   *0x18(%rax)
  75f936:	add    $0x10,%r13
  75f93a:	cmp    %r15,%rax
  75f93d:	jne    75f920 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x90>
  75f93f:	mov    -0x10(%rbp,%r13,1),%rdi
  75f944:	mov    -0x8(%rbp,%r13,1),%rax
  75f949:	lea    0x290(%rbx),%rsi
  75f950:	call   *0x28(%rax)
  75f953:	mov    %rax,%rdi
  75f956:	mov    %rdx,%rax
  75f959:	lea    0x33a710(%rip),%rdx        # a9a070 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1938>
  75f960:	lea    0x2b0(%rbx),%rsi
  75f967:	call   *0x20(%rax)
  75f96a:	mov    %r15,0x18(%rsp)
  75f96f:	mov    0x18(%rsp),%rcx
  75f974:	mov    %rcx,0xb0(%rsp)
  75f97c:	mov    0x20(%rsp),%rcx
  75f981:	mov    %rcx,0xb8(%rsp)
  75f989:	test   %al,%al
  75f98b:	je     75fbed <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x35d>
  75f991:	movq   $0x0,0xb0(%rsp)
  75f99d:	cmpb   $0x0,0x76e(%rbx)
  75f9a4:	jne    75fbf4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x364>
  75f9aa:	mov    0x6a0(%rbx),%rax
  75f9b1:	inc    %rax
  75f9b4:	je     75fa75 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x1e5>
  75f9ba:	mov    0x2c8(%rbx),%ecx
  75f9c0:	cmp    $0xffffffff,%ecx
  75f9c3:	je     75fb42 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x2b2>
  75f9c9:	inc    %ecx
  75f9cb:	mov    %ecx,0x2c8(%rbx)
  75f9d1:	movaps -0x69bed8(%rip),%xmm0        # c3b00 <GCC_except_table0+0x1798>
  75f9d8:	movups %xmm0,0x2b0(%rbx)
  75f9df:	movss  (%rsp),%xmm0
  75f9e4:	movss  %xmm0,0x2c0(%rbx)
  75f9ec:	movl   $0x0,0x2c4(%rbx)
  75f9f6:	mov    %rax,0x6a0(%rbx)
  75f9fd:	incq   0x700(%rbx)
  75fa04:	movq   $0x0,0x758(%rbx)
  75fa0f:	lea    0x78(%rsp),%rdi
  75fa14:	lea    0xd8(%rsp),%rsi
  75fa1c:	lea    0xb0(%rsp),%rcx
  75fa24:	mov    %r15,%rdx
  75fa27:	xor    %r8d,%r8d
  75fa2a:	call   766c80 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB4_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE20after_source_changedBW_>
  75fa2f:	mov    0x78(%rsp),%r12
  75fa34:	cmp    $0xfffffffffffffffe,%r12
  75fa38:	jne    75fbff <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x36f>
  75fa3e:	mov    (%r14),%rsi
  75fa41:	lea    0x10(%rsp),%rdi
  75fa46:	call   760520 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack>
  75fa4b:	mov    0x28(%rsp),%rcx
  75fa50:	xor    0x20(%rsp),%rcx
  75fa55:	movabs $0x100000001b3,%rax
  75fa5f:	imul   %rcx,%rax
  75fa63:	add    $0xe8,%rsp
  75fa6a:	pop    %rbx
  75fa6b:	pop    %r12
  75fa6d:	pop    %r13
  75fa6f:	pop    %r14
  75fa71:	pop    %r15
  75fa73:	pop    %rbp
  75fa74:	ret
  75fa75:	mov    $0x1f,%r12d
  75fa7b:	mov    0x88(%rsp),%r14
  75fa83:	mov    0x90(%rsp),%rbx
  75fa8b:	movd   (%rsp),%xmm0
  75fa90:	movd   %xmm0,%ecx
  75fa94:	mov    %ecx,%r9d
  75fa97:	shr    $0x8,%r9d
  75fa9b:	movabs $0x3f80000000000000,%rsi
  75faa5:	mov    $0x3f800000,%edx
  75faaa:	mov    $0x2,%r10d
  75fab0:	pxor   %xmm0,%xmm0
  75fab4:	mov    %r10,0x10(%rsp)
  75fab9:	mov    %r12,0x18(%rsp)
  75fabe:	mov    %rax,0x20(%rsp)
  75fac3:	mov    %r14,0x28(%rsp)
  75fac8:	mov    %rbx,0x30(%rsp)
  75facd:	mov    %r11b,0x38(%rsp)
  75fad2:	mov    0x8(%rsp),%eax
  75fad6:	mov    0xb(%rsp),%r10d
  75fadb:	mov    %eax,0x39(%rsp)
  75fadf:	mov    %r10d,0x3c(%rsp)
  75fae4:	mov    %r13,0x40(%rsp)
  75fae9:	mov    %r15,0x48(%rsp)
  75faee:	mov    %rdx,0x50(%rsp)
  75faf3:	mov    %rsi,0x58(%rsp)
  75faf8:	mov    %cl,0x60(%rsp)
  75fafc:	mov    %r9w,0x61(%rsp)
  75fb02:	shr    $0x10,%r9d
  75fb06:	mov    %r9b,0x63(%rsp)
  75fb0b:	movd   %xmm0,0x64(%rsp)
  75fb11:	mov    %rdi,0x68(%rsp)
  75fb16:	mov    %r8,0x70(%rsp)
  75fb1b:	lea    -0x68ff40(%rip),%rdi        # cfbe2 <GCC_except_table0+0xd87a>
  75fb22:	lea    0x339ecf(%rip),%rcx        # a999f8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x12c0>
  75fb29:	lea    0x339ac8(%rip),%r8        # a995f8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xec0>
  75fb30:	lea    0x10(%rsp),%rdx
  75fb35:	mov    $0x2b,%esi
  75fb3a:	call   *0x359430(%rip)        # ab8f70 <_DYNAMIC+0x310>
  75fb40:	jmp    75fb5b <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x2cb>
  75fb42:	lea    -0x68ceaf(%rip),%rdi        # d2c9a <GCC_except_table0+0x10932>
  75fb49:	lea    0x33af90(%rip),%rdx        # a9aae0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x23a8>
  75fb50:	mov    $0x19,%esi
  75fb55:	call   *0x35941d(%rip)        # ab8f78 <_DYNAMIC+0x318>
  75fb5b:	ud2
  75fb5d:	mov    %r15,0x18(%rsp)
  75fb62:	mov    0x18(%rsp),%rax
  75fb67:	mov    %rax,0xb0(%rsp)
  75fb6f:	mov    0x20(%rsp),%rax
  75fb74:	mov    %rax,0xb8(%rsp)
  75fb7c:	mov    $0xb,%eax
  75fb81:	mov    0xb0(%rsp),%rcx
  75fb89:	mov    %rcx,0x88(%rsp)
  75fb91:	mov    0xb8(%rsp),%rcx
  75fb99:	mov    %rcx,0x90(%rsp)
  75fba1:	mov    $0x20,%r12d
  75fba7:	jmp    75fa7b <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x1eb>
  75fbac:	movd   (%rsp),%xmm0
  75fbb1:	movd   %xmm0,%ecx
  75fbb5:	mov    %ecx,%r9d
  75fbb8:	shr    $0x8,%r9d
  75fbbc:	movabs $0x3f80000000000000,%rsi
  75fbc6:	mov    $0x3f800000,%edx
  75fbcb:	pxor   %xmm0,%xmm0
  75fbcf:	mov    $0xd,%r12d
  75fbd5:	mov    $0x2,%r10d
  75fbdb:	xor    %eax,%eax
  75fbdd:	jmp    75fab4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x224>
  75fbe2:	mov    $0xe,%r12d
  75fbe8:	jmp    75fa8b <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x1fb>
  75fbed:	mov    $0xa,%eax
  75fbf2:	jmp    75fb81 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x2f1>
  75fbf4:	mov    $0xe,%r12d
  75fbfa:	jmp    75fa7b <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x1eb>
  75fbff:	mov    0x80(%rsp),%rax
  75fc07:	mov    %rax,(%rsp)
  75fc0b:	mov    0x88(%rsp),%rdx
  75fc13:	movzbl 0x98(%rsp),%ecx
  75fc1b:	mov    0xa0(%rsp),%rdi
  75fc23:	mov    0xa8(%rsp),%r8
  75fc2b:	mov    0x90(%rsp),%rsi
  75fc33:	mov    0x6a0(%rbx),%rax
  75fc3a:	cmp    0xd0(%rsp),%rax
  75fc42:	jne    75fc79 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x3e9>
  75fc44:	lea    0x99(%rsp),%rax
  75fc4c:	mov    (%rax),%r9d
  75fc4f:	mov    0x3(%rax),%eax
  75fc52:	mov    %eax,0xb(%rsp)
  75fc56:	mov    %r9d,0x8(%rsp)
  75fc5b:	mov    $0x4,%r10d
  75fc61:	mov    %r8,%r15
  75fc64:	mov    %rdi,%r13
  75fc67:	mov    %ecx,%r11d
  75fc6a:	mov    %rsi,%rbx
  75fc6d:	mov    %rdx,%r14
  75fc70:	mov    (%rsp),%rax
  75fc74:	jmp    75fab4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x224>
  75fc79:	movzbl 0x76c(%rbx),%r11d
  75fc81:	cmpq   $0x0,0x6d0(%rbx)
  75fc89:	je     75fc9a <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x40a>
  75fc8b:	test   %r11b,%r11b
  75fc8e:	je     75fc9f <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x40f>
  75fc90:	cmpq   $0xffffffffffffffff,0x5c8(%rbx)
  75fc98:	jne    75fc9f <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x40f>
  75fc9a:	xor    %r10d,%r10d
  75fc9d:	jmp    75fcac <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x41c>
  75fc9f:	mov    0x6e0(%rbx),%rbp
  75fca6:	mov    $0x1,%r10d
  75fcac:	mov    0x6a8(%rbx),%r14
  75fcb3:	mov    0x758(%rbx),%rbx
  75fcba:	movzbl 0x9b(%rsp),%r15d
  75fcc3:	shl    $0x10,%r15d
  75fcc7:	movzwl 0x99(%rsp),%r9d
  75fcd0:	or     %r15d,%r9d
  75fcd3:	movd   0x9c(%rsp),%xmm0
  75fcdc:	mov    (%rsp),%r15
  75fce0:	mov    %r12,%r13
  75fce3:	mov    %rbp,%r12
  75fce6:	jmp    75fab4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x224>
  75fceb:	jmp    75fced <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x45d>
  75fced:	mov    %rax,%rdi
  75fcf0:	call   *0x359202(%rip)        # ab8ef8 <_DYNAMIC+0x298>
  75fcf6:	mov    %rax,%r14
  75fcf9:	mov    %rdx,%r15
  75fcfc:	mov    %rax,0x18(%rsp)
  75fd01:	mov    %rdx,0x20(%rsp)
  75fd06:	movq   $0xfffffffffffffffe,0x10(%rsp)
  75fd0f:	mov    %rbx,%rdi
  75fd12:	call   78cbc0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE6poisonBO_>
  75fd17:	mov    (%r15),%rax
  75fd1a:	test   %rax,%rax
  75fd1d:	je     75fd24 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x494>
  75fd1f:	mov    %r14,%rdi
  75fd22:	call   *%rax
  75fd24:	mov    0x8(%r15),%rsi
  75fd28:	mov    $0xf,%r12d
  75fd2e:	test   %rsi,%rsi
  75fd31:	je     75fa7b <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x1eb>
  75fd37:	mov    0x10(%r15),%rdx
  75fd3b:	mov    %r14,%rdi
  75fd3e:	call   *0x35915c(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  75fd44:	jmp    75fa7b <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x1eb>
  75fd49:	mov    %rax,%rbx
  75fd4c:	mov    0x8(%r15),%rsi
  75fd50:	test   %rsi,%rsi
  75fd53:	je     75fdcb <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x53b>
  75fd55:	mov    0x10(%r15),%rdx
  75fd59:	mov    %r14,%rdi
  75fd5c:	call   *0x35913e(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  75fd62:	mov    %rbx,%rdi
  75fd65:	call   a97380 <_Unwind_Resume@plt>
  75fd6a:	mov    %rax,%rbx
  75fd6d:	lea    0x10(%rsp),%rdi
  75fd72:	call   746020 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultIBC_NtNtCslbxve4rcJus_4gpui7element9AdmissionNtNtB15_6source9BindErrorEINtNtCscdodAO9FK5_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECs9C2G9YFESsD_29canonical_text_public_control>
  75fd77:	jmp    75fdcb <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x53b>
  75fd79:	call   *0x359149(%rip)        # ab8ec8 <_DYNAMIC+0x268>
  75fd7f:	call   *0x35917b(%rip)        # ab8f00 <_DYNAMIC+0x2a0>
  75fd85:	mov    %rax,%rdi
  75fd88:	call   *0x35916a(%rip)        # ab8ef8 <_DYNAMIC+0x298>
  75fd8e:	mov    %rax,0x18(%rsp)
  75fd93:	mov    %rdx,0x20(%rsp)
  75fd98:	movq   $0xfffffffffffffffd,0x10(%rsp)
  75fda1:	mov    %rbx,%rdi
  75fda4:	call   78cbc0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE6poisonBO_>
  75fda9:	lea    0x10(%rsp),%rdi
  75fdae:	call   746090 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultIBC_NtNtNtCslbxve4rcJus_4gpui7runtime5paint12PatchOutcomeNtB15_5ErrorEINtNtCscdodAO9FK5_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECs9C2G9YFESsD_29canonical_text_public_control>
  75fdb3:	mov    $0xf,%r12d
  75fdb9:	jmp    75fa7b <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x1eb>
  75fdbe:	mov    %rax,%rbx
  75fdc1:	lea    0x10(%rsp),%rdi
  75fdc6:	call   746090 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultIBC_NtNtNtCslbxve4rcJus_4gpui7runtime5paint12PatchOutcomeNtB15_5ErrorEINtNtCscdodAO9FK5_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECs9C2G9YFESsD_29canonical_text_public_control>
  75fdcb:	mov    %rbx,%rdi
  75fdce:	call   a97380 <_Unwind_Resume@plt>
  75fdd3:	call   *0x3590ef(%rip)        # ab8ec8 <_DYNAMIC+0x268>
  75fdd9:	call   *0x359121(%rip)        # ab8f00 <_DYNAMIC+0x2a0>
  75fddf:	mov    %rax,%rbx
  75fde2:	lea    0x10(%rsp),%rdi
  75fde7:	call   748320 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui7runtime8SetErrorNtNtCscO85OU7Wpt0_20gpui_reactivity_core8geometry6AffineEECs9C2G9YFESsD_29canonical_text_public_control>
  75fdec:	mov    %rbx,%rdi
  75fdef:	call   a97380 <_Unwind_Resume@plt>

canonical_text_public_control::owner_reshape bytes=340 frame=248

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075fe00 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_reshape>:
  75fe00:	push   %r15
  75fe02:	push   %r14
  75fe04:	push   %r13
  75fe06:	push   %r12
  75fe08:	push   %rbx
  75fe09:	sub    $0xd0,%rsp
  75fe10:	mov    %rdx,%r14
  75fe13:	test   %rdx,%rdx
  75fe16:	jns    75fe27 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_reshape+0x27>
  75fe18:	xor    %r13d,%r13d
  75fe1b:	mov    %r13,%rdi
  75fe1e:	mov    %r14,%rsi
  75fe21:	call   *0x359131(%rip)        # ab8f58 <_DYNAMIC+0x2f8>
  75fe27:	mov    %rdi,%rbx
  75fe2a:	je     75fe62 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_reshape+0x62>
  75fe2c:	mov    %rsi,%r12
  75fe2f:	call   *0x359073(%rip)        # ab8ea8 <_DYNAMIC+0x248>
  75fe35:	mov    $0x1,%r13d
  75fe3b:	mov    $0x1,%esi
  75fe40:	mov    %r14,%rdi
  75fe43:	call   *0x359067(%rip)        # ab8eb0 <_DYNAMIC+0x250>
  75fe49:	test   %rax,%rax
  75fe4c:	je     75fe1b <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_reshape+0x1b>
  75fe4e:	mov    %rax,%r15
  75fe51:	mov    %rax,%rdi
  75fe54:	mov    %r12,%rsi
  75fe57:	mov    %r14,%rdx
  75fe5a:	call   *0x359060(%rip)        # ab8ec0 <memcpy@GLIBC_2.14>
  75fe60:	jmp    75fe68 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_reshape+0x68>
  75fe62:	mov    $0x1,%r15d
  75fe68:	mov    %r14,(%rsp)
  75fe6c:	mov    %r15,0x8(%rsp)
  75fe71:	mov    %r14,0x10(%rsp)
  75fe76:	lea    0x339683(%rip),%rdx        # a99500 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xdc8>
  75fe7d:	lea    0x68(%rsp),%rdi
  75fe82:	mov    %rsp,%rcx
  75fe85:	mov    %rbx,%rsi
  75fe88:	call   7447f0 <_RINvMst_NtCslbxve4rcJus_4gpui7runtimeINtB6_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE3setNtNtCscdodAO9FK5_5alloc6string6StringEBL_>
  75fe8d:	cmpl   $0xffffffff,0x68(%rsp)
  75fe92:	jne    75fec8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_reshape+0xc8>
  75fe94:	mov    (%rbx),%rsi
  75fe97:	mov    %rsp,%rdi
  75fe9a:	call   760520 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack>
  75fe9f:	mov    0x18(%rsp),%rcx
  75fea4:	xor    0x10(%rsp),%rcx
  75fea9:	movabs $0x100000001b3,%rax
  75feb3:	imul   %rcx,%rax
  75feb7:	add    $0xd0,%rsp
  75febe:	pop    %rbx
  75febf:	pop    %r12
  75fec1:	pop    %r13
  75fec3:	pop    %r14
  75fec5:	pop    %r15
  75fec7:	ret
  75fec8:	mov    0xc8(%rsp),%rax
  75fed0:	mov    %rax,0x60(%rsp)
  75fed5:	movups 0xb8(%rsp),%xmm0
  75fedd:	movaps %xmm0,0x50(%rsp)
  75fee2:	movups 0xa8(%rsp),%xmm0
  75feea:	movaps %xmm0,0x40(%rsp)
  75feef:	movups 0x68(%rsp),%xmm0
  75fef4:	movups 0x78(%rsp),%xmm1
  75fef9:	movups 0x88(%rsp),%xmm2
  75ff01:	movups 0x98(%rsp),%xmm3
  75ff09:	movaps %xmm3,0x30(%rsp)
  75ff0e:	movaps %xmm2,0x20(%rsp)
  75ff13:	movaps %xmm1,0x10(%rsp)
  75ff18:	movaps %xmm0,(%rsp)
  75ff1c:	lea    -0x690341(%rip),%rdi        # cfbe2 <GCC_except_table0+0xd87a>
  75ff23:	lea    0x339aee(%rip),%rcx        # a99a18 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x12e0>
  75ff2a:	lea    0x3396df(%rip),%r8        # a99610 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xed8>
  75ff31:	mov    %rsp,%rdx
  75ff34:	mov    $0x2b,%esi
  75ff39:	call   *0x359031(%rip)        # ab8f70 <_DYNAMIC+0x310>
  75ff3f:	ud2
  75ff41:	mov    %rax,%rbx
  75ff44:	mov    %rsp,%rdi
  75ff47:	call   7483e0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui7runtime8SetErrorNtNtCscdodAO9FK5_5alloc6string6StringEECs9C2G9YFESsD_29canonical_text_public_control>
  75ff4c:	mov    %rbx,%rdi
  75ff4f:	call   a97380 <_Unwind_Resume@plt>

canonical_text_public_control::map_transcript bytes=303 frame=136

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075ff60 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript>:
  75ff60:	push   %r15
  75ff62:	push   %r14
  75ff64:	push   %r12
  75ff66:	push   %rbx
  75ff67:	sub    $0x68,%rsp
  75ff6b:	mov    %rdi,%rsi
  75ff6e:	mov    %rsp,%rdi
  75ff71:	call   *0x3591a1(%rip)        # ab9118 <_DYNAMIC+0x4b8>
  75ff77:	mov    0x8(%rsp),%rsi
  75ff7c:	mov    0x10(%rsp),%rcx
  75ff81:	mov    $0x1,%eax
  75ff86:	cmp    %rsi,%rcx
  75ff89:	jbe    75ff97 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x37>
  75ff8b:	add    $0x68,%rsp
  75ff8f:	pop    %rbx
  75ff90:	pop    %r12
  75ff92:	pop    %r14
  75ff94:	pop    %r15
  75ff96:	ret
  75ff97:	lea    0x18(%rsp),%rbx
  75ff9c:	lea    0x30(%rsp),%r14
  75ffa1:	movabs $0x100000001b3,%r15
  75ffab:	cmp    $0x1,%rcx
  75ffaf:	je     760078 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x118>
  75ffb5:	mov    (%rsp),%rdx
  75ffb9:	mov    (%rdx),%edi
  75ffbb:	add    $0xc,%rdx
  75ffbf:	jmp    75ffdc <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x7c>
  75ffc1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  75ffd0:	dec    %rsi
  75ffd3:	add    $0xc,%rdx
  75ffd7:	cmp    %rsi,%rcx
  75ffda:	ja     75ff8b <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x2b>
  75ffdc:	mov    %edi,%r8d
  75ffdf:	mov    (%rdx),%edi
  75ffe1:	cmp    %edi,%r8d
  75ffe4:	je     75ffd0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x70>
  75ffe6:	testb  $0x2,-0x4(%rdx)
  75ffea:	je     75ffd0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x70>
  75ffec:	testb  $0x1,0x8(%rdx)
  75fff0:	je     75ffd0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x70>
  75fff2:	mov    %rdx,(%rsp)
  75fff6:	dec    %rsi
  75fff9:	mov    %rsi,0x8(%rsp)
  75fffe:	add    $0xfffffffffffffff4,%rdx
  760002:	mov    %r14,%rdi
  760005:	mov    %rbx,%rsi
  760008:	mov    %rax,%r12
  76000b:	call   75d2b0 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control>
  760010:	mov    %r12,%rax
  760013:	mov    0x30(%rsp),%ecx
  760017:	mov    0x38(%rsp),%edx
  76001b:	mov    0x40(%rsp),%esi
  76001f:	mov    0x44(%rsp),%edi
  760023:	mov    0x48(%rsp),%r8d
  760028:	mov    0x4c(%rsp),%r9d
  76002d:	xor    %rcx,%rax
  760030:	imul   %r15,%rax
  760034:	xor    %rdx,%rax
  760037:	imul   %r15,%rax
  76003b:	xor    0x50(%rsp),%rax
  760040:	imul   %r15,%rax
  760044:	xor    %rsi,%rax
  760047:	imul   %r15,%rax
  76004b:	xor    %rdi,%rax
  76004e:	imul   %r15,%rax
  760052:	xor    %r8,%rax
  760055:	imul   %r15,%rax
  760059:	xor    %r9,%rax
  76005c:	imul   %r15,%rax
  760060:	mov    0x8(%rsp),%rsi
  760065:	mov    0x10(%rsp),%rcx
  76006a:	cmp    %rsi,%rcx
  76006d:	jbe    75ffab <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x4b>
  760073:	jmp    75ff8b <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x2b>
  760078:	lea    0x338e91(%rip),%rdx        # a98f10 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x7d8>
  76007f:	mov    $0x1,%edi
  760084:	mov    $0x1,%esi
  760089:	call   *0x358e41(%rip)        # ab8ed0 <_DYNAMIC+0x270>

canonical_text_public_control::query_selection bytes=1157 frame=200

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000760090 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection>:
  760090:	push   %rbp
  760091:	push   %r15
  760093:	push   %r14
  760095:	push   %r13
  760097:	push   %r12
  760099:	push   %rbx
  76009a:	sub    $0x98,%rsp
  7600a1:	mov    %rsi,%r14
  7600a4:	mov    %rdi,%rbx
  7600a7:	call   *0x358e73(%rip)        # ab8f20 <_DYNAMIC+0x2c0>
  7600ad:	test   %al,%al
  7600af:	je     7604e5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x455>
  7600b5:	mov    (%r14),%esi
  7600b8:	mov    0x8(%r14),%ecx
  7600bc:	mov    $0x1,%eax
  7600c1:	cmp    %esi,%ecx
  7600c3:	je     7604a4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x414>
  7600c9:	mov    %esi,%edx
  7600cb:	cmova  %ecx,%edx
  7600ce:	cmovb  %ecx,%esi
  7600d1:	mov    %rbx,%rdi
  7600d4:	call   *0x358e4e(%rip)        # ab8f28 <_DYNAMIC+0x2c8>
  7600da:	test   %rax,%rax
  7600dd:	je     7604d8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x448>
  7600e3:	mov    %rdx,%rcx
  7600e6:	movss  0x4c(%rbx),%xmm0
  7600eb:	mulss  -0x69dc9b(%rip),%xmm0        # c2458 <GCC_except_table0+0xf0>
  7600f3:	lea    0x10(%rsp),%rdi
  7600f8:	mov    %rbx,%rsi
  7600fb:	mov    %rax,%rdx
  7600fe:	call   *0x358e2c(%rip)        # ab8f30 <_DYNAMIC+0x2d0>
  760104:	mov    0x18(%rsp),%r10
  760109:	mov    0x20(%rsp),%rcx
  76010e:	mov    $0x1,%eax
  760113:	cmp    %r10,%rcx
  760116:	ja     7604a4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x414>
  76011c:	lea    0x28(%rsp),%rsi
  760121:	xor    %ebp,%ebp
  760123:	lea    0x60(%rsp),%rdi
  760128:	movabs $0x100000001b3,%r14
  760132:	mov    $0x1,%r15d
  760138:	test   $0x1,%bpl
  76013c:	je     7602eb <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x25b>
  760142:	cmp    $0x1,%rcx
  760146:	je     7604fe <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x46e>
  76014c:	mov    0x10(%rsp),%rdx
  760151:	mov    (%rdx),%r11d
  760154:	add    $0xc,%rdx
  760158:	jmp    760170 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0xe0>
  76015a:	nopw   0x0(%rax,%rax,1)
  760160:	dec    %r10
  760163:	add    $0xc,%rdx
  760167:	cmp    %r10,%rcx
  76016a:	ja     76046a <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x3da>
  760170:	mov    %r11d,%r8d
  760173:	mov    (%rdx),%r11d
  760176:	cmp    %r11d,%r8d
  760179:	je     760160 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0xd0>
  76017b:	testb  $0x2,-0x4(%rdx)
  76017f:	je     760160 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0xd0>
  760181:	testb  $0x1,0x8(%rdx)
  760185:	je     760160 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0xd0>
  760187:	movaps %xmm4,0x40(%rsp)
  76018c:	movss  %xmm8,0x8(%rsp)
  760193:	movaps %xmm5,0x50(%rsp)
  760198:	movss  %xmm6,0xc(%rsp)
  76019e:	mov    %r9,%rbx
  7601a1:	mov    %rax,%r12
  7601a4:	mov    %rdx,0x10(%rsp)
  7601a9:	dec    %r10
  7601ac:	mov    %r10,0x18(%rsp)
  7601b1:	add    $0xfffffffffffffff4,%rdx
  7601b5:	mov    %rdi,%r13
  7601b8:	mov    %rsi,%r14
  7601bb:	call   75d2b0 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control>
  7601c0:	xorps  %xmm0,%xmm0
  7601c3:	movss  0x78(%rsp),%xmm1
  7601c9:	ucomiss %xmm0,%xmm1
  7601cc:	jne    760202 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x172>
  7601ce:	jp     760202 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x172>
  7601d0:	mov    %r12,%rax
  7601d3:	mov    %rbx,%r9
  7601d6:	mov    %r14,%rsi
  7601d9:	mov    %r13,%rdi
  7601dc:	movabs $0x100000001b3,%r14
  7601e6:	movss  0xc(%rsp),%xmm6
  7601ec:	movaps 0x50(%rsp),%xmm5
  7601f1:	movss  0x8(%rsp),%xmm8
  7601f8:	movaps 0x40(%rsp),%xmm4
  7601fd:	jmp    7602d3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x243>
  760202:	movss  0x70(%rsp),%xmm0
  760208:	movss  0x74(%rsp),%xmm2
  76020e:	movss  0x7c(%rsp),%xmm3
  760214:	mov    0x80(%rsp),%rdx
  76021c:	mov    %rbx,%r9
  76021f:	cmp    %rdx,%rbx
  760222:	movss  0xc(%rsp),%xmm6
  760228:	movaps 0x50(%rsp),%xmm7
  76022d:	movss  0x8(%rsp),%xmm8
  760234:	movaps 0x40(%rsp),%xmm9
  76023a:	jne    760458 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x3c8>
  760240:	ucomiss %xmm2,%xmm8
  760244:	mov    %r14,%rsi
  760247:	mov    %r13,%rdi
  76024a:	movabs $0x100000001b3,%r14
  760254:	jne    7603f7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x367>
  76025a:	jp     7603f7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x367>
  760260:	ucomiss %xmm3,%xmm6
  760263:	jne    7603f7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x367>
  760269:	jp     7603f7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x367>
  76026f:	movaps %xmm0,%xmm5
  760272:	addss  %xmm1,%xmm5
  760276:	ucomiss %xmm9,%xmm5
  76027a:	jb     7603f4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x364>
  760280:	movaps %xmm7,%xmm4
  760283:	addss  %xmm9,%xmm4
  760288:	ucomiss %xmm0,%xmm4
  76028b:	jb     7603f4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x364>
  760291:	mov    %r12,%rax
  760294:	movaps %xmm4,%xmm1
  760297:	maxss  %xmm5,%xmm1
  76029b:	movaps %xmm1,%xmm5
  76029e:	cmpunordss %xmm1,%xmm5
  7602a3:	movaps %xmm5,%xmm2
  7602a6:	andnps %xmm1,%xmm2
  7602a9:	andps  %xmm4,%xmm5
  7602ac:	orps   %xmm2,%xmm5
  7602af:	movaps %xmm9,%xmm1
  7602b3:	minss  %xmm0,%xmm1
  7602b7:	movaps %xmm1,%xmm0
  7602ba:	cmpunordss %xmm1,%xmm0
  7602bf:	movaps %xmm0,%xmm2
  7602c2:	andnps %xmm1,%xmm2
  7602c5:	andps  %xmm9,%xmm0
  7602c9:	orps   %xmm2,%xmm0
  7602cc:	subss  %xmm0,%xmm5
  7602d0:	movaps %xmm0,%xmm4
  7602d3:	mov    0x18(%rsp),%r10
  7602d8:	mov    0x20(%rsp),%rcx
  7602dd:	cmp    %r10,%rcx
  7602e0:	jbe    760142 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0xb2>
  7602e6:	jmp    7604b6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x426>
  7602eb:	cmp    $0x1,%rcx
  7602ef:	je     7604fe <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x46e>
  7602f5:	mov    0x10(%rsp),%rdx
  7602fa:	mov    (%rdx),%r11d
  7602fd:	add    $0xc,%rdx
  760301:	jmp    760320 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x290>
  760303:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  760310:	dec    %r10
  760313:	add    $0xc,%rdx
  760317:	cmp    %r10,%rcx
  76031a:	ja     76046a <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x3da>
  760320:	mov    %r11d,%r8d
  760323:	mov    (%rdx),%r11d
  760326:	cmp    %r11d,%r8d
  760329:	je     760310 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x280>
  76032b:	testb  $0x2,-0x4(%rdx)
  76032f:	je     760310 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x280>
  760331:	testb  $0x1,0x8(%rdx)
  760335:	je     760310 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x280>
  760337:	movaps %xmm4,0x40(%rsp)
  76033c:	movss  %xmm8,0x8(%rsp)
  760343:	movaps %xmm5,0x50(%rsp)
  760348:	movss  %xmm6,0xc(%rsp)
  76034e:	mov    %r9,%rbx
  760351:	mov    %rax,%r12
  760354:	mov    %rdx,0x10(%rsp)
  760359:	dec    %r10
  76035c:	mov    %r10,0x18(%rsp)
  760361:	add    $0xfffffffffffffff4,%rdx
  760365:	mov    %rdi,%r13
  760368:	mov    %rsi,%r14
  76036b:	call   75d2b0 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control>
  760370:	xorps  %xmm0,%xmm0
  760373:	movss  0x78(%rsp),%xmm1
  760379:	ucomiss %xmm0,%xmm1
  76037c:	jne    7603c5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x335>
  76037e:	jp     7603c5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x335>
  760380:	mov    0x18(%rsp),%r10
  760385:	mov    0x20(%rsp),%rcx
  76038a:	cmp    %r10,%rcx
  76038d:	mov    %r12,%rax
  760390:	mov    %rbx,%r9
  760393:	mov    %r14,%rsi
  760396:	mov    %r13,%rdi
  760399:	movabs $0x100000001b3,%r14
  7603a3:	movss  0xc(%rsp),%xmm6
  7603a9:	movaps 0x50(%rsp),%xmm5
  7603ae:	movss  0x8(%rsp),%xmm8
  7603b5:	movaps 0x40(%rsp),%xmm4
  7603ba:	jbe    7602eb <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x25b>
  7603c0:	jmp    7604a4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x414>
  7603c5:	movss  0x70(%rsp),%xmm0
  7603cb:	movss  0x74(%rsp),%xmm2
  7603d1:	movss  0x7c(%rsp),%xmm3
  7603d7:	mov    0x80(%rsp),%rdx
  7603df:	mov    %r12,%rax
  7603e2:	mov    %r14,%rsi
  7603e5:	mov    %r13,%rdi
  7603e8:	movabs $0x100000001b3,%r14
  7603f2:	jmp    760430 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x3a0>
  7603f4:	mov    %r9,%rdx
  7603f7:	movd   %xmm9,%ecx
  7603fc:	movd   %xmm8,%r8d
  760401:	movd   %xmm7,%r10d
  760406:	movd   %xmm6,%eax
  76040a:	xor    %rcx,%r15
  76040d:	imul   %r14,%r15
  760411:	xor    %r15,%r8
  760414:	imul   %r14,%r8
  760418:	xor    %r8,%r10
  76041b:	imul   %r14,%r10
  76041f:	xor    %r10,%rax
  760422:	imul   %r14,%rax
  760426:	xor    %r9,%rax
  760429:	imul   %r14,%rax
  76042d:	mov    %rax,%r15
  760430:	mov    0x18(%rsp),%r10
  760435:	mov    0x20(%rsp),%rcx
  76043a:	mov    $0x1,%bpl
  76043d:	mov    %rdx,%r9
  760440:	movaps %xmm3,%xmm6
  760443:	movaps %xmm1,%xmm5
  760446:	movaps %xmm2,%xmm8
  76044a:	movaps %xmm0,%xmm4
  76044d:	cmp    %r10,%rcx
  760450:	jbe    760138 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0xa8>
  760456:	jmp    7604c6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x436>
  760458:	mov    %r14,%rsi
  76045b:	mov    %r13,%rdi
  76045e:	movabs $0x100000001b3,%r14
  760468:	jmp    7603f7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x367>
  76046a:	test   $0x1,%bpl
  76046e:	je     7604a4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x414>
  760470:	movd   %xmm4,%ecx
  760474:	movd   %xmm8,%edx
  760479:	movd   %xmm5,%esi
  76047d:	xor    %rax,%rcx
  760480:	movd   %xmm6,%eax
  760484:	imul   %r14,%rcx
  760488:	xor    %rcx,%rdx
  76048b:	imul   %r14,%rdx
  76048f:	xor    %rdx,%rsi
  760492:	imul   %r14,%rsi
  760496:	xor    %rsi,%rax
  760499:	imul   %r14,%rax
  76049d:	xor    %r9,%rax
  7604a0:	imul   %r14,%rax
  7604a4:	add    $0x98,%rsp
  7604ab:	pop    %rbx
  7604ac:	pop    %r12
  7604ae:	pop    %r13
  7604b0:	pop    %r14
  7604b2:	pop    %r15
  7604b4:	pop    %rbp
  7604b5:	ret
  7604b6:	movaps %xmm8,%xmm2
  7604ba:	movaps %xmm6,%xmm3
  7604bd:	mov    %r9,%rdx
  7604c0:	movaps %xmm4,%xmm0
  7604c3:	movaps %xmm5,%xmm1
  7604c6:	movaps %xmm1,%xmm5
  7604c9:	movaps %xmm0,%xmm4
  7604cc:	mov    %rdx,%r9
  7604cf:	movaps %xmm3,%xmm6
  7604d2:	movaps %xmm2,%xmm8
  7604d6:	jmp    760470 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x3e0>
  7604d8:	lea    0x3382a9(%rip),%rdi        # a98788 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x50>
  7604df:	call   *0x358a63(%rip)        # ab8f48 <_DYNAMIC+0x2e8>
  7604e5:	lea    -0x690ad8(%rip),%rdi        # cfa14 <GCC_except_table0+0xd6ac>
  7604ec:	lea    0x339135(%rip),%rdx        # a99628 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xef0>
  7604f3:	mov    $0x73,%esi
  7604f8:	call   *0x358a1a(%rip)        # ab8f18 <_DYNAMIC+0x2b8>
  7604fe:	lea    0x338a0b(%rip),%rdx        # a98f10 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x7d8>
  760505:	mov    $0x1,%edi
  76050a:	mov    $0x1,%esi
  76050f:	call   *0x3589bb(%rip)        # ab8ed0 <_DYNAMIC+0x270>

canonical_text_public_control::ack bytes=358 frame=136

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000760520 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack>:
  760520:	push   %r14
  760522:	push   %rbx
  760523:	sub    $0x78,%rsp
  760527:	test   %rsi,%rsi
  76052a:	je     7605d4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack+0xb4>
  760530:	cmpb   $0x0,0x76e(%rsi)
  760537:	jne    7605db <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack+0xbb>
  76053d:	mov    0x6d0(%rsi),%rdx
  760544:	test   %rdx,%rdx
  760547:	je     7605e2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack+0xc2>
  76054d:	mov    %rdi,%rbx
  760550:	mov    0x6d8(%rsi),%rcx
  760557:	lea    0x8(%rsp),%rdi
  76055c:	call   77ae10 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_>
  760561:	cmpq   $0xfffffffffffffffe,0x8(%rsp)
  760567:	jne    76061f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack+0xff>
  76056d:	movups 0x10(%rsp),%xmm0
  760572:	movups 0x20(%rsp),%xmm1
  760577:	movups 0x30(%rsp),%xmm2
  76057c:	movups %xmm2,0x20(%rbx)
  760580:	movups %xmm1,0x10(%rbx)
  760584:	movups %xmm0,(%rbx)
  760587:	cmpb   $0x0,0x28(%rbx)
  76058b:	je     76059f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack+0x7f>
  76058d:	mov    0x10(%rbx),%rax
  760591:	cmp    0x18(%rbx),%rax
  760595:	jne    7605b8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack+0x98>
  760597:	add    $0x78,%rsp
  76059b:	pop    %rbx
  76059c:	pop    %r14
  76059e:	ret
  76059f:	lea    -0x690b1f(%rip),%rdi        # cfa87 <GCC_except_table0+0xd71f>
  7605a6:	lea    0x3390c3(%rip),%rdx        # a99670 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xf38>
  7605ad:	mov    $0x2b,%esi
  7605b2:	call   *0x358960(%rip)        # ab8f18 <_DYNAMIC+0x2b8>
  7605b8:	lea    0x10(%rbx),%rsi
  7605bc:	add    $0x18,%rbx
  7605c0:	lea    0x3390c1(%rip),%r9        # a99688 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xf50>
  7605c7:	xor    %edi,%edi
  7605c9:	mov    %rbx,%rdx
  7605cc:	xor    %ecx,%ecx
  7605ce:	call   *0x358b4c(%rip)        # ab9120 <_DYNAMIC+0x4c0>
  7605d4:	mov    $0xd,%eax
  7605d9:	jmp    7605e7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack+0xc7>
  7605db:	mov    $0xe,%eax
  7605e0:	jmp    7605e7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack+0xc7>
  7605e2:	mov    $0x14,%eax
  7605e7:	mov    %rax,0x40(%rsp)
  7605ec:	movq   $0x0,0x48(%rsp)
  7605f5:	lea    -0x690a1a(%rip),%rdi        # cfbe2 <GCC_except_table0+0xd87a>
  7605fc:	lea    0x339395(%rip),%rcx        # a99998 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1260>
  760603:	lea    0x339036(%rip),%r8        # a99640 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xf08>
  76060a:	lea    0x40(%rsp),%rbx
  76060f:	mov    $0x2b,%esi
  760614:	mov    %rbx,%rdx
  760617:	call   *0x358953(%rip)        # ab8f70 <_DYNAMIC+0x310>
  76061d:	jmp    76066f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack+0x14f>
  76061f:	mov    0x38(%rsp),%rax
  760624:	mov    %rax,0x70(%rsp)
  760629:	movups 0x8(%rsp),%xmm0
  76062e:	movups 0x18(%rsp),%xmm1
  760633:	movups 0x28(%rsp),%xmm2
  760638:	movaps %xmm2,0x60(%rsp)
  76063d:	movaps %xmm1,0x50(%rsp)
  760642:	movaps %xmm0,0x40(%rsp)
  760647:	lea    -0x690a6c(%rip),%rdi        # cfbe2 <GCC_except_table0+0xd87a>
  76064e:	lea    0x339343(%rip),%rcx        # a99998 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1260>
  760655:	lea    0x338ffc(%rip),%r8        # a99658 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xf20>
  76065c:	lea    0x40(%rsp),%rbx
  760661:	mov    $0x2b,%esi
  760666:	mov    %rbx,%rdx
  760669:	call   *0x358901(%rip)        # ab8f70 <_DYNAMIC+0x310>
  76066f:	ud2
  760671:	jmp    760673 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack+0x153>
  760673:	mov    %rax,%r14
  760676:	mov    %rbx,%rdi
  760679:	call   74d540 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  76067e:	mov    %r14,%rdi
  760681:	call   a97380 <_Unwind_Resume@plt>

canonical_text_public_control::run bytes=8994 frame=872

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000760690 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run>:
  760690:	push   %rbp
  760691:	push   %r15
  760693:	push   %r14
  760695:	push   %r13
  760697:	push   %r12
  760699:	push   %rbx
  76069a:	sub    $0x338,%rsp
  7606a1:	mov    %rsi,0x2a0(%rsp)
  7606a9:	mov    %rdx,0x2a8(%rsp)
  7606b1:	mov    %rcx,0x278(%rsp)
  7606b9:	mov    %r8,0x280(%rsp)
  7606c1:	test   %r9,%r9
  7606c4:	je     762109 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1a79>
  7606ca:	mov    %r9,%r15
  7606cd:	mov    %rdx,%rbp
  7606d0:	mov    %rsi,%r13
  7606d3:	mov    %rdi,%r14
  7606d6:	lea    0x248(%rsp),%rbx
  7606de:	mov    %rbx,%rdi
  7606e1:	call   7657f0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source>
  7606e6:	lea    0x148(%rsp),%r12
  7606ee:	mov    %r12,%rdi
  7606f1:	mov    %rbx,%rsi
  7606f4:	call   *0x358a2e(%rip)        # ab9128 <_DYNAMIC+0x4c8>
  7606fa:	cmpq   $0x0,0x258(%rsp)
  760703:	je     7607a5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x115>
  760709:	mov    0x250(%rsp),%rcx
  760711:	movzbl (%rcx),%edi
  760714:	mov    $0x1,%esi
  760719:	test   %dil,%dil
  76071c:	js     7618a3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1213>
  760722:	mov    0x158(%rsp),%rdx
  76072a:	mov    %rdx,%rax
  76072d:	sub    %rsi,%rax
  760730:	jb     7621bd <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1b2d>
  760736:	mov    0x150(%rsp),%rcx
  76073e:	jbe    76074a <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xba>
  760740:	cmpb   $0xc0,(%rcx,%rsi,1)
  760744:	jl     7621f6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1b66>
  76074a:	movq   $0x0,0x158(%rsp)
  760756:	mov    %rcx,0x70(%rsp)
  76075b:	add    %rsi,%rcx
  76075e:	mov    %rcx,0x78(%rsp)
  760763:	mov    %r12,0x80(%rsp)
  76076b:	mov    %rsi,0x88(%rsp)
  760773:	mov    %rax,0x90(%rsp)
  76077b:	lea    -0x690cb5(%rip),%rax        # cfacd <GCC_except_table0+0xd765>
  760782:	mov    %rax,0x98(%rsp)
  76078a:	lea    -0x690cc3(%rip),%rax        # cface <GCC_except_table0+0xd766>
  760791:	mov    %rax,0xa0(%rsp)
  760799:	lea    0x70(%rsp),%rdi
  76079e:	call   748e30 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtCscdodAO9FK5_5alloc3vec6splice6SpliceNtNtNtB4_3str4iter5BytesEECs9C2G9YFESsD_29canonical_text_public_control>
  7607a3:	jmp    7607d2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x142>
  7607a5:	mov    0x158(%rsp),%rbx
  7607ad:	cmp    %rbx,0x148(%rsp)
  7607b5:	je     7621d1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1b41>
  7607bb:	mov    0x150(%rsp),%rax
  7607c3:	movb   $0x62,(%rax,%rbx,1)
  7607c7:	inc    %rbx
  7607ca:	mov    %rbx,0x158(%rsp)
  7607d2:	lea    0x260(%rsp),%rdi
  7607da:	lea    0x248(%rsp),%rsi
  7607e2:	call   *0x358940(%rip)        # ab9128 <_DYNAMIC+0x4c8>
  7607e8:	mov    %rbp,0x128(%rsp)
  7607f0:	mov    %r13,0x100(%rsp)
  7607f8:	mov    %r15,0x138(%rsp)
  760800:	mov    %r14,0x288(%rsp)
  760808:	mov    $0x1,%bpl
  76080b:	lea    0x70(%rsp),%rdi
  760810:	call   *0x35891a(%rip)        # ab9130 <_DYNAMIC+0x4d0>
  760816:	cmpl   $0x1,0x70(%rsp)
  76081b:	je     762122 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1a92>
  760821:	mov    0x78(%rsp),%rax
  760826:	mov    %rax,0x140(%rsp)
  76082e:	lea    0x140(%rsp),%rax
  760836:	mov    %rax,0x30(%rsp)
  76083b:	movq   $0x0,0x38(%rsp)
  760844:	mov    0x250(%rsp),%rdx
  76084c:	mov    0x258(%rsp),%rcx
  760854:	lea    0x70(%rsp),%rdi
  760859:	lea    0x30(%rsp),%rsi
  76085e:	movss  -0x69e40a(%rip),%xmm0        # c245c <GCC_except_table0+0xf4>
  760866:	movss  -0x69e432(%rip),%xmm1        # c243c <GCC_except_table0+0xd4>
  76086e:	mov    $0x1,%r8d
  760874:	call   *0x3588be(%rip)        # ab9138 <_DYNAMIC+0x4d8>
  76087a:	cmpq   $0xffffffffffffffff,0x70(%rsp)
  760880:	je     762156 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1ac6>
  760886:	mov    0xa0(%rsp),%rax
  76088e:	mov    %rax,0x330(%rsp)
  760896:	movups 0x70(%rsp),%xmm0
  76089b:	movups 0x80(%rsp),%xmm1
  7608a3:	movups 0x90(%rsp),%xmm2
  7608ab:	movaps %xmm2,0x320(%rsp)
  7608b3:	movaps %xmm1,0x310(%rsp)
  7608bb:	movaps %xmm0,0x300(%rsp)
  7608c3:	mov    0x38(%rsp),%rdi
  7608c8:	call   74cab0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text10TextShaperECs9C2G9YFESsD_29canonical_text_public_control>
  7608cd:	mov    0x320(%rsp),%rbx
  7608d5:	test   %rbx,%rbx
  7608d8:	je     762190 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1b00>
  7608de:	add    $0x10,%rbx
  7608e2:	lea    0x200(%rsp),%rdi
  7608ea:	mov    %rbx,%rsi
  7608ed:	call   *0x358825(%rip)        # ab9118 <_DYNAMIC+0x4b8>
  7608f3:	mov    0x208(%rsp),%rax
  7608fb:	mov    0x210(%rsp),%rcx
  760903:	cmp    %rax,%rcx
  760906:	mov    %rbx,0x110(%rsp)
  76090e:	jbe    760dcb <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x73b>
  760914:	mov    $0x4,%eax
  760919:	mov    %rax,0xf8(%rsp)
  760921:	mov    $0x8,%r12d
  760927:	xor    %r15d,%r15d
  76092a:	movq   $0x0,(%rsp)
  760932:	mov    %r12,0x130(%rsp)
  76093a:	lea    0x248(%rsp),%rdi
  760942:	mov    %r15,0x1a8(%rsp)
  76094a:	call   764cf0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount>
  76094f:	mov    %rax,%rbx
  760952:	mov    %rax,0x18(%rsp)
  760957:	cmpb   $0x0,0x76e(%rax)
  76095e:	jne    76249c <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1e0c>
  760964:	cmpb   $0x1,0x76a(%rbx)
  76096b:	jne    7624a3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1e13>
  760971:	mov    0x5c0(%rbx),%r12
  760978:	mov    $0x1a,%eax
  76097d:	mov    %rax,0x8(%rsp)
  760982:	test   %r12,%r12
  760985:	je     7624ad <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1e1d>
  76098b:	mov    0x5b8(%rbx),%r13
  760992:	shl    $0x6,%r12
  760996:	lea    0x1e8(%rbx),%r14
  76099d:	xor    %ebp,%ebp
  76099f:	mov    0x3585ba(%rip),%r15        # ab8f60 <_DYNAMIC+0x300>
  7609a6:	jmp    7609bd <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x32d>
  7609a8:	nopl   0x0(%rax,%rax,1)
  7609b0:	add    $0x40,%rbp
  7609b4:	cmp    %rbp,%r12
  7609b7:	je     7624ad <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1e1d>
  7609bd:	cmpb   $0x4,0x3d(%r13,%rbp,1)
  7609c3:	jne    7609b0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x320>
  7609c5:	mov    0x20(%r13,%rbp,1),%rsi
  7609ca:	mov    %r14,%rdi
  7609cd:	call   *%r15
  7609d0:	test   %al,%al
  7609d2:	je     7609b0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x320>
  7609d4:	mov    0x20(%r13,%rbp,1),%rsi
  7609d9:	add    $0x5f0,%rbx
  7609e0:	mov    %rbx,%rdi
  7609e3:	call   *0x358717(%rip)        # ab9100 <_DYNAMIC+0x4a0>
  7609e9:	mov    0x18(%rsp),%rsi
  7609ee:	movq   $0x0,0x1e8(%rsp)
  7609fa:	movq   $0x4,0x1f0(%rsp)
  760a06:	movq   $0x0,0x1f8(%rsp)
  760a12:	test   %rsi,%rsi
  760a15:	mov    (%rsp),%r15
  760a19:	je     7624e1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1e51>
  760a1f:	cmpb   $0x0,0x76e(%rsi)
  760a26:	jne    7624e8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1e58>
  760a2c:	cmpb   $0x1,0x76c(%rsi)
  760a33:	jne    7624ef <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1e5f>
  760a39:	mov    %rax,%rbx
  760a3c:	mov    %rdx,%r14
  760a3f:	lea    0x70(%rsp),%rdi
  760a44:	call   73dc40 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime5queryNtB3_7Context3newNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEBX_>
  760a49:	mov    %r14,0x118(%rsp)
  760a51:	mov    %rbx,0x120(%rsp)
  760a59:	mov    0xa8(%rsp),%r14
  760a61:	mov    $0x4,%eax
  760a66:	test   %r14,%r14
  760a69:	je     761011 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x981>
  760a6f:	mov    %rax,0x108(%rsp)
  760a77:	movq   $0x0,0x28(%rsp)
  760a80:	lea    0x3381e9(%rip),%rax        # a98c70 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x538>
  760a87:	mov    %rax,0x10(%rsp)
  760a8c:	xor    %ebp,%ebp
  760a8e:	mov    %r14,0x8(%rsp)
  760a93:	jmp    760abe <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x42e>
  760a95:	data16 cs nopw 0x0(%rax,%rax,1)
  760aa0:	test   %r14,%r14
  760aa3:	jne    7623b5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1d25>
  760aa9:	mov    (%rsp),%r15
  760aad:	mov    0x8(%rsp),%r14
  760ab2:	inc    %rbp
  760ab5:	cmp    %r14,%rbp
  760ab8:	je     760dac <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x71c>
  760abe:	mov    0xa8(%rsp),%rsi
  760ac6:	cmp    %rsi,%rbp
  760ac9:	jae    7623cb <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1d3b>
  760acf:	mov    0xa0(%rsp),%rax
  760ad7:	mov    %rbp,%rcx
  760ada:	shl    $0x6,%rcx
  760ade:	cmpb   $0x4,0x3d(%rax,%rcx,1)
  760ae3:	jne    760ab2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x422>
  760ae5:	lea    0x30(%rsp),%rdi
  760aea:	lea    0x70(%rsp),%rsi
  760aef:	mov    %rbp,%rdx
  760af2:	call   *0x3585b0(%rip)        # ab90a8 <_DYNAMIC+0x448>
  760af8:	cmpq   $0x0,0x30(%rsp)
  760afe:	je     7620e0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1a50>
  760b04:	movups 0x30(%rsp),%xmm0
  760b09:	movaps %xmm0,0x290(%rsp)
  760b11:	mov    0x40(%rsp),%rbx
  760b16:	mov    0x48(%rsp),%r13
  760b1b:	lea    0x200(%rsp),%rdi
  760b23:	mov    %rbx,%rsi
  760b26:	call   *0x3585ec(%rip)        # ab9118 <_DYNAMIC+0x4b8>
  760b2c:	movups 0x200(%rsp),%xmm0
  760b34:	movups 0x210(%rsp),%xmm1
  760b3c:	movups 0x220(%rsp),%xmm2
  760b44:	movaps %xmm1,0x170(%rsp)
  760b4c:	movaps %xmm0,0x160(%rsp)
  760b54:	movaps %xmm2,0x180(%rsp)
  760b5c:	mov    0x170(%rsp),%r15
  760b64:	mov    0x168(%rsp),%r14
  760b6c:	cmp    $0x1,%r15
  760b70:	je     760aa0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x410>
  760b76:	mov    0x160(%rsp),%r12
  760b7e:	mov    $0x2,%eax
  760b83:	dec    %rax
  760b86:	mov    %rax,0x190(%rsp)
  760b8e:	cmp    %r14,%r15
  760b91:	ja     760aa9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x419>
  760b97:	add    $0xc,%r12
  760b9b:	jmp    760bb0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x520>
  760b9d:	nopl   (%rax)
  760ba0:	dec    %r14
  760ba3:	add    $0xc,%r12
  760ba7:	cmp    %r14,%r15
  760baa:	ja     760aa9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x419>
  760bb0:	mov    -0xc(%r12),%eax
  760bb5:	cmp    (%r12),%eax
  760bb9:	je     760ba0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x510>
  760bbb:	testb  $0x2,-0x4(%r12)
  760bc1:	je     760ba0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x510>
  760bc3:	testb  $0x1,0x8(%r12)
  760bc9:	je     760ba0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x510>
  760bcb:	lea    -0xc(%r12),%rdx
  760bd0:	lea    0x30(%rsp),%rdi
  760bd5:	lea    0x178(%rsp),%rsi
  760bdd:	mov    %r15,%rcx
  760be0:	call   75d2b0 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control>
  760be5:	cmpb   $0x1,0x60(%rsp)
  760bea:	je     760ba0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x510>
  760bec:	movzbl 0x34(%rsp),%eax
  760bf1:	lea    0x35(%rsp),%rcx
  760bf6:	movups (%rcx),%xmm0
  760bf9:	movups 0x10(%rcx),%xmm1
  760bfd:	movups 0x1b(%rcx),%xmm2
  760c01:	movaps %xmm0,0x1b0(%rsp)
  760c09:	movaps %xmm1,0x1c0(%rsp)
  760c11:	movups %xmm2,0x1cb(%rsp)
  760c19:	cmp    $0x2,%al
  760c1b:	je     760ba0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x510>
  760c1d:	movups 0x1cb(%rsp),%xmm0
  760c25:	movups %xmm0,0x2eb(%rsp)
  760c2d:	movaps 0x1b0(%rsp),%xmm0
  760c35:	movaps 0x1c0(%rsp),%xmm1
  760c3d:	movaps %xmm1,0x2e0(%rsp)
  760c45:	movaps %xmm0,0x2d0(%rsp)
  760c4d:	lea    0x2d8(%rsp),%rax
  760c55:	movups (%rax),%xmm0
  760c58:	movaps %xmm0,0x2b0(%rsp)
  760c60:	mov    0xf(%rax),%eax
  760c63:	mov    %eax,0x2bf(%rsp)
  760c6a:	lea    0x2b3(%rsp),%rax
  760c72:	movups (%rax),%xmm0
  760c75:	movaps %xmm0,0x2d0(%rsp)
  760c7d:	movaps 0x290(%rsp),%xmm0
  760c85:	movaps %xmm0,0x30(%rsp)
  760c8a:	mov    %rbx,0x40(%rsp)
  760c8f:	mov    %r13,0x48(%rsp)
  760c94:	lea    0x1b0(%rsp),%rdi
  760c9c:	lea    0x30(%rsp),%rsi
  760ca1:	lea    0x2d0(%rsp),%rdx
  760ca9:	call   *0x358491(%rip)        # ab9140 <_DYNAMIC+0x4e0>
  760caf:	cmpb   $0x0,0x1b0(%rsp)
  760cb7:	je     762214 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1b84>
  760cbd:	movsd  0x1b4(%rsp),%xmm1
  760cc6:	movsd  0x1bc(%rsp),%xmm0
  760ccf:	mulps  -0x69d686(%rip),%xmm0        # c3650 <GCC_except_table0+0x12e8>
  760cd6:	addps  %xmm1,%xmm0
  760cd9:	movaps %xmm0,%xmm1
  760cdc:	shufps $0x55,%xmm0,%xmm1
  760ce0:	movaps 0x290(%rsp),%xmm2
  760ce8:	movaps %xmm2,0x30(%rsp)
  760ced:	mov    %rbx,0x40(%rsp)
  760cf2:	mov    %r13,0x48(%rsp)
  760cf7:	lea    0x30(%rsp),%rdi
  760cfc:	movaps %xmm0,0x230(%rsp)
  760d04:	call   *0x35843e(%rip)        # ab9148 <_DYNAMIC+0x4e8>
  760d0a:	mov    %eax,0x1a0(%rsp)
  760d11:	mov    %dl,0x27(%rsp)
  760d15:	cmp    $0x2,%dl
  760d18:	je     762224 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1b94>
  760d1e:	mov    0x28(%rsp),%rax
  760d23:	cmp    0x1e8(%rsp),%rax
  760d2b:	jne    760d4a <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x6ba>
  760d2d:	lea    0x1e8(%rsp),%rdi
  760d35:	call   771d90 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtCscO85OU7Wpt0_20gpui_reactivity_core8geometry4RectE8grow_oneCs9C2G9YFESsD_29canonical_text_public_control>
  760d3a:	mov    0x1f0(%rsp),%rax
  760d42:	mov    %rax,0x108(%rsp)
  760d4a:	dec    %r14
  760d4d:	movzbl 0x27(%rsp),%esi
  760d52:	and    $0x1,%sil
  760d56:	mov    0x28(%rsp),%rcx
  760d5b:	mov    %rcx,%rax
  760d5e:	shl    $0x4,%rax
  760d62:	mov    0x108(%rsp),%rdx
  760d6a:	movaps 0x230(%rsp),%xmm0
  760d72:	movlps %xmm0,(%rdx,%rax,1)
  760d76:	mov    0x1a0(%rsp),%edi
  760d7d:	mov    %edi,0x8(%rdx,%rax,1)
  760d81:	mov    %sil,0xc(%rdx,%rax,1)
  760d86:	inc    %rcx
  760d89:	mov    %rcx,0x28(%rsp)
  760d8e:	mov    %rcx,0x1f8(%rsp)
  760d96:	mov    0x190(%rsp),%rax
  760d9e:	test   %rax,%rax
  760da1:	jne    760b83 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x4f3>
  760da7:	jmp    760aa9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x419>
  760dac:	mov    0x1e8(%rsp),%rax
  760db4:	mov    %rax,0x10(%rsp)
  760db9:	mov    0x1f0(%rsp),%rax
  760dc1:	mov    %rax,0x8(%rsp)
  760dc6:	jmp    761028 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x998>
  760dcb:	cmp    $0x1,%rcx
  760dcf:	je     762538 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1ea8>
  760dd5:	mov    0x200(%rsp),%rdx
  760ddd:	mov    (%rdx),%esi
  760ddf:	add    $0xc,%rdx
  760de3:	jmp    760e00 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x770>
  760de5:	data16 cs nopw 0x0(%rax,%rax,1)
  760df0:	dec    %rax
  760df3:	add    $0xc,%rdx
  760df7:	cmp    %rax,%rcx
  760dfa:	ja     760914 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x284>
  760e00:	mov    %esi,%edi
  760e02:	mov    (%rdx),%esi
  760e04:	cmp    %esi,%edi
  760e06:	je     760df0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x760>
  760e08:	testb  $0x2,-0x4(%rdx)
  760e0c:	je     760df0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x760>
  760e0e:	testb  $0x1,0x8(%rdx)
  760e12:	je     760df0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x760>
  760e14:	mov    %rdx,0x200(%rsp)
  760e1c:	dec    %rax
  760e1f:	mov    %rax,0x208(%rsp)
  760e27:	lea    0x218(%rsp),%rsi
  760e2f:	add    $0xfffffffffffffff4,%rdx
  760e33:	lea    0x30(%rsp),%rdi
  760e38:	call   75d2b0 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control>
  760e3d:	cmpb   $0x2,0x34(%rsp)
  760e42:	je     760914 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x284>
  760e48:	call   *0x35805a(%rip)        # ab8ea8 <_DYNAMIC+0x248>
  760e4e:	mov    $0xe0,%edi
  760e53:	mov    $0x8,%esi
  760e58:	call   *0x358052(%rip)        # ab8eb0 <_DYNAMIC+0x250>
  760e5e:	test   %rax,%rax
  760e61:	je     76264f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1fbf>
  760e67:	mov    %rax,%r12
  760e6a:	mov    0x60(%rsp),%rax
  760e6f:	mov    %rax,0x30(%r12)
  760e74:	movups 0x30(%rsp),%xmm0
  760e79:	movups 0x40(%rsp),%xmm1
  760e7e:	movups 0x50(%rsp),%xmm2
  760e83:	movups %xmm2,0x20(%r12)
  760e89:	movups %xmm1,0x10(%r12)
  760e8f:	movups %xmm0,(%r12)
  760e94:	movq   $0x4,0x1b0(%rsp)
  760ea0:	mov    %r12,0x1b8(%rsp)
  760ea8:	movq   $0x1,0x1c0(%rsp)
  760eb4:	movups 0x200(%rsp),%xmm0
  760ebc:	movups 0x210(%rsp),%xmm1
  760ec4:	movups 0x220(%rsp),%xmm2
  760ecc:	movaps %xmm2,0x180(%rsp)
  760ed4:	movaps %xmm1,0x170(%rsp)
  760edc:	movaps %xmm0,0x160(%rsp)
  760ee4:	mov    0x170(%rsp),%rcx
  760eec:	mov    0x168(%rsp),%rax
  760ef4:	mov    $0x1,%edx
  760ef9:	mov    %rdx,(%rsp)
  760efd:	cmp    %rax,%rcx
  760f00:	jbe    761f37 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x18a7>
  760f06:	mov    0x1b0(%rsp),%r15
  760f0e:	mov    (%rsp),%r14
  760f12:	lea    0x0(,%r14,4),%rbx
  760f1a:	call   *0x357f88(%rip)        # ab8ea8 <_DYNAMIC+0x248>
  760f20:	mov    $0x4,%esi
  760f25:	mov    %rbx,%rdi
  760f28:	call   *0x357f82(%rip)        # ab8eb0 <_DYNAMIC+0x250>
  760f2e:	mov    %rax,0xf8(%rsp)
  760f36:	test   %rax,%rax
  760f39:	je     762661 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1fd1>
  760f3f:	cmp    $0x14,%r14
  760f43:	jb     760f6e <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x8de>
  760f45:	imul   $0x38,%r14,%rax
  760f49:	add    %r12,%rax
  760f4c:	add    $0xffffffffffffffcc,%rax
  760f50:	mov    0xf8(%rsp),%rsi
  760f58:	cmp    %rax,%rsi
  760f5b:	jae    762057 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x19c7>
  760f61:	lea    (%rsi,%r14,4),%rax
  760f65:	cmp    %rax,%r12
  760f68:	jae    762057 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x19c7>
  760f6e:	xor    %eax,%eax
  760f70:	mov    (%rsp),%rdx
  760f74:	mov    %rax,%rcx
  760f77:	and    $0x3,%rdx
  760f7b:	mov    0xf8(%rsp),%r9
  760f83:	je     760fb4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x924>
  760f85:	imul   $0x38,%rax,%rsi
  760f89:	add    %r12,%rsi
  760f8c:	lea    (%rdx,%rdx,1),%rcx
  760f90:	shl    $0x4,%edx
  760f93:	sub    %rcx,%rdx
  760f96:	xor    %edi,%edi
  760f98:	mov    %rax,%rcx
  760f9b:	nopl   0x0(%rax,%rax,1)
  760fa0:	mov    (%rsi,%rdi,4),%r8d
  760fa4:	mov    %r8d,(%r9,%rcx,4)
  760fa8:	inc    %rcx
  760fab:	add    $0xe,%rdi
  760faf:	cmp    %rdi,%rdx
  760fb2:	jne    760fa0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x910>
  760fb4:	sub    (%rsp),%rax
  760fb8:	cmp    $0xfffffffffffffffc,%rax
  760fbc:	ja     760932 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2a2>
  760fc2:	imul   $0x38,%rcx,%rax
  760fc6:	add    %r12,%rax
  760fc9:	mov    (%rsp),%rsi
  760fcd:	mov    0xf8(%rsp),%rdi
  760fd5:	data16 cs nopw 0x0(%rax,%rax,1)
  760fe0:	mov    (%rax),%edx
  760fe2:	mov    %edx,(%rdi,%rcx,4)
  760fe5:	mov    0x38(%rax),%edx
  760fe8:	mov    %edx,0x4(%rdi,%rcx,4)
  760fec:	mov    0x70(%rax),%edx
  760fef:	mov    %edx,0x8(%rdi,%rcx,4)
  760ff3:	mov    0xa8(%rax),%edx
  760ff9:	mov    %edx,0xc(%rdi,%rcx,4)
  760ffd:	add    $0x4,%rcx
  761001:	add    $0xe0,%rax
  761007:	cmp    %rcx,%rsi
  76100a:	jne    760fe0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x950>
  76100c:	jmp    760932 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2a2>
  761011:	mov    %rax,0x8(%rsp)
  761016:	movq   $0x0,0x28(%rsp)
  76101f:	movq   $0x0,0x10(%rsp)
  761028:	mov    $0xffffffff,%eax
  76102d:	mov    %rax,0x200(%rsp)
  761035:	movq   $0x0,0x208(%rsp)
  761041:	mov    0x110(%rsp),%rdi
  761049:	xor    %esi,%esi
  76104b:	mov    $0x1,%edx
  761050:	call   *0x3580b2(%rip)        # ab9108 <_DYNAMIC+0x4a8>
  761056:	mov    %edx,%ebp
  761058:	cmp    $0x2,%dl
  76105b:	je     7621a2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1b12>
  761061:	test   %eax,%eax
  761063:	sete   0x108(%rsp)
  76106b:	mov    0x278(%rsp),%r13
  761073:	mov    0x280(%rsp),%r14
  76107b:	cmp    $0x4,%r14
  76107f:	je     761188 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xaf8>
  761085:	cmp    $0x5,%r14
  761089:	jne    761246 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xbb6>
  76108f:	mov    $0x6f727261,%eax
  761094:	xor    0x0(%r13),%eax
  761098:	movzbl 0x4(%r13),%ecx
  76109d:	xor    $0x77,%ecx
  7610a0:	or     %eax,%ecx
  7610a2:	jne    761133 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xaa3>
  7610a8:	cmpq   $0x5,0x128(%rsp)
  7610b1:	jne    7610d1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xa41>
  7610b3:	mov    $0x74706d65,%eax
  7610b8:	mov    0x100(%rsp),%rcx
  7610c0:	xor    (%rcx),%eax
  7610c2:	movzbl 0x4(%rcx),%ecx
  7610c6:	xor    $0x79,%ecx
  7610c9:	or     %eax,%ecx
  7610cb:	je     762367 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1cd7>
  7610d1:	movl   $0x0,0x70(%rsp)
  7610d9:	movb   $0x1,0x74(%rsp)
  7610de:	movl   $0x0,0x78(%rsp)
  7610e6:	movb   $0x1,0x7c(%rsp)
  7610eb:	mov    0x18(%rsp),%rsi
  7610f0:	test   %rsi,%rsi
  7610f3:	je     762590 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1f00>
  7610f9:	lea    0x30(%rsp),%rdi
  7610fe:	lea    0x70(%rsp),%r8
  761103:	mov    0x120(%rsp),%rdx
  76110b:	mov    0x118(%rsp),%rcx
  761113:	call   76ef20 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE12select_inputB12_>
  761118:	cmpq   $0xfffffffffffffffe,0x30(%rsp)
  76111e:	jne    7625a2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1f12>
  761124:	mov    0x18(%rsp),%rsi
  761129:	lea    0x70(%rsp),%rdi
  76112e:	call   760520 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack>
  761133:	movl   $0x0,0x100(%rsp)
  76113e:	mov    0x18(%rsp),%rax
  761143:	test   %rax,%rax
  761146:	jne    76125f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xbcf>
  76114c:	movq   $0xd,0x70(%rsp)
  761155:	movq   $0x0,0x78(%rsp)
  76115e:	lea    -0x691583(%rip),%rdi        # cfbe2 <GCC_except_table0+0xd87a>
  761165:	lea    0x33882c(%rip),%rcx        # a99998 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1260>
  76116c:	lea    0x338615(%rip),%r8        # a99788 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1050>
  761173:	lea    0x70(%rsp),%rdx
  761178:	mov    $0x2b,%esi
  76117d:	call   *0x357ded(%rip)        # ab8f70 <_DYNAMIC+0x310>
  761183:	jmp    762698 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2008>
  761188:	mov    $0x1,%al
  76118a:	mov    %eax,0x100(%rsp)
  761191:	cmpl   $0x67617264,0x0(%r13)
  761199:	jne    761251 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xbc1>
  76119f:	mov    0x28(%rsp),%rax
  7611a4:	mov    %rax,0x70(%rsp)
  7611a9:	cmp    $0x2,%rax
  7611ad:	jne    762234 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1ba4>
  7611b3:	mov    0x8(%rsp),%rcx
  7611b8:	mov    0x8(%rcx),%eax
  7611bb:	cmp    0x18(%rcx),%eax
  7611be:	jne    7611cd <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xb3d>
  7611c0:	movzbl 0xc(%rcx),%eax
  7611c4:	cmp    0x1c(%rcx),%al
  7611c7:	je     762379 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1ce9>
  7611cd:	movsd  (%rcx),%xmm0
  7611d1:	movsd  %xmm0,0x74(%rsp)
  7611d7:	movl   $0x0,0x70(%rsp)
  7611df:	lea    0x30(%rsp),%rdi
  7611e4:	lea    0x18(%rsp),%rsi
  7611e9:	lea    0x200(%rsp),%rdx
  7611f1:	lea    0x70(%rsp),%rcx
  7611f6:	call   76cd00 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_>
  7611fb:	cmpl   $0xfffffffe,0x30(%rsp)
  761200:	jne    762256 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1bc6>
  761206:	movl   $0x2,0x70(%rsp)
  76120e:	lea    0x30(%rsp),%rdi
  761213:	lea    0x18(%rsp),%rsi
  761218:	lea    0x200(%rsp),%rdx
  761220:	lea    0x70(%rsp),%rcx
  761225:	call   76cd00 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_>
  76122a:	cmpl   $0xfffffffe,0x30(%rsp)
  76122f:	jne    7622b1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1c21>
  761235:	mov    0x18(%rsp),%rsi
  76123a:	lea    0x70(%rsp),%rdi
  76123f:	call   760520 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack>
  761244:	jmp    761251 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xbc1>
  761246:	movl   $0x0,0x100(%rsp)
  761251:	mov    0x18(%rsp),%rax
  761256:	test   %rax,%rax
  761259:	je     76114c <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xabc>
  76125f:	xorps  %xmm0,%xmm0
  761262:	movups %xmm0,0x740(%rax)
  761269:	movups %xmm0,0x730(%rax)
  761270:	movups %xmm0,0x720(%rax)
  761277:	movups %xmm0,0x710(%rax)
  76127e:	movups %xmm0,0x700(%rax)
  761285:	movups %xmm0,0x6f0(%rax)
  76128c:	movq   $0x0,0x750(%rax)
  761297:	cmpb   $0x0,0x370(%rsp)
  76129f:	je     7612b8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xc28>
  7612a1:	call   *0x357ea9(%rip)        # ab9150 <_DYNAMIC+0x4f0>
  7612a7:	mov    %rax,0x1a0(%rsp)
  7612af:	mov    %edx,0x118(%rsp)
  7612b6:	jmp    7612c3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xc33>
  7612b8:	movl   $0xffffffff,0x118(%rsp)
  7612c3:	mov    (%rsp),%rbx
  7612c7:	cmp    $0x1,%rbx
  7612cb:	adc    $0x0,%rbx
  7612cf:	mov    0x28(%rsp),%rax
  7612d4:	cmp    $0x1,%rax
  7612d8:	adc    $0x0,%rax
  7612dc:	mov    %rax,0x128(%rsp)
  7612e4:	mov    %r14,0x120(%rsp)
  7612ec:	lea    -0x3(%r14),%r15
  7612f0:	cmp    $0x7,%r15
  7612f4:	setb   %al
  7612f7:	mov    $0x5f,%dl
  7612f9:	mov    %r15d,%ecx
  7612fc:	shr    %cl,%dl
  7612fe:	and    %al,%dl
  761300:	cmp    $0x1,%dl
  761303:	je     76133c <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xcac>
  761305:	lea    0x278(%rsp),%rax
  76130d:	mov    %rax,0x70(%rsp)
  761312:	lea    0x34d07(%rip),%rax        # 796020 <_RNvXs1i_NtCs4NRVxsYgnAr_4core3fmtReNtB6_7Display3fmtCs9C2G9YFESsD_29canonical_text_public_control>
  761319:	mov    %rax,0x78(%rsp)
  76131e:	lea    -0x697a22(%rip),%rdi        # c9903 <GCC_except_table0+0x759b>
  761325:	lea    0x3384d4(%rip),%rdx        # a99800 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x10c8>
  76132c:	lea    0x70(%rsp),%rsi
  761331:	call   *0x357ba1(%rip)        # ab8ed8 <_DYNAMIC+0x278>
  761337:	jmp    762698 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2008>
  76133c:	and    %bpl,0x108(%rsp)
  761344:	mov    (%rsp),%rax
  761348:	shr    $1,%rax
  76134b:	mov    %rax,0x230(%rsp)
  761353:	mov    $0x1,%ebp
  761358:	xor    %r14d,%r14d
  76135b:	lea    0x70(%rsp),%r12
  761360:	jmp    7613c2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xd32>
  761362:	lea    0x4e47(%rip),%rax        # 7661b0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9query_hit>
  761369:	mov    %rax,0x70(%rsp)
  76136e:	mov    0x70(%rsp),%rcx
  761373:	mov    0x110(%rsp),%rax
  76137b:	mov    %rax,0x70(%rsp)
  761380:	mov    0x70(%rsp),%rdi
  761385:	movlps %xmm0,0x70(%rsp)
  76138a:	movsd  0x70(%rsp),%xmm0
  761390:	movaps %xmm0,%xmm1
  761393:	shufps $0x55,%xmm0,%xmm1
  761397:	call   *%rcx
  761399:	inc    %r14
  76139c:	mov    %rax,0x70(%rsp)
  7613a1:	xor    0x70(%rsp),%rbp
  7613a6:	movabs $0x100000001b3,%rax
  7613b0:	imul   %rax,%rbp
  7613b4:	cmp    %r14,0x138(%rsp)
  7613bc:	je     761844 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x11b4>
  7613c2:	cmp    $0x6,%r15
  7613c6:	ja     761422 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xd92>
  7613c8:	lea    -0x69d457(%rip),%rcx        # c3f78 <GCC_except_table0+0x1c10>
  7613cf:	movslq (%rcx,%r15,4),%rax
  7613d3:	add    %rcx,%rax
  7613d6:	jmp    *%rax
  7613d8:	movzwl 0x0(%r13),%eax
  7613dd:	xor    $0x6968,%eax
  7613e2:	movzbl 0x2(%r13),%ecx
  7613e7:	xor    $0x74,%ecx
  7613ea:	or     %ax,%cx
  7613ed:	jne    761305 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xc75>
  7613f3:	mov    %r14,%rax
  7613f6:	or     %rbx,%rax
  7613f9:	shr    $0x20,%rax
  7613fd:	je     76179b <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x110b>
  761403:	mov    %r14,%rax
  761406:	xor    %edx,%edx
  761408:	div    %rbx
  76140b:	xorps  %xmm0,%xmm0
  76140e:	cmpq   $0x0,0x130(%rsp)
  761417:	jne    7617b4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1124>
  76141d:	jmp    761362 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xcd2>
  761422:	mov    0x0(%r13),%eax
  761426:	mov    $0x70657270,%ecx
  76142b:	xor    %ecx,%eax
  76142d:	mov    0x3(%r13),%ecx
  761431:	mov    $0x65726170,%edx
  761436:	xor    %edx,%ecx
  761438:	or     %eax,%ecx
  76143a:	je     7616c3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1033>
  761440:	mov    0x0(%r13),%eax
  761444:	mov    $0x68736572,%ecx
  761449:	xor    %ecx,%eax
  76144b:	mov    0x3(%r13),%ecx
  76144f:	mov    $0x65706168,%edx
  761454:	xor    %edx,%ecx
  761456:	or     %eax,%ecx
  761458:	jne    761305 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xc75>
  76145e:	lea    -0x1665(%rip),%rax        # 75fe00 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_reshape>
  761465:	mov    %rax,0x70(%rsp)
  76146a:	mov    0x70(%rsp),%rax
  76146f:	lea    0x18(%rsp),%rcx
  761474:	mov    %rcx,0x70(%rsp)
  761479:	mov    0x70(%rsp),%rdi
  76147e:	test   $0x1,%r14b
  761482:	lea    0x268(%rsp),%rcx
  76148a:	lea    0x150(%rsp),%rdx
  761492:	cmove  %rdx,%rcx
  761496:	mov    (%rcx),%rcx
  761499:	lea    0x270(%rsp),%rdx
  7614a1:	lea    0x158(%rsp),%rsi
  7614a9:	cmove  %rsi,%rdx
  7614ad:	mov    (%rdx),%rdx
  7614b0:	mov    %rcx,0x70(%rsp)
  7614b5:	mov    %rdx,0x78(%rsp)
  7614ba:	mov    0x70(%rsp),%rsi
  7614bf:	mov    0x78(%rsp),%rdx
  7614c4:	call   *%rax
  7614c6:	jmp    761399 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xd09>
  7614cb:	mov    0x0(%r13),%eax
  7614cf:	mov    $0x6f727261,%ecx
  7614d4:	xor    %ecx,%eax
  7614d6:	movzbl 0x4(%r13),%ecx
  7614db:	xor    $0x77,%ecx
  7614de:	or     %eax,%ecx
  7614e0:	jne    761305 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xc75>
  7614e6:	lea    -0x227d(%rip),%rax        # 75f270 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow>
  7614ed:	mov    %rax,0x70(%rsp)
  7614f2:	mov    0x70(%rsp),%rax
  7614f7:	lea    0x18(%rsp),%rcx
  7614fc:	mov    %rcx,0x70(%rsp)
  761501:	mov    0x70(%rsp),%rdi
  761506:	test   $0x1,%r14b
  76150a:	sete   %cl
  76150d:	xor    0x108(%rsp),%cl
  761514:	mov    %cl,0x70(%rsp)
  761518:	jmp    7616ef <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x105f>
  76151d:	cmpl   $0x67617264,0x0(%r13)
  761525:	jne    761305 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xc75>
  76152b:	lea    -0x2862(%rip),%rax        # 75ecd0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag>
  761532:	mov    %rax,0x70(%rsp)
  761537:	mov    0x70(%rsp),%rcx
  76153c:	lea    0x18(%rsp),%rax
  761541:	mov    %rax,0x70(%rsp)
  761546:	mov    0x70(%rsp),%rdi
  76154b:	lea    0x200(%rsp),%rax
  761553:	mov    %rax,0x70(%rsp)
  761558:	mov    %r14d,%eax
  76155b:	not    %eax
  76155d:	and    $0x1,%eax
  761560:	cmp    0x28(%rsp),%rax
  761565:	jae    762482 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1df2>
  76156b:	mov    0x70(%rsp),%rsi
  761570:	shl    $0x4,%eax
  761573:	mov    0x8(%rsp),%rdx
  761578:	movsd  (%rdx,%rax,1),%xmm0
  76157d:	movsd  %xmm0,0x70(%rsp)
  761583:	movss  0x70(%rsp),%xmm0
  761589:	movss  0x74(%rsp),%xmm1
  76158f:	call   *%rcx
  761591:	jmp    761399 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xd09>
  761596:	mov    0x0(%r13),%eax
  76159a:	mov    $0x75736976,%ecx
  76159f:	xor    %ecx,%eax
  7615a1:	movzwl 0x4(%r13),%ecx
  7615a6:	xor    $0x6c61,%ecx
  7615ac:	or     %eax,%ecx
  7615ae:	jne    761305 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xc75>
  7615b4:	lea    -0x1dbb(%rip),%rax        # 75f800 <_RNvCs9C2G9YFESsD_29canonical_text_public_control12query_visual>
  7615bb:	mov    %rax,0x70(%rsp)
  7615c0:	mov    0x70(%rsp),%rcx
  7615c5:	mov    0x110(%rsp),%rax
  7615cd:	mov    %rax,0x70(%rsp)
  7615d2:	mov    0x70(%rsp),%rdi
  7615d7:	mov    %r14,%rax
  7615da:	or     %rbx,%rax
  7615dd:	shr    $0x20,%rax
  7615e1:	je     7617e5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1155>
  7615e7:	mov    %r14,%rax
  7615ea:	xor    %edx,%edx
  7615ec:	div    %rbx
  7615ef:	xor    %eax,%eax
  7615f1:	cmp    (%rsp),%rdx
  7615f5:	jae    761602 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xf72>
  7615f7:	mov    0xf8(%rsp),%rax
  7615ff:	mov    (%rax,%rdx,4),%eax
  761602:	mov    %eax,0x70(%rsp)
  761606:	movb   $0x1,0x74(%rsp)
  76160b:	mov    0x70(%rsp),%esi
  76160f:	movzbl 0x74(%rsp),%edx
  761614:	call   *%rcx
  761616:	jmp    761399 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xd09>
  76161b:	mov    0x0(%r13),%rax
  76161f:	movabs $0x6f697463656c6573,%rcx
  761629:	xor    %rcx,%rax
  76162c:	movzbl 0x8(%r13),%ecx
  761631:	xor    $0x6e,%rcx
  761635:	or     %rax,%rcx
  761638:	je     7616fe <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x106e>
  76163e:	mov    0x0(%r13),%rax
  761642:	movabs $0x69682d72656e776f,%rcx
  76164c:	xor    %rcx,%rax
  76164f:	movzbl 0x8(%r13),%ecx
  761654:	xor    $0x74,%rcx
  761658:	or     %rax,%rcx
  76165b:	jne    761305 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xc75>
  761661:	lea    0x49a8(%rip),%rax        # 766010 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit>
  761668:	mov    %rax,0x70(%rsp)
  76166d:	mov    0x70(%rsp),%rcx
  761672:	lea    0x18(%rsp),%rax
  761677:	mov    %rax,0x70(%rsp)
  76167c:	mov    0x70(%rsp),%rdi
  761681:	mov    %r14,%rax
  761684:	mov    0x128(%rsp),%rsi
  76168c:	or     %rsi,%rax
  76168f:	shr    $0x20,%rax
  761693:	je     7617fd <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x116d>
  761699:	mov    %r14,%rax
  76169c:	xor    %edx,%edx
  76169e:	div    %rsi
  7616a1:	xorps  %xmm0,%xmm0
  7616a4:	cmp    0x28(%rsp),%rdx
  7616a9:	jae    7616b9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1029>
  7616ab:	shl    $0x4,%rdx
  7616af:	mov    0x8(%rsp),%rax
  7616b4:	movsd  (%rax,%rdx,1),%xmm0
  7616b9:	movlps %xmm0,0x70(%rsp)
  7616be:	jmp    76138a <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xcfa>
  7616c3:	lea    -0x1e3a(%rip),%rax        # 75f890 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare>
  7616ca:	mov    %rax,0x70(%rsp)
  7616cf:	mov    0x70(%rsp),%rax
  7616d4:	lea    0x18(%rsp),%rcx
  7616d9:	mov    %rcx,0x70(%rsp)
  7616de:	mov    0x70(%rsp),%rdi
  7616e3:	mov    %r14d,%ecx
  7616e6:	not    %cl
  7616e8:	and    $0x1,%cl
  7616eb:	mov    %cl,0x70(%rsp)
  7616ef:	movzbl 0x70(%rsp),%ecx
  7616f4:	movzbl %cl,%esi
  7616f7:	call   *%rax
  7616f9:	jmp    761399 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xd09>
  7616fe:	lea    -0x1675(%rip),%rax        # 760090 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection>
  761705:	mov    %rax,0x70(%rsp)
  76170a:	mov    0x70(%rsp),%rcx
  76170f:	mov    0x110(%rsp),%rax
  761717:	mov    %rax,0x70(%rsp)
  76171c:	mov    0x70(%rsp),%rdi
  761721:	mov    %r14,%rax
  761724:	or     %rbx,%rax
  761727:	shr    $0x20,%rax
  76172b:	je     761817 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1187>
  761731:	mov    %r14,%rax
  761734:	xor    %edx,%edx
  761736:	div    %rbx
  761739:	xor    %esi,%esi
  76173b:	cmp    (%rsp),%rdx
  76173f:	jae    76174c <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x10bc>
  761741:	mov    0xf8(%rsp),%rax
  761749:	mov    (%rax,%rdx,4),%esi
  76174c:	mov    0x230(%rsp),%rax
  761754:	add    %r14,%rax
  761757:	mov    %rax,%rdx
  76175a:	or     %rbx,%rdx
  76175d:	shr    $0x20,%rdx
  761761:	je     76182f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x119f>
  761767:	xor    %edx,%edx
  761769:	div    %rbx
  76176c:	xor    %eax,%eax
  76176e:	cmp    (%rsp),%rdx
  761772:	jae    76177f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x10ef>
  761774:	mov    0xf8(%rsp),%rax
  76177c:	mov    (%rax,%rdx,4),%eax
  76177f:	mov    %esi,0x70(%rsp)
  761783:	movb   $0x1,0x74(%rsp)
  761788:	mov    %eax,0x78(%rsp)
  76178c:	movb   $0x1,0x7c(%rsp)
  761791:	mov    %r12,%rsi
  761794:	call   *%rcx
  761796:	jmp    761399 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xd09>
  76179b:	mov    %r14d,%eax
  76179e:	xor    %edx,%edx
  7617a0:	div    %ebx
  7617a2:	xorps  %xmm0,%xmm0
  7617a5:	cmpq   $0x0,0x130(%rsp)
  7617ae:	je     761362 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xcd2>
  7617b4:	cmp    (%rsp),%rdx
  7617b8:	jae    761362 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xcd2>
  7617be:	imul   $0x38,%rdx,%rax
  7617c2:	mov    0x130(%rsp),%rcx
  7617ca:	movsd  0x10(%rcx,%rax,1),%xmm1
  7617d0:	movsd  0x18(%rcx,%rax,1),%xmm0
  7617d6:	mulps  -0x69e18d(%rip),%xmm0        # c3650 <GCC_except_table0+0x12e8>
  7617dd:	addps  %xmm1,%xmm0
  7617e0:	jmp    761362 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xcd2>
  7617e5:	mov    %r14d,%eax
  7617e8:	xor    %edx,%edx
  7617ea:	div    %ebx
  7617ec:	xor    %eax,%eax
  7617ee:	cmp    (%rsp),%rdx
  7617f2:	jae    761602 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xf72>
  7617f8:	jmp    7615f7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xf67>
  7617fd:	mov    %r14d,%eax
  761800:	xor    %edx,%edx
  761802:	div    %esi
  761804:	xorps  %xmm0,%xmm0
  761807:	cmp    0x28(%rsp),%rdx
  76180c:	jb     7616ab <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x101b>
  761812:	jmp    7616b9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1029>
  761817:	mov    %r14d,%eax
  76181a:	xor    %edx,%edx
  76181c:	div    %ebx
  76181e:	xor    %esi,%esi
  761820:	cmp    (%rsp),%rdx
  761824:	jb     761741 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x10b1>
  76182a:	jmp    76174c <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x10bc>
  76182f:	xor    %edx,%edx
  761831:	div    %ebx
  761833:	xor    %eax,%eax
  761835:	cmp    (%rsp),%rdx
  761839:	jb     761774 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x10e4>
  76183f:	jmp    76177f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x10ef>
  761844:	mov    0x118(%rsp),%eax
  76184b:	cmp    $0xffffffff,%eax
  76184e:	je     7618f7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1267>
  761854:	mov    0x1a0(%rsp),%rcx
  76185c:	mov    %rcx,0x70(%rsp)
  761861:	mov    %eax,0x78(%rsp)
  761865:	lea    0x70(%rsp),%rdi
  76186a:	call   *0x3578e8(%rip)        # ab9158 <_DYNAMIC+0x4f8>
  761870:	mov    0x120(%rsp),%rsi
  761878:	mov    %edx,%ecx
  76187a:	mov    $0x3b9aca00,%edx
  76187f:	mul    %rdx
  761882:	mov    %ecx,%ecx
  761884:	add    %rax,%rcx
  761887:	mov    %rcx,0x110(%rsp)
  76188f:	adc    $0x0,%rdx
  761893:	mov    %rdx,0x28(%rsp)
  761898:	cmp    $0x7,%rsi
  76189c:	je     76191a <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x128a>
  76189e:	jmp    761934 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x12a4>
  7618a3:	mov    %edi,%eax
  7618a5:	and    $0x1f,%eax
  7618a8:	movzbl 0x1(%rcx),%r8d
  7618ad:	and    $0x3f,%r8d
  7618b1:	cmp    $0xe0,%dil
  7618b5:	jb     761da3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1713>
  7618bb:	movzbl 0x2(%rcx),%edx
  7618bf:	shl    $0x6,%r8d
  7618c3:	and    $0x3f,%edx
  7618c6:	or     %r8d,%edx
  7618c9:	cmp    $0xf0,%dil
  7618cd:	jb     761f04 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1874>
  7618d3:	movzbl 0x3(%rcx),%ecx
  7618d7:	and    $0x7,%eax
  7618da:	shl    $0x12,%eax
  7618dd:	shl    $0x6,%edx
  7618e0:	and    $0x3f,%ecx
  7618e3:	or     %edx,%ecx
  7618e5:	or     %ecx,%eax
  7618e7:	cmp    $0x80,%eax
  7618ec:	jae    761f14 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1884>
  7618f2:	jmp    760722 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x92>
  7618f7:	movq   $0x0,0x110(%rsp)
  761903:	movq   $0x0,0x28(%rsp)
  76190c:	mov    0x120(%rsp),%rsi
  761914:	cmp    $0x7,%rsi
  761918:	jne    761934 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x12a4>
  76191a:	mov    $0x68736572,%eax
  76191f:	xor    0x0(%r13),%eax
  761923:	mov    $0x65706168,%ecx
  761928:	xor    0x3(%r13),%ecx
  76192c:	or     %eax,%ecx
  76192e:	je     761db9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1729>
  761934:	cmpb   $0x0,0x100(%rsp)
  76193c:	je     761986 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x12f6>
  76193e:	cmpl   $0x67617264,0x0(%r13)
  761946:	jne    761986 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x12f6>
  761948:	movl   $0x3,0x70(%rsp)
  761950:	lea    0x30(%rsp),%rdi
  761955:	lea    0x18(%rsp),%rsi
  76195a:	lea    0x200(%rsp),%rdx
  761962:	lea    0x70(%rsp),%rcx
  761967:	call   76cd00 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_>
  76196c:	cmpl   $0xfffffffe,0x30(%rsp)
  761971:	jne    76230c <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1c7c>
  761977:	mov    0x18(%rsp),%rsi
  76197c:	lea    0x70(%rsp),%rdi
  761981:	call   760520 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack>
  761986:	mov    0x18(%rsp),%rax
  76198b:	test   %rax,%rax
  76198e:	je     762554 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1ec4>
  761994:	mov    0x6f0(%rax),%rcx
  76199b:	mov    0x6f8(%rax),%r15
  7619a2:	mov    0x700(%rax),%r14
  7619a9:	mov    0x708(%rax),%rbx
  7619b0:	mov    0x710(%rax),%r13
  7619b7:	mov    0x718(%rax),%r12
  7619be:	mov    0x720(%rax),%rdx
  7619c5:	mov    %rdx,0x138(%rsp)
  7619cd:	mov    0x728(%rax),%rdx
  7619d4:	mov    %rdx,0x108(%rsp)
  7619dc:	mov    0x730(%rax),%rdx
  7619e3:	mov    %rdx,0x128(%rsp)
  7619eb:	mov    0x738(%rax),%rdx
  7619f2:	mov    %rdx,0x120(%rsp)
  7619fa:	mov    0x740(%rax),%rdx
  761a01:	mov    %rdx,0x118(%rsp)
  761a09:	mov    0x748(%rax),%rdx
  761a10:	mov    %rdx,0x100(%rsp)
  761a18:	mov    0x750(%rax),%rax
  761a1f:	mov    %rax,0x230(%rsp)
  761a27:	movq   $0xffffffffffffffff,0x30(%rsp)
  761a30:	movq   $0x0,0x48(%rsp)
  761a39:	movq   $0x0,0x58(%rsp)
  761a42:	lea    -0x692214(%rip),%rsi        # cf835 <GCC_except_table0+0xd4cd>
  761a49:	lea    0x30(%rsp),%rdi
  761a4e:	mov    $0xc,%edx
  761a53:	call   75c6b0 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  761a58:	test   %rax,%rax
  761a5b:	jne    762392 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1d02>
  761a61:	lea    -0x692227(%rip),%rsi        # cf841 <GCC_except_table0+0xd4d9>
  761a68:	lea    0x30(%rsp),%rdi
  761a6d:	mov    $0xc,%edx
  761a72:	mov    %r15,%rcx
  761a75:	call   75c6b0 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  761a7a:	test   %rax,%rax
  761a7d:	jne    762392 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1d02>
  761a83:	lea    -0x69223d(%rip),%rsi        # cf84d <GCC_except_table0+0xd4e5>
  761a8a:	lea    0x30(%rsp),%rdi
  761a8f:	mov    $0x11,%edx
  761a94:	mov    %r14,%rcx
  761a97:	call   75c6b0 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  761a9c:	test   %rax,%rax
  761a9f:	jne    762392 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1d02>
  761aa5:	lea    -0x69224e(%rip),%rsi        # cf85e <GCC_except_table0+0xd4f6>
  761aac:	lea    0x30(%rsp),%rdi
  761ab1:	mov    $0xc,%edx
  761ab6:	mov    %rbx,%rcx
  761ab9:	call   75c6b0 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  761abe:	test   %rax,%rax
  761ac1:	jne    762392 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1d02>
  761ac7:	lea    -0x692264(%rip),%rsi        # cf86a <GCC_except_table0+0xd502>
  761ace:	lea    0x30(%rsp),%rdi
  761ad3:	mov    $0x14,%edx
  761ad8:	mov    %r13,%rcx
  761adb:	call   75c6b0 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  761ae0:	test   %rax,%rax
  761ae3:	jne    762392 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1d02>
  761ae9:	lea    -0x692272(%rip),%rsi        # cf87e <GCC_except_table0+0xd516>
  761af0:	lea    0x30(%rsp),%rdi
  761af5:	mov    $0xf,%edx
  761afa:	mov    %r12,%rcx
  761afd:	call   75c6b0 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  761b02:	test   %rax,%rax
  761b05:	jne    762392 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1d02>
  761b0b:	lea    -0x692285(%rip),%rsi        # cf88d <GCC_except_table0+0xd525>
  761b12:	lea    0x30(%rsp),%rdi
  761b17:	mov    $0x11,%edx
  761b1c:	mov    0x138(%rsp),%rcx
  761b24:	call   75c6b0 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  761b29:	test   %rax,%rax
  761b2c:	jne    762392 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1d02>
  761b32:	lea    -0x69229b(%rip),%rsi        # cf89e <GCC_except_table0+0xd536>
  761b39:	lea    0x30(%rsp),%rdi
  761b3e:	mov    $0xb,%edx
  761b43:	mov    0x108(%rsp),%rcx
  761b4b:	call   75c6b0 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  761b50:	test   %rax,%rax
  761b53:	jne    762392 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1d02>
  761b59:	lea    -0x6922b7(%rip),%rsi        # cf8a9 <GCC_except_table0+0xd541>
  761b60:	lea    0x30(%rsp),%rdi
  761b65:	mov    $0xd,%edx
  761b6a:	mov    0x128(%rsp),%rcx
  761b72:	call   75c6b0 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  761b77:	test   %rax,%rax
  761b7a:	jne    762392 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1d02>
  761b80:	lea    -0x6922d1(%rip),%rsi        # cf8b6 <GCC_except_table0+0xd54e>
  761b87:	lea    0x30(%rsp),%rdi
  761b8c:	mov    $0xd,%edx
  761b91:	mov    0x120(%rsp),%rcx
  761b99:	call   75c6b0 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  761b9e:	test   %rax,%rax
  761ba1:	jne    762392 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1d02>
  761ba7:	lea    -0x6922eb(%rip),%rsi        # cf8c3 <GCC_except_table0+0xd55b>
  761bae:	lea    0x30(%rsp),%rdi
  761bb3:	mov    $0xc,%edx
  761bb8:	mov    0x118(%rsp),%rcx
  761bc0:	call   75c6b0 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  761bc5:	test   %rax,%rax
  761bc8:	jne    762392 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1d02>
  761bce:	lea    -0x692306(%rip),%rsi        # cf8cf <GCC_except_table0+0xd567>
  761bd5:	lea    0x30(%rsp),%rdi
  761bda:	mov    $0xd,%edx
  761bdf:	mov    0x100(%rsp),%rcx
  761be7:	call   75c6b0 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  761bec:	test   %rax,%rax
  761bef:	jne    762392 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1d02>
  761bf5:	lea    -0x692320(%rip),%rsi        # cf8dc <GCC_except_table0+0xd574>
  761bfc:	lea    0x30(%rsp),%rdi
  761c01:	mov    $0xe,%edx
  761c06:	mov    0x230(%rsp),%rcx
  761c0e:	call   75c6b0 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  761c13:	test   %rax,%rax
  761c16:	jne    762392 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1d02>
  761c1c:	movups 0x30(%rsp),%xmm0
  761c21:	movups 0x40(%rsp),%xmm1
  761c26:	movups 0x50(%rsp),%xmm2
  761c2b:	movaps %xmm2,0x90(%rsp)
  761c33:	movaps %xmm1,0x80(%rsp)
  761c3b:	movaps %xmm0,0x70(%rsp)
  761c40:	lea    0x160(%rsp),%rdi
  761c48:	lea    0x70(%rsp),%rsi
  761c4d:	call   *0x35750d(%rip)        # ab9160 <_DYNAMIC+0x500>
  761c53:	cmpb   $0xff,0x160(%rsp)
  761c5b:	je     7626af <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x201f>
  761c61:	movups 0x160(%rsp),%xmm0
  761c69:	movups 0x170(%rsp),%xmm1
  761c71:	mov    0x288(%rsp),%rax
  761c79:	movups %xmm1,0x28(%rax)
  761c7d:	movups %xmm0,0x18(%rax)
  761c81:	mov    %rbp,0x10(%rax)
  761c85:	mov    0x28(%rsp),%rcx
  761c8a:	mov    %rcx,0x8(%rax)
  761c8e:	mov    0x110(%rsp),%rcx
  761c96:	mov    %rcx,(%rax)
  761c99:	mov    0x10(%rsp),%rsi
  761c9e:	test   %rsi,%rsi
  761ca1:	mov    (%rsp),%r15
  761ca5:	je     761cbb <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x162b>
  761ca7:	shl    $0x4,%rsi
  761cab:	mov    $0x4,%edx
  761cb0:	mov    0x8(%rsp),%rdi
  761cb5:	call   *0x3571e5(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  761cbb:	mov    0x18(%rsp),%r14
  761cc0:	test   %r14,%r14
  761cc3:	mov    0x130(%rsp),%rbx
  761ccb:	mov    0x1a8(%rsp),%r12
  761cd3:	je     761cf0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1660>
  761cd5:	mov    %r14,%rdi
  761cd8:	call   747d30 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui7runtime7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEEB1h_>
  761cdd:	mov    $0x770,%esi
  761ce2:	mov    $0x8,%edx
  761ce7:	mov    %r14,%rdi
  761cea:	call   *0x3571b0(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  761cf0:	test   %r15,%r15
  761cf3:	je     761d0f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x167f>
  761cf5:	shl    $0x2,%r15
  761cf9:	mov    $0x4,%edx
  761cfe:	mov    0xf8(%rsp),%rdi
  761d06:	mov    %r15,%rsi
  761d09:	call   *0x357191(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  761d0f:	test   %r12,%r12
  761d12:	je     761d26 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1696>
  761d14:	imul   $0x38,%r12,%rsi
  761d18:	mov    $0x8,%edx
  761d1d:	mov    %rbx,%rdi
  761d20:	call   *0x35717a(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  761d26:	lea    0x300(%rsp),%rdi
  761d2e:	call   74ca20 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text10TextLayoutECs9C2G9YFESsD_29canonical_text_public_control>
  761d33:	mov    0x140(%rsp),%rax
  761d3b:	lock decq (%rax)
  761d3f:	jne    761d51 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x16c1>
  761d41:	xor    %ebp,%ebp
  761d43:	lea    0x140(%rsp),%rdi
  761d4b:	call   *0x35723f(%rip)        # ab8f90 <_DYNAMIC+0x330>
  761d51:	mov    0x260(%rsp),%rsi
  761d59:	test   %rsi,%rsi
  761d5c:	je     761d71 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x16e1>
  761d5e:	mov    0x268(%rsp),%rdi
  761d66:	mov    $0x1,%edx
  761d6b:	call   *0x35712f(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  761d71:	mov    0x148(%rsp),%rsi
  761d79:	test   %rsi,%rsi
  761d7c:	je     761d91 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1701>
  761d7e:	mov    0x150(%rsp),%rdi
  761d86:	mov    $0x1,%edx
  761d8b:	call   *0x35710f(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  761d91:	add    $0x338,%rsp
  761d98:	pop    %rbx
  761d99:	pop    %r12
  761d9b:	pop    %r13
  761d9d:	pop    %r14
  761d9f:	pop    %r15
  761da1:	pop    %rbp
  761da2:	ret
  761da3:	shl    $0x6,%eax
  761da6:	or     %r8d,%eax
  761da9:	cmp    $0x80,%eax
  761dae:	jae    761f14 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1884>
  761db4:	jmp    760722 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x92>
  761db9:	testb  $0x1,0x138(%rsp)
  761dc1:	lea    0x148(%rsp),%rax
  761dc9:	lea    0x260(%rsp),%rcx
  761dd1:	cmove  %rcx,%rax
  761dd5:	mov    %rax,0x160(%rsp)
  761ddd:	mov    0x18(%rsp),%rsi
  761de2:	test   %rsi,%rsi
  761de5:	je     762607 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1f77>
  761deb:	cmpb   $0x0,0x76e(%rsi)
  761df2:	jne    76260e <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1f7e>
  761df8:	cmpb   $0x1,0x76c(%rsi)
  761dff:	jne    762615 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1f85>
  761e05:	lea    0x70(%rsp),%rdi
  761e0a:	call   73dc40 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime5queryNtB3_7Context3newNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEBX_>
  761e0f:	mov    0xa8(%rsp),%rbx
  761e17:	test   %rbx,%rbx
  761e1a:	je     761934 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x12a4>
  761e20:	mov    0xa0(%rsp),%r15
  761e28:	add    $0x3d,%r15
  761e2c:	xor    %r14d,%r14d
  761e2f:	mov    %rbp,%r12
  761e32:	jmp    761e67 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x17d7>
  761e34:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  761e40:	mov    %rax,%rbp
  761e43:	xor    %r12,%rbp
  761e46:	movabs $0x100000001b3,%rax
  761e50:	imul   %rax,%rbp
  761e54:	mov    %rbp,%r12
  761e57:	inc    %r14
  761e5a:	add    $0x40,%r15
  761e5e:	cmp    %r14,%rbx
  761e61:	je     761934 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x12a4>
  761e67:	cmpb   $0x4,(%r15)
  761e6b:	jne    761e57 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x17c7>
  761e6d:	mov    -0x15(%r15),%rdi
  761e71:	test   %rdi,%rdi
  761e74:	je     76252c <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1e9c>
  761e7a:	mov    (%rdi),%rdx
  761e7d:	shr    $1,%rdx
  761e80:	add    $0x10,%rdi
  761e84:	mov    0x138(%rsp),%rcx
  761e8c:	test   $0x1,%cl
  761e8f:	mov    %rdi,0x30(%rsp)
  761e94:	mov    %rdx,0x38(%rsp)
  761e99:	lea    0x148(%rsp),%rsi
  761ea1:	mov    %rsi,%rax
  761ea4:	lea    0x260(%rsp),%r8
  761eac:	cmove  %r8,%rax
  761eb0:	cmp    0x10(%rax),%rdx
  761eb4:	jne    7620f2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1a62>
  761eba:	test   $0x1,%cl
  761ebd:	mov    %rsi,%rax
  761ec0:	cmove  %r8,%rax
  761ec4:	mov    0x8(%rax),%rsi
  761ec8:	call   *0x35729a(%rip)        # ab9168 <bcmp@GLIBC_2.2.5>
  761ece:	test   %eax,%eax
  761ed0:	jne    7620f2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1a62>
  761ed6:	lea    0x30(%rsp),%rdi
  761edb:	lea    0x70(%rsp),%rsi
  761ee0:	mov    %r14,%rdx
  761ee3:	call   *0x3571bf(%rip)        # ab90a8 <_DYNAMIC+0x448>
  761ee9:	cmpq   $0x0,0x30(%rsp)
  761eef:	je     7621ab <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1b1b>
  761ef5:	mov    0x40(%rsp),%rdi
  761efa:	call   75ff60 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript>
  761eff:	jmp    761e40 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x17b0>
  761f04:	shl    $0xc,%eax
  761f07:	or     %edx,%eax
  761f09:	cmp    $0x80,%eax
  761f0e:	jb     760722 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x92>
  761f14:	mov    $0x2,%esi
  761f19:	cmp    $0x800,%eax
  761f1e:	jb     760722 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x92>
  761f24:	cmp    $0x10000,%eax
  761f29:	mov    $0x4,%esi
  761f2e:	sbb    $0x0,%rsi
  761f32:	jmp    760722 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x92>
  761f37:	lea    0x178(%rsp),%rbx
  761f3f:	mov    %rdx,(%rsp)
  761f43:	lea    0x70(%rsp),%r14
  761f48:	lea    0x1b0(%rsp),%r15
  761f50:	cmp    $0x1,%rcx
  761f54:	je     762681 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1ff1>
  761f5a:	mov    0x160(%rsp),%rdx
  761f62:	mov    (%rdx),%esi
  761f64:	add    $0xc,%rdx
  761f68:	jmp    761f80 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x18f0>
  761f6a:	nopw   0x0(%rax,%rax,1)
  761f70:	dec    %rax
  761f73:	add    $0xc,%rdx
  761f77:	cmp    %rax,%rcx
  761f7a:	ja     760f06 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x876>
  761f80:	mov    %esi,%edi
  761f82:	mov    (%rdx),%esi
  761f84:	cmp    %esi,%edi
  761f86:	je     761f70 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x18e0>
  761f88:	testb  $0x2,-0x4(%rdx)
  761f8c:	je     761f70 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x18e0>
  761f8e:	testb  $0x1,0x8(%rdx)
  761f92:	je     761f70 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x18e0>
  761f94:	mov    %rdx,0x160(%rsp)
  761f9c:	dec    %rax
  761f9f:	mov    %rax,0x168(%rsp)
  761fa7:	add    $0xfffffffffffffff4,%rdx
  761fab:	mov    %r14,%rdi
  761fae:	mov    %rbx,%rsi
  761fb1:	call   75d2b0 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control>
  761fb6:	cmpb   $0x2,0x74(%rsp)
  761fbb:	je     760f06 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x876>
  761fc1:	mov    (%rsp),%rsi
  761fc5:	cmp    0x1b0(%rsp),%rsi
  761fcd:	jne    761ff3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1963>
  761fcf:	mov    $0x1,%edx
  761fd4:	mov    $0x8,%ecx
  761fd9:	mov    $0x38,%r8d
  761fdf:	mov    %r15,%rdi
  761fe2:	call   75b120 <_RINvNvMs2_NtCscdodAO9FK5_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs9C2G9YFESsD_29canonical_text_public_control>
  761fe7:	mov    0x1b8(%rsp),%r12
  761fef:	mov    (%rsp),%rsi
  761ff3:	imul   $0x38,%rsi,%rax
  761ff7:	mov    0xa0(%rsp),%rcx
  761fff:	mov    %rcx,0x30(%r12,%rax,1)
  762004:	movups 0x70(%rsp),%xmm0
  762009:	movups 0x80(%rsp),%xmm1
  762011:	movups 0x90(%rsp),%xmm2
  762019:	movups %xmm2,0x20(%r12,%rax,1)
  76201f:	movups %xmm1,0x10(%r12,%rax,1)
  762025:	movups %xmm0,(%r12,%rax,1)
  76202a:	inc    %rsi
  76202d:	mov    %rsi,(%rsp)
  762031:	mov    %rsi,0x1c0(%rsp)
  762039:	mov    0x168(%rsp),%rax
  762041:	mov    0x170(%rsp),%rcx
  762049:	cmp    %rax,%rcx
  76204c:	jbe    761f50 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x18c0>
  762052:	jmp    760f06 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x876>
  762057:	mov    %r14,%rax
  76205a:	and    $0xfffffffffffffff8,%rax
  76205e:	xor    %ecx,%ecx
  762060:	mov    %r12,%rdx
  762063:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  762070:	movss  0xa8(%rdx),%xmm0
  762078:	movss  0x70(%rdx),%xmm1
  76207d:	unpcklps %xmm0,%xmm1
  762080:	movss  0x38(%rdx),%xmm0
  762085:	movss  (%rdx),%xmm2
  762089:	unpcklps %xmm0,%xmm2
  76208c:	movlhps %xmm1,%xmm2
  76208f:	movss  0x188(%rdx),%xmm0
  762097:	movss  0x150(%rdx),%xmm1
  76209f:	unpcklps %xmm0,%xmm1
  7620a2:	movss  0x118(%rdx),%xmm0
  7620aa:	movss  0xe0(%rdx),%xmm3
  7620b2:	unpcklps %xmm0,%xmm3
  7620b5:	movlhps %xmm1,%xmm3
  7620b8:	movups %xmm2,(%rsi,%rcx,4)
  7620bc:	movups %xmm3,0x10(%rsi,%rcx,4)
  7620c1:	add    $0x8,%rcx
  7620c5:	add    $0x1c0,%rdx
  7620cc:	cmp    %rcx,%rax
  7620cf:	jne    762070 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x19e0>
  7620d1:	cmp    %rax,(%rsp)
  7620d5:	je     760932 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2a2>
  7620db:	jmp    760f70 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x8e0>
  7620e0:	lea    0x336ca9(%rip),%rdi        # a98d90 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x658>
  7620e7:	call   *0x356e5b(%rip)        # ab8f48 <_DYNAMIC+0x2e8>
  7620ed:	jmp    762698 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2008>
  7620f2:	lea    0x30(%rsp),%rdi
  7620f7:	lea    0x160(%rsp),%rsi
  7620ff:	call   74f36a <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedReRNtNtCscdodAO9FK5_5alloc6string6StringECs9C2G9YFESsD_29canonical_text_public_control>
  762104:	jmp    762698 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2008>
  762109:	lea    -0x69265e(%rip),%rdi        # cfab2 <GCC_except_table0+0xd74a>
  762110:	lea    0x337589(%rip),%rdx        # a996a0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xf68>
  762117:	mov    $0x1b,%esi
  76211c:	call   *0x356df6(%rip)        # ab8f18 <_DYNAMIC+0x2b8>
  762122:	mov    0x74(%rsp),%rax
  762127:	mov    %rax,0x30(%rsp)
  76212c:	lea    -0x692551(%rip),%rdi        # cfbe2 <GCC_except_table0+0xd87a>
  762133:	lea    0x33789e(%rip),%rcx        # a999d8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x12a0>
  76213a:	lea    0x33758f(%rip),%r8        # a996d0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xf98>
  762141:	lea    0x30(%rsp),%rdx
  762146:	mov    $0x2b,%esi
  76214b:	call   *0x356e1f(%rip)        # ab8f70 <_DYNAMIC+0x310>
  762151:	jmp    762698 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2008>
  762156:	mov    0x78(%rsp),%rax
  76215b:	mov    %rax,0x160(%rsp)
  762163:	lea    -0x692588(%rip),%rdi        # cfbe2 <GCC_except_table0+0xd87a>
  76216a:	lea    0x337867(%rip),%rcx        # a999d8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x12a0>
  762171:	lea    0x337570(%rip),%r8        # a996e8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xfb0>
  762178:	lea    0x160(%rsp),%rdx
  762180:	mov    $0x2b,%esi
  762185:	call   *0x356de5(%rip)        # ab8f70 <_DYNAMIC+0x310>
  76218b:	jmp    762698 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2008>
  762190:	lea    0x337569(%rip),%rdi        # a99700 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xfc8>
  762197:	call   *0x356dab(%rip)        # ab8f48 <_DYNAMIC+0x2e8>
  76219d:	jmp    762698 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2008>
  7621a2:	lea    0x33756f(%rip),%rdi        # a99718 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xfe0>
  7621a9:	jmp    7621b2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1b22>
  7621ab:	lea    0x336bc6(%rip),%rdi        # a98d78 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x640>
  7621b2:	call   *0x356d90(%rip)        # ab8f48 <_DYNAMIC+0x2e8>
  7621b8:	jmp    762698 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2008>
  7621bd:	lea    0x3385ac(%rip),%rcx        # a9a770 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2038>
  7621c4:	xor    %edi,%edi
  7621c6:	call   *0x356d24(%rip)        # ab8ef0 <_DYNAMIC+0x290>
  7621cc:	jmp    762698 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2008>
  7621d1:	lea    0x148(%rsp),%rdi
  7621d9:	mov    $0x1,%edx
  7621de:	mov    $0x1,%ecx
  7621e3:	mov    $0x1,%r8d
  7621e9:	mov    %rbx,%rsi
  7621ec:	call   75b120 <_RINvNvMs2_NtCscdodAO9FK5_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs9C2G9YFESsD_29canonical_text_public_control>
  7621f1:	jmp    7607bb <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x12b>
  7621f6:	lea    -0x69de4c(%rip),%rdi        # c43b1 <GCC_except_table0+0x2049>
  7621fd:	lea    0x3374b4(%rip),%rdx        # a996b8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xf80>
  762204:	mov    $0x57,%esi
  762209:	call   *0x356cc9(%rip)        # ab8ed8 <_DYNAMIC+0x278>
  76220f:	jmp    762698 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2008>
  762214:	lea    0x336b8d(%rip),%rdi        # a98da8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x670>
  76221b:	mov    (%rsp),%r15
  76221f:	jmp    7620e7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1a57>
  762224:	lea    0x336b95(%rip),%rdi        # a98dc0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x688>
  76222b:	mov    (%rsp),%r15
  76222f:	jmp    7620e7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1a57>
  762234:	lea    -0x69e4cb(%rip),%rdx        # c3d70 <GCC_except_table0+0x1a08>
  76223b:	lea    0x337606(%rip),%r9        # a99848 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1110>
  762242:	lea    0x70(%rsp),%rsi
  762247:	xor    %edi,%edi
  762249:	xor    %ecx,%ecx
  76224b:	call   *0x356f1f(%rip)        # ab9170 <_DYNAMIC+0x510>
  762251:	jmp    762698 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2008>
  762256:	mov    0x60(%rsp),%rax
  76225b:	mov    %rax,0xa0(%rsp)
  762263:	movups 0x30(%rsp),%xmm0
  762268:	movups 0x40(%rsp),%xmm1
  76226d:	movups 0x50(%rsp),%xmm2
  762272:	movaps %xmm2,0x90(%rsp)
  76227a:	movaps %xmm1,0x80(%rsp)
  762282:	movaps %xmm0,0x70(%rsp)
  762287:	lea    -0x6926ac(%rip),%rdi        # cfbe2 <GCC_except_table0+0xd87a>
  76228e:	lea    0x337703(%rip),%rcx        # a99998 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1260>
  762295:	lea    0x3374bc(%rip),%r8        # a99758 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1020>
  76229c:	lea    0x70(%rsp),%rdx
  7622a1:	mov    $0x2b,%esi
  7622a6:	call   *0x356cc4(%rip)        # ab8f70 <_DYNAMIC+0x310>
  7622ac:	jmp    762698 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2008>
  7622b1:	mov    0x60(%rsp),%rax
  7622b6:	mov    %rax,0xa0(%rsp)
  7622be:	movups 0x30(%rsp),%xmm0
  7622c3:	movups 0x40(%rsp),%xmm1
  7622c8:	movups 0x50(%rsp),%xmm2
  7622cd:	movaps %xmm2,0x90(%rsp)
  7622d5:	movaps %xmm1,0x80(%rsp)
  7622dd:	movaps %xmm0,0x70(%rsp)
  7622e2:	lea    -0x692707(%rip),%rdi        # cfbe2 <GCC_except_table0+0xd87a>
  7622e9:	lea    0x3376a8(%rip),%rcx        # a99998 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1260>
  7622f0:	lea    0x337479(%rip),%r8        # a99770 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1038>
  7622f7:	lea    0x70(%rsp),%rdx
  7622fc:	mov    $0x2b,%esi
  762301:	call   *0x356c69(%rip)        # ab8f70 <_DYNAMIC+0x310>
  762307:	jmp    762698 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2008>
  76230c:	mov    0x60(%rsp),%rax
  762311:	mov    %rax,0xa0(%rsp)
  762319:	movups 0x30(%rsp),%xmm0
  76231e:	movups 0x40(%rsp),%xmm1
  762323:	movups 0x50(%rsp),%xmm2
  762328:	movaps %xmm2,0x90(%rsp)
  762330:	movaps %xmm1,0x80(%rsp)
  762338:	movaps %xmm0,0x70(%rsp)
  76233d:	lea    -0x692762(%rip),%rdi        # cfbe2 <GCC_except_table0+0xd87a>
  762344:	lea    0x33764d(%rip),%rcx        # a99998 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1260>
  76234b:	lea    0x337466(%rip),%r8        # a997b8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1080>
  762352:	lea    0x70(%rsp),%rdx
  762357:	mov    $0x2b,%esi
  76235c:	call   *0x356c0e(%rip)        # ab8f70 <_DYNAMIC+0x310>
  762362:	jmp    762698 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2008>
  762367:	lea    0x2a0(%rsp),%rdi
  76236f:	call   74f32d <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedReBM_ECs9C2G9YFESsD_29canonical_text_public_control>
  762374:	jmp    762698 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2008>
  762379:	lea    0x8(%rcx),%rdi
  76237d:	lea    0x18(%rcx),%rsi
  762381:	lea    0x3374a8(%rip),%rdx        # a99830 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x10f8>
  762388:	call   74f2c3 <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextPositionBM_ECs9C2G9YFESsD_29canonical_text_public_control>
  76238d:	jmp    762698 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2008>
  762392:	mov    %rax,%rbx
  762395:	mov    %rax,0x168(%rsp)
  76239d:	movb   $0xff,0x160(%rsp)
  7623a5:	mov    0x48(%rsp),%rcx
  7623aa:	test   %rcx,%rcx
  7623ad:	jne    7623e2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1d52>
  7623af:	xor    %ecx,%ecx
  7623b1:	xor    %eax,%eax
  7623b3:	jmp    762426 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1d96>
  7623b5:	lea    0x336b54(%rip),%rax        # a98f10 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x7d8>
  7623bc:	mov    %rax,0x10(%rsp)
  7623c1:	mov    $0x1,%ebp
  7623c6:	mov    $0x1,%esi
  7623cb:	mov    %rbp,%rdi
  7623ce:	mov    0x10(%rsp),%rdx
  7623d3:	mov    (%rsp),%r15
  7623d7:	call   *0x356af3(%rip)        # ab8ed0 <_DYNAMIC+0x270>
  7623dd:	jmp    762698 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2008>
  7623e2:	mov    0x50(%rsp),%rdx
  7623e7:	mov    0x58(%rsp),%rax
  7623ec:	movq   $0x0,0x78(%rsp)
  7623f5:	mov    %rcx,0x80(%rsp)
  7623fd:	mov    %rdx,0x88(%rsp)
  762405:	movq   $0x0,0x98(%rsp)
  762411:	mov    %rcx,0xa0(%rsp)
  762419:	mov    %rdx,0xa8(%rsp)
  762421:	mov    $0x1,%ecx
  762426:	mov    %rcx,0x70(%rsp)
  76242b:	mov    %rcx,0x90(%rsp)
  762433:	mov    %rax,0xb0(%rsp)
  76243b:	lea    0x70(%rsp),%rdi
  762440:	call   74aac0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtCscdodAO9FK5_5alloc11collections5btree3map8IntoIterNtNtBK_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueEECs9C2G9YFESsD_29canonical_text_public_control>
  762445:	mov    0x30(%rsp),%rsi
  76244a:	test   %rsi,%rsi
  76244d:	jg     76269a <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x200a>
  762453:	mov    %rbx,0x70(%rsp)
  762458:	lea    -0x69287d(%rip),%rdi        # cfbe2 <GCC_except_table0+0xd87a>
  76245f:	lea    0x337552(%rip),%rcx        # a999b8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1280>
  762466:	lea    0x33737b(%rip),%r8        # a997e8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x10b0>
  76246d:	lea    0x70(%rsp),%rdx
  762472:	mov    $0x2b,%esi
  762477:	call   *0x356af3(%rip)        # ab8f70 <_DYNAMIC+0x310>
  76247d:	jmp    762698 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2008>
  762482:	lea    0x33738f(%rip),%rdx        # a99818 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x10e0>
  762489:	mov    %rax,%rdi
  76248c:	mov    0x28(%rsp),%rsi
  762491:	call   *0x356a39(%rip)        # ab8ed0 <_DYNAMIC+0x270>
  762497:	jmp    762698 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2008>
  76249c:	mov    $0xe,%eax
  7624a1:	jmp    7624a8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1e18>
  7624a3:	mov    $0x12,%eax
  7624a8:	mov    %rax,0x8(%rsp)
  7624ad:	mov    0x8(%rsp),%rax
  7624b2:	mov    %rax,0x70(%rsp)
  7624b7:	lea    -0x692b5d(%rip),%rdi        # cf961 <GCC_except_table0+0xd5f9>
  7624be:	lea    0x3374d3(%rip),%rcx        # a99998 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1260>
  7624c5:	lea    0x336e34(%rip),%r8        # a99300 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xbc8>
  7624cc:	lea    0x70(%rsp),%rdx
  7624d1:	mov    $0x2a,%esi
  7624d6:	call   *0x356a94(%rip)        # ab8f70 <_DYNAMIC+0x310>
  7624dc:	jmp    762698 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2008>
  7624e1:	mov    $0xd,%eax
  7624e6:	jmp    7624f4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1e64>
  7624e8:	mov    $0xe,%eax
  7624ed:	jmp    7624f4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1e64>
  7624ef:	mov    $0x12,%eax
  7624f4:	mov    %rax,0x70(%rsp)
  7624f9:	movq   $0x0,0x78(%rsp)
  762502:	lea    -0x692927(%rip),%rdi        # cfbe2 <GCC_except_table0+0xd87a>
  762509:	lea    0x337488(%rip),%rcx        # a99998 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1260>
  762510:	lea    0x337409(%rip),%r8        # a99920 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x11e8>
  762517:	lea    0x70(%rsp),%rdx
  76251c:	mov    $0x2b,%esi
  762521:	call   *0x356a49(%rip)        # ab8f70 <_DYNAMIC+0x310>
  762527:	jmp    762698 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2008>
  76252c:	lea    0x336815(%rip),%rdi        # a98d48 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x610>
  762533:	jmp    7621b2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1b22>
  762538:	lea    0x3369d1(%rip),%rdx        # a98f10 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x7d8>
  76253f:	mov    $0x1,%edi
  762544:	mov    $0x1,%esi
  762549:	call   *0x356981(%rip)        # ab8ed0 <_DYNAMIC+0x270>
  76254f:	jmp    762698 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2008>
  762554:	movq   $0xd,0x70(%rsp)
  76255d:	movq   $0x0,0x78(%rsp)
  762566:	lea    -0x692a93(%rip),%rdi        # cfada <GCC_except_table0+0xd772>
  76256d:	lea    0x337424(%rip),%rcx        # a99998 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1260>
  762574:	lea    0x337255(%rip),%r8        # a997d0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1098>
  76257b:	lea    0x70(%rsp),%rdx
  762580:	mov    $0x24,%esi
  762585:	call   *0x3569e5(%rip)        # ab8f70 <_DYNAMIC+0x310>
  76258b:	jmp    762698 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2008>
  762590:	movq   $0xd,0x30(%rsp)
  762599:	movq   $0x0,0x38(%rsp)
  7625a2:	mov    0x60(%rsp),%rax
  7625a7:	mov    %rax,0xa0(%rsp)
  7625af:	mov    0x30(%rsp),%rax
  7625b4:	mov    0x38(%rsp),%rcx
  7625b9:	movups 0x40(%rsp),%xmm0
  7625be:	movups 0x50(%rsp),%xmm1
  7625c3:	movaps %xmm1,0x90(%rsp)
  7625cb:	movaps %xmm0,0x80(%rsp)
  7625d3:	mov    %rax,0x70(%rsp)
  7625d8:	mov    %rcx,0x78(%rsp)
  7625dd:	lea    -0x692a02(%rip),%rdi        # cfbe2 <GCC_except_table0+0xd87a>
  7625e4:	lea    0x3373ad(%rip),%rcx        # a99998 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1260>
  7625eb:	lea    0x33714e(%rip),%r8        # a99740 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1008>
  7625f2:	lea    0x70(%rsp),%rdx
  7625f7:	mov    $0x2b,%esi
  7625fc:	call   *0x35696e(%rip)        # ab8f70 <_DYNAMIC+0x310>
  762602:	jmp    762698 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2008>
  762607:	mov    $0xd,%eax
  76260c:	jmp    76261a <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1f8a>
  76260e:	mov    $0xe,%eax
  762613:	jmp    76261a <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1f8a>
  762615:	mov    $0x12,%eax
  76261a:	mov    %rax,0x70(%rsp)
  76261f:	movq   $0x0,0x78(%rsp)
  762628:	lea    -0x692a4d(%rip),%rdi        # cfbe2 <GCC_except_table0+0xd87a>
  76262f:	lea    0x337362(%rip),%rcx        # a99998 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1260>
  762636:	lea    0x337163(%rip),%r8        # a997a0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1068>
  76263d:	lea    0x70(%rsp),%rdx
  762642:	mov    $0x2b,%esi
  762647:	call   *0x356923(%rip)        # ab8f70 <_DYNAMIC+0x310>
  76264d:	jmp    762698 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2008>
  76264f:	mov    $0x8,%edi
  762654:	mov    $0xe0,%esi
  762659:	call   *0x3568f9(%rip)        # ab8f58 <_DYNAMIC+0x2f8>
  76265f:	jmp    762698 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2008>
  762661:	mov    %r15,0x1a8(%rsp)
  762669:	mov    %r12,0x130(%rsp)
  762671:	mov    $0x4,%edi
  762676:	mov    %rbx,%rsi
  762679:	call   *0x3568d9(%rip)        # ab8f58 <_DYNAMIC+0x2f8>
  76267f:	jmp    762698 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2008>
  762681:	lea    0x336888(%rip),%rdx        # a98f10 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x7d8>
  762688:	mov    $0x1,%edi
  76268d:	mov    $0x1,%esi
  762692:	call   *0x356838(%rip)        # ab8ed0 <_DYNAMIC+0x270>
  762698:	ud2
  76269a:	mov    0x38(%rsp),%rdi
  76269f:	mov    $0x1,%edx
  7626a4:	call   *0x3567f6(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  7626aa:	jmp    762453 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1dc3>
  7626af:	mov    0x168(%rsp),%rbx
  7626b7:	jmp    762453 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1dc3>
  7626bc:	jmp    7626be <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x202e>
  7626be:	mov    %rax,%rbx
  7626c1:	mov    0x1b0(%rsp),%rax
  7626c9:	mov    $0x1,%bpl
  7626cc:	test   %rax,%rax
  7626cf:	je     7628f5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2265>
  7626d5:	mov    0x1b8(%rsp),%rdi
  7626dd:	imul   $0x38,%rax,%rsi
  7626e1:	mov    $0x8,%edx
  7626e6:	jmp    7628ef <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x225f>
  7626eb:	mov    %rax,%rbx
  7626ee:	mov    $0x1,%bpl
  7626f1:	mov    0x1a8(%rsp),%rax
  7626f9:	test   %rax,%rax
  7626fc:	jne    7628de <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x224e>
  762702:	jmp    7628f5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2265>
  762707:	jmp    7627db <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x214b>
  76270c:	jmp    7627db <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x214b>
  762711:	mov    %rax,%rbx
  762714:	jmp    76288c <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x21fc>
  762719:	mov    %rax,%rbx
  76271c:	xor    %ebp,%ebp
  76271e:	jmp    762902 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2272>
  762723:	jmp    7627db <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x214b>
  762728:	jmp    7627c4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2134>
  76272d:	jmp    7627db <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x214b>
  762732:	mov    %rax,%rbx
  762735:	jmp    762876 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x21e6>
  76273a:	mov    %rax,%rbx
  76273d:	mov    (%rsp),%r15
  762741:	jmp    76289f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x220f>
  762746:	mov    %rax,%rbx
  762749:	jmp    762963 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x22d3>
  76274e:	jmp    762855 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x21c5>
  762753:	mov    %rax,%rbx
  762756:	mov    0x30(%rsp),%rsi
  76275b:	test   %rsi,%rsi
  76275e:	jle    762858 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x21c8>
  762764:	mov    0x38(%rsp),%rdi
  762769:	mov    $0x1,%edx
  76276e:	call   *0x35672c(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  762774:	jmp    762858 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x21c8>
  762779:	mov    %rax,%rbx
  76277c:	lea    0x70(%rsp),%rdi
  762781:	call   74c7e0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5error5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  762786:	jmp    762858 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x21c8>
  76278b:	call   *0x356737(%rip)        # ab8ec8 <_DYNAMIC+0x268>
  762791:	mov    %rax,%rbx
  762794:	lea    0x70(%rsp),%rdi
  762799:	call   74d540 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  76279e:	mov    (%rsp),%r15
  7627a2:	jmp    76282f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x219f>
  7627a7:	mov    %rax,%rbx
  7627aa:	lea    0x30(%rsp),%rdi
  7627af:	call   74df60 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCscl5MXVnO7Zx_10serde_json5value3ser12SerializeMapECs9C2G9YFESsD_29canonical_text_public_control>
  7627b4:	jmp    762858 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x21c8>
  7627b9:	call   *0x356709(%rip)        # ab8ec8 <_DYNAMIC+0x268>
  7627bf:	jmp    762855 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x21c5>
  7627c4:	mov    %rax,%rbx
  7627c7:	mov    (%rsp),%r15
  7627cb:	jmp    76282f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x219f>
  7627cd:	jmp    76282c <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x219c>
  7627cf:	mov    %rax,%rbx
  7627d2:	jmp    762876 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x21e6>
  7627d7:	jmp    7627db <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x214b>
  7627d9:	jmp    7627db <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x214b>
  7627db:	mov    %rax,%rbx
  7627de:	lea    0x70(%rsp),%rdi
  7627e3:	call   74d540 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  7627e8:	jmp    762858 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x21c8>
  7627ea:	mov    %rax,%rbx
  7627ed:	lea    0x70(%rsp),%rdi
  7627f2:	call   74d540 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  7627f7:	jmp    762876 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x21e6>
  7627f9:	mov    %rax,%rbx
  7627fc:	mov    $0x1,%bpl
  7627ff:	jmp    76293e <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x22ae>
  762804:	mov    %rax,%rbx
  762807:	mov    0x38(%rsp),%rdi
  76280c:	call   74cab0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text10TextShaperECs9C2G9YFESsD_29canonical_text_public_control>
  762811:	mov    $0x1,%bpl
  762814:	jmp    762902 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2272>
  762819:	mov    %rax,%rbx
  76281c:	jmp    76291e <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x228e>
  762821:	mov    %rax,%rbx
  762824:	mov    $0x1,%bpl
  762827:	jmp    7628f5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2265>
  76282c:	mov    %rax,%rbx
  76282f:	mov    0x1e8(%rsp),%rsi
  762837:	test   %rsi,%rsi
  76283a:	je     76287a <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x21ea>
  76283c:	mov    0x1f0(%rsp),%rdi
  762844:	shl    $0x4,%rsi
  762848:	mov    $0x4,%edx
  76284d:	call   *0x35664d(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  762853:	jmp    76287a <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x21ea>
  762855:	mov    %rax,%rbx
  762858:	mov    0x8(%rsp),%rdi
  76285d:	mov    0x10(%rsp),%rsi
  762862:	test   %rsi,%rsi
  762865:	je     762876 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x21e6>
  762867:	shl    $0x4,%rsi
  76286b:	mov    $0x4,%edx
  762870:	call   *0x35662a(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  762876:	mov    (%rsp),%r15
  76287a:	mov    0x18(%rsp),%r14
  76287f:	test   %r14,%r14
  762882:	je     76289f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x220f>
  762884:	mov    %r14,%rdi
  762887:	call   747d30 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui7runtime7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEEB1h_>
  76288c:	mov    $0x770,%esi
  762891:	mov    $0x8,%edx
  762896:	mov    %r14,%rdi
  762899:	call   *0x356601(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  76289f:	test   %r15,%r15
  7628a2:	jne    7628b5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2225>
  7628a4:	xor    %ebp,%ebp
  7628a6:	mov    0x1a8(%rsp),%rax
  7628ae:	test   %rax,%rax
  7628b1:	jne    7628de <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x224e>
  7628b3:	jmp    7628f5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2265>
  7628b5:	shl    $0x2,%r15
  7628b9:	mov    $0x4,%edx
  7628be:	mov    0xf8(%rsp),%rdi
  7628c6:	mov    %r15,%rsi
  7628c9:	call   *0x3565d1(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  7628cf:	xor    %ebp,%ebp
  7628d1:	mov    0x1a8(%rsp),%rax
  7628d9:	test   %rax,%rax
  7628dc:	je     7628f5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2265>
  7628de:	imul   $0x38,%rax,%rsi
  7628e2:	mov    $0x8,%edx
  7628e7:	mov    0x130(%rsp),%rdi
  7628ef:	call   *0x3565ab(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  7628f5:	lea    0x300(%rsp),%rdi
  7628fd:	call   74ca20 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text10TextLayoutECs9C2G9YFESsD_29canonical_text_public_control>
  762902:	mov    0x140(%rsp),%rax
  76290a:	lock decq (%rax)
  76290e:	jne    76291e <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x228e>
  762910:	lea    0x140(%rsp),%rdi
  762918:	call   *0x356672(%rip)        # ab8f90 <_DYNAMIC+0x330>
  76291e:	mov    0x260(%rsp),%rsi
  762926:	test   %rsi,%rsi
  762929:	je     76293e <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x22ae>
  76292b:	mov    0x268(%rsp),%rdi
  762933:	mov    $0x1,%edx
  762938:	call   *0x356562(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  76293e:	mov    0x148(%rsp),%rsi
  762946:	test   %rsi,%rsi
  762949:	je     76295e <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x22ce>
  76294b:	mov    0x150(%rsp),%rdi
  762953:	mov    $0x1,%edx
  762958:	call   *0x356542(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  76295e:	test   %bpl,%bpl
  762961:	je     762970 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x22e0>
  762963:	mov    0x248(%rsp),%rsi
  76296b:	test   %rsi,%rsi
  76296e:	jne    762978 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x22e8>
  762970:	mov    %rbx,%rdi
  762973:	call   a97380 <_Unwind_Resume@plt>
  762978:	mov    0x250(%rsp),%rdi
  762980:	mov    $0x1,%edx
  762985:	call   *0x356515(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  76298b:	mov    %rbx,%rdi
  76298e:	call   a97380 <_Unwind_Resume@plt>
  762993:	mov    $0x770,%esi
  762998:	mov    $0x8,%edx
  76299d:	mov    %r14,%rdi
  7629a0:	call   *0x3564fa(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  7629a6:	call   *0x35651c(%rip)        # ab8ec8 <_DYNAMIC+0x268>
  7629ac:	call   *0x356516(%rip)        # ab8ec8 <_DYNAMIC+0x268>

canonical_text_public_control::main bytes=9007 frame=760

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007629c0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main>:
  7629c0:	push   %rbp
  7629c1:	push   %r15
  7629c3:	push   %r14
  7629c5:	push   %r13
  7629c7:	push   %r12
  7629c9:	push   %rbx
  7629ca:	sub    $0x2c8,%rsp
  7629d1:	lea    0x60(%rsp),%rbx
  7629d6:	mov    %rbx,%rdi
  7629d9:	call   *0x356799(%rip)        # ab9178 <_DYNAMIC+0x518>
  7629df:	movq   $0x0,0x80(%rsp)
  7629eb:	lea    0x150(%rsp),%rdi
  7629f3:	mov    $0x1,%edx
  7629f8:	mov    %rbx,%rsi
  7629fb:	call   798af0 <_RNvYNtNtCs2AWtUsOyxgP_3std3env4ArgsNtNtNtNtCs4NRVxsYgnAr_4core4iter6traits8iterator8Iterator3nthCs9C2G9YFESsD_29canonical_text_public_control>
  762a00:	mov    0x150(%rsp),%rax
  762a08:	mov    %rax,0x18(%rsp)
  762a0d:	cmp    $0xffffffffffffffff,%rax
  762a11:	je     76467c <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1cbc>
  762a17:	mov    0x158(%rsp),%rbx
  762a1f:	mov    0x78(%rsp),%rax
  762a24:	sub    0x68(%rsp),%rax
  762a29:	shr    $0x3,%rax
  762a2d:	movabs $0xaaaaaaaaaaaaaaab,%rcx
  762a37:	imul   %rcx,%rax
  762a3b:	xor    %r14d,%r14d
  762a3e:	sub    0x80(%rsp),%rax
  762a46:	cmovb  %r14,%rax
  762a4a:	cmp    $0x4,%rax
  762a4e:	mov    $0x3,%r12d
  762a54:	cmovae %rax,%r12
  762a58:	lea    0x8(,%r12,8),%rcx
  762a60:	lea    (%rcx,%rcx,2),%r15
  762a64:	movabs $0x555555555555554,%rcx
  762a6e:	cmp    %rcx,%rax
  762a71:	jbe    762a84 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xc4>
  762a73:	mov    %r14,%rdi
  762a76:	mov    %r15,%rsi
  762a79:	call   *0x3564d9(%rip)        # ab8f58 <_DYNAMIC+0x2f8>
  762a7f:	jmp    764764 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  762a84:	mov    0x160(%rsp),%rbp
  762a8c:	test   %r15,%r15
  762a8f:	je     762ab8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xf8>
  762a91:	call   *0x356411(%rip)        # ab8ea8 <_DYNAMIC+0x248>
  762a97:	mov    $0x8,%r14d
  762a9d:	mov    $0x8,%esi
  762aa2:	mov    %r15,%rdi
  762aa5:	call   *0x356405(%rip)        # ab8eb0 <_DYNAMIC+0x250>
  762aab:	test   %rax,%rax
  762aae:	je     762a73 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xb3>
  762ab0:	mov    %rax,%r13
  762ab3:	inc    %r12
  762ab6:	jmp    762ac1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x101>
  762ab8:	mov    $0x8,%r13d
  762abe:	xor    %r12d,%r12d
  762ac1:	mov    0x18(%rsp),%rax
  762ac6:	mov    %rax,0x0(%r13)
  762aca:	mov    %rbx,0x8(%r13)
  762ace:	mov    %rbp,0x10(%r13)
  762ad2:	mov    %r12,0x28(%rsp)
  762ad7:	mov    %r13,0x30(%rsp)
  762adc:	movq   $0x1,0x38(%rsp)
  762ae5:	mov    0x80(%rsp),%rax
  762aed:	mov    %rax,0x170(%rsp)
  762af5:	movups 0x60(%rsp),%xmm0
  762afa:	movups 0x70(%rsp),%xmm1
  762aff:	movaps %xmm1,0x160(%rsp)
  762b07:	movaps %xmm0,0x150(%rsp)
  762b0f:	mov    $0x1,%ebx
  762b14:	mov    $0x28,%r15d
  762b1a:	jmp    762b5b <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x19b>
  762b1c:	nopl   0x0(%rax)
  762b20:	inc    %rdx
  762b23:	mov    $0x8,%ecx
  762b28:	mov    $0x18,%r8d
  762b2e:	lea    0x28(%rsp),%rdi
  762b33:	mov    %rbx,%rsi
  762b36:	call   75b120 <_RINvNvMs2_NtCscdodAO9FK5_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs9C2G9YFESsD_29canonical_text_public_control>
  762b3b:	mov    0x30(%rsp),%r13
  762b40:	mov    %r14,-0x10(%r13,%r15,1)
  762b45:	mov    %rbp,-0x8(%r13,%r15,1)
  762b4a:	mov    %r12,0x0(%r13,%r15,1)
  762b4f:	inc    %rbx
  762b52:	mov    %rbx,0x38(%rsp)
  762b57:	add    $0x18,%r15
  762b5b:	mov    0x170(%rsp),%rdx
  762b63:	test   %rdx,%rdx
  762b66:	jne    762bda <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x21a>
  762b68:	lea    0x1f0(%rsp),%rdi
  762b70:	lea    0x150(%rsp),%rsi
  762b78:	call   *0x356602(%rip)        # ab9180 <_DYNAMIC+0x520>
  762b7e:	mov    0x1f0(%rsp),%r14
  762b86:	cmp    $0xffffffffffffffff,%r14
  762b8a:	je     762bfd <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x23d>
  762b8c:	mov    0x1f8(%rsp),%rbp
  762b94:	mov    0x200(%rsp),%r12
  762b9c:	cmp    0x28(%rsp),%rbx
  762ba1:	jne    762b40 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x180>
  762ba3:	mov    0x168(%rsp),%rdx
  762bab:	sub    0x158(%rsp),%rdx
  762bb3:	shr    $0x3,%rdx
  762bb7:	movabs $0xaaaaaaaaaaaaaaab,%rax
  762bc1:	imul   %rax,%rdx
  762bc5:	sub    0x170(%rsp),%rdx
  762bcd:	jae    762b20 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x160>
  762bd3:	xor    %edx,%edx
  762bd5:	jmp    762b20 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x160>
  762bda:	movq   $0x0,0x170(%rsp)
  762be6:	lea    0x1f0(%rsp),%rdi
  762bee:	lea    0x150(%rsp),%rsi
  762bf6:	call   798af0 <_RNvYNtNtCs2AWtUsOyxgP_3std3env4ArgsNtNtNtNtCs4NRVxsYgnAr_4core4iter6traits8iterator8Iterator3nthCs9C2G9YFESsD_29canonical_text_public_control>
  762bfb:	jmp    762b7e <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1be>
  762bfd:	mov    0x158(%rsp),%r15
  762c05:	mov    0x168(%rsp),%rcx
  762c0d:	mov    %rcx,%rax
  762c10:	sub    %r15,%rax
  762c13:	movabs $0xaaaaaaaaaaaaaaab,%rdx
  762c1d:	mul    %rdx
  762c20:	cmp    %r15,%rcx
  762c23:	je     762c5f <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x29f>
  762c25:	mov    %rdx,%r14
  762c28:	shr    $0x4,%r14
  762c2c:	add    $0x8,%r15
  762c30:	mov    0x356269(%rip),%r12        # ab8ea0 <_DYNAMIC+0x240>
  762c37:	jmp    762c49 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x289>
  762c39:	nopl   0x0(%rax)
  762c40:	add    $0x18,%r15
  762c44:	dec    %r14
  762c47:	je     762c5f <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x29f>
  762c49:	mov    -0x8(%r15),%rsi
  762c4d:	test   %rsi,%rsi
  762c50:	je     762c40 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x280>
  762c52:	mov    (%r15),%rdi
  762c55:	mov    $0x1,%edx
  762c5a:	call   *%r12
  762c5d:	jmp    762c40 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x280>
  762c5f:	mov    0x160(%rsp),%rax
  762c67:	test   %rax,%rax
  762c6a:	je     762c87 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2c7>
  762c6c:	mov    0x150(%rsp),%rdi
  762c74:	shl    $0x3,%rax
  762c78:	lea    (%rax,%rax,2),%rsi
  762c7c:	mov    $0x8,%edx
  762c81:	call   *0x356219(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  762c87:	mov    0x28(%rsp),%rax
  762c8c:	mov    %rax,0x280(%rsp)
  762c94:	mov    0x30(%rsp),%rcx
  762c99:	mov    0x8(%rcx),%rax
  762c9d:	mov    %rcx,0x20(%rsp)
  762ca2:	mov    0x10(%rcx),%rcx
  762ca6:	cmp    $0x6,%rcx
  762caa:	jne    7632d1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x911>
  762cb0:	mov    $0x6361726f,%ecx
  762cb5:	xor    (%rax),%ecx
  762cb7:	movzwl 0x4(%rax),%eax
  762cbb:	xor    $0x656c,%eax
  762cc0:	or     %ecx,%eax
  762cc2:	jne    7646d8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1d18>
  762cc8:	movq   $0x0,0x150(%rsp)
  762cd4:	movq   $0x8,0x158(%rsp)
  762ce0:	movups 0x3366f1(%rip),%xmm0        # a993d8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xca0>
  762ce7:	movups %xmm0,0x160(%rsp)
  762cef:	movups 0x3366f2(%rip),%xmm0        # a993e8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xcb0>
  762cf6:	movups %xmm0,0x170(%rsp)
  762cfe:	movups 0x3366f3(%rip),%xmm0        # a993f8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xcc0>
  762d05:	movups %xmm0,0x180(%rsp)
  762d0d:	movups 0x3366f4(%rip),%xmm0        # a99408 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xcd0>
  762d14:	movups %xmm0,0x190(%rsp)
  762d1c:	movups 0x3366f5(%rip),%xmm0        # a99418 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xce0>
  762d23:	movups %xmm0,0x1a0(%rsp)
  762d2b:	movups 0x3366f6(%rip),%xmm0        # a99428 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xcf0>
  762d32:	movups %xmm0,0x1b0(%rsp)
  762d3a:	movups 0x3366f7(%rip),%xmm0        # a99438 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xd00>
  762d41:	movups %xmm0,0x1c0(%rsp)
  762d49:	movups 0x3366f8(%rip),%xmm0        # a99448 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xd10>
  762d50:	movups %xmm0,0x1d0(%rsp)
  762d58:	mov    $0x1,%r14d
  762d5e:	lea    0x2a8(%rsp),%r15
  762d66:	lea    0x60(%rsp),%rbp
  762d6b:	xor    %r12d,%r12d
  762d6e:	jmp    762db3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x3f3>
  762d70:	mov    $0x770,%esi
  762d75:	mov    $0x8,%edx
  762d7a:	mov    %r14,%rdi
  762d7d:	call   *0x35611d(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  762d83:	mov    0xf0(%rsp),%r14
  762d8b:	xor    %r12,%r14
  762d8e:	movabs $0x100000001b3,%rax
  762d98:	imul   %rax,%r14
  762d9c:	mov    %r13,0x2a0(%rsp)
  762da4:	mov    0x10(%rsp),%r12
  762da9:	cmp    $0x8,%r12
  762dad:	je     763324 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x964>
  762db3:	mov    %r12,%rax
  762db6:	shl    $0x4,%rax
  762dba:	lea    0x160(%rsp),%rcx
  762dc2:	mov    (%rcx,%rax,1),%rsi
  762dc6:	mov    0x8(%rcx,%rax,1),%rdx
  762dcb:	mov    %r15,%rdi
  762dce:	call   7657f0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source>
  762dd3:	mov    %rbp,%rdi
  762dd6:	mov    %r15,%rsi
  762dd9:	call   *0x356349(%rip)        # ab9128 <_DYNAMIC+0x4c8>
  762ddf:	mov    %rbp,%rdi
  762de2:	call   764cf0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount>
  762de7:	mov    %rax,%r13
  762dea:	mov    %rax,0x260(%rsp)
  762df2:	cmpb   $0x0,0x76e(%rax)
  762df9:	jne    764489 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ac9>
  762dff:	cmpb   $0x1,0x76a(%r13)
  762e07:	jne    764482 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ac2>
  762e0d:	mov    %r14,0xf0(%rsp)
  762e15:	mov    0x5c0(%r13),%r15
  762e1c:	mov    $0x1a,%eax
  762e21:	mov    %rax,0x1e8(%rsp)
  762e29:	test   %r15,%r15
  762e2c:	je     764496 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ad6>
  762e32:	inc    %r12
  762e35:	mov    %r12,0x10(%rsp)
  762e3a:	mov    0x5b8(%r13),%rbp
  762e41:	shl    $0x6,%r15
  762e45:	lea    0x1e8(%r13),%r14
  762e4c:	xor    %r12d,%r12d
  762e4f:	jmp    762e6d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x4ad>
  762e51:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  762e60:	add    $0x40,%r12
  762e64:	cmp    %r12,%r15
  762e67:	je     764496 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ad6>
  762e6d:	cmpb   $0x4,0x3d(%rbp,%r12,1)
  762e73:	jne    762e60 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x4a0>
  762e75:	mov    0x20(%rbp,%r12,1),%rsi
  762e7a:	mov    %r14,%rdi
  762e7d:	call   *0x3560dd(%rip)        # ab8f60 <_DYNAMIC+0x300>
  762e83:	test   %al,%al
  762e85:	je     762e60 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x4a0>
  762e87:	mov    0x20(%rbp,%r12,1),%rsi
  762e8c:	add    $0x5f0,%r13
  762e93:	mov    %r13,%rdi
  762e96:	call   *0x356264(%rip)        # ab9100 <_DYNAMIC+0x4a0>
  762e9c:	mov    %rax,%r14
  762e9f:	mov    %rdx,%r12
  762ea2:	mov    0x260(%rsp),%rsi
  762eaa:	lea    0x100(%rsp),%rdi
  762eb2:	call   75c8b0 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_>
  762eb7:	mov    0x2b8(%rsp),%rax
  762ebf:	mov    %rax,%rcx
  762ec2:	shr    $0x20,%rcx
  762ec6:	lea    0x2a8(%rsp),%r15
  762ece:	lea    0x60(%rsp),%rbp
  762ed3:	jne    76424b <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x188b>
  762ed9:	movl   $0x0,0x60(%rsp)
  762ee1:	movb   $0x1,0x64(%rsp)
  762ee6:	mov    %eax,0x68(%rsp)
  762eea:	movb   $0x1,0x6c(%rsp)
  762eef:	mov    0x260(%rsp),%rsi
  762ef7:	test   %rsi,%rsi
  762efa:	je     7644e4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1b24>
  762f00:	lea    0x1f0(%rsp),%rdi
  762f08:	mov    %r14,0x18(%rsp)
  762f0d:	mov    %r14,%rdx
  762f10:	mov    %r12,0xf8(%rsp)
  762f18:	mov    %r12,%rcx
  762f1b:	mov    %rbp,%r8
  762f1e:	call   76ef20 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE12select_inputB12_>
  762f23:	cmpq   $0xfffffffffffffffe,0x1f0(%rsp)
  762f2c:	jne    7644fc <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1b3c>
  762f32:	mov    0x260(%rsp),%rax
  762f3a:	test   %rax,%rax
  762f3d:	je     76456d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1bad>
  762f43:	cmpb   $0x0,0x76e(%rax)
  762f4a:	jne    764580 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1bc0>
  762f50:	mov    0x6d0(%rax),%r13
  762f57:	test   %r13,%r13
  762f5a:	je     764587 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1bc7>
  762f60:	mov    0x6d8(%rax),%r12
  762f67:	mov    %rax,0x28(%rsp)
  762f6c:	lea    0x268(%rsp),%rax
  762f74:	mov    %rax,0x30(%rsp)
  762f79:	movb   $0x2,0x1fc(%rsp)
  762f81:	movq   $0x3,(%rsp)
  762f89:	mov    %rbp,%rdi
  762f8c:	lea    0x28(%rsp),%rsi
  762f91:	mov    0x18(%rsp),%rdx
  762f96:	mov    0xf8(%rsp),%rcx
  762f9e:	lea    0x1f0(%rsp),%r8
  762fa6:	lea    -0x6935f0(%rip),%r9        # cf9bd <GCC_except_table0+0xd655>
  762fad:	call   76f150 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_>
  762fb2:	mov    0x60(%rsp),%rax
  762fb7:	cmp    $0xfffffffffffffffe,%rax
  762fbb:	je     764453 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1a93>
  762fc1:	cmp    $0x23,%eax
  762fc4:	jne    764453 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1a93>
  762fca:	mov    0x260(%rsp),%rsi
  762fd2:	mov    %rbp,%rdi
  762fd5:	call   75c8b0 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_>
  762fda:	mov    0x70(%rsp),%rdx
  762fdf:	cmp    0x110(%rsp),%rdx
  762fe7:	jne    764206 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1846>
  762fed:	mov    0x108(%rsp),%rsi
  762ff5:	mov    0x68(%rsp),%r14
  762ffa:	mov    %r14,%rdi
  762ffd:	call   *0x356165(%rip)        # ab9168 <bcmp@GLIBC_2.2.5>
  763003:	test   %eax,%eax
  763005:	jne    764206 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1846>
  76300b:	mov    0x78(%rsp),%eax
  76300f:	cmp    0x118(%rsp),%eax
  763016:	jne    764206 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1846>
  76301c:	movzbl 0x7c(%rsp),%eax
  763021:	cmp    0x11c(%rsp),%al
  763028:	jne    764206 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1846>
  76302e:	mov    0x80(%rsp),%eax
  763035:	cmp    0x120(%rsp),%eax
  76303c:	jne    764206 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1846>
  763042:	movzbl 0x84(%rsp),%eax
  76304a:	cmp    0x124(%rsp),%al
  763051:	jne    764206 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1846>
  763057:	mov    0x88(%rsp),%rax
  76305f:	cmp    0x128(%rsp),%rax
  763067:	jne    764206 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1846>
  76306d:	mov    0x90(%rsp),%rax
  763075:	cmp    0x130(%rsp),%rax
  76307d:	jne    764206 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1846>
  763083:	mov    0x60(%rsp),%rsi
  763088:	test   %rsi,%rsi
  76308b:	je     76309b <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x6db>
  76308d:	mov    $0x1,%edx
  763092:	mov    %r14,%rdi
  763095:	call   *0x355e05(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  76309b:	mov    0x260(%rsp),%rsi
  7630a3:	test   %rsi,%rsi
  7630a6:	je     7645d2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1c12>
  7630ac:	cmpb   $0x0,0x76e(%rsi)
  7630b3:	jne    7645ec <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1c2c>
  7630b9:	lea    0x1f0(%rsp),%rdi
  7630c1:	mov    %r13,%rdx
  7630c4:	mov    %r12,%rcx
  7630c7:	call   77ae10 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_>
  7630cc:	cmpq   $0xfffffffffffffffe,0x1f0(%rsp)
  7630d5:	jne    7645f8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1c38>
  7630db:	mov    0x260(%rsp),%rsi
  7630e3:	lea    0x28(%rsp),%rdi
  7630e8:	call   75c8b0 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_>
  7630ed:	mov    0x38(%rsp),%r14
  7630f2:	cmp    0x2b8(%rsp),%r14
  7630fa:	jne    76421d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x185d>
  763100:	mov    0x2b0(%rsp),%rsi
  763108:	mov    0x30(%rsp),%rdi
  76310d:	mov    %r14,%rdx
  763110:	call   *0x356052(%rip)        # ab9168 <bcmp@GLIBC_2.2.5>
  763116:	test   %eax,%eax
  763118:	jne    76421d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x185d>
  76311e:	mov    %r14,%rax
  763121:	shr    $0x20,%rax
  763125:	jne    76425d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x189d>
  76312b:	movl   $0x0,0x60(%rsp)
  763133:	movb   $0x1,0x64(%rsp)
  763138:	mov    %r14d,0x68(%rsp)
  76313d:	movb   $0x1,0x6c(%rsp)
  763142:	cmpl   $0x0,0x40(%rsp)
  763147:	jne    763297 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x8d7>
  76314d:	movzbl 0x44(%rsp),%eax
  763152:	cmp    %r14d,0x48(%rsp)
  763157:	sete   %cl
  76315a:	test   %al,%al
  76315c:	je     7632a9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x8e9>
  763162:	test   %cl,%cl
  763164:	je     7632b3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x8f3>
  76316a:	movzbl 0x4c(%rsp),%eax
  76316f:	test   %al,%al
  763171:	je     7632bd <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x8fd>
  763177:	mov    %r12,0x8(%rsp)
  76317c:	mov    0x50(%rsp),%rcx
  763181:	mov    0x58(%rsp),%r12
  763186:	mov    %rcx,0x1f0(%rsp)
  76318e:	mov    %r12,0x1f8(%rsp)
  763196:	mov    0x128(%rsp),%rdx
  76319e:	mov    0x130(%rsp),%rax
  7631a6:	mov    %rdx,0x60(%rsp)
  7631ab:	mov    %rax,0x68(%rsp)
  7631b0:	cmp    %rdx,%rcx
  7631b3:	jne    764234 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1874>
  7631b9:	cmp    %rax,%r12
  7631bc:	jne    764234 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1874>
  7631c2:	lea    0x1f0(%rsp),%rdi
  7631ca:	lea    0x260(%rsp),%rsi
  7631d2:	lea    0x336327(%rip),%rdx        # a99500 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xdc8>
  7631d9:	mov    %r15,%rcx
  7631dc:	call   7447f0 <_RINvMst_NtCslbxve4rcJus_4gpui7runtimeINtB6_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE3setNtNtCscdodAO9FK5_5alloc6string6StringEBL_>
  7631e1:	cmpl   $0xffffffff,0x1f0(%rsp)
  7631e9:	jne    76426f <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x18af>
  7631ef:	mov    0x260(%rsp),%rsi
  7631f7:	mov    %rbp,%rdi
  7631fa:	call   760520 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack>
  7631ff:	mov    0x260(%rsp),%rsi
  763207:	mov    %rbp,%rdi
  76320a:	call   75c8b0 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_>
  76320f:	mov    0x90(%rsp),%rax
  763217:	cmp    0x130(%rsp),%rax
  76321f:	jne    764303 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1943>
  763225:	mov    0x60(%rsp),%rsi
  76322a:	test   %rsi,%rsi
  76322d:	je     76323f <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x87f>
  76322f:	mov    0x68(%rsp),%rdi
  763234:	mov    $0x1,%edx
  763239:	call   *0x355c61(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  76323f:	mov    0x28(%rsp),%rsi
  763244:	test   %rsi,%rsi
  763247:	je     763259 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x899>
  763249:	mov    0x30(%rsp),%rdi
  76324e:	mov    $0x1,%edx
  763253:	call   *0x355c47(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  763259:	mov    0x100(%rsp),%rsi
  763261:	test   %rsi,%rsi
  763264:	je     763279 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x8b9>
  763266:	mov    0x108(%rsp),%rdi
  76326e:	mov    $0x1,%edx
  763273:	call   *0x355c27(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  763279:	mov    0x260(%rsp),%r14
  763281:	test   %r14,%r14
  763284:	je     762d83 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x3c3>
  76328a:	mov    %r14,%rdi
  76328d:	call   747d30 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui7runtime7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEEB1h_>
  763292:	jmp    762d70 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x3b0>
  763297:	xor    %eax,%eax
  763299:	cmp    %r14d,0x48(%rsp)
  76329e:	sete   %cl
  7632a1:	test   %al,%al
  7632a3:	jne    763162 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x7a2>
  7632a9:	xor    %ecx,%ecx
  7632ab:	test   %cl,%cl
  7632ad:	jne    76316a <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x7aa>
  7632b3:	xor    %eax,%eax
  7632b5:	test   %al,%al
  7632b7:	jne    763177 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x7b7>
  7632bd:	lea    0x60(%rsp),%rsi
  7632c2:	lea    0x40(%rsp),%rdi
  7632c7:	call   74f2f5 <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout13TextSelectionBM_ECs9C2G9YFESsD_29canonical_text_public_control>
  7632cc:	jmp    764764 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  7632d1:	cmp    $0x7,%rcx
  7632d5:	jne    7646d8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1d18>
  7632db:	mov    $0x7361656d,%ecx
  7632e0:	xor    (%rax),%ecx
  7632e2:	mov    $0x65727573,%edx
  7632e7:	xor    0x3(%rax),%edx
  7632ea:	or     %ecx,%edx
  7632ec:	jne    7646d8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1d18>
  7632f2:	cmp    $0x3,%rbx
  7632f6:	jbe    76472f <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1d6f>
  7632fc:	mov    0x20(%rsp),%rax
  763301:	mov    0x50(%rax),%rcx
  763305:	mov    0x58(%rax),%rsi
  763309:	cmp    $0x1,%rsi
  76330d:	je     763b0b <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x114b>
  763313:	test   %rsi,%rsi
  763316:	je     764766 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da6>
  76331c:	movzbl (%rcx),%edx
  76331f:	jmp    763b22 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1162>
  763324:	mov    %r14,0x60(%rsp)
  763329:	mov    %rbp,0x150(%rsp)
  763331:	mov    0x355e50(%rip),%rax        # ab9188 <_DYNAMIC+0x528>
  763338:	mov    %rax,0x158(%rsp)
  763340:	lea    -0x699624(%rip),%rdi        # c9d23 <GCC_except_table0+0x79bb>
  763347:	lea    0x150(%rsp),%rsi
  76334f:	call   *0x355e3b(%rip)        # ab9190 <_DYNAMIC+0x530>
  763355:	movq   $0x0,0x60(%rsp)
  76335e:	movq   $0x8,0x68(%rsp)
  763367:	movups 0x33606a(%rip),%xmm0        # a993d8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xca0>
  76336e:	movups %xmm0,0x70(%rsp)
  763373:	movups 0x33606e(%rip),%xmm0        # a993e8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xcb0>
  76337a:	movups %xmm0,0x80(%rsp)
  763382:	movups 0x33606f(%rip),%xmm0        # a993f8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xcc0>
  763389:	movups %xmm0,0x90(%rsp)
  763391:	movups 0x336070(%rip),%xmm0        # a99408 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xcd0>
  763398:	movups %xmm0,0xa0(%rsp)
  7633a0:	movups 0x336071(%rip),%xmm0        # a99418 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xce0>
  7633a7:	movups %xmm0,0xb0(%rsp)
  7633af:	movups 0x336072(%rip),%xmm0        # a99428 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xcf0>
  7633b6:	movups %xmm0,0xc0(%rsp)
  7633be:	movups 0x336073(%rip),%xmm0        # a99438 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xd00>
  7633c5:	movups %xmm0,0xd0(%rsp)
  7633cd:	movups 0x336074(%rip),%xmm0        # a99448 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xd10>
  7633d4:	movups %xmm0,0xe0(%rsp)
  7633dc:	xor    %eax,%eax
  7633de:	lea    0x1f0(%rsp),%r12
  7633e6:	jmp    7633ff <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xa3f>
  7633e8:	nopl   0x0(%rax,%rax,1)
  7633f0:	mov    0x8(%rsp),%rax
  7633f5:	cmp    $0x8,%rax
  7633f9:	je     76419a <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x17da>
  7633ff:	lea    0x1(%rax),%rcx
  763403:	mov    %rcx,0x8(%rsp)
  763408:	shl    $0x4,%rax
  76340c:	lea    0x70(%rsp),%rcx
  763411:	mov    (%rcx,%rax,1),%rdx
  763415:	mov    %rdx,0x18(%rsp)
  76341a:	mov    0x8(%rcx,%rax,1),%r13
  76341f:	movq   $0x0,0x150(%rsp)
  76342b:	movq   $0x8,0x158(%rsp)
  763437:	lea    -0x693940(%rip),%rax        # cfafe <GCC_except_table0+0xd796>
  76343e:	mov    %rax,0x160(%rsp)
  763446:	movq   $0x3,0x168(%rsp)
  763452:	lea    -0x693958(%rip),%rax        # cfb01 <GCC_except_table0+0xd799>
  763459:	mov    %rax,0x170(%rsp)
  763461:	movq   $0x9,0x178(%rsp)
  76346d:	lea    -0x69396a(%rip),%rax        # cfb0a <GCC_except_table0+0xd7a2>
  763474:	mov    %rax,0x180(%rsp)
  76347c:	movq   $0x6,0x188(%rsp)
  763488:	lea    -0x69397f(%rip),%rax        # cfb10 <GCC_except_table0+0xd7a8>
  76348f:	mov    %rax,0x190(%rsp)
  763497:	movq   $0x9,0x198(%rsp)
  7634a3:	lea    -0x693991(%rip),%rax        # cfb19 <GCC_except_table0+0xd7b1>
  7634aa:	mov    %rax,0x1a0(%rsp)
  7634b2:	movq   $0x7,0x1a8(%rsp)
  7634be:	lea    -0x6939f2(%rip),%rax        # cfad3 <GCC_except_table0+0xd76b>
  7634c5:	mov    %rax,0x1b0(%rsp)
  7634cd:	movq   $0x7,0x1b8(%rsp)
  7634d9:	lea    -0x693a12(%rip),%rax        # cface <GCC_except_table0+0xd766>
  7634e0:	mov    %rax,0x1c0(%rsp)
  7634e8:	movq   $0x5,0x1c8(%rsp)
  7634f4:	lea    -0x6a1107(%rip),%rax        # c23f4 <GCC_except_table0+0x8c>
  7634fb:	mov    %rax,0x1d0(%rsp)
  763503:	movq   $0x4,0x1d8(%rsp)
  76350f:	mov    $0x1,%r15d
  763515:	lea    0x168(%rsp),%rbp
  76351d:	mov    %r13,0xf0(%rsp)
  763525:	jmp    763549 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xb89>
  763527:	nopw   0x0(%rax,%rax,1)
  763530:	mov    0xf8(%rsp),%rbp
  763538:	add    $0x10,%rbp
  76353c:	inc    %r15
  76353f:	cmp    $0x9,%r15
  763543:	je     7633f0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xa30>
  763549:	mov    -0x8(%rbp),%r8
  76354d:	mov    %rbp,0xf8(%rsp)
  763555:	mov    0x0(%rbp),%r14
  763559:	cmp    $0x4,%r13
  76355d:	je     763600 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xc40>
  763563:	cmp    $0x5,%r13
  763567:	je     7635b0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xbf0>
  763569:	cmp    $0xd,%r13
  76356d:	jne    763629 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xc69>
  763573:	mov    0x18(%rsp),%rdx
  763578:	mov    (%rdx),%rcx
  76357b:	movabs $0x6172672d676e6f6c,%rax
  763585:	xor    %rax,%rcx
  763588:	mov    0x5(%rdx),%rdx
  76358c:	movabs $0x656d656870617267,%rax
  763596:	xor    %rax,%rdx
  763599:	xor    %eax,%eax
  76359b:	or     %rcx,%rdx
  76359e:	setne  %cl
  7635a1:	cmp    $0x4,%r14
  7635a5:	je     763616 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xc56>
  7635a7:	jmp    763629 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xc69>
  7635ac:	nopl   0x0(%rax)
  7635b0:	mov    0x18(%rsp),%rdx
  7635b5:	mov    (%rdx),%ecx
  7635b7:	mov    $0x74706d65,%eax
  7635bc:	xor    %eax,%ecx
  7635be:	movzbl 0x4(%rdx),%edx
  7635c2:	xor    $0x79,%edx
  7635c5:	xor    %eax,%eax
  7635c7:	or     %ecx,%edx
  7635c9:	setne  %al
  7635cc:	cmp    $0x5,%r14
  7635d0:	jne    763afc <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x113c>
  7635d6:	test   %eax,%eax
  7635d8:	jne    763afc <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x113c>
  7635de:	mov    (%r8),%eax
  7635e1:	mov    $0x6f727261,%ecx
  7635e6:	xor    %ecx,%eax
  7635e8:	movzbl 0x4(%r8),%ecx
  7635ed:	xor    $0x77,%ecx
  7635f0:	or     %eax,%ecx
  7635f2:	jne    763629 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xc69>
  7635f4:	jmp    763530 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xb70>
  7635f9:	nopl   0x0(%rax)
  763600:	xor    %eax,%eax
  763602:	mov    0x18(%rsp),%rcx
  763607:	cmpl   $0x796e6974,(%rcx)
  76360d:	setne  %cl
  763610:	cmp    $0x4,%r14
  763614:	jne    763629 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xc69>
  763616:	mov    %cl,%al
  763618:	test   %eax,%eax
  76361a:	jne    763629 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xc69>
  76361c:	cmpl   $0x67617264,(%r8)
  763623:	je     763530 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xb70>
  763629:	movl   $0x0,(%rsp)
  763630:	mov    $0x4,%r9d
  763636:	mov    %r12,%rdi
  763639:	mov    0x18(%rsp),%rsi
  76363e:	mov    %r13,%rdx
  763641:	mov    %r8,%rbp
  763644:	mov    %r8,%rcx
  763647:	mov    %r14,%r8
  76364a:	call   760690 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run>
  76364f:	mov    %r15,0x10(%rsp)
  763654:	mov    0x200(%rsp),%rax
  76365c:	mov    %rax,0x1e8(%rsp)
  763664:	lea    0x208(%rsp),%rax
  76366c:	movups (%rax),%xmm0
  76366f:	movups 0x10(%rax),%xmm1
  763673:	movaps %xmm1,0x270(%rsp)
  76367b:	movaps %xmm0,0x260(%rsp)
  763683:	movq   $0x0,0x288(%rsp)
  76368f:	movq   $0x0,0x298(%rsp)
  76369b:	call   *0x355807(%rip)        # ab8ea8 <_DYNAMIC+0x248>
  7636a1:	mov    $0x4,%r15d
  7636a7:	mov    $0x4,%edi
  7636ac:	mov    $0x1,%esi
  7636b1:	call   *0x3557f9(%rip)        # ab8eb0 <_DYNAMIC+0x250>
  7636b7:	test   %rax,%rax
  7636ba:	je     764367 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x19a7>
  7636c0:	mov    %rax,%r13
  7636c3:	movl   $0x65736163,(%rax)
  7636c9:	movq   $0x4,0x138(%rsp)
  7636d5:	mov    %rax,0x140(%rsp)
  7636dd:	movq   $0x4,0x148(%rsp)
  7636e9:	mov    0xf0(%rsp),%r12
  7636f1:	test   %r12,%r12
  7636f4:	je     763730 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xd70>
  7636f6:	call   *0x3557ac(%rip)        # ab8ea8 <_DYNAMIC+0x248>
  7636fc:	mov    $0x1,%esi
  763701:	mov    %r12,%rdi
  763704:	call   *0x3557a6(%rip)        # ab8eb0 <_DYNAMIC+0x250>
  76370a:	test   %rax,%rax
  76370d:	je     764429 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1a69>
  763713:	mov    %rax,%r15
  763716:	mov    %rax,%rdi
  763719:	mov    0x18(%rsp),%rsi
  76371e:	mov    %r12,%rdx
  763721:	call   *0x355799(%rip)        # ab8ec0 <memcpy@GLIBC_2.14>
  763727:	jmp    763736 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xd76>
  763729:	nopl   0x0(%rax)
  763730:	mov    $0x1,%r15d
  763736:	movb   $0x3,0x28(%rsp)
  76373b:	mov    %r12,0x30(%rsp)
  763740:	mov    %r15,0x38(%rsp)
  763745:	mov    %r12,0x40(%rsp)
  76374a:	lea    0x100(%rsp),%rdi
  763752:	lea    0x288(%rsp),%rsi
  76375a:	lea    0x138(%rsp),%rdx
  763762:	lea    0x28(%rsp),%rcx
  763767:	call   775b80 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  76376c:	cmpb   $0xff,0x100(%rsp)
  763774:	je     763783 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xdc3>
  763776:	lea    0x100(%rsp),%rdi
  76377e:	call   74c8d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  763783:	call   *0x35571f(%rip)        # ab8ea8 <_DYNAMIC+0x248>
  763789:	mov    $0x9,%r15d
  76378f:	mov    $0x9,%edi
  763794:	mov    $0x1,%esi
  763799:	call   *0x355711(%rip)        # ab8eb0 <_DYNAMIC+0x250>
  76379f:	test   %rax,%rax
  7637a2:	je     764367 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x19a7>
  7637a8:	movabs $0x6f6974617265706f,%rcx
  7637b2:	mov    %rcx,(%rax)
  7637b5:	movb   $0x6e,0x8(%rax)
  7637b9:	movq   $0x9,0x138(%rsp)
  7637c5:	mov    %rax,0x140(%rsp)
  7637cd:	movq   $0x9,0x148(%rsp)
  7637d9:	test   %r14,%r14
  7637dc:	je     763820 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xe60>
  7637de:	mov    %rax,%r13
  7637e1:	call   *0x3556c1(%rip)        # ab8ea8 <_DYNAMIC+0x248>
  7637e7:	mov    $0x1,%esi
  7637ec:	mov    %r14,%rdi
  7637ef:	call   *0x3556bb(%rip)        # ab8eb0 <_DYNAMIC+0x250>
  7637f5:	test   %rax,%rax
  7637f8:	je     7643ff <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1a3f>
  7637fe:	mov    %rax,%r15
  763801:	mov    %rax,%rdi
  763804:	mov    %rbp,%rsi
  763807:	mov    %r14,%rdx
  76380a:	call   *0x3556b0(%rip)        # ab8ec0 <memcpy@GLIBC_2.14>
  763810:	jmp    763826 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xe66>
  763812:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  763820:	mov    $0x1,%r15d
  763826:	movb   $0x3,0x28(%rsp)
  76382b:	mov    %r14,0x30(%rsp)
  763830:	mov    %r15,0x38(%rsp)
  763835:	mov    %r14,0x40(%rsp)
  76383a:	lea    0x100(%rsp),%rdi
  763842:	lea    0x288(%rsp),%rsi
  76384a:	lea    0x138(%rsp),%rdx
  763852:	lea    0x28(%rsp),%rcx
  763857:	call   775b80 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  76385c:	cmpb   $0xff,0x100(%rsp)
  763864:	je     763873 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xeb3>
  763866:	lea    0x100(%rsp),%rdi
  76386e:	call   74c8d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  763873:	call   *0x35562f(%rip)        # ab8ea8 <_DYNAMIC+0x248>
  763879:	mov    $0x5,%r15d
  76387f:	mov    $0x5,%edi
  763884:	mov    $0x1,%esi
  763889:	call   *0x355621(%rip)        # ab8eb0 <_DYNAMIC+0x250>
  76388f:	test   %rax,%rax
  763892:	je     764367 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x19a7>
  763898:	movb   $0x74,0x4(%rax)
  76389c:	movl   $0x6e756f63,(%rax)
  7638a2:	movq   $0x5,0x138(%rsp)
  7638ae:	mov    %rax,0x140(%rsp)
  7638b6:	movq   $0x5,0x148(%rsp)
  7638c2:	movb   $0x2,0x28(%rsp)
  7638c7:	movq   $0x0,0x30(%rsp)
  7638d0:	movq   $0x4,0x38(%rsp)
  7638d9:	lea    0x100(%rsp),%rdi
  7638e1:	lea    0x288(%rsp),%rsi
  7638e9:	lea    0x138(%rsp),%rdx
  7638f1:	lea    0x28(%rsp),%rcx
  7638f6:	call   775b80 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  7638fb:	cmpb   $0xff,0x100(%rsp)
  763903:	je     763912 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xf52>
  763905:	lea    0x100(%rsp),%rdi
  76390d:	call   74c8d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  763912:	call   *0x355590(%rip)        # ab8ea8 <_DYNAMIC+0x248>
  763918:	mov    $0x8,%r15d
  76391e:	mov    $0x8,%edi
  763923:	mov    $0x1,%esi
  763928:	call   *0x355582(%rip)        # ab8eb0 <_DYNAMIC+0x250>
  76392e:	test   %rax,%rax
  763931:	je     764367 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x19a7>
  763937:	movabs $0x6d75736b63656863,%rcx
  763941:	mov    %rcx,(%rax)
  763944:	movq   $0x8,0x138(%rsp)
  763950:	mov    %rax,0x140(%rsp)
  763958:	movq   $0x8,0x148(%rsp)
  763964:	movb   $0x2,0x28(%rsp)
  763969:	movq   $0x0,0x30(%rsp)
  763972:	mov    0x1e8(%rsp),%rax
  76397a:	mov    %rax,0x38(%rsp)
  76397f:	lea    0x100(%rsp),%rdi
  763987:	lea    0x288(%rsp),%rsi
  76398f:	lea    0x138(%rsp),%rdx
  763997:	lea    0x28(%rsp),%rcx
  76399c:	call   775b80 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  7639a1:	cmpb   $0xff,0x100(%rsp)
  7639a9:	je     7639b8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xff8>
  7639ab:	lea    0x100(%rsp),%rdi
  7639b3:	call   74c8d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  7639b8:	call   *0x3554ea(%rip)        # ab8ea8 <_DYNAMIC+0x248>
  7639be:	mov    $0x8,%r15d
  7639c4:	mov    $0x8,%edi
  7639c9:	mov    $0x1,%esi
  7639ce:	call   *0x3554dc(%rip)        # ab8eb0 <_DYNAMIC+0x250>
  7639d4:	test   %rax,%rax
  7639d7:	je     764367 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x19a7>
  7639dd:	mov    %rax,%r14
  7639e0:	movabs $0x737265746e756f63,%rax
  7639ea:	mov    %rax,(%r14)
  7639ed:	movq   $0x8,0x138(%rsp)
  7639f9:	mov    %r14,0x140(%rsp)
  763a01:	movq   $0x8,0x148(%rsp)
  763a0d:	lea    0x28(%rsp),%rdi
  763a12:	lea    0x260(%rsp),%rsi
  763a1a:	call   75b1a0 <_RINvXNtNtCscl5MXVnO7Zx_10serde_json5value3serNtB5_5ValueNtNtCs8znKHa7cbRS_10serde_core3ser9Serialize9serializeNtB3_10SerializerECs9C2G9YFESsD_29canonical_text_public_control>
  763a1f:	cmpb   $0xff,0x28(%rsp)
  763a24:	je     763bc3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1203>
  763a2a:	movups 0x28(%rsp),%xmm0
  763a2f:	movups 0x38(%rsp),%xmm1
  763a34:	movaps %xmm1,0x110(%rsp)
  763a3c:	movaps %xmm0,0x100(%rsp)
  763a44:	lea    0x28(%rsp),%rdi
  763a49:	lea    0x288(%rsp),%rsi
  763a51:	lea    0x138(%rsp),%rdx
  763a59:	lea    0x100(%rsp),%rcx
  763a61:	call   775b80 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  763a66:	cmpb   $0xff,0x28(%rsp)
  763a6b:	je     763a77 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x10b7>
  763a6d:	lea    0x28(%rsp),%rdi
  763a72:	call   74c8d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  763a77:	mov    0x298(%rsp),%rax
  763a7f:	lea    0x2b0(%rsp),%rcx
  763a87:	mov    %rax,0x10(%rcx)
  763a8b:	movups 0x288(%rsp),%xmm0
  763a93:	movups %xmm0,(%rcx)
  763a96:	movb   $0x5,0x2a8(%rsp)
  763a9e:	lea    0x2a8(%rsp),%r14
  763aa6:	mov    %r14,0x1f0(%rsp)
  763aae:	mov    0x3556e3(%rip),%rax        # ab9198 <_DYNAMIC+0x538>
  763ab5:	mov    %rax,0x1f8(%rsp)
  763abd:	lea    -0x69ee22(%rip),%rdi        # c4ca2 <GCC_except_table0+0x293a>
  763ac4:	lea    0x1f0(%rsp),%r12
  763acc:	mov    %r12,%rsi
  763acf:	call   *0x3556bb(%rip)        # ab9190 <_DYNAMIC+0x530>
  763ad5:	mov    %r14,%rdi
  763ad8:	mov    0x10(%rsp),%r15
  763add:	call   74c8d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  763ae2:	mov    0xf0(%rsp),%r13
  763aea:	lea    0x260(%rsp),%rdi
  763af2:	call   74c8d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  763af7:	jmp    763530 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xb70>
  763afc:	cmp    $0x4,%r14
  763b00:	je     763618 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xc58>
  763b06:	jmp    763629 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xc69>
  763b0b:	movzbl (%rcx),%edx
  763b0e:	mov    $0x1,%al
  763b10:	cmp    $0x2b,%edx
  763b13:	je     764333 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1973>
  763b19:	cmp    $0x2d,%edx
  763b1c:	je     764333 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1973>
  763b22:	xor    %eax,%eax
  763b24:	cmp    $0x2b,%dl
  763b27:	sete   %al
  763b2a:	mov    %rsi,%rdx
  763b2d:	sub    %rax,%rdx
  763b30:	add    %rax,%rcx
  763b33:	neg    %rax
  763b36:	cmp    $0x11,%rdx
  763b3a:	jae    763b7a <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x11ba>
  763b3c:	test   %rdx,%rdx
  763b3f:	je     763c14 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1254>
  763b45:	add    %rax,%rsi
  763b48:	neg    %rsi
  763b4b:	xor    %eax,%eax
  763b4d:	xor    %edx,%edx
  763b4f:	nop
  763b50:	movzbl (%rcx,%rdx,1),%edi
  763b54:	add    $0xffffffd0,%edi
  763b57:	cmp    $0x9,%edi
  763b5a:	ja     76447b <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1abb>
  763b60:	lea    (%rax,%rax,4),%rax
  763b64:	mov    %edi,%edi
  763b66:	lea    (%rdi,%rax,2),%rax
  763b6a:	inc    %rdx
  763b6d:	mov    %rsi,%rdi
  763b70:	add    %rdx,%rdi
  763b73:	jne    763b50 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1190>
  763b75:	jmp    763c16 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1256>
  763b7a:	add    %rax,%rsi
  763b7d:	neg    %rsi
  763b80:	xor    %eax,%eax
  763b82:	mov    $0xa,%edi
  763b87:	xor    %r8d,%r8d
  763b8a:	nopw   0x0(%rax,%rax,1)
  763b90:	mov    %rsi,%rdx
  763b93:	add    %r8,%rdx
  763b96:	je     763c16 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1256>
  763b98:	mul    %rdi
  763b9b:	movzbl (%rcx,%r8,1),%edx
  763ba0:	jo     764329 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1969>
  763ba6:	add    $0xffffffd0,%edx
  763ba9:	cmp    $0xa,%edx
  763bac:	jae    76447b <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1abb>
  763bb2:	mov    %edx,%edx
  763bb4:	inc    %r8
  763bb7:	add    %rdx,%rax
  763bba:	jae    763b90 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x11d0>
  763bbc:	mov    $0x2,%al
  763bbe:	jmp    764333 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1973>
  763bc3:	mov    0x8(%rsp),%rax
  763bc8:	mov    %rax,0x60(%rsp)
  763bcd:	mov    0x10(%rsp),%rax
  763bd2:	mov    %rax,0x150(%rsp)
  763bda:	mov    0x30(%rsp),%rax
  763bdf:	mov    %rax,0x100(%rsp)
  763be7:	lea    -0x69400c(%rip),%rdi        # cfbe2 <GCC_except_table0+0xd87a>
  763bee:	lea    0x335dc3(%rip),%rcx        # a999b8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1280>
  763bf5:	lea    0x335cdc(%rip),%r8        # a998d8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x11a0>
  763bfc:	lea    0x100(%rsp),%rdx
  763c04:	mov    $0x2b,%esi
  763c09:	call   *0x355361(%rip)        # ab8f70 <_DYNAMIC+0x310>
  763c0f:	jmp    764764 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  763c14:	xor    %eax,%eax
  763c16:	mov    0x20(%rsp),%rdi
  763c1b:	mov    0x20(%rdi),%rsi
  763c1f:	mov    0x28(%rdi),%rdx
  763c23:	mov    0x38(%rdi),%rcx
  763c27:	mov    0x40(%rdi),%r8
  763c2b:	movl   $0x1,(%rsp)
  763c32:	lea    0x150(%rsp),%rdi
  763c3a:	mov    %rax,%r15
  763c3d:	mov    %rax,%r9
  763c40:	call   760690 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run>
  763c45:	mov    0x160(%rsp),%rax
  763c4d:	mov    %rax,0x18(%rsp)
  763c52:	mov    0x150(%rsp),%rax
  763c5a:	mov    %rax,0xf8(%rsp)
  763c62:	mov    0x158(%rsp),%rax
  763c6a:	mov    %rax,0xf0(%rsp)
  763c72:	movups 0x178(%rsp),%xmm0
  763c7a:	movaps %xmm0,0x200(%rsp)
  763c82:	movups 0x168(%rsp),%xmm0
  763c8a:	movaps %xmm0,0x1f0(%rsp)
  763c92:	movq   $0x0,0x100(%rsp)
  763c9e:	movq   $0x0,0x110(%rsp)
  763caa:	call   *0x3551f8(%rip)        # ab8ea8 <_DYNAMIC+0x248>
  763cb0:	mov    $0x4,%r13d
  763cb6:	mov    $0x1,%ebp
  763cbb:	mov    $0x4,%edi
  763cc0:	mov    $0x1,%esi
  763cc5:	call   *0x3551e5(%rip)        # ab8eb0 <_DYNAMIC+0x250>
  763ccb:	test   %rax,%rax
  763cce:	je     764669 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ca9>
  763cd4:	movl   $0x65736163,(%rax)
  763cda:	movq   $0x4,0x28(%rsp)
  763ce3:	mov    %rax,0x30(%rsp)
  763ce8:	movq   $0x4,0x38(%rsp)
  763cf1:	mov    0x20(%rsp),%rcx
  763cf6:	mov    0x28(%rcx),%r12
  763cfa:	test   %r12,%r12
  763cfd:	je     763d3a <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x137a>
  763cff:	mov    %rax,%r13
  763d02:	mov    0x20(%rsp),%rax
  763d07:	mov    0x20(%rax),%r14
  763d0b:	call   *0x355197(%rip)        # ab8ea8 <_DYNAMIC+0x248>
  763d11:	mov    $0x1,%esi
  763d16:	mov    %r12,%rdi
  763d19:	call   *0x355191(%rip)        # ab8eb0 <_DYNAMIC+0x250>
  763d1f:	test   %rax,%rax
  763d22:	je     764746 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1d86>
  763d28:	mov    %rax,%rbp
  763d2b:	mov    %rax,%rdi
  763d2e:	mov    %r14,%rsi
  763d31:	mov    %r12,%rdx
  763d34:	call   *0x355186(%rip)        # ab8ec0 <memcpy@GLIBC_2.14>
  763d3a:	movb   $0x3,0x150(%rsp)
  763d42:	mov    %r12,0x158(%rsp)
  763d4a:	mov    %rbp,0x160(%rsp)
  763d52:	mov    %r12,0x168(%rsp)
  763d5a:	lea    0x60(%rsp),%rdi
  763d5f:	lea    0x100(%rsp),%rsi
  763d67:	lea    0x28(%rsp),%rdx
  763d6c:	lea    0x150(%rsp),%rcx
  763d74:	call   775b80 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  763d79:	cmpb   $0xff,0x60(%rsp)
  763d7e:	je     763d8a <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x13ca>
  763d80:	lea    0x60(%rsp),%rdi
  763d85:	call   74c8d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  763d8a:	call   *0x355118(%rip)        # ab8ea8 <_DYNAMIC+0x248>
  763d90:	mov    $0x9,%r13d
  763d96:	mov    $0x1,%r12d
  763d9c:	mov    $0x9,%edi
  763da1:	mov    $0x1,%esi
  763da6:	call   *0x355104(%rip)        # ab8eb0 <_DYNAMIC+0x250>
  763dac:	test   %rax,%rax
  763daf:	je     764669 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ca9>
  763db5:	movabs $0x6f6974617265706f,%rcx
  763dbf:	mov    %rcx,(%rax)
  763dc2:	movb   $0x6e,0x8(%rax)
  763dc6:	movq   $0x9,0x28(%rsp)
  763dcf:	mov    %rax,0x30(%rsp)
  763dd4:	movq   $0x9,0x38(%rsp)
  763ddd:	mov    0x20(%rsp),%rcx
  763de2:	mov    0x40(%rcx),%r13
  763de6:	test   %r13,%r13
  763de9:	je     763e26 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1466>
  763deb:	mov    %rax,%rbp
  763dee:	mov    0x20(%rsp),%rax
  763df3:	mov    0x38(%rax),%r14
  763df7:	call   *0x3550ab(%rip)        # ab8ea8 <_DYNAMIC+0x248>
  763dfd:	mov    $0x1,%esi
  763e02:	mov    %r13,%rdi
  763e05:	call   *0x3550a5(%rip)        # ab8eb0 <_DYNAMIC+0x250>
  763e0b:	test   %rax,%rax
  763e0e:	je     764756 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1d96>
  763e14:	mov    %rax,%r12
  763e17:	mov    %rax,%rdi
  763e1a:	mov    %r14,%rsi
  763e1d:	mov    %r13,%rdx
  763e20:	call   *0x35509a(%rip)        # ab8ec0 <memcpy@GLIBC_2.14>
  763e26:	movb   $0x3,0x150(%rsp)
  763e2e:	mov    %r13,0x158(%rsp)
  763e36:	mov    %r12,0x160(%rsp)
  763e3e:	mov    %r13,0x168(%rsp)
  763e46:	lea    0x60(%rsp),%rdi
  763e4b:	lea    0x100(%rsp),%rsi
  763e53:	lea    0x28(%rsp),%rdx
  763e58:	lea    0x150(%rsp),%rcx
  763e60:	call   775b80 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  763e65:	cmpb   $0xff,0x60(%rsp)
  763e6a:	je     763e76 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x14b6>
  763e6c:	lea    0x60(%rsp),%rdi
  763e71:	call   74c8d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  763e76:	call   *0x35502c(%rip)        # ab8ea8 <_DYNAMIC+0x248>
  763e7c:	mov    $0x5,%r13d
  763e82:	mov    $0x5,%edi
  763e87:	mov    $0x1,%esi
  763e8c:	call   *0x35501e(%rip)        # ab8eb0 <_DYNAMIC+0x250>
  763e92:	test   %rax,%rax
  763e95:	je     764669 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ca9>
  763e9b:	movb   $0x74,0x4(%rax)
  763e9f:	movl   $0x6e756f63,(%rax)
  763ea5:	movq   $0x5,0x28(%rsp)
  763eae:	mov    %rax,0x30(%rsp)
  763eb3:	movq   $0x5,0x38(%rsp)
  763ebc:	movb   $0x2,0x150(%rsp)
  763ec4:	movq   $0x0,0x158(%rsp)
  763ed0:	mov    %r15,0x160(%rsp)
  763ed8:	lea    0x60(%rsp),%rdi
  763edd:	lea    0x100(%rsp),%rsi
  763ee5:	lea    0x28(%rsp),%rdx
  763eea:	lea    0x150(%rsp),%rcx
  763ef2:	call   775b80 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  763ef7:	cmpb   $0xff,0x60(%rsp)
  763efc:	je     763f08 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1548>
  763efe:	lea    0x60(%rsp),%rdi
  763f03:	call   74c8d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  763f08:	call   *0x354f9a(%rip)        # ab8ea8 <_DYNAMIC+0x248>
  763f0e:	mov    $0x8,%r13d
  763f14:	mov    $0x8,%edi
  763f19:	mov    $0x1,%esi
  763f1e:	call   *0x354f8c(%rip)        # ab8eb0 <_DYNAMIC+0x250>
  763f24:	test   %rax,%rax
  763f27:	je     764669 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ca9>
  763f2d:	movabs $0x6d75736b63656863,%rcx
  763f37:	mov    %rcx,(%rax)
  763f3a:	movq   $0x8,0x28(%rsp)
  763f43:	mov    %rax,0x30(%rsp)
  763f48:	movq   $0x8,0x38(%rsp)
  763f51:	movb   $0x2,0x150(%rsp)
  763f59:	movq   $0x0,0x158(%rsp)
  763f65:	mov    0x18(%rsp),%rax
  763f6a:	mov    %rax,0x160(%rsp)
  763f72:	lea    0x60(%rsp),%rdi
  763f77:	lea    0x100(%rsp),%rsi
  763f7f:	lea    0x28(%rsp),%rdx
  763f84:	lea    0x150(%rsp),%rcx
  763f8c:	call   775b80 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  763f91:	cmpb   $0xff,0x60(%rsp)
  763f96:	je     763fa2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x15e2>
  763f98:	lea    0x60(%rsp),%rdi
  763f9d:	call   74c8d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  763fa2:	call   *0x354f00(%rip)        # ab8ea8 <_DYNAMIC+0x248>
  763fa8:	mov    $0xa,%r13d
  763fae:	mov    $0xa,%edi
  763fb3:	mov    $0x1,%esi
  763fb8:	call   *0x354ef2(%rip)        # ab8eb0 <_DYNAMIC+0x250>
  763fbe:	test   %rax,%rax
  763fc1:	je     764669 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ca9>
  763fc7:	mov    %rax,%r12
  763fca:	movabs $0x5f64657370616c65,%rax
  763fd4:	mov    %rax,(%r12)
  763fd8:	movw   $0x736e,0x8(%r12)
  763fe0:	movq   $0xa,0x28(%rsp)
  763fe9:	mov    %r12,0x30(%rsp)
  763fee:	movq   $0xa,0x38(%rsp)
  763ff7:	lea    0x150(%rsp),%rdi
  763fff:	mov    0xf8(%rsp),%rsi
  764007:	mov    0xf0(%rsp),%rdx
  76400f:	call   *0x35518b(%rip)        # ab91a0 <_DYNAMIC+0x540>
  764015:	cmpb   $0xff,0x150(%rsp)
  76401d:	je     764391 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x19d1>
  764023:	movups 0x150(%rsp),%xmm0
  76402b:	movups 0x160(%rsp),%xmm1
  764033:	movaps %xmm1,0x70(%rsp)
  764038:	movaps %xmm0,0x60(%rsp)
  76403d:	lea    0x150(%rsp),%rdi
  764045:	lea    0x100(%rsp),%rsi
  76404d:	lea    0x28(%rsp),%rdx
  764052:	lea    0x60(%rsp),%rcx
  764057:	call   775b80 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  76405c:	cmpb   $0xff,0x150(%rsp)
  764064:	je     764073 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x16b3>
  764066:	lea    0x150(%rsp),%rdi
  76406e:	call   74c8d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  764073:	call   *0x354e2f(%rip)        # ab8ea8 <_DYNAMIC+0x248>
  764079:	mov    $0x8,%r13d
  76407f:	mov    $0x8,%edi
  764084:	mov    $0x1,%esi
  764089:	call   *0x354e21(%rip)        # ab8eb0 <_DYNAMIC+0x250>
  76408f:	test   %rax,%rax
  764092:	je     764669 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ca9>
  764098:	mov    %rax,%r14
  76409b:	movabs $0x737265746e756f63,%rax
  7640a5:	mov    %rax,(%r14)
  7640a8:	movq   $0x8,0x28(%rsp)
  7640b1:	mov    %r14,0x30(%rsp)
  7640b6:	movq   $0x8,0x38(%rsp)
  7640bf:	lea    0x150(%rsp),%rdi
  7640c7:	lea    0x1f0(%rsp),%rsi
  7640cf:	call   75b1a0 <_RINvXNtNtCscl5MXVnO7Zx_10serde_json5value3serNtB5_5ValueNtNtCs8znKHa7cbRS_10serde_core3ser9Serialize9serializeNtB3_10SerializerECs9C2G9YFESsD_29canonical_text_public_control>
  7640d4:	cmpb   $0xff,0x150(%rsp)
  7640dc:	je     7643c8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1a08>
  7640e2:	movups 0x150(%rsp),%xmm0
  7640ea:	movups 0x160(%rsp),%xmm1
  7640f2:	movaps %xmm1,0x70(%rsp)
  7640f7:	movaps %xmm0,0x60(%rsp)
  7640fc:	lea    0x150(%rsp),%r14
  764104:	lea    0x100(%rsp),%rsi
  76410c:	lea    0x28(%rsp),%rdx
  764111:	lea    0x60(%rsp),%rcx
  764116:	mov    %r14,%rdi
  764119:	call   775b80 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  76411e:	cmpb   $0xff,0x150(%rsp)
  764126:	je     764135 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1775>
  764128:	lea    0x150(%rsp),%rdi
  764130:	call   74c8d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  764135:	movups 0x100(%rsp),%xmm0
  76413d:	movups %xmm0,0x158(%rsp)
  764145:	mov    0x110(%rsp),%rax
  76414d:	mov    %rax,0x168(%rsp)
  764155:	movb   $0x5,0x150(%rsp)
  76415d:	mov    %r14,0x60(%rsp)
  764162:	mov    0x35502f(%rip),%rax        # ab9198 <_DYNAMIC+0x538>
  764169:	mov    %rax,0x68(%rsp)
  76416e:	lea    -0x69f4d3(%rip),%rdi        # c4ca2 <GCC_except_table0+0x293a>
  764175:	lea    0x60(%rsp),%rsi
  76417a:	call   *0x355010(%rip)        # ab9190 <_DYNAMIC+0x530>
  764180:	lea    0x150(%rsp),%rdi
  764188:	call   74c8d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  76418d:	lea    0x1f0(%rsp),%rdi
  764195:	call   74c8d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  76419a:	mov    0x20(%rsp),%rax
  76419f:	lea    0x8(%rax),%r14
  7641a3:	mov    0x354cf6(%rip),%r15        # ab8ea0 <_DYNAMIC+0x240>
  7641aa:	jmp    7641b9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x17f9>
  7641ac:	nopl   0x0(%rax)
  7641b0:	add    $0x18,%r14
  7641b4:	dec    %rbx
  7641b7:	je     7641cf <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x180f>
  7641b9:	mov    -0x8(%r14),%rsi
  7641bd:	test   %rsi,%rsi
  7641c0:	je     7641b0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x17f0>
  7641c2:	mov    (%r14),%rdi
  7641c5:	mov    $0x1,%edx
  7641ca:	call   *%r15
  7641cd:	jmp    7641b0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x17f0>
  7641cf:	mov    0x280(%rsp),%rax
  7641d7:	test   %rax,%rax
  7641da:	je     7641f4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1834>
  7641dc:	shl    $0x3,%rax
  7641e0:	lea    (%rax,%rax,2),%rsi
  7641e4:	mov    $0x8,%edx
  7641e9:	mov    0x20(%rsp),%rdi
  7641ee:	call   *0x354cac(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  7641f4:	add    $0x2c8,%rsp
  7641fb:	pop    %rbx
  7641fc:	pop    %r12
  7641fe:	pop    %r13
  764200:	pop    %r14
  764202:	pop    %r15
  764204:	pop    %rbp
  764205:	ret
  764206:	lea    0x60(%rsp),%rdi
  76420b:	lea    0x100(%rsp),%rsi
  764213:	call   74f3a6 <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedTNtNtCscdodAO9FK5_5alloc6string6StringNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout13TextSelectionPNtB1q_12TextGeometryyEBM_ECs9C2G9YFESsD_29canonical_text_public_control>
  764218:	jmp    764764 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  76421d:	lea    0x28(%rsp),%rdi
  764222:	lea    0x2a8(%rsp),%rsi
  76422a:	call   74f28b <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedNtNtCscdodAO9FK5_5alloc6string6StringBM_ECs9C2G9YFESsD_29canonical_text_public_control>
  76422f:	jmp    764764 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  764234:	lea    0x1f0(%rsp),%rdi
  76423c:	lea    0x60(%rsp),%rsi
  764241:	call   74f3de <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedTPNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryyEBM_ECs9C2G9YFESsD_29canonical_text_public_control>
  764246:	jmp    764764 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  76424b:	lea    0x335336(%rip),%rdi        # a99588 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xe50>
  764252:	call   *0x354cf0(%rip)        # ab8f48 <_DYNAMIC+0x2e8>
  764258:	jmp    764764 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  76425d:	lea    0x3352f4(%rip),%rdi        # a99558 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xe20>
  764264:	call   *0x354cde(%rip)        # ab8f48 <_DYNAMIC+0x2e8>
  76426a:	jmp    764764 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  76426f:	mov    0x250(%rsp),%rax
  764277:	mov    %rax,0xc0(%rsp)
  76427f:	movups 0x240(%rsp),%xmm0
  764287:	movaps %xmm0,0xb0(%rsp)
  76428f:	movups 0x230(%rsp),%xmm0
  764297:	movaps %xmm0,0xa0(%rsp)
  76429f:	movups 0x1f0(%rsp),%xmm0
  7642a7:	movups 0x200(%rsp),%xmm1
  7642af:	movups 0x210(%rsp),%xmm2
  7642b7:	movups 0x220(%rsp),%xmm3
  7642bf:	movaps %xmm3,0x90(%rsp)
  7642c7:	movaps %xmm2,0x80(%rsp)
  7642cf:	movaps %xmm1,0x70(%rsp)
  7642d4:	movaps %xmm0,0x60(%rsp)
  7642d9:	lea    -0x6946fe(%rip),%rdi        # cfbe2 <GCC_except_table0+0xd87a>
  7642e0:	lea    0x335731(%rip),%rcx        # a99a18 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x12e0>
  7642e7:	lea    0x33523a(%rip),%r8        # a99528 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xdf0>
  7642ee:	lea    0x60(%rsp),%rdx
  7642f3:	mov    $0x2b,%esi
  7642f8:	call   *0x354c72(%rip)        # ab8f70 <_DYNAMIC+0x310>
  7642fe:	jmp    764764 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  764303:	lea    0x335236(%rip),%r9        # a99540 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xe08>
  76430a:	xor    %edi,%edi
  76430c:	lea    0x90(%rsp),%rsi
  764314:	lea    0x130(%rsp),%rdx
  76431c:	xor    %ecx,%ecx
  76431e:	call   *0x354dfc(%rip)        # ab9120 <_DYNAMIC+0x4c0>
  764324:	jmp    764764 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  764329:	add    $0xd0,%dl
  76432c:	xor    %eax,%eax
  76432e:	cmp    $0xa,%dl
  764331:	adc    $0x1,%al
  764333:	mov    %al,0x150(%rsp)
  76433a:	lea    -0x69475f(%rip),%rdi        # cfbe2 <GCC_except_table0+0xd87a>
  764341:	lea    0x335710(%rip),%rcx        # a99a58 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1320>
  764348:	lea    0x335559(%rip),%r8        # a998a8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1170>
  76434f:	lea    0x150(%rsp),%rdx
  764357:	mov    $0x2b,%esi
  76435c:	call   *0x354c0e(%rip)        # ab8f70 <_DYNAMIC+0x310>
  764362:	jmp    764764 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  764367:	mov    0x8(%rsp),%rax
  76436c:	mov    %rax,0x60(%rsp)
  764371:	mov    0x10(%rsp),%rax
  764376:	mov    %rax,0x150(%rsp)
  76437e:	mov    $0x1,%edi
  764383:	mov    %r15,%rsi
  764386:	call   *0x354bcc(%rip)        # ab8f58 <_DYNAMIC+0x2f8>
  76438c:	jmp    764764 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  764391:	mov    0x158(%rsp),%rax
  764399:	mov    %rax,0x60(%rsp)
  76439e:	lea    -0x6947c3(%rip),%rdi        # cfbe2 <GCC_except_table0+0xd87a>
  7643a5:	lea    0x33560c(%rip),%rcx        # a999b8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1280>
  7643ac:	lea    0x33550d(%rip),%r8        # a998c0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1188>
  7643b3:	lea    0x60(%rsp),%rdx
  7643b8:	mov    $0x2b,%esi
  7643bd:	call   *0x354bad(%rip)        # ab8f70 <_DYNAMIC+0x310>
  7643c3:	jmp    764764 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  7643c8:	mov    0x158(%rsp),%rax
  7643d0:	mov    %rax,0x60(%rsp)
  7643d5:	lea    -0x6947fa(%rip),%rdi        # cfbe2 <GCC_except_table0+0xd87a>
  7643dc:	lea    0x3355d5(%rip),%rcx        # a999b8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1280>
  7643e3:	lea    0x3354d6(%rip),%r8        # a998c0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1188>
  7643ea:	lea    0x60(%rsp),%rdx
  7643ef:	mov    $0x2b,%esi
  7643f4:	call   *0x354b76(%rip)        # ab8f70 <_DYNAMIC+0x310>
  7643fa:	jmp    764764 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  7643ff:	mov    0x8(%rsp),%rax
  764404:	mov    %rax,0x60(%rsp)
  764409:	mov    0x10(%rsp),%rax
  76440e:	mov    %rax,0x150(%rsp)
  764416:	mov    $0x1,%edi
  76441b:	mov    %r14,%rsi
  76441e:	call   *0x354b34(%rip)        # ab8f58 <_DYNAMIC+0x2f8>
  764424:	jmp    764764 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  764429:	mov    0x8(%rsp),%rax
  76442e:	mov    %rax,0x60(%rsp)
  764433:	mov    0x10(%rsp),%rax
  764438:	mov    %rax,0x150(%rsp)
  764440:	mov    $0x1,%edi
  764445:	mov    %r12,%rsi
  764448:	call   *0x354b0a(%rip)        # ab8f58 <_DYNAMIC+0x2f8>
  76444e:	jmp    764764 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  764453:	lea    0x60(%rsp),%rdi
  764458:	call   7461b0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultNtNtCslbxve4rcJus_4gpui7runtime6CommitNtBZ_5ErrorEECs9C2G9YFESsD_29canonical_text_public_control>
  76445d:	lea    -0x694aa4(%rip),%rdi        # cf9c0 <GCC_except_table0+0xd658>
  764464:	lea    0x335105(%rip),%rdx        # a99570 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xe38>
  76446b:	mov    $0x4e,%esi
  764470:	call   *0x354aa2(%rip)        # ab8f18 <_DYNAMIC+0x2b8>
  764476:	jmp    764764 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  76447b:	mov    $0x1,%al
  76447d:	jmp    764333 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1973>
  764482:	mov    $0x12,%eax
  764487:	jmp    76448e <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ace>
  764489:	mov    $0xe,%eax
  76448e:	mov    %rax,0x1e8(%rsp)
  764496:	mov    0x1e8(%rsp),%rax
  76449e:	mov    %rax,0x60(%rsp)
  7644a3:	mov    0x18(%rsp),%rax
  7644a8:	mov    %rax,0x68(%rsp)
  7644ad:	mov    0xf8(%rsp),%rax
  7644b5:	mov    %rax,0x70(%rsp)
  7644ba:	lea    -0x694b60(%rip),%rdi        # cf961 <GCC_except_table0+0xd5f9>
  7644c1:	lea    0x3354d0(%rip),%rcx        # a99998 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1260>
  7644c8:	lea    0x334e31(%rip),%r8        # a99300 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xbc8>
  7644cf:	lea    0x60(%rsp),%rdx
  7644d4:	mov    $0x2a,%esi
  7644d9:	call   *0x354a91(%rip)        # ab8f70 <_DYNAMIC+0x310>
  7644df:	jmp    764764 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  7644e4:	movq   $0xd,0x1f0(%rsp)
  7644f0:	movq   $0x0,0x1f8(%rsp)
  7644fc:	mov    0x220(%rsp),%rax
  764504:	mov    %rax,0x90(%rsp)
  76450c:	mov    0x1f0(%rsp),%rax
  764514:	mov    0x1f8(%rsp),%rcx
  76451c:	movups 0x200(%rsp),%xmm0
  764524:	movups 0x210(%rsp),%xmm1
  76452c:	movaps %xmm1,0x80(%rsp)
  764534:	movaps %xmm0,0x70(%rsp)
  764539:	mov    %rax,0x60(%rsp)
  76453e:	mov    %rcx,0x68(%rsp)
  764543:	lea    -0x694968(%rip),%rdi        # cfbe2 <GCC_except_table0+0xd87a>
  76454a:	lea    0x335447(%rip),%rcx        # a99998 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1260>
  764551:	lea    0x334f00(%rip),%r8        # a99458 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xd20>
  764558:	lea    0x60(%rsp),%rdx
  76455d:	mov    $0x2b,%esi
  764562:	call   *0x354a08(%rip)        # ab8f70 <_DYNAMIC+0x310>
  764568:	jmp    764764 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  76456d:	mov    $0xd,%eax
  764572:	movq   $0x0,0x2a0(%rsp)
  76457e:	jmp    76458c <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1bcc>
  764580:	mov    $0xe,%eax
  764585:	jmp    76458c <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1bcc>
  764587:	mov    $0x14,%eax
  76458c:	mov    %rax,0x60(%rsp)
  764591:	mov    0x2a0(%rsp),%rax
  764599:	mov    %rax,0x68(%rsp)
  76459e:	mov    0x8(%rsp),%rax
  7645a3:	mov    %rax,0x70(%rsp)
  7645a8:	lea    -0x6949cd(%rip),%rdi        # cfbe2 <GCC_except_table0+0xd87a>
  7645af:	lea    0x3353e2(%rip),%rcx        # a99998 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1260>
  7645b6:	lea    0x334eb3(%rip),%r8        # a99470 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xd38>
  7645bd:	lea    0x60(%rsp),%rdx
  7645c2:	mov    $0x2b,%esi
  7645c7:	call   *0x3549a3(%rip)        # ab8f70 <_DYNAMIC+0x310>
  7645cd:	jmp    764764 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  7645d2:	movq   $0xd,0x1f0(%rsp)
  7645de:	movq   $0x0,0x1f8(%rsp)
  7645ea:	jmp    7645f8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1c38>
  7645ec:	movq   $0xe,0x1f0(%rsp)
  7645f8:	mov    0x220(%rsp),%rax
  764600:	mov    %rax,0x90(%rsp)
  764608:	mov    0x1f0(%rsp),%rax
  764610:	mov    0x1f8(%rsp),%rcx
  764618:	movups 0x200(%rsp),%xmm0
  764620:	movups 0x210(%rsp),%xmm1
  764628:	movaps %xmm1,0x80(%rsp)
  764630:	movaps %xmm0,0x70(%rsp)
  764635:	mov    %rax,0x60(%rsp)
  76463a:	mov    %rcx,0x68(%rsp)
  76463f:	lea    -0x694a64(%rip),%rdi        # cfbe2 <GCC_except_table0+0xd87a>
  764646:	lea    0x33534b(%rip),%rcx        # a99998 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1260>
  76464d:	lea    0x334e4c(%rip),%r8        # a994a0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xd68>
  764654:	lea    0x60(%rsp),%rdx
  764659:	mov    $0x2b,%esi
  76465e:	call   *0x35490c(%rip)        # ab8f70 <_DYNAMIC+0x310>
  764664:	jmp    764764 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  764669:	mov    $0x1,%edi
  76466e:	mov    %r13,%rsi
  764671:	call   *0x3548e1(%rip)        # ab8f58 <_DYNAMIC+0x2f8>
  764677:	jmp    764764 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  76467c:	mov    0x68(%rsp),%r14
  764681:	mov    0x78(%rsp),%rcx
  764686:	mov    %rcx,%rax
  764689:	sub    %r14,%rax
  76468c:	movabs $0xaaaaaaaaaaaaaaab,%rdx
  764696:	mul    %rdx
  764699:	cmp    %r14,%rcx
  76469c:	jne    7646f3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1d33>
  76469e:	mov    0x70(%rsp),%rax
  7646a3:	test   %rax,%rax
  7646a6:	je     7646c0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1d00>
  7646a8:	mov    0x60(%rsp),%rdi
  7646ad:	shl    $0x3,%rax
  7646b1:	lea    (%rax,%rax,2),%rsi
  7646b5:	mov    $0x8,%edx
  7646ba:	call   *0x3547e0(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  7646c0:	mov    $0x8,%eax
  7646c5:	mov    %rax,0x20(%rsp)
  7646ca:	movq   $0x0,0x280(%rsp)
  7646d6:	xor    %ebx,%ebx
  7646d8:	lea    -0x694bbf(%rip),%rdi        # cfb20 <GCC_except_table0+0xd7b8>
  7646df:	lea    0x335192(%rip),%rdx        # a99878 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1140>
  7646e6:	mov    $0x5d,%esi
  7646eb:	call   *0x3547e7(%rip)        # ab8ed8 <_DYNAMIC+0x278>
  7646f1:	jmp    764764 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  7646f3:	mov    %rdx,%rbx
  7646f6:	shr    $0x4,%rbx
  7646fa:	add    $0x8,%r14
  7646fe:	mov    0x35479b(%rip),%r15        # ab8ea0 <_DYNAMIC+0x240>
  764705:	jmp    764719 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1d59>
  764707:	nopw   0x0(%rax,%rax,1)
  764710:	add    $0x18,%r14
  764714:	dec    %rbx
  764717:	je     76469e <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1cde>
  764719:	mov    -0x8(%r14),%rsi
  76471d:	test   %rsi,%rsi
  764720:	je     764710 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1d50>
  764722:	mov    (%r14),%rdi
  764725:	mov    $0x1,%edx
  76472a:	call   *%r15
  76472d:	jmp    764710 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1d50>
  76472f:	lea    0x33515a(%rip),%rdx        # a99890 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1158>
  764736:	mov    $0x3,%edi
  76473b:	mov    %rbx,%rsi
  76473e:	call   *0x35478c(%rip)        # ab8ed0 <_DYNAMIC+0x270>
  764744:	jmp    764764 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  764746:	mov    $0x1,%edi
  76474b:	mov    %r12,%rsi
  76474e:	call   *0x354804(%rip)        # ab8f58 <_DYNAMIC+0x2f8>
  764754:	jmp    764764 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1da4>
  764756:	mov    $0x1,%edi
  76475b:	mov    %r13,%rsi
  76475e:	call   *0x3547f4(%rip)        # ab8f58 <_DYNAMIC+0x2f8>
  764764:	ud2
  764766:	xor    %eax,%eax
  764768:	jmp    764333 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1973>
  76476d:	mov    %rax,%r15
  764770:	mov    $0x9,%esi
  764775:	mov    $0x1,%edx
  76477a:	mov    %rbp,%rdi
  76477d:	jmp    764970 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1fb0>
  764782:	mov    %rax,%r15
  764785:	mov    $0x4,%esi
  76478a:	mov    $0x1,%edx
  76478f:	mov    %r13,%rdi
  764792:	jmp    764970 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1fb0>
  764797:	mov    %rax,%r15
  76479a:	jmp    764983 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1fc3>
  76479f:	mov    %rax,%r15
  7647a2:	lea    0x150(%rsp),%rdi
  7647aa:	call   74c8d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  7647af:	jmp    764983 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1fc3>
  7647b4:	mov    %rax,%r15
  7647b7:	jmp    764976 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1fb6>
  7647bc:	mov    %rax,%r15
  7647bf:	jmp    764941 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1f81>
  7647c4:	mov    %rax,%r15
  7647c7:	jmp    764976 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1fb6>
  7647cc:	mov    %rax,%r15
  7647cf:	jmp    764963 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1fa3>
  7647d4:	mov    %rax,%r15
  7647d7:	jmp    764976 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1fb6>
  7647dc:	mov    %rax,%r15
  7647df:	jmp    764976 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1fb6>
  7647e4:	mov    %rax,%r15
  7647e7:	jmp    764976 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1fb6>
  7647ec:	mov    %rax,%r15
  7647ef:	jmp    764976 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1fb6>
  7647f4:	mov    %rax,%r15
  7647f7:	jmp    764c5a <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x229a>
  7647fc:	mov    %rax,%r15
  7647ff:	jmp    764976 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1fb6>
  764804:	mov    %rax,%r15
  764807:	mov    $0x770,%esi
  76480c:	mov    $0x8,%edx
  764811:	mov    %r14,%rdi
  764814:	jmp    764b22 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2162>
  764819:	jmp    76487a <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1eba>
  76481b:	mov    %rax,%r15
  76481e:	jmp    764bfb <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x223b>
  764823:	mov    %rax,%r15
  764826:	test   %r14,%r14
  764829:	je     764853 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1e93>
  76482b:	mov    $0x1,%edx
  764830:	mov    %rbp,%rdi
  764833:	mov    %r14,%rsi
  764836:	call   *0x354664(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  76483c:	jmp    764853 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1e93>
  76483e:	jmp    76487a <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1eba>
  764840:	mov    %rax,%r15
  764843:	jmp    764a2c <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x206c>
  764848:	mov    %rax,%r15
  76484b:	jmp    764b04 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2144>
  764850:	mov    %rax,%r15
  764853:	lea    0x150(%rsp),%rdi
  76485b:	call   7497a0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtB4_4iter8adapters4skip4SkipNtNtCs2AWtUsOyxgP_3std3env4ArgsEECs9C2G9YFESsD_29canonical_text_public_control>
  764860:	lea    0x28(%rsp),%rdi
  764865:	call   746dd0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtBG_6string6StringEECs9C2G9YFESsD_29canonical_text_public_control>
  76486a:	mov    %r15,%rdi
  76486d:	call   a97380 <_Unwind_Resume@plt>
  764872:	mov    %rax,%r15
  764875:	jmp    764a68 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x20a8>
  76487a:	mov    %rax,%r15
  76487d:	lea    0x60(%rsp),%rdi
  764882:	call   74d540 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  764887:	mov    $0x1,%bpl
  76488a:	jmp    764ab3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x20f3>
  76488f:	jmp    764a6c <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x20ac>
  764894:	mov    %rax,%r15
  764897:	mov    $0x4,%esi
  76489c:	jmp    7648a6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ee6>
  76489e:	mov    %rax,%r15
  7648a1:	mov    $0x9,%esi
  7648a6:	mov    $0x1,%edx
  7648ab:	mov    %r13,%rdi
  7648ae:	jmp    764b63 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x21a3>
  7648b3:	mov    %r15,%rcx
  7648b6:	mov    %rax,%r15
  7648b9:	mov    0x8(%rsp),%rax
  7648be:	mov    %rax,0x60(%rsp)
  7648c3:	mov    %rcx,0x150(%rsp)
  7648cb:	jmp    764bee <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x222e>
  7648d0:	jmp    764a00 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2040>
  7648d5:	mov    %rax,%r15
  7648d8:	mov    0x8(%rsp),%rax
  7648dd:	mov    %rax,0x60(%rsp)
  7648e2:	mov    0x10(%rsp),%rax
  7648e7:	mov    %rax,0x150(%rsp)
  7648ef:	lea    0x2a8(%rsp),%rdi
  7648f7:	call   74c8d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  7648fc:	jmp    764bee <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x222e>
  764901:	jmp    764a00 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2040>
  764906:	mov    %rax,%r15
  764909:	mov    0x8(%rsp),%rax
  76490e:	mov    %rax,0x60(%rsp)
  764913:	mov    0x10(%rsp),%rax
  764918:	mov    %rax,0x150(%rsp)
  764920:	jmp    764b56 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2196>
  764925:	jmp    764a00 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2040>
  76492a:	jmp    764a00 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2040>
  76492f:	jmp    764a00 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2040>
  764934:	mov    %rax,%r15
  764937:	lea    0x60(%rsp),%rdi
  76493c:	call   74c7e0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5error5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  764941:	mov    $0x8,%esi
  764946:	mov    $0x1,%edx
  76494b:	mov    %r14,%rdi
  76494e:	jmp    764970 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1fb0>
  764950:	call   *0x354572(%rip)        # ab8ec8 <_DYNAMIC+0x268>
  764956:	mov    %rax,%r15
  764959:	lea    0x60(%rsp),%rdi
  76495e:	call   74c7e0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5error5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  764963:	mov    $0xa,%esi
  764968:	mov    $0x1,%edx
  76496d:	mov    %r12,%rdi
  764970:	call   *0x35452a(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  764976:	lea    0x100(%rsp),%rdi
  76497e:	call   747b00 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscl5MXVnO7Zx_10serde_json3map3MapNtNtCscdodAO9FK5_5alloc6string6StringNtNtBG_5value5ValueEECs9C2G9YFESsD_29canonical_text_public_control>
  764983:	lea    0x1f0(%rsp),%rdi
  76498b:	call   74c8d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  764990:	jmp    764bfb <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x223b>
  764995:	call   *0x35452d(%rip)        # ab8ec8 <_DYNAMIC+0x268>
  76499b:	mov    %rax,%r15
  76499e:	jmp    764a2c <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x206c>
  7649a3:	mov    %r15,%rcx
  7649a6:	mov    %rax,%r15
  7649a9:	mov    0x8(%rsp),%rax
  7649ae:	mov    %rax,0x60(%rsp)
  7649b3:	mov    %rcx,0x150(%rsp)
  7649bb:	jmp    764bfb <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x223b>
  7649c0:	mov    %rax,%r15
  7649c3:	cmpq   $0xffffffffffffffff,0x18(%rsp)
  7649c9:	jne    764bfb <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x223b>
  7649cf:	mov    0x280(%rsp),%rax
  7649d7:	test   %rax,%rax
  7649da:	je     764c86 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x22c6>
  7649e0:	shl    $0x3,%rax
  7649e4:	lea    (%rax,%rax,2),%rsi
  7649e8:	mov    $0x8,%edx
  7649ed:	mov    0x20(%rsp),%rdi
  7649f2:	call   *0x3544a8(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  7649f8:	mov    %r15,%rdi
  7649fb:	call   a97380 <_Unwind_Resume@plt>
  764a00:	mov    %rax,%r15
  764a03:	mov    0x8(%rsp),%rax
  764a08:	mov    %rax,0x60(%rsp)
  764a0d:	mov    0x10(%rsp),%rax
  764a12:	mov    %rax,0x150(%rsp)
  764a1a:	jmp    764b69 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x21a9>
  764a1f:	mov    %rax,%r15
  764a22:	lea    0x60(%rsp),%rdi
  764a27:	call   74d540 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  764a2c:	mov    $0x1,%bpl
  764a2f:	jmp    764ad3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2113>
  764a34:	mov    %rax,%r15
  764a37:	jmp    764b69 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x21a9>
  764a3c:	mov    %rax,%r15
  764a3f:	mov    0x60(%rsp),%rsi
  764a44:	test   %rsi,%rsi
  764a47:	je     764a68 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x20a8>
  764a49:	mov    0x68(%rsp),%rdi
  764a4e:	mov    $0x1,%edx
  764a53:	call   *0x354447(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  764a59:	jmp    764a68 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x20a8>
  764a5b:	mov    %rax,%r15
  764a5e:	lea    0x60(%rsp),%rdi
  764a63:	call   7483e0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui7runtime8SetErrorNtNtCscdodAO9FK5_5alloc6string6StringEECs9C2G9YFESsD_29canonical_text_public_control>
  764a68:	xor    %ebp,%ebp
  764a6a:	jmp    764a99 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x20d9>
  764a6c:	mov    %rax,%r15
  764a6f:	mov    $0x1,%bpl
  764a72:	jmp    764ab3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x20f3>
  764a74:	mov    %rax,%r15
  764a77:	jmp    764bfb <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x223b>
  764a7c:	mov    %rax,%r15
  764a7f:	mov    0x60(%rsp),%rsi
  764a84:	mov    $0x1,%bpl
  764a87:	test   %rsi,%rsi
  764a8a:	je     764ab3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x20f3>
  764a8c:	mov    0x68(%rsp),%rdi
  764a91:	jmp    764aa8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x20e8>
  764a93:	mov    %rax,%r15
  764a96:	mov    $0x1,%bpl
  764a99:	mov    0x28(%rsp),%rsi
  764a9e:	test   %rsi,%rsi
  764aa1:	je     764ab3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x20f3>
  764aa3:	mov    0x30(%rsp),%rdi
  764aa8:	mov    $0x1,%edx
  764aad:	call   *0x3543ed(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  764ab3:	mov    0x100(%rsp),%rsi
  764abb:	test   %rsi,%rsi
  764abe:	je     764ad3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2113>
  764ac0:	mov    0x108(%rsp),%rdi
  764ac8:	mov    $0x1,%edx
  764acd:	call   *0x3543cd(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  764ad3:	mov    0x260(%rsp),%r14
  764adb:	test   %r14,%r14
  764ade:	je     764afb <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x213b>
  764ae0:	mov    %r14,%rdi
  764ae3:	call   747d30 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui7runtime7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEEB1h_>
  764ae8:	mov    $0x770,%esi
  764aed:	mov    $0x8,%edx
  764af2:	mov    %r14,%rdi
  764af5:	call   *0x3543a5(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  764afb:	test   %bpl,%bpl
  764afe:	je     764bfb <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x223b>
  764b04:	mov    0x2a8(%rsp),%rsi
  764b0c:	test   %rsi,%rsi
  764b0f:	je     764bfb <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x223b>
  764b15:	mov    0x2b0(%rsp),%rdi
  764b1d:	mov    $0x1,%edx
  764b22:	call   *0x354378(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  764b28:	jmp    764bfb <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x223b>
  764b2d:	mov    $0x770,%esi
  764b32:	mov    $0x8,%edx
  764b37:	mov    %r14,%rdi
  764b3a:	call   *0x354360(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  764b40:	call   *0x354382(%rip)        # ab8ec8 <_DYNAMIC+0x268>
  764b46:	mov    %rax,%r15
  764b49:	lea    0x100(%rsp),%rdi
  764b51:	call   74c7e0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5error5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  764b56:	mov    $0x8,%esi
  764b5b:	mov    $0x1,%edx
  764b60:	mov    %r14,%rdi
  764b63:	call   *0x354337(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  764b69:	mov    0x288(%rsp),%rcx
  764b71:	test   %rcx,%rcx
  764b74:	jne    764b7c <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x21bc>
  764b76:	xor    %ecx,%ecx
  764b78:	xor    %eax,%eax
  764b7a:	jmp    764bc9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2209>
  764b7c:	mov    0x290(%rsp),%rdx
  764b84:	mov    0x298(%rsp),%rax
  764b8c:	movq   $0x0,0x1f8(%rsp)
  764b98:	mov    %rcx,0x200(%rsp)
  764ba0:	mov    %rdx,0x208(%rsp)
  764ba8:	movq   $0x0,0x218(%rsp)
  764bb4:	mov    %rcx,0x220(%rsp)
  764bbc:	mov    %rdx,0x228(%rsp)
  764bc4:	mov    $0x1,%ecx
  764bc9:	mov    %rcx,0x1f0(%rsp)
  764bd1:	mov    %rcx,0x210(%rsp)
  764bd9:	mov    %rax,0x230(%rsp)
  764be1:	lea    0x1f0(%rsp),%rdi
  764be9:	call   74aac0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtCscdodAO9FK5_5alloc11collections5btree3map8IntoIterNtNtBK_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueEECs9C2G9YFESsD_29canonical_text_public_control>
  764bee:	lea    0x260(%rsp),%rdi
  764bf6:	call   74c8d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  764bfb:	mov    0x20(%rsp),%rax
  764c00:	lea    0x8(%rax),%r14
  764c04:	mov    0x354295(%rip),%r12        # ab8ea0 <_DYNAMIC+0x240>
  764c0b:	jmp    764c1d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x225d>
  764c0d:	nopl   (%rax)
  764c10:	add    $0x18,%r14
  764c14:	dec    %rbx
  764c17:	je     7649cf <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x200f>
  764c1d:	mov    -0x8(%r14),%rsi
  764c21:	test   %rsi,%rsi
  764c24:	je     764c10 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2250>
  764c26:	mov    (%r14),%rdi
  764c29:	mov    $0x1,%edx
  764c2e:	call   *%r12
  764c31:	jmp    764c10 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2250>
  764c33:	call   *0x35428f(%rip)        # ab8ec8 <_DYNAMIC+0x268>
  764c39:	call   *0x354289(%rip)        # ab8ec8 <_DYNAMIC+0x268>
  764c3f:	mov    %rax,%r15
  764c42:	mov    0x18(%rsp),%rsi
  764c47:	test   %rsi,%rsi
  764c4a:	je     764c5a <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x229a>
  764c4c:	mov    $0x1,%edx
  764c51:	mov    %rbx,%rdi
  764c54:	call   *0x354246(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  764c5a:	mov    0x68(%rsp),%r14
  764c5f:	mov    0x78(%rsp),%rcx
  764c64:	mov    %rcx,%rax
  764c67:	sub    %r14,%rax
  764c6a:	movabs $0xaaaaaaaaaaaaaaab,%rdx
  764c74:	mul    %rdx
  764c77:	cmp    %r14,%rcx
  764c7a:	jne    764c8e <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x22ce>
  764c7c:	mov    0x70(%rsp),%rax
  764c81:	test   %rax,%rax
  764c84:	jne    764ccf <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x230f>
  764c86:	mov    %r15,%rdi
  764c89:	call   a97380 <_Unwind_Resume@plt>
  764c8e:	mov    %rdx,%rbx
  764c91:	shr    $0x4,%rbx
  764c95:	add    $0x8,%r14
  764c99:	mov    0x354200(%rip),%r12        # ab8ea0 <_DYNAMIC+0x240>
  764ca0:	jmp    764cb9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x22f9>
  764ca2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  764cb0:	add    $0x18,%r14
  764cb4:	dec    %rbx
  764cb7:	je     764c7c <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x22bc>
  764cb9:	mov    -0x8(%r14),%rsi
  764cbd:	test   %rsi,%rsi
  764cc0:	je     764cb0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x22f0>
  764cc2:	mov    (%r14),%rdi
  764cc5:	mov    $0x1,%edx
  764cca:	call   *%r12
  764ccd:	jmp    764cb0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x22f0>
  764ccf:	mov    0x60(%rsp),%rdi
  764cd4:	shl    $0x3,%rax
  764cd8:	lea    (%rax,%rax,2),%rsi
  764cdc:	mov    $0x8,%edx
  764ce1:	call   *0x3541b9(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  764ce7:	mov    %r15,%rdi
  764cea:	call   a97380 <_Unwind_Resume@plt>

canonical_text_public_control::mount bytes=2801 frame=3384

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000764cf0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount>:
  764cf0:	push   %rbp
  764cf1:	push   %r15
  764cf3:	push   %r14
  764cf5:	push   %r13
  764cf7:	push   %r12
  764cf9:	push   %rbx
  764cfa:	sub    $0xd08,%rsp
  764d01:	mov    (%rdi),%rax
  764d04:	mov    %rax,0x10(%rsp)
  764d09:	mov    0x8(%rdi),%r14
  764d0d:	mov    0x10(%rdi),%rbx
  764d11:	movups -0x6951c8(%rip),%xmm0        # cfb50 <GCC_except_table0+0xd7e8>
  764d18:	movups %xmm0,0xf8(%rsp)
  764d20:	movq   $0x0,0x108(%rsp)
  764d2c:	lea    0x3b0(%rsp),%rdi
  764d34:	movabs $0x104000001a4,%r15
  764d3e:	movss  -0x6a297e(%rip),%xmm0        # c23c8 <GCC_except_table0+0x60>
  764d46:	mov    %r15,%rsi
  764d49:	call   *0x354459(%rip)        # ab91a8 <_DYNAMIC+0x548>
  764d4f:	mov    0x3b0(%rsp),%r13
  764d57:	cmp    $0xfffffffffffffffe,%r13
  764d5b:	jne    765432 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x742>
  764d61:	lea    0x3b0(%rsp),%rdi
  764d69:	call   796ac0 <_RNvXs_Cs9C2G9YFESsD_29canonical_text_public_controlNtB4_6EditorNtCslbxve4rcJus_4gpui4View7sources>
  764d6e:	mov    0x3b0(%rsp),%rax
  764d76:	movups 0x408(%rsp),%xmm0
  764d7e:	movaps %xmm0,0x150(%rsp)
  764d86:	movups 0x3f8(%rsp),%xmm0
  764d8e:	movaps %xmm0,0x140(%rsp)
  764d96:	movups 0x3e8(%rsp),%xmm0
  764d9e:	movaps %xmm0,0x130(%rsp)
  764da6:	movups 0x3d8(%rsp),%xmm0
  764dae:	movaps %xmm0,0x120(%rsp)
  764db6:	movups 0x3c8(%rsp),%xmm1
  764dbe:	movaps %xmm1,0x110(%rsp)
  764dc6:	movups 0x3b8(%rsp),%xmm2
  764dce:	movups %xmm1,0xa0(%rsp)
  764dd6:	movups %xmm0,0xb0(%rsp)
  764dde:	mov    0x130(%rsp),%rcx
  764de6:	mov    %rcx,0xc0(%rsp)
  764dee:	mov    0x158(%rsp),%rcx
  764df6:	mov    %rcx,0xe8(%rsp)
  764dfe:	movups 0x148(%rsp),%xmm0
  764e06:	movups %xmm0,0xd8(%rsp)
  764e0e:	movups 0x138(%rsp),%xmm0
  764e16:	movups %xmm0,0xc8(%rsp)
  764e1e:	mov    %rax,0x88(%rsp)
  764e26:	movups %xmm2,0x90(%rsp)
  764e2e:	movl   $0x0,0x110(%rsp)
  764e39:	movl   $0x434b0000,0x118(%rsp)
  764e44:	movw   $0x0,0x11c(%rsp)
  764e4e:	lea    0x3b0(%rsp),%rdi
  764e56:	lea    0x110(%rsp),%rcx
  764e5e:	mov    $0x1a4,%esi
  764e63:	mov    $0x104,%edx
  764e68:	call   *0x354342(%rip)        # ab91b0 <_DYNAMIC+0x550>
  764e6e:	mov    0x3b0(%rsp),%r13
  764e76:	mov    0x3b8(%rsp),%ebp
  764e7d:	mov    0x3bc(%rsp),%r12d
  764e85:	cmp    $0x2,%r13
  764e89:	je     76547f <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x78f>
  764e8f:	lea    0x3c0(%rsp),%rsi
  764e97:	lea    0xb30(%rsp),%rdi
  764e9f:	mov    $0x1d8,%edx
  764ea4:	call   *0x354016(%rip)        # ab8ec0 <memcpy@GLIBC_2.14>
  764eaa:	mov    %r13,0xb20(%rsp)
  764eb2:	mov    %ebp,0xb28(%rsp)
  764eb9:	mov    %r12d,0xb2c(%rsp)
  764ec1:	call   *0x3542f1(%rip)        # ab91b8 <_DYNAMIC+0x558>
  764ec7:	mov    %rax,%r12
  764eca:	lea    0x110(%rsp),%rdi
  764ed2:	call   *0x3542e8(%rip)        # ab91c0 <_DYNAMIC+0x560>
  764ed8:	mov    %rbx,0x650(%rsp)
  764ee0:	movl   $0x0,0x658(%rsp)
  764eeb:	movups 0xf4(%rsp),%xmm0
  764ef3:	movups 0x100(%rsp),%xmm1
  764efb:	movups %xmm0,0x65c(%rsp)
  764f03:	movups %xmm1,0x668(%rsp)
  764f0b:	movl   $0x0,0x678(%rsp)
  764f16:	movups 0x88(%rsp),%xmm0
  764f1e:	movups 0x98(%rsp),%xmm1
  764f26:	movups 0xa8(%rsp),%xmm2
  764f2e:	movups 0xb8(%rsp),%xmm3
  764f36:	movups %xmm0,0x5d8(%rsp)
  764f3e:	movups %xmm1,0x5e8(%rsp)
  764f46:	movups %xmm2,0x5f8(%rsp)
  764f4e:	movups %xmm3,0x608(%rsp)
  764f56:	movups 0xc8(%rsp),%xmm0
  764f5e:	movups %xmm0,0x618(%rsp)
  764f66:	movups 0xd8(%rsp),%xmm0
  764f6e:	movups %xmm0,0x628(%rsp)
  764f76:	mov    0xe8(%rsp),%rax
  764f7e:	mov    %rax,0x638(%rsp)
  764f86:	lea    0x6b0(%rsp),%rdi
  764f8e:	lea    0x110(%rsp),%rsi
  764f96:	mov    0x353f23(%rip),%rbx        # ab8ec0 <memcpy@GLIBC_2.14>
  764f9d:	mov    $0x298,%edx
  764fa2:	call   *%rbx
  764fa4:	lea    0x3b0(%rsp),%rdi
  764fac:	lea    0xb20(%rsp),%rsi
  764fb4:	mov    $0x1e8,%edx
  764fb9:	call   *%rbx
  764fbb:	mov    0x10(%rsp),%rax
  764fc0:	mov    %rax,0x640(%rsp)
  764fc8:	mov    %r14,0x648(%rsp)
  764fd0:	movq   $0x0,0x680(%rsp)
  764fdc:	movq   $0x8,0x688(%rsp)
  764fe8:	xorps  %xmm0,%xmm0
  764feb:	movups %xmm0,0x690(%rsp)
  764ff3:	movq   $0x8,0x6a0(%rsp)
  764fff:	movq   $0x0,0x6a8(%rsp)
  76500b:	movq   $0x0,0x9c8(%rsp)
  765017:	movups %xmm0,0x598(%rsp)
  76501f:	movups %xmm0,0x5a8(%rsp)
  765027:	movups %xmm0,0x9b0(%rsp)
  76502f:	movq   $0x1,0x9d0(%rsp)
  76503b:	movq   $0x0,0x9d8(%rsp)
  765047:	mov    %r12,0x9a0(%rsp)
  76504f:	movq   $0x0,0x9e8(%rsp)
  76505b:	movq   $0x0,0xa30(%rsp)
  765067:	movups %xmm0,0x9f8(%rsp)
  76506f:	movq   $0x0,0xa08(%rsp)
  76507b:	movups %xmm0,0xa18(%rsp)
  765083:	movq   $0x0,0x948(%rsp)
  76508f:	movq   $0x8,0x950(%rsp)
  76509b:	movups %xmm0,0x958(%rsp)
  7650a3:	movq   $0x0,0xa38(%rsp)
  7650af:	movq   $0x0,0xa48(%rsp)
  7650bb:	movl   $0x1000101,0xb18(%rsp)
  7650c6:	movw   $0x0,0xb1c(%rsp)
  7650d0:	movups %xmm0,0xa50(%rsp)
  7650d8:	movups %xmm0,0xa60(%rsp)
  7650e0:	movq   $0x0,0xa70(%rsp)
  7650ec:	mov    %r15,0xa78(%rsp)
  7650f4:	movsd  -0x6a219c(%rip),%xmm1        # c2f60 <GCC_except_table0+0xbf8>
  7650fc:	movsd  %xmm1,0xb10(%rsp)
  765105:	movq   $0x1,0x9a8(%rsp)
  765111:	movq   $0xffffffffffffffff,0x978(%rsp)
  76511d:	movq   $0x0,0xa80(%rsp)
  765129:	movq   $0x0,0xa90(%rsp)
  765135:	movq   $0x8,0x968(%rsp)
  765141:	movq   $0x0,0x970(%rsp)
  76514d:	movb   $0x0,0xb1e(%rsp)
  765155:	movups %xmm0,0xaf8(%rsp)
  76515d:	movups %xmm0,0xae8(%rsp)
  765165:	movups %xmm0,0xad8(%rsp)
  76516d:	movups %xmm0,0xac8(%rsp)
  765175:	movups %xmm0,0xab8(%rsp)
  76517d:	movups %xmm0,0xaa8(%rsp)
  765185:	movups %xmm0,0xa98(%rsp)
  76518d:	movq   $0x0,0xb08(%rsp)
  765199:	call   *0x353d09(%rip)        # ab8ea8 <_DYNAMIC+0x248>
  76519f:	mov    $0x770,%edi
  7651a4:	mov    $0x8,%esi
  7651a9:	call   *0x353d01(%rip)        # ab8eb0 <_DYNAMIC+0x250>
  7651af:	test   %rax,%rax
  7651b2:	je     7653bd <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x6cd>
  7651b8:	mov    %rax,%rbx
  7651bb:	lea    0x3b0(%rsp),%rsi
  7651c3:	mov    $0x770,%edx
  7651c8:	mov    %rax,%rdi
  7651cb:	call   *0x353cef(%rip)        # ab8ec0 <memcpy@GLIBC_2.14>
  7651d1:	mov    %rbx,0x20(%rsp)
  7651d6:	lea    0x28(%rsp),%rdx
  7651db:	movq   $0x0,(%rsp)
  7651e3:	lea    0x28(%rsp),%rdi
  7651e8:	mov    $0x8,%r8d
  7651ee:	mov    %rbx,%rsi
  7651f1:	mov    $0x1,%ecx
  7651f6:	xor    %r9d,%r9d
  7651f9:	call   769140 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB4_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE21describe_with_changedBW_>
  7651fe:	mov    0x28(%rsp),%r13
  765203:	cmp    $0xfffffffffffffffe,%r13
  765207:	jne    7653d2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x6e2>
  76520d:	lea    0x28(%rsp),%rdi
  765212:	mov    %rbx,%rsi
  765215:	call   78ccd0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE7presentBO_>
  76521a:	mov    0x28(%rsp),%r13
  76521f:	cmp    $0xfffffffffffffffe,%r13
  765223:	jne    7653d2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x6e2>
  765229:	mov    0x20(%rsp),%rbx
  76522e:	lea    0x3b0(%rsp),%rdi
  765236:	mov    %rbx,%rsi
  765239:	call   760520 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack>
  76523e:	test   %rbx,%rbx
  765241:	je     765497 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x7a7>
  765247:	cmpb   $0x0,0x76e(%rbx)
  76524e:	jne    76549e <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x7ae>
  765254:	cmpb   $0x1,0x76a(%rbx)
  76525b:	jne    7654a5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x7b5>
  765261:	mov    0x5c0(%rbx),%r12
  765268:	mov    $0x1a,%eax
  76526d:	mov    %rax,0x10(%rsp)
  765272:	test   %r12,%r12
  765275:	je     7654af <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x7bf>
  76527b:	mov    0x5b8(%rbx),%r13
  765282:	shl    $0x6,%r12
  765286:	lea    0x1e8(%rbx),%r14
  76528d:	xor    %ebp,%ebp
  76528f:	mov    0x353cca(%rip),%r15        # ab8f60 <_DYNAMIC+0x300>
  765296:	jmp    7652ad <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x5bd>
  765298:	nopl   0x0(%rax,%rax,1)
  7652a0:	add    $0x40,%rbp
  7652a4:	cmp    %rbp,%r12
  7652a7:	je     7654af <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x7bf>
  7652ad:	cmpb   $0x4,0x3d(%r13,%rbp,1)
  7652b3:	jne    7652a0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x5b0>
  7652b5:	mov    0x20(%r13,%rbp,1),%rsi
  7652ba:	mov    %r14,%rdi
  7652bd:	call   *%r15
  7652c0:	test   %al,%al
  7652c2:	je     7652a0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x5b0>
  7652c4:	mov    0x20(%r13,%rbp,1),%rsi
  7652c9:	lea    0x5f0(%rbx),%r12
  7652d0:	mov    %r12,%rdi
  7652d3:	call   *0x353e27(%rip)        # ab9100 <_DYNAMIC+0x4a0>
  7652d9:	cmpb   $0x0,0x76e(%rbx)
  7652e0:	jne    7654f5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x805>
  7652e6:	mov    %rax,%r14
  7652e9:	cmp    (%r12),%rax
  7652ed:	jne    7654fc <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x80c>
  7652f3:	mov    %rdx,%r15
  7652f6:	mov    0x628(%rbx),%r12
  7652fd:	mov    0x630(%rbx),%r13
  765304:	lea    0x3b0(%rsp),%rdi
  76530c:	mov    %rbx,%rsi
  76530f:	call   78c570 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE16resolve_identityBO_>
  765314:	mov    0x3b0(%rsp),%rax
  76531c:	mov    0x3b8(%rsp),%rdi
  765324:	cmp    $0xfffffffffffffffe,%rax
  765328:	jne    765503 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x813>
  76532e:	mov    0x2e0(%rbx),%rsi
  765335:	cmp    %rsi,%rdi
  765338:	jae    765539 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x849>
  76533e:	lea    (%rdi,%rdi,4),%rdi
  765342:	shl    $0x3,%rdi
  765346:	add    0x2d8(%rbx),%rdi
  76534d:	call   *0x353e75(%rip)        # ab91c8 <_DYNAMIC+0x568>
  765353:	test   %al,%al
  765355:	je     76554b <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x85b>
  76535b:	mov    %r14,0x628(%rbx)
  765362:	mov    %r15,0x630(%rbx)
  765369:	movq   $0x0,0x758(%rbx)
  765374:	lea    0x110(%rsp),%rdi
  76537c:	mov    %rbx,%rsi
  76537f:	mov    %r12,%rdx
  765382:	mov    %r13,%rcx
  765385:	call   7701a0 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE20publish_focus_changeB12_>
  76538a:	cmpl   $0xfffffffe,0x110(%rsp)
  765392:	jne    765593 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x8a3>
  765398:	lea    0x3b0(%rsp),%rdi
  7653a0:	mov    %rbx,%rsi
  7653a3:	call   760520 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack>
  7653a8:	mov    %rbx,%rax
  7653ab:	add    $0xd08,%rsp
  7653b2:	pop    %rbx
  7653b3:	pop    %r12
  7653b5:	pop    %r13
  7653b7:	pop    %r14
  7653b9:	pop    %r15
  7653bb:	pop    %rbp
  7653bc:	ret
  7653bd:	mov    $0x8,%edi
  7653c2:	mov    $0x770,%esi
  7653c7:	call   *0x353aeb(%rip)        # ab8eb8 <_DYNAMIC+0x258>
  7653cd:	jmp    765702 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xa12>
  7653d2:	mov    0x30(%rsp),%rbp
  7653d7:	movups 0x38(%rsp),%xmm0
  7653dc:	movaps %xmm0,0x70(%rsp)
  7653e1:	movups 0x48(%rsp),%xmm0
  7653e6:	movaps %xmm0,0x60(%rsp)
  7653eb:	movzbl 0x58(%rsp),%r15d
  7653f1:	mov    0x59(%rsp),%eax
  7653f5:	mov    %eax,0x18(%rsp)
  7653f9:	mov    0x5c(%rsp),%eax
  7653fd:	mov    %eax,0x1b(%rsp)
  765401:	mov    0x20(%rsp),%rbx
  765406:	test   %rbx,%rbx
  765409:	je     765426 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x736>
  76540b:	mov    %rbx,%rdi
  76540e:	call   747d30 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui7runtime7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEEB1h_>
  765413:	mov    $0x770,%esi
  765418:	mov    $0x8,%edx
  76541d:	mov    %rbx,%rdi
  765420:	call   *0x353a7a(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  765426:	mov    %rbp,%r12
  765429:	shr    $0x20,%r12
  76542d:	jmp    765689 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x999>
  765432:	mov    0x3b8(%rsp),%rbp
  76543a:	mov    %rbp,%r12
  76543d:	shr    $0x20,%r12
  765441:	movups 0x3c0(%rsp),%xmm0
  765449:	movaps %xmm0,0x70(%rsp)
  76544e:	movups 0x3d0(%rsp),%xmm0
  765456:	movaps %xmm0,0x60(%rsp)
  76545b:	movzbl 0x3e0(%rsp),%r15d
  765464:	mov    0x3e1(%rsp),%eax
  76546b:	mov    %eax,0x18(%rsp)
  76546f:	mov    0x3e4(%rsp),%eax
  765476:	mov    %eax,0x1b(%rsp)
  76547a:	jmp    76566e <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x97e>
  76547f:	lea    0x88(%rsp),%rdi
  765487:	call   747b80 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui6source7SourcesNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEEB1g_>
  76548c:	mov    $0x23,%r13d
  765492:	jmp    76566e <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x97e>
  765497:	mov    $0xd,%eax
  76549c:	jmp    7654aa <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x7ba>
  76549e:	mov    $0xe,%eax
  7654a3:	jmp    7654aa <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x7ba>
  7654a5:	mov    $0x12,%eax
  7654aa:	mov    %rax,0x10(%rsp)
  7654af:	mov    0x10(%rsp),%rax
  7654b4:	mov    %rax,0x3b0(%rsp)
  7654bc:	movq   $0x0,0x3b8(%rsp)
  7654c8:	lea    -0x695b6e(%rip),%rdi        # cf961 <GCC_except_table0+0xd5f9>
  7654cf:	lea    0x3344c2(%rip),%rcx        # a99998 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1260>
  7654d6:	lea    0x333e23(%rip),%r8        # a99300 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xbc8>
  7654dd:	lea    0x3b0(%rsp),%rdx
  7654e5:	mov    $0x2a,%esi
  7654ea:	call   *0x353a80(%rip)        # ab8f70 <_DYNAMIC+0x310>
  7654f0:	jmp    765702 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xa12>
  7654f5:	mov    $0xe,%eax
  7654fa:	jmp    765550 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x860>
  7654fc:	mov    $0x11,%eax
  765501:	jmp    76551b <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x82b>
  765503:	movups 0x3c0(%rsp),%xmm0
  76550b:	movups 0x3d0(%rsp),%xmm1
  765513:	movzbl 0x3e0(%rsp),%ecx
  76551b:	mov    0x3e1(%rsp),%edx
  765522:	mov    0x3e4(%rsp),%esi
  765529:	mov    %esi,0xb23(%rsp)
  765530:	mov    %edx,0xb20(%rsp)
  765537:	jmp    765550 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x860>
  765539:	lea    0x334980(%rip),%rdx        # a99ec0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1788>
  765540:	call   *0x35398a(%rip)        # ab8ed0 <_DYNAMIC+0x270>
  765546:	jmp    765702 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xa12>
  76554b:	mov    $0x16,%eax
  765550:	mov    %rax,0x110(%rsp)
  765558:	mov    %rdi,0x118(%rsp)
  765560:	movups %xmm0,0x120(%rsp)
  765568:	movups %xmm1,0x130(%rsp)
  765570:	mov    %cl,0x140(%rsp)
  765577:	mov    0xb20(%rsp),%eax
  76557e:	mov    0xb23(%rsp),%ecx
  765585:	mov    %eax,0x141(%rsp)
  76558c:	mov    %ecx,0x144(%rsp)
  765593:	mov    0x140(%rsp),%rax
  76559b:	mov    %rax,0x3e0(%rsp)
  7655a3:	mov    0x110(%rsp),%rax
  7655ab:	mov    0x118(%rsp),%rcx
  7655b3:	movups 0x120(%rsp),%xmm0
  7655bb:	movups 0x130(%rsp),%xmm1
  7655c3:	movaps %xmm1,0x3d0(%rsp)
  7655cb:	movaps %xmm0,0x3c0(%rsp)
  7655d3:	mov    %rax,0x3b0(%rsp)
  7655db:	mov    %rcx,0x3b8(%rsp)
  7655e3:	lea    -0x695a08(%rip),%rdi        # cfbe2 <GCC_except_table0+0xd87a>
  7655ea:	lea    0x3343a7(%rip),%rcx        # a99998 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1260>
  7655f1:	lea    0x334310(%rip),%r8        # a99908 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x11d0>
  7655f8:	lea    0x3b0(%rsp),%rdx
  765600:	mov    $0x2b,%esi
  765605:	call   *0x353965(%rip)        # ab8f70 <_DYNAMIC+0x310>
  76560b:	jmp    765702 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xa12>
  765610:	mov    %rax,%r15
  765613:	mov    $0x770,%esi
  765618:	mov    $0x8,%edx
  76561d:	mov    %rbx,%rdi
  765620:	call   *0x35387a(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  765626:	mov    %r15,%rdi
  765629:	call   a97380 <_Unwind_Resume@plt>
  76562e:	mov    %rax,%r15
  765631:	jmp    76574c <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xa5c>
  765636:	mov    %rax,%rdi
  765639:	call   *0x3538b9(%rip)        # ab8ef8 <_DYNAMIC+0x298>
  76563f:	mov    %rax,%r12
  765642:	mov    %rdx,%r13
  765645:	mov    (%rdx),%rax
  765648:	test   %rax,%rax
  76564b:	je     765652 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x962>
  76564d:	mov    %r12,%rdi
  765650:	call   *%rax
  765652:	mov    0x8(%r13),%rsi
  765656:	test   %rsi,%rsi
  765659:	je     765668 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x978>
  76565b:	mov    0x10(%r13),%rdx
  76565f:	mov    %r12,%rdi
  765662:	call   *0x353838(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  765668:	mov    $0xf,%r13d
  76566e:	cmpq   $0x0,0x10(%rsp)
  765674:	je     765689 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x999>
  765676:	mov    $0x1,%edx
  76567b:	mov    %r14,%rdi
  76567e:	mov    0x10(%rsp),%rsi
  765683:	call   *0x353817(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  765689:	mov    %r13,0x110(%rsp)
  765691:	shl    $0x20,%r12
  765695:	mov    %ebp,%eax
  765697:	or     %r12,%rax
  76569a:	mov    %rax,0x118(%rsp)
  7656a2:	movaps 0x70(%rsp),%xmm0
  7656a7:	movups %xmm0,0x120(%rsp)
  7656af:	movaps 0x60(%rsp),%xmm0
  7656b4:	movups %xmm0,0x130(%rsp)
  7656bc:	mov    %r15b,0x140(%rsp)
  7656c4:	mov    0x18(%rsp),%eax
  7656c8:	mov    0x1b(%rsp),%ecx
  7656cc:	mov    %eax,0x141(%rsp)
  7656d3:	mov    %ecx,0x144(%rsp)
  7656da:	lea    -0x695aff(%rip),%rdi        # cfbe2 <GCC_except_table0+0xd87a>
  7656e1:	lea    0x3342b0(%rip),%rcx        # a99998 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1260>
  7656e8:	lea    0x334201(%rip),%r8        # a998f0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x11b8>
  7656ef:	lea    0x110(%rsp),%rdx
  7656f7:	mov    $0x2b,%esi
  7656fc:	call   *0x35386e(%rip)        # ab8f70 <_DYNAMIC+0x310>
  765702:	ud2
  765704:	mov    %rax,%r15
  765707:	mov    0x8(%r13),%rsi
  76570b:	test   %rsi,%rsi
  76570e:	je     765759 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xa69>
  765710:	mov    0x10(%r13),%rdx
  765714:	mov    %r12,%rdi
  765717:	call   *0x353783(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  76571d:	jmp    765759 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xa69>
  76571f:	call   *0x3537db(%rip)        # ab8f00 <_DYNAMIC+0x2a0>
  765725:	mov    %rax,%r15
  765728:	jmp    765759 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xa69>
  76572a:	mov    %rax,%r15
  76572d:	mov    0x20(%rsp),%rdi
  765732:	call   747cd0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui7runtime3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEEB1d_>
  765737:	jmp    7657d3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xae3>
  76573c:	mov    %rax,%r15
  76573f:	lea    0xb20(%rsp),%rdi
  765747:	call   74d050 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas6canvas6CanvasECs9C2G9YFESsD_29canonical_text_public_control>
  76574c:	lea    0x88(%rsp),%rdi
  765754:	call   747b80 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui6source7SourcesNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEEB1g_>
  765759:	cmpq   $0x0,0x10(%rsp)
  76575f:	je     7657d3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xae3>
  765761:	mov    $0x1,%edx
  765766:	mov    %r14,%rdi
  765769:	mov    0x10(%rsp),%rsi
  76576e:	call   *0x35372c(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  765774:	mov    %r15,%rdi
  765777:	call   a97380 <_Unwind_Resume@plt>
  76577c:	call   *0x353746(%rip)        # ab8ec8 <_DYNAMIC+0x268>
  765782:	mov    %rax,%r15
  765785:	lea    0x110(%rsp),%rdi
  76578d:	call   74d540 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  765792:	mov    %r15,%rdi
  765795:	call   a97380 <_Unwind_Resume@plt>
  76579a:	jmp    7657a3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xab3>
  76579c:	jmp    76579e <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xaae>
  76579e:	mov    %rax,%r15
  7657a1:	jmp    7657b3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xac3>
  7657a3:	mov    %rax,%r15
  7657a6:	lea    0x3b0(%rsp),%rdi
  7657ae:	call   74d540 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  7657b3:	mov    %rbx,%rdi
  7657b6:	call   747cd0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui7runtime3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEEB1d_>
  7657bb:	jmp    7657d3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xae3>
  7657bd:	call   *0x353705(%rip)        # ab8ec8 <_DYNAMIC+0x268>
  7657c3:	mov    %rax,%r15
  7657c6:	lea    0x3b0(%rsp),%rdi
  7657ce:	call   747d30 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui7runtime7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEEB1h_>
  7657d3:	mov    %r15,%rdi
  7657d6:	call   a97380 <_Unwind_Resume@plt>
  7657db:	call   *0x3536e7(%rip)        # ab8ec8 <_DYNAMIC+0x268>

canonical_text_public_control::source bytes=2078 frame=88

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007657f0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source>:
  7657f0:	push   %r15
  7657f2:	push   %r14
  7657f4:	push   %rbx
  7657f5:	sub    $0x40,%rsp
  7657f9:	mov    %rsi,0x20(%rsp)
  7657fe:	mov    %rdx,0x28(%rsp)
  765803:	lea    -0x3(%rdx),%rax
  765807:	cmp    $0xa,%rax
  76580b:	ja     765f4a <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x75a>
  765811:	mov    %rdi,%rbx
  765814:	lea    -0x6a1887(%rip),%rcx        # c3f94 <GCC_except_table0+0x1c2c>
  76581b:	movslq (%rcx,%rax,4),%rax
  76581f:	add    %rcx,%rax
  765822:	jmp    *%rax
  765824:	lea    -0x695e8c(%rip),%rax        # cf99f <GCC_except_table0+0xd637>
  76582b:	mov    %rsi,%rdi
  76582e:	mov    %rax,%rsi
  765831:	call   *0x353931(%rip)        # ab9168 <bcmp@GLIBC_2.2.5>
  765837:	test   %eax,%eax
  765839:	jne    765f4a <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x75a>
  76583f:	call   *0x353663(%rip)        # ab8ea8 <_DYNAMIC+0x248>
  765845:	mov    $0x1b80,%edi
  76584a:	mov    $0x1,%esi
  76584f:	call   *0x35365b(%rip)        # ab8eb0 <_DYNAMIC+0x250>
  765855:	test   %rax,%rax
  765858:	je     765f79 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x789>
  76585e:	mov    %rax,%r14
  765861:	movups -0x695cbe(%rip),%xmm0        # cfbaa <GCC_except_table0+0xd842>
  765868:	movups %xmm0,0x20(%rax)
  76586c:	movabs $0x20aad7a9d7a8d7a7,%rax
  765876:	mov    %rax,0x2f(%r14)
  76587a:	movups -0x695ce7(%rip),%xmm1        # cfb9a <GCC_except_table0+0xd832>
  765881:	movups %xmm1,0x10(%r14)
  765886:	movups -0x695d03(%rip),%xmm2        # cfb8a <GCC_except_table0+0xd822>
  76588d:	movups %xmm2,(%r14)
  765891:	movups %xmm2,0x37(%r14)
  765896:	movups %xmm1,0x47(%r14)
  76589b:	movups %xmm0,0x57(%r14)
  7658a0:	mov    %rax,0x66(%r14)
  7658a4:	movups %xmm2,0x6e(%r14)
  7658a9:	movups %xmm1,0x7e(%r14)
  7658ae:	movups 0x20(%r14),%xmm0
  7658b3:	movups %xmm0,0x8e(%r14)
  7658bb:	movups 0x30(%r14),%xmm0
  7658c0:	movups %xmm0,0x9e(%r14)
  7658c8:	movups 0x40(%r14),%xmm0
  7658cd:	movups %xmm0,0xae(%r14)
  7658d5:	movups 0x50(%r14),%xmm0
  7658da:	movups %xmm0,0xbe(%r14)
  7658e2:	mov    0x5e(%r14),%rax
  7658e6:	mov    %rax,0xcc(%r14)
  7658ed:	mov    0x66(%r14),%rax
  7658f1:	mov    %rax,0xd4(%r14)
  7658f8:	lea    0xdc(%r14),%rdi
  7658ff:	mov    0x3535ba(%rip),%r15        # ab8ec0 <memcpy@GLIBC_2.14>
  765906:	mov    $0xdc,%edx
  76590b:	mov    %r14,%rsi
  76590e:	call   *%r15
  765911:	lea    0x1b8(%r14),%rdi
  765918:	mov    $0x1b8,%edx
  76591d:	mov    %r14,%rsi
  765920:	call   *%r15
  765923:	lea    0x370(%r14),%rdi
  76592a:	mov    $0x370,%edx
  76592f:	mov    %r14,%rsi
  765932:	call   *%r15
  765935:	lea    0x6e0(%r14),%rdi
  76593c:	mov    $0x6e0,%edx
  765941:	mov    %r14,%rsi
  765944:	call   *%r15
  765947:	mov    %r14,%rdi
  76594a:	add    $0xdc0,%rdi
  765951:	mov    $0xdc0,%edx
  765956:	mov    %r14,%rsi
  765959:	call   *%r15
  76595c:	movq   $0x1b80,(%rbx)
  765963:	mov    %r14,0x8(%rbx)
  765967:	movq   $0x1b80,0x10(%rbx)
  76596f:	jmp    765f40 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x750>
  765974:	mov    $0x74706d65,%eax
  765979:	xor    (%rsi),%eax
  76597b:	movzbl 0x4(%rsi),%ecx
  76597f:	xor    $0x79,%ecx
  765982:	or     %eax,%ecx
  765984:	je     765edd <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x6ed>
  76598a:	mov    $0x6562616c,%eax
  76598f:	xor    (%rsi),%eax
  765991:	movzbl 0x4(%rsi),%ecx
  765995:	xor    $0x6c,%ecx
  765998:	or     %eax,%ecx
  76599a:	je     765ef6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x706>
  7659a0:	lea    -0x696005(%rip),%rax        # cf9a2 <GCC_except_table0+0xd63a>
  7659a7:	mov    %rsi,%rdi
  7659aa:	mov    %rax,%rsi
  7659ad:	call   *0x3537b5(%rip)        # ab9168 <bcmp@GLIBC_2.2.5>
  7659b3:	test   %eax,%eax
  7659b5:	jne    765f4a <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x75a>
  7659bb:	call   *0x3534e7(%rip)        # ab8ea8 <_DYNAMIC+0x248>
  7659c1:	mov    $0x880,%edi
  7659c6:	mov    $0x1,%esi
  7659cb:	call   *0x3534df(%rip)        # ab8eb0 <_DYNAMIC+0x250>
  7659d1:	test   %rax,%rax
  7659d4:	je     765fc9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x7d9>
  7659da:	mov    %rax,%r14
  7659dd:	movups -0x695e6c(%rip),%xmm0        # cfb78 <GCC_except_table0+0xd810>
  7659e4:	movups %xmm0,0x10(%rax)
  7659e8:	movups -0x695e87(%rip),%xmm1        # cfb68 <GCC_except_table0+0xd800>
  7659ef:	movups %xmm1,(%rax)
  7659f2:	movw   $0xa0d,0x20(%rax)
  7659f8:	movups %xmm1,0x22(%rax)
  7659fc:	movups %xmm0,0x32(%rax)
  765a00:	movw   $0xa0d,0x42(%rax)
  765a06:	movups %xmm1,0x44(%rax)
  765a0a:	movups %xmm0,0x54(%rax)
  765a0e:	movzwl 0x20(%rax),%eax
  765a12:	mov    %ax,0x64(%r14)
  765a17:	mov    0x22(%r14),%rax
  765a1b:	mov    %rax,0x66(%r14)
  765a1f:	mov    0x2a(%r14),%eax
  765a23:	mov    %eax,0x6e(%r14)
  765a27:	movzwl 0x2e(%r14),%eax
  765a2c:	mov    %ax,0x72(%r14)
  765a31:	movups 0x30(%r14),%xmm0
  765a36:	movups %xmm0,0x74(%r14)
  765a3b:	mov    0x40(%r14),%eax
  765a3f:	mov    %eax,0x84(%r14)
  765a46:	lea    0x88(%r14),%rdi
  765a4d:	mov    0x35346c(%rip),%r15        # ab8ec0 <memcpy@GLIBC_2.14>
  765a54:	mov    $0x88,%edx
  765a59:	mov    %r14,%rsi
  765a5c:	call   *%r15
  765a5f:	lea    0x110(%r14),%rdi
  765a66:	mov    $0x110,%edx
  765a6b:	mov    %r14,%rsi
  765a6e:	call   *%r15
  765a71:	lea    0x220(%r14),%rdi
  765a78:	mov    $0x220,%edx
  765a7d:	mov    %r14,%rsi
  765a80:	call   *%r15
  765a83:	mov    %r14,%rdi
  765a86:	add    $0x440,%rdi
  765a8d:	mov    $0x440,%edx
  765a92:	mov    %r14,%rsi
  765a95:	call   *%r15
  765a98:	movq   $0x880,(%rbx)
  765a9f:	mov    %r14,0x8(%rbx)
  765aa3:	movq   $0x880,0x10(%rbx)
  765aab:	jmp    765f40 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x750>
  765ab0:	cmpl   $0x796e6974,(%rsi)
  765ab6:	jne    765f4a <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x75a>
  765abc:	call   *0x3533e6(%rip)        # ab8ea8 <_DYNAMIC+0x248>
  765ac2:	mov    $0x1,%edi
  765ac7:	mov    $0x1,%esi
  765acc:	call   *0x3533de(%rip)        # ab8eb0 <_DYNAMIC+0x250>
  765ad2:	test   %rax,%rax
  765ad5:	je     765f89 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x799>
  765adb:	movb   $0x61,(%rax)
  765ade:	movq   $0x1,(%rbx)
  765ae5:	mov    %rax,0x8(%rbx)
  765ae9:	movq   $0x1,0x10(%rbx)
  765af1:	jmp    765f40 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x750>
  765af6:	lea    -0x696156(%rip),%rax        # cf9a7 <GCC_except_table0+0xd63f>
  765afd:	mov    %rsi,%rdi
  765b00:	mov    %rax,%rsi
  765b03:	call   *0x35365f(%rip)        # ab9168 <bcmp@GLIBC_2.2.5>
  765b09:	test   %eax,%eax
  765b0b:	jne    765f4a <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x75a>
  765b11:	call   *0x353391(%rip)        # ab8ea8 <_DYNAMIC+0x248>
  765b17:	mov    $0x580,%edi
  765b1c:	mov    $0x1,%esi
  765b21:	call   *0x353389(%rip)        # ab8eb0 <_DYNAMIC+0x250>
  765b27:	test   %rax,%rax
  765b2a:	je     765f99 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x7a9>
  765b30:	mov    %rax,%r14
  765b33:	movabs $0x616c0aa880e20a0d,%rax
  765b3d:	mov    %rax,(%r14)
  765b40:	movl   $0xa747361,0x7(%r14)
  765b48:	mov    %rax,0xb(%r14)
  765b4c:	movl   $0xa747361,0x12(%r14)
  765b54:	movups (%r14),%xmm0
  765b58:	movups %xmm0,0x16(%r14)
  765b5d:	mov    0xe(%r14),%rax
  765b61:	mov    %rax,0x24(%r14)
  765b65:	movups %xmm0,0x2c(%r14)
  765b6a:	movups 0x10(%r14),%xmm1
  765b6f:	movups %xmm1,0x3c(%r14)
  765b74:	mov    0x1c(%r14),%rax
  765b78:	mov    %rax,0x48(%r14)
  765b7c:	mov    0x24(%r14),%rax
  765b80:	mov    %rax,0x50(%r14)
  765b84:	movups %xmm0,0x58(%r14)
  765b89:	movups %xmm1,0x68(%r14)
  765b8e:	mov    0x20(%r14),%eax
  765b92:	mov    %eax,0x78(%r14)
  765b96:	mov    0x24(%r14),%rax
  765b9a:	mov    %rax,0x7c(%r14)
  765b9e:	mov    0x2c(%r14),%eax
  765ba2:	mov    %eax,0x84(%r14)
  765ba9:	movups 0x30(%r14),%xmm0
  765bae:	movups %xmm0,0x88(%r14)
  765bb6:	mov    0x40(%r14),%rax
  765bba:	mov    %rax,0x98(%r14)
  765bc1:	mov    0x48(%r14),%rax
  765bc5:	mov    %rax,0xa0(%r14)
  765bcc:	mov    0x50(%r14),%rax
  765bd0:	mov    %rax,0xa8(%r14)
  765bd7:	lea    0xb0(%r14),%rdi
  765bde:	mov    0x3532db(%rip),%r15        # ab8ec0 <memcpy@GLIBC_2.14>
  765be5:	mov    $0xb0,%edx
  765bea:	mov    %r14,%rsi
  765bed:	call   *%r15
  765bf0:	lea    0x160(%r14),%rdi
  765bf7:	mov    $0x160,%edx
  765bfc:	mov    %r14,%rsi
  765bff:	call   *%r15
  765c02:	mov    %r14,%rdi
  765c05:	add    $0x2c0,%rdi
  765c0c:	mov    $0x2c0,%edx
  765c11:	mov    %r14,%rsi
  765c14:	call   *%r15
  765c17:	movq   $0x580,(%rbx)
  765c1e:	mov    %r14,0x8(%rbx)
  765c22:	movq   $0x580,0x10(%rbx)
  765c2a:	jmp    765f40 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x750>
  765c2f:	movabs $0x3364657070617277,%rax
  765c39:	xor    (%rsi),%rax
  765c3c:	movzwl 0x8(%rsi),%ecx
  765c40:	xor    $0x6b32,%rcx
  765c47:	or     %rax,%rcx
  765c4a:	jne    765f4a <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x75a>
  765c50:	call   *0x353252(%rip)        # ab8ea8 <_DYNAMIC+0x248>
  765c56:	mov    $0x8000,%edi
  765c5b:	mov    $0x1,%esi
  765c60:	call   *0x35324a(%rip)        # ab8eb0 <_DYNAMIC+0x250>
  765c66:	test   %rax,%rax
  765c69:	je     765fa9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x7b9>
  765c6f:	mov    %rax,%r14
  765c72:	movabs $0x6161616161616161,%rax
  765c7c:	mov    %rax,(%r14)
  765c7f:	mov    %rax,0x8(%r14)
  765c83:	movups (%r14),%xmm0
  765c87:	movups %xmm0,0x10(%r14)
  765c8c:	movups %xmm0,0x20(%r14)
  765c91:	movups %xmm0,0x30(%r14)
  765c96:	movups %xmm0,0x40(%r14)
  765c9b:	movups %xmm0,0x50(%r14)
  765ca0:	movups %xmm0,0x60(%r14)
  765ca5:	movups %xmm0,0x70(%r14)
  765caa:	movups %xmm0,0xa0(%r14)
  765cb2:	movups %xmm0,0xe0(%r14)
  765cba:	movups %xmm0,0xb0(%r14)
  765cc2:	movups %xmm0,0xf0(%r14)
  765cca:	movups %xmm0,0xd0(%r14)
  765cd2:	movups %xmm0,0xc0(%r14)
  765cda:	movups %xmm0,0x90(%r14)
  765ce2:	movups %xmm0,0x80(%r14)
  765cea:	lea    0x100(%r14),%rdi
  765cf1:	mov    0x3531c8(%rip),%r15        # ab8ec0 <memcpy@GLIBC_2.14>
  765cf8:	mov    $0x100,%edx
  765cfd:	mov    %r14,%rsi
  765d00:	call   *%r15
  765d03:	lea    0x200(%r14),%rdi
  765d0a:	mov    $0x200,%edx
  765d0f:	mov    %r14,%rsi
  765d12:	call   *%r15
  765d15:	lea    0x400(%r14),%rdi
  765d1c:	mov    $0x400,%edx
  765d21:	mov    %r14,%rsi
  765d24:	call   *%r15
  765d27:	lea    0x800(%r14),%rdi
  765d2e:	mov    $0x800,%edx
  765d33:	mov    %r14,%rsi
  765d36:	call   *%r15
  765d39:	lea    0x1000(%r14),%rdi
  765d40:	mov    $0x1000,%edx
  765d45:	mov    %r14,%rsi
  765d48:	call   *%r15
  765d4b:	lea    0x2000(%r14),%rdi
  765d52:	mov    $0x2000,%edx
  765d57:	mov    %r14,%rsi
  765d5a:	call   *%r15
  765d5d:	mov    %r14,%rdi
  765d60:	add    $0x4000,%rdi
  765d67:	mov    $0x4000,%edx
  765d6c:	mov    %r14,%rsi
  765d6f:	call   *%r15
  765d72:	movq   $0x8000,(%rbx)
  765d79:	mov    %r14,0x8(%rbx)
  765d7d:	movq   $0x8000,0x10(%rbx)
  765d85:	jmp    765f40 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x750>
  765d8a:	lea    -0x6963e1(%rip),%rax        # cf9b0 <GCC_except_table0+0xd648>
  765d91:	mov    %rsi,%rdi
  765d94:	mov    %rax,%rsi
  765d97:	call   *0x3533cb(%rip)        # ab9168 <bcmp@GLIBC_2.2.5>
  765d9d:	test   %eax,%eax
  765d9f:	jne    765f4a <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x75a>
  765da5:	call   *0x3530fd(%rip)        # ab8ea8 <_DYNAMIC+0x248>
  765dab:	mov    $0x800,%edi
  765db0:	mov    $0x1,%esi
  765db5:	call   *0x3530f5(%rip)        # ab8eb0 <_DYNAMIC+0x250>
  765dbb:	test   %rax,%rax
  765dbe:	je     765fb9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x7c9>
  765dc4:	mov    %rax,%r14
  765dc7:	movabs $0x81cc81cc81cc81cc,%rax
  765dd1:	mov    %rax,(%r14)
  765dd4:	mov    %rax,0x8(%r14)
  765dd8:	movups (%r14),%xmm0
  765ddc:	movups %xmm0,0x10(%r14)
  765de1:	movups %xmm0,0x20(%r14)
  765de6:	movups %xmm0,0x30(%r14)
  765deb:	movups %xmm0,0x40(%r14)
  765df0:	movups %xmm0,0x50(%r14)
  765df5:	movups %xmm0,0x60(%r14)
  765dfa:	movups %xmm0,0x70(%r14)
  765dff:	movups %xmm0,0x80(%r14)
  765e07:	movups %xmm0,0xf0(%r14)
  765e0f:	movups %xmm0,0xe0(%r14)
  765e17:	movups %xmm0,0xd0(%r14)
  765e1f:	movups %xmm0,0xc0(%r14)
  765e27:	movups %xmm0,0xb0(%r14)
  765e2f:	movups %xmm0,0xa0(%r14)
  765e37:	movups %xmm0,0x90(%r14)
  765e3f:	lea    0x100(%r14),%rdi
  765e46:	mov    0x353073(%rip),%r15        # ab8ec0 <memcpy@GLIBC_2.14>
  765e4d:	mov    $0x100,%edx
  765e52:	mov    %r14,%rsi
  765e55:	call   *%r15
  765e58:	lea    0x200(%r14),%rdi
  765e5f:	mov    $0x200,%edx
  765e64:	mov    %r14,%rsi
  765e67:	call   *%r15
  765e6a:	mov    %r14,%rdi
  765e6d:	add    $0x400,%rdi
  765e74:	mov    $0x400,%edx
  765e79:	mov    %r14,%rsi
  765e7c:	call   *%r15
  765e7f:	movq   $0x800,0x8(%rsp)
  765e88:	mov    %r14,0x10(%rsp)
  765e8d:	movq   $0x800,0x18(%rsp)
  765e96:	lea    0x8(%rsp),%rax
  765e9b:	mov    %rax,0x30(%rsp)
  765ea0:	lea    0x32089(%rip),%rax        # 797f30 <_RNvXsq_NtCscdodAO9FK5_5alloc6stringNtB5_6StringNtNtCs4NRVxsYgnAr_4core3fmt7Display3fmt>
  765ea7:	mov    %rax,0x38(%rsp)
  765eac:	lea    -0x6a0d82(%rip),%rsi        # c5131 <GCC_except_table0+0x2dc9>
  765eb3:	lea    0x30(%rsp),%rdx
  765eb8:	mov    %rbx,%rdi
  765ebb:	call   *0x35330f(%rip)        # ab91d0 <_DYNAMIC+0x570>
  765ec1:	mov    0x8(%rsp),%rsi
  765ec6:	test   %rsi,%rsi
  765ec9:	je     765f40 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x750>
  765ecb:	mov    0x10(%rsp),%rdi
  765ed0:	mov    $0x1,%edx
  765ed5:	call   *0x352fc5(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  765edb:	jmp    765f40 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x750>
  765edd:	movq   $0x0,(%rbx)
  765ee4:	movq   $0x1,0x8(%rbx)
  765eec:	movq   $0x0,0x10(%rbx)
  765ef4:	jmp    765f40 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x750>
  765ef6:	call   *0x352fac(%rip)        # ab8ea8 <_DYNAMIC+0x248>
  765efc:	mov    $0x17,%edi
  765f01:	mov    $0x1,%esi
  765f06:	call   *0x352fa4(%rip)        # ab8eb0 <_DYNAMIC+0x250>
  765f0c:	test   %rax,%rax
  765f0f:	je     765fd9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x7e9>
  765f15:	movups -0x69635a(%rip),%xmm0        # cfbc2 <GCC_except_table0+0xd85a>
  765f1c:	movups %xmm0,(%rax)
  765f1f:	movabs $0x92d791d790d72081,%rcx
  765f29:	mov    %rcx,0xf(%rax)
  765f2d:	movq   $0x17,(%rbx)
  765f34:	mov    %rax,0x8(%rbx)
  765f38:	movq   $0x17,0x10(%rbx)
  765f40:	add    $0x40,%rsp
  765f44:	pop    %rbx
  765f45:	pop    %r14
  765f47:	pop    %r15
  765f49:	ret
  765f4a:	lea    0x20(%rsp),%rax
  765f4f:	mov    %rax,0x8(%rsp)
  765f54:	lea    0x300c5(%rip),%rax        # 796020 <_RNvXs1i_NtCs4NRVxsYgnAr_4core3fmtReNtB6_7Display3fmtCs9C2G9YFESsD_29canonical_text_public_control>
  765f5b:	mov    %rax,0x10(%rsp)
  765f60:	lea    -0x69eecb(%rip),%rdi        # c709c <GCC_except_table0+0x4d34>
  765f67:	lea    0x3339ca(%rip),%rdx        # a99938 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1200>
  765f6e:	lea    0x8(%rsp),%rsi
  765f73:	call   *0x352f5f(%rip)        # ab8ed8 <_DYNAMIC+0x278>
  765f79:	mov    $0x1,%edi
  765f7e:	mov    $0x1b80,%esi
  765f83:	call   *0x352fcf(%rip)        # ab8f58 <_DYNAMIC+0x2f8>
  765f89:	mov    $0x1,%edi
  765f8e:	mov    $0x1,%esi
  765f93:	call   *0x352fbf(%rip)        # ab8f58 <_DYNAMIC+0x2f8>
  765f99:	mov    $0x1,%edi
  765f9e:	mov    $0x580,%esi
  765fa3:	call   *0x352faf(%rip)        # ab8f58 <_DYNAMIC+0x2f8>
  765fa9:	mov    $0x1,%edi
  765fae:	mov    $0x8000,%esi
  765fb3:	call   *0x352f9f(%rip)        # ab8f58 <_DYNAMIC+0x2f8>
  765fb9:	mov    $0x1,%edi
  765fbe:	mov    $0x800,%esi
  765fc3:	call   *0x352f8f(%rip)        # ab8f58 <_DYNAMIC+0x2f8>
  765fc9:	mov    $0x1,%edi
  765fce:	mov    $0x880,%esi
  765fd3:	call   *0x352f7f(%rip)        # ab8f58 <_DYNAMIC+0x2f8>
  765fd9:	mov    $0x1,%edi
  765fde:	mov    $0x17,%esi
  765fe3:	call   *0x352f6f(%rip)        # ab8f58 <_DYNAMIC+0x2f8>
  765fe9:	mov    %rax,%rbx
  765fec:	mov    0x8(%rsp),%rsi
  765ff1:	test   %rsi,%rsi
  765ff4:	je     766006 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x816>
  765ff6:	mov    0x10(%rsp),%rdi
  765ffb:	mov    $0x1,%edx
  766000:	call   *0x352e9a(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  766006:	mov    %rbx,%rdi
  766009:	call   a97380 <_Unwind_Resume@plt>

canonical_text_public_control::owner_hit bytes=416 frame=264

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000766010 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit>:
  766010:	push   %rbp
  766011:	push   %r15
  766013:	push   %r14
  766015:	push   %r13
  766017:	push   %r12
  766019:	push   %rbx
  76601a:	sub    $0xd8,%rsp
  766021:	mov    (%rdi),%rsi
  766024:	test   %rsi,%rsi
  766027:	je     766153 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit+0x143>
  76602d:	cmpb   $0x0,0x76e(%rsi)
  766034:	jne    76615a <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit+0x14a>
  76603a:	movss  %xmm0,0x8(%rsp)
  766040:	movss  %xmm1,0xc(%rsp)
  766046:	cmpb   $0x1,0x76c(%rsi)
  76604d:	jne    766161 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit+0x151>
  766053:	lea    0x58(%rsp),%rdi
  766058:	call   73dc40 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime5queryNtB3_7Context3newNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEBX_>
  76605d:	mov    0x90(%rsp),%r13
  766065:	test   %r13,%r13
  766068:	je     766132 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit+0x122>
  76606e:	movabs $0x100000001b3,%rbp
  766078:	mov    0x88(%rsp),%rbx
  766080:	add    $0x3d,%rbx
  766084:	xor    %eax,%eax
  766086:	lea    0x58(%rsp),%r14
  76608b:	xor    %r12d,%r12d
  76608e:	jmp    7660d3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit+0xc3>
  766090:	xor    $0x1,%eax
  766093:	imul   %rbp,%rax
  766097:	and    $0x1,%dl
  76609a:	movzbl %dl,%r15d
  76609e:	xor    %rax,%r15
  7660a1:	imul   %rbp,%r15
  7660a5:	mov    %r14,%rdi
  7660a8:	mov    %r12,%rsi
  7660ab:	movss  0x8(%rsp),%xmm0
  7660b1:	movss  0xc(%rsp),%xmm1
  7660b7:	call   *0x35311b(%rip)        # ab91d8 <_DYNAMIC+0x578>
  7660bd:	movzbl %al,%eax
  7660c0:	xor    %r15,%rax
  7660c3:	imul   %rbp,%rax
  7660c7:	inc    %r12
  7660ca:	add    $0x40,%rbx
  7660ce:	cmp    %r12,%r13
  7660d1:	je     766134 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit+0x124>
  7660d3:	cmpb   $0x4,(%rbx)
  7660d6:	jne    7660c7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit+0xb7>
  7660d8:	lea    0x10(%rsp),%rdi
  7660dd:	mov    %r14,%rsi
  7660e0:	mov    %r12,%rdx
  7660e3:	call   *0x352fbf(%rip)        # ab90a8 <_DYNAMIC+0x448>
  7660e9:	cmpq   $0x0,0x10(%rsp)
  7660ef:	je     766146 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit+0x136>
  7660f1:	movups 0x10(%rsp),%xmm0
  7660f6:	movups 0x20(%rsp),%xmm1
  7660fb:	movaps %xmm1,0x40(%rsp)
  766100:	movaps %xmm0,0x30(%rsp)
  766105:	lea    0x30(%rsp),%rdi
  76610a:	movss  0x8(%rsp),%xmm0
  766110:	movss  0xc(%rsp),%xmm1
  766116:	call   *0x35302c(%rip)        # ab9148 <_DYNAMIC+0x4e8>
  76611c:	cmp    $0x2,%dl
  76611f:	jne    766090 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit+0x80>
  766125:	lea    0x332cc4(%rip),%rdi        # a98df0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x6b8>
  76612c:	call   *0x352e16(%rip)        # ab8f48 <_DYNAMIC+0x2e8>
  766132:	xor    %eax,%eax
  766134:	add    $0xd8,%rsp
  76613b:	pop    %rbx
  76613c:	pop    %r12
  76613e:	pop    %r13
  766140:	pop    %r14
  766142:	pop    %r15
  766144:	pop    %rbp
  766145:	ret
  766146:	lea    0x332c8b(%rip),%rdi        # a98dd8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x6a0>
  76614d:	call   *0x352df5(%rip)        # ab8f48 <_DYNAMIC+0x2e8>
  766153:	mov    $0xd,%eax
  766158:	jmp    766166 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit+0x156>
  76615a:	mov    $0xe,%eax
  76615f:	jmp    766166 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit+0x156>
  766161:	mov    $0x12,%eax
  766166:	mov    %rax,0x58(%rsp)
  76616b:	movq   $0x0,0x60(%rsp)
  766174:	lea    -0x696599(%rip),%rdi        # cfbe2 <GCC_except_table0+0xd87a>
  76617b:	lea    0x333816(%rip),%rcx        # a99998 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1260>
  766182:	lea    0x3337c7(%rip),%r8        # a99950 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1218>
  766189:	lea    0x58(%rsp),%rdx
  76618e:	mov    $0x2b,%esi
  766193:	call   *0x352dd7(%rip)        # ab8f70 <_DYNAMIC+0x310>
  766199:	ud2
  76619b:	mov    %rax,%rbx
  76619e:	lea    0x58(%rsp),%rdi
  7661a3:	call   74d540 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  7661a8:	mov    %rbx,%rdi
  7661ab:	call   a97380 <_Unwind_Resume@plt>

canonical_text_public_control::query_hit bytes=181 frame=88

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007661b0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9query_hit>:
  7661b0:	push   %r15
  7661b2:	push   %r14
  7661b4:	push   %rbx
  7661b5:	sub    $0x40,%rsp
  7661b9:	mov    %rdi,%r14
  7661bc:	movss  %xmm0,(%rsp)
  7661c1:	movss  %xmm1,0x4(%rsp)
  7661c7:	call   *0x353013(%rip)        # ab91e0 <_DYNAMIC+0x580>
  7661cd:	cmp    $0x2,%dl
  7661d0:	je     766258 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9query_hit+0xa8>
  7661d6:	movabs $0x100000001b3,%r15
  7661e0:	xor    $0x1,%eax
  7661e3:	imul   %r15,%rax
  7661e7:	and    $0x1,%dl
  7661ea:	movzbl %dl,%ebx
  7661ed:	xor    %rax,%rbx
  7661f0:	imul   %r15,%rbx
  7661f4:	lea    0x8(%rsp),%rdi
  7661f9:	mov    %r14,%rsi
  7661fc:	movss  (%rsp),%xmm0
  766201:	movss  0x4(%rsp),%xmm1
  766207:	call   *0x352fdb(%rip)        # ab91e8 <_DYNAMIC+0x588>
  76620d:	cmpb   $0x2,0xc(%rsp)
  766212:	je     76624b <_RNvCs9C2G9YFESsD_29canonical_text_public_control9query_hit+0x9b>
  766214:	mov    0x8(%rsp),%eax
  766218:	mov    0x18(%rsp),%ecx
  76621c:	mov    0x1c(%rsp),%edx
  766220:	mov    0x20(%rsp),%esi
  766224:	mov    0x24(%rsp),%edi
  766228:	xor    %rax,%rbx
  76622b:	imul   %r15,%rbx
  76622f:	xor    %rcx,%rbx
  766232:	imul   %r15,%rbx
  766236:	xor    %rdx,%rbx
  766239:	imul   %r15,%rbx
  76623d:	xor    %rsi,%rbx
  766240:	imul   %r15,%rbx
  766244:	xor    %rdi,%rbx
  766247:	imul   %r15,%rbx
  76624b:	mov    %rbx,%rax
  76624e:	add    $0x40,%rsp
  766252:	pop    %rbx
  766253:	pop    %r14
  766255:	pop    %r15
  766257:	ret
  766258:	lea    0x333709(%rip),%rdi        # a99968 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1230>
  76625f:	call   *0x352ce3(%rip)        # ab8f48 <_DYNAMIC+0x2e8>

<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::interaction_layout bytes=1226 frame=248

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000076b170 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_>:
  76b170:	push   %rbp
  76b171:	push   %r15
  76b173:	push   %r14
  76b175:	push   %r13
  76b177:	push   %r12
  76b179:	push   %rbx
  76b17a:	sub    $0xc8,%rsp
  76b181:	mov    %rdx,%r14
  76b184:	mov    %rsi,%r15
  76b187:	mov    0x2e0(%rsi),%rsi
  76b18e:	cmp    %rsi,%rdx
  76b191:	jae    76b5ab <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x43b>
  76b197:	mov    0x2d8(%r15),%rax
  76b19e:	lea    (%r14,%r14,4),%rcx
  76b1a2:	mov    0x20(%rax,%rcx,8),%r13d
  76b1a7:	mov    %r13d,%eax
  76b1aa:	and    $0xf,%eax
  76b1ad:	cmp    $0x9,%eax
  76b1b0:	ja     76b592 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x422>
  76b1b6:	mov    %rdi,%rbx
  76b1b9:	cmp    $0x6,%eax
  76b1bc:	je     76b52f <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x3bf>
  76b1c2:	shr    $0x4,%r13d
  76b1c6:	lea    0x2f0(%r15),%rax
  76b1cd:	mov    %rax,0x10(%rsp)
  76b1d2:	lea    0x2f8(%r15),%rbp
  76b1d9:	sub    $0x1,%r13d
  76b1dd:	jae    76b308 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x198>
  76b1e3:	mov    $0xffffffff,%r13d
  76b1e9:	mov    $0x1,%r12b
  76b1ec:	mov    0x5a8(%r15),%rsi
  76b1f3:	cmp    %rsi,%r14
  76b1f6:	jae    76b368 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x1f8>
  76b1fc:	mov    0x5a0(%r15),%rax
  76b203:	lea    0x300(%r15),%rsi
  76b20a:	mov    %r14,%rcx
  76b20d:	shl    $0x4,%rcx
  76b211:	movups (%rax,%rcx,1),%xmm0
  76b215:	movaps %xmm0,0x90(%rsp)
  76b21d:	lea    0x30(%rsp),%rdi
  76b222:	lea    0x90(%rsp),%rdx
  76b22a:	call   *0x34de10(%rip)        # ab9040 <_DYNAMIC+0x3e0>
  76b230:	cmpb   $0x0,0x30(%rsp)
  76b235:	je     76b24b <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0xdb>
  76b237:	movzbl 0x31(%rsp),%eax
  76b23c:	movq   $0x22,(%rbx)
  76b243:	mov    %al,0x8(%rbx)
  76b246:	jmp    76b51d <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x3ad>
  76b24b:	mov    0x6e8(%r15),%rax
  76b252:	test   %rax,%rax
  76b255:	je     76b547 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x3d7>
  76b25b:	mov    0x30(%rax),%rax
  76b25f:	test   %rax,%rax
  76b262:	je     76b547 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x3d7>
  76b268:	movss  0x7c(%rsp),%xmm1
  76b26e:	subss  0x54(%rsp),%xmm1
  76b274:	subss  0x58(%rsp),%xmm1
  76b27a:	subss  0x44(%rsp),%xmm1
  76b280:	subss  0x48(%rsp),%xmm1
  76b286:	subss  0x84(%rsp),%xmm1
  76b28f:	lock incq (%rax)
  76b293:	jle    76b602 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x492>
  76b299:	mov    %rax,0x8(%rsp)
  76b29e:	test   %r12b,%r12b
  76b2a1:	jne    76b56d <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x3fd>
  76b2a7:	mov    0x0(%rbp),%rsi
  76b2ab:	mov    %r13d,%r12d
  76b2ae:	cmp    %r12,%rsi
  76b2b1:	jbe    76b5cb <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x45b>
  76b2b7:	mov    0x10(%rsp),%rax
  76b2bc:	mov    (%rax),%rsi
  76b2bf:	lea    (%r12,%r12,4),%r13
  76b2c3:	shl    $0x4,%r13
  76b2c7:	cmpq   $0xfffffffffffffffe,(%rsi,%r13,1)
  76b2cc:	je     76b576 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x406>
  76b2d2:	lea    0x8(%rsp),%rax
  76b2d7:	mov    %rax,0x20(%rsp)
  76b2dc:	movq   $0x0,0x28(%rsp)
  76b2e5:	mov    0x200(%r15),%rax
  76b2ec:	lea    -0x6a72db(%rip),%rcx        # c4018 <GCC_except_table0+0x1cb0>
  76b2f3:	movslq (%rcx,%rax,4),%rax
  76b2f7:	add    %rcx,%rax
  76b2fa:	jmp    *%rax
  76b2fc:	lea    -0x6a6f27(%rip),%rax        # c43dc <GCC_except_table0+0x2074>
  76b303:	jmp    76b3f8 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x288>
  76b308:	mov    0x2f8(%r15),%rsi
  76b30f:	mov    %r13d,%r12d
  76b312:	cmp    %r12,%rsi
  76b315:	jbe    76b5bb <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x44b>
  76b31b:	mov    0x2f0(%r15),%rax
  76b322:	lea    (%r12,%r12,4),%rcx
  76b326:	shl    $0x4,%rcx
  76b32a:	mov    (%rax,%rcx,1),%rdx
  76b32e:	cmp    $0xffffffffffffffff,%rdx
  76b332:	je     76b355 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x1e5>
  76b334:	cmp    $0xfffffffffffffffe,%rdx
  76b338:	je     76b560 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x3f0>
  76b33e:	add    %rcx,%rax
  76b341:	mov    0x20(%rax),%rax
  76b345:	test   %rax,%rax
  76b348:	je     76b355 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x1e5>
  76b34a:	cmpq   $0x0,0x50(%rax)
  76b34f:	jne    76b489 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x319>
  76b355:	xor    %r12d,%r12d
  76b358:	mov    0x5a8(%r15),%rsi
  76b35f:	cmp    %rsi,%r14
  76b362:	jb     76b1fc <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x8c>
  76b368:	lea    0x32e971(%rip),%rdx        # a99ce0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x15a8>
  76b36f:	mov    %r14,%rdi
  76b372:	call   *0x34db58(%rip)        # ab8ed0 <_DYNAMIC+0x270>
  76b378:	mov    0x220(%r15),%rax
  76b37f:	cmp    %rax,%r14
  76b382:	jae    76b5dd <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x46d>
  76b388:	mov    0x210(%r15),%rax
  76b38f:	mov    0x218(%r15),%rcx
  76b396:	movzbl (%rcx,%r14,1),%r14d
  76b39b:	cmp    %r14,%rax
  76b39e:	jbe    76b5ef <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x47f>
  76b3a4:	imul   $0x58,%r14,%rax
  76b3a8:	add    0x208(%r15),%rax
  76b3af:	jmp    76b3f8 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x288>
  76b3b1:	mov    0x208(%r15),%rax
  76b3b8:	lea    0x30(%rsp),%rdi
  76b3bd:	mov    %rsi,%r15
  76b3c0:	mov    %rax,%rsi
  76b3c3:	mov    %r14,%rdx
  76b3c6:	movss  %xmm1,0x1c(%rsp)
  76b3cc:	call   *0x34dc7e(%rip)        # ab9050 <_DYNAMIC+0x3f0>
  76b3d2:	movss  0x1c(%rsp),%xmm1
  76b3d8:	mov    %r15,%rsi
  76b3db:	jmp    76b430 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x2c0>
  76b3dd:	mov    0x218(%r15),%rax
  76b3e4:	cmp    %rax,%r14
  76b3e7:	jae    76b5e6 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x476>
  76b3ed:	imul   $0x58,%r14,%rax
  76b3f1:	add    0x210(%r15),%rax
  76b3f8:	mov    0x50(%rax),%rcx
  76b3fc:	mov    %rcx,0x80(%rsp)
  76b404:	movups 0x40(%rax),%xmm0
  76b408:	movaps %xmm0,0x70(%rsp)
  76b40d:	movups (%rax),%xmm0
  76b410:	movups 0x10(%rax),%xmm4
  76b414:	movups 0x20(%rax),%xmm2
  76b418:	movups 0x30(%rax),%xmm3
  76b41c:	movaps %xmm3,0x60(%rsp)
  76b421:	movaps %xmm2,0x50(%rsp)
  76b426:	movaps %xmm4,0x40(%rsp)
  76b42b:	movaps %xmm0,0x30(%rsp)
  76b430:	add    %r13,%rsi
  76b433:	movss  0x48(%rsp),%xmm0
  76b439:	lea    0x90(%rsp),%rdi
  76b441:	lea    0x20(%rsp),%rdx
  76b446:	mov    $0x1,%ecx
  76b44b:	mov    $0x1,%r8d
  76b451:	call   *0x34dc89(%rip)        # ab90e0 <_DYNAMIC+0x480>
  76b457:	mov    0x90(%rsp),%rax
  76b45f:	cmp    $0xfffffffffffffffe,%rax
  76b463:	jne    76b4ca <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x35a>
  76b465:	mov    0x28(%rsp),%rdi
  76b46a:	call   74cab0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text10TextShaperECs9C2G9YFESsD_29canonical_text_public_control>
  76b46f:	mov    0x8(%rsp),%rax
  76b474:	lock decq (%rax)
  76b478:	jne    76b485 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x315>
  76b47a:	lea    0x8(%rsp),%rdi
  76b47f:	call   *0x34db0b(%rip)        # ab8f90 <_DYNAMIC+0x330>
  76b485:	mov    0x0(%rbp),%rsi
  76b489:	cmp    %r12,%rsi
  76b48c:	jbe    76b5bb <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x44b>
  76b492:	mov    0x10(%rsp),%rax
  76b497:	mov    (%rax),%rax
  76b49a:	lea    (%r12,%r12,4),%rcx
  76b49e:	shl    $0x4,%rcx
  76b4a2:	mov    (%rax,%rcx,1),%rdx
  76b4a6:	cmp    $0xfffffffffffffffe,%rdx
  76b4aa:	je     76b560 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x3f0>
  76b4b0:	cmp    $0xffffffffffffffff,%rdx
  76b4b4:	je     76b585 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x415>
  76b4ba:	add    %rcx,%rax
  76b4bd:	mov    %rax,0x8(%rbx)
  76b4c1:	movq   $0xfffffffffffffffe,(%rbx)
  76b4c8:	jmp    76b51d <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x3ad>
  76b4ca:	mov    0x98(%rsp),%rcx
  76b4d2:	mov    0xc0(%rsp),%rdx
  76b4da:	mov    %rdx,0x30(%rbx)
  76b4de:	movups 0xb0(%rsp),%xmm0
  76b4e6:	movups %xmm0,0x20(%rbx)
  76b4ea:	movups 0xa0(%rsp),%xmm0
  76b4f2:	movups %xmm0,0x10(%rbx)
  76b4f6:	mov    %rax,(%rbx)
  76b4f9:	mov    %rcx,0x8(%rbx)
  76b4fd:	mov    0x28(%rsp),%rdi
  76b502:	call   74cab0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text10TextShaperECs9C2G9YFESsD_29canonical_text_public_control>
  76b507:	mov    0x8(%rsp),%rax
  76b50c:	lock decq (%rax)
  76b510:	jne    76b51d <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x3ad>
  76b512:	lea    0x8(%rsp),%rdi
  76b517:	call   *0x34da73(%rip)        # ab8f90 <_DYNAMIC+0x330>
  76b51d:	add    $0xc8,%rsp
  76b524:	pop    %rbx
  76b525:	pop    %r12
  76b527:	pop    %r13
  76b529:	pop    %r14
  76b52b:	pop    %r15
  76b52d:	pop    %rbp
  76b52e:	ret
  76b52f:	lea    0x2f0(%r15),%rax
  76b536:	mov    %rax,0x10(%rsp)
  76b53b:	lea    0x2f8(%r15),%rbp
  76b542:	jmp    76b1e3 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x73>
  76b547:	lea    -0x698f32(%rip),%rdi        # d261c <GCC_except_table0+0x102b4>
  76b54e:	lea    0x32e7a3(%rip),%rdx        # a99cf8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x15c0>
  76b555:	mov    $0x2c,%esi
  76b55a:	call   *0x34da18(%rip)        # ab8f78 <_DYNAMIC+0x318>
  76b560:	lea    0x32da21(%rip),%rdi        # a98f88 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x850>
  76b567:	call   *0x34d9db(%rip)        # ab8f48 <_DYNAMIC+0x2e8>
  76b56d:	lea    0x32e79c(%rip),%rdi        # a99d10 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x15d8>
  76b574:	jmp    76b57d <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x40d>
  76b576:	lea    0x32da3b(%rip),%rdi        # a98fb8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x880>
  76b57d:	call   *0x34d9c5(%rip)        # ab8f48 <_DYNAMIC+0x2e8>
  76b583:	jmp    76b602 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x492>
  76b585:	lea    0x32e79c(%rip),%rdi        # a99d28 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x15f0>
  76b58c:	call   *0x34d9b6(%rip)        # ab8f48 <_DYNAMIC+0x2e8>
  76b592:	lea    -0x698cd1(%rip),%rdi        # d28c8 <GCC_except_table0+0x10560>
  76b599:	lea    0x32ec70(%rip),%rdx        # a9a210 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1ad8>
  76b5a0:	mov    $0x83,%esi
  76b5a5:	call   *0x34d92d(%rip)        # ab8ed8 <_DYNAMIC+0x278>
  76b5ab:	lea    0x32e716(%rip),%rdx        # a99cc8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1590>
  76b5b2:	mov    %r14,%rdi
  76b5b5:	call   *0x34d915(%rip)        # ab8ed0 <_DYNAMIC+0x270>
  76b5bb:	lea    0x32d9ae(%rip),%rdx        # a98f70 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x838>
  76b5c2:	mov    %r12,%rdi
  76b5c5:	call   *0x34d905(%rip)        # ab8ed0 <_DYNAMIC+0x270>
  76b5cb:	lea    0x32d9ce(%rip),%rdx        # a98fa0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x868>
  76b5d2:	mov    %r12,%rdi
  76b5d5:	call   *0x34d8f5(%rip)        # ab8ed0 <_DYNAMIC+0x270>
  76b5db:	jmp    76b602 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x492>
  76b5dd:	lea    0x32e574(%rip),%rdx        # a99b58 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1420>
  76b5e4:	jmp    76b5f6 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x486>
  76b5e6:	lea    0x32e553(%rip),%rdx        # a99b40 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1408>
  76b5ed:	jmp    76b5f6 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x486>
  76b5ef:	lea    0x32e57a(%rip),%rdx        # a99b70 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1438>
  76b5f6:	mov    %r14,%rdi
  76b5f9:	mov    %rax,%rsi
  76b5fc:	call   *0x34d8ce(%rip)        # ab8ed0 <_DYNAMIC+0x270>
  76b602:	ud2
  76b604:	mov    %rax,%rbx
  76b607:	mov    0x28(%rsp),%rdi
  76b60c:	call   74cab0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text10TextShaperECs9C2G9YFESsD_29canonical_text_public_control>
  76b611:	jmp    76b616 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x4a6>
  76b613:	mov    %rax,%rbx
  76b616:	mov    0x8(%rsp),%rax
  76b61b:	lock decq (%rax)
  76b61f:	jne    76b62c <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x4bc>
  76b621:	lea    0x8(%rsp),%rdi
  76b626:	call   *0x34d964(%rip)        # ab8f90 <_DYNAMIC+0x330>
  76b62c:	mov    %rbx,%rdi
  76b62f:	call   a97380 <_Unwind_Resume@plt>
  76b634:	call   *0x34d88e(%rip)        # ab8ec8 <_DYNAMIC+0x268>

<gpui::runtime::Win<canonical_text_public_control::Editor>>::pointer_event bytes=3204 frame=296

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000076cd00 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_>:
  76cd00:	push   %rbp
  76cd01:	push   %r15
  76cd03:	push   %r14
  76cd05:	push   %r13
  76cd07:	push   %r12
  76cd09:	push   %rbx
  76cd0a:	sub    $0xf8,%rsp
  76cd11:	mov    %rdx,%r14
  76cd14:	mov    %rdi,%rbx
  76cd17:	mov    (%rcx),%ebp
  76cd19:	test   %ebp,%ebp
  76cd1b:	je     76cd50 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x50>
  76cd1d:	mov    0x8(%r14),%r12
  76cd21:	mov    0x10(%r14),%r13
  76cd25:	mov    0x18(%r14),%rax
  76cd29:	movq   $0x0,0x8(%r14)
  76cd31:	lea    -0x1(%rbp),%edx
  76cd34:	lea    -0x6a8d13(%rip),%rdi        # c4028 <GCC_except_table0+0x1cc0>
  76cd3b:	movslq (%rdi,%rdx,4),%rdx
  76cd3f:	add    %rdi,%rdx
  76cd42:	jmp    *%rdx
  76cd44:	movl   $0xffffffff,(%r14)
  76cd4b:	jmp    76cf11 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x211>
  76cd50:	movd   0x4(%rcx),%xmm1
  76cd55:	movd   0x8(%rcx),%xmm0
  76cd5a:	movd   %xmm1,%eax
  76cd5e:	movd   %xmm0,%ecx
  76cd62:	mov    %eax,%edx
  76cd64:	and    $0x7fffffff,%edx
  76cd6a:	cmp    $0x7f800000,%edx
  76cd70:	setge  %dl
  76cd73:	and    $0x7fffffff,%ecx
  76cd79:	cmp    $0x7f800000,%ecx
  76cd7f:	setge  %cl
  76cd82:	or     %dl,%cl
  76cd84:	je     76cd9d <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x9d>
  76cd86:	movl   $0xffffffff,(%r14)
  76cd8d:	movq   $0x0,0x8(%r14)
  76cd95:	xor    %r12d,%r12d
  76cd98:	jmp    76cf11 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x211>
  76cd9d:	inc    %eax
  76cd9f:	je     76d909 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xc09>
  76cda5:	mov    %eax,(%r14)
  76cda8:	movd   %xmm0,0x4(%r14)
  76cdae:	xor    %r12d,%r12d
  76cdb1:	jmp    76cf11 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x211>
  76cdb6:	mov    (%r14),%r15d
  76cdb9:	cmp    $0xffffffff,%r15d
  76cdbd:	je     76cf11 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x211>
  76cdc3:	mov    %rsi,%r13
  76cdc6:	movups 0x8(%rcx),%xmm0
  76cdca:	movss  0x4(%r14),%xmm1
  76cdd0:	movss  %xmm1,0x58(%rsp)
  76cdd6:	movaps %xmm0,%xmm1
  76cdd9:	unpckhpd %xmm0,%xmm1
  76cddd:	lea    0x10(%rsp),%rdi
  76cde2:	movaps %xmm0,0x60(%rsp)
  76cde7:	call   *0x34c4f3(%rip)        # ab92e0 <_DYNAMIC+0x680>
  76cded:	cmpl   $0xfffffffe,0x10(%rsp)
  76cdf2:	jne    76d16e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x46e>
  76cdf8:	mov    0x0(%r13),%r14
  76cdfc:	test   %r14,%r14
  76cdff:	je     76cf43 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x243>
  76ce05:	cmpb   $0x1,0x76e(%r14)
  76ce0d:	je     76cf37 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x237>
  76ce13:	cmpb   $0x1,0x76a(%r14)
  76ce1b:	jne    76d2fe <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76ce21:	cmpb   $0x0,0x76b(%r14)
  76ce29:	jne    76d2fe <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76ce2f:	cmpb   $0x0,0x76c(%r14)
  76ce37:	je     76d2fe <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76ce3d:	cmpq   $0xffffffffffffffff,0x5c8(%r14)
  76ce45:	jne    76d2fe <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76ce4b:	mov    0x6a0(%r14),%rax
  76ce52:	cmp    0x6a8(%r14),%rax
  76ce59:	jne    76d2fe <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76ce5f:	mov    0x6c0(%r14),%rax
  76ce66:	cmp    %rax,0x6c8(%r14)
  76ce6d:	jne    76d2fe <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76ce73:	movss  0x760(%r14),%xmm0
  76ce7c:	ucomiss 0x764(%r14),%xmm0
  76ce84:	jne    76d2fe <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76ce8a:	jp     76d2fe <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76ce90:	mov    %eax,%ecx
  76ce92:	cvtsi2ss %rcx,%xmm2
  76ce97:	dec    %r15d
  76ce9a:	shr    $0x20,%rax
  76ce9e:	mov    %eax,%eax
  76cea0:	xorps  %xmm1,%xmm1
  76cea3:	cvtsi2ss %rax,%xmm1
  76cea8:	movd   %r15d,%xmm0
  76cead:	movq   $0x0,0x10(%rsp)
  76ceb6:	movss  %xmm2,0x18(%rsp)
  76cebc:	movss  %xmm1,0x1c(%rsp)
  76cec2:	lea    0x10(%rsp),%rdi
  76cec7:	movd   %xmm0,0x54(%rsp)
  76cecd:	movss  0x58(%rsp),%xmm1
  76ced3:	call   *0x34c40f(%rip)        # ab92e8 <_DYNAMIC+0x688>
  76ced9:	test   %al,%al
  76cedb:	je     76d8fd <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xbfd>
  76cee1:	mov    0x650(%r14),%rax
  76cee8:	test   %rax,%rax
  76ceeb:	je     76d733 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xa33>
  76cef1:	mov    0x100(%rax),%rsi
  76cef8:	test   %rsi,%rsi
  76cefb:	je     76d733 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xa33>
  76cf01:	lea    0x70(%rsp),%rdi
  76cf06:	call   *0x34bffc(%rip)        # ab8f08 <_DYNAMIC+0x2a8>
  76cf0c:	jmp    76d746 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xa46>
  76cf11:	mov    (%rsi),%r15
  76cf14:	test   %r15,%r15
  76cf17:	je     76cf43 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x243>
  76cf19:	add    $0x8,%rsi
  76cf1d:	mov    %r15,0xb0(%rsp)
  76cf25:	mov    %rsi,0xb8(%rsp)
  76cf2d:	cmpb   $0x1,0x76e(%r15)
  76cf35:	jne    76cf57 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x257>
  76cf37:	movq   $0xe,(%rbx)
  76cf3e:	jmp    76d305 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76cf43:	movq   $0xd,(%rbx)
  76cf4a:	movq   $0x0,0x8(%rbx)
  76cf52:	jmp    76d305 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76cf57:	movq   $0x0,0x758(%r15)
  76cf62:	cmp    $0x3,%ebp
  76cf65:	je     76d138 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x438>
  76cf6b:	cmp    $0x2,%ebp
  76cf6e:	je     76d084 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x384>
  76cf74:	test   %ebp,%ebp
  76cf76:	jne    76d1b1 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4b1>
  76cf7c:	mov    0x650(%r15),%rax
  76cf83:	test   %rax,%rax
  76cf86:	je     76cf9e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x29e>
  76cf88:	mov    0xd8(%rax),%rax
  76cf8f:	test   %rax,%rax
  76cf92:	je     76cf9e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x29e>
  76cf94:	cmpb   $0x0,0x12(%rax)
  76cf98:	jne    76d1b1 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4b1>
  76cf9e:	mov    0x8(%r14),%r12
  76cfa2:	test   %r12,%r12
  76cfa5:	je     76d1b1 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4b1>
  76cfab:	cmp    0x5f0(%r15),%r12
  76cfb2:	jne    76d196 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x496>
  76cfb8:	mov    0x10(%r14),%r13
  76cfbc:	lea    0x70(%rsp),%rdi
  76cfc1:	mov    %r15,%rsi
  76cfc4:	mov    %r13,%rdx
  76cfc7:	call   78c570 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE16resolve_identityBO_>
  76cfcc:	cmpq   $0xfffffffffffffffe,0x70(%rsp)
  76cfd2:	jne    76d19f <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x49f>
  76cfd8:	mov    0x78(%rsp),%rdi
  76cfdd:	mov    0x2e0(%r15),%rsi
  76cfe4:	cmp    %rsi,%rdi
  76cfe7:	jae    76d922 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xc22>
  76cfed:	mov    0x2d8(%r15),%rax
  76cff4:	lea    (%rdi,%rdi,4),%rcx
  76cff8:	mov    0x20(%rax,%rcx,8),%edi
  76cffc:	call   775950 <_RNvMsh_NtCslbxve4rcJus_4gpui7runtimeNtB5_4Node4kind>
  76d001:	cmp    $0x4,%al
  76d003:	jne    76d317 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x617>
  76d009:	mov    (%r14),%eax
  76d00c:	cmp    $0xffffffff,%eax
  76d00f:	je     76d931 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xc31>
  76d015:	movd   0x4(%r14),%xmm1
  76d01b:	dec    %eax
  76d01d:	movd   %eax,%xmm0
  76d021:	lea    0x10(%rsp),%rdi
  76d026:	mov    %r15,%rsi
  76d029:	mov    %r12,%rdx
  76d02c:	mov    %r13,%rcx
  76d02f:	mov    $0x1,%r8d
  76d035:	call   76fb80 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE14select_pointerB12_>
  76d03a:	mov    0x10(%rsp),%rax
  76d03f:	cmp    $0xfffffffffffffffe,%rax
  76d043:	je     76d052 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x352>
  76d045:	cmp    $0x11,%eax
  76d048:	jne    76d052 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x352>
  76d04a:	movq   $0x0,0x8(%r14)
  76d052:	mov    0x40(%rsp),%rax
  76d057:	mov    %rax,0x30(%rbx)
  76d05b:	movups 0x10(%rsp),%xmm0
  76d060:	movups 0x20(%rsp),%xmm1
  76d065:	movups 0x30(%rsp),%xmm2
  76d06a:	movups %xmm2,0x20(%rbx)
  76d06e:	movups %xmm1,0x10(%rbx)
  76d072:	movups %xmm0,(%rbx)
  76d075:	lea    0x70(%rsp),%rdi
  76d07a:	call   7461b0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultNtNtCslbxve4rcJus_4gpui7runtime6CommitNtBZ_5ErrorEECs9C2G9YFESsD_29canonical_text_public_control>
  76d07f:	jmp    76d305 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76d084:	test   %r12,%r12
  76d087:	sete   %cl
  76d08a:	cmpb   $0x1,0x76a(%r15)
  76d092:	jne    76d2fe <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d098:	cmpb   $0x0,0x76b(%r15)
  76d0a0:	jne    76d2fe <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d0a6:	cmpb   $0x0,0x76c(%r15)
  76d0ae:	je     76d2fe <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d0b4:	cmpq   $0xffffffffffffffff,0x5c8(%r15)
  76d0bc:	jne    76d2fe <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d0c2:	mov    0x6a0(%r15),%rax
  76d0c9:	cmp    0x6a8(%r15),%rax
  76d0d0:	jne    76d2fe <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d0d6:	mov    0x6c8(%r15),%rax
  76d0dd:	cmp    0x6c0(%r15),%rax
  76d0e4:	jne    76d2fe <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d0ea:	movss  0x760(%r15),%xmm0
  76d0f3:	ucomiss 0x764(%r15),%xmm0
  76d0fb:	jne    76d2fe <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d101:	jp     76d2fe <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d107:	mov    (%r14),%eax
  76d10a:	cmp    $0xffffffff,%eax
  76d10d:	mov    %rax,0x58(%rsp)
  76d112:	mov    %ecx,0x54(%rsp)
  76d116:	je     76d326 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x626>
  76d11c:	movss  0x4(%r14),%xmm0
  76d122:	dec    %eax
  76d124:	mov    %eax,0x14(%rsp)
  76d128:	movss  %xmm0,0x18(%rsp)
  76d12e:	mov    $0x1,%eax
  76d133:	jmp    76d328 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x628>
  76d138:	test   %r12,%r12
  76d13b:	je     76d1b1 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4b1>
  76d13d:	mov    (%r14),%ecx
  76d140:	cmp    $0xffffffff,%ecx
  76d143:	mov    %rcx,0x58(%rsp)
  76d148:	je     76d20f <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x50f>
  76d14e:	movss  0x4(%r14),%xmm1
  76d154:	dec    %ecx
  76d156:	mov    %ecx,0x74(%rsp)
  76d15a:	movss  %xmm1,0x78(%rsp)
  76d160:	movd   %ecx,%xmm0
  76d164:	mov    $0x1,%ecx
  76d169:	jmp    76d211 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x511>
  76d16e:	mov    0x40(%rsp),%rax
  76d173:	mov    %rax,0x30(%rbx)
  76d177:	movups 0x10(%rsp),%xmm0
  76d17c:	movups 0x20(%rsp),%xmm1
  76d181:	movups 0x30(%rsp),%xmm2
  76d186:	movups %xmm2,0x20(%rbx)
  76d18a:	movups %xmm1,0x10(%rbx)
  76d18e:	movups %xmm0,(%rbx)
  76d191:	jmp    76d305 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76d196:	movq   $0x11,0x70(%rsp)
  76d19f:	lea    0x70(%rsp),%rdi
  76d1a4:	call   7461b0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultNtNtCslbxve4rcJus_4gpui7runtime6CommitNtBZ_5ErrorEECs9C2G9YFESsD_29canonical_text_public_control>
  76d1a9:	movq   $0x0,0x8(%r14)
  76d1b1:	movups 0x6a0(%r15),%xmm0
  76d1b9:	movzbl 0x76c(%r15),%eax
  76d1c1:	cmpq   $0x0,0x6d0(%r15)
  76d1c9:	je     76d1d9 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4d9>
  76d1cb:	test   %al,%al
  76d1cd:	je     76d1dd <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4dd>
  76d1cf:	cmpq   $0xffffffffffffffff,0x5c8(%r15)
  76d1d7:	jne    76d1dd <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4dd>
  76d1d9:	xor    %ecx,%ecx
  76d1db:	jmp    76d1e9 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4e9>
  76d1dd:	mov    0x6e0(%r15),%rdx
  76d1e4:	mov    $0x1,%ecx
  76d1e9:	mov    0x758(%r15),%rsi
  76d1f0:	mov    %rcx,0x8(%rbx)
  76d1f4:	mov    %rdx,0x10(%rbx)
  76d1f8:	movups %xmm0,0x18(%rbx)
  76d1fc:	mov    %rsi,0x28(%rbx)
  76d200:	mov    %al,0x30(%rbx)
  76d203:	movq   $0xfffffffffffffffe,(%rbx)
  76d20a:	jmp    76d305 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76d20f:	xor    %ecx,%ecx
  76d211:	mov    %ecx,0x70(%rsp)
  76d215:	movzbl 0x76b(%r15),%edx
  76d21d:	xor    $0x1,%dl
  76d220:	and    0x76a(%r15),%dl
  76d227:	and    0x76c(%r15),%dl
  76d22e:	mov    0x5c8(%r15),%rsi
  76d235:	cmp    $0xffffffffffffffff,%rsi
  76d239:	sete   %dil
  76d23d:	and    %dl,%dil
  76d240:	cmp    $0x1,%dil
  76d244:	jne    76d2c2 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5c2>
  76d246:	mov    0x6a0(%r15),%rax
  76d24d:	cmp    0x6a8(%r15),%rax
  76d254:	jne    76d2fe <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d25a:	mov    0x6c8(%r15),%rax
  76d261:	cmp    0x6c0(%r15),%rax
  76d268:	jne    76d2fe <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d26e:	movss  0x760(%r15),%xmm2
  76d277:	ucomiss 0x764(%r15),%xmm2
  76d27f:	jne    76d2fe <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d281:	jp     76d2fe <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d283:	test   %ecx,%ecx
  76d285:	je     76d430 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x730>
  76d28b:	mov    0x650(%r15),%rax
  76d292:	test   %rax,%rax
  76d295:	je     76d408 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x708>
  76d29b:	mov    0xd8(%rax),%rax
  76d2a2:	test   %rax,%rax
  76d2a5:	je     76d408 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x708>
  76d2ab:	cmpb   $0x0,0x12(%rax)
  76d2af:	je     76d408 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x708>
  76d2b5:	mov    %r15,%rdi
  76d2b8:	call   770450 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime9inspectorINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE14inspector_pickB10_>
  76d2bd:	jmp    76d424 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x724>
  76d2c2:	cmp    $0xffffffffffffffff,%rsi
  76d2c6:	sete   %cl
  76d2c9:	movq   $0x12,0x10(%rsp)
  76d2d2:	xor    $0x1,%dl
  76d2d5:	or     %cl,%dl
  76d2d7:	jne    76d2fe <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d2d9:	mov    0x6c8(%r15),%rcx
  76d2e0:	cmp    0x6c0(%r15),%rcx
  76d2e7:	jne    76d2fe <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d2e9:	movss  0x760(%r15),%xmm0
  76d2f2:	ucomiss 0x764(%r15),%xmm0
  76d2fa:	jne    76d2fe <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d2fc:	jnp    76d34c <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x64c>
  76d2fe:	movq   $0x12,(%rbx)
  76d305:	add    $0xf8,%rsp
  76d30c:	pop    %rbx
  76d30d:	pop    %r12
  76d30f:	pop    %r13
  76d311:	pop    %r14
  76d313:	pop    %r15
  76d315:	pop    %rbp
  76d316:	ret
  76d317:	lea    0x70(%rsp),%rdi
  76d31c:	call   7461b0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultNtNtCslbxve4rcJus_4gpui7runtime6CommitNtBZ_5ErrorEECs9C2G9YFESsD_29canonical_text_public_control>
  76d321:	jmp    76d1b1 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4b1>
  76d326:	xor    %eax,%eax
  76d328:	mov    %eax,0x10(%rsp)
  76d32c:	lea    0x10(%rsp),%rsi
  76d331:	mov    %r15,%rdi
  76d334:	call   76e810 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11pointer_hitBW_>
  76d339:	mov    %rax,0x60(%rsp)
  76d33e:	mov    %rdx,0x8(%rsp)
  76d343:	mov    0x54(%rsp),%ecx
  76d347:	jmp    76d43b <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x73b>
  76d34c:	mov    0x6a8(%r15),%rcx
  76d353:	cmp    $0xffffffffffffffff,%rcx
  76d357:	je     76d2fe <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d359:	inc    %rcx
  76d35c:	mov    0x6a0(%r15),%rdx
  76d363:	cmp    %rdx,%rcx
  76d366:	jne    76d2fe <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d368:	cmp    %rdx,0x6e0(%r15)
  76d36f:	jne    76d2fe <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d371:	test   %rax,%rax
  76d374:	je     76d2fe <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d376:	cmpq   $0x0,0x6d0(%r15)
  76d37e:	je     76d2fe <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d384:	cmp    %rax,0x6d8(%r15)
  76d38b:	jne    76d2fe <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d391:	cmp    0x5f0(%r15),%r12
  76d398:	jne    76d2fe <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d39e:	lea    0x70(%rsp),%rsi
  76d3a3:	mov    %r15,%rdi
  76d3a6:	call   76e810 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11pointer_hitBW_>
  76d3ab:	mov    %rax,0x60(%rsp)
  76d3b0:	mov    %rdx,0x8(%rsp)
  76d3b5:	mov    0x650(%r15),%rax
  76d3bc:	test   %rax,%rax
  76d3bf:	je     76d3fc <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x6fc>
  76d3c1:	cmpq   $0x0,0xd8(%rax)
  76d3c9:	je     76d3fc <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x6fc>
  76d3cb:	cmp    %r12,0x60(%rsp)
  76d3d0:	jne    76d2fe <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d3d6:	cmp    %r13,0x8(%rsp)
  76d3db:	jne    76d2fe <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d3e1:	lea    0x70(%rsp),%rcx
  76d3e6:	mov    %r15,%rdi
  76d3e9:	mov    %r12,%rsi
  76d3ec:	mov    %r13,%rdx
  76d3ef:	call   76e940 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE19inspector_focus_hitBW_>
  76d3f4:	test   %al,%al
  76d3f6:	je     76d2fe <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d3fc:	lea    0x10(%rsp),%rdi
  76d401:	call   74d540 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  76d406:	jmp    76d439 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x739>
  76d408:	mov    %r15,%rdi
  76d40b:	call   78c850 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE3hitBO_>
  76d410:	test   $0x1,%al
  76d412:	je     76d430 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x730>
  76d414:	lea    0x5f0(%r15),%rdi
  76d41b:	mov    %rdx,%rsi
  76d41e:	call   *0x34bcdc(%rip)        # ab9100 <_DYNAMIC+0x4a0>
  76d424:	mov    %rax,0x60(%rsp)
  76d429:	mov    %rdx,0x8(%rsp)
  76d42e:	jmp    76d439 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x739>
  76d430:	movq   $0x0,0x60(%rsp)
  76d439:	xor    %ecx,%ecx
  76d43b:	mov    0x650(%r15),%rax
  76d442:	test   %rax,%rax
  76d445:	je     76d459 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x759>
  76d447:	mov    0xd8(%rax),%rax
  76d44e:	test   %rax,%rax
  76d451:	je     76d459 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x759>
  76d453:	movzbl 0x12(%rax),%eax
  76d457:	jmp    76d45b <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x75b>
  76d459:	xor    %eax,%eax
  76d45b:	cmp    $0x2,%ebp
  76d45e:	jne    76d54c <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x84c>
  76d464:	mov    0x628(%r15),%rdx
  76d46b:	mov    0x630(%r15),%rcx
  76d472:	mov    0x60(%rsp),%rbp
  76d477:	test   %rbp,%rbp
  76d47a:	sete   %sil
  76d47e:	or     %al,%sil
  76d481:	test   $0x1,%sil
  76d485:	je     76d594 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x894>
  76d48b:	movq   $0x0,0x628(%r15)
  76d496:	lea    0x10(%rsp),%rdi
  76d49b:	mov    %r15,%rsi
  76d49e:	call   7701a0 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE20publish_focus_changeB12_>
  76d4a3:	mov    0x10(%rsp),%rax
  76d4a8:	movups 0x18(%rsp),%xmm0
  76d4ad:	movaps %xmm0,0x70(%rsp)
  76d4b2:	movups 0x28(%rsp),%xmm0
  76d4b7:	movaps %xmm0,0x80(%rsp)
  76d4bf:	movups 0x38(%rsp),%xmm0
  76d4c4:	movaps %xmm0,0x90(%rsp)
  76d4cc:	cmp    $0xfffffffffffffffe,%rax
  76d4d0:	jne    76d685 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x985>
  76d4d6:	movaps 0x70(%rsp),%xmm0
  76d4db:	movaps 0x80(%rsp),%xmm1
  76d4e3:	movaps 0x90(%rsp),%xmm2
  76d4eb:	movaps %xmm2,0xe0(%rsp)
  76d4f3:	movaps %xmm1,0xd0(%rsp)
  76d4fb:	movaps %xmm0,0xc0(%rsp)
  76d503:	cmpq   $0xffffffffffffffff,0x5c8(%r15)
  76d50b:	je     76d6da <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x9da>
  76d511:	mov    0x6a8(%r15),%rax
  76d518:	cmp    $0xffffffffffffffff,%rax
  76d51c:	je     76d6da <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x9da>
  76d522:	inc    %rax
  76d525:	cmp    0x6a0(%r15),%rax
  76d52c:	jne    76d6da <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x9da>
  76d532:	cmpq   $0x0,0x6d0(%r15)
  76d53a:	je     76d6da <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x9da>
  76d540:	mov    0x6d8(%r15),%rax
  76d547:	jmp    76d6dc <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x9dc>
  76d54c:	test   %cl,%cl
  76d54e:	mov    0x60(%rsp),%rcx
  76d553:	jne    76d1b1 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4b1>
  76d559:	test   %rcx,%rcx
  76d55c:	je     76d1b1 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4b1>
  76d562:	cmp    %rcx,%r12
  76d565:	jne    76d1b1 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4b1>
  76d56b:	cmp    0x8(%rsp),%r13
  76d570:	jne    76d1b1 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4b1>
  76d576:	test   %al,%al
  76d578:	je     76d718 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xa18>
  76d57e:	mov    %rbx,%rdi
  76d581:	mov    %r15,%rsi
  76d584:	mov    %r12,%rdx
  76d587:	mov    %r13,%rcx
  76d58a:	call   772f70 <_RNvMs4_NtNtCslbxve4rcJus_4gpui7runtime9inspectorINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE16inspector_selectB14_>
  76d58f:	jmp    76d305 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76d594:	cmp    0x5f0(%r15),%rbp
  76d59b:	jne    76d6ae <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x9ae>
  76d5a1:	mov    %rcx,%r12
  76d5a4:	mov    %rdx,%r13
  76d5a7:	lea    0x10(%rsp),%rdi
  76d5ac:	mov    %r15,%rsi
  76d5af:	mov    0x8(%rsp),%rdx
  76d5b4:	call   78c570 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE16resolve_identityBO_>
  76d5b9:	mov    0x10(%rsp),%rax
  76d5be:	mov    0x18(%rsp),%rdi
  76d5c3:	cmp    $0xfffffffffffffffe,%rax
  76d5c7:	jne    76d6b3 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x9b3>
  76d5cd:	mov    0x2e0(%r15),%rsi
  76d5d4:	cmp    %rsi,%rdi
  76d5d7:	jae    76d940 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xc40>
  76d5dd:	mov    0x2d8(%r15),%rax
  76d5e4:	lea    (%rdi,%rdi,4),%rcx
  76d5e8:	mov    0x20(%rax,%rcx,8),%edi
  76d5ec:	call   775950 <_RNvMsh_NtCslbxve4rcJus_4gpui7runtimeNtB5_4Node4kind>
  76d5f1:	cmp    $0x4,%al
  76d5f3:	jne    76d80d <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xb0d>
  76d5f9:	mov    0x58(%rsp),%rax
  76d5fe:	cmp    $0xffffffff,%eax
  76d601:	je     76d94d <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xc4d>
  76d607:	movss  0x4(%r14),%xmm1
  76d60d:	dec    %eax
  76d60f:	movd   %eax,%xmm0
  76d613:	lea    0x10(%rsp),%rdi
  76d618:	mov    %r15,%rsi
  76d61b:	mov    %rbp,%rdx
  76d61e:	mov    0x8(%rsp),%r15
  76d623:	mov    %r15,%rcx
  76d626:	xor    %r8d,%r8d
  76d629:	call   76fb80 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE14select_pointerB12_>
  76d62e:	mov    0x10(%rsp),%rax
  76d633:	movups 0x38(%rsp),%xmm0
  76d638:	movaps %xmm0,0x90(%rsp)
  76d640:	movdqu 0x28(%rsp),%xmm1
  76d646:	movdqa %xmm1,0x80(%rsp)
  76d64f:	movups 0x18(%rsp),%xmm2
  76d654:	movaps %xmm2,0x70(%rsp)
  76d659:	movups %xmm0,0x28(%rbx)
  76d65d:	movdqu %xmm1,0x18(%rbx)
  76d662:	movups %xmm2,0x8(%rbx)
  76d666:	cmp    $0xfffffffffffffffe,%rax
  76d66a:	jne    76d881 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xb81>
  76d670:	mov    %rbp,0x8(%r14)
  76d674:	mov    %r15,0x10(%r14)
  76d678:	movq   $0x0,0x18(%r14)
  76d680:	jmp    76d203 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x503>
  76d685:	movaps 0x70(%rsp),%xmm0
  76d68a:	movaps 0x80(%rsp),%xmm1
  76d692:	movaps 0x90(%rsp),%xmm2
  76d69a:	movups %xmm2,0x28(%rbx)
  76d69e:	movups %xmm1,0x18(%rbx)
  76d6a2:	movups %xmm0,0x8(%rbx)
  76d6a6:	mov    %rax,(%rbx)
  76d6a9:	jmp    76d305 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76d6ae:	mov    $0x11,%eax
  76d6b3:	mov    0x40(%rsp),%rcx
  76d6b8:	mov    %rcx,0x30(%rbx)
  76d6bc:	movups 0x20(%rsp),%xmm0
  76d6c1:	movups 0x30(%rsp),%xmm1
  76d6c6:	movups %xmm1,0x20(%rbx)
  76d6ca:	movups %xmm0,0x10(%rbx)
  76d6ce:	mov    %rax,(%rbx)
  76d6d1:	mov    %rdi,0x8(%rbx)
  76d6d5:	jmp    76d305 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76d6da:	xor    %eax,%eax
  76d6dc:	mov    %rbp,0x8(%r14)
  76d6e0:	mov    0x8(%rsp),%rcx
  76d6e5:	mov    %rcx,0x10(%r14)
  76d6e9:	mov    %rax,0x18(%r14)
  76d6ed:	movaps 0xc0(%rsp),%xmm0
  76d6f5:	movdqa 0xd0(%rsp),%xmm1
  76d6fe:	movaps 0xe0(%rsp),%xmm2
  76d706:	movups %xmm2,0x28(%rbx)
  76d70a:	movdqu %xmm1,0x18(%rbx)
  76d70f:	movups %xmm0,0x8(%rbx)
  76d713:	jmp    76d203 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x503>
  76d718:	lea    0xb0(%rsp),%rsi
  76d720:	mov    %rbx,%rdi
  76d723:	mov    %r12,%rdx
  76d726:	mov    %r13,%rcx
  76d729:	call   769770 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB4_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE8activateBW_>
  76d72e:	jmp    76d305 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76d733:	movq   $0x4,0x70(%rsp)
  76d73c:	pxor   %xmm0,%xmm0
  76d740:	movdqu %xmm0,0x78(%rsp)
  76d746:	mov    0x5c0(%r14),%rax
  76d74d:	mov    %rax,0x8(%rsp)
  76d752:	test   %rax,%rax
  76d755:	je     76d8fd <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xbfd>
  76d75b:	mov    0x5b8(%r14),%rbp
  76d762:	mov    0x8(%rsp),%rax
  76d767:	mov    %rax,%r15
  76d76a:	shl    $0x6,%r15
  76d76e:	lea    -0x1(%rax),%r12
  76d772:	jmp    76d7d8 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xad8>
  76d774:	mov    0x80(%rsp),%rax
  76d77c:	mov    %rax,0x20(%rsp)
  76d781:	movups 0x70(%rsp),%xmm0
  76d786:	movaps %xmm0,0x10(%rsp)
  76d78b:	mov    0x650(%r14),%rax
  76d792:	test   %rax,%rax
  76d795:	je     76d809 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xb09>
  76d797:	cmpq   $0x0,(%rax)
  76d79b:	setne  %al
  76d79e:	movzbl %al,%ecx
  76d7a1:	mov    %rbp,%rdi
  76d7a4:	mov    0x8(%rsp),%rsi
  76d7a9:	lea    0x10(%rsp),%rdx
  76d7ae:	mov    %r12,%r8
  76d7b1:	movd   0x54(%rsp),%xmm0
  76d7b7:	movss  0x58(%rsp),%xmm1
  76d7bd:	call   *0x34bb2d(%rip)        # ab92f0 <_DYNAMIC+0x690>
  76d7c3:	test   %al,%al
  76d7c5:	jne    76d889 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xb89>
  76d7cb:	dec    %r12
  76d7ce:	add    $0xffffffffffffffc0,%r15
  76d7d2:	je     76d8fd <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xbfd>
  76d7d8:	cmpb   $0x0,-0x2(%rbp,%r15,1)
  76d7de:	jne    76d774 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xa74>
  76d7e0:	movzbl -0x3(%rbp,%r15,1),%eax
  76d7e6:	sub    $0x2,%al
  76d7e8:	movzbl %al,%eax
  76d7eb:	mov    $0x8,%ecx
  76d7f0:	cmovb  %ecx,%eax
  76d7f3:	cmp    $0x7,%al
  76d7f5:	je     76d774 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xa74>
  76d7fb:	movzbl %al,%eax
  76d7fe:	cmp    $0x4,%eax
  76d801:	je     76d774 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xa74>
  76d807:	jmp    76d7cb <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xacb>
  76d809:	xor    %eax,%eax
  76d80b:	jmp    76d79e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xa9e>
  76d80d:	lea    0x10(%rsp),%rdi
  76d812:	mov    %r15,%rsi
  76d815:	mov    %rbp,%rdx
  76d818:	mov    0x8(%rsp),%rcx
  76d81d:	call   76edd0 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE5focusBW_>
  76d822:	mov    0x10(%rsp),%rax
  76d827:	cmp    $0xfffffffffffffffe,%rax
  76d82b:	jne    76d838 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xb38>
  76d82d:	mov    %r13,%rdx
  76d830:	mov    %r12,%rcx
  76d833:	jmp    76d496 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x796>
  76d838:	mov    0x38(%rsp),%rcx
  76d83d:	movzbl 0x40(%rsp),%edx
  76d842:	mov    0x41(%rsp),%esi
  76d846:	mov    %esi,0x70(%rsp)
  76d84a:	mov    0x44(%rsp),%esi
  76d84e:	mov    %esi,0x73(%rsp)
  76d852:	movups 0x18(%rsp),%xmm0
  76d857:	movups 0x28(%rsp),%xmm1
  76d85c:	mov    0x70(%rsp),%esi
  76d860:	mov    0x73(%rsp),%edi
  76d864:	mov    %edi,0x34(%rbx)
  76d867:	mov    %esi,0x31(%rbx)
  76d86a:	mov    %rax,(%rbx)
  76d86d:	movups %xmm0,0x8(%rbx)
  76d871:	movups %xmm1,0x18(%rbx)
  76d875:	mov    %rcx,0x28(%rbx)
  76d879:	mov    %dl,0x30(%rbx)
  76d87c:	jmp    76d305 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76d881:	mov    %rax,(%rbx)
  76d884:	jmp    76d305 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76d889:	movq   $0x19,0x10(%rsp)
  76d892:	lea    0x10(%rsp),%rdi
  76d897:	call   74d540 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  76d89c:	mov    %r12,0xb8(%rsp)
  76d8a4:	movq   $0x1,0xb0(%rsp)
  76d8b0:	lea    0xb0(%rsp),%rdi
  76d8b8:	mov    %r14,%rsi
  76d8bb:	mov    %r14,%rdx
  76d8be:	call   75c7e0 <_RINvYINtNtNtNtCs4NRVxsYgnAr_4core4iter7sources7from_fn6FromFnNCNvMs6_NtNtCslbxve4rcJus_4gpui7runtime6scrollINtB17_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE12scroll_at_2ds0_0ENtNtNtBa_6traits8iterator8Iterator8try_folduNCINvNvB34_3any5checkjNCBZ_s1_0E0INtNtNtBc_3ops12control_flow11ControlFlowuEEB1U_>
  76d8c3:	test   %al,%al
  76d8c5:	je     76d8fd <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xbfd>
  76d8c7:	movq   $0x1,0x18(%rsp)
  76d8d0:	mov    %r12,0x20(%rsp)
  76d8d5:	movaps 0x60(%rsp),%xmm0
  76d8da:	movups %xmm0,0x28(%rsp)
  76d8df:	movq   $0x3,0x10(%rsp)
  76d8e8:	lea    0x10(%rsp),%rdx
  76d8ed:	mov    %rbx,%rdi
  76d8f0:	mov    %r13,%rsi
  76d8f3:	call   774890 <_RNvMs6_NtNtCslbxve4rcJus_4gpui7runtime6scrollINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE17apply_scroll_planBT_>
  76d8f8:	jmp    76d305 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76d8fd:	movq   $0x19,(%rbx)
  76d904:	jmp    76d305 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76d909:	lea    -0x69b1df(%rip),%rdi        # d2731 <GCC_except_table0+0x103c9>
  76d910:	lea    0x32c4e9(%rip),%rdx        # a99e00 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x16c8>
  76d917:	mov    $0x22,%esi
  76d91c:	call   *0x34b656(%rip)        # ab8f78 <_DYNAMIC+0x318>
  76d922:	lea    0x32c4ef(%rip),%rdx        # a99e18 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x16e0>
  76d929:	call   *0x34b5a1(%rip)        # ab8ed0 <_DYNAMIC+0x270>
  76d92f:	jmp    76d93e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xc3e>
  76d931:	lea    0x32c4f8(%rip),%rdi        # a99e30 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x16f8>
  76d938:	call   *0x34b60a(%rip)        # ab8f48 <_DYNAMIC+0x2e8>
  76d93e:	ud2
  76d940:	lea    0x32c501(%rip),%rdx        # a99e48 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1710>
  76d947:	call   *0x34b583(%rip)        # ab8ed0 <_DYNAMIC+0x270>
  76d94d:	lea    0x32c50c(%rip),%rdi        # a99e60 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1728>
  76d954:	call   *0x34b5ee(%rip)        # ab8f48 <_DYNAMIC+0x2e8>
  76d95a:	mov    %rax,%rbx
  76d95d:	lea    0x10(%rsp),%rdi
  76d962:	call   74d540 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  76d967:	mov    %rbx,%rdi
  76d96a:	call   a97380 <_Unwind_Resume@plt>
  76d96f:	mov    %rax,%rbx
  76d972:	lea    0x70(%rsp),%rdi
  76d977:	call   7461b0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultNtNtCslbxve4rcJus_4gpui7runtime6CommitNtBZ_5ErrorEECs9C2G9YFESsD_29canonical_text_public_control>
  76d97c:	mov    %rbx,%rdi
  76d97f:	call   a97380 <_Unwind_Resume@plt>

<gpui::runtime::RuntimeMut<canonical_text_public_control::Editor, ()>>::replace_input bytes=1615 frame=248

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000076f150 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_>:
  76f150:	push   %rbp
  76f151:	push   %r15
  76f153:	push   %r14
  76f155:	push   %r13
  76f157:	push   %r12
  76f159:	push   %rbx
  76f15a:	sub    $0xc8,%rsp
  76f161:	mov    %rdi,%rbx
  76f164:	mov    (%rsi),%r13
  76f167:	cmpb   $0x1,0x76e(%r13)
  76f16f:	jne    76f17d <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x2d>
  76f171:	movq   $0xe,(%rbx)
  76f178:	jmp    76f5d8 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x488>
  76f17d:	mov    %r8,%rbp
  76f180:	mov    %r9,0x90(%rsp)
  76f188:	mov    %rsi,0x98(%rsp)
  76f190:	lea    0x30(%rsp),%rdi
  76f195:	mov    %r13,%rsi
  76f198:	call   76a2f0 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11input_indexBY_>
  76f19d:	mov    0x30(%rsp),%rax
  76f1a2:	mov    0x38(%rsp),%rdx
  76f1a7:	cmp    $0xfffffffffffffffe,%rax
  76f1ab:	jne    76f2a7 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x157>
  76f1b1:	mov    0x2e0(%r13),%rsi
  76f1b8:	cmp    %rsi,%rdx
  76f1bb:	jae    76f6c3 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x573>
  76f1c1:	mov    0x2d8(%r13),%rcx
  76f1c8:	lea    (%rdx,%rdx,4),%r8
  76f1cc:	mov    0x20(%rcx,%r8,8),%edi
  76f1d1:	mov    %edi,%eax
  76f1d3:	and    $0xf,%eax
  76f1d6:	cmp    $0x9,%eax
  76f1d9:	ja     76f671 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x521>
  76f1df:	cmp    $0x6,%eax
  76f1e2:	je     76f5ea <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x49a>
  76f1e8:	shr    $0x4,%edi
  76f1eb:	je     76f5ea <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x49a>
  76f1f1:	mov    0x2f8(%r13),%rsi
  76f1f8:	dec    %edi
  76f1fa:	cmp    %rdi,%rsi
  76f1fd:	jbe    76f6d6 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x586>
  76f203:	mov    0x2f0(%r13),%rax
  76f20a:	lea    (%rdi,%rdi,4),%rsi
  76f20e:	shl    $0x4,%rsi
  76f212:	cmpq   $0xfffffffffffffffe,(%rax,%rsi,1)
  76f217:	je     76f657 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x507>
  76f21d:	add    %rsi,%rax
  76f220:	mov    0x48(%rax),%r12
  76f224:	test   %r12,%r12
  76f227:	je     76f664 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x514>
  76f22d:	mov    0x608(%r13),%rax
  76f234:	test   %rax,%rax
  76f237:	je     76f6aa <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x55a>
  76f23d:	mov    (%rcx,%r8,8),%r14
  76f241:	mov    0x610(%r13),%rcx
  76f248:	movzwl 0x1c2(%rax),%edi
  76f24f:	mov    %edi,%r9d
  76f252:	shl    $0x5,%r9d
  76f256:	mov    $0xffffffffffffffff,%rsi
  76f25d:	xor    %r8d,%r8d
  76f260:	cmp    %r8,%r9
  76f263:	je     76f290 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x140>
  76f265:	cmp    0x170(%rax,%rsi,8),%r12
  76f26d:	seta   %r10b
  76f271:	sbb    $0x0,%r10b
  76f275:	add    $0x20,%r8
  76f279:	inc    %rsi
  76f27c:	cmp    $0x1,%r10b
  76f280:	je     76f260 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x110>
  76f282:	movzbl %r10b,%edi
  76f286:	test   %edi,%edi
  76f288:	je     76f2d0 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x180>
  76f28a:	jmp    76f293 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x143>
  76f28c:	nopl   0x0(%rax)
  76f290:	mov    %rdi,%rsi
  76f293:	sub    $0x1,%rcx
  76f297:	jb     76f6aa <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x55a>
  76f29d:	mov    0x1c8(%rax,%rsi,8),%rax
  76f2a5:	jmp    76f248 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0xf8>
  76f2a7:	mov    0x60(%rsp),%rcx
  76f2ac:	mov    %rcx,0x30(%rbx)
  76f2b0:	movdqu 0x40(%rsp),%xmm0
  76f2b6:	movups 0x50(%rsp),%xmm1
  76f2bb:	movups %xmm1,0x20(%rbx)
  76f2bf:	movdqu %xmm0,0x10(%rbx)
  76f2c4:	mov    %rax,(%rbx)
  76f2c7:	mov    %rdx,0x8(%rbx)
  76f2cb:	jmp    76f5d8 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x488>
  76f2d0:	cmpq   $0xffffffffffffffff,-0x20(%rax,%r8,1)
  76f2d6:	je     76f2ee <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x19e>
  76f2d8:	mov    -0x8(%rax,%r8,1),%r15
  76f2dd:	cmpb   $0x2,0xc(%rbp)
  76f2e1:	je     76f2fb <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x1ab>
  76f2e3:	movups 0x0(%rbp),%xmm0
  76f2e7:	movups %xmm0,0x38(%rsp)
  76f2ec:	jmp    76f317 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x1c7>
  76f2ee:	lea    0x32af4b(%rip),%r15        # a9a240 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1b08>
  76f2f5:	cmpb   $0x2,0xc(%rbp)
  76f2f9:	jne    76f2e3 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x193>
  76f2fb:	lea    0x30(%rsp),%rdi
  76f300:	mov    %r13,%rsi
  76f303:	call   76a430 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE12selection_atBY_>
  76f308:	mov    0x30(%rsp),%rax
  76f30d:	cmp    $0xfffffffffffffffe,%rax
  76f311:	jne    76f5ba <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x46a>
  76f317:	mov    %r15,0x28(%rsp)
  76f31c:	mov    %r14,0x88(%rsp)
  76f324:	movdqu 0x38(%rsp),%xmm0
  76f32a:	movdqa %xmm0,0xa0(%rsp)
  76f333:	cmp    $0x1,%r12d
  76f337:	jne    76f393 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x243>
  76f339:	mov    0x248(%r13),%rbp
  76f340:	mov    0x250(%r13),%r14
  76f347:	shl    $0x4,%r14
  76f34b:	xor    %r15d,%r15d
  76f34e:	xchg   %ax,%ax
  76f350:	cmp    %r15,%r14
  76f353:	je     76f584 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x434>
  76f359:	mov    0x0(%rbp,%r15,1),%rdi
  76f35e:	mov    0x8(%rbp,%r15,1),%rax
  76f363:	call   *0x18(%rax)
  76f366:	add    $0x10,%r15
  76f36a:	cmp    %r12,%rax
  76f36d:	jne    76f350 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x200>
  76f36f:	mov    -0x10(%rbp,%r15,1),%rdi
  76f374:	mov    -0x8(%rbp,%r15,1),%rax
  76f379:	lea    0x290(%r13),%rsi
  76f380:	call   *0x28(%rax)
  76f383:	mov    0x28(%rsp),%r15
  76f388:	mov    %rax,%r14
  76f38b:	mov    %rdx,%rbp
  76f38e:	jmp    76f417 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x2c7>
  76f393:	mov    0x278(%r13),%rbp
  76f39a:	mov    0x280(%r13),%r14
  76f3a1:	shl    $0x4,%r14
  76f3a5:	xor    %r15d,%r15d
  76f3a8:	nopl   0x0(%rax,%rax,1)
  76f3b0:	cmp    %r15,%r14
  76f3b3:	je     76f584 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x434>
  76f3b9:	mov    0x0(%rbp,%r15,1),%rdi
  76f3be:	mov    0x8(%rbp,%r15,1),%rax
  76f3c3:	mov    %r12,%rsi
  76f3c6:	call   *0x30(%rax)
  76f3c9:	add    $0x10,%r15
  76f3cd:	test   %al,%al
  76f3cf:	je     76f3b0 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x260>
  76f3d1:	mov    -0x10(%rbp,%r15,1),%rsi
  76f3d6:	mov    -0x8(%rbp,%r15,1),%rax
  76f3db:	lea    0xb0(%rsp),%rdi
  76f3e3:	lea    0x290(%r13),%rdx
  76f3ea:	mov    %r12,%rcx
  76f3ed:	call   *0x58(%rax)
  76f3f0:	mov    0x28(%rsp),%r15
  76f3f5:	mov    0xb0(%rsp),%rax
  76f3fd:	mov    0xb8(%rsp),%r14
  76f405:	mov    0xc0(%rsp),%rbp
  76f40d:	cmp    $0xffffffffffffffff,%rax
  76f411:	jne    76f58c <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x43c>
  76f417:	mov    %r14,%rdi
  76f41a:	call   *0x18(%rbp)
  76f41d:	mov    %rdx,%rcx
  76f420:	lea    0x30(%rsp),%rdi
  76f425:	mov    %r15,%rsi
  76f428:	mov    %rax,%rdx
  76f42b:	mov    %r12,%r8
  76f42e:	call   *0x349efc(%rip)        # ab9330 <_DYNAMIC+0x6d0>
  76f434:	mov    0x38(%rsp),%rax
  76f439:	mov    0x40(%rsp),%r14
  76f43e:	mov    0x48(%rsp),%rbp
  76f443:	cmpb   $0x0,0x30(%rsp)
  76f448:	jne    76f58c <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x43c>
  76f44e:	cmp    $0xffffffffffffffff,%rax
  76f452:	je     76f5f7 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x4a7>
  76f458:	mov    %rax,0x10(%rsp)
  76f45d:	mov    %r14,0x18(%rsp)
  76f462:	mov    %rbp,0x80(%rsp)
  76f46a:	mov    0x10(%rsp),%rax
  76f46f:	mov    %rax,0x70(%rsp)
  76f474:	mov    0x18(%rsp),%rax
  76f479:	mov    %rax,0x78(%rsp)
  76f47e:	mov    0x78(%rsp),%r14
  76f483:	movdqa 0xa0(%rsp),%xmm0
  76f48c:	movdqa %xmm0,0x30(%rsp)
  76f492:	lea    0x30(%rsp),%rdx
  76f497:	mov    %r14,%rdi
  76f49a:	mov    %rbp,%rsi
  76f49d:	call   *0x349e85(%rip)        # ab9328 <_DYNAMIC+0x6c8>
  76f4a3:	mov    $0x18,%ecx
  76f4a8:	test   %al,%al
  76f4aa:	je     76f68f <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x53f>
  76f4b0:	movdqa 0xa0(%rsp),%xmm0
  76f4b9:	movd   %xmm0,%r13d
  76f4be:	pshufd $0xee,%xmm0,%xmm0
  76f4c3:	movd   %xmm0,%eax
  76f4c7:	cmp    %r13,%rax
  76f4ca:	mov    %r13,%rbp
  76f4cd:	cmovb  %rax,%rbp
  76f4d1:	mov    %rbp,%r15
  76f4d4:	mov    0x100(%rsp),%rcx
  76f4dc:	add    %rcx,%r15
  76f4df:	jb     76f68a <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x53a>
  76f4e5:	cmp    %r13,%rax
  76f4e8:	cmova  %rax,%r13
  76f4ec:	movq   $0x1e,0x30(%rsp)
  76f4f5:	lea    0x30(%rsp),%rdi
  76f4fa:	call   74d540 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  76f4ff:	lea    0x70(%rsp),%rdi
  76f504:	mov    %rbp,%rsi
  76f507:	mov    %r13,%rdx
  76f50a:	mov    0x90(%rsp),%rcx
  76f512:	mov    0x100(%rsp),%r8
  76f51a:	call   73d780 <_RINvMNtCscdodAO9FK5_5alloc6stringNtB3_6String13replace_rangeINtNtNtCs4NRVxsYgnAr_4core3ops5range5RangejEECs9C2G9YFESsD_29canonical_text_public_control>
  76f51f:	mov    0x88(%rsp),%rax
  76f527:	mov    %rax,0x10(%rsp)
  76f52c:	mov    %r12,0x20(%rsp)
  76f531:	mov    %r15,0x18(%rsp)
  76f536:	movq   $0x1,0x8(%rsp)
  76f53f:	mov    %r12,0x48(%rsp)
  76f544:	movaps 0x70(%rsp),%xmm0
  76f549:	movaps %xmm0,0x30(%rsp)
  76f54e:	mov    0x80(%rsp),%rax
  76f556:	mov    %rax,0x40(%rsp)
  76f55b:	mov    0x28(%rsp),%rax
  76f560:	mov    %rax,0x50(%rsp)
  76f565:	lea    0x30(%rsp),%rcx
  76f56a:	lea    0x8(%rsp),%r8
  76f56f:	mov    %rbx,%rdi
  76f572:	mov    0x98(%rsp),%rsi
  76f57a:	mov    %r12,%rdx
  76f57d:	call   73d870 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_>
  76f582:	jmp    76f5d8 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x488>
  76f584:	mov    $0xb,%eax
  76f589:	mov    %r12,%r14
  76f58c:	mov    %rax,0x10(%rsp)
  76f591:	mov    %r14,0x18(%rsp)
  76f596:	mov    %rbp,0x20(%rsp)
  76f59b:	mov    %rbp,0x18(%rbx)
  76f59f:	mov    0x10(%rsp),%rax
  76f5a4:	mov    %rax,0x8(%rbx)
  76f5a8:	mov    0x18(%rsp),%rax
  76f5ad:	mov    %rax,0x10(%rbx)
  76f5b1:	movq   $0x20,(%rbx)
  76f5b8:	jmp    76f5d8 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x488>
  76f5ba:	movups 0x48(%rsp),%xmm0
  76f5bf:	movups 0x58(%rsp),%xmm1
  76f5c4:	movups %xmm1,0x28(%rbx)
  76f5c8:	movups %xmm0,0x18(%rbx)
  76f5cc:	movups 0x38(%rsp),%xmm0
  76f5d1:	mov    %rax,(%rbx)
  76f5d4:	movups %xmm0,0x8(%rbx)
  76f5d8:	add    $0xc8,%rsp
  76f5df:	pop    %rbx
  76f5e0:	pop    %r12
  76f5e2:	pop    %r13
  76f5e4:	pop    %r14
  76f5e6:	pop    %r15
  76f5e8:	pop    %rbp
  76f5e9:	ret
  76f5ea:	lea    0x32a92f(%rip),%rdi        # a99f20 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x17e8>
  76f5f1:	call   *0x349951(%rip)        # ab8f48 <_DYNAMIC+0x2e8>
  76f5f7:	test   %rbp,%rbp
  76f5fa:	jns    76f60d <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x4bd>
  76f5fc:	xor    %r15d,%r15d
  76f5ff:	mov    %r15,%rdi
  76f602:	mov    %rbp,%rsi
  76f605:	call   *0x34994d(%rip)        # ab8f58 <_DYNAMIC+0x2f8>
  76f60b:	ud2
  76f60d:	je     76f648 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x4f8>
  76f60f:	call   *0x349893(%rip)        # ab8ea8 <_DYNAMIC+0x248>
  76f615:	mov    $0x1,%r15d
  76f61b:	mov    $0x1,%esi
  76f620:	mov    %rbp,%rdi
  76f623:	call   *0x349887(%rip)        # ab8eb0 <_DYNAMIC+0x250>
  76f629:	test   %rax,%rax
  76f62c:	je     76f5ff <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x4af>
  76f62e:	mov    %rax,%rdi
  76f631:	mov    %r14,%rsi
  76f634:	mov    %rbp,%rdx
  76f637:	mov    %rax,%r14
  76f63a:	call   *0x349880(%rip)        # ab8ec0 <memcpy@GLIBC_2.14>
  76f640:	mov    %rbp,%rax
  76f643:	jmp    76f458 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x308>
  76f648:	mov    $0x1,%r14d
  76f64e:	xor    %eax,%eax
  76f650:	xor    %ebp,%ebp
  76f652:	jmp    76f458 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x308>
  76f657:	lea    0x32992a(%rip),%rdi        # a98f88 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x850>
  76f65e:	call   *0x3498e4(%rip)        # ab8f48 <_DYNAMIC+0x2e8>
  76f664:	lea    0x32a8cd(%rip),%rdi        # a99f38 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1800>
  76f66b:	call   *0x3498d7(%rip)        # ab8f48 <_DYNAMIC+0x2e8>
  76f671:	lea    -0x69cdb0(%rip),%rdi        # d28c8 <GCC_except_table0+0x10560>
  76f678:	lea    0x32ab91(%rip),%rdx        # a9a210 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1ad8>
  76f67f:	mov    $0x83,%esi
  76f684:	call   *0x34984e(%rip)        # ab8ed8 <_DYNAMIC+0x278>
  76f68a:	mov    $0x1e,%ecx
  76f68f:	mov    %rcx,(%rbx)
  76f692:	mov    0x70(%rsp),%rsi
  76f697:	test   %rsi,%rsi
  76f69a:	je     76f5d8 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x488>
  76f6a0:	mov    $0x1,%edx
  76f6a5:	jmp    76f75b <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x60b>
  76f6aa:	lea    -0x69cf5e(%rip),%rdi        # d2753 <GCC_except_table0+0x103eb>
  76f6b1:	lea    0x32a898(%rip),%rdx        # a99f50 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1818>
  76f6b8:	mov    $0x16,%esi
  76f6bd:	call   *0x3498b5(%rip)        # ab8f78 <_DYNAMIC+0x318>
  76f6c3:	lea    0x32a83e(%rip),%rax        # a99f08 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x17d0>
  76f6ca:	mov    %rdx,%rdi
  76f6cd:	mov    %rax,%rdx
  76f6d0:	call   *0x3497fa(%rip)        # ab8ed0 <_DYNAMIC+0x270>
  76f6d6:	lea    0x329893(%rip),%rdx        # a98f70 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x838>
  76f6dd:	call   *0x3497ed(%rip)        # ab8ed0 <_DYNAMIC+0x270>
  76f6e3:	mov    %rax,%rbx
  76f6e6:	mov    0x70(%rsp),%rsi
  76f6eb:	test   %rsi,%rsi
  76f6ee:	je     76f700 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x5b0>
  76f6f0:	mov    0x78(%rsp),%rdi
  76f6f5:	mov    $0x1,%edx
  76f6fa:	call   *0x3497a0(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  76f700:	mov    %rbx,%rdi
  76f703:	call   a97380 <_Unwind_Resume@plt>
  76f708:	jmp    76f70c <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x5bc>
  76f70a:	jmp    76f70c <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x5bc>
  76f70c:	mov    %rax,%rdi
  76f70f:	call   *0x3497e3(%rip)        # ab8ef8 <_DYNAMIC+0x298>
  76f715:	mov    %rax,%r14
  76f718:	mov    %rdx,%r15
  76f71b:	mov    %rax,0x10(%rsp)
  76f720:	mov    %rdx,0x18(%rsp)
  76f725:	movq   $0x2,0x8(%rsp)
  76f72e:	mov    %r13,%rdi
  76f731:	call   78cbc0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE6poisonBO_>
  76f736:	movq   $0xf,(%rbx)
  76f73d:	mov    (%r15),%rax
  76f740:	test   %rax,%rax
  76f743:	je     76f74a <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x5fa>
  76f745:	mov    %r14,%rdi
  76f748:	call   *%rax
  76f74a:	mov    0x8(%r15),%rsi
  76f74e:	test   %rsi,%rsi
  76f751:	je     76f5d8 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x488>
  76f757:	mov    0x10(%r15),%rdx
  76f75b:	mov    %r14,%rdi
  76f75e:	call   *0x34973c(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  76f764:	jmp    76f5d8 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x488>
  76f769:	mov    %rax,%rbx
  76f76c:	mov    0x8(%r15),%rsi
  76f770:	test   %rsi,%rsi
  76f773:	je     76f700 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x5b0>
  76f775:	mov    0x10(%r15),%rdx
  76f779:	mov    %r14,%rdi
  76f77c:	jmp    76f6fa <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x5aa>
  76f781:	mov    %rax,%rbx
  76f784:	lea    0x8(%rsp),%rdi
  76f789:	call   745f90 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultIBC_NtNtCscdodAO9FK5_5alloc6string6StringNtNtCslbxve4rcJus_4gpui6source9BindErrorEINtNtB15_5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECs9C2G9YFESsD_29canonical_text_public_control>
  76f78e:	jmp    76f700 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x5b0>
  76f793:	call   *0x34972f(%rip)        # ab8ec8 <_DYNAMIC+0x268>
  76f799:	call   *0x349761(%rip)        # ab8f00 <_DYNAMIC+0x2a0>

<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::acknowledge bytes=1581 frame=200

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000077ae10 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_>:
  77ae10:	push   %r15
  77ae12:	push   %r14
  77ae14:	push   %r13
  77ae16:	push   %r12
  77ae18:	push   %rbx
  77ae19:	sub    $0xa0,%rsp
  77ae20:	mov    %rdi,%r14
  77ae23:	cmp    %rdx,0x6d0(%rsi)
  77ae2a:	jne    77b16e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x35e>
  77ae30:	mov    %rcx,%r15
  77ae33:	mov    %rsi,%rbx
  77ae36:	cmp    %rcx,0x6d8(%rsi)
  77ae3d:	jne    77b16e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x35e>
  77ae43:	lea    0x600(%rbx),%rdi
  77ae4a:	mov    %r15,%rsi
  77ae4d:	call   *0x33e58d(%rip)        # ab93e0 <_DYNAMIC+0x780>
  77ae53:	mov    0x5e8(%rbx),%rax
  77ae5a:	mov    %rax,0x30(%rsp)
  77ae5f:	movdqu 0x5c8(%rbx),%xmm0
  77ae67:	movdqu 0x5d8(%rbx),%xmm1
  77ae6f:	movdqa %xmm0,0x10(%rsp)
  77ae75:	movq   $0xffffffffffffffff,0x5c8(%rbx)
  77ae80:	movzbl 0x76c(%rbx),%eax
  77ae87:	xor    $0x1,%rax
  77ae8b:	cmpq   $0xffffffffffffffff,0x10(%rsp)
  77ae91:	movdqa %xmm1,0x20(%rsp)
  77ae97:	mov    $0x1,%r13d
  77ae9d:	cmove  %rax,%r13
  77aea1:	je     77af49 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x139>
  77aea7:	movdqa 0x30(%rsp),%xmm0
  77aead:	movss  0x34(%rsp),%xmm2
  77aeb3:	movd   %xmm0,%eax
  77aeb7:	pand   -0x6b742f(%rip),%xmm0        # c3a90 <GCC_except_table0+0x1728>
  77aebf:	pxor   %xmm1,%xmm1
  77aec3:	punpcklwd %xmm1,%xmm0
  77aec7:	movq   %xmm0,0x6c0(%rbx)
  77aecf:	test   %ax,%ax
  77aed2:	js     77b17a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x36a>
  77aed8:	movss  %xmm2,0xc(%rsp)
  77aede:	lea    0x5b0(%rbx),%r12
  77aee5:	mov    %r12,%rdi
  77aee8:	call   747220 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCslbxve4rcJus_4gpui7runtime9PresentedEECs9C2G9YFESsD_29canonical_text_public_control>
  77aeed:	mov    0x20(%rsp),%rax
  77aef2:	mov    %rax,0x10(%r12)
  77aef7:	movaps 0x10(%rsp),%xmm0
  77aefc:	movups %xmm0,(%r12)
  77af01:	mov    0x6e8(%rbx),%rdi
  77af08:	test   %rdi,%rdi
  77af0b:	je     77af13 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x103>
  77af0d:	call   *0x33e4d5(%rip)        # ab93e8 <_DYNAMIC+0x788>
  77af13:	mov    0x650(%rbx),%rax
  77af1a:	test   %rax,%rax
  77af1d:	je     77af3b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x12b>
  77af1f:	mov    0xe0(%rax),%rax
  77af26:	test   %rax,%rax
  77af29:	je     77af3b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x12b>
  77af2b:	mov    0x50(%rax),%rcx
  77af2f:	mov    %rcx,0x38(%rax)
  77af33:	movups 0x40(%rax),%xmm0
  77af37:	movups %xmm0,0x28(%rax)
  77af3b:	movd   0xc(%rsp),%xmm0
  77af41:	movd   %xmm0,0x764(%rbx)
  77af49:	mov    0x650(%rbx),%rax
  77af50:	test   %rax,%rax
  77af53:	je     77b19c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77af59:	mov    0x60(%rax),%r12
  77af5d:	movq   $0xffffffffffffffff,0x60(%rax)
  77af65:	cmp    $0xffffffffffffffff,%r12
  77af69:	je     77b00d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x1fd>
  77af6f:	mov    0xb8(%rax),%rcx
  77af76:	mov    %rcx,0x90(%rsp)
  77af7e:	movups 0xa8(%rax),%xmm0
  77af85:	movaps %xmm0,0x80(%rsp)
  77af8d:	movups 0x68(%rax),%xmm0
  77af91:	movups 0x78(%rax),%xmm1
  77af95:	movups 0x88(%rax),%xmm2
  77af9c:	movups 0x98(%rax),%xmm3
  77afa3:	movaps %xmm3,0x70(%rsp)
  77afa8:	movaps %xmm2,0x60(%rsp)
  77afad:	movaps %xmm1,0x50(%rsp)
  77afb2:	movaps %xmm0,0x40(%rsp)
  77afb7:	mov    0x650(%rbx),%rdi
  77afbe:	call   74e9d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime8metadata5SheetECs9C2G9YFESsD_29canonical_text_public_control>
  77afc3:	mov    0x650(%rbx),%rax
  77afca:	mov    %r12,(%rax)
  77afcd:	movaps 0x40(%rsp),%xmm0
  77afd2:	movdqa 0x50(%rsp),%xmm1
  77afd8:	movaps 0x60(%rsp),%xmm2
  77afdd:	movaps 0x70(%rsp),%xmm3
  77afe2:	movups %xmm0,0x8(%rax)
  77afe6:	movdqu %xmm1,0x18(%rax)
  77afeb:	movups %xmm2,0x28(%rax)
  77afef:	movups %xmm3,0x38(%rax)
  77aff3:	movdqa 0x80(%rsp),%xmm0
  77affc:	movdqu %xmm0,0x48(%rax)
  77b001:	mov    0x90(%rsp),%rcx
  77b009:	mov    %rcx,0x58(%rax)
  77b00d:	mov    0x650(%rbx),%r12
  77b014:	test   %r12,%r12
  77b017:	je     77b19c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77b01d:	mov    0x100(%r12),%rdi
  77b025:	test   %rdi,%rdi
  77b028:	je     77b079 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x269>
  77b02a:	call   *0x33e3c0(%rip)        # ab93f0 <_DYNAMIC+0x790>
  77b030:	mov    0x100(%r12),%rax
  77b038:	cmpq   $0x0,0x10(%rax)
  77b03d:	jne    77b079 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x269>
  77b03f:	cmpq   $0x0,0x58(%rax)
  77b044:	jne    77b079 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x269>
  77b046:	cmpq   $0x0,0x28(%rax)
  77b04b:	jne    77b079 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x269>
  77b04d:	cmpq   $0xffffffffffffffff,0x30(%rax)
  77b052:	jne    77b079 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x269>
  77b054:	mov    0x650(%rbx),%rax
  77b05b:	mov    0x100(%rax),%rdi
  77b062:	call   745bf0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionINtNtCscdodAO9FK5_5alloc5boxed3BoxNtNtNtCslbxve4rcJus_4gpui7runtime8geometry8GeometryEEECs9C2G9YFESsD_29canonical_text_public_control>
  77b067:	mov    0x650(%rbx),%rax
  77b06e:	movq   $0x0,0x100(%rax)
  77b079:	mov    0x650(%rbx),%r12
  77b080:	test   %r12,%r12
  77b083:	je     77b19c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77b089:	mov    0xe0(%r12),%rdi
  77b091:	test   %rdi,%rdi
  77b094:	je     77b0da <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x2ca>
  77b096:	cmpb   $0x2,0x24(%rdi)
  77b09a:	jne    77b0da <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x2ca>
  77b09c:	cmpb   $0x2,0x3c(%rdi)
  77b0a0:	jne    77b0da <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x2ca>
  77b0a2:	cmpb   $0x2,0x54(%rdi)
  77b0a6:	jne    77b0da <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x2ca>
  77b0a8:	mov    $0x58,%esi
  77b0ad:	mov    $0x8,%edx
  77b0b2:	call   *0x33dde8(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  77b0b8:	mov    0x650(%rbx),%rax
  77b0bf:	movq   $0x0,0xe0(%rax)
  77b0ca:	mov    0x650(%rbx),%r12
  77b0d1:	test   %r12,%r12
  77b0d4:	je     77b19c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77b0da:	cmpq   $0x0,0xd8(%r12)
  77b0e3:	jne    77b19c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77b0e9:	cmpq   $0x0,0xe0(%r12)
  77b0f2:	jne    77b19c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77b0f8:	cmpq   $0x0,0x100(%r12)
  77b101:	jne    77b19c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77b107:	cmpq   $0x0,0xd0(%r12)
  77b110:	jne    77b19c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77b116:	cmpq   $0x0,0xf8(%r12)
  77b11f:	jne    77b19c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77b121:	mov    0x60(%r12),%rax
  77b126:	cmp    $0xffffffff,%eax
  77b129:	jne    77b19c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77b12b:	cmpq   $0x0,0x28(%r12)
  77b131:	jne    77b19c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77b133:	mov    (%r12),%rax
  77b137:	or     0x40(%r12),%rax
  77b13c:	jne    77b19c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77b13e:	cmpq   $0x0,0x58(%r12)
  77b144:	jne    77b19c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77b146:	mov    %r12,%rdi
  77b149:	call   74ea70 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime8metadata8MetadataECs9C2G9YFESsD_29canonical_text_public_control>
  77b14e:	mov    $0x108,%esi
  77b153:	mov    $0x8,%edx
  77b158:	mov    %r12,%rdi
  77b15b:	call   *0x33dd3f(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  77b161:	movq   $0x0,0x650(%rbx)
  77b16c:	jmp    77b19c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77b16e:	movq   $0x15,(%r14)
  77b175:	jmp    77b350 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x540>
  77b17a:	movss  %xmm2,0x764(%rbx)
  77b182:	lea    0x10(%rsp),%rdi
  77b187:	call   747220 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCslbxve4rcJus_4gpui7runtime9PresentedEECs9C2G9YFESsD_29canonical_text_public_control>
  77b18c:	mov    0x650(%rbx),%rax
  77b193:	test   %rax,%rax
  77b196:	jne    77af59 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x149>
  77b19c:	mov    0x6e8(%rbx),%rdi
  77b1a3:	test   %rdi,%rdi
  77b1a6:	je     77b1cd <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x3bd>
  77b1a8:	cmpq   $0x0,0x30(%rdi)
  77b1ad:	jne    77b1cd <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x3bd>
  77b1af:	cmpq   $0x0,0x10(%rdi)
  77b1b4:	jne    77b1cd <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x3bd>
  77b1b6:	cmpq   $0xffffffffffffffff,0x18(%rdi)
  77b1bb:	jne    77b1cd <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x3bd>
  77b1bd:	call   745a80 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionINtNtCscdodAO9FK5_5alloc5boxed3BoxNtNtNtCslbxve4rcJus_4gpui7runtime13text_geometry13TextResourcesEEECs9C2G9YFESsD_29canonical_text_public_control>
  77b1c2:	movq   $0x0,0x6e8(%rbx)
  77b1cd:	mov    0x628(%rbx),%rax
  77b1d4:	test   %rax,%rax
  77b1d7:	je     77b27f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x46f>
  77b1dd:	cmp    0x5f0(%rbx),%rax
  77b1e4:	jne    77b274 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x464>
  77b1ea:	mov    0x630(%rbx),%rdx
  77b1f1:	lea    0x40(%rsp),%rdi
  77b1f6:	mov    %rbx,%rsi
  77b1f9:	call   78c570 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE16resolve_identityBO_>
  77b1fe:	mov    0x40(%rsp),%rax
  77b203:	mov    0x48(%rsp),%rsi
  77b208:	cmp    $0xfffffffffffffffe,%rax
  77b20c:	jne    77b239 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x429>
  77b20e:	mov    0x2e0(%rbx),%rax
  77b215:	cmp    %rax,%rsi
  77b218:	jae    77b361 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x551>
  77b21e:	lea    (%rsi,%rsi,4),%rdi
  77b222:	shl    $0x3,%rdi
  77b226:	add    0x2d8(%rbx),%rdi
  77b22d:	call   *0x33df95(%rip)        # ab91c8 <_DYNAMIC+0x568>
  77b233:	test   %al,%al
  77b235:	je     77b274 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x464>
  77b237:	jmp    77b27f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x46f>
  77b239:	cmp    $0xd,%rax
  77b23d:	jl     77b257 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x447>
  77b23f:	cmp    $0x21,%rax
  77b243:	je     77b257 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x447>
  77b245:	cmp    $0x26,%rax
  77b249:	jne    77b274 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x464>
  77b24b:	test   %rsi,%rsi
  77b24e:	je     77b274 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x464>
  77b250:	lea    0x50(%rsp),%rax
  77b255:	jmp    77b266 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x456>
  77b257:	mov    0x58(%rsp),%rsi
  77b25c:	test   %rsi,%rsi
  77b25f:	je     77b274 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x464>
  77b261:	lea    0x60(%rsp),%rax
  77b266:	mov    (%rax),%rdi
  77b269:	mov    $0x1,%edx
  77b26e:	call   *0x33dc2c(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  77b274:	movq   $0x0,0x628(%rbx)
  77b27f:	mov    0x6e0(%rbx),%rax
  77b286:	mov    %rax,0x6a8(%rbx)
  77b28d:	mov    %r15,0x6b0(%rbx)
  77b294:	mov    0x6b8(%rbx),%rcx
  77b29b:	test   %rcx,%rcx
  77b29e:	je     77b2f2 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x4e2>
  77b2a0:	mov    0x6c0(%rbx),%rdx
  77b2a7:	cmpb   $0x0,0x59(%rcx)
  77b2ab:	je     77b2c3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x4b3>
  77b2ad:	cmp    %r15,0x30(%rcx)
  77b2b1:	jne    77b2d5 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x4c5>
  77b2b3:	cmp    %rax,0x38(%rcx)
  77b2b7:	jne    77b2d5 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x4c5>
  77b2b9:	cmp    %rdx,0x40(%rcx)
  77b2bd:	sete   %sil
  77b2c1:	jmp    77b2d7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x4c7>
  77b2c3:	cmp    %rax,0x38(%rcx)
  77b2c7:	jne    77b2d5 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x4c5>
  77b2c9:	cmp    %r15,0x30(%rcx)
  77b2cd:	jne    77b2d5 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x4c5>
  77b2cf:	cmp    %rdx,0x40(%rcx)
  77b2d3:	je     77b2f2 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x4e2>
  77b2d5:	xor    %esi,%esi
  77b2d7:	and    %sil,0x58(%rcx)
  77b2db:	movb   $0x0,0x59(%rcx)
  77b2df:	mov    %r15,0x30(%rcx)
  77b2e3:	mov    %rax,0x38(%rcx)
  77b2e7:	mov    %rdx,0x40(%rcx)
  77b2eb:	mov    0x6a8(%rbx),%rax
  77b2f2:	movb   $0x1,0x76c(%rbx)
  77b2f9:	add    %r13,0x738(%rbx)
  77b300:	mov    0x6a0(%rbx),%rcx
  77b307:	cmpq   $0x0,0x6d0(%rbx)
  77b30f:	je     77b327 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x517>
  77b311:	mov    0x6e0(%rbx),%rsi
  77b318:	xor    %edx,%edx
  77b31a:	cmpq   $0xffffffffffffffff,0x5c8(%rbx)
  77b322:	setne  %dl
  77b325:	jmp    77b329 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x519>
  77b327:	xor    %edx,%edx
  77b329:	mov    0x758(%rbx),%rdi
  77b330:	mov    %rdx,0x8(%r14)
  77b334:	mov    %rsi,0x10(%r14)
  77b338:	mov    %rcx,0x18(%r14)
  77b33c:	mov    %rax,0x20(%r14)
  77b340:	mov    %rdi,0x28(%r14)
  77b344:	movb   $0x1,0x30(%r14)
  77b349:	movq   $0xfffffffffffffffe,(%r14)
  77b350:	add    $0xa0,%rsp
  77b357:	pop    %rbx
  77b358:	pop    %r12
  77b35a:	pop    %r13
  77b35c:	pop    %r14
  77b35e:	pop    %r15
  77b360:	ret
  77b361:	lea    0x31db48(%rip),%rdx        # a98eb0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x778>
  77b368:	mov    %rsi,%rdi
  77b36b:	mov    %rax,%rsi
  77b36e:	call   *0x33db5c(%rip)        # ab8ed0 <_DYNAMIC+0x270>
  77b374:	mov    %rax,%r14
  77b377:	mov    $0x108,%esi
  77b37c:	mov    $0x8,%edx
  77b381:	mov    %r12,%rdi
  77b384:	call   *0x33db16(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  77b38a:	movq   $0x0,0x650(%rbx)
  77b395:	mov    %r14,%rdi
  77b398:	call   a97380 <_Unwind_Resume@plt>
  77b39d:	mov    %rax,%r14
  77b3a0:	mov    0x650(%rbx),%rax
  77b3a7:	movq   $0x0,0x100(%rax)
  77b3b2:	mov    %r14,%rdi
  77b3b5:	call   a97380 <_Unwind_Resume@plt>
  77b3ba:	movq   $0x0,0x6e8(%rbx)
  77b3c5:	mov    %rax,%rdi
  77b3c8:	call   a97380 <_Unwind_Resume@plt>
  77b3cd:	mov    %rax,%r14
  77b3d0:	mov    0x650(%rbx),%rax
  77b3d7:	mov    %r12,(%rax)
  77b3da:	movaps 0x40(%rsp),%xmm0
  77b3df:	movaps 0x50(%rsp),%xmm1
  77b3e4:	movaps 0x60(%rsp),%xmm2
  77b3e9:	movaps 0x70(%rsp),%xmm3
  77b3ee:	movups %xmm0,0x8(%rax)
  77b3f2:	movups %xmm1,0x18(%rax)
  77b3f6:	movups %xmm2,0x28(%rax)
  77b3fa:	movups %xmm3,0x38(%rax)
  77b3fe:	movaps 0x80(%rsp),%xmm0
  77b406:	movups %xmm0,0x48(%rax)
  77b40a:	mov    0x90(%rsp),%rcx
  77b412:	mov    %rcx,0x58(%rax)
  77b416:	mov    %r14,%rdi
  77b419:	call   a97380 <_Unwind_Resume@plt>
  77b41e:	mov    %rax,%r14
  77b421:	mov    0x20(%rsp),%rax
  77b426:	mov    %rax,0x10(%r12)
  77b42b:	movaps 0x10(%rsp),%xmm0
  77b430:	movups %xmm0,(%r12)
  77b435:	mov    %r14,%rdi
  77b438:	call   a97380 <_Unwind_Resume@plt>

<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::present_inner bytes=22621 frame=3768

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000077b440 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_>:
  77b440:	push   %rbp
  77b441:	push   %r15
  77b443:	push   %r14
  77b445:	push   %r13
  77b447:	push   %r12
  77b449:	push   %rbx
  77b44a:	sub    $0xe88,%rsp
  77b451:	mov    %rdi,0x48(%rsp)
  77b456:	mov    0x5f8(%rsi),%rax
  77b45d:	mov    %rax,0x260(%rsp)
  77b465:	inc    %rax
  77b468:	je     77fe2a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x49ea>
  77b46e:	mov    %rsi,%r13
  77b471:	mov    %rax,0x8b0(%rsp)
  77b479:	mov    0x5f0(%rsi),%rax
  77b480:	mov    %rax,0x680(%rsp)
  77b488:	mov    0x6c8(%rsi),%rsi
  77b48f:	mov    %rsi,%r14
  77b492:	shr    $0x20,%r14
  77b496:	movss  0x760(%r13),%xmm0
  77b49f:	movss  %xmm0,0x9c(%rsp)
  77b4a8:	mov    0x1a8(%r13),%eax
  77b4af:	mov    0x1b0(%r13),%rcx
  77b4b6:	shl    $0x20,%rcx
  77b4ba:	or     %rax,%rcx
  77b4bd:	cmp    %rcx,%rsi
  77b4c0:	jne    77b4e8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xa8>
  77b4c2:	mov    %rsi,%r15
  77b4c5:	movq   $0x2,0xca0(%rsp)
  77b4d1:	mov    $0x2,%ebx
  77b4d6:	cmp    $0xffff,%r15d
  77b4dd:	jbe    77b58a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x14a>
  77b4e3:	jmp    77b59b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x15b>
  77b4e8:	movups 0x138(%r13),%xmm0
  77b4f0:	movaps %xmm0,0x970(%rsp)
  77b4f8:	lea    0x390(%rsp),%rdi
  77b500:	lea    0x970(%rsp),%rcx
  77b508:	mov    %rsi,%r15
  77b50b:	mov    %r14,%r12
  77b50e:	mov    %r14d,%edx
  77b511:	call   *0x33dc99(%rip)        # ab91b0 <_DYNAMIC+0x550>
  77b517:	mov    0x390(%rsp),%rbx
  77b51f:	mov    0x398(%rsp),%r14d
  77b527:	mov    0x39c(%rsp),%ebp
  77b52e:	cmp    $0x2,%rbx
  77b532:	jne    77b54c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x10c>
  77b534:	mov    0x48(%rsp),%rax
  77b539:	movq   $0x23,(%rax)
  77b540:	mov    %r14d,0x8(%rax)
  77b544:	mov    %ebp,0xc(%rax)
  77b547:	jmp    77cc81 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1841>
  77b54c:	lea    0x3a0(%rsp),%rsi
  77b554:	lea    0xcb0(%rsp),%rdi
  77b55c:	mov    $0x1d8,%edx
  77b561:	call   *0x33d959(%rip)        # ab8ec0 <memcpy@GLIBC_2.14>
  77b567:	mov    %rbx,0xca0(%rsp)
  77b56f:	mov    %r14d,0xca8(%rsp)
  77b577:	mov    %ebp,0xcac(%rsp)
  77b57e:	mov    %r12,%r14
  77b581:	cmp    $0xffff,%r15d
  77b588:	ja     77b59b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x15b>
  77b58a:	mov    %r15,0xf8(%rsp)
  77b592:	mov    %r15,%rax
  77b595:	shr    $0x30,%rax
  77b599:	je     77b5bc <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17c>
  77b59b:	mov    0x48(%rsp),%rax
  77b5a0:	movq   $0x23,(%rax)
  77b5a7:	movl   $0x0,0x8(%rax)
  77b5ae:	cmp    $0x2,%ebx
  77b5b1:	jne    77cc74 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1834>
  77b5b7:	jmp    77cc81 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1841>
  77b5bc:	cmpq   $0x0,0x2f8(%r13)
  77b5c4:	mov    %r13,0x40(%rsp)
  77b5c9:	je     77b5de <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x19e>
  77b5cb:	mov    0x6e8(%r13),%rax
  77b5d2:	test   %rax,%rax
  77b5d5:	je     77b5f3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1b3>
  77b5d7:	cmpq   $0x0,0x30(%rax)
  77b5dc:	je     77b640 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x200>
  77b5de:	mov    0x6e8(%r13),%rax
  77b5e5:	test   %rax,%rax
  77b5e8:	jne    77b735 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2f5>
  77b5ee:	jmp    77b792 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x352>
  77b5f3:	call   *0x33d8af(%rip)        # ab8ea8 <_DYNAMIC+0x248>
  77b5f9:	mov    $0x78,%edi
  77b5fe:	mov    $0x8,%esi
  77b603:	call   *0x33d8a7(%rip)        # ab8eb0 <_DYNAMIC+0x250>
  77b609:	test   %rax,%rax
  77b60c:	je     780247 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4e07>
  77b612:	movq   $0x0,(%rax)
  77b619:	movq   $0x8,0x8(%rax)
  77b621:	movq   $0x0,0x10(%rax)
  77b629:	movq   $0xffffffffffffffff,0x18(%rax)
  77b631:	movq   $0x0,0x30(%rax)
  77b639:	mov    %rax,0x6e8(%r13)
  77b640:	mov    %r14,%rbx
  77b643:	mov    $0x1,%bpl
  77b646:	lea    0x390(%rsp),%rdi
  77b64e:	call   *0x33dda4(%rip)        # ab93f8 <_DYNAMIC+0x798>
  77b654:	mov    0x390(%rsp),%r12
  77b65c:	mov    0x398(%rsp),%r14d
  77b664:	mov    0x39c(%rsp),%ebp
  77b66b:	test   %r12,%r12
  77b66e:	je     77cb8d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x174d>
  77b674:	mov    0x3d0(%rsp),%rax
  77b67c:	mov    %rax,0x9a0(%rsp)
  77b684:	movups 0x3a0(%rsp),%xmm0
  77b68c:	movups 0x3b0(%rsp),%xmm1
  77b694:	movups 0x3c0(%rsp),%xmm2
  77b69c:	movaps %xmm2,0x990(%rsp)
  77b6a4:	movaps %xmm1,0x980(%rsp)
  77b6ac:	movaps %xmm0,0x970(%rsp)
  77b6b4:	mov    0x6e8(%r13),%r15
  77b6bb:	mov    0x30(%r15),%rax
  77b6bf:	test   %rax,%rax
  77b6c2:	je     77b6e7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2a7>
  77b6c4:	lock decq (%rax)
  77b6c8:	jne    77b6d4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x294>
  77b6ca:	lea    0x30(%r15),%rdi
  77b6ce:	call   *0x33d8bc(%rip)        # ab8f90 <_DYNAMIC+0x330>
  77b6d4:	add    $0x38,%r15
  77b6d8:	mov    %r15,%rdi
  77b6db:	call   74cd00 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text11RasterCacheECs9C2G9YFESsD_29canonical_text_public_control>
  77b6e0:	mov    0x6e8(%r13),%r15
  77b6e7:	mov    %r12,0x30(%r15)
  77b6eb:	mov    %r14d,0x38(%r15)
  77b6ef:	mov    %ebp,0x3c(%r15)
  77b6f3:	movaps 0x970(%rsp),%xmm0
  77b6fb:	movaps 0x980(%rsp),%xmm1
  77b703:	movaps 0x990(%rsp),%xmm2
  77b70b:	movups %xmm0,0x40(%r15)
  77b710:	movups %xmm1,0x50(%r15)
  77b715:	movups %xmm2,0x60(%r15)
  77b71a:	mov    0x9a0(%rsp),%rax
  77b722:	mov    %rax,0x70(%r15)
  77b726:	mov    %rbx,%r14
  77b729:	mov    0x6e8(%r13),%rax
  77b730:	test   %rax,%rax
  77b733:	je     77b792 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x352>
  77b735:	mov    0x30(%rax),%rax
  77b739:	test   %rax,%rax
  77b73c:	je     77b792 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x352>
  77b73e:	lock incq (%rax)
  77b742:	jle    7805c8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  77b748:	mov    %rax,0xd0(%rsp)
  77b750:	movq   $0x0,0x200(%rsp)
  77b75c:	movq   $0x8,0x208(%rsp)
  77b768:	movq   $0x0,0x210(%rsp)
  77b774:	lea    0xd0(%rsp),%rax
  77b77c:	mov    %rax,0x1c0(%rsp)
  77b784:	movq   $0x0,0x1c8(%rsp)
  77b790:	jmp    77b7ce <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x38e>
  77b792:	movq   $0x0,0xd0(%rsp)
  77b79e:	movq   $0x0,0x200(%rsp)
  77b7aa:	movq   $0x8,0x208(%rsp)
  77b7b6:	movq   $0x0,0x210(%rsp)
  77b7c2:	movq   $0x0,0x1c0(%rsp)
  77b7ce:	lea    0x778(%rsp),%rdi
  77b7d6:	mov    %r13,%rsi
  77b7d9:	call   76aa00 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE16active_selectionBY_>
  77b7de:	lea    0x390(%rsp),%rdi
  77b7e6:	mov    %r13,%rsi
  77b7e9:	call   76aa00 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE16active_selectionBY_>
  77b7ee:	movzbl 0x3a4(%rsp),%eax
  77b7f6:	mov    %al,0x57(%rsp)
  77b7fa:	cmp    $0x2,%al
  77b7fc:	je     77b84e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x40e>
  77b7fe:	mov    0x390(%rsp),%rax
  77b806:	mov    %rax,0x678(%rsp)
  77b80e:	test   %rax,%rax
  77b811:	je     780229 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4de9>
  77b817:	mov    0x3a0(%rsp),%eax
  77b81e:	mov    %eax,0x2f0(%rsp)
  77b825:	mov    0x398(%rsp),%rax
  77b82d:	mov    %rax,0x2e8(%rsp)
  77b835:	movzwl 0x3a5(%rsp),%eax
  77b83d:	mov    %ax,0x7a(%rsp)
  77b842:	movzbl 0x3a7(%rsp),%eax
  77b84a:	mov    %al,0x7c(%rsp)
  77b84e:	lea    0x300(%r13),%rax
  77b855:	mov    %rax,0x58(%rsp)
  77b85a:	cmpb   $0x0,0x768(%r13)
  77b862:	mov    %r14,0x2e0(%rsp)
  77b86a:	jne    77bbb2 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x772>
  77b870:	cmpb   $0x0,0x769(%r13)
  77b878:	jne    77bbb2 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x772>
  77b87e:	cmpb   $0x0,0x590(%r13)
  77b886:	jne    77bbb2 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x772>
  77b88c:	mov    0x658(%r13),%rax
  77b893:	mov    0x668(%r13),%r15
  77b89a:	test   %rax,%rax
  77b89d:	setne  %cl
  77b8a0:	test   %r15,%r15
  77b8a3:	setne  %dl
  77b8a6:	and    %cl,%dl
  77b8a8:	cmp    $0x1,%dl
  77b8ab:	jne    77c114 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xcd4>
  77b8b1:	mov    0x660(%r13),%r14
  77b8b8:	lea    0x1e8(%r13),%rcx
  77b8bf:	mov    %rcx,0x30(%rsp)
  77b8c4:	lea    0x688(%r13),%rcx
  77b8cb:	mov    %rcx,0x38(%rsp)
  77b8d0:	xor    %ebx,%ebx
  77b8d2:	lea    0x31ea07(%rip),%rcx        # a9a2e0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1ba8>
  77b8d9:	mov    %rcx,0x80(%rsp)
  77b8e1:	jmp    77b910 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4d0>
  77b8e3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  77b8f0:	mov    0x38(%rsp),%rdi
  77b8f5:	mov    %rbp,%rsi
  77b8f8:	call   77a3c0 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapyNtNtB7_7set_val9SetValZSTE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  77b8fd:	mov    $0x0,%eax
  77b902:	dec    %r15
  77b905:	mov    0x40(%rsp),%r13
  77b90a:	je     77c114 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xcd4>
  77b910:	test   %rbx,%rbx
  77b913:	je     77b930 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4f0>
  77b915:	movzwl 0x58a(%rbx),%ecx
  77b91c:	cmp    %rcx,%r14
  77b91f:	jae    77b9e0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5a0>
  77b925:	mov    %rbx,%rcx
  77b928:	mov    %r14,%rdx
  77b92b:	jmp    77ba06 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5c6>
  77b930:	test   %r14,%r14
  77b933:	je     77b96d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x52d>
  77b935:	mov    %r14,%rcx
  77b938:	mov    %rax,%rbx
  77b93b:	and    $0x7,%rcx
  77b93f:	je     77b972 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x532>
  77b941:	xor    %edx,%edx
  77b943:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  77b950:	mov    0x590(%rbx),%rbx
  77b957:	inc    %rdx
  77b95a:	cmp    %rdx,%rcx
  77b95d:	jne    77b950 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x510>
  77b95f:	mov    %r14,%rax
  77b962:	sub    %rdx,%rax
  77b965:	cmp    $0x8,%r14
  77b969:	jae    77b980 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x540>
  77b96b:	jmp    77b9be <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57e>
  77b96d:	mov    %rax,%rbx
  77b970:	jmp    77b9be <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57e>
  77b972:	mov    %r14,%rax
  77b975:	cmp    $0x8,%r14
  77b979:	jb     77b9be <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57e>
  77b97b:	nopl   0x0(%rax,%rax,1)
  77b980:	mov    0x590(%rbx),%rcx
  77b987:	mov    0x590(%rcx),%rcx
  77b98e:	mov    0x590(%rcx),%rcx
  77b995:	mov    0x590(%rcx),%rcx
  77b99c:	mov    0x590(%rcx),%rcx
  77b9a3:	mov    0x590(%rcx),%rcx
  77b9aa:	mov    0x590(%rcx),%rcx
  77b9b1:	mov    0x590(%rcx),%rbx
  77b9b8:	add    $0xfffffffffffffff8,%rax
  77b9bc:	jne    77b980 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x540>
  77b9be:	xor    %eax,%eax
  77b9c0:	xor    %r14d,%r14d
  77b9c3:	movzwl 0x58a(%rbx),%ecx
  77b9ca:	cmp    %rcx,%r14
  77b9cd:	jb     77b925 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4e5>
  77b9d3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  77b9e0:	mov    0x580(%rbx),%rcx
  77b9e7:	test   %rcx,%rcx
  77b9ea:	je     78025f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4e1f>
  77b9f0:	inc    %rax
  77b9f3:	movzwl 0x588(%rbx),%edx
  77b9fa:	mov    %rcx,%rbx
  77b9fd:	cmp    0x58a(%rcx),%dx
  77ba04:	jae    77b9e0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5a0>
  77ba06:	test   %rax,%rax
  77ba09:	je     77baa0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x660>
  77ba0f:	lea    (%rcx,%rdx,8),%rsi
  77ba13:	add    $0x598,%rsi
  77ba1a:	mov    %rax,%rdi
  77ba1d:	and    $0x7,%rdi
  77ba21:	je     77bba0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x760>
  77ba27:	xor    %r8d,%r8d
  77ba2a:	nopw   0x0(%rax,%rax,1)
  77ba30:	mov    (%rsi),%rbx
  77ba33:	lea    0x590(%rbx),%rsi
  77ba3a:	inc    %r8
  77ba3d:	cmp    %r8,%rdi
  77ba40:	jne    77ba30 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5f0>
  77ba42:	mov    %rax,%rdi
  77ba45:	sub    %r8,%rdi
  77ba48:	cmp    $0x8,%rax
  77ba4c:	jb     77ba91 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x651>
  77ba4e:	xchg   %ax,%ax
  77ba50:	mov    (%rsi),%rax
  77ba53:	mov    0x590(%rax),%rax
  77ba5a:	mov    0x590(%rax),%rax
  77ba61:	mov    0x590(%rax),%rax
  77ba68:	mov    0x590(%rax),%rax
  77ba6f:	mov    0x590(%rax),%rax
  77ba76:	mov    0x590(%rax),%rax
  77ba7d:	mov    0x590(%rax),%rbx
  77ba84:	lea    0x590(%rbx),%rsi
  77ba8b:	add    $0xfffffffffffffff8,%rdi
  77ba8f:	jne    77ba50 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x610>
  77ba91:	xor    %r14d,%r14d
  77ba94:	jmp    77baa7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x667>
  77ba96:	cs nopw 0x0(%rax,%rax,1)
  77baa0:	lea    0x1(%rdx),%r14
  77baa4:	mov    %rcx,%rbx
  77baa7:	imul   $0x70,%rdx,%rax
  77baab:	shl    $0x4,%rdx
  77baaf:	lea    (%rcx,%rax,1),%rdi
  77bab3:	add    $0xb0,%rdi
  77baba:	mov    (%rcx,%rdx,1),%rsi
  77babe:	mov    0x8(%rcx,%rdx,1),%rdx
  77bac3:	call   *0x33d56f(%rip)        # ab9038 <_DYNAMIC+0x3d8>
  77bac9:	mov    %rax,%rbp
  77bacc:	mov    0x30(%rsp),%rdi
  77bad1:	mov    %rax,%rsi
  77bad4:	call   775470 <_RNvMs_NtNtCslbxve4rcJus_4gpui7runtime14identity_indexNtB4_13IdentityIndex8required>
  77bad9:	mov    %rax,%r12
  77badc:	mov    0x40(%rsp),%rax
  77bae1:	mov    0x2e0(%rax),%r13
  77bae8:	cmp    %r13,%r12
  77baeb:	jae    780457 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5017>
  77baf1:	mov    0x2d8(%rax),%rcx
  77baf8:	lea    (%r12,%r12,4),%rax
  77bafc:	mov    0x18(%rcx,%rax,8),%r12d
  77bb01:	mov    $0xffffffff,%eax
  77bb06:	cmp    %rax,%r12
  77bb09:	je     77b8fd <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4bd>
  77bb0f:	cmp    %r12,%r13
  77bb12:	jbe    7803b9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4f79>
  77bb18:	mov    0x38(%rsp),%rax
  77bb1d:	mov    (%rax),%rax
  77bb20:	test   %rax,%rax
  77bb23:	je     77b8fd <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4bd>
  77bb29:	lea    (%r12,%r12,4),%rdx
  77bb2d:	mov    (%rcx,%rdx,8),%rcx
  77bb31:	mov    0x40(%rsp),%rdx
  77bb36:	mov    0x690(%rdx),%rdx
  77bb3d:	movzwl 0x62(%rax),%edi
  77bb41:	mov    %edi,%r8d
  77bb44:	shl    $0x3,%r8d
  77bb48:	mov    $0xffffffffffffffff,%rsi
  77bb4f:	nop
  77bb50:	test   %r8,%r8
  77bb53:	je     77bb80 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x740>
  77bb55:	cmp    0x10(%rax,%rsi,8),%rcx
  77bb5a:	seta   %r9b
  77bb5e:	sbb    $0x0,%r9b
  77bb62:	inc    %rsi
  77bb65:	add    $0xfffffffffffffff8,%r8
  77bb69:	cmp    $0x1,%r9b
  77bb6d:	je     77bb50 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x710>
  77bb6f:	movzbl %r9b,%edi
  77bb73:	test   %edi,%edi
  77bb75:	je     77b8f0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4b0>
  77bb7b:	jmp    77bb83 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x743>
  77bb7d:	nopl   (%rax)
  77bb80:	mov    %rdi,%rsi
  77bb83:	sub    $0x1,%rdx
  77bb87:	jb     77b8fd <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4bd>
  77bb8d:	mov    0x68(%rax,%rsi,8),%rax
  77bb92:	jmp    77bb3d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x6fd>
  77bb94:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  77bba0:	mov    %rax,%rdi
  77bba3:	cmp    $0x8,%rax
  77bba7:	jae    77ba50 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x610>
  77bbad:	jmp    77ba91 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x651>
  77bbb2:	lea    0x390(%rsp),%rdi
  77bbba:	call   *0x33d600(%rip)        # ab91c0 <_DYNAMIC+0x560>
  77bbc0:	lea    0x300(%r13),%r14
  77bbc7:	mov    %r14,%rdi
  77bbca:	call   74c280 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscO85OU7Wpt0_20gpui_reactivity_core6layout10LayoutTreeECs9C2G9YFESsD_29canonical_text_public_control>
  77bbcf:	lea    0x390(%rsp),%rsi
  77bbd7:	mov    $0x298,%edx
  77bbdc:	mov    %r14,%rdi
  77bbdf:	call   *0x33d2db(%rip)        # ab8ec0 <memcpy@GLIBC_2.14>
  77bbe5:	movq   $0x0,0x5a8(%r13)
  77bbf0:	mov    0x2e0(%r13),%rax
  77bbf7:	test   %rax,%rax
  77bbfa:	je     77c6e6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x12a6>
  77bc00:	mov    0x40(%rsp),%rcx
  77bc05:	lea    0x598(%rcx),%rdx
  77bc0c:	mov    %rdx,0x38(%rsp)
  77bc11:	mov    0x2d8(%rcx),%rbx
  77bc18:	lea    (%rax,%rax,4),%rax
  77bc1c:	lea    (%rbx,%rax,8),%rax
  77bc20:	mov    %rax,0x30(%rsp)
  77bc25:	xor    %r13d,%r13d
  77bc28:	lea    -0x6b7b7b(%rip),%r14        # c40b4 <GCC_except_table0+0x1d4c>
  77bc2f:	lea    0x31d3ca(%rip),%rax        # a99000 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x8c8>
  77bc36:	mov    %rax,0x80(%rsp)
  77bc3e:	xor    %ebp,%ebp
  77bc40:	jmp    77bc8b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x84b>
  77bc42:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  77bc50:	add    $0x28,%rbx
  77bc54:	inc    %rbp
  77bc57:	mov    0x40(%rsp),%rdx
  77bc5c:	mov    0x5a0(%rdx),%rax
  77bc63:	mov    %r13,%rcx
  77bc66:	shl    $0x4,%rcx
  77bc6a:	movaps 0x950(%rsp),%xmm0
  77bc72:	movups %xmm0,(%rax,%rcx,1)
  77bc76:	inc    %r13
  77bc79:	mov    %r13,0x5a8(%rdx)
  77bc80:	cmp    0x30(%rsp),%rbx
  77bc85:	je     77c6e6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x12a6>
  77bc8b:	mov    0x18(%rbx),%r12d
  77bc8f:	mov    $0xffffffff,%eax
  77bc94:	cmp    %rax,%r12
  77bc97:	je     77bcd0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x890>
  77bc99:	cmp    %r12,%r13
  77bc9c:	jbe    780457 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5017>
  77bca2:	mov    0x40(%rsp),%rax
  77bca7:	mov    0x5a0(%rax),%rax
  77bcae:	mov    %r12,%rcx
  77bcb1:	shl    $0x4,%rcx
  77bcb5:	movups (%rax,%rcx,1),%xmm0
  77bcb9:	lea    0xc68(%rsp),%rax
  77bcc1:	movups %xmm0,(%rax)
  77bcc4:	mov    $0x1,%eax
  77bcc9:	jmp    77bcd2 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x892>
  77bccb:	nopl   0x0(%rax,%rax,1)
  77bcd0:	xor    %eax,%eax
  77bcd2:	mov    %rax,0xc60(%rsp)
  77bcda:	mov    0x20(%rbx),%eax
  77bcdd:	and    $0xf,%eax
  77bce0:	cmp    $0xa,%eax
  77bce3:	jae    78020b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4dcb>
  77bce9:	lea    -0x6a8bcf(%rip),%rcx        # d3121 <GCC_except_table0+0x10db9>
  77bcf0:	movzbl (%rax,%rcx,1),%r15d
  77bcf5:	mov    0x40(%rsp),%rcx
  77bcfa:	mov    0x200(%rcx),%rax
  77bd01:	movslq (%r14,%rax,4),%rax
  77bd05:	add    %r14,%rax
  77bd08:	jmp    *%rax
  77bd0a:	movups -0x6b78f5(%rip),%xmm0        # c441c <GCC_except_table0+0x20b4>
  77bd11:	movaps %xmm0,0x9b0(%rsp)
  77bd19:	movups -0x6b7914(%rip),%xmm0        # c440c <GCC_except_table0+0x20a4>
  77bd20:	movaps %xmm0,0x9a0(%rsp)
  77bd28:	movups -0x6b7933(%rip),%xmm0        # c43fc <GCC_except_table0+0x2094>
  77bd2f:	movaps %xmm0,0x990(%rsp)
  77bd37:	movups -0x6b7952(%rip),%xmm0        # c43ec <GCC_except_table0+0x2084>
  77bd3e:	movaps %xmm0,0x980(%rsp)
  77bd46:	movups -0x6b7971(%rip),%xmm0        # c43dc <GCC_except_table0+0x2074>
  77bd4d:	movaps %xmm0,0x970(%rsp)
  77bd55:	movabs $0x3000100000000,%rax
  77bd5f:	mov    %rax,0x9c0(%rsp)
  77bd67:	cmp    $0xffffffff,%r12d
  77bd6b:	jne    77be01 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x9c1>
  77bd71:	jmp    77beb8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xa78>
  77bd76:	mov    0x220(%rcx),%r13
  77bd7d:	cmp    %r13,%rbp
  77bd80:	jae    78040d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4fcd>
  77bd86:	mov    0x210(%rcx),%r13
  77bd8d:	mov    0x218(%rcx),%rax
  77bd94:	movzbl (%rax,%rbp,1),%eax
  77bd98:	cmp    %rax,%r13
  77bd9b:	jbe    780419 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4fd9>
  77bda1:	mov    0x208(%rcx),%rcx
  77bda8:	imul   $0x58,%rax,%rax
  77bdac:	mov    0x50(%rcx,%rax,1),%rdx
  77bdb1:	mov    %rdx,0x9c0(%rsp)
  77bdb9:	movups 0x40(%rcx,%rax,1),%xmm0
  77bdbe:	movaps %xmm0,0x9b0(%rsp)
  77bdc6:	movups (%rcx,%rax,1),%xmm0
  77bdca:	movups 0x10(%rcx,%rax,1),%xmm1
  77bdcf:	movups 0x20(%rcx,%rax,1),%xmm2
  77bdd4:	movupd 0x30(%rcx,%rax,1),%xmm3
  77bdda:	jmp    77be8d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xa4d>
  77bddf:	mov    0x208(%rcx),%rsi
  77bde6:	lea    0x970(%rsp),%rdi
  77bdee:	mov    %rbp,%rdx
  77bdf1:	call   *0x33d259(%rip)        # ab9050 <_DYNAMIC+0x3f0>
  77bdf7:	cmp    $0xffffffff,%r12d
  77bdfb:	je     77beb8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xa78>
  77be01:	mov    0x40(%rsp),%rdx
  77be06:	mov    0x200(%rdx),%rax
  77be0d:	lea    -0x6b7d50(%rip),%rsi        # c40c4 <GCC_except_table0+0x1d5c>
  77be14:	movslq (%rsi,%rax,4),%rcx
  77be18:	add    %rsi,%rcx
  77be1b:	lea    -0x6b7a46(%rip),%rax        # c43dc <GCC_except_table0+0x2074>
  77be22:	jmp    *%rcx
  77be24:	mov    0x218(%rdx),%r13
  77be2b:	cmp    %r12,%r13
  77be2e:	jbe    780404 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4fc4>
  77be34:	imul   $0x58,%r12,%rax
  77be38:	add    0x210(%rdx),%rax
  77be3f:	jmp    77bf0e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xace>
  77be44:	mov    0x218(%rcx),%r13
  77be4b:	cmp    %r13,%rbp
  77be4e:	jae    78041e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4fde>
  77be54:	mov    0x210(%rcx),%rax
  77be5b:	imul   $0x58,%rbp,%rcx
  77be5f:	mov    0x50(%rax,%rcx,1),%rdx
  77be64:	mov    %rdx,0x9c0(%rsp)
  77be6c:	movups 0x40(%rax,%rcx,1),%xmm0
  77be71:	movaps %xmm0,0x9b0(%rsp)
  77be79:	movups (%rax,%rcx,1),%xmm0
  77be7d:	movups 0x10(%rax,%rcx,1),%xmm1
  77be82:	movups 0x20(%rax,%rcx,1),%xmm2
  77be87:	movupd 0x30(%rax,%rcx,1),%xmm3
  77be8d:	movapd %xmm3,0x9a0(%rsp)
  77be96:	movaps %xmm2,0x990(%rsp)
  77be9e:	movaps %xmm1,0x980(%rsp)
  77bea6:	movaps %xmm0,0x970(%rsp)
  77beae:	cmp    $0xffffffff,%r12d
  77beb2:	jne    77be01 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x9c1>
  77beb8:	mov    $0x2,%al
  77beba:	mov    0x40(%rsp),%rdx
  77bebf:	mov    0x670(%rdx),%r8
  77bec6:	test   %r8,%r8
  77bec9:	jne    77bf8e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xb4e>
  77becf:	jmp    77c020 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xbe0>
  77bed4:	mov    0x220(%rdx),%r13
  77bedb:	cmp    %r12,%r13
  77bede:	jbe    7803fb <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4fbb>
  77bee4:	mov    %rdx,%rcx
  77bee7:	mov    0x210(%rdx),%r13
  77beee:	mov    0x218(%rdx),%rax
  77bef5:	movzbl (%rax,%r12,1),%r12d
  77befa:	cmp    %r12,%r13
  77befd:	jbe    780448 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5008>
  77bf03:	imul   $0x58,%r12,%rax
  77bf07:	add    0x208(%rcx),%rax
  77bf0e:	mov    0x50(%rax),%rcx
  77bf12:	mov    %rcx,0x3e0(%rsp)
  77bf1a:	movups 0x40(%rax),%xmm0
  77bf1e:	movaps %xmm0,0x3d0(%rsp)
  77bf26:	movups (%rax),%xmm0
  77bf29:	movups 0x10(%rax),%xmm1
  77bf2d:	movups 0x20(%rax),%xmm2
  77bf31:	movupd 0x30(%rax),%xmm3
  77bf36:	movapd %xmm3,0x3c0(%rsp)
  77bf3f:	movaps %xmm2,0x3b0(%rsp)
  77bf47:	movaps %xmm1,0x3a0(%rsp)
  77bf4f:	movaps %xmm0,0x390(%rsp)
  77bf57:	jmp    77bf71 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xb31>
  77bf59:	mov    0x208(%rdx),%rsi
  77bf60:	lea    0x390(%rsp),%rdi
  77bf68:	mov    %r12,%rdx
  77bf6b:	call   *0x33d0df(%rip)        # ab9050 <_DYNAMIC+0x3f0>
  77bf71:	movzbl 0x3e4(%rsp),%eax
  77bf79:	mov    0x40(%rsp),%rdx
  77bf7e:	mov    0x670(%rdx),%r8
  77bf85:	test   %r8,%r8
  77bf88:	je     77c020 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xbe0>
  77bf8e:	mov    (%rbx),%rcx
  77bf91:	mov    0x678(%rdx),%rdx
  77bf98:	movzwl 0x1c2(%r8),%edi
  77bfa0:	mov    %edi,%r10d
  77bfa3:	shl    $0x5,%r10d
  77bfa7:	mov    $0xffffffffffffffff,%rsi
  77bfae:	xor    %r9d,%r9d
  77bfb1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  77bfc0:	mov    %r10,%r11
  77bfc3:	add    %r9,%r11
  77bfc6:	je     77bff0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xbb0>
  77bfc8:	cmp    0x170(%r8,%rsi,8),%rcx
  77bfd0:	seta   %r11b
  77bfd4:	sbb    $0x0,%r11b
  77bfd8:	add    $0xffffffffffffffe0,%r9
  77bfdc:	inc    %rsi
  77bfdf:	cmp    $0x1,%r11b
  77bfe3:	je     77bfc0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xb80>
  77bfe5:	movzbl %r11b,%edi
  77bfe9:	test   %edi,%edi
  77bfeb:	jne    77bff3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xbb3>
  77bfed:	jmp    77c010 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xbd0>
  77bfef:	nop
  77bff0:	mov    %rdi,%rsi
  77bff3:	sub    $0x1,%rdx
  77bff7:	jb     77c020 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xbe0>
  77bff9:	mov    0x1c8(%r8,%rsi,8),%r8
  77c001:	jmp    77bf98 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xb58>
  77c003:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  77c010:	sub    %r9,%r8
  77c013:	add    $0xffffffffffffffe0,%r8
  77c017:	jmp    77c023 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xbe3>
  77c019:	nopl   0x0(%rax)
  77c020:	xor    %r8d,%r8d
  77c023:	movzbl %r15b,%esi
  77c027:	movzbl %al,%ecx
  77c02a:	lea    0x390(%rsp),%rdi
  77c032:	lea    0x970(%rsp),%rdx
  77c03a:	call   *0x33d3c0(%rip)        # ab9400 <_DYNAMIC+0x7a0>
  77c040:	lea    0x810(%rsp),%rdi
  77c048:	mov    0x58(%rsp),%rsi
  77c04d:	lea    0xc60(%rsp),%rdx
  77c055:	xor    %ecx,%ecx
  77c057:	lea    0x390(%rsp),%r8
  77c05f:	call   *0x33d3a3(%rip)        # ab9408 <_DYNAMIC+0x7a8>
  77c065:	cmpb   $0x0,0x810(%rsp)
  77c06d:	jne    77cbfd <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17bd>
  77c073:	lea    0x818(%rsp),%rax
  77c07b:	movups (%rax),%xmm0
  77c07e:	lea    0x316(%rsp),%rax
  77c086:	movups %xmm0,(%rax)
  77c089:	movups (%rax),%xmm0
  77c08c:	movaps %xmm0,0x950(%rsp)
  77c094:	mov    0x20(%rbx),%ecx
  77c097:	mov    %ecx,%eax
  77c099:	and    $0xf,%eax
  77c09c:	cmp    $0x9,%eax
  77c09f:	ja     78020b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4dcb>
  77c0a5:	cmp    $0x6,%eax
  77c0a8:	je     77c0ba <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xc7a>
  77c0aa:	cmp    $0x10,%ecx
  77c0ad:	setae  %cl
  77c0b0:	cmp    $0x6,%eax
  77c0b3:	sete   %al
  77c0b6:	or     %cl,%al
  77c0b8:	je     77c0ec <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xcac>
  77c0ba:	movaps 0x950(%rsp),%xmm0
  77c0c2:	movaps %xmm0,0x390(%rsp)
  77c0ca:	mov    0x58(%rsp),%rdi
  77c0cf:	lea    0x390(%rsp),%rsi
  77c0d7:	mov    0x33d332(%rip),%rdx        # ab9410 <_DYNAMIC+0x7b0>
  77c0de:	call   *0x33d334(%rip)        # ab9418 <_DYNAMIC+0x7b8>
  77c0e4:	test   $0x1,%al
  77c0e6:	jne    77cbec <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17ac>
  77c0ec:	mov    0x40(%rsp),%rax
  77c0f1:	mov    0x5a8(%rax),%r13
  77c0f8:	cmp    0x598(%rax),%r13
  77c0ff:	jne    77bc50 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x810>
  77c105:	mov    0x38(%rsp),%rdi
  77c10a:	call   771bd0 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecAINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtCslbxve4rcJus_4gpui6source7FieldIdEj2_E8grow_oneCs9C2G9YFESsD_29canonical_text_public_control>
  77c10f:	jmp    77bc50 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x810>
  77c114:	mov    0x688(%r13),%rax
  77c11b:	mov    0x698(%r13),%rdi
  77c122:	test   %rax,%rax
  77c125:	setne  %cl
  77c128:	test   %rdi,%rdi
  77c12b:	setne  %dl
  77c12e:	and    %cl,%dl
  77c130:	cmp    $0x1,%dl
  77c133:	jne    77c6e6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x12a6>
  77c139:	mov    0x40(%rsp),%rcx
  77c13e:	mov    0x690(%rcx),%rbx
  77c145:	add    $0x1e8,%rcx
  77c14c:	mov    %rcx,0xc0(%rsp)
  77c154:	xor    %ebp,%ebp
  77c156:	lea    0x31e13b(%rip),%rcx        # a9a298 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1b60>
  77c15d:	mov    %rcx,0x80(%rsp)
  77c165:	data16 cs nopw 0x0(%rax,%rax,1)
  77c170:	test   %rbp,%rbp
  77c173:	je     77c18f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xd4f>
  77c175:	mov    0x40(%rsp),%r14
  77c17a:	movzwl 0x62(%rbp),%ecx
  77c17e:	cmp    %rcx,%rbx
  77c181:	jae    77c220 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xde0>
  77c187:	mov    %rbp,%r15
  77c18a:	jmp    77c23e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xdfe>
  77c18f:	test   %rbx,%rbx
  77c192:	mov    0x40(%rsp),%r14
  77c197:	je     77c1ca <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xd8a>
  77c199:	mov    %rbx,%rcx
  77c19c:	mov    %rax,%rbp
  77c19f:	and    $0x7,%rcx
  77c1a3:	je     77c1cf <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xd8f>
  77c1a5:	xor    %edx,%edx
  77c1a7:	nopw   0x0(%rax,%rax,1)
  77c1b0:	mov    0x68(%rbp),%rbp
  77c1b4:	inc    %rdx
  77c1b7:	cmp    %rdx,%rcx
  77c1ba:	jne    77c1b0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xd70>
  77c1bc:	mov    %rbx,%rax
  77c1bf:	sub    %rdx,%rax
  77c1c2:	cmp    $0x8,%rbx
  77c1c6:	jae    77c1e0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xda0>
  77c1c8:	jmp    77c206 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xdc6>
  77c1ca:	mov    %rax,%rbp
  77c1cd:	jmp    77c206 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xdc6>
  77c1cf:	mov    %rbx,%rax
  77c1d2:	cmp    $0x8,%rbx
  77c1d6:	jb     77c206 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xdc6>
  77c1d8:	nopl   0x0(%rax,%rax,1)
  77c1e0:	mov    0x68(%rbp),%rcx
  77c1e4:	mov    0x68(%rcx),%rcx
  77c1e8:	mov    0x68(%rcx),%rcx
  77c1ec:	mov    0x68(%rcx),%rcx
  77c1f0:	mov    0x68(%rcx),%rcx
  77c1f4:	mov    0x68(%rcx),%rcx
  77c1f8:	mov    0x68(%rcx),%rcx
  77c1fc:	mov    0x68(%rcx),%rbp
  77c200:	add    $0xfffffffffffffff8,%rax
  77c204:	jne    77c1e0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xda0>
  77c206:	xor    %eax,%eax
  77c208:	xor    %ebx,%ebx
  77c20a:	movzwl 0x62(%rbp),%ecx
  77c20e:	cmp    %rcx,%rbx
  77c211:	jb     77c187 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xd47>
  77c217:	nopw   0x0(%rax,%rax,1)
  77c220:	mov    0x0(%rbp),%r15
  77c224:	test   %r15,%r15
  77c227:	je     7802ab <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4e6b>
  77c22d:	inc    %rax
  77c230:	movzwl 0x60(%rbp),%ebx
  77c234:	mov    %r15,%rbp
  77c237:	cmp    0x62(%r15),%bx
  77c23c:	jae    77c220 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xde0>
  77c23e:	test   %rax,%rax
  77c241:	mov    %rdi,0x38(%rsp)
  77c246:	je     77c2b7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xe77>
  77c248:	lea    (%r15,%rbx,8),%rcx
  77c24c:	add    $0x70,%rcx
  77c250:	mov    %rax,%rdx
  77c253:	and    $0x7,%rdx
  77c257:	je     77c506 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x10c6>
  77c25d:	xor    %esi,%esi
  77c25f:	nop
  77c260:	mov    (%rcx),%rbp
  77c263:	lea    0x68(%rbp),%rcx
  77c267:	inc    %rsi
  77c26a:	cmp    %rsi,%rdx
  77c26d:	jne    77c260 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xe20>
  77c26f:	mov    %rax,%rdx
  77c272:	sub    %rsi,%rdx
  77c275:	cmp    $0x8,%rax
  77c279:	jb     77c2a9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xe69>
  77c27b:	nopl   0x0(%rax,%rax,1)
  77c280:	mov    (%rcx),%rax
  77c283:	mov    0x68(%rax),%rax
  77c287:	mov    0x68(%rax),%rax
  77c28b:	mov    0x68(%rax),%rax
  77c28f:	mov    0x68(%rax),%rax
  77c293:	mov    0x68(%rax),%rax
  77c297:	mov    0x68(%rax),%rax
  77c29b:	mov    0x68(%rax),%rbp
  77c29f:	lea    0x68(%rbp),%rcx
  77c2a3:	add    $0xfffffffffffffff8,%rdx
  77c2a7:	jne    77c280 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xe40>
  77c2a9:	movq   $0x0,0xa8(%rsp)
  77c2b5:	jmp    77c2c6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xe86>
  77c2b7:	lea    0x1(%rbx),%rax
  77c2bb:	mov    %rax,0xa8(%rsp)
  77c2c3:	mov    %r15,%rbp
  77c2c6:	mov    0x8(%r15,%rbx,8),%rsi
  77c2cb:	mov    0xc0(%rsp),%rdi
  77c2d3:	call   775470 <_RNvMs_NtNtCslbxve4rcJus_4gpui7runtime14identity_indexNtB4_13IdentityIndex8required>
  77c2d8:	mov    %rax,%r12
  77c2db:	mov    0x5a8(%r14),%r13
  77c2e2:	cmp    %r13,%rax
  77c2e5:	jae    780457 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5017>
  77c2eb:	mov    0x5a0(%r14),%rax
  77c2f2:	mov    %r12,%rcx
  77c2f5:	shl    $0x4,%rcx
  77c2f9:	movups (%rax,%rcx,1),%xmm0
  77c2fd:	movaps %xmm0,0x310(%rsp)
  77c305:	mov    0x2e0(%r14),%r13
  77c30c:	cmp    %r13,%r12
  77c30f:	jae    7803e9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4fa9>
  77c315:	mov    0x2d8(%r14),%rax
  77c31c:	lea    (%r12,%r12,4),%rsi
  77c320:	mov    0x20(%rax,%rsi,8),%eax
  77c324:	and    $0xf,%eax
  77c327:	cmp    $0xa,%eax
  77c32a:	jae    78020b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4dcb>
  77c330:	lea    -0x6a9216(%rip),%rcx        # d3121 <GCC_except_table0+0x10db9>
  77c337:	movzbl (%rax,%rcx,1),%eax
  77c33b:	mov    %al,0x30(%rsp)
  77c33f:	mov    0x40(%rsp),%r14
  77c344:	mov    0x200(%r14),%rax
  77c34b:	lea    -0x6b82be(%rip),%rcx        # c4094 <GCC_except_table0+0x1d2c>
  77c352:	movslq (%rcx,%rax,4),%rax
  77c356:	add    %rcx,%rax
  77c359:	jmp    *%rax
  77c35b:	movups -0x6b7f46(%rip),%xmm0        # c441c <GCC_except_table0+0x20b4>
  77c362:	movaps %xmm0,0x9b0(%rsp)
  77c36a:	movups -0x6b7f65(%rip),%xmm0        # c440c <GCC_except_table0+0x20a4>
  77c371:	movaps %xmm0,0x9a0(%rsp)
  77c379:	movups -0x6b7f84(%rip),%xmm0        # c43fc <GCC_except_table0+0x2094>
  77c380:	movaps %xmm0,0x990(%rsp)
  77c388:	movups -0x6b7fa3(%rip),%xmm0        # c43ec <GCC_except_table0+0x2084>
  77c38f:	movaps %xmm0,0x980(%rsp)
  77c397:	movups -0x6b7fc2(%rip),%xmm0        # c43dc <GCC_except_table0+0x2074>
  77c39e:	movaps %xmm0,0x970(%rsp)
  77c3a6:	movabs $0x3000100000000,%rax
  77c3b0:	mov    %rax,0x9c0(%rsp)
  77c3b8:	jmp    77c485 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1045>
  77c3bd:	mov    0x220(%r14),%rax
  77c3c4:	cmp    %rax,%r12
  77c3c7:	jae    780436 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4ff6>
  77c3cd:	mov    0x210(%r14),%rax
  77c3d4:	mov    0x218(%r14),%rcx
  77c3db:	movzbl (%rcx,%r12,1),%ecx
  77c3e0:	cmp    %rcx,%rax
  77c3e3:	jbe    780442 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5002>
  77c3e9:	mov    0x208(%r14),%rax
  77c3f0:	imul   $0x58,%rcx,%rcx
  77c3f4:	jmp    77c436 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xff6>
  77c3f6:	mov    0x208(%r14),%rsi
  77c3fd:	lea    0x970(%rsp),%rdi
  77c405:	mov    %r12,%rdx
  77c408:	call   *0x33cc42(%rip)        # ab9050 <_DYNAMIC+0x3f0>
  77c40e:	mov    0x2e0(%r14),%r13
  77c415:	lea    (%r12,%r12,4),%rsi
  77c419:	jmp    77c485 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1045>
  77c41b:	mov    0x218(%r14),%rax
  77c422:	cmp    %rax,%r12
  77c425:	jae    78042a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4fea>
  77c42b:	mov    0x210(%r14),%rax
  77c432:	imul   $0x58,%r12,%rcx
  77c436:	mov    0x50(%rax,%rcx,1),%rdx
  77c43b:	mov    %rdx,0x9c0(%rsp)
  77c443:	movups 0x40(%rax,%rcx,1),%xmm0
  77c448:	movaps %xmm0,0x9b0(%rsp)
  77c450:	movups (%rax,%rcx,1),%xmm0
  77c454:	movups 0x10(%rax,%rcx,1),%xmm1
  77c459:	movups 0x20(%rax,%rcx,1),%xmm2
  77c45e:	movupd 0x30(%rax,%rcx,1),%xmm3
  77c464:	movapd %xmm3,0x9a0(%rsp)
  77c46d:	movaps %xmm2,0x990(%rsp)
  77c475:	movaps %xmm1,0x980(%rsp)
  77c47d:	movaps %xmm0,0x970(%rsp)
  77c485:	cmp    %r13,%r12
  77c488:	jae    7803f2 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4fb2>
  77c48e:	mov    0x40(%rsp),%r13
  77c493:	mov    0x2d8(%r13),%rax
  77c49a:	mov    0x18(%rax,%rsi,8),%r12d
  77c49f:	mov    $0xffffffff,%eax
  77c4a4:	cmp    %rax,%r12
  77c4a7:	je     77c4e7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x10a7>
  77c4a9:	mov    0x200(%r13),%rax
  77c4b0:	lea    -0x6b8413(%rip),%rdx        # c40a4 <GCC_except_table0+0x1d3c>
  77c4b7:	movslq (%rdx,%rax,4),%rcx
  77c4bb:	add    %rdx,%rcx
  77c4be:	lea    -0x6b80e9(%rip),%rax        # c43dc <GCC_except_table0+0x2074>
  77c4c5:	jmp    *%rcx
  77c4c7:	mov    %r13,%rcx
  77c4ca:	mov    0x218(%r13),%r13
  77c4d1:	cmp    %r12,%r13
  77c4d4:	jbe    780404 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4fc4>
  77c4da:	imul   $0x58,%r12,%rax
  77c4de:	add    0x210(%rcx),%rax
  77c4e5:	jmp    77c552 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1112>
  77c4e7:	mov    $0x2,%al
  77c4e9:	mov    0x670(%r13),%r8
  77c4f0:	test   %r8,%r8
  77c4f3:	jne    77c5d0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1190>
  77c4f9:	xor    %r8d,%r8d
  77c4fc:	movzbl 0x30(%rsp),%ebx
  77c501:	jmp    77c657 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1217>
  77c506:	mov    %rax,%rdx
  77c509:	cmp    $0x8,%rax
  77c50d:	jae    77c280 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xe40>
  77c513:	jmp    77c2a9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xe69>
  77c518:	mov    %r13,%rcx
  77c51b:	mov    0x220(%r13),%r13
  77c522:	cmp    %r12,%r13
  77c525:	jbe    7803fb <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4fbb>
  77c52b:	mov    0x210(%rcx),%r13
  77c532:	mov    0x218(%rcx),%rax
  77c539:	movzbl (%rax,%r12,1),%r12d
  77c53e:	cmp    %r12,%r13
  77c541:	jbe    780448 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5008>
  77c547:	imul   $0x58,%r12,%rax
  77c54b:	add    0x208(%rcx),%rax
  77c552:	mov    %rcx,%r13
  77c555:	mov    0x50(%rax),%rcx
  77c559:	mov    %rcx,0x3e0(%rsp)
  77c561:	movups 0x40(%rax),%xmm0
  77c565:	movaps %xmm0,0x3d0(%rsp)
  77c56d:	movups (%rax),%xmm0
  77c570:	movups 0x10(%rax),%xmm1
  77c574:	movups 0x20(%rax),%xmm2
  77c578:	movupd 0x30(%rax),%xmm3
  77c57d:	movapd %xmm3,0x3c0(%rsp)
  77c586:	movaps %xmm2,0x3b0(%rsp)
  77c58e:	movaps %xmm1,0x3a0(%rsp)
  77c596:	movaps %xmm0,0x390(%rsp)
  77c59e:	jmp    77c5b8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1178>
  77c5a0:	mov    0x208(%r13),%rsi
  77c5a7:	lea    0x390(%rsp),%rdi
  77c5af:	mov    %r12,%rdx
  77c5b2:	call   *0x33ca98(%rip)        # ab9050 <_DYNAMIC+0x3f0>
  77c5b8:	movzbl 0x3e4(%rsp),%eax
  77c5c0:	mov    0x670(%r13),%r8
  77c5c7:	test   %r8,%r8
  77c5ca:	je     77c4f9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x10b9>
  77c5d0:	mov    0x8(%r15,%rbx,8),%rcx
  77c5d5:	mov    0x678(%r13),%rdx
  77c5dc:	movzbl 0x30(%rsp),%ebx
  77c5e1:	movzwl 0x1c2(%r8),%edi
  77c5e9:	mov    %edi,%r10d
  77c5ec:	shl    $0x5,%r10d
  77c5f0:	mov    $0xffffffffffffffff,%rsi
  77c5f7:	xor    %r9d,%r9d
  77c5fa:	nopw   0x0(%rax,%rax,1)
  77c600:	mov    %r10,%r11
  77c603:	add    %r9,%r11
  77c606:	je     77c630 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x11f0>
  77c608:	cmp    0x170(%r8,%rsi,8),%rcx
  77c610:	seta   %r11b
  77c614:	sbb    $0x0,%r11b
  77c618:	add    $0xffffffffffffffe0,%r9
  77c61c:	inc    %rsi
  77c61f:	cmp    $0x1,%r11b
  77c623:	je     77c600 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x11c0>
  77c625:	movzbl %r11b,%edi
  77c629:	test   %edi,%edi
  77c62b:	jne    77c633 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x11f3>
  77c62d:	jmp    77c650 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1210>
  77c62f:	nop
  77c630:	mov    %rdi,%rsi
  77c633:	sub    $0x1,%rdx
  77c637:	jb     77c6de <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x129e>
  77c63d:	mov    0x1c8(%r8,%rsi,8),%r8
  77c645:	jmp    77c5e1 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x11a1>
  77c647:	nopw   0x0(%rax,%rax,1)
  77c650:	sub    %r9,%r8
  77c653:	add    $0xffffffffffffffe0,%r8
  77c657:	movzbl %bl,%esi
  77c65a:	movzbl %al,%ecx
  77c65d:	lea    0x390(%rsp),%rdi
  77c665:	lea    0x970(%rsp),%rdx
  77c66d:	call   *0x33cd8d(%rip)        # ab9400 <_DYNAMIC+0x7a0>
  77c673:	movaps 0x310(%rsp),%xmm0
  77c67b:	movaps %xmm0,0x810(%rsp)
  77c683:	mov    0x58(%rsp),%rdi
  77c688:	lea    0x810(%rsp),%rsi
  77c690:	lea    0x390(%rsp),%rdx
  77c698:	call   *0x33cd82(%rip)        # ab9420 <_DYNAMIC+0x7c0>
  77c69e:	test   $0x1,%al
  77c6a0:	jne    77cbec <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17ac>
  77c6a6:	mov    0x58(%rsp),%rdi
  77c6ab:	lea    0x310(%rsp),%rsi
  77c6b3:	call   *0x33ccbf(%rip)        # ab9378 <_DYNAMIC+0x718>
  77c6b9:	cmp    $0xff,%al
  77c6bb:	jne    77cc05 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17c5>
  77c6c1:	mov    $0x0,%eax
  77c6c6:	mov    0x38(%rsp),%rdi
  77c6cb:	dec    %rdi
  77c6ce:	mov    0xa8(%rsp),%rbx
  77c6d6:	jne    77c170 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xd30>
  77c6dc:	jmp    77c6e6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x12a6>
  77c6de:	xor    %r8d,%r8d
  77c6e1:	jmp    77c657 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1217>
  77c6e6:	mov    0x40(%rsp),%r15
  77c6eb:	lea    0x2e8(%r15),%rax
  77c6f2:	mov    0x558(%r15),%r14
  77c6f9:	mov    0x578(%r15),%rbx
  77c700:	lea    0x598(%r15),%rcx
  77c707:	movq   $0xfffffffffffffffe,0x7c8(%rsp)
  77c713:	lea    0x2d0(%r15),%rdx
  77c71a:	lea    0x200(%r15),%rsi
  77c721:	lea    0x600(%r15),%r13
  77c728:	mov    %rcx,0xbe8(%rsp)
  77c730:	mov    %rdx,0xbf0(%rsp)
  77c738:	mov    %r13,0xbf8(%rsp)
  77c740:	lea    0x1c0(%rsp),%rcx
  77c748:	mov    %rcx,0xc00(%rsp)
  77c750:	mov    %rax,0xc08(%rsp)
  77c758:	mov    %rsi,0xa8(%rsp)
  77c760:	mov    %rsi,0xc10(%rsp)
  77c768:	lea    0x7c8(%rsp),%rax
  77c770:	mov    %rax,0xc18(%rsp)
  77c778:	cmpq   $0x0,0x5a8(%r15)
  77c780:	je     780470 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5030>
  77c786:	mov    0x5a0(%r15),%rax
  77c78d:	movups (%rax),%xmm0
  77c790:	movaps %xmm0,0x970(%rsp)
  77c798:	xorps  %xmm0,%xmm0
  77c79b:	cvtsi2ssl 0xf8(%rsp),%xmm0
  77c7a4:	movaps %xmm0,0xc0(%rsp)
  77c7ac:	cvtsi2ssl 0x2e0(%rsp),%xmm1
  77c7b5:	movss  0x9c(%rsp),%xmm2
  77c7be:	divss  %xmm2,%xmm0
  77c7c2:	movaps %xmm1,0x80(%rsp)
  77c7ca:	divss  %xmm2,%xmm1
  77c7ce:	movl   $0x0,0x390(%rsp)
  77c7d9:	movss  %xmm0,0x394(%rsp)
  77c7e2:	movl   $0x0,0x398(%rsp)
  77c7ed:	movss  %xmm1,0x39c(%rsp)
  77c7f6:	mov    $0x1,%r12b
  77c7f9:	lea    0x31db10(%rip),%r8        # a9a310 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1bd8>
  77c800:	lea    0x970(%rsp),%rsi
  77c808:	lea    0x390(%rsp),%rdx
  77c810:	lea    0xbe8(%rsp),%rcx
  77c818:	mov    $0x1,%bpl
  77c81b:	mov    0x58(%rsp),%rdi
  77c820:	call   *0x33cc02(%rip)        # ab9428 <_DYNAMIC+0x7c8>
  77c826:	test   $0x1,%al
  77c828:	je     77c890 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1450>
  77c82a:	mov    0x48(%rsp),%rax
  77c82f:	movq   $0x22,(%rax)
  77c836:	mov    %dl,0x8(%rax)
  77c839:	mov    0x7c8(%rsp),%rax
  77c841:	mov    $0x1,%r12b
  77c844:	mov    $0x1,%bpl
  77c847:	cmp    $0xfffffffffffffffe,%rax
  77c84b:	je     77cc1a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17da>
  77c851:	sub    $0xd,%rax
  77c855:	mov    $0x14,%ecx
  77c85a:	cmovge %rax,%rcx
  77c85e:	cmp    $0x14,%rcx
  77c862:	je     77cccc <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x188c>
  77c868:	cmp    $0x19,%rcx
  77c86c:	jne    77cc1a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17da>
  77c872:	mov    0x7d0(%rsp),%rsi
  77c87a:	test   %rsi,%rsi
  77c87d:	je     77cc1a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17da>
  77c883:	lea    0x7d8(%rsp),%rax
  77c88b:	jmp    77cce5 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x18a5>
  77c890:	mov    0x558(%r15),%rax
  77c897:	sub    %r14,%rax
  77c89a:	mov    0x578(%r15),%rcx
  77c8a1:	add    %rax,0x728(%r15)
  77c8a8:	sub    %rbx,%rcx
  77c8ab:	add    %rcx,0x730(%r15)
  77c8b2:	cmpl   $0xfffffffe,0x7c8(%rsp)
  77c8ba:	jne    77cbb6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1776>
  77c8c0:	lea    0x390(%rsp),%rdi
  77c8c8:	mov    $0x1,%bpl
  77c8cb:	mov    %r15,%rsi
  77c8ce:	mov    $0x1,%edx
  77c8d3:	call   7706f0 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime9inspectorINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE17refresh_inspectorB10_>
  77c8d8:	cmpl   $0xfffffffe,0x390(%rsp)
  77c8e0:	jne    77cc93 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1853>
  77c8e6:	mov    0x2e0(%r15),%rsi
  77c8ed:	lea    0x390(%rsp),%rdi
  77c8f5:	mov    $0x8,%ecx
  77c8fa:	mov    $0x40,%r8d
  77c900:	xor    %edx,%edx
  77c902:	call   772230 <_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCs9C2G9YFESsD_29canonical_text_public_control>
  77c907:	mov    0x398(%rsp),%rdi
  77c90f:	cmpl   $0x1,0x390(%rsp)
  77c917:	je     7802dd <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4e9d>
  77c91d:	mov    0x3a0(%rsp),%rax
  77c925:	mov    %rdi,0x140(%rsp)
  77c92d:	mov    %rax,0x148(%rsp)
  77c935:	movq   $0x0,0x150(%rsp)
  77c941:	movq   $0x0,0x268(%rsp)
  77c94d:	movq   $0x4,0x270(%rsp)
  77c959:	movq   $0x0,0x278(%rsp)
  77c965:	mov    0x2e0(%r15),%rsi
  77c96c:	lea    0x390(%rsp),%rdi
  77c974:	mov    $0x8,%ecx
  77c979:	mov    $0x38,%r8d
  77c97f:	xor    %edx,%edx
  77c981:	call   772230 <_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCs9C2G9YFESsD_29canonical_text_public_control>
  77c986:	mov    0x398(%rsp),%rdi
  77c98e:	cmpb   $0x0,0x390(%rsp)
  77c996:	jne    7802f3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4eb3>
  77c99c:	mov    0x3a0(%rsp),%rax
  77c9a4:	mov    %rdi,0x1d8(%rsp)
  77c9ac:	mov    %rax,0x1e0(%rsp)
  77c9b4:	movq   $0x0,0x1e8(%rsp)
  77c9c0:	mov    0x668(%r15),%rbx
  77c9c7:	test   %rbx,%rbx
  77c9ca:	setne  0x2f(%rsp)
  77c9cf:	je     77c9d8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1598>
  77c9d1:	mov    0x2e0(%r15),%rbx
  77c9d8:	lea    0x390(%rsp),%rdi
  77c9e0:	mov    $0x4,%ecx
  77c9e5:	mov    $0x10,%r8d
  77c9eb:	mov    %rbx,%rsi
  77c9ee:	xor    %edx,%edx
  77c9f0:	call   772230 <_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCs9C2G9YFESsD_29canonical_text_public_control>
  77c9f5:	mov    0x398(%rsp),%rdi
  77c9fd:	cmpb   $0x0,0x390(%rsp)
  77ca05:	jne    780306 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4ec6>
  77ca0b:	mov    0x3a0(%rsp),%rax
  77ca13:	mov    %rdi,0x218(%rsp)
  77ca1b:	mov    %rax,0x220(%rsp)
  77ca23:	movq   $0x0,0x228(%rsp)
  77ca2f:	lea    0x390(%rsp),%rdi
  77ca37:	mov    $0x4,%ecx
  77ca3c:	mov    $0x10,%r8d
  77ca42:	mov    %rbx,%rsi
  77ca45:	xor    %edx,%edx
  77ca47:	call   772230 <_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCs9C2G9YFESsD_29canonical_text_public_control>
  77ca4c:	mov    0x398(%rsp),%rdi
  77ca54:	cmpb   $0x0,0x390(%rsp)
  77ca5c:	jne    780319 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4ed9>
  77ca62:	mov    0x3a0(%rsp),%rax
  77ca6a:	mov    %rdi,0x230(%rsp)
  77ca72:	mov    %rax,0x238(%rsp)
  77ca7a:	movq   $0x0,0x240(%rsp)
  77ca86:	lea    0x390(%rsp),%rdi
  77ca8e:	mov    $0x1,%ecx
  77ca93:	mov    $0x1,%r8d
  77ca99:	mov    %rbx,%rsi
  77ca9c:	xor    %edx,%edx
  77ca9e:	call   772230 <_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCs9C2G9YFESsD_29canonical_text_public_control>
  77caa3:	mov    0x398(%rsp),%rdi
  77caab:	cmpb   $0x0,0x390(%rsp)
  77cab3:	jne    78032c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4eec>
  77cab9:	mov    0x3a0(%rsp),%rax
  77cac1:	mov    %rdi,0x158(%rsp)
  77cac9:	mov    %rax,0x160(%rsp)
  77cad1:	movq   $0x0,0x168(%rsp)
  77cadd:	lea    0x390(%rsp),%rdi
  77cae5:	mov    $0x4,%ecx
  77caea:	mov    $0x4,%r8d
  77caf0:	mov    %rbx,%rsi
  77caf3:	xor    %edx,%edx
  77caf5:	call   772230 <_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCs9C2G9YFESsD_29canonical_text_public_control>
  77cafa:	mov    0x398(%rsp),%rdi
  77cb02:	cmpb   $0x0,0x390(%rsp)
  77cb0a:	jne    78033f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4eff>
  77cb10:	mov    %r13,0x2d8(%rsp)
  77cb18:	mov    0x3a0(%rsp),%rax
  77cb20:	mov    %rdi,0x100(%rsp)
  77cb28:	mov    %rax,0x108(%rsp)
  77cb30:	movq   $0x0,0x110(%rsp)
  77cb3c:	movq   $0x0,0x6a8(%rsp)
  77cb48:	movq   $0x0,0x6b8(%rsp)
  77cb54:	mov    0x650(%r15),%rcx
  77cb5b:	test   %rcx,%rcx
  77cb5e:	je     77ccf8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x18b8>
  77cb64:	mov    0x2e0(%r15),%rsi
  77cb6b:	mov    0x680(%r15),%rdx
  77cb72:	mov    $0x1,%r12b
  77cb75:	lea    0x810(%rsp),%rdi
  77cb7d:	mov    $0x1,%r13b
  77cb80:	mov    $0x1,%bpl
  77cb83:	call   75cbd0 <_RNCNvMs1_NtNtCslbxve4rcJus_4gpui7runtime8metadataINtB9_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE14metadata_sheet0B11_>
  77cb88:	jmp    77cd04 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x18c4>
  77cb8d:	mov    0x48(%rsp),%rax
  77cb92:	movq   $0x23,(%rax)
  77cb99:	mov    %r14d,0x8(%rax)
  77cb9d:	mov    %ebp,0xc(%rax)
  77cba0:	mov    0xca0(%rsp),%rbx
  77cba8:	cmp    $0x2,%ebx
  77cbab:	jne    77cc74 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1834>
  77cbb1:	jmp    77cc81 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1841>
  77cbb6:	mov    0x7f8(%rsp),%rax
  77cbbe:	mov    0x48(%rsp),%rcx
  77cbc3:	mov    %rax,0x30(%rcx)
  77cbc7:	movups 0x7c8(%rsp),%xmm0
  77cbcf:	movups 0x7d8(%rsp),%xmm1
  77cbd7:	movups 0x7e8(%rsp),%xmm2
  77cbdf:	movups %xmm2,0x20(%rcx)
  77cbe3:	movups %xmm1,0x10(%rcx)
  77cbe7:	movups %xmm0,(%rcx)
  77cbea:	jmp    77cc14 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17d4>
  77cbec:	mov    0x48(%rsp),%rax
  77cbf1:	movq   $0x22,(%rax)
  77cbf8:	mov    %dl,0x8(%rax)
  77cbfb:	jmp    77cc14 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17d4>
  77cbfd:	movzbl 0x811(%rsp),%eax
  77cc05:	mov    0x48(%rsp),%rcx
  77cc0a:	movq   $0x22,(%rcx)
  77cc11:	mov    %al,0x8(%rcx)
  77cc14:	mov    $0x1,%r12b
  77cc17:	mov    $0x1,%bpl
  77cc1a:	cmpq   $0x0,0x1c0(%rsp)
  77cc23:	je     77cc32 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17f2>
  77cc25:	mov    0x1c8(%rsp),%rdi
  77cc2d:	call   74cab0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text10TextShaperECs9C2G9YFESsD_29canonical_text_public_control>
  77cc32:	test   %r12b,%r12b
  77cc35:	je     77cc44 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1804>
  77cc37:	lea    0x200(%rsp),%rdi
  77cc3f:	call   747680 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime13text_geometry5EntryEECs9C2G9YFESsD_29canonical_text_public_control>
  77cc44:	mov    0xd0(%rsp),%rax
  77cc4c:	test   %rax,%rax
  77cc4f:	je     77cc65 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1825>
  77cc51:	lock decq (%rax)
  77cc55:	jne    77cc65 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1825>
  77cc57:	lea    0xd0(%rsp),%rdi
  77cc5f:	call   *0x33c32b(%rip)        # ab8f90 <_DYNAMIC+0x330>
  77cc65:	cmpl   $0x2,0xca0(%rsp)
  77cc6d:	je     77cc81 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1841>
  77cc6f:	test   %bpl,%bpl
  77cc72:	je     77cc81 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1841>
  77cc74:	lea    0xca0(%rsp),%rdi
  77cc7c:	call   74d050 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas6canvas6CanvasECs9C2G9YFESsD_29canonical_text_public_control>
  77cc81:	add    $0xe88,%rsp
  77cc88:	pop    %rbx
  77cc89:	pop    %r12
  77cc8b:	pop    %r13
  77cc8d:	pop    %r14
  77cc8f:	pop    %r15
  77cc91:	pop    %rbp
  77cc92:	ret
  77cc93:	mov    0x3c0(%rsp),%rax
  77cc9b:	mov    0x48(%rsp),%rcx
  77cca0:	mov    %rax,0x30(%rcx)
  77cca4:	movups 0x390(%rsp),%xmm0
  77ccac:	movups 0x3a0(%rsp),%xmm1
  77ccb4:	movups 0x3b0(%rsp),%xmm2
  77ccbc:	movups %xmm2,0x20(%rcx)
  77ccc0:	movups %xmm1,0x10(%rcx)
  77ccc4:	movups %xmm0,(%rcx)
  77ccc7:	jmp    77c839 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x13f9>
  77cccc:	mov    0x7e0(%rsp),%rsi
  77ccd4:	test   %rsi,%rsi
  77ccd7:	je     77cc1a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17da>
  77ccdd:	lea    0x7e8(%rsp),%rax
  77cce5:	mov    (%rax),%rdi
  77cce8:	mov    $0x1,%edx
  77cced:	call   *0x33c1ad(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  77ccf3:	jmp    77cc1a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17da>
  77ccf8:	movq   $0xffffffffffffffff,0x810(%rsp)
  77cd04:	mov    0x2d8(%rsp),%rax
  77cd0c:	mov    (%rax),%rsi
  77cd0f:	test   %rsi,%rsi
  77cd12:	je     77cde0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x19a0>
  77cd18:	mov    $0x1,%r12b
  77cd1b:	lea    0x390(%rsp),%rdi
  77cd23:	mov    $0x1,%bl
  77cd25:	mov    $0x1,%r15b
  77cd28:	mov    $0x1,%bpl
  77cd2b:	call   *0x33c6ff(%rip)        # ab9430 <_DYNAMIC+0x7d0>
  77cd31:	mov    0xf8(%rsp),%r13
  77cd39:	mov    0x390(%rsp),%rax
  77cd41:	mov    0x398(%rsp),%rsi
  77cd49:	movups 0x3a0(%rsp),%xmm0
  77cd51:	movaps %xmm0,0x310(%rsp)
  77cd59:	movups 0x3b0(%rsp),%xmm1
  77cd61:	movaps %xmm1,0x970(%rsp)
  77cd69:	mov    0x3c0(%rsp),%rcx
  77cd71:	mov    %rcx,0x980(%rsp)
  77cd79:	movaps %xmm0,0x790(%rsp)
  77cd81:	cmp    $0xfffffffffffffffe,%rax
  77cd85:	mov    0x40(%rsp),%r12
  77cd8a:	je     77cdf4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x19b4>
  77cd8c:	mov    0x980(%rsp),%rcx
  77cd94:	mov    0x48(%rsp),%rdx
  77cd99:	mov    %rcx,0x30(%rdx)
  77cd9d:	movaps 0x970(%rsp),%xmm0
  77cda5:	movups %xmm0,0x20(%rdx)
  77cda9:	movaps 0x790(%rsp),%xmm0
  77cdb1:	movaps %xmm0,0x180(%rsp)
  77cdb9:	movups %xmm0,0x10(%rdx)
  77cdbd:	mov    %rax,(%rdx)
  77cdc0:	mov    %rsi,0x8(%rdx)
  77cdc4:	mov    $0x1,%r12b
  77cdc7:	cmpl   $0xffffffff,0x810(%rsp)
  77cdcf:	mov    $0x1,%r13b
  77cdd2:	mov    $0x1,%bpl
  77cdd5:	jne    7800f4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4cb4>
  77cddb:	jmp    780101 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4cc1>
  77cde0:	mov    $0xffffffffffffffff,%rsi
  77cde7:	mov    0x40(%rsp),%r12
  77cdec:	mov    0xf8(%rsp),%r13
  77cdf4:	movaps 0x790(%rsp),%xmm0
  77cdfc:	movups %xmm0,0x8c0(%rsp)
  77ce04:	mov    %rsi,0x258(%rsp)
  77ce0c:	mov    %rsi,0x8b8(%rsp)
  77ce14:	cmpb   $0x0,0x2f(%rsp)
  77ce19:	je     77ceb3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1a73>
  77ce1f:	lea    0x390(%rsp),%rdi
  77ce27:	lea    0x1d8(%rsp),%rdx
  77ce2f:	lea    0x100(%rsp),%rcx
  77ce37:	mov    %r12,%rsi
  77ce3a:	call   74fb40 <_RINvNtNtCslbxve4rcJus_4gpui7runtime6scroll8geometryNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEBP_>
  77ce3f:	mov    0x390(%rsp),%rax
  77ce47:	movups 0x398(%rsp),%xmm0
  77ce4f:	movaps %xmm0,0x970(%rsp)
  77ce57:	movups 0x3a8(%rsp),%xmm0
  77ce5f:	movaps %xmm0,0x980(%rsp)
  77ce67:	movups 0x3b8(%rsp),%xmm0
  77ce6f:	movaps %xmm0,0x990(%rsp)
  77ce77:	cmp    $0xfffffffffffffffe,%rax
  77ce7b:	jne    77f18e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3d4e>
  77ce81:	movaps 0x970(%rsp),%xmm0
  77ce89:	movaps 0x980(%rsp),%xmm1
  77ce91:	movaps 0x990(%rsp),%xmm2
  77ce99:	movaps %xmm2,0x6e0(%rsp)
  77cea1:	movaps %xmm1,0x6d0(%rsp)
  77cea9:	movaps %xmm0,0x6c0(%rsp)
  77ceb1:	jmp    77ceee <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1aae>
  77ceb3:	movq   $0x0,0x6c0(%rsp)
  77cebf:	movq   $0x8,0x6c8(%rsp)
  77cecb:	xorps  %xmm0,%xmm0
  77cece:	movups %xmm0,0x6d0(%rsp)
  77ced6:	movq   $0x8,0x6e0(%rsp)
  77cee2:	movq   $0x0,0x6e8(%rsp)
  77ceee:	mov    0x6a8(%r12),%r15
  77cef6:	mov    0x6b0(%r12),%r14
  77cefe:	mov    0x6c0(%r12),%rbx
  77cf06:	lea    0xc78(%rsp),%rdi
  77cf0e:	mov    %r12,%rsi
  77cf11:	call   770530 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime9inspectorINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE17inspector_displayB10_>
  77cf16:	lea    0x650(%r12),%rax
  77cf1e:	mov    %rax,0xf0(%rsp)
  77cf26:	mov    (%rax),%rax
  77cf29:	test   %rax,%rax
  77cf2c:	je     77cf4a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1b0a>
  77cf2e:	mov    0x100(%rax),%rsi
  77cf35:	test   %rsi,%rsi
  77cf38:	je     77cf4a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1b0a>
  77cf3a:	lea    0xb98(%rsp),%rdi
  77cf42:	call   *0x33bfc0(%rip)        # ab8f08 <_DYNAMIC+0x2a8>
  77cf48:	jmp    77cf61 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1b21>
  77cf4a:	movq   $0x4,0xb98(%rsp)
  77cf56:	xorps  %xmm0,%xmm0
  77cf59:	movups %xmm0,0xba0(%rsp)
  77cf61:	mov    0x6b8(%r12),%rax
  77cf69:	test   %rax,%rax
  77cf6c:	je     77cfa0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1b60>
  77cf6e:	mov    %r14,0x18(%rax)
  77cf72:	mov    %r15,0x20(%rax)
  77cf76:	mov    %rbx,0x28(%rax)
  77cf7a:	movq   $0x0,0x10(%rax)
  77cf82:	movw   $0x100,0x58(%rax)
  77cf88:	test   %r14,%r14
  77cf8b:	setne  %dl
  77cf8e:	cmp    %r13,%rbx
  77cf91:	sete   %cl
  77cf94:	and    %dl,%cl
  77cf96:	mov    %rax,0x688(%rsp)
  77cf9e:	jmp    77cfa2 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1b62>
  77cfa0:	mov    $0x2,%cl
  77cfa2:	mov    %cl,0x690(%rsp)
  77cfa9:	mov    0xa8(%rsp),%rdi
  77cfb1:	call   *0x33c481(%rip)        # ab9438 <_DYNAMIC+0x7d8>
  77cfb7:	movzbl 0xc78(%rsp),%eax
  77cfbf:	movq   $0xffffffffffffffff,0x670(%rsp)
  77cfcb:	mov    %al,0x7f(%rsp)
  77cfcf:	test   %al,%al
  77cfd1:	je     77cfe3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1ba3>
  77cfd3:	mov    0xc80(%rsp),%rax
  77cfdb:	mov    %rax,0x670(%rsp)
  77cfe3:	cmpl   $0x2,0xca0(%rsp)
  77cfeb:	lea    0xca0(%rsp),%rsi
  77cff3:	cmove  %r12,%rsi
  77cff7:	lea    0x970(%rsp),%rdi
  77cfff:	call   *0x33c43b(%rip)        # ab9440 <_DYNAMIC+0x7e0>
  77d005:	movups -0x6ba98c(%rip),%xmm0        # c2680 <GCC_except_table0+0x318>
  77d00c:	movaps %xmm0,0x390(%rsp)
  77d014:	lea    0x970(%rsp),%rdi
  77d01c:	lea    0x390(%rsp),%rsi
  77d024:	call   *0x33c41e(%rip)        # ab9448 <_DYNAMIC+0x7e8>
  77d02a:	incq   0x740(%r12)
  77d032:	mov    0x2e0(%r12),%rax
  77d03a:	mov    %rax,0x660(%rsp)
  77d042:	test   %rax,%rax
  77d045:	je     77f06b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3c2b>
  77d04b:	movss  0x9c(%rsp),%xmm0
  77d054:	cvtss2sd %xmm0,%xmm0
  77d058:	movsd  %xmm0,0x890(%rsp)
  77d061:	movaps 0xc0(%rsp),%xmm0
  77d069:	unpcklps 0x80(%rsp),%xmm0
  77d071:	movaps %xmm0,0x800(%rsp)
  77d079:	lea    0x31d2d0(%rip),%rax        # a9a350 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1c18>
  77d080:	mov    %rax,0x658(%rsp)
  77d088:	movabs $0x8000000000000000,%rax
  77d092:	inc    %rax
  77d095:	mov    %rax,0x888(%rsp)
  77d09d:	lea    0x31d2c4(%rip),%rax        # a9a368 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1c30>
  77d0a4:	mov    %rax,0xa0(%rsp)
  77d0ac:	lea    0x180(%rsp),%r15
  77d0b4:	lea    0x31bfbd(%rip),%rax        # a99078 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x940>
  77d0bb:	mov    %rax,0x650(%rsp)
  77d0c3:	lea    0x31c0ce(%rip),%rax        # a99198 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xa60>
  77d0ca:	mov    %rax,0x648(%rsp)
  77d0d2:	lea    0x31d31f(%rip),%rax        # a9a3f8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1cc0>
  77d0d9:	mov    %rax,0x248(%rsp)
  77d0e1:	lea    -0x6aa7c1(%rip),%rax        # d2927 <GCC_except_table0+0x105bf>
  77d0e8:	mov    %rax,0x250(%rsp)
  77d0f0:	xor    %ecx,%ecx
  77d0f2:	lea    0x0(,%rcx,8),%rax
  77d0fa:	lea    (%rax,%rax,4),%r13
  77d0fe:	imul   $0x58,%rcx,%rax
  77d102:	mov    %rax,0x668(%rsp)
  77d10a:	mov    %rcx,%rsi
  77d10d:	shl    $0x4,%rsi
  77d111:	mov    %rcx,%rdx
  77d114:	jmp    77d145 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1d05>
  77d116:	add    $0x28,%r13
  77d11a:	addq   $0x58,0x668(%rsp)
  77d123:	mov    0x8a8(%rsp),%rsi
  77d12b:	add    $0x10,%rsi
  77d12f:	mov    0x8a0(%rsp),%rdx
  77d137:	cmp    0x660(%rsp),%rdx
  77d13f:	jae    77f06b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3c2b>
  77d145:	cmp    %rdx,0x670(%rsp)
  77d14d:	mov    %rdx,0x38(%rsp)
  77d152:	jne    77d1d8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1d98>
  77d158:	cmpb   $0x0,0x7f(%rsp)
  77d15d:	je     780298 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4e58>
  77d163:	mov    %rsi,%rbx
  77d166:	mov    0x148(%rsp),%rdx
  77d16e:	mov    0x150(%rsp),%rcx
  77d176:	mov    0x270(%rsp),%r8
  77d17e:	mov    0x278(%rsp),%r9
  77d186:	mov    0x40(%rsp),%rax
  77d18b:	movups 0x2f0(%rax),%xmm0
  77d192:	movups 0x5a0(%rax),%xmm1
  77d199:	movups %xmm1,0x18(%rsp)
  77d19e:	mov    0x58(%rsp),%rax
  77d1a3:	mov    %rax,0x10(%rsp)
  77d1a8:	movups %xmm0,(%rsp)
  77d1ac:	lea    0x390(%rsp),%rdi
  77d1b4:	lea    0xc80(%rsp),%rsi
  77d1bc:	call   *0x33c28e(%rip)        # ab9450 <_DYNAMIC+0x7f0>
  77d1c2:	cmpl   $0xfffffffe,0x390(%rsp)
  77d1ca:	jne    77fec0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4a80>
  77d1d0:	mov    0x38(%rsp),%rdx
  77d1d5:	mov    %rbx,%rsi
  77d1d8:	mov    0x40(%rsp),%rcx
  77d1dd:	mov    0x5a8(%rcx),%rax
  77d1e4:	cmp    %rax,%rdx
  77d1e7:	jae    780590 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5150>
  77d1ed:	mov    0x5a0(%rcx),%rax
  77d1f4:	mov    %rsi,0x8a8(%rsp)
  77d1fc:	movups (%rax,%rsi,1),%xmm0
  77d200:	movaps %xmm0,0x310(%rsp)
  77d208:	lea    0x390(%rsp),%rdi
  77d210:	mov    0x58(%rsp),%rsi
  77d215:	lea    0x310(%rsp),%rdx
  77d21d:	call   *0x33be1d(%rip)        # ab9040 <_DYNAMIC+0x3e0>
  77d223:	cmpb   $0x0,0x390(%rsp)
  77d22b:	jne    77fe0e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x49ce>
  77d231:	mov    0x38(%rsp),%rdx
  77d236:	lea    0x1(%rdx),%rcx
  77d23a:	mov    0x40(%rsp),%rax
  77d23f:	mov    0x2e0(%rax),%rsi
  77d246:	mov    %rcx,0x8a0(%rsp)
  77d24e:	cmp    %rsi,%rcx
  77d251:	jae    77d27b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1e3b>
  77d253:	mov    0x2d8(%rax),%rax
  77d25a:	mov    0x40(%rax,%r13,1),%eax
  77d25f:	mov    $0xffffffff,%ecx
  77d264:	cmp    %rcx,%rax
  77d267:	setne  %cl
  77d26a:	cmp    %rax,%rdx
  77d26d:	sete   %al
  77d270:	and    %cl,%al
  77d272:	mov    %eax,0x1d4(%rsp)
  77d279:	jmp    77d286 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1e46>
  77d27b:	movl   $0x0,0x1d4(%rsp)
  77d286:	movsd  0x3d4(%rsp),%xmm0
  77d28f:	movaps %xmm0,0x940(%rsp)
  77d297:	movsd  0x3dc(%rsp),%xmm0
  77d2a0:	movaps %xmm0,0x630(%rsp)
  77d2a8:	movups 0x3a4(%rsp),%xmm0
  77d2b0:	movaps %xmm0,0x930(%rsp)
  77d2b8:	movss  0x3a8(%rsp),%xmm0
  77d2c1:	movss  %xmm0,0x30c(%rsp)
  77d2ca:	movups 0x3b4(%rsp),%xmm0
  77d2d2:	movaps %xmm0,0x2c0(%rsp)
  77d2da:	movss  0x3bc(%rsp),%xmm0
  77d2e3:	movaps %xmm0,0x910(%rsp)
  77d2eb:	movss  0x3b8(%rsp),%xmm0
  77d2f4:	movss  %xmm0,0x308(%rsp)
  77d2fd:	movsd  0x3e4(%rsp),%xmm0
  77d306:	movaps %xmm0,0x920(%rsp)
  77d30e:	mov    0xa8(%rsp),%rax
  77d316:	mov    (%rax),%rax
  77d319:	lea    -0x6b924c(%rip),%rcx        # c40d4 <GCC_except_table0+0x1d6c>
  77d320:	movslq (%rcx,%rax,4),%rax
  77d324:	add    %rcx,%rax
  77d327:	jmp    *%rax
  77d329:	movups -0x6b8f14(%rip),%xmm0        # c441c <GCC_except_table0+0x20b4>
  77d330:	movaps %xmm0,0x350(%rsp)
  77d338:	movups -0x6b8f33(%rip),%xmm0        # c440c <GCC_except_table0+0x20a4>
  77d33f:	movaps %xmm0,0x340(%rsp)
  77d347:	movups -0x6b8f52(%rip),%xmm0        # c43fc <GCC_except_table0+0x2094>
  77d34e:	movaps %xmm0,0x330(%rsp)
  77d356:	movups -0x6b8f71(%rip),%xmm0        # c43ec <GCC_except_table0+0x2084>
  77d35d:	movaps %xmm0,0x320(%rsp)
  77d365:	movups -0x6b8f90(%rip),%xmm0        # c43dc <GCC_except_table0+0x2074>
  77d36c:	movaps %xmm0,0x310(%rsp)
  77d374:	movabs $0x3000100000000,%rax
  77d37e:	mov    %rax,0x360(%rsp)
  77d386:	jmp    77d4a0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2060>
  77d38b:	mov    0x40(%rsp),%rdx
  77d390:	mov    0x220(%rdx),%rax
  77d397:	mov    0x38(%rsp),%rdi
  77d39c:	cmp    %rax,%rdi
  77d39f:	jae    78055c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x511c>
  77d3a5:	mov    0x210(%rdx),%rax
  77d3ac:	mov    0x218(%rdx),%rcx
  77d3b3:	movzbl (%rcx,%rdi,1),%ecx
  77d3b7:	cmp    %rcx,%rax
  77d3ba:	jbe    780565 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5125>
  77d3c0:	mov    0x208(%rdx),%rax
  77d3c7:	imul   $0x58,%rcx,%rcx
  77d3cb:	mov    0x50(%rax,%rcx,1),%rdx
  77d3d0:	mov    %rdx,0x360(%rsp)
  77d3d8:	movups 0x40(%rax,%rcx,1),%xmm0
  77d3dd:	movaps %xmm0,0x350(%rsp)
  77d3e5:	movups (%rax,%rcx,1),%xmm0
  77d3e9:	movups 0x10(%rax,%rcx,1),%xmm1
  77d3ee:	movups 0x20(%rax,%rcx,1),%xmm2
  77d3f3:	movupd 0x30(%rax,%rcx,1),%xmm3
  77d3f9:	jmp    77d47f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x203f>
  77d3fe:	mov    0x40(%rsp),%rax
  77d403:	mov    0x208(%rax),%rsi
  77d40a:	lea    0x310(%rsp),%rdi
  77d412:	mov    0x38(%rsp),%rdx
  77d417:	call   *0x33bc33(%rip)        # ab9050 <_DYNAMIC+0x3f0>
  77d41d:	mov    0x40(%rsp),%rax
  77d422:	mov    0x2e0(%rax),%rsi
  77d429:	jmp    77d4a0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2060>
  77d42b:	mov    0x40(%rsp),%rcx
  77d430:	mov    0x218(%rcx),%rax
  77d437:	cmp    %rax,0x38(%rsp)
  77d43c:	jae    780573 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5133>
  77d442:	mov    0x210(%rcx),%rax
  77d449:	mov    0x668(%rsp),%rdx
  77d451:	mov    0x50(%rax,%rdx,1),%rcx
  77d456:	mov    %rcx,0x360(%rsp)
  77d45e:	movups 0x40(%rax,%rdx,1),%xmm0
  77d463:	movaps %xmm0,0x350(%rsp)
  77d46b:	movups (%rax,%rdx,1),%xmm0
  77d46f:	movups 0x10(%rax,%rdx,1),%xmm1
  77d474:	movups 0x20(%rax,%rdx,1),%xmm2
  77d479:	movupd 0x30(%rax,%rdx,1),%xmm3
  77d47f:	movapd %xmm3,0x340(%rsp)
  77d488:	movaps %xmm2,0x330(%rsp)
  77d490:	movaps %xmm1,0x320(%rsp)
  77d498:	movaps %xmm0,0x310(%rsp)
  77d4a0:	cmp    %rsi,0x38(%rsp)
  77d4a5:	jae    7804cd <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x508d>
  77d4ab:	mov    0x40(%rsp),%rax
  77d4b0:	mov    0x2d8(%rax),%rdi
  77d4b7:	mov    0x18(%rdi,%r13,1),%edx
  77d4bc:	mov    $0xffffffff,%eax
  77d4c1:	cmp    %rax,%rdx
  77d4c4:	je     77d4e0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x20a0>
  77d4c6:	call   75e040 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_>
  77d4cb:	mov    %eax,0xbc(%rsp)
  77d4d2:	mov    0x40(%rsp),%rax
  77d4d7:	mov    0x2e0(%rax),%rsi
  77d4de:	jmp    77d4eb <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x20ab>
  77d4e0:	movl   $0x0,0xbc(%rsp)
  77d4eb:	cmp    %rsi,0x38(%rsp)
  77d4f0:	jae    7804dc <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x509c>
  77d4f6:	mov    0x40(%rsp),%rax
  77d4fb:	mov    0x2d8(%rax),%rax
  77d502:	mov    0x18(%rax,%r13,1),%ebx
  77d507:	mov    $0xffffffff,%ecx
  77d50c:	cmp    %rcx,%rbx
  77d50f:	je     77d52a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x20ea>
  77d511:	cmp    %rbx,%rsi
  77d514:	jbe    7804fa <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x50ba>
  77d51a:	lea    (%rbx,%rbx,4),%rcx
  77d51e:	mov    (%rax,%rcx,8),%rcx
  77d522:	mov    %rcx,0x898(%rsp)
  77d52a:	mov    0xf0(%rsp),%rcx
  77d532:	mov    (%rcx),%rcx
  77d535:	xorps  %xmm0,%xmm0
  77d538:	movss  %xmm0,0x74(%rsp)
  77d53e:	test   %rcx,%rcx
  77d541:	je     77d56b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x212b>
  77d543:	mov    0x100(%rcx),%rdi
  77d54a:	test   %rdi,%rdi
  77d54d:	je     77d56b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x212b>
  77d54f:	mov    (%rax,%r13,1),%rsi
  77d553:	call   *0x33be57(%rip)        # ab93b0 <_DYNAMIC+0x750>
  77d559:	movss  %xmm0,0x74(%rsp)
  77d55f:	mov    0x40(%rsp),%rax
  77d564:	mov    0x2e0(%rax),%rsi
  77d56b:	cmp    %rsi,0x38(%rsp)
  77d570:	jae    7804eb <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x50ab>
  77d576:	mov    0x40(%rsp),%rax
  77d57b:	mov    0x2d8(%rax),%rax
  77d582:	mov    %rax,0x30(%rsp)
  77d587:	mov    0x18(%rax,%r13,1),%ecx
  77d58c:	mov    $0xffffffff,%eax
  77d591:	cmp    %rax,%rcx
  77d594:	je     77d6b0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2270>
  77d59a:	mov    0x1e8(%rsp),%rax
  77d5a2:	cmp    %rcx,%rax
  77d5a5:	jbe    78050b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x50cb>
  77d5ab:	imul   $0x38,%rcx,%rax
  77d5af:	mov    0x1e0(%rsp),%rcx
  77d5b7:	movups (%rcx,%rax,1),%xmm0
  77d5bb:	movaps %xmm0,0x60(%rsp)
  77d5c0:	movups 0x10(%rcx,%rax,1),%xmm0
  77d5c5:	movaps %xmm0,0xe0(%rsp)
  77d5cd:	movups 0x20(%rcx,%rax,1),%xmm0
  77d5d2:	movaps %xmm0,0x280(%rsp)
  77d5da:	movzbl 0x30(%rcx,%rax,1),%ebp
  77d5df:	mov    0x31(%rcx,%rax,1),%edx
  77d5e3:	mov    %edx,0x180(%rsp)
  77d5ea:	mov    0x34(%rcx,%rax,1),%eax
  77d5ee:	mov    %eax,0x183(%rsp)
  77d5f5:	cmp    $0xffffffff,%ebx
  77d5f8:	je     780289 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4e49>
  77d5fe:	lea    0x390(%rsp),%rdi
  77d606:	lea    0x6c0(%rsp),%rsi
  77d60e:	mov    0x898(%rsp),%rdx
  77d616:	call   *0x33be3c(%rip)        # ab9458 <_DYNAMIC+0x7f8>
  77d61c:	cmpl   $0x1,0x390(%rsp)
  77d624:	jne    77d6e4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x22a4>
  77d62a:	movq   0x398(%rsp),%xmm0
  77d633:	movq   0x3a0(%rsp),%xmm1
  77d63c:	movq   %xmm0,%rax
  77d641:	movq   %xmm1,%rcx
  77d646:	movabs $0x7fffffffffffffff,%rdx
  77d650:	and    %rdx,%rax
  77d653:	movabs $0x7fefffffffffffff,%rsi
  77d65d:	cmp    %rsi,%rax
  77d660:	setg   %al
  77d663:	and    %rdx,%rcx
  77d666:	cmp    %rsi,%rcx
  77d669:	setg   %cl
  77d66c:	or     %al,%cl
  77d66e:	or     %bpl,%cl
  77d671:	and    $0x1,%cl
  77d674:	punpcklqdq %xmm1,%xmm1
  77d678:	pxor   -0x6b9e90(%rip),%xmm1        # c37f0 <GCC_except_table0+0x1488>
  77d680:	movapd 0xe0(%rsp),%xmm3
  77d689:	mulpd  %xmm3,%xmm1
  77d68d:	punpcklqdq %xmm0,%xmm0
  77d691:	movapd 0x60(%rsp),%xmm2
  77d697:	mulpd  %xmm2,%xmm0
  77d69b:	subpd  %xmm0,%xmm1
  77d69f:	movapd 0x280(%rsp),%xmm0
  77d6a8:	addpd  %xmm1,%xmm0
  77d6ac:	mov    %ecx,%ebp
  77d6ae:	jmp    77d717 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x22d7>
  77d6b0:	movsd  0x890(%rsp),%xmm0
  77d6b9:	movsd  %xmm0,0x790(%rsp)
  77d6c2:	lea    0x7c1(%rsp),%rax
  77d6ca:	xorps  %xmm1,%xmm1
  77d6cd:	movups %xmm1,-0x29(%rax)
  77d6d1:	movsd  %xmm0,0x7a8(%rsp)
  77d6da:	movaps %xmm1,-0x11(%rax)
  77d6de:	movb   $0x0,-0x1(%rax)
  77d6e2:	jmp    77d73a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x22fa>
  77d6e4:	mov    0x180(%rsp),%eax
  77d6eb:	mov    0x183(%rsp),%ecx
  77d6f2:	lea    0x7c1(%rsp),%rdx
  77d6fa:	mov    %ecx,0x3(%rdx)
  77d6fd:	mov    %eax,(%rdx)
  77d6ff:	movapd 0x60(%rsp),%xmm2
  77d705:	movapd 0xe0(%rsp),%xmm3
  77d70e:	movapd 0x280(%rsp),%xmm0
  77d717:	movapd %xmm2,0x790(%rsp)
  77d720:	movapd %xmm3,0x7a0(%rsp)
  77d729:	movapd %xmm0,0x7b0(%rsp)
  77d732:	mov    %bpl,0x7c0(%rsp)
  77d73a:	movaps -0x6b9c41(%rip),%xmm0        # c3b00 <GCC_except_table0+0x1798>
  77d741:	movaps %xmm0,0x180(%rsp)
  77d749:	movaps 0x940(%rsp),%xmm0
  77d751:	movlps %xmm0,0x190(%rsp)
  77d759:	lea    0x390(%rsp),%rdi
  77d761:	lea    0x790(%rsp),%rsi
  77d769:	mov    %r15,%rdx
  77d76c:	call   *0x33b8d6(%rip)        # ab9048 <_DYNAMIC+0x3e8>
  77d772:	lea    0xbb0(%rsp),%rdi
  77d77a:	lea    0x390(%rsp),%rsi
  77d782:	lea    0x34c(%rsp),%rdx
  77d78a:	call   *0x33b8b8(%rip)        # ab9048 <_DYNAMIC+0x3e8>
  77d790:	mov    0x1e8(%rsp),%rbx
  77d798:	cmp    0x1d8(%rsp),%rbx
  77d7a0:	jne    77d7af <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x236f>
  77d7a2:	lea    0x1d8(%rsp),%rdi
  77d7aa:	call   771d20 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtCscO85OU7Wpt0_20gpui_reactivity_core8geometry15CoordinateSpaceE8grow_oneCs9C2G9YFESsD_29canonical_text_public_control>
  77d7af:	mov    0x1e0(%rsp),%rax
  77d7b7:	imul   $0x38,%rbx,%rcx
  77d7bb:	mov    0xbe0(%rsp),%rdx
  77d7c3:	mov    %rdx,0x30(%rax,%rcx,1)
  77d7c8:	movups 0xbb0(%rsp),%xmm0
  77d7d0:	movups 0xbc0(%rsp),%xmm1
  77d7d8:	movups 0xbd0(%rsp),%xmm2
  77d7e0:	movups %xmm2,0x20(%rax,%rcx,1)
  77d7e5:	movups %xmm1,0x10(%rax,%rcx,1)
  77d7ea:	movups %xmm0,(%rax,%rcx,1)
  77d7ee:	inc    %rbx
  77d7f1:	mov    %rbx,0x1e8(%rsp)
  77d7f9:	movups 0xbb0(%rsp),%xmm0
  77d801:	movaps %xmm0,0xe0(%rsp)
  77d809:	movups 0xbc0(%rsp),%xmm0
  77d811:	movaps %xmm0,0x280(%rsp)
  77d819:	movups 0xbd0(%rsp),%xmm0
  77d821:	movaps %xmm0,0x60(%rsp)
  77d826:	lea    0xbb0(%rsp),%rdi
  77d82e:	call   *0x33bc2c(%rip)        # ab9460 <_DYNAMIC+0x800>
  77d834:	xor    %ebx,%ebx
  77d836:	test   %al,%al
  77d838:	je     77d963 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2523>
  77d83e:	cvtpd2ps 0x280(%rsp),%xmm0
  77d847:	cvtpd2ps 0xe0(%rsp),%xmm1
  77d850:	cvtpd2ps 0x60(%rsp),%xmm2
  77d856:	unpcklpd %xmm0,%xmm1
  77d85a:	movd   %xmm1,%eax
  77d85e:	and    $0x7fffffff,%eax
  77d863:	movapd %xmm1,%xmm0
  77d867:	shufps $0x55,%xmm1,%xmm0
  77d86b:	movd   %xmm0,%ecx
  77d86f:	and    $0x7fffffff,%ecx
  77d875:	cmp    $0x7f800000,%ecx
  77d87b:	setge  %cl
  77d87e:	movdqa %xmm1,%xmm0
  77d882:	punpckhqdq %xmm1,%xmm0
  77d886:	movd   %xmm0,%edx
  77d88a:	and    $0x7fffffff,%edx
  77d890:	cmp    $0x7f800000,%edx
  77d896:	setge  %dl
  77d899:	movaps %xmm1,%xmm0
  77d89c:	shufps $0xff,%xmm1,%xmm0
  77d8a0:	movd   %xmm0,%esi
  77d8a4:	and    $0x7fffffff,%esi
  77d8aa:	cmp    $0x7f800000,%esi
  77d8b0:	setge  %sil
  77d8b4:	movd   %xmm2,%edi
  77d8b8:	and    $0x7fffffff,%edi
  77d8be:	cmp    $0x7f800000,%edi
  77d8c4:	setge  %dil
  77d8c8:	movapd %xmm2,%xmm0
  77d8cc:	shufps $0x55,%xmm2,%xmm0
  77d8d0:	movd   %xmm0,%r8d
  77d8d5:	and    $0x7fffffff,%r8d
  77d8dc:	cmp    $0x7f800000,%r8d
  77d8e3:	setl   %r8b
  77d8e7:	cmp    $0x7f7fffff,%eax
  77d8ec:	mov    0x30(%rsp),%r9
  77d8f1:	jg     77d968 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2528>
  77d8f3:	test   %cl,%cl
  77d8f5:	jne    77d968 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2528>
  77d8f7:	test   %dl,%dl
  77d8f9:	jne    77d968 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2528>
  77d8fb:	test   %sil,%sil
  77d8fe:	jne    77d968 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2528>
  77d900:	test   %dil,%dil
  77d903:	jne    77d968 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2528>
  77d905:	test   %r8b,%r8b
  77d908:	je     77d968 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2528>
  77d90a:	movaps %xmm1,0x60(%rsp)
  77d90f:	movaps %xmm1,0x390(%rsp)
  77d917:	movaps %xmm2,0xe0(%rsp)
  77d91f:	movlpd %xmm2,0x3a0(%rsp)
  77d928:	lea    0x390(%rsp),%rdi
  77d930:	call   *0x33bb32(%rip)        # ab9468 <_DYNAMIC+0x808>
  77d936:	test   %al,%al
  77d938:	mov    0x30(%rsp),%r9
  77d93d:	je     77d968 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2528>
  77d93f:	movaps 0x60(%rsp),%xmm0
  77d944:	movups %xmm0,0x2a8(%rsp)
  77d94c:	movaps 0xe0(%rsp),%xmm0
  77d954:	movlps %xmm0,0x2b8(%rsp)
  77d95c:	mov    $0x1,%ebx
  77d961:	jmp    77d968 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2528>
  77d963:	mov    0x30(%rsp),%r9
  77d968:	mov    %ebx,0x2a4(%rsp)
  77d96f:	xorps  %xmm0,%xmm0
  77d972:	unpcklpd 0x630(%rsp),%xmm0
  77d97b:	movups %xmm0,0x698(%rsp)
  77d983:	cmpb   $0x0,0x2f(%rsp)
  77d988:	je     77da28 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x25e8>
  77d98e:	mov    0x18(%r9,%r13,1),%edx
  77d993:	mov    $0xffffffff,%eax
  77d998:	cmp    %rax,%rdx
  77d99b:	je     77da6e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x262e>
  77d9a1:	mov    0x228(%rsp),%rax
  77d9a9:	cmp    %rdx,%rax
  77d9ac:	jbe    780519 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x50d9>
  77d9b2:	mov    0x220(%rsp),%rax
  77d9ba:	mov    %rdx,%rcx
  77d9bd:	shl    $0x4,%rcx
  77d9c1:	movsd  (%rax,%rcx,1),%xmm1
  77d9c6:	movsd  0x8(%rax,%rcx,1),%xmm2
  77d9cc:	movq   $0x0,0x390(%rsp)
  77d9d8:	movaps 0xc0(%rsp),%xmm0
  77d9e0:	movss  %xmm0,0x398(%rsp)
  77d9e9:	movaps 0x80(%rsp),%xmm0
  77d9f1:	movss  %xmm0,0x39c(%rsp)
  77d9fa:	mov    0x240(%rsp),%rax
  77da02:	cmp    %rdx,%rax
  77da05:	jbe    780527 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x50e7>
  77da0b:	movaps %xmm2,0x280(%rsp)
  77da13:	movaps %xmm1,0xe0(%rsp)
  77da1b:	add    0x238(%rsp),%rcx
  77da23:	jmp    77dabf <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x267f>
  77da28:	movq   $0x0,0x1b0(%rsp)
  77da34:	movaps 0xc0(%rsp),%xmm0
  77da3c:	movss  %xmm0,0x1b8(%rsp)
  77da45:	movaps 0x80(%rsp),%xmm0
  77da4d:	movss  %xmm0,0x1bc(%rsp)
  77da56:	xorps  %xmm0,%xmm0
  77da59:	movl   $0x0,0x60(%rsp)
  77da61:	movaps 0x800(%rsp),%xmm1
  77da69:	jmp    77db46 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2706>
  77da6e:	movq   $0x0,0x390(%rsp)
  77da7a:	movaps 0xc0(%rsp),%xmm0
  77da82:	movss  %xmm0,0x398(%rsp)
  77da8b:	movaps 0x80(%rsp),%xmm0
  77da93:	movss  %xmm0,0x39c(%rsp)
  77da9c:	xorps  %xmm0,%xmm0
  77da9f:	movaps %xmm0,0xe0(%rsp)
  77daa7:	lea    0x390(%rsp),%rcx
  77daaf:	movaps 0x800(%rsp),%xmm0
  77dab7:	movaps %xmm0,0x280(%rsp)
  77dabf:	movups (%rcx),%xmm0
  77dac2:	movaps %xmm0,0x1b0(%rsp)
  77daca:	mov    0x20(%r9,%r13,1),%edi
  77dacf:	call   775950 <_RNvMsh_NtCslbxve4rcJus_4gpui7runtimeNtB5_4Node4kind>
  77dad4:	mov    $0x1,%cl
  77dad6:	mov    %ecx,0x60(%rsp)
  77dada:	cmp    $0x7,%al
  77dadc:	jne    77daf5 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x26b5>
  77dade:	mov    0x30(%rsp),%r9
  77dae3:	movaps 0xe0(%rsp),%xmm0
  77daeb:	movaps 0x280(%rsp),%xmm1
  77daf3:	jmp    77db46 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2706>
  77daf5:	mov    0x30(%rsp),%r9
  77dafa:	mov    0x18(%r9,%r13,1),%ecx
  77daff:	mov    $0xffffffff,%eax
  77db04:	cmp    %rax,%rcx
  77db07:	movaps 0xe0(%rsp),%xmm0
  77db0f:	movaps 0x280(%rsp),%xmm1
  77db17:	je     77db3e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x26fe>
  77db19:	mov    0x168(%rsp),%rax
  77db21:	cmp    %rcx,%rax
  77db24:	jbe    78057c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x513c>
  77db2a:	mov    0x160(%rsp),%rax
  77db32:	movzbl (%rax,%rcx,1),%eax
  77db36:	and    $0x1,%al
  77db38:	mov    %eax,0x60(%rsp)
  77db3c:	jmp    77db46 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2706>
  77db3e:	movl   $0x0,0x60(%rsp)
  77db46:	movlhps %xmm1,%xmm0
  77db49:	movups %xmm0,0x170(%rsp)
  77db51:	mov    0x20(%r9,%r13,1),%eax
  77db56:	and    $0xf,%eax
  77db59:	cmp    $0x7,%eax
  77db5c:	jb     77db6a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x272a>
  77db5e:	lea    -0x8(%rax),%ecx
  77db61:	cmp    $0x2,%ecx
  77db64:	jae    77e6c4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3284>
  77db6a:	mov    0x18(%r9,%r13,1),%ecx
  77db6f:	xor    %r12d,%r12d
  77db72:	mov    $0xffffffff,%edx
  77db77:	cmp    %rdx,%rcx
  77db7a:	je     77db9a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x275a>
  77db7c:	cmp    %rcx,0x168(%rsp)
  77db84:	jbe    77db9a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x275a>
  77db86:	mov    0x160(%rsp),%rdx
  77db8e:	movzbl (%rdx,%rcx,1),%r12d
  77db93:	and    $0x2,%r12b
  77db97:	shr    $1,%r12b
  77db9a:	cmpb   $0x0,0x2f(%rsp)
  77db9f:	je     77dbed <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x27ad>
  77dba1:	mov    0x168(%rsp),%r14
  77dba9:	cmp    0x158(%rsp),%r14
  77dbb1:	jne    77dbc1 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2781>
  77dbb3:	lea    0x158(%rsp),%rdi
  77dbbb:	call   *0x33b8af(%rip)        # ab9470 <_DYNAMIC+0x810>
  77dbc1:	lea    (%r12,%r12,1),%eax
  77dbc5:	add    0x60(%rsp),%al
  77dbc9:	mov    0x160(%rsp),%rcx
  77dbd1:	mov    %al,(%rcx,%r14,1)
  77dbd5:	inc    %r14
  77dbd8:	mov    %r14,0x168(%rsp)
  77dbe0:	mov    0x30(%rsp),%rax
  77dbe5:	mov    0x20(%rax,%r13,1),%eax
  77dbea:	and    $0xf,%eax
  77dbed:	cmp    $0x9,%eax
  77dbf0:	ja     780372 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4f32>
  77dbf6:	mov    $0x34f,%ecx
  77dbfb:	bt     %eax,%ecx
  77dbfe:	jb     77dc7e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x283e>
  77dc00:	movups 0x170(%rsp),%xmm0
  77dc08:	movaps %xmm0,0x180(%rsp)
  77dc10:	movups 0x698(%rsp),%xmm0
  77dc18:	movaps %xmm0,0x390(%rsp)
  77dc20:	lea    0x8d0(%rsp),%rdi
  77dc28:	mov    %r15,%rsi
  77dc2b:	lea    0x1b0(%rsp),%rdx
  77dc33:	lea    0x2a4(%rsp),%rcx
  77dc3b:	lea    0x390(%rsp),%r8
  77dc43:	mov    0xf8(%rsp),%r9
  77dc4b:	call   *0x33b827(%rip)        # ab9478 <_DYNAMIC+0x818>
  77dc51:	cmpl   $0xfffffffe,0x8d0(%rsp)
  77dc59:	jne    77fef9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4ab9>
  77dc5f:	lea    0x8d8(%rsp),%rax
  77dc67:	movups (%rax),%xmm0
  77dc6a:	movaps %xmm0,0x170(%rsp)
  77dc72:	movups 0x10(%rax),%xmm0
  77dc76:	movaps %xmm0,0x1b0(%rsp)
  77dc7e:	cmpb   $0x0,0x2f(%rsp)
  77dc83:	je     77dd23 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x28e3>
  77dc89:	movaps 0x170(%rsp),%xmm0
  77dc91:	movaps %xmm0,0x390(%rsp)
  77dc99:	mov    0x228(%rsp),%r14
  77dca1:	cmp    0x218(%rsp),%r14
  77dca9:	jne    77dcb8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2878>
  77dcab:	lea    0x218(%rsp),%rdi
  77dcb3:	call   771d90 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtCscO85OU7Wpt0_20gpui_reactivity_core8geometry4RectE8grow_oneCs9C2G9YFESsD_29canonical_text_public_control>
  77dcb8:	mov    0x220(%rsp),%rax
  77dcc0:	mov    %r14,%rcx
  77dcc3:	shl    $0x4,%rcx
  77dcc7:	movaps 0x390(%rsp),%xmm0
  77dccf:	movups %xmm0,(%rax,%rcx,1)
  77dcd3:	inc    %r14
  77dcd6:	mov    %r14,0x228(%rsp)
  77dcde:	mov    0x240(%rsp),%r14
  77dce6:	cmp    0x230(%rsp),%r14
  77dcee:	jne    77dcfd <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x28bd>
  77dcf0:	lea    0x230(%rsp),%rdi
  77dcf8:	call   771d90 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtCscO85OU7Wpt0_20gpui_reactivity_core8geometry4RectE8grow_oneCs9C2G9YFESsD_29canonical_text_public_control>
  77dcfd:	mov    0x238(%rsp),%rax
  77dd05:	mov    %r14,%rcx
  77dd08:	shl    $0x4,%rcx
  77dd0c:	movaps 0x1b0(%rsp),%xmm0
  77dd14:	movups %xmm0,(%rax,%rcx,1)
  77dd18:	inc    %r14
  77dd1b:	mov    %r14,0x240(%rsp)
  77dd23:	test   %ebx,%ebx
  77dd25:	je     77dd5b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x291b>
  77dd27:	lea    0x390(%rsp),%rdi
  77dd2f:	lea    0x698(%rsp),%rsi
  77dd37:	lea    0x2a8(%rsp),%rdx
  77dd3f:	call   75e160 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerso_0BQ_>
  77dd44:	cmpl   $0x1,0x390(%rsp)
  77dd4c:	jne    77dd5b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x291b>
  77dd4e:	lea    0x394(%rsp),%rax
  77dd56:	movups (%rax),%xmm0
  77dd59:	jmp    77dd5e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x291e>
  77dd5b:	xorps  %xmm0,%xmm0
  77dd5e:	movaps %xmm0,0x6f0(%rsp)
  77dd66:	mov    0x60(%rsp),%eax
  77dd6a:	or     %r12b,%al
  77dd6d:	cmp    $0x1,%al
  77dd6f:	je     77dd84 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2944>
  77dd71:	mov    0x30(%rsp),%rax
  77dd76:	mov    0x20(%rax,%r13,1),%edi
  77dd7b:	call   775950 <_RNvMsh_NtCslbxve4rcJus_4gpui7runtimeNtB5_4Node4kind>
  77dd80:	cmp    $0x6,%al
  77dd82:	jne    77dda4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2964>
  77dd84:	lea    0x290(%rsp),%rdi
  77dd8c:	lea    0x6f0(%rsp),%rsi
  77dd94:	lea    0x1b0(%rsp),%rdx
  77dd9c:	call   *0x33b6de(%rip)        # ab9480 <_DYNAMIC+0x820>
  77dda2:	jmp    77de11 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x29d1>
  77dda4:	movsd  0x6f0(%rsp),%xmm0
  77ddad:	movsd  0x6f8(%rsp),%xmm1
  77ddb6:	movaps %xmm0,%xmm2
  77ddb9:	addps  %xmm0,%xmm1
  77ddbc:	xorps  %xmm4,%xmm4
  77ddbf:	maxps  %xmm4,%xmm0
  77ddc2:	movaps %xmm0,%xmm3
  77ddc5:	cmpunordps %xmm0,%xmm3
  77ddc9:	andps  %xmm3,%xmm2
  77ddcc:	andnps %xmm0,%xmm3
  77ddcf:	orps   %xmm2,%xmm3
  77ddd2:	movaps %xmm1,%xmm0
  77ddd5:	minps  0x800(%rsp),%xmm0
  77dddd:	movaps %xmm0,%xmm2
  77dde0:	cmpunordps %xmm0,%xmm2
  77dde4:	andps  %xmm2,%xmm1
  77dde7:	andnps %xmm0,%xmm2
  77ddea:	orps   %xmm1,%xmm2
  77dded:	subps  %xmm3,%xmm2
  77ddf0:	movaps %xmm2,%xmm0
  77ddf3:	maxps  %xmm4,%xmm0
  77ddf6:	movaps %xmm0,%xmm1
  77ddf9:	cmpunordps %xmm0,%xmm1
  77ddfd:	andps  %xmm1,%xmm2
  77de00:	andnps %xmm0,%xmm1
  77de03:	orps   %xmm2,%xmm1
  77de06:	movlhps %xmm1,%xmm3
  77de09:	movups %xmm3,0x290(%rsp)
  77de11:	test   %r12b,%r12b
  77de14:	mov    0x30(%rsp),%rsi
  77de19:	je     77de48 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2a08>
  77de1b:	movss  0x298(%rsp),%xmm0
  77de24:	xor    %ebp,%ebp
  77de26:	xorps  %xmm1,%xmm1
  77de29:	ucomiss %xmm1,%xmm0
  77de2c:	jne    77de34 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x29f4>
  77de2e:	jnp    77e0b5 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2c75>
  77de34:	movss  0x29c(%rsp),%xmm0
  77de3d:	ucomiss %xmm1,%xmm0
  77de40:	jne    77de48 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2a08>
  77de42:	jnp    77e0b5 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2c75>
  77de48:	mov    0x348(%rsp),%eax
  77de4f:	mov    $0x3fffffff,%ecx
  77de54:	and    %ecx,%eax
  77de56:	cmp    $0x3f800001,%eax
  77de5b:	mov    $0x80000000,%ecx
  77de60:	cmove  %ecx,%eax
  77de63:	movd   %eax,%xmm0
  77de67:	xorps  %xmm1,%xmm1
  77de6a:	ucomiss %xmm1,%xmm0
  77de6d:	jbe    77df4e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2b0e>
  77de73:	movl   $0x1,0x398(%rsp)
  77de7e:	movq   $0x23,0x390(%rsp)
  77de8a:	test   %bl,%bl
  77de8c:	je     77fe3b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x49fb>
  77de92:	lea    0x390(%rsp),%rbx
  77de9a:	mov    %rbx,%rdi
  77de9d:	call   74d540 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  77dea2:	lea    0x2a8(%rsp),%rax
  77deaa:	movups (%rax),%xmm0
  77dead:	movaps %xmm0,0xb60(%rsp)
  77deb5:	mov    0x10(%rax),%rax
  77deb9:	mov    %rax,0xb70(%rsp)
  77dec1:	mov    %rbx,%rdi
  77dec4:	mov    0xa8(%rsp),%rsi
  77decc:	mov    0x38(%rsp),%rdx
  77ded1:	xor    %ecx,%ecx
  77ded3:	call   *0x33b5af(%rip)        # ab9488 <_DYNAMIC+0x828>
  77ded9:	mov    0x3a0(%rsp),%r9
  77dee1:	test   %r9,%r9
  77dee4:	je     77e041 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2c01>
  77deea:	movups 0x390(%rsp),%xmm0
  77def2:	movaps %xmm0,0x370(%rsp)
  77defa:	movaps 0x170(%rsp),%xmm0
  77df02:	movaps %xmm0,0x120(%rsp)
  77df0a:	movups 0x698(%rsp),%xmm0
  77df12:	movaps %xmm0,0x180(%rsp)
  77df1a:	lea    0x970(%rsp),%rdi
  77df22:	mov    %r15,%rsi
  77df25:	movss  0x74(%rsp),%xmm0
  77df2b:	lea    0xb60(%rsp),%rdx
  77df33:	lea    0x120(%rsp),%rcx
  77df3b:	lea    0x370(%rsp),%r8
  77df43:	call   *0x33b547(%rip)        # ab9490 <_DYNAMIC+0x830>
  77df49:	jmp    77e02e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2bee>
  77df4e:	cmpq   $0x0,0x8(%rsi,%r13,1)
  77df54:	jne    77df70 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2b30>
  77df56:	mov    0x20(%rsi,%r13,1),%edi
  77df5b:	call   775950 <_RNvMsh_NtCslbxve4rcJus_4gpui7runtimeNtB5_4Node4kind>
  77df60:	mov    $0x1,%bpl
  77df63:	cmp    $0x4,%al
  77df65:	mov    0x30(%rsp),%rsi
  77df6a:	jne    77e0b5 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2c75>
  77df70:	movl   $0x1,0x398(%rsp)
  77df7b:	movq   $0x23,0x390(%rsp)
  77df87:	test   %bl,%bl
  77df89:	je     77fe3b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x49fb>
  77df8f:	lea    0x390(%rsp),%rbx
  77df97:	mov    %rbx,%rdi
  77df9a:	call   74d540 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  77df9f:	lea    0x2a8(%rsp),%rcx
  77dfa7:	movups (%rcx),%xmm0
  77dfaa:	movaps %xmm0,0x120(%rsp)
  77dfb2:	mov    0x10(%rcx),%rax
  77dfb6:	mov    %rax,0x130(%rsp)
  77dfbe:	movups (%rcx),%xmm0
  77dfc1:	movaps %xmm0,0xc20(%rsp)
  77dfc9:	mov    0x10(%rcx),%rax
  77dfcd:	mov    %rax,0xc30(%rsp)
  77dfd5:	movaps 0x170(%rsp),%xmm0
  77dfdd:	movaps %xmm0,0x370(%rsp)
  77dfe5:	movups 0x698(%rsp),%xmm0
  77dfed:	movaps %xmm0,0x180(%rsp)
  77dff5:	movups -0x6ba67c(%rip),%xmm0        # c3980 <GCC_except_table0+0x1618>
  77dffc:	movaps %xmm0,0x390(%rsp)
  77e004:	lea    0x970(%rsp),%rdi
  77e00c:	mov    %r15,%rsi
  77e00f:	movss  0x74(%rsp),%xmm0
  77e015:	lea    0xc20(%rsp),%rdx
  77e01d:	lea    0x370(%rsp),%rcx
  77e025:	mov    %rbx,%r8
  77e028:	call   *0x33b46a(%rip)        # ab9498 <_DYNAMIC+0x838>
  77e02e:	cmp    $0xffffffff,%eax
  77e031:	jne    77fe74 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4a34>
  77e037:	mov    $0x1,%bpl
  77e03a:	mov    0x30(%rsp),%rsi
  77e03f:	jmp    77e0b5 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2c75>
  77e041:	movaps 0x170(%rsp),%xmm0
  77e049:	movaps %xmm0,0x120(%rsp)
  77e051:	lea    0x34c(%rsp),%rax
  77e059:	movups -0x10(%rax),%xmm0
  77e05d:	movaps %xmm0,0x180(%rsp)
  77e065:	movups 0x698(%rsp),%xmm0
  77e06d:	movaps %xmm0,0x390(%rsp)
  77e075:	lea    0x970(%rsp),%rdi
  77e07d:	lea    0x390(%rsp),%rsi
  77e085:	movss  0x74(%rsp),%xmm0
  77e08b:	lea    0xb60(%rsp),%rdx
  77e093:	lea    0x120(%rsp),%rcx
  77e09b:	mov    %r15,%r8
  77e09e:	call   *0x33b3f4(%rip)        # ab9498 <_DYNAMIC+0x838>
  77e0a4:	mov    $0x1,%bpl
  77e0a7:	cmp    $0xffffffff,%eax
  77e0aa:	mov    0x30(%rsp),%rsi
  77e0af:	jne    77fe74 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4a34>
  77e0b5:	mov    0x20(%rsi,%r13,1),%edi
  77e0ba:	mov    %edi,%eax
  77e0bc:	and    $0xf,%eax
  77e0bf:	cmp    $0x9,%eax
  77e0c2:	ja     780372 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4f32>
  77e0c8:	cmp    $0x6,%eax
  77e0cb:	je     77e6d5 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3295>
  77e0d1:	shr    $0x4,%edi
  77e0d4:	dec    %edi
  77e0d6:	mov    0x40(%rsp),%rax
  77e0db:	mov    0x2f0(%rax),%rsi
  77e0e2:	mov    0x2f8(%rax),%rdx
  77e0e9:	call   775840 <_RNvMsf_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSlot7get_mut>
  77e0ee:	test   %rax,%rax
  77e0f1:	je     77e4de <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x309e>
  77e0f7:	lea    0x34c(%rsp),%rcx
  77e0ff:	movups -0x20(%rcx),%xmm0
  77e103:	movaps %xmm0,0x960(%rsp)
  77e10b:	mov    0x40(%rsp),%rcx
  77e110:	mov    0x6e8(%rcx),%rbx
  77e117:	mov    $0x1e,%esi
  77e11c:	test   %rbx,%rbx
  77e11f:	mov    0x30(%rsp),%rdx
  77e124:	je     780271 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4e31>
  77e12a:	cmpq   $0x0,0x30(%rbx)
  77e12f:	je     780271 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4e31>
  77e135:	movzbl 0x78c(%rsp),%ecx
  77e13d:	movb   $0x2,0xe0(%rsp)
  77e145:	cmp    $0x2,%cl
  77e148:	je     77e1bc <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2d7c>
  77e14a:	mov    (%rdx,%r13,1),%rdx
  77e14e:	cmp    %rdx,0x778(%rsp)
  77e156:	jne    77e1bc <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2d7c>
  77e158:	mov    0x788(%rsp),%edx
  77e15f:	mov    %edx,0x1d0(%rsp)
  77e166:	movzbl 0x784(%rsp),%edx
  77e16e:	mov    %dl,0x7e(%rsp)
  77e172:	mov    0x780(%rsp),%edx
  77e179:	mov    %edx,0x11c(%rsp)
  77e180:	lea    0x785(%rsp),%rdi
  77e188:	movzwl (%rdi),%edx
  77e18b:	mov    %dx,0xb8(%rsp)
  77e193:	movzbl 0x2(%rdi),%edx
  77e197:	mov    %dl,0xba(%rsp)
  77e19e:	movzwl 0x8(%rdi),%edx
  77e1a2:	mov    %dx,0xb4(%rsp)
  77e1aa:	movzbl 0xa(%rdi),%edx
  77e1ae:	mov    %dl,0xb6(%rsp)
  77e1b5:	mov    %cl,0xe0(%rsp)
  77e1bc:	cmpq   $0x0,0x1c0(%rsp)
  77e1c5:	je     7802bd <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4e7d>
  77e1cb:	movss  0x328(%rsp),%xmm0
  77e1d4:	movaps 0x630(%rsp),%xmm1
  77e1dc:	subss  0x2c0(%rsp),%xmm1
  77e1e5:	subss  0x308(%rsp),%xmm1
  77e1ee:	subss  0x930(%rsp),%xmm1
  77e1f7:	subss  0x30c(%rsp),%xmm1
  77e200:	subss  0x920(%rsp),%xmm1
  77e209:	lea    0x390(%rsp),%rdi
  77e211:	mov    %rax,%rsi
  77e214:	lea    0x1c0(%rsp),%rdx
  77e21c:	mov    $0x1,%ecx
  77e221:	mov    $0x1,%r8d
  77e227:	call   *0x33aeb3(%rip)        # ab90e0 <_DYNAMIC+0x480>
  77e22d:	mov    %r15,%r14
  77e230:	mov    0x390(%rsp),%rax
  77e238:	mov    0x398(%rsp),%r15
  77e240:	cmp    $0xfffffffffffffffe,%rax
  77e244:	jne    77fe8b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4a4b>
  77e24a:	movaps 0x2c0(%rsp),%xmm0
  77e252:	movss  %xmm0,0xd8(%rsp)
  77e25b:	movaps 0x910(%rsp),%xmm0
  77e263:	movss  %xmm0,0xdc(%rsp)
  77e26c:	mov    0x20(%r15),%rax
  77e270:	test   %rax,%rax
  77e273:	je     780352 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4f12>
  77e279:	lock incq (%rax)
  77e27d:	jle    7805c8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  77e283:	movsd  0xd8(%rsp),%xmm0
  77e28c:	movsd  %xmm0,0x2f8(%rsp)
  77e295:	mov    %rax,0x300(%rsp)
  77e29d:	test   %bpl,%bpl
  77e2a0:	je     77e726 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x32e6>
  77e2a6:	testb  $0x1,0x2a4(%rsp)
  77e2ae:	movl   $0x1,0x398(%rsp)
  77e2b9:	movq   $0x23,0x390(%rsp)
  77e2c5:	je     77ffb3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4b73>
  77e2cb:	lea    0x390(%rsp),%rdi
  77e2d3:	call   74d540 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  77e2d8:	lea    0x2a8(%rsp),%rcx
  77e2e0:	movups (%rcx),%xmm0
  77e2e3:	movaps %xmm0,0xb80(%rsp)
  77e2eb:	mov    0x10(%rcx),%rax
  77e2ef:	mov    %rax,0xb90(%rsp)
  77e2f7:	movups (%rcx),%xmm0
  77e2fa:	movaps %xmm0,0x370(%rsp)
  77e302:	mov    0x10(%rcx),%rax
  77e306:	mov    %rax,0x380(%rsp)
  77e30e:	cmpb   $0x2,0xe0(%rsp)
  77e316:	je     77e41f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2fdf>
  77e31c:	mov    0x11c(%rsp),%eax
  77e323:	mov    %eax,0x180(%rsp)
  77e32a:	movzbl 0x7e(%rsp),%eax
  77e32f:	mov    %al,0x184(%rsp)
  77e336:	movzbl 0xba(%rsp),%eax
  77e33e:	lea    0x185(%rsp),%rcx
  77e346:	mov    %al,0x2(%rcx)
  77e349:	movzwl 0xb8(%rsp),%eax
  77e351:	mov    %ax,(%rcx)
  77e354:	mov    0x1d0(%rsp),%eax
  77e35b:	mov    %eax,0x188(%rsp)
  77e362:	movzbl 0xe0(%rsp),%eax
  77e36a:	mov    %al,0x18c(%rsp)
  77e371:	movzbl 0xb6(%rsp),%eax
  77e379:	mov    %al,0xa(%rcx)
  77e37c:	movzwl 0xb4(%rsp),%eax
  77e384:	mov    %ax,0x8(%rcx)
  77e388:	movl   $0xffffffff,0x120(%rsp)
  77e393:	lea    0x120(%rsp),%rax
  77e39b:	mov    %rax,0x390(%rsp)
  77e3a3:	lea    0x970(%rsp),%rax
  77e3ab:	mov    %rax,0x398(%rsp)
  77e3b3:	lea    0xd8(%rsp),%rax
  77e3bb:	mov    %rax,0x3a0(%rsp)
  77e3c3:	lea    0xdc(%rsp),%rax
  77e3cb:	mov    %rax,0x3a8(%rsp)
  77e3d3:	lea    0x370(%rsp),%rax
  77e3db:	mov    %rax,0x3b0(%rsp)
  77e3e3:	lea    0x170(%rsp),%rax
  77e3eb:	mov    %rax,0x3b8(%rsp)
  77e3f3:	mov    0x20(%r15),%rdi
  77e3f7:	mov    %r14,%rsi
  77e3fa:	lea    0x390(%rsp),%rdx
  77e402:	call   73f430 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_>
  77e407:	test   %al,%al
  77e409:	je     780057 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c17>
  77e40f:	mov    0x120(%rsp),%eax
  77e416:	cmp    $0xffffffff,%eax
  77e419:	jne    780065 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c25>
  77e41f:	mov    %r14,%rdi
  77e422:	mov    0xa8(%rsp),%rsi
  77e42a:	mov    0x38(%rsp),%rdx
  77e42f:	mov    $0x1,%ecx
  77e434:	call   *0x33b04e(%rip)        # ab9488 <_DYNAMIC+0x828>
  77e43a:	add    $0x30,%rbx
  77e43e:	mov    0x190(%rsp),%rax
  77e446:	test   %rax,%rax
  77e449:	je     77e4ef <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x30af>
  77e44f:	movups 0x180(%rsp),%xmm0
  77e457:	movaps %xmm0,0x700(%rsp)
  77e45f:	movaps 0x170(%rsp),%xmm0
  77e467:	movaps %xmm0,0x120(%rsp)
  77e46f:	movss  0xd8(%rsp),%xmm0
  77e478:	movss  0xdc(%rsp),%xmm1
  77e481:	lea    0x2a8(%rsp),%rdx
  77e489:	mov    0x10(%rdx),%rcx
  77e48d:	mov    %rcx,0x3a0(%rsp)
  77e495:	movups (%rdx),%xmm2
  77e498:	movaps %xmm2,0x390(%rsp)
  77e4a0:	mov    %rax,(%rsp)
  77e4a4:	lea    0x970(%rsp),%rdi
  77e4ac:	mov    %rbx,%rsi
  77e4af:	mov    %r15,%rdx
  77e4b2:	lea    0x390(%rsp),%rcx
  77e4ba:	lea    0x120(%rsp),%r8
  77e4c2:	lea    0x700(%rsp),%r9
  77e4ca:	movss  0x9c(%rsp),%xmm2
  77e4d3:	call   *0x33afc7(%rip)        # ab94a0 <_DYNAMIC+0x840>
  77e4d9:	jmp    77e570 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3130>
  77e4de:	movq   $0x0,0x1f8(%rsp)
  77e4ea:	jmp    77e749 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3309>
  77e4ef:	movaps 0x170(%rsp),%xmm0
  77e4f7:	movaps %xmm0,0x120(%rsp)
  77e4ff:	movss  0xd8(%rsp),%xmm0
  77e508:	movss  0xdc(%rsp),%xmm1
  77e511:	lea    0x2a8(%rsp),%rcx
  77e519:	mov    0x10(%rcx),%rax
  77e51d:	mov    %rax,0x3a0(%rsp)
  77e525:	movups (%rcx),%xmm2
  77e528:	movaps %xmm2,0x390(%rsp)
  77e530:	movaps 0x960(%rsp),%xmm2
  77e538:	movaps %xmm2,0x180(%rsp)
  77e540:	lea    0x970(%rsp),%rdi
  77e548:	mov    %rbx,%rsi
  77e54b:	mov    %r15,%rdx
  77e54e:	lea    0x390(%rsp),%rcx
  77e556:	lea    0x120(%rsp),%r8
  77e55e:	mov    %r14,%r9
  77e561:	movss  0x9c(%rsp),%xmm2
  77e56a:	call   *0x33af38(%rip)        # ab94a8 <_DYNAMIC+0x848>
  77e570:	cmp    $0xffffffff,%eax
  77e573:	jne    77ff9c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4b5c>
  77e579:	cmpb   $0x2,0xe0(%rsp)
  77e581:	je     77e726 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x32e6>
  77e587:	mov    0x11c(%rsp),%eax
  77e58e:	cmp    0x1d0(%rsp),%eax
  77e595:	jne    77e726 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x32e6>
  77e59b:	mov    0x40(%rsp),%rax
  77e5a0:	mov    0x628(%rax),%rax
  77e5a7:	test   %rax,%rax
  77e5aa:	je     77e726 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x32e6>
  77e5b0:	mov    0x40(%rsp),%rcx
  77e5b5:	cmp    0x5f0(%rcx),%rax
  77e5bc:	jne    77e726 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x32e6>
  77e5c2:	mov    0x30(%rsp),%rax
  77e5c7:	mov    (%rax,%r13,1),%rax
  77e5cb:	mov    0x40(%rsp),%rcx
  77e5d0:	cmp    %rax,0x630(%rcx)
  77e5d7:	jne    77e726 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x32e6>
  77e5dd:	movzbl 0xe0(%rsp),%ecx
  77e5e5:	mov    %r14,%rdi
  77e5e8:	mov    %r15,%rsi
  77e5eb:	mov    0x11c(%rsp),%edx
  77e5f2:	call   *0x33ad48(%rip)        # ab9340 <_DYNAMIC+0x6e0>
  77e5f8:	movq   $0x18,0x390(%rsp)
  77e604:	cmpl   $0x1,0x180(%rsp)
  77e60c:	jne    780057 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c17>
  77e612:	lea    0x390(%rsp),%rbx
  77e61a:	mov    %rbx,%rdi
  77e61d:	call   74d540 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  77e622:	movsd  0x184(%rsp),%xmm0
  77e62b:	movaps 0x2c0(%rsp),%xmm1
  77e633:	unpcklps 0x910(%rsp),%xmm1
  77e63b:	addps  %xmm0,%xmm1
  77e63e:	movhps 0x18c(%rsp),%xmm1
  77e646:	movups %xmm1,0x700(%rsp)
  77e64e:	mov    %rbx,%rdi
  77e651:	mov    0xa8(%rsp),%rsi
  77e659:	mov    0x38(%rsp),%rdx
  77e65e:	mov    $0x1,%ecx
  77e663:	call   *0x33ae1f(%rip)        # ab9488 <_DYNAMIC+0x828>
  77e669:	mov    0x3a0(%rsp),%r9
  77e671:	test   %r9,%r9
  77e674:	je     77e6df <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x329f>
  77e676:	movups 0x390(%rsp),%xmm0
  77e67e:	movaps %xmm0,0x120(%rsp)
  77e686:	movaps 0x170(%rsp),%xmm0
  77e68e:	movaps %xmm0,0x180(%rsp)
  77e696:	xorps  %xmm0,%xmm0
  77e699:	lea    0x970(%rsp),%rdi
  77e6a1:	lea    0x700(%rsp),%rsi
  77e6a9:	lea    0xb80(%rsp),%rdx
  77e6b1:	mov    %r14,%rcx
  77e6b4:	lea    0x120(%rsp),%r8
  77e6bc:	call   *0x33adce(%rip)        # ab9490 <_DYNAMIC+0x830>
  77e6c2:	jmp    77e71d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x32dd>
  77e6c4:	mov    $0x1,%r12b
  77e6c7:	cmp    $0x7,%eax
  77e6ca:	je     77db9a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x275a>
  77e6d0:	jmp    780372 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4f32>
  77e6d5:	mov    $0xffffffff,%edi
  77e6da:	jmp    77e0d6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2c96>
  77e6df:	movaps 0x170(%rsp),%xmm0
  77e6e7:	movaps %xmm0,0x390(%rsp)
  77e6ef:	lea    0x970(%rsp),%rdi
  77e6f7:	lea    0x700(%rsp),%rsi
  77e6ff:	lea    0xb80(%rsp),%rdx
  77e707:	lea    0x390(%rsp),%rcx
  77e70f:	lea    0x960(%rsp),%r8
  77e717:	call   *0x33a823(%rip)        # ab8f40 <_DYNAMIC+0x2e0>
  77e71d:	cmp    $0xffffffff,%eax
  77e720:	jne    77ff9c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4b5c>
  77e726:	mov    0x2f8(%rsp),%rax
  77e72e:	mov    %rax,0x1f0(%rsp)
  77e736:	mov    0x300(%rsp),%rax
  77e73e:	mov    %rax,0x1f8(%rsp)
  77e746:	mov    %r14,%r15
  77e749:	mov    0x30(%rsp),%r14
  77e74e:	test   %bpl,%bpl
  77e751:	je     77e8aa <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x346a>
  77e757:	mov    0x20(%r14,%r13,1),%edi
  77e75c:	call   *0x33a976(%rip)        # ab90d8 <_DYNAMIC+0x478>
  77e762:	mov    %edx,%ebp
  77e764:	cmp    $0x2,%dl
  77e767:	je     77e8aa <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x346a>
  77e76d:	mov    0x2d8(%rsp),%rcx
  77e775:	mov    (%rcx),%rcx
  77e778:	test   %rcx,%rcx
  77e77b:	je     780390 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4f50>
  77e781:	mov    0x10(%rcx),%rsi
  77e785:	mov    %eax,%ebx
  77e787:	cmp    %rbx,%rsi
  77e78a:	jbe    780544 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5104>
  77e790:	mov    0x8(%rcx),%rax
  77e794:	movaps 0x930(%rsp),%xmm4
  77e79c:	movaps %xmm4,%xmm0
  77e79f:	shufps $0xe8,%xmm4,%xmm0
  77e7a3:	movaps 0x940(%rsp),%xmm3
  77e7ab:	addps  %xmm0,%xmm3
  77e7ae:	movaps 0x2c0(%rsp),%xmm5
  77e7b6:	movaps %xmm5,%xmm1
  77e7b9:	shufps $0xe8,%xmm5,%xmm1
  77e7bd:	addps  %xmm1,%xmm3
  77e7c0:	movaps 0x630(%rsp),%xmm2
  77e7c8:	subps  %xmm1,%xmm2
  77e7cb:	shufps $0xed,%xmm5,%xmm5
  77e7cf:	subps  %xmm5,%xmm2
  77e7d2:	subps  %xmm0,%xmm2
  77e7d5:	shufps $0xed,%xmm4,%xmm4
  77e7d9:	subps  %xmm4,%xmm2
  77e7dc:	subps  0x920(%rsp),%xmm2
  77e7e4:	movlhps %xmm2,%xmm3
  77e7e7:	movups %xmm3,0x370(%rsp)
  77e7ef:	testb  $0x1,0x2a4(%rsp)
  77e7f7:	movl   $0x1,0x398(%rsp)
  77e802:	movq   $0x23,0x390(%rsp)
  77e80e:	je     77ffec <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4bac>
  77e814:	lea    (%rax,%rbx,8),%rbx
  77e818:	lea    0x390(%rsp),%r14
  77e820:	mov    %r14,%rdi
  77e823:	call   74d540 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  77e828:	lea    0x2a8(%rsp),%rcx
  77e830:	movups (%rcx),%xmm0
  77e833:	movaps %xmm0,0x120(%rsp)
  77e83b:	mov    0x10(%rcx),%rax
  77e83f:	mov    %rax,0x130(%rsp)
  77e847:	movups (%rcx),%xmm0
  77e84a:	movaps %xmm0,0xc40(%rsp)
  77e852:	mov    0x10(%rcx),%rax
  77e856:	mov    %rax,0xc50(%rsp)
  77e85e:	movaps 0x170(%rsp),%xmm0
  77e866:	movaps %xmm0,0x390(%rsp)
  77e86e:	movzbl %bpl,%r9d
  77e872:	lea    0x970(%rsp),%rdi
  77e87a:	mov    %rbx,%rsi
  77e87d:	lea    0x370(%rsp),%rdx
  77e885:	lea    0xc40(%rsp),%rcx
  77e88d:	mov    %r14,%r8
  77e890:	mov    0x30(%rsp),%r14
  77e895:	movss  0x74(%rsp),%xmm0
  77e89b:	call   *0x33ac0f(%rip)        # ab94b0 <_DYNAMIC+0x850>
  77e8a1:	cmp    $0xffffffff,%eax
  77e8a4:	jne    780022 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4be2>
  77e8aa:	mov    0x18(%r14,%r13,1),%ebx
  77e8af:	cmpb   $0x0,0x2f(%rsp)
  77e8b4:	je     77e8de <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x349e>
  77e8b6:	cmp    $0xffffffff,%ebx
  77e8b9:	je     77e8d9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3499>
  77e8bb:	mov    0x110(%rsp),%rsi
  77e8c3:	cmp    %rbx,%rsi
  77e8c6:	jbe    780535 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x50f5>
  77e8cc:	mov    0x108(%rsp),%rax
  77e8d4:	mov    (%rax,%rbx,4),%ebx
  77e8d7:	jmp    77e8de <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x349e>
  77e8d9:	mov    $0xffffffff,%ebx
  77e8de:	cmpb   $0x0,0x60(%rsp)
  77e8e3:	je     77e9cf <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x358f>
  77e8e9:	movss  0x298(%rsp),%xmm0
  77e8f2:	xorps  %xmm1,%xmm1
  77e8f5:	ucomiss %xmm1,%xmm0
  77e8f8:	jne    77e8fc <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x34bc>
  77e8fa:	jnp    77e914 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x34d4>
  77e8fc:	movss  0x29c(%rsp),%xmm0
  77e905:	ucomiss %xmm1,%xmm0
  77e908:	jne    77e9cf <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x358f>
  77e90e:	jp     77e9cf <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x358f>
  77e914:	cmpb   $0x0,0x1d4(%rsp)
  77e91c:	je     77e946 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3506>
  77e91e:	movss  0x1b8(%rsp),%xmm0
  77e927:	ucomiss %xmm1,%xmm0
  77e92a:	jne    77e92e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x34ee>
  77e92c:	jnp    77e946 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3506>
  77e92e:	movss  0x1bc(%rsp),%xmm0
  77e937:	ucomiss %xmm1,%xmm0
  77e93a:	jne    77e9cf <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x358f>
  77e940:	jp     77e9cf <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x358f>
  77e946:	test   %r12b,%r12b
  77e949:	je     77e96b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x352b>
  77e94b:	movss  0x1b8(%rsp),%xmm0
  77e954:	ucomiss %xmm1,%xmm0
  77e957:	jne    77e95b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x351b>
  77e959:	jnp    77e96b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x352b>
  77e95b:	movss  0x1bc(%rsp),%xmm0
  77e964:	ucomiss %xmm1,%xmm0
  77e967:	jne    77e9cf <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x358f>
  77e969:	jp     77e9cf <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x358f>
  77e96b:	mov    0x110(%rsp),%r14
  77e973:	cmp    0x100(%rsp),%r14
  77e97b:	jne    77e98a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x354a>
  77e97d:	lea    0x100(%rsp),%rdi
  77e985:	call   772030 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtCslbxve4rcJus_4gpui7runtime6ParentE8grow_oneCs9C2G9YFESsD_29canonical_text_public_control>
  77e98a:	mov    0x108(%rsp),%rax
  77e992:	mov    %ebx,(%rax,%r14,4)
  77e996:	inc    %r14
  77e999:	mov    %r14,0x110(%rsp)
  77e9a1:	mov    0x1f8(%rsp),%rax
  77e9a9:	test   %rax,%rax
  77e9ac:	je     77d116 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1cd6>
  77e9b2:	lock decq (%rax)
  77e9b6:	jne    77d116 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1cd6>
  77e9bc:	lea    0x1f8(%rsp),%rdi
  77e9c4:	call   *0x33a5f6(%rip)        # ab8fc0 <_DYNAMIC+0x360>
  77e9ca:	jmp    77d116 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1cd6>
  77e9cf:	mov    0x20(%r14,%r13,1),%edi
  77e9d4:	mov    $0x1,%r12b
  77e9d7:	call   775950 <_RNvMsh_NtCslbxve4rcJus_4gpui7runtimeNtB5_4Node4kind>
  77e9dc:	cmp    $0x7,%al
  77e9de:	jne    77e9f9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x35b9>
  77e9e0:	mov    0x30(%rsp),%rax
  77e9e5:	mov    (%rax,%r13,1),%rsi
  77e9e9:	mov    $0x1,%r12b
  77e9ec:	lea    0x6a8(%rsp),%rdi
  77e9f4:	call   77a3c0 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapyNtNtB7_7set_val9SetValZSTE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  77e9f9:	cmpb   $0x0,0x2f(%rsp)
  77e9fe:	je     77ea51 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3611>
  77ea00:	mov    0x150(%rsp),%rsi
  77ea08:	mov    $0x1,%edi
  77ea0d:	mov    $0x1,%r12b
  77ea10:	call   *0x33a4ca(%rip)        # ab8ee0 <_DYNAMIC+0x280>
  77ea16:	mov    %eax,%ebp
  77ea18:	mov    0x110(%rsp),%r14
  77ea20:	cmp    0x100(%rsp),%r14
  77ea28:	jne    77ea3a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x35fa>
  77ea2a:	mov    $0x1,%r12b
  77ea2d:	lea    0x100(%rsp),%rdi
  77ea35:	call   772030 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtCslbxve4rcJus_4gpui7runtime6ParentE8grow_oneCs9C2G9YFESsD_29canonical_text_public_control>
  77ea3a:	mov    0x108(%rsp),%rax
  77ea42:	mov    %ebp,(%rax,%r14,4)
  77ea46:	inc    %r14
  77ea49:	mov    %r14,0x110(%rsp)
  77ea51:	movss  0x298(%rsp),%xmm0
  77ea5a:	xor    %edx,%edx
  77ea5c:	xorps  %xmm1,%xmm1
  77ea5f:	ucomiss %xmm1,%xmm0
  77ea62:	jne    77ea6a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x362a>
  77ea64:	jnp    77eaf1 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x36b1>
  77ea6a:	movss  0x29c(%rsp),%xmm0
  77ea73:	ucomiss %xmm1,%xmm0
  77ea76:	mov    $0x0,%ebp
  77ea7b:	mov    0x30(%rsp),%rsi
  77ea80:	jne    77ea84 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3644>
  77ea82:	jnp    77eaf3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x36b3>
  77ea84:	mov    0x20(%rsi,%r13,1),%edi
  77ea89:	mov    %edi,%eax
  77ea8b:	and    $0xf,%eax
  77ea8e:	cmp    $0x9,%eax
  77ea91:	ja     7804aa <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x506a>
  77ea97:	cmp    $0x6,%eax
  77ea9a:	je     77eaa4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3664>
  77ea9c:	mov    $0x1,%bpl
  77ea9f:	cmp    $0xf,%edi
  77eaa2:	ja     77eaf3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x36b3>
  77eaa4:	mov    0x348(%rsp),%eax
  77eaab:	mov    $0x3fffffff,%ecx
  77eab0:	and    %ecx,%eax
  77eab2:	cmp    $0x3f800001,%eax
  77eab7:	mov    $0x80000000,%ecx
  77eabc:	cmove  %ecx,%eax
  77eabf:	movd   %eax,%xmm0
  77eac3:	mov    $0x1,%bpl
  77eac6:	ucomiss %xmm1,%xmm0
  77eac9:	ja     77eaf3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x36b3>
  77eacb:	cmpq   $0x0,0x8(%rsi,%r13,1)
  77ead1:	jne    77eaf3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x36b3>
  77ead3:	mov    $0x1,%r12b
  77ead6:	call   775950 <_RNvMsh_NtCslbxve4rcJus_4gpui7runtimeNtB5_4Node4kind>
  77eadb:	lea    -0x4(%rax),%ecx
  77eade:	cmp    $0x2,%al
  77eae0:	setae  %al
  77eae3:	test   $0xfb,%cl
  77eae6:	sete   %bpl
  77eaea:	and    %al,%bpl
  77eaed:	xor    %edx,%edx
  77eaef:	jmp    77eaf3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x36b3>
  77eaf1:	xor    %ebp,%ebp
  77eaf3:	mov    0x150(%rsp),%rax
  77eafb:	test   %rax,%rax
  77eafe:	je     77eb15 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x36d5>
  77eb00:	mov    0x148(%rsp),%rcx
  77eb08:	shl    $0x6,%rax
  77eb0c:	mov    -0x8(%rcx,%rax,1),%ecx
  77eb10:	mov    $0x1,%edx
  77eb15:	mov    %ebp,%eax
  77eb17:	xor    $0x1,%al
  77eb19:	movzbl %al,%esi
  77eb1c:	mov    $0x1,%r12b
  77eb1f:	mov    %ebx,%edi
  77eb21:	call   *0x33a991(%rip)        # ab94b8 <_DYNAMIC+0x858>
  77eb27:	mov    %eax,0x2c0(%rsp)
  77eb2e:	mov    0x1f8(%rsp),%rax
  77eb36:	test   %rax,%rax
  77eb39:	sete   0x60(%rsp)
  77eb3e:	je     77eb80 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3740>
  77eb40:	mov    0x150(%rsp),%ecx
  77eb47:	mov    %ecx,0x3a0(%rsp)
  77eb4e:	movsd  0x1f0(%rsp),%xmm0
  77eb57:	movsd  %xmm0,0x398(%rsp)
  77eb60:	mov    %rax,0x390(%rsp)
  77eb68:	xor    %r12d,%r12d
  77eb6b:	lea    0x200(%rsp),%rdi
  77eb73:	lea    0x390(%rsp),%rsi
  77eb7b:	call   775280 <_RNvMsF_NtCscdodAO9FK5_5alloc3vecINtB5_3VecNtNtNtCslbxve4rcJus_4gpui7runtime13text_geometry5EntryE8push_mutCs9C2G9YFESsD_29canonical_text_public_control>
  77eb80:	cmp    $0xffffffff,%ebx
  77eb83:	je     77ebb8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3778>
  77eb85:	mov    %ebx,%ebx
  77eb87:	mov    0x150(%rsp),%rsi
  77eb8f:	cmp    %rbx,%rsi
  77eb92:	jbe    7805b7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5177>
  77eb98:	mov    0x148(%rsp),%rax
  77eba0:	shl    $0x6,%rbx
  77eba4:	mov    0x30(%rax,%rbx,1),%rax
  77eba9:	mov    %rax,0x394(%rsp)
  77ebb1:	mov    $0x1,%eax
  77ebb6:	jmp    77ebba <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x377a>
  77ebb8:	xor    %eax,%eax
  77ebba:	mov    %eax,0x390(%rsp)
  77ebc1:	movzbl 0x60(%rsp),%eax
  77ebc6:	mov    %eax,%r12d
  77ebc9:	lea    0x2a4(%rsp),%rdi
  77ebd1:	lea    0x390(%rsp),%rsi
  77ebd9:	lea    0x268(%rsp),%rdx
  77ebe1:	call   *0x33a8d9(%rip)        # ab94c0 <_DYNAMIC+0x860>
  77ebe7:	mov    %rax,%rbx
  77ebea:	mov    0x30(%rsp),%rax
  77ebef:	mov    (%rax,%r13,1),%r14
  77ebf3:	mov    0x20(%rax,%r13,1),%edi
  77ebf8:	movzbl 0x60(%rsp),%eax
  77ebfd:	mov    %eax,%r12d
  77ec00:	call   775950 <_RNvMsh_NtCslbxve4rcJus_4gpui7runtimeNtB5_4Node4kind>
  77ec05:	mov    %eax,%r15d
  77ec08:	mov    0x30(%rsp),%rax
  77ec0d:	mov    0x20(%rax,%r13,1),%edi
  77ec12:	mov    %edi,%eax
  77ec14:	and    $0xf,%eax
  77ec17:	cmp    $0x9,%eax
  77ec1a:	ja     78048c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x504c>
  77ec20:	cmp    $0x6,%eax
  77ec23:	je     77f061 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3c21>
  77ec29:	shr    $0x4,%edi
  77ec2c:	dec    %edi
  77ec2e:	mov    0x40(%rsp),%rax
  77ec33:	mov    0x2f0(%rax),%rsi
  77ec3a:	mov    0x2f8(%rax),%rdx
  77ec41:	movzbl 0x60(%rsp),%eax
  77ec46:	mov    %eax,%r12d
  77ec49:	call   7757f0 <_RNvMsf_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSlot3get>
  77ec4e:	mov    %ebp,0x74(%rsp)
  77ec52:	test   %rax,%rax
  77ec55:	je     77ec89 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3849>
  77ec57:	mov    0x40(%rax),%rbp
  77ec5b:	testb  $0x1,0x0(%rbp)
  77ec5f:	jne    77ec8b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x384b>
  77ec61:	mov    0x8(%rbp),%rax
  77ec65:	test   $0x1,%al
  77ec67:	jne    77ec8b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x384b>
  77ec69:	mov    $0x2,%eax
  77ec6e:	lock xadd %rax,0x8(%rbp)
  77ec74:	and    0x888(%rsp),%rax
  77ec7c:	neg    %rax
  77ec7f:	jno    77ec8b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x384b>
  77ec81:	lock orq $0x1,0x8(%rbp)
  77ec87:	jmp    77ec8b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x384b>
  77ec89:	xor    %ebp,%ebp
  77ec8b:	movdqa 0x630(%rsp),%xmm0
  77ec94:	movd   %xmm0,%esi
  77ec98:	shufps $0x55,%xmm0,%xmm0
  77ec9c:	movd   %xmm0,%eax
  77eca0:	shl    $0x20,%rax
  77eca4:	or     %rax,%rsi
  77eca7:	lea    0x180(%rsp),%rdi
  77ecaf:	lea    0x2a4(%rsp),%rdx
  77ecb7:	call   *0x33a80b(%rip)        # ab94c8 <_DYNAMIC+0x868>
  77ecbd:	mov    0x30(%rsp),%r12
  77ecc2:	mov    0x20(%r12,%r13,1),%edi
  77ecc7:	call   775950 <_RNvMsh_NtCslbxve4rcJus_4gpui7runtimeNtB5_4Node4kind>
  77eccc:	xor    %esi,%esi
  77ecce:	cmpq   $0x0,0x8(%r12,%r13,1)
  77ecd4:	setne  %sil
  77ecd8:	movzbl %al,%edi
  77ecdb:	call   7755a0 <_RNvMs_NtNtCslbxve4rcJus_4gpui7runtime9semanticsNtB4_7Actions8for_node>
  77ece0:	mov    0x18(%r12,%r13,1),%ecx
  77ece5:	mov    $0xffffffff,%edx
  77ecea:	cmp    %rdx,%rcx
  77eced:	je     77ed23 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x38e3>
  77ecef:	cmp    %rcx,0x168(%rsp)
  77ecf7:	mov    0x2c0(%rsp),%esi
  77ecfe:	jbe    77ed1a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x38da>
  77ed00:	mov    0x160(%rsp),%rdx
  77ed08:	cmpb   $0x0,(%rdx,%rcx,1)
  77ed0c:	setne  %cl
  77ed0f:	mov    0xbc(%rsp),%edx
  77ed16:	or     %cl,%dl
  77ed18:	jmp    77ed31 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x38f1>
  77ed1a:	mov    0xbc(%rsp),%edx
  77ed21:	jmp    77ed31 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x38f1>
  77ed23:	mov    0xbc(%rsp),%edx
  77ed2a:	mov    0x2c0(%rsp),%esi
  77ed31:	movzbl %al,%ecx
  77ed34:	or     $0x20,%al
  77ed36:	movzbl %al,%eax
  77ed39:	test   %dl,%dl
  77ed3b:	cmove  %ecx,%eax
  77ed3e:	mov    %r14,0x3b0(%rsp)
  77ed46:	mov    %esi,0x3c8(%rsp)
  77ed4d:	mov    %r15b,0x3cd(%rsp)
  77ed55:	mov    %rbp,0x3b8(%rsp)
  77ed5d:	movups 0x180(%rsp),%xmm0
  77ed65:	movaps %xmm0,0x390(%rsp)
  77ed6d:	mov    %rbx,0x3c0(%rsp)
  77ed75:	movups 0x290(%rsp),%xmm0
  77ed7d:	lea    0x394(%rsp),%rcx
  77ed85:	movups %xmm0,0xc(%rcx)
  77ed89:	mov    0x74(%rsp),%ecx
  77ed8d:	mov    %cl,0x3ce(%rsp)
  77ed94:	mov    %al,0x3cc(%rsp)
  77ed9b:	movzbl 0x60(%rsp),%eax
  77eda0:	mov    %eax,%r12d
  77eda3:	lea    0x140(%rsp),%rdi
  77edab:	lea    0x390(%rsp),%rsi
  77edb3:	call   775200 <_RNvMsF_NtCscdodAO9FK5_5alloc3vecINtB5_3VecNtNtCslbxve4rcJus_4gpui7runtime9PresentedE8push_mutCs9C2G9YFESsD_29canonical_text_public_control>
  77edb8:	cmpb   $0x2,0x690(%rsp)
  77edc0:	je     77efe4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3ba4>
  77edc6:	mov    0x150(%rsp),%rsi
  77edce:	lea    -0x1(%rsi),%rbx
  77edd2:	mov    0x40(%rsp),%rax
  77edd7:	cmp    0x5c0(%rax),%rbx
  77edde:	jae    77ee21 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x39e1>
  77ede0:	mov    0x5b8(%rax),%r14
  77ede7:	movzbl 0x60(%rsp),%eax
  77edec:	mov    %eax,%r12d
  77edef:	lea    0xb98(%rsp),%rdi
  77edf7:	call   *0x33a553(%rip)        # ab9350 <_DYNAMIC+0x6f0>
  77edfd:	mov    %rax,0x878(%rsp)
  77ee05:	mov    %rdx,0x880(%rsp)
  77ee0d:	mov    %rbx,%rax
  77ee10:	shl    $0x6,%rax
  77ee14:	add    %rax,%r14
  77ee17:	mov    0x150(%rsp),%rsi
  77ee1f:	jmp    77ee24 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x39e4>
  77ee21:	xor    %r14d,%r14d
  77ee24:	cmp    %rsi,%rbx
  77ee27:	jae    7805a8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5168>
  77ee2d:	mov    %rbx,%rax
  77ee30:	shl    $0x6,%rax
  77ee34:	add    0x148(%rsp),%rax
  77ee3c:	movups 0x270(%rsp),%xmm0
  77ee44:	mov    %r14,0x198(%rsp)
  77ee4c:	mov    0x878(%rsp),%rcx
  77ee54:	mov    %rcx,0x1a0(%rsp)
  77ee5c:	mov    0x880(%rsp),%rcx
  77ee64:	mov    %rcx,0x1a8(%rsp)
  77ee6c:	mov    %rax,0x180(%rsp)
  77ee74:	movups %xmm0,0x188(%rsp)
  77ee7c:	mov    0x40(%rsp),%rcx
  77ee81:	mov    0x650(%rcx),%rax
  77ee88:	mov    %rax,0x120(%rsp)
  77ee90:	mov    0x678(%rsp),%rax
  77ee98:	mov    %rax,0x128(%rsp)
  77eea0:	mov    0x2f0(%rsp),%eax
  77eea7:	lea    0x130(%rsp),%rdx
  77eeaf:	mov    %eax,0x8(%rdx)
  77eeb2:	mov    0x2e8(%rsp),%rax
  77eeba:	mov    %rax,(%rdx)
  77eebd:	movzbl 0x57(%rsp),%eax
  77eec2:	mov    %al,0x13c(%rsp)
  77eec9:	movzbl 0x7c(%rsp),%eax
  77eece:	mov    %al,0xf(%rdx)
  77eed1:	movzwl 0x7a(%rsp),%eax
  77eed6:	mov    %ax,0xd(%rdx)
  77eeda:	mov    0x6e8(%rcx),%rdi
  77eee1:	test   %rdi,%rdi
  77eee4:	je     77eefc <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3abc>
  77eee6:	movzbl 0x60(%rsp),%eax
  77eeeb:	mov    %eax,%r12d
  77eeee:	mov    %rbx,%rsi
  77eef1:	call   *0x33a5d9(%rip)        # ab94d0 <_DYNAMIC+0x870>
  77eef7:	mov    %rax,%r15
  77eefa:	jmp    77eeff <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3abf>
  77eefc:	xor    %r15d,%r15d
  77eeff:	mov    0x210(%rsp),%rax
  77ef07:	test   %rax,%rax
  77ef0a:	mov    0x30(%rsp),%rsi
  77ef0f:	je     77ef47 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3b07>
  77ef11:	mov    0x208(%rsp),%rcx
  77ef19:	lea    (%rax,%rax,2),%rdx
  77ef1d:	lea    (%rcx,%rdx,8),%rax
  77ef21:	add    $0xffffffffffffffe8,%rax
  77ef25:	mov    $0x0,%ebp
  77ef2a:	test   %rax,%rax
  77ef2d:	je     77ef49 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3b09>
  77ef2f:	lea    (%rcx,%rdx,8),%rcx
  77ef33:	mov    -0x8(%rcx),%ecx
  77ef36:	cmp    %rcx,%rbx
  77ef39:	mov    $0x0,%ecx
  77ef3e:	cmovne %rcx,%rax
  77ef42:	mov    %rax,%rbp
  77ef45:	jmp    77ef49 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3b09>
  77ef47:	xor    %ebp,%ebp
  77ef49:	mov    (%rsi,%r13,1),%rdx
  77ef4d:	cvtps2pd 0x630(%rsp),%xmm0
  77ef55:	movaps %xmm0,0x370(%rsp)
  77ef5d:	movzbl 0x60(%rsp),%eax
  77ef62:	mov    %eax,%r12d
  77ef65:	lea    0x390(%rsp),%rdi
  77ef6d:	lea    0x6c0(%rsp),%rsi
  77ef75:	lea    0x370(%rsp),%rcx
  77ef7d:	call   *0x33a555(%rip)        # ab94d8 <_DYNAMIC+0x878>
  77ef83:	mov    0x30(%rsp),%rax
  77ef88:	mov    (%rax,%r13,1),%rdx
  77ef8c:	mov    0x40(%rsp),%rax
  77ef91:	mov    0x670(%rax),%rdi
  77ef98:	mov    0x678(%rax),%rsi
  77ef9f:	call   744780 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyNtNtNtCslbxve4rcJus_4gpui7runtime4list7ListRowE3getyECs9C2G9YFESsD_29canonical_text_public_control>
  77efa4:	mov    %rax,0x8(%rsp)
  77efa9:	lea    0x390(%rsp),%rax
  77efb1:	mov    %rax,(%rsp)
  77efb5:	movzbl 0x60(%rsp),%eax
  77efba:	mov    %eax,%r12d
  77efbd:	lea    0x688(%rsp),%rdi
  77efc5:	mov    %rbx,%rsi
  77efc8:	lea    0x180(%rsp),%rdx
  77efd0:	mov    %r15,%r8
  77efd3:	mov    %rbp,%r9
  77efd6:	lea    0x120(%rsp),%rcx
  77efde:	call   *0x33a4fc(%rip)        # ab94e0 <_DYNAMIC+0x880>
  77efe4:	cmpl   $0xffffffff,0x810(%rsp)
  77efec:	je     77f041 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3c01>
  77efee:	mov    0xf0(%rsp),%rax
  77eff6:	mov    (%rax),%rbx
  77eff9:	test   %rbx,%rbx
  77effc:	je     77f041 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3c01>
  77effe:	mov    0x30(%rsp),%rax
  77f003:	mov    (%rax,%r13,1),%r15
  77f007:	mov    0x40(%rsp),%rax
  77f00c:	mov    0x670(%rax),%rdi
  77f013:	mov    0x678(%rax),%rsi
  77f01a:	mov    %r15,%rdx
  77f01d:	call   744780 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyNtNtNtCslbxve4rcJus_4gpui7runtime4list7ListRowE3getyECs9C2G9YFESsD_29canonical_text_public_control>
  77f022:	movzbl 0x60(%rsp),%ecx
  77f027:	mov    %ecx,%r12d
  77f02a:	lea    0x810(%rsp),%rdi
  77f032:	mov    %rbx,%rsi
  77f035:	mov    %r15,%rdx
  77f038:	mov    %rax,%rcx
  77f03b:	call   *0x33a2b7(%rip)        # ab92f8 <_DYNAMIC+0x698>
  77f041:	mov    0x38(%rsp),%rcx
  77f046:	inc    %rcx
  77f049:	cmp    0x660(%rsp),%rcx
  77f051:	lea    0x180(%rsp),%r15
  77f059:	jb     77d0f2 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1cb2>
  77f05f:	jmp    77f06b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3c2b>
  77f061:	mov    $0xffffffff,%edi
  77f066:	jmp    77ec2e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x37ee>
  77f06b:	cmpl   $0xffffffff,0x810(%rsp)
  77f073:	mov    0x40(%rsp),%r14
  77f078:	mov    0xf8(%rsp),%rbx
  77f080:	je     77f090 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3c50>
  77f082:	lea    0x810(%rsp),%rdi
  77f08a:	call   *0x33a270(%rip)        # ab9300 <_DYNAMIC+0x6a0>
  77f090:	movzbl 0x690(%rsp),%eax
  77f098:	cmp    $0x2,%al
  77f09a:	je     77f0eb <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3cab>
  77f09c:	mov    0x688(%rsp),%rdi
  77f0a4:	mov    0x6a0(%r14),%rcx
  77f0ab:	mov    0x260(%rsp),%rdx
  77f0b3:	mov    %rdx,0x390(%rsp)
  77f0bb:	mov    %rcx,0x398(%rsp)
  77f0c3:	mov    %rbx,0x3a0(%rsp)
  77f0cb:	mov    0x5c0(%r14),%rcx
  77f0d2:	mov    0x150(%rsp),%r8
  77f0da:	movzbl %al,%esi
  77f0dd:	lea    0x390(%rsp),%rdx
  77f0e5:	call   *0x33a21d(%rip)        # ab9308 <_DYNAMIC+0x6a8>
  77f0eb:	lea    0x1e8(%r14),%rbx
  77f0f2:	mov    0x650(%r14),%rax
  77f0f9:	test   %rax,%rax
  77f0fc:	je     77f1dc <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3d9c>
  77f102:	mov    0x100(%rax),%rdx
  77f109:	lea    0x268(%rsp),%rax
  77f111:	mov    %rax,0x390(%rsp)
  77f119:	lea    0x2f(%rsp),%rax
  77f11e:	mov    %rax,0x398(%rsp)
  77f126:	mov    %rbx,0x3a0(%rsp)
  77f12e:	lea    0x100(%rsp),%rax
  77f136:	mov    %rax,0x3a8(%rsp)
  77f13e:	lea    0x140(%rsp),%rax
  77f146:	mov    %rax,0x3b0(%rsp)
  77f14e:	test   %rdx,%rdx
  77f151:	je     77f1dc <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3d9c>
  77f157:	lea    0x310(%rsp),%rdi
  77f15f:	lea    0x390(%rsp),%rsi
  77f167:	call   75db20 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_>
  77f16c:	mov    0x320(%rsp),%rax
  77f174:	mov    %rax,0x7a0(%rsp)
  77f17c:	movups 0x310(%rsp),%xmm0
  77f184:	movaps %xmm0,0x790(%rsp)
  77f18c:	jmp    77f1e8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3da8>
  77f18e:	movaps 0x970(%rsp),%xmm0
  77f196:	movaps 0x980(%rsp),%xmm1
  77f19e:	movaps 0x990(%rsp),%xmm2
  77f1a6:	mov    0x48(%rsp),%rcx
  77f1ab:	movups %xmm2,0x28(%rcx)
  77f1af:	movups %xmm1,0x18(%rcx)
  77f1b3:	movups %xmm0,0x8(%rcx)
  77f1b7:	mov    %rax,(%rcx)
  77f1ba:	mov    $0x1,%r12b
  77f1bd:	mov    $0x1,%bl
  77f1bf:	mov    $0x1,%r13b
  77f1c2:	mov    $0x1,%bpl
  77f1c5:	mov    $0x1,%r15b
  77f1c8:	cmpq   $0xffffffffffffffff,0x258(%rsp)
  77f1d1:	jne    7800d6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c96>
  77f1d7:	jmp    7800e6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4ca6>
  77f1dc:	movq   $0xffffffffffffffff,0x790(%rsp)
  77f1e8:	mov    %rbx,0x60(%rsp)
  77f1ed:	mov    0x278(%rsp),%rax
  77f1f5:	mov    %rax,0x3a0(%rsp)
  77f1fd:	movups 0x268(%rsp),%xmm0
  77f205:	movaps %xmm0,0x390(%rsp)
  77f20d:	lea    0x180(%rsp),%rdi
  77f215:	lea    0x790(%rsp),%rsi
  77f21d:	lea    0x390(%rsp),%rdx
  77f225:	call   73d2a0 <_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime8geometry6RecordEE7or_elseNCNvMsu_B1i_INtB1i_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersE_0EB2E_>
  77f22a:	cmpb   $0x0,0x76d(%r14)
  77f232:	je     77f28f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3e4f>
  77f234:	lea    0x390(%rsp),%rbx
  77f23c:	lea    0x970(%rsp),%rsi
  77f244:	mov    $0x1f0,%edx
  77f249:	mov    %rbx,%rdi
  77f24c:	call   *0x339c6e(%rip)        # ab8ec0 <memcpy@GLIBC_2.14>
  77f252:	mov    $0x1,%al
  77f254:	mov    %eax,0x58(%rsp)
  77f258:	mov    $0x1,%r12b
  77f25b:	mov    $0x1,%al
  77f25d:	mov    %eax,0x38(%rsp)
  77f261:	mov    $0x1,%al
  77f263:	mov    %eax,0x30(%rsp)
  77f267:	mov    $0x1,%r15b
  77f26a:	mov    $0x1,%bpl
  77f26d:	movb   $0x1,0xc0(%rsp)
  77f275:	mov    %rbx,%rdi
  77f278:	call   *0x33a26a(%rip)        # ab94e8 <_DYNAMIC+0x888>
  77f27e:	movq   $0x0,0x80(%rsp)
  77f28a:	jmp    77f322 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3ee2>
  77f28f:	lea    0x390(%rsp),%rbx
  77f297:	lea    0x970(%rsp),%rsi
  77f29f:	mov    $0x1f0,%edx
  77f2a4:	mov    %rbx,%rdi
  77f2a7:	call   *0x339c13(%rip)        # ab8ec0 <memcpy@GLIBC_2.14>
  77f2ad:	mov    $0x1,%al
  77f2af:	mov    %eax,0x58(%rsp)
  77f2b3:	mov    $0x1,%r12b
  77f2b6:	mov    $0x1,%al
  77f2b8:	mov    %eax,0x38(%rsp)
  77f2bc:	mov    $0x1,%al
  77f2be:	mov    %eax,0x30(%rsp)
  77f2c2:	mov    $0x1,%r15b
  77f2c5:	mov    $0x1,%bpl
  77f2c8:	movb   $0x1,0xc0(%rsp)
  77f2d0:	mov    %rbx,%rdi
  77f2d3:	call   *0x33a217(%rip)        # ab94f0 <_DYNAMIC+0x890>
  77f2d9:	cmpq   $0xffffffffffffffff,0x5c8(%r14)
  77f2e1:	je     77f2ec <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3eac>
  77f2e3:	mov    0x5e0(%r14),%rsi
  77f2ea:	jmp    77f2ee <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3eae>
  77f2ec:	xor    %esi,%esi
  77f2ee:	mov    $0x1,%cl
  77f2f0:	mov    %ecx,0x58(%rsp)
  77f2f4:	mov    $0x1,%r12b
  77f2f7:	mov    $0x1,%cl
  77f2f9:	mov    %ecx,0x38(%rsp)
  77f2fd:	mov    $0x1,%cl
  77f2ff:	mov    %ecx,0x30(%rsp)
  77f303:	mov    $0x1,%r15b
  77f306:	mov    $0x1,%bpl
  77f309:	movb   $0x1,0xc0(%rsp)
  77f311:	mov    %rax,%rdi
  77f314:	call   *0x339f96(%rip)        # ab92b0 <_DYNAMIC+0x650>
  77f31a:	mov    %rax,0x80(%rsp)
  77f322:	mov    0x658(%r14),%rax
  77f329:	mov    0x668(%r14),%r12
  77f330:	test   %rax,%rax
  77f333:	setne  %cl
  77f336:	test   %r12,%r12
  77f339:	setne  %dl
  77f33c:	test   %dl,%cl
  77f33e:	je     77f52e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x40ee>
  77f344:	mov    0x40(%rsp),%rcx
  77f349:	mov    0x660(%rcx),%r13
  77f350:	xor    %r14d,%r14d
  77f353:	lea    0x390(%rsp),%rbx
  77f35b:	lea    0x6c0(%rsp),%r15
  77f363:	jmp    77f373 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3f33>
  77f365:	mov    $0x0,%eax
  77f36a:	dec    %r12
  77f36d:	je     77f52e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x40ee>
  77f373:	test   %r14,%r14
  77f376:	jne    77f3f8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3fb8>
  77f37c:	test   %r13,%r13
  77f37f:	je     77f3a7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3f67>
  77f381:	mov    %r13,%rcx
  77f384:	mov    %rax,%r14
  77f387:	and    $0x7,%rcx
  77f38b:	je     77f3ac <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3f6c>
  77f38d:	xor    %edx,%edx
  77f38f:	nop
  77f390:	mov    0x590(%r14),%r14
  77f397:	inc    %rdx
  77f39a:	cmp    %rdx,%rcx
  77f39d:	jne    77f390 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3f50>
  77f39f:	mov    %r13,%rax
  77f3a2:	sub    %rdx,%rax
  77f3a5:	jmp    77f3af <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3f6f>
  77f3a7:	mov    %rax,%r14
  77f3aa:	jmp    77f3f3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3fb3>
  77f3ac:	mov    %r13,%rax
  77f3af:	cmp    $0x8,%r13
  77f3b3:	jb     77f3f3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3fb3>
  77f3b5:	mov    0x590(%r14),%rcx
  77f3bc:	mov    0x590(%rcx),%rcx
  77f3c3:	mov    0x590(%rcx),%rcx
  77f3ca:	mov    0x590(%rcx),%rcx
  77f3d1:	mov    0x590(%rcx),%rcx
  77f3d8:	mov    0x590(%rcx),%rcx
  77f3df:	mov    0x590(%rcx),%rcx
  77f3e6:	mov    0x590(%rcx),%r14
  77f3ed:	add    $0xfffffffffffffff8,%rax
  77f3f1:	jne    77f3b5 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3f75>
  77f3f3:	xor    %r13d,%r13d
  77f3f6:	xor    %eax,%eax
  77f3f8:	movzwl 0x58a(%r14),%ecx
  77f400:	cmp    %rcx,%r13
  77f403:	jae    77f410 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3fd0>
  77f405:	mov    %r13,%rdx
  77f408:	mov    %r14,%rcx
  77f40b:	jmp    77f437 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3ff7>
  77f40d:	nopl   (%rax)
  77f410:	mov    0x580(%r14),%rcx
  77f417:	test   %rcx,%rcx
  77f41a:	je     7803c5 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4f85>
  77f420:	inc    %rax
  77f423:	movzwl 0x588(%r14),%edx
  77f42b:	mov    %rcx,%r14
  77f42e:	cmp    0x58a(%rcx),%dx
  77f435:	jae    77f410 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3fd0>
  77f437:	test   %rax,%rax
  77f43a:	je     77f47a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x403a>
  77f43c:	lea    (%rcx,%rdx,8),%rsi
  77f440:	add    $0x598,%rsi
  77f447:	mov    %rax,%rdi
  77f44a:	and    $0x7,%rdi
  77f44e:	je     77f483 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4043>
  77f450:	xor    %r8d,%r8d
  77f453:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  77f460:	mov    (%rsi),%r14
  77f463:	lea    0x590(%r14),%rsi
  77f46a:	inc    %r8
  77f46d:	cmp    %r8,%rdi
  77f470:	jne    77f460 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4020>
  77f472:	mov    %rax,%rdi
  77f475:	sub    %r8,%rdi
  77f478:	jmp    77f486 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4046>
  77f47a:	lea    0x1(%rdx),%r13
  77f47e:	mov    %rcx,%r14
  77f481:	jmp    77f4d4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4094>
  77f483:	mov    %rax,%rdi
  77f486:	cmp    $0x8,%rax
  77f48a:	jb     77f4d1 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4091>
  77f48c:	nopl   0x0(%rax)
  77f490:	mov    (%rsi),%rax
  77f493:	mov    0x590(%rax),%rax
  77f49a:	mov    0x590(%rax),%rax
  77f4a1:	mov    0x590(%rax),%rax
  77f4a8:	mov    0x590(%rax),%rax
  77f4af:	mov    0x590(%rax),%rax
  77f4b6:	mov    0x590(%rax),%rax
  77f4bd:	mov    0x590(%rax),%r14
  77f4c4:	lea    0x590(%r14),%rsi
  77f4cb:	add    $0xfffffffffffffff8,%rdi
  77f4cf:	jne    77f490 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4050>
  77f4d1:	xor    %r13d,%r13d
  77f4d4:	mov    %rdx,%rax
  77f4d7:	shl    $0x4,%rax
  77f4db:	cmpl   $0x1,(%rcx,%rax,1)
  77f4df:	jne    77f365 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3f25>
  77f4e5:	imul   $0x70,%rdx,%rdx
  77f4e9:	lea    (%rcx,%rdx,1),%rbp
  77f4ed:	add    $0xb0,%rbp
  77f4f4:	cmpl   $0x2,0x0(%rbp)
  77f4f8:	jne    77f365 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3f25>
  77f4fe:	mov    0x8(%rcx,%rax,1),%rdx
  77f503:	mov    %rbx,%rdi
  77f506:	mov    %r15,%rsi
  77f509:	call   *0x339f49(%rip)        # ab9458 <_DYNAMIC+0x7f8>
  77f50f:	cmpl   $0x1,0x390(%rsp)
  77f517:	jne    77f365 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3f25>
  77f51d:	movups 0x398(%rsp),%xmm0
  77f525:	movups %xmm0,0x8(%rbp)
  77f529:	jmp    77f365 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3f25>
  77f52e:	mov    0x40(%rsp),%r13
  77f533:	mov    0x670(%r13),%r8
  77f53a:	mov    0x680(%r13),%rax
  77f541:	test   %r8,%r8
  77f544:	setne  %cl
  77f547:	test   %rax,%rax
  77f54a:	setne  %dl
  77f54d:	test   %dl,%cl
  77f54f:	mov    0xf0(%rsp),%rbx
  77f557:	je     77f77d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x433d>
  77f55d:	mov    0x678(%r13),%rsi
  77f564:	xor    %ecx,%ecx
  77f566:	jmp    77f590 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4150>
  77f568:	mov    $0x1,%r8b
  77f56b:	mov    0xf0(%rsp),%rbx
  77f573:	dec    %rax
  77f576:	shl    $0x5,%rdi
  77f57a:	add    %rdi,%rdx
  77f57d:	mov    %r8b,0x1c(%rdx)
  77f581:	mov    $0x0,%r8d
  77f587:	test   %rax,%rax
  77f58a:	je     77f77d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x433d>
  77f590:	test   %rcx,%rcx
  77f593:	jne    77f618 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x41d8>
  77f599:	test   %rsi,%rsi
  77f59c:	je     77f5c7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4187>
  77f59e:	mov    %rsi,%rdx
  77f5a1:	mov    %r8,%rcx
  77f5a4:	and    $0x7,%rdx
  77f5a8:	je     77f5cc <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x418c>
  77f5aa:	xor    %edi,%edi
  77f5ac:	nopl   0x0(%rax)
  77f5b0:	mov    0x1c8(%rcx),%rcx
  77f5b7:	inc    %rdi
  77f5ba:	cmp    %rdi,%rdx
  77f5bd:	jne    77f5b0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4170>
  77f5bf:	mov    %rsi,%rdx
  77f5c2:	sub    %rdi,%rdx
  77f5c5:	jmp    77f5cf <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x418f>
  77f5c7:	mov    %r8,%rcx
  77f5ca:	jmp    77f613 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x41d3>
  77f5cc:	mov    %rsi,%rdx
  77f5cf:	cmp    $0x8,%rsi
  77f5d3:	jb     77f613 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x41d3>
  77f5d5:	mov    0x1c8(%rcx),%rcx
  77f5dc:	mov    0x1c8(%rcx),%rcx
  77f5e3:	mov    0x1c8(%rcx),%rcx
  77f5ea:	mov    0x1c8(%rcx),%rcx
  77f5f1:	mov    0x1c8(%rcx),%rcx
  77f5f8:	mov    0x1c8(%rcx),%rcx
  77f5ff:	mov    0x1c8(%rcx),%rcx
  77f606:	mov    0x1c8(%rcx),%rcx
  77f60d:	add    $0xfffffffffffffff8,%rdx
  77f611:	jne    77f5d5 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4195>
  77f613:	xor    %esi,%esi
  77f615:	xor    %r8d,%r8d
  77f618:	movzwl 0x1c2(%rcx),%edx
  77f61f:	cmp    %rdx,%rsi
  77f622:	jae    77f630 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x41f0>
  77f624:	mov    %rsi,%rdi
  77f627:	mov    %rcx,%rdx
  77f62a:	jmp    77f656 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4216>
  77f62c:	nopl   0x0(%rax)
  77f630:	mov    0x160(%rcx),%rdx
  77f637:	test   %rdx,%rdx
  77f63a:	je     7803d7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4f97>
  77f640:	inc    %r8
  77f643:	movzwl 0x1c0(%rcx),%edi
  77f64a:	mov    %rdx,%rcx
  77f64d:	cmp    0x1c2(%rdx),%di
  77f654:	jae    77f630 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x41f0>
  77f656:	test   %r8,%r8
  77f659:	je     77f69a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x425a>
  77f65b:	lea    (%rdx,%rdi,8),%rsi
  77f65f:	add    $0x1d0,%rsi
  77f666:	mov    %r8,%r9
  77f669:	and    $0x7,%r9
  77f66d:	je     77f6a3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4263>
  77f66f:	xor    %r10d,%r10d
  77f672:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  77f680:	mov    (%rsi),%rcx
  77f683:	lea    0x1c8(%rcx),%rsi
  77f68a:	inc    %r10
  77f68d:	cmp    %r10,%r9
  77f690:	jne    77f680 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4240>
  77f692:	mov    %r8,%r9
  77f695:	sub    %r10,%r9
  77f698:	jmp    77f6a6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4266>
  77f69a:	lea    0x1(%rdi),%rsi
  77f69e:	mov    %rdx,%rcx
  77f6a1:	jmp    77f6f3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x42b3>
  77f6a3:	mov    %r8,%r9
  77f6a6:	cmp    $0x8,%r8
  77f6aa:	jb     77f6f1 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x42b1>
  77f6ac:	nopl   0x0(%rax)
  77f6b0:	mov    (%rsi),%rcx
  77f6b3:	mov    0x1c8(%rcx),%rcx
  77f6ba:	mov    0x1c8(%rcx),%rcx
  77f6c1:	mov    0x1c8(%rcx),%rcx
  77f6c8:	mov    0x1c8(%rcx),%rcx
  77f6cf:	mov    0x1c8(%rcx),%rcx
  77f6d6:	mov    0x1c8(%rcx),%rcx
  77f6dd:	mov    0x1c8(%rcx),%rcx
  77f6e4:	lea    0x1c8(%rcx),%rsi
  77f6eb:	add    $0xfffffffffffffff8,%r9
  77f6ef:	jne    77f6b0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4270>
  77f6f1:	xor    %esi,%esi
  77f6f3:	mov    0x6a8(%rsp),%r8
  77f6fb:	test   %r8,%r8
  77f6fe:	je     77f775 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4335>
  77f700:	mov    0x168(%rdx,%rdi,8),%r9
  77f708:	mov    0x6b0(%rsp),%r10
  77f710:	movzwl 0x62(%r8),%ebx
  77f715:	mov    %ebx,%r14d
  77f718:	shl    $0x3,%r14d
  77f71c:	mov    $0xffffffffffffffff,%r11
  77f723:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  77f730:	test   %r14,%r14
  77f733:	je     77f75d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x431d>
  77f735:	cmp    0x10(%r8,%r11,8),%r9
  77f73a:	seta   %bpl
  77f73e:	sbb    $0x0,%bpl
  77f742:	inc    %r11
  77f745:	add    $0xfffffffffffffff8,%r14
  77f749:	cmp    $0x1,%bpl
  77f74d:	je     77f730 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x42f0>
  77f74f:	movzbl %bpl,%ebx
  77f753:	test   %ebx,%ebx
  77f755:	je     77f568 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4128>
  77f75b:	jmp    77f760 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4320>
  77f75d:	mov    %rbx,%r11
  77f760:	mov    0xf0(%rsp),%rbx
  77f768:	sub    $0x1,%r10
  77f76c:	jb     77f775 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4335>
  77f76e:	mov    0x68(%r8,%r11,8),%r8
  77f773:	jmp    77f710 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x42d0>
  77f775:	xor    %r8d,%r8d
  77f778:	jmp    77f573 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4133>
  77f77d:	cmpl   $0x2,0xca0(%rsp)
  77f785:	mov    $0x1,%bpl
  77f788:	je     77f7c5 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4385>
  77f78a:	lea    0x390(%rsp),%rdi
  77f792:	lea    0xca0(%rsp),%rsi
  77f79a:	mov    $0x1e8,%edx
  77f79f:	call   *0x33971b(%rip)        # ab8ec0 <memcpy@GLIBC_2.14>
  77f7a5:	mov    %r13,%rdi
  77f7a8:	call   74d050 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas6canvas6CanvasECs9C2G9YFESsD_29canonical_text_public_control>
  77f7ad:	lea    0x390(%rsp),%rsi
  77f7b5:	mov    $0x1e8,%edx
  77f7ba:	mov    %r13,%rdi
  77f7bd:	call   *0x3396fd(%rip)        # ab8ec0 <memcpy@GLIBC_2.14>
  77f7c3:	xor    %ebp,%ebp
  77f7c5:	mov    $0x1,%al
  77f7c7:	mov    %eax,0x58(%rsp)
  77f7cb:	cmpl   $0xffffffff,0x810(%rsp)
  77f7d3:	mov    $0x1,%al
  77f7d5:	mov    %eax,0x30(%rsp)
  77f7d9:	je     77f978 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4538>
  77f7df:	movups 0x860(%rsp),%xmm0
  77f7e7:	movaps %xmm0,0x760(%rsp)
  77f7ef:	movups 0x850(%rsp),%xmm0
  77f7f7:	movaps %xmm0,0x750(%rsp)
  77f7ff:	movups 0x810(%rsp),%xmm0
  77f807:	movups 0x820(%rsp),%xmm1
  77f80f:	movups 0x830(%rsp),%xmm2
  77f817:	movupd 0x840(%rsp),%xmm3
  77f820:	movapd %xmm3,0x740(%rsp)
  77f829:	movaps %xmm2,0x730(%rsp)
  77f831:	movaps %xmm1,0x720(%rsp)
  77f839:	movaps %xmm0,0x710(%rsp)
  77f841:	cmpq   $0x0,(%rbx)
  77f845:	je     77f949 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4509>
  77f84b:	mov    0x60(%rsp),%rax
  77f850:	mov    %rax,0x390(%rsp)
  77f858:	lea    0x100(%rsp),%rax
  77f860:	mov    %rax,0x398(%rsp)
  77f868:	lea    0x140(%rsp),%rax
  77f870:	mov    %rax,0x3a0(%rsp)
  77f878:	lea    0x310(%rsp),%rdi
  77f880:	lea    0x6c0(%rsp),%rsi
  77f888:	lea    0x390(%rsp),%rdx
  77f890:	call   73fa80 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_>
  77f895:	lea    0x710(%rsp),%rdi
  77f89d:	call   74e5e0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime6scroll14ViewportColumnECs9C2G9YFESsD_29canonical_text_public_control>
  77f8a2:	mov    0x320(%rsp),%rax
  77f8aa:	mov    %rax,0x720(%rsp)
  77f8b2:	movups 0x310(%rsp),%xmm0
  77f8ba:	movaps %xmm0,0x710(%rsp)
  77f8c2:	mov    (%rbx),%rdi
  77f8c5:	cmpl   $0xffffffff,0x60(%rdi)
  77f8c9:	je     77f8d7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4497>
  77f8cb:	add    $0x60,%rdi
  77f8cf:	call   74e9d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime8metadata5SheetECs9C2G9YFESsD_29canonical_text_public_control>
  77f8d4:	mov    (%rbx),%rdi
  77f8d7:	movaps 0x760(%rsp),%xmm0
  77f8df:	movups %xmm0,0xb0(%rdi)
  77f8e6:	movaps 0x750(%rsp),%xmm0
  77f8ee:	movups %xmm0,0xa0(%rdi)
  77f8f5:	movaps 0x710(%rsp),%xmm0
  77f8fd:	mov    0x720(%rsp),%rax
  77f905:	mov    0x728(%rsp),%rcx
  77f90d:	movaps 0x730(%rsp),%xmm1
  77f915:	movaps 0x740(%rsp),%xmm2
  77f91d:	movups %xmm2,0x90(%rdi)
  77f924:	movups %xmm1,0x80(%rdi)
  77f92b:	mov    %rax,0x70(%rdi)
  77f92f:	mov    %rcx,0x78(%rdi)
  77f933:	movups %xmm0,0x60(%rdi)
  77f937:	movl   $0x0,0x58(%rsp)
  77f93f:	movl   $0x0,0x30(%rsp)
  77f947:	jmp    77f978 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4538>
  77f949:	mov    $0x1,%al
  77f94b:	mov    %eax,0x58(%rsp)
  77f94f:	movl   $0x0,0x30(%rsp)
  77f957:	lea    0x710(%rsp),%rdi
  77f95f:	mov    $0x1,%r12b
  77f962:	mov    $0x1,%al
  77f964:	mov    %eax,0x38(%rsp)
  77f968:	mov    $0x1,%r15b
  77f96b:	movb   $0x1,0xc0(%rsp)
  77f973:	call   74e9d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime8metadata5SheetECs9C2G9YFESsD_29canonical_text_public_control>
  77f978:	mov    0x180(%rsp),%r15
  77f980:	cmp    $0xffffffffffffffff,%r15
  77f984:	sete   0xc0(%rsp)
  77f98c:	je     77f9ef <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x45af>
  77f98e:	mov    0x188(%rsp),%r13
  77f996:	mov    0x190(%rsp),%r14
  77f99e:	mov    %rbx,%rdi
  77f9a1:	call   73d4b0 <_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionINtNtCscdodAO9FK5_5alloc5boxed3BoxNtNtNtCslbxve4rcJus_4gpui7runtime8metadata8MetadataEE18get_or_insert_withNvYBI_NtNtB5_7default7Default7defaultECs9C2G9YFESsD_29canonical_text_public_control>
  77f9a6:	mov    %rbx,%rax
  77f9a9:	mov    $0x100,%ebx
  77f9ae:	add    (%rax),%rbx
  77f9b1:	mov    %rbx,%rdi
  77f9b4:	call   73d310 <_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionINtNtCscdodAO9FK5_5alloc5boxed3BoxNtNtNtCslbxve4rcJus_4gpui7runtime8geometry8GeometryEE18get_or_insert_withNvYBI_NtNtB5_7default7Default7defaultECs9C2G9YFESsD_29canonical_text_public_control>
  77f9b9:	mov    (%rbx),%rdi
  77f9bc:	mov    %r15,0x390(%rsp)
  77f9c4:	mov    %r13,0x398(%rsp)
  77f9cc:	mov    %r14,0x3a0(%rsp)
  77f9d4:	lea    0x390(%rsp),%rsi
  77f9dc:	call   *0x339b16(%rip)        # ab94f8 <_DYNAMIC+0x898>
  77f9e2:	mov    0x40(%rsp),%r13
  77f9e7:	mov    0xf0(%rsp),%rbx
  77f9ef:	cmpq   $0xffffffffffffffff,0x258(%rsp)
  77f9f8:	je     77fa29 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x45e9>
  77f9fa:	mov    0x2d8(%rsp),%rax
  77fa02:	mov    (%rax),%rdi
  77fa05:	test   %rdi,%rdi
  77fa08:	je     7803a7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4f67>
  77fa0e:	lea    0x8b8(%rsp),%rdx
  77fa16:	mov    0x260(%rsp),%rsi
  77fa1e:	call   *0x339adc(%rip)        # ab9500 <_DYNAMIC+0x8a0>
  77fa24:	xor    %r14d,%r14d
  77fa27:	jmp    77fa2c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x45ec>
  77fa29:	mov    $0x1,%r14b
  77fa2c:	mov    0xa8(%rsp),%rax
  77fa34:	cmpl   $0x3,(%rax)
  77fa37:	jne    77fa48 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4608>
  77fa39:	mov    0x208(%r13),%rax
  77fa40:	movq   $0x0,0x58(%rax)
  77fa48:	mov    (%rbx),%rax
  77fa4b:	test   %rax,%rax
  77fa4e:	je     77fa97 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4657>
  77fa50:	mov    0xe0(%rax),%rax
  77fa57:	test   %rax,%rax
  77fa5a:	je     77fa97 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4657>
  77fa5c:	mov    0x678(%rsp),%rcx
  77fa64:	mov    %rcx,0x40(%rax)
  77fa68:	mov    0x2e8(%rsp),%rcx
  77fa70:	mov    %rcx,0x48(%rax)
  77fa74:	mov    0x2f0(%rsp),%ecx
  77fa7b:	mov    %ecx,0x50(%rax)
  77fa7e:	movzbl 0x57(%rsp),%ecx
  77fa83:	mov    %cl,0x54(%rax)
  77fa86:	movzwl 0x7a(%rsp),%ecx
  77fa8b:	mov    %cx,0x55(%rax)
  77fa8f:	movzbl 0x7c(%rsp),%ecx
  77fa94:	mov    %cl,0x57(%rax)
  77fa97:	mov    0x6e8(%r13),%rdi
  77fa9e:	test   %rdi,%rdi
  77faa1:	mov    %r14d,0x38(%rsp)
  77faa6:	je     77fadc <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x469c>
  77faa8:	cmpq   $0xffffffffffffffff,0x18(%rdi)
  77faad:	je     77fabf <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x467f>
  77faaf:	add    $0x18,%rdi
  77fab3:	call   747680 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime13text_geometry5EntryEECs9C2G9YFESsD_29canonical_text_public_control>
  77fab8:	mov    0x6e8(%r13),%rdi
  77fabf:	mov    0x210(%rsp),%rax
  77fac7:	mov    %rax,0x28(%rdi)
  77facb:	movups 0x200(%rsp),%xmm0
  77fad3:	movups %xmm0,0x18(%rdi)
  77fad7:	xor    %r12d,%r12d
  77fada:	jmp    77fadf <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x469f>
  77fadc:	mov    $0x1,%r12b
  77fadf:	mov    0x150(%rsp),%rax
  77fae7:	mov    %rax,0x3a0(%rsp)
  77faef:	movups 0x140(%rsp),%xmm0
  77faf7:	movaps %xmm0,0x390(%rsp)
  77faff:	lea    0x5c8(%r13),%r15
  77fb06:	cmpq   $0xffffffffffffffff,0x5c8(%r13)
  77fb0e:	je     77fb18 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x46d8>
  77fb10:	mov    %r15,%rdi
  77fb13:	call   747220 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCslbxve4rcJus_4gpui7runtime9PresentedEECs9C2G9YFESsD_29canonical_text_public_control>
  77fb18:	mov    0x3a0(%rsp),%rax
  77fb20:	mov    %rax,0x10(%r15)
  77fb24:	movaps 0x390(%rsp),%xmm0
  77fb2c:	movups %xmm0,(%r15)
  77fb30:	mov    0x80(%rsp),%rax
  77fb38:	mov    %rax,0x5e0(%r13)
  77fb3f:	mov    0xf8(%rsp),%rax
  77fb47:	mov    %ax,0x5e8(%r13)
  77fb4f:	mov    0x2e0(%rsp),%rax
  77fb57:	mov    %ax,0x5ea(%r13)
  77fb5f:	movss  0x9c(%rsp),%xmm0
  77fb68:	movss  %xmm0,0x5ec(%r13)
  77fb71:	xor    %r15d,%r15d
  77fb74:	mov    %r13,%rdi
  77fb77:	call   76e870 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11prune_focusBW_>
  77fb7c:	mov    0x680(%rsp),%rax
  77fb84:	mov    %rax,0x6d0(%r13)
  77fb8b:	mov    0x260(%rsp),%rax
  77fb93:	mov    %rax,0x6d8(%r13)
  77fb9a:	mov    0x6a0(%r13),%rax
  77fba1:	mov    0x6e8(%r13),%rdi
  77fba8:	mov    %rax,0x6e0(%r13)
  77fbaf:	mov    0x8b0(%rsp),%rax
  77fbb7:	mov    %rax,0x5f8(%r13)
  77fbbe:	cmpq   $0x0,0x2f8(%r13)
  77fbc6:	setne  %al
  77fbc9:	test   %rdi,%rdi
  77fbcc:	sete   %cl
  77fbcf:	or     %al,%cl
  77fbd1:	cmp    $0x1,%cl
  77fbd4:	je     77fbee <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x47ae>
  77fbd6:	add    $0x30,%rdi
  77fbda:	call   745d30 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtCsghYClfd3M9V_11gpui_canvas4text10TextSystemEECs9C2G9YFESsD_29canonical_text_public_control>
  77fbdf:	mov    0x6e8(%r13),%rax
  77fbe6:	movq   $0x0,0x30(%rax)
  77fbee:	movb   $0x0,0x76b(%r13)
  77fbf6:	movw   $0x0,0x768(%r13)
  77fc00:	lea    0x688(%r13),%rdi
  77fc07:	xor    %r15d,%r15d
  77fc0a:	call   775980 <_RNvMsh_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapyNtNtB7_7set_val9SetValZSTE5clearCs9C2G9YFESsD_29canonical_text_public_control>
  77fc0f:	cmpb   $0x0,0x76d(%r13)
  77fc17:	je     77fc4e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x480e>
  77fc19:	xor    %r15d,%r15d
  77fc1c:	lea    0x390(%rsp),%rdi
  77fc24:	mov    %r13,%rsi
  77fc27:	mov    0x680(%rsp),%rdx
  77fc2f:	mov    0x260(%rsp),%rcx
  77fc37:	call   77ae10 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_>
  77fc3c:	mov    0x390(%rsp),%rax
  77fc44:	cmp    $0xfffffffffffffffe,%rax
  77fc48:	jne    77fd86 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4946>
  77fc4e:	mov    0x48(%rsp),%rax
  77fc53:	movq   $0xfffffffffffffffe,(%rax)
  77fc5a:	cmpb   $0x0,0x58(%rsp)
  77fc5f:	je     77fc6e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x482e>
  77fc61:	lea    0x6c0(%rsp),%rdi
  77fc69:	call   74e590 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime6scroll13ViewportBuildECs9C2G9YFESsD_29canonical_text_public_control>
  77fc6e:	xor    %r13d,%r13d
  77fc71:	lea    0x6a8(%rsp),%rdi
  77fc79:	call   74ac30 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtCscdodAO9FK5_5alloc11collections5btree3set8BTreeSetNtNtCslbxve4rcJus_4gpui4list6ListIdEECs9C2G9YFESsD_29canonical_text_public_control>
  77fc7e:	mov    0x100(%rsp),%rsi
  77fc86:	test   %rsi,%rsi
  77fc89:	je     77fca2 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4862>
  77fc8b:	mov    0x108(%rsp),%rdi
  77fc93:	shl    $0x2,%rsi
  77fc97:	mov    $0x4,%edx
  77fc9c:	call   *0x3391fe(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  77fca2:	mov    0x158(%rsp),%rsi
  77fcaa:	test   %rsi,%rsi
  77fcad:	je     77fcc2 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4882>
  77fcaf:	mov    0x160(%rsp),%rdi
  77fcb7:	mov    $0x1,%edx
  77fcbc:	call   *0x3391de(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  77fcc2:	mov    0x230(%rsp),%rsi
  77fcca:	test   %rsi,%rsi
  77fccd:	je     77fce6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x48a6>
  77fccf:	mov    0x238(%rsp),%rdi
  77fcd7:	shl    $0x4,%rsi
  77fcdb:	mov    $0x4,%edx
  77fce0:	call   *0x3391ba(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  77fce6:	mov    0x218(%rsp),%rsi
  77fcee:	test   %rsi,%rsi
  77fcf1:	je     77fd0a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x48ca>
  77fcf3:	mov    0x220(%rsp),%rdi
  77fcfb:	shl    $0x4,%rsi
  77fcff:	mov    $0x4,%edx
  77fd04:	call   *0x339196(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  77fd0a:	mov    0x1d8(%rsp),%rax
  77fd12:	test   %rax,%rax
  77fd15:	je     77fd2e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x48ee>
  77fd17:	mov    0x1e0(%rsp),%rdi
  77fd1f:	imul   $0x38,%rax,%rsi
  77fd23:	mov    $0x8,%edx
  77fd28:	call   *0x339172(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  77fd2e:	cmpq   $0x0,0x1c0(%rsp)
  77fd37:	je     77fd46 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4906>
  77fd39:	mov    0x1c8(%rsp),%rdi
  77fd41:	call   74cab0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text10TextShaperECs9C2G9YFESsD_29canonical_text_public_control>
  77fd46:	test   %r12b,%r12b
  77fd49:	je     77fd58 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4918>
  77fd4b:	lea    0x200(%rsp),%rdi
  77fd53:	call   747680 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime13text_geometry5EntryEECs9C2G9YFESsD_29canonical_text_public_control>
  77fd58:	mov    0xd0(%rsp),%rax
  77fd60:	test   %rax,%rax
  77fd63:	je     77cc81 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1841>
  77fd69:	lock decq (%rax)
  77fd6d:	jne    77cc81 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1841>
  77fd73:	lea    0xd0(%rsp),%rdi
  77fd7b:	call   *0x33920f(%rip)        # ab8f90 <_DYNAMIC+0x330>
  77fd81:	jmp    77cc81 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1841>
  77fd86:	mov    0x3b8(%rsp),%rcx
  77fd8e:	movzbl 0x3c0(%rsp),%edx
  77fd96:	mov    0x3c1(%rsp),%esi
  77fd9d:	mov    %esi,0x310(%rsp)
  77fda4:	mov    0x3c4(%rsp),%esi
  77fdab:	mov    %esi,0x313(%rsp)
  77fdb2:	movups 0x398(%rsp),%xmm0
  77fdba:	movups 0x3a8(%rsp),%xmm1
  77fdc2:	mov    0x310(%rsp),%esi
  77fdc9:	mov    0x313(%rsp),%edi
  77fdd0:	mov    0x48(%rsp),%r8
  77fdd5:	mov    %edi,0x34(%r8)
  77fdd9:	mov    %esi,0x31(%r8)
  77fddd:	mov    %rax,(%r8)
  77fde0:	movups %xmm0,0x8(%r8)
  77fde5:	movups %xmm1,0x18(%r8)
  77fdea:	mov    %rcx,0x28(%r8)
  77fdee:	mov    %dl,0x30(%r8)
  77fdf2:	xor    %r13d,%r13d
  77fdf5:	cmpb   $0x0,0x58(%rsp)
  77fdfa:	mov    0x30(%rsp),%ebx
  77fdfe:	mov    0x38(%rsp),%r14d
  77fe03:	jne    7800b5 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c75>
  77fe09:	jmp    7800c2 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c82>
  77fe0e:	movzbl 0x391(%rsp),%eax
  77fe16:	mov    0x48(%rsp),%rcx
  77fe1b:	movq   $0x22,(%rcx)
  77fe22:	mov    %al,0x8(%rcx)
  77fe25:	jmp    78009a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c5a>
  77fe2a:	mov    0x48(%rsp),%rax
  77fe2f:	movq   $0x1f,(%rax)
  77fe36:	jmp    77cc81 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1841>
  77fe3b:	lea    0x394(%rsp),%rcx
  77fe43:	mov    0x14(%rcx),%rax
  77fe47:	movups 0x4(%rcx),%xmm0
  77fe4b:	movaps %xmm0,0x120(%rsp)
  77fe53:	mov    %rax,0x130(%rsp)
  77fe5b:	mov    0x48(%rsp),%rcx
  77fe60:	mov    %rax,0x18(%rcx)
  77fe64:	movups %xmm0,0x8(%rcx)
  77fe68:	movq   $0x23,(%rcx)
  77fe6f:	jmp    78009a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c5a>
  77fe74:	mov    0x48(%rsp),%rcx
  77fe79:	movq   $0x23,(%rcx)
  77fe80:	mov    %eax,0x8(%rcx)
  77fe83:	mov    %edx,0xc(%rcx)
  77fe86:	jmp    78009a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c5a>
  77fe8b:	mov    0x3c0(%rsp),%rcx
  77fe93:	mov    0x48(%rsp),%rdx
  77fe98:	mov    %rcx,0x30(%rdx)
  77fe9c:	movups 0x3a0(%rsp),%xmm0
  77fea4:	movups 0x3b0(%rsp),%xmm1
  77feac:	movups %xmm1,0x20(%rdx)
  77feb0:	movups %xmm0,0x10(%rdx)
  77feb4:	mov    %rax,(%rdx)
  77feb7:	mov    %r15,0x8(%rdx)
  77febb:	jmp    78009a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c5a>
  77fec0:	mov    0x3c0(%rsp),%rax
  77fec8:	mov    0x48(%rsp),%rcx
  77fecd:	mov    %rax,0x30(%rcx)
  77fed1:	movups 0x390(%rsp),%xmm0
  77fed9:	movups 0x3a0(%rsp),%xmm1
  77fee1:	movups 0x3b0(%rsp),%xmm2
  77fee9:	movups %xmm2,0x20(%rcx)
  77feed:	movups %xmm1,0x10(%rcx)
  77fef1:	movups %xmm0,(%rcx)
  77fef4:	jmp    78009a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c5a>
  77fef9:	mov    0x30(%rsp),%rax
  77fefe:	mov    0x20(%rax,%r13,1),%esi
  77ff03:	lea    0x390(%rsp),%rdi
  77ff0b:	lea    0x8d0(%rsp),%rdx
  77ff13:	call   75e0d0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersn_0BQ_>
  77ff18:	mov    0x3c0(%rsp),%rax
  77ff20:	mov    %rax,0x900(%rsp)
  77ff28:	movups 0x390(%rsp),%xmm0
  77ff30:	movups 0x3a0(%rsp),%xmm1
  77ff38:	movups 0x3b0(%rsp),%xmm2
  77ff40:	movaps %xmm2,0x8f0(%rsp)
  77ff48:	movaps %xmm1,0x8e0(%rsp)
  77ff50:	movaps %xmm0,0x8d0(%rsp)
  77ff58:	mov    0x8d0(%rsp),%rax
  77ff60:	mov    0x8f8(%rsp),%rcx
  77ff68:	mov    0x48(%rsp),%rdx
  77ff6d:	mov    %rcx,0x28(%rdx)
  77ff71:	mov    0x900(%rsp),%rcx
  77ff79:	mov    %rcx,0x30(%rdx)
  77ff7d:	lea    0x8d8(%rsp),%rcx
  77ff85:	movups (%rcx),%xmm0
  77ff88:	movups 0x10(%rcx),%xmm1
  77ff8c:	movups %xmm0,0x8(%rdx)
  77ff90:	movups %xmm1,0x18(%rdx)
  77ff94:	mov    %rax,(%rdx)
  77ff97:	jmp    78009a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c5a>
  77ff9c:	mov    0x48(%rsp),%rcx
  77ffa1:	movq   $0x23,(%rcx)
  77ffa8:	mov    %eax,0x8(%rcx)
  77ffab:	mov    %edx,0xc(%rcx)
  77ffae:	jmp    78007e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c3e>
  77ffb3:	lea    0x394(%rsp),%rcx
  77ffbb:	mov    0x14(%rcx),%rax
  77ffbf:	movups 0x4(%rcx),%xmm0
  77ffc3:	movaps %xmm0,0x120(%rsp)
  77ffcb:	mov    %rax,0x130(%rsp)
  77ffd3:	mov    0x48(%rsp),%rcx
  77ffd8:	mov    %rax,0x18(%rcx)
  77ffdc:	movups %xmm0,0x8(%rcx)
  77ffe0:	movq   $0x23,(%rcx)
  77ffe7:	jmp    78007e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c3e>
  77ffec:	lea    0x394(%rsp),%rcx
  77fff4:	mov    0x14(%rcx),%rax
  77fff8:	movups 0x4(%rcx),%xmm0
  77fffc:	movaps %xmm0,0x120(%rsp)
  780004:	mov    %rax,0x130(%rsp)
  78000c:	mov    0x48(%rsp),%rcx
  780011:	mov    %rax,0x18(%rcx)
  780015:	movups %xmm0,0x8(%rcx)
  780019:	movq   $0x23,(%rcx)
  780020:	jmp    780034 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4bf4>
  780022:	mov    0x48(%rsp),%rcx
  780027:	movq   $0x23,(%rcx)
  78002e:	mov    %eax,0x8(%rcx)
  780031:	mov    %edx,0xc(%rcx)
  780034:	mov    0x1f8(%rsp),%rax
  78003c:	test   %rax,%rax
  78003f:	je     78009a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c5a>
  780041:	lock decq (%rax)
  780045:	jne    78009a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c5a>
  780047:	lea    0x1f8(%rsp),%rdi
  78004f:	call   *0x338f6b(%rip)        # ab8fc0 <_DYNAMIC+0x360>
  780055:	jmp    78009a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c5a>
  780057:	mov    0x48(%rsp),%rax
  78005c:	movq   $0x18,(%rax)
  780063:	jmp    78007e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c3e>
  780065:	mov    0x124(%rsp),%ecx
  78006c:	mov    0x48(%rsp),%rdx
  780071:	movq   $0x23,(%rdx)
  780078:	mov    %eax,0x8(%rdx)
  78007b:	mov    %ecx,0xc(%rdx)
  78007e:	mov    0x300(%rsp),%rax
  780086:	lock decq (%rax)
  78008a:	jne    78009a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c5a>
  78008c:	lea    0x300(%rsp),%rdi
  780094:	call   *0x338f26(%rip)        # ab8fc0 <_DYNAMIC+0x360>
  78009a:	lea    0x970(%rsp),%rdi
  7800a2:	call   74d050 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas6canvas6CanvasECs9C2G9YFESsD_29canonical_text_public_control>
  7800a7:	mov    $0x1,%r12b
  7800aa:	mov    $0x1,%r14b
  7800ad:	mov    $0x1,%bl
  7800af:	mov    $0x1,%r13b
  7800b2:	mov    $0x1,%bpl
  7800b5:	lea    0x6c0(%rsp),%rdi
  7800bd:	call   74e590 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime6scroll13ViewportBuildECs9C2G9YFESsD_29canonical_text_public_control>
  7800c2:	cmpq   $0xffffffffffffffff,0x258(%rsp)
  7800cb:	setne  %al
  7800ce:	mov    %r13d,%r15d
  7800d1:	test   %r14b,%al
  7800d4:	je     7800e6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4ca6>
  7800d6:	lea    0x8b8(%rsp),%rdi
  7800de:	call   746e60 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCsghYClfd3M9V_11gpui_canvas5image5ImageEECs9C2G9YFESsD_29canonical_text_public_control>
  7800e3:	mov    %r15d,%r13d
  7800e6:	cmpl   $0xffffffff,0x810(%rsp)
  7800ee:	je     780101 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4cc1>
  7800f0:	test   %bl,%bl
  7800f2:	je     780101 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4cc1>
  7800f4:	lea    0x810(%rsp),%rdi
  7800fc:	call   74e9d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime8metadata5SheetECs9C2G9YFESsD_29canonical_text_public_control>
  780101:	lea    0x6a8(%rsp),%rdi
  780109:	call   74ac30 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtCscdodAO9FK5_5alloc11collections5btree3set8BTreeSetNtNtCslbxve4rcJus_4gpui4list6ListIdEECs9C2G9YFESsD_29canonical_text_public_control>
  78010e:	mov    0x100(%rsp),%rsi
  780116:	test   %rsi,%rsi
  780119:	je     780132 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4cf2>
  78011b:	mov    0x108(%rsp),%rdi
  780123:	shl    $0x2,%rsi
  780127:	mov    $0x4,%edx
  78012c:	call   *0x338d6e(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  780132:	mov    0x158(%rsp),%rsi
  78013a:	test   %rsi,%rsi
  78013d:	je     780152 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4d12>
  78013f:	mov    0x160(%rsp),%rdi
  780147:	mov    $0x1,%edx
  78014c:	call   *0x338d4e(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  780152:	mov    0x230(%rsp),%rsi
  78015a:	test   %rsi,%rsi
  78015d:	je     780176 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4d36>
  78015f:	mov    0x238(%rsp),%rdi
  780167:	shl    $0x4,%rsi
  78016b:	mov    $0x4,%edx
  780170:	call   *0x338d2a(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  780176:	mov    0x218(%rsp),%rsi
  78017e:	test   %rsi,%rsi
  780181:	je     78019a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4d5a>
  780183:	mov    0x220(%rsp),%rdi
  78018b:	shl    $0x4,%rsi
  78018f:	mov    $0x4,%edx
  780194:	call   *0x338d06(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  78019a:	mov    0x1d8(%rsp),%rax
  7801a2:	test   %rax,%rax
  7801a5:	je     7801be <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4d7e>
  7801a7:	mov    0x1e0(%rsp),%rdi
  7801af:	imul   $0x38,%rax,%rsi
  7801b3:	mov    $0x8,%edx
  7801b8:	call   *0x338ce2(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  7801be:	test   %r13b,%r13b
  7801c1:	je     7801f4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4db4>
  7801c3:	mov    0x268(%rsp),%rsi
  7801cb:	test   %rsi,%rsi
  7801ce:	je     7801e7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4da7>
  7801d0:	mov    0x270(%rsp),%rdi
  7801d8:	shl    $0x4,%rsi
  7801dc:	mov    $0x4,%edx
  7801e1:	call   *0x338cb9(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  7801e7:	lea    0x140(%rsp),%rdi
  7801ef:	call   747220 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCslbxve4rcJus_4gpui7runtime9PresentedEECs9C2G9YFESsD_29canonical_text_public_control>
  7801f4:	mov    0x7c8(%rsp),%rax
  7801fc:	cmp    $0xfffffffffffffffe,%rax
  780200:	jne    77c851 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1411>
  780206:	jmp    77cc1a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17da>
  78020b:	lea    -0x6ad94a(%rip),%rdi        # d28c8 <GCC_except_table0+0x10560>
  780212:	lea    0x319ff7(%rip),%rdx        # a9a210 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1ad8>
  780219:	mov    $0x83,%esi
  78021e:	call   *0x338cb4(%rip)        # ab8ed8 <_DYNAMIC+0x278>
  780224:	jmp    7805c8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  780229:	lea    -0x6adbe8(%rip),%rdi        # d2648 <GCC_except_table0+0x102e0>
  780230:	lea    0x319b09(%rip),%rdx        # a99d40 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1608>
  780237:	mov    $0x1c,%esi
  78023c:	call   *0x338d36(%rip)        # ab8f78 <_DYNAMIC+0x318>
  780242:	jmp    7805c8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  780247:	mov    $0x1,%bpl
  78024a:	mov    $0x8,%edi
  78024f:	mov    $0x78,%esi
  780254:	call   *0x338c5e(%rip)        # ab8eb8 <_DYNAMIC+0x258>
  78025a:	jmp    7805c8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  78025f:	lea    0x318d6a(%rip),%rdi        # a98fd0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x898>
  780266:	call   *0x338cdc(%rip)        # ab8f48 <_DYNAMIC+0x2e8>
  78026c:	jmp    7805c8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  780271:	lea    -0x6ad96f(%rip),%rax        # d2909 <GCC_except_table0+0x105a1>
  780278:	mov    %rax,0x250(%rsp)
  780280:	lea    0x31a141(%rip),%rax        # a9a3c8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1c90>
  780287:	jmp    7802d3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4e93>
  780289:	lea    0x318e90(%rip),%rax        # a99120 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x9e8>
  780290:	mov    %rax,0x658(%rsp)
  780298:	mov    0x658(%rsp),%rdi
  7802a0:	call   *0x338ca2(%rip)        # ab8f48 <_DYNAMIC+0x2e8>
  7802a6:	jmp    7805c8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  7802ab:	lea    0x318d1e(%rip),%rdi        # a98fd0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x898>
  7802b2:	call   *0x338c90(%rip)        # ab8f48 <_DYNAMIC+0x2e8>
  7802b8:	jmp    7805c8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  7802bd:	lea    -0x6ad9bb(%rip),%rax        # d2909 <GCC_except_table0+0x105a1>
  7802c4:	mov    %rax,0x250(%rsp)
  7802cc:	lea    0x31a10d(%rip),%rax        # a9a3e0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1ca8>
  7802d3:	mov    %rax,0x248(%rsp)
  7802db:	jmp    780357 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4f17>
  7802dd:	mov    0x3a0(%rsp),%rsi
  7802e5:	mov    $0x1,%bpl
  7802e8:	call   *0x338c6a(%rip)        # ab8f58 <_DYNAMIC+0x2f8>
  7802ee:	jmp    7805c8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  7802f3:	mov    0x3a0(%rsp),%rsi
  7802fb:	call   *0x338c57(%rip)        # ab8f58 <_DYNAMIC+0x2f8>
  780301:	jmp    7805c8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  780306:	mov    0x3a0(%rsp),%rsi
  78030e:	call   *0x338c44(%rip)        # ab8f58 <_DYNAMIC+0x2f8>
  780314:	jmp    7805c8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  780319:	mov    0x3a0(%rsp),%rsi
  780321:	call   *0x338c31(%rip)        # ab8f58 <_DYNAMIC+0x2f8>
  780327:	jmp    7805c8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  78032c:	mov    0x3a0(%rsp),%rsi
  780334:	call   *0x338c1e(%rip)        # ab8f58 <_DYNAMIC+0x2f8>
  78033a:	jmp    7805c8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  78033f:	mov    0x3a0(%rsp),%rsi
  780347:	call   *0x338c0b(%rip)        # ab8f58 <_DYNAMIC+0x2f8>
  78034d:	jmp    7805c8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  780352:	mov    $0x1f,%esi
  780357:	mov    0x250(%rsp),%rdi
  78035f:	mov    0x248(%rsp),%rdx
  780367:	call   *0x338c0b(%rip)        # ab8f78 <_DYNAMIC+0x318>
  78036d:	jmp    7805c8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  780372:	lea    -0x6adab1(%rip),%rdi        # d28c8 <GCC_except_table0+0x10560>
  780379:	lea    0x319e90(%rip),%rdx        # a9a210 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1ad8>
  780380:	mov    $0x83,%esi
  780385:	call   *0x338b4d(%rip)        # ab8ed8 <_DYNAMIC+0x278>
  78038b:	jmp    7805c8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  780390:	movb   $0x1,0x60(%rsp)
  780395:	lea    0x31a074(%rip),%rdi        # a9a410 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1cd8>
  78039c:	call   *0x338ba6(%rip)        # ab8f48 <_DYNAMIC+0x2e8>
  7803a2:	jmp    7805c8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  7803a7:	lea    0x319f8a(%rip),%rdi        # a9a338 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1c00>
  7803ae:	call   *0x338b94(%rip)        # ab8f48 <_DYNAMIC+0x2e8>
  7803b4:	jmp    7805c8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  7803b9:	lea    0x318c58(%rip),%rax        # a99018 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x8e0>
  7803c0:	jmp    78044f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x500f>
  7803c5:	lea    0x318c1c(%rip),%rdi        # a98fe8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x8b0>
  7803cc:	call   *0x338b76(%rip)        # ab8f48 <_DYNAMIC+0x2e8>
  7803d2:	jmp    7805c8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  7803d7:	lea    0x318c0a(%rip),%rdi        # a98fe8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x8b0>
  7803de:	call   *0x338b64(%rip)        # ab8f48 <_DYNAMIC+0x2e8>
  7803e4:	jmp    7805c8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  7803e9:	lea    0x319ec0(%rip),%rax        # a9a2b0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1b78>
  7803f0:	jmp    78044f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x500f>
  7803f2:	lea    0x319ecf(%rip),%rax        # a9a2c8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1b90>
  7803f9:	jmp    78044f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x500f>
  7803fb:	lea    0x319756(%rip),%rax        # a99b58 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1420>
  780402:	jmp    78044f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x500f>
  780404:	lea    0x319735(%rip),%rax        # a99b40 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1408>
  78040b:	jmp    78044f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x500f>
  78040d:	mov    %rbp,%r12
  780410:	lea    0x319741(%rip),%rax        # a99b58 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1420>
  780417:	jmp    78044f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x500f>
  780419:	mov    %rax,%r12
  78041c:	jmp    780448 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5008>
  78041e:	mov    %rbp,%r12
  780421:	lea    0x319718(%rip),%rax        # a99b40 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1408>
  780428:	jmp    78044f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x500f>
  78042a:	mov    %rax,%r13
  78042d:	lea    0x31970c(%rip),%rax        # a99b40 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1408>
  780434:	jmp    78044f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x500f>
  780436:	mov    %rax,%r13
  780439:	lea    0x319718(%rip),%rax        # a99b58 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1420>
  780440:	jmp    78044f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x500f>
  780442:	mov    %rcx,%r12
  780445:	mov    %rax,%r13
  780448:	lea    0x319721(%rip),%rax        # a99b70 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1438>
  78044f:	mov    %rax,0x80(%rsp)
  780457:	mov    %r12,%rdi
  78045a:	mov    %r13,%rsi
  78045d:	mov    0x80(%rsp),%rdx
  780465:	call   *0x338a65(%rip)        # ab8ed0 <_DYNAMIC+0x270>
  78046b:	jmp    7805c8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  780470:	mov    $0x1,%r12b
  780473:	lea    0x319e7e(%rip),%rdx        # a9a2f8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1bc0>
  78047a:	mov    $0x1,%bpl
  78047d:	xor    %edi,%edi
  78047f:	xor    %esi,%esi
  780481:	call   *0x338a49(%rip)        # ab8ed0 <_DYNAMIC+0x270>
  780487:	jmp    7805c8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  78048c:	lea    -0x6adbcb(%rip),%rdi        # d28c8 <GCC_except_table0+0x10560>
  780493:	lea    0x319d76(%rip),%rdx        # a9a210 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1ad8>
  78049a:	mov    $0x83,%esi
  78049f:	call   *0x338a33(%rip)        # ab8ed8 <_DYNAMIC+0x278>
  7804a5:	jmp    7805c8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  7804aa:	movb   $0x1,0x60(%rsp)
  7804af:	lea    -0x6adbee(%rip),%rdi        # d28c8 <GCC_except_table0+0x10560>
  7804b6:	lea    0x319d53(%rip),%rdx        # a9a210 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1ad8>
  7804bd:	mov    $0x83,%esi
  7804c2:	call   *0x338a10(%rip)        # ab8ed8 <_DYNAMIC+0x278>
  7804c8:	jmp    7805c8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  7804cd:	mov    %rsi,%rax
  7804d0:	lea    0x319ea9(%rip),%rcx        # a9a380 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1c48>
  7804d7:	jmp    780588 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5148>
  7804dc:	mov    %rsi,%rax
  7804df:	lea    0x319eb2(%rip),%rcx        # a9a398 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1c60>
  7804e6:	jmp    780588 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5148>
  7804eb:	mov    %rsi,%rax
  7804ee:	lea    0x319ebb(%rip),%rcx        # a9a3b0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1c78>
  7804f5:	jmp    780588 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5148>
  7804fa:	mov    %rbx,0x38(%rsp)
  7804ff:	mov    %rsi,%rax
  780502:	lea    0x318be7(%rip),%rcx        # a990f0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x9b8>
  780509:	jmp    780588 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5148>
  78050b:	mov    %rcx,0x38(%rsp)
  780510:	lea    0x318bf1(%rip),%rcx        # a99108 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x9d0>
  780517:	jmp    780588 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5148>
  780519:	mov    %rdx,0x38(%rsp)
  78051e:	lea    0x318c13(%rip),%rcx        # a99138 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xa00>
  780525:	jmp    780588 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5148>
  780527:	mov    %rdx,0x38(%rsp)
  78052c:	lea    0x318c1d(%rip),%rcx        # a99150 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xa18>
  780533:	jmp    780588 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5148>
  780535:	lea    0x318c44(%rip),%rax        # a99180 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xa48>
  78053c:	mov    %rax,0x650(%rsp)
  780544:	movb   $0x1,0x60(%rsp)
  780549:	mov    %rbx,%rdi
  78054c:	mov    0x650(%rsp),%rdx
  780554:	call   *0x338976(%rip)        # ab8ed0 <_DYNAMIC+0x270>
  78055a:	jmp    7805c8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  78055c:	lea    0x3195f5(%rip),%rcx        # a99b58 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1420>
  780563:	jmp    780588 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5148>
  780565:	mov    %rcx,0x38(%rsp)
  78056a:	lea    0x3195ff(%rip),%rcx        # a99b70 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1438>
  780571:	jmp    780588 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5148>
  780573:	lea    0x3195c6(%rip),%rcx        # a99b40 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1408>
  78057a:	jmp    780588 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5148>
  78057c:	mov    %rcx,0x38(%rsp)
  780581:	lea    0x318be0(%rip),%rcx        # a99168 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xa30>
  780588:	mov    %rcx,0xa0(%rsp)
  780590:	mov    0x38(%rsp),%rdi
  780595:	mov    %rax,%rsi
  780598:	mov    0xa0(%rsp),%rdx
  7805a0:	call   *0x33892a(%rip)        # ab8ed0 <_DYNAMIC+0x270>
  7805a6:	jmp    7805c8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  7805a8:	lea    0x319e79(%rip),%rax        # a9a428 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1cf0>
  7805af:	mov    %rax,0x648(%rsp)
  7805b7:	mov    %rbx,%rdi
  7805ba:	mov    0x648(%rsp),%rdx
  7805c2:	call   *0x338908(%rip)        # ab8ed0 <_DYNAMIC+0x270>
  7805c8:	ud2
  7805ca:	mov    %rbx,%rcx
  7805cd:	mov    %rax,%rbx
  7805d0:	mov    (%rcx),%rax
  7805d3:	movaps 0x760(%rsp),%xmm0
  7805db:	movups %xmm0,0xb0(%rax)
  7805e2:	movaps 0x750(%rsp),%xmm0
  7805ea:	movups %xmm0,0xa0(%rax)
  7805f1:	movaps 0x710(%rsp),%xmm0
  7805f9:	movaps 0x720(%rsp),%xmm1
  780601:	movaps 0x730(%rsp),%xmm2
  780609:	movapd 0x740(%rsp),%xmm3
  780612:	movupd %xmm3,0x90(%rax)
  78061a:	movups %xmm2,0x80(%rax)
  780621:	movups %xmm1,0x70(%rax)
  780625:	movups %xmm0,0x60(%rax)
  780629:	jmp    7806aa <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x526a>
  78062b:	mov    %rax,%rbx
  78062e:	mov    0x6e8(%r13),%rax
  780635:	mov    0x210(%rsp),%rcx
  78063d:	mov    %rcx,0x28(%rax)
  780641:	movups 0x200(%rsp),%xmm0
  780649:	movups %xmm0,0x18(%rax)
  78064d:	mov    $0x1,%r15b
  780650:	xor    %r12d,%r12d
  780653:	jmp    780984 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5544>
  780658:	mov    %rax,%rbx
  78065b:	lea    0x728(%rsp),%rdi
  780663:	call   747850 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime8metadata8TextSlotEECs9C2G9YFESsD_29canonical_text_public_control>
  780668:	lea    0x740(%rsp),%rdi
  780670:	call   747850 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime8metadata8TextSlotEECs9C2G9YFESsD_29canonical_text_public_control>
  780675:	lea    0x710(%rsp),%rdi
  78067d:	call   74e5e0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime6scroll14ViewportColumnECs9C2G9YFESsD_29canonical_text_public_control>
  780682:	mov    0x758(%rsp),%rax
  78068a:	test   %rax,%rax
  78068d:	je     7806aa <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x526a>
  78068f:	mov    0x760(%rsp),%rdi
  780697:	shl    $0x3,%rax
  78069b:	lea    (%rax,%rax,2),%rsi
  78069f:	mov    $0x8,%edx
  7806a4:	call   *0x3387f6(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  7806aa:	mov    $0x1,%r12b
  7806ad:	movl   $0x0,0x58(%rsp)
  7806b5:	mov    $0x1,%al
  7806b7:	mov    %eax,0x38(%rsp)
  7806bb:	movl   $0x0,0x30(%rsp)
  7806c3:	mov    $0x1,%r15b
  7806c6:	jmp    780839 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x53f9>
  7806cb:	mov    %rax,%rbx
  7806ce:	mov    0x6e8(%r13),%rax
  7806d5:	movq   $0x0,0x30(%rax)
  7806dd:	xor    %r15d,%r15d
  7806e0:	jmp    780984 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5544>
  7806e5:	mov    %rax,%rbx
  7806e8:	lea    0x390(%rsp),%rsi
  7806f0:	mov    $0x1e8,%edx
  7806f5:	mov    %r13,%rdi
  7806f8:	call   *0x3387c2(%rip)        # ab8ec0 <memcpy@GLIBC_2.14>
  7806fe:	mov    $0x1,%al
  780700:	mov    %eax,0x58(%rsp)
  780704:	xor    %ebp,%ebp
  780706:	mov    $0x1,%r12b
  780709:	mov    $0x1,%al
  78070b:	mov    %eax,0x38(%rsp)
  78070f:	mov    $0x1,%al
  780711:	mov    %eax,0x30(%rsp)
  780715:	mov    $0x1,%r15b
  780718:	jmp    780839 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x53f9>
  78071d:	mov    %rax,%rbx
  780720:	jmp    780976 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5536>
  780725:	mov    %rax,%rbx
  780728:	mov    0x3a0(%rsp),%rax
  780730:	mov    %rax,0x10(%r15)
  780734:	movaps 0x390(%rsp),%xmm0
  78073c:	movups %xmm0,(%r15)
  780740:	mov    0x80(%rsp),%rax
  780748:	mov    %rax,0x5e0(%r13)
  78074f:	mov    0xf8(%rsp),%rax
  780757:	mov    %ax,0x5e8(%r13)
  78075f:	mov    0x2e0(%rsp),%rax
  780767:	mov    %ax,0x5ea(%r13)
  78076f:	movss  0x9c(%rsp),%xmm0
  780778:	movss  %xmm0,0x5ec(%r13)
  780781:	xor    %r15d,%r15d
  780784:	jmp    780984 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5544>
  780789:	mov    %rax,%rbx
  78078c:	mov    $0x1,%r12b
  78078f:	jmp    7807c1 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5381>
  780791:	mov    %rax,%rbx
  780794:	mov    %rbp,%rdi
  780797:	call   745d90 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtCslbxve4rcJus_4gpui11shared_text10SharedTextEECs9C2G9YFESsD_29canonical_text_public_control>
  78079c:	jmp    7809f0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x55b0>
  7807a1:	mov    %rax,%rbx
  7807a4:	mov    $0x1,%r12b
  7807a7:	test   %r15,%r15
  7807aa:	je     7807c1 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5381>
  7807ac:	shl    $0x4,%r15
  7807b0:	mov    $0x4,%edx
  7807b5:	mov    %r13,%rdi
  7807b8:	mov    %r15,%rsi
  7807bb:	call   *0x3386df(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  7807c1:	mov    $0x1,%al
  7807c3:	mov    %eax,0x38(%rsp)
  7807c7:	mov    $0x1,%r15b
  7807ca:	xor    %r13d,%r13d
  7807cd:	cmpb   $0x0,0x58(%rsp)
  7807d2:	je     7809cf <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x558f>
  7807d8:	jmp    780ac4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5684>
  7807dd:	mov    %rax,%rbx
  7807e0:	mov    $0x1,%r12b
  7807e3:	mov    $0x1,%al
  7807e5:	mov    %eax,0x38(%rsp)
  7807e9:	mov    $0x1,%al
  7807eb:	mov    %eax,0x30(%rsp)
  7807ef:	mov    $0x1,%r13b
  7807f2:	mov    $0x1,%r15b
  7807f5:	mov    $0x1,%bpl
  7807f8:	cmpq   $0xffffffffffffffff,0x258(%rsp)
  780801:	jne    780adc <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x569c>
  780807:	jmp    780af0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x56b0>
  78080c:	mov    %ebx,0x30(%rsp)
  780810:	mov    %rax,%rbx
  780813:	mov    %r15d,%r13d
  780816:	jmp    780af0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x56b0>
  78081b:	mov    %rax,%rbx
  78081e:	mov    $0x1,%al
  780820:	mov    %eax,0x58(%rsp)
  780824:	mov    $0x1,%r12b
  780827:	mov    $0x1,%al
  780829:	mov    %eax,0x38(%rsp)
  78082d:	mov    $0x1,%al
  78082f:	mov    %eax,0x30(%rsp)
  780833:	mov    $0x1,%r15b
  780836:	mov    $0x1,%bpl
  780839:	movb   $0x1,0xc0(%rsp)
  780841:	jmp    780984 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5544>
  780846:	mov    %rax,%rbx
  780849:	mov    %r13d,%r15d
  78084c:	jmp    780b1b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x56db>
  780851:	mov    %rax,%rbx
  780854:	jmp    780984 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5544>
  780859:	mov    %rax,%rbx
  78085c:	mov    %r13d,%r15d
  78085f:	jmp    780b0e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x56ce>
  780864:	mov    %rax,%rbx
  780867:	add    $0x38,%r15
  78086b:	mov    %r15,%rdi
  78086e:	call   74cd00 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text11RasterCacheECs9C2G9YFESsD_29canonical_text_public_control>
  780873:	jmp    7808e0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x54a0>
  780875:	call   *0x33864d(%rip)        # ab8ec8 <_DYNAMIC+0x268>
  78087b:	mov    %rax,%rbx
  78087e:	mov    0x300(%rsp),%rax
  780886:	lock decq (%rax)
  78088a:	jne    780a9f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x565f>
  780890:	lea    0x300(%rsp),%rdi
  780898:	call   *0x338722(%rip)        # ab8fc0 <_DYNAMIC+0x360>
  78089e:	jmp    780a9f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x565f>
  7808a3:	mov    %rax,%rbx
  7808a6:	mov    %r12b,0x60(%rsp)
  7808ab:	jmp    7809f0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x55b0>
  7808b0:	mov    %rax,%rbx
  7808b3:	movb   $0x1,0x60(%rsp)
  7808b8:	jmp    7809f0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x55b0>
  7808bd:	mov    %rax,%rbx
  7808c0:	mov    $0x1,%bpl
  7808c3:	mov    $0x1,%r15b
  7808c6:	mov    $0x1,%r13b
  7808c9:	mov    $0x1,%al
  7808cb:	mov    %eax,0x30(%rsp)
  7808cf:	mov    $0x1,%al
  7808d1:	mov    %eax,0x38(%rsp)
  7808d5:	mov    $0x1,%r12b
  7808d8:	jmp    780ac4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5684>
  7808dd:	mov    %rax,%rbx
  7808e0:	mov    0x40(%rsp),%rax
  7808e5:	mov    0x6e8(%rax),%rax
  7808ec:	mov    %r12,0x30(%rax)
  7808f0:	mov    %r14d,0x38(%rax)
  7808f4:	mov    %ebp,0x3c(%rax)
  7808f7:	movaps 0x970(%rsp),%xmm0
  7808ff:	movaps 0x980(%rsp),%xmm1
  780907:	movaps 0x990(%rsp),%xmm2
  78090f:	movups %xmm0,0x40(%rax)
  780913:	movups %xmm1,0x50(%rax)
  780917:	movups %xmm2,0x60(%rax)
  78091b:	mov    0x9a0(%rsp),%rcx
  780923:	mov    %rcx,0x70(%rax)
  780927:	mov    $0x1,%bpl
  78092a:	jmp    780c73 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5833>
  78092f:	mov    %rax,%rbx
  780932:	jmp    780c52 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5812>
  780937:	mov    %rax,%rbx
  78093a:	lea    0x390(%rsp),%rsi
  780942:	mov    $0x298,%edx
  780947:	mov    %r14,%rdi
  78094a:	call   *0x338570(%rip)        # ab8ec0 <memcpy@GLIBC_2.14>
  780950:	jmp    780c22 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57e2>
  780955:	mov    %rax,%rbx
  780958:	jmp    780c40 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5800>
  78095d:	jmp    780a9c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x565c>
  780962:	ud2
  780964:	ud2
  780966:	mov    %rax,%rbx
  780969:	lea    0x8b8(%rsp),%rdi
  780971:	call   746e60 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCsghYClfd3M9V_11gpui_canvas5image5ImageEECs9C2G9YFESsD_29canonical_text_public_control>
  780976:	mov    $0x1,%r12b
  780979:	movl   $0x0,0x38(%rsp)
  780981:	mov    $0x1,%r15b
  780984:	mov    0x180(%rsp),%rsi
  78098c:	test   %rsi,%rsi
  78098f:	setg   %al
  780992:	test   %al,0xc0(%rsp)
  780999:	je     7809c1 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5581>
  78099b:	mov    0x188(%rsp),%rdi
  7809a3:	shl    $0x4,%rsi
  7809a7:	mov    $0x4,%edx
  7809ac:	call   *0x3384ee(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  7809b2:	xor    %r13d,%r13d
  7809b5:	cmpb   $0x0,0x58(%rsp)
  7809ba:	je     7809cf <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x558f>
  7809bc:	jmp    780ac4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5684>
  7809c1:	xor    %r13d,%r13d
  7809c4:	cmpb   $0x0,0x58(%rsp)
  7809c9:	jne    780ac4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5684>
  7809cf:	cmpq   $0xffffffffffffffff,0x258(%rsp)
  7809d8:	jne    780adc <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x569c>
  7809de:	jmp    780af0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x56b0>
  7809e3:	jmp    780c1f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57df>
  7809e8:	jmp    780c1f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57df>
  7809ed:	mov    %rax,%rbx
  7809f0:	mov    0x1f8(%rsp),%rax
  7809f8:	test   %rax,%rax
  7809fb:	setne  %cl
  7809fe:	test   %cl,0x60(%rsp)
  780a02:	je     780a9f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x565f>
  780a08:	lock decq (%rax)
  780a0c:	jne    780a9f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x565f>
  780a12:	lea    0x1f8(%rsp),%rdi
  780a1a:	call   *0x3385a0(%rip)        # ab8fc0 <_DYNAMIC+0x360>
  780a20:	jmp    780a9f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x565f>
  780a22:	jmp    780c1f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57df>
  780a27:	mov    %rax,%rbx
  780a2a:	mov    $0x1,%r12b
  780a2d:	mov    $0x1,%r13b
  780a30:	mov    $0x1,%r15b
  780a33:	mov    $0x1,%bpl
  780a36:	jmp    780b3f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x56ff>
  780a3b:	mov    %rax,%rbx
  780a3e:	mov    $0x1,%r12b
  780a41:	mov    $0x1,%r13b
  780a44:	mov    $0x1,%r15b
  780a47:	mov    $0x1,%bpl
  780a4a:	jmp    780b5f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x571f>
  780a4f:	mov    %rax,%rbx
  780a52:	mov    $0x1,%r12b
  780a55:	mov    $0x1,%r13b
  780a58:	mov    $0x1,%r15b
  780a5b:	mov    $0x1,%bpl
  780a5e:	jmp    780b83 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5743>
  780a63:	mov    %rax,%rbx
  780a66:	mov    $0x1,%r12b
  780a69:	mov    $0x1,%r13b
  780a6c:	mov    $0x1,%r15b
  780a6f:	mov    $0x1,%bpl
  780a72:	jmp    780ba7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5767>
  780a77:	mov    %rax,%rbx
  780a7a:	mov    $0x1,%bpl
  780a7d:	mov    $0x1,%r15b
  780a80:	mov    $0x1,%r12b
  780a83:	jmp    780bd0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5790>
  780a88:	mov    %rax,%rbx
  780a8b:	jmp    780c06 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57c6>
  780a90:	ud2
  780a92:	ud2
  780a94:	mov    %rax,%rbx
  780a97:	jmp    780c73 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5833>
  780a9c:	mov    %rax,%rbx
  780a9f:	mov    $0x1,%bpl
  780aa2:	lea    0x970(%rsp),%rdi
  780aaa:	call   74d050 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas6canvas6CanvasECs9C2G9YFESsD_29canonical_text_public_control>
  780aaf:	mov    $0x1,%r15b
  780ab2:	mov    $0x1,%r13b
  780ab5:	mov    $0x1,%al
  780ab7:	mov    %eax,0x30(%rsp)
  780abb:	mov    $0x1,%al
  780abd:	mov    %eax,0x38(%rsp)
  780ac1:	mov    $0x1,%r12b
  780ac4:	lea    0x6c0(%rsp),%rdi
  780acc:	call   74e590 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime6scroll13ViewportBuildECs9C2G9YFESsD_29canonical_text_public_control>
  780ad1:	cmpq   $0xffffffffffffffff,0x258(%rsp)
  780ada:	je     780af0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x56b0>
  780adc:	cmpb   $0x0,0x38(%rsp)
  780ae1:	je     780af0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x56b0>
  780ae3:	lea    0x8b8(%rsp),%rdi
  780aeb:	call   746e60 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCsghYClfd3M9V_11gpui_canvas5image5ImageEECs9C2G9YFESsD_29canonical_text_public_control>
  780af0:	cmpl   $0xffffffff,0x810(%rsp)
  780af8:	je     780b0e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x56ce>
  780afa:	cmpb   $0x0,0x30(%rsp)
  780aff:	je     780b0e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x56ce>
  780b01:	lea    0x810(%rsp),%rdi
  780b09:	call   74e9d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime8metadata5SheetECs9C2G9YFESsD_29canonical_text_public_control>
  780b0e:	lea    0x6a8(%rsp),%rdi
  780b16:	call   74ac30 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtCscdodAO9FK5_5alloc11collections5btree3set8BTreeSetNtNtCslbxve4rcJus_4gpui4list6ListIdEECs9C2G9YFESsD_29canonical_text_public_control>
  780b1b:	mov    0x100(%rsp),%rsi
  780b23:	test   %rsi,%rsi
  780b26:	je     780b3f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x56ff>
  780b28:	mov    0x108(%rsp),%rdi
  780b30:	shl    $0x2,%rsi
  780b34:	mov    $0x4,%edx
  780b39:	call   *0x338361(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  780b3f:	mov    0x158(%rsp),%rsi
  780b47:	test   %rsi,%rsi
  780b4a:	je     780b5f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x571f>
  780b4c:	mov    0x160(%rsp),%rdi
  780b54:	mov    $0x1,%edx
  780b59:	call   *0x338341(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  780b5f:	mov    0x230(%rsp),%rsi
  780b67:	test   %rsi,%rsi
  780b6a:	je     780b83 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5743>
  780b6c:	mov    0x238(%rsp),%rdi
  780b74:	shl    $0x4,%rsi
  780b78:	mov    $0x4,%edx
  780b7d:	call   *0x33831d(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  780b83:	mov    0x218(%rsp),%rsi
  780b8b:	test   %rsi,%rsi
  780b8e:	je     780ba7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5767>
  780b90:	mov    0x220(%rsp),%rdi
  780b98:	shl    $0x4,%rsi
  780b9c:	mov    $0x4,%edx
  780ba1:	call   *0x3382f9(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  780ba7:	mov    0x1d8(%rsp),%rax
  780baf:	test   %rax,%rax
  780bb2:	je     780bcb <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x578b>
  780bb4:	mov    0x1e0(%rsp),%rdi
  780bbc:	imul   $0x38,%rax,%rsi
  780bc0:	mov    $0x8,%edx
  780bc5:	call   *0x3382d5(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  780bcb:	test   %r13b,%r13b
  780bce:	je     780bf4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57b4>
  780bd0:	mov    0x268(%rsp),%rsi
  780bd8:	test   %rsi,%rsi
  780bdb:	je     780bf4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57b4>
  780bdd:	mov    0x270(%rsp),%rdi
  780be5:	shl    $0x4,%rsi
  780be9:	mov    $0x4,%edx
  780bee:	call   *0x3382ac(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  780bf4:	test   %r15b,%r15b
  780bf7:	je     780c06 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57c6>
  780bf9:	lea    0x140(%rsp),%rdi
  780c01:	call   747220 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCslbxve4rcJus_4gpui7runtime9PresentedEECs9C2G9YFESsD_29canonical_text_public_control>
  780c06:	cmpl   $0xfffffffe,0x7c8(%rsp)
  780c0e:	je     780c28 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57e8>
  780c10:	lea    0x7c8(%rsp),%rdi
  780c18:	call   74d540 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  780c1d:	jmp    780c28 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57e8>
  780c1f:	mov    %rax,%rbx
  780c22:	mov    $0x1,%r12b
  780c25:	mov    $0x1,%bpl
  780c28:	cmpq   $0x0,0x1c0(%rsp)
  780c31:	je     780c40 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5800>
  780c33:	mov    0x1c8(%rsp),%rdi
  780c3b:	call   74cab0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text10TextShaperECs9C2G9YFESsD_29canonical_text_public_control>
  780c40:	test   %r12b,%r12b
  780c43:	je     780c52 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5812>
  780c45:	lea    0x200(%rsp),%rdi
  780c4d:	call   747680 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime13text_geometry5EntryEECs9C2G9YFESsD_29canonical_text_public_control>
  780c52:	mov    0xd0(%rsp),%rax
  780c5a:	test   %rax,%rax
  780c5d:	je     780c73 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5833>
  780c5f:	lock decq (%rax)
  780c63:	jne    780c73 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5833>
  780c65:	lea    0xd0(%rsp),%rdi
  780c6d:	call   *0x33831d(%rip)        # ab8f90 <_DYNAMIC+0x330>
  780c73:	cmpl   $0x2,0xca0(%rsp)
  780c7b:	je     780c8f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x584f>
  780c7d:	test   %bpl,%bpl
  780c80:	je     780c8f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x584f>
  780c82:	lea    0xca0(%rsp),%rdi
  780c8a:	call   74d050 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas6canvas6CanvasECs9C2G9YFESsD_29canonical_text_public_control>
  780c8f:	mov    %rbx,%rdi
  780c92:	call   a97380 <_Unwind_Resume@plt>
  780c97:	call   *0x33822b(%rip)        # ab8ec8 <_DYNAMIC+0x268>

<&gpui_canvas::text::layout::TextPosition as core::fmt::Debug>::fmt bytes=99 frame=24

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000795cd0 <_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextPositionNtB6_5Debug3fmtCs9C2G9YFESsD_29canonical_text_public_control>:
  795cd0:	push   %r14
  795cd2:	push   %rbx
  795cd3:	push   %rax
  795cd4:	mov    %rsi,%rax
  795cd7:	mov    (%rdi),%r9
  795cda:	lea    0x4(%r9),%rcx
  795cde:	mov    %rcx,(%rsp)
  795ce2:	sub    $0x8,%rsp
  795ce6:	lea    0x30515b(%rip),%r10        # a9ae48 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2710>
  795ced:	lea    0x8(%rsp),%r11
  795cf2:	lea    -0x6d2081(%rip),%rbx        # c3c78 <GCC_except_table0+0x1910>
  795cf9:	lea    0x305128(%rip),%r14        # a9ae28 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x26f0>
  795d00:	lea    -0x6c2d58(%rip),%rsi        # d2faf <GCC_except_table0+0x10c47>
  795d07:	lea    -0x6c6300(%rip),%rcx        # cfa0e <GCC_except_table0+0xd6a6>
  795d0e:	mov    $0xc,%edx
  795d13:	mov    $0x6,%r8d
  795d19:	mov    %rax,%rdi
  795d1c:	push   %r10
  795d1e:	push   %r11
  795d20:	push   $0x8
  795d22:	push   %rbx
  795d23:	push   %r14
  795d25:	call   *0x323905(%rip)        # ab9630 <_DYNAMIC+0x9d0>
  795d2b:	add    $0x38,%rsp
  795d2f:	pop    %rbx
  795d30:	pop    %r14
  795d32:	ret

<&gpui_canvas::text::layout::CaretAffinity as core::fmt::Debug>::fmt bytes=46 frame=0

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000795d40 <_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout13CaretAffinityNtB6_5Debug3fmtCs9C2G9YFESsD_29canonical_text_public_control>:
  795d40:	mov    %rsi,%rax
  795d43:	mov    (%rdi),%rcx
  795d46:	movzbl (%rcx),%ecx
  795d49:	lea    -0x6c2e0b(%rip),%rdx        # d2f45 <GCC_except_table0+0x10bdd>
  795d50:	lea    -0x6d1fdf(%rip),%rsi        # c3d78 <GCC_except_table0+0x1a10>
  795d57:	test   %ecx,%ecx
  795d59:	cmovne %rdx,%rsi
  795d5d:	lea    0x8(,%rcx,2),%rdx
  795d65:	mov    %rax,%rdi
  795d68:	jmp    *0x3238ca(%rip)        # ab9638 <_DYNAMIC+0x9d8>

<&gpui_canvas::text::layout::TextSelection as core::fmt::Debug>::fmt bytes=99 frame=24

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000795d70 <_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout13TextSelectionNtB6_5Debug3fmtCs9C2G9YFESsD_29canonical_text_public_control>:
  795d70:	push   %r14
  795d72:	push   %rbx
  795d73:	push   %rax
  795d74:	mov    %rsi,%rax
  795d77:	mov    (%rdi),%r9
  795d7a:	lea    0x8(%r9),%rcx
  795d7e:	mov    %rcx,(%rsp)
  795d82:	sub    $0x8,%rsp
  795d86:	lea    0x302c8b(%rip),%r10        # a98a18 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2e0>
  795d8d:	lea    0x8(%rsp),%r11
  795d92:	lea    -0x6c2cf0(%rip),%rbx        # d30a9 <GCC_except_table0+0x10d41>
  795d99:	lea    0x305108(%rip),%r14        # a9aea8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2770>
  795da0:	lea    -0x6c2d11(%rip),%rsi        # d3096 <GCC_except_table0+0x10d2e>
  795da7:	lea    -0x6c2d0b(%rip),%rcx        # d30a3 <GCC_except_table0+0x10d3b>
  795dae:	mov    $0xd,%edx
  795db3:	mov    $0x6,%r8d
  795db9:	mov    %rax,%rdi
  795dbc:	push   %r10
  795dbe:	push   %r11
  795dc0:	push   $0x5
  795dc2:	push   %rbx
  795dc3:	push   %r14
  795dc5:	call   *0x323865(%rip)        # ab9630 <_DYNAMIC+0x9d0>
  795dcb:	add    $0x38,%rsp
  795dcf:	pop    %rbx
  795dd0:	pop    %r14
  795dd2:	ret

<&*const gpui_canvas::text::layout::TextGeometry as core::fmt::Debug>::fmt bytes=12 frame=0

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000795de0 <_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRPNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryNtB6_5Debug3fmtCs9C2G9YFESsD_29canonical_text_public_control>:
  795de0:	mov    (%rdi),%rax
  795de3:	mov    (%rax),%rdi
  795de6:	jmp    *0x323884(%rip)        # ab9670 <_DYNAMIC+0xa10>

<&(alloc::string::String, gpui_canvas::text::layout::TextSelection, *const gpui_canvas::text::layout::TextGeometry, u64) as core::fmt::Debug>::fmt bytes=156 frame=72

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000795e30 <_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRTNtNtCscdodAO9FK5_5alloc6string6StringNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout13TextSelectionPNtB1a_12TextGeometryyENtB6_5Debug3fmtCs9C2G9YFESsD_29canonical_text_public_control>:
  795e30:	push   %r14
  795e32:	push   %rbx
  795e33:	sub    $0x38,%rsp
  795e37:	mov    (%rdi),%r14
  795e3a:	lea    0x20(%rsp),%rbx
  795e3f:	mov    $0x1,%edx
  795e44:	mov    %rbx,%rdi
  795e47:	xor    %ecx,%ecx
  795e49:	call   *0x323829(%rip)        # ab9678 <_DYNAMIC+0xa18>
  795e4f:	mov    %r14,(%rsp)
  795e53:	lea    0x18(%r14),%rax
  795e57:	mov    %rax,0x8(%rsp)
  795e5c:	lea    0x28(%r14),%rax
  795e60:	mov    %rax,0x10(%rsp)
  795e65:	add    $0x30,%r14
  795e69:	mov    %r14,0x18(%rsp)
  795e6e:	lea    0x302b83(%rip),%rdx        # a989f8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2c0>
  795e75:	mov    0x323804(%rip),%r14        # ab9680 <_DYNAMIC+0xa20>
  795e7c:	mov    %rsp,%rsi
  795e7f:	mov    %rbx,%rdi
  795e82:	call   *%r14
  795e85:	lea    0x302bac(%rip),%rdx        # a98a38 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x300>
  795e8c:	lea    0x8(%rsp),%rsi
  795e91:	mov    %rbx,%rdi
  795e94:	call   *%r14
  795e97:	lea    0x304a2a(%rip),%rdx        # a9a8c8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2190>
  795e9e:	lea    0x10(%rsp),%rsi
  795ea3:	mov    %rbx,%rdi
  795ea6:	call   *%r14
  795ea9:	lea    0x304a38(%rip),%rdx        # a9a8e8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x21b0>
  795eb0:	lea    0x18(%rsp),%rsi
  795eb5:	mov    %rbx,%rdi
  795eb8:	call   *%r14
  795ebb:	mov    %rbx,%rdi
  795ebe:	call   *0x3237c4(%rip)        # ab9688 <_DYNAMIC+0xa28>
  795ec4:	add    $0x38,%rsp
  795ec8:	pop    %rbx
  795ec9:	pop    %r14
  795ecb:	ret

<&(*const gpui_canvas::text::layout::TextGeometry, u64) as core::fmt::Debug>::fmt bytes=102 frame=56

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000795ed0 <_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRTPNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryyENtB6_5Debug3fmtCs9C2G9YFESsD_29canonical_text_public_control>:
  795ed0:	push   %r14
  795ed2:	push   %rbx
  795ed3:	sub    $0x28,%rsp
  795ed7:	mov    (%rdi),%r14
  795eda:	lea    0x10(%rsp),%rbx
  795edf:	mov    $0x1,%edx
  795ee4:	mov    %rbx,%rdi
  795ee7:	xor    %ecx,%ecx
  795ee9:	call   *0x323789(%rip)        # ab9678 <_DYNAMIC+0xa18>
  795eef:	mov    %r14,(%rsp)
  795ef3:	add    $0x8,%r14
  795ef7:	mov    %r14,0x8(%rsp)
  795efc:	lea    0x3049c5(%rip),%rdx        # a9a8c8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2190>
  795f03:	mov    0x323776(%rip),%r14        # ab9680 <_DYNAMIC+0xa20>
  795f0a:	mov    %rsp,%rsi
  795f0d:	mov    %rbx,%rdi
  795f10:	call   *%r14
  795f13:	lea    0x3049ce(%rip),%rdx        # a9a8e8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x21b0>
  795f1a:	lea    0x8(%rsp),%rsi
  795f1f:	mov    %rbx,%rdi
  795f22:	call   *%r14
  795f25:	mov    %rbx,%rdi
  795f28:	call   *0x32375a(%rip)        # ab9688 <_DYNAMIC+0xa28>
  795f2e:	add    $0x28,%rsp
  795f32:	pop    %rbx
  795f33:	pop    %r14
  795f35:	ret

<gpui_canvas::text::layout::TextOffset as core::fmt::Debug>::fmt bytes=41 frame=8

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007961e0 <_RNvXs7_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_10TextOffsetNtNtCs4NRVxsYgnAr_4core3fmt5Debug3fmt>:
  7961e0:	push   %rax
  7961e1:	mov    %rsi,%rax
  7961e4:	mov    %rdi,(%rsp)
  7961e8:	lea    -0x6c3535(%rip),%rsi        # d2cba <GCC_except_table0+0x10952>
  7961ef:	lea    0x304902(%rip),%r8        # a9aaf8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x23c0>
  7961f6:	mov    %rsp,%rcx
  7961f9:	mov    $0xa,%edx
  7961fe:	mov    %rax,%rdi
  796201:	call   *0x323439(%rip)        # ab9640 <_DYNAMIC+0x9e0>
  796207:	pop    %rcx
  796208:	ret

<gpui_canvas::text::layout::TextPosition as core::fmt::Debug>::fmt bytes=99 frame=24

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000797c20 <_RNvXsn_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextPositionNtNtCs4NRVxsYgnAr_4core3fmt5Debug3fmt>:
  797c20:	push   %r14
  797c22:	push   %rbx
  797c23:	push   %rax
  797c24:	mov    %rsi,%rax
  797c27:	mov    %rdi,%r9
  797c2a:	lea    0x4(%rdi),%rcx
  797c2e:	mov    %rcx,(%rsp)
  797c32:	sub    $0x8,%rsp
  797c36:	lea    0x30320b(%rip),%r10        # a9ae48 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2710>
  797c3d:	lea    0x8(%rsp),%r11
  797c42:	lea    -0x6d3fd1(%rip),%rbx        # c3c78 <GCC_except_table0+0x1910>
  797c49:	lea    0x3031d8(%rip),%r14        # a9ae28 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x26f0>
  797c50:	lea    -0x6c4ca8(%rip),%rsi        # d2faf <GCC_except_table0+0x10c47>
  797c57:	lea    -0x6c8250(%rip),%rcx        # cfa0e <GCC_except_table0+0xd6a6>
  797c5e:	mov    $0xc,%edx
  797c63:	mov    $0x6,%r8d
  797c69:	mov    %rax,%rdi
  797c6c:	push   %r10
  797c6e:	push   %r11
  797c70:	push   $0x8
  797c72:	push   %rbx
  797c73:	push   %r14
  797c75:	call   *0x3219b5(%rip)        # ab9630 <_DYNAMIC+0x9d0>
  797c7b:	add    $0x38,%rsp
  797c7f:	pop    %rbx
  797c80:	pop    %r14
  797c82:	ret

<gpui::runtime::text_geometry::TextResources>::acknowledge bytes=336 frame=104

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000079d310 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge>:
  79d310:	push   %rbp
  79d311:	push   %r15
  79d313:	push   %r14
  79d315:	push   %r13
  79d317:	push   %r12
  79d319:	push   %rbx
  79d31a:	sub    $0x38,%rsp
  79d31e:	mov    0x18(%rdi),%rax
  79d322:	movq   $0xffffffffffffffff,0x18(%rdi)
  79d32a:	cmp    $0xffffffffffffffff,%rax
  79d32e:	je     79d3d6 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0xc6>
  79d334:	mov    %rdi,%rbx
  79d337:	mov    %rax,0x10(%rsp)
  79d33c:	movups 0x20(%rdi),%xmm0
  79d340:	movaps %xmm0,0x20(%rsp)
  79d345:	lea    0x8(%rdi),%rax
  79d349:	mov    %rax,0x8(%rsp)
  79d34e:	mov    0x8(%rdi),%r14
  79d352:	mov    0x10(%rdi),%rax
  79d356:	test   %rax,%rax
  79d359:	je     79d3a3 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0x93>
  79d35b:	mov    $0x1,%r15d
  79d361:	sub    %rax,%r15
  79d364:	mov    $0xffffffffffffffe8,%r13
  79d36b:	xor    %r12d,%r12d
  79d36e:	mov    0x31bc4b(%rip),%rbp        # ab8fc0 <_DYNAMIC+0x360>
  79d375:	jmp    79d391 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0x81>
  79d377:	nopw   0x0(%rax,%rax,1)
  79d380:	add    $0xffffffffffffffe8,%r13
  79d384:	inc    %r15
  79d387:	add    $0x18,%r12
  79d38b:	cmp    $0x1,%r15
  79d38f:	je     79d3a3 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0x93>
  79d391:	mov    (%r14,%r12,1),%rax
  79d395:	lock decq (%rax)
  79d399:	jne    79d380 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0x70>
  79d39b:	lea    (%r14,%r12,1),%rdi
  79d39f:	call   *%rbp
  79d3a1:	jmp    79d380 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0x70>
  79d3a3:	mov    (%rbx),%rax
  79d3a6:	test   %rax,%rax
  79d3a9:	je     79d3c1 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0xb1>
  79d3ab:	shl    $0x3,%rax
  79d3af:	lea    (%rax,%rax,2),%rsi
  79d3b3:	mov    $0x8,%edx
  79d3b8:	mov    %r14,%rdi
  79d3bb:	call   *0x31badf(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  79d3c1:	mov    0x10(%rsp),%rax
  79d3c6:	mov    %rax,(%rbx)
  79d3c9:	movaps 0x20(%rsp),%xmm0
  79d3ce:	mov    0x8(%rsp),%rax
  79d3d3:	movups %xmm0,(%rax)
  79d3d6:	add    $0x38,%rsp
  79d3da:	pop    %rbx
  79d3db:	pop    %r12
  79d3dd:	pop    %r13
  79d3df:	pop    %r14
  79d3e1:	pop    %r15
  79d3e3:	pop    %rbp
  79d3e4:	ret
  79d3e5:	mov    %rax,0x18(%rsp)
  79d3ea:	test   %r15,%r15
  79d3ed:	jne    79d42c <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0x11c>
  79d3ef:	mov    (%rbx),%rax
  79d3f2:	test   %rax,%rax
  79d3f5:	je     79d40d <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0xfd>
  79d3f7:	shl    $0x3,%rax
  79d3fb:	lea    (%rax,%rax,2),%rsi
  79d3ff:	mov    $0x8,%edx
  79d404:	mov    %r14,%rdi
  79d407:	call   *0x31ba93(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  79d40d:	mov    0x10(%rsp),%rax
  79d412:	mov    %rax,(%rbx)
  79d415:	movaps 0x20(%rsp),%xmm0
  79d41a:	mov    0x8(%rsp),%rax
  79d41f:	movups %xmm0,(%rax)
  79d422:	mov    0x18(%rsp),%rdi
  79d427:	call   a97380 <_Unwind_Resume@plt>
  79d42c:	mov    %r14,%r12
  79d42f:	sub    %r13,%r12
  79d432:	neg    %r15
  79d435:	jmp    79d449 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0x139>
  79d437:	nopw   0x0(%rax,%rax,1)
  79d440:	add    $0x18,%r12
  79d444:	dec    %r15
  79d447:	je     79d3ef <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0xdf>
  79d449:	mov    (%r12),%rax
  79d44d:	lock decq (%rax)
  79d451:	jne    79d440 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0x130>
  79d453:	mov    %r12,%rdi
  79d456:	call   *%rbp
  79d458:	jmp    79d440 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0x130>
  79d45a:	call   *0x31ba68(%rip)        # ab8ec8 <_DYNAMIC+0x268>

<gpui::runtime::geometry::Geometry>::acknowledge bytes=76 frame=24

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007a56a0 <_RNvMs4_NtNtCslbxve4rcJus_4gpui7runtime8geometryNtB5_8Geometry11acknowledge>:
  7a56a0:	push   %r15
  7a56a2:	push   %r14
  7a56a4:	push   %rbx
  7a56a5:	mov    0x30(%rdi),%r14
  7a56a9:	movq   $0xffffffffffffffff,0x30(%rdi)
  7a56b1:	cmp    $0xffffffffffffffff,%r14
  7a56b5:	je     7a56e6 <_RNvMs4_NtNtCslbxve4rcJus_4gpui7runtime8geometryNtB5_8Geometry11acknowledge+0x46>
  7a56b7:	mov    %rdi,%rbx
  7a56ba:	lea    0x38(%rdi),%r15
  7a56be:	mov    0x18(%rdi),%rsi
  7a56c2:	test   %rsi,%rsi
  7a56c5:	je     7a56da <_RNvMs4_NtNtCslbxve4rcJus_4gpui7runtime8geometryNtB5_8Geometry11acknowledge+0x3a>
  7a56c7:	mov    0x20(%rbx),%rdi
  7a56cb:	shl    $0x4,%rsi
  7a56cf:	mov    $0x4,%edx
  7a56d4:	call   *0x3137c6(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  7a56da:	mov    %r14,0x18(%rbx)
  7a56de:	movups (%r15),%xmm0
  7a56e2:	movups %xmm0,0x20(%rbx)
  7a56e6:	pop    %rbx
  7a56e7:	pop    %r14
  7a56e9:	pop    %r15
  7a56eb:	ret

<gpui::runtime::TextSite>::shape_for bytes=402 frame=168

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007a7bb0 <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for>:
  7a7bb0:	push   %rbp
  7a7bb1:	push   %r15
  7a7bb3:	push   %r14
  7a7bb5:	push   %r13
  7a7bb7:	push   %r12
  7a7bb9:	push   %rbx
  7a7bba:	sub    $0x78,%rsp
  7a7bbe:	mov    %ecx,%ebp
  7a7bc0:	mov    %rsi,%rbx
  7a7bc3:	maxss  -0x6e5603(%rip),%xmm1        # c25c8 <GCC_except_table0+0x260>
  7a7bcb:	mov    %rdi,%r14
  7a7bce:	movd   %xmm1,%ecx
  7a7bd2:	cmpq   $0xffffffffffffffff,(%rsi)
  7a7bd6:	je     7a7bf1 <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x41>
  7a7bd8:	cmpl   $0x1,0x38(%rbx)
  7a7bdc:	jne    7a7cb5 <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x105>
  7a7be2:	cmp    %ecx,0x3c(%rbx)
  7a7be5:	sete   %al
  7a7be8:	test   %al,%bpl
  7a7beb:	jne    7a7cbf <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x10f>
  7a7bf1:	test   %r8b,%r8b
  7a7bf4:	je     7a7c1e <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x6e>
  7a7bf6:	mov    %ecx,0xc(%rsp)
  7a7bfa:	mov    0x40(%rbx),%rax
  7a7bfe:	mov    (%rax),%rcx
  7a7c01:	shr    $1,%rcx
  7a7c04:	add    $0x10,%rax
  7a7c08:	lea    0x40(%rsp),%rdi
  7a7c0d:	mov    %rdx,%rsi
  7a7c10:	mov    %rax,%rdx
  7a7c13:	mov    %ebp,%r8d
  7a7c16:	call   *0x31151c(%rip)        # ab9138 <_DYNAMIC+0x4d8>
  7a7c1c:	jmp    7a7c44 <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x94>
  7a7c1e:	mov    %ecx,0xc(%rsp)
  7a7c22:	mov    0x40(%rbx),%rax
  7a7c26:	mov    (%rax),%rcx
  7a7c29:	shr    $1,%rcx
  7a7c2c:	add    $0x10,%rax
  7a7c30:	lea    0x40(%rsp),%rdi
  7a7c35:	mov    %rdx,%rsi
  7a7c38:	mov    %rax,%rdx
  7a7c3b:	mov    %ebp,%r8d
  7a7c3e:	call   *0x311c24(%rip)        # ab9868 <_DYNAMIC+0xc08>
  7a7c44:	mov    0x40(%rsp),%r15
  7a7c49:	mov    0x48(%rsp),%r13d
  7a7c4e:	mov    0x4c(%rsp),%r12d
  7a7c53:	cmp    $0xffffffffffffffff,%r15
  7a7c57:	je     7a7ce9 <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x139>
  7a7c5d:	mov    0x70(%rsp),%rax
  7a7c62:	mov    %rax,0x30(%rsp)
  7a7c67:	movups 0x50(%rsp),%xmm0
  7a7c6c:	movups 0x60(%rsp),%xmm1
  7a7c71:	movaps %xmm1,0x20(%rsp)
  7a7c76:	movaps %xmm0,0x10(%rsp)
  7a7c7b:	mov    %rbx,%rdi
  7a7c7e:	call   7991b0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtCslbxve4rcJus_4gpui7runtime6ShapedEEB11_>
  7a7c83:	mov    %r15,(%rbx)
  7a7c86:	mov    %r13d,0x8(%rbx)
  7a7c8a:	mov    %r12d,0xc(%rbx)
  7a7c8e:	movaps 0x10(%rsp),%xmm0
  7a7c93:	movaps 0x20(%rsp),%xmm1
  7a7c98:	movups %xmm0,0x10(%rbx)
  7a7c9c:	movups %xmm1,0x20(%rbx)
  7a7ca0:	mov    0x30(%rsp),%rax
  7a7ca5:	mov    %rax,0x30(%rbx)
  7a7ca9:	mov    %ebp,0x38(%rbx)
  7a7cac:	mov    0xc(%rsp),%eax
  7a7cb0:	mov    %eax,0x3c(%rbx)
  7a7cb3:	jmp    7a7cdc <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x12c>
  7a7cb5:	test   $0x1,%bpl
  7a7cb9:	jne    7a7bf1 <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x41>
  7a7cbf:	test   %r8b,%r8b
  7a7cc2:	je     7a7cdc <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x12c>
  7a7cc4:	mov    0x20(%rbx),%rax
  7a7cc8:	test   %rax,%rax
  7a7ccb:	je     7a7bf6 <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x46>
  7a7cd1:	cmpq   $0x0,0x50(%rax)
  7a7cd6:	je     7a7bf6 <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x46>
  7a7cdc:	mov    %rbx,0x8(%r14)
  7a7ce0:	movq   $0xfffffffffffffffe,(%r14)
  7a7ce7:	jmp    7a7cf8 <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x148>
  7a7ce9:	movq   $0x23,(%r14)
  7a7cf0:	mov    %r13d,0x8(%r14)
  7a7cf4:	mov    %r12d,0xc(%r14)
  7a7cf8:	mov    %r14,%rax
  7a7cfb:	add    $0x78,%rsp
  7a7cff:	pop    %rbx
  7a7d00:	pop    %r12
  7a7d02:	pop    %r13
  7a7d04:	pop    %r14
  7a7d06:	pop    %r15
  7a7d08:	pop    %rbp
  7a7d09:	ret
  7a7d0a:	mov    %r15,(%rbx)
  7a7d0d:	mov    %r13d,0x8(%rbx)
  7a7d11:	mov    %r12d,0xc(%rbx)
  7a7d15:	movaps 0x10(%rsp),%xmm0
  7a7d1a:	movaps 0x20(%rsp),%xmm1
  7a7d1f:	movups %xmm0,0x10(%rbx)
  7a7d23:	movups %xmm1,0x20(%rbx)
  7a7d27:	mov    0x30(%rsp),%rcx
  7a7d2c:	mov    %rcx,0x30(%rbx)
  7a7d30:	mov    %ebp,0x38(%rbx)
  7a7d33:	mov    0xc(%rsp),%ecx
  7a7d37:	mov    %ecx,0x3c(%rbx)
  7a7d3a:	mov    %rax,%rdi
  7a7d3d:	call   a97380 <_Unwind_Resume@plt>

gpui::runtime::image::acknowledge bytes=157 frame=40

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007aa1f0 <_RNvNtNtCslbxve4rcJus_4gpui7runtime5image11acknowledge>:
  7aa1f0:	push   %r15
  7aa1f2:	push   %r14
  7aa1f4:	push   %rbx
  7aa1f5:	sub    $0x10,%rsp
  7aa1f9:	mov    (%rdi),%r14
  7aa1fc:	test   %r14,%r14
  7aa1ff:	je     7aa25f <_RNvNtNtCslbxve4rcJus_4gpui7runtime5image11acknowledge+0x6f>
  7aa201:	mov    %rdi,%rbx
  7aa204:	mov    0x38(%r14),%r15
  7aa208:	cmp    $0xffffffffffffffff,%r15
  7aa20c:	je     7aa23b <_RNvNtNtCslbxve4rcJus_4gpui7runtime5image11acknowledge+0x4b>
  7aa20e:	cmp    %rsi,0x30(%r14)
  7aa212:	jne    7aa23b <_RNvNtNtCslbxve4rcJus_4gpui7runtime5image11acknowledge+0x4b>
  7aa214:	movups 0x40(%r14),%xmm0
  7aa219:	movaps %xmm0,(%rsp)
  7aa21d:	movq   $0xffffffffffffffff,0x38(%r14)
  7aa225:	lea    0x18(%r14),%rdi
  7aa229:	call   7992e0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCsghYClfd3M9V_11gpui_canvas5image5ImageEECslbxve4rcJus_4gpui>
  7aa22e:	mov    %r15,0x18(%r14)
  7aa232:	movaps (%rsp),%xmm0
  7aa236:	movups %xmm0,0x20(%r14)
  7aa23b:	cmpq   $0x0,0x10(%r14)
  7aa240:	jne    7aa25f <_RNvNtNtCslbxve4rcJus_4gpui7runtime5image11acknowledge+0x6f>
  7aa242:	cmpq   $0x0,0x28(%r14)
  7aa247:	jne    7aa25f <_RNvNtNtCslbxve4rcJus_4gpui7runtime5image11acknowledge+0x6f>
  7aa249:	cmpq   $0xffffffffffffffff,0x38(%r14)
  7aa24e:	jne    7aa25f <_RNvNtNtCslbxve4rcJus_4gpui7runtime5image11acknowledge+0x6f>
  7aa250:	mov    %r14,%rdi
  7aa253:	call   799050 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionINtNtCscdodAO9FK5_5alloc5boxed3BoxNtNtNtCslbxve4rcJus_4gpui7runtime5image6ImagesEEEB1B_>
  7aa258:	movq   $0x0,(%rbx)
  7aa25f:	add    $0x10,%rsp
  7aa263:	pop    %rbx
  7aa264:	pop    %r14
  7aa266:	pop    %r15
  7aa268:	ret
  7aa269:	movq   $0x0,(%rbx)
  7aa270:	mov    %rax,%rdi
  7aa273:	call   a97380 <_Unwind_Resume@plt>
  7aa278:	mov    %r15,0x18(%r14)
  7aa27c:	movaps (%rsp),%xmm0
  7aa280:	movups %xmm0,0x20(%r14)
  7aa285:	mov    %rax,%rdi
  7aa288:	call   a97380 <_Unwind_Resume@plt>

core::ptr::drop_glue::<core::option::Option<gpui_canvas::text::layout::TextGeometry>> bytes=108 frame=8

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007baf90 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryEEB13_>:
  7baf90:	push   %rbx
  7baf91:	mov    (%rdi),%rax
  7baf94:	cmp    $0xffffffffffffffff,%rax
  7baf98:	je     7baffa <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryEEB13_+0x6a>
  7baf9a:	mov    %rdi,%rbx
  7baf9d:	test   %rax,%rax
  7bafa0:	je     7bafb9 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryEEB13_+0x29>
  7bafa2:	mov    0x8(%rbx),%rdi
  7bafa6:	shl    $0x3,%rax
  7bafaa:	lea    (%rax,%rax,2),%rsi
  7bafae:	mov    $0x4,%edx
  7bafb3:	call   *0x2fdee7(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  7bafb9:	mov    0x18(%rbx),%rax
  7bafbd:	test   %rax,%rax
  7bafc0:	je     7bafd9 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryEEB13_+0x49>
  7bafc2:	mov    0x20(%rbx),%rdi
  7bafc6:	shl    $0x3,%rax
  7bafca:	lea    (%rax,%rax,2),%rsi
  7bafce:	mov    $0x4,%edx
  7bafd3:	call   *0x2fdec7(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  7bafd9:	mov    0x30(%rbx),%rax
  7bafdd:	test   %rax,%rax
  7bafe0:	je     7baffa <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryEEB13_+0x6a>
  7bafe2:	mov    0x38(%rbx),%rdi
  7bafe6:	shl    $0x2,%rax
  7bafea:	lea    (%rax,%rax,2),%rsi
  7bafee:	mov    $0x4,%edx
  7baff3:	pop    %rbx
  7baff4:	jmp    *0x2fdea6(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  7baffa:	pop    %rbx
  7baffb:	ret

core::ptr::drop_glue::<alloc::sync::ArcInner<gpui_canvas::text::layout::TextGeometry>> bytes=103 frame=8

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007bbcd0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc4sync8ArcInnerNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryEEB1j_>:
  7bbcd0:	push   %rbx
  7bbcd1:	mov    %rdi,%rbx
  7bbcd4:	mov    0x10(%rdi),%rax
  7bbcd8:	test   %rax,%rax
  7bbcdb:	je     7bbcf4 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc4sync8ArcInnerNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryEEB1j_+0x24>
  7bbcdd:	mov    0x18(%rbx),%rdi
  7bbce1:	shl    $0x3,%rax
  7bbce5:	lea    (%rax,%rax,2),%rsi
  7bbce9:	mov    $0x4,%edx
  7bbcee:	call   *0x2fd1ac(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  7bbcf4:	mov    0x28(%rbx),%rax
  7bbcf8:	test   %rax,%rax
  7bbcfb:	je     7bbd14 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc4sync8ArcInnerNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryEEB1j_+0x44>
  7bbcfd:	mov    0x30(%rbx),%rdi
  7bbd01:	shl    $0x3,%rax
  7bbd05:	lea    (%rax,%rax,2),%rsi
  7bbd09:	mov    $0x4,%edx
  7bbd0e:	call   *0x2fd18c(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  7bbd14:	mov    0x40(%rbx),%rax
  7bbd18:	test   %rax,%rax
  7bbd1b:	je     7bbd35 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc4sync8ArcInnerNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryEEB1j_+0x65>
  7bbd1d:	mov    0x48(%rbx),%rdi
  7bbd21:	shl    $0x2,%rax
  7bbd25:	lea    (%rax,%rax,2),%rsi
  7bbd29:	mov    $0x4,%edx
  7bbd2e:	pop    %rbx
  7bbd2f:	jmp    *0x2fd16b(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  7bbd35:	pop    %rbx
  7bbd36:	ret

<gpui_canvas::text::layout::TextGeometry>::intervals::{closure#3} bytes=687 frame=56

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007c8a20 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_>:
  7c8a20:	push   %rbp
  7c8a21:	push   %r15
  7c8a23:	push   %r14
  7c8a25:	push   %r13
  7c8a27:	push   %r12
  7c8a29:	push   %rbx
  7c8a2a:	push   %rax
  7c8a2b:	cmp    $0x2,%rcx
  7c8a2f:	jb     7c8c92 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x272>
  7c8a35:	mov    (%rsi),%r11
  7c8a38:	mov    0x8(%rsi),%rax
  7c8a3c:	mov    0x20(%r11),%r9
  7c8a40:	mov    0x28(%r11),%r8
  7c8a44:	lea    0x1(%rax),%r10
  7c8a48:	cmp    %r8,%r10
  7c8a4b:	jae    7c8a8d <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x6d>
  7c8a4d:	mov    (%rdx),%ecx
  7c8a4f:	lea    (%r10,%r10,2),%rbx
  7c8a53:	cmp    %ecx,(%r9,%rbx,8)
  7c8a57:	ja     7c8a8d <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x6d>
  7c8a59:	lea    (%rax,%rax,2),%rax
  7c8a5d:	lea    (%r9,%rax,8),%r14
  7c8a61:	add    $0x30,%r14
  7c8a65:	mov    $0x2,%ebx
  7c8a6a:	sub    %r8,%rbx
  7c8a6d:	nopl   (%rax)
  7c8a70:	mov    %r10,%rax
  7c8a73:	add    %rbx,%r10
  7c8a76:	cmp    $0x1,%r10
  7c8a7a:	je     7c8a89 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x69>
  7c8a7c:	lea    0x1(%rax),%r10
  7c8a80:	cmp    %ecx,(%r14)
  7c8a83:	lea    0x18(%r14),%r14
  7c8a87:	jbe    7c8a70 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x50>
  7c8a89:	mov    %rax,0x8(%rsi)
  7c8a8d:	cmp    %r8,%rax
  7c8a90:	jae    7c8ca9 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x289>
  7c8a96:	lea    (%rax,%rax,2),%r10
  7c8a9a:	testb  $0x1,0x8(%rdx)
  7c8a9e:	mov    %rax,%rcx
  7c8aa1:	jne    7c8ad9 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0xb9>
  7c8aa3:	cmp    %r8,%rcx
  7c8aa6:	jae    7c8cbc <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x29c>
  7c8aac:	mov    0xc(%rdx),%r8d
  7c8ab0:	mov    0x4(%r9,%r10,8),%r10d
  7c8ab5:	movss  0x4(%rdx),%xmm0
  7c8aba:	movss  0x10(%rdx),%xmm1
  7c8abf:	cmp    %r10d,%r8d
  7c8ac2:	ja     7c8b3d <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x11d>
  7c8ac4:	ucomiss %xmm1,%xmm0
  7c8ac7:	jne    7c8acb <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0xab>
  7c8ac9:	jnp    7c8b3d <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x11d>
  7c8acb:	ucomiss %xmm0,%xmm1
  7c8ace:	setbe  %r11b
  7c8ad2:	mov    (%rdx),%edx
  7c8ad4:	jmp    7c8bee <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x1ce>
  7c8ad9:	mov    %rax,%rcx
  7c8adc:	test   %rax,%rax
  7c8adf:	je     7c8aa3 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x83>
  7c8ae1:	mov    (%rdx),%ebx
  7c8ae3:	mov    %rax,%rcx
  7c8ae6:	test   %ebx,%ebx
  7c8ae8:	je     7c8aa3 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x83>
  7c8aea:	lea    (%r9,%r10,8),%r14
  7c8aee:	mov    %rax,%rcx
  7c8af1:	cmp    %ebx,-0x14(%r14)
  7c8af5:	jne    7c8aa3 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x83>
  7c8af7:	xor    %ecx,%ecx
  7c8af9:	mov    %r8,%r14
  7c8afc:	nopl   0x0(%rax)
  7c8b00:	mov    %r14,%r15
  7c8b03:	shr    $1,%r15
  7c8b06:	lea    (%r15,%rcx,1),%r12
  7c8b0a:	lea    (%r12,%r12,2),%r13
  7c8b0e:	cmp    %ebx,0x4(%r9,%r13,8)
  7c8b13:	cmovb  %r12,%rcx
  7c8b17:	sub    %r15,%r14
  7c8b1a:	cmp    $0x1,%r14
  7c8b1e:	ja     7c8b00 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0xe0>
  7c8b20:	lea    (%rcx,%rcx,2),%r14
  7c8b24:	cmp    %ebx,0x4(%r9,%r14,8)
  7c8b29:	adc    $0x0,%rcx
  7c8b2d:	lea    -0x1(%r8),%rbx
  7c8b31:	cmp    %rcx,%rbx
  7c8b34:	cmovb  %rbx,%rcx
  7c8b38:	jmp    7c8aa3 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x83>
  7c8b3d:	mov    0x8(%r11),%rbx
  7c8b41:	mov    0x10(%r11),%r11
  7c8b45:	mov    %r11,%r14
  7c8b48:	test   %r11,%r11
  7c8b4b:	je     7c8b99 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x179>
  7c8b4d:	xor    %r14d,%r14d
  7c8b50:	cmp    $0x1,%r11
  7c8b54:	je     7c8b89 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x169>
  7c8b56:	mov    %r11,%r15
  7c8b59:	nopl   0x0(%rax)
  7c8b60:	mov    %r15,%r12
  7c8b63:	shr    $1,%r12
  7c8b66:	lea    (%r12,%r14,1),%r13
  7c8b6a:	lea    0x0(,%r13,2),%rbp
  7c8b72:	add    %r13,%rbp
  7c8b75:	mov    0x10(%rbx,%rbp,8),%ebp
  7c8b79:	cmp    %rbp,%rax
  7c8b7c:	cmova  %r13,%r14
  7c8b80:	sub    %r12,%r15
  7c8b83:	cmp    $0x1,%r15
  7c8b87:	ja     7c8b60 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x140>
  7c8b89:	lea    (%r14,%r14,2),%r15
  7c8b8d:	mov    0x10(%rbx,%r15,8),%r15d
  7c8b92:	cmp    %rax,%r15
  7c8b95:	adc    $0x0,%r14
  7c8b99:	shl    $0x3,%r14
  7c8b9d:	lea    (%r14,%r14,2),%r14
  7c8ba1:	lea    (%rbx,%r14,1),%r15
  7c8ba5:	mov    (%rdx),%edx
  7c8ba7:	shl    $0x3,%r11
  7c8bab:	lea    (%r11,%r11,2),%r11
  7c8baf:	nop
  7c8bb0:	cmp    %r14,%r11
  7c8bb3:	je     7c8c73 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x253>
  7c8bb9:	mov    %r15,%r12
  7c8bbc:	mov    0x10(%r15),%r15d
  7c8bc0:	cmp    %r15,%rax
  7c8bc3:	jne    7c8c73 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x253>
  7c8bc9:	lea    0x18(%r12),%r15
  7c8bce:	add    $0x18,%r14
  7c8bd2:	cmp    %edx,(%r12)
  7c8bd6:	ja     7c8bb0 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x190>
  7c8bd8:	cmp    0x4(%r12),%edx
  7c8bdd:	ja     7c8bb0 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x190>
  7c8bdf:	movzbl -0x3(%rbx,%r14,1),%r11d
  7c8be5:	cmp    %r10d,%r8d
  7c8be8:	ja     7c8c7f <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x25f>
  7c8bee:	movaps %xmm0,%xmm3
  7c8bf1:	minss  %xmm1,%xmm3
  7c8bf5:	movaps %xmm3,%xmm2
  7c8bf8:	cmpunordss %xmm3,%xmm2
  7c8bfd:	movaps %xmm2,%xmm4
  7c8c00:	andps  %xmm0,%xmm4
  7c8c03:	andnps %xmm3,%xmm2
  7c8c06:	orps   %xmm4,%xmm2
  7c8c09:	movaps %xmm1,%xmm3
  7c8c0c:	subss  %xmm0,%xmm3
  7c8c10:	andps  -0x7057f7(%rip),%xmm3        # c3420 <GCC_except_table0+0x10b8>
  7c8c17:	cmp    %r10d,%r8d
  7c8c1a:	lea    (%rcx,%rcx,2),%rcx
  7c8c1e:	movss  0x8(%r9,%rcx,8),%xmm4
  7c8c25:	movss  0xc(%r9,%rcx,8),%xmm5
  7c8c2c:	mov    %edx,(%rdi)
  7c8c2e:	movb   $0x1,0x4(%rdi)
  7c8c32:	mov    %r8d,0x8(%rdi)
  7c8c36:	movb   $0x0,0xc(%rdi)
  7c8c3a:	movss  %xmm0,0x28(%rdi)
  7c8c3f:	movss  %xmm1,0x2c(%rdi)
  7c8c44:	movss  %xmm2,0x10(%rdi)
  7c8c49:	movss  %xmm4,0x14(%rdi)
  7c8c4e:	movss  %xmm3,0x18(%rdi)
  7c8c53:	movss  %xmm5,0x1c(%rdi)
  7c8c58:	mov    %rax,0x20(%rdi)
  7c8c5c:	seta   0x30(%rdi)
  7c8c60:	mov    %r11b,0x31(%rdi)
  7c8c64:	add    $0x8,%rsp
  7c8c68:	pop    %rbx
  7c8c69:	pop    %r12
  7c8c6b:	pop    %r13
  7c8c6d:	pop    %r14
  7c8c6f:	pop    %r15
  7c8c71:	pop    %rbp
  7c8c72:	ret
  7c8c73:	xor    %r11d,%r11d
  7c8c76:	cmp    %r10d,%r8d
  7c8c79:	jbe    7c8bee <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x1ce>
  7c8c7f:	movss  0x10(%rsi),%xmm3
  7c8c84:	movaps %xmm0,%xmm2
  7c8c87:	test   %r11b,%r11b
  7c8c8a:	je     7c8c17 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x1f7>
  7c8c8c:	subss  %xmm3,%xmm2
  7c8c90:	jmp    7c8c17 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x1f7>
  7c8c92:	lea    0x2d3cef(%rip),%rdx        # a9c988 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0xf80>
  7c8c99:	mov    $0x1,%edi
  7c8c9e:	mov    $0x1,%esi
  7c8ca3:	call   *0x2f0227(%rip)        # ab8ed0 <_DYNAMIC+0x270>
  7c8ca9:	lea    0x2d3cf0(%rip),%rdx        # a9c9a0 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0xf98>
  7c8cb0:	mov    %rax,%rdi
  7c8cb3:	mov    %r8,%rsi
  7c8cb6:	call   *0x2f0214(%rip)        # ab8ed0 <_DYNAMIC+0x270>
  7c8cbc:	lea    0x2d3cf5(%rip),%rdx        # a9c9b8 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0xfb0>
  7c8cc3:	mov    %rcx,%rdi
  7c8cc6:	mov    %r8,%rsi
  7c8cc9:	call   *0x2f0201(%rip)        # ab8ed0 <_DYNAMIC+0x270>

<gpui_canvas::text::layout::TextGeometry>::grapheme_at bytes=850 frame=264

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007d4bb0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at>:
  7d4bb0:	push   %rbp
  7d4bb1:	push   %r15
  7d4bb3:	push   %r14
  7d4bb5:	push   %r13
  7d4bb7:	push   %r12
  7d4bb9:	push   %rbx
  7d4bba:	sub    $0xd8,%rsp
  7d4bc1:	mov    %rdi,%rbx
  7d4bc4:	movd   %xmm1,%eax
  7d4bc8:	movd   %xmm0,%ecx
  7d4bcc:	and    $0x7fffffff,%ecx
  7d4bd2:	cmp    $0x7f800000,%ecx
  7d4bd8:	setge  %cl
  7d4bdb:	and    $0x7fffffff,%eax
  7d4be0:	cmp    $0x7f800000,%eax
  7d4be5:	setge  %al
  7d4be8:	or     %cl,%al
  7d4bea:	cmp    $0x1,%al
  7d4bec:	jne    7d4bf7 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x47>
  7d4bee:	movb   $0x2,0x4(%rbx)
  7d4bf2:	jmp    7d4d8e <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x1de>
  7d4bf7:	mov    0x20(%rsi),%rcx
  7d4bfb:	mov    0x28(%rsi),%rax
  7d4bff:	mov    %rax,%r14
  7d4c02:	test   %rax,%rax
  7d4c05:	je     7d4c5e <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0xae>
  7d4c07:	xor    %edx,%edx
  7d4c09:	cmp    $0x1,%rax
  7d4c0d:	je     7d4c43 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x93>
  7d4c0f:	mov    %rax,%rdi
  7d4c12:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  7d4c20:	mov    %rdx,%r8
  7d4c23:	mov    %rdi,%r9
  7d4c26:	shr    $1,%r9
  7d4c29:	add    %r9,%rdx
  7d4c2c:	lea    (%rdx,%rdx,2),%r10
  7d4c30:	ucomiss 0x8(%rcx,%r10,8),%xmm1
  7d4c36:	cmovb  %r8,%rdx
  7d4c3a:	sub    %r9,%rdi
  7d4c3d:	cmp    $0x1,%rdi
  7d4c41:	ja     7d4c20 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x70>
  7d4c43:	lea    (%rdx,%rdx,2),%rdi
  7d4c47:	xor    %r14d,%r14d
  7d4c4a:	ucomiss 0x8(%rcx,%rdi,8),%xmm1
  7d4c4f:	setae  %r14b
  7d4c53:	add    %rdx,%r14
  7d4c56:	cmp    $0x1,%r14
  7d4c5a:	adc    $0xffffffffffffffff,%r14
  7d4c5e:	mov    %r14,0x10(%rsp)
  7d4c63:	cmp    %rax,%r14
  7d4c66:	jae    7d4eef <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x33f>
  7d4c6c:	lea    (%r14,%r14,2),%rdx
  7d4c70:	mov    (%rcx,%rdx,8),%r8d
  7d4c74:	test   %r8d,%r8d
  7d4c77:	movss  %xmm1,0xc(%rsp)
  7d4c7d:	movd   %xmm0,0x8(%rsp)
  7d4c83:	je     7d4ccd <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x11d>
  7d4c85:	mov    0x38(%rsi),%rdx
  7d4c89:	mov    0x40(%rsi),%r13
  7d4c8d:	test   %r13,%r13
  7d4c90:	je     7d4cd9 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x129>
  7d4c92:	xor    %edi,%edi
  7d4c94:	cmp    $0x1,%r13
  7d4c98:	je     7d4cbf <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x10f>
  7d4c9a:	mov    %r13,%r9
  7d4c9d:	nopl   (%rax)
  7d4ca0:	mov    %r9,%r10
  7d4ca3:	shr    $1,%r10
  7d4ca6:	lea    (%r10,%rdi,1),%r11
  7d4caa:	lea    (%r11,%r11,2),%r15
  7d4cae:	cmp    %r8d,(%rdx,%r15,4)
  7d4cb2:	cmovb  %r11,%rdi
  7d4cb6:	sub    %r10,%r9
  7d4cb9:	cmp    $0x1,%r9
  7d4cbd:	ja     7d4ca0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0xf0>
  7d4cbf:	lea    (%rdi,%rdi,2),%r9
  7d4cc3:	cmp    %r8d,(%rdx,%r9,4)
  7d4cc7:	adc    $0x0,%rdi
  7d4ccb:	jmp    7d4cdc <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x12c>
  7d4ccd:	mov    0x38(%rsi),%rdx
  7d4cd1:	mov    0x40(%rsi),%r13
  7d4cd5:	xor    %edi,%edi
  7d4cd7:	jmp    7d4cdc <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x12c>
  7d4cd9:	mov    %r13,%rdi
  7d4cdc:	lea    (%rdi,%rdi,2),%r8
  7d4ce0:	lea    (%rdx,%r8,4),%r15
  7d4ce4:	movss  0x4c(%rsi),%xmm0
  7d4ce9:	sub    %rdi,%r13
  7d4cec:	je     7d4ec7 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x317>
  7d4cf2:	mov    (%r15),%edx
  7d4cf5:	mulss  -0x7128a5(%rip),%xmm0        # c2458 <GCC_except_table0+0xf0>
  7d4cfd:	xor    %edi,%edi
  7d4cff:	cmp    $0x1,%rax
  7d4d03:	je     7d4d31 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x181>
  7d4d05:	data16 cs nopw 0x0(%rax,%rax,1)
  7d4d10:	mov    %rdi,%r8
  7d4d13:	mov    %rax,%r9
  7d4d16:	shr    $1,%r9
  7d4d19:	add    %r9,%rdi
  7d4d1c:	lea    (%rdi,%rdi,2),%r10
  7d4d20:	cmp    %edx,(%rcx,%r10,8)
  7d4d24:	cmova  %r8,%rdi
  7d4d28:	sub    %r9,%rax
  7d4d2b:	cmp    $0x1,%rax
  7d4d2f:	ja     7d4d10 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x160>
  7d4d31:	lea    (%rdi,%rdi,2),%rax
  7d4d35:	xor    %r8d,%r8d
  7d4d38:	cmp    %edx,(%rcx,%rax,8)
  7d4d3b:	setbe  %r8b
  7d4d3f:	add    %rdi,%r8
  7d4d42:	cmp    $0x1,%r8
  7d4d46:	adc    $0xffffffffffffffff,%r8
  7d4d4a:	mov    %r15,0x18(%rsp)
  7d4d4f:	mov    %r13,0x20(%rsp)
  7d4d54:	movq   $0x2,0x28(%rsp)
  7d4d5d:	mov    %rsi,0x30(%rsp)
  7d4d62:	mov    %r8,0x38(%rsp)
  7d4d67:	movss  %xmm0,0x40(%rsp)
  7d4d6d:	movb   $0x0,0x58(%rsp)
  7d4d72:	mov    %rsi,0x48(%rsp)
  7d4d77:	lea    0x10(%rsp),%rax
  7d4d7c:	mov    %rax,0x50(%rsp)
  7d4d81:	mov    $0x2,%r12b
  7d4d84:	cmp    $0x2,%r13
  7d4d88:	jae    7d4da3 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x1f3>
  7d4d8a:	mov    %r12b,0x4(%rbx)
  7d4d8e:	mov    %rbx,%rax
  7d4d91:	add    $0xd8,%rsp
  7d4d98:	pop    %rbx
  7d4d99:	pop    %r12
  7d4d9b:	pop    %r13
  7d4d9d:	pop    %r14
  7d4d9f:	pop    %r15
  7d4da1:	pop    %rbp
  7d4da2:	ret
  7d4da3:	inc    %r13
  7d4da6:	jmp    7d4dbd <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x20d>
  7d4da8:	nopl   0x0(%rax,%rax,1)
  7d4db0:	add    $0xc,%r15
  7d4db4:	dec    %r13
  7d4db7:	cmp    $0x3,%r13
  7d4dbb:	jb     7d4d8a <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x1da>
  7d4dbd:	mov    (%r15),%eax
  7d4dc0:	cmp    0xc(%r15),%eax
  7d4dc4:	je     7d4db0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x200>
  7d4dc6:	testb  $0x2,0x8(%r15)
  7d4dcb:	je     7d4db0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x200>
  7d4dcd:	testb  $0x1,0x14(%r15)
  7d4dd2:	je     7d4db0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x200>
  7d4dd4:	mov    $0x2,%ecx
  7d4dd9:	lea    0xa0(%rsp),%rdi
  7d4de1:	lea    0x30(%rsp),%rsi
  7d4de6:	mov    %r15,%rdx
  7d4de9:	call   7c8a20 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_>
  7d4dee:	mov    0x48(%rsp),%rax
  7d4df3:	mov    0x50(%rsp),%rcx
  7d4df8:	mov    (%rcx),%rdi
  7d4dfb:	mov    0x28(%rax),%rsi
  7d4dff:	cmp    %rsi,%rdi
  7d4e02:	jae    7d4ee2 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x332>
  7d4e08:	mov    0xa0(%rsp),%ebp
  7d4e0f:	mov    0x20(%rax),%rax
  7d4e13:	lea    (%rdi,%rdi,2),%rcx
  7d4e17:	cmp    0x4(%rax,%rcx,8),%ebp
  7d4e1b:	ja     7d4d8a <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x1da>
  7d4e21:	cmp    %r14,0xc0(%rsp)
  7d4e29:	jne    7d4db0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x200>
  7d4e2b:	lea    0xb0(%rsp),%rdi
  7d4e33:	movss  0x8(%rsp),%xmm0
  7d4e39:	movss  0xc(%rsp),%xmm1
  7d4e3f:	call   *0x2e44a3(%rip)        # ab92e8 <_DYNAMIC+0x688>
  7d4e45:	test   %al,%al
  7d4e47:	je     7d4db0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x200>
  7d4e4d:	movzbl 0xa4(%rsp),%eax
  7d4e55:	cmp    $0x2,%al
  7d4e57:	je     7d4db0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x200>
  7d4e5d:	lea    0xb0(%rsp),%rdx
  7d4e65:	mov    0x24(%rdx),%ecx
  7d4e68:	mov    %ecx,0x8f(%rsp)
  7d4e6f:	movups -0xb(%rdx),%xmm0
  7d4e73:	movups 0x5(%rdx),%xmm1
  7d4e77:	movups 0x15(%rdx),%xmm2
  7d4e7b:	movaps %xmm2,0x80(%rsp)
  7d4e83:	movaps %xmm1,0x70(%rsp)
  7d4e88:	movaps %xmm0,0x60(%rsp)
  7d4e8d:	cmp    $0xff,%al
  7d4e8f:	je     7d4db0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x200>
  7d4e95:	mov    0x8f(%rsp),%ecx
  7d4e9c:	mov    %ecx,0x34(%rbx)
  7d4e9f:	movaps 0x60(%rsp),%xmm0
  7d4ea4:	movaps 0x70(%rsp),%xmm1
  7d4ea9:	movaps 0x80(%rsp),%xmm2
  7d4eb1:	movups %xmm2,0x25(%rbx)
  7d4eb5:	movups %xmm1,0x15(%rbx)
  7d4eb9:	movups %xmm0,0x5(%rbx)
  7d4ebd:	mov    %ebp,(%rbx)
  7d4ebf:	mov    %eax,%r12d
  7d4ec2:	jmp    7d4d8a <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x1da>
  7d4ec7:	xor    %edx,%edx
  7d4ec9:	mulss  -0x712a79(%rip),%xmm0        # c2458 <GCC_except_table0+0xf0>
  7d4ed1:	xor    %edi,%edi
  7d4ed3:	cmp    $0x1,%rax
  7d4ed7:	jne    7d4d10 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x160>
  7d4edd:	jmp    7d4d31 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x181>
  7d4ee2:	lea    0x2c7a0f(%rip),%rdx        # a9c8f8 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0xef0>
  7d4ee9:	call   *0x2e3fe1(%rip)        # ab8ed0 <_DYNAMIC+0x270>
  7d4eef:	lea    0x2c833a(%rip),%rdx        # a9d230 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0x1828>
  7d4ef6:	mov    %r14,%rdi
  7d4ef9:	mov    %rax,%rsi
  7d4efc:	call   *0x2e3fce(%rip)        # ab8ed0 <_DYNAMIC+0x270>

<gpui_canvas::text::layout::TextGeometry>::move_visual bytes=1175 frame=216

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007d4f10 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual>:
  7d4f10:	push   %rbp
  7d4f11:	push   %r15
  7d4f13:	push   %r14
  7d4f15:	push   %r13
  7d4f17:	push   %r12
  7d4f19:	push   %rbx
  7d4f1a:	sub    $0xa8,%rsp
  7d4f21:	mov    %ecx,%r14d
  7d4f24:	mov    %edx,%r13d
  7d4f27:	mov    %esi,%ebp
  7d4f29:	mov    %rdi,%rbx
  7d4f2c:	lea    0x20(%rsp),%rdi
  7d4f31:	mov    %rbx,%rsi
  7d4f34:	mov    %ebp,%edx
  7d4f36:	mov    %r13d,%ecx
  7d4f39:	call   *0x2e48c1(%rip)        # ab9800 <_DYNAMIC+0xba0>
  7d4f3f:	cmpl   $0x1,0x20(%rsp)
  7d4f44:	jne    7d4fbb <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0xab>
  7d4f46:	test   %ebp,%ebp
  7d4f48:	setne  %cl
  7d4f4b:	mov    %r13d,%edx
  7d4f4e:	not    %dl
  7d4f50:	mov    0x20(%rbx),%rax
  7d4f54:	mov    0x28(%rbx),%r12
  7d4f58:	mov    %r12,%rdi
  7d4f5b:	test   %cl,%dl
  7d4f5d:	jne    7d4fc3 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0xb3>
  7d4f5f:	test   %r12,%r12
  7d4f62:	je     7d5018 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x108>
  7d4f68:	xor    %ecx,%ecx
  7d4f6a:	cmp    $0x1,%r12
  7d4f6e:	je     7d4fa1 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x91>
  7d4f70:	mov    %r12,%rdx
  7d4f73:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  7d4f80:	mov    %rcx,%rsi
  7d4f83:	mov    %rdx,%rdi
  7d4f86:	shr    $1,%rdi
  7d4f89:	add    %rdi,%rcx
  7d4f8c:	lea    (%rcx,%rcx,2),%r8
  7d4f90:	cmp    %ebp,(%rax,%r8,8)
  7d4f94:	cmova  %rsi,%rcx
  7d4f98:	sub    %rdi,%rdx
  7d4f9b:	cmp    $0x1,%rdx
  7d4f9f:	ja     7d4f80 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x70>
  7d4fa1:	lea    (%rcx,%rcx,2),%rdx
  7d4fa5:	xor    %edi,%edi
  7d4fa7:	cmp    %ebp,(%rax,%rdx,8)
  7d4faa:	setbe  %dil
  7d4fae:	add    %rcx,%rdi
  7d4fb1:	cmp    $0x1,%rdi
  7d4fb5:	adc    $0xffffffffffffffff,%rdi
  7d4fb9:	jmp    7d5018 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x108>
  7d4fbb:	mov    $0x2,%r13b
  7d4fbe:	jmp    7d5373 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x463>
  7d4fc3:	test   %r12,%r12
  7d4fc6:	je     7d500c <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0xfc>
  7d4fc8:	xor    %edi,%edi
  7d4fca:	cmp    $0x1,%r12
  7d4fce:	je     7d5000 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0xf0>
  7d4fd0:	mov    %r12,%rcx
  7d4fd3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  7d4fe0:	mov    %rcx,%rdx
  7d4fe3:	shr    $1,%rdx
  7d4fe6:	lea    (%rdx,%rdi,1),%rsi
  7d4fea:	lea    (%rsi,%rsi,2),%r8
  7d4fee:	cmp    %ebp,0x4(%rax,%r8,8)
  7d4ff3:	cmovb  %rsi,%rdi
  7d4ff7:	sub    %rdx,%rcx
  7d4ffa:	cmp    $0x1,%rcx
  7d4ffe:	ja     7d4fe0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0xd0>
  7d5000:	lea    (%rdi,%rdi,2),%rcx
  7d5004:	cmp    %ebp,0x4(%rax,%rcx,8)
  7d5008:	adc    $0x0,%rdi
  7d500c:	lea    -0x1(%r12),%rcx
  7d5011:	cmp    %rdi,%rcx
  7d5014:	cmovb  %rcx,%rdi
  7d5018:	movss  0x24(%rsp),%xmm0
  7d501e:	movss  %xmm0,0xc(%rsp)
  7d5024:	mov    %rdi,0x18(%rsp)
  7d5029:	cmp    %r12,%rdi
  7d502c:	jae    7d5397 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x487>
  7d5032:	mov    %r14d,0x4(%rsp)
  7d5037:	lea    (%rdi,%rdi,2),%rcx
  7d503b:	mov    (%rax,%rcx,8),%edx
  7d503e:	test   %edx,%edx
  7d5040:	je     7d508d <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x17d>
  7d5042:	mov    0x38(%rbx),%r15
  7d5046:	mov    0x40(%rbx),%r14
  7d504a:	xor    %ecx,%ecx
  7d504c:	test   %r14,%r14
  7d504f:	je     7d50dd <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x1cd>
  7d5055:	cmp    $0x1,%r14
  7d5059:	je     7d507f <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x16f>
  7d505b:	xor    %ecx,%ecx
  7d505d:	mov    %r14,%rsi
  7d5060:	mov    %rsi,%rdi
  7d5063:	shr    $1,%rdi
  7d5066:	lea    (%rdi,%rcx,1),%r8
  7d506a:	lea    (%r8,%r8,2),%r9
  7d506e:	cmp    %edx,(%r15,%r9,4)
  7d5072:	cmovb  %r8,%rcx
  7d5076:	sub    %rdi,%rsi
  7d5079:	cmp    $0x1,%rsi
  7d507d:	ja     7d5060 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x150>
  7d507f:	lea    (%rcx,%rcx,2),%rsi
  7d5083:	cmp    %edx,(%r15,%rsi,4)
  7d5087:	adc    $0x0,%rcx
  7d508b:	jmp    7d5097 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x187>
  7d508d:	mov    0x38(%rbx),%r15
  7d5091:	mov    0x40(%rbx),%r14
  7d5095:	xor    %ecx,%ecx
  7d5097:	lea    (%rcx,%rcx,2),%rdx
  7d509b:	lea    (%r15,%rdx,4),%r15
  7d509f:	movss  0x4c(%rbx),%xmm0
  7d50a4:	sub    %rcx,%r14
  7d50a7:	jne    7d50c3 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x1b3>
  7d50a9:	xor    %r14d,%r14d
  7d50ac:	xor    %ecx,%ecx
  7d50ae:	mulss  -0x712c5e(%rip),%xmm0        # c2458 <GCC_except_table0+0xf0>
  7d50b6:	cmp    $0x1,%r12
  7d50ba:	mov    %r13d,0x14(%rsp)
  7d50bf:	je     7d50d9 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x1c9>
  7d50c1:	jmp    7d50f8 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x1e8>
  7d50c3:	mov    (%r15),%ecx
  7d50c6:	mulss  -0x712c76(%rip),%xmm0        # c2458 <GCC_except_table0+0xf0>
  7d50ce:	cmp    $0x1,%r12
  7d50d2:	mov    %r13d,0x14(%rsp)
  7d50d7:	jne    7d50f8 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x1e8>
  7d50d9:	xor    %edx,%edx
  7d50db:	jmp    7d5121 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x211>
  7d50dd:	movss  0x4c(%rbx),%xmm0
  7d50e2:	xor    %r14d,%r14d
  7d50e5:	mulss  -0x712c95(%rip),%xmm0        # c2458 <GCC_except_table0+0xf0>
  7d50ed:	cmp    $0x1,%r12
  7d50f1:	mov    %r13d,0x14(%rsp)
  7d50f6:	je     7d50d9 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x1c9>
  7d50f8:	xor    %edx,%edx
  7d50fa:	mov    %r12,%rsi
  7d50fd:	nopl   (%rax)
  7d5100:	mov    %rdx,%rdi
  7d5103:	mov    %rsi,%r8
  7d5106:	shr    $1,%r8
  7d5109:	add    %r8,%rdx
  7d510c:	lea    (%rdx,%rdx,2),%r9
  7d5110:	cmp    %ecx,(%rax,%r9,8)
  7d5114:	cmova  %rdi,%rdx
  7d5118:	sub    %r8,%rsi
  7d511b:	cmp    $0x1,%rsi
  7d511f:	ja     7d5100 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x1f0>
  7d5121:	lea    (%rdx,%rdx,2),%rsi
  7d5125:	xor    %edi,%edi
  7d5127:	cmp    %ecx,(%rax,%rsi,8)
  7d512a:	setbe  %dil
  7d512e:	add    %rdx,%rdi
  7d5131:	cmp    $0x1,%rdi
  7d5135:	adc    $0xffffffffffffffff,%rdi
  7d5139:	lea    0x18(%rsp),%rax
  7d513e:	mov    %rax,0x20(%rsp)
  7d5143:	mov    %r15,0x28(%rsp)
  7d5148:	mov    %r14,0x30(%rsp)
  7d514d:	movq   $0x2,0x38(%rsp)
  7d5156:	mov    %rbx,0x40(%rsp)
  7d515b:	mov    %rdi,0x48(%rsp)
  7d5160:	movss  %xmm0,0x50(%rsp)
  7d5166:	mov    %rbx,0x58(%rsp)
  7d516b:	mov    %rax,0x60(%rsp)
  7d5170:	movb   $0x0,0x68(%rsp)
  7d5175:	movss  -0x712c8d(%rip),%xmm0        # c24f0 <GCC_except_table0+0x188>
  7d517d:	movss  %xmm0,0x10(%rsp)
  7d5183:	mov    $0x2,%r13b
  7d5186:	cmp    $0x2,%r14
  7d518a:	jb     7d52f9 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x3e9>
  7d5190:	inc    %r14
  7d5193:	add    $0xc,%r15
  7d5197:	jmp    7d51b1 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x2a1>
  7d5199:	nopl   0x0(%rax)
  7d51a0:	dec    %r14
  7d51a3:	add    $0xc,%r15
  7d51a7:	cmp    $0x3,%r14
  7d51ab:	jb     7d52f9 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x3e9>
  7d51b1:	mov    -0xc(%r15),%eax
  7d51b5:	cmp    (%r15),%eax
  7d51b8:	je     7d51a0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x290>
  7d51ba:	testb  $0x2,-0x4(%r15)
  7d51bf:	je     7d51a0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x290>
  7d51c1:	testb  $0x1,0x8(%r15)
  7d51c6:	je     7d51a0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x290>
  7d51c8:	lea    -0xc(%r15),%rdx
  7d51cc:	mov    $0x2,%ecx
  7d51d1:	lea    0x70(%rsp),%rdi
  7d51d6:	lea    0x40(%rsp),%rsi
  7d51db:	call   7c8a20 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_>
  7d51e0:	mov    0x58(%rsp),%rcx
  7d51e5:	mov    0x60(%rsp),%rax
  7d51ea:	mov    (%rax),%rdi
  7d51ed:	mov    0x28(%rcx),%rsi
  7d51f1:	cmp    %rsi,%rdi
  7d51f4:	jae    7d538a <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x47a>
  7d51fa:	mov    0x70(%rsp),%eax
  7d51fe:	mov    0x20(%rcx),%rcx
  7d5202:	lea    (%rdi,%rdi,2),%rdx
  7d5206:	cmp    0x4(%rcx,%rdx,8),%eax
  7d520a:	ja     7d52f9 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x3e9>
  7d5210:	mov    0x90(%rsp),%rcx
  7d5218:	cmp    0x18(%rsp),%rcx
  7d521d:	movzbl 0x74(%rsp),%ecx
  7d5222:	setne  %dl
  7d5225:	or     0xa0(%rsp),%dl
  7d522c:	cmp    $0x2,%cl
  7d522f:	sete   %sil
  7d5233:	or     %dl,%sil
  7d5236:	test   $0x1,%sil
  7d523a:	jne    7d51a0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x290>
  7d5240:	cmp    $0xff,%cl
  7d5243:	je     7d51a0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x290>
  7d5249:	mov    0x98(%rsp),%rdx
  7d5251:	movd   %edx,%xmm0
  7d5255:	shr    $0x20,%rdx
  7d5259:	movd   %edx,%xmm1
  7d525d:	cmpb   $0x0,0x4(%rsp)
  7d5262:	je     7d5287 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x377>
  7d5264:	movaps %xmm0,%xmm3
  7d5267:	maxss  %xmm1,%xmm3
  7d526b:	movaps %xmm3,%xmm2
  7d526e:	cmpunordss %xmm3,%xmm2
  7d5273:	movaps %xmm2,%xmm4
  7d5276:	andnps %xmm3,%xmm4
  7d5279:	andps  %xmm0,%xmm2
  7d527c:	orps   %xmm4,%xmm2
  7d527f:	subss  0xc(%rsp),%xmm2
  7d5285:	jmp    7d52ad <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x39d>
  7d5287:	movdqa %xmm0,%xmm2
  7d528b:	minss  %xmm1,%xmm2
  7d528f:	movaps %xmm2,%xmm3
  7d5292:	cmpunordss %xmm2,%xmm3
  7d5297:	movaps %xmm3,%xmm4
  7d529a:	andnps %xmm2,%xmm4
  7d529d:	andps  %xmm0,%xmm3
  7d52a0:	orps   %xmm4,%xmm3
  7d52a3:	movss  0xc(%rsp),%xmm2
  7d52a9:	subss  %xmm3,%xmm2
  7d52ad:	xorps  %xmm3,%xmm3
  7d52b0:	ucomiss %xmm3,%xmm2
  7d52b3:	jbe    7d52ea <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x3da>
  7d52b5:	movss  0x10(%rsp),%xmm3
  7d52bb:	ucomiss %xmm2,%xmm3
  7d52be:	jbe    7d52ea <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x3da>
  7d52c0:	ucomiss %xmm0,%xmm1
  7d52c3:	setbe  %dl
  7d52c6:	xor    0x4(%rsp),%dl
  7d52ca:	cmovne 0x78(%rsp),%eax
  7d52cf:	movzbl 0x7c(%rsp),%edx
  7d52d4:	movzbl %cl,%r13d
  7d52d8:	cmovne %edx,%r13d
  7d52dc:	and    $0x1,%r13b
  7d52e0:	movss  %xmm2,0x10(%rsp)
  7d52e6:	mov    %eax,0x8(%rsp)
  7d52ea:	add    $0xfffffffffffffffe,%r14
  7d52ee:	cmpb   $0x0,0x68(%rsp)
  7d52f3:	je     7d5186 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x276>
  7d52f9:	cmp    $0x2,%r13b
  7d52fd:	jne    7d5367 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x457>
  7d52ff:	mov    0x18(%rsp),%rsi
  7d5304:	cmpb   $0x0,0x4(%rsp)
  7d5309:	je     7d532f <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x41f>
  7d530b:	cmp    $0xffffffffffffffff,%rsi
  7d530f:	mov    0x14(%rsp),%r13d
  7d5314:	je     7d536d <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x45d>
  7d5316:	inc    %rsi
  7d5319:	xor    %eax,%eax
  7d531b:	cmp    %r12,%rsi
  7d531e:	setb   %al
  7d5321:	test   $0x1,%al
  7d5323:	je     7d5373 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x463>
  7d5325:	movss  -0x712e11(%rip),%xmm0        # c251c <GCC_except_table0+0x1b4>
  7d532d:	jmp    7d5358 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x448>
  7d532f:	test   %rsi,%rsi
  7d5332:	mov    0x14(%rsp),%r13d
  7d5337:	je     7d534a <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x43a>
  7d5339:	dec    %rsi
  7d533c:	xor    %eax,%eax
  7d533e:	cmp    %r12,%rsi
  7d5341:	setb   %al
  7d5344:	test   $0x1,%al
  7d5346:	jne    7d5350 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x440>
  7d5348:	jmp    7d5373 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x463>
  7d534a:	xor    %eax,%eax
  7d534c:	test   $0x1,%al
  7d534e:	je     7d5373 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x463>
  7d5350:	movss  -0x712e7c(%rip),%xmm0        # c24dc <GCC_except_table0+0x174>
  7d5358:	mov    %rbx,%rdi
  7d535b:	call   7d5470 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line>
  7d5360:	mov    %eax,0x8(%rsp)
  7d5364:	mov    %edx,%r13d
  7d5367:	mov    0x8(%rsp),%ebp
  7d536b:	jmp    7d5373 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x463>
  7d536d:	xor    %eax,%eax
  7d536f:	test   $0x1,%al
  7d5371:	jne    7d5325 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x415>
  7d5373:	mov    %ebp,%eax
  7d5375:	mov    %r13d,%edx
  7d5378:	add    $0xa8,%rsp
  7d537f:	pop    %rbx
  7d5380:	pop    %r12
  7d5382:	pop    %r13
  7d5384:	pop    %r14
  7d5386:	pop    %r15
  7d5388:	pop    %rbp
  7d5389:	ret
  7d538a:	lea    0x2c757f(%rip),%rdx        # a9c910 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0xf08>
  7d5391:	call   *0x2e3b39(%rip)        # ab8ed0 <_DYNAMIC+0x270>
  7d5397:	lea    0x2c7e92(%rip),%rdx        # a9d230 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0x1828>
  7d539e:	mov    %r12,%rsi
  7d53a1:	call   *0x2e3b29(%rip)        # ab8ed0 <_DYNAMIC+0x270>

<gpui_canvas::text::layout::TextGeometry>::next_visual bytes=10 frame=0

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007d53b0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11next_visual>:
  7d53b0:	mov    $0x1,%ecx
  7d53b5:	jmp    7d4f10 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual>

<gpui_canvas::text::layout::TextGeometry>::position_at bytes=151 frame=8

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007d53c0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11position_at>:
  7d53c0:	movd   %xmm1,%eax
  7d53c4:	movd   %xmm0,%ecx
  7d53c8:	and    $0x7fffffff,%ecx
  7d53ce:	cmp    $0x7f800000,%ecx
  7d53d4:	setge  %cl
  7d53d7:	and    $0x7fffffff,%eax
  7d53dc:	cmp    $0x7f800000,%eax
  7d53e1:	setge  %al
  7d53e4:	or     %cl,%al
  7d53e6:	je     7d53eb <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11position_at+0x2b>
  7d53e8:	mov    $0x2,%dl
  7d53ea:	ret
  7d53eb:	push   %rax
  7d53ec:	mov    0x28(%rdi),%rsi
  7d53f0:	test   %rsi,%rsi
  7d53f3:	je     7d544d <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11position_at+0x8d>
  7d53f5:	mov    0x20(%rdi),%rax
  7d53f9:	xor    %ecx,%ecx
  7d53fb:	cmp    $0x1,%rsi
  7d53ff:	je     7d5433 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11position_at+0x73>
  7d5401:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  7d5410:	mov    %rcx,%rdx
  7d5413:	mov    %rsi,%r8
  7d5416:	shr    $1,%r8
  7d5419:	add    %r8,%rcx
  7d541c:	lea    (%rcx,%rcx,2),%r9
  7d5420:	ucomiss 0x8(%rax,%r9,8),%xmm1
  7d5426:	cmovb  %rdx,%rcx
  7d542a:	sub    %r8,%rsi
  7d542d:	cmp    $0x1,%rsi
  7d5431:	ja     7d5410 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11position_at+0x50>
  7d5433:	lea    (%rcx,%rcx,2),%rdx
  7d5437:	xor    %esi,%esi
  7d5439:	ucomiss 0x8(%rax,%rdx,8),%xmm1
  7d543e:	setae  %sil
  7d5442:	add    %rcx,%rsi
  7d5445:	cmp    $0x1,%rsi
  7d5449:	adc    $0xffffffffffffffff,%rsi
  7d544d:	call   7d5470 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line>
  7d5452:	add    $0x8,%rsp
  7d5456:	ret

<gpui_canvas::text::layout::TextGeometry>::previous_visual bytes=7 frame=0

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007d5460 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry15previous_visual>:
  7d5460:	xor    %ecx,%ecx
  7d5462:	jmp    7d4f10 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual>

<gpui_canvas::text::layout::TextGeometry>::position_on_line bytes=1664 frame=232

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007d5470 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line>:
  7d5470:	push   %rbp
  7d5471:	push   %r15
  7d5473:	push   %r14
  7d5475:	push   %r13
  7d5477:	push   %r12
  7d5479:	push   %rbx
  7d547a:	sub    $0xb8,%rsp
  7d5481:	mov    %rsi,0x18(%rsp)
  7d5486:	mov    0x40(%rdi),%rbx
  7d548a:	test   %rbx,%rbx
  7d548d:	je     7d5554 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0xe4>
  7d5493:	mov    0x28(%rdi),%r11
  7d5497:	cmp    %r11,%rsi
  7d549a:	jae    7d5ad0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x660>
  7d54a0:	mov    0x20(%rdi),%r13
  7d54a4:	mov    0x38(%rdi),%rbp
  7d54a8:	lea    (%rsi,%rsi,2),%rax
  7d54ac:	mov    0x0(%r13,%rax,8),%ecx
  7d54b1:	test   %ecx,%ecx
  7d54b3:	movss  %xmm0,0x14(%rsp)
  7d54b9:	je     7d555b <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0xeb>
  7d54bf:	xor    %eax,%eax
  7d54c1:	xor    %edx,%edx
  7d54c3:	cmp    $0x1,%rbx
  7d54c7:	je     7d54f0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x80>
  7d54c9:	mov    %rbx,%rsi
  7d54cc:	nopl   0x0(%rax)
  7d54d0:	mov    %rsi,%r8
  7d54d3:	shr    $1,%r8
  7d54d6:	lea    (%r8,%rdx,1),%r9
  7d54da:	lea    (%r9,%r9,2),%r10
  7d54de:	cmp    %ecx,0x0(%rbp,%r10,4)
  7d54e3:	cmovb  %r9,%rdx
  7d54e7:	sub    %r8,%rsi
  7d54ea:	cmp    $0x1,%rsi
  7d54ee:	ja     7d54d0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x60>
  7d54f0:	lea    (%rdx,%rdx,2),%rsi
  7d54f4:	cmp    %ecx,0x0(%rbp,%rsi,4)
  7d54f8:	adc    $0x0,%rdx
  7d54fc:	lea    (%rdx,%rdx,2),%rcx
  7d5500:	lea    0x0(%rbp,%rcx,4),%rbp
  7d5505:	movss  0x4c(%rdi),%xmm0
  7d550a:	mulss  -0x7130ba(%rip),%xmm0        # c2458 <GCC_except_table0+0xf0>
  7d5512:	sub    %rdx,%rbx
  7d5515:	jne    7d5568 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0xf8>
  7d5517:	mov    $0x1,%cl
  7d5519:	xor    %ebx,%ebx
  7d551b:	cmp    $0x1,%r11
  7d551f:	mov    %r11,0x28(%rsp)
  7d5524:	mov    %ecx,0x24(%rsp)
  7d5528:	je     7d557c <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x10c>
  7d552a:	xor    %ecx,%ecx
  7d552c:	nopl   0x0(%rax)
  7d5530:	mov    %rcx,%rsi
  7d5533:	mov    %r11,%r8
  7d5536:	shr    $1,%r8
  7d5539:	add    %r8,%rcx
  7d553c:	lea    (%rcx,%rcx,2),%r9
  7d5540:	cmp    %eax,0x0(%r13,%r9,8)
  7d5545:	cmova  %rsi,%rcx
  7d5549:	sub    %r8,%r11
  7d554c:	cmp    $0x1,%r11
  7d5550:	ja     7d5530 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0xc0>
  7d5552:	jmp    7d557e <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x10e>
  7d5554:	mov    $0x2,%dl
  7d5556:	jmp    7d5a6a <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x5fa>
  7d555b:	movss  0x4c(%rdi),%xmm0
  7d5560:	mulss  -0x713110(%rip),%xmm0        # c2458 <GCC_except_table0+0xf0>
  7d5568:	mov    0x0(%rbp),%eax
  7d556b:	xor    %ecx,%ecx
  7d556d:	cmp    $0x1,%r11
  7d5571:	mov    %r11,0x28(%rsp)
  7d5576:	mov    %ecx,0x24(%rsp)
  7d557a:	jne    7d552a <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0xba>
  7d557c:	xor    %ecx,%ecx
  7d557e:	lea    (%rcx,%rcx,2),%rdx
  7d5582:	xor    %esi,%esi
  7d5584:	cmp    %eax,0x0(%r13,%rdx,8)
  7d5589:	setbe  %sil
  7d558d:	add    %rcx,%rsi
  7d5590:	cmp    $0x1,%rsi
  7d5594:	adc    $0xffffffffffffffff,%rsi
  7d5598:	lea    0x18(%rsp),%rax
  7d559d:	mov    %rax,0x30(%rsp)
  7d55a2:	mov    %rbp,0x38(%rsp)
  7d55a7:	mov    %rbx,0x40(%rsp)
  7d55ac:	movq   $0x2,0x48(%rsp)
  7d55b5:	mov    %rdi,0x50(%rsp)
  7d55ba:	mov    %rsi,0x58(%rsp)
  7d55bf:	movss  %xmm0,0x60(%rsp)
  7d55c5:	mov    %rdi,0x68(%rsp)
  7d55ca:	mov    %rax,0x70(%rsp)
  7d55cf:	movb   $0x0,0x78(%rsp)
  7d55d4:	mov    $0x2,%dl
  7d55d6:	mov    $0x2,%al
  7d55d8:	mov    %eax,0xc(%rsp)
  7d55dc:	mov    %rbx,%r12
  7d55df:	mov    %rbp,%r15
  7d55e2:	cmp    $0x2,%r12
  7d55e6:	jb     7d5a0d <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x59d>
  7d55ec:	mov    %dl,0x3(%rsp)
  7d55f0:	inc    %r12
  7d55f3:	add    $0xc,%r15
  7d55f7:	jmp    7d5611 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x1a1>
  7d55f9:	nopl   0x0(%rax)
  7d5600:	dec    %r12
  7d5603:	add    $0xc,%r15
  7d5607:	cmp    $0x3,%r12
  7d560b:	jb     7d57c0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x350>
  7d5611:	mov    -0xc(%r15),%eax
  7d5615:	cmp    (%r15),%eax
  7d5618:	je     7d5600 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x190>
  7d561a:	testb  $0x2,-0x4(%r15)
  7d561f:	je     7d5600 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x190>
  7d5621:	testb  $0x1,0x8(%r15)
  7d5626:	je     7d5600 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x190>
  7d5628:	lea    -0xc(%r15),%rdx
  7d562c:	mov    $0x2,%ecx
  7d5631:	lea    0x80(%rsp),%rdi
  7d5639:	lea    0x50(%rsp),%rsi
  7d563e:	call   7c8a20 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_>
  7d5643:	mov    0x68(%rsp),%rax
  7d5648:	mov    0x70(%rsp),%rcx
  7d564d:	mov    (%rcx),%rdi
  7d5650:	mov    0x28(%rax),%rsi
  7d5654:	cmp    %rsi,%rdi
  7d5657:	jae    7d5ac3 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x653>
  7d565d:	mov    0x80(%rsp),%r9d
  7d5665:	mov    0x20(%rax),%rax
  7d5669:	lea    (%rdi,%rdi,2),%rcx
  7d566d:	cmp    0x4(%rax,%rcx,8),%r9d
  7d5672:	ja     7d57c0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x350>
  7d5678:	movzbl 0x84(%rsp),%esi
  7d5680:	mov    0xa0(%rsp),%rax
  7d5688:	cmp    0x18(%rsp),%rax
  7d568d:	setne  %al
  7d5690:	cmp    $0x2,%sil
  7d5694:	sete   %cl
  7d5697:	or     %al,%cl
  7d5699:	cmp    $0x1,%cl
  7d569c:	je     7d5600 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x190>
  7d56a2:	cmp    $0xff,%sil
  7d56a6:	je     7d5600 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x190>
  7d56ac:	movss  0xa8(%rsp),%xmm1
  7d56b5:	and    $0x1,%sil
  7d56b9:	testb  $0x1,0xb0(%rsp)
  7d56c1:	je     7d56cd <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x25d>
  7d56c3:	mov    %r9d,%eax
  7d56c6:	mov    %esi,%ecx
  7d56c8:	movaps %xmm1,%xmm0
  7d56cb:	jmp    7d5742 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x2d2>
  7d56cd:	mov    0x88(%rsp),%eax
  7d56d4:	movzbl 0x8c(%rsp),%ecx
  7d56dc:	movss  0xac(%rsp),%xmm0
  7d56e5:	and    $0x1,%cl
  7d56e8:	movaps %xmm1,%xmm3
  7d56eb:	minss  %xmm0,%xmm3
  7d56ef:	movaps %xmm3,%xmm2
  7d56f2:	cmpunordss %xmm3,%xmm2
  7d56f7:	movaps %xmm2,%xmm4
  7d56fa:	andnps %xmm3,%xmm4
  7d56fd:	andps  %xmm1,%xmm2
  7d5700:	orps   %xmm4,%xmm2
  7d5703:	movaps %xmm1,%xmm3
  7d5706:	maxss  %xmm0,%xmm3
  7d570a:	ucomiss %xmm1,%xmm0
  7d570d:	mov    %r9d,%edi
  7d5710:	cmovbe %eax,%edi
  7d5713:	movaps %xmm3,%xmm0
  7d5716:	cmpunordss %xmm3,%xmm0
  7d571b:	movzbl %sil,%r8d
  7d571f:	movzbl %cl,%ecx
  7d5722:	mov    %r8d,%esi
  7d5725:	cmovbe %ecx,%esi
  7d5728:	movaps %xmm0,%xmm4
  7d572b:	cmovbe %r9d,%eax
  7d572f:	andnps %xmm3,%xmm4
  7d5732:	cmovbe %r8d,%ecx
  7d5736:	andps  %xmm1,%xmm0
  7d5739:	orps   %xmm4,%xmm0
  7d573c:	movaps %xmm2,%xmm1
  7d573f:	mov    %edi,%r9d
  7d5742:	movss  0x14(%rsp),%xmm2
  7d5748:	ucomiss %xmm2,%xmm1
  7d574b:	jbe    7d577d <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x30d>
  7d574d:	cmpb   $0x2,0xc(%rsp)
  7d5752:	je     7d575f <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x2ef>
  7d5754:	movss  0x10(%rsp),%xmm0
  7d575a:	ucomiss %xmm1,%xmm0
  7d575d:	jbe    7d576c <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x2fc>
  7d575f:	movss  %xmm1,0x10(%rsp)
  7d5765:	mov    %r9d,%r14d
  7d5768:	mov    %esi,0xc(%rsp)
  7d576c:	movss  0x4(%rsp),%xmm0
  7d5772:	mov    0x8(%rsp),%eax
  7d5776:	movzbl 0x3(%rsp),%ecx
  7d577b:	jmp    7d57a3 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x333>
  7d577d:	ucomiss %xmm0,%xmm2
  7d5780:	jbe    7d5a8e <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x61e>
  7d5786:	movzbl 0x3(%rsp),%edx
  7d578b:	cmp    $0x2,%dl
  7d578e:	je     7d57a3 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x333>
  7d5790:	ucomiss 0x4(%rsp),%xmm0
  7d5795:	ja     7d57a3 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x333>
  7d5797:	movss  0x4(%rsp),%xmm0
  7d579d:	mov    0x8(%rsp),%eax
  7d57a1:	mov    %edx,%ecx
  7d57a3:	add    $0xfffffffffffffffe,%r12
  7d57a7:	cmpb   $0x0,0x78(%rsp)
  7d57ac:	mov    %ecx,%edx
  7d57ae:	mov    %eax,0x8(%rsp)
  7d57b2:	movss  %xmm0,0x4(%rsp)
  7d57b8:	je     7d55e2 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x172>
  7d57be:	jmp    7d57cf <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x35f>
  7d57c0:	movss  0x4(%rsp),%xmm0
  7d57c6:	mov    0x8(%rsp),%eax
  7d57ca:	movzbl 0x3(%rsp),%ecx
  7d57cf:	cmp    $0x2,%cl
  7d57d2:	jne    7d5a22 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x5b2>
  7d57d8:	mov    0xc(%rsp),%edx
  7d57dc:	cmp    $0x2,%dl
  7d57df:	jne    7d5a67 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x5f7>
  7d57e5:	mov    $0x2,%dl
  7d57e7:	cmpb   $0x0,0x24(%rsp)
  7d57ec:	je     7d57f3 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x383>
  7d57ee:	jmp    7d5a6a <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x5fa>
  7d57f3:	mov    0x18(%rsp),%rdi
  7d57f8:	mov    0x28(%rsp),%rsi
  7d57fd:	cmp    %rsi,%rdi
  7d5800:	jae    7d5ae3 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x673>
  7d5806:	lea    (%rbx,%rbx,2),%rax
  7d580a:	lea    0x0(,%rax,4),%rax
  7d5812:	add    %rbp,%rax
  7d5815:	lea    (%rdi,%rdi,2),%rcx
  7d5819:	mov    0x4(%r13,%rcx,8),%ecx
  7d581e:	lea    -0x1(%rsi),%r12
  7d5822:	jmp    7d584c <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x3dc>
  7d5824:	xor    %ebx,%ebx
  7d5826:	lea    (%rbx,%rbx,2),%r8
  7d582a:	cmp    %r14d,0x4(%r13,%r8,8)
  7d582f:	adc    $0x0,%rbx
  7d5833:	cmp    %rbx,%r12
  7d5836:	cmovb  %r12,%rbx
  7d583a:	cmp    %rdi,%rbx
  7d583d:	je     7d5a83 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x613>
  7d5843:	add    $0xc,%rbp
  7d5847:	cmp    %rax,%rbp
  7d584a:	je     7d57ee <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x37e>
  7d584c:	mov    0x0(%rbp),%r14d
  7d5850:	cmp    %ecx,%r14d
  7d5853:	ja     7d5a6a <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x5fa>
  7d5859:	movzbl 0x8(%rbp),%r15d
  7d585e:	test   %r14d,%r14d
  7d5861:	je     7d5880 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x410>
  7d5863:	test   $0x2,%r15b
  7d5867:	je     7d58f6 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x486>
  7d586d:	mov    %rsi,%r9
  7d5870:	test   %rsi,%rsi
  7d5873:	je     7d58ed <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x47d>
  7d5875:	cmp    $0x1,%rsi
  7d5879:	jne    7d58a8 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x438>
  7d587b:	xor    %r8d,%r8d
  7d587e:	jmp    7d58d2 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x462>
  7d5880:	test   $0x2,%r15b
  7d5884:	je     7d5996 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x526>
  7d588a:	mov    %rsi,%r9
  7d588d:	test   %rsi,%rsi
  7d5890:	je     7d598d <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x51d>
  7d5896:	cmp    $0x1,%rsi
  7d589a:	jne    7d5945 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x4d5>
  7d58a0:	xor    %r8d,%r8d
  7d58a3:	jmp    7d5971 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x501>
  7d58a8:	mov    %rsi,%r9
  7d58ab:	xor    %r8d,%r8d
  7d58ae:	xchg   %ax,%ax
  7d58b0:	mov    %r8,%r10
  7d58b3:	mov    %r9,%r11
  7d58b6:	shr    $1,%r11
  7d58b9:	add    %r11,%r8
  7d58bc:	lea    (%r8,%r8,2),%rbx
  7d58c0:	cmp    %r14d,0x0(%r13,%rbx,8)
  7d58c5:	cmova  %r10,%r8
  7d58c9:	sub    %r11,%r9
  7d58cc:	cmp    $0x1,%r9
  7d58d0:	ja     7d58b0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x440>
  7d58d2:	lea    (%r8,%r8,2),%r10
  7d58d6:	xor    %r9d,%r9d
  7d58d9:	cmp    %r14d,0x0(%r13,%r10,8)
  7d58de:	setbe  %r9b
  7d58e2:	add    %r8,%r9
  7d58e5:	cmp    $0x1,%r9
  7d58e9:	adc    $0xffffffffffffffff,%r9
  7d58ed:	cmp    %rdi,%r9
  7d58f0:	je     7d5a7f <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x60f>
  7d58f6:	test   $0x1,%r15b
  7d58fa:	je     7d5843 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x3d3>
  7d5900:	mov    %rsi,%rbx
  7d5903:	test   %rsi,%rsi
  7d5906:	je     7d583a <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x3ca>
  7d590c:	cmp    $0x1,%rsi
  7d5910:	je     7d5824 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x3b4>
  7d5916:	mov    %rsi,%r8
  7d5919:	xor    %ebx,%ebx
  7d591b:	nopl   0x0(%rax,%rax,1)
  7d5920:	mov    %r8,%r9
  7d5923:	shr    $1,%r9
  7d5926:	lea    (%r9,%rbx,1),%r10
  7d592a:	lea    (%r10,%r10,2),%r11
  7d592e:	cmp    %r14d,0x4(%r13,%r11,8)
  7d5933:	cmovb  %r10,%rbx
  7d5937:	sub    %r9,%r8
  7d593a:	cmp    $0x1,%r8
  7d593e:	ja     7d5920 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x4b0>
  7d5940:	jmp    7d5826 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x3b6>
  7d5945:	mov    %rsi,%r9
  7d5948:	xor    %r8d,%r8d
  7d594b:	nopl   0x0(%rax,%rax,1)
  7d5950:	mov    %r9,%r10
  7d5953:	shr    $1,%r10
  7d5956:	lea    (%r10,%r8,1),%r11
  7d595a:	lea    (%r11,%r11,2),%rbx
  7d595e:	cmpl   $0x0,0x0(%r13,%rbx,8)
  7d5964:	cmove  %r11,%r8
  7d5968:	sub    %r10,%r9
  7d596b:	cmp    $0x1,%r9
  7d596f:	ja     7d5950 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x4e0>
  7d5971:	lea    (%r8,%r8,2),%r10
  7d5975:	xor    %r9d,%r9d
  7d5978:	cmpl   $0x0,0x0(%r13,%r10,8)
  7d597e:	sete   %r9b
  7d5982:	add    %r8,%r9
  7d5985:	cmp    $0x1,%r9
  7d5989:	adc    $0xffffffffffffffff,%r9
  7d598d:	cmp    %rdi,%r9
  7d5990:	je     7d5a87 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x617>
  7d5996:	test   $0x1,%r15b
  7d599a:	je     7d5843 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x3d3>
  7d59a0:	mov    %rsi,%r8
  7d59a3:	test   %rsi,%rsi
  7d59a6:	je     7d59fd <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x58d>
  7d59a8:	cmp    $0x1,%rsi
  7d59ac:	jne    7d59b2 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x542>
  7d59ae:	xor    %ebx,%ebx
  7d59b0:	jmp    7d59e1 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x571>
  7d59b2:	mov    %rsi,%r8
  7d59b5:	xor    %ebx,%ebx
  7d59b7:	nopw   0x0(%rax,%rax,1)
  7d59c0:	mov    %r8,%r9
  7d59c3:	shr    $1,%r9
  7d59c6:	lea    (%r9,%rbx,1),%r10
  7d59ca:	lea    (%r10,%r10,2),%r11
  7d59ce:	cmpl   $0x0,0x0(%r13,%r11,8)
  7d59d4:	cmove  %r10,%rbx
  7d59d8:	sub    %r9,%r8
  7d59db:	cmp    $0x1,%r8
  7d59df:	ja     7d59c0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x550>
  7d59e1:	lea    (%rbx,%rbx,2),%r9
  7d59e5:	xor    %r8d,%r8d
  7d59e8:	cmpl   $0x0,0x0(%r13,%r9,8)
  7d59ee:	sete   %r8b
  7d59f2:	add    %rbx,%r8
  7d59f5:	cmp    $0x1,%r8
  7d59f9:	adc    $0xffffffffffffffff,%r8
  7d59fd:	cmp    %rdi,%r8
  7d5a00:	jne    7d5843 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x3d3>
  7d5a06:	xor    %edx,%edx
  7d5a08:	xor    %r14d,%r14d
  7d5a0b:	jmp    7d5a6a <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x5fa>
  7d5a0d:	movss  0x4(%rsp),%xmm0
  7d5a13:	mov    0x8(%rsp),%eax
  7d5a17:	mov    %edx,%ecx
  7d5a19:	cmp    $0x2,%cl
  7d5a1c:	je     7d57d8 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x368>
  7d5a22:	mov    0xc(%rsp),%edx
  7d5a26:	cmp    $0x2,%dl
  7d5a29:	jne    7d5a32 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x5c2>
  7d5a2b:	mov    %eax,%r14d
  7d5a2e:	mov    %ecx,%edx
  7d5a30:	jmp    7d5a67 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x5f7>
  7d5a32:	cvtss2sd %xmm0,%xmm0
  7d5a36:	movss  0x10(%rsp),%xmm1
  7d5a3c:	cvtss2sd %xmm1,%xmm1
  7d5a40:	addsd  %xmm0,%xmm1
  7d5a44:	mulsd  -0x711d3c(%rip),%xmm1        # c3d10 <GCC_except_table0+0x19a8>
  7d5a4c:	movss  0x14(%rsp),%xmm0
  7d5a52:	cvtss2sd %xmm0,%xmm0
  7d5a56:	ucomisd %xmm1,%xmm0
  7d5a5a:	cmovbe %eax,%r14d
  7d5a5e:	movzbl %dl,%eax
  7d5a61:	movzbl %cl,%edx
  7d5a64:	cmova  %eax,%edx
  7d5a67:	and    $0x1,%dl
  7d5a6a:	mov    %r14d,%eax
  7d5a6d:	add    $0xb8,%rsp
  7d5a74:	pop    %rbx
  7d5a75:	pop    %r12
  7d5a77:	pop    %r13
  7d5a79:	pop    %r14
  7d5a7b:	pop    %r15
  7d5a7d:	pop    %rbp
  7d5a7e:	ret
  7d5a7f:	mov    $0x1,%dl
  7d5a81:	jmp    7d5a6a <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x5fa>
  7d5a83:	xor    %edx,%edx
  7d5a85:	jmp    7d5a6a <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x5fa>
  7d5a87:	xor    %r14d,%r14d
  7d5a8a:	mov    $0x1,%dl
  7d5a8c:	jmp    7d5a6a <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x5fa>
  7d5a8e:	cvtss2sd %xmm1,%xmm1
  7d5a92:	cvtss2sd %xmm0,%xmm0
  7d5a96:	addsd  %xmm1,%xmm0
  7d5a9a:	mulsd  -0x711d92(%rip),%xmm0        # c3d10 <GCC_except_table0+0x19a8>
  7d5aa2:	movss  0x14(%rsp),%xmm1
  7d5aa8:	cvtss2sd %xmm1,%xmm1
  7d5aac:	ucomisd %xmm0,%xmm1
  7d5ab0:	cmova  %eax,%r9d
  7d5ab4:	movzbl %cl,%eax
  7d5ab7:	movzbl %sil,%edx
  7d5abb:	cmova  %eax,%edx
  7d5abe:	mov    %r9d,%r14d
  7d5ac1:	jmp    7d5a6a <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x5fa>
  7d5ac3:	lea    0x2c6e5e(%rip),%rdx        # a9c928 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0xf20>
  7d5aca:	call   *0x2e3400(%rip)        # ab8ed0 <_DYNAMIC+0x270>
  7d5ad0:	lea    0x2c7759(%rip),%rdx        # a9d230 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0x1828>
  7d5ad7:	mov    %rsi,%rdi
  7d5ada:	mov    %r11,%rsi
  7d5add:	call   *0x2e33ed(%rip)        # ab8ed0 <_DYNAMIC+0x270>
  7d5ae3:	lea    0x2c6d7e(%rip),%rdx        # a9c868 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0xe60>
  7d5aea:	call   *0x2e33e0(%rip)        # ab8ed0 <_DYNAMIC+0x270>

<gpui_canvas::text::layout::TextGeometry>::graphemes bytes=178 frame=16

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007d5af0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry9graphemes>:
  7d5af0:	mov    %rdi,%rax
  7d5af3:	mov    0x38(%rsi),%rcx
  7d5af7:	mov    0x40(%rsi),%rdx
  7d5afb:	test   %rdx,%rdx
  7d5afe:	je     7d5b13 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry9graphemes+0x23>
  7d5b00:	mov    (%rcx),%r8d
  7d5b03:	movss  0x4c(%rsi),%xmm0
  7d5b08:	mov    0x28(%rsi),%rdi
  7d5b0c:	test   %rdi,%rdi
  7d5b0f:	jne    7d5b24 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry9graphemes+0x34>
  7d5b11:	jmp    7d5b7d <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry9graphemes+0x8d>
  7d5b13:	xor    %r8d,%r8d
  7d5b16:	movss  0x4c(%rsi),%xmm0
  7d5b1b:	mov    0x28(%rsi),%rdi
  7d5b1f:	test   %rdi,%rdi
  7d5b22:	je     7d5b7d <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry9graphemes+0x8d>
  7d5b24:	push   %r14
  7d5b26:	push   %rbx
  7d5b27:	mov    0x20(%rsi),%r9
  7d5b2b:	xor    %r10d,%r10d
  7d5b2e:	cmp    $0x1,%rdi
  7d5b32:	je     7d5b61 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry9graphemes+0x71>
  7d5b34:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  7d5b40:	mov    %r10,%r11
  7d5b43:	mov    %rdi,%rbx
  7d5b46:	shr    $1,%rbx
  7d5b49:	add    %rbx,%r10
  7d5b4c:	lea    (%r10,%r10,2),%r14
  7d5b50:	cmp    %r8d,(%r9,%r14,8)
  7d5b54:	cmova  %r11,%r10
  7d5b58:	sub    %rbx,%rdi
  7d5b5b:	cmp    $0x1,%rdi
  7d5b5f:	ja     7d5b40 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry9graphemes+0x50>
  7d5b61:	lea    (%r10,%r10,2),%r11
  7d5b65:	xor    %edi,%edi
  7d5b67:	cmp    %r8d,(%r9,%r11,8)
  7d5b6b:	setbe  %dil
  7d5b6f:	add    %r10,%rdi
  7d5b72:	cmp    $0x1,%rdi
  7d5b76:	adc    $0xffffffffffffffff,%rdi
  7d5b7a:	pop    %rbx
  7d5b7b:	pop    %r14
  7d5b7d:	mulss  -0x71372d(%rip),%xmm0        # c2458 <GCC_except_table0+0xf0>
  7d5b85:	mov    %rcx,(%rax)
  7d5b88:	mov    %rdx,0x8(%rax)
  7d5b8c:	movq   $0x2,0x10(%rax)
  7d5b94:	mov    %rsi,0x18(%rax)
  7d5b98:	mov    %rdi,0x20(%rax)
  7d5b9c:	movss  %xmm0,0x28(%rax)
  7d5ba1:	ret

<alloc::raw_vec::RawVec<gpui_canvas::text::layout::Run>>::grow_one bytes=100 frame=40

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007d8020 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout3RunE8grow_oneBR_>:
  7d8020:	push   %r14
  7d8022:	push   %rbx
  7d8023:	sub    $0x18,%rsp
  7d8027:	mov    %rdi,%rbx
  7d802a:	mov    (%rdi),%rsi
  7d802d:	lea    (%rsi,%rsi,1),%rax
  7d8031:	cmp    $0x5,%rax
  7d8035:	mov    $0x4,%r14d
  7d803b:	cmovae %rax,%r14
  7d803f:	mov    0x8(%rdi),%rdx
  7d8043:	mov    %rsp,%rdi
  7d8046:	mov    $0x4,%r8d
  7d804c:	mov    $0x18,%r9d
  7d8052:	mov    %r14,%rcx
  7d8055:	call   7d8730 <_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsghYClfd3M9V_11gpui_canvas>
  7d805a:	cmpl   $0x1,(%rsp)
  7d805e:	je     7d8074 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout3RunE8grow_oneBR_+0x54>
  7d8060:	mov    0x8(%rsp),%rax
  7d8065:	mov    %rax,0x8(%rbx)
  7d8069:	mov    %r14,(%rbx)
  7d806c:	add    $0x18,%rsp
  7d8070:	pop    %rbx
  7d8071:	pop    %r14
  7d8073:	ret
  7d8074:	mov    0x8(%rsp),%rdi
  7d8079:	mov    0x10(%rsp),%rsi
  7d807e:	call   *0x2e0ed4(%rip)        # ab8f58 <_DYNAMIC+0x2f8>

<alloc::raw_vec::RawVec<gpui_canvas::text::layout::Stop>>::grow_one bytes=100 frame=40

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007d8090 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopE8grow_oneBR_>:
  7d8090:	push   %r14
  7d8092:	push   %rbx
  7d8093:	sub    $0x18,%rsp
  7d8097:	mov    %rdi,%rbx
  7d809a:	mov    (%rdi),%rsi
  7d809d:	lea    (%rsi,%rsi,1),%rax
  7d80a1:	cmp    $0x5,%rax
  7d80a5:	mov    $0x4,%r14d
  7d80ab:	cmovae %rax,%r14
  7d80af:	mov    0x8(%rdi),%rdx
  7d80b3:	mov    %rsp,%rdi
  7d80b6:	mov    $0x4,%r8d
  7d80bc:	mov    $0xc,%r9d
  7d80c2:	mov    %r14,%rcx
  7d80c5:	call   7d8730 <_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsghYClfd3M9V_11gpui_canvas>
  7d80ca:	cmpl   $0x1,(%rsp)
  7d80ce:	je     7d80e4 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopE8grow_oneBR_+0x54>
  7d80d0:	mov    0x8(%rsp),%rax
  7d80d5:	mov    %rax,0x8(%rbx)
  7d80d9:	mov    %r14,(%rbx)
  7d80dc:	add    $0x18,%rsp
  7d80e0:	pop    %rbx
  7d80e1:	pop    %r14
  7d80e3:	ret
  7d80e4:	mov    0x8(%rsp),%rdi
  7d80e9:	mov    0x10(%rsp),%rsi
  7d80ee:	call   *0x2e0e64(%rip)        # ab8f58 <_DYNAMIC+0x2f8>

<gpui_canvas::text::layout::TextGeometry>::caret_bounds bytes=429 frame=24

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007d8460 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds>:
  7d8460:	push   %r14
  7d8462:	push   %rbx
  7d8463:	push   %rax
  7d8464:	mov    0x38(%rsi),%r8
  7d8468:	mov    0x40(%rsi),%rax
  7d846c:	mov    %rax,%r9
  7d846f:	test   %rax,%rax
  7d8472:	je     7d84ab <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x4b>
  7d8474:	xor    %r9d,%r9d
  7d8477:	cmp    $0x1,%rax
  7d847b:	je     7d849f <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x3f>
  7d847d:	mov    %rax,%r10
  7d8480:	mov    %r10,%r11
  7d8483:	shr    $1,%r11
  7d8486:	lea    (%r11,%r9,1),%rbx
  7d848a:	lea    (%rbx,%rbx,2),%r14
  7d848e:	cmp    %edx,(%r8,%r14,4)
  7d8492:	cmovb  %rbx,%r9
  7d8496:	sub    %r11,%r10
  7d8499:	cmp    $0x1,%r10
  7d849d:	ja     7d8480 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x20>
  7d849f:	lea    (%r9,%r9,2),%r10
  7d84a3:	cmp    %edx,(%r8,%r10,4)
  7d84a7:	adc    $0x0,%r9
  7d84ab:	inc    %cl
  7d84ad:	shl    $0x2,%r9
  7d84b1:	lea    (%r9,%r9,2),%r9
  7d84b5:	lea    (%r8,%r9,1),%r10
  7d84b9:	shl    $0x2,%rax
  7d84bd:	lea    (%rax,%rax,2),%rax
  7d84c1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  7d84d0:	xor    %r11d,%r11d
  7d84d3:	cmp    %r9,%rax
  7d84d6:	je     7d85ef <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x18f>
  7d84dc:	cmp    %edx,(%r10)
  7d84df:	jne    7d85ef <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x18f>
  7d84e5:	movzbl 0x8(%r10),%r11d
  7d84ea:	add    $0xc,%r10
  7d84ee:	add    $0xc,%r9
  7d84f2:	test   %cl,%r11b
  7d84f5:	je     7d84d0 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x70>
  7d84f7:	mov    0x20(%rsi),%rcx
  7d84fb:	mov    0x28(%rsi),%rsi
  7d84ff:	test   $0x1,%r11b
  7d8503:	je     7d855a <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0xfa>
  7d8505:	test   %edx,%edx
  7d8507:	je     7d855a <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0xfa>
  7d8509:	mov    %rsi,%rax
  7d850c:	test   %rsi,%rsi
  7d850f:	je     7d854d <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0xed>
  7d8511:	xor    %eax,%eax
  7d8513:	cmp    $0x1,%rsi
  7d8517:	je     7d8540 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0xe0>
  7d8519:	mov    %rsi,%r10
  7d851c:	nopl   0x0(%rax)
  7d8520:	mov    %r10,%r11
  7d8523:	shr    $1,%r11
  7d8526:	lea    (%r11,%rax,1),%rbx
  7d852a:	lea    (%rbx,%rbx,2),%r14
  7d852e:	cmp    %edx,0x4(%rcx,%r14,8)
  7d8533:	cmovb  %rbx,%rax
  7d8537:	sub    %r11,%r10
  7d853a:	cmp    $0x1,%r10
  7d853e:	ja     7d8520 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0xc0>
  7d8540:	lea    (%rax,%rax,2),%r10
  7d8544:	cmp    %edx,0x4(%rcx,%r10,8)
  7d8549:	adc    $0x0,%rax
  7d854d:	lea    -0x1(%rsi),%rdx
  7d8551:	cmp    %rax,%rdx
  7d8554:	cmovb  %rdx,%rax
  7d8558:	jmp    7d85a9 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x149>
  7d855a:	mov    %rsi,%rax
  7d855d:	test   %rsi,%rsi
  7d8560:	je     7d85a9 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x149>
  7d8562:	xor    %r10d,%r10d
  7d8565:	cmp    $0x1,%rsi
  7d8569:	je     7d8591 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x131>
  7d856b:	mov    %rsi,%rax
  7d856e:	xchg   %ax,%ax
  7d8570:	mov    %r10,%r11
  7d8573:	mov    %rax,%rbx
  7d8576:	shr    $1,%rbx
  7d8579:	add    %rbx,%r10
  7d857c:	lea    (%r10,%r10,2),%r14
  7d8580:	cmp    %edx,(%rcx,%r14,8)
  7d8584:	cmova  %r11,%r10
  7d8588:	sub    %rbx,%rax
  7d858b:	cmp    $0x1,%rax
  7d858f:	ja     7d8570 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x110>
  7d8591:	lea    (%r10,%r10,2),%r11
  7d8595:	xor    %eax,%eax
  7d8597:	cmp    %edx,(%rcx,%r11,8)
  7d859b:	setbe  %al
  7d859e:	add    %r10,%rax
  7d85a1:	cmp    $0x1,%rax
  7d85a5:	adc    $0xffffffffffffffff,%rax
  7d85a9:	cmp    %rsi,%rax
  7d85ac:	jae    7d85fd <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x19d>
  7d85ae:	lea    (%rax,%rax,2),%rax
  7d85b2:	movss  -0x8(%r8,%r9,1),%xmm0
  7d85b9:	movss  -0x7161f9(%rip),%xmm1        # c23c8 <GCC_except_table0+0x60>
  7d85c1:	addss  %xmm0,%xmm1
  7d85c5:	subss  %xmm0,%xmm1
  7d85c9:	movss  0x8(%rcx,%rax,8),%xmm2
  7d85cf:	movss  0xc(%rcx,%rax,8),%xmm3
  7d85d5:	movss  %xmm0,0x4(%rdi)
  7d85da:	movss  %xmm2,0x8(%rdi)
  7d85df:	movss  %xmm1,0xc(%rdi)
  7d85e4:	movss  %xmm3,0x10(%rdi)
  7d85e9:	mov    $0x1,%r11d
  7d85ef:	mov    %r11d,(%rdi)
  7d85f2:	mov    %rdi,%rax
  7d85f5:	add    $0x8,%rsp
  7d85f9:	pop    %rbx
  7d85fa:	pop    %r14
  7d85fc:	ret
  7d85fd:	lea    0x2c4884(%rip),%rdx        # a9ce88 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0x1480>
  7d8604:	mov    %rax,%rdi
  7d8607:	call   *0x2e08c3(%rip)        # ab8ed0 <_DYNAMIC+0x270>

<gpui_canvas::text::layout::TextGeometry>::validates_selection bytes=287 frame=8

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007d8610 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection>:
  7d8610:	push   %rbx
  7d8611:	mov    (%rsi),%r8d
  7d8614:	movzbl 0x4(%rsi),%r9d
  7d8619:	mov    0x38(%rdi),%rax
  7d861d:	mov    0x40(%rdi),%rcx
  7d8621:	mov    %rcx,%rdx
  7d8624:	test   %rcx,%rcx
  7d8627:	je     7d866b <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0x5b>
  7d8629:	xor    %edx,%edx
  7d862b:	cmp    $0x1,%rcx
  7d862f:	je     7d865f <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0x4f>
  7d8631:	mov    %rcx,%rdi
  7d8634:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  7d8640:	mov    %rdi,%r10
  7d8643:	shr    $1,%r10
  7d8646:	lea    (%r10,%rdx,1),%r11
  7d864a:	lea    (%r11,%r11,2),%rbx
  7d864e:	cmp    %r8d,(%rax,%rbx,4)
  7d8652:	cmovb  %r11,%rdx
  7d8656:	sub    %r10,%rdi
  7d8659:	cmp    $0x1,%rdi
  7d865d:	ja     7d8640 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0x30>
  7d865f:	lea    (%rdx,%rdx,2),%rdi
  7d8663:	cmp    %r8d,(%rax,%rdi,4)
  7d8667:	adc    $0x0,%rdx
  7d866b:	inc    %r9b
  7d866e:	shl    $0x2,%rdx
  7d8672:	lea    (%rdx,%rdx,2),%r11
  7d8676:	lea    (%rax,%r11,1),%rdi
  7d867a:	lea    0x0(,%rcx,4),%rdx
  7d8682:	lea    (%rdx,%rdx,2),%rdx
  7d8686:	mov    %rdx,%r10
  7d8689:	sub    %r11,%r10
  7d868c:	nopl   0x0(%rax)
  7d8690:	test   %r10,%r10
  7d8693:	je     7d872b <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0x11b>
  7d8699:	cmp    %r8d,(%rdi)
  7d869c:	jne    7d872b <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0x11b>
  7d86a2:	add    $0xfffffffffffffff4,%r10
  7d86a6:	test   %r9b,0x8(%rdi)
  7d86aa:	lea    0xc(%rdi),%rdi
  7d86ae:	je     7d8690 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0x80>
  7d86b0:	mov    0x8(%rsi),%edi
  7d86b3:	movzbl 0xc(%rsi),%esi
  7d86b7:	test   %rcx,%rcx
  7d86ba:	je     7d86fd <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0xed>
  7d86bc:	xor    %r8d,%r8d
  7d86bf:	cmp    $0x1,%rcx
  7d86c3:	je     7d86ef <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0xdf>
  7d86c5:	data16 cs nopw 0x0(%rax,%rax,1)
  7d86d0:	mov    %rcx,%r9
  7d86d3:	shr    $1,%r9
  7d86d6:	lea    (%r9,%r8,1),%r10
  7d86da:	lea    (%r10,%r10,2),%r11
  7d86de:	cmp    %edi,(%rax,%r11,4)
  7d86e2:	cmovb  %r10,%r8
  7d86e6:	sub    %r9,%rcx
  7d86e9:	cmp    $0x1,%rcx
  7d86ed:	ja     7d86d0 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0xc0>
  7d86ef:	lea    (%r8,%r8,2),%rcx
  7d86f3:	cmp    %edi,(%rax,%rcx,4)
  7d86f6:	adc    $0x0,%r8
  7d86fa:	mov    %r8,%rcx
  7d86fd:	inc    %sil
  7d8700:	shl    $0x2,%rcx
  7d8704:	lea    (%rcx,%rcx,2),%rcx
  7d8708:	add    %rcx,%rax
  7d870b:	sub    %rcx,%rdx
  7d870e:	xchg   %ax,%ax
  7d8710:	test   %rdx,%rdx
  7d8713:	je     7d872b <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0x11b>
  7d8715:	cmp    %edi,(%rax)
  7d8717:	jne    7d872b <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0x11b>
  7d8719:	add    $0xfffffffffffffff4,%rdx
  7d871d:	test   %sil,0x8(%rax)
  7d8721:	lea    0xc(%rax),%rax
  7d8725:	je     7d8710 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0x100>
  7d8727:	mov    $0x1,%al
  7d8729:	pop    %rbx
  7d872a:	ret
  7d872b:	xor    %eax,%eax
  7d872d:	pop    %rbx
  7d872e:	ret

<gpui_canvas::text::layout::TextGeometry>::source_line bytes=183 frame=0

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007dbf30 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry11source_line>:
  7dbf30:	not    %dl
  7dbf32:	test   %esi,%esi
  7dbf34:	setne  %r8b
  7dbf38:	mov    0x20(%rdi),%rcx
  7dbf3c:	mov    0x28(%rdi),%rax
  7dbf40:	test   %r8b,%dl
  7dbf43:	jne    7dbf99 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry11source_line+0x69>
  7dbf45:	test   %rax,%rax
  7dbf48:	je     7dbfe6 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry11source_line+0xb6>
  7dbf4e:	xor    %edx,%edx
  7dbf50:	cmp    $0x1,%rax
  7dbf54:	je     7dbf81 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry11source_line+0x51>
  7dbf56:	cs nopw 0x0(%rax,%rax,1)
  7dbf60:	mov    %rdx,%rdi
  7dbf63:	mov    %rax,%r8
  7dbf66:	shr    $1,%r8
  7dbf69:	add    %r8,%rdx
  7dbf6c:	lea    (%rdx,%rdx,2),%r9
  7dbf70:	cmp    %esi,(%rcx,%r9,8)
  7dbf74:	cmova  %rdi,%rdx
  7dbf78:	sub    %r8,%rax
  7dbf7b:	cmp    $0x1,%rax
  7dbf7f:	ja     7dbf60 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry11source_line+0x30>
  7dbf81:	lea    (%rdx,%rdx,2),%rdi
  7dbf85:	xor    %eax,%eax
  7dbf87:	cmp    %esi,(%rcx,%rdi,8)
  7dbf8a:	setbe  %al
  7dbf8d:	add    %rdx,%rax
  7dbf90:	cmp    $0x1,%rax
  7dbf94:	adc    $0xffffffffffffffff,%rax
  7dbf98:	ret
  7dbf99:	mov    %rax,%rdx
  7dbf9c:	test   %rax,%rax
  7dbf9f:	je     7dbfdc <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry11source_line+0xac>
  7dbfa1:	xor    %edx,%edx
  7dbfa3:	cmp    $0x1,%rax
  7dbfa7:	je     7dbfd0 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry11source_line+0xa0>
  7dbfa9:	mov    %rax,%rdi
  7dbfac:	nopl   0x0(%rax)
  7dbfb0:	mov    %rdi,%r8
  7dbfb3:	shr    $1,%r8
  7dbfb6:	lea    (%r8,%rdx,1),%r9
  7dbfba:	lea    (%r9,%r9,2),%r10
  7dbfbe:	cmp    %esi,0x4(%rcx,%r10,8)
  7dbfc3:	cmovb  %r9,%rdx
  7dbfc7:	sub    %r8,%rdi
  7dbfca:	cmp    $0x1,%rdi
  7dbfce:	ja     7dbfb0 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry11source_line+0x80>
  7dbfd0:	lea    (%rdx,%rdx,2),%rdi
  7dbfd4:	cmp    %esi,0x4(%rcx,%rdi,8)
  7dbfd8:	adc    $0x0,%rdx
  7dbfdc:	dec    %rax
  7dbfdf:	cmp    %rdx,%rax
  7dbfe2:	cmovae %rdx,%rax
  7dbfe6:	ret

<gpui_canvas::text::layout::TextGeometry>::stops bytes=190 frame=0

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007dbff0 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry5stops>:
  7dbff0:	mov    0x40(%rdi),%rcx
  7dbff4:	xor    %eax,%eax
  7dbff6:	test   %rcx,%rcx
  7dbff9:	je     7dc0aa <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry5stops+0xba>
  7dbfff:	mov    0x38(%rdi),%rdi
  7dc003:	cmp    $0x1,%rcx
  7dc007:	je     7dc02f <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry5stops+0x3f>
  7dc009:	xor    %eax,%eax
  7dc00b:	mov    %rcx,%r8
  7dc00e:	xchg   %ax,%ax
  7dc010:	mov    %r8,%r9
  7dc013:	shr    $1,%r9
  7dc016:	lea    (%r9,%rax,1),%r10
  7dc01a:	lea    (%r10,%r10,2),%r11
  7dc01e:	cmp    %esi,(%rdi,%r11,4)
  7dc022:	cmovb  %r10,%rax
  7dc026:	sub    %r9,%r8
  7dc029:	cmp    $0x1,%r8
  7dc02d:	ja     7dc010 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry5stops+0x20>
  7dc02f:	lea    (%rax,%rax,2),%r8
  7dc033:	cmp    %esi,(%rdi,%r8,4)
  7dc037:	adc    $0x0,%rax
  7dc03b:	xor    %r8d,%r8d
  7dc03e:	cmp    $0x1,%rcx
  7dc042:	je     7dc071 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry5stops+0x81>
  7dc044:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  7dc050:	mov    %r8,%r9
  7dc053:	mov    %rcx,%r10
  7dc056:	shr    $1,%r10
  7dc059:	add    %r10,%r8
  7dc05c:	lea    (%r8,%r8,2),%r11
  7dc060:	cmp    %edx,(%rdi,%r11,4)
  7dc064:	cmova  %r9,%r8
  7dc068:	sub    %r10,%rcx
  7dc06b:	cmp    $0x1,%rcx
  7dc06f:	ja     7dc050 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry5stops+0x60>
  7dc071:	lea    (%r8,%r8,2),%rcx
  7dc075:	cmp    (%rdi,%rcx,4),%edx
  7dc078:	sbb    $0xffffffffffffffff,%r8
  7dc07c:	cmp    %rax,%r8
  7dc07f:	jb     7dc0a8 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry5stops+0xb8>
  7dc081:	mov    %r8,%rcx
  7dc084:	sub    %rax,%rcx
  7dc087:	je     7dc0a8 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry5stops+0xb8>
  7dc089:	lea    (%rax,%rax,2),%rax
  7dc08d:	lea    (%rdi,%rax,4),%r9
  7dc091:	cmp    %esi,(%r9)
  7dc094:	jne    7dc0a8 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry5stops+0xb8>
  7dc096:	lea    (%r8,%r8,2),%rsi
  7dc09a:	xor    %eax,%eax
  7dc09c:	cmp    %edx,-0xc(%rdi,%rsi,4)
  7dc0a0:	cmove  %r9,%rax
  7dc0a4:	mov    %rcx,%rdx
  7dc0a7:	ret
  7dc0a8:	xor    %eax,%eax
  7dc0aa:	mov    %rcx,%rdx
  7dc0ad:	ret

<gpui_canvas::text::layout::TextGeometry>::intervals bytes=154 frame=16

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007dc0b0 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry9intervals>:
  7dc0b0:	mov    %rdi,%rax
  7dc0b3:	test   %rcx,%rcx
  7dc0b6:	je     7dc0c6 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry9intervals+0x16>
  7dc0b8:	mov    (%rdx),%r8d
  7dc0bb:	mov    0x28(%rsi),%rdi
  7dc0bf:	test   %rdi,%rdi
  7dc0c2:	jne    7dc0d2 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry9intervals+0x22>
  7dc0c4:	jmp    7dc12d <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry9intervals+0x7d>
  7dc0c6:	xor    %r8d,%r8d
  7dc0c9:	mov    0x28(%rsi),%rdi
  7dc0cd:	test   %rdi,%rdi
  7dc0d0:	je     7dc12d <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry9intervals+0x7d>
  7dc0d2:	push   %r14
  7dc0d4:	push   %rbx
  7dc0d5:	mov    0x20(%rsi),%r9
  7dc0d9:	xor    %r10d,%r10d
  7dc0dc:	cmp    $0x1,%rdi
  7dc0e0:	je     7dc111 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry9intervals+0x61>
  7dc0e2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  7dc0f0:	mov    %r10,%r11
  7dc0f3:	mov    %rdi,%rbx
  7dc0f6:	shr    $1,%rbx
  7dc0f9:	add    %rbx,%r10
  7dc0fc:	lea    (%r10,%r10,2),%r14
  7dc100:	cmp    %r8d,(%r9,%r14,8)
  7dc104:	cmova  %r11,%r10
  7dc108:	sub    %rbx,%rdi
  7dc10b:	cmp    $0x1,%rdi
  7dc10f:	ja     7dc0f0 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry9intervals+0x40>
  7dc111:	lea    (%r10,%r10,2),%r11
  7dc115:	xor    %edi,%edi
  7dc117:	cmp    %r8d,(%r9,%r11,8)
  7dc11b:	setbe  %dil
  7dc11f:	add    %r10,%rdi
  7dc122:	cmp    $0x1,%rdi
  7dc126:	adc    $0xffffffffffffffff,%rdi
  7dc12a:	pop    %rbx
  7dc12b:	pop    %r14
  7dc12d:	mov    %rdx,(%rax)
  7dc130:	mov    %rcx,0x8(%rax)
  7dc134:	movq   $0x2,0x10(%rax)
  7dc13c:	mov    %rsi,0x18(%rax)
  7dc140:	mov    %rdi,0x20(%rax)
  7dc144:	movss  %xmm0,0x28(%rax)
  7dc149:	ret

<alloc::sync::Arc<gpui_canvas::text::layout::TextGeometry>>::drop_slow bytes=135 frame=8

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007e16d0 <_RNvMsn_NtCscdodAO9FK5_5alloc4syncINtB5_3ArcNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryE9drop_slowBL_>:
  7e16d0:	push   %rbx
  7e16d1:	mov    (%rdi),%rbx
  7e16d4:	mov    0x10(%rbx),%rax
  7e16d8:	test   %rax,%rax
  7e16db:	je     7e16f4 <_RNvMsn_NtCscdodAO9FK5_5alloc4syncINtB5_3ArcNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryE9drop_slowBL_+0x24>
  7e16dd:	mov    0x18(%rbx),%rdi
  7e16e1:	shl    $0x3,%rax
  7e16e5:	lea    (%rax,%rax,2),%rsi
  7e16e9:	mov    $0x4,%edx
  7e16ee:	call   *0x2d77ac(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  7e16f4:	mov    0x28(%rbx),%rax
  7e16f8:	test   %rax,%rax
  7e16fb:	je     7e1714 <_RNvMsn_NtCscdodAO9FK5_5alloc4syncINtB5_3ArcNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryE9drop_slowBL_+0x44>
  7e16fd:	mov    0x30(%rbx),%rdi
  7e1701:	shl    $0x3,%rax
  7e1705:	lea    (%rax,%rax,2),%rsi
  7e1709:	mov    $0x4,%edx
  7e170e:	call   *0x2d778c(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  7e1714:	mov    0x40(%rbx),%rax
  7e1718:	test   %rax,%rax
  7e171b:	je     7e1734 <_RNvMsn_NtCscdodAO9FK5_5alloc4syncINtB5_3ArcNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryE9drop_slowBL_+0x64>
  7e171d:	mov    0x48(%rbx),%rdi
  7e1721:	shl    $0x2,%rax
  7e1725:	lea    (%rax,%rax,2),%rsi
  7e1729:	mov    $0x4,%edx
  7e172e:	call   *0x2d776c(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  7e1734:	cmp    $0xffffffffffffffff,%rbx
  7e1738:	je     7e1755 <_RNvMsn_NtCscdodAO9FK5_5alloc4syncINtB5_3ArcNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryE9drop_slowBL_+0x85>
  7e173a:	lock decq 0x8(%rbx)
  7e173f:	jne    7e1755 <_RNvMsn_NtCscdodAO9FK5_5alloc4syncINtB5_3ArcNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryE9drop_slowBL_+0x85>
  7e1741:	mov    $0x60,%esi
  7e1746:	mov    $0x8,%edx
  7e174b:	mov    %rbx,%rdi
  7e174e:	pop    %rbx
  7e174f:	jmp    *0x2d774b(%rip)        # ab8ea0 <_DYNAMIC+0x240>
  7e1755:	pop    %rbx
  7e1756:	ret
