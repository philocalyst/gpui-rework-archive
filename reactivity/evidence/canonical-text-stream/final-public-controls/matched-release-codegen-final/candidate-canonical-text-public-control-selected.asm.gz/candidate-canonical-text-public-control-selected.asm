
<core::option::Option<alloc::vec::Vec<gpui::runtime::geometry::Record>>>::or_else::<<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::present_inner::{closure#42}> bytes=105 frame=0

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000073d2e0 <_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime8geometry6RecordEE7or_elseNCNvMsu_B1i_INtB1i_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersE_0EB2E_>:
  73d2e0:	cmpq   $0xffffffffffffffff,(%rsi)
  73d2e4:	je     73d30f <_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime8geometry6RecordEE7or_elseNCNvMsu_B1i_INtB1i_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersE_0EB2E_+0x2f>
  73d2e6:	mov    0x10(%rsi),%rax
  73d2ea:	mov    %rax,0x10(%rdi)
  73d2ee:	movups (%rsi),%xmm0
  73d2f1:	movups %xmm0,(%rdi)
  73d2f4:	mov    (%rdx),%rsi
  73d2f7:	test   %rsi,%rsi
  73d2fa:	je     73d32a <_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime8geometry6RecordEE7or_elseNCNvMsu_B1i_INtB1i_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersE_0EB2E_+0x4a>
  73d2fc:	mov    0x8(%rdx),%rdi
  73d300:	shl    $0x4,%rsi
  73d304:	mov    $0x4,%edx
  73d309:	jmp    *0x37bc61(%rip)        # ab8f70 <_DYNAMIC+0x240>
  73d30f:	mov    (%rdx),%rsi
  73d312:	mov    0x8(%rdx),%rax
  73d316:	mov    0x10(%rdx),%rcx
  73d31a:	test   %rcx,%rcx
  73d31d:	je     73d32b <_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime8geometry6RecordEE7or_elseNCNvMsu_B1i_INtB1i_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersE_0EB2E_+0x4b>
  73d31f:	mov    %rsi,(%rdi)
  73d322:	mov    %rax,0x8(%rdi)
  73d326:	mov    %rcx,0x10(%rdi)
  73d32a:	ret
  73d32b:	movq   $0xffffffffffffffff,(%rdi)
  73d332:	test   %rsi,%rsi
  73d335:	je     73d32a <_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime8geometry6RecordEE7or_elseNCNvMsu_B1i_INtB1i_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersE_0EB2E_+0x4a>
  73d337:	shl    $0x4,%rsi
  73d33b:	mov    $0x4,%edx
  73d340:	mov    %rax,%rdi
  73d343:	jmp    *0x37bc27(%rip)        # ab8f70 <_DYNAMIC+0x240>

<gpui::runtime::RuntimeMut<canonical_text_public_control::Editor, ()>>::operation_with_editing::<<gpui::runtime::RuntimeMut<canonical_text_public_control::Editor, ()>>::replace_input::{closure#2}> bytes=974 frame=280

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000073d8b0 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_>:
  73d8b0:	push   %rbp
  73d8b1:	push   %r15
  73d8b3:	push   %r14
  73d8b5:	push   %r13
  73d8b7:	push   %r12
  73d8b9:	push   %rbx
  73d8ba:	sub    $0xe8,%rsp
  73d8c1:	mov    %rdi,%rbx
  73d8c4:	mov    (%rsi),%r14
  73d8c7:	mov    $0xe,%eax
  73d8cc:	cmpb   $0x0,0x76e(%r14)
  73d8d4:	je     73d905 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x55>
  73d8d6:	mov    %rax,(%rbx)
  73d8d9:	mov    (%rcx),%rsi
  73d8dc:	test   %rsi,%rsi
  73d8df:	je     73dbc5 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x315>
  73d8e5:	mov    0x8(%rcx),%rdi
  73d8e9:	mov    $0x1,%edx
  73d8ee:	add    $0xe8,%rsp
  73d8f5:	pop    %rbx
  73d8f6:	pop    %r12
  73d8f8:	pop    %r13
  73d8fa:	pop    %r14
  73d8fc:	pop    %r15
  73d8fe:	pop    %rbp
  73d8ff:	jmp    *0x37b66b(%rip)        # ab8f70 <_DYNAMIC+0x240>
  73d905:	mov    0x6a0(%r14),%r9
  73d90c:	inc    %r9
  73d90f:	je     73dbd7 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x327>
  73d915:	mov    (%rcx),%r11
  73d918:	mov    0x8(%rcx),%r10
  73d91c:	mov    0x10(%rcx),%r13
  73d920:	mov    0x18(%rcx),%r12
  73d924:	mov    0x20(%rcx),%r15
  73d928:	mov    0x228(%r14),%rax
  73d92f:	lea    0x230(%r14),%rcx
  73d936:	cmp    $0xffffffffffffffff,%rax
  73d93a:	lea    0x88(%rsp),%rdi
  73d942:	cmovne %rcx,%rdi
  73d946:	movups (%rdi),%xmm0
  73d949:	movaps %xmm0,0xd0(%rsp)
  73d951:	je     73d9b4 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x104>
  73d953:	movaps 0xd0(%rsp),%xmm0
  73d95b:	movups %xmm0,0x48(%rsp)
  73d960:	mov    %rax,0x40(%rsp)
  73d965:	mov    %r11,0x58(%rsp)
  73d96a:	mov    %r10,0x60(%rsp)
  73d96f:	mov    %r13,0x68(%rsp)
  73d974:	mov    %r12,0x70(%rsp)
  73d979:	mov    0x40(%rsp),%rax
  73d97e:	cmp    $0xfffffffffffffffe,%rax
  73d982:	jne    73db52 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x2a2>
  73d988:	mov    %r9,0x6a0(%r14)
  73d98f:	incq   0x700(%r14)
  73d996:	movq   $0x0,0x758(%r14)
  73d9a1:	mov    %rbx,%rdi
  73d9a4:	mov    %r8,%rcx
  73d9a7:	xor    %r8d,%r8d
  73d9aa:	call   766d20 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB4_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE20after_source_changedBW_>
  73d9af:	jmp    73dbc5 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x315>
  73d9b4:	mov    %r13,0x38(%rsp)
  73d9b9:	mov    %r15,0x78(%rsp)
  73d9be:	mov    %r11,0x8(%rsp)
  73d9c3:	mov    %r10,0x10(%rsp)
  73d9c8:	mov    %r9,0x18(%rsp)
  73d9cd:	mov    %rsi,0x20(%rsp)
  73d9d2:	mov    %rdx,0x28(%rsp)
  73d9d7:	mov    %r8,0x30(%rsp)
  73d9dc:	cmp    $0x1,%r12d
  73d9e0:	jne    73da70 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x1c0>
  73d9e6:	mov    0x248(%r14),%r15
  73d9ed:	mov    0x250(%r14),%r13
  73d9f4:	shl    $0x4,%r13
  73d9f8:	xor    %ebp,%ebp
  73d9fa:	nopw   0x0(%rax,%rax,1)
  73da00:	cmp    %rbp,%r13
  73da03:	je     73dafe <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x24e>
  73da09:	mov    (%r15,%rbp,1),%rdi
  73da0d:	mov    0x8(%r15,%rbp,1),%rax
  73da12:	call   *0x18(%rax)
  73da15:	add    $0x10,%rbp
  73da19:	cmp    %r12,%rax
  73da1c:	jne    73da00 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x150>
  73da1e:	mov    -0x10(%r15,%rbp,1),%rsi
  73da23:	mov    -0x8(%r15,%rbp,1),%rax
  73da28:	mov    0x8(%rsp),%rcx
  73da2d:	mov    %rcx,0x80(%rsp)
  73da35:	mov    0x10(%rsp),%rcx
  73da3a:	mov    %rcx,0x88(%rsp)
  73da42:	mov    0x38(%rsp),%rcx
  73da47:	mov    %rcx,0x90(%rsp)
  73da4f:	lea    0x40(%rsp),%rdi
  73da54:	lea    0x80(%rsp),%rcx
  73da5c:	lea    0x290(%r14),%rdx
  73da63:	mov    0x78(%rsp),%r8
  73da68:	call   *0x40(%rax)
  73da6b:	jmp    73db2f <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x27f>
  73da70:	mov    0x278(%r14),%r15
  73da77:	mov    0x280(%r14),%rbp
  73da7e:	shl    $0x4,%rbp
  73da82:	xor    %r13d,%r13d
  73da85:	data16 cs nopw 0x0(%rax,%rax,1)
  73da90:	cmp    %r13,%rbp
  73da93:	je     73dafe <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x24e>
  73da95:	mov    (%r15,%r13,1),%rdi
  73da99:	mov    0x8(%r15,%r13,1),%rax
  73da9e:	mov    %r12,%rsi
  73daa1:	call   *0x30(%rax)
  73daa4:	add    $0x10,%r13
  73daa8:	test   %al,%al
  73daaa:	je     73da90 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x1e0>
  73daac:	mov    -0x10(%r15,%r13,1),%rsi
  73dab1:	mov    -0x8(%r15,%r13,1),%rax
  73dab6:	mov    0x8(%rsp),%rcx
  73dabb:	mov    %rcx,0x80(%rsp)
  73dac3:	mov    0x10(%rsp),%rcx
  73dac8:	mov    %rcx,0x88(%rsp)
  73dad0:	mov    0x38(%rsp),%rcx
  73dad5:	mov    %rcx,0x90(%rsp)
  73dadd:	lea    0x40(%rsp),%rdi
  73dae2:	lea    0x80(%rsp),%r8
  73daea:	lea    0x290(%r14),%rdx
  73daf1:	mov    %r12,%rcx
  73daf4:	mov    0x78(%rsp),%r9
  73daf9:	call   *0x70(%rax)
  73dafc:	jmp    73db2f <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x27f>
  73dafe:	movq   $0xb,0x40(%rsp)
  73db07:	mov    %r12,0x48(%rsp)
  73db0c:	mov    0x8(%rsp),%rax
  73db11:	mov    %rax,0x58(%rsp)
  73db16:	mov    0x10(%rsp),%rax
  73db1b:	mov    %rax,0x60(%rsp)
  73db20:	mov    0x38(%rsp),%rax
  73db25:	mov    %rax,0x68(%rsp)
  73db2a:	mov    %r12,0x70(%rsp)
  73db2f:	mov    0x30(%rsp),%r8
  73db34:	mov    0x28(%rsp),%rdx
  73db39:	mov    0x20(%rsp),%rsi
  73db3e:	mov    0x18(%rsp),%r9
  73db43:	mov    0x40(%rsp),%rax
  73db48:	cmp    $0xfffffffffffffffe,%rax
  73db4c:	je     73d988 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0xd8>
  73db52:	mov    0x48(%rsp),%rcx
  73db57:	movups 0x50(%rsp),%xmm0
  73db5c:	movups 0x60(%rsp),%xmm1
  73db61:	mov    0x70(%rsp),%rdx
  73db66:	mov    %rcx,0xa0(%rsp)
  73db6e:	movups %xmm0,0xa8(%rsp)
  73db76:	movups %xmm1,0xb8(%rsp)
  73db7e:	mov    %rdx,0xc8(%rsp)
  73db86:	movups 0xb0(%rsp),%xmm0
  73db8e:	movups %xmm0,0x18(%rbx)
  73db92:	mov    0xc0(%rsp),%rcx
  73db9a:	mov    %rcx,0x28(%rbx)
  73db9e:	mov    0xc8(%rsp),%rcx
  73dba6:	mov    %rcx,0x30(%rbx)
  73dbaa:	mov    0xa0(%rsp),%rcx
  73dbb2:	mov    %rcx,0x8(%rbx)
  73dbb6:	mov    0xa8(%rsp),%rcx
  73dbbe:	mov    %rcx,0x10(%rbx)
  73dbc2:	mov    %rax,(%rbx)
  73dbc5:	add    $0xe8,%rsp
  73dbcc:	pop    %rbx
  73dbcd:	pop    %r12
  73dbcf:	pop    %r13
  73dbd1:	pop    %r14
  73dbd3:	pop    %r15
  73dbd5:	pop    %rbp
  73dbd6:	ret
  73dbd7:	mov    $0x1f,%eax
  73dbdc:	mov    %rax,(%rbx)
  73dbdf:	mov    (%rcx),%rsi
  73dbe2:	test   %rsi,%rsi
  73dbe5:	jne    73d8e5 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x35>
  73dbeb:	jmp    73dbc5 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x315>
  73dbed:	mov    %rax,%r12
  73dbf0:	jmp    73dc14 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x364>
  73dbf2:	jmp    73dbf4 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x344>
  73dbf4:	mov    %rax,%r12
  73dbf7:	cmpq   $0x0,0x8(%rsp)
  73dbfd:	je     73dc14 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x364>
  73dbff:	mov    $0x1,%edx
  73dc04:	mov    0x10(%rsp),%rdi
  73dc09:	mov    0x8(%rsp),%rsi
  73dc0e:	call   *0x37b35c(%rip)        # ab8f70 <_DYNAMIC+0x240>
  73dc14:	mov    %r12,%rdi
  73dc17:	call   *0x37b3ab(%rip)        # ab8fc8 <_DYNAMIC+0x298>
  73dc1d:	mov    %rax,0xa0(%rsp)
  73dc25:	mov    %rdx,0xa8(%rsp)
  73dc2d:	movq   $0xfffffffffffffffd,0x98(%rsp)
  73dc39:	mov    %r14,%rdi
  73dc3c:	call   78cc60 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE6poisonBO_>
  73dc41:	movq   $0xf,(%rbx)
  73dc48:	lea    0x98(%rsp),%rdi
  73dc50:	call   7460d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultIBC_NtNtNtCslbxve4rcJus_4gpui7runtime5paint12PatchOutcomeNtB15_5ErrorEINtNtCscdodAO9FK5_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECs9C2G9YFESsD_29canonical_text_public_control>
  73dc55:	jmp    73dbc5 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x315>
  73dc5a:	mov    %rax,%rbx
  73dc5d:	lea    0x98(%rsp),%rdi
  73dc65:	call   7460d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultIBC_NtNtNtCslbxve4rcJus_4gpui7runtime5paint12PatchOutcomeNtB15_5ErrorEINtNtCscdodAO9FK5_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECs9C2G9YFESsD_29canonical_text_public_control>
  73dc6a:	mov    %rbx,%rdi
  73dc6d:	call   a97420 <_Unwind_Resume@plt>
  73dc72:	call   *0x37b320(%rip)        # ab8f98 <_DYNAMIC+0x268>
  73dc78:	call   *0x37b352(%rip)        # ab8fd0 <_DYNAMIC+0x2a0>

<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::present_inner::{closure#30}> bytes=1513 frame=328

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000073f470 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_>:
  73f470:	push   %rbp
  73f471:	push   %r15
  73f473:	push   %r14
  73f475:	push   %r13
  73f477:	push   %r12
  73f479:	push   %rbx
  73f47a:	sub    $0x118,%rsp
  73f481:	test   %rdi,%rdi
  73f484:	je     73f925 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x4b5>
  73f48a:	mov    %rsi,%r12
  73f48d:	mov    %rdi,%r15
  73f490:	lea    0x10(%rdi),%r14
  73f494:	mov    (%rdx),%r13
  73f497:	mov    0x8(%rdx),%rax
  73f49b:	mov    %rax,0x78(%rsp)
  73f4a0:	mov    0x10(%rdx),%rbp
  73f4a4:	mov    0x18(%rdx),%rax
  73f4a8:	mov    %rax,0x68(%rsp)
  73f4ad:	mov    0x20(%rdx),%rbx
  73f4b1:	mov    0x28(%rdx),%rax
  73f4b5:	mov    %rax,0x70(%rsp)
  73f4ba:	mov    %r14,%rdi
  73f4bd:	call   *0x379b2d(%rip)        # ab8ff0 <_DYNAMIC+0x2c0>
  73f4c3:	test   %al,%al
  73f4c5:	je     73f925 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x4b5>
  73f4cb:	mov    (%r12),%esi
  73f4cf:	mov    0x8(%r12),%ecx
  73f4d4:	mov    $0x1,%al
  73f4d6:	cmp    %esi,%ecx
  73f4d8:	je     73f927 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x4b7>
  73f4de:	mov    %esi,%edx
  73f4e0:	cmova  %ecx,%edx
  73f4e3:	cmovb  %ecx,%esi
  73f4e6:	mov    %r14,%rdi
  73f4e9:	call   *0x379b09(%rip)        # ab8ff8 <_DYNAMIC+0x2c8>
  73f4ef:	test   %rax,%rax
  73f4f2:	je     73fa35 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x5c5>
  73f4f8:	mov    %rdx,%rcx
  73f4fb:	movss  0x5c(%r15),%xmm0
  73f501:	mulss  -0x67d071(%rip),%xmm0        # c2498 <GCC_except_table0+0xf8>
  73f509:	lea    0xc0(%rsp),%rdi
  73f511:	mov    %r14,%rsi
  73f514:	mov    %rax,%rdx
  73f517:	call   *0x379ae3(%rip)        # ab9000 <_DYNAMIC+0x2d0>
  73f51d:	mov    0xc8(%rsp),%r10
  73f525:	mov    0xd0(%rsp),%rcx
  73f52d:	cmp    %r10,%rcx
  73f530:	mov    $0x1,%al
  73f532:	ja     73f927 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x4b7>
  73f538:	lea    0xd8(%rsp),%rsi
  73f540:	xor    %r12d,%r12d
  73f543:	lea    0x80(%rsp),%r11
  73f54b:	lea    0x100(%rsp),%rdi
  73f553:	test   $0x1,%r12b
  73f557:	je     73f6e6 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x276>
  73f55d:	cmp    $0x1,%rcx
  73f561:	je     73fa42 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x5d2>
  73f567:	mov    0xc0(%rsp),%rdx
  73f56f:	mov    (%rdx),%r9d
  73f572:	add    $0xc,%rdx
  73f576:	jmp    73f590 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x120>
  73f578:	nopl   0x0(%rax,%rax,1)
  73f580:	dec    %r10
  73f583:	add    $0xc,%rdx
  73f587:	cmp    %r10,%rcx
  73f58a:	ja     73f939 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x4c9>
  73f590:	mov    %r9d,%r8d
  73f593:	mov    (%rdx),%r9d
  73f596:	cmp    %r9d,%r8d
  73f599:	je     73f580 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x110>
  73f59b:	testb  $0x2,-0x4(%rdx)
  73f59f:	je     73f580 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x110>
  73f5a1:	testb  $0x1,0x8(%rdx)
  73f5a5:	je     73f580 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x110>
  73f5a7:	movaps %xmm3,0x40(%rsp)
  73f5ac:	mov    %rdi,%r14
  73f5af:	mov    %rdx,0xc0(%rsp)
  73f5b7:	dec    %r10
  73f5ba:	mov    %r10,0xc8(%rsp)
  73f5c2:	add    $0xfffffffffffffff4,%rdx
  73f5c6:	mov    %r11,%rdi
  73f5c9:	mov    %rsi,%r15
  73f5cc:	call   75d2f0 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control>
  73f5d1:	xorps  %xmm0,%xmm0
  73f5d4:	movss  0x98(%rsp),%xmm6
  73f5dd:	ucomiss %xmm0,%xmm6
  73f5e0:	jne    73f5f6 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x186>
  73f5e2:	jp     73f5f6 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x186>
  73f5e4:	mov    $0x1,%al
  73f5e6:	mov    %r14,%rdi
  73f5e9:	mov    %r15,%rsi
  73f5ec:	movaps 0x40(%rsp),%xmm3
  73f5f1:	jmp    73f6c0 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x250>
  73f5f6:	movss  0x90(%rsp),%xmm5
  73f5ff:	movss  0x94(%rsp),%xmm7
  73f608:	movss  0x9c(%rsp),%xmm8
  73f612:	mov    0xa0(%rsp),%rdx
  73f61a:	cmp    %rdx,0x38(%rsp)
  73f61f:	mov    %r14,%rdi
  73f622:	movaps 0x40(%rsp),%xmm2
  73f627:	jne    73f90f <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x49f>
  73f62d:	movaps 0x20(%rsp),%xmm0
  73f632:	ucomiss %xmm7,%xmm0
  73f635:	mov    $0x1,%al
  73f637:	mov    %r15,%rsi
  73f63a:	movaps 0x10(%rsp),%xmm4
  73f63f:	jne    73f7dd <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x36d>
  73f645:	jp     73f7dd <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x36d>
  73f64b:	movss  0xc(%rsp),%xmm0
  73f651:	ucomiss %xmm8,%xmm0
  73f655:	jne    73f7dd <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x36d>
  73f65b:	jp     73f7dd <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x36d>
  73f661:	movaps %xmm5,%xmm1
  73f664:	addss  %xmm6,%xmm1
  73f668:	ucomiss %xmm4,%xmm1
  73f66b:	jb     73f7d8 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x368>
  73f671:	movaps %xmm2,%xmm0
  73f674:	addss  %xmm4,%xmm0
  73f678:	ucomiss %xmm5,%xmm0
  73f67b:	jb     73f7d8 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x368>
  73f681:	movaps %xmm0,%xmm2
  73f684:	maxss  %xmm1,%xmm2
  73f688:	movaps %xmm2,%xmm3
  73f68b:	cmpunordss %xmm2,%xmm3
  73f690:	movaps %xmm3,%xmm1
  73f693:	andnps %xmm2,%xmm1
  73f696:	andps  %xmm0,%xmm3
  73f699:	orps   %xmm1,%xmm3
  73f69c:	movaps %xmm4,%xmm0
  73f69f:	minss  %xmm5,%xmm0
  73f6a3:	movaps %xmm0,%xmm1
  73f6a6:	cmpunordss %xmm0,%xmm1
  73f6ab:	movaps %xmm1,%xmm2
  73f6ae:	andnps %xmm0,%xmm2
  73f6b1:	andps  %xmm4,%xmm1
  73f6b4:	orps   %xmm2,%xmm1
  73f6b7:	subss  %xmm1,%xmm3
  73f6bb:	movaps %xmm1,0x10(%rsp)
  73f6c0:	mov    0xc8(%rsp),%r10
  73f6c8:	mov    0xd0(%rsp),%rcx
  73f6d0:	cmp    %r10,%rcx
  73f6d3:	lea    0x80(%rsp),%r11
  73f6db:	jbe    73f55d <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0xed>
  73f6e1:	jmp    73f9fd <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x58d>
  73f6e6:	cmp    $0x1,%rcx
  73f6ea:	je     73fa42 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x5d2>
  73f6f0:	mov    0xc0(%rsp),%rdx
  73f6f8:	mov    (%rdx),%r9d
  73f6fb:	add    $0xc,%rdx
  73f6ff:	jmp    73f720 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x2b0>
  73f701:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  73f710:	dec    %r10
  73f713:	add    $0xc,%rdx
  73f717:	cmp    %r10,%rcx
  73f71a:	ja     73f939 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x4c9>
  73f720:	mov    %r9d,%r8d
  73f723:	mov    (%rdx),%r9d
  73f726:	cmp    %r9d,%r8d
  73f729:	je     73f710 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x2a0>
  73f72b:	testb  $0x2,-0x4(%rdx)
  73f72f:	je     73f710 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x2a0>
  73f731:	testb  $0x1,0x8(%rdx)
  73f735:	je     73f710 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x2a0>
  73f737:	movaps %xmm3,0x40(%rsp)
  73f73c:	mov    %rdi,%r14
  73f73f:	mov    %rdx,0xc0(%rsp)
  73f747:	dec    %r10
  73f74a:	mov    %r10,0xc8(%rsp)
  73f752:	add    $0xfffffffffffffff4,%rdx
  73f756:	mov    %r11,%rdi
  73f759:	mov    %rsi,%r15
  73f75c:	call   75d2f0 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control>
  73f761:	xorps  %xmm0,%xmm0
  73f764:	movss  0x98(%rsp),%xmm6
  73f76d:	ucomiss %xmm0,%xmm6
  73f770:	jne    73f7a7 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x337>
  73f772:	jp     73f7a7 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x337>
  73f774:	mov    0xc8(%rsp),%r10
  73f77c:	mov    0xd0(%rsp),%rcx
  73f784:	cmp    %r10,%rcx
  73f787:	mov    $0x1,%al
  73f789:	mov    %r14,%rdi
  73f78c:	mov    %r15,%rsi
  73f78f:	lea    0x80(%rsp),%r11
  73f797:	movaps 0x40(%rsp),%xmm3
  73f79c:	jbe    73f6e6 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x276>
  73f7a2:	jmp    73f927 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x4b7>
  73f7a7:	movss  0x90(%rsp),%xmm5
  73f7b0:	movss  0x94(%rsp),%xmm7
  73f7b9:	movss  0x9c(%rsp),%xmm8
  73f7c3:	mov    0xa0(%rsp),%rdx
  73f7cb:	mov    $0x1,%al
  73f7cd:	mov    %r14,%rdi
  73f7d0:	mov    %r15,%rsi
  73f7d3:	jmp    73f8cd <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x45d>
  73f7d8:	mov    0x38(%rsp),%rdx
  73f7dd:	cmpl   $0xffffffff,0x0(%r13)
  73f7e2:	jne    73f8cd <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x45d>
  73f7e8:	unpcklps 0x20(%rsp),%xmm4
  73f7ed:	mov    0x68(%rsp),%rax
  73f7f2:	movss  (%rax),%xmm0
  73f7f6:	movss  0x0(%rbp),%xmm1
  73f7fb:	unpcklps %xmm0,%xmm1
  73f7fe:	addps  %xmm4,%xmm1
  73f801:	movlps %xmm1,0xf0(%rsp)
  73f809:	movss  %xmm2,0xf8(%rsp)
  73f812:	movss  0xc(%rsp),%xmm0
  73f818:	movss  %xmm0,0xfc(%rsp)
  73f821:	mov    0x10(%rbx),%rax
  73f825:	mov    %rax,0x90(%rsp)
  73f82d:	movups (%rbx),%xmm0
  73f830:	movaps %xmm0,0x80(%rsp)
  73f838:	mov    0x70(%rsp),%rax
  73f83d:	movups (%rax),%xmm0
  73f840:	movaps %xmm0,0x50(%rsp)
  73f845:	mov    $0x46,%esi
  73f84a:	mov    %rdx,%r12
  73f84d:	mov    $0x82,%edx
  73f852:	mov    $0xf0,%ecx
  73f857:	mov    $0x60,%r8d
  73f85d:	movss  %xmm5,0x40(%rsp)
  73f863:	movss  %xmm6,0x10(%rsp)
  73f869:	movss  %xmm7,0x20(%rsp)
  73f86f:	movss  %xmm8,0xc(%rsp)
  73f876:	call   *0x37978c(%rip)        # ab9008 <_DYNAMIC+0x2d8>
  73f87c:	mov    0x78(%rsp),%rdi
  73f881:	lea    0xf0(%rsp),%rsi
  73f889:	lea    0x80(%rsp),%rdx
  73f891:	lea    0x50(%rsp),%rcx
  73f896:	mov    %r14,%r8
  73f899:	call   *0x379771(%rip)        # ab9010 <_DYNAMIC+0x2e0>
  73f89f:	movss  0xc(%rsp),%xmm8
  73f8a6:	movss  0x20(%rsp),%xmm7
  73f8ac:	movss  0x10(%rsp),%xmm6
  73f8b2:	movss  0x40(%rsp),%xmm5
  73f8b8:	mov    %r15,%rsi
  73f8bb:	mov    %r14,%rdi
  73f8be:	mov    %eax,%ecx
  73f8c0:	mov    $0x1,%al
  73f8c2:	mov    %ecx,0x0(%r13)
  73f8c6:	mov    %edx,0x4(%r13)
  73f8ca:	mov    %r12,%rdx
  73f8cd:	mov    0xc8(%rsp),%r10
  73f8d5:	mov    0xd0(%rsp),%rcx
  73f8dd:	mov    $0x1,%r12b
  73f8e0:	mov    %rdx,0x38(%rsp)
  73f8e5:	movss  %xmm8,0xc(%rsp)
  73f8ec:	movaps %xmm6,%xmm3
  73f8ef:	movaps %xmm7,0x20(%rsp)
  73f8f4:	movaps %xmm5,0x10(%rsp)
  73f8f9:	cmp    %r10,%rcx
  73f8fc:	lea    0x80(%rsp),%r11
  73f904:	jbe    73f553 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0xe3>
  73f90a:	jmp    73fa11 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x5a1>
  73f90f:	mov    $0x1,%al
  73f911:	mov    %r15,%rsi
  73f914:	movaps 0x10(%rsp),%xmm4
  73f919:	cmpl   $0xffffffff,0x0(%r13)
  73f91e:	jne    73f8cd <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x45d>
  73f920:	jmp    73f7e8 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x378>
  73f925:	xor    %eax,%eax
  73f927:	add    $0x118,%rsp
  73f92e:	pop    %rbx
  73f92f:	pop    %r12
  73f931:	pop    %r13
  73f933:	pop    %r14
  73f935:	pop    %r15
  73f937:	pop    %rbp
  73f938:	ret
  73f939:	test   $0x1,%r12b
  73f93d:	je     73f927 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x4b7>
  73f93f:	cmpl   $0xffffffff,0x0(%r13)
  73f944:	jne    73f927 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x4b7>
  73f946:	movaps 0x10(%rsp),%xmm0
  73f94b:	addss  0x0(%rbp),%xmm0
  73f950:	mov    0x68(%rsp),%rax
  73f955:	movaps 0x20(%rsp),%xmm1
  73f95a:	addss  (%rax),%xmm1
  73f95e:	movss  %xmm0,0x50(%rsp)
  73f964:	movss  %xmm1,0x54(%rsp)
  73f96a:	movss  %xmm3,0x58(%rsp)
  73f970:	movss  0xc(%rsp),%xmm0
  73f976:	movss  %xmm0,0x5c(%rsp)
  73f97c:	mov    0x10(%rbx),%rax
  73f980:	mov    %rax,0x90(%rsp)
  73f988:	movups (%rbx),%xmm0
  73f98b:	movaps %xmm0,0x80(%rsp)
  73f993:	mov    0x70(%rsp),%rax
  73f998:	movups (%rax),%xmm0
  73f99b:	movaps %xmm0,0x100(%rsp)
  73f9a3:	lea    0xc0(%rsp),%r14
  73f9ab:	mov    %r14,%rdi
  73f9ae:	mov    $0x46,%esi
  73f9b3:	mov    $0x82,%edx
  73f9b8:	mov    $0xf0,%ecx
  73f9bd:	mov    $0x60,%r8d
  73f9c3:	call   *0x37963f(%rip)        # ab9008 <_DYNAMIC+0x2d8>
  73f9c9:	lea    0x50(%rsp),%rsi
  73f9ce:	lea    0x80(%rsp),%rdx
  73f9d6:	lea    0x100(%rsp),%rcx
  73f9de:	mov    0x78(%rsp),%rdi
  73f9e3:	mov    %r14,%r8
  73f9e6:	call   *0x379624(%rip)        # ab9010 <_DYNAMIC+0x2e0>
  73f9ec:	mov    %eax,%ecx
  73f9ee:	mov    $0x1,%al
  73f9f0:	mov    %ecx,0x0(%r13)
  73f9f4:	mov    %edx,0x4(%r13)
  73f9f8:	jmp    73f927 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x4b7>
  73f9fd:	movaps 0x20(%rsp),%xmm7
  73fa02:	movss  0xc(%rsp),%xmm8
  73fa09:	movaps 0x10(%rsp),%xmm5
  73fa0e:	movaps %xmm3,%xmm6
  73fa11:	movaps %xmm6,%xmm3
  73fa14:	movaps %xmm5,0x10(%rsp)
  73fa19:	movss  %xmm8,0xc(%rsp)
  73fa20:	movaps %xmm7,0x20(%rsp)
  73fa25:	cmpl   $0xffffffff,0x0(%r13)
  73fa2a:	jne    73f927 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x4b7>
  73fa30:	jmp    73f946 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x4d6>
  73fa35:	lea    0x358dec(%rip),%rdi        # a98828 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x50>
  73fa3c:	call   *0x3795d6(%rip)        # ab9018 <_DYNAMIC+0x2e8>
  73fa42:	lea    0x35957f(%rip),%rdx        # a98fc8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x7f0>
  73fa49:	mov    $0x1,%edi
  73fa4e:	mov    $0x1,%esi
  73fa53:	call   *0x379547(%rip)        # ab8fa0 <_DYNAMIC+0x270>

<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::present_inner::{closure#44}> bytes=1391 frame=120

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000073fac0 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_>:
  73fac0:	push   %rbp
  73fac1:	push   %r15
  73fac3:	push   %r14
  73fac5:	push   %r13
  73fac7:	push   %r12
  73fac9:	push   %rbx
  73faca:	sub    $0x48,%rsp
  73face:	mov    %rdx,0x10(%rsp)
  73fad3:	mov    %rdi,0x18(%rsp)
  73fad8:	mov    0x10(%rsi),%rbx
  73fadc:	test   %rbx,%rbx
  73fadf:	mov    %rsi,0x8(%rsp)
  73fae4:	je     73fb29 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x69>
  73fae6:	mov    0x8(%rsi),%rbp
  73faea:	lea    -0x1(%rbx),%r15
  73faee:	mov    $0x28,%r13d
  73faf4:	xor    %r14d,%r14d
  73faf7:	nopw   0x0(%rax,%rax,1)
  73fb00:	mov    -0x28(%rbp,%r13,1),%rsi
  73fb05:	mov    0x10(%rsp),%rdi
  73fb0a:	call   75dee0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_>
  73fb0f:	test   $0x1,%al
  73fb11:	je     73fb2e <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x6e>
  73fb13:	mov    %edx,-0x4(%rbp,%r13,1)
  73fb18:	inc    %r14
  73fb1b:	add    $0x28,%r13
  73fb1f:	cmp    %r14,%rbx
  73fb22:	jne    73fb00 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x40>
  73fb24:	mov    %rbx,%r14
  73fb27:	jmp    73fb91 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0xd1>
  73fb29:	xor    %r14d,%r14d
  73fb2c:	jmp    73fb91 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0xd1>
  73fb2e:	lea    0x1(%r14),%rax
  73fb32:	cmp    %rbx,%rax
  73fb35:	jae    73fb91 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0xd1>
  73fb37:	sub    %r14,%r15
  73fb3a:	jmp    73fb49 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x89>
  73fb3c:	nopl   0x0(%rax)
  73fb40:	add    $0x28,%r13
  73fb44:	dec    %r15
  73fb47:	je     73fb91 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0xd1>
  73fb49:	mov    %rbp,%r12
  73fb4c:	add    %r13,%r12
  73fb4f:	mov    0x0(%rbp,%r13,1),%rsi
  73fb54:	mov    0x10(%rsp),%rdi
  73fb59:	call   75dee0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_>
  73fb5e:	cmp    $0x1,%rax
  73fb62:	jne    73fb40 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x80>
  73fb64:	mov    %edx,0x24(%rbp,%r13,1)
  73fb69:	lea    (%r14,%r14,4),%rax
  73fb6d:	mov    0x20(%r12),%rcx
  73fb72:	mov    %rcx,0x20(%rbp,%rax,8)
  73fb77:	movups (%r12),%xmm0
  73fb7c:	movups 0x10(%r12),%xmm1
  73fb82:	movups %xmm1,0x10(%rbp,%rax,8)
  73fb87:	movups %xmm0,0x0(%rbp,%rax,8)
  73fb8c:	inc    %r14
  73fb8f:	jmp    73fb40 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x80>
  73fb91:	mov    0x8(%rsp),%rax
  73fb96:	mov    0x28(%rax),%rbp
  73fb9a:	test   %rbp,%rbp
  73fb9d:	mov    %r14,0x20(%rsp)
  73fba2:	je     73fbe9 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x129>
  73fba4:	mov    0x20(%rax),%r13
  73fba8:	lea    -0x1(%rbp),%r15
  73fbac:	mov    $0x40,%ebx
  73fbb1:	xor    %r12d,%r12d
  73fbb4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  73fbc0:	mov    -0x10(%r13,%rbx,1),%rsi
  73fbc5:	mov    0x10(%rsp),%rdi
  73fbca:	call   75dee0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_>
  73fbcf:	test   $0x1,%al
  73fbd1:	je     73fbee <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x12e>
  73fbd3:	mov    %edx,-0x8(%r13,%rbx,1)
  73fbd8:	inc    %r12
  73fbdb:	add    $0x40,%rbx
  73fbdf:	cmp    %r12,%rbp
  73fbe2:	jne    73fbc0 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x100>
  73fbe4:	mov    %rbp,%r12
  73fbe7:	jmp    73fc61 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x1a1>
  73fbe9:	xor    %r12d,%r12d
  73fbec:	jmp    73fc61 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x1a1>
  73fbee:	lea    0x1(%r12),%rax
  73fbf3:	cmp    %rbp,%rax
  73fbf6:	jae    73fc61 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x1a1>
  73fbf8:	sub    %r12,%r15
  73fbfb:	jmp    73fc0c <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x14c>
  73fbfd:	nopl   (%rax)
  73fc00:	mov    %r14,%rbp
  73fc03:	add    $0x40,%rbx
  73fc07:	dec    %r15
  73fc0a:	je     73fc61 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x1a1>
  73fc0c:	mov    %rbp,%r14
  73fc0f:	lea    (%rbx,%r13,1),%rbp
  73fc13:	mov    0x30(%r13,%rbx,1),%rsi
  73fc18:	mov    0x10(%rsp),%rdi
  73fc1d:	call   75dee0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_>
  73fc22:	cmp    $0x1,%rax
  73fc26:	jne    73fc00 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x140>
  73fc28:	mov    %edx,0x38(%r13,%rbx,1)
  73fc2d:	mov    %r12,%rax
  73fc30:	shl    $0x6,%rax
  73fc34:	movups 0x0(%rbp),%xmm0
  73fc38:	movups 0x10(%rbp),%xmm1
  73fc3c:	movups 0x20(%rbp),%xmm2
  73fc40:	movups 0x30(%rbp),%xmm3
  73fc44:	movups %xmm3,0x30(%r13,%rax,1)
  73fc4a:	movups %xmm2,0x20(%r13,%rax,1)
  73fc50:	movups %xmm1,0x10(%r13,%rax,1)
  73fc56:	movups %xmm0,0x0(%r13,%rax,1)
  73fc5c:	inc    %r12
  73fc5f:	jmp    73fc00 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x140>
  73fc61:	mov    0x20(%rsp),%r14
  73fc66:	test   %r14,%r14
  73fc69:	je     73fcd0 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x210>
  73fc6b:	test   %r12,%r12
  73fc6e:	je     73fd2a <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x26a>
  73fc74:	mov    0x8(%rsp),%rcx
  73fc79:	mov    (%rcx),%rax
  73fc7c:	mov    0x8(%rcx),%rbx
  73fc80:	cmp    %r14,%rax
  73fc83:	jbe    73fd83 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x2c3>
  73fc89:	shl    $0x3,%rax
  73fc8d:	lea    (%rax,%rax,4),%r13
  73fc91:	lea    0x0(,%r14,8),%rax
  73fc99:	lea    (%rax,%rax,4),%rbp
  73fc9d:	mov    $0x8,%edx
  73fca2:	mov    %rbx,%rdi
  73fca5:	mov    %r13,%rsi
  73fca8:	mov    %rbp,%rcx
  73fcab:	call   *0x37936f(%rip)        # ab9020 <_DYNAMIC+0x2f0>
  73fcb1:	mov    %rax,%r15
  73fcb4:	test   %rax,%rax
  73fcb7:	jne    73fd86 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x2c6>
  73fcbd:	mov    $0x8,%edi
  73fcc2:	mov    %rbp,%rsi
  73fcc5:	call   *0x37935d(%rip)        # ab9028 <_DYNAMIC+0x2f8>
  73fccb:	jmp    73feee <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x42e>
  73fcd0:	test   %r12,%r12
  73fcd3:	je     73fe2b <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x36b>
  73fcd9:	mov    0x8(%rsp),%r14
  73fcde:	mov    0x18(%r14),%r15
  73fce2:	mov    0x20(%r14),%rbx
  73fce6:	cmp    %r12,%r15
  73fce9:	jbe    73fe44 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x384>
  73fcef:	shl    $0x6,%r15
  73fcf3:	mov    %r12,%r13
  73fcf6:	shl    $0x6,%r13
  73fcfa:	mov    $0x8,%edx
  73fcff:	mov    %rbx,%rdi
  73fd02:	mov    %r15,%rsi
  73fd05:	mov    %r13,%rcx
  73fd08:	call   *0x379312(%rip)        # ab9020 <_DYNAMIC+0x2f0>
  73fd0e:	test   %rax,%rax
  73fd11:	jne    73fe47 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x387>
  73fd17:	mov    $0x8,%edi
  73fd1c:	mov    %r13,%rsi
  73fd1f:	call   *0x379303(%rip)        # ab9028 <_DYNAMIC+0x2f8>
  73fd25:	jmp    73feee <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x42e>
  73fd2a:	mov    0x8(%rsp),%rcx
  73fd2f:	mov    (%rcx),%rax
  73fd32:	mov    0x8(%rcx),%r15
  73fd36:	cmp    %r14,%rax
  73fd39:	jbe    73feaa <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x3ea>
  73fd3f:	shl    $0x3,%rax
  73fd43:	lea    (%rax,%rax,4),%r12
  73fd47:	lea    0x0(,%r14,8),%rax
  73fd4f:	lea    (%rax,%rax,4),%r13
  73fd53:	mov    $0x8,%edx
  73fd58:	mov    %r15,%rdi
  73fd5b:	mov    %r12,%rsi
  73fd5e:	mov    %r13,%rcx
  73fd61:	call   *0x3792b9(%rip)        # ab9020 <_DYNAMIC+0x2f0>
  73fd67:	test   %rax,%rax
  73fd6a:	jne    73fead <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x3ed>
  73fd70:	mov    $0x8,%edi
  73fd75:	mov    %r13,%rsi
  73fd78:	call   *0x3792aa(%rip)        # ab9028 <_DYNAMIC+0x2f8>
  73fd7e:	jmp    73feee <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x42e>
  73fd83:	mov    %rbx,%r15
  73fd86:	mov    0x8(%rsp),%rax
  73fd8b:	mov    0x18(%rax),%rbp
  73fd8f:	mov    0x20(%rax),%rbx
  73fd93:	cmp    %r12,%rbp
  73fd96:	jbe    73fdcf <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x30f>
  73fd98:	shl    $0x6,%rbp
  73fd9c:	mov    %r12,%r13
  73fd9f:	shl    $0x6,%r13
  73fda3:	mov    $0x8,%edx
  73fda8:	mov    %rbx,%rdi
  73fdab:	mov    %rbp,%rsi
  73fdae:	mov    %r13,%rcx
  73fdb1:	call   *0x379269(%rip)        # ab9020 <_DYNAMIC+0x2f0>
  73fdb7:	test   %rax,%rax
  73fdba:	jne    73fdd2 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x312>
  73fdbc:	mov    $0x8,%edi
  73fdc1:	mov    %r13,%rsi
  73fdc4:	call   *0x37925e(%rip)        # ab9028 <_DYNAMIC+0x2f8>
  73fdca:	jmp    73feee <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x42e>
  73fdcf:	mov    %rbx,%rax
  73fdd2:	mov    %r15,0x28(%rsp)
  73fdd7:	mov    %r14,0x30(%rsp)
  73fddc:	mov    %rax,0x38(%rsp)
  73fde1:	mov    %r12,0x40(%rsp)
  73fde6:	call   *0x37918c(%rip)        # ab8f78 <_DYNAMIC+0x248>
  73fdec:	mov    $0x20,%edi
  73fdf1:	mov    $0x8,%esi
  73fdf6:	call   *0x379184(%rip)        # ab8f80 <_DYNAMIC+0x250>
  73fdfc:	test   %rax,%rax
  73fdff:	je     73fede <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x41e>
  73fe05:	movups 0x28(%rsp),%xmm0
  73fe0a:	movups 0x38(%rsp),%xmm1
  73fe0f:	movups %xmm1,0x10(%rax)
  73fe13:	movups %xmm0,(%rax)
  73fe16:	mov    0x18(%rsp),%rcx
  73fe1b:	mov    %rax,0x8(%rcx)
  73fe1f:	movq   $0x3,(%rcx)
  73fe26:	jmp    73fecf <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x40f>
  73fe2b:	xor    %eax,%eax
  73fe2d:	mov    0x8(%rsp),%r14
  73fe32:	mov    0x18(%rsp),%rcx
  73fe37:	mov    %rax,(%rcx)
  73fe3a:	mov    (%r14),%rax
  73fe3d:	test   %rax,%rax
  73fe40:	jne    73fe64 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x3a4>
  73fe42:	jmp    73fe7b <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x3bb>
  73fe44:	mov    %rbx,%rax
  73fe47:	mov    0x18(%rsp),%rcx
  73fe4c:	mov    %rax,0x8(%rcx)
  73fe50:	mov    %r12,0x10(%rcx)
  73fe54:	mov    $0x2,%eax
  73fe59:	mov    %rax,(%rcx)
  73fe5c:	mov    (%r14),%rax
  73fe5f:	test   %rax,%rax
  73fe62:	je     73fe7b <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x3bb>
  73fe64:	mov    0x8(%r14),%rdi
  73fe68:	shl    $0x3,%rax
  73fe6c:	lea    (%rax,%rax,4),%rsi
  73fe70:	mov    $0x8,%edx
  73fe75:	call   *0x3790f5(%rip)        # ab8f70 <_DYNAMIC+0x240>
  73fe7b:	test   %r12,%r12
  73fe7e:	jne    73fecf <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x40f>
  73fe80:	mov    0x18(%r14),%rsi
  73fe84:	test   %rsi,%rsi
  73fe87:	je     73fecf <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x40f>
  73fe89:	mov    0x20(%r14),%rdi
  73fe8d:	shl    $0x6,%rsi
  73fe91:	mov    $0x8,%edx
  73fe96:	add    $0x48,%rsp
  73fe9a:	pop    %rbx
  73fe9b:	pop    %r12
  73fe9d:	pop    %r13
  73fe9f:	pop    %r14
  73fea1:	pop    %r15
  73fea3:	pop    %rbp
  73fea4:	jmp    *0x3790c6(%rip)        # ab8f70 <_DYNAMIC+0x240>
  73feaa:	mov    %r15,%rax
  73fead:	mov    0x18(%rsp),%rcx
  73feb2:	mov    %rax,0x8(%rcx)
  73feb6:	mov    %r14,0x10(%rcx)
  73feba:	movq   $0x1,(%rcx)
  73fec1:	mov    0x8(%rsp),%r14
  73fec6:	mov    0x18(%r14),%rsi
  73feca:	test   %rsi,%rsi
  73fecd:	jne    73fe89 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x3c9>
  73fecf:	add    $0x48,%rsp
  73fed3:	pop    %rbx
  73fed4:	pop    %r12
  73fed6:	pop    %r13
  73fed8:	pop    %r14
  73feda:	pop    %r15
  73fedc:	pop    %rbp
  73fedd:	ret
  73fede:	mov    $0x8,%edi
  73fee3:	mov    $0x20,%esi
  73fee8:	call   *0x37909a(%rip)        # ab8f88 <_DYNAMIC+0x258>
  73feee:	ud2
  73fef0:	mov    %rax,%r14
  73fef3:	mov    $0x8,%edx
  73fef8:	mov    %r15,%rdi
  73fefb:	mov    %r12,%rsi
  73fefe:	jmp    73ff5e <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x49e>
  73ff00:	mov    %rax,0x10(%rsp)
  73ff05:	mov    $0x8,%edx
  73ff0a:	mov    %rbx,%rdi
  73ff0d:	mov    %r15,%rsi
  73ff10:	call   *0x37905a(%rip)        # ab8f70 <_DYNAMIC+0x240>
  73ff16:	xor    %ebx,%ebx
  73ff18:	jmp    73ffba <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x4fa>
  73ff1d:	mov    %rax,%r13
  73ff20:	mov    0x379049(%rip),%r12        # ab8f70 <_DYNAMIC+0x240>
  73ff27:	mov    $0x8,%edx
  73ff2c:	mov    %rbx,%rdi
  73ff2f:	mov    %rbp,%rsi
  73ff32:	call   *%r12
  73ff35:	shl    $0x3,%r14
  73ff39:	lea    (%r14,%r14,4),%rsi
  73ff3d:	mov    $0x8,%edx
  73ff42:	mov    %r15,%rdi
  73ff45:	call   *%r12
  73ff48:	mov    %r13,%rdi
  73ff4b:	call   a97420 <_Unwind_Resume@plt>
  73ff50:	mov    %rax,%r14
  73ff53:	mov    $0x8,%edx
  73ff58:	mov    %rbx,%rdi
  73ff5b:	mov    %r13,%rsi
  73ff5e:	call   *0x37900c(%rip)        # ab8f70 <_DYNAMIC+0x240>
  73ff64:	jmp    73ffec <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x52c>
  73ff69:	mov    %rax,0x10(%rsp)
  73ff6e:	shl    $0x6,%r12
  73ff72:	add    %r12,%r13
  73ff75:	shl    $0x6,%r14
  73ff79:	sub    %rbx,%r14
  73ff7c:	mov    %r13,%rdi
  73ff7f:	mov    %rbp,%rsi
  73ff82:	mov    %r14,%rdx
  73ff85:	jmp    73ffa9 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x4e9>
  73ff87:	mov    %rax,0x10(%rsp)
  73ff8c:	lea    (%r14,%r14,4),%rax
  73ff90:	lea    0x0(,%rax,8),%rdi
  73ff98:	add    %rbp,%rdi
  73ff9b:	shl    $0x3,%rbx
  73ff9f:	lea    (%rbx,%rbx,4),%rdx
  73ffa3:	sub    %r13,%rdx
  73ffa6:	mov    %r12,%rsi
  73ffa9:	call   *0x379031(%rip)        # ab8fe0 <memmove@GLIBC_2.2.5>
  73ffaf:	jmp    73ffb8 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x4f8>
  73ffb1:	jmp    73ffb3 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x4f3>
  73ffb3:	mov    %rax,0x10(%rsp)
  73ffb8:	mov    $0x1,%bl
  73ffba:	mov    0x8(%rsp),%rax
  73ffbf:	mov    (%rax),%rax
  73ffc2:	test   %rax,%rax
  73ffc5:	je     73ffe3 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x523>
  73ffc7:	mov    0x8(%rsp),%rcx
  73ffcc:	mov    0x8(%rcx),%rdi
  73ffd0:	shl    $0x3,%rax
  73ffd4:	lea    (%rax,%rax,4),%rsi
  73ffd8:	mov    $0x8,%edx
  73ffdd:	call   *0x378f8d(%rip)        # ab8f70 <_DYNAMIC+0x240>
  73ffe3:	test   %bl,%bl
  73ffe5:	mov    0x10(%rsp),%r14
  73ffea:	je     740027 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x567>
  73ffec:	mov    0x8(%rsp),%rax
  73fff1:	mov    0x18(%rax),%rsi
  73fff5:	test   %rsi,%rsi
  73fff8:	je     740027 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x567>
  73fffa:	mov    0x8(%rsp),%rax
  73ffff:	mov    0x20(%rax),%rdi
  740003:	shl    $0x6,%rsi
  740007:	mov    $0x8,%edx
  74000c:	call   *0x378f5e(%rip)        # ab8f70 <_DYNAMIC+0x240>
  740012:	mov    %r14,%rdi
  740015:	call   a97420 <_Unwind_Resume@plt>
  74001a:	mov    %rax,%r14
  74001d:	lea    0x28(%rsp),%rdi
  740022:	call   74e6d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime6scroll7ColumnsECs9C2G9YFESsD_29canonical_text_public_control>
  740027:	mov    %r14,%rdi
  74002a:	call   a97420 <_Unwind_Resume@plt>

core::panicking::assert_failed::<gpui_canvas::text::layout::TextPosition, gpui_canvas::text::layout::TextPosition> bytes=50 frame=40

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000074f303 <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextPositionBM_ECs9C2G9YFESsD_29canonical_text_public_control>:
  74f303:	sub    $0x28,%rsp
  74f307:	lea    0x18(%rsp),%rax
  74f30c:	mov    %rdi,(%rax)
  74f30f:	lea    0x20(%rsp),%rcx
  74f314:	mov    %rsi,(%rcx)
  74f317:	mov    %rdx,0x8(%rsp)
  74f31c:	lea    0x349795(%rip),%rdx        # a98ab8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2e0>
  74f323:	push   $0x1
  74f325:	pop    %rdi
  74f326:	mov    %rax,%rsi
  74f329:	mov    %rdx,%r8
  74f32c:	xor    %r9d,%r9d
  74f32f:	call   *0x369dc3(%rip)        # ab90f8 <_DYNAMIC+0x3c8>

core::panicking::assert_failed::<gpui_canvas::text::layout::TextSelection, gpui_canvas::text::layout::TextSelection> bytes=56 frame=40

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000074f335 <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout13TextSelectionBM_ECs9C2G9YFESsD_29canonical_text_public_control>:
  74f335:	sub    $0x28,%rsp
  74f339:	lea    0x18(%rsp),%rax
  74f33e:	mov    %rdi,(%rax)
  74f341:	lea    0x20(%rsp),%rcx
  74f346:	mov    %rsi,(%rcx)
  74f349:	lea    0x34a238(%rip),%rdx        # a99588 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xdb0>
  74f350:	mov    %rdx,0x8(%rsp)
  74f355:	lea    0x34977c(%rip),%rdx        # a98ad8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x300>
  74f35c:	xor    %edi,%edi
  74f35e:	mov    %rax,%rsi
  74f361:	mov    %rdx,%r8
  74f364:	xor    %r9d,%r9d
  74f367:	call   *0x369d8b(%rip)        # ab90f8 <_DYNAMIC+0x3c8>

core::panicking::assert_failed::<(alloc::string::String, gpui_canvas::text::layout::TextSelection, *const gpui_canvas::text::layout::TextGeometry, u64), (alloc::string::String, gpui_canvas::text::layout::TextSelection, *const gpui_canvas::text::layout::TextGeometry, u64)> bytes=56 frame=40

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000074f3e6 <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedTNtNtCscdodAO9FK5_5alloc6string6StringNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout13TextSelectionPNtB1q_12TextGeometryyEBM_ECs9C2G9YFESsD_29canonical_text_public_control>:
  74f3e6:	sub    $0x28,%rsp
  74f3ea:	lea    0x18(%rsp),%rax
  74f3ef:	mov    %rdi,(%rax)
  74f3f2:	lea    0x20(%rsp),%rcx
  74f3f7:	mov    %rsi,(%rcx)
  74f3fa:	lea    0x34a13f(%rip),%rdx        # a99540 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xd68>
  74f401:	mov    %rdx,0x8(%rsp)
  74f406:	lea    0x34972b(%rip),%rdx        # a98b38 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x360>
  74f40d:	xor    %edi,%edi
  74f40f:	mov    %rax,%rsi
  74f412:	mov    %rdx,%r8
  74f415:	xor    %r9d,%r9d
  74f418:	call   *0x369cda(%rip)        # ab90f8 <_DYNAMIC+0x3c8>

core::panicking::assert_failed::<(*const gpui_canvas::text::layout::TextGeometry, u64), (*const gpui_canvas::text::layout::TextGeometry, u64)> bytes=56 frame=40

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000074f41e <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedTPNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryyEBM_ECs9C2G9YFESsD_29canonical_text_public_control>:
  74f41e:	sub    $0x28,%rsp
  74f422:	lea    0x18(%rsp),%rax
  74f427:	mov    %rdi,(%rax)
  74f42a:	lea    0x20(%rsp),%rcx
  74f42f:	mov    %rsi,(%rcx)
  74f432:	lea    0x34a167(%rip),%rdx        # a995a0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xdc8>
  74f439:	mov    %rdx,0x8(%rsp)
  74f43e:	lea    0x349713(%rip),%rdx        # a98b58 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x380>
  74f445:	xor    %edi,%edi
  74f447:	mov    %rax,%rsi
  74f44a:	mov    %rdx,%r8
  74f44d:	xor    %r9d,%r9d
  74f450:	call   *0x369ca2(%rip)        # ab90f8 <_DYNAMIC+0x3c8>

canonical_text_public_control::old_p_oracle::{closure#0} bytes=800 frame=296

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075c8f0 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_>:
  75c8f0:	push   %rbp
  75c8f1:	push   %r15
  75c8f3:	push   %r14
  75c8f5:	push   %r13
  75c8f7:	push   %r12
  75c8f9:	push   %rbx
  75c8fa:	sub    $0xf8,%rsp
  75c901:	test   %rsi,%rsi
  75c904:	je     75cb68 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x278>
  75c90a:	cmpb   $0x0,0x76e(%rsi)
  75c911:	jne    75cb6f <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x27f>
  75c917:	cmpb   $0x1,0x76c(%rsi)
  75c91e:	jne    75cb76 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x286>
  75c924:	mov    %rdi,%r14
  75c927:	mov    $0xffffffffffffffff,%rbx
  75c92e:	lea    0x78(%rsp),%rdi
  75c933:	call   73dc80 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime5queryNtB3_7Context3newNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEBX_>
  75c938:	mov    %r14,0x38(%rsp)
  75c93d:	mov    0xb0(%rsp),%rax
  75c945:	mov    %rax,0x48(%rsp)
  75c94a:	test   %rax,%rax
  75c94d:	je     75cb5b <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x26b>
  75c953:	movq   $0xffffffffffffffff,0x8(%rsp)
  75c95c:	mov    $0x3d,%ebx
  75c961:	xor    %ebp,%ebp
  75c963:	jmp    75c988 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x98>
  75c965:	data16 cs nopw 0x0(%rax,%rax,1)
  75c970:	mov    %r14,%r13
  75c973:	inc    %rbp
  75c976:	add    $0x40,%rbx
  75c97a:	mov    %r13,%r14
  75c97d:	cmp    %rbp,0x48(%rsp)
  75c982:	je     75caa6 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x1b6>
  75c988:	mov    0xb0(%rsp),%rsi
  75c990:	cmp    %rsi,%rbp
  75c993:	jae    75cb1b <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x22b>
  75c999:	mov    0xa8(%rsp),%rax
  75c9a1:	cmpb   $0x4,(%rax,%rbx,1)
  75c9a5:	jne    75c970 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x80>
  75c9a7:	mov    -0x15(%rax,%rbx,1),%r15
  75c9ac:	test   %r15,%r15
  75c9af:	je     75cb32 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x242>
  75c9b5:	mov    (%r15),%r12
  75c9b8:	shr    $1,%r12
  75c9bb:	je     75c9f2 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x102>
  75c9bd:	call   *0x35c5b5(%rip)        # ab8f78 <_DYNAMIC+0x248>
  75c9c3:	mov    $0x1,%esi
  75c9c8:	mov    %r12,%rdi
  75c9cb:	call   *0x35c5af(%rip)        # ab8f80 <_DYNAMIC+0x250>
  75c9d1:	test   %rax,%rax
  75c9d4:	je     75cb46 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x256>
  75c9da:	mov    %rax,%r13
  75c9dd:	add    $0x10,%r15
  75c9e1:	mov    %rax,%rdi
  75c9e4:	mov    %r15,%rsi
  75c9e7:	mov    %r12,%rdx
  75c9ea:	call   *0x35c5a0(%rip)        # ab8f90 <memcpy@GLIBC_2.14>
  75c9f0:	jmp    75c9f8 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x108>
  75c9f2:	mov    $0x1,%r13d
  75c9f8:	lea    0x18(%rsp),%rdi
  75c9fd:	lea    0x78(%rsp),%rsi
  75ca02:	mov    %rbp,%rdx
  75ca05:	call   *0x35c765(%rip)        # ab9170 <_DYNAMIC+0x440>
  75ca0b:	cmpb   $0x2,0x24(%rsp)
  75ca10:	je     75caf2 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x202>
  75ca16:	movups 0x18(%rsp),%xmm0
  75ca1b:	movaps %xmm0,0x60(%rsp)
  75ca20:	lea    0x18(%rsp),%rdi
  75ca25:	lea    0x78(%rsp),%rsi
  75ca2a:	mov    %rbp,%rdx
  75ca2d:	call   *0x35c745(%rip)        # ab9178 <_DYNAMIC+0x448>
  75ca33:	cmpq   $0x0,0x18(%rsp)
  75ca39:	je     75cafb <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x20b>
  75ca3f:	mov    0x28(%rsp),%rax
  75ca44:	mov    %rax,0x40(%rsp)
  75ca49:	lea    0x18(%rsp),%rdi
  75ca4e:	lea    0x78(%rsp),%rsi
  75ca53:	mov    %rbp,%rdx
  75ca56:	call   *0x35c71c(%rip)        # ab9178 <_DYNAMIC+0x448>
  75ca5c:	cmpq   $0x0,0x18(%rsp)
  75ca62:	je     75cb04 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x214>
  75ca68:	mov    0x28(%rsp),%rdi
  75ca6d:	call   75ffa0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript>
  75ca72:	mov    %rax,%r15
  75ca75:	movaps 0x60(%rsp),%xmm0
  75ca7a:	movaps %xmm0,0x50(%rsp)
  75ca7f:	mov    0x8(%rsp),%rsi
  75ca84:	test   %rsi,%rsi
  75ca87:	jle    75ca97 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x1a7>
  75ca89:	mov    $0x1,%edx
  75ca8e:	mov    %r14,%rdi
  75ca91:	call   *0x35c4d9(%rip)        # ab8f70 <_DYNAMIC+0x240>
  75ca97:	mov    %r13,0x10(%rsp)
  75ca9c:	mov    %r12,0x8(%rsp)
  75caa1:	jmp    75c973 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x83>
  75caa6:	mov    0x8(%rsp),%rax
  75caab:	cmp    $0xffffffffffffffff,%rax
  75caaf:	je     75cb5b <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x26b>
  75cab5:	mov    0x38(%rsp),%rcx
  75caba:	mov    %rax,(%rcx)
  75cabd:	mov    0x10(%rsp),%rax
  75cac2:	mov    %rax,0x8(%rcx)
  75cac6:	mov    %r12,0x10(%rcx)
  75caca:	movaps 0x50(%rsp),%xmm0
  75cacf:	movups %xmm0,0x18(%rcx)
  75cad3:	mov    0x40(%rsp),%rax
  75cad8:	mov    %rax,0x28(%rcx)
  75cadc:	mov    %r15,0x30(%rcx)
  75cae0:	add    $0xf8,%rsp
  75cae7:	pop    %rbx
  75cae8:	pop    %r12
  75caea:	pop    %r13
  75caec:	pop    %r14
  75caee:	pop    %r15
  75caf0:	pop    %rbp
  75caf1:	ret
  75caf2:	lea    0x33c247(%rip),%rdi        # a98d40 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x568>
  75caf9:	jmp    75cb0b <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x21b>
  75cafb:	lea    0x33c256(%rip),%rdi        # a98d58 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x580>
  75cb02:	jmp    75cb0b <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x21b>
  75cb04:	lea    0x33c265(%rip),%rdi        # a98d70 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x598>
  75cb0b:	mov    0x8(%rsp),%rbx
  75cb10:	call   *0x35c502(%rip)        # ab9018 <_DYNAMIC+0x2e8>
  75cb16:	jmp    75cbb1 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x2c1>
  75cb1b:	lea    0x33c1ee(%rip),%rdx        # a98d10 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x538>
  75cb22:	mov    %rbp,%rdi
  75cb25:	mov    0x8(%rsp),%rbx
  75cb2a:	call   *0x35c470(%rip)        # ab8fa0 <_DYNAMIC+0x270>
  75cb30:	jmp    75cbb1 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x2c1>
  75cb32:	lea    0x33c1ef(%rip),%rdi        # a98d28 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x550>
  75cb39:	mov    0x8(%rsp),%rbx
  75cb3e:	call   *0x35c4d4(%rip)        # ab9018 <_DYNAMIC+0x2e8>
  75cb44:	jmp    75cbb1 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x2c1>
  75cb46:	mov    $0x1,%edi
  75cb4b:	mov    %r12,%rsi
  75cb4e:	mov    0x8(%rsp),%rbx
  75cb53:	call   *0x35c4cf(%rip)        # ab9028 <_DYNAMIC+0x2f8>
  75cb59:	jmp    75cbb1 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x2c1>
  75cb5b:	lea    0x33c26e(%rip),%rdi        # a98dd0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x5f8>
  75cb62:	call   *0x35c4b0(%rip)        # ab9018 <_DYNAMIC+0x2e8>
  75cb68:	mov    $0xd,%eax
  75cb6d:	jmp    75cb7b <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x28b>
  75cb6f:	mov    $0xe,%eax
  75cb74:	jmp    75cb7b <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x28b>
  75cb76:	mov    $0x12,%eax
  75cb7b:	mov    %rax,0x78(%rsp)
  75cb80:	movq   $0x0,0x80(%rsp)
  75cb8c:	lea    -0x68cf69(%rip),%rdi        # cfc2a <GCC_except_table0+0xd88a>
  75cb93:	lea    0x33cece(%rip),%rcx        # a99a68 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1290>
  75cb9a:	lea    0x33c217(%rip),%r8        # a98db8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x5e0>
  75cba1:	lea    0x78(%rsp),%rdx
  75cba6:	mov    $0x2b,%esi
  75cbab:	call   *0x35c48f(%rip)        # ab9040 <_DYNAMIC+0x310>
  75cbb1:	ud2
  75cbb3:	mov    %rax,%r14
  75cbb6:	lea    0x78(%rsp),%rdi
  75cbbb:	call   74d580 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  75cbc0:	mov    %r14,%rdi
  75cbc3:	call   a97420 <_Unwind_Resume@plt>
  75cbc8:	mov    %rax,%r14
  75cbcb:	jmp    75cbf0 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x300>
  75cbcd:	mov    %rax,%r14
  75cbd0:	mov    0x8(%rsp),%rbx
  75cbd5:	jmp    75cbda <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x2ea>
  75cbd7:	mov    %rax,%r14
  75cbda:	test   %r12,%r12
  75cbdd:	je     75cbf0 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x300>
  75cbdf:	mov    $0x1,%edx
  75cbe4:	mov    %r13,%rdi
  75cbe7:	mov    %r12,%rsi
  75cbea:	call   *0x35c380(%rip)        # ab8f70 <_DYNAMIC+0x240>
  75cbf0:	mov    0x10(%rsp),%rdi
  75cbf5:	test   %rbx,%rbx
  75cbf8:	jle    75cc08 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x318>
  75cbfa:	mov    $0x1,%edx
  75cbff:	mov    %rbx,%rsi
  75cc02:	call   *0x35c368(%rip)        # ab8f70 <_DYNAMIC+0x240>
  75cc08:	mov    %r14,%rdi
  75cc0b:	call   a97420 <_Unwind_Resume@plt>

<gpui_canvas::text::layout::TextGeometry>::intervals::{closure#3} bytes=649 frame=56

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075d2f0 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control>:
  75d2f0:	push   %rbp
  75d2f1:	push   %r15
  75d2f3:	push   %r14
  75d2f5:	push   %r13
  75d2f7:	push   %r12
  75d2f9:	push   %rbx
  75d2fa:	push   %rax
  75d2fb:	cmp    $0x2,%rcx
  75d2ff:	jb     75d53c <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x24c>
  75d305:	mov    (%rsi),%r14
  75d308:	mov    0x8(%rsi),%rbx
  75d30c:	mov    0x20(%r14),%rax
  75d310:	mov    0x28(%r14),%rcx
  75d314:	lea    0x1(%rbx),%r9
  75d318:	cmp    %rcx,%r9
  75d31b:	jae    75d35d <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x6d>
  75d31d:	mov    (%rdx),%r8d
  75d320:	lea    (%r9,%r9,2),%r10
  75d324:	cmp    %r8d,(%rax,%r10,8)
  75d328:	ja     75d35d <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x6d>
  75d32a:	lea    (%rbx,%rbx,2),%r10
  75d32e:	lea    (%rax,%r10,8),%r11
  75d332:	add    $0x30,%r11
  75d336:	mov    $0x2,%r10d
  75d33c:	sub    %rcx,%r10
  75d33f:	nop
  75d340:	mov    %r9,%rbx
  75d343:	add    %r10,%r9
  75d346:	cmp    $0x1,%r9
  75d34a:	je     75d359 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x69>
  75d34c:	lea    0x1(%rbx),%r9
  75d350:	cmp    %r8d,(%r11)
  75d353:	lea    0x18(%r11),%r11
  75d357:	jbe    75d340 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x50>
  75d359:	mov    %rbx,0x8(%rsi)
  75d35d:	cmp    %rcx,%rbx
  75d360:	jae    75d553 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x263>
  75d366:	mov    0xc(%rdx),%ebp
  75d369:	lea    (%rbx,%rbx,2),%r9
  75d36d:	mov    0x4(%rax,%r9,8),%r15d
  75d372:	testb  $0x1,0x8(%rdx)
  75d376:	jne    75d3ac <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0xbc>
  75d378:	mov    %rbx,%rax
  75d37b:	cmp    %rcx,%rax
  75d37e:	jae    75d566 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x276>
  75d384:	mov    0x20(%r14),%rcx
  75d388:	movss  0x4(%rdx),%xmm0
  75d38d:	movss  0x10(%rdx),%xmm1
  75d392:	cmp    %r15d,%ebp
  75d395:	ja     75d3ee <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0xfe>
  75d397:	ucomiss %xmm1,%xmm0
  75d39a:	jne    75d39e <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0xae>
  75d39c:	jnp    75d3ee <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0xfe>
  75d39e:	ucomiss %xmm0,%xmm1
  75d3a1:	setbe  %r8b
  75d3a5:	mov    (%rdx),%edx
  75d3a7:	jmp    75d49b <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x1ab>
  75d3ac:	test   %rbx,%rbx
  75d3af:	je     75d378 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x88>
  75d3b1:	mov    (%rdx),%r8d
  75d3b4:	test   %r8d,%r8d
  75d3b7:	je     75d378 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x88>
  75d3b9:	lea    (%rax,%r9,8),%r9
  75d3bd:	mov    %rbx,%rax
  75d3c0:	cmp    %r8d,-0x14(%r9)
  75d3c4:	jne    75d37b <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x8b>
  75d3c6:	mov    %rdi,(%rsp)
  75d3ca:	mov    %r14,%rdi
  75d3cd:	mov    %rsi,%r13
  75d3d0:	mov    %r8d,%esi
  75d3d3:	mov    %rdx,%r12
  75d3d6:	xor    %edx,%edx
  75d3d8:	call   *0x35bdc2(%rip)        # ab91a0 <_DYNAMIC+0x470>
  75d3de:	mov    %r12,%rdx
  75d3e1:	mov    %r13,%rsi
  75d3e4:	mov    (%rsp),%rdi
  75d3e8:	mov    0x28(%r14),%rcx
  75d3ec:	jmp    75d37b <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x8b>
  75d3ee:	mov    0x8(%r14),%r8
  75d3f2:	mov    0x10(%r14),%r9
  75d3f6:	mov    %r9,%r10
  75d3f9:	test   %r9,%r9
  75d3fc:	je     75d443 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x153>
  75d3fe:	xor    %r10d,%r10d
  75d401:	cmp    $0x1,%r9
  75d405:	je     75d433 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x143>
  75d407:	mov    %r9,%r11
  75d40a:	nopw   0x0(%rax,%rax,1)
  75d410:	mov    %r11,%r14
  75d413:	shr    $1,%r14
  75d416:	lea    (%r14,%r10,1),%r12
  75d41a:	lea    (%r12,%r12,2),%r13
  75d41e:	mov    0x10(%r8,%r13,8),%r13d
  75d423:	cmp    %r13,%rbx
  75d426:	cmova  %r12,%r10
  75d42a:	sub    %r14,%r11
  75d42d:	cmp    $0x1,%r11
  75d431:	ja     75d410 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x120>
  75d433:	lea    (%r10,%r10,2),%r11
  75d437:	mov    0x10(%r8,%r11,8),%r11d
  75d43c:	cmp    %rbx,%r11
  75d43f:	adc    $0x0,%r10
  75d443:	shl    $0x3,%r10
  75d447:	lea    (%r10,%r10,2),%r10
  75d44b:	lea    (%r8,%r10,1),%r11
  75d44f:	mov    (%rdx),%edx
  75d451:	shl    $0x3,%r9
  75d455:	lea    (%r9,%r9,2),%r9
  75d459:	nopl   0x0(%rax)
  75d460:	cmp    %r10,%r9
  75d463:	je     75d51d <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x22d>
  75d469:	mov    %r11,%r14
  75d46c:	mov    0x10(%r11),%r11d
  75d470:	cmp    %r11,%rbx
  75d473:	jne    75d51d <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x22d>
  75d479:	lea    0x18(%r14),%r11
  75d47d:	add    $0x18,%r10
  75d481:	cmp    %edx,(%r14)
  75d484:	ja     75d460 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x170>
  75d486:	cmp    0x4(%r14),%edx
  75d48a:	ja     75d460 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x170>
  75d48c:	movzbl -0x3(%r8,%r10,1),%r8d
  75d492:	cmp    %r15d,%ebp
  75d495:	ja     75d529 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x239>
  75d49b:	movaps %xmm0,%xmm3
  75d49e:	minss  %xmm1,%xmm3
  75d4a2:	movaps %xmm3,%xmm2
  75d4a5:	cmpunordss %xmm3,%xmm2
  75d4aa:	movaps %xmm2,%xmm4
  75d4ad:	andps  %xmm0,%xmm4
  75d4b0:	andnps %xmm3,%xmm2
  75d4b3:	orps   %xmm4,%xmm2
  75d4b6:	movaps %xmm1,%xmm3
  75d4b9:	subss  %xmm0,%xmm3
  75d4bd:	andps  -0x69a064(%rip),%xmm3        # c3460 <GCC_except_table0+0x10c0>
  75d4c4:	cmp    %r15d,%ebp
  75d4c7:	lea    (%rax,%rax,2),%rax
  75d4cb:	movss  0x8(%rcx,%rax,8),%xmm4
  75d4d1:	movss  0xc(%rcx,%rax,8),%xmm5
  75d4d7:	mov    %edx,(%rdi)
  75d4d9:	movb   $0x1,0x4(%rdi)
  75d4dd:	mov    %ebp,0x8(%rdi)
  75d4e0:	movb   $0x0,0xc(%rdi)
  75d4e4:	movss  %xmm0,0x28(%rdi)
  75d4e9:	movss  %xmm1,0x2c(%rdi)
  75d4ee:	movss  %xmm2,0x10(%rdi)
  75d4f3:	movss  %xmm4,0x14(%rdi)
  75d4f8:	movss  %xmm3,0x18(%rdi)
  75d4fd:	movss  %xmm5,0x1c(%rdi)
  75d502:	mov    %rbx,0x20(%rdi)
  75d506:	seta   0x30(%rdi)
  75d50a:	mov    %r8b,0x31(%rdi)
  75d50e:	add    $0x8,%rsp
  75d512:	pop    %rbx
  75d513:	pop    %r12
  75d515:	pop    %r13
  75d517:	pop    %r14
  75d519:	pop    %r15
  75d51b:	pop    %rbp
  75d51c:	ret
  75d51d:	xor    %r8d,%r8d
  75d520:	cmp    %r15d,%ebp
  75d523:	jbe    75d49b <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x1ab>
  75d529:	movss  0x10(%rsi),%xmm3
  75d52e:	movaps %xmm0,%xmm2
  75d531:	test   %r8b,%r8b
  75d534:	je     75d4c4 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x1d4>
  75d536:	subss  %xmm3,%xmm2
  75d53a:	jmp    75d4c4 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control+0x1d4>
  75d53c:	lea    0x33ba9d(%rip),%rdx        # a98fe0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x808>
  75d543:	mov    $0x1,%edi
  75d548:	mov    $0x1,%esi
  75d54d:	call   *0x35ba4d(%rip)        # ab8fa0 <_DYNAMIC+0x270>
  75d553:	lea    0x33ba9e(%rip),%rdx        # a98ff8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x820>
  75d55a:	mov    %rbx,%rdi
  75d55d:	mov    %rcx,%rsi
  75d560:	call   *0x35ba3a(%rip)        # ab8fa0 <_DYNAMIC+0x270>
  75d566:	lea    0x33baa3(%rip),%rdx        # a99010 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x838>
  75d56d:	mov    %rax,%rdi
  75d570:	mov    %rcx,%rsi
  75d573:	call   *0x35ba27(%rip)        # ab8fa0 <_DYNAMIC+0x270>

<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::present_inner::{closure#9} bytes=1503 frame=248

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075d580 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_>:
  75d580:	push   %rbp
  75d581:	push   %r15
  75d583:	push   %r14
  75d585:	push   %r13
  75d587:	push   %r12
  75d589:	push   %rbx
  75d58a:	sub    $0xc8,%rsp
  75d591:	mov    %rcx,%r14
  75d594:	mov    %rsi,%r15
  75d597:	mov    (%rcx),%ecx
  75d599:	mov    0x10(%r14),%ebx
  75d59d:	test   %ebx,%ebx
  75d59f:	je     75d5c3 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x43>
  75d5a1:	cmp    $0x1,%ebx
  75d5a4:	jne    75d79a <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x21a>
  75d5aa:	movss  -0x69afaa(%rip),%xmm0        # c2608 <GCC_except_table0+0x268>
  75d5b2:	mov    %ebx,%ebp
  75d5b4:	movss  0x4(%r14),%xmm1
  75d5ba:	movaps %xmm1,%xmm2
  75d5bd:	test   %ecx,%ecx
  75d5bf:	je     75d5db <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x5b>
  75d5c1:	jmp    75d5de <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x5e>
  75d5c3:	movss  0x14(%r14),%xmm0
  75d5c9:	mov    $0x1,%ebp
  75d5ce:	movss  0x4(%r14),%xmm1
  75d5d4:	movaps %xmm1,%xmm2
  75d5d7:	test   %ecx,%ecx
  75d5d9:	jne    75d5de <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x5e>
  75d5db:	movaps %xmm0,%xmm2
  75d5de:	mov    $0x1,%eax
  75d5e3:	cmovne %eax,%ebp
  75d5e6:	mov    (%r15),%rax
  75d5e9:	mov    0x10(%rax),%rsi
  75d5ed:	test   %rsi,%rsi
  75d5f0:	je     75dac1 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x541>
  75d5f6:	mov    %ecx,0x1c(%rsp)
  75d5fa:	mov    %rdi,0x10(%rsp)
  75d5ff:	mov    0x8(%rax),%rax
  75d603:	mov    (%rdx),%rcx
  75d606:	cmp    $0x1,%rsi
  75d60a:	jne    75d6d1 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x151>
  75d610:	xor    %r12d,%r12d
  75d613:	mov    %r12,%rdi
  75d616:	shl    $0x4,%rdi
  75d61a:	mov    (%rax,%rdi,1),%r8
  75d61e:	cmp    %rcx,%r8
  75d621:	seta   %sil
  75d625:	sbb    $0x0,%sil
  75d629:	cmp    %rcx,%r8
  75d62c:	jne    75d653 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0xd3>
  75d62e:	add    %rdi,%rax
  75d631:	mov    0x8(%rax),%ecx
  75d634:	mov    0x8(%rdx),%edi
  75d637:	cmp    %edi,%ecx
  75d639:	seta   %sil
  75d63d:	sbb    $0x0,%sil
  75d641:	cmp    %edi,%ecx
  75d643:	jne    75d653 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0xd3>
  75d645:	mov    0xc(%rax),%eax
  75d648:	cmp    0xc(%rdx),%eax
  75d64b:	seta   %sil
  75d64f:	sbb    $0x0,%sil
  75d653:	test   %sil,%sil
  75d656:	jne    75dac6 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x546>
  75d65c:	movss  %xmm2,0x8(%rsp)
  75d662:	movss  %xmm1,0xc(%rsp)
  75d668:	mov    0x8(%r15),%rax
  75d66c:	mov    0x10(%rax),%rsi
  75d670:	cmp    %rsi,%r12
  75d673:	jae    75dafc <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x57c>
  75d679:	mov    0x8(%rax),%rax
  75d67d:	lea    (%r12,%r12,4),%rcx
  75d681:	mov    0x20(%rax,%rcx,8),%r13d
  75d686:	mov    %r13d,%edi
  75d689:	call   *0x35bb19(%rip)        # ab91a8 <_DYNAMIC+0x478>
  75d68f:	cmp    $0x2,%dl
  75d692:	jne    75d729 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x1a9>
  75d698:	mov    0x18(%r15),%rdx
  75d69c:	cmpq   $0x0,(%rdx)
  75d6a0:	je     75da75 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x4f5>
  75d6a6:	mov    %r13d,%eax
  75d6a9:	and    $0xf,%eax
  75d6ac:	cmp    $0x9,%eax
  75d6af:	ja     75daa8 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x528>
  75d6b5:	cmp    $0x6,%eax
  75d6b8:	je     75d6c4 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x144>
  75d6ba:	shr    $0x4,%r13d
  75d6be:	jne    75d7c9 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x249>
  75d6c4:	lea    0x33ba95(%rip),%rdi        # a99160 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x988>
  75d6cb:	call   *0x35b947(%rip)        # ab9018 <_DYNAMIC+0x2e8>
  75d6d1:	mov    0x8(%rdx),%edi
  75d6d4:	mov    0xc(%rdx),%r8d
  75d6d8:	xor    %r9d,%r9d
  75d6db:	jmp    75d6f7 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x177>
  75d6dd:	nopl   (%rax)
  75d6e0:	test   %r13b,%r13b
  75d6e3:	cmovne %r9,%r12
  75d6e7:	sub    %r10,%rsi
  75d6ea:	mov    %r12,%r9
  75d6ed:	cmp    $0x1,%rsi
  75d6f1:	jbe    75d613 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x93>
  75d6f7:	mov    %rsi,%r10
  75d6fa:	shr    $1,%r10
  75d6fd:	lea    (%r10,%r9,1),%r12
  75d701:	mov    %r12,%r11
  75d704:	shl    $0x4,%r11
  75d708:	cmp    %rcx,(%rax,%r11,1)
  75d70c:	seta   %r13b
  75d710:	jne    75d6e0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x160>
  75d712:	add    %rax,%r11
  75d715:	cmp    %edi,0x8(%r11)
  75d719:	seta   %r13b
  75d71d:	jne    75d6e0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x160>
  75d71f:	cmp    %r8d,0xc(%r11)
  75d723:	seta   %r13b
  75d727:	jmp    75d6e0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x160>
  75d729:	mov    0x10(%r15),%rcx
  75d72d:	mov    (%rcx),%rcx
  75d730:	test   %rcx,%rcx
  75d733:	je     75da8e <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x50e>
  75d739:	mov    %eax,%edi
  75d73b:	mov    0x10(%rcx),%rsi
  75d73f:	cmp    %rdi,%rsi
  75d742:	jbe    75db0c <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x58c>
  75d748:	mov    0x8(%rcx),%rax
  75d74c:	mov    (%rax,%rdi,8),%rax
  75d750:	mov    0x30(%rax),%ecx
  75d753:	mov    0x34(%rax),%eax
  75d756:	xorps  %xmm0,%xmm0
  75d759:	cvtsi2ss %rcx,%xmm0
  75d75e:	xorps  %xmm1,%xmm1
  75d761:	cvtsi2ss %rax,%xmm1
  75d766:	movaps %xmm0,%xmm2
  75d769:	divss  %xmm1,%xmm2
  75d76d:	movzbl 0x8(%r14),%ecx
  75d772:	movss  0xc(%r14),%xmm3
  75d778:	cmpb   $0x0,0x1c(%rsp)
  75d77d:	mov    0x10(%rsp),%rax
  75d782:	je     75d7b2 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x232>
  75d784:	test   %cl,%cl
  75d786:	je     75d85c <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x2dc>
  75d78c:	movss  0xc(%rsp),%xmm0
  75d792:	movaps %xmm3,%xmm1
  75d795:	jmp    75d869 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x2e9>
  75d79a:	xor    %ebp,%ebp
  75d79c:	movss  0x4(%r14),%xmm1
  75d7a2:	movaps %xmm1,%xmm2
  75d7a5:	test   %ecx,%ecx
  75d7a7:	je     75d5db <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x5b>
  75d7ad:	jmp    75d5de <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x5e>
  75d7b2:	test   %cl,%cl
  75d7b4:	je     75d869 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x2e9>
  75d7ba:	mulss  %xmm3,%xmm2
  75d7be:	movaps %xmm2,%xmm0
  75d7c1:	movaps %xmm3,%xmm1
  75d7c4:	jmp    75d869 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x2e9>
  75d7c9:	mov    0x20(%r15),%rax
  75d7cd:	mov    0x10(%rax),%rsi
  75d7d1:	dec    %r13d
  75d7d4:	cmp    %r13,%rsi
  75d7d7:	jbe    75db19 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x599>
  75d7dd:	mov    0x8(%rax),%rsi
  75d7e1:	lea    0x0(%r13,%r13,4),%r13
  75d7e6:	shl    $0x4,%r13
  75d7ea:	cmpq   $0xfffffffffffffffe,(%rsi,%r13,1)
  75d7ef:	je     75da9b <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x51b>
  75d7f5:	mov    0x28(%r15),%rcx
  75d7f9:	mov    (%rcx),%rax
  75d7fc:	lea    -0x699883(%rip),%rdi        # c3f80 <GCC_except_table0+0x1be0>
  75d803:	movslq (%rdi,%rax,4),%rax
  75d807:	add    %rdi,%rax
  75d80a:	jmp    *%rax
  75d80c:	movups -0x6993b7(%rip),%xmm0        # c445c <GCC_except_table0+0x20bc>
  75d813:	movaps %xmm0,0x60(%rsp)
  75d818:	movups -0x6993d3(%rip),%xmm0        # c444c <GCC_except_table0+0x20ac>
  75d81f:	movaps %xmm0,0x50(%rsp)
  75d824:	movups -0x6993ef(%rip),%xmm0        # c443c <GCC_except_table0+0x209c>
  75d82b:	movaps %xmm0,0x40(%rsp)
  75d830:	movups -0x69940b(%rip),%xmm0        # c442c <GCC_except_table0+0x208c>
  75d837:	movaps %xmm0,0x30(%rsp)
  75d83c:	movups -0x699427(%rip),%xmm0        # c441c <GCC_except_table0+0x207c>
  75d843:	movaps %xmm0,0x20(%rsp)
  75d848:	movabs $0x3000100000000,%rax
  75d852:	mov    %rax,0x70(%rsp)
  75d857:	jmp    75d932 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x3b2>
  75d85c:	movss  0xc(%rsp),%xmm0
  75d862:	movaps %xmm0,%xmm1
  75d865:	divss  %xmm2,%xmm1
  75d869:	movss  %xmm0,0x10(%rax)
  75d86e:	movss  %xmm1,0x14(%rax)
  75d873:	xorps  %xmm0,%xmm0
  75d876:	movups %xmm0,(%rax)
  75d879:	jmp    75da63 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x4e3>
  75d87e:	mov    0x20(%rcx),%rax
  75d882:	cmp    %rax,%r12
  75d885:	jae    75db29 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x5a9>
  75d88b:	mov    0x10(%rcx),%rax
  75d88f:	mov    0x18(%rcx),%rdi
  75d893:	movzbl (%rdi,%r12,1),%edi
  75d898:	cmp    %rdi,%rax
  75d89b:	jbe    75db4f <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x5cf>
  75d8a1:	mov    0x8(%rcx),%rax
  75d8a5:	imul   $0x58,%rdi,%rcx
  75d8a9:	jmp    75d8f7 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x377>
  75d8ab:	mov    0x8(%rcx),%rax
  75d8af:	lea    0x20(%rsp),%rdi
  75d8b4:	mov    %rsi,0x88(%rsp)
  75d8bc:	mov    %rax,%rsi
  75d8bf:	mov    %rdx,0x80(%rsp)
  75d8c7:	mov    %r12,%rdx
  75d8ca:	call   *0x35b850(%rip)        # ab9120 <_DYNAMIC+0x3f0>
  75d8d0:	mov    0x88(%rsp),%rsi
  75d8d8:	mov    0x80(%rsp),%rdx
  75d8e0:	jmp    75d932 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x3b2>
  75d8e2:	mov    0x18(%rcx),%rax
  75d8e6:	cmp    %rax,%r12
  75d8e9:	jae    75db3c <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x5bc>
  75d8ef:	mov    0x10(%rcx),%rax
  75d8f3:	imul   $0x58,%r12,%rcx
  75d8f7:	mov    0x50(%rax,%rcx,1),%rdi
  75d8fc:	mov    %rdi,0x70(%rsp)
  75d901:	movups 0x40(%rax,%rcx,1),%xmm0
  75d906:	movaps %xmm0,0x60(%rsp)
  75d90b:	movups (%rax,%rcx,1),%xmm0
  75d90f:	movups 0x10(%rax,%rcx,1),%xmm1
  75d914:	movups 0x20(%rax,%rcx,1),%xmm2
  75d919:	movups 0x30(%rax,%rcx,1),%xmm3
  75d91e:	movaps %xmm3,0x50(%rsp)
  75d923:	movaps %xmm2,0x40(%rsp)
  75d928:	movaps %xmm1,0x30(%rsp)
  75d92d:	movaps %xmm0,0x20(%rsp)
  75d932:	mov    0x10(%rsp),%r12
  75d937:	movss  0x8(%rsp),%xmm1
  75d93d:	add    %r13,%rsi
  75d940:	movss  0x38(%rsp),%xmm0
  75d946:	test   %ebx,%ebx
  75d948:	sete   %al
  75d94b:	mov    0x1c(%rsp),%ebx
  75d94f:	or     %bl,%al
  75d951:	movzbl %al,%r8d
  75d955:	lea    0x90(%rsp),%rdi
  75d95d:	mov    %ebp,%ecx
  75d95f:	call   *0x35b84b(%rip)        # ab91b0 <_DYNAMIC+0x480>
  75d965:	cmpl   $0xfffffffe,0x90(%rsp)
  75d96d:	jne    75d9d2 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x452>
  75d96f:	mov    0x98(%rsp),%rax
  75d977:	movss  0x30(%rax),%xmm0
  75d97c:	test   %bl,%bl
  75d97e:	movss  0xc(%rsp),%xmm2
  75d984:	jne    75d98b <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x40b>
  75d986:	movss  0x28(%rax),%xmm2
  75d98b:	add    $0x2c,%rax
  75d98f:	lea    0xc(%r14),%rcx
  75d993:	cmpb   $0x0,0x8(%r14)
  75d998:	cmove  %rax,%rcx
  75d99c:	movss  (%rcx),%xmm1
  75d9a0:	movss  %xmm2,0x10(%r12)
  75d9a7:	movss  %xmm1,0x14(%r12)
  75d9ae:	movl   $0x1,(%r12)
  75d9b6:	movss  %xmm0,0x4(%r12)
  75d9bd:	movl   $0x1,0x8(%r12)
  75d9c6:	movss  %xmm0,0xc(%r12)
  75d9cd:	jmp    75da60 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x4e0>
  75d9d2:	mov    0x30(%r15),%rbx
  75d9d6:	mov    (%rbx),%rax
  75d9d9:	cmp    $0xfffffffffffffffe,%rax
  75d9dd:	je     75da20 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x4a0>
  75d9df:	sub    $0xd,%rax
  75d9e3:	mov    $0x14,%ecx
  75d9e8:	cmovge %rax,%rcx
  75d9ec:	cmp    $0x14,%rcx
  75d9f0:	je     75da03 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x483>
  75d9f2:	cmp    $0x19,%rcx
  75d9f6:	jne    75da20 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x4a0>
  75d9f8:	mov    0x8(%rbx),%rsi
  75d9fc:	mov    $0x10,%eax
  75da01:	jmp    75da0c <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x48c>
  75da03:	mov    0x18(%rbx),%rsi
  75da07:	mov    $0x20,%eax
  75da0c:	test   %rsi,%rsi
  75da0f:	je     75da20 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x4a0>
  75da11:	mov    (%rbx,%rax,1),%rdi
  75da15:	mov    $0x1,%edx
  75da1a:	call   *0x35b550(%rip)        # ab8f70 <_DYNAMIC+0x240>
  75da20:	mov    0xc0(%rsp),%rax
  75da28:	mov    %rax,0x30(%rbx)
  75da2c:	movups 0x90(%rsp),%xmm0
  75da34:	movups 0xa0(%rsp),%xmm1
  75da3c:	movups 0xb0(%rsp),%xmm2
  75da44:	movups %xmm2,0x20(%rbx)
  75da48:	movups %xmm1,0x10(%rbx)
  75da4c:	movups %xmm0,(%rbx)
  75da4f:	xorps  %xmm0,%xmm0
  75da52:	movups %xmm0,(%r12)
  75da57:	movq   $0x0,0x10(%r12)
  75da60:	mov    %r12,%rax
  75da63:	add    $0xc8,%rsp
  75da6a:	pop    %rbx
  75da6b:	pop    %r12
  75da6d:	pop    %r13
  75da6f:	pop    %r14
  75da71:	pop    %r15
  75da73:	pop    %rbp
  75da74:	ret
  75da75:	lea    -0x68e103(%rip),%rdi        # cf979 <GCC_except_table0+0xd5d9>
  75da7c:	lea    0x33b6c5(%rip),%rdx        # a99148 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x970>
  75da83:	mov    $0x28,%esi
  75da88:	call   *0x35b5ba(%rip)        # ab9048 <_DYNAMIC+0x318>
  75da8e:	lea    0x33b683(%rip),%rdi        # a99118 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x940>
  75da95:	call   *0x35b57d(%rip)        # ab9018 <_DYNAMIC+0x2e8>
  75da9b:	lea    0x33b5ce(%rip),%rdi        # a99070 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x898>
  75daa2:	call   *0x35b570(%rip)        # ab9018 <_DYNAMIC+0x2e8>
  75daa8:	lea    -0x68b19f(%rip),%rdi        # d2910 <GCC_except_table0+0x10570>
  75daaf:	lea    0x33c82a(%rip),%rdx        # a9a2e0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1b08>
  75dab6:	mov    $0x83,%esi
  75dabb:	call   *0x35b4e7(%rip)        # ab8fa8 <_DYNAMIC+0x278>
  75dac1:	xor    %r12d,%r12d
  75dac4:	jmp    75dad2 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x552>
  75dac6:	xor    %eax,%eax
  75dac8:	cmp    $0xff,%sil
  75dacc:	sete   %al
  75dacf:	add    %rax,%r12
  75dad2:	mov    %r12,0x20(%rsp)
  75dad7:	lea    -0x68e199(%rip),%rdi        # cf945 <GCC_except_table0+0xd5a5>
  75dade:	lea    0x33c063(%rip),%rcx        # a99b48 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1370>
  75dae5:	lea    0x33b5fc(%rip),%r8        # a990e8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x910>
  75daec:	lea    0x20(%rsp),%rdx
  75daf1:	mov    $0x34,%esi
  75daf6:	call   *0x35b544(%rip)        # ab9040 <_DYNAMIC+0x310>
  75dafc:	lea    0x33b5fd(%rip),%rdx        # a99100 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x928>
  75db03:	mov    %r12,%rdi
  75db06:	call   *0x35b494(%rip)        # ab8fa0 <_DYNAMIC+0x270>
  75db0c:	lea    0x33b61d(%rip),%rdx        # a99130 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x958>
  75db13:	call   *0x35b487(%rip)        # ab8fa0 <_DYNAMIC+0x270>
  75db19:	lea    0x33b538(%rip),%rdx        # a99058 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x880>
  75db20:	mov    %r13,%rdi
  75db23:	call   *0x35b477(%rip)        # ab8fa0 <_DYNAMIC+0x270>
  75db29:	lea    0x33c0f8(%rip),%rdx        # a99c28 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1450>
  75db30:	mov    %r12,%rdi
  75db33:	mov    %rax,%rsi
  75db36:	call   *0x35b464(%rip)        # ab8fa0 <_DYNAMIC+0x270>
  75db3c:	lea    0x33c0cd(%rip),%rdx        # a99c10 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1438>
  75db43:	mov    %r12,%rdi
  75db46:	mov    %rax,%rsi
  75db49:	call   *0x35b451(%rip)        # ab8fa0 <_DYNAMIC+0x270>
  75db4f:	lea    0x33c0ea(%rip),%rdx        # a99c40 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1468>
  75db56:	mov    %rax,%rsi
  75db59:	call   *0x35b441(%rip)        # ab8fa0 <_DYNAMIC+0x270>

<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::present_inner::{closure#41} bytes=884 frame=136

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075db60 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_>:
  75db60:	push   %rbp
  75db61:	push   %r15
  75db63:	push   %r14
  75db65:	push   %r13
  75db67:	push   %r12
  75db69:	push   %rbx
  75db6a:	sub    $0x58,%rsp
  75db6e:	mov    (%rsi),%rax
  75db71:	mov    0x10(%rax),%rcx
  75db75:	mov    %rcx,0x10(%rsp)
  75db7a:	movups (%rax),%xmm0
  75db7d:	movaps %xmm0,(%rsp)
  75db81:	movq   $0x0,(%rax)
  75db88:	movq   $0x4,0x8(%rax)
  75db90:	movq   $0x0,0x10(%rax)
  75db98:	mov    0x8(%rsi),%r13
  75db9c:	mov    0x10(%rsi),%rbp
  75dba0:	mov    0x18(%rsi),%rax
  75dba4:	mov    %rax,0x30(%rsp)
  75dba9:	mov    0x20(%rsi),%rax
  75dbad:	mov    %rax,0x28(%rsp)
  75dbb2:	mov    0x8(%rdx),%r12
  75dbb6:	mov    0x10(%rdx),%rbx
  75dbba:	mov    (%rsp),%r15
  75dbbe:	mov    0x10(%rsp),%rsi
  75dbc3:	mov    %r15,%rax
  75dbc6:	sub    %rsi,%rax
  75dbc9:	cmp    %rax,%rbx
  75dbcc:	mov    %rdi,0x38(%rsp)
  75dbd1:	ja     75de3e <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x2de>
  75dbd7:	test   %rbx,%rbx
  75dbda:	je     75de1a <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x2ba>
  75dbe0:	shl    $0x4,%rbx
  75dbe4:	add    %r12,%rbx
  75dbe7:	mov    %rsp,%rdi
  75dbea:	jmp    75dc29 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc9>
  75dbec:	mov    0x8(%rsp),%rax
  75dbf1:	mov    %rsi,%rcx
  75dbf4:	shl    $0x4,%rcx
  75dbf8:	movl   $0x7fc00000,(%rax,%rcx,1)
  75dbff:	mov    %r15d,0x4(%rax,%rcx,1)
  75dc04:	mov    %r14,0x8(%rax,%rcx,1)
  75dc09:	inc    %rsi
  75dc0c:	mov    %rsi,0x10(%rsp)
  75dc11:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  75dc20:	cmp    %rbx,%r12
  75dc23:	je     75de1a <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x2ba>
  75dc29:	mov    %r12,%rax
  75dc2c:	add    $0x10,%r12
  75dc30:	mov    0x8(%rax),%r15d
  75dc34:	test   %r15d,%r15d
  75dc37:	je     75dc20 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75dc39:	mov    (%rax),%r14
  75dc3c:	cmpb   $0x1,0x0(%r13)
  75dc41:	jne    75dd97 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x237>
  75dc47:	mov    0x0(%rbp),%rax
  75dc4b:	test   %rax,%rax
  75dc4e:	je     75dd00 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x1a0>
  75dc54:	cmp    $0x1,%eax
  75dc57:	jne    75dd20 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x1c0>
  75dc5d:	mov    0x10(%rbp),%rcx
  75dc61:	test   %rcx,%rcx
  75dc64:	je     75dc20 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75dc66:	mov    0x8(%rbp),%rax
  75dc6a:	xor    %edx,%edx
  75dc6c:	cmp    $0x1,%rcx
  75dc70:	je     75dca4 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x144>
  75dc72:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  75dc80:	mov    %rdx,%r9
  75dc83:	mov    %rcx,%r10
  75dc86:	shr    $1,%r10
  75dc89:	add    %r10,%rdx
  75dc8c:	mov    %rdx,%r8
  75dc8f:	shl    $0x4,%r8
  75dc93:	cmp    %r14,(%rax,%r8,1)
  75dc97:	cmova  %r9,%rdx
  75dc9b:	sub    %r10,%rcx
  75dc9e:	cmp    $0x1,%rcx
  75dca2:	ja     75dc80 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x120>
  75dca4:	mov    %rdx,%rcx
  75dca7:	shl    $0x4,%rcx
  75dcab:	xor    %r8d,%r8d
  75dcae:	cmp    %r14,(%rax,%rcx,1)
  75dcb2:	setbe  %r8b
  75dcb6:	add    %rdx,%r8
  75dcb9:	je     75dc20 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75dcbf:	shl    $0x4,%r8
  75dcc3:	mov    %r14,%rcx
  75dcc6:	sub    -0x10(%rax,%r8,1),%rcx
  75dccb:	mov    -0x4(%rax,%r8,1),%edx
  75dcd0:	cmp    %rdx,%rcx
  75dcd3:	jae    75dc20 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75dcd9:	add    %r8,%rax
  75dcdc:	mov    -0x8(%rax),%eax
  75dcdf:	add    %rax,%rcx
  75dce2:	mov    0x30(%rsp),%rax
  75dce7:	cmp    0x10(%rax),%rcx
  75dceb:	jae    75dc20 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75dcf1:	jmp    75dd56 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x1f6>
  75dcf3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  75dd00:	mov    %r14,%rcx
  75dd03:	sub    0x8(%rbp),%rcx
  75dd07:	jb     75dc20 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75dd0d:	cmp    0x10(%rbp),%rcx
  75dd11:	jae    75dc20 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75dd17:	jmp    75dd47 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x1e7>
  75dd19:	nopl   0x0(%rax)
  75dd20:	mov    0x10(%rbp),%rcx
  75dd24:	test   %rcx,%rcx
  75dd27:	je     75dc20 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75dd2d:	mov    0x8(%rbp),%rax
  75dd31:	cmp    $0x1,%rcx
  75dd35:	jne    75ddc8 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x268>
  75dd3b:	cmp    %r14,(%rax)
  75dd3e:	jne    75dc20 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75dd44:	mov    0x8(%rax),%ecx
  75dd47:	mov    0x30(%rsp),%rax
  75dd4c:	cmp    0x10(%rax),%rcx
  75dd50:	jae    75dc20 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75dd56:	mov    0x30(%rsp),%rax
  75dd5b:	mov    0x8(%rax),%rax
  75dd5f:	mov    (%rax,%rcx,4),%eax
  75dd62:	mov    $0xffffffff,%ecx
  75dd67:	cmp    %rcx,%rax
  75dd6a:	je     75dc20 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75dd70:	mov    0x28(%rsp),%rcx
  75dd75:	cmp    %rax,0x10(%rcx)
  75dd79:	jbe    75dc20 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75dd7f:	mov    0x28(%rsp),%rcx
  75dd84:	mov    0x8(%rcx),%rcx
  75dd88:	shl    $0x6,%rax
  75dd8c:	cmp    %r14,0x20(%rcx,%rax,1)
  75dd91:	jne    75dc20 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75dd97:	cmp    (%rsp),%rsi
  75dd9b:	jne    75dbec <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x8c>
  75dda1:	mov    $0x1,%edx
  75dda6:	mov    $0x4,%ecx
  75ddab:	mov    $0x10,%r8d
  75ddb1:	mov    %rsi,0x20(%rsp)
  75ddb6:	call   75b160 <_RINvNvMs2_NtCscdodAO9FK5_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs9C2G9YFESsD_29canonical_text_public_control>
  75ddbb:	mov    %rsp,%rdi
  75ddbe:	mov    0x20(%rsp),%rsi
  75ddc3:	jmp    75dbec <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x8c>
  75ddc8:	xor    %edx,%edx
  75ddca:	nopw   0x0(%rax,%rax,1)
  75ddd0:	mov    %rdx,%r9
  75ddd3:	mov    %rcx,%r10
  75ddd6:	shr    $1,%r10
  75ddd9:	add    %r10,%rdx
  75dddc:	lea    (%rdx,%rdx,2),%r8
  75dde0:	cmp    %r14,(%rax,%r8,4)
  75dde4:	cmova  %r9,%rdx
  75dde8:	sub    %r10,%rcx
  75ddeb:	cmp    $0x1,%rcx
  75ddef:	ja     75ddd0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x270>
  75ddf1:	lea    (%rdx,%rdx,2),%rcx
  75ddf5:	cmp    %r14,(%rax,%rcx,4)
  75ddf9:	jne    75dc20 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75ddff:	lea    (%rax,%rcx,4),%rax
  75de03:	mov    0x8(%rax),%ecx
  75de06:	mov    0x30(%rsp),%rax
  75de0b:	cmp    0x10(%rax),%rcx
  75de0f:	jae    75dc20 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75de15:	jmp    75dd56 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x1f6>
  75de1a:	mov    0x10(%rsp),%rax
  75de1f:	mov    0x38(%rsp),%rcx
  75de24:	mov    %rax,0x10(%rcx)
  75de28:	movaps (%rsp),%xmm0
  75de2c:	movups %xmm0,(%rcx)
  75de2f:	add    $0x58,%rsp
  75de33:	pop    %rbx
  75de34:	pop    %r12
  75de36:	pop    %r13
  75de38:	pop    %r14
  75de3a:	pop    %r15
  75de3c:	pop    %rbp
  75de3d:	ret
  75de3e:	mov    %rsi,0x20(%rsp)
  75de43:	mov    %rsi,%rax
  75de46:	add    %rbx,%rax
  75de49:	jb     75de8e <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x32e>
  75de4b:	mov    0x8(%rsp),%rdx
  75de50:	lea    0x40(%rsp),%rdi
  75de55:	mov    $0x4,%r8d
  75de5b:	mov    $0x10,%r9d
  75de61:	mov    %r15,%rsi
  75de64:	mov    %rax,%r14
  75de67:	mov    %rax,%rcx
  75de6a:	call   772220 <_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs9C2G9YFESsD_29canonical_text_public_control>
  75de6f:	cmpl   $0x1,0x40(%rsp)
  75de74:	je     75de98 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x338>
  75de76:	mov    0x48(%rsp),%rax
  75de7b:	mov    %rax,0x8(%rsp)
  75de80:	mov    %r14,(%rsp)
  75de84:	mov    0x20(%rsp),%rsi
  75de89:	jmp    75dbe0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x80>
  75de8e:	xor    %edi,%edi
  75de90:	call   *0x35b192(%rip)        # ab9028 <_DYNAMIC+0x2f8>
  75de96:	ud2
  75de98:	mov    0x48(%rsp),%rdi
  75de9d:	mov    0x50(%rsp),%rsi
  75dea2:	jmp    75de90 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x330>
  75dea4:	mov    %rax,%rbx
  75dea7:	mov    (%rsp),%r15
  75deab:	jmp    75deb0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x350>
  75dead:	mov    %rax,%rbx
  75deb0:	test   %r15,%r15
  75deb3:	je     75decc <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x36c>
  75deb5:	mov    0x8(%rsp),%rdi
  75deba:	shl    $0x4,%r15
  75debe:	mov    $0x4,%edx
  75dec3:	mov    %r15,%rsi
  75dec6:	call   *0x35b0a4(%rip)        # ab8f70 <_DYNAMIC+0x240>
  75decc:	mov    %rbx,%rdi
  75decf:	call   a97420 <_Unwind_Resume@plt>

<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::present_inner::{closure#44} bytes=415 frame=8

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075dee0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_>:
  75dee0:	push   %rax
  75dee1:	mov    (%rdi),%rdx
  75dee4:	mov    (%rdx),%rax
  75dee7:	test   %rax,%rax
  75deea:	je     75df36 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x56>
  75deec:	cmp    $0x1,%eax
  75deef:	jne    75df52 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x72>
  75def1:	mov    0x8(%rdx),%rcx
  75def5:	mov    0x10(%rdx),%rdx
  75def9:	cmp    $0x1,%rdx
  75defd:	je     75dfa8 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0xc8>
  75df03:	test   %rdx,%rdx
  75df06:	je     75e050 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x170>
  75df0c:	xor    %eax,%eax
  75df0e:	xchg   %ax,%ax
  75df10:	mov    %rax,%r8
  75df13:	mov    %rdx,%r9
  75df16:	shr    $1,%r9
  75df19:	add    %r9,%rax
  75df1c:	mov    %rax,%r10
  75df1f:	shl    $0x4,%r10
  75df23:	cmp    %rsi,(%rcx,%r10,1)
  75df27:	cmova  %r8,%rax
  75df2b:	sub    %r9,%rdx
  75df2e:	cmp    $0x1,%rdx
  75df32:	ja     75df10 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x30>
  75df34:	jmp    75dfaa <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0xca>
  75df36:	mov    %rsi,%rax
  75df39:	sub    0x8(%rdx),%rax
  75df3d:	jb     75e050 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x170>
  75df43:	cmp    0x10(%rdx),%rax
  75df47:	jb     75dfe2 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x102>
  75df4d:	jmp    75e050 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x170>
  75df52:	mov    0x8(%rdx),%rax
  75df56:	mov    0x10(%rdx),%rcx
  75df5a:	cmp    $0x1,%rcx
  75df5e:	je     75e028 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x148>
  75df64:	test   %rcx,%rcx
  75df67:	je     75e050 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x170>
  75df6d:	xor    %edx,%edx
  75df6f:	nop
  75df70:	mov    %rdx,%r8
  75df73:	mov    %rcx,%r9
  75df76:	shr    $1,%r9
  75df79:	add    %r9,%rdx
  75df7c:	lea    (%rdx,%rdx,2),%r10
  75df80:	cmp    %rsi,(%rax,%r10,4)
  75df84:	cmova  %r8,%rdx
  75df88:	sub    %r9,%rcx
  75df8b:	cmp    $0x1,%rcx
  75df8f:	ja     75df70 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x90>
  75df91:	lea    (%rdx,%rdx,2),%rcx
  75df95:	cmp    %rsi,(%rax,%rcx,4)
  75df99:	jne    75e050 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x170>
  75df9f:	lea    (%rax,%rcx,4),%rax
  75dfa3:	jmp    75e02d <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x14d>
  75dfa8:	xor    %eax,%eax
  75dfaa:	mov    %rax,%r8
  75dfad:	shl    $0x4,%r8
  75dfb1:	xor    %edx,%edx
  75dfb3:	cmp    %rsi,(%rcx,%r8,1)
  75dfb7:	setbe  %dl
  75dfba:	add    %rax,%rdx
  75dfbd:	je     75e050 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x170>
  75dfc3:	shl    $0x4,%rdx
  75dfc7:	mov    %rsi,%rax
  75dfca:	sub    -0x10(%rcx,%rdx,1),%rax
  75dfcf:	mov    -0x4(%rcx,%rdx,1),%r8d
  75dfd4:	cmp    %r8,%rax
  75dfd7:	jae    75e050 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x170>
  75dfd9:	add    %rdx,%rcx
  75dfdc:	mov    -0x8(%rcx),%ecx
  75dfdf:	add    %rcx,%rax
  75dfe2:	mov    0x8(%rdi),%rdx
  75dfe6:	mov    0x10(%rdx),%rcx
  75dfea:	cmp    %rcx,%rax
  75dfed:	jae    75e03d <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x15d>
  75dfef:	mov    0x8(%rdx),%rcx
  75dff3:	mov    (%rcx,%rax,4),%edx
  75dff6:	mov    $0xffffffff,%eax
  75dffb:	cmp    %rax,%rdx
  75dffe:	je     75e024 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x144>
  75e000:	mov    0x10(%rdi),%rcx
  75e004:	mov    0x10(%rcx),%rax
  75e008:	cmp    %rdx,%rax
  75e00b:	jbe    75e069 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x189>
  75e00d:	mov    0x8(%rcx),%rcx
  75e011:	mov    %rdx,%rdi
  75e014:	shl    $0x6,%rdi
  75e018:	xor    %eax,%eax
  75e01a:	cmp    %rsi,0x20(%rcx,%rdi,1)
  75e01f:	sete   %al
  75e022:	pop    %rcx
  75e023:	ret
  75e024:	xor    %eax,%eax
  75e026:	pop    %rcx
  75e027:	ret
  75e028:	cmp    %rsi,(%rax)
  75e02b:	jne    75e050 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x170>
  75e02d:	mov    0x8(%rax),%eax
  75e030:	mov    0x8(%rdi),%rdx
  75e034:	mov    0x10(%rdx),%rcx
  75e038:	cmp    %rcx,%rax
  75e03b:	jb     75dfef <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x10f>
  75e03d:	lea    0x33b134(%rip),%rdx        # a99178 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x9a0>
  75e044:	mov    %rax,%rdi
  75e047:	mov    %rcx,%rsi
  75e04a:	call   *0x35af50(%rip)        # ab8fa0 <_DYNAMIC+0x270>
  75e050:	lea    -0x68e81f(%rip),%rdi        # cf838 <GCC_except_table0+0xd498>
  75e057:	lea    0x33ab32(%rip),%rdx        # a98b90 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x3b8>
  75e05e:	mov    $0x15,%esi
  75e063:	call   *0x35afdf(%rip)        # ab9048 <_DYNAMIC+0x318>
  75e069:	lea    0x33ad30(%rip),%rcx        # a98da0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x5c8>
  75e070:	mov    %rdx,%rdi
  75e073:	mov    %rax,%rsi
  75e076:	mov    %rcx,%rdx
  75e079:	call   *0x35af21(%rip)        # ab8fa0 <_DYNAMIC+0x270>

<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::present_inner::{closure#15} bytes=130 frame=8

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075e080 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_>:
  75e080:	push   %rax
  75e081:	cmp    %rsi,%rdx
  75e084:	jae    75e0ef <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_+0x6f>
  75e086:	lea    (%rdx,%rdx,4),%rax
  75e08a:	mov    0x20(%rdi,%rax,8),%eax
  75e08e:	and    $0xf,%eax
  75e091:	cmp    $0x9,%eax
  75e094:	ja     75e0d6 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_+0x56>
  75e096:	lea    -0x69a10d(%rip),%rcx        # c3f90 <GCC_except_table0+0x1bf0>
  75e09d:	movslq (%rcx,%rax,4),%rax
  75e0a1:	add    %rcx,%rax
  75e0a4:	jmp    *%rax
  75e0a6:	mov    $0x8,%al
  75e0a8:	jmp    75e0c8 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_+0x48>
  75e0aa:	mov    $0x4,%al
  75e0ac:	jmp    75e0c8 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_+0x48>
  75e0ae:	mov    $0x2,%al
  75e0b0:	jmp    75e0c8 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_+0x48>
  75e0b2:	mov    $0x3,%al
  75e0b4:	jmp    75e0c8 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_+0x48>
  75e0b6:	mov    $0x7,%al
  75e0b8:	jmp    75e0c8 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_+0x48>
  75e0ba:	xor    %eax,%eax
  75e0bc:	jmp    75e0c8 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_+0x48>
  75e0be:	mov    $0x1,%al
  75e0c0:	jmp    75e0c8 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_+0x48>
  75e0c2:	mov    $0x5,%al
  75e0c4:	jmp    75e0c8 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_+0x48>
  75e0c6:	mov    $0x6,%al
  75e0c8:	cmp    $0x4,%al
  75e0ca:	sete   %cl
  75e0cd:	cmp    $0x7,%al
  75e0cf:	sete   %al
  75e0d2:	or     %cl,%al
  75e0d4:	pop    %rcx
  75e0d5:	ret
  75e0d6:	lea    -0x68b7cd(%rip),%rdi        # d2910 <GCC_except_table0+0x10570>
  75e0dd:	lea    0x33c1fc(%rip),%rdx        # a9a2e0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1b08>
  75e0e4:	mov    $0x83,%esi
  75e0e9:	call   *0x35aeb9(%rip)        # ab8fa8 <_DYNAMIC+0x278>
  75e0ef:	lea    0x33b09a(%rip),%rax        # a99190 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x9b8>
  75e0f6:	mov    %rdx,%rdi
  75e0f9:	mov    %rax,%rdx
  75e0fc:	call   *0x35ae9e(%rip)        # ab8fa0 <_DYNAMIC+0x270>

<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::present_inner::{closure#25} bytes=143 frame=24

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075e110 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersn_0BQ_>:
  75e110:	push   %r14
  75e112:	push   %rbx
  75e113:	push   %rax
  75e114:	mov    %rdx,%rbx
  75e117:	and    $0xf,%esi
  75e11a:	cmp    $0x7,%esi
  75e11d:	jb     75e127 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersn_0BQ_+0x17>
  75e11f:	lea    -0x8(%rsi),%eax
  75e122:	cmp    $0x2,%eax
  75e125:	jae    75e14d <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersn_0BQ_+0x3d>
  75e127:	mov    0x30(%rbx),%rax
  75e12b:	mov    %rax,0x30(%rdi)
  75e12f:	movups (%rbx),%xmm0
  75e132:	movups 0x10(%rbx),%xmm1
  75e136:	movups 0x20(%rbx),%xmm2
  75e13a:	movups %xmm2,0x20(%rdi)
  75e13e:	movups %xmm1,0x10(%rdi)
  75e142:	movups %xmm0,(%rdi)
  75e145:	add    $0x8,%rsp
  75e149:	pop    %rbx
  75e14a:	pop    %r14
  75e14c:	ret
  75e14d:	cmp    $0x7,%esi
  75e150:	jne    75e171 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersn_0BQ_+0x61>
  75e152:	cmpl   $0x27,(%rbx)
  75e155:	jne    75e127 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersn_0BQ_+0x17>
  75e157:	cmpq   $0xb,0x8(%rbx)
  75e15c:	jne    75e127 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersn_0BQ_+0x17>
  75e15e:	movb   $0x5,0x8(%rdi)
  75e162:	movq   $0x28,(%rdi)
  75e169:	add    $0x8,%rsp
  75e16d:	pop    %rbx
  75e16e:	pop    %r14
  75e170:	ret
  75e171:	lea    -0x68b868(%rip),%rdi        # d2910 <GCC_except_table0+0x10570>
  75e178:	lea    0x33c161(%rip),%rdx        # a9a2e0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1b08>
  75e17f:	mov    $0x83,%esi
  75e184:	call   *0x35ae1e(%rip)        # ab8fa8 <_DYNAMIC+0x278>
  75e18a:	ud2
  75e18c:	mov    %rax,%r14
  75e18f:	mov    %rbx,%rdi
  75e192:	call   74d580 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  75e197:	mov    %r14,%rdi
  75e19a:	call   a97420 <_Unwind_Resume@plt>

<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::present_inner::{closure#26} bytes=61 frame=72

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075e1a0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerso_0BQ_>:
  75e1a0:	sub    $0x48,%rsp
  75e1a4:	cvtps2pd (%rdx),%xmm0
  75e1a7:	cvtps2pd 0x8(%rdx),%xmm1
  75e1ab:	movaps %xmm0,0x10(%rsp)
  75e1b0:	movaps %xmm1,0x20(%rsp)
  75e1b5:	cvtps2pd 0x10(%rdx),%xmm0
  75e1b9:	movaps %xmm0,0x30(%rsp)
  75e1be:	movb   $0x0,0x40(%rsp)
  75e1c3:	movups (%rsi),%xmm0
  75e1c6:	movaps %xmm0,(%rsp)
  75e1ca:	lea    0x10(%rsp),%rsi
  75e1cf:	mov    %rsp,%rdx
  75e1d2:	call   *0x35afe0(%rip)        # ab91b8 <_DYNAMIC+0x488>
  75e1d8:	add    $0x48,%rsp
  75e1dc:	ret

<<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::present_inner::{closure#9} as core::ops::function::FnOnce<(gpui_reactivity_core::tree::NodeId, cephal::tree::traits::MeasureInput)>>::call_once::{shim:vtable#0} bytes=57 frame=56

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075ecd0 <_RNSNvYNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtBc_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0INtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceTNtNtCscO85OU7Wpt0_20gpui_reactivity_core4tree6NodeIdNtNtNtCs2M7EwM6HstD_6cephal4tree6traits12MeasureInputEE9call_once6vtableBV_>:
  75ecd0:	push   %rbx
  75ecd1:	sub    $0x30,%rsp
  75ecd5:	mov    %rdi,%rbx
  75ecd8:	lea    0x10(%rsp),%rax
  75ecdd:	movups (%rcx),%xmm0
  75ece0:	movups 0x10(%rcx),%xmm1
  75ece4:	movaps %xmm1,0x20(%rsp)
  75ece9:	movaps %xmm0,0x10(%rsp)
  75ecee:	movups (%rdx),%xmm0
  75ecf1:	movaps %xmm0,(%rsp)
  75ecf5:	mov    %rsp,%rdx
  75ecf8:	mov    %rax,%rcx
  75ecfb:	call   75d580 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_>
  75ed00:	mov    %rbx,%rax
  75ed03:	add    $0x30,%rsp
  75ed07:	pop    %rbx
  75ed08:	ret

canonical_text_public_control::owner_drag bytes=1426 frame=280

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075ed10 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag>:
  75ed10:	push   %rbp
  75ed11:	push   %r15
  75ed13:	push   %r14
  75ed15:	push   %r13
  75ed17:	push   %r12
  75ed19:	push   %rbx
  75ed1a:	sub    $0xe8,%rsp
  75ed21:	movss  %xmm1,0x8(%rsp)
  75ed27:	movss  %xmm0,0x94(%rsp)
  75ed30:	mov    (%rdi),%r15
  75ed33:	test   %r15,%r15
  75ed36:	je     75f090 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x380>
  75ed3c:	cmpb   $0x0,0x76e(%r15)
  75ed44:	jne    75f097 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x387>
  75ed4a:	cmpb   $0x1,0x76a(%r15)
  75ed52:	jne    75f09e <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x38e>
  75ed58:	mov    %rsi,0xb0(%rsp)
  75ed60:	mov    %rdi,0x98(%rsp)
  75ed68:	mov    0x5c0(%r15),%rbp
  75ed6f:	mov    $0x1a,%eax
  75ed74:	mov    %rax,0x88(%rsp)
  75ed7c:	test   %rbp,%rbp
  75ed7f:	je     75f0ab <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x39b>
  75ed85:	mov    0x5b8(%r15),%r14
  75ed8c:	shl    $0x6,%rbp
  75ed90:	lea    0x1e8(%r15),%r12
  75ed97:	xor    %ebx,%ebx
  75ed99:	mov    0x35a290(%rip),%r13        # ab9030 <_DYNAMIC+0x300>
  75eda0:	jmp    75edbd <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0xad>
  75eda2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  75edb0:	add    $0x40,%rbx
  75edb4:	cmp    %rbx,%rbp
  75edb7:	je     75f0ab <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x39b>
  75edbd:	cmpb   $0x4,0x3d(%r14,%rbx,1)
  75edc3:	jne    75edb0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0xa0>
  75edc5:	mov    0x20(%r14,%rbx,1),%rsi
  75edca:	mov    %r12,%rdi
  75edcd:	call   *%r13
  75edd0:	test   %al,%al
  75edd2:	je     75edb0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0xa0>
  75edd4:	mov    0x20(%r14,%rbx,1),%rsi
  75edd9:	lea    0x5f0(%r15),%rdi
  75ede0:	call   *0x35a3ea(%rip)        # ab91d0 <_DYNAMIC+0x4a0>
  75ede6:	cmpb   $0x0,0x76e(%r15)
  75edee:	jne    75f0ee <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x3de>
  75edf4:	mov    %rdx,%rcx
  75edf7:	lea    0x10(%rsp),%rdi
  75edfc:	mov    %r15,%rsi
  75edff:	mov    %rax,%rdx
  75ee02:	call   76a390 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11input_indexBY_>
  75ee07:	mov    0x10(%rsp),%rax
  75ee0c:	mov    0x18(%rsp),%rdx
  75ee11:	cmp    $0xfffffffffffffffe,%rax
  75ee15:	mov    0x98(%rsp),%rbx
  75ee1d:	jne    75f0f9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x3e9>
  75ee23:	lea    0x50(%rsp),%rdi
  75ee28:	mov    %r15,%rsi
  75ee2b:	call   76a4d0 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE12selection_atBY_>
  75ee30:	cmpq   $0xfffffffffffffffe,0x50(%rsp)
  75ee36:	jne    75f124 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x414>
  75ee3c:	movups 0x58(%rsp),%xmm0
  75ee41:	movaps %xmm0,0xa0(%rsp)
  75ee49:	movss  0x94(%rsp),%xmm0
  75ee52:	movss  %xmm0,0x14(%rsp)
  75ee58:	movss  0x8(%rsp),%xmm0
  75ee5e:	movss  %xmm0,0x18(%rsp)
  75ee64:	movl   $0x0,0x10(%rsp)
  75ee6c:	lea    0x50(%rsp),%rdi
  75ee71:	lea    0x10(%rsp),%rcx
  75ee76:	mov    %rbx,%rsi
  75ee79:	mov    0xb0(%rsp),%rdx
  75ee81:	call   76cda0 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_>
  75ee86:	cmpl   $0xfffffffe,0x50(%rsp)
  75ee8b:	jne    75f01f <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x30f>
  75ee91:	mov    (%rbx),%rsi
  75ee94:	lea    0xb8(%rsp),%rdi
  75ee9c:	call   760560 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack>
  75eea1:	mov    (%rbx),%r14
  75eea4:	test   %r14,%r14
  75eea7:	je     75f186 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x476>
  75eead:	cmpb   $0x0,0x76e(%r14)
  75eeb5:	jne    75f18d <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x47d>
  75eebb:	cmpb   $0x1,0x76a(%r14)
  75eec3:	jne    75f194 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x484>
  75eec9:	mov    0x5c0(%r14),%rbp
  75eed0:	mov    $0x1a,%eax
  75eed5:	mov    %rax,0x8(%rsp)
  75eeda:	test   %rbp,%rbp
  75eedd:	je     75f19e <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x48e>
  75eee3:	mov    0x5b8(%r14),%r12
  75eeea:	shl    $0x6,%rbp
  75eeee:	lea    0x1e8(%r14),%r15
  75eef5:	xor    %ebx,%ebx
  75eef7:	jmp    75ef0d <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x1fd>
  75eef9:	nopl   0x0(%rax)
  75ef00:	add    $0x40,%rbx
  75ef04:	cmp    %rbx,%rbp
  75ef07:	je     75f19e <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x48e>
  75ef0d:	cmpb   $0x4,0x3d(%r12,%rbx,1)
  75ef13:	jne    75ef00 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x1f0>
  75ef15:	mov    0x20(%r12,%rbx,1),%rsi
  75ef1a:	mov    %r15,%rdi
  75ef1d:	call   *%r13
  75ef20:	test   %al,%al
  75ef22:	je     75ef00 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x1f0>
  75ef24:	mov    0x20(%r12,%rbx,1),%rsi
  75ef29:	add    $0x5f0,%r14
  75ef30:	mov    %r14,%rdi
  75ef33:	call   *0x35a297(%rip)        # ab91d0 <_DYNAMIC+0x4a0>
  75ef39:	mov    %rdx,%rcx
  75ef3c:	mov    0x98(%rsp),%rdx
  75ef44:	mov    (%rdx),%rbx
  75ef47:	test   %rbx,%rbx
  75ef4a:	je     75f1de <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x4ce>
  75ef50:	cmpb   $0x0,0x76e(%rbx)
  75ef57:	jne    75f1f2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x4e2>
  75ef5d:	lea    0x10(%rsp),%rdi
  75ef62:	mov    %rbx,%rsi
  75ef65:	mov    %rax,%rdx
  75ef68:	call   76a390 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11input_indexBY_>
  75ef6d:	mov    0x10(%rsp),%rax
  75ef72:	mov    0x18(%rsp),%rdx
  75ef77:	cmp    $0xfffffffffffffffe,%rax
  75ef7b:	jne    75f1fd <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x4ed>
  75ef81:	lea    0x50(%rsp),%rdi
  75ef86:	mov    %rbx,%rsi
  75ef89:	call   76a4d0 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE12selection_atBY_>
  75ef8e:	cmpq   $0xfffffffffffffffe,0x50(%rsp)
  75ef94:	jne    75f228 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x518>
  75ef9a:	movups 0x58(%rsp),%xmm0
  75ef9f:	movaps %xmm0,0x10(%rsp)
  75efa4:	movzbl 0x1c(%rsp),%ecx
  75efa9:	cmp    0xac(%rsp),%cl
  75efb0:	mov    0x18(%rsp),%edx
  75efb4:	sete   %al
  75efb7:	cmp    0xa8(%rsp),%edx
  75efbe:	je     75efc2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x2b2>
  75efc0:	xor    %eax,%eax
  75efc2:	test   %al,%al
  75efc4:	jne    75f077 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x367>
  75efca:	mov    0xd0(%rsp),%rsi
  75efd2:	xor    0xc8(%rsp),%rsi
  75efda:	movabs $0x100000001b3,%rdi
  75efe4:	imul   %rdi,%rsi
  75efe8:	mov    0x10(%rsp),%eax
  75efec:	xor    %rsi,%rax
  75efef:	movzbl 0x14(%rsp),%esi
  75eff4:	imul   %rdi,%rax
  75eff8:	xor    %rsi,%rax
  75effb:	imul   %rdi,%rax
  75efff:	xor    %rdx,%rax
  75f002:	imul   %rdi,%rax
  75f006:	xor    %rcx,%rax
  75f009:	imul   %rdi,%rax
  75f00d:	add    $0xe8,%rsp
  75f014:	pop    %rbx
  75f015:	pop    %r12
  75f017:	pop    %r13
  75f019:	pop    %r14
  75f01b:	pop    %r15
  75f01d:	pop    %rbp
  75f01e:	ret
  75f01f:	mov    0x80(%rsp),%rax
  75f027:	mov    %rax,0x40(%rsp)
  75f02c:	movups 0x50(%rsp),%xmm0
  75f031:	movups 0x60(%rsp),%xmm1
  75f036:	movups 0x70(%rsp),%xmm2
  75f03b:	movaps %xmm2,0x30(%rsp)
  75f040:	movaps %xmm1,0x20(%rsp)
  75f045:	movaps %xmm0,0x10(%rsp)
  75f04a:	lea    -0x68f427(%rip),%rdi        # cfc2a <GCC_except_table0+0xd88a>
  75f051:	lea    0x33aa10(%rip),%rcx        # a99a68 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1290>
  75f058:	lea    0x33a389(%rip),%r8        # a993e8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xc10>
  75f05f:	lea    0x10(%rsp),%rbx
  75f064:	mov    $0x2b,%esi
  75f069:	mov    %rbx,%rdx
  75f06c:	call   *0x359fce(%rip)        # ab9040 <_DYNAMIC+0x310>
  75f072:	jmp    75f285 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x575>
  75f077:	lea    0x18(%rsp),%rdi
  75f07c:	lea    0xa8(%rsp),%rsi
  75f084:	lea    0x33a38d(%rip),%rdx        # a99418 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xc40>
  75f08b:	call   74f303 <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextPositionBM_ECs9C2G9YFESsD_29canonical_text_public_control>
  75f090:	mov    $0xd,%eax
  75f095:	jmp    75f0a3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x393>
  75f097:	mov    $0xe,%eax
  75f09c:	jmp    75f0a3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x393>
  75f09e:	mov    $0x12,%eax
  75f0a3:	mov    %rax,0x88(%rsp)
  75f0ab:	mov    0x88(%rsp),%rax
  75f0b3:	mov    %rax,0x10(%rsp)
  75f0b8:	movq   $0x0,0x18(%rsp)
  75f0c1:	lea    -0x68f727(%rip),%rdi        # cf9a1 <GCC_except_table0+0xd601>
  75f0c8:	lea    0x33a999(%rip),%rcx        # a99a68 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1290>
  75f0cf:	lea    0x33a2e2(%rip),%r8        # a993b8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xbe0>
  75f0d6:	lea    0x10(%rsp),%rbx
  75f0db:	mov    $0x2a,%esi
  75f0e0:	mov    %rbx,%rdx
  75f0e3:	call   *0x359f57(%rip)        # ab9040 <_DYNAMIC+0x310>
  75f0e9:	jmp    75f285 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x575>
  75f0ee:	movq   $0xe,0x50(%rsp)
  75f0f7:	jmp    75f124 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x414>
  75f0f9:	mov    0x40(%rsp),%rcx
  75f0fe:	mov    %rcx,0x80(%rsp)
  75f106:	movups 0x20(%rsp),%xmm0
  75f10b:	movups 0x30(%rsp),%xmm1
  75f110:	movups %xmm1,0x70(%rsp)
  75f115:	movups %xmm0,0x60(%rsp)
  75f11a:	mov    %rax,0x50(%rsp)
  75f11f:	mov    %rdx,0x58(%rsp)
  75f124:	mov    0x80(%rsp),%rax
  75f12c:	mov    %rax,0x40(%rsp)
  75f131:	mov    0x50(%rsp),%rax
  75f136:	mov    0x58(%rsp),%rcx
  75f13b:	movups 0x60(%rsp),%xmm0
  75f140:	movups 0x70(%rsp),%xmm1
  75f145:	movaps %xmm1,0x30(%rsp)
  75f14a:	movaps %xmm0,0x20(%rsp)
  75f14f:	mov    %rax,0x10(%rsp)
  75f154:	mov    %rcx,0x18(%rsp)
  75f159:	lea    -0x68f536(%rip),%rdi        # cfc2a <GCC_except_table0+0xd88a>
  75f160:	lea    0x33a901(%rip),%rcx        # a99a68 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1290>
  75f167:	lea    0x33a262(%rip),%r8        # a993d0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xbf8>
  75f16e:	lea    0x10(%rsp),%rbx
  75f173:	mov    $0x2b,%esi
  75f178:	mov    %rbx,%rdx
  75f17b:	call   *0x359ebf(%rip)        # ab9040 <_DYNAMIC+0x310>
  75f181:	jmp    75f285 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x575>
  75f186:	mov    $0xd,%eax
  75f18b:	jmp    75f199 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x489>
  75f18d:	mov    $0xe,%eax
  75f192:	jmp    75f199 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x489>
  75f194:	mov    $0x12,%eax
  75f199:	mov    %rax,0x8(%rsp)
  75f19e:	mov    0x8(%rsp),%rax
  75f1a3:	mov    %rax,0x10(%rsp)
  75f1a8:	movq   $0x0,0x18(%rsp)
  75f1b1:	lea    -0x68f817(%rip),%rdi        # cf9a1 <GCC_except_table0+0xd601>
  75f1b8:	lea    0x33a8a9(%rip),%rcx        # a99a68 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1290>
  75f1bf:	lea    0x33a1f2(%rip),%r8        # a993b8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xbe0>
  75f1c6:	lea    0x10(%rsp),%rbx
  75f1cb:	mov    $0x2a,%esi
  75f1d0:	mov    %rbx,%rdx
  75f1d3:	call   *0x359e67(%rip)        # ab9040 <_DYNAMIC+0x310>
  75f1d9:	jmp    75f285 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x575>
  75f1de:	movq   $0xd,0x50(%rsp)
  75f1e7:	movq   $0x0,0x58(%rsp)
  75f1f0:	jmp    75f228 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x518>
  75f1f2:	movq   $0xe,0x50(%rsp)
  75f1fb:	jmp    75f228 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x518>
  75f1fd:	mov    0x40(%rsp),%rcx
  75f202:	mov    %rcx,0x80(%rsp)
  75f20a:	movups 0x20(%rsp),%xmm0
  75f20f:	movups 0x30(%rsp),%xmm1
  75f214:	movups %xmm1,0x70(%rsp)
  75f219:	movups %xmm0,0x60(%rsp)
  75f21e:	mov    %rax,0x50(%rsp)
  75f223:	mov    %rdx,0x58(%rsp)
  75f228:	mov    0x80(%rsp),%rax
  75f230:	mov    %rax,0x40(%rsp)
  75f235:	mov    0x50(%rsp),%rax
  75f23a:	mov    0x58(%rsp),%rcx
  75f23f:	movups 0x60(%rsp),%xmm0
  75f244:	movups 0x70(%rsp),%xmm1
  75f249:	movaps %xmm1,0x30(%rsp)
  75f24e:	movaps %xmm0,0x20(%rsp)
  75f253:	mov    %rax,0x10(%rsp)
  75f258:	mov    %rcx,0x18(%rsp)
  75f25d:	lea    -0x68f63a(%rip),%rdi        # cfc2a <GCC_except_table0+0xd88a>
  75f264:	lea    0x33a7fd(%rip),%rcx        # a99a68 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1290>
  75f26b:	lea    0x33a18e(%rip),%r8        # a99400 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xc28>
  75f272:	lea    0x10(%rsp),%rbx
  75f277:	mov    $0x2b,%esi
  75f27c:	mov    %rbx,%rdx
  75f27f:	call   *0x359dbb(%rip)        # ab9040 <_DYNAMIC+0x310>
  75f285:	ud2
  75f287:	jmp    75f28f <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x57f>
  75f289:	jmp    75f28f <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x57f>
  75f28b:	jmp    75f28f <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x57f>
  75f28d:	jmp    75f28f <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x57f>
  75f28f:	mov    %rax,%r14
  75f292:	mov    %rbx,%rdi
  75f295:	call   74d580 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  75f29a:	mov    %r14,%rdi
  75f29d:	call   a97420 <_Unwind_Resume@plt>

canonical_text_public_control::owner_arrow bytes=1422 frame=248

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075f2b0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow>:
  75f2b0:	push   %rbp
  75f2b1:	push   %r15
  75f2b3:	push   %r14
  75f2b5:	push   %r13
  75f2b7:	push   %r12
  75f2b9:	push   %rbx
  75f2ba:	sub    $0xc8,%rsp
  75f2c1:	mov    (%rdi),%rbx
  75f2c4:	test   %rbx,%rbx
  75f2c7:	je     75f5c1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x311>
  75f2cd:	cmpb   $0x0,0x76e(%rbx)
  75f2d4:	jne    75f5c8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x318>
  75f2da:	cmpb   $0x1,0x76a(%rbx)
  75f2e1:	jne    75f5cf <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x31f>
  75f2e7:	mov    %esi,0x38(%rsp)
  75f2eb:	mov    0x5c0(%rbx),%r12
  75f2f2:	mov    $0x1a,%eax
  75f2f7:	mov    %rax,0x78(%rsp)
  75f2fc:	test   %r12,%r12
  75f2ff:	je     75f5d9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x329>
  75f305:	mov    0x5b8(%rbx),%r13
  75f30c:	shl    $0x6,%r12
  75f310:	lea    0x1e8(%rbx),%r14
  75f317:	xor    %r15d,%r15d
  75f31a:	mov    0x359d0f(%rip),%rbp        # ab9030 <_DYNAMIC+0x300>
  75f321:	jmp    75f33d <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x8d>
  75f323:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  75f330:	add    $0x40,%r15
  75f334:	cmp    %r15,%r12
  75f337:	je     75f5d9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x329>
  75f33d:	cmpb   $0x4,0x3d(%r13,%r15,1)
  75f343:	jne    75f330 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x80>
  75f345:	mov    0x20(%r13,%r15,1),%rsi
  75f34a:	mov    %r14,%rdi
  75f34d:	call   *%rbp
  75f34f:	test   %al,%al
  75f351:	je     75f330 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x80>
  75f353:	mov    0x20(%r13,%r15,1),%rsi
  75f358:	lea    0x5f0(%rbx),%rdi
  75f35f:	call   *0x359e6b(%rip)        # ab91d0 <_DYNAMIC+0x4a0>
  75f365:	cmpb   $0x0,0x76e(%rbx)
  75f36c:	jne    75f616 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x366>
  75f372:	mov    %rdx,%rcx
  75f375:	mov    %rsp,%rdi
  75f378:	mov    %rbx,%rsi
  75f37b:	mov    %rax,%rdx
  75f37e:	call   76a390 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11input_indexBY_>
  75f383:	mov    (%rsp),%rax
  75f387:	mov    0x8(%rsp),%rdx
  75f38c:	cmp    $0xfffffffffffffffe,%rax
  75f390:	jne    75f621 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x371>
  75f396:	lea    0x40(%rsp),%rdi
  75f39b:	mov    %rbx,%rsi
  75f39e:	call   76a4d0 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE12selection_atBY_>
  75f3a3:	cmpq   $0xfffffffffffffffe,0x40(%rsp)
  75f3a9:	jne    75f649 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x399>
  75f3af:	movups 0x48(%rsp),%xmm0
  75f3b4:	movaps %xmm0,0x80(%rsp)
  75f3bc:	cmpb   $0x1,0x76e(%rbx)
  75f3c3:	je     75f6a5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x3f5>
  75f3c9:	movq   $0x0,0x758(%rbx)
  75f3d4:	mov    0x628(%rbx),%r12
  75f3db:	test   %r12,%r12
  75f3de:	je     75f46c <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x1bc>
  75f3e4:	cmp    0x5f0(%rbx),%r12
  75f3eb:	jne    75f790 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x4e0>
  75f3f1:	mov    0x630(%rbx),%r13
  75f3f8:	mov    %rsp,%rdi
  75f3fb:	mov    %rbx,%rsi
  75f3fe:	mov    %r13,%rdx
  75f401:	call   78c610 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE16resolve_identityBO_>
  75f406:	mov    (%rsp),%rax
  75f40a:	mov    0x8(%rsp),%rdi
  75f40f:	cmp    $0xfffffffffffffffe,%rax
  75f413:	jne    75f795 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x4e5>
  75f419:	mov    0x2e0(%rbx),%rsi
  75f420:	cmp    %rsi,%rdi
  75f423:	jae    75f816 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x566>
  75f429:	mov    0x2d8(%rbx),%rax
  75f430:	lea    (%rdi,%rdi,4),%rcx
  75f434:	mov    0x20(%rax,%rcx,8),%edi
  75f438:	call   7759f0 <_RNvMsh_NtCslbxve4rcJus_4gpui7runtimeNtB5_4Node4kind>
  75f43d:	cmp    $0x4,%al
  75f43f:	jne    75f46c <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x1bc>
  75f441:	movzbl 0x38(%rsp),%r8d
  75f447:	lea    0x40(%rsp),%rdi
  75f44c:	mov    %rbx,%rsi
  75f44f:	mov    %r12,%rdx
  75f452:	mov    %r13,%rcx
  75f455:	mov    $0x1,%r9d
  75f45b:	call   76f840 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE14move_selectionB12_>
  75f460:	cmpq   $0xfffffffffffffffe,0x40(%rsp)
  75f466:	jne    75f7bd <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x50d>
  75f46c:	lea    0x98(%rsp),%rdi
  75f474:	mov    %rbx,%rsi
  75f477:	call   760560 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack>
  75f47c:	cmpb   $0x0,0x76e(%rbx)
  75f483:	jne    75f6b3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x403>
  75f489:	cmpb   $0x1,0x76a(%rbx)
  75f490:	jne    75f6ba <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x40a>
  75f496:	mov    0x5c0(%rbx),%r13
  75f49d:	mov    $0x1a,%eax
  75f4a2:	mov    %rax,0x38(%rsp)
  75f4a7:	test   %r13,%r13
  75f4aa:	je     75f6c4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x414>
  75f4b0:	mov    0x5b8(%rbx),%r15
  75f4b7:	shl    $0x6,%r13
  75f4bb:	xor    %r12d,%r12d
  75f4be:	jmp    75f4cd <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x21d>
  75f4c0:	add    $0x40,%r12
  75f4c4:	cmp    %r12,%r13
  75f4c7:	je     75f6c4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x414>
  75f4cd:	cmpb   $0x4,0x3d(%r15,%r12,1)
  75f4d3:	jne    75f4c0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x210>
  75f4d5:	mov    0x20(%r15,%r12,1),%rsi
  75f4da:	mov    %r14,%rdi
  75f4dd:	call   *%rbp
  75f4df:	test   %al,%al
  75f4e1:	je     75f4c0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x210>
  75f4e3:	mov    0x20(%r15,%r12,1),%rsi
  75f4e8:	lea    0x5f0(%rbx),%rdi
  75f4ef:	call   *0x359cdb(%rip)        # ab91d0 <_DYNAMIC+0x4a0>
  75f4f5:	cmpb   $0x0,0x76e(%rbx)
  75f4fc:	jne    75f701 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x451>
  75f502:	mov    %rdx,%rcx
  75f505:	mov    %rsp,%rdi
  75f508:	mov    %rbx,%rsi
  75f50b:	mov    %rax,%rdx
  75f50e:	call   76a390 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11input_indexBY_>
  75f513:	mov    (%rsp),%rax
  75f517:	mov    0x8(%rsp),%rdx
  75f51c:	cmp    $0xfffffffffffffffe,%rax
  75f520:	jne    75f70c <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x45c>
  75f526:	lea    0x40(%rsp),%rdi
  75f52b:	mov    %rbx,%rsi
  75f52e:	call   76a4d0 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE12selection_atBY_>
  75f533:	cmpq   $0xfffffffffffffffe,0x40(%rsp)
  75f539:	jne    75f734 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x484>
  75f53f:	movups 0x48(%rsp),%xmm0
  75f544:	movaps %xmm0,(%rsp)
  75f548:	movzbl 0xc(%rsp),%ecx
  75f54d:	cmp    0x8c(%rsp),%cl
  75f554:	mov    0x8(%rsp),%edx
  75f558:	sete   %al
  75f55b:	cmp    0x88(%rsp),%edx
  75f562:	je     75f566 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x2b6>
  75f564:	xor    %eax,%eax
  75f566:	test   %al,%al
  75f568:	jne    75f5a8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x2f8>
  75f56a:	mov    0xb0(%rsp),%rax
  75f572:	xor    0xa8(%rsp),%rax
  75f57a:	movabs $0x100000001b3,%rsi
  75f584:	imul   %rsi,%rax
  75f588:	xor    %rdx,%rax
  75f58b:	imul   %rsi,%rax
  75f58f:	xor    %rcx,%rax
  75f592:	imul   %rsi,%rax
  75f596:	add    $0xc8,%rsp
  75f59d:	pop    %rbx
  75f59e:	pop    %r12
  75f5a0:	pop    %r13
  75f5a2:	pop    %r14
  75f5a4:	pop    %r15
  75f5a6:	pop    %rbp
  75f5a7:	ret
  75f5a8:	lea    0x8(%rsp),%rdi
  75f5ad:	lea    0x88(%rsp),%rsi
  75f5b5:	lea    0x339ebc(%rip),%rdx        # a99478 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xca0>
  75f5bc:	call   74f303 <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextPositionBM_ECs9C2G9YFESsD_29canonical_text_public_control>
  75f5c1:	mov    $0xd,%eax
  75f5c6:	jmp    75f5d4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x324>
  75f5c8:	mov    $0xe,%eax
  75f5cd:	jmp    75f5d4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x324>
  75f5cf:	mov    $0x12,%eax
  75f5d4:	mov    %rax,0x78(%rsp)
  75f5d9:	mov    0x78(%rsp),%rax
  75f5de:	mov    %rax,(%rsp)
  75f5e2:	movq   $0x0,0x8(%rsp)
  75f5eb:	lea    -0x68fc51(%rip),%rdi        # cf9a1 <GCC_except_table0+0xd601>
  75f5f2:	lea    0x33a46f(%rip),%rcx        # a99a68 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1290>
  75f5f9:	lea    0x339db8(%rip),%r8        # a993b8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xbe0>
  75f600:	mov    %rsp,%rbx
  75f603:	mov    $0x2a,%esi
  75f608:	mov    %rbx,%rdx
  75f60b:	call   *0x359a2f(%rip)        # ab9040 <_DYNAMIC+0x310>
  75f611:	jmp    75f814 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x564>
  75f616:	movq   $0xe,0x40(%rsp)
  75f61f:	jmp    75f649 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x399>
  75f621:	mov    0x30(%rsp),%rcx
  75f626:	mov    %rcx,0x70(%rsp)
  75f62b:	movups 0x10(%rsp),%xmm0
  75f630:	movups 0x20(%rsp),%xmm1
  75f635:	movups %xmm1,0x60(%rsp)
  75f63a:	movups %xmm0,0x50(%rsp)
  75f63f:	mov    %rax,0x40(%rsp)
  75f644:	mov    %rdx,0x48(%rsp)
  75f649:	mov    0x70(%rsp),%rax
  75f64e:	mov    %rax,0x30(%rsp)
  75f653:	mov    0x40(%rsp),%rax
  75f658:	mov    0x48(%rsp),%rcx
  75f65d:	movups 0x50(%rsp),%xmm0
  75f662:	movups 0x60(%rsp),%xmm1
  75f667:	movaps %xmm1,0x20(%rsp)
  75f66c:	movaps %xmm0,0x10(%rsp)
  75f671:	mov    %rax,(%rsp)
  75f675:	mov    %rcx,0x8(%rsp)
  75f67a:	lea    -0x68fa57(%rip),%rdi        # cfc2a <GCC_except_table0+0xd88a>
  75f681:	lea    0x33a3e0(%rip),%rcx        # a99a68 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1290>
  75f688:	lea    0x339da1(%rip),%r8        # a99430 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xc58>
  75f68f:	mov    %rsp,%rbx
  75f692:	mov    $0x2b,%esi
  75f697:	mov    %rbx,%rdx
  75f69a:	call   *0x3599a0(%rip)        # ab9040 <_DYNAMIC+0x310>
  75f6a0:	jmp    75f814 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x564>
  75f6a5:	movq   $0xe,0x40(%rsp)
  75f6ae:	jmp    75f7bd <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x50d>
  75f6b3:	mov    $0xe,%eax
  75f6b8:	jmp    75f6bf <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x40f>
  75f6ba:	mov    $0x12,%eax
  75f6bf:	mov    %rax,0x38(%rsp)
  75f6c4:	mov    0x38(%rsp),%rax
  75f6c9:	mov    %rax,(%rsp)
  75f6cd:	movq   $0x0,0x8(%rsp)
  75f6d6:	lea    -0x68fd3c(%rip),%rdi        # cf9a1 <GCC_except_table0+0xd601>
  75f6dd:	lea    0x33a384(%rip),%rcx        # a99a68 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1290>
  75f6e4:	lea    0x339ccd(%rip),%r8        # a993b8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xbe0>
  75f6eb:	mov    %rsp,%rbx
  75f6ee:	mov    $0x2a,%esi
  75f6f3:	mov    %rbx,%rdx
  75f6f6:	call   *0x359944(%rip)        # ab9040 <_DYNAMIC+0x310>
  75f6fc:	jmp    75f814 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x564>
  75f701:	movq   $0xe,0x40(%rsp)
  75f70a:	jmp    75f734 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x484>
  75f70c:	mov    0x30(%rsp),%rcx
  75f711:	mov    %rcx,0x70(%rsp)
  75f716:	movups 0x10(%rsp),%xmm0
  75f71b:	movups 0x20(%rsp),%xmm1
  75f720:	movups %xmm1,0x60(%rsp)
  75f725:	movups %xmm0,0x50(%rsp)
  75f72a:	mov    %rax,0x40(%rsp)
  75f72f:	mov    %rdx,0x48(%rsp)
  75f734:	mov    0x70(%rsp),%rax
  75f739:	mov    %rax,0x30(%rsp)
  75f73e:	mov    0x40(%rsp),%rax
  75f743:	mov    0x48(%rsp),%rcx
  75f748:	movups 0x50(%rsp),%xmm0
  75f74d:	movups 0x60(%rsp),%xmm1
  75f752:	movaps %xmm1,0x20(%rsp)
  75f757:	movaps %xmm0,0x10(%rsp)
  75f75c:	mov    %rax,(%rsp)
  75f760:	mov    %rcx,0x8(%rsp)
  75f765:	lea    -0x68fb42(%rip),%rdi        # cfc2a <GCC_except_table0+0xd88a>
  75f76c:	lea    0x33a2f5(%rip),%rcx        # a99a68 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1290>
  75f773:	lea    0x339ce6(%rip),%r8        # a99460 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xc88>
  75f77a:	mov    %rsp,%rbx
  75f77d:	mov    $0x2b,%esi
  75f782:	mov    %rbx,%rdx
  75f785:	call   *0x3598b5(%rip)        # ab9040 <_DYNAMIC+0x310>
  75f78b:	jmp    75f814 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x564>
  75f790:	mov    $0x11,%eax
  75f795:	mov    0x30(%rsp),%rcx
  75f79a:	mov    %rcx,0x70(%rsp)
  75f79f:	movups 0x10(%rsp),%xmm0
  75f7a4:	movups 0x20(%rsp),%xmm1
  75f7a9:	movups %xmm1,0x60(%rsp)
  75f7ae:	movups %xmm0,0x50(%rsp)
  75f7b3:	mov    %rax,0x40(%rsp)
  75f7b8:	mov    %rdi,0x48(%rsp)
  75f7bd:	mov    0x70(%rsp),%rax
  75f7c2:	mov    %rax,0x30(%rsp)
  75f7c7:	mov    0x40(%rsp),%rax
  75f7cc:	mov    0x48(%rsp),%rcx
  75f7d1:	movups 0x50(%rsp),%xmm0
  75f7d6:	movups 0x60(%rsp),%xmm1
  75f7db:	movaps %xmm1,0x20(%rsp)
  75f7e0:	movaps %xmm0,0x10(%rsp)
  75f7e5:	mov    %rax,(%rsp)
  75f7e9:	mov    %rcx,0x8(%rsp)
  75f7ee:	lea    -0x68fbcb(%rip),%rdi        # cfc2a <GCC_except_table0+0xd88a>
  75f7f5:	lea    0x33a26c(%rip),%rcx        # a99a68 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1290>
  75f7fc:	lea    0x339c45(%rip),%r8        # a99448 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xc70>
  75f803:	mov    %rsp,%rbx
  75f806:	mov    $0x2b,%esi
  75f80b:	mov    %rbx,%rdx
  75f80e:	call   *0x35982c(%rip)        # ab9040 <_DYNAMIC+0x310>
  75f814:	ud2
  75f816:	lea    0x33a72b(%rip),%rdx        # a99f48 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1770>
  75f81d:	call   *0x35977d(%rip)        # ab8fa0 <_DYNAMIC+0x270>
  75f823:	jmp    75f82b <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x57b>
  75f825:	jmp    75f82b <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x57b>
  75f827:	jmp    75f82b <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x57b>
  75f829:	jmp    75f82b <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x57b>
  75f82b:	mov    %rax,%r14
  75f82e:	mov    %rbx,%rdi
  75f831:	call   74d580 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  75f836:	mov    %r14,%rdi
  75f839:	call   a97420 <_Unwind_Resume@plt>

canonical_text_public_control::query_visual bytes=142 frame=40

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075f840 <_RNvCs9C2G9YFESsD_29canonical_text_public_control12query_visual>:
  75f840:	push   %rbp
  75f841:	push   %r15
  75f843:	push   %r14
  75f845:	push   %r12
  75f847:	push   %rbx
  75f848:	mov    %edx,%r15d
  75f84b:	mov    %esi,%r14d
  75f84e:	mov    %rdi,%r12
  75f851:	call   *0x359981(%rip)        # ab91d8 <_DYNAMIC+0x4a8>
  75f857:	cmp    $0x2,%dl
  75f85a:	je     75f8b4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control12query_visual+0x74>
  75f85c:	mov    %eax,%ebx
  75f85e:	mov    %edx,%ebp
  75f860:	movzbl %r15b,%edx
  75f864:	mov    %r12,%rdi
  75f867:	mov    %r14d,%esi
  75f86a:	call   *0x359970(%rip)        # ab91e0 <_DYNAMIC+0x4b0>
  75f870:	cmp    $0x2,%dl
  75f873:	je     75f8c1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control12query_visual+0x81>
  75f875:	xor    $0x1,%ebx
  75f878:	movabs $0x100000001b3,%rcx
  75f882:	imul   %rcx,%rbx
  75f886:	and    $0x1,%bpl
  75f88a:	movzbl %bpl,%esi
  75f88e:	xor    %rbx,%rsi
  75f891:	imul   %rcx,%rsi
  75f895:	mov    %eax,%edi
  75f897:	xor    %rsi,%rdi
  75f89a:	imul   %rcx,%rdi
  75f89e:	and    $0x1,%dl
  75f8a1:	movzbl %dl,%eax
  75f8a4:	xor    %rdi,%rax
  75f8a7:	imul   %rcx,%rax
  75f8ab:	pop    %rbx
  75f8ac:	pop    %r12
  75f8ae:	pop    %r14
  75f8b0:	pop    %r15
  75f8b2:	pop    %rbp
  75f8b3:	ret
  75f8b4:	lea    0x339d9d(%rip),%rdi        # a99658 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xe80>
  75f8bb:	call   *0x359757(%rip)        # ab9018 <_DYNAMIC+0x2e8>
  75f8c1:	lea    0x339da8(%rip),%rdi        # a99670 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xe98>
  75f8c8:	call   *0x35974a(%rip)        # ab9018 <_DYNAMIC+0x2e8>

canonical_text_public_control::owner_prepare bytes=1380 frame=280

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075f8d0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare>:
  75f8d0:	push   %rbp
  75f8d1:	push   %r15
  75f8d3:	push   %r14
  75f8d5:	push   %r13
  75f8d7:	push   %r12
  75f8d9:	push   %rbx
  75f8da:	sub    $0xe8,%rsp
  75f8e1:	mov    %rdi,%r14
  75f8e4:	test   %esi,%esi
  75f8e6:	jne    75f8ee <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x1e>
  75f8e8:	pxor   %xmm0,%xmm0
  75f8ec:	jmp    75f8f6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x26>
  75f8ee:	movd   -0x69d4ee(%rip),%xmm0        # c2408 <GCC_except_table0+0x68>
  75f8f6:	movd   %xmm0,(%rsp)
  75f8fb:	mov    (%r14),%rbx
  75f8fe:	test   %rbx,%rbx
  75f901:	je     75fbec <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x31c>
  75f907:	lea    0x8(%r14),%rax
  75f90b:	mov    %rbx,0xd8(%rsp)
  75f913:	mov    %rax,0xe0(%rsp)
  75f91b:	cmpb   $0x0,0x76e(%rbx)
  75f922:	jne    75fc22 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x352>
  75f928:	mov    0x6a0(%rbx),%rax
  75f92f:	mov    %rax,0xd0(%rsp)
  75f937:	movabs $0x200000001,%r15
  75f941:	mov    0x248(%rbx),%rbp
  75f948:	mov    0x250(%rbx),%r12
  75f94f:	shl    $0x4,%r12
  75f953:	xor    %r13d,%r13d
  75f956:	cs nopw 0x0(%rax,%rax,1)
  75f960:	cmp    %r13,%r12
  75f963:	je     75fb9d <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x2cd>
  75f969:	mov    0x0(%rbp,%r13,1),%rdi
  75f96e:	mov    0x8(%rbp,%r13,1),%rax
  75f973:	call   *0x18(%rax)
  75f976:	add    $0x10,%r13
  75f97a:	cmp    %r15,%rax
  75f97d:	jne    75f960 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x90>
  75f97f:	mov    -0x10(%rbp,%r13,1),%rdi
  75f984:	mov    -0x8(%rbp,%r13,1),%rax
  75f989:	lea    0x290(%rbx),%rsi
  75f990:	call   *0x28(%rax)
  75f993:	mov    %rax,%rdi
  75f996:	mov    %rdx,%rax
  75f999:	lea    0x33a7a0(%rip),%rdx        # a9a140 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1968>
  75f9a0:	lea    0x2b0(%rbx),%rsi
  75f9a7:	call   *0x20(%rax)
  75f9aa:	mov    %r15,0x18(%rsp)
  75f9af:	mov    0x18(%rsp),%rcx
  75f9b4:	mov    %rcx,0xb0(%rsp)
  75f9bc:	mov    0x20(%rsp),%rcx
  75f9c1:	mov    %rcx,0xb8(%rsp)
  75f9c9:	test   %al,%al
  75f9cb:	je     75fc2d <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x35d>
  75f9d1:	movq   $0x0,0xb0(%rsp)
  75f9dd:	cmpb   $0x0,0x76e(%rbx)
  75f9e4:	jne    75fc34 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x364>
  75f9ea:	mov    0x6a0(%rbx),%rax
  75f9f1:	inc    %rax
  75f9f4:	je     75fab5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x1e5>
  75f9fa:	mov    0x2c8(%rbx),%ecx
  75fa00:	cmp    $0xffffffff,%ecx
  75fa03:	je     75fb82 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x2b2>
  75fa09:	inc    %ecx
  75fa0b:	mov    %ecx,0x2c8(%rbx)
  75fa11:	movaps -0x69bed8(%rip),%xmm0        # c3b40 <GCC_except_table0+0x17a0>
  75fa18:	movups %xmm0,0x2b0(%rbx)
  75fa1f:	movss  (%rsp),%xmm0
  75fa24:	movss  %xmm0,0x2c0(%rbx)
  75fa2c:	movl   $0x0,0x2c4(%rbx)
  75fa36:	mov    %rax,0x6a0(%rbx)
  75fa3d:	incq   0x700(%rbx)
  75fa44:	movq   $0x0,0x758(%rbx)
  75fa4f:	lea    0x78(%rsp),%rdi
  75fa54:	lea    0xd8(%rsp),%rsi
  75fa5c:	lea    0xb0(%rsp),%rcx
  75fa64:	mov    %r15,%rdx
  75fa67:	xor    %r8d,%r8d
  75fa6a:	call   766d20 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB4_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE20after_source_changedBW_>
  75fa6f:	mov    0x78(%rsp),%r12
  75fa74:	cmp    $0xfffffffffffffffe,%r12
  75fa78:	jne    75fc3f <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x36f>
  75fa7e:	mov    (%r14),%rsi
  75fa81:	lea    0x10(%rsp),%rdi
  75fa86:	call   760560 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack>
  75fa8b:	mov    0x28(%rsp),%rcx
  75fa90:	xor    0x20(%rsp),%rcx
  75fa95:	movabs $0x100000001b3,%rax
  75fa9f:	imul   %rcx,%rax
  75faa3:	add    $0xe8,%rsp
  75faaa:	pop    %rbx
  75faab:	pop    %r12
  75faad:	pop    %r13
  75faaf:	pop    %r14
  75fab1:	pop    %r15
  75fab3:	pop    %rbp
  75fab4:	ret
  75fab5:	mov    $0x1f,%r12d
  75fabb:	mov    0x88(%rsp),%r14
  75fac3:	mov    0x90(%rsp),%rbx
  75facb:	movd   (%rsp),%xmm0
  75fad0:	movd   %xmm0,%ecx
  75fad4:	mov    %ecx,%r9d
  75fad7:	shr    $0x8,%r9d
  75fadb:	movabs $0x3f80000000000000,%rsi
  75fae5:	mov    $0x3f800000,%edx
  75faea:	mov    $0x2,%r10d
  75faf0:	pxor   %xmm0,%xmm0
  75faf4:	mov    %r10,0x10(%rsp)
  75faf9:	mov    %r12,0x18(%rsp)
  75fafe:	mov    %rax,0x20(%rsp)
  75fb03:	mov    %r14,0x28(%rsp)
  75fb08:	mov    %rbx,0x30(%rsp)
  75fb0d:	mov    %r11b,0x38(%rsp)
  75fb12:	mov    0x8(%rsp),%eax
  75fb16:	mov    0xb(%rsp),%r10d
  75fb1b:	mov    %eax,0x39(%rsp)
  75fb1f:	mov    %r10d,0x3c(%rsp)
  75fb24:	mov    %r13,0x40(%rsp)
  75fb29:	mov    %r15,0x48(%rsp)
  75fb2e:	mov    %rdx,0x50(%rsp)
  75fb33:	mov    %rsi,0x58(%rsp)
  75fb38:	mov    %cl,0x60(%rsp)
  75fb3c:	mov    %r9w,0x61(%rsp)
  75fb42:	shr    $0x10,%r9d
  75fb46:	mov    %r9b,0x63(%rsp)
  75fb4b:	movd   %xmm0,0x64(%rsp)
  75fb51:	mov    %rdi,0x68(%rsp)
  75fb56:	mov    %r8,0x70(%rsp)
  75fb5b:	lea    -0x68ff38(%rip),%rdi        # cfc2a <GCC_except_table0+0xd88a>
  75fb62:	lea    0x339f5f(%rip),%rcx        # a99ac8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x12f0>
  75fb69:	lea    0x339b40(%rip),%r8        # a996b0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xed8>
  75fb70:	lea    0x10(%rsp),%rdx
  75fb75:	mov    $0x2b,%esi
  75fb7a:	call   *0x3594c0(%rip)        # ab9040 <_DYNAMIC+0x310>
  75fb80:	jmp    75fb9b <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x2cb>
  75fb82:	lea    -0x68cea7(%rip),%rdi        # d2ce2 <GCC_except_table0+0x10942>
  75fb89:	lea    0x33b020(%rip),%rdx        # a9abb0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x23d8>
  75fb90:	mov    $0x19,%esi
  75fb95:	call   *0x3594ad(%rip)        # ab9048 <_DYNAMIC+0x318>
  75fb9b:	ud2
  75fb9d:	mov    %r15,0x18(%rsp)
  75fba2:	mov    0x18(%rsp),%rax
  75fba7:	mov    %rax,0xb0(%rsp)
  75fbaf:	mov    0x20(%rsp),%rax
  75fbb4:	mov    %rax,0xb8(%rsp)
  75fbbc:	mov    $0xb,%eax
  75fbc1:	mov    0xb0(%rsp),%rcx
  75fbc9:	mov    %rcx,0x88(%rsp)
  75fbd1:	mov    0xb8(%rsp),%rcx
  75fbd9:	mov    %rcx,0x90(%rsp)
  75fbe1:	mov    $0x20,%r12d
  75fbe7:	jmp    75fabb <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x1eb>
  75fbec:	movd   (%rsp),%xmm0
  75fbf1:	movd   %xmm0,%ecx
  75fbf5:	mov    %ecx,%r9d
  75fbf8:	shr    $0x8,%r9d
  75fbfc:	movabs $0x3f80000000000000,%rsi
  75fc06:	mov    $0x3f800000,%edx
  75fc0b:	pxor   %xmm0,%xmm0
  75fc0f:	mov    $0xd,%r12d
  75fc15:	mov    $0x2,%r10d
  75fc1b:	xor    %eax,%eax
  75fc1d:	jmp    75faf4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x224>
  75fc22:	mov    $0xe,%r12d
  75fc28:	jmp    75facb <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x1fb>
  75fc2d:	mov    $0xa,%eax
  75fc32:	jmp    75fbc1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x2f1>
  75fc34:	mov    $0xe,%r12d
  75fc3a:	jmp    75fabb <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x1eb>
  75fc3f:	mov    0x80(%rsp),%rax
  75fc47:	mov    %rax,(%rsp)
  75fc4b:	mov    0x88(%rsp),%rdx
  75fc53:	movzbl 0x98(%rsp),%ecx
  75fc5b:	mov    0xa0(%rsp),%rdi
  75fc63:	mov    0xa8(%rsp),%r8
  75fc6b:	mov    0x90(%rsp),%rsi
  75fc73:	mov    0x6a0(%rbx),%rax
  75fc7a:	cmp    0xd0(%rsp),%rax
  75fc82:	jne    75fcb9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x3e9>
  75fc84:	lea    0x99(%rsp),%rax
  75fc8c:	mov    (%rax),%r9d
  75fc8f:	mov    0x3(%rax),%eax
  75fc92:	mov    %eax,0xb(%rsp)
  75fc96:	mov    %r9d,0x8(%rsp)
  75fc9b:	mov    $0x4,%r10d
  75fca1:	mov    %r8,%r15
  75fca4:	mov    %rdi,%r13
  75fca7:	mov    %ecx,%r11d
  75fcaa:	mov    %rsi,%rbx
  75fcad:	mov    %rdx,%r14
  75fcb0:	mov    (%rsp),%rax
  75fcb4:	jmp    75faf4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x224>
  75fcb9:	movzbl 0x76c(%rbx),%r11d
  75fcc1:	cmpq   $0x0,0x6d0(%rbx)
  75fcc9:	je     75fcda <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x40a>
  75fccb:	test   %r11b,%r11b
  75fcce:	je     75fcdf <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x40f>
  75fcd0:	cmpq   $0xffffffffffffffff,0x5c8(%rbx)
  75fcd8:	jne    75fcdf <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x40f>
  75fcda:	xor    %r10d,%r10d
  75fcdd:	jmp    75fcec <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x41c>
  75fcdf:	mov    0x6e0(%rbx),%rbp
  75fce6:	mov    $0x1,%r10d
  75fcec:	mov    0x6a8(%rbx),%r14
  75fcf3:	mov    0x758(%rbx),%rbx
  75fcfa:	movzbl 0x9b(%rsp),%r15d
  75fd03:	shl    $0x10,%r15d
  75fd07:	movzwl 0x99(%rsp),%r9d
  75fd10:	or     %r15d,%r9d
  75fd13:	movd   0x9c(%rsp),%xmm0
  75fd1c:	mov    (%rsp),%r15
  75fd20:	mov    %r12,%r13
  75fd23:	mov    %rbp,%r12
  75fd26:	jmp    75faf4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x224>
  75fd2b:	jmp    75fd2d <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x45d>
  75fd2d:	mov    %rax,%rdi
  75fd30:	call   *0x359292(%rip)        # ab8fc8 <_DYNAMIC+0x298>
  75fd36:	mov    %rax,%r14
  75fd39:	mov    %rdx,%r15
  75fd3c:	mov    %rax,0x18(%rsp)
  75fd41:	mov    %rdx,0x20(%rsp)
  75fd46:	movq   $0xfffffffffffffffe,0x10(%rsp)
  75fd4f:	mov    %rbx,%rdi
  75fd52:	call   78cc60 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE6poisonBO_>
  75fd57:	mov    (%r15),%rax
  75fd5a:	test   %rax,%rax
  75fd5d:	je     75fd64 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x494>
  75fd5f:	mov    %r14,%rdi
  75fd62:	call   *%rax
  75fd64:	mov    0x8(%r15),%rsi
  75fd68:	mov    $0xf,%r12d
  75fd6e:	test   %rsi,%rsi
  75fd71:	je     75fabb <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x1eb>
  75fd77:	mov    0x10(%r15),%rdx
  75fd7b:	mov    %r14,%rdi
  75fd7e:	call   *0x3591ec(%rip)        # ab8f70 <_DYNAMIC+0x240>
  75fd84:	jmp    75fabb <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x1eb>
  75fd89:	mov    %rax,%rbx
  75fd8c:	mov    0x8(%r15),%rsi
  75fd90:	test   %rsi,%rsi
  75fd93:	je     75fe0b <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x53b>
  75fd95:	mov    0x10(%r15),%rdx
  75fd99:	mov    %r14,%rdi
  75fd9c:	call   *0x3591ce(%rip)        # ab8f70 <_DYNAMIC+0x240>
  75fda2:	mov    %rbx,%rdi
  75fda5:	call   a97420 <_Unwind_Resume@plt>
  75fdaa:	mov    %rax,%rbx
  75fdad:	lea    0x10(%rsp),%rdi
  75fdb2:	call   746060 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultIBC_NtNtCslbxve4rcJus_4gpui7element9AdmissionNtNtB15_6source9BindErrorEINtNtCscdodAO9FK5_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECs9C2G9YFESsD_29canonical_text_public_control>
  75fdb7:	jmp    75fe0b <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x53b>
  75fdb9:	call   *0x3591d9(%rip)        # ab8f98 <_DYNAMIC+0x268>
  75fdbf:	call   *0x35920b(%rip)        # ab8fd0 <_DYNAMIC+0x2a0>
  75fdc5:	mov    %rax,%rdi
  75fdc8:	call   *0x3591fa(%rip)        # ab8fc8 <_DYNAMIC+0x298>
  75fdce:	mov    %rax,0x18(%rsp)
  75fdd3:	mov    %rdx,0x20(%rsp)
  75fdd8:	movq   $0xfffffffffffffffd,0x10(%rsp)
  75fde1:	mov    %rbx,%rdi
  75fde4:	call   78cc60 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE6poisonBO_>
  75fde9:	lea    0x10(%rsp),%rdi
  75fdee:	call   7460d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultIBC_NtNtNtCslbxve4rcJus_4gpui7runtime5paint12PatchOutcomeNtB15_5ErrorEINtNtCscdodAO9FK5_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECs9C2G9YFESsD_29canonical_text_public_control>
  75fdf3:	mov    $0xf,%r12d
  75fdf9:	jmp    75fabb <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x1eb>
  75fdfe:	mov    %rax,%rbx
  75fe01:	lea    0x10(%rsp),%rdi
  75fe06:	call   7460d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultIBC_NtNtNtCslbxve4rcJus_4gpui7runtime5paint12PatchOutcomeNtB15_5ErrorEINtNtCscdodAO9FK5_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECs9C2G9YFESsD_29canonical_text_public_control>
  75fe0b:	mov    %rbx,%rdi
  75fe0e:	call   a97420 <_Unwind_Resume@plt>
  75fe13:	call   *0x35917f(%rip)        # ab8f98 <_DYNAMIC+0x268>
  75fe19:	call   *0x3591b1(%rip)        # ab8fd0 <_DYNAMIC+0x2a0>
  75fe1f:	mov    %rax,%rbx
  75fe22:	lea    0x10(%rsp),%rdi
  75fe27:	call   748360 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui7runtime8SetErrorNtNtCscO85OU7Wpt0_20gpui_reactivity_core8geometry6AffineEECs9C2G9YFESsD_29canonical_text_public_control>
  75fe2c:	mov    %rbx,%rdi
  75fe2f:	call   a97420 <_Unwind_Resume@plt>

canonical_text_public_control::owner_reshape bytes=340 frame=248

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075fe40 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_reshape>:
  75fe40:	push   %r15
  75fe42:	push   %r14
  75fe44:	push   %r13
  75fe46:	push   %r12
  75fe48:	push   %rbx
  75fe49:	sub    $0xd0,%rsp
  75fe50:	mov    %rdx,%r14
  75fe53:	test   %rdx,%rdx
  75fe56:	jns    75fe67 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_reshape+0x27>
  75fe58:	xor    %r13d,%r13d
  75fe5b:	mov    %r13,%rdi
  75fe5e:	mov    %r14,%rsi
  75fe61:	call   *0x3591c1(%rip)        # ab9028 <_DYNAMIC+0x2f8>
  75fe67:	mov    %rdi,%rbx
  75fe6a:	je     75fea2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_reshape+0x62>
  75fe6c:	mov    %rsi,%r12
  75fe6f:	call   *0x359103(%rip)        # ab8f78 <_DYNAMIC+0x248>
  75fe75:	mov    $0x1,%r13d
  75fe7b:	mov    $0x1,%esi
  75fe80:	mov    %r14,%rdi
  75fe83:	call   *0x3590f7(%rip)        # ab8f80 <_DYNAMIC+0x250>
  75fe89:	test   %rax,%rax
  75fe8c:	je     75fe5b <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_reshape+0x1b>
  75fe8e:	mov    %rax,%r15
  75fe91:	mov    %rax,%rdi
  75fe94:	mov    %r12,%rsi
  75fe97:	mov    %r14,%rdx
  75fe9a:	call   *0x3590f0(%rip)        # ab8f90 <memcpy@GLIBC_2.14>
  75fea0:	jmp    75fea8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_reshape+0x68>
  75fea2:	mov    $0x1,%r15d
  75fea8:	mov    %r14,(%rsp)
  75feac:	mov    %r15,0x8(%rsp)
  75feb1:	mov    %r14,0x10(%rsp)
  75feb6:	lea    0x3396fb(%rip),%rdx        # a995b8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xde0>
  75febd:	lea    0x68(%rsp),%rdi
  75fec2:	mov    %rsp,%rcx
  75fec5:	mov    %rbx,%rsi
  75fec8:	call   744830 <_RINvMst_NtCslbxve4rcJus_4gpui7runtimeINtB6_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE3setNtNtCscdodAO9FK5_5alloc6string6StringEBL_>
  75fecd:	cmpl   $0xffffffff,0x68(%rsp)
  75fed2:	jne    75ff08 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_reshape+0xc8>
  75fed4:	mov    (%rbx),%rsi
  75fed7:	mov    %rsp,%rdi
  75feda:	call   760560 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack>
  75fedf:	mov    0x18(%rsp),%rcx
  75fee4:	xor    0x10(%rsp),%rcx
  75fee9:	movabs $0x100000001b3,%rax
  75fef3:	imul   %rcx,%rax
  75fef7:	add    $0xd0,%rsp
  75fefe:	pop    %rbx
  75feff:	pop    %r12
  75ff01:	pop    %r13
  75ff03:	pop    %r14
  75ff05:	pop    %r15
  75ff07:	ret
  75ff08:	mov    0xc8(%rsp),%rax
  75ff10:	mov    %rax,0x60(%rsp)
  75ff15:	movups 0xb8(%rsp),%xmm0
  75ff1d:	movaps %xmm0,0x50(%rsp)
  75ff22:	movups 0xa8(%rsp),%xmm0
  75ff2a:	movaps %xmm0,0x40(%rsp)
  75ff2f:	movups 0x68(%rsp),%xmm0
  75ff34:	movups 0x78(%rsp),%xmm1
  75ff39:	movups 0x88(%rsp),%xmm2
  75ff41:	movups 0x98(%rsp),%xmm3
  75ff49:	movaps %xmm3,0x30(%rsp)
  75ff4e:	movaps %xmm2,0x20(%rsp)
  75ff53:	movaps %xmm1,0x10(%rsp)
  75ff58:	movaps %xmm0,(%rsp)
  75ff5c:	lea    -0x690339(%rip),%rdi        # cfc2a <GCC_except_table0+0xd88a>
  75ff63:	lea    0x339b7e(%rip),%rcx        # a99ae8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1310>
  75ff6a:	lea    0x339757(%rip),%r8        # a996c8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xef0>
  75ff71:	mov    %rsp,%rdx
  75ff74:	mov    $0x2b,%esi
  75ff79:	call   *0x3590c1(%rip)        # ab9040 <_DYNAMIC+0x310>
  75ff7f:	ud2
  75ff81:	mov    %rax,%rbx
  75ff84:	mov    %rsp,%rdi
  75ff87:	call   748420 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui7runtime8SetErrorNtNtCscdodAO9FK5_5alloc6string6StringEECs9C2G9YFESsD_29canonical_text_public_control>
  75ff8c:	mov    %rbx,%rdi
  75ff8f:	call   a97420 <_Unwind_Resume@plt>

canonical_text_public_control::map_transcript bytes=303 frame=136

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075ffa0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript>:
  75ffa0:	push   %r15
  75ffa2:	push   %r14
  75ffa4:	push   %r12
  75ffa6:	push   %rbx
  75ffa7:	sub    $0x68,%rsp
  75ffab:	mov    %rdi,%rsi
  75ffae:	mov    %rsp,%rdi
  75ffb1:	call   *0x359231(%rip)        # ab91e8 <_DYNAMIC+0x4b8>
  75ffb7:	mov    0x8(%rsp),%rsi
  75ffbc:	mov    0x10(%rsp),%rcx
  75ffc1:	mov    $0x1,%eax
  75ffc6:	cmp    %rsi,%rcx
  75ffc9:	jbe    75ffd7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x37>
  75ffcb:	add    $0x68,%rsp
  75ffcf:	pop    %rbx
  75ffd0:	pop    %r12
  75ffd2:	pop    %r14
  75ffd4:	pop    %r15
  75ffd6:	ret
  75ffd7:	lea    0x18(%rsp),%rbx
  75ffdc:	lea    0x30(%rsp),%r14
  75ffe1:	movabs $0x100000001b3,%r15
  75ffeb:	cmp    $0x1,%rcx
  75ffef:	je     7600b8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x118>
  75fff5:	mov    (%rsp),%rdx
  75fff9:	mov    (%rdx),%edi
  75fffb:	add    $0xc,%rdx
  75ffff:	jmp    76001c <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x7c>
  760001:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  760010:	dec    %rsi
  760013:	add    $0xc,%rdx
  760017:	cmp    %rsi,%rcx
  76001a:	ja     75ffcb <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x2b>
  76001c:	mov    %edi,%r8d
  76001f:	mov    (%rdx),%edi
  760021:	cmp    %edi,%r8d
  760024:	je     760010 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x70>
  760026:	testb  $0x2,-0x4(%rdx)
  76002a:	je     760010 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x70>
  76002c:	testb  $0x1,0x8(%rdx)
  760030:	je     760010 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x70>
  760032:	mov    %rdx,(%rsp)
  760036:	dec    %rsi
  760039:	mov    %rsi,0x8(%rsp)
  76003e:	add    $0xfffffffffffffff4,%rdx
  760042:	mov    %r14,%rdi
  760045:	mov    %rbx,%rsi
  760048:	mov    %rax,%r12
  76004b:	call   75d2f0 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control>
  760050:	mov    %r12,%rax
  760053:	mov    0x30(%rsp),%ecx
  760057:	mov    0x38(%rsp),%edx
  76005b:	mov    0x40(%rsp),%esi
  76005f:	mov    0x44(%rsp),%edi
  760063:	mov    0x48(%rsp),%r8d
  760068:	mov    0x4c(%rsp),%r9d
  76006d:	xor    %rcx,%rax
  760070:	imul   %r15,%rax
  760074:	xor    %rdx,%rax
  760077:	imul   %r15,%rax
  76007b:	xor    0x50(%rsp),%rax
  760080:	imul   %r15,%rax
  760084:	xor    %rsi,%rax
  760087:	imul   %r15,%rax
  76008b:	xor    %rdi,%rax
  76008e:	imul   %r15,%rax
  760092:	xor    %r8,%rax
  760095:	imul   %r15,%rax
  760099:	xor    %r9,%rax
  76009c:	imul   %r15,%rax
  7600a0:	mov    0x8(%rsp),%rsi
  7600a5:	mov    0x10(%rsp),%rcx
  7600aa:	cmp    %rsi,%rcx
  7600ad:	jbe    75ffeb <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x4b>
  7600b3:	jmp    75ffcb <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x2b>
  7600b8:	lea    0x338f09(%rip),%rdx        # a98fc8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x7f0>
  7600bf:	mov    $0x1,%edi
  7600c4:	mov    $0x1,%esi
  7600c9:	call   *0x358ed1(%rip)        # ab8fa0 <_DYNAMIC+0x270>

canonical_text_public_control::query_selection bytes=1157 frame=200

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007600d0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection>:
  7600d0:	push   %rbp
  7600d1:	push   %r15
  7600d3:	push   %r14
  7600d5:	push   %r13
  7600d7:	push   %r12
  7600d9:	push   %rbx
  7600da:	sub    $0x98,%rsp
  7600e1:	mov    %rsi,%r14
  7600e4:	mov    %rdi,%rbx
  7600e7:	call   *0x358f03(%rip)        # ab8ff0 <_DYNAMIC+0x2c0>
  7600ed:	test   %al,%al
  7600ef:	je     760525 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x455>
  7600f5:	mov    (%r14),%esi
  7600f8:	mov    0x8(%r14),%ecx
  7600fc:	mov    $0x1,%eax
  760101:	cmp    %esi,%ecx
  760103:	je     7604e4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x414>
  760109:	mov    %esi,%edx
  76010b:	cmova  %ecx,%edx
  76010e:	cmovb  %ecx,%esi
  760111:	mov    %rbx,%rdi
  760114:	call   *0x358ede(%rip)        # ab8ff8 <_DYNAMIC+0x2c8>
  76011a:	test   %rax,%rax
  76011d:	je     760518 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x448>
  760123:	mov    %rdx,%rcx
  760126:	movss  0x4c(%rbx),%xmm0
  76012b:	mulss  -0x69dc9b(%rip),%xmm0        # c2498 <GCC_except_table0+0xf8>
  760133:	lea    0x10(%rsp),%rdi
  760138:	mov    %rbx,%rsi
  76013b:	mov    %rax,%rdx
  76013e:	call   *0x358ebc(%rip)        # ab9000 <_DYNAMIC+0x2d0>
  760144:	mov    0x18(%rsp),%r10
  760149:	mov    0x20(%rsp),%rcx
  76014e:	mov    $0x1,%eax
  760153:	cmp    %r10,%rcx
  760156:	ja     7604e4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x414>
  76015c:	lea    0x28(%rsp),%rsi
  760161:	xor    %ebp,%ebp
  760163:	lea    0x60(%rsp),%rdi
  760168:	movabs $0x100000001b3,%r14
  760172:	mov    $0x1,%r15d
  760178:	test   $0x1,%bpl
  76017c:	je     76032b <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x25b>
  760182:	cmp    $0x1,%rcx
  760186:	je     76053e <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x46e>
  76018c:	mov    0x10(%rsp),%rdx
  760191:	mov    (%rdx),%r11d
  760194:	add    $0xc,%rdx
  760198:	jmp    7601b0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0xe0>
  76019a:	nopw   0x0(%rax,%rax,1)
  7601a0:	dec    %r10
  7601a3:	add    $0xc,%rdx
  7601a7:	cmp    %r10,%rcx
  7601aa:	ja     7604aa <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x3da>
  7601b0:	mov    %r11d,%r8d
  7601b3:	mov    (%rdx),%r11d
  7601b6:	cmp    %r11d,%r8d
  7601b9:	je     7601a0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0xd0>
  7601bb:	testb  $0x2,-0x4(%rdx)
  7601bf:	je     7601a0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0xd0>
  7601c1:	testb  $0x1,0x8(%rdx)
  7601c5:	je     7601a0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0xd0>
  7601c7:	movaps %xmm4,0x40(%rsp)
  7601cc:	movss  %xmm8,0x8(%rsp)
  7601d3:	movaps %xmm5,0x50(%rsp)
  7601d8:	movss  %xmm6,0xc(%rsp)
  7601de:	mov    %r9,%rbx
  7601e1:	mov    %rax,%r12
  7601e4:	mov    %rdx,0x10(%rsp)
  7601e9:	dec    %r10
  7601ec:	mov    %r10,0x18(%rsp)
  7601f1:	add    $0xfffffffffffffff4,%rdx
  7601f5:	mov    %rdi,%r13
  7601f8:	mov    %rsi,%r14
  7601fb:	call   75d2f0 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control>
  760200:	xorps  %xmm0,%xmm0
  760203:	movss  0x78(%rsp),%xmm1
  760209:	ucomiss %xmm0,%xmm1
  76020c:	jne    760242 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x172>
  76020e:	jp     760242 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x172>
  760210:	mov    %r12,%rax
  760213:	mov    %rbx,%r9
  760216:	mov    %r14,%rsi
  760219:	mov    %r13,%rdi
  76021c:	movabs $0x100000001b3,%r14
  760226:	movss  0xc(%rsp),%xmm6
  76022c:	movaps 0x50(%rsp),%xmm5
  760231:	movss  0x8(%rsp),%xmm8
  760238:	movaps 0x40(%rsp),%xmm4
  76023d:	jmp    760313 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x243>
  760242:	movss  0x70(%rsp),%xmm0
  760248:	movss  0x74(%rsp),%xmm2
  76024e:	movss  0x7c(%rsp),%xmm3
  760254:	mov    0x80(%rsp),%rdx
  76025c:	mov    %rbx,%r9
  76025f:	cmp    %rdx,%rbx
  760262:	movss  0xc(%rsp),%xmm6
  760268:	movaps 0x50(%rsp),%xmm7
  76026d:	movss  0x8(%rsp),%xmm8
  760274:	movaps 0x40(%rsp),%xmm9
  76027a:	jne    760498 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x3c8>
  760280:	ucomiss %xmm2,%xmm8
  760284:	mov    %r14,%rsi
  760287:	mov    %r13,%rdi
  76028a:	movabs $0x100000001b3,%r14
  760294:	jne    760437 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x367>
  76029a:	jp     760437 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x367>
  7602a0:	ucomiss %xmm3,%xmm6
  7602a3:	jne    760437 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x367>
  7602a9:	jp     760437 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x367>
  7602af:	movaps %xmm0,%xmm5
  7602b2:	addss  %xmm1,%xmm5
  7602b6:	ucomiss %xmm9,%xmm5
  7602ba:	jb     760434 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x364>
  7602c0:	movaps %xmm7,%xmm4
  7602c3:	addss  %xmm9,%xmm4
  7602c8:	ucomiss %xmm0,%xmm4
  7602cb:	jb     760434 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x364>
  7602d1:	mov    %r12,%rax
  7602d4:	movaps %xmm4,%xmm1
  7602d7:	maxss  %xmm5,%xmm1
  7602db:	movaps %xmm1,%xmm5
  7602de:	cmpunordss %xmm1,%xmm5
  7602e3:	movaps %xmm5,%xmm2
  7602e6:	andnps %xmm1,%xmm2
  7602e9:	andps  %xmm4,%xmm5
  7602ec:	orps   %xmm2,%xmm5
  7602ef:	movaps %xmm9,%xmm1
  7602f3:	minss  %xmm0,%xmm1
  7602f7:	movaps %xmm1,%xmm0
  7602fa:	cmpunordss %xmm1,%xmm0
  7602ff:	movaps %xmm0,%xmm2
  760302:	andnps %xmm1,%xmm2
  760305:	andps  %xmm9,%xmm0
  760309:	orps   %xmm2,%xmm0
  76030c:	subss  %xmm0,%xmm5
  760310:	movaps %xmm0,%xmm4
  760313:	mov    0x18(%rsp),%r10
  760318:	mov    0x20(%rsp),%rcx
  76031d:	cmp    %r10,%rcx
  760320:	jbe    760182 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0xb2>
  760326:	jmp    7604f6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x426>
  76032b:	cmp    $0x1,%rcx
  76032f:	je     76053e <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x46e>
  760335:	mov    0x10(%rsp),%rdx
  76033a:	mov    (%rdx),%r11d
  76033d:	add    $0xc,%rdx
  760341:	jmp    760360 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x290>
  760343:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  760350:	dec    %r10
  760353:	add    $0xc,%rdx
  760357:	cmp    %r10,%rcx
  76035a:	ja     7604aa <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x3da>
  760360:	mov    %r11d,%r8d
  760363:	mov    (%rdx),%r11d
  760366:	cmp    %r11d,%r8d
  760369:	je     760350 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x280>
  76036b:	testb  $0x2,-0x4(%rdx)
  76036f:	je     760350 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x280>
  760371:	testb  $0x1,0x8(%rdx)
  760375:	je     760350 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x280>
  760377:	movaps %xmm4,0x40(%rsp)
  76037c:	movss  %xmm8,0x8(%rsp)
  760383:	movaps %xmm5,0x50(%rsp)
  760388:	movss  %xmm6,0xc(%rsp)
  76038e:	mov    %r9,%rbx
  760391:	mov    %rax,%r12
  760394:	mov    %rdx,0x10(%rsp)
  760399:	dec    %r10
  76039c:	mov    %r10,0x18(%rsp)
  7603a1:	add    $0xfffffffffffffff4,%rdx
  7603a5:	mov    %rdi,%r13
  7603a8:	mov    %rsi,%r14
  7603ab:	call   75d2f0 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control>
  7603b0:	xorps  %xmm0,%xmm0
  7603b3:	movss  0x78(%rsp),%xmm1
  7603b9:	ucomiss %xmm0,%xmm1
  7603bc:	jne    760405 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x335>
  7603be:	jp     760405 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x335>
  7603c0:	mov    0x18(%rsp),%r10
  7603c5:	mov    0x20(%rsp),%rcx
  7603ca:	cmp    %r10,%rcx
  7603cd:	mov    %r12,%rax
  7603d0:	mov    %rbx,%r9
  7603d3:	mov    %r14,%rsi
  7603d6:	mov    %r13,%rdi
  7603d9:	movabs $0x100000001b3,%r14
  7603e3:	movss  0xc(%rsp),%xmm6
  7603e9:	movaps 0x50(%rsp),%xmm5
  7603ee:	movss  0x8(%rsp),%xmm8
  7603f5:	movaps 0x40(%rsp),%xmm4
  7603fa:	jbe    76032b <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x25b>
  760400:	jmp    7604e4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x414>
  760405:	movss  0x70(%rsp),%xmm0
  76040b:	movss  0x74(%rsp),%xmm2
  760411:	movss  0x7c(%rsp),%xmm3
  760417:	mov    0x80(%rsp),%rdx
  76041f:	mov    %r12,%rax
  760422:	mov    %r14,%rsi
  760425:	mov    %r13,%rdi
  760428:	movabs $0x100000001b3,%r14
  760432:	jmp    760470 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x3a0>
  760434:	mov    %r9,%rdx
  760437:	movd   %xmm9,%ecx
  76043c:	movd   %xmm8,%r8d
  760441:	movd   %xmm7,%r10d
  760446:	movd   %xmm6,%eax
  76044a:	xor    %rcx,%r15
  76044d:	imul   %r14,%r15
  760451:	xor    %r15,%r8
  760454:	imul   %r14,%r8
  760458:	xor    %r8,%r10
  76045b:	imul   %r14,%r10
  76045f:	xor    %r10,%rax
  760462:	imul   %r14,%rax
  760466:	xor    %r9,%rax
  760469:	imul   %r14,%rax
  76046d:	mov    %rax,%r15
  760470:	mov    0x18(%rsp),%r10
  760475:	mov    0x20(%rsp),%rcx
  76047a:	mov    $0x1,%bpl
  76047d:	mov    %rdx,%r9
  760480:	movaps %xmm3,%xmm6
  760483:	movaps %xmm1,%xmm5
  760486:	movaps %xmm2,%xmm8
  76048a:	movaps %xmm0,%xmm4
  76048d:	cmp    %r10,%rcx
  760490:	jbe    760178 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0xa8>
  760496:	jmp    760506 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x436>
  760498:	mov    %r14,%rsi
  76049b:	mov    %r13,%rdi
  76049e:	movabs $0x100000001b3,%r14
  7604a8:	jmp    760437 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x367>
  7604aa:	test   $0x1,%bpl
  7604ae:	je     7604e4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x414>
  7604b0:	movd   %xmm4,%ecx
  7604b4:	movd   %xmm8,%edx
  7604b9:	movd   %xmm5,%esi
  7604bd:	xor    %rax,%rcx
  7604c0:	movd   %xmm6,%eax
  7604c4:	imul   %r14,%rcx
  7604c8:	xor    %rcx,%rdx
  7604cb:	imul   %r14,%rdx
  7604cf:	xor    %rdx,%rsi
  7604d2:	imul   %r14,%rsi
  7604d6:	xor    %rsi,%rax
  7604d9:	imul   %r14,%rax
  7604dd:	xor    %r9,%rax
  7604e0:	imul   %r14,%rax
  7604e4:	add    $0x98,%rsp
  7604eb:	pop    %rbx
  7604ec:	pop    %r12
  7604ee:	pop    %r13
  7604f0:	pop    %r14
  7604f2:	pop    %r15
  7604f4:	pop    %rbp
  7604f5:	ret
  7604f6:	movaps %xmm8,%xmm2
  7604fa:	movaps %xmm6,%xmm3
  7604fd:	mov    %r9,%rdx
  760500:	movaps %xmm4,%xmm0
  760503:	movaps %xmm5,%xmm1
  760506:	movaps %xmm1,%xmm5
  760509:	movaps %xmm0,%xmm4
  76050c:	mov    %rdx,%r9
  76050f:	movaps %xmm3,%xmm6
  760512:	movaps %xmm2,%xmm8
  760516:	jmp    7604b0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x3e0>
  760518:	lea    0x338309(%rip),%rdi        # a98828 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x50>
  76051f:	call   *0x358af3(%rip)        # ab9018 <_DYNAMIC+0x2e8>
  760525:	lea    -0x690ad8(%rip),%rdi        # cfa54 <GCC_except_table0+0xd6b4>
  76052c:	lea    0x3391ad(%rip),%rdx        # a996e0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xf08>
  760533:	mov    $0x73,%esi
  760538:	call   *0x358aaa(%rip)        # ab8fe8 <_DYNAMIC+0x2b8>
  76053e:	lea    0x338a83(%rip),%rdx        # a98fc8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x7f0>
  760545:	mov    $0x1,%edi
  76054a:	mov    $0x1,%esi
  76054f:	call   *0x358a4b(%rip)        # ab8fa0 <_DYNAMIC+0x270>

canonical_text_public_control::ack bytes=358 frame=136

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000760560 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack>:
  760560:	push   %r14
  760562:	push   %rbx
  760563:	sub    $0x78,%rsp
  760567:	test   %rsi,%rsi
  76056a:	je     760614 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack+0xb4>
  760570:	cmpb   $0x0,0x76e(%rsi)
  760577:	jne    76061b <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack+0xbb>
  76057d:	mov    0x6d0(%rsi),%rdx
  760584:	test   %rdx,%rdx
  760587:	je     760622 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack+0xc2>
  76058d:	mov    %rdi,%rbx
  760590:	mov    0x6d8(%rsi),%rcx
  760597:	lea    0x8(%rsp),%rdi
  76059c:	call   77aeb0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_>
  7605a1:	cmpq   $0xfffffffffffffffe,0x8(%rsp)
  7605a7:	jne    76065f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack+0xff>
  7605ad:	movups 0x10(%rsp),%xmm0
  7605b2:	movups 0x20(%rsp),%xmm1
  7605b7:	movups 0x30(%rsp),%xmm2
  7605bc:	movups %xmm2,0x20(%rbx)
  7605c0:	movups %xmm1,0x10(%rbx)
  7605c4:	movups %xmm0,(%rbx)
  7605c7:	cmpb   $0x0,0x28(%rbx)
  7605cb:	je     7605df <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack+0x7f>
  7605cd:	mov    0x10(%rbx),%rax
  7605d1:	cmp    0x18(%rbx),%rax
  7605d5:	jne    7605f8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack+0x98>
  7605d7:	add    $0x78,%rsp
  7605db:	pop    %rbx
  7605dc:	pop    %r14
  7605de:	ret
  7605df:	lea    -0x690b1f(%rip),%rdi        # cfac7 <GCC_except_table0+0xd727>
  7605e6:	lea    0x33913b(%rip),%rdx        # a99728 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xf50>
  7605ed:	mov    $0x2b,%esi
  7605f2:	call   *0x3589f0(%rip)        # ab8fe8 <_DYNAMIC+0x2b8>
  7605f8:	lea    0x10(%rbx),%rsi
  7605fc:	add    $0x18,%rbx
  760600:	lea    0x339139(%rip),%r9        # a99740 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xf68>
  760607:	xor    %edi,%edi
  760609:	mov    %rbx,%rdx
  76060c:	xor    %ecx,%ecx
  76060e:	call   *0x358bdc(%rip)        # ab91f0 <_DYNAMIC+0x4c0>
  760614:	mov    $0xd,%eax
  760619:	jmp    760627 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack+0xc7>
  76061b:	mov    $0xe,%eax
  760620:	jmp    760627 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack+0xc7>
  760622:	mov    $0x14,%eax
  760627:	mov    %rax,0x40(%rsp)
  76062c:	movq   $0x0,0x48(%rsp)
  760635:	lea    -0x690a12(%rip),%rdi        # cfc2a <GCC_except_table0+0xd88a>
  76063c:	lea    0x339425(%rip),%rcx        # a99a68 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1290>
  760643:	lea    0x3390ae(%rip),%r8        # a996f8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xf20>
  76064a:	lea    0x40(%rsp),%rbx
  76064f:	mov    $0x2b,%esi
  760654:	mov    %rbx,%rdx
  760657:	call   *0x3589e3(%rip)        # ab9040 <_DYNAMIC+0x310>
  76065d:	jmp    7606af <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack+0x14f>
  76065f:	mov    0x38(%rsp),%rax
  760664:	mov    %rax,0x70(%rsp)
  760669:	movups 0x8(%rsp),%xmm0
  76066e:	movups 0x18(%rsp),%xmm1
  760673:	movups 0x28(%rsp),%xmm2
  760678:	movaps %xmm2,0x60(%rsp)
  76067d:	movaps %xmm1,0x50(%rsp)
  760682:	movaps %xmm0,0x40(%rsp)
  760687:	lea    -0x690a64(%rip),%rdi        # cfc2a <GCC_except_table0+0xd88a>
  76068e:	lea    0x3393d3(%rip),%rcx        # a99a68 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1290>
  760695:	lea    0x339074(%rip),%r8        # a99710 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xf38>
  76069c:	lea    0x40(%rsp),%rbx
  7606a1:	mov    $0x2b,%esi
  7606a6:	mov    %rbx,%rdx
  7606a9:	call   *0x358991(%rip)        # ab9040 <_DYNAMIC+0x310>
  7606af:	ud2
  7606b1:	jmp    7606b3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack+0x153>
  7606b3:	mov    %rax,%r14
  7606b6:	mov    %rbx,%rdi
  7606b9:	call   74d580 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  7606be:	mov    %r14,%rdi
  7606c1:	call   a97420 <_Unwind_Resume@plt>

canonical_text_public_control::run bytes=9049 frame=888

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007606d0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run>:
  7606d0:	push   %rbp
  7606d1:	push   %r15
  7606d3:	push   %r14
  7606d5:	push   %r13
  7606d7:	push   %r12
  7606d9:	push   %rbx
  7606da:	sub    $0x348,%rsp
  7606e1:	mov    %rsi,0x2b0(%rsp)
  7606e9:	mov    %rdx,0x2b8(%rsp)
  7606f1:	mov    %rcx,0x288(%rsp)
  7606f9:	mov    %r8,0x290(%rsp)
  760701:	test   %r9,%r9
  760704:	je     762185 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1ab5>
  76070a:	mov    %rdx,%r12
  76070d:	mov    %rsi,%r15
  760710:	mov    %r9,0x138(%rsp)
  760718:	mov    %rdi,0x298(%rsp)
  760720:	lea    0x228(%rsp),%rbx
  760728:	mov    %rbx,%rdi
  76072b:	call   765890 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source>
  760730:	lea    0x148(%rsp),%r14
  760738:	mov    %r14,%rdi
  76073b:	mov    %rbx,%rsi
  76073e:	call   *0x358ab4(%rip)        # ab91f8 <_DYNAMIC+0x4c8>
  760744:	cmpq   $0x0,0x238(%rsp)
  76074d:	je     7607ef <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x11f>
  760753:	mov    0x230(%rsp),%rcx
  76075b:	movzbl (%rcx),%edi
  76075e:	mov    $0x1,%esi
  760763:	test   %dil,%dil
  760766:	js     761930 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1260>
  76076c:	mov    0x158(%rsp),%rdx
  760774:	mov    %rdx,%rax
  760777:	sub    %rsi,%rax
  76077a:	jb     76224e <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1b7e>
  760780:	mov    0x150(%rsp),%rcx
  760788:	jbe    760794 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xc4>
  76078a:	cmpb   $0xc0,(%rcx,%rsi,1)
  76078e:	jl     762287 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1bb7>
  760794:	movq   $0x0,0x158(%rsp)
  7607a0:	mov    %rcx,0x70(%rsp)
  7607a5:	add    %rsi,%rcx
  7607a8:	mov    %rcx,0x78(%rsp)
  7607ad:	mov    %r14,0x80(%rsp)
  7607b5:	mov    %rsi,0x88(%rsp)
  7607bd:	mov    %rax,0x90(%rsp)
  7607c5:	lea    -0x690cbf(%rip),%rax        # cfb0d <GCC_except_table0+0xd76d>
  7607cc:	mov    %rax,0x98(%rsp)
  7607d4:	lea    -0x690ccd(%rip),%rax        # cfb0e <GCC_except_table0+0xd76e>
  7607db:	mov    %rax,0xa0(%rsp)
  7607e3:	lea    0x70(%rsp),%rdi
  7607e8:	call   748e70 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtCscdodAO9FK5_5alloc3vec6splice6SpliceNtNtNtB4_3str4iter5BytesEECs9C2G9YFESsD_29canonical_text_public_control>
  7607ed:	jmp    76081c <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x14c>
  7607ef:	mov    0x158(%rsp),%rbx
  7607f7:	cmp    %rbx,0x148(%rsp)
  7607ff:	je     762262 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1b92>
  760805:	mov    0x150(%rsp),%rax
  76080d:	movb   $0x62,(%rax,%rbx,1)
  760811:	inc    %rbx
  760814:	mov    %rbx,0x158(%rsp)
  76081c:	lea    0x240(%rsp),%rdi
  760824:	lea    0x228(%rsp),%rsi
  76082c:	call   *0x3589c6(%rip)        # ab91f8 <_DYNAMIC+0x4c8>
  760832:	mov    %r12,0x128(%rsp)
  76083a:	mov    %r15,0x160(%rsp)
  760842:	mov    $0x1,%bpl
  760845:	lea    0x70(%rsp),%rdi
  76084a:	call   *0x3589b0(%rip)        # ab9200 <_DYNAMIC+0x4d0>
  760850:	cmpl   $0x1,0x70(%rsp)
  760855:	je     76219e <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1ace>
  76085b:	mov    0x78(%rsp),%rax
  760860:	mov    %rax,0x140(%rsp)
  760868:	lea    0x140(%rsp),%rax
  760870:	mov    %rax,0x30(%rsp)
  760875:	movq   $0x0,0x38(%rsp)
  76087e:	mov    0x230(%rsp),%rdx
  760886:	mov    0x238(%rsp),%rcx
  76088e:	lea    0x70(%rsp),%rdi
  760893:	lea    0x30(%rsp),%rsi
  760898:	movss  -0x69e404(%rip),%xmm0        # c249c <GCC_except_table0+0xfc>
  7608a0:	movss  -0x69e42c(%rip),%xmm1        # c247c <GCC_except_table0+0xdc>
  7608a8:	mov    $0x1,%r8d
  7608ae:	call   *0x358954(%rip)        # ab9208 <_DYNAMIC+0x4d8>
  7608b4:	cmpq   $0xffffffffffffffff,0x70(%rsp)
  7608ba:	je     7621d2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1b02>
  7608c0:	mov    0xa0(%rsp),%rax
  7608c8:	mov    %rax,0x340(%rsp)
  7608d0:	movups 0x70(%rsp),%xmm0
  7608d5:	movups 0x80(%rsp),%xmm1
  7608dd:	movups 0x90(%rsp),%xmm2
  7608e5:	movaps %xmm2,0x330(%rsp)
  7608ed:	movaps %xmm1,0x320(%rsp)
  7608f5:	movaps %xmm0,0x310(%rsp)
  7608fd:	mov    0x38(%rsp),%rdi
  760902:	call   74caf0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text10TextShaperECs9C2G9YFESsD_29canonical_text_public_control>
  760907:	mov    0x330(%rsp),%rsi
  76090f:	test   %rsi,%rsi
  760912:	je     76220c <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1b3c>
  760918:	add    $0x10,%rsi
  76091c:	lea    0x258(%rsp),%rdi
  760924:	mov    %rsi,0xf0(%rsp)
  76092c:	call   *0x3588b6(%rip)        # ab91e8 <_DYNAMIC+0x4b8>
  760932:	mov    0x260(%rsp),%rax
  76093a:	mov    0x268(%rsp),%rcx
  760942:	cmp    %rax,%rcx
  760945:	jbe    760e61 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x791>
  76094b:	mov    $0x4,%eax
  760950:	mov    $0x8,%ecx
  760955:	xor    %edx,%edx
  760957:	xor    %r12d,%r12d
  76095a:	mov    %rdx,0x108(%rsp)
  760962:	mov    %rcx,0x20(%rsp)
  760967:	mov    %r12,0x168(%rsp)
  76096f:	mov    %rax,0x170(%rsp)
  760977:	mov    %r12,0x178(%rsp)
  76097f:	mov    0x238(%rsp),%rax
  760987:	mov    %rax,0x118(%rsp)
  76098f:	shr    $0x20,%rax
  760993:	jne    76221e <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1b4e>
  760999:	mov    %r12,0x130(%rsp)
  7609a1:	mov    $0x1,%bpl
  7609a4:	lea    0x168(%rsp),%rdi
  7609ac:	call   7720d0 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtCslbxve4rcJus_4gpui7runtime6ParentE8grow_oneCs9C2G9YFESsD_29canonical_text_public_control>
  7609b1:	mov    0x170(%rsp),%rax
  7609b9:	mov    0x130(%rsp),%rcx
  7609c1:	mov    0x118(%rsp),%rdx
  7609c9:	mov    %edx,(%rax,%rcx,4)
  7609cc:	lea    0x1(%rcx),%rax
  7609d0:	mov    %rax,0x178(%rsp)
  7609d8:	xor    %ebp,%ebp
  7609da:	lea    0x228(%rsp),%rdi
  7609e2:	call   764d90 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount>
  7609e7:	mov    %rax,%rbx
  7609ea:	mov    %rax,0x10(%rsp)
  7609ef:	cmpb   $0x0,0x76e(%rax)
  7609f6:	jne    76253c <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1e6c>
  7609fc:	cmpb   $0x1,0x76a(%rbx)
  760a03:	jne    762543 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1e73>
  760a09:	mov    0x5c0(%rbx),%r12
  760a10:	mov    $0x1a,%eax
  760a15:	mov    %rax,0x8(%rsp)
  760a1a:	test   %r12,%r12
  760a1d:	je     76254d <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1e7d>
  760a23:	mov    0x5b8(%rbx),%r13
  760a2a:	shl    $0x6,%r12
  760a2e:	lea    0x1e8(%rbx),%r14
  760a35:	xor    %ebp,%ebp
  760a37:	mov    0x3585f2(%rip),%r15        # ab9030 <_DYNAMIC+0x300>
  760a3e:	jmp    760a4d <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x37d>
  760a40:	add    $0x40,%rbp
  760a44:	cmp    %rbp,%r12
  760a47:	je     76254d <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1e7d>
  760a4d:	cmpb   $0x4,0x3d(%r13,%rbp,1)
  760a53:	jne    760a40 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x370>
  760a55:	mov    0x20(%r13,%rbp,1),%rsi
  760a5a:	mov    %r14,%rdi
  760a5d:	call   *%r15
  760a60:	test   %al,%al
  760a62:	je     760a40 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x370>
  760a64:	mov    0x20(%r13,%rbp,1),%rsi
  760a69:	add    $0x5f0,%rbx
  760a70:	mov    %rbx,%rdi
  760a73:	call   *0x358757(%rip)        # ab91d0 <_DYNAMIC+0x4a0>
  760a79:	mov    %rax,0x120(%rsp)
  760a81:	mov    %rdx,0x100(%rsp)
  760a89:	mov    0x10(%rsp),%rsi
  760a8e:	movq   $0x0,0x1f8(%rsp)
  760a9a:	movq   $0x4,0x200(%rsp)
  760aa6:	movq   $0x0,0x208(%rsp)
  760ab2:	test   %rsi,%rsi
  760ab5:	mov    0xf0(%rsp),%rbx
  760abd:	je     762581 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1eb1>
  760ac3:	cmpb   $0x0,0x76e(%rsi)
  760aca:	jne    762588 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1eb8>
  760ad0:	cmpb   $0x1,0x76c(%rsi)
  760ad7:	jne    76258f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1ebf>
  760add:	lea    0x70(%rsp),%rdi
  760ae2:	call   73dc80 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime5queryNtB3_7Context3newNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEBX_>
  760ae7:	mov    0xa8(%rsp),%r14
  760aef:	mov    $0x4,%eax
  760af4:	test   %r14,%r14
  760af7:	je     761082 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x9b2>
  760afd:	mov    %rax,0xf8(%rsp)
  760b05:	movq   $0x0,0x28(%rsp)
  760b0e:	lea    0x3381fb(%rip),%rax        # a98d10 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x538>
  760b15:	mov    %rax,0x110(%rsp)
  760b1d:	xor    %ebx,%ebx
  760b1f:	mov    %r14,0x8(%rsp)
  760b24:	jmp    760b4a <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x47a>
  760b26:	cs nopw 0x0(%rax,%rax,1)
  760b30:	test   %r12,%r12
  760b33:	jne    762441 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1d71>
  760b39:	mov    0x8(%rsp),%r14
  760b3e:	inc    %rbx
  760b41:	cmp    %r14,%rbx
  760b44:	je     760e37 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x767>
  760b4a:	mov    0xa8(%rsp),%rsi
  760b52:	cmp    %rsi,%rbx
  760b55:	jae    76245a <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1d8a>
  760b5b:	mov    0xa0(%rsp),%rax
  760b63:	mov    %rbx,%rcx
  760b66:	shl    $0x6,%rcx
  760b6a:	cmpb   $0x4,0x3d(%rax,%rcx,1)
  760b6f:	jne    760b3e <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x46e>
  760b71:	lea    0x30(%rsp),%rdi
  760b76:	lea    0x70(%rsp),%rsi
  760b7b:	mov    %rbx,%rdx
  760b7e:	call   *0x3585f4(%rip)        # ab9178 <_DYNAMIC+0x448>
  760b84:	cmpq   $0x0,0x30(%rsp)
  760b8a:	je     76215c <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1a8c>
  760b90:	movups 0x30(%rsp),%xmm0
  760b95:	movaps %xmm0,0x2a0(%rsp)
  760b9d:	mov    0x40(%rsp),%rbp
  760ba2:	mov    0x48(%rsp),%r15
  760ba7:	lea    0x258(%rsp),%rdi
  760baf:	mov    %rbp,%rsi
  760bb2:	call   *0x358630(%rip)        # ab91e8 <_DYNAMIC+0x4b8>
  760bb8:	movups 0x258(%rsp),%xmm0
  760bc0:	movups 0x268(%rsp),%xmm1
  760bc8:	movups 0x278(%rsp),%xmm2
  760bd0:	movaps %xmm1,0x190(%rsp)
  760bd8:	movaps %xmm0,0x180(%rsp)
  760be0:	movaps %xmm2,0x1a0(%rsp)
  760be8:	mov    0x190(%rsp),%r13
  760bf0:	mov    0x188(%rsp),%r12
  760bf8:	cmp    $0x1,%r13
  760bfc:	je     760b30 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x460>
  760c02:	mov    0x180(%rsp),%r14
  760c0a:	mov    $0x2,%eax
  760c0f:	dec    %rax
  760c12:	mov    %rax,0x1b0(%rsp)
  760c1a:	cmp    %r12,%r13
  760c1d:	ja     760b39 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x469>
  760c23:	add    $0xc,%r14
  760c27:	jmp    760c40 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x570>
  760c29:	nopl   0x0(%rax)
  760c30:	dec    %r12
  760c33:	add    $0xc,%r14
  760c37:	cmp    %r12,%r13
  760c3a:	ja     760b39 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x469>
  760c40:	mov    -0xc(%r14),%eax
  760c44:	cmp    (%r14),%eax
  760c47:	je     760c30 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x560>
  760c49:	testb  $0x2,-0x4(%r14)
  760c4e:	je     760c30 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x560>
  760c50:	testb  $0x1,0x8(%r14)
  760c55:	je     760c30 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x560>
  760c57:	lea    -0xc(%r14),%rdx
  760c5b:	lea    0x30(%rsp),%rdi
  760c60:	lea    0x198(%rsp),%rsi
  760c68:	mov    %r13,%rcx
  760c6b:	call   75d2f0 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control>
  760c70:	cmpb   $0x1,0x60(%rsp)
  760c75:	je     760c30 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x560>
  760c77:	movzbl 0x34(%rsp),%eax
  760c7c:	lea    0x35(%rsp),%rcx
  760c81:	movups (%rcx),%xmm0
  760c84:	movups 0x10(%rcx),%xmm1
  760c88:	movups 0x1b(%rcx),%xmm2
  760c8c:	movaps %xmm0,0x1c0(%rsp)
  760c94:	movaps %xmm1,0x1d0(%rsp)
  760c9c:	movups %xmm2,0x1db(%rsp)
  760ca4:	cmp    $0x2,%al
  760ca6:	je     760c30 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x560>
  760ca8:	movups 0x1db(%rsp),%xmm0
  760cb0:	movups %xmm0,0x2fb(%rsp)
  760cb8:	movaps 0x1c0(%rsp),%xmm0
  760cc0:	movaps 0x1d0(%rsp),%xmm1
  760cc8:	movaps %xmm1,0x2f0(%rsp)
  760cd0:	movaps %xmm0,0x2e0(%rsp)
  760cd8:	lea    0x2e8(%rsp),%rax
  760ce0:	movups (%rax),%xmm0
  760ce3:	movaps %xmm0,0x2c0(%rsp)
  760ceb:	mov    0xf(%rax),%eax
  760cee:	mov    %eax,0x2cf(%rsp)
  760cf5:	lea    0x2c3(%rsp),%rax
  760cfd:	movups (%rax),%xmm0
  760d00:	movaps %xmm0,0x2e0(%rsp)
  760d08:	movaps 0x2a0(%rsp),%xmm0
  760d10:	movaps %xmm0,0x30(%rsp)
  760d15:	mov    %rbp,0x40(%rsp)
  760d1a:	mov    %r15,0x48(%rsp)
  760d1f:	lea    0x1c0(%rsp),%rdi
  760d27:	lea    0x30(%rsp),%rsi
  760d2c:	lea    0x2e0(%rsp),%rdx
  760d34:	call   *0x3584d6(%rip)        # ab9210 <_DYNAMIC+0x4e0>
  760d3a:	cmpb   $0x0,0x1c0(%rsp)
  760d42:	je     7622a5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1bd5>
  760d48:	movsd  0x1c4(%rsp),%xmm1
  760d51:	movsd  0x1cc(%rsp),%xmm0
  760d5a:	mulps  -0x69d6d1(%rip),%xmm0        # c3690 <GCC_except_table0+0x12f0>
  760d61:	addps  %xmm1,%xmm0
  760d64:	movaps %xmm0,%xmm1
  760d67:	shufps $0x55,%xmm0,%xmm1
  760d6b:	movaps 0x2a0(%rsp),%xmm2
  760d73:	movaps %xmm2,0x30(%rsp)
  760d78:	mov    %rbp,0x40(%rsp)
  760d7d:	mov    %r15,0x48(%rsp)
  760d82:	lea    0x30(%rsp),%rdi
  760d87:	movaps %xmm0,0x210(%rsp)
  760d8f:	call   *0x358483(%rip)        # ab9218 <_DYNAMIC+0x4e8>
  760d95:	mov    %eax,0x1b8(%rsp)
  760d9c:	mov    %dl,0x1f(%rsp)
  760da0:	cmp    $0x2,%dl
  760da3:	je     7622b1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1be1>
  760da9:	mov    0x28(%rsp),%rax
  760dae:	cmp    0x1f8(%rsp),%rax
  760db6:	jne    760dd5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x705>
  760db8:	lea    0x1f8(%rsp),%rdi
  760dc0:	call   771e30 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtCscO85OU7Wpt0_20gpui_reactivity_core8geometry4RectE8grow_oneCs9C2G9YFESsD_29canonical_text_public_control>
  760dc5:	mov    0x200(%rsp),%rax
  760dcd:	mov    %rax,0xf8(%rsp)
  760dd5:	dec    %r12
  760dd8:	movzbl 0x1f(%rsp),%esi
  760ddd:	and    $0x1,%sil
  760de1:	mov    0x28(%rsp),%rcx
  760de6:	mov    %rcx,%rax
  760de9:	shl    $0x4,%rax
  760ded:	mov    0xf8(%rsp),%rdx
  760df5:	movaps 0x210(%rsp),%xmm0
  760dfd:	movlps %xmm0,(%rdx,%rax,1)
  760e01:	mov    0x1b8(%rsp),%edi
  760e08:	mov    %edi,0x8(%rdx,%rax,1)
  760e0c:	mov    %sil,0xc(%rdx,%rax,1)
  760e11:	inc    %rcx
  760e14:	mov    %rcx,0x28(%rsp)
  760e19:	mov    %rcx,0x208(%rsp)
  760e21:	mov    0x1b0(%rsp),%rax
  760e29:	test   %rax,%rax
  760e2c:	jne    760c0f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x53f>
  760e32:	jmp    760b39 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x469>
  760e37:	mov    0x1f8(%rsp),%rax
  760e3f:	mov    %rax,0x110(%rsp)
  760e47:	mov    0x200(%rsp),%rax
  760e4f:	mov    %rax,0x8(%rsp)
  760e54:	mov    0xf0(%rsp),%rbx
  760e5c:	jmp    76109c <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x9cc>
  760e61:	cmp    $0x1,%rcx
  760e65:	je     7625d8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1f08>
  760e6b:	mov    0x258(%rsp),%rdx
  760e73:	mov    (%rdx),%esi
  760e75:	add    $0xc,%rdx
  760e79:	jmp    760e90 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x7c0>
  760e7b:	nopl   0x0(%rax,%rax,1)
  760e80:	dec    %rax
  760e83:	add    $0xc,%rdx
  760e87:	cmp    %rax,%rcx
  760e8a:	ja     76094b <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x27b>
  760e90:	mov    %esi,%edi
  760e92:	mov    (%rdx),%esi
  760e94:	cmp    %esi,%edi
  760e96:	je     760e80 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x7b0>
  760e98:	testb  $0x2,-0x4(%rdx)
  760e9c:	je     760e80 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x7b0>
  760e9e:	testb  $0x1,0x8(%rdx)
  760ea2:	je     760e80 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x7b0>
  760ea4:	mov    %rdx,0x258(%rsp)
  760eac:	dec    %rax
  760eaf:	mov    %rax,0x260(%rsp)
  760eb7:	lea    0x270(%rsp),%rsi
  760ebf:	add    $0xfffffffffffffff4,%rdx
  760ec3:	lea    0x30(%rsp),%rdi
  760ec8:	call   75d2f0 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control>
  760ecd:	cmpb   $0x2,0x34(%rsp)
  760ed2:	je     76094b <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x27b>
  760ed8:	call   *0x35809a(%rip)        # ab8f78 <_DYNAMIC+0x248>
  760ede:	mov    $0xe0,%edi
  760ee3:	mov    $0x8,%esi
  760ee8:	call   *0x358092(%rip)        # ab8f80 <_DYNAMIC+0x250>
  760eee:	test   %rax,%rax
  760ef1:	je     7626ef <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x201f>
  760ef7:	mov    0x60(%rsp),%rcx
  760efc:	mov    %rcx,0x30(%rax)
  760f00:	movups 0x30(%rsp),%xmm0
  760f05:	movups 0x40(%rsp),%xmm1
  760f0a:	movups 0x50(%rsp),%xmm2
  760f0f:	movups %xmm2,0x20(%rax)
  760f13:	movups %xmm1,0x10(%rax)
  760f17:	movups %xmm0,(%rax)
  760f1a:	movq   $0x4,0x1c0(%rsp)
  760f26:	mov    %rax,0x20(%rsp)
  760f2b:	mov    %rax,0x1c8(%rsp)
  760f33:	movq   $0x1,0x1d0(%rsp)
  760f3f:	movups 0x258(%rsp),%xmm0
  760f47:	movups 0x268(%rsp),%xmm1
  760f4f:	movups 0x278(%rsp),%xmm2
  760f57:	movaps %xmm2,0x1a0(%rsp)
  760f5f:	movaps %xmm1,0x190(%rsp)
  760f67:	movaps %xmm0,0x180(%rsp)
  760f6f:	mov    0x190(%rsp),%rcx
  760f77:	mov    0x188(%rsp),%rax
  760f7f:	mov    $0x1,%r12d
  760f85:	cmp    %rax,%rcx
  760f88:	jbe    761fb9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x18e9>
  760f8e:	mov    0x1c0(%rsp),%rax
  760f96:	mov    %rax,0x108(%rsp)
  760f9e:	lea    0x0(,%r12,4),%rbx
  760fa6:	call   *0x357fcc(%rip)        # ab8f78 <_DYNAMIC+0x248>
  760fac:	mov    $0x4,%esi
  760fb1:	mov    %rbx,%rdi
  760fb4:	call   *0x357fc6(%rip)        # ab8f80 <_DYNAMIC+0x250>
  760fba:	test   %rax,%rax
  760fbd:	je     762701 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2031>
  760fc3:	cmp    $0x14,%r12
  760fc7:	jb     760fef <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x91f>
  760fc9:	imul   $0x38,%r12,%rcx
  760fcd:	mov    0x20(%rsp),%rsi
  760fd2:	add    %rsi,%rcx
  760fd5:	add    $0xffffffffffffffcc,%rcx
  760fd9:	cmp    %rcx,%rax
  760fdc:	jae    7620d5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1a05>
  760fe2:	lea    (%rax,%r12,4),%rcx
  760fe6:	cmp    %rcx,%rsi
  760fe9:	jae    7620d5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1a05>
  760fef:	xor    %ecx,%ecx
  760ff1:	mov    %r12,%rsi
  760ff4:	mov    %rcx,%rdx
  760ff7:	and    $0x3,%rsi
  760ffb:	je     761034 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x964>
  760ffd:	imul   $0x38,%rcx,%rdi
  761001:	add    0x20(%rsp),%rdi
  761006:	lea    (%rsi,%rsi,1),%rdx
  76100a:	shl    $0x4,%esi
  76100d:	sub    %rdx,%rsi
  761010:	xor    %r8d,%r8d
  761013:	mov    %rcx,%rdx
  761016:	cs nopw 0x0(%rax,%rax,1)
  761020:	mov    (%rdi,%r8,4),%r9d
  761024:	mov    %r9d,(%rax,%rdx,4)
  761028:	inc    %rdx
  76102b:	add    $0xe,%r8
  76102f:	cmp    %r8,%rsi
  761032:	jne    761020 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x950>
  761034:	sub    %r12,%rcx
  761037:	cmp    $0xfffffffffffffffc,%rcx
  76103b:	ja     76214a <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1a7a>
  761041:	imul   $0x38,%rdx,%rcx
  761045:	add    0x20(%rsp),%rcx
  76104a:	nopw   0x0(%rax,%rax,1)
  761050:	mov    (%rcx),%esi
  761052:	mov    %esi,(%rax,%rdx,4)
  761055:	mov    0x38(%rcx),%esi
  761058:	mov    %esi,0x4(%rax,%rdx,4)
  76105c:	mov    0x70(%rcx),%esi
  76105f:	mov    %esi,0x8(%rax,%rdx,4)
  761063:	mov    0xa8(%rcx),%esi
  761069:	mov    %esi,0xc(%rax,%rdx,4)
  76106d:	add    $0x4,%rdx
  761071:	add    $0xe0,%rcx
  761078:	cmp    %rdx,%r12
  76107b:	jne    761050 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x980>
  76107d:	jmp    76214a <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1a7a>
  761082:	mov    %rax,0x8(%rsp)
  761087:	movq   $0x0,0x28(%rsp)
  761090:	movq   $0x0,0x110(%rsp)
  76109c:	mov    $0xffffffff,%eax
  7610a1:	mov    %rax,0x258(%rsp)
  7610a9:	movq   $0x0,0x260(%rsp)
  7610b5:	mov    %rbx,%rdi
  7610b8:	xor    %esi,%esi
  7610ba:	mov    $0x1,%edx
  7610bf:	call   *0x358113(%rip)        # ab91d8 <_DYNAMIC+0x4a8>
  7610c5:	mov    %edx,%ebx
  7610c7:	cmp    $0x2,%dl
  7610ca:	je     762233 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1b63>
  7610d0:	test   %eax,%eax
  7610d2:	sete   0xf8(%rsp)
  7610da:	mov    0x288(%rsp),%rbp
  7610e2:	mov    0x290(%rsp),%r14
  7610ea:	cmp    $0x4,%r14
  7610ee:	je     7611f5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xb25>
  7610f4:	cmp    $0x5,%r14
  7610f8:	jne    7612b2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xbe2>
  7610fe:	mov    $0x6f727261,%eax
  761103:	xor    0x0(%rbp),%eax
  761106:	movzbl 0x4(%rbp),%ecx
  76110a:	xor    $0x77,%ecx
  76110d:	or     %eax,%ecx
  76110f:	jne    7611a0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xad0>
  761115:	cmpq   $0x5,0x128(%rsp)
  76111e:	jne    76113e <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xa6e>
  761120:	mov    $0x74706d65,%eax
  761125:	mov    0x160(%rsp),%rcx
  76112d:	xor    (%rcx),%eax
  76112f:	movzbl 0x4(%rcx),%ecx
  761133:	xor    $0x79,%ecx
  761136:	or     %eax,%ecx
  761138:	je     7623f0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1d20>
  76113e:	movl   $0x0,0x70(%rsp)
  761146:	movb   $0x1,0x74(%rsp)
  76114b:	movl   $0x0,0x78(%rsp)
  761153:	movb   $0x1,0x7c(%rsp)
  761158:	mov    0x10(%rsp),%rsi
  76115d:	test   %rsi,%rsi
  761160:	je     762630 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1f60>
  761166:	lea    0x30(%rsp),%rdi
  76116b:	lea    0x70(%rsp),%r8
  761170:	mov    0x120(%rsp),%rdx
  761178:	mov    0x100(%rsp),%rcx
  761180:	call   76efc0 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE12select_inputB12_>
  761185:	cmpq   $0xfffffffffffffffe,0x30(%rsp)
  76118b:	jne    762642 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1f72>
  761191:	mov    0x10(%rsp),%rsi
  761196:	lea    0x70(%rsp),%rdi
  76119b:	call   760560 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack>
  7611a0:	movl   $0x0,0x210(%rsp)
  7611ab:	mov    0x10(%rsp),%rax
  7611b0:	test   %rax,%rax
  7611b3:	jne    7612cb <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xbfb>
  7611b9:	movq   $0xd,0x70(%rsp)
  7611c2:	movq   $0x0,0x78(%rsp)
  7611cb:	lea    -0x6915a8(%rip),%rdi        # cfc2a <GCC_except_table0+0xd88a>
  7611d2:	lea    0x33888f(%rip),%rcx        # a99a68 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1290>
  7611d9:	lea    0x338660(%rip),%r8        # a99840 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1068>
  7611e0:	lea    0x70(%rsp),%rdx
  7611e5:	mov    $0x2b,%esi
  7611ea:	call   *0x357e50(%rip)        # ab9040 <_DYNAMIC+0x310>
  7611f0:	jmp    762728 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2058>
  7611f5:	mov    $0x1,%al
  7611f7:	mov    %eax,0x210(%rsp)
  7611fe:	cmpl   $0x67617264,0x0(%rbp)
  761205:	jne    7612bd <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xbed>
  76120b:	mov    0x28(%rsp),%rax
  761210:	mov    %rax,0x70(%rsp)
  761215:	cmp    $0x2,%rax
  761219:	jne    7622bd <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1bed>
  76121f:	mov    0x8(%rsp),%rcx
  761224:	mov    0x8(%rcx),%eax
  761227:	cmp    0x18(%rcx),%eax
  76122a:	jne    761239 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xb69>
  76122c:	movzbl 0xc(%rcx),%eax
  761230:	cmp    0x1c(%rcx),%al
  761233:	je     762402 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1d32>
  761239:	movsd  (%rcx),%xmm0
  76123d:	movsd  %xmm0,0x74(%rsp)
  761243:	movl   $0x0,0x70(%rsp)
  76124b:	lea    0x30(%rsp),%rdi
  761250:	lea    0x10(%rsp),%rsi
  761255:	lea    0x258(%rsp),%rdx
  76125d:	lea    0x70(%rsp),%rcx
  761262:	call   76cda0 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_>
  761267:	cmpl   $0xfffffffe,0x30(%rsp)
  76126c:	jne    7622df <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1c0f>
  761272:	movl   $0x2,0x70(%rsp)
  76127a:	lea    0x30(%rsp),%rdi
  76127f:	lea    0x10(%rsp),%rsi
  761284:	lea    0x258(%rsp),%rdx
  76128c:	lea    0x70(%rsp),%rcx
  761291:	call   76cda0 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_>
  761296:	cmpl   $0xfffffffe,0x30(%rsp)
  76129b:	jne    76233a <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1c6a>
  7612a1:	mov    0x10(%rsp),%rsi
  7612a6:	lea    0x70(%rsp),%rdi
  7612ab:	call   760560 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack>
  7612b0:	jmp    7612bd <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xbed>
  7612b2:	movl   $0x0,0x210(%rsp)
  7612bd:	mov    0x10(%rsp),%rax
  7612c2:	test   %rax,%rax
  7612c5:	je     7611b9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xae9>
  7612cb:	xorps  %xmm0,%xmm0
  7612ce:	movups %xmm0,0x740(%rax)
  7612d5:	movups %xmm0,0x730(%rax)
  7612dc:	movups %xmm0,0x720(%rax)
  7612e3:	movups %xmm0,0x710(%rax)
  7612ea:	movups %xmm0,0x700(%rax)
  7612f1:	movups %xmm0,0x6f0(%rax)
  7612f8:	movq   $0x0,0x750(%rax)
  761303:	cmpb   $0x0,0x380(%rsp)
  76130b:	je     761324 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xc54>
  76130d:	call   *0x357f0d(%rip)        # ab9220 <_DYNAMIC+0x4f0>
  761313:	mov    %rax,0x1b8(%rsp)
  76131b:	mov    %edx,0x160(%rsp)
  761322:	jmp    76132f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xc5f>
  761324:	movl   $0xffffffff,0x160(%rsp)
  76132f:	mov    0x28(%rsp),%rax
  761334:	cmp    $0x1,%rax
  761338:	adc    $0x0,%rax
  76133c:	mov    %rax,0x120(%rsp)
  761344:	mov    0x130(%rsp),%rax
  76134c:	cmp    $0x1,%rax
  761350:	adc    $0x0,%rax
  761354:	mov    %rax,0x128(%rsp)
  76135c:	mov    %r14,0x100(%rsp)
  761364:	lea    -0x3(%r14),%r13
  761368:	cmp    $0x7,%r13
  76136c:	setb   %al
  76136f:	mov    $0x5f,%dl
  761371:	mov    %r13d,%ecx
  761374:	shr    %cl,%dl
  761376:	and    %al,%dl
  761378:	cmp    $0x1,%dl
  76137b:	je     7613b4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xce4>
  76137d:	lea    0x288(%rsp),%rax
  761385:	mov    %rax,0x70(%rsp)
  76138a:	lea    0x34d2f(%rip),%rax        # 7960c0 <_RNvXs1i_NtCs4NRVxsYgnAr_4core3fmtReNtB6_7Display3fmtCs9C2G9YFESsD_29canonical_text_public_control>
  761391:	mov    %rax,0x78(%rsp)
  761396:	lea    -0x697a5a(%rip),%rdi        # c9943 <GCC_except_table0+0x75a3>
  76139d:	lea    0x338514(%rip),%rdx        # a998b8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x10e0>
  7613a4:	lea    0x70(%rsp),%rsi
  7613a9:	call   *0x357bf9(%rip)        # ab8fa8 <_DYNAMIC+0x278>
  7613af:	jmp    762728 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2058>
  7613b4:	and    %bl,0xf8(%rsp)
  7613bb:	mov    $0x1,%ebx
  7613c0:	xor    %r14d,%r14d
  7613c3:	lea    0x70(%rsp),%r12
  7613c8:	lea    -0x69d417(%rip),%r15        # c3fb8 <GCC_except_table0+0x1c18>
  7613cf:	jmp    761431 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xd61>
  7613d1:	lea    0x4e78(%rip),%rax        # 766250 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9query_hit>
  7613d8:	mov    %rax,0x70(%rsp)
  7613dd:	mov    0x70(%rsp),%rcx
  7613e2:	mov    0xf0(%rsp),%rax
  7613ea:	mov    %rax,0x70(%rsp)
  7613ef:	mov    0x70(%rsp),%rdi
  7613f4:	movlps %xmm0,0x70(%rsp)
  7613f9:	movsd  0x70(%rsp),%xmm0
  7613ff:	movaps %xmm0,%xmm1
  761402:	shufps $0x55,%xmm0,%xmm1
  761406:	call   *%rcx
  761408:	inc    %r14
  76140b:	mov    %rax,0x70(%rsp)
  761410:	xor    0x70(%rsp),%rbx
  761415:	movabs $0x100000001b3,%rax
  76141f:	imul   %rax,%rbx
  761423:	cmp    %r14,0x138(%rsp)
  76142b:	je     7618c5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x11f5>
  761431:	cmp    $0x6,%r13
  761435:	ja     76148d <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xdbd>
  761437:	movslq (%r15,%r13,4),%rax
  76143b:	add    %r15,%rax
  76143e:	jmp    *%rax
  761440:	movzwl 0x0(%rbp),%eax
  761444:	xor    $0x6968,%eax
  761449:	movzbl 0x2(%rbp),%ecx
  76144d:	xor    $0x74,%ecx
  761450:	or     %ax,%cx
  761453:	jne    76137d <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xcad>
  761459:	mov    %r14,%rax
  76145c:	mov    0x128(%rsp),%rcx
  761464:	or     %rcx,%rax
  761467:	shr    $0x20,%rax
  76146b:	je     7617a9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x10d9>
  761471:	mov    %r14,%rax
  761474:	xor    %edx,%edx
  761476:	div    %rcx
  761479:	xorps  %xmm0,%xmm0
  76147c:	cmpq   $0x0,0x20(%rsp)
  761482:	jne    7617bf <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x10ef>
  761488:	jmp    7613d1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xd01>
  76148d:	mov    0x0(%rbp),%eax
  761490:	mov    $0x70657270,%ecx
  761495:	xor    %ecx,%eax
  761497:	mov    0x3(%rbp),%ecx
  76149a:	mov    $0x65726170,%edx
  76149f:	xor    %edx,%ecx
  7614a1:	or     %eax,%ecx
  7614a3:	je     761715 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1045>
  7614a9:	mov    0x0(%rbp),%eax
  7614ac:	mov    $0x68736572,%ecx
  7614b1:	xor    %ecx,%eax
  7614b3:	mov    0x3(%rbp),%ecx
  7614b6:	mov    $0x65706168,%edx
  7614bb:	xor    %edx,%ecx
  7614bd:	or     %eax,%ecx
  7614bf:	jne    76137d <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xcad>
  7614c5:	lea    -0x168c(%rip),%rax        # 75fe40 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_reshape>
  7614cc:	mov    %rax,0x70(%rsp)
  7614d1:	mov    0x70(%rsp),%rax
  7614d6:	lea    0x10(%rsp),%rcx
  7614db:	mov    %rcx,0x70(%rsp)
  7614e0:	mov    0x70(%rsp),%rdi
  7614e5:	test   $0x1,%r14b
  7614e9:	lea    0x248(%rsp),%rcx
  7614f1:	lea    0x150(%rsp),%rdx
  7614f9:	cmove  %rdx,%rcx
  7614fd:	mov    (%rcx),%rcx
  761500:	lea    0x250(%rsp),%rdx
  761508:	lea    0x158(%rsp),%rsi
  761510:	cmove  %rsi,%rdx
  761514:	mov    (%rdx),%rdx
  761517:	mov    %rcx,0x70(%rsp)
  76151c:	mov    %rdx,0x78(%rsp)
  761521:	mov    0x70(%rsp),%rsi
  761526:	mov    0x78(%rsp),%rdx
  76152b:	call   *%rax
  76152d:	jmp    761408 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xd38>
  761532:	mov    0x0(%rbp),%eax
  761535:	mov    $0x6f727261,%ecx
  76153a:	xor    %ecx,%eax
  76153c:	movzbl 0x4(%rbp),%ecx
  761540:	xor    $0x77,%ecx
  761543:	or     %eax,%ecx
  761545:	jne    76137d <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xcad>
  76154b:	lea    -0x22a2(%rip),%rax        # 75f2b0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow>
  761552:	mov    %rax,0x70(%rsp)
  761557:	mov    0x70(%rsp),%rax
  76155c:	lea    0x10(%rsp),%rcx
  761561:	mov    %rcx,0x70(%rsp)
  761566:	mov    0x70(%rsp),%rdi
  76156b:	test   $0x1,%r14b
  76156f:	sete   %cl
  761572:	xor    0xf8(%rsp),%cl
  761579:	mov    %cl,0x70(%rsp)
  76157d:	jmp    761741 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1071>
  761582:	cmpl   $0x67617264,0x0(%rbp)
  761589:	jne    76137d <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xcad>
  76158f:	lea    -0x2886(%rip),%rax        # 75ed10 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag>
  761596:	mov    %rax,0x70(%rsp)
  76159b:	mov    0x70(%rsp),%rcx
  7615a0:	lea    0x10(%rsp),%rax
  7615a5:	mov    %rax,0x70(%rsp)
  7615aa:	mov    0x70(%rsp),%rdi
  7615af:	lea    0x258(%rsp),%rax
  7615b7:	mov    %rax,0x70(%rsp)
  7615bc:	mov    %r14d,%eax
  7615bf:	not    %eax
  7615c1:	and    $0x1,%eax
  7615c4:	cmp    0x28(%rsp),%rax
  7615c9:	jae    762522 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1e52>
  7615cf:	mov    0x70(%rsp),%rsi
  7615d4:	shl    $0x4,%eax
  7615d7:	mov    0x8(%rsp),%rdx
  7615dc:	movsd  (%rdx,%rax,1),%xmm0
  7615e1:	movsd  %xmm0,0x70(%rsp)
  7615e7:	movss  0x70(%rsp),%xmm0
  7615ed:	movss  0x74(%rsp),%xmm1
  7615f3:	call   *%rcx
  7615f5:	jmp    761408 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xd38>
  7615fa:	mov    0x0(%rbp),%eax
  7615fd:	mov    $0x75736976,%ecx
  761602:	xor    %ecx,%eax
  761604:	movzwl 0x4(%rbp),%ecx
  761608:	xor    $0x6c61,%ecx
  76160e:	or     %eax,%ecx
  761610:	jne    76137d <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xcad>
  761616:	lea    -0x1ddd(%rip),%rax        # 75f840 <_RNvCs9C2G9YFESsD_29canonical_text_public_control12query_visual>
  76161d:	mov    %rax,0x70(%rsp)
  761622:	mov    0x70(%rsp),%rcx
  761627:	mov    0xf0(%rsp),%rax
  76162f:	mov    %rax,0x70(%rsp)
  761634:	mov    0x178(%rsp),%r8
  76163c:	test   %r8,%r8
  76163f:	je     762470 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1da0>
  761645:	mov    0x70(%rsp),%rdi
  76164a:	mov    0x170(%rsp),%rsi
  761652:	mov    %r14,%rax
  761655:	or     %r8,%rax
  761658:	shr    $0x20,%rax
  76165c:	je     7617f1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1121>
  761662:	mov    %r14,%rax
  761665:	xor    %edx,%edx
  761667:	div    %r8
  76166a:	jmp    7617f9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1129>
  76166f:	mov    0x0(%rbp),%rax
  761673:	movabs $0x6f697463656c6573,%rcx
  76167d:	xor    %rcx,%rax
  761680:	movzbl 0x8(%rbp),%ecx
  761684:	xor    $0x6e,%rcx
  761688:	or     %rax,%rcx
  76168b:	je     761750 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1080>
  761691:	mov    0x0(%rbp),%rax
  761695:	movabs $0x69682d72656e776f,%rcx
  76169f:	xor    %rcx,%rax
  7616a2:	movzbl 0x8(%rbp),%ecx
  7616a6:	xor    $0x74,%rcx
  7616aa:	or     %rax,%rcx
  7616ad:	jne    76137d <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xcad>
  7616b3:	lea    0x49f6(%rip),%rax        # 7660b0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit>
  7616ba:	mov    %rax,0x70(%rsp)
  7616bf:	mov    0x70(%rsp),%rcx
  7616c4:	lea    0x10(%rsp),%rax
  7616c9:	mov    %rax,0x70(%rsp)
  7616ce:	mov    0x70(%rsp),%rdi
  7616d3:	mov    %r14,%rax
  7616d6:	mov    0x120(%rsp),%rsi
  7616de:	or     %rsi,%rax
  7616e1:	shr    $0x20,%rax
  7616e5:	je     76182d <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x115d>
  7616eb:	mov    %r14,%rax
  7616ee:	xor    %edx,%edx
  7616f0:	div    %rsi
  7616f3:	xorps  %xmm0,%xmm0
  7616f6:	cmp    0x28(%rsp),%rdx
  7616fb:	jae    76170b <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x103b>
  7616fd:	shl    $0x4,%rdx
  761701:	mov    0x8(%rsp),%rax
  761706:	movsd  (%rax,%rdx,1),%xmm0
  76170b:	movlps %xmm0,0x70(%rsp)
  761710:	jmp    7613f9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xd29>
  761715:	lea    -0x1e4c(%rip),%rax        # 75f8d0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare>
  76171c:	mov    %rax,0x70(%rsp)
  761721:	mov    0x70(%rsp),%rax
  761726:	lea    0x10(%rsp),%rcx
  76172b:	mov    %rcx,0x70(%rsp)
  761730:	mov    0x70(%rsp),%rdi
  761735:	mov    %r14d,%ecx
  761738:	not    %cl
  76173a:	and    $0x1,%cl
  76173d:	mov    %cl,0x70(%rsp)
  761741:	movzbl 0x70(%rsp),%ecx
  761746:	movzbl %cl,%esi
  761749:	call   *%rax
  76174b:	jmp    761408 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xd38>
  761750:	lea    -0x1687(%rip),%rax        # 7600d0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection>
  761757:	mov    %rax,0x70(%rsp)
  76175c:	mov    0x70(%rsp),%rcx
  761761:	mov    0xf0(%rsp),%rax
  761769:	mov    %rax,0x70(%rsp)
  76176e:	mov    0x178(%rsp),%r8
  761776:	test   %r8,%r8
  761779:	je     762470 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1da0>
  76177f:	mov    0x70(%rsp),%rdi
  761784:	mov    0x170(%rsp),%rsi
  76178c:	mov    %r14,%rax
  76178f:	or     %r8,%rax
  761792:	shr    $0x20,%rax
  761796:	je     761847 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1177>
  76179c:	mov    %r14,%rax
  76179f:	xor    %edx,%edx
  7617a1:	div    %r8
  7617a4:	jmp    76184f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x117f>
  7617a9:	mov    %r14d,%eax
  7617ac:	xor    %edx,%edx
  7617ae:	div    %ecx
  7617b0:	xorps  %xmm0,%xmm0
  7617b3:	cmpq   $0x0,0x20(%rsp)
  7617b9:	je     7613d1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xd01>
  7617bf:	cmp    0x130(%rsp),%rdx
  7617c7:	jae    7613d1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xd01>
  7617cd:	imul   $0x38,%rdx,%rax
  7617d1:	mov    0x20(%rsp),%rcx
  7617d6:	movsd  0x10(%rcx,%rax,1),%xmm1
  7617dc:	movsd  0x18(%rcx,%rax,1),%xmm0
  7617e2:	mulps  -0x69e159(%rip),%xmm0        # c3690 <GCC_except_table0+0x12f0>
  7617e9:	addps  %xmm1,%xmm0
  7617ec:	jmp    7613d1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xd01>
  7617f1:	mov    %r14d,%eax
  7617f4:	xor    %edx,%edx
  7617f6:	div    %r8d
  7617f9:	mov    0x118(%rsp),%r8
  761801:	test   %r8,%r8
  761804:	sete   %al
  761807:	mov    (%rsi,%rdx,4),%edx
  76180a:	cmp    %rdx,%r8
  76180d:	setne  %sil
  761811:	or     %al,%sil
  761814:	mov    %edx,0x70(%rsp)
  761818:	mov    %sil,0x74(%rsp)
  76181d:	mov    0x70(%rsp),%esi
  761821:	movzbl 0x74(%rsp),%edx
  761826:	call   *%rcx
  761828:	jmp    761408 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xd38>
  76182d:	mov    %r14d,%eax
  761830:	xor    %edx,%edx
  761832:	div    %esi
  761834:	xorps  %xmm0,%xmm0
  761837:	cmp    0x28(%rsp),%rdx
  76183c:	jae    76170b <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x103b>
  761842:	jmp    7616fd <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x102d>
  761847:	mov    %r14d,%eax
  76184a:	xor    %edx,%edx
  76184c:	div    %r8d
  76184f:	mov    0x118(%rsp),%rax
  761857:	test   %rax,%rax
  76185a:	sete   %r9b
  76185e:	mov    (%rsi,%rdx,4),%r10d
  761862:	cmp    %r10,%rax
  761865:	setne  %r11b
  761869:	mov    %r8,%rax
  76186c:	shr    $1,%rax
  76186f:	add    %r14,%rax
  761872:	mov    %rax,%rdx
  761875:	or     %r8,%rdx
  761878:	shr    $0x20,%rdx
  76187c:	je     761885 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x11b5>
  76187e:	xor    %edx,%edx
  761880:	div    %r8
  761883:	jmp    76188a <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x11ba>
  761885:	xor    %edx,%edx
  761887:	div    %r8d
  76188a:	or     %r11b,%r9b
  76188d:	mov    0x118(%rsp),%r8
  761895:	test   %r8,%r8
  761898:	sete   %al
  76189b:	mov    (%rsi,%rdx,4),%edx
  76189e:	cmp    %rdx,%r8
  7618a1:	setne  %sil
  7618a5:	or     %al,%sil
  7618a8:	mov    %r10d,0x70(%rsp)
  7618ad:	mov    %r9b,0x74(%rsp)
  7618b2:	mov    %edx,0x78(%rsp)
  7618b6:	mov    %sil,0x7c(%rsp)
  7618bb:	mov    %r12,%rsi
  7618be:	call   *%rcx
  7618c0:	jmp    761408 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xd38>
  7618c5:	mov    0x160(%rsp),%eax
  7618cc:	cmp    $0xffffffff,%eax
  7618cf:	je     761984 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x12b4>
  7618d5:	mov    0x1b8(%rsp),%rcx
  7618dd:	mov    %rcx,0x70(%rsp)
  7618e2:	mov    %eax,0x78(%rsp)
  7618e6:	lea    0x70(%rsp),%rdi
  7618eb:	call   *0x357937(%rip)        # ab9228 <_DYNAMIC+0x4f8>
  7618f1:	lea    0x240(%rsp),%rsi
  7618f9:	mov    0x100(%rsp),%rdi
  761901:	mov    %edx,%ecx
  761903:	mov    $0x3b9aca00,%edx
  761908:	mul    %rdx
  76190b:	mov    %ecx,%ecx
  76190d:	add    %rax,%rcx
  761910:	mov    %rcx,0xf0(%rsp)
  761918:	adc    $0x0,%rdx
  76191c:	mov    %rdx,0x28(%rsp)
  761921:	cmp    $0x7,%rdi
  761925:	je     7619af <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x12df>
  76192b:	jmp    7619c7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x12f7>
  761930:	mov    %edi,%eax
  761932:	and    $0x1f,%eax
  761935:	movzbl 0x1(%rcx),%r8d
  76193a:	and    $0x3f,%r8d
  76193e:	cmp    $0xe0,%dil
  761942:	jb     761e33 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1763>
  761948:	movzbl 0x2(%rcx),%edx
  76194c:	shl    $0x6,%r8d
  761950:	and    $0x3f,%edx
  761953:	or     %r8d,%edx
  761956:	cmp    $0xf0,%dil
  76195a:	jb     761f86 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x18b6>
  761960:	movzbl 0x3(%rcx),%ecx
  761964:	and    $0x7,%eax
  761967:	shl    $0x12,%eax
  76196a:	shl    $0x6,%edx
  76196d:	and    $0x3f,%ecx
  761970:	or     %edx,%ecx
  761972:	or     %ecx,%eax
  761974:	cmp    $0x80,%eax
  761979:	jae    761f96 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x18c6>
  76197f:	jmp    76076c <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x9c>
  761984:	movq   $0x0,0xf0(%rsp)
  761990:	movq   $0x0,0x28(%rsp)
  761999:	lea    0x240(%rsp),%rsi
  7619a1:	mov    0x100(%rsp),%rdi
  7619a9:	cmp    $0x7,%rdi
  7619ad:	jne    7619c7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x12f7>
  7619af:	mov    $0x68736572,%eax
  7619b4:	xor    0x0(%rbp),%eax
  7619b7:	mov    $0x65706168,%ecx
  7619bc:	xor    0x3(%rbp),%ecx
  7619bf:	or     %eax,%ecx
  7619c1:	je     761e49 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1779>
  7619c7:	cmpb   $0x0,0x210(%rsp)
  7619cf:	je     761a18 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1348>
  7619d1:	cmpl   $0x67617264,0x0(%rbp)
  7619d8:	jne    761a18 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1348>
  7619da:	movl   $0x3,0x70(%rsp)
  7619e2:	lea    0x30(%rsp),%rdi
  7619e7:	lea    0x10(%rsp),%rsi
  7619ec:	lea    0x258(%rsp),%rdx
  7619f4:	lea    0x70(%rsp),%rcx
  7619f9:	call   76cda0 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_>
  7619fe:	cmpl   $0xfffffffe,0x30(%rsp)
  761a03:	jne    762395 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1cc5>
  761a09:	mov    0x10(%rsp),%rsi
  761a0e:	lea    0x70(%rsp),%rdi
  761a13:	call   760560 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack>
  761a18:	mov    0x10(%rsp),%rax
  761a1d:	test   %rax,%rax
  761a20:	je     7625f4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1f24>
  761a26:	mov    0x6f0(%rax),%rcx
  761a2d:	mov    0x6f8(%rax),%r12
  761a34:	mov    0x700(%rax),%r15
  761a3b:	mov    0x708(%rax),%r14
  761a42:	mov    0x710(%rax),%rbp
  761a49:	mov    0x718(%rax),%r13
  761a50:	mov    0x720(%rax),%rdx
  761a57:	mov    %rdx,0x138(%rsp)
  761a5f:	mov    0x728(%rax),%rdx
  761a66:	mov    %rdx,0x118(%rsp)
  761a6e:	mov    0x730(%rax),%rdx
  761a75:	mov    %rdx,0x130(%rsp)
  761a7d:	mov    0x738(%rax),%rdx
  761a84:	mov    %rdx,0xf8(%rsp)
  761a8c:	mov    0x740(%rax),%rdx
  761a93:	mov    %rdx,0x128(%rsp)
  761a9b:	mov    0x748(%rax),%rdx
  761aa2:	mov    %rdx,0x120(%rsp)
  761aaa:	mov    0x750(%rax),%rax
  761ab1:	mov    %rax,0x100(%rsp)
  761ab9:	movq   $0xffffffffffffffff,0x30(%rsp)
  761ac2:	movq   $0x0,0x48(%rsp)
  761acb:	movq   $0x0,0x58(%rsp)
  761ad4:	lea    -0x692266(%rip),%rsi        # cf875 <GCC_except_table0+0xd4d5>
  761adb:	lea    0x30(%rsp),%rdi
  761ae0:	mov    $0xc,%edx
  761ae5:	call   75c6f0 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  761aea:	test   %rax,%rax
  761aed:	jne    76241b <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1d4b>
  761af3:	lea    -0x692279(%rip),%rsi        # cf881 <GCC_except_table0+0xd4e1>
  761afa:	lea    0x30(%rsp),%rdi
  761aff:	mov    $0xc,%edx
  761b04:	mov    %r12,%rcx
  761b07:	call   75c6f0 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  761b0c:	test   %rax,%rax
  761b0f:	jne    76241b <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1d4b>
  761b15:	lea    -0x69228f(%rip),%rsi        # cf88d <GCC_except_table0+0xd4ed>
  761b1c:	lea    0x30(%rsp),%rdi
  761b21:	mov    $0x11,%edx
  761b26:	mov    %r15,%rcx
  761b29:	call   75c6f0 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  761b2e:	test   %rax,%rax
  761b31:	jne    76241b <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1d4b>
  761b37:	lea    -0x6922a0(%rip),%rsi        # cf89e <GCC_except_table0+0xd4fe>
  761b3e:	lea    0x30(%rsp),%rdi
  761b43:	mov    $0xc,%edx
  761b48:	mov    %r14,%rcx
  761b4b:	call   75c6f0 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  761b50:	test   %rax,%rax
  761b53:	jne    76241b <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1d4b>
  761b59:	lea    -0x6922b6(%rip),%rsi        # cf8aa <GCC_except_table0+0xd50a>
  761b60:	lea    0x30(%rsp),%rdi
  761b65:	mov    $0x14,%edx
  761b6a:	mov    %rbp,%rcx
  761b6d:	call   75c6f0 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  761b72:	test   %rax,%rax
  761b75:	jne    76241b <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1d4b>
  761b7b:	lea    -0x6922c4(%rip),%rsi        # cf8be <GCC_except_table0+0xd51e>
  761b82:	lea    0x30(%rsp),%rdi
  761b87:	mov    $0xf,%edx
  761b8c:	mov    %r13,%rcx
  761b8f:	call   75c6f0 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  761b94:	test   %rax,%rax
  761b97:	jne    76241b <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1d4b>
  761b9d:	lea    -0x6922d7(%rip),%rsi        # cf8cd <GCC_except_table0+0xd52d>
  761ba4:	lea    0x30(%rsp),%rdi
  761ba9:	mov    $0x11,%edx
  761bae:	mov    0x138(%rsp),%rcx
  761bb6:	call   75c6f0 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  761bbb:	test   %rax,%rax
  761bbe:	jne    76241b <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1d4b>
  761bc4:	lea    -0x6922ed(%rip),%rsi        # cf8de <GCC_except_table0+0xd53e>
  761bcb:	lea    0x30(%rsp),%rdi
  761bd0:	mov    $0xb,%edx
  761bd5:	mov    0x118(%rsp),%rcx
  761bdd:	call   75c6f0 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  761be2:	test   %rax,%rax
  761be5:	jne    76241b <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1d4b>
  761beb:	lea    -0x692309(%rip),%rsi        # cf8e9 <GCC_except_table0+0xd549>
  761bf2:	lea    0x30(%rsp),%rdi
  761bf7:	mov    $0xd,%edx
  761bfc:	mov    0x130(%rsp),%rcx
  761c04:	call   75c6f0 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  761c09:	test   %rax,%rax
  761c0c:	jne    76241b <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1d4b>
  761c12:	lea    -0x692323(%rip),%rsi        # cf8f6 <GCC_except_table0+0xd556>
  761c19:	lea    0x30(%rsp),%rdi
  761c1e:	mov    $0xd,%edx
  761c23:	mov    0xf8(%rsp),%rcx
  761c2b:	call   75c6f0 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  761c30:	test   %rax,%rax
  761c33:	jne    76241b <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1d4b>
  761c39:	lea    -0x69233d(%rip),%rsi        # cf903 <GCC_except_table0+0xd563>
  761c40:	lea    0x30(%rsp),%rdi
  761c45:	mov    $0xc,%edx
  761c4a:	mov    0x128(%rsp),%rcx
  761c52:	call   75c6f0 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  761c57:	test   %rax,%rax
  761c5a:	jne    76241b <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1d4b>
  761c60:	lea    -0x692358(%rip),%rsi        # cf90f <GCC_except_table0+0xd56f>
  761c67:	lea    0x30(%rsp),%rdi
  761c6c:	mov    $0xd,%edx
  761c71:	mov    0x120(%rsp),%rcx
  761c79:	call   75c6f0 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  761c7e:	test   %rax,%rax
  761c81:	jne    76241b <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1d4b>
  761c87:	lea    -0x692372(%rip),%rsi        # cf91c <GCC_except_table0+0xd57c>
  761c8e:	lea    0x30(%rsp),%rdi
  761c93:	mov    $0xe,%edx
  761c98:	mov    0x100(%rsp),%rcx
  761ca0:	call   75c6f0 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  761ca5:	test   %rax,%rax
  761ca8:	jne    76241b <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1d4b>
  761cae:	movups 0x30(%rsp),%xmm0
  761cb3:	movups 0x40(%rsp),%xmm1
  761cb8:	movups 0x50(%rsp),%xmm2
  761cbd:	movaps %xmm2,0x90(%rsp)
  761cc5:	movaps %xmm1,0x80(%rsp)
  761ccd:	movaps %xmm0,0x70(%rsp)
  761cd2:	lea    0x180(%rsp),%rdi
  761cda:	lea    0x70(%rsp),%rsi
  761cdf:	call   *0x35754b(%rip)        # ab9230 <_DYNAMIC+0x500>
  761ce5:	cmpb   $0xff,0x180(%rsp)
  761ced:	je     76273f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x206f>
  761cf3:	movups 0x180(%rsp),%xmm0
  761cfb:	movups 0x190(%rsp),%xmm1
  761d03:	mov    0x298(%rsp),%rax
  761d0b:	movups %xmm1,0x28(%rax)
  761d0f:	movups %xmm0,0x18(%rax)
  761d13:	mov    %rbx,0x10(%rax)
  761d17:	mov    0x28(%rsp),%rcx
  761d1c:	mov    %rcx,0x8(%rax)
  761d20:	mov    0xf0(%rsp),%rcx
  761d28:	mov    %rcx,(%rax)
  761d2b:	mov    0x110(%rsp),%rsi
  761d33:	test   %rsi,%rsi
  761d36:	mov    0x8(%rsp),%rdi
  761d3b:	je     761d4c <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x167c>
  761d3d:	shl    $0x4,%rsi
  761d41:	mov    $0x4,%edx
  761d46:	call   *0x357224(%rip)        # ab8f70 <_DYNAMIC+0x240>
  761d4c:	mov    0x10(%rsp),%r14
  761d51:	test   %r14,%r14
  761d54:	je     761d71 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x16a1>
  761d56:	mov    %r14,%rdi
  761d59:	call   747d70 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui7runtime7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEEB1h_>
  761d5e:	mov    $0x770,%esi
  761d63:	mov    $0x8,%edx
  761d68:	mov    %r14,%rdi
  761d6b:	call   *0x3571ff(%rip)        # ab8f70 <_DYNAMIC+0x240>
  761d71:	mov    0x168(%rsp),%rsi
  761d79:	test   %rsi,%rsi
  761d7c:	je     761d95 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x16c5>
  761d7e:	mov    0x170(%rsp),%rdi
  761d86:	shl    $0x2,%rsi
  761d8a:	mov    $0x4,%edx
  761d8f:	call   *0x3571db(%rip)        # ab8f70 <_DYNAMIC+0x240>
  761d95:	mov    0x108(%rsp),%rax
  761d9d:	test   %rax,%rax
  761da0:	je     761db6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x16e6>
  761da2:	imul   $0x38,%rax,%rsi
  761da6:	mov    $0x8,%edx
  761dab:	mov    0x20(%rsp),%rdi
  761db0:	call   *0x3571ba(%rip)        # ab8f70 <_DYNAMIC+0x240>
  761db6:	lea    0x310(%rsp),%rdi
  761dbe:	call   74ca60 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text10TextLayoutECs9C2G9YFESsD_29canonical_text_public_control>
  761dc3:	mov    0x140(%rsp),%rax
  761dcb:	lock decq (%rax)
  761dcf:	jne    761de1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1711>
  761dd1:	xor    %ebp,%ebp
  761dd3:	lea    0x140(%rsp),%rdi
  761ddb:	call   *0x35727f(%rip)        # ab9060 <_DYNAMIC+0x330>
  761de1:	mov    0x240(%rsp),%rsi
  761de9:	test   %rsi,%rsi
  761dec:	je     761e01 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1731>
  761dee:	mov    0x248(%rsp),%rdi
  761df6:	mov    $0x1,%edx
  761dfb:	call   *0x35716f(%rip)        # ab8f70 <_DYNAMIC+0x240>
  761e01:	mov    0x148(%rsp),%rsi
  761e09:	test   %rsi,%rsi
  761e0c:	je     761e21 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1751>
  761e0e:	mov    0x150(%rsp),%rdi
  761e16:	mov    $0x1,%edx
  761e1b:	call   *0x35714f(%rip)        # ab8f70 <_DYNAMIC+0x240>
  761e21:	add    $0x348,%rsp
  761e28:	pop    %rbx
  761e29:	pop    %r12
  761e2b:	pop    %r13
  761e2d:	pop    %r14
  761e2f:	pop    %r15
  761e31:	pop    %rbp
  761e32:	ret
  761e33:	shl    $0x6,%eax
  761e36:	or     %r8d,%eax
  761e39:	cmp    $0x80,%eax
  761e3e:	jae    761f96 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x18c6>
  761e44:	jmp    76076c <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x9c>
  761e49:	testb  $0x1,0x138(%rsp)
  761e51:	lea    0x148(%rsp),%rax
  761e59:	cmove  %rsi,%rax
  761e5d:	mov    %rax,0x180(%rsp)
  761e65:	mov    0x10(%rsp),%rsi
  761e6a:	test   %rsi,%rsi
  761e6d:	je     7626a7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1fd7>
  761e73:	cmpb   $0x0,0x76e(%rsi)
  761e7a:	jne    7626ae <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1fde>
  761e80:	cmpb   $0x1,0x76c(%rsi)
  761e87:	jne    7626b5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1fe5>
  761e8d:	lea    0x70(%rsp),%rdi
  761e92:	call   73dc80 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime5queryNtB3_7Context3newNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEBX_>
  761e97:	mov    0xa8(%rsp),%r14
  761e9f:	test   %r14,%r14
  761ea2:	je     7619c7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x12f7>
  761ea8:	mov    0xa0(%rsp),%r12
  761eb0:	add    $0x3d,%r12
  761eb4:	xor    %r15d,%r15d
  761eb7:	mov    %rbx,%r13
  761eba:	jmp    761ee7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1817>
  761ebc:	nopl   0x0(%rax)
  761ec0:	mov    %rax,%rbx
  761ec3:	xor    %r13,%rbx
  761ec6:	movabs $0x100000001b3,%rax
  761ed0:	imul   %rax,%rbx
  761ed4:	mov    %rbx,%r13
  761ed7:	inc    %r15
  761eda:	add    $0x40,%r12
  761ede:	cmp    %r15,%r14
  761ee1:	je     7619c7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x12f7>
  761ee7:	cmpb   $0x4,(%r12)
  761eec:	jne    761ed7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1807>
  761eee:	mov    -0x15(%r12),%rdi
  761ef3:	test   %rdi,%rdi
  761ef6:	je     7625cc <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1efc>
  761efc:	mov    (%rdi),%rdx
  761eff:	shr    $1,%rdx
  761f02:	add    $0x10,%rdi
  761f06:	mov    0x138(%rsp),%rcx
  761f0e:	test   $0x1,%cl
  761f11:	mov    %rdi,0x30(%rsp)
  761f16:	mov    %rdx,0x38(%rsp)
  761f1b:	lea    0x148(%rsp),%rsi
  761f23:	mov    %rsi,%rax
  761f26:	lea    0x240(%rsp),%r8
  761f2e:	cmove  %r8,%rax
  761f32:	cmp    0x10(%rax),%rdx
  761f36:	jne    76216e <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1a9e>
  761f3c:	test   $0x1,%cl
  761f3f:	mov    %rsi,%rax
  761f42:	cmove  %r8,%rax
  761f46:	mov    0x8(%rax),%rsi
  761f4a:	call   *0x3572e8(%rip)        # ab9238 <bcmp@GLIBC_2.2.5>
  761f50:	test   %eax,%eax
  761f52:	jne    76216e <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1a9e>
  761f58:	lea    0x30(%rsp),%rdi
  761f5d:	lea    0x70(%rsp),%rsi
  761f62:	mov    %r15,%rdx
  761f65:	call   *0x35720d(%rip)        # ab9178 <_DYNAMIC+0x448>
  761f6b:	cmpq   $0x0,0x30(%rsp)
  761f71:	je     76223c <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1b6c>
  761f77:	mov    0x40(%rsp),%rdi
  761f7c:	call   75ffa0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript>
  761f81:	jmp    761ec0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x17f0>
  761f86:	shl    $0xc,%eax
  761f89:	or     %edx,%eax
  761f8b:	cmp    $0x80,%eax
  761f90:	jb     76076c <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x9c>
  761f96:	mov    $0x2,%esi
  761f9b:	cmp    $0x800,%eax
  761fa0:	jb     76076c <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x9c>
  761fa6:	cmp    $0x10000,%eax
  761fab:	mov    $0x4,%esi
  761fb0:	sbb    $0x0,%rsi
  761fb4:	jmp    76076c <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x9c>
  761fb9:	lea    0x198(%rsp),%rbx
  761fc1:	lea    0x70(%rsp),%r14
  761fc6:	lea    0x1c0(%rsp),%r15
  761fce:	cmp    $0x1,%rcx
  761fd2:	je     762711 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2041>
  761fd8:	mov    0x180(%rsp),%rdx
  761fe0:	mov    (%rdx),%esi
  761fe2:	add    $0xc,%rdx
  761fe6:	jmp    762000 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1930>
  761fe8:	nopl   0x0(%rax,%rax,1)
  761ff0:	dec    %rax
  761ff3:	add    $0xc,%rdx
  761ff7:	cmp    %rax,%rcx
  761ffa:	ja     760f8e <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x8be>
  762000:	mov    %esi,%edi
  762002:	mov    (%rdx),%esi
  762004:	cmp    %esi,%edi
  762006:	je     761ff0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1920>
  762008:	testb  $0x2,-0x4(%rdx)
  76200c:	je     761ff0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1920>
  76200e:	testb  $0x1,0x8(%rdx)
  762012:	je     761ff0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1920>
  762014:	mov    %rdx,0x180(%rsp)
  76201c:	dec    %rax
  76201f:	mov    %rax,0x188(%rsp)
  762027:	add    $0xfffffffffffffff4,%rdx
  76202b:	mov    %r14,%rdi
  76202e:	mov    %rbx,%rsi
  762031:	call   75d2f0 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Cs9C2G9YFESsD_29canonical_text_public_control>
  762036:	cmpb   $0x2,0x74(%rsp)
  76203b:	mov    0x20(%rsp),%rdx
  762040:	je     760f8e <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x8be>
  762046:	cmp    0x1c0(%rsp),%r12
  76204e:	jne    762073 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x19a3>
  762050:	mov    $0x1,%edx
  762055:	mov    $0x8,%ecx
  76205a:	mov    $0x38,%r8d
  762060:	mov    %r15,%rdi
  762063:	mov    %r12,%rsi
  762066:	call   75b160 <_RINvNvMs2_NtCscdodAO9FK5_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs9C2G9YFESsD_29canonical_text_public_control>
  76206b:	mov    0x1c8(%rsp),%rdx
  762073:	imul   $0x38,%r12,%rax
  762077:	mov    0xa0(%rsp),%rcx
  76207f:	mov    %rcx,0x30(%rdx,%rax,1)
  762084:	movups 0x70(%rsp),%xmm0
  762089:	movups 0x80(%rsp),%xmm1
  762091:	movups 0x90(%rsp),%xmm2
  762099:	movups %xmm2,0x20(%rdx,%rax,1)
  76209e:	movups %xmm1,0x10(%rdx,%rax,1)
  7620a3:	mov    %rdx,0x20(%rsp)
  7620a8:	movups %xmm0,(%rdx,%rax,1)
  7620ac:	inc    %r12
  7620af:	mov    %r12,0x1d0(%rsp)
  7620b7:	mov    0x188(%rsp),%rax
  7620bf:	mov    0x190(%rsp),%rcx
  7620c7:	cmp    %rax,%rcx
  7620ca:	jbe    761fce <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x18fe>
  7620d0:	jmp    760f8e <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x8be>
  7620d5:	mov    %r12,%rcx
  7620d8:	and    $0xfffffffffffffff8,%rcx
  7620dc:	xor    %edx,%edx
  7620de:	xchg   %ax,%ax
  7620e0:	movss  0xa8(%rsi),%xmm0
  7620e8:	movss  0x70(%rsi),%xmm1
  7620ed:	unpcklps %xmm0,%xmm1
  7620f0:	movss  0x38(%rsi),%xmm0
  7620f5:	movss  (%rsi),%xmm2
  7620f9:	unpcklps %xmm0,%xmm2
  7620fc:	movlhps %xmm1,%xmm2
  7620ff:	movss  0x188(%rsi),%xmm0
  762107:	movss  0x150(%rsi),%xmm1
  76210f:	unpcklps %xmm0,%xmm1
  762112:	movss  0x118(%rsi),%xmm0
  76211a:	movss  0xe0(%rsi),%xmm3
  762122:	unpcklps %xmm0,%xmm3
  762125:	movlhps %xmm1,%xmm3
  762128:	movups %xmm2,(%rax,%rdx,4)
  76212c:	movups %xmm3,0x10(%rax,%rdx,4)
  762131:	add    $0x8,%rdx
  762135:	add    $0x1c0,%rsi
  76213c:	cmp    %rdx,%rcx
  76213f:	jne    7620e0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1a10>
  762141:	cmp    %rcx,%r12
  762144:	jne    760ff1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x921>
  76214a:	mov    0x20(%rsp),%rcx
  76214f:	mov    0x108(%rsp),%rdx
  762157:	jmp    76095a <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x28a>
  76215c:	lea    0x336ce5(%rip),%rdi        # a98e48 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x670>
  762163:	call   *0x356eaf(%rip)        # ab9018 <_DYNAMIC+0x2e8>
  762169:	jmp    762728 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2058>
  76216e:	lea    0x30(%rsp),%rdi
  762173:	lea    0x180(%rsp),%rsi
  76217b:	call   74f3aa <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedReRNtNtCscdodAO9FK5_5alloc6string6StringECs9C2G9YFESsD_29canonical_text_public_control>
  762180:	jmp    762728 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2058>
  762185:	lea    -0x69269a(%rip),%rdi        # cfaf2 <GCC_except_table0+0xd752>
  76218c:	lea    0x3375c5(%rip),%rdx        # a99758 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xf80>
  762193:	mov    $0x1b,%esi
  762198:	call   *0x356e4a(%rip)        # ab8fe8 <_DYNAMIC+0x2b8>
  76219e:	mov    0x74(%rsp),%rax
  7621a3:	mov    %rax,0x30(%rsp)
  7621a8:	lea    -0x692585(%rip),%rdi        # cfc2a <GCC_except_table0+0xd88a>
  7621af:	lea    0x3378f2(%rip),%rcx        # a99aa8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x12d0>
  7621b6:	lea    0x3375cb(%rip),%r8        # a99788 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xfb0>
  7621bd:	lea    0x30(%rsp),%rdx
  7621c2:	mov    $0x2b,%esi
  7621c7:	call   *0x356e73(%rip)        # ab9040 <_DYNAMIC+0x310>
  7621cd:	jmp    762728 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2058>
  7621d2:	mov    0x78(%rsp),%rax
  7621d7:	mov    %rax,0x180(%rsp)
  7621df:	lea    -0x6925bc(%rip),%rdi        # cfc2a <GCC_except_table0+0xd88a>
  7621e6:	lea    0x3378bb(%rip),%rcx        # a99aa8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x12d0>
  7621ed:	lea    0x3375ac(%rip),%r8        # a997a0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xfc8>
  7621f4:	lea    0x180(%rsp),%rdx
  7621fc:	mov    $0x2b,%esi
  762201:	call   *0x356e39(%rip)        # ab9040 <_DYNAMIC+0x310>
  762207:	jmp    762728 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2058>
  76220c:	lea    0x3375a5(%rip),%rdi        # a997b8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xfe0>
  762213:	call   *0x356dff(%rip)        # ab9018 <_DYNAMIC+0x2e8>
  762219:	jmp    762728 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2058>
  76221e:	mov    $0x1,%bpl
  762221:	lea    0x337708(%rip),%rdi        # a99930 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1158>
  762228:	call   *0x356dea(%rip)        # ab9018 <_DYNAMIC+0x2e8>
  76222e:	jmp    762728 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2058>
  762233:	lea    0x337596(%rip),%rdi        # a997d0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xff8>
  76223a:	jmp    762243 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1b73>
  76223c:	lea    0x336bd5(%rip),%rdi        # a98e18 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x640>
  762243:	call   *0x356dcf(%rip)        # ab9018 <_DYNAMIC+0x2e8>
  762249:	jmp    762728 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2058>
  76224e:	lea    0x3385eb(%rip),%rcx        # a9a840 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2068>
  762255:	xor    %edi,%edi
  762257:	call   *0x356d63(%rip)        # ab8fc0 <_DYNAMIC+0x290>
  76225d:	jmp    762728 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2058>
  762262:	lea    0x148(%rsp),%rdi
  76226a:	mov    $0x1,%edx
  76226f:	mov    $0x1,%ecx
  762274:	mov    $0x1,%r8d
  76227a:	mov    %rbx,%rsi
  76227d:	call   75b160 <_RINvNvMs2_NtCscdodAO9FK5_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs9C2G9YFESsD_29canonical_text_public_control>
  762282:	jmp    760805 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x135>
  762287:	lea    -0x69de9d(%rip),%rdi        # c43f1 <GCC_except_table0+0x2051>
  76228e:	lea    0x3374db(%rip),%rdx        # a99770 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xf98>
  762295:	mov    $0x57,%esi
  76229a:	call   *0x356d08(%rip)        # ab8fa8 <_DYNAMIC+0x278>
  7622a0:	jmp    762728 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2058>
  7622a5:	lea    0x336bb4(%rip),%rdi        # a98e60 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x688>
  7622ac:	jmp    762163 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1a93>
  7622b1:	lea    0x336bc0(%rip),%rdi        # a98e78 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x6a0>
  7622b8:	jmp    762163 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1a93>
  7622bd:	lea    -0x69e514(%rip),%rdx        # c3db0 <GCC_except_table0+0x1a10>
  7622c4:	lea    0x337635(%rip),%r9        # a99900 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1128>
  7622cb:	lea    0x70(%rsp),%rsi
  7622d0:	xor    %edi,%edi
  7622d2:	xor    %ecx,%ecx
  7622d4:	call   *0x356f66(%rip)        # ab9240 <_DYNAMIC+0x510>
  7622da:	jmp    762728 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2058>
  7622df:	mov    0x60(%rsp),%rax
  7622e4:	mov    %rax,0xa0(%rsp)
  7622ec:	movups 0x30(%rsp),%xmm0
  7622f1:	movups 0x40(%rsp),%xmm1
  7622f6:	movups 0x50(%rsp),%xmm2
  7622fb:	movaps %xmm2,0x90(%rsp)
  762303:	movaps %xmm1,0x80(%rsp)
  76230b:	movaps %xmm0,0x70(%rsp)
  762310:	lea    -0x6926ed(%rip),%rdi        # cfc2a <GCC_except_table0+0xd88a>
  762317:	lea    0x33774a(%rip),%rcx        # a99a68 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1290>
  76231e:	lea    0x3374eb(%rip),%r8        # a99810 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1038>
  762325:	lea    0x70(%rsp),%rdx
  76232a:	mov    $0x2b,%esi
  76232f:	call   *0x356d0b(%rip)        # ab9040 <_DYNAMIC+0x310>
  762335:	jmp    762728 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2058>
  76233a:	mov    0x60(%rsp),%rax
  76233f:	mov    %rax,0xa0(%rsp)
  762347:	movups 0x30(%rsp),%xmm0
  76234c:	movups 0x40(%rsp),%xmm1
  762351:	movups 0x50(%rsp),%xmm2
  762356:	movaps %xmm2,0x90(%rsp)
  76235e:	movaps %xmm1,0x80(%rsp)
  762366:	movaps %xmm0,0x70(%rsp)
  76236b:	lea    -0x692748(%rip),%rdi        # cfc2a <GCC_except_table0+0xd88a>
  762372:	lea    0x3376ef(%rip),%rcx        # a99a68 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1290>
  762379:	lea    0x3374a8(%rip),%r8        # a99828 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1050>
  762380:	lea    0x70(%rsp),%rdx
  762385:	mov    $0x2b,%esi
  76238a:	call   *0x356cb0(%rip)        # ab9040 <_DYNAMIC+0x310>
  762390:	jmp    762728 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2058>
  762395:	mov    0x60(%rsp),%rax
  76239a:	mov    %rax,0xa0(%rsp)
  7623a2:	movups 0x30(%rsp),%xmm0
  7623a7:	movups 0x40(%rsp),%xmm1
  7623ac:	movups 0x50(%rsp),%xmm2
  7623b1:	movaps %xmm2,0x90(%rsp)
  7623b9:	movaps %xmm1,0x80(%rsp)
  7623c1:	movaps %xmm0,0x70(%rsp)
  7623c6:	lea    -0x6927a3(%rip),%rdi        # cfc2a <GCC_except_table0+0xd88a>
  7623cd:	lea    0x337694(%rip),%rcx        # a99a68 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1290>
  7623d4:	lea    0x337495(%rip),%r8        # a99870 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1098>
  7623db:	lea    0x70(%rsp),%rdx
  7623e0:	mov    $0x2b,%esi
  7623e5:	call   *0x356c55(%rip)        # ab9040 <_DYNAMIC+0x310>
  7623eb:	jmp    762728 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2058>
  7623f0:	lea    0x2b0(%rsp),%rdi
  7623f8:	call   74f36d <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedReBM_ECs9C2G9YFESsD_29canonical_text_public_control>
  7623fd:	jmp    762728 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2058>
  762402:	lea    0x8(%rcx),%rdi
  762406:	lea    0x18(%rcx),%rsi
  76240a:	lea    0x3374d7(%rip),%rdx        # a998e8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1110>
  762411:	call   74f303 <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextPositionBM_ECs9C2G9YFESsD_29canonical_text_public_control>
  762416:	jmp    762728 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2058>
  76241b:	mov    %rax,%rbx
  76241e:	mov    %rax,0x188(%rsp)
  762426:	movb   $0xff,0x180(%rsp)
  76242e:	mov    0x48(%rsp),%rcx
  762433:	test   %rcx,%rcx
  762436:	jne    762482 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1db2>
  762438:	xor    %ecx,%ecx
  76243a:	xor    %eax,%eax
  76243c:	jmp    7624c6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1df6>
  762441:	lea    0x336b80(%rip),%rax        # a98fc8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x7f0>
  762448:	mov    %rax,0x110(%rsp)
  762450:	mov    $0x1,%ebx
  762455:	mov    $0x1,%esi
  76245a:	mov    %rbx,%rdi
  76245d:	mov    0x110(%rsp),%rdx
  762465:	call   *0x356b35(%rip)        # ab8fa0 <_DYNAMIC+0x270>
  76246b:	jmp    762728 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2058>
  762470:	lea    0x3369b9(%rip),%rdi        # a98e30 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x658>
  762477:	call   *0x356dcb(%rip)        # ab9248 <_DYNAMIC+0x518>
  76247d:	jmp    762728 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2058>
  762482:	mov    0x50(%rsp),%rdx
  762487:	mov    0x58(%rsp),%rax
  76248c:	movq   $0x0,0x78(%rsp)
  762495:	mov    %rcx,0x80(%rsp)
  76249d:	mov    %rdx,0x88(%rsp)
  7624a5:	movq   $0x0,0x98(%rsp)
  7624b1:	mov    %rcx,0xa0(%rsp)
  7624b9:	mov    %rdx,0xa8(%rsp)
  7624c1:	mov    $0x1,%ecx
  7624c6:	mov    %rcx,0x70(%rsp)
  7624cb:	mov    %rcx,0x90(%rsp)
  7624d3:	mov    %rax,0xb0(%rsp)
  7624db:	lea    0x70(%rsp),%rdi
  7624e0:	call   74ab00 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtCscdodAO9FK5_5alloc11collections5btree3map8IntoIterNtNtBK_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueEECs9C2G9YFESsD_29canonical_text_public_control>
  7624e5:	mov    0x30(%rsp),%rsi
  7624ea:	test   %rsi,%rsi
  7624ed:	jg     76272a <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x205a>
  7624f3:	mov    %rbx,0x70(%rsp)
  7624f8:	lea    -0x6928d5(%rip),%rdi        # cfc2a <GCC_except_table0+0xd88a>
  7624ff:	lea    0x337582(%rip),%rcx        # a99a88 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x12b0>
  762506:	lea    0x337393(%rip),%r8        # a998a0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x10c8>
  76250d:	lea    0x70(%rsp),%rdx
  762512:	mov    $0x2b,%esi
  762517:	call   *0x356b23(%rip)        # ab9040 <_DYNAMIC+0x310>
  76251d:	jmp    762728 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2058>
  762522:	lea    0x3373a7(%rip),%rdx        # a998d0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x10f8>
  762529:	mov    %rax,%rdi
  76252c:	mov    0x28(%rsp),%rsi
  762531:	call   *0x356a69(%rip)        # ab8fa0 <_DYNAMIC+0x270>
  762537:	jmp    762728 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2058>
  76253c:	mov    $0xe,%eax
  762541:	jmp    762548 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1e78>
  762543:	mov    $0x12,%eax
  762548:	mov    %rax,0x8(%rsp)
  76254d:	mov    0x8(%rsp),%rax
  762552:	mov    %rax,0x70(%rsp)
  762557:	lea    -0x692bbd(%rip),%rdi        # cf9a1 <GCC_except_table0+0xd601>
  76255e:	lea    0x337503(%rip),%rcx        # a99a68 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1290>
  762565:	lea    0x336e4c(%rip),%r8        # a993b8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xbe0>
  76256c:	lea    0x70(%rsp),%rdx
  762571:	mov    $0x2a,%esi
  762576:	call   *0x356ac4(%rip)        # ab9040 <_DYNAMIC+0x310>
  76257c:	jmp    762728 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2058>
  762581:	mov    $0xd,%eax
  762586:	jmp    762594 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1ec4>
  762588:	mov    $0xe,%eax
  76258d:	jmp    762594 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1ec4>
  76258f:	mov    $0x12,%eax
  762594:	mov    %rax,0x70(%rsp)
  762599:	movq   $0x0,0x78(%rsp)
  7625a2:	lea    -0x69297f(%rip),%rdi        # cfc2a <GCC_except_table0+0xd88a>
  7625a9:	lea    0x3374b8(%rip),%rcx        # a99a68 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1290>
  7625b0:	lea    0x337439(%rip),%r8        # a999f0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1218>
  7625b7:	lea    0x70(%rsp),%rdx
  7625bc:	mov    $0x2b,%esi
  7625c1:	call   *0x356a79(%rip)        # ab9040 <_DYNAMIC+0x310>
  7625c7:	jmp    762728 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2058>
  7625cc:	lea    0x336815(%rip),%rdi        # a98de8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x610>
  7625d3:	jmp    762243 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1b73>
  7625d8:	lea    0x3369e9(%rip),%rdx        # a98fc8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x7f0>
  7625df:	mov    $0x1,%edi
  7625e4:	mov    $0x1,%esi
  7625e9:	call   *0x3569b1(%rip)        # ab8fa0 <_DYNAMIC+0x270>
  7625ef:	jmp    762728 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2058>
  7625f4:	movq   $0xd,0x70(%rsp)
  7625fd:	movq   $0x0,0x78(%rsp)
  762606:	lea    -0x692af3(%rip),%rdi        # cfb1a <GCC_except_table0+0xd77a>
  76260d:	lea    0x337454(%rip),%rcx        # a99a68 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1290>
  762614:	lea    0x33726d(%rip),%r8        # a99888 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x10b0>
  76261b:	lea    0x70(%rsp),%rdx
  762620:	mov    $0x24,%esi
  762625:	call   *0x356a15(%rip)        # ab9040 <_DYNAMIC+0x310>
  76262b:	jmp    762728 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2058>
  762630:	movq   $0xd,0x30(%rsp)
  762639:	movq   $0x0,0x38(%rsp)
  762642:	mov    0x60(%rsp),%rax
  762647:	mov    %rax,0xa0(%rsp)
  76264f:	mov    0x30(%rsp),%rax
  762654:	mov    0x38(%rsp),%rcx
  762659:	movups 0x40(%rsp),%xmm0
  76265e:	movups 0x50(%rsp),%xmm1
  762663:	movaps %xmm1,0x90(%rsp)
  76266b:	movaps %xmm0,0x80(%rsp)
  762673:	mov    %rax,0x70(%rsp)
  762678:	mov    %rcx,0x78(%rsp)
  76267d:	lea    -0x692a5a(%rip),%rdi        # cfc2a <GCC_except_table0+0xd88a>
  762684:	lea    0x3373dd(%rip),%rcx        # a99a68 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1290>
  76268b:	lea    0x337166(%rip),%r8        # a997f8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1020>
  762692:	lea    0x70(%rsp),%rdx
  762697:	mov    $0x2b,%esi
  76269c:	call   *0x35699e(%rip)        # ab9040 <_DYNAMIC+0x310>
  7626a2:	jmp    762728 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2058>
  7626a7:	mov    $0xd,%eax
  7626ac:	jmp    7626ba <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1fea>
  7626ae:	mov    $0xe,%eax
  7626b3:	jmp    7626ba <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1fea>
  7626b5:	mov    $0x12,%eax
  7626ba:	mov    %rax,0x70(%rsp)
  7626bf:	movq   $0x0,0x78(%rsp)
  7626c8:	lea    -0x692aa5(%rip),%rdi        # cfc2a <GCC_except_table0+0xd88a>
  7626cf:	lea    0x337392(%rip),%rcx        # a99a68 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1290>
  7626d6:	lea    0x33717b(%rip),%r8        # a99858 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1080>
  7626dd:	lea    0x70(%rsp),%rdx
  7626e2:	mov    $0x2b,%esi
  7626e7:	call   *0x356953(%rip)        # ab9040 <_DYNAMIC+0x310>
  7626ed:	jmp    762728 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2058>
  7626ef:	mov    $0x8,%edi
  7626f4:	mov    $0xe0,%esi
  7626f9:	call   *0x356929(%rip)        # ab9028 <_DYNAMIC+0x2f8>
  7626ff:	jmp    762728 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2058>
  762701:	mov    $0x4,%edi
  762706:	mov    %rbx,%rsi
  762709:	call   *0x356919(%rip)        # ab9028 <_DYNAMIC+0x2f8>
  76270f:	jmp    762728 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2058>
  762711:	lea    0x3368b0(%rip),%rdx        # a98fc8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x7f0>
  762718:	mov    $0x1,%edi
  76271d:	mov    $0x1,%esi
  762722:	call   *0x356878(%rip)        # ab8fa0 <_DYNAMIC+0x270>
  762728:	ud2
  76272a:	mov    0x38(%rsp),%rdi
  76272f:	mov    $0x1,%edx
  762734:	call   *0x356836(%rip)        # ab8f70 <_DYNAMIC+0x240>
  76273a:	jmp    7624f3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1e23>
  76273f:	mov    0x188(%rsp),%rbx
  762747:	jmp    7624f3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1e23>
  76274c:	jmp    76274e <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x207e>
  76274e:	mov    %rax,%rbx
  762751:	mov    0x1c0(%rsp),%rax
  762759:	mov    $0x1,%bpl
  76275c:	test   %rax,%rax
  76275f:	je     762939 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2269>
  762765:	mov    0x1c8(%rsp),%rdi
  76276d:	imul   $0x38,%rax,%rsi
  762771:	mov    $0x8,%edx
  762776:	jmp    762933 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2263>
  76277b:	mov    %rax,%rbx
  76277e:	mov    $0x1,%bpl
  762781:	jmp    762918 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2248>
  762786:	jmp    76283d <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x216d>
  76278b:	jmp    76283d <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x216d>
  762790:	mov    %rax,%rbx
  762793:	jmp    7629c4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x22f4>
  762798:	mov    %rax,%rbx
  76279b:	xor    %ebp,%ebp
  76279d:	jmp    762946 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2276>
  7627a2:	jmp    76283d <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x216d>
  7627a7:	jmp    7628a6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x21d6>
  7627ac:	jmp    76283d <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x216d>
  7627b1:	jmp    762831 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2161>
  7627b3:	mov    %rax,%rbx
  7627b6:	jmp    7629a7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x22d7>
  7627bb:	jmp    7628c0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x21f0>
  7627c0:	mov    %rax,%rbx
  7627c3:	mov    0x30(%rsp),%rsi
  7627c8:	test   %rsi,%rsi
  7627cb:	jle    7628c3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x21f3>
  7627d1:	mov    0x38(%rsp),%rdi
  7627d6:	mov    $0x1,%edx
  7627db:	call   *0x35678f(%rip)        # ab8f70 <_DYNAMIC+0x240>
  7627e1:	jmp    7628c3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x21f3>
  7627e6:	mov    %rax,%rbx
  7627e9:	lea    0x70(%rsp),%rdi
  7627ee:	call   74c820 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5error5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  7627f3:	jmp    7628c3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x21f3>
  7627f8:	call   *0x35679a(%rip)        # ab8f98 <_DYNAMIC+0x268>
  7627fe:	mov    %rax,%rbx
  762801:	lea    0x70(%rsp),%rdi
  762806:	call   74d580 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  76280b:	jmp    7628a9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x21d9>
  762810:	mov    %rax,%rbx
  762813:	lea    0x30(%rsp),%rdi
  762818:	call   74dfa0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCscl5MXVnO7Zx_10serde_json5value3ser12SerializeMapECs9C2G9YFESsD_29canonical_text_public_control>
  76281d:	jmp    7628c3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x21f3>
  762822:	call   *0x356770(%rip)        # ab8f98 <_DYNAMIC+0x268>
  762828:	jmp    7628c0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x21f0>
  76282d:	jmp    7628a6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x21d6>
  76282f:	jmp    7628a6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x21d6>
  762831:	mov    %rax,%rbx
  762834:	jmp    7628e4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2214>
  762839:	jmp    76283d <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x216d>
  76283b:	jmp    76283d <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x216d>
  76283d:	mov    %rax,%rbx
  762840:	lea    0x70(%rsp),%rdi
  762845:	call   74d580 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  76284a:	jmp    7628c3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x21f3>
  76284c:	mov    %rax,%rbx
  76284f:	lea    0x70(%rsp),%rdi
  762854:	call   74d580 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  762859:	jmp    7628e4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2214>
  76285e:	mov    %rax,%rbx
  762861:	mov    $0x1,%bpl
  762864:	jmp    762982 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x22b2>
  762869:	mov    %rax,%rbx
  76286c:	mov    0x38(%rsp),%rdi
  762871:	call   74caf0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text10TextShaperECs9C2G9YFESsD_29canonical_text_public_control>
  762876:	mov    $0x1,%bpl
  762879:	jmp    762946 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2276>
  76287e:	mov    %rax,%rbx
  762881:	mov    0x168(%rsp),%rsi
  762889:	test   %rsi,%rsi
  76288c:	jne    762901 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2231>
  76288e:	jmp    762918 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2248>
  762893:	mov    %rax,%rbx
  762896:	jmp    762962 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2292>
  76289b:	mov    %rax,%rbx
  76289e:	mov    $0x1,%bpl
  7628a1:	jmp    762939 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2269>
  7628a6:	mov    %rax,%rbx
  7628a9:	mov    0x1f8(%rsp),%rsi
  7628b1:	test   %rsi,%rsi
  7628b4:	je     7628e4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2214>
  7628b6:	mov    0x200(%rsp),%rdi
  7628be:	jmp    7628d5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2205>
  7628c0:	mov    %rax,%rbx
  7628c3:	mov    0x8(%rsp),%rdi
  7628c8:	mov    0x110(%rsp),%rsi
  7628d0:	test   %rsi,%rsi
  7628d3:	je     7628e4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2214>
  7628d5:	shl    $0x4,%rsi
  7628d9:	mov    $0x4,%edx
  7628de:	call   *0x35668c(%rip)        # ab8f70 <_DYNAMIC+0x240>
  7628e4:	mov    0x10(%rsp),%r14
  7628e9:	test   %r14,%r14
  7628ec:	jne    7629bc <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x22ec>
  7628f2:	xor    %ebp,%ebp
  7628f4:	mov    0x168(%rsp),%rsi
  7628fc:	test   %rsi,%rsi
  7628ff:	je     762918 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2248>
  762901:	mov    0x170(%rsp),%rdi
  762909:	shl    $0x2,%rsi
  76290d:	mov    $0x4,%edx
  762912:	call   *0x356658(%rip)        # ab8f70 <_DYNAMIC+0x240>
  762918:	mov    0x108(%rsp),%rax
  762920:	test   %rax,%rax
  762923:	je     762939 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2269>
  762925:	imul   $0x38,%rax,%rsi
  762929:	mov    $0x8,%edx
  76292e:	mov    0x20(%rsp),%rdi
  762933:	call   *0x356637(%rip)        # ab8f70 <_DYNAMIC+0x240>
  762939:	lea    0x310(%rsp),%rdi
  762941:	call   74ca60 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text10TextLayoutECs9C2G9YFESsD_29canonical_text_public_control>
  762946:	mov    0x140(%rsp),%rax
  76294e:	lock decq (%rax)
  762952:	jne    762962 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2292>
  762954:	lea    0x140(%rsp),%rdi
  76295c:	call   *0x3566fe(%rip)        # ab9060 <_DYNAMIC+0x330>
  762962:	mov    0x240(%rsp),%rsi
  76296a:	test   %rsi,%rsi
  76296d:	je     762982 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x22b2>
  76296f:	mov    0x248(%rsp),%rdi
  762977:	mov    $0x1,%edx
  76297c:	call   *0x3565ee(%rip)        # ab8f70 <_DYNAMIC+0x240>
  762982:	mov    0x148(%rsp),%rsi
  76298a:	test   %rsi,%rsi
  76298d:	je     7629a2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x22d2>
  76298f:	mov    0x150(%rsp),%rdi
  762997:	mov    $0x1,%edx
  76299c:	call   *0x3565ce(%rip)        # ab8f70 <_DYNAMIC+0x240>
  7629a2:	test   %bpl,%bpl
  7629a5:	je     7629b4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x22e4>
  7629a7:	mov    0x228(%rsp),%rsi
  7629af:	test   %rsi,%rsi
  7629b2:	jne    7629ef <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x231f>
  7629b4:	mov    %rbx,%rdi
  7629b7:	call   a97420 <_Unwind_Resume@plt>
  7629bc:	mov    %r14,%rdi
  7629bf:	call   747d70 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui7runtime7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEEB1h_>
  7629c4:	mov    $0x770,%esi
  7629c9:	mov    $0x8,%edx
  7629ce:	mov    %r14,%rdi
  7629d1:	call   *0x356599(%rip)        # ab8f70 <_DYNAMIC+0x240>
  7629d7:	xor    %ebp,%ebp
  7629d9:	mov    0x168(%rsp),%rsi
  7629e1:	test   %rsi,%rsi
  7629e4:	jne    762901 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2231>
  7629ea:	jmp    762918 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2248>
  7629ef:	mov    0x230(%rsp),%rdi
  7629f7:	mov    $0x1,%edx
  7629fc:	call   *0x35656e(%rip)        # ab8f70 <_DYNAMIC+0x240>
  762a02:	mov    %rbx,%rdi
  762a05:	call   a97420 <_Unwind_Resume@plt>
  762a0a:	mov    $0x770,%esi
  762a0f:	mov    $0x8,%edx
  762a14:	mov    %r14,%rdi
  762a17:	call   *0x356553(%rip)        # ab8f70 <_DYNAMIC+0x240>
  762a1d:	call   *0x356575(%rip)        # ab8f98 <_DYNAMIC+0x268>
  762a23:	call   *0x35656f(%rip)        # ab8f98 <_DYNAMIC+0x268>

canonical_text_public_control::main bytes=9055 frame=776

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000762a30 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main>:
  762a30:	push   %rbp
  762a31:	push   %r15
  762a33:	push   %r14
  762a35:	push   %r13
  762a37:	push   %r12
  762a39:	push   %rbx
  762a3a:	sub    $0x2d8,%rsp
  762a41:	lea    0x60(%rsp),%rbx
  762a46:	mov    %rbx,%rdi
  762a49:	call   *0x356801(%rip)        # ab9250 <_DYNAMIC+0x520>
  762a4f:	movq   $0x0,0x80(%rsp)
  762a5b:	lea    0x150(%rsp),%rdi
  762a63:	mov    $0x1,%edx
  762a68:	mov    %rbx,%rsi
  762a6b:	call   798b90 <_RNvYNtNtCs2AWtUsOyxgP_3std3env4ArgsNtNtNtNtCs4NRVxsYgnAr_4core4iter6traits8iterator8Iterator3nthCs9C2G9YFESsD_29canonical_text_public_control>
  762a70:	mov    0x150(%rsp),%rax
  762a78:	mov    %rax,0x18(%rsp)
  762a7d:	cmp    $0xffffffffffffffff,%rax
  762a81:	je     764732 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1d02>
  762a87:	mov    0x158(%rsp),%rbx
  762a8f:	mov    0x78(%rsp),%rax
  762a94:	sub    0x68(%rsp),%rax
  762a99:	shr    $0x3,%rax
  762a9d:	movabs $0xaaaaaaaaaaaaaaab,%rcx
  762aa7:	imul   %rcx,%rax
  762aab:	xor    %r14d,%r14d
  762aae:	sub    0x80(%rsp),%rax
  762ab6:	cmovb  %r14,%rax
  762aba:	cmp    $0x4,%rax
  762abe:	mov    $0x3,%r12d
  762ac4:	cmovae %rax,%r12
  762ac8:	lea    0x8(,%r12,8),%rcx
  762ad0:	lea    (%rcx,%rcx,2),%r15
  762ad4:	movabs $0x555555555555554,%rcx
  762ade:	cmp    %rcx,%rax
  762ae1:	jbe    762af4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xc4>
  762ae3:	mov    %r14,%rdi
  762ae6:	mov    %r15,%rsi
  762ae9:	call   *0x356539(%rip)        # ab9028 <_DYNAMIC+0x2f8>
  762aef:	jmp    7647fd <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  762af4:	mov    0x160(%rsp),%rbp
  762afc:	test   %r15,%r15
  762aff:	je     762b28 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xf8>
  762b01:	call   *0x356471(%rip)        # ab8f78 <_DYNAMIC+0x248>
  762b07:	mov    $0x8,%r14d
  762b0d:	mov    $0x8,%esi
  762b12:	mov    %r15,%rdi
  762b15:	call   *0x356465(%rip)        # ab8f80 <_DYNAMIC+0x250>
  762b1b:	test   %rax,%rax
  762b1e:	je     762ae3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xb3>
  762b20:	mov    %rax,%r13
  762b23:	inc    %r12
  762b26:	jmp    762b31 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x101>
  762b28:	mov    $0x8,%r13d
  762b2e:	xor    %r12d,%r12d
  762b31:	mov    0x18(%rsp),%rax
  762b36:	mov    %rax,0x0(%r13)
  762b3a:	mov    %rbx,0x8(%r13)
  762b3e:	mov    %rbp,0x10(%r13)
  762b42:	mov    %r12,0x28(%rsp)
  762b47:	mov    %r13,0x30(%rsp)
  762b4c:	movq   $0x1,0x38(%rsp)
  762b55:	mov    0x80(%rsp),%rax
  762b5d:	mov    %rax,0x170(%rsp)
  762b65:	movups 0x60(%rsp),%xmm0
  762b6a:	movups 0x70(%rsp),%xmm1
  762b6f:	movaps %xmm1,0x160(%rsp)
  762b77:	movaps %xmm0,0x150(%rsp)
  762b7f:	mov    $0x1,%ebx
  762b84:	mov    $0x28,%r15d
  762b8a:	jmp    762bcb <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x19b>
  762b8c:	nopl   0x0(%rax)
  762b90:	inc    %rdx
  762b93:	mov    $0x8,%ecx
  762b98:	mov    $0x18,%r8d
  762b9e:	lea    0x28(%rsp),%rdi
  762ba3:	mov    %rbx,%rsi
  762ba6:	call   75b160 <_RINvNvMs2_NtCscdodAO9FK5_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs9C2G9YFESsD_29canonical_text_public_control>
  762bab:	mov    0x30(%rsp),%r13
  762bb0:	mov    %r14,-0x10(%r13,%r15,1)
  762bb5:	mov    %rbp,-0x8(%r13,%r15,1)
  762bba:	mov    %r12,0x0(%r13,%r15,1)
  762bbf:	inc    %rbx
  762bc2:	mov    %rbx,0x38(%rsp)
  762bc7:	add    $0x18,%r15
  762bcb:	mov    0x170(%rsp),%rdx
  762bd3:	test   %rdx,%rdx
  762bd6:	jne    762c4a <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x21a>
  762bd8:	lea    0x1f0(%rsp),%rdi
  762be0:	lea    0x150(%rsp),%rsi
  762be8:	call   *0x35666a(%rip)        # ab9258 <_DYNAMIC+0x528>
  762bee:	mov    0x1f0(%rsp),%r14
  762bf6:	cmp    $0xffffffffffffffff,%r14
  762bfa:	je     762c6d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x23d>
  762bfc:	mov    0x1f8(%rsp),%rbp
  762c04:	mov    0x200(%rsp),%r12
  762c0c:	cmp    0x28(%rsp),%rbx
  762c11:	jne    762bb0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x180>
  762c13:	mov    0x168(%rsp),%rdx
  762c1b:	sub    0x158(%rsp),%rdx
  762c23:	shr    $0x3,%rdx
  762c27:	movabs $0xaaaaaaaaaaaaaaab,%rax
  762c31:	imul   %rax,%rdx
  762c35:	sub    0x170(%rsp),%rdx
  762c3d:	jae    762b90 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x160>
  762c43:	xor    %edx,%edx
  762c45:	jmp    762b90 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x160>
  762c4a:	movq   $0x0,0x170(%rsp)
  762c56:	lea    0x1f0(%rsp),%rdi
  762c5e:	lea    0x150(%rsp),%rsi
  762c66:	call   798b90 <_RNvYNtNtCs2AWtUsOyxgP_3std3env4ArgsNtNtNtNtCs4NRVxsYgnAr_4core4iter6traits8iterator8Iterator3nthCs9C2G9YFESsD_29canonical_text_public_control>
  762c6b:	jmp    762bee <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1be>
  762c6d:	mov    0x158(%rsp),%r15
  762c75:	mov    0x168(%rsp),%rcx
  762c7d:	mov    %rcx,%rax
  762c80:	sub    %r15,%rax
  762c83:	movabs $0xaaaaaaaaaaaaaaab,%rdx
  762c8d:	mul    %rdx
  762c90:	cmp    %r15,%rcx
  762c93:	je     762ccf <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x29f>
  762c95:	mov    %rdx,%r14
  762c98:	shr    $0x4,%r14
  762c9c:	add    $0x8,%r15
  762ca0:	mov    0x3562c9(%rip),%r12        # ab8f70 <_DYNAMIC+0x240>
  762ca7:	jmp    762cb9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x289>
  762ca9:	nopl   0x0(%rax)
  762cb0:	add    $0x18,%r15
  762cb4:	dec    %r14
  762cb7:	je     762ccf <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x29f>
  762cb9:	mov    -0x8(%r15),%rsi
  762cbd:	test   %rsi,%rsi
  762cc0:	je     762cb0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x280>
  762cc2:	mov    (%r15),%rdi
  762cc5:	mov    $0x1,%edx
  762cca:	call   *%r12
  762ccd:	jmp    762cb0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x280>
  762ccf:	mov    0x160(%rsp),%rax
  762cd7:	test   %rax,%rax
  762cda:	je     762cf7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2c7>
  762cdc:	mov    0x150(%rsp),%rdi
  762ce4:	shl    $0x3,%rax
  762ce8:	lea    (%rax,%rax,2),%rsi
  762cec:	mov    $0x8,%edx
  762cf1:	call   *0x356279(%rip)        # ab8f70 <_DYNAMIC+0x240>
  762cf7:	mov    0x28(%rsp),%rax
  762cfc:	mov    %rax,0x288(%rsp)
  762d04:	mov    0x30(%rsp),%rax
  762d09:	mov    0x8(%rax),%rdi
  762d0d:	mov    %rax,0x20(%rsp)
  762d12:	mov    0x10(%rax),%rax
  762d16:	cmp    $0x6,%rax
  762d1a:	je     762d67 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x337>
  762d1c:	cmp    $0x7,%rax
  762d20:	jne    76478e <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1d5e>
  762d26:	mov    $0x7361656d,%eax
  762d2b:	xor    (%rdi),%eax
  762d2d:	mov    $0x65727573,%ecx
  762d32:	xor    0x3(%rdi),%ecx
  762d35:	or     %eax,%ecx
  762d37:	mov    $0x1,%r9b
  762d3a:	jne    76478e <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1d5e>
  762d40:	cmp    $0x3,%rbx
  762d44:	jbe    762da2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x372>
  762d46:	mov    0x20(%rsp),%rax
  762d4b:	mov    0x50(%rax),%rcx
  762d4f:	mov    0x58(%rax),%rsi
  762d53:	cmp    $0x1,%rsi
  762d57:	je     762dbc <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x38c>
  762d59:	test   %rsi,%rsi
  762d5c:	je     7647ff <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcf>
  762d62:	movzbl (%rcx),%edx
  762d65:	jmp    762dd3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x3a3>
  762d67:	mov    $0x6361726f,%eax
  762d6c:	xor    (%rdi),%eax
  762d6e:	movzwl 0x4(%rdi),%ecx
  762d72:	xor    $0x656c,%ecx
  762d78:	or     %eax,%ecx
  762d7a:	je     762e77 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x447>
  762d80:	mov    $0x69726576,%eax
  762d85:	xor    (%rdi),%eax
  762d87:	movzwl 0x4(%rdi),%ecx
  762d8b:	xor    $0x7966,%ecx
  762d91:	or     %eax,%ecx
  762d93:	jne    76478e <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1d5e>
  762d99:	xor    %r9d,%r9d
  762d9c:	cmp    $0x3,%rbx
  762da0:	ja     762d46 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x316>
  762da2:	lea    0x336bb7(%rip),%rdx        # a99960 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1188>
  762da9:	mov    $0x3,%edi
  762dae:	mov    %rbx,%rsi
  762db1:	call   *0x3561e9(%rip)        # ab8fa0 <_DYNAMIC+0x270>
  762db7:	jmp    7647fd <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  762dbc:	movzbl (%rcx),%edx
  762dbf:	mov    $0x1,%al
  762dc1:	cmp    $0x2b,%edx
  762dc4:	je     7642e0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x18b0>
  762dca:	cmp    $0x2d,%edx
  762dcd:	je     7642e0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x18b0>
  762dd3:	xor    %eax,%eax
  762dd5:	cmp    $0x2b,%dl
  762dd8:	sete   %al
  762ddb:	mov    %rsi,%rdx
  762dde:	sub    %rax,%rdx
  762de1:	add    %rax,%rcx
  762de4:	neg    %rax
  762de7:	cmp    $0x11,%rdx
  762deb:	jae    762e2e <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x3fe>
  762ded:	test   %rdx,%rdx
  762df0:	je     76347b <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xa4b>
  762df6:	add    %rax,%rsi
  762df9:	neg    %rsi
  762dfc:	xor    %eax,%eax
  762dfe:	xor    %edx,%edx
  762e00:	movzbl (%rcx,%rdx,1),%r8d
  762e05:	add    $0xffffffd0,%r8d
  762e09:	cmp    $0x9,%r8d
  762e0d:	ja     76450c <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1adc>
  762e13:	lea    (%rax,%rax,4),%rax
  762e17:	mov    %r8d,%r8d
  762e1a:	lea    (%r8,%rax,2),%rax
  762e1e:	inc    %rdx
  762e21:	mov    %rsi,%r8
  762e24:	add    %rdx,%r8
  762e27:	jne    762e00 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x3d0>
  762e29:	jmp    76347d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xa4d>
  762e2e:	add    %rax,%rsi
  762e31:	neg    %rsi
  762e34:	xor    %eax,%eax
  762e36:	mov    $0xa,%r8d
  762e3c:	xor    %r10d,%r10d
  762e3f:	nop
  762e40:	mov    %rsi,%rdx
  762e43:	add    %r10,%rdx
  762e46:	je     76347d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xa4d>
  762e4c:	mul    %r8
  762e4f:	movzbl (%rcx,%r10,1),%edx
  762e54:	jo     7642d6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x18a6>
  762e5a:	add    $0xffffffd0,%edx
  762e5d:	cmp    $0xa,%edx
  762e60:	jae    76450c <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1adc>
  762e66:	mov    %edx,%edx
  762e68:	inc    %r10
  762e6b:	add    %rdx,%rax
  762e6e:	jae    762e40 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x410>
  762e70:	mov    $0x2,%al
  762e72:	jmp    7642e0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x18b0>
  762e77:	movq   $0x0,0x150(%rsp)
  762e83:	movq   $0x8,0x158(%rsp)
  762e8f:	movups 0x3365fa(%rip),%xmm0        # a99490 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xcb8>
  762e96:	movups %xmm0,0x160(%rsp)
  762e9e:	movups 0x3365fb(%rip),%xmm0        # a994a0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xcc8>
  762ea5:	movups %xmm0,0x170(%rsp)
  762ead:	movups 0x3365fc(%rip),%xmm0        # a994b0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xcd8>
  762eb4:	movups %xmm0,0x180(%rsp)
  762ebc:	movups 0x3365fd(%rip),%xmm0        # a994c0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xce8>
  762ec3:	movups %xmm0,0x190(%rsp)
  762ecb:	movups 0x3365fe(%rip),%xmm0        # a994d0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xcf8>
  762ed2:	movups %xmm0,0x1a0(%rsp)
  762eda:	movups 0x3365ff(%rip),%xmm0        # a994e0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xd08>
  762ee1:	movups %xmm0,0x1b0(%rsp)
  762ee9:	movups 0x336600(%rip),%xmm0        # a994f0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xd18>
  762ef0:	movups %xmm0,0x1c0(%rsp)
  762ef8:	movups 0x336601(%rip),%xmm0        # a99500 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xd28>
  762eff:	movups %xmm0,0x1d0(%rsp)
  762f07:	mov    $0x1,%r14d
  762f0d:	lea    0x2b8(%rsp),%r15
  762f15:	lea    0x60(%rsp),%rbp
  762f1a:	xor    %r12d,%r12d
  762f1d:	jmp    762f66 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x536>
  762f1f:	nop
  762f20:	mov    $0x770,%esi
  762f25:	mov    $0x8,%edx
  762f2a:	mov    %r14,%rdi
  762f2d:	call   *0x35603d(%rip)        # ab8f70 <_DYNAMIC+0x240>
  762f33:	mov    0xf8(%rsp),%r14
  762f3b:	xor    %r12,%r14
  762f3e:	movabs $0x100000001b3,%rax
  762f48:	imul   %rax,%r14
  762f4c:	mov    %r13,0x2b0(%rsp)
  762f54:	mov    0x290(%rsp),%r12
  762f5c:	cmp    $0x8,%r12
  762f60:	je     763a86 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1056>
  762f66:	mov    %r12,%rax
  762f69:	shl    $0x4,%rax
  762f6d:	lea    0x160(%rsp),%rcx
  762f75:	mov    (%rcx,%rax,1),%rsi
  762f79:	mov    0x8(%rcx,%rax,1),%rdx
  762f7e:	mov    %r15,%rdi
  762f81:	call   765890 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source>
  762f86:	mov    %rbp,%rdi
  762f89:	mov    %r15,%rsi
  762f8c:	call   *0x356266(%rip)        # ab91f8 <_DYNAMIC+0x4c8>
  762f92:	mov    %rbp,%rdi
  762f95:	call   764d90 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount>
  762f9a:	mov    %rax,%r13
  762f9d:	mov    %rax,0x260(%rsp)
  762fa5:	cmpb   $0x0,0x76e(%rax)
  762fac:	jne    764555 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1b25>
  762fb2:	cmpb   $0x1,0x76a(%r13)
  762fba:	jne    76454e <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1b1e>
  762fc0:	mov    %r14,0xf8(%rsp)
  762fc8:	mov    0x5c0(%r13),%r15
  762fcf:	mov    $0x1a,%eax
  762fd4:	mov    %rax,0x1e8(%rsp)
  762fdc:	test   %r15,%r15
  762fdf:	je     764562 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1b32>
  762fe5:	inc    %r12
  762fe8:	mov    %r12,0x290(%rsp)
  762ff0:	mov    0x5b8(%r13),%rbp
  762ff7:	shl    $0x6,%r15
  762ffb:	lea    0x1e8(%r13),%r14
  763002:	xor    %r12d,%r12d
  763005:	jmp    76301d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x5ed>
  763007:	nopw   0x0(%rax,%rax,1)
  763010:	add    $0x40,%r12
  763014:	cmp    %r12,%r15
  763017:	je     764562 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1b32>
  76301d:	cmpb   $0x4,0x3d(%rbp,%r12,1)
  763023:	jne    763010 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x5e0>
  763025:	mov    0x20(%rbp,%r12,1),%rsi
  76302a:	mov    %r14,%rdi
  76302d:	call   *0x355ffd(%rip)        # ab9030 <_DYNAMIC+0x300>
  763033:	test   %al,%al
  763035:	je     763010 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x5e0>
  763037:	mov    0x20(%rbp,%r12,1),%rsi
  76303c:	add    $0x5f0,%r13
  763043:	mov    %r13,%rdi
  763046:	call   *0x356184(%rip)        # ab91d0 <_DYNAMIC+0x4a0>
  76304c:	mov    %rax,%r14
  76304f:	mov    %rdx,%r12
  763052:	mov    0x260(%rsp),%rsi
  76305a:	lea    0x100(%rsp),%rdi
  763062:	call   75c8f0 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_>
  763067:	mov    0x2c8(%rsp),%rax
  76306f:	mov    %rax,%rcx
  763072:	shr    $0x20,%rcx
  763076:	lea    0x2b8(%rsp),%r15
  76307e:	lea    0x60(%rsp),%rbp
  763083:	jne    764342 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1912>
  763089:	movl   $0x0,0x60(%rsp)
  763091:	movb   $0x1,0x64(%rsp)
  763096:	mov    %eax,0x68(%rsp)
  76309a:	movb   $0x1,0x6c(%rsp)
  76309f:	mov    0x260(%rsp),%rsi
  7630a7:	test   %rsi,%rsi
  7630aa:	je     7645ad <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1b7d>
  7630b0:	lea    0x1f0(%rsp),%rdi
  7630b8:	mov    %r14,0x18(%rsp)
  7630bd:	mov    %r14,%rdx
  7630c0:	mov    %r12,0x8(%rsp)
  7630c5:	mov    %r12,%rcx
  7630c8:	mov    %rbp,%r8
  7630cb:	call   76efc0 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE12select_inputB12_>
  7630d0:	cmpq   $0xfffffffffffffffe,0x1f0(%rsp)
  7630d9:	jne    7645c5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1b95>
  7630df:	mov    0x260(%rsp),%rax
  7630e7:	test   %rax,%rax
  7630ea:	je     764636 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1c06>
  7630f0:	cmpb   $0x0,0x76e(%rax)
  7630f7:	jne    764649 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1c19>
  7630fd:	mov    0x6d0(%rax),%r13
  763104:	test   %r13,%r13
  763107:	je     764650 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1c20>
  76310d:	mov    0x6d8(%rax),%r12
  763114:	mov    %rax,0x28(%rsp)
  763119:	lea    0x268(%rsp),%rax
  763121:	mov    %rax,0x30(%rsp)
  763126:	movb   $0x2,0x1fc(%rsp)
  76312e:	movq   $0x3,(%rsp)
  763136:	mov    %rbp,%rdi
  763139:	lea    0x28(%rsp),%rsi
  76313e:	mov    0x18(%rsp),%rdx
  763143:	mov    0x8(%rsp),%rcx
  763148:	lea    0x1f0(%rsp),%r8
  763150:	lea    -0x69375a(%rip),%r9        # cf9fd <GCC_except_table0+0xd65d>
  763157:	call   76f1f0 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_>
  76315c:	mov    0x60(%rsp),%rax
  763161:	cmp    $0xfffffffffffffffe,%rax
  763165:	je     764513 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ae3>
  76316b:	cmp    $0x23,%eax
  76316e:	jne    764513 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ae3>
  763174:	mov    0x260(%rsp),%rsi
  76317c:	mov    %rbp,%rdi
  76317f:	call   75c8f0 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_>
  763184:	mov    0x70(%rsp),%rdx
  763189:	cmp    0x110(%rsp),%rdx
  763191:	jne    7642bf <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x188f>
  763197:	mov    0x108(%rsp),%rsi
  76319f:	mov    0x68(%rsp),%r14
  7631a4:	mov    %r14,%rdi
  7631a7:	call   *0x35608b(%rip)        # ab9238 <bcmp@GLIBC_2.2.5>
  7631ad:	test   %eax,%eax
  7631af:	jne    7642bf <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x188f>
  7631b5:	mov    0x78(%rsp),%eax
  7631b9:	cmp    0x118(%rsp),%eax
  7631c0:	jne    7642bf <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x188f>
  7631c6:	movzbl 0x7c(%rsp),%eax
  7631cb:	cmp    0x11c(%rsp),%al
  7631d2:	jne    7642bf <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x188f>
  7631d8:	mov    0x80(%rsp),%eax
  7631df:	cmp    0x120(%rsp),%eax
  7631e6:	jne    7642bf <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x188f>
  7631ec:	movzbl 0x84(%rsp),%eax
  7631f4:	cmp    0x124(%rsp),%al
  7631fb:	jne    7642bf <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x188f>
  763201:	mov    0x88(%rsp),%rax
  763209:	cmp    0x128(%rsp),%rax
  763211:	jne    7642bf <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x188f>
  763217:	mov    0x90(%rsp),%rax
  76321f:	cmp    0x130(%rsp),%rax
  763227:	jne    7642bf <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x188f>
  76322d:	mov    0x60(%rsp),%rsi
  763232:	test   %rsi,%rsi
  763235:	je     763245 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x815>
  763237:	mov    $0x1,%edx
  76323c:	mov    %r14,%rdi
  76323f:	call   *0x355d2b(%rip)        # ab8f70 <_DYNAMIC+0x240>
  763245:	mov    0x260(%rsp),%rsi
  76324d:	test   %rsi,%rsi
  763250:	je     76469b <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1c6b>
  763256:	cmpb   $0x0,0x76e(%rsi)
  76325d:	jne    7646b5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1c85>
  763263:	lea    0x1f0(%rsp),%rdi
  76326b:	mov    %r13,%rdx
  76326e:	mov    %r12,%rcx
  763271:	call   77aeb0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_>
  763276:	cmpq   $0xfffffffffffffffe,0x1f0(%rsp)
  76327f:	jne    7646c1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1c91>
  763285:	mov    0x260(%rsp),%rsi
  76328d:	lea    0x28(%rsp),%rdi
  763292:	call   75c8f0 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_>
  763297:	mov    0x38(%rsp),%r14
  76329c:	cmp    0x2c8(%rsp),%r14
  7632a4:	jne    764314 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x18e4>
  7632aa:	mov    0x2c0(%rsp),%rsi
  7632b2:	mov    0x30(%rsp),%rdi
  7632b7:	mov    %r14,%rdx
  7632ba:	call   *0x355f78(%rip)        # ab9238 <bcmp@GLIBC_2.2.5>
  7632c0:	test   %eax,%eax
  7632c2:	jne    764314 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x18e4>
  7632c8:	mov    %r14,%rax
  7632cb:	shr    $0x20,%rax
  7632cf:	jne    764354 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1924>
  7632d5:	movl   $0x0,0x60(%rsp)
  7632dd:	movb   $0x1,0x64(%rsp)
  7632e2:	mov    %r14d,0x68(%rsp)
  7632e7:	movb   $0x1,0x6c(%rsp)
  7632ec:	cmpl   $0x0,0x40(%rsp)
  7632f1:	jne    763441 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xa11>
  7632f7:	movzbl 0x44(%rsp),%eax
  7632fc:	cmp    %r14d,0x48(%rsp)
  763301:	sete   %cl
  763304:	test   %al,%al
  763306:	je     763453 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xa23>
  76330c:	test   %cl,%cl
  76330e:	je     76345d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xa2d>
  763314:	movzbl 0x4c(%rsp),%eax
  763319:	test   %al,%al
  76331b:	je     763467 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xa37>
  763321:	mov    %r12,0x10(%rsp)
  763326:	mov    0x50(%rsp),%rcx
  76332b:	mov    0x58(%rsp),%r12
  763330:	mov    %rcx,0x1f0(%rsp)
  763338:	mov    %r12,0x1f8(%rsp)
  763340:	mov    0x128(%rsp),%rdx
  763348:	mov    0x130(%rsp),%rax
  763350:	mov    %rdx,0x60(%rsp)
  763355:	mov    %rax,0x68(%rsp)
  76335a:	cmp    %rdx,%rcx
  76335d:	jne    76432b <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x18fb>
  763363:	cmp    %rax,%r12
  763366:	jne    76432b <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x18fb>
  76336c:	lea    0x1f0(%rsp),%rdi
  763374:	lea    0x260(%rsp),%rsi
  76337c:	lea    0x336235(%rip),%rdx        # a995b8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xde0>
  763383:	mov    %r15,%rcx
  763386:	call   744830 <_RINvMst_NtCslbxve4rcJus_4gpui7runtimeINtB6_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE3setNtNtCscdodAO9FK5_5alloc6string6StringEBL_>
  76338b:	cmpl   $0xffffffff,0x1f0(%rsp)
  763393:	jne    764366 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1936>
  763399:	mov    0x260(%rsp),%rsi
  7633a1:	mov    %rbp,%rdi
  7633a4:	call   760560 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack>
  7633a9:	mov    0x260(%rsp),%rsi
  7633b1:	mov    %rbp,%rdi
  7633b4:	call   75c8f0 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_>
  7633b9:	mov    0x90(%rsp),%rax
  7633c1:	cmp    0x130(%rsp),%rax
  7633c9:	jne    7643fa <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x19ca>
  7633cf:	mov    0x60(%rsp),%rsi
  7633d4:	test   %rsi,%rsi
  7633d7:	je     7633e9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x9b9>
  7633d9:	mov    0x68(%rsp),%rdi
  7633de:	mov    $0x1,%edx
  7633e3:	call   *0x355b87(%rip)        # ab8f70 <_DYNAMIC+0x240>
  7633e9:	mov    0x28(%rsp),%rsi
  7633ee:	test   %rsi,%rsi
  7633f1:	je     763403 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x9d3>
  7633f3:	mov    0x30(%rsp),%rdi
  7633f8:	mov    $0x1,%edx
  7633fd:	call   *0x355b6d(%rip)        # ab8f70 <_DYNAMIC+0x240>
  763403:	mov    0x100(%rsp),%rsi
  76340b:	test   %rsi,%rsi
  76340e:	je     763423 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x9f3>
  763410:	mov    0x108(%rsp),%rdi
  763418:	mov    $0x1,%edx
  76341d:	call   *0x355b4d(%rip)        # ab8f70 <_DYNAMIC+0x240>
  763423:	mov    0x260(%rsp),%r14
  76342b:	test   %r14,%r14
  76342e:	je     762f33 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x503>
  763434:	mov    %r14,%rdi
  763437:	call   747d70 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui7runtime7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEEB1h_>
  76343c:	jmp    762f20 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x4f0>
  763441:	xor    %eax,%eax
  763443:	cmp    %r14d,0x48(%rsp)
  763448:	sete   %cl
  76344b:	test   %al,%al
  76344d:	jne    76330c <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x8dc>
  763453:	xor    %ecx,%ecx
  763455:	test   %cl,%cl
  763457:	jne    763314 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x8e4>
  76345d:	xor    %eax,%eax
  76345f:	test   %al,%al
  763461:	jne    763321 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x8f1>
  763467:	lea    0x60(%rsp),%rsi
  76346c:	lea    0x40(%rsp),%rdi
  763471:	call   74f335 <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout13TextSelectionBM_ECs9C2G9YFESsD_29canonical_text_public_control>
  763476:	jmp    7647fd <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  76347b:	xor    %eax,%eax
  76347d:	mov    0x20(%rsp),%r8
  763482:	mov    0x20(%r8),%rsi
  763486:	mov    0x28(%r8),%rdx
  76348a:	mov    0x38(%r8),%rcx
  76348e:	mov    0x40(%r8),%r8
  763492:	test   %r9b,%r9b
  763495:	je     7634b3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xa83>
  763497:	mov    $0x7361656d,%r9d
  76349d:	xor    (%rdi),%r9d
  7634a0:	mov    $0x65727573,%r10d
  7634a6:	xor    0x3(%rdi),%r10d
  7634aa:	or     %r9d,%r10d
  7634ad:	sete   %dil
  7634b1:	jmp    7634b5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xa85>
  7634b3:	xor    %edi,%edi
  7634b5:	movzbl %dil,%edi
  7634b9:	mov    %edi,(%rsp)
  7634bc:	lea    0x150(%rsp),%rdi
  7634c4:	mov    %rax,%r15
  7634c7:	mov    %rax,%r9
  7634ca:	call   7606d0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run>
  7634cf:	mov    0x160(%rsp),%rax
  7634d7:	mov    %rax,0x18(%rsp)
  7634dc:	mov    0x150(%rsp),%rax
  7634e4:	mov    %rax,0x8(%rsp)
  7634e9:	mov    0x158(%rsp),%rax
  7634f1:	mov    %rax,0xf8(%rsp)
  7634f9:	movups 0x178(%rsp),%xmm0
  763501:	movaps %xmm0,0x200(%rsp)
  763509:	movups 0x168(%rsp),%xmm0
  763511:	movaps %xmm0,0x1f0(%rsp)
  763519:	movq   $0x0,0x100(%rsp)
  763525:	movq   $0x0,0x110(%rsp)
  763531:	call   *0x355a41(%rip)        # ab8f78 <_DYNAMIC+0x248>
  763537:	mov    $0x4,%r13d
  76353d:	mov    $0x1,%ebp
  763542:	mov    $0x4,%edi
  763547:	mov    $0x1,%esi
  76354c:	call   *0x355a2e(%rip)        # ab8f80 <_DYNAMIC+0x250>
  763552:	test   %rax,%rax
  763555:	je     76453b <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1b0b>
  76355b:	movl   $0x65736163,(%rax)
  763561:	movq   $0x4,0x28(%rsp)
  76356a:	mov    %rax,0x30(%rsp)
  76356f:	movq   $0x4,0x38(%rsp)
  763578:	mov    0x20(%rsp),%rcx
  76357d:	mov    0x28(%rcx),%r12
  763581:	test   %r12,%r12
  763584:	je     7635c1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xb91>
  763586:	mov    %rax,%r13
  763589:	mov    0x20(%rsp),%rax
  76358e:	mov    0x20(%rax),%r14
  763592:	call   *0x3559e0(%rip)        # ab8f78 <_DYNAMIC+0x248>
  763598:	mov    $0x1,%esi
  76359d:	mov    %r12,%rdi
  7635a0:	call   *0x3559da(%rip)        # ab8f80 <_DYNAMIC+0x250>
  7635a6:	test   %rax,%rax
  7635a9:	je     7647df <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1daf>
  7635af:	mov    %rax,%rbp
  7635b2:	mov    %rax,%rdi
  7635b5:	mov    %r14,%rsi
  7635b8:	mov    %r12,%rdx
  7635bb:	call   *0x3559cf(%rip)        # ab8f90 <memcpy@GLIBC_2.14>
  7635c1:	movb   $0x3,0x150(%rsp)
  7635c9:	mov    %r12,0x158(%rsp)
  7635d1:	mov    %rbp,0x160(%rsp)
  7635d9:	mov    %r12,0x168(%rsp)
  7635e1:	lea    0x60(%rsp),%rdi
  7635e6:	lea    0x100(%rsp),%rsi
  7635ee:	lea    0x28(%rsp),%rdx
  7635f3:	lea    0x150(%rsp),%rcx
  7635fb:	call   775c20 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  763600:	cmpb   $0xff,0x60(%rsp)
  763605:	je     763611 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xbe1>
  763607:	lea    0x60(%rsp),%rdi
  76360c:	call   74c910 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  763611:	call   *0x355961(%rip)        # ab8f78 <_DYNAMIC+0x248>
  763617:	mov    $0x9,%r13d
  76361d:	mov    $0x1,%r12d
  763623:	mov    $0x9,%edi
  763628:	mov    $0x1,%esi
  76362d:	call   *0x35594d(%rip)        # ab8f80 <_DYNAMIC+0x250>
  763633:	test   %rax,%rax
  763636:	je     76453b <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1b0b>
  76363c:	movabs $0x6f6974617265706f,%rcx
  763646:	mov    %rcx,(%rax)
  763649:	movb   $0x6e,0x8(%rax)
  76364d:	movq   $0x9,0x28(%rsp)
  763656:	mov    %rax,0x30(%rsp)
  76365b:	movq   $0x9,0x38(%rsp)
  763664:	mov    0x20(%rsp),%rcx
  763669:	mov    0x40(%rcx),%r13
  76366d:	test   %r13,%r13
  763670:	je     7636ad <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xc7d>
  763672:	mov    %rax,%rbp
  763675:	mov    0x20(%rsp),%rax
  76367a:	mov    0x38(%rax),%r14
  76367e:	call   *0x3558f4(%rip)        # ab8f78 <_DYNAMIC+0x248>
  763684:	mov    $0x1,%esi
  763689:	mov    %r13,%rdi
  76368c:	call   *0x3558ee(%rip)        # ab8f80 <_DYNAMIC+0x250>
  763692:	test   %rax,%rax
  763695:	je     7647ef <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dbf>
  76369b:	mov    %rax,%r12
  76369e:	mov    %rax,%rdi
  7636a1:	mov    %r14,%rsi
  7636a4:	mov    %r13,%rdx
  7636a7:	call   *0x3558e3(%rip)        # ab8f90 <memcpy@GLIBC_2.14>
  7636ad:	movb   $0x3,0x150(%rsp)
  7636b5:	mov    %r13,0x158(%rsp)
  7636bd:	mov    %r12,0x160(%rsp)
  7636c5:	mov    %r13,0x168(%rsp)
  7636cd:	lea    0x60(%rsp),%rdi
  7636d2:	lea    0x100(%rsp),%rsi
  7636da:	lea    0x28(%rsp),%rdx
  7636df:	lea    0x150(%rsp),%rcx
  7636e7:	call   775c20 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  7636ec:	cmpb   $0xff,0x60(%rsp)
  7636f1:	je     7636fd <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xccd>
  7636f3:	lea    0x60(%rsp),%rdi
  7636f8:	call   74c910 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  7636fd:	call   *0x355875(%rip)        # ab8f78 <_DYNAMIC+0x248>
  763703:	mov    $0x5,%r13d
  763709:	mov    $0x5,%edi
  76370e:	mov    $0x1,%esi
  763713:	call   *0x355867(%rip)        # ab8f80 <_DYNAMIC+0x250>
  763719:	test   %rax,%rax
  76371c:	je     76453b <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1b0b>
  763722:	movb   $0x74,0x4(%rax)
  763726:	movl   $0x6e756f63,(%rax)
  76372c:	movq   $0x5,0x28(%rsp)
  763735:	mov    %rax,0x30(%rsp)
  76373a:	movq   $0x5,0x38(%rsp)
  763743:	movb   $0x2,0x150(%rsp)
  76374b:	movq   $0x0,0x158(%rsp)
  763757:	mov    %r15,0x160(%rsp)
  76375f:	lea    0x60(%rsp),%rdi
  763764:	lea    0x100(%rsp),%rsi
  76376c:	lea    0x28(%rsp),%rdx
  763771:	lea    0x150(%rsp),%rcx
  763779:	call   775c20 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  76377e:	cmpb   $0xff,0x60(%rsp)
  763783:	je     76378f <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xd5f>
  763785:	lea    0x60(%rsp),%rdi
  76378a:	call   74c910 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  76378f:	call   *0x3557e3(%rip)        # ab8f78 <_DYNAMIC+0x248>
  763795:	mov    $0x8,%r13d
  76379b:	mov    $0x8,%edi
  7637a0:	mov    $0x1,%esi
  7637a5:	call   *0x3557d5(%rip)        # ab8f80 <_DYNAMIC+0x250>
  7637ab:	test   %rax,%rax
  7637ae:	je     76453b <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1b0b>
  7637b4:	movabs $0x6d75736b63656863,%rcx
  7637be:	mov    %rcx,(%rax)
  7637c1:	movq   $0x8,0x28(%rsp)
  7637ca:	mov    %rax,0x30(%rsp)
  7637cf:	movq   $0x8,0x38(%rsp)
  7637d8:	movb   $0x2,0x150(%rsp)
  7637e0:	movq   $0x0,0x158(%rsp)
  7637ec:	mov    0x18(%rsp),%rax
  7637f1:	mov    %rax,0x160(%rsp)
  7637f9:	lea    0x60(%rsp),%rdi
  7637fe:	lea    0x100(%rsp),%rsi
  763806:	lea    0x28(%rsp),%rdx
  76380b:	lea    0x150(%rsp),%rcx
  763813:	call   775c20 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  763818:	cmpb   $0xff,0x60(%rsp)
  76381d:	je     763829 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xdf9>
  76381f:	lea    0x60(%rsp),%rdi
  763824:	call   74c910 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  763829:	call   *0x355749(%rip)        # ab8f78 <_DYNAMIC+0x248>
  76382f:	mov    $0xa,%r13d
  763835:	mov    $0xa,%edi
  76383a:	mov    $0x1,%esi
  76383f:	call   *0x35573b(%rip)        # ab8f80 <_DYNAMIC+0x250>
  763845:	test   %rax,%rax
  763848:	je     76453b <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1b0b>
  76384e:	mov    %rax,%r12
  763851:	movabs $0x5f64657370616c65,%rax
  76385b:	mov    %rax,(%r12)
  76385f:	movw   $0x736e,0x8(%r12)
  763867:	movq   $0xa,0x28(%rsp)
  763870:	mov    %r12,0x30(%rsp)
  763875:	movq   $0xa,0x38(%rsp)
  76387e:	lea    0x150(%rsp),%rdi
  763886:	mov    0x8(%rsp),%rsi
  76388b:	mov    0xf8(%rsp),%rdx
  763893:	call   *0x3559c7(%rip)        # ab9260 <_DYNAMIC+0x530>
  763899:	cmpb   $0xff,0x150(%rsp)
  7638a1:	je     76444a <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1a1a>
  7638a7:	movups 0x150(%rsp),%xmm0
  7638af:	movups 0x160(%rsp),%xmm1
  7638b7:	movaps %xmm1,0x70(%rsp)
  7638bc:	movaps %xmm0,0x60(%rsp)
  7638c1:	lea    0x150(%rsp),%rdi
  7638c9:	lea    0x100(%rsp),%rsi
  7638d1:	lea    0x28(%rsp),%rdx
  7638d6:	lea    0x60(%rsp),%rcx
  7638db:	call   775c20 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  7638e0:	cmpb   $0xff,0x150(%rsp)
  7638e8:	je     7638f7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xec7>
  7638ea:	lea    0x150(%rsp),%rdi
  7638f2:	call   74c910 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  7638f7:	call   *0x35567b(%rip)        # ab8f78 <_DYNAMIC+0x248>
  7638fd:	mov    $0x8,%r13d
  763903:	mov    $0x8,%edi
  763908:	mov    $0x1,%esi
  76390d:	call   *0x35566d(%rip)        # ab8f80 <_DYNAMIC+0x250>
  763913:	test   %rax,%rax
  763916:	je     76453b <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1b0b>
  76391c:	mov    %rax,%r14
  76391f:	movabs $0x737265746e756f63,%rax
  763929:	mov    %rax,(%r14)
  76392c:	movq   $0x8,0x28(%rsp)
  763935:	mov    %r14,0x30(%rsp)
  76393a:	movq   $0x8,0x38(%rsp)
  763943:	lea    0x150(%rsp),%rdi
  76394b:	lea    0x1f0(%rsp),%rsi
  763953:	call   75b1e0 <_RINvXNtNtCscl5MXVnO7Zx_10serde_json5value3serNtB5_5ValueNtNtCs8znKHa7cbRS_10serde_core3ser9Serialize9serializeNtB3_10SerializerECs9C2G9YFESsD_29canonical_text_public_control>
  763958:	cmpb   $0xff,0x150(%rsp)
  763960:	je     764481 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1a51>
  763966:	movups 0x150(%rsp),%xmm0
  76396e:	movups 0x160(%rsp),%xmm1
  763976:	movaps %xmm1,0x70(%rsp)
  76397b:	movaps %xmm0,0x60(%rsp)
  763980:	lea    0x150(%rsp),%r14
  763988:	lea    0x100(%rsp),%rsi
  763990:	lea    0x28(%rsp),%rdx
  763995:	lea    0x60(%rsp),%rcx
  76399a:	mov    %r14,%rdi
  76399d:	call   775c20 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  7639a2:	cmpb   $0xff,0x150(%rsp)
  7639aa:	je     7639b9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xf89>
  7639ac:	lea    0x150(%rsp),%rdi
  7639b4:	call   74c910 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  7639b9:	movups 0x100(%rsp),%xmm0
  7639c1:	movups %xmm0,0x158(%rsp)
  7639c9:	mov    0x110(%rsp),%rax
  7639d1:	mov    %rax,0x168(%rsp)
  7639d9:	movb   $0x5,0x150(%rsp)
  7639e1:	mov    %r14,0x60(%rsp)
  7639e6:	mov    0x35587b(%rip),%rax        # ab9268 <_DYNAMIC+0x538>
  7639ed:	mov    %rax,0x68(%rsp)
  7639f2:	lea    -0x69ed17(%rip),%rdi        # c4ce2 <GCC_except_table0+0x2942>
  7639f9:	lea    0x60(%rsp),%rsi
  7639fe:	call   *0x35586c(%rip)        # ab9270 <_DYNAMIC+0x540>
  763a04:	lea    0x150(%rsp),%rdi
  763a0c:	call   74c910 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  763a11:	lea    0x1f0(%rsp),%rdi
  763a19:	call   74c910 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  763a1e:	mov    0x20(%rsp),%rax
  763a23:	lea    0x8(%rax),%r14
  763a27:	mov    0x355542(%rip),%r15        # ab8f70 <_DYNAMIC+0x240>
  763a2e:	jmp    763a39 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1009>
  763a30:	add    $0x18,%r14
  763a34:	dec    %rbx
  763a37:	je     763a4f <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x101f>
  763a39:	mov    -0x8(%r14),%rsi
  763a3d:	test   %rsi,%rsi
  763a40:	je     763a30 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1000>
  763a42:	mov    (%r14),%rdi
  763a45:	mov    $0x1,%edx
  763a4a:	call   *%r15
  763a4d:	jmp    763a30 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1000>
  763a4f:	mov    0x288(%rsp),%rax
  763a57:	test   %rax,%rax
  763a5a:	je     763a74 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1044>
  763a5c:	shl    $0x3,%rax
  763a60:	lea    (%rax,%rax,2),%rsi
  763a64:	mov    $0x8,%edx
  763a69:	mov    0x20(%rsp),%rdi
  763a6e:	call   *0x3554fc(%rip)        # ab8f70 <_DYNAMIC+0x240>
  763a74:	add    $0x2d8,%rsp
  763a7b:	pop    %rbx
  763a7c:	pop    %r12
  763a7e:	pop    %r13
  763a80:	pop    %r14
  763a82:	pop    %r15
  763a84:	pop    %rbp
  763a85:	ret
  763a86:	mov    %r14,0x60(%rsp)
  763a8b:	mov    %rbp,0x150(%rsp)
  763a93:	mov    0x3557de(%rip),%rax        # ab9278 <_DYNAMIC+0x548>
  763a9a:	mov    %rax,0x158(%rsp)
  763aa2:	lea    -0x699d46(%rip),%rdi        # c9d63 <GCC_except_table0+0x79c3>
  763aa9:	lea    0x150(%rsp),%rsi
  763ab1:	call   *0x3557b9(%rip)        # ab9270 <_DYNAMIC+0x540>
  763ab7:	movq   $0x0,0x60(%rsp)
  763ac0:	movq   $0x8,0x68(%rsp)
  763ac9:	movups 0x3359c0(%rip),%xmm0        # a99490 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xcb8>
  763ad0:	movups %xmm0,0x70(%rsp)
  763ad5:	movups 0x3359c4(%rip),%xmm0        # a994a0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xcc8>
  763adc:	movups %xmm0,0x80(%rsp)
  763ae4:	movups 0x3359c5(%rip),%xmm0        # a994b0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xcd8>
  763aeb:	movups %xmm0,0x90(%rsp)
  763af3:	movups 0x3359c6(%rip),%xmm0        # a994c0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xce8>
  763afa:	movups %xmm0,0xa0(%rsp)
  763b02:	movups 0x3359c7(%rip),%xmm0        # a994d0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xcf8>
  763b09:	movups %xmm0,0xb0(%rsp)
  763b11:	movups 0x3359c8(%rip),%xmm0        # a994e0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xd08>
  763b18:	movups %xmm0,0xc0(%rsp)
  763b20:	movups 0x3359c9(%rip),%xmm0        # a994f0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xd18>
  763b27:	movups %xmm0,0xd0(%rsp)
  763b2f:	movups 0x3359ca(%rip),%xmm0        # a99500 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xd28>
  763b36:	movups %xmm0,0xe0(%rsp)
  763b3e:	xor    %eax,%eax
  763b40:	lea    0x1f0(%rsp),%r15
  763b48:	jmp    763b5f <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x112f>
  763b4a:	nopw   0x0(%rax,%rax,1)
  763b50:	mov    0x10(%rsp),%rax
  763b55:	cmp    $0x8,%rax
  763b59:	je     763a1e <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xfee>
  763b5f:	lea    0x1(%rax),%rcx
  763b63:	mov    %rcx,0x10(%rsp)
  763b68:	shl    $0x4,%rax
  763b6c:	lea    0x70(%rsp),%rcx
  763b71:	mov    (%rcx,%rax,1),%rdx
  763b75:	mov    %rdx,0x18(%rsp)
  763b7a:	mov    0x8(%rcx,%rax,1),%r12
  763b7f:	movq   $0x0,0x150(%rsp)
  763b8b:	movq   $0x8,0x158(%rsp)
  763b97:	lea    -0x694060(%rip),%rax        # cfb3e <GCC_except_table0+0xd79e>
  763b9e:	mov    %rax,0x160(%rsp)
  763ba6:	movq   $0x3,0x168(%rsp)
  763bb2:	lea    -0x694078(%rip),%rax        # cfb41 <GCC_except_table0+0xd7a1>
  763bb9:	mov    %rax,0x170(%rsp)
  763bc1:	movq   $0x9,0x178(%rsp)
  763bcd:	lea    -0x69408a(%rip),%rax        # cfb4a <GCC_except_table0+0xd7aa>
  763bd4:	mov    %rax,0x180(%rsp)
  763bdc:	movq   $0x6,0x188(%rsp)
  763be8:	lea    -0x69409f(%rip),%rax        # cfb50 <GCC_except_table0+0xd7b0>
  763bef:	mov    %rax,0x190(%rsp)
  763bf7:	movq   $0x9,0x198(%rsp)
  763c03:	lea    -0x6940b1(%rip),%rax        # cfb59 <GCC_except_table0+0xd7b9>
  763c0a:	mov    %rax,0x1a0(%rsp)
  763c12:	movq   $0x7,0x1a8(%rsp)
  763c1e:	lea    -0x694112(%rip),%rax        # cfb13 <GCC_except_table0+0xd773>
  763c25:	mov    %rax,0x1b0(%rsp)
  763c2d:	movq   $0x7,0x1b8(%rsp)
  763c39:	lea    -0x694132(%rip),%rax        # cfb0e <GCC_except_table0+0xd76e>
  763c40:	mov    %rax,0x1c0(%rsp)
  763c48:	movq   $0x5,0x1c8(%rsp)
  763c54:	lea    -0x6a1827(%rip),%rax        # c2434 <GCC_except_table0+0x94>
  763c5b:	mov    %rax,0x1d0(%rsp)
  763c63:	movq   $0x4,0x1d8(%rsp)
  763c6f:	mov    $0x1,%eax
  763c74:	mov    %rax,0x8(%rsp)
  763c79:	lea    0x168(%rsp),%r13
  763c81:	mov    %r12,0xf8(%rsp)
  763c89:	jmp    763cab <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x127b>
  763c8b:	nopl   0x0(%rax,%rax,1)
  763c90:	add    $0x10,%r13
  763c94:	mov    0x8(%rsp),%rax
  763c99:	inc    %rax
  763c9c:	mov    %rax,0x8(%rsp)
  763ca1:	cmp    $0x9,%rax
  763ca5:	je     763b50 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1120>
  763cab:	mov    -0x8(%r13),%r8
  763caf:	mov    0x0(%r13),%r14
  763cb3:	cmp    $0x4,%r12
  763cb7:	je     763d60 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1330>
  763cbd:	cmp    $0x5,%r12
  763cc1:	je     763d10 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x12e0>
  763cc3:	cmp    $0xd,%r12
  763cc7:	jne    763d89 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1359>
  763ccd:	mov    0x18(%rsp),%rdx
  763cd2:	mov    (%rdx),%rcx
  763cd5:	movabs $0x6172672d676e6f6c,%rax
  763cdf:	xor    %rax,%rcx
  763ce2:	mov    0x5(%rdx),%rdx
  763ce6:	movabs $0x656d656870617267,%rax
  763cf0:	xor    %rax,%rdx
  763cf3:	xor    %eax,%eax
  763cf5:	or     %rcx,%rdx
  763cf8:	setne  %cl
  763cfb:	cmp    $0x4,%r14
  763cff:	je     763d76 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1346>
  763d01:	jmp    763d89 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1359>
  763d06:	cs nopw 0x0(%rax,%rax,1)
  763d10:	mov    0x18(%rsp),%rdx
  763d15:	mov    (%rdx),%ecx
  763d17:	mov    $0x74706d65,%eax
  763d1c:	xor    %eax,%ecx
  763d1e:	movzbl 0x4(%rdx),%edx
  763d22:	xor    $0x79,%edx
  763d25:	xor    %eax,%eax
  763d27:	or     %ecx,%edx
  763d29:	setne  %al
  763d2c:	cmp    $0x5,%r14
  763d30:	jne    76425f <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x182f>
  763d36:	test   %eax,%eax
  763d38:	jne    76425f <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x182f>
  763d3e:	mov    (%r8),%eax
  763d41:	mov    $0x6f727261,%ecx
  763d46:	xor    %ecx,%eax
  763d48:	movzbl 0x4(%r8),%ecx
  763d4d:	xor    $0x77,%ecx
  763d50:	or     %eax,%ecx
  763d52:	jne    763d89 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1359>
  763d54:	jmp    763c90 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1260>
  763d59:	nopl   0x0(%rax)
  763d60:	xor    %eax,%eax
  763d62:	mov    0x18(%rsp),%rcx
  763d67:	cmpl   $0x796e6974,(%rcx)
  763d6d:	setne  %cl
  763d70:	cmp    $0x4,%r14
  763d74:	jne    763d89 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1359>
  763d76:	mov    %cl,%al
  763d78:	test   %eax,%eax
  763d7a:	jne    763d89 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1359>
  763d7c:	cmpl   $0x67617264,(%r8)
  763d83:	je     763c90 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1260>
  763d89:	movl   $0x0,(%rsp)
  763d90:	mov    $0x4,%r9d
  763d96:	mov    %r15,%rdi
  763d99:	mov    0x18(%rsp),%rsi
  763d9e:	mov    %r12,%rdx
  763da1:	mov    %r8,%rbp
  763da4:	mov    %r8,%rcx
  763da7:	mov    %r14,%r8
  763daa:	call   7606d0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run>
  763daf:	mov    %r13,0x1e8(%rsp)
  763db7:	mov    0x200(%rsp),%rax
  763dbf:	mov    %rax,0x290(%rsp)
  763dc7:	lea    0x208(%rsp),%rax
  763dcf:	movups (%rax),%xmm0
  763dd2:	movups 0x10(%rax),%xmm1
  763dd6:	movaps %xmm1,0x270(%rsp)
  763dde:	movaps %xmm0,0x260(%rsp)
  763de6:	movq   $0x0,0x298(%rsp)
  763df2:	movq   $0x0,0x2a8(%rsp)
  763dfe:	call   *0x355174(%rip)        # ab8f78 <_DYNAMIC+0x248>
  763e04:	mov    $0x4,%r15d
  763e0a:	mov    $0x4,%edi
  763e0f:	mov    $0x1,%esi
  763e14:	call   *0x355166(%rip)        # ab8f80 <_DYNAMIC+0x250>
  763e1a:	test   %rax,%rax
  763e1d:	je     764420 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x19f0>
  763e23:	mov    %rax,%r13
  763e26:	movl   $0x65736163,(%rax)
  763e2c:	movq   $0x4,0x138(%rsp)
  763e38:	mov    %rax,0x140(%rsp)
  763e40:	movq   $0x4,0x148(%rsp)
  763e4c:	mov    0xf8(%rsp),%r12
  763e54:	test   %r12,%r12
  763e57:	je     763e90 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1460>
  763e59:	call   *0x355119(%rip)        # ab8f78 <_DYNAMIC+0x248>
  763e5f:	mov    $0x1,%esi
  763e64:	mov    %r12,%rdi
  763e67:	call   *0x355113(%rip)        # ab8f80 <_DYNAMIC+0x250>
  763e6d:	test   %rax,%rax
  763e70:	je     7644e2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ab2>
  763e76:	mov    %rax,%r15
  763e79:	mov    %rax,%rdi
  763e7c:	mov    0x18(%rsp),%rsi
  763e81:	mov    %r12,%rdx
  763e84:	call   *0x355106(%rip)        # ab8f90 <memcpy@GLIBC_2.14>
  763e8a:	jmp    763e96 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1466>
  763e8c:	nopl   0x0(%rax)
  763e90:	mov    $0x1,%r15d
  763e96:	movb   $0x3,0x28(%rsp)
  763e9b:	mov    %r12,0x30(%rsp)
  763ea0:	mov    %r15,0x38(%rsp)
  763ea5:	mov    %r12,0x40(%rsp)
  763eaa:	lea    0x100(%rsp),%rdi
  763eb2:	lea    0x298(%rsp),%rsi
  763eba:	lea    0x138(%rsp),%rdx
  763ec2:	lea    0x28(%rsp),%rcx
  763ec7:	call   775c20 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  763ecc:	cmpb   $0xff,0x100(%rsp)
  763ed4:	je     763ee3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x14b3>
  763ed6:	lea    0x100(%rsp),%rdi
  763ede:	call   74c910 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  763ee3:	call   *0x35508f(%rip)        # ab8f78 <_DYNAMIC+0x248>
  763ee9:	mov    $0x9,%r15d
  763eef:	mov    $0x9,%edi
  763ef4:	mov    $0x1,%esi
  763ef9:	call   *0x355081(%rip)        # ab8f80 <_DYNAMIC+0x250>
  763eff:	test   %rax,%rax
  763f02:	je     764420 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x19f0>
  763f08:	movabs $0x6f6974617265706f,%rcx
  763f12:	mov    %rcx,(%rax)
  763f15:	movb   $0x6e,0x8(%rax)
  763f19:	movq   $0x9,0x138(%rsp)
  763f25:	mov    %rax,0x140(%rsp)
  763f2d:	movq   $0x9,0x148(%rsp)
  763f39:	test   %r14,%r14
  763f3c:	je     763f80 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1550>
  763f3e:	mov    %rax,%r13
  763f41:	call   *0x355031(%rip)        # ab8f78 <_DYNAMIC+0x248>
  763f47:	mov    $0x1,%esi
  763f4c:	mov    %r14,%rdi
  763f4f:	call   *0x35502b(%rip)        # ab8f80 <_DYNAMIC+0x250>
  763f55:	test   %rax,%rax
  763f58:	je     7644b8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1a88>
  763f5e:	mov    %rax,%r15
  763f61:	mov    %rax,%rdi
  763f64:	mov    %rbp,%rsi
  763f67:	mov    %r14,%rdx
  763f6a:	call   *0x355020(%rip)        # ab8f90 <memcpy@GLIBC_2.14>
  763f70:	jmp    763f86 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1556>
  763f72:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  763f80:	mov    $0x1,%r15d
  763f86:	movb   $0x3,0x28(%rsp)
  763f8b:	mov    %r14,0x30(%rsp)
  763f90:	mov    %r15,0x38(%rsp)
  763f95:	mov    %r14,0x40(%rsp)
  763f9a:	lea    0x100(%rsp),%rdi
  763fa2:	lea    0x298(%rsp),%rsi
  763faa:	lea    0x138(%rsp),%rdx
  763fb2:	lea    0x28(%rsp),%rcx
  763fb7:	call   775c20 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  763fbc:	cmpb   $0xff,0x100(%rsp)
  763fc4:	je     763fd3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x15a3>
  763fc6:	lea    0x100(%rsp),%rdi
  763fce:	call   74c910 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  763fd3:	call   *0x354f9f(%rip)        # ab8f78 <_DYNAMIC+0x248>
  763fd9:	mov    $0x5,%r15d
  763fdf:	mov    $0x5,%edi
  763fe4:	mov    $0x1,%esi
  763fe9:	call   *0x354f91(%rip)        # ab8f80 <_DYNAMIC+0x250>
  763fef:	test   %rax,%rax
  763ff2:	je     764420 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x19f0>
  763ff8:	movb   $0x74,0x4(%rax)
  763ffc:	movl   $0x6e756f63,(%rax)
  764002:	movq   $0x5,0x138(%rsp)
  76400e:	mov    %rax,0x140(%rsp)
  764016:	movq   $0x5,0x148(%rsp)
  764022:	movb   $0x2,0x28(%rsp)
  764027:	movq   $0x0,0x30(%rsp)
  764030:	movq   $0x4,0x38(%rsp)
  764039:	lea    0x100(%rsp),%rdi
  764041:	lea    0x298(%rsp),%rsi
  764049:	lea    0x138(%rsp),%rdx
  764051:	lea    0x28(%rsp),%rcx
  764056:	call   775c20 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  76405b:	cmpb   $0xff,0x100(%rsp)
  764063:	je     764072 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1642>
  764065:	lea    0x100(%rsp),%rdi
  76406d:	call   74c910 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  764072:	call   *0x354f00(%rip)        # ab8f78 <_DYNAMIC+0x248>
  764078:	mov    $0x8,%r15d
  76407e:	mov    $0x8,%edi
  764083:	mov    $0x1,%esi
  764088:	call   *0x354ef2(%rip)        # ab8f80 <_DYNAMIC+0x250>
  76408e:	test   %rax,%rax
  764091:	je     764420 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x19f0>
  764097:	movabs $0x6d75736b63656863,%rcx
  7640a1:	mov    %rcx,(%rax)
  7640a4:	movq   $0x8,0x138(%rsp)
  7640b0:	mov    %rax,0x140(%rsp)
  7640b8:	movq   $0x8,0x148(%rsp)
  7640c4:	movb   $0x2,0x28(%rsp)
  7640c9:	movq   $0x0,0x30(%rsp)
  7640d2:	mov    0x290(%rsp),%rax
  7640da:	mov    %rax,0x38(%rsp)
  7640df:	lea    0x100(%rsp),%rdi
  7640e7:	lea    0x298(%rsp),%rsi
  7640ef:	lea    0x138(%rsp),%rdx
  7640f7:	lea    0x28(%rsp),%rcx
  7640fc:	call   775c20 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  764101:	cmpb   $0xff,0x100(%rsp)
  764109:	je     764118 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x16e8>
  76410b:	lea    0x100(%rsp),%rdi
  764113:	call   74c910 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  764118:	call   *0x354e5a(%rip)        # ab8f78 <_DYNAMIC+0x248>
  76411e:	mov    $0x8,%r15d
  764124:	mov    $0x8,%edi
  764129:	mov    $0x1,%esi
  76412e:	call   *0x354e4c(%rip)        # ab8f80 <_DYNAMIC+0x250>
  764134:	test   %rax,%rax
  764137:	je     764420 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x19f0>
  76413d:	mov    %rax,%r14
  764140:	movabs $0x737265746e756f63,%rax
  76414a:	mov    %rax,(%r14)
  76414d:	movq   $0x8,0x138(%rsp)
  764159:	mov    %r14,0x140(%rsp)
  764161:	movq   $0x8,0x148(%rsp)
  76416d:	lea    0x28(%rsp),%rdi
  764172:	lea    0x260(%rsp),%rsi
  76417a:	call   75b1e0 <_RINvXNtNtCscl5MXVnO7Zx_10serde_json5value3serNtB5_5ValueNtNtCs8znKHa7cbRS_10serde_core3ser9Serialize9serializeNtB3_10SerializerECs9C2G9YFESsD_29canonical_text_public_control>
  76417f:	cmpb   $0xff,0x28(%rsp)
  764184:	je     76426e <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x183e>
  76418a:	movups 0x28(%rsp),%xmm0
  76418f:	movups 0x38(%rsp),%xmm1
  764194:	movaps %xmm1,0x110(%rsp)
  76419c:	movaps %xmm0,0x100(%rsp)
  7641a4:	lea    0x28(%rsp),%rdi
  7641a9:	lea    0x298(%rsp),%rsi
  7641b1:	lea    0x138(%rsp),%rdx
  7641b9:	lea    0x100(%rsp),%rcx
  7641c1:	call   775c20 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  7641c6:	cmpb   $0xff,0x28(%rsp)
  7641cb:	je     7641d7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x17a7>
  7641cd:	lea    0x28(%rsp),%rdi
  7641d2:	call   74c910 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  7641d7:	mov    0x2a8(%rsp),%rax
  7641df:	lea    0x2c0(%rsp),%rcx
  7641e7:	mov    %rax,0x10(%rcx)
  7641eb:	movups 0x298(%rsp),%xmm0
  7641f3:	movups %xmm0,(%rcx)
  7641f6:	movb   $0x5,0x2b8(%rsp)
  7641fe:	lea    0x2b8(%rsp),%r14
  764206:	mov    %r14,0x1f0(%rsp)
  76420e:	mov    0x355053(%rip),%rax        # ab9268 <_DYNAMIC+0x538>
  764215:	mov    %rax,0x1f8(%rsp)
  76421d:	lea    -0x69f542(%rip),%rdi        # c4ce2 <GCC_except_table0+0x2942>
  764224:	lea    0x1f0(%rsp),%r15
  76422c:	mov    %r15,%rsi
  76422f:	call   *0x35503b(%rip)        # ab9270 <_DYNAMIC+0x540>
  764235:	mov    %r14,%rdi
  764238:	call   74c910 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  76423d:	mov    0xf8(%rsp),%r12
  764245:	mov    0x1e8(%rsp),%r13
  76424d:	lea    0x260(%rsp),%rdi
  764255:	call   74c910 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  76425a:	jmp    763c90 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1260>
  76425f:	cmp    $0x4,%r14
  764263:	je     763d78 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1348>
  764269:	jmp    763d89 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1359>
  76426e:	mov    0x10(%rsp),%rax
  764273:	mov    %rax,0x60(%rsp)
  764278:	mov    0x8(%rsp),%rax
  76427d:	mov    %rax,0x150(%rsp)
  764285:	mov    0x30(%rsp),%rax
  76428a:	mov    %rax,0x100(%rsp)
  764292:	lea    -0x69466f(%rip),%rdi        # cfc2a <GCC_except_table0+0xd88a>
  764299:	lea    0x3357e8(%rip),%rcx        # a99a88 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x12b0>
  7642a0:	lea    0x335701(%rip),%r8        # a999a8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x11d0>
  7642a7:	lea    0x100(%rsp),%rdx
  7642af:	mov    $0x2b,%esi
  7642b4:	call   *0x354d86(%rip)        # ab9040 <_DYNAMIC+0x310>
  7642ba:	jmp    7647fd <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  7642bf:	lea    0x60(%rsp),%rdi
  7642c4:	lea    0x100(%rsp),%rsi
  7642cc:	call   74f3e6 <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedTNtNtCscdodAO9FK5_5alloc6string6StringNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout13TextSelectionPNtB1q_12TextGeometryyEBM_ECs9C2G9YFESsD_29canonical_text_public_control>
  7642d1:	jmp    7647fd <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  7642d6:	add    $0xd0,%dl
  7642d9:	xor    %eax,%eax
  7642db:	cmp    $0xa,%dl
  7642de:	adc    $0x1,%al
  7642e0:	mov    %al,0x150(%rsp)
  7642e7:	lea    -0x6946c4(%rip),%rdi        # cfc2a <GCC_except_table0+0xd88a>
  7642ee:	lea    0x335833(%rip),%rcx        # a99b28 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1350>
  7642f5:	lea    0x33567c(%rip),%r8        # a99978 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x11a0>
  7642fc:	lea    0x150(%rsp),%rdx
  764304:	mov    $0x2b,%esi
  764309:	call   *0x354d31(%rip)        # ab9040 <_DYNAMIC+0x310>
  76430f:	jmp    7647fd <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  764314:	lea    0x28(%rsp),%rdi
  764319:	lea    0x2b8(%rsp),%rsi
  764321:	call   74f2cb <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedNtNtCscdodAO9FK5_5alloc6string6StringBM_ECs9C2G9YFESsD_29canonical_text_public_control>
  764326:	jmp    7647fd <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  76432b:	lea    0x1f0(%rsp),%rdi
  764333:	lea    0x60(%rsp),%rsi
  764338:	call   74f41e <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedTPNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryyEBM_ECs9C2G9YFESsD_29canonical_text_public_control>
  76433d:	jmp    7647fd <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  764342:	lea    0x3352f7(%rip),%rdi        # a99640 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xe68>
  764349:	call   *0x354cc9(%rip)        # ab9018 <_DYNAMIC+0x2e8>
  76434f:	jmp    7647fd <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  764354:	lea    0x3352b5(%rip),%rdi        # a99610 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xe38>
  76435b:	call   *0x354cb7(%rip)        # ab9018 <_DYNAMIC+0x2e8>
  764361:	jmp    7647fd <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  764366:	mov    0x250(%rsp),%rax
  76436e:	mov    %rax,0xc0(%rsp)
  764376:	movups 0x240(%rsp),%xmm0
  76437e:	movaps %xmm0,0xb0(%rsp)
  764386:	movups 0x230(%rsp),%xmm0
  76438e:	movaps %xmm0,0xa0(%rsp)
  764396:	movups 0x1f0(%rsp),%xmm0
  76439e:	movups 0x200(%rsp),%xmm1
  7643a6:	movups 0x210(%rsp),%xmm2
  7643ae:	movups 0x220(%rsp),%xmm3
  7643b6:	movaps %xmm3,0x90(%rsp)
  7643be:	movaps %xmm2,0x80(%rsp)
  7643c6:	movaps %xmm1,0x70(%rsp)
  7643cb:	movaps %xmm0,0x60(%rsp)
  7643d0:	lea    -0x6947ad(%rip),%rdi        # cfc2a <GCC_except_table0+0xd88a>
  7643d7:	lea    0x33570a(%rip),%rcx        # a99ae8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1310>
  7643de:	lea    0x3351fb(%rip),%r8        # a995e0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xe08>
  7643e5:	lea    0x60(%rsp),%rdx
  7643ea:	mov    $0x2b,%esi
  7643ef:	call   *0x354c4b(%rip)        # ab9040 <_DYNAMIC+0x310>
  7643f5:	jmp    7647fd <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  7643fa:	lea    0x3351f7(%rip),%r9        # a995f8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xe20>
  764401:	xor    %edi,%edi
  764403:	lea    0x90(%rsp),%rsi
  76440b:	lea    0x130(%rsp),%rdx
  764413:	xor    %ecx,%ecx
  764415:	call   *0x354dd5(%rip)        # ab91f0 <_DYNAMIC+0x4c0>
  76441b:	jmp    7647fd <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  764420:	mov    0x10(%rsp),%rax
  764425:	mov    %rax,0x60(%rsp)
  76442a:	mov    0x8(%rsp),%rax
  76442f:	mov    %rax,0x150(%rsp)
  764437:	mov    $0x1,%edi
  76443c:	mov    %r15,%rsi
  76443f:	call   *0x354be3(%rip)        # ab9028 <_DYNAMIC+0x2f8>
  764445:	jmp    7647fd <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  76444a:	mov    0x158(%rsp),%rax
  764452:	mov    %rax,0x60(%rsp)
  764457:	lea    -0x694834(%rip),%rdi        # cfc2a <GCC_except_table0+0xd88a>
  76445e:	lea    0x335623(%rip),%rcx        # a99a88 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x12b0>
  764465:	lea    0x335524(%rip),%r8        # a99990 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x11b8>
  76446c:	lea    0x60(%rsp),%rdx
  764471:	mov    $0x2b,%esi
  764476:	call   *0x354bc4(%rip)        # ab9040 <_DYNAMIC+0x310>
  76447c:	jmp    7647fd <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  764481:	mov    0x158(%rsp),%rax
  764489:	mov    %rax,0x60(%rsp)
  76448e:	lea    -0x69486b(%rip),%rdi        # cfc2a <GCC_except_table0+0xd88a>
  764495:	lea    0x3355ec(%rip),%rcx        # a99a88 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x12b0>
  76449c:	lea    0x3354ed(%rip),%r8        # a99990 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x11b8>
  7644a3:	lea    0x60(%rsp),%rdx
  7644a8:	mov    $0x2b,%esi
  7644ad:	call   *0x354b8d(%rip)        # ab9040 <_DYNAMIC+0x310>
  7644b3:	jmp    7647fd <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  7644b8:	mov    0x10(%rsp),%rax
  7644bd:	mov    %rax,0x60(%rsp)
  7644c2:	mov    0x8(%rsp),%rax
  7644c7:	mov    %rax,0x150(%rsp)
  7644cf:	mov    $0x1,%edi
  7644d4:	mov    %r14,%rsi
  7644d7:	call   *0x354b4b(%rip)        # ab9028 <_DYNAMIC+0x2f8>
  7644dd:	jmp    7647fd <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  7644e2:	mov    0x10(%rsp),%rax
  7644e7:	mov    %rax,0x60(%rsp)
  7644ec:	mov    0x8(%rsp),%rax
  7644f1:	mov    %rax,0x150(%rsp)
  7644f9:	mov    $0x1,%edi
  7644fe:	mov    %r12,%rsi
  764501:	call   *0x354b21(%rip)        # ab9028 <_DYNAMIC+0x2f8>
  764507:	jmp    7647fd <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  76450c:	mov    $0x1,%al
  76450e:	jmp    7642e0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x18b0>
  764513:	lea    0x60(%rsp),%rdi
  764518:	call   7461f0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultNtNtCslbxve4rcJus_4gpui7runtime6CommitNtBZ_5ErrorEECs9C2G9YFESsD_29canonical_text_public_control>
  76451d:	lea    -0x694b24(%rip),%rdi        # cfa00 <GCC_except_table0+0xd660>
  764524:	lea    0x3350fd(%rip),%rdx        # a99628 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xe50>
  76452b:	mov    $0x4e,%esi
  764530:	call   *0x354ab2(%rip)        # ab8fe8 <_DYNAMIC+0x2b8>
  764536:	jmp    7647fd <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  76453b:	mov    $0x1,%edi
  764540:	mov    %r13,%rsi
  764543:	call   *0x354adf(%rip)        # ab9028 <_DYNAMIC+0x2f8>
  764549:	jmp    7647fd <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  76454e:	mov    $0x12,%eax
  764553:	jmp    76455a <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1b2a>
  764555:	mov    $0xe,%eax
  76455a:	mov    %rax,0x1e8(%rsp)
  764562:	mov    0x1e8(%rsp),%rax
  76456a:	mov    %rax,0x60(%rsp)
  76456f:	mov    0x18(%rsp),%rax
  764574:	mov    %rax,0x68(%rsp)
  764579:	mov    0x8(%rsp),%rax
  76457e:	mov    %rax,0x70(%rsp)
  764583:	lea    -0x694be9(%rip),%rdi        # cf9a1 <GCC_except_table0+0xd601>
  76458a:	lea    0x3354d7(%rip),%rcx        # a99a68 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1290>
  764591:	lea    0x334e20(%rip),%r8        # a993b8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xbe0>
  764598:	lea    0x60(%rsp),%rdx
  76459d:	mov    $0x2a,%esi
  7645a2:	call   *0x354a98(%rip)        # ab9040 <_DYNAMIC+0x310>
  7645a8:	jmp    7647fd <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  7645ad:	movq   $0xd,0x1f0(%rsp)
  7645b9:	movq   $0x0,0x1f8(%rsp)
  7645c5:	mov    0x220(%rsp),%rax
  7645cd:	mov    %rax,0x90(%rsp)
  7645d5:	mov    0x1f0(%rsp),%rax
  7645dd:	mov    0x1f8(%rsp),%rcx
  7645e5:	movups 0x200(%rsp),%xmm0
  7645ed:	movups 0x210(%rsp),%xmm1
  7645f5:	movaps %xmm1,0x80(%rsp)
  7645fd:	movaps %xmm0,0x70(%rsp)
  764602:	mov    %rax,0x60(%rsp)
  764607:	mov    %rcx,0x68(%rsp)
  76460c:	lea    -0x6949e9(%rip),%rdi        # cfc2a <GCC_except_table0+0xd88a>
  764613:	lea    0x33544e(%rip),%rcx        # a99a68 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1290>
  76461a:	lea    0x334eef(%rip),%r8        # a99510 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xd38>
  764621:	lea    0x60(%rsp),%rdx
  764626:	mov    $0x2b,%esi
  76462b:	call   *0x354a0f(%rip)        # ab9040 <_DYNAMIC+0x310>
  764631:	jmp    7647fd <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  764636:	mov    $0xd,%eax
  76463b:	movq   $0x0,0x2b0(%rsp)
  764647:	jmp    764655 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1c25>
  764649:	mov    $0xe,%eax
  76464e:	jmp    764655 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1c25>
  764650:	mov    $0x14,%eax
  764655:	mov    %rax,0x60(%rsp)
  76465a:	mov    0x2b0(%rsp),%rax
  764662:	mov    %rax,0x68(%rsp)
  764667:	mov    0x10(%rsp),%rax
  76466c:	mov    %rax,0x70(%rsp)
  764671:	lea    -0x694a4e(%rip),%rdi        # cfc2a <GCC_except_table0+0xd88a>
  764678:	lea    0x3353e9(%rip),%rcx        # a99a68 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1290>
  76467f:	lea    0x334ea2(%rip),%r8        # a99528 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xd50>
  764686:	lea    0x60(%rsp),%rdx
  76468b:	mov    $0x2b,%esi
  764690:	call   *0x3549aa(%rip)        # ab9040 <_DYNAMIC+0x310>
  764696:	jmp    7647fd <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  76469b:	movq   $0xd,0x1f0(%rsp)
  7646a7:	movq   $0x0,0x1f8(%rsp)
  7646b3:	jmp    7646c1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1c91>
  7646b5:	movq   $0xe,0x1f0(%rsp)
  7646c1:	mov    0x220(%rsp),%rax
  7646c9:	mov    %rax,0x90(%rsp)
  7646d1:	mov    0x1f0(%rsp),%rax
  7646d9:	mov    0x1f8(%rsp),%rcx
  7646e1:	movups 0x200(%rsp),%xmm0
  7646e9:	movups 0x210(%rsp),%xmm1
  7646f1:	movaps %xmm1,0x80(%rsp)
  7646f9:	movaps %xmm0,0x70(%rsp)
  7646fe:	mov    %rax,0x60(%rsp)
  764703:	mov    %rcx,0x68(%rsp)
  764708:	lea    -0x694ae5(%rip),%rdi        # cfc2a <GCC_except_table0+0xd88a>
  76470f:	lea    0x335352(%rip),%rcx        # a99a68 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1290>
  764716:	lea    0x334e3b(%rip),%r8        # a99558 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xd80>
  76471d:	lea    0x60(%rsp),%rdx
  764722:	mov    $0x2b,%esi
  764727:	call   *0x354913(%rip)        # ab9040 <_DYNAMIC+0x310>
  76472d:	jmp    7647fd <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  764732:	mov    0x68(%rsp),%r14
  764737:	mov    0x78(%rsp),%rcx
  76473c:	mov    %rcx,%rax
  76473f:	sub    %r14,%rax
  764742:	movabs $0xaaaaaaaaaaaaaaab,%rdx
  76474c:	mul    %rdx
  76474f:	cmp    %r14,%rcx
  764752:	jne    7647a9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1d79>
  764754:	mov    0x70(%rsp),%rax
  764759:	test   %rax,%rax
  76475c:	je     764776 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1d46>
  76475e:	mov    0x60(%rsp),%rdi
  764763:	shl    $0x3,%rax
  764767:	lea    (%rax,%rax,2),%rsi
  76476b:	mov    $0x8,%edx
  764770:	call   *0x3547fa(%rip)        # ab8f70 <_DYNAMIC+0x240>
  764776:	mov    $0x8,%eax
  76477b:	mov    %rax,0x20(%rsp)
  764780:	movq   $0x0,0x288(%rsp)
  76478c:	xor    %ebx,%ebx
  76478e:	lea    -0x694c35(%rip),%rdi        # cfb60 <GCC_except_table0+0xd7c0>
  764795:	lea    0x3351ac(%rip),%rdx        # a99948 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1170>
  76479c:	mov    $0x6b,%esi
  7647a1:	call   *0x354801(%rip)        # ab8fa8 <_DYNAMIC+0x278>
  7647a7:	jmp    7647fd <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  7647a9:	mov    %rdx,%rbx
  7647ac:	shr    $0x4,%rbx
  7647b0:	add    $0x8,%r14
  7647b4:	mov    0x3547b5(%rip),%r15        # ab8f70 <_DYNAMIC+0x240>
  7647bb:	jmp    7647c9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1d99>
  7647bd:	nopl   (%rax)
  7647c0:	add    $0x18,%r14
  7647c4:	dec    %rbx
  7647c7:	je     764754 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1d24>
  7647c9:	mov    -0x8(%r14),%rsi
  7647cd:	test   %rsi,%rsi
  7647d0:	je     7647c0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1d90>
  7647d2:	mov    (%r14),%rdi
  7647d5:	mov    $0x1,%edx
  7647da:	call   *%r15
  7647dd:	jmp    7647c0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1d90>
  7647df:	mov    $0x1,%edi
  7647e4:	mov    %r12,%rsi
  7647e7:	call   *0x35483b(%rip)        # ab9028 <_DYNAMIC+0x2f8>
  7647ed:	jmp    7647fd <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  7647ef:	mov    $0x1,%edi
  7647f4:	mov    %r13,%rsi
  7647f7:	call   *0x35482b(%rip)        # ab9028 <_DYNAMIC+0x2f8>
  7647fd:	ud2
  7647ff:	xor    %eax,%eax
  764801:	jmp    7642e0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x18b0>
  764806:	mov    %rax,%r15
  764809:	mov    $0x9,%esi
  76480e:	mov    $0x1,%edx
  764813:	mov    %rbp,%rdi
  764816:	jmp    764a9d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x206d>
  76481b:	mov    %rax,%r15
  76481e:	mov    $0x4,%esi
  764823:	mov    $0x1,%edx
  764828:	mov    %r13,%rdi
  76482b:	jmp    764a9d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x206d>
  764830:	mov    %rax,%r15
  764833:	jmp    764ab0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2080>
  764838:	mov    %rax,%r15
  76483b:	lea    0x150(%rsp),%rdi
  764843:	call   74c910 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  764848:	jmp    764ab0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2080>
  76484d:	mov    %rax,%r15
  764850:	jmp    764aa3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2073>
  764855:	mov    %rax,%r15
  764858:	jmp    764a6e <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x203e>
  76485d:	mov    %rax,%r15
  764860:	jmp    764aa3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2073>
  764865:	mov    %rax,%r15
  764868:	jmp    764a90 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2060>
  76486d:	mov    %rax,%r15
  764870:	jmp    764aa3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2073>
  764875:	mov    %rax,%r15
  764878:	jmp    764aa3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2073>
  76487d:	mov    %rax,%r15
  764880:	jmp    764aa3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2073>
  764885:	mov    %rax,%r15
  764888:	jmp    764aa3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2073>
  76488d:	mov    %rax,%r15
  764890:	jmp    764cfa <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x22ca>
  764895:	mov    %rax,%r15
  764898:	mov    $0x770,%esi
  76489d:	mov    $0x8,%edx
  7648a2:	mov    %r14,%rdi
  7648a5:	jmp    764bb6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2186>
  7648aa:	jmp    7648d6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ea6>
  7648ac:	mov    %rax,%r15
  7648af:	jmp    764c8f <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x225f>
  7648b4:	mov    %rax,%r15
  7648b7:	jmp    764aa3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2073>
  7648bc:	jmp    7648d6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ea6>
  7648be:	mov    %rax,%r15
  7648c1:	jmp    764a59 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2029>
  7648c6:	mov    %rax,%r15
  7648c9:	jmp    764b98 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2168>
  7648ce:	mov    %rax,%r15
  7648d1:	jmp    764afc <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x20cc>
  7648d6:	mov    %rax,%r15
  7648d9:	lea    0x60(%rsp),%rdi
  7648de:	call   74d580 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  7648e3:	mov    $0x1,%bpl
  7648e6:	jmp    764b47 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2117>
  7648eb:	mov    %rax,%r15
  7648ee:	test   %r14,%r14
  7648f1:	je     76490e <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ede>
  7648f3:	mov    $0x1,%edx
  7648f8:	mov    %rbp,%rdi
  7648fb:	mov    %r14,%rsi
  7648fe:	call   *0x35466c(%rip)        # ab8f70 <_DYNAMIC+0x240>
  764904:	jmp    76490e <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ede>
  764906:	jmp    764b00 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x20d0>
  76490b:	mov    %rax,%r15
  76490e:	lea    0x150(%rsp),%rdi
  764916:	call   7497e0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtB4_4iter8adapters4skip4SkipNtNtCs2AWtUsOyxgP_3std3env4ArgsEECs9C2G9YFESsD_29canonical_text_public_control>
  76491b:	lea    0x28(%rsp),%rdi
  764920:	call   746e10 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtBG_6string6StringEECs9C2G9YFESsD_29canonical_text_public_control>
  764925:	mov    %r15,%rdi
  764928:	call   a97420 <_Unwind_Resume@plt>
  76492d:	mov    %rax,%r15
  764930:	mov    $0x4,%esi
  764935:	jmp    76493f <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1f0f>
  764937:	mov    %rax,%r15
  76493a:	mov    $0x9,%esi
  76493f:	mov    $0x1,%edx
  764944:	mov    %r13,%rdi
  764947:	jmp    764bf7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x21c7>
  76494c:	mov    %rax,%r15
  76494f:	mov    0x10(%rsp),%rax
  764954:	mov    %rax,0x60(%rsp)
  764959:	mov    0x8(%rsp),%rax
  76495e:	mov    %rax,0x150(%rsp)
  764966:	jmp    764c82 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2252>
  76496b:	jmp    764a2d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ffd>
  764970:	mov    %rax,%r15
  764973:	mov    0x10(%rsp),%rax
  764978:	mov    %rax,0x60(%rsp)
  76497d:	mov    0x8(%rsp),%rax
  764982:	mov    %rax,0x150(%rsp)
  76498a:	lea    0x2b8(%rsp),%rdi
  764992:	call   74c910 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  764997:	jmp    764c82 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2252>
  76499c:	jmp    764a2d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ffd>
  7649a1:	mov    %rax,%r15
  7649a4:	mov    0x10(%rsp),%rax
  7649a9:	mov    %rax,0x60(%rsp)
  7649ae:	mov    0x8(%rsp),%rax
  7649b3:	mov    %rax,0x150(%rsp)
  7649bb:	jmp    764bea <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x21ba>
  7649c0:	jmp    764a2d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ffd>
  7649c2:	jmp    764a2d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ffd>
  7649c4:	jmp    764a2d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ffd>
  7649c6:	mov    %rax,%r15
  7649c9:	jmp    764a59 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2029>
  7649ce:	mov    %rax,%r15
  7649d1:	cmpq   $0xffffffffffffffff,0x18(%rsp)
  7649d7:	jne    764c8f <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x225f>
  7649dd:	mov    0x288(%rsp),%rax
  7649e5:	test   %rax,%rax
  7649e8:	je     764d26 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x22f6>
  7649ee:	shl    $0x3,%rax
  7649f2:	lea    (%rax,%rax,2),%rsi
  7649f6:	mov    $0x8,%edx
  7649fb:	mov    0x20(%rsp),%rdi
  764a00:	call   *0x35456a(%rip)        # ab8f70 <_DYNAMIC+0x240>
  764a06:	mov    %r15,%rdi
  764a09:	call   a97420 <_Unwind_Resume@plt>
  764a0e:	mov    %rax,%r15
  764a11:	mov    0x10(%rsp),%rax
  764a16:	mov    %rax,0x60(%rsp)
  764a1b:	mov    0x8(%rsp),%rax
  764a20:	mov    %rax,0x150(%rsp)
  764a28:	jmp    764c8f <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x225f>
  764a2d:	mov    %rax,%r15
  764a30:	mov    0x10(%rsp),%rax
  764a35:	mov    %rax,0x60(%rsp)
  764a3a:	mov    0x8(%rsp),%rax
  764a3f:	mov    %rax,0x150(%rsp)
  764a47:	jmp    764bfd <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x21cd>
  764a4c:	mov    %rax,%r15
  764a4f:	lea    0x60(%rsp),%rdi
  764a54:	call   74d580 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  764a59:	mov    $0x1,%bpl
  764a5c:	jmp    764b67 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2137>
  764a61:	mov    %rax,%r15
  764a64:	lea    0x60(%rsp),%rdi
  764a69:	call   74c820 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5error5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  764a6e:	mov    $0x8,%esi
  764a73:	mov    $0x1,%edx
  764a78:	mov    %r14,%rdi
  764a7b:	jmp    764a9d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x206d>
  764a7d:	call   *0x354515(%rip)        # ab8f98 <_DYNAMIC+0x268>
  764a83:	mov    %rax,%r15
  764a86:	lea    0x60(%rsp),%rdi
  764a8b:	call   74c820 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5error5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  764a90:	mov    $0xa,%esi
  764a95:	mov    $0x1,%edx
  764a9a:	mov    %r12,%rdi
  764a9d:	call   *0x3544cd(%rip)        # ab8f70 <_DYNAMIC+0x240>
  764aa3:	lea    0x100(%rsp),%rdi
  764aab:	call   747b40 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscl5MXVnO7Zx_10serde_json3map3MapNtNtCscdodAO9FK5_5alloc6string6StringNtNtBG_5value5ValueEECs9C2G9YFESsD_29canonical_text_public_control>
  764ab0:	lea    0x1f0(%rsp),%rdi
  764ab8:	call   74c910 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  764abd:	jmp    764c8f <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x225f>
  764ac2:	call   *0x3544d0(%rip)        # ab8f98 <_DYNAMIC+0x268>
  764ac8:	mov    %rax,%r15
  764acb:	jmp    764bfd <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x21cd>
  764ad0:	mov    %rax,%r15
  764ad3:	mov    0x60(%rsp),%rsi
  764ad8:	test   %rsi,%rsi
  764adb:	je     764afc <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x20cc>
  764add:	mov    0x68(%rsp),%rdi
  764ae2:	mov    $0x1,%edx
  764ae7:	call   *0x354483(%rip)        # ab8f70 <_DYNAMIC+0x240>
  764aed:	jmp    764afc <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x20cc>
  764aef:	mov    %rax,%r15
  764af2:	lea    0x60(%rsp),%rdi
  764af7:	call   748420 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui7runtime8SetErrorNtNtCscdodAO9FK5_5alloc6string6StringEECs9C2G9YFESsD_29canonical_text_public_control>
  764afc:	xor    %ebp,%ebp
  764afe:	jmp    764b2d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x20fd>
  764b00:	mov    %rax,%r15
  764b03:	mov    $0x1,%bpl
  764b06:	jmp    764b47 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2117>
  764b08:	mov    %rax,%r15
  764b0b:	jmp    764c8f <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x225f>
  764b10:	mov    %rax,%r15
  764b13:	mov    0x60(%rsp),%rsi
  764b18:	mov    $0x1,%bpl
  764b1b:	test   %rsi,%rsi
  764b1e:	je     764b47 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2117>
  764b20:	mov    0x68(%rsp),%rdi
  764b25:	jmp    764b3c <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x210c>
  764b27:	mov    %rax,%r15
  764b2a:	mov    $0x1,%bpl
  764b2d:	mov    0x28(%rsp),%rsi
  764b32:	test   %rsi,%rsi
  764b35:	je     764b47 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2117>
  764b37:	mov    0x30(%rsp),%rdi
  764b3c:	mov    $0x1,%edx
  764b41:	call   *0x354429(%rip)        # ab8f70 <_DYNAMIC+0x240>
  764b47:	mov    0x100(%rsp),%rsi
  764b4f:	test   %rsi,%rsi
  764b52:	je     764b67 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2137>
  764b54:	mov    0x108(%rsp),%rdi
  764b5c:	mov    $0x1,%edx
  764b61:	call   *0x354409(%rip)        # ab8f70 <_DYNAMIC+0x240>
  764b67:	mov    0x260(%rsp),%r14
  764b6f:	test   %r14,%r14
  764b72:	je     764b8f <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x215f>
  764b74:	mov    %r14,%rdi
  764b77:	call   747d70 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui7runtime7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEEB1h_>
  764b7c:	mov    $0x770,%esi
  764b81:	mov    $0x8,%edx
  764b86:	mov    %r14,%rdi
  764b89:	call   *0x3543e1(%rip)        # ab8f70 <_DYNAMIC+0x240>
  764b8f:	test   %bpl,%bpl
  764b92:	je     764c8f <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x225f>
  764b98:	mov    0x2b8(%rsp),%rsi
  764ba0:	test   %rsi,%rsi
  764ba3:	je     764c8f <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x225f>
  764ba9:	mov    0x2c0(%rsp),%rdi
  764bb1:	mov    $0x1,%edx
  764bb6:	call   *0x3543b4(%rip)        # ab8f70 <_DYNAMIC+0x240>
  764bbc:	jmp    764c8f <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x225f>
  764bc1:	mov    $0x770,%esi
  764bc6:	mov    $0x8,%edx
  764bcb:	mov    %r14,%rdi
  764bce:	call   *0x35439c(%rip)        # ab8f70 <_DYNAMIC+0x240>
  764bd4:	call   *0x3543be(%rip)        # ab8f98 <_DYNAMIC+0x268>
  764bda:	mov    %rax,%r15
  764bdd:	lea    0x100(%rsp),%rdi
  764be5:	call   74c820 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5error5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  764bea:	mov    $0x8,%esi
  764bef:	mov    $0x1,%edx
  764bf4:	mov    %r14,%rdi
  764bf7:	call   *0x354373(%rip)        # ab8f70 <_DYNAMIC+0x240>
  764bfd:	mov    0x298(%rsp),%rcx
  764c05:	test   %rcx,%rcx
  764c08:	jne    764c10 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x21e0>
  764c0a:	xor    %ecx,%ecx
  764c0c:	xor    %eax,%eax
  764c0e:	jmp    764c5d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x222d>
  764c10:	mov    0x2a0(%rsp),%rdx
  764c18:	mov    0x2a8(%rsp),%rax
  764c20:	movq   $0x0,0x1f8(%rsp)
  764c2c:	mov    %rcx,0x200(%rsp)
  764c34:	mov    %rdx,0x208(%rsp)
  764c3c:	movq   $0x0,0x218(%rsp)
  764c48:	mov    %rcx,0x220(%rsp)
  764c50:	mov    %rdx,0x228(%rsp)
  764c58:	mov    $0x1,%ecx
  764c5d:	mov    %rcx,0x1f0(%rsp)
  764c65:	mov    %rcx,0x210(%rsp)
  764c6d:	mov    %rax,0x230(%rsp)
  764c75:	lea    0x1f0(%rsp),%rdi
  764c7d:	call   74ab00 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtCscdodAO9FK5_5alloc11collections5btree3map8IntoIterNtNtBK_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueEECs9C2G9YFESsD_29canonical_text_public_control>
  764c82:	lea    0x260(%rsp),%rdi
  764c8a:	call   74c910 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  764c8f:	mov    0x20(%rsp),%rax
  764c94:	lea    0x8(%rax),%r14
  764c98:	mov    0x3542d1(%rip),%r12        # ab8f70 <_DYNAMIC+0x240>
  764c9f:	jmp    764cbd <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x228d>
  764ca1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  764cb0:	add    $0x18,%r14
  764cb4:	dec    %rbx
  764cb7:	je     7649dd <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1fad>
  764cbd:	mov    -0x8(%r14),%rsi
  764cc1:	test   %rsi,%rsi
  764cc4:	je     764cb0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2280>
  764cc6:	mov    (%r14),%rdi
  764cc9:	mov    $0x1,%edx
  764cce:	call   *%r12
  764cd1:	jmp    764cb0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2280>
  764cd3:	call   *0x3542bf(%rip)        # ab8f98 <_DYNAMIC+0x268>
  764cd9:	call   *0x3542b9(%rip)        # ab8f98 <_DYNAMIC+0x268>
  764cdf:	mov    %rax,%r15
  764ce2:	mov    0x18(%rsp),%rsi
  764ce7:	test   %rsi,%rsi
  764cea:	je     764cfa <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x22ca>
  764cec:	mov    $0x1,%edx
  764cf1:	mov    %rbx,%rdi
  764cf4:	call   *0x354276(%rip)        # ab8f70 <_DYNAMIC+0x240>
  764cfa:	mov    0x68(%rsp),%r14
  764cff:	mov    0x78(%rsp),%rcx
  764d04:	mov    %rcx,%rax
  764d07:	sub    %r14,%rax
  764d0a:	movabs $0xaaaaaaaaaaaaaaab,%rdx
  764d14:	mul    %rdx
  764d17:	cmp    %r14,%rcx
  764d1a:	jne    764d2e <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x22fe>
  764d1c:	mov    0x70(%rsp),%rax
  764d21:	test   %rax,%rax
  764d24:	jne    764d6f <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x233f>
  764d26:	mov    %r15,%rdi
  764d29:	call   a97420 <_Unwind_Resume@plt>
  764d2e:	mov    %rdx,%rbx
  764d31:	shr    $0x4,%rbx
  764d35:	add    $0x8,%r14
  764d39:	mov    0x354230(%rip),%r12        # ab8f70 <_DYNAMIC+0x240>
  764d40:	jmp    764d59 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2329>
  764d42:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  764d50:	add    $0x18,%r14
  764d54:	dec    %rbx
  764d57:	je     764d1c <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x22ec>
  764d59:	mov    -0x8(%r14),%rsi
  764d5d:	test   %rsi,%rsi
  764d60:	je     764d50 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2320>
  764d62:	mov    (%r14),%rdi
  764d65:	mov    $0x1,%edx
  764d6a:	call   *%r12
  764d6d:	jmp    764d50 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2320>
  764d6f:	mov    0x60(%rsp),%rdi
  764d74:	shl    $0x3,%rax
  764d78:	lea    (%rax,%rax,2),%rsi
  764d7c:	mov    $0x8,%edx
  764d81:	call   *0x3541e9(%rip)        # ab8f70 <_DYNAMIC+0x240>
  764d87:	mov    %r15,%rdi
  764d8a:	call   a97420 <_Unwind_Resume@plt>

canonical_text_public_control::mount bytes=2801 frame=3384

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000764d90 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount>:
  764d90:	push   %rbp
  764d91:	push   %r15
  764d93:	push   %r14
  764d95:	push   %r13
  764d97:	push   %r12
  764d99:	push   %rbx
  764d9a:	sub    $0xd08,%rsp
  764da1:	mov    (%rdi),%rax
  764da4:	mov    %rax,0x10(%rsp)
  764da9:	mov    0x8(%rdi),%r14
  764dad:	mov    0x10(%rdi),%rbx
  764db1:	movups -0x695220(%rip),%xmm0        # cfb98 <GCC_except_table0+0xd7f8>
  764db8:	movups %xmm0,0xf8(%rsp)
  764dc0:	movq   $0x0,0x108(%rsp)
  764dcc:	lea    0x3b0(%rsp),%rdi
  764dd4:	movabs $0x104000001a4,%r15
  764dde:	movss  -0x6a29de(%rip),%xmm0        # c2408 <GCC_except_table0+0x68>
  764de6:	mov    %r15,%rsi
  764de9:	call   *0x354491(%rip)        # ab9280 <_DYNAMIC+0x550>
  764def:	mov    0x3b0(%rsp),%r13
  764df7:	cmp    $0xfffffffffffffffe,%r13
  764dfb:	jne    7654d2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x742>
  764e01:	lea    0x3b0(%rsp),%rdi
  764e09:	call   796b60 <_RNvXs_Cs9C2G9YFESsD_29canonical_text_public_controlNtB4_6EditorNtCslbxve4rcJus_4gpui4View7sources>
  764e0e:	mov    0x3b0(%rsp),%rax
  764e16:	movups 0x408(%rsp),%xmm0
  764e1e:	movaps %xmm0,0x150(%rsp)
  764e26:	movups 0x3f8(%rsp),%xmm0
  764e2e:	movaps %xmm0,0x140(%rsp)
  764e36:	movups 0x3e8(%rsp),%xmm0
  764e3e:	movaps %xmm0,0x130(%rsp)
  764e46:	movups 0x3d8(%rsp),%xmm0
  764e4e:	movaps %xmm0,0x120(%rsp)
  764e56:	movups 0x3c8(%rsp),%xmm1
  764e5e:	movaps %xmm1,0x110(%rsp)
  764e66:	movups 0x3b8(%rsp),%xmm2
  764e6e:	movups %xmm1,0xa0(%rsp)
  764e76:	movups %xmm0,0xb0(%rsp)
  764e7e:	mov    0x130(%rsp),%rcx
  764e86:	mov    %rcx,0xc0(%rsp)
  764e8e:	mov    0x158(%rsp),%rcx
  764e96:	mov    %rcx,0xe8(%rsp)
  764e9e:	movups 0x148(%rsp),%xmm0
  764ea6:	movups %xmm0,0xd8(%rsp)
  764eae:	movups 0x138(%rsp),%xmm0
  764eb6:	movups %xmm0,0xc8(%rsp)
  764ebe:	mov    %rax,0x88(%rsp)
  764ec6:	movups %xmm2,0x90(%rsp)
  764ece:	movl   $0x0,0x110(%rsp)
  764ed9:	movl   $0x434b0000,0x118(%rsp)
  764ee4:	movw   $0x0,0x11c(%rsp)
  764eee:	lea    0x3b0(%rsp),%rdi
  764ef6:	lea    0x110(%rsp),%rcx
  764efe:	mov    $0x1a4,%esi
  764f03:	mov    $0x104,%edx
  764f08:	call   *0x35437a(%rip)        # ab9288 <_DYNAMIC+0x558>
  764f0e:	mov    0x3b0(%rsp),%r13
  764f16:	mov    0x3b8(%rsp),%ebp
  764f1d:	mov    0x3bc(%rsp),%r12d
  764f25:	cmp    $0x2,%r13
  764f29:	je     76551f <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x78f>
  764f2f:	lea    0x3c0(%rsp),%rsi
  764f37:	lea    0xb30(%rsp),%rdi
  764f3f:	mov    $0x1d8,%edx
  764f44:	call   *0x354046(%rip)        # ab8f90 <memcpy@GLIBC_2.14>
  764f4a:	mov    %r13,0xb20(%rsp)
  764f52:	mov    %ebp,0xb28(%rsp)
  764f59:	mov    %r12d,0xb2c(%rsp)
  764f61:	call   *0x354329(%rip)        # ab9290 <_DYNAMIC+0x560>
  764f67:	mov    %rax,%r12
  764f6a:	lea    0x110(%rsp),%rdi
  764f72:	call   *0x354320(%rip)        # ab9298 <_DYNAMIC+0x568>
  764f78:	mov    %rbx,0x650(%rsp)
  764f80:	movl   $0x0,0x658(%rsp)
  764f8b:	movups 0xf4(%rsp),%xmm0
  764f93:	movups 0x100(%rsp),%xmm1
  764f9b:	movups %xmm0,0x65c(%rsp)
  764fa3:	movups %xmm1,0x668(%rsp)
  764fab:	movl   $0x0,0x678(%rsp)
  764fb6:	movups 0x88(%rsp),%xmm0
  764fbe:	movups 0x98(%rsp),%xmm1
  764fc6:	movups 0xa8(%rsp),%xmm2
  764fce:	movups 0xb8(%rsp),%xmm3
  764fd6:	movups %xmm0,0x5d8(%rsp)
  764fde:	movups %xmm1,0x5e8(%rsp)
  764fe6:	movups %xmm2,0x5f8(%rsp)
  764fee:	movups %xmm3,0x608(%rsp)
  764ff6:	movups 0xc8(%rsp),%xmm0
  764ffe:	movups %xmm0,0x618(%rsp)
  765006:	movups 0xd8(%rsp),%xmm0
  76500e:	movups %xmm0,0x628(%rsp)
  765016:	mov    0xe8(%rsp),%rax
  76501e:	mov    %rax,0x638(%rsp)
  765026:	lea    0x6b0(%rsp),%rdi
  76502e:	lea    0x110(%rsp),%rsi
  765036:	mov    0x353f53(%rip),%rbx        # ab8f90 <memcpy@GLIBC_2.14>
  76503d:	mov    $0x298,%edx
  765042:	call   *%rbx
  765044:	lea    0x3b0(%rsp),%rdi
  76504c:	lea    0xb20(%rsp),%rsi
  765054:	mov    $0x1e8,%edx
  765059:	call   *%rbx
  76505b:	mov    0x10(%rsp),%rax
  765060:	mov    %rax,0x640(%rsp)
  765068:	mov    %r14,0x648(%rsp)
  765070:	movq   $0x0,0x680(%rsp)
  76507c:	movq   $0x8,0x688(%rsp)
  765088:	xorps  %xmm0,%xmm0
  76508b:	movups %xmm0,0x690(%rsp)
  765093:	movq   $0x8,0x6a0(%rsp)
  76509f:	movq   $0x0,0x6a8(%rsp)
  7650ab:	movq   $0x0,0x9c8(%rsp)
  7650b7:	movups %xmm0,0x598(%rsp)
  7650bf:	movups %xmm0,0x5a8(%rsp)
  7650c7:	movups %xmm0,0x9b0(%rsp)
  7650cf:	movq   $0x1,0x9d0(%rsp)
  7650db:	movq   $0x0,0x9d8(%rsp)
  7650e7:	mov    %r12,0x9a0(%rsp)
  7650ef:	movq   $0x0,0x9e8(%rsp)
  7650fb:	movq   $0x0,0xa30(%rsp)
  765107:	movups %xmm0,0x9f8(%rsp)
  76510f:	movq   $0x0,0xa08(%rsp)
  76511b:	movups %xmm0,0xa18(%rsp)
  765123:	movq   $0x0,0x948(%rsp)
  76512f:	movq   $0x8,0x950(%rsp)
  76513b:	movups %xmm0,0x958(%rsp)
  765143:	movq   $0x0,0xa38(%rsp)
  76514f:	movq   $0x0,0xa48(%rsp)
  76515b:	movl   $0x1000101,0xb18(%rsp)
  765166:	movw   $0x0,0xb1c(%rsp)
  765170:	movups %xmm0,0xa50(%rsp)
  765178:	movups %xmm0,0xa60(%rsp)
  765180:	movq   $0x0,0xa70(%rsp)
  76518c:	mov    %r15,0xa78(%rsp)
  765194:	movsd  -0x6a21fc(%rip),%xmm1        # c2fa0 <GCC_except_table0+0xc00>
  76519c:	movsd  %xmm1,0xb10(%rsp)
  7651a5:	movq   $0x1,0x9a8(%rsp)
  7651b1:	movq   $0xffffffffffffffff,0x978(%rsp)
  7651bd:	movq   $0x0,0xa80(%rsp)
  7651c9:	movq   $0x0,0xa90(%rsp)
  7651d5:	movq   $0x8,0x968(%rsp)
  7651e1:	movq   $0x0,0x970(%rsp)
  7651ed:	movb   $0x0,0xb1e(%rsp)
  7651f5:	movups %xmm0,0xaf8(%rsp)
  7651fd:	movups %xmm0,0xae8(%rsp)
  765205:	movups %xmm0,0xad8(%rsp)
  76520d:	movups %xmm0,0xac8(%rsp)
  765215:	movups %xmm0,0xab8(%rsp)
  76521d:	movups %xmm0,0xaa8(%rsp)
  765225:	movups %xmm0,0xa98(%rsp)
  76522d:	movq   $0x0,0xb08(%rsp)
  765239:	call   *0x353d39(%rip)        # ab8f78 <_DYNAMIC+0x248>
  76523f:	mov    $0x770,%edi
  765244:	mov    $0x8,%esi
  765249:	call   *0x353d31(%rip)        # ab8f80 <_DYNAMIC+0x250>
  76524f:	test   %rax,%rax
  765252:	je     76545d <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x6cd>
  765258:	mov    %rax,%rbx
  76525b:	lea    0x3b0(%rsp),%rsi
  765263:	mov    $0x770,%edx
  765268:	mov    %rax,%rdi
  76526b:	call   *0x353d1f(%rip)        # ab8f90 <memcpy@GLIBC_2.14>
  765271:	mov    %rbx,0x20(%rsp)
  765276:	lea    0x28(%rsp),%rdx
  76527b:	movq   $0x0,(%rsp)
  765283:	lea    0x28(%rsp),%rdi
  765288:	mov    $0x8,%r8d
  76528e:	mov    %rbx,%rsi
  765291:	mov    $0x1,%ecx
  765296:	xor    %r9d,%r9d
  765299:	call   7691e0 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB4_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE21describe_with_changedBW_>
  76529e:	mov    0x28(%rsp),%r13
  7652a3:	cmp    $0xfffffffffffffffe,%r13
  7652a7:	jne    765472 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x6e2>
  7652ad:	lea    0x28(%rsp),%rdi
  7652b2:	mov    %rbx,%rsi
  7652b5:	call   78cd70 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE7presentBO_>
  7652ba:	mov    0x28(%rsp),%r13
  7652bf:	cmp    $0xfffffffffffffffe,%r13
  7652c3:	jne    765472 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x6e2>
  7652c9:	mov    0x20(%rsp),%rbx
  7652ce:	lea    0x3b0(%rsp),%rdi
  7652d6:	mov    %rbx,%rsi
  7652d9:	call   760560 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack>
  7652de:	test   %rbx,%rbx
  7652e1:	je     765537 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x7a7>
  7652e7:	cmpb   $0x0,0x76e(%rbx)
  7652ee:	jne    76553e <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x7ae>
  7652f4:	cmpb   $0x1,0x76a(%rbx)
  7652fb:	jne    765545 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x7b5>
  765301:	mov    0x5c0(%rbx),%r12
  765308:	mov    $0x1a,%eax
  76530d:	mov    %rax,0x10(%rsp)
  765312:	test   %r12,%r12
  765315:	je     76554f <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x7bf>
  76531b:	mov    0x5b8(%rbx),%r13
  765322:	shl    $0x6,%r12
  765326:	lea    0x1e8(%rbx),%r14
  76532d:	xor    %ebp,%ebp
  76532f:	mov    0x353cfa(%rip),%r15        # ab9030 <_DYNAMIC+0x300>
  765336:	jmp    76534d <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x5bd>
  765338:	nopl   0x0(%rax,%rax,1)
  765340:	add    $0x40,%rbp
  765344:	cmp    %rbp,%r12
  765347:	je     76554f <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x7bf>
  76534d:	cmpb   $0x4,0x3d(%r13,%rbp,1)
  765353:	jne    765340 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x5b0>
  765355:	mov    0x20(%r13,%rbp,1),%rsi
  76535a:	mov    %r14,%rdi
  76535d:	call   *%r15
  765360:	test   %al,%al
  765362:	je     765340 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x5b0>
  765364:	mov    0x20(%r13,%rbp,1),%rsi
  765369:	lea    0x5f0(%rbx),%r12
  765370:	mov    %r12,%rdi
  765373:	call   *0x353e57(%rip)        # ab91d0 <_DYNAMIC+0x4a0>
  765379:	cmpb   $0x0,0x76e(%rbx)
  765380:	jne    765595 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x805>
  765386:	mov    %rax,%r14
  765389:	cmp    (%r12),%rax
  76538d:	jne    76559c <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x80c>
  765393:	mov    %rdx,%r15
  765396:	mov    0x628(%rbx),%r12
  76539d:	mov    0x630(%rbx),%r13
  7653a4:	lea    0x3b0(%rsp),%rdi
  7653ac:	mov    %rbx,%rsi
  7653af:	call   78c610 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE16resolve_identityBO_>
  7653b4:	mov    0x3b0(%rsp),%rax
  7653bc:	mov    0x3b8(%rsp),%rdi
  7653c4:	cmp    $0xfffffffffffffffe,%rax
  7653c8:	jne    7655a3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x813>
  7653ce:	mov    0x2e0(%rbx),%rsi
  7653d5:	cmp    %rsi,%rdi
  7653d8:	jae    7655d9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x849>
  7653de:	lea    (%rdi,%rdi,4),%rdi
  7653e2:	shl    $0x3,%rdi
  7653e6:	add    0x2d8(%rbx),%rdi
  7653ed:	call   *0x353ead(%rip)        # ab92a0 <_DYNAMIC+0x570>
  7653f3:	test   %al,%al
  7653f5:	je     7655eb <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x85b>
  7653fb:	mov    %r14,0x628(%rbx)
  765402:	mov    %r15,0x630(%rbx)
  765409:	movq   $0x0,0x758(%rbx)
  765414:	lea    0x110(%rsp),%rdi
  76541c:	mov    %rbx,%rsi
  76541f:	mov    %r12,%rdx
  765422:	mov    %r13,%rcx
  765425:	call   770240 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE20publish_focus_changeB12_>
  76542a:	cmpl   $0xfffffffe,0x110(%rsp)
  765432:	jne    765633 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x8a3>
  765438:	lea    0x3b0(%rsp),%rdi
  765440:	mov    %rbx,%rsi
  765443:	call   760560 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack>
  765448:	mov    %rbx,%rax
  76544b:	add    $0xd08,%rsp
  765452:	pop    %rbx
  765453:	pop    %r12
  765455:	pop    %r13
  765457:	pop    %r14
  765459:	pop    %r15
  76545b:	pop    %rbp
  76545c:	ret
  76545d:	mov    $0x8,%edi
  765462:	mov    $0x770,%esi
  765467:	call   *0x353b1b(%rip)        # ab8f88 <_DYNAMIC+0x258>
  76546d:	jmp    7657a2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xa12>
  765472:	mov    0x30(%rsp),%rbp
  765477:	movups 0x38(%rsp),%xmm0
  76547c:	movaps %xmm0,0x70(%rsp)
  765481:	movups 0x48(%rsp),%xmm0
  765486:	movaps %xmm0,0x60(%rsp)
  76548b:	movzbl 0x58(%rsp),%r15d
  765491:	mov    0x59(%rsp),%eax
  765495:	mov    %eax,0x18(%rsp)
  765499:	mov    0x5c(%rsp),%eax
  76549d:	mov    %eax,0x1b(%rsp)
  7654a1:	mov    0x20(%rsp),%rbx
  7654a6:	test   %rbx,%rbx
  7654a9:	je     7654c6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x736>
  7654ab:	mov    %rbx,%rdi
  7654ae:	call   747d70 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui7runtime7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEEB1h_>
  7654b3:	mov    $0x770,%esi
  7654b8:	mov    $0x8,%edx
  7654bd:	mov    %rbx,%rdi
  7654c0:	call   *0x353aaa(%rip)        # ab8f70 <_DYNAMIC+0x240>
  7654c6:	mov    %rbp,%r12
  7654c9:	shr    $0x20,%r12
  7654cd:	jmp    765729 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x999>
  7654d2:	mov    0x3b8(%rsp),%rbp
  7654da:	mov    %rbp,%r12
  7654dd:	shr    $0x20,%r12
  7654e1:	movups 0x3c0(%rsp),%xmm0
  7654e9:	movaps %xmm0,0x70(%rsp)
  7654ee:	movups 0x3d0(%rsp),%xmm0
  7654f6:	movaps %xmm0,0x60(%rsp)
  7654fb:	movzbl 0x3e0(%rsp),%r15d
  765504:	mov    0x3e1(%rsp),%eax
  76550b:	mov    %eax,0x18(%rsp)
  76550f:	mov    0x3e4(%rsp),%eax
  765516:	mov    %eax,0x1b(%rsp)
  76551a:	jmp    76570e <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x97e>
  76551f:	lea    0x88(%rsp),%rdi
  765527:	call   747bc0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui6source7SourcesNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEEB1g_>
  76552c:	mov    $0x23,%r13d
  765532:	jmp    76570e <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x97e>
  765537:	mov    $0xd,%eax
  76553c:	jmp    76554a <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x7ba>
  76553e:	mov    $0xe,%eax
  765543:	jmp    76554a <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x7ba>
  765545:	mov    $0x12,%eax
  76554a:	mov    %rax,0x10(%rsp)
  76554f:	mov    0x10(%rsp),%rax
  765554:	mov    %rax,0x3b0(%rsp)
  76555c:	movq   $0x0,0x3b8(%rsp)
  765568:	lea    -0x695bce(%rip),%rdi        # cf9a1 <GCC_except_table0+0xd601>
  76556f:	lea    0x3344f2(%rip),%rcx        # a99a68 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1290>
  765576:	lea    0x333e3b(%rip),%r8        # a993b8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xbe0>
  76557d:	lea    0x3b0(%rsp),%rdx
  765585:	mov    $0x2a,%esi
  76558a:	call   *0x353ab0(%rip)        # ab9040 <_DYNAMIC+0x310>
  765590:	jmp    7657a2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xa12>
  765595:	mov    $0xe,%eax
  76559a:	jmp    7655f0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x860>
  76559c:	mov    $0x11,%eax
  7655a1:	jmp    7655bb <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x82b>
  7655a3:	movups 0x3c0(%rsp),%xmm0
  7655ab:	movups 0x3d0(%rsp),%xmm1
  7655b3:	movzbl 0x3e0(%rsp),%ecx
  7655bb:	mov    0x3e1(%rsp),%edx
  7655c2:	mov    0x3e4(%rsp),%esi
  7655c9:	mov    %esi,0xb23(%rsp)
  7655d0:	mov    %edx,0xb20(%rsp)
  7655d7:	jmp    7655f0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x860>
  7655d9:	lea    0x3349b0(%rip),%rdx        # a99f90 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x17b8>
  7655e0:	call   *0x3539ba(%rip)        # ab8fa0 <_DYNAMIC+0x270>
  7655e6:	jmp    7657a2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xa12>
  7655eb:	mov    $0x16,%eax
  7655f0:	mov    %rax,0x110(%rsp)
  7655f8:	mov    %rdi,0x118(%rsp)
  765600:	movups %xmm0,0x120(%rsp)
  765608:	movups %xmm1,0x130(%rsp)
  765610:	mov    %cl,0x140(%rsp)
  765617:	mov    0xb20(%rsp),%eax
  76561e:	mov    0xb23(%rsp),%ecx
  765625:	mov    %eax,0x141(%rsp)
  76562c:	mov    %ecx,0x144(%rsp)
  765633:	mov    0x140(%rsp),%rax
  76563b:	mov    %rax,0x3e0(%rsp)
  765643:	mov    0x110(%rsp),%rax
  76564b:	mov    0x118(%rsp),%rcx
  765653:	movups 0x120(%rsp),%xmm0
  76565b:	movups 0x130(%rsp),%xmm1
  765663:	movaps %xmm1,0x3d0(%rsp)
  76566b:	movaps %xmm0,0x3c0(%rsp)
  765673:	mov    %rax,0x3b0(%rsp)
  76567b:	mov    %rcx,0x3b8(%rsp)
  765683:	lea    -0x695a60(%rip),%rdi        # cfc2a <GCC_except_table0+0xd88a>
  76568a:	lea    0x3343d7(%rip),%rcx        # a99a68 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1290>
  765691:	lea    0x334340(%rip),%r8        # a999d8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1200>
  765698:	lea    0x3b0(%rsp),%rdx
  7656a0:	mov    $0x2b,%esi
  7656a5:	call   *0x353995(%rip)        # ab9040 <_DYNAMIC+0x310>
  7656ab:	jmp    7657a2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xa12>
  7656b0:	mov    %rax,%r15
  7656b3:	mov    $0x770,%esi
  7656b8:	mov    $0x8,%edx
  7656bd:	mov    %rbx,%rdi
  7656c0:	call   *0x3538aa(%rip)        # ab8f70 <_DYNAMIC+0x240>
  7656c6:	mov    %r15,%rdi
  7656c9:	call   a97420 <_Unwind_Resume@plt>
  7656ce:	mov    %rax,%r15
  7656d1:	jmp    7657ec <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xa5c>
  7656d6:	mov    %rax,%rdi
  7656d9:	call   *0x3538e9(%rip)        # ab8fc8 <_DYNAMIC+0x298>
  7656df:	mov    %rax,%r12
  7656e2:	mov    %rdx,%r13
  7656e5:	mov    (%rdx),%rax
  7656e8:	test   %rax,%rax
  7656eb:	je     7656f2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x962>
  7656ed:	mov    %r12,%rdi
  7656f0:	call   *%rax
  7656f2:	mov    0x8(%r13),%rsi
  7656f6:	test   %rsi,%rsi
  7656f9:	je     765708 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x978>
  7656fb:	mov    0x10(%r13),%rdx
  7656ff:	mov    %r12,%rdi
  765702:	call   *0x353868(%rip)        # ab8f70 <_DYNAMIC+0x240>
  765708:	mov    $0xf,%r13d
  76570e:	cmpq   $0x0,0x10(%rsp)
  765714:	je     765729 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x999>
  765716:	mov    $0x1,%edx
  76571b:	mov    %r14,%rdi
  76571e:	mov    0x10(%rsp),%rsi
  765723:	call   *0x353847(%rip)        # ab8f70 <_DYNAMIC+0x240>
  765729:	mov    %r13,0x110(%rsp)
  765731:	shl    $0x20,%r12
  765735:	mov    %ebp,%eax
  765737:	or     %r12,%rax
  76573a:	mov    %rax,0x118(%rsp)
  765742:	movaps 0x70(%rsp),%xmm0
  765747:	movups %xmm0,0x120(%rsp)
  76574f:	movaps 0x60(%rsp),%xmm0
  765754:	movups %xmm0,0x130(%rsp)
  76575c:	mov    %r15b,0x140(%rsp)
  765764:	mov    0x18(%rsp),%eax
  765768:	mov    0x1b(%rsp),%ecx
  76576c:	mov    %eax,0x141(%rsp)
  765773:	mov    %ecx,0x144(%rsp)
  76577a:	lea    -0x695b57(%rip),%rdi        # cfc2a <GCC_except_table0+0xd88a>
  765781:	lea    0x3342e0(%rip),%rcx        # a99a68 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1290>
  765788:	lea    0x334231(%rip),%r8        # a999c0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x11e8>
  76578f:	lea    0x110(%rsp),%rdx
  765797:	mov    $0x2b,%esi
  76579c:	call   *0x35389e(%rip)        # ab9040 <_DYNAMIC+0x310>
  7657a2:	ud2
  7657a4:	mov    %rax,%r15
  7657a7:	mov    0x8(%r13),%rsi
  7657ab:	test   %rsi,%rsi
  7657ae:	je     7657f9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xa69>
  7657b0:	mov    0x10(%r13),%rdx
  7657b4:	mov    %r12,%rdi
  7657b7:	call   *0x3537b3(%rip)        # ab8f70 <_DYNAMIC+0x240>
  7657bd:	jmp    7657f9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xa69>
  7657bf:	call   *0x35380b(%rip)        # ab8fd0 <_DYNAMIC+0x2a0>
  7657c5:	mov    %rax,%r15
  7657c8:	jmp    7657f9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xa69>
  7657ca:	mov    %rax,%r15
  7657cd:	mov    0x20(%rsp),%rdi
  7657d2:	call   747d10 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui7runtime3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEEB1d_>
  7657d7:	jmp    765873 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xae3>
  7657dc:	mov    %rax,%r15
  7657df:	lea    0xb20(%rsp),%rdi
  7657e7:	call   74d090 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas6canvas6CanvasECs9C2G9YFESsD_29canonical_text_public_control>
  7657ec:	lea    0x88(%rsp),%rdi
  7657f4:	call   747bc0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui6source7SourcesNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEEB1g_>
  7657f9:	cmpq   $0x0,0x10(%rsp)
  7657ff:	je     765873 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xae3>
  765801:	mov    $0x1,%edx
  765806:	mov    %r14,%rdi
  765809:	mov    0x10(%rsp),%rsi
  76580e:	call   *0x35375c(%rip)        # ab8f70 <_DYNAMIC+0x240>
  765814:	mov    %r15,%rdi
  765817:	call   a97420 <_Unwind_Resume@plt>
  76581c:	call   *0x353776(%rip)        # ab8f98 <_DYNAMIC+0x268>
  765822:	mov    %rax,%r15
  765825:	lea    0x110(%rsp),%rdi
  76582d:	call   74d580 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  765832:	mov    %r15,%rdi
  765835:	call   a97420 <_Unwind_Resume@plt>
  76583a:	jmp    765843 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xab3>
  76583c:	jmp    76583e <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xaae>
  76583e:	mov    %rax,%r15
  765841:	jmp    765853 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xac3>
  765843:	mov    %rax,%r15
  765846:	lea    0x3b0(%rsp),%rdi
  76584e:	call   74d580 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  765853:	mov    %rbx,%rdi
  765856:	call   747d10 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui7runtime3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEEB1d_>
  76585b:	jmp    765873 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xae3>
  76585d:	call   *0x353735(%rip)        # ab8f98 <_DYNAMIC+0x268>
  765863:	mov    %rax,%r15
  765866:	lea    0x3b0(%rsp),%rdi
  76586e:	call   747d70 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui7runtime7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEEB1h_>
  765873:	mov    %r15,%rdi
  765876:	call   a97420 <_Unwind_Resume@plt>
  76587b:	call   *0x353717(%rip)        # ab8f98 <_DYNAMIC+0x268>

canonical_text_public_control::source bytes=2078 frame=88

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000765890 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source>:
  765890:	push   %r15
  765892:	push   %r14
  765894:	push   %rbx
  765895:	sub    $0x40,%rsp
  765899:	mov    %rsi,0x20(%rsp)
  76589e:	mov    %rdx,0x28(%rsp)
  7658a3:	lea    -0x3(%rdx),%rax
  7658a7:	cmp    $0xa,%rax
  7658ab:	ja     765fea <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x75a>
  7658b1:	mov    %rdi,%rbx
  7658b4:	lea    -0x6a18e7(%rip),%rcx        # c3fd4 <GCC_except_table0+0x1c34>
  7658bb:	movslq (%rcx,%rax,4),%rax
  7658bf:	add    %rcx,%rax
  7658c2:	jmp    *%rax
  7658c4:	lea    -0x695eec(%rip),%rax        # cf9df <GCC_except_table0+0xd63f>
  7658cb:	mov    %rsi,%rdi
  7658ce:	mov    %rax,%rsi
  7658d1:	call   *0x353961(%rip)        # ab9238 <bcmp@GLIBC_2.2.5>
  7658d7:	test   %eax,%eax
  7658d9:	jne    765fea <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x75a>
  7658df:	call   *0x353693(%rip)        # ab8f78 <_DYNAMIC+0x248>
  7658e5:	mov    $0x1b80,%edi
  7658ea:	mov    $0x1,%esi
  7658ef:	call   *0x35368b(%rip)        # ab8f80 <_DYNAMIC+0x250>
  7658f5:	test   %rax,%rax
  7658f8:	je     766019 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x789>
  7658fe:	mov    %rax,%r14
  765901:	movups -0x695d16(%rip),%xmm0        # cfbf2 <GCC_except_table0+0xd852>
  765908:	movups %xmm0,0x20(%rax)
  76590c:	movabs $0x20aad7a9d7a8d7a7,%rax
  765916:	mov    %rax,0x2f(%r14)
  76591a:	movups -0x695d3f(%rip),%xmm1        # cfbe2 <GCC_except_table0+0xd842>
  765921:	movups %xmm1,0x10(%r14)
  765926:	movups -0x695d5b(%rip),%xmm2        # cfbd2 <GCC_except_table0+0xd832>
  76592d:	movups %xmm2,(%r14)
  765931:	movups %xmm2,0x37(%r14)
  765936:	movups %xmm1,0x47(%r14)
  76593b:	movups %xmm0,0x57(%r14)
  765940:	mov    %rax,0x66(%r14)
  765944:	movups %xmm2,0x6e(%r14)
  765949:	movups %xmm1,0x7e(%r14)
  76594e:	movups 0x20(%r14),%xmm0
  765953:	movups %xmm0,0x8e(%r14)
  76595b:	movups 0x30(%r14),%xmm0
  765960:	movups %xmm0,0x9e(%r14)
  765968:	movups 0x40(%r14),%xmm0
  76596d:	movups %xmm0,0xae(%r14)
  765975:	movups 0x50(%r14),%xmm0
  76597a:	movups %xmm0,0xbe(%r14)
  765982:	mov    0x5e(%r14),%rax
  765986:	mov    %rax,0xcc(%r14)
  76598d:	mov    0x66(%r14),%rax
  765991:	mov    %rax,0xd4(%r14)
  765998:	lea    0xdc(%r14),%rdi
  76599f:	mov    0x3535ea(%rip),%r15        # ab8f90 <memcpy@GLIBC_2.14>
  7659a6:	mov    $0xdc,%edx
  7659ab:	mov    %r14,%rsi
  7659ae:	call   *%r15
  7659b1:	lea    0x1b8(%r14),%rdi
  7659b8:	mov    $0x1b8,%edx
  7659bd:	mov    %r14,%rsi
  7659c0:	call   *%r15
  7659c3:	lea    0x370(%r14),%rdi
  7659ca:	mov    $0x370,%edx
  7659cf:	mov    %r14,%rsi
  7659d2:	call   *%r15
  7659d5:	lea    0x6e0(%r14),%rdi
  7659dc:	mov    $0x6e0,%edx
  7659e1:	mov    %r14,%rsi
  7659e4:	call   *%r15
  7659e7:	mov    %r14,%rdi
  7659ea:	add    $0xdc0,%rdi
  7659f1:	mov    $0xdc0,%edx
  7659f6:	mov    %r14,%rsi
  7659f9:	call   *%r15
  7659fc:	movq   $0x1b80,(%rbx)
  765a03:	mov    %r14,0x8(%rbx)
  765a07:	movq   $0x1b80,0x10(%rbx)
  765a0f:	jmp    765fe0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x750>
  765a14:	mov    $0x74706d65,%eax
  765a19:	xor    (%rsi),%eax
  765a1b:	movzbl 0x4(%rsi),%ecx
  765a1f:	xor    $0x79,%ecx
  765a22:	or     %eax,%ecx
  765a24:	je     765f7d <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x6ed>
  765a2a:	mov    $0x6562616c,%eax
  765a2f:	xor    (%rsi),%eax
  765a31:	movzbl 0x4(%rsi),%ecx
  765a35:	xor    $0x6c,%ecx
  765a38:	or     %eax,%ecx
  765a3a:	je     765f96 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x706>
  765a40:	lea    -0x696065(%rip),%rax        # cf9e2 <GCC_except_table0+0xd642>
  765a47:	mov    %rsi,%rdi
  765a4a:	mov    %rax,%rsi
  765a4d:	call   *0x3537e5(%rip)        # ab9238 <bcmp@GLIBC_2.2.5>
  765a53:	test   %eax,%eax
  765a55:	jne    765fea <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x75a>
  765a5b:	call   *0x353517(%rip)        # ab8f78 <_DYNAMIC+0x248>
  765a61:	mov    $0x880,%edi
  765a66:	mov    $0x1,%esi
  765a6b:	call   *0x35350f(%rip)        # ab8f80 <_DYNAMIC+0x250>
  765a71:	test   %rax,%rax
  765a74:	je     766069 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x7d9>
  765a7a:	mov    %rax,%r14
  765a7d:	movups -0x695ec4(%rip),%xmm0        # cfbc0 <GCC_except_table0+0xd820>
  765a84:	movups %xmm0,0x10(%rax)
  765a88:	movups -0x695edf(%rip),%xmm1        # cfbb0 <GCC_except_table0+0xd810>
  765a8f:	movups %xmm1,(%rax)
  765a92:	movw   $0xa0d,0x20(%rax)
  765a98:	movups %xmm1,0x22(%rax)
  765a9c:	movups %xmm0,0x32(%rax)
  765aa0:	movw   $0xa0d,0x42(%rax)
  765aa6:	movups %xmm1,0x44(%rax)
  765aaa:	movups %xmm0,0x54(%rax)
  765aae:	movzwl 0x20(%rax),%eax
  765ab2:	mov    %ax,0x64(%r14)
  765ab7:	mov    0x22(%r14),%rax
  765abb:	mov    %rax,0x66(%r14)
  765abf:	mov    0x2a(%r14),%eax
  765ac3:	mov    %eax,0x6e(%r14)
  765ac7:	movzwl 0x2e(%r14),%eax
  765acc:	mov    %ax,0x72(%r14)
  765ad1:	movups 0x30(%r14),%xmm0
  765ad6:	movups %xmm0,0x74(%r14)
  765adb:	mov    0x40(%r14),%eax
  765adf:	mov    %eax,0x84(%r14)
  765ae6:	lea    0x88(%r14),%rdi
  765aed:	mov    0x35349c(%rip),%r15        # ab8f90 <memcpy@GLIBC_2.14>
  765af4:	mov    $0x88,%edx
  765af9:	mov    %r14,%rsi
  765afc:	call   *%r15
  765aff:	lea    0x110(%r14),%rdi
  765b06:	mov    $0x110,%edx
  765b0b:	mov    %r14,%rsi
  765b0e:	call   *%r15
  765b11:	lea    0x220(%r14),%rdi
  765b18:	mov    $0x220,%edx
  765b1d:	mov    %r14,%rsi
  765b20:	call   *%r15
  765b23:	mov    %r14,%rdi
  765b26:	add    $0x440,%rdi
  765b2d:	mov    $0x440,%edx
  765b32:	mov    %r14,%rsi
  765b35:	call   *%r15
  765b38:	movq   $0x880,(%rbx)
  765b3f:	mov    %r14,0x8(%rbx)
  765b43:	movq   $0x880,0x10(%rbx)
  765b4b:	jmp    765fe0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x750>
  765b50:	cmpl   $0x796e6974,(%rsi)
  765b56:	jne    765fea <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x75a>
  765b5c:	call   *0x353416(%rip)        # ab8f78 <_DYNAMIC+0x248>
  765b62:	mov    $0x1,%edi
  765b67:	mov    $0x1,%esi
  765b6c:	call   *0x35340e(%rip)        # ab8f80 <_DYNAMIC+0x250>
  765b72:	test   %rax,%rax
  765b75:	je     766029 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x799>
  765b7b:	movb   $0x61,(%rax)
  765b7e:	movq   $0x1,(%rbx)
  765b85:	mov    %rax,0x8(%rbx)
  765b89:	movq   $0x1,0x10(%rbx)
  765b91:	jmp    765fe0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x750>
  765b96:	lea    -0x6961b6(%rip),%rax        # cf9e7 <GCC_except_table0+0xd647>
  765b9d:	mov    %rsi,%rdi
  765ba0:	mov    %rax,%rsi
  765ba3:	call   *0x35368f(%rip)        # ab9238 <bcmp@GLIBC_2.2.5>
  765ba9:	test   %eax,%eax
  765bab:	jne    765fea <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x75a>
  765bb1:	call   *0x3533c1(%rip)        # ab8f78 <_DYNAMIC+0x248>
  765bb7:	mov    $0x580,%edi
  765bbc:	mov    $0x1,%esi
  765bc1:	call   *0x3533b9(%rip)        # ab8f80 <_DYNAMIC+0x250>
  765bc7:	test   %rax,%rax
  765bca:	je     766039 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x7a9>
  765bd0:	mov    %rax,%r14
  765bd3:	movabs $0x616c0aa880e20a0d,%rax
  765bdd:	mov    %rax,(%r14)
  765be0:	movl   $0xa747361,0x7(%r14)
  765be8:	mov    %rax,0xb(%r14)
  765bec:	movl   $0xa747361,0x12(%r14)
  765bf4:	movups (%r14),%xmm0
  765bf8:	movups %xmm0,0x16(%r14)
  765bfd:	mov    0xe(%r14),%rax
  765c01:	mov    %rax,0x24(%r14)
  765c05:	movups %xmm0,0x2c(%r14)
  765c0a:	movups 0x10(%r14),%xmm1
  765c0f:	movups %xmm1,0x3c(%r14)
  765c14:	mov    0x1c(%r14),%rax
  765c18:	mov    %rax,0x48(%r14)
  765c1c:	mov    0x24(%r14),%rax
  765c20:	mov    %rax,0x50(%r14)
  765c24:	movups %xmm0,0x58(%r14)
  765c29:	movups %xmm1,0x68(%r14)
  765c2e:	mov    0x20(%r14),%eax
  765c32:	mov    %eax,0x78(%r14)
  765c36:	mov    0x24(%r14),%rax
  765c3a:	mov    %rax,0x7c(%r14)
  765c3e:	mov    0x2c(%r14),%eax
  765c42:	mov    %eax,0x84(%r14)
  765c49:	movups 0x30(%r14),%xmm0
  765c4e:	movups %xmm0,0x88(%r14)
  765c56:	mov    0x40(%r14),%rax
  765c5a:	mov    %rax,0x98(%r14)
  765c61:	mov    0x48(%r14),%rax
  765c65:	mov    %rax,0xa0(%r14)
  765c6c:	mov    0x50(%r14),%rax
  765c70:	mov    %rax,0xa8(%r14)
  765c77:	lea    0xb0(%r14),%rdi
  765c7e:	mov    0x35330b(%rip),%r15        # ab8f90 <memcpy@GLIBC_2.14>
  765c85:	mov    $0xb0,%edx
  765c8a:	mov    %r14,%rsi
  765c8d:	call   *%r15
  765c90:	lea    0x160(%r14),%rdi
  765c97:	mov    $0x160,%edx
  765c9c:	mov    %r14,%rsi
  765c9f:	call   *%r15
  765ca2:	mov    %r14,%rdi
  765ca5:	add    $0x2c0,%rdi
  765cac:	mov    $0x2c0,%edx
  765cb1:	mov    %r14,%rsi
  765cb4:	call   *%r15
  765cb7:	movq   $0x580,(%rbx)
  765cbe:	mov    %r14,0x8(%rbx)
  765cc2:	movq   $0x580,0x10(%rbx)
  765cca:	jmp    765fe0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x750>
  765ccf:	movabs $0x3364657070617277,%rax
  765cd9:	xor    (%rsi),%rax
  765cdc:	movzwl 0x8(%rsi),%ecx
  765ce0:	xor    $0x6b32,%rcx
  765ce7:	or     %rax,%rcx
  765cea:	jne    765fea <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x75a>
  765cf0:	call   *0x353282(%rip)        # ab8f78 <_DYNAMIC+0x248>
  765cf6:	mov    $0x8000,%edi
  765cfb:	mov    $0x1,%esi
  765d00:	call   *0x35327a(%rip)        # ab8f80 <_DYNAMIC+0x250>
  765d06:	test   %rax,%rax
  765d09:	je     766049 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x7b9>
  765d0f:	mov    %rax,%r14
  765d12:	movabs $0x6161616161616161,%rax
  765d1c:	mov    %rax,(%r14)
  765d1f:	mov    %rax,0x8(%r14)
  765d23:	movups (%r14),%xmm0
  765d27:	movups %xmm0,0x10(%r14)
  765d2c:	movups %xmm0,0x20(%r14)
  765d31:	movups %xmm0,0x30(%r14)
  765d36:	movups %xmm0,0x40(%r14)
  765d3b:	movups %xmm0,0x50(%r14)
  765d40:	movups %xmm0,0x60(%r14)
  765d45:	movups %xmm0,0x70(%r14)
  765d4a:	movups %xmm0,0xa0(%r14)
  765d52:	movups %xmm0,0xe0(%r14)
  765d5a:	movups %xmm0,0xb0(%r14)
  765d62:	movups %xmm0,0xf0(%r14)
  765d6a:	movups %xmm0,0xd0(%r14)
  765d72:	movups %xmm0,0xc0(%r14)
  765d7a:	movups %xmm0,0x90(%r14)
  765d82:	movups %xmm0,0x80(%r14)
  765d8a:	lea    0x100(%r14),%rdi
  765d91:	mov    0x3531f8(%rip),%r15        # ab8f90 <memcpy@GLIBC_2.14>
  765d98:	mov    $0x100,%edx
  765d9d:	mov    %r14,%rsi
  765da0:	call   *%r15
  765da3:	lea    0x200(%r14),%rdi
  765daa:	mov    $0x200,%edx
  765daf:	mov    %r14,%rsi
  765db2:	call   *%r15
  765db5:	lea    0x400(%r14),%rdi
  765dbc:	mov    $0x400,%edx
  765dc1:	mov    %r14,%rsi
  765dc4:	call   *%r15
  765dc7:	lea    0x800(%r14),%rdi
  765dce:	mov    $0x800,%edx
  765dd3:	mov    %r14,%rsi
  765dd6:	call   *%r15
  765dd9:	lea    0x1000(%r14),%rdi
  765de0:	mov    $0x1000,%edx
  765de5:	mov    %r14,%rsi
  765de8:	call   *%r15
  765deb:	lea    0x2000(%r14),%rdi
  765df2:	mov    $0x2000,%edx
  765df7:	mov    %r14,%rsi
  765dfa:	call   *%r15
  765dfd:	mov    %r14,%rdi
  765e00:	add    $0x4000,%rdi
  765e07:	mov    $0x4000,%edx
  765e0c:	mov    %r14,%rsi
  765e0f:	call   *%r15
  765e12:	movq   $0x8000,(%rbx)
  765e19:	mov    %r14,0x8(%rbx)
  765e1d:	movq   $0x8000,0x10(%rbx)
  765e25:	jmp    765fe0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x750>
  765e2a:	lea    -0x696441(%rip),%rax        # cf9f0 <GCC_except_table0+0xd650>
  765e31:	mov    %rsi,%rdi
  765e34:	mov    %rax,%rsi
  765e37:	call   *0x3533fb(%rip)        # ab9238 <bcmp@GLIBC_2.2.5>
  765e3d:	test   %eax,%eax
  765e3f:	jne    765fea <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x75a>
  765e45:	call   *0x35312d(%rip)        # ab8f78 <_DYNAMIC+0x248>
  765e4b:	mov    $0x800,%edi
  765e50:	mov    $0x1,%esi
  765e55:	call   *0x353125(%rip)        # ab8f80 <_DYNAMIC+0x250>
  765e5b:	test   %rax,%rax
  765e5e:	je     766059 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x7c9>
  765e64:	mov    %rax,%r14
  765e67:	movabs $0x81cc81cc81cc81cc,%rax
  765e71:	mov    %rax,(%r14)
  765e74:	mov    %rax,0x8(%r14)
  765e78:	movups (%r14),%xmm0
  765e7c:	movups %xmm0,0x10(%r14)
  765e81:	movups %xmm0,0x20(%r14)
  765e86:	movups %xmm0,0x30(%r14)
  765e8b:	movups %xmm0,0x40(%r14)
  765e90:	movups %xmm0,0x50(%r14)
  765e95:	movups %xmm0,0x60(%r14)
  765e9a:	movups %xmm0,0x70(%r14)
  765e9f:	movups %xmm0,0x80(%r14)
  765ea7:	movups %xmm0,0xf0(%r14)
  765eaf:	movups %xmm0,0xe0(%r14)
  765eb7:	movups %xmm0,0xd0(%r14)
  765ebf:	movups %xmm0,0xc0(%r14)
  765ec7:	movups %xmm0,0xb0(%r14)
  765ecf:	movups %xmm0,0xa0(%r14)
  765ed7:	movups %xmm0,0x90(%r14)
  765edf:	lea    0x100(%r14),%rdi
  765ee6:	mov    0x3530a3(%rip),%r15        # ab8f90 <memcpy@GLIBC_2.14>
  765eed:	mov    $0x100,%edx
  765ef2:	mov    %r14,%rsi
  765ef5:	call   *%r15
  765ef8:	lea    0x200(%r14),%rdi
  765eff:	mov    $0x200,%edx
  765f04:	mov    %r14,%rsi
  765f07:	call   *%r15
  765f0a:	mov    %r14,%rdi
  765f0d:	add    $0x400,%rdi
  765f14:	mov    $0x400,%edx
  765f19:	mov    %r14,%rsi
  765f1c:	call   *%r15
  765f1f:	movq   $0x800,0x8(%rsp)
  765f28:	mov    %r14,0x10(%rsp)
  765f2d:	movq   $0x800,0x18(%rsp)
  765f36:	lea    0x8(%rsp),%rax
  765f3b:	mov    %rax,0x30(%rsp)
  765f40:	lea    0x32089(%rip),%rax        # 797fd0 <_RNvXsq_NtCscdodAO9FK5_5alloc6stringNtB5_6StringNtNtCs4NRVxsYgnAr_4core3fmt7Display3fmt>
  765f47:	mov    %rax,0x38(%rsp)
  765f4c:	lea    -0x6a0de2(%rip),%rsi        # c5171 <GCC_except_table0+0x2dd1>
  765f53:	lea    0x30(%rsp),%rdx
  765f58:	mov    %rbx,%rdi
  765f5b:	call   *0x353347(%rip)        # ab92a8 <_DYNAMIC+0x578>
  765f61:	mov    0x8(%rsp),%rsi
  765f66:	test   %rsi,%rsi
  765f69:	je     765fe0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x750>
  765f6b:	mov    0x10(%rsp),%rdi
  765f70:	mov    $0x1,%edx
  765f75:	call   *0x352ff5(%rip)        # ab8f70 <_DYNAMIC+0x240>
  765f7b:	jmp    765fe0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x750>
  765f7d:	movq   $0x0,(%rbx)
  765f84:	movq   $0x1,0x8(%rbx)
  765f8c:	movq   $0x0,0x10(%rbx)
  765f94:	jmp    765fe0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x750>
  765f96:	call   *0x352fdc(%rip)        # ab8f78 <_DYNAMIC+0x248>
  765f9c:	mov    $0x17,%edi
  765fa1:	mov    $0x1,%esi
  765fa6:	call   *0x352fd4(%rip)        # ab8f80 <_DYNAMIC+0x250>
  765fac:	test   %rax,%rax
  765faf:	je     766079 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x7e9>
  765fb5:	movups -0x6963b2(%rip),%xmm0        # cfc0a <GCC_except_table0+0xd86a>
  765fbc:	movups %xmm0,(%rax)
  765fbf:	movabs $0x92d791d790d72081,%rcx
  765fc9:	mov    %rcx,0xf(%rax)
  765fcd:	movq   $0x17,(%rbx)
  765fd4:	mov    %rax,0x8(%rbx)
  765fd8:	movq   $0x17,0x10(%rbx)
  765fe0:	add    $0x40,%rsp
  765fe4:	pop    %rbx
  765fe5:	pop    %r14
  765fe7:	pop    %r15
  765fe9:	ret
  765fea:	lea    0x20(%rsp),%rax
  765fef:	mov    %rax,0x8(%rsp)
  765ff4:	lea    0x300c5(%rip),%rax        # 7960c0 <_RNvXs1i_NtCs4NRVxsYgnAr_4core3fmtReNtB6_7Display3fmtCs9C2G9YFESsD_29canonical_text_public_control>
  765ffb:	mov    %rax,0x10(%rsp)
  766000:	lea    -0x69ef2b(%rip),%rdi        # c70dc <GCC_except_table0+0x4d3c>
  766007:	lea    0x3339fa(%rip),%rdx        # a99a08 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1230>
  76600e:	lea    0x8(%rsp),%rsi
  766013:	call   *0x352f8f(%rip)        # ab8fa8 <_DYNAMIC+0x278>
  766019:	mov    $0x1,%edi
  76601e:	mov    $0x1b80,%esi
  766023:	call   *0x352fff(%rip)        # ab9028 <_DYNAMIC+0x2f8>
  766029:	mov    $0x1,%edi
  76602e:	mov    $0x1,%esi
  766033:	call   *0x352fef(%rip)        # ab9028 <_DYNAMIC+0x2f8>
  766039:	mov    $0x1,%edi
  76603e:	mov    $0x580,%esi
  766043:	call   *0x352fdf(%rip)        # ab9028 <_DYNAMIC+0x2f8>
  766049:	mov    $0x1,%edi
  76604e:	mov    $0x8000,%esi
  766053:	call   *0x352fcf(%rip)        # ab9028 <_DYNAMIC+0x2f8>
  766059:	mov    $0x1,%edi
  76605e:	mov    $0x800,%esi
  766063:	call   *0x352fbf(%rip)        # ab9028 <_DYNAMIC+0x2f8>
  766069:	mov    $0x1,%edi
  76606e:	mov    $0x880,%esi
  766073:	call   *0x352faf(%rip)        # ab9028 <_DYNAMIC+0x2f8>
  766079:	mov    $0x1,%edi
  76607e:	mov    $0x17,%esi
  766083:	call   *0x352f9f(%rip)        # ab9028 <_DYNAMIC+0x2f8>
  766089:	mov    %rax,%rbx
  76608c:	mov    0x8(%rsp),%rsi
  766091:	test   %rsi,%rsi
  766094:	je     7660a6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x816>
  766096:	mov    0x10(%rsp),%rdi
  76609b:	mov    $0x1,%edx
  7660a0:	call   *0x352eca(%rip)        # ab8f70 <_DYNAMIC+0x240>
  7660a6:	mov    %rbx,%rdi
  7660a9:	call   a97420 <_Unwind_Resume@plt>

canonical_text_public_control::owner_hit bytes=416 frame=264

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007660b0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit>:
  7660b0:	push   %rbp
  7660b1:	push   %r15
  7660b3:	push   %r14
  7660b5:	push   %r13
  7660b7:	push   %r12
  7660b9:	push   %rbx
  7660ba:	sub    $0xd8,%rsp
  7660c1:	mov    (%rdi),%rsi
  7660c4:	test   %rsi,%rsi
  7660c7:	je     7661f3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit+0x143>
  7660cd:	cmpb   $0x0,0x76e(%rsi)
  7660d4:	jne    7661fa <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit+0x14a>
  7660da:	movss  %xmm0,0x8(%rsp)
  7660e0:	movss  %xmm1,0xc(%rsp)
  7660e6:	cmpb   $0x1,0x76c(%rsi)
  7660ed:	jne    766201 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit+0x151>
  7660f3:	lea    0x58(%rsp),%rdi
  7660f8:	call   73dc80 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime5queryNtB3_7Context3newNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEBX_>
  7660fd:	mov    0x90(%rsp),%r13
  766105:	test   %r13,%r13
  766108:	je     7661d2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit+0x122>
  76610e:	movabs $0x100000001b3,%rbp
  766118:	mov    0x88(%rsp),%rbx
  766120:	add    $0x3d,%rbx
  766124:	xor    %eax,%eax
  766126:	lea    0x58(%rsp),%r14
  76612b:	xor    %r12d,%r12d
  76612e:	jmp    766173 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit+0xc3>
  766130:	xor    $0x1,%eax
  766133:	imul   %rbp,%rax
  766137:	and    $0x1,%dl
  76613a:	movzbl %dl,%r15d
  76613e:	xor    %rax,%r15
  766141:	imul   %rbp,%r15
  766145:	mov    %r14,%rdi
  766148:	mov    %r12,%rsi
  76614b:	movss  0x8(%rsp),%xmm0
  766151:	movss  0xc(%rsp),%xmm1
  766157:	call   *0x353153(%rip)        # ab92b0 <_DYNAMIC+0x580>
  76615d:	movzbl %al,%eax
  766160:	xor    %r15,%rax
  766163:	imul   %rbp,%rax
  766167:	inc    %r12
  76616a:	add    $0x40,%rbx
  76616e:	cmp    %r12,%r13
  766171:	je     7661d4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit+0x124>
  766173:	cmpb   $0x4,(%rbx)
  766176:	jne    766167 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit+0xb7>
  766178:	lea    0x10(%rsp),%rdi
  76617d:	mov    %r14,%rsi
  766180:	mov    %r12,%rdx
  766183:	call   *0x352fef(%rip)        # ab9178 <_DYNAMIC+0x448>
  766189:	cmpq   $0x0,0x10(%rsp)
  76618f:	je     7661e6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit+0x136>
  766191:	movups 0x10(%rsp),%xmm0
  766196:	movups 0x20(%rsp),%xmm1
  76619b:	movaps %xmm1,0x40(%rsp)
  7661a0:	movaps %xmm0,0x30(%rsp)
  7661a5:	lea    0x30(%rsp),%rdi
  7661aa:	movss  0x8(%rsp),%xmm0
  7661b0:	movss  0xc(%rsp),%xmm1
  7661b6:	call   *0x35305c(%rip)        # ab9218 <_DYNAMIC+0x4e8>
  7661bc:	cmp    $0x2,%dl
  7661bf:	jne    766130 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit+0x80>
  7661c5:	lea    0x332cdc(%rip),%rdi        # a98ea8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x6d0>
  7661cc:	call   *0x352e46(%rip)        # ab9018 <_DYNAMIC+0x2e8>
  7661d2:	xor    %eax,%eax
  7661d4:	add    $0xd8,%rsp
  7661db:	pop    %rbx
  7661dc:	pop    %r12
  7661de:	pop    %r13
  7661e0:	pop    %r14
  7661e2:	pop    %r15
  7661e4:	pop    %rbp
  7661e5:	ret
  7661e6:	lea    0x332ca3(%rip),%rdi        # a98e90 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x6b8>
  7661ed:	call   *0x352e25(%rip)        # ab9018 <_DYNAMIC+0x2e8>
  7661f3:	mov    $0xd,%eax
  7661f8:	jmp    766206 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit+0x156>
  7661fa:	mov    $0xe,%eax
  7661ff:	jmp    766206 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit+0x156>
  766201:	mov    $0x12,%eax
  766206:	mov    %rax,0x58(%rsp)
  76620b:	movq   $0x0,0x60(%rsp)
  766214:	lea    -0x6965f1(%rip),%rdi        # cfc2a <GCC_except_table0+0xd88a>
  76621b:	lea    0x333846(%rip),%rcx        # a99a68 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1290>
  766222:	lea    0x3337f7(%rip),%r8        # a99a20 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1248>
  766229:	lea    0x58(%rsp),%rdx
  76622e:	mov    $0x2b,%esi
  766233:	call   *0x352e07(%rip)        # ab9040 <_DYNAMIC+0x310>
  766239:	ud2
  76623b:	mov    %rax,%rbx
  76623e:	lea    0x58(%rsp),%rdi
  766243:	call   74d580 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  766248:	mov    %rbx,%rdi
  76624b:	call   a97420 <_Unwind_Resume@plt>

canonical_text_public_control::query_hit bytes=181 frame=88

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000766250 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9query_hit>:
  766250:	push   %r15
  766252:	push   %r14
  766254:	push   %rbx
  766255:	sub    $0x40,%rsp
  766259:	mov    %rdi,%r14
  76625c:	movss  %xmm0,(%rsp)
  766261:	movss  %xmm1,0x4(%rsp)
  766267:	call   *0x35304b(%rip)        # ab92b8 <_DYNAMIC+0x588>
  76626d:	cmp    $0x2,%dl
  766270:	je     7662f8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9query_hit+0xa8>
  766276:	movabs $0x100000001b3,%r15
  766280:	xor    $0x1,%eax
  766283:	imul   %r15,%rax
  766287:	and    $0x1,%dl
  76628a:	movzbl %dl,%ebx
  76628d:	xor    %rax,%rbx
  766290:	imul   %r15,%rbx
  766294:	lea    0x8(%rsp),%rdi
  766299:	mov    %r14,%rsi
  76629c:	movss  (%rsp),%xmm0
  7662a1:	movss  0x4(%rsp),%xmm1
  7662a7:	call   *0x353013(%rip)        # ab92c0 <_DYNAMIC+0x590>
  7662ad:	cmpb   $0x2,0xc(%rsp)
  7662b2:	je     7662eb <_RNvCs9C2G9YFESsD_29canonical_text_public_control9query_hit+0x9b>
  7662b4:	mov    0x8(%rsp),%eax
  7662b8:	mov    0x18(%rsp),%ecx
  7662bc:	mov    0x1c(%rsp),%edx
  7662c0:	mov    0x20(%rsp),%esi
  7662c4:	mov    0x24(%rsp),%edi
  7662c8:	xor    %rax,%rbx
  7662cb:	imul   %r15,%rbx
  7662cf:	xor    %rcx,%rbx
  7662d2:	imul   %r15,%rbx
  7662d6:	xor    %rdx,%rbx
  7662d9:	imul   %r15,%rbx
  7662dd:	xor    %rsi,%rbx
  7662e0:	imul   %r15,%rbx
  7662e4:	xor    %rdi,%rbx
  7662e7:	imul   %r15,%rbx
  7662eb:	mov    %rbx,%rax
  7662ee:	add    $0x40,%rsp
  7662f2:	pop    %rbx
  7662f3:	pop    %r14
  7662f5:	pop    %r15
  7662f7:	ret
  7662f8:	lea    0x333739(%rip),%rdi        # a99a38 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1260>
  7662ff:	call   *0x352d13(%rip)        # ab9018 <_DYNAMIC+0x2e8>

<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::interaction_layout bytes=1226 frame=248

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000076b210 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_>:
  76b210:	push   %rbp
  76b211:	push   %r15
  76b213:	push   %r14
  76b215:	push   %r13
  76b217:	push   %r12
  76b219:	push   %rbx
  76b21a:	sub    $0xc8,%rsp
  76b221:	mov    %rdx,%r14
  76b224:	mov    %rsi,%r15
  76b227:	mov    0x2e0(%rsi),%rsi
  76b22e:	cmp    %rsi,%rdx
  76b231:	jae    76b64b <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x43b>
  76b237:	mov    0x2d8(%r15),%rax
  76b23e:	lea    (%r14,%r14,4),%rcx
  76b242:	mov    0x20(%rax,%rcx,8),%r13d
  76b247:	mov    %r13d,%eax
  76b24a:	and    $0xf,%eax
  76b24d:	cmp    $0x9,%eax
  76b250:	ja     76b632 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x422>
  76b256:	mov    %rdi,%rbx
  76b259:	cmp    $0x6,%eax
  76b25c:	je     76b5cf <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x3bf>
  76b262:	shr    $0x4,%r13d
  76b266:	lea    0x2f0(%r15),%rax
  76b26d:	mov    %rax,0x10(%rsp)
  76b272:	lea    0x2f8(%r15),%rbp
  76b279:	sub    $0x1,%r13d
  76b27d:	jae    76b3a8 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x198>
  76b283:	mov    $0xffffffff,%r13d
  76b289:	mov    $0x1,%r12b
  76b28c:	mov    0x5a8(%r15),%rsi
  76b293:	cmp    %rsi,%r14
  76b296:	jae    76b408 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x1f8>
  76b29c:	mov    0x5a0(%r15),%rax
  76b2a3:	lea    0x300(%r15),%rsi
  76b2aa:	mov    %r14,%rcx
  76b2ad:	shl    $0x4,%rcx
  76b2b1:	movups (%rax,%rcx,1),%xmm0
  76b2b5:	movaps %xmm0,0x90(%rsp)
  76b2bd:	lea    0x30(%rsp),%rdi
  76b2c2:	lea    0x90(%rsp),%rdx
  76b2ca:	call   *0x34de40(%rip)        # ab9110 <_DYNAMIC+0x3e0>
  76b2d0:	cmpb   $0x0,0x30(%rsp)
  76b2d5:	je     76b2eb <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0xdb>
  76b2d7:	movzbl 0x31(%rsp),%eax
  76b2dc:	movq   $0x22,(%rbx)
  76b2e3:	mov    %al,0x8(%rbx)
  76b2e6:	jmp    76b5bd <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x3ad>
  76b2eb:	mov    0x6e8(%r15),%rax
  76b2f2:	test   %rax,%rax
  76b2f5:	je     76b5e7 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x3d7>
  76b2fb:	mov    0x30(%rax),%rax
  76b2ff:	test   %rax,%rax
  76b302:	je     76b5e7 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x3d7>
  76b308:	movss  0x7c(%rsp),%xmm1
  76b30e:	subss  0x54(%rsp),%xmm1
  76b314:	subss  0x58(%rsp),%xmm1
  76b31a:	subss  0x44(%rsp),%xmm1
  76b320:	subss  0x48(%rsp),%xmm1
  76b326:	subss  0x84(%rsp),%xmm1
  76b32f:	lock incq (%rax)
  76b333:	jle    76b6a2 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x492>
  76b339:	mov    %rax,0x8(%rsp)
  76b33e:	test   %r12b,%r12b
  76b341:	jne    76b60d <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x3fd>
  76b347:	mov    0x0(%rbp),%rsi
  76b34b:	mov    %r13d,%r12d
  76b34e:	cmp    %r12,%rsi
  76b351:	jbe    76b66b <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x45b>
  76b357:	mov    0x10(%rsp),%rax
  76b35c:	mov    (%rax),%rsi
  76b35f:	lea    (%r12,%r12,4),%r13
  76b363:	shl    $0x4,%r13
  76b367:	cmpq   $0xfffffffffffffffe,(%rsi,%r13,1)
  76b36c:	je     76b616 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x406>
  76b372:	lea    0x8(%rsp),%rax
  76b377:	mov    %rax,0x20(%rsp)
  76b37c:	movq   $0x0,0x28(%rsp)
  76b385:	mov    0x200(%r15),%rax
  76b38c:	lea    -0x6a733b(%rip),%rcx        # c4058 <GCC_except_table0+0x1cb8>
  76b393:	movslq (%rcx,%rax,4),%rax
  76b397:	add    %rcx,%rax
  76b39a:	jmp    *%rax
  76b39c:	lea    -0x6a6f87(%rip),%rax        # c441c <GCC_except_table0+0x207c>
  76b3a3:	jmp    76b498 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x288>
  76b3a8:	mov    0x2f8(%r15),%rsi
  76b3af:	mov    %r13d,%r12d
  76b3b2:	cmp    %r12,%rsi
  76b3b5:	jbe    76b65b <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x44b>
  76b3bb:	mov    0x2f0(%r15),%rax
  76b3c2:	lea    (%r12,%r12,4),%rcx
  76b3c6:	shl    $0x4,%rcx
  76b3ca:	mov    (%rax,%rcx,1),%rdx
  76b3ce:	cmp    $0xffffffffffffffff,%rdx
  76b3d2:	je     76b3f5 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x1e5>
  76b3d4:	cmp    $0xfffffffffffffffe,%rdx
  76b3d8:	je     76b600 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x3f0>
  76b3de:	add    %rcx,%rax
  76b3e1:	mov    0x20(%rax),%rax
  76b3e5:	test   %rax,%rax
  76b3e8:	je     76b3f5 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x1e5>
  76b3ea:	cmpq   $0x0,0x50(%rax)
  76b3ef:	jne    76b529 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x319>
  76b3f5:	xor    %r12d,%r12d
  76b3f8:	mov    0x5a8(%r15),%rsi
  76b3ff:	cmp    %rsi,%r14
  76b402:	jb     76b29c <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x8c>
  76b408:	lea    0x32e9a1(%rip),%rdx        # a99db0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x15d8>
  76b40f:	mov    %r14,%rdi
  76b412:	call   *0x34db88(%rip)        # ab8fa0 <_DYNAMIC+0x270>
  76b418:	mov    0x220(%r15),%rax
  76b41f:	cmp    %rax,%r14
  76b422:	jae    76b67d <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x46d>
  76b428:	mov    0x210(%r15),%rax
  76b42f:	mov    0x218(%r15),%rcx
  76b436:	movzbl (%rcx,%r14,1),%r14d
  76b43b:	cmp    %r14,%rax
  76b43e:	jbe    76b68f <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x47f>
  76b444:	imul   $0x58,%r14,%rax
  76b448:	add    0x208(%r15),%rax
  76b44f:	jmp    76b498 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x288>
  76b451:	mov    0x208(%r15),%rax
  76b458:	lea    0x30(%rsp),%rdi
  76b45d:	mov    %rsi,%r15
  76b460:	mov    %rax,%rsi
  76b463:	mov    %r14,%rdx
  76b466:	movss  %xmm1,0x1c(%rsp)
  76b46c:	call   *0x34dcae(%rip)        # ab9120 <_DYNAMIC+0x3f0>
  76b472:	movss  0x1c(%rsp),%xmm1
  76b478:	mov    %r15,%rsi
  76b47b:	jmp    76b4d0 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x2c0>
  76b47d:	mov    0x218(%r15),%rax
  76b484:	cmp    %rax,%r14
  76b487:	jae    76b686 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x476>
  76b48d:	imul   $0x58,%r14,%rax
  76b491:	add    0x210(%r15),%rax
  76b498:	mov    0x50(%rax),%rcx
  76b49c:	mov    %rcx,0x80(%rsp)
  76b4a4:	movups 0x40(%rax),%xmm0
  76b4a8:	movaps %xmm0,0x70(%rsp)
  76b4ad:	movups (%rax),%xmm0
  76b4b0:	movups 0x10(%rax),%xmm4
  76b4b4:	movups 0x20(%rax),%xmm2
  76b4b8:	movups 0x30(%rax),%xmm3
  76b4bc:	movaps %xmm3,0x60(%rsp)
  76b4c1:	movaps %xmm2,0x50(%rsp)
  76b4c6:	movaps %xmm4,0x40(%rsp)
  76b4cb:	movaps %xmm0,0x30(%rsp)
  76b4d0:	add    %r13,%rsi
  76b4d3:	movss  0x48(%rsp),%xmm0
  76b4d9:	lea    0x90(%rsp),%rdi
  76b4e1:	lea    0x20(%rsp),%rdx
  76b4e6:	mov    $0x1,%ecx
  76b4eb:	mov    $0x1,%r8d
  76b4f1:	call   *0x34dcb9(%rip)        # ab91b0 <_DYNAMIC+0x480>
  76b4f7:	mov    0x90(%rsp),%rax
  76b4ff:	cmp    $0xfffffffffffffffe,%rax
  76b503:	jne    76b56a <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x35a>
  76b505:	mov    0x28(%rsp),%rdi
  76b50a:	call   74caf0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text10TextShaperECs9C2G9YFESsD_29canonical_text_public_control>
  76b50f:	mov    0x8(%rsp),%rax
  76b514:	lock decq (%rax)
  76b518:	jne    76b525 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x315>
  76b51a:	lea    0x8(%rsp),%rdi
  76b51f:	call   *0x34db3b(%rip)        # ab9060 <_DYNAMIC+0x330>
  76b525:	mov    0x0(%rbp),%rsi
  76b529:	cmp    %r12,%rsi
  76b52c:	jbe    76b65b <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x44b>
  76b532:	mov    0x10(%rsp),%rax
  76b537:	mov    (%rax),%rax
  76b53a:	lea    (%r12,%r12,4),%rcx
  76b53e:	shl    $0x4,%rcx
  76b542:	mov    (%rax,%rcx,1),%rdx
  76b546:	cmp    $0xfffffffffffffffe,%rdx
  76b54a:	je     76b600 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x3f0>
  76b550:	cmp    $0xffffffffffffffff,%rdx
  76b554:	je     76b625 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x415>
  76b55a:	add    %rcx,%rax
  76b55d:	mov    %rax,0x8(%rbx)
  76b561:	movq   $0xfffffffffffffffe,(%rbx)
  76b568:	jmp    76b5bd <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x3ad>
  76b56a:	mov    0x98(%rsp),%rcx
  76b572:	mov    0xc0(%rsp),%rdx
  76b57a:	mov    %rdx,0x30(%rbx)
  76b57e:	movups 0xb0(%rsp),%xmm0
  76b586:	movups %xmm0,0x20(%rbx)
  76b58a:	movups 0xa0(%rsp),%xmm0
  76b592:	movups %xmm0,0x10(%rbx)
  76b596:	mov    %rax,(%rbx)
  76b599:	mov    %rcx,0x8(%rbx)
  76b59d:	mov    0x28(%rsp),%rdi
  76b5a2:	call   74caf0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text10TextShaperECs9C2G9YFESsD_29canonical_text_public_control>
  76b5a7:	mov    0x8(%rsp),%rax
  76b5ac:	lock decq (%rax)
  76b5b0:	jne    76b5bd <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x3ad>
  76b5b2:	lea    0x8(%rsp),%rdi
  76b5b7:	call   *0x34daa3(%rip)        # ab9060 <_DYNAMIC+0x330>
  76b5bd:	add    $0xc8,%rsp
  76b5c4:	pop    %rbx
  76b5c5:	pop    %r12
  76b5c7:	pop    %r13
  76b5c9:	pop    %r14
  76b5cb:	pop    %r15
  76b5cd:	pop    %rbp
  76b5ce:	ret
  76b5cf:	lea    0x2f0(%r15),%rax
  76b5d6:	mov    %rax,0x10(%rsp)
  76b5db:	lea    0x2f8(%r15),%rbp
  76b5e2:	jmp    76b283 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x73>
  76b5e7:	lea    -0x698f8a(%rip),%rdi        # d2664 <GCC_except_table0+0x102c4>
  76b5ee:	lea    0x32e7d3(%rip),%rdx        # a99dc8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x15f0>
  76b5f5:	mov    $0x2c,%esi
  76b5fa:	call   *0x34da48(%rip)        # ab9048 <_DYNAMIC+0x318>
  76b600:	lea    0x32da39(%rip),%rdi        # a99040 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x868>
  76b607:	call   *0x34da0b(%rip)        # ab9018 <_DYNAMIC+0x2e8>
  76b60d:	lea    0x32e7cc(%rip),%rdi        # a99de0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1608>
  76b614:	jmp    76b61d <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x40d>
  76b616:	lea    0x32da53(%rip),%rdi        # a99070 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x898>
  76b61d:	call   *0x34d9f5(%rip)        # ab9018 <_DYNAMIC+0x2e8>
  76b623:	jmp    76b6a2 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x492>
  76b625:	lea    0x32e7cc(%rip),%rdi        # a99df8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1620>
  76b62c:	call   *0x34d9e6(%rip)        # ab9018 <_DYNAMIC+0x2e8>
  76b632:	lea    -0x698d29(%rip),%rdi        # d2910 <GCC_except_table0+0x10570>
  76b639:	lea    0x32eca0(%rip),%rdx        # a9a2e0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1b08>
  76b640:	mov    $0x83,%esi
  76b645:	call   *0x34d95d(%rip)        # ab8fa8 <_DYNAMIC+0x278>
  76b64b:	lea    0x32e746(%rip),%rdx        # a99d98 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x15c0>
  76b652:	mov    %r14,%rdi
  76b655:	call   *0x34d945(%rip)        # ab8fa0 <_DYNAMIC+0x270>
  76b65b:	lea    0x32d9c6(%rip),%rdx        # a99028 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x850>
  76b662:	mov    %r12,%rdi
  76b665:	call   *0x34d935(%rip)        # ab8fa0 <_DYNAMIC+0x270>
  76b66b:	lea    0x32d9e6(%rip),%rdx        # a99058 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x880>
  76b672:	mov    %r12,%rdi
  76b675:	call   *0x34d925(%rip)        # ab8fa0 <_DYNAMIC+0x270>
  76b67b:	jmp    76b6a2 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x492>
  76b67d:	lea    0x32e5a4(%rip),%rdx        # a99c28 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1450>
  76b684:	jmp    76b696 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x486>
  76b686:	lea    0x32e583(%rip),%rdx        # a99c10 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1438>
  76b68d:	jmp    76b696 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x486>
  76b68f:	lea    0x32e5aa(%rip),%rdx        # a99c40 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1468>
  76b696:	mov    %r14,%rdi
  76b699:	mov    %rax,%rsi
  76b69c:	call   *0x34d8fe(%rip)        # ab8fa0 <_DYNAMIC+0x270>
  76b6a2:	ud2
  76b6a4:	mov    %rax,%rbx
  76b6a7:	mov    0x28(%rsp),%rdi
  76b6ac:	call   74caf0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text10TextShaperECs9C2G9YFESsD_29canonical_text_public_control>
  76b6b1:	jmp    76b6b6 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x4a6>
  76b6b3:	mov    %rax,%rbx
  76b6b6:	mov    0x8(%rsp),%rax
  76b6bb:	lock decq (%rax)
  76b6bf:	jne    76b6cc <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x4bc>
  76b6c1:	lea    0x8(%rsp),%rdi
  76b6c6:	call   *0x34d994(%rip)        # ab9060 <_DYNAMIC+0x330>
  76b6cc:	mov    %rbx,%rdi
  76b6cf:	call   a97420 <_Unwind_Resume@plt>
  76b6d4:	call   *0x34d8be(%rip)        # ab8f98 <_DYNAMIC+0x268>

<gpui::runtime::Win<canonical_text_public_control::Editor>>::pointer_event bytes=3204 frame=296

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000076cda0 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_>:
  76cda0:	push   %rbp
  76cda1:	push   %r15
  76cda3:	push   %r14
  76cda5:	push   %r13
  76cda7:	push   %r12
  76cda9:	push   %rbx
  76cdaa:	sub    $0xf8,%rsp
  76cdb1:	mov    %rdx,%r14
  76cdb4:	mov    %rdi,%rbx
  76cdb7:	mov    (%rcx),%ebp
  76cdb9:	test   %ebp,%ebp
  76cdbb:	je     76cdf0 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x50>
  76cdbd:	mov    0x8(%r14),%r12
  76cdc1:	mov    0x10(%r14),%r13
  76cdc5:	mov    0x18(%r14),%rax
  76cdc9:	movq   $0x0,0x8(%r14)
  76cdd1:	lea    -0x1(%rbp),%edx
  76cdd4:	lea    -0x6a8d73(%rip),%rdi        # c4068 <GCC_except_table0+0x1cc8>
  76cddb:	movslq (%rdi,%rdx,4),%rdx
  76cddf:	add    %rdi,%rdx
  76cde2:	jmp    *%rdx
  76cde4:	movl   $0xffffffff,(%r14)
  76cdeb:	jmp    76cfb1 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x211>
  76cdf0:	movd   0x4(%rcx),%xmm1
  76cdf5:	movd   0x8(%rcx),%xmm0
  76cdfa:	movd   %xmm1,%eax
  76cdfe:	movd   %xmm0,%ecx
  76ce02:	mov    %eax,%edx
  76ce04:	and    $0x7fffffff,%edx
  76ce0a:	cmp    $0x7f800000,%edx
  76ce10:	setge  %dl
  76ce13:	and    $0x7fffffff,%ecx
  76ce19:	cmp    $0x7f800000,%ecx
  76ce1f:	setge  %cl
  76ce22:	or     %dl,%cl
  76ce24:	je     76ce3d <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x9d>
  76ce26:	movl   $0xffffffff,(%r14)
  76ce2d:	movq   $0x0,0x8(%r14)
  76ce35:	xor    %r12d,%r12d
  76ce38:	jmp    76cfb1 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x211>
  76ce3d:	inc    %eax
  76ce3f:	je     76d9a9 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xc09>
  76ce45:	mov    %eax,(%r14)
  76ce48:	movd   %xmm0,0x4(%r14)
  76ce4e:	xor    %r12d,%r12d
  76ce51:	jmp    76cfb1 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x211>
  76ce56:	mov    (%r14),%r15d
  76ce59:	cmp    $0xffffffff,%r15d
  76ce5d:	je     76cfb1 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x211>
  76ce63:	mov    %rsi,%r13
  76ce66:	movups 0x8(%rcx),%xmm0
  76ce6a:	movss  0x4(%r14),%xmm1
  76ce70:	movss  %xmm1,0x58(%rsp)
  76ce76:	movaps %xmm0,%xmm1
  76ce79:	unpckhpd %xmm0,%xmm1
  76ce7d:	lea    0x10(%rsp),%rdi
  76ce82:	movaps %xmm0,0x60(%rsp)
  76ce87:	call   *0x34c52b(%rip)        # ab93b8 <_DYNAMIC+0x688>
  76ce8d:	cmpl   $0xfffffffe,0x10(%rsp)
  76ce92:	jne    76d20e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x46e>
  76ce98:	mov    0x0(%r13),%r14
  76ce9c:	test   %r14,%r14
  76ce9f:	je     76cfe3 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x243>
  76cea5:	cmpb   $0x1,0x76e(%r14)
  76cead:	je     76cfd7 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x237>
  76ceb3:	cmpb   $0x1,0x76a(%r14)
  76cebb:	jne    76d39e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76cec1:	cmpb   $0x0,0x76b(%r14)
  76cec9:	jne    76d39e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76cecf:	cmpb   $0x0,0x76c(%r14)
  76ced7:	je     76d39e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76cedd:	cmpq   $0xffffffffffffffff,0x5c8(%r14)
  76cee5:	jne    76d39e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76ceeb:	mov    0x6a0(%r14),%rax
  76cef2:	cmp    0x6a8(%r14),%rax
  76cef9:	jne    76d39e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76ceff:	mov    0x6c0(%r14),%rax
  76cf06:	cmp    %rax,0x6c8(%r14)
  76cf0d:	jne    76d39e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76cf13:	movss  0x760(%r14),%xmm0
  76cf1c:	ucomiss 0x764(%r14),%xmm0
  76cf24:	jne    76d39e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76cf2a:	jp     76d39e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76cf30:	mov    %eax,%ecx
  76cf32:	cvtsi2ss %rcx,%xmm2
  76cf37:	dec    %r15d
  76cf3a:	shr    $0x20,%rax
  76cf3e:	mov    %eax,%eax
  76cf40:	xorps  %xmm1,%xmm1
  76cf43:	cvtsi2ss %rax,%xmm1
  76cf48:	movd   %r15d,%xmm0
  76cf4d:	movq   $0x0,0x10(%rsp)
  76cf56:	movss  %xmm2,0x18(%rsp)
  76cf5c:	movss  %xmm1,0x1c(%rsp)
  76cf62:	lea    0x10(%rsp),%rdi
  76cf67:	movd   %xmm0,0x54(%rsp)
  76cf6d:	movss  0x58(%rsp),%xmm1
  76cf73:	call   *0x34c447(%rip)        # ab93c0 <_DYNAMIC+0x690>
  76cf79:	test   %al,%al
  76cf7b:	je     76d99d <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xbfd>
  76cf81:	mov    0x650(%r14),%rax
  76cf88:	test   %rax,%rax
  76cf8b:	je     76d7d3 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xa33>
  76cf91:	mov    0x100(%rax),%rsi
  76cf98:	test   %rsi,%rsi
  76cf9b:	je     76d7d3 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xa33>
  76cfa1:	lea    0x70(%rsp),%rdi
  76cfa6:	call   *0x34c02c(%rip)        # ab8fd8 <_DYNAMIC+0x2a8>
  76cfac:	jmp    76d7e6 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xa46>
  76cfb1:	mov    (%rsi),%r15
  76cfb4:	test   %r15,%r15
  76cfb7:	je     76cfe3 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x243>
  76cfb9:	add    $0x8,%rsi
  76cfbd:	mov    %r15,0xb0(%rsp)
  76cfc5:	mov    %rsi,0xb8(%rsp)
  76cfcd:	cmpb   $0x1,0x76e(%r15)
  76cfd5:	jne    76cff7 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x257>
  76cfd7:	movq   $0xe,(%rbx)
  76cfde:	jmp    76d3a5 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76cfe3:	movq   $0xd,(%rbx)
  76cfea:	movq   $0x0,0x8(%rbx)
  76cff2:	jmp    76d3a5 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76cff7:	movq   $0x0,0x758(%r15)
  76d002:	cmp    $0x3,%ebp
  76d005:	je     76d1d8 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x438>
  76d00b:	cmp    $0x2,%ebp
  76d00e:	je     76d124 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x384>
  76d014:	test   %ebp,%ebp
  76d016:	jne    76d251 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4b1>
  76d01c:	mov    0x650(%r15),%rax
  76d023:	test   %rax,%rax
  76d026:	je     76d03e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x29e>
  76d028:	mov    0xd8(%rax),%rax
  76d02f:	test   %rax,%rax
  76d032:	je     76d03e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x29e>
  76d034:	cmpb   $0x0,0x12(%rax)
  76d038:	jne    76d251 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4b1>
  76d03e:	mov    0x8(%r14),%r12
  76d042:	test   %r12,%r12
  76d045:	je     76d251 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4b1>
  76d04b:	cmp    0x5f0(%r15),%r12
  76d052:	jne    76d236 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x496>
  76d058:	mov    0x10(%r14),%r13
  76d05c:	lea    0x70(%rsp),%rdi
  76d061:	mov    %r15,%rsi
  76d064:	mov    %r13,%rdx
  76d067:	call   78c610 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE16resolve_identityBO_>
  76d06c:	cmpq   $0xfffffffffffffffe,0x70(%rsp)
  76d072:	jne    76d23f <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x49f>
  76d078:	mov    0x78(%rsp),%rdi
  76d07d:	mov    0x2e0(%r15),%rsi
  76d084:	cmp    %rsi,%rdi
  76d087:	jae    76d9c2 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xc22>
  76d08d:	mov    0x2d8(%r15),%rax
  76d094:	lea    (%rdi,%rdi,4),%rcx
  76d098:	mov    0x20(%rax,%rcx,8),%edi
  76d09c:	call   7759f0 <_RNvMsh_NtCslbxve4rcJus_4gpui7runtimeNtB5_4Node4kind>
  76d0a1:	cmp    $0x4,%al
  76d0a3:	jne    76d3b7 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x617>
  76d0a9:	mov    (%r14),%eax
  76d0ac:	cmp    $0xffffffff,%eax
  76d0af:	je     76d9d1 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xc31>
  76d0b5:	movd   0x4(%r14),%xmm1
  76d0bb:	dec    %eax
  76d0bd:	movd   %eax,%xmm0
  76d0c1:	lea    0x10(%rsp),%rdi
  76d0c6:	mov    %r15,%rsi
  76d0c9:	mov    %r12,%rdx
  76d0cc:	mov    %r13,%rcx
  76d0cf:	mov    $0x1,%r8d
  76d0d5:	call   76fc20 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE14select_pointerB12_>
  76d0da:	mov    0x10(%rsp),%rax
  76d0df:	cmp    $0xfffffffffffffffe,%rax
  76d0e3:	je     76d0f2 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x352>
  76d0e5:	cmp    $0x11,%eax
  76d0e8:	jne    76d0f2 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x352>
  76d0ea:	movq   $0x0,0x8(%r14)
  76d0f2:	mov    0x40(%rsp),%rax
  76d0f7:	mov    %rax,0x30(%rbx)
  76d0fb:	movups 0x10(%rsp),%xmm0
  76d100:	movups 0x20(%rsp),%xmm1
  76d105:	movups 0x30(%rsp),%xmm2
  76d10a:	movups %xmm2,0x20(%rbx)
  76d10e:	movups %xmm1,0x10(%rbx)
  76d112:	movups %xmm0,(%rbx)
  76d115:	lea    0x70(%rsp),%rdi
  76d11a:	call   7461f0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultNtNtCslbxve4rcJus_4gpui7runtime6CommitNtBZ_5ErrorEECs9C2G9YFESsD_29canonical_text_public_control>
  76d11f:	jmp    76d3a5 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76d124:	test   %r12,%r12
  76d127:	sete   %cl
  76d12a:	cmpb   $0x1,0x76a(%r15)
  76d132:	jne    76d39e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d138:	cmpb   $0x0,0x76b(%r15)
  76d140:	jne    76d39e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d146:	cmpb   $0x0,0x76c(%r15)
  76d14e:	je     76d39e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d154:	cmpq   $0xffffffffffffffff,0x5c8(%r15)
  76d15c:	jne    76d39e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d162:	mov    0x6a0(%r15),%rax
  76d169:	cmp    0x6a8(%r15),%rax
  76d170:	jne    76d39e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d176:	mov    0x6c8(%r15),%rax
  76d17d:	cmp    0x6c0(%r15),%rax
  76d184:	jne    76d39e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d18a:	movss  0x760(%r15),%xmm0
  76d193:	ucomiss 0x764(%r15),%xmm0
  76d19b:	jne    76d39e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d1a1:	jp     76d39e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d1a7:	mov    (%r14),%eax
  76d1aa:	cmp    $0xffffffff,%eax
  76d1ad:	mov    %rax,0x58(%rsp)
  76d1b2:	mov    %ecx,0x54(%rsp)
  76d1b6:	je     76d3c6 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x626>
  76d1bc:	movss  0x4(%r14),%xmm0
  76d1c2:	dec    %eax
  76d1c4:	mov    %eax,0x14(%rsp)
  76d1c8:	movss  %xmm0,0x18(%rsp)
  76d1ce:	mov    $0x1,%eax
  76d1d3:	jmp    76d3c8 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x628>
  76d1d8:	test   %r12,%r12
  76d1db:	je     76d251 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4b1>
  76d1dd:	mov    (%r14),%ecx
  76d1e0:	cmp    $0xffffffff,%ecx
  76d1e3:	mov    %rcx,0x58(%rsp)
  76d1e8:	je     76d2af <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x50f>
  76d1ee:	movss  0x4(%r14),%xmm1
  76d1f4:	dec    %ecx
  76d1f6:	mov    %ecx,0x74(%rsp)
  76d1fa:	movss  %xmm1,0x78(%rsp)
  76d200:	movd   %ecx,%xmm0
  76d204:	mov    $0x1,%ecx
  76d209:	jmp    76d2b1 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x511>
  76d20e:	mov    0x40(%rsp),%rax
  76d213:	mov    %rax,0x30(%rbx)
  76d217:	movups 0x10(%rsp),%xmm0
  76d21c:	movups 0x20(%rsp),%xmm1
  76d221:	movups 0x30(%rsp),%xmm2
  76d226:	movups %xmm2,0x20(%rbx)
  76d22a:	movups %xmm1,0x10(%rbx)
  76d22e:	movups %xmm0,(%rbx)
  76d231:	jmp    76d3a5 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76d236:	movq   $0x11,0x70(%rsp)
  76d23f:	lea    0x70(%rsp),%rdi
  76d244:	call   7461f0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultNtNtCslbxve4rcJus_4gpui7runtime6CommitNtBZ_5ErrorEECs9C2G9YFESsD_29canonical_text_public_control>
  76d249:	movq   $0x0,0x8(%r14)
  76d251:	movups 0x6a0(%r15),%xmm0
  76d259:	movzbl 0x76c(%r15),%eax
  76d261:	cmpq   $0x0,0x6d0(%r15)
  76d269:	je     76d279 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4d9>
  76d26b:	test   %al,%al
  76d26d:	je     76d27d <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4dd>
  76d26f:	cmpq   $0xffffffffffffffff,0x5c8(%r15)
  76d277:	jne    76d27d <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4dd>
  76d279:	xor    %ecx,%ecx
  76d27b:	jmp    76d289 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4e9>
  76d27d:	mov    0x6e0(%r15),%rdx
  76d284:	mov    $0x1,%ecx
  76d289:	mov    0x758(%r15),%rsi
  76d290:	mov    %rcx,0x8(%rbx)
  76d294:	mov    %rdx,0x10(%rbx)
  76d298:	movups %xmm0,0x18(%rbx)
  76d29c:	mov    %rsi,0x28(%rbx)
  76d2a0:	mov    %al,0x30(%rbx)
  76d2a3:	movq   $0xfffffffffffffffe,(%rbx)
  76d2aa:	jmp    76d3a5 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76d2af:	xor    %ecx,%ecx
  76d2b1:	mov    %ecx,0x70(%rsp)
  76d2b5:	movzbl 0x76b(%r15),%edx
  76d2bd:	xor    $0x1,%dl
  76d2c0:	and    0x76a(%r15),%dl
  76d2c7:	and    0x76c(%r15),%dl
  76d2ce:	mov    0x5c8(%r15),%rsi
  76d2d5:	cmp    $0xffffffffffffffff,%rsi
  76d2d9:	sete   %dil
  76d2dd:	and    %dl,%dil
  76d2e0:	cmp    $0x1,%dil
  76d2e4:	jne    76d362 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5c2>
  76d2e6:	mov    0x6a0(%r15),%rax
  76d2ed:	cmp    0x6a8(%r15),%rax
  76d2f4:	jne    76d39e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d2fa:	mov    0x6c8(%r15),%rax
  76d301:	cmp    0x6c0(%r15),%rax
  76d308:	jne    76d39e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d30e:	movss  0x760(%r15),%xmm2
  76d317:	ucomiss 0x764(%r15),%xmm2
  76d31f:	jne    76d39e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d321:	jp     76d39e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d323:	test   %ecx,%ecx
  76d325:	je     76d4d0 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x730>
  76d32b:	mov    0x650(%r15),%rax
  76d332:	test   %rax,%rax
  76d335:	je     76d4a8 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x708>
  76d33b:	mov    0xd8(%rax),%rax
  76d342:	test   %rax,%rax
  76d345:	je     76d4a8 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x708>
  76d34b:	cmpb   $0x0,0x12(%rax)
  76d34f:	je     76d4a8 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x708>
  76d355:	mov    %r15,%rdi
  76d358:	call   7704f0 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime9inspectorINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE14inspector_pickB10_>
  76d35d:	jmp    76d4c4 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x724>
  76d362:	cmp    $0xffffffffffffffff,%rsi
  76d366:	sete   %cl
  76d369:	movq   $0x12,0x10(%rsp)
  76d372:	xor    $0x1,%dl
  76d375:	or     %cl,%dl
  76d377:	jne    76d39e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d379:	mov    0x6c8(%r15),%rcx
  76d380:	cmp    0x6c0(%r15),%rcx
  76d387:	jne    76d39e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d389:	movss  0x760(%r15),%xmm0
  76d392:	ucomiss 0x764(%r15),%xmm0
  76d39a:	jne    76d39e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d39c:	jnp    76d3ec <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x64c>
  76d39e:	movq   $0x12,(%rbx)
  76d3a5:	add    $0xf8,%rsp
  76d3ac:	pop    %rbx
  76d3ad:	pop    %r12
  76d3af:	pop    %r13
  76d3b1:	pop    %r14
  76d3b3:	pop    %r15
  76d3b5:	pop    %rbp
  76d3b6:	ret
  76d3b7:	lea    0x70(%rsp),%rdi
  76d3bc:	call   7461f0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultNtNtCslbxve4rcJus_4gpui7runtime6CommitNtBZ_5ErrorEECs9C2G9YFESsD_29canonical_text_public_control>
  76d3c1:	jmp    76d251 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4b1>
  76d3c6:	xor    %eax,%eax
  76d3c8:	mov    %eax,0x10(%rsp)
  76d3cc:	lea    0x10(%rsp),%rsi
  76d3d1:	mov    %r15,%rdi
  76d3d4:	call   76e8b0 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11pointer_hitBW_>
  76d3d9:	mov    %rax,0x60(%rsp)
  76d3de:	mov    %rdx,0x8(%rsp)
  76d3e3:	mov    0x54(%rsp),%ecx
  76d3e7:	jmp    76d4db <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x73b>
  76d3ec:	mov    0x6a8(%r15),%rcx
  76d3f3:	cmp    $0xffffffffffffffff,%rcx
  76d3f7:	je     76d39e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d3f9:	inc    %rcx
  76d3fc:	mov    0x6a0(%r15),%rdx
  76d403:	cmp    %rdx,%rcx
  76d406:	jne    76d39e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d408:	cmp    %rdx,0x6e0(%r15)
  76d40f:	jne    76d39e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d411:	test   %rax,%rax
  76d414:	je     76d39e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d416:	cmpq   $0x0,0x6d0(%r15)
  76d41e:	je     76d39e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d424:	cmp    %rax,0x6d8(%r15)
  76d42b:	jne    76d39e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d431:	cmp    0x5f0(%r15),%r12
  76d438:	jne    76d39e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d43e:	lea    0x70(%rsp),%rsi
  76d443:	mov    %r15,%rdi
  76d446:	call   76e8b0 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11pointer_hitBW_>
  76d44b:	mov    %rax,0x60(%rsp)
  76d450:	mov    %rdx,0x8(%rsp)
  76d455:	mov    0x650(%r15),%rax
  76d45c:	test   %rax,%rax
  76d45f:	je     76d49c <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x6fc>
  76d461:	cmpq   $0x0,0xd8(%rax)
  76d469:	je     76d49c <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x6fc>
  76d46b:	cmp    %r12,0x60(%rsp)
  76d470:	jne    76d39e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d476:	cmp    %r13,0x8(%rsp)
  76d47b:	jne    76d39e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d481:	lea    0x70(%rsp),%rcx
  76d486:	mov    %r15,%rdi
  76d489:	mov    %r12,%rsi
  76d48c:	mov    %r13,%rdx
  76d48f:	call   76e9e0 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE19inspector_focus_hitBW_>
  76d494:	test   %al,%al
  76d496:	je     76d39e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76d49c:	lea    0x10(%rsp),%rdi
  76d4a1:	call   74d580 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  76d4a6:	jmp    76d4d9 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x739>
  76d4a8:	mov    %r15,%rdi
  76d4ab:	call   78c8f0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE3hitBO_>
  76d4b0:	test   $0x1,%al
  76d4b2:	je     76d4d0 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x730>
  76d4b4:	lea    0x5f0(%r15),%rdi
  76d4bb:	mov    %rdx,%rsi
  76d4be:	call   *0x34bd0c(%rip)        # ab91d0 <_DYNAMIC+0x4a0>
  76d4c4:	mov    %rax,0x60(%rsp)
  76d4c9:	mov    %rdx,0x8(%rsp)
  76d4ce:	jmp    76d4d9 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x739>
  76d4d0:	movq   $0x0,0x60(%rsp)
  76d4d9:	xor    %ecx,%ecx
  76d4db:	mov    0x650(%r15),%rax
  76d4e2:	test   %rax,%rax
  76d4e5:	je     76d4f9 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x759>
  76d4e7:	mov    0xd8(%rax),%rax
  76d4ee:	test   %rax,%rax
  76d4f1:	je     76d4f9 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x759>
  76d4f3:	movzbl 0x12(%rax),%eax
  76d4f7:	jmp    76d4fb <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x75b>
  76d4f9:	xor    %eax,%eax
  76d4fb:	cmp    $0x2,%ebp
  76d4fe:	jne    76d5ec <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x84c>
  76d504:	mov    0x628(%r15),%rdx
  76d50b:	mov    0x630(%r15),%rcx
  76d512:	mov    0x60(%rsp),%rbp
  76d517:	test   %rbp,%rbp
  76d51a:	sete   %sil
  76d51e:	or     %al,%sil
  76d521:	test   $0x1,%sil
  76d525:	je     76d634 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x894>
  76d52b:	movq   $0x0,0x628(%r15)
  76d536:	lea    0x10(%rsp),%rdi
  76d53b:	mov    %r15,%rsi
  76d53e:	call   770240 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE20publish_focus_changeB12_>
  76d543:	mov    0x10(%rsp),%rax
  76d548:	movups 0x18(%rsp),%xmm0
  76d54d:	movaps %xmm0,0x70(%rsp)
  76d552:	movups 0x28(%rsp),%xmm0
  76d557:	movaps %xmm0,0x80(%rsp)
  76d55f:	movups 0x38(%rsp),%xmm0
  76d564:	movaps %xmm0,0x90(%rsp)
  76d56c:	cmp    $0xfffffffffffffffe,%rax
  76d570:	jne    76d725 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x985>
  76d576:	movaps 0x70(%rsp),%xmm0
  76d57b:	movaps 0x80(%rsp),%xmm1
  76d583:	movaps 0x90(%rsp),%xmm2
  76d58b:	movaps %xmm2,0xe0(%rsp)
  76d593:	movaps %xmm1,0xd0(%rsp)
  76d59b:	movaps %xmm0,0xc0(%rsp)
  76d5a3:	cmpq   $0xffffffffffffffff,0x5c8(%r15)
  76d5ab:	je     76d77a <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x9da>
  76d5b1:	mov    0x6a8(%r15),%rax
  76d5b8:	cmp    $0xffffffffffffffff,%rax
  76d5bc:	je     76d77a <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x9da>
  76d5c2:	inc    %rax
  76d5c5:	cmp    0x6a0(%r15),%rax
  76d5cc:	jne    76d77a <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x9da>
  76d5d2:	cmpq   $0x0,0x6d0(%r15)
  76d5da:	je     76d77a <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x9da>
  76d5e0:	mov    0x6d8(%r15),%rax
  76d5e7:	jmp    76d77c <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x9dc>
  76d5ec:	test   %cl,%cl
  76d5ee:	mov    0x60(%rsp),%rcx
  76d5f3:	jne    76d251 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4b1>
  76d5f9:	test   %rcx,%rcx
  76d5fc:	je     76d251 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4b1>
  76d602:	cmp    %rcx,%r12
  76d605:	jne    76d251 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4b1>
  76d60b:	cmp    0x8(%rsp),%r13
  76d610:	jne    76d251 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4b1>
  76d616:	test   %al,%al
  76d618:	je     76d7b8 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xa18>
  76d61e:	mov    %rbx,%rdi
  76d621:	mov    %r15,%rsi
  76d624:	mov    %r12,%rdx
  76d627:	mov    %r13,%rcx
  76d62a:	call   773010 <_RNvMs4_NtNtCslbxve4rcJus_4gpui7runtime9inspectorINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE16inspector_selectB14_>
  76d62f:	jmp    76d3a5 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76d634:	cmp    0x5f0(%r15),%rbp
  76d63b:	jne    76d74e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x9ae>
  76d641:	mov    %rcx,%r12
  76d644:	mov    %rdx,%r13
  76d647:	lea    0x10(%rsp),%rdi
  76d64c:	mov    %r15,%rsi
  76d64f:	mov    0x8(%rsp),%rdx
  76d654:	call   78c610 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE16resolve_identityBO_>
  76d659:	mov    0x10(%rsp),%rax
  76d65e:	mov    0x18(%rsp),%rdi
  76d663:	cmp    $0xfffffffffffffffe,%rax
  76d667:	jne    76d753 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x9b3>
  76d66d:	mov    0x2e0(%r15),%rsi
  76d674:	cmp    %rsi,%rdi
  76d677:	jae    76d9e0 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xc40>
  76d67d:	mov    0x2d8(%r15),%rax
  76d684:	lea    (%rdi,%rdi,4),%rcx
  76d688:	mov    0x20(%rax,%rcx,8),%edi
  76d68c:	call   7759f0 <_RNvMsh_NtCslbxve4rcJus_4gpui7runtimeNtB5_4Node4kind>
  76d691:	cmp    $0x4,%al
  76d693:	jne    76d8ad <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xb0d>
  76d699:	mov    0x58(%rsp),%rax
  76d69e:	cmp    $0xffffffff,%eax
  76d6a1:	je     76d9ed <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xc4d>
  76d6a7:	movss  0x4(%r14),%xmm1
  76d6ad:	dec    %eax
  76d6af:	movd   %eax,%xmm0
  76d6b3:	lea    0x10(%rsp),%rdi
  76d6b8:	mov    %r15,%rsi
  76d6bb:	mov    %rbp,%rdx
  76d6be:	mov    0x8(%rsp),%r15
  76d6c3:	mov    %r15,%rcx
  76d6c6:	xor    %r8d,%r8d
  76d6c9:	call   76fc20 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE14select_pointerB12_>
  76d6ce:	mov    0x10(%rsp),%rax
  76d6d3:	movups 0x38(%rsp),%xmm0
  76d6d8:	movaps %xmm0,0x90(%rsp)
  76d6e0:	movdqu 0x28(%rsp),%xmm1
  76d6e6:	movdqa %xmm1,0x80(%rsp)
  76d6ef:	movups 0x18(%rsp),%xmm2
  76d6f4:	movaps %xmm2,0x70(%rsp)
  76d6f9:	movups %xmm0,0x28(%rbx)
  76d6fd:	movdqu %xmm1,0x18(%rbx)
  76d702:	movups %xmm2,0x8(%rbx)
  76d706:	cmp    $0xfffffffffffffffe,%rax
  76d70a:	jne    76d921 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xb81>
  76d710:	mov    %rbp,0x8(%r14)
  76d714:	mov    %r15,0x10(%r14)
  76d718:	movq   $0x0,0x18(%r14)
  76d720:	jmp    76d2a3 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x503>
  76d725:	movaps 0x70(%rsp),%xmm0
  76d72a:	movaps 0x80(%rsp),%xmm1
  76d732:	movaps 0x90(%rsp),%xmm2
  76d73a:	movups %xmm2,0x28(%rbx)
  76d73e:	movups %xmm1,0x18(%rbx)
  76d742:	movups %xmm0,0x8(%rbx)
  76d746:	mov    %rax,(%rbx)
  76d749:	jmp    76d3a5 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76d74e:	mov    $0x11,%eax
  76d753:	mov    0x40(%rsp),%rcx
  76d758:	mov    %rcx,0x30(%rbx)
  76d75c:	movups 0x20(%rsp),%xmm0
  76d761:	movups 0x30(%rsp),%xmm1
  76d766:	movups %xmm1,0x20(%rbx)
  76d76a:	movups %xmm0,0x10(%rbx)
  76d76e:	mov    %rax,(%rbx)
  76d771:	mov    %rdi,0x8(%rbx)
  76d775:	jmp    76d3a5 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76d77a:	xor    %eax,%eax
  76d77c:	mov    %rbp,0x8(%r14)
  76d780:	mov    0x8(%rsp),%rcx
  76d785:	mov    %rcx,0x10(%r14)
  76d789:	mov    %rax,0x18(%r14)
  76d78d:	movaps 0xc0(%rsp),%xmm0
  76d795:	movdqa 0xd0(%rsp),%xmm1
  76d79e:	movaps 0xe0(%rsp),%xmm2
  76d7a6:	movups %xmm2,0x28(%rbx)
  76d7aa:	movdqu %xmm1,0x18(%rbx)
  76d7af:	movups %xmm0,0x8(%rbx)
  76d7b3:	jmp    76d2a3 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x503>
  76d7b8:	lea    0xb0(%rsp),%rsi
  76d7c0:	mov    %rbx,%rdi
  76d7c3:	mov    %r12,%rdx
  76d7c6:	mov    %r13,%rcx
  76d7c9:	call   769810 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB4_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE8activateBW_>
  76d7ce:	jmp    76d3a5 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76d7d3:	movq   $0x4,0x70(%rsp)
  76d7dc:	pxor   %xmm0,%xmm0
  76d7e0:	movdqu %xmm0,0x78(%rsp)
  76d7e6:	mov    0x5c0(%r14),%rax
  76d7ed:	mov    %rax,0x8(%rsp)
  76d7f2:	test   %rax,%rax
  76d7f5:	je     76d99d <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xbfd>
  76d7fb:	mov    0x5b8(%r14),%rbp
  76d802:	mov    0x8(%rsp),%rax
  76d807:	mov    %rax,%r15
  76d80a:	shl    $0x6,%r15
  76d80e:	lea    -0x1(%rax),%r12
  76d812:	jmp    76d878 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xad8>
  76d814:	mov    0x80(%rsp),%rax
  76d81c:	mov    %rax,0x20(%rsp)
  76d821:	movups 0x70(%rsp),%xmm0
  76d826:	movaps %xmm0,0x10(%rsp)
  76d82b:	mov    0x650(%r14),%rax
  76d832:	test   %rax,%rax
  76d835:	je     76d8a9 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xb09>
  76d837:	cmpq   $0x0,(%rax)
  76d83b:	setne  %al
  76d83e:	movzbl %al,%ecx
  76d841:	mov    %rbp,%rdi
  76d844:	mov    0x8(%rsp),%rsi
  76d849:	lea    0x10(%rsp),%rdx
  76d84e:	mov    %r12,%r8
  76d851:	movd   0x54(%rsp),%xmm0
  76d857:	movss  0x58(%rsp),%xmm1
  76d85d:	call   *0x34bb65(%rip)        # ab93c8 <_DYNAMIC+0x698>
  76d863:	test   %al,%al
  76d865:	jne    76d929 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xb89>
  76d86b:	dec    %r12
  76d86e:	add    $0xffffffffffffffc0,%r15
  76d872:	je     76d99d <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xbfd>
  76d878:	cmpb   $0x0,-0x2(%rbp,%r15,1)
  76d87e:	jne    76d814 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xa74>
  76d880:	movzbl -0x3(%rbp,%r15,1),%eax
  76d886:	sub    $0x2,%al
  76d888:	movzbl %al,%eax
  76d88b:	mov    $0x8,%ecx
  76d890:	cmovb  %ecx,%eax
  76d893:	cmp    $0x7,%al
  76d895:	je     76d814 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xa74>
  76d89b:	movzbl %al,%eax
  76d89e:	cmp    $0x4,%eax
  76d8a1:	je     76d814 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xa74>
  76d8a7:	jmp    76d86b <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xacb>
  76d8a9:	xor    %eax,%eax
  76d8ab:	jmp    76d83e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xa9e>
  76d8ad:	lea    0x10(%rsp),%rdi
  76d8b2:	mov    %r15,%rsi
  76d8b5:	mov    %rbp,%rdx
  76d8b8:	mov    0x8(%rsp),%rcx
  76d8bd:	call   76ee70 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE5focusBW_>
  76d8c2:	mov    0x10(%rsp),%rax
  76d8c7:	cmp    $0xfffffffffffffffe,%rax
  76d8cb:	jne    76d8d8 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xb38>
  76d8cd:	mov    %r13,%rdx
  76d8d0:	mov    %r12,%rcx
  76d8d3:	jmp    76d536 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x796>
  76d8d8:	mov    0x38(%rsp),%rcx
  76d8dd:	movzbl 0x40(%rsp),%edx
  76d8e2:	mov    0x41(%rsp),%esi
  76d8e6:	mov    %esi,0x70(%rsp)
  76d8ea:	mov    0x44(%rsp),%esi
  76d8ee:	mov    %esi,0x73(%rsp)
  76d8f2:	movups 0x18(%rsp),%xmm0
  76d8f7:	movups 0x28(%rsp),%xmm1
  76d8fc:	mov    0x70(%rsp),%esi
  76d900:	mov    0x73(%rsp),%edi
  76d904:	mov    %edi,0x34(%rbx)
  76d907:	mov    %esi,0x31(%rbx)
  76d90a:	mov    %rax,(%rbx)
  76d90d:	movups %xmm0,0x8(%rbx)
  76d911:	movups %xmm1,0x18(%rbx)
  76d915:	mov    %rcx,0x28(%rbx)
  76d919:	mov    %dl,0x30(%rbx)
  76d91c:	jmp    76d3a5 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76d921:	mov    %rax,(%rbx)
  76d924:	jmp    76d3a5 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76d929:	movq   $0x19,0x10(%rsp)
  76d932:	lea    0x10(%rsp),%rdi
  76d937:	call   74d580 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  76d93c:	mov    %r12,0xb8(%rsp)
  76d944:	movq   $0x1,0xb0(%rsp)
  76d950:	lea    0xb0(%rsp),%rdi
  76d958:	mov    %r14,%rsi
  76d95b:	mov    %r14,%rdx
  76d95e:	call   75c820 <_RINvYINtNtNtNtCs4NRVxsYgnAr_4core4iter7sources7from_fn6FromFnNCNvMs6_NtNtCslbxve4rcJus_4gpui7runtime6scrollINtB17_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE12scroll_at_2ds0_0ENtNtNtBa_6traits8iterator8Iterator8try_folduNCINvNvB34_3any5checkjNCBZ_s1_0E0INtNtNtBc_3ops12control_flow11ControlFlowuEEB1U_>
  76d963:	test   %al,%al
  76d965:	je     76d99d <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xbfd>
  76d967:	movq   $0x1,0x18(%rsp)
  76d970:	mov    %r12,0x20(%rsp)
  76d975:	movaps 0x60(%rsp),%xmm0
  76d97a:	movups %xmm0,0x28(%rsp)
  76d97f:	movq   $0x3,0x10(%rsp)
  76d988:	lea    0x10(%rsp),%rdx
  76d98d:	mov    %rbx,%rdi
  76d990:	mov    %r13,%rsi
  76d993:	call   774930 <_RNvMs6_NtNtCslbxve4rcJus_4gpui7runtime6scrollINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE17apply_scroll_planBT_>
  76d998:	jmp    76d3a5 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76d99d:	movq   $0x19,(%rbx)
  76d9a4:	jmp    76d3a5 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76d9a9:	lea    -0x69b237(%rip),%rdi        # d2779 <GCC_except_table0+0x103d9>
  76d9b0:	lea    0x32c519(%rip),%rdx        # a99ed0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x16f8>
  76d9b7:	mov    $0x22,%esi
  76d9bc:	call   *0x34b686(%rip)        # ab9048 <_DYNAMIC+0x318>
  76d9c2:	lea    0x32c51f(%rip),%rdx        # a99ee8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1710>
  76d9c9:	call   *0x34b5d1(%rip)        # ab8fa0 <_DYNAMIC+0x270>
  76d9cf:	jmp    76d9de <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xc3e>
  76d9d1:	lea    0x32c528(%rip),%rdi        # a99f00 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1728>
  76d9d8:	call   *0x34b63a(%rip)        # ab9018 <_DYNAMIC+0x2e8>
  76d9de:	ud2
  76d9e0:	lea    0x32c531(%rip),%rdx        # a99f18 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1740>
  76d9e7:	call   *0x34b5b3(%rip)        # ab8fa0 <_DYNAMIC+0x270>
  76d9ed:	lea    0x32c53c(%rip),%rdi        # a99f30 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1758>
  76d9f4:	call   *0x34b61e(%rip)        # ab9018 <_DYNAMIC+0x2e8>
  76d9fa:	mov    %rax,%rbx
  76d9fd:	lea    0x10(%rsp),%rdi
  76da02:	call   74d580 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  76da07:	mov    %rbx,%rdi
  76da0a:	call   a97420 <_Unwind_Resume@plt>
  76da0f:	mov    %rax,%rbx
  76da12:	lea    0x70(%rsp),%rdi
  76da17:	call   7461f0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultNtNtCslbxve4rcJus_4gpui7runtime6CommitNtBZ_5ErrorEECs9C2G9YFESsD_29canonical_text_public_control>
  76da1c:	mov    %rbx,%rdi
  76da1f:	call   a97420 <_Unwind_Resume@plt>

<gpui::runtime::RuntimeMut<canonical_text_public_control::Editor, ()>>::replace_input bytes=1615 frame=248

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000076f1f0 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_>:
  76f1f0:	push   %rbp
  76f1f1:	push   %r15
  76f1f3:	push   %r14
  76f1f5:	push   %r13
  76f1f7:	push   %r12
  76f1f9:	push   %rbx
  76f1fa:	sub    $0xc8,%rsp
  76f201:	mov    %rdi,%rbx
  76f204:	mov    (%rsi),%r13
  76f207:	cmpb   $0x1,0x76e(%r13)
  76f20f:	jne    76f21d <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x2d>
  76f211:	movq   $0xe,(%rbx)
  76f218:	jmp    76f678 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x488>
  76f21d:	mov    %r8,%rbp
  76f220:	mov    %r9,0x90(%rsp)
  76f228:	mov    %rsi,0x98(%rsp)
  76f230:	lea    0x30(%rsp),%rdi
  76f235:	mov    %r13,%rsi
  76f238:	call   76a390 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11input_indexBY_>
  76f23d:	mov    0x30(%rsp),%rax
  76f242:	mov    0x38(%rsp),%rdx
  76f247:	cmp    $0xfffffffffffffffe,%rax
  76f24b:	jne    76f347 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x157>
  76f251:	mov    0x2e0(%r13),%rsi
  76f258:	cmp    %rsi,%rdx
  76f25b:	jae    76f763 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x573>
  76f261:	mov    0x2d8(%r13),%rcx
  76f268:	lea    (%rdx,%rdx,4),%r8
  76f26c:	mov    0x20(%rcx,%r8,8),%edi
  76f271:	mov    %edi,%eax
  76f273:	and    $0xf,%eax
  76f276:	cmp    $0x9,%eax
  76f279:	ja     76f711 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x521>
  76f27f:	cmp    $0x6,%eax
  76f282:	je     76f68a <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x49a>
  76f288:	shr    $0x4,%edi
  76f28b:	je     76f68a <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x49a>
  76f291:	mov    0x2f8(%r13),%rsi
  76f298:	dec    %edi
  76f29a:	cmp    %rdi,%rsi
  76f29d:	jbe    76f776 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x586>
  76f2a3:	mov    0x2f0(%r13),%rax
  76f2aa:	lea    (%rdi,%rdi,4),%rsi
  76f2ae:	shl    $0x4,%rsi
  76f2b2:	cmpq   $0xfffffffffffffffe,(%rax,%rsi,1)
  76f2b7:	je     76f6f7 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x507>
  76f2bd:	add    %rsi,%rax
  76f2c0:	mov    0x48(%rax),%r12
  76f2c4:	test   %r12,%r12
  76f2c7:	je     76f704 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x514>
  76f2cd:	mov    0x608(%r13),%rax
  76f2d4:	test   %rax,%rax
  76f2d7:	je     76f74a <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x55a>
  76f2dd:	mov    (%rcx,%r8,8),%r14
  76f2e1:	mov    0x610(%r13),%rcx
  76f2e8:	movzwl 0x1c2(%rax),%edi
  76f2ef:	mov    %edi,%r9d
  76f2f2:	shl    $0x5,%r9d
  76f2f6:	mov    $0xffffffffffffffff,%rsi
  76f2fd:	xor    %r8d,%r8d
  76f300:	cmp    %r8,%r9
  76f303:	je     76f330 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x140>
  76f305:	cmp    0x170(%rax,%rsi,8),%r12
  76f30d:	seta   %r10b
  76f311:	sbb    $0x0,%r10b
  76f315:	add    $0x20,%r8
  76f319:	inc    %rsi
  76f31c:	cmp    $0x1,%r10b
  76f320:	je     76f300 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x110>
  76f322:	movzbl %r10b,%edi
  76f326:	test   %edi,%edi
  76f328:	je     76f370 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x180>
  76f32a:	jmp    76f333 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x143>
  76f32c:	nopl   0x0(%rax)
  76f330:	mov    %rdi,%rsi
  76f333:	sub    $0x1,%rcx
  76f337:	jb     76f74a <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x55a>
  76f33d:	mov    0x1c8(%rax,%rsi,8),%rax
  76f345:	jmp    76f2e8 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0xf8>
  76f347:	mov    0x60(%rsp),%rcx
  76f34c:	mov    %rcx,0x30(%rbx)
  76f350:	movdqu 0x40(%rsp),%xmm0
  76f356:	movups 0x50(%rsp),%xmm1
  76f35b:	movups %xmm1,0x20(%rbx)
  76f35f:	movdqu %xmm0,0x10(%rbx)
  76f364:	mov    %rax,(%rbx)
  76f367:	mov    %rdx,0x8(%rbx)
  76f36b:	jmp    76f678 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x488>
  76f370:	cmpq   $0xffffffffffffffff,-0x20(%rax,%r8,1)
  76f376:	je     76f38e <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x19e>
  76f378:	mov    -0x8(%rax,%r8,1),%r15
  76f37d:	cmpb   $0x2,0xc(%rbp)
  76f381:	je     76f39b <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x1ab>
  76f383:	movups 0x0(%rbp),%xmm0
  76f387:	movups %xmm0,0x38(%rsp)
  76f38c:	jmp    76f3b7 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x1c7>
  76f38e:	lea    0x32af7b(%rip),%r15        # a9a310 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1b38>
  76f395:	cmpb   $0x2,0xc(%rbp)
  76f399:	jne    76f383 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x193>
  76f39b:	lea    0x30(%rsp),%rdi
  76f3a0:	mov    %r13,%rsi
  76f3a3:	call   76a4d0 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE12selection_atBY_>
  76f3a8:	mov    0x30(%rsp),%rax
  76f3ad:	cmp    $0xfffffffffffffffe,%rax
  76f3b1:	jne    76f65a <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x46a>
  76f3b7:	mov    %r15,0x28(%rsp)
  76f3bc:	mov    %r14,0x88(%rsp)
  76f3c4:	movdqu 0x38(%rsp),%xmm0
  76f3ca:	movdqa %xmm0,0xa0(%rsp)
  76f3d3:	cmp    $0x1,%r12d
  76f3d7:	jne    76f433 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x243>
  76f3d9:	mov    0x248(%r13),%rbp
  76f3e0:	mov    0x250(%r13),%r14
  76f3e7:	shl    $0x4,%r14
  76f3eb:	xor    %r15d,%r15d
  76f3ee:	xchg   %ax,%ax
  76f3f0:	cmp    %r15,%r14
  76f3f3:	je     76f624 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x434>
  76f3f9:	mov    0x0(%rbp,%r15,1),%rdi
  76f3fe:	mov    0x8(%rbp,%r15,1),%rax
  76f403:	call   *0x18(%rax)
  76f406:	add    $0x10,%r15
  76f40a:	cmp    %r12,%rax
  76f40d:	jne    76f3f0 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x200>
  76f40f:	mov    -0x10(%rbp,%r15,1),%rdi
  76f414:	mov    -0x8(%rbp,%r15,1),%rax
  76f419:	lea    0x290(%r13),%rsi
  76f420:	call   *0x28(%rax)
  76f423:	mov    0x28(%rsp),%r15
  76f428:	mov    %rax,%r14
  76f42b:	mov    %rdx,%rbp
  76f42e:	jmp    76f4b7 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x2c7>
  76f433:	mov    0x278(%r13),%rbp
  76f43a:	mov    0x280(%r13),%r14
  76f441:	shl    $0x4,%r14
  76f445:	xor    %r15d,%r15d
  76f448:	nopl   0x0(%rax,%rax,1)
  76f450:	cmp    %r15,%r14
  76f453:	je     76f624 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x434>
  76f459:	mov    0x0(%rbp,%r15,1),%rdi
  76f45e:	mov    0x8(%rbp,%r15,1),%rax
  76f463:	mov    %r12,%rsi
  76f466:	call   *0x30(%rax)
  76f469:	add    $0x10,%r15
  76f46d:	test   %al,%al
  76f46f:	je     76f450 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x260>
  76f471:	mov    -0x10(%rbp,%r15,1),%rsi
  76f476:	mov    -0x8(%rbp,%r15,1),%rax
  76f47b:	lea    0xb0(%rsp),%rdi
  76f483:	lea    0x290(%r13),%rdx
  76f48a:	mov    %r12,%rcx
  76f48d:	call   *0x58(%rax)
  76f490:	mov    0x28(%rsp),%r15
  76f495:	mov    0xb0(%rsp),%rax
  76f49d:	mov    0xb8(%rsp),%r14
  76f4a5:	mov    0xc0(%rsp),%rbp
  76f4ad:	cmp    $0xffffffffffffffff,%rax
  76f4b1:	jne    76f62c <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x43c>
  76f4b7:	mov    %r14,%rdi
  76f4ba:	call   *0x18(%rbp)
  76f4bd:	mov    %rdx,%rcx
  76f4c0:	lea    0x30(%rsp),%rdi
  76f4c5:	mov    %r15,%rsi
  76f4c8:	mov    %rax,%rdx
  76f4cb:	mov    %r12,%r8
  76f4ce:	call   *0x349f34(%rip)        # ab9408 <_DYNAMIC+0x6d8>
  76f4d4:	mov    0x38(%rsp),%rax
  76f4d9:	mov    0x40(%rsp),%r14
  76f4de:	mov    0x48(%rsp),%rbp
  76f4e3:	cmpb   $0x0,0x30(%rsp)
  76f4e8:	jne    76f62c <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x43c>
  76f4ee:	cmp    $0xffffffffffffffff,%rax
  76f4f2:	je     76f697 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x4a7>
  76f4f8:	mov    %rax,0x10(%rsp)
  76f4fd:	mov    %r14,0x18(%rsp)
  76f502:	mov    %rbp,0x80(%rsp)
  76f50a:	mov    0x10(%rsp),%rax
  76f50f:	mov    %rax,0x70(%rsp)
  76f514:	mov    0x18(%rsp),%rax
  76f519:	mov    %rax,0x78(%rsp)
  76f51e:	mov    0x78(%rsp),%r14
  76f523:	movdqa 0xa0(%rsp),%xmm0
  76f52c:	movdqa %xmm0,0x30(%rsp)
  76f532:	lea    0x30(%rsp),%rdx
  76f537:	mov    %r14,%rdi
  76f53a:	mov    %rbp,%rsi
  76f53d:	call   *0x349ebd(%rip)        # ab9400 <_DYNAMIC+0x6d0>
  76f543:	mov    $0x18,%ecx
  76f548:	test   %al,%al
  76f54a:	je     76f72f <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x53f>
  76f550:	movdqa 0xa0(%rsp),%xmm0
  76f559:	movd   %xmm0,%r13d
  76f55e:	pshufd $0xee,%xmm0,%xmm0
  76f563:	movd   %xmm0,%eax
  76f567:	cmp    %r13,%rax
  76f56a:	mov    %r13,%rbp
  76f56d:	cmovb  %rax,%rbp
  76f571:	mov    %rbp,%r15
  76f574:	mov    0x100(%rsp),%rcx
  76f57c:	add    %rcx,%r15
  76f57f:	jb     76f72a <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x53a>
  76f585:	cmp    %r13,%rax
  76f588:	cmova  %rax,%r13
  76f58c:	movq   $0x1e,0x30(%rsp)
  76f595:	lea    0x30(%rsp),%rdi
  76f59a:	call   74d580 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  76f59f:	lea    0x70(%rsp),%rdi
  76f5a4:	mov    %rbp,%rsi
  76f5a7:	mov    %r13,%rdx
  76f5aa:	mov    0x90(%rsp),%rcx
  76f5b2:	mov    0x100(%rsp),%r8
  76f5ba:	call   73d7c0 <_RINvMNtCscdodAO9FK5_5alloc6stringNtB3_6String13replace_rangeINtNtNtCs4NRVxsYgnAr_4core3ops5range5RangejEECs9C2G9YFESsD_29canonical_text_public_control>
  76f5bf:	mov    0x88(%rsp),%rax
  76f5c7:	mov    %rax,0x10(%rsp)
  76f5cc:	mov    %r12,0x20(%rsp)
  76f5d1:	mov    %r15,0x18(%rsp)
  76f5d6:	movq   $0x1,0x8(%rsp)
  76f5df:	mov    %r12,0x48(%rsp)
  76f5e4:	movaps 0x70(%rsp),%xmm0
  76f5e9:	movaps %xmm0,0x30(%rsp)
  76f5ee:	mov    0x80(%rsp),%rax
  76f5f6:	mov    %rax,0x40(%rsp)
  76f5fb:	mov    0x28(%rsp),%rax
  76f600:	mov    %rax,0x50(%rsp)
  76f605:	lea    0x30(%rsp),%rcx
  76f60a:	lea    0x8(%rsp),%r8
  76f60f:	mov    %rbx,%rdi
  76f612:	mov    0x98(%rsp),%rsi
  76f61a:	mov    %r12,%rdx
  76f61d:	call   73d8b0 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_>
  76f622:	jmp    76f678 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x488>
  76f624:	mov    $0xb,%eax
  76f629:	mov    %r12,%r14
  76f62c:	mov    %rax,0x10(%rsp)
  76f631:	mov    %r14,0x18(%rsp)
  76f636:	mov    %rbp,0x20(%rsp)
  76f63b:	mov    %rbp,0x18(%rbx)
  76f63f:	mov    0x10(%rsp),%rax
  76f644:	mov    %rax,0x8(%rbx)
  76f648:	mov    0x18(%rsp),%rax
  76f64d:	mov    %rax,0x10(%rbx)
  76f651:	movq   $0x20,(%rbx)
  76f658:	jmp    76f678 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x488>
  76f65a:	movups 0x48(%rsp),%xmm0
  76f65f:	movups 0x58(%rsp),%xmm1
  76f664:	movups %xmm1,0x28(%rbx)
  76f668:	movups %xmm0,0x18(%rbx)
  76f66c:	movups 0x38(%rsp),%xmm0
  76f671:	mov    %rax,(%rbx)
  76f674:	movups %xmm0,0x8(%rbx)
  76f678:	add    $0xc8,%rsp
  76f67f:	pop    %rbx
  76f680:	pop    %r12
  76f682:	pop    %r13
  76f684:	pop    %r14
  76f686:	pop    %r15
  76f688:	pop    %rbp
  76f689:	ret
  76f68a:	lea    0x32a95f(%rip),%rdi        # a99ff0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1818>
  76f691:	call   *0x349981(%rip)        # ab9018 <_DYNAMIC+0x2e8>
  76f697:	test   %rbp,%rbp
  76f69a:	jns    76f6ad <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x4bd>
  76f69c:	xor    %r15d,%r15d
  76f69f:	mov    %r15,%rdi
  76f6a2:	mov    %rbp,%rsi
  76f6a5:	call   *0x34997d(%rip)        # ab9028 <_DYNAMIC+0x2f8>
  76f6ab:	ud2
  76f6ad:	je     76f6e8 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x4f8>
  76f6af:	call   *0x3498c3(%rip)        # ab8f78 <_DYNAMIC+0x248>
  76f6b5:	mov    $0x1,%r15d
  76f6bb:	mov    $0x1,%esi
  76f6c0:	mov    %rbp,%rdi
  76f6c3:	call   *0x3498b7(%rip)        # ab8f80 <_DYNAMIC+0x250>
  76f6c9:	test   %rax,%rax
  76f6cc:	je     76f69f <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x4af>
  76f6ce:	mov    %rax,%rdi
  76f6d1:	mov    %r14,%rsi
  76f6d4:	mov    %rbp,%rdx
  76f6d7:	mov    %rax,%r14
  76f6da:	call   *0x3498b0(%rip)        # ab8f90 <memcpy@GLIBC_2.14>
  76f6e0:	mov    %rbp,%rax
  76f6e3:	jmp    76f4f8 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x308>
  76f6e8:	mov    $0x1,%r14d
  76f6ee:	xor    %eax,%eax
  76f6f0:	xor    %ebp,%ebp
  76f6f2:	jmp    76f4f8 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x308>
  76f6f7:	lea    0x329942(%rip),%rdi        # a99040 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x868>
  76f6fe:	call   *0x349914(%rip)        # ab9018 <_DYNAMIC+0x2e8>
  76f704:	lea    0x32a8fd(%rip),%rdi        # a9a008 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1830>
  76f70b:	call   *0x349907(%rip)        # ab9018 <_DYNAMIC+0x2e8>
  76f711:	lea    -0x69ce08(%rip),%rdi        # d2910 <GCC_except_table0+0x10570>
  76f718:	lea    0x32abc1(%rip),%rdx        # a9a2e0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1b08>
  76f71f:	mov    $0x83,%esi
  76f724:	call   *0x34987e(%rip)        # ab8fa8 <_DYNAMIC+0x278>
  76f72a:	mov    $0x1e,%ecx
  76f72f:	mov    %rcx,(%rbx)
  76f732:	mov    0x70(%rsp),%rsi
  76f737:	test   %rsi,%rsi
  76f73a:	je     76f678 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x488>
  76f740:	mov    $0x1,%edx
  76f745:	jmp    76f7fb <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x60b>
  76f74a:	lea    -0x69cfb6(%rip),%rdi        # d279b <GCC_except_table0+0x103fb>
  76f751:	lea    0x32a8c8(%rip),%rdx        # a9a020 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1848>
  76f758:	mov    $0x16,%esi
  76f75d:	call   *0x3498e5(%rip)        # ab9048 <_DYNAMIC+0x318>
  76f763:	lea    0x32a86e(%rip),%rax        # a99fd8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1800>
  76f76a:	mov    %rdx,%rdi
  76f76d:	mov    %rax,%rdx
  76f770:	call   *0x34982a(%rip)        # ab8fa0 <_DYNAMIC+0x270>
  76f776:	lea    0x3298ab(%rip),%rdx        # a99028 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x850>
  76f77d:	call   *0x34981d(%rip)        # ab8fa0 <_DYNAMIC+0x270>
  76f783:	mov    %rax,%rbx
  76f786:	mov    0x70(%rsp),%rsi
  76f78b:	test   %rsi,%rsi
  76f78e:	je     76f7a0 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x5b0>
  76f790:	mov    0x78(%rsp),%rdi
  76f795:	mov    $0x1,%edx
  76f79a:	call   *0x3497d0(%rip)        # ab8f70 <_DYNAMIC+0x240>
  76f7a0:	mov    %rbx,%rdi
  76f7a3:	call   a97420 <_Unwind_Resume@plt>
  76f7a8:	jmp    76f7ac <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x5bc>
  76f7aa:	jmp    76f7ac <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x5bc>
  76f7ac:	mov    %rax,%rdi
  76f7af:	call   *0x349813(%rip)        # ab8fc8 <_DYNAMIC+0x298>
  76f7b5:	mov    %rax,%r14
  76f7b8:	mov    %rdx,%r15
  76f7bb:	mov    %rax,0x10(%rsp)
  76f7c0:	mov    %rdx,0x18(%rsp)
  76f7c5:	movq   $0x2,0x8(%rsp)
  76f7ce:	mov    %r13,%rdi
  76f7d1:	call   78cc60 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE6poisonBO_>
  76f7d6:	movq   $0xf,(%rbx)
  76f7dd:	mov    (%r15),%rax
  76f7e0:	test   %rax,%rax
  76f7e3:	je     76f7ea <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x5fa>
  76f7e5:	mov    %r14,%rdi
  76f7e8:	call   *%rax
  76f7ea:	mov    0x8(%r15),%rsi
  76f7ee:	test   %rsi,%rsi
  76f7f1:	je     76f678 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x488>
  76f7f7:	mov    0x10(%r15),%rdx
  76f7fb:	mov    %r14,%rdi
  76f7fe:	call   *0x34976c(%rip)        # ab8f70 <_DYNAMIC+0x240>
  76f804:	jmp    76f678 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x488>
  76f809:	mov    %rax,%rbx
  76f80c:	mov    0x8(%r15),%rsi
  76f810:	test   %rsi,%rsi
  76f813:	je     76f7a0 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x5b0>
  76f815:	mov    0x10(%r15),%rdx
  76f819:	mov    %r14,%rdi
  76f81c:	jmp    76f79a <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x5aa>
  76f821:	mov    %rax,%rbx
  76f824:	lea    0x8(%rsp),%rdi
  76f829:	call   745fd0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultIBC_NtNtCscdodAO9FK5_5alloc6string6StringNtNtCslbxve4rcJus_4gpui6source9BindErrorEINtNtB15_5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECs9C2G9YFESsD_29canonical_text_public_control>
  76f82e:	jmp    76f7a0 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x5b0>
  76f833:	call   *0x34975f(%rip)        # ab8f98 <_DYNAMIC+0x268>
  76f839:	call   *0x349791(%rip)        # ab8fd0 <_DYNAMIC+0x2a0>

<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::acknowledge bytes=1581 frame=200

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000077aeb0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_>:
  77aeb0:	push   %r15
  77aeb2:	push   %r14
  77aeb4:	push   %r13
  77aeb6:	push   %r12
  77aeb8:	push   %rbx
  77aeb9:	sub    $0xa0,%rsp
  77aec0:	mov    %rdi,%r14
  77aec3:	cmp    %rdx,0x6d0(%rsi)
  77aeca:	jne    77b20e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x35e>
  77aed0:	mov    %rcx,%r15
  77aed3:	mov    %rsi,%rbx
  77aed6:	cmp    %rcx,0x6d8(%rsi)
  77aedd:	jne    77b20e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x35e>
  77aee3:	lea    0x600(%rbx),%rdi
  77aeea:	mov    %r15,%rsi
  77aeed:	call   *0x33e5c5(%rip)        # ab94b8 <_DYNAMIC+0x788>
  77aef3:	mov    0x5e8(%rbx),%rax
  77aefa:	mov    %rax,0x30(%rsp)
  77aeff:	movdqu 0x5c8(%rbx),%xmm0
  77af07:	movdqu 0x5d8(%rbx),%xmm1
  77af0f:	movdqa %xmm0,0x10(%rsp)
  77af15:	movq   $0xffffffffffffffff,0x5c8(%rbx)
  77af20:	movzbl 0x76c(%rbx),%eax
  77af27:	xor    $0x1,%rax
  77af2b:	cmpq   $0xffffffffffffffff,0x10(%rsp)
  77af31:	movdqa %xmm1,0x20(%rsp)
  77af37:	mov    $0x1,%r13d
  77af3d:	cmove  %rax,%r13
  77af41:	je     77afe9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x139>
  77af47:	movdqa 0x30(%rsp),%xmm0
  77af4d:	movss  0x34(%rsp),%xmm2
  77af53:	movd   %xmm0,%eax
  77af57:	pand   -0x6b748f(%rip),%xmm0        # c3ad0 <GCC_except_table0+0x1730>
  77af5f:	pxor   %xmm1,%xmm1
  77af63:	punpcklwd %xmm1,%xmm0
  77af67:	movq   %xmm0,0x6c0(%rbx)
  77af6f:	test   %ax,%ax
  77af72:	js     77b21a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x36a>
  77af78:	movss  %xmm2,0xc(%rsp)
  77af7e:	lea    0x5b0(%rbx),%r12
  77af85:	mov    %r12,%rdi
  77af88:	call   747260 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCslbxve4rcJus_4gpui7runtime9PresentedEECs9C2G9YFESsD_29canonical_text_public_control>
  77af8d:	mov    0x20(%rsp),%rax
  77af92:	mov    %rax,0x10(%r12)
  77af97:	movaps 0x10(%rsp),%xmm0
  77af9c:	movups %xmm0,(%r12)
  77afa1:	mov    0x6e8(%rbx),%rdi
  77afa8:	test   %rdi,%rdi
  77afab:	je     77afb3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x103>
  77afad:	call   *0x33e50d(%rip)        # ab94c0 <_DYNAMIC+0x790>
  77afb3:	mov    0x650(%rbx),%rax
  77afba:	test   %rax,%rax
  77afbd:	je     77afdb <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x12b>
  77afbf:	mov    0xe0(%rax),%rax
  77afc6:	test   %rax,%rax
  77afc9:	je     77afdb <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x12b>
  77afcb:	mov    0x50(%rax),%rcx
  77afcf:	mov    %rcx,0x38(%rax)
  77afd3:	movups 0x40(%rax),%xmm0
  77afd7:	movups %xmm0,0x28(%rax)
  77afdb:	movd   0xc(%rsp),%xmm0
  77afe1:	movd   %xmm0,0x764(%rbx)
  77afe9:	mov    0x650(%rbx),%rax
  77aff0:	test   %rax,%rax
  77aff3:	je     77b23c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77aff9:	mov    0x60(%rax),%r12
  77affd:	movq   $0xffffffffffffffff,0x60(%rax)
  77b005:	cmp    $0xffffffffffffffff,%r12
  77b009:	je     77b0ad <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x1fd>
  77b00f:	mov    0xb8(%rax),%rcx
  77b016:	mov    %rcx,0x90(%rsp)
  77b01e:	movups 0xa8(%rax),%xmm0
  77b025:	movaps %xmm0,0x80(%rsp)
  77b02d:	movups 0x68(%rax),%xmm0
  77b031:	movups 0x78(%rax),%xmm1
  77b035:	movups 0x88(%rax),%xmm2
  77b03c:	movups 0x98(%rax),%xmm3
  77b043:	movaps %xmm3,0x70(%rsp)
  77b048:	movaps %xmm2,0x60(%rsp)
  77b04d:	movaps %xmm1,0x50(%rsp)
  77b052:	movaps %xmm0,0x40(%rsp)
  77b057:	mov    0x650(%rbx),%rdi
  77b05e:	call   74ea10 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime8metadata5SheetECs9C2G9YFESsD_29canonical_text_public_control>
  77b063:	mov    0x650(%rbx),%rax
  77b06a:	mov    %r12,(%rax)
  77b06d:	movaps 0x40(%rsp),%xmm0
  77b072:	movdqa 0x50(%rsp),%xmm1
  77b078:	movaps 0x60(%rsp),%xmm2
  77b07d:	movaps 0x70(%rsp),%xmm3
  77b082:	movups %xmm0,0x8(%rax)
  77b086:	movdqu %xmm1,0x18(%rax)
  77b08b:	movups %xmm2,0x28(%rax)
  77b08f:	movups %xmm3,0x38(%rax)
  77b093:	movdqa 0x80(%rsp),%xmm0
  77b09c:	movdqu %xmm0,0x48(%rax)
  77b0a1:	mov    0x90(%rsp),%rcx
  77b0a9:	mov    %rcx,0x58(%rax)
  77b0ad:	mov    0x650(%rbx),%r12
  77b0b4:	test   %r12,%r12
  77b0b7:	je     77b23c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77b0bd:	mov    0x100(%r12),%rdi
  77b0c5:	test   %rdi,%rdi
  77b0c8:	je     77b119 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x269>
  77b0ca:	call   *0x33e3f8(%rip)        # ab94c8 <_DYNAMIC+0x798>
  77b0d0:	mov    0x100(%r12),%rax
  77b0d8:	cmpq   $0x0,0x10(%rax)
  77b0dd:	jne    77b119 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x269>
  77b0df:	cmpq   $0x0,0x58(%rax)
  77b0e4:	jne    77b119 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x269>
  77b0e6:	cmpq   $0x0,0x28(%rax)
  77b0eb:	jne    77b119 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x269>
  77b0ed:	cmpq   $0xffffffffffffffff,0x30(%rax)
  77b0f2:	jne    77b119 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x269>
  77b0f4:	mov    0x650(%rbx),%rax
  77b0fb:	mov    0x100(%rax),%rdi
  77b102:	call   745c30 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionINtNtCscdodAO9FK5_5alloc5boxed3BoxNtNtNtCslbxve4rcJus_4gpui7runtime8geometry8GeometryEEECs9C2G9YFESsD_29canonical_text_public_control>
  77b107:	mov    0x650(%rbx),%rax
  77b10e:	movq   $0x0,0x100(%rax)
  77b119:	mov    0x650(%rbx),%r12
  77b120:	test   %r12,%r12
  77b123:	je     77b23c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77b129:	mov    0xe0(%r12),%rdi
  77b131:	test   %rdi,%rdi
  77b134:	je     77b17a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x2ca>
  77b136:	cmpb   $0x2,0x24(%rdi)
  77b13a:	jne    77b17a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x2ca>
  77b13c:	cmpb   $0x2,0x3c(%rdi)
  77b140:	jne    77b17a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x2ca>
  77b142:	cmpb   $0x2,0x54(%rdi)
  77b146:	jne    77b17a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x2ca>
  77b148:	mov    $0x58,%esi
  77b14d:	mov    $0x8,%edx
  77b152:	call   *0x33de18(%rip)        # ab8f70 <_DYNAMIC+0x240>
  77b158:	mov    0x650(%rbx),%rax
  77b15f:	movq   $0x0,0xe0(%rax)
  77b16a:	mov    0x650(%rbx),%r12
  77b171:	test   %r12,%r12
  77b174:	je     77b23c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77b17a:	cmpq   $0x0,0xd8(%r12)
  77b183:	jne    77b23c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77b189:	cmpq   $0x0,0xe0(%r12)
  77b192:	jne    77b23c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77b198:	cmpq   $0x0,0x100(%r12)
  77b1a1:	jne    77b23c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77b1a7:	cmpq   $0x0,0xd0(%r12)
  77b1b0:	jne    77b23c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77b1b6:	cmpq   $0x0,0xf8(%r12)
  77b1bf:	jne    77b23c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77b1c1:	mov    0x60(%r12),%rax
  77b1c6:	cmp    $0xffffffff,%eax
  77b1c9:	jne    77b23c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77b1cb:	cmpq   $0x0,0x28(%r12)
  77b1d1:	jne    77b23c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77b1d3:	mov    (%r12),%rax
  77b1d7:	or     0x40(%r12),%rax
  77b1dc:	jne    77b23c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77b1de:	cmpq   $0x0,0x58(%r12)
  77b1e4:	jne    77b23c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77b1e6:	mov    %r12,%rdi
  77b1e9:	call   74eab0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime8metadata8MetadataECs9C2G9YFESsD_29canonical_text_public_control>
  77b1ee:	mov    $0x108,%esi
  77b1f3:	mov    $0x8,%edx
  77b1f8:	mov    %r12,%rdi
  77b1fb:	call   *0x33dd6f(%rip)        # ab8f70 <_DYNAMIC+0x240>
  77b201:	movq   $0x0,0x650(%rbx)
  77b20c:	jmp    77b23c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77b20e:	movq   $0x15,(%r14)
  77b215:	jmp    77b3f0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x540>
  77b21a:	movss  %xmm2,0x764(%rbx)
  77b222:	lea    0x10(%rsp),%rdi
  77b227:	call   747260 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCslbxve4rcJus_4gpui7runtime9PresentedEECs9C2G9YFESsD_29canonical_text_public_control>
  77b22c:	mov    0x650(%rbx),%rax
  77b233:	test   %rax,%rax
  77b236:	jne    77aff9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x149>
  77b23c:	mov    0x6e8(%rbx),%rdi
  77b243:	test   %rdi,%rdi
  77b246:	je     77b26d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x3bd>
  77b248:	cmpq   $0x0,0x30(%rdi)
  77b24d:	jne    77b26d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x3bd>
  77b24f:	cmpq   $0x0,0x10(%rdi)
  77b254:	jne    77b26d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x3bd>
  77b256:	cmpq   $0xffffffffffffffff,0x18(%rdi)
  77b25b:	jne    77b26d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x3bd>
  77b25d:	call   745ac0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionINtNtCscdodAO9FK5_5alloc5boxed3BoxNtNtNtCslbxve4rcJus_4gpui7runtime13text_geometry13TextResourcesEEECs9C2G9YFESsD_29canonical_text_public_control>
  77b262:	movq   $0x0,0x6e8(%rbx)
  77b26d:	mov    0x628(%rbx),%rax
  77b274:	test   %rax,%rax
  77b277:	je     77b31f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x46f>
  77b27d:	cmp    0x5f0(%rbx),%rax
  77b284:	jne    77b314 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x464>
  77b28a:	mov    0x630(%rbx),%rdx
  77b291:	lea    0x40(%rsp),%rdi
  77b296:	mov    %rbx,%rsi
  77b299:	call   78c610 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE16resolve_identityBO_>
  77b29e:	mov    0x40(%rsp),%rax
  77b2a3:	mov    0x48(%rsp),%rsi
  77b2a8:	cmp    $0xfffffffffffffffe,%rax
  77b2ac:	jne    77b2d9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x429>
  77b2ae:	mov    0x2e0(%rbx),%rax
  77b2b5:	cmp    %rax,%rsi
  77b2b8:	jae    77b401 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x551>
  77b2be:	lea    (%rsi,%rsi,4),%rdi
  77b2c2:	shl    $0x3,%rdi
  77b2c6:	add    0x2d8(%rbx),%rdi
  77b2cd:	call   *0x33dfcd(%rip)        # ab92a0 <_DYNAMIC+0x570>
  77b2d3:	test   %al,%al
  77b2d5:	je     77b314 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x464>
  77b2d7:	jmp    77b31f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x46f>
  77b2d9:	cmp    $0xd,%rax
  77b2dd:	jl     77b2f7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x447>
  77b2df:	cmp    $0x21,%rax
  77b2e3:	je     77b2f7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x447>
  77b2e5:	cmp    $0x26,%rax
  77b2e9:	jne    77b314 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x464>
  77b2eb:	test   %rsi,%rsi
  77b2ee:	je     77b314 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x464>
  77b2f0:	lea    0x50(%rsp),%rax
  77b2f5:	jmp    77b306 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x456>
  77b2f7:	mov    0x58(%rsp),%rsi
  77b2fc:	test   %rsi,%rsi
  77b2ff:	je     77b314 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x464>
  77b301:	lea    0x60(%rsp),%rax
  77b306:	mov    (%rax),%rdi
  77b309:	mov    $0x1,%edx
  77b30e:	call   *0x33dc5c(%rip)        # ab8f70 <_DYNAMIC+0x240>
  77b314:	movq   $0x0,0x628(%rbx)
  77b31f:	mov    0x6e0(%rbx),%rax
  77b326:	mov    %rax,0x6a8(%rbx)
  77b32d:	mov    %r15,0x6b0(%rbx)
  77b334:	mov    0x6b8(%rbx),%rcx
  77b33b:	test   %rcx,%rcx
  77b33e:	je     77b392 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x4e2>
  77b340:	mov    0x6c0(%rbx),%rdx
  77b347:	cmpb   $0x0,0x59(%rcx)
  77b34b:	je     77b363 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x4b3>
  77b34d:	cmp    %r15,0x30(%rcx)
  77b351:	jne    77b375 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x4c5>
  77b353:	cmp    %rax,0x38(%rcx)
  77b357:	jne    77b375 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x4c5>
  77b359:	cmp    %rdx,0x40(%rcx)
  77b35d:	sete   %sil
  77b361:	jmp    77b377 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x4c7>
  77b363:	cmp    %rax,0x38(%rcx)
  77b367:	jne    77b375 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x4c5>
  77b369:	cmp    %r15,0x30(%rcx)
  77b36d:	jne    77b375 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x4c5>
  77b36f:	cmp    %rdx,0x40(%rcx)
  77b373:	je     77b392 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x4e2>
  77b375:	xor    %esi,%esi
  77b377:	and    %sil,0x58(%rcx)
  77b37b:	movb   $0x0,0x59(%rcx)
  77b37f:	mov    %r15,0x30(%rcx)
  77b383:	mov    %rax,0x38(%rcx)
  77b387:	mov    %rdx,0x40(%rcx)
  77b38b:	mov    0x6a8(%rbx),%rax
  77b392:	movb   $0x1,0x76c(%rbx)
  77b399:	add    %r13,0x738(%rbx)
  77b3a0:	mov    0x6a0(%rbx),%rcx
  77b3a7:	cmpq   $0x0,0x6d0(%rbx)
  77b3af:	je     77b3c7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x517>
  77b3b1:	mov    0x6e0(%rbx),%rsi
  77b3b8:	xor    %edx,%edx
  77b3ba:	cmpq   $0xffffffffffffffff,0x5c8(%rbx)
  77b3c2:	setne  %dl
  77b3c5:	jmp    77b3c9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x519>
  77b3c7:	xor    %edx,%edx
  77b3c9:	mov    0x758(%rbx),%rdi
  77b3d0:	mov    %rdx,0x8(%r14)
  77b3d4:	mov    %rsi,0x10(%r14)
  77b3d8:	mov    %rcx,0x18(%r14)
  77b3dc:	mov    %rax,0x20(%r14)
  77b3e0:	mov    %rdi,0x28(%r14)
  77b3e4:	movb   $0x1,0x30(%r14)
  77b3e9:	movq   $0xfffffffffffffffe,(%r14)
  77b3f0:	add    $0xa0,%rsp
  77b3f7:	pop    %rbx
  77b3f8:	pop    %r12
  77b3fa:	pop    %r13
  77b3fc:	pop    %r14
  77b3fe:	pop    %r15
  77b400:	ret
  77b401:	lea    0x31db60(%rip),%rdx        # a98f68 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x790>
  77b408:	mov    %rsi,%rdi
  77b40b:	mov    %rax,%rsi
  77b40e:	call   *0x33db8c(%rip)        # ab8fa0 <_DYNAMIC+0x270>
  77b414:	mov    %rax,%r14
  77b417:	mov    $0x108,%esi
  77b41c:	mov    $0x8,%edx
  77b421:	mov    %r12,%rdi
  77b424:	call   *0x33db46(%rip)        # ab8f70 <_DYNAMIC+0x240>
  77b42a:	movq   $0x0,0x650(%rbx)
  77b435:	mov    %r14,%rdi
  77b438:	call   a97420 <_Unwind_Resume@plt>
  77b43d:	mov    %rax,%r14
  77b440:	mov    0x650(%rbx),%rax
  77b447:	movq   $0x0,0x100(%rax)
  77b452:	mov    %r14,%rdi
  77b455:	call   a97420 <_Unwind_Resume@plt>
  77b45a:	movq   $0x0,0x6e8(%rbx)
  77b465:	mov    %rax,%rdi
  77b468:	call   a97420 <_Unwind_Resume@plt>
  77b46d:	mov    %rax,%r14
  77b470:	mov    0x650(%rbx),%rax
  77b477:	mov    %r12,(%rax)
  77b47a:	movaps 0x40(%rsp),%xmm0
  77b47f:	movaps 0x50(%rsp),%xmm1
  77b484:	movaps 0x60(%rsp),%xmm2
  77b489:	movaps 0x70(%rsp),%xmm3
  77b48e:	movups %xmm0,0x8(%rax)
  77b492:	movups %xmm1,0x18(%rax)
  77b496:	movups %xmm2,0x28(%rax)
  77b49a:	movups %xmm3,0x38(%rax)
  77b49e:	movaps 0x80(%rsp),%xmm0
  77b4a6:	movups %xmm0,0x48(%rax)
  77b4aa:	mov    0x90(%rsp),%rcx
  77b4b2:	mov    %rcx,0x58(%rax)
  77b4b6:	mov    %r14,%rdi
  77b4b9:	call   a97420 <_Unwind_Resume@plt>
  77b4be:	mov    %rax,%r14
  77b4c1:	mov    0x20(%rsp),%rax
  77b4c6:	mov    %rax,0x10(%r12)
  77b4cb:	movaps 0x10(%rsp),%xmm0
  77b4d0:	movups %xmm0,(%r12)
  77b4d5:	mov    %r14,%rdi
  77b4d8:	call   a97420 <_Unwind_Resume@plt>

<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::present_inner bytes=22621 frame=3768

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000077b4e0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_>:
  77b4e0:	push   %rbp
  77b4e1:	push   %r15
  77b4e3:	push   %r14
  77b4e5:	push   %r13
  77b4e7:	push   %r12
  77b4e9:	push   %rbx
  77b4ea:	sub    $0xe88,%rsp
  77b4f1:	mov    %rdi,0x48(%rsp)
  77b4f6:	mov    0x5f8(%rsi),%rax
  77b4fd:	mov    %rax,0x260(%rsp)
  77b505:	inc    %rax
  77b508:	je     77feca <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x49ea>
  77b50e:	mov    %rsi,%r13
  77b511:	mov    %rax,0x8b0(%rsp)
  77b519:	mov    0x5f0(%rsi),%rax
  77b520:	mov    %rax,0x680(%rsp)
  77b528:	mov    0x6c8(%rsi),%rsi
  77b52f:	mov    %rsi,%r14
  77b532:	shr    $0x20,%r14
  77b536:	movss  0x760(%r13),%xmm0
  77b53f:	movss  %xmm0,0x9c(%rsp)
  77b548:	mov    0x1a8(%r13),%eax
  77b54f:	mov    0x1b0(%r13),%rcx
  77b556:	shl    $0x20,%rcx
  77b55a:	or     %rax,%rcx
  77b55d:	cmp    %rcx,%rsi
  77b560:	jne    77b588 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xa8>
  77b562:	mov    %rsi,%r15
  77b565:	movq   $0x2,0xca0(%rsp)
  77b571:	mov    $0x2,%ebx
  77b576:	cmp    $0xffff,%r15d
  77b57d:	jbe    77b62a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x14a>
  77b583:	jmp    77b63b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x15b>
  77b588:	movups 0x138(%r13),%xmm0
  77b590:	movaps %xmm0,0x970(%rsp)
  77b598:	lea    0x390(%rsp),%rdi
  77b5a0:	lea    0x970(%rsp),%rcx
  77b5a8:	mov    %rsi,%r15
  77b5ab:	mov    %r14,%r12
  77b5ae:	mov    %r14d,%edx
  77b5b1:	call   *0x33dcd1(%rip)        # ab9288 <_DYNAMIC+0x558>
  77b5b7:	mov    0x390(%rsp),%rbx
  77b5bf:	mov    0x398(%rsp),%r14d
  77b5c7:	mov    0x39c(%rsp),%ebp
  77b5ce:	cmp    $0x2,%rbx
  77b5d2:	jne    77b5ec <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x10c>
  77b5d4:	mov    0x48(%rsp),%rax
  77b5d9:	movq   $0x23,(%rax)
  77b5e0:	mov    %r14d,0x8(%rax)
  77b5e4:	mov    %ebp,0xc(%rax)
  77b5e7:	jmp    77cd21 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1841>
  77b5ec:	lea    0x3a0(%rsp),%rsi
  77b5f4:	lea    0xcb0(%rsp),%rdi
  77b5fc:	mov    $0x1d8,%edx
  77b601:	call   *0x33d989(%rip)        # ab8f90 <memcpy@GLIBC_2.14>
  77b607:	mov    %rbx,0xca0(%rsp)
  77b60f:	mov    %r14d,0xca8(%rsp)
  77b617:	mov    %ebp,0xcac(%rsp)
  77b61e:	mov    %r12,%r14
  77b621:	cmp    $0xffff,%r15d
  77b628:	ja     77b63b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x15b>
  77b62a:	mov    %r15,0xf8(%rsp)
  77b632:	mov    %r15,%rax
  77b635:	shr    $0x30,%rax
  77b639:	je     77b65c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17c>
  77b63b:	mov    0x48(%rsp),%rax
  77b640:	movq   $0x23,(%rax)
  77b647:	movl   $0x0,0x8(%rax)
  77b64e:	cmp    $0x2,%ebx
  77b651:	jne    77cd14 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1834>
  77b657:	jmp    77cd21 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1841>
  77b65c:	cmpq   $0x0,0x2f8(%r13)
  77b664:	mov    %r13,0x40(%rsp)
  77b669:	je     77b67e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x19e>
  77b66b:	mov    0x6e8(%r13),%rax
  77b672:	test   %rax,%rax
  77b675:	je     77b693 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1b3>
  77b677:	cmpq   $0x0,0x30(%rax)
  77b67c:	je     77b6e0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x200>
  77b67e:	mov    0x6e8(%r13),%rax
  77b685:	test   %rax,%rax
  77b688:	jne    77b7d5 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2f5>
  77b68e:	jmp    77b832 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x352>
  77b693:	call   *0x33d8df(%rip)        # ab8f78 <_DYNAMIC+0x248>
  77b699:	mov    $0x78,%edi
  77b69e:	mov    $0x8,%esi
  77b6a3:	call   *0x33d8d7(%rip)        # ab8f80 <_DYNAMIC+0x250>
  77b6a9:	test   %rax,%rax
  77b6ac:	je     7802e7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4e07>
  77b6b2:	movq   $0x0,(%rax)
  77b6b9:	movq   $0x8,0x8(%rax)
  77b6c1:	movq   $0x0,0x10(%rax)
  77b6c9:	movq   $0xffffffffffffffff,0x18(%rax)
  77b6d1:	movq   $0x0,0x30(%rax)
  77b6d9:	mov    %rax,0x6e8(%r13)
  77b6e0:	mov    %r14,%rbx
  77b6e3:	mov    $0x1,%bpl
  77b6e6:	lea    0x390(%rsp),%rdi
  77b6ee:	call   *0x33dddc(%rip)        # ab94d0 <_DYNAMIC+0x7a0>
  77b6f4:	mov    0x390(%rsp),%r12
  77b6fc:	mov    0x398(%rsp),%r14d
  77b704:	mov    0x39c(%rsp),%ebp
  77b70b:	test   %r12,%r12
  77b70e:	je     77cc2d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x174d>
  77b714:	mov    0x3d0(%rsp),%rax
  77b71c:	mov    %rax,0x9a0(%rsp)
  77b724:	movups 0x3a0(%rsp),%xmm0
  77b72c:	movups 0x3b0(%rsp),%xmm1
  77b734:	movups 0x3c0(%rsp),%xmm2
  77b73c:	movaps %xmm2,0x990(%rsp)
  77b744:	movaps %xmm1,0x980(%rsp)
  77b74c:	movaps %xmm0,0x970(%rsp)
  77b754:	mov    0x6e8(%r13),%r15
  77b75b:	mov    0x30(%r15),%rax
  77b75f:	test   %rax,%rax
  77b762:	je     77b787 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2a7>
  77b764:	lock decq (%rax)
  77b768:	jne    77b774 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x294>
  77b76a:	lea    0x30(%r15),%rdi
  77b76e:	call   *0x33d8ec(%rip)        # ab9060 <_DYNAMIC+0x330>
  77b774:	add    $0x38,%r15
  77b778:	mov    %r15,%rdi
  77b77b:	call   74cd40 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text11RasterCacheECs9C2G9YFESsD_29canonical_text_public_control>
  77b780:	mov    0x6e8(%r13),%r15
  77b787:	mov    %r12,0x30(%r15)
  77b78b:	mov    %r14d,0x38(%r15)
  77b78f:	mov    %ebp,0x3c(%r15)
  77b793:	movaps 0x970(%rsp),%xmm0
  77b79b:	movaps 0x980(%rsp),%xmm1
  77b7a3:	movaps 0x990(%rsp),%xmm2
  77b7ab:	movups %xmm0,0x40(%r15)
  77b7b0:	movups %xmm1,0x50(%r15)
  77b7b5:	movups %xmm2,0x60(%r15)
  77b7ba:	mov    0x9a0(%rsp),%rax
  77b7c2:	mov    %rax,0x70(%r15)
  77b7c6:	mov    %rbx,%r14
  77b7c9:	mov    0x6e8(%r13),%rax
  77b7d0:	test   %rax,%rax
  77b7d3:	je     77b832 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x352>
  77b7d5:	mov    0x30(%rax),%rax
  77b7d9:	test   %rax,%rax
  77b7dc:	je     77b832 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x352>
  77b7de:	lock incq (%rax)
  77b7e2:	jle    780668 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  77b7e8:	mov    %rax,0xd0(%rsp)
  77b7f0:	movq   $0x0,0x200(%rsp)
  77b7fc:	movq   $0x8,0x208(%rsp)
  77b808:	movq   $0x0,0x210(%rsp)
  77b814:	lea    0xd0(%rsp),%rax
  77b81c:	mov    %rax,0x1c0(%rsp)
  77b824:	movq   $0x0,0x1c8(%rsp)
  77b830:	jmp    77b86e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x38e>
  77b832:	movq   $0x0,0xd0(%rsp)
  77b83e:	movq   $0x0,0x200(%rsp)
  77b84a:	movq   $0x8,0x208(%rsp)
  77b856:	movq   $0x0,0x210(%rsp)
  77b862:	movq   $0x0,0x1c0(%rsp)
  77b86e:	lea    0x778(%rsp),%rdi
  77b876:	mov    %r13,%rsi
  77b879:	call   76aaa0 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE16active_selectionBY_>
  77b87e:	lea    0x390(%rsp),%rdi
  77b886:	mov    %r13,%rsi
  77b889:	call   76aaa0 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE16active_selectionBY_>
  77b88e:	movzbl 0x3a4(%rsp),%eax
  77b896:	mov    %al,0x57(%rsp)
  77b89a:	cmp    $0x2,%al
  77b89c:	je     77b8ee <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x40e>
  77b89e:	mov    0x390(%rsp),%rax
  77b8a6:	mov    %rax,0x678(%rsp)
  77b8ae:	test   %rax,%rax
  77b8b1:	je     7802c9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4de9>
  77b8b7:	mov    0x3a0(%rsp),%eax
  77b8be:	mov    %eax,0x2f0(%rsp)
  77b8c5:	mov    0x398(%rsp),%rax
  77b8cd:	mov    %rax,0x2e8(%rsp)
  77b8d5:	movzwl 0x3a5(%rsp),%eax
  77b8dd:	mov    %ax,0x7a(%rsp)
  77b8e2:	movzbl 0x3a7(%rsp),%eax
  77b8ea:	mov    %al,0x7c(%rsp)
  77b8ee:	lea    0x300(%r13),%rax
  77b8f5:	mov    %rax,0x58(%rsp)
  77b8fa:	cmpb   $0x0,0x768(%r13)
  77b902:	mov    %r14,0x2e0(%rsp)
  77b90a:	jne    77bc52 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x772>
  77b910:	cmpb   $0x0,0x769(%r13)
  77b918:	jne    77bc52 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x772>
  77b91e:	cmpb   $0x0,0x590(%r13)
  77b926:	jne    77bc52 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x772>
  77b92c:	mov    0x658(%r13),%rax
  77b933:	mov    0x668(%r13),%r15
  77b93a:	test   %rax,%rax
  77b93d:	setne  %cl
  77b940:	test   %r15,%r15
  77b943:	setne  %dl
  77b946:	and    %cl,%dl
  77b948:	cmp    $0x1,%dl
  77b94b:	jne    77c1b4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xcd4>
  77b951:	mov    0x660(%r13),%r14
  77b958:	lea    0x1e8(%r13),%rcx
  77b95f:	mov    %rcx,0x30(%rsp)
  77b964:	lea    0x688(%r13),%rcx
  77b96b:	mov    %rcx,0x38(%rsp)
  77b970:	xor    %ebx,%ebx
  77b972:	lea    0x31ea37(%rip),%rcx        # a9a3b0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1bd8>
  77b979:	mov    %rcx,0x80(%rsp)
  77b981:	jmp    77b9b0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4d0>
  77b983:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  77b990:	mov    0x38(%rsp),%rdi
  77b995:	mov    %rbp,%rsi
  77b998:	call   77a460 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapyNtNtB7_7set_val9SetValZSTE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  77b99d:	mov    $0x0,%eax
  77b9a2:	dec    %r15
  77b9a5:	mov    0x40(%rsp),%r13
  77b9aa:	je     77c1b4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xcd4>
  77b9b0:	test   %rbx,%rbx
  77b9b3:	je     77b9d0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4f0>
  77b9b5:	movzwl 0x58a(%rbx),%ecx
  77b9bc:	cmp    %rcx,%r14
  77b9bf:	jae    77ba80 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5a0>
  77b9c5:	mov    %rbx,%rcx
  77b9c8:	mov    %r14,%rdx
  77b9cb:	jmp    77baa6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5c6>
  77b9d0:	test   %r14,%r14
  77b9d3:	je     77ba0d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x52d>
  77b9d5:	mov    %r14,%rcx
  77b9d8:	mov    %rax,%rbx
  77b9db:	and    $0x7,%rcx
  77b9df:	je     77ba12 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x532>
  77b9e1:	xor    %edx,%edx
  77b9e3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  77b9f0:	mov    0x590(%rbx),%rbx
  77b9f7:	inc    %rdx
  77b9fa:	cmp    %rdx,%rcx
  77b9fd:	jne    77b9f0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x510>
  77b9ff:	mov    %r14,%rax
  77ba02:	sub    %rdx,%rax
  77ba05:	cmp    $0x8,%r14
  77ba09:	jae    77ba20 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x540>
  77ba0b:	jmp    77ba5e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57e>
  77ba0d:	mov    %rax,%rbx
  77ba10:	jmp    77ba5e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57e>
  77ba12:	mov    %r14,%rax
  77ba15:	cmp    $0x8,%r14
  77ba19:	jb     77ba5e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57e>
  77ba1b:	nopl   0x0(%rax,%rax,1)
  77ba20:	mov    0x590(%rbx),%rcx
  77ba27:	mov    0x590(%rcx),%rcx
  77ba2e:	mov    0x590(%rcx),%rcx
  77ba35:	mov    0x590(%rcx),%rcx
  77ba3c:	mov    0x590(%rcx),%rcx
  77ba43:	mov    0x590(%rcx),%rcx
  77ba4a:	mov    0x590(%rcx),%rcx
  77ba51:	mov    0x590(%rcx),%rbx
  77ba58:	add    $0xfffffffffffffff8,%rax
  77ba5c:	jne    77ba20 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x540>
  77ba5e:	xor    %eax,%eax
  77ba60:	xor    %r14d,%r14d
  77ba63:	movzwl 0x58a(%rbx),%ecx
  77ba6a:	cmp    %rcx,%r14
  77ba6d:	jb     77b9c5 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4e5>
  77ba73:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  77ba80:	mov    0x580(%rbx),%rcx
  77ba87:	test   %rcx,%rcx
  77ba8a:	je     7802ff <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4e1f>
  77ba90:	inc    %rax
  77ba93:	movzwl 0x588(%rbx),%edx
  77ba9a:	mov    %rcx,%rbx
  77ba9d:	cmp    0x58a(%rcx),%dx
  77baa4:	jae    77ba80 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5a0>
  77baa6:	test   %rax,%rax
  77baa9:	je     77bb40 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x660>
  77baaf:	lea    (%rcx,%rdx,8),%rsi
  77bab3:	add    $0x598,%rsi
  77baba:	mov    %rax,%rdi
  77babd:	and    $0x7,%rdi
  77bac1:	je     77bc40 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x760>
  77bac7:	xor    %r8d,%r8d
  77baca:	nopw   0x0(%rax,%rax,1)
  77bad0:	mov    (%rsi),%rbx
  77bad3:	lea    0x590(%rbx),%rsi
  77bada:	inc    %r8
  77badd:	cmp    %r8,%rdi
  77bae0:	jne    77bad0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5f0>
  77bae2:	mov    %rax,%rdi
  77bae5:	sub    %r8,%rdi
  77bae8:	cmp    $0x8,%rax
  77baec:	jb     77bb31 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x651>
  77baee:	xchg   %ax,%ax
  77baf0:	mov    (%rsi),%rax
  77baf3:	mov    0x590(%rax),%rax
  77bafa:	mov    0x590(%rax),%rax
  77bb01:	mov    0x590(%rax),%rax
  77bb08:	mov    0x590(%rax),%rax
  77bb0f:	mov    0x590(%rax),%rax
  77bb16:	mov    0x590(%rax),%rax
  77bb1d:	mov    0x590(%rax),%rbx
  77bb24:	lea    0x590(%rbx),%rsi
  77bb2b:	add    $0xfffffffffffffff8,%rdi
  77bb2f:	jne    77baf0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x610>
  77bb31:	xor    %r14d,%r14d
  77bb34:	jmp    77bb47 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x667>
  77bb36:	cs nopw 0x0(%rax,%rax,1)
  77bb40:	lea    0x1(%rdx),%r14
  77bb44:	mov    %rcx,%rbx
  77bb47:	imul   $0x70,%rdx,%rax
  77bb4b:	shl    $0x4,%rdx
  77bb4f:	lea    (%rcx,%rax,1),%rdi
  77bb53:	add    $0xb0,%rdi
  77bb5a:	mov    (%rcx,%rdx,1),%rsi
  77bb5e:	mov    0x8(%rcx,%rdx,1),%rdx
  77bb63:	call   *0x33d59f(%rip)        # ab9108 <_DYNAMIC+0x3d8>
  77bb69:	mov    %rax,%rbp
  77bb6c:	mov    0x30(%rsp),%rdi
  77bb71:	mov    %rax,%rsi
  77bb74:	call   775510 <_RNvMs_NtNtCslbxve4rcJus_4gpui7runtime14identity_indexNtB4_13IdentityIndex8required>
  77bb79:	mov    %rax,%r12
  77bb7c:	mov    0x40(%rsp),%rax
  77bb81:	mov    0x2e0(%rax),%r13
  77bb88:	cmp    %r13,%r12
  77bb8b:	jae    7804f7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5017>
  77bb91:	mov    0x2d8(%rax),%rcx
  77bb98:	lea    (%r12,%r12,4),%rax
  77bb9c:	mov    0x18(%rcx,%rax,8),%r12d
  77bba1:	mov    $0xffffffff,%eax
  77bba6:	cmp    %rax,%r12
  77bba9:	je     77b99d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4bd>
  77bbaf:	cmp    %r12,%r13
  77bbb2:	jbe    780459 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4f79>
  77bbb8:	mov    0x38(%rsp),%rax
  77bbbd:	mov    (%rax),%rax
  77bbc0:	test   %rax,%rax
  77bbc3:	je     77b99d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4bd>
  77bbc9:	lea    (%r12,%r12,4),%rdx
  77bbcd:	mov    (%rcx,%rdx,8),%rcx
  77bbd1:	mov    0x40(%rsp),%rdx
  77bbd6:	mov    0x690(%rdx),%rdx
  77bbdd:	movzwl 0x62(%rax),%edi
  77bbe1:	mov    %edi,%r8d
  77bbe4:	shl    $0x3,%r8d
  77bbe8:	mov    $0xffffffffffffffff,%rsi
  77bbef:	nop
  77bbf0:	test   %r8,%r8
  77bbf3:	je     77bc20 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x740>
  77bbf5:	cmp    0x10(%rax,%rsi,8),%rcx
  77bbfa:	seta   %r9b
  77bbfe:	sbb    $0x0,%r9b
  77bc02:	inc    %rsi
  77bc05:	add    $0xfffffffffffffff8,%r8
  77bc09:	cmp    $0x1,%r9b
  77bc0d:	je     77bbf0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x710>
  77bc0f:	movzbl %r9b,%edi
  77bc13:	test   %edi,%edi
  77bc15:	je     77b990 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4b0>
  77bc1b:	jmp    77bc23 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x743>
  77bc1d:	nopl   (%rax)
  77bc20:	mov    %rdi,%rsi
  77bc23:	sub    $0x1,%rdx
  77bc27:	jb     77b99d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4bd>
  77bc2d:	mov    0x68(%rax,%rsi,8),%rax
  77bc32:	jmp    77bbdd <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x6fd>
  77bc34:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  77bc40:	mov    %rax,%rdi
  77bc43:	cmp    $0x8,%rax
  77bc47:	jae    77baf0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x610>
  77bc4d:	jmp    77bb31 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x651>
  77bc52:	lea    0x390(%rsp),%rdi
  77bc5a:	call   *0x33d638(%rip)        # ab9298 <_DYNAMIC+0x568>
  77bc60:	lea    0x300(%r13),%r14
  77bc67:	mov    %r14,%rdi
  77bc6a:	call   74c2c0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscO85OU7Wpt0_20gpui_reactivity_core6layout10LayoutTreeECs9C2G9YFESsD_29canonical_text_public_control>
  77bc6f:	lea    0x390(%rsp),%rsi
  77bc77:	mov    $0x298,%edx
  77bc7c:	mov    %r14,%rdi
  77bc7f:	call   *0x33d30b(%rip)        # ab8f90 <memcpy@GLIBC_2.14>
  77bc85:	movq   $0x0,0x5a8(%r13)
  77bc90:	mov    0x2e0(%r13),%rax
  77bc97:	test   %rax,%rax
  77bc9a:	je     77c786 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x12a6>
  77bca0:	mov    0x40(%rsp),%rcx
  77bca5:	lea    0x598(%rcx),%rdx
  77bcac:	mov    %rdx,0x38(%rsp)
  77bcb1:	mov    0x2d8(%rcx),%rbx
  77bcb8:	lea    (%rax,%rax,4),%rax
  77bcbc:	lea    (%rbx,%rax,8),%rax
  77bcc0:	mov    %rax,0x30(%rsp)
  77bcc5:	xor    %r13d,%r13d
  77bcc8:	lea    -0x6b7bdb(%rip),%r14        # c40f4 <GCC_except_table0+0x1d54>
  77bccf:	lea    0x31d3e2(%rip),%rax        # a990b8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x8e0>
  77bcd6:	mov    %rax,0x80(%rsp)
  77bcde:	xor    %ebp,%ebp
  77bce0:	jmp    77bd2b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x84b>
  77bce2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  77bcf0:	add    $0x28,%rbx
  77bcf4:	inc    %rbp
  77bcf7:	mov    0x40(%rsp),%rdx
  77bcfc:	mov    0x5a0(%rdx),%rax
  77bd03:	mov    %r13,%rcx
  77bd06:	shl    $0x4,%rcx
  77bd0a:	movaps 0x950(%rsp),%xmm0
  77bd12:	movups %xmm0,(%rax,%rcx,1)
  77bd16:	inc    %r13
  77bd19:	mov    %r13,0x5a8(%rdx)
  77bd20:	cmp    0x30(%rsp),%rbx
  77bd25:	je     77c786 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x12a6>
  77bd2b:	mov    0x18(%rbx),%r12d
  77bd2f:	mov    $0xffffffff,%eax
  77bd34:	cmp    %rax,%r12
  77bd37:	je     77bd70 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x890>
  77bd39:	cmp    %r12,%r13
  77bd3c:	jbe    7804f7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5017>
  77bd42:	mov    0x40(%rsp),%rax
  77bd47:	mov    0x5a0(%rax),%rax
  77bd4e:	mov    %r12,%rcx
  77bd51:	shl    $0x4,%rcx
  77bd55:	movups (%rax,%rcx,1),%xmm0
  77bd59:	lea    0xc68(%rsp),%rax
  77bd61:	movups %xmm0,(%rax)
  77bd64:	mov    $0x1,%eax
  77bd69:	jmp    77bd72 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x892>
  77bd6b:	nopl   0x0(%rax,%rax,1)
  77bd70:	xor    %eax,%eax
  77bd72:	mov    %rax,0xc60(%rsp)
  77bd7a:	mov    0x20(%rbx),%eax
  77bd7d:	and    $0xf,%eax
  77bd80:	cmp    $0xa,%eax
  77bd83:	jae    7802ab <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4dcb>
  77bd89:	lea    -0x6a8c27(%rip),%rcx        # d3169 <GCC_except_table0+0x10dc9>
  77bd90:	movzbl (%rax,%rcx,1),%r15d
  77bd95:	mov    0x40(%rsp),%rcx
  77bd9a:	mov    0x200(%rcx),%rax
  77bda1:	movslq (%r14,%rax,4),%rax
  77bda5:	add    %r14,%rax
  77bda8:	jmp    *%rax
  77bdaa:	movups -0x6b7955(%rip),%xmm0        # c445c <GCC_except_table0+0x20bc>
  77bdb1:	movaps %xmm0,0x9b0(%rsp)
  77bdb9:	movups -0x6b7974(%rip),%xmm0        # c444c <GCC_except_table0+0x20ac>
  77bdc0:	movaps %xmm0,0x9a0(%rsp)
  77bdc8:	movups -0x6b7993(%rip),%xmm0        # c443c <GCC_except_table0+0x209c>
  77bdcf:	movaps %xmm0,0x990(%rsp)
  77bdd7:	movups -0x6b79b2(%rip),%xmm0        # c442c <GCC_except_table0+0x208c>
  77bdde:	movaps %xmm0,0x980(%rsp)
  77bde6:	movups -0x6b79d1(%rip),%xmm0        # c441c <GCC_except_table0+0x207c>
  77bded:	movaps %xmm0,0x970(%rsp)
  77bdf5:	movabs $0x3000100000000,%rax
  77bdff:	mov    %rax,0x9c0(%rsp)
  77be07:	cmp    $0xffffffff,%r12d
  77be0b:	jne    77bea1 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x9c1>
  77be11:	jmp    77bf58 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xa78>
  77be16:	mov    0x220(%rcx),%r13
  77be1d:	cmp    %r13,%rbp
  77be20:	jae    7804ad <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4fcd>
  77be26:	mov    0x210(%rcx),%r13
  77be2d:	mov    0x218(%rcx),%rax
  77be34:	movzbl (%rax,%rbp,1),%eax
  77be38:	cmp    %rax,%r13
  77be3b:	jbe    7804b9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4fd9>
  77be41:	mov    0x208(%rcx),%rcx
  77be48:	imul   $0x58,%rax,%rax
  77be4c:	mov    0x50(%rcx,%rax,1),%rdx
  77be51:	mov    %rdx,0x9c0(%rsp)
  77be59:	movups 0x40(%rcx,%rax,1),%xmm0
  77be5e:	movaps %xmm0,0x9b0(%rsp)
  77be66:	movups (%rcx,%rax,1),%xmm0
  77be6a:	movups 0x10(%rcx,%rax,1),%xmm1
  77be6f:	movups 0x20(%rcx,%rax,1),%xmm2
  77be74:	movupd 0x30(%rcx,%rax,1),%xmm3
  77be7a:	jmp    77bf2d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xa4d>
  77be7f:	mov    0x208(%rcx),%rsi
  77be86:	lea    0x970(%rsp),%rdi
  77be8e:	mov    %rbp,%rdx
  77be91:	call   *0x33d289(%rip)        # ab9120 <_DYNAMIC+0x3f0>
  77be97:	cmp    $0xffffffff,%r12d
  77be9b:	je     77bf58 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xa78>
  77bea1:	mov    0x40(%rsp),%rdx
  77bea6:	mov    0x200(%rdx),%rax
  77bead:	lea    -0x6b7db0(%rip),%rsi        # c4104 <GCC_except_table0+0x1d64>
  77beb4:	movslq (%rsi,%rax,4),%rcx
  77beb8:	add    %rsi,%rcx
  77bebb:	lea    -0x6b7aa6(%rip),%rax        # c441c <GCC_except_table0+0x207c>
  77bec2:	jmp    *%rcx
  77bec4:	mov    0x218(%rdx),%r13
  77becb:	cmp    %r12,%r13
  77bece:	jbe    7804a4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4fc4>
  77bed4:	imul   $0x58,%r12,%rax
  77bed8:	add    0x210(%rdx),%rax
  77bedf:	jmp    77bfae <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xace>
  77bee4:	mov    0x218(%rcx),%r13
  77beeb:	cmp    %r13,%rbp
  77beee:	jae    7804be <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4fde>
  77bef4:	mov    0x210(%rcx),%rax
  77befb:	imul   $0x58,%rbp,%rcx
  77beff:	mov    0x50(%rax,%rcx,1),%rdx
  77bf04:	mov    %rdx,0x9c0(%rsp)
  77bf0c:	movups 0x40(%rax,%rcx,1),%xmm0
  77bf11:	movaps %xmm0,0x9b0(%rsp)
  77bf19:	movups (%rax,%rcx,1),%xmm0
  77bf1d:	movups 0x10(%rax,%rcx,1),%xmm1
  77bf22:	movups 0x20(%rax,%rcx,1),%xmm2
  77bf27:	movupd 0x30(%rax,%rcx,1),%xmm3
  77bf2d:	movapd %xmm3,0x9a0(%rsp)
  77bf36:	movaps %xmm2,0x990(%rsp)
  77bf3e:	movaps %xmm1,0x980(%rsp)
  77bf46:	movaps %xmm0,0x970(%rsp)
  77bf4e:	cmp    $0xffffffff,%r12d
  77bf52:	jne    77bea1 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x9c1>
  77bf58:	mov    $0x2,%al
  77bf5a:	mov    0x40(%rsp),%rdx
  77bf5f:	mov    0x670(%rdx),%r8
  77bf66:	test   %r8,%r8
  77bf69:	jne    77c02e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xb4e>
  77bf6f:	jmp    77c0c0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xbe0>
  77bf74:	mov    0x220(%rdx),%r13
  77bf7b:	cmp    %r12,%r13
  77bf7e:	jbe    78049b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4fbb>
  77bf84:	mov    %rdx,%rcx
  77bf87:	mov    0x210(%rdx),%r13
  77bf8e:	mov    0x218(%rdx),%rax
  77bf95:	movzbl (%rax,%r12,1),%r12d
  77bf9a:	cmp    %r12,%r13
  77bf9d:	jbe    7804e8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5008>
  77bfa3:	imul   $0x58,%r12,%rax
  77bfa7:	add    0x208(%rcx),%rax
  77bfae:	mov    0x50(%rax),%rcx
  77bfb2:	mov    %rcx,0x3e0(%rsp)
  77bfba:	movups 0x40(%rax),%xmm0
  77bfbe:	movaps %xmm0,0x3d0(%rsp)
  77bfc6:	movups (%rax),%xmm0
  77bfc9:	movups 0x10(%rax),%xmm1
  77bfcd:	movups 0x20(%rax),%xmm2
  77bfd1:	movupd 0x30(%rax),%xmm3
  77bfd6:	movapd %xmm3,0x3c0(%rsp)
  77bfdf:	movaps %xmm2,0x3b0(%rsp)
  77bfe7:	movaps %xmm1,0x3a0(%rsp)
  77bfef:	movaps %xmm0,0x390(%rsp)
  77bff7:	jmp    77c011 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xb31>
  77bff9:	mov    0x208(%rdx),%rsi
  77c000:	lea    0x390(%rsp),%rdi
  77c008:	mov    %r12,%rdx
  77c00b:	call   *0x33d10f(%rip)        # ab9120 <_DYNAMIC+0x3f0>
  77c011:	movzbl 0x3e4(%rsp),%eax
  77c019:	mov    0x40(%rsp),%rdx
  77c01e:	mov    0x670(%rdx),%r8
  77c025:	test   %r8,%r8
  77c028:	je     77c0c0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xbe0>
  77c02e:	mov    (%rbx),%rcx
  77c031:	mov    0x678(%rdx),%rdx
  77c038:	movzwl 0x1c2(%r8),%edi
  77c040:	mov    %edi,%r10d
  77c043:	shl    $0x5,%r10d
  77c047:	mov    $0xffffffffffffffff,%rsi
  77c04e:	xor    %r9d,%r9d
  77c051:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  77c060:	mov    %r10,%r11
  77c063:	add    %r9,%r11
  77c066:	je     77c090 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xbb0>
  77c068:	cmp    0x170(%r8,%rsi,8),%rcx
  77c070:	seta   %r11b
  77c074:	sbb    $0x0,%r11b
  77c078:	add    $0xffffffffffffffe0,%r9
  77c07c:	inc    %rsi
  77c07f:	cmp    $0x1,%r11b
  77c083:	je     77c060 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xb80>
  77c085:	movzbl %r11b,%edi
  77c089:	test   %edi,%edi
  77c08b:	jne    77c093 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xbb3>
  77c08d:	jmp    77c0b0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xbd0>
  77c08f:	nop
  77c090:	mov    %rdi,%rsi
  77c093:	sub    $0x1,%rdx
  77c097:	jb     77c0c0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xbe0>
  77c099:	mov    0x1c8(%r8,%rsi,8),%r8
  77c0a1:	jmp    77c038 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xb58>
  77c0a3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  77c0b0:	sub    %r9,%r8
  77c0b3:	add    $0xffffffffffffffe0,%r8
  77c0b7:	jmp    77c0c3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xbe3>
  77c0b9:	nopl   0x0(%rax)
  77c0c0:	xor    %r8d,%r8d
  77c0c3:	movzbl %r15b,%esi
  77c0c7:	movzbl %al,%ecx
  77c0ca:	lea    0x390(%rsp),%rdi
  77c0d2:	lea    0x970(%rsp),%rdx
  77c0da:	call   *0x33d3f8(%rip)        # ab94d8 <_DYNAMIC+0x7a8>
  77c0e0:	lea    0x810(%rsp),%rdi
  77c0e8:	mov    0x58(%rsp),%rsi
  77c0ed:	lea    0xc60(%rsp),%rdx
  77c0f5:	xor    %ecx,%ecx
  77c0f7:	lea    0x390(%rsp),%r8
  77c0ff:	call   *0x33d3db(%rip)        # ab94e0 <_DYNAMIC+0x7b0>
  77c105:	cmpb   $0x0,0x810(%rsp)
  77c10d:	jne    77cc9d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17bd>
  77c113:	lea    0x818(%rsp),%rax
  77c11b:	movups (%rax),%xmm0
  77c11e:	lea    0x316(%rsp),%rax
  77c126:	movups %xmm0,(%rax)
  77c129:	movups (%rax),%xmm0
  77c12c:	movaps %xmm0,0x950(%rsp)
  77c134:	mov    0x20(%rbx),%ecx
  77c137:	mov    %ecx,%eax
  77c139:	and    $0xf,%eax
  77c13c:	cmp    $0x9,%eax
  77c13f:	ja     7802ab <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4dcb>
  77c145:	cmp    $0x6,%eax
  77c148:	je     77c15a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xc7a>
  77c14a:	cmp    $0x10,%ecx
  77c14d:	setae  %cl
  77c150:	cmp    $0x6,%eax
  77c153:	sete   %al
  77c156:	or     %cl,%al
  77c158:	je     77c18c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xcac>
  77c15a:	movaps 0x950(%rsp),%xmm0
  77c162:	movaps %xmm0,0x390(%rsp)
  77c16a:	mov    0x58(%rsp),%rdi
  77c16f:	lea    0x390(%rsp),%rsi
  77c177:	mov    0x33d36a(%rip),%rdx        # ab94e8 <_DYNAMIC+0x7b8>
  77c17e:	call   *0x33d36c(%rip)        # ab94f0 <_DYNAMIC+0x7c0>
  77c184:	test   $0x1,%al
  77c186:	jne    77cc8c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17ac>
  77c18c:	mov    0x40(%rsp),%rax
  77c191:	mov    0x5a8(%rax),%r13
  77c198:	cmp    0x598(%rax),%r13
  77c19f:	jne    77bcf0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x810>
  77c1a5:	mov    0x38(%rsp),%rdi
  77c1aa:	call   771c70 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecAINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtCslbxve4rcJus_4gpui6source7FieldIdEj2_E8grow_oneCs9C2G9YFESsD_29canonical_text_public_control>
  77c1af:	jmp    77bcf0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x810>
  77c1b4:	mov    0x688(%r13),%rax
  77c1bb:	mov    0x698(%r13),%rdi
  77c1c2:	test   %rax,%rax
  77c1c5:	setne  %cl
  77c1c8:	test   %rdi,%rdi
  77c1cb:	setne  %dl
  77c1ce:	and    %cl,%dl
  77c1d0:	cmp    $0x1,%dl
  77c1d3:	jne    77c786 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x12a6>
  77c1d9:	mov    0x40(%rsp),%rcx
  77c1de:	mov    0x690(%rcx),%rbx
  77c1e5:	add    $0x1e8,%rcx
  77c1ec:	mov    %rcx,0xc0(%rsp)
  77c1f4:	xor    %ebp,%ebp
  77c1f6:	lea    0x31e16b(%rip),%rcx        # a9a368 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1b90>
  77c1fd:	mov    %rcx,0x80(%rsp)
  77c205:	data16 cs nopw 0x0(%rax,%rax,1)
  77c210:	test   %rbp,%rbp
  77c213:	je     77c22f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xd4f>
  77c215:	mov    0x40(%rsp),%r14
  77c21a:	movzwl 0x62(%rbp),%ecx
  77c21e:	cmp    %rcx,%rbx
  77c221:	jae    77c2c0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xde0>
  77c227:	mov    %rbp,%r15
  77c22a:	jmp    77c2de <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xdfe>
  77c22f:	test   %rbx,%rbx
  77c232:	mov    0x40(%rsp),%r14
  77c237:	je     77c26a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xd8a>
  77c239:	mov    %rbx,%rcx
  77c23c:	mov    %rax,%rbp
  77c23f:	and    $0x7,%rcx
  77c243:	je     77c26f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xd8f>
  77c245:	xor    %edx,%edx
  77c247:	nopw   0x0(%rax,%rax,1)
  77c250:	mov    0x68(%rbp),%rbp
  77c254:	inc    %rdx
  77c257:	cmp    %rdx,%rcx
  77c25a:	jne    77c250 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xd70>
  77c25c:	mov    %rbx,%rax
  77c25f:	sub    %rdx,%rax
  77c262:	cmp    $0x8,%rbx
  77c266:	jae    77c280 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xda0>
  77c268:	jmp    77c2a6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xdc6>
  77c26a:	mov    %rax,%rbp
  77c26d:	jmp    77c2a6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xdc6>
  77c26f:	mov    %rbx,%rax
  77c272:	cmp    $0x8,%rbx
  77c276:	jb     77c2a6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xdc6>
  77c278:	nopl   0x0(%rax,%rax,1)
  77c280:	mov    0x68(%rbp),%rcx
  77c284:	mov    0x68(%rcx),%rcx
  77c288:	mov    0x68(%rcx),%rcx
  77c28c:	mov    0x68(%rcx),%rcx
  77c290:	mov    0x68(%rcx),%rcx
  77c294:	mov    0x68(%rcx),%rcx
  77c298:	mov    0x68(%rcx),%rcx
  77c29c:	mov    0x68(%rcx),%rbp
  77c2a0:	add    $0xfffffffffffffff8,%rax
  77c2a4:	jne    77c280 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xda0>
  77c2a6:	xor    %eax,%eax
  77c2a8:	xor    %ebx,%ebx
  77c2aa:	movzwl 0x62(%rbp),%ecx
  77c2ae:	cmp    %rcx,%rbx
  77c2b1:	jb     77c227 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xd47>
  77c2b7:	nopw   0x0(%rax,%rax,1)
  77c2c0:	mov    0x0(%rbp),%r15
  77c2c4:	test   %r15,%r15
  77c2c7:	je     78034b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4e6b>
  77c2cd:	inc    %rax
  77c2d0:	movzwl 0x60(%rbp),%ebx
  77c2d4:	mov    %r15,%rbp
  77c2d7:	cmp    0x62(%r15),%bx
  77c2dc:	jae    77c2c0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xde0>
  77c2de:	test   %rax,%rax
  77c2e1:	mov    %rdi,0x38(%rsp)
  77c2e6:	je     77c357 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xe77>
  77c2e8:	lea    (%r15,%rbx,8),%rcx
  77c2ec:	add    $0x70,%rcx
  77c2f0:	mov    %rax,%rdx
  77c2f3:	and    $0x7,%rdx
  77c2f7:	je     77c5a6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x10c6>
  77c2fd:	xor    %esi,%esi
  77c2ff:	nop
  77c300:	mov    (%rcx),%rbp
  77c303:	lea    0x68(%rbp),%rcx
  77c307:	inc    %rsi
  77c30a:	cmp    %rsi,%rdx
  77c30d:	jne    77c300 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xe20>
  77c30f:	mov    %rax,%rdx
  77c312:	sub    %rsi,%rdx
  77c315:	cmp    $0x8,%rax
  77c319:	jb     77c349 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xe69>
  77c31b:	nopl   0x0(%rax,%rax,1)
  77c320:	mov    (%rcx),%rax
  77c323:	mov    0x68(%rax),%rax
  77c327:	mov    0x68(%rax),%rax
  77c32b:	mov    0x68(%rax),%rax
  77c32f:	mov    0x68(%rax),%rax
  77c333:	mov    0x68(%rax),%rax
  77c337:	mov    0x68(%rax),%rax
  77c33b:	mov    0x68(%rax),%rbp
  77c33f:	lea    0x68(%rbp),%rcx
  77c343:	add    $0xfffffffffffffff8,%rdx
  77c347:	jne    77c320 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xe40>
  77c349:	movq   $0x0,0xa8(%rsp)
  77c355:	jmp    77c366 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xe86>
  77c357:	lea    0x1(%rbx),%rax
  77c35b:	mov    %rax,0xa8(%rsp)
  77c363:	mov    %r15,%rbp
  77c366:	mov    0x8(%r15,%rbx,8),%rsi
  77c36b:	mov    0xc0(%rsp),%rdi
  77c373:	call   775510 <_RNvMs_NtNtCslbxve4rcJus_4gpui7runtime14identity_indexNtB4_13IdentityIndex8required>
  77c378:	mov    %rax,%r12
  77c37b:	mov    0x5a8(%r14),%r13
  77c382:	cmp    %r13,%rax
  77c385:	jae    7804f7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5017>
  77c38b:	mov    0x5a0(%r14),%rax
  77c392:	mov    %r12,%rcx
  77c395:	shl    $0x4,%rcx
  77c399:	movups (%rax,%rcx,1),%xmm0
  77c39d:	movaps %xmm0,0x310(%rsp)
  77c3a5:	mov    0x2e0(%r14),%r13
  77c3ac:	cmp    %r13,%r12
  77c3af:	jae    780489 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4fa9>
  77c3b5:	mov    0x2d8(%r14),%rax
  77c3bc:	lea    (%r12,%r12,4),%rsi
  77c3c0:	mov    0x20(%rax,%rsi,8),%eax
  77c3c4:	and    $0xf,%eax
  77c3c7:	cmp    $0xa,%eax
  77c3ca:	jae    7802ab <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4dcb>
  77c3d0:	lea    -0x6a926e(%rip),%rcx        # d3169 <GCC_except_table0+0x10dc9>
  77c3d7:	movzbl (%rax,%rcx,1),%eax
  77c3db:	mov    %al,0x30(%rsp)
  77c3df:	mov    0x40(%rsp),%r14
  77c3e4:	mov    0x200(%r14),%rax
  77c3eb:	lea    -0x6b831e(%rip),%rcx        # c40d4 <GCC_except_table0+0x1d34>
  77c3f2:	movslq (%rcx,%rax,4),%rax
  77c3f6:	add    %rcx,%rax
  77c3f9:	jmp    *%rax
  77c3fb:	movups -0x6b7fa6(%rip),%xmm0        # c445c <GCC_except_table0+0x20bc>
  77c402:	movaps %xmm0,0x9b0(%rsp)
  77c40a:	movups -0x6b7fc5(%rip),%xmm0        # c444c <GCC_except_table0+0x20ac>
  77c411:	movaps %xmm0,0x9a0(%rsp)
  77c419:	movups -0x6b7fe4(%rip),%xmm0        # c443c <GCC_except_table0+0x209c>
  77c420:	movaps %xmm0,0x990(%rsp)
  77c428:	movups -0x6b8003(%rip),%xmm0        # c442c <GCC_except_table0+0x208c>
  77c42f:	movaps %xmm0,0x980(%rsp)
  77c437:	movups -0x6b8022(%rip),%xmm0        # c441c <GCC_except_table0+0x207c>
  77c43e:	movaps %xmm0,0x970(%rsp)
  77c446:	movabs $0x3000100000000,%rax
  77c450:	mov    %rax,0x9c0(%rsp)
  77c458:	jmp    77c525 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1045>
  77c45d:	mov    0x220(%r14),%rax
  77c464:	cmp    %rax,%r12
  77c467:	jae    7804d6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4ff6>
  77c46d:	mov    0x210(%r14),%rax
  77c474:	mov    0x218(%r14),%rcx
  77c47b:	movzbl (%rcx,%r12,1),%ecx
  77c480:	cmp    %rcx,%rax
  77c483:	jbe    7804e2 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5002>
  77c489:	mov    0x208(%r14),%rax
  77c490:	imul   $0x58,%rcx,%rcx
  77c494:	jmp    77c4d6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xff6>
  77c496:	mov    0x208(%r14),%rsi
  77c49d:	lea    0x970(%rsp),%rdi
  77c4a5:	mov    %r12,%rdx
  77c4a8:	call   *0x33cc72(%rip)        # ab9120 <_DYNAMIC+0x3f0>
  77c4ae:	mov    0x2e0(%r14),%r13
  77c4b5:	lea    (%r12,%r12,4),%rsi
  77c4b9:	jmp    77c525 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1045>
  77c4bb:	mov    0x218(%r14),%rax
  77c4c2:	cmp    %rax,%r12
  77c4c5:	jae    7804ca <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4fea>
  77c4cb:	mov    0x210(%r14),%rax
  77c4d2:	imul   $0x58,%r12,%rcx
  77c4d6:	mov    0x50(%rax,%rcx,1),%rdx
  77c4db:	mov    %rdx,0x9c0(%rsp)
  77c4e3:	movups 0x40(%rax,%rcx,1),%xmm0
  77c4e8:	movaps %xmm0,0x9b0(%rsp)
  77c4f0:	movups (%rax,%rcx,1),%xmm0
  77c4f4:	movups 0x10(%rax,%rcx,1),%xmm1
  77c4f9:	movups 0x20(%rax,%rcx,1),%xmm2
  77c4fe:	movupd 0x30(%rax,%rcx,1),%xmm3
  77c504:	movapd %xmm3,0x9a0(%rsp)
  77c50d:	movaps %xmm2,0x990(%rsp)
  77c515:	movaps %xmm1,0x980(%rsp)
  77c51d:	movaps %xmm0,0x970(%rsp)
  77c525:	cmp    %r13,%r12
  77c528:	jae    780492 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4fb2>
  77c52e:	mov    0x40(%rsp),%r13
  77c533:	mov    0x2d8(%r13),%rax
  77c53a:	mov    0x18(%rax,%rsi,8),%r12d
  77c53f:	mov    $0xffffffff,%eax
  77c544:	cmp    %rax,%r12
  77c547:	je     77c587 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x10a7>
  77c549:	mov    0x200(%r13),%rax
  77c550:	lea    -0x6b8473(%rip),%rdx        # c40e4 <GCC_except_table0+0x1d44>
  77c557:	movslq (%rdx,%rax,4),%rcx
  77c55b:	add    %rdx,%rcx
  77c55e:	lea    -0x6b8149(%rip),%rax        # c441c <GCC_except_table0+0x207c>
  77c565:	jmp    *%rcx
  77c567:	mov    %r13,%rcx
  77c56a:	mov    0x218(%r13),%r13
  77c571:	cmp    %r12,%r13
  77c574:	jbe    7804a4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4fc4>
  77c57a:	imul   $0x58,%r12,%rax
  77c57e:	add    0x210(%rcx),%rax
  77c585:	jmp    77c5f2 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1112>
  77c587:	mov    $0x2,%al
  77c589:	mov    0x670(%r13),%r8
  77c590:	test   %r8,%r8
  77c593:	jne    77c670 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1190>
  77c599:	xor    %r8d,%r8d
  77c59c:	movzbl 0x30(%rsp),%ebx
  77c5a1:	jmp    77c6f7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1217>
  77c5a6:	mov    %rax,%rdx
  77c5a9:	cmp    $0x8,%rax
  77c5ad:	jae    77c320 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xe40>
  77c5b3:	jmp    77c349 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xe69>
  77c5b8:	mov    %r13,%rcx
  77c5bb:	mov    0x220(%r13),%r13
  77c5c2:	cmp    %r12,%r13
  77c5c5:	jbe    78049b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4fbb>
  77c5cb:	mov    0x210(%rcx),%r13
  77c5d2:	mov    0x218(%rcx),%rax
  77c5d9:	movzbl (%rax,%r12,1),%r12d
  77c5de:	cmp    %r12,%r13
  77c5e1:	jbe    7804e8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5008>
  77c5e7:	imul   $0x58,%r12,%rax
  77c5eb:	add    0x208(%rcx),%rax
  77c5f2:	mov    %rcx,%r13
  77c5f5:	mov    0x50(%rax),%rcx
  77c5f9:	mov    %rcx,0x3e0(%rsp)
  77c601:	movups 0x40(%rax),%xmm0
  77c605:	movaps %xmm0,0x3d0(%rsp)
  77c60d:	movups (%rax),%xmm0
  77c610:	movups 0x10(%rax),%xmm1
  77c614:	movups 0x20(%rax),%xmm2
  77c618:	movupd 0x30(%rax),%xmm3
  77c61d:	movapd %xmm3,0x3c0(%rsp)
  77c626:	movaps %xmm2,0x3b0(%rsp)
  77c62e:	movaps %xmm1,0x3a0(%rsp)
  77c636:	movaps %xmm0,0x390(%rsp)
  77c63e:	jmp    77c658 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1178>
  77c640:	mov    0x208(%r13),%rsi
  77c647:	lea    0x390(%rsp),%rdi
  77c64f:	mov    %r12,%rdx
  77c652:	call   *0x33cac8(%rip)        # ab9120 <_DYNAMIC+0x3f0>
  77c658:	movzbl 0x3e4(%rsp),%eax
  77c660:	mov    0x670(%r13),%r8
  77c667:	test   %r8,%r8
  77c66a:	je     77c599 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x10b9>
  77c670:	mov    0x8(%r15,%rbx,8),%rcx
  77c675:	mov    0x678(%r13),%rdx
  77c67c:	movzbl 0x30(%rsp),%ebx
  77c681:	movzwl 0x1c2(%r8),%edi
  77c689:	mov    %edi,%r10d
  77c68c:	shl    $0x5,%r10d
  77c690:	mov    $0xffffffffffffffff,%rsi
  77c697:	xor    %r9d,%r9d
  77c69a:	nopw   0x0(%rax,%rax,1)
  77c6a0:	mov    %r10,%r11
  77c6a3:	add    %r9,%r11
  77c6a6:	je     77c6d0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x11f0>
  77c6a8:	cmp    0x170(%r8,%rsi,8),%rcx
  77c6b0:	seta   %r11b
  77c6b4:	sbb    $0x0,%r11b
  77c6b8:	add    $0xffffffffffffffe0,%r9
  77c6bc:	inc    %rsi
  77c6bf:	cmp    $0x1,%r11b
  77c6c3:	je     77c6a0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x11c0>
  77c6c5:	movzbl %r11b,%edi
  77c6c9:	test   %edi,%edi
  77c6cb:	jne    77c6d3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x11f3>
  77c6cd:	jmp    77c6f0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1210>
  77c6cf:	nop
  77c6d0:	mov    %rdi,%rsi
  77c6d3:	sub    $0x1,%rdx
  77c6d7:	jb     77c77e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x129e>
  77c6dd:	mov    0x1c8(%r8,%rsi,8),%r8
  77c6e5:	jmp    77c681 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x11a1>
  77c6e7:	nopw   0x0(%rax,%rax,1)
  77c6f0:	sub    %r9,%r8
  77c6f3:	add    $0xffffffffffffffe0,%r8
  77c6f7:	movzbl %bl,%esi
  77c6fa:	movzbl %al,%ecx
  77c6fd:	lea    0x390(%rsp),%rdi
  77c705:	lea    0x970(%rsp),%rdx
  77c70d:	call   *0x33cdc5(%rip)        # ab94d8 <_DYNAMIC+0x7a8>
  77c713:	movaps 0x310(%rsp),%xmm0
  77c71b:	movaps %xmm0,0x810(%rsp)
  77c723:	mov    0x58(%rsp),%rdi
  77c728:	lea    0x810(%rsp),%rsi
  77c730:	lea    0x390(%rsp),%rdx
  77c738:	call   *0x33cdba(%rip)        # ab94f8 <_DYNAMIC+0x7c8>
  77c73e:	test   $0x1,%al
  77c740:	jne    77cc8c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17ac>
  77c746:	mov    0x58(%rsp),%rdi
  77c74b:	lea    0x310(%rsp),%rsi
  77c753:	call   *0x33ccf7(%rip)        # ab9450 <_DYNAMIC+0x720>
  77c759:	cmp    $0xff,%al
  77c75b:	jne    77cca5 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17c5>
  77c761:	mov    $0x0,%eax
  77c766:	mov    0x38(%rsp),%rdi
  77c76b:	dec    %rdi
  77c76e:	mov    0xa8(%rsp),%rbx
  77c776:	jne    77c210 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xd30>
  77c77c:	jmp    77c786 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x12a6>
  77c77e:	xor    %r8d,%r8d
  77c781:	jmp    77c6f7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1217>
  77c786:	mov    0x40(%rsp),%r15
  77c78b:	lea    0x2e8(%r15),%rax
  77c792:	mov    0x558(%r15),%r14
  77c799:	mov    0x578(%r15),%rbx
  77c7a0:	lea    0x598(%r15),%rcx
  77c7a7:	movq   $0xfffffffffffffffe,0x7c8(%rsp)
  77c7b3:	lea    0x2d0(%r15),%rdx
  77c7ba:	lea    0x200(%r15),%rsi
  77c7c1:	lea    0x600(%r15),%r13
  77c7c8:	mov    %rcx,0xbe8(%rsp)
  77c7d0:	mov    %rdx,0xbf0(%rsp)
  77c7d8:	mov    %r13,0xbf8(%rsp)
  77c7e0:	lea    0x1c0(%rsp),%rcx
  77c7e8:	mov    %rcx,0xc00(%rsp)
  77c7f0:	mov    %rax,0xc08(%rsp)
  77c7f8:	mov    %rsi,0xa8(%rsp)
  77c800:	mov    %rsi,0xc10(%rsp)
  77c808:	lea    0x7c8(%rsp),%rax
  77c810:	mov    %rax,0xc18(%rsp)
  77c818:	cmpq   $0x0,0x5a8(%r15)
  77c820:	je     780510 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5030>
  77c826:	mov    0x5a0(%r15),%rax
  77c82d:	movups (%rax),%xmm0
  77c830:	movaps %xmm0,0x970(%rsp)
  77c838:	xorps  %xmm0,%xmm0
  77c83b:	cvtsi2ssl 0xf8(%rsp),%xmm0
  77c844:	movaps %xmm0,0xc0(%rsp)
  77c84c:	cvtsi2ssl 0x2e0(%rsp),%xmm1
  77c855:	movss  0x9c(%rsp),%xmm2
  77c85e:	divss  %xmm2,%xmm0
  77c862:	movaps %xmm1,0x80(%rsp)
  77c86a:	divss  %xmm2,%xmm1
  77c86e:	movl   $0x0,0x390(%rsp)
  77c879:	movss  %xmm0,0x394(%rsp)
  77c882:	movl   $0x0,0x398(%rsp)
  77c88d:	movss  %xmm1,0x39c(%rsp)
  77c896:	mov    $0x1,%r12b
  77c899:	lea    0x31db40(%rip),%r8        # a9a3e0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1c08>
  77c8a0:	lea    0x970(%rsp),%rsi
  77c8a8:	lea    0x390(%rsp),%rdx
  77c8b0:	lea    0xbe8(%rsp),%rcx
  77c8b8:	mov    $0x1,%bpl
  77c8bb:	mov    0x58(%rsp),%rdi
  77c8c0:	call   *0x33cc3a(%rip)        # ab9500 <_DYNAMIC+0x7d0>
  77c8c6:	test   $0x1,%al
  77c8c8:	je     77c930 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1450>
  77c8ca:	mov    0x48(%rsp),%rax
  77c8cf:	movq   $0x22,(%rax)
  77c8d6:	mov    %dl,0x8(%rax)
  77c8d9:	mov    0x7c8(%rsp),%rax
  77c8e1:	mov    $0x1,%r12b
  77c8e4:	mov    $0x1,%bpl
  77c8e7:	cmp    $0xfffffffffffffffe,%rax
  77c8eb:	je     77ccba <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17da>
  77c8f1:	sub    $0xd,%rax
  77c8f5:	mov    $0x14,%ecx
  77c8fa:	cmovge %rax,%rcx
  77c8fe:	cmp    $0x14,%rcx
  77c902:	je     77cd6c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x188c>
  77c908:	cmp    $0x19,%rcx
  77c90c:	jne    77ccba <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17da>
  77c912:	mov    0x7d0(%rsp),%rsi
  77c91a:	test   %rsi,%rsi
  77c91d:	je     77ccba <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17da>
  77c923:	lea    0x7d8(%rsp),%rax
  77c92b:	jmp    77cd85 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x18a5>
  77c930:	mov    0x558(%r15),%rax
  77c937:	sub    %r14,%rax
  77c93a:	mov    0x578(%r15),%rcx
  77c941:	add    %rax,0x728(%r15)
  77c948:	sub    %rbx,%rcx
  77c94b:	add    %rcx,0x730(%r15)
  77c952:	cmpl   $0xfffffffe,0x7c8(%rsp)
  77c95a:	jne    77cc56 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1776>
  77c960:	lea    0x390(%rsp),%rdi
  77c968:	mov    $0x1,%bpl
  77c96b:	mov    %r15,%rsi
  77c96e:	mov    $0x1,%edx
  77c973:	call   770790 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime9inspectorINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE17refresh_inspectorB10_>
  77c978:	cmpl   $0xfffffffe,0x390(%rsp)
  77c980:	jne    77cd33 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1853>
  77c986:	mov    0x2e0(%r15),%rsi
  77c98d:	lea    0x390(%rsp),%rdi
  77c995:	mov    $0x8,%ecx
  77c99a:	mov    $0x40,%r8d
  77c9a0:	xor    %edx,%edx
  77c9a2:	call   7722d0 <_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCs9C2G9YFESsD_29canonical_text_public_control>
  77c9a7:	mov    0x398(%rsp),%rdi
  77c9af:	cmpl   $0x1,0x390(%rsp)
  77c9b7:	je     78037d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4e9d>
  77c9bd:	mov    0x3a0(%rsp),%rax
  77c9c5:	mov    %rdi,0x140(%rsp)
  77c9cd:	mov    %rax,0x148(%rsp)
  77c9d5:	movq   $0x0,0x150(%rsp)
  77c9e1:	movq   $0x0,0x268(%rsp)
  77c9ed:	movq   $0x4,0x270(%rsp)
  77c9f9:	movq   $0x0,0x278(%rsp)
  77ca05:	mov    0x2e0(%r15),%rsi
  77ca0c:	lea    0x390(%rsp),%rdi
  77ca14:	mov    $0x8,%ecx
  77ca19:	mov    $0x38,%r8d
  77ca1f:	xor    %edx,%edx
  77ca21:	call   7722d0 <_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCs9C2G9YFESsD_29canonical_text_public_control>
  77ca26:	mov    0x398(%rsp),%rdi
  77ca2e:	cmpb   $0x0,0x390(%rsp)
  77ca36:	jne    780393 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4eb3>
  77ca3c:	mov    0x3a0(%rsp),%rax
  77ca44:	mov    %rdi,0x1d8(%rsp)
  77ca4c:	mov    %rax,0x1e0(%rsp)
  77ca54:	movq   $0x0,0x1e8(%rsp)
  77ca60:	mov    0x668(%r15),%rbx
  77ca67:	test   %rbx,%rbx
  77ca6a:	setne  0x2f(%rsp)
  77ca6f:	je     77ca78 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1598>
  77ca71:	mov    0x2e0(%r15),%rbx
  77ca78:	lea    0x390(%rsp),%rdi
  77ca80:	mov    $0x4,%ecx
  77ca85:	mov    $0x10,%r8d
  77ca8b:	mov    %rbx,%rsi
  77ca8e:	xor    %edx,%edx
  77ca90:	call   7722d0 <_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCs9C2G9YFESsD_29canonical_text_public_control>
  77ca95:	mov    0x398(%rsp),%rdi
  77ca9d:	cmpb   $0x0,0x390(%rsp)
  77caa5:	jne    7803a6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4ec6>
  77caab:	mov    0x3a0(%rsp),%rax
  77cab3:	mov    %rdi,0x218(%rsp)
  77cabb:	mov    %rax,0x220(%rsp)
  77cac3:	movq   $0x0,0x228(%rsp)
  77cacf:	lea    0x390(%rsp),%rdi
  77cad7:	mov    $0x4,%ecx
  77cadc:	mov    $0x10,%r8d
  77cae2:	mov    %rbx,%rsi
  77cae5:	xor    %edx,%edx
  77cae7:	call   7722d0 <_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCs9C2G9YFESsD_29canonical_text_public_control>
  77caec:	mov    0x398(%rsp),%rdi
  77caf4:	cmpb   $0x0,0x390(%rsp)
  77cafc:	jne    7803b9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4ed9>
  77cb02:	mov    0x3a0(%rsp),%rax
  77cb0a:	mov    %rdi,0x230(%rsp)
  77cb12:	mov    %rax,0x238(%rsp)
  77cb1a:	movq   $0x0,0x240(%rsp)
  77cb26:	lea    0x390(%rsp),%rdi
  77cb2e:	mov    $0x1,%ecx
  77cb33:	mov    $0x1,%r8d
  77cb39:	mov    %rbx,%rsi
  77cb3c:	xor    %edx,%edx
  77cb3e:	call   7722d0 <_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCs9C2G9YFESsD_29canonical_text_public_control>
  77cb43:	mov    0x398(%rsp),%rdi
  77cb4b:	cmpb   $0x0,0x390(%rsp)
  77cb53:	jne    7803cc <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4eec>
  77cb59:	mov    0x3a0(%rsp),%rax
  77cb61:	mov    %rdi,0x158(%rsp)
  77cb69:	mov    %rax,0x160(%rsp)
  77cb71:	movq   $0x0,0x168(%rsp)
  77cb7d:	lea    0x390(%rsp),%rdi
  77cb85:	mov    $0x4,%ecx
  77cb8a:	mov    $0x4,%r8d
  77cb90:	mov    %rbx,%rsi
  77cb93:	xor    %edx,%edx
  77cb95:	call   7722d0 <_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCs9C2G9YFESsD_29canonical_text_public_control>
  77cb9a:	mov    0x398(%rsp),%rdi
  77cba2:	cmpb   $0x0,0x390(%rsp)
  77cbaa:	jne    7803df <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4eff>
  77cbb0:	mov    %r13,0x2d8(%rsp)
  77cbb8:	mov    0x3a0(%rsp),%rax
  77cbc0:	mov    %rdi,0x100(%rsp)
  77cbc8:	mov    %rax,0x108(%rsp)
  77cbd0:	movq   $0x0,0x110(%rsp)
  77cbdc:	movq   $0x0,0x6a8(%rsp)
  77cbe8:	movq   $0x0,0x6b8(%rsp)
  77cbf4:	mov    0x650(%r15),%rcx
  77cbfb:	test   %rcx,%rcx
  77cbfe:	je     77cd98 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x18b8>
  77cc04:	mov    0x2e0(%r15),%rsi
  77cc0b:	mov    0x680(%r15),%rdx
  77cc12:	mov    $0x1,%r12b
  77cc15:	lea    0x810(%rsp),%rdi
  77cc1d:	mov    $0x1,%r13b
  77cc20:	mov    $0x1,%bpl
  77cc23:	call   75cc10 <_RNCNvMs1_NtNtCslbxve4rcJus_4gpui7runtime8metadataINtB9_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE14metadata_sheet0B11_>
  77cc28:	jmp    77cda4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x18c4>
  77cc2d:	mov    0x48(%rsp),%rax
  77cc32:	movq   $0x23,(%rax)
  77cc39:	mov    %r14d,0x8(%rax)
  77cc3d:	mov    %ebp,0xc(%rax)
  77cc40:	mov    0xca0(%rsp),%rbx
  77cc48:	cmp    $0x2,%ebx
  77cc4b:	jne    77cd14 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1834>
  77cc51:	jmp    77cd21 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1841>
  77cc56:	mov    0x7f8(%rsp),%rax
  77cc5e:	mov    0x48(%rsp),%rcx
  77cc63:	mov    %rax,0x30(%rcx)
  77cc67:	movups 0x7c8(%rsp),%xmm0
  77cc6f:	movups 0x7d8(%rsp),%xmm1
  77cc77:	movups 0x7e8(%rsp),%xmm2
  77cc7f:	movups %xmm2,0x20(%rcx)
  77cc83:	movups %xmm1,0x10(%rcx)
  77cc87:	movups %xmm0,(%rcx)
  77cc8a:	jmp    77ccb4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17d4>
  77cc8c:	mov    0x48(%rsp),%rax
  77cc91:	movq   $0x22,(%rax)
  77cc98:	mov    %dl,0x8(%rax)
  77cc9b:	jmp    77ccb4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17d4>
  77cc9d:	movzbl 0x811(%rsp),%eax
  77cca5:	mov    0x48(%rsp),%rcx
  77ccaa:	movq   $0x22,(%rcx)
  77ccb1:	mov    %al,0x8(%rcx)
  77ccb4:	mov    $0x1,%r12b
  77ccb7:	mov    $0x1,%bpl
  77ccba:	cmpq   $0x0,0x1c0(%rsp)
  77ccc3:	je     77ccd2 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17f2>
  77ccc5:	mov    0x1c8(%rsp),%rdi
  77cccd:	call   74caf0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text10TextShaperECs9C2G9YFESsD_29canonical_text_public_control>
  77ccd2:	test   %r12b,%r12b
  77ccd5:	je     77cce4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1804>
  77ccd7:	lea    0x200(%rsp),%rdi
  77ccdf:	call   7476c0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime13text_geometry5EntryEECs9C2G9YFESsD_29canonical_text_public_control>
  77cce4:	mov    0xd0(%rsp),%rax
  77ccec:	test   %rax,%rax
  77ccef:	je     77cd05 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1825>
  77ccf1:	lock decq (%rax)
  77ccf5:	jne    77cd05 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1825>
  77ccf7:	lea    0xd0(%rsp),%rdi
  77ccff:	call   *0x33c35b(%rip)        # ab9060 <_DYNAMIC+0x330>
  77cd05:	cmpl   $0x2,0xca0(%rsp)
  77cd0d:	je     77cd21 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1841>
  77cd0f:	test   %bpl,%bpl
  77cd12:	je     77cd21 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1841>
  77cd14:	lea    0xca0(%rsp),%rdi
  77cd1c:	call   74d090 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas6canvas6CanvasECs9C2G9YFESsD_29canonical_text_public_control>
  77cd21:	add    $0xe88,%rsp
  77cd28:	pop    %rbx
  77cd29:	pop    %r12
  77cd2b:	pop    %r13
  77cd2d:	pop    %r14
  77cd2f:	pop    %r15
  77cd31:	pop    %rbp
  77cd32:	ret
  77cd33:	mov    0x3c0(%rsp),%rax
  77cd3b:	mov    0x48(%rsp),%rcx
  77cd40:	mov    %rax,0x30(%rcx)
  77cd44:	movups 0x390(%rsp),%xmm0
  77cd4c:	movups 0x3a0(%rsp),%xmm1
  77cd54:	movups 0x3b0(%rsp),%xmm2
  77cd5c:	movups %xmm2,0x20(%rcx)
  77cd60:	movups %xmm1,0x10(%rcx)
  77cd64:	movups %xmm0,(%rcx)
  77cd67:	jmp    77c8d9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x13f9>
  77cd6c:	mov    0x7e0(%rsp),%rsi
  77cd74:	test   %rsi,%rsi
  77cd77:	je     77ccba <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17da>
  77cd7d:	lea    0x7e8(%rsp),%rax
  77cd85:	mov    (%rax),%rdi
  77cd88:	mov    $0x1,%edx
  77cd8d:	call   *0x33c1dd(%rip)        # ab8f70 <_DYNAMIC+0x240>
  77cd93:	jmp    77ccba <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17da>
  77cd98:	movq   $0xffffffffffffffff,0x810(%rsp)
  77cda4:	mov    0x2d8(%rsp),%rax
  77cdac:	mov    (%rax),%rsi
  77cdaf:	test   %rsi,%rsi
  77cdb2:	je     77ce80 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x19a0>
  77cdb8:	mov    $0x1,%r12b
  77cdbb:	lea    0x390(%rsp),%rdi
  77cdc3:	mov    $0x1,%bl
  77cdc5:	mov    $0x1,%r15b
  77cdc8:	mov    $0x1,%bpl
  77cdcb:	call   *0x33c737(%rip)        # ab9508 <_DYNAMIC+0x7d8>
  77cdd1:	mov    0xf8(%rsp),%r13
  77cdd9:	mov    0x390(%rsp),%rax
  77cde1:	mov    0x398(%rsp),%rsi
  77cde9:	movups 0x3a0(%rsp),%xmm0
  77cdf1:	movaps %xmm0,0x310(%rsp)
  77cdf9:	movups 0x3b0(%rsp),%xmm1
  77ce01:	movaps %xmm1,0x970(%rsp)
  77ce09:	mov    0x3c0(%rsp),%rcx
  77ce11:	mov    %rcx,0x980(%rsp)
  77ce19:	movaps %xmm0,0x790(%rsp)
  77ce21:	cmp    $0xfffffffffffffffe,%rax
  77ce25:	mov    0x40(%rsp),%r12
  77ce2a:	je     77ce94 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x19b4>
  77ce2c:	mov    0x980(%rsp),%rcx
  77ce34:	mov    0x48(%rsp),%rdx
  77ce39:	mov    %rcx,0x30(%rdx)
  77ce3d:	movaps 0x970(%rsp),%xmm0
  77ce45:	movups %xmm0,0x20(%rdx)
  77ce49:	movaps 0x790(%rsp),%xmm0
  77ce51:	movaps %xmm0,0x180(%rsp)
  77ce59:	movups %xmm0,0x10(%rdx)
  77ce5d:	mov    %rax,(%rdx)
  77ce60:	mov    %rsi,0x8(%rdx)
  77ce64:	mov    $0x1,%r12b
  77ce67:	cmpl   $0xffffffff,0x810(%rsp)
  77ce6f:	mov    $0x1,%r13b
  77ce72:	mov    $0x1,%bpl
  77ce75:	jne    780194 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4cb4>
  77ce7b:	jmp    7801a1 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4cc1>
  77ce80:	mov    $0xffffffffffffffff,%rsi
  77ce87:	mov    0x40(%rsp),%r12
  77ce8c:	mov    0xf8(%rsp),%r13
  77ce94:	movaps 0x790(%rsp),%xmm0
  77ce9c:	movups %xmm0,0x8c0(%rsp)
  77cea4:	mov    %rsi,0x258(%rsp)
  77ceac:	mov    %rsi,0x8b8(%rsp)
  77ceb4:	cmpb   $0x0,0x2f(%rsp)
  77ceb9:	je     77cf53 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1a73>
  77cebf:	lea    0x390(%rsp),%rdi
  77cec7:	lea    0x1d8(%rsp),%rdx
  77cecf:	lea    0x100(%rsp),%rcx
  77ced7:	mov    %r12,%rsi
  77ceda:	call   74fb80 <_RINvNtNtCslbxve4rcJus_4gpui7runtime6scroll8geometryNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEBP_>
  77cedf:	mov    0x390(%rsp),%rax
  77cee7:	movups 0x398(%rsp),%xmm0
  77ceef:	movaps %xmm0,0x970(%rsp)
  77cef7:	movups 0x3a8(%rsp),%xmm0
  77ceff:	movaps %xmm0,0x980(%rsp)
  77cf07:	movups 0x3b8(%rsp),%xmm0
  77cf0f:	movaps %xmm0,0x990(%rsp)
  77cf17:	cmp    $0xfffffffffffffffe,%rax
  77cf1b:	jne    77f22e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3d4e>
  77cf21:	movaps 0x970(%rsp),%xmm0
  77cf29:	movaps 0x980(%rsp),%xmm1
  77cf31:	movaps 0x990(%rsp),%xmm2
  77cf39:	movaps %xmm2,0x6e0(%rsp)
  77cf41:	movaps %xmm1,0x6d0(%rsp)
  77cf49:	movaps %xmm0,0x6c0(%rsp)
  77cf51:	jmp    77cf8e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1aae>
  77cf53:	movq   $0x0,0x6c0(%rsp)
  77cf5f:	movq   $0x8,0x6c8(%rsp)
  77cf6b:	xorps  %xmm0,%xmm0
  77cf6e:	movups %xmm0,0x6d0(%rsp)
  77cf76:	movq   $0x8,0x6e0(%rsp)
  77cf82:	movq   $0x0,0x6e8(%rsp)
  77cf8e:	mov    0x6a8(%r12),%r15
  77cf96:	mov    0x6b0(%r12),%r14
  77cf9e:	mov    0x6c0(%r12),%rbx
  77cfa6:	lea    0xc78(%rsp),%rdi
  77cfae:	mov    %r12,%rsi
  77cfb1:	call   7705d0 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime9inspectorINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE17inspector_displayB10_>
  77cfb6:	lea    0x650(%r12),%rax
  77cfbe:	mov    %rax,0xf0(%rsp)
  77cfc6:	mov    (%rax),%rax
  77cfc9:	test   %rax,%rax
  77cfcc:	je     77cfea <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1b0a>
  77cfce:	mov    0x100(%rax),%rsi
  77cfd5:	test   %rsi,%rsi
  77cfd8:	je     77cfea <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1b0a>
  77cfda:	lea    0xb98(%rsp),%rdi
  77cfe2:	call   *0x33bff0(%rip)        # ab8fd8 <_DYNAMIC+0x2a8>
  77cfe8:	jmp    77d001 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1b21>
  77cfea:	movq   $0x4,0xb98(%rsp)
  77cff6:	xorps  %xmm0,%xmm0
  77cff9:	movups %xmm0,0xba0(%rsp)
  77d001:	mov    0x6b8(%r12),%rax
  77d009:	test   %rax,%rax
  77d00c:	je     77d040 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1b60>
  77d00e:	mov    %r14,0x18(%rax)
  77d012:	mov    %r15,0x20(%rax)
  77d016:	mov    %rbx,0x28(%rax)
  77d01a:	movq   $0x0,0x10(%rax)
  77d022:	movw   $0x100,0x58(%rax)
  77d028:	test   %r14,%r14
  77d02b:	setne  %dl
  77d02e:	cmp    %r13,%rbx
  77d031:	sete   %cl
  77d034:	and    %dl,%cl
  77d036:	mov    %rax,0x688(%rsp)
  77d03e:	jmp    77d042 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1b62>
  77d040:	mov    $0x2,%cl
  77d042:	mov    %cl,0x690(%rsp)
  77d049:	mov    0xa8(%rsp),%rdi
  77d051:	call   *0x33c4b9(%rip)        # ab9510 <_DYNAMIC+0x7e0>
  77d057:	movzbl 0xc78(%rsp),%eax
  77d05f:	movq   $0xffffffffffffffff,0x670(%rsp)
  77d06b:	mov    %al,0x7f(%rsp)
  77d06f:	test   %al,%al
  77d071:	je     77d083 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1ba3>
  77d073:	mov    0xc80(%rsp),%rax
  77d07b:	mov    %rax,0x670(%rsp)
  77d083:	cmpl   $0x2,0xca0(%rsp)
  77d08b:	lea    0xca0(%rsp),%rsi
  77d093:	cmove  %r12,%rsi
  77d097:	lea    0x970(%rsp),%rdi
  77d09f:	call   *0x33c473(%rip)        # ab9518 <_DYNAMIC+0x7e8>
  77d0a5:	movups -0x6ba9ec(%rip),%xmm0        # c26c0 <GCC_except_table0+0x320>
  77d0ac:	movaps %xmm0,0x390(%rsp)
  77d0b4:	lea    0x970(%rsp),%rdi
  77d0bc:	lea    0x390(%rsp),%rsi
  77d0c4:	call   *0x33c456(%rip)        # ab9520 <_DYNAMIC+0x7f0>
  77d0ca:	incq   0x740(%r12)
  77d0d2:	mov    0x2e0(%r12),%rax
  77d0da:	mov    %rax,0x660(%rsp)
  77d0e2:	test   %rax,%rax
  77d0e5:	je     77f10b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3c2b>
  77d0eb:	movss  0x9c(%rsp),%xmm0
  77d0f4:	cvtss2sd %xmm0,%xmm0
  77d0f8:	movsd  %xmm0,0x890(%rsp)
  77d101:	movaps 0xc0(%rsp),%xmm0
  77d109:	unpcklps 0x80(%rsp),%xmm0
  77d111:	movaps %xmm0,0x800(%rsp)
  77d119:	lea    0x31d300(%rip),%rax        # a9a420 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1c48>
  77d120:	mov    %rax,0x658(%rsp)
  77d128:	movabs $0x8000000000000000,%rax
  77d132:	inc    %rax
  77d135:	mov    %rax,0x888(%rsp)
  77d13d:	lea    0x31d2f4(%rip),%rax        # a9a438 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1c60>
  77d144:	mov    %rax,0xa0(%rsp)
  77d14c:	lea    0x180(%rsp),%r15
  77d154:	lea    0x31bfd5(%rip),%rax        # a99130 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x958>
  77d15b:	mov    %rax,0x650(%rsp)
  77d163:	lea    0x31c0e6(%rip),%rax        # a99250 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xa78>
  77d16a:	mov    %rax,0x648(%rsp)
  77d172:	lea    0x31d34f(%rip),%rax        # a9a4c8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1cf0>
  77d179:	mov    %rax,0x248(%rsp)
  77d181:	lea    -0x6aa819(%rip),%rax        # d296f <GCC_except_table0+0x105cf>
  77d188:	mov    %rax,0x250(%rsp)
  77d190:	xor    %ecx,%ecx
  77d192:	lea    0x0(,%rcx,8),%rax
  77d19a:	lea    (%rax,%rax,4),%r13
  77d19e:	imul   $0x58,%rcx,%rax
  77d1a2:	mov    %rax,0x668(%rsp)
  77d1aa:	mov    %rcx,%rsi
  77d1ad:	shl    $0x4,%rsi
  77d1b1:	mov    %rcx,%rdx
  77d1b4:	jmp    77d1e5 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1d05>
  77d1b6:	add    $0x28,%r13
  77d1ba:	addq   $0x58,0x668(%rsp)
  77d1c3:	mov    0x8a8(%rsp),%rsi
  77d1cb:	add    $0x10,%rsi
  77d1cf:	mov    0x8a0(%rsp),%rdx
  77d1d7:	cmp    0x660(%rsp),%rdx
  77d1df:	jae    77f10b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3c2b>
  77d1e5:	cmp    %rdx,0x670(%rsp)
  77d1ed:	mov    %rdx,0x38(%rsp)
  77d1f2:	jne    77d278 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1d98>
  77d1f8:	cmpb   $0x0,0x7f(%rsp)
  77d1fd:	je     780338 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4e58>
  77d203:	mov    %rsi,%rbx
  77d206:	mov    0x148(%rsp),%rdx
  77d20e:	mov    0x150(%rsp),%rcx
  77d216:	mov    0x270(%rsp),%r8
  77d21e:	mov    0x278(%rsp),%r9
  77d226:	mov    0x40(%rsp),%rax
  77d22b:	movups 0x2f0(%rax),%xmm0
  77d232:	movups 0x5a0(%rax),%xmm1
  77d239:	movups %xmm1,0x18(%rsp)
  77d23e:	mov    0x58(%rsp),%rax
  77d243:	mov    %rax,0x10(%rsp)
  77d248:	movups %xmm0,(%rsp)
  77d24c:	lea    0x390(%rsp),%rdi
  77d254:	lea    0xc80(%rsp),%rsi
  77d25c:	call   *0x33c2c6(%rip)        # ab9528 <_DYNAMIC+0x7f8>
  77d262:	cmpl   $0xfffffffe,0x390(%rsp)
  77d26a:	jne    77ff60 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4a80>
  77d270:	mov    0x38(%rsp),%rdx
  77d275:	mov    %rbx,%rsi
  77d278:	mov    0x40(%rsp),%rcx
  77d27d:	mov    0x5a8(%rcx),%rax
  77d284:	cmp    %rax,%rdx
  77d287:	jae    780630 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5150>
  77d28d:	mov    0x5a0(%rcx),%rax
  77d294:	mov    %rsi,0x8a8(%rsp)
  77d29c:	movups (%rax,%rsi,1),%xmm0
  77d2a0:	movaps %xmm0,0x310(%rsp)
  77d2a8:	lea    0x390(%rsp),%rdi
  77d2b0:	mov    0x58(%rsp),%rsi
  77d2b5:	lea    0x310(%rsp),%rdx
  77d2bd:	call   *0x33be4d(%rip)        # ab9110 <_DYNAMIC+0x3e0>
  77d2c3:	cmpb   $0x0,0x390(%rsp)
  77d2cb:	jne    77feae <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x49ce>
  77d2d1:	mov    0x38(%rsp),%rdx
  77d2d6:	lea    0x1(%rdx),%rcx
  77d2da:	mov    0x40(%rsp),%rax
  77d2df:	mov    0x2e0(%rax),%rsi
  77d2e6:	mov    %rcx,0x8a0(%rsp)
  77d2ee:	cmp    %rsi,%rcx
  77d2f1:	jae    77d31b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1e3b>
  77d2f3:	mov    0x2d8(%rax),%rax
  77d2fa:	mov    0x40(%rax,%r13,1),%eax
  77d2ff:	mov    $0xffffffff,%ecx
  77d304:	cmp    %rcx,%rax
  77d307:	setne  %cl
  77d30a:	cmp    %rax,%rdx
  77d30d:	sete   %al
  77d310:	and    %cl,%al
  77d312:	mov    %eax,0x1d4(%rsp)
  77d319:	jmp    77d326 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1e46>
  77d31b:	movl   $0x0,0x1d4(%rsp)
  77d326:	movsd  0x3d4(%rsp),%xmm0
  77d32f:	movaps %xmm0,0x940(%rsp)
  77d337:	movsd  0x3dc(%rsp),%xmm0
  77d340:	movaps %xmm0,0x630(%rsp)
  77d348:	movups 0x3a4(%rsp),%xmm0
  77d350:	movaps %xmm0,0x930(%rsp)
  77d358:	movss  0x3a8(%rsp),%xmm0
  77d361:	movss  %xmm0,0x30c(%rsp)
  77d36a:	movups 0x3b4(%rsp),%xmm0
  77d372:	movaps %xmm0,0x2c0(%rsp)
  77d37a:	movss  0x3bc(%rsp),%xmm0
  77d383:	movaps %xmm0,0x910(%rsp)
  77d38b:	movss  0x3b8(%rsp),%xmm0
  77d394:	movss  %xmm0,0x308(%rsp)
  77d39d:	movsd  0x3e4(%rsp),%xmm0
  77d3a6:	movaps %xmm0,0x920(%rsp)
  77d3ae:	mov    0xa8(%rsp),%rax
  77d3b6:	mov    (%rax),%rax
  77d3b9:	lea    -0x6b92ac(%rip),%rcx        # c4114 <GCC_except_table0+0x1d74>
  77d3c0:	movslq (%rcx,%rax,4),%rax
  77d3c4:	add    %rcx,%rax
  77d3c7:	jmp    *%rax
  77d3c9:	movups -0x6b8f74(%rip),%xmm0        # c445c <GCC_except_table0+0x20bc>
  77d3d0:	movaps %xmm0,0x350(%rsp)
  77d3d8:	movups -0x6b8f93(%rip),%xmm0        # c444c <GCC_except_table0+0x20ac>
  77d3df:	movaps %xmm0,0x340(%rsp)
  77d3e7:	movups -0x6b8fb2(%rip),%xmm0        # c443c <GCC_except_table0+0x209c>
  77d3ee:	movaps %xmm0,0x330(%rsp)
  77d3f6:	movups -0x6b8fd1(%rip),%xmm0        # c442c <GCC_except_table0+0x208c>
  77d3fd:	movaps %xmm0,0x320(%rsp)
  77d405:	movups -0x6b8ff0(%rip),%xmm0        # c441c <GCC_except_table0+0x207c>
  77d40c:	movaps %xmm0,0x310(%rsp)
  77d414:	movabs $0x3000100000000,%rax
  77d41e:	mov    %rax,0x360(%rsp)
  77d426:	jmp    77d540 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2060>
  77d42b:	mov    0x40(%rsp),%rdx
  77d430:	mov    0x220(%rdx),%rax
  77d437:	mov    0x38(%rsp),%rdi
  77d43c:	cmp    %rax,%rdi
  77d43f:	jae    7805fc <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x511c>
  77d445:	mov    0x210(%rdx),%rax
  77d44c:	mov    0x218(%rdx),%rcx
  77d453:	movzbl (%rcx,%rdi,1),%ecx
  77d457:	cmp    %rcx,%rax
  77d45a:	jbe    780605 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5125>
  77d460:	mov    0x208(%rdx),%rax
  77d467:	imul   $0x58,%rcx,%rcx
  77d46b:	mov    0x50(%rax,%rcx,1),%rdx
  77d470:	mov    %rdx,0x360(%rsp)
  77d478:	movups 0x40(%rax,%rcx,1),%xmm0
  77d47d:	movaps %xmm0,0x350(%rsp)
  77d485:	movups (%rax,%rcx,1),%xmm0
  77d489:	movups 0x10(%rax,%rcx,1),%xmm1
  77d48e:	movups 0x20(%rax,%rcx,1),%xmm2
  77d493:	movupd 0x30(%rax,%rcx,1),%xmm3
  77d499:	jmp    77d51f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x203f>
  77d49e:	mov    0x40(%rsp),%rax
  77d4a3:	mov    0x208(%rax),%rsi
  77d4aa:	lea    0x310(%rsp),%rdi
  77d4b2:	mov    0x38(%rsp),%rdx
  77d4b7:	call   *0x33bc63(%rip)        # ab9120 <_DYNAMIC+0x3f0>
  77d4bd:	mov    0x40(%rsp),%rax
  77d4c2:	mov    0x2e0(%rax),%rsi
  77d4c9:	jmp    77d540 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2060>
  77d4cb:	mov    0x40(%rsp),%rcx
  77d4d0:	mov    0x218(%rcx),%rax
  77d4d7:	cmp    %rax,0x38(%rsp)
  77d4dc:	jae    780613 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5133>
  77d4e2:	mov    0x210(%rcx),%rax
  77d4e9:	mov    0x668(%rsp),%rdx
  77d4f1:	mov    0x50(%rax,%rdx,1),%rcx
  77d4f6:	mov    %rcx,0x360(%rsp)
  77d4fe:	movups 0x40(%rax,%rdx,1),%xmm0
  77d503:	movaps %xmm0,0x350(%rsp)
  77d50b:	movups (%rax,%rdx,1),%xmm0
  77d50f:	movups 0x10(%rax,%rdx,1),%xmm1
  77d514:	movups 0x20(%rax,%rdx,1),%xmm2
  77d519:	movupd 0x30(%rax,%rdx,1),%xmm3
  77d51f:	movapd %xmm3,0x340(%rsp)
  77d528:	movaps %xmm2,0x330(%rsp)
  77d530:	movaps %xmm1,0x320(%rsp)
  77d538:	movaps %xmm0,0x310(%rsp)
  77d540:	cmp    %rsi,0x38(%rsp)
  77d545:	jae    78056d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x508d>
  77d54b:	mov    0x40(%rsp),%rax
  77d550:	mov    0x2d8(%rax),%rdi
  77d557:	mov    0x18(%rdi,%r13,1),%edx
  77d55c:	mov    $0xffffffff,%eax
  77d561:	cmp    %rax,%rdx
  77d564:	je     77d580 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x20a0>
  77d566:	call   75e080 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_>
  77d56b:	mov    %eax,0xbc(%rsp)
  77d572:	mov    0x40(%rsp),%rax
  77d577:	mov    0x2e0(%rax),%rsi
  77d57e:	jmp    77d58b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x20ab>
  77d580:	movl   $0x0,0xbc(%rsp)
  77d58b:	cmp    %rsi,0x38(%rsp)
  77d590:	jae    78057c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x509c>
  77d596:	mov    0x40(%rsp),%rax
  77d59b:	mov    0x2d8(%rax),%rax
  77d5a2:	mov    0x18(%rax,%r13,1),%ebx
  77d5a7:	mov    $0xffffffff,%ecx
  77d5ac:	cmp    %rcx,%rbx
  77d5af:	je     77d5ca <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x20ea>
  77d5b1:	cmp    %rbx,%rsi
  77d5b4:	jbe    78059a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x50ba>
  77d5ba:	lea    (%rbx,%rbx,4),%rcx
  77d5be:	mov    (%rax,%rcx,8),%rcx
  77d5c2:	mov    %rcx,0x898(%rsp)
  77d5ca:	mov    0xf0(%rsp),%rcx
  77d5d2:	mov    (%rcx),%rcx
  77d5d5:	xorps  %xmm0,%xmm0
  77d5d8:	movss  %xmm0,0x74(%rsp)
  77d5de:	test   %rcx,%rcx
  77d5e1:	je     77d60b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x212b>
  77d5e3:	mov    0x100(%rcx),%rdi
  77d5ea:	test   %rdi,%rdi
  77d5ed:	je     77d60b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x212b>
  77d5ef:	mov    (%rax,%r13,1),%rsi
  77d5f3:	call   *0x33be8f(%rip)        # ab9488 <_DYNAMIC+0x758>
  77d5f9:	movss  %xmm0,0x74(%rsp)
  77d5ff:	mov    0x40(%rsp),%rax
  77d604:	mov    0x2e0(%rax),%rsi
  77d60b:	cmp    %rsi,0x38(%rsp)
  77d610:	jae    78058b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x50ab>
  77d616:	mov    0x40(%rsp),%rax
  77d61b:	mov    0x2d8(%rax),%rax
  77d622:	mov    %rax,0x30(%rsp)
  77d627:	mov    0x18(%rax,%r13,1),%ecx
  77d62c:	mov    $0xffffffff,%eax
  77d631:	cmp    %rax,%rcx
  77d634:	je     77d750 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2270>
  77d63a:	mov    0x1e8(%rsp),%rax
  77d642:	cmp    %rcx,%rax
  77d645:	jbe    7805ab <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x50cb>
  77d64b:	imul   $0x38,%rcx,%rax
  77d64f:	mov    0x1e0(%rsp),%rcx
  77d657:	movups (%rcx,%rax,1),%xmm0
  77d65b:	movaps %xmm0,0x60(%rsp)
  77d660:	movups 0x10(%rcx,%rax,1),%xmm0
  77d665:	movaps %xmm0,0xe0(%rsp)
  77d66d:	movups 0x20(%rcx,%rax,1),%xmm0
  77d672:	movaps %xmm0,0x280(%rsp)
  77d67a:	movzbl 0x30(%rcx,%rax,1),%ebp
  77d67f:	mov    0x31(%rcx,%rax,1),%edx
  77d683:	mov    %edx,0x180(%rsp)
  77d68a:	mov    0x34(%rcx,%rax,1),%eax
  77d68e:	mov    %eax,0x183(%rsp)
  77d695:	cmp    $0xffffffff,%ebx
  77d698:	je     780329 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4e49>
  77d69e:	lea    0x390(%rsp),%rdi
  77d6a6:	lea    0x6c0(%rsp),%rsi
  77d6ae:	mov    0x898(%rsp),%rdx
  77d6b6:	call   *0x33be74(%rip)        # ab9530 <_DYNAMIC+0x800>
  77d6bc:	cmpl   $0x1,0x390(%rsp)
  77d6c4:	jne    77d784 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x22a4>
  77d6ca:	movq   0x398(%rsp),%xmm0
  77d6d3:	movq   0x3a0(%rsp),%xmm1
  77d6dc:	movq   %xmm0,%rax
  77d6e1:	movq   %xmm1,%rcx
  77d6e6:	movabs $0x7fffffffffffffff,%rdx
  77d6f0:	and    %rdx,%rax
  77d6f3:	movabs $0x7fefffffffffffff,%rsi
  77d6fd:	cmp    %rsi,%rax
  77d700:	setg   %al
  77d703:	and    %rdx,%rcx
  77d706:	cmp    %rsi,%rcx
  77d709:	setg   %cl
  77d70c:	or     %al,%cl
  77d70e:	or     %bpl,%cl
  77d711:	and    $0x1,%cl
  77d714:	punpcklqdq %xmm1,%xmm1
  77d718:	pxor   -0x6b9ef0(%rip),%xmm1        # c3830 <GCC_except_table0+0x1490>
  77d720:	movapd 0xe0(%rsp),%xmm3
  77d729:	mulpd  %xmm3,%xmm1
  77d72d:	punpcklqdq %xmm0,%xmm0
  77d731:	movapd 0x60(%rsp),%xmm2
  77d737:	mulpd  %xmm2,%xmm0
  77d73b:	subpd  %xmm0,%xmm1
  77d73f:	movapd 0x280(%rsp),%xmm0
  77d748:	addpd  %xmm1,%xmm0
  77d74c:	mov    %ecx,%ebp
  77d74e:	jmp    77d7b7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x22d7>
  77d750:	movsd  0x890(%rsp),%xmm0
  77d759:	movsd  %xmm0,0x790(%rsp)
  77d762:	lea    0x7c1(%rsp),%rax
  77d76a:	xorps  %xmm1,%xmm1
  77d76d:	movups %xmm1,-0x29(%rax)
  77d771:	movsd  %xmm0,0x7a8(%rsp)
  77d77a:	movaps %xmm1,-0x11(%rax)
  77d77e:	movb   $0x0,-0x1(%rax)
  77d782:	jmp    77d7da <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x22fa>
  77d784:	mov    0x180(%rsp),%eax
  77d78b:	mov    0x183(%rsp),%ecx
  77d792:	lea    0x7c1(%rsp),%rdx
  77d79a:	mov    %ecx,0x3(%rdx)
  77d79d:	mov    %eax,(%rdx)
  77d79f:	movapd 0x60(%rsp),%xmm2
  77d7a5:	movapd 0xe0(%rsp),%xmm3
  77d7ae:	movapd 0x280(%rsp),%xmm0
  77d7b7:	movapd %xmm2,0x790(%rsp)
  77d7c0:	movapd %xmm3,0x7a0(%rsp)
  77d7c9:	movapd %xmm0,0x7b0(%rsp)
  77d7d2:	mov    %bpl,0x7c0(%rsp)
  77d7da:	movaps -0x6b9ca1(%rip),%xmm0        # c3b40 <GCC_except_table0+0x17a0>
  77d7e1:	movaps %xmm0,0x180(%rsp)
  77d7e9:	movaps 0x940(%rsp),%xmm0
  77d7f1:	movlps %xmm0,0x190(%rsp)
  77d7f9:	lea    0x390(%rsp),%rdi
  77d801:	lea    0x790(%rsp),%rsi
  77d809:	mov    %r15,%rdx
  77d80c:	call   *0x33b906(%rip)        # ab9118 <_DYNAMIC+0x3e8>
  77d812:	lea    0xbb0(%rsp),%rdi
  77d81a:	lea    0x390(%rsp),%rsi
  77d822:	lea    0x34c(%rsp),%rdx
  77d82a:	call   *0x33b8e8(%rip)        # ab9118 <_DYNAMIC+0x3e8>
  77d830:	mov    0x1e8(%rsp),%rbx
  77d838:	cmp    0x1d8(%rsp),%rbx
  77d840:	jne    77d84f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x236f>
  77d842:	lea    0x1d8(%rsp),%rdi
  77d84a:	call   771dc0 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtCscO85OU7Wpt0_20gpui_reactivity_core8geometry15CoordinateSpaceE8grow_oneCs9C2G9YFESsD_29canonical_text_public_control>
  77d84f:	mov    0x1e0(%rsp),%rax
  77d857:	imul   $0x38,%rbx,%rcx
  77d85b:	mov    0xbe0(%rsp),%rdx
  77d863:	mov    %rdx,0x30(%rax,%rcx,1)
  77d868:	movups 0xbb0(%rsp),%xmm0
  77d870:	movups 0xbc0(%rsp),%xmm1
  77d878:	movups 0xbd0(%rsp),%xmm2
  77d880:	movups %xmm2,0x20(%rax,%rcx,1)
  77d885:	movups %xmm1,0x10(%rax,%rcx,1)
  77d88a:	movups %xmm0,(%rax,%rcx,1)
  77d88e:	inc    %rbx
  77d891:	mov    %rbx,0x1e8(%rsp)
  77d899:	movups 0xbb0(%rsp),%xmm0
  77d8a1:	movaps %xmm0,0xe0(%rsp)
  77d8a9:	movups 0xbc0(%rsp),%xmm0
  77d8b1:	movaps %xmm0,0x280(%rsp)
  77d8b9:	movups 0xbd0(%rsp),%xmm0
  77d8c1:	movaps %xmm0,0x60(%rsp)
  77d8c6:	lea    0xbb0(%rsp),%rdi
  77d8ce:	call   *0x33bc64(%rip)        # ab9538 <_DYNAMIC+0x808>
  77d8d4:	xor    %ebx,%ebx
  77d8d6:	test   %al,%al
  77d8d8:	je     77da03 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2523>
  77d8de:	cvtpd2ps 0x280(%rsp),%xmm0
  77d8e7:	cvtpd2ps 0xe0(%rsp),%xmm1
  77d8f0:	cvtpd2ps 0x60(%rsp),%xmm2
  77d8f6:	unpcklpd %xmm0,%xmm1
  77d8fa:	movd   %xmm1,%eax
  77d8fe:	and    $0x7fffffff,%eax
  77d903:	movapd %xmm1,%xmm0
  77d907:	shufps $0x55,%xmm1,%xmm0
  77d90b:	movd   %xmm0,%ecx
  77d90f:	and    $0x7fffffff,%ecx
  77d915:	cmp    $0x7f800000,%ecx
  77d91b:	setge  %cl
  77d91e:	movdqa %xmm1,%xmm0
  77d922:	punpckhqdq %xmm1,%xmm0
  77d926:	movd   %xmm0,%edx
  77d92a:	and    $0x7fffffff,%edx
  77d930:	cmp    $0x7f800000,%edx
  77d936:	setge  %dl
  77d939:	movaps %xmm1,%xmm0
  77d93c:	shufps $0xff,%xmm1,%xmm0
  77d940:	movd   %xmm0,%esi
  77d944:	and    $0x7fffffff,%esi
  77d94a:	cmp    $0x7f800000,%esi
  77d950:	setge  %sil
  77d954:	movd   %xmm2,%edi
  77d958:	and    $0x7fffffff,%edi
  77d95e:	cmp    $0x7f800000,%edi
  77d964:	setge  %dil
  77d968:	movapd %xmm2,%xmm0
  77d96c:	shufps $0x55,%xmm2,%xmm0
  77d970:	movd   %xmm0,%r8d
  77d975:	and    $0x7fffffff,%r8d
  77d97c:	cmp    $0x7f800000,%r8d
  77d983:	setl   %r8b
  77d987:	cmp    $0x7f7fffff,%eax
  77d98c:	mov    0x30(%rsp),%r9
  77d991:	jg     77da08 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2528>
  77d993:	test   %cl,%cl
  77d995:	jne    77da08 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2528>
  77d997:	test   %dl,%dl
  77d999:	jne    77da08 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2528>
  77d99b:	test   %sil,%sil
  77d99e:	jne    77da08 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2528>
  77d9a0:	test   %dil,%dil
  77d9a3:	jne    77da08 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2528>
  77d9a5:	test   %r8b,%r8b
  77d9a8:	je     77da08 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2528>
  77d9aa:	movaps %xmm1,0x60(%rsp)
  77d9af:	movaps %xmm1,0x390(%rsp)
  77d9b7:	movaps %xmm2,0xe0(%rsp)
  77d9bf:	movlpd %xmm2,0x3a0(%rsp)
  77d9c8:	lea    0x390(%rsp),%rdi
  77d9d0:	call   *0x33bb6a(%rip)        # ab9540 <_DYNAMIC+0x810>
  77d9d6:	test   %al,%al
  77d9d8:	mov    0x30(%rsp),%r9
  77d9dd:	je     77da08 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2528>
  77d9df:	movaps 0x60(%rsp),%xmm0
  77d9e4:	movups %xmm0,0x2a8(%rsp)
  77d9ec:	movaps 0xe0(%rsp),%xmm0
  77d9f4:	movlps %xmm0,0x2b8(%rsp)
  77d9fc:	mov    $0x1,%ebx
  77da01:	jmp    77da08 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2528>
  77da03:	mov    0x30(%rsp),%r9
  77da08:	mov    %ebx,0x2a4(%rsp)
  77da0f:	xorps  %xmm0,%xmm0
  77da12:	unpcklpd 0x630(%rsp),%xmm0
  77da1b:	movups %xmm0,0x698(%rsp)
  77da23:	cmpb   $0x0,0x2f(%rsp)
  77da28:	je     77dac8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x25e8>
  77da2e:	mov    0x18(%r9,%r13,1),%edx
  77da33:	mov    $0xffffffff,%eax
  77da38:	cmp    %rax,%rdx
  77da3b:	je     77db0e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x262e>
  77da41:	mov    0x228(%rsp),%rax
  77da49:	cmp    %rdx,%rax
  77da4c:	jbe    7805b9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x50d9>
  77da52:	mov    0x220(%rsp),%rax
  77da5a:	mov    %rdx,%rcx
  77da5d:	shl    $0x4,%rcx
  77da61:	movsd  (%rax,%rcx,1),%xmm1
  77da66:	movsd  0x8(%rax,%rcx,1),%xmm2
  77da6c:	movq   $0x0,0x390(%rsp)
  77da78:	movaps 0xc0(%rsp),%xmm0
  77da80:	movss  %xmm0,0x398(%rsp)
  77da89:	movaps 0x80(%rsp),%xmm0
  77da91:	movss  %xmm0,0x39c(%rsp)
  77da9a:	mov    0x240(%rsp),%rax
  77daa2:	cmp    %rdx,%rax
  77daa5:	jbe    7805c7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x50e7>
  77daab:	movaps %xmm2,0x280(%rsp)
  77dab3:	movaps %xmm1,0xe0(%rsp)
  77dabb:	add    0x238(%rsp),%rcx
  77dac3:	jmp    77db5f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x267f>
  77dac8:	movq   $0x0,0x1b0(%rsp)
  77dad4:	movaps 0xc0(%rsp),%xmm0
  77dadc:	movss  %xmm0,0x1b8(%rsp)
  77dae5:	movaps 0x80(%rsp),%xmm0
  77daed:	movss  %xmm0,0x1bc(%rsp)
  77daf6:	xorps  %xmm0,%xmm0
  77daf9:	movl   $0x0,0x60(%rsp)
  77db01:	movaps 0x800(%rsp),%xmm1
  77db09:	jmp    77dbe6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2706>
  77db0e:	movq   $0x0,0x390(%rsp)
  77db1a:	movaps 0xc0(%rsp),%xmm0
  77db22:	movss  %xmm0,0x398(%rsp)
  77db2b:	movaps 0x80(%rsp),%xmm0
  77db33:	movss  %xmm0,0x39c(%rsp)
  77db3c:	xorps  %xmm0,%xmm0
  77db3f:	movaps %xmm0,0xe0(%rsp)
  77db47:	lea    0x390(%rsp),%rcx
  77db4f:	movaps 0x800(%rsp),%xmm0
  77db57:	movaps %xmm0,0x280(%rsp)
  77db5f:	movups (%rcx),%xmm0
  77db62:	movaps %xmm0,0x1b0(%rsp)
  77db6a:	mov    0x20(%r9,%r13,1),%edi
  77db6f:	call   7759f0 <_RNvMsh_NtCslbxve4rcJus_4gpui7runtimeNtB5_4Node4kind>
  77db74:	mov    $0x1,%cl
  77db76:	mov    %ecx,0x60(%rsp)
  77db7a:	cmp    $0x7,%al
  77db7c:	jne    77db95 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x26b5>
  77db7e:	mov    0x30(%rsp),%r9
  77db83:	movaps 0xe0(%rsp),%xmm0
  77db8b:	movaps 0x280(%rsp),%xmm1
  77db93:	jmp    77dbe6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2706>
  77db95:	mov    0x30(%rsp),%r9
  77db9a:	mov    0x18(%r9,%r13,1),%ecx
  77db9f:	mov    $0xffffffff,%eax
  77dba4:	cmp    %rax,%rcx
  77dba7:	movaps 0xe0(%rsp),%xmm0
  77dbaf:	movaps 0x280(%rsp),%xmm1
  77dbb7:	je     77dbde <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x26fe>
  77dbb9:	mov    0x168(%rsp),%rax
  77dbc1:	cmp    %rcx,%rax
  77dbc4:	jbe    78061c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x513c>
  77dbca:	mov    0x160(%rsp),%rax
  77dbd2:	movzbl (%rax,%rcx,1),%eax
  77dbd6:	and    $0x1,%al
  77dbd8:	mov    %eax,0x60(%rsp)
  77dbdc:	jmp    77dbe6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2706>
  77dbde:	movl   $0x0,0x60(%rsp)
  77dbe6:	movlhps %xmm1,%xmm0
  77dbe9:	movups %xmm0,0x170(%rsp)
  77dbf1:	mov    0x20(%r9,%r13,1),%eax
  77dbf6:	and    $0xf,%eax
  77dbf9:	cmp    $0x7,%eax
  77dbfc:	jb     77dc0a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x272a>
  77dbfe:	lea    -0x8(%rax),%ecx
  77dc01:	cmp    $0x2,%ecx
  77dc04:	jae    77e764 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3284>
  77dc0a:	mov    0x18(%r9,%r13,1),%ecx
  77dc0f:	xor    %r12d,%r12d
  77dc12:	mov    $0xffffffff,%edx
  77dc17:	cmp    %rdx,%rcx
  77dc1a:	je     77dc3a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x275a>
  77dc1c:	cmp    %rcx,0x168(%rsp)
  77dc24:	jbe    77dc3a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x275a>
  77dc26:	mov    0x160(%rsp),%rdx
  77dc2e:	movzbl (%rdx,%rcx,1),%r12d
  77dc33:	and    $0x2,%r12b
  77dc37:	shr    $1,%r12b
  77dc3a:	cmpb   $0x0,0x2f(%rsp)
  77dc3f:	je     77dc8d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x27ad>
  77dc41:	mov    0x168(%rsp),%r14
  77dc49:	cmp    0x158(%rsp),%r14
  77dc51:	jne    77dc61 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2781>
  77dc53:	lea    0x158(%rsp),%rdi
  77dc5b:	call   *0x33b8e7(%rip)        # ab9548 <_DYNAMIC+0x818>
  77dc61:	lea    (%r12,%r12,1),%eax
  77dc65:	add    0x60(%rsp),%al
  77dc69:	mov    0x160(%rsp),%rcx
  77dc71:	mov    %al,(%rcx,%r14,1)
  77dc75:	inc    %r14
  77dc78:	mov    %r14,0x168(%rsp)
  77dc80:	mov    0x30(%rsp),%rax
  77dc85:	mov    0x20(%rax,%r13,1),%eax
  77dc8a:	and    $0xf,%eax
  77dc8d:	cmp    $0x9,%eax
  77dc90:	ja     780412 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4f32>
  77dc96:	mov    $0x34f,%ecx
  77dc9b:	bt     %eax,%ecx
  77dc9e:	jb     77dd1e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x283e>
  77dca0:	movups 0x170(%rsp),%xmm0
  77dca8:	movaps %xmm0,0x180(%rsp)
  77dcb0:	movups 0x698(%rsp),%xmm0
  77dcb8:	movaps %xmm0,0x390(%rsp)
  77dcc0:	lea    0x8d0(%rsp),%rdi
  77dcc8:	mov    %r15,%rsi
  77dccb:	lea    0x1b0(%rsp),%rdx
  77dcd3:	lea    0x2a4(%rsp),%rcx
  77dcdb:	lea    0x390(%rsp),%r8
  77dce3:	mov    0xf8(%rsp),%r9
  77dceb:	call   *0x33b85f(%rip)        # ab9550 <_DYNAMIC+0x820>
  77dcf1:	cmpl   $0xfffffffe,0x8d0(%rsp)
  77dcf9:	jne    77ff99 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4ab9>
  77dcff:	lea    0x8d8(%rsp),%rax
  77dd07:	movups (%rax),%xmm0
  77dd0a:	movaps %xmm0,0x170(%rsp)
  77dd12:	movups 0x10(%rax),%xmm0
  77dd16:	movaps %xmm0,0x1b0(%rsp)
  77dd1e:	cmpb   $0x0,0x2f(%rsp)
  77dd23:	je     77ddc3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x28e3>
  77dd29:	movaps 0x170(%rsp),%xmm0
  77dd31:	movaps %xmm0,0x390(%rsp)
  77dd39:	mov    0x228(%rsp),%r14
  77dd41:	cmp    0x218(%rsp),%r14
  77dd49:	jne    77dd58 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2878>
  77dd4b:	lea    0x218(%rsp),%rdi
  77dd53:	call   771e30 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtCscO85OU7Wpt0_20gpui_reactivity_core8geometry4RectE8grow_oneCs9C2G9YFESsD_29canonical_text_public_control>
  77dd58:	mov    0x220(%rsp),%rax
  77dd60:	mov    %r14,%rcx
  77dd63:	shl    $0x4,%rcx
  77dd67:	movaps 0x390(%rsp),%xmm0
  77dd6f:	movups %xmm0,(%rax,%rcx,1)
  77dd73:	inc    %r14
  77dd76:	mov    %r14,0x228(%rsp)
  77dd7e:	mov    0x240(%rsp),%r14
  77dd86:	cmp    0x230(%rsp),%r14
  77dd8e:	jne    77dd9d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x28bd>
  77dd90:	lea    0x230(%rsp),%rdi
  77dd98:	call   771e30 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtCscO85OU7Wpt0_20gpui_reactivity_core8geometry4RectE8grow_oneCs9C2G9YFESsD_29canonical_text_public_control>
  77dd9d:	mov    0x238(%rsp),%rax
  77dda5:	mov    %r14,%rcx
  77dda8:	shl    $0x4,%rcx
  77ddac:	movaps 0x1b0(%rsp),%xmm0
  77ddb4:	movups %xmm0,(%rax,%rcx,1)
  77ddb8:	inc    %r14
  77ddbb:	mov    %r14,0x240(%rsp)
  77ddc3:	test   %ebx,%ebx
  77ddc5:	je     77ddfb <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x291b>
  77ddc7:	lea    0x390(%rsp),%rdi
  77ddcf:	lea    0x698(%rsp),%rsi
  77ddd7:	lea    0x2a8(%rsp),%rdx
  77dddf:	call   75e1a0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerso_0BQ_>
  77dde4:	cmpl   $0x1,0x390(%rsp)
  77ddec:	jne    77ddfb <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x291b>
  77ddee:	lea    0x394(%rsp),%rax
  77ddf6:	movups (%rax),%xmm0
  77ddf9:	jmp    77ddfe <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x291e>
  77ddfb:	xorps  %xmm0,%xmm0
  77ddfe:	movaps %xmm0,0x6f0(%rsp)
  77de06:	mov    0x60(%rsp),%eax
  77de0a:	or     %r12b,%al
  77de0d:	cmp    $0x1,%al
  77de0f:	je     77de24 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2944>
  77de11:	mov    0x30(%rsp),%rax
  77de16:	mov    0x20(%rax,%r13,1),%edi
  77de1b:	call   7759f0 <_RNvMsh_NtCslbxve4rcJus_4gpui7runtimeNtB5_4Node4kind>
  77de20:	cmp    $0x6,%al
  77de22:	jne    77de44 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2964>
  77de24:	lea    0x290(%rsp),%rdi
  77de2c:	lea    0x6f0(%rsp),%rsi
  77de34:	lea    0x1b0(%rsp),%rdx
  77de3c:	call   *0x33b716(%rip)        # ab9558 <_DYNAMIC+0x828>
  77de42:	jmp    77deb1 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x29d1>
  77de44:	movsd  0x6f0(%rsp),%xmm0
  77de4d:	movsd  0x6f8(%rsp),%xmm1
  77de56:	movaps %xmm0,%xmm2
  77de59:	addps  %xmm0,%xmm1
  77de5c:	xorps  %xmm4,%xmm4
  77de5f:	maxps  %xmm4,%xmm0
  77de62:	movaps %xmm0,%xmm3
  77de65:	cmpunordps %xmm0,%xmm3
  77de69:	andps  %xmm3,%xmm2
  77de6c:	andnps %xmm0,%xmm3
  77de6f:	orps   %xmm2,%xmm3
  77de72:	movaps %xmm1,%xmm0
  77de75:	minps  0x800(%rsp),%xmm0
  77de7d:	movaps %xmm0,%xmm2
  77de80:	cmpunordps %xmm0,%xmm2
  77de84:	andps  %xmm2,%xmm1
  77de87:	andnps %xmm0,%xmm2
  77de8a:	orps   %xmm1,%xmm2
  77de8d:	subps  %xmm3,%xmm2
  77de90:	movaps %xmm2,%xmm0
  77de93:	maxps  %xmm4,%xmm0
  77de96:	movaps %xmm0,%xmm1
  77de99:	cmpunordps %xmm0,%xmm1
  77de9d:	andps  %xmm1,%xmm2
  77dea0:	andnps %xmm0,%xmm1
  77dea3:	orps   %xmm2,%xmm1
  77dea6:	movlhps %xmm1,%xmm3
  77dea9:	movups %xmm3,0x290(%rsp)
  77deb1:	test   %r12b,%r12b
  77deb4:	mov    0x30(%rsp),%rsi
  77deb9:	je     77dee8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2a08>
  77debb:	movss  0x298(%rsp),%xmm0
  77dec4:	xor    %ebp,%ebp
  77dec6:	xorps  %xmm1,%xmm1
  77dec9:	ucomiss %xmm1,%xmm0
  77decc:	jne    77ded4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x29f4>
  77dece:	jnp    77e155 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2c75>
  77ded4:	movss  0x29c(%rsp),%xmm0
  77dedd:	ucomiss %xmm1,%xmm0
  77dee0:	jne    77dee8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2a08>
  77dee2:	jnp    77e155 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2c75>
  77dee8:	mov    0x348(%rsp),%eax
  77deef:	mov    $0x3fffffff,%ecx
  77def4:	and    %ecx,%eax
  77def6:	cmp    $0x3f800001,%eax
  77defb:	mov    $0x80000000,%ecx
  77df00:	cmove  %ecx,%eax
  77df03:	movd   %eax,%xmm0
  77df07:	xorps  %xmm1,%xmm1
  77df0a:	ucomiss %xmm1,%xmm0
  77df0d:	jbe    77dfee <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2b0e>
  77df13:	movl   $0x1,0x398(%rsp)
  77df1e:	movq   $0x23,0x390(%rsp)
  77df2a:	test   %bl,%bl
  77df2c:	je     77fedb <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x49fb>
  77df32:	lea    0x390(%rsp),%rbx
  77df3a:	mov    %rbx,%rdi
  77df3d:	call   74d580 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  77df42:	lea    0x2a8(%rsp),%rax
  77df4a:	movups (%rax),%xmm0
  77df4d:	movaps %xmm0,0xb60(%rsp)
  77df55:	mov    0x10(%rax),%rax
  77df59:	mov    %rax,0xb70(%rsp)
  77df61:	mov    %rbx,%rdi
  77df64:	mov    0xa8(%rsp),%rsi
  77df6c:	mov    0x38(%rsp),%rdx
  77df71:	xor    %ecx,%ecx
  77df73:	call   *0x33b5e7(%rip)        # ab9560 <_DYNAMIC+0x830>
  77df79:	mov    0x3a0(%rsp),%r9
  77df81:	test   %r9,%r9
  77df84:	je     77e0e1 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2c01>
  77df8a:	movups 0x390(%rsp),%xmm0
  77df92:	movaps %xmm0,0x370(%rsp)
  77df9a:	movaps 0x170(%rsp),%xmm0
  77dfa2:	movaps %xmm0,0x120(%rsp)
  77dfaa:	movups 0x698(%rsp),%xmm0
  77dfb2:	movaps %xmm0,0x180(%rsp)
  77dfba:	lea    0x970(%rsp),%rdi
  77dfc2:	mov    %r15,%rsi
  77dfc5:	movss  0x74(%rsp),%xmm0
  77dfcb:	lea    0xb60(%rsp),%rdx
  77dfd3:	lea    0x120(%rsp),%rcx
  77dfdb:	lea    0x370(%rsp),%r8
  77dfe3:	call   *0x33b57f(%rip)        # ab9568 <_DYNAMIC+0x838>
  77dfe9:	jmp    77e0ce <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2bee>
  77dfee:	cmpq   $0x0,0x8(%rsi,%r13,1)
  77dff4:	jne    77e010 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2b30>
  77dff6:	mov    0x20(%rsi,%r13,1),%edi
  77dffb:	call   7759f0 <_RNvMsh_NtCslbxve4rcJus_4gpui7runtimeNtB5_4Node4kind>
  77e000:	mov    $0x1,%bpl
  77e003:	cmp    $0x4,%al
  77e005:	mov    0x30(%rsp),%rsi
  77e00a:	jne    77e155 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2c75>
  77e010:	movl   $0x1,0x398(%rsp)
  77e01b:	movq   $0x23,0x390(%rsp)
  77e027:	test   %bl,%bl
  77e029:	je     77fedb <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x49fb>
  77e02f:	lea    0x390(%rsp),%rbx
  77e037:	mov    %rbx,%rdi
  77e03a:	call   74d580 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  77e03f:	lea    0x2a8(%rsp),%rcx
  77e047:	movups (%rcx),%xmm0
  77e04a:	movaps %xmm0,0x120(%rsp)
  77e052:	mov    0x10(%rcx),%rax
  77e056:	mov    %rax,0x130(%rsp)
  77e05e:	movups (%rcx),%xmm0
  77e061:	movaps %xmm0,0xc20(%rsp)
  77e069:	mov    0x10(%rcx),%rax
  77e06d:	mov    %rax,0xc30(%rsp)
  77e075:	movaps 0x170(%rsp),%xmm0
  77e07d:	movaps %xmm0,0x370(%rsp)
  77e085:	movups 0x698(%rsp),%xmm0
  77e08d:	movaps %xmm0,0x180(%rsp)
  77e095:	movups -0x6ba6dc(%rip),%xmm0        # c39c0 <GCC_except_table0+0x1620>
  77e09c:	movaps %xmm0,0x390(%rsp)
  77e0a4:	lea    0x970(%rsp),%rdi
  77e0ac:	mov    %r15,%rsi
  77e0af:	movss  0x74(%rsp),%xmm0
  77e0b5:	lea    0xc20(%rsp),%rdx
  77e0bd:	lea    0x370(%rsp),%rcx
  77e0c5:	mov    %rbx,%r8
  77e0c8:	call   *0x33b4a2(%rip)        # ab9570 <_DYNAMIC+0x840>
  77e0ce:	cmp    $0xffffffff,%eax
  77e0d1:	jne    77ff14 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4a34>
  77e0d7:	mov    $0x1,%bpl
  77e0da:	mov    0x30(%rsp),%rsi
  77e0df:	jmp    77e155 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2c75>
  77e0e1:	movaps 0x170(%rsp),%xmm0
  77e0e9:	movaps %xmm0,0x120(%rsp)
  77e0f1:	lea    0x34c(%rsp),%rax
  77e0f9:	movups -0x10(%rax),%xmm0
  77e0fd:	movaps %xmm0,0x180(%rsp)
  77e105:	movups 0x698(%rsp),%xmm0
  77e10d:	movaps %xmm0,0x390(%rsp)
  77e115:	lea    0x970(%rsp),%rdi
  77e11d:	lea    0x390(%rsp),%rsi
  77e125:	movss  0x74(%rsp),%xmm0
  77e12b:	lea    0xb60(%rsp),%rdx
  77e133:	lea    0x120(%rsp),%rcx
  77e13b:	mov    %r15,%r8
  77e13e:	call   *0x33b42c(%rip)        # ab9570 <_DYNAMIC+0x840>
  77e144:	mov    $0x1,%bpl
  77e147:	cmp    $0xffffffff,%eax
  77e14a:	mov    0x30(%rsp),%rsi
  77e14f:	jne    77ff14 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4a34>
  77e155:	mov    0x20(%rsi,%r13,1),%edi
  77e15a:	mov    %edi,%eax
  77e15c:	and    $0xf,%eax
  77e15f:	cmp    $0x9,%eax
  77e162:	ja     780412 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4f32>
  77e168:	cmp    $0x6,%eax
  77e16b:	je     77e775 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3295>
  77e171:	shr    $0x4,%edi
  77e174:	dec    %edi
  77e176:	mov    0x40(%rsp),%rax
  77e17b:	mov    0x2f0(%rax),%rsi
  77e182:	mov    0x2f8(%rax),%rdx
  77e189:	call   7758e0 <_RNvMsf_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSlot7get_mut>
  77e18e:	test   %rax,%rax
  77e191:	je     77e57e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x309e>
  77e197:	lea    0x34c(%rsp),%rcx
  77e19f:	movups -0x20(%rcx),%xmm0
  77e1a3:	movaps %xmm0,0x960(%rsp)
  77e1ab:	mov    0x40(%rsp),%rcx
  77e1b0:	mov    0x6e8(%rcx),%rbx
  77e1b7:	mov    $0x1e,%esi
  77e1bc:	test   %rbx,%rbx
  77e1bf:	mov    0x30(%rsp),%rdx
  77e1c4:	je     780311 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4e31>
  77e1ca:	cmpq   $0x0,0x30(%rbx)
  77e1cf:	je     780311 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4e31>
  77e1d5:	movzbl 0x78c(%rsp),%ecx
  77e1dd:	movb   $0x2,0xe0(%rsp)
  77e1e5:	cmp    $0x2,%cl
  77e1e8:	je     77e25c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2d7c>
  77e1ea:	mov    (%rdx,%r13,1),%rdx
  77e1ee:	cmp    %rdx,0x778(%rsp)
  77e1f6:	jne    77e25c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2d7c>
  77e1f8:	mov    0x788(%rsp),%edx
  77e1ff:	mov    %edx,0x1d0(%rsp)
  77e206:	movzbl 0x784(%rsp),%edx
  77e20e:	mov    %dl,0x7e(%rsp)
  77e212:	mov    0x780(%rsp),%edx
  77e219:	mov    %edx,0x11c(%rsp)
  77e220:	lea    0x785(%rsp),%rdi
  77e228:	movzwl (%rdi),%edx
  77e22b:	mov    %dx,0xb8(%rsp)
  77e233:	movzbl 0x2(%rdi),%edx
  77e237:	mov    %dl,0xba(%rsp)
  77e23e:	movzwl 0x8(%rdi),%edx
  77e242:	mov    %dx,0xb4(%rsp)
  77e24a:	movzbl 0xa(%rdi),%edx
  77e24e:	mov    %dl,0xb6(%rsp)
  77e255:	mov    %cl,0xe0(%rsp)
  77e25c:	cmpq   $0x0,0x1c0(%rsp)
  77e265:	je     78035d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4e7d>
  77e26b:	movss  0x328(%rsp),%xmm0
  77e274:	movaps 0x630(%rsp),%xmm1
  77e27c:	subss  0x2c0(%rsp),%xmm1
  77e285:	subss  0x308(%rsp),%xmm1
  77e28e:	subss  0x930(%rsp),%xmm1
  77e297:	subss  0x30c(%rsp),%xmm1
  77e2a0:	subss  0x920(%rsp),%xmm1
  77e2a9:	lea    0x390(%rsp),%rdi
  77e2b1:	mov    %rax,%rsi
  77e2b4:	lea    0x1c0(%rsp),%rdx
  77e2bc:	mov    $0x1,%ecx
  77e2c1:	mov    $0x1,%r8d
  77e2c7:	call   *0x33aee3(%rip)        # ab91b0 <_DYNAMIC+0x480>
  77e2cd:	mov    %r15,%r14
  77e2d0:	mov    0x390(%rsp),%rax
  77e2d8:	mov    0x398(%rsp),%r15
  77e2e0:	cmp    $0xfffffffffffffffe,%rax
  77e2e4:	jne    77ff2b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4a4b>
  77e2ea:	movaps 0x2c0(%rsp),%xmm0
  77e2f2:	movss  %xmm0,0xd8(%rsp)
  77e2fb:	movaps 0x910(%rsp),%xmm0
  77e303:	movss  %xmm0,0xdc(%rsp)
  77e30c:	mov    0x20(%r15),%rax
  77e310:	test   %rax,%rax
  77e313:	je     7803f2 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4f12>
  77e319:	lock incq (%rax)
  77e31d:	jle    780668 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  77e323:	movsd  0xd8(%rsp),%xmm0
  77e32c:	movsd  %xmm0,0x2f8(%rsp)
  77e335:	mov    %rax,0x300(%rsp)
  77e33d:	test   %bpl,%bpl
  77e340:	je     77e7c6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x32e6>
  77e346:	testb  $0x1,0x2a4(%rsp)
  77e34e:	movl   $0x1,0x398(%rsp)
  77e359:	movq   $0x23,0x390(%rsp)
  77e365:	je     780053 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4b73>
  77e36b:	lea    0x390(%rsp),%rdi
  77e373:	call   74d580 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  77e378:	lea    0x2a8(%rsp),%rcx
  77e380:	movups (%rcx),%xmm0
  77e383:	movaps %xmm0,0xb80(%rsp)
  77e38b:	mov    0x10(%rcx),%rax
  77e38f:	mov    %rax,0xb90(%rsp)
  77e397:	movups (%rcx),%xmm0
  77e39a:	movaps %xmm0,0x370(%rsp)
  77e3a2:	mov    0x10(%rcx),%rax
  77e3a6:	mov    %rax,0x380(%rsp)
  77e3ae:	cmpb   $0x2,0xe0(%rsp)
  77e3b6:	je     77e4bf <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2fdf>
  77e3bc:	mov    0x11c(%rsp),%eax
  77e3c3:	mov    %eax,0x180(%rsp)
  77e3ca:	movzbl 0x7e(%rsp),%eax
  77e3cf:	mov    %al,0x184(%rsp)
  77e3d6:	movzbl 0xba(%rsp),%eax
  77e3de:	lea    0x185(%rsp),%rcx
  77e3e6:	mov    %al,0x2(%rcx)
  77e3e9:	movzwl 0xb8(%rsp),%eax
  77e3f1:	mov    %ax,(%rcx)
  77e3f4:	mov    0x1d0(%rsp),%eax
  77e3fb:	mov    %eax,0x188(%rsp)
  77e402:	movzbl 0xe0(%rsp),%eax
  77e40a:	mov    %al,0x18c(%rsp)
  77e411:	movzbl 0xb6(%rsp),%eax
  77e419:	mov    %al,0xa(%rcx)
  77e41c:	movzwl 0xb4(%rsp),%eax
  77e424:	mov    %ax,0x8(%rcx)
  77e428:	movl   $0xffffffff,0x120(%rsp)
  77e433:	lea    0x120(%rsp),%rax
  77e43b:	mov    %rax,0x390(%rsp)
  77e443:	lea    0x970(%rsp),%rax
  77e44b:	mov    %rax,0x398(%rsp)
  77e453:	lea    0xd8(%rsp),%rax
  77e45b:	mov    %rax,0x3a0(%rsp)
  77e463:	lea    0xdc(%rsp),%rax
  77e46b:	mov    %rax,0x3a8(%rsp)
  77e473:	lea    0x370(%rsp),%rax
  77e47b:	mov    %rax,0x3b0(%rsp)
  77e483:	lea    0x170(%rsp),%rax
  77e48b:	mov    %rax,0x3b8(%rsp)
  77e493:	mov    0x20(%r15),%rdi
  77e497:	mov    %r14,%rsi
  77e49a:	lea    0x390(%rsp),%rdx
  77e4a2:	call   73f470 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_>
  77e4a7:	test   %al,%al
  77e4a9:	je     7800f7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c17>
  77e4af:	mov    0x120(%rsp),%eax
  77e4b6:	cmp    $0xffffffff,%eax
  77e4b9:	jne    780105 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c25>
  77e4bf:	mov    %r14,%rdi
  77e4c2:	mov    0xa8(%rsp),%rsi
  77e4ca:	mov    0x38(%rsp),%rdx
  77e4cf:	mov    $0x1,%ecx
  77e4d4:	call   *0x33b086(%rip)        # ab9560 <_DYNAMIC+0x830>
  77e4da:	add    $0x30,%rbx
  77e4de:	mov    0x190(%rsp),%rax
  77e4e6:	test   %rax,%rax
  77e4e9:	je     77e58f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x30af>
  77e4ef:	movups 0x180(%rsp),%xmm0
  77e4f7:	movaps %xmm0,0x700(%rsp)
  77e4ff:	movaps 0x170(%rsp),%xmm0
  77e507:	movaps %xmm0,0x120(%rsp)
  77e50f:	movss  0xd8(%rsp),%xmm0
  77e518:	movss  0xdc(%rsp),%xmm1
  77e521:	lea    0x2a8(%rsp),%rdx
  77e529:	mov    0x10(%rdx),%rcx
  77e52d:	mov    %rcx,0x3a0(%rsp)
  77e535:	movups (%rdx),%xmm2
  77e538:	movaps %xmm2,0x390(%rsp)
  77e540:	mov    %rax,(%rsp)
  77e544:	lea    0x970(%rsp),%rdi
  77e54c:	mov    %rbx,%rsi
  77e54f:	mov    %r15,%rdx
  77e552:	lea    0x390(%rsp),%rcx
  77e55a:	lea    0x120(%rsp),%r8
  77e562:	lea    0x700(%rsp),%r9
  77e56a:	movss  0x9c(%rsp),%xmm2
  77e573:	call   *0x33afff(%rip)        # ab9578 <_DYNAMIC+0x848>
  77e579:	jmp    77e610 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3130>
  77e57e:	movq   $0x0,0x1f8(%rsp)
  77e58a:	jmp    77e7e9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3309>
  77e58f:	movaps 0x170(%rsp),%xmm0
  77e597:	movaps %xmm0,0x120(%rsp)
  77e59f:	movss  0xd8(%rsp),%xmm0
  77e5a8:	movss  0xdc(%rsp),%xmm1
  77e5b1:	lea    0x2a8(%rsp),%rcx
  77e5b9:	mov    0x10(%rcx),%rax
  77e5bd:	mov    %rax,0x3a0(%rsp)
  77e5c5:	movups (%rcx),%xmm2
  77e5c8:	movaps %xmm2,0x390(%rsp)
  77e5d0:	movaps 0x960(%rsp),%xmm2
  77e5d8:	movaps %xmm2,0x180(%rsp)
  77e5e0:	lea    0x970(%rsp),%rdi
  77e5e8:	mov    %rbx,%rsi
  77e5eb:	mov    %r15,%rdx
  77e5ee:	lea    0x390(%rsp),%rcx
  77e5f6:	lea    0x120(%rsp),%r8
  77e5fe:	mov    %r14,%r9
  77e601:	movss  0x9c(%rsp),%xmm2
  77e60a:	call   *0x33af70(%rip)        # ab9580 <_DYNAMIC+0x850>
  77e610:	cmp    $0xffffffff,%eax
  77e613:	jne    78003c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4b5c>
  77e619:	cmpb   $0x2,0xe0(%rsp)
  77e621:	je     77e7c6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x32e6>
  77e627:	mov    0x11c(%rsp),%eax
  77e62e:	cmp    0x1d0(%rsp),%eax
  77e635:	jne    77e7c6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x32e6>
  77e63b:	mov    0x40(%rsp),%rax
  77e640:	mov    0x628(%rax),%rax
  77e647:	test   %rax,%rax
  77e64a:	je     77e7c6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x32e6>
  77e650:	mov    0x40(%rsp),%rcx
  77e655:	cmp    0x5f0(%rcx),%rax
  77e65c:	jne    77e7c6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x32e6>
  77e662:	mov    0x30(%rsp),%rax
  77e667:	mov    (%rax,%r13,1),%rax
  77e66b:	mov    0x40(%rsp),%rcx
  77e670:	cmp    %rax,0x630(%rcx)
  77e677:	jne    77e7c6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x32e6>
  77e67d:	movzbl 0xe0(%rsp),%ecx
  77e685:	mov    %r14,%rdi
  77e688:	mov    %r15,%rsi
  77e68b:	mov    0x11c(%rsp),%edx
  77e692:	call   *0x33ad80(%rip)        # ab9418 <_DYNAMIC+0x6e8>
  77e698:	movq   $0x18,0x390(%rsp)
  77e6a4:	cmpl   $0x1,0x180(%rsp)
  77e6ac:	jne    7800f7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c17>
  77e6b2:	lea    0x390(%rsp),%rbx
  77e6ba:	mov    %rbx,%rdi
  77e6bd:	call   74d580 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  77e6c2:	movsd  0x184(%rsp),%xmm0
  77e6cb:	movaps 0x2c0(%rsp),%xmm1
  77e6d3:	unpcklps 0x910(%rsp),%xmm1
  77e6db:	addps  %xmm0,%xmm1
  77e6de:	movhps 0x18c(%rsp),%xmm1
  77e6e6:	movups %xmm1,0x700(%rsp)
  77e6ee:	mov    %rbx,%rdi
  77e6f1:	mov    0xa8(%rsp),%rsi
  77e6f9:	mov    0x38(%rsp),%rdx
  77e6fe:	mov    $0x1,%ecx
  77e703:	call   *0x33ae57(%rip)        # ab9560 <_DYNAMIC+0x830>
  77e709:	mov    0x3a0(%rsp),%r9
  77e711:	test   %r9,%r9
  77e714:	je     77e77f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x329f>
  77e716:	movups 0x390(%rsp),%xmm0
  77e71e:	movaps %xmm0,0x120(%rsp)
  77e726:	movaps 0x170(%rsp),%xmm0
  77e72e:	movaps %xmm0,0x180(%rsp)
  77e736:	xorps  %xmm0,%xmm0
  77e739:	lea    0x970(%rsp),%rdi
  77e741:	lea    0x700(%rsp),%rsi
  77e749:	lea    0xb80(%rsp),%rdx
  77e751:	mov    %r14,%rcx
  77e754:	lea    0x120(%rsp),%r8
  77e75c:	call   *0x33ae06(%rip)        # ab9568 <_DYNAMIC+0x838>
  77e762:	jmp    77e7bd <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x32dd>
  77e764:	mov    $0x1,%r12b
  77e767:	cmp    $0x7,%eax
  77e76a:	je     77dc3a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x275a>
  77e770:	jmp    780412 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4f32>
  77e775:	mov    $0xffffffff,%edi
  77e77a:	jmp    77e176 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2c96>
  77e77f:	movaps 0x170(%rsp),%xmm0
  77e787:	movaps %xmm0,0x390(%rsp)
  77e78f:	lea    0x970(%rsp),%rdi
  77e797:	lea    0x700(%rsp),%rsi
  77e79f:	lea    0xb80(%rsp),%rdx
  77e7a7:	lea    0x390(%rsp),%rcx
  77e7af:	lea    0x960(%rsp),%r8
  77e7b7:	call   *0x33a853(%rip)        # ab9010 <_DYNAMIC+0x2e0>
  77e7bd:	cmp    $0xffffffff,%eax
  77e7c0:	jne    78003c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4b5c>
  77e7c6:	mov    0x2f8(%rsp),%rax
  77e7ce:	mov    %rax,0x1f0(%rsp)
  77e7d6:	mov    0x300(%rsp),%rax
  77e7de:	mov    %rax,0x1f8(%rsp)
  77e7e6:	mov    %r14,%r15
  77e7e9:	mov    0x30(%rsp),%r14
  77e7ee:	test   %bpl,%bpl
  77e7f1:	je     77e94a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x346a>
  77e7f7:	mov    0x20(%r14,%r13,1),%edi
  77e7fc:	call   *0x33a9a6(%rip)        # ab91a8 <_DYNAMIC+0x478>
  77e802:	mov    %edx,%ebp
  77e804:	cmp    $0x2,%dl
  77e807:	je     77e94a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x346a>
  77e80d:	mov    0x2d8(%rsp),%rcx
  77e815:	mov    (%rcx),%rcx
  77e818:	test   %rcx,%rcx
  77e81b:	je     780430 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4f50>
  77e821:	mov    0x10(%rcx),%rsi
  77e825:	mov    %eax,%ebx
  77e827:	cmp    %rbx,%rsi
  77e82a:	jbe    7805e4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5104>
  77e830:	mov    0x8(%rcx),%rax
  77e834:	movaps 0x930(%rsp),%xmm4
  77e83c:	movaps %xmm4,%xmm0
  77e83f:	shufps $0xe8,%xmm4,%xmm0
  77e843:	movaps 0x940(%rsp),%xmm3
  77e84b:	addps  %xmm0,%xmm3
  77e84e:	movaps 0x2c0(%rsp),%xmm5
  77e856:	movaps %xmm5,%xmm1
  77e859:	shufps $0xe8,%xmm5,%xmm1
  77e85d:	addps  %xmm1,%xmm3
  77e860:	movaps 0x630(%rsp),%xmm2
  77e868:	subps  %xmm1,%xmm2
  77e86b:	shufps $0xed,%xmm5,%xmm5
  77e86f:	subps  %xmm5,%xmm2
  77e872:	subps  %xmm0,%xmm2
  77e875:	shufps $0xed,%xmm4,%xmm4
  77e879:	subps  %xmm4,%xmm2
  77e87c:	subps  0x920(%rsp),%xmm2
  77e884:	movlhps %xmm2,%xmm3
  77e887:	movups %xmm3,0x370(%rsp)
  77e88f:	testb  $0x1,0x2a4(%rsp)
  77e897:	movl   $0x1,0x398(%rsp)
  77e8a2:	movq   $0x23,0x390(%rsp)
  77e8ae:	je     78008c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4bac>
  77e8b4:	lea    (%rax,%rbx,8),%rbx
  77e8b8:	lea    0x390(%rsp),%r14
  77e8c0:	mov    %r14,%rdi
  77e8c3:	call   74d580 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  77e8c8:	lea    0x2a8(%rsp),%rcx
  77e8d0:	movups (%rcx),%xmm0
  77e8d3:	movaps %xmm0,0x120(%rsp)
  77e8db:	mov    0x10(%rcx),%rax
  77e8df:	mov    %rax,0x130(%rsp)
  77e8e7:	movups (%rcx),%xmm0
  77e8ea:	movaps %xmm0,0xc40(%rsp)
  77e8f2:	mov    0x10(%rcx),%rax
  77e8f6:	mov    %rax,0xc50(%rsp)
  77e8fe:	movaps 0x170(%rsp),%xmm0
  77e906:	movaps %xmm0,0x390(%rsp)
  77e90e:	movzbl %bpl,%r9d
  77e912:	lea    0x970(%rsp),%rdi
  77e91a:	mov    %rbx,%rsi
  77e91d:	lea    0x370(%rsp),%rdx
  77e925:	lea    0xc40(%rsp),%rcx
  77e92d:	mov    %r14,%r8
  77e930:	mov    0x30(%rsp),%r14
  77e935:	movss  0x74(%rsp),%xmm0
  77e93b:	call   *0x33ac47(%rip)        # ab9588 <_DYNAMIC+0x858>
  77e941:	cmp    $0xffffffff,%eax
  77e944:	jne    7800c2 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4be2>
  77e94a:	mov    0x18(%r14,%r13,1),%ebx
  77e94f:	cmpb   $0x0,0x2f(%rsp)
  77e954:	je     77e97e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x349e>
  77e956:	cmp    $0xffffffff,%ebx
  77e959:	je     77e979 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3499>
  77e95b:	mov    0x110(%rsp),%rsi
  77e963:	cmp    %rbx,%rsi
  77e966:	jbe    7805d5 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x50f5>
  77e96c:	mov    0x108(%rsp),%rax
  77e974:	mov    (%rax,%rbx,4),%ebx
  77e977:	jmp    77e97e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x349e>
  77e979:	mov    $0xffffffff,%ebx
  77e97e:	cmpb   $0x0,0x60(%rsp)
  77e983:	je     77ea6f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x358f>
  77e989:	movss  0x298(%rsp),%xmm0
  77e992:	xorps  %xmm1,%xmm1
  77e995:	ucomiss %xmm1,%xmm0
  77e998:	jne    77e99c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x34bc>
  77e99a:	jnp    77e9b4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x34d4>
  77e99c:	movss  0x29c(%rsp),%xmm0
  77e9a5:	ucomiss %xmm1,%xmm0
  77e9a8:	jne    77ea6f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x358f>
  77e9ae:	jp     77ea6f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x358f>
  77e9b4:	cmpb   $0x0,0x1d4(%rsp)
  77e9bc:	je     77e9e6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3506>
  77e9be:	movss  0x1b8(%rsp),%xmm0
  77e9c7:	ucomiss %xmm1,%xmm0
  77e9ca:	jne    77e9ce <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x34ee>
  77e9cc:	jnp    77e9e6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3506>
  77e9ce:	movss  0x1bc(%rsp),%xmm0
  77e9d7:	ucomiss %xmm1,%xmm0
  77e9da:	jne    77ea6f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x358f>
  77e9e0:	jp     77ea6f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x358f>
  77e9e6:	test   %r12b,%r12b
  77e9e9:	je     77ea0b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x352b>
  77e9eb:	movss  0x1b8(%rsp),%xmm0
  77e9f4:	ucomiss %xmm1,%xmm0
  77e9f7:	jne    77e9fb <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x351b>
  77e9f9:	jnp    77ea0b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x352b>
  77e9fb:	movss  0x1bc(%rsp),%xmm0
  77ea04:	ucomiss %xmm1,%xmm0
  77ea07:	jne    77ea6f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x358f>
  77ea09:	jp     77ea6f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x358f>
  77ea0b:	mov    0x110(%rsp),%r14
  77ea13:	cmp    0x100(%rsp),%r14
  77ea1b:	jne    77ea2a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x354a>
  77ea1d:	lea    0x100(%rsp),%rdi
  77ea25:	call   7720d0 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtCslbxve4rcJus_4gpui7runtime6ParentE8grow_oneCs9C2G9YFESsD_29canonical_text_public_control>
  77ea2a:	mov    0x108(%rsp),%rax
  77ea32:	mov    %ebx,(%rax,%r14,4)
  77ea36:	inc    %r14
  77ea39:	mov    %r14,0x110(%rsp)
  77ea41:	mov    0x1f8(%rsp),%rax
  77ea49:	test   %rax,%rax
  77ea4c:	je     77d1b6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1cd6>
  77ea52:	lock decq (%rax)
  77ea56:	jne    77d1b6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1cd6>
  77ea5c:	lea    0x1f8(%rsp),%rdi
  77ea64:	call   *0x33a626(%rip)        # ab9090 <_DYNAMIC+0x360>
  77ea6a:	jmp    77d1b6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1cd6>
  77ea6f:	mov    0x20(%r14,%r13,1),%edi
  77ea74:	mov    $0x1,%r12b
  77ea77:	call   7759f0 <_RNvMsh_NtCslbxve4rcJus_4gpui7runtimeNtB5_4Node4kind>
  77ea7c:	cmp    $0x7,%al
  77ea7e:	jne    77ea99 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x35b9>
  77ea80:	mov    0x30(%rsp),%rax
  77ea85:	mov    (%rax,%r13,1),%rsi
  77ea89:	mov    $0x1,%r12b
  77ea8c:	lea    0x6a8(%rsp),%rdi
  77ea94:	call   77a460 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapyNtNtB7_7set_val9SetValZSTE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  77ea99:	cmpb   $0x0,0x2f(%rsp)
  77ea9e:	je     77eaf1 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3611>
  77eaa0:	mov    0x150(%rsp),%rsi
  77eaa8:	mov    $0x1,%edi
  77eaad:	mov    $0x1,%r12b
  77eab0:	call   *0x33a4fa(%rip)        # ab8fb0 <_DYNAMIC+0x280>
  77eab6:	mov    %eax,%ebp
  77eab8:	mov    0x110(%rsp),%r14
  77eac0:	cmp    0x100(%rsp),%r14
  77eac8:	jne    77eada <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x35fa>
  77eaca:	mov    $0x1,%r12b
  77eacd:	lea    0x100(%rsp),%rdi
  77ead5:	call   7720d0 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtCslbxve4rcJus_4gpui7runtime6ParentE8grow_oneCs9C2G9YFESsD_29canonical_text_public_control>
  77eada:	mov    0x108(%rsp),%rax
  77eae2:	mov    %ebp,(%rax,%r14,4)
  77eae6:	inc    %r14
  77eae9:	mov    %r14,0x110(%rsp)
  77eaf1:	movss  0x298(%rsp),%xmm0
  77eafa:	xor    %edx,%edx
  77eafc:	xorps  %xmm1,%xmm1
  77eaff:	ucomiss %xmm1,%xmm0
  77eb02:	jne    77eb0a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x362a>
  77eb04:	jnp    77eb91 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x36b1>
  77eb0a:	movss  0x29c(%rsp),%xmm0
  77eb13:	ucomiss %xmm1,%xmm0
  77eb16:	mov    $0x0,%ebp
  77eb1b:	mov    0x30(%rsp),%rsi
  77eb20:	jne    77eb24 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3644>
  77eb22:	jnp    77eb93 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x36b3>
  77eb24:	mov    0x20(%rsi,%r13,1),%edi
  77eb29:	mov    %edi,%eax
  77eb2b:	and    $0xf,%eax
  77eb2e:	cmp    $0x9,%eax
  77eb31:	ja     78054a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x506a>
  77eb37:	cmp    $0x6,%eax
  77eb3a:	je     77eb44 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3664>
  77eb3c:	mov    $0x1,%bpl
  77eb3f:	cmp    $0xf,%edi
  77eb42:	ja     77eb93 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x36b3>
  77eb44:	mov    0x348(%rsp),%eax
  77eb4b:	mov    $0x3fffffff,%ecx
  77eb50:	and    %ecx,%eax
  77eb52:	cmp    $0x3f800001,%eax
  77eb57:	mov    $0x80000000,%ecx
  77eb5c:	cmove  %ecx,%eax
  77eb5f:	movd   %eax,%xmm0
  77eb63:	mov    $0x1,%bpl
  77eb66:	ucomiss %xmm1,%xmm0
  77eb69:	ja     77eb93 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x36b3>
  77eb6b:	cmpq   $0x0,0x8(%rsi,%r13,1)
  77eb71:	jne    77eb93 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x36b3>
  77eb73:	mov    $0x1,%r12b
  77eb76:	call   7759f0 <_RNvMsh_NtCslbxve4rcJus_4gpui7runtimeNtB5_4Node4kind>
  77eb7b:	lea    -0x4(%rax),%ecx
  77eb7e:	cmp    $0x2,%al
  77eb80:	setae  %al
  77eb83:	test   $0xfb,%cl
  77eb86:	sete   %bpl
  77eb8a:	and    %al,%bpl
  77eb8d:	xor    %edx,%edx
  77eb8f:	jmp    77eb93 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x36b3>
  77eb91:	xor    %ebp,%ebp
  77eb93:	mov    0x150(%rsp),%rax
  77eb9b:	test   %rax,%rax
  77eb9e:	je     77ebb5 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x36d5>
  77eba0:	mov    0x148(%rsp),%rcx
  77eba8:	shl    $0x6,%rax
  77ebac:	mov    -0x8(%rcx,%rax,1),%ecx
  77ebb0:	mov    $0x1,%edx
  77ebb5:	mov    %ebp,%eax
  77ebb7:	xor    $0x1,%al
  77ebb9:	movzbl %al,%esi
  77ebbc:	mov    $0x1,%r12b
  77ebbf:	mov    %ebx,%edi
  77ebc1:	call   *0x33a9c9(%rip)        # ab9590 <_DYNAMIC+0x860>
  77ebc7:	mov    %eax,0x2c0(%rsp)
  77ebce:	mov    0x1f8(%rsp),%rax
  77ebd6:	test   %rax,%rax
  77ebd9:	sete   0x60(%rsp)
  77ebde:	je     77ec20 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3740>
  77ebe0:	mov    0x150(%rsp),%ecx
  77ebe7:	mov    %ecx,0x3a0(%rsp)
  77ebee:	movsd  0x1f0(%rsp),%xmm0
  77ebf7:	movsd  %xmm0,0x398(%rsp)
  77ec00:	mov    %rax,0x390(%rsp)
  77ec08:	xor    %r12d,%r12d
  77ec0b:	lea    0x200(%rsp),%rdi
  77ec13:	lea    0x390(%rsp),%rsi
  77ec1b:	call   775320 <_RNvMsF_NtCscdodAO9FK5_5alloc3vecINtB5_3VecNtNtNtCslbxve4rcJus_4gpui7runtime13text_geometry5EntryE8push_mutCs9C2G9YFESsD_29canonical_text_public_control>
  77ec20:	cmp    $0xffffffff,%ebx
  77ec23:	je     77ec58 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3778>
  77ec25:	mov    %ebx,%ebx
  77ec27:	mov    0x150(%rsp),%rsi
  77ec2f:	cmp    %rbx,%rsi
  77ec32:	jbe    780657 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5177>
  77ec38:	mov    0x148(%rsp),%rax
  77ec40:	shl    $0x6,%rbx
  77ec44:	mov    0x30(%rax,%rbx,1),%rax
  77ec49:	mov    %rax,0x394(%rsp)
  77ec51:	mov    $0x1,%eax
  77ec56:	jmp    77ec5a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x377a>
  77ec58:	xor    %eax,%eax
  77ec5a:	mov    %eax,0x390(%rsp)
  77ec61:	movzbl 0x60(%rsp),%eax
  77ec66:	mov    %eax,%r12d
  77ec69:	lea    0x2a4(%rsp),%rdi
  77ec71:	lea    0x390(%rsp),%rsi
  77ec79:	lea    0x268(%rsp),%rdx
  77ec81:	call   *0x33a911(%rip)        # ab9598 <_DYNAMIC+0x868>
  77ec87:	mov    %rax,%rbx
  77ec8a:	mov    0x30(%rsp),%rax
  77ec8f:	mov    (%rax,%r13,1),%r14
  77ec93:	mov    0x20(%rax,%r13,1),%edi
  77ec98:	movzbl 0x60(%rsp),%eax
  77ec9d:	mov    %eax,%r12d
  77eca0:	call   7759f0 <_RNvMsh_NtCslbxve4rcJus_4gpui7runtimeNtB5_4Node4kind>
  77eca5:	mov    %eax,%r15d
  77eca8:	mov    0x30(%rsp),%rax
  77ecad:	mov    0x20(%rax,%r13,1),%edi
  77ecb2:	mov    %edi,%eax
  77ecb4:	and    $0xf,%eax
  77ecb7:	cmp    $0x9,%eax
  77ecba:	ja     78052c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x504c>
  77ecc0:	cmp    $0x6,%eax
  77ecc3:	je     77f101 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3c21>
  77ecc9:	shr    $0x4,%edi
  77eccc:	dec    %edi
  77ecce:	mov    0x40(%rsp),%rax
  77ecd3:	mov    0x2f0(%rax),%rsi
  77ecda:	mov    0x2f8(%rax),%rdx
  77ece1:	movzbl 0x60(%rsp),%eax
  77ece6:	mov    %eax,%r12d
  77ece9:	call   775890 <_RNvMsf_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSlot3get>
  77ecee:	mov    %ebp,0x74(%rsp)
  77ecf2:	test   %rax,%rax
  77ecf5:	je     77ed29 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3849>
  77ecf7:	mov    0x40(%rax),%rbp
  77ecfb:	testb  $0x1,0x0(%rbp)
  77ecff:	jne    77ed2b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x384b>
  77ed01:	mov    0x8(%rbp),%rax
  77ed05:	test   $0x1,%al
  77ed07:	jne    77ed2b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x384b>
  77ed09:	mov    $0x2,%eax
  77ed0e:	lock xadd %rax,0x8(%rbp)
  77ed14:	and    0x888(%rsp),%rax
  77ed1c:	neg    %rax
  77ed1f:	jno    77ed2b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x384b>
  77ed21:	lock orq $0x1,0x8(%rbp)
  77ed27:	jmp    77ed2b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x384b>
  77ed29:	xor    %ebp,%ebp
  77ed2b:	movdqa 0x630(%rsp),%xmm0
  77ed34:	movd   %xmm0,%esi
  77ed38:	shufps $0x55,%xmm0,%xmm0
  77ed3c:	movd   %xmm0,%eax
  77ed40:	shl    $0x20,%rax
  77ed44:	or     %rax,%rsi
  77ed47:	lea    0x180(%rsp),%rdi
  77ed4f:	lea    0x2a4(%rsp),%rdx
  77ed57:	call   *0x33a843(%rip)        # ab95a0 <_DYNAMIC+0x870>
  77ed5d:	mov    0x30(%rsp),%r12
  77ed62:	mov    0x20(%r12,%r13,1),%edi
  77ed67:	call   7759f0 <_RNvMsh_NtCslbxve4rcJus_4gpui7runtimeNtB5_4Node4kind>
  77ed6c:	xor    %esi,%esi
  77ed6e:	cmpq   $0x0,0x8(%r12,%r13,1)
  77ed74:	setne  %sil
  77ed78:	movzbl %al,%edi
  77ed7b:	call   775640 <_RNvMs_NtNtCslbxve4rcJus_4gpui7runtime9semanticsNtB4_7Actions8for_node>
  77ed80:	mov    0x18(%r12,%r13,1),%ecx
  77ed85:	mov    $0xffffffff,%edx
  77ed8a:	cmp    %rdx,%rcx
  77ed8d:	je     77edc3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x38e3>
  77ed8f:	cmp    %rcx,0x168(%rsp)
  77ed97:	mov    0x2c0(%rsp),%esi
  77ed9e:	jbe    77edba <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x38da>
  77eda0:	mov    0x160(%rsp),%rdx
  77eda8:	cmpb   $0x0,(%rdx,%rcx,1)
  77edac:	setne  %cl
  77edaf:	mov    0xbc(%rsp),%edx
  77edb6:	or     %cl,%dl
  77edb8:	jmp    77edd1 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x38f1>
  77edba:	mov    0xbc(%rsp),%edx
  77edc1:	jmp    77edd1 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x38f1>
  77edc3:	mov    0xbc(%rsp),%edx
  77edca:	mov    0x2c0(%rsp),%esi
  77edd1:	movzbl %al,%ecx
  77edd4:	or     $0x20,%al
  77edd6:	movzbl %al,%eax
  77edd9:	test   %dl,%dl
  77eddb:	cmove  %ecx,%eax
  77edde:	mov    %r14,0x3b0(%rsp)
  77ede6:	mov    %esi,0x3c8(%rsp)
  77eded:	mov    %r15b,0x3cd(%rsp)
  77edf5:	mov    %rbp,0x3b8(%rsp)
  77edfd:	movups 0x180(%rsp),%xmm0
  77ee05:	movaps %xmm0,0x390(%rsp)
  77ee0d:	mov    %rbx,0x3c0(%rsp)
  77ee15:	movups 0x290(%rsp),%xmm0
  77ee1d:	lea    0x394(%rsp),%rcx
  77ee25:	movups %xmm0,0xc(%rcx)
  77ee29:	mov    0x74(%rsp),%ecx
  77ee2d:	mov    %cl,0x3ce(%rsp)
  77ee34:	mov    %al,0x3cc(%rsp)
  77ee3b:	movzbl 0x60(%rsp),%eax
  77ee40:	mov    %eax,%r12d
  77ee43:	lea    0x140(%rsp),%rdi
  77ee4b:	lea    0x390(%rsp),%rsi
  77ee53:	call   7752a0 <_RNvMsF_NtCscdodAO9FK5_5alloc3vecINtB5_3VecNtNtCslbxve4rcJus_4gpui7runtime9PresentedE8push_mutCs9C2G9YFESsD_29canonical_text_public_control>
  77ee58:	cmpb   $0x2,0x690(%rsp)
  77ee60:	je     77f084 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3ba4>
  77ee66:	mov    0x150(%rsp),%rsi
  77ee6e:	lea    -0x1(%rsi),%rbx
  77ee72:	mov    0x40(%rsp),%rax
  77ee77:	cmp    0x5c0(%rax),%rbx
  77ee7e:	jae    77eec1 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x39e1>
  77ee80:	mov    0x5b8(%rax),%r14
  77ee87:	movzbl 0x60(%rsp),%eax
  77ee8c:	mov    %eax,%r12d
  77ee8f:	lea    0xb98(%rsp),%rdi
  77ee97:	call   *0x33a58b(%rip)        # ab9428 <_DYNAMIC+0x6f8>
  77ee9d:	mov    %rax,0x878(%rsp)
  77eea5:	mov    %rdx,0x880(%rsp)
  77eead:	mov    %rbx,%rax
  77eeb0:	shl    $0x6,%rax
  77eeb4:	add    %rax,%r14
  77eeb7:	mov    0x150(%rsp),%rsi
  77eebf:	jmp    77eec4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x39e4>
  77eec1:	xor    %r14d,%r14d
  77eec4:	cmp    %rsi,%rbx
  77eec7:	jae    780648 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5168>
  77eecd:	mov    %rbx,%rax
  77eed0:	shl    $0x6,%rax
  77eed4:	add    0x148(%rsp),%rax
  77eedc:	movups 0x270(%rsp),%xmm0
  77eee4:	mov    %r14,0x198(%rsp)
  77eeec:	mov    0x878(%rsp),%rcx
  77eef4:	mov    %rcx,0x1a0(%rsp)
  77eefc:	mov    0x880(%rsp),%rcx
  77ef04:	mov    %rcx,0x1a8(%rsp)
  77ef0c:	mov    %rax,0x180(%rsp)
  77ef14:	movups %xmm0,0x188(%rsp)
  77ef1c:	mov    0x40(%rsp),%rcx
  77ef21:	mov    0x650(%rcx),%rax
  77ef28:	mov    %rax,0x120(%rsp)
  77ef30:	mov    0x678(%rsp),%rax
  77ef38:	mov    %rax,0x128(%rsp)
  77ef40:	mov    0x2f0(%rsp),%eax
  77ef47:	lea    0x130(%rsp),%rdx
  77ef4f:	mov    %eax,0x8(%rdx)
  77ef52:	mov    0x2e8(%rsp),%rax
  77ef5a:	mov    %rax,(%rdx)
  77ef5d:	movzbl 0x57(%rsp),%eax
  77ef62:	mov    %al,0x13c(%rsp)
  77ef69:	movzbl 0x7c(%rsp),%eax
  77ef6e:	mov    %al,0xf(%rdx)
  77ef71:	movzwl 0x7a(%rsp),%eax
  77ef76:	mov    %ax,0xd(%rdx)
  77ef7a:	mov    0x6e8(%rcx),%rdi
  77ef81:	test   %rdi,%rdi
  77ef84:	je     77ef9c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3abc>
  77ef86:	movzbl 0x60(%rsp),%eax
  77ef8b:	mov    %eax,%r12d
  77ef8e:	mov    %rbx,%rsi
  77ef91:	call   *0x33a611(%rip)        # ab95a8 <_DYNAMIC+0x878>
  77ef97:	mov    %rax,%r15
  77ef9a:	jmp    77ef9f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3abf>
  77ef9c:	xor    %r15d,%r15d
  77ef9f:	mov    0x210(%rsp),%rax
  77efa7:	test   %rax,%rax
  77efaa:	mov    0x30(%rsp),%rsi
  77efaf:	je     77efe7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3b07>
  77efb1:	mov    0x208(%rsp),%rcx
  77efb9:	lea    (%rax,%rax,2),%rdx
  77efbd:	lea    (%rcx,%rdx,8),%rax
  77efc1:	add    $0xffffffffffffffe8,%rax
  77efc5:	mov    $0x0,%ebp
  77efca:	test   %rax,%rax
  77efcd:	je     77efe9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3b09>
  77efcf:	lea    (%rcx,%rdx,8),%rcx
  77efd3:	mov    -0x8(%rcx),%ecx
  77efd6:	cmp    %rcx,%rbx
  77efd9:	mov    $0x0,%ecx
  77efde:	cmovne %rcx,%rax
  77efe2:	mov    %rax,%rbp
  77efe5:	jmp    77efe9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3b09>
  77efe7:	xor    %ebp,%ebp
  77efe9:	mov    (%rsi,%r13,1),%rdx
  77efed:	cvtps2pd 0x630(%rsp),%xmm0
  77eff5:	movaps %xmm0,0x370(%rsp)
  77effd:	movzbl 0x60(%rsp),%eax
  77f002:	mov    %eax,%r12d
  77f005:	lea    0x390(%rsp),%rdi
  77f00d:	lea    0x6c0(%rsp),%rsi
  77f015:	lea    0x370(%rsp),%rcx
  77f01d:	call   *0x33a58d(%rip)        # ab95b0 <_DYNAMIC+0x880>
  77f023:	mov    0x30(%rsp),%rax
  77f028:	mov    (%rax,%r13,1),%rdx
  77f02c:	mov    0x40(%rsp),%rax
  77f031:	mov    0x670(%rax),%rdi
  77f038:	mov    0x678(%rax),%rsi
  77f03f:	call   7447c0 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyNtNtNtCslbxve4rcJus_4gpui7runtime4list7ListRowE3getyECs9C2G9YFESsD_29canonical_text_public_control>
  77f044:	mov    %rax,0x8(%rsp)
  77f049:	lea    0x390(%rsp),%rax
  77f051:	mov    %rax,(%rsp)
  77f055:	movzbl 0x60(%rsp),%eax
  77f05a:	mov    %eax,%r12d
  77f05d:	lea    0x688(%rsp),%rdi
  77f065:	mov    %rbx,%rsi
  77f068:	lea    0x180(%rsp),%rdx
  77f070:	mov    %r15,%r8
  77f073:	mov    %rbp,%r9
  77f076:	lea    0x120(%rsp),%rcx
  77f07e:	call   *0x33a534(%rip)        # ab95b8 <_DYNAMIC+0x888>
  77f084:	cmpl   $0xffffffff,0x810(%rsp)
  77f08c:	je     77f0e1 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3c01>
  77f08e:	mov    0xf0(%rsp),%rax
  77f096:	mov    (%rax),%rbx
  77f099:	test   %rbx,%rbx
  77f09c:	je     77f0e1 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3c01>
  77f09e:	mov    0x30(%rsp),%rax
  77f0a3:	mov    (%rax,%r13,1),%r15
  77f0a7:	mov    0x40(%rsp),%rax
  77f0ac:	mov    0x670(%rax),%rdi
  77f0b3:	mov    0x678(%rax),%rsi
  77f0ba:	mov    %r15,%rdx
  77f0bd:	call   7447c0 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyNtNtNtCslbxve4rcJus_4gpui7runtime4list7ListRowE3getyECs9C2G9YFESsD_29canonical_text_public_control>
  77f0c2:	movzbl 0x60(%rsp),%ecx
  77f0c7:	mov    %ecx,%r12d
  77f0ca:	lea    0x810(%rsp),%rdi
  77f0d2:	mov    %rbx,%rsi
  77f0d5:	mov    %r15,%rdx
  77f0d8:	mov    %rax,%rcx
  77f0db:	call   *0x33a2ef(%rip)        # ab93d0 <_DYNAMIC+0x6a0>
  77f0e1:	mov    0x38(%rsp),%rcx
  77f0e6:	inc    %rcx
  77f0e9:	cmp    0x660(%rsp),%rcx
  77f0f1:	lea    0x180(%rsp),%r15
  77f0f9:	jb     77d192 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1cb2>
  77f0ff:	jmp    77f10b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3c2b>
  77f101:	mov    $0xffffffff,%edi
  77f106:	jmp    77ecce <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x37ee>
  77f10b:	cmpl   $0xffffffff,0x810(%rsp)
  77f113:	mov    0x40(%rsp),%r14
  77f118:	mov    0xf8(%rsp),%rbx
  77f120:	je     77f130 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3c50>
  77f122:	lea    0x810(%rsp),%rdi
  77f12a:	call   *0x33a2a8(%rip)        # ab93d8 <_DYNAMIC+0x6a8>
  77f130:	movzbl 0x690(%rsp),%eax
  77f138:	cmp    $0x2,%al
  77f13a:	je     77f18b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3cab>
  77f13c:	mov    0x688(%rsp),%rdi
  77f144:	mov    0x6a0(%r14),%rcx
  77f14b:	mov    0x260(%rsp),%rdx
  77f153:	mov    %rdx,0x390(%rsp)
  77f15b:	mov    %rcx,0x398(%rsp)
  77f163:	mov    %rbx,0x3a0(%rsp)
  77f16b:	mov    0x5c0(%r14),%rcx
  77f172:	mov    0x150(%rsp),%r8
  77f17a:	movzbl %al,%esi
  77f17d:	lea    0x390(%rsp),%rdx
  77f185:	call   *0x33a255(%rip)        # ab93e0 <_DYNAMIC+0x6b0>
  77f18b:	lea    0x1e8(%r14),%rbx
  77f192:	mov    0x650(%r14),%rax
  77f199:	test   %rax,%rax
  77f19c:	je     77f27c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3d9c>
  77f1a2:	mov    0x100(%rax),%rdx
  77f1a9:	lea    0x268(%rsp),%rax
  77f1b1:	mov    %rax,0x390(%rsp)
  77f1b9:	lea    0x2f(%rsp),%rax
  77f1be:	mov    %rax,0x398(%rsp)
  77f1c6:	mov    %rbx,0x3a0(%rsp)
  77f1ce:	lea    0x100(%rsp),%rax
  77f1d6:	mov    %rax,0x3a8(%rsp)
  77f1de:	lea    0x140(%rsp),%rax
  77f1e6:	mov    %rax,0x3b0(%rsp)
  77f1ee:	test   %rdx,%rdx
  77f1f1:	je     77f27c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3d9c>
  77f1f7:	lea    0x310(%rsp),%rdi
  77f1ff:	lea    0x390(%rsp),%rsi
  77f207:	call   75db60 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_>
  77f20c:	mov    0x320(%rsp),%rax
  77f214:	mov    %rax,0x7a0(%rsp)
  77f21c:	movups 0x310(%rsp),%xmm0
  77f224:	movaps %xmm0,0x790(%rsp)
  77f22c:	jmp    77f288 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3da8>
  77f22e:	movaps 0x970(%rsp),%xmm0
  77f236:	movaps 0x980(%rsp),%xmm1
  77f23e:	movaps 0x990(%rsp),%xmm2
  77f246:	mov    0x48(%rsp),%rcx
  77f24b:	movups %xmm2,0x28(%rcx)
  77f24f:	movups %xmm1,0x18(%rcx)
  77f253:	movups %xmm0,0x8(%rcx)
  77f257:	mov    %rax,(%rcx)
  77f25a:	mov    $0x1,%r12b
  77f25d:	mov    $0x1,%bl
  77f25f:	mov    $0x1,%r13b
  77f262:	mov    $0x1,%bpl
  77f265:	mov    $0x1,%r15b
  77f268:	cmpq   $0xffffffffffffffff,0x258(%rsp)
  77f271:	jne    780176 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c96>
  77f277:	jmp    780186 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4ca6>
  77f27c:	movq   $0xffffffffffffffff,0x790(%rsp)
  77f288:	mov    %rbx,0x60(%rsp)
  77f28d:	mov    0x278(%rsp),%rax
  77f295:	mov    %rax,0x3a0(%rsp)
  77f29d:	movups 0x268(%rsp),%xmm0
  77f2a5:	movaps %xmm0,0x390(%rsp)
  77f2ad:	lea    0x180(%rsp),%rdi
  77f2b5:	lea    0x790(%rsp),%rsi
  77f2bd:	lea    0x390(%rsp),%rdx
  77f2c5:	call   73d2e0 <_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime8geometry6RecordEE7or_elseNCNvMsu_B1i_INtB1i_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersE_0EB2E_>
  77f2ca:	cmpb   $0x0,0x76d(%r14)
  77f2d2:	je     77f32f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3e4f>
  77f2d4:	lea    0x390(%rsp),%rbx
  77f2dc:	lea    0x970(%rsp),%rsi
  77f2e4:	mov    $0x1f0,%edx
  77f2e9:	mov    %rbx,%rdi
  77f2ec:	call   *0x339c9e(%rip)        # ab8f90 <memcpy@GLIBC_2.14>
  77f2f2:	mov    $0x1,%al
  77f2f4:	mov    %eax,0x58(%rsp)
  77f2f8:	mov    $0x1,%r12b
  77f2fb:	mov    $0x1,%al
  77f2fd:	mov    %eax,0x38(%rsp)
  77f301:	mov    $0x1,%al
  77f303:	mov    %eax,0x30(%rsp)
  77f307:	mov    $0x1,%r15b
  77f30a:	mov    $0x1,%bpl
  77f30d:	movb   $0x1,0xc0(%rsp)
  77f315:	mov    %rbx,%rdi
  77f318:	call   *0x33a2a2(%rip)        # ab95c0 <_DYNAMIC+0x890>
  77f31e:	movq   $0x0,0x80(%rsp)
  77f32a:	jmp    77f3c2 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3ee2>
  77f32f:	lea    0x390(%rsp),%rbx
  77f337:	lea    0x970(%rsp),%rsi
  77f33f:	mov    $0x1f0,%edx
  77f344:	mov    %rbx,%rdi
  77f347:	call   *0x339c43(%rip)        # ab8f90 <memcpy@GLIBC_2.14>
  77f34d:	mov    $0x1,%al
  77f34f:	mov    %eax,0x58(%rsp)
  77f353:	mov    $0x1,%r12b
  77f356:	mov    $0x1,%al
  77f358:	mov    %eax,0x38(%rsp)
  77f35c:	mov    $0x1,%al
  77f35e:	mov    %eax,0x30(%rsp)
  77f362:	mov    $0x1,%r15b
  77f365:	mov    $0x1,%bpl
  77f368:	movb   $0x1,0xc0(%rsp)
  77f370:	mov    %rbx,%rdi
  77f373:	call   *0x33a24f(%rip)        # ab95c8 <_DYNAMIC+0x898>
  77f379:	cmpq   $0xffffffffffffffff,0x5c8(%r14)
  77f381:	je     77f38c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3eac>
  77f383:	mov    0x5e0(%r14),%rsi
  77f38a:	jmp    77f38e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3eae>
  77f38c:	xor    %esi,%esi
  77f38e:	mov    $0x1,%cl
  77f390:	mov    %ecx,0x58(%rsp)
  77f394:	mov    $0x1,%r12b
  77f397:	mov    $0x1,%cl
  77f399:	mov    %ecx,0x38(%rsp)
  77f39d:	mov    $0x1,%cl
  77f39f:	mov    %ecx,0x30(%rsp)
  77f3a3:	mov    $0x1,%r15b
  77f3a6:	mov    $0x1,%bpl
  77f3a9:	movb   $0x1,0xc0(%rsp)
  77f3b1:	mov    %rax,%rdi
  77f3b4:	call   *0x339fce(%rip)        # ab9388 <_DYNAMIC+0x658>
  77f3ba:	mov    %rax,0x80(%rsp)
  77f3c2:	mov    0x658(%r14),%rax
  77f3c9:	mov    0x668(%r14),%r12
  77f3d0:	test   %rax,%rax
  77f3d3:	setne  %cl
  77f3d6:	test   %r12,%r12
  77f3d9:	setne  %dl
  77f3dc:	test   %dl,%cl
  77f3de:	je     77f5ce <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x40ee>
  77f3e4:	mov    0x40(%rsp),%rcx
  77f3e9:	mov    0x660(%rcx),%r13
  77f3f0:	xor    %r14d,%r14d
  77f3f3:	lea    0x390(%rsp),%rbx
  77f3fb:	lea    0x6c0(%rsp),%r15
  77f403:	jmp    77f413 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3f33>
  77f405:	mov    $0x0,%eax
  77f40a:	dec    %r12
  77f40d:	je     77f5ce <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x40ee>
  77f413:	test   %r14,%r14
  77f416:	jne    77f498 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3fb8>
  77f41c:	test   %r13,%r13
  77f41f:	je     77f447 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3f67>
  77f421:	mov    %r13,%rcx
  77f424:	mov    %rax,%r14
  77f427:	and    $0x7,%rcx
  77f42b:	je     77f44c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3f6c>
  77f42d:	xor    %edx,%edx
  77f42f:	nop
  77f430:	mov    0x590(%r14),%r14
  77f437:	inc    %rdx
  77f43a:	cmp    %rdx,%rcx
  77f43d:	jne    77f430 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3f50>
  77f43f:	mov    %r13,%rax
  77f442:	sub    %rdx,%rax
  77f445:	jmp    77f44f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3f6f>
  77f447:	mov    %rax,%r14
  77f44a:	jmp    77f493 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3fb3>
  77f44c:	mov    %r13,%rax
  77f44f:	cmp    $0x8,%r13
  77f453:	jb     77f493 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3fb3>
  77f455:	mov    0x590(%r14),%rcx
  77f45c:	mov    0x590(%rcx),%rcx
  77f463:	mov    0x590(%rcx),%rcx
  77f46a:	mov    0x590(%rcx),%rcx
  77f471:	mov    0x590(%rcx),%rcx
  77f478:	mov    0x590(%rcx),%rcx
  77f47f:	mov    0x590(%rcx),%rcx
  77f486:	mov    0x590(%rcx),%r14
  77f48d:	add    $0xfffffffffffffff8,%rax
  77f491:	jne    77f455 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3f75>
  77f493:	xor    %r13d,%r13d
  77f496:	xor    %eax,%eax
  77f498:	movzwl 0x58a(%r14),%ecx
  77f4a0:	cmp    %rcx,%r13
  77f4a3:	jae    77f4b0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3fd0>
  77f4a5:	mov    %r13,%rdx
  77f4a8:	mov    %r14,%rcx
  77f4ab:	jmp    77f4d7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3ff7>
  77f4ad:	nopl   (%rax)
  77f4b0:	mov    0x580(%r14),%rcx
  77f4b7:	test   %rcx,%rcx
  77f4ba:	je     780465 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4f85>
  77f4c0:	inc    %rax
  77f4c3:	movzwl 0x588(%r14),%edx
  77f4cb:	mov    %rcx,%r14
  77f4ce:	cmp    0x58a(%rcx),%dx
  77f4d5:	jae    77f4b0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3fd0>
  77f4d7:	test   %rax,%rax
  77f4da:	je     77f51a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x403a>
  77f4dc:	lea    (%rcx,%rdx,8),%rsi
  77f4e0:	add    $0x598,%rsi
  77f4e7:	mov    %rax,%rdi
  77f4ea:	and    $0x7,%rdi
  77f4ee:	je     77f523 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4043>
  77f4f0:	xor    %r8d,%r8d
  77f4f3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  77f500:	mov    (%rsi),%r14
  77f503:	lea    0x590(%r14),%rsi
  77f50a:	inc    %r8
  77f50d:	cmp    %r8,%rdi
  77f510:	jne    77f500 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4020>
  77f512:	mov    %rax,%rdi
  77f515:	sub    %r8,%rdi
  77f518:	jmp    77f526 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4046>
  77f51a:	lea    0x1(%rdx),%r13
  77f51e:	mov    %rcx,%r14
  77f521:	jmp    77f574 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4094>
  77f523:	mov    %rax,%rdi
  77f526:	cmp    $0x8,%rax
  77f52a:	jb     77f571 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4091>
  77f52c:	nopl   0x0(%rax)
  77f530:	mov    (%rsi),%rax
  77f533:	mov    0x590(%rax),%rax
  77f53a:	mov    0x590(%rax),%rax
  77f541:	mov    0x590(%rax),%rax
  77f548:	mov    0x590(%rax),%rax
  77f54f:	mov    0x590(%rax),%rax
  77f556:	mov    0x590(%rax),%rax
  77f55d:	mov    0x590(%rax),%r14
  77f564:	lea    0x590(%r14),%rsi
  77f56b:	add    $0xfffffffffffffff8,%rdi
  77f56f:	jne    77f530 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4050>
  77f571:	xor    %r13d,%r13d
  77f574:	mov    %rdx,%rax
  77f577:	shl    $0x4,%rax
  77f57b:	cmpl   $0x1,(%rcx,%rax,1)
  77f57f:	jne    77f405 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3f25>
  77f585:	imul   $0x70,%rdx,%rdx
  77f589:	lea    (%rcx,%rdx,1),%rbp
  77f58d:	add    $0xb0,%rbp
  77f594:	cmpl   $0x2,0x0(%rbp)
  77f598:	jne    77f405 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3f25>
  77f59e:	mov    0x8(%rcx,%rax,1),%rdx
  77f5a3:	mov    %rbx,%rdi
  77f5a6:	mov    %r15,%rsi
  77f5a9:	call   *0x339f81(%rip)        # ab9530 <_DYNAMIC+0x800>
  77f5af:	cmpl   $0x1,0x390(%rsp)
  77f5b7:	jne    77f405 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3f25>
  77f5bd:	movups 0x398(%rsp),%xmm0
  77f5c5:	movups %xmm0,0x8(%rbp)
  77f5c9:	jmp    77f405 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3f25>
  77f5ce:	mov    0x40(%rsp),%r13
  77f5d3:	mov    0x670(%r13),%r8
  77f5da:	mov    0x680(%r13),%rax
  77f5e1:	test   %r8,%r8
  77f5e4:	setne  %cl
  77f5e7:	test   %rax,%rax
  77f5ea:	setne  %dl
  77f5ed:	test   %dl,%cl
  77f5ef:	mov    0xf0(%rsp),%rbx
  77f5f7:	je     77f81d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x433d>
  77f5fd:	mov    0x678(%r13),%rsi
  77f604:	xor    %ecx,%ecx
  77f606:	jmp    77f630 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4150>
  77f608:	mov    $0x1,%r8b
  77f60b:	mov    0xf0(%rsp),%rbx
  77f613:	dec    %rax
  77f616:	shl    $0x5,%rdi
  77f61a:	add    %rdi,%rdx
  77f61d:	mov    %r8b,0x1c(%rdx)
  77f621:	mov    $0x0,%r8d
  77f627:	test   %rax,%rax
  77f62a:	je     77f81d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x433d>
  77f630:	test   %rcx,%rcx
  77f633:	jne    77f6b8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x41d8>
  77f639:	test   %rsi,%rsi
  77f63c:	je     77f667 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4187>
  77f63e:	mov    %rsi,%rdx
  77f641:	mov    %r8,%rcx
  77f644:	and    $0x7,%rdx
  77f648:	je     77f66c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x418c>
  77f64a:	xor    %edi,%edi
  77f64c:	nopl   0x0(%rax)
  77f650:	mov    0x1c8(%rcx),%rcx
  77f657:	inc    %rdi
  77f65a:	cmp    %rdi,%rdx
  77f65d:	jne    77f650 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4170>
  77f65f:	mov    %rsi,%rdx
  77f662:	sub    %rdi,%rdx
  77f665:	jmp    77f66f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x418f>
  77f667:	mov    %r8,%rcx
  77f66a:	jmp    77f6b3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x41d3>
  77f66c:	mov    %rsi,%rdx
  77f66f:	cmp    $0x8,%rsi
  77f673:	jb     77f6b3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x41d3>
  77f675:	mov    0x1c8(%rcx),%rcx
  77f67c:	mov    0x1c8(%rcx),%rcx
  77f683:	mov    0x1c8(%rcx),%rcx
  77f68a:	mov    0x1c8(%rcx),%rcx
  77f691:	mov    0x1c8(%rcx),%rcx
  77f698:	mov    0x1c8(%rcx),%rcx
  77f69f:	mov    0x1c8(%rcx),%rcx
  77f6a6:	mov    0x1c8(%rcx),%rcx
  77f6ad:	add    $0xfffffffffffffff8,%rdx
  77f6b1:	jne    77f675 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4195>
  77f6b3:	xor    %esi,%esi
  77f6b5:	xor    %r8d,%r8d
  77f6b8:	movzwl 0x1c2(%rcx),%edx
  77f6bf:	cmp    %rdx,%rsi
  77f6c2:	jae    77f6d0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x41f0>
  77f6c4:	mov    %rsi,%rdi
  77f6c7:	mov    %rcx,%rdx
  77f6ca:	jmp    77f6f6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4216>
  77f6cc:	nopl   0x0(%rax)
  77f6d0:	mov    0x160(%rcx),%rdx
  77f6d7:	test   %rdx,%rdx
  77f6da:	je     780477 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4f97>
  77f6e0:	inc    %r8
  77f6e3:	movzwl 0x1c0(%rcx),%edi
  77f6ea:	mov    %rdx,%rcx
  77f6ed:	cmp    0x1c2(%rdx),%di
  77f6f4:	jae    77f6d0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x41f0>
  77f6f6:	test   %r8,%r8
  77f6f9:	je     77f73a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x425a>
  77f6fb:	lea    (%rdx,%rdi,8),%rsi
  77f6ff:	add    $0x1d0,%rsi
  77f706:	mov    %r8,%r9
  77f709:	and    $0x7,%r9
  77f70d:	je     77f743 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4263>
  77f70f:	xor    %r10d,%r10d
  77f712:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  77f720:	mov    (%rsi),%rcx
  77f723:	lea    0x1c8(%rcx),%rsi
  77f72a:	inc    %r10
  77f72d:	cmp    %r10,%r9
  77f730:	jne    77f720 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4240>
  77f732:	mov    %r8,%r9
  77f735:	sub    %r10,%r9
  77f738:	jmp    77f746 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4266>
  77f73a:	lea    0x1(%rdi),%rsi
  77f73e:	mov    %rdx,%rcx
  77f741:	jmp    77f793 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x42b3>
  77f743:	mov    %r8,%r9
  77f746:	cmp    $0x8,%r8
  77f74a:	jb     77f791 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x42b1>
  77f74c:	nopl   0x0(%rax)
  77f750:	mov    (%rsi),%rcx
  77f753:	mov    0x1c8(%rcx),%rcx
  77f75a:	mov    0x1c8(%rcx),%rcx
  77f761:	mov    0x1c8(%rcx),%rcx
  77f768:	mov    0x1c8(%rcx),%rcx
  77f76f:	mov    0x1c8(%rcx),%rcx
  77f776:	mov    0x1c8(%rcx),%rcx
  77f77d:	mov    0x1c8(%rcx),%rcx
  77f784:	lea    0x1c8(%rcx),%rsi
  77f78b:	add    $0xfffffffffffffff8,%r9
  77f78f:	jne    77f750 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4270>
  77f791:	xor    %esi,%esi
  77f793:	mov    0x6a8(%rsp),%r8
  77f79b:	test   %r8,%r8
  77f79e:	je     77f815 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4335>
  77f7a0:	mov    0x168(%rdx,%rdi,8),%r9
  77f7a8:	mov    0x6b0(%rsp),%r10
  77f7b0:	movzwl 0x62(%r8),%ebx
  77f7b5:	mov    %ebx,%r14d
  77f7b8:	shl    $0x3,%r14d
  77f7bc:	mov    $0xffffffffffffffff,%r11
  77f7c3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  77f7d0:	test   %r14,%r14
  77f7d3:	je     77f7fd <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x431d>
  77f7d5:	cmp    0x10(%r8,%r11,8),%r9
  77f7da:	seta   %bpl
  77f7de:	sbb    $0x0,%bpl
  77f7e2:	inc    %r11
  77f7e5:	add    $0xfffffffffffffff8,%r14
  77f7e9:	cmp    $0x1,%bpl
  77f7ed:	je     77f7d0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x42f0>
  77f7ef:	movzbl %bpl,%ebx
  77f7f3:	test   %ebx,%ebx
  77f7f5:	je     77f608 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4128>
  77f7fb:	jmp    77f800 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4320>
  77f7fd:	mov    %rbx,%r11
  77f800:	mov    0xf0(%rsp),%rbx
  77f808:	sub    $0x1,%r10
  77f80c:	jb     77f815 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4335>
  77f80e:	mov    0x68(%r8,%r11,8),%r8
  77f813:	jmp    77f7b0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x42d0>
  77f815:	xor    %r8d,%r8d
  77f818:	jmp    77f613 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4133>
  77f81d:	cmpl   $0x2,0xca0(%rsp)
  77f825:	mov    $0x1,%bpl
  77f828:	je     77f865 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4385>
  77f82a:	lea    0x390(%rsp),%rdi
  77f832:	lea    0xca0(%rsp),%rsi
  77f83a:	mov    $0x1e8,%edx
  77f83f:	call   *0x33974b(%rip)        # ab8f90 <memcpy@GLIBC_2.14>
  77f845:	mov    %r13,%rdi
  77f848:	call   74d090 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas6canvas6CanvasECs9C2G9YFESsD_29canonical_text_public_control>
  77f84d:	lea    0x390(%rsp),%rsi
  77f855:	mov    $0x1e8,%edx
  77f85a:	mov    %r13,%rdi
  77f85d:	call   *0x33972d(%rip)        # ab8f90 <memcpy@GLIBC_2.14>
  77f863:	xor    %ebp,%ebp
  77f865:	mov    $0x1,%al
  77f867:	mov    %eax,0x58(%rsp)
  77f86b:	cmpl   $0xffffffff,0x810(%rsp)
  77f873:	mov    $0x1,%al
  77f875:	mov    %eax,0x30(%rsp)
  77f879:	je     77fa18 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4538>
  77f87f:	movups 0x860(%rsp),%xmm0
  77f887:	movaps %xmm0,0x760(%rsp)
  77f88f:	movups 0x850(%rsp),%xmm0
  77f897:	movaps %xmm0,0x750(%rsp)
  77f89f:	movups 0x810(%rsp),%xmm0
  77f8a7:	movups 0x820(%rsp),%xmm1
  77f8af:	movups 0x830(%rsp),%xmm2
  77f8b7:	movupd 0x840(%rsp),%xmm3
  77f8c0:	movapd %xmm3,0x740(%rsp)
  77f8c9:	movaps %xmm2,0x730(%rsp)
  77f8d1:	movaps %xmm1,0x720(%rsp)
  77f8d9:	movaps %xmm0,0x710(%rsp)
  77f8e1:	cmpq   $0x0,(%rbx)
  77f8e5:	je     77f9e9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4509>
  77f8eb:	mov    0x60(%rsp),%rax
  77f8f0:	mov    %rax,0x390(%rsp)
  77f8f8:	lea    0x100(%rsp),%rax
  77f900:	mov    %rax,0x398(%rsp)
  77f908:	lea    0x140(%rsp),%rax
  77f910:	mov    %rax,0x3a0(%rsp)
  77f918:	lea    0x310(%rsp),%rdi
  77f920:	lea    0x6c0(%rsp),%rsi
  77f928:	lea    0x390(%rsp),%rdx
  77f930:	call   73fac0 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_>
  77f935:	lea    0x710(%rsp),%rdi
  77f93d:	call   74e620 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime6scroll14ViewportColumnECs9C2G9YFESsD_29canonical_text_public_control>
  77f942:	mov    0x320(%rsp),%rax
  77f94a:	mov    %rax,0x720(%rsp)
  77f952:	movups 0x310(%rsp),%xmm0
  77f95a:	movaps %xmm0,0x710(%rsp)
  77f962:	mov    (%rbx),%rdi
  77f965:	cmpl   $0xffffffff,0x60(%rdi)
  77f969:	je     77f977 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4497>
  77f96b:	add    $0x60,%rdi
  77f96f:	call   74ea10 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime8metadata5SheetECs9C2G9YFESsD_29canonical_text_public_control>
  77f974:	mov    (%rbx),%rdi
  77f977:	movaps 0x760(%rsp),%xmm0
  77f97f:	movups %xmm0,0xb0(%rdi)
  77f986:	movaps 0x750(%rsp),%xmm0
  77f98e:	movups %xmm0,0xa0(%rdi)
  77f995:	movaps 0x710(%rsp),%xmm0
  77f99d:	mov    0x720(%rsp),%rax
  77f9a5:	mov    0x728(%rsp),%rcx
  77f9ad:	movaps 0x730(%rsp),%xmm1
  77f9b5:	movaps 0x740(%rsp),%xmm2
  77f9bd:	movups %xmm2,0x90(%rdi)
  77f9c4:	movups %xmm1,0x80(%rdi)
  77f9cb:	mov    %rax,0x70(%rdi)
  77f9cf:	mov    %rcx,0x78(%rdi)
  77f9d3:	movups %xmm0,0x60(%rdi)
  77f9d7:	movl   $0x0,0x58(%rsp)
  77f9df:	movl   $0x0,0x30(%rsp)
  77f9e7:	jmp    77fa18 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4538>
  77f9e9:	mov    $0x1,%al
  77f9eb:	mov    %eax,0x58(%rsp)
  77f9ef:	movl   $0x0,0x30(%rsp)
  77f9f7:	lea    0x710(%rsp),%rdi
  77f9ff:	mov    $0x1,%r12b
  77fa02:	mov    $0x1,%al
  77fa04:	mov    %eax,0x38(%rsp)
  77fa08:	mov    $0x1,%r15b
  77fa0b:	movb   $0x1,0xc0(%rsp)
  77fa13:	call   74ea10 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime8metadata5SheetECs9C2G9YFESsD_29canonical_text_public_control>
  77fa18:	mov    0x180(%rsp),%r15
  77fa20:	cmp    $0xffffffffffffffff,%r15
  77fa24:	sete   0xc0(%rsp)
  77fa2c:	je     77fa8f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x45af>
  77fa2e:	mov    0x188(%rsp),%r13
  77fa36:	mov    0x190(%rsp),%r14
  77fa3e:	mov    %rbx,%rdi
  77fa41:	call   73d4f0 <_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionINtNtCscdodAO9FK5_5alloc5boxed3BoxNtNtNtCslbxve4rcJus_4gpui7runtime8metadata8MetadataEE18get_or_insert_withNvYBI_NtNtB5_7default7Default7defaultECs9C2G9YFESsD_29canonical_text_public_control>
  77fa46:	mov    %rbx,%rax
  77fa49:	mov    $0x100,%ebx
  77fa4e:	add    (%rax),%rbx
  77fa51:	mov    %rbx,%rdi
  77fa54:	call   73d350 <_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionINtNtCscdodAO9FK5_5alloc5boxed3BoxNtNtNtCslbxve4rcJus_4gpui7runtime8geometry8GeometryEE18get_or_insert_withNvYBI_NtNtB5_7default7Default7defaultECs9C2G9YFESsD_29canonical_text_public_control>
  77fa59:	mov    (%rbx),%rdi
  77fa5c:	mov    %r15,0x390(%rsp)
  77fa64:	mov    %r13,0x398(%rsp)
  77fa6c:	mov    %r14,0x3a0(%rsp)
  77fa74:	lea    0x390(%rsp),%rsi
  77fa7c:	call   *0x339b4e(%rip)        # ab95d0 <_DYNAMIC+0x8a0>
  77fa82:	mov    0x40(%rsp),%r13
  77fa87:	mov    0xf0(%rsp),%rbx
  77fa8f:	cmpq   $0xffffffffffffffff,0x258(%rsp)
  77fa98:	je     77fac9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x45e9>
  77fa9a:	mov    0x2d8(%rsp),%rax
  77faa2:	mov    (%rax),%rdi
  77faa5:	test   %rdi,%rdi
  77faa8:	je     780447 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4f67>
  77faae:	lea    0x8b8(%rsp),%rdx
  77fab6:	mov    0x260(%rsp),%rsi
  77fabe:	call   *0x339b14(%rip)        # ab95d8 <_DYNAMIC+0x8a8>
  77fac4:	xor    %r14d,%r14d
  77fac7:	jmp    77facc <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x45ec>
  77fac9:	mov    $0x1,%r14b
  77facc:	mov    0xa8(%rsp),%rax
  77fad4:	cmpl   $0x3,(%rax)
  77fad7:	jne    77fae8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4608>
  77fad9:	mov    0x208(%r13),%rax
  77fae0:	movq   $0x0,0x58(%rax)
  77fae8:	mov    (%rbx),%rax
  77faeb:	test   %rax,%rax
  77faee:	je     77fb37 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4657>
  77faf0:	mov    0xe0(%rax),%rax
  77faf7:	test   %rax,%rax
  77fafa:	je     77fb37 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4657>
  77fafc:	mov    0x678(%rsp),%rcx
  77fb04:	mov    %rcx,0x40(%rax)
  77fb08:	mov    0x2e8(%rsp),%rcx
  77fb10:	mov    %rcx,0x48(%rax)
  77fb14:	mov    0x2f0(%rsp),%ecx
  77fb1b:	mov    %ecx,0x50(%rax)
  77fb1e:	movzbl 0x57(%rsp),%ecx
  77fb23:	mov    %cl,0x54(%rax)
  77fb26:	movzwl 0x7a(%rsp),%ecx
  77fb2b:	mov    %cx,0x55(%rax)
  77fb2f:	movzbl 0x7c(%rsp),%ecx
  77fb34:	mov    %cl,0x57(%rax)
  77fb37:	mov    0x6e8(%r13),%rdi
  77fb3e:	test   %rdi,%rdi
  77fb41:	mov    %r14d,0x38(%rsp)
  77fb46:	je     77fb7c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x469c>
  77fb48:	cmpq   $0xffffffffffffffff,0x18(%rdi)
  77fb4d:	je     77fb5f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x467f>
  77fb4f:	add    $0x18,%rdi
  77fb53:	call   7476c0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime13text_geometry5EntryEECs9C2G9YFESsD_29canonical_text_public_control>
  77fb58:	mov    0x6e8(%r13),%rdi
  77fb5f:	mov    0x210(%rsp),%rax
  77fb67:	mov    %rax,0x28(%rdi)
  77fb6b:	movups 0x200(%rsp),%xmm0
  77fb73:	movups %xmm0,0x18(%rdi)
  77fb77:	xor    %r12d,%r12d
  77fb7a:	jmp    77fb7f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x469f>
  77fb7c:	mov    $0x1,%r12b
  77fb7f:	mov    0x150(%rsp),%rax
  77fb87:	mov    %rax,0x3a0(%rsp)
  77fb8f:	movups 0x140(%rsp),%xmm0
  77fb97:	movaps %xmm0,0x390(%rsp)
  77fb9f:	lea    0x5c8(%r13),%r15
  77fba6:	cmpq   $0xffffffffffffffff,0x5c8(%r13)
  77fbae:	je     77fbb8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x46d8>
  77fbb0:	mov    %r15,%rdi
  77fbb3:	call   747260 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCslbxve4rcJus_4gpui7runtime9PresentedEECs9C2G9YFESsD_29canonical_text_public_control>
  77fbb8:	mov    0x3a0(%rsp),%rax
  77fbc0:	mov    %rax,0x10(%r15)
  77fbc4:	movaps 0x390(%rsp),%xmm0
  77fbcc:	movups %xmm0,(%r15)
  77fbd0:	mov    0x80(%rsp),%rax
  77fbd8:	mov    %rax,0x5e0(%r13)
  77fbdf:	mov    0xf8(%rsp),%rax
  77fbe7:	mov    %ax,0x5e8(%r13)
  77fbef:	mov    0x2e0(%rsp),%rax
  77fbf7:	mov    %ax,0x5ea(%r13)
  77fbff:	movss  0x9c(%rsp),%xmm0
  77fc08:	movss  %xmm0,0x5ec(%r13)
  77fc11:	xor    %r15d,%r15d
  77fc14:	mov    %r13,%rdi
  77fc17:	call   76e910 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11prune_focusBW_>
  77fc1c:	mov    0x680(%rsp),%rax
  77fc24:	mov    %rax,0x6d0(%r13)
  77fc2b:	mov    0x260(%rsp),%rax
  77fc33:	mov    %rax,0x6d8(%r13)
  77fc3a:	mov    0x6a0(%r13),%rax
  77fc41:	mov    0x6e8(%r13),%rdi
  77fc48:	mov    %rax,0x6e0(%r13)
  77fc4f:	mov    0x8b0(%rsp),%rax
  77fc57:	mov    %rax,0x5f8(%r13)
  77fc5e:	cmpq   $0x0,0x2f8(%r13)
  77fc66:	setne  %al
  77fc69:	test   %rdi,%rdi
  77fc6c:	sete   %cl
  77fc6f:	or     %al,%cl
  77fc71:	cmp    $0x1,%cl
  77fc74:	je     77fc8e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x47ae>
  77fc76:	add    $0x30,%rdi
  77fc7a:	call   745d70 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtCsghYClfd3M9V_11gpui_canvas4text10TextSystemEECs9C2G9YFESsD_29canonical_text_public_control>
  77fc7f:	mov    0x6e8(%r13),%rax
  77fc86:	movq   $0x0,0x30(%rax)
  77fc8e:	movb   $0x0,0x76b(%r13)
  77fc96:	movw   $0x0,0x768(%r13)
  77fca0:	lea    0x688(%r13),%rdi
  77fca7:	xor    %r15d,%r15d
  77fcaa:	call   775a20 <_RNvMsh_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapyNtNtB7_7set_val9SetValZSTE5clearCs9C2G9YFESsD_29canonical_text_public_control>
  77fcaf:	cmpb   $0x0,0x76d(%r13)
  77fcb7:	je     77fcee <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x480e>
  77fcb9:	xor    %r15d,%r15d
  77fcbc:	lea    0x390(%rsp),%rdi
  77fcc4:	mov    %r13,%rsi
  77fcc7:	mov    0x680(%rsp),%rdx
  77fccf:	mov    0x260(%rsp),%rcx
  77fcd7:	call   77aeb0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_>
  77fcdc:	mov    0x390(%rsp),%rax
  77fce4:	cmp    $0xfffffffffffffffe,%rax
  77fce8:	jne    77fe26 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4946>
  77fcee:	mov    0x48(%rsp),%rax
  77fcf3:	movq   $0xfffffffffffffffe,(%rax)
  77fcfa:	cmpb   $0x0,0x58(%rsp)
  77fcff:	je     77fd0e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x482e>
  77fd01:	lea    0x6c0(%rsp),%rdi
  77fd09:	call   74e5d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime6scroll13ViewportBuildECs9C2G9YFESsD_29canonical_text_public_control>
  77fd0e:	xor    %r13d,%r13d
  77fd11:	lea    0x6a8(%rsp),%rdi
  77fd19:	call   74ac70 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtCscdodAO9FK5_5alloc11collections5btree3set8BTreeSetNtNtCslbxve4rcJus_4gpui4list6ListIdEECs9C2G9YFESsD_29canonical_text_public_control>
  77fd1e:	mov    0x100(%rsp),%rsi
  77fd26:	test   %rsi,%rsi
  77fd29:	je     77fd42 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4862>
  77fd2b:	mov    0x108(%rsp),%rdi
  77fd33:	shl    $0x2,%rsi
  77fd37:	mov    $0x4,%edx
  77fd3c:	call   *0x33922e(%rip)        # ab8f70 <_DYNAMIC+0x240>
  77fd42:	mov    0x158(%rsp),%rsi
  77fd4a:	test   %rsi,%rsi
  77fd4d:	je     77fd62 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4882>
  77fd4f:	mov    0x160(%rsp),%rdi
  77fd57:	mov    $0x1,%edx
  77fd5c:	call   *0x33920e(%rip)        # ab8f70 <_DYNAMIC+0x240>
  77fd62:	mov    0x230(%rsp),%rsi
  77fd6a:	test   %rsi,%rsi
  77fd6d:	je     77fd86 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x48a6>
  77fd6f:	mov    0x238(%rsp),%rdi
  77fd77:	shl    $0x4,%rsi
  77fd7b:	mov    $0x4,%edx
  77fd80:	call   *0x3391ea(%rip)        # ab8f70 <_DYNAMIC+0x240>
  77fd86:	mov    0x218(%rsp),%rsi
  77fd8e:	test   %rsi,%rsi
  77fd91:	je     77fdaa <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x48ca>
  77fd93:	mov    0x220(%rsp),%rdi
  77fd9b:	shl    $0x4,%rsi
  77fd9f:	mov    $0x4,%edx
  77fda4:	call   *0x3391c6(%rip)        # ab8f70 <_DYNAMIC+0x240>
  77fdaa:	mov    0x1d8(%rsp),%rax
  77fdb2:	test   %rax,%rax
  77fdb5:	je     77fdce <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x48ee>
  77fdb7:	mov    0x1e0(%rsp),%rdi
  77fdbf:	imul   $0x38,%rax,%rsi
  77fdc3:	mov    $0x8,%edx
  77fdc8:	call   *0x3391a2(%rip)        # ab8f70 <_DYNAMIC+0x240>
  77fdce:	cmpq   $0x0,0x1c0(%rsp)
  77fdd7:	je     77fde6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4906>
  77fdd9:	mov    0x1c8(%rsp),%rdi
  77fde1:	call   74caf0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text10TextShaperECs9C2G9YFESsD_29canonical_text_public_control>
  77fde6:	test   %r12b,%r12b
  77fde9:	je     77fdf8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4918>
  77fdeb:	lea    0x200(%rsp),%rdi
  77fdf3:	call   7476c0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime13text_geometry5EntryEECs9C2G9YFESsD_29canonical_text_public_control>
  77fdf8:	mov    0xd0(%rsp),%rax
  77fe00:	test   %rax,%rax
  77fe03:	je     77cd21 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1841>
  77fe09:	lock decq (%rax)
  77fe0d:	jne    77cd21 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1841>
  77fe13:	lea    0xd0(%rsp),%rdi
  77fe1b:	call   *0x33923f(%rip)        # ab9060 <_DYNAMIC+0x330>
  77fe21:	jmp    77cd21 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1841>
  77fe26:	mov    0x3b8(%rsp),%rcx
  77fe2e:	movzbl 0x3c0(%rsp),%edx
  77fe36:	mov    0x3c1(%rsp),%esi
  77fe3d:	mov    %esi,0x310(%rsp)
  77fe44:	mov    0x3c4(%rsp),%esi
  77fe4b:	mov    %esi,0x313(%rsp)
  77fe52:	movups 0x398(%rsp),%xmm0
  77fe5a:	movups 0x3a8(%rsp),%xmm1
  77fe62:	mov    0x310(%rsp),%esi
  77fe69:	mov    0x313(%rsp),%edi
  77fe70:	mov    0x48(%rsp),%r8
  77fe75:	mov    %edi,0x34(%r8)
  77fe79:	mov    %esi,0x31(%r8)
  77fe7d:	mov    %rax,(%r8)
  77fe80:	movups %xmm0,0x8(%r8)
  77fe85:	movups %xmm1,0x18(%r8)
  77fe8a:	mov    %rcx,0x28(%r8)
  77fe8e:	mov    %dl,0x30(%r8)
  77fe92:	xor    %r13d,%r13d
  77fe95:	cmpb   $0x0,0x58(%rsp)
  77fe9a:	mov    0x30(%rsp),%ebx
  77fe9e:	mov    0x38(%rsp),%r14d
  77fea3:	jne    780155 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c75>
  77fea9:	jmp    780162 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c82>
  77feae:	movzbl 0x391(%rsp),%eax
  77feb6:	mov    0x48(%rsp),%rcx
  77febb:	movq   $0x22,(%rcx)
  77fec2:	mov    %al,0x8(%rcx)
  77fec5:	jmp    78013a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c5a>
  77feca:	mov    0x48(%rsp),%rax
  77fecf:	movq   $0x1f,(%rax)
  77fed6:	jmp    77cd21 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1841>
  77fedb:	lea    0x394(%rsp),%rcx
  77fee3:	mov    0x14(%rcx),%rax
  77fee7:	movups 0x4(%rcx),%xmm0
  77feeb:	movaps %xmm0,0x120(%rsp)
  77fef3:	mov    %rax,0x130(%rsp)
  77fefb:	mov    0x48(%rsp),%rcx
  77ff00:	mov    %rax,0x18(%rcx)
  77ff04:	movups %xmm0,0x8(%rcx)
  77ff08:	movq   $0x23,(%rcx)
  77ff0f:	jmp    78013a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c5a>
  77ff14:	mov    0x48(%rsp),%rcx
  77ff19:	movq   $0x23,(%rcx)
  77ff20:	mov    %eax,0x8(%rcx)
  77ff23:	mov    %edx,0xc(%rcx)
  77ff26:	jmp    78013a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c5a>
  77ff2b:	mov    0x3c0(%rsp),%rcx
  77ff33:	mov    0x48(%rsp),%rdx
  77ff38:	mov    %rcx,0x30(%rdx)
  77ff3c:	movups 0x3a0(%rsp),%xmm0
  77ff44:	movups 0x3b0(%rsp),%xmm1
  77ff4c:	movups %xmm1,0x20(%rdx)
  77ff50:	movups %xmm0,0x10(%rdx)
  77ff54:	mov    %rax,(%rdx)
  77ff57:	mov    %r15,0x8(%rdx)
  77ff5b:	jmp    78013a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c5a>
  77ff60:	mov    0x3c0(%rsp),%rax
  77ff68:	mov    0x48(%rsp),%rcx
  77ff6d:	mov    %rax,0x30(%rcx)
  77ff71:	movups 0x390(%rsp),%xmm0
  77ff79:	movups 0x3a0(%rsp),%xmm1
  77ff81:	movups 0x3b0(%rsp),%xmm2
  77ff89:	movups %xmm2,0x20(%rcx)
  77ff8d:	movups %xmm1,0x10(%rcx)
  77ff91:	movups %xmm0,(%rcx)
  77ff94:	jmp    78013a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c5a>
  77ff99:	mov    0x30(%rsp),%rax
  77ff9e:	mov    0x20(%rax,%r13,1),%esi
  77ffa3:	lea    0x390(%rsp),%rdi
  77ffab:	lea    0x8d0(%rsp),%rdx
  77ffb3:	call   75e110 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersn_0BQ_>
  77ffb8:	mov    0x3c0(%rsp),%rax
  77ffc0:	mov    %rax,0x900(%rsp)
  77ffc8:	movups 0x390(%rsp),%xmm0
  77ffd0:	movups 0x3a0(%rsp),%xmm1
  77ffd8:	movups 0x3b0(%rsp),%xmm2
  77ffe0:	movaps %xmm2,0x8f0(%rsp)
  77ffe8:	movaps %xmm1,0x8e0(%rsp)
  77fff0:	movaps %xmm0,0x8d0(%rsp)
  77fff8:	mov    0x8d0(%rsp),%rax
  780000:	mov    0x8f8(%rsp),%rcx
  780008:	mov    0x48(%rsp),%rdx
  78000d:	mov    %rcx,0x28(%rdx)
  780011:	mov    0x900(%rsp),%rcx
  780019:	mov    %rcx,0x30(%rdx)
  78001d:	lea    0x8d8(%rsp),%rcx
  780025:	movups (%rcx),%xmm0
  780028:	movups 0x10(%rcx),%xmm1
  78002c:	movups %xmm0,0x8(%rdx)
  780030:	movups %xmm1,0x18(%rdx)
  780034:	mov    %rax,(%rdx)
  780037:	jmp    78013a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c5a>
  78003c:	mov    0x48(%rsp),%rcx
  780041:	movq   $0x23,(%rcx)
  780048:	mov    %eax,0x8(%rcx)
  78004b:	mov    %edx,0xc(%rcx)
  78004e:	jmp    78011e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c3e>
  780053:	lea    0x394(%rsp),%rcx
  78005b:	mov    0x14(%rcx),%rax
  78005f:	movups 0x4(%rcx),%xmm0
  780063:	movaps %xmm0,0x120(%rsp)
  78006b:	mov    %rax,0x130(%rsp)
  780073:	mov    0x48(%rsp),%rcx
  780078:	mov    %rax,0x18(%rcx)
  78007c:	movups %xmm0,0x8(%rcx)
  780080:	movq   $0x23,(%rcx)
  780087:	jmp    78011e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c3e>
  78008c:	lea    0x394(%rsp),%rcx
  780094:	mov    0x14(%rcx),%rax
  780098:	movups 0x4(%rcx),%xmm0
  78009c:	movaps %xmm0,0x120(%rsp)
  7800a4:	mov    %rax,0x130(%rsp)
  7800ac:	mov    0x48(%rsp),%rcx
  7800b1:	mov    %rax,0x18(%rcx)
  7800b5:	movups %xmm0,0x8(%rcx)
  7800b9:	movq   $0x23,(%rcx)
  7800c0:	jmp    7800d4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4bf4>
  7800c2:	mov    0x48(%rsp),%rcx
  7800c7:	movq   $0x23,(%rcx)
  7800ce:	mov    %eax,0x8(%rcx)
  7800d1:	mov    %edx,0xc(%rcx)
  7800d4:	mov    0x1f8(%rsp),%rax
  7800dc:	test   %rax,%rax
  7800df:	je     78013a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c5a>
  7800e1:	lock decq (%rax)
  7800e5:	jne    78013a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c5a>
  7800e7:	lea    0x1f8(%rsp),%rdi
  7800ef:	call   *0x338f9b(%rip)        # ab9090 <_DYNAMIC+0x360>
  7800f5:	jmp    78013a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c5a>
  7800f7:	mov    0x48(%rsp),%rax
  7800fc:	movq   $0x18,(%rax)
  780103:	jmp    78011e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c3e>
  780105:	mov    0x124(%rsp),%ecx
  78010c:	mov    0x48(%rsp),%rdx
  780111:	movq   $0x23,(%rdx)
  780118:	mov    %eax,0x8(%rdx)
  78011b:	mov    %ecx,0xc(%rdx)
  78011e:	mov    0x300(%rsp),%rax
  780126:	lock decq (%rax)
  78012a:	jne    78013a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c5a>
  78012c:	lea    0x300(%rsp),%rdi
  780134:	call   *0x338f56(%rip)        # ab9090 <_DYNAMIC+0x360>
  78013a:	lea    0x970(%rsp),%rdi
  780142:	call   74d090 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas6canvas6CanvasECs9C2G9YFESsD_29canonical_text_public_control>
  780147:	mov    $0x1,%r12b
  78014a:	mov    $0x1,%r14b
  78014d:	mov    $0x1,%bl
  78014f:	mov    $0x1,%r13b
  780152:	mov    $0x1,%bpl
  780155:	lea    0x6c0(%rsp),%rdi
  78015d:	call   74e5d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime6scroll13ViewportBuildECs9C2G9YFESsD_29canonical_text_public_control>
  780162:	cmpq   $0xffffffffffffffff,0x258(%rsp)
  78016b:	setne  %al
  78016e:	mov    %r13d,%r15d
  780171:	test   %r14b,%al
  780174:	je     780186 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4ca6>
  780176:	lea    0x8b8(%rsp),%rdi
  78017e:	call   746ea0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCsghYClfd3M9V_11gpui_canvas5image5ImageEECs9C2G9YFESsD_29canonical_text_public_control>
  780183:	mov    %r15d,%r13d
  780186:	cmpl   $0xffffffff,0x810(%rsp)
  78018e:	je     7801a1 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4cc1>
  780190:	test   %bl,%bl
  780192:	je     7801a1 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4cc1>
  780194:	lea    0x810(%rsp),%rdi
  78019c:	call   74ea10 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime8metadata5SheetECs9C2G9YFESsD_29canonical_text_public_control>
  7801a1:	lea    0x6a8(%rsp),%rdi
  7801a9:	call   74ac70 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtCscdodAO9FK5_5alloc11collections5btree3set8BTreeSetNtNtCslbxve4rcJus_4gpui4list6ListIdEECs9C2G9YFESsD_29canonical_text_public_control>
  7801ae:	mov    0x100(%rsp),%rsi
  7801b6:	test   %rsi,%rsi
  7801b9:	je     7801d2 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4cf2>
  7801bb:	mov    0x108(%rsp),%rdi
  7801c3:	shl    $0x2,%rsi
  7801c7:	mov    $0x4,%edx
  7801cc:	call   *0x338d9e(%rip)        # ab8f70 <_DYNAMIC+0x240>
  7801d2:	mov    0x158(%rsp),%rsi
  7801da:	test   %rsi,%rsi
  7801dd:	je     7801f2 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4d12>
  7801df:	mov    0x160(%rsp),%rdi
  7801e7:	mov    $0x1,%edx
  7801ec:	call   *0x338d7e(%rip)        # ab8f70 <_DYNAMIC+0x240>
  7801f2:	mov    0x230(%rsp),%rsi
  7801fa:	test   %rsi,%rsi
  7801fd:	je     780216 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4d36>
  7801ff:	mov    0x238(%rsp),%rdi
  780207:	shl    $0x4,%rsi
  78020b:	mov    $0x4,%edx
  780210:	call   *0x338d5a(%rip)        # ab8f70 <_DYNAMIC+0x240>
  780216:	mov    0x218(%rsp),%rsi
  78021e:	test   %rsi,%rsi
  780221:	je     78023a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4d5a>
  780223:	mov    0x220(%rsp),%rdi
  78022b:	shl    $0x4,%rsi
  78022f:	mov    $0x4,%edx
  780234:	call   *0x338d36(%rip)        # ab8f70 <_DYNAMIC+0x240>
  78023a:	mov    0x1d8(%rsp),%rax
  780242:	test   %rax,%rax
  780245:	je     78025e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4d7e>
  780247:	mov    0x1e0(%rsp),%rdi
  78024f:	imul   $0x38,%rax,%rsi
  780253:	mov    $0x8,%edx
  780258:	call   *0x338d12(%rip)        # ab8f70 <_DYNAMIC+0x240>
  78025e:	test   %r13b,%r13b
  780261:	je     780294 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4db4>
  780263:	mov    0x268(%rsp),%rsi
  78026b:	test   %rsi,%rsi
  78026e:	je     780287 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4da7>
  780270:	mov    0x270(%rsp),%rdi
  780278:	shl    $0x4,%rsi
  78027c:	mov    $0x4,%edx
  780281:	call   *0x338ce9(%rip)        # ab8f70 <_DYNAMIC+0x240>
  780287:	lea    0x140(%rsp),%rdi
  78028f:	call   747260 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCslbxve4rcJus_4gpui7runtime9PresentedEECs9C2G9YFESsD_29canonical_text_public_control>
  780294:	mov    0x7c8(%rsp),%rax
  78029c:	cmp    $0xfffffffffffffffe,%rax
  7802a0:	jne    77c8f1 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1411>
  7802a6:	jmp    77ccba <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17da>
  7802ab:	lea    -0x6ad9a2(%rip),%rdi        # d2910 <GCC_except_table0+0x10570>
  7802b2:	lea    0x31a027(%rip),%rdx        # a9a2e0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1b08>
  7802b9:	mov    $0x83,%esi
  7802be:	call   *0x338ce4(%rip)        # ab8fa8 <_DYNAMIC+0x278>
  7802c4:	jmp    780668 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  7802c9:	lea    -0x6adc40(%rip),%rdi        # d2690 <GCC_except_table0+0x102f0>
  7802d0:	lea    0x319b39(%rip),%rdx        # a99e10 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1638>
  7802d7:	mov    $0x1c,%esi
  7802dc:	call   *0x338d66(%rip)        # ab9048 <_DYNAMIC+0x318>
  7802e2:	jmp    780668 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  7802e7:	mov    $0x1,%bpl
  7802ea:	mov    $0x8,%edi
  7802ef:	mov    $0x78,%esi
  7802f4:	call   *0x338c8e(%rip)        # ab8f88 <_DYNAMIC+0x258>
  7802fa:	jmp    780668 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  7802ff:	lea    0x318d82(%rip),%rdi        # a99088 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x8b0>
  780306:	call   *0x338d0c(%rip)        # ab9018 <_DYNAMIC+0x2e8>
  78030c:	jmp    780668 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  780311:	lea    -0x6ad9c7(%rip),%rax        # d2951 <GCC_except_table0+0x105b1>
  780318:	mov    %rax,0x250(%rsp)
  780320:	lea    0x31a171(%rip),%rax        # a9a498 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1cc0>
  780327:	jmp    780373 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4e93>
  780329:	lea    0x318ea8(%rip),%rax        # a991d8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xa00>
  780330:	mov    %rax,0x658(%rsp)
  780338:	mov    0x658(%rsp),%rdi
  780340:	call   *0x338cd2(%rip)        # ab9018 <_DYNAMIC+0x2e8>
  780346:	jmp    780668 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  78034b:	lea    0x318d36(%rip),%rdi        # a99088 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x8b0>
  780352:	call   *0x338cc0(%rip)        # ab9018 <_DYNAMIC+0x2e8>
  780358:	jmp    780668 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  78035d:	lea    -0x6ada13(%rip),%rax        # d2951 <GCC_except_table0+0x105b1>
  780364:	mov    %rax,0x250(%rsp)
  78036c:	lea    0x31a13d(%rip),%rax        # a9a4b0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1cd8>
  780373:	mov    %rax,0x248(%rsp)
  78037b:	jmp    7803f7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4f17>
  78037d:	mov    0x3a0(%rsp),%rsi
  780385:	mov    $0x1,%bpl
  780388:	call   *0x338c9a(%rip)        # ab9028 <_DYNAMIC+0x2f8>
  78038e:	jmp    780668 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  780393:	mov    0x3a0(%rsp),%rsi
  78039b:	call   *0x338c87(%rip)        # ab9028 <_DYNAMIC+0x2f8>
  7803a1:	jmp    780668 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  7803a6:	mov    0x3a0(%rsp),%rsi
  7803ae:	call   *0x338c74(%rip)        # ab9028 <_DYNAMIC+0x2f8>
  7803b4:	jmp    780668 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  7803b9:	mov    0x3a0(%rsp),%rsi
  7803c1:	call   *0x338c61(%rip)        # ab9028 <_DYNAMIC+0x2f8>
  7803c7:	jmp    780668 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  7803cc:	mov    0x3a0(%rsp),%rsi
  7803d4:	call   *0x338c4e(%rip)        # ab9028 <_DYNAMIC+0x2f8>
  7803da:	jmp    780668 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  7803df:	mov    0x3a0(%rsp),%rsi
  7803e7:	call   *0x338c3b(%rip)        # ab9028 <_DYNAMIC+0x2f8>
  7803ed:	jmp    780668 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  7803f2:	mov    $0x1f,%esi
  7803f7:	mov    0x250(%rsp),%rdi
  7803ff:	mov    0x248(%rsp),%rdx
  780407:	call   *0x338c3b(%rip)        # ab9048 <_DYNAMIC+0x318>
  78040d:	jmp    780668 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  780412:	lea    -0x6adb09(%rip),%rdi        # d2910 <GCC_except_table0+0x10570>
  780419:	lea    0x319ec0(%rip),%rdx        # a9a2e0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1b08>
  780420:	mov    $0x83,%esi
  780425:	call   *0x338b7d(%rip)        # ab8fa8 <_DYNAMIC+0x278>
  78042b:	jmp    780668 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  780430:	movb   $0x1,0x60(%rsp)
  780435:	lea    0x31a0a4(%rip),%rdi        # a9a4e0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1d08>
  78043c:	call   *0x338bd6(%rip)        # ab9018 <_DYNAMIC+0x2e8>
  780442:	jmp    780668 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  780447:	lea    0x319fba(%rip),%rdi        # a9a408 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1c30>
  78044e:	call   *0x338bc4(%rip)        # ab9018 <_DYNAMIC+0x2e8>
  780454:	jmp    780668 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  780459:	lea    0x318c70(%rip),%rax        # a990d0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x8f8>
  780460:	jmp    7804ef <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x500f>
  780465:	lea    0x318c34(%rip),%rdi        # a990a0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x8c8>
  78046c:	call   *0x338ba6(%rip)        # ab9018 <_DYNAMIC+0x2e8>
  780472:	jmp    780668 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  780477:	lea    0x318c22(%rip),%rdi        # a990a0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x8c8>
  78047e:	call   *0x338b94(%rip)        # ab9018 <_DYNAMIC+0x2e8>
  780484:	jmp    780668 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  780489:	lea    0x319ef0(%rip),%rax        # a9a380 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1ba8>
  780490:	jmp    7804ef <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x500f>
  780492:	lea    0x319eff(%rip),%rax        # a9a398 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1bc0>
  780499:	jmp    7804ef <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x500f>
  78049b:	lea    0x319786(%rip),%rax        # a99c28 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1450>
  7804a2:	jmp    7804ef <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x500f>
  7804a4:	lea    0x319765(%rip),%rax        # a99c10 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1438>
  7804ab:	jmp    7804ef <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x500f>
  7804ad:	mov    %rbp,%r12
  7804b0:	lea    0x319771(%rip),%rax        # a99c28 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1450>
  7804b7:	jmp    7804ef <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x500f>
  7804b9:	mov    %rax,%r12
  7804bc:	jmp    7804e8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5008>
  7804be:	mov    %rbp,%r12
  7804c1:	lea    0x319748(%rip),%rax        # a99c10 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1438>
  7804c8:	jmp    7804ef <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x500f>
  7804ca:	mov    %rax,%r13
  7804cd:	lea    0x31973c(%rip),%rax        # a99c10 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1438>
  7804d4:	jmp    7804ef <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x500f>
  7804d6:	mov    %rax,%r13
  7804d9:	lea    0x319748(%rip),%rax        # a99c28 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1450>
  7804e0:	jmp    7804ef <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x500f>
  7804e2:	mov    %rcx,%r12
  7804e5:	mov    %rax,%r13
  7804e8:	lea    0x319751(%rip),%rax        # a99c40 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1468>
  7804ef:	mov    %rax,0x80(%rsp)
  7804f7:	mov    %r12,%rdi
  7804fa:	mov    %r13,%rsi
  7804fd:	mov    0x80(%rsp),%rdx
  780505:	call   *0x338a95(%rip)        # ab8fa0 <_DYNAMIC+0x270>
  78050b:	jmp    780668 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  780510:	mov    $0x1,%r12b
  780513:	lea    0x319eae(%rip),%rdx        # a9a3c8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1bf0>
  78051a:	mov    $0x1,%bpl
  78051d:	xor    %edi,%edi
  78051f:	xor    %esi,%esi
  780521:	call   *0x338a79(%rip)        # ab8fa0 <_DYNAMIC+0x270>
  780527:	jmp    780668 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  78052c:	lea    -0x6adc23(%rip),%rdi        # d2910 <GCC_except_table0+0x10570>
  780533:	lea    0x319da6(%rip),%rdx        # a9a2e0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1b08>
  78053a:	mov    $0x83,%esi
  78053f:	call   *0x338a63(%rip)        # ab8fa8 <_DYNAMIC+0x278>
  780545:	jmp    780668 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  78054a:	movb   $0x1,0x60(%rsp)
  78054f:	lea    -0x6adc46(%rip),%rdi        # d2910 <GCC_except_table0+0x10570>
  780556:	lea    0x319d83(%rip),%rdx        # a9a2e0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1b08>
  78055d:	mov    $0x83,%esi
  780562:	call   *0x338a40(%rip)        # ab8fa8 <_DYNAMIC+0x278>
  780568:	jmp    780668 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  78056d:	mov    %rsi,%rax
  780570:	lea    0x319ed9(%rip),%rcx        # a9a450 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1c78>
  780577:	jmp    780628 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5148>
  78057c:	mov    %rsi,%rax
  78057f:	lea    0x319ee2(%rip),%rcx        # a9a468 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1c90>
  780586:	jmp    780628 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5148>
  78058b:	mov    %rsi,%rax
  78058e:	lea    0x319eeb(%rip),%rcx        # a9a480 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1ca8>
  780595:	jmp    780628 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5148>
  78059a:	mov    %rbx,0x38(%rsp)
  78059f:	mov    %rsi,%rax
  7805a2:	lea    0x318bff(%rip),%rcx        # a991a8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x9d0>
  7805a9:	jmp    780628 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5148>
  7805ab:	mov    %rcx,0x38(%rsp)
  7805b0:	lea    0x318c09(%rip),%rcx        # a991c0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x9e8>
  7805b7:	jmp    780628 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5148>
  7805b9:	mov    %rdx,0x38(%rsp)
  7805be:	lea    0x318c2b(%rip),%rcx        # a991f0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xa18>
  7805c5:	jmp    780628 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5148>
  7805c7:	mov    %rdx,0x38(%rsp)
  7805cc:	lea    0x318c35(%rip),%rcx        # a99208 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xa30>
  7805d3:	jmp    780628 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5148>
  7805d5:	lea    0x318c5c(%rip),%rax        # a99238 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xa60>
  7805dc:	mov    %rax,0x650(%rsp)
  7805e4:	movb   $0x1,0x60(%rsp)
  7805e9:	mov    %rbx,%rdi
  7805ec:	mov    0x650(%rsp),%rdx
  7805f4:	call   *0x3389a6(%rip)        # ab8fa0 <_DYNAMIC+0x270>
  7805fa:	jmp    780668 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  7805fc:	lea    0x319625(%rip),%rcx        # a99c28 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1450>
  780603:	jmp    780628 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5148>
  780605:	mov    %rcx,0x38(%rsp)
  78060a:	lea    0x31962f(%rip),%rcx        # a99c40 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1468>
  780611:	jmp    780628 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5148>
  780613:	lea    0x3195f6(%rip),%rcx        # a99c10 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1438>
  78061a:	jmp    780628 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5148>
  78061c:	mov    %rcx,0x38(%rsp)
  780621:	lea    0x318bf8(%rip),%rcx        # a99220 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xa48>
  780628:	mov    %rcx,0xa0(%rsp)
  780630:	mov    0x38(%rsp),%rdi
  780635:	mov    %rax,%rsi
  780638:	mov    0xa0(%rsp),%rdx
  780640:	call   *0x33895a(%rip)        # ab8fa0 <_DYNAMIC+0x270>
  780646:	jmp    780668 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  780648:	lea    0x319ea9(%rip),%rax        # a9a4f8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1d20>
  78064f:	mov    %rax,0x648(%rsp)
  780657:	mov    %rbx,%rdi
  78065a:	mov    0x648(%rsp),%rdx
  780662:	call   *0x338938(%rip)        # ab8fa0 <_DYNAMIC+0x270>
  780668:	ud2
  78066a:	mov    %rbx,%rcx
  78066d:	mov    %rax,%rbx
  780670:	mov    (%rcx),%rax
  780673:	movaps 0x760(%rsp),%xmm0
  78067b:	movups %xmm0,0xb0(%rax)
  780682:	movaps 0x750(%rsp),%xmm0
  78068a:	movups %xmm0,0xa0(%rax)
  780691:	movaps 0x710(%rsp),%xmm0
  780699:	movaps 0x720(%rsp),%xmm1
  7806a1:	movaps 0x730(%rsp),%xmm2
  7806a9:	movapd 0x740(%rsp),%xmm3
  7806b2:	movupd %xmm3,0x90(%rax)
  7806ba:	movups %xmm2,0x80(%rax)
  7806c1:	movups %xmm1,0x70(%rax)
  7806c5:	movups %xmm0,0x60(%rax)
  7806c9:	jmp    78074a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x526a>
  7806cb:	mov    %rax,%rbx
  7806ce:	mov    0x6e8(%r13),%rax
  7806d5:	mov    0x210(%rsp),%rcx
  7806dd:	mov    %rcx,0x28(%rax)
  7806e1:	movups 0x200(%rsp),%xmm0
  7806e9:	movups %xmm0,0x18(%rax)
  7806ed:	mov    $0x1,%r15b
  7806f0:	xor    %r12d,%r12d
  7806f3:	jmp    780a24 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5544>
  7806f8:	mov    %rax,%rbx
  7806fb:	lea    0x728(%rsp),%rdi
  780703:	call   747890 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime8metadata8TextSlotEECs9C2G9YFESsD_29canonical_text_public_control>
  780708:	lea    0x740(%rsp),%rdi
  780710:	call   747890 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime8metadata8TextSlotEECs9C2G9YFESsD_29canonical_text_public_control>
  780715:	lea    0x710(%rsp),%rdi
  78071d:	call   74e620 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime6scroll14ViewportColumnECs9C2G9YFESsD_29canonical_text_public_control>
  780722:	mov    0x758(%rsp),%rax
  78072a:	test   %rax,%rax
  78072d:	je     78074a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x526a>
  78072f:	mov    0x760(%rsp),%rdi
  780737:	shl    $0x3,%rax
  78073b:	lea    (%rax,%rax,2),%rsi
  78073f:	mov    $0x8,%edx
  780744:	call   *0x338826(%rip)        # ab8f70 <_DYNAMIC+0x240>
  78074a:	mov    $0x1,%r12b
  78074d:	movl   $0x0,0x58(%rsp)
  780755:	mov    $0x1,%al
  780757:	mov    %eax,0x38(%rsp)
  78075b:	movl   $0x0,0x30(%rsp)
  780763:	mov    $0x1,%r15b
  780766:	jmp    7808d9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x53f9>
  78076b:	mov    %rax,%rbx
  78076e:	mov    0x6e8(%r13),%rax
  780775:	movq   $0x0,0x30(%rax)
  78077d:	xor    %r15d,%r15d
  780780:	jmp    780a24 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5544>
  780785:	mov    %rax,%rbx
  780788:	lea    0x390(%rsp),%rsi
  780790:	mov    $0x1e8,%edx
  780795:	mov    %r13,%rdi
  780798:	call   *0x3387f2(%rip)        # ab8f90 <memcpy@GLIBC_2.14>
  78079e:	mov    $0x1,%al
  7807a0:	mov    %eax,0x58(%rsp)
  7807a4:	xor    %ebp,%ebp
  7807a6:	mov    $0x1,%r12b
  7807a9:	mov    $0x1,%al
  7807ab:	mov    %eax,0x38(%rsp)
  7807af:	mov    $0x1,%al
  7807b1:	mov    %eax,0x30(%rsp)
  7807b5:	mov    $0x1,%r15b
  7807b8:	jmp    7808d9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x53f9>
  7807bd:	mov    %rax,%rbx
  7807c0:	jmp    780a16 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5536>
  7807c5:	mov    %rax,%rbx
  7807c8:	mov    0x3a0(%rsp),%rax
  7807d0:	mov    %rax,0x10(%r15)
  7807d4:	movaps 0x390(%rsp),%xmm0
  7807dc:	movups %xmm0,(%r15)
  7807e0:	mov    0x80(%rsp),%rax
  7807e8:	mov    %rax,0x5e0(%r13)
  7807ef:	mov    0xf8(%rsp),%rax
  7807f7:	mov    %ax,0x5e8(%r13)
  7807ff:	mov    0x2e0(%rsp),%rax
  780807:	mov    %ax,0x5ea(%r13)
  78080f:	movss  0x9c(%rsp),%xmm0
  780818:	movss  %xmm0,0x5ec(%r13)
  780821:	xor    %r15d,%r15d
  780824:	jmp    780a24 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5544>
  780829:	mov    %rax,%rbx
  78082c:	mov    $0x1,%r12b
  78082f:	jmp    780861 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5381>
  780831:	mov    %rax,%rbx
  780834:	mov    %rbp,%rdi
  780837:	call   745dd0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtCslbxve4rcJus_4gpui11shared_text10SharedTextEECs9C2G9YFESsD_29canonical_text_public_control>
  78083c:	jmp    780a90 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x55b0>
  780841:	mov    %rax,%rbx
  780844:	mov    $0x1,%r12b
  780847:	test   %r15,%r15
  78084a:	je     780861 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5381>
  78084c:	shl    $0x4,%r15
  780850:	mov    $0x4,%edx
  780855:	mov    %r13,%rdi
  780858:	mov    %r15,%rsi
  78085b:	call   *0x33870f(%rip)        # ab8f70 <_DYNAMIC+0x240>
  780861:	mov    $0x1,%al
  780863:	mov    %eax,0x38(%rsp)
  780867:	mov    $0x1,%r15b
  78086a:	xor    %r13d,%r13d
  78086d:	cmpb   $0x0,0x58(%rsp)
  780872:	je     780a6f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x558f>
  780878:	jmp    780b64 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5684>
  78087d:	mov    %rax,%rbx
  780880:	mov    $0x1,%r12b
  780883:	mov    $0x1,%al
  780885:	mov    %eax,0x38(%rsp)
  780889:	mov    $0x1,%al
  78088b:	mov    %eax,0x30(%rsp)
  78088f:	mov    $0x1,%r13b
  780892:	mov    $0x1,%r15b
  780895:	mov    $0x1,%bpl
  780898:	cmpq   $0xffffffffffffffff,0x258(%rsp)
  7808a1:	jne    780b7c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x569c>
  7808a7:	jmp    780b90 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x56b0>
  7808ac:	mov    %ebx,0x30(%rsp)
  7808b0:	mov    %rax,%rbx
  7808b3:	mov    %r15d,%r13d
  7808b6:	jmp    780b90 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x56b0>
  7808bb:	mov    %rax,%rbx
  7808be:	mov    $0x1,%al
  7808c0:	mov    %eax,0x58(%rsp)
  7808c4:	mov    $0x1,%r12b
  7808c7:	mov    $0x1,%al
  7808c9:	mov    %eax,0x38(%rsp)
  7808cd:	mov    $0x1,%al
  7808cf:	mov    %eax,0x30(%rsp)
  7808d3:	mov    $0x1,%r15b
  7808d6:	mov    $0x1,%bpl
  7808d9:	movb   $0x1,0xc0(%rsp)
  7808e1:	jmp    780a24 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5544>
  7808e6:	mov    %rax,%rbx
  7808e9:	mov    %r13d,%r15d
  7808ec:	jmp    780bbb <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x56db>
  7808f1:	mov    %rax,%rbx
  7808f4:	jmp    780a24 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5544>
  7808f9:	mov    %rax,%rbx
  7808fc:	mov    %r13d,%r15d
  7808ff:	jmp    780bae <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x56ce>
  780904:	mov    %rax,%rbx
  780907:	add    $0x38,%r15
  78090b:	mov    %r15,%rdi
  78090e:	call   74cd40 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text11RasterCacheECs9C2G9YFESsD_29canonical_text_public_control>
  780913:	jmp    780980 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x54a0>
  780915:	call   *0x33867d(%rip)        # ab8f98 <_DYNAMIC+0x268>
  78091b:	mov    %rax,%rbx
  78091e:	mov    0x300(%rsp),%rax
  780926:	lock decq (%rax)
  78092a:	jne    780b3f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x565f>
  780930:	lea    0x300(%rsp),%rdi
  780938:	call   *0x338752(%rip)        # ab9090 <_DYNAMIC+0x360>
  78093e:	jmp    780b3f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x565f>
  780943:	mov    %rax,%rbx
  780946:	mov    %r12b,0x60(%rsp)
  78094b:	jmp    780a90 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x55b0>
  780950:	mov    %rax,%rbx
  780953:	movb   $0x1,0x60(%rsp)
  780958:	jmp    780a90 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x55b0>
  78095d:	mov    %rax,%rbx
  780960:	mov    $0x1,%bpl
  780963:	mov    $0x1,%r15b
  780966:	mov    $0x1,%r13b
  780969:	mov    $0x1,%al
  78096b:	mov    %eax,0x30(%rsp)
  78096f:	mov    $0x1,%al
  780971:	mov    %eax,0x38(%rsp)
  780975:	mov    $0x1,%r12b
  780978:	jmp    780b64 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5684>
  78097d:	mov    %rax,%rbx
  780980:	mov    0x40(%rsp),%rax
  780985:	mov    0x6e8(%rax),%rax
  78098c:	mov    %r12,0x30(%rax)
  780990:	mov    %r14d,0x38(%rax)
  780994:	mov    %ebp,0x3c(%rax)
  780997:	movaps 0x970(%rsp),%xmm0
  78099f:	movaps 0x980(%rsp),%xmm1
  7809a7:	movaps 0x990(%rsp),%xmm2
  7809af:	movups %xmm0,0x40(%rax)
  7809b3:	movups %xmm1,0x50(%rax)
  7809b7:	movups %xmm2,0x60(%rax)
  7809bb:	mov    0x9a0(%rsp),%rcx
  7809c3:	mov    %rcx,0x70(%rax)
  7809c7:	mov    $0x1,%bpl
  7809ca:	jmp    780d13 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5833>
  7809cf:	mov    %rax,%rbx
  7809d2:	jmp    780cf2 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5812>
  7809d7:	mov    %rax,%rbx
  7809da:	lea    0x390(%rsp),%rsi
  7809e2:	mov    $0x298,%edx
  7809e7:	mov    %r14,%rdi
  7809ea:	call   *0x3385a0(%rip)        # ab8f90 <memcpy@GLIBC_2.14>
  7809f0:	jmp    780cc2 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57e2>
  7809f5:	mov    %rax,%rbx
  7809f8:	jmp    780ce0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5800>
  7809fd:	jmp    780b3c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x565c>
  780a02:	ud2
  780a04:	ud2
  780a06:	mov    %rax,%rbx
  780a09:	lea    0x8b8(%rsp),%rdi
  780a11:	call   746ea0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCsghYClfd3M9V_11gpui_canvas5image5ImageEECs9C2G9YFESsD_29canonical_text_public_control>
  780a16:	mov    $0x1,%r12b
  780a19:	movl   $0x0,0x38(%rsp)
  780a21:	mov    $0x1,%r15b
  780a24:	mov    0x180(%rsp),%rsi
  780a2c:	test   %rsi,%rsi
  780a2f:	setg   %al
  780a32:	test   %al,0xc0(%rsp)
  780a39:	je     780a61 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5581>
  780a3b:	mov    0x188(%rsp),%rdi
  780a43:	shl    $0x4,%rsi
  780a47:	mov    $0x4,%edx
  780a4c:	call   *0x33851e(%rip)        # ab8f70 <_DYNAMIC+0x240>
  780a52:	xor    %r13d,%r13d
  780a55:	cmpb   $0x0,0x58(%rsp)
  780a5a:	je     780a6f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x558f>
  780a5c:	jmp    780b64 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5684>
  780a61:	xor    %r13d,%r13d
  780a64:	cmpb   $0x0,0x58(%rsp)
  780a69:	jne    780b64 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5684>
  780a6f:	cmpq   $0xffffffffffffffff,0x258(%rsp)
  780a78:	jne    780b7c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x569c>
  780a7e:	jmp    780b90 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x56b0>
  780a83:	jmp    780cbf <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57df>
  780a88:	jmp    780cbf <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57df>
  780a8d:	mov    %rax,%rbx
  780a90:	mov    0x1f8(%rsp),%rax
  780a98:	test   %rax,%rax
  780a9b:	setne  %cl
  780a9e:	test   %cl,0x60(%rsp)
  780aa2:	je     780b3f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x565f>
  780aa8:	lock decq (%rax)
  780aac:	jne    780b3f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x565f>
  780ab2:	lea    0x1f8(%rsp),%rdi
  780aba:	call   *0x3385d0(%rip)        # ab9090 <_DYNAMIC+0x360>
  780ac0:	jmp    780b3f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x565f>
  780ac2:	jmp    780cbf <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57df>
  780ac7:	mov    %rax,%rbx
  780aca:	mov    $0x1,%r12b
  780acd:	mov    $0x1,%r13b
  780ad0:	mov    $0x1,%r15b
  780ad3:	mov    $0x1,%bpl
  780ad6:	jmp    780bdf <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x56ff>
  780adb:	mov    %rax,%rbx
  780ade:	mov    $0x1,%r12b
  780ae1:	mov    $0x1,%r13b
  780ae4:	mov    $0x1,%r15b
  780ae7:	mov    $0x1,%bpl
  780aea:	jmp    780bff <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x571f>
  780aef:	mov    %rax,%rbx
  780af2:	mov    $0x1,%r12b
  780af5:	mov    $0x1,%r13b
  780af8:	mov    $0x1,%r15b
  780afb:	mov    $0x1,%bpl
  780afe:	jmp    780c23 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5743>
  780b03:	mov    %rax,%rbx
  780b06:	mov    $0x1,%r12b
  780b09:	mov    $0x1,%r13b
  780b0c:	mov    $0x1,%r15b
  780b0f:	mov    $0x1,%bpl
  780b12:	jmp    780c47 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5767>
  780b17:	mov    %rax,%rbx
  780b1a:	mov    $0x1,%bpl
  780b1d:	mov    $0x1,%r15b
  780b20:	mov    $0x1,%r12b
  780b23:	jmp    780c70 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5790>
  780b28:	mov    %rax,%rbx
  780b2b:	jmp    780ca6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57c6>
  780b30:	ud2
  780b32:	ud2
  780b34:	mov    %rax,%rbx
  780b37:	jmp    780d13 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5833>
  780b3c:	mov    %rax,%rbx
  780b3f:	mov    $0x1,%bpl
  780b42:	lea    0x970(%rsp),%rdi
  780b4a:	call   74d090 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas6canvas6CanvasECs9C2G9YFESsD_29canonical_text_public_control>
  780b4f:	mov    $0x1,%r15b
  780b52:	mov    $0x1,%r13b
  780b55:	mov    $0x1,%al
  780b57:	mov    %eax,0x30(%rsp)
  780b5b:	mov    $0x1,%al
  780b5d:	mov    %eax,0x38(%rsp)
  780b61:	mov    $0x1,%r12b
  780b64:	lea    0x6c0(%rsp),%rdi
  780b6c:	call   74e5d0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime6scroll13ViewportBuildECs9C2G9YFESsD_29canonical_text_public_control>
  780b71:	cmpq   $0xffffffffffffffff,0x258(%rsp)
  780b7a:	je     780b90 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x56b0>
  780b7c:	cmpb   $0x0,0x38(%rsp)
  780b81:	je     780b90 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x56b0>
  780b83:	lea    0x8b8(%rsp),%rdi
  780b8b:	call   746ea0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCsghYClfd3M9V_11gpui_canvas5image5ImageEECs9C2G9YFESsD_29canonical_text_public_control>
  780b90:	cmpl   $0xffffffff,0x810(%rsp)
  780b98:	je     780bae <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x56ce>
  780b9a:	cmpb   $0x0,0x30(%rsp)
  780b9f:	je     780bae <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x56ce>
  780ba1:	lea    0x810(%rsp),%rdi
  780ba9:	call   74ea10 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime8metadata5SheetECs9C2G9YFESsD_29canonical_text_public_control>
  780bae:	lea    0x6a8(%rsp),%rdi
  780bb6:	call   74ac70 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtCscdodAO9FK5_5alloc11collections5btree3set8BTreeSetNtNtCslbxve4rcJus_4gpui4list6ListIdEECs9C2G9YFESsD_29canonical_text_public_control>
  780bbb:	mov    0x100(%rsp),%rsi
  780bc3:	test   %rsi,%rsi
  780bc6:	je     780bdf <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x56ff>
  780bc8:	mov    0x108(%rsp),%rdi
  780bd0:	shl    $0x2,%rsi
  780bd4:	mov    $0x4,%edx
  780bd9:	call   *0x338391(%rip)        # ab8f70 <_DYNAMIC+0x240>
  780bdf:	mov    0x158(%rsp),%rsi
  780be7:	test   %rsi,%rsi
  780bea:	je     780bff <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x571f>
  780bec:	mov    0x160(%rsp),%rdi
  780bf4:	mov    $0x1,%edx
  780bf9:	call   *0x338371(%rip)        # ab8f70 <_DYNAMIC+0x240>
  780bff:	mov    0x230(%rsp),%rsi
  780c07:	test   %rsi,%rsi
  780c0a:	je     780c23 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5743>
  780c0c:	mov    0x238(%rsp),%rdi
  780c14:	shl    $0x4,%rsi
  780c18:	mov    $0x4,%edx
  780c1d:	call   *0x33834d(%rip)        # ab8f70 <_DYNAMIC+0x240>
  780c23:	mov    0x218(%rsp),%rsi
  780c2b:	test   %rsi,%rsi
  780c2e:	je     780c47 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5767>
  780c30:	mov    0x220(%rsp),%rdi
  780c38:	shl    $0x4,%rsi
  780c3c:	mov    $0x4,%edx
  780c41:	call   *0x338329(%rip)        # ab8f70 <_DYNAMIC+0x240>
  780c47:	mov    0x1d8(%rsp),%rax
  780c4f:	test   %rax,%rax
  780c52:	je     780c6b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x578b>
  780c54:	mov    0x1e0(%rsp),%rdi
  780c5c:	imul   $0x38,%rax,%rsi
  780c60:	mov    $0x8,%edx
  780c65:	call   *0x338305(%rip)        # ab8f70 <_DYNAMIC+0x240>
  780c6b:	test   %r13b,%r13b
  780c6e:	je     780c94 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57b4>
  780c70:	mov    0x268(%rsp),%rsi
  780c78:	test   %rsi,%rsi
  780c7b:	je     780c94 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57b4>
  780c7d:	mov    0x270(%rsp),%rdi
  780c85:	shl    $0x4,%rsi
  780c89:	mov    $0x4,%edx
  780c8e:	call   *0x3382dc(%rip)        # ab8f70 <_DYNAMIC+0x240>
  780c94:	test   %r15b,%r15b
  780c97:	je     780ca6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57c6>
  780c99:	lea    0x140(%rsp),%rdi
  780ca1:	call   747260 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCslbxve4rcJus_4gpui7runtime9PresentedEECs9C2G9YFESsD_29canonical_text_public_control>
  780ca6:	cmpl   $0xfffffffe,0x7c8(%rsp)
  780cae:	je     780cc8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57e8>
  780cb0:	lea    0x7c8(%rsp),%rdi
  780cb8:	call   74d580 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  780cbd:	jmp    780cc8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57e8>
  780cbf:	mov    %rax,%rbx
  780cc2:	mov    $0x1,%r12b
  780cc5:	mov    $0x1,%bpl
  780cc8:	cmpq   $0x0,0x1c0(%rsp)
  780cd1:	je     780ce0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5800>
  780cd3:	mov    0x1c8(%rsp),%rdi
  780cdb:	call   74caf0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text10TextShaperECs9C2G9YFESsD_29canonical_text_public_control>
  780ce0:	test   %r12b,%r12b
  780ce3:	je     780cf2 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5812>
  780ce5:	lea    0x200(%rsp),%rdi
  780ced:	call   7476c0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime13text_geometry5EntryEECs9C2G9YFESsD_29canonical_text_public_control>
  780cf2:	mov    0xd0(%rsp),%rax
  780cfa:	test   %rax,%rax
  780cfd:	je     780d13 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5833>
  780cff:	lock decq (%rax)
  780d03:	jne    780d13 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5833>
  780d05:	lea    0xd0(%rsp),%rdi
  780d0d:	call   *0x33834d(%rip)        # ab9060 <_DYNAMIC+0x330>
  780d13:	cmpl   $0x2,0xca0(%rsp)
  780d1b:	je     780d2f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x584f>
  780d1d:	test   %bpl,%bpl
  780d20:	je     780d2f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x584f>
  780d22:	lea    0xca0(%rsp),%rdi
  780d2a:	call   74d090 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas6canvas6CanvasECs9C2G9YFESsD_29canonical_text_public_control>
  780d2f:	mov    %rbx,%rdi
  780d32:	call   a97420 <_Unwind_Resume@plt>
  780d37:	call   *0x33825b(%rip)        # ab8f98 <_DYNAMIC+0x268>

<&gpui_canvas::text::layout::TextPosition as core::fmt::Debug>::fmt bytes=99 frame=24

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000795d70 <_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextPositionNtB6_5Debug3fmtCs9C2G9YFESsD_29canonical_text_public_control>:
  795d70:	push   %r14
  795d72:	push   %rbx
  795d73:	push   %rax
  795d74:	mov    %rsi,%rax
  795d77:	mov    (%rdi),%r9
  795d7a:	lea    0x4(%r9),%rcx
  795d7e:	mov    %rcx,(%rsp)
  795d82:	sub    $0x8,%rsp
  795d86:	lea    0x30518b(%rip),%r10        # a9af18 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2740>
  795d8d:	lea    0x8(%rsp),%r11
  795d92:	lea    -0x6d20e1(%rip),%rbx        # c3cb8 <GCC_except_table0+0x1918>
  795d99:	lea    0x305158(%rip),%r14        # a9aef8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2720>
  795da0:	lea    -0x6c2db0(%rip),%rsi        # d2ff7 <GCC_except_table0+0x10c57>
  795da7:	lea    -0x6c6360(%rip),%rcx        # cfa4e <GCC_except_table0+0xd6ae>
  795dae:	mov    $0xc,%edx
  795db3:	mov    $0x6,%r8d
  795db9:	mov    %rax,%rdi
  795dbc:	push   %r10
  795dbe:	push   %r11
  795dc0:	push   $0x8
  795dc2:	push   %rbx
  795dc3:	push   %r14
  795dc5:	call   *0x32393d(%rip)        # ab9708 <_DYNAMIC+0x9d8>
  795dcb:	add    $0x38,%rsp
  795dcf:	pop    %rbx
  795dd0:	pop    %r14
  795dd2:	ret

<&gpui_canvas::text::layout::CaretAffinity as core::fmt::Debug>::fmt bytes=46 frame=0

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000795de0 <_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout13CaretAffinityNtB6_5Debug3fmtCs9C2G9YFESsD_29canonical_text_public_control>:
  795de0:	mov    %rsi,%rax
  795de3:	mov    (%rdi),%rcx
  795de6:	movzbl (%rcx),%ecx
  795de9:	lea    -0x6c2e63(%rip),%rdx        # d2f8d <GCC_except_table0+0x10bed>
  795df0:	lea    -0x6d203f(%rip),%rsi        # c3db8 <GCC_except_table0+0x1a18>
  795df7:	test   %ecx,%ecx
  795df9:	cmovne %rdx,%rsi
  795dfd:	lea    0x8(,%rcx,2),%rdx
  795e05:	mov    %rax,%rdi
  795e08:	jmp    *0x323902(%rip)        # ab9710 <_DYNAMIC+0x9e0>

<&gpui_canvas::text::layout::TextSelection as core::fmt::Debug>::fmt bytes=99 frame=24

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000795e10 <_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout13TextSelectionNtB6_5Debug3fmtCs9C2G9YFESsD_29canonical_text_public_control>:
  795e10:	push   %r14
  795e12:	push   %rbx
  795e13:	push   %rax
  795e14:	mov    %rsi,%rax
  795e17:	mov    (%rdi),%r9
  795e1a:	lea    0x8(%r9),%rcx
  795e1e:	mov    %rcx,(%rsp)
  795e22:	sub    $0x8,%rsp
  795e26:	lea    0x302c8b(%rip),%r10        # a98ab8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2e0>
  795e2d:	lea    0x8(%rsp),%r11
  795e32:	lea    -0x6c2d48(%rip),%rbx        # d30f1 <GCC_except_table0+0x10d51>
  795e39:	lea    0x305138(%rip),%r14        # a9af78 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x27a0>
  795e40:	lea    -0x6c2d69(%rip),%rsi        # d30de <GCC_except_table0+0x10d3e>
  795e47:	lea    -0x6c2d63(%rip),%rcx        # d30eb <GCC_except_table0+0x10d4b>
  795e4e:	mov    $0xd,%edx
  795e53:	mov    $0x6,%r8d
  795e59:	mov    %rax,%rdi
  795e5c:	push   %r10
  795e5e:	push   %r11
  795e60:	push   $0x5
  795e62:	push   %rbx
  795e63:	push   %r14
  795e65:	call   *0x32389d(%rip)        # ab9708 <_DYNAMIC+0x9d8>
  795e6b:	add    $0x38,%rsp
  795e6f:	pop    %rbx
  795e70:	pop    %r14
  795e72:	ret

<&*const gpui_canvas::text::layout::TextGeometry as core::fmt::Debug>::fmt bytes=12 frame=0

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000795e80 <_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRPNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryNtB6_5Debug3fmtCs9C2G9YFESsD_29canonical_text_public_control>:
  795e80:	mov    (%rdi),%rax
  795e83:	mov    (%rax),%rdi
  795e86:	jmp    *0x3238bc(%rip)        # ab9748 <_DYNAMIC+0xa18>

<&(alloc::string::String, gpui_canvas::text::layout::TextSelection, *const gpui_canvas::text::layout::TextGeometry, u64) as core::fmt::Debug>::fmt bytes=156 frame=72

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000795ed0 <_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRTNtNtCscdodAO9FK5_5alloc6string6StringNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout13TextSelectionPNtB1a_12TextGeometryyENtB6_5Debug3fmtCs9C2G9YFESsD_29canonical_text_public_control>:
  795ed0:	push   %r14
  795ed2:	push   %rbx
  795ed3:	sub    $0x38,%rsp
  795ed7:	mov    (%rdi),%r14
  795eda:	lea    0x20(%rsp),%rbx
  795edf:	mov    $0x1,%edx
  795ee4:	mov    %rbx,%rdi
  795ee7:	xor    %ecx,%ecx
  795ee9:	call   *0x323861(%rip)        # ab9750 <_DYNAMIC+0xa20>
  795eef:	mov    %r14,(%rsp)
  795ef3:	lea    0x18(%r14),%rax
  795ef7:	mov    %rax,0x8(%rsp)
  795efc:	lea    0x28(%r14),%rax
  795f00:	mov    %rax,0x10(%rsp)
  795f05:	add    $0x30,%r14
  795f09:	mov    %r14,0x18(%rsp)
  795f0e:	lea    0x302b83(%rip),%rdx        # a98a98 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2c0>
  795f15:	mov    0x32383c(%rip),%r14        # ab9758 <_DYNAMIC+0xa28>
  795f1c:	mov    %rsp,%rsi
  795f1f:	mov    %rbx,%rdi
  795f22:	call   *%r14
  795f25:	lea    0x302bac(%rip),%rdx        # a98ad8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x300>
  795f2c:	lea    0x8(%rsp),%rsi
  795f31:	mov    %rbx,%rdi
  795f34:	call   *%r14
  795f37:	lea    0x304a5a(%rip),%rdx        # a9a998 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x21c0>
  795f3e:	lea    0x10(%rsp),%rsi
  795f43:	mov    %rbx,%rdi
  795f46:	call   *%r14
  795f49:	lea    0x304a68(%rip),%rdx        # a9a9b8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x21e0>
  795f50:	lea    0x18(%rsp),%rsi
  795f55:	mov    %rbx,%rdi
  795f58:	call   *%r14
  795f5b:	mov    %rbx,%rdi
  795f5e:	call   *0x3237fc(%rip)        # ab9760 <_DYNAMIC+0xa30>
  795f64:	add    $0x38,%rsp
  795f68:	pop    %rbx
  795f69:	pop    %r14
  795f6b:	ret

<&(*const gpui_canvas::text::layout::TextGeometry, u64) as core::fmt::Debug>::fmt bytes=102 frame=56

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000795f70 <_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRTPNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryyENtB6_5Debug3fmtCs9C2G9YFESsD_29canonical_text_public_control>:
  795f70:	push   %r14
  795f72:	push   %rbx
  795f73:	sub    $0x28,%rsp
  795f77:	mov    (%rdi),%r14
  795f7a:	lea    0x10(%rsp),%rbx
  795f7f:	mov    $0x1,%edx
  795f84:	mov    %rbx,%rdi
  795f87:	xor    %ecx,%ecx
  795f89:	call   *0x3237c1(%rip)        # ab9750 <_DYNAMIC+0xa20>
  795f8f:	mov    %r14,(%rsp)
  795f93:	add    $0x8,%r14
  795f97:	mov    %r14,0x8(%rsp)
  795f9c:	lea    0x3049f5(%rip),%rdx        # a9a998 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x21c0>
  795fa3:	mov    0x3237ae(%rip),%r14        # ab9758 <_DYNAMIC+0xa28>
  795faa:	mov    %rsp,%rsi
  795fad:	mov    %rbx,%rdi
  795fb0:	call   *%r14
  795fb3:	lea    0x3049fe(%rip),%rdx        # a9a9b8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x21e0>
  795fba:	lea    0x8(%rsp),%rsi
  795fbf:	mov    %rbx,%rdi
  795fc2:	call   *%r14
  795fc5:	mov    %rbx,%rdi
  795fc8:	call   *0x323792(%rip)        # ab9760 <_DYNAMIC+0xa30>
  795fce:	add    $0x28,%rsp
  795fd2:	pop    %rbx
  795fd3:	pop    %r14
  795fd5:	ret

<gpui_canvas::text::layout::TextOffset as core::fmt::Debug>::fmt bytes=41 frame=8

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000796280 <_RNvXs7_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_10TextOffsetNtNtCs4NRVxsYgnAr_4core3fmt5Debug3fmt>:
  796280:	push   %rax
  796281:	mov    %rsi,%rax
  796284:	mov    %rdi,(%rsp)
  796288:	lea    -0x6c358d(%rip),%rsi        # d2d02 <GCC_except_table0+0x10962>
  79628f:	lea    0x304932(%rip),%r8        # a9abc8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x23f0>
  796296:	mov    %rsp,%rcx
  796299:	mov    $0xa,%edx
  79629e:	mov    %rax,%rdi
  7962a1:	call   *0x323471(%rip)        # ab9718 <_DYNAMIC+0x9e8>
  7962a7:	pop    %rcx
  7962a8:	ret

<gpui_canvas::text::layout::TextPosition as core::fmt::Debug>::fmt bytes=99 frame=24

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000797cc0 <_RNvXsn_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextPositionNtNtCs4NRVxsYgnAr_4core3fmt5Debug3fmt>:
  797cc0:	push   %r14
  797cc2:	push   %rbx
  797cc3:	push   %rax
  797cc4:	mov    %rsi,%rax
  797cc7:	mov    %rdi,%r9
  797cca:	lea    0x4(%rdi),%rcx
  797cce:	mov    %rcx,(%rsp)
  797cd2:	sub    $0x8,%rsp
  797cd6:	lea    0x30323b(%rip),%r10        # a9af18 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2740>
  797cdd:	lea    0x8(%rsp),%r11
  797ce2:	lea    -0x6d4031(%rip),%rbx        # c3cb8 <GCC_except_table0+0x1918>
  797ce9:	lea    0x303208(%rip),%r14        # a9aef8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2720>
  797cf0:	lea    -0x6c4d00(%rip),%rsi        # d2ff7 <GCC_except_table0+0x10c57>
  797cf7:	lea    -0x6c82b0(%rip),%rcx        # cfa4e <GCC_except_table0+0xd6ae>
  797cfe:	mov    $0xc,%edx
  797d03:	mov    $0x6,%r8d
  797d09:	mov    %rax,%rdi
  797d0c:	push   %r10
  797d0e:	push   %r11
  797d10:	push   $0x8
  797d12:	push   %rbx
  797d13:	push   %r14
  797d15:	call   *0x3219ed(%rip)        # ab9708 <_DYNAMIC+0x9d8>
  797d1b:	add    $0x38,%rsp
  797d1f:	pop    %rbx
  797d20:	pop    %r14
  797d22:	ret

<gpui::runtime::text_geometry::TextResources>::acknowledge bytes=336 frame=104

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000079d3b0 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge>:
  79d3b0:	push   %rbp
  79d3b1:	push   %r15
  79d3b3:	push   %r14
  79d3b5:	push   %r13
  79d3b7:	push   %r12
  79d3b9:	push   %rbx
  79d3ba:	sub    $0x38,%rsp
  79d3be:	mov    0x18(%rdi),%rax
  79d3c2:	movq   $0xffffffffffffffff,0x18(%rdi)
  79d3ca:	cmp    $0xffffffffffffffff,%rax
  79d3ce:	je     79d476 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0xc6>
  79d3d4:	mov    %rdi,%rbx
  79d3d7:	mov    %rax,0x10(%rsp)
  79d3dc:	movups 0x20(%rdi),%xmm0
  79d3e0:	movaps %xmm0,0x20(%rsp)
  79d3e5:	lea    0x8(%rdi),%rax
  79d3e9:	mov    %rax,0x8(%rsp)
  79d3ee:	mov    0x8(%rdi),%r14
  79d3f2:	mov    0x10(%rdi),%rax
  79d3f6:	test   %rax,%rax
  79d3f9:	je     79d443 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0x93>
  79d3fb:	mov    $0x1,%r15d
  79d401:	sub    %rax,%r15
  79d404:	mov    $0xffffffffffffffe8,%r13
  79d40b:	xor    %r12d,%r12d
  79d40e:	mov    0x31bc7b(%rip),%rbp        # ab9090 <_DYNAMIC+0x360>
  79d415:	jmp    79d431 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0x81>
  79d417:	nopw   0x0(%rax,%rax,1)
  79d420:	add    $0xffffffffffffffe8,%r13
  79d424:	inc    %r15
  79d427:	add    $0x18,%r12
  79d42b:	cmp    $0x1,%r15
  79d42f:	je     79d443 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0x93>
  79d431:	mov    (%r14,%r12,1),%rax
  79d435:	lock decq (%rax)
  79d439:	jne    79d420 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0x70>
  79d43b:	lea    (%r14,%r12,1),%rdi
  79d43f:	call   *%rbp
  79d441:	jmp    79d420 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0x70>
  79d443:	mov    (%rbx),%rax
  79d446:	test   %rax,%rax
  79d449:	je     79d461 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0xb1>
  79d44b:	shl    $0x3,%rax
  79d44f:	lea    (%rax,%rax,2),%rsi
  79d453:	mov    $0x8,%edx
  79d458:	mov    %r14,%rdi
  79d45b:	call   *0x31bb0f(%rip)        # ab8f70 <_DYNAMIC+0x240>
  79d461:	mov    0x10(%rsp),%rax
  79d466:	mov    %rax,(%rbx)
  79d469:	movaps 0x20(%rsp),%xmm0
  79d46e:	mov    0x8(%rsp),%rax
  79d473:	movups %xmm0,(%rax)
  79d476:	add    $0x38,%rsp
  79d47a:	pop    %rbx
  79d47b:	pop    %r12
  79d47d:	pop    %r13
  79d47f:	pop    %r14
  79d481:	pop    %r15
  79d483:	pop    %rbp
  79d484:	ret
  79d485:	mov    %rax,0x18(%rsp)
  79d48a:	test   %r15,%r15
  79d48d:	jne    79d4cc <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0x11c>
  79d48f:	mov    (%rbx),%rax
  79d492:	test   %rax,%rax
  79d495:	je     79d4ad <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0xfd>
  79d497:	shl    $0x3,%rax
  79d49b:	lea    (%rax,%rax,2),%rsi
  79d49f:	mov    $0x8,%edx
  79d4a4:	mov    %r14,%rdi
  79d4a7:	call   *0x31bac3(%rip)        # ab8f70 <_DYNAMIC+0x240>
  79d4ad:	mov    0x10(%rsp),%rax
  79d4b2:	mov    %rax,(%rbx)
  79d4b5:	movaps 0x20(%rsp),%xmm0
  79d4ba:	mov    0x8(%rsp),%rax
  79d4bf:	movups %xmm0,(%rax)
  79d4c2:	mov    0x18(%rsp),%rdi
  79d4c7:	call   a97420 <_Unwind_Resume@plt>
  79d4cc:	mov    %r14,%r12
  79d4cf:	sub    %r13,%r12
  79d4d2:	neg    %r15
  79d4d5:	jmp    79d4e9 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0x139>
  79d4d7:	nopw   0x0(%rax,%rax,1)
  79d4e0:	add    $0x18,%r12
  79d4e4:	dec    %r15
  79d4e7:	je     79d48f <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0xdf>
  79d4e9:	mov    (%r12),%rax
  79d4ed:	lock decq (%rax)
  79d4f1:	jne    79d4e0 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0x130>
  79d4f3:	mov    %r12,%rdi
  79d4f6:	call   *%rbp
  79d4f8:	jmp    79d4e0 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0x130>
  79d4fa:	call   *0x31ba98(%rip)        # ab8f98 <_DYNAMIC+0x268>

<gpui::runtime::geometry::Geometry>::acknowledge bytes=76 frame=24

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007a5740 <_RNvMs4_NtNtCslbxve4rcJus_4gpui7runtime8geometryNtB5_8Geometry11acknowledge>:
  7a5740:	push   %r15
  7a5742:	push   %r14
  7a5744:	push   %rbx
  7a5745:	mov    0x30(%rdi),%r14
  7a5749:	movq   $0xffffffffffffffff,0x30(%rdi)
  7a5751:	cmp    $0xffffffffffffffff,%r14
  7a5755:	je     7a5786 <_RNvMs4_NtNtCslbxve4rcJus_4gpui7runtime8geometryNtB5_8Geometry11acknowledge+0x46>
  7a5757:	mov    %rdi,%rbx
  7a575a:	lea    0x38(%rdi),%r15
  7a575e:	mov    0x18(%rdi),%rsi
  7a5762:	test   %rsi,%rsi
  7a5765:	je     7a577a <_RNvMs4_NtNtCslbxve4rcJus_4gpui7runtime8geometryNtB5_8Geometry11acknowledge+0x3a>
  7a5767:	mov    0x20(%rbx),%rdi
  7a576b:	shl    $0x4,%rsi
  7a576f:	mov    $0x4,%edx
  7a5774:	call   *0x3137f6(%rip)        # ab8f70 <_DYNAMIC+0x240>
  7a577a:	mov    %r14,0x18(%rbx)
  7a577e:	movups (%r15),%xmm0
  7a5782:	movups %xmm0,0x20(%rbx)
  7a5786:	pop    %rbx
  7a5787:	pop    %r14
  7a5789:	pop    %r15
  7a578b:	ret

<gpui::runtime::TextSite>::shape_for bytes=402 frame=168

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007a7c50 <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for>:
  7a7c50:	push   %rbp
  7a7c51:	push   %r15
  7a7c53:	push   %r14
  7a7c55:	push   %r13
  7a7c57:	push   %r12
  7a7c59:	push   %rbx
  7a7c5a:	sub    $0x78,%rsp
  7a7c5e:	mov    %ecx,%ebp
  7a7c60:	mov    %rsi,%rbx
  7a7c63:	maxss  -0x6e5663(%rip),%xmm1        # c2608 <GCC_except_table0+0x268>
  7a7c6b:	mov    %rdi,%r14
  7a7c6e:	movd   %xmm1,%ecx
  7a7c72:	cmpq   $0xffffffffffffffff,(%rsi)
  7a7c76:	je     7a7c91 <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x41>
  7a7c78:	cmpl   $0x1,0x38(%rbx)
  7a7c7c:	jne    7a7d55 <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x105>
  7a7c82:	cmp    %ecx,0x3c(%rbx)
  7a7c85:	sete   %al
  7a7c88:	test   %al,%bpl
  7a7c8b:	jne    7a7d5f <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x10f>
  7a7c91:	test   %r8b,%r8b
  7a7c94:	je     7a7cbe <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x6e>
  7a7c96:	mov    %ecx,0xc(%rsp)
  7a7c9a:	mov    0x40(%rbx),%rax
  7a7c9e:	mov    (%rax),%rcx
  7a7ca1:	shr    $1,%rcx
  7a7ca4:	add    $0x10,%rax
  7a7ca8:	lea    0x40(%rsp),%rdi
  7a7cad:	mov    %rdx,%rsi
  7a7cb0:	mov    %rax,%rdx
  7a7cb3:	mov    %ebp,%r8d
  7a7cb6:	call   *0x31154c(%rip)        # ab9208 <_DYNAMIC+0x4d8>
  7a7cbc:	jmp    7a7ce4 <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x94>
  7a7cbe:	mov    %ecx,0xc(%rsp)
  7a7cc2:	mov    0x40(%rbx),%rax
  7a7cc6:	mov    (%rax),%rcx
  7a7cc9:	shr    $1,%rcx
  7a7ccc:	add    $0x10,%rax
  7a7cd0:	lea    0x40(%rsp),%rdi
  7a7cd5:	mov    %rdx,%rsi
  7a7cd8:	mov    %rax,%rdx
  7a7cdb:	mov    %ebp,%r8d
  7a7cde:	call   *0x311c5c(%rip)        # ab9940 <_DYNAMIC+0xc10>
  7a7ce4:	mov    0x40(%rsp),%r15
  7a7ce9:	mov    0x48(%rsp),%r13d
  7a7cee:	mov    0x4c(%rsp),%r12d
  7a7cf3:	cmp    $0xffffffffffffffff,%r15
  7a7cf7:	je     7a7d89 <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x139>
  7a7cfd:	mov    0x70(%rsp),%rax
  7a7d02:	mov    %rax,0x30(%rsp)
  7a7d07:	movups 0x50(%rsp),%xmm0
  7a7d0c:	movups 0x60(%rsp),%xmm1
  7a7d11:	movaps %xmm1,0x20(%rsp)
  7a7d16:	movaps %xmm0,0x10(%rsp)
  7a7d1b:	mov    %rbx,%rdi
  7a7d1e:	call   799250 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtCslbxve4rcJus_4gpui7runtime6ShapedEEB11_>
  7a7d23:	mov    %r15,(%rbx)
  7a7d26:	mov    %r13d,0x8(%rbx)
  7a7d2a:	mov    %r12d,0xc(%rbx)
  7a7d2e:	movaps 0x10(%rsp),%xmm0
  7a7d33:	movaps 0x20(%rsp),%xmm1
  7a7d38:	movups %xmm0,0x10(%rbx)
  7a7d3c:	movups %xmm1,0x20(%rbx)
  7a7d40:	mov    0x30(%rsp),%rax
  7a7d45:	mov    %rax,0x30(%rbx)
  7a7d49:	mov    %ebp,0x38(%rbx)
  7a7d4c:	mov    0xc(%rsp),%eax
  7a7d50:	mov    %eax,0x3c(%rbx)
  7a7d53:	jmp    7a7d7c <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x12c>
  7a7d55:	test   $0x1,%bpl
  7a7d59:	jne    7a7c91 <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x41>
  7a7d5f:	test   %r8b,%r8b
  7a7d62:	je     7a7d7c <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x12c>
  7a7d64:	mov    0x20(%rbx),%rax
  7a7d68:	test   %rax,%rax
  7a7d6b:	je     7a7c96 <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x46>
  7a7d71:	cmpq   $0x0,0x50(%rax)
  7a7d76:	je     7a7c96 <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x46>
  7a7d7c:	mov    %rbx,0x8(%r14)
  7a7d80:	movq   $0xfffffffffffffffe,(%r14)
  7a7d87:	jmp    7a7d98 <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x148>
  7a7d89:	movq   $0x23,(%r14)
  7a7d90:	mov    %r13d,0x8(%r14)
  7a7d94:	mov    %r12d,0xc(%r14)
  7a7d98:	mov    %r14,%rax
  7a7d9b:	add    $0x78,%rsp
  7a7d9f:	pop    %rbx
  7a7da0:	pop    %r12
  7a7da2:	pop    %r13
  7a7da4:	pop    %r14
  7a7da6:	pop    %r15
  7a7da8:	pop    %rbp
  7a7da9:	ret
  7a7daa:	mov    %r15,(%rbx)
  7a7dad:	mov    %r13d,0x8(%rbx)
  7a7db1:	mov    %r12d,0xc(%rbx)
  7a7db5:	movaps 0x10(%rsp),%xmm0
  7a7dba:	movaps 0x20(%rsp),%xmm1
  7a7dbf:	movups %xmm0,0x10(%rbx)
  7a7dc3:	movups %xmm1,0x20(%rbx)
  7a7dc7:	mov    0x30(%rsp),%rcx
  7a7dcc:	mov    %rcx,0x30(%rbx)
  7a7dd0:	mov    %ebp,0x38(%rbx)
  7a7dd3:	mov    0xc(%rsp),%ecx
  7a7dd7:	mov    %ecx,0x3c(%rbx)
  7a7dda:	mov    %rax,%rdi
  7a7ddd:	call   a97420 <_Unwind_Resume@plt>

gpui::runtime::image::acknowledge bytes=157 frame=40

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007aa290 <_RNvNtNtCslbxve4rcJus_4gpui7runtime5image11acknowledge>:
  7aa290:	push   %r15
  7aa292:	push   %r14
  7aa294:	push   %rbx
  7aa295:	sub    $0x10,%rsp
  7aa299:	mov    (%rdi),%r14
  7aa29c:	test   %r14,%r14
  7aa29f:	je     7aa2ff <_RNvNtNtCslbxve4rcJus_4gpui7runtime5image11acknowledge+0x6f>
  7aa2a1:	mov    %rdi,%rbx
  7aa2a4:	mov    0x38(%r14),%r15
  7aa2a8:	cmp    $0xffffffffffffffff,%r15
  7aa2ac:	je     7aa2db <_RNvNtNtCslbxve4rcJus_4gpui7runtime5image11acknowledge+0x4b>
  7aa2ae:	cmp    %rsi,0x30(%r14)
  7aa2b2:	jne    7aa2db <_RNvNtNtCslbxve4rcJus_4gpui7runtime5image11acknowledge+0x4b>
  7aa2b4:	movups 0x40(%r14),%xmm0
  7aa2b9:	movaps %xmm0,(%rsp)
  7aa2bd:	movq   $0xffffffffffffffff,0x38(%r14)
  7aa2c5:	lea    0x18(%r14),%rdi
  7aa2c9:	call   799380 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCsghYClfd3M9V_11gpui_canvas5image5ImageEECslbxve4rcJus_4gpui>
  7aa2ce:	mov    %r15,0x18(%r14)
  7aa2d2:	movaps (%rsp),%xmm0
  7aa2d6:	movups %xmm0,0x20(%r14)
  7aa2db:	cmpq   $0x0,0x10(%r14)
  7aa2e0:	jne    7aa2ff <_RNvNtNtCslbxve4rcJus_4gpui7runtime5image11acknowledge+0x6f>
  7aa2e2:	cmpq   $0x0,0x28(%r14)
  7aa2e7:	jne    7aa2ff <_RNvNtNtCslbxve4rcJus_4gpui7runtime5image11acknowledge+0x6f>
  7aa2e9:	cmpq   $0xffffffffffffffff,0x38(%r14)
  7aa2ee:	jne    7aa2ff <_RNvNtNtCslbxve4rcJus_4gpui7runtime5image11acknowledge+0x6f>
  7aa2f0:	mov    %r14,%rdi
  7aa2f3:	call   7990f0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionINtNtCscdodAO9FK5_5alloc5boxed3BoxNtNtNtCslbxve4rcJus_4gpui7runtime5image6ImagesEEEB1B_>
  7aa2f8:	movq   $0x0,(%rbx)
  7aa2ff:	add    $0x10,%rsp
  7aa303:	pop    %rbx
  7aa304:	pop    %r14
  7aa306:	pop    %r15
  7aa308:	ret
  7aa309:	movq   $0x0,(%rbx)
  7aa310:	mov    %rax,%rdi
  7aa313:	call   a97420 <_Unwind_Resume@plt>
  7aa318:	mov    %r15,0x18(%r14)
  7aa31c:	movaps (%rsp),%xmm0
  7aa320:	movups %xmm0,0x20(%r14)
  7aa325:	mov    %rax,%rdi
  7aa328:	call   a97420 <_Unwind_Resume@plt>

core::ptr::drop_glue::<core::option::Option<gpui_canvas::text::layout::TextGeometry>> bytes=108 frame=8

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007bb030 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryEEB13_>:
  7bb030:	push   %rbx
  7bb031:	mov    (%rdi),%rax
  7bb034:	cmp    $0xffffffffffffffff,%rax
  7bb038:	je     7bb09a <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryEEB13_+0x6a>
  7bb03a:	mov    %rdi,%rbx
  7bb03d:	test   %rax,%rax
  7bb040:	je     7bb059 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryEEB13_+0x29>
  7bb042:	mov    0x8(%rbx),%rdi
  7bb046:	shl    $0x3,%rax
  7bb04a:	lea    (%rax,%rax,2),%rsi
  7bb04e:	mov    $0x4,%edx
  7bb053:	call   *0x2fdf17(%rip)        # ab8f70 <_DYNAMIC+0x240>
  7bb059:	mov    0x18(%rbx),%rax
  7bb05d:	test   %rax,%rax
  7bb060:	je     7bb079 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryEEB13_+0x49>
  7bb062:	mov    0x20(%rbx),%rdi
  7bb066:	shl    $0x3,%rax
  7bb06a:	lea    (%rax,%rax,2),%rsi
  7bb06e:	mov    $0x4,%edx
  7bb073:	call   *0x2fdef7(%rip)        # ab8f70 <_DYNAMIC+0x240>
  7bb079:	mov    0x30(%rbx),%rax
  7bb07d:	test   %rax,%rax
  7bb080:	je     7bb09a <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryEEB13_+0x6a>
  7bb082:	mov    0x38(%rbx),%rdi
  7bb086:	shl    $0x2,%rax
  7bb08a:	lea    (%rax,%rax,2),%rsi
  7bb08e:	mov    $0x4,%edx
  7bb093:	pop    %rbx
  7bb094:	jmp    *0x2fded6(%rip)        # ab8f70 <_DYNAMIC+0x240>
  7bb09a:	pop    %rbx
  7bb09b:	ret

core::ptr::drop_glue::<alloc::sync::ArcInner<gpui_canvas::text::layout::TextGeometry>> bytes=103 frame=8

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007bbd70 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc4sync8ArcInnerNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryEEB1j_>:
  7bbd70:	push   %rbx
  7bbd71:	mov    %rdi,%rbx
  7bbd74:	mov    0x10(%rdi),%rax
  7bbd78:	test   %rax,%rax
  7bbd7b:	je     7bbd94 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc4sync8ArcInnerNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryEEB1j_+0x24>
  7bbd7d:	mov    0x18(%rbx),%rdi
  7bbd81:	shl    $0x3,%rax
  7bbd85:	lea    (%rax,%rax,2),%rsi
  7bbd89:	mov    $0x4,%edx
  7bbd8e:	call   *0x2fd1dc(%rip)        # ab8f70 <_DYNAMIC+0x240>
  7bbd94:	mov    0x28(%rbx),%rax
  7bbd98:	test   %rax,%rax
  7bbd9b:	je     7bbdb4 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc4sync8ArcInnerNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryEEB1j_+0x44>
  7bbd9d:	mov    0x30(%rbx),%rdi
  7bbda1:	shl    $0x3,%rax
  7bbda5:	lea    (%rax,%rax,2),%rsi
  7bbda9:	mov    $0x4,%edx
  7bbdae:	call   *0x2fd1bc(%rip)        # ab8f70 <_DYNAMIC+0x240>
  7bbdb4:	mov    0x40(%rbx),%rax
  7bbdb8:	test   %rax,%rax
  7bbdbb:	je     7bbdd5 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc4sync8ArcInnerNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryEEB1j_+0x65>
  7bbdbd:	mov    0x48(%rbx),%rdi
  7bbdc1:	shl    $0x2,%rax
  7bbdc5:	lea    (%rax,%rax,2),%rsi
  7bbdc9:	mov    $0x4,%edx
  7bbdce:	pop    %rbx
  7bbdcf:	jmp    *0x2fd19b(%rip)        # ab8f70 <_DYNAMIC+0x240>
  7bbdd5:	pop    %rbx
  7bbdd6:	ret

<gpui_canvas::text::layout::TextGeometry>::intervals::{closure#3} bytes=687 frame=56

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007c8ac0 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_>:
  7c8ac0:	push   %rbp
  7c8ac1:	push   %r15
  7c8ac3:	push   %r14
  7c8ac5:	push   %r13
  7c8ac7:	push   %r12
  7c8ac9:	push   %rbx
  7c8aca:	push   %rax
  7c8acb:	cmp    $0x2,%rcx
  7c8acf:	jb     7c8d32 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x272>
  7c8ad5:	mov    (%rsi),%r11
  7c8ad8:	mov    0x8(%rsi),%rax
  7c8adc:	mov    0x20(%r11),%r9
  7c8ae0:	mov    0x28(%r11),%r8
  7c8ae4:	lea    0x1(%rax),%r10
  7c8ae8:	cmp    %r8,%r10
  7c8aeb:	jae    7c8b2d <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x6d>
  7c8aed:	mov    (%rdx),%ecx
  7c8aef:	lea    (%r10,%r10,2),%rbx
  7c8af3:	cmp    %ecx,(%r9,%rbx,8)
  7c8af7:	ja     7c8b2d <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x6d>
  7c8af9:	lea    (%rax,%rax,2),%rax
  7c8afd:	lea    (%r9,%rax,8),%r14
  7c8b01:	add    $0x30,%r14
  7c8b05:	mov    $0x2,%ebx
  7c8b0a:	sub    %r8,%rbx
  7c8b0d:	nopl   (%rax)
  7c8b10:	mov    %r10,%rax
  7c8b13:	add    %rbx,%r10
  7c8b16:	cmp    $0x1,%r10
  7c8b1a:	je     7c8b29 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x69>
  7c8b1c:	lea    0x1(%rax),%r10
  7c8b20:	cmp    %ecx,(%r14)
  7c8b23:	lea    0x18(%r14),%r14
  7c8b27:	jbe    7c8b10 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x50>
  7c8b29:	mov    %rax,0x8(%rsi)
  7c8b2d:	cmp    %r8,%rax
  7c8b30:	jae    7c8d49 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x289>
  7c8b36:	lea    (%rax,%rax,2),%r10
  7c8b3a:	testb  $0x1,0x8(%rdx)
  7c8b3e:	mov    %rax,%rcx
  7c8b41:	jne    7c8b79 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0xb9>
  7c8b43:	cmp    %r8,%rcx
  7c8b46:	jae    7c8d5c <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x29c>
  7c8b4c:	mov    0xc(%rdx),%r8d
  7c8b50:	mov    0x4(%r9,%r10,8),%r10d
  7c8b55:	movss  0x4(%rdx),%xmm0
  7c8b5a:	movss  0x10(%rdx),%xmm1
  7c8b5f:	cmp    %r10d,%r8d
  7c8b62:	ja     7c8bdd <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x11d>
  7c8b64:	ucomiss %xmm1,%xmm0
  7c8b67:	jne    7c8b6b <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0xab>
  7c8b69:	jnp    7c8bdd <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x11d>
  7c8b6b:	ucomiss %xmm0,%xmm1
  7c8b6e:	setbe  %r11b
  7c8b72:	mov    (%rdx),%edx
  7c8b74:	jmp    7c8c8e <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x1ce>
  7c8b79:	mov    %rax,%rcx
  7c8b7c:	test   %rax,%rax
  7c8b7f:	je     7c8b43 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x83>
  7c8b81:	mov    (%rdx),%ebx
  7c8b83:	mov    %rax,%rcx
  7c8b86:	test   %ebx,%ebx
  7c8b88:	je     7c8b43 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x83>
  7c8b8a:	lea    (%r9,%r10,8),%r14
  7c8b8e:	mov    %rax,%rcx
  7c8b91:	cmp    %ebx,-0x14(%r14)
  7c8b95:	jne    7c8b43 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x83>
  7c8b97:	xor    %ecx,%ecx
  7c8b99:	mov    %r8,%r14
  7c8b9c:	nopl   0x0(%rax)
  7c8ba0:	mov    %r14,%r15
  7c8ba3:	shr    $1,%r15
  7c8ba6:	lea    (%r15,%rcx,1),%r12
  7c8baa:	lea    (%r12,%r12,2),%r13
  7c8bae:	cmp    %ebx,0x4(%r9,%r13,8)
  7c8bb3:	cmovb  %r12,%rcx
  7c8bb7:	sub    %r15,%r14
  7c8bba:	cmp    $0x1,%r14
  7c8bbe:	ja     7c8ba0 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0xe0>
  7c8bc0:	lea    (%rcx,%rcx,2),%r14
  7c8bc4:	cmp    %ebx,0x4(%r9,%r14,8)
  7c8bc9:	adc    $0x0,%rcx
  7c8bcd:	lea    -0x1(%r8),%rbx
  7c8bd1:	cmp    %rcx,%rbx
  7c8bd4:	cmovb  %rbx,%rcx
  7c8bd8:	jmp    7c8b43 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x83>
  7c8bdd:	mov    0x8(%r11),%rbx
  7c8be1:	mov    0x10(%r11),%r11
  7c8be5:	mov    %r11,%r14
  7c8be8:	test   %r11,%r11
  7c8beb:	je     7c8c39 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x179>
  7c8bed:	xor    %r14d,%r14d
  7c8bf0:	cmp    $0x1,%r11
  7c8bf4:	je     7c8c29 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x169>
  7c8bf6:	mov    %r11,%r15
  7c8bf9:	nopl   0x0(%rax)
  7c8c00:	mov    %r15,%r12
  7c8c03:	shr    $1,%r12
  7c8c06:	lea    (%r12,%r14,1),%r13
  7c8c0a:	lea    0x0(,%r13,2),%rbp
  7c8c12:	add    %r13,%rbp
  7c8c15:	mov    0x10(%rbx,%rbp,8),%ebp
  7c8c19:	cmp    %rbp,%rax
  7c8c1c:	cmova  %r13,%r14
  7c8c20:	sub    %r12,%r15
  7c8c23:	cmp    $0x1,%r15
  7c8c27:	ja     7c8c00 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x140>
  7c8c29:	lea    (%r14,%r14,2),%r15
  7c8c2d:	mov    0x10(%rbx,%r15,8),%r15d
  7c8c32:	cmp    %rax,%r15
  7c8c35:	adc    $0x0,%r14
  7c8c39:	shl    $0x3,%r14
  7c8c3d:	lea    (%r14,%r14,2),%r14
  7c8c41:	lea    (%rbx,%r14,1),%r15
  7c8c45:	mov    (%rdx),%edx
  7c8c47:	shl    $0x3,%r11
  7c8c4b:	lea    (%r11,%r11,2),%r11
  7c8c4f:	nop
  7c8c50:	cmp    %r14,%r11
  7c8c53:	je     7c8d13 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x253>
  7c8c59:	mov    %r15,%r12
  7c8c5c:	mov    0x10(%r15),%r15d
  7c8c60:	cmp    %r15,%rax
  7c8c63:	jne    7c8d13 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x253>
  7c8c69:	lea    0x18(%r12),%r15
  7c8c6e:	add    $0x18,%r14
  7c8c72:	cmp    %edx,(%r12)
  7c8c76:	ja     7c8c50 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x190>
  7c8c78:	cmp    0x4(%r12),%edx
  7c8c7d:	ja     7c8c50 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x190>
  7c8c7f:	movzbl -0x3(%rbx,%r14,1),%r11d
  7c8c85:	cmp    %r10d,%r8d
  7c8c88:	ja     7c8d1f <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x25f>
  7c8c8e:	movaps %xmm0,%xmm3
  7c8c91:	minss  %xmm1,%xmm3
  7c8c95:	movaps %xmm3,%xmm2
  7c8c98:	cmpunordss %xmm3,%xmm2
  7c8c9d:	movaps %xmm2,%xmm4
  7c8ca0:	andps  %xmm0,%xmm4
  7c8ca3:	andnps %xmm3,%xmm2
  7c8ca6:	orps   %xmm4,%xmm2
  7c8ca9:	movaps %xmm1,%xmm3
  7c8cac:	subss  %xmm0,%xmm3
  7c8cb0:	andps  -0x705857(%rip),%xmm3        # c3460 <GCC_except_table0+0x10c0>
  7c8cb7:	cmp    %r10d,%r8d
  7c8cba:	lea    (%rcx,%rcx,2),%rcx
  7c8cbe:	movss  0x8(%r9,%rcx,8),%xmm4
  7c8cc5:	movss  0xc(%r9,%rcx,8),%xmm5
  7c8ccc:	mov    %edx,(%rdi)
  7c8cce:	movb   $0x1,0x4(%rdi)
  7c8cd2:	mov    %r8d,0x8(%rdi)
  7c8cd6:	movb   $0x0,0xc(%rdi)
  7c8cda:	movss  %xmm0,0x28(%rdi)
  7c8cdf:	movss  %xmm1,0x2c(%rdi)
  7c8ce4:	movss  %xmm2,0x10(%rdi)
  7c8ce9:	movss  %xmm4,0x14(%rdi)
  7c8cee:	movss  %xmm3,0x18(%rdi)
  7c8cf3:	movss  %xmm5,0x1c(%rdi)
  7c8cf8:	mov    %rax,0x20(%rdi)
  7c8cfc:	seta   0x30(%rdi)
  7c8d00:	mov    %r11b,0x31(%rdi)
  7c8d04:	add    $0x8,%rsp
  7c8d08:	pop    %rbx
  7c8d09:	pop    %r12
  7c8d0b:	pop    %r13
  7c8d0d:	pop    %r14
  7c8d0f:	pop    %r15
  7c8d11:	pop    %rbp
  7c8d12:	ret
  7c8d13:	xor    %r11d,%r11d
  7c8d16:	cmp    %r10d,%r8d
  7c8d19:	jbe    7c8c8e <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x1ce>
  7c8d1f:	movss  0x10(%rsi),%xmm3
  7c8d24:	movaps %xmm0,%xmm2
  7c8d27:	test   %r11b,%r11b
  7c8d2a:	je     7c8cb7 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x1f7>
  7c8d2c:	subss  %xmm3,%xmm2
  7c8d30:	jmp    7c8cb7 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_+0x1f7>
  7c8d32:	lea    0x2d3d1f(%rip),%rdx        # a9ca58 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0xf80>
  7c8d39:	mov    $0x1,%edi
  7c8d3e:	mov    $0x1,%esi
  7c8d43:	call   *0x2f0257(%rip)        # ab8fa0 <_DYNAMIC+0x270>
  7c8d49:	lea    0x2d3d20(%rip),%rdx        # a9ca70 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0xf98>
  7c8d50:	mov    %rax,%rdi
  7c8d53:	mov    %r8,%rsi
  7c8d56:	call   *0x2f0244(%rip)        # ab8fa0 <_DYNAMIC+0x270>
  7c8d5c:	lea    0x2d3d25(%rip),%rdx        # a9ca88 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0xfb0>
  7c8d63:	mov    %rcx,%rdi
  7c8d66:	mov    %r8,%rsi
  7c8d69:	call   *0x2f0231(%rip)        # ab8fa0 <_DYNAMIC+0x270>

<gpui_canvas::text::layout::TextGeometry>::grapheme_at bytes=850 frame=264

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007d4c50 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at>:
  7d4c50:	push   %rbp
  7d4c51:	push   %r15
  7d4c53:	push   %r14
  7d4c55:	push   %r13
  7d4c57:	push   %r12
  7d4c59:	push   %rbx
  7d4c5a:	sub    $0xd8,%rsp
  7d4c61:	mov    %rdi,%rbx
  7d4c64:	movd   %xmm1,%eax
  7d4c68:	movd   %xmm0,%ecx
  7d4c6c:	and    $0x7fffffff,%ecx
  7d4c72:	cmp    $0x7f800000,%ecx
  7d4c78:	setge  %cl
  7d4c7b:	and    $0x7fffffff,%eax
  7d4c80:	cmp    $0x7f800000,%eax
  7d4c85:	setge  %al
  7d4c88:	or     %cl,%al
  7d4c8a:	cmp    $0x1,%al
  7d4c8c:	jne    7d4c97 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x47>
  7d4c8e:	movb   $0x2,0x4(%rbx)
  7d4c92:	jmp    7d4e2e <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x1de>
  7d4c97:	mov    0x20(%rsi),%rcx
  7d4c9b:	mov    0x28(%rsi),%rax
  7d4c9f:	mov    %rax,%r14
  7d4ca2:	test   %rax,%rax
  7d4ca5:	je     7d4cfe <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0xae>
  7d4ca7:	xor    %edx,%edx
  7d4ca9:	cmp    $0x1,%rax
  7d4cad:	je     7d4ce3 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x93>
  7d4caf:	mov    %rax,%rdi
  7d4cb2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  7d4cc0:	mov    %rdx,%r8
  7d4cc3:	mov    %rdi,%r9
  7d4cc6:	shr    $1,%r9
  7d4cc9:	add    %r9,%rdx
  7d4ccc:	lea    (%rdx,%rdx,2),%r10
  7d4cd0:	ucomiss 0x8(%rcx,%r10,8),%xmm1
  7d4cd6:	cmovb  %r8,%rdx
  7d4cda:	sub    %r9,%rdi
  7d4cdd:	cmp    $0x1,%rdi
  7d4ce1:	ja     7d4cc0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x70>
  7d4ce3:	lea    (%rdx,%rdx,2),%rdi
  7d4ce7:	xor    %r14d,%r14d
  7d4cea:	ucomiss 0x8(%rcx,%rdi,8),%xmm1
  7d4cef:	setae  %r14b
  7d4cf3:	add    %rdx,%r14
  7d4cf6:	cmp    $0x1,%r14
  7d4cfa:	adc    $0xffffffffffffffff,%r14
  7d4cfe:	mov    %r14,0x10(%rsp)
  7d4d03:	cmp    %rax,%r14
  7d4d06:	jae    7d4f8f <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x33f>
  7d4d0c:	lea    (%r14,%r14,2),%rdx
  7d4d10:	mov    (%rcx,%rdx,8),%r8d
  7d4d14:	test   %r8d,%r8d
  7d4d17:	movss  %xmm1,0xc(%rsp)
  7d4d1d:	movd   %xmm0,0x8(%rsp)
  7d4d23:	je     7d4d6d <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x11d>
  7d4d25:	mov    0x38(%rsi),%rdx
  7d4d29:	mov    0x40(%rsi),%r13
  7d4d2d:	test   %r13,%r13
  7d4d30:	je     7d4d79 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x129>
  7d4d32:	xor    %edi,%edi
  7d4d34:	cmp    $0x1,%r13
  7d4d38:	je     7d4d5f <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x10f>
  7d4d3a:	mov    %r13,%r9
  7d4d3d:	nopl   (%rax)
  7d4d40:	mov    %r9,%r10
  7d4d43:	shr    $1,%r10
  7d4d46:	lea    (%r10,%rdi,1),%r11
  7d4d4a:	lea    (%r11,%r11,2),%r15
  7d4d4e:	cmp    %r8d,(%rdx,%r15,4)
  7d4d52:	cmovb  %r11,%rdi
  7d4d56:	sub    %r10,%r9
  7d4d59:	cmp    $0x1,%r9
  7d4d5d:	ja     7d4d40 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0xf0>
  7d4d5f:	lea    (%rdi,%rdi,2),%r9
  7d4d63:	cmp    %r8d,(%rdx,%r9,4)
  7d4d67:	adc    $0x0,%rdi
  7d4d6b:	jmp    7d4d7c <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x12c>
  7d4d6d:	mov    0x38(%rsi),%rdx
  7d4d71:	mov    0x40(%rsi),%r13
  7d4d75:	xor    %edi,%edi
  7d4d77:	jmp    7d4d7c <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x12c>
  7d4d79:	mov    %r13,%rdi
  7d4d7c:	lea    (%rdi,%rdi,2),%r8
  7d4d80:	lea    (%rdx,%r8,4),%r15
  7d4d84:	movss  0x4c(%rsi),%xmm0
  7d4d89:	sub    %rdi,%r13
  7d4d8c:	je     7d4f67 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x317>
  7d4d92:	mov    (%r15),%edx
  7d4d95:	mulss  -0x712905(%rip),%xmm0        # c2498 <GCC_except_table0+0xf8>
  7d4d9d:	xor    %edi,%edi
  7d4d9f:	cmp    $0x1,%rax
  7d4da3:	je     7d4dd1 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x181>
  7d4da5:	data16 cs nopw 0x0(%rax,%rax,1)
  7d4db0:	mov    %rdi,%r8
  7d4db3:	mov    %rax,%r9
  7d4db6:	shr    $1,%r9
  7d4db9:	add    %r9,%rdi
  7d4dbc:	lea    (%rdi,%rdi,2),%r10
  7d4dc0:	cmp    %edx,(%rcx,%r10,8)
  7d4dc4:	cmova  %r8,%rdi
  7d4dc8:	sub    %r9,%rax
  7d4dcb:	cmp    $0x1,%rax
  7d4dcf:	ja     7d4db0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x160>
  7d4dd1:	lea    (%rdi,%rdi,2),%rax
  7d4dd5:	xor    %r8d,%r8d
  7d4dd8:	cmp    %edx,(%rcx,%rax,8)
  7d4ddb:	setbe  %r8b
  7d4ddf:	add    %rdi,%r8
  7d4de2:	cmp    $0x1,%r8
  7d4de6:	adc    $0xffffffffffffffff,%r8
  7d4dea:	mov    %r15,0x18(%rsp)
  7d4def:	mov    %r13,0x20(%rsp)
  7d4df4:	movq   $0x2,0x28(%rsp)
  7d4dfd:	mov    %rsi,0x30(%rsp)
  7d4e02:	mov    %r8,0x38(%rsp)
  7d4e07:	movss  %xmm0,0x40(%rsp)
  7d4e0d:	movb   $0x0,0x58(%rsp)
  7d4e12:	mov    %rsi,0x48(%rsp)
  7d4e17:	lea    0x10(%rsp),%rax
  7d4e1c:	mov    %rax,0x50(%rsp)
  7d4e21:	mov    $0x2,%r12b
  7d4e24:	cmp    $0x2,%r13
  7d4e28:	jae    7d4e43 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x1f3>
  7d4e2a:	mov    %r12b,0x4(%rbx)
  7d4e2e:	mov    %rbx,%rax
  7d4e31:	add    $0xd8,%rsp
  7d4e38:	pop    %rbx
  7d4e39:	pop    %r12
  7d4e3b:	pop    %r13
  7d4e3d:	pop    %r14
  7d4e3f:	pop    %r15
  7d4e41:	pop    %rbp
  7d4e42:	ret
  7d4e43:	inc    %r13
  7d4e46:	jmp    7d4e5d <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x20d>
  7d4e48:	nopl   0x0(%rax,%rax,1)
  7d4e50:	add    $0xc,%r15
  7d4e54:	dec    %r13
  7d4e57:	cmp    $0x3,%r13
  7d4e5b:	jb     7d4e2a <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x1da>
  7d4e5d:	mov    (%r15),%eax
  7d4e60:	cmp    0xc(%r15),%eax
  7d4e64:	je     7d4e50 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x200>
  7d4e66:	testb  $0x2,0x8(%r15)
  7d4e6b:	je     7d4e50 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x200>
  7d4e6d:	testb  $0x1,0x14(%r15)
  7d4e72:	je     7d4e50 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x200>
  7d4e74:	mov    $0x2,%ecx
  7d4e79:	lea    0xa0(%rsp),%rdi
  7d4e81:	lea    0x30(%rsp),%rsi
  7d4e86:	mov    %r15,%rdx
  7d4e89:	call   7c8ac0 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_>
  7d4e8e:	mov    0x48(%rsp),%rax
  7d4e93:	mov    0x50(%rsp),%rcx
  7d4e98:	mov    (%rcx),%rdi
  7d4e9b:	mov    0x28(%rax),%rsi
  7d4e9f:	cmp    %rsi,%rdi
  7d4ea2:	jae    7d4f82 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x332>
  7d4ea8:	mov    0xa0(%rsp),%ebp
  7d4eaf:	mov    0x20(%rax),%rax
  7d4eb3:	lea    (%rdi,%rdi,2),%rcx
  7d4eb7:	cmp    0x4(%rax,%rcx,8),%ebp
  7d4ebb:	ja     7d4e2a <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x1da>
  7d4ec1:	cmp    %r14,0xc0(%rsp)
  7d4ec9:	jne    7d4e50 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x200>
  7d4ecb:	lea    0xb0(%rsp),%rdi
  7d4ed3:	movss  0x8(%rsp),%xmm0
  7d4ed9:	movss  0xc(%rsp),%xmm1
  7d4edf:	call   *0x2e44db(%rip)        # ab93c0 <_DYNAMIC+0x690>
  7d4ee5:	test   %al,%al
  7d4ee7:	je     7d4e50 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x200>
  7d4eed:	movzbl 0xa4(%rsp),%eax
  7d4ef5:	cmp    $0x2,%al
  7d4ef7:	je     7d4e50 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x200>
  7d4efd:	lea    0xb0(%rsp),%rdx
  7d4f05:	mov    0x24(%rdx),%ecx
  7d4f08:	mov    %ecx,0x8f(%rsp)
  7d4f0f:	movups -0xb(%rdx),%xmm0
  7d4f13:	movups 0x5(%rdx),%xmm1
  7d4f17:	movups 0x15(%rdx),%xmm2
  7d4f1b:	movaps %xmm2,0x80(%rsp)
  7d4f23:	movaps %xmm1,0x70(%rsp)
  7d4f28:	movaps %xmm0,0x60(%rsp)
  7d4f2d:	cmp    $0xff,%al
  7d4f2f:	je     7d4e50 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x200>
  7d4f35:	mov    0x8f(%rsp),%ecx
  7d4f3c:	mov    %ecx,0x34(%rbx)
  7d4f3f:	movaps 0x60(%rsp),%xmm0
  7d4f44:	movaps 0x70(%rsp),%xmm1
  7d4f49:	movaps 0x80(%rsp),%xmm2
  7d4f51:	movups %xmm2,0x25(%rbx)
  7d4f55:	movups %xmm1,0x15(%rbx)
  7d4f59:	movups %xmm0,0x5(%rbx)
  7d4f5d:	mov    %ebp,(%rbx)
  7d4f5f:	mov    %eax,%r12d
  7d4f62:	jmp    7d4e2a <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x1da>
  7d4f67:	xor    %edx,%edx
  7d4f69:	mulss  -0x712ad9(%rip),%xmm0        # c2498 <GCC_except_table0+0xf8>
  7d4f71:	xor    %edi,%edi
  7d4f73:	cmp    $0x1,%rax
  7d4f77:	jne    7d4db0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x160>
  7d4f7d:	jmp    7d4dd1 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x181>
  7d4f82:	lea    0x2c7a3f(%rip),%rdx        # a9c9c8 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0xef0>
  7d4f89:	call   *0x2e4011(%rip)        # ab8fa0 <_DYNAMIC+0x270>
  7d4f8f:	lea    0x2c836a(%rip),%rdx        # a9d300 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0x1828>
  7d4f96:	mov    %r14,%rdi
  7d4f99:	mov    %rax,%rsi
  7d4f9c:	call   *0x2e3ffe(%rip)        # ab8fa0 <_DYNAMIC+0x270>

<gpui_canvas::text::layout::TextGeometry>::move_visual bytes=1175 frame=216

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007d4fb0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual>:
  7d4fb0:	push   %rbp
  7d4fb1:	push   %r15
  7d4fb3:	push   %r14
  7d4fb5:	push   %r13
  7d4fb7:	push   %r12
  7d4fb9:	push   %rbx
  7d4fba:	sub    $0xa8,%rsp
  7d4fc1:	mov    %ecx,%r14d
  7d4fc4:	mov    %edx,%r13d
  7d4fc7:	mov    %esi,%ebp
  7d4fc9:	mov    %rdi,%rbx
  7d4fcc:	lea    0x20(%rsp),%rdi
  7d4fd1:	mov    %rbx,%rsi
  7d4fd4:	mov    %ebp,%edx
  7d4fd6:	mov    %r13d,%ecx
  7d4fd9:	call   *0x2e48f9(%rip)        # ab98d8 <_DYNAMIC+0xba8>
  7d4fdf:	cmpl   $0x1,0x20(%rsp)
  7d4fe4:	jne    7d505b <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0xab>
  7d4fe6:	test   %ebp,%ebp
  7d4fe8:	setne  %cl
  7d4feb:	mov    %r13d,%edx
  7d4fee:	not    %dl
  7d4ff0:	mov    0x20(%rbx),%rax
  7d4ff4:	mov    0x28(%rbx),%r12
  7d4ff8:	mov    %r12,%rdi
  7d4ffb:	test   %cl,%dl
  7d4ffd:	jne    7d5063 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0xb3>
  7d4fff:	test   %r12,%r12
  7d5002:	je     7d50b8 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x108>
  7d5008:	xor    %ecx,%ecx
  7d500a:	cmp    $0x1,%r12
  7d500e:	je     7d5041 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x91>
  7d5010:	mov    %r12,%rdx
  7d5013:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  7d5020:	mov    %rcx,%rsi
  7d5023:	mov    %rdx,%rdi
  7d5026:	shr    $1,%rdi
  7d5029:	add    %rdi,%rcx
  7d502c:	lea    (%rcx,%rcx,2),%r8
  7d5030:	cmp    %ebp,(%rax,%r8,8)
  7d5034:	cmova  %rsi,%rcx
  7d5038:	sub    %rdi,%rdx
  7d503b:	cmp    $0x1,%rdx
  7d503f:	ja     7d5020 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x70>
  7d5041:	lea    (%rcx,%rcx,2),%rdx
  7d5045:	xor    %edi,%edi
  7d5047:	cmp    %ebp,(%rax,%rdx,8)
  7d504a:	setbe  %dil
  7d504e:	add    %rcx,%rdi
  7d5051:	cmp    $0x1,%rdi
  7d5055:	adc    $0xffffffffffffffff,%rdi
  7d5059:	jmp    7d50b8 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x108>
  7d505b:	mov    $0x2,%r13b
  7d505e:	jmp    7d5413 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x463>
  7d5063:	test   %r12,%r12
  7d5066:	je     7d50ac <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0xfc>
  7d5068:	xor    %edi,%edi
  7d506a:	cmp    $0x1,%r12
  7d506e:	je     7d50a0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0xf0>
  7d5070:	mov    %r12,%rcx
  7d5073:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  7d5080:	mov    %rcx,%rdx
  7d5083:	shr    $1,%rdx
  7d5086:	lea    (%rdx,%rdi,1),%rsi
  7d508a:	lea    (%rsi,%rsi,2),%r8
  7d508e:	cmp    %ebp,0x4(%rax,%r8,8)
  7d5093:	cmovb  %rsi,%rdi
  7d5097:	sub    %rdx,%rcx
  7d509a:	cmp    $0x1,%rcx
  7d509e:	ja     7d5080 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0xd0>
  7d50a0:	lea    (%rdi,%rdi,2),%rcx
  7d50a4:	cmp    %ebp,0x4(%rax,%rcx,8)
  7d50a8:	adc    $0x0,%rdi
  7d50ac:	lea    -0x1(%r12),%rcx
  7d50b1:	cmp    %rdi,%rcx
  7d50b4:	cmovb  %rcx,%rdi
  7d50b8:	movss  0x24(%rsp),%xmm0
  7d50be:	movss  %xmm0,0xc(%rsp)
  7d50c4:	mov    %rdi,0x18(%rsp)
  7d50c9:	cmp    %r12,%rdi
  7d50cc:	jae    7d5437 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x487>
  7d50d2:	mov    %r14d,0x4(%rsp)
  7d50d7:	lea    (%rdi,%rdi,2),%rcx
  7d50db:	mov    (%rax,%rcx,8),%edx
  7d50de:	test   %edx,%edx
  7d50e0:	je     7d512d <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x17d>
  7d50e2:	mov    0x38(%rbx),%r15
  7d50e6:	mov    0x40(%rbx),%r14
  7d50ea:	xor    %ecx,%ecx
  7d50ec:	test   %r14,%r14
  7d50ef:	je     7d517d <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x1cd>
  7d50f5:	cmp    $0x1,%r14
  7d50f9:	je     7d511f <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x16f>
  7d50fb:	xor    %ecx,%ecx
  7d50fd:	mov    %r14,%rsi
  7d5100:	mov    %rsi,%rdi
  7d5103:	shr    $1,%rdi
  7d5106:	lea    (%rdi,%rcx,1),%r8
  7d510a:	lea    (%r8,%r8,2),%r9
  7d510e:	cmp    %edx,(%r15,%r9,4)
  7d5112:	cmovb  %r8,%rcx
  7d5116:	sub    %rdi,%rsi
  7d5119:	cmp    $0x1,%rsi
  7d511d:	ja     7d5100 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x150>
  7d511f:	lea    (%rcx,%rcx,2),%rsi
  7d5123:	cmp    %edx,(%r15,%rsi,4)
  7d5127:	adc    $0x0,%rcx
  7d512b:	jmp    7d5137 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x187>
  7d512d:	mov    0x38(%rbx),%r15
  7d5131:	mov    0x40(%rbx),%r14
  7d5135:	xor    %ecx,%ecx
  7d5137:	lea    (%rcx,%rcx,2),%rdx
  7d513b:	lea    (%r15,%rdx,4),%r15
  7d513f:	movss  0x4c(%rbx),%xmm0
  7d5144:	sub    %rcx,%r14
  7d5147:	jne    7d5163 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x1b3>
  7d5149:	xor    %r14d,%r14d
  7d514c:	xor    %ecx,%ecx
  7d514e:	mulss  -0x712cbe(%rip),%xmm0        # c2498 <GCC_except_table0+0xf8>
  7d5156:	cmp    $0x1,%r12
  7d515a:	mov    %r13d,0x14(%rsp)
  7d515f:	je     7d5179 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x1c9>
  7d5161:	jmp    7d5198 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x1e8>
  7d5163:	mov    (%r15),%ecx
  7d5166:	mulss  -0x712cd6(%rip),%xmm0        # c2498 <GCC_except_table0+0xf8>
  7d516e:	cmp    $0x1,%r12
  7d5172:	mov    %r13d,0x14(%rsp)
  7d5177:	jne    7d5198 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x1e8>
  7d5179:	xor    %edx,%edx
  7d517b:	jmp    7d51c1 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x211>
  7d517d:	movss  0x4c(%rbx),%xmm0
  7d5182:	xor    %r14d,%r14d
  7d5185:	mulss  -0x712cf5(%rip),%xmm0        # c2498 <GCC_except_table0+0xf8>
  7d518d:	cmp    $0x1,%r12
  7d5191:	mov    %r13d,0x14(%rsp)
  7d5196:	je     7d5179 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x1c9>
  7d5198:	xor    %edx,%edx
  7d519a:	mov    %r12,%rsi
  7d519d:	nopl   (%rax)
  7d51a0:	mov    %rdx,%rdi
  7d51a3:	mov    %rsi,%r8
  7d51a6:	shr    $1,%r8
  7d51a9:	add    %r8,%rdx
  7d51ac:	lea    (%rdx,%rdx,2),%r9
  7d51b0:	cmp    %ecx,(%rax,%r9,8)
  7d51b4:	cmova  %rdi,%rdx
  7d51b8:	sub    %r8,%rsi
  7d51bb:	cmp    $0x1,%rsi
  7d51bf:	ja     7d51a0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x1f0>
  7d51c1:	lea    (%rdx,%rdx,2),%rsi
  7d51c5:	xor    %edi,%edi
  7d51c7:	cmp    %ecx,(%rax,%rsi,8)
  7d51ca:	setbe  %dil
  7d51ce:	add    %rdx,%rdi
  7d51d1:	cmp    $0x1,%rdi
  7d51d5:	adc    $0xffffffffffffffff,%rdi
  7d51d9:	lea    0x18(%rsp),%rax
  7d51de:	mov    %rax,0x20(%rsp)
  7d51e3:	mov    %r15,0x28(%rsp)
  7d51e8:	mov    %r14,0x30(%rsp)
  7d51ed:	movq   $0x2,0x38(%rsp)
  7d51f6:	mov    %rbx,0x40(%rsp)
  7d51fb:	mov    %rdi,0x48(%rsp)
  7d5200:	movss  %xmm0,0x50(%rsp)
  7d5206:	mov    %rbx,0x58(%rsp)
  7d520b:	mov    %rax,0x60(%rsp)
  7d5210:	movb   $0x0,0x68(%rsp)
  7d5215:	movss  -0x712ced(%rip),%xmm0        # c2530 <GCC_except_table0+0x190>
  7d521d:	movss  %xmm0,0x10(%rsp)
  7d5223:	mov    $0x2,%r13b
  7d5226:	cmp    $0x2,%r14
  7d522a:	jb     7d5399 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x3e9>
  7d5230:	inc    %r14
  7d5233:	add    $0xc,%r15
  7d5237:	jmp    7d5251 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x2a1>
  7d5239:	nopl   0x0(%rax)
  7d5240:	dec    %r14
  7d5243:	add    $0xc,%r15
  7d5247:	cmp    $0x3,%r14
  7d524b:	jb     7d5399 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x3e9>
  7d5251:	mov    -0xc(%r15),%eax
  7d5255:	cmp    (%r15),%eax
  7d5258:	je     7d5240 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x290>
  7d525a:	testb  $0x2,-0x4(%r15)
  7d525f:	je     7d5240 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x290>
  7d5261:	testb  $0x1,0x8(%r15)
  7d5266:	je     7d5240 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x290>
  7d5268:	lea    -0xc(%r15),%rdx
  7d526c:	mov    $0x2,%ecx
  7d5271:	lea    0x70(%rsp),%rdi
  7d5276:	lea    0x40(%rsp),%rsi
  7d527b:	call   7c8ac0 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_>
  7d5280:	mov    0x58(%rsp),%rcx
  7d5285:	mov    0x60(%rsp),%rax
  7d528a:	mov    (%rax),%rdi
  7d528d:	mov    0x28(%rcx),%rsi
  7d5291:	cmp    %rsi,%rdi
  7d5294:	jae    7d542a <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x47a>
  7d529a:	mov    0x70(%rsp),%eax
  7d529e:	mov    0x20(%rcx),%rcx
  7d52a2:	lea    (%rdi,%rdi,2),%rdx
  7d52a6:	cmp    0x4(%rcx,%rdx,8),%eax
  7d52aa:	ja     7d5399 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x3e9>
  7d52b0:	mov    0x90(%rsp),%rcx
  7d52b8:	cmp    0x18(%rsp),%rcx
  7d52bd:	movzbl 0x74(%rsp),%ecx
  7d52c2:	setne  %dl
  7d52c5:	or     0xa0(%rsp),%dl
  7d52cc:	cmp    $0x2,%cl
  7d52cf:	sete   %sil
  7d52d3:	or     %dl,%sil
  7d52d6:	test   $0x1,%sil
  7d52da:	jne    7d5240 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x290>
  7d52e0:	cmp    $0xff,%cl
  7d52e3:	je     7d5240 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x290>
  7d52e9:	mov    0x98(%rsp),%rdx
  7d52f1:	movd   %edx,%xmm0
  7d52f5:	shr    $0x20,%rdx
  7d52f9:	movd   %edx,%xmm1
  7d52fd:	cmpb   $0x0,0x4(%rsp)
  7d5302:	je     7d5327 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x377>
  7d5304:	movaps %xmm0,%xmm3
  7d5307:	maxss  %xmm1,%xmm3
  7d530b:	movaps %xmm3,%xmm2
  7d530e:	cmpunordss %xmm3,%xmm2
  7d5313:	movaps %xmm2,%xmm4
  7d5316:	andnps %xmm3,%xmm4
  7d5319:	andps  %xmm0,%xmm2
  7d531c:	orps   %xmm4,%xmm2
  7d531f:	subss  0xc(%rsp),%xmm2
  7d5325:	jmp    7d534d <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x39d>
  7d5327:	movdqa %xmm0,%xmm2
  7d532b:	minss  %xmm1,%xmm2
  7d532f:	movaps %xmm2,%xmm3
  7d5332:	cmpunordss %xmm2,%xmm3
  7d5337:	movaps %xmm3,%xmm4
  7d533a:	andnps %xmm2,%xmm4
  7d533d:	andps  %xmm0,%xmm3
  7d5340:	orps   %xmm4,%xmm3
  7d5343:	movss  0xc(%rsp),%xmm2
  7d5349:	subss  %xmm3,%xmm2
  7d534d:	xorps  %xmm3,%xmm3
  7d5350:	ucomiss %xmm3,%xmm2
  7d5353:	jbe    7d538a <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x3da>
  7d5355:	movss  0x10(%rsp),%xmm3
  7d535b:	ucomiss %xmm2,%xmm3
  7d535e:	jbe    7d538a <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x3da>
  7d5360:	ucomiss %xmm0,%xmm1
  7d5363:	setbe  %dl
  7d5366:	xor    0x4(%rsp),%dl
  7d536a:	cmovne 0x78(%rsp),%eax
  7d536f:	movzbl 0x7c(%rsp),%edx
  7d5374:	movzbl %cl,%r13d
  7d5378:	cmovne %edx,%r13d
  7d537c:	and    $0x1,%r13b
  7d5380:	movss  %xmm2,0x10(%rsp)
  7d5386:	mov    %eax,0x8(%rsp)
  7d538a:	add    $0xfffffffffffffffe,%r14
  7d538e:	cmpb   $0x0,0x68(%rsp)
  7d5393:	je     7d5226 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x276>
  7d5399:	cmp    $0x2,%r13b
  7d539d:	jne    7d5407 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x457>
  7d539f:	mov    0x18(%rsp),%rsi
  7d53a4:	cmpb   $0x0,0x4(%rsp)
  7d53a9:	je     7d53cf <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x41f>
  7d53ab:	cmp    $0xffffffffffffffff,%rsi
  7d53af:	mov    0x14(%rsp),%r13d
  7d53b4:	je     7d540d <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x45d>
  7d53b6:	inc    %rsi
  7d53b9:	xor    %eax,%eax
  7d53bb:	cmp    %r12,%rsi
  7d53be:	setb   %al
  7d53c1:	test   $0x1,%al
  7d53c3:	je     7d5413 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x463>
  7d53c5:	movss  -0x712e71(%rip),%xmm0        # c255c <GCC_except_table0+0x1bc>
  7d53cd:	jmp    7d53f8 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x448>
  7d53cf:	test   %rsi,%rsi
  7d53d2:	mov    0x14(%rsp),%r13d
  7d53d7:	je     7d53ea <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x43a>
  7d53d9:	dec    %rsi
  7d53dc:	xor    %eax,%eax
  7d53de:	cmp    %r12,%rsi
  7d53e1:	setb   %al
  7d53e4:	test   $0x1,%al
  7d53e6:	jne    7d53f0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x440>
  7d53e8:	jmp    7d5413 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x463>
  7d53ea:	xor    %eax,%eax
  7d53ec:	test   $0x1,%al
  7d53ee:	je     7d5413 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x463>
  7d53f0:	movss  -0x712edc(%rip),%xmm0        # c251c <GCC_except_table0+0x17c>
  7d53f8:	mov    %rbx,%rdi
  7d53fb:	call   7d5510 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line>
  7d5400:	mov    %eax,0x8(%rsp)
  7d5404:	mov    %edx,%r13d
  7d5407:	mov    0x8(%rsp),%ebp
  7d540b:	jmp    7d5413 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x463>
  7d540d:	xor    %eax,%eax
  7d540f:	test   $0x1,%al
  7d5411:	jne    7d53c5 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x415>
  7d5413:	mov    %ebp,%eax
  7d5415:	mov    %r13d,%edx
  7d5418:	add    $0xa8,%rsp
  7d541f:	pop    %rbx
  7d5420:	pop    %r12
  7d5422:	pop    %r13
  7d5424:	pop    %r14
  7d5426:	pop    %r15
  7d5428:	pop    %rbp
  7d5429:	ret
  7d542a:	lea    0x2c75af(%rip),%rdx        # a9c9e0 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0xf08>
  7d5431:	call   *0x2e3b69(%rip)        # ab8fa0 <_DYNAMIC+0x270>
  7d5437:	lea    0x2c7ec2(%rip),%rdx        # a9d300 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0x1828>
  7d543e:	mov    %r12,%rsi
  7d5441:	call   *0x2e3b59(%rip)        # ab8fa0 <_DYNAMIC+0x270>

<gpui_canvas::text::layout::TextGeometry>::next_visual bytes=10 frame=0

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007d5450 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11next_visual>:
  7d5450:	mov    $0x1,%ecx
  7d5455:	jmp    7d4fb0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual>

<gpui_canvas::text::layout::TextGeometry>::position_at bytes=151 frame=8

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007d5460 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11position_at>:
  7d5460:	movd   %xmm1,%eax
  7d5464:	movd   %xmm0,%ecx
  7d5468:	and    $0x7fffffff,%ecx
  7d546e:	cmp    $0x7f800000,%ecx
  7d5474:	setge  %cl
  7d5477:	and    $0x7fffffff,%eax
  7d547c:	cmp    $0x7f800000,%eax
  7d5481:	setge  %al
  7d5484:	or     %cl,%al
  7d5486:	je     7d548b <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11position_at+0x2b>
  7d5488:	mov    $0x2,%dl
  7d548a:	ret
  7d548b:	push   %rax
  7d548c:	mov    0x28(%rdi),%rsi
  7d5490:	test   %rsi,%rsi
  7d5493:	je     7d54ed <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11position_at+0x8d>
  7d5495:	mov    0x20(%rdi),%rax
  7d5499:	xor    %ecx,%ecx
  7d549b:	cmp    $0x1,%rsi
  7d549f:	je     7d54d3 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11position_at+0x73>
  7d54a1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  7d54b0:	mov    %rcx,%rdx
  7d54b3:	mov    %rsi,%r8
  7d54b6:	shr    $1,%r8
  7d54b9:	add    %r8,%rcx
  7d54bc:	lea    (%rcx,%rcx,2),%r9
  7d54c0:	ucomiss 0x8(%rax,%r9,8),%xmm1
  7d54c6:	cmovb  %rdx,%rcx
  7d54ca:	sub    %r8,%rsi
  7d54cd:	cmp    $0x1,%rsi
  7d54d1:	ja     7d54b0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11position_at+0x50>
  7d54d3:	lea    (%rcx,%rcx,2),%rdx
  7d54d7:	xor    %esi,%esi
  7d54d9:	ucomiss 0x8(%rax,%rdx,8),%xmm1
  7d54de:	setae  %sil
  7d54e2:	add    %rcx,%rsi
  7d54e5:	cmp    $0x1,%rsi
  7d54e9:	adc    $0xffffffffffffffff,%rsi
  7d54ed:	call   7d5510 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line>
  7d54f2:	add    $0x8,%rsp
  7d54f6:	ret

<gpui_canvas::text::layout::TextGeometry>::previous_visual bytes=7 frame=0

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007d5500 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry15previous_visual>:
  7d5500:	xor    %ecx,%ecx
  7d5502:	jmp    7d4fb0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual>

<gpui_canvas::text::layout::TextGeometry>::position_on_line bytes=1664 frame=232

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007d5510 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line>:
  7d5510:	push   %rbp
  7d5511:	push   %r15
  7d5513:	push   %r14
  7d5515:	push   %r13
  7d5517:	push   %r12
  7d5519:	push   %rbx
  7d551a:	sub    $0xb8,%rsp
  7d5521:	mov    %rsi,0x18(%rsp)
  7d5526:	mov    0x40(%rdi),%rbx
  7d552a:	test   %rbx,%rbx
  7d552d:	je     7d55f4 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0xe4>
  7d5533:	mov    0x28(%rdi),%r11
  7d5537:	cmp    %r11,%rsi
  7d553a:	jae    7d5b70 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x660>
  7d5540:	mov    0x20(%rdi),%r13
  7d5544:	mov    0x38(%rdi),%rbp
  7d5548:	lea    (%rsi,%rsi,2),%rax
  7d554c:	mov    0x0(%r13,%rax,8),%ecx
  7d5551:	test   %ecx,%ecx
  7d5553:	movss  %xmm0,0x14(%rsp)
  7d5559:	je     7d55fb <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0xeb>
  7d555f:	xor    %eax,%eax
  7d5561:	xor    %edx,%edx
  7d5563:	cmp    $0x1,%rbx
  7d5567:	je     7d5590 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x80>
  7d5569:	mov    %rbx,%rsi
  7d556c:	nopl   0x0(%rax)
  7d5570:	mov    %rsi,%r8
  7d5573:	shr    $1,%r8
  7d5576:	lea    (%r8,%rdx,1),%r9
  7d557a:	lea    (%r9,%r9,2),%r10
  7d557e:	cmp    %ecx,0x0(%rbp,%r10,4)
  7d5583:	cmovb  %r9,%rdx
  7d5587:	sub    %r8,%rsi
  7d558a:	cmp    $0x1,%rsi
  7d558e:	ja     7d5570 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x60>
  7d5590:	lea    (%rdx,%rdx,2),%rsi
  7d5594:	cmp    %ecx,0x0(%rbp,%rsi,4)
  7d5598:	adc    $0x0,%rdx
  7d559c:	lea    (%rdx,%rdx,2),%rcx
  7d55a0:	lea    0x0(%rbp,%rcx,4),%rbp
  7d55a5:	movss  0x4c(%rdi),%xmm0
  7d55aa:	mulss  -0x71311a(%rip),%xmm0        # c2498 <GCC_except_table0+0xf8>
  7d55b2:	sub    %rdx,%rbx
  7d55b5:	jne    7d5608 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0xf8>
  7d55b7:	mov    $0x1,%cl
  7d55b9:	xor    %ebx,%ebx
  7d55bb:	cmp    $0x1,%r11
  7d55bf:	mov    %r11,0x28(%rsp)
  7d55c4:	mov    %ecx,0x24(%rsp)
  7d55c8:	je     7d561c <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x10c>
  7d55ca:	xor    %ecx,%ecx
  7d55cc:	nopl   0x0(%rax)
  7d55d0:	mov    %rcx,%rsi
  7d55d3:	mov    %r11,%r8
  7d55d6:	shr    $1,%r8
  7d55d9:	add    %r8,%rcx
  7d55dc:	lea    (%rcx,%rcx,2),%r9
  7d55e0:	cmp    %eax,0x0(%r13,%r9,8)
  7d55e5:	cmova  %rsi,%rcx
  7d55e9:	sub    %r8,%r11
  7d55ec:	cmp    $0x1,%r11
  7d55f0:	ja     7d55d0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0xc0>
  7d55f2:	jmp    7d561e <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x10e>
  7d55f4:	mov    $0x2,%dl
  7d55f6:	jmp    7d5b0a <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x5fa>
  7d55fb:	movss  0x4c(%rdi),%xmm0
  7d5600:	mulss  -0x713170(%rip),%xmm0        # c2498 <GCC_except_table0+0xf8>
  7d5608:	mov    0x0(%rbp),%eax
  7d560b:	xor    %ecx,%ecx
  7d560d:	cmp    $0x1,%r11
  7d5611:	mov    %r11,0x28(%rsp)
  7d5616:	mov    %ecx,0x24(%rsp)
  7d561a:	jne    7d55ca <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0xba>
  7d561c:	xor    %ecx,%ecx
  7d561e:	lea    (%rcx,%rcx,2),%rdx
  7d5622:	xor    %esi,%esi
  7d5624:	cmp    %eax,0x0(%r13,%rdx,8)
  7d5629:	setbe  %sil
  7d562d:	add    %rcx,%rsi
  7d5630:	cmp    $0x1,%rsi
  7d5634:	adc    $0xffffffffffffffff,%rsi
  7d5638:	lea    0x18(%rsp),%rax
  7d563d:	mov    %rax,0x30(%rsp)
  7d5642:	mov    %rbp,0x38(%rsp)
  7d5647:	mov    %rbx,0x40(%rsp)
  7d564c:	movq   $0x2,0x48(%rsp)
  7d5655:	mov    %rdi,0x50(%rsp)
  7d565a:	mov    %rsi,0x58(%rsp)
  7d565f:	movss  %xmm0,0x60(%rsp)
  7d5665:	mov    %rdi,0x68(%rsp)
  7d566a:	mov    %rax,0x70(%rsp)
  7d566f:	movb   $0x0,0x78(%rsp)
  7d5674:	mov    $0x2,%dl
  7d5676:	mov    $0x2,%al
  7d5678:	mov    %eax,0xc(%rsp)
  7d567c:	mov    %rbx,%r12
  7d567f:	mov    %rbp,%r15
  7d5682:	cmp    $0x2,%r12
  7d5686:	jb     7d5aad <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x59d>
  7d568c:	mov    %dl,0x3(%rsp)
  7d5690:	inc    %r12
  7d5693:	add    $0xc,%r15
  7d5697:	jmp    7d56b1 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x1a1>
  7d5699:	nopl   0x0(%rax)
  7d56a0:	dec    %r12
  7d56a3:	add    $0xc,%r15
  7d56a7:	cmp    $0x3,%r12
  7d56ab:	jb     7d5860 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x350>
  7d56b1:	mov    -0xc(%r15),%eax
  7d56b5:	cmp    (%r15),%eax
  7d56b8:	je     7d56a0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x190>
  7d56ba:	testb  $0x2,-0x4(%r15)
  7d56bf:	je     7d56a0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x190>
  7d56c1:	testb  $0x1,0x8(%r15)
  7d56c6:	je     7d56a0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x190>
  7d56c8:	lea    -0xc(%r15),%rdx
  7d56cc:	mov    $0x2,%ecx
  7d56d1:	lea    0x80(%rsp),%rdi
  7d56d9:	lea    0x50(%rsp),%rsi
  7d56de:	call   7c8ac0 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss1_0Bc_>
  7d56e3:	mov    0x68(%rsp),%rax
  7d56e8:	mov    0x70(%rsp),%rcx
  7d56ed:	mov    (%rcx),%rdi
  7d56f0:	mov    0x28(%rax),%rsi
  7d56f4:	cmp    %rsi,%rdi
  7d56f7:	jae    7d5b63 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x653>
  7d56fd:	mov    0x80(%rsp),%r9d
  7d5705:	mov    0x20(%rax),%rax
  7d5709:	lea    (%rdi,%rdi,2),%rcx
  7d570d:	cmp    0x4(%rax,%rcx,8),%r9d
  7d5712:	ja     7d5860 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x350>
  7d5718:	movzbl 0x84(%rsp),%esi
  7d5720:	mov    0xa0(%rsp),%rax
  7d5728:	cmp    0x18(%rsp),%rax
  7d572d:	setne  %al
  7d5730:	cmp    $0x2,%sil
  7d5734:	sete   %cl
  7d5737:	or     %al,%cl
  7d5739:	cmp    $0x1,%cl
  7d573c:	je     7d56a0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x190>
  7d5742:	cmp    $0xff,%sil
  7d5746:	je     7d56a0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x190>
  7d574c:	movss  0xa8(%rsp),%xmm1
  7d5755:	and    $0x1,%sil
  7d5759:	testb  $0x1,0xb0(%rsp)
  7d5761:	je     7d576d <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x25d>
  7d5763:	mov    %r9d,%eax
  7d5766:	mov    %esi,%ecx
  7d5768:	movaps %xmm1,%xmm0
  7d576b:	jmp    7d57e2 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x2d2>
  7d576d:	mov    0x88(%rsp),%eax
  7d5774:	movzbl 0x8c(%rsp),%ecx
  7d577c:	movss  0xac(%rsp),%xmm0
  7d5785:	and    $0x1,%cl
  7d5788:	movaps %xmm1,%xmm3
  7d578b:	minss  %xmm0,%xmm3
  7d578f:	movaps %xmm3,%xmm2
  7d5792:	cmpunordss %xmm3,%xmm2
  7d5797:	movaps %xmm2,%xmm4
  7d579a:	andnps %xmm3,%xmm4
  7d579d:	andps  %xmm1,%xmm2
  7d57a0:	orps   %xmm4,%xmm2
  7d57a3:	movaps %xmm1,%xmm3
  7d57a6:	maxss  %xmm0,%xmm3
  7d57aa:	ucomiss %xmm1,%xmm0
  7d57ad:	mov    %r9d,%edi
  7d57b0:	cmovbe %eax,%edi
  7d57b3:	movaps %xmm3,%xmm0
  7d57b6:	cmpunordss %xmm3,%xmm0
  7d57bb:	movzbl %sil,%r8d
  7d57bf:	movzbl %cl,%ecx
  7d57c2:	mov    %r8d,%esi
  7d57c5:	cmovbe %ecx,%esi
  7d57c8:	movaps %xmm0,%xmm4
  7d57cb:	cmovbe %r9d,%eax
  7d57cf:	andnps %xmm3,%xmm4
  7d57d2:	cmovbe %r8d,%ecx
  7d57d6:	andps  %xmm1,%xmm0
  7d57d9:	orps   %xmm4,%xmm0
  7d57dc:	movaps %xmm2,%xmm1
  7d57df:	mov    %edi,%r9d
  7d57e2:	movss  0x14(%rsp),%xmm2
  7d57e8:	ucomiss %xmm2,%xmm1
  7d57eb:	jbe    7d581d <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x30d>
  7d57ed:	cmpb   $0x2,0xc(%rsp)
  7d57f2:	je     7d57ff <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x2ef>
  7d57f4:	movss  0x10(%rsp),%xmm0
  7d57fa:	ucomiss %xmm1,%xmm0
  7d57fd:	jbe    7d580c <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x2fc>
  7d57ff:	movss  %xmm1,0x10(%rsp)
  7d5805:	mov    %r9d,%r14d
  7d5808:	mov    %esi,0xc(%rsp)
  7d580c:	movss  0x4(%rsp),%xmm0
  7d5812:	mov    0x8(%rsp),%eax
  7d5816:	movzbl 0x3(%rsp),%ecx
  7d581b:	jmp    7d5843 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x333>
  7d581d:	ucomiss %xmm0,%xmm2
  7d5820:	jbe    7d5b2e <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x61e>
  7d5826:	movzbl 0x3(%rsp),%edx
  7d582b:	cmp    $0x2,%dl
  7d582e:	je     7d5843 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x333>
  7d5830:	ucomiss 0x4(%rsp),%xmm0
  7d5835:	ja     7d5843 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x333>
  7d5837:	movss  0x4(%rsp),%xmm0
  7d583d:	mov    0x8(%rsp),%eax
  7d5841:	mov    %edx,%ecx
  7d5843:	add    $0xfffffffffffffffe,%r12
  7d5847:	cmpb   $0x0,0x78(%rsp)
  7d584c:	mov    %ecx,%edx
  7d584e:	mov    %eax,0x8(%rsp)
  7d5852:	movss  %xmm0,0x4(%rsp)
  7d5858:	je     7d5682 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x172>
  7d585e:	jmp    7d586f <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x35f>
  7d5860:	movss  0x4(%rsp),%xmm0
  7d5866:	mov    0x8(%rsp),%eax
  7d586a:	movzbl 0x3(%rsp),%ecx
  7d586f:	cmp    $0x2,%cl
  7d5872:	jne    7d5ac2 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x5b2>
  7d5878:	mov    0xc(%rsp),%edx
  7d587c:	cmp    $0x2,%dl
  7d587f:	jne    7d5b07 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x5f7>
  7d5885:	mov    $0x2,%dl
  7d5887:	cmpb   $0x0,0x24(%rsp)
  7d588c:	je     7d5893 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x383>
  7d588e:	jmp    7d5b0a <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x5fa>
  7d5893:	mov    0x18(%rsp),%rdi
  7d5898:	mov    0x28(%rsp),%rsi
  7d589d:	cmp    %rsi,%rdi
  7d58a0:	jae    7d5b83 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x673>
  7d58a6:	lea    (%rbx,%rbx,2),%rax
  7d58aa:	lea    0x0(,%rax,4),%rax
  7d58b2:	add    %rbp,%rax
  7d58b5:	lea    (%rdi,%rdi,2),%rcx
  7d58b9:	mov    0x4(%r13,%rcx,8),%ecx
  7d58be:	lea    -0x1(%rsi),%r12
  7d58c2:	jmp    7d58ec <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x3dc>
  7d58c4:	xor    %ebx,%ebx
  7d58c6:	lea    (%rbx,%rbx,2),%r8
  7d58ca:	cmp    %r14d,0x4(%r13,%r8,8)
  7d58cf:	adc    $0x0,%rbx
  7d58d3:	cmp    %rbx,%r12
  7d58d6:	cmovb  %r12,%rbx
  7d58da:	cmp    %rdi,%rbx
  7d58dd:	je     7d5b23 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x613>
  7d58e3:	add    $0xc,%rbp
  7d58e7:	cmp    %rax,%rbp
  7d58ea:	je     7d588e <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x37e>
  7d58ec:	mov    0x0(%rbp),%r14d
  7d58f0:	cmp    %ecx,%r14d
  7d58f3:	ja     7d5b0a <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x5fa>
  7d58f9:	movzbl 0x8(%rbp),%r15d
  7d58fe:	test   %r14d,%r14d
  7d5901:	je     7d5920 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x410>
  7d5903:	test   $0x2,%r15b
  7d5907:	je     7d5996 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x486>
  7d590d:	mov    %rsi,%r9
  7d5910:	test   %rsi,%rsi
  7d5913:	je     7d598d <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x47d>
  7d5915:	cmp    $0x1,%rsi
  7d5919:	jne    7d5948 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x438>
  7d591b:	xor    %r8d,%r8d
  7d591e:	jmp    7d5972 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x462>
  7d5920:	test   $0x2,%r15b
  7d5924:	je     7d5a36 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x526>
  7d592a:	mov    %rsi,%r9
  7d592d:	test   %rsi,%rsi
  7d5930:	je     7d5a2d <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x51d>
  7d5936:	cmp    $0x1,%rsi
  7d593a:	jne    7d59e5 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x4d5>
  7d5940:	xor    %r8d,%r8d
  7d5943:	jmp    7d5a11 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x501>
  7d5948:	mov    %rsi,%r9
  7d594b:	xor    %r8d,%r8d
  7d594e:	xchg   %ax,%ax
  7d5950:	mov    %r8,%r10
  7d5953:	mov    %r9,%r11
  7d5956:	shr    $1,%r11
  7d5959:	add    %r11,%r8
  7d595c:	lea    (%r8,%r8,2),%rbx
  7d5960:	cmp    %r14d,0x0(%r13,%rbx,8)
  7d5965:	cmova  %r10,%r8
  7d5969:	sub    %r11,%r9
  7d596c:	cmp    $0x1,%r9
  7d5970:	ja     7d5950 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x440>
  7d5972:	lea    (%r8,%r8,2),%r10
  7d5976:	xor    %r9d,%r9d
  7d5979:	cmp    %r14d,0x0(%r13,%r10,8)
  7d597e:	setbe  %r9b
  7d5982:	add    %r8,%r9
  7d5985:	cmp    $0x1,%r9
  7d5989:	adc    $0xffffffffffffffff,%r9
  7d598d:	cmp    %rdi,%r9
  7d5990:	je     7d5b1f <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x60f>
  7d5996:	test   $0x1,%r15b
  7d599a:	je     7d58e3 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x3d3>
  7d59a0:	mov    %rsi,%rbx
  7d59a3:	test   %rsi,%rsi
  7d59a6:	je     7d58da <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x3ca>
  7d59ac:	cmp    $0x1,%rsi
  7d59b0:	je     7d58c4 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x3b4>
  7d59b6:	mov    %rsi,%r8
  7d59b9:	xor    %ebx,%ebx
  7d59bb:	nopl   0x0(%rax,%rax,1)
  7d59c0:	mov    %r8,%r9
  7d59c3:	shr    $1,%r9
  7d59c6:	lea    (%r9,%rbx,1),%r10
  7d59ca:	lea    (%r10,%r10,2),%r11
  7d59ce:	cmp    %r14d,0x4(%r13,%r11,8)
  7d59d3:	cmovb  %r10,%rbx
  7d59d7:	sub    %r9,%r8
  7d59da:	cmp    $0x1,%r8
  7d59de:	ja     7d59c0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x4b0>
  7d59e0:	jmp    7d58c6 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x3b6>
  7d59e5:	mov    %rsi,%r9
  7d59e8:	xor    %r8d,%r8d
  7d59eb:	nopl   0x0(%rax,%rax,1)
  7d59f0:	mov    %r9,%r10
  7d59f3:	shr    $1,%r10
  7d59f6:	lea    (%r10,%r8,1),%r11
  7d59fa:	lea    (%r11,%r11,2),%rbx
  7d59fe:	cmpl   $0x0,0x0(%r13,%rbx,8)
  7d5a04:	cmove  %r11,%r8
  7d5a08:	sub    %r10,%r9
  7d5a0b:	cmp    $0x1,%r9
  7d5a0f:	ja     7d59f0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x4e0>
  7d5a11:	lea    (%r8,%r8,2),%r10
  7d5a15:	xor    %r9d,%r9d
  7d5a18:	cmpl   $0x0,0x0(%r13,%r10,8)
  7d5a1e:	sete   %r9b
  7d5a22:	add    %r8,%r9
  7d5a25:	cmp    $0x1,%r9
  7d5a29:	adc    $0xffffffffffffffff,%r9
  7d5a2d:	cmp    %rdi,%r9
  7d5a30:	je     7d5b27 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x617>
  7d5a36:	test   $0x1,%r15b
  7d5a3a:	je     7d58e3 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x3d3>
  7d5a40:	mov    %rsi,%r8
  7d5a43:	test   %rsi,%rsi
  7d5a46:	je     7d5a9d <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x58d>
  7d5a48:	cmp    $0x1,%rsi
  7d5a4c:	jne    7d5a52 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x542>
  7d5a4e:	xor    %ebx,%ebx
  7d5a50:	jmp    7d5a81 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x571>
  7d5a52:	mov    %rsi,%r8
  7d5a55:	xor    %ebx,%ebx
  7d5a57:	nopw   0x0(%rax,%rax,1)
  7d5a60:	mov    %r8,%r9
  7d5a63:	shr    $1,%r9
  7d5a66:	lea    (%r9,%rbx,1),%r10
  7d5a6a:	lea    (%r10,%r10,2),%r11
  7d5a6e:	cmpl   $0x0,0x0(%r13,%r11,8)
  7d5a74:	cmove  %r10,%rbx
  7d5a78:	sub    %r9,%r8
  7d5a7b:	cmp    $0x1,%r8
  7d5a7f:	ja     7d5a60 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x550>
  7d5a81:	lea    (%rbx,%rbx,2),%r9
  7d5a85:	xor    %r8d,%r8d
  7d5a88:	cmpl   $0x0,0x0(%r13,%r9,8)
  7d5a8e:	sete   %r8b
  7d5a92:	add    %rbx,%r8
  7d5a95:	cmp    $0x1,%r8
  7d5a99:	adc    $0xffffffffffffffff,%r8
  7d5a9d:	cmp    %rdi,%r8
  7d5aa0:	jne    7d58e3 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x3d3>
  7d5aa6:	xor    %edx,%edx
  7d5aa8:	xor    %r14d,%r14d
  7d5aab:	jmp    7d5b0a <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x5fa>
  7d5aad:	movss  0x4(%rsp),%xmm0
  7d5ab3:	mov    0x8(%rsp),%eax
  7d5ab7:	mov    %edx,%ecx
  7d5ab9:	cmp    $0x2,%cl
  7d5abc:	je     7d5878 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x368>
  7d5ac2:	mov    0xc(%rsp),%edx
  7d5ac6:	cmp    $0x2,%dl
  7d5ac9:	jne    7d5ad2 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x5c2>
  7d5acb:	mov    %eax,%r14d
  7d5ace:	mov    %ecx,%edx
  7d5ad0:	jmp    7d5b07 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x5f7>
  7d5ad2:	cvtss2sd %xmm0,%xmm0
  7d5ad6:	movss  0x10(%rsp),%xmm1
  7d5adc:	cvtss2sd %xmm1,%xmm1
  7d5ae0:	addsd  %xmm0,%xmm1
  7d5ae4:	mulsd  -0x711d9c(%rip),%xmm1        # c3d50 <GCC_except_table0+0x19b0>
  7d5aec:	movss  0x14(%rsp),%xmm0
  7d5af2:	cvtss2sd %xmm0,%xmm0
  7d5af6:	ucomisd %xmm1,%xmm0
  7d5afa:	cmovbe %eax,%r14d
  7d5afe:	movzbl %dl,%eax
  7d5b01:	movzbl %cl,%edx
  7d5b04:	cmova  %eax,%edx
  7d5b07:	and    $0x1,%dl
  7d5b0a:	mov    %r14d,%eax
  7d5b0d:	add    $0xb8,%rsp
  7d5b14:	pop    %rbx
  7d5b15:	pop    %r12
  7d5b17:	pop    %r13
  7d5b19:	pop    %r14
  7d5b1b:	pop    %r15
  7d5b1d:	pop    %rbp
  7d5b1e:	ret
  7d5b1f:	mov    $0x1,%dl
  7d5b21:	jmp    7d5b0a <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x5fa>
  7d5b23:	xor    %edx,%edx
  7d5b25:	jmp    7d5b0a <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x5fa>
  7d5b27:	xor    %r14d,%r14d
  7d5b2a:	mov    $0x1,%dl
  7d5b2c:	jmp    7d5b0a <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x5fa>
  7d5b2e:	cvtss2sd %xmm1,%xmm1
  7d5b32:	cvtss2sd %xmm0,%xmm0
  7d5b36:	addsd  %xmm1,%xmm0
  7d5b3a:	mulsd  -0x711df2(%rip),%xmm0        # c3d50 <GCC_except_table0+0x19b0>
  7d5b42:	movss  0x14(%rsp),%xmm1
  7d5b48:	cvtss2sd %xmm1,%xmm1
  7d5b4c:	ucomisd %xmm0,%xmm1
  7d5b50:	cmova  %eax,%r9d
  7d5b54:	movzbl %cl,%eax
  7d5b57:	movzbl %sil,%edx
  7d5b5b:	cmova  %eax,%edx
  7d5b5e:	mov    %r9d,%r14d
  7d5b61:	jmp    7d5b0a <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x5fa>
  7d5b63:	lea    0x2c6e8e(%rip),%rdx        # a9c9f8 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0xf20>
  7d5b6a:	call   *0x2e3430(%rip)        # ab8fa0 <_DYNAMIC+0x270>
  7d5b70:	lea    0x2c7789(%rip),%rdx        # a9d300 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0x1828>
  7d5b77:	mov    %rsi,%rdi
  7d5b7a:	mov    %r11,%rsi
  7d5b7d:	call   *0x2e341d(%rip)        # ab8fa0 <_DYNAMIC+0x270>
  7d5b83:	lea    0x2c6dae(%rip),%rdx        # a9c938 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0xe60>
  7d5b8a:	call   *0x2e3410(%rip)        # ab8fa0 <_DYNAMIC+0x270>

<gpui_canvas::text::layout::TextGeometry>::graphemes bytes=178 frame=16

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007d5b90 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry9graphemes>:
  7d5b90:	mov    %rdi,%rax
  7d5b93:	mov    0x38(%rsi),%rcx
  7d5b97:	mov    0x40(%rsi),%rdx
  7d5b9b:	test   %rdx,%rdx
  7d5b9e:	je     7d5bb3 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry9graphemes+0x23>
  7d5ba0:	mov    (%rcx),%r8d
  7d5ba3:	movss  0x4c(%rsi),%xmm0
  7d5ba8:	mov    0x28(%rsi),%rdi
  7d5bac:	test   %rdi,%rdi
  7d5baf:	jne    7d5bc4 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry9graphemes+0x34>
  7d5bb1:	jmp    7d5c1d <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry9graphemes+0x8d>
  7d5bb3:	xor    %r8d,%r8d
  7d5bb6:	movss  0x4c(%rsi),%xmm0
  7d5bbb:	mov    0x28(%rsi),%rdi
  7d5bbf:	test   %rdi,%rdi
  7d5bc2:	je     7d5c1d <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry9graphemes+0x8d>
  7d5bc4:	push   %r14
  7d5bc6:	push   %rbx
  7d5bc7:	mov    0x20(%rsi),%r9
  7d5bcb:	xor    %r10d,%r10d
  7d5bce:	cmp    $0x1,%rdi
  7d5bd2:	je     7d5c01 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry9graphemes+0x71>
  7d5bd4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  7d5be0:	mov    %r10,%r11
  7d5be3:	mov    %rdi,%rbx
  7d5be6:	shr    $1,%rbx
  7d5be9:	add    %rbx,%r10
  7d5bec:	lea    (%r10,%r10,2),%r14
  7d5bf0:	cmp    %r8d,(%r9,%r14,8)
  7d5bf4:	cmova  %r11,%r10
  7d5bf8:	sub    %rbx,%rdi
  7d5bfb:	cmp    $0x1,%rdi
  7d5bff:	ja     7d5be0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry9graphemes+0x50>
  7d5c01:	lea    (%r10,%r10,2),%r11
  7d5c05:	xor    %edi,%edi
  7d5c07:	cmp    %r8d,(%r9,%r11,8)
  7d5c0b:	setbe  %dil
  7d5c0f:	add    %r10,%rdi
  7d5c12:	cmp    $0x1,%rdi
  7d5c16:	adc    $0xffffffffffffffff,%rdi
  7d5c1a:	pop    %rbx
  7d5c1b:	pop    %r14
  7d5c1d:	mulss  -0x71378d(%rip),%xmm0        # c2498 <GCC_except_table0+0xf8>
  7d5c25:	mov    %rcx,(%rax)
  7d5c28:	mov    %rdx,0x8(%rax)
  7d5c2c:	movq   $0x2,0x10(%rax)
  7d5c34:	mov    %rsi,0x18(%rax)
  7d5c38:	mov    %rdi,0x20(%rax)
  7d5c3c:	movss  %xmm0,0x28(%rax)
  7d5c41:	ret

<alloc::raw_vec::RawVec<gpui_canvas::text::layout::Run>>::grow_one bytes=100 frame=40

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007d80c0 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout3RunE8grow_oneBR_>:
  7d80c0:	push   %r14
  7d80c2:	push   %rbx
  7d80c3:	sub    $0x18,%rsp
  7d80c7:	mov    %rdi,%rbx
  7d80ca:	mov    (%rdi),%rsi
  7d80cd:	lea    (%rsi,%rsi,1),%rax
  7d80d1:	cmp    $0x5,%rax
  7d80d5:	mov    $0x4,%r14d
  7d80db:	cmovae %rax,%r14
  7d80df:	mov    0x8(%rdi),%rdx
  7d80e3:	mov    %rsp,%rdi
  7d80e6:	mov    $0x4,%r8d
  7d80ec:	mov    $0x18,%r9d
  7d80f2:	mov    %r14,%rcx
  7d80f5:	call   7d87d0 <_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsghYClfd3M9V_11gpui_canvas>
  7d80fa:	cmpl   $0x1,(%rsp)
  7d80fe:	je     7d8114 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout3RunE8grow_oneBR_+0x54>
  7d8100:	mov    0x8(%rsp),%rax
  7d8105:	mov    %rax,0x8(%rbx)
  7d8109:	mov    %r14,(%rbx)
  7d810c:	add    $0x18,%rsp
  7d8110:	pop    %rbx
  7d8111:	pop    %r14
  7d8113:	ret
  7d8114:	mov    0x8(%rsp),%rdi
  7d8119:	mov    0x10(%rsp),%rsi
  7d811e:	call   *0x2e0f04(%rip)        # ab9028 <_DYNAMIC+0x2f8>

<alloc::raw_vec::RawVec<gpui_canvas::text::layout::Stop>>::grow_one bytes=100 frame=40

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007d8130 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopE8grow_oneBR_>:
  7d8130:	push   %r14
  7d8132:	push   %rbx
  7d8133:	sub    $0x18,%rsp
  7d8137:	mov    %rdi,%rbx
  7d813a:	mov    (%rdi),%rsi
  7d813d:	lea    (%rsi,%rsi,1),%rax
  7d8141:	cmp    $0x5,%rax
  7d8145:	mov    $0x4,%r14d
  7d814b:	cmovae %rax,%r14
  7d814f:	mov    0x8(%rdi),%rdx
  7d8153:	mov    %rsp,%rdi
  7d8156:	mov    $0x4,%r8d
  7d815c:	mov    $0xc,%r9d
  7d8162:	mov    %r14,%rcx
  7d8165:	call   7d87d0 <_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsghYClfd3M9V_11gpui_canvas>
  7d816a:	cmpl   $0x1,(%rsp)
  7d816e:	je     7d8184 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopE8grow_oneBR_+0x54>
  7d8170:	mov    0x8(%rsp),%rax
  7d8175:	mov    %rax,0x8(%rbx)
  7d8179:	mov    %r14,(%rbx)
  7d817c:	add    $0x18,%rsp
  7d8180:	pop    %rbx
  7d8181:	pop    %r14
  7d8183:	ret
  7d8184:	mov    0x8(%rsp),%rdi
  7d8189:	mov    0x10(%rsp),%rsi
  7d818e:	call   *0x2e0e94(%rip)        # ab9028 <_DYNAMIC+0x2f8>

<gpui_canvas::text::layout::TextGeometry>::caret_bounds bytes=429 frame=24

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007d8500 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds>:
  7d8500:	push   %r14
  7d8502:	push   %rbx
  7d8503:	push   %rax
  7d8504:	mov    0x38(%rsi),%r8
  7d8508:	mov    0x40(%rsi),%rax
  7d850c:	mov    %rax,%r9
  7d850f:	test   %rax,%rax
  7d8512:	je     7d854b <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x4b>
  7d8514:	xor    %r9d,%r9d
  7d8517:	cmp    $0x1,%rax
  7d851b:	je     7d853f <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x3f>
  7d851d:	mov    %rax,%r10
  7d8520:	mov    %r10,%r11
  7d8523:	shr    $1,%r11
  7d8526:	lea    (%r11,%r9,1),%rbx
  7d852a:	lea    (%rbx,%rbx,2),%r14
  7d852e:	cmp    %edx,(%r8,%r14,4)
  7d8532:	cmovb  %rbx,%r9
  7d8536:	sub    %r11,%r10
  7d8539:	cmp    $0x1,%r10
  7d853d:	ja     7d8520 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x20>
  7d853f:	lea    (%r9,%r9,2),%r10
  7d8543:	cmp    %edx,(%r8,%r10,4)
  7d8547:	adc    $0x0,%r9
  7d854b:	inc    %cl
  7d854d:	shl    $0x2,%r9
  7d8551:	lea    (%r9,%r9,2),%r9
  7d8555:	lea    (%r8,%r9,1),%r10
  7d8559:	shl    $0x2,%rax
  7d855d:	lea    (%rax,%rax,2),%rax
  7d8561:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  7d8570:	xor    %r11d,%r11d
  7d8573:	cmp    %r9,%rax
  7d8576:	je     7d868f <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x18f>
  7d857c:	cmp    %edx,(%r10)
  7d857f:	jne    7d868f <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x18f>
  7d8585:	movzbl 0x8(%r10),%r11d
  7d858a:	add    $0xc,%r10
  7d858e:	add    $0xc,%r9
  7d8592:	test   %cl,%r11b
  7d8595:	je     7d8570 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x70>
  7d8597:	mov    0x20(%rsi),%rcx
  7d859b:	mov    0x28(%rsi),%rsi
  7d859f:	test   $0x1,%r11b
  7d85a3:	je     7d85fa <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0xfa>
  7d85a5:	test   %edx,%edx
  7d85a7:	je     7d85fa <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0xfa>
  7d85a9:	mov    %rsi,%rax
  7d85ac:	test   %rsi,%rsi
  7d85af:	je     7d85ed <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0xed>
  7d85b1:	xor    %eax,%eax
  7d85b3:	cmp    $0x1,%rsi
  7d85b7:	je     7d85e0 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0xe0>
  7d85b9:	mov    %rsi,%r10
  7d85bc:	nopl   0x0(%rax)
  7d85c0:	mov    %r10,%r11
  7d85c3:	shr    $1,%r11
  7d85c6:	lea    (%r11,%rax,1),%rbx
  7d85ca:	lea    (%rbx,%rbx,2),%r14
  7d85ce:	cmp    %edx,0x4(%rcx,%r14,8)
  7d85d3:	cmovb  %rbx,%rax
  7d85d7:	sub    %r11,%r10
  7d85da:	cmp    $0x1,%r10
  7d85de:	ja     7d85c0 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0xc0>
  7d85e0:	lea    (%rax,%rax,2),%r10
  7d85e4:	cmp    %edx,0x4(%rcx,%r10,8)
  7d85e9:	adc    $0x0,%rax
  7d85ed:	lea    -0x1(%rsi),%rdx
  7d85f1:	cmp    %rax,%rdx
  7d85f4:	cmovb  %rdx,%rax
  7d85f8:	jmp    7d8649 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x149>
  7d85fa:	mov    %rsi,%rax
  7d85fd:	test   %rsi,%rsi
  7d8600:	je     7d8649 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x149>
  7d8602:	xor    %r10d,%r10d
  7d8605:	cmp    $0x1,%rsi
  7d8609:	je     7d8631 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x131>
  7d860b:	mov    %rsi,%rax
  7d860e:	xchg   %ax,%ax
  7d8610:	mov    %r10,%r11
  7d8613:	mov    %rax,%rbx
  7d8616:	shr    $1,%rbx
  7d8619:	add    %rbx,%r10
  7d861c:	lea    (%r10,%r10,2),%r14
  7d8620:	cmp    %edx,(%rcx,%r14,8)
  7d8624:	cmova  %r11,%r10
  7d8628:	sub    %rbx,%rax
  7d862b:	cmp    $0x1,%rax
  7d862f:	ja     7d8610 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x110>
  7d8631:	lea    (%r10,%r10,2),%r11
  7d8635:	xor    %eax,%eax
  7d8637:	cmp    %edx,(%rcx,%r11,8)
  7d863b:	setbe  %al
  7d863e:	add    %r10,%rax
  7d8641:	cmp    $0x1,%rax
  7d8645:	adc    $0xffffffffffffffff,%rax
  7d8649:	cmp    %rsi,%rax
  7d864c:	jae    7d869d <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x19d>
  7d864e:	lea    (%rax,%rax,2),%rax
  7d8652:	movss  -0x8(%r8,%r9,1),%xmm0
  7d8659:	movss  -0x716259(%rip),%xmm1        # c2408 <GCC_except_table0+0x68>
  7d8661:	addss  %xmm0,%xmm1
  7d8665:	subss  %xmm0,%xmm1
  7d8669:	movss  0x8(%rcx,%rax,8),%xmm2
  7d866f:	movss  0xc(%rcx,%rax,8),%xmm3
  7d8675:	movss  %xmm0,0x4(%rdi)
  7d867a:	movss  %xmm2,0x8(%rdi)
  7d867f:	movss  %xmm1,0xc(%rdi)
  7d8684:	movss  %xmm3,0x10(%rdi)
  7d8689:	mov    $0x1,%r11d
  7d868f:	mov    %r11d,(%rdi)
  7d8692:	mov    %rdi,%rax
  7d8695:	add    $0x8,%rsp
  7d8699:	pop    %rbx
  7d869a:	pop    %r14
  7d869c:	ret
  7d869d:	lea    0x2c48b4(%rip),%rdx        # a9cf58 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0x1480>
  7d86a4:	mov    %rax,%rdi
  7d86a7:	call   *0x2e08f3(%rip)        # ab8fa0 <_DYNAMIC+0x270>

<gpui_canvas::text::layout::TextGeometry>::validates_selection bytes=287 frame=8

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007d86b0 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection>:
  7d86b0:	push   %rbx
  7d86b1:	mov    (%rsi),%r8d
  7d86b4:	movzbl 0x4(%rsi),%r9d
  7d86b9:	mov    0x38(%rdi),%rax
  7d86bd:	mov    0x40(%rdi),%rcx
  7d86c1:	mov    %rcx,%rdx
  7d86c4:	test   %rcx,%rcx
  7d86c7:	je     7d870b <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0x5b>
  7d86c9:	xor    %edx,%edx
  7d86cb:	cmp    $0x1,%rcx
  7d86cf:	je     7d86ff <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0x4f>
  7d86d1:	mov    %rcx,%rdi
  7d86d4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  7d86e0:	mov    %rdi,%r10
  7d86e3:	shr    $1,%r10
  7d86e6:	lea    (%r10,%rdx,1),%r11
  7d86ea:	lea    (%r11,%r11,2),%rbx
  7d86ee:	cmp    %r8d,(%rax,%rbx,4)
  7d86f2:	cmovb  %r11,%rdx
  7d86f6:	sub    %r10,%rdi
  7d86f9:	cmp    $0x1,%rdi
  7d86fd:	ja     7d86e0 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0x30>
  7d86ff:	lea    (%rdx,%rdx,2),%rdi
  7d8703:	cmp    %r8d,(%rax,%rdi,4)
  7d8707:	adc    $0x0,%rdx
  7d870b:	inc    %r9b
  7d870e:	shl    $0x2,%rdx
  7d8712:	lea    (%rdx,%rdx,2),%r11
  7d8716:	lea    (%rax,%r11,1),%rdi
  7d871a:	lea    0x0(,%rcx,4),%rdx
  7d8722:	lea    (%rdx,%rdx,2),%rdx
  7d8726:	mov    %rdx,%r10
  7d8729:	sub    %r11,%r10
  7d872c:	nopl   0x0(%rax)
  7d8730:	test   %r10,%r10
  7d8733:	je     7d87cb <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0x11b>
  7d8739:	cmp    %r8d,(%rdi)
  7d873c:	jne    7d87cb <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0x11b>
  7d8742:	add    $0xfffffffffffffff4,%r10
  7d8746:	test   %r9b,0x8(%rdi)
  7d874a:	lea    0xc(%rdi),%rdi
  7d874e:	je     7d8730 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0x80>
  7d8750:	mov    0x8(%rsi),%edi
  7d8753:	movzbl 0xc(%rsi),%esi
  7d8757:	test   %rcx,%rcx
  7d875a:	je     7d879d <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0xed>
  7d875c:	xor    %r8d,%r8d
  7d875f:	cmp    $0x1,%rcx
  7d8763:	je     7d878f <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0xdf>
  7d8765:	data16 cs nopw 0x0(%rax,%rax,1)
  7d8770:	mov    %rcx,%r9
  7d8773:	shr    $1,%r9
  7d8776:	lea    (%r9,%r8,1),%r10
  7d877a:	lea    (%r10,%r10,2),%r11
  7d877e:	cmp    %edi,(%rax,%r11,4)
  7d8782:	cmovb  %r10,%r8
  7d8786:	sub    %r9,%rcx
  7d8789:	cmp    $0x1,%rcx
  7d878d:	ja     7d8770 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0xc0>
  7d878f:	lea    (%r8,%r8,2),%rcx
  7d8793:	cmp    %edi,(%rax,%rcx,4)
  7d8796:	adc    $0x0,%r8
  7d879a:	mov    %r8,%rcx
  7d879d:	inc    %sil
  7d87a0:	shl    $0x2,%rcx
  7d87a4:	lea    (%rcx,%rcx,2),%rcx
  7d87a8:	add    %rcx,%rax
  7d87ab:	sub    %rcx,%rdx
  7d87ae:	xchg   %ax,%ax
  7d87b0:	test   %rdx,%rdx
  7d87b3:	je     7d87cb <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0x11b>
  7d87b5:	cmp    %edi,(%rax)
  7d87b7:	jne    7d87cb <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0x11b>
  7d87b9:	add    $0xfffffffffffffff4,%rdx
  7d87bd:	test   %sil,0x8(%rax)
  7d87c1:	lea    0xc(%rax),%rax
  7d87c5:	je     7d87b0 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0x100>
  7d87c7:	mov    $0x1,%al
  7d87c9:	pop    %rbx
  7d87ca:	ret
  7d87cb:	xor    %eax,%eax
  7d87cd:	pop    %rbx
  7d87ce:	ret

<gpui_canvas::text::layout::TextGeometry>::source_line bytes=183 frame=0

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007dbfd0 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry11source_line>:
  7dbfd0:	not    %dl
  7dbfd2:	test   %esi,%esi
  7dbfd4:	setne  %r8b
  7dbfd8:	mov    0x20(%rdi),%rcx
  7dbfdc:	mov    0x28(%rdi),%rax
  7dbfe0:	test   %r8b,%dl
  7dbfe3:	jne    7dc039 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry11source_line+0x69>
  7dbfe5:	test   %rax,%rax
  7dbfe8:	je     7dc086 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry11source_line+0xb6>
  7dbfee:	xor    %edx,%edx
  7dbff0:	cmp    $0x1,%rax
  7dbff4:	je     7dc021 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry11source_line+0x51>
  7dbff6:	cs nopw 0x0(%rax,%rax,1)
  7dc000:	mov    %rdx,%rdi
  7dc003:	mov    %rax,%r8
  7dc006:	shr    $1,%r8
  7dc009:	add    %r8,%rdx
  7dc00c:	lea    (%rdx,%rdx,2),%r9
  7dc010:	cmp    %esi,(%rcx,%r9,8)
  7dc014:	cmova  %rdi,%rdx
  7dc018:	sub    %r8,%rax
  7dc01b:	cmp    $0x1,%rax
  7dc01f:	ja     7dc000 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry11source_line+0x30>
  7dc021:	lea    (%rdx,%rdx,2),%rdi
  7dc025:	xor    %eax,%eax
  7dc027:	cmp    %esi,(%rcx,%rdi,8)
  7dc02a:	setbe  %al
  7dc02d:	add    %rdx,%rax
  7dc030:	cmp    $0x1,%rax
  7dc034:	adc    $0xffffffffffffffff,%rax
  7dc038:	ret
  7dc039:	mov    %rax,%rdx
  7dc03c:	test   %rax,%rax
  7dc03f:	je     7dc07c <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry11source_line+0xac>
  7dc041:	xor    %edx,%edx
  7dc043:	cmp    $0x1,%rax
  7dc047:	je     7dc070 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry11source_line+0xa0>
  7dc049:	mov    %rax,%rdi
  7dc04c:	nopl   0x0(%rax)
  7dc050:	mov    %rdi,%r8
  7dc053:	shr    $1,%r8
  7dc056:	lea    (%r8,%rdx,1),%r9
  7dc05a:	lea    (%r9,%r9,2),%r10
  7dc05e:	cmp    %esi,0x4(%rcx,%r10,8)
  7dc063:	cmovb  %r9,%rdx
  7dc067:	sub    %r8,%rdi
  7dc06a:	cmp    $0x1,%rdi
  7dc06e:	ja     7dc050 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry11source_line+0x80>
  7dc070:	lea    (%rdx,%rdx,2),%rdi
  7dc074:	cmp    %esi,0x4(%rcx,%rdi,8)
  7dc078:	adc    $0x0,%rdx
  7dc07c:	dec    %rax
  7dc07f:	cmp    %rdx,%rax
  7dc082:	cmovae %rdx,%rax
  7dc086:	ret

<gpui_canvas::text::layout::TextGeometry>::stops bytes=190 frame=0

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007dc090 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry5stops>:
  7dc090:	mov    0x40(%rdi),%rcx
  7dc094:	xor    %eax,%eax
  7dc096:	test   %rcx,%rcx
  7dc099:	je     7dc14a <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry5stops+0xba>
  7dc09f:	mov    0x38(%rdi),%rdi
  7dc0a3:	cmp    $0x1,%rcx
  7dc0a7:	je     7dc0cf <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry5stops+0x3f>
  7dc0a9:	xor    %eax,%eax
  7dc0ab:	mov    %rcx,%r8
  7dc0ae:	xchg   %ax,%ax
  7dc0b0:	mov    %r8,%r9
  7dc0b3:	shr    $1,%r9
  7dc0b6:	lea    (%r9,%rax,1),%r10
  7dc0ba:	lea    (%r10,%r10,2),%r11
  7dc0be:	cmp    %esi,(%rdi,%r11,4)
  7dc0c2:	cmovb  %r10,%rax
  7dc0c6:	sub    %r9,%r8
  7dc0c9:	cmp    $0x1,%r8
  7dc0cd:	ja     7dc0b0 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry5stops+0x20>
  7dc0cf:	lea    (%rax,%rax,2),%r8
  7dc0d3:	cmp    %esi,(%rdi,%r8,4)
  7dc0d7:	adc    $0x0,%rax
  7dc0db:	xor    %r8d,%r8d
  7dc0de:	cmp    $0x1,%rcx
  7dc0e2:	je     7dc111 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry5stops+0x81>
  7dc0e4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  7dc0f0:	mov    %r8,%r9
  7dc0f3:	mov    %rcx,%r10
  7dc0f6:	shr    $1,%r10
  7dc0f9:	add    %r10,%r8
  7dc0fc:	lea    (%r8,%r8,2),%r11
  7dc100:	cmp    %edx,(%rdi,%r11,4)
  7dc104:	cmova  %r9,%r8
  7dc108:	sub    %r10,%rcx
  7dc10b:	cmp    $0x1,%rcx
  7dc10f:	ja     7dc0f0 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry5stops+0x60>
  7dc111:	lea    (%r8,%r8,2),%rcx
  7dc115:	cmp    (%rdi,%rcx,4),%edx
  7dc118:	sbb    $0xffffffffffffffff,%r8
  7dc11c:	cmp    %rax,%r8
  7dc11f:	jb     7dc148 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry5stops+0xb8>
  7dc121:	mov    %r8,%rcx
  7dc124:	sub    %rax,%rcx
  7dc127:	je     7dc148 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry5stops+0xb8>
  7dc129:	lea    (%rax,%rax,2),%rax
  7dc12d:	lea    (%rdi,%rax,4),%r9
  7dc131:	cmp    %esi,(%r9)
  7dc134:	jne    7dc148 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry5stops+0xb8>
  7dc136:	lea    (%r8,%r8,2),%rsi
  7dc13a:	xor    %eax,%eax
  7dc13c:	cmp    %edx,-0xc(%rdi,%rsi,4)
  7dc140:	cmove  %r9,%rax
  7dc144:	mov    %rcx,%rdx
  7dc147:	ret
  7dc148:	xor    %eax,%eax
  7dc14a:	mov    %rcx,%rdx
  7dc14d:	ret

<gpui_canvas::text::layout::TextGeometry>::intervals bytes=154 frame=16

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007dc150 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry9intervals>:
  7dc150:	mov    %rdi,%rax
  7dc153:	test   %rcx,%rcx
  7dc156:	je     7dc166 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry9intervals+0x16>
  7dc158:	mov    (%rdx),%r8d
  7dc15b:	mov    0x28(%rsi),%rdi
  7dc15f:	test   %rdi,%rdi
  7dc162:	jne    7dc172 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry9intervals+0x22>
  7dc164:	jmp    7dc1cd <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry9intervals+0x7d>
  7dc166:	xor    %r8d,%r8d
  7dc169:	mov    0x28(%rsi),%rdi
  7dc16d:	test   %rdi,%rdi
  7dc170:	je     7dc1cd <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry9intervals+0x7d>
  7dc172:	push   %r14
  7dc174:	push   %rbx
  7dc175:	mov    0x20(%rsi),%r9
  7dc179:	xor    %r10d,%r10d
  7dc17c:	cmp    $0x1,%rdi
  7dc180:	je     7dc1b1 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry9intervals+0x61>
  7dc182:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  7dc190:	mov    %r10,%r11
  7dc193:	mov    %rdi,%rbx
  7dc196:	shr    $1,%rbx
  7dc199:	add    %rbx,%r10
  7dc19c:	lea    (%r10,%r10,2),%r14
  7dc1a0:	cmp    %r8d,(%r9,%r14,8)
  7dc1a4:	cmova  %r11,%r10
  7dc1a8:	sub    %rbx,%rdi
  7dc1ab:	cmp    $0x1,%rdi
  7dc1af:	ja     7dc190 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry9intervals+0x40>
  7dc1b1:	lea    (%r10,%r10,2),%r11
  7dc1b5:	xor    %edi,%edi
  7dc1b7:	cmp    %r8d,(%r9,%r11,8)
  7dc1bb:	setbe  %dil
  7dc1bf:	add    %r10,%rdi
  7dc1c2:	cmp    $0x1,%rdi
  7dc1c6:	adc    $0xffffffffffffffff,%rdi
  7dc1ca:	pop    %rbx
  7dc1cb:	pop    %r14
  7dc1cd:	mov    %rdx,(%rax)
  7dc1d0:	mov    %rcx,0x8(%rax)
  7dc1d4:	movq   $0x2,0x10(%rax)
  7dc1dc:	mov    %rsi,0x18(%rax)
  7dc1e0:	mov    %rdi,0x20(%rax)
  7dc1e4:	movss  %xmm0,0x28(%rax)
  7dc1e9:	ret

<alloc::sync::Arc<gpui_canvas::text::layout::TextGeometry>>::drop_slow bytes=135 frame=8

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/candidate-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007e1770 <_RNvMsn_NtCscdodAO9FK5_5alloc4syncINtB5_3ArcNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryE9drop_slowBL_>:
  7e1770:	push   %rbx
  7e1771:	mov    (%rdi),%rbx
  7e1774:	mov    0x10(%rbx),%rax
  7e1778:	test   %rax,%rax
  7e177b:	je     7e1794 <_RNvMsn_NtCscdodAO9FK5_5alloc4syncINtB5_3ArcNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryE9drop_slowBL_+0x24>
  7e177d:	mov    0x18(%rbx),%rdi
  7e1781:	shl    $0x3,%rax
  7e1785:	lea    (%rax,%rax,2),%rsi
  7e1789:	mov    $0x4,%edx
  7e178e:	call   *0x2d77dc(%rip)        # ab8f70 <_DYNAMIC+0x240>
  7e1794:	mov    0x28(%rbx),%rax
  7e1798:	test   %rax,%rax
  7e179b:	je     7e17b4 <_RNvMsn_NtCscdodAO9FK5_5alloc4syncINtB5_3ArcNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryE9drop_slowBL_+0x44>
  7e179d:	mov    0x30(%rbx),%rdi
  7e17a1:	shl    $0x3,%rax
  7e17a5:	lea    (%rax,%rax,2),%rsi
  7e17a9:	mov    $0x4,%edx
  7e17ae:	call   *0x2d77bc(%rip)        # ab8f70 <_DYNAMIC+0x240>
  7e17b4:	mov    0x40(%rbx),%rax
  7e17b8:	test   %rax,%rax
  7e17bb:	je     7e17d4 <_RNvMsn_NtCscdodAO9FK5_5alloc4syncINtB5_3ArcNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryE9drop_slowBL_+0x64>
  7e17bd:	mov    0x48(%rbx),%rdi
  7e17c1:	shl    $0x2,%rax
  7e17c5:	lea    (%rax,%rax,2),%rsi
  7e17c9:	mov    $0x4,%edx
  7e17ce:	call   *0x2d779c(%rip)        # ab8f70 <_DYNAMIC+0x240>
  7e17d4:	cmp    $0xffffffffffffffff,%rbx
  7e17d8:	je     7e17f5 <_RNvMsn_NtCscdodAO9FK5_5alloc4syncINtB5_3ArcNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryE9drop_slowBL_+0x85>
  7e17da:	lock decq 0x8(%rbx)
  7e17df:	jne    7e17f5 <_RNvMsn_NtCscdodAO9FK5_5alloc4syncINtB5_3ArcNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryE9drop_slowBL_+0x85>
  7e17e1:	mov    $0x60,%esi
  7e17e6:	mov    $0x8,%edx
  7e17eb:	mov    %rbx,%rdi
  7e17ee:	pop    %rbx
  7e17ef:	jmp    *0x2d777b(%rip)        # ab8f70 <_DYNAMIC+0x240>
  7e17f5:	pop    %rbx
  7e17f6:	ret
