
<core::option::Option<alloc::vec::Vec<gpui::runtime::geometry::Record>>>::or_else::<<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::present_inner::{closure#42}> bytes=105 frame=0

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000073d480 <_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime8geometry6RecordEE7or_elseNCNvMsu_B1i_INtB1i_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersE_0EB2E_>:
  73d480:	cmpq   $0xffffffffffffffff,(%rsi)
  73d484:	je     73d4af <_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime8geometry6RecordEE7or_elseNCNvMsu_B1i_INtB1i_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersE_0EB2E_+0x2f>
  73d486:	mov    0x10(%rsi),%rax
  73d48a:	mov    %rax,0x10(%rdi)
  73d48e:	movups (%rsi),%xmm0
  73d491:	movups %xmm0,(%rdi)
  73d494:	mov    (%rdx),%rsi
  73d497:	test   %rsi,%rsi
  73d49a:	je     73d4ca <_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime8geometry6RecordEE7or_elseNCNvMsu_B1i_INtB1i_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersE_0EB2E_+0x4a>
  73d49c:	mov    0x8(%rdx),%rdi
  73d4a0:	shl    $0x4,%rsi
  73d4a4:	mov    $0x4,%edx
  73d4a9:	jmp    *0x37cdd1(%rip)        # aba280 <_DYNAMIC+0x240>
  73d4af:	mov    (%rdx),%rsi
  73d4b2:	mov    0x8(%rdx),%rax
  73d4b6:	mov    0x10(%rdx),%rcx
  73d4ba:	test   %rcx,%rcx
  73d4bd:	je     73d4cb <_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime8geometry6RecordEE7or_elseNCNvMsu_B1i_INtB1i_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersE_0EB2E_+0x4b>
  73d4bf:	mov    %rsi,(%rdi)
  73d4c2:	mov    %rax,0x8(%rdi)
  73d4c6:	mov    %rcx,0x10(%rdi)
  73d4ca:	ret
  73d4cb:	movq   $0xffffffffffffffff,(%rdi)
  73d4d2:	test   %rsi,%rsi
  73d4d5:	je     73d4ca <_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime8geometry6RecordEE7or_elseNCNvMsu_B1i_INtB1i_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersE_0EB2E_+0x4a>
  73d4d7:	shl    $0x4,%rsi
  73d4db:	mov    $0x4,%edx
  73d4e0:	mov    %rax,%rdi
  73d4e3:	jmp    *0x37cd97(%rip)        # aba280 <_DYNAMIC+0x240>

<gpui::runtime::RuntimeMut<canonical_text_public_control::Editor, ()>>::operation_with_editing::<<gpui::runtime::RuntimeMut<canonical_text_public_control::Editor, ()>>::replace_input::{closure#2}> bytes=974 frame=280

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000073da50 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_>:
  73da50:	push   %rbp
  73da51:	push   %r15
  73da53:	push   %r14
  73da55:	push   %r13
  73da57:	push   %r12
  73da59:	push   %rbx
  73da5a:	sub    $0xe8,%rsp
  73da61:	mov    %rdi,%rbx
  73da64:	mov    (%rsi),%r14
  73da67:	mov    $0xe,%eax
  73da6c:	cmpb   $0x0,0x76e(%r14)
  73da74:	je     73daa5 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x55>
  73da76:	mov    %rax,(%rbx)
  73da79:	mov    (%rcx),%rsi
  73da7c:	test   %rsi,%rsi
  73da7f:	je     73dd65 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x315>
  73da85:	mov    0x8(%rcx),%rdi
  73da89:	mov    $0x1,%edx
  73da8e:	add    $0xe8,%rsp
  73da95:	pop    %rbx
  73da96:	pop    %r12
  73da98:	pop    %r13
  73da9a:	pop    %r14
  73da9c:	pop    %r15
  73da9e:	pop    %rbp
  73da9f:	jmp    *0x37c7db(%rip)        # aba280 <_DYNAMIC+0x240>
  73daa5:	mov    0x6a0(%r14),%r9
  73daac:	inc    %r9
  73daaf:	je     73dd77 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x327>
  73dab5:	mov    (%rcx),%r11
  73dab8:	mov    0x8(%rcx),%r10
  73dabc:	mov    0x10(%rcx),%r13
  73dac0:	mov    0x18(%rcx),%r12
  73dac4:	mov    0x20(%rcx),%r15
  73dac8:	mov    0x228(%r14),%rax
  73dacf:	lea    0x230(%r14),%rcx
  73dad6:	cmp    $0xffffffffffffffff,%rax
  73dada:	lea    0x88(%rsp),%rdi
  73dae2:	cmovne %rcx,%rdi
  73dae6:	movups (%rdi),%xmm0
  73dae9:	movaps %xmm0,0xd0(%rsp)
  73daf1:	je     73db54 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x104>
  73daf3:	movaps 0xd0(%rsp),%xmm0
  73dafb:	movups %xmm0,0x48(%rsp)
  73db00:	mov    %rax,0x40(%rsp)
  73db05:	mov    %r11,0x58(%rsp)
  73db0a:	mov    %r10,0x60(%rsp)
  73db0f:	mov    %r13,0x68(%rsp)
  73db14:	mov    %r12,0x70(%rsp)
  73db19:	mov    0x40(%rsp),%rax
  73db1e:	cmp    $0xfffffffffffffffe,%rax
  73db22:	jne    73dcf2 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x2a2>
  73db28:	mov    %r9,0x6a0(%r14)
  73db2f:	incq   0x700(%r14)
  73db36:	movq   $0x0,0x758(%r14)
  73db41:	mov    %rbx,%rdi
  73db44:	mov    %r8,%rcx
  73db47:	xor    %r8d,%r8d
  73db4a:	call   767940 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB4_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE20after_source_changedBW_>
  73db4f:	jmp    73dd65 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x315>
  73db54:	mov    %r13,0x38(%rsp)
  73db59:	mov    %r15,0x78(%rsp)
  73db5e:	mov    %r11,0x8(%rsp)
  73db63:	mov    %r10,0x10(%rsp)
  73db68:	mov    %r9,0x18(%rsp)
  73db6d:	mov    %rsi,0x20(%rsp)
  73db72:	mov    %rdx,0x28(%rsp)
  73db77:	mov    %r8,0x30(%rsp)
  73db7c:	cmp    $0x1,%r12d
  73db80:	jne    73dc10 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x1c0>
  73db86:	mov    0x248(%r14),%r15
  73db8d:	mov    0x250(%r14),%r13
  73db94:	shl    $0x4,%r13
  73db98:	xor    %ebp,%ebp
  73db9a:	nopw   0x0(%rax,%rax,1)
  73dba0:	cmp    %rbp,%r13
  73dba3:	je     73dc9e <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x24e>
  73dba9:	mov    (%r15,%rbp,1),%rdi
  73dbad:	mov    0x8(%r15,%rbp,1),%rax
  73dbb2:	call   *0x18(%rax)
  73dbb5:	add    $0x10,%rbp
  73dbb9:	cmp    %r12,%rax
  73dbbc:	jne    73dba0 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x150>
  73dbbe:	mov    -0x10(%r15,%rbp,1),%rsi
  73dbc3:	mov    -0x8(%r15,%rbp,1),%rax
  73dbc8:	mov    0x8(%rsp),%rcx
  73dbcd:	mov    %rcx,0x80(%rsp)
  73dbd5:	mov    0x10(%rsp),%rcx
  73dbda:	mov    %rcx,0x88(%rsp)
  73dbe2:	mov    0x38(%rsp),%rcx
  73dbe7:	mov    %rcx,0x90(%rsp)
  73dbef:	lea    0x40(%rsp),%rdi
  73dbf4:	lea    0x80(%rsp),%rcx
  73dbfc:	lea    0x290(%r14),%rdx
  73dc03:	mov    0x78(%rsp),%r8
  73dc08:	call   *0x40(%rax)
  73dc0b:	jmp    73dccf <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x27f>
  73dc10:	mov    0x278(%r14),%r15
  73dc17:	mov    0x280(%r14),%rbp
  73dc1e:	shl    $0x4,%rbp
  73dc22:	xor    %r13d,%r13d
  73dc25:	data16 cs nopw 0x0(%rax,%rax,1)
  73dc30:	cmp    %r13,%rbp
  73dc33:	je     73dc9e <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x24e>
  73dc35:	mov    (%r15,%r13,1),%rdi
  73dc39:	mov    0x8(%r15,%r13,1),%rax
  73dc3e:	mov    %r12,%rsi
  73dc41:	call   *0x30(%rax)
  73dc44:	add    $0x10,%r13
  73dc48:	test   %al,%al
  73dc4a:	je     73dc30 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x1e0>
  73dc4c:	mov    -0x10(%r15,%r13,1),%rsi
  73dc51:	mov    -0x8(%r15,%r13,1),%rax
  73dc56:	mov    0x8(%rsp),%rcx
  73dc5b:	mov    %rcx,0x80(%rsp)
  73dc63:	mov    0x10(%rsp),%rcx
  73dc68:	mov    %rcx,0x88(%rsp)
  73dc70:	mov    0x38(%rsp),%rcx
  73dc75:	mov    %rcx,0x90(%rsp)
  73dc7d:	lea    0x40(%rsp),%rdi
  73dc82:	lea    0x80(%rsp),%r8
  73dc8a:	lea    0x290(%r14),%rdx
  73dc91:	mov    %r12,%rcx
  73dc94:	mov    0x78(%rsp),%r9
  73dc99:	call   *0x70(%rax)
  73dc9c:	jmp    73dccf <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x27f>
  73dc9e:	movq   $0xb,0x40(%rsp)
  73dca7:	mov    %r12,0x48(%rsp)
  73dcac:	mov    0x8(%rsp),%rax
  73dcb1:	mov    %rax,0x58(%rsp)
  73dcb6:	mov    0x10(%rsp),%rax
  73dcbb:	mov    %rax,0x60(%rsp)
  73dcc0:	mov    0x38(%rsp),%rax
  73dcc5:	mov    %rax,0x68(%rsp)
  73dcca:	mov    %r12,0x70(%rsp)
  73dccf:	mov    0x30(%rsp),%r8
  73dcd4:	mov    0x28(%rsp),%rdx
  73dcd9:	mov    0x20(%rsp),%rsi
  73dcde:	mov    0x18(%rsp),%r9
  73dce3:	mov    0x40(%rsp),%rax
  73dce8:	cmp    $0xfffffffffffffffe,%rax
  73dcec:	je     73db28 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0xd8>
  73dcf2:	mov    0x48(%rsp),%rcx
  73dcf7:	movups 0x50(%rsp),%xmm0
  73dcfc:	movups 0x60(%rsp),%xmm1
  73dd01:	mov    0x70(%rsp),%rdx
  73dd06:	mov    %rcx,0xa0(%rsp)
  73dd0e:	movups %xmm0,0xa8(%rsp)
  73dd16:	movups %xmm1,0xb8(%rsp)
  73dd1e:	mov    %rdx,0xc8(%rsp)
  73dd26:	movups 0xb0(%rsp),%xmm0
  73dd2e:	movups %xmm0,0x18(%rbx)
  73dd32:	mov    0xc0(%rsp),%rcx
  73dd3a:	mov    %rcx,0x28(%rbx)
  73dd3e:	mov    0xc8(%rsp),%rcx
  73dd46:	mov    %rcx,0x30(%rbx)
  73dd4a:	mov    0xa0(%rsp),%rcx
  73dd52:	mov    %rcx,0x8(%rbx)
  73dd56:	mov    0xa8(%rsp),%rcx
  73dd5e:	mov    %rcx,0x10(%rbx)
  73dd62:	mov    %rax,(%rbx)
  73dd65:	add    $0xe8,%rsp
  73dd6c:	pop    %rbx
  73dd6d:	pop    %r12
  73dd6f:	pop    %r13
  73dd71:	pop    %r14
  73dd73:	pop    %r15
  73dd75:	pop    %rbp
  73dd76:	ret
  73dd77:	mov    $0x1f,%eax
  73dd7c:	mov    %rax,(%rbx)
  73dd7f:	mov    (%rcx),%rsi
  73dd82:	test   %rsi,%rsi
  73dd85:	jne    73da85 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x35>
  73dd8b:	jmp    73dd65 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x315>
  73dd8d:	mov    %rax,%r12
  73dd90:	jmp    73ddb4 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x364>
  73dd92:	jmp    73dd94 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x344>
  73dd94:	mov    %rax,%r12
  73dd97:	cmpq   $0x0,0x8(%rsp)
  73dd9d:	je     73ddb4 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x364>
  73dd9f:	mov    $0x1,%edx
  73dda4:	mov    0x10(%rsp),%rdi
  73dda9:	mov    0x8(%rsp),%rsi
  73ddae:	call   *0x37c4cc(%rip)        # aba280 <_DYNAMIC+0x240>
  73ddb4:	mov    %r12,%rdi
  73ddb7:	call   *0x37c51b(%rip)        # aba2d8 <_DYNAMIC+0x298>
  73ddbd:	mov    %rax,0xa0(%rsp)
  73ddc5:	mov    %rdx,0xa8(%rsp)
  73ddcd:	movq   $0xfffffffffffffffd,0x98(%rsp)
  73ddd9:	mov    %r14,%rdi
  73dddc:	call   78d970 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE6poisonBO_>
  73dde1:	movq   $0xf,(%rbx)
  73dde8:	lea    0x98(%rsp),%rdi
  73ddf0:	call   746360 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultIBC_NtNtNtCslbxve4rcJus_4gpui7runtime5paint12PatchOutcomeNtB15_5ErrorEINtNtCscdodAO9FK5_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECs9C2G9YFESsD_29canonical_text_public_control>
  73ddf5:	jmp    73dd65 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_+0x315>
  73ddfa:	mov    %rax,%rbx
  73ddfd:	lea    0x98(%rsp),%rdi
  73de05:	call   746360 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultIBC_NtNtNtCslbxve4rcJus_4gpui7runtime5paint12PatchOutcomeNtB15_5ErrorEINtNtCscdodAO9FK5_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECs9C2G9YFESsD_29canonical_text_public_control>
  73de0a:	mov    %rbx,%rdi
  73de0d:	call   a98730 <_Unwind_Resume@plt>
  73de12:	call   *0x37c490(%rip)        # aba2a8 <_DYNAMIC+0x268>
  73de18:	call   *0x37c4c2(%rip)        # aba2e0 <_DYNAMIC+0x2a0>

<gpui_canvas::text::TextLayout>::selection_rects::<<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::present_inner::{closure#30}> bytes=1753 frame=424

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000073f610 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_>:
  73f610:	push   %rbp
  73f611:	push   %r15
  73f613:	push   %r14
  73f615:	push   %r13
  73f617:	push   %r12
  73f619:	push   %rbx
  73f61a:	sub    $0x178,%rsp
  73f621:	test   %rdi,%rdi
  73f624:	je     73fbe9 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x5d9>
  73f62a:	mov    %rsi,%rbx
  73f62d:	mov    %rdi,%r12
  73f630:	lea    0x10(%rdi),%r15
  73f634:	mov    (%rdx),%r14
  73f637:	mov    0x8(%rdx),%r13
  73f63b:	mov    0x10(%rdx),%rax
  73f63f:	mov    %rax,0x70(%rsp)
  73f644:	mov    0x18(%rdx),%rax
  73f648:	mov    %rax,0x68(%rsp)
  73f64d:	mov    0x20(%rdx),%rax
  73f651:	mov    %rax,0x78(%rsp)
  73f656:	mov    0x28(%rdx),%rbp
  73f65a:	mov    %r15,%rdi
  73f65d:	call   *0x37ac9d(%rip)        # aba300 <_DYNAMIC+0x2c0>
  73f663:	test   %al,%al
  73f665:	je     73fbe9 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x5d9>
  73f66b:	mov    (%rbx),%esi
  73f66d:	mov    0x8(%rbx),%eax
  73f670:	cmp    %esi,%eax
  73f672:	je     73fbed <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x5dd>
  73f678:	mov    %esi,%edx
  73f67a:	cmova  %eax,%edx
  73f67d:	cmovb  %eax,%esi
  73f680:	mov    %r15,%rdi
  73f683:	call   *0x37ac7f(%rip)        # aba308 <_DYNAMIC+0x2c8>
  73f689:	mov    %rdx,%rcx
  73f68c:	movss  0x5c(%r12),%xmm0
  73f693:	mulss  -0x67d183(%rip),%xmm0        # c2518 <GCC_except_table0+0x110>
  73f69b:	lea    0xb0(%rsp),%r12
  73f6a3:	mov    %r12,%rdi
  73f6a6:	mov    %r15,%rsi
  73f6a9:	mov    %rax,%rdx
  73f6ac:	call   *0x37ac5e(%rip)        # aba310 <_DYNAMIC+0x2d0>
  73f6b2:	lea    0x30(%rsp),%rdi
  73f6b7:	mov    %r12,%rsi
  73f6ba:	call   7986e0 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control>
  73f6bf:	cmpq   $0x0,0x30(%rsp)
  73f6c5:	je     73fbed <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x5dd>
  73f6cb:	movq   $0x0,0x28(%rsp)
  73f6d4:	mov    %r14,0x18(%rsp)
  73f6d9:	mov    %r13,0x10(%rsp)
  73f6de:	mov    %rbp,0x8(%rsp)
  73f6e3:	movss  %xmm1,0x4(%rsp)
  73f6e9:	movaps %xmm3,%xmm0
  73f6ec:	mov    0xe8(%rsp),%rbp
  73f6f4:	movss  0xf0(%rsp),%xmm1
  73f6fd:	movss  %xmm1,0x80(%rsp)
  73f706:	mov    0xb0(%rsp),%r14
  73f70e:	mov    0xb8(%rsp),%r13
  73f716:	mov    0xd0(%rsp),%rbx
  73f71e:	mov    0xc8(%rsp),%r15
  73f726:	mov    0xc0(%rsp),%r12
  73f72e:	movaps %xmm2,0xa0(%rsp)
  73f736:	movaps %xmm0,0x90(%rsp)
  73f73e:	xchg   %ax,%ax
  73f740:	lea    0x140(%rsp),%rdi
  73f748:	mov    %rbp,%rsi
  73f74b:	movss  0x80(%rsp),%xmm0
  73f754:	lea    0x30(%rsp),%rdx
  73f759:	call   75d580 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control>
  73f75e:	cmpb   $0x2,0x144(%rsp)
  73f766:	jne    73f945 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x335>
  73f76c:	mov    %r13,%rax
  73f76f:	cmp    $0x1,%r13
  73f773:	movaps 0xa0(%rsp),%xmm2
  73f77b:	movaps 0x90(%rsp),%xmm0
  73f783:	je     73f7b4 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x1a4>
  73f785:	test   %r13,%r13
  73f788:	je     73fc01 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x5f1>
  73f78e:	mov    (%r14),%ecx
  73f791:	lea    0xc(%r14),%rdx
  73f795:	lea    0x1(%r13),%rsi
  73f799:	mov    $0x1,%eax
  73f79e:	xchg   %ax,%ax
  73f7a0:	cmp    (%rdx),%ecx
  73f7a2:	jne    73f7b4 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x1a4>
  73f7a4:	inc    %rax
  73f7a7:	add    $0xc,%rdx
  73f7ab:	dec    %rsi
  73f7ae:	cmp    $0x2,%rsi
  73f7b2:	ja     73f7a0 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x190>
  73f7b4:	sub    %rax,%r13
  73f7b7:	jb     73fcd0 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x6c0>
  73f7bd:	mov    %r13,0xb8(%rsp)
  73f7c5:	test   %rbx,%rbx
  73f7c8:	jne    73f870 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x260>
  73f7ce:	mov    %r15,%rcx
  73f7d1:	cmp    $0x1,%r15
  73f7d5:	je     73f814 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x204>
  73f7d7:	test   %r15,%r15
  73f7da:	je     73fc01 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x5f1>
  73f7e0:	mov    (%r12),%edx
  73f7e4:	lea    0xc(%r12),%rsi
  73f7e9:	lea    0x1(%r15),%rdi
  73f7ed:	mov    $0x1,%ecx
  73f7f2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  73f800:	cmp    (%rsi),%edx
  73f802:	jne    73f814 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x204>
  73f804:	inc    %rcx
  73f807:	add    $0xc,%rsi
  73f80b:	dec    %rdi
  73f80e:	cmp    $0x2,%rdi
  73f812:	ja     73f800 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x1f0>
  73f814:	sub    %rcx,%r15
  73f817:	jb     73fcd0 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x6c0>
  73f81d:	lea    (%rcx,%rcx,2),%rdx
  73f821:	lea    (%r12,%rdx,4),%rdx
  73f825:	mov    %rdx,0xc0(%rsp)
  73f82d:	mov    %r15,0xc8(%rsp)
  73f835:	test   %r12,%r12
  73f838:	je     73fc01 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x5f1>
  73f83e:	lea    (%rax,%rax,2),%rsi
  73f842:	mov    %r14,0x30(%rsp)
  73f847:	mov    %rax,0x38(%rsp)
  73f84c:	mov    %r12,0x40(%rsp)
  73f851:	mov    %rcx,0x48(%rsp)
  73f856:	mov    %rdx,%r12
  73f859:	mov    $0x0,%ebx
  73f85e:	test   %r14,%r14
  73f861:	lea    (%r14,%rsi,4),%r14
  73f865:	jne    73f740 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x130>
  73f86b:	jmp    73fc01 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x5f1>
  73f870:	movq   $0x0,0xd0(%rsp)
  73f87c:	mov    %r12,%rsi
  73f87f:	mov    %r15,%rdx
  73f882:	mov    %r15,%rdi
  73f885:	cmp    $0x1,%r15
  73f889:	je     73f8b8 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x2a8>
  73f88b:	test   %rdx,%rdx
  73f88e:	je     73fc01 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x5f1>
  73f894:	mov    (%rsi),%ecx
  73f896:	lea    0xc(%rsi),%r8
  73f89a:	lea    0x1(%rdx),%r9
  73f89e:	mov    $0x1,%edi
  73f8a3:	cmp    (%r8),%ecx
  73f8a6:	jne    73f8b8 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x2a8>
  73f8a8:	inc    %rdi
  73f8ab:	add    $0xc,%r8
  73f8af:	dec    %r9
  73f8b2:	cmp    $0x2,%r9
  73f8b6:	ja     73f8a3 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x293>
  73f8b8:	mov    %rdx,%r15
  73f8bb:	sub    %rdi,%r15
  73f8be:	jb     73fcd0 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x6c0>
  73f8c4:	lea    (%rdi,%rdi,2),%r9
  73f8c8:	lea    (%rsi,%r9,4),%r12
  73f8cc:	dec    %rbx
  73f8cf:	jne    73f87c <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x26c>
  73f8d1:	mov    %r12,0xc0(%rsp)
  73f8d9:	mov    %r15,0xc8(%rsp)
  73f8e1:	mov    %r15,%rcx
  73f8e4:	cmp    $0x1,%r15
  73f8e8:	je     73f91f <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x30f>
  73f8ea:	test   %r15,%r15
  73f8ed:	je     73fc01 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x5f1>
  73f8f3:	mov    (%r12),%r8d
  73f8f7:	lea    (%rsi,%r9,4),%rsi
  73f8fb:	add    $0xc,%rsi
  73f8ff:	sub    %rdi,%rdx
  73f902:	inc    %rdx
  73f905:	mov    $0x1,%ecx
  73f90a:	cmp    (%rsi),%r8d
  73f90d:	jne    73f91f <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x30f>
  73f90f:	inc    %rcx
  73f912:	add    $0xc,%rsi
  73f916:	dec    %rdx
  73f919:	cmp    $0x2,%rdx
  73f91d:	ja     73f90a <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x2fa>
  73f91f:	sub    %rcx,%r15
  73f922:	jb     73fcd0 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x6c0>
  73f928:	lea    (%rcx,%rcx,2),%rdx
  73f92c:	lea    (%r12,%rdx,4),%rdx
  73f930:	mov    %rdx,0xc0(%rsp)
  73f938:	mov    %r15,0xc8(%rsp)
  73f940:	jmp    73f83e <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x22e>
  73f945:	mov    %r14,0xb0(%rsp)
  73f94d:	movss  0x158(%rsp),%xmm3
  73f956:	xorps  %xmm0,%xmm0
  73f959:	ucomiss %xmm0,%xmm3
  73f95c:	jne    73f974 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x364>
  73f95e:	jp     73f974 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x364>
  73f960:	mov    0x18(%rsp),%r14
  73f965:	mov    0x10(%rsp),%r13
  73f96a:	mov    0x8(%rsp),%rbp
  73f96f:	jmp    73fa62 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x452>
  73f974:	movsd  0x150(%rsp),%xmm5
  73f97d:	movss  0x15c(%rsp),%xmm6
  73f986:	mov    0x160(%rsp),%rbx
  73f98e:	movaps %xmm5,%xmm7
  73f991:	shufps $0x55,%xmm5,%xmm7
  73f995:	testb  $0x1,0x28(%rsp)
  73f99a:	mov    0x18(%rsp),%r14
  73f99f:	mov    0x10(%rsp),%r13
  73f9a4:	mov    0x8(%rsp),%rbp
  73f9a9:	movaps 0xa0(%rsp),%xmm2
  73f9b1:	movaps 0x90(%rsp),%xmm4
  73f9b9:	je     73fb72 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x562>
  73f9bf:	mov    0x118(%rsp),%rax
  73f9c7:	cmp    %rbx,%rax
  73f9ca:	jne    73fa9a <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x48a>
  73f9d0:	movaps 0x100(%rsp),%xmm0
  73f9d8:	ucomiss %xmm7,%xmm0
  73f9db:	jne    73fa9a <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x48a>
  73f9e1:	jp     73fa9a <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x48a>
  73f9e7:	movss  0x4(%rsp),%xmm0
  73f9ed:	ucomiss %xmm6,%xmm0
  73f9f0:	jne    73fa9a <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x48a>
  73f9f6:	jp     73fa9a <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x48a>
  73f9fc:	movaps %xmm5,%xmm0
  73f9ff:	addss  %xmm3,%xmm0
  73fa03:	ucomiss %xmm4,%xmm0
  73fa06:	jb     73fa97 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x487>
  73fa0c:	movaps %xmm2,%xmm1
  73fa0f:	addss  %xmm4,%xmm1
  73fa13:	ucomiss %xmm5,%xmm1
  73fa16:	jb     73fa97 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x487>
  73fa18:	movaps %xmm1,%xmm2
  73fa1b:	maxss  %xmm0,%xmm2
  73fa1f:	movaps %xmm2,%xmm3
  73fa22:	cmpunordss %xmm2,%xmm3
  73fa27:	movaps %xmm3,%xmm0
  73fa2a:	andnps %xmm2,%xmm0
  73fa2d:	andps  %xmm1,%xmm3
  73fa30:	orps   %xmm0,%xmm3
  73fa33:	movaps %xmm4,%xmm0
  73fa36:	minss  %xmm5,%xmm0
  73fa3a:	movaps %xmm0,%xmm1
  73fa3d:	cmpunordss %xmm0,%xmm1
  73fa42:	movaps %xmm1,%xmm2
  73fa45:	andnps %xmm0,%xmm2
  73fa48:	andps  %xmm4,%xmm1
  73fa4b:	orps   %xmm2,%xmm1
  73fa4e:	subss  %xmm1,%xmm3
  73fa52:	movaps %xmm3,0xa0(%rsp)
  73fa5a:	movaps %xmm1,0x90(%rsp)
  73fa62:	lea    0x30(%rsp),%rdi
  73fa67:	lea    0xb0(%rsp),%rsi
  73fa6f:	call   7986e0 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control>
  73fa74:	cmpq   $0x0,0x30(%rsp)
  73fa7a:	mov    $0x1,%al
  73fa7c:	movaps 0xa0(%rsp),%xmm2
  73fa84:	movaps 0x90(%rsp),%xmm0
  73fa8c:	jne    73f6ec <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0xdc>
  73fa92:	jmp    73fc12 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x602>
  73fa97:	mov    %rax,%rbx
  73fa9a:	movaps %xmm7,0x130(%rsp)
  73faa2:	movss  %xmm6,0x20(%rsp)
  73faa8:	movss  %xmm3,0x24(%rsp)
  73faae:	movaps %xmm5,0x80(%rsp)
  73fab6:	cmpl   $0xffffffff,(%r14)
  73faba:	jne    73fb8e <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x57e>
  73fac0:	unpcklps 0x100(%rsp),%xmm4
  73fac8:	mov    0x68(%rsp),%rax
  73facd:	movss  (%rax),%xmm0
  73fad1:	mov    0x70(%rsp),%rax
  73fad6:	movss  (%rax),%xmm1
  73fada:	unpcklps %xmm0,%xmm1
  73fadd:	addps  %xmm4,%xmm1
  73fae0:	movlps %xmm1,0x120(%rsp)
  73fae8:	movss  %xmm2,0x128(%rsp)
  73faf1:	movss  0x4(%rsp),%xmm0
  73faf7:	movss  %xmm0,0x12c(%rsp)
  73fb00:	mov    0x78(%rsp),%rcx
  73fb05:	mov    0x10(%rcx),%rax
  73fb09:	mov    %rax,0x150(%rsp)
  73fb11:	movups (%rcx),%xmm0
  73fb14:	movaps %xmm0,0x140(%rsp)
  73fb1c:	movups 0x0(%rbp),%xmm0
  73fb20:	movaps %xmm0,0x50(%rsp)
  73fb25:	lea    0x30(%rsp),%r15
  73fb2a:	mov    %r15,%rdi
  73fb2d:	mov    $0x46,%esi
  73fb32:	mov    $0x82,%edx
  73fb37:	mov    $0xf0,%ecx
  73fb3c:	mov    $0x60,%r8d
  73fb42:	call   *0x37a7d0(%rip)        # aba318 <_DYNAMIC+0x2d8>
  73fb48:	mov    %r13,%rdi
  73fb4b:	lea    0x120(%rsp),%rsi
  73fb53:	lea    0x140(%rsp),%rdx
  73fb5b:	lea    0x50(%rsp),%rcx
  73fb60:	mov    %r15,%r8
  73fb63:	call   *0x37a7b7(%rip)        # aba320 <_DYNAMIC+0x2e0>
  73fb69:	mov    %eax,(%r14)
  73fb6c:	mov    %edx,0x4(%r14)
  73fb70:	jmp    73fb8e <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x57e>
  73fb72:	movaps %xmm7,0x130(%rsp)
  73fb7a:	movss  %xmm6,0x20(%rsp)
  73fb80:	movss  %xmm3,0x24(%rsp)
  73fb86:	movaps %xmm5,0x80(%rsp)
  73fb8e:	lea    0x30(%rsp),%rdi
  73fb93:	lea    0xb0(%rsp),%rsi
  73fb9b:	call   7986e0 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control>
  73fba0:	cmpq   $0x0,0x30(%rsp)
  73fba6:	mov    $0x1,%al
  73fba8:	mov    %rax,0x28(%rsp)
  73fbad:	mov    %rbx,0x118(%rsp)
  73fbb5:	movaps 0x130(%rsp),%xmm0
  73fbbd:	movaps %xmm0,0x100(%rsp)
  73fbc5:	movaps 0x80(%rsp),%xmm3
  73fbcd:	movss  0x24(%rsp),%xmm2
  73fbd3:	movss  0x20(%rsp),%xmm1
  73fbd9:	jne    73f6e3 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0xd3>
  73fbdf:	movss  %xmm1,0x4(%rsp)
  73fbe5:	mov    $0x1,%al
  73fbe7:	jmp    73fc24 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x614>
  73fbe9:	xor    %eax,%eax
  73fbeb:	jmp    73fbef <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x5df>
  73fbed:	mov    $0x1,%al
  73fbef:	add    $0x178,%rsp
  73fbf6:	pop    %rbx
  73fbf7:	pop    %r12
  73fbf9:	pop    %r13
  73fbfb:	pop    %r14
  73fbfd:	pop    %r15
  73fbff:	pop    %rbp
  73fc00:	ret
  73fc01:	mov    $0x1,%al
  73fc03:	mov    0x18(%rsp),%r14
  73fc08:	mov    0x10(%rsp),%r13
  73fc0d:	mov    0x8(%rsp),%rbp
  73fc12:	testb  $0x1,0x28(%rsp)
  73fc17:	je     73fbef <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x5df>
  73fc19:	unpcklps 0x100(%rsp),%xmm0
  73fc21:	movaps %xmm0,%xmm3
  73fc24:	cmpl   $0xffffffff,(%r14)
  73fc28:	jne    73fbef <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x5df>
  73fc2a:	mov    0x68(%rsp),%rax
  73fc2f:	movss  (%rax),%xmm0
  73fc33:	mov    0x70(%rsp),%rax
  73fc38:	movss  (%rax),%xmm1
  73fc3c:	unpcklps %xmm0,%xmm1
  73fc3f:	addps  %xmm1,%xmm3
  73fc42:	movlps %xmm3,0x50(%rsp)
  73fc47:	movss  %xmm2,0x58(%rsp)
  73fc4d:	movss  0x4(%rsp),%xmm0
  73fc53:	movss  %xmm0,0x5c(%rsp)
  73fc59:	mov    0x78(%rsp),%rcx
  73fc5e:	mov    0x10(%rcx),%rax
  73fc62:	mov    %rax,0xc0(%rsp)
  73fc6a:	movups (%rcx),%xmm0
  73fc6d:	movaps %xmm0,0xb0(%rsp)
  73fc75:	movups 0x0(%rbp),%xmm0
  73fc79:	movaps %xmm0,0x30(%rsp)
  73fc7e:	lea    0x140(%rsp),%r15
  73fc86:	mov    %r15,%rdi
  73fc89:	mov    $0x46,%esi
  73fc8e:	mov    $0x82,%edx
  73fc93:	mov    $0xf0,%ecx
  73fc98:	mov    $0x60,%r8d
  73fc9e:	call   *0x37a674(%rip)        # aba318 <_DYNAMIC+0x2d8>
  73fca4:	lea    0x50(%rsp),%rsi
  73fca9:	lea    0xb0(%rsp),%rdx
  73fcb1:	lea    0x30(%rsp),%rcx
  73fcb6:	mov    %r13,%rdi
  73fcb9:	mov    %r15,%r8
  73fcbc:	call   *0x37a65e(%rip)        # aba320 <_DYNAMIC+0x2e0>
  73fcc2:	mov    %eax,(%r14)
  73fcc5:	mov    $0x1,%al
  73fcc7:	mov    %edx,0x4(%r14)
  73fccb:	jmp    73fbef <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_+0x5df>
  73fcd0:	lea    -0x670036(%rip),%rdi        # cfca1 <GCC_except_table0+0xd899>
  73fcd7:	lea    0x35c1b2(%rip),%rdx        # a9be90 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x23a8>
  73fcde:	mov    $0x13,%esi
  73fce3:	call   *0x37a5cf(%rip)        # aba2b8 <_DYNAMIC+0x278>

<gpui::runtime::scroll::ViewportBuild>::freeze::<<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::present_inner::{closure#44}> bytes=1391 frame=120

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000073fd50 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_>:
  73fd50:	push   %rbp
  73fd51:	push   %r15
  73fd53:	push   %r14
  73fd55:	push   %r13
  73fd57:	push   %r12
  73fd59:	push   %rbx
  73fd5a:	sub    $0x48,%rsp
  73fd5e:	mov    %rdx,0x10(%rsp)
  73fd63:	mov    %rdi,0x18(%rsp)
  73fd68:	mov    0x10(%rsi),%rbx
  73fd6c:	test   %rbx,%rbx
  73fd6f:	mov    %rsi,0x8(%rsp)
  73fd74:	je     73fdb9 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x69>
  73fd76:	mov    0x8(%rsi),%rbp
  73fd7a:	lea    -0x1(%rbx),%r15
  73fd7e:	mov    $0x28,%r13d
  73fd84:	xor    %r14d,%r14d
  73fd87:	nopw   0x0(%rax,%rax,1)
  73fd90:	mov    -0x28(%rbp,%r13,1),%rsi
  73fd95:	mov    0x10(%rsp),%rdi
  73fd9a:	call   75e1e0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_>
  73fd9f:	test   $0x1,%al
  73fda1:	je     73fdbe <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x6e>
  73fda3:	mov    %edx,-0x4(%rbp,%r13,1)
  73fda8:	inc    %r14
  73fdab:	add    $0x28,%r13
  73fdaf:	cmp    %r14,%rbx
  73fdb2:	jne    73fd90 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x40>
  73fdb4:	mov    %rbx,%r14
  73fdb7:	jmp    73fe21 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0xd1>
  73fdb9:	xor    %r14d,%r14d
  73fdbc:	jmp    73fe21 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0xd1>
  73fdbe:	lea    0x1(%r14),%rax
  73fdc2:	cmp    %rbx,%rax
  73fdc5:	jae    73fe21 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0xd1>
  73fdc7:	sub    %r14,%r15
  73fdca:	jmp    73fdd9 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x89>
  73fdcc:	nopl   0x0(%rax)
  73fdd0:	add    $0x28,%r13
  73fdd4:	dec    %r15
  73fdd7:	je     73fe21 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0xd1>
  73fdd9:	mov    %rbp,%r12
  73fddc:	add    %r13,%r12
  73fddf:	mov    0x0(%rbp,%r13,1),%rsi
  73fde4:	mov    0x10(%rsp),%rdi
  73fde9:	call   75e1e0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_>
  73fdee:	cmp    $0x1,%rax
  73fdf2:	jne    73fdd0 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x80>
  73fdf4:	mov    %edx,0x24(%rbp,%r13,1)
  73fdf9:	lea    (%r14,%r14,4),%rax
  73fdfd:	mov    0x20(%r12),%rcx
  73fe02:	mov    %rcx,0x20(%rbp,%rax,8)
  73fe07:	movups (%r12),%xmm0
  73fe0c:	movups 0x10(%r12),%xmm1
  73fe12:	movups %xmm1,0x10(%rbp,%rax,8)
  73fe17:	movups %xmm0,0x0(%rbp,%rax,8)
  73fe1c:	inc    %r14
  73fe1f:	jmp    73fdd0 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x80>
  73fe21:	mov    0x8(%rsp),%rax
  73fe26:	mov    0x28(%rax),%rbp
  73fe2a:	test   %rbp,%rbp
  73fe2d:	mov    %r14,0x20(%rsp)
  73fe32:	je     73fe79 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x129>
  73fe34:	mov    0x20(%rax),%r13
  73fe38:	lea    -0x1(%rbp),%r15
  73fe3c:	mov    $0x40,%ebx
  73fe41:	xor    %r12d,%r12d
  73fe44:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  73fe50:	mov    -0x10(%r13,%rbx,1),%rsi
  73fe55:	mov    0x10(%rsp),%rdi
  73fe5a:	call   75e1e0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_>
  73fe5f:	test   $0x1,%al
  73fe61:	je     73fe7e <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x12e>
  73fe63:	mov    %edx,-0x8(%r13,%rbx,1)
  73fe68:	inc    %r12
  73fe6b:	add    $0x40,%rbx
  73fe6f:	cmp    %r12,%rbp
  73fe72:	jne    73fe50 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x100>
  73fe74:	mov    %rbp,%r12
  73fe77:	jmp    73fef1 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x1a1>
  73fe79:	xor    %r12d,%r12d
  73fe7c:	jmp    73fef1 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x1a1>
  73fe7e:	lea    0x1(%r12),%rax
  73fe83:	cmp    %rbp,%rax
  73fe86:	jae    73fef1 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x1a1>
  73fe88:	sub    %r12,%r15
  73fe8b:	jmp    73fe9c <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x14c>
  73fe8d:	nopl   (%rax)
  73fe90:	mov    %r14,%rbp
  73fe93:	add    $0x40,%rbx
  73fe97:	dec    %r15
  73fe9a:	je     73fef1 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x1a1>
  73fe9c:	mov    %rbp,%r14
  73fe9f:	lea    (%rbx,%r13,1),%rbp
  73fea3:	mov    0x30(%r13,%rbx,1),%rsi
  73fea8:	mov    0x10(%rsp),%rdi
  73fead:	call   75e1e0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_>
  73feb2:	cmp    $0x1,%rax
  73feb6:	jne    73fe90 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x140>
  73feb8:	mov    %edx,0x38(%r13,%rbx,1)
  73febd:	mov    %r12,%rax
  73fec0:	shl    $0x6,%rax
  73fec4:	movups 0x0(%rbp),%xmm0
  73fec8:	movups 0x10(%rbp),%xmm1
  73fecc:	movups 0x20(%rbp),%xmm2
  73fed0:	movups 0x30(%rbp),%xmm3
  73fed4:	movups %xmm3,0x30(%r13,%rax,1)
  73feda:	movups %xmm2,0x20(%r13,%rax,1)
  73fee0:	movups %xmm1,0x10(%r13,%rax,1)
  73fee6:	movups %xmm0,0x0(%r13,%rax,1)
  73feec:	inc    %r12
  73feef:	jmp    73fe90 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x140>
  73fef1:	mov    0x20(%rsp),%r14
  73fef6:	test   %r14,%r14
  73fef9:	je     73ff60 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x210>
  73fefb:	test   %r12,%r12
  73fefe:	je     73ffba <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x26a>
  73ff04:	mov    0x8(%rsp),%rcx
  73ff09:	mov    (%rcx),%rax
  73ff0c:	mov    0x8(%rcx),%rbx
  73ff10:	cmp    %r14,%rax
  73ff13:	jbe    740013 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x2c3>
  73ff19:	shl    $0x3,%rax
  73ff1d:	lea    (%rax,%rax,4),%r13
  73ff21:	lea    0x0(,%r14,8),%rax
  73ff29:	lea    (%rax,%rax,4),%rbp
  73ff2d:	mov    $0x8,%edx
  73ff32:	mov    %rbx,%rdi
  73ff35:	mov    %r13,%rsi
  73ff38:	mov    %rbp,%rcx
  73ff3b:	call   *0x37a3e7(%rip)        # aba328 <_DYNAMIC+0x2e8>
  73ff41:	mov    %rax,%r15
  73ff44:	test   %rax,%rax
  73ff47:	jne    740016 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x2c6>
  73ff4d:	mov    $0x8,%edi
  73ff52:	mov    %rbp,%rsi
  73ff55:	call   *0x37a3d5(%rip)        # aba330 <_DYNAMIC+0x2f0>
  73ff5b:	jmp    74017e <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x42e>
  73ff60:	test   %r12,%r12
  73ff63:	je     7400bb <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x36b>
  73ff69:	mov    0x8(%rsp),%r14
  73ff6e:	mov    0x18(%r14),%r15
  73ff72:	mov    0x20(%r14),%rbx
  73ff76:	cmp    %r12,%r15
  73ff79:	jbe    7400d4 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x384>
  73ff7f:	shl    $0x6,%r15
  73ff83:	mov    %r12,%r13
  73ff86:	shl    $0x6,%r13
  73ff8a:	mov    $0x8,%edx
  73ff8f:	mov    %rbx,%rdi
  73ff92:	mov    %r15,%rsi
  73ff95:	mov    %r13,%rcx
  73ff98:	call   *0x37a38a(%rip)        # aba328 <_DYNAMIC+0x2e8>
  73ff9e:	test   %rax,%rax
  73ffa1:	jne    7400d7 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x387>
  73ffa7:	mov    $0x8,%edi
  73ffac:	mov    %r13,%rsi
  73ffaf:	call   *0x37a37b(%rip)        # aba330 <_DYNAMIC+0x2f0>
  73ffb5:	jmp    74017e <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x42e>
  73ffba:	mov    0x8(%rsp),%rcx
  73ffbf:	mov    (%rcx),%rax
  73ffc2:	mov    0x8(%rcx),%r15
  73ffc6:	cmp    %r14,%rax
  73ffc9:	jbe    74013a <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x3ea>
  73ffcf:	shl    $0x3,%rax
  73ffd3:	lea    (%rax,%rax,4),%r12
  73ffd7:	lea    0x0(,%r14,8),%rax
  73ffdf:	lea    (%rax,%rax,4),%r13
  73ffe3:	mov    $0x8,%edx
  73ffe8:	mov    %r15,%rdi
  73ffeb:	mov    %r12,%rsi
  73ffee:	mov    %r13,%rcx
  73fff1:	call   *0x37a331(%rip)        # aba328 <_DYNAMIC+0x2e8>
  73fff7:	test   %rax,%rax
  73fffa:	jne    74013d <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x3ed>
  740000:	mov    $0x8,%edi
  740005:	mov    %r13,%rsi
  740008:	call   *0x37a322(%rip)        # aba330 <_DYNAMIC+0x2f0>
  74000e:	jmp    74017e <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x42e>
  740013:	mov    %rbx,%r15
  740016:	mov    0x8(%rsp),%rax
  74001b:	mov    0x18(%rax),%rbp
  74001f:	mov    0x20(%rax),%rbx
  740023:	cmp    %r12,%rbp
  740026:	jbe    74005f <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x30f>
  740028:	shl    $0x6,%rbp
  74002c:	mov    %r12,%r13
  74002f:	shl    $0x6,%r13
  740033:	mov    $0x8,%edx
  740038:	mov    %rbx,%rdi
  74003b:	mov    %rbp,%rsi
  74003e:	mov    %r13,%rcx
  740041:	call   *0x37a2e1(%rip)        # aba328 <_DYNAMIC+0x2e8>
  740047:	test   %rax,%rax
  74004a:	jne    740062 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x312>
  74004c:	mov    $0x8,%edi
  740051:	mov    %r13,%rsi
  740054:	call   *0x37a2d6(%rip)        # aba330 <_DYNAMIC+0x2f0>
  74005a:	jmp    74017e <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x42e>
  74005f:	mov    %rbx,%rax
  740062:	mov    %r15,0x28(%rsp)
  740067:	mov    %r14,0x30(%rsp)
  74006c:	mov    %rax,0x38(%rsp)
  740071:	mov    %r12,0x40(%rsp)
  740076:	call   *0x37a20c(%rip)        # aba288 <_DYNAMIC+0x248>
  74007c:	mov    $0x20,%edi
  740081:	mov    $0x8,%esi
  740086:	call   *0x37a204(%rip)        # aba290 <_DYNAMIC+0x250>
  74008c:	test   %rax,%rax
  74008f:	je     74016e <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x41e>
  740095:	movups 0x28(%rsp),%xmm0
  74009a:	movups 0x38(%rsp),%xmm1
  74009f:	movups %xmm1,0x10(%rax)
  7400a3:	movups %xmm0,(%rax)
  7400a6:	mov    0x18(%rsp),%rcx
  7400ab:	mov    %rax,0x8(%rcx)
  7400af:	movq   $0x3,(%rcx)
  7400b6:	jmp    74015f <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x40f>
  7400bb:	xor    %eax,%eax
  7400bd:	mov    0x8(%rsp),%r14
  7400c2:	mov    0x18(%rsp),%rcx
  7400c7:	mov    %rax,(%rcx)
  7400ca:	mov    (%r14),%rax
  7400cd:	test   %rax,%rax
  7400d0:	jne    7400f4 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x3a4>
  7400d2:	jmp    74010b <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x3bb>
  7400d4:	mov    %rbx,%rax
  7400d7:	mov    0x18(%rsp),%rcx
  7400dc:	mov    %rax,0x8(%rcx)
  7400e0:	mov    %r12,0x10(%rcx)
  7400e4:	mov    $0x2,%eax
  7400e9:	mov    %rax,(%rcx)
  7400ec:	mov    (%r14),%rax
  7400ef:	test   %rax,%rax
  7400f2:	je     74010b <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x3bb>
  7400f4:	mov    0x8(%r14),%rdi
  7400f8:	shl    $0x3,%rax
  7400fc:	lea    (%rax,%rax,4),%rsi
  740100:	mov    $0x8,%edx
  740105:	call   *0x37a175(%rip)        # aba280 <_DYNAMIC+0x240>
  74010b:	test   %r12,%r12
  74010e:	jne    74015f <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x40f>
  740110:	mov    0x18(%r14),%rsi
  740114:	test   %rsi,%rsi
  740117:	je     74015f <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x40f>
  740119:	mov    0x20(%r14),%rdi
  74011d:	shl    $0x6,%rsi
  740121:	mov    $0x8,%edx
  740126:	add    $0x48,%rsp
  74012a:	pop    %rbx
  74012b:	pop    %r12
  74012d:	pop    %r13
  74012f:	pop    %r14
  740131:	pop    %r15
  740133:	pop    %rbp
  740134:	jmp    *0x37a146(%rip)        # aba280 <_DYNAMIC+0x240>
  74013a:	mov    %r15,%rax
  74013d:	mov    0x18(%rsp),%rcx
  740142:	mov    %rax,0x8(%rcx)
  740146:	mov    %r14,0x10(%rcx)
  74014a:	movq   $0x1,(%rcx)
  740151:	mov    0x8(%rsp),%r14
  740156:	mov    0x18(%r14),%rsi
  74015a:	test   %rsi,%rsi
  74015d:	jne    740119 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x3c9>
  74015f:	add    $0x48,%rsp
  740163:	pop    %rbx
  740164:	pop    %r12
  740166:	pop    %r13
  740168:	pop    %r14
  74016a:	pop    %r15
  74016c:	pop    %rbp
  74016d:	ret
  74016e:	mov    $0x8,%edi
  740173:	mov    $0x20,%esi
  740178:	call   *0x37a11a(%rip)        # aba298 <_DYNAMIC+0x258>
  74017e:	ud2
  740180:	mov    %rax,%r14
  740183:	mov    $0x8,%edx
  740188:	mov    %r15,%rdi
  74018b:	mov    %r12,%rsi
  74018e:	jmp    7401ee <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x49e>
  740190:	mov    %rax,0x10(%rsp)
  740195:	mov    $0x8,%edx
  74019a:	mov    %rbx,%rdi
  74019d:	mov    %r15,%rsi
  7401a0:	call   *0x37a0da(%rip)        # aba280 <_DYNAMIC+0x240>
  7401a6:	xor    %ebx,%ebx
  7401a8:	jmp    74024a <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x4fa>
  7401ad:	mov    %rax,%r13
  7401b0:	mov    0x37a0c9(%rip),%r12        # aba280 <_DYNAMIC+0x240>
  7401b7:	mov    $0x8,%edx
  7401bc:	mov    %rbx,%rdi
  7401bf:	mov    %rbp,%rsi
  7401c2:	call   *%r12
  7401c5:	shl    $0x3,%r14
  7401c9:	lea    (%r14,%r14,4),%rsi
  7401cd:	mov    $0x8,%edx
  7401d2:	mov    %r15,%rdi
  7401d5:	call   *%r12
  7401d8:	mov    %r13,%rdi
  7401db:	call   a98730 <_Unwind_Resume@plt>
  7401e0:	mov    %rax,%r14
  7401e3:	mov    $0x8,%edx
  7401e8:	mov    %rbx,%rdi
  7401eb:	mov    %r13,%rsi
  7401ee:	call   *0x37a08c(%rip)        # aba280 <_DYNAMIC+0x240>
  7401f4:	jmp    74027c <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x52c>
  7401f9:	mov    %rax,0x10(%rsp)
  7401fe:	shl    $0x6,%r12
  740202:	add    %r12,%r13
  740205:	shl    $0x6,%r14
  740209:	sub    %rbx,%r14
  74020c:	mov    %r13,%rdi
  74020f:	mov    %rbp,%rsi
  740212:	mov    %r14,%rdx
  740215:	jmp    740239 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x4e9>
  740217:	mov    %rax,0x10(%rsp)
  74021c:	lea    (%r14,%r14,4),%rax
  740220:	lea    0x0(,%rax,8),%rdi
  740228:	add    %rbp,%rdi
  74022b:	shl    $0x3,%rbx
  74022f:	lea    (%rbx,%rbx,4),%rdx
  740233:	sub    %r13,%rdx
  740236:	mov    %r12,%rsi
  740239:	call   *0x37a0b1(%rip)        # aba2f0 <memmove@GLIBC_2.2.5>
  74023f:	jmp    740248 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x4f8>
  740241:	jmp    740243 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x4f3>
  740243:	mov    %rax,0x10(%rsp)
  740248:	mov    $0x1,%bl
  74024a:	mov    0x8(%rsp),%rax
  74024f:	mov    (%rax),%rax
  740252:	test   %rax,%rax
  740255:	je     740273 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x523>
  740257:	mov    0x8(%rsp),%rcx
  74025c:	mov    0x8(%rcx),%rdi
  740260:	shl    $0x3,%rax
  740264:	lea    (%rax,%rax,4),%rsi
  740268:	mov    $0x8,%edx
  74026d:	call   *0x37a00d(%rip)        # aba280 <_DYNAMIC+0x240>
  740273:	test   %bl,%bl
  740275:	mov    0x10(%rsp),%r14
  74027a:	je     7402b7 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x567>
  74027c:	mov    0x8(%rsp),%rax
  740281:	mov    0x18(%rax),%rsi
  740285:	test   %rsi,%rsi
  740288:	je     7402b7 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_+0x567>
  74028a:	mov    0x8(%rsp),%rax
  74028f:	mov    0x20(%rax),%rdi
  740293:	shl    $0x6,%rsi
  740297:	mov    $0x8,%edx
  74029c:	call   *0x379fde(%rip)        # aba280 <_DYNAMIC+0x240>
  7402a2:	mov    %r14,%rdi
  7402a5:	call   a98730 <_Unwind_Resume@plt>
  7402aa:	mov    %rax,%r14
  7402ad:	lea    0x28(%rsp),%rdi
  7402b2:	call   74e960 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime6scroll7ColumnsECs9C2G9YFESsD_29canonical_text_public_control>
  7402b7:	mov    %r14,%rdi
  7402ba:	call   a98730 <_Unwind_Resume@plt>

core::panicking::assert_failed::<gpui_canvas::text::layout::TextPosition, gpui_canvas::text::layout::TextPosition> bytes=50 frame=40

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000074f593 <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextPositionBM_ECs9C2G9YFESsD_29canonical_text_public_control>:
  74f593:	sub    $0x28,%rsp
  74f597:	lea    0x18(%rsp),%rax
  74f59c:	mov    %rdi,(%rax)
  74f59f:	lea    0x20(%rsp),%rcx
  74f5a4:	mov    %rsi,(%rcx)
  74f5a7:	mov    %rdx,0x8(%rsp)
  74f5ac:	lea    0x34a7fd(%rip),%rdx        # a99db0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2c8>
  74f5b3:	push   $0x1
  74f5b5:	pop    %rdi
  74f5b6:	mov    %rax,%rsi
  74f5b9:	mov    %rdx,%r8
  74f5bc:	xor    %r9d,%r9d
  74f5bf:	call   *0x36ae43(%rip)        # aba408 <_DYNAMIC+0x3c8>

core::panicking::assert_failed::<gpui_canvas::text::layout::TextSelection, gpui_canvas::text::layout::TextSelection> bytes=56 frame=40

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000074f5c5 <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout13TextSelectionBM_ECs9C2G9YFESsD_29canonical_text_public_control>:
  74f5c5:	sub    $0x28,%rsp
  74f5c9:	lea    0x18(%rsp),%rax
  74f5ce:	mov    %rdi,(%rax)
  74f5d1:	lea    0x20(%rsp),%rcx
  74f5d6:	mov    %rsi,(%rcx)
  74f5d9:	lea    0x34b270(%rip),%rdx        # a9a850 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xd68>
  74f5e0:	mov    %rdx,0x8(%rsp)
  74f5e5:	lea    0x34a7e4(%rip),%rdx        # a99dd0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2e8>
  74f5ec:	xor    %edi,%edi
  74f5ee:	mov    %rax,%rsi
  74f5f1:	mov    %rdx,%r8
  74f5f4:	xor    %r9d,%r9d
  74f5f7:	call   *0x36ae0b(%rip)        # aba408 <_DYNAMIC+0x3c8>

core::panicking::assert_failed::<(alloc::string::String, gpui_canvas::text::layout::TextSelection, *const gpui_canvas::text::layout::TextGeometry, u64), (alloc::string::String, gpui_canvas::text::layout::TextSelection, *const gpui_canvas::text::layout::TextGeometry, u64)> bytes=56 frame=40

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000074f676 <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedTNtNtCscdodAO9FK5_5alloc6string6StringNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout13TextSelectionPNtB1q_12TextGeometryyEBM_ECs9C2G9YFESsD_29canonical_text_public_control>:
  74f676:	sub    $0x28,%rsp
  74f67a:	lea    0x18(%rsp),%rax
  74f67f:	mov    %rdi,(%rax)
  74f682:	lea    0x20(%rsp),%rcx
  74f687:	mov    %rsi,(%rcx)
  74f68a:	lea    0x34b177(%rip),%rdx        # a9a808 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xd20>
  74f691:	mov    %rdx,0x8(%rsp)
  74f696:	lea    0x34a793(%rip),%rdx        # a99e30 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x348>
  74f69d:	xor    %edi,%edi
  74f69f:	mov    %rax,%rsi
  74f6a2:	mov    %rdx,%r8
  74f6a5:	xor    %r9d,%r9d
  74f6a8:	call   *0x36ad5a(%rip)        # aba408 <_DYNAMIC+0x3c8>

core::panicking::assert_failed::<(*const gpui_canvas::text::layout::TextGeometry, u64), (*const gpui_canvas::text::layout::TextGeometry, u64)> bytes=56 frame=40

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000074f6ae <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedTPNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryyEBM_ECs9C2G9YFESsD_29canonical_text_public_control>:
  74f6ae:	sub    $0x28,%rsp
  74f6b2:	lea    0x18(%rsp),%rax
  74f6b7:	mov    %rdi,(%rax)
  74f6ba:	lea    0x20(%rsp),%rcx
  74f6bf:	mov    %rsi,(%rcx)
  74f6c2:	lea    0x34b19f(%rip),%rdx        # a9a868 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xd80>
  74f6c9:	mov    %rdx,0x8(%rsp)
  74f6ce:	lea    0x34a77b(%rip),%rdx        # a99e50 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x368>
  74f6d5:	xor    %edi,%edi
  74f6d7:	mov    %rax,%rsi
  74f6da:	mov    %rdx,%r8
  74f6dd:	xor    %r9d,%r9d
  74f6e0:	call   *0x36ad22(%rip)        # aba408 <_DYNAMIC+0x3c8>

canonical_text_public_control::old_p_oracle::{closure#0} bytes=800 frame=296

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075cb80 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_>:
  75cb80:	push   %rbp
  75cb81:	push   %r15
  75cb83:	push   %r14
  75cb85:	push   %r13
  75cb87:	push   %r12
  75cb89:	push   %rbx
  75cb8a:	sub    $0xf8,%rsp
  75cb91:	test   %rsi,%rsi
  75cb94:	je     75cdf8 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x278>
  75cb9a:	cmpb   $0x0,0x76e(%rsi)
  75cba1:	jne    75cdff <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x27f>
  75cba7:	cmpb   $0x1,0x76c(%rsi)
  75cbae:	jne    75ce06 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x286>
  75cbb4:	mov    %rdi,%r14
  75cbb7:	mov    $0xffffffffffffffff,%rbx
  75cbbe:	lea    0x78(%rsp),%rdi
  75cbc3:	call   73de20 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime5queryNtB3_7Context3newNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEBX_>
  75cbc8:	mov    %r14,0x38(%rsp)
  75cbcd:	mov    0xb0(%rsp),%rax
  75cbd5:	mov    %rax,0x48(%rsp)
  75cbda:	test   %rax,%rax
  75cbdd:	je     75cdeb <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x26b>
  75cbe3:	movq   $0xffffffffffffffff,0x8(%rsp)
  75cbec:	mov    $0x3d,%ebx
  75cbf1:	xor    %ebp,%ebp
  75cbf3:	jmp    75cc18 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x98>
  75cbf5:	data16 cs nopw 0x0(%rax,%rax,1)
  75cc00:	mov    %r14,%r13
  75cc03:	inc    %rbp
  75cc06:	add    $0x40,%rbx
  75cc0a:	mov    %r13,%r14
  75cc0d:	cmp    %rbp,0x48(%rsp)
  75cc12:	je     75cd36 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x1b6>
  75cc18:	mov    0xb0(%rsp),%rsi
  75cc20:	cmp    %rsi,%rbp
  75cc23:	jae    75cdab <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x22b>
  75cc29:	mov    0xa8(%rsp),%rax
  75cc31:	cmpb   $0x4,(%rax,%rbx,1)
  75cc35:	jne    75cc00 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x80>
  75cc37:	mov    -0x15(%rax,%rbx,1),%r15
  75cc3c:	test   %r15,%r15
  75cc3f:	je     75cdc2 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x242>
  75cc45:	mov    (%r15),%r12
  75cc48:	shr    $1,%r12
  75cc4b:	je     75cc82 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x102>
  75cc4d:	call   *0x35d635(%rip)        # aba288 <_DYNAMIC+0x248>
  75cc53:	mov    $0x1,%esi
  75cc58:	mov    %r12,%rdi
  75cc5b:	call   *0x35d62f(%rip)        # aba290 <_DYNAMIC+0x250>
  75cc61:	test   %rax,%rax
  75cc64:	je     75cdd6 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x256>
  75cc6a:	mov    %rax,%r13
  75cc6d:	add    $0x10,%r15
  75cc71:	mov    %rax,%rdi
  75cc74:	mov    %r15,%rsi
  75cc77:	mov    %r12,%rdx
  75cc7a:	call   *0x35d620(%rip)        # aba2a0 <memcpy@GLIBC_2.14>
  75cc80:	jmp    75cc88 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x108>
  75cc82:	mov    $0x1,%r13d
  75cc88:	lea    0x18(%rsp),%rdi
  75cc8d:	lea    0x78(%rsp),%rsi
  75cc92:	mov    %rbp,%rdx
  75cc95:	call   *0x35d7e5(%rip)        # aba480 <_DYNAMIC+0x440>
  75cc9b:	cmpb   $0x2,0x24(%rsp)
  75cca0:	je     75cd82 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x202>
  75cca6:	movups 0x18(%rsp),%xmm0
  75ccab:	movaps %xmm0,0x60(%rsp)
  75ccb0:	lea    0x18(%rsp),%rdi
  75ccb5:	lea    0x78(%rsp),%rsi
  75ccba:	mov    %rbp,%rdx
  75ccbd:	call   *0x35d7c5(%rip)        # aba488 <_DYNAMIC+0x448>
  75ccc3:	cmpq   $0x0,0x18(%rsp)
  75ccc9:	je     75cd8b <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x20b>
  75cccf:	mov    0x28(%rsp),%rax
  75ccd4:	mov    %rax,0x40(%rsp)
  75ccd9:	lea    0x18(%rsp),%rdi
  75ccde:	lea    0x78(%rsp),%rsi
  75cce3:	mov    %rbp,%rdx
  75cce6:	call   *0x35d79c(%rip)        # aba488 <_DYNAMIC+0x448>
  75ccec:	cmpq   $0x0,0x18(%rsp)
  75ccf2:	je     75cd94 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x214>
  75ccf8:	mov    0x28(%rsp),%rdi
  75ccfd:	call   7602a0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript>
  75cd02:	mov    %rax,%r15
  75cd05:	movaps 0x60(%rsp),%xmm0
  75cd0a:	movaps %xmm0,0x50(%rsp)
  75cd0f:	mov    0x8(%rsp),%rsi
  75cd14:	test   %rsi,%rsi
  75cd17:	jle    75cd27 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x1a7>
  75cd19:	mov    $0x1,%edx
  75cd1e:	mov    %r14,%rdi
  75cd21:	call   *0x35d559(%rip)        # aba280 <_DYNAMIC+0x240>
  75cd27:	mov    %r13,0x10(%rsp)
  75cd2c:	mov    %r12,0x8(%rsp)
  75cd31:	jmp    75cc03 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x83>
  75cd36:	mov    0x8(%rsp),%rax
  75cd3b:	cmp    $0xffffffffffffffff,%rax
  75cd3f:	je     75cdeb <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x26b>
  75cd45:	mov    0x38(%rsp),%rcx
  75cd4a:	mov    %rax,(%rcx)
  75cd4d:	mov    0x10(%rsp),%rax
  75cd52:	mov    %rax,0x8(%rcx)
  75cd56:	mov    %r12,0x10(%rcx)
  75cd5a:	movaps 0x50(%rsp),%xmm0
  75cd5f:	movups %xmm0,0x18(%rcx)
  75cd63:	mov    0x40(%rsp),%rax
  75cd68:	mov    %rax,0x28(%rcx)
  75cd6c:	mov    %r15,0x30(%rcx)
  75cd70:	add    $0xf8,%rsp
  75cd77:	pop    %rbx
  75cd78:	pop    %r12
  75cd7a:	pop    %r13
  75cd7c:	pop    %r14
  75cd7e:	pop    %r15
  75cd80:	pop    %rbp
  75cd81:	ret
  75cd82:	lea    0x33d2af(%rip),%rdi        # a9a038 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x550>
  75cd89:	jmp    75cd9b <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x21b>
  75cd8b:	lea    0x33d2be(%rip),%rdi        # a9a050 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x568>
  75cd92:	jmp    75cd9b <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x21b>
  75cd94:	lea    0x33d2cd(%rip),%rdi        # a9a068 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x580>
  75cd9b:	mov    0x8(%rsp),%rbx
  75cda0:	call   *0x35d59a(%rip)        # aba340 <_DYNAMIC+0x300>
  75cda6:	jmp    75ce41 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x2c1>
  75cdab:	lea    0x33d256(%rip),%rdx        # a9a008 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x520>
  75cdb2:	mov    %rbp,%rdi
  75cdb5:	mov    0x8(%rsp),%rbx
  75cdba:	call   *0x35d4f0(%rip)        # aba2b0 <_DYNAMIC+0x270>
  75cdc0:	jmp    75ce41 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x2c1>
  75cdc2:	lea    0x33d257(%rip),%rdi        # a9a020 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x538>
  75cdc9:	mov    0x8(%rsp),%rbx
  75cdce:	call   *0x35d56c(%rip)        # aba340 <_DYNAMIC+0x300>
  75cdd4:	jmp    75ce41 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x2c1>
  75cdd6:	mov    $0x1,%edi
  75cddb:	mov    %r12,%rsi
  75cdde:	mov    0x8(%rsp),%rbx
  75cde3:	call   *0x35d547(%rip)        # aba330 <_DYNAMIC+0x2f0>
  75cde9:	jmp    75ce41 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x2c1>
  75cdeb:	lea    0x33d2d6(%rip),%rdi        # a9a0c8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x5e0>
  75cdf2:	call   *0x35d548(%rip)        # aba340 <_DYNAMIC+0x300>
  75cdf8:	mov    $0xd,%eax
  75cdfd:	jmp    75ce0b <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x28b>
  75cdff:	mov    $0xe,%eax
  75ce04:	jmp    75ce0b <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x28b>
  75ce06:	mov    $0x12,%eax
  75ce0b:	mov    %rax,0x78(%rsp)
  75ce10:	movq   $0x0,0x80(%rsp)
  75ce1c:	lea    -0x68d179(%rip),%rdi        # cfcaa <GCC_except_table0+0xd8a2>
  75ce23:	lea    0x33df06(%rip),%rcx        # a9ad30 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1248>
  75ce2a:	lea    0x33d27f(%rip),%r8        # a9a0b0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x5c8>
  75ce31:	lea    0x78(%rsp),%rdx
  75ce36:	mov    $0x2b,%esi
  75ce3b:	call   *0x35d50f(%rip)        # aba350 <_DYNAMIC+0x310>
  75ce41:	ud2
  75ce43:	mov    %rax,%r14
  75ce46:	lea    0x78(%rsp),%rdi
  75ce4b:	call   74d810 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  75ce50:	mov    %r14,%rdi
  75ce53:	call   a98730 <_Unwind_Resume@plt>
  75ce58:	mov    %rax,%r14
  75ce5b:	jmp    75ce80 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x300>
  75ce5d:	mov    %rax,%r14
  75ce60:	mov    0x8(%rsp),%rbx
  75ce65:	jmp    75ce6a <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x2ea>
  75ce67:	mov    %rax,%r14
  75ce6a:	test   %r12,%r12
  75ce6d:	je     75ce80 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x300>
  75ce6f:	mov    $0x1,%edx
  75ce74:	mov    %r13,%rdi
  75ce77:	mov    %r12,%rsi
  75ce7a:	call   *0x35d400(%rip)        # aba280 <_DYNAMIC+0x240>
  75ce80:	mov    0x10(%rsp),%rdi
  75ce85:	test   %rbx,%rbx
  75ce88:	jle    75ce98 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_+0x318>
  75ce8a:	mov    $0x1,%edx
  75ce8f:	mov    %rbx,%rsi
  75ce92:	call   *0x35d3e8(%rip)        # aba280 <_DYNAMIC+0x240>
  75ce98:	mov    %r14,%rdi
  75ce9b:	call   a98730 <_Unwind_Resume@plt>

<gpui_canvas::text::layout::TextGeometry>::intervals::{closure#1} bytes=753 frame=104

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075d580 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control>:
  75d580:	push   %rbp
  75d581:	push   %r15
  75d583:	push   %r14
  75d585:	push   %r13
  75d587:	push   %r12
  75d589:	push   %rbx
  75d58a:	sub    $0x38,%rsp
  75d58e:	mov    (%rdx),%r15
  75d591:	mov    0x8(%rdx),%rcx
  75d595:	mov    0x10(%rdx),%r13
  75d599:	mov    0x18(%rdx),%rax
  75d59d:	shl    $0x2,%rcx
  75d5a1:	lea    (%rcx,%rcx,2),%rcx
  75d5a5:	xor    %edx,%edx
  75d5a7:	nopw   0x0(%rax,%rax,1)
  75d5b0:	cmp    %rdx,%rcx
  75d5b3:	je     75d6ae <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x12e>
  75d5b9:	lea    0xc(%rdx),%r12
  75d5bd:	testb  $0x2,0x8(%r15,%rdx,1)
  75d5c3:	mov    %r12,%rdx
  75d5c6:	je     75d5b0 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x30>
  75d5c8:	shl    $0x2,%rax
  75d5cc:	lea    (%rax,%rax,2),%rax
  75d5d0:	xor    %ecx,%ecx
  75d5d2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  75d5e0:	cmp    %rcx,%rax
  75d5e3:	je     75d6ae <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x12e>
  75d5e9:	lea    0xc(%rcx),%r14
  75d5ed:	testb  $0x1,0x8(%r13,%rcx,1)
  75d5f3:	mov    %r14,%rcx
  75d5f6:	je     75d5e0 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x60>
  75d5f8:	movaps %xmm0,0x20(%rsp)
  75d5fd:	mov    %rdi,%rbx
  75d600:	mov    -0xc(%r15,%r12,1),%eax
  75d605:	mov    %rsi,%rdi
  75d608:	mov    %rsi,%rbp
  75d60b:	mov    %eax,0xc(%rsp)
  75d60f:	mov    %eax,%esi
  75d611:	mov    $0x1,%edx
  75d616:	call   *0x35ce94(%rip)        # aba4b0 <_DYNAMIC+0x470>
  75d61c:	mov    0x28(%rbp),%rsi
  75d620:	cmp    %rsi,%rax
  75d623:	jae    75d851 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x2d1>
  75d629:	mov    %rbp,%rdi
  75d62c:	mov    -0xc(%r13,%r14,1),%r10d
  75d631:	mov    0x20(%rbp),%rcx
  75d635:	lea    (%rax,%rax,2),%r8
  75d639:	mov    0x4(%rcx,%r8,8),%r11d
  75d63e:	test   %rax,%rax
  75d641:	mov    %rbx,%rdx
  75d644:	movaps 0x20(%rsp),%xmm5
  75d649:	je     75d6b7 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x137>
  75d64b:	cmpl   $0x0,0xc(%rsp)
  75d650:	je     75d6b7 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x137>
  75d652:	movzbl -0x4(%r15,%r12,1),%r9d
  75d658:	and    $0x1,%r9b
  75d65c:	je     75d6b7 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x137>
  75d65e:	lea    (%rcx,%r8,8),%r8
  75d662:	mov    %rax,%rcx
  75d665:	mov    0xc(%rsp),%r9d
  75d66a:	cmp    %r9d,-0x14(%r8)
  75d66e:	jne    75d6ba <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x13a>
  75d670:	mov    0xc(%rsp),%esi
  75d674:	xor    %edx,%edx
  75d676:	mov    %rax,0x18(%rsp)
  75d67b:	mov    %r10d,0x14(%rsp)
  75d680:	mov    %r11d,0x10(%rsp)
  75d685:	call   *0x35ce25(%rip)        # aba4b0 <_DYNAMIC+0x470>
  75d68b:	mov    0x10(%rsp),%r11d
  75d690:	mov    0x14(%rsp),%r10d
  75d695:	movaps 0x20(%rsp),%xmm5
  75d69a:	mov    %rbp,%rdi
  75d69d:	mov    %rbx,%rdx
  75d6a0:	mov    %rax,%rcx
  75d6a3:	mov    0x18(%rsp),%rax
  75d6a8:	mov    0x28(%rbp),%rsi
  75d6ac:	jmp    75d6ba <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x13a>
  75d6ae:	movb   $0x2,0x4(%rdi)
  75d6b2:	jmp    75d823 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x2a3>
  75d6b7:	mov    %rax,%rcx
  75d6ba:	cmp    %rsi,%rcx
  75d6bd:	jae    75d861 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x2e1>
  75d6c3:	lea    (%rcx,%rcx,2),%rcx
  75d6c7:	shl    $0x3,%rcx
  75d6cb:	add    0x20(%rdi),%rcx
  75d6cf:	movss  -0x8(%r15,%r12,1),%xmm0
  75d6d6:	movss  -0x8(%r13,%r14,1),%xmm1
  75d6dd:	cmp    %r11d,%r10d
  75d6e0:	ja     75d6f5 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x175>
  75d6e2:	ucomiss %xmm1,%xmm0
  75d6e5:	jne    75d6e9 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x169>
  75d6e7:	jnp    75d6f5 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x175>
  75d6e9:	ucomiss %xmm0,%xmm1
  75d6ec:	setbe  %sil
  75d6f0:	jmp    75d7b1 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x231>
  75d6f5:	mov    %r11d,%r14d
  75d6f8:	mov    %r10d,%ebp
  75d6fb:	mov    0x8(%rdi),%rsi
  75d6ff:	mov    0x10(%rdi),%rdi
  75d703:	mov    %rdi,%r8
  75d706:	test   %rdi,%rdi
  75d709:	je     75d752 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x1d2>
  75d70b:	xor    %r8d,%r8d
  75d70e:	cmp    $0x1,%rdi
  75d712:	je     75d742 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x1c2>
  75d714:	mov    %rdi,%r9
  75d717:	nopw   0x0(%rax,%rax,1)
  75d720:	mov    %r9,%r10
  75d723:	shr    $1,%r10
  75d726:	lea    (%r10,%r8,1),%r11
  75d72a:	lea    (%r11,%r11,2),%rbx
  75d72e:	mov    0x10(%rsi,%rbx,8),%ebx
  75d732:	cmp    %rbx,%rax
  75d735:	cmova  %r11,%r8
  75d739:	sub    %r10,%r9
  75d73c:	cmp    $0x1,%r9
  75d740:	ja     75d720 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x1a0>
  75d742:	lea    (%r8,%r8,2),%r9
  75d746:	mov    0x10(%rsi,%r9,8),%r9d
  75d74b:	cmp    %rax,%r9
  75d74e:	adc    $0x0,%r8
  75d752:	shl    $0x3,%r8
  75d756:	lea    (%r8,%r8,2),%r8
  75d75a:	lea    (%rsi,%r8,1),%r10
  75d75e:	mov    -0xc(%r15,%r12,1),%r9d
  75d763:	shl    $0x3,%rdi
  75d767:	lea    (%rdi,%rdi,2),%rdi
  75d76b:	nopl   0x0(%rax,%rax,1)
  75d770:	cmp    %r8,%rdi
  75d773:	je     75d832 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x2b2>
  75d779:	mov    %r10,%r11
  75d77c:	mov    0x10(%r10),%r10d
  75d780:	cmp    %r10,%rax
  75d783:	jne    75d832 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x2b2>
  75d789:	lea    0x18(%r11),%r10
  75d78d:	add    $0x18,%r8
  75d791:	cmp    %r9d,(%r11)
  75d794:	ja     75d770 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x1f0>
  75d796:	cmp    0x4(%r11),%r9d
  75d79a:	ja     75d770 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x1f0>
  75d79c:	movzbl -0x3(%rsi,%r8,1),%esi
  75d7a2:	mov    %ebp,%r10d
  75d7a5:	mov    %r14d,%r11d
  75d7a8:	cmp    %r14d,%ebp
  75d7ab:	ja     75d843 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x2c3>
  75d7b1:	movaps %xmm0,%xmm3
  75d7b4:	minss  %xmm1,%xmm3
  75d7b8:	movaps %xmm3,%xmm2
  75d7bb:	cmpunordss %xmm3,%xmm2
  75d7c0:	movaps %xmm2,%xmm4
  75d7c3:	andnps %xmm3,%xmm4
  75d7c6:	andps  %xmm0,%xmm2
  75d7c9:	orps   %xmm4,%xmm2
  75d7cc:	movaps %xmm1,%xmm5
  75d7cf:	subss  %xmm0,%xmm5
  75d7d3:	andps  -0x69a2fa(%rip),%xmm5        # c34e0 <GCC_except_table0+0x10d8>
  75d7da:	cmp    %r11d,%r10d
  75d7dd:	movss  0x8(%rcx),%xmm3
  75d7e2:	movss  0xc(%rcx),%xmm4
  75d7e7:	mov    0xc(%rsp),%ecx
  75d7eb:	mov    %ecx,(%rdx)
  75d7ed:	movb   $0x1,0x4(%rdx)
  75d7f1:	mov    %r10d,0x8(%rdx)
  75d7f5:	movb   $0x0,0xc(%rdx)
  75d7f9:	movss  %xmm2,0x10(%rdx)
  75d7fe:	movss  %xmm3,0x14(%rdx)
  75d803:	movss  %xmm5,0x18(%rdx)
  75d808:	movss  %xmm4,0x1c(%rdx)
  75d80d:	mov    %rax,0x20(%rdx)
  75d811:	movss  %xmm0,0x28(%rdx)
  75d816:	movss  %xmm1,0x2c(%rdx)
  75d81b:	seta   0x30(%rdx)
  75d81f:	mov    %sil,0x31(%rdx)
  75d823:	add    $0x38,%rsp
  75d827:	pop    %rbx
  75d828:	pop    %r12
  75d82a:	pop    %r13
  75d82c:	pop    %r14
  75d82e:	pop    %r15
  75d830:	pop    %rbp
  75d831:	ret
  75d832:	xor    %esi,%esi
  75d834:	mov    %ebp,%r10d
  75d837:	mov    %r14d,%r11d
  75d83a:	cmp    %r14d,%ebp
  75d83d:	jbe    75d7b1 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x231>
  75d843:	movaps %xmm0,%xmm2
  75d846:	test   %sil,%sil
  75d849:	je     75d7da <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x25a>
  75d84b:	subss  %xmm5,%xmm2
  75d84f:	jmp    75d7da <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control+0x25a>
  75d851:	lea    0x33ca68(%rip),%rdx        # a9a2c0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x7d8>
  75d858:	mov    %rax,%rdi
  75d85b:	call   *0x35ca4f(%rip)        # aba2b0 <_DYNAMIC+0x270>
  75d861:	lea    0x33ca70(%rip),%rdx        # a9a2d8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x7f0>
  75d868:	mov    %rcx,%rdi
  75d86b:	call   *0x35ca3f(%rip)        # aba2b0 <_DYNAMIC+0x270>

<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::present_inner::{closure#9} bytes=1503 frame=248

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075d880 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_>:
  75d880:	push   %rbp
  75d881:	push   %r15
  75d883:	push   %r14
  75d885:	push   %r13
  75d887:	push   %r12
  75d889:	push   %rbx
  75d88a:	sub    $0xc8,%rsp
  75d891:	mov    %rcx,%r14
  75d894:	mov    %rsi,%r15
  75d897:	mov    (%rcx),%ecx
  75d899:	mov    0x10(%r14),%ebx
  75d89d:	test   %ebx,%ebx
  75d89f:	je     75d8c3 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x43>
  75d8a1:	cmp    $0x1,%ebx
  75d8a4:	jne    75da9a <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x21a>
  75d8aa:	movss  -0x69b22a(%rip),%xmm0        # c2688 <GCC_except_table0+0x280>
  75d8b2:	mov    %ebx,%ebp
  75d8b4:	movss  0x4(%r14),%xmm1
  75d8ba:	movaps %xmm1,%xmm2
  75d8bd:	test   %ecx,%ecx
  75d8bf:	je     75d8db <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x5b>
  75d8c1:	jmp    75d8de <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x5e>
  75d8c3:	movss  0x14(%r14),%xmm0
  75d8c9:	mov    $0x1,%ebp
  75d8ce:	movss  0x4(%r14),%xmm1
  75d8d4:	movaps %xmm1,%xmm2
  75d8d7:	test   %ecx,%ecx
  75d8d9:	jne    75d8de <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x5e>
  75d8db:	movaps %xmm0,%xmm2
  75d8de:	mov    $0x1,%eax
  75d8e3:	cmovne %eax,%ebp
  75d8e6:	mov    (%r15),%rax
  75d8e9:	mov    0x10(%rax),%rsi
  75d8ed:	test   %rsi,%rsi
  75d8f0:	je     75ddc1 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x541>
  75d8f6:	mov    %ecx,0x1c(%rsp)
  75d8fa:	mov    %rdi,0x10(%rsp)
  75d8ff:	mov    0x8(%rax),%rax
  75d903:	mov    (%rdx),%rcx
  75d906:	cmp    $0x1,%rsi
  75d90a:	jne    75d9d1 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x151>
  75d910:	xor    %r12d,%r12d
  75d913:	mov    %r12,%rdi
  75d916:	shl    $0x4,%rdi
  75d91a:	mov    (%rax,%rdi,1),%r8
  75d91e:	cmp    %rcx,%r8
  75d921:	seta   %sil
  75d925:	sbb    $0x0,%sil
  75d929:	cmp    %rcx,%r8
  75d92c:	jne    75d953 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0xd3>
  75d92e:	add    %rdi,%rax
  75d931:	mov    0x8(%rax),%ecx
  75d934:	mov    0x8(%rdx),%edi
  75d937:	cmp    %edi,%ecx
  75d939:	seta   %sil
  75d93d:	sbb    $0x0,%sil
  75d941:	cmp    %edi,%ecx
  75d943:	jne    75d953 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0xd3>
  75d945:	mov    0xc(%rax),%eax
  75d948:	cmp    0xc(%rdx),%eax
  75d94b:	seta   %sil
  75d94f:	sbb    $0x0,%sil
  75d953:	test   %sil,%sil
  75d956:	jne    75ddc6 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x546>
  75d95c:	movss  %xmm2,0x8(%rsp)
  75d962:	movss  %xmm1,0xc(%rsp)
  75d968:	mov    0x8(%r15),%rax
  75d96c:	mov    0x10(%rax),%rsi
  75d970:	cmp    %rsi,%r12
  75d973:	jae    75ddfc <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x57c>
  75d979:	mov    0x8(%rax),%rax
  75d97d:	lea    (%r12,%r12,4),%rcx
  75d981:	mov    0x20(%rax,%rcx,8),%r13d
  75d986:	mov    %r13d,%edi
  75d989:	call   *0x35cb29(%rip)        # aba4b8 <_DYNAMIC+0x478>
  75d98f:	cmp    $0x2,%dl
  75d992:	jne    75da29 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x1a9>
  75d998:	mov    0x18(%r15),%rdx
  75d99c:	cmpq   $0x0,(%rdx)
  75d9a0:	je     75dd75 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x4f5>
  75d9a6:	mov    %r13d,%eax
  75d9a9:	and    $0xf,%eax
  75d9ac:	cmp    $0x9,%eax
  75d9af:	ja     75dda8 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x528>
  75d9b5:	cmp    $0x6,%eax
  75d9b8:	je     75d9c4 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x144>
  75d9ba:	shr    $0x4,%r13d
  75d9be:	jne    75dac9 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x249>
  75d9c4:	lea    0x33ca5d(%rip),%rdi        # a9a428 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x940>
  75d9cb:	call   *0x35c96f(%rip)        # aba340 <_DYNAMIC+0x300>
  75d9d1:	mov    0x8(%rdx),%edi
  75d9d4:	mov    0xc(%rdx),%r8d
  75d9d8:	xor    %r9d,%r9d
  75d9db:	jmp    75d9f7 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x177>
  75d9dd:	nopl   (%rax)
  75d9e0:	test   %r13b,%r13b
  75d9e3:	cmovne %r9,%r12
  75d9e7:	sub    %r10,%rsi
  75d9ea:	mov    %r12,%r9
  75d9ed:	cmp    $0x1,%rsi
  75d9f1:	jbe    75d913 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x93>
  75d9f7:	mov    %rsi,%r10
  75d9fa:	shr    $1,%r10
  75d9fd:	lea    (%r10,%r9,1),%r12
  75da01:	mov    %r12,%r11
  75da04:	shl    $0x4,%r11
  75da08:	cmp    %rcx,(%rax,%r11,1)
  75da0c:	seta   %r13b
  75da10:	jne    75d9e0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x160>
  75da12:	add    %rax,%r11
  75da15:	cmp    %edi,0x8(%r11)
  75da19:	seta   %r13b
  75da1d:	jne    75d9e0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x160>
  75da1f:	cmp    %r8d,0xc(%r11)
  75da23:	seta   %r13b
  75da27:	jmp    75d9e0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x160>
  75da29:	mov    0x10(%r15),%rcx
  75da2d:	mov    (%rcx),%rcx
  75da30:	test   %rcx,%rcx
  75da33:	je     75dd8e <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x50e>
  75da39:	mov    %eax,%edi
  75da3b:	mov    0x10(%rcx),%rsi
  75da3f:	cmp    %rdi,%rsi
  75da42:	jbe    75de0c <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x58c>
  75da48:	mov    0x8(%rcx),%rax
  75da4c:	mov    (%rax,%rdi,8),%rax
  75da50:	mov    0x30(%rax),%ecx
  75da53:	mov    0x34(%rax),%eax
  75da56:	xorps  %xmm0,%xmm0
  75da59:	cvtsi2ss %rcx,%xmm0
  75da5e:	xorps  %xmm1,%xmm1
  75da61:	cvtsi2ss %rax,%xmm1
  75da66:	movaps %xmm0,%xmm2
  75da69:	divss  %xmm1,%xmm2
  75da6d:	movzbl 0x8(%r14),%ecx
  75da72:	movss  0xc(%r14),%xmm3
  75da78:	cmpb   $0x0,0x1c(%rsp)
  75da7d:	mov    0x10(%rsp),%rax
  75da82:	je     75dab2 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x232>
  75da84:	test   %cl,%cl
  75da86:	je     75db5c <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x2dc>
  75da8c:	movss  0xc(%rsp),%xmm0
  75da92:	movaps %xmm3,%xmm1
  75da95:	jmp    75db69 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x2e9>
  75da9a:	xor    %ebp,%ebp
  75da9c:	movss  0x4(%r14),%xmm1
  75daa2:	movaps %xmm1,%xmm2
  75daa5:	test   %ecx,%ecx
  75daa7:	je     75d8db <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x5b>
  75daad:	jmp    75d8de <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x5e>
  75dab2:	test   %cl,%cl
  75dab4:	je     75db69 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x2e9>
  75daba:	mulss  %xmm3,%xmm2
  75dabe:	movaps %xmm2,%xmm0
  75dac1:	movaps %xmm3,%xmm1
  75dac4:	jmp    75db69 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x2e9>
  75dac9:	mov    0x20(%r15),%rax
  75dacd:	mov    0x10(%rax),%rsi
  75dad1:	dec    %r13d
  75dad4:	cmp    %r13,%rsi
  75dad7:	jbe    75de19 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x599>
  75dadd:	mov    0x8(%rax),%rsi
  75dae1:	lea    0x0(%r13,%r13,4),%r13
  75dae6:	shl    $0x4,%r13
  75daea:	cmpq   $0xfffffffffffffffe,(%rsi,%r13,1)
  75daef:	je     75dd9b <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x51b>
  75daf5:	mov    0x28(%r15),%rcx
  75daf9:	mov    (%rcx),%rax
  75dafc:	lea    -0x699b03(%rip),%rdi        # c4000 <GCC_except_table0+0x1bf8>
  75db03:	movslq (%rdi,%rax,4),%rax
  75db07:	add    %rdi,%rax
  75db0a:	jmp    *%rax
  75db0c:	movups -0x699637(%rip),%xmm0        # c44dc <GCC_except_table0+0x20d4>
  75db13:	movaps %xmm0,0x60(%rsp)
  75db18:	movups -0x699653(%rip),%xmm0        # c44cc <GCC_except_table0+0x20c4>
  75db1f:	movaps %xmm0,0x50(%rsp)
  75db24:	movups -0x69966f(%rip),%xmm0        # c44bc <GCC_except_table0+0x20b4>
  75db2b:	movaps %xmm0,0x40(%rsp)
  75db30:	movups -0x69968b(%rip),%xmm0        # c44ac <GCC_except_table0+0x20a4>
  75db37:	movaps %xmm0,0x30(%rsp)
  75db3c:	movups -0x6996a7(%rip),%xmm0        # c449c <GCC_except_table0+0x2094>
  75db43:	movaps %xmm0,0x20(%rsp)
  75db48:	movabs $0x3000100000000,%rax
  75db52:	mov    %rax,0x70(%rsp)
  75db57:	jmp    75dc32 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x3b2>
  75db5c:	movss  0xc(%rsp),%xmm0
  75db62:	movaps %xmm0,%xmm1
  75db65:	divss  %xmm2,%xmm1
  75db69:	movss  %xmm0,0x10(%rax)
  75db6e:	movss  %xmm1,0x14(%rax)
  75db73:	xorps  %xmm0,%xmm0
  75db76:	movups %xmm0,(%rax)
  75db79:	jmp    75dd63 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x4e3>
  75db7e:	mov    0x20(%rcx),%rax
  75db82:	cmp    %rax,%r12
  75db85:	jae    75de29 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x5a9>
  75db8b:	mov    0x10(%rcx),%rax
  75db8f:	mov    0x18(%rcx),%rdi
  75db93:	movzbl (%rdi,%r12,1),%edi
  75db98:	cmp    %rdi,%rax
  75db9b:	jbe    75de4f <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x5cf>
  75dba1:	mov    0x8(%rcx),%rax
  75dba5:	imul   $0x58,%rdi,%rcx
  75dba9:	jmp    75dbf7 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x377>
  75dbab:	mov    0x8(%rcx),%rax
  75dbaf:	lea    0x20(%rsp),%rdi
  75dbb4:	mov    %rsi,0x88(%rsp)
  75dbbc:	mov    %rax,%rsi
  75dbbf:	mov    %rdx,0x80(%rsp)
  75dbc7:	mov    %r12,%rdx
  75dbca:	call   *0x35c860(%rip)        # aba430 <_DYNAMIC+0x3f0>
  75dbd0:	mov    0x88(%rsp),%rsi
  75dbd8:	mov    0x80(%rsp),%rdx
  75dbe0:	jmp    75dc32 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x3b2>
  75dbe2:	mov    0x18(%rcx),%rax
  75dbe6:	cmp    %rax,%r12
  75dbe9:	jae    75de3c <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x5bc>
  75dbef:	mov    0x10(%rcx),%rax
  75dbf3:	imul   $0x58,%r12,%rcx
  75dbf7:	mov    0x50(%rax,%rcx,1),%rdi
  75dbfc:	mov    %rdi,0x70(%rsp)
  75dc01:	movups 0x40(%rax,%rcx,1),%xmm0
  75dc06:	movaps %xmm0,0x60(%rsp)
  75dc0b:	movups (%rax,%rcx,1),%xmm0
  75dc0f:	movups 0x10(%rax,%rcx,1),%xmm1
  75dc14:	movups 0x20(%rax,%rcx,1),%xmm2
  75dc19:	movups 0x30(%rax,%rcx,1),%xmm3
  75dc1e:	movaps %xmm3,0x50(%rsp)
  75dc23:	movaps %xmm2,0x40(%rsp)
  75dc28:	movaps %xmm1,0x30(%rsp)
  75dc2d:	movaps %xmm0,0x20(%rsp)
  75dc32:	mov    0x10(%rsp),%r12
  75dc37:	movss  0x8(%rsp),%xmm1
  75dc3d:	add    %r13,%rsi
  75dc40:	movss  0x38(%rsp),%xmm0
  75dc46:	test   %ebx,%ebx
  75dc48:	sete   %al
  75dc4b:	mov    0x1c(%rsp),%ebx
  75dc4f:	or     %bl,%al
  75dc51:	movzbl %al,%r8d
  75dc55:	lea    0x90(%rsp),%rdi
  75dc5d:	mov    %ebp,%ecx
  75dc5f:	call   *0x35c85b(%rip)        # aba4c0 <_DYNAMIC+0x480>
  75dc65:	cmpl   $0xfffffffe,0x90(%rsp)
  75dc6d:	jne    75dcd2 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x452>
  75dc6f:	mov    0x98(%rsp),%rax
  75dc77:	movss  0x30(%rax),%xmm0
  75dc7c:	test   %bl,%bl
  75dc7e:	movss  0xc(%rsp),%xmm2
  75dc84:	jne    75dc8b <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x40b>
  75dc86:	movss  0x28(%rax),%xmm2
  75dc8b:	add    $0x2c,%rax
  75dc8f:	lea    0xc(%r14),%rcx
  75dc93:	cmpb   $0x0,0x8(%r14)
  75dc98:	cmove  %rax,%rcx
  75dc9c:	movss  (%rcx),%xmm1
  75dca0:	movss  %xmm2,0x10(%r12)
  75dca7:	movss  %xmm1,0x14(%r12)
  75dcae:	movl   $0x1,(%r12)
  75dcb6:	movss  %xmm0,0x4(%r12)
  75dcbd:	movl   $0x1,0x8(%r12)
  75dcc6:	movss  %xmm0,0xc(%r12)
  75dccd:	jmp    75dd60 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x4e0>
  75dcd2:	mov    0x30(%r15),%rbx
  75dcd6:	mov    (%rbx),%rax
  75dcd9:	cmp    $0xfffffffffffffffe,%rax
  75dcdd:	je     75dd20 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x4a0>
  75dcdf:	sub    $0xd,%rax
  75dce3:	mov    $0x14,%ecx
  75dce8:	cmovge %rax,%rcx
  75dcec:	cmp    $0x14,%rcx
  75dcf0:	je     75dd03 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x483>
  75dcf2:	cmp    $0x19,%rcx
  75dcf6:	jne    75dd20 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x4a0>
  75dcf8:	mov    0x8(%rbx),%rsi
  75dcfc:	mov    $0x10,%eax
  75dd01:	jmp    75dd0c <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x48c>
  75dd03:	mov    0x18(%rbx),%rsi
  75dd07:	mov    $0x20,%eax
  75dd0c:	test   %rsi,%rsi
  75dd0f:	je     75dd20 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x4a0>
  75dd11:	mov    (%rbx,%rax,1),%rdi
  75dd15:	mov    $0x1,%edx
  75dd1a:	call   *0x35c560(%rip)        # aba280 <_DYNAMIC+0x240>
  75dd20:	mov    0xc0(%rsp),%rax
  75dd28:	mov    %rax,0x30(%rbx)
  75dd2c:	movups 0x90(%rsp),%xmm0
  75dd34:	movups 0xa0(%rsp),%xmm1
  75dd3c:	movups 0xb0(%rsp),%xmm2
  75dd44:	movups %xmm2,0x20(%rbx)
  75dd48:	movups %xmm1,0x10(%rbx)
  75dd4c:	movups %xmm0,(%rbx)
  75dd4f:	xorps  %xmm0,%xmm0
  75dd52:	movups %xmm0,(%r12)
  75dd57:	movq   $0x0,0x10(%r12)
  75dd60:	mov    %r12,%rax
  75dd63:	add    $0xc8,%rsp
  75dd6a:	pop    %rbx
  75dd6b:	pop    %r12
  75dd6d:	pop    %r13
  75dd6f:	pop    %r14
  75dd71:	pop    %r15
  75dd73:	pop    %rbp
  75dd74:	ret
  75dd75:	lea    -0x68e383(%rip),%rdi        # cf9f9 <GCC_except_table0+0xd5f1>
  75dd7c:	lea    0x33c68d(%rip),%rdx        # a9a410 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x928>
  75dd83:	mov    $0x28,%esi
  75dd88:	call   *0x35c5ca(%rip)        # aba358 <_DYNAMIC+0x318>
  75dd8e:	lea    0x33c64b(%rip),%rdi        # a9a3e0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x8f8>
  75dd95:	call   *0x35c5a5(%rip)        # aba340 <_DYNAMIC+0x300>
  75dd9b:	lea    0x33c596(%rip),%rdi        # a9a338 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x850>
  75dda2:	call   *0x35c598(%rip)        # aba340 <_DYNAMIC+0x300>
  75dda8:	lea    -0x68b41f(%rip),%rdi        # d2990 <GCC_except_table0+0x10588>
  75ddaf:	lea    0x33d80a(%rip),%rdx        # a9b5c0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1ad8>
  75ddb6:	mov    $0x83,%esi
  75ddbb:	call   *0x35c4f7(%rip)        # aba2b8 <_DYNAMIC+0x278>
  75ddc1:	xor    %r12d,%r12d
  75ddc4:	jmp    75ddd2 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_+0x552>
  75ddc6:	xor    %eax,%eax
  75ddc8:	cmp    $0xff,%sil
  75ddcc:	sete   %al
  75ddcf:	add    %rax,%r12
  75ddd2:	mov    %r12,0x20(%rsp)
  75ddd7:	lea    -0x68e419(%rip),%rdi        # cf9c5 <GCC_except_table0+0xd5bd>
  75ddde:	lea    0x33d02b(%rip),%rcx        # a9ae10 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1328>
  75dde5:	lea    0x33c5c4(%rip),%r8        # a9a3b0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x8c8>
  75ddec:	lea    0x20(%rsp),%rdx
  75ddf1:	mov    $0x34,%esi
  75ddf6:	call   *0x35c554(%rip)        # aba350 <_DYNAMIC+0x310>
  75ddfc:	lea    0x33c5c5(%rip),%rdx        # a9a3c8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x8e0>
  75de03:	mov    %r12,%rdi
  75de06:	call   *0x35c4a4(%rip)        # aba2b0 <_DYNAMIC+0x270>
  75de0c:	lea    0x33c5e5(%rip),%rdx        # a9a3f8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x910>
  75de13:	call   *0x35c497(%rip)        # aba2b0 <_DYNAMIC+0x270>
  75de19:	lea    0x33c500(%rip),%rdx        # a9a320 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x838>
  75de20:	mov    %r13,%rdi
  75de23:	call   *0x35c487(%rip)        # aba2b0 <_DYNAMIC+0x270>
  75de29:	lea    0x33d0c0(%rip),%rdx        # a9aef0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1408>
  75de30:	mov    %r12,%rdi
  75de33:	mov    %rax,%rsi
  75de36:	call   *0x35c474(%rip)        # aba2b0 <_DYNAMIC+0x270>
  75de3c:	lea    0x33d095(%rip),%rdx        # a9aed8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x13f0>
  75de43:	mov    %r12,%rdi
  75de46:	mov    %rax,%rsi
  75de49:	call   *0x35c461(%rip)        # aba2b0 <_DYNAMIC+0x270>
  75de4f:	lea    0x33d0b2(%rip),%rdx        # a9af08 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1420>
  75de56:	mov    %rax,%rsi
  75de59:	call   *0x35c451(%rip)        # aba2b0 <_DYNAMIC+0x270>

<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::present_inner::{closure#41} bytes=884 frame=136

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075de60 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_>:
  75de60:	push   %rbp
  75de61:	push   %r15
  75de63:	push   %r14
  75de65:	push   %r13
  75de67:	push   %r12
  75de69:	push   %rbx
  75de6a:	sub    $0x58,%rsp
  75de6e:	mov    (%rsi),%rax
  75de71:	mov    0x10(%rax),%rcx
  75de75:	mov    %rcx,0x10(%rsp)
  75de7a:	movups (%rax),%xmm0
  75de7d:	movaps %xmm0,(%rsp)
  75de81:	movq   $0x0,(%rax)
  75de88:	movq   $0x4,0x8(%rax)
  75de90:	movq   $0x0,0x10(%rax)
  75de98:	mov    0x8(%rsi),%r13
  75de9c:	mov    0x10(%rsi),%rbp
  75dea0:	mov    0x18(%rsi),%rax
  75dea4:	mov    %rax,0x30(%rsp)
  75dea9:	mov    0x20(%rsi),%rax
  75dead:	mov    %rax,0x28(%rsp)
  75deb2:	mov    0x8(%rdx),%r12
  75deb6:	mov    0x10(%rdx),%rbx
  75deba:	mov    (%rsp),%r15
  75debe:	mov    0x10(%rsp),%rsi
  75dec3:	mov    %r15,%rax
  75dec6:	sub    %rsi,%rax
  75dec9:	cmp    %rax,%rbx
  75decc:	mov    %rdi,0x38(%rsp)
  75ded1:	ja     75e13e <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x2de>
  75ded7:	test   %rbx,%rbx
  75deda:	je     75e11a <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x2ba>
  75dee0:	shl    $0x4,%rbx
  75dee4:	add    %r12,%rbx
  75dee7:	mov    %rsp,%rdi
  75deea:	jmp    75df29 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc9>
  75deec:	mov    0x8(%rsp),%rax
  75def1:	mov    %rsi,%rcx
  75def4:	shl    $0x4,%rcx
  75def8:	movl   $0x7fc00000,(%rax,%rcx,1)
  75deff:	mov    %r15d,0x4(%rax,%rcx,1)
  75df04:	mov    %r14,0x8(%rax,%rcx,1)
  75df09:	inc    %rsi
  75df0c:	mov    %rsi,0x10(%rsp)
  75df11:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  75df20:	cmp    %rbx,%r12
  75df23:	je     75e11a <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x2ba>
  75df29:	mov    %r12,%rax
  75df2c:	add    $0x10,%r12
  75df30:	mov    0x8(%rax),%r15d
  75df34:	test   %r15d,%r15d
  75df37:	je     75df20 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75df39:	mov    (%rax),%r14
  75df3c:	cmpb   $0x1,0x0(%r13)
  75df41:	jne    75e097 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x237>
  75df47:	mov    0x0(%rbp),%rax
  75df4b:	test   %rax,%rax
  75df4e:	je     75e000 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x1a0>
  75df54:	cmp    $0x1,%eax
  75df57:	jne    75e020 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x1c0>
  75df5d:	mov    0x10(%rbp),%rcx
  75df61:	test   %rcx,%rcx
  75df64:	je     75df20 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75df66:	mov    0x8(%rbp),%rax
  75df6a:	xor    %edx,%edx
  75df6c:	cmp    $0x1,%rcx
  75df70:	je     75dfa4 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x144>
  75df72:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  75df80:	mov    %rdx,%r9
  75df83:	mov    %rcx,%r10
  75df86:	shr    $1,%r10
  75df89:	add    %r10,%rdx
  75df8c:	mov    %rdx,%r8
  75df8f:	shl    $0x4,%r8
  75df93:	cmp    %r14,(%rax,%r8,1)
  75df97:	cmova  %r9,%rdx
  75df9b:	sub    %r10,%rcx
  75df9e:	cmp    $0x1,%rcx
  75dfa2:	ja     75df80 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x120>
  75dfa4:	mov    %rdx,%rcx
  75dfa7:	shl    $0x4,%rcx
  75dfab:	xor    %r8d,%r8d
  75dfae:	cmp    %r14,(%rax,%rcx,1)
  75dfb2:	setbe  %r8b
  75dfb6:	add    %rdx,%r8
  75dfb9:	je     75df20 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75dfbf:	shl    $0x4,%r8
  75dfc3:	mov    %r14,%rcx
  75dfc6:	sub    -0x10(%rax,%r8,1),%rcx
  75dfcb:	mov    -0x4(%rax,%r8,1),%edx
  75dfd0:	cmp    %rdx,%rcx
  75dfd3:	jae    75df20 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75dfd9:	add    %r8,%rax
  75dfdc:	mov    -0x8(%rax),%eax
  75dfdf:	add    %rax,%rcx
  75dfe2:	mov    0x30(%rsp),%rax
  75dfe7:	cmp    0x10(%rax),%rcx
  75dfeb:	jae    75df20 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75dff1:	jmp    75e056 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x1f6>
  75dff3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  75e000:	mov    %r14,%rcx
  75e003:	sub    0x8(%rbp),%rcx
  75e007:	jb     75df20 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75e00d:	cmp    0x10(%rbp),%rcx
  75e011:	jae    75df20 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75e017:	jmp    75e047 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x1e7>
  75e019:	nopl   0x0(%rax)
  75e020:	mov    0x10(%rbp),%rcx
  75e024:	test   %rcx,%rcx
  75e027:	je     75df20 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75e02d:	mov    0x8(%rbp),%rax
  75e031:	cmp    $0x1,%rcx
  75e035:	jne    75e0c8 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x268>
  75e03b:	cmp    %r14,(%rax)
  75e03e:	jne    75df20 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75e044:	mov    0x8(%rax),%ecx
  75e047:	mov    0x30(%rsp),%rax
  75e04c:	cmp    0x10(%rax),%rcx
  75e050:	jae    75df20 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75e056:	mov    0x30(%rsp),%rax
  75e05b:	mov    0x8(%rax),%rax
  75e05f:	mov    (%rax,%rcx,4),%eax
  75e062:	mov    $0xffffffff,%ecx
  75e067:	cmp    %rcx,%rax
  75e06a:	je     75df20 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75e070:	mov    0x28(%rsp),%rcx
  75e075:	cmp    %rax,0x10(%rcx)
  75e079:	jbe    75df20 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75e07f:	mov    0x28(%rsp),%rcx
  75e084:	mov    0x8(%rcx),%rcx
  75e088:	shl    $0x6,%rax
  75e08c:	cmp    %r14,0x20(%rcx,%rax,1)
  75e091:	jne    75df20 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75e097:	cmp    (%rsp),%rsi
  75e09b:	jne    75deec <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x8c>
  75e0a1:	mov    $0x1,%edx
  75e0a6:	mov    $0x4,%ecx
  75e0ab:	mov    $0x10,%r8d
  75e0b1:	mov    %rsi,0x20(%rsp)
  75e0b6:	call   75b3f0 <_RINvNvMs2_NtCscdodAO9FK5_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs9C2G9YFESsD_29canonical_text_public_control>
  75e0bb:	mov    %rsp,%rdi
  75e0be:	mov    0x20(%rsp),%rsi
  75e0c3:	jmp    75deec <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x8c>
  75e0c8:	xor    %edx,%edx
  75e0ca:	nopw   0x0(%rax,%rax,1)
  75e0d0:	mov    %rdx,%r9
  75e0d3:	mov    %rcx,%r10
  75e0d6:	shr    $1,%r10
  75e0d9:	add    %r10,%rdx
  75e0dc:	lea    (%rdx,%rdx,2),%r8
  75e0e0:	cmp    %r14,(%rax,%r8,4)
  75e0e4:	cmova  %r9,%rdx
  75e0e8:	sub    %r10,%rcx
  75e0eb:	cmp    $0x1,%rcx
  75e0ef:	ja     75e0d0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x270>
  75e0f1:	lea    (%rdx,%rdx,2),%rcx
  75e0f5:	cmp    %r14,(%rax,%rcx,4)
  75e0f9:	jne    75df20 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75e0ff:	lea    (%rax,%rcx,4),%rax
  75e103:	mov    0x8(%rax),%ecx
  75e106:	mov    0x30(%rsp),%rax
  75e10b:	cmp    0x10(%rax),%rcx
  75e10f:	jae    75df20 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0xc0>
  75e115:	jmp    75e056 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x1f6>
  75e11a:	mov    0x10(%rsp),%rax
  75e11f:	mov    0x38(%rsp),%rcx
  75e124:	mov    %rax,0x10(%rcx)
  75e128:	movaps (%rsp),%xmm0
  75e12c:	movups %xmm0,(%rcx)
  75e12f:	add    $0x58,%rsp
  75e133:	pop    %rbx
  75e134:	pop    %r12
  75e136:	pop    %r13
  75e138:	pop    %r14
  75e13a:	pop    %r15
  75e13c:	pop    %rbp
  75e13d:	ret
  75e13e:	mov    %rsi,0x20(%rsp)
  75e143:	mov    %rsi,%rax
  75e146:	add    %rbx,%rax
  75e149:	jb     75e18e <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x32e>
  75e14b:	mov    0x8(%rsp),%rdx
  75e150:	lea    0x40(%rsp),%rdi
  75e155:	mov    $0x4,%r8d
  75e15b:	mov    $0x10,%r9d
  75e161:	mov    %r15,%rsi
  75e164:	mov    %rax,%r14
  75e167:	mov    %rax,%rcx
  75e16a:	call   772f30 <_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner11finish_growCs9C2G9YFESsD_29canonical_text_public_control>
  75e16f:	cmpl   $0x1,0x40(%rsp)
  75e174:	je     75e198 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x338>
  75e176:	mov    0x48(%rsp),%rax
  75e17b:	mov    %rax,0x8(%rsp)
  75e180:	mov    %r14,(%rsp)
  75e184:	mov    0x20(%rsp),%rsi
  75e189:	jmp    75dee0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x80>
  75e18e:	xor    %edi,%edi
  75e190:	call   *0x35c19a(%rip)        # aba330 <_DYNAMIC+0x2f0>
  75e196:	ud2
  75e198:	mov    0x48(%rsp),%rdi
  75e19d:	mov    0x50(%rsp),%rsi
  75e1a2:	jmp    75e190 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x330>
  75e1a4:	mov    %rax,%rbx
  75e1a7:	mov    (%rsp),%r15
  75e1ab:	jmp    75e1b0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x350>
  75e1ad:	mov    %rax,%rbx
  75e1b0:	test   %r15,%r15
  75e1b3:	je     75e1cc <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_+0x36c>
  75e1b5:	mov    0x8(%rsp),%rdi
  75e1ba:	shl    $0x4,%r15
  75e1be:	mov    $0x4,%edx
  75e1c3:	mov    %r15,%rsi
  75e1c6:	call   *0x35c0b4(%rip)        # aba280 <_DYNAMIC+0x240>
  75e1cc:	mov    %rbx,%rdi
  75e1cf:	call   a98730 <_Unwind_Resume@plt>

<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::present_inner::{closure#44} bytes=415 frame=8

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075e1e0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_>:
  75e1e0:	push   %rax
  75e1e1:	mov    (%rdi),%rdx
  75e1e4:	mov    (%rdx),%rax
  75e1e7:	test   %rax,%rax
  75e1ea:	je     75e236 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x56>
  75e1ec:	cmp    $0x1,%eax
  75e1ef:	jne    75e252 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x72>
  75e1f1:	mov    0x8(%rdx),%rcx
  75e1f5:	mov    0x10(%rdx),%rdx
  75e1f9:	cmp    $0x1,%rdx
  75e1fd:	je     75e2a8 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0xc8>
  75e203:	test   %rdx,%rdx
  75e206:	je     75e350 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x170>
  75e20c:	xor    %eax,%eax
  75e20e:	xchg   %ax,%ax
  75e210:	mov    %rax,%r8
  75e213:	mov    %rdx,%r9
  75e216:	shr    $1,%r9
  75e219:	add    %r9,%rax
  75e21c:	mov    %rax,%r10
  75e21f:	shl    $0x4,%r10
  75e223:	cmp    %rsi,(%rcx,%r10,1)
  75e227:	cmova  %r8,%rax
  75e22b:	sub    %r9,%rdx
  75e22e:	cmp    $0x1,%rdx
  75e232:	ja     75e210 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x30>
  75e234:	jmp    75e2aa <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0xca>
  75e236:	mov    %rsi,%rax
  75e239:	sub    0x8(%rdx),%rax
  75e23d:	jb     75e350 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x170>
  75e243:	cmp    0x10(%rdx),%rax
  75e247:	jb     75e2e2 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x102>
  75e24d:	jmp    75e350 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x170>
  75e252:	mov    0x8(%rdx),%rax
  75e256:	mov    0x10(%rdx),%rcx
  75e25a:	cmp    $0x1,%rcx
  75e25e:	je     75e328 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x148>
  75e264:	test   %rcx,%rcx
  75e267:	je     75e350 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x170>
  75e26d:	xor    %edx,%edx
  75e26f:	nop
  75e270:	mov    %rdx,%r8
  75e273:	mov    %rcx,%r9
  75e276:	shr    $1,%r9
  75e279:	add    %r9,%rdx
  75e27c:	lea    (%rdx,%rdx,2),%r10
  75e280:	cmp    %rsi,(%rax,%r10,4)
  75e284:	cmova  %r8,%rdx
  75e288:	sub    %r9,%rcx
  75e28b:	cmp    $0x1,%rcx
  75e28f:	ja     75e270 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x90>
  75e291:	lea    (%rdx,%rdx,2),%rcx
  75e295:	cmp    %rsi,(%rax,%rcx,4)
  75e299:	jne    75e350 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x170>
  75e29f:	lea    (%rax,%rcx,4),%rax
  75e2a3:	jmp    75e32d <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x14d>
  75e2a8:	xor    %eax,%eax
  75e2aa:	mov    %rax,%r8
  75e2ad:	shl    $0x4,%r8
  75e2b1:	xor    %edx,%edx
  75e2b3:	cmp    %rsi,(%rcx,%r8,1)
  75e2b7:	setbe  %dl
  75e2ba:	add    %rax,%rdx
  75e2bd:	je     75e350 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x170>
  75e2c3:	shl    $0x4,%rdx
  75e2c7:	mov    %rsi,%rax
  75e2ca:	sub    -0x10(%rcx,%rdx,1),%rax
  75e2cf:	mov    -0x4(%rcx,%rdx,1),%r8d
  75e2d4:	cmp    %r8,%rax
  75e2d7:	jae    75e350 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x170>
  75e2d9:	add    %rdx,%rcx
  75e2dc:	mov    -0x8(%rcx),%ecx
  75e2df:	add    %rcx,%rax
  75e2e2:	mov    0x8(%rdi),%rdx
  75e2e6:	mov    0x10(%rdx),%rcx
  75e2ea:	cmp    %rcx,%rax
  75e2ed:	jae    75e33d <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x15d>
  75e2ef:	mov    0x8(%rdx),%rcx
  75e2f3:	mov    (%rcx,%rax,4),%edx
  75e2f6:	mov    $0xffffffff,%eax
  75e2fb:	cmp    %rax,%rdx
  75e2fe:	je     75e324 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x144>
  75e300:	mov    0x10(%rdi),%rcx
  75e304:	mov    0x10(%rcx),%rax
  75e308:	cmp    %rdx,%rax
  75e30b:	jbe    75e369 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x189>
  75e30d:	mov    0x8(%rcx),%rcx
  75e311:	mov    %rdx,%rdi
  75e314:	shl    $0x6,%rdi
  75e318:	xor    %eax,%eax
  75e31a:	cmp    %rsi,0x20(%rcx,%rdi,1)
  75e31f:	sete   %al
  75e322:	pop    %rcx
  75e323:	ret
  75e324:	xor    %eax,%eax
  75e326:	pop    %rcx
  75e327:	ret
  75e328:	cmp    %rsi,(%rax)
  75e32b:	jne    75e350 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x170>
  75e32d:	mov    0x8(%rax),%eax
  75e330:	mov    0x8(%rdi),%rdx
  75e334:	mov    0x10(%rdx),%rcx
  75e338:	cmp    %rcx,%rax
  75e33b:	jb     75e2ef <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0BQ_+0x10f>
  75e33d:	lea    0x33c0fc(%rip),%rdx        # a9a440 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x958>
  75e344:	mov    %rax,%rdi
  75e347:	mov    %rcx,%rsi
  75e34a:	call   *0x35bf60(%rip)        # aba2b0 <_DYNAMIC+0x270>
  75e350:	lea    -0x68ea9f(%rip),%rdi        # cf8b8 <GCC_except_table0+0xd4b0>
  75e357:	lea    0x33bb2a(%rip),%rdx        # a99e88 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x3a0>
  75e35e:	mov    $0x15,%esi
  75e363:	call   *0x35bfef(%rip)        # aba358 <_DYNAMIC+0x318>
  75e369:	lea    0x33bd28(%rip),%rcx        # a9a098 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x5b0>
  75e370:	mov    %rdx,%rdi
  75e373:	mov    %rax,%rsi
  75e376:	mov    %rcx,%rdx
  75e379:	call   *0x35bf31(%rip)        # aba2b0 <_DYNAMIC+0x270>

<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::present_inner::{closure#15} bytes=130 frame=8

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075e380 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_>:
  75e380:	push   %rax
  75e381:	cmp    %rsi,%rdx
  75e384:	jae    75e3ef <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_+0x6f>
  75e386:	lea    (%rdx,%rdx,4),%rax
  75e38a:	mov    0x20(%rdi,%rax,8),%eax
  75e38e:	and    $0xf,%eax
  75e391:	cmp    $0x9,%eax
  75e394:	ja     75e3d6 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_+0x56>
  75e396:	lea    -0x69a38d(%rip),%rcx        # c4010 <GCC_except_table0+0x1c08>
  75e39d:	movslq (%rcx,%rax,4),%rax
  75e3a1:	add    %rcx,%rax
  75e3a4:	jmp    *%rax
  75e3a6:	mov    $0x8,%al
  75e3a8:	jmp    75e3c8 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_+0x48>
  75e3aa:	mov    $0x4,%al
  75e3ac:	jmp    75e3c8 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_+0x48>
  75e3ae:	mov    $0x2,%al
  75e3b0:	jmp    75e3c8 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_+0x48>
  75e3b2:	mov    $0x3,%al
  75e3b4:	jmp    75e3c8 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_+0x48>
  75e3b6:	mov    $0x7,%al
  75e3b8:	jmp    75e3c8 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_+0x48>
  75e3ba:	xor    %eax,%eax
  75e3bc:	jmp    75e3c8 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_+0x48>
  75e3be:	mov    $0x1,%al
  75e3c0:	jmp    75e3c8 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_+0x48>
  75e3c2:	mov    $0x5,%al
  75e3c4:	jmp    75e3c8 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_+0x48>
  75e3c6:	mov    $0x6,%al
  75e3c8:	cmp    $0x4,%al
  75e3ca:	sete   %cl
  75e3cd:	cmp    $0x7,%al
  75e3cf:	sete   %al
  75e3d2:	or     %cl,%al
  75e3d4:	pop    %rcx
  75e3d5:	ret
  75e3d6:	lea    -0x68ba4d(%rip),%rdi        # d2990 <GCC_except_table0+0x10588>
  75e3dd:	lea    0x33d1dc(%rip),%rdx        # a9b5c0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1ad8>
  75e3e4:	mov    $0x83,%esi
  75e3e9:	call   *0x35bec9(%rip)        # aba2b8 <_DYNAMIC+0x278>
  75e3ef:	lea    0x33c062(%rip),%rax        # a9a458 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x970>
  75e3f6:	mov    %rdx,%rdi
  75e3f9:	mov    %rax,%rdx
  75e3fc:	call   *0x35beae(%rip)        # aba2b0 <_DYNAMIC+0x270>

<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::present_inner::{closure#25} bytes=143 frame=24

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075e410 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersn_0BQ_>:
  75e410:	push   %r14
  75e412:	push   %rbx
  75e413:	push   %rax
  75e414:	mov    %rdx,%rbx
  75e417:	and    $0xf,%esi
  75e41a:	cmp    $0x7,%esi
  75e41d:	jb     75e427 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersn_0BQ_+0x17>
  75e41f:	lea    -0x8(%rsi),%eax
  75e422:	cmp    $0x2,%eax
  75e425:	jae    75e44d <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersn_0BQ_+0x3d>
  75e427:	mov    0x30(%rbx),%rax
  75e42b:	mov    %rax,0x30(%rdi)
  75e42f:	movups (%rbx),%xmm0
  75e432:	movups 0x10(%rbx),%xmm1
  75e436:	movups 0x20(%rbx),%xmm2
  75e43a:	movups %xmm2,0x20(%rdi)
  75e43e:	movups %xmm1,0x10(%rdi)
  75e442:	movups %xmm0,(%rdi)
  75e445:	add    $0x8,%rsp
  75e449:	pop    %rbx
  75e44a:	pop    %r14
  75e44c:	ret
  75e44d:	cmp    $0x7,%esi
  75e450:	jne    75e471 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersn_0BQ_+0x61>
  75e452:	cmpl   $0x27,(%rbx)
  75e455:	jne    75e427 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersn_0BQ_+0x17>
  75e457:	cmpq   $0xb,0x8(%rbx)
  75e45c:	jne    75e427 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersn_0BQ_+0x17>
  75e45e:	movb   $0x5,0x8(%rdi)
  75e462:	movq   $0x28,(%rdi)
  75e469:	add    $0x8,%rsp
  75e46d:	pop    %rbx
  75e46e:	pop    %r14
  75e470:	ret
  75e471:	lea    -0x68bae8(%rip),%rdi        # d2990 <GCC_except_table0+0x10588>
  75e478:	lea    0x33d141(%rip),%rdx        # a9b5c0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1ad8>
  75e47f:	mov    $0x83,%esi
  75e484:	call   *0x35be2e(%rip)        # aba2b8 <_DYNAMIC+0x278>
  75e48a:	ud2
  75e48c:	mov    %rax,%r14
  75e48f:	mov    %rbx,%rdi
  75e492:	call   74d810 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  75e497:	mov    %r14,%rdi
  75e49a:	call   a98730 <_Unwind_Resume@plt>

<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::present_inner::{closure#26} bytes=61 frame=72

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075e4a0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerso_0BQ_>:
  75e4a0:	sub    $0x48,%rsp
  75e4a4:	cvtps2pd (%rdx),%xmm0
  75e4a7:	cvtps2pd 0x8(%rdx),%xmm1
  75e4ab:	movaps %xmm0,0x10(%rsp)
  75e4b0:	movaps %xmm1,0x20(%rsp)
  75e4b5:	cvtps2pd 0x10(%rdx),%xmm0
  75e4b9:	movaps %xmm0,0x30(%rsp)
  75e4be:	movb   $0x0,0x40(%rsp)
  75e4c3:	movups (%rsi),%xmm0
  75e4c6:	movaps %xmm0,(%rsp)
  75e4ca:	lea    0x10(%rsp),%rsi
  75e4cf:	mov    %rsp,%rdx
  75e4d2:	call   *0x35bff0(%rip)        # aba4c8 <_DYNAMIC+0x488>
  75e4d8:	add    $0x48,%rsp
  75e4dc:	ret

<<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::present_inner::{closure#9} as core::ops::function::FnOnce<(gpui_reactivity_core::tree::NodeId, cephal::tree::traits::MeasureInput)>>::call_once::{shim:vtable#0} bytes=57 frame=56

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075efd0 <_RNSNvYNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtBc_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0INtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceTNtNtCscO85OU7Wpt0_20gpui_reactivity_core4tree6NodeIdNtNtNtCs2M7EwM6HstD_6cephal4tree6traits12MeasureInputEE9call_once6vtableBV_>:
  75efd0:	push   %rbx
  75efd1:	sub    $0x30,%rsp
  75efd5:	mov    %rdi,%rbx
  75efd8:	lea    0x10(%rsp),%rax
  75efdd:	movups (%rcx),%xmm0
  75efe0:	movups 0x10(%rcx),%xmm1
  75efe4:	movaps %xmm1,0x20(%rsp)
  75efe9:	movaps %xmm0,0x10(%rsp)
  75efee:	movups (%rdx),%xmm0
  75eff1:	movaps %xmm0,(%rsp)
  75eff5:	mov    %rsp,%rdx
  75eff8:	mov    %rax,%rcx
  75effb:	call   75d880 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_inners7_0BQ_>
  75f000:	mov    %rbx,%rax
  75f003:	add    $0x30,%rsp
  75f007:	pop    %rbx
  75f008:	ret

canonical_text_public_control::owner_drag bytes=1426 frame=280

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075f010 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag>:
  75f010:	push   %rbp
  75f011:	push   %r15
  75f013:	push   %r14
  75f015:	push   %r13
  75f017:	push   %r12
  75f019:	push   %rbx
  75f01a:	sub    $0xe8,%rsp
  75f021:	movss  %xmm1,0x8(%rsp)
  75f027:	movss  %xmm0,0x94(%rsp)
  75f030:	mov    (%rdi),%r15
  75f033:	test   %r15,%r15
  75f036:	je     75f390 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x380>
  75f03c:	cmpb   $0x0,0x76e(%r15)
  75f044:	jne    75f397 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x387>
  75f04a:	cmpb   $0x1,0x76a(%r15)
  75f052:	jne    75f39e <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x38e>
  75f058:	mov    %rsi,0xb0(%rsp)
  75f060:	mov    %rdi,0x98(%rsp)
  75f068:	mov    0x5c0(%r15),%rbp
  75f06f:	mov    $0x1a,%eax
  75f074:	mov    %rax,0x88(%rsp)
  75f07c:	test   %rbp,%rbp
  75f07f:	je     75f3ab <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x39b>
  75f085:	mov    0x5b8(%r15),%r14
  75f08c:	shl    $0x6,%rbp
  75f090:	lea    0x1e8(%r15),%r12
  75f097:	xor    %ebx,%ebx
  75f099:	mov    0x35b298(%rip),%r13        # aba338 <_DYNAMIC+0x2f8>
  75f0a0:	jmp    75f0bd <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0xad>
  75f0a2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  75f0b0:	add    $0x40,%rbx
  75f0b4:	cmp    %rbx,%rbp
  75f0b7:	je     75f3ab <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x39b>
  75f0bd:	cmpb   $0x4,0x3d(%r14,%rbx,1)
  75f0c3:	jne    75f0b0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0xa0>
  75f0c5:	mov    0x20(%r14,%rbx,1),%rsi
  75f0ca:	mov    %r12,%rdi
  75f0cd:	call   *%r13
  75f0d0:	test   %al,%al
  75f0d2:	je     75f0b0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0xa0>
  75f0d4:	mov    0x20(%r14,%rbx,1),%rsi
  75f0d9:	lea    0x5f0(%r15),%rdi
  75f0e0:	call   *0x35b3fa(%rip)        # aba4e0 <_DYNAMIC+0x4a0>
  75f0e6:	cmpb   $0x0,0x76e(%r15)
  75f0ee:	jne    75f3ee <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x3de>
  75f0f4:	mov    %rdx,%rcx
  75f0f7:	lea    0x10(%rsp),%rdi
  75f0fc:	mov    %r15,%rsi
  75f0ff:	mov    %rax,%rdx
  75f102:	call   76afb0 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11input_indexBY_>
  75f107:	mov    0x10(%rsp),%rax
  75f10c:	mov    0x18(%rsp),%rdx
  75f111:	cmp    $0xfffffffffffffffe,%rax
  75f115:	mov    0x98(%rsp),%rbx
  75f11d:	jne    75f3f9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x3e9>
  75f123:	lea    0x50(%rsp),%rdi
  75f128:	mov    %r15,%rsi
  75f12b:	call   76b0f0 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE12selection_atBY_>
  75f130:	cmpq   $0xfffffffffffffffe,0x50(%rsp)
  75f136:	jne    75f424 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x414>
  75f13c:	movups 0x58(%rsp),%xmm0
  75f141:	movaps %xmm0,0xa0(%rsp)
  75f149:	movss  0x94(%rsp),%xmm0
  75f152:	movss  %xmm0,0x14(%rsp)
  75f158:	movss  0x8(%rsp),%xmm0
  75f15e:	movss  %xmm0,0x18(%rsp)
  75f164:	movl   $0x0,0x10(%rsp)
  75f16c:	lea    0x50(%rsp),%rdi
  75f171:	lea    0x10(%rsp),%rcx
  75f176:	mov    %rbx,%rsi
  75f179:	mov    0xb0(%rsp),%rdx
  75f181:	call   76dab0 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_>
  75f186:	cmpl   $0xfffffffe,0x50(%rsp)
  75f18b:	jne    75f31f <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x30f>
  75f191:	mov    (%rbx),%rsi
  75f194:	lea    0xb8(%rsp),%rdi
  75f19c:	call   760be0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack>
  75f1a1:	mov    (%rbx),%r14
  75f1a4:	test   %r14,%r14
  75f1a7:	je     75f486 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x476>
  75f1ad:	cmpb   $0x0,0x76e(%r14)
  75f1b5:	jne    75f48d <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x47d>
  75f1bb:	cmpb   $0x1,0x76a(%r14)
  75f1c3:	jne    75f494 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x484>
  75f1c9:	mov    0x5c0(%r14),%rbp
  75f1d0:	mov    $0x1a,%eax
  75f1d5:	mov    %rax,0x8(%rsp)
  75f1da:	test   %rbp,%rbp
  75f1dd:	je     75f49e <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x48e>
  75f1e3:	mov    0x5b8(%r14),%r12
  75f1ea:	shl    $0x6,%rbp
  75f1ee:	lea    0x1e8(%r14),%r15
  75f1f5:	xor    %ebx,%ebx
  75f1f7:	jmp    75f20d <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x1fd>
  75f1f9:	nopl   0x0(%rax)
  75f200:	add    $0x40,%rbx
  75f204:	cmp    %rbx,%rbp
  75f207:	je     75f49e <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x48e>
  75f20d:	cmpb   $0x4,0x3d(%r12,%rbx,1)
  75f213:	jne    75f200 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x1f0>
  75f215:	mov    0x20(%r12,%rbx,1),%rsi
  75f21a:	mov    %r15,%rdi
  75f21d:	call   *%r13
  75f220:	test   %al,%al
  75f222:	je     75f200 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x1f0>
  75f224:	mov    0x20(%r12,%rbx,1),%rsi
  75f229:	add    $0x5f0,%r14
  75f230:	mov    %r14,%rdi
  75f233:	call   *0x35b2a7(%rip)        # aba4e0 <_DYNAMIC+0x4a0>
  75f239:	mov    %rdx,%rcx
  75f23c:	mov    0x98(%rsp),%rdx
  75f244:	mov    (%rdx),%rbx
  75f247:	test   %rbx,%rbx
  75f24a:	je     75f4de <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x4ce>
  75f250:	cmpb   $0x0,0x76e(%rbx)
  75f257:	jne    75f4f2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x4e2>
  75f25d:	lea    0x10(%rsp),%rdi
  75f262:	mov    %rbx,%rsi
  75f265:	mov    %rax,%rdx
  75f268:	call   76afb0 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11input_indexBY_>
  75f26d:	mov    0x10(%rsp),%rax
  75f272:	mov    0x18(%rsp),%rdx
  75f277:	cmp    $0xfffffffffffffffe,%rax
  75f27b:	jne    75f4fd <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x4ed>
  75f281:	lea    0x50(%rsp),%rdi
  75f286:	mov    %rbx,%rsi
  75f289:	call   76b0f0 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE12selection_atBY_>
  75f28e:	cmpq   $0xfffffffffffffffe,0x50(%rsp)
  75f294:	jne    75f528 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x518>
  75f29a:	movups 0x58(%rsp),%xmm0
  75f29f:	movaps %xmm0,0x10(%rsp)
  75f2a4:	movzbl 0x1c(%rsp),%ecx
  75f2a9:	cmp    0xac(%rsp),%cl
  75f2b0:	mov    0x18(%rsp),%edx
  75f2b4:	sete   %al
  75f2b7:	cmp    0xa8(%rsp),%edx
  75f2be:	je     75f2c2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x2b2>
  75f2c0:	xor    %eax,%eax
  75f2c2:	test   %al,%al
  75f2c4:	jne    75f377 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x367>
  75f2ca:	mov    0xd0(%rsp),%rsi
  75f2d2:	xor    0xc8(%rsp),%rsi
  75f2da:	movabs $0x100000001b3,%rdi
  75f2e4:	imul   %rdi,%rsi
  75f2e8:	mov    0x10(%rsp),%eax
  75f2ec:	xor    %rsi,%rax
  75f2ef:	movzbl 0x14(%rsp),%esi
  75f2f4:	imul   %rdi,%rax
  75f2f8:	xor    %rsi,%rax
  75f2fb:	imul   %rdi,%rax
  75f2ff:	xor    %rdx,%rax
  75f302:	imul   %rdi,%rax
  75f306:	xor    %rcx,%rax
  75f309:	imul   %rdi,%rax
  75f30d:	add    $0xe8,%rsp
  75f314:	pop    %rbx
  75f315:	pop    %r12
  75f317:	pop    %r13
  75f319:	pop    %r14
  75f31b:	pop    %r15
  75f31d:	pop    %rbp
  75f31e:	ret
  75f31f:	mov    0x80(%rsp),%rax
  75f327:	mov    %rax,0x40(%rsp)
  75f32c:	movups 0x50(%rsp),%xmm0
  75f331:	movups 0x60(%rsp),%xmm1
  75f336:	movups 0x70(%rsp),%xmm2
  75f33b:	movaps %xmm2,0x30(%rsp)
  75f340:	movaps %xmm1,0x20(%rsp)
  75f345:	movaps %xmm0,0x10(%rsp)
  75f34a:	lea    -0x68f6a7(%rip),%rdi        # cfcaa <GCC_except_table0+0xd8a2>
  75f351:	lea    0x33b9d8(%rip),%rcx        # a9ad30 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1248>
  75f358:	lea    0x33b351(%rip),%r8        # a9a6b0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xbc8>
  75f35f:	lea    0x10(%rsp),%rbx
  75f364:	mov    $0x2b,%esi
  75f369:	mov    %rbx,%rdx
  75f36c:	call   *0x35afde(%rip)        # aba350 <_DYNAMIC+0x310>
  75f372:	jmp    75f585 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x575>
  75f377:	lea    0x18(%rsp),%rdi
  75f37c:	lea    0xa8(%rsp),%rsi
  75f384:	lea    0x33b355(%rip),%rdx        # a9a6e0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xbf8>
  75f38b:	call   74f593 <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextPositionBM_ECs9C2G9YFESsD_29canonical_text_public_control>
  75f390:	mov    $0xd,%eax
  75f395:	jmp    75f3a3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x393>
  75f397:	mov    $0xe,%eax
  75f39c:	jmp    75f3a3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x393>
  75f39e:	mov    $0x12,%eax
  75f3a3:	mov    %rax,0x88(%rsp)
  75f3ab:	mov    0x88(%rsp),%rax
  75f3b3:	mov    %rax,0x10(%rsp)
  75f3b8:	movq   $0x0,0x18(%rsp)
  75f3c1:	lea    -0x68f9a7(%rip),%rdi        # cfa21 <GCC_except_table0+0xd619>
  75f3c8:	lea    0x33b961(%rip),%rcx        # a9ad30 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1248>
  75f3cf:	lea    0x33b2aa(%rip),%r8        # a9a680 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xb98>
  75f3d6:	lea    0x10(%rsp),%rbx
  75f3db:	mov    $0x2a,%esi
  75f3e0:	mov    %rbx,%rdx
  75f3e3:	call   *0x35af67(%rip)        # aba350 <_DYNAMIC+0x310>
  75f3e9:	jmp    75f585 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x575>
  75f3ee:	movq   $0xe,0x50(%rsp)
  75f3f7:	jmp    75f424 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x414>
  75f3f9:	mov    0x40(%rsp),%rcx
  75f3fe:	mov    %rcx,0x80(%rsp)
  75f406:	movups 0x20(%rsp),%xmm0
  75f40b:	movups 0x30(%rsp),%xmm1
  75f410:	movups %xmm1,0x70(%rsp)
  75f415:	movups %xmm0,0x60(%rsp)
  75f41a:	mov    %rax,0x50(%rsp)
  75f41f:	mov    %rdx,0x58(%rsp)
  75f424:	mov    0x80(%rsp),%rax
  75f42c:	mov    %rax,0x40(%rsp)
  75f431:	mov    0x50(%rsp),%rax
  75f436:	mov    0x58(%rsp),%rcx
  75f43b:	movups 0x60(%rsp),%xmm0
  75f440:	movups 0x70(%rsp),%xmm1
  75f445:	movaps %xmm1,0x30(%rsp)
  75f44a:	movaps %xmm0,0x20(%rsp)
  75f44f:	mov    %rax,0x10(%rsp)
  75f454:	mov    %rcx,0x18(%rsp)
  75f459:	lea    -0x68f7b6(%rip),%rdi        # cfcaa <GCC_except_table0+0xd8a2>
  75f460:	lea    0x33b8c9(%rip),%rcx        # a9ad30 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1248>
  75f467:	lea    0x33b22a(%rip),%r8        # a9a698 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xbb0>
  75f46e:	lea    0x10(%rsp),%rbx
  75f473:	mov    $0x2b,%esi
  75f478:	mov    %rbx,%rdx
  75f47b:	call   *0x35aecf(%rip)        # aba350 <_DYNAMIC+0x310>
  75f481:	jmp    75f585 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x575>
  75f486:	mov    $0xd,%eax
  75f48b:	jmp    75f499 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x489>
  75f48d:	mov    $0xe,%eax
  75f492:	jmp    75f499 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x489>
  75f494:	mov    $0x12,%eax
  75f499:	mov    %rax,0x8(%rsp)
  75f49e:	mov    0x8(%rsp),%rax
  75f4a3:	mov    %rax,0x10(%rsp)
  75f4a8:	movq   $0x0,0x18(%rsp)
  75f4b1:	lea    -0x68fa97(%rip),%rdi        # cfa21 <GCC_except_table0+0xd619>
  75f4b8:	lea    0x33b871(%rip),%rcx        # a9ad30 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1248>
  75f4bf:	lea    0x33b1ba(%rip),%r8        # a9a680 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xb98>
  75f4c6:	lea    0x10(%rsp),%rbx
  75f4cb:	mov    $0x2a,%esi
  75f4d0:	mov    %rbx,%rdx
  75f4d3:	call   *0x35ae77(%rip)        # aba350 <_DYNAMIC+0x310>
  75f4d9:	jmp    75f585 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x575>
  75f4de:	movq   $0xd,0x50(%rsp)
  75f4e7:	movq   $0x0,0x58(%rsp)
  75f4f0:	jmp    75f528 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x518>
  75f4f2:	movq   $0xe,0x50(%rsp)
  75f4fb:	jmp    75f528 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x518>
  75f4fd:	mov    0x40(%rsp),%rcx
  75f502:	mov    %rcx,0x80(%rsp)
  75f50a:	movups 0x20(%rsp),%xmm0
  75f50f:	movups 0x30(%rsp),%xmm1
  75f514:	movups %xmm1,0x70(%rsp)
  75f519:	movups %xmm0,0x60(%rsp)
  75f51e:	mov    %rax,0x50(%rsp)
  75f523:	mov    %rdx,0x58(%rsp)
  75f528:	mov    0x80(%rsp),%rax
  75f530:	mov    %rax,0x40(%rsp)
  75f535:	mov    0x50(%rsp),%rax
  75f53a:	mov    0x58(%rsp),%rcx
  75f53f:	movups 0x60(%rsp),%xmm0
  75f544:	movups 0x70(%rsp),%xmm1
  75f549:	movaps %xmm1,0x30(%rsp)
  75f54e:	movaps %xmm0,0x20(%rsp)
  75f553:	mov    %rax,0x10(%rsp)
  75f558:	mov    %rcx,0x18(%rsp)
  75f55d:	lea    -0x68f8ba(%rip),%rdi        # cfcaa <GCC_except_table0+0xd8a2>
  75f564:	lea    0x33b7c5(%rip),%rcx        # a9ad30 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1248>
  75f56b:	lea    0x33b156(%rip),%r8        # a9a6c8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xbe0>
  75f572:	lea    0x10(%rsp),%rbx
  75f577:	mov    $0x2b,%esi
  75f57c:	mov    %rbx,%rdx
  75f57f:	call   *0x35adcb(%rip)        # aba350 <_DYNAMIC+0x310>
  75f585:	ud2
  75f587:	jmp    75f58f <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x57f>
  75f589:	jmp    75f58f <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x57f>
  75f58b:	jmp    75f58f <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x57f>
  75f58d:	jmp    75f58f <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag+0x57f>
  75f58f:	mov    %rax,%r14
  75f592:	mov    %rbx,%rdi
  75f595:	call   74d810 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  75f59a:	mov    %r14,%rdi
  75f59d:	call   a98730 <_Unwind_Resume@plt>

canonical_text_public_control::owner_arrow bytes=1422 frame=248

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075f5b0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow>:
  75f5b0:	push   %rbp
  75f5b1:	push   %r15
  75f5b3:	push   %r14
  75f5b5:	push   %r13
  75f5b7:	push   %r12
  75f5b9:	push   %rbx
  75f5ba:	sub    $0xc8,%rsp
  75f5c1:	mov    (%rdi),%rbx
  75f5c4:	test   %rbx,%rbx
  75f5c7:	je     75f8c1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x311>
  75f5cd:	cmpb   $0x0,0x76e(%rbx)
  75f5d4:	jne    75f8c8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x318>
  75f5da:	cmpb   $0x1,0x76a(%rbx)
  75f5e1:	jne    75f8cf <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x31f>
  75f5e7:	mov    %esi,0x38(%rsp)
  75f5eb:	mov    0x5c0(%rbx),%r12
  75f5f2:	mov    $0x1a,%eax
  75f5f7:	mov    %rax,0x78(%rsp)
  75f5fc:	test   %r12,%r12
  75f5ff:	je     75f8d9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x329>
  75f605:	mov    0x5b8(%rbx),%r13
  75f60c:	shl    $0x6,%r12
  75f610:	lea    0x1e8(%rbx),%r14
  75f617:	xor    %r15d,%r15d
  75f61a:	mov    0x35ad17(%rip),%rbp        # aba338 <_DYNAMIC+0x2f8>
  75f621:	jmp    75f63d <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x8d>
  75f623:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  75f630:	add    $0x40,%r15
  75f634:	cmp    %r15,%r12
  75f637:	je     75f8d9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x329>
  75f63d:	cmpb   $0x4,0x3d(%r13,%r15,1)
  75f643:	jne    75f630 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x80>
  75f645:	mov    0x20(%r13,%r15,1),%rsi
  75f64a:	mov    %r14,%rdi
  75f64d:	call   *%rbp
  75f64f:	test   %al,%al
  75f651:	je     75f630 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x80>
  75f653:	mov    0x20(%r13,%r15,1),%rsi
  75f658:	lea    0x5f0(%rbx),%rdi
  75f65f:	call   *0x35ae7b(%rip)        # aba4e0 <_DYNAMIC+0x4a0>
  75f665:	cmpb   $0x0,0x76e(%rbx)
  75f66c:	jne    75f916 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x366>
  75f672:	mov    %rdx,%rcx
  75f675:	mov    %rsp,%rdi
  75f678:	mov    %rbx,%rsi
  75f67b:	mov    %rax,%rdx
  75f67e:	call   76afb0 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11input_indexBY_>
  75f683:	mov    (%rsp),%rax
  75f687:	mov    0x8(%rsp),%rdx
  75f68c:	cmp    $0xfffffffffffffffe,%rax
  75f690:	jne    75f921 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x371>
  75f696:	lea    0x40(%rsp),%rdi
  75f69b:	mov    %rbx,%rsi
  75f69e:	call   76b0f0 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE12selection_atBY_>
  75f6a3:	cmpq   $0xfffffffffffffffe,0x40(%rsp)
  75f6a9:	jne    75f949 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x399>
  75f6af:	movups 0x48(%rsp),%xmm0
  75f6b4:	movaps %xmm0,0x80(%rsp)
  75f6bc:	cmpb   $0x1,0x76e(%rbx)
  75f6c3:	je     75f9a5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x3f5>
  75f6c9:	movq   $0x0,0x758(%rbx)
  75f6d4:	mov    0x628(%rbx),%r12
  75f6db:	test   %r12,%r12
  75f6de:	je     75f76c <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x1bc>
  75f6e4:	cmp    0x5f0(%rbx),%r12
  75f6eb:	jne    75fa90 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x4e0>
  75f6f1:	mov    0x630(%rbx),%r13
  75f6f8:	mov    %rsp,%rdi
  75f6fb:	mov    %rbx,%rsi
  75f6fe:	mov    %r13,%rdx
  75f701:	call   78d320 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE16resolve_identityBO_>
  75f706:	mov    (%rsp),%rax
  75f70a:	mov    0x8(%rsp),%rdi
  75f70f:	cmp    $0xfffffffffffffffe,%rax
  75f713:	jne    75fa95 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x4e5>
  75f719:	mov    0x2e0(%rbx),%rsi
  75f720:	cmp    %rsi,%rdi
  75f723:	jae    75fb16 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x566>
  75f729:	mov    0x2d8(%rbx),%rax
  75f730:	lea    (%rdi,%rdi,4),%rcx
  75f734:	mov    0x20(%rax,%rcx,8),%edi
  75f738:	call   776700 <_RNvMsh_NtCslbxve4rcJus_4gpui7runtimeNtB5_4Node4kind>
  75f73d:	cmp    $0x4,%al
  75f73f:	jne    75f76c <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x1bc>
  75f741:	movzbl 0x38(%rsp),%r8d
  75f747:	lea    0x40(%rsp),%rdi
  75f74c:	mov    %rbx,%rsi
  75f74f:	mov    %r12,%rdx
  75f752:	mov    %r13,%rcx
  75f755:	mov    $0x1,%r9d
  75f75b:	call   770550 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE14move_selectionB12_>
  75f760:	cmpq   $0xfffffffffffffffe,0x40(%rsp)
  75f766:	jne    75fabd <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x50d>
  75f76c:	lea    0x98(%rsp),%rdi
  75f774:	mov    %rbx,%rsi
  75f777:	call   760be0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack>
  75f77c:	cmpb   $0x0,0x76e(%rbx)
  75f783:	jne    75f9b3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x403>
  75f789:	cmpb   $0x1,0x76a(%rbx)
  75f790:	jne    75f9ba <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x40a>
  75f796:	mov    0x5c0(%rbx),%r13
  75f79d:	mov    $0x1a,%eax
  75f7a2:	mov    %rax,0x38(%rsp)
  75f7a7:	test   %r13,%r13
  75f7aa:	je     75f9c4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x414>
  75f7b0:	mov    0x5b8(%rbx),%r15
  75f7b7:	shl    $0x6,%r13
  75f7bb:	xor    %r12d,%r12d
  75f7be:	jmp    75f7cd <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x21d>
  75f7c0:	add    $0x40,%r12
  75f7c4:	cmp    %r12,%r13
  75f7c7:	je     75f9c4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x414>
  75f7cd:	cmpb   $0x4,0x3d(%r15,%r12,1)
  75f7d3:	jne    75f7c0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x210>
  75f7d5:	mov    0x20(%r15,%r12,1),%rsi
  75f7da:	mov    %r14,%rdi
  75f7dd:	call   *%rbp
  75f7df:	test   %al,%al
  75f7e1:	je     75f7c0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x210>
  75f7e3:	mov    0x20(%r15,%r12,1),%rsi
  75f7e8:	lea    0x5f0(%rbx),%rdi
  75f7ef:	call   *0x35aceb(%rip)        # aba4e0 <_DYNAMIC+0x4a0>
  75f7f5:	cmpb   $0x0,0x76e(%rbx)
  75f7fc:	jne    75fa01 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x451>
  75f802:	mov    %rdx,%rcx
  75f805:	mov    %rsp,%rdi
  75f808:	mov    %rbx,%rsi
  75f80b:	mov    %rax,%rdx
  75f80e:	call   76afb0 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11input_indexBY_>
  75f813:	mov    (%rsp),%rax
  75f817:	mov    0x8(%rsp),%rdx
  75f81c:	cmp    $0xfffffffffffffffe,%rax
  75f820:	jne    75fa0c <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x45c>
  75f826:	lea    0x40(%rsp),%rdi
  75f82b:	mov    %rbx,%rsi
  75f82e:	call   76b0f0 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE12selection_atBY_>
  75f833:	cmpq   $0xfffffffffffffffe,0x40(%rsp)
  75f839:	jne    75fa34 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x484>
  75f83f:	movups 0x48(%rsp),%xmm0
  75f844:	movaps %xmm0,(%rsp)
  75f848:	movzbl 0xc(%rsp),%ecx
  75f84d:	cmp    0x8c(%rsp),%cl
  75f854:	mov    0x8(%rsp),%edx
  75f858:	sete   %al
  75f85b:	cmp    0x88(%rsp),%edx
  75f862:	je     75f866 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x2b6>
  75f864:	xor    %eax,%eax
  75f866:	test   %al,%al
  75f868:	jne    75f8a8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x2f8>
  75f86a:	mov    0xb0(%rsp),%rax
  75f872:	xor    0xa8(%rsp),%rax
  75f87a:	movabs $0x100000001b3,%rsi
  75f884:	imul   %rsi,%rax
  75f888:	xor    %rdx,%rax
  75f88b:	imul   %rsi,%rax
  75f88f:	xor    %rcx,%rax
  75f892:	imul   %rsi,%rax
  75f896:	add    $0xc8,%rsp
  75f89d:	pop    %rbx
  75f89e:	pop    %r12
  75f8a0:	pop    %r13
  75f8a2:	pop    %r14
  75f8a4:	pop    %r15
  75f8a6:	pop    %rbp
  75f8a7:	ret
  75f8a8:	lea    0x8(%rsp),%rdi
  75f8ad:	lea    0x88(%rsp),%rsi
  75f8b5:	lea    0x33ae84(%rip),%rdx        # a9a740 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xc58>
  75f8bc:	call   74f593 <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextPositionBM_ECs9C2G9YFESsD_29canonical_text_public_control>
  75f8c1:	mov    $0xd,%eax
  75f8c6:	jmp    75f8d4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x324>
  75f8c8:	mov    $0xe,%eax
  75f8cd:	jmp    75f8d4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x324>
  75f8cf:	mov    $0x12,%eax
  75f8d4:	mov    %rax,0x78(%rsp)
  75f8d9:	mov    0x78(%rsp),%rax
  75f8de:	mov    %rax,(%rsp)
  75f8e2:	movq   $0x0,0x8(%rsp)
  75f8eb:	lea    -0x68fed1(%rip),%rdi        # cfa21 <GCC_except_table0+0xd619>
  75f8f2:	lea    0x33b437(%rip),%rcx        # a9ad30 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1248>
  75f8f9:	lea    0x33ad80(%rip),%r8        # a9a680 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xb98>
  75f900:	mov    %rsp,%rbx
  75f903:	mov    $0x2a,%esi
  75f908:	mov    %rbx,%rdx
  75f90b:	call   *0x35aa3f(%rip)        # aba350 <_DYNAMIC+0x310>
  75f911:	jmp    75fb14 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x564>
  75f916:	movq   $0xe,0x40(%rsp)
  75f91f:	jmp    75f949 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x399>
  75f921:	mov    0x30(%rsp),%rcx
  75f926:	mov    %rcx,0x70(%rsp)
  75f92b:	movups 0x10(%rsp),%xmm0
  75f930:	movups 0x20(%rsp),%xmm1
  75f935:	movups %xmm1,0x60(%rsp)
  75f93a:	movups %xmm0,0x50(%rsp)
  75f93f:	mov    %rax,0x40(%rsp)
  75f944:	mov    %rdx,0x48(%rsp)
  75f949:	mov    0x70(%rsp),%rax
  75f94e:	mov    %rax,0x30(%rsp)
  75f953:	mov    0x40(%rsp),%rax
  75f958:	mov    0x48(%rsp),%rcx
  75f95d:	movups 0x50(%rsp),%xmm0
  75f962:	movups 0x60(%rsp),%xmm1
  75f967:	movaps %xmm1,0x20(%rsp)
  75f96c:	movaps %xmm0,0x10(%rsp)
  75f971:	mov    %rax,(%rsp)
  75f975:	mov    %rcx,0x8(%rsp)
  75f97a:	lea    -0x68fcd7(%rip),%rdi        # cfcaa <GCC_except_table0+0xd8a2>
  75f981:	lea    0x33b3a8(%rip),%rcx        # a9ad30 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1248>
  75f988:	lea    0x33ad69(%rip),%r8        # a9a6f8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xc10>
  75f98f:	mov    %rsp,%rbx
  75f992:	mov    $0x2b,%esi
  75f997:	mov    %rbx,%rdx
  75f99a:	call   *0x35a9b0(%rip)        # aba350 <_DYNAMIC+0x310>
  75f9a0:	jmp    75fb14 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x564>
  75f9a5:	movq   $0xe,0x40(%rsp)
  75f9ae:	jmp    75fabd <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x50d>
  75f9b3:	mov    $0xe,%eax
  75f9b8:	jmp    75f9bf <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x40f>
  75f9ba:	mov    $0x12,%eax
  75f9bf:	mov    %rax,0x38(%rsp)
  75f9c4:	mov    0x38(%rsp),%rax
  75f9c9:	mov    %rax,(%rsp)
  75f9cd:	movq   $0x0,0x8(%rsp)
  75f9d6:	lea    -0x68ffbc(%rip),%rdi        # cfa21 <GCC_except_table0+0xd619>
  75f9dd:	lea    0x33b34c(%rip),%rcx        # a9ad30 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1248>
  75f9e4:	lea    0x33ac95(%rip),%r8        # a9a680 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xb98>
  75f9eb:	mov    %rsp,%rbx
  75f9ee:	mov    $0x2a,%esi
  75f9f3:	mov    %rbx,%rdx
  75f9f6:	call   *0x35a954(%rip)        # aba350 <_DYNAMIC+0x310>
  75f9fc:	jmp    75fb14 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x564>
  75fa01:	movq   $0xe,0x40(%rsp)
  75fa0a:	jmp    75fa34 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x484>
  75fa0c:	mov    0x30(%rsp),%rcx
  75fa11:	mov    %rcx,0x70(%rsp)
  75fa16:	movups 0x10(%rsp),%xmm0
  75fa1b:	movups 0x20(%rsp),%xmm1
  75fa20:	movups %xmm1,0x60(%rsp)
  75fa25:	movups %xmm0,0x50(%rsp)
  75fa2a:	mov    %rax,0x40(%rsp)
  75fa2f:	mov    %rdx,0x48(%rsp)
  75fa34:	mov    0x70(%rsp),%rax
  75fa39:	mov    %rax,0x30(%rsp)
  75fa3e:	mov    0x40(%rsp),%rax
  75fa43:	mov    0x48(%rsp),%rcx
  75fa48:	movups 0x50(%rsp),%xmm0
  75fa4d:	movups 0x60(%rsp),%xmm1
  75fa52:	movaps %xmm1,0x20(%rsp)
  75fa57:	movaps %xmm0,0x10(%rsp)
  75fa5c:	mov    %rax,(%rsp)
  75fa60:	mov    %rcx,0x8(%rsp)
  75fa65:	lea    -0x68fdc2(%rip),%rdi        # cfcaa <GCC_except_table0+0xd8a2>
  75fa6c:	lea    0x33b2bd(%rip),%rcx        # a9ad30 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1248>
  75fa73:	lea    0x33acae(%rip),%r8        # a9a728 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xc40>
  75fa7a:	mov    %rsp,%rbx
  75fa7d:	mov    $0x2b,%esi
  75fa82:	mov    %rbx,%rdx
  75fa85:	call   *0x35a8c5(%rip)        # aba350 <_DYNAMIC+0x310>
  75fa8b:	jmp    75fb14 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x564>
  75fa90:	mov    $0x11,%eax
  75fa95:	mov    0x30(%rsp),%rcx
  75fa9a:	mov    %rcx,0x70(%rsp)
  75fa9f:	movups 0x10(%rsp),%xmm0
  75faa4:	movups 0x20(%rsp),%xmm1
  75faa9:	movups %xmm1,0x60(%rsp)
  75faae:	movups %xmm0,0x50(%rsp)
  75fab3:	mov    %rax,0x40(%rsp)
  75fab8:	mov    %rdi,0x48(%rsp)
  75fabd:	mov    0x70(%rsp),%rax
  75fac2:	mov    %rax,0x30(%rsp)
  75fac7:	mov    0x40(%rsp),%rax
  75facc:	mov    0x48(%rsp),%rcx
  75fad1:	movups 0x50(%rsp),%xmm0
  75fad6:	movups 0x60(%rsp),%xmm1
  75fadb:	movaps %xmm1,0x20(%rsp)
  75fae0:	movaps %xmm0,0x10(%rsp)
  75fae5:	mov    %rax,(%rsp)
  75fae9:	mov    %rcx,0x8(%rsp)
  75faee:	lea    -0x68fe4b(%rip),%rdi        # cfcaa <GCC_except_table0+0xd8a2>
  75faf5:	lea    0x33b234(%rip),%rcx        # a9ad30 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1248>
  75fafc:	lea    0x33ac0d(%rip),%r8        # a9a710 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xc28>
  75fb03:	mov    %rsp,%rbx
  75fb06:	mov    $0x2b,%esi
  75fb0b:	mov    %rbx,%rdx
  75fb0e:	call   *0x35a83c(%rip)        # aba350 <_DYNAMIC+0x310>
  75fb14:	ud2
  75fb16:	lea    0x33b70b(%rip),%rdx        # a9b228 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1740>
  75fb1d:	call   *0x35a78d(%rip)        # aba2b0 <_DYNAMIC+0x270>
  75fb23:	jmp    75fb2b <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x57b>
  75fb25:	jmp    75fb2b <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x57b>
  75fb27:	jmp    75fb2b <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x57b>
  75fb29:	jmp    75fb2b <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow+0x57b>
  75fb2b:	mov    %rax,%r14
  75fb2e:	mov    %rbx,%rdi
  75fb31:	call   74d810 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  75fb36:	mov    %r14,%rdi
  75fb39:	call   a98730 <_Unwind_Resume@plt>

canonical_text_public_control::query_visual bytes=142 frame=40

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075fb40 <_RNvCs9C2G9YFESsD_29canonical_text_public_control12query_visual>:
  75fb40:	push   %rbp
  75fb41:	push   %r15
  75fb43:	push   %r14
  75fb45:	push   %r12
  75fb47:	push   %rbx
  75fb48:	mov    %edx,%r15d
  75fb4b:	mov    %esi,%r14d
  75fb4e:	mov    %rdi,%r12
  75fb51:	call   *0x35a991(%rip)        # aba4e8 <_DYNAMIC+0x4a8>
  75fb57:	cmp    $0x2,%dl
  75fb5a:	je     75fbb4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control12query_visual+0x74>
  75fb5c:	mov    %eax,%ebx
  75fb5e:	mov    %edx,%ebp
  75fb60:	movzbl %r15b,%edx
  75fb64:	mov    %r12,%rdi
  75fb67:	mov    %r14d,%esi
  75fb6a:	call   *0x35a980(%rip)        # aba4f0 <_DYNAMIC+0x4b0>
  75fb70:	cmp    $0x2,%dl
  75fb73:	je     75fbc1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control12query_visual+0x81>
  75fb75:	xor    $0x1,%ebx
  75fb78:	movabs $0x100000001b3,%rcx
  75fb82:	imul   %rcx,%rbx
  75fb86:	and    $0x1,%bpl
  75fb8a:	movzbl %bpl,%esi
  75fb8e:	xor    %rbx,%rsi
  75fb91:	imul   %rcx,%rsi
  75fb95:	mov    %eax,%edi
  75fb97:	xor    %rsi,%rdi
  75fb9a:	imul   %rcx,%rdi
  75fb9e:	and    $0x1,%dl
  75fba1:	movzbl %dl,%eax
  75fba4:	xor    %rdi,%rax
  75fba7:	imul   %rcx,%rax
  75fbab:	pop    %rbx
  75fbac:	pop    %r12
  75fbae:	pop    %r14
  75fbb0:	pop    %r15
  75fbb2:	pop    %rbp
  75fbb3:	ret
  75fbb4:	lea    0x33ad65(%rip),%rdi        # a9a920 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xe38>
  75fbbb:	call   *0x35a77f(%rip)        # aba340 <_DYNAMIC+0x300>
  75fbc1:	lea    0x33ad70(%rip),%rdi        # a9a938 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xe50>
  75fbc8:	call   *0x35a772(%rip)        # aba340 <_DYNAMIC+0x300>

canonical_text_public_control::owner_prepare bytes=1380 frame=280

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000075fbd0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare>:
  75fbd0:	push   %rbp
  75fbd1:	push   %r15
  75fbd3:	push   %r14
  75fbd5:	push   %r13
  75fbd7:	push   %r12
  75fbd9:	push   %rbx
  75fbda:	sub    $0xe8,%rsp
  75fbe1:	mov    %rdi,%r14
  75fbe4:	test   %esi,%esi
  75fbe6:	jne    75fbee <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x1e>
  75fbe8:	pxor   %xmm0,%xmm0
  75fbec:	jmp    75fbf6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x26>
  75fbee:	movd   -0x69d76e(%rip),%xmm0        # c2488 <GCC_except_table0+0x80>
  75fbf6:	movd   %xmm0,(%rsp)
  75fbfb:	mov    (%r14),%rbx
  75fbfe:	test   %rbx,%rbx
  75fc01:	je     75feec <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x31c>
  75fc07:	lea    0x8(%r14),%rax
  75fc0b:	mov    %rbx,0xd8(%rsp)
  75fc13:	mov    %rax,0xe0(%rsp)
  75fc1b:	cmpb   $0x0,0x76e(%rbx)
  75fc22:	jne    75ff22 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x352>
  75fc28:	mov    0x6a0(%rbx),%rax
  75fc2f:	mov    %rax,0xd0(%rsp)
  75fc37:	movabs $0x200000001,%r15
  75fc41:	mov    0x248(%rbx),%rbp
  75fc48:	mov    0x250(%rbx),%r12
  75fc4f:	shl    $0x4,%r12
  75fc53:	xor    %r13d,%r13d
  75fc56:	cs nopw 0x0(%rax,%rax,1)
  75fc60:	cmp    %r13,%r12
  75fc63:	je     75fe9d <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x2cd>
  75fc69:	mov    0x0(%rbp,%r13,1),%rdi
  75fc6e:	mov    0x8(%rbp,%r13,1),%rax
  75fc73:	call   *0x18(%rax)
  75fc76:	add    $0x10,%r13
  75fc7a:	cmp    %r15,%rax
  75fc7d:	jne    75fc60 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x90>
  75fc7f:	mov    -0x10(%rbp,%r13,1),%rdi
  75fc84:	mov    -0x8(%rbp,%r13,1),%rax
  75fc89:	lea    0x290(%rbx),%rsi
  75fc90:	call   *0x28(%rax)
  75fc93:	mov    %rax,%rdi
  75fc96:	mov    %rdx,%rax
  75fc99:	lea    0x33b780(%rip),%rdx        # a9b420 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1938>
  75fca0:	lea    0x2b0(%rbx),%rsi
  75fca7:	call   *0x20(%rax)
  75fcaa:	mov    %r15,0x18(%rsp)
  75fcaf:	mov    0x18(%rsp),%rcx
  75fcb4:	mov    %rcx,0xb0(%rsp)
  75fcbc:	mov    0x20(%rsp),%rcx
  75fcc1:	mov    %rcx,0xb8(%rsp)
  75fcc9:	test   %al,%al
  75fccb:	je     75ff2d <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x35d>
  75fcd1:	movq   $0x0,0xb0(%rsp)
  75fcdd:	cmpb   $0x0,0x76e(%rbx)
  75fce4:	jne    75ff34 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x364>
  75fcea:	mov    0x6a0(%rbx),%rax
  75fcf1:	inc    %rax
  75fcf4:	je     75fdb5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x1e5>
  75fcfa:	mov    0x2c8(%rbx),%ecx
  75fd00:	cmp    $0xffffffff,%ecx
  75fd03:	je     75fe82 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x2b2>
  75fd09:	inc    %ecx
  75fd0b:	mov    %ecx,0x2c8(%rbx)
  75fd11:	movaps -0x69c158(%rip),%xmm0        # c3bc0 <GCC_except_table0+0x17b8>
  75fd18:	movups %xmm0,0x2b0(%rbx)
  75fd1f:	movss  (%rsp),%xmm0
  75fd24:	movss  %xmm0,0x2c0(%rbx)
  75fd2c:	movl   $0x0,0x2c4(%rbx)
  75fd36:	mov    %rax,0x6a0(%rbx)
  75fd3d:	incq   0x700(%rbx)
  75fd44:	movq   $0x0,0x758(%rbx)
  75fd4f:	lea    0x78(%rsp),%rdi
  75fd54:	lea    0xd8(%rsp),%rsi
  75fd5c:	lea    0xb0(%rsp),%rcx
  75fd64:	mov    %r15,%rdx
  75fd67:	xor    %r8d,%r8d
  75fd6a:	call   767940 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB4_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE20after_source_changedBW_>
  75fd6f:	mov    0x78(%rsp),%r12
  75fd74:	cmp    $0xfffffffffffffffe,%r12
  75fd78:	jne    75ff3f <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x36f>
  75fd7e:	mov    (%r14),%rsi
  75fd81:	lea    0x10(%rsp),%rdi
  75fd86:	call   760be0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack>
  75fd8b:	mov    0x28(%rsp),%rcx
  75fd90:	xor    0x20(%rsp),%rcx
  75fd95:	movabs $0x100000001b3,%rax
  75fd9f:	imul   %rcx,%rax
  75fda3:	add    $0xe8,%rsp
  75fdaa:	pop    %rbx
  75fdab:	pop    %r12
  75fdad:	pop    %r13
  75fdaf:	pop    %r14
  75fdb1:	pop    %r15
  75fdb3:	pop    %rbp
  75fdb4:	ret
  75fdb5:	mov    $0x1f,%r12d
  75fdbb:	mov    0x88(%rsp),%r14
  75fdc3:	mov    0x90(%rsp),%rbx
  75fdcb:	movd   (%rsp),%xmm0
  75fdd0:	movd   %xmm0,%ecx
  75fdd4:	mov    %ecx,%r9d
  75fdd7:	shr    $0x8,%r9d
  75fddb:	movabs $0x3f80000000000000,%rsi
  75fde5:	mov    $0x3f800000,%edx
  75fdea:	mov    $0x2,%r10d
  75fdf0:	pxor   %xmm0,%xmm0
  75fdf4:	mov    %r10,0x10(%rsp)
  75fdf9:	mov    %r12,0x18(%rsp)
  75fdfe:	mov    %rax,0x20(%rsp)
  75fe03:	mov    %r14,0x28(%rsp)
  75fe08:	mov    %rbx,0x30(%rsp)
  75fe0d:	mov    %r11b,0x38(%rsp)
  75fe12:	mov    0x8(%rsp),%eax
  75fe16:	mov    0xb(%rsp),%r10d
  75fe1b:	mov    %eax,0x39(%rsp)
  75fe1f:	mov    %r10d,0x3c(%rsp)
  75fe24:	mov    %r13,0x40(%rsp)
  75fe29:	mov    %r15,0x48(%rsp)
  75fe2e:	mov    %rdx,0x50(%rsp)
  75fe33:	mov    %rsi,0x58(%rsp)
  75fe38:	mov    %cl,0x60(%rsp)
  75fe3c:	mov    %r9w,0x61(%rsp)
  75fe42:	shr    $0x10,%r9d
  75fe46:	mov    %r9b,0x63(%rsp)
  75fe4b:	movd   %xmm0,0x64(%rsp)
  75fe51:	mov    %rdi,0x68(%rsp)
  75fe56:	mov    %r8,0x70(%rsp)
  75fe5b:	lea    -0x6901b8(%rip),%rdi        # cfcaa <GCC_except_table0+0xd8a2>
  75fe62:	lea    0x33af27(%rip),%rcx        # a9ad90 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x12a8>
  75fe69:	lea    0x33ab08(%rip),%r8        # a9a978 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xe90>
  75fe70:	lea    0x10(%rsp),%rdx
  75fe75:	mov    $0x2b,%esi
  75fe7a:	call   *0x35a4d0(%rip)        # aba350 <_DYNAMIC+0x310>
  75fe80:	jmp    75fe9b <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x2cb>
  75fe82:	lea    -0x68d127(%rip),%rdi        # d2d62 <GCC_except_table0+0x1095a>
  75fe89:	lea    0x33c018(%rip),%rdx        # a9bea8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x23c0>
  75fe90:	mov    $0x19,%esi
  75fe95:	call   *0x35a4bd(%rip)        # aba358 <_DYNAMIC+0x318>
  75fe9b:	ud2
  75fe9d:	mov    %r15,0x18(%rsp)
  75fea2:	mov    0x18(%rsp),%rax
  75fea7:	mov    %rax,0xb0(%rsp)
  75feaf:	mov    0x20(%rsp),%rax
  75feb4:	mov    %rax,0xb8(%rsp)
  75febc:	mov    $0xb,%eax
  75fec1:	mov    0xb0(%rsp),%rcx
  75fec9:	mov    %rcx,0x88(%rsp)
  75fed1:	mov    0xb8(%rsp),%rcx
  75fed9:	mov    %rcx,0x90(%rsp)
  75fee1:	mov    $0x20,%r12d
  75fee7:	jmp    75fdbb <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x1eb>
  75feec:	movd   (%rsp),%xmm0
  75fef1:	movd   %xmm0,%ecx
  75fef5:	mov    %ecx,%r9d
  75fef8:	shr    $0x8,%r9d
  75fefc:	movabs $0x3f80000000000000,%rsi
  75ff06:	mov    $0x3f800000,%edx
  75ff0b:	pxor   %xmm0,%xmm0
  75ff0f:	mov    $0xd,%r12d
  75ff15:	mov    $0x2,%r10d
  75ff1b:	xor    %eax,%eax
  75ff1d:	jmp    75fdf4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x224>
  75ff22:	mov    $0xe,%r12d
  75ff28:	jmp    75fdcb <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x1fb>
  75ff2d:	mov    $0xa,%eax
  75ff32:	jmp    75fec1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x2f1>
  75ff34:	mov    $0xe,%r12d
  75ff3a:	jmp    75fdbb <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x1eb>
  75ff3f:	mov    0x80(%rsp),%rax
  75ff47:	mov    %rax,(%rsp)
  75ff4b:	mov    0x88(%rsp),%rdx
  75ff53:	movzbl 0x98(%rsp),%ecx
  75ff5b:	mov    0xa0(%rsp),%rdi
  75ff63:	mov    0xa8(%rsp),%r8
  75ff6b:	mov    0x90(%rsp),%rsi
  75ff73:	mov    0x6a0(%rbx),%rax
  75ff7a:	cmp    0xd0(%rsp),%rax
  75ff82:	jne    75ffb9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x3e9>
  75ff84:	lea    0x99(%rsp),%rax
  75ff8c:	mov    (%rax),%r9d
  75ff8f:	mov    0x3(%rax),%eax
  75ff92:	mov    %eax,0xb(%rsp)
  75ff96:	mov    %r9d,0x8(%rsp)
  75ff9b:	mov    $0x4,%r10d
  75ffa1:	mov    %r8,%r15
  75ffa4:	mov    %rdi,%r13
  75ffa7:	mov    %ecx,%r11d
  75ffaa:	mov    %rsi,%rbx
  75ffad:	mov    %rdx,%r14
  75ffb0:	mov    (%rsp),%rax
  75ffb4:	jmp    75fdf4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x224>
  75ffb9:	movzbl 0x76c(%rbx),%r11d
  75ffc1:	cmpq   $0x0,0x6d0(%rbx)
  75ffc9:	je     75ffda <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x40a>
  75ffcb:	test   %r11b,%r11b
  75ffce:	je     75ffdf <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x40f>
  75ffd0:	cmpq   $0xffffffffffffffff,0x5c8(%rbx)
  75ffd8:	jne    75ffdf <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x40f>
  75ffda:	xor    %r10d,%r10d
  75ffdd:	jmp    75ffec <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x41c>
  75ffdf:	mov    0x6e0(%rbx),%rbp
  75ffe6:	mov    $0x1,%r10d
  75ffec:	mov    0x6a8(%rbx),%r14
  75fff3:	mov    0x758(%rbx),%rbx
  75fffa:	movzbl 0x9b(%rsp),%r15d
  760003:	shl    $0x10,%r15d
  760007:	movzwl 0x99(%rsp),%r9d
  760010:	or     %r15d,%r9d
  760013:	movd   0x9c(%rsp),%xmm0
  76001c:	mov    (%rsp),%r15
  760020:	mov    %r12,%r13
  760023:	mov    %rbp,%r12
  760026:	jmp    75fdf4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x224>
  76002b:	jmp    76002d <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x45d>
  76002d:	mov    %rax,%rdi
  760030:	call   *0x35a2a2(%rip)        # aba2d8 <_DYNAMIC+0x298>
  760036:	mov    %rax,%r14
  760039:	mov    %rdx,%r15
  76003c:	mov    %rax,0x18(%rsp)
  760041:	mov    %rdx,0x20(%rsp)
  760046:	movq   $0xfffffffffffffffe,0x10(%rsp)
  76004f:	mov    %rbx,%rdi
  760052:	call   78d970 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE6poisonBO_>
  760057:	mov    (%r15),%rax
  76005a:	test   %rax,%rax
  76005d:	je     760064 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x494>
  76005f:	mov    %r14,%rdi
  760062:	call   *%rax
  760064:	mov    0x8(%r15),%rsi
  760068:	mov    $0xf,%r12d
  76006e:	test   %rsi,%rsi
  760071:	je     75fdbb <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x1eb>
  760077:	mov    0x10(%r15),%rdx
  76007b:	mov    %r14,%rdi
  76007e:	call   *0x35a1fc(%rip)        # aba280 <_DYNAMIC+0x240>
  760084:	jmp    75fdbb <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x1eb>
  760089:	mov    %rax,%rbx
  76008c:	mov    0x8(%r15),%rsi
  760090:	test   %rsi,%rsi
  760093:	je     76010b <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x53b>
  760095:	mov    0x10(%r15),%rdx
  760099:	mov    %r14,%rdi
  76009c:	call   *0x35a1de(%rip)        # aba280 <_DYNAMIC+0x240>
  7600a2:	mov    %rbx,%rdi
  7600a5:	call   a98730 <_Unwind_Resume@plt>
  7600aa:	mov    %rax,%rbx
  7600ad:	lea    0x10(%rsp),%rdi
  7600b2:	call   7462f0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultIBC_NtNtCslbxve4rcJus_4gpui7element9AdmissionNtNtB15_6source9BindErrorEINtNtCscdodAO9FK5_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECs9C2G9YFESsD_29canonical_text_public_control>
  7600b7:	jmp    76010b <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x53b>
  7600b9:	call   *0x35a1e9(%rip)        # aba2a8 <_DYNAMIC+0x268>
  7600bf:	call   *0x35a21b(%rip)        # aba2e0 <_DYNAMIC+0x2a0>
  7600c5:	mov    %rax,%rdi
  7600c8:	call   *0x35a20a(%rip)        # aba2d8 <_DYNAMIC+0x298>
  7600ce:	mov    %rax,0x18(%rsp)
  7600d3:	mov    %rdx,0x20(%rsp)
  7600d8:	movq   $0xfffffffffffffffd,0x10(%rsp)
  7600e1:	mov    %rbx,%rdi
  7600e4:	call   78d970 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE6poisonBO_>
  7600e9:	lea    0x10(%rsp),%rdi
  7600ee:	call   746360 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultIBC_NtNtNtCslbxve4rcJus_4gpui7runtime5paint12PatchOutcomeNtB15_5ErrorEINtNtCscdodAO9FK5_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECs9C2G9YFESsD_29canonical_text_public_control>
  7600f3:	mov    $0xf,%r12d
  7600f9:	jmp    75fdbb <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare+0x1eb>
  7600fe:	mov    %rax,%rbx
  760101:	lea    0x10(%rsp),%rdi
  760106:	call   746360 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultIBC_NtNtNtCslbxve4rcJus_4gpui7runtime5paint12PatchOutcomeNtB15_5ErrorEINtNtCscdodAO9FK5_5alloc5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECs9C2G9YFESsD_29canonical_text_public_control>
  76010b:	mov    %rbx,%rdi
  76010e:	call   a98730 <_Unwind_Resume@plt>
  760113:	call   *0x35a18f(%rip)        # aba2a8 <_DYNAMIC+0x268>
  760119:	call   *0x35a1c1(%rip)        # aba2e0 <_DYNAMIC+0x2a0>
  76011f:	mov    %rax,%rbx
  760122:	lea    0x10(%rsp),%rdi
  760127:	call   7485f0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui7runtime8SetErrorNtNtCscO85OU7Wpt0_20gpui_reactivity_core8geometry6AffineEECs9C2G9YFESsD_29canonical_text_public_control>
  76012c:	mov    %rbx,%rdi
  76012f:	call   a98730 <_Unwind_Resume@plt>

canonical_text_public_control::owner_reshape bytes=340 frame=248

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000760140 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_reshape>:
  760140:	push   %r15
  760142:	push   %r14
  760144:	push   %r13
  760146:	push   %r12
  760148:	push   %rbx
  760149:	sub    $0xd0,%rsp
  760150:	mov    %rdx,%r14
  760153:	test   %rdx,%rdx
  760156:	jns    760167 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_reshape+0x27>
  760158:	xor    %r13d,%r13d
  76015b:	mov    %r13,%rdi
  76015e:	mov    %r14,%rsi
  760161:	call   *0x35a1c9(%rip)        # aba330 <_DYNAMIC+0x2f0>
  760167:	mov    %rdi,%rbx
  76016a:	je     7601a2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_reshape+0x62>
  76016c:	mov    %rsi,%r12
  76016f:	call   *0x35a113(%rip)        # aba288 <_DYNAMIC+0x248>
  760175:	mov    $0x1,%r13d
  76017b:	mov    $0x1,%esi
  760180:	mov    %r14,%rdi
  760183:	call   *0x35a107(%rip)        # aba290 <_DYNAMIC+0x250>
  760189:	test   %rax,%rax
  76018c:	je     76015b <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_reshape+0x1b>
  76018e:	mov    %rax,%r15
  760191:	mov    %rax,%rdi
  760194:	mov    %r12,%rsi
  760197:	mov    %r14,%rdx
  76019a:	call   *0x35a100(%rip)        # aba2a0 <memcpy@GLIBC_2.14>
  7601a0:	jmp    7601a8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_reshape+0x68>
  7601a2:	mov    $0x1,%r15d
  7601a8:	mov    %r14,(%rsp)
  7601ac:	mov    %r15,0x8(%rsp)
  7601b1:	mov    %r14,0x10(%rsp)
  7601b6:	lea    0x33a6c3(%rip),%rdx        # a9a880 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xd98>
  7601bd:	lea    0x68(%rsp),%rdi
  7601c2:	mov    %rsp,%rcx
  7601c5:	mov    %rbx,%rsi
  7601c8:	call   744ac0 <_RINvMst_NtCslbxve4rcJus_4gpui7runtimeINtB6_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE3setNtNtCscdodAO9FK5_5alloc6string6StringEBL_>
  7601cd:	cmpl   $0xffffffff,0x68(%rsp)
  7601d2:	jne    760208 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_reshape+0xc8>
  7601d4:	mov    (%rbx),%rsi
  7601d7:	mov    %rsp,%rdi
  7601da:	call   760be0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack>
  7601df:	mov    0x18(%rsp),%rcx
  7601e4:	xor    0x10(%rsp),%rcx
  7601e9:	movabs $0x100000001b3,%rax
  7601f3:	imul   %rcx,%rax
  7601f7:	add    $0xd0,%rsp
  7601fe:	pop    %rbx
  7601ff:	pop    %r12
  760201:	pop    %r13
  760203:	pop    %r14
  760205:	pop    %r15
  760207:	ret
  760208:	mov    0xc8(%rsp),%rax
  760210:	mov    %rax,0x60(%rsp)
  760215:	movups 0xb8(%rsp),%xmm0
  76021d:	movaps %xmm0,0x50(%rsp)
  760222:	movups 0xa8(%rsp),%xmm0
  76022a:	movaps %xmm0,0x40(%rsp)
  76022f:	movups 0x68(%rsp),%xmm0
  760234:	movups 0x78(%rsp),%xmm1
  760239:	movups 0x88(%rsp),%xmm2
  760241:	movups 0x98(%rsp),%xmm3
  760249:	movaps %xmm3,0x30(%rsp)
  76024e:	movaps %xmm2,0x20(%rsp)
  760253:	movaps %xmm1,0x10(%rsp)
  760258:	movaps %xmm0,(%rsp)
  76025c:	lea    -0x6905b9(%rip),%rdi        # cfcaa <GCC_except_table0+0xd8a2>
  760263:	lea    0x33ab46(%rip),%rcx        # a9adb0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x12c8>
  76026a:	lea    0x33a71f(%rip),%r8        # a9a990 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xea8>
  760271:	mov    %rsp,%rdx
  760274:	mov    $0x2b,%esi
  760279:	call   *0x35a0d1(%rip)        # aba350 <_DYNAMIC+0x310>
  76027f:	ud2
  760281:	mov    %rax,%rbx
  760284:	mov    %rsp,%rdi
  760287:	call   7486b0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui7runtime8SetErrorNtNtCscdodAO9FK5_5alloc6string6StringEECs9C2G9YFESsD_29canonical_text_public_control>
  76028c:	mov    %rbx,%rdi
  76028f:	call   a98730 <_Unwind_Resume@plt>

canonical_text_public_control::map_transcript bytes=880 frame=312

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007602a0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript>:
  7602a0:	push   %rbp
  7602a1:	push   %r15
  7602a3:	push   %r14
  7602a5:	push   %r13
  7602a7:	push   %r12
  7602a9:	push   %rbx
  7602aa:	sub    $0x108,%rsp
  7602b1:	mov    %rdi,%rsi
  7602b4:	lea    0xc0(%rsp),%rdi
  7602bc:	call   *0x35a236(%rip)        # aba4f8 <_DYNAMIC+0x4b8>
  7602c2:	mov    0x100(%rsp),%rax
  7602ca:	mov    %rax,0x50(%rsp)
  7602cf:	movups 0xc0(%rsp),%xmm0
  7602d7:	movups 0xd0(%rsp),%xmm1
  7602df:	movups 0xe0(%rsp),%xmm2
  7602e7:	movups 0xf0(%rsp),%xmm3
  7602ef:	movaps %xmm3,0x40(%rsp)
  7602f4:	movaps %xmm2,0x30(%rsp)
  7602f9:	movaps %xmm1,0x20(%rsp)
  7602fe:	movaps %xmm0,0x10(%rsp)
  760303:	lea    0x60(%rsp),%rdi
  760308:	lea    0x10(%rsp),%rsi
  76030d:	call   7986e0 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control>
  760312:	cmpq   $0x0,0x60(%rsp)
  760318:	je     7605dd <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x33d>
  76031e:	mov    $0x1,%ebx
  760323:	mov    0x48(%rsp),%rax
  760328:	mov    %rax,0x80(%rsp)
  760330:	movss  0x50(%rsp),%xmm0
  760336:	movss  %xmm0,0xc(%rsp)
  76033c:	mov    0x10(%rsp),%r12
  760341:	mov    0x18(%rsp),%rbp
  760346:	mov    0x30(%rsp),%r13
  76034b:	mov    0x28(%rsp),%r14
  760350:	mov    0x20(%rsp),%r15
  760355:	data16 cs nopw 0x0(%rax,%rax,1)
  760360:	lea    0x88(%rsp),%rdi
  760368:	mov    0x80(%rsp),%rsi
  760370:	movss  0xc(%rsp),%xmm0
  760376:	lea    0x60(%rsp),%rdx
  76037b:	call   75d580 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control>
  760380:	cmpb   $0x2,0x8c(%rsp)
  760388:	jne    760550 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x2b0>
  76038e:	mov    %rbp,%rax
  760391:	cmp    $0x1,%rbp
  760395:	je     7603d4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x134>
  760397:	test   %rbp,%rbp
  76039a:	je     7605e2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x342>
  7603a0:	mov    (%r12),%ecx
  7603a4:	lea    0xc(%r12),%rdx
  7603a9:	lea    0x1(%rbp),%rsi
  7603ad:	mov    $0x1,%eax
  7603b2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  7603c0:	cmp    (%rdx),%ecx
  7603c2:	jne    7603d4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x134>
  7603c4:	inc    %rax
  7603c7:	add    $0xc,%rdx
  7603cb:	dec    %rsi
  7603ce:	cmp    $0x2,%rsi
  7603d2:	ja     7603c0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x120>
  7603d4:	sub    %rax,%rbp
  7603d7:	jb     7605f7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x357>
  7603dd:	mov    %rbp,0x18(%rsp)
  7603e2:	test   %r13,%r13
  7603e5:	jne    76047b <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x1db>
  7603eb:	mov    %r14,%rcx
  7603ee:	cmp    $0x1,%r14
  7603f2:	je     760424 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x184>
  7603f4:	test   %r14,%r14
  7603f7:	je     7605e2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x342>
  7603fd:	mov    (%r15),%edx
  760400:	lea    0xc(%r15),%rsi
  760404:	lea    0x1(%r14),%rdi
  760408:	mov    $0x1,%ecx
  76040d:	nopl   (%rax)
  760410:	cmp    (%rsi),%edx
  760412:	jne    760424 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x184>
  760414:	inc    %rcx
  760417:	add    $0xc,%rsi
  76041b:	dec    %rdi
  76041e:	cmp    $0x2,%rdi
  760422:	ja     760410 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x170>
  760424:	sub    %rcx,%r14
  760427:	jb     7605f7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x357>
  76042d:	lea    (%rcx,%rcx,2),%rdx
  760431:	lea    (%r15,%rdx,4),%rdx
  760435:	mov    %rdx,0x20(%rsp)
  76043a:	mov    %r14,0x28(%rsp)
  76043f:	test   %r15,%r15
  760442:	je     7605e2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x342>
  760448:	lea    (%rax,%rax,2),%rsi
  76044c:	mov    %r12,0x60(%rsp)
  760451:	mov    %rax,0x68(%rsp)
  760456:	mov    %r15,0x70(%rsp)
  76045b:	mov    %rcx,0x78(%rsp)
  760460:	mov    %rdx,%r15
  760463:	mov    $0x0,%r13d
  760469:	test   %r12,%r12
  76046c:	lea    (%r12,%rsi,4),%r12
  760470:	jne    760360 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0xc0>
  760476:	jmp    7605e2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x342>
  76047b:	movq   $0x0,0x30(%rsp)
  760484:	mov    %r15,%rsi
  760487:	mov    %r14,%rdx
  76048a:	mov    %r14,%rdi
  76048d:	cmp    $0x1,%r14
  760491:	je     7604c5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x225>
  760493:	test   %rdx,%rdx
  760496:	je     7605e2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x342>
  76049c:	mov    (%rsi),%ecx
  76049e:	lea    0xc(%rsi),%r8
  7604a2:	lea    0x1(%rdx),%r9
  7604a6:	mov    $0x1,%edi
  7604ab:	nopl   0x0(%rax,%rax,1)
  7604b0:	cmp    (%r8),%ecx
  7604b3:	jne    7604c5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x225>
  7604b5:	inc    %rdi
  7604b8:	add    $0xc,%r8
  7604bc:	dec    %r9
  7604bf:	cmp    $0x2,%r9
  7604c3:	ja     7604b0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x210>
  7604c5:	mov    %rdx,%r14
  7604c8:	sub    %rdi,%r14
  7604cb:	jb     7605f7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x357>
  7604d1:	lea    (%rdi,%rdi,2),%r9
  7604d5:	lea    (%rsi,%r9,4),%r15
  7604d9:	dec    %r13
  7604dc:	jne    760484 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x1e4>
  7604de:	mov    %r15,0x20(%rsp)
  7604e3:	mov    %r14,0x28(%rsp)
  7604e8:	mov    %r14,%rcx
  7604eb:	cmp    $0x1,%r14
  7604ef:	je     760525 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x285>
  7604f1:	test   %r14,%r14
  7604f4:	je     7605e2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x342>
  7604fa:	mov    (%r15),%r8d
  7604fd:	lea    (%rsi,%r9,4),%rsi
  760501:	add    $0xc,%rsi
  760505:	sub    %rdi,%rdx
  760508:	inc    %rdx
  76050b:	mov    $0x1,%ecx
  760510:	cmp    (%rsi),%r8d
  760513:	jne    760525 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x285>
  760515:	inc    %rcx
  760518:	add    $0xc,%rsi
  76051c:	dec    %rdx
  76051f:	cmp    $0x2,%rdx
  760523:	ja     760510 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x270>
  760525:	sub    %rcx,%r14
  760528:	jb     7605f7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x357>
  76052e:	lea    (%rcx,%rcx,2),%rdx
  760532:	lea    (%r15,%rdx,4),%rdx
  760536:	mov    %rdx,0x20(%rsp)
  76053b:	mov    %r14,0x28(%rsp)
  760540:	jmp    760448 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x1a8>
  760545:	data16 cs nopw 0x0(%rax,%rax,1)
  760550:	mov    %r12,0x10(%rsp)
  760555:	mov    0x88(%rsp),%eax
  76055c:	mov    0x90(%rsp),%ecx
  760563:	mov    0x98(%rsp),%edx
  76056a:	mov    0x9c(%rsp),%esi
  760571:	mov    0xa0(%rsp),%edi
  760578:	mov    0xa4(%rsp),%r8d
  760580:	xor    %rax,%rbx
  760583:	movabs $0x100000001b3,%rax
  76058d:	imul   %rax,%rbx
  760591:	xor    %rcx,%rbx
  760594:	imul   %rax,%rbx
  760598:	xor    0xa8(%rsp),%rbx
  7605a0:	imul   %rax,%rbx
  7605a4:	xor    %rdx,%rbx
  7605a7:	imul   %rax,%rbx
  7605ab:	xor    %rsi,%rbx
  7605ae:	imul   %rax,%rbx
  7605b2:	xor    %rdi,%rbx
  7605b5:	imul   %rax,%rbx
  7605b9:	xor    %r8,%rbx
  7605bc:	imul   %rax,%rbx
  7605c0:	lea    0x60(%rsp),%rdi
  7605c5:	lea    0x10(%rsp),%rsi
  7605ca:	call   7986e0 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control>
  7605cf:	cmpq   $0x0,0x60(%rsp)
  7605d5:	jne    760323 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x83>
  7605db:	jmp    7605e2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript+0x342>
  7605dd:	mov    $0x1,%ebx
  7605e2:	mov    %rbx,%rax
  7605e5:	add    $0x108,%rsp
  7605ec:	pop    %rbx
  7605ed:	pop    %r12
  7605ef:	pop    %r13
  7605f1:	pop    %r14
  7605f3:	pop    %r15
  7605f5:	pop    %rbp
  7605f6:	ret
  7605f7:	lea    -0x69095d(%rip),%rdi        # cfca1 <GCC_except_table0+0xd899>
  7605fe:	lea    0x33b88b(%rip),%rdx        # a9be90 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x23a8>
  760605:	mov    $0x13,%esi
  76060a:	call   *0x359ca8(%rip)        # aba2b8 <_DYNAMIC+0x278>

canonical_text_public_control::query_selection bytes=1484 frame=312

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000760610 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection>:
  760610:	push   %rbp
  760611:	push   %r15
  760613:	push   %r14
  760615:	push   %r13
  760617:	push   %r12
  760619:	push   %rbx
  76061a:	sub    $0x108,%rsp
  760621:	mov    %rsi,%rbx
  760624:	mov    %rdi,%r14
  760627:	call   *0x359cd3(%rip)        # aba300 <_DYNAMIC+0x2c0>
  76062d:	test   %al,%al
  76062f:	je     760bc3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x5b3>
  760635:	mov    (%rbx),%esi
  760637:	mov    0x8(%rbx),%eax
  76063a:	mov    $0x1,%ebx
  76063f:	cmp    %esi,%eax
  760641:	je     760b95 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x585>
  760647:	mov    %esi,%edx
  760649:	cmova  %eax,%edx
  76064c:	cmovb  %eax,%esi
  76064f:	mov    %r14,%rdi
  760652:	call   *0x359cb0(%rip)        # aba308 <_DYNAMIC+0x2c8>
  760658:	mov    %rdx,%rcx
  76065b:	movss  0x4c(%r14),%xmm0
  760661:	mulss  -0x69e151(%rip),%xmm0        # c2518 <GCC_except_table0+0x110>
  760669:	lea    0x88(%rsp),%r15
  760671:	mov    %r15,%rdi
  760674:	mov    %r14,%rsi
  760677:	mov    %rax,%rdx
  76067a:	call   *0x359c90(%rip)        # aba310 <_DYNAMIC+0x2d0>
  760680:	lea    0x68(%rsp),%rdi
  760685:	mov    %r15,%rsi
  760688:	call   7986e0 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control>
  76068d:	cmpq   $0x0,0x68(%rsp)
  760693:	je     760b95 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x585>
  760699:	mov    $0x1,%ebx
  76069e:	movq   $0x0,0x48(%rsp)
  7606a7:	mov    $0x1,%eax
  7606ac:	mov    %rax,0x40(%rsp)
  7606b1:	movss  %xmm3,0x10(%rsp)
  7606b7:	movss  %xmm0,0xc(%rsp)
  7606bd:	movaps %xmm2,%xmm0
  7606c0:	movaps %xmm1,0x30(%rsp)
  7606c5:	mov    %rbx,0x18(%rsp)
  7606ca:	mov    0xc0(%rsp),%r13
  7606d2:	movss  0xc8(%rsp),%xmm1
  7606db:	movss  %xmm1,0x14(%rsp)
  7606e1:	mov    0x88(%rsp),%rbp
  7606e9:	mov    0x90(%rsp),%r12
  7606f1:	mov    0xa8(%rsp),%rbx
  7606f9:	mov    0xa0(%rsp),%r14
  760701:	mov    0x98(%rsp),%r15
  760709:	movaps %xmm0,0x50(%rsp)
  76070e:	xchg   %ax,%ax
  760710:	lea    0xd0(%rsp),%rdi
  760718:	mov    %r13,%rsi
  76071b:	movss  0x14(%rsp),%xmm0
  760721:	lea    0x68(%rsp),%rdx
  760726:	call   75d580 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control>
  76072b:	cmpb   $0x2,0xd4(%rsp)
  760733:	jne    760911 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x301>
  760739:	mov    %r12,%rax
  76073c:	cmp    $0x1,%r12
  760740:	movaps 0x50(%rsp),%xmm0
  760745:	je     760784 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x174>
  760747:	test   %r12,%r12
  76074a:	je     760b34 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x524>
  760750:	mov    0x0(%rbp),%ecx
  760753:	lea    0xc(%rbp),%rdx
  760757:	lea    0x1(%r12),%rsi
  76075c:	mov    $0x1,%eax
  760761:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  760770:	cmp    (%rdx),%ecx
  760772:	jne    760784 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x174>
  760774:	inc    %rax
  760777:	add    $0xc,%rdx
  76077b:	dec    %rsi
  76077e:	cmp    $0x2,%rsi
  760782:	ja     760770 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x160>
  760784:	sub    %rax,%r12
  760787:	jb     760baa <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x59a>
  76078d:	mov    %r12,0x90(%rsp)
  760795:	test   %rbx,%rbx
  760798:	jne    760834 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x224>
  76079e:	mov    %r14,%rcx
  7607a1:	cmp    $0x1,%r14
  7607a5:	je     7607d4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x1c4>
  7607a7:	test   %r14,%r14
  7607aa:	je     760b34 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x524>
  7607b0:	mov    (%r15),%edx
  7607b3:	lea    0xc(%r15),%rsi
  7607b7:	lea    0x1(%r14),%rdi
  7607bb:	mov    $0x1,%ecx
  7607c0:	cmp    (%rsi),%edx
  7607c2:	jne    7607d4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x1c4>
  7607c4:	inc    %rcx
  7607c7:	add    $0xc,%rsi
  7607cb:	dec    %rdi
  7607ce:	cmp    $0x2,%rdi
  7607d2:	ja     7607c0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x1b0>
  7607d4:	sub    %rcx,%r14
  7607d7:	jb     760baa <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x59a>
  7607dd:	lea    (%rcx,%rcx,2),%rdx
  7607e1:	lea    (%r15,%rdx,4),%rdx
  7607e5:	mov    %rdx,0x98(%rsp)
  7607ed:	mov    %r14,0xa0(%rsp)
  7607f5:	test   %r15,%r15
  7607f8:	je     760b34 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x524>
  7607fe:	lea    (%rax,%rax,2),%rsi
  760802:	mov    %rbp,0x68(%rsp)
  760807:	mov    %rax,0x70(%rsp)
  76080c:	mov    %r15,0x78(%rsp)
  760811:	mov    %rcx,0x80(%rsp)
  760819:	mov    %rdx,%r15
  76081c:	mov    $0x0,%ebx
  760821:	test   %rbp,%rbp
  760824:	lea    0x0(%rbp,%rsi,4),%rbp
  760829:	jne    760710 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x100>
  76082f:	jmp    760b34 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x524>
  760834:	movq   $0x0,0xa8(%rsp)
  760840:	mov    %r15,%rsi
  760843:	mov    %r14,%rdx
  760846:	mov    %r14,%rdi
  760849:	cmp    $0x1,%r14
  76084d:	je     760885 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x275>
  76084f:	test   %rdx,%rdx
  760852:	je     760b34 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x524>
  760858:	mov    (%rsi),%ecx
  76085a:	lea    0xc(%rsi),%r8
  76085e:	lea    0x1(%rdx),%r9
  760862:	mov    $0x1,%edi
  760867:	nopw   0x0(%rax,%rax,1)
  760870:	cmp    (%r8),%ecx
  760873:	jne    760885 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x275>
  760875:	inc    %rdi
  760878:	add    $0xc,%r8
  76087c:	dec    %r9
  76087f:	cmp    $0x2,%r9
  760883:	ja     760870 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x260>
  760885:	mov    %rdx,%r14
  760888:	sub    %rdi,%r14
  76088b:	jb     760baa <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x59a>
  760891:	lea    (%rdi,%rdi,2),%r9
  760895:	lea    (%rsi,%r9,4),%r15
  760899:	dec    %rbx
  76089c:	jne    760840 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x230>
  76089e:	mov    %r15,0x98(%rsp)
  7608a6:	mov    %r14,0xa0(%rsp)
  7608ae:	mov    %r14,%rcx
  7608b1:	cmp    $0x1,%r14
  7608b5:	je     7608eb <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x2db>
  7608b7:	test   %r14,%r14
  7608ba:	je     760b34 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x524>
  7608c0:	mov    (%r15),%r8d
  7608c3:	lea    (%rsi,%r9,4),%rsi
  7608c7:	add    $0xc,%rsi
  7608cb:	sub    %rdi,%rdx
  7608ce:	inc    %rdx
  7608d1:	mov    $0x1,%ecx
  7608d6:	cmp    (%rsi),%r8d
  7608d9:	jne    7608eb <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x2db>
  7608db:	inc    %rcx
  7608de:	add    $0xc,%rsi
  7608e2:	dec    %rdx
  7608e5:	cmp    $0x2,%rdx
  7608e9:	ja     7608d6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x2c6>
  7608eb:	sub    %rcx,%r14
  7608ee:	jb     760baa <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x59a>
  7608f4:	lea    (%rcx,%rcx,2),%rdx
  7608f8:	lea    (%r15,%rdx,4),%rdx
  7608fc:	mov    %rdx,0x98(%rsp)
  760904:	mov    %r14,0xa0(%rsp)
  76090c:	jmp    7607fe <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x1ee>
  760911:	mov    %rbp,0x88(%rsp)
  760919:	movss  0xe8(%rsp),%xmm2
  760922:	xorps  %xmm0,%xmm0
  760925:	ucomiss %xmm0,%xmm2
  760928:	jne    760936 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x326>
  76092a:	jp     760936 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x326>
  76092c:	mov    0x18(%rsp),%rbx
  760931:	jmp    760a16 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x406>
  760936:	movss  0xe0(%rsp),%xmm5
  76093f:	movss  0xe4(%rsp),%xmm6
  760948:	movss  0xec(%rsp),%xmm3
  760951:	mov    0xf0(%rsp),%rax
  760959:	testb  $0x1,0x48(%rsp)
  76095e:	mov    0x18(%rsp),%rbx
  760963:	movaps 0x30(%rsp),%xmm0
  760968:	je     760a3e <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x42e>
  76096e:	cmp    %rax,0x20(%rsp)
  760973:	jne    760a71 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x461>
  760979:	movss  0x10(%rsp),%xmm0
  76097f:	ucomiss %xmm6,%xmm0
  760982:	jne    760a6c <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x45c>
  760988:	jp     760a6c <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x45c>
  76098e:	movss  0xc(%rsp),%xmm0
  760994:	ucomiss %xmm3,%xmm0
  760997:	movaps 0x30(%rsp),%xmm0
  76099c:	jne    760a71 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x461>
  7609a2:	jp     760a71 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x461>
  7609a8:	movaps %xmm5,%xmm1
  7609ab:	addss  %xmm2,%xmm1
  7609af:	ucomiss %xmm0,%xmm1
  7609b2:	jb     760a60 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x450>
  7609b8:	movaps %xmm0,%xmm4
  7609bb:	movaps 0x50(%rsp),%xmm0
  7609c0:	addss  %xmm4,%xmm0
  7609c4:	ucomiss %xmm5,%xmm0
  7609c7:	mov    0x20(%rsp),%rax
  7609cc:	jb     760a67 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x457>
  7609d2:	movaps %xmm0,%xmm2
  7609d5:	maxss  %xmm1,%xmm2
  7609d9:	movaps %xmm2,%xmm3
  7609dc:	cmpunordss %xmm2,%xmm3
  7609e1:	movaps %xmm3,%xmm1
  7609e4:	andnps %xmm2,%xmm1
  7609e7:	andps  %xmm0,%xmm3
  7609ea:	orps   %xmm1,%xmm3
  7609ed:	movaps %xmm4,%xmm0
  7609f0:	minss  %xmm5,%xmm0
  7609f4:	movaps %xmm0,%xmm1
  7609f7:	cmpunordss %xmm0,%xmm1
  7609fc:	movaps %xmm1,%xmm2
  7609ff:	andnps %xmm0,%xmm2
  760a02:	andps  %xmm4,%xmm1
  760a05:	orps   %xmm2,%xmm1
  760a08:	subss  %xmm1,%xmm3
  760a0c:	movaps %xmm3,0x50(%rsp)
  760a11:	movaps %xmm1,0x30(%rsp)
  760a16:	lea    0x68(%rsp),%rdi
  760a1b:	lea    0x88(%rsp),%rsi
  760a23:	call   7986e0 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control>
  760a28:	cmpq   $0x0,0x68(%rsp)
  760a2e:	movaps 0x50(%rsp),%xmm0
  760a33:	jne    7606ca <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0xba>
  760a39:	jmp    760b39 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x529>
  760a3e:	movss  %xmm6,0x28(%rsp)
  760a44:	movss  %xmm3,0x2c(%rsp)
  760a4a:	movss  %xmm2,0x30(%rsp)
  760a50:	movss  %xmm5,0x14(%rsp)
  760a56:	mov    %rax,0x20(%rsp)
  760a5b:	jmp    760ae9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x4d9>
  760a60:	mov    0x20(%rsp),%rax
  760a65:	jmp    760a71 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x461>
  760a67:	movaps %xmm4,%xmm0
  760a6a:	jmp    760a71 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x461>
  760a6c:	movaps 0x30(%rsp),%xmm0
  760a71:	movss  %xmm6,0x28(%rsp)
  760a77:	movss  %xmm3,0x2c(%rsp)
  760a7d:	movss  %xmm2,0x30(%rsp)
  760a83:	movss  %xmm5,0x14(%rsp)
  760a89:	movd   %xmm0,%ecx
  760a8d:	movd   0x10(%rsp),%xmm0
  760a93:	movd   %xmm0,%edx
  760a97:	movdqa 0x50(%rsp),%xmm0
  760a9d:	movd   %xmm0,%esi
  760aa1:	movd   0xc(%rsp),%xmm0
  760aa7:	movd   %xmm0,%ebx
  760aab:	mov    0x40(%rsp),%rdi
  760ab0:	xor    %rcx,%rdi
  760ab3:	movabs $0x100000001b3,%rcx
  760abd:	imul   %rcx,%rdi
  760ac1:	xor    %rdi,%rdx
  760ac4:	imul   %rcx,%rdx
  760ac8:	xor    %rdx,%rsi
  760acb:	imul   %rcx,%rsi
  760acf:	xor    %rsi,%rbx
  760ad2:	imul   %rcx,%rbx
  760ad6:	xor    0x20(%rsp),%rbx
  760adb:	imul   %rcx,%rbx
  760adf:	mov    %rax,0x20(%rsp)
  760ae4:	mov    %rbx,0x40(%rsp)
  760ae9:	lea    0x68(%rsp),%rdi
  760aee:	lea    0x88(%rsp),%rsi
  760af6:	call   7986e0 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control>
  760afb:	mov    $0x1,%al
  760afd:	mov    %rax,0x48(%rsp)
  760b02:	cmpq   $0x0,0x68(%rsp)
  760b08:	movss  0x14(%rsp),%xmm1
  760b0e:	movss  0x30(%rsp),%xmm2
  760b14:	movss  0x2c(%rsp),%xmm0
  760b1a:	movss  0x28(%rsp),%xmm3
  760b20:	jne    7606b1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0xa1>
  760b26:	movss  %xmm0,0xc(%rsp)
  760b2c:	movss  %xmm3,0x10(%rsp)
  760b32:	jmp    760b48 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x538>
  760b34:	mov    0x18(%rsp),%rbx
  760b39:	movaps %xmm0,%xmm2
  760b3c:	movaps 0x30(%rsp),%xmm1
  760b41:	testb  $0x1,0x48(%rsp)
  760b46:	je     760b95 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection+0x585>
  760b48:	movd   %xmm1,%eax
  760b4c:	movd   0x10(%rsp),%xmm0
  760b52:	movd   %xmm0,%ecx
  760b56:	movd   %xmm2,%edx
  760b5a:	movd   0xc(%rsp),%xmm0
  760b60:	movd   %xmm0,%ebx
  760b64:	xor    0x40(%rsp),%rax
  760b69:	movabs $0x100000001b3,%rsi
  760b73:	imul   %rsi,%rax
  760b77:	xor    %rax,%rcx
  760b7a:	imul   %rsi,%rcx
  760b7e:	xor    %rcx,%rdx
  760b81:	imul   %rsi,%rdx
  760b85:	xor    %rdx,%rbx
  760b88:	imul   %rsi,%rbx
  760b8c:	xor    0x20(%rsp),%rbx
  760b91:	imul   %rsi,%rbx
  760b95:	mov    %rbx,%rax
  760b98:	add    $0x108,%rsp
  760b9f:	pop    %rbx
  760ba0:	pop    %r12
  760ba2:	pop    %r13
  760ba4:	pop    %r14
  760ba6:	pop    %r15
  760ba8:	pop    %rbp
  760ba9:	ret
  760baa:	lea    -0x690f10(%rip),%rdi        # cfca1 <GCC_except_table0+0xd899>
  760bb1:	lea    0x33b2d8(%rip),%rdx        # a9be90 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x23a8>
  760bb8:	mov    $0x13,%esi
  760bbd:	call   *0x3596f5(%rip)        # aba2b8 <_DYNAMIC+0x278>
  760bc3:	lea    -0x6910f6(%rip),%rdi        # cfad4 <GCC_except_table0+0xd6cc>
  760bca:	lea    0x339dd7(%rip),%rdx        # a9a9a8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xec0>
  760bd1:	mov    $0x73,%esi
  760bd6:	call   *0x35971c(%rip)        # aba2f8 <_DYNAMIC+0x2b8>

canonical_text_public_control::ack bytes=358 frame=136

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000760be0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack>:
  760be0:	push   %r14
  760be2:	push   %rbx
  760be3:	sub    $0x78,%rsp
  760be7:	test   %rsi,%rsi
  760bea:	je     760c94 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack+0xb4>
  760bf0:	cmpb   $0x0,0x76e(%rsi)
  760bf7:	jne    760c9b <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack+0xbb>
  760bfd:	mov    0x6d0(%rsi),%rdx
  760c04:	test   %rdx,%rdx
  760c07:	je     760ca2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack+0xc2>
  760c0d:	mov    %rdi,%rbx
  760c10:	mov    0x6d8(%rsi),%rcx
  760c17:	lea    0x8(%rsp),%rdi
  760c1c:	call   77bbc0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_>
  760c21:	cmpq   $0xfffffffffffffffe,0x8(%rsp)
  760c27:	jne    760cdf <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack+0xff>
  760c2d:	movups 0x10(%rsp),%xmm0
  760c32:	movups 0x20(%rsp),%xmm1
  760c37:	movups 0x30(%rsp),%xmm2
  760c3c:	movups %xmm2,0x20(%rbx)
  760c40:	movups %xmm1,0x10(%rbx)
  760c44:	movups %xmm0,(%rbx)
  760c47:	cmpb   $0x0,0x28(%rbx)
  760c4b:	je     760c5f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack+0x7f>
  760c4d:	mov    0x10(%rbx),%rax
  760c51:	cmp    0x18(%rbx),%rax
  760c55:	jne    760c78 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack+0x98>
  760c57:	add    $0x78,%rsp
  760c5b:	pop    %rbx
  760c5c:	pop    %r14
  760c5e:	ret
  760c5f:	lea    -0x69111f(%rip),%rdi        # cfb47 <GCC_except_table0+0xd73f>
  760c66:	lea    0x339d83(%rip),%rdx        # a9a9f0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xf08>
  760c6d:	mov    $0x2b,%esi
  760c72:	call   *0x359680(%rip)        # aba2f8 <_DYNAMIC+0x2b8>
  760c78:	lea    0x10(%rbx),%rsi
  760c7c:	add    $0x18,%rbx
  760c80:	lea    0x339d81(%rip),%r9        # a9aa08 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xf20>
  760c87:	xor    %edi,%edi
  760c89:	mov    %rbx,%rdx
  760c8c:	xor    %ecx,%ecx
  760c8e:	call   *0x35986c(%rip)        # aba500 <_DYNAMIC+0x4c0>
  760c94:	mov    $0xd,%eax
  760c99:	jmp    760ca7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack+0xc7>
  760c9b:	mov    $0xe,%eax
  760ca0:	jmp    760ca7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack+0xc7>
  760ca2:	mov    $0x14,%eax
  760ca7:	mov    %rax,0x40(%rsp)
  760cac:	movq   $0x0,0x48(%rsp)
  760cb5:	lea    -0x691012(%rip),%rdi        # cfcaa <GCC_except_table0+0xd8a2>
  760cbc:	lea    0x33a06d(%rip),%rcx        # a9ad30 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1248>
  760cc3:	lea    0x339cf6(%rip),%r8        # a9a9c0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xed8>
  760cca:	lea    0x40(%rsp),%rbx
  760ccf:	mov    $0x2b,%esi
  760cd4:	mov    %rbx,%rdx
  760cd7:	call   *0x359673(%rip)        # aba350 <_DYNAMIC+0x310>
  760cdd:	jmp    760d2f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack+0x14f>
  760cdf:	mov    0x38(%rsp),%rax
  760ce4:	mov    %rax,0x70(%rsp)
  760ce9:	movups 0x8(%rsp),%xmm0
  760cee:	movups 0x18(%rsp),%xmm1
  760cf3:	movups 0x28(%rsp),%xmm2
  760cf8:	movaps %xmm2,0x60(%rsp)
  760cfd:	movaps %xmm1,0x50(%rsp)
  760d02:	movaps %xmm0,0x40(%rsp)
  760d07:	lea    -0x691064(%rip),%rdi        # cfcaa <GCC_except_table0+0xd8a2>
  760d0e:	lea    0x33a01b(%rip),%rcx        # a9ad30 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1248>
  760d15:	lea    0x339cbc(%rip),%r8        # a9a9d8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xef0>
  760d1c:	lea    0x40(%rsp),%rbx
  760d21:	mov    $0x2b,%esi
  760d26:	mov    %rbx,%rdx
  760d29:	call   *0x359621(%rip)        # aba350 <_DYNAMIC+0x310>
  760d2f:	ud2
  760d31:	jmp    760d33 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack+0x153>
  760d33:	mov    %rax,%r14
  760d36:	mov    %rbx,%rdi
  760d39:	call   74d810 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  760d3e:	mov    %r14,%rdi
  760d41:	call   a98730 <_Unwind_Resume@plt>

canonical_text_public_control::run bytes=10487 frame=936

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000760d50 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run>:
  760d50:	push   %rbp
  760d51:	push   %r15
  760d53:	push   %r14
  760d55:	push   %r13
  760d57:	push   %r12
  760d59:	push   %rbx
  760d5a:	sub    $0x378,%rsp
  760d61:	mov    %rsi,0x310(%rsp)
  760d69:	mov    %rdx,0x318(%rsp)
  760d71:	mov    %rcx,0x2d8(%rsp)
  760d79:	mov    %r8,0x2e0(%rsp)
  760d81:	test   %r9,%r9
  760d84:	je     762dd2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2082>
  760d8a:	mov    %rdx,%r13
  760d8d:	mov    %rsi,%r12
  760d90:	mov    %rdi,%r14
  760d93:	mov    %r9,0x148(%rsp)
  760d9b:	lea    0x228(%rsp),%rbx
  760da3:	mov    %rbx,%rdi
  760da6:	call   7664b0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source>
  760dab:	lea    0x158(%rsp),%r15
  760db3:	mov    %r15,%rdi
  760db6:	mov    %rbx,%rsi
  760db9:	call   *0x359749(%rip)        # aba508 <_DYNAMIC+0x4c8>
  760dbf:	cmpq   $0x0,0x238(%rsp)
  760dc8:	je     760e5b <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x10b>
  760dce:	mov    0x230(%rsp),%rcx
  760dd6:	movzbl (%rcx),%edi
  760dd9:	mov    $0x1,%esi
  760dde:	test   %dil,%dil
  760de1:	js     7614c5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x775>
  760de7:	mov    0x168(%rsp),%rdx
  760def:	mov    %rdx,%rax
  760df2:	sub    %rsi,%rax
  760df5:	jb     762e9e <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x214e>
  760dfb:	mov    0x160(%rsp),%rcx
  760e03:	jbe    760e0f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xbf>
  760e05:	cmpb   $0xc0,(%rcx,%rsi,1)
  760e09:	jl     762ed7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2187>
  760e0f:	movq   $0x0,0x168(%rsp)
  760e1b:	mov    %rcx,0x20(%rsp)
  760e20:	add    %rsi,%rcx
  760e23:	mov    %rcx,0x28(%rsp)
  760e28:	mov    %r15,0x30(%rsp)
  760e2d:	mov    %rsi,0x38(%rsp)
  760e32:	mov    %rax,0x40(%rsp)
  760e37:	lea    -0x6912b1(%rip),%rax        # cfb8d <GCC_except_table0+0xd785>
  760e3e:	mov    %rax,0x48(%rsp)
  760e43:	lea    -0x6912bc(%rip),%rax        # cfb8e <GCC_except_table0+0xd786>
  760e4a:	mov    %rax,0x50(%rsp)
  760e4f:	lea    0x20(%rsp),%rdi
  760e54:	call   749100 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtCscdodAO9FK5_5alloc3vec6splice6SpliceNtNtNtB4_3str4iter5BytesEECs9C2G9YFESsD_29canonical_text_public_control>
  760e59:	jmp    760e88 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x138>
  760e5b:	mov    0x168(%rsp),%rbx
  760e63:	cmp    %rbx,0x158(%rsp)
  760e6b:	je     762eb2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2162>
  760e71:	mov    0x160(%rsp),%rax
  760e79:	movb   $0x62,(%rax,%rbx,1)
  760e7d:	inc    %rbx
  760e80:	mov    %rbx,0x168(%rsp)
  760e88:	lea    0x2c0(%rsp),%rdi
  760e90:	lea    0x228(%rsp),%rsi
  760e98:	call   *0x35966a(%rip)        # aba508 <_DYNAMIC+0x4c8>
  760e9e:	mov    %r13,0x128(%rsp)
  760ea6:	mov    %r12,0x2e8(%rsp)
  760eae:	mov    %r14,0x2f8(%rsp)
  760eb6:	mov    $0x1,%bpl
  760eb9:	lea    0x20(%rsp),%rdi
  760ebe:	call   *0x35964c(%rip)        # aba510 <_DYNAMIC+0x4d0>
  760ec4:	cmpl   $0x1,0x20(%rsp)
  760ec9:	je     762deb <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x209b>
  760ecf:	mov    0x28(%rsp),%rax
  760ed4:	mov    %rax,0x150(%rsp)
  760edc:	lea    0x150(%rsp),%rax
  760ee4:	mov    %rax,0xc0(%rsp)
  760eec:	movq   $0x0,0xc8(%rsp)
  760ef8:	mov    0x230(%rsp),%rdx
  760f00:	mov    0x238(%rsp),%rcx
  760f08:	lea    0x20(%rsp),%rdi
  760f0d:	lea    0xc0(%rsp),%rsi
  760f15:	movss  -0x69ea01(%rip),%xmm0        # c251c <GCC_except_table0+0x114>
  760f1d:	movss  -0x69ea29(%rip),%xmm1        # c24fc <GCC_except_table0+0xf4>
  760f25:	mov    $0x1,%r8d
  760f2b:	call   *0x3595e7(%rip)        # aba518 <_DYNAMIC+0x4d8>
  760f31:	cmpq   $0xffffffffffffffff,0x20(%rsp)
  760f37:	je     762e25 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x20d5>
  760f3d:	mov    0x50(%rsp),%rax
  760f42:	mov    %rax,0x370(%rsp)
  760f4a:	movups 0x20(%rsp),%xmm0
  760f4f:	movups 0x30(%rsp),%xmm1
  760f54:	movups 0x40(%rsp),%xmm2
  760f59:	movaps %xmm2,0x360(%rsp)
  760f61:	movaps %xmm1,0x350(%rsp)
  760f69:	movaps %xmm0,0x340(%rsp)
  760f71:	mov    0xc8(%rsp),%rdi
  760f79:	call   74cd80 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text10TextShaperECs9C2G9YFESsD_29canonical_text_public_control>
  760f7e:	mov    0x360(%rsp),%rsi
  760f86:	test   %rsi,%rsi
  760f89:	je     762e5f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x210f>
  760f8f:	add    $0x10,%rsi
  760f93:	lea    0xc0(%rsp),%rdi
  760f9b:	mov    %rsi,0x140(%rsp)
  760fa3:	call   *0x35954f(%rip)        # aba4f8 <_DYNAMIC+0x4b8>
  760fa9:	mov    0xf8(%rsp),%rbx
  760fb1:	movss  0x100(%rsp),%xmm0
  760fba:	movss  %xmm0,0x8(%rsp)
  760fc0:	lea    0x1b0(%rsp),%rdi
  760fc8:	lea    0xc0(%rsp),%rsi
  760fd0:	call   7986e0 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control>
  760fd5:	cmpq   $0x0,0x1b0(%rsp)
  760fde:	je     761035 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2e5>
  760fe0:	lea    0x20(%rsp),%r14
  760fe5:	lea    0x1b0(%rsp),%r15
  760fed:	lea    0xc0(%rsp),%r12
  760ff5:	data16 cs nopw 0x0(%rax,%rax,1)
  761000:	mov    %r14,%rdi
  761003:	mov    %rbx,%rsi
  761006:	movss  0x8(%rsp),%xmm0
  76100c:	mov    %r15,%rdx
  76100f:	call   75d580 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control>
  761014:	movzbl 0x24(%rsp),%ebp
  761019:	cmp    $0x2,%bpl
  76101d:	jne    761049 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2f9>
  76101f:	mov    %r15,%rdi
  761022:	mov    %r12,%rsi
  761025:	call   7986e0 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control>
  76102a:	cmpq   $0x0,0x1b0(%rsp)
  761033:	jne    761000 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2b0>
  761035:	mov    $0x4,%eax
  76103a:	mov    $0x8,%ecx
  76103f:	xor    %edx,%edx
  761041:	xor    %r14d,%r14d
  761044:	jmp    7616da <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x98a>
  761049:	mov    0x20(%rsp),%ebx
  76104d:	mov    0x54(%rsp),%eax
  761051:	mov    %eax,0x26f(%rsp)
  761058:	movups 0x45(%rsp),%xmm0
  76105d:	movaps %xmm0,0x260(%rsp)
  761065:	movups 0x35(%rsp),%xmm0
  76106a:	movaps %xmm0,0x250(%rsp)
  761072:	movups 0x25(%rsp),%xmm0
  761077:	movaps %xmm0,0x240(%rsp)
  76107f:	call   *0x359203(%rip)        # aba288 <_DYNAMIC+0x248>
  761085:	mov    $0xe0,%edi
  76108a:	mov    $0x8,%esi
  76108f:	call   *0x3591fb(%rip)        # aba290 <_DYNAMIC+0x250>
  761095:	test   %rax,%rax
  761098:	je     763232 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x24e2>
  76109e:	mov    %rax,%r15
  7610a1:	mov    0x26f(%rsp),%eax
  7610a8:	mov    %eax,0x34(%r15)
  7610ac:	movaps 0x240(%rsp),%xmm0
  7610b4:	movaps 0x250(%rsp),%xmm1
  7610bc:	movaps 0x260(%rsp),%xmm2
  7610c4:	movups %xmm2,0x25(%r15)
  7610c9:	movups %xmm1,0x15(%r15)
  7610ce:	movups %xmm0,0x5(%r15)
  7610d3:	mov    %ebx,(%r15)
  7610d6:	mov    %bpl,0x4(%r15)
  7610da:	movq   $0x4,0x170(%rsp)
  7610e6:	mov    %r15,0x178(%rsp)
  7610ee:	movq   $0x1,0x180(%rsp)
  7610fa:	mov    0x100(%rsp),%rax
  761102:	mov    %rax,0x60(%rsp)
  761107:	movups 0xc0(%rsp),%xmm0
  76110f:	movups 0xd0(%rsp),%xmm1
  761117:	movups 0xe0(%rsp),%xmm2
  76111f:	movups 0xf0(%rsp),%xmm3
  761127:	movaps %xmm3,0x50(%rsp)
  76112c:	movaps %xmm2,0x40(%rsp)
  761131:	movaps %xmm1,0x30(%rsp)
  761136:	movaps %xmm0,0x20(%rsp)
  76113b:	mov    0x58(%rsp),%rax
  761140:	mov    %rax,0x8(%rsp)
  761145:	movss  0x60(%rsp),%xmm0
  76114b:	movss  %xmm0,0xb8(%rsp)
  761154:	lea    0x290(%rsp),%rdi
  76115c:	lea    0x20(%rsp),%rsi
  761161:	call   7986e0 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control>
  761166:	cmpq   $0x0,0x290(%rsp)
  76116f:	je     761523 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x7d3>
  761175:	mov    $0x1,%r14d
  76117b:	mov    %r15,0x118(%rsp)
  761183:	mov    %r14,0xb0(%rsp)
  76118b:	mov    0x20(%rsp),%r12
  761190:	mov    0x28(%rsp),%r13
  761195:	mov    0x40(%rsp),%rbp
  76119a:	mov    0x38(%rsp),%r14
  76119f:	mov    0x30(%rsp),%r15
  7611a4:	mov    %rbp,0x110(%rsp)
  7611ac:	nopl   0x0(%rax)
  7611b0:	lea    0x240(%rsp),%rdi
  7611b8:	mov    0x8(%rsp),%rsi
  7611bd:	movss  0xb8(%rsp),%xmm0
  7611c6:	lea    0x290(%rsp),%rdx
  7611ce:	call   75d580 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control>
  7611d3:	movzbl 0x244(%rsp),%ebx
  7611db:	cmp    $0x2,%bl
  7611de:	jne    7613a6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x656>
  7611e4:	mov    %r13,%rax
  7611e7:	cmp    $0x1,%r13
  7611eb:	je     761224 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x4d4>
  7611ed:	test   %r13,%r13
  7611f0:	je     761519 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x7c9>
  7611f6:	mov    (%r12),%ecx
  7611fa:	lea    0xc(%r12),%rdx
  7611ff:	lea    0x1(%r13),%rsi
  761203:	mov    $0x1,%eax
  761208:	nopl   0x0(%rax,%rax,1)
  761210:	cmp    (%rdx),%ecx
  761212:	jne    761224 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x4d4>
  761214:	inc    %rax
  761217:	add    $0xc,%rdx
  76121b:	dec    %rsi
  76121e:	cmp    $0x2,%rsi
  761222:	ja     761210 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x4c0>
  761224:	sub    %rax,%r13
  761227:	jb     762d7f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x202f>
  76122d:	test   %rbp,%rbp
  761230:	jne    7612d6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x586>
  761236:	mov    %r14,%rcx
  761239:	cmp    $0x1,%r14
  76123d:	je     761274 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x524>
  76123f:	test   %r14,%r14
  761242:	je     761519 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x7c9>
  761248:	mov    (%r15),%edx
  76124b:	lea    0xc(%r15),%rsi
  76124f:	lea    0x1(%r14),%rdi
  761253:	mov    $0x1,%ecx
  761258:	nopl   0x0(%rax,%rax,1)
  761260:	cmp    (%rsi),%edx
  761262:	jne    761274 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x524>
  761264:	inc    %rcx
  761267:	add    $0xc,%rsi
  76126b:	dec    %rdi
  76126e:	cmp    $0x2,%rdi
  761272:	ja     761260 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x510>
  761274:	sub    %rcx,%r14
  761277:	jb     762d7f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x202f>
  76127d:	lea    (%rcx,%rcx,2),%rdx
  761281:	lea    (%r15,%rdx,4),%rdx
  761285:	mov    %rdx,0x30(%rsp)
  76128a:	mov    %r14,0x38(%rsp)
  76128f:	test   %r15,%r15
  761292:	je     761519 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x7c9>
  761298:	lea    (%rax,%rax,2),%rsi
  76129c:	mov    %r12,0x290(%rsp)
  7612a4:	mov    %rax,0x298(%rsp)
  7612ac:	mov    %r15,0x2a0(%rsp)
  7612b4:	mov    %rcx,0x2a8(%rsp)
  7612bc:	mov    %rdx,%r15
  7612bf:	mov    $0x0,%ebp
  7612c4:	test   %r12,%r12
  7612c7:	lea    (%r12,%rsi,4),%r12
  7612cb:	jne    7611b0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x460>
  7612d1:	jmp    761519 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x7c9>
  7612d6:	mov    %r14,%rdx
  7612d9:	mov    %r15,%rsi
  7612dc:	mov    %r14,%rdi
  7612df:	cmp    $0x1,%r14
  7612e3:	mov    0xb0(%rsp),%r14
  7612eb:	je     76131a <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x5ca>
  7612ed:	test   %rdx,%rdx
  7612f0:	je     761529 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x7d9>
  7612f6:	mov    (%rsi),%ecx
  7612f8:	lea    0xc(%rsi),%r8
  7612fc:	lea    0x1(%rdx),%r9
  761300:	mov    $0x1,%edi
  761305:	cmp    (%r8),%ecx
  761308:	jne    76131a <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x5ca>
  76130a:	inc    %rdi
  76130d:	add    $0xc,%r8
  761311:	dec    %r9
  761314:	cmp    $0x2,%r9
  761318:	ja     761305 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x5b5>
  76131a:	mov    %rdx,%r14
  76131d:	sub    %rdi,%r14
  761320:	jb     762d7f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x202f>
  761326:	lea    (%rdi,%rdi,2),%r9
  76132a:	lea    (%rsi,%r9,4),%r15
  76132e:	dec    %rbp
  761331:	jne    7612d6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x586>
  761333:	mov    %r15,0x30(%rsp)
  761338:	mov    %r14,0x38(%rsp)
  76133d:	mov    %r14,%rcx
  761340:	cmp    $0x1,%r14
  761344:	je     76137a <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x62a>
  761346:	test   %r14,%r14
  761349:	je     761519 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x7c9>
  76134f:	mov    (%r15),%r8d
  761352:	lea    (%rsi,%r9,4),%rsi
  761356:	add    $0xc,%rsi
  76135a:	sub    %rdi,%rdx
  76135d:	inc    %rdx
  761360:	mov    $0x1,%ecx
  761365:	cmp    (%rsi),%r8d
  761368:	jne    76137a <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x62a>
  76136a:	inc    %rcx
  76136d:	add    $0xc,%rsi
  761371:	dec    %rdx
  761374:	cmp    $0x2,%rdx
  761378:	ja     761365 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x615>
  76137a:	sub    %rcx,%r14
  76137d:	jb     762d7f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x202f>
  761383:	lea    (%rcx,%rcx,2),%rdx
  761387:	lea    (%r15,%rdx,4),%rdx
  76138b:	mov    %rdx,0x30(%rsp)
  761390:	mov    %r14,0x38(%rsp)
  761395:	movq   $0x0,0x110(%rsp)
  7613a1:	jmp    761298 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x548>
  7613a6:	mov    %r12,0x20(%rsp)
  7613ab:	mov    %r13,0x28(%rsp)
  7613b0:	mov    0x110(%rsp),%rax
  7613b8:	mov    %rax,0x40(%rsp)
  7613bd:	mov    0x240(%rsp),%ebp
  7613c4:	lea    0x245(%rsp),%rax
  7613cc:	movups (%rax),%xmm0
  7613cf:	movups 0x10(%rax),%xmm1
  7613d3:	movups 0x20(%rax),%xmm2
  7613d7:	movaps %xmm0,0x1b0(%rsp)
  7613df:	movaps %xmm1,0x1c0(%rsp)
  7613e7:	movaps %xmm2,0x1d0(%rsp)
  7613ef:	mov    0x2f(%rax),%eax
  7613f2:	mov    %eax,0x1df(%rsp)
  7613f9:	mov    0xb0(%rsp),%r14
  761401:	cmp    0x170(%rsp),%r14
  761409:	mov    0x118(%rsp),%r15
  761411:	jne    76143b <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x6eb>
  761413:	mov    $0x1,%edx
  761418:	mov    $0x8,%ecx
  76141d:	mov    $0x38,%r8d
  761423:	lea    0x170(%rsp),%rdi
  76142b:	mov    %r14,%rsi
  76142e:	call   75b3f0 <_RINvNvMs2_NtCscdodAO9FK5_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs9C2G9YFESsD_29canonical_text_public_control>
  761433:	mov    0x178(%rsp),%r15
  76143b:	imul   $0x38,%r14,%rax
  76143f:	mov    %ebp,(%r15,%rax,1)
  761443:	mov    %bl,0x4(%r15,%rax,1)
  761448:	movaps 0x1b0(%rsp),%xmm0
  761450:	movaps 0x1c0(%rsp),%xmm1
  761458:	movaps 0x1d0(%rsp),%xmm2
  761460:	movups %xmm0,0x5(%r15,%rax,1)
  761466:	movups %xmm1,0x15(%r15,%rax,1)
  76146c:	movups %xmm2,0x25(%r15,%rax,1)
  761472:	mov    0x1df(%rsp),%ecx
  761479:	mov    %ecx,0x34(%r15,%rax,1)
  76147e:	inc    %r14
  761481:	mov    %r14,0x180(%rsp)
  761489:	mov    0x58(%rsp),%rax
  76148e:	mov    %rax,0x8(%rsp)
  761493:	movss  0x60(%rsp),%xmm0
  761499:	movss  %xmm0,0xb8(%rsp)
  7614a2:	lea    0x290(%rsp),%rdi
  7614aa:	lea    0x20(%rsp),%rsi
  7614af:	call   7986e0 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control>
  7614b4:	cmpq   $0x0,0x290(%rsp)
  7614bd:	jne    76117b <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x42b>
  7614c3:	jmp    761529 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x7d9>
  7614c5:	mov    %edi,%eax
  7614c7:	and    $0x1f,%eax
  7614ca:	movzbl 0x1(%rcx),%r8d
  7614cf:	and    $0x3f,%r8d
  7614d3:	cmp    $0xe0,%dil
  7614d7:	jb     761632 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x8e2>
  7614dd:	movzbl 0x2(%rcx),%edx
  7614e1:	shl    $0x6,%r8d
  7614e5:	and    $0x3f,%edx
  7614e8:	or     %r8d,%edx
  7614eb:	cmp    $0xf0,%dil
  7614ef:	jb     762d43 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1ff3>
  7614f5:	movzbl 0x3(%rcx),%ecx
  7614f9:	and    $0x7,%eax
  7614fc:	shl    $0x12,%eax
  7614ff:	shl    $0x6,%edx
  761502:	and    $0x3f,%ecx
  761505:	or     %edx,%ecx
  761507:	or     %ecx,%eax
  761509:	cmp    $0x80,%eax
  76150e:	jae    762d53 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2003>
  761514:	jmp    760de7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x97>
  761519:	mov    0xb0(%rsp),%r14
  761521:	jmp    761529 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x7d9>
  761523:	mov    $0x1,%r14d
  761529:	mov    0x170(%rsp),%rax
  761531:	mov    %rax,0x130(%rsp)
  761539:	mov    0x178(%rsp),%rax
  761541:	mov    %rax,0xa0(%rsp)
  761549:	lea    0x0(,%r14,4),%rbx
  761551:	call   *0x358d31(%rip)        # aba288 <_DYNAMIC+0x248>
  761557:	mov    $0x4,%esi
  76155c:	mov    %rbx,%rdi
  76155f:	call   *0x358d2b(%rip)        # aba290 <_DYNAMIC+0x250>
  761565:	test   %rax,%rax
  761568:	je     763247 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x24f7>
  76156e:	cmp    $0x14,%r14
  761572:	jb     76159f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x84f>
  761574:	lea    (%rax,%r14,4),%rcx
  761578:	imul   $0x38,%r14,%rdx
  76157c:	mov    0xa0(%rsp),%rsi
  761584:	add    %rsi,%rdx
  761587:	add    $0xffffffffffffffcc,%rdx
  76158b:	cmp    %rdx,%rax
  76158e:	setb   %dl
  761591:	cmp    %rcx,%rsi
  761594:	setb   %cl
  761597:	test   %cl,%dl
  761599:	je     761648 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x8f8>
  76159f:	xor    %ecx,%ecx
  7615a1:	mov    %r14,%rsi
  7615a4:	mov    %rcx,%rdx
  7615a7:	and    $0x3,%rsi
  7615ab:	je     7615e4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x894>
  7615ad:	imul   $0x38,%rcx,%rdi
  7615b1:	add    0xa0(%rsp),%rdi
  7615b9:	lea    (%rsi,%rsi,1),%rdx
  7615bd:	shl    $0x4,%esi
  7615c0:	sub    %rdx,%rsi
  7615c3:	xor    %r8d,%r8d
  7615c6:	mov    %rcx,%rdx
  7615c9:	nopl   0x0(%rax)
  7615d0:	mov    (%rdi,%r8,4),%r9d
  7615d4:	mov    %r9d,(%rax,%rdx,4)
  7615d8:	inc    %rdx
  7615db:	add    $0xe,%r8
  7615df:	cmp    %r8,%rsi
  7615e2:	jne    7615d0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x880>
  7615e4:	sub    %r14,%rcx
  7615e7:	cmp    $0xfffffffffffffffc,%rcx
  7615eb:	ja     7616ca <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x97a>
  7615f1:	imul   $0x38,%rdx,%rcx
  7615f5:	add    0xa0(%rsp),%rcx
  7615fd:	nopl   (%rax)
  761600:	mov    (%rcx),%esi
  761602:	mov    %esi,(%rax,%rdx,4)
  761605:	mov    0x38(%rcx),%esi
  761608:	mov    %esi,0x4(%rax,%rdx,4)
  76160c:	mov    0x70(%rcx),%esi
  76160f:	mov    %esi,0x8(%rax,%rdx,4)
  761613:	mov    0xa8(%rcx),%esi
  761619:	mov    %esi,0xc(%rax,%rdx,4)
  76161d:	add    $0x4,%rdx
  761621:	add    $0xe0,%rcx
  761628:	cmp    %rdx,%r14
  76162b:	jne    761600 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x8b0>
  76162d:	jmp    7616ca <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x97a>
  761632:	shl    $0x6,%eax
  761635:	or     %r8d,%eax
  761638:	cmp    $0x80,%eax
  76163d:	jae    762d53 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2003>
  761643:	jmp    760de7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x97>
  761648:	mov    %r14,%rcx
  76164b:	and    $0xfffffffffffffff8,%rcx
  76164f:	xor    %edx,%edx
  761651:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  761660:	movss  0xa8(%rsi),%xmm0
  761668:	movss  0x70(%rsi),%xmm1
  76166d:	unpcklps %xmm0,%xmm1
  761670:	movss  0x38(%rsi),%xmm0
  761675:	movss  (%rsi),%xmm2
  761679:	unpcklps %xmm0,%xmm2
  76167c:	movlhps %xmm1,%xmm2
  76167f:	movss  0x188(%rsi),%xmm0
  761687:	movss  0x150(%rsi),%xmm1
  76168f:	unpcklps %xmm0,%xmm1
  761692:	movss  0x118(%rsi),%xmm0
  76169a:	movss  0xe0(%rsi),%xmm3
  7616a2:	unpcklps %xmm0,%xmm3
  7616a5:	movlhps %xmm1,%xmm3
  7616a8:	movups %xmm2,(%rax,%rdx,4)
  7616ac:	movups %xmm3,0x10(%rax,%rdx,4)
  7616b1:	add    $0x8,%rdx
  7616b5:	add    $0x1c0,%rsi
  7616bc:	cmp    %rdx,%rcx
  7616bf:	jne    761660 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x910>
  7616c1:	cmp    %rcx,%r14
  7616c4:	jne    7615a1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x851>
  7616ca:	mov    0xa0(%rsp),%rcx
  7616d2:	mov    0x130(%rsp),%rdx
  7616da:	mov    %rdx,0x130(%rsp)
  7616e2:	mov    %rcx,0xa0(%rsp)
  7616ea:	mov    %r14,0x198(%rsp)
  7616f2:	mov    %rax,0x1a0(%rsp)
  7616fa:	mov    %r14,0x1a8(%rsp)
  761702:	mov    0x238(%rsp),%rax
  76170a:	mov    %rax,0x138(%rsp)
  761712:	mov    $0x1,%bpl
  761715:	shr    $0x20,%rax
  761719:	jne    762e71 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2121>
  76171f:	lea    0x198(%rsp),%rdi
  761727:	call   772de0 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtCslbxve4rcJus_4gpui7runtime6ParentE8grow_oneCs9C2G9YFESsD_29canonical_text_public_control>
  76172c:	mov    0x1a0(%rsp),%rax
  761734:	mov    0x138(%rsp),%rcx
  76173c:	mov    %ecx,(%rax,%r14,4)
  761740:	lea    0x1(%r14),%rax
  761744:	mov    %rax,0x1a8(%rsp)
  76174c:	xor    %ebp,%ebp
  76174e:	lea    0x228(%rsp),%rdi
  761756:	call   7659b0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount>
  76175b:	mov    %rax,%rbx
  76175e:	mov    %rax,0x18(%rsp)
  761763:	cmpb   $0x0,0x76e(%rax)
  76176a:	jne    76315a <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x240a>
  761770:	cmpb   $0x1,0x76a(%rbx)
  761777:	jne    763161 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2411>
  76177d:	mov    %r14,0xb0(%rsp)
  761785:	mov    0x5c0(%rbx),%r12
  76178c:	mov    $0x1a,%eax
  761791:	mov    %rax,0x8(%rsp)
  761796:	test   %r12,%r12
  761799:	je     76316b <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x241b>
  76179f:	mov    0x5b8(%rbx),%r13
  7617a6:	shl    $0x6,%r12
  7617aa:	lea    0x1e8(%rbx),%r14
  7617b1:	xor    %ebp,%ebp
  7617b3:	mov    0x358b7e(%rip),%r15        # aba338 <_DYNAMIC+0x2f8>
  7617ba:	jmp    7617cd <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xa7d>
  7617bc:	nopl   0x0(%rax)
  7617c0:	add    $0x40,%rbp
  7617c4:	cmp    %rbp,%r12
  7617c7:	je     76316b <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x241b>
  7617cd:	cmpb   $0x4,0x3d(%r13,%rbp,1)
  7617d3:	jne    7617c0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xa70>
  7617d5:	mov    0x20(%r13,%rbp,1),%rsi
  7617da:	mov    %r14,%rdi
  7617dd:	call   *%r15
  7617e0:	test   %al,%al
  7617e2:	je     7617c0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xa70>
  7617e4:	mov    0x20(%r13,%rbp,1),%rsi
  7617e9:	add    $0x5f0,%rbx
  7617f0:	mov    %rbx,%rdi
  7617f3:	call   *0x358ce7(%rip)        # aba4e0 <_DYNAMIC+0x4a0>
  7617f9:	mov    0x18(%rsp),%rsi
  7617fe:	movq   $0x0,0x1f8(%rsp)
  76180a:	movq   $0x4,0x200(%rsp)
  761816:	movq   $0x0,0x208(%rsp)
  761822:	test   %rsi,%rsi
  761825:	je     76319f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x244f>
  76182b:	cmpb   $0x0,0x76e(%rsi)
  761832:	jne    7631a6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2456>
  761838:	cmpb   $0x1,0x76c(%rsi)
  76183f:	jne    7631ad <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x245d>
  761845:	mov    %rax,%rbx
  761848:	mov    %rdx,%r14
  76184b:	lea    0x20(%rsp),%rdi
  761850:	call   73de20 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime5queryNtB3_7Context3newNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEBX_>
  761855:	mov    %r14,0x2f0(%rsp)
  76185d:	mov    %rbx,0x1f0(%rsp)
  761865:	mov    0x58(%rsp),%rax
  76186a:	mov    %rax,0x110(%rsp)
  761872:	test   %rax,%rax
  761875:	je     761e14 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x10c4>
  76187b:	mov    $0x4,%eax
  761880:	mov    %rax,0x120(%rsp)
  761888:	movq   $0x0,0xa8(%rsp)
  761894:	xor    %r15d,%r15d
  761897:	jmp    7618b1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xb61>
  761899:	nopl   0x0(%rax)
  7618a0:	inc    %r15
  7618a3:	cmp    0x110(%rsp),%r15
  7618ab:	je     761df8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x10a8>
  7618b1:	mov    0x58(%rsp),%rsi
  7618b6:	cmp    %rsi,%r15
  7618b9:	jae    76305c <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x230c>
  7618bf:	mov    0x50(%rsp),%rax
  7618c4:	mov    %r15,%rcx
  7618c7:	shl    $0x6,%rcx
  7618cb:	cmpb   $0x4,0x3d(%rax,%rcx,1)
  7618d0:	jne    7618a0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xb50>
  7618d2:	lea    0xc0(%rsp),%rdi
  7618da:	lea    0x20(%rsp),%rsi
  7618df:	mov    %r15,%rdx
  7618e2:	call   *0x358ba0(%rip)        # aba488 <_DYNAMIC+0x448>
  7618e8:	cmpq   $0x0,0xc0(%rsp)
  7618f1:	je     762d76 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2026>
  7618f7:	movups 0xc0(%rsp),%xmm0
  7618ff:	movaps %xmm0,0x300(%rsp)
  761907:	mov    0xd0(%rsp),%rsi
  76190f:	mov    0xd8(%rsp),%rax
  761917:	mov    %rax,0x10(%rsp)
  76191c:	lea    0x240(%rsp),%rdi
  761924:	mov    %rsi,0x118(%rsp)
  76192c:	call   *0x358bc6(%rip)        # aba4f8 <_DYNAMIC+0x4b8>
  761932:	mov    0x280(%rsp),%rax
  76193a:	mov    %rax,0x100(%rsp)
  761942:	movups 0x240(%rsp),%xmm0
  76194a:	movups 0x250(%rsp),%xmm1
  761952:	movups 0x260(%rsp),%xmm2
  76195a:	movups 0x270(%rsp),%xmm3
  761962:	movaps %xmm3,0xf0(%rsp)
  76196a:	movaps %xmm2,0xe0(%rsp)
  761972:	movaps %xmm1,0xd0(%rsp)
  76197a:	movaps %xmm0,0xc0(%rsp)
  761982:	mov    0xf8(%rsp),%rax
  76198a:	mov    %rax,0x8(%rsp)
  76198f:	mov    $0x2,%eax
  761994:	movss  0x100(%rsp),%xmm0
  76199d:	movss  %xmm0,0xb8(%rsp)
  7619a6:	dec    %rax
  7619a9:	mov    %rax,0x108(%rsp)
  7619b1:	lea    0x170(%rsp),%rdi
  7619b9:	lea    0xc0(%rsp),%rsi
  7619c1:	call   7986e0 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control>
  7619c6:	cmpq   $0x0,0x170(%rsp)
  7619cf:	je     7618a0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xb50>
  7619d5:	mov    0xc0(%rsp),%rbx
  7619dd:	mov    0xc8(%rsp),%r14
  7619e5:	mov    0xe0(%rsp),%rbp
  7619ed:	mov    0xd8(%rsp),%r12
  7619f5:	mov    0xd0(%rsp),%r13
  7619fd:	nopl   (%rax)
  761a00:	lea    0x1b0(%rsp),%rdi
  761a08:	mov    0x8(%rsp),%rsi
  761a0d:	movss  0xb8(%rsp),%xmm0
  761a16:	lea    0x170(%rsp),%rdx
  761a1e:	call   75d580 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Cs9C2G9YFESsD_29canonical_text_public_control>
  761a23:	cmpb   $0x2,0x1b4(%rsp)
  761a2b:	je     761a3b <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xceb>
  761a2d:	testb  $0x1,0x1e0(%rsp)
  761a35:	je     761c40 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xef0>
  761a3b:	mov    %r14,%rax
  761a3e:	cmp    $0x1,%r14
  761a42:	je     761a74 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xd24>
  761a44:	test   %r14,%r14
  761a47:	je     7618a0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xb50>
  761a4d:	mov    (%rbx),%ecx
  761a4f:	lea    0xc(%rbx),%rdx
  761a53:	lea    0x1(%r14),%rsi
  761a57:	mov    $0x1,%eax
  761a5c:	nopl   0x0(%rax)
  761a60:	cmp    (%rdx),%ecx
  761a62:	jne    761a74 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xd24>
  761a64:	inc    %rax
  761a67:	add    $0xc,%rdx
  761a6b:	dec    %rsi
  761a6e:	cmp    $0x2,%rsi
  761a72:	ja     761a60 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xd10>
  761a74:	sub    %rax,%r14
  761a77:	jb     762bdd <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1e8d>
  761a7d:	mov    %r14,0xc8(%rsp)
  761a85:	test   %rbp,%rbp
  761a88:	jne    761b43 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xdf3>
  761a8e:	mov    %r12,%rcx
  761a91:	cmp    $0x1,%r12
  761a95:	je     761ad4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xd84>
  761a97:	test   %r12,%r12
  761a9a:	je     7618a0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xb50>
  761aa0:	mov    0x0(%r13),%edx
  761aa4:	lea    0xc(%r13),%rsi
  761aa8:	lea    0x1(%r12),%rdi
  761aad:	mov    $0x1,%ecx
  761ab2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  761ac0:	cmp    (%rsi),%edx
  761ac2:	jne    761ad4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xd84>
  761ac4:	inc    %rcx
  761ac7:	add    $0xc,%rsi
  761acb:	dec    %rdi
  761ace:	cmp    $0x2,%rdi
  761ad2:	ja     761ac0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xd70>
  761ad4:	sub    %rcx,%r12
  761ad7:	jb     762bdd <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1e8d>
  761add:	lea    (%rcx,%rcx,2),%rdx
  761ae1:	lea    0x0(,%rdx,4),%rdx
  761ae9:	add    %r13,%rdx
  761aec:	mov    %rdx,0xd0(%rsp)
  761af4:	mov    %r12,0xd8(%rsp)
  761afc:	test   %r13,%r13
  761aff:	je     7618a0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xb50>
  761b05:	lea    (%rax,%rax,2),%rsi
  761b09:	mov    %rbx,0x170(%rsp)
  761b11:	mov    %rax,0x178(%rsp)
  761b19:	mov    %r13,0x180(%rsp)
  761b21:	mov    %rcx,0x188(%rsp)
  761b29:	mov    %rdx,%r13
  761b2c:	mov    $0x0,%ebp
  761b31:	test   %rbx,%rbx
  761b34:	lea    (%rbx,%rsi,4),%rbx
  761b38:	jne    761a00 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xcb0>
  761b3e:	jmp    7618a0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xb50>
  761b43:	movq   $0x0,0xe0(%rsp)
  761b4f:	nop
  761b50:	mov    %r13,%rsi
  761b53:	mov    %r12,%rdx
  761b56:	mov    %r12,%rdi
  761b59:	cmp    $0x1,%r12
  761b5d:	je     761b95 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xe45>
  761b5f:	test   %rdx,%rdx
  761b62:	je     7618a0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xb50>
  761b68:	mov    (%rsi),%ecx
  761b6a:	lea    0xc(%rsi),%r8
  761b6e:	lea    0x1(%rdx),%r9
  761b72:	mov    $0x1,%edi
  761b77:	nopw   0x0(%rax,%rax,1)
  761b80:	cmp    (%r8),%ecx
  761b83:	jne    761b95 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xe45>
  761b85:	inc    %rdi
  761b88:	add    $0xc,%r8
  761b8c:	dec    %r9
  761b8f:	cmp    $0x2,%r9
  761b93:	ja     761b80 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xe30>
  761b95:	mov    %rdx,%r12
  761b98:	sub    %rdi,%r12
  761b9b:	jb     762bdd <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1e8d>
  761ba1:	lea    (%rdi,%rdi,2),%r9
  761ba5:	lea    (%rsi,%r9,4),%r13
  761ba9:	dec    %rbp
  761bac:	jne    761b50 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xe00>
  761bae:	mov    %r13,0xd0(%rsp)
  761bb6:	mov    %r12,0xd8(%rsp)
  761bbe:	mov    %r12,%rcx
  761bc1:	cmp    $0x1,%r12
  761bc5:	je     761c05 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xeb5>
  761bc7:	test   %r12,%r12
  761bca:	je     7618a0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xb50>
  761bd0:	mov    0x0(%r13),%r8d
  761bd4:	lea    (%rsi,%r9,4),%rsi
  761bd8:	add    $0xc,%rsi
  761bdc:	sub    %rdi,%rdx
  761bdf:	inc    %rdx
  761be2:	mov    $0x1,%ecx
  761be7:	nopw   0x0(%rax,%rax,1)
  761bf0:	cmp    (%rsi),%r8d
  761bf3:	jne    761c05 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xeb5>
  761bf5:	inc    %rcx
  761bf8:	add    $0xc,%rsi
  761bfc:	dec    %rdx
  761bff:	cmp    $0x2,%rdx
  761c03:	ja     761bf0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xea0>
  761c05:	sub    %rcx,%r12
  761c08:	jb     762bdd <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1e8d>
  761c0e:	lea    (%rcx,%rcx,2),%rdx
  761c12:	lea    0x0(,%rdx,4),%rdx
  761c1a:	add    %r13,%rdx
  761c1d:	mov    %rdx,0xd0(%rsp)
  761c25:	mov    %r12,0xd8(%rsp)
  761c2d:	jmp    761b05 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xdb5>
  761c32:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  761c40:	mov    %rbx,0xc0(%rsp)
  761c48:	lea    0x1b5(%rsp),%rax
  761c50:	movups (%rax),%xmm0
  761c53:	movups 0x10(%rax),%xmm1
  761c57:	movups 0x1b(%rax),%xmm2
  761c5b:	movaps %xmm0,0x290(%rsp)
  761c63:	movaps %xmm1,0x2a0(%rsp)
  761c6b:	movups %xmm2,0x2ab(%rsp)
  761c73:	lea    0x298(%rsp),%rax
  761c7b:	movups (%rax),%xmm0
  761c7e:	movaps %xmm0,0x320(%rsp)
  761c86:	mov    0xf(%rax),%eax
  761c89:	mov    %eax,0x32f(%rsp)
  761c90:	lea    0x323(%rsp),%rax
  761c98:	movups (%rax),%xmm0
  761c9b:	movaps %xmm0,0x170(%rsp)
  761ca3:	movaps 0x300(%rsp),%xmm0
  761cab:	movaps %xmm0,0x1b0(%rsp)
  761cb3:	mov    0x118(%rsp),%rax
  761cbb:	mov    %rax,0x1c0(%rsp)
  761cc3:	mov    0x10(%rsp),%rax
  761cc8:	mov    %rax,0x1c8(%rsp)
  761cd0:	lea    0x290(%rsp),%rdi
  761cd8:	lea    0x1b0(%rsp),%rsi
  761ce0:	lea    0x170(%rsp),%rdx
  761ce8:	call   *0x358832(%rip)        # aba520 <_DYNAMIC+0x4e0>
  761cee:	cmpb   $0x0,0x290(%rsp)
  761cf6:	je     762d9d <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x204d>
  761cfc:	movsd  0x294(%rsp),%xmm1
  761d05:	movsd  0x29c(%rsp),%xmm0
  761d0e:	mulps  -0x69e605(%rip),%xmm0        # c3710 <GCC_except_table0+0x1308>
  761d15:	addps  %xmm1,%xmm0
  761d18:	movaps %xmm0,%xmm1
  761d1b:	shufps $0x55,%xmm0,%xmm1
  761d1f:	movaps 0x300(%rsp),%xmm2
  761d27:	movaps %xmm2,0x1b0(%rsp)
  761d2f:	mov    0x118(%rsp),%rax
  761d37:	mov    %rax,0x1c0(%rsp)
  761d3f:	mov    0x10(%rsp),%rax
  761d44:	mov    %rax,0x1c8(%rsp)
  761d4c:	lea    0x1b0(%rsp),%rdi
  761d54:	movaps %xmm0,0x210(%rsp)
  761d5c:	call   *0x3587c6(%rip)        # aba528 <_DYNAMIC+0x4e8>
  761d62:	mov    %edx,%r14d
  761d65:	cmp    $0x2,%dl
  761d68:	je     762da6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2056>
  761d6e:	mov    %eax,%ebx
  761d70:	mov    0xa8(%rsp),%rax
  761d78:	cmp    0x1f8(%rsp),%rax
  761d80:	jne    761d9f <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x104f>
  761d82:	lea    0x1f8(%rsp),%rdi
  761d8a:	call   772b40 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtCscO85OU7Wpt0_20gpui_reactivity_core8geometry4RectE8grow_oneCs9C2G9YFESsD_29canonical_text_public_control>
  761d8f:	mov    0x200(%rsp),%rax
  761d97:	mov    %rax,0x120(%rsp)
  761d9f:	and    $0x1,%r14b
  761da3:	mov    0xa8(%rsp),%rcx
  761dab:	mov    %rcx,%rax
  761dae:	shl    $0x4,%rax
  761db2:	mov    0x120(%rsp),%rdx
  761dba:	movaps 0x210(%rsp),%xmm0
  761dc2:	movlps %xmm0,(%rdx,%rax,1)
  761dc6:	mov    %ebx,0x8(%rdx,%rax,1)
  761dca:	mov    %r14b,0xc(%rdx,%rax,1)
  761dcf:	inc    %rcx
  761dd2:	mov    %rcx,0xa8(%rsp)
  761dda:	mov    %rcx,0x208(%rsp)
  761de2:	mov    0x108(%rsp),%rax
  761dea:	test   %rax,%rax
  761ded:	jne    7619a6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xc56>
  761df3:	jmp    7618a0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0xb50>
  761df8:	mov    0x1f8(%rsp),%rax
  761e00:	mov    %rax,0x10(%rsp)
  761e05:	mov    0x200(%rsp),%rax
  761e0d:	mov    %rax,0x8(%rsp)
  761e12:	jmp    761e33 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x10e3>
  761e14:	mov    $0x4,%eax
  761e19:	mov    %rax,0x8(%rsp)
  761e1e:	movq   $0x0,0xa8(%rsp)
  761e2a:	movq   $0x0,0x10(%rsp)
  761e33:	mov    $0xffffffff,%eax
  761e38:	mov    %rax,0x1b0(%rsp)
  761e40:	movq   $0x0,0x1b8(%rsp)
  761e4c:	mov    0x140(%rsp),%rdi
  761e54:	xor    %esi,%esi
  761e56:	mov    $0x1,%edx
  761e5b:	call   *0x358687(%rip)        # aba4e8 <_DYNAMIC+0x4a8>
  761e61:	mov    0xb0(%rsp),%r15
  761e69:	mov    %edx,%ebx
  761e6b:	cmp    $0x2,%dl
  761e6e:	je     762e83 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2133>
  761e74:	test   %eax,%eax
  761e76:	sete   0xb8(%rsp)
  761e7e:	mov    0x2d8(%rsp),%r14
  761e86:	mov    0x2e0(%rsp),%r12
  761e8e:	cmp    $0x4,%r12
  761e92:	je     761fa0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1250>
  761e98:	cmp    $0x5,%r12
  761e9c:	jne    76206c <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x131c>
  761ea2:	mov    $0x6f727261,%eax
  761ea7:	xor    (%r14),%eax
  761eaa:	movzbl 0x4(%r14),%ecx
  761eaf:	xor    $0x77,%ecx
  761eb2:	or     %eax,%ecx
  761eb4:	jne    761f4b <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x11fb>
  761eba:	cmpq   $0x5,0x128(%rsp)
  761ec3:	jne    761ee3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1193>
  761ec5:	mov    $0x74706d65,%eax
  761eca:	mov    0x2e8(%rsp),%rcx
  761ed2:	xor    (%rcx),%eax
  761ed4:	movzbl 0x4(%rcx),%ecx
  761ed8:	xor    $0x79,%ecx
  761edb:	or     %eax,%ecx
  761edd:	je     763031 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x22e1>
  761ee3:	movl   $0x0,0x20(%rsp)
  761eeb:	movb   $0x1,0x24(%rsp)
  761ef0:	movl   $0x0,0x28(%rsp)
  761ef8:	movb   $0x1,0x2c(%rsp)
  761efd:	mov    0x18(%rsp),%rsi
  761f02:	test   %rsi,%rsi
  761f05:	je     76325a <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x250a>
  761f0b:	lea    0xc0(%rsp),%rdi
  761f13:	lea    0x20(%rsp),%r8
  761f18:	mov    0x1f0(%rsp),%rdx
  761f20:	mov    0x2f0(%rsp),%rcx
  761f28:	call   76fcd0 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE12select_inputB12_>
  761f2d:	cmpq   $0xfffffffffffffffe,0xc0(%rsp)
  761f36:	jne    763272 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2522>
  761f3c:	mov    0x18(%rsp),%rsi
  761f41:	lea    0x20(%rsp),%rdi
  761f46:	call   760be0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack>
  761f4b:	movl   $0x0,0x128(%rsp)
  761f56:	mov    0x18(%rsp),%rax
  761f5b:	test   %rax,%rax
  761f5e:	jne    762085 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1335>
  761f64:	movq   $0xd,0x20(%rsp)
  761f6d:	movq   $0x0,0x28(%rsp)
  761f76:	lea    -0x6922d3(%rip),%rdi        # cfcaa <GCC_except_table0+0xd8a2>
  761f7d:	lea    0x338dac(%rip),%rcx        # a9ad30 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1248>
  761f84:	lea    0x338b7d(%rip),%r8        # a9ab08 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1020>
  761f8b:	lea    0x20(%rsp),%rdx
  761f90:	mov    $0x2b,%esi
  761f95:	call   *0x3583b5(%rip)        # aba350 <_DYNAMIC+0x310>
  761f9b:	jmp    763320 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x25d0>
  761fa0:	mov    $0x1,%al
  761fa2:	mov    %eax,0x128(%rsp)
  761fa9:	cmpl   $0x67617264,(%r14)
  761fb0:	jne    762077 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1327>
  761fb6:	mov    0xa8(%rsp),%rax
  761fbe:	mov    %rax,0x20(%rsp)
  761fc3:	cmp    $0x2,%rax
  761fc7:	jne    762ef5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x21a5>
  761fcd:	mov    0x8(%rsp),%rcx
  761fd2:	mov    0x8(%rcx),%eax
  761fd5:	cmp    0x18(%rcx),%eax
  761fd8:	jne    761fe7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1297>
  761fda:	movzbl 0xc(%rcx),%eax
  761fde:	cmp    0x1c(%rcx),%al
  761fe1:	je     763043 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x22f3>
  761fe7:	movsd  (%rcx),%xmm0
  761feb:	movsd  %xmm0,0x24(%rsp)
  761ff1:	movl   $0x0,0x20(%rsp)
  761ff9:	lea    0xc0(%rsp),%rdi
  762001:	lea    0x18(%rsp),%rsi
  762006:	lea    0x1b0(%rsp),%rdx
  76200e:	lea    0x20(%rsp),%rcx
  762013:	call   76dab0 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_>
  762018:	cmpl   $0xfffffffe,0xc0(%rsp)
  762020:	jne    762f17 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x21c7>
  762026:	movl   $0x2,0x20(%rsp)
  76202e:	lea    0xc0(%rsp),%rdi
  762036:	lea    0x18(%rsp),%rsi
  76203b:	lea    0x1b0(%rsp),%rdx
  762043:	lea    0x20(%rsp),%rcx
  762048:	call   76dab0 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_>
  76204d:	cmpl   $0xfffffffe,0xc0(%rsp)
  762055:	jne    762f75 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2225>
  76205b:	mov    0x18(%rsp),%rsi
  762060:	lea    0x20(%rsp),%rdi
  762065:	call   760be0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack>
  76206a:	jmp    762077 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1327>
  76206c:	movl   $0x0,0x128(%rsp)
  762077:	mov    0x18(%rsp),%rax
  76207c:	test   %rax,%rax
  76207f:	je     761f64 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1214>
  762085:	xorps  %xmm0,%xmm0
  762088:	movups %xmm0,0x740(%rax)
  76208f:	movups %xmm0,0x730(%rax)
  762096:	movups %xmm0,0x720(%rax)
  76209d:	movups %xmm0,0x710(%rax)
  7620a4:	movups %xmm0,0x700(%rax)
  7620ab:	movups %xmm0,0x6f0(%rax)
  7620b2:	movq   $0x0,0x750(%rax)
  7620bd:	cmpb   $0x0,0x3b0(%rsp)
  7620c5:	je     7620de <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x138e>
  7620c7:	call   *0x358463(%rip)        # aba530 <_DYNAMIC+0x4f0>
  7620cd:	mov    %rax,0x1f0(%rsp)
  7620d5:	mov    %edx,0x210(%rsp)
  7620dc:	jmp    7620e9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1399>
  7620de:	movl   $0xffffffff,0x210(%rsp)
  7620e9:	mov    0xa8(%rsp),%rax
  7620f1:	cmp    $0x1,%rax
  7620f5:	adc    $0x0,%rax
  7620f9:	mov    %rax,0x118(%rsp)
  762101:	cmp    $0x1,%r15
  762105:	adc    $0x0,%r15
  762109:	mov    %r15,0x110(%rsp)
  762111:	mov    %r12,0x120(%rsp)
  762119:	lea    -0x3(%r12),%r13
  76211e:	cmp    $0x7,%r13
  762122:	setb   %al
  762125:	mov    $0x5f,%dl
  762127:	mov    %r13d,%ecx
  76212a:	shr    %cl,%dl
  76212c:	and    %al,%dl
  76212e:	cmp    $0x1,%dl
  762131:	je     76216a <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x141a>
  762133:	lea    0x2d8(%rsp),%rax
  76213b:	mov    %rax,0x20(%rsp)
  762140:	lea    0x34c89(%rip),%rax        # 796dd0 <_RNvXs1i_NtCs4NRVxsYgnAr_4core3fmtReNtB6_7Display3fmtCs9C2G9YFESsD_29canonical_text_public_control>
  762147:	mov    %rax,0x28(%rsp)
  76214c:	lea    -0x698790(%rip),%rdi        # c99c3 <GCC_except_table0+0x75bb>
  762153:	lea    0x338a26(%rip),%rdx        # a9ab80 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1098>
  76215a:	lea    0x20(%rsp),%rsi
  76215f:	call   *0x358153(%rip)        # aba2b8 <_DYNAMIC+0x278>
  762165:	jmp    763320 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x25d0>
  76216a:	and    %bl,0xb8(%rsp)
  762171:	mov    $0x1,%ebx
  762176:	xor    %ebp,%ebp
  762178:	lea    0x20(%rsp),%r15
  76217d:	lea    -0x69e14c(%rip),%r12        # c4038 <GCC_except_table0+0x1c30>
  762184:	jmp    7621e6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1496>
  762186:	lea    0x4ce3(%rip),%rax        # 766e70 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9query_hit>
  76218d:	mov    %rax,0x20(%rsp)
  762192:	mov    0x20(%rsp),%rcx
  762197:	mov    0x140(%rsp),%rax
  76219f:	mov    %rax,0x20(%rsp)
  7621a4:	mov    0x20(%rsp),%rdi
  7621a9:	movlps %xmm0,0x20(%rsp)
  7621ae:	movsd  0x20(%rsp),%xmm0
  7621b4:	movaps %xmm0,%xmm1
  7621b7:	shufps $0x55,%xmm0,%xmm1
  7621bb:	call   *%rcx
  7621bd:	inc    %rbp
  7621c0:	mov    %rax,0x20(%rsp)
  7621c5:	xor    0x20(%rsp),%rbx
  7621ca:	movabs $0x100000001b3,%rax
  7621d4:	imul   %rax,%rbx
  7621d8:	cmp    %rbp,0x148(%rsp)
  7621e0:	je     76267b <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x192b>
  7621e6:	cmp    $0x6,%r13
  7621ea:	ja     762234 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x14e4>
  7621ec:	movslq (%r12,%r13,4),%rax
  7621f0:	add    %r12,%rax
  7621f3:	jmp    *%rax
  7621f5:	movzwl (%r14),%eax
  7621f9:	xor    $0x6968,%eax
  7621fe:	movzbl 0x2(%r14),%ecx
  762203:	xor    $0x74,%ecx
  762206:	or     %ax,%cx
  762209:	jne    762133 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x13e3>
  76220f:	mov    %rbp,%rax
  762212:	mov    0x110(%rsp),%rcx
  76221a:	or     %rcx,%rax
  76221d:	shr    $0x20,%rax
  762221:	je     762558 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1808>
  762227:	mov    %rbp,%rax
  76222a:	xor    %edx,%edx
  76222c:	div    %rcx
  76222f:	jmp    76255e <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x180e>
  762234:	mov    (%r14),%eax
  762237:	mov    $0x70657270,%ecx
  76223c:	xor    %ecx,%eax
  76223e:	mov    0x3(%r14),%ecx
  762242:	mov    $0x65726170,%edx
  762247:	xor    %edx,%ecx
  762249:	or     %eax,%ecx
  76224b:	je     7624c5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1775>
  762251:	mov    (%r14),%eax
  762254:	mov    $0x68736572,%ecx
  762259:	xor    %ecx,%eax
  76225b:	mov    0x3(%r14),%ecx
  76225f:	mov    $0x65706168,%edx
  762264:	xor    %edx,%ecx
  762266:	or     %eax,%ecx
  762268:	jne    762133 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x13e3>
  76226e:	lea    -0x2135(%rip),%rax        # 760140 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_reshape>
  762275:	mov    %rax,0x20(%rsp)
  76227a:	mov    0x20(%rsp),%rax
  76227f:	lea    0x18(%rsp),%rcx
  762284:	mov    %rcx,0x20(%rsp)
  762289:	mov    0x20(%rsp),%rdi
  76228e:	test   $0x1,%bpl
  762292:	lea    0x2c8(%rsp),%rcx
  76229a:	lea    0x160(%rsp),%rdx
  7622a2:	cmove  %rdx,%rcx
  7622a6:	mov    (%rcx),%rcx
  7622a9:	lea    0x2d0(%rsp),%rdx
  7622b1:	lea    0x168(%rsp),%rsi
  7622b9:	cmove  %rsi,%rdx
  7622bd:	mov    (%rdx),%rdx
  7622c0:	mov    %rcx,0x20(%rsp)
  7622c5:	mov    %rdx,0x28(%rsp)
  7622ca:	mov    0x20(%rsp),%rsi
  7622cf:	mov    0x28(%rsp),%rdx
  7622d4:	call   *%rax
  7622d6:	jmp    7621bd <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x146d>
  7622db:	mov    (%r14),%eax
  7622de:	mov    $0x6f727261,%ecx
  7622e3:	xor    %ecx,%eax
  7622e5:	movzbl 0x4(%r14),%ecx
  7622ea:	xor    $0x77,%ecx
  7622ed:	or     %eax,%ecx
  7622ef:	jne    762133 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x13e3>
  7622f5:	lea    -0x2d4c(%rip),%rax        # 75f5b0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control11owner_arrow>
  7622fc:	mov    %rax,0x20(%rsp)
  762301:	mov    0x20(%rsp),%rax
  762306:	lea    0x18(%rsp),%rcx
  76230b:	mov    %rcx,0x20(%rsp)
  762310:	mov    0x20(%rsp),%rdi
  762315:	test   $0x1,%bpl
  762319:	sete   %cl
  76231c:	xor    0xb8(%rsp),%cl
  762323:	mov    %cl,0x20(%rsp)
  762327:	jmp    7624f0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x17a0>
  76232c:	cmpl   $0x67617264,(%r14)
  762333:	jne    762133 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x13e3>
  762339:	lea    -0x3330(%rip),%rax        # 75f010 <_RNvCs9C2G9YFESsD_29canonical_text_public_control10owner_drag>
  762340:	mov    %rax,0x20(%rsp)
  762345:	mov    0x20(%rsp),%rcx
  76234a:	lea    0x18(%rsp),%rax
  76234f:	mov    %rax,0x20(%rsp)
  762354:	mov    0x20(%rsp),%rdi
  762359:	lea    0x1b0(%rsp),%rax
  762361:	mov    %rax,0x20(%rsp)
  762366:	mov    %ebp,%eax
  762368:	not    %eax
  76236a:	and    $0x1,%eax
  76236d:	cmp    0xa8(%rsp),%rax
  762375:	jae    76313d <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x23ed>
  76237b:	mov    0x20(%rsp),%rsi
  762380:	shl    $0x4,%eax
  762383:	mov    0x8(%rsp),%rdx
  762388:	movsd  (%rdx,%rax,1),%xmm0
  76238d:	movsd  %xmm0,0x20(%rsp)
  762393:	movss  0x20(%rsp),%xmm0
  762399:	movss  0x24(%rsp),%xmm1
  76239f:	call   *%rcx
  7623a1:	jmp    7621bd <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x146d>
  7623a6:	mov    (%r14),%eax
  7623a9:	mov    $0x75736976,%ecx
  7623ae:	xor    %ecx,%eax
  7623b0:	movzwl 0x4(%r14),%ecx
  7623b5:	xor    $0x6c61,%ecx
  7623bb:	or     %eax,%ecx
  7623bd:	jne    762133 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x13e3>
  7623c3:	lea    -0x288a(%rip),%rax        # 75fb40 <_RNvCs9C2G9YFESsD_29canonical_text_public_control12query_visual>
  7623ca:	mov    %rax,0x20(%rsp)
  7623cf:	mov    0x20(%rsp),%rcx
  7623d4:	mov    0x140(%rsp),%rax
  7623dc:	mov    %rax,0x20(%rsp)
  7623e1:	mov    0x1a8(%rsp),%r8
  7623e9:	test   %r8,%r8
  7623ec:	je     763097 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2347>
  7623f2:	mov    0x20(%rsp),%rdi
  7623f7:	mov    0x1a0(%rsp),%rsi
  7623ff:	mov    %rbp,%rax
  762402:	or     %r8,%rax
  762405:	shr    $0x20,%rax
  762409:	je     7625a7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1857>
  76240f:	mov    %rbp,%rax
  762412:	xor    %edx,%edx
  762414:	div    %r8
  762417:	jmp    7625ae <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x185e>
  76241c:	mov    (%r14),%rax
  76241f:	movabs $0x6f697463656c6573,%rcx
  762429:	xor    %rcx,%rax
  76242c:	movzbl 0x8(%r14),%ecx
  762431:	xor    $0x6e,%rcx
  762435:	or     %rax,%rcx
  762438:	je     7624ff <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x17af>
  76243e:	mov    (%r14),%rax
  762441:	movabs $0x69682d72656e776f,%rcx
  76244b:	xor    %rcx,%rax
  76244e:	movzbl 0x8(%r14),%ecx
  762453:	xor    $0x74,%rcx
  762457:	or     %rax,%rcx
  76245a:	jne    762133 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x13e3>
  762460:	lea    0x4869(%rip),%rax        # 766cd0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit>
  762467:	mov    %rax,0x20(%rsp)
  76246c:	mov    0x20(%rsp),%rcx
  762471:	lea    0x18(%rsp),%rax
  762476:	mov    %rax,0x20(%rsp)
  76247b:	mov    0x20(%rsp),%rdi
  762480:	mov    %rbp,%rax
  762483:	mov    0x118(%rsp),%rsi
  76248b:	or     %rsi,%rax
  76248e:	shr    $0x20,%rax
  762492:	je     7625e2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1892>
  762498:	mov    %rbp,%rax
  76249b:	xor    %edx,%edx
  76249d:	div    %rsi
  7624a0:	xorps  %xmm0,%xmm0
  7624a3:	cmp    0xa8(%rsp),%rdx
  7624ab:	jae    7624bb <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x176b>
  7624ad:	shl    $0x4,%rdx
  7624b1:	mov    0x8(%rsp),%rax
  7624b6:	movsd  (%rax,%rdx,1),%xmm0
  7624bb:	movlps %xmm0,0x20(%rsp)
  7624c0:	jmp    7621ae <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x145e>
  7624c5:	lea    -0x28fc(%rip),%rax        # 75fbd0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control13owner_prepare>
  7624cc:	mov    %rax,0x20(%rsp)
  7624d1:	mov    0x20(%rsp),%rax
  7624d6:	lea    0x18(%rsp),%rcx
  7624db:	mov    %rcx,0x20(%rsp)
  7624e0:	mov    0x20(%rsp),%rdi
  7624e5:	mov    %ebp,%ecx
  7624e7:	not    %cl
  7624e9:	and    $0x1,%cl
  7624ec:	mov    %cl,0x20(%rsp)
  7624f0:	movzbl 0x20(%rsp),%ecx
  7624f5:	movzbl %cl,%esi
  7624f8:	call   *%rax
  7624fa:	jmp    7621bd <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x146d>
  7624ff:	lea    -0x1ef6(%rip),%rax        # 760610 <_RNvCs9C2G9YFESsD_29canonical_text_public_control15query_selection>
  762506:	mov    %rax,0x20(%rsp)
  76250b:	mov    0x20(%rsp),%rcx
  762510:	mov    0x140(%rsp),%rax
  762518:	mov    %rax,0x20(%rsp)
  76251d:	mov    0x1a8(%rsp),%r8
  762525:	test   %r8,%r8
  762528:	je     763097 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2347>
  76252e:	mov    0x20(%rsp),%rdi
  762533:	mov    0x1a0(%rsp),%rsi
  76253b:	mov    %rbp,%rax
  76253e:	or     %r8,%rax
  762541:	shr    $0x20,%rax
  762545:	je     7625fe <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x18ae>
  76254b:	mov    %rbp,%rax
  76254e:	xor    %edx,%edx
  762550:	div    %r8
  762553:	jmp    762605 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x18b5>
  762558:	mov    %ebp,%eax
  76255a:	xor    %edx,%edx
  76255c:	div    %ecx
  76255e:	cmpq   $0x0,0xa0(%rsp)
  762567:	sete   %al
  76256a:	cmp    0xb0(%rsp),%rdx
  762572:	setae  %cl
  762575:	or     %al,%cl
  762577:	xorps  %xmm0,%xmm0
  76257a:	jne    762186 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1436>
  762580:	imul   $0x38,%rdx,%rax
  762584:	mov    0xa0(%rsp),%rcx
  76258c:	movsd  0x10(%rcx,%rax,1),%xmm1
  762592:	movsd  0x18(%rcx,%rax,1),%xmm0
  762598:	mulps  -0x69ee8f(%rip),%xmm0        # c3710 <GCC_except_table0+0x1308>
  76259f:	addps  %xmm1,%xmm0
  7625a2:	jmp    762186 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1436>
  7625a7:	mov    %ebp,%eax
  7625a9:	xor    %edx,%edx
  7625ab:	div    %r8d
  7625ae:	mov    0x138(%rsp),%r8
  7625b6:	test   %r8,%r8
  7625b9:	sete   %al
  7625bc:	mov    (%rsi,%rdx,4),%edx
  7625bf:	cmp    %rdx,%r8
  7625c2:	setne  %sil
  7625c6:	or     %al,%sil
  7625c9:	mov    %edx,0x20(%rsp)
  7625cd:	mov    %sil,0x24(%rsp)
  7625d2:	mov    0x20(%rsp),%esi
  7625d6:	movzbl 0x24(%rsp),%edx
  7625db:	call   *%rcx
  7625dd:	jmp    7621bd <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x146d>
  7625e2:	mov    %ebp,%eax
  7625e4:	xor    %edx,%edx
  7625e6:	div    %esi
  7625e8:	xorps  %xmm0,%xmm0
  7625eb:	cmp    0xa8(%rsp),%rdx
  7625f3:	jb     7624ad <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x175d>
  7625f9:	jmp    7624bb <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x176b>
  7625fe:	mov    %ebp,%eax
  762600:	xor    %edx,%edx
  762602:	div    %r8d
  762605:	mov    0x138(%rsp),%rax
  76260d:	test   %rax,%rax
  762610:	sete   %r9b
  762614:	mov    (%rsi,%rdx,4),%r10d
  762618:	cmp    %r10,%rax
  76261b:	setne  %r11b
  76261f:	mov    %r8,%rax
  762622:	shr    $1,%rax
  762625:	add    %rbp,%rax
  762628:	mov    %rax,%rdx
  76262b:	or     %r8,%rdx
  76262e:	shr    $0x20,%rdx
  762632:	je     76263b <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x18eb>
  762634:	xor    %edx,%edx
  762636:	div    %r8
  762639:	jmp    762640 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x18f0>
  76263b:	xor    %edx,%edx
  76263d:	div    %r8d
  762640:	or     %r11b,%r9b
  762643:	mov    0x138(%rsp),%r8
  76264b:	test   %r8,%r8
  76264e:	sete   %al
  762651:	mov    (%rsi,%rdx,4),%edx
  762654:	cmp    %rdx,%r8
  762657:	setne  %sil
  76265b:	or     %al,%sil
  76265e:	mov    %r10d,0x20(%rsp)
  762663:	mov    %r9b,0x24(%rsp)
  762668:	mov    %edx,0x28(%rsp)
  76266c:	mov    %sil,0x2c(%rsp)
  762671:	mov    %r15,%rsi
  762674:	call   *%rcx
  762676:	jmp    7621bd <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x146d>
  76267b:	mov    0x210(%rsp),%eax
  762682:	cmp    $0xffffffff,%eax
  762685:	je     7626e6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1996>
  762687:	mov    0x1f0(%rsp),%rcx
  76268f:	mov    %rcx,0x20(%rsp)
  762694:	mov    %eax,0x28(%rsp)
  762698:	lea    0x20(%rsp),%rdi
  76269d:	call   *0x357e95(%rip)        # aba538 <_DYNAMIC+0x4f8>
  7626a3:	mov    0x120(%rsp),%rsi
  7626ab:	mov    %edx,%ecx
  7626ad:	mov    $0x3b9aca00,%edx
  7626b2:	mul    %rdx
  7626b5:	mov    %ecx,%ecx
  7626b7:	add    %rax,%rcx
  7626ba:	mov    %rcx,0xb8(%rsp)
  7626c2:	adc    $0x0,%rdx
  7626c6:	mov    %rdx,0x110(%rsp)
  7626ce:	cmp    $0x7,%rsi
  7626d2:	lea    0x158(%rsp),%rdx
  7626da:	lea    0x2c0(%rsp),%rsi
  7626e2:	je     76271c <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x19cc>
  7626e4:	jmp    762735 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x19e5>
  7626e6:	movq   $0x0,0xb8(%rsp)
  7626f2:	movq   $0x0,0x110(%rsp)
  7626fe:	mov    0x120(%rsp),%rsi
  762706:	cmp    $0x7,%rsi
  76270a:	lea    0x158(%rsp),%rdx
  762712:	lea    0x2c0(%rsp),%rsi
  76271a:	jne    762735 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x19e5>
  76271c:	mov    $0x68736572,%eax
  762721:	xor    (%r14),%eax
  762724:	mov    $0x65706168,%ecx
  762729:	xor    0x3(%r14),%ecx
  76272d:	or     %eax,%ecx
  76272f:	je     762bfb <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1eab>
  762735:	cmpb   $0x0,0x128(%rsp)
  76273d:	je     76278c <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1a3c>
  76273f:	cmpl   $0x67617264,(%r14)
  762746:	jne    76278c <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1a3c>
  762748:	movl   $0x3,0x20(%rsp)
  762750:	lea    0xc0(%rsp),%rdi
  762758:	lea    0x18(%rsp),%rsi
  76275d:	lea    0x1b0(%rsp),%rdx
  762765:	lea    0x20(%rsp),%rcx
  76276a:	call   76dab0 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_>
  76276f:	cmpl   $0xfffffffe,0xc0(%rsp)
  762777:	jne    762fd3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2283>
  76277d:	mov    0x18(%rsp),%rsi
  762782:	lea    0x20(%rsp),%rdi
  762787:	call   760be0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack>
  76278c:	mov    0x18(%rsp),%rax
  762791:	test   %rax,%rax
  762794:	je     7631f6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x24a6>
  76279a:	mov    0x6f0(%rax),%rcx
  7627a1:	mov    0x6f8(%rax),%r12
  7627a8:	mov    0x700(%rax),%r15
  7627af:	mov    0x708(%rax),%r14
  7627b6:	mov    0x710(%rax),%rbp
  7627bd:	mov    0x718(%rax),%r13
  7627c4:	mov    0x720(%rax),%rdx
  7627cb:	mov    %rdx,0x118(%rsp)
  7627d3:	mov    0x728(%rax),%rdx
  7627da:	mov    %rdx,0x148(%rsp)
  7627e2:	mov    0x730(%rax),%rdx
  7627e9:	mov    %rdx,0xa8(%rsp)
  7627f1:	mov    0x738(%rax),%rdx
  7627f8:	mov    %rdx,0x140(%rsp)
  762800:	mov    0x740(%rax),%rdx
  762807:	mov    %rdx,0x210(%rsp)
  76280f:	mov    0x748(%rax),%rdx
  762816:	mov    %rdx,0x138(%rsp)
  76281e:	mov    0x750(%rax),%rax
  762825:	mov    %rax,0x120(%rsp)
  76282d:	movq   $0xffffffffffffffff,0xc0(%rsp)
  762839:	movq   $0x0,0xd8(%rsp)
  762845:	movq   $0x0,0xe8(%rsp)
  762851:	lea    -0x692f63(%rip),%rsi        # cf8f5 <GCC_except_table0+0xd4ed>
  762858:	lea    0xc0(%rsp),%rdi
  762860:	mov    $0xc,%edx
  762865:	call   75c980 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  76286a:	test   %rax,%rax
  76286d:	jne    763071 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2321>
  762873:	lea    -0x692f79(%rip),%rsi        # cf901 <GCC_except_table0+0xd4f9>
  76287a:	lea    0xc0(%rsp),%rdi
  762882:	mov    $0xc,%edx
  762887:	mov    %r12,%rcx
  76288a:	call   75c980 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  76288f:	test   %rax,%rax
  762892:	jne    763071 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2321>
  762898:	lea    -0x692f92(%rip),%rsi        # cf90d <GCC_except_table0+0xd505>
  76289f:	lea    0xc0(%rsp),%rdi
  7628a7:	mov    $0x11,%edx
  7628ac:	mov    %r15,%rcx
  7628af:	call   75c980 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  7628b4:	test   %rax,%rax
  7628b7:	jne    763071 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2321>
  7628bd:	lea    -0x692fa6(%rip),%rsi        # cf91e <GCC_except_table0+0xd516>
  7628c4:	lea    0xc0(%rsp),%rdi
  7628cc:	mov    $0xc,%edx
  7628d1:	mov    %r14,%rcx
  7628d4:	call   75c980 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  7628d9:	test   %rax,%rax
  7628dc:	jne    763071 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2321>
  7628e2:	lea    -0x692fbf(%rip),%rsi        # cf92a <GCC_except_table0+0xd522>
  7628e9:	lea    0xc0(%rsp),%rdi
  7628f1:	mov    $0x14,%edx
  7628f6:	mov    %rbp,%rcx
  7628f9:	call   75c980 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  7628fe:	test   %rax,%rax
  762901:	jne    763071 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2321>
  762907:	lea    -0x692fd0(%rip),%rsi        # cf93e <GCC_except_table0+0xd536>
  76290e:	lea    0xc0(%rsp),%rdi
  762916:	mov    $0xf,%edx
  76291b:	mov    %r13,%rcx
  76291e:	call   75c980 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  762923:	test   %rax,%rax
  762926:	jne    763071 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2321>
  76292c:	lea    -0x692fe6(%rip),%rsi        # cf94d <GCC_except_table0+0xd545>
  762933:	lea    0xc0(%rsp),%rdi
  76293b:	mov    $0x11,%edx
  762940:	mov    0x118(%rsp),%rcx
  762948:	call   75c980 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  76294d:	test   %rax,%rax
  762950:	jne    763071 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2321>
  762956:	lea    -0x692fff(%rip),%rsi        # cf95e <GCC_except_table0+0xd556>
  76295d:	lea    0xc0(%rsp),%rdi
  762965:	mov    $0xb,%edx
  76296a:	mov    0x148(%rsp),%rcx
  762972:	call   75c980 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  762977:	test   %rax,%rax
  76297a:	jne    763071 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2321>
  762980:	lea    -0x69301e(%rip),%rsi        # cf969 <GCC_except_table0+0xd561>
  762987:	lea    0xc0(%rsp),%rdi
  76298f:	mov    $0xd,%edx
  762994:	mov    0xa8(%rsp),%rcx
  76299c:	call   75c980 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  7629a1:	test   %rax,%rax
  7629a4:	jne    763071 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2321>
  7629aa:	lea    -0x69303b(%rip),%rsi        # cf976 <GCC_except_table0+0xd56e>
  7629b1:	lea    0xc0(%rsp),%rdi
  7629b9:	mov    $0xd,%edx
  7629be:	mov    0x140(%rsp),%rcx
  7629c6:	call   75c980 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  7629cb:	test   %rax,%rax
  7629ce:	jne    763071 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2321>
  7629d4:	lea    -0x693058(%rip),%rsi        # cf983 <GCC_except_table0+0xd57b>
  7629db:	lea    0xc0(%rsp),%rdi
  7629e3:	mov    $0xc,%edx
  7629e8:	mov    0x210(%rsp),%rcx
  7629f0:	call   75c980 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  7629f5:	test   %rax,%rax
  7629f8:	jne    763071 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2321>
  7629fe:	lea    -0x693076(%rip),%rsi        # cf98f <GCC_except_table0+0xd587>
  762a05:	lea    0xc0(%rsp),%rdi
  762a0d:	mov    $0xd,%edx
  762a12:	mov    0x138(%rsp),%rcx
  762a1a:	call   75c980 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  762a1f:	test   %rax,%rax
  762a22:	jne    763071 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2321>
  762a28:	lea    -0x693093(%rip),%rsi        # cf99c <GCC_except_table0+0xd594>
  762a2f:	lea    0xc0(%rsp),%rdi
  762a37:	mov    $0xe,%edx
  762a3c:	mov    0x120(%rsp),%rcx
  762a44:	call   75c980 <_RINvXs6_NtNtCscl5MXVnO7Zx_10serde_json5value3serNtB6_12SerializeMapNtNtCs8znKHa7cbRS_10serde_core3ser15SerializeStruct15serialize_fieldyECs9C2G9YFESsD_29canonical_text_public_control>
  762a49:	test   %rax,%rax
  762a4c:	jne    763071 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2321>
  762a52:	movups 0xc0(%rsp),%xmm0
  762a5a:	movups 0xd0(%rsp),%xmm1
  762a62:	movups 0xe0(%rsp),%xmm2
  762a6a:	movaps %xmm2,0x40(%rsp)
  762a6f:	movaps %xmm1,0x30(%rsp)
  762a74:	movaps %xmm0,0x20(%rsp)
  762a79:	lea    0x240(%rsp),%rdi
  762a81:	lea    0x20(%rsp),%rsi
  762a86:	call   *0x357ab4(%rip)        # aba540 <_DYNAMIC+0x500>
  762a8c:	cmpb   $0xff,0x240(%rsp)
  762a94:	je     76333a <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x25ea>
  762a9a:	movups 0x240(%rsp),%xmm0
  762aa2:	movups 0x250(%rsp),%xmm1
  762aaa:	mov    0x2f8(%rsp),%rax
  762ab2:	movups %xmm1,0x28(%rax)
  762ab6:	movups %xmm0,0x18(%rax)
  762aba:	mov    %rbx,0x10(%rax)
  762abe:	mov    0x110(%rsp),%rcx
  762ac6:	mov    %rcx,0x8(%rax)
  762aca:	mov    0xb8(%rsp),%rcx
  762ad2:	mov    %rcx,(%rax)
  762ad5:	mov    0x10(%rsp),%rsi
  762ada:	test   %rsi,%rsi
  762add:	mov    0x8(%rsp),%rdi
  762ae2:	je     762af3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1da3>
  762ae4:	shl    $0x4,%rsi
  762ae8:	mov    $0x4,%edx
  762aed:	call   *0x35778d(%rip)        # aba280 <_DYNAMIC+0x240>
  762af3:	mov    0x18(%rsp),%r14
  762af8:	test   %r14,%r14
  762afb:	je     762b18 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1dc8>
  762afd:	mov    %r14,%rdi
  762b00:	call   748000 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui7runtime7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEEB1h_>
  762b05:	mov    $0x770,%esi
  762b0a:	mov    $0x8,%edx
  762b0f:	mov    %r14,%rdi
  762b12:	call   *0x357768(%rip)        # aba280 <_DYNAMIC+0x240>
  762b18:	mov    0x198(%rsp),%rsi
  762b20:	test   %rsi,%rsi
  762b23:	je     762b3c <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1dec>
  762b25:	mov    0x1a0(%rsp),%rdi
  762b2d:	shl    $0x2,%rsi
  762b31:	mov    $0x4,%edx
  762b36:	call   *0x357744(%rip)        # aba280 <_DYNAMIC+0x240>
  762b3c:	mov    0x130(%rsp),%rax
  762b44:	test   %rax,%rax
  762b47:	je     762b60 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1e10>
  762b49:	imul   $0x38,%rax,%rsi
  762b4d:	mov    $0x8,%edx
  762b52:	mov    0xa0(%rsp),%rdi
  762b5a:	call   *0x357720(%rip)        # aba280 <_DYNAMIC+0x240>
  762b60:	lea    0x340(%rsp),%rdi
  762b68:	call   74ccf0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text10TextLayoutECs9C2G9YFESsD_29canonical_text_public_control>
  762b6d:	mov    0x150(%rsp),%rax
  762b75:	lock decq (%rax)
  762b79:	jne    762b8b <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1e3b>
  762b7b:	xor    %ebp,%ebp
  762b7d:	lea    0x150(%rsp),%rdi
  762b85:	call   *0x3577e5(%rip)        # aba370 <_DYNAMIC+0x330>
  762b8b:	mov    0x2c0(%rsp),%rsi
  762b93:	test   %rsi,%rsi
  762b96:	je     762bab <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1e5b>
  762b98:	mov    0x2c8(%rsp),%rdi
  762ba0:	mov    $0x1,%edx
  762ba5:	call   *0x3576d5(%rip)        # aba280 <_DYNAMIC+0x240>
  762bab:	mov    0x158(%rsp),%rsi
  762bb3:	test   %rsi,%rsi
  762bb6:	je     762bcb <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1e7b>
  762bb8:	mov    0x160(%rsp),%rdi
  762bc0:	mov    $0x1,%edx
  762bc5:	call   *0x3576b5(%rip)        # aba280 <_DYNAMIC+0x240>
  762bcb:	add    $0x378,%rsp
  762bd2:	pop    %rbx
  762bd3:	pop    %r12
  762bd5:	pop    %r13
  762bd7:	pop    %r14
  762bd9:	pop    %r15
  762bdb:	pop    %rbp
  762bdc:	ret
  762bdd:	lea    -0x692f43(%rip),%rdi        # cfca1 <GCC_except_table0+0xd899>
  762be4:	lea    0x3392a5(%rip),%rdx        # a9be90 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x23a8>
  762beb:	mov    $0x13,%esi
  762bf0:	call   *0x3576c2(%rip)        # aba2b8 <_DYNAMIC+0x278>
  762bf6:	jmp    763320 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x25d0>
  762bfb:	testb  $0x1,0x148(%rsp)
  762c03:	mov    %rdx,%rax
  762c06:	cmove  %rsi,%rax
  762c0a:	mov    %rax,0x240(%rsp)
  762c12:	mov    0x18(%rsp),%rsi
  762c17:	test   %rsi,%rsi
  762c1a:	je     7632da <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x258a>
  762c20:	cmpb   $0x0,0x76e(%rsi)
  762c27:	jne    7632e1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2591>
  762c2d:	cmpb   $0x1,0x76c(%rsi)
  762c34:	jne    7632e8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2598>
  762c3a:	lea    0x20(%rsp),%rdi
  762c3f:	call   73de20 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime5queryNtB3_7Context3newNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEBX_>
  762c44:	mov    0x58(%rsp),%r12
  762c49:	test   %r12,%r12
  762c4c:	je     762735 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x19e5>
  762c52:	mov    0x50(%rsp),%rbp
  762c57:	add    $0x3d,%rbp
  762c5b:	xor    %r15d,%r15d
  762c5e:	mov    %rbx,%r13
  762c61:	jmp    762c80 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1f30>
  762c63:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  762c70:	inc    %r15
  762c73:	add    $0x40,%rbp
  762c77:	cmp    %r15,%r12
  762c7a:	je     762735 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x19e5>
  762c80:	cmpb   $0x4,0x0(%rbp)
  762c84:	jne    762c70 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1f20>
  762c86:	mov    -0x15(%rbp),%rdi
  762c8a:	test   %rdi,%rdi
  762c8d:	je     7631ea <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x249a>
  762c93:	mov    (%rdi),%rdx
  762c96:	shr    $1,%rdx
  762c99:	add    $0x10,%rdi
  762c9d:	mov    0x148(%rsp),%rcx
  762ca5:	test   $0x1,%cl
  762ca8:	mov    %rdi,0xc0(%rsp)
  762cb0:	mov    %rdx,0xc8(%rsp)
  762cb8:	lea    0x158(%rsp),%rsi
  762cc0:	mov    %rsi,%rax
  762cc3:	lea    0x2c0(%rsp),%r8
  762ccb:	cmove  %r8,%rax
  762ccf:	cmp    0x10(%rax),%rdx
  762cd3:	jne    762db8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2068>
  762cd9:	test   $0x1,%cl
  762cdc:	mov    %rsi,%rax
  762cdf:	cmove  %r8,%rax
  762ce3:	mov    0x8(%rax),%rsi
  762ce7:	call   *0x35785b(%rip)        # aba548 <bcmp@GLIBC_2.2.5>
  762ced:	test   %eax,%eax
  762cef:	jne    762db8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2068>
  762cf5:	lea    0xc0(%rsp),%rdi
  762cfd:	lea    0x20(%rsp),%rsi
  762d02:	mov    %r15,%rdx
  762d05:	call   *0x35777d(%rip)        # aba488 <_DYNAMIC+0x448>
  762d0b:	cmpq   $0x0,0xc0(%rsp)
  762d14:	je     762e8c <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x213c>
  762d1a:	mov    0xd0(%rsp),%rdi
  762d22:	call   7602a0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control14map_transcript>
  762d27:	mov    %rax,%rbx
  762d2a:	xor    %r13,%rbx
  762d2d:	movabs $0x100000001b3,%rax
  762d37:	imul   %rax,%rbx
  762d3b:	mov    %rbx,%r13
  762d3e:	jmp    762c70 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x1f20>
  762d43:	shl    $0xc,%eax
  762d46:	or     %edx,%eax
  762d48:	cmp    $0x80,%eax
  762d4d:	jb     760de7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x97>
  762d53:	mov    $0x2,%esi
  762d58:	cmp    $0x800,%eax
  762d5d:	jb     760de7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x97>
  762d63:	cmp    $0x10000,%eax
  762d68:	mov    $0x4,%esi
  762d6d:	sbb    $0x0,%rsi
  762d71:	jmp    760de7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x97>
  762d76:	lea    0x3373c3(%rip),%rdi        # a9a140 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x658>
  762d7d:	jmp    762dad <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x205d>
  762d7f:	lea    -0x6930e5(%rip),%rdi        # cfca1 <GCC_except_table0+0xd899>
  762d86:	lea    0x339103(%rip),%rdx        # a9be90 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x23a8>
  762d8d:	mov    $0x13,%esi
  762d92:	call   *0x357520(%rip)        # aba2b8 <_DYNAMIC+0x278>
  762d98:	jmp    763320 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x25d0>
  762d9d:	lea    0x3373b4(%rip),%rdi        # a9a158 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x670>
  762da4:	jmp    762dad <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x205d>
  762da6:	lea    0x3373c3(%rip),%rdi        # a9a170 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x688>
  762dad:	call   *0x35758d(%rip)        # aba340 <_DYNAMIC+0x300>
  762db3:	jmp    763320 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x25d0>
  762db8:	lea    0xc0(%rsp),%rdi
  762dc0:	lea    0x240(%rsp),%rsi
  762dc8:	call   74f63a <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedReRNtNtCscdodAO9FK5_5alloc6string6StringECs9C2G9YFESsD_29canonical_text_public_control>
  762dcd:	jmp    763320 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x25d0>
  762dd2:	lea    -0x693267(%rip),%rdi        # cfb72 <GCC_except_table0+0xd76a>
  762dd9:	lea    0x337c40(%rip),%rdx        # a9aa20 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xf38>
  762de0:	mov    $0x1b,%esi
  762de5:	call   *0x35750d(%rip)        # aba2f8 <_DYNAMIC+0x2b8>
  762deb:	mov    0x24(%rsp),%rax
  762df0:	mov    %rax,0xc0(%rsp)
  762df8:	lea    -0x693155(%rip),%rdi        # cfcaa <GCC_except_table0+0xd8a2>
  762dff:	lea    0x337f6a(%rip),%rcx        # a9ad70 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1288>
  762e06:	lea    0x337c43(%rip),%r8        # a9aa50 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xf68>
  762e0d:	lea    0xc0(%rsp),%rdx
  762e15:	mov    $0x2b,%esi
  762e1a:	call   *0x357530(%rip)        # aba350 <_DYNAMIC+0x310>
  762e20:	jmp    763320 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x25d0>
  762e25:	mov    0x28(%rsp),%rax
  762e2a:	mov    %rax,0x240(%rsp)
  762e32:	lea    -0x69318f(%rip),%rdi        # cfcaa <GCC_except_table0+0xd8a2>
  762e39:	lea    0x337f30(%rip),%rcx        # a9ad70 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1288>
  762e40:	lea    0x337c21(%rip),%r8        # a9aa68 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xf80>
  762e47:	lea    0x240(%rsp),%rdx
  762e4f:	mov    $0x2b,%esi
  762e54:	call   *0x3574f6(%rip)        # aba350 <_DYNAMIC+0x310>
  762e5a:	jmp    763320 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x25d0>
  762e5f:	lea    0x337c1a(%rip),%rdi        # a9aa80 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xf98>
  762e66:	call   *0x3574d4(%rip)        # aba340 <_DYNAMIC+0x300>
  762e6c:	jmp    763320 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x25d0>
  762e71:	lea    0x337d80(%rip),%rdi        # a9abf8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1110>
  762e78:	call   *0x3574c2(%rip)        # aba340 <_DYNAMIC+0x300>
  762e7e:	jmp    763320 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x25d0>
  762e83:	lea    0x337c0e(%rip),%rdi        # a9aa98 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xfb0>
  762e8a:	jmp    762e93 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2143>
  762e8c:	lea    0x33727d(%rip),%rdi        # a9a110 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x628>
  762e93:	call   *0x3574a7(%rip)        # aba340 <_DYNAMIC+0x300>
  762e99:	jmp    763320 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x25d0>
  762e9e:	lea    0x338c7b(%rip),%rcx        # a9bb20 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2038>
  762ea5:	xor    %edi,%edi
  762ea7:	call   *0x357423(%rip)        # aba2d0 <_DYNAMIC+0x290>
  762ead:	jmp    763320 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x25d0>
  762eb2:	lea    0x158(%rsp),%rdi
  762eba:	mov    $0x1,%edx
  762ebf:	mov    $0x1,%ecx
  762ec4:	mov    $0x1,%r8d
  762eca:	mov    %rbx,%rsi
  762ecd:	call   75b3f0 <_RINvNvMs2_NtCscdodAO9FK5_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs9C2G9YFESsD_29canonical_text_public_control>
  762ed2:	jmp    760e71 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x121>
  762ed7:	lea    -0x69ea6d(%rip),%rdi        # c4471 <GCC_except_table0+0x2069>
  762ede:	lea    0x337b53(%rip),%rdx        # a9aa38 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xf50>
  762ee5:	mov    $0x57,%esi
  762eea:	call   *0x3573c8(%rip)        # aba2b8 <_DYNAMIC+0x278>
  762ef0:	jmp    763320 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x25d0>
  762ef5:	lea    -0x69f0cc(%rip),%rdx        # c3e30 <GCC_except_table0+0x1a28>
  762efc:	lea    0x337cc5(%rip),%r9        # a9abc8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x10e0>
  762f03:	lea    0x20(%rsp),%rsi
  762f08:	xor    %edi,%edi
  762f0a:	xor    %ecx,%ecx
  762f0c:	call   *0x35763e(%rip)        # aba550 <_DYNAMIC+0x510>
  762f12:	jmp    763320 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x25d0>
  762f17:	mov    0xf0(%rsp),%rax
  762f1f:	mov    %rax,0x50(%rsp)
  762f24:	movups 0xc0(%rsp),%xmm0
  762f2c:	movups 0xd0(%rsp),%xmm1
  762f34:	movups 0xe0(%rsp),%xmm2
  762f3c:	movaps %xmm2,0x40(%rsp)
  762f41:	movaps %xmm1,0x30(%rsp)
  762f46:	movaps %xmm0,0x20(%rsp)
  762f4b:	lea    -0x6932a8(%rip),%rdi        # cfcaa <GCC_except_table0+0xd8a2>
  762f52:	lea    0x337dd7(%rip),%rcx        # a9ad30 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1248>
  762f59:	lea    0x337b78(%rip),%r8        # a9aad8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xff0>
  762f60:	lea    0x20(%rsp),%rdx
  762f65:	mov    $0x2b,%esi
  762f6a:	call   *0x3573e0(%rip)        # aba350 <_DYNAMIC+0x310>
  762f70:	jmp    763320 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x25d0>
  762f75:	mov    0xf0(%rsp),%rax
  762f7d:	mov    %rax,0x50(%rsp)
  762f82:	movups 0xc0(%rsp),%xmm0
  762f8a:	movups 0xd0(%rsp),%xmm1
  762f92:	movups 0xe0(%rsp),%xmm2
  762f9a:	movaps %xmm2,0x40(%rsp)
  762f9f:	movaps %xmm1,0x30(%rsp)
  762fa4:	movaps %xmm0,0x20(%rsp)
  762fa9:	lea    -0x693306(%rip),%rdi        # cfcaa <GCC_except_table0+0xd8a2>
  762fb0:	lea    0x337d79(%rip),%rcx        # a9ad30 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1248>
  762fb7:	lea    0x337b32(%rip),%r8        # a9aaf0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1008>
  762fbe:	lea    0x20(%rsp),%rdx
  762fc3:	mov    $0x2b,%esi
  762fc8:	call   *0x357382(%rip)        # aba350 <_DYNAMIC+0x310>
  762fce:	jmp    763320 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x25d0>
  762fd3:	mov    0xf0(%rsp),%rax
  762fdb:	mov    %rax,0x50(%rsp)
  762fe0:	movups 0xc0(%rsp),%xmm0
  762fe8:	movups 0xd0(%rsp),%xmm1
  762ff0:	movups 0xe0(%rsp),%xmm2
  762ff8:	movaps %xmm2,0x40(%rsp)
  762ffd:	movaps %xmm1,0x30(%rsp)
  763002:	movaps %xmm0,0x20(%rsp)
  763007:	lea    -0x693364(%rip),%rdi        # cfcaa <GCC_except_table0+0xd8a2>
  76300e:	lea    0x337d1b(%rip),%rcx        # a9ad30 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1248>
  763015:	lea    0x337b1c(%rip),%r8        # a9ab38 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1050>
  76301c:	lea    0x20(%rsp),%rdx
  763021:	mov    $0x2b,%esi
  763026:	call   *0x357324(%rip)        # aba350 <_DYNAMIC+0x310>
  76302c:	jmp    763320 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x25d0>
  763031:	lea    0x310(%rsp),%rdi
  763039:	call   74f5fd <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedReBM_ECs9C2G9YFESsD_29canonical_text_public_control>
  76303e:	jmp    763320 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x25d0>
  763043:	lea    0x8(%rcx),%rdi
  763047:	lea    0x18(%rcx),%rsi
  76304b:	lea    0x337b5e(%rip),%rdx        # a9abb0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x10c8>
  763052:	call   74f593 <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextPositionBM_ECs9C2G9YFESsD_29canonical_text_public_control>
  763057:	jmp    763320 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x25d0>
  76305c:	lea    0x336fa5(%rip),%rdx        # a9a008 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x520>
  763063:	mov    %r15,%rdi
  763066:	call   *0x357244(%rip)        # aba2b0 <_DYNAMIC+0x270>
  76306c:	jmp    763320 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x25d0>
  763071:	mov    %rax,%rbx
  763074:	mov    %rax,0x248(%rsp)
  76307c:	movb   $0xff,0x240(%rsp)
  763084:	mov    0xd8(%rsp),%rcx
  76308c:	test   %rcx,%rcx
  76308f:	jne    7630a9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2359>
  763091:	xor    %ecx,%ecx
  763093:	xor    %eax,%eax
  763095:	jmp    7630e4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2394>
  763097:	lea    0x33708a(%rip),%rdi        # a9a128 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x640>
  76309e:	call   *0x3574b4(%rip)        # aba558 <_DYNAMIC+0x518>
  7630a4:	jmp    763320 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x25d0>
  7630a9:	mov    0xe0(%rsp),%rdx
  7630b1:	mov    0xe8(%rsp),%rax
  7630b9:	movq   $0x0,0x28(%rsp)
  7630c2:	mov    %rcx,0x30(%rsp)
  7630c7:	mov    %rdx,0x38(%rsp)
  7630cc:	movq   $0x0,0x48(%rsp)
  7630d5:	mov    %rcx,0x50(%rsp)
  7630da:	mov    %rdx,0x58(%rsp)
  7630df:	mov    $0x1,%ecx
  7630e4:	mov    %rcx,0x20(%rsp)
  7630e9:	mov    %rcx,0x40(%rsp)
  7630ee:	mov    %rax,0x60(%rsp)
  7630f3:	lea    0x20(%rsp),%rdi
  7630f8:	call   74ad90 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtCscdodAO9FK5_5alloc11collections5btree3map8IntoIterNtNtBK_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueEECs9C2G9YFESsD_29canonical_text_public_control>
  7630fd:	mov    0xc0(%rsp),%rsi
  763105:	test   %rsi,%rsi
  763108:	jg     763322 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x25d2>
  76310e:	mov    %rbx,0x20(%rsp)
  763113:	lea    -0x693470(%rip),%rdi        # cfcaa <GCC_except_table0+0xd8a2>
  76311a:	lea    0x337c2f(%rip),%rcx        # a9ad50 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1268>
  763121:	lea    0x337a40(%rip),%r8        # a9ab68 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1080>
  763128:	lea    0x20(%rsp),%rdx
  76312d:	mov    $0x2b,%esi
  763132:	call   *0x357218(%rip)        # aba350 <_DYNAMIC+0x310>
  763138:	jmp    763320 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x25d0>
  76313d:	lea    0x337a54(%rip),%rdx        # a9ab98 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x10b0>
  763144:	mov    %rax,%rdi
  763147:	mov    0xa8(%rsp),%rsi
  76314f:	call   *0x35715b(%rip)        # aba2b0 <_DYNAMIC+0x270>
  763155:	jmp    763320 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x25d0>
  76315a:	mov    $0xe,%eax
  76315f:	jmp    763166 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2416>
  763161:	mov    $0x12,%eax
  763166:	mov    %rax,0x8(%rsp)
  76316b:	mov    0x8(%rsp),%rax
  763170:	mov    %rax,0x20(%rsp)
  763175:	lea    -0x69375b(%rip),%rdi        # cfa21 <GCC_except_table0+0xd619>
  76317c:	lea    0x337bad(%rip),%rcx        # a9ad30 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1248>
  763183:	lea    0x3374f6(%rip),%r8        # a9a680 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xb98>
  76318a:	lea    0x20(%rsp),%rdx
  76318f:	mov    $0x2a,%esi
  763194:	call   *0x3571b6(%rip)        # aba350 <_DYNAMIC+0x310>
  76319a:	jmp    763320 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x25d0>
  76319f:	mov    $0xd,%eax
  7631a4:	jmp    7631b2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2462>
  7631a6:	mov    $0xe,%eax
  7631ab:	jmp    7631b2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2462>
  7631ad:	mov    $0x12,%eax
  7631b2:	mov    %rax,0x20(%rsp)
  7631b7:	movq   $0x0,0x28(%rsp)
  7631c0:	lea    -0x69351d(%rip),%rdi        # cfcaa <GCC_except_table0+0xd8a2>
  7631c7:	lea    0x337b62(%rip),%rcx        # a9ad30 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1248>
  7631ce:	lea    0x337ae3(%rip),%r8        # a9acb8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x11d0>
  7631d5:	lea    0x20(%rsp),%rdx
  7631da:	mov    $0x2b,%esi
  7631df:	call   *0x35716b(%rip)        # aba350 <_DYNAMIC+0x310>
  7631e5:	jmp    763320 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x25d0>
  7631ea:	lea    0x336eef(%rip),%rdi        # a9a0e0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x5f8>
  7631f1:	jmp    762e93 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2143>
  7631f6:	movq   $0xd,0x20(%rsp)
  7631ff:	movq   $0x0,0x28(%rsp)
  763208:	lea    -0x693675(%rip),%rdi        # cfb9a <GCC_except_table0+0xd792>
  76320f:	lea    0x337b1a(%rip),%rcx        # a9ad30 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1248>
  763216:	lea    0x337933(%rip),%r8        # a9ab50 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1068>
  76321d:	lea    0x20(%rsp),%rdx
  763222:	mov    $0x24,%esi
  763227:	call   *0x357123(%rip)        # aba350 <_DYNAMIC+0x310>
  76322d:	jmp    763320 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x25d0>
  763232:	mov    $0x8,%edi
  763237:	mov    $0xe0,%esi
  76323c:	call   *0x3570ee(%rip)        # aba330 <_DYNAMIC+0x2f0>
  763242:	jmp    763320 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x25d0>
  763247:	mov    $0x4,%edi
  76324c:	mov    %rbx,%rsi
  76324f:	call   *0x3570db(%rip)        # aba330 <_DYNAMIC+0x2f0>
  763255:	jmp    763320 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x25d0>
  76325a:	movq   $0xd,0xc0(%rsp)
  763266:	movq   $0x0,0xc8(%rsp)
  763272:	mov    0xf0(%rsp),%rax
  76327a:	mov    %rax,0x50(%rsp)
  76327f:	mov    0xc0(%rsp),%rax
  763287:	mov    0xc8(%rsp),%rcx
  76328f:	movups 0xd0(%rsp),%xmm0
  763297:	movups 0xe0(%rsp),%xmm1
  76329f:	movaps %xmm1,0x40(%rsp)
  7632a4:	movaps %xmm0,0x30(%rsp)
  7632a9:	mov    %rax,0x20(%rsp)
  7632ae:	mov    %rcx,0x28(%rsp)
  7632b3:	lea    -0x693610(%rip),%rdi        # cfcaa <GCC_except_table0+0xd8a2>
  7632ba:	lea    0x337a6f(%rip),%rcx        # a9ad30 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1248>
  7632c1:	lea    0x3377f8(%rip),%r8        # a9aac0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xfd8>
  7632c8:	lea    0x20(%rsp),%rdx
  7632cd:	mov    $0x2b,%esi
  7632d2:	call   *0x357078(%rip)        # aba350 <_DYNAMIC+0x310>
  7632d8:	jmp    763320 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x25d0>
  7632da:	mov    $0xd,%eax
  7632df:	jmp    7632ed <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x259d>
  7632e1:	mov    $0xe,%eax
  7632e6:	jmp    7632ed <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x259d>
  7632e8:	mov    $0x12,%eax
  7632ed:	mov    %rax,0x20(%rsp)
  7632f2:	movq   $0x0,0x28(%rsp)
  7632fb:	lea    -0x693658(%rip),%rdi        # cfcaa <GCC_except_table0+0xd8a2>
  763302:	lea    0x337a27(%rip),%rcx        # a9ad30 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1248>
  763309:	lea    0x337810(%rip),%r8        # a9ab20 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1038>
  763310:	lea    0x20(%rsp),%rdx
  763315:	mov    $0x2b,%esi
  76331a:	call   *0x357030(%rip)        # aba350 <_DYNAMIC+0x310>
  763320:	ud2
  763322:	mov    0xc8(%rsp),%rdi
  76332a:	mov    $0x1,%edx
  76332f:	call   *0x356f4b(%rip)        # aba280 <_DYNAMIC+0x240>
  763335:	jmp    76310e <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x23be>
  76333a:	mov    0x248(%rsp),%rbx
  763342:	jmp    76310e <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x23be>
  763347:	jmp    763497 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2747>
  76334c:	jmp    763422 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x26d2>
  763351:	jmp    763422 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x26d2>
  763356:	mov    %rax,%rbx
  763359:	jmp    7635e2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2892>
  76335e:	mov    %rax,%rbx
  763361:	mov    $0x1,%bpl
  763364:	jmp    763533 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x27e3>
  763369:	mov    %rax,%rbx
  76336c:	xor    %ebp,%ebp
  76336e:	jmp    763564 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2814>
  763373:	jmp    763422 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x26d2>
  763378:	jmp    763422 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x26d2>
  76337d:	jmp    763416 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x26c6>
  763382:	mov    %rax,%rbx
  763385:	jmp    7635c5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2875>
  76338a:	jmp    7634de <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x278e>
  76338f:	jmp    763497 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2747>
  763394:	mov    %rax,%rbx
  763397:	mov    0xc0(%rsp),%rsi
  76339f:	test   %rsi,%rsi
  7633a2:	jle    7634e1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2791>
  7633a8:	mov    0xc8(%rsp),%rdi
  7633b0:	mov    $0x1,%edx
  7633b5:	call   *0x356ec5(%rip)        # aba280 <_DYNAMIC+0x240>
  7633bb:	jmp    7634e1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2791>
  7633c0:	mov    %rax,%rbx
  7633c3:	lea    0x20(%rsp),%rdi
  7633c8:	call   74cab0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5error5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  7633cd:	jmp    7634e1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2791>
  7633d2:	call   *0x356ed0(%rip)        # aba2a8 <_DYNAMIC+0x268>
  7633d8:	mov    %rax,%rbx
  7633db:	lea    0x20(%rsp),%rdi
  7633e0:	call   74d810 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  7633e5:	jmp    7634c7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2777>
  7633ea:	mov    %rax,%rbx
  7633ed:	lea    0xc0(%rsp),%rdi
  7633f5:	call   74e230 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCscl5MXVnO7Zx_10serde_json5value3ser12SerializeMapECs9C2G9YFESsD_29canonical_text_public_control>
  7633fa:	jmp    7634e1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2791>
  7633ff:	call   *0x356ea3(%rip)        # aba2a8 <_DYNAMIC+0x268>
  763405:	jmp    7634de <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x278e>
  76340a:	jmp    7634c4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2774>
  76340f:	jmp    7634c4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2774>
  763414:	jmp    76348c <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x273c>
  763416:	mov    %rax,%rbx
  763419:	jmp    7634ff <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x27af>
  76341e:	jmp    763422 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x26d2>
  763420:	jmp    763422 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x26d2>
  763422:	mov    %rax,%rbx
  763425:	lea    0x20(%rsp),%rdi
  76342a:	call   74d810 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  76342f:	jmp    7634e1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2791>
  763434:	mov    %rax,%rbx
  763437:	lea    0x20(%rsp),%rdi
  76343c:	call   74d810 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  763441:	jmp    7634ff <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x27af>
  763446:	jmp    7634c4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2774>
  763448:	mov    %rax,%rbx
  76344b:	mov    $0x1,%bpl
  76344e:	jmp    7635a0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2850>
  763453:	mov    %rax,%rbx
  763456:	mov    0x198(%rsp),%rsi
  76345e:	test   %rsi,%rsi
  763461:	jne    76351c <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x27cc>
  763467:	jmp    763533 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x27e3>
  76346c:	mov    %rax,%rbx
  76346f:	mov    0xc8(%rsp),%rdi
  763477:	call   74cd80 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text10TextShaperECs9C2G9YFESsD_29canonical_text_public_control>
  76347c:	mov    $0x1,%bpl
  76347f:	jmp    763564 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2814>
  763484:	mov    %rax,%rbx
  763487:	jmp    763580 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2830>
  76348c:	mov    %rax,%rbx
  76348f:	mov    $0x1,%bpl
  763492:	jmp    763557 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2807>
  763497:	mov    %rax,%rbx
  76349a:	mov    0x170(%rsp),%rax
  7634a2:	mov    $0x1,%bpl
  7634a5:	test   %rax,%rax
  7634a8:	je     763557 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2807>
  7634ae:	mov    0x178(%rsp),%rdi
  7634b6:	imul   $0x38,%rax,%rsi
  7634ba:	mov    $0x8,%edx
  7634bf:	jmp    763551 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2801>
  7634c4:	mov    %rax,%rbx
  7634c7:	mov    0x1f8(%rsp),%rsi
  7634cf:	test   %rsi,%rsi
  7634d2:	je     7634ff <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x27af>
  7634d4:	mov    0x200(%rsp),%rdi
  7634dc:	jmp    7634f0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x27a0>
  7634de:	mov    %rax,%rbx
  7634e1:	mov    0x8(%rsp),%rdi
  7634e6:	mov    0x10(%rsp),%rsi
  7634eb:	test   %rsi,%rsi
  7634ee:	je     7634ff <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x27af>
  7634f0:	shl    $0x4,%rsi
  7634f4:	mov    $0x4,%edx
  7634f9:	call   *0x356d81(%rip)        # aba280 <_DYNAMIC+0x240>
  7634ff:	mov    0x18(%rsp),%r14
  763504:	test   %r14,%r14
  763507:	jne    7635da <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x288a>
  76350d:	xor    %ebp,%ebp
  76350f:	mov    0x198(%rsp),%rsi
  763517:	test   %rsi,%rsi
  76351a:	je     763533 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x27e3>
  76351c:	mov    0x1a0(%rsp),%rdi
  763524:	shl    $0x2,%rsi
  763528:	mov    $0x4,%edx
  76352d:	call   *0x356d4d(%rip)        # aba280 <_DYNAMIC+0x240>
  763533:	mov    0x130(%rsp),%rax
  76353b:	test   %rax,%rax
  76353e:	je     763557 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2807>
  763540:	imul   $0x38,%rax,%rsi
  763544:	mov    $0x8,%edx
  763549:	mov    0xa0(%rsp),%rdi
  763551:	call   *0x356d29(%rip)        # aba280 <_DYNAMIC+0x240>
  763557:	lea    0x340(%rsp),%rdi
  76355f:	call   74ccf0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text10TextLayoutECs9C2G9YFESsD_29canonical_text_public_control>
  763564:	mov    0x150(%rsp),%rax
  76356c:	lock decq (%rax)
  763570:	jne    763580 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2830>
  763572:	lea    0x150(%rsp),%rdi
  76357a:	call   *0x356df0(%rip)        # aba370 <_DYNAMIC+0x330>
  763580:	mov    0x2c0(%rsp),%rsi
  763588:	test   %rsi,%rsi
  76358b:	je     7635a0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2850>
  76358d:	mov    0x2c8(%rsp),%rdi
  763595:	mov    $0x1,%edx
  76359a:	call   *0x356ce0(%rip)        # aba280 <_DYNAMIC+0x240>
  7635a0:	mov    0x158(%rsp),%rsi
  7635a8:	test   %rsi,%rsi
  7635ab:	je     7635c0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2870>
  7635ad:	mov    0x160(%rsp),%rdi
  7635b5:	mov    $0x1,%edx
  7635ba:	call   *0x356cc0(%rip)        # aba280 <_DYNAMIC+0x240>
  7635c0:	test   %bpl,%bpl
  7635c3:	je     7635d2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x2882>
  7635c5:	mov    0x228(%rsp),%rsi
  7635cd:	test   %rsi,%rsi
  7635d0:	jne    76360d <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x28bd>
  7635d2:	mov    %rbx,%rdi
  7635d5:	call   a98730 <_Unwind_Resume@plt>
  7635da:	mov    %r14,%rdi
  7635dd:	call   748000 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui7runtime7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEEB1h_>
  7635e2:	mov    $0x770,%esi
  7635e7:	mov    $0x8,%edx
  7635ec:	mov    %r14,%rdi
  7635ef:	call   *0x356c8b(%rip)        # aba280 <_DYNAMIC+0x240>
  7635f5:	xor    %ebp,%ebp
  7635f7:	mov    0x198(%rsp),%rsi
  7635ff:	test   %rsi,%rsi
  763602:	jne    76351c <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x27cc>
  763608:	jmp    763533 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run+0x27e3>
  76360d:	mov    0x230(%rsp),%rdi
  763615:	mov    $0x1,%edx
  76361a:	call   *0x356c60(%rip)        # aba280 <_DYNAMIC+0x240>
  763620:	mov    %rbx,%rdi
  763623:	call   a98730 <_Unwind_Resume@plt>
  763628:	mov    $0x770,%esi
  76362d:	mov    $0x8,%edx
  763632:	mov    %r14,%rdi
  763635:	call   *0x356c45(%rip)        # aba280 <_DYNAMIC+0x240>
  76363b:	call   *0x356c67(%rip)        # aba2a8 <_DYNAMIC+0x268>
  763641:	call   *0x356c61(%rip)        # aba2a8 <_DYNAMIC+0x268>

canonical_text_public_control::main bytes=9055 frame=776

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000763650 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main>:
  763650:	push   %rbp
  763651:	push   %r15
  763653:	push   %r14
  763655:	push   %r13
  763657:	push   %r12
  763659:	push   %rbx
  76365a:	sub    $0x2d8,%rsp
  763661:	lea    0x60(%rsp),%rbx
  763666:	mov    %rbx,%rdi
  763669:	call   *0x356ef1(%rip)        # aba560 <_DYNAMIC+0x520>
  76366f:	movq   $0x0,0x80(%rsp)
  76367b:	lea    0x150(%rsp),%rdi
  763683:	mov    $0x1,%edx
  763688:	mov    %rbx,%rsi
  76368b:	call   799ac0 <_RNvYNtNtCs2AWtUsOyxgP_3std3env4ArgsNtNtNtNtCs4NRVxsYgnAr_4core4iter6traits8iterator8Iterator3nthCs9C2G9YFESsD_29canonical_text_public_control>
  763690:	mov    0x150(%rsp),%rax
  763698:	mov    %rax,0x18(%rsp)
  76369d:	cmp    $0xffffffffffffffff,%rax
  7636a1:	je     765352 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1d02>
  7636a7:	mov    0x158(%rsp),%rbx
  7636af:	mov    0x78(%rsp),%rax
  7636b4:	sub    0x68(%rsp),%rax
  7636b9:	shr    $0x3,%rax
  7636bd:	movabs $0xaaaaaaaaaaaaaaab,%rcx
  7636c7:	imul   %rcx,%rax
  7636cb:	xor    %r14d,%r14d
  7636ce:	sub    0x80(%rsp),%rax
  7636d6:	cmovb  %r14,%rax
  7636da:	cmp    $0x4,%rax
  7636de:	mov    $0x3,%r12d
  7636e4:	cmovae %rax,%r12
  7636e8:	lea    0x8(,%r12,8),%rcx
  7636f0:	lea    (%rcx,%rcx,2),%r15
  7636f4:	movabs $0x555555555555554,%rcx
  7636fe:	cmp    %rcx,%rax
  763701:	jbe    763714 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xc4>
  763703:	mov    %r14,%rdi
  763706:	mov    %r15,%rsi
  763709:	call   *0x356c21(%rip)        # aba330 <_DYNAMIC+0x2f0>
  76370f:	jmp    76541d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  763714:	mov    0x160(%rsp),%rbp
  76371c:	test   %r15,%r15
  76371f:	je     763748 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xf8>
  763721:	call   *0x356b61(%rip)        # aba288 <_DYNAMIC+0x248>
  763727:	mov    $0x8,%r14d
  76372d:	mov    $0x8,%esi
  763732:	mov    %r15,%rdi
  763735:	call   *0x356b55(%rip)        # aba290 <_DYNAMIC+0x250>
  76373b:	test   %rax,%rax
  76373e:	je     763703 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xb3>
  763740:	mov    %rax,%r13
  763743:	inc    %r12
  763746:	jmp    763751 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x101>
  763748:	mov    $0x8,%r13d
  76374e:	xor    %r12d,%r12d
  763751:	mov    0x18(%rsp),%rax
  763756:	mov    %rax,0x0(%r13)
  76375a:	mov    %rbx,0x8(%r13)
  76375e:	mov    %rbp,0x10(%r13)
  763762:	mov    %r12,0x28(%rsp)
  763767:	mov    %r13,0x30(%rsp)
  76376c:	movq   $0x1,0x38(%rsp)
  763775:	mov    0x80(%rsp),%rax
  76377d:	mov    %rax,0x170(%rsp)
  763785:	movups 0x60(%rsp),%xmm0
  76378a:	movups 0x70(%rsp),%xmm1
  76378f:	movaps %xmm1,0x160(%rsp)
  763797:	movaps %xmm0,0x150(%rsp)
  76379f:	mov    $0x1,%ebx
  7637a4:	mov    $0x28,%r15d
  7637aa:	jmp    7637eb <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x19b>
  7637ac:	nopl   0x0(%rax)
  7637b0:	inc    %rdx
  7637b3:	mov    $0x8,%ecx
  7637b8:	mov    $0x18,%r8d
  7637be:	lea    0x28(%rsp),%rdi
  7637c3:	mov    %rbx,%rsi
  7637c6:	call   75b3f0 <_RINvNvMs2_NtCscdodAO9FK5_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs9C2G9YFESsD_29canonical_text_public_control>
  7637cb:	mov    0x30(%rsp),%r13
  7637d0:	mov    %r14,-0x10(%r13,%r15,1)
  7637d5:	mov    %rbp,-0x8(%r13,%r15,1)
  7637da:	mov    %r12,0x0(%r13,%r15,1)
  7637df:	inc    %rbx
  7637e2:	mov    %rbx,0x38(%rsp)
  7637e7:	add    $0x18,%r15
  7637eb:	mov    0x170(%rsp),%rdx
  7637f3:	test   %rdx,%rdx
  7637f6:	jne    76386a <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x21a>
  7637f8:	lea    0x1f0(%rsp),%rdi
  763800:	lea    0x150(%rsp),%rsi
  763808:	call   *0x356d5a(%rip)        # aba568 <_DYNAMIC+0x528>
  76380e:	mov    0x1f0(%rsp),%r14
  763816:	cmp    $0xffffffffffffffff,%r14
  76381a:	je     76388d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x23d>
  76381c:	mov    0x1f8(%rsp),%rbp
  763824:	mov    0x200(%rsp),%r12
  76382c:	cmp    0x28(%rsp),%rbx
  763831:	jne    7637d0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x180>
  763833:	mov    0x168(%rsp),%rdx
  76383b:	sub    0x158(%rsp),%rdx
  763843:	shr    $0x3,%rdx
  763847:	movabs $0xaaaaaaaaaaaaaaab,%rax
  763851:	imul   %rax,%rdx
  763855:	sub    0x170(%rsp),%rdx
  76385d:	jae    7637b0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x160>
  763863:	xor    %edx,%edx
  763865:	jmp    7637b0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x160>
  76386a:	movq   $0x0,0x170(%rsp)
  763876:	lea    0x1f0(%rsp),%rdi
  76387e:	lea    0x150(%rsp),%rsi
  763886:	call   799ac0 <_RNvYNtNtCs2AWtUsOyxgP_3std3env4ArgsNtNtNtNtCs4NRVxsYgnAr_4core4iter6traits8iterator8Iterator3nthCs9C2G9YFESsD_29canonical_text_public_control>
  76388b:	jmp    76380e <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1be>
  76388d:	mov    0x158(%rsp),%r15
  763895:	mov    0x168(%rsp),%rcx
  76389d:	mov    %rcx,%rax
  7638a0:	sub    %r15,%rax
  7638a3:	movabs $0xaaaaaaaaaaaaaaab,%rdx
  7638ad:	mul    %rdx
  7638b0:	cmp    %r15,%rcx
  7638b3:	je     7638ef <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x29f>
  7638b5:	mov    %rdx,%r14
  7638b8:	shr    $0x4,%r14
  7638bc:	add    $0x8,%r15
  7638c0:	mov    0x3569b9(%rip),%r12        # aba280 <_DYNAMIC+0x240>
  7638c7:	jmp    7638d9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x289>
  7638c9:	nopl   0x0(%rax)
  7638d0:	add    $0x18,%r15
  7638d4:	dec    %r14
  7638d7:	je     7638ef <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x29f>
  7638d9:	mov    -0x8(%r15),%rsi
  7638dd:	test   %rsi,%rsi
  7638e0:	je     7638d0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x280>
  7638e2:	mov    (%r15),%rdi
  7638e5:	mov    $0x1,%edx
  7638ea:	call   *%r12
  7638ed:	jmp    7638d0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x280>
  7638ef:	mov    0x160(%rsp),%rax
  7638f7:	test   %rax,%rax
  7638fa:	je     763917 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2c7>
  7638fc:	mov    0x150(%rsp),%rdi
  763904:	shl    $0x3,%rax
  763908:	lea    (%rax,%rax,2),%rsi
  76390c:	mov    $0x8,%edx
  763911:	call   *0x356969(%rip)        # aba280 <_DYNAMIC+0x240>
  763917:	mov    0x28(%rsp),%rax
  76391c:	mov    %rax,0x288(%rsp)
  763924:	mov    0x30(%rsp),%rax
  763929:	mov    0x8(%rax),%rdi
  76392d:	mov    %rax,0x20(%rsp)
  763932:	mov    0x10(%rax),%rax
  763936:	cmp    $0x6,%rax
  76393a:	je     763987 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x337>
  76393c:	cmp    $0x7,%rax
  763940:	jne    7653ae <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1d5e>
  763946:	mov    $0x7361656d,%eax
  76394b:	xor    (%rdi),%eax
  76394d:	mov    $0x65727573,%ecx
  763952:	xor    0x3(%rdi),%ecx
  763955:	or     %eax,%ecx
  763957:	mov    $0x1,%r9b
  76395a:	jne    7653ae <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1d5e>
  763960:	cmp    $0x3,%rbx
  763964:	jbe    7639c2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x372>
  763966:	mov    0x20(%rsp),%rax
  76396b:	mov    0x50(%rax),%rcx
  76396f:	mov    0x58(%rax),%rsi
  763973:	cmp    $0x1,%rsi
  763977:	je     7639dc <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x38c>
  763979:	test   %rsi,%rsi
  76397c:	je     76541f <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcf>
  763982:	movzbl (%rcx),%edx
  763985:	jmp    7639f3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x3a3>
  763987:	mov    $0x6361726f,%eax
  76398c:	xor    (%rdi),%eax
  76398e:	movzwl 0x4(%rdi),%ecx
  763992:	xor    $0x656c,%ecx
  763998:	or     %eax,%ecx
  76399a:	je     763a97 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x447>
  7639a0:	mov    $0x69726576,%eax
  7639a5:	xor    (%rdi),%eax
  7639a7:	movzwl 0x4(%rdi),%ecx
  7639ab:	xor    $0x7966,%ecx
  7639b1:	or     %eax,%ecx
  7639b3:	jne    7653ae <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1d5e>
  7639b9:	xor    %r9d,%r9d
  7639bc:	cmp    $0x3,%rbx
  7639c0:	ja     763966 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x316>
  7639c2:	lea    0x33725f(%rip),%rdx        # a9ac28 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1140>
  7639c9:	mov    $0x3,%edi
  7639ce:	mov    %rbx,%rsi
  7639d1:	call   *0x3568d9(%rip)        # aba2b0 <_DYNAMIC+0x270>
  7639d7:	jmp    76541d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  7639dc:	movzbl (%rcx),%edx
  7639df:	mov    $0x1,%al
  7639e1:	cmp    $0x2b,%edx
  7639e4:	je     764f00 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x18b0>
  7639ea:	cmp    $0x2d,%edx
  7639ed:	je     764f00 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x18b0>
  7639f3:	xor    %eax,%eax
  7639f5:	cmp    $0x2b,%dl
  7639f8:	sete   %al
  7639fb:	mov    %rsi,%rdx
  7639fe:	sub    %rax,%rdx
  763a01:	add    %rax,%rcx
  763a04:	neg    %rax
  763a07:	cmp    $0x11,%rdx
  763a0b:	jae    763a4e <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x3fe>
  763a0d:	test   %rdx,%rdx
  763a10:	je     76409b <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xa4b>
  763a16:	add    %rax,%rsi
  763a19:	neg    %rsi
  763a1c:	xor    %eax,%eax
  763a1e:	xor    %edx,%edx
  763a20:	movzbl (%rcx,%rdx,1),%r8d
  763a25:	add    $0xffffffd0,%r8d
  763a29:	cmp    $0x9,%r8d
  763a2d:	ja     76512c <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1adc>
  763a33:	lea    (%rax,%rax,4),%rax
  763a37:	mov    %r8d,%r8d
  763a3a:	lea    (%r8,%rax,2),%rax
  763a3e:	inc    %rdx
  763a41:	mov    %rsi,%r8
  763a44:	add    %rdx,%r8
  763a47:	jne    763a20 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x3d0>
  763a49:	jmp    76409d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xa4d>
  763a4e:	add    %rax,%rsi
  763a51:	neg    %rsi
  763a54:	xor    %eax,%eax
  763a56:	mov    $0xa,%r8d
  763a5c:	xor    %r10d,%r10d
  763a5f:	nop
  763a60:	mov    %rsi,%rdx
  763a63:	add    %r10,%rdx
  763a66:	je     76409d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xa4d>
  763a6c:	mul    %r8
  763a6f:	movzbl (%rcx,%r10,1),%edx
  763a74:	jo     764ef6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x18a6>
  763a7a:	add    $0xffffffd0,%edx
  763a7d:	cmp    $0xa,%edx
  763a80:	jae    76512c <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1adc>
  763a86:	mov    %edx,%edx
  763a88:	inc    %r10
  763a8b:	add    %rdx,%rax
  763a8e:	jae    763a60 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x410>
  763a90:	mov    $0x2,%al
  763a92:	jmp    764f00 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x18b0>
  763a97:	movq   $0x0,0x150(%rsp)
  763aa3:	movq   $0x8,0x158(%rsp)
  763aaf:	movups 0x336ca2(%rip),%xmm0        # a9a758 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xc70>
  763ab6:	movups %xmm0,0x160(%rsp)
  763abe:	movups 0x336ca3(%rip),%xmm0        # a9a768 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xc80>
  763ac5:	movups %xmm0,0x170(%rsp)
  763acd:	movups 0x336ca4(%rip),%xmm0        # a9a778 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xc90>
  763ad4:	movups %xmm0,0x180(%rsp)
  763adc:	movups 0x336ca5(%rip),%xmm0        # a9a788 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xca0>
  763ae3:	movups %xmm0,0x190(%rsp)
  763aeb:	movups 0x336ca6(%rip),%xmm0        # a9a798 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xcb0>
  763af2:	movups %xmm0,0x1a0(%rsp)
  763afa:	movups 0x336ca7(%rip),%xmm0        # a9a7a8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xcc0>
  763b01:	movups %xmm0,0x1b0(%rsp)
  763b09:	movups 0x336ca8(%rip),%xmm0        # a9a7b8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xcd0>
  763b10:	movups %xmm0,0x1c0(%rsp)
  763b18:	movups 0x336ca9(%rip),%xmm0        # a9a7c8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xce0>
  763b1f:	movups %xmm0,0x1d0(%rsp)
  763b27:	mov    $0x1,%r14d
  763b2d:	lea    0x2b8(%rsp),%r15
  763b35:	lea    0x60(%rsp),%rbp
  763b3a:	xor    %r12d,%r12d
  763b3d:	jmp    763b86 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x536>
  763b3f:	nop
  763b40:	mov    $0x770,%esi
  763b45:	mov    $0x8,%edx
  763b4a:	mov    %r14,%rdi
  763b4d:	call   *0x35672d(%rip)        # aba280 <_DYNAMIC+0x240>
  763b53:	mov    0xf8(%rsp),%r14
  763b5b:	xor    %r12,%r14
  763b5e:	movabs $0x100000001b3,%rax
  763b68:	imul   %rax,%r14
  763b6c:	mov    %r13,0x2b0(%rsp)
  763b74:	mov    0x290(%rsp),%r12
  763b7c:	cmp    $0x8,%r12
  763b80:	je     7646a6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1056>
  763b86:	mov    %r12,%rax
  763b89:	shl    $0x4,%rax
  763b8d:	lea    0x160(%rsp),%rcx
  763b95:	mov    (%rcx,%rax,1),%rsi
  763b99:	mov    0x8(%rcx,%rax,1),%rdx
  763b9e:	mov    %r15,%rdi
  763ba1:	call   7664b0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source>
  763ba6:	mov    %rbp,%rdi
  763ba9:	mov    %r15,%rsi
  763bac:	call   *0x356956(%rip)        # aba508 <_DYNAMIC+0x4c8>
  763bb2:	mov    %rbp,%rdi
  763bb5:	call   7659b0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount>
  763bba:	mov    %rax,%r13
  763bbd:	mov    %rax,0x260(%rsp)
  763bc5:	cmpb   $0x0,0x76e(%rax)
  763bcc:	jne    765175 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1b25>
  763bd2:	cmpb   $0x1,0x76a(%r13)
  763bda:	jne    76516e <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1b1e>
  763be0:	mov    %r14,0xf8(%rsp)
  763be8:	mov    0x5c0(%r13),%r15
  763bef:	mov    $0x1a,%eax
  763bf4:	mov    %rax,0x1e8(%rsp)
  763bfc:	test   %r15,%r15
  763bff:	je     765182 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1b32>
  763c05:	inc    %r12
  763c08:	mov    %r12,0x290(%rsp)
  763c10:	mov    0x5b8(%r13),%rbp
  763c17:	shl    $0x6,%r15
  763c1b:	lea    0x1e8(%r13),%r14
  763c22:	xor    %r12d,%r12d
  763c25:	jmp    763c3d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x5ed>
  763c27:	nopw   0x0(%rax,%rax,1)
  763c30:	add    $0x40,%r12
  763c34:	cmp    %r12,%r15
  763c37:	je     765182 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1b32>
  763c3d:	cmpb   $0x4,0x3d(%rbp,%r12,1)
  763c43:	jne    763c30 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x5e0>
  763c45:	mov    0x20(%rbp,%r12,1),%rsi
  763c4a:	mov    %r14,%rdi
  763c4d:	call   *0x3566e5(%rip)        # aba338 <_DYNAMIC+0x2f8>
  763c53:	test   %al,%al
  763c55:	je     763c30 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x5e0>
  763c57:	mov    0x20(%rbp,%r12,1),%rsi
  763c5c:	add    $0x5f0,%r13
  763c63:	mov    %r13,%rdi
  763c66:	call   *0x356874(%rip)        # aba4e0 <_DYNAMIC+0x4a0>
  763c6c:	mov    %rax,%r14
  763c6f:	mov    %rdx,%r12
  763c72:	mov    0x260(%rsp),%rsi
  763c7a:	lea    0x100(%rsp),%rdi
  763c82:	call   75cb80 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_>
  763c87:	mov    0x2c8(%rsp),%rax
  763c8f:	mov    %rax,%rcx
  763c92:	shr    $0x20,%rcx
  763c96:	lea    0x2b8(%rsp),%r15
  763c9e:	lea    0x60(%rsp),%rbp
  763ca3:	jne    764f62 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1912>
  763ca9:	movl   $0x0,0x60(%rsp)
  763cb1:	movb   $0x1,0x64(%rsp)
  763cb6:	mov    %eax,0x68(%rsp)
  763cba:	movb   $0x1,0x6c(%rsp)
  763cbf:	mov    0x260(%rsp),%rsi
  763cc7:	test   %rsi,%rsi
  763cca:	je     7651cd <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1b7d>
  763cd0:	lea    0x1f0(%rsp),%rdi
  763cd8:	mov    %r14,0x18(%rsp)
  763cdd:	mov    %r14,%rdx
  763ce0:	mov    %r12,0x8(%rsp)
  763ce5:	mov    %r12,%rcx
  763ce8:	mov    %rbp,%r8
  763ceb:	call   76fcd0 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE12select_inputB12_>
  763cf0:	cmpq   $0xfffffffffffffffe,0x1f0(%rsp)
  763cf9:	jne    7651e5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1b95>
  763cff:	mov    0x260(%rsp),%rax
  763d07:	test   %rax,%rax
  763d0a:	je     765256 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1c06>
  763d10:	cmpb   $0x0,0x76e(%rax)
  763d17:	jne    765269 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1c19>
  763d1d:	mov    0x6d0(%rax),%r13
  763d24:	test   %r13,%r13
  763d27:	je     765270 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1c20>
  763d2d:	mov    0x6d8(%rax),%r12
  763d34:	mov    %rax,0x28(%rsp)
  763d39:	lea    0x268(%rsp),%rax
  763d41:	mov    %rax,0x30(%rsp)
  763d46:	movb   $0x2,0x1fc(%rsp)
  763d4e:	movq   $0x3,(%rsp)
  763d56:	mov    %rbp,%rdi
  763d59:	lea    0x28(%rsp),%rsi
  763d5e:	mov    0x18(%rsp),%rdx
  763d63:	mov    0x8(%rsp),%rcx
  763d68:	lea    0x1f0(%rsp),%r8
  763d70:	lea    -0x6942fa(%rip),%r9        # cfa7d <GCC_except_table0+0xd675>
  763d77:	call   76ff00 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_>
  763d7c:	mov    0x60(%rsp),%rax
  763d81:	cmp    $0xfffffffffffffffe,%rax
  763d85:	je     765133 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ae3>
  763d8b:	cmp    $0x23,%eax
  763d8e:	jne    765133 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ae3>
  763d94:	mov    0x260(%rsp),%rsi
  763d9c:	mov    %rbp,%rdi
  763d9f:	call   75cb80 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_>
  763da4:	mov    0x70(%rsp),%rdx
  763da9:	cmp    0x110(%rsp),%rdx
  763db1:	jne    764edf <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x188f>
  763db7:	mov    0x108(%rsp),%rsi
  763dbf:	mov    0x68(%rsp),%r14
  763dc4:	mov    %r14,%rdi
  763dc7:	call   *0x35677b(%rip)        # aba548 <bcmp@GLIBC_2.2.5>
  763dcd:	test   %eax,%eax
  763dcf:	jne    764edf <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x188f>
  763dd5:	mov    0x78(%rsp),%eax
  763dd9:	cmp    0x118(%rsp),%eax
  763de0:	jne    764edf <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x188f>
  763de6:	movzbl 0x7c(%rsp),%eax
  763deb:	cmp    0x11c(%rsp),%al
  763df2:	jne    764edf <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x188f>
  763df8:	mov    0x80(%rsp),%eax
  763dff:	cmp    0x120(%rsp),%eax
  763e06:	jne    764edf <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x188f>
  763e0c:	movzbl 0x84(%rsp),%eax
  763e14:	cmp    0x124(%rsp),%al
  763e1b:	jne    764edf <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x188f>
  763e21:	mov    0x88(%rsp),%rax
  763e29:	cmp    0x128(%rsp),%rax
  763e31:	jne    764edf <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x188f>
  763e37:	mov    0x90(%rsp),%rax
  763e3f:	cmp    0x130(%rsp),%rax
  763e47:	jne    764edf <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x188f>
  763e4d:	mov    0x60(%rsp),%rsi
  763e52:	test   %rsi,%rsi
  763e55:	je     763e65 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x815>
  763e57:	mov    $0x1,%edx
  763e5c:	mov    %r14,%rdi
  763e5f:	call   *0x35641b(%rip)        # aba280 <_DYNAMIC+0x240>
  763e65:	mov    0x260(%rsp),%rsi
  763e6d:	test   %rsi,%rsi
  763e70:	je     7652bb <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1c6b>
  763e76:	cmpb   $0x0,0x76e(%rsi)
  763e7d:	jne    7652d5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1c85>
  763e83:	lea    0x1f0(%rsp),%rdi
  763e8b:	mov    %r13,%rdx
  763e8e:	mov    %r12,%rcx
  763e91:	call   77bbc0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_>
  763e96:	cmpq   $0xfffffffffffffffe,0x1f0(%rsp)
  763e9f:	jne    7652e1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1c91>
  763ea5:	mov    0x260(%rsp),%rsi
  763ead:	lea    0x28(%rsp),%rdi
  763eb2:	call   75cb80 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_>
  763eb7:	mov    0x38(%rsp),%r14
  763ebc:	cmp    0x2c8(%rsp),%r14
  763ec4:	jne    764f34 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x18e4>
  763eca:	mov    0x2c0(%rsp),%rsi
  763ed2:	mov    0x30(%rsp),%rdi
  763ed7:	mov    %r14,%rdx
  763eda:	call   *0x356668(%rip)        # aba548 <bcmp@GLIBC_2.2.5>
  763ee0:	test   %eax,%eax
  763ee2:	jne    764f34 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x18e4>
  763ee8:	mov    %r14,%rax
  763eeb:	shr    $0x20,%rax
  763eef:	jne    764f74 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1924>
  763ef5:	movl   $0x0,0x60(%rsp)
  763efd:	movb   $0x1,0x64(%rsp)
  763f02:	mov    %r14d,0x68(%rsp)
  763f07:	movb   $0x1,0x6c(%rsp)
  763f0c:	cmpl   $0x0,0x40(%rsp)
  763f11:	jne    764061 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xa11>
  763f17:	movzbl 0x44(%rsp),%eax
  763f1c:	cmp    %r14d,0x48(%rsp)
  763f21:	sete   %cl
  763f24:	test   %al,%al
  763f26:	je     764073 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xa23>
  763f2c:	test   %cl,%cl
  763f2e:	je     76407d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xa2d>
  763f34:	movzbl 0x4c(%rsp),%eax
  763f39:	test   %al,%al
  763f3b:	je     764087 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xa37>
  763f41:	mov    %r12,0x10(%rsp)
  763f46:	mov    0x50(%rsp),%rcx
  763f4b:	mov    0x58(%rsp),%r12
  763f50:	mov    %rcx,0x1f0(%rsp)
  763f58:	mov    %r12,0x1f8(%rsp)
  763f60:	mov    0x128(%rsp),%rdx
  763f68:	mov    0x130(%rsp),%rax
  763f70:	mov    %rdx,0x60(%rsp)
  763f75:	mov    %rax,0x68(%rsp)
  763f7a:	cmp    %rdx,%rcx
  763f7d:	jne    764f4b <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x18fb>
  763f83:	cmp    %rax,%r12
  763f86:	jne    764f4b <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x18fb>
  763f8c:	lea    0x1f0(%rsp),%rdi
  763f94:	lea    0x260(%rsp),%rsi
  763f9c:	lea    0x3368dd(%rip),%rdx        # a9a880 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xd98>
  763fa3:	mov    %r15,%rcx
  763fa6:	call   744ac0 <_RINvMst_NtCslbxve4rcJus_4gpui7runtimeINtB6_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE3setNtNtCscdodAO9FK5_5alloc6string6StringEBL_>
  763fab:	cmpl   $0xffffffff,0x1f0(%rsp)
  763fb3:	jne    764f86 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1936>
  763fb9:	mov    0x260(%rsp),%rsi
  763fc1:	mov    %rbp,%rdi
  763fc4:	call   760be0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack>
  763fc9:	mov    0x260(%rsp),%rsi
  763fd1:	mov    %rbp,%rdi
  763fd4:	call   75cb80 <_RNCNvCs9C2G9YFESsD_29canonical_text_public_control12old_p_oracle0B3_>
  763fd9:	mov    0x90(%rsp),%rax
  763fe1:	cmp    0x130(%rsp),%rax
  763fe9:	jne    76501a <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x19ca>
  763fef:	mov    0x60(%rsp),%rsi
  763ff4:	test   %rsi,%rsi
  763ff7:	je     764009 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x9b9>
  763ff9:	mov    0x68(%rsp),%rdi
  763ffe:	mov    $0x1,%edx
  764003:	call   *0x356277(%rip)        # aba280 <_DYNAMIC+0x240>
  764009:	mov    0x28(%rsp),%rsi
  76400e:	test   %rsi,%rsi
  764011:	je     764023 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x9d3>
  764013:	mov    0x30(%rsp),%rdi
  764018:	mov    $0x1,%edx
  76401d:	call   *0x35625d(%rip)        # aba280 <_DYNAMIC+0x240>
  764023:	mov    0x100(%rsp),%rsi
  76402b:	test   %rsi,%rsi
  76402e:	je     764043 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x9f3>
  764030:	mov    0x108(%rsp),%rdi
  764038:	mov    $0x1,%edx
  76403d:	call   *0x35623d(%rip)        # aba280 <_DYNAMIC+0x240>
  764043:	mov    0x260(%rsp),%r14
  76404b:	test   %r14,%r14
  76404e:	je     763b53 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x503>
  764054:	mov    %r14,%rdi
  764057:	call   748000 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui7runtime7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEEB1h_>
  76405c:	jmp    763b40 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x4f0>
  764061:	xor    %eax,%eax
  764063:	cmp    %r14d,0x48(%rsp)
  764068:	sete   %cl
  76406b:	test   %al,%al
  76406d:	jne    763f2c <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x8dc>
  764073:	xor    %ecx,%ecx
  764075:	test   %cl,%cl
  764077:	jne    763f34 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x8e4>
  76407d:	xor    %eax,%eax
  76407f:	test   %al,%al
  764081:	jne    763f41 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x8f1>
  764087:	lea    0x60(%rsp),%rsi
  76408c:	lea    0x40(%rsp),%rdi
  764091:	call   74f5c5 <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout13TextSelectionBM_ECs9C2G9YFESsD_29canonical_text_public_control>
  764096:	jmp    76541d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  76409b:	xor    %eax,%eax
  76409d:	mov    0x20(%rsp),%r8
  7640a2:	mov    0x20(%r8),%rsi
  7640a6:	mov    0x28(%r8),%rdx
  7640aa:	mov    0x38(%r8),%rcx
  7640ae:	mov    0x40(%r8),%r8
  7640b2:	test   %r9b,%r9b
  7640b5:	je     7640d3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xa83>
  7640b7:	mov    $0x7361656d,%r9d
  7640bd:	xor    (%rdi),%r9d
  7640c0:	mov    $0x65727573,%r10d
  7640c6:	xor    0x3(%rdi),%r10d
  7640ca:	or     %r9d,%r10d
  7640cd:	sete   %dil
  7640d1:	jmp    7640d5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xa85>
  7640d3:	xor    %edi,%edi
  7640d5:	movzbl %dil,%edi
  7640d9:	mov    %edi,(%rsp)
  7640dc:	lea    0x150(%rsp),%rdi
  7640e4:	mov    %rax,%r15
  7640e7:	mov    %rax,%r9
  7640ea:	call   760d50 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run>
  7640ef:	mov    0x160(%rsp),%rax
  7640f7:	mov    %rax,0x18(%rsp)
  7640fc:	mov    0x150(%rsp),%rax
  764104:	mov    %rax,0x8(%rsp)
  764109:	mov    0x158(%rsp),%rax
  764111:	mov    %rax,0xf8(%rsp)
  764119:	movups 0x178(%rsp),%xmm0
  764121:	movaps %xmm0,0x200(%rsp)
  764129:	movups 0x168(%rsp),%xmm0
  764131:	movaps %xmm0,0x1f0(%rsp)
  764139:	movq   $0x0,0x100(%rsp)
  764145:	movq   $0x0,0x110(%rsp)
  764151:	call   *0x356131(%rip)        # aba288 <_DYNAMIC+0x248>
  764157:	mov    $0x4,%r13d
  76415d:	mov    $0x1,%ebp
  764162:	mov    $0x4,%edi
  764167:	mov    $0x1,%esi
  76416c:	call   *0x35611e(%rip)        # aba290 <_DYNAMIC+0x250>
  764172:	test   %rax,%rax
  764175:	je     76515b <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1b0b>
  76417b:	movl   $0x65736163,(%rax)
  764181:	movq   $0x4,0x28(%rsp)
  76418a:	mov    %rax,0x30(%rsp)
  76418f:	movq   $0x4,0x38(%rsp)
  764198:	mov    0x20(%rsp),%rcx
  76419d:	mov    0x28(%rcx),%r12
  7641a1:	test   %r12,%r12
  7641a4:	je     7641e1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xb91>
  7641a6:	mov    %rax,%r13
  7641a9:	mov    0x20(%rsp),%rax
  7641ae:	mov    0x20(%rax),%r14
  7641b2:	call   *0x3560d0(%rip)        # aba288 <_DYNAMIC+0x248>
  7641b8:	mov    $0x1,%esi
  7641bd:	mov    %r12,%rdi
  7641c0:	call   *0x3560ca(%rip)        # aba290 <_DYNAMIC+0x250>
  7641c6:	test   %rax,%rax
  7641c9:	je     7653ff <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1daf>
  7641cf:	mov    %rax,%rbp
  7641d2:	mov    %rax,%rdi
  7641d5:	mov    %r14,%rsi
  7641d8:	mov    %r12,%rdx
  7641db:	call   *0x3560bf(%rip)        # aba2a0 <memcpy@GLIBC_2.14>
  7641e1:	movb   $0x3,0x150(%rsp)
  7641e9:	mov    %r12,0x158(%rsp)
  7641f1:	mov    %rbp,0x160(%rsp)
  7641f9:	mov    %r12,0x168(%rsp)
  764201:	lea    0x60(%rsp),%rdi
  764206:	lea    0x100(%rsp),%rsi
  76420e:	lea    0x28(%rsp),%rdx
  764213:	lea    0x150(%rsp),%rcx
  76421b:	call   776930 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  764220:	cmpb   $0xff,0x60(%rsp)
  764225:	je     764231 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xbe1>
  764227:	lea    0x60(%rsp),%rdi
  76422c:	call   74cba0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  764231:	call   *0x356051(%rip)        # aba288 <_DYNAMIC+0x248>
  764237:	mov    $0x9,%r13d
  76423d:	mov    $0x1,%r12d
  764243:	mov    $0x9,%edi
  764248:	mov    $0x1,%esi
  76424d:	call   *0x35603d(%rip)        # aba290 <_DYNAMIC+0x250>
  764253:	test   %rax,%rax
  764256:	je     76515b <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1b0b>
  76425c:	movabs $0x6f6974617265706f,%rcx
  764266:	mov    %rcx,(%rax)
  764269:	movb   $0x6e,0x8(%rax)
  76426d:	movq   $0x9,0x28(%rsp)
  764276:	mov    %rax,0x30(%rsp)
  76427b:	movq   $0x9,0x38(%rsp)
  764284:	mov    0x20(%rsp),%rcx
  764289:	mov    0x40(%rcx),%r13
  76428d:	test   %r13,%r13
  764290:	je     7642cd <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xc7d>
  764292:	mov    %rax,%rbp
  764295:	mov    0x20(%rsp),%rax
  76429a:	mov    0x38(%rax),%r14
  76429e:	call   *0x355fe4(%rip)        # aba288 <_DYNAMIC+0x248>
  7642a4:	mov    $0x1,%esi
  7642a9:	mov    %r13,%rdi
  7642ac:	call   *0x355fde(%rip)        # aba290 <_DYNAMIC+0x250>
  7642b2:	test   %rax,%rax
  7642b5:	je     76540f <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dbf>
  7642bb:	mov    %rax,%r12
  7642be:	mov    %rax,%rdi
  7642c1:	mov    %r14,%rsi
  7642c4:	mov    %r13,%rdx
  7642c7:	call   *0x355fd3(%rip)        # aba2a0 <memcpy@GLIBC_2.14>
  7642cd:	movb   $0x3,0x150(%rsp)
  7642d5:	mov    %r13,0x158(%rsp)
  7642dd:	mov    %r12,0x160(%rsp)
  7642e5:	mov    %r13,0x168(%rsp)
  7642ed:	lea    0x60(%rsp),%rdi
  7642f2:	lea    0x100(%rsp),%rsi
  7642fa:	lea    0x28(%rsp),%rdx
  7642ff:	lea    0x150(%rsp),%rcx
  764307:	call   776930 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  76430c:	cmpb   $0xff,0x60(%rsp)
  764311:	je     76431d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xccd>
  764313:	lea    0x60(%rsp),%rdi
  764318:	call   74cba0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  76431d:	call   *0x355f65(%rip)        # aba288 <_DYNAMIC+0x248>
  764323:	mov    $0x5,%r13d
  764329:	mov    $0x5,%edi
  76432e:	mov    $0x1,%esi
  764333:	call   *0x355f57(%rip)        # aba290 <_DYNAMIC+0x250>
  764339:	test   %rax,%rax
  76433c:	je     76515b <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1b0b>
  764342:	movb   $0x74,0x4(%rax)
  764346:	movl   $0x6e756f63,(%rax)
  76434c:	movq   $0x5,0x28(%rsp)
  764355:	mov    %rax,0x30(%rsp)
  76435a:	movq   $0x5,0x38(%rsp)
  764363:	movb   $0x2,0x150(%rsp)
  76436b:	movq   $0x0,0x158(%rsp)
  764377:	mov    %r15,0x160(%rsp)
  76437f:	lea    0x60(%rsp),%rdi
  764384:	lea    0x100(%rsp),%rsi
  76438c:	lea    0x28(%rsp),%rdx
  764391:	lea    0x150(%rsp),%rcx
  764399:	call   776930 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  76439e:	cmpb   $0xff,0x60(%rsp)
  7643a3:	je     7643af <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xd5f>
  7643a5:	lea    0x60(%rsp),%rdi
  7643aa:	call   74cba0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  7643af:	call   *0x355ed3(%rip)        # aba288 <_DYNAMIC+0x248>
  7643b5:	mov    $0x8,%r13d
  7643bb:	mov    $0x8,%edi
  7643c0:	mov    $0x1,%esi
  7643c5:	call   *0x355ec5(%rip)        # aba290 <_DYNAMIC+0x250>
  7643cb:	test   %rax,%rax
  7643ce:	je     76515b <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1b0b>
  7643d4:	movabs $0x6d75736b63656863,%rcx
  7643de:	mov    %rcx,(%rax)
  7643e1:	movq   $0x8,0x28(%rsp)
  7643ea:	mov    %rax,0x30(%rsp)
  7643ef:	movq   $0x8,0x38(%rsp)
  7643f8:	movb   $0x2,0x150(%rsp)
  764400:	movq   $0x0,0x158(%rsp)
  76440c:	mov    0x18(%rsp),%rax
  764411:	mov    %rax,0x160(%rsp)
  764419:	lea    0x60(%rsp),%rdi
  76441e:	lea    0x100(%rsp),%rsi
  764426:	lea    0x28(%rsp),%rdx
  76442b:	lea    0x150(%rsp),%rcx
  764433:	call   776930 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  764438:	cmpb   $0xff,0x60(%rsp)
  76443d:	je     764449 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xdf9>
  76443f:	lea    0x60(%rsp),%rdi
  764444:	call   74cba0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  764449:	call   *0x355e39(%rip)        # aba288 <_DYNAMIC+0x248>
  76444f:	mov    $0xa,%r13d
  764455:	mov    $0xa,%edi
  76445a:	mov    $0x1,%esi
  76445f:	call   *0x355e2b(%rip)        # aba290 <_DYNAMIC+0x250>
  764465:	test   %rax,%rax
  764468:	je     76515b <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1b0b>
  76446e:	mov    %rax,%r12
  764471:	movabs $0x5f64657370616c65,%rax
  76447b:	mov    %rax,(%r12)
  76447f:	movw   $0x736e,0x8(%r12)
  764487:	movq   $0xa,0x28(%rsp)
  764490:	mov    %r12,0x30(%rsp)
  764495:	movq   $0xa,0x38(%rsp)
  76449e:	lea    0x150(%rsp),%rdi
  7644a6:	mov    0x8(%rsp),%rsi
  7644ab:	mov    0xf8(%rsp),%rdx
  7644b3:	call   *0x3560b7(%rip)        # aba570 <_DYNAMIC+0x530>
  7644b9:	cmpb   $0xff,0x150(%rsp)
  7644c1:	je     76506a <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1a1a>
  7644c7:	movups 0x150(%rsp),%xmm0
  7644cf:	movups 0x160(%rsp),%xmm1
  7644d7:	movaps %xmm1,0x70(%rsp)
  7644dc:	movaps %xmm0,0x60(%rsp)
  7644e1:	lea    0x150(%rsp),%rdi
  7644e9:	lea    0x100(%rsp),%rsi
  7644f1:	lea    0x28(%rsp),%rdx
  7644f6:	lea    0x60(%rsp),%rcx
  7644fb:	call   776930 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  764500:	cmpb   $0xff,0x150(%rsp)
  764508:	je     764517 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xec7>
  76450a:	lea    0x150(%rsp),%rdi
  764512:	call   74cba0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  764517:	call   *0x355d6b(%rip)        # aba288 <_DYNAMIC+0x248>
  76451d:	mov    $0x8,%r13d
  764523:	mov    $0x8,%edi
  764528:	mov    $0x1,%esi
  76452d:	call   *0x355d5d(%rip)        # aba290 <_DYNAMIC+0x250>
  764533:	test   %rax,%rax
  764536:	je     76515b <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1b0b>
  76453c:	mov    %rax,%r14
  76453f:	movabs $0x737265746e756f63,%rax
  764549:	mov    %rax,(%r14)
  76454c:	movq   $0x8,0x28(%rsp)
  764555:	mov    %r14,0x30(%rsp)
  76455a:	movq   $0x8,0x38(%rsp)
  764563:	lea    0x150(%rsp),%rdi
  76456b:	lea    0x1f0(%rsp),%rsi
  764573:	call   75b470 <_RINvXNtNtCscl5MXVnO7Zx_10serde_json5value3serNtB5_5ValueNtNtCs8znKHa7cbRS_10serde_core3ser9Serialize9serializeNtB3_10SerializerECs9C2G9YFESsD_29canonical_text_public_control>
  764578:	cmpb   $0xff,0x150(%rsp)
  764580:	je     7650a1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1a51>
  764586:	movups 0x150(%rsp),%xmm0
  76458e:	movups 0x160(%rsp),%xmm1
  764596:	movaps %xmm1,0x70(%rsp)
  76459b:	movaps %xmm0,0x60(%rsp)
  7645a0:	lea    0x150(%rsp),%r14
  7645a8:	lea    0x100(%rsp),%rsi
  7645b0:	lea    0x28(%rsp),%rdx
  7645b5:	lea    0x60(%rsp),%rcx
  7645ba:	mov    %r14,%rdi
  7645bd:	call   776930 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  7645c2:	cmpb   $0xff,0x150(%rsp)
  7645ca:	je     7645d9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xf89>
  7645cc:	lea    0x150(%rsp),%rdi
  7645d4:	call   74cba0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  7645d9:	movups 0x100(%rsp),%xmm0
  7645e1:	movups %xmm0,0x158(%rsp)
  7645e9:	mov    0x110(%rsp),%rax
  7645f1:	mov    %rax,0x168(%rsp)
  7645f9:	movb   $0x5,0x150(%rsp)
  764601:	mov    %r14,0x60(%rsp)
  764606:	mov    0x355f6b(%rip),%rax        # aba578 <_DYNAMIC+0x538>
  76460d:	mov    %rax,0x68(%rsp)
  764612:	lea    -0x69f8b7(%rip),%rdi        # c4d62 <GCC_except_table0+0x295a>
  764619:	lea    0x60(%rsp),%rsi
  76461e:	call   *0x355f5c(%rip)        # aba580 <_DYNAMIC+0x540>
  764624:	lea    0x150(%rsp),%rdi
  76462c:	call   74cba0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  764631:	lea    0x1f0(%rsp),%rdi
  764639:	call   74cba0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  76463e:	mov    0x20(%rsp),%rax
  764643:	lea    0x8(%rax),%r14
  764647:	mov    0x355c32(%rip),%r15        # aba280 <_DYNAMIC+0x240>
  76464e:	jmp    764659 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1009>
  764650:	add    $0x18,%r14
  764654:	dec    %rbx
  764657:	je     76466f <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x101f>
  764659:	mov    -0x8(%r14),%rsi
  76465d:	test   %rsi,%rsi
  764660:	je     764650 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1000>
  764662:	mov    (%r14),%rdi
  764665:	mov    $0x1,%edx
  76466a:	call   *%r15
  76466d:	jmp    764650 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1000>
  76466f:	mov    0x288(%rsp),%rax
  764677:	test   %rax,%rax
  76467a:	je     764694 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1044>
  76467c:	shl    $0x3,%rax
  764680:	lea    (%rax,%rax,2),%rsi
  764684:	mov    $0x8,%edx
  764689:	mov    0x20(%rsp),%rdi
  76468e:	call   *0x355bec(%rip)        # aba280 <_DYNAMIC+0x240>
  764694:	add    $0x2d8,%rsp
  76469b:	pop    %rbx
  76469c:	pop    %r12
  76469e:	pop    %r13
  7646a0:	pop    %r14
  7646a2:	pop    %r15
  7646a4:	pop    %rbp
  7646a5:	ret
  7646a6:	mov    %r14,0x60(%rsp)
  7646ab:	mov    %rbp,0x150(%rsp)
  7646b3:	mov    0x355ece(%rip),%rax        # aba588 <_DYNAMIC+0x548>
  7646ba:	mov    %rax,0x158(%rsp)
  7646c2:	lea    -0x69a8e6(%rip),%rdi        # c9de3 <GCC_except_table0+0x79db>
  7646c9:	lea    0x150(%rsp),%rsi
  7646d1:	call   *0x355ea9(%rip)        # aba580 <_DYNAMIC+0x540>
  7646d7:	movq   $0x0,0x60(%rsp)
  7646e0:	movq   $0x8,0x68(%rsp)
  7646e9:	movups 0x336068(%rip),%xmm0        # a9a758 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xc70>
  7646f0:	movups %xmm0,0x70(%rsp)
  7646f5:	movups 0x33606c(%rip),%xmm0        # a9a768 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xc80>
  7646fc:	movups %xmm0,0x80(%rsp)
  764704:	movups 0x33606d(%rip),%xmm0        # a9a778 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xc90>
  76470b:	movups %xmm0,0x90(%rsp)
  764713:	movups 0x33606e(%rip),%xmm0        # a9a788 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xca0>
  76471a:	movups %xmm0,0xa0(%rsp)
  764722:	movups 0x33606f(%rip),%xmm0        # a9a798 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xcb0>
  764729:	movups %xmm0,0xb0(%rsp)
  764731:	movups 0x336070(%rip),%xmm0        # a9a7a8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xcc0>
  764738:	movups %xmm0,0xc0(%rsp)
  764740:	movups 0x336071(%rip),%xmm0        # a9a7b8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xcd0>
  764747:	movups %xmm0,0xd0(%rsp)
  76474f:	movups 0x336072(%rip),%xmm0        # a9a7c8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xce0>
  764756:	movups %xmm0,0xe0(%rsp)
  76475e:	xor    %eax,%eax
  764760:	lea    0x1f0(%rsp),%r15
  764768:	jmp    76477f <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x112f>
  76476a:	nopw   0x0(%rax,%rax,1)
  764770:	mov    0x10(%rsp),%rax
  764775:	cmp    $0x8,%rax
  764779:	je     76463e <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0xfee>
  76477f:	lea    0x1(%rax),%rcx
  764783:	mov    %rcx,0x10(%rsp)
  764788:	shl    $0x4,%rax
  76478c:	lea    0x70(%rsp),%rcx
  764791:	mov    (%rcx,%rax,1),%rdx
  764795:	mov    %rdx,0x18(%rsp)
  76479a:	mov    0x8(%rcx,%rax,1),%r12
  76479f:	movq   $0x0,0x150(%rsp)
  7647ab:	movq   $0x8,0x158(%rsp)
  7647b7:	lea    -0x694c00(%rip),%rax        # cfbbe <GCC_except_table0+0xd7b6>
  7647be:	mov    %rax,0x160(%rsp)
  7647c6:	movq   $0x3,0x168(%rsp)
  7647d2:	lea    -0x694c18(%rip),%rax        # cfbc1 <GCC_except_table0+0xd7b9>
  7647d9:	mov    %rax,0x170(%rsp)
  7647e1:	movq   $0x9,0x178(%rsp)
  7647ed:	lea    -0x694c2a(%rip),%rax        # cfbca <GCC_except_table0+0xd7c2>
  7647f4:	mov    %rax,0x180(%rsp)
  7647fc:	movq   $0x6,0x188(%rsp)
  764808:	lea    -0x694c3f(%rip),%rax        # cfbd0 <GCC_except_table0+0xd7c8>
  76480f:	mov    %rax,0x190(%rsp)
  764817:	movq   $0x9,0x198(%rsp)
  764823:	lea    -0x694c51(%rip),%rax        # cfbd9 <GCC_except_table0+0xd7d1>
  76482a:	mov    %rax,0x1a0(%rsp)
  764832:	movq   $0x7,0x1a8(%rsp)
  76483e:	lea    -0x694cb2(%rip),%rax        # cfb93 <GCC_except_table0+0xd78b>
  764845:	mov    %rax,0x1b0(%rsp)
  76484d:	movq   $0x7,0x1b8(%rsp)
  764859:	lea    -0x694cd2(%rip),%rax        # cfb8e <GCC_except_table0+0xd786>
  764860:	mov    %rax,0x1c0(%rsp)
  764868:	movq   $0x5,0x1c8(%rsp)
  764874:	lea    -0x6a23c7(%rip),%rax        # c24b4 <GCC_except_table0+0xac>
  76487b:	mov    %rax,0x1d0(%rsp)
  764883:	movq   $0x4,0x1d8(%rsp)
  76488f:	mov    $0x1,%eax
  764894:	mov    %rax,0x8(%rsp)
  764899:	lea    0x168(%rsp),%r13
  7648a1:	mov    %r12,0xf8(%rsp)
  7648a9:	jmp    7648cb <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x127b>
  7648ab:	nopl   0x0(%rax,%rax,1)
  7648b0:	add    $0x10,%r13
  7648b4:	mov    0x8(%rsp),%rax
  7648b9:	inc    %rax
  7648bc:	mov    %rax,0x8(%rsp)
  7648c1:	cmp    $0x9,%rax
  7648c5:	je     764770 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1120>
  7648cb:	mov    -0x8(%r13),%r8
  7648cf:	mov    0x0(%r13),%r14
  7648d3:	cmp    $0x4,%r12
  7648d7:	je     764980 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1330>
  7648dd:	cmp    $0x5,%r12
  7648e1:	je     764930 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x12e0>
  7648e3:	cmp    $0xd,%r12
  7648e7:	jne    7649a9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1359>
  7648ed:	mov    0x18(%rsp),%rdx
  7648f2:	mov    (%rdx),%rcx
  7648f5:	movabs $0x6172672d676e6f6c,%rax
  7648ff:	xor    %rax,%rcx
  764902:	mov    0x5(%rdx),%rdx
  764906:	movabs $0x656d656870617267,%rax
  764910:	xor    %rax,%rdx
  764913:	xor    %eax,%eax
  764915:	or     %rcx,%rdx
  764918:	setne  %cl
  76491b:	cmp    $0x4,%r14
  76491f:	je     764996 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1346>
  764921:	jmp    7649a9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1359>
  764926:	cs nopw 0x0(%rax,%rax,1)
  764930:	mov    0x18(%rsp),%rdx
  764935:	mov    (%rdx),%ecx
  764937:	mov    $0x74706d65,%eax
  76493c:	xor    %eax,%ecx
  76493e:	movzbl 0x4(%rdx),%edx
  764942:	xor    $0x79,%edx
  764945:	xor    %eax,%eax
  764947:	or     %ecx,%edx
  764949:	setne  %al
  76494c:	cmp    $0x5,%r14
  764950:	jne    764e7f <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x182f>
  764956:	test   %eax,%eax
  764958:	jne    764e7f <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x182f>
  76495e:	mov    (%r8),%eax
  764961:	mov    $0x6f727261,%ecx
  764966:	xor    %ecx,%eax
  764968:	movzbl 0x4(%r8),%ecx
  76496d:	xor    $0x77,%ecx
  764970:	or     %eax,%ecx
  764972:	jne    7649a9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1359>
  764974:	jmp    7648b0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1260>
  764979:	nopl   0x0(%rax)
  764980:	xor    %eax,%eax
  764982:	mov    0x18(%rsp),%rcx
  764987:	cmpl   $0x796e6974,(%rcx)
  76498d:	setne  %cl
  764990:	cmp    $0x4,%r14
  764994:	jne    7649a9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1359>
  764996:	mov    %cl,%al
  764998:	test   %eax,%eax
  76499a:	jne    7649a9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1359>
  76499c:	cmpl   $0x67617264,(%r8)
  7649a3:	je     7648b0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1260>
  7649a9:	movl   $0x0,(%rsp)
  7649b0:	mov    $0x4,%r9d
  7649b6:	mov    %r15,%rdi
  7649b9:	mov    0x18(%rsp),%rsi
  7649be:	mov    %r12,%rdx
  7649c1:	mov    %r8,%rbp
  7649c4:	mov    %r8,%rcx
  7649c7:	mov    %r14,%r8
  7649ca:	call   760d50 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3run>
  7649cf:	mov    %r13,0x1e8(%rsp)
  7649d7:	mov    0x200(%rsp),%rax
  7649df:	mov    %rax,0x290(%rsp)
  7649e7:	lea    0x208(%rsp),%rax
  7649ef:	movups (%rax),%xmm0
  7649f2:	movups 0x10(%rax),%xmm1
  7649f6:	movaps %xmm1,0x270(%rsp)
  7649fe:	movaps %xmm0,0x260(%rsp)
  764a06:	movq   $0x0,0x298(%rsp)
  764a12:	movq   $0x0,0x2a8(%rsp)
  764a1e:	call   *0x355864(%rip)        # aba288 <_DYNAMIC+0x248>
  764a24:	mov    $0x4,%r15d
  764a2a:	mov    $0x4,%edi
  764a2f:	mov    $0x1,%esi
  764a34:	call   *0x355856(%rip)        # aba290 <_DYNAMIC+0x250>
  764a3a:	test   %rax,%rax
  764a3d:	je     765040 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x19f0>
  764a43:	mov    %rax,%r13
  764a46:	movl   $0x65736163,(%rax)
  764a4c:	movq   $0x4,0x138(%rsp)
  764a58:	mov    %rax,0x140(%rsp)
  764a60:	movq   $0x4,0x148(%rsp)
  764a6c:	mov    0xf8(%rsp),%r12
  764a74:	test   %r12,%r12
  764a77:	je     764ab0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1460>
  764a79:	call   *0x355809(%rip)        # aba288 <_DYNAMIC+0x248>
  764a7f:	mov    $0x1,%esi
  764a84:	mov    %r12,%rdi
  764a87:	call   *0x355803(%rip)        # aba290 <_DYNAMIC+0x250>
  764a8d:	test   %rax,%rax
  764a90:	je     765102 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ab2>
  764a96:	mov    %rax,%r15
  764a99:	mov    %rax,%rdi
  764a9c:	mov    0x18(%rsp),%rsi
  764aa1:	mov    %r12,%rdx
  764aa4:	call   *0x3557f6(%rip)        # aba2a0 <memcpy@GLIBC_2.14>
  764aaa:	jmp    764ab6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1466>
  764aac:	nopl   0x0(%rax)
  764ab0:	mov    $0x1,%r15d
  764ab6:	movb   $0x3,0x28(%rsp)
  764abb:	mov    %r12,0x30(%rsp)
  764ac0:	mov    %r15,0x38(%rsp)
  764ac5:	mov    %r12,0x40(%rsp)
  764aca:	lea    0x100(%rsp),%rdi
  764ad2:	lea    0x298(%rsp),%rsi
  764ada:	lea    0x138(%rsp),%rdx
  764ae2:	lea    0x28(%rsp),%rcx
  764ae7:	call   776930 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  764aec:	cmpb   $0xff,0x100(%rsp)
  764af4:	je     764b03 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x14b3>
  764af6:	lea    0x100(%rsp),%rdi
  764afe:	call   74cba0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  764b03:	call   *0x35577f(%rip)        # aba288 <_DYNAMIC+0x248>
  764b09:	mov    $0x9,%r15d
  764b0f:	mov    $0x9,%edi
  764b14:	mov    $0x1,%esi
  764b19:	call   *0x355771(%rip)        # aba290 <_DYNAMIC+0x250>
  764b1f:	test   %rax,%rax
  764b22:	je     765040 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x19f0>
  764b28:	movabs $0x6f6974617265706f,%rcx
  764b32:	mov    %rcx,(%rax)
  764b35:	movb   $0x6e,0x8(%rax)
  764b39:	movq   $0x9,0x138(%rsp)
  764b45:	mov    %rax,0x140(%rsp)
  764b4d:	movq   $0x9,0x148(%rsp)
  764b59:	test   %r14,%r14
  764b5c:	je     764ba0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1550>
  764b5e:	mov    %rax,%r13
  764b61:	call   *0x355721(%rip)        # aba288 <_DYNAMIC+0x248>
  764b67:	mov    $0x1,%esi
  764b6c:	mov    %r14,%rdi
  764b6f:	call   *0x35571b(%rip)        # aba290 <_DYNAMIC+0x250>
  764b75:	test   %rax,%rax
  764b78:	je     7650d8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1a88>
  764b7e:	mov    %rax,%r15
  764b81:	mov    %rax,%rdi
  764b84:	mov    %rbp,%rsi
  764b87:	mov    %r14,%rdx
  764b8a:	call   *0x355710(%rip)        # aba2a0 <memcpy@GLIBC_2.14>
  764b90:	jmp    764ba6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1556>
  764b92:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  764ba0:	mov    $0x1,%r15d
  764ba6:	movb   $0x3,0x28(%rsp)
  764bab:	mov    %r14,0x30(%rsp)
  764bb0:	mov    %r15,0x38(%rsp)
  764bb5:	mov    %r14,0x40(%rsp)
  764bba:	lea    0x100(%rsp),%rdi
  764bc2:	lea    0x298(%rsp),%rsi
  764bca:	lea    0x138(%rsp),%rdx
  764bd2:	lea    0x28(%rsp),%rcx
  764bd7:	call   776930 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  764bdc:	cmpb   $0xff,0x100(%rsp)
  764be4:	je     764bf3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x15a3>
  764be6:	lea    0x100(%rsp),%rdi
  764bee:	call   74cba0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  764bf3:	call   *0x35568f(%rip)        # aba288 <_DYNAMIC+0x248>
  764bf9:	mov    $0x5,%r15d
  764bff:	mov    $0x5,%edi
  764c04:	mov    $0x1,%esi
  764c09:	call   *0x355681(%rip)        # aba290 <_DYNAMIC+0x250>
  764c0f:	test   %rax,%rax
  764c12:	je     765040 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x19f0>
  764c18:	movb   $0x74,0x4(%rax)
  764c1c:	movl   $0x6e756f63,(%rax)
  764c22:	movq   $0x5,0x138(%rsp)
  764c2e:	mov    %rax,0x140(%rsp)
  764c36:	movq   $0x5,0x148(%rsp)
  764c42:	movb   $0x2,0x28(%rsp)
  764c47:	movq   $0x0,0x30(%rsp)
  764c50:	movq   $0x4,0x38(%rsp)
  764c59:	lea    0x100(%rsp),%rdi
  764c61:	lea    0x298(%rsp),%rsi
  764c69:	lea    0x138(%rsp),%rdx
  764c71:	lea    0x28(%rsp),%rcx
  764c76:	call   776930 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  764c7b:	cmpb   $0xff,0x100(%rsp)
  764c83:	je     764c92 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1642>
  764c85:	lea    0x100(%rsp),%rdi
  764c8d:	call   74cba0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  764c92:	call   *0x3555f0(%rip)        # aba288 <_DYNAMIC+0x248>
  764c98:	mov    $0x8,%r15d
  764c9e:	mov    $0x8,%edi
  764ca3:	mov    $0x1,%esi
  764ca8:	call   *0x3555e2(%rip)        # aba290 <_DYNAMIC+0x250>
  764cae:	test   %rax,%rax
  764cb1:	je     765040 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x19f0>
  764cb7:	movabs $0x6d75736b63656863,%rcx
  764cc1:	mov    %rcx,(%rax)
  764cc4:	movq   $0x8,0x138(%rsp)
  764cd0:	mov    %rax,0x140(%rsp)
  764cd8:	movq   $0x8,0x148(%rsp)
  764ce4:	movb   $0x2,0x28(%rsp)
  764ce9:	movq   $0x0,0x30(%rsp)
  764cf2:	mov    0x290(%rsp),%rax
  764cfa:	mov    %rax,0x38(%rsp)
  764cff:	lea    0x100(%rsp),%rdi
  764d07:	lea    0x298(%rsp),%rsi
  764d0f:	lea    0x138(%rsp),%rdx
  764d17:	lea    0x28(%rsp),%rcx
  764d1c:	call   776930 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  764d21:	cmpb   $0xff,0x100(%rsp)
  764d29:	je     764d38 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x16e8>
  764d2b:	lea    0x100(%rsp),%rdi
  764d33:	call   74cba0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  764d38:	call   *0x35554a(%rip)        # aba288 <_DYNAMIC+0x248>
  764d3e:	mov    $0x8,%r15d
  764d44:	mov    $0x8,%edi
  764d49:	mov    $0x1,%esi
  764d4e:	call   *0x35553c(%rip)        # aba290 <_DYNAMIC+0x250>
  764d54:	test   %rax,%rax
  764d57:	je     765040 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x19f0>
  764d5d:	mov    %rax,%r14
  764d60:	movabs $0x737265746e756f63,%rax
  764d6a:	mov    %rax,(%r14)
  764d6d:	movq   $0x8,0x138(%rsp)
  764d79:	mov    %r14,0x140(%rsp)
  764d81:	movq   $0x8,0x148(%rsp)
  764d8d:	lea    0x28(%rsp),%rdi
  764d92:	lea    0x260(%rsp),%rsi
  764d9a:	call   75b470 <_RINvXNtNtCscl5MXVnO7Zx_10serde_json5value3serNtB5_5ValueNtNtCs8znKHa7cbRS_10serde_core3ser9Serialize9serializeNtB3_10SerializerECs9C2G9YFESsD_29canonical_text_public_control>
  764d9f:	cmpb   $0xff,0x28(%rsp)
  764da4:	je     764e8e <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x183e>
  764daa:	movups 0x28(%rsp),%xmm0
  764daf:	movups 0x38(%rsp),%xmm1
  764db4:	movaps %xmm1,0x110(%rsp)
  764dbc:	movaps %xmm0,0x100(%rsp)
  764dc4:	lea    0x28(%rsp),%rdi
  764dc9:	lea    0x298(%rsp),%rsi
  764dd1:	lea    0x138(%rsp),%rdx
  764dd9:	lea    0x100(%rsp),%rcx
  764de1:	call   776930 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  764de6:	cmpb   $0xff,0x28(%rsp)
  764deb:	je     764df7 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x17a7>
  764ded:	lea    0x28(%rsp),%rdi
  764df2:	call   74cba0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  764df7:	mov    0x2a8(%rsp),%rax
  764dff:	lea    0x2c0(%rsp),%rcx
  764e07:	mov    %rax,0x10(%rcx)
  764e0b:	movups 0x298(%rsp),%xmm0
  764e13:	movups %xmm0,(%rcx)
  764e16:	movb   $0x5,0x2b8(%rsp)
  764e1e:	lea    0x2b8(%rsp),%r14
  764e26:	mov    %r14,0x1f0(%rsp)
  764e2e:	mov    0x355743(%rip),%rax        # aba578 <_DYNAMIC+0x538>
  764e35:	mov    %rax,0x1f8(%rsp)
  764e3d:	lea    -0x6a00e2(%rip),%rdi        # c4d62 <GCC_except_table0+0x295a>
  764e44:	lea    0x1f0(%rsp),%r15
  764e4c:	mov    %r15,%rsi
  764e4f:	call   *0x35572b(%rip)        # aba580 <_DYNAMIC+0x540>
  764e55:	mov    %r14,%rdi
  764e58:	call   74cba0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  764e5d:	mov    0xf8(%rsp),%r12
  764e65:	mov    0x1e8(%rsp),%r13
  764e6d:	lea    0x260(%rsp),%rdi
  764e75:	call   74cba0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  764e7a:	jmp    7648b0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1260>
  764e7f:	cmp    $0x4,%r14
  764e83:	je     764998 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1348>
  764e89:	jmp    7649a9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1359>
  764e8e:	mov    0x10(%rsp),%rax
  764e93:	mov    %rax,0x60(%rsp)
  764e98:	mov    0x8(%rsp),%rax
  764e9d:	mov    %rax,0x150(%rsp)
  764ea5:	mov    0x30(%rsp),%rax
  764eaa:	mov    %rax,0x100(%rsp)
  764eb2:	lea    -0x69520f(%rip),%rdi        # cfcaa <GCC_except_table0+0xd8a2>
  764eb9:	lea    0x335e90(%rip),%rcx        # a9ad50 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1268>
  764ec0:	lea    0x335da9(%rip),%r8        # a9ac70 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1188>
  764ec7:	lea    0x100(%rsp),%rdx
  764ecf:	mov    $0x2b,%esi
  764ed4:	call   *0x355476(%rip)        # aba350 <_DYNAMIC+0x310>
  764eda:	jmp    76541d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  764edf:	lea    0x60(%rsp),%rdi
  764ee4:	lea    0x100(%rsp),%rsi
  764eec:	call   74f676 <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedTNtNtCscdodAO9FK5_5alloc6string6StringNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout13TextSelectionPNtB1q_12TextGeometryyEBM_ECs9C2G9YFESsD_29canonical_text_public_control>
  764ef1:	jmp    76541d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  764ef6:	add    $0xd0,%dl
  764ef9:	xor    %eax,%eax
  764efb:	cmp    $0xa,%dl
  764efe:	adc    $0x1,%al
  764f00:	mov    %al,0x150(%rsp)
  764f07:	lea    -0x695264(%rip),%rdi        # cfcaa <GCC_except_table0+0xd8a2>
  764f0e:	lea    0x335edb(%rip),%rcx        # a9adf0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1308>
  764f15:	lea    0x335d24(%rip),%r8        # a9ac40 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1158>
  764f1c:	lea    0x150(%rsp),%rdx
  764f24:	mov    $0x2b,%esi
  764f29:	call   *0x355421(%rip)        # aba350 <_DYNAMIC+0x310>
  764f2f:	jmp    76541d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  764f34:	lea    0x28(%rsp),%rdi
  764f39:	lea    0x2b8(%rsp),%rsi
  764f41:	call   74f55b <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedNtNtCscdodAO9FK5_5alloc6string6StringBM_ECs9C2G9YFESsD_29canonical_text_public_control>
  764f46:	jmp    76541d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  764f4b:	lea    0x1f0(%rsp),%rdi
  764f53:	lea    0x60(%rsp),%rsi
  764f58:	call   74f6ae <_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedTPNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryyEBM_ECs9C2G9YFESsD_29canonical_text_public_control>
  764f5d:	jmp    76541d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  764f62:	lea    0x33599f(%rip),%rdi        # a9a908 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xe20>
  764f69:	call   *0x3553d1(%rip)        # aba340 <_DYNAMIC+0x300>
  764f6f:	jmp    76541d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  764f74:	lea    0x33595d(%rip),%rdi        # a9a8d8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xdf0>
  764f7b:	call   *0x3553bf(%rip)        # aba340 <_DYNAMIC+0x300>
  764f81:	jmp    76541d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  764f86:	mov    0x250(%rsp),%rax
  764f8e:	mov    %rax,0xc0(%rsp)
  764f96:	movups 0x240(%rsp),%xmm0
  764f9e:	movaps %xmm0,0xb0(%rsp)
  764fa6:	movups 0x230(%rsp),%xmm0
  764fae:	movaps %xmm0,0xa0(%rsp)
  764fb6:	movups 0x1f0(%rsp),%xmm0
  764fbe:	movups 0x200(%rsp),%xmm1
  764fc6:	movups 0x210(%rsp),%xmm2
  764fce:	movups 0x220(%rsp),%xmm3
  764fd6:	movaps %xmm3,0x90(%rsp)
  764fde:	movaps %xmm2,0x80(%rsp)
  764fe6:	movaps %xmm1,0x70(%rsp)
  764feb:	movaps %xmm0,0x60(%rsp)
  764ff0:	lea    -0x69534d(%rip),%rdi        # cfcaa <GCC_except_table0+0xd8a2>
  764ff7:	lea    0x335db2(%rip),%rcx        # a9adb0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x12c8>
  764ffe:	lea    0x3358a3(%rip),%r8        # a9a8a8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xdc0>
  765005:	lea    0x60(%rsp),%rdx
  76500a:	mov    $0x2b,%esi
  76500f:	call   *0x35533b(%rip)        # aba350 <_DYNAMIC+0x310>
  765015:	jmp    76541d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  76501a:	lea    0x33589f(%rip),%r9        # a9a8c0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xdd8>
  765021:	xor    %edi,%edi
  765023:	lea    0x90(%rsp),%rsi
  76502b:	lea    0x130(%rsp),%rdx
  765033:	xor    %ecx,%ecx
  765035:	call   *0x3554c5(%rip)        # aba500 <_DYNAMIC+0x4c0>
  76503b:	jmp    76541d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  765040:	mov    0x10(%rsp),%rax
  765045:	mov    %rax,0x60(%rsp)
  76504a:	mov    0x8(%rsp),%rax
  76504f:	mov    %rax,0x150(%rsp)
  765057:	mov    $0x1,%edi
  76505c:	mov    %r15,%rsi
  76505f:	call   *0x3552cb(%rip)        # aba330 <_DYNAMIC+0x2f0>
  765065:	jmp    76541d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  76506a:	mov    0x158(%rsp),%rax
  765072:	mov    %rax,0x60(%rsp)
  765077:	lea    -0x6953d4(%rip),%rdi        # cfcaa <GCC_except_table0+0xd8a2>
  76507e:	lea    0x335ccb(%rip),%rcx        # a9ad50 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1268>
  765085:	lea    0x335bcc(%rip),%r8        # a9ac58 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1170>
  76508c:	lea    0x60(%rsp),%rdx
  765091:	mov    $0x2b,%esi
  765096:	call   *0x3552b4(%rip)        # aba350 <_DYNAMIC+0x310>
  76509c:	jmp    76541d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  7650a1:	mov    0x158(%rsp),%rax
  7650a9:	mov    %rax,0x60(%rsp)
  7650ae:	lea    -0x69540b(%rip),%rdi        # cfcaa <GCC_except_table0+0xd8a2>
  7650b5:	lea    0x335c94(%rip),%rcx        # a9ad50 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1268>
  7650bc:	lea    0x335b95(%rip),%r8        # a9ac58 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1170>
  7650c3:	lea    0x60(%rsp),%rdx
  7650c8:	mov    $0x2b,%esi
  7650cd:	call   *0x35527d(%rip)        # aba350 <_DYNAMIC+0x310>
  7650d3:	jmp    76541d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  7650d8:	mov    0x10(%rsp),%rax
  7650dd:	mov    %rax,0x60(%rsp)
  7650e2:	mov    0x8(%rsp),%rax
  7650e7:	mov    %rax,0x150(%rsp)
  7650ef:	mov    $0x1,%edi
  7650f4:	mov    %r14,%rsi
  7650f7:	call   *0x355233(%rip)        # aba330 <_DYNAMIC+0x2f0>
  7650fd:	jmp    76541d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  765102:	mov    0x10(%rsp),%rax
  765107:	mov    %rax,0x60(%rsp)
  76510c:	mov    0x8(%rsp),%rax
  765111:	mov    %rax,0x150(%rsp)
  765119:	mov    $0x1,%edi
  76511e:	mov    %r12,%rsi
  765121:	call   *0x355209(%rip)        # aba330 <_DYNAMIC+0x2f0>
  765127:	jmp    76541d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  76512c:	mov    $0x1,%al
  76512e:	jmp    764f00 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x18b0>
  765133:	lea    0x60(%rsp),%rdi
  765138:	call   746480 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultNtNtCslbxve4rcJus_4gpui7runtime6CommitNtBZ_5ErrorEECs9C2G9YFESsD_29canonical_text_public_control>
  76513d:	lea    -0x6956c4(%rip),%rdi        # cfa80 <GCC_except_table0+0xd678>
  765144:	lea    0x3357a5(%rip),%rdx        # a9a8f0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xe08>
  76514b:	mov    $0x4e,%esi
  765150:	call   *0x3551a2(%rip)        # aba2f8 <_DYNAMIC+0x2b8>
  765156:	jmp    76541d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  76515b:	mov    $0x1,%edi
  765160:	mov    %r13,%rsi
  765163:	call   *0x3551c7(%rip)        # aba330 <_DYNAMIC+0x2f0>
  765169:	jmp    76541d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  76516e:	mov    $0x12,%eax
  765173:	jmp    76517a <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1b2a>
  765175:	mov    $0xe,%eax
  76517a:	mov    %rax,0x1e8(%rsp)
  765182:	mov    0x1e8(%rsp),%rax
  76518a:	mov    %rax,0x60(%rsp)
  76518f:	mov    0x18(%rsp),%rax
  765194:	mov    %rax,0x68(%rsp)
  765199:	mov    0x8(%rsp),%rax
  76519e:	mov    %rax,0x70(%rsp)
  7651a3:	lea    -0x695789(%rip),%rdi        # cfa21 <GCC_except_table0+0xd619>
  7651aa:	lea    0x335b7f(%rip),%rcx        # a9ad30 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1248>
  7651b1:	lea    0x3354c8(%rip),%r8        # a9a680 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xb98>
  7651b8:	lea    0x60(%rsp),%rdx
  7651bd:	mov    $0x2a,%esi
  7651c2:	call   *0x355188(%rip)        # aba350 <_DYNAMIC+0x310>
  7651c8:	jmp    76541d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  7651cd:	movq   $0xd,0x1f0(%rsp)
  7651d9:	movq   $0x0,0x1f8(%rsp)
  7651e5:	mov    0x220(%rsp),%rax
  7651ed:	mov    %rax,0x90(%rsp)
  7651f5:	mov    0x1f0(%rsp),%rax
  7651fd:	mov    0x1f8(%rsp),%rcx
  765205:	movups 0x200(%rsp),%xmm0
  76520d:	movups 0x210(%rsp),%xmm1
  765215:	movaps %xmm1,0x80(%rsp)
  76521d:	movaps %xmm0,0x70(%rsp)
  765222:	mov    %rax,0x60(%rsp)
  765227:	mov    %rcx,0x68(%rsp)
  76522c:	lea    -0x695589(%rip),%rdi        # cfcaa <GCC_except_table0+0xd8a2>
  765233:	lea    0x335af6(%rip),%rcx        # a9ad30 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1248>
  76523a:	lea    0x335597(%rip),%r8        # a9a7d8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xcf0>
  765241:	lea    0x60(%rsp),%rdx
  765246:	mov    $0x2b,%esi
  76524b:	call   *0x3550ff(%rip)        # aba350 <_DYNAMIC+0x310>
  765251:	jmp    76541d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  765256:	mov    $0xd,%eax
  76525b:	movq   $0x0,0x2b0(%rsp)
  765267:	jmp    765275 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1c25>
  765269:	mov    $0xe,%eax
  76526e:	jmp    765275 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1c25>
  765270:	mov    $0x14,%eax
  765275:	mov    %rax,0x60(%rsp)
  76527a:	mov    0x2b0(%rsp),%rax
  765282:	mov    %rax,0x68(%rsp)
  765287:	mov    0x10(%rsp),%rax
  76528c:	mov    %rax,0x70(%rsp)
  765291:	lea    -0x6955ee(%rip),%rdi        # cfcaa <GCC_except_table0+0xd8a2>
  765298:	lea    0x335a91(%rip),%rcx        # a9ad30 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1248>
  76529f:	lea    0x33554a(%rip),%r8        # a9a7f0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xd08>
  7652a6:	lea    0x60(%rsp),%rdx
  7652ab:	mov    $0x2b,%esi
  7652b0:	call   *0x35509a(%rip)        # aba350 <_DYNAMIC+0x310>
  7652b6:	jmp    76541d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  7652bb:	movq   $0xd,0x1f0(%rsp)
  7652c7:	movq   $0x0,0x1f8(%rsp)
  7652d3:	jmp    7652e1 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1c91>
  7652d5:	movq   $0xe,0x1f0(%rsp)
  7652e1:	mov    0x220(%rsp),%rax
  7652e9:	mov    %rax,0x90(%rsp)
  7652f1:	mov    0x1f0(%rsp),%rax
  7652f9:	mov    0x1f8(%rsp),%rcx
  765301:	movups 0x200(%rsp),%xmm0
  765309:	movups 0x210(%rsp),%xmm1
  765311:	movaps %xmm1,0x80(%rsp)
  765319:	movaps %xmm0,0x70(%rsp)
  76531e:	mov    %rax,0x60(%rsp)
  765323:	mov    %rcx,0x68(%rsp)
  765328:	lea    -0x695685(%rip),%rdi        # cfcaa <GCC_except_table0+0xd8a2>
  76532f:	lea    0x3359fa(%rip),%rcx        # a9ad30 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1248>
  765336:	lea    0x3354e3(%rip),%r8        # a9a820 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xd38>
  76533d:	lea    0x60(%rsp),%rdx
  765342:	mov    $0x2b,%esi
  765347:	call   *0x355003(%rip)        # aba350 <_DYNAMIC+0x310>
  76534d:	jmp    76541d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  765352:	mov    0x68(%rsp),%r14
  765357:	mov    0x78(%rsp),%rcx
  76535c:	mov    %rcx,%rax
  76535f:	sub    %r14,%rax
  765362:	movabs $0xaaaaaaaaaaaaaaab,%rdx
  76536c:	mul    %rdx
  76536f:	cmp    %r14,%rcx
  765372:	jne    7653c9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1d79>
  765374:	mov    0x70(%rsp),%rax
  765379:	test   %rax,%rax
  76537c:	je     765396 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1d46>
  76537e:	mov    0x60(%rsp),%rdi
  765383:	shl    $0x3,%rax
  765387:	lea    (%rax,%rax,2),%rsi
  76538b:	mov    $0x8,%edx
  765390:	call   *0x354eea(%rip)        # aba280 <_DYNAMIC+0x240>
  765396:	mov    $0x8,%eax
  76539b:	mov    %rax,0x20(%rsp)
  7653a0:	movq   $0x0,0x288(%rsp)
  7653ac:	xor    %ebx,%ebx
  7653ae:	lea    -0x6957d5(%rip),%rdi        # cfbe0 <GCC_except_table0+0xd7d8>
  7653b5:	lea    0x335854(%rip),%rdx        # a9ac10 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1128>
  7653bc:	mov    $0x6b,%esi
  7653c1:	call   *0x354ef1(%rip)        # aba2b8 <_DYNAMIC+0x278>
  7653c7:	jmp    76541d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  7653c9:	mov    %rdx,%rbx
  7653cc:	shr    $0x4,%rbx
  7653d0:	add    $0x8,%r14
  7653d4:	mov    0x354ea5(%rip),%r15        # aba280 <_DYNAMIC+0x240>
  7653db:	jmp    7653e9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1d99>
  7653dd:	nopl   (%rax)
  7653e0:	add    $0x18,%r14
  7653e4:	dec    %rbx
  7653e7:	je     765374 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1d24>
  7653e9:	mov    -0x8(%r14),%rsi
  7653ed:	test   %rsi,%rsi
  7653f0:	je     7653e0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1d90>
  7653f2:	mov    (%r14),%rdi
  7653f5:	mov    $0x1,%edx
  7653fa:	call   *%r15
  7653fd:	jmp    7653e0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1d90>
  7653ff:	mov    $0x1,%edi
  765404:	mov    %r12,%rsi
  765407:	call   *0x354f23(%rip)        # aba330 <_DYNAMIC+0x2f0>
  76540d:	jmp    76541d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1dcd>
  76540f:	mov    $0x1,%edi
  765414:	mov    %r13,%rsi
  765417:	call   *0x354f13(%rip)        # aba330 <_DYNAMIC+0x2f0>
  76541d:	ud2
  76541f:	xor    %eax,%eax
  765421:	jmp    764f00 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x18b0>
  765426:	mov    %rax,%r15
  765429:	mov    $0x9,%esi
  76542e:	mov    $0x1,%edx
  765433:	mov    %rbp,%rdi
  765436:	jmp    7656bd <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x206d>
  76543b:	mov    %rax,%r15
  76543e:	mov    $0x4,%esi
  765443:	mov    $0x1,%edx
  765448:	mov    %r13,%rdi
  76544b:	jmp    7656bd <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x206d>
  765450:	mov    %rax,%r15
  765453:	jmp    7656d0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2080>
  765458:	mov    %rax,%r15
  76545b:	lea    0x150(%rsp),%rdi
  765463:	call   74cba0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  765468:	jmp    7656d0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2080>
  76546d:	mov    %rax,%r15
  765470:	jmp    7656c3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2073>
  765475:	mov    %rax,%r15
  765478:	jmp    76568e <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x203e>
  76547d:	mov    %rax,%r15
  765480:	jmp    7656c3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2073>
  765485:	mov    %rax,%r15
  765488:	jmp    7656b0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2060>
  76548d:	mov    %rax,%r15
  765490:	jmp    7656c3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2073>
  765495:	mov    %rax,%r15
  765498:	jmp    7656c3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2073>
  76549d:	mov    %rax,%r15
  7654a0:	jmp    7656c3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2073>
  7654a5:	mov    %rax,%r15
  7654a8:	jmp    7656c3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2073>
  7654ad:	mov    %rax,%r15
  7654b0:	jmp    76591a <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x22ca>
  7654b5:	mov    %rax,%r15
  7654b8:	mov    $0x770,%esi
  7654bd:	mov    $0x8,%edx
  7654c2:	mov    %r14,%rdi
  7654c5:	jmp    7657d6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2186>
  7654ca:	jmp    7654f6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ea6>
  7654cc:	mov    %rax,%r15
  7654cf:	jmp    7658af <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x225f>
  7654d4:	mov    %rax,%r15
  7654d7:	jmp    7656c3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2073>
  7654dc:	jmp    7654f6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ea6>
  7654de:	mov    %rax,%r15
  7654e1:	jmp    765679 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2029>
  7654e6:	mov    %rax,%r15
  7654e9:	jmp    7657b8 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2168>
  7654ee:	mov    %rax,%r15
  7654f1:	jmp    76571c <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x20cc>
  7654f6:	mov    %rax,%r15
  7654f9:	lea    0x60(%rsp),%rdi
  7654fe:	call   74d810 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  765503:	mov    $0x1,%bpl
  765506:	jmp    765767 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2117>
  76550b:	mov    %rax,%r15
  76550e:	test   %r14,%r14
  765511:	je     76552e <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ede>
  765513:	mov    $0x1,%edx
  765518:	mov    %rbp,%rdi
  76551b:	mov    %r14,%rsi
  76551e:	call   *0x354d5c(%rip)        # aba280 <_DYNAMIC+0x240>
  765524:	jmp    76552e <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ede>
  765526:	jmp    765720 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x20d0>
  76552b:	mov    %rax,%r15
  76552e:	lea    0x150(%rsp),%rdi
  765536:	call   749a70 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtB4_4iter8adapters4skip4SkipNtNtCs2AWtUsOyxgP_3std3env4ArgsEECs9C2G9YFESsD_29canonical_text_public_control>
  76553b:	lea    0x28(%rsp),%rdi
  765540:	call   7470a0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtBG_6string6StringEECs9C2G9YFESsD_29canonical_text_public_control>
  765545:	mov    %r15,%rdi
  765548:	call   a98730 <_Unwind_Resume@plt>
  76554d:	mov    %rax,%r15
  765550:	mov    $0x4,%esi
  765555:	jmp    76555f <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1f0f>
  765557:	mov    %rax,%r15
  76555a:	mov    $0x9,%esi
  76555f:	mov    $0x1,%edx
  765564:	mov    %r13,%rdi
  765567:	jmp    765817 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x21c7>
  76556c:	mov    %rax,%r15
  76556f:	mov    0x10(%rsp),%rax
  765574:	mov    %rax,0x60(%rsp)
  765579:	mov    0x8(%rsp),%rax
  76557e:	mov    %rax,0x150(%rsp)
  765586:	jmp    7658a2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2252>
  76558b:	jmp    76564d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ffd>
  765590:	mov    %rax,%r15
  765593:	mov    0x10(%rsp),%rax
  765598:	mov    %rax,0x60(%rsp)
  76559d:	mov    0x8(%rsp),%rax
  7655a2:	mov    %rax,0x150(%rsp)
  7655aa:	lea    0x2b8(%rsp),%rdi
  7655b2:	call   74cba0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  7655b7:	jmp    7658a2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2252>
  7655bc:	jmp    76564d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ffd>
  7655c1:	mov    %rax,%r15
  7655c4:	mov    0x10(%rsp),%rax
  7655c9:	mov    %rax,0x60(%rsp)
  7655ce:	mov    0x8(%rsp),%rax
  7655d3:	mov    %rax,0x150(%rsp)
  7655db:	jmp    76580a <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x21ba>
  7655e0:	jmp    76564d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ffd>
  7655e2:	jmp    76564d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ffd>
  7655e4:	jmp    76564d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1ffd>
  7655e6:	mov    %rax,%r15
  7655e9:	jmp    765679 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2029>
  7655ee:	mov    %rax,%r15
  7655f1:	cmpq   $0xffffffffffffffff,0x18(%rsp)
  7655f7:	jne    7658af <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x225f>
  7655fd:	mov    0x288(%rsp),%rax
  765605:	test   %rax,%rax
  765608:	je     765946 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x22f6>
  76560e:	shl    $0x3,%rax
  765612:	lea    (%rax,%rax,2),%rsi
  765616:	mov    $0x8,%edx
  76561b:	mov    0x20(%rsp),%rdi
  765620:	call   *0x354c5a(%rip)        # aba280 <_DYNAMIC+0x240>
  765626:	mov    %r15,%rdi
  765629:	call   a98730 <_Unwind_Resume@plt>
  76562e:	mov    %rax,%r15
  765631:	mov    0x10(%rsp),%rax
  765636:	mov    %rax,0x60(%rsp)
  76563b:	mov    0x8(%rsp),%rax
  765640:	mov    %rax,0x150(%rsp)
  765648:	jmp    7658af <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x225f>
  76564d:	mov    %rax,%r15
  765650:	mov    0x10(%rsp),%rax
  765655:	mov    %rax,0x60(%rsp)
  76565a:	mov    0x8(%rsp),%rax
  76565f:	mov    %rax,0x150(%rsp)
  765667:	jmp    76581d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x21cd>
  76566c:	mov    %rax,%r15
  76566f:	lea    0x60(%rsp),%rdi
  765674:	call   74d810 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  765679:	mov    $0x1,%bpl
  76567c:	jmp    765787 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2137>
  765681:	mov    %rax,%r15
  765684:	lea    0x60(%rsp),%rdi
  765689:	call   74cab0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5error5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  76568e:	mov    $0x8,%esi
  765693:	mov    $0x1,%edx
  765698:	mov    %r14,%rdi
  76569b:	jmp    7656bd <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x206d>
  76569d:	call   *0x354c05(%rip)        # aba2a8 <_DYNAMIC+0x268>
  7656a3:	mov    %rax,%r15
  7656a6:	lea    0x60(%rsp),%rdi
  7656ab:	call   74cab0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5error5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  7656b0:	mov    $0xa,%esi
  7656b5:	mov    $0x1,%edx
  7656ba:	mov    %r12,%rdi
  7656bd:	call   *0x354bbd(%rip)        # aba280 <_DYNAMIC+0x240>
  7656c3:	lea    0x100(%rsp),%rdi
  7656cb:	call   747dd0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscl5MXVnO7Zx_10serde_json3map3MapNtNtCscdodAO9FK5_5alloc6string6StringNtNtBG_5value5ValueEECs9C2G9YFESsD_29canonical_text_public_control>
  7656d0:	lea    0x1f0(%rsp),%rdi
  7656d8:	call   74cba0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  7656dd:	jmp    7658af <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x225f>
  7656e2:	call   *0x354bc0(%rip)        # aba2a8 <_DYNAMIC+0x268>
  7656e8:	mov    %rax,%r15
  7656eb:	jmp    76581d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x21cd>
  7656f0:	mov    %rax,%r15
  7656f3:	mov    0x60(%rsp),%rsi
  7656f8:	test   %rsi,%rsi
  7656fb:	je     76571c <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x20cc>
  7656fd:	mov    0x68(%rsp),%rdi
  765702:	mov    $0x1,%edx
  765707:	call   *0x354b73(%rip)        # aba280 <_DYNAMIC+0x240>
  76570d:	jmp    76571c <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x20cc>
  76570f:	mov    %rax,%r15
  765712:	lea    0x60(%rsp),%rdi
  765717:	call   7486b0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui7runtime8SetErrorNtNtCscdodAO9FK5_5alloc6string6StringEECs9C2G9YFESsD_29canonical_text_public_control>
  76571c:	xor    %ebp,%ebp
  76571e:	jmp    76574d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x20fd>
  765720:	mov    %rax,%r15
  765723:	mov    $0x1,%bpl
  765726:	jmp    765767 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2117>
  765728:	mov    %rax,%r15
  76572b:	jmp    7658af <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x225f>
  765730:	mov    %rax,%r15
  765733:	mov    0x60(%rsp),%rsi
  765738:	mov    $0x1,%bpl
  76573b:	test   %rsi,%rsi
  76573e:	je     765767 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2117>
  765740:	mov    0x68(%rsp),%rdi
  765745:	jmp    76575c <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x210c>
  765747:	mov    %rax,%r15
  76574a:	mov    $0x1,%bpl
  76574d:	mov    0x28(%rsp),%rsi
  765752:	test   %rsi,%rsi
  765755:	je     765767 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2117>
  765757:	mov    0x30(%rsp),%rdi
  76575c:	mov    $0x1,%edx
  765761:	call   *0x354b19(%rip)        # aba280 <_DYNAMIC+0x240>
  765767:	mov    0x100(%rsp),%rsi
  76576f:	test   %rsi,%rsi
  765772:	je     765787 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2137>
  765774:	mov    0x108(%rsp),%rdi
  76577c:	mov    $0x1,%edx
  765781:	call   *0x354af9(%rip)        # aba280 <_DYNAMIC+0x240>
  765787:	mov    0x260(%rsp),%r14
  76578f:	test   %r14,%r14
  765792:	je     7657af <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x215f>
  765794:	mov    %r14,%rdi
  765797:	call   748000 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui7runtime7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEEB1h_>
  76579c:	mov    $0x770,%esi
  7657a1:	mov    $0x8,%edx
  7657a6:	mov    %r14,%rdi
  7657a9:	call   *0x354ad1(%rip)        # aba280 <_DYNAMIC+0x240>
  7657af:	test   %bpl,%bpl
  7657b2:	je     7658af <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x225f>
  7657b8:	mov    0x2b8(%rsp),%rsi
  7657c0:	test   %rsi,%rsi
  7657c3:	je     7658af <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x225f>
  7657c9:	mov    0x2c0(%rsp),%rdi
  7657d1:	mov    $0x1,%edx
  7657d6:	call   *0x354aa4(%rip)        # aba280 <_DYNAMIC+0x240>
  7657dc:	jmp    7658af <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x225f>
  7657e1:	mov    $0x770,%esi
  7657e6:	mov    $0x8,%edx
  7657eb:	mov    %r14,%rdi
  7657ee:	call   *0x354a8c(%rip)        # aba280 <_DYNAMIC+0x240>
  7657f4:	call   *0x354aae(%rip)        # aba2a8 <_DYNAMIC+0x268>
  7657fa:	mov    %rax,%r15
  7657fd:	lea    0x100(%rsp),%rdi
  765805:	call   74cab0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5error5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  76580a:	mov    $0x8,%esi
  76580f:	mov    $0x1,%edx
  765814:	mov    %r14,%rdi
  765817:	call   *0x354a63(%rip)        # aba280 <_DYNAMIC+0x240>
  76581d:	mov    0x298(%rsp),%rcx
  765825:	test   %rcx,%rcx
  765828:	jne    765830 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x21e0>
  76582a:	xor    %ecx,%ecx
  76582c:	xor    %eax,%eax
  76582e:	jmp    76587d <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x222d>
  765830:	mov    0x2a0(%rsp),%rdx
  765838:	mov    0x2a8(%rsp),%rax
  765840:	movq   $0x0,0x1f8(%rsp)
  76584c:	mov    %rcx,0x200(%rsp)
  765854:	mov    %rdx,0x208(%rsp)
  76585c:	movq   $0x0,0x218(%rsp)
  765868:	mov    %rcx,0x220(%rsp)
  765870:	mov    %rdx,0x228(%rsp)
  765878:	mov    $0x1,%ecx
  76587d:	mov    %rcx,0x1f0(%rsp)
  765885:	mov    %rcx,0x210(%rsp)
  76588d:	mov    %rax,0x230(%rsp)
  765895:	lea    0x1f0(%rsp),%rdi
  76589d:	call   74ad90 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtCscdodAO9FK5_5alloc11collections5btree3map8IntoIterNtNtBK_6string6StringNtNtCscl5MXVnO7Zx_10serde_json5value5ValueEECs9C2G9YFESsD_29canonical_text_public_control>
  7658a2:	lea    0x260(%rsp),%rdi
  7658aa:	call   74cba0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscl5MXVnO7Zx_10serde_json5value5ValueECs9C2G9YFESsD_29canonical_text_public_control>
  7658af:	mov    0x20(%rsp),%rax
  7658b4:	lea    0x8(%rax),%r14
  7658b8:	mov    0x3549c1(%rip),%r12        # aba280 <_DYNAMIC+0x240>
  7658bf:	jmp    7658dd <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x228d>
  7658c1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  7658d0:	add    $0x18,%r14
  7658d4:	dec    %rbx
  7658d7:	je     7655fd <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x1fad>
  7658dd:	mov    -0x8(%r14),%rsi
  7658e1:	test   %rsi,%rsi
  7658e4:	je     7658d0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2280>
  7658e6:	mov    (%r14),%rdi
  7658e9:	mov    $0x1,%edx
  7658ee:	call   *%r12
  7658f1:	jmp    7658d0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2280>
  7658f3:	call   *0x3549af(%rip)        # aba2a8 <_DYNAMIC+0x268>
  7658f9:	call   *0x3549a9(%rip)        # aba2a8 <_DYNAMIC+0x268>
  7658ff:	mov    %rax,%r15
  765902:	mov    0x18(%rsp),%rsi
  765907:	test   %rsi,%rsi
  76590a:	je     76591a <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x22ca>
  76590c:	mov    $0x1,%edx
  765911:	mov    %rbx,%rdi
  765914:	call   *0x354966(%rip)        # aba280 <_DYNAMIC+0x240>
  76591a:	mov    0x68(%rsp),%r14
  76591f:	mov    0x78(%rsp),%rcx
  765924:	mov    %rcx,%rax
  765927:	sub    %r14,%rax
  76592a:	movabs $0xaaaaaaaaaaaaaaab,%rdx
  765934:	mul    %rdx
  765937:	cmp    %r14,%rcx
  76593a:	jne    76594e <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x22fe>
  76593c:	mov    0x70(%rsp),%rax
  765941:	test   %rax,%rax
  765944:	jne    76598f <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x233f>
  765946:	mov    %r15,%rdi
  765949:	call   a98730 <_Unwind_Resume@plt>
  76594e:	mov    %rdx,%rbx
  765951:	shr    $0x4,%rbx
  765955:	add    $0x8,%r14
  765959:	mov    0x354920(%rip),%r12        # aba280 <_DYNAMIC+0x240>
  765960:	jmp    765979 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2329>
  765962:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  765970:	add    $0x18,%r14
  765974:	dec    %rbx
  765977:	je     76593c <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x22ec>
  765979:	mov    -0x8(%r14),%rsi
  76597d:	test   %rsi,%rsi
  765980:	je     765970 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2320>
  765982:	mov    (%r14),%rdi
  765985:	mov    $0x1,%edx
  76598a:	call   *%r12
  76598d:	jmp    765970 <_RNvCs9C2G9YFESsD_29canonical_text_public_control4main+0x2320>
  76598f:	mov    0x60(%rsp),%rdi
  765994:	shl    $0x3,%rax
  765998:	lea    (%rax,%rax,2),%rsi
  76599c:	mov    $0x8,%edx
  7659a1:	call   *0x3548d9(%rip)        # aba280 <_DYNAMIC+0x240>
  7659a7:	mov    %r15,%rdi
  7659aa:	call   a98730 <_Unwind_Resume@plt>

canonical_text_public_control::mount bytes=2801 frame=3384

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007659b0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount>:
  7659b0:	push   %rbp
  7659b1:	push   %r15
  7659b3:	push   %r14
  7659b5:	push   %r13
  7659b7:	push   %r12
  7659b9:	push   %rbx
  7659ba:	sub    $0xd08,%rsp
  7659c1:	mov    (%rdi),%rax
  7659c4:	mov    %rax,0x10(%rsp)
  7659c9:	mov    0x8(%rdi),%r14
  7659cd:	mov    0x10(%rdi),%rbx
  7659d1:	movups -0x695dc0(%rip),%xmm0        # cfc18 <GCC_except_table0+0xd810>
  7659d8:	movups %xmm0,0xf8(%rsp)
  7659e0:	movq   $0x0,0x108(%rsp)
  7659ec:	lea    0x3b0(%rsp),%rdi
  7659f4:	movabs $0x104000001a4,%r15
  7659fe:	movss  -0x6a357e(%rip),%xmm0        # c2488 <GCC_except_table0+0x80>
  765a06:	mov    %r15,%rsi
  765a09:	call   *0x354b81(%rip)        # aba590 <_DYNAMIC+0x550>
  765a0f:	mov    0x3b0(%rsp),%r13
  765a17:	cmp    $0xfffffffffffffffe,%r13
  765a1b:	jne    7660f2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x742>
  765a21:	lea    0x3b0(%rsp),%rdi
  765a29:	call   797870 <_RNvXs_Cs9C2G9YFESsD_29canonical_text_public_controlNtB4_6EditorNtCslbxve4rcJus_4gpui4View7sources>
  765a2e:	mov    0x3b0(%rsp),%rax
  765a36:	movups 0x408(%rsp),%xmm0
  765a3e:	movaps %xmm0,0x150(%rsp)
  765a46:	movups 0x3f8(%rsp),%xmm0
  765a4e:	movaps %xmm0,0x140(%rsp)
  765a56:	movups 0x3e8(%rsp),%xmm0
  765a5e:	movaps %xmm0,0x130(%rsp)
  765a66:	movups 0x3d8(%rsp),%xmm0
  765a6e:	movaps %xmm0,0x120(%rsp)
  765a76:	movups 0x3c8(%rsp),%xmm1
  765a7e:	movaps %xmm1,0x110(%rsp)
  765a86:	movups 0x3b8(%rsp),%xmm2
  765a8e:	movups %xmm1,0xa0(%rsp)
  765a96:	movups %xmm0,0xb0(%rsp)
  765a9e:	mov    0x130(%rsp),%rcx
  765aa6:	mov    %rcx,0xc0(%rsp)
  765aae:	mov    0x158(%rsp),%rcx
  765ab6:	mov    %rcx,0xe8(%rsp)
  765abe:	movups 0x148(%rsp),%xmm0
  765ac6:	movups %xmm0,0xd8(%rsp)
  765ace:	movups 0x138(%rsp),%xmm0
  765ad6:	movups %xmm0,0xc8(%rsp)
  765ade:	mov    %rax,0x88(%rsp)
  765ae6:	movups %xmm2,0x90(%rsp)
  765aee:	movl   $0x0,0x110(%rsp)
  765af9:	movl   $0x434b0000,0x118(%rsp)
  765b04:	movw   $0x0,0x11c(%rsp)
  765b0e:	lea    0x3b0(%rsp),%rdi
  765b16:	lea    0x110(%rsp),%rcx
  765b1e:	mov    $0x1a4,%esi
  765b23:	mov    $0x104,%edx
  765b28:	call   *0x354a6a(%rip)        # aba598 <_DYNAMIC+0x558>
  765b2e:	mov    0x3b0(%rsp),%r13
  765b36:	mov    0x3b8(%rsp),%ebp
  765b3d:	mov    0x3bc(%rsp),%r12d
  765b45:	cmp    $0x2,%r13
  765b49:	je     76613f <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x78f>
  765b4f:	lea    0x3c0(%rsp),%rsi
  765b57:	lea    0xb30(%rsp),%rdi
  765b5f:	mov    $0x1d8,%edx
  765b64:	call   *0x354736(%rip)        # aba2a0 <memcpy@GLIBC_2.14>
  765b6a:	mov    %r13,0xb20(%rsp)
  765b72:	mov    %ebp,0xb28(%rsp)
  765b79:	mov    %r12d,0xb2c(%rsp)
  765b81:	call   *0x354a19(%rip)        # aba5a0 <_DYNAMIC+0x560>
  765b87:	mov    %rax,%r12
  765b8a:	lea    0x110(%rsp),%rdi
  765b92:	call   *0x354a10(%rip)        # aba5a8 <_DYNAMIC+0x568>
  765b98:	mov    %rbx,0x650(%rsp)
  765ba0:	movl   $0x0,0x658(%rsp)
  765bab:	movups 0xf4(%rsp),%xmm0
  765bb3:	movups 0x100(%rsp),%xmm1
  765bbb:	movups %xmm0,0x65c(%rsp)
  765bc3:	movups %xmm1,0x668(%rsp)
  765bcb:	movl   $0x0,0x678(%rsp)
  765bd6:	movups 0x88(%rsp),%xmm0
  765bde:	movups 0x98(%rsp),%xmm1
  765be6:	movups 0xa8(%rsp),%xmm2
  765bee:	movups 0xb8(%rsp),%xmm3
  765bf6:	movups %xmm0,0x5d8(%rsp)
  765bfe:	movups %xmm1,0x5e8(%rsp)
  765c06:	movups %xmm2,0x5f8(%rsp)
  765c0e:	movups %xmm3,0x608(%rsp)
  765c16:	movups 0xc8(%rsp),%xmm0
  765c1e:	movups %xmm0,0x618(%rsp)
  765c26:	movups 0xd8(%rsp),%xmm0
  765c2e:	movups %xmm0,0x628(%rsp)
  765c36:	mov    0xe8(%rsp),%rax
  765c3e:	mov    %rax,0x638(%rsp)
  765c46:	lea    0x6b0(%rsp),%rdi
  765c4e:	lea    0x110(%rsp),%rsi
  765c56:	mov    0x354643(%rip),%rbx        # aba2a0 <memcpy@GLIBC_2.14>
  765c5d:	mov    $0x298,%edx
  765c62:	call   *%rbx
  765c64:	lea    0x3b0(%rsp),%rdi
  765c6c:	lea    0xb20(%rsp),%rsi
  765c74:	mov    $0x1e8,%edx
  765c79:	call   *%rbx
  765c7b:	mov    0x10(%rsp),%rax
  765c80:	mov    %rax,0x640(%rsp)
  765c88:	mov    %r14,0x648(%rsp)
  765c90:	movq   $0x0,0x680(%rsp)
  765c9c:	movq   $0x8,0x688(%rsp)
  765ca8:	xorps  %xmm0,%xmm0
  765cab:	movups %xmm0,0x690(%rsp)
  765cb3:	movq   $0x8,0x6a0(%rsp)
  765cbf:	movq   $0x0,0x6a8(%rsp)
  765ccb:	movq   $0x0,0x9c8(%rsp)
  765cd7:	movups %xmm0,0x598(%rsp)
  765cdf:	movups %xmm0,0x5a8(%rsp)
  765ce7:	movups %xmm0,0x9b0(%rsp)
  765cef:	movq   $0x1,0x9d0(%rsp)
  765cfb:	movq   $0x0,0x9d8(%rsp)
  765d07:	mov    %r12,0x9a0(%rsp)
  765d0f:	movq   $0x0,0x9e8(%rsp)
  765d1b:	movq   $0x0,0xa30(%rsp)
  765d27:	movups %xmm0,0x9f8(%rsp)
  765d2f:	movq   $0x0,0xa08(%rsp)
  765d3b:	movups %xmm0,0xa18(%rsp)
  765d43:	movq   $0x0,0x948(%rsp)
  765d4f:	movq   $0x8,0x950(%rsp)
  765d5b:	movups %xmm0,0x958(%rsp)
  765d63:	movq   $0x0,0xa38(%rsp)
  765d6f:	movq   $0x0,0xa48(%rsp)
  765d7b:	movl   $0x1000101,0xb18(%rsp)
  765d86:	movw   $0x0,0xb1c(%rsp)
  765d90:	movups %xmm0,0xa50(%rsp)
  765d98:	movups %xmm0,0xa60(%rsp)
  765da0:	movq   $0x0,0xa70(%rsp)
  765dac:	mov    %r15,0xa78(%rsp)
  765db4:	movsd  -0x6a2d9c(%rip),%xmm1        # c3020 <GCC_except_table0+0xc18>
  765dbc:	movsd  %xmm1,0xb10(%rsp)
  765dc5:	movq   $0x1,0x9a8(%rsp)
  765dd1:	movq   $0xffffffffffffffff,0x978(%rsp)
  765ddd:	movq   $0x0,0xa80(%rsp)
  765de9:	movq   $0x0,0xa90(%rsp)
  765df5:	movq   $0x8,0x968(%rsp)
  765e01:	movq   $0x0,0x970(%rsp)
  765e0d:	movb   $0x0,0xb1e(%rsp)
  765e15:	movups %xmm0,0xaf8(%rsp)
  765e1d:	movups %xmm0,0xae8(%rsp)
  765e25:	movups %xmm0,0xad8(%rsp)
  765e2d:	movups %xmm0,0xac8(%rsp)
  765e35:	movups %xmm0,0xab8(%rsp)
  765e3d:	movups %xmm0,0xaa8(%rsp)
  765e45:	movups %xmm0,0xa98(%rsp)
  765e4d:	movq   $0x0,0xb08(%rsp)
  765e59:	call   *0x354429(%rip)        # aba288 <_DYNAMIC+0x248>
  765e5f:	mov    $0x770,%edi
  765e64:	mov    $0x8,%esi
  765e69:	call   *0x354421(%rip)        # aba290 <_DYNAMIC+0x250>
  765e6f:	test   %rax,%rax
  765e72:	je     76607d <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x6cd>
  765e78:	mov    %rax,%rbx
  765e7b:	lea    0x3b0(%rsp),%rsi
  765e83:	mov    $0x770,%edx
  765e88:	mov    %rax,%rdi
  765e8b:	call   *0x35440f(%rip)        # aba2a0 <memcpy@GLIBC_2.14>
  765e91:	mov    %rbx,0x20(%rsp)
  765e96:	lea    0x28(%rsp),%rdx
  765e9b:	movq   $0x0,(%rsp)
  765ea3:	lea    0x28(%rsp),%rdi
  765ea8:	mov    $0x8,%r8d
  765eae:	mov    %rbx,%rsi
  765eb1:	mov    $0x1,%ecx
  765eb6:	xor    %r9d,%r9d
  765eb9:	call   769e00 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB4_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE21describe_with_changedBW_>
  765ebe:	mov    0x28(%rsp),%r13
  765ec3:	cmp    $0xfffffffffffffffe,%r13
  765ec7:	jne    766092 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x6e2>
  765ecd:	lea    0x28(%rsp),%rdi
  765ed2:	mov    %rbx,%rsi
  765ed5:	call   78da80 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE7presentBO_>
  765eda:	mov    0x28(%rsp),%r13
  765edf:	cmp    $0xfffffffffffffffe,%r13
  765ee3:	jne    766092 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x6e2>
  765ee9:	mov    0x20(%rsp),%rbx
  765eee:	lea    0x3b0(%rsp),%rdi
  765ef6:	mov    %rbx,%rsi
  765ef9:	call   760be0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack>
  765efe:	test   %rbx,%rbx
  765f01:	je     766157 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x7a7>
  765f07:	cmpb   $0x0,0x76e(%rbx)
  765f0e:	jne    76615e <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x7ae>
  765f14:	cmpb   $0x1,0x76a(%rbx)
  765f1b:	jne    766165 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x7b5>
  765f21:	mov    0x5c0(%rbx),%r12
  765f28:	mov    $0x1a,%eax
  765f2d:	mov    %rax,0x10(%rsp)
  765f32:	test   %r12,%r12
  765f35:	je     76616f <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x7bf>
  765f3b:	mov    0x5b8(%rbx),%r13
  765f42:	shl    $0x6,%r12
  765f46:	lea    0x1e8(%rbx),%r14
  765f4d:	xor    %ebp,%ebp
  765f4f:	mov    0x3543e2(%rip),%r15        # aba338 <_DYNAMIC+0x2f8>
  765f56:	jmp    765f6d <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x5bd>
  765f58:	nopl   0x0(%rax,%rax,1)
  765f60:	add    $0x40,%rbp
  765f64:	cmp    %rbp,%r12
  765f67:	je     76616f <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x7bf>
  765f6d:	cmpb   $0x4,0x3d(%r13,%rbp,1)
  765f73:	jne    765f60 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x5b0>
  765f75:	mov    0x20(%r13,%rbp,1),%rsi
  765f7a:	mov    %r14,%rdi
  765f7d:	call   *%r15
  765f80:	test   %al,%al
  765f82:	je     765f60 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x5b0>
  765f84:	mov    0x20(%r13,%rbp,1),%rsi
  765f89:	lea    0x5f0(%rbx),%r12
  765f90:	mov    %r12,%rdi
  765f93:	call   *0x354547(%rip)        # aba4e0 <_DYNAMIC+0x4a0>
  765f99:	cmpb   $0x0,0x76e(%rbx)
  765fa0:	jne    7661b5 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x805>
  765fa6:	mov    %rax,%r14
  765fa9:	cmp    (%r12),%rax
  765fad:	jne    7661bc <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x80c>
  765fb3:	mov    %rdx,%r15
  765fb6:	mov    0x628(%rbx),%r12
  765fbd:	mov    0x630(%rbx),%r13
  765fc4:	lea    0x3b0(%rsp),%rdi
  765fcc:	mov    %rbx,%rsi
  765fcf:	call   78d320 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE16resolve_identityBO_>
  765fd4:	mov    0x3b0(%rsp),%rax
  765fdc:	mov    0x3b8(%rsp),%rdi
  765fe4:	cmp    $0xfffffffffffffffe,%rax
  765fe8:	jne    7661c3 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x813>
  765fee:	mov    0x2e0(%rbx),%rsi
  765ff5:	cmp    %rsi,%rdi
  765ff8:	jae    7661f9 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x849>
  765ffe:	lea    (%rdi,%rdi,4),%rdi
  766002:	shl    $0x3,%rdi
  766006:	add    0x2d8(%rbx),%rdi
  76600d:	call   *0x35459d(%rip)        # aba5b0 <_DYNAMIC+0x570>
  766013:	test   %al,%al
  766015:	je     76620b <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x85b>
  76601b:	mov    %r14,0x628(%rbx)
  766022:	mov    %r15,0x630(%rbx)
  766029:	movq   $0x0,0x758(%rbx)
  766034:	lea    0x110(%rsp),%rdi
  76603c:	mov    %rbx,%rsi
  76603f:	mov    %r12,%rdx
  766042:	mov    %r13,%rcx
  766045:	call   770f50 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE20publish_focus_changeB12_>
  76604a:	cmpl   $0xfffffffe,0x110(%rsp)
  766052:	jne    766253 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x8a3>
  766058:	lea    0x3b0(%rsp),%rdi
  766060:	mov    %rbx,%rsi
  766063:	call   760be0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control3ack>
  766068:	mov    %rbx,%rax
  76606b:	add    $0xd08,%rsp
  766072:	pop    %rbx
  766073:	pop    %r12
  766075:	pop    %r13
  766077:	pop    %r14
  766079:	pop    %r15
  76607b:	pop    %rbp
  76607c:	ret
  76607d:	mov    $0x8,%edi
  766082:	mov    $0x770,%esi
  766087:	call   *0x35420b(%rip)        # aba298 <_DYNAMIC+0x258>
  76608d:	jmp    7663c2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xa12>
  766092:	mov    0x30(%rsp),%rbp
  766097:	movups 0x38(%rsp),%xmm0
  76609c:	movaps %xmm0,0x70(%rsp)
  7660a1:	movups 0x48(%rsp),%xmm0
  7660a6:	movaps %xmm0,0x60(%rsp)
  7660ab:	movzbl 0x58(%rsp),%r15d
  7660b1:	mov    0x59(%rsp),%eax
  7660b5:	mov    %eax,0x18(%rsp)
  7660b9:	mov    0x5c(%rsp),%eax
  7660bd:	mov    %eax,0x1b(%rsp)
  7660c1:	mov    0x20(%rsp),%rbx
  7660c6:	test   %rbx,%rbx
  7660c9:	je     7660e6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x736>
  7660cb:	mov    %rbx,%rdi
  7660ce:	call   748000 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui7runtime7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEEB1h_>
  7660d3:	mov    $0x770,%esi
  7660d8:	mov    $0x8,%edx
  7660dd:	mov    %rbx,%rdi
  7660e0:	call   *0x35419a(%rip)        # aba280 <_DYNAMIC+0x240>
  7660e6:	mov    %rbp,%r12
  7660e9:	shr    $0x20,%r12
  7660ed:	jmp    766349 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x999>
  7660f2:	mov    0x3b8(%rsp),%rbp
  7660fa:	mov    %rbp,%r12
  7660fd:	shr    $0x20,%r12
  766101:	movups 0x3c0(%rsp),%xmm0
  766109:	movaps %xmm0,0x70(%rsp)
  76610e:	movups 0x3d0(%rsp),%xmm0
  766116:	movaps %xmm0,0x60(%rsp)
  76611b:	movzbl 0x3e0(%rsp),%r15d
  766124:	mov    0x3e1(%rsp),%eax
  76612b:	mov    %eax,0x18(%rsp)
  76612f:	mov    0x3e4(%rsp),%eax
  766136:	mov    %eax,0x1b(%rsp)
  76613a:	jmp    76632e <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x97e>
  76613f:	lea    0x88(%rsp),%rdi
  766147:	call   747e50 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui6source7SourcesNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEEB1g_>
  76614c:	mov    $0x23,%r13d
  766152:	jmp    76632e <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x97e>
  766157:	mov    $0xd,%eax
  76615c:	jmp    76616a <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x7ba>
  76615e:	mov    $0xe,%eax
  766163:	jmp    76616a <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x7ba>
  766165:	mov    $0x12,%eax
  76616a:	mov    %rax,0x10(%rsp)
  76616f:	mov    0x10(%rsp),%rax
  766174:	mov    %rax,0x3b0(%rsp)
  76617c:	movq   $0x0,0x3b8(%rsp)
  766188:	lea    -0x69676e(%rip),%rdi        # cfa21 <GCC_except_table0+0xd619>
  76618f:	lea    0x334b9a(%rip),%rcx        # a9ad30 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1248>
  766196:	lea    0x3344e3(%rip),%r8        # a9a680 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xb98>
  76619d:	lea    0x3b0(%rsp),%rdx
  7661a5:	mov    $0x2a,%esi
  7661aa:	call   *0x3541a0(%rip)        # aba350 <_DYNAMIC+0x310>
  7661b0:	jmp    7663c2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xa12>
  7661b5:	mov    $0xe,%eax
  7661ba:	jmp    766210 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x860>
  7661bc:	mov    $0x11,%eax
  7661c1:	jmp    7661db <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x82b>
  7661c3:	movups 0x3c0(%rsp),%xmm0
  7661cb:	movups 0x3d0(%rsp),%xmm1
  7661d3:	movzbl 0x3e0(%rsp),%ecx
  7661db:	mov    0x3e1(%rsp),%edx
  7661e2:	mov    0x3e4(%rsp),%esi
  7661e9:	mov    %esi,0xb23(%rsp)
  7661f0:	mov    %edx,0xb20(%rsp)
  7661f7:	jmp    766210 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x860>
  7661f9:	lea    0x335070(%rip),%rdx        # a9b270 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1788>
  766200:	call   *0x3540aa(%rip)        # aba2b0 <_DYNAMIC+0x270>
  766206:	jmp    7663c2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xa12>
  76620b:	mov    $0x16,%eax
  766210:	mov    %rax,0x110(%rsp)
  766218:	mov    %rdi,0x118(%rsp)
  766220:	movups %xmm0,0x120(%rsp)
  766228:	movups %xmm1,0x130(%rsp)
  766230:	mov    %cl,0x140(%rsp)
  766237:	mov    0xb20(%rsp),%eax
  76623e:	mov    0xb23(%rsp),%ecx
  766245:	mov    %eax,0x141(%rsp)
  76624c:	mov    %ecx,0x144(%rsp)
  766253:	mov    0x140(%rsp),%rax
  76625b:	mov    %rax,0x3e0(%rsp)
  766263:	mov    0x110(%rsp),%rax
  76626b:	mov    0x118(%rsp),%rcx
  766273:	movups 0x120(%rsp),%xmm0
  76627b:	movups 0x130(%rsp),%xmm1
  766283:	movaps %xmm1,0x3d0(%rsp)
  76628b:	movaps %xmm0,0x3c0(%rsp)
  766293:	mov    %rax,0x3b0(%rsp)
  76629b:	mov    %rcx,0x3b8(%rsp)
  7662a3:	lea    -0x696600(%rip),%rdi        # cfcaa <GCC_except_table0+0xd8a2>
  7662aa:	lea    0x334a7f(%rip),%rcx        # a9ad30 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1248>
  7662b1:	lea    0x3349e8(%rip),%r8        # a9aca0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x11b8>
  7662b8:	lea    0x3b0(%rsp),%rdx
  7662c0:	mov    $0x2b,%esi
  7662c5:	call   *0x354085(%rip)        # aba350 <_DYNAMIC+0x310>
  7662cb:	jmp    7663c2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xa12>
  7662d0:	mov    %rax,%r15
  7662d3:	mov    $0x770,%esi
  7662d8:	mov    $0x8,%edx
  7662dd:	mov    %rbx,%rdi
  7662e0:	call   *0x353f9a(%rip)        # aba280 <_DYNAMIC+0x240>
  7662e6:	mov    %r15,%rdi
  7662e9:	call   a98730 <_Unwind_Resume@plt>
  7662ee:	mov    %rax,%r15
  7662f1:	jmp    76640c <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xa5c>
  7662f6:	mov    %rax,%rdi
  7662f9:	call   *0x353fd9(%rip)        # aba2d8 <_DYNAMIC+0x298>
  7662ff:	mov    %rax,%r12
  766302:	mov    %rdx,%r13
  766305:	mov    (%rdx),%rax
  766308:	test   %rax,%rax
  76630b:	je     766312 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x962>
  76630d:	mov    %r12,%rdi
  766310:	call   *%rax
  766312:	mov    0x8(%r13),%rsi
  766316:	test   %rsi,%rsi
  766319:	je     766328 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x978>
  76631b:	mov    0x10(%r13),%rdx
  76631f:	mov    %r12,%rdi
  766322:	call   *0x353f58(%rip)        # aba280 <_DYNAMIC+0x240>
  766328:	mov    $0xf,%r13d
  76632e:	cmpq   $0x0,0x10(%rsp)
  766334:	je     766349 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0x999>
  766336:	mov    $0x1,%edx
  76633b:	mov    %r14,%rdi
  76633e:	mov    0x10(%rsp),%rsi
  766343:	call   *0x353f37(%rip)        # aba280 <_DYNAMIC+0x240>
  766349:	mov    %r13,0x110(%rsp)
  766351:	shl    $0x20,%r12
  766355:	mov    %ebp,%eax
  766357:	or     %r12,%rax
  76635a:	mov    %rax,0x118(%rsp)
  766362:	movaps 0x70(%rsp),%xmm0
  766367:	movups %xmm0,0x120(%rsp)
  76636f:	movaps 0x60(%rsp),%xmm0
  766374:	movups %xmm0,0x130(%rsp)
  76637c:	mov    %r15b,0x140(%rsp)
  766384:	mov    0x18(%rsp),%eax
  766388:	mov    0x1b(%rsp),%ecx
  76638c:	mov    %eax,0x141(%rsp)
  766393:	mov    %ecx,0x144(%rsp)
  76639a:	lea    -0x6966f7(%rip),%rdi        # cfcaa <GCC_except_table0+0xd8a2>
  7663a1:	lea    0x334988(%rip),%rcx        # a9ad30 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1248>
  7663a8:	lea    0x3348d9(%rip),%r8        # a9ac88 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x11a0>
  7663af:	lea    0x110(%rsp),%rdx
  7663b7:	mov    $0x2b,%esi
  7663bc:	call   *0x353f8e(%rip)        # aba350 <_DYNAMIC+0x310>
  7663c2:	ud2
  7663c4:	mov    %rax,%r15
  7663c7:	mov    0x8(%r13),%rsi
  7663cb:	test   %rsi,%rsi
  7663ce:	je     766419 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xa69>
  7663d0:	mov    0x10(%r13),%rdx
  7663d4:	mov    %r12,%rdi
  7663d7:	call   *0x353ea3(%rip)        # aba280 <_DYNAMIC+0x240>
  7663dd:	jmp    766419 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xa69>
  7663df:	call   *0x353efb(%rip)        # aba2e0 <_DYNAMIC+0x2a0>
  7663e5:	mov    %rax,%r15
  7663e8:	jmp    766419 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xa69>
  7663ea:	mov    %rax,%r15
  7663ed:	mov    0x20(%rsp),%rdi
  7663f2:	call   747fa0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui7runtime3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEEB1d_>
  7663f7:	jmp    766493 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xae3>
  7663fc:	mov    %rax,%r15
  7663ff:	lea    0xb20(%rsp),%rdi
  766407:	call   74d320 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas6canvas6CanvasECs9C2G9YFESsD_29canonical_text_public_control>
  76640c:	lea    0x88(%rsp),%rdi
  766414:	call   747e50 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui6source7SourcesNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEEB1g_>
  766419:	cmpq   $0x0,0x10(%rsp)
  76641f:	je     766493 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xae3>
  766421:	mov    $0x1,%edx
  766426:	mov    %r14,%rdi
  766429:	mov    0x10(%rsp),%rsi
  76642e:	call   *0x353e4c(%rip)        # aba280 <_DYNAMIC+0x240>
  766434:	mov    %r15,%rdi
  766437:	call   a98730 <_Unwind_Resume@plt>
  76643c:	call   *0x353e66(%rip)        # aba2a8 <_DYNAMIC+0x268>
  766442:	mov    %rax,%r15
  766445:	lea    0x110(%rsp),%rdi
  76644d:	call   74d810 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  766452:	mov    %r15,%rdi
  766455:	call   a98730 <_Unwind_Resume@plt>
  76645a:	jmp    766463 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xab3>
  76645c:	jmp    76645e <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xaae>
  76645e:	mov    %rax,%r15
  766461:	jmp    766473 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xac3>
  766463:	mov    %rax,%r15
  766466:	lea    0x3b0(%rsp),%rdi
  76646e:	call   74d810 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  766473:	mov    %rbx,%rdi
  766476:	call   747fa0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui7runtime3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEEB1d_>
  76647b:	jmp    766493 <_RNvCs9C2G9YFESsD_29canonical_text_public_control5mount+0xae3>
  76647d:	call   *0x353e25(%rip)        # aba2a8 <_DYNAMIC+0x268>
  766483:	mov    %rax,%r15
  766486:	lea    0x3b0(%rsp),%rdi
  76648e:	call   748000 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCslbxve4rcJus_4gpui7runtime7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEEB1h_>
  766493:	mov    %r15,%rdi
  766496:	call   a98730 <_Unwind_Resume@plt>
  76649b:	call   *0x353e07(%rip)        # aba2a8 <_DYNAMIC+0x268>

canonical_text_public_control::source bytes=2078 frame=88

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007664b0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source>:
  7664b0:	push   %r15
  7664b2:	push   %r14
  7664b4:	push   %rbx
  7664b5:	sub    $0x40,%rsp
  7664b9:	mov    %rsi,0x20(%rsp)
  7664be:	mov    %rdx,0x28(%rsp)
  7664c3:	lea    -0x3(%rdx),%rax
  7664c7:	cmp    $0xa,%rax
  7664cb:	ja     766c0a <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x75a>
  7664d1:	mov    %rdi,%rbx
  7664d4:	lea    -0x6a2487(%rip),%rcx        # c4054 <GCC_except_table0+0x1c4c>
  7664db:	movslq (%rcx,%rax,4),%rax
  7664df:	add    %rcx,%rax
  7664e2:	jmp    *%rax
  7664e4:	lea    -0x696a8c(%rip),%rax        # cfa5f <GCC_except_table0+0xd657>
  7664eb:	mov    %rsi,%rdi
  7664ee:	mov    %rax,%rsi
  7664f1:	call   *0x354051(%rip)        # aba548 <bcmp@GLIBC_2.2.5>
  7664f7:	test   %eax,%eax
  7664f9:	jne    766c0a <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x75a>
  7664ff:	call   *0x353d83(%rip)        # aba288 <_DYNAMIC+0x248>
  766505:	mov    $0x1b80,%edi
  76650a:	mov    $0x1,%esi
  76650f:	call   *0x353d7b(%rip)        # aba290 <_DYNAMIC+0x250>
  766515:	test   %rax,%rax
  766518:	je     766c39 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x789>
  76651e:	mov    %rax,%r14
  766521:	movups -0x6968b6(%rip),%xmm0        # cfc72 <GCC_except_table0+0xd86a>
  766528:	movups %xmm0,0x20(%rax)
  76652c:	movabs $0x20aad7a9d7a8d7a7,%rax
  766536:	mov    %rax,0x2f(%r14)
  76653a:	movups -0x6968df(%rip),%xmm1        # cfc62 <GCC_except_table0+0xd85a>
  766541:	movups %xmm1,0x10(%r14)
  766546:	movups -0x6968fb(%rip),%xmm2        # cfc52 <GCC_except_table0+0xd84a>
  76654d:	movups %xmm2,(%r14)
  766551:	movups %xmm2,0x37(%r14)
  766556:	movups %xmm1,0x47(%r14)
  76655b:	movups %xmm0,0x57(%r14)
  766560:	mov    %rax,0x66(%r14)
  766564:	movups %xmm2,0x6e(%r14)
  766569:	movups %xmm1,0x7e(%r14)
  76656e:	movups 0x20(%r14),%xmm0
  766573:	movups %xmm0,0x8e(%r14)
  76657b:	movups 0x30(%r14),%xmm0
  766580:	movups %xmm0,0x9e(%r14)
  766588:	movups 0x40(%r14),%xmm0
  76658d:	movups %xmm0,0xae(%r14)
  766595:	movups 0x50(%r14),%xmm0
  76659a:	movups %xmm0,0xbe(%r14)
  7665a2:	mov    0x5e(%r14),%rax
  7665a6:	mov    %rax,0xcc(%r14)
  7665ad:	mov    0x66(%r14),%rax
  7665b1:	mov    %rax,0xd4(%r14)
  7665b8:	lea    0xdc(%r14),%rdi
  7665bf:	mov    0x353cda(%rip),%r15        # aba2a0 <memcpy@GLIBC_2.14>
  7665c6:	mov    $0xdc,%edx
  7665cb:	mov    %r14,%rsi
  7665ce:	call   *%r15
  7665d1:	lea    0x1b8(%r14),%rdi
  7665d8:	mov    $0x1b8,%edx
  7665dd:	mov    %r14,%rsi
  7665e0:	call   *%r15
  7665e3:	lea    0x370(%r14),%rdi
  7665ea:	mov    $0x370,%edx
  7665ef:	mov    %r14,%rsi
  7665f2:	call   *%r15
  7665f5:	lea    0x6e0(%r14),%rdi
  7665fc:	mov    $0x6e0,%edx
  766601:	mov    %r14,%rsi
  766604:	call   *%r15
  766607:	mov    %r14,%rdi
  76660a:	add    $0xdc0,%rdi
  766611:	mov    $0xdc0,%edx
  766616:	mov    %r14,%rsi
  766619:	call   *%r15
  76661c:	movq   $0x1b80,(%rbx)
  766623:	mov    %r14,0x8(%rbx)
  766627:	movq   $0x1b80,0x10(%rbx)
  76662f:	jmp    766c00 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x750>
  766634:	mov    $0x74706d65,%eax
  766639:	xor    (%rsi),%eax
  76663b:	movzbl 0x4(%rsi),%ecx
  76663f:	xor    $0x79,%ecx
  766642:	or     %eax,%ecx
  766644:	je     766b9d <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x6ed>
  76664a:	mov    $0x6562616c,%eax
  76664f:	xor    (%rsi),%eax
  766651:	movzbl 0x4(%rsi),%ecx
  766655:	xor    $0x6c,%ecx
  766658:	or     %eax,%ecx
  76665a:	je     766bb6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x706>
  766660:	lea    -0x696c05(%rip),%rax        # cfa62 <GCC_except_table0+0xd65a>
  766667:	mov    %rsi,%rdi
  76666a:	mov    %rax,%rsi
  76666d:	call   *0x353ed5(%rip)        # aba548 <bcmp@GLIBC_2.2.5>
  766673:	test   %eax,%eax
  766675:	jne    766c0a <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x75a>
  76667b:	call   *0x353c07(%rip)        # aba288 <_DYNAMIC+0x248>
  766681:	mov    $0x880,%edi
  766686:	mov    $0x1,%esi
  76668b:	call   *0x353bff(%rip)        # aba290 <_DYNAMIC+0x250>
  766691:	test   %rax,%rax
  766694:	je     766c89 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x7d9>
  76669a:	mov    %rax,%r14
  76669d:	movups -0x696a64(%rip),%xmm0        # cfc40 <GCC_except_table0+0xd838>
  7666a4:	movups %xmm0,0x10(%rax)
  7666a8:	movups -0x696a7f(%rip),%xmm1        # cfc30 <GCC_except_table0+0xd828>
  7666af:	movups %xmm1,(%rax)
  7666b2:	movw   $0xa0d,0x20(%rax)
  7666b8:	movups %xmm1,0x22(%rax)
  7666bc:	movups %xmm0,0x32(%rax)
  7666c0:	movw   $0xa0d,0x42(%rax)
  7666c6:	movups %xmm1,0x44(%rax)
  7666ca:	movups %xmm0,0x54(%rax)
  7666ce:	movzwl 0x20(%rax),%eax
  7666d2:	mov    %ax,0x64(%r14)
  7666d7:	mov    0x22(%r14),%rax
  7666db:	mov    %rax,0x66(%r14)
  7666df:	mov    0x2a(%r14),%eax
  7666e3:	mov    %eax,0x6e(%r14)
  7666e7:	movzwl 0x2e(%r14),%eax
  7666ec:	mov    %ax,0x72(%r14)
  7666f1:	movups 0x30(%r14),%xmm0
  7666f6:	movups %xmm0,0x74(%r14)
  7666fb:	mov    0x40(%r14),%eax
  7666ff:	mov    %eax,0x84(%r14)
  766706:	lea    0x88(%r14),%rdi
  76670d:	mov    0x353b8c(%rip),%r15        # aba2a0 <memcpy@GLIBC_2.14>
  766714:	mov    $0x88,%edx
  766719:	mov    %r14,%rsi
  76671c:	call   *%r15
  76671f:	lea    0x110(%r14),%rdi
  766726:	mov    $0x110,%edx
  76672b:	mov    %r14,%rsi
  76672e:	call   *%r15
  766731:	lea    0x220(%r14),%rdi
  766738:	mov    $0x220,%edx
  76673d:	mov    %r14,%rsi
  766740:	call   *%r15
  766743:	mov    %r14,%rdi
  766746:	add    $0x440,%rdi
  76674d:	mov    $0x440,%edx
  766752:	mov    %r14,%rsi
  766755:	call   *%r15
  766758:	movq   $0x880,(%rbx)
  76675f:	mov    %r14,0x8(%rbx)
  766763:	movq   $0x880,0x10(%rbx)
  76676b:	jmp    766c00 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x750>
  766770:	cmpl   $0x796e6974,(%rsi)
  766776:	jne    766c0a <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x75a>
  76677c:	call   *0x353b06(%rip)        # aba288 <_DYNAMIC+0x248>
  766782:	mov    $0x1,%edi
  766787:	mov    $0x1,%esi
  76678c:	call   *0x353afe(%rip)        # aba290 <_DYNAMIC+0x250>
  766792:	test   %rax,%rax
  766795:	je     766c49 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x799>
  76679b:	movb   $0x61,(%rax)
  76679e:	movq   $0x1,(%rbx)
  7667a5:	mov    %rax,0x8(%rbx)
  7667a9:	movq   $0x1,0x10(%rbx)
  7667b1:	jmp    766c00 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x750>
  7667b6:	lea    -0x696d56(%rip),%rax        # cfa67 <GCC_except_table0+0xd65f>
  7667bd:	mov    %rsi,%rdi
  7667c0:	mov    %rax,%rsi
  7667c3:	call   *0x353d7f(%rip)        # aba548 <bcmp@GLIBC_2.2.5>
  7667c9:	test   %eax,%eax
  7667cb:	jne    766c0a <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x75a>
  7667d1:	call   *0x353ab1(%rip)        # aba288 <_DYNAMIC+0x248>
  7667d7:	mov    $0x580,%edi
  7667dc:	mov    $0x1,%esi
  7667e1:	call   *0x353aa9(%rip)        # aba290 <_DYNAMIC+0x250>
  7667e7:	test   %rax,%rax
  7667ea:	je     766c59 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x7a9>
  7667f0:	mov    %rax,%r14
  7667f3:	movabs $0x616c0aa880e20a0d,%rax
  7667fd:	mov    %rax,(%r14)
  766800:	movl   $0xa747361,0x7(%r14)
  766808:	mov    %rax,0xb(%r14)
  76680c:	movl   $0xa747361,0x12(%r14)
  766814:	movups (%r14),%xmm0
  766818:	movups %xmm0,0x16(%r14)
  76681d:	mov    0xe(%r14),%rax
  766821:	mov    %rax,0x24(%r14)
  766825:	movups %xmm0,0x2c(%r14)
  76682a:	movups 0x10(%r14),%xmm1
  76682f:	movups %xmm1,0x3c(%r14)
  766834:	mov    0x1c(%r14),%rax
  766838:	mov    %rax,0x48(%r14)
  76683c:	mov    0x24(%r14),%rax
  766840:	mov    %rax,0x50(%r14)
  766844:	movups %xmm0,0x58(%r14)
  766849:	movups %xmm1,0x68(%r14)
  76684e:	mov    0x20(%r14),%eax
  766852:	mov    %eax,0x78(%r14)
  766856:	mov    0x24(%r14),%rax
  76685a:	mov    %rax,0x7c(%r14)
  76685e:	mov    0x2c(%r14),%eax
  766862:	mov    %eax,0x84(%r14)
  766869:	movups 0x30(%r14),%xmm0
  76686e:	movups %xmm0,0x88(%r14)
  766876:	mov    0x40(%r14),%rax
  76687a:	mov    %rax,0x98(%r14)
  766881:	mov    0x48(%r14),%rax
  766885:	mov    %rax,0xa0(%r14)
  76688c:	mov    0x50(%r14),%rax
  766890:	mov    %rax,0xa8(%r14)
  766897:	lea    0xb0(%r14),%rdi
  76689e:	mov    0x3539fb(%rip),%r15        # aba2a0 <memcpy@GLIBC_2.14>
  7668a5:	mov    $0xb0,%edx
  7668aa:	mov    %r14,%rsi
  7668ad:	call   *%r15
  7668b0:	lea    0x160(%r14),%rdi
  7668b7:	mov    $0x160,%edx
  7668bc:	mov    %r14,%rsi
  7668bf:	call   *%r15
  7668c2:	mov    %r14,%rdi
  7668c5:	add    $0x2c0,%rdi
  7668cc:	mov    $0x2c0,%edx
  7668d1:	mov    %r14,%rsi
  7668d4:	call   *%r15
  7668d7:	movq   $0x580,(%rbx)
  7668de:	mov    %r14,0x8(%rbx)
  7668e2:	movq   $0x580,0x10(%rbx)
  7668ea:	jmp    766c00 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x750>
  7668ef:	movabs $0x3364657070617277,%rax
  7668f9:	xor    (%rsi),%rax
  7668fc:	movzwl 0x8(%rsi),%ecx
  766900:	xor    $0x6b32,%rcx
  766907:	or     %rax,%rcx
  76690a:	jne    766c0a <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x75a>
  766910:	call   *0x353972(%rip)        # aba288 <_DYNAMIC+0x248>
  766916:	mov    $0x8000,%edi
  76691b:	mov    $0x1,%esi
  766920:	call   *0x35396a(%rip)        # aba290 <_DYNAMIC+0x250>
  766926:	test   %rax,%rax
  766929:	je     766c69 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x7b9>
  76692f:	mov    %rax,%r14
  766932:	movabs $0x6161616161616161,%rax
  76693c:	mov    %rax,(%r14)
  76693f:	mov    %rax,0x8(%r14)
  766943:	movups (%r14),%xmm0
  766947:	movups %xmm0,0x10(%r14)
  76694c:	movups %xmm0,0x20(%r14)
  766951:	movups %xmm0,0x30(%r14)
  766956:	movups %xmm0,0x40(%r14)
  76695b:	movups %xmm0,0x50(%r14)
  766960:	movups %xmm0,0x60(%r14)
  766965:	movups %xmm0,0x70(%r14)
  76696a:	movups %xmm0,0xa0(%r14)
  766972:	movups %xmm0,0xe0(%r14)
  76697a:	movups %xmm0,0xb0(%r14)
  766982:	movups %xmm0,0xf0(%r14)
  76698a:	movups %xmm0,0xd0(%r14)
  766992:	movups %xmm0,0xc0(%r14)
  76699a:	movups %xmm0,0x90(%r14)
  7669a2:	movups %xmm0,0x80(%r14)
  7669aa:	lea    0x100(%r14),%rdi
  7669b1:	mov    0x3538e8(%rip),%r15        # aba2a0 <memcpy@GLIBC_2.14>
  7669b8:	mov    $0x100,%edx
  7669bd:	mov    %r14,%rsi
  7669c0:	call   *%r15
  7669c3:	lea    0x200(%r14),%rdi
  7669ca:	mov    $0x200,%edx
  7669cf:	mov    %r14,%rsi
  7669d2:	call   *%r15
  7669d5:	lea    0x400(%r14),%rdi
  7669dc:	mov    $0x400,%edx
  7669e1:	mov    %r14,%rsi
  7669e4:	call   *%r15
  7669e7:	lea    0x800(%r14),%rdi
  7669ee:	mov    $0x800,%edx
  7669f3:	mov    %r14,%rsi
  7669f6:	call   *%r15
  7669f9:	lea    0x1000(%r14),%rdi
  766a00:	mov    $0x1000,%edx
  766a05:	mov    %r14,%rsi
  766a08:	call   *%r15
  766a0b:	lea    0x2000(%r14),%rdi
  766a12:	mov    $0x2000,%edx
  766a17:	mov    %r14,%rsi
  766a1a:	call   *%r15
  766a1d:	mov    %r14,%rdi
  766a20:	add    $0x4000,%rdi
  766a27:	mov    $0x4000,%edx
  766a2c:	mov    %r14,%rsi
  766a2f:	call   *%r15
  766a32:	movq   $0x8000,(%rbx)
  766a39:	mov    %r14,0x8(%rbx)
  766a3d:	movq   $0x8000,0x10(%rbx)
  766a45:	jmp    766c00 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x750>
  766a4a:	lea    -0x696fe1(%rip),%rax        # cfa70 <GCC_except_table0+0xd668>
  766a51:	mov    %rsi,%rdi
  766a54:	mov    %rax,%rsi
  766a57:	call   *0x353aeb(%rip)        # aba548 <bcmp@GLIBC_2.2.5>
  766a5d:	test   %eax,%eax
  766a5f:	jne    766c0a <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x75a>
  766a65:	call   *0x35381d(%rip)        # aba288 <_DYNAMIC+0x248>
  766a6b:	mov    $0x800,%edi
  766a70:	mov    $0x1,%esi
  766a75:	call   *0x353815(%rip)        # aba290 <_DYNAMIC+0x250>
  766a7b:	test   %rax,%rax
  766a7e:	je     766c79 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x7c9>
  766a84:	mov    %rax,%r14
  766a87:	movabs $0x81cc81cc81cc81cc,%rax
  766a91:	mov    %rax,(%r14)
  766a94:	mov    %rax,0x8(%r14)
  766a98:	movups (%r14),%xmm0
  766a9c:	movups %xmm0,0x10(%r14)
  766aa1:	movups %xmm0,0x20(%r14)
  766aa6:	movups %xmm0,0x30(%r14)
  766aab:	movups %xmm0,0x40(%r14)
  766ab0:	movups %xmm0,0x50(%r14)
  766ab5:	movups %xmm0,0x60(%r14)
  766aba:	movups %xmm0,0x70(%r14)
  766abf:	movups %xmm0,0x80(%r14)
  766ac7:	movups %xmm0,0xf0(%r14)
  766acf:	movups %xmm0,0xe0(%r14)
  766ad7:	movups %xmm0,0xd0(%r14)
  766adf:	movups %xmm0,0xc0(%r14)
  766ae7:	movups %xmm0,0xb0(%r14)
  766aef:	movups %xmm0,0xa0(%r14)
  766af7:	movups %xmm0,0x90(%r14)
  766aff:	lea    0x100(%r14),%rdi
  766b06:	mov    0x353793(%rip),%r15        # aba2a0 <memcpy@GLIBC_2.14>
  766b0d:	mov    $0x100,%edx
  766b12:	mov    %r14,%rsi
  766b15:	call   *%r15
  766b18:	lea    0x200(%r14),%rdi
  766b1f:	mov    $0x200,%edx
  766b24:	mov    %r14,%rsi
  766b27:	call   *%r15
  766b2a:	mov    %r14,%rdi
  766b2d:	add    $0x400,%rdi
  766b34:	mov    $0x400,%edx
  766b39:	mov    %r14,%rsi
  766b3c:	call   *%r15
  766b3f:	movq   $0x800,0x8(%rsp)
  766b48:	mov    %r14,0x10(%rsp)
  766b4d:	movq   $0x800,0x18(%rsp)
  766b56:	lea    0x8(%rsp),%rax
  766b5b:	mov    %rax,0x30(%rsp)
  766b60:	lea    0x322a9(%rip),%rax        # 798e10 <_RNvXsq_NtCscdodAO9FK5_5alloc6stringNtB5_6StringNtNtCs4NRVxsYgnAr_4core3fmt7Display3fmt>
  766b67:	mov    %rax,0x38(%rsp)
  766b6c:	lea    -0x6a1982(%rip),%rsi        # c51f1 <GCC_except_table0+0x2de9>
  766b73:	lea    0x30(%rsp),%rdx
  766b78:	mov    %rbx,%rdi
  766b7b:	call   *0x353a37(%rip)        # aba5b8 <_DYNAMIC+0x578>
  766b81:	mov    0x8(%rsp),%rsi
  766b86:	test   %rsi,%rsi
  766b89:	je     766c00 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x750>
  766b8b:	mov    0x10(%rsp),%rdi
  766b90:	mov    $0x1,%edx
  766b95:	call   *0x3536e5(%rip)        # aba280 <_DYNAMIC+0x240>
  766b9b:	jmp    766c00 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x750>
  766b9d:	movq   $0x0,(%rbx)
  766ba4:	movq   $0x1,0x8(%rbx)
  766bac:	movq   $0x0,0x10(%rbx)
  766bb4:	jmp    766c00 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x750>
  766bb6:	call   *0x3536cc(%rip)        # aba288 <_DYNAMIC+0x248>
  766bbc:	mov    $0x17,%edi
  766bc1:	mov    $0x1,%esi
  766bc6:	call   *0x3536c4(%rip)        # aba290 <_DYNAMIC+0x250>
  766bcc:	test   %rax,%rax
  766bcf:	je     766c99 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x7e9>
  766bd5:	movups -0x696f52(%rip),%xmm0        # cfc8a <GCC_except_table0+0xd882>
  766bdc:	movups %xmm0,(%rax)
  766bdf:	movabs $0x92d791d790d72081,%rcx
  766be9:	mov    %rcx,0xf(%rax)
  766bed:	movq   $0x17,(%rbx)
  766bf4:	mov    %rax,0x8(%rbx)
  766bf8:	movq   $0x17,0x10(%rbx)
  766c00:	add    $0x40,%rsp
  766c04:	pop    %rbx
  766c05:	pop    %r14
  766c07:	pop    %r15
  766c09:	ret
  766c0a:	lea    0x20(%rsp),%rax
  766c0f:	mov    %rax,0x8(%rsp)
  766c14:	lea    0x301b5(%rip),%rax        # 796dd0 <_RNvXs1i_NtCs4NRVxsYgnAr_4core3fmtReNtB6_7Display3fmtCs9C2G9YFESsD_29canonical_text_public_control>
  766c1b:	mov    %rax,0x10(%rsp)
  766c20:	lea    -0x69facb(%rip),%rdi        # c715c <GCC_except_table0+0x4d54>
  766c27:	lea    0x3340a2(%rip),%rdx        # a9acd0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x11e8>
  766c2e:	lea    0x8(%rsp),%rsi
  766c33:	call   *0x35367f(%rip)        # aba2b8 <_DYNAMIC+0x278>
  766c39:	mov    $0x1,%edi
  766c3e:	mov    $0x1b80,%esi
  766c43:	call   *0x3536e7(%rip)        # aba330 <_DYNAMIC+0x2f0>
  766c49:	mov    $0x1,%edi
  766c4e:	mov    $0x1,%esi
  766c53:	call   *0x3536d7(%rip)        # aba330 <_DYNAMIC+0x2f0>
  766c59:	mov    $0x1,%edi
  766c5e:	mov    $0x580,%esi
  766c63:	call   *0x3536c7(%rip)        # aba330 <_DYNAMIC+0x2f0>
  766c69:	mov    $0x1,%edi
  766c6e:	mov    $0x8000,%esi
  766c73:	call   *0x3536b7(%rip)        # aba330 <_DYNAMIC+0x2f0>
  766c79:	mov    $0x1,%edi
  766c7e:	mov    $0x800,%esi
  766c83:	call   *0x3536a7(%rip)        # aba330 <_DYNAMIC+0x2f0>
  766c89:	mov    $0x1,%edi
  766c8e:	mov    $0x880,%esi
  766c93:	call   *0x353697(%rip)        # aba330 <_DYNAMIC+0x2f0>
  766c99:	mov    $0x1,%edi
  766c9e:	mov    $0x17,%esi
  766ca3:	call   *0x353687(%rip)        # aba330 <_DYNAMIC+0x2f0>
  766ca9:	mov    %rax,%rbx
  766cac:	mov    0x8(%rsp),%rsi
  766cb1:	test   %rsi,%rsi
  766cb4:	je     766cc6 <_RNvCs9C2G9YFESsD_29canonical_text_public_control6source+0x816>
  766cb6:	mov    0x10(%rsp),%rdi
  766cbb:	mov    $0x1,%edx
  766cc0:	call   *0x3535ba(%rip)        # aba280 <_DYNAMIC+0x240>
  766cc6:	mov    %rbx,%rdi
  766cc9:	call   a98730 <_Unwind_Resume@plt>

canonical_text_public_control::owner_hit bytes=416 frame=264

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000766cd0 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit>:
  766cd0:	push   %rbp
  766cd1:	push   %r15
  766cd3:	push   %r14
  766cd5:	push   %r13
  766cd7:	push   %r12
  766cd9:	push   %rbx
  766cda:	sub    $0xd8,%rsp
  766ce1:	mov    (%rdi),%rsi
  766ce4:	test   %rsi,%rsi
  766ce7:	je     766e13 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit+0x143>
  766ced:	cmpb   $0x0,0x76e(%rsi)
  766cf4:	jne    766e1a <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit+0x14a>
  766cfa:	movss  %xmm0,0x8(%rsp)
  766d00:	movss  %xmm1,0xc(%rsp)
  766d06:	cmpb   $0x1,0x76c(%rsi)
  766d0d:	jne    766e21 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit+0x151>
  766d13:	lea    0x58(%rsp),%rdi
  766d18:	call   73de20 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime5queryNtB3_7Context3newNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEBX_>
  766d1d:	mov    0x90(%rsp),%r13
  766d25:	test   %r13,%r13
  766d28:	je     766df2 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit+0x122>
  766d2e:	movabs $0x100000001b3,%rbp
  766d38:	mov    0x88(%rsp),%rbx
  766d40:	add    $0x3d,%rbx
  766d44:	xor    %eax,%eax
  766d46:	lea    0x58(%rsp),%r14
  766d4b:	xor    %r12d,%r12d
  766d4e:	jmp    766d93 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit+0xc3>
  766d50:	xor    $0x1,%eax
  766d53:	imul   %rbp,%rax
  766d57:	and    $0x1,%dl
  766d5a:	movzbl %dl,%r15d
  766d5e:	xor    %rax,%r15
  766d61:	imul   %rbp,%r15
  766d65:	mov    %r14,%rdi
  766d68:	mov    %r12,%rsi
  766d6b:	movss  0x8(%rsp),%xmm0
  766d71:	movss  0xc(%rsp),%xmm1
  766d77:	call   *0x353843(%rip)        # aba5c0 <_DYNAMIC+0x580>
  766d7d:	movzbl %al,%eax
  766d80:	xor    %r15,%rax
  766d83:	imul   %rbp,%rax
  766d87:	inc    %r12
  766d8a:	add    $0x40,%rbx
  766d8e:	cmp    %r12,%r13
  766d91:	je     766df4 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit+0x124>
  766d93:	cmpb   $0x4,(%rbx)
  766d96:	jne    766d87 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit+0xb7>
  766d98:	lea    0x10(%rsp),%rdi
  766d9d:	mov    %r14,%rsi
  766da0:	mov    %r12,%rdx
  766da3:	call   *0x3536df(%rip)        # aba488 <_DYNAMIC+0x448>
  766da9:	cmpq   $0x0,0x10(%rsp)
  766daf:	je     766e06 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit+0x136>
  766db1:	movups 0x10(%rsp),%xmm0
  766db6:	movups 0x20(%rsp),%xmm1
  766dbb:	movaps %xmm1,0x40(%rsp)
  766dc0:	movaps %xmm0,0x30(%rsp)
  766dc5:	lea    0x30(%rsp),%rdi
  766dca:	movss  0x8(%rsp),%xmm0
  766dd0:	movss  0xc(%rsp),%xmm1
  766dd6:	call   *0x35374c(%rip)        # aba528 <_DYNAMIC+0x4e8>
  766ddc:	cmp    $0x2,%dl
  766ddf:	jne    766d50 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit+0x80>
  766de5:	lea    0x3333b4(%rip),%rdi        # a9a1a0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x6b8>
  766dec:	call   *0x35354e(%rip)        # aba340 <_DYNAMIC+0x300>
  766df2:	xor    %eax,%eax
  766df4:	add    $0xd8,%rsp
  766dfb:	pop    %rbx
  766dfc:	pop    %r12
  766dfe:	pop    %r13
  766e00:	pop    %r14
  766e02:	pop    %r15
  766e04:	pop    %rbp
  766e05:	ret
  766e06:	lea    0x33337b(%rip),%rdi        # a9a188 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x6a0>
  766e0d:	call   *0x35352d(%rip)        # aba340 <_DYNAMIC+0x300>
  766e13:	mov    $0xd,%eax
  766e18:	jmp    766e26 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit+0x156>
  766e1a:	mov    $0xe,%eax
  766e1f:	jmp    766e26 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9owner_hit+0x156>
  766e21:	mov    $0x12,%eax
  766e26:	mov    %rax,0x58(%rsp)
  766e2b:	movq   $0x0,0x60(%rsp)
  766e34:	lea    -0x697191(%rip),%rdi        # cfcaa <GCC_except_table0+0xd8a2>
  766e3b:	lea    0x333eee(%rip),%rcx        # a9ad30 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1248>
  766e42:	lea    0x333e9f(%rip),%r8        # a9ace8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1200>
  766e49:	lea    0x58(%rsp),%rdx
  766e4e:	mov    $0x2b,%esi
  766e53:	call   *0x3534f7(%rip)        # aba350 <_DYNAMIC+0x310>
  766e59:	ud2
  766e5b:	mov    %rax,%rbx
  766e5e:	lea    0x58(%rsp),%rdi
  766e63:	call   74d810 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  766e68:	mov    %rbx,%rdi
  766e6b:	call   a98730 <_Unwind_Resume@plt>

canonical_text_public_control::query_hit bytes=181 frame=88

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000766e70 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9query_hit>:
  766e70:	push   %r15
  766e72:	push   %r14
  766e74:	push   %rbx
  766e75:	sub    $0x40,%rsp
  766e79:	mov    %rdi,%r14
  766e7c:	movss  %xmm0,(%rsp)
  766e81:	movss  %xmm1,0x4(%rsp)
  766e87:	call   *0x35373b(%rip)        # aba5c8 <_DYNAMIC+0x588>
  766e8d:	cmp    $0x2,%dl
  766e90:	je     766f18 <_RNvCs9C2G9YFESsD_29canonical_text_public_control9query_hit+0xa8>
  766e96:	movabs $0x100000001b3,%r15
  766ea0:	xor    $0x1,%eax
  766ea3:	imul   %r15,%rax
  766ea7:	and    $0x1,%dl
  766eaa:	movzbl %dl,%ebx
  766ead:	xor    %rax,%rbx
  766eb0:	imul   %r15,%rbx
  766eb4:	lea    0x8(%rsp),%rdi
  766eb9:	mov    %r14,%rsi
  766ebc:	movss  (%rsp),%xmm0
  766ec1:	movss  0x4(%rsp),%xmm1
  766ec7:	call   *0x353703(%rip)        # aba5d0 <_DYNAMIC+0x590>
  766ecd:	cmpb   $0x2,0xc(%rsp)
  766ed2:	je     766f0b <_RNvCs9C2G9YFESsD_29canonical_text_public_control9query_hit+0x9b>
  766ed4:	mov    0x8(%rsp),%eax
  766ed8:	mov    0x18(%rsp),%ecx
  766edc:	mov    0x1c(%rsp),%edx
  766ee0:	mov    0x20(%rsp),%esi
  766ee4:	mov    0x24(%rsp),%edi
  766ee8:	xor    %rax,%rbx
  766eeb:	imul   %r15,%rbx
  766eef:	xor    %rcx,%rbx
  766ef2:	imul   %r15,%rbx
  766ef6:	xor    %rdx,%rbx
  766ef9:	imul   %r15,%rbx
  766efd:	xor    %rsi,%rbx
  766f00:	imul   %r15,%rbx
  766f04:	xor    %rdi,%rbx
  766f07:	imul   %r15,%rbx
  766f0b:	mov    %rbx,%rax
  766f0e:	add    $0x40,%rsp
  766f12:	pop    %rbx
  766f13:	pop    %r14
  766f15:	pop    %r15
  766f17:	ret
  766f18:	lea    0x333de1(%rip),%rdi        # a9ad00 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1218>
  766f1f:	call   *0x35341b(%rip)        # aba340 <_DYNAMIC+0x300>

<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::interaction_layout bytes=1471 frame=280

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000076be30 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_>:
  76be30:	push   %rbp
  76be31:	push   %r15
  76be33:	push   %r14
  76be35:	push   %r13
  76be37:	push   %r12
  76be39:	push   %rbx
  76be3a:	sub    $0xe8,%rsp
  76be41:	mov    %rdx,%r14
  76be44:	mov    %rsi,%r15
  76be47:	mov    0x2e0(%rsi),%rsi
  76be4e:	cmp    %rsi,%rdx
  76be51:	jae    76c34b <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x51b>
  76be57:	mov    0x2d8(%r15),%rax
  76be5e:	lea    (%r14,%r14,4),%rcx
  76be62:	mov    0x20(%rax,%rcx,8),%ebx
  76be66:	mov    %ebx,%eax
  76be68:	and    $0xf,%eax
  76be6b:	cmp    $0x9,%eax
  76be6e:	ja     76c332 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x502>
  76be74:	mov    %rdi,%r12
  76be77:	cmp    $0x6,%eax
  76be7a:	je     76c26e <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x43e>
  76be80:	shr    $0x4,%ebx
  76be83:	lea    0x2f0(%r15),%r13
  76be8a:	lea    0x2f8(%r15),%rax
  76be91:	sub    $0x1,%ebx
  76be94:	mov    %rax,0x28(%rsp)
  76be99:	jae    76bf0c <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0xdc>
  76be9b:	mov    $0xffffffff,%ebx
  76bea0:	mov    $0x1,%bpl
  76bea3:	mov    0x5a8(%r15),%rsi
  76beaa:	cmp    %rsi,%r14
  76bead:	jae    76c091 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x261>
  76beb3:	mov    0x5a0(%r15),%rax
  76beba:	lea    0x300(%r15),%rsi
  76bec1:	mov    %r14,%rcx
  76bec4:	shl    $0x4,%rcx
  76bec8:	movups (%rax,%rcx,1),%xmm0
  76becc:	movaps %xmm0,0x40(%rsp)
  76bed1:	lea    0x80(%rsp),%rdi
  76bed9:	lea    0x40(%rsp),%rdx
  76bede:	call   *0x34e53c(%rip)        # aba420 <_DYNAMIC+0x3e0>
  76bee4:	cmpb   $0x0,0x80(%rsp)
  76beec:	je     76bfa2 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x172>
  76bef2:	movzbl 0x81(%rsp),%eax
  76befa:	movq   $0x22,(%r12)
  76bf02:	mov    %al,0x8(%r12)
  76bf07:	jmp    76c25c <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x42c>
  76bf0c:	mov    %r13,0x10(%rsp)
  76bf11:	mov    %r12,0x18(%rsp)
  76bf16:	mov    0x2f8(%r15),%r13
  76bf1d:	mov    %ebx,%edi
  76bf1f:	cmp    %rdi,%r13
  76bf22:	jbe    76c35b <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x52b>
  76bf28:	mov    0x2f0(%r15),%rbp
  76bf2f:	lea    (%rdi,%rdi,4),%r12
  76bf33:	shl    $0x4,%r12
  76bf37:	mov    0x0(%rbp,%r12,1),%rax
  76bf3c:	cmp    $0xffffffffffffffff,%rax
  76bf40:	je     76c073 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x243>
  76bf46:	cmp    $0xfffffffffffffffe,%rax
  76bf4a:	je     76c29f <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x46f>
  76bf50:	mov    %rdi,0x20(%rsp)
  76bf55:	lea    0x40(%rsp),%rdi
  76bf5a:	xor    %esi,%esi
  76bf5c:	call   *0x34e75e(%rip)        # aba6c0 <_DYNAMIC+0x680>
  76bf62:	cmpl   $0xfffffffe,0x40(%rsp)
  76bf67:	jne    76c2d4 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x4a4>
  76bf6d:	add    %r12,%rbp
  76bf70:	mov    0x48(%rsp),%edx
  76bf74:	movzbl 0x4c(%rsp),%ecx
  76bf79:	lea    0x80(%rsp),%rdi
  76bf81:	mov    %rbp,%rsi
  76bf84:	call   *0x34e73e(%rip)        # aba6c8 <_DYNAMIC+0x688>
  76bf8a:	cmpb   $0x0,0x80(%rsp)
  76bf92:	je     76c073 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x243>
  76bf98:	mov    0x18(%rsp),%r12
  76bf9d:	jmp    76c1c6 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x396>
  76bfa2:	mov    0x6e8(%r15),%rax
  76bfa9:	test   %rax,%rax
  76bfac:	je     76c286 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x456>
  76bfb2:	mov    0x30(%rax),%rax
  76bfb6:	test   %rax,%rax
  76bfb9:	je     76c286 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x456>
  76bfbf:	movss  0xcc(%rsp),%xmm1
  76bfc8:	subss  0xa4(%rsp),%xmm1
  76bfd1:	subss  0xa8(%rsp),%xmm1
  76bfda:	subss  0x94(%rsp),%xmm1
  76bfe3:	subss  0x98(%rsp),%xmm1
  76bfec:	subss  0xd4(%rsp),%xmm1
  76bff5:	lock incq (%rax)
  76bff9:	jle    76c39f <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x56f>
  76bfff:	mov    %rax,0x8(%rsp)
  76c004:	test   %bpl,%bpl
  76c007:	jne    76c2ac <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x47c>
  76c00d:	mov    0x28(%rsp),%rbp
  76c012:	mov    0x0(%rbp),%rsi
  76c016:	mov    %ebx,%edi
  76c018:	cmp    %rdi,%rsi
  76c01b:	jbe    76c36b <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x53b>
  76c021:	mov    0x0(%r13),%rsi
  76c025:	lea    (%rdi,%rdi,4),%rbx
  76c029:	shl    $0x4,%rbx
  76c02d:	cmpq   $0xfffffffffffffffe,(%rsi,%rbx,1)
  76c032:	je     76c2b5 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x485>
  76c038:	lea    0x8(%rsp),%rax
  76c03d:	mov    %rax,0x30(%rsp)
  76c042:	movq   $0x0,0x38(%rsp)
  76c04b:	mov    0x200(%r15),%rax
  76c052:	lea    -0x6a7f81(%rip),%rcx        # c40d8 <GCC_except_table0+0x1cd0>
  76c059:	movslq (%rcx,%rax,4),%rax
  76c05d:	add    %rcx,%rax
  76c060:	mov    %rdi,0x20(%rsp)
  76c065:	jmp    *%rax
  76c067:	lea    -0x6a7bd2(%rip),%rax        # c449c <GCC_except_table0+0x2094>
  76c06e:	jmp    76c124 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x2f4>
  76c073:	xor    %ebp,%ebp
  76c075:	mov    0x18(%rsp),%r12
  76c07a:	lea    0x2f0(%r15),%r13
  76c081:	mov    0x5a8(%r15),%rsi
  76c088:	cmp    %rsi,%r14
  76c08b:	jb     76beb3 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x83>
  76c091:	lea    0x32eff8(%rip),%rdx        # a9b090 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x15a8>
  76c098:	mov    %r14,%rdi
  76c09b:	call   *0x34e20f(%rip)        # aba2b0 <_DYNAMIC+0x270>
  76c0a1:	mov    0x220(%r15),%rax
  76c0a8:	cmp    %rax,%r14
  76c0ab:	jae    76c37a <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x54a>
  76c0b1:	mov    0x210(%r15),%rax
  76c0b8:	mov    0x218(%r15),%rcx
  76c0bf:	movzbl (%rcx,%r14,1),%r14d
  76c0c4:	cmp    %r14,%rax
  76c0c7:	jbe    76c38c <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x55c>
  76c0cd:	imul   $0x58,%r14,%rax
  76c0d1:	add    0x208(%r15),%rax
  76c0d8:	jmp    76c124 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x2f4>
  76c0da:	mov    0x208(%r15),%rax
  76c0e1:	lea    0x80(%rsp),%rdi
  76c0e9:	mov    %rsi,%r15
  76c0ec:	mov    %rax,%rsi
  76c0ef:	mov    %r14,%rdx
  76c0f2:	movss  %xmm1,0x10(%rsp)
  76c0f8:	call   *0x34e332(%rip)        # aba430 <_DYNAMIC+0x3f0>
  76c0fe:	movss  0x10(%rsp),%xmm1
  76c104:	mov    %r15,%rsi
  76c107:	jmp    76c16b <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x33b>
  76c109:	mov    0x218(%r15),%rax
  76c110:	cmp    %rax,%r14
  76c113:	jae    76c383 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x553>
  76c119:	imul   $0x58,%r14,%rax
  76c11d:	add    0x210(%r15),%rax
  76c124:	mov    0x50(%rax),%rcx
  76c128:	mov    %rcx,0xd0(%rsp)
  76c130:	movups 0x40(%rax),%xmm0
  76c134:	movaps %xmm0,0xc0(%rsp)
  76c13c:	movups (%rax),%xmm0
  76c13f:	movups 0x10(%rax),%xmm4
  76c143:	movups 0x20(%rax),%xmm2
  76c147:	movups 0x30(%rax),%xmm3
  76c14b:	movaps %xmm3,0xb0(%rsp)
  76c153:	movaps %xmm2,0xa0(%rsp)
  76c15b:	movaps %xmm4,0x90(%rsp)
  76c163:	movaps %xmm0,0x80(%rsp)
  76c16b:	add    %rbx,%rsi
  76c16e:	movss  0x98(%rsp),%xmm0
  76c177:	lea    0x40(%rsp),%rdi
  76c17c:	lea    0x30(%rsp),%rdx
  76c181:	mov    $0x1,%ecx
  76c186:	mov    $0x1,%r8d
  76c18c:	call   *0x34e32e(%rip)        # aba4c0 <_DYNAMIC+0x480>
  76c192:	mov    0x40(%rsp),%rax
  76c197:	cmp    $0xfffffffffffffffe,%rax
  76c19b:	jne    76c20e <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x3de>
  76c19d:	mov    0x38(%rsp),%rdi
  76c1a2:	call   74cd80 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text10TextShaperECs9C2G9YFESsD_29canonical_text_public_control>
  76c1a7:	mov    %r13,0x10(%rsp)
  76c1ac:	mov    0x8(%rsp),%rax
  76c1b1:	lock decq (%rax)
  76c1b5:	jne    76c1c2 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x392>
  76c1b7:	lea    0x8(%rsp),%rdi
  76c1bc:	call   *0x34e1ae(%rip)        # aba370 <_DYNAMIC+0x330>
  76c1c2:	mov    0x0(%rbp),%r13
  76c1c6:	mov    0x20(%rsp),%rdi
  76c1cb:	cmp    %rdi,%r13
  76c1ce:	jbe    76c35b <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x52b>
  76c1d4:	mov    0x10(%rsp),%rax
  76c1d9:	mov    (%rax),%rax
  76c1dc:	lea    (%rdi,%rdi,4),%rcx
  76c1e0:	shl    $0x4,%rcx
  76c1e4:	mov    (%rax,%rcx,1),%rdx
  76c1e8:	cmp    $0xfffffffffffffffe,%rdx
  76c1ec:	je     76c29f <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x46f>
  76c1f2:	cmp    $0xffffffffffffffff,%rdx
  76c1f6:	je     76c2c7 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x497>
  76c1fc:	add    %rcx,%rax
  76c1ff:	mov    %rax,0x8(%r12)
  76c204:	movq   $0xfffffffffffffffe,(%r12)
  76c20c:	jmp    76c25c <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x42c>
  76c20e:	mov    0x48(%rsp),%rcx
  76c213:	mov    0x70(%rsp),%rdx
  76c218:	mov    %rdx,0x30(%r12)
  76c21d:	movups 0x60(%rsp),%xmm0
  76c222:	movups %xmm0,0x20(%r12)
  76c228:	movups 0x50(%rsp),%xmm0
  76c22d:	movups %xmm0,0x10(%r12)
  76c233:	mov    %rax,(%r12)
  76c237:	mov    %rcx,0x8(%r12)
  76c23c:	mov    0x38(%rsp),%rdi
  76c241:	call   74cd80 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text10TextShaperECs9C2G9YFESsD_29canonical_text_public_control>
  76c246:	mov    0x8(%rsp),%rax
  76c24b:	lock decq (%rax)
  76c24f:	jne    76c25c <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x42c>
  76c251:	lea    0x8(%rsp),%rdi
  76c256:	call   *0x34e114(%rip)        # aba370 <_DYNAMIC+0x330>
  76c25c:	add    $0xe8,%rsp
  76c263:	pop    %rbx
  76c264:	pop    %r12
  76c266:	pop    %r13
  76c268:	pop    %r14
  76c26a:	pop    %r15
  76c26c:	pop    %rbp
  76c26d:	ret
  76c26e:	lea    0x2f0(%r15),%r13
  76c275:	lea    0x2f8(%r15),%rax
  76c27c:	mov    %rax,0x28(%rsp)
  76c281:	jmp    76be9b <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x6b>
  76c286:	lea    -0x699ba9(%rip),%rdi        # d26e4 <GCC_except_table0+0x102dc>
  76c28d:	lea    0x32ee14(%rip),%rdx        # a9b0a8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x15c0>
  76c294:	mov    $0x2c,%esi
  76c299:	call   *0x34e0b9(%rip)        # aba358 <_DYNAMIC+0x318>
  76c29f:	lea    0x32e062(%rip),%rdi        # a9a308 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x820>
  76c2a6:	call   *0x34e094(%rip)        # aba340 <_DYNAMIC+0x300>
  76c2ac:	lea    0x32ee0d(%rip),%rdi        # a9b0c0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x15d8>
  76c2b3:	jmp    76c2bc <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x48c>
  76c2b5:	lea    0x32e07c(%rip),%rdi        # a9a338 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x850>
  76c2bc:	call   *0x34e07e(%rip)        # aba340 <_DYNAMIC+0x300>
  76c2c2:	jmp    76c39f <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x56f>
  76c2c7:	lea    0x32ee0a(%rip),%rdi        # a9b0d8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x15f0>
  76c2ce:	call   *0x34e06c(%rip)        # aba340 <_DYNAMIC+0x300>
  76c2d4:	mov    0x70(%rsp),%rax
  76c2d9:	mov    %rax,0xb0(%rsp)
  76c2e1:	movups 0x40(%rsp),%xmm0
  76c2e6:	movups 0x50(%rsp),%xmm1
  76c2eb:	movups 0x60(%rsp),%xmm2
  76c2f0:	movaps %xmm2,0xa0(%rsp)
  76c2f8:	movaps %xmm1,0x90(%rsp)
  76c300:	movaps %xmm0,0x80(%rsp)
  76c308:	lea    -0x69c665(%rip),%rdi        # cfcaa <GCC_except_table0+0xd8a2>
  76c30f:	lea    0x32ea1a(%rip),%rcx        # a9ad30 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1248>
  76c316:	lea    0x32ed5b(%rip),%r8        # a9b078 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1590>
  76c31d:	lea    0x80(%rsp),%rdx
  76c325:	mov    $0x2b,%esi
  76c32a:	call   *0x34e020(%rip)        # aba350 <_DYNAMIC+0x310>
  76c330:	jmp    76c39f <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x56f>
  76c332:	lea    -0x6999a9(%rip),%rdi        # d2990 <GCC_except_table0+0x10588>
  76c339:	lea    0x32f280(%rip),%rdx        # a9b5c0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1ad8>
  76c340:	mov    $0x83,%esi
  76c345:	call   *0x34df6d(%rip)        # aba2b8 <_DYNAMIC+0x278>
  76c34b:	lea    0x32ed0e(%rip),%rdx        # a9b060 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1578>
  76c352:	mov    %r14,%rdi
  76c355:	call   *0x34df55(%rip)        # aba2b0 <_DYNAMIC+0x270>
  76c35b:	lea    0x32df8e(%rip),%rdx        # a9a2f0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x808>
  76c362:	mov    %r13,%rsi
  76c365:	call   *0x34df45(%rip)        # aba2b0 <_DYNAMIC+0x270>
  76c36b:	lea    0x32dfae(%rip),%rdx        # a9a320 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x838>
  76c372:	call   *0x34df38(%rip)        # aba2b0 <_DYNAMIC+0x270>
  76c378:	jmp    76c39f <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x56f>
  76c37a:	lea    0x32eb6f(%rip),%rdx        # a9aef0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1408>
  76c381:	jmp    76c393 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x563>
  76c383:	lea    0x32eb4e(%rip),%rdx        # a9aed8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x13f0>
  76c38a:	jmp    76c393 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x563>
  76c38c:	lea    0x32eb75(%rip),%rdx        # a9af08 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1420>
  76c393:	mov    %r14,%rdi
  76c396:	mov    %rax,%rsi
  76c399:	call   *0x34df11(%rip)        # aba2b0 <_DYNAMIC+0x270>
  76c39f:	ud2
  76c3a1:	mov    %rax,%rbx
  76c3a4:	mov    0x38(%rsp),%rdi
  76c3a9:	call   74cd80 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text10TextShaperECs9C2G9YFESsD_29canonical_text_public_control>
  76c3ae:	jmp    76c3cb <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x59b>
  76c3b0:	mov    %rax,%rbx
  76c3b3:	lea    0x80(%rsp),%rdi
  76c3bb:	call   74d810 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  76c3c0:	mov    %rbx,%rdi
  76c3c3:	call   a98730 <_Unwind_Resume@plt>
  76c3c8:	mov    %rax,%rbx
  76c3cb:	mov    0x8(%rsp),%rax
  76c3d0:	lock decq (%rax)
  76c3d4:	jne    76c3e1 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE18interaction_layoutBY_+0x5b1>
  76c3d6:	lea    0x8(%rsp),%rdi
  76c3db:	call   *0x34df8f(%rip)        # aba370 <_DYNAMIC+0x330>
  76c3e1:	mov    %rbx,%rdi
  76c3e4:	call   a98730 <_Unwind_Resume@plt>
  76c3e9:	call   *0x34deb9(%rip)        # aba2a8 <_DYNAMIC+0x268>

<gpui::runtime::Win<canonical_text_public_control::Editor>>::pointer_event bytes=3204 frame=296

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000076dab0 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_>:
  76dab0:	push   %rbp
  76dab1:	push   %r15
  76dab3:	push   %r14
  76dab5:	push   %r13
  76dab7:	push   %r12
  76dab9:	push   %rbx
  76daba:	sub    $0xf8,%rsp
  76dac1:	mov    %rdx,%r14
  76dac4:	mov    %rdi,%rbx
  76dac7:	mov    (%rcx),%ebp
  76dac9:	test   %ebp,%ebp
  76dacb:	je     76db00 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x50>
  76dacd:	mov    0x8(%r14),%r12
  76dad1:	mov    0x10(%r14),%r13
  76dad5:	mov    0x18(%r14),%rax
  76dad9:	movq   $0x0,0x8(%r14)
  76dae1:	lea    -0x1(%rbp),%edx
  76dae4:	lea    -0x6a9a03(%rip),%rdi        # c40e8 <GCC_except_table0+0x1ce0>
  76daeb:	movslq (%rdi,%rdx,4),%rdx
  76daef:	add    %rdi,%rdx
  76daf2:	jmp    *%rdx
  76daf4:	movl   $0xffffffff,(%r14)
  76dafb:	jmp    76dcc1 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x211>
  76db00:	movd   0x4(%rcx),%xmm1
  76db05:	movd   0x8(%rcx),%xmm0
  76db0a:	movd   %xmm1,%eax
  76db0e:	movd   %xmm0,%ecx
  76db12:	mov    %eax,%edx
  76db14:	and    $0x7fffffff,%edx
  76db1a:	cmp    $0x7f800000,%edx
  76db20:	setge  %dl
  76db23:	and    $0x7fffffff,%ecx
  76db29:	cmp    $0x7f800000,%ecx
  76db2f:	setge  %cl
  76db32:	or     %dl,%cl
  76db34:	je     76db4d <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x9d>
  76db36:	movl   $0xffffffff,(%r14)
  76db3d:	movq   $0x0,0x8(%r14)
  76db45:	xor    %r12d,%r12d
  76db48:	jmp    76dcc1 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x211>
  76db4d:	inc    %eax
  76db4f:	je     76e6b9 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xc09>
  76db55:	mov    %eax,(%r14)
  76db58:	movd   %xmm0,0x4(%r14)
  76db5e:	xor    %r12d,%r12d
  76db61:	jmp    76dcc1 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x211>
  76db66:	mov    (%r14),%r15d
  76db69:	cmp    $0xffffffff,%r15d
  76db6d:	je     76dcc1 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x211>
  76db73:	mov    %rsi,%r13
  76db76:	movups 0x8(%rcx),%xmm0
  76db7a:	movss  0x4(%r14),%xmm1
  76db80:	movss  %xmm1,0x58(%rsp)
  76db86:	movaps %xmm0,%xmm1
  76db89:	unpckhpd %xmm0,%xmm1
  76db8d:	lea    0x10(%rsp),%rdi
  76db92:	movaps %xmm0,0x60(%rsp)
  76db97:	call   *0x34cb33(%rip)        # aba6d0 <_DYNAMIC+0x690>
  76db9d:	cmpl   $0xfffffffe,0x10(%rsp)
  76dba2:	jne    76df1e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x46e>
  76dba8:	mov    0x0(%r13),%r14
  76dbac:	test   %r14,%r14
  76dbaf:	je     76dcf3 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x243>
  76dbb5:	cmpb   $0x1,0x76e(%r14)
  76dbbd:	je     76dce7 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x237>
  76dbc3:	cmpb   $0x1,0x76a(%r14)
  76dbcb:	jne    76e0ae <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76dbd1:	cmpb   $0x0,0x76b(%r14)
  76dbd9:	jne    76e0ae <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76dbdf:	cmpb   $0x0,0x76c(%r14)
  76dbe7:	je     76e0ae <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76dbed:	cmpq   $0xffffffffffffffff,0x5c8(%r14)
  76dbf5:	jne    76e0ae <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76dbfb:	mov    0x6a0(%r14),%rax
  76dc02:	cmp    0x6a8(%r14),%rax
  76dc09:	jne    76e0ae <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76dc0f:	mov    0x6c0(%r14),%rax
  76dc16:	cmp    %rax,0x6c8(%r14)
  76dc1d:	jne    76e0ae <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76dc23:	movss  0x760(%r14),%xmm0
  76dc2c:	ucomiss 0x764(%r14),%xmm0
  76dc34:	jne    76e0ae <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76dc3a:	jp     76e0ae <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76dc40:	mov    %eax,%ecx
  76dc42:	cvtsi2ss %rcx,%xmm2
  76dc47:	dec    %r15d
  76dc4a:	shr    $0x20,%rax
  76dc4e:	mov    %eax,%eax
  76dc50:	xorps  %xmm1,%xmm1
  76dc53:	cvtsi2ss %rax,%xmm1
  76dc58:	movd   %r15d,%xmm0
  76dc5d:	movq   $0x0,0x10(%rsp)
  76dc66:	movss  %xmm2,0x18(%rsp)
  76dc6c:	movss  %xmm1,0x1c(%rsp)
  76dc72:	lea    0x10(%rsp),%rdi
  76dc77:	movd   %xmm0,0x54(%rsp)
  76dc7d:	movss  0x58(%rsp),%xmm1
  76dc83:	call   *0x34ca4f(%rip)        # aba6d8 <_DYNAMIC+0x698>
  76dc89:	test   %al,%al
  76dc8b:	je     76e6ad <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xbfd>
  76dc91:	mov    0x650(%r14),%rax
  76dc98:	test   %rax,%rax
  76dc9b:	je     76e4e3 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xa33>
  76dca1:	mov    0x100(%rax),%rsi
  76dca8:	test   %rsi,%rsi
  76dcab:	je     76e4e3 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xa33>
  76dcb1:	lea    0x70(%rsp),%rdi
  76dcb6:	call   *0x34c62c(%rip)        # aba2e8 <_DYNAMIC+0x2a8>
  76dcbc:	jmp    76e4f6 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xa46>
  76dcc1:	mov    (%rsi),%r15
  76dcc4:	test   %r15,%r15
  76dcc7:	je     76dcf3 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x243>
  76dcc9:	add    $0x8,%rsi
  76dccd:	mov    %r15,0xb0(%rsp)
  76dcd5:	mov    %rsi,0xb8(%rsp)
  76dcdd:	cmpb   $0x1,0x76e(%r15)
  76dce5:	jne    76dd07 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x257>
  76dce7:	movq   $0xe,(%rbx)
  76dcee:	jmp    76e0b5 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76dcf3:	movq   $0xd,(%rbx)
  76dcfa:	movq   $0x0,0x8(%rbx)
  76dd02:	jmp    76e0b5 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76dd07:	movq   $0x0,0x758(%r15)
  76dd12:	cmp    $0x3,%ebp
  76dd15:	je     76dee8 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x438>
  76dd1b:	cmp    $0x2,%ebp
  76dd1e:	je     76de34 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x384>
  76dd24:	test   %ebp,%ebp
  76dd26:	jne    76df61 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4b1>
  76dd2c:	mov    0x650(%r15),%rax
  76dd33:	test   %rax,%rax
  76dd36:	je     76dd4e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x29e>
  76dd38:	mov    0xd8(%rax),%rax
  76dd3f:	test   %rax,%rax
  76dd42:	je     76dd4e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x29e>
  76dd44:	cmpb   $0x0,0x12(%rax)
  76dd48:	jne    76df61 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4b1>
  76dd4e:	mov    0x8(%r14),%r12
  76dd52:	test   %r12,%r12
  76dd55:	je     76df61 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4b1>
  76dd5b:	cmp    0x5f0(%r15),%r12
  76dd62:	jne    76df46 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x496>
  76dd68:	mov    0x10(%r14),%r13
  76dd6c:	lea    0x70(%rsp),%rdi
  76dd71:	mov    %r15,%rsi
  76dd74:	mov    %r13,%rdx
  76dd77:	call   78d320 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE16resolve_identityBO_>
  76dd7c:	cmpq   $0xfffffffffffffffe,0x70(%rsp)
  76dd82:	jne    76df4f <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x49f>
  76dd88:	mov    0x78(%rsp),%rdi
  76dd8d:	mov    0x2e0(%r15),%rsi
  76dd94:	cmp    %rsi,%rdi
  76dd97:	jae    76e6d2 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xc22>
  76dd9d:	mov    0x2d8(%r15),%rax
  76dda4:	lea    (%rdi,%rdi,4),%rcx
  76dda8:	mov    0x20(%rax,%rcx,8),%edi
  76ddac:	call   776700 <_RNvMsh_NtCslbxve4rcJus_4gpui7runtimeNtB5_4Node4kind>
  76ddb1:	cmp    $0x4,%al
  76ddb3:	jne    76e0c7 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x617>
  76ddb9:	mov    (%r14),%eax
  76ddbc:	cmp    $0xffffffff,%eax
  76ddbf:	je     76e6e1 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xc31>
  76ddc5:	movd   0x4(%r14),%xmm1
  76ddcb:	dec    %eax
  76ddcd:	movd   %eax,%xmm0
  76ddd1:	lea    0x10(%rsp),%rdi
  76ddd6:	mov    %r15,%rsi
  76ddd9:	mov    %r12,%rdx
  76dddc:	mov    %r13,%rcx
  76dddf:	mov    $0x1,%r8d
  76dde5:	call   770930 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE14select_pointerB12_>
  76ddea:	mov    0x10(%rsp),%rax
  76ddef:	cmp    $0xfffffffffffffffe,%rax
  76ddf3:	je     76de02 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x352>
  76ddf5:	cmp    $0x11,%eax
  76ddf8:	jne    76de02 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x352>
  76ddfa:	movq   $0x0,0x8(%r14)
  76de02:	mov    0x40(%rsp),%rax
  76de07:	mov    %rax,0x30(%rbx)
  76de0b:	movups 0x10(%rsp),%xmm0
  76de10:	movups 0x20(%rsp),%xmm1
  76de15:	movups 0x30(%rsp),%xmm2
  76de1a:	movups %xmm2,0x20(%rbx)
  76de1e:	movups %xmm1,0x10(%rbx)
  76de22:	movups %xmm0,(%rbx)
  76de25:	lea    0x70(%rsp),%rdi
  76de2a:	call   746480 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultNtNtCslbxve4rcJus_4gpui7runtime6CommitNtBZ_5ErrorEECs9C2G9YFESsD_29canonical_text_public_control>
  76de2f:	jmp    76e0b5 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76de34:	test   %r12,%r12
  76de37:	sete   %cl
  76de3a:	cmpb   $0x1,0x76a(%r15)
  76de42:	jne    76e0ae <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76de48:	cmpb   $0x0,0x76b(%r15)
  76de50:	jne    76e0ae <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76de56:	cmpb   $0x0,0x76c(%r15)
  76de5e:	je     76e0ae <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76de64:	cmpq   $0xffffffffffffffff,0x5c8(%r15)
  76de6c:	jne    76e0ae <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76de72:	mov    0x6a0(%r15),%rax
  76de79:	cmp    0x6a8(%r15),%rax
  76de80:	jne    76e0ae <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76de86:	mov    0x6c8(%r15),%rax
  76de8d:	cmp    0x6c0(%r15),%rax
  76de94:	jne    76e0ae <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76de9a:	movss  0x760(%r15),%xmm0
  76dea3:	ucomiss 0x764(%r15),%xmm0
  76deab:	jne    76e0ae <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76deb1:	jp     76e0ae <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76deb7:	mov    (%r14),%eax
  76deba:	cmp    $0xffffffff,%eax
  76debd:	mov    %rax,0x58(%rsp)
  76dec2:	mov    %ecx,0x54(%rsp)
  76dec6:	je     76e0d6 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x626>
  76decc:	movss  0x4(%r14),%xmm0
  76ded2:	dec    %eax
  76ded4:	mov    %eax,0x14(%rsp)
  76ded8:	movss  %xmm0,0x18(%rsp)
  76dede:	mov    $0x1,%eax
  76dee3:	jmp    76e0d8 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x628>
  76dee8:	test   %r12,%r12
  76deeb:	je     76df61 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4b1>
  76deed:	mov    (%r14),%ecx
  76def0:	cmp    $0xffffffff,%ecx
  76def3:	mov    %rcx,0x58(%rsp)
  76def8:	je     76dfbf <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x50f>
  76defe:	movss  0x4(%r14),%xmm1
  76df04:	dec    %ecx
  76df06:	mov    %ecx,0x74(%rsp)
  76df0a:	movss  %xmm1,0x78(%rsp)
  76df10:	movd   %ecx,%xmm0
  76df14:	mov    $0x1,%ecx
  76df19:	jmp    76dfc1 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x511>
  76df1e:	mov    0x40(%rsp),%rax
  76df23:	mov    %rax,0x30(%rbx)
  76df27:	movups 0x10(%rsp),%xmm0
  76df2c:	movups 0x20(%rsp),%xmm1
  76df31:	movups 0x30(%rsp),%xmm2
  76df36:	movups %xmm2,0x20(%rbx)
  76df3a:	movups %xmm1,0x10(%rbx)
  76df3e:	movups %xmm0,(%rbx)
  76df41:	jmp    76e0b5 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76df46:	movq   $0x11,0x70(%rsp)
  76df4f:	lea    0x70(%rsp),%rdi
  76df54:	call   746480 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultNtNtCslbxve4rcJus_4gpui7runtime6CommitNtBZ_5ErrorEECs9C2G9YFESsD_29canonical_text_public_control>
  76df59:	movq   $0x0,0x8(%r14)
  76df61:	movups 0x6a0(%r15),%xmm0
  76df69:	movzbl 0x76c(%r15),%eax
  76df71:	cmpq   $0x0,0x6d0(%r15)
  76df79:	je     76df89 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4d9>
  76df7b:	test   %al,%al
  76df7d:	je     76df8d <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4dd>
  76df7f:	cmpq   $0xffffffffffffffff,0x5c8(%r15)
  76df87:	jne    76df8d <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4dd>
  76df89:	xor    %ecx,%ecx
  76df8b:	jmp    76df99 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4e9>
  76df8d:	mov    0x6e0(%r15),%rdx
  76df94:	mov    $0x1,%ecx
  76df99:	mov    0x758(%r15),%rsi
  76dfa0:	mov    %rcx,0x8(%rbx)
  76dfa4:	mov    %rdx,0x10(%rbx)
  76dfa8:	movups %xmm0,0x18(%rbx)
  76dfac:	mov    %rsi,0x28(%rbx)
  76dfb0:	mov    %al,0x30(%rbx)
  76dfb3:	movq   $0xfffffffffffffffe,(%rbx)
  76dfba:	jmp    76e0b5 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76dfbf:	xor    %ecx,%ecx
  76dfc1:	mov    %ecx,0x70(%rsp)
  76dfc5:	movzbl 0x76b(%r15),%edx
  76dfcd:	xor    $0x1,%dl
  76dfd0:	and    0x76a(%r15),%dl
  76dfd7:	and    0x76c(%r15),%dl
  76dfde:	mov    0x5c8(%r15),%rsi
  76dfe5:	cmp    $0xffffffffffffffff,%rsi
  76dfe9:	sete   %dil
  76dfed:	and    %dl,%dil
  76dff0:	cmp    $0x1,%dil
  76dff4:	jne    76e072 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5c2>
  76dff6:	mov    0x6a0(%r15),%rax
  76dffd:	cmp    0x6a8(%r15),%rax
  76e004:	jne    76e0ae <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76e00a:	mov    0x6c8(%r15),%rax
  76e011:	cmp    0x6c0(%r15),%rax
  76e018:	jne    76e0ae <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76e01e:	movss  0x760(%r15),%xmm2
  76e027:	ucomiss 0x764(%r15),%xmm2
  76e02f:	jne    76e0ae <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76e031:	jp     76e0ae <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76e033:	test   %ecx,%ecx
  76e035:	je     76e1e0 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x730>
  76e03b:	mov    0x650(%r15),%rax
  76e042:	test   %rax,%rax
  76e045:	je     76e1b8 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x708>
  76e04b:	mov    0xd8(%rax),%rax
  76e052:	test   %rax,%rax
  76e055:	je     76e1b8 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x708>
  76e05b:	cmpb   $0x0,0x12(%rax)
  76e05f:	je     76e1b8 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x708>
  76e065:	mov    %r15,%rdi
  76e068:	call   771200 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime9inspectorINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE14inspector_pickB10_>
  76e06d:	jmp    76e1d4 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x724>
  76e072:	cmp    $0xffffffffffffffff,%rsi
  76e076:	sete   %cl
  76e079:	movq   $0x12,0x10(%rsp)
  76e082:	xor    $0x1,%dl
  76e085:	or     %cl,%dl
  76e087:	jne    76e0ae <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76e089:	mov    0x6c8(%r15),%rcx
  76e090:	cmp    0x6c0(%r15),%rcx
  76e097:	jne    76e0ae <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76e099:	movss  0x760(%r15),%xmm0
  76e0a2:	ucomiss 0x764(%r15),%xmm0
  76e0aa:	jne    76e0ae <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76e0ac:	jnp    76e0fc <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x64c>
  76e0ae:	movq   $0x12,(%rbx)
  76e0b5:	add    $0xf8,%rsp
  76e0bc:	pop    %rbx
  76e0bd:	pop    %r12
  76e0bf:	pop    %r13
  76e0c1:	pop    %r14
  76e0c3:	pop    %r15
  76e0c5:	pop    %rbp
  76e0c6:	ret
  76e0c7:	lea    0x70(%rsp),%rdi
  76e0cc:	call   746480 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultNtNtCslbxve4rcJus_4gpui7runtime6CommitNtBZ_5ErrorEECs9C2G9YFESsD_29canonical_text_public_control>
  76e0d1:	jmp    76df61 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4b1>
  76e0d6:	xor    %eax,%eax
  76e0d8:	mov    %eax,0x10(%rsp)
  76e0dc:	lea    0x10(%rsp),%rsi
  76e0e1:	mov    %r15,%rdi
  76e0e4:	call   76f5c0 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11pointer_hitBW_>
  76e0e9:	mov    %rax,0x60(%rsp)
  76e0ee:	mov    %rdx,0x8(%rsp)
  76e0f3:	mov    0x54(%rsp),%ecx
  76e0f7:	jmp    76e1eb <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x73b>
  76e0fc:	mov    0x6a8(%r15),%rcx
  76e103:	cmp    $0xffffffffffffffff,%rcx
  76e107:	je     76e0ae <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76e109:	inc    %rcx
  76e10c:	mov    0x6a0(%r15),%rdx
  76e113:	cmp    %rdx,%rcx
  76e116:	jne    76e0ae <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76e118:	cmp    %rdx,0x6e0(%r15)
  76e11f:	jne    76e0ae <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76e121:	test   %rax,%rax
  76e124:	je     76e0ae <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76e126:	cmpq   $0x0,0x6d0(%r15)
  76e12e:	je     76e0ae <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76e134:	cmp    %rax,0x6d8(%r15)
  76e13b:	jne    76e0ae <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76e141:	cmp    0x5f0(%r15),%r12
  76e148:	jne    76e0ae <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76e14e:	lea    0x70(%rsp),%rsi
  76e153:	mov    %r15,%rdi
  76e156:	call   76f5c0 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11pointer_hitBW_>
  76e15b:	mov    %rax,0x60(%rsp)
  76e160:	mov    %rdx,0x8(%rsp)
  76e165:	mov    0x650(%r15),%rax
  76e16c:	test   %rax,%rax
  76e16f:	je     76e1ac <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x6fc>
  76e171:	cmpq   $0x0,0xd8(%rax)
  76e179:	je     76e1ac <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x6fc>
  76e17b:	cmp    %r12,0x60(%rsp)
  76e180:	jne    76e0ae <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76e186:	cmp    %r13,0x8(%rsp)
  76e18b:	jne    76e0ae <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76e191:	lea    0x70(%rsp),%rcx
  76e196:	mov    %r15,%rdi
  76e199:	mov    %r12,%rsi
  76e19c:	mov    %r13,%rdx
  76e19f:	call   76f6f0 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE19inspector_focus_hitBW_>
  76e1a4:	test   %al,%al
  76e1a6:	je     76e0ae <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x5fe>
  76e1ac:	lea    0x10(%rsp),%rdi
  76e1b1:	call   74d810 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  76e1b6:	jmp    76e1e9 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x739>
  76e1b8:	mov    %r15,%rdi
  76e1bb:	call   78d600 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE3hitBO_>
  76e1c0:	test   $0x1,%al
  76e1c2:	je     76e1e0 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x730>
  76e1c4:	lea    0x5f0(%r15),%rdi
  76e1cb:	mov    %rdx,%rsi
  76e1ce:	call   *0x34c30c(%rip)        # aba4e0 <_DYNAMIC+0x4a0>
  76e1d4:	mov    %rax,0x60(%rsp)
  76e1d9:	mov    %rdx,0x8(%rsp)
  76e1de:	jmp    76e1e9 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x739>
  76e1e0:	movq   $0x0,0x60(%rsp)
  76e1e9:	xor    %ecx,%ecx
  76e1eb:	mov    0x650(%r15),%rax
  76e1f2:	test   %rax,%rax
  76e1f5:	je     76e209 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x759>
  76e1f7:	mov    0xd8(%rax),%rax
  76e1fe:	test   %rax,%rax
  76e201:	je     76e209 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x759>
  76e203:	movzbl 0x12(%rax),%eax
  76e207:	jmp    76e20b <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x75b>
  76e209:	xor    %eax,%eax
  76e20b:	cmp    $0x2,%ebp
  76e20e:	jne    76e2fc <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x84c>
  76e214:	mov    0x628(%r15),%rdx
  76e21b:	mov    0x630(%r15),%rcx
  76e222:	mov    0x60(%rsp),%rbp
  76e227:	test   %rbp,%rbp
  76e22a:	sete   %sil
  76e22e:	or     %al,%sil
  76e231:	test   $0x1,%sil
  76e235:	je     76e344 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x894>
  76e23b:	movq   $0x0,0x628(%r15)
  76e246:	lea    0x10(%rsp),%rdi
  76e24b:	mov    %r15,%rsi
  76e24e:	call   770f50 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE20publish_focus_changeB12_>
  76e253:	mov    0x10(%rsp),%rax
  76e258:	movups 0x18(%rsp),%xmm0
  76e25d:	movaps %xmm0,0x70(%rsp)
  76e262:	movups 0x28(%rsp),%xmm0
  76e267:	movaps %xmm0,0x80(%rsp)
  76e26f:	movups 0x38(%rsp),%xmm0
  76e274:	movaps %xmm0,0x90(%rsp)
  76e27c:	cmp    $0xfffffffffffffffe,%rax
  76e280:	jne    76e435 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x985>
  76e286:	movaps 0x70(%rsp),%xmm0
  76e28b:	movaps 0x80(%rsp),%xmm1
  76e293:	movaps 0x90(%rsp),%xmm2
  76e29b:	movaps %xmm2,0xe0(%rsp)
  76e2a3:	movaps %xmm1,0xd0(%rsp)
  76e2ab:	movaps %xmm0,0xc0(%rsp)
  76e2b3:	cmpq   $0xffffffffffffffff,0x5c8(%r15)
  76e2bb:	je     76e48a <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x9da>
  76e2c1:	mov    0x6a8(%r15),%rax
  76e2c8:	cmp    $0xffffffffffffffff,%rax
  76e2cc:	je     76e48a <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x9da>
  76e2d2:	inc    %rax
  76e2d5:	cmp    0x6a0(%r15),%rax
  76e2dc:	jne    76e48a <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x9da>
  76e2e2:	cmpq   $0x0,0x6d0(%r15)
  76e2ea:	je     76e48a <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x9da>
  76e2f0:	mov    0x6d8(%r15),%rax
  76e2f7:	jmp    76e48c <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x9dc>
  76e2fc:	test   %cl,%cl
  76e2fe:	mov    0x60(%rsp),%rcx
  76e303:	jne    76df61 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4b1>
  76e309:	test   %rcx,%rcx
  76e30c:	je     76df61 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4b1>
  76e312:	cmp    %rcx,%r12
  76e315:	jne    76df61 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4b1>
  76e31b:	cmp    0x8(%rsp),%r13
  76e320:	jne    76df61 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x4b1>
  76e326:	test   %al,%al
  76e328:	je     76e4c8 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xa18>
  76e32e:	mov    %rbx,%rdi
  76e331:	mov    %r15,%rsi
  76e334:	mov    %r12,%rdx
  76e337:	mov    %r13,%rcx
  76e33a:	call   773d20 <_RNvMs4_NtNtCslbxve4rcJus_4gpui7runtime9inspectorINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE16inspector_selectB14_>
  76e33f:	jmp    76e0b5 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76e344:	cmp    0x5f0(%r15),%rbp
  76e34b:	jne    76e45e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x9ae>
  76e351:	mov    %rcx,%r12
  76e354:	mov    %rdx,%r13
  76e357:	lea    0x10(%rsp),%rdi
  76e35c:	mov    %r15,%rsi
  76e35f:	mov    0x8(%rsp),%rdx
  76e364:	call   78d320 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE16resolve_identityBO_>
  76e369:	mov    0x10(%rsp),%rax
  76e36e:	mov    0x18(%rsp),%rdi
  76e373:	cmp    $0xfffffffffffffffe,%rax
  76e377:	jne    76e463 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x9b3>
  76e37d:	mov    0x2e0(%r15),%rsi
  76e384:	cmp    %rsi,%rdi
  76e387:	jae    76e6f0 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xc40>
  76e38d:	mov    0x2d8(%r15),%rax
  76e394:	lea    (%rdi,%rdi,4),%rcx
  76e398:	mov    0x20(%rax,%rcx,8),%edi
  76e39c:	call   776700 <_RNvMsh_NtCslbxve4rcJus_4gpui7runtimeNtB5_4Node4kind>
  76e3a1:	cmp    $0x4,%al
  76e3a3:	jne    76e5bd <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xb0d>
  76e3a9:	mov    0x58(%rsp),%rax
  76e3ae:	cmp    $0xffffffff,%eax
  76e3b1:	je     76e6fd <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xc4d>
  76e3b7:	movss  0x4(%r14),%xmm1
  76e3bd:	dec    %eax
  76e3bf:	movd   %eax,%xmm0
  76e3c3:	lea    0x10(%rsp),%rdi
  76e3c8:	mov    %r15,%rsi
  76e3cb:	mov    %rbp,%rdx
  76e3ce:	mov    0x8(%rsp),%r15
  76e3d3:	mov    %r15,%rcx
  76e3d6:	xor    %r8d,%r8d
  76e3d9:	call   770930 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE14select_pointerB12_>
  76e3de:	mov    0x10(%rsp),%rax
  76e3e3:	movups 0x38(%rsp),%xmm0
  76e3e8:	movaps %xmm0,0x90(%rsp)
  76e3f0:	movdqu 0x28(%rsp),%xmm1
  76e3f6:	movdqa %xmm1,0x80(%rsp)
  76e3ff:	movups 0x18(%rsp),%xmm2
  76e404:	movaps %xmm2,0x70(%rsp)
  76e409:	movups %xmm0,0x28(%rbx)
  76e40d:	movdqu %xmm1,0x18(%rbx)
  76e412:	movups %xmm2,0x8(%rbx)
  76e416:	cmp    $0xfffffffffffffffe,%rax
  76e41a:	jne    76e631 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xb81>
  76e420:	mov    %rbp,0x8(%r14)
  76e424:	mov    %r15,0x10(%r14)
  76e428:	movq   $0x0,0x18(%r14)
  76e430:	jmp    76dfb3 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x503>
  76e435:	movaps 0x70(%rsp),%xmm0
  76e43a:	movaps 0x80(%rsp),%xmm1
  76e442:	movaps 0x90(%rsp),%xmm2
  76e44a:	movups %xmm2,0x28(%rbx)
  76e44e:	movups %xmm1,0x18(%rbx)
  76e452:	movups %xmm0,0x8(%rbx)
  76e456:	mov    %rax,(%rbx)
  76e459:	jmp    76e0b5 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76e45e:	mov    $0x11,%eax
  76e463:	mov    0x40(%rsp),%rcx
  76e468:	mov    %rcx,0x30(%rbx)
  76e46c:	movups 0x20(%rsp),%xmm0
  76e471:	movups 0x30(%rsp),%xmm1
  76e476:	movups %xmm1,0x20(%rbx)
  76e47a:	movups %xmm0,0x10(%rbx)
  76e47e:	mov    %rax,(%rbx)
  76e481:	mov    %rdi,0x8(%rbx)
  76e485:	jmp    76e0b5 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76e48a:	xor    %eax,%eax
  76e48c:	mov    %rbp,0x8(%r14)
  76e490:	mov    0x8(%rsp),%rcx
  76e495:	mov    %rcx,0x10(%r14)
  76e499:	mov    %rax,0x18(%r14)
  76e49d:	movaps 0xc0(%rsp),%xmm0
  76e4a5:	movdqa 0xd0(%rsp),%xmm1
  76e4ae:	movaps 0xe0(%rsp),%xmm2
  76e4b6:	movups %xmm2,0x28(%rbx)
  76e4ba:	movdqu %xmm1,0x18(%rbx)
  76e4bf:	movups %xmm0,0x8(%rbx)
  76e4c3:	jmp    76dfb3 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x503>
  76e4c8:	lea    0xb0(%rsp),%rsi
  76e4d0:	mov    %rbx,%rdi
  76e4d3:	mov    %r12,%rdx
  76e4d6:	mov    %r13,%rcx
  76e4d9:	call   76a430 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB4_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE8activateBW_>
  76e4de:	jmp    76e0b5 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76e4e3:	movq   $0x4,0x70(%rsp)
  76e4ec:	pxor   %xmm0,%xmm0
  76e4f0:	movdqu %xmm0,0x78(%rsp)
  76e4f6:	mov    0x5c0(%r14),%rax
  76e4fd:	mov    %rax,0x8(%rsp)
  76e502:	test   %rax,%rax
  76e505:	je     76e6ad <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xbfd>
  76e50b:	mov    0x5b8(%r14),%rbp
  76e512:	mov    0x8(%rsp),%rax
  76e517:	mov    %rax,%r15
  76e51a:	shl    $0x6,%r15
  76e51e:	lea    -0x1(%rax),%r12
  76e522:	jmp    76e588 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xad8>
  76e524:	mov    0x80(%rsp),%rax
  76e52c:	mov    %rax,0x20(%rsp)
  76e531:	movups 0x70(%rsp),%xmm0
  76e536:	movaps %xmm0,0x10(%rsp)
  76e53b:	mov    0x650(%r14),%rax
  76e542:	test   %rax,%rax
  76e545:	je     76e5b9 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xb09>
  76e547:	cmpq   $0x0,(%rax)
  76e54b:	setne  %al
  76e54e:	movzbl %al,%ecx
  76e551:	mov    %rbp,%rdi
  76e554:	mov    0x8(%rsp),%rsi
  76e559:	lea    0x10(%rsp),%rdx
  76e55e:	mov    %r12,%r8
  76e561:	movd   0x54(%rsp),%xmm0
  76e567:	movss  0x58(%rsp),%xmm1
  76e56d:	call   *0x34c16d(%rip)        # aba6e0 <_DYNAMIC+0x6a0>
  76e573:	test   %al,%al
  76e575:	jne    76e639 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xb89>
  76e57b:	dec    %r12
  76e57e:	add    $0xffffffffffffffc0,%r15
  76e582:	je     76e6ad <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xbfd>
  76e588:	cmpb   $0x0,-0x2(%rbp,%r15,1)
  76e58e:	jne    76e524 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xa74>
  76e590:	movzbl -0x3(%rbp,%r15,1),%eax
  76e596:	sub    $0x2,%al
  76e598:	movzbl %al,%eax
  76e59b:	mov    $0x8,%ecx
  76e5a0:	cmovb  %ecx,%eax
  76e5a3:	cmp    $0x7,%al
  76e5a5:	je     76e524 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xa74>
  76e5ab:	movzbl %al,%eax
  76e5ae:	cmp    $0x4,%eax
  76e5b1:	je     76e524 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xa74>
  76e5b7:	jmp    76e57b <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xacb>
  76e5b9:	xor    %eax,%eax
  76e5bb:	jmp    76e54e <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xa9e>
  76e5bd:	lea    0x10(%rsp),%rdi
  76e5c2:	mov    %r15,%rsi
  76e5c5:	mov    %rbp,%rdx
  76e5c8:	mov    0x8(%rsp),%rcx
  76e5cd:	call   76fb80 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE5focusBW_>
  76e5d2:	mov    0x10(%rsp),%rax
  76e5d7:	cmp    $0xfffffffffffffffe,%rax
  76e5db:	jne    76e5e8 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xb38>
  76e5dd:	mov    %r13,%rdx
  76e5e0:	mov    %r12,%rcx
  76e5e3:	jmp    76e246 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x796>
  76e5e8:	mov    0x38(%rsp),%rcx
  76e5ed:	movzbl 0x40(%rsp),%edx
  76e5f2:	mov    0x41(%rsp),%esi
  76e5f6:	mov    %esi,0x70(%rsp)
  76e5fa:	mov    0x44(%rsp),%esi
  76e5fe:	mov    %esi,0x73(%rsp)
  76e602:	movups 0x18(%rsp),%xmm0
  76e607:	movups 0x28(%rsp),%xmm1
  76e60c:	mov    0x70(%rsp),%esi
  76e610:	mov    0x73(%rsp),%edi
  76e614:	mov    %edi,0x34(%rbx)
  76e617:	mov    %esi,0x31(%rbx)
  76e61a:	mov    %rax,(%rbx)
  76e61d:	movups %xmm0,0x8(%rbx)
  76e621:	movups %xmm1,0x18(%rbx)
  76e625:	mov    %rcx,0x28(%rbx)
  76e629:	mov    %dl,0x30(%rbx)
  76e62c:	jmp    76e0b5 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76e631:	mov    %rax,(%rbx)
  76e634:	jmp    76e0b5 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76e639:	movq   $0x19,0x10(%rsp)
  76e642:	lea    0x10(%rsp),%rdi
  76e647:	call   74d810 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  76e64c:	mov    %r12,0xb8(%rsp)
  76e654:	movq   $0x1,0xb0(%rsp)
  76e660:	lea    0xb0(%rsp),%rdi
  76e668:	mov    %r14,%rsi
  76e66b:	mov    %r14,%rdx
  76e66e:	call   75cab0 <_RINvYINtNtNtNtCs4NRVxsYgnAr_4core4iter7sources7from_fn6FromFnNCNvMs6_NtNtCslbxve4rcJus_4gpui7runtime6scrollINtB17_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE12scroll_at_2ds0_0ENtNtNtBa_6traits8iterator8Iterator8try_folduNCINvNvB34_3any5checkjNCBZ_s1_0E0INtNtNtBc_3ops12control_flow11ControlFlowuEEB1U_>
  76e673:	test   %al,%al
  76e675:	je     76e6ad <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xbfd>
  76e677:	movq   $0x1,0x18(%rsp)
  76e680:	mov    %r12,0x20(%rsp)
  76e685:	movaps 0x60(%rsp),%xmm0
  76e68a:	movups %xmm0,0x28(%rsp)
  76e68f:	movq   $0x3,0x10(%rsp)
  76e698:	lea    0x10(%rsp),%rdx
  76e69d:	mov    %rbx,%rdi
  76e6a0:	mov    %r13,%rsi
  76e6a3:	call   775640 <_RNvMs6_NtNtCslbxve4rcJus_4gpui7runtime6scrollINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE17apply_scroll_planBT_>
  76e6a8:	jmp    76e0b5 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76e6ad:	movq   $0x19,(%rbx)
  76e6b4:	jmp    76e0b5 <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0x605>
  76e6b9:	lea    -0x69bec7(%rip),%rdi        # d27f9 <GCC_except_table0+0x103f1>
  76e6c0:	lea    0x32cae9(%rip),%rdx        # a9b1b0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x16c8>
  76e6c7:	mov    $0x22,%esi
  76e6cc:	call   *0x34bc86(%rip)        # aba358 <_DYNAMIC+0x318>
  76e6d2:	lea    0x32caef(%rip),%rdx        # a9b1c8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x16e0>
  76e6d9:	call   *0x34bbd1(%rip)        # aba2b0 <_DYNAMIC+0x270>
  76e6df:	jmp    76e6ee <_RNvMs1_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_3WinNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13pointer_eventBS_+0xc3e>
  76e6e1:	lea    0x32caf8(%rip),%rdi        # a9b1e0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x16f8>
  76e6e8:	call   *0x34bc52(%rip)        # aba340 <_DYNAMIC+0x300>
  76e6ee:	ud2
  76e6f0:	lea    0x32cb01(%rip),%rdx        # a9b1f8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1710>
  76e6f7:	call   *0x34bbb3(%rip)        # aba2b0 <_DYNAMIC+0x270>
  76e6fd:	lea    0x32cb0c(%rip),%rdi        # a9b210 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1728>
  76e704:	call   *0x34bc36(%rip)        # aba340 <_DYNAMIC+0x300>
  76e70a:	mov    %rax,%rbx
  76e70d:	lea    0x10(%rsp),%rdi
  76e712:	call   74d810 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  76e717:	mov    %rbx,%rdi
  76e71a:	call   a98730 <_Unwind_Resume@plt>
  76e71f:	mov    %rax,%rbx
  76e722:	lea    0x70(%rsp),%rdi
  76e727:	call   746480 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultNtNtCslbxve4rcJus_4gpui7runtime6CommitNtBZ_5ErrorEECs9C2G9YFESsD_29canonical_text_public_control>
  76e72c:	mov    %rbx,%rdi
  76e72f:	call   a98730 <_Unwind_Resume@plt>

<gpui::runtime::RuntimeMut<canonical_text_public_control::Editor, ()>>::replace_input bytes=1615 frame=248

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000076ff00 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_>:
  76ff00:	push   %rbp
  76ff01:	push   %r15
  76ff03:	push   %r14
  76ff05:	push   %r13
  76ff07:	push   %r12
  76ff09:	push   %rbx
  76ff0a:	sub    $0xc8,%rsp
  76ff11:	mov    %rdi,%rbx
  76ff14:	mov    (%rsi),%r13
  76ff17:	cmpb   $0x1,0x76e(%r13)
  76ff1f:	jne    76ff2d <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x2d>
  76ff21:	movq   $0xe,(%rbx)
  76ff28:	jmp    770388 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x488>
  76ff2d:	mov    %r8,%rbp
  76ff30:	mov    %r9,0x90(%rsp)
  76ff38:	mov    %rsi,0x98(%rsp)
  76ff40:	lea    0x30(%rsp),%rdi
  76ff45:	mov    %r13,%rsi
  76ff48:	call   76afb0 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11input_indexBY_>
  76ff4d:	mov    0x30(%rsp),%rax
  76ff52:	mov    0x38(%rsp),%rdx
  76ff57:	cmp    $0xfffffffffffffffe,%rax
  76ff5b:	jne    770057 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x157>
  76ff61:	mov    0x2e0(%r13),%rsi
  76ff68:	cmp    %rsi,%rdx
  76ff6b:	jae    770473 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x573>
  76ff71:	mov    0x2d8(%r13),%rcx
  76ff78:	lea    (%rdx,%rdx,4),%r8
  76ff7c:	mov    0x20(%rcx,%r8,8),%edi
  76ff81:	mov    %edi,%eax
  76ff83:	and    $0xf,%eax
  76ff86:	cmp    $0x9,%eax
  76ff89:	ja     770421 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x521>
  76ff8f:	cmp    $0x6,%eax
  76ff92:	je     77039a <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x49a>
  76ff98:	shr    $0x4,%edi
  76ff9b:	je     77039a <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x49a>
  76ffa1:	mov    0x2f8(%r13),%rsi
  76ffa8:	dec    %edi
  76ffaa:	cmp    %rdi,%rsi
  76ffad:	jbe    770486 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x586>
  76ffb3:	mov    0x2f0(%r13),%rax
  76ffba:	lea    (%rdi,%rdi,4),%rsi
  76ffbe:	shl    $0x4,%rsi
  76ffc2:	cmpq   $0xfffffffffffffffe,(%rax,%rsi,1)
  76ffc7:	je     770407 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x507>
  76ffcd:	add    %rsi,%rax
  76ffd0:	mov    0x48(%rax),%r12
  76ffd4:	test   %r12,%r12
  76ffd7:	je     770414 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x514>
  76ffdd:	mov    0x608(%r13),%rax
  76ffe4:	test   %rax,%rax
  76ffe7:	je     77045a <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x55a>
  76ffed:	mov    (%rcx,%r8,8),%r14
  76fff1:	mov    0x610(%r13),%rcx
  76fff8:	movzwl 0x1c2(%rax),%edi
  76ffff:	mov    %edi,%r9d
  770002:	shl    $0x5,%r9d
  770006:	mov    $0xffffffffffffffff,%rsi
  77000d:	xor    %r8d,%r8d
  770010:	cmp    %r8,%r9
  770013:	je     770040 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x140>
  770015:	cmp    0x170(%rax,%rsi,8),%r12
  77001d:	seta   %r10b
  770021:	sbb    $0x0,%r10b
  770025:	add    $0x20,%r8
  770029:	inc    %rsi
  77002c:	cmp    $0x1,%r10b
  770030:	je     770010 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x110>
  770032:	movzbl %r10b,%edi
  770036:	test   %edi,%edi
  770038:	je     770080 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x180>
  77003a:	jmp    770043 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x143>
  77003c:	nopl   0x0(%rax)
  770040:	mov    %rdi,%rsi
  770043:	sub    $0x1,%rcx
  770047:	jb     77045a <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x55a>
  77004d:	mov    0x1c8(%rax,%rsi,8),%rax
  770055:	jmp    76fff8 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0xf8>
  770057:	mov    0x60(%rsp),%rcx
  77005c:	mov    %rcx,0x30(%rbx)
  770060:	movdqu 0x40(%rsp),%xmm0
  770066:	movups 0x50(%rsp),%xmm1
  77006b:	movups %xmm1,0x20(%rbx)
  77006f:	movdqu %xmm0,0x10(%rbx)
  770074:	mov    %rax,(%rbx)
  770077:	mov    %rdx,0x8(%rbx)
  77007b:	jmp    770388 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x488>
  770080:	cmpq   $0xffffffffffffffff,-0x20(%rax,%r8,1)
  770086:	je     77009e <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x19e>
  770088:	mov    -0x8(%rax,%r8,1),%r15
  77008d:	cmpb   $0x2,0xc(%rbp)
  770091:	je     7700ab <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x1ab>
  770093:	movups 0x0(%rbp),%xmm0
  770097:	movups %xmm0,0x38(%rsp)
  77009c:	jmp    7700c7 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x1c7>
  77009e:	lea    0x32b54b(%rip),%r15        # a9b5f0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1b08>
  7700a5:	cmpb   $0x2,0xc(%rbp)
  7700a9:	jne    770093 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x193>
  7700ab:	lea    0x30(%rsp),%rdi
  7700b0:	mov    %r13,%rsi
  7700b3:	call   76b0f0 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE12selection_atBY_>
  7700b8:	mov    0x30(%rsp),%rax
  7700bd:	cmp    $0xfffffffffffffffe,%rax
  7700c1:	jne    77036a <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x46a>
  7700c7:	mov    %r15,0x28(%rsp)
  7700cc:	mov    %r14,0x88(%rsp)
  7700d4:	movdqu 0x38(%rsp),%xmm0
  7700da:	movdqa %xmm0,0xa0(%rsp)
  7700e3:	cmp    $0x1,%r12d
  7700e7:	jne    770143 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x243>
  7700e9:	mov    0x248(%r13),%rbp
  7700f0:	mov    0x250(%r13),%r14
  7700f7:	shl    $0x4,%r14
  7700fb:	xor    %r15d,%r15d
  7700fe:	xchg   %ax,%ax
  770100:	cmp    %r15,%r14
  770103:	je     770334 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x434>
  770109:	mov    0x0(%rbp,%r15,1),%rdi
  77010e:	mov    0x8(%rbp,%r15,1),%rax
  770113:	call   *0x18(%rax)
  770116:	add    $0x10,%r15
  77011a:	cmp    %r12,%rax
  77011d:	jne    770100 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x200>
  77011f:	mov    -0x10(%rbp,%r15,1),%rdi
  770124:	mov    -0x8(%rbp,%r15,1),%rax
  770129:	lea    0x290(%r13),%rsi
  770130:	call   *0x28(%rax)
  770133:	mov    0x28(%rsp),%r15
  770138:	mov    %rax,%r14
  77013b:	mov    %rdx,%rbp
  77013e:	jmp    7701c7 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x2c7>
  770143:	mov    0x278(%r13),%rbp
  77014a:	mov    0x280(%r13),%r14
  770151:	shl    $0x4,%r14
  770155:	xor    %r15d,%r15d
  770158:	nopl   0x0(%rax,%rax,1)
  770160:	cmp    %r15,%r14
  770163:	je     770334 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x434>
  770169:	mov    0x0(%rbp,%r15,1),%rdi
  77016e:	mov    0x8(%rbp,%r15,1),%rax
  770173:	mov    %r12,%rsi
  770176:	call   *0x30(%rax)
  770179:	add    $0x10,%r15
  77017d:	test   %al,%al
  77017f:	je     770160 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x260>
  770181:	mov    -0x10(%rbp,%r15,1),%rsi
  770186:	mov    -0x8(%rbp,%r15,1),%rax
  77018b:	lea    0xb0(%rsp),%rdi
  770193:	lea    0x290(%r13),%rdx
  77019a:	mov    %r12,%rcx
  77019d:	call   *0x58(%rax)
  7701a0:	mov    0x28(%rsp),%r15
  7701a5:	mov    0xb0(%rsp),%rax
  7701ad:	mov    0xb8(%rsp),%r14
  7701b5:	mov    0xc0(%rsp),%rbp
  7701bd:	cmp    $0xffffffffffffffff,%rax
  7701c1:	jne    77033c <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x43c>
  7701c7:	mov    %r14,%rdi
  7701ca:	call   *0x18(%rbp)
  7701cd:	mov    %rdx,%rcx
  7701d0:	lea    0x30(%rsp),%rdi
  7701d5:	mov    %r15,%rsi
  7701d8:	mov    %rax,%rdx
  7701db:	mov    %r12,%r8
  7701de:	call   *0x34a53c(%rip)        # aba720 <_DYNAMIC+0x6e0>
  7701e4:	mov    0x38(%rsp),%rax
  7701e9:	mov    0x40(%rsp),%r14
  7701ee:	mov    0x48(%rsp),%rbp
  7701f3:	cmpb   $0x0,0x30(%rsp)
  7701f8:	jne    77033c <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x43c>
  7701fe:	cmp    $0xffffffffffffffff,%rax
  770202:	je     7703a7 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x4a7>
  770208:	mov    %rax,0x10(%rsp)
  77020d:	mov    %r14,0x18(%rsp)
  770212:	mov    %rbp,0x80(%rsp)
  77021a:	mov    0x10(%rsp),%rax
  77021f:	mov    %rax,0x70(%rsp)
  770224:	mov    0x18(%rsp),%rax
  770229:	mov    %rax,0x78(%rsp)
  77022e:	mov    0x78(%rsp),%r14
  770233:	movdqa 0xa0(%rsp),%xmm0
  77023c:	movdqa %xmm0,0x30(%rsp)
  770242:	lea    0x30(%rsp),%rdx
  770247:	mov    %r14,%rdi
  77024a:	mov    %rbp,%rsi
  77024d:	call   *0x34a4c5(%rip)        # aba718 <_DYNAMIC+0x6d8>
  770253:	mov    $0x18,%ecx
  770258:	test   %al,%al
  77025a:	je     77043f <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x53f>
  770260:	movdqa 0xa0(%rsp),%xmm0
  770269:	movd   %xmm0,%r13d
  77026e:	pshufd $0xee,%xmm0,%xmm0
  770273:	movd   %xmm0,%eax
  770277:	cmp    %r13,%rax
  77027a:	mov    %r13,%rbp
  77027d:	cmovb  %rax,%rbp
  770281:	mov    %rbp,%r15
  770284:	mov    0x100(%rsp),%rcx
  77028c:	add    %rcx,%r15
  77028f:	jb     77043a <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x53a>
  770295:	cmp    %r13,%rax
  770298:	cmova  %rax,%r13
  77029c:	movq   $0x1e,0x30(%rsp)
  7702a5:	lea    0x30(%rsp),%rdi
  7702aa:	call   74d810 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  7702af:	lea    0x70(%rsp),%rdi
  7702b4:	mov    %rbp,%rsi
  7702b7:	mov    %r13,%rdx
  7702ba:	mov    0x90(%rsp),%rcx
  7702c2:	mov    0x100(%rsp),%r8
  7702ca:	call   73d960 <_RINvMNtCscdodAO9FK5_5alloc6stringNtB3_6String13replace_rangeINtNtNtCs4NRVxsYgnAr_4core3ops5range5RangejEECs9C2G9YFESsD_29canonical_text_public_control>
  7702cf:	mov    0x88(%rsp),%rax
  7702d7:	mov    %rax,0x10(%rsp)
  7702dc:	mov    %r12,0x20(%rsp)
  7702e1:	mov    %r15,0x18(%rsp)
  7702e6:	movq   $0x1,0x8(%rsp)
  7702ef:	mov    %r12,0x48(%rsp)
  7702f4:	movaps 0x70(%rsp),%xmm0
  7702f9:	movaps %xmm0,0x30(%rsp)
  7702fe:	mov    0x80(%rsp),%rax
  770306:	mov    %rax,0x40(%rsp)
  77030b:	mov    0x28(%rsp),%rax
  770310:	mov    %rax,0x50(%rsp)
  770315:	lea    0x30(%rsp),%rcx
  77031a:	lea    0x8(%rsp),%r8
  77031f:	mov    %rbx,%rdi
  770322:	mov    0x98(%rsp),%rsi
  77032a:	mov    %r12,%rdx
  77032d:	call   73da50 <_RINvMNtNtCslbxve4rcJus_4gpui7runtime4turnINtB5_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE22operation_with_editingNCNvMs2_NtB5_7editingBD_13replace_inputs0_0EBX_>
  770332:	jmp    770388 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x488>
  770334:	mov    $0xb,%eax
  770339:	mov    %r12,%r14
  77033c:	mov    %rax,0x10(%rsp)
  770341:	mov    %r14,0x18(%rsp)
  770346:	mov    %rbp,0x20(%rsp)
  77034b:	mov    %rbp,0x18(%rbx)
  77034f:	mov    0x10(%rsp),%rax
  770354:	mov    %rax,0x8(%rbx)
  770358:	mov    0x18(%rsp),%rax
  77035d:	mov    %rax,0x10(%rbx)
  770361:	movq   $0x20,(%rbx)
  770368:	jmp    770388 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x488>
  77036a:	movups 0x48(%rsp),%xmm0
  77036f:	movups 0x58(%rsp),%xmm1
  770374:	movups %xmm1,0x28(%rbx)
  770378:	movups %xmm0,0x18(%rbx)
  77037c:	movups 0x38(%rsp),%xmm0
  770381:	mov    %rax,(%rbx)
  770384:	movups %xmm0,0x8(%rbx)
  770388:	add    $0xc8,%rsp
  77038f:	pop    %rbx
  770390:	pop    %r12
  770392:	pop    %r13
  770394:	pop    %r14
  770396:	pop    %r15
  770398:	pop    %rbp
  770399:	ret
  77039a:	lea    0x32af2f(%rip),%rdi        # a9b2d0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x17e8>
  7703a1:	call   *0x349f99(%rip)        # aba340 <_DYNAMIC+0x300>
  7703a7:	test   %rbp,%rbp
  7703aa:	jns    7703bd <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x4bd>
  7703ac:	xor    %r15d,%r15d
  7703af:	mov    %r15,%rdi
  7703b2:	mov    %rbp,%rsi
  7703b5:	call   *0x349f75(%rip)        # aba330 <_DYNAMIC+0x2f0>
  7703bb:	ud2
  7703bd:	je     7703f8 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x4f8>
  7703bf:	call   *0x349ec3(%rip)        # aba288 <_DYNAMIC+0x248>
  7703c5:	mov    $0x1,%r15d
  7703cb:	mov    $0x1,%esi
  7703d0:	mov    %rbp,%rdi
  7703d3:	call   *0x349eb7(%rip)        # aba290 <_DYNAMIC+0x250>
  7703d9:	test   %rax,%rax
  7703dc:	je     7703af <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x4af>
  7703de:	mov    %rax,%rdi
  7703e1:	mov    %r14,%rsi
  7703e4:	mov    %rbp,%rdx
  7703e7:	mov    %rax,%r14
  7703ea:	call   *0x349eb0(%rip)        # aba2a0 <memcpy@GLIBC_2.14>
  7703f0:	mov    %rbp,%rax
  7703f3:	jmp    770208 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x308>
  7703f8:	mov    $0x1,%r14d
  7703fe:	xor    %eax,%eax
  770400:	xor    %ebp,%ebp
  770402:	jmp    770208 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x308>
  770407:	lea    0x329efa(%rip),%rdi        # a9a308 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x820>
  77040e:	call   *0x349f2c(%rip)        # aba340 <_DYNAMIC+0x300>
  770414:	lea    0x32aecd(%rip),%rdi        # a9b2e8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1800>
  77041b:	call   *0x349f1f(%rip)        # aba340 <_DYNAMIC+0x300>
  770421:	lea    -0x69da98(%rip),%rdi        # d2990 <GCC_except_table0+0x10588>
  770428:	lea    0x32b191(%rip),%rdx        # a9b5c0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1ad8>
  77042f:	mov    $0x83,%esi
  770434:	call   *0x349e7e(%rip)        # aba2b8 <_DYNAMIC+0x278>
  77043a:	mov    $0x1e,%ecx
  77043f:	mov    %rcx,(%rbx)
  770442:	mov    0x70(%rsp),%rsi
  770447:	test   %rsi,%rsi
  77044a:	je     770388 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x488>
  770450:	mov    $0x1,%edx
  770455:	jmp    77050b <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x60b>
  77045a:	lea    -0x69dc46(%rip),%rdi        # d281b <GCC_except_table0+0x10413>
  770461:	lea    0x32ae98(%rip),%rdx        # a9b300 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1818>
  770468:	mov    $0x16,%esi
  77046d:	call   *0x349ee5(%rip)        # aba358 <_DYNAMIC+0x318>
  770473:	lea    0x32ae3e(%rip),%rax        # a9b2b8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x17d0>
  77047a:	mov    %rdx,%rdi
  77047d:	mov    %rax,%rdx
  770480:	call   *0x349e2a(%rip)        # aba2b0 <_DYNAMIC+0x270>
  770486:	lea    0x329e63(%rip),%rdx        # a9a2f0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x808>
  77048d:	call   *0x349e1d(%rip)        # aba2b0 <_DYNAMIC+0x270>
  770493:	mov    %rax,%rbx
  770496:	mov    0x70(%rsp),%rsi
  77049b:	test   %rsi,%rsi
  77049e:	je     7704b0 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x5b0>
  7704a0:	mov    0x78(%rsp),%rdi
  7704a5:	mov    $0x1,%edx
  7704aa:	call   *0x349dd0(%rip)        # aba280 <_DYNAMIC+0x240>
  7704b0:	mov    %rbx,%rdi
  7704b3:	call   a98730 <_Unwind_Resume@plt>
  7704b8:	jmp    7704bc <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x5bc>
  7704ba:	jmp    7704bc <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x5bc>
  7704bc:	mov    %rax,%rdi
  7704bf:	call   *0x349e13(%rip)        # aba2d8 <_DYNAMIC+0x298>
  7704c5:	mov    %rax,%r14
  7704c8:	mov    %rdx,%r15
  7704cb:	mov    %rax,0x10(%rsp)
  7704d0:	mov    %rdx,0x18(%rsp)
  7704d5:	movq   $0x2,0x8(%rsp)
  7704de:	mov    %r13,%rdi
  7704e1:	call   78d970 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE6poisonBO_>
  7704e6:	movq   $0xf,(%rbx)
  7704ed:	mov    (%r15),%rax
  7704f0:	test   %rax,%rax
  7704f3:	je     7704fa <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x5fa>
  7704f5:	mov    %r14,%rdi
  7704f8:	call   *%rax
  7704fa:	mov    0x8(%r15),%rsi
  7704fe:	test   %rsi,%rsi
  770501:	je     770388 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x488>
  770507:	mov    0x10(%r15),%rdx
  77050b:	mov    %r14,%rdi
  77050e:	call   *0x349d6c(%rip)        # aba280 <_DYNAMIC+0x240>
  770514:	jmp    770388 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x488>
  770519:	mov    %rax,%rbx
  77051c:	mov    0x8(%r15),%rsi
  770520:	test   %rsi,%rsi
  770523:	je     7704b0 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x5b0>
  770525:	mov    0x10(%r15),%rdx
  770529:	mov    %r14,%rdi
  77052c:	jmp    7704aa <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x5aa>
  770531:	mov    %rax,%rbx
  770534:	lea    0x8(%rsp),%rdi
  770539:	call   746260 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultIBC_NtNtCscdodAO9FK5_5alloc6string6StringNtNtCslbxve4rcJus_4gpui6source9BindErrorEINtNtB15_5boxed3BoxDNtNtB4_3any3AnyNtNtB4_6marker4SendEL_EEECs9C2G9YFESsD_29canonical_text_public_control>
  77053e:	jmp    7704b0 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_10RuntimeMutNtCs9C2G9YFESsD_29canonical_text_public_control6EditoruE13replace_inputB12_+0x5b0>
  770543:	call   *0x349d5f(%rip)        # aba2a8 <_DYNAMIC+0x268>
  770549:	call   *0x349d91(%rip)        # aba2e0 <_DYNAMIC+0x2a0>

<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::acknowledge bytes=1581 frame=200

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000077bbc0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_>:
  77bbc0:	push   %r15
  77bbc2:	push   %r14
  77bbc4:	push   %r13
  77bbc6:	push   %r12
  77bbc8:	push   %rbx
  77bbc9:	sub    $0xa0,%rsp
  77bbd0:	mov    %rdi,%r14
  77bbd3:	cmp    %rdx,0x6d0(%rsi)
  77bbda:	jne    77bf1e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x35e>
  77bbe0:	mov    %rcx,%r15
  77bbe3:	mov    %rsi,%rbx
  77bbe6:	cmp    %rcx,0x6d8(%rsi)
  77bbed:	jne    77bf1e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x35e>
  77bbf3:	lea    0x600(%rbx),%rdi
  77bbfa:	mov    %r15,%rsi
  77bbfd:	call   *0x33ebc5(%rip)        # aba7c8 <_DYNAMIC+0x788>
  77bc03:	mov    0x5e8(%rbx),%rax
  77bc0a:	mov    %rax,0x30(%rsp)
  77bc0f:	movdqu 0x5c8(%rbx),%xmm0
  77bc17:	movdqu 0x5d8(%rbx),%xmm1
  77bc1f:	movdqa %xmm0,0x10(%rsp)
  77bc25:	movq   $0xffffffffffffffff,0x5c8(%rbx)
  77bc30:	movzbl 0x76c(%rbx),%eax
  77bc37:	xor    $0x1,%rax
  77bc3b:	cmpq   $0xffffffffffffffff,0x10(%rsp)
  77bc41:	movdqa %xmm1,0x20(%rsp)
  77bc47:	mov    $0x1,%r13d
  77bc4d:	cmove  %rax,%r13
  77bc51:	je     77bcf9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x139>
  77bc57:	movdqa 0x30(%rsp),%xmm0
  77bc5d:	movss  0x34(%rsp),%xmm2
  77bc63:	movd   %xmm0,%eax
  77bc67:	pand   -0x6b811f(%rip),%xmm0        # c3b50 <GCC_except_table0+0x1748>
  77bc6f:	pxor   %xmm1,%xmm1
  77bc73:	punpcklwd %xmm1,%xmm0
  77bc77:	movq   %xmm0,0x6c0(%rbx)
  77bc7f:	test   %ax,%ax
  77bc82:	js     77bf2a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x36a>
  77bc88:	movss  %xmm2,0xc(%rsp)
  77bc8e:	lea    0x5b0(%rbx),%r12
  77bc95:	mov    %r12,%rdi
  77bc98:	call   7474f0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCslbxve4rcJus_4gpui7runtime9PresentedEECs9C2G9YFESsD_29canonical_text_public_control>
  77bc9d:	mov    0x20(%rsp),%rax
  77bca2:	mov    %rax,0x10(%r12)
  77bca7:	movaps 0x10(%rsp),%xmm0
  77bcac:	movups %xmm0,(%r12)
  77bcb1:	mov    0x6e8(%rbx),%rdi
  77bcb8:	test   %rdi,%rdi
  77bcbb:	je     77bcc3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x103>
  77bcbd:	call   *0x33eb0d(%rip)        # aba7d0 <_DYNAMIC+0x790>
  77bcc3:	mov    0x650(%rbx),%rax
  77bcca:	test   %rax,%rax
  77bccd:	je     77bceb <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x12b>
  77bccf:	mov    0xe0(%rax),%rax
  77bcd6:	test   %rax,%rax
  77bcd9:	je     77bceb <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x12b>
  77bcdb:	mov    0x50(%rax),%rcx
  77bcdf:	mov    %rcx,0x38(%rax)
  77bce3:	movups 0x40(%rax),%xmm0
  77bce7:	movups %xmm0,0x28(%rax)
  77bceb:	movd   0xc(%rsp),%xmm0
  77bcf1:	movd   %xmm0,0x764(%rbx)
  77bcf9:	mov    0x650(%rbx),%rax
  77bd00:	test   %rax,%rax
  77bd03:	je     77bf4c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77bd09:	mov    0x60(%rax),%r12
  77bd0d:	movq   $0xffffffffffffffff,0x60(%rax)
  77bd15:	cmp    $0xffffffffffffffff,%r12
  77bd19:	je     77bdbd <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x1fd>
  77bd1f:	mov    0xb8(%rax),%rcx
  77bd26:	mov    %rcx,0x90(%rsp)
  77bd2e:	movups 0xa8(%rax),%xmm0
  77bd35:	movaps %xmm0,0x80(%rsp)
  77bd3d:	movups 0x68(%rax),%xmm0
  77bd41:	movups 0x78(%rax),%xmm1
  77bd45:	movups 0x88(%rax),%xmm2
  77bd4c:	movups 0x98(%rax),%xmm3
  77bd53:	movaps %xmm3,0x70(%rsp)
  77bd58:	movaps %xmm2,0x60(%rsp)
  77bd5d:	movaps %xmm1,0x50(%rsp)
  77bd62:	movaps %xmm0,0x40(%rsp)
  77bd67:	mov    0x650(%rbx),%rdi
  77bd6e:	call   74eca0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime8metadata5SheetECs9C2G9YFESsD_29canonical_text_public_control>
  77bd73:	mov    0x650(%rbx),%rax
  77bd7a:	mov    %r12,(%rax)
  77bd7d:	movaps 0x40(%rsp),%xmm0
  77bd82:	movdqa 0x50(%rsp),%xmm1
  77bd88:	movaps 0x60(%rsp),%xmm2
  77bd8d:	movaps 0x70(%rsp),%xmm3
  77bd92:	movups %xmm0,0x8(%rax)
  77bd96:	movdqu %xmm1,0x18(%rax)
  77bd9b:	movups %xmm2,0x28(%rax)
  77bd9f:	movups %xmm3,0x38(%rax)
  77bda3:	movdqa 0x80(%rsp),%xmm0
  77bdac:	movdqu %xmm0,0x48(%rax)
  77bdb1:	mov    0x90(%rsp),%rcx
  77bdb9:	mov    %rcx,0x58(%rax)
  77bdbd:	mov    0x650(%rbx),%r12
  77bdc4:	test   %r12,%r12
  77bdc7:	je     77bf4c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77bdcd:	mov    0x100(%r12),%rdi
  77bdd5:	test   %rdi,%rdi
  77bdd8:	je     77be29 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x269>
  77bdda:	call   *0x33e9f8(%rip)        # aba7d8 <_DYNAMIC+0x798>
  77bde0:	mov    0x100(%r12),%rax
  77bde8:	cmpq   $0x0,0x10(%rax)
  77bded:	jne    77be29 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x269>
  77bdef:	cmpq   $0x0,0x58(%rax)
  77bdf4:	jne    77be29 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x269>
  77bdf6:	cmpq   $0x0,0x28(%rax)
  77bdfb:	jne    77be29 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x269>
  77bdfd:	cmpq   $0xffffffffffffffff,0x30(%rax)
  77be02:	jne    77be29 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x269>
  77be04:	mov    0x650(%rbx),%rax
  77be0b:	mov    0x100(%rax),%rdi
  77be12:	call   745ec0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionINtNtCscdodAO9FK5_5alloc5boxed3BoxNtNtNtCslbxve4rcJus_4gpui7runtime8geometry8GeometryEEECs9C2G9YFESsD_29canonical_text_public_control>
  77be17:	mov    0x650(%rbx),%rax
  77be1e:	movq   $0x0,0x100(%rax)
  77be29:	mov    0x650(%rbx),%r12
  77be30:	test   %r12,%r12
  77be33:	je     77bf4c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77be39:	mov    0xe0(%r12),%rdi
  77be41:	test   %rdi,%rdi
  77be44:	je     77be8a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x2ca>
  77be46:	cmpb   $0x2,0x24(%rdi)
  77be4a:	jne    77be8a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x2ca>
  77be4c:	cmpb   $0x2,0x3c(%rdi)
  77be50:	jne    77be8a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x2ca>
  77be52:	cmpb   $0x2,0x54(%rdi)
  77be56:	jne    77be8a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x2ca>
  77be58:	mov    $0x58,%esi
  77be5d:	mov    $0x8,%edx
  77be62:	call   *0x33e418(%rip)        # aba280 <_DYNAMIC+0x240>
  77be68:	mov    0x650(%rbx),%rax
  77be6f:	movq   $0x0,0xe0(%rax)
  77be7a:	mov    0x650(%rbx),%r12
  77be81:	test   %r12,%r12
  77be84:	je     77bf4c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77be8a:	cmpq   $0x0,0xd8(%r12)
  77be93:	jne    77bf4c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77be99:	cmpq   $0x0,0xe0(%r12)
  77bea2:	jne    77bf4c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77bea8:	cmpq   $0x0,0x100(%r12)
  77beb1:	jne    77bf4c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77beb7:	cmpq   $0x0,0xd0(%r12)
  77bec0:	jne    77bf4c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77bec6:	cmpq   $0x0,0xf8(%r12)
  77becf:	jne    77bf4c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77bed1:	mov    0x60(%r12),%rax
  77bed6:	cmp    $0xffffffff,%eax
  77bed9:	jne    77bf4c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77bedb:	cmpq   $0x0,0x28(%r12)
  77bee1:	jne    77bf4c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77bee3:	mov    (%r12),%rax
  77bee7:	or     0x40(%r12),%rax
  77beec:	jne    77bf4c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77beee:	cmpq   $0x0,0x58(%r12)
  77bef4:	jne    77bf4c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77bef6:	mov    %r12,%rdi
  77bef9:	call   74ed40 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime8metadata8MetadataECs9C2G9YFESsD_29canonical_text_public_control>
  77befe:	mov    $0x108,%esi
  77bf03:	mov    $0x8,%edx
  77bf08:	mov    %r12,%rdi
  77bf0b:	call   *0x33e36f(%rip)        # aba280 <_DYNAMIC+0x240>
  77bf11:	movq   $0x0,0x650(%rbx)
  77bf1c:	jmp    77bf4c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x38c>
  77bf1e:	movq   $0x15,(%r14)
  77bf25:	jmp    77c100 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x540>
  77bf2a:	movss  %xmm2,0x764(%rbx)
  77bf32:	lea    0x10(%rsp),%rdi
  77bf37:	call   7474f0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCslbxve4rcJus_4gpui7runtime9PresentedEECs9C2G9YFESsD_29canonical_text_public_control>
  77bf3c:	mov    0x650(%rbx),%rax
  77bf43:	test   %rax,%rax
  77bf46:	jne    77bd09 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x149>
  77bf4c:	mov    0x6e8(%rbx),%rdi
  77bf53:	test   %rdi,%rdi
  77bf56:	je     77bf7d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x3bd>
  77bf58:	cmpq   $0x0,0x30(%rdi)
  77bf5d:	jne    77bf7d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x3bd>
  77bf5f:	cmpq   $0x0,0x10(%rdi)
  77bf64:	jne    77bf7d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x3bd>
  77bf66:	cmpq   $0xffffffffffffffff,0x18(%rdi)
  77bf6b:	jne    77bf7d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x3bd>
  77bf6d:	call   745d50 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionINtNtCscdodAO9FK5_5alloc5boxed3BoxNtNtNtCslbxve4rcJus_4gpui7runtime13text_geometry13TextResourcesEEECs9C2G9YFESsD_29canonical_text_public_control>
  77bf72:	movq   $0x0,0x6e8(%rbx)
  77bf7d:	mov    0x628(%rbx),%rax
  77bf84:	test   %rax,%rax
  77bf87:	je     77c02f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x46f>
  77bf8d:	cmp    0x5f0(%rbx),%rax
  77bf94:	jne    77c024 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x464>
  77bf9a:	mov    0x630(%rbx),%rdx
  77bfa1:	lea    0x40(%rsp),%rdi
  77bfa6:	mov    %rbx,%rsi
  77bfa9:	call   78d320 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE16resolve_identityBO_>
  77bfae:	mov    0x40(%rsp),%rax
  77bfb3:	mov    0x48(%rsp),%rsi
  77bfb8:	cmp    $0xfffffffffffffffe,%rax
  77bfbc:	jne    77bfe9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x429>
  77bfbe:	mov    0x2e0(%rbx),%rax
  77bfc5:	cmp    %rax,%rsi
  77bfc8:	jae    77c111 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x551>
  77bfce:	lea    (%rsi,%rsi,4),%rdi
  77bfd2:	shl    $0x3,%rdi
  77bfd6:	add    0x2d8(%rbx),%rdi
  77bfdd:	call   *0x33e5cd(%rip)        # aba5b0 <_DYNAMIC+0x570>
  77bfe3:	test   %al,%al
  77bfe5:	je     77c024 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x464>
  77bfe7:	jmp    77c02f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x46f>
  77bfe9:	cmp    $0xd,%rax
  77bfed:	jl     77c007 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x447>
  77bfef:	cmp    $0x21,%rax
  77bff3:	je     77c007 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x447>
  77bff5:	cmp    $0x26,%rax
  77bff9:	jne    77c024 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x464>
  77bffb:	test   %rsi,%rsi
  77bffe:	je     77c024 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x464>
  77c000:	lea    0x50(%rsp),%rax
  77c005:	jmp    77c016 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x456>
  77c007:	mov    0x58(%rsp),%rsi
  77c00c:	test   %rsi,%rsi
  77c00f:	je     77c024 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x464>
  77c011:	lea    0x60(%rsp),%rax
  77c016:	mov    (%rax),%rdi
  77c019:	mov    $0x1,%edx
  77c01e:	call   *0x33e25c(%rip)        # aba280 <_DYNAMIC+0x240>
  77c024:	movq   $0x0,0x628(%rbx)
  77c02f:	mov    0x6e0(%rbx),%rax
  77c036:	mov    %rax,0x6a8(%rbx)
  77c03d:	mov    %r15,0x6b0(%rbx)
  77c044:	mov    0x6b8(%rbx),%rcx
  77c04b:	test   %rcx,%rcx
  77c04e:	je     77c0a2 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x4e2>
  77c050:	mov    0x6c0(%rbx),%rdx
  77c057:	cmpb   $0x0,0x59(%rcx)
  77c05b:	je     77c073 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x4b3>
  77c05d:	cmp    %r15,0x30(%rcx)
  77c061:	jne    77c085 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x4c5>
  77c063:	cmp    %rax,0x38(%rcx)
  77c067:	jne    77c085 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x4c5>
  77c069:	cmp    %rdx,0x40(%rcx)
  77c06d:	sete   %sil
  77c071:	jmp    77c087 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x4c7>
  77c073:	cmp    %rax,0x38(%rcx)
  77c077:	jne    77c085 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x4c5>
  77c079:	cmp    %r15,0x30(%rcx)
  77c07d:	jne    77c085 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x4c5>
  77c07f:	cmp    %rdx,0x40(%rcx)
  77c083:	je     77c0a2 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x4e2>
  77c085:	xor    %esi,%esi
  77c087:	and    %sil,0x58(%rcx)
  77c08b:	movb   $0x0,0x59(%rcx)
  77c08f:	mov    %r15,0x30(%rcx)
  77c093:	mov    %rax,0x38(%rcx)
  77c097:	mov    %rdx,0x40(%rcx)
  77c09b:	mov    0x6a8(%rbx),%rax
  77c0a2:	movb   $0x1,0x76c(%rbx)
  77c0a9:	add    %r13,0x738(%rbx)
  77c0b0:	mov    0x6a0(%rbx),%rcx
  77c0b7:	cmpq   $0x0,0x6d0(%rbx)
  77c0bf:	je     77c0d7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x517>
  77c0c1:	mov    0x6e0(%rbx),%rsi
  77c0c8:	xor    %edx,%edx
  77c0ca:	cmpq   $0xffffffffffffffff,0x5c8(%rbx)
  77c0d2:	setne  %dl
  77c0d5:	jmp    77c0d9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_+0x519>
  77c0d7:	xor    %edx,%edx
  77c0d9:	mov    0x758(%rbx),%rdi
  77c0e0:	mov    %rdx,0x8(%r14)
  77c0e4:	mov    %rsi,0x10(%r14)
  77c0e8:	mov    %rcx,0x18(%r14)
  77c0ec:	mov    %rax,0x20(%r14)
  77c0f0:	mov    %rdi,0x28(%r14)
  77c0f4:	movb   $0x1,0x30(%r14)
  77c0f9:	movq   $0xfffffffffffffffe,(%r14)
  77c100:	add    $0xa0,%rsp
  77c107:	pop    %rbx
  77c108:	pop    %r12
  77c10a:	pop    %r13
  77c10c:	pop    %r14
  77c10e:	pop    %r15
  77c110:	ret
  77c111:	lea    0x31e148(%rip),%rdx        # a9a260 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x778>
  77c118:	mov    %rsi,%rdi
  77c11b:	mov    %rax,%rsi
  77c11e:	call   *0x33e18c(%rip)        # aba2b0 <_DYNAMIC+0x270>
  77c124:	mov    %rax,%r14
  77c127:	mov    $0x108,%esi
  77c12c:	mov    $0x8,%edx
  77c131:	mov    %r12,%rdi
  77c134:	call   *0x33e146(%rip)        # aba280 <_DYNAMIC+0x240>
  77c13a:	movq   $0x0,0x650(%rbx)
  77c145:	mov    %r14,%rdi
  77c148:	call   a98730 <_Unwind_Resume@plt>
  77c14d:	mov    %rax,%r14
  77c150:	mov    0x650(%rbx),%rax
  77c157:	movq   $0x0,0x100(%rax)
  77c162:	mov    %r14,%rdi
  77c165:	call   a98730 <_Unwind_Resume@plt>
  77c16a:	movq   $0x0,0x6e8(%rbx)
  77c175:	mov    %rax,%rdi
  77c178:	call   a98730 <_Unwind_Resume@plt>
  77c17d:	mov    %rax,%r14
  77c180:	mov    0x650(%rbx),%rax
  77c187:	mov    %r12,(%rax)
  77c18a:	movaps 0x40(%rsp),%xmm0
  77c18f:	movaps 0x50(%rsp),%xmm1
  77c194:	movaps 0x60(%rsp),%xmm2
  77c199:	movaps 0x70(%rsp),%xmm3
  77c19e:	movups %xmm0,0x8(%rax)
  77c1a2:	movups %xmm1,0x18(%rax)
  77c1a6:	movups %xmm2,0x28(%rax)
  77c1aa:	movups %xmm3,0x38(%rax)
  77c1ae:	movaps 0x80(%rsp),%xmm0
  77c1b6:	movups %xmm0,0x48(%rax)
  77c1ba:	mov    0x90(%rsp),%rcx
  77c1c2:	mov    %rcx,0x58(%rax)
  77c1c6:	mov    %r14,%rdi
  77c1c9:	call   a98730 <_Unwind_Resume@plt>
  77c1ce:	mov    %rax,%r14
  77c1d1:	mov    0x20(%rsp),%rax
  77c1d6:	mov    %rax,0x10(%r12)
  77c1db:	movaps 0x10(%rsp),%xmm0
  77c1e0:	movups %xmm0,(%r12)
  77c1e5:	mov    %r14,%rdi
  77c1e8:	call   a98730 <_Unwind_Resume@plt>

<gpui::runtime::Runtime<canonical_text_public_control::Editor>>::present_inner bytes=22621 frame=3768

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000077c1f0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_>:
  77c1f0:	push   %rbp
  77c1f1:	push   %r15
  77c1f3:	push   %r14
  77c1f5:	push   %r13
  77c1f7:	push   %r12
  77c1f9:	push   %rbx
  77c1fa:	sub    $0xe88,%rsp
  77c201:	mov    %rdi,0x48(%rsp)
  77c206:	mov    0x5f8(%rsi),%rax
  77c20d:	mov    %rax,0x260(%rsp)
  77c215:	inc    %rax
  77c218:	je     780bda <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x49ea>
  77c21e:	mov    %rsi,%r13
  77c221:	mov    %rax,0x8b0(%rsp)
  77c229:	mov    0x5f0(%rsi),%rax
  77c230:	mov    %rax,0x680(%rsp)
  77c238:	mov    0x6c8(%rsi),%rsi
  77c23f:	mov    %rsi,%r14
  77c242:	shr    $0x20,%r14
  77c246:	movss  0x760(%r13),%xmm0
  77c24f:	movss  %xmm0,0x9c(%rsp)
  77c258:	mov    0x1a8(%r13),%eax
  77c25f:	mov    0x1b0(%r13),%rcx
  77c266:	shl    $0x20,%rcx
  77c26a:	or     %rax,%rcx
  77c26d:	cmp    %rcx,%rsi
  77c270:	jne    77c298 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xa8>
  77c272:	mov    %rsi,%r15
  77c275:	movq   $0x2,0xca0(%rsp)
  77c281:	mov    $0x2,%ebx
  77c286:	cmp    $0xffff,%r15d
  77c28d:	jbe    77c33a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x14a>
  77c293:	jmp    77c34b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x15b>
  77c298:	movups 0x138(%r13),%xmm0
  77c2a0:	movaps %xmm0,0x970(%rsp)
  77c2a8:	lea    0x390(%rsp),%rdi
  77c2b0:	lea    0x970(%rsp),%rcx
  77c2b8:	mov    %rsi,%r15
  77c2bb:	mov    %r14,%r12
  77c2be:	mov    %r14d,%edx
  77c2c1:	call   *0x33e2d1(%rip)        # aba598 <_DYNAMIC+0x558>
  77c2c7:	mov    0x390(%rsp),%rbx
  77c2cf:	mov    0x398(%rsp),%r14d
  77c2d7:	mov    0x39c(%rsp),%ebp
  77c2de:	cmp    $0x2,%rbx
  77c2e2:	jne    77c2fc <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x10c>
  77c2e4:	mov    0x48(%rsp),%rax
  77c2e9:	movq   $0x23,(%rax)
  77c2f0:	mov    %r14d,0x8(%rax)
  77c2f4:	mov    %ebp,0xc(%rax)
  77c2f7:	jmp    77da31 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1841>
  77c2fc:	lea    0x3a0(%rsp),%rsi
  77c304:	lea    0xcb0(%rsp),%rdi
  77c30c:	mov    $0x1d8,%edx
  77c311:	call   *0x33df89(%rip)        # aba2a0 <memcpy@GLIBC_2.14>
  77c317:	mov    %rbx,0xca0(%rsp)
  77c31f:	mov    %r14d,0xca8(%rsp)
  77c327:	mov    %ebp,0xcac(%rsp)
  77c32e:	mov    %r12,%r14
  77c331:	cmp    $0xffff,%r15d
  77c338:	ja     77c34b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x15b>
  77c33a:	mov    %r15,0xf8(%rsp)
  77c342:	mov    %r15,%rax
  77c345:	shr    $0x30,%rax
  77c349:	je     77c36c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17c>
  77c34b:	mov    0x48(%rsp),%rax
  77c350:	movq   $0x23,(%rax)
  77c357:	movl   $0x0,0x8(%rax)
  77c35e:	cmp    $0x2,%ebx
  77c361:	jne    77da24 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1834>
  77c367:	jmp    77da31 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1841>
  77c36c:	cmpq   $0x0,0x2f8(%r13)
  77c374:	mov    %r13,0x40(%rsp)
  77c379:	je     77c38e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x19e>
  77c37b:	mov    0x6e8(%r13),%rax
  77c382:	test   %rax,%rax
  77c385:	je     77c3a3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1b3>
  77c387:	cmpq   $0x0,0x30(%rax)
  77c38c:	je     77c3f0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x200>
  77c38e:	mov    0x6e8(%r13),%rax
  77c395:	test   %rax,%rax
  77c398:	jne    77c4e5 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2f5>
  77c39e:	jmp    77c542 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x352>
  77c3a3:	call   *0x33dedf(%rip)        # aba288 <_DYNAMIC+0x248>
  77c3a9:	mov    $0x78,%edi
  77c3ae:	mov    $0x8,%esi
  77c3b3:	call   *0x33ded7(%rip)        # aba290 <_DYNAMIC+0x250>
  77c3b9:	test   %rax,%rax
  77c3bc:	je     780ff7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4e07>
  77c3c2:	movq   $0x0,(%rax)
  77c3c9:	movq   $0x8,0x8(%rax)
  77c3d1:	movq   $0x0,0x10(%rax)
  77c3d9:	movq   $0xffffffffffffffff,0x18(%rax)
  77c3e1:	movq   $0x0,0x30(%rax)
  77c3e9:	mov    %rax,0x6e8(%r13)
  77c3f0:	mov    %r14,%rbx
  77c3f3:	mov    $0x1,%bpl
  77c3f6:	lea    0x390(%rsp),%rdi
  77c3fe:	call   *0x33e3dc(%rip)        # aba7e0 <_DYNAMIC+0x7a0>
  77c404:	mov    0x390(%rsp),%r12
  77c40c:	mov    0x398(%rsp),%r14d
  77c414:	mov    0x39c(%rsp),%ebp
  77c41b:	test   %r12,%r12
  77c41e:	je     77d93d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x174d>
  77c424:	mov    0x3d0(%rsp),%rax
  77c42c:	mov    %rax,0x9a0(%rsp)
  77c434:	movups 0x3a0(%rsp),%xmm0
  77c43c:	movups 0x3b0(%rsp),%xmm1
  77c444:	movups 0x3c0(%rsp),%xmm2
  77c44c:	movaps %xmm2,0x990(%rsp)
  77c454:	movaps %xmm1,0x980(%rsp)
  77c45c:	movaps %xmm0,0x970(%rsp)
  77c464:	mov    0x6e8(%r13),%r15
  77c46b:	mov    0x30(%r15),%rax
  77c46f:	test   %rax,%rax
  77c472:	je     77c497 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2a7>
  77c474:	lock decq (%rax)
  77c478:	jne    77c484 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x294>
  77c47a:	lea    0x30(%r15),%rdi
  77c47e:	call   *0x33deec(%rip)        # aba370 <_DYNAMIC+0x330>
  77c484:	add    $0x38,%r15
  77c488:	mov    %r15,%rdi
  77c48b:	call   74cfd0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text11RasterCacheECs9C2G9YFESsD_29canonical_text_public_control>
  77c490:	mov    0x6e8(%r13),%r15
  77c497:	mov    %r12,0x30(%r15)
  77c49b:	mov    %r14d,0x38(%r15)
  77c49f:	mov    %ebp,0x3c(%r15)
  77c4a3:	movaps 0x970(%rsp),%xmm0
  77c4ab:	movaps 0x980(%rsp),%xmm1
  77c4b3:	movaps 0x990(%rsp),%xmm2
  77c4bb:	movups %xmm0,0x40(%r15)
  77c4c0:	movups %xmm1,0x50(%r15)
  77c4c5:	movups %xmm2,0x60(%r15)
  77c4ca:	mov    0x9a0(%rsp),%rax
  77c4d2:	mov    %rax,0x70(%r15)
  77c4d6:	mov    %rbx,%r14
  77c4d9:	mov    0x6e8(%r13),%rax
  77c4e0:	test   %rax,%rax
  77c4e3:	je     77c542 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x352>
  77c4e5:	mov    0x30(%rax),%rax
  77c4e9:	test   %rax,%rax
  77c4ec:	je     77c542 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x352>
  77c4ee:	lock incq (%rax)
  77c4f2:	jle    781378 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  77c4f8:	mov    %rax,0xd0(%rsp)
  77c500:	movq   $0x0,0x200(%rsp)
  77c50c:	movq   $0x8,0x208(%rsp)
  77c518:	movq   $0x0,0x210(%rsp)
  77c524:	lea    0xd0(%rsp),%rax
  77c52c:	mov    %rax,0x1c0(%rsp)
  77c534:	movq   $0x0,0x1c8(%rsp)
  77c540:	jmp    77c57e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x38e>
  77c542:	movq   $0x0,0xd0(%rsp)
  77c54e:	movq   $0x0,0x200(%rsp)
  77c55a:	movq   $0x8,0x208(%rsp)
  77c566:	movq   $0x0,0x210(%rsp)
  77c572:	movq   $0x0,0x1c0(%rsp)
  77c57e:	lea    0x778(%rsp),%rdi
  77c586:	mov    %r13,%rsi
  77c589:	call   76b6c0 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE16active_selectionBY_>
  77c58e:	lea    0x390(%rsp),%rdi
  77c596:	mov    %r13,%rsi
  77c599:	call   76b6c0 <_RNvMs0_NtNtCslbxve4rcJus_4gpui7runtime7editingINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE16active_selectionBY_>
  77c59e:	movzbl 0x3a4(%rsp),%eax
  77c5a6:	mov    %al,0x57(%rsp)
  77c5aa:	cmp    $0x2,%al
  77c5ac:	je     77c5fe <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x40e>
  77c5ae:	mov    0x390(%rsp),%rax
  77c5b6:	mov    %rax,0x678(%rsp)
  77c5be:	test   %rax,%rax
  77c5c1:	je     780fd9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4de9>
  77c5c7:	mov    0x3a0(%rsp),%eax
  77c5ce:	mov    %eax,0x2f0(%rsp)
  77c5d5:	mov    0x398(%rsp),%rax
  77c5dd:	mov    %rax,0x2e8(%rsp)
  77c5e5:	movzwl 0x3a5(%rsp),%eax
  77c5ed:	mov    %ax,0x7a(%rsp)
  77c5f2:	movzbl 0x3a7(%rsp),%eax
  77c5fa:	mov    %al,0x7c(%rsp)
  77c5fe:	lea    0x300(%r13),%rax
  77c605:	mov    %rax,0x58(%rsp)
  77c60a:	cmpb   $0x0,0x768(%r13)
  77c612:	mov    %r14,0x2e0(%rsp)
  77c61a:	jne    77c962 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x772>
  77c620:	cmpb   $0x0,0x769(%r13)
  77c628:	jne    77c962 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x772>
  77c62e:	cmpb   $0x0,0x590(%r13)
  77c636:	jne    77c962 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x772>
  77c63c:	mov    0x658(%r13),%rax
  77c643:	mov    0x668(%r13),%r15
  77c64a:	test   %rax,%rax
  77c64d:	setne  %cl
  77c650:	test   %r15,%r15
  77c653:	setne  %dl
  77c656:	and    %cl,%dl
  77c658:	cmp    $0x1,%dl
  77c65b:	jne    77cec4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xcd4>
  77c661:	mov    0x660(%r13),%r14
  77c668:	lea    0x1e8(%r13),%rcx
  77c66f:	mov    %rcx,0x30(%rsp)
  77c674:	lea    0x688(%r13),%rcx
  77c67b:	mov    %rcx,0x38(%rsp)
  77c680:	xor    %ebx,%ebx
  77c682:	lea    0x31f007(%rip),%rcx        # a9b690 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1ba8>
  77c689:	mov    %rcx,0x80(%rsp)
  77c691:	jmp    77c6c0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4d0>
  77c693:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  77c6a0:	mov    0x38(%rsp),%rdi
  77c6a5:	mov    %rbp,%rsi
  77c6a8:	call   77b170 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapyNtNtB7_7set_val9SetValZSTE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  77c6ad:	mov    $0x0,%eax
  77c6b2:	dec    %r15
  77c6b5:	mov    0x40(%rsp),%r13
  77c6ba:	je     77cec4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xcd4>
  77c6c0:	test   %rbx,%rbx
  77c6c3:	je     77c6e0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4f0>
  77c6c5:	movzwl 0x58a(%rbx),%ecx
  77c6cc:	cmp    %rcx,%r14
  77c6cf:	jae    77c790 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5a0>
  77c6d5:	mov    %rbx,%rcx
  77c6d8:	mov    %r14,%rdx
  77c6db:	jmp    77c7b6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5c6>
  77c6e0:	test   %r14,%r14
  77c6e3:	je     77c71d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x52d>
  77c6e5:	mov    %r14,%rcx
  77c6e8:	mov    %rax,%rbx
  77c6eb:	and    $0x7,%rcx
  77c6ef:	je     77c722 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x532>
  77c6f1:	xor    %edx,%edx
  77c6f3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  77c700:	mov    0x590(%rbx),%rbx
  77c707:	inc    %rdx
  77c70a:	cmp    %rdx,%rcx
  77c70d:	jne    77c700 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x510>
  77c70f:	mov    %r14,%rax
  77c712:	sub    %rdx,%rax
  77c715:	cmp    $0x8,%r14
  77c719:	jae    77c730 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x540>
  77c71b:	jmp    77c76e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57e>
  77c71d:	mov    %rax,%rbx
  77c720:	jmp    77c76e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57e>
  77c722:	mov    %r14,%rax
  77c725:	cmp    $0x8,%r14
  77c729:	jb     77c76e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57e>
  77c72b:	nopl   0x0(%rax,%rax,1)
  77c730:	mov    0x590(%rbx),%rcx
  77c737:	mov    0x590(%rcx),%rcx
  77c73e:	mov    0x590(%rcx),%rcx
  77c745:	mov    0x590(%rcx),%rcx
  77c74c:	mov    0x590(%rcx),%rcx
  77c753:	mov    0x590(%rcx),%rcx
  77c75a:	mov    0x590(%rcx),%rcx
  77c761:	mov    0x590(%rcx),%rbx
  77c768:	add    $0xfffffffffffffff8,%rax
  77c76c:	jne    77c730 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x540>
  77c76e:	xor    %eax,%eax
  77c770:	xor    %r14d,%r14d
  77c773:	movzwl 0x58a(%rbx),%ecx
  77c77a:	cmp    %rcx,%r14
  77c77d:	jb     77c6d5 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4e5>
  77c783:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  77c790:	mov    0x580(%rbx),%rcx
  77c797:	test   %rcx,%rcx
  77c79a:	je     78100f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4e1f>
  77c7a0:	inc    %rax
  77c7a3:	movzwl 0x588(%rbx),%edx
  77c7aa:	mov    %rcx,%rbx
  77c7ad:	cmp    0x58a(%rcx),%dx
  77c7b4:	jae    77c790 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5a0>
  77c7b6:	test   %rax,%rax
  77c7b9:	je     77c850 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x660>
  77c7bf:	lea    (%rcx,%rdx,8),%rsi
  77c7c3:	add    $0x598,%rsi
  77c7ca:	mov    %rax,%rdi
  77c7cd:	and    $0x7,%rdi
  77c7d1:	je     77c950 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x760>
  77c7d7:	xor    %r8d,%r8d
  77c7da:	nopw   0x0(%rax,%rax,1)
  77c7e0:	mov    (%rsi),%rbx
  77c7e3:	lea    0x590(%rbx),%rsi
  77c7ea:	inc    %r8
  77c7ed:	cmp    %r8,%rdi
  77c7f0:	jne    77c7e0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5f0>
  77c7f2:	mov    %rax,%rdi
  77c7f5:	sub    %r8,%rdi
  77c7f8:	cmp    $0x8,%rax
  77c7fc:	jb     77c841 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x651>
  77c7fe:	xchg   %ax,%ax
  77c800:	mov    (%rsi),%rax
  77c803:	mov    0x590(%rax),%rax
  77c80a:	mov    0x590(%rax),%rax
  77c811:	mov    0x590(%rax),%rax
  77c818:	mov    0x590(%rax),%rax
  77c81f:	mov    0x590(%rax),%rax
  77c826:	mov    0x590(%rax),%rax
  77c82d:	mov    0x590(%rax),%rbx
  77c834:	lea    0x590(%rbx),%rsi
  77c83b:	add    $0xfffffffffffffff8,%rdi
  77c83f:	jne    77c800 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x610>
  77c841:	xor    %r14d,%r14d
  77c844:	jmp    77c857 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x667>
  77c846:	cs nopw 0x0(%rax,%rax,1)
  77c850:	lea    0x1(%rdx),%r14
  77c854:	mov    %rcx,%rbx
  77c857:	imul   $0x70,%rdx,%rax
  77c85b:	shl    $0x4,%rdx
  77c85f:	lea    (%rcx,%rax,1),%rdi
  77c863:	add    $0xb0,%rdi
  77c86a:	mov    (%rcx,%rdx,1),%rsi
  77c86e:	mov    0x8(%rcx,%rdx,1),%rdx
  77c873:	call   *0x33db9f(%rip)        # aba418 <_DYNAMIC+0x3d8>
  77c879:	mov    %rax,%rbp
  77c87c:	mov    0x30(%rsp),%rdi
  77c881:	mov    %rax,%rsi
  77c884:	call   776220 <_RNvMs_NtNtCslbxve4rcJus_4gpui7runtime14identity_indexNtB4_13IdentityIndex8required>
  77c889:	mov    %rax,%r12
  77c88c:	mov    0x40(%rsp),%rax
  77c891:	mov    0x2e0(%rax),%r13
  77c898:	cmp    %r13,%r12
  77c89b:	jae    781207 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5017>
  77c8a1:	mov    0x2d8(%rax),%rcx
  77c8a8:	lea    (%r12,%r12,4),%rax
  77c8ac:	mov    0x18(%rcx,%rax,8),%r12d
  77c8b1:	mov    $0xffffffff,%eax
  77c8b6:	cmp    %rax,%r12
  77c8b9:	je     77c6ad <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4bd>
  77c8bf:	cmp    %r12,%r13
  77c8c2:	jbe    781169 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4f79>
  77c8c8:	mov    0x38(%rsp),%rax
  77c8cd:	mov    (%rax),%rax
  77c8d0:	test   %rax,%rax
  77c8d3:	je     77c6ad <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4bd>
  77c8d9:	lea    (%r12,%r12,4),%rdx
  77c8dd:	mov    (%rcx,%rdx,8),%rcx
  77c8e1:	mov    0x40(%rsp),%rdx
  77c8e6:	mov    0x690(%rdx),%rdx
  77c8ed:	movzwl 0x62(%rax),%edi
  77c8f1:	mov    %edi,%r8d
  77c8f4:	shl    $0x3,%r8d
  77c8f8:	mov    $0xffffffffffffffff,%rsi
  77c8ff:	nop
  77c900:	test   %r8,%r8
  77c903:	je     77c930 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x740>
  77c905:	cmp    0x10(%rax,%rsi,8),%rcx
  77c90a:	seta   %r9b
  77c90e:	sbb    $0x0,%r9b
  77c912:	inc    %rsi
  77c915:	add    $0xfffffffffffffff8,%r8
  77c919:	cmp    $0x1,%r9b
  77c91d:	je     77c900 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x710>
  77c91f:	movzbl %r9b,%edi
  77c923:	test   %edi,%edi
  77c925:	je     77c6a0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4b0>
  77c92b:	jmp    77c933 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x743>
  77c92d:	nopl   (%rax)
  77c930:	mov    %rdi,%rsi
  77c933:	sub    $0x1,%rdx
  77c937:	jb     77c6ad <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4bd>
  77c93d:	mov    0x68(%rax,%rsi,8),%rax
  77c942:	jmp    77c8ed <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x6fd>
  77c944:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  77c950:	mov    %rax,%rdi
  77c953:	cmp    $0x8,%rax
  77c957:	jae    77c800 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x610>
  77c95d:	jmp    77c841 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x651>
  77c962:	lea    0x390(%rsp),%rdi
  77c96a:	call   *0x33dc38(%rip)        # aba5a8 <_DYNAMIC+0x568>
  77c970:	lea    0x300(%r13),%r14
  77c977:	mov    %r14,%rdi
  77c97a:	call   74c550 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCscO85OU7Wpt0_20gpui_reactivity_core6layout10LayoutTreeECs9C2G9YFESsD_29canonical_text_public_control>
  77c97f:	lea    0x390(%rsp),%rsi
  77c987:	mov    $0x298,%edx
  77c98c:	mov    %r14,%rdi
  77c98f:	call   *0x33d90b(%rip)        # aba2a0 <memcpy@GLIBC_2.14>
  77c995:	movq   $0x0,0x5a8(%r13)
  77c9a0:	mov    0x2e0(%r13),%rax
  77c9a7:	test   %rax,%rax
  77c9aa:	je     77d496 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x12a6>
  77c9b0:	mov    0x40(%rsp),%rcx
  77c9b5:	lea    0x598(%rcx),%rdx
  77c9bc:	mov    %rdx,0x38(%rsp)
  77c9c1:	mov    0x2d8(%rcx),%rbx
  77c9c8:	lea    (%rax,%rax,4),%rax
  77c9cc:	lea    (%rbx,%rax,8),%rax
  77c9d0:	mov    %rax,0x30(%rsp)
  77c9d5:	xor    %r13d,%r13d
  77c9d8:	lea    -0x6b886b(%rip),%r14        # c4174 <GCC_except_table0+0x1d6c>
  77c9df:	lea    0x31d99a(%rip),%rax        # a9a380 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x898>
  77c9e6:	mov    %rax,0x80(%rsp)
  77c9ee:	xor    %ebp,%ebp
  77c9f0:	jmp    77ca3b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x84b>
  77c9f2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  77ca00:	add    $0x28,%rbx
  77ca04:	inc    %rbp
  77ca07:	mov    0x40(%rsp),%rdx
  77ca0c:	mov    0x5a0(%rdx),%rax
  77ca13:	mov    %r13,%rcx
  77ca16:	shl    $0x4,%rcx
  77ca1a:	movaps 0x950(%rsp),%xmm0
  77ca22:	movups %xmm0,(%rax,%rcx,1)
  77ca26:	inc    %r13
  77ca29:	mov    %r13,0x5a8(%rdx)
  77ca30:	cmp    0x30(%rsp),%rbx
  77ca35:	je     77d496 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x12a6>
  77ca3b:	mov    0x18(%rbx),%r12d
  77ca3f:	mov    $0xffffffff,%eax
  77ca44:	cmp    %rax,%r12
  77ca47:	je     77ca80 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x890>
  77ca49:	cmp    %r12,%r13
  77ca4c:	jbe    781207 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5017>
  77ca52:	mov    0x40(%rsp),%rax
  77ca57:	mov    0x5a0(%rax),%rax
  77ca5e:	mov    %r12,%rcx
  77ca61:	shl    $0x4,%rcx
  77ca65:	movups (%rax,%rcx,1),%xmm0
  77ca69:	lea    0xc68(%rsp),%rax
  77ca71:	movups %xmm0,(%rax)
  77ca74:	mov    $0x1,%eax
  77ca79:	jmp    77ca82 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x892>
  77ca7b:	nopl   0x0(%rax,%rax,1)
  77ca80:	xor    %eax,%eax
  77ca82:	mov    %rax,0xc60(%rsp)
  77ca8a:	mov    0x20(%rbx),%eax
  77ca8d:	and    $0xf,%eax
  77ca90:	cmp    $0xa,%eax
  77ca93:	jae    780fbb <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4dcb>
  77ca99:	lea    -0x6a98b7(%rip),%rcx        # d31e9 <GCC_except_table0+0x10de1>
  77caa0:	movzbl (%rax,%rcx,1),%r15d
  77caa5:	mov    0x40(%rsp),%rcx
  77caaa:	mov    0x200(%rcx),%rax
  77cab1:	movslq (%r14,%rax,4),%rax
  77cab5:	add    %r14,%rax
  77cab8:	jmp    *%rax
  77caba:	movups -0x6b85e5(%rip),%xmm0        # c44dc <GCC_except_table0+0x20d4>
  77cac1:	movaps %xmm0,0x9b0(%rsp)
  77cac9:	movups -0x6b8604(%rip),%xmm0        # c44cc <GCC_except_table0+0x20c4>
  77cad0:	movaps %xmm0,0x9a0(%rsp)
  77cad8:	movups -0x6b8623(%rip),%xmm0        # c44bc <GCC_except_table0+0x20b4>
  77cadf:	movaps %xmm0,0x990(%rsp)
  77cae7:	movups -0x6b8642(%rip),%xmm0        # c44ac <GCC_except_table0+0x20a4>
  77caee:	movaps %xmm0,0x980(%rsp)
  77caf6:	movups -0x6b8661(%rip),%xmm0        # c449c <GCC_except_table0+0x2094>
  77cafd:	movaps %xmm0,0x970(%rsp)
  77cb05:	movabs $0x3000100000000,%rax
  77cb0f:	mov    %rax,0x9c0(%rsp)
  77cb17:	cmp    $0xffffffff,%r12d
  77cb1b:	jne    77cbb1 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x9c1>
  77cb21:	jmp    77cc68 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xa78>
  77cb26:	mov    0x220(%rcx),%r13
  77cb2d:	cmp    %r13,%rbp
  77cb30:	jae    7811bd <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4fcd>
  77cb36:	mov    0x210(%rcx),%r13
  77cb3d:	mov    0x218(%rcx),%rax
  77cb44:	movzbl (%rax,%rbp,1),%eax
  77cb48:	cmp    %rax,%r13
  77cb4b:	jbe    7811c9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4fd9>
  77cb51:	mov    0x208(%rcx),%rcx
  77cb58:	imul   $0x58,%rax,%rax
  77cb5c:	mov    0x50(%rcx,%rax,1),%rdx
  77cb61:	mov    %rdx,0x9c0(%rsp)
  77cb69:	movups 0x40(%rcx,%rax,1),%xmm0
  77cb6e:	movaps %xmm0,0x9b0(%rsp)
  77cb76:	movups (%rcx,%rax,1),%xmm0
  77cb7a:	movups 0x10(%rcx,%rax,1),%xmm1
  77cb7f:	movups 0x20(%rcx,%rax,1),%xmm2
  77cb84:	movupd 0x30(%rcx,%rax,1),%xmm3
  77cb8a:	jmp    77cc3d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xa4d>
  77cb8f:	mov    0x208(%rcx),%rsi
  77cb96:	lea    0x970(%rsp),%rdi
  77cb9e:	mov    %rbp,%rdx
  77cba1:	call   *0x33d889(%rip)        # aba430 <_DYNAMIC+0x3f0>
  77cba7:	cmp    $0xffffffff,%r12d
  77cbab:	je     77cc68 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xa78>
  77cbb1:	mov    0x40(%rsp),%rdx
  77cbb6:	mov    0x200(%rdx),%rax
  77cbbd:	lea    -0x6b8a40(%rip),%rsi        # c4184 <GCC_except_table0+0x1d7c>
  77cbc4:	movslq (%rsi,%rax,4),%rcx
  77cbc8:	add    %rsi,%rcx
  77cbcb:	lea    -0x6b8736(%rip),%rax        # c449c <GCC_except_table0+0x2094>
  77cbd2:	jmp    *%rcx
  77cbd4:	mov    0x218(%rdx),%r13
  77cbdb:	cmp    %r12,%r13
  77cbde:	jbe    7811b4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4fc4>
  77cbe4:	imul   $0x58,%r12,%rax
  77cbe8:	add    0x210(%rdx),%rax
  77cbef:	jmp    77ccbe <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xace>
  77cbf4:	mov    0x218(%rcx),%r13
  77cbfb:	cmp    %r13,%rbp
  77cbfe:	jae    7811ce <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4fde>
  77cc04:	mov    0x210(%rcx),%rax
  77cc0b:	imul   $0x58,%rbp,%rcx
  77cc0f:	mov    0x50(%rax,%rcx,1),%rdx
  77cc14:	mov    %rdx,0x9c0(%rsp)
  77cc1c:	movups 0x40(%rax,%rcx,1),%xmm0
  77cc21:	movaps %xmm0,0x9b0(%rsp)
  77cc29:	movups (%rax,%rcx,1),%xmm0
  77cc2d:	movups 0x10(%rax,%rcx,1),%xmm1
  77cc32:	movups 0x20(%rax,%rcx,1),%xmm2
  77cc37:	movupd 0x30(%rax,%rcx,1),%xmm3
  77cc3d:	movapd %xmm3,0x9a0(%rsp)
  77cc46:	movaps %xmm2,0x990(%rsp)
  77cc4e:	movaps %xmm1,0x980(%rsp)
  77cc56:	movaps %xmm0,0x970(%rsp)
  77cc5e:	cmp    $0xffffffff,%r12d
  77cc62:	jne    77cbb1 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x9c1>
  77cc68:	mov    $0x2,%al
  77cc6a:	mov    0x40(%rsp),%rdx
  77cc6f:	mov    0x670(%rdx),%r8
  77cc76:	test   %r8,%r8
  77cc79:	jne    77cd3e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xb4e>
  77cc7f:	jmp    77cdd0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xbe0>
  77cc84:	mov    0x220(%rdx),%r13
  77cc8b:	cmp    %r12,%r13
  77cc8e:	jbe    7811ab <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4fbb>
  77cc94:	mov    %rdx,%rcx
  77cc97:	mov    0x210(%rdx),%r13
  77cc9e:	mov    0x218(%rdx),%rax
  77cca5:	movzbl (%rax,%r12,1),%r12d
  77ccaa:	cmp    %r12,%r13
  77ccad:	jbe    7811f8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5008>
  77ccb3:	imul   $0x58,%r12,%rax
  77ccb7:	add    0x208(%rcx),%rax
  77ccbe:	mov    0x50(%rax),%rcx
  77ccc2:	mov    %rcx,0x3e0(%rsp)
  77ccca:	movups 0x40(%rax),%xmm0
  77ccce:	movaps %xmm0,0x3d0(%rsp)
  77ccd6:	movups (%rax),%xmm0
  77ccd9:	movups 0x10(%rax),%xmm1
  77ccdd:	movups 0x20(%rax),%xmm2
  77cce1:	movupd 0x30(%rax),%xmm3
  77cce6:	movapd %xmm3,0x3c0(%rsp)
  77ccef:	movaps %xmm2,0x3b0(%rsp)
  77ccf7:	movaps %xmm1,0x3a0(%rsp)
  77ccff:	movaps %xmm0,0x390(%rsp)
  77cd07:	jmp    77cd21 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xb31>
  77cd09:	mov    0x208(%rdx),%rsi
  77cd10:	lea    0x390(%rsp),%rdi
  77cd18:	mov    %r12,%rdx
  77cd1b:	call   *0x33d70f(%rip)        # aba430 <_DYNAMIC+0x3f0>
  77cd21:	movzbl 0x3e4(%rsp),%eax
  77cd29:	mov    0x40(%rsp),%rdx
  77cd2e:	mov    0x670(%rdx),%r8
  77cd35:	test   %r8,%r8
  77cd38:	je     77cdd0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xbe0>
  77cd3e:	mov    (%rbx),%rcx
  77cd41:	mov    0x678(%rdx),%rdx
  77cd48:	movzwl 0x1c2(%r8),%edi
  77cd50:	mov    %edi,%r10d
  77cd53:	shl    $0x5,%r10d
  77cd57:	mov    $0xffffffffffffffff,%rsi
  77cd5e:	xor    %r9d,%r9d
  77cd61:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  77cd70:	mov    %r10,%r11
  77cd73:	add    %r9,%r11
  77cd76:	je     77cda0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xbb0>
  77cd78:	cmp    0x170(%r8,%rsi,8),%rcx
  77cd80:	seta   %r11b
  77cd84:	sbb    $0x0,%r11b
  77cd88:	add    $0xffffffffffffffe0,%r9
  77cd8c:	inc    %rsi
  77cd8f:	cmp    $0x1,%r11b
  77cd93:	je     77cd70 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xb80>
  77cd95:	movzbl %r11b,%edi
  77cd99:	test   %edi,%edi
  77cd9b:	jne    77cda3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xbb3>
  77cd9d:	jmp    77cdc0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xbd0>
  77cd9f:	nop
  77cda0:	mov    %rdi,%rsi
  77cda3:	sub    $0x1,%rdx
  77cda7:	jb     77cdd0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xbe0>
  77cda9:	mov    0x1c8(%r8,%rsi,8),%r8
  77cdb1:	jmp    77cd48 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xb58>
  77cdb3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  77cdc0:	sub    %r9,%r8
  77cdc3:	add    $0xffffffffffffffe0,%r8
  77cdc7:	jmp    77cdd3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xbe3>
  77cdc9:	nopl   0x0(%rax)
  77cdd0:	xor    %r8d,%r8d
  77cdd3:	movzbl %r15b,%esi
  77cdd7:	movzbl %al,%ecx
  77cdda:	lea    0x390(%rsp),%rdi
  77cde2:	lea    0x970(%rsp),%rdx
  77cdea:	call   *0x33d9f8(%rip)        # aba7e8 <_DYNAMIC+0x7a8>
  77cdf0:	lea    0x810(%rsp),%rdi
  77cdf8:	mov    0x58(%rsp),%rsi
  77cdfd:	lea    0xc60(%rsp),%rdx
  77ce05:	xor    %ecx,%ecx
  77ce07:	lea    0x390(%rsp),%r8
  77ce0f:	call   *0x33d9db(%rip)        # aba7f0 <_DYNAMIC+0x7b0>
  77ce15:	cmpb   $0x0,0x810(%rsp)
  77ce1d:	jne    77d9ad <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17bd>
  77ce23:	lea    0x818(%rsp),%rax
  77ce2b:	movups (%rax),%xmm0
  77ce2e:	lea    0x316(%rsp),%rax
  77ce36:	movups %xmm0,(%rax)
  77ce39:	movups (%rax),%xmm0
  77ce3c:	movaps %xmm0,0x950(%rsp)
  77ce44:	mov    0x20(%rbx),%ecx
  77ce47:	mov    %ecx,%eax
  77ce49:	and    $0xf,%eax
  77ce4c:	cmp    $0x9,%eax
  77ce4f:	ja     780fbb <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4dcb>
  77ce55:	cmp    $0x6,%eax
  77ce58:	je     77ce6a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xc7a>
  77ce5a:	cmp    $0x10,%ecx
  77ce5d:	setae  %cl
  77ce60:	cmp    $0x6,%eax
  77ce63:	sete   %al
  77ce66:	or     %cl,%al
  77ce68:	je     77ce9c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xcac>
  77ce6a:	movaps 0x950(%rsp),%xmm0
  77ce72:	movaps %xmm0,0x390(%rsp)
  77ce7a:	mov    0x58(%rsp),%rdi
  77ce7f:	lea    0x390(%rsp),%rsi
  77ce87:	mov    0x33d96a(%rip),%rdx        # aba7f8 <_DYNAMIC+0x7b8>
  77ce8e:	call   *0x33d96c(%rip)        # aba800 <_DYNAMIC+0x7c0>
  77ce94:	test   $0x1,%al
  77ce96:	jne    77d99c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17ac>
  77ce9c:	mov    0x40(%rsp),%rax
  77cea1:	mov    0x5a8(%rax),%r13
  77cea8:	cmp    0x598(%rax),%r13
  77ceaf:	jne    77ca00 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x810>
  77ceb5:	mov    0x38(%rsp),%rdi
  77ceba:	call   772980 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecAINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtCslbxve4rcJus_4gpui6source7FieldIdEj2_E8grow_oneCs9C2G9YFESsD_29canonical_text_public_control>
  77cebf:	jmp    77ca00 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x810>
  77cec4:	mov    0x688(%r13),%rax
  77cecb:	mov    0x698(%r13),%rdi
  77ced2:	test   %rax,%rax
  77ced5:	setne  %cl
  77ced8:	test   %rdi,%rdi
  77cedb:	setne  %dl
  77cede:	and    %cl,%dl
  77cee0:	cmp    $0x1,%dl
  77cee3:	jne    77d496 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x12a6>
  77cee9:	mov    0x40(%rsp),%rcx
  77ceee:	mov    0x690(%rcx),%rbx
  77cef5:	add    $0x1e8,%rcx
  77cefc:	mov    %rcx,0xc0(%rsp)
  77cf04:	xor    %ebp,%ebp
  77cf06:	lea    0x31e73b(%rip),%rcx        # a9b648 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1b60>
  77cf0d:	mov    %rcx,0x80(%rsp)
  77cf15:	data16 cs nopw 0x0(%rax,%rax,1)
  77cf20:	test   %rbp,%rbp
  77cf23:	je     77cf3f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xd4f>
  77cf25:	mov    0x40(%rsp),%r14
  77cf2a:	movzwl 0x62(%rbp),%ecx
  77cf2e:	cmp    %rcx,%rbx
  77cf31:	jae    77cfd0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xde0>
  77cf37:	mov    %rbp,%r15
  77cf3a:	jmp    77cfee <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xdfe>
  77cf3f:	test   %rbx,%rbx
  77cf42:	mov    0x40(%rsp),%r14
  77cf47:	je     77cf7a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xd8a>
  77cf49:	mov    %rbx,%rcx
  77cf4c:	mov    %rax,%rbp
  77cf4f:	and    $0x7,%rcx
  77cf53:	je     77cf7f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xd8f>
  77cf55:	xor    %edx,%edx
  77cf57:	nopw   0x0(%rax,%rax,1)
  77cf60:	mov    0x68(%rbp),%rbp
  77cf64:	inc    %rdx
  77cf67:	cmp    %rdx,%rcx
  77cf6a:	jne    77cf60 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xd70>
  77cf6c:	mov    %rbx,%rax
  77cf6f:	sub    %rdx,%rax
  77cf72:	cmp    $0x8,%rbx
  77cf76:	jae    77cf90 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xda0>
  77cf78:	jmp    77cfb6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xdc6>
  77cf7a:	mov    %rax,%rbp
  77cf7d:	jmp    77cfb6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xdc6>
  77cf7f:	mov    %rbx,%rax
  77cf82:	cmp    $0x8,%rbx
  77cf86:	jb     77cfb6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xdc6>
  77cf88:	nopl   0x0(%rax,%rax,1)
  77cf90:	mov    0x68(%rbp),%rcx
  77cf94:	mov    0x68(%rcx),%rcx
  77cf98:	mov    0x68(%rcx),%rcx
  77cf9c:	mov    0x68(%rcx),%rcx
  77cfa0:	mov    0x68(%rcx),%rcx
  77cfa4:	mov    0x68(%rcx),%rcx
  77cfa8:	mov    0x68(%rcx),%rcx
  77cfac:	mov    0x68(%rcx),%rbp
  77cfb0:	add    $0xfffffffffffffff8,%rax
  77cfb4:	jne    77cf90 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xda0>
  77cfb6:	xor    %eax,%eax
  77cfb8:	xor    %ebx,%ebx
  77cfba:	movzwl 0x62(%rbp),%ecx
  77cfbe:	cmp    %rcx,%rbx
  77cfc1:	jb     77cf37 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xd47>
  77cfc7:	nopw   0x0(%rax,%rax,1)
  77cfd0:	mov    0x0(%rbp),%r15
  77cfd4:	test   %r15,%r15
  77cfd7:	je     78105b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4e6b>
  77cfdd:	inc    %rax
  77cfe0:	movzwl 0x60(%rbp),%ebx
  77cfe4:	mov    %r15,%rbp
  77cfe7:	cmp    0x62(%r15),%bx
  77cfec:	jae    77cfd0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xde0>
  77cfee:	test   %rax,%rax
  77cff1:	mov    %rdi,0x38(%rsp)
  77cff6:	je     77d067 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xe77>
  77cff8:	lea    (%r15,%rbx,8),%rcx
  77cffc:	add    $0x70,%rcx
  77d000:	mov    %rax,%rdx
  77d003:	and    $0x7,%rdx
  77d007:	je     77d2b6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x10c6>
  77d00d:	xor    %esi,%esi
  77d00f:	nop
  77d010:	mov    (%rcx),%rbp
  77d013:	lea    0x68(%rbp),%rcx
  77d017:	inc    %rsi
  77d01a:	cmp    %rsi,%rdx
  77d01d:	jne    77d010 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xe20>
  77d01f:	mov    %rax,%rdx
  77d022:	sub    %rsi,%rdx
  77d025:	cmp    $0x8,%rax
  77d029:	jb     77d059 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xe69>
  77d02b:	nopl   0x0(%rax,%rax,1)
  77d030:	mov    (%rcx),%rax
  77d033:	mov    0x68(%rax),%rax
  77d037:	mov    0x68(%rax),%rax
  77d03b:	mov    0x68(%rax),%rax
  77d03f:	mov    0x68(%rax),%rax
  77d043:	mov    0x68(%rax),%rax
  77d047:	mov    0x68(%rax),%rax
  77d04b:	mov    0x68(%rax),%rbp
  77d04f:	lea    0x68(%rbp),%rcx
  77d053:	add    $0xfffffffffffffff8,%rdx
  77d057:	jne    77d030 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xe40>
  77d059:	movq   $0x0,0xa8(%rsp)
  77d065:	jmp    77d076 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xe86>
  77d067:	lea    0x1(%rbx),%rax
  77d06b:	mov    %rax,0xa8(%rsp)
  77d073:	mov    %r15,%rbp
  77d076:	mov    0x8(%r15,%rbx,8),%rsi
  77d07b:	mov    0xc0(%rsp),%rdi
  77d083:	call   776220 <_RNvMs_NtNtCslbxve4rcJus_4gpui7runtime14identity_indexNtB4_13IdentityIndex8required>
  77d088:	mov    %rax,%r12
  77d08b:	mov    0x5a8(%r14),%r13
  77d092:	cmp    %r13,%rax
  77d095:	jae    781207 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5017>
  77d09b:	mov    0x5a0(%r14),%rax
  77d0a2:	mov    %r12,%rcx
  77d0a5:	shl    $0x4,%rcx
  77d0a9:	movups (%rax,%rcx,1),%xmm0
  77d0ad:	movaps %xmm0,0x310(%rsp)
  77d0b5:	mov    0x2e0(%r14),%r13
  77d0bc:	cmp    %r13,%r12
  77d0bf:	jae    781199 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4fa9>
  77d0c5:	mov    0x2d8(%r14),%rax
  77d0cc:	lea    (%r12,%r12,4),%rsi
  77d0d0:	mov    0x20(%rax,%rsi,8),%eax
  77d0d4:	and    $0xf,%eax
  77d0d7:	cmp    $0xa,%eax
  77d0da:	jae    780fbb <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4dcb>
  77d0e0:	lea    -0x6a9efe(%rip),%rcx        # d31e9 <GCC_except_table0+0x10de1>
  77d0e7:	movzbl (%rax,%rcx,1),%eax
  77d0eb:	mov    %al,0x30(%rsp)
  77d0ef:	mov    0x40(%rsp),%r14
  77d0f4:	mov    0x200(%r14),%rax
  77d0fb:	lea    -0x6b8fae(%rip),%rcx        # c4154 <GCC_except_table0+0x1d4c>
  77d102:	movslq (%rcx,%rax,4),%rax
  77d106:	add    %rcx,%rax
  77d109:	jmp    *%rax
  77d10b:	movups -0x6b8c36(%rip),%xmm0        # c44dc <GCC_except_table0+0x20d4>
  77d112:	movaps %xmm0,0x9b0(%rsp)
  77d11a:	movups -0x6b8c55(%rip),%xmm0        # c44cc <GCC_except_table0+0x20c4>
  77d121:	movaps %xmm0,0x9a0(%rsp)
  77d129:	movups -0x6b8c74(%rip),%xmm0        # c44bc <GCC_except_table0+0x20b4>
  77d130:	movaps %xmm0,0x990(%rsp)
  77d138:	movups -0x6b8c93(%rip),%xmm0        # c44ac <GCC_except_table0+0x20a4>
  77d13f:	movaps %xmm0,0x980(%rsp)
  77d147:	movups -0x6b8cb2(%rip),%xmm0        # c449c <GCC_except_table0+0x2094>
  77d14e:	movaps %xmm0,0x970(%rsp)
  77d156:	movabs $0x3000100000000,%rax
  77d160:	mov    %rax,0x9c0(%rsp)
  77d168:	jmp    77d235 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1045>
  77d16d:	mov    0x220(%r14),%rax
  77d174:	cmp    %rax,%r12
  77d177:	jae    7811e6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4ff6>
  77d17d:	mov    0x210(%r14),%rax
  77d184:	mov    0x218(%r14),%rcx
  77d18b:	movzbl (%rcx,%r12,1),%ecx
  77d190:	cmp    %rcx,%rax
  77d193:	jbe    7811f2 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5002>
  77d199:	mov    0x208(%r14),%rax
  77d1a0:	imul   $0x58,%rcx,%rcx
  77d1a4:	jmp    77d1e6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xff6>
  77d1a6:	mov    0x208(%r14),%rsi
  77d1ad:	lea    0x970(%rsp),%rdi
  77d1b5:	mov    %r12,%rdx
  77d1b8:	call   *0x33d272(%rip)        # aba430 <_DYNAMIC+0x3f0>
  77d1be:	mov    0x2e0(%r14),%r13
  77d1c5:	lea    (%r12,%r12,4),%rsi
  77d1c9:	jmp    77d235 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1045>
  77d1cb:	mov    0x218(%r14),%rax
  77d1d2:	cmp    %rax,%r12
  77d1d5:	jae    7811da <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4fea>
  77d1db:	mov    0x210(%r14),%rax
  77d1e2:	imul   $0x58,%r12,%rcx
  77d1e6:	mov    0x50(%rax,%rcx,1),%rdx
  77d1eb:	mov    %rdx,0x9c0(%rsp)
  77d1f3:	movups 0x40(%rax,%rcx,1),%xmm0
  77d1f8:	movaps %xmm0,0x9b0(%rsp)
  77d200:	movups (%rax,%rcx,1),%xmm0
  77d204:	movups 0x10(%rax,%rcx,1),%xmm1
  77d209:	movups 0x20(%rax,%rcx,1),%xmm2
  77d20e:	movupd 0x30(%rax,%rcx,1),%xmm3
  77d214:	movapd %xmm3,0x9a0(%rsp)
  77d21d:	movaps %xmm2,0x990(%rsp)
  77d225:	movaps %xmm1,0x980(%rsp)
  77d22d:	movaps %xmm0,0x970(%rsp)
  77d235:	cmp    %r13,%r12
  77d238:	jae    7811a2 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4fb2>
  77d23e:	mov    0x40(%rsp),%r13
  77d243:	mov    0x2d8(%r13),%rax
  77d24a:	mov    0x18(%rax,%rsi,8),%r12d
  77d24f:	mov    $0xffffffff,%eax
  77d254:	cmp    %rax,%r12
  77d257:	je     77d297 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x10a7>
  77d259:	mov    0x200(%r13),%rax
  77d260:	lea    -0x6b9103(%rip),%rdx        # c4164 <GCC_except_table0+0x1d5c>
  77d267:	movslq (%rdx,%rax,4),%rcx
  77d26b:	add    %rdx,%rcx
  77d26e:	lea    -0x6b8dd9(%rip),%rax        # c449c <GCC_except_table0+0x2094>
  77d275:	jmp    *%rcx
  77d277:	mov    %r13,%rcx
  77d27a:	mov    0x218(%r13),%r13
  77d281:	cmp    %r12,%r13
  77d284:	jbe    7811b4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4fc4>
  77d28a:	imul   $0x58,%r12,%rax
  77d28e:	add    0x210(%rcx),%rax
  77d295:	jmp    77d302 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1112>
  77d297:	mov    $0x2,%al
  77d299:	mov    0x670(%r13),%r8
  77d2a0:	test   %r8,%r8
  77d2a3:	jne    77d380 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1190>
  77d2a9:	xor    %r8d,%r8d
  77d2ac:	movzbl 0x30(%rsp),%ebx
  77d2b1:	jmp    77d407 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1217>
  77d2b6:	mov    %rax,%rdx
  77d2b9:	cmp    $0x8,%rax
  77d2bd:	jae    77d030 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xe40>
  77d2c3:	jmp    77d059 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xe69>
  77d2c8:	mov    %r13,%rcx
  77d2cb:	mov    0x220(%r13),%r13
  77d2d2:	cmp    %r12,%r13
  77d2d5:	jbe    7811ab <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4fbb>
  77d2db:	mov    0x210(%rcx),%r13
  77d2e2:	mov    0x218(%rcx),%rax
  77d2e9:	movzbl (%rax,%r12,1),%r12d
  77d2ee:	cmp    %r12,%r13
  77d2f1:	jbe    7811f8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5008>
  77d2f7:	imul   $0x58,%r12,%rax
  77d2fb:	add    0x208(%rcx),%rax
  77d302:	mov    %rcx,%r13
  77d305:	mov    0x50(%rax),%rcx
  77d309:	mov    %rcx,0x3e0(%rsp)
  77d311:	movups 0x40(%rax),%xmm0
  77d315:	movaps %xmm0,0x3d0(%rsp)
  77d31d:	movups (%rax),%xmm0
  77d320:	movups 0x10(%rax),%xmm1
  77d324:	movups 0x20(%rax),%xmm2
  77d328:	movupd 0x30(%rax),%xmm3
  77d32d:	movapd %xmm3,0x3c0(%rsp)
  77d336:	movaps %xmm2,0x3b0(%rsp)
  77d33e:	movaps %xmm1,0x3a0(%rsp)
  77d346:	movaps %xmm0,0x390(%rsp)
  77d34e:	jmp    77d368 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1178>
  77d350:	mov    0x208(%r13),%rsi
  77d357:	lea    0x390(%rsp),%rdi
  77d35f:	mov    %r12,%rdx
  77d362:	call   *0x33d0c8(%rip)        # aba430 <_DYNAMIC+0x3f0>
  77d368:	movzbl 0x3e4(%rsp),%eax
  77d370:	mov    0x670(%r13),%r8
  77d377:	test   %r8,%r8
  77d37a:	je     77d2a9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x10b9>
  77d380:	mov    0x8(%r15,%rbx,8),%rcx
  77d385:	mov    0x678(%r13),%rdx
  77d38c:	movzbl 0x30(%rsp),%ebx
  77d391:	movzwl 0x1c2(%r8),%edi
  77d399:	mov    %edi,%r10d
  77d39c:	shl    $0x5,%r10d
  77d3a0:	mov    $0xffffffffffffffff,%rsi
  77d3a7:	xor    %r9d,%r9d
  77d3aa:	nopw   0x0(%rax,%rax,1)
  77d3b0:	mov    %r10,%r11
  77d3b3:	add    %r9,%r11
  77d3b6:	je     77d3e0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x11f0>
  77d3b8:	cmp    0x170(%r8,%rsi,8),%rcx
  77d3c0:	seta   %r11b
  77d3c4:	sbb    $0x0,%r11b
  77d3c8:	add    $0xffffffffffffffe0,%r9
  77d3cc:	inc    %rsi
  77d3cf:	cmp    $0x1,%r11b
  77d3d3:	je     77d3b0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x11c0>
  77d3d5:	movzbl %r11b,%edi
  77d3d9:	test   %edi,%edi
  77d3db:	jne    77d3e3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x11f3>
  77d3dd:	jmp    77d400 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1210>
  77d3df:	nop
  77d3e0:	mov    %rdi,%rsi
  77d3e3:	sub    $0x1,%rdx
  77d3e7:	jb     77d48e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x129e>
  77d3ed:	mov    0x1c8(%r8,%rsi,8),%r8
  77d3f5:	jmp    77d391 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x11a1>
  77d3f7:	nopw   0x0(%rax,%rax,1)
  77d400:	sub    %r9,%r8
  77d403:	add    $0xffffffffffffffe0,%r8
  77d407:	movzbl %bl,%esi
  77d40a:	movzbl %al,%ecx
  77d40d:	lea    0x390(%rsp),%rdi
  77d415:	lea    0x970(%rsp),%rdx
  77d41d:	call   *0x33d3c5(%rip)        # aba7e8 <_DYNAMIC+0x7a8>
  77d423:	movaps 0x310(%rsp),%xmm0
  77d42b:	movaps %xmm0,0x810(%rsp)
  77d433:	mov    0x58(%rsp),%rdi
  77d438:	lea    0x810(%rsp),%rsi
  77d440:	lea    0x390(%rsp),%rdx
  77d448:	call   *0x33d3ba(%rip)        # aba808 <_DYNAMIC+0x7c8>
  77d44e:	test   $0x1,%al
  77d450:	jne    77d99c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17ac>
  77d456:	mov    0x58(%rsp),%rdi
  77d45b:	lea    0x310(%rsp),%rsi
  77d463:	call   *0x33d2f7(%rip)        # aba760 <_DYNAMIC+0x720>
  77d469:	cmp    $0xff,%al
  77d46b:	jne    77d9b5 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17c5>
  77d471:	mov    $0x0,%eax
  77d476:	mov    0x38(%rsp),%rdi
  77d47b:	dec    %rdi
  77d47e:	mov    0xa8(%rsp),%rbx
  77d486:	jne    77cf20 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0xd30>
  77d48c:	jmp    77d496 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x12a6>
  77d48e:	xor    %r8d,%r8d
  77d491:	jmp    77d407 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1217>
  77d496:	mov    0x40(%rsp),%r15
  77d49b:	lea    0x2e8(%r15),%rax
  77d4a2:	mov    0x558(%r15),%r14
  77d4a9:	mov    0x578(%r15),%rbx
  77d4b0:	lea    0x598(%r15),%rcx
  77d4b7:	movq   $0xfffffffffffffffe,0x7c8(%rsp)
  77d4c3:	lea    0x2d0(%r15),%rdx
  77d4ca:	lea    0x200(%r15),%rsi
  77d4d1:	lea    0x600(%r15),%r13
  77d4d8:	mov    %rcx,0xbe8(%rsp)
  77d4e0:	mov    %rdx,0xbf0(%rsp)
  77d4e8:	mov    %r13,0xbf8(%rsp)
  77d4f0:	lea    0x1c0(%rsp),%rcx
  77d4f8:	mov    %rcx,0xc00(%rsp)
  77d500:	mov    %rax,0xc08(%rsp)
  77d508:	mov    %rsi,0xa8(%rsp)
  77d510:	mov    %rsi,0xc10(%rsp)
  77d518:	lea    0x7c8(%rsp),%rax
  77d520:	mov    %rax,0xc18(%rsp)
  77d528:	cmpq   $0x0,0x5a8(%r15)
  77d530:	je     781220 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5030>
  77d536:	mov    0x5a0(%r15),%rax
  77d53d:	movups (%rax),%xmm0
  77d540:	movaps %xmm0,0x970(%rsp)
  77d548:	xorps  %xmm0,%xmm0
  77d54b:	cvtsi2ssl 0xf8(%rsp),%xmm0
  77d554:	movaps %xmm0,0xc0(%rsp)
  77d55c:	cvtsi2ssl 0x2e0(%rsp),%xmm1
  77d565:	movss  0x9c(%rsp),%xmm2
  77d56e:	divss  %xmm2,%xmm0
  77d572:	movaps %xmm1,0x80(%rsp)
  77d57a:	divss  %xmm2,%xmm1
  77d57e:	movl   $0x0,0x390(%rsp)
  77d589:	movss  %xmm0,0x394(%rsp)
  77d592:	movl   $0x0,0x398(%rsp)
  77d59d:	movss  %xmm1,0x39c(%rsp)
  77d5a6:	mov    $0x1,%r12b
  77d5a9:	lea    0x31e110(%rip),%r8        # a9b6c0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1bd8>
  77d5b0:	lea    0x970(%rsp),%rsi
  77d5b8:	lea    0x390(%rsp),%rdx
  77d5c0:	lea    0xbe8(%rsp),%rcx
  77d5c8:	mov    $0x1,%bpl
  77d5cb:	mov    0x58(%rsp),%rdi
  77d5d0:	call   *0x33d23a(%rip)        # aba810 <_DYNAMIC+0x7d0>
  77d5d6:	test   $0x1,%al
  77d5d8:	je     77d640 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1450>
  77d5da:	mov    0x48(%rsp),%rax
  77d5df:	movq   $0x22,(%rax)
  77d5e6:	mov    %dl,0x8(%rax)
  77d5e9:	mov    0x7c8(%rsp),%rax
  77d5f1:	mov    $0x1,%r12b
  77d5f4:	mov    $0x1,%bpl
  77d5f7:	cmp    $0xfffffffffffffffe,%rax
  77d5fb:	je     77d9ca <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17da>
  77d601:	sub    $0xd,%rax
  77d605:	mov    $0x14,%ecx
  77d60a:	cmovge %rax,%rcx
  77d60e:	cmp    $0x14,%rcx
  77d612:	je     77da7c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x188c>
  77d618:	cmp    $0x19,%rcx
  77d61c:	jne    77d9ca <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17da>
  77d622:	mov    0x7d0(%rsp),%rsi
  77d62a:	test   %rsi,%rsi
  77d62d:	je     77d9ca <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17da>
  77d633:	lea    0x7d8(%rsp),%rax
  77d63b:	jmp    77da95 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x18a5>
  77d640:	mov    0x558(%r15),%rax
  77d647:	sub    %r14,%rax
  77d64a:	mov    0x578(%r15),%rcx
  77d651:	add    %rax,0x728(%r15)
  77d658:	sub    %rbx,%rcx
  77d65b:	add    %rcx,0x730(%r15)
  77d662:	cmpl   $0xfffffffe,0x7c8(%rsp)
  77d66a:	jne    77d966 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1776>
  77d670:	lea    0x390(%rsp),%rdi
  77d678:	mov    $0x1,%bpl
  77d67b:	mov    %r15,%rsi
  77d67e:	mov    $0x1,%edx
  77d683:	call   7714a0 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime9inspectorINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE17refresh_inspectorB10_>
  77d688:	cmpl   $0xfffffffe,0x390(%rsp)
  77d690:	jne    77da43 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1853>
  77d696:	mov    0x2e0(%r15),%rsi
  77d69d:	lea    0x390(%rsp),%rdi
  77d6a5:	mov    $0x8,%ecx
  77d6aa:	mov    $0x40,%r8d
  77d6b0:	xor    %edx,%edx
  77d6b2:	call   772fe0 <_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCs9C2G9YFESsD_29canonical_text_public_control>
  77d6b7:	mov    0x398(%rsp),%rdi
  77d6bf:	cmpl   $0x1,0x390(%rsp)
  77d6c7:	je     78108d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4e9d>
  77d6cd:	mov    0x3a0(%rsp),%rax
  77d6d5:	mov    %rdi,0x140(%rsp)
  77d6dd:	mov    %rax,0x148(%rsp)
  77d6e5:	movq   $0x0,0x150(%rsp)
  77d6f1:	movq   $0x0,0x268(%rsp)
  77d6fd:	movq   $0x4,0x270(%rsp)
  77d709:	movq   $0x0,0x278(%rsp)
  77d715:	mov    0x2e0(%r15),%rsi
  77d71c:	lea    0x390(%rsp),%rdi
  77d724:	mov    $0x8,%ecx
  77d729:	mov    $0x38,%r8d
  77d72f:	xor    %edx,%edx
  77d731:	call   772fe0 <_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCs9C2G9YFESsD_29canonical_text_public_control>
  77d736:	mov    0x398(%rsp),%rdi
  77d73e:	cmpb   $0x0,0x390(%rsp)
  77d746:	jne    7810a3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4eb3>
  77d74c:	mov    0x3a0(%rsp),%rax
  77d754:	mov    %rdi,0x1d8(%rsp)
  77d75c:	mov    %rax,0x1e0(%rsp)
  77d764:	movq   $0x0,0x1e8(%rsp)
  77d770:	mov    0x668(%r15),%rbx
  77d777:	test   %rbx,%rbx
  77d77a:	setne  0x2f(%rsp)
  77d77f:	je     77d788 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1598>
  77d781:	mov    0x2e0(%r15),%rbx
  77d788:	lea    0x390(%rsp),%rdi
  77d790:	mov    $0x4,%ecx
  77d795:	mov    $0x10,%r8d
  77d79b:	mov    %rbx,%rsi
  77d79e:	xor    %edx,%edx
  77d7a0:	call   772fe0 <_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCs9C2G9YFESsD_29canonical_text_public_control>
  77d7a5:	mov    0x398(%rsp),%rdi
  77d7ad:	cmpb   $0x0,0x390(%rsp)
  77d7b5:	jne    7810b6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4ec6>
  77d7bb:	mov    0x3a0(%rsp),%rax
  77d7c3:	mov    %rdi,0x218(%rsp)
  77d7cb:	mov    %rax,0x220(%rsp)
  77d7d3:	movq   $0x0,0x228(%rsp)
  77d7df:	lea    0x390(%rsp),%rdi
  77d7e7:	mov    $0x4,%ecx
  77d7ec:	mov    $0x10,%r8d
  77d7f2:	mov    %rbx,%rsi
  77d7f5:	xor    %edx,%edx
  77d7f7:	call   772fe0 <_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCs9C2G9YFESsD_29canonical_text_public_control>
  77d7fc:	mov    0x398(%rsp),%rdi
  77d804:	cmpb   $0x0,0x390(%rsp)
  77d80c:	jne    7810c9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4ed9>
  77d812:	mov    0x3a0(%rsp),%rax
  77d81a:	mov    %rdi,0x230(%rsp)
  77d822:	mov    %rax,0x238(%rsp)
  77d82a:	movq   $0x0,0x240(%rsp)
  77d836:	lea    0x390(%rsp),%rdi
  77d83e:	mov    $0x1,%ecx
  77d843:	mov    $0x1,%r8d
  77d849:	mov    %rbx,%rsi
  77d84c:	xor    %edx,%edx
  77d84e:	call   772fe0 <_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCs9C2G9YFESsD_29canonical_text_public_control>
  77d853:	mov    0x398(%rsp),%rdi
  77d85b:	cmpb   $0x0,0x390(%rsp)
  77d863:	jne    7810dc <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4eec>
  77d869:	mov    0x3a0(%rsp),%rax
  77d871:	mov    %rdi,0x158(%rsp)
  77d879:	mov    %rax,0x160(%rsp)
  77d881:	movq   $0x0,0x168(%rsp)
  77d88d:	lea    0x390(%rsp),%rdi
  77d895:	mov    $0x4,%ecx
  77d89a:	mov    $0x4,%r8d
  77d8a0:	mov    %rbx,%rsi
  77d8a3:	xor    %edx,%edx
  77d8a5:	call   772fe0 <_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCs9C2G9YFESsD_29canonical_text_public_control>
  77d8aa:	mov    0x398(%rsp),%rdi
  77d8b2:	cmpb   $0x0,0x390(%rsp)
  77d8ba:	jne    7810ef <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4eff>
  77d8c0:	mov    %r13,0x2d8(%rsp)
  77d8c8:	mov    0x3a0(%rsp),%rax
  77d8d0:	mov    %rdi,0x100(%rsp)
  77d8d8:	mov    %rax,0x108(%rsp)
  77d8e0:	movq   $0x0,0x110(%rsp)
  77d8ec:	movq   $0x0,0x6a8(%rsp)
  77d8f8:	movq   $0x0,0x6b8(%rsp)
  77d904:	mov    0x650(%r15),%rcx
  77d90b:	test   %rcx,%rcx
  77d90e:	je     77daa8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x18b8>
  77d914:	mov    0x2e0(%r15),%rsi
  77d91b:	mov    0x680(%r15),%rdx
  77d922:	mov    $0x1,%r12b
  77d925:	lea    0x810(%rsp),%rdi
  77d92d:	mov    $0x1,%r13b
  77d930:	mov    $0x1,%bpl
  77d933:	call   75cea0 <_RNCNvMs1_NtNtCslbxve4rcJus_4gpui7runtime8metadataINtB9_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE14metadata_sheet0B11_>
  77d938:	jmp    77dab4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x18c4>
  77d93d:	mov    0x48(%rsp),%rax
  77d942:	movq   $0x23,(%rax)
  77d949:	mov    %r14d,0x8(%rax)
  77d94d:	mov    %ebp,0xc(%rax)
  77d950:	mov    0xca0(%rsp),%rbx
  77d958:	cmp    $0x2,%ebx
  77d95b:	jne    77da24 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1834>
  77d961:	jmp    77da31 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1841>
  77d966:	mov    0x7f8(%rsp),%rax
  77d96e:	mov    0x48(%rsp),%rcx
  77d973:	mov    %rax,0x30(%rcx)
  77d977:	movups 0x7c8(%rsp),%xmm0
  77d97f:	movups 0x7d8(%rsp),%xmm1
  77d987:	movups 0x7e8(%rsp),%xmm2
  77d98f:	movups %xmm2,0x20(%rcx)
  77d993:	movups %xmm1,0x10(%rcx)
  77d997:	movups %xmm0,(%rcx)
  77d99a:	jmp    77d9c4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17d4>
  77d99c:	mov    0x48(%rsp),%rax
  77d9a1:	movq   $0x22,(%rax)
  77d9a8:	mov    %dl,0x8(%rax)
  77d9ab:	jmp    77d9c4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17d4>
  77d9ad:	movzbl 0x811(%rsp),%eax
  77d9b5:	mov    0x48(%rsp),%rcx
  77d9ba:	movq   $0x22,(%rcx)
  77d9c1:	mov    %al,0x8(%rcx)
  77d9c4:	mov    $0x1,%r12b
  77d9c7:	mov    $0x1,%bpl
  77d9ca:	cmpq   $0x0,0x1c0(%rsp)
  77d9d3:	je     77d9e2 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17f2>
  77d9d5:	mov    0x1c8(%rsp),%rdi
  77d9dd:	call   74cd80 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text10TextShaperECs9C2G9YFESsD_29canonical_text_public_control>
  77d9e2:	test   %r12b,%r12b
  77d9e5:	je     77d9f4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1804>
  77d9e7:	lea    0x200(%rsp),%rdi
  77d9ef:	call   747950 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime13text_geometry5EntryEECs9C2G9YFESsD_29canonical_text_public_control>
  77d9f4:	mov    0xd0(%rsp),%rax
  77d9fc:	test   %rax,%rax
  77d9ff:	je     77da15 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1825>
  77da01:	lock decq (%rax)
  77da05:	jne    77da15 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1825>
  77da07:	lea    0xd0(%rsp),%rdi
  77da0f:	call   *0x33c95b(%rip)        # aba370 <_DYNAMIC+0x330>
  77da15:	cmpl   $0x2,0xca0(%rsp)
  77da1d:	je     77da31 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1841>
  77da1f:	test   %bpl,%bpl
  77da22:	je     77da31 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1841>
  77da24:	lea    0xca0(%rsp),%rdi
  77da2c:	call   74d320 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas6canvas6CanvasECs9C2G9YFESsD_29canonical_text_public_control>
  77da31:	add    $0xe88,%rsp
  77da38:	pop    %rbx
  77da39:	pop    %r12
  77da3b:	pop    %r13
  77da3d:	pop    %r14
  77da3f:	pop    %r15
  77da41:	pop    %rbp
  77da42:	ret
  77da43:	mov    0x3c0(%rsp),%rax
  77da4b:	mov    0x48(%rsp),%rcx
  77da50:	mov    %rax,0x30(%rcx)
  77da54:	movups 0x390(%rsp),%xmm0
  77da5c:	movups 0x3a0(%rsp),%xmm1
  77da64:	movups 0x3b0(%rsp),%xmm2
  77da6c:	movups %xmm2,0x20(%rcx)
  77da70:	movups %xmm1,0x10(%rcx)
  77da74:	movups %xmm0,(%rcx)
  77da77:	jmp    77d5e9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x13f9>
  77da7c:	mov    0x7e0(%rsp),%rsi
  77da84:	test   %rsi,%rsi
  77da87:	je     77d9ca <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17da>
  77da8d:	lea    0x7e8(%rsp),%rax
  77da95:	mov    (%rax),%rdi
  77da98:	mov    $0x1,%edx
  77da9d:	call   *0x33c7dd(%rip)        # aba280 <_DYNAMIC+0x240>
  77daa3:	jmp    77d9ca <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17da>
  77daa8:	movq   $0xffffffffffffffff,0x810(%rsp)
  77dab4:	mov    0x2d8(%rsp),%rax
  77dabc:	mov    (%rax),%rsi
  77dabf:	test   %rsi,%rsi
  77dac2:	je     77db90 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x19a0>
  77dac8:	mov    $0x1,%r12b
  77dacb:	lea    0x390(%rsp),%rdi
  77dad3:	mov    $0x1,%bl
  77dad5:	mov    $0x1,%r15b
  77dad8:	mov    $0x1,%bpl
  77dadb:	call   *0x33cd37(%rip)        # aba818 <_DYNAMIC+0x7d8>
  77dae1:	mov    0xf8(%rsp),%r13
  77dae9:	mov    0x390(%rsp),%rax
  77daf1:	mov    0x398(%rsp),%rsi
  77daf9:	movups 0x3a0(%rsp),%xmm0
  77db01:	movaps %xmm0,0x310(%rsp)
  77db09:	movups 0x3b0(%rsp),%xmm1
  77db11:	movaps %xmm1,0x970(%rsp)
  77db19:	mov    0x3c0(%rsp),%rcx
  77db21:	mov    %rcx,0x980(%rsp)
  77db29:	movaps %xmm0,0x790(%rsp)
  77db31:	cmp    $0xfffffffffffffffe,%rax
  77db35:	mov    0x40(%rsp),%r12
  77db3a:	je     77dba4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x19b4>
  77db3c:	mov    0x980(%rsp),%rcx
  77db44:	mov    0x48(%rsp),%rdx
  77db49:	mov    %rcx,0x30(%rdx)
  77db4d:	movaps 0x970(%rsp),%xmm0
  77db55:	movups %xmm0,0x20(%rdx)
  77db59:	movaps 0x790(%rsp),%xmm0
  77db61:	movaps %xmm0,0x180(%rsp)
  77db69:	movups %xmm0,0x10(%rdx)
  77db6d:	mov    %rax,(%rdx)
  77db70:	mov    %rsi,0x8(%rdx)
  77db74:	mov    $0x1,%r12b
  77db77:	cmpl   $0xffffffff,0x810(%rsp)
  77db7f:	mov    $0x1,%r13b
  77db82:	mov    $0x1,%bpl
  77db85:	jne    780ea4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4cb4>
  77db8b:	jmp    780eb1 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4cc1>
  77db90:	mov    $0xffffffffffffffff,%rsi
  77db97:	mov    0x40(%rsp),%r12
  77db9c:	mov    0xf8(%rsp),%r13
  77dba4:	movaps 0x790(%rsp),%xmm0
  77dbac:	movups %xmm0,0x8c0(%rsp)
  77dbb4:	mov    %rsi,0x258(%rsp)
  77dbbc:	mov    %rsi,0x8b8(%rsp)
  77dbc4:	cmpb   $0x0,0x2f(%rsp)
  77dbc9:	je     77dc63 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1a73>
  77dbcf:	lea    0x390(%rsp),%rdi
  77dbd7:	lea    0x1d8(%rsp),%rdx
  77dbdf:	lea    0x100(%rsp),%rcx
  77dbe7:	mov    %r12,%rsi
  77dbea:	call   74fe10 <_RINvNtNtCslbxve4rcJus_4gpui7runtime6scroll8geometryNtCs9C2G9YFESsD_29canonical_text_public_control6EditorEBP_>
  77dbef:	mov    0x390(%rsp),%rax
  77dbf7:	movups 0x398(%rsp),%xmm0
  77dbff:	movaps %xmm0,0x970(%rsp)
  77dc07:	movups 0x3a8(%rsp),%xmm0
  77dc0f:	movaps %xmm0,0x980(%rsp)
  77dc17:	movups 0x3b8(%rsp),%xmm0
  77dc1f:	movaps %xmm0,0x990(%rsp)
  77dc27:	cmp    $0xfffffffffffffffe,%rax
  77dc2b:	jne    77ff3e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3d4e>
  77dc31:	movaps 0x970(%rsp),%xmm0
  77dc39:	movaps 0x980(%rsp),%xmm1
  77dc41:	movaps 0x990(%rsp),%xmm2
  77dc49:	movaps %xmm2,0x6e0(%rsp)
  77dc51:	movaps %xmm1,0x6d0(%rsp)
  77dc59:	movaps %xmm0,0x6c0(%rsp)
  77dc61:	jmp    77dc9e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1aae>
  77dc63:	movq   $0x0,0x6c0(%rsp)
  77dc6f:	movq   $0x8,0x6c8(%rsp)
  77dc7b:	xorps  %xmm0,%xmm0
  77dc7e:	movups %xmm0,0x6d0(%rsp)
  77dc86:	movq   $0x8,0x6e0(%rsp)
  77dc92:	movq   $0x0,0x6e8(%rsp)
  77dc9e:	mov    0x6a8(%r12),%r15
  77dca6:	mov    0x6b0(%r12),%r14
  77dcae:	mov    0x6c0(%r12),%rbx
  77dcb6:	lea    0xc78(%rsp),%rdi
  77dcbe:	mov    %r12,%rsi
  77dcc1:	call   7712e0 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime9inspectorINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE17inspector_displayB10_>
  77dcc6:	lea    0x650(%r12),%rax
  77dcce:	mov    %rax,0xf0(%rsp)
  77dcd6:	mov    (%rax),%rax
  77dcd9:	test   %rax,%rax
  77dcdc:	je     77dcfa <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1b0a>
  77dcde:	mov    0x100(%rax),%rsi
  77dce5:	test   %rsi,%rsi
  77dce8:	je     77dcfa <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1b0a>
  77dcea:	lea    0xb98(%rsp),%rdi
  77dcf2:	call   *0x33c5f0(%rip)        # aba2e8 <_DYNAMIC+0x2a8>
  77dcf8:	jmp    77dd11 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1b21>
  77dcfa:	movq   $0x4,0xb98(%rsp)
  77dd06:	xorps  %xmm0,%xmm0
  77dd09:	movups %xmm0,0xba0(%rsp)
  77dd11:	mov    0x6b8(%r12),%rax
  77dd19:	test   %rax,%rax
  77dd1c:	je     77dd50 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1b60>
  77dd1e:	mov    %r14,0x18(%rax)
  77dd22:	mov    %r15,0x20(%rax)
  77dd26:	mov    %rbx,0x28(%rax)
  77dd2a:	movq   $0x0,0x10(%rax)
  77dd32:	movw   $0x100,0x58(%rax)
  77dd38:	test   %r14,%r14
  77dd3b:	setne  %dl
  77dd3e:	cmp    %r13,%rbx
  77dd41:	sete   %cl
  77dd44:	and    %dl,%cl
  77dd46:	mov    %rax,0x688(%rsp)
  77dd4e:	jmp    77dd52 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1b62>
  77dd50:	mov    $0x2,%cl
  77dd52:	mov    %cl,0x690(%rsp)
  77dd59:	mov    0xa8(%rsp),%rdi
  77dd61:	call   *0x33cab9(%rip)        # aba820 <_DYNAMIC+0x7e0>
  77dd67:	movzbl 0xc78(%rsp),%eax
  77dd6f:	movq   $0xffffffffffffffff,0x670(%rsp)
  77dd7b:	mov    %al,0x7f(%rsp)
  77dd7f:	test   %al,%al
  77dd81:	je     77dd93 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1ba3>
  77dd83:	mov    0xc80(%rsp),%rax
  77dd8b:	mov    %rax,0x670(%rsp)
  77dd93:	cmpl   $0x2,0xca0(%rsp)
  77dd9b:	lea    0xca0(%rsp),%rsi
  77dda3:	cmove  %r12,%rsi
  77dda7:	lea    0x970(%rsp),%rdi
  77ddaf:	call   *0x33ca73(%rip)        # aba828 <_DYNAMIC+0x7e8>
  77ddb5:	movups -0x6bb67c(%rip),%xmm0        # c2740 <GCC_except_table0+0x338>
  77ddbc:	movaps %xmm0,0x390(%rsp)
  77ddc4:	lea    0x970(%rsp),%rdi
  77ddcc:	lea    0x390(%rsp),%rsi
  77ddd4:	call   *0x33ca56(%rip)        # aba830 <_DYNAMIC+0x7f0>
  77ddda:	incq   0x740(%r12)
  77dde2:	mov    0x2e0(%r12),%rax
  77ddea:	mov    %rax,0x660(%rsp)
  77ddf2:	test   %rax,%rax
  77ddf5:	je     77fe1b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3c2b>
  77ddfb:	movss  0x9c(%rsp),%xmm0
  77de04:	cvtss2sd %xmm0,%xmm0
  77de08:	movsd  %xmm0,0x890(%rsp)
  77de11:	movaps 0xc0(%rsp),%xmm0
  77de19:	unpcklps 0x80(%rsp),%xmm0
  77de21:	movaps %xmm0,0x800(%rsp)
  77de29:	lea    0x31d8d0(%rip),%rax        # a9b700 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1c18>
  77de30:	mov    %rax,0x658(%rsp)
  77de38:	movabs $0x8000000000000000,%rax
  77de42:	inc    %rax
  77de45:	mov    %rax,0x888(%rsp)
  77de4d:	lea    0x31d8c4(%rip),%rax        # a9b718 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1c30>
  77de54:	mov    %rax,0xa0(%rsp)
  77de5c:	lea    0x180(%rsp),%r15
  77de64:	lea    0x31c58d(%rip),%rax        # a9a3f8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x910>
  77de6b:	mov    %rax,0x650(%rsp)
  77de73:	lea    0x31c69e(%rip),%rax        # a9a518 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xa30>
  77de7a:	mov    %rax,0x648(%rsp)
  77de82:	lea    0x31d91f(%rip),%rax        # a9b7a8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1cc0>
  77de89:	mov    %rax,0x248(%rsp)
  77de91:	lea    -0x6ab4a9(%rip),%rax        # d29ef <GCC_except_table0+0x105e7>
  77de98:	mov    %rax,0x250(%rsp)
  77dea0:	xor    %ecx,%ecx
  77dea2:	lea    0x0(,%rcx,8),%rax
  77deaa:	lea    (%rax,%rax,4),%r13
  77deae:	imul   $0x58,%rcx,%rax
  77deb2:	mov    %rax,0x668(%rsp)
  77deba:	mov    %rcx,%rsi
  77debd:	shl    $0x4,%rsi
  77dec1:	mov    %rcx,%rdx
  77dec4:	jmp    77def5 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1d05>
  77dec6:	add    $0x28,%r13
  77deca:	addq   $0x58,0x668(%rsp)
  77ded3:	mov    0x8a8(%rsp),%rsi
  77dedb:	add    $0x10,%rsi
  77dedf:	mov    0x8a0(%rsp),%rdx
  77dee7:	cmp    0x660(%rsp),%rdx
  77deef:	jae    77fe1b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3c2b>
  77def5:	cmp    %rdx,0x670(%rsp)
  77defd:	mov    %rdx,0x38(%rsp)
  77df02:	jne    77df88 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1d98>
  77df08:	cmpb   $0x0,0x7f(%rsp)
  77df0d:	je     781048 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4e58>
  77df13:	mov    %rsi,%rbx
  77df16:	mov    0x148(%rsp),%rdx
  77df1e:	mov    0x150(%rsp),%rcx
  77df26:	mov    0x270(%rsp),%r8
  77df2e:	mov    0x278(%rsp),%r9
  77df36:	mov    0x40(%rsp),%rax
  77df3b:	movups 0x2f0(%rax),%xmm0
  77df42:	movups 0x5a0(%rax),%xmm1
  77df49:	movups %xmm1,0x18(%rsp)
  77df4e:	mov    0x58(%rsp),%rax
  77df53:	mov    %rax,0x10(%rsp)
  77df58:	movups %xmm0,(%rsp)
  77df5c:	lea    0x390(%rsp),%rdi
  77df64:	lea    0xc80(%rsp),%rsi
  77df6c:	call   *0x33c8c6(%rip)        # aba838 <_DYNAMIC+0x7f8>
  77df72:	cmpl   $0xfffffffe,0x390(%rsp)
  77df7a:	jne    780c70 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4a80>
  77df80:	mov    0x38(%rsp),%rdx
  77df85:	mov    %rbx,%rsi
  77df88:	mov    0x40(%rsp),%rcx
  77df8d:	mov    0x5a8(%rcx),%rax
  77df94:	cmp    %rax,%rdx
  77df97:	jae    781340 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5150>
  77df9d:	mov    0x5a0(%rcx),%rax
  77dfa4:	mov    %rsi,0x8a8(%rsp)
  77dfac:	movups (%rax,%rsi,1),%xmm0
  77dfb0:	movaps %xmm0,0x310(%rsp)
  77dfb8:	lea    0x390(%rsp),%rdi
  77dfc0:	mov    0x58(%rsp),%rsi
  77dfc5:	lea    0x310(%rsp),%rdx
  77dfcd:	call   *0x33c44d(%rip)        # aba420 <_DYNAMIC+0x3e0>
  77dfd3:	cmpb   $0x0,0x390(%rsp)
  77dfdb:	jne    780bbe <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x49ce>
  77dfe1:	mov    0x38(%rsp),%rdx
  77dfe6:	lea    0x1(%rdx),%rcx
  77dfea:	mov    0x40(%rsp),%rax
  77dfef:	mov    0x2e0(%rax),%rsi
  77dff6:	mov    %rcx,0x8a0(%rsp)
  77dffe:	cmp    %rsi,%rcx
  77e001:	jae    77e02b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1e3b>
  77e003:	mov    0x2d8(%rax),%rax
  77e00a:	mov    0x40(%rax,%r13,1),%eax
  77e00f:	mov    $0xffffffff,%ecx
  77e014:	cmp    %rcx,%rax
  77e017:	setne  %cl
  77e01a:	cmp    %rax,%rdx
  77e01d:	sete   %al
  77e020:	and    %cl,%al
  77e022:	mov    %eax,0x1d4(%rsp)
  77e029:	jmp    77e036 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1e46>
  77e02b:	movl   $0x0,0x1d4(%rsp)
  77e036:	movsd  0x3d4(%rsp),%xmm0
  77e03f:	movaps %xmm0,0x940(%rsp)
  77e047:	movsd  0x3dc(%rsp),%xmm0
  77e050:	movaps %xmm0,0x630(%rsp)
  77e058:	movups 0x3a4(%rsp),%xmm0
  77e060:	movaps %xmm0,0x930(%rsp)
  77e068:	movss  0x3a8(%rsp),%xmm0
  77e071:	movss  %xmm0,0x30c(%rsp)
  77e07a:	movups 0x3b4(%rsp),%xmm0
  77e082:	movaps %xmm0,0x2c0(%rsp)
  77e08a:	movss  0x3bc(%rsp),%xmm0
  77e093:	movaps %xmm0,0x910(%rsp)
  77e09b:	movss  0x3b8(%rsp),%xmm0
  77e0a4:	movss  %xmm0,0x308(%rsp)
  77e0ad:	movsd  0x3e4(%rsp),%xmm0
  77e0b6:	movaps %xmm0,0x920(%rsp)
  77e0be:	mov    0xa8(%rsp),%rax
  77e0c6:	mov    (%rax),%rax
  77e0c9:	lea    -0x6b9f3c(%rip),%rcx        # c4194 <GCC_except_table0+0x1d8c>
  77e0d0:	movslq (%rcx,%rax,4),%rax
  77e0d4:	add    %rcx,%rax
  77e0d7:	jmp    *%rax
  77e0d9:	movups -0x6b9c04(%rip),%xmm0        # c44dc <GCC_except_table0+0x20d4>
  77e0e0:	movaps %xmm0,0x350(%rsp)
  77e0e8:	movups -0x6b9c23(%rip),%xmm0        # c44cc <GCC_except_table0+0x20c4>
  77e0ef:	movaps %xmm0,0x340(%rsp)
  77e0f7:	movups -0x6b9c42(%rip),%xmm0        # c44bc <GCC_except_table0+0x20b4>
  77e0fe:	movaps %xmm0,0x330(%rsp)
  77e106:	movups -0x6b9c61(%rip),%xmm0        # c44ac <GCC_except_table0+0x20a4>
  77e10d:	movaps %xmm0,0x320(%rsp)
  77e115:	movups -0x6b9c80(%rip),%xmm0        # c449c <GCC_except_table0+0x2094>
  77e11c:	movaps %xmm0,0x310(%rsp)
  77e124:	movabs $0x3000100000000,%rax
  77e12e:	mov    %rax,0x360(%rsp)
  77e136:	jmp    77e250 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2060>
  77e13b:	mov    0x40(%rsp),%rdx
  77e140:	mov    0x220(%rdx),%rax
  77e147:	mov    0x38(%rsp),%rdi
  77e14c:	cmp    %rax,%rdi
  77e14f:	jae    78130c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x511c>
  77e155:	mov    0x210(%rdx),%rax
  77e15c:	mov    0x218(%rdx),%rcx
  77e163:	movzbl (%rcx,%rdi,1),%ecx
  77e167:	cmp    %rcx,%rax
  77e16a:	jbe    781315 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5125>
  77e170:	mov    0x208(%rdx),%rax
  77e177:	imul   $0x58,%rcx,%rcx
  77e17b:	mov    0x50(%rax,%rcx,1),%rdx
  77e180:	mov    %rdx,0x360(%rsp)
  77e188:	movups 0x40(%rax,%rcx,1),%xmm0
  77e18d:	movaps %xmm0,0x350(%rsp)
  77e195:	movups (%rax,%rcx,1),%xmm0
  77e199:	movups 0x10(%rax,%rcx,1),%xmm1
  77e19e:	movups 0x20(%rax,%rcx,1),%xmm2
  77e1a3:	movupd 0x30(%rax,%rcx,1),%xmm3
  77e1a9:	jmp    77e22f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x203f>
  77e1ae:	mov    0x40(%rsp),%rax
  77e1b3:	mov    0x208(%rax),%rsi
  77e1ba:	lea    0x310(%rsp),%rdi
  77e1c2:	mov    0x38(%rsp),%rdx
  77e1c7:	call   *0x33c263(%rip)        # aba430 <_DYNAMIC+0x3f0>
  77e1cd:	mov    0x40(%rsp),%rax
  77e1d2:	mov    0x2e0(%rax),%rsi
  77e1d9:	jmp    77e250 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2060>
  77e1db:	mov    0x40(%rsp),%rcx
  77e1e0:	mov    0x218(%rcx),%rax
  77e1e7:	cmp    %rax,0x38(%rsp)
  77e1ec:	jae    781323 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5133>
  77e1f2:	mov    0x210(%rcx),%rax
  77e1f9:	mov    0x668(%rsp),%rdx
  77e201:	mov    0x50(%rax,%rdx,1),%rcx
  77e206:	mov    %rcx,0x360(%rsp)
  77e20e:	movups 0x40(%rax,%rdx,1),%xmm0
  77e213:	movaps %xmm0,0x350(%rsp)
  77e21b:	movups (%rax,%rdx,1),%xmm0
  77e21f:	movups 0x10(%rax,%rdx,1),%xmm1
  77e224:	movups 0x20(%rax,%rdx,1),%xmm2
  77e229:	movupd 0x30(%rax,%rdx,1),%xmm3
  77e22f:	movapd %xmm3,0x340(%rsp)
  77e238:	movaps %xmm2,0x330(%rsp)
  77e240:	movaps %xmm1,0x320(%rsp)
  77e248:	movaps %xmm0,0x310(%rsp)
  77e250:	cmp    %rsi,0x38(%rsp)
  77e255:	jae    78127d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x508d>
  77e25b:	mov    0x40(%rsp),%rax
  77e260:	mov    0x2d8(%rax),%rdi
  77e267:	mov    0x18(%rdi,%r13,1),%edx
  77e26c:	mov    $0xffffffff,%eax
  77e271:	cmp    %rax,%rdx
  77e274:	je     77e290 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x20a0>
  77e276:	call   75e380 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersd_0BQ_>
  77e27b:	mov    %eax,0xbc(%rsp)
  77e282:	mov    0x40(%rsp),%rax
  77e287:	mov    0x2e0(%rax),%rsi
  77e28e:	jmp    77e29b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x20ab>
  77e290:	movl   $0x0,0xbc(%rsp)
  77e29b:	cmp    %rsi,0x38(%rsp)
  77e2a0:	jae    78128c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x509c>
  77e2a6:	mov    0x40(%rsp),%rax
  77e2ab:	mov    0x2d8(%rax),%rax
  77e2b2:	mov    0x18(%rax,%r13,1),%ebx
  77e2b7:	mov    $0xffffffff,%ecx
  77e2bc:	cmp    %rcx,%rbx
  77e2bf:	je     77e2da <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x20ea>
  77e2c1:	cmp    %rbx,%rsi
  77e2c4:	jbe    7812aa <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x50ba>
  77e2ca:	lea    (%rbx,%rbx,4),%rcx
  77e2ce:	mov    (%rax,%rcx,8),%rcx
  77e2d2:	mov    %rcx,0x898(%rsp)
  77e2da:	mov    0xf0(%rsp),%rcx
  77e2e2:	mov    (%rcx),%rcx
  77e2e5:	xorps  %xmm0,%xmm0
  77e2e8:	movss  %xmm0,0x74(%rsp)
  77e2ee:	test   %rcx,%rcx
  77e2f1:	je     77e31b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x212b>
  77e2f3:	mov    0x100(%rcx),%rdi
  77e2fa:	test   %rdi,%rdi
  77e2fd:	je     77e31b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x212b>
  77e2ff:	mov    (%rax,%r13,1),%rsi
  77e303:	call   *0x33c48f(%rip)        # aba798 <_DYNAMIC+0x758>
  77e309:	movss  %xmm0,0x74(%rsp)
  77e30f:	mov    0x40(%rsp),%rax
  77e314:	mov    0x2e0(%rax),%rsi
  77e31b:	cmp    %rsi,0x38(%rsp)
  77e320:	jae    78129b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x50ab>
  77e326:	mov    0x40(%rsp),%rax
  77e32b:	mov    0x2d8(%rax),%rax
  77e332:	mov    %rax,0x30(%rsp)
  77e337:	mov    0x18(%rax,%r13,1),%ecx
  77e33c:	mov    $0xffffffff,%eax
  77e341:	cmp    %rax,%rcx
  77e344:	je     77e460 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2270>
  77e34a:	mov    0x1e8(%rsp),%rax
  77e352:	cmp    %rcx,%rax
  77e355:	jbe    7812bb <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x50cb>
  77e35b:	imul   $0x38,%rcx,%rax
  77e35f:	mov    0x1e0(%rsp),%rcx
  77e367:	movups (%rcx,%rax,1),%xmm0
  77e36b:	movaps %xmm0,0x60(%rsp)
  77e370:	movups 0x10(%rcx,%rax,1),%xmm0
  77e375:	movaps %xmm0,0xe0(%rsp)
  77e37d:	movups 0x20(%rcx,%rax,1),%xmm0
  77e382:	movaps %xmm0,0x280(%rsp)
  77e38a:	movzbl 0x30(%rcx,%rax,1),%ebp
  77e38f:	mov    0x31(%rcx,%rax,1),%edx
  77e393:	mov    %edx,0x180(%rsp)
  77e39a:	mov    0x34(%rcx,%rax,1),%eax
  77e39e:	mov    %eax,0x183(%rsp)
  77e3a5:	cmp    $0xffffffff,%ebx
  77e3a8:	je     781039 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4e49>
  77e3ae:	lea    0x390(%rsp),%rdi
  77e3b6:	lea    0x6c0(%rsp),%rsi
  77e3be:	mov    0x898(%rsp),%rdx
  77e3c6:	call   *0x33c474(%rip)        # aba840 <_DYNAMIC+0x800>
  77e3cc:	cmpl   $0x1,0x390(%rsp)
  77e3d4:	jne    77e494 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x22a4>
  77e3da:	movq   0x398(%rsp),%xmm0
  77e3e3:	movq   0x3a0(%rsp),%xmm1
  77e3ec:	movq   %xmm0,%rax
  77e3f1:	movq   %xmm1,%rcx
  77e3f6:	movabs $0x7fffffffffffffff,%rdx
  77e400:	and    %rdx,%rax
  77e403:	movabs $0x7fefffffffffffff,%rsi
  77e40d:	cmp    %rsi,%rax
  77e410:	setg   %al
  77e413:	and    %rdx,%rcx
  77e416:	cmp    %rsi,%rcx
  77e419:	setg   %cl
  77e41c:	or     %al,%cl
  77e41e:	or     %bpl,%cl
  77e421:	and    $0x1,%cl
  77e424:	punpcklqdq %xmm1,%xmm1
  77e428:	pxor   -0x6bab80(%rip),%xmm1        # c38b0 <GCC_except_table0+0x14a8>
  77e430:	movapd 0xe0(%rsp),%xmm3
  77e439:	mulpd  %xmm3,%xmm1
  77e43d:	punpcklqdq %xmm0,%xmm0
  77e441:	movapd 0x60(%rsp),%xmm2
  77e447:	mulpd  %xmm2,%xmm0
  77e44b:	subpd  %xmm0,%xmm1
  77e44f:	movapd 0x280(%rsp),%xmm0
  77e458:	addpd  %xmm1,%xmm0
  77e45c:	mov    %ecx,%ebp
  77e45e:	jmp    77e4c7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x22d7>
  77e460:	movsd  0x890(%rsp),%xmm0
  77e469:	movsd  %xmm0,0x790(%rsp)
  77e472:	lea    0x7c1(%rsp),%rax
  77e47a:	xorps  %xmm1,%xmm1
  77e47d:	movups %xmm1,-0x29(%rax)
  77e481:	movsd  %xmm0,0x7a8(%rsp)
  77e48a:	movaps %xmm1,-0x11(%rax)
  77e48e:	movb   $0x0,-0x1(%rax)
  77e492:	jmp    77e4ea <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x22fa>
  77e494:	mov    0x180(%rsp),%eax
  77e49b:	mov    0x183(%rsp),%ecx
  77e4a2:	lea    0x7c1(%rsp),%rdx
  77e4aa:	mov    %ecx,0x3(%rdx)
  77e4ad:	mov    %eax,(%rdx)
  77e4af:	movapd 0x60(%rsp),%xmm2
  77e4b5:	movapd 0xe0(%rsp),%xmm3
  77e4be:	movapd 0x280(%rsp),%xmm0
  77e4c7:	movapd %xmm2,0x790(%rsp)
  77e4d0:	movapd %xmm3,0x7a0(%rsp)
  77e4d9:	movapd %xmm0,0x7b0(%rsp)
  77e4e2:	mov    %bpl,0x7c0(%rsp)
  77e4ea:	movaps -0x6ba931(%rip),%xmm0        # c3bc0 <GCC_except_table0+0x17b8>
  77e4f1:	movaps %xmm0,0x180(%rsp)
  77e4f9:	movaps 0x940(%rsp),%xmm0
  77e501:	movlps %xmm0,0x190(%rsp)
  77e509:	lea    0x390(%rsp),%rdi
  77e511:	lea    0x790(%rsp),%rsi
  77e519:	mov    %r15,%rdx
  77e51c:	call   *0x33bf06(%rip)        # aba428 <_DYNAMIC+0x3e8>
  77e522:	lea    0xbb0(%rsp),%rdi
  77e52a:	lea    0x390(%rsp),%rsi
  77e532:	lea    0x34c(%rsp),%rdx
  77e53a:	call   *0x33bee8(%rip)        # aba428 <_DYNAMIC+0x3e8>
  77e540:	mov    0x1e8(%rsp),%rbx
  77e548:	cmp    0x1d8(%rsp),%rbx
  77e550:	jne    77e55f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x236f>
  77e552:	lea    0x1d8(%rsp),%rdi
  77e55a:	call   772ad0 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtCscO85OU7Wpt0_20gpui_reactivity_core8geometry15CoordinateSpaceE8grow_oneCs9C2G9YFESsD_29canonical_text_public_control>
  77e55f:	mov    0x1e0(%rsp),%rax
  77e567:	imul   $0x38,%rbx,%rcx
  77e56b:	mov    0xbe0(%rsp),%rdx
  77e573:	mov    %rdx,0x30(%rax,%rcx,1)
  77e578:	movups 0xbb0(%rsp),%xmm0
  77e580:	movups 0xbc0(%rsp),%xmm1
  77e588:	movups 0xbd0(%rsp),%xmm2
  77e590:	movups %xmm2,0x20(%rax,%rcx,1)
  77e595:	movups %xmm1,0x10(%rax,%rcx,1)
  77e59a:	movups %xmm0,(%rax,%rcx,1)
  77e59e:	inc    %rbx
  77e5a1:	mov    %rbx,0x1e8(%rsp)
  77e5a9:	movups 0xbb0(%rsp),%xmm0
  77e5b1:	movaps %xmm0,0xe0(%rsp)
  77e5b9:	movups 0xbc0(%rsp),%xmm0
  77e5c1:	movaps %xmm0,0x280(%rsp)
  77e5c9:	movups 0xbd0(%rsp),%xmm0
  77e5d1:	movaps %xmm0,0x60(%rsp)
  77e5d6:	lea    0xbb0(%rsp),%rdi
  77e5de:	call   *0x33c264(%rip)        # aba848 <_DYNAMIC+0x808>
  77e5e4:	xor    %ebx,%ebx
  77e5e6:	test   %al,%al
  77e5e8:	je     77e713 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2523>
  77e5ee:	cvtpd2ps 0x280(%rsp),%xmm0
  77e5f7:	cvtpd2ps 0xe0(%rsp),%xmm1
  77e600:	cvtpd2ps 0x60(%rsp),%xmm2
  77e606:	unpcklpd %xmm0,%xmm1
  77e60a:	movd   %xmm1,%eax
  77e60e:	and    $0x7fffffff,%eax
  77e613:	movapd %xmm1,%xmm0
  77e617:	shufps $0x55,%xmm1,%xmm0
  77e61b:	movd   %xmm0,%ecx
  77e61f:	and    $0x7fffffff,%ecx
  77e625:	cmp    $0x7f800000,%ecx
  77e62b:	setge  %cl
  77e62e:	movdqa %xmm1,%xmm0
  77e632:	punpckhqdq %xmm1,%xmm0
  77e636:	movd   %xmm0,%edx
  77e63a:	and    $0x7fffffff,%edx
  77e640:	cmp    $0x7f800000,%edx
  77e646:	setge  %dl
  77e649:	movaps %xmm1,%xmm0
  77e64c:	shufps $0xff,%xmm1,%xmm0
  77e650:	movd   %xmm0,%esi
  77e654:	and    $0x7fffffff,%esi
  77e65a:	cmp    $0x7f800000,%esi
  77e660:	setge  %sil
  77e664:	movd   %xmm2,%edi
  77e668:	and    $0x7fffffff,%edi
  77e66e:	cmp    $0x7f800000,%edi
  77e674:	setge  %dil
  77e678:	movapd %xmm2,%xmm0
  77e67c:	shufps $0x55,%xmm2,%xmm0
  77e680:	movd   %xmm0,%r8d
  77e685:	and    $0x7fffffff,%r8d
  77e68c:	cmp    $0x7f800000,%r8d
  77e693:	setl   %r8b
  77e697:	cmp    $0x7f7fffff,%eax
  77e69c:	mov    0x30(%rsp),%r9
  77e6a1:	jg     77e718 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2528>
  77e6a3:	test   %cl,%cl
  77e6a5:	jne    77e718 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2528>
  77e6a7:	test   %dl,%dl
  77e6a9:	jne    77e718 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2528>
  77e6ab:	test   %sil,%sil
  77e6ae:	jne    77e718 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2528>
  77e6b0:	test   %dil,%dil
  77e6b3:	jne    77e718 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2528>
  77e6b5:	test   %r8b,%r8b
  77e6b8:	je     77e718 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2528>
  77e6ba:	movaps %xmm1,0x60(%rsp)
  77e6bf:	movaps %xmm1,0x390(%rsp)
  77e6c7:	movaps %xmm2,0xe0(%rsp)
  77e6cf:	movlpd %xmm2,0x3a0(%rsp)
  77e6d8:	lea    0x390(%rsp),%rdi
  77e6e0:	call   *0x33c16a(%rip)        # aba850 <_DYNAMIC+0x810>
  77e6e6:	test   %al,%al
  77e6e8:	mov    0x30(%rsp),%r9
  77e6ed:	je     77e718 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2528>
  77e6ef:	movaps 0x60(%rsp),%xmm0
  77e6f4:	movups %xmm0,0x2a8(%rsp)
  77e6fc:	movaps 0xe0(%rsp),%xmm0
  77e704:	movlps %xmm0,0x2b8(%rsp)
  77e70c:	mov    $0x1,%ebx
  77e711:	jmp    77e718 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2528>
  77e713:	mov    0x30(%rsp),%r9
  77e718:	mov    %ebx,0x2a4(%rsp)
  77e71f:	xorps  %xmm0,%xmm0
  77e722:	unpcklpd 0x630(%rsp),%xmm0
  77e72b:	movups %xmm0,0x698(%rsp)
  77e733:	cmpb   $0x0,0x2f(%rsp)
  77e738:	je     77e7d8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x25e8>
  77e73e:	mov    0x18(%r9,%r13,1),%edx
  77e743:	mov    $0xffffffff,%eax
  77e748:	cmp    %rax,%rdx
  77e74b:	je     77e81e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x262e>
  77e751:	mov    0x228(%rsp),%rax
  77e759:	cmp    %rdx,%rax
  77e75c:	jbe    7812c9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x50d9>
  77e762:	mov    0x220(%rsp),%rax
  77e76a:	mov    %rdx,%rcx
  77e76d:	shl    $0x4,%rcx
  77e771:	movsd  (%rax,%rcx,1),%xmm1
  77e776:	movsd  0x8(%rax,%rcx,1),%xmm2
  77e77c:	movq   $0x0,0x390(%rsp)
  77e788:	movaps 0xc0(%rsp),%xmm0
  77e790:	movss  %xmm0,0x398(%rsp)
  77e799:	movaps 0x80(%rsp),%xmm0
  77e7a1:	movss  %xmm0,0x39c(%rsp)
  77e7aa:	mov    0x240(%rsp),%rax
  77e7b2:	cmp    %rdx,%rax
  77e7b5:	jbe    7812d7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x50e7>
  77e7bb:	movaps %xmm2,0x280(%rsp)
  77e7c3:	movaps %xmm1,0xe0(%rsp)
  77e7cb:	add    0x238(%rsp),%rcx
  77e7d3:	jmp    77e86f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x267f>
  77e7d8:	movq   $0x0,0x1b0(%rsp)
  77e7e4:	movaps 0xc0(%rsp),%xmm0
  77e7ec:	movss  %xmm0,0x1b8(%rsp)
  77e7f5:	movaps 0x80(%rsp),%xmm0
  77e7fd:	movss  %xmm0,0x1bc(%rsp)
  77e806:	xorps  %xmm0,%xmm0
  77e809:	movl   $0x0,0x60(%rsp)
  77e811:	movaps 0x800(%rsp),%xmm1
  77e819:	jmp    77e8f6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2706>
  77e81e:	movq   $0x0,0x390(%rsp)
  77e82a:	movaps 0xc0(%rsp),%xmm0
  77e832:	movss  %xmm0,0x398(%rsp)
  77e83b:	movaps 0x80(%rsp),%xmm0
  77e843:	movss  %xmm0,0x39c(%rsp)
  77e84c:	xorps  %xmm0,%xmm0
  77e84f:	movaps %xmm0,0xe0(%rsp)
  77e857:	lea    0x390(%rsp),%rcx
  77e85f:	movaps 0x800(%rsp),%xmm0
  77e867:	movaps %xmm0,0x280(%rsp)
  77e86f:	movups (%rcx),%xmm0
  77e872:	movaps %xmm0,0x1b0(%rsp)
  77e87a:	mov    0x20(%r9,%r13,1),%edi
  77e87f:	call   776700 <_RNvMsh_NtCslbxve4rcJus_4gpui7runtimeNtB5_4Node4kind>
  77e884:	mov    $0x1,%cl
  77e886:	mov    %ecx,0x60(%rsp)
  77e88a:	cmp    $0x7,%al
  77e88c:	jne    77e8a5 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x26b5>
  77e88e:	mov    0x30(%rsp),%r9
  77e893:	movaps 0xe0(%rsp),%xmm0
  77e89b:	movaps 0x280(%rsp),%xmm1
  77e8a3:	jmp    77e8f6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2706>
  77e8a5:	mov    0x30(%rsp),%r9
  77e8aa:	mov    0x18(%r9,%r13,1),%ecx
  77e8af:	mov    $0xffffffff,%eax
  77e8b4:	cmp    %rax,%rcx
  77e8b7:	movaps 0xe0(%rsp),%xmm0
  77e8bf:	movaps 0x280(%rsp),%xmm1
  77e8c7:	je     77e8ee <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x26fe>
  77e8c9:	mov    0x168(%rsp),%rax
  77e8d1:	cmp    %rcx,%rax
  77e8d4:	jbe    78132c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x513c>
  77e8da:	mov    0x160(%rsp),%rax
  77e8e2:	movzbl (%rax,%rcx,1),%eax
  77e8e6:	and    $0x1,%al
  77e8e8:	mov    %eax,0x60(%rsp)
  77e8ec:	jmp    77e8f6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2706>
  77e8ee:	movl   $0x0,0x60(%rsp)
  77e8f6:	movlhps %xmm1,%xmm0
  77e8f9:	movups %xmm0,0x170(%rsp)
  77e901:	mov    0x20(%r9,%r13,1),%eax
  77e906:	and    $0xf,%eax
  77e909:	cmp    $0x7,%eax
  77e90c:	jb     77e91a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x272a>
  77e90e:	lea    -0x8(%rax),%ecx
  77e911:	cmp    $0x2,%ecx
  77e914:	jae    77f474 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3284>
  77e91a:	mov    0x18(%r9,%r13,1),%ecx
  77e91f:	xor    %r12d,%r12d
  77e922:	mov    $0xffffffff,%edx
  77e927:	cmp    %rdx,%rcx
  77e92a:	je     77e94a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x275a>
  77e92c:	cmp    %rcx,0x168(%rsp)
  77e934:	jbe    77e94a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x275a>
  77e936:	mov    0x160(%rsp),%rdx
  77e93e:	movzbl (%rdx,%rcx,1),%r12d
  77e943:	and    $0x2,%r12b
  77e947:	shr    $1,%r12b
  77e94a:	cmpb   $0x0,0x2f(%rsp)
  77e94f:	je     77e99d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x27ad>
  77e951:	mov    0x168(%rsp),%r14
  77e959:	cmp    0x158(%rsp),%r14
  77e961:	jne    77e971 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2781>
  77e963:	lea    0x158(%rsp),%rdi
  77e96b:	call   *0x33bee7(%rip)        # aba858 <_DYNAMIC+0x818>
  77e971:	lea    (%r12,%r12,1),%eax
  77e975:	add    0x60(%rsp),%al
  77e979:	mov    0x160(%rsp),%rcx
  77e981:	mov    %al,(%rcx,%r14,1)
  77e985:	inc    %r14
  77e988:	mov    %r14,0x168(%rsp)
  77e990:	mov    0x30(%rsp),%rax
  77e995:	mov    0x20(%rax,%r13,1),%eax
  77e99a:	and    $0xf,%eax
  77e99d:	cmp    $0x9,%eax
  77e9a0:	ja     781122 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4f32>
  77e9a6:	mov    $0x34f,%ecx
  77e9ab:	bt     %eax,%ecx
  77e9ae:	jb     77ea2e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x283e>
  77e9b0:	movups 0x170(%rsp),%xmm0
  77e9b8:	movaps %xmm0,0x180(%rsp)
  77e9c0:	movups 0x698(%rsp),%xmm0
  77e9c8:	movaps %xmm0,0x390(%rsp)
  77e9d0:	lea    0x8d0(%rsp),%rdi
  77e9d8:	mov    %r15,%rsi
  77e9db:	lea    0x1b0(%rsp),%rdx
  77e9e3:	lea    0x2a4(%rsp),%rcx
  77e9eb:	lea    0x390(%rsp),%r8
  77e9f3:	mov    0xf8(%rsp),%r9
  77e9fb:	call   *0x33be5f(%rip)        # aba860 <_DYNAMIC+0x820>
  77ea01:	cmpl   $0xfffffffe,0x8d0(%rsp)
  77ea09:	jne    780ca9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4ab9>
  77ea0f:	lea    0x8d8(%rsp),%rax
  77ea17:	movups (%rax),%xmm0
  77ea1a:	movaps %xmm0,0x170(%rsp)
  77ea22:	movups 0x10(%rax),%xmm0
  77ea26:	movaps %xmm0,0x1b0(%rsp)
  77ea2e:	cmpb   $0x0,0x2f(%rsp)
  77ea33:	je     77ead3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x28e3>
  77ea39:	movaps 0x170(%rsp),%xmm0
  77ea41:	movaps %xmm0,0x390(%rsp)
  77ea49:	mov    0x228(%rsp),%r14
  77ea51:	cmp    0x218(%rsp),%r14
  77ea59:	jne    77ea68 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2878>
  77ea5b:	lea    0x218(%rsp),%rdi
  77ea63:	call   772b40 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtCscO85OU7Wpt0_20gpui_reactivity_core8geometry4RectE8grow_oneCs9C2G9YFESsD_29canonical_text_public_control>
  77ea68:	mov    0x220(%rsp),%rax
  77ea70:	mov    %r14,%rcx
  77ea73:	shl    $0x4,%rcx
  77ea77:	movaps 0x390(%rsp),%xmm0
  77ea7f:	movups %xmm0,(%rax,%rcx,1)
  77ea83:	inc    %r14
  77ea86:	mov    %r14,0x228(%rsp)
  77ea8e:	mov    0x240(%rsp),%r14
  77ea96:	cmp    0x230(%rsp),%r14
  77ea9e:	jne    77eaad <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x28bd>
  77eaa0:	lea    0x230(%rsp),%rdi
  77eaa8:	call   772b40 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtCscO85OU7Wpt0_20gpui_reactivity_core8geometry4RectE8grow_oneCs9C2G9YFESsD_29canonical_text_public_control>
  77eaad:	mov    0x238(%rsp),%rax
  77eab5:	mov    %r14,%rcx
  77eab8:	shl    $0x4,%rcx
  77eabc:	movaps 0x1b0(%rsp),%xmm0
  77eac4:	movups %xmm0,(%rax,%rcx,1)
  77eac8:	inc    %r14
  77eacb:	mov    %r14,0x240(%rsp)
  77ead3:	test   %ebx,%ebx
  77ead5:	je     77eb0b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x291b>
  77ead7:	lea    0x390(%rsp),%rdi
  77eadf:	lea    0x698(%rsp),%rsi
  77eae7:	lea    0x2a8(%rsp),%rdx
  77eaef:	call   75e4a0 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerso_0BQ_>
  77eaf4:	cmpl   $0x1,0x390(%rsp)
  77eafc:	jne    77eb0b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x291b>
  77eafe:	lea    0x394(%rsp),%rax
  77eb06:	movups (%rax),%xmm0
  77eb09:	jmp    77eb0e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x291e>
  77eb0b:	xorps  %xmm0,%xmm0
  77eb0e:	movaps %xmm0,0x6f0(%rsp)
  77eb16:	mov    0x60(%rsp),%eax
  77eb1a:	or     %r12b,%al
  77eb1d:	cmp    $0x1,%al
  77eb1f:	je     77eb34 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2944>
  77eb21:	mov    0x30(%rsp),%rax
  77eb26:	mov    0x20(%rax,%r13,1),%edi
  77eb2b:	call   776700 <_RNvMsh_NtCslbxve4rcJus_4gpui7runtimeNtB5_4Node4kind>
  77eb30:	cmp    $0x6,%al
  77eb32:	jne    77eb54 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2964>
  77eb34:	lea    0x290(%rsp),%rdi
  77eb3c:	lea    0x6f0(%rsp),%rsi
  77eb44:	lea    0x1b0(%rsp),%rdx
  77eb4c:	call   *0x33bd16(%rip)        # aba868 <_DYNAMIC+0x828>
  77eb52:	jmp    77ebc1 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x29d1>
  77eb54:	movsd  0x6f0(%rsp),%xmm0
  77eb5d:	movsd  0x6f8(%rsp),%xmm1
  77eb66:	movaps %xmm0,%xmm2
  77eb69:	addps  %xmm0,%xmm1
  77eb6c:	xorps  %xmm4,%xmm4
  77eb6f:	maxps  %xmm4,%xmm0
  77eb72:	movaps %xmm0,%xmm3
  77eb75:	cmpunordps %xmm0,%xmm3
  77eb79:	andps  %xmm3,%xmm2
  77eb7c:	andnps %xmm0,%xmm3
  77eb7f:	orps   %xmm2,%xmm3
  77eb82:	movaps %xmm1,%xmm0
  77eb85:	minps  0x800(%rsp),%xmm0
  77eb8d:	movaps %xmm0,%xmm2
  77eb90:	cmpunordps %xmm0,%xmm2
  77eb94:	andps  %xmm2,%xmm1
  77eb97:	andnps %xmm0,%xmm2
  77eb9a:	orps   %xmm1,%xmm2
  77eb9d:	subps  %xmm3,%xmm2
  77eba0:	movaps %xmm2,%xmm0
  77eba3:	maxps  %xmm4,%xmm0
  77eba6:	movaps %xmm0,%xmm1
  77eba9:	cmpunordps %xmm0,%xmm1
  77ebad:	andps  %xmm1,%xmm2
  77ebb0:	andnps %xmm0,%xmm1
  77ebb3:	orps   %xmm2,%xmm1
  77ebb6:	movlhps %xmm1,%xmm3
  77ebb9:	movups %xmm3,0x290(%rsp)
  77ebc1:	test   %r12b,%r12b
  77ebc4:	mov    0x30(%rsp),%rsi
  77ebc9:	je     77ebf8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2a08>
  77ebcb:	movss  0x298(%rsp),%xmm0
  77ebd4:	xor    %ebp,%ebp
  77ebd6:	xorps  %xmm1,%xmm1
  77ebd9:	ucomiss %xmm1,%xmm0
  77ebdc:	jne    77ebe4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x29f4>
  77ebde:	jnp    77ee65 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2c75>
  77ebe4:	movss  0x29c(%rsp),%xmm0
  77ebed:	ucomiss %xmm1,%xmm0
  77ebf0:	jne    77ebf8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2a08>
  77ebf2:	jnp    77ee65 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2c75>
  77ebf8:	mov    0x348(%rsp),%eax
  77ebff:	mov    $0x3fffffff,%ecx
  77ec04:	and    %ecx,%eax
  77ec06:	cmp    $0x3f800001,%eax
  77ec0b:	mov    $0x80000000,%ecx
  77ec10:	cmove  %ecx,%eax
  77ec13:	movd   %eax,%xmm0
  77ec17:	xorps  %xmm1,%xmm1
  77ec1a:	ucomiss %xmm1,%xmm0
  77ec1d:	jbe    77ecfe <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2b0e>
  77ec23:	movl   $0x1,0x398(%rsp)
  77ec2e:	movq   $0x23,0x390(%rsp)
  77ec3a:	test   %bl,%bl
  77ec3c:	je     780beb <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x49fb>
  77ec42:	lea    0x390(%rsp),%rbx
  77ec4a:	mov    %rbx,%rdi
  77ec4d:	call   74d810 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  77ec52:	lea    0x2a8(%rsp),%rax
  77ec5a:	movups (%rax),%xmm0
  77ec5d:	movaps %xmm0,0xb60(%rsp)
  77ec65:	mov    0x10(%rax),%rax
  77ec69:	mov    %rax,0xb70(%rsp)
  77ec71:	mov    %rbx,%rdi
  77ec74:	mov    0xa8(%rsp),%rsi
  77ec7c:	mov    0x38(%rsp),%rdx
  77ec81:	xor    %ecx,%ecx
  77ec83:	call   *0x33bbe7(%rip)        # aba870 <_DYNAMIC+0x830>
  77ec89:	mov    0x3a0(%rsp),%r9
  77ec91:	test   %r9,%r9
  77ec94:	je     77edf1 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2c01>
  77ec9a:	movups 0x390(%rsp),%xmm0
  77eca2:	movaps %xmm0,0x370(%rsp)
  77ecaa:	movaps 0x170(%rsp),%xmm0
  77ecb2:	movaps %xmm0,0x120(%rsp)
  77ecba:	movups 0x698(%rsp),%xmm0
  77ecc2:	movaps %xmm0,0x180(%rsp)
  77ecca:	lea    0x970(%rsp),%rdi
  77ecd2:	mov    %r15,%rsi
  77ecd5:	movss  0x74(%rsp),%xmm0
  77ecdb:	lea    0xb60(%rsp),%rdx
  77ece3:	lea    0x120(%rsp),%rcx
  77eceb:	lea    0x370(%rsp),%r8
  77ecf3:	call   *0x33bb7f(%rip)        # aba878 <_DYNAMIC+0x838>
  77ecf9:	jmp    77edde <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2bee>
  77ecfe:	cmpq   $0x0,0x8(%rsi,%r13,1)
  77ed04:	jne    77ed20 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2b30>
  77ed06:	mov    0x20(%rsi,%r13,1),%edi
  77ed0b:	call   776700 <_RNvMsh_NtCslbxve4rcJus_4gpui7runtimeNtB5_4Node4kind>
  77ed10:	mov    $0x1,%bpl
  77ed13:	cmp    $0x4,%al
  77ed15:	mov    0x30(%rsp),%rsi
  77ed1a:	jne    77ee65 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2c75>
  77ed20:	movl   $0x1,0x398(%rsp)
  77ed2b:	movq   $0x23,0x390(%rsp)
  77ed37:	test   %bl,%bl
  77ed39:	je     780beb <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x49fb>
  77ed3f:	lea    0x390(%rsp),%rbx
  77ed47:	mov    %rbx,%rdi
  77ed4a:	call   74d810 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  77ed4f:	lea    0x2a8(%rsp),%rcx
  77ed57:	movups (%rcx),%xmm0
  77ed5a:	movaps %xmm0,0x120(%rsp)
  77ed62:	mov    0x10(%rcx),%rax
  77ed66:	mov    %rax,0x130(%rsp)
  77ed6e:	movups (%rcx),%xmm0
  77ed71:	movaps %xmm0,0xc20(%rsp)
  77ed79:	mov    0x10(%rcx),%rax
  77ed7d:	mov    %rax,0xc30(%rsp)
  77ed85:	movaps 0x170(%rsp),%xmm0
  77ed8d:	movaps %xmm0,0x370(%rsp)
  77ed95:	movups 0x698(%rsp),%xmm0
  77ed9d:	movaps %xmm0,0x180(%rsp)
  77eda5:	movups -0x6bb36c(%rip),%xmm0        # c3a40 <GCC_except_table0+0x1638>
  77edac:	movaps %xmm0,0x390(%rsp)
  77edb4:	lea    0x970(%rsp),%rdi
  77edbc:	mov    %r15,%rsi
  77edbf:	movss  0x74(%rsp),%xmm0
  77edc5:	lea    0xc20(%rsp),%rdx
  77edcd:	lea    0x370(%rsp),%rcx
  77edd5:	mov    %rbx,%r8
  77edd8:	call   *0x33baa2(%rip)        # aba880 <_DYNAMIC+0x840>
  77edde:	cmp    $0xffffffff,%eax
  77ede1:	jne    780c24 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4a34>
  77ede7:	mov    $0x1,%bpl
  77edea:	mov    0x30(%rsp),%rsi
  77edef:	jmp    77ee65 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2c75>
  77edf1:	movaps 0x170(%rsp),%xmm0
  77edf9:	movaps %xmm0,0x120(%rsp)
  77ee01:	lea    0x34c(%rsp),%rax
  77ee09:	movups -0x10(%rax),%xmm0
  77ee0d:	movaps %xmm0,0x180(%rsp)
  77ee15:	movups 0x698(%rsp),%xmm0
  77ee1d:	movaps %xmm0,0x390(%rsp)
  77ee25:	lea    0x970(%rsp),%rdi
  77ee2d:	lea    0x390(%rsp),%rsi
  77ee35:	movss  0x74(%rsp),%xmm0
  77ee3b:	lea    0xb60(%rsp),%rdx
  77ee43:	lea    0x120(%rsp),%rcx
  77ee4b:	mov    %r15,%r8
  77ee4e:	call   *0x33ba2c(%rip)        # aba880 <_DYNAMIC+0x840>
  77ee54:	mov    $0x1,%bpl
  77ee57:	cmp    $0xffffffff,%eax
  77ee5a:	mov    0x30(%rsp),%rsi
  77ee5f:	jne    780c24 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4a34>
  77ee65:	mov    0x20(%rsi,%r13,1),%edi
  77ee6a:	mov    %edi,%eax
  77ee6c:	and    $0xf,%eax
  77ee6f:	cmp    $0x9,%eax
  77ee72:	ja     781122 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4f32>
  77ee78:	cmp    $0x6,%eax
  77ee7b:	je     77f485 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3295>
  77ee81:	shr    $0x4,%edi
  77ee84:	dec    %edi
  77ee86:	mov    0x40(%rsp),%rax
  77ee8b:	mov    0x2f0(%rax),%rsi
  77ee92:	mov    0x2f8(%rax),%rdx
  77ee99:	call   7765f0 <_RNvMsf_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSlot7get_mut>
  77ee9e:	test   %rax,%rax
  77eea1:	je     77f28e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x309e>
  77eea7:	lea    0x34c(%rsp),%rcx
  77eeaf:	movups -0x20(%rcx),%xmm0
  77eeb3:	movaps %xmm0,0x960(%rsp)
  77eebb:	mov    0x40(%rsp),%rcx
  77eec0:	mov    0x6e8(%rcx),%rbx
  77eec7:	mov    $0x1e,%esi
  77eecc:	test   %rbx,%rbx
  77eecf:	mov    0x30(%rsp),%rdx
  77eed4:	je     781021 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4e31>
  77eeda:	cmpq   $0x0,0x30(%rbx)
  77eedf:	je     781021 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4e31>
  77eee5:	movzbl 0x78c(%rsp),%ecx
  77eeed:	movb   $0x2,0xe0(%rsp)
  77eef5:	cmp    $0x2,%cl
  77eef8:	je     77ef6c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2d7c>
  77eefa:	mov    (%rdx,%r13,1),%rdx
  77eefe:	cmp    %rdx,0x778(%rsp)
  77ef06:	jne    77ef6c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2d7c>
  77ef08:	mov    0x788(%rsp),%edx
  77ef0f:	mov    %edx,0x1d0(%rsp)
  77ef16:	movzbl 0x784(%rsp),%edx
  77ef1e:	mov    %dl,0x7e(%rsp)
  77ef22:	mov    0x780(%rsp),%edx
  77ef29:	mov    %edx,0x11c(%rsp)
  77ef30:	lea    0x785(%rsp),%rdi
  77ef38:	movzwl (%rdi),%edx
  77ef3b:	mov    %dx,0xb8(%rsp)
  77ef43:	movzbl 0x2(%rdi),%edx
  77ef47:	mov    %dl,0xba(%rsp)
  77ef4e:	movzwl 0x8(%rdi),%edx
  77ef52:	mov    %dx,0xb4(%rsp)
  77ef5a:	movzbl 0xa(%rdi),%edx
  77ef5e:	mov    %dl,0xb6(%rsp)
  77ef65:	mov    %cl,0xe0(%rsp)
  77ef6c:	cmpq   $0x0,0x1c0(%rsp)
  77ef75:	je     78106d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4e7d>
  77ef7b:	movss  0x328(%rsp),%xmm0
  77ef84:	movaps 0x630(%rsp),%xmm1
  77ef8c:	subss  0x2c0(%rsp),%xmm1
  77ef95:	subss  0x308(%rsp),%xmm1
  77ef9e:	subss  0x930(%rsp),%xmm1
  77efa7:	subss  0x30c(%rsp),%xmm1
  77efb0:	subss  0x920(%rsp),%xmm1
  77efb9:	lea    0x390(%rsp),%rdi
  77efc1:	mov    %rax,%rsi
  77efc4:	lea    0x1c0(%rsp),%rdx
  77efcc:	mov    $0x1,%ecx
  77efd1:	mov    $0x1,%r8d
  77efd7:	call   *0x33b4e3(%rip)        # aba4c0 <_DYNAMIC+0x480>
  77efdd:	mov    %r15,%r14
  77efe0:	mov    0x390(%rsp),%rax
  77efe8:	mov    0x398(%rsp),%r15
  77eff0:	cmp    $0xfffffffffffffffe,%rax
  77eff4:	jne    780c3b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4a4b>
  77effa:	movaps 0x2c0(%rsp),%xmm0
  77f002:	movss  %xmm0,0xd8(%rsp)
  77f00b:	movaps 0x910(%rsp),%xmm0
  77f013:	movss  %xmm0,0xdc(%rsp)
  77f01c:	mov    0x20(%r15),%rax
  77f020:	test   %rax,%rax
  77f023:	je     781102 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4f12>
  77f029:	lock incq (%rax)
  77f02d:	jle    781378 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  77f033:	movsd  0xd8(%rsp),%xmm0
  77f03c:	movsd  %xmm0,0x2f8(%rsp)
  77f045:	mov    %rax,0x300(%rsp)
  77f04d:	test   %bpl,%bpl
  77f050:	je     77f4d6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x32e6>
  77f056:	testb  $0x1,0x2a4(%rsp)
  77f05e:	movl   $0x1,0x398(%rsp)
  77f069:	movq   $0x23,0x390(%rsp)
  77f075:	je     780d63 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4b73>
  77f07b:	lea    0x390(%rsp),%rdi
  77f083:	call   74d810 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  77f088:	lea    0x2a8(%rsp),%rcx
  77f090:	movups (%rcx),%xmm0
  77f093:	movaps %xmm0,0xb80(%rsp)
  77f09b:	mov    0x10(%rcx),%rax
  77f09f:	mov    %rax,0xb90(%rsp)
  77f0a7:	movups (%rcx),%xmm0
  77f0aa:	movaps %xmm0,0x370(%rsp)
  77f0b2:	mov    0x10(%rcx),%rax
  77f0b6:	mov    %rax,0x380(%rsp)
  77f0be:	cmpb   $0x2,0xe0(%rsp)
  77f0c6:	je     77f1cf <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2fdf>
  77f0cc:	mov    0x11c(%rsp),%eax
  77f0d3:	mov    %eax,0x180(%rsp)
  77f0da:	movzbl 0x7e(%rsp),%eax
  77f0df:	mov    %al,0x184(%rsp)
  77f0e6:	movzbl 0xba(%rsp),%eax
  77f0ee:	lea    0x185(%rsp),%rcx
  77f0f6:	mov    %al,0x2(%rcx)
  77f0f9:	movzwl 0xb8(%rsp),%eax
  77f101:	mov    %ax,(%rcx)
  77f104:	mov    0x1d0(%rsp),%eax
  77f10b:	mov    %eax,0x188(%rsp)
  77f112:	movzbl 0xe0(%rsp),%eax
  77f11a:	mov    %al,0x18c(%rsp)
  77f121:	movzbl 0xb6(%rsp),%eax
  77f129:	mov    %al,0xa(%rcx)
  77f12c:	movzwl 0xb4(%rsp),%eax
  77f134:	mov    %ax,0x8(%rcx)
  77f138:	movl   $0xffffffff,0x120(%rsp)
  77f143:	lea    0x120(%rsp),%rax
  77f14b:	mov    %rax,0x390(%rsp)
  77f153:	lea    0x970(%rsp),%rax
  77f15b:	mov    %rax,0x398(%rsp)
  77f163:	lea    0xd8(%rsp),%rax
  77f16b:	mov    %rax,0x3a0(%rsp)
  77f173:	lea    0xdc(%rsp),%rax
  77f17b:	mov    %rax,0x3a8(%rsp)
  77f183:	lea    0x370(%rsp),%rax
  77f18b:	mov    %rax,0x3b0(%rsp)
  77f193:	lea    0x170(%rsp),%rax
  77f19b:	mov    %rax,0x3b8(%rsp)
  77f1a3:	mov    0x20(%r15),%rdi
  77f1a7:	mov    %r14,%rsi
  77f1aa:	lea    0x390(%rsp),%rdx
  77f1b2:	call   73f610 <_RINvMs1_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtBa_10TextLayout15selection_rectsNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB1I_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerss_0EB2s_>
  77f1b7:	test   %al,%al
  77f1b9:	je     780e07 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c17>
  77f1bf:	mov    0x120(%rsp),%eax
  77f1c6:	cmp    $0xffffffff,%eax
  77f1c9:	jne    780e15 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c25>
  77f1cf:	mov    %r14,%rdi
  77f1d2:	mov    0xa8(%rsp),%rsi
  77f1da:	mov    0x38(%rsp),%rdx
  77f1df:	mov    $0x1,%ecx
  77f1e4:	call   *0x33b686(%rip)        # aba870 <_DYNAMIC+0x830>
  77f1ea:	add    $0x30,%rbx
  77f1ee:	mov    0x190(%rsp),%rax
  77f1f6:	test   %rax,%rax
  77f1f9:	je     77f29f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x30af>
  77f1ff:	movups 0x180(%rsp),%xmm0
  77f207:	movaps %xmm0,0x700(%rsp)
  77f20f:	movaps 0x170(%rsp),%xmm0
  77f217:	movaps %xmm0,0x120(%rsp)
  77f21f:	movss  0xd8(%rsp),%xmm0
  77f228:	movss  0xdc(%rsp),%xmm1
  77f231:	lea    0x2a8(%rsp),%rdx
  77f239:	mov    0x10(%rdx),%rcx
  77f23d:	mov    %rcx,0x3a0(%rsp)
  77f245:	movups (%rdx),%xmm2
  77f248:	movaps %xmm2,0x390(%rsp)
  77f250:	mov    %rax,(%rsp)
  77f254:	lea    0x970(%rsp),%rdi
  77f25c:	mov    %rbx,%rsi
  77f25f:	mov    %r15,%rdx
  77f262:	lea    0x390(%rsp),%rcx
  77f26a:	lea    0x120(%rsp),%r8
  77f272:	lea    0x700(%rsp),%r9
  77f27a:	movss  0x9c(%rsp),%xmm2
  77f283:	call   *0x33b5ff(%rip)        # aba888 <_DYNAMIC+0x848>
  77f289:	jmp    77f320 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3130>
  77f28e:	movq   $0x0,0x1f8(%rsp)
  77f29a:	jmp    77f4f9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3309>
  77f29f:	movaps 0x170(%rsp),%xmm0
  77f2a7:	movaps %xmm0,0x120(%rsp)
  77f2af:	movss  0xd8(%rsp),%xmm0
  77f2b8:	movss  0xdc(%rsp),%xmm1
  77f2c1:	lea    0x2a8(%rsp),%rcx
  77f2c9:	mov    0x10(%rcx),%rax
  77f2cd:	mov    %rax,0x3a0(%rsp)
  77f2d5:	movups (%rcx),%xmm2
  77f2d8:	movaps %xmm2,0x390(%rsp)
  77f2e0:	movaps 0x960(%rsp),%xmm2
  77f2e8:	movaps %xmm2,0x180(%rsp)
  77f2f0:	lea    0x970(%rsp),%rdi
  77f2f8:	mov    %rbx,%rsi
  77f2fb:	mov    %r15,%rdx
  77f2fe:	lea    0x390(%rsp),%rcx
  77f306:	lea    0x120(%rsp),%r8
  77f30e:	mov    %r14,%r9
  77f311:	movss  0x9c(%rsp),%xmm2
  77f31a:	call   *0x33b570(%rip)        # aba890 <_DYNAMIC+0x850>
  77f320:	cmp    $0xffffffff,%eax
  77f323:	jne    780d4c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4b5c>
  77f329:	cmpb   $0x2,0xe0(%rsp)
  77f331:	je     77f4d6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x32e6>
  77f337:	mov    0x11c(%rsp),%eax
  77f33e:	cmp    0x1d0(%rsp),%eax
  77f345:	jne    77f4d6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x32e6>
  77f34b:	mov    0x40(%rsp),%rax
  77f350:	mov    0x628(%rax),%rax
  77f357:	test   %rax,%rax
  77f35a:	je     77f4d6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x32e6>
  77f360:	mov    0x40(%rsp),%rcx
  77f365:	cmp    0x5f0(%rcx),%rax
  77f36c:	jne    77f4d6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x32e6>
  77f372:	mov    0x30(%rsp),%rax
  77f377:	mov    (%rax,%r13,1),%rax
  77f37b:	mov    0x40(%rsp),%rcx
  77f380:	cmp    %rax,0x630(%rcx)
  77f387:	jne    77f4d6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x32e6>
  77f38d:	movzbl 0xe0(%rsp),%ecx
  77f395:	mov    %r14,%rdi
  77f398:	mov    %r15,%rsi
  77f39b:	mov    0x11c(%rsp),%edx
  77f3a2:	call   *0x33b320(%rip)        # aba6c8 <_DYNAMIC+0x688>
  77f3a8:	movq   $0x18,0x390(%rsp)
  77f3b4:	cmpl   $0x1,0x180(%rsp)
  77f3bc:	jne    780e07 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c17>
  77f3c2:	lea    0x390(%rsp),%rbx
  77f3ca:	mov    %rbx,%rdi
  77f3cd:	call   74d810 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  77f3d2:	movsd  0x184(%rsp),%xmm0
  77f3db:	movaps 0x2c0(%rsp),%xmm1
  77f3e3:	unpcklps 0x910(%rsp),%xmm1
  77f3eb:	addps  %xmm0,%xmm1
  77f3ee:	movhps 0x18c(%rsp),%xmm1
  77f3f6:	movups %xmm1,0x700(%rsp)
  77f3fe:	mov    %rbx,%rdi
  77f401:	mov    0xa8(%rsp),%rsi
  77f409:	mov    0x38(%rsp),%rdx
  77f40e:	mov    $0x1,%ecx
  77f413:	call   *0x33b457(%rip)        # aba870 <_DYNAMIC+0x830>
  77f419:	mov    0x3a0(%rsp),%r9
  77f421:	test   %r9,%r9
  77f424:	je     77f48f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x329f>
  77f426:	movups 0x390(%rsp),%xmm0
  77f42e:	movaps %xmm0,0x120(%rsp)
  77f436:	movaps 0x170(%rsp),%xmm0
  77f43e:	movaps %xmm0,0x180(%rsp)
  77f446:	xorps  %xmm0,%xmm0
  77f449:	lea    0x970(%rsp),%rdi
  77f451:	lea    0x700(%rsp),%rsi
  77f459:	lea    0xb80(%rsp),%rdx
  77f461:	mov    %r14,%rcx
  77f464:	lea    0x120(%rsp),%r8
  77f46c:	call   *0x33b406(%rip)        # aba878 <_DYNAMIC+0x838>
  77f472:	jmp    77f4cd <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x32dd>
  77f474:	mov    $0x1,%r12b
  77f477:	cmp    $0x7,%eax
  77f47a:	je     77e94a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x275a>
  77f480:	jmp    781122 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4f32>
  77f485:	mov    $0xffffffff,%edi
  77f48a:	jmp    77ee86 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x2c96>
  77f48f:	movaps 0x170(%rsp),%xmm0
  77f497:	movaps %xmm0,0x390(%rsp)
  77f49f:	lea    0x970(%rsp),%rdi
  77f4a7:	lea    0x700(%rsp),%rsi
  77f4af:	lea    0xb80(%rsp),%rdx
  77f4b7:	lea    0x390(%rsp),%rcx
  77f4bf:	lea    0x960(%rsp),%r8
  77f4c7:	call   *0x33ae53(%rip)        # aba320 <_DYNAMIC+0x2e0>
  77f4cd:	cmp    $0xffffffff,%eax
  77f4d0:	jne    780d4c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4b5c>
  77f4d6:	mov    0x2f8(%rsp),%rax
  77f4de:	mov    %rax,0x1f0(%rsp)
  77f4e6:	mov    0x300(%rsp),%rax
  77f4ee:	mov    %rax,0x1f8(%rsp)
  77f4f6:	mov    %r14,%r15
  77f4f9:	mov    0x30(%rsp),%r14
  77f4fe:	test   %bpl,%bpl
  77f501:	je     77f65a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x346a>
  77f507:	mov    0x20(%r14,%r13,1),%edi
  77f50c:	call   *0x33afa6(%rip)        # aba4b8 <_DYNAMIC+0x478>
  77f512:	mov    %edx,%ebp
  77f514:	cmp    $0x2,%dl
  77f517:	je     77f65a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x346a>
  77f51d:	mov    0x2d8(%rsp),%rcx
  77f525:	mov    (%rcx),%rcx
  77f528:	test   %rcx,%rcx
  77f52b:	je     781140 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4f50>
  77f531:	mov    0x10(%rcx),%rsi
  77f535:	mov    %eax,%ebx
  77f537:	cmp    %rbx,%rsi
  77f53a:	jbe    7812f4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5104>
  77f540:	mov    0x8(%rcx),%rax
  77f544:	movaps 0x930(%rsp),%xmm4
  77f54c:	movaps %xmm4,%xmm0
  77f54f:	shufps $0xe8,%xmm4,%xmm0
  77f553:	movaps 0x940(%rsp),%xmm3
  77f55b:	addps  %xmm0,%xmm3
  77f55e:	movaps 0x2c0(%rsp),%xmm5
  77f566:	movaps %xmm5,%xmm1
  77f569:	shufps $0xe8,%xmm5,%xmm1
  77f56d:	addps  %xmm1,%xmm3
  77f570:	movaps 0x630(%rsp),%xmm2
  77f578:	subps  %xmm1,%xmm2
  77f57b:	shufps $0xed,%xmm5,%xmm5
  77f57f:	subps  %xmm5,%xmm2
  77f582:	subps  %xmm0,%xmm2
  77f585:	shufps $0xed,%xmm4,%xmm4
  77f589:	subps  %xmm4,%xmm2
  77f58c:	subps  0x920(%rsp),%xmm2
  77f594:	movlhps %xmm2,%xmm3
  77f597:	movups %xmm3,0x370(%rsp)
  77f59f:	testb  $0x1,0x2a4(%rsp)
  77f5a7:	movl   $0x1,0x398(%rsp)
  77f5b2:	movq   $0x23,0x390(%rsp)
  77f5be:	je     780d9c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4bac>
  77f5c4:	lea    (%rax,%rbx,8),%rbx
  77f5c8:	lea    0x390(%rsp),%r14
  77f5d0:	mov    %r14,%rdi
  77f5d3:	call   74d810 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  77f5d8:	lea    0x2a8(%rsp),%rcx
  77f5e0:	movups (%rcx),%xmm0
  77f5e3:	movaps %xmm0,0x120(%rsp)
  77f5eb:	mov    0x10(%rcx),%rax
  77f5ef:	mov    %rax,0x130(%rsp)
  77f5f7:	movups (%rcx),%xmm0
  77f5fa:	movaps %xmm0,0xc40(%rsp)
  77f602:	mov    0x10(%rcx),%rax
  77f606:	mov    %rax,0xc50(%rsp)
  77f60e:	movaps 0x170(%rsp),%xmm0
  77f616:	movaps %xmm0,0x390(%rsp)
  77f61e:	movzbl %bpl,%r9d
  77f622:	lea    0x970(%rsp),%rdi
  77f62a:	mov    %rbx,%rsi
  77f62d:	lea    0x370(%rsp),%rdx
  77f635:	lea    0xc40(%rsp),%rcx
  77f63d:	mov    %r14,%r8
  77f640:	mov    0x30(%rsp),%r14
  77f645:	movss  0x74(%rsp),%xmm0
  77f64b:	call   *0x33b247(%rip)        # aba898 <_DYNAMIC+0x858>
  77f651:	cmp    $0xffffffff,%eax
  77f654:	jne    780dd2 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4be2>
  77f65a:	mov    0x18(%r14,%r13,1),%ebx
  77f65f:	cmpb   $0x0,0x2f(%rsp)
  77f664:	je     77f68e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x349e>
  77f666:	cmp    $0xffffffff,%ebx
  77f669:	je     77f689 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3499>
  77f66b:	mov    0x110(%rsp),%rsi
  77f673:	cmp    %rbx,%rsi
  77f676:	jbe    7812e5 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x50f5>
  77f67c:	mov    0x108(%rsp),%rax
  77f684:	mov    (%rax,%rbx,4),%ebx
  77f687:	jmp    77f68e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x349e>
  77f689:	mov    $0xffffffff,%ebx
  77f68e:	cmpb   $0x0,0x60(%rsp)
  77f693:	je     77f77f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x358f>
  77f699:	movss  0x298(%rsp),%xmm0
  77f6a2:	xorps  %xmm1,%xmm1
  77f6a5:	ucomiss %xmm1,%xmm0
  77f6a8:	jne    77f6ac <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x34bc>
  77f6aa:	jnp    77f6c4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x34d4>
  77f6ac:	movss  0x29c(%rsp),%xmm0
  77f6b5:	ucomiss %xmm1,%xmm0
  77f6b8:	jne    77f77f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x358f>
  77f6be:	jp     77f77f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x358f>
  77f6c4:	cmpb   $0x0,0x1d4(%rsp)
  77f6cc:	je     77f6f6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3506>
  77f6ce:	movss  0x1b8(%rsp),%xmm0
  77f6d7:	ucomiss %xmm1,%xmm0
  77f6da:	jne    77f6de <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x34ee>
  77f6dc:	jnp    77f6f6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3506>
  77f6de:	movss  0x1bc(%rsp),%xmm0
  77f6e7:	ucomiss %xmm1,%xmm0
  77f6ea:	jne    77f77f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x358f>
  77f6f0:	jp     77f77f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x358f>
  77f6f6:	test   %r12b,%r12b
  77f6f9:	je     77f71b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x352b>
  77f6fb:	movss  0x1b8(%rsp),%xmm0
  77f704:	ucomiss %xmm1,%xmm0
  77f707:	jne    77f70b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x351b>
  77f709:	jnp    77f71b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x352b>
  77f70b:	movss  0x1bc(%rsp),%xmm0
  77f714:	ucomiss %xmm1,%xmm0
  77f717:	jne    77f77f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x358f>
  77f719:	jp     77f77f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x358f>
  77f71b:	mov    0x110(%rsp),%r14
  77f723:	cmp    0x100(%rsp),%r14
  77f72b:	jne    77f73a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x354a>
  77f72d:	lea    0x100(%rsp),%rdi
  77f735:	call   772de0 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtCslbxve4rcJus_4gpui7runtime6ParentE8grow_oneCs9C2G9YFESsD_29canonical_text_public_control>
  77f73a:	mov    0x108(%rsp),%rax
  77f742:	mov    %ebx,(%rax,%r14,4)
  77f746:	inc    %r14
  77f749:	mov    %r14,0x110(%rsp)
  77f751:	mov    0x1f8(%rsp),%rax
  77f759:	test   %rax,%rax
  77f75c:	je     77dec6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1cd6>
  77f762:	lock decq (%rax)
  77f766:	jne    77dec6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1cd6>
  77f76c:	lea    0x1f8(%rsp),%rdi
  77f774:	call   *0x33ac26(%rip)        # aba3a0 <_DYNAMIC+0x360>
  77f77a:	jmp    77dec6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1cd6>
  77f77f:	mov    0x20(%r14,%r13,1),%edi
  77f784:	mov    $0x1,%r12b
  77f787:	call   776700 <_RNvMsh_NtCslbxve4rcJus_4gpui7runtimeNtB5_4Node4kind>
  77f78c:	cmp    $0x7,%al
  77f78e:	jne    77f7a9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x35b9>
  77f790:	mov    0x30(%rsp),%rax
  77f795:	mov    (%rax,%r13,1),%rsi
  77f799:	mov    $0x1,%r12b
  77f79c:	lea    0x6a8(%rsp),%rdi
  77f7a4:	call   77b170 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapyNtNtB7_7set_val9SetValZSTE6insertCs9C2G9YFESsD_29canonical_text_public_control>
  77f7a9:	cmpb   $0x0,0x2f(%rsp)
  77f7ae:	je     77f801 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3611>
  77f7b0:	mov    0x150(%rsp),%rsi
  77f7b8:	mov    $0x1,%edi
  77f7bd:	mov    $0x1,%r12b
  77f7c0:	call   *0x33aafa(%rip)        # aba2c0 <_DYNAMIC+0x280>
  77f7c6:	mov    %eax,%ebp
  77f7c8:	mov    0x110(%rsp),%r14
  77f7d0:	cmp    0x100(%rsp),%r14
  77f7d8:	jne    77f7ea <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x35fa>
  77f7da:	mov    $0x1,%r12b
  77f7dd:	lea    0x100(%rsp),%rdi
  77f7e5:	call   772de0 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtCslbxve4rcJus_4gpui7runtime6ParentE8grow_oneCs9C2G9YFESsD_29canonical_text_public_control>
  77f7ea:	mov    0x108(%rsp),%rax
  77f7f2:	mov    %ebp,(%rax,%r14,4)
  77f7f6:	inc    %r14
  77f7f9:	mov    %r14,0x110(%rsp)
  77f801:	movss  0x298(%rsp),%xmm0
  77f80a:	xor    %edx,%edx
  77f80c:	xorps  %xmm1,%xmm1
  77f80f:	ucomiss %xmm1,%xmm0
  77f812:	jne    77f81a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x362a>
  77f814:	jnp    77f8a1 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x36b1>
  77f81a:	movss  0x29c(%rsp),%xmm0
  77f823:	ucomiss %xmm1,%xmm0
  77f826:	mov    $0x0,%ebp
  77f82b:	mov    0x30(%rsp),%rsi
  77f830:	jne    77f834 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3644>
  77f832:	jnp    77f8a3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x36b3>
  77f834:	mov    0x20(%rsi,%r13,1),%edi
  77f839:	mov    %edi,%eax
  77f83b:	and    $0xf,%eax
  77f83e:	cmp    $0x9,%eax
  77f841:	ja     78125a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x506a>
  77f847:	cmp    $0x6,%eax
  77f84a:	je     77f854 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3664>
  77f84c:	mov    $0x1,%bpl
  77f84f:	cmp    $0xf,%edi
  77f852:	ja     77f8a3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x36b3>
  77f854:	mov    0x348(%rsp),%eax
  77f85b:	mov    $0x3fffffff,%ecx
  77f860:	and    %ecx,%eax
  77f862:	cmp    $0x3f800001,%eax
  77f867:	mov    $0x80000000,%ecx
  77f86c:	cmove  %ecx,%eax
  77f86f:	movd   %eax,%xmm0
  77f873:	mov    $0x1,%bpl
  77f876:	ucomiss %xmm1,%xmm0
  77f879:	ja     77f8a3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x36b3>
  77f87b:	cmpq   $0x0,0x8(%rsi,%r13,1)
  77f881:	jne    77f8a3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x36b3>
  77f883:	mov    $0x1,%r12b
  77f886:	call   776700 <_RNvMsh_NtCslbxve4rcJus_4gpui7runtimeNtB5_4Node4kind>
  77f88b:	lea    -0x4(%rax),%ecx
  77f88e:	cmp    $0x2,%al
  77f890:	setae  %al
  77f893:	test   $0xfb,%cl
  77f896:	sete   %bpl
  77f89a:	and    %al,%bpl
  77f89d:	xor    %edx,%edx
  77f89f:	jmp    77f8a3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x36b3>
  77f8a1:	xor    %ebp,%ebp
  77f8a3:	mov    0x150(%rsp),%rax
  77f8ab:	test   %rax,%rax
  77f8ae:	je     77f8c5 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x36d5>
  77f8b0:	mov    0x148(%rsp),%rcx
  77f8b8:	shl    $0x6,%rax
  77f8bc:	mov    -0x8(%rcx,%rax,1),%ecx
  77f8c0:	mov    $0x1,%edx
  77f8c5:	mov    %ebp,%eax
  77f8c7:	xor    $0x1,%al
  77f8c9:	movzbl %al,%esi
  77f8cc:	mov    $0x1,%r12b
  77f8cf:	mov    %ebx,%edi
  77f8d1:	call   *0x33afc9(%rip)        # aba8a0 <_DYNAMIC+0x860>
  77f8d7:	mov    %eax,0x2c0(%rsp)
  77f8de:	mov    0x1f8(%rsp),%rax
  77f8e6:	test   %rax,%rax
  77f8e9:	sete   0x60(%rsp)
  77f8ee:	je     77f930 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3740>
  77f8f0:	mov    0x150(%rsp),%ecx
  77f8f7:	mov    %ecx,0x3a0(%rsp)
  77f8fe:	movsd  0x1f0(%rsp),%xmm0
  77f907:	movsd  %xmm0,0x398(%rsp)
  77f910:	mov    %rax,0x390(%rsp)
  77f918:	xor    %r12d,%r12d
  77f91b:	lea    0x200(%rsp),%rdi
  77f923:	lea    0x390(%rsp),%rsi
  77f92b:	call   776030 <_RNvMsF_NtCscdodAO9FK5_5alloc3vecINtB5_3VecNtNtNtCslbxve4rcJus_4gpui7runtime13text_geometry5EntryE8push_mutCs9C2G9YFESsD_29canonical_text_public_control>
  77f930:	cmp    $0xffffffff,%ebx
  77f933:	je     77f968 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3778>
  77f935:	mov    %ebx,%ebx
  77f937:	mov    0x150(%rsp),%rsi
  77f93f:	cmp    %rbx,%rsi
  77f942:	jbe    781367 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5177>
  77f948:	mov    0x148(%rsp),%rax
  77f950:	shl    $0x6,%rbx
  77f954:	mov    0x30(%rax,%rbx,1),%rax
  77f959:	mov    %rax,0x394(%rsp)
  77f961:	mov    $0x1,%eax
  77f966:	jmp    77f96a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x377a>
  77f968:	xor    %eax,%eax
  77f96a:	mov    %eax,0x390(%rsp)
  77f971:	movzbl 0x60(%rsp),%eax
  77f976:	mov    %eax,%r12d
  77f979:	lea    0x2a4(%rsp),%rdi
  77f981:	lea    0x390(%rsp),%rsi
  77f989:	lea    0x268(%rsp),%rdx
  77f991:	call   *0x33af11(%rip)        # aba8a8 <_DYNAMIC+0x868>
  77f997:	mov    %rax,%rbx
  77f99a:	mov    0x30(%rsp),%rax
  77f99f:	mov    (%rax,%r13,1),%r14
  77f9a3:	mov    0x20(%rax,%r13,1),%edi
  77f9a8:	movzbl 0x60(%rsp),%eax
  77f9ad:	mov    %eax,%r12d
  77f9b0:	call   776700 <_RNvMsh_NtCslbxve4rcJus_4gpui7runtimeNtB5_4Node4kind>
  77f9b5:	mov    %eax,%r15d
  77f9b8:	mov    0x30(%rsp),%rax
  77f9bd:	mov    0x20(%rax,%r13,1),%edi
  77f9c2:	mov    %edi,%eax
  77f9c4:	and    $0xf,%eax
  77f9c7:	cmp    $0x9,%eax
  77f9ca:	ja     78123c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x504c>
  77f9d0:	cmp    $0x6,%eax
  77f9d3:	je     77fe11 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3c21>
  77f9d9:	shr    $0x4,%edi
  77f9dc:	dec    %edi
  77f9de:	mov    0x40(%rsp),%rax
  77f9e3:	mov    0x2f0(%rax),%rsi
  77f9ea:	mov    0x2f8(%rax),%rdx
  77f9f1:	movzbl 0x60(%rsp),%eax
  77f9f6:	mov    %eax,%r12d
  77f9f9:	call   7765a0 <_RNvMsf_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSlot3get>
  77f9fe:	mov    %ebp,0x74(%rsp)
  77fa02:	test   %rax,%rax
  77fa05:	je     77fa39 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3849>
  77fa07:	mov    0x40(%rax),%rbp
  77fa0b:	testb  $0x1,0x0(%rbp)
  77fa0f:	jne    77fa3b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x384b>
  77fa11:	mov    0x8(%rbp),%rax
  77fa15:	test   $0x1,%al
  77fa17:	jne    77fa3b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x384b>
  77fa19:	mov    $0x2,%eax
  77fa1e:	lock xadd %rax,0x8(%rbp)
  77fa24:	and    0x888(%rsp),%rax
  77fa2c:	neg    %rax
  77fa2f:	jno    77fa3b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x384b>
  77fa31:	lock orq $0x1,0x8(%rbp)
  77fa37:	jmp    77fa3b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x384b>
  77fa39:	xor    %ebp,%ebp
  77fa3b:	movdqa 0x630(%rsp),%xmm0
  77fa44:	movd   %xmm0,%esi
  77fa48:	shufps $0x55,%xmm0,%xmm0
  77fa4c:	movd   %xmm0,%eax
  77fa50:	shl    $0x20,%rax
  77fa54:	or     %rax,%rsi
  77fa57:	lea    0x180(%rsp),%rdi
  77fa5f:	lea    0x2a4(%rsp),%rdx
  77fa67:	call   *0x33ae43(%rip)        # aba8b0 <_DYNAMIC+0x870>
  77fa6d:	mov    0x30(%rsp),%r12
  77fa72:	mov    0x20(%r12,%r13,1),%edi
  77fa77:	call   776700 <_RNvMsh_NtCslbxve4rcJus_4gpui7runtimeNtB5_4Node4kind>
  77fa7c:	xor    %esi,%esi
  77fa7e:	cmpq   $0x0,0x8(%r12,%r13,1)
  77fa84:	setne  %sil
  77fa88:	movzbl %al,%edi
  77fa8b:	call   776350 <_RNvMs_NtNtCslbxve4rcJus_4gpui7runtime9semanticsNtB4_7Actions8for_node>
  77fa90:	mov    0x18(%r12,%r13,1),%ecx
  77fa95:	mov    $0xffffffff,%edx
  77fa9a:	cmp    %rdx,%rcx
  77fa9d:	je     77fad3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x38e3>
  77fa9f:	cmp    %rcx,0x168(%rsp)
  77faa7:	mov    0x2c0(%rsp),%esi
  77faae:	jbe    77faca <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x38da>
  77fab0:	mov    0x160(%rsp),%rdx
  77fab8:	cmpb   $0x0,(%rdx,%rcx,1)
  77fabc:	setne  %cl
  77fabf:	mov    0xbc(%rsp),%edx
  77fac6:	or     %cl,%dl
  77fac8:	jmp    77fae1 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x38f1>
  77faca:	mov    0xbc(%rsp),%edx
  77fad1:	jmp    77fae1 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x38f1>
  77fad3:	mov    0xbc(%rsp),%edx
  77fada:	mov    0x2c0(%rsp),%esi
  77fae1:	movzbl %al,%ecx
  77fae4:	or     $0x20,%al
  77fae6:	movzbl %al,%eax
  77fae9:	test   %dl,%dl
  77faeb:	cmove  %ecx,%eax
  77faee:	mov    %r14,0x3b0(%rsp)
  77faf6:	mov    %esi,0x3c8(%rsp)
  77fafd:	mov    %r15b,0x3cd(%rsp)
  77fb05:	mov    %rbp,0x3b8(%rsp)
  77fb0d:	movups 0x180(%rsp),%xmm0
  77fb15:	movaps %xmm0,0x390(%rsp)
  77fb1d:	mov    %rbx,0x3c0(%rsp)
  77fb25:	movups 0x290(%rsp),%xmm0
  77fb2d:	lea    0x394(%rsp),%rcx
  77fb35:	movups %xmm0,0xc(%rcx)
  77fb39:	mov    0x74(%rsp),%ecx
  77fb3d:	mov    %cl,0x3ce(%rsp)
  77fb44:	mov    %al,0x3cc(%rsp)
  77fb4b:	movzbl 0x60(%rsp),%eax
  77fb50:	mov    %eax,%r12d
  77fb53:	lea    0x140(%rsp),%rdi
  77fb5b:	lea    0x390(%rsp),%rsi
  77fb63:	call   775fb0 <_RNvMsF_NtCscdodAO9FK5_5alloc3vecINtB5_3VecNtNtCslbxve4rcJus_4gpui7runtime9PresentedE8push_mutCs9C2G9YFESsD_29canonical_text_public_control>
  77fb68:	cmpb   $0x2,0x690(%rsp)
  77fb70:	je     77fd94 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3ba4>
  77fb76:	mov    0x150(%rsp),%rsi
  77fb7e:	lea    -0x1(%rsi),%rbx
  77fb82:	mov    0x40(%rsp),%rax
  77fb87:	cmp    0x5c0(%rax),%rbx
  77fb8e:	jae    77fbd1 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x39e1>
  77fb90:	mov    0x5b8(%rax),%r14
  77fb97:	movzbl 0x60(%rsp),%eax
  77fb9c:	mov    %eax,%r12d
  77fb9f:	lea    0xb98(%rsp),%rdi
  77fba7:	call   *0x33ab8b(%rip)        # aba738 <_DYNAMIC+0x6f8>
  77fbad:	mov    %rax,0x878(%rsp)
  77fbb5:	mov    %rdx,0x880(%rsp)
  77fbbd:	mov    %rbx,%rax
  77fbc0:	shl    $0x6,%rax
  77fbc4:	add    %rax,%r14
  77fbc7:	mov    0x150(%rsp),%rsi
  77fbcf:	jmp    77fbd4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x39e4>
  77fbd1:	xor    %r14d,%r14d
  77fbd4:	cmp    %rsi,%rbx
  77fbd7:	jae    781358 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5168>
  77fbdd:	mov    %rbx,%rax
  77fbe0:	shl    $0x6,%rax
  77fbe4:	add    0x148(%rsp),%rax
  77fbec:	movups 0x270(%rsp),%xmm0
  77fbf4:	mov    %r14,0x198(%rsp)
  77fbfc:	mov    0x878(%rsp),%rcx
  77fc04:	mov    %rcx,0x1a0(%rsp)
  77fc0c:	mov    0x880(%rsp),%rcx
  77fc14:	mov    %rcx,0x1a8(%rsp)
  77fc1c:	mov    %rax,0x180(%rsp)
  77fc24:	movups %xmm0,0x188(%rsp)
  77fc2c:	mov    0x40(%rsp),%rcx
  77fc31:	mov    0x650(%rcx),%rax
  77fc38:	mov    %rax,0x120(%rsp)
  77fc40:	mov    0x678(%rsp),%rax
  77fc48:	mov    %rax,0x128(%rsp)
  77fc50:	mov    0x2f0(%rsp),%eax
  77fc57:	lea    0x130(%rsp),%rdx
  77fc5f:	mov    %eax,0x8(%rdx)
  77fc62:	mov    0x2e8(%rsp),%rax
  77fc6a:	mov    %rax,(%rdx)
  77fc6d:	movzbl 0x57(%rsp),%eax
  77fc72:	mov    %al,0x13c(%rsp)
  77fc79:	movzbl 0x7c(%rsp),%eax
  77fc7e:	mov    %al,0xf(%rdx)
  77fc81:	movzwl 0x7a(%rsp),%eax
  77fc86:	mov    %ax,0xd(%rdx)
  77fc8a:	mov    0x6e8(%rcx),%rdi
  77fc91:	test   %rdi,%rdi
  77fc94:	je     77fcac <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3abc>
  77fc96:	movzbl 0x60(%rsp),%eax
  77fc9b:	mov    %eax,%r12d
  77fc9e:	mov    %rbx,%rsi
  77fca1:	call   *0x33ac11(%rip)        # aba8b8 <_DYNAMIC+0x878>
  77fca7:	mov    %rax,%r15
  77fcaa:	jmp    77fcaf <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3abf>
  77fcac:	xor    %r15d,%r15d
  77fcaf:	mov    0x210(%rsp),%rax
  77fcb7:	test   %rax,%rax
  77fcba:	mov    0x30(%rsp),%rsi
  77fcbf:	je     77fcf7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3b07>
  77fcc1:	mov    0x208(%rsp),%rcx
  77fcc9:	lea    (%rax,%rax,2),%rdx
  77fccd:	lea    (%rcx,%rdx,8),%rax
  77fcd1:	add    $0xffffffffffffffe8,%rax
  77fcd5:	mov    $0x0,%ebp
  77fcda:	test   %rax,%rax
  77fcdd:	je     77fcf9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3b09>
  77fcdf:	lea    (%rcx,%rdx,8),%rcx
  77fce3:	mov    -0x8(%rcx),%ecx
  77fce6:	cmp    %rcx,%rbx
  77fce9:	mov    $0x0,%ecx
  77fcee:	cmovne %rcx,%rax
  77fcf2:	mov    %rax,%rbp
  77fcf5:	jmp    77fcf9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3b09>
  77fcf7:	xor    %ebp,%ebp
  77fcf9:	mov    (%rsi,%r13,1),%rdx
  77fcfd:	cvtps2pd 0x630(%rsp),%xmm0
  77fd05:	movaps %xmm0,0x370(%rsp)
  77fd0d:	movzbl 0x60(%rsp),%eax
  77fd12:	mov    %eax,%r12d
  77fd15:	lea    0x390(%rsp),%rdi
  77fd1d:	lea    0x6c0(%rsp),%rsi
  77fd25:	lea    0x370(%rsp),%rcx
  77fd2d:	call   *0x33ab8d(%rip)        # aba8c0 <_DYNAMIC+0x880>
  77fd33:	mov    0x30(%rsp),%rax
  77fd38:	mov    (%rax,%r13,1),%rdx
  77fd3c:	mov    0x40(%rsp),%rax
  77fd41:	mov    0x670(%rax),%rdi
  77fd48:	mov    0x678(%rax),%rsi
  77fd4f:	call   744a50 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyNtNtNtCslbxve4rcJus_4gpui7runtime4list7ListRowE3getyECs9C2G9YFESsD_29canonical_text_public_control>
  77fd54:	mov    %rax,0x8(%rsp)
  77fd59:	lea    0x390(%rsp),%rax
  77fd61:	mov    %rax,(%rsp)
  77fd65:	movzbl 0x60(%rsp),%eax
  77fd6a:	mov    %eax,%r12d
  77fd6d:	lea    0x688(%rsp),%rdi
  77fd75:	mov    %rbx,%rsi
  77fd78:	lea    0x180(%rsp),%rdx
  77fd80:	mov    %r15,%r8
  77fd83:	mov    %rbp,%r9
  77fd86:	lea    0x120(%rsp),%rcx
  77fd8e:	call   *0x33ab34(%rip)        # aba8c8 <_DYNAMIC+0x888>
  77fd94:	cmpl   $0xffffffff,0x810(%rsp)
  77fd9c:	je     77fdf1 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3c01>
  77fd9e:	mov    0xf0(%rsp),%rax
  77fda6:	mov    (%rax),%rbx
  77fda9:	test   %rbx,%rbx
  77fdac:	je     77fdf1 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3c01>
  77fdae:	mov    0x30(%rsp),%rax
  77fdb3:	mov    (%rax,%r13,1),%r15
  77fdb7:	mov    0x40(%rsp),%rax
  77fdbc:	mov    0x670(%rax),%rdi
  77fdc3:	mov    0x678(%rax),%rsi
  77fdca:	mov    %r15,%rdx
  77fdcd:	call   744a50 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyNtNtNtCslbxve4rcJus_4gpui7runtime4list7ListRowE3getyECs9C2G9YFESsD_29canonical_text_public_control>
  77fdd2:	movzbl 0x60(%rsp),%ecx
  77fdd7:	mov    %ecx,%r12d
  77fdda:	lea    0x810(%rsp),%rdi
  77fde2:	mov    %rbx,%rsi
  77fde5:	mov    %r15,%rdx
  77fde8:	mov    %rax,%rcx
  77fdeb:	call   *0x33a8f7(%rip)        # aba6e8 <_DYNAMIC+0x6a8>
  77fdf1:	mov    0x38(%rsp),%rcx
  77fdf6:	inc    %rcx
  77fdf9:	cmp    0x660(%rsp),%rcx
  77fe01:	lea    0x180(%rsp),%r15
  77fe09:	jb     77dea2 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1cb2>
  77fe0f:	jmp    77fe1b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3c2b>
  77fe11:	mov    $0xffffffff,%edi
  77fe16:	jmp    77f9de <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x37ee>
  77fe1b:	cmpl   $0xffffffff,0x810(%rsp)
  77fe23:	mov    0x40(%rsp),%r14
  77fe28:	mov    0xf8(%rsp),%rbx
  77fe30:	je     77fe40 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3c50>
  77fe32:	lea    0x810(%rsp),%rdi
  77fe3a:	call   *0x33a8b0(%rip)        # aba6f0 <_DYNAMIC+0x6b0>
  77fe40:	movzbl 0x690(%rsp),%eax
  77fe48:	cmp    $0x2,%al
  77fe4a:	je     77fe9b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3cab>
  77fe4c:	mov    0x688(%rsp),%rdi
  77fe54:	mov    0x6a0(%r14),%rcx
  77fe5b:	mov    0x260(%rsp),%rdx
  77fe63:	mov    %rdx,0x390(%rsp)
  77fe6b:	mov    %rcx,0x398(%rsp)
  77fe73:	mov    %rbx,0x3a0(%rsp)
  77fe7b:	mov    0x5c0(%r14),%rcx
  77fe82:	mov    0x150(%rsp),%r8
  77fe8a:	movzbl %al,%esi
  77fe8d:	lea    0x390(%rsp),%rdx
  77fe95:	call   *0x33a85d(%rip)        # aba6f8 <_DYNAMIC+0x6b8>
  77fe9b:	lea    0x1e8(%r14),%rbx
  77fea2:	mov    0x650(%r14),%rax
  77fea9:	test   %rax,%rax
  77feac:	je     77ff8c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3d9c>
  77feb2:	mov    0x100(%rax),%rdx
  77feb9:	lea    0x268(%rsp),%rax
  77fec1:	mov    %rax,0x390(%rsp)
  77fec9:	lea    0x2f(%rsp),%rax
  77fece:	mov    %rax,0x398(%rsp)
  77fed6:	mov    %rbx,0x3a0(%rsp)
  77fede:	lea    0x100(%rsp),%rax
  77fee6:	mov    %rax,0x3a8(%rsp)
  77feee:	lea    0x140(%rsp),%rax
  77fef6:	mov    %rax,0x3b0(%rsp)
  77fefe:	test   %rdx,%rdx
  77ff01:	je     77ff8c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3d9c>
  77ff07:	lea    0x310(%rsp),%rdi
  77ff0f:	lea    0x390(%rsp),%rsi
  77ff17:	call   75de60 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersD_0BQ_>
  77ff1c:	mov    0x320(%rsp),%rax
  77ff24:	mov    %rax,0x7a0(%rsp)
  77ff2c:	movups 0x310(%rsp),%xmm0
  77ff34:	movaps %xmm0,0x790(%rsp)
  77ff3c:	jmp    77ff98 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3da8>
  77ff3e:	movaps 0x970(%rsp),%xmm0
  77ff46:	movaps 0x980(%rsp),%xmm1
  77ff4e:	movaps 0x990(%rsp),%xmm2
  77ff56:	mov    0x48(%rsp),%rcx
  77ff5b:	movups %xmm2,0x28(%rcx)
  77ff5f:	movups %xmm1,0x18(%rcx)
  77ff63:	movups %xmm0,0x8(%rcx)
  77ff67:	mov    %rax,(%rcx)
  77ff6a:	mov    $0x1,%r12b
  77ff6d:	mov    $0x1,%bl
  77ff6f:	mov    $0x1,%r13b
  77ff72:	mov    $0x1,%bpl
  77ff75:	mov    $0x1,%r15b
  77ff78:	cmpq   $0xffffffffffffffff,0x258(%rsp)
  77ff81:	jne    780e86 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c96>
  77ff87:	jmp    780e96 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4ca6>
  77ff8c:	movq   $0xffffffffffffffff,0x790(%rsp)
  77ff98:	mov    %rbx,0x60(%rsp)
  77ff9d:	mov    0x278(%rsp),%rax
  77ffa5:	mov    %rax,0x3a0(%rsp)
  77ffad:	movups 0x268(%rsp),%xmm0
  77ffb5:	movaps %xmm0,0x390(%rsp)
  77ffbd:	lea    0x180(%rsp),%rdi
  77ffc5:	lea    0x790(%rsp),%rsi
  77ffcd:	lea    0x390(%rsp),%rdx
  77ffd5:	call   73d480 <_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime8geometry6RecordEE7or_elseNCNvMsu_B1i_INtB1i_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersE_0EB2E_>
  77ffda:	cmpb   $0x0,0x76d(%r14)
  77ffe2:	je     78003f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3e4f>
  77ffe4:	lea    0x390(%rsp),%rbx
  77ffec:	lea    0x970(%rsp),%rsi
  77fff4:	mov    $0x1f0,%edx
  77fff9:	mov    %rbx,%rdi
  77fffc:	call   *0x33a29e(%rip)        # aba2a0 <memcpy@GLIBC_2.14>
  780002:	mov    $0x1,%al
  780004:	mov    %eax,0x58(%rsp)
  780008:	mov    $0x1,%r12b
  78000b:	mov    $0x1,%al
  78000d:	mov    %eax,0x38(%rsp)
  780011:	mov    $0x1,%al
  780013:	mov    %eax,0x30(%rsp)
  780017:	mov    $0x1,%r15b
  78001a:	mov    $0x1,%bpl
  78001d:	movb   $0x1,0xc0(%rsp)
  780025:	mov    %rbx,%rdi
  780028:	call   *0x33a8a2(%rip)        # aba8d0 <_DYNAMIC+0x890>
  78002e:	movq   $0x0,0x80(%rsp)
  78003a:	jmp    7800d2 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3ee2>
  78003f:	lea    0x390(%rsp),%rbx
  780047:	lea    0x970(%rsp),%rsi
  78004f:	mov    $0x1f0,%edx
  780054:	mov    %rbx,%rdi
  780057:	call   *0x33a243(%rip)        # aba2a0 <memcpy@GLIBC_2.14>
  78005d:	mov    $0x1,%al
  78005f:	mov    %eax,0x58(%rsp)
  780063:	mov    $0x1,%r12b
  780066:	mov    $0x1,%al
  780068:	mov    %eax,0x38(%rsp)
  78006c:	mov    $0x1,%al
  78006e:	mov    %eax,0x30(%rsp)
  780072:	mov    $0x1,%r15b
  780075:	mov    $0x1,%bpl
  780078:	movb   $0x1,0xc0(%rsp)
  780080:	mov    %rbx,%rdi
  780083:	call   *0x33a84f(%rip)        # aba8d8 <_DYNAMIC+0x898>
  780089:	cmpq   $0xffffffffffffffff,0x5c8(%r14)
  780091:	je     78009c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3eac>
  780093:	mov    0x5e0(%r14),%rsi
  78009a:	jmp    78009e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3eae>
  78009c:	xor    %esi,%esi
  78009e:	mov    $0x1,%cl
  7800a0:	mov    %ecx,0x58(%rsp)
  7800a4:	mov    $0x1,%r12b
  7800a7:	mov    $0x1,%cl
  7800a9:	mov    %ecx,0x38(%rsp)
  7800ad:	mov    $0x1,%cl
  7800af:	mov    %ecx,0x30(%rsp)
  7800b3:	mov    $0x1,%r15b
  7800b6:	mov    $0x1,%bpl
  7800b9:	movb   $0x1,0xc0(%rsp)
  7800c1:	mov    %rax,%rdi
  7800c4:	call   *0x33a5ce(%rip)        # aba698 <_DYNAMIC+0x658>
  7800ca:	mov    %rax,0x80(%rsp)
  7800d2:	mov    0x658(%r14),%rax
  7800d9:	mov    0x668(%r14),%r12
  7800e0:	test   %rax,%rax
  7800e3:	setne  %cl
  7800e6:	test   %r12,%r12
  7800e9:	setne  %dl
  7800ec:	test   %dl,%cl
  7800ee:	je     7802de <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x40ee>
  7800f4:	mov    0x40(%rsp),%rcx
  7800f9:	mov    0x660(%rcx),%r13
  780100:	xor    %r14d,%r14d
  780103:	lea    0x390(%rsp),%rbx
  78010b:	lea    0x6c0(%rsp),%r15
  780113:	jmp    780123 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3f33>
  780115:	mov    $0x0,%eax
  78011a:	dec    %r12
  78011d:	je     7802de <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x40ee>
  780123:	test   %r14,%r14
  780126:	jne    7801a8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3fb8>
  78012c:	test   %r13,%r13
  78012f:	je     780157 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3f67>
  780131:	mov    %r13,%rcx
  780134:	mov    %rax,%r14
  780137:	and    $0x7,%rcx
  78013b:	je     78015c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3f6c>
  78013d:	xor    %edx,%edx
  78013f:	nop
  780140:	mov    0x590(%r14),%r14
  780147:	inc    %rdx
  78014a:	cmp    %rdx,%rcx
  78014d:	jne    780140 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3f50>
  78014f:	mov    %r13,%rax
  780152:	sub    %rdx,%rax
  780155:	jmp    78015f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3f6f>
  780157:	mov    %rax,%r14
  78015a:	jmp    7801a3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3fb3>
  78015c:	mov    %r13,%rax
  78015f:	cmp    $0x8,%r13
  780163:	jb     7801a3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3fb3>
  780165:	mov    0x590(%r14),%rcx
  78016c:	mov    0x590(%rcx),%rcx
  780173:	mov    0x590(%rcx),%rcx
  78017a:	mov    0x590(%rcx),%rcx
  780181:	mov    0x590(%rcx),%rcx
  780188:	mov    0x590(%rcx),%rcx
  78018f:	mov    0x590(%rcx),%rcx
  780196:	mov    0x590(%rcx),%r14
  78019d:	add    $0xfffffffffffffff8,%rax
  7801a1:	jne    780165 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3f75>
  7801a3:	xor    %r13d,%r13d
  7801a6:	xor    %eax,%eax
  7801a8:	movzwl 0x58a(%r14),%ecx
  7801b0:	cmp    %rcx,%r13
  7801b3:	jae    7801c0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3fd0>
  7801b5:	mov    %r13,%rdx
  7801b8:	mov    %r14,%rcx
  7801bb:	jmp    7801e7 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3ff7>
  7801bd:	nopl   (%rax)
  7801c0:	mov    0x580(%r14),%rcx
  7801c7:	test   %rcx,%rcx
  7801ca:	je     781175 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4f85>
  7801d0:	inc    %rax
  7801d3:	movzwl 0x588(%r14),%edx
  7801db:	mov    %rcx,%r14
  7801de:	cmp    0x58a(%rcx),%dx
  7801e5:	jae    7801c0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3fd0>
  7801e7:	test   %rax,%rax
  7801ea:	je     78022a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x403a>
  7801ec:	lea    (%rcx,%rdx,8),%rsi
  7801f0:	add    $0x598,%rsi
  7801f7:	mov    %rax,%rdi
  7801fa:	and    $0x7,%rdi
  7801fe:	je     780233 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4043>
  780200:	xor    %r8d,%r8d
  780203:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  780210:	mov    (%rsi),%r14
  780213:	lea    0x590(%r14),%rsi
  78021a:	inc    %r8
  78021d:	cmp    %r8,%rdi
  780220:	jne    780210 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4020>
  780222:	mov    %rax,%rdi
  780225:	sub    %r8,%rdi
  780228:	jmp    780236 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4046>
  78022a:	lea    0x1(%rdx),%r13
  78022e:	mov    %rcx,%r14
  780231:	jmp    780284 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4094>
  780233:	mov    %rax,%rdi
  780236:	cmp    $0x8,%rax
  78023a:	jb     780281 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4091>
  78023c:	nopl   0x0(%rax)
  780240:	mov    (%rsi),%rax
  780243:	mov    0x590(%rax),%rax
  78024a:	mov    0x590(%rax),%rax
  780251:	mov    0x590(%rax),%rax
  780258:	mov    0x590(%rax),%rax
  78025f:	mov    0x590(%rax),%rax
  780266:	mov    0x590(%rax),%rax
  78026d:	mov    0x590(%rax),%r14
  780274:	lea    0x590(%r14),%rsi
  78027b:	add    $0xfffffffffffffff8,%rdi
  78027f:	jne    780240 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4050>
  780281:	xor    %r13d,%r13d
  780284:	mov    %rdx,%rax
  780287:	shl    $0x4,%rax
  78028b:	cmpl   $0x1,(%rcx,%rax,1)
  78028f:	jne    780115 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3f25>
  780295:	imul   $0x70,%rdx,%rdx
  780299:	lea    (%rcx,%rdx,1),%rbp
  78029d:	add    $0xb0,%rbp
  7802a4:	cmpl   $0x2,0x0(%rbp)
  7802a8:	jne    780115 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3f25>
  7802ae:	mov    0x8(%rcx,%rax,1),%rdx
  7802b3:	mov    %rbx,%rdi
  7802b6:	mov    %r15,%rsi
  7802b9:	call   *0x33a581(%rip)        # aba840 <_DYNAMIC+0x800>
  7802bf:	cmpl   $0x1,0x390(%rsp)
  7802c7:	jne    780115 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3f25>
  7802cd:	movups 0x398(%rsp),%xmm0
  7802d5:	movups %xmm0,0x8(%rbp)
  7802d9:	jmp    780115 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x3f25>
  7802de:	mov    0x40(%rsp),%r13
  7802e3:	mov    0x670(%r13),%r8
  7802ea:	mov    0x680(%r13),%rax
  7802f1:	test   %r8,%r8
  7802f4:	setne  %cl
  7802f7:	test   %rax,%rax
  7802fa:	setne  %dl
  7802fd:	test   %dl,%cl
  7802ff:	mov    0xf0(%rsp),%rbx
  780307:	je     78052d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x433d>
  78030d:	mov    0x678(%r13),%rsi
  780314:	xor    %ecx,%ecx
  780316:	jmp    780340 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4150>
  780318:	mov    $0x1,%r8b
  78031b:	mov    0xf0(%rsp),%rbx
  780323:	dec    %rax
  780326:	shl    $0x5,%rdi
  78032a:	add    %rdi,%rdx
  78032d:	mov    %r8b,0x1c(%rdx)
  780331:	mov    $0x0,%r8d
  780337:	test   %rax,%rax
  78033a:	je     78052d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x433d>
  780340:	test   %rcx,%rcx
  780343:	jne    7803c8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x41d8>
  780349:	test   %rsi,%rsi
  78034c:	je     780377 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4187>
  78034e:	mov    %rsi,%rdx
  780351:	mov    %r8,%rcx
  780354:	and    $0x7,%rdx
  780358:	je     78037c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x418c>
  78035a:	xor    %edi,%edi
  78035c:	nopl   0x0(%rax)
  780360:	mov    0x1c8(%rcx),%rcx
  780367:	inc    %rdi
  78036a:	cmp    %rdi,%rdx
  78036d:	jne    780360 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4170>
  78036f:	mov    %rsi,%rdx
  780372:	sub    %rdi,%rdx
  780375:	jmp    78037f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x418f>
  780377:	mov    %r8,%rcx
  78037a:	jmp    7803c3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x41d3>
  78037c:	mov    %rsi,%rdx
  78037f:	cmp    $0x8,%rsi
  780383:	jb     7803c3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x41d3>
  780385:	mov    0x1c8(%rcx),%rcx
  78038c:	mov    0x1c8(%rcx),%rcx
  780393:	mov    0x1c8(%rcx),%rcx
  78039a:	mov    0x1c8(%rcx),%rcx
  7803a1:	mov    0x1c8(%rcx),%rcx
  7803a8:	mov    0x1c8(%rcx),%rcx
  7803af:	mov    0x1c8(%rcx),%rcx
  7803b6:	mov    0x1c8(%rcx),%rcx
  7803bd:	add    $0xfffffffffffffff8,%rdx
  7803c1:	jne    780385 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4195>
  7803c3:	xor    %esi,%esi
  7803c5:	xor    %r8d,%r8d
  7803c8:	movzwl 0x1c2(%rcx),%edx
  7803cf:	cmp    %rdx,%rsi
  7803d2:	jae    7803e0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x41f0>
  7803d4:	mov    %rsi,%rdi
  7803d7:	mov    %rcx,%rdx
  7803da:	jmp    780406 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4216>
  7803dc:	nopl   0x0(%rax)
  7803e0:	mov    0x160(%rcx),%rdx
  7803e7:	test   %rdx,%rdx
  7803ea:	je     781187 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4f97>
  7803f0:	inc    %r8
  7803f3:	movzwl 0x1c0(%rcx),%edi
  7803fa:	mov    %rdx,%rcx
  7803fd:	cmp    0x1c2(%rdx),%di
  780404:	jae    7803e0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x41f0>
  780406:	test   %r8,%r8
  780409:	je     78044a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x425a>
  78040b:	lea    (%rdx,%rdi,8),%rsi
  78040f:	add    $0x1d0,%rsi
  780416:	mov    %r8,%r9
  780419:	and    $0x7,%r9
  78041d:	je     780453 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4263>
  78041f:	xor    %r10d,%r10d
  780422:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  780430:	mov    (%rsi),%rcx
  780433:	lea    0x1c8(%rcx),%rsi
  78043a:	inc    %r10
  78043d:	cmp    %r10,%r9
  780440:	jne    780430 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4240>
  780442:	mov    %r8,%r9
  780445:	sub    %r10,%r9
  780448:	jmp    780456 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4266>
  78044a:	lea    0x1(%rdi),%rsi
  78044e:	mov    %rdx,%rcx
  780451:	jmp    7804a3 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x42b3>
  780453:	mov    %r8,%r9
  780456:	cmp    $0x8,%r8
  78045a:	jb     7804a1 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x42b1>
  78045c:	nopl   0x0(%rax)
  780460:	mov    (%rsi),%rcx
  780463:	mov    0x1c8(%rcx),%rcx
  78046a:	mov    0x1c8(%rcx),%rcx
  780471:	mov    0x1c8(%rcx),%rcx
  780478:	mov    0x1c8(%rcx),%rcx
  78047f:	mov    0x1c8(%rcx),%rcx
  780486:	mov    0x1c8(%rcx),%rcx
  78048d:	mov    0x1c8(%rcx),%rcx
  780494:	lea    0x1c8(%rcx),%rsi
  78049b:	add    $0xfffffffffffffff8,%r9
  78049f:	jne    780460 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4270>
  7804a1:	xor    %esi,%esi
  7804a3:	mov    0x6a8(%rsp),%r8
  7804ab:	test   %r8,%r8
  7804ae:	je     780525 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4335>
  7804b0:	mov    0x168(%rdx,%rdi,8),%r9
  7804b8:	mov    0x6b0(%rsp),%r10
  7804c0:	movzwl 0x62(%r8),%ebx
  7804c5:	mov    %ebx,%r14d
  7804c8:	shl    $0x3,%r14d
  7804cc:	mov    $0xffffffffffffffff,%r11
  7804d3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  7804e0:	test   %r14,%r14
  7804e3:	je     78050d <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x431d>
  7804e5:	cmp    0x10(%r8,%r11,8),%r9
  7804ea:	seta   %bpl
  7804ee:	sbb    $0x0,%bpl
  7804f2:	inc    %r11
  7804f5:	add    $0xfffffffffffffff8,%r14
  7804f9:	cmp    $0x1,%bpl
  7804fd:	je     7804e0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x42f0>
  7804ff:	movzbl %bpl,%ebx
  780503:	test   %ebx,%ebx
  780505:	je     780318 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4128>
  78050b:	jmp    780510 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4320>
  78050d:	mov    %rbx,%r11
  780510:	mov    0xf0(%rsp),%rbx
  780518:	sub    $0x1,%r10
  78051c:	jb     780525 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4335>
  78051e:	mov    0x68(%r8,%r11,8),%r8
  780523:	jmp    7804c0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x42d0>
  780525:	xor    %r8d,%r8d
  780528:	jmp    780323 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4133>
  78052d:	cmpl   $0x2,0xca0(%rsp)
  780535:	mov    $0x1,%bpl
  780538:	je     780575 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4385>
  78053a:	lea    0x390(%rsp),%rdi
  780542:	lea    0xca0(%rsp),%rsi
  78054a:	mov    $0x1e8,%edx
  78054f:	call   *0x339d4b(%rip)        # aba2a0 <memcpy@GLIBC_2.14>
  780555:	mov    %r13,%rdi
  780558:	call   74d320 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas6canvas6CanvasECs9C2G9YFESsD_29canonical_text_public_control>
  78055d:	lea    0x390(%rsp),%rsi
  780565:	mov    $0x1e8,%edx
  78056a:	mov    %r13,%rdi
  78056d:	call   *0x339d2d(%rip)        # aba2a0 <memcpy@GLIBC_2.14>
  780573:	xor    %ebp,%ebp
  780575:	mov    $0x1,%al
  780577:	mov    %eax,0x58(%rsp)
  78057b:	cmpl   $0xffffffff,0x810(%rsp)
  780583:	mov    $0x1,%al
  780585:	mov    %eax,0x30(%rsp)
  780589:	je     780728 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4538>
  78058f:	movups 0x860(%rsp),%xmm0
  780597:	movaps %xmm0,0x760(%rsp)
  78059f:	movups 0x850(%rsp),%xmm0
  7805a7:	movaps %xmm0,0x750(%rsp)
  7805af:	movups 0x810(%rsp),%xmm0
  7805b7:	movups 0x820(%rsp),%xmm1
  7805bf:	movups 0x830(%rsp),%xmm2
  7805c7:	movupd 0x840(%rsp),%xmm3
  7805d0:	movapd %xmm3,0x740(%rsp)
  7805d9:	movaps %xmm2,0x730(%rsp)
  7805e1:	movaps %xmm1,0x720(%rsp)
  7805e9:	movaps %xmm0,0x710(%rsp)
  7805f1:	cmpq   $0x0,(%rbx)
  7805f5:	je     7806f9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4509>
  7805fb:	mov    0x60(%rsp),%rax
  780600:	mov    %rax,0x390(%rsp)
  780608:	lea    0x100(%rsp),%rax
  780610:	mov    %rax,0x398(%rsp)
  780618:	lea    0x140(%rsp),%rax
  780620:	mov    %rax,0x3a0(%rsp)
  780628:	lea    0x310(%rsp),%rdi
  780630:	lea    0x6c0(%rsp),%rsi
  780638:	lea    0x390(%rsp),%rdx
  780640:	call   73fd50 <_RINvMs3_NtNtCslbxve4rcJus_4gpui7runtime6scrollNtB6_13ViewportBuild6freezeNCNvMsu_B8_INtB8_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersG_0EB1A_>
  780645:	lea    0x710(%rsp),%rdi
  78064d:	call   74e8b0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime6scroll14ViewportColumnECs9C2G9YFESsD_29canonical_text_public_control>
  780652:	mov    0x320(%rsp),%rax
  78065a:	mov    %rax,0x720(%rsp)
  780662:	movups 0x310(%rsp),%xmm0
  78066a:	movaps %xmm0,0x710(%rsp)
  780672:	mov    (%rbx),%rdi
  780675:	cmpl   $0xffffffff,0x60(%rdi)
  780679:	je     780687 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4497>
  78067b:	add    $0x60,%rdi
  78067f:	call   74eca0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime8metadata5SheetECs9C2G9YFESsD_29canonical_text_public_control>
  780684:	mov    (%rbx),%rdi
  780687:	movaps 0x760(%rsp),%xmm0
  78068f:	movups %xmm0,0xb0(%rdi)
  780696:	movaps 0x750(%rsp),%xmm0
  78069e:	movups %xmm0,0xa0(%rdi)
  7806a5:	movaps 0x710(%rsp),%xmm0
  7806ad:	mov    0x720(%rsp),%rax
  7806b5:	mov    0x728(%rsp),%rcx
  7806bd:	movaps 0x730(%rsp),%xmm1
  7806c5:	movaps 0x740(%rsp),%xmm2
  7806cd:	movups %xmm2,0x90(%rdi)
  7806d4:	movups %xmm1,0x80(%rdi)
  7806db:	mov    %rax,0x70(%rdi)
  7806df:	mov    %rcx,0x78(%rdi)
  7806e3:	movups %xmm0,0x60(%rdi)
  7806e7:	movl   $0x0,0x58(%rsp)
  7806ef:	movl   $0x0,0x30(%rsp)
  7806f7:	jmp    780728 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4538>
  7806f9:	mov    $0x1,%al
  7806fb:	mov    %eax,0x58(%rsp)
  7806ff:	movl   $0x0,0x30(%rsp)
  780707:	lea    0x710(%rsp),%rdi
  78070f:	mov    $0x1,%r12b
  780712:	mov    $0x1,%al
  780714:	mov    %eax,0x38(%rsp)
  780718:	mov    $0x1,%r15b
  78071b:	movb   $0x1,0xc0(%rsp)
  780723:	call   74eca0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime8metadata5SheetECs9C2G9YFESsD_29canonical_text_public_control>
  780728:	mov    0x180(%rsp),%r15
  780730:	cmp    $0xffffffffffffffff,%r15
  780734:	sete   0xc0(%rsp)
  78073c:	je     78079f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x45af>
  78073e:	mov    0x188(%rsp),%r13
  780746:	mov    0x190(%rsp),%r14
  78074e:	mov    %rbx,%rdi
  780751:	call   73d690 <_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionINtNtCscdodAO9FK5_5alloc5boxed3BoxNtNtNtCslbxve4rcJus_4gpui7runtime8metadata8MetadataEE18get_or_insert_withNvYBI_NtNtB5_7default7Default7defaultECs9C2G9YFESsD_29canonical_text_public_control>
  780756:	mov    %rbx,%rax
  780759:	mov    $0x100,%ebx
  78075e:	add    (%rax),%rbx
  780761:	mov    %rbx,%rdi
  780764:	call   73d4f0 <_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionINtNtCscdodAO9FK5_5alloc5boxed3BoxNtNtNtCslbxve4rcJus_4gpui7runtime8geometry8GeometryEE18get_or_insert_withNvYBI_NtNtB5_7default7Default7defaultECs9C2G9YFESsD_29canonical_text_public_control>
  780769:	mov    (%rbx),%rdi
  78076c:	mov    %r15,0x390(%rsp)
  780774:	mov    %r13,0x398(%rsp)
  78077c:	mov    %r14,0x3a0(%rsp)
  780784:	lea    0x390(%rsp),%rsi
  78078c:	call   *0x33a14e(%rip)        # aba8e0 <_DYNAMIC+0x8a0>
  780792:	mov    0x40(%rsp),%r13
  780797:	mov    0xf0(%rsp),%rbx
  78079f:	cmpq   $0xffffffffffffffff,0x258(%rsp)
  7807a8:	je     7807d9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x45e9>
  7807aa:	mov    0x2d8(%rsp),%rax
  7807b2:	mov    (%rax),%rdi
  7807b5:	test   %rdi,%rdi
  7807b8:	je     781157 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4f67>
  7807be:	lea    0x8b8(%rsp),%rdx
  7807c6:	mov    0x260(%rsp),%rsi
  7807ce:	call   *0x33a114(%rip)        # aba8e8 <_DYNAMIC+0x8a8>
  7807d4:	xor    %r14d,%r14d
  7807d7:	jmp    7807dc <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x45ec>
  7807d9:	mov    $0x1,%r14b
  7807dc:	mov    0xa8(%rsp),%rax
  7807e4:	cmpl   $0x3,(%rax)
  7807e7:	jne    7807f8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4608>
  7807e9:	mov    0x208(%r13),%rax
  7807f0:	movq   $0x0,0x58(%rax)
  7807f8:	mov    (%rbx),%rax
  7807fb:	test   %rax,%rax
  7807fe:	je     780847 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4657>
  780800:	mov    0xe0(%rax),%rax
  780807:	test   %rax,%rax
  78080a:	je     780847 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4657>
  78080c:	mov    0x678(%rsp),%rcx
  780814:	mov    %rcx,0x40(%rax)
  780818:	mov    0x2e8(%rsp),%rcx
  780820:	mov    %rcx,0x48(%rax)
  780824:	mov    0x2f0(%rsp),%ecx
  78082b:	mov    %ecx,0x50(%rax)
  78082e:	movzbl 0x57(%rsp),%ecx
  780833:	mov    %cl,0x54(%rax)
  780836:	movzwl 0x7a(%rsp),%ecx
  78083b:	mov    %cx,0x55(%rax)
  78083f:	movzbl 0x7c(%rsp),%ecx
  780844:	mov    %cl,0x57(%rax)
  780847:	mov    0x6e8(%r13),%rdi
  78084e:	test   %rdi,%rdi
  780851:	mov    %r14d,0x38(%rsp)
  780856:	je     78088c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x469c>
  780858:	cmpq   $0xffffffffffffffff,0x18(%rdi)
  78085d:	je     78086f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x467f>
  78085f:	add    $0x18,%rdi
  780863:	call   747950 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime13text_geometry5EntryEECs9C2G9YFESsD_29canonical_text_public_control>
  780868:	mov    0x6e8(%r13),%rdi
  78086f:	mov    0x210(%rsp),%rax
  780877:	mov    %rax,0x28(%rdi)
  78087b:	movups 0x200(%rsp),%xmm0
  780883:	movups %xmm0,0x18(%rdi)
  780887:	xor    %r12d,%r12d
  78088a:	jmp    78088f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x469f>
  78088c:	mov    $0x1,%r12b
  78088f:	mov    0x150(%rsp),%rax
  780897:	mov    %rax,0x3a0(%rsp)
  78089f:	movups 0x140(%rsp),%xmm0
  7808a7:	movaps %xmm0,0x390(%rsp)
  7808af:	lea    0x5c8(%r13),%r15
  7808b6:	cmpq   $0xffffffffffffffff,0x5c8(%r13)
  7808be:	je     7808c8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x46d8>
  7808c0:	mov    %r15,%rdi
  7808c3:	call   7474f0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCslbxve4rcJus_4gpui7runtime9PresentedEECs9C2G9YFESsD_29canonical_text_public_control>
  7808c8:	mov    0x3a0(%rsp),%rax
  7808d0:	mov    %rax,0x10(%r15)
  7808d4:	movaps 0x390(%rsp),%xmm0
  7808dc:	movups %xmm0,(%r15)
  7808e0:	mov    0x80(%rsp),%rax
  7808e8:	mov    %rax,0x5e0(%r13)
  7808ef:	mov    0xf8(%rsp),%rax
  7808f7:	mov    %ax,0x5e8(%r13)
  7808ff:	mov    0x2e0(%rsp),%rax
  780907:	mov    %ax,0x5ea(%r13)
  78090f:	movss  0x9c(%rsp),%xmm0
  780918:	movss  %xmm0,0x5ec(%r13)
  780921:	xor    %r15d,%r15d
  780924:	mov    %r13,%rdi
  780927:	call   76f620 <_RNvMs2_NtNtCslbxve4rcJus_4gpui7runtime5inputINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11prune_focusBW_>
  78092c:	mov    0x680(%rsp),%rax
  780934:	mov    %rax,0x6d0(%r13)
  78093b:	mov    0x260(%rsp),%rax
  780943:	mov    %rax,0x6d8(%r13)
  78094a:	mov    0x6a0(%r13),%rax
  780951:	mov    0x6e8(%r13),%rdi
  780958:	mov    %rax,0x6e0(%r13)
  78095f:	mov    0x8b0(%rsp),%rax
  780967:	mov    %rax,0x5f8(%r13)
  78096e:	cmpq   $0x0,0x2f8(%r13)
  780976:	setne  %al
  780979:	test   %rdi,%rdi
  78097c:	sete   %cl
  78097f:	or     %al,%cl
  780981:	cmp    $0x1,%cl
  780984:	je     78099e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x47ae>
  780986:	add    $0x30,%rdi
  78098a:	call   746000 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtCsghYClfd3M9V_11gpui_canvas4text10TextSystemEECs9C2G9YFESsD_29canonical_text_public_control>
  78098f:	mov    0x6e8(%r13),%rax
  780996:	movq   $0x0,0x30(%rax)
  78099e:	movb   $0x0,0x76b(%r13)
  7809a6:	movw   $0x0,0x768(%r13)
  7809b0:	lea    0x688(%r13),%rdi
  7809b7:	xor    %r15d,%r15d
  7809ba:	call   776730 <_RNvMsh_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapyNtNtB7_7set_val9SetValZSTE5clearCs9C2G9YFESsD_29canonical_text_public_control>
  7809bf:	cmpb   $0x0,0x76d(%r13)
  7809c7:	je     7809fe <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x480e>
  7809c9:	xor    %r15d,%r15d
  7809cc:	lea    0x390(%rsp),%rdi
  7809d4:	mov    %r13,%rsi
  7809d7:	mov    0x680(%rsp),%rdx
  7809df:	mov    0x260(%rsp),%rcx
  7809e7:	call   77bbc0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE11acknowledgeBO_>
  7809ec:	mov    0x390(%rsp),%rax
  7809f4:	cmp    $0xfffffffffffffffe,%rax
  7809f8:	jne    780b36 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4946>
  7809fe:	mov    0x48(%rsp),%rax
  780a03:	movq   $0xfffffffffffffffe,(%rax)
  780a0a:	cmpb   $0x0,0x58(%rsp)
  780a0f:	je     780a1e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x482e>
  780a11:	lea    0x6c0(%rsp),%rdi
  780a19:	call   74e860 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime6scroll13ViewportBuildECs9C2G9YFESsD_29canonical_text_public_control>
  780a1e:	xor    %r13d,%r13d
  780a21:	lea    0x6a8(%rsp),%rdi
  780a29:	call   74af00 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtCscdodAO9FK5_5alloc11collections5btree3set8BTreeSetNtNtCslbxve4rcJus_4gpui4list6ListIdEECs9C2G9YFESsD_29canonical_text_public_control>
  780a2e:	mov    0x100(%rsp),%rsi
  780a36:	test   %rsi,%rsi
  780a39:	je     780a52 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4862>
  780a3b:	mov    0x108(%rsp),%rdi
  780a43:	shl    $0x2,%rsi
  780a47:	mov    $0x4,%edx
  780a4c:	call   *0x33982e(%rip)        # aba280 <_DYNAMIC+0x240>
  780a52:	mov    0x158(%rsp),%rsi
  780a5a:	test   %rsi,%rsi
  780a5d:	je     780a72 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4882>
  780a5f:	mov    0x160(%rsp),%rdi
  780a67:	mov    $0x1,%edx
  780a6c:	call   *0x33980e(%rip)        # aba280 <_DYNAMIC+0x240>
  780a72:	mov    0x230(%rsp),%rsi
  780a7a:	test   %rsi,%rsi
  780a7d:	je     780a96 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x48a6>
  780a7f:	mov    0x238(%rsp),%rdi
  780a87:	shl    $0x4,%rsi
  780a8b:	mov    $0x4,%edx
  780a90:	call   *0x3397ea(%rip)        # aba280 <_DYNAMIC+0x240>
  780a96:	mov    0x218(%rsp),%rsi
  780a9e:	test   %rsi,%rsi
  780aa1:	je     780aba <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x48ca>
  780aa3:	mov    0x220(%rsp),%rdi
  780aab:	shl    $0x4,%rsi
  780aaf:	mov    $0x4,%edx
  780ab4:	call   *0x3397c6(%rip)        # aba280 <_DYNAMIC+0x240>
  780aba:	mov    0x1d8(%rsp),%rax
  780ac2:	test   %rax,%rax
  780ac5:	je     780ade <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x48ee>
  780ac7:	mov    0x1e0(%rsp),%rdi
  780acf:	imul   $0x38,%rax,%rsi
  780ad3:	mov    $0x8,%edx
  780ad8:	call   *0x3397a2(%rip)        # aba280 <_DYNAMIC+0x240>
  780ade:	cmpq   $0x0,0x1c0(%rsp)
  780ae7:	je     780af6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4906>
  780ae9:	mov    0x1c8(%rsp),%rdi
  780af1:	call   74cd80 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text10TextShaperECs9C2G9YFESsD_29canonical_text_public_control>
  780af6:	test   %r12b,%r12b
  780af9:	je     780b08 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4918>
  780afb:	lea    0x200(%rsp),%rdi
  780b03:	call   747950 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime13text_geometry5EntryEECs9C2G9YFESsD_29canonical_text_public_control>
  780b08:	mov    0xd0(%rsp),%rax
  780b10:	test   %rax,%rax
  780b13:	je     77da31 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1841>
  780b19:	lock decq (%rax)
  780b1d:	jne    77da31 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1841>
  780b23:	lea    0xd0(%rsp),%rdi
  780b2b:	call   *0x33983f(%rip)        # aba370 <_DYNAMIC+0x330>
  780b31:	jmp    77da31 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1841>
  780b36:	mov    0x3b8(%rsp),%rcx
  780b3e:	movzbl 0x3c0(%rsp),%edx
  780b46:	mov    0x3c1(%rsp),%esi
  780b4d:	mov    %esi,0x310(%rsp)
  780b54:	mov    0x3c4(%rsp),%esi
  780b5b:	mov    %esi,0x313(%rsp)
  780b62:	movups 0x398(%rsp),%xmm0
  780b6a:	movups 0x3a8(%rsp),%xmm1
  780b72:	mov    0x310(%rsp),%esi
  780b79:	mov    0x313(%rsp),%edi
  780b80:	mov    0x48(%rsp),%r8
  780b85:	mov    %edi,0x34(%r8)
  780b89:	mov    %esi,0x31(%r8)
  780b8d:	mov    %rax,(%r8)
  780b90:	movups %xmm0,0x8(%r8)
  780b95:	movups %xmm1,0x18(%r8)
  780b9a:	mov    %rcx,0x28(%r8)
  780b9e:	mov    %dl,0x30(%r8)
  780ba2:	xor    %r13d,%r13d
  780ba5:	cmpb   $0x0,0x58(%rsp)
  780baa:	mov    0x30(%rsp),%ebx
  780bae:	mov    0x38(%rsp),%r14d
  780bb3:	jne    780e65 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c75>
  780bb9:	jmp    780e72 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c82>
  780bbe:	movzbl 0x391(%rsp),%eax
  780bc6:	mov    0x48(%rsp),%rcx
  780bcb:	movq   $0x22,(%rcx)
  780bd2:	mov    %al,0x8(%rcx)
  780bd5:	jmp    780e4a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c5a>
  780bda:	mov    0x48(%rsp),%rax
  780bdf:	movq   $0x1f,(%rax)
  780be6:	jmp    77da31 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1841>
  780beb:	lea    0x394(%rsp),%rcx
  780bf3:	mov    0x14(%rcx),%rax
  780bf7:	movups 0x4(%rcx),%xmm0
  780bfb:	movaps %xmm0,0x120(%rsp)
  780c03:	mov    %rax,0x130(%rsp)
  780c0b:	mov    0x48(%rsp),%rcx
  780c10:	mov    %rax,0x18(%rcx)
  780c14:	movups %xmm0,0x8(%rcx)
  780c18:	movq   $0x23,(%rcx)
  780c1f:	jmp    780e4a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c5a>
  780c24:	mov    0x48(%rsp),%rcx
  780c29:	movq   $0x23,(%rcx)
  780c30:	mov    %eax,0x8(%rcx)
  780c33:	mov    %edx,0xc(%rcx)
  780c36:	jmp    780e4a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c5a>
  780c3b:	mov    0x3c0(%rsp),%rcx
  780c43:	mov    0x48(%rsp),%rdx
  780c48:	mov    %rcx,0x30(%rdx)
  780c4c:	movups 0x3a0(%rsp),%xmm0
  780c54:	movups 0x3b0(%rsp),%xmm1
  780c5c:	movups %xmm1,0x20(%rdx)
  780c60:	movups %xmm0,0x10(%rdx)
  780c64:	mov    %rax,(%rdx)
  780c67:	mov    %r15,0x8(%rdx)
  780c6b:	jmp    780e4a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c5a>
  780c70:	mov    0x3c0(%rsp),%rax
  780c78:	mov    0x48(%rsp),%rcx
  780c7d:	mov    %rax,0x30(%rcx)
  780c81:	movups 0x390(%rsp),%xmm0
  780c89:	movups 0x3a0(%rsp),%xmm1
  780c91:	movups 0x3b0(%rsp),%xmm2
  780c99:	movups %xmm2,0x20(%rcx)
  780c9d:	movups %xmm1,0x10(%rcx)
  780ca1:	movups %xmm0,(%rcx)
  780ca4:	jmp    780e4a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c5a>
  780ca9:	mov    0x30(%rsp),%rax
  780cae:	mov    0x20(%rax,%r13,1),%esi
  780cb3:	lea    0x390(%rsp),%rdi
  780cbb:	lea    0x8d0(%rsp),%rdx
  780cc3:	call   75e410 <_RNCNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB7_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innersn_0BQ_>
  780cc8:	mov    0x3c0(%rsp),%rax
  780cd0:	mov    %rax,0x900(%rsp)
  780cd8:	movups 0x390(%rsp),%xmm0
  780ce0:	movups 0x3a0(%rsp),%xmm1
  780ce8:	movups 0x3b0(%rsp),%xmm2
  780cf0:	movaps %xmm2,0x8f0(%rsp)
  780cf8:	movaps %xmm1,0x8e0(%rsp)
  780d00:	movaps %xmm0,0x8d0(%rsp)
  780d08:	mov    0x8d0(%rsp),%rax
  780d10:	mov    0x8f8(%rsp),%rcx
  780d18:	mov    0x48(%rsp),%rdx
  780d1d:	mov    %rcx,0x28(%rdx)
  780d21:	mov    0x900(%rsp),%rcx
  780d29:	mov    %rcx,0x30(%rdx)
  780d2d:	lea    0x8d8(%rsp),%rcx
  780d35:	movups (%rcx),%xmm0
  780d38:	movups 0x10(%rcx),%xmm1
  780d3c:	movups %xmm0,0x8(%rdx)
  780d40:	movups %xmm1,0x18(%rdx)
  780d44:	mov    %rax,(%rdx)
  780d47:	jmp    780e4a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c5a>
  780d4c:	mov    0x48(%rsp),%rcx
  780d51:	movq   $0x23,(%rcx)
  780d58:	mov    %eax,0x8(%rcx)
  780d5b:	mov    %edx,0xc(%rcx)
  780d5e:	jmp    780e2e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c3e>
  780d63:	lea    0x394(%rsp),%rcx
  780d6b:	mov    0x14(%rcx),%rax
  780d6f:	movups 0x4(%rcx),%xmm0
  780d73:	movaps %xmm0,0x120(%rsp)
  780d7b:	mov    %rax,0x130(%rsp)
  780d83:	mov    0x48(%rsp),%rcx
  780d88:	mov    %rax,0x18(%rcx)
  780d8c:	movups %xmm0,0x8(%rcx)
  780d90:	movq   $0x23,(%rcx)
  780d97:	jmp    780e2e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c3e>
  780d9c:	lea    0x394(%rsp),%rcx
  780da4:	mov    0x14(%rcx),%rax
  780da8:	movups 0x4(%rcx),%xmm0
  780dac:	movaps %xmm0,0x120(%rsp)
  780db4:	mov    %rax,0x130(%rsp)
  780dbc:	mov    0x48(%rsp),%rcx
  780dc1:	mov    %rax,0x18(%rcx)
  780dc5:	movups %xmm0,0x8(%rcx)
  780dc9:	movq   $0x23,(%rcx)
  780dd0:	jmp    780de4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4bf4>
  780dd2:	mov    0x48(%rsp),%rcx
  780dd7:	movq   $0x23,(%rcx)
  780dde:	mov    %eax,0x8(%rcx)
  780de1:	mov    %edx,0xc(%rcx)
  780de4:	mov    0x1f8(%rsp),%rax
  780dec:	test   %rax,%rax
  780def:	je     780e4a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c5a>
  780df1:	lock decq (%rax)
  780df5:	jne    780e4a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c5a>
  780df7:	lea    0x1f8(%rsp),%rdi
  780dff:	call   *0x33959b(%rip)        # aba3a0 <_DYNAMIC+0x360>
  780e05:	jmp    780e4a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c5a>
  780e07:	mov    0x48(%rsp),%rax
  780e0c:	movq   $0x18,(%rax)
  780e13:	jmp    780e2e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c3e>
  780e15:	mov    0x124(%rsp),%ecx
  780e1c:	mov    0x48(%rsp),%rdx
  780e21:	movq   $0x23,(%rdx)
  780e28:	mov    %eax,0x8(%rdx)
  780e2b:	mov    %ecx,0xc(%rdx)
  780e2e:	mov    0x300(%rsp),%rax
  780e36:	lock decq (%rax)
  780e3a:	jne    780e4a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4c5a>
  780e3c:	lea    0x300(%rsp),%rdi
  780e44:	call   *0x339556(%rip)        # aba3a0 <_DYNAMIC+0x360>
  780e4a:	lea    0x970(%rsp),%rdi
  780e52:	call   74d320 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas6canvas6CanvasECs9C2G9YFESsD_29canonical_text_public_control>
  780e57:	mov    $0x1,%r12b
  780e5a:	mov    $0x1,%r14b
  780e5d:	mov    $0x1,%bl
  780e5f:	mov    $0x1,%r13b
  780e62:	mov    $0x1,%bpl
  780e65:	lea    0x6c0(%rsp),%rdi
  780e6d:	call   74e860 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime6scroll13ViewportBuildECs9C2G9YFESsD_29canonical_text_public_control>
  780e72:	cmpq   $0xffffffffffffffff,0x258(%rsp)
  780e7b:	setne  %al
  780e7e:	mov    %r13d,%r15d
  780e81:	test   %r14b,%al
  780e84:	je     780e96 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4ca6>
  780e86:	lea    0x8b8(%rsp),%rdi
  780e8e:	call   747130 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCsghYClfd3M9V_11gpui_canvas5image5ImageEECs9C2G9YFESsD_29canonical_text_public_control>
  780e93:	mov    %r15d,%r13d
  780e96:	cmpl   $0xffffffff,0x810(%rsp)
  780e9e:	je     780eb1 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4cc1>
  780ea0:	test   %bl,%bl
  780ea2:	je     780eb1 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4cc1>
  780ea4:	lea    0x810(%rsp),%rdi
  780eac:	call   74eca0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime8metadata5SheetECs9C2G9YFESsD_29canonical_text_public_control>
  780eb1:	lea    0x6a8(%rsp),%rdi
  780eb9:	call   74af00 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtCscdodAO9FK5_5alloc11collections5btree3set8BTreeSetNtNtCslbxve4rcJus_4gpui4list6ListIdEECs9C2G9YFESsD_29canonical_text_public_control>
  780ebe:	mov    0x100(%rsp),%rsi
  780ec6:	test   %rsi,%rsi
  780ec9:	je     780ee2 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4cf2>
  780ecb:	mov    0x108(%rsp),%rdi
  780ed3:	shl    $0x2,%rsi
  780ed7:	mov    $0x4,%edx
  780edc:	call   *0x33939e(%rip)        # aba280 <_DYNAMIC+0x240>
  780ee2:	mov    0x158(%rsp),%rsi
  780eea:	test   %rsi,%rsi
  780eed:	je     780f02 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4d12>
  780eef:	mov    0x160(%rsp),%rdi
  780ef7:	mov    $0x1,%edx
  780efc:	call   *0x33937e(%rip)        # aba280 <_DYNAMIC+0x240>
  780f02:	mov    0x230(%rsp),%rsi
  780f0a:	test   %rsi,%rsi
  780f0d:	je     780f26 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4d36>
  780f0f:	mov    0x238(%rsp),%rdi
  780f17:	shl    $0x4,%rsi
  780f1b:	mov    $0x4,%edx
  780f20:	call   *0x33935a(%rip)        # aba280 <_DYNAMIC+0x240>
  780f26:	mov    0x218(%rsp),%rsi
  780f2e:	test   %rsi,%rsi
  780f31:	je     780f4a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4d5a>
  780f33:	mov    0x220(%rsp),%rdi
  780f3b:	shl    $0x4,%rsi
  780f3f:	mov    $0x4,%edx
  780f44:	call   *0x339336(%rip)        # aba280 <_DYNAMIC+0x240>
  780f4a:	mov    0x1d8(%rsp),%rax
  780f52:	test   %rax,%rax
  780f55:	je     780f6e <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4d7e>
  780f57:	mov    0x1e0(%rsp),%rdi
  780f5f:	imul   $0x38,%rax,%rsi
  780f63:	mov    $0x8,%edx
  780f68:	call   *0x339312(%rip)        # aba280 <_DYNAMIC+0x240>
  780f6e:	test   %r13b,%r13b
  780f71:	je     780fa4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4db4>
  780f73:	mov    0x268(%rsp),%rsi
  780f7b:	test   %rsi,%rsi
  780f7e:	je     780f97 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4da7>
  780f80:	mov    0x270(%rsp),%rdi
  780f88:	shl    $0x4,%rsi
  780f8c:	mov    $0x4,%edx
  780f91:	call   *0x3392e9(%rip)        # aba280 <_DYNAMIC+0x240>
  780f97:	lea    0x140(%rsp),%rdi
  780f9f:	call   7474f0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCslbxve4rcJus_4gpui7runtime9PresentedEECs9C2G9YFESsD_29canonical_text_public_control>
  780fa4:	mov    0x7c8(%rsp),%rax
  780fac:	cmp    $0xfffffffffffffffe,%rax
  780fb0:	jne    77d601 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x1411>
  780fb6:	jmp    77d9ca <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x17da>
  780fbb:	lea    -0x6ae632(%rip),%rdi        # d2990 <GCC_except_table0+0x10588>
  780fc2:	lea    0x31a5f7(%rip),%rdx        # a9b5c0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1ad8>
  780fc9:	mov    $0x83,%esi
  780fce:	call   *0x3392e4(%rip)        # aba2b8 <_DYNAMIC+0x278>
  780fd4:	jmp    781378 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  780fd9:	lea    -0x6ae8d0(%rip),%rdi        # d2710 <GCC_except_table0+0x10308>
  780fe0:	lea    0x31a109(%rip),%rdx        # a9b0f0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1608>
  780fe7:	mov    $0x1c,%esi
  780fec:	call   *0x339366(%rip)        # aba358 <_DYNAMIC+0x318>
  780ff2:	jmp    781378 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  780ff7:	mov    $0x1,%bpl
  780ffa:	mov    $0x8,%edi
  780fff:	mov    $0x78,%esi
  781004:	call   *0x33928e(%rip)        # aba298 <_DYNAMIC+0x258>
  78100a:	jmp    781378 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  78100f:	lea    0x31933a(%rip),%rdi        # a9a350 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x868>
  781016:	call   *0x339324(%rip)        # aba340 <_DYNAMIC+0x300>
  78101c:	jmp    781378 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  781021:	lea    -0x6ae657(%rip),%rax        # d29d1 <GCC_except_table0+0x105c9>
  781028:	mov    %rax,0x250(%rsp)
  781030:	lea    0x31a741(%rip),%rax        # a9b778 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1c90>
  781037:	jmp    781083 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4e93>
  781039:	lea    0x319460(%rip),%rax        # a9a4a0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x9b8>
  781040:	mov    %rax,0x658(%rsp)
  781048:	mov    0x658(%rsp),%rdi
  781050:	call   *0x3392ea(%rip)        # aba340 <_DYNAMIC+0x300>
  781056:	jmp    781378 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  78105b:	lea    0x3192ee(%rip),%rdi        # a9a350 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x868>
  781062:	call   *0x3392d8(%rip)        # aba340 <_DYNAMIC+0x300>
  781068:	jmp    781378 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  78106d:	lea    -0x6ae6a3(%rip),%rax        # d29d1 <GCC_except_table0+0x105c9>
  781074:	mov    %rax,0x250(%rsp)
  78107c:	lea    0x31a70d(%rip),%rax        # a9b790 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1ca8>
  781083:	mov    %rax,0x248(%rsp)
  78108b:	jmp    781107 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x4f17>
  78108d:	mov    0x3a0(%rsp),%rsi
  781095:	mov    $0x1,%bpl
  781098:	call   *0x339292(%rip)        # aba330 <_DYNAMIC+0x2f0>
  78109e:	jmp    781378 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  7810a3:	mov    0x3a0(%rsp),%rsi
  7810ab:	call   *0x33927f(%rip)        # aba330 <_DYNAMIC+0x2f0>
  7810b1:	jmp    781378 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  7810b6:	mov    0x3a0(%rsp),%rsi
  7810be:	call   *0x33926c(%rip)        # aba330 <_DYNAMIC+0x2f0>
  7810c4:	jmp    781378 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  7810c9:	mov    0x3a0(%rsp),%rsi
  7810d1:	call   *0x339259(%rip)        # aba330 <_DYNAMIC+0x2f0>
  7810d7:	jmp    781378 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  7810dc:	mov    0x3a0(%rsp),%rsi
  7810e4:	call   *0x339246(%rip)        # aba330 <_DYNAMIC+0x2f0>
  7810ea:	jmp    781378 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  7810ef:	mov    0x3a0(%rsp),%rsi
  7810f7:	call   *0x339233(%rip)        # aba330 <_DYNAMIC+0x2f0>
  7810fd:	jmp    781378 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  781102:	mov    $0x1f,%esi
  781107:	mov    0x250(%rsp),%rdi
  78110f:	mov    0x248(%rsp),%rdx
  781117:	call   *0x33923b(%rip)        # aba358 <_DYNAMIC+0x318>
  78111d:	jmp    781378 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  781122:	lea    -0x6ae799(%rip),%rdi        # d2990 <GCC_except_table0+0x10588>
  781129:	lea    0x31a490(%rip),%rdx        # a9b5c0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1ad8>
  781130:	mov    $0x83,%esi
  781135:	call   *0x33917d(%rip)        # aba2b8 <_DYNAMIC+0x278>
  78113b:	jmp    781378 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  781140:	movb   $0x1,0x60(%rsp)
  781145:	lea    0x31a674(%rip),%rdi        # a9b7c0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1cd8>
  78114c:	call   *0x3391ee(%rip)        # aba340 <_DYNAMIC+0x300>
  781152:	jmp    781378 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  781157:	lea    0x31a58a(%rip),%rdi        # a9b6e8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1c00>
  78115e:	call   *0x3391dc(%rip)        # aba340 <_DYNAMIC+0x300>
  781164:	jmp    781378 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  781169:	lea    0x319228(%rip),%rax        # a9a398 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x8b0>
  781170:	jmp    7811ff <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x500f>
  781175:	lea    0x3191ec(%rip),%rdi        # a9a368 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x880>
  78117c:	call   *0x3391be(%rip)        # aba340 <_DYNAMIC+0x300>
  781182:	jmp    781378 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  781187:	lea    0x3191da(%rip),%rdi        # a9a368 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x880>
  78118e:	call   *0x3391ac(%rip)        # aba340 <_DYNAMIC+0x300>
  781194:	jmp    781378 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  781199:	lea    0x31a4c0(%rip),%rax        # a9b660 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1b78>
  7811a0:	jmp    7811ff <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x500f>
  7811a2:	lea    0x31a4cf(%rip),%rax        # a9b678 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1b90>
  7811a9:	jmp    7811ff <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x500f>
  7811ab:	lea    0x319d3e(%rip),%rax        # a9aef0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1408>
  7811b2:	jmp    7811ff <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x500f>
  7811b4:	lea    0x319d1d(%rip),%rax        # a9aed8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x13f0>
  7811bb:	jmp    7811ff <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x500f>
  7811bd:	mov    %rbp,%r12
  7811c0:	lea    0x319d29(%rip),%rax        # a9aef0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1408>
  7811c7:	jmp    7811ff <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x500f>
  7811c9:	mov    %rax,%r12
  7811cc:	jmp    7811f8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5008>
  7811ce:	mov    %rbp,%r12
  7811d1:	lea    0x319d00(%rip),%rax        # a9aed8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x13f0>
  7811d8:	jmp    7811ff <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x500f>
  7811da:	mov    %rax,%r13
  7811dd:	lea    0x319cf4(%rip),%rax        # a9aed8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x13f0>
  7811e4:	jmp    7811ff <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x500f>
  7811e6:	mov    %rax,%r13
  7811e9:	lea    0x319d00(%rip),%rax        # a9aef0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1408>
  7811f0:	jmp    7811ff <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x500f>
  7811f2:	mov    %rcx,%r12
  7811f5:	mov    %rax,%r13
  7811f8:	lea    0x319d09(%rip),%rax        # a9af08 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1420>
  7811ff:	mov    %rax,0x80(%rsp)
  781207:	mov    %r12,%rdi
  78120a:	mov    %r13,%rsi
  78120d:	mov    0x80(%rsp),%rdx
  781215:	call   *0x339095(%rip)        # aba2b0 <_DYNAMIC+0x270>
  78121b:	jmp    781378 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  781220:	mov    $0x1,%r12b
  781223:	lea    0x31a47e(%rip),%rdx        # a9b6a8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1bc0>
  78122a:	mov    $0x1,%bpl
  78122d:	xor    %edi,%edi
  78122f:	xor    %esi,%esi
  781231:	call   *0x339079(%rip)        # aba2b0 <_DYNAMIC+0x270>
  781237:	jmp    781378 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  78123c:	lea    -0x6ae8b3(%rip),%rdi        # d2990 <GCC_except_table0+0x10588>
  781243:	lea    0x31a376(%rip),%rdx        # a9b5c0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1ad8>
  78124a:	mov    $0x83,%esi
  78124f:	call   *0x339063(%rip)        # aba2b8 <_DYNAMIC+0x278>
  781255:	jmp    781378 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  78125a:	movb   $0x1,0x60(%rsp)
  78125f:	lea    -0x6ae8d6(%rip),%rdi        # d2990 <GCC_except_table0+0x10588>
  781266:	lea    0x31a353(%rip),%rdx        # a9b5c0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1ad8>
  78126d:	mov    $0x83,%esi
  781272:	call   *0x339040(%rip)        # aba2b8 <_DYNAMIC+0x278>
  781278:	jmp    781378 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  78127d:	mov    %rsi,%rax
  781280:	lea    0x31a4a9(%rip),%rcx        # a9b730 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1c48>
  781287:	jmp    781338 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5148>
  78128c:	mov    %rsi,%rax
  78128f:	lea    0x31a4b2(%rip),%rcx        # a9b748 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1c60>
  781296:	jmp    781338 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5148>
  78129b:	mov    %rsi,%rax
  78129e:	lea    0x31a4bb(%rip),%rcx        # a9b760 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1c78>
  7812a5:	jmp    781338 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5148>
  7812aa:	mov    %rbx,0x38(%rsp)
  7812af:	mov    %rsi,%rax
  7812b2:	lea    0x3191b7(%rip),%rcx        # a9a470 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x988>
  7812b9:	jmp    781338 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5148>
  7812bb:	mov    %rcx,0x38(%rsp)
  7812c0:	lea    0x3191c1(%rip),%rcx        # a9a488 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x9a0>
  7812c7:	jmp    781338 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5148>
  7812c9:	mov    %rdx,0x38(%rsp)
  7812ce:	lea    0x3191e3(%rip),%rcx        # a9a4b8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x9d0>
  7812d5:	jmp    781338 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5148>
  7812d7:	mov    %rdx,0x38(%rsp)
  7812dc:	lea    0x3191ed(%rip),%rcx        # a9a4d0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x9e8>
  7812e3:	jmp    781338 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5148>
  7812e5:	lea    0x319214(%rip),%rax        # a9a500 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xa18>
  7812ec:	mov    %rax,0x650(%rsp)
  7812f4:	movb   $0x1,0x60(%rsp)
  7812f9:	mov    %rbx,%rdi
  7812fc:	mov    0x650(%rsp),%rdx
  781304:	call   *0x338fa6(%rip)        # aba2b0 <_DYNAMIC+0x270>
  78130a:	jmp    781378 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  78130c:	lea    0x319bdd(%rip),%rcx        # a9aef0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1408>
  781313:	jmp    781338 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5148>
  781315:	mov    %rcx,0x38(%rsp)
  78131a:	lea    0x319be7(%rip),%rcx        # a9af08 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1420>
  781321:	jmp    781338 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5148>
  781323:	lea    0x319bae(%rip),%rcx        # a9aed8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x13f0>
  78132a:	jmp    781338 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5148>
  78132c:	mov    %rcx,0x38(%rsp)
  781331:	lea    0x3191b0(%rip),%rcx        # a9a4e8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0xa00>
  781338:	mov    %rcx,0xa0(%rsp)
  781340:	mov    0x38(%rsp),%rdi
  781345:	mov    %rax,%rsi
  781348:	mov    0xa0(%rsp),%rdx
  781350:	call   *0x338f5a(%rip)        # aba2b0 <_DYNAMIC+0x270>
  781356:	jmp    781378 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5188>
  781358:	lea    0x31a479(%rip),%rax        # a9b7d8 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x1cf0>
  78135f:	mov    %rax,0x648(%rsp)
  781367:	mov    %rbx,%rdi
  78136a:	mov    0x648(%rsp),%rdx
  781372:	call   *0x338f38(%rip)        # aba2b0 <_DYNAMIC+0x270>
  781378:	ud2
  78137a:	mov    %rbx,%rcx
  78137d:	mov    %rax,%rbx
  781380:	mov    (%rcx),%rax
  781383:	movaps 0x760(%rsp),%xmm0
  78138b:	movups %xmm0,0xb0(%rax)
  781392:	movaps 0x750(%rsp),%xmm0
  78139a:	movups %xmm0,0xa0(%rax)
  7813a1:	movaps 0x710(%rsp),%xmm0
  7813a9:	movaps 0x720(%rsp),%xmm1
  7813b1:	movaps 0x730(%rsp),%xmm2
  7813b9:	movapd 0x740(%rsp),%xmm3
  7813c2:	movupd %xmm3,0x90(%rax)
  7813ca:	movups %xmm2,0x80(%rax)
  7813d1:	movups %xmm1,0x70(%rax)
  7813d5:	movups %xmm0,0x60(%rax)
  7813d9:	jmp    78145a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x526a>
  7813db:	mov    %rax,%rbx
  7813de:	mov    0x6e8(%r13),%rax
  7813e5:	mov    0x210(%rsp),%rcx
  7813ed:	mov    %rcx,0x28(%rax)
  7813f1:	movups 0x200(%rsp),%xmm0
  7813f9:	movups %xmm0,0x18(%rax)
  7813fd:	mov    $0x1,%r15b
  781400:	xor    %r12d,%r12d
  781403:	jmp    781734 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5544>
  781408:	mov    %rax,%rbx
  78140b:	lea    0x728(%rsp),%rdi
  781413:	call   747b20 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime8metadata8TextSlotEECs9C2G9YFESsD_29canonical_text_public_control>
  781418:	lea    0x740(%rsp),%rdi
  781420:	call   747b20 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime8metadata8TextSlotEECs9C2G9YFESsD_29canonical_text_public_control>
  781425:	lea    0x710(%rsp),%rdi
  78142d:	call   74e8b0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime6scroll14ViewportColumnECs9C2G9YFESsD_29canonical_text_public_control>
  781432:	mov    0x758(%rsp),%rax
  78143a:	test   %rax,%rax
  78143d:	je     78145a <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x526a>
  78143f:	mov    0x760(%rsp),%rdi
  781447:	shl    $0x3,%rax
  78144b:	lea    (%rax,%rax,2),%rsi
  78144f:	mov    $0x8,%edx
  781454:	call   *0x338e26(%rip)        # aba280 <_DYNAMIC+0x240>
  78145a:	mov    $0x1,%r12b
  78145d:	movl   $0x0,0x58(%rsp)
  781465:	mov    $0x1,%al
  781467:	mov    %eax,0x38(%rsp)
  78146b:	movl   $0x0,0x30(%rsp)
  781473:	mov    $0x1,%r15b
  781476:	jmp    7815e9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x53f9>
  78147b:	mov    %rax,%rbx
  78147e:	mov    0x6e8(%r13),%rax
  781485:	movq   $0x0,0x30(%rax)
  78148d:	xor    %r15d,%r15d
  781490:	jmp    781734 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5544>
  781495:	mov    %rax,%rbx
  781498:	lea    0x390(%rsp),%rsi
  7814a0:	mov    $0x1e8,%edx
  7814a5:	mov    %r13,%rdi
  7814a8:	call   *0x338df2(%rip)        # aba2a0 <memcpy@GLIBC_2.14>
  7814ae:	mov    $0x1,%al
  7814b0:	mov    %eax,0x58(%rsp)
  7814b4:	xor    %ebp,%ebp
  7814b6:	mov    $0x1,%r12b
  7814b9:	mov    $0x1,%al
  7814bb:	mov    %eax,0x38(%rsp)
  7814bf:	mov    $0x1,%al
  7814c1:	mov    %eax,0x30(%rsp)
  7814c5:	mov    $0x1,%r15b
  7814c8:	jmp    7815e9 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x53f9>
  7814cd:	mov    %rax,%rbx
  7814d0:	jmp    781726 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5536>
  7814d5:	mov    %rax,%rbx
  7814d8:	mov    0x3a0(%rsp),%rax
  7814e0:	mov    %rax,0x10(%r15)
  7814e4:	movaps 0x390(%rsp),%xmm0
  7814ec:	movups %xmm0,(%r15)
  7814f0:	mov    0x80(%rsp),%rax
  7814f8:	mov    %rax,0x5e0(%r13)
  7814ff:	mov    0xf8(%rsp),%rax
  781507:	mov    %ax,0x5e8(%r13)
  78150f:	mov    0x2e0(%rsp),%rax
  781517:	mov    %ax,0x5ea(%r13)
  78151f:	movss  0x9c(%rsp),%xmm0
  781528:	movss  %xmm0,0x5ec(%r13)
  781531:	xor    %r15d,%r15d
  781534:	jmp    781734 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5544>
  781539:	mov    %rax,%rbx
  78153c:	mov    $0x1,%r12b
  78153f:	jmp    781571 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5381>
  781541:	mov    %rax,%rbx
  781544:	mov    %rbp,%rdi
  781547:	call   746060 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtCslbxve4rcJus_4gpui11shared_text10SharedTextEECs9C2G9YFESsD_29canonical_text_public_control>
  78154c:	jmp    7817a0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x55b0>
  781551:	mov    %rax,%rbx
  781554:	mov    $0x1,%r12b
  781557:	test   %r15,%r15
  78155a:	je     781571 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5381>
  78155c:	shl    $0x4,%r15
  781560:	mov    $0x4,%edx
  781565:	mov    %r13,%rdi
  781568:	mov    %r15,%rsi
  78156b:	call   *0x338d0f(%rip)        # aba280 <_DYNAMIC+0x240>
  781571:	mov    $0x1,%al
  781573:	mov    %eax,0x38(%rsp)
  781577:	mov    $0x1,%r15b
  78157a:	xor    %r13d,%r13d
  78157d:	cmpb   $0x0,0x58(%rsp)
  781582:	je     78177f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x558f>
  781588:	jmp    781874 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5684>
  78158d:	mov    %rax,%rbx
  781590:	mov    $0x1,%r12b
  781593:	mov    $0x1,%al
  781595:	mov    %eax,0x38(%rsp)
  781599:	mov    $0x1,%al
  78159b:	mov    %eax,0x30(%rsp)
  78159f:	mov    $0x1,%r13b
  7815a2:	mov    $0x1,%r15b
  7815a5:	mov    $0x1,%bpl
  7815a8:	cmpq   $0xffffffffffffffff,0x258(%rsp)
  7815b1:	jne    78188c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x569c>
  7815b7:	jmp    7818a0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x56b0>
  7815bc:	mov    %ebx,0x30(%rsp)
  7815c0:	mov    %rax,%rbx
  7815c3:	mov    %r15d,%r13d
  7815c6:	jmp    7818a0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x56b0>
  7815cb:	mov    %rax,%rbx
  7815ce:	mov    $0x1,%al
  7815d0:	mov    %eax,0x58(%rsp)
  7815d4:	mov    $0x1,%r12b
  7815d7:	mov    $0x1,%al
  7815d9:	mov    %eax,0x38(%rsp)
  7815dd:	mov    $0x1,%al
  7815df:	mov    %eax,0x30(%rsp)
  7815e3:	mov    $0x1,%r15b
  7815e6:	mov    $0x1,%bpl
  7815e9:	movb   $0x1,0xc0(%rsp)
  7815f1:	jmp    781734 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5544>
  7815f6:	mov    %rax,%rbx
  7815f9:	mov    %r13d,%r15d
  7815fc:	jmp    7818cb <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x56db>
  781601:	mov    %rax,%rbx
  781604:	jmp    781734 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5544>
  781609:	mov    %rax,%rbx
  78160c:	mov    %r13d,%r15d
  78160f:	jmp    7818be <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x56ce>
  781614:	mov    %rax,%rbx
  781617:	add    $0x38,%r15
  78161b:	mov    %r15,%rdi
  78161e:	call   74cfd0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text11RasterCacheECs9C2G9YFESsD_29canonical_text_public_control>
  781623:	jmp    781690 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x54a0>
  781625:	call   *0x338c7d(%rip)        # aba2a8 <_DYNAMIC+0x268>
  78162b:	mov    %rax,%rbx
  78162e:	mov    0x300(%rsp),%rax
  781636:	lock decq (%rax)
  78163a:	jne    78184f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x565f>
  781640:	lea    0x300(%rsp),%rdi
  781648:	call   *0x338d52(%rip)        # aba3a0 <_DYNAMIC+0x360>
  78164e:	jmp    78184f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x565f>
  781653:	mov    %rax,%rbx
  781656:	mov    %r12b,0x60(%rsp)
  78165b:	jmp    7817a0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x55b0>
  781660:	mov    %rax,%rbx
  781663:	movb   $0x1,0x60(%rsp)
  781668:	jmp    7817a0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x55b0>
  78166d:	mov    %rax,%rbx
  781670:	mov    $0x1,%bpl
  781673:	mov    $0x1,%r15b
  781676:	mov    $0x1,%r13b
  781679:	mov    $0x1,%al
  78167b:	mov    %eax,0x30(%rsp)
  78167f:	mov    $0x1,%al
  781681:	mov    %eax,0x38(%rsp)
  781685:	mov    $0x1,%r12b
  781688:	jmp    781874 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5684>
  78168d:	mov    %rax,%rbx
  781690:	mov    0x40(%rsp),%rax
  781695:	mov    0x6e8(%rax),%rax
  78169c:	mov    %r12,0x30(%rax)
  7816a0:	mov    %r14d,0x38(%rax)
  7816a4:	mov    %ebp,0x3c(%rax)
  7816a7:	movaps 0x970(%rsp),%xmm0
  7816af:	movaps 0x980(%rsp),%xmm1
  7816b7:	movaps 0x990(%rsp),%xmm2
  7816bf:	movups %xmm0,0x40(%rax)
  7816c3:	movups %xmm1,0x50(%rax)
  7816c7:	movups %xmm2,0x60(%rax)
  7816cb:	mov    0x9a0(%rsp),%rcx
  7816d3:	mov    %rcx,0x70(%rax)
  7816d7:	mov    $0x1,%bpl
  7816da:	jmp    781a23 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5833>
  7816df:	mov    %rax,%rbx
  7816e2:	jmp    781a02 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5812>
  7816e7:	mov    %rax,%rbx
  7816ea:	lea    0x390(%rsp),%rsi
  7816f2:	mov    $0x298,%edx
  7816f7:	mov    %r14,%rdi
  7816fa:	call   *0x338ba0(%rip)        # aba2a0 <memcpy@GLIBC_2.14>
  781700:	jmp    7819d2 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57e2>
  781705:	mov    %rax,%rbx
  781708:	jmp    7819f0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5800>
  78170d:	jmp    78184c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x565c>
  781712:	ud2
  781714:	ud2
  781716:	mov    %rax,%rbx
  781719:	lea    0x8b8(%rsp),%rdi
  781721:	call   747130 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCsghYClfd3M9V_11gpui_canvas5image5ImageEECs9C2G9YFESsD_29canonical_text_public_control>
  781726:	mov    $0x1,%r12b
  781729:	movl   $0x0,0x38(%rsp)
  781731:	mov    $0x1,%r15b
  781734:	mov    0x180(%rsp),%rsi
  78173c:	test   %rsi,%rsi
  78173f:	setg   %al
  781742:	test   %al,0xc0(%rsp)
  781749:	je     781771 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5581>
  78174b:	mov    0x188(%rsp),%rdi
  781753:	shl    $0x4,%rsi
  781757:	mov    $0x4,%edx
  78175c:	call   *0x338b1e(%rip)        # aba280 <_DYNAMIC+0x240>
  781762:	xor    %r13d,%r13d
  781765:	cmpb   $0x0,0x58(%rsp)
  78176a:	je     78177f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x558f>
  78176c:	jmp    781874 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5684>
  781771:	xor    %r13d,%r13d
  781774:	cmpb   $0x0,0x58(%rsp)
  781779:	jne    781874 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5684>
  78177f:	cmpq   $0xffffffffffffffff,0x258(%rsp)
  781788:	jne    78188c <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x569c>
  78178e:	jmp    7818a0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x56b0>
  781793:	jmp    7819cf <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57df>
  781798:	jmp    7819cf <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57df>
  78179d:	mov    %rax,%rbx
  7817a0:	mov    0x1f8(%rsp),%rax
  7817a8:	test   %rax,%rax
  7817ab:	setne  %cl
  7817ae:	test   %cl,0x60(%rsp)
  7817b2:	je     78184f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x565f>
  7817b8:	lock decq (%rax)
  7817bc:	jne    78184f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x565f>
  7817c2:	lea    0x1f8(%rsp),%rdi
  7817ca:	call   *0x338bd0(%rip)        # aba3a0 <_DYNAMIC+0x360>
  7817d0:	jmp    78184f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x565f>
  7817d2:	jmp    7819cf <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57df>
  7817d7:	mov    %rax,%rbx
  7817da:	mov    $0x1,%r12b
  7817dd:	mov    $0x1,%r13b
  7817e0:	mov    $0x1,%r15b
  7817e3:	mov    $0x1,%bpl
  7817e6:	jmp    7818ef <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x56ff>
  7817eb:	mov    %rax,%rbx
  7817ee:	mov    $0x1,%r12b
  7817f1:	mov    $0x1,%r13b
  7817f4:	mov    $0x1,%r15b
  7817f7:	mov    $0x1,%bpl
  7817fa:	jmp    78190f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x571f>
  7817ff:	mov    %rax,%rbx
  781802:	mov    $0x1,%r12b
  781805:	mov    $0x1,%r13b
  781808:	mov    $0x1,%r15b
  78180b:	mov    $0x1,%bpl
  78180e:	jmp    781933 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5743>
  781813:	mov    %rax,%rbx
  781816:	mov    $0x1,%r12b
  781819:	mov    $0x1,%r13b
  78181c:	mov    $0x1,%r15b
  78181f:	mov    $0x1,%bpl
  781822:	jmp    781957 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5767>
  781827:	mov    %rax,%rbx
  78182a:	mov    $0x1,%bpl
  78182d:	mov    $0x1,%r15b
  781830:	mov    $0x1,%r12b
  781833:	jmp    781980 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5790>
  781838:	mov    %rax,%rbx
  78183b:	jmp    7819b6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57c6>
  781840:	ud2
  781842:	ud2
  781844:	mov    %rax,%rbx
  781847:	jmp    781a23 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5833>
  78184c:	mov    %rax,%rbx
  78184f:	mov    $0x1,%bpl
  781852:	lea    0x970(%rsp),%rdi
  78185a:	call   74d320 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas6canvas6CanvasECs9C2G9YFESsD_29canonical_text_public_control>
  78185f:	mov    $0x1,%r15b
  781862:	mov    $0x1,%r13b
  781865:	mov    $0x1,%al
  781867:	mov    %eax,0x30(%rsp)
  78186b:	mov    $0x1,%al
  78186d:	mov    %eax,0x38(%rsp)
  781871:	mov    $0x1,%r12b
  781874:	lea    0x6c0(%rsp),%rdi
  78187c:	call   74e860 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime6scroll13ViewportBuildECs9C2G9YFESsD_29canonical_text_public_control>
  781881:	cmpq   $0xffffffffffffffff,0x258(%rsp)
  78188a:	je     7818a0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x56b0>
  78188c:	cmpb   $0x0,0x38(%rsp)
  781891:	je     7818a0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x56b0>
  781893:	lea    0x8b8(%rsp),%rdi
  78189b:	call   747130 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCsghYClfd3M9V_11gpui_canvas5image5ImageEECs9C2G9YFESsD_29canonical_text_public_control>
  7818a0:	cmpl   $0xffffffff,0x810(%rsp)
  7818a8:	je     7818be <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x56ce>
  7818aa:	cmpb   $0x0,0x30(%rsp)
  7818af:	je     7818be <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x56ce>
  7818b1:	lea    0x810(%rsp),%rdi
  7818b9:	call   74eca0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCslbxve4rcJus_4gpui7runtime8metadata5SheetECs9C2G9YFESsD_29canonical_text_public_control>
  7818be:	lea    0x6a8(%rsp),%rdi
  7818c6:	call   74af00 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtCscdodAO9FK5_5alloc11collections5btree3set8BTreeSetNtNtCslbxve4rcJus_4gpui4list6ListIdEECs9C2G9YFESsD_29canonical_text_public_control>
  7818cb:	mov    0x100(%rsp),%rsi
  7818d3:	test   %rsi,%rsi
  7818d6:	je     7818ef <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x56ff>
  7818d8:	mov    0x108(%rsp),%rdi
  7818e0:	shl    $0x2,%rsi
  7818e4:	mov    $0x4,%edx
  7818e9:	call   *0x338991(%rip)        # aba280 <_DYNAMIC+0x240>
  7818ef:	mov    0x158(%rsp),%rsi
  7818f7:	test   %rsi,%rsi
  7818fa:	je     78190f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x571f>
  7818fc:	mov    0x160(%rsp),%rdi
  781904:	mov    $0x1,%edx
  781909:	call   *0x338971(%rip)        # aba280 <_DYNAMIC+0x240>
  78190f:	mov    0x230(%rsp),%rsi
  781917:	test   %rsi,%rsi
  78191a:	je     781933 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5743>
  78191c:	mov    0x238(%rsp),%rdi
  781924:	shl    $0x4,%rsi
  781928:	mov    $0x4,%edx
  78192d:	call   *0x33894d(%rip)        # aba280 <_DYNAMIC+0x240>
  781933:	mov    0x218(%rsp),%rsi
  78193b:	test   %rsi,%rsi
  78193e:	je     781957 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5767>
  781940:	mov    0x220(%rsp),%rdi
  781948:	shl    $0x4,%rsi
  78194c:	mov    $0x4,%edx
  781951:	call   *0x338929(%rip)        # aba280 <_DYNAMIC+0x240>
  781957:	mov    0x1d8(%rsp),%rax
  78195f:	test   %rax,%rax
  781962:	je     78197b <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x578b>
  781964:	mov    0x1e0(%rsp),%rdi
  78196c:	imul   $0x38,%rax,%rsi
  781970:	mov    $0x8,%edx
  781975:	call   *0x338905(%rip)        # aba280 <_DYNAMIC+0x240>
  78197b:	test   %r13b,%r13b
  78197e:	je     7819a4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57b4>
  781980:	mov    0x268(%rsp),%rsi
  781988:	test   %rsi,%rsi
  78198b:	je     7819a4 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57b4>
  78198d:	mov    0x270(%rsp),%rdi
  781995:	shl    $0x4,%rsi
  781999:	mov    $0x4,%edx
  78199e:	call   *0x3388dc(%rip)        # aba280 <_DYNAMIC+0x240>
  7819a4:	test   %r15b,%r15b
  7819a7:	je     7819b6 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57c6>
  7819a9:	lea    0x140(%rsp),%rdi
  7819b1:	call   7474f0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCslbxve4rcJus_4gpui7runtime9PresentedEECs9C2G9YFESsD_29canonical_text_public_control>
  7819b6:	cmpl   $0xfffffffe,0x7c8(%rsp)
  7819be:	je     7819d8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57e8>
  7819c0:	lea    0x7c8(%rsp),%rdi
  7819c8:	call   74d810 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCslbxve4rcJus_4gpui7runtime5ErrorECs9C2G9YFESsD_29canonical_text_public_control>
  7819cd:	jmp    7819d8 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x57e8>
  7819cf:	mov    %rax,%rbx
  7819d2:	mov    $0x1,%r12b
  7819d5:	mov    $0x1,%bpl
  7819d8:	cmpq   $0x0,0x1c0(%rsp)
  7819e1:	je     7819f0 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5800>
  7819e3:	mov    0x1c8(%rsp),%rdi
  7819eb:	call   74cd80 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas4text10TextShaperECs9C2G9YFESsD_29canonical_text_public_control>
  7819f0:	test   %r12b,%r12b
  7819f3:	je     781a02 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5812>
  7819f5:	lea    0x200(%rsp),%rdi
  7819fd:	call   747950 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtNtCslbxve4rcJus_4gpui7runtime13text_geometry5EntryEECs9C2G9YFESsD_29canonical_text_public_control>
  781a02:	mov    0xd0(%rsp),%rax
  781a0a:	test   %rax,%rax
  781a0d:	je     781a23 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5833>
  781a0f:	lock decq (%rax)
  781a13:	jne    781a23 <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x5833>
  781a15:	lea    0xd0(%rsp),%rdi
  781a1d:	call   *0x33894d(%rip)        # aba370 <_DYNAMIC+0x330>
  781a23:	cmpl   $0x2,0xca0(%rsp)
  781a2b:	je     781a3f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x584f>
  781a2d:	test   %bpl,%bpl
  781a30:	je     781a3f <_RNvMsu_NtCslbxve4rcJus_4gpui7runtimeINtB5_7RuntimeNtCs9C2G9YFESsD_29canonical_text_public_control6EditorE13present_innerBO_+0x584f>
  781a32:	lea    0xca0(%rsp),%rdi
  781a3a:	call   74d320 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCsghYClfd3M9V_11gpui_canvas6canvas6CanvasECs9C2G9YFESsD_29canonical_text_public_control>
  781a3f:	mov    %rbx,%rdi
  781a42:	call   a98730 <_Unwind_Resume@plt>
  781a47:	call   *0x33885b(%rip)        # aba2a8 <_DYNAMIC+0x268>

<&gpui_canvas::text::layout::TextPosition as core::fmt::Debug>::fmt bytes=99 frame=24

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000796a80 <_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextPositionNtB6_5Debug3fmtCs9C2G9YFESsD_29canonical_text_public_control>:
  796a80:	push   %r14
  796a82:	push   %rbx
  796a83:	push   %rax
  796a84:	mov    %rsi,%rax
  796a87:	mov    (%rdi),%r9
  796a8a:	lea    0x4(%r9),%rcx
  796a8e:	mov    %rcx,(%rsp)
  796a92:	sub    $0x8,%rsp
  796a96:	lea    0x305773(%rip),%r10        # a9c210 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2728>
  796a9d:	lea    0x8(%rsp),%r11
  796aa2:	lea    -0x6d2d71(%rip),%rbx        # c3d38 <GCC_except_table0+0x1930>
  796aa9:	lea    0x305740(%rip),%r14        # a9c1f0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2708>
  796ab0:	lea    -0x6c3a40(%rip),%rsi        # d3077 <GCC_except_table0+0x10c6f>
  796ab7:	lea    -0x6c6ff0(%rip),%rcx        # cface <GCC_except_table0+0xd6c6>
  796abe:	mov    $0xc,%edx
  796ac3:	mov    $0x6,%r8d
  796ac9:	mov    %rax,%rdi
  796acc:	push   %r10
  796ace:	push   %r11
  796ad0:	push   $0x8
  796ad2:	push   %rbx
  796ad3:	push   %r14
  796ad5:	call   *0x323f3d(%rip)        # abaa18 <_DYNAMIC+0x9d8>
  796adb:	add    $0x38,%rsp
  796adf:	pop    %rbx
  796ae0:	pop    %r14
  796ae2:	ret

<&gpui_canvas::text::layout::CaretAffinity as core::fmt::Debug>::fmt bytes=46 frame=0

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000796af0 <_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout13CaretAffinityNtB6_5Debug3fmtCs9C2G9YFESsD_29canonical_text_public_control>:
  796af0:	mov    %rsi,%rax
  796af3:	mov    (%rdi),%rcx
  796af6:	movzbl (%rcx),%ecx
  796af9:	lea    -0x6c3af3(%rip),%rdx        # d300d <GCC_except_table0+0x10c05>
  796b00:	lea    -0x6d2ccf(%rip),%rsi        # c3e38 <GCC_except_table0+0x1a30>
  796b07:	test   %ecx,%ecx
  796b09:	cmovne %rdx,%rsi
  796b0d:	lea    0x8(,%rcx,2),%rdx
  796b15:	mov    %rax,%rdi
  796b18:	jmp    *0x323f02(%rip)        # abaa20 <_DYNAMIC+0x9e0>

<&gpui_canvas::text::layout::TextSelection as core::fmt::Debug>::fmt bytes=99 frame=24

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000796b20 <_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout13TextSelectionNtB6_5Debug3fmtCs9C2G9YFESsD_29canonical_text_public_control>:
  796b20:	push   %r14
  796b22:	push   %rbx
  796b23:	push   %rax
  796b24:	mov    %rsi,%rax
  796b27:	mov    (%rdi),%r9
  796b2a:	lea    0x8(%r9),%rcx
  796b2e:	mov    %rcx,(%rsp)
  796b32:	sub    $0x8,%rsp
  796b36:	lea    0x303273(%rip),%r10        # a99db0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2c8>
  796b3d:	lea    0x8(%rsp),%r11
  796b42:	lea    -0x6c39d8(%rip),%rbx        # d3171 <GCC_except_table0+0x10d69>
  796b49:	lea    0x305720(%rip),%r14        # a9c270 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2788>
  796b50:	lea    -0x6c39f9(%rip),%rsi        # d315e <GCC_except_table0+0x10d56>
  796b57:	lea    -0x6c39f3(%rip),%rcx        # d316b <GCC_except_table0+0x10d63>
  796b5e:	mov    $0xd,%edx
  796b63:	mov    $0x6,%r8d
  796b69:	mov    %rax,%rdi
  796b6c:	push   %r10
  796b6e:	push   %r11
  796b70:	push   $0x5
  796b72:	push   %rbx
  796b73:	push   %r14
  796b75:	call   *0x323e9d(%rip)        # abaa18 <_DYNAMIC+0x9d8>
  796b7b:	add    $0x38,%rsp
  796b7f:	pop    %rbx
  796b80:	pop    %r14
  796b82:	ret

<&*const gpui_canvas::text::layout::TextGeometry as core::fmt::Debug>::fmt bytes=12 frame=0

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000796b90 <_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRPNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryNtB6_5Debug3fmtCs9C2G9YFESsD_29canonical_text_public_control>:
  796b90:	mov    (%rdi),%rax
  796b93:	mov    (%rax),%rdi
  796b96:	jmp    *0x323ebc(%rip)        # abaa58 <_DYNAMIC+0xa18>

<&(alloc::string::String, gpui_canvas::text::layout::TextSelection, *const gpui_canvas::text::layout::TextGeometry, u64) as core::fmt::Debug>::fmt bytes=156 frame=72

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000796be0 <_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRTNtNtCscdodAO9FK5_5alloc6string6StringNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout13TextSelectionPNtB1a_12TextGeometryyENtB6_5Debug3fmtCs9C2G9YFESsD_29canonical_text_public_control>:
  796be0:	push   %r14
  796be2:	push   %rbx
  796be3:	sub    $0x38,%rsp
  796be7:	mov    (%rdi),%r14
  796bea:	lea    0x20(%rsp),%rbx
  796bef:	mov    $0x1,%edx
  796bf4:	mov    %rbx,%rdi
  796bf7:	xor    %ecx,%ecx
  796bf9:	call   *0x323e61(%rip)        # abaa60 <_DYNAMIC+0xa20>
  796bff:	mov    %r14,(%rsp)
  796c03:	lea    0x18(%r14),%rax
  796c07:	mov    %rax,0x8(%rsp)
  796c0c:	lea    0x28(%r14),%rax
  796c10:	mov    %rax,0x10(%rsp)
  796c15:	add    $0x30,%r14
  796c19:	mov    %r14,0x18(%rsp)
  796c1e:	lea    0x30316b(%rip),%rdx        # a99d90 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2a8>
  796c25:	mov    0x323e3c(%rip),%r14        # abaa68 <_DYNAMIC+0xa28>
  796c2c:	mov    %rsp,%rsi
  796c2f:	mov    %rbx,%rdi
  796c32:	call   *%r14
  796c35:	lea    0x303194(%rip),%rdx        # a99dd0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2e8>
  796c3c:	lea    0x8(%rsp),%rsi
  796c41:	mov    %rbx,%rdi
  796c44:	call   *%r14
  796c47:	lea    0x30502a(%rip),%rdx        # a9bc78 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2190>
  796c4e:	lea    0x10(%rsp),%rsi
  796c53:	mov    %rbx,%rdi
  796c56:	call   *%r14
  796c59:	lea    0x305038(%rip),%rdx        # a9bc98 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x21b0>
  796c60:	lea    0x18(%rsp),%rsi
  796c65:	mov    %rbx,%rdi
  796c68:	call   *%r14
  796c6b:	mov    %rbx,%rdi
  796c6e:	call   *0x323dfc(%rip)        # abaa70 <_DYNAMIC+0xa30>
  796c74:	add    $0x38,%rsp
  796c78:	pop    %rbx
  796c79:	pop    %r14
  796c7b:	ret

<&(*const gpui_canvas::text::layout::TextGeometry, u64) as core::fmt::Debug>::fmt bytes=102 frame=56

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000796c80 <_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRTPNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryyENtB6_5Debug3fmtCs9C2G9YFESsD_29canonical_text_public_control>:
  796c80:	push   %r14
  796c82:	push   %rbx
  796c83:	sub    $0x28,%rsp
  796c87:	mov    (%rdi),%r14
  796c8a:	lea    0x10(%rsp),%rbx
  796c8f:	mov    $0x1,%edx
  796c94:	mov    %rbx,%rdi
  796c97:	xor    %ecx,%ecx
  796c99:	call   *0x323dc1(%rip)        # abaa60 <_DYNAMIC+0xa20>
  796c9f:	mov    %r14,(%rsp)
  796ca3:	add    $0x8,%r14
  796ca7:	mov    %r14,0x8(%rsp)
  796cac:	lea    0x304fc5(%rip),%rdx        # a9bc78 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2190>
  796cb3:	mov    0x323dae(%rip),%r14        # abaa68 <_DYNAMIC+0xa28>
  796cba:	mov    %rsp,%rsi
  796cbd:	mov    %rbx,%rdi
  796cc0:	call   *%r14
  796cc3:	lea    0x304fce(%rip),%rdx        # a9bc98 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x21b0>
  796cca:	lea    0x8(%rsp),%rsi
  796ccf:	mov    %rbx,%rdi
  796cd2:	call   *%r14
  796cd5:	mov    %rbx,%rdi
  796cd8:	call   *0x323d92(%rip)        # abaa70 <_DYNAMIC+0xa30>
  796cde:	add    $0x28,%rsp
  796ce2:	pop    %rbx
  796ce3:	pop    %r14
  796ce5:	ret

<gpui_canvas::text::layout::TextOffset as core::fmt::Debug>::fmt bytes=41 frame=8

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000796f90 <_RNvXs7_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_10TextOffsetNtNtCs4NRVxsYgnAr_4core3fmt5Debug3fmt>:
  796f90:	push   %rax
  796f91:	mov    %rsi,%rax
  796f94:	mov    %rdi,(%rsp)
  796f98:	lea    -0x6c421d(%rip),%rsi        # d2d82 <GCC_except_table0+0x1097a>
  796f9f:	lea    0x304f1a(%rip),%r8        # a9bec0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x23d8>
  796fa6:	mov    %rsp,%rcx
  796fa9:	mov    $0xa,%edx
  796fae:	mov    %rax,%rdi
  796fb1:	call   *0x323a71(%rip)        # abaa28 <_DYNAMIC+0x9e8>
  796fb7:	pop    %rcx
  796fb8:	ret

<core::iter::adapters::zip::Zip<core::slice::iter::ChunkBy<gpui_canvas::text::layout::Stop, <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#0}>, core::iter::adapters::skip::Skip<core::slice::iter::ChunkBy<gpui_canvas::text::layout::Stop, <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#0}>>> as core::iter::traits::iterator::Iterator>::next bytes=289 frame=24

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007986e0 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control>:
  7986e0:	push   %r15
  7986e2:	push   %r14
  7986e4:	push   %rbx
  7986e5:	mov    0x8(%rsi),%rax
  7986e9:	test   %rax,%rax
  7986ec:	je     7987f4 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control+0x114>
  7986f2:	mov    (%rsi),%rbx
  7986f5:	mov    $0x1,%r14d
  7986fb:	cmp    $0x1,%rax
  7986ff:	je     798724 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control+0x44>
  798701:	mov    (%rbx),%ecx
  798703:	lea    0xc(%rbx),%rdx
  798707:	lea    0x1(%rax),%r8
  79870b:	nopl   0x0(%rax,%rax,1)
  798710:	cmp    (%rdx),%ecx
  798712:	jne    798724 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control+0x44>
  798714:	inc    %r14
  798717:	add    $0xc,%rdx
  79871b:	dec    %r8
  79871e:	cmp    $0x2,%r8
  798722:	ja     798710 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control+0x30>
  798724:	sub    %r14,%rax
  798727:	jb     7987bd <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control+0xdd>
  79872d:	lea    (%r14,%r14,2),%rcx
  798731:	lea    (%rbx,%rcx,4),%rcx
  798735:	mov    %rcx,(%rsi)
  798738:	mov    %rax,0x8(%rsi)
  79873c:	lea    0x10(%rsi),%rax
  798740:	mov    0x20(%rsi),%rcx
  798744:	test   %rcx,%rcx
  798747:	jne    7987d6 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control+0xf6>
  79874d:	mov    0x18(%rsi),%rcx
  798751:	test   %rcx,%rcx
  798754:	je     7987a1 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control+0xc1>
  798756:	mov    (%rax),%rax
  798759:	mov    $0x1,%edx
  79875e:	cmp    $0x1,%rcx
  798762:	je     798785 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control+0xa5>
  798764:	mov    (%rax),%r8d
  798767:	lea    0xc(%rax),%r9
  79876b:	lea    0x1(%rcx),%r10
  79876f:	nop
  798770:	cmp    (%r9),%r8d
  798773:	jne    798785 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control+0xa5>
  798775:	inc    %rdx
  798778:	add    $0xc,%r9
  79877c:	dec    %r10
  79877f:	cmp    $0x2,%r10
  798783:	ja     798770 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control+0x90>
  798785:	sub    %rdx,%rcx
  798788:	jb     7987bd <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control+0xdd>
  79878a:	lea    (%rdx,%rdx,2),%r8
  79878e:	lea    (%rax,%r8,4),%r8
  798792:	mov    %r8,0x10(%rsi)
  798796:	mov    %rcx,0x18(%rsi)
  79879a:	test   %rax,%rax
  79879d:	jne    7987a8 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control+0xc8>
  79879f:	jmp    7987f4 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control+0x114>
  7987a1:	xor    %eax,%eax
  7987a3:	test   %rax,%rax
  7987a6:	je     7987f4 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control+0x114>
  7987a8:	mov    %rbx,(%rdi)
  7987ab:	mov    %r14,0x8(%rdi)
  7987af:	mov    %rax,0x10(%rdi)
  7987b3:	mov    %rdx,0x18(%rdi)
  7987b7:	pop    %rbx
  7987b8:	pop    %r14
  7987ba:	pop    %r15
  7987bc:	ret
  7987bd:	lea    -0x6c8b23(%rip),%rdi        # cfca1 <GCC_except_table0+0xd899>
  7987c4:	lea    0x3036c5(%rip),%rdx        # a9be90 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x23a8>
  7987cb:	mov    $0x13,%esi
  7987d0:	call   *0x321ae2(%rip)        # aba2b8 <_DYNAMIC+0x278>
  7987d6:	movq   $0x0,0x20(%rsi)
  7987de:	mov    %rdi,%r15
  7987e1:	mov    %rax,%rdi
  7987e4:	mov    %rcx,%rsi
  7987e7:	call   7996a0 <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthCs9C2G9YFESsD_29canonical_text_public_control>
  7987ec:	mov    %r15,%rdi
  7987ef:	test   %rax,%rax
  7987f2:	jne    7987a8 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextCs9C2G9YFESsD_29canonical_text_public_control+0xc8>
  7987f4:	movq   $0x0,(%rdi)
  7987fb:	pop    %rbx
  7987fc:	pop    %r14
  7987fe:	pop    %r15
  798800:	ret

<gpui_canvas::text::layout::TextPosition as core::fmt::Debug>::fmt bytes=99 frame=24

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

0000000000798b00 <_RNvXsn_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextPositionNtNtCs4NRVxsYgnAr_4core3fmt5Debug3fmt>:
  798b00:	push   %r14
  798b02:	push   %rbx
  798b03:	push   %rax
  798b04:	mov    %rsi,%rax
  798b07:	mov    %rdi,%r9
  798b0a:	lea    0x4(%rdi),%rcx
  798b0e:	mov    %rcx,(%rsp)
  798b12:	sub    $0x8,%rsp
  798b16:	lea    0x3036f3(%rip),%r10        # a9c210 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2728>
  798b1d:	lea    0x8(%rsp),%r11
  798b22:	lea    -0x6d4df1(%rip),%rbx        # c3d38 <GCC_except_table0+0x1930>
  798b29:	lea    0x3036c0(%rip),%r14        # a9c1f0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x2708>
  798b30:	lea    -0x6c5ac0(%rip),%rsi        # d3077 <GCC_except_table0+0x10c6f>
  798b37:	lea    -0x6c9070(%rip),%rcx        # cface <GCC_except_table0+0xd6c6>
  798b3e:	mov    $0xc,%edx
  798b43:	mov    $0x6,%r8d
  798b49:	mov    %rax,%rdi
  798b4c:	push   %r10
  798b4e:	push   %r11
  798b50:	push   $0x8
  798b52:	push   %rbx
  798b53:	push   %r14
  798b55:	call   *0x321ebd(%rip)        # abaa18 <_DYNAMIC+0x9d8>
  798b5b:	add    $0x38,%rsp
  798b5f:	pop    %rbx
  798b60:	pop    %r14
  798b62:	ret

<core::slice::iter::ChunkBy<gpui_canvas::text::layout::Stop, <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#0}> as core::iter::traits::iterator::Iterator>::nth bytes=232 frame=8

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007996a0 <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthCs9C2G9YFESsD_29canonical_text_public_control>:
  7996a0:	push   %rax
  7996a1:	mov    (%rdi),%rax
  7996a4:	mov    0x8(%rdi),%r8
  7996a8:	nopl   0x0(%rax,%rax,1)
  7996b0:	mov    %r8,%rcx
  7996b3:	mov    %rax,%r9
  7996b6:	mov    %r8,%r10
  7996b9:	cmp    $0x1,%r8
  7996bd:	je     7996f4 <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthCs9C2G9YFESsD_29canonical_text_public_control+0x54>
  7996bf:	test   %rcx,%rcx
  7996c2:	je     79976b <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthCs9C2G9YFESsD_29canonical_text_public_control+0xcb>
  7996c8:	mov    (%r9),%eax
  7996cb:	lea    0xc(%r9),%rdx
  7996cf:	lea    0x1(%rcx),%r8
  7996d3:	mov    $0x1,%r10d
  7996d9:	nopl   0x0(%rax)
  7996e0:	cmp    (%rdx),%eax
  7996e2:	jne    7996f4 <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthCs9C2G9YFESsD_29canonical_text_public_control+0x54>
  7996e4:	inc    %r10
  7996e7:	add    $0xc,%rdx
  7996eb:	dec    %r8
  7996ee:	cmp    $0x2,%r8
  7996f2:	ja     7996e0 <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthCs9C2G9YFESsD_29canonical_text_public_control+0x40>
  7996f4:	mov    %rcx,%r8
  7996f7:	sub    %r10,%r8
  7996fa:	jb     79976f <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthCs9C2G9YFESsD_29canonical_text_public_control+0xcf>
  7996fc:	lea    (%r10,%r10,2),%r11
  799700:	lea    (%r9,%r11,4),%rax
  799704:	mov    %rax,(%rdi)
  799707:	mov    %r8,0x8(%rdi)
  79970b:	dec    %rsi
  79970e:	jne    7996b0 <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthCs9C2G9YFESsD_29canonical_text_public_control+0x10>
  799710:	test   %r8,%r8
  799713:	je     79976b <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthCs9C2G9YFESsD_29canonical_text_public_control+0xcb>
  799715:	mov    %r8,%rdx
  799718:	cmp    $0x1,%r8
  79971c:	je     799755 <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthCs9C2G9YFESsD_29canonical_text_public_control+0xb5>
  79971e:	mov    (%rax),%esi
  799720:	lea    (%r9,%r11,4),%r9
  799724:	add    $0xc,%r9
  799728:	sub    %r10,%rcx
  79972b:	inc    %rcx
  79972e:	mov    $0x1,%edx
  799733:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  799740:	cmp    (%r9),%esi
  799743:	jne    799755 <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthCs9C2G9YFESsD_29canonical_text_public_control+0xb5>
  799745:	inc    %rdx
  799748:	add    $0xc,%r9
  79974c:	dec    %rcx
  79974f:	cmp    $0x2,%rcx
  799753:	ja     799740 <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthCs9C2G9YFESsD_29canonical_text_public_control+0xa0>
  799755:	sub    %rdx,%r8
  799758:	jb     79976f <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthCs9C2G9YFESsD_29canonical_text_public_control+0xcf>
  79975a:	lea    (%rdx,%rdx,2),%rcx
  79975e:	lea    (%rax,%rcx,4),%rcx
  799762:	mov    %rcx,(%rdi)
  799765:	mov    %r8,0x8(%rdi)
  799769:	pop    %rcx
  79976a:	ret
  79976b:	xor    %eax,%eax
  79976d:	pop    %rcx
  79976e:	ret
  79976f:	lea    -0x6c9ad5(%rip),%rdi        # cfca1 <GCC_except_table0+0xd899>
  799776:	lea    0x302713(%rip),%rdx        # a9be90 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x23a8>
  79977d:	mov    $0x13,%esi
  799782:	call   *0x320b30(%rip)        # aba2b8 <_DYNAMIC+0x278>

<gpui::runtime::text_geometry::TextResources>::acknowledge bytes=336 frame=104

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

000000000079e2e0 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge>:
  79e2e0:	push   %rbp
  79e2e1:	push   %r15
  79e2e3:	push   %r14
  79e2e5:	push   %r13
  79e2e7:	push   %r12
  79e2e9:	push   %rbx
  79e2ea:	sub    $0x38,%rsp
  79e2ee:	mov    0x18(%rdi),%rax
  79e2f2:	movq   $0xffffffffffffffff,0x18(%rdi)
  79e2fa:	cmp    $0xffffffffffffffff,%rax
  79e2fe:	je     79e3a6 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0xc6>
  79e304:	mov    %rdi,%rbx
  79e307:	mov    %rax,0x10(%rsp)
  79e30c:	movups 0x20(%rdi),%xmm0
  79e310:	movaps %xmm0,0x20(%rsp)
  79e315:	lea    0x8(%rdi),%rax
  79e319:	mov    %rax,0x8(%rsp)
  79e31e:	mov    0x8(%rdi),%r14
  79e322:	mov    0x10(%rdi),%rax
  79e326:	test   %rax,%rax
  79e329:	je     79e373 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0x93>
  79e32b:	mov    $0x1,%r15d
  79e331:	sub    %rax,%r15
  79e334:	mov    $0xffffffffffffffe8,%r13
  79e33b:	xor    %r12d,%r12d
  79e33e:	mov    0x31c05b(%rip),%rbp        # aba3a0 <_DYNAMIC+0x360>
  79e345:	jmp    79e361 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0x81>
  79e347:	nopw   0x0(%rax,%rax,1)
  79e350:	add    $0xffffffffffffffe8,%r13
  79e354:	inc    %r15
  79e357:	add    $0x18,%r12
  79e35b:	cmp    $0x1,%r15
  79e35f:	je     79e373 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0x93>
  79e361:	mov    (%r14,%r12,1),%rax
  79e365:	lock decq (%rax)
  79e369:	jne    79e350 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0x70>
  79e36b:	lea    (%r14,%r12,1),%rdi
  79e36f:	call   *%rbp
  79e371:	jmp    79e350 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0x70>
  79e373:	mov    (%rbx),%rax
  79e376:	test   %rax,%rax
  79e379:	je     79e391 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0xb1>
  79e37b:	shl    $0x3,%rax
  79e37f:	lea    (%rax,%rax,2),%rsi
  79e383:	mov    $0x8,%edx
  79e388:	mov    %r14,%rdi
  79e38b:	call   *0x31beef(%rip)        # aba280 <_DYNAMIC+0x240>
  79e391:	mov    0x10(%rsp),%rax
  79e396:	mov    %rax,(%rbx)
  79e399:	movaps 0x20(%rsp),%xmm0
  79e39e:	mov    0x8(%rsp),%rax
  79e3a3:	movups %xmm0,(%rax)
  79e3a6:	add    $0x38,%rsp
  79e3aa:	pop    %rbx
  79e3ab:	pop    %r12
  79e3ad:	pop    %r13
  79e3af:	pop    %r14
  79e3b1:	pop    %r15
  79e3b3:	pop    %rbp
  79e3b4:	ret
  79e3b5:	mov    %rax,0x18(%rsp)
  79e3ba:	test   %r15,%r15
  79e3bd:	jne    79e3fc <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0x11c>
  79e3bf:	mov    (%rbx),%rax
  79e3c2:	test   %rax,%rax
  79e3c5:	je     79e3dd <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0xfd>
  79e3c7:	shl    $0x3,%rax
  79e3cb:	lea    (%rax,%rax,2),%rsi
  79e3cf:	mov    $0x8,%edx
  79e3d4:	mov    %r14,%rdi
  79e3d7:	call   *0x31bea3(%rip)        # aba280 <_DYNAMIC+0x240>
  79e3dd:	mov    0x10(%rsp),%rax
  79e3e2:	mov    %rax,(%rbx)
  79e3e5:	movaps 0x20(%rsp),%xmm0
  79e3ea:	mov    0x8(%rsp),%rax
  79e3ef:	movups %xmm0,(%rax)
  79e3f2:	mov    0x18(%rsp),%rdi
  79e3f7:	call   a98730 <_Unwind_Resume@plt>
  79e3fc:	mov    %r14,%r12
  79e3ff:	sub    %r13,%r12
  79e402:	neg    %r15
  79e405:	jmp    79e419 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0x139>
  79e407:	nopw   0x0(%rax,%rax,1)
  79e410:	add    $0x18,%r12
  79e414:	dec    %r15
  79e417:	je     79e3bf <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0xdf>
  79e419:	mov    (%r12),%rax
  79e41d:	lock decq (%rax)
  79e421:	jne    79e410 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0x130>
  79e423:	mov    %r12,%rdi
  79e426:	call   *%rbp
  79e428:	jmp    79e410 <_RNvMNtNtCslbxve4rcJus_4gpui7runtime13text_geometryNtB2_13TextResources11acknowledge+0x130>
  79e42a:	call   *0x31be78(%rip)        # aba2a8 <_DYNAMIC+0x268>

<gpui::runtime::geometry::Geometry>::acknowledge bytes=76 frame=24

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007a6670 <_RNvMs4_NtNtCslbxve4rcJus_4gpui7runtime8geometryNtB5_8Geometry11acknowledge>:
  7a6670:	push   %r15
  7a6672:	push   %r14
  7a6674:	push   %rbx
  7a6675:	mov    0x30(%rdi),%r14
  7a6679:	movq   $0xffffffffffffffff,0x30(%rdi)
  7a6681:	cmp    $0xffffffffffffffff,%r14
  7a6685:	je     7a66b6 <_RNvMs4_NtNtCslbxve4rcJus_4gpui7runtime8geometryNtB5_8Geometry11acknowledge+0x46>
  7a6687:	mov    %rdi,%rbx
  7a668a:	lea    0x38(%rdi),%r15
  7a668e:	mov    0x18(%rdi),%rsi
  7a6692:	test   %rsi,%rsi
  7a6695:	je     7a66aa <_RNvMs4_NtNtCslbxve4rcJus_4gpui7runtime8geometryNtB5_8Geometry11acknowledge+0x3a>
  7a6697:	mov    0x20(%rbx),%rdi
  7a669b:	shl    $0x4,%rsi
  7a669f:	mov    $0x4,%edx
  7a66a4:	call   *0x313bd6(%rip)        # aba280 <_DYNAMIC+0x240>
  7a66aa:	mov    %r14,0x18(%rbx)
  7a66ae:	movups (%r15),%xmm0
  7a66b2:	movups %xmm0,0x20(%rbx)
  7a66b6:	pop    %rbx
  7a66b7:	pop    %r14
  7a66b9:	pop    %r15
  7a66bb:	ret

<gpui::runtime::TextSite>::shape_for bytes=463 frame=168

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007a8b80 <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for>:
  7a8b80:	push   %rbp
  7a8b81:	push   %r15
  7a8b83:	push   %r14
  7a8b85:	push   %r13
  7a8b87:	push   %r12
  7a8b89:	push   %rbx
  7a8b8a:	sub    $0x78,%rsp
  7a8b8e:	mov    %ecx,%ebp
  7a8b90:	mov    %rsi,%rbx
  7a8b93:	maxss  -0x6e6513(%rip),%xmm1        # c2688 <GCC_except_table0+0x280>
  7a8b9b:	mov    %rdi,%r14
  7a8b9e:	movd   %xmm1,%r12d
  7a8ba3:	cmpq   $0xffffffffffffffff,(%rsi)
  7a8ba7:	je     7a8bc3 <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x43>
  7a8ba9:	cmpl   $0x1,0x38(%rbx)
  7a8bad:	jne    7a8c89 <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x109>
  7a8bb3:	cmp    %r12d,0x3c(%rbx)
  7a8bb7:	sete   %al
  7a8bba:	test   %al,%bpl
  7a8bbd:	jne    7a8c93 <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x113>
  7a8bc3:	test   %r8b,%r8b
  7a8bc6:	je     7a8bf1 <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x71>
  7a8bc8:	mov    %r12d,0x8(%rsp)
  7a8bcd:	mov    0x40(%rbx),%rax
  7a8bd1:	mov    (%rax),%rcx
  7a8bd4:	shr    $1,%rcx
  7a8bd7:	add    $0x10,%rax
  7a8bdb:	lea    0x40(%rsp),%rdi
  7a8be0:	mov    %rdx,%rsi
  7a8be3:	mov    %rax,%rdx
  7a8be6:	mov    %ebp,%r8d
  7a8be9:	call   *0x311929(%rip)        # aba518 <_DYNAMIC+0x4d8>
  7a8bef:	jmp    7a8c18 <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x98>
  7a8bf1:	mov    %r12d,0x8(%rsp)
  7a8bf6:	mov    0x40(%rbx),%rax
  7a8bfa:	mov    (%rax),%rcx
  7a8bfd:	shr    $1,%rcx
  7a8c00:	add    $0x10,%rax
  7a8c04:	lea    0x40(%rsp),%rdi
  7a8c09:	mov    %rdx,%rsi
  7a8c0c:	mov    %rax,%rdx
  7a8c0f:	mov    %ebp,%r8d
  7a8c12:	call   *0x312038(%rip)        # abac50 <_DYNAMIC+0xc10>
  7a8c18:	mov    0x40(%rsp),%r15
  7a8c1d:	mov    0x48(%rsp),%r13d
  7a8c22:	mov    0x4c(%rsp),%r12d
  7a8c27:	cmp    $0xffffffffffffffff,%r15
  7a8c2b:	je     7a8ce9 <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x169>
  7a8c31:	mov    0x70(%rsp),%rax
  7a8c36:	mov    %rax,0x30(%rsp)
  7a8c3b:	movups 0x50(%rsp),%xmm0
  7a8c40:	movups 0x60(%rsp),%xmm1
  7a8c45:	movaps %xmm1,0x20(%rsp)
  7a8c4a:	movaps %xmm0,0x10(%rsp)
  7a8c4f:	mov    %rbx,%rdi
  7a8c52:	call   79a180 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtCslbxve4rcJus_4gpui7runtime6ShapedEEB11_>
  7a8c57:	mov    %r15,(%rbx)
  7a8c5a:	mov    %r13d,0x8(%rbx)
  7a8c5e:	mov    %r12d,0xc(%rbx)
  7a8c62:	movaps 0x10(%rsp),%xmm0
  7a8c67:	movaps 0x20(%rsp),%xmm1
  7a8c6c:	movups %xmm0,0x10(%rbx)
  7a8c70:	movups %xmm1,0x20(%rbx)
  7a8c74:	mov    0x30(%rsp),%rax
  7a8c79:	mov    %rax,0x30(%rbx)
  7a8c7d:	mov    %ebp,0x38(%rbx)
  7a8c80:	mov    0x8(%rsp),%eax
  7a8c84:	mov    %eax,0x3c(%rbx)
  7a8c87:	jmp    7a8cdc <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x15c>
  7a8c89:	test   $0x1,%bpl
  7a8c8d:	jne    7a8bc3 <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x43>
  7a8c93:	test   %r8b,%r8b
  7a8c96:	je     7a8cdc <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x15c>
  7a8c98:	lea    0x40(%rsp),%rdi
  7a8c9d:	mov    %rbx,%rsi
  7a8ca0:	mov    %rdx,%r15
  7a8ca3:	xor    %edx,%edx
  7a8ca5:	mov    $0x1,%ecx
  7a8caa:	movss  %xmm1,0x8(%rsp)
  7a8cb0:	movss  %xmm0,0xc(%rsp)
  7a8cb6:	call   *0x311a0c(%rip)        # aba6c8 <_DYNAMIC+0x688>
  7a8cbc:	movss  0xc(%rsp),%xmm0
  7a8cc2:	movss  0x8(%rsp),%xmm1
  7a8cc8:	mov    %r15,%rdx
  7a8ccb:	cmpb   $0x0,0x40(%rsp)
  7a8cd0:	je     7a8bc8 <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x48>
  7a8cd6:	cmpq   $0xffffffffffffffff,(%rbx)
  7a8cda:	je     7a8d0a <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x18a>
  7a8cdc:	mov    %rbx,0x8(%r14)
  7a8ce0:	movq   $0xfffffffffffffffe,(%r14)
  7a8ce7:	jmp    7a8cf8 <_RNvMsi_NtCslbxve4rcJus_4gpui7runtimeNtB5_8TextSite9shape_for+0x178>
  7a8ce9:	movq   $0x23,(%r14)
  7a8cf0:	mov    %r13d,0x8(%r14)
  7a8cf4:	mov    %r12d,0xc(%r14)
  7a8cf8:	mov    %r14,%rax
  7a8cfb:	add    $0x78,%rsp
  7a8cff:	pop    %rbx
  7a8d00:	pop    %r12
  7a8d02:	pop    %r13
  7a8d04:	pop    %r14
  7a8d06:	pop    %r15
  7a8d08:	pop    %rbp
  7a8d09:	ret
  7a8d0a:	lea    0x2f3ddf(%rip),%rdi        # a9caf0 <_RNvNvCslJFIqpe90s2_9tiny_xlib4XLIB15___CTOR_FUNCTION+0x3008>
  7a8d11:	call   *0x311629(%rip)        # aba340 <_DYNAMIC+0x300>
  7a8d17:	mov    %r15,(%rbx)
  7a8d1a:	mov    %r13d,0x8(%rbx)
  7a8d1e:	mov    %r12d,0xc(%rbx)
  7a8d22:	movaps 0x10(%rsp),%xmm0
  7a8d27:	movaps 0x20(%rsp),%xmm1
  7a8d2c:	movups %xmm0,0x10(%rbx)
  7a8d30:	movups %xmm1,0x20(%rbx)
  7a8d34:	mov    0x30(%rsp),%rcx
  7a8d39:	mov    %rcx,0x30(%rbx)
  7a8d3d:	mov    %ebp,0x38(%rbx)
  7a8d40:	mov    0x8(%rsp),%ecx
  7a8d44:	mov    %ecx,0x3c(%rbx)
  7a8d47:	mov    %rax,%rdi
  7a8d4a:	call   a98730 <_Unwind_Resume@plt>

gpui::runtime::image::acknowledge bytes=157 frame=40

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007ab1f0 <_RNvNtNtCslbxve4rcJus_4gpui7runtime5image11acknowledge>:
  7ab1f0:	push   %r15
  7ab1f2:	push   %r14
  7ab1f4:	push   %rbx
  7ab1f5:	sub    $0x10,%rsp
  7ab1f9:	mov    (%rdi),%r14
  7ab1fc:	test   %r14,%r14
  7ab1ff:	je     7ab25f <_RNvNtNtCslbxve4rcJus_4gpui7runtime5image11acknowledge+0x6f>
  7ab201:	mov    %rdi,%rbx
  7ab204:	mov    0x38(%r14),%r15
  7ab208:	cmp    $0xffffffffffffffff,%r15
  7ab20c:	je     7ab23b <_RNvNtNtCslbxve4rcJus_4gpui7runtime5image11acknowledge+0x4b>
  7ab20e:	cmp    %rsi,0x30(%r14)
  7ab212:	jne    7ab23b <_RNvNtNtCslbxve4rcJus_4gpui7runtime5image11acknowledge+0x4b>
  7ab214:	movups 0x40(%r14),%xmm0
  7ab219:	movaps %xmm0,(%rsp)
  7ab21d:	movq   $0xffffffffffffffff,0x38(%r14)
  7ab225:	lea    0x18(%r14),%rdi
  7ab229:	call   79a2b0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCsghYClfd3M9V_11gpui_canvas5image5ImageEECslbxve4rcJus_4gpui>
  7ab22e:	mov    %r15,0x18(%r14)
  7ab232:	movaps (%rsp),%xmm0
  7ab236:	movups %xmm0,0x20(%r14)
  7ab23b:	cmpq   $0x0,0x10(%r14)
  7ab240:	jne    7ab25f <_RNvNtNtCslbxve4rcJus_4gpui7runtime5image11acknowledge+0x6f>
  7ab242:	cmpq   $0x0,0x28(%r14)
  7ab247:	jne    7ab25f <_RNvNtNtCslbxve4rcJus_4gpui7runtime5image11acknowledge+0x6f>
  7ab249:	cmpq   $0xffffffffffffffff,0x38(%r14)
  7ab24e:	jne    7ab25f <_RNvNtNtCslbxve4rcJus_4gpui7runtime5image11acknowledge+0x6f>
  7ab250:	mov    %r14,%rdi
  7ab253:	call   79a020 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionINtNtCscdodAO9FK5_5alloc5boxed3BoxNtNtNtCslbxve4rcJus_4gpui7runtime5image6ImagesEEEB1B_>
  7ab258:	movq   $0x0,(%rbx)
  7ab25f:	add    $0x10,%rsp
  7ab263:	pop    %rbx
  7ab264:	pop    %r14
  7ab266:	pop    %r15
  7ab268:	ret
  7ab269:	movq   $0x0,(%rbx)
  7ab270:	mov    %rax,%rdi
  7ab273:	call   a98730 <_Unwind_Resume@plt>
  7ab278:	mov    %r15,0x18(%r14)
  7ab27c:	movaps (%rsp),%xmm0
  7ab280:	movups %xmm0,0x20(%r14)
  7ab285:	mov    %rax,%rdi
  7ab288:	call   a98730 <_Unwind_Resume@plt>

core::ptr::drop_glue::<core::option::Option<gpui_canvas::text::layout::TextGeometry>> bytes=108 frame=8

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007bbe30 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryEEB13_>:
  7bbe30:	push   %rbx
  7bbe31:	mov    (%rdi),%rax
  7bbe34:	cmp    $0xffffffffffffffff,%rax
  7bbe38:	je     7bbe9a <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryEEB13_+0x6a>
  7bbe3a:	mov    %rdi,%rbx
  7bbe3d:	test   %rax,%rax
  7bbe40:	je     7bbe59 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryEEB13_+0x29>
  7bbe42:	mov    0x8(%rbx),%rdi
  7bbe46:	shl    $0x3,%rax
  7bbe4a:	lea    (%rax,%rax,2),%rsi
  7bbe4e:	mov    $0x4,%edx
  7bbe53:	call   *0x2fe427(%rip)        # aba280 <_DYNAMIC+0x240>
  7bbe59:	mov    0x18(%rbx),%rax
  7bbe5d:	test   %rax,%rax
  7bbe60:	je     7bbe79 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryEEB13_+0x49>
  7bbe62:	mov    0x20(%rbx),%rdi
  7bbe66:	shl    $0x3,%rax
  7bbe6a:	lea    (%rax,%rax,2),%rsi
  7bbe6e:	mov    $0x4,%edx
  7bbe73:	call   *0x2fe407(%rip)        # aba280 <_DYNAMIC+0x240>
  7bbe79:	mov    0x30(%rbx),%rax
  7bbe7d:	test   %rax,%rax
  7bbe80:	jle    7bbe9a <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryEEB13_+0x6a>
  7bbe82:	mov    0x38(%rbx),%rdi
  7bbe86:	shl    $0x2,%rax
  7bbe8a:	lea    (%rax,%rax,2),%rsi
  7bbe8e:	mov    $0x4,%edx
  7bbe93:	pop    %rbx
  7bbe94:	jmp    *0x2fe3e6(%rip)        # aba280 <_DYNAMIC+0x240>
  7bbe9a:	pop    %rbx
  7bbe9b:	ret

core::ptr::drop_glue::<alloc::sync::ArcInner<gpui_canvas::text::layout::TextGeometry>> bytes=103 frame=8

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007bcb70 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc4sync8ArcInnerNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryEEB1j_>:
  7bcb70:	push   %rbx
  7bcb71:	mov    %rdi,%rbx
  7bcb74:	mov    0x10(%rdi),%rax
  7bcb78:	test   %rax,%rax
  7bcb7b:	je     7bcb94 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc4sync8ArcInnerNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryEEB1j_+0x24>
  7bcb7d:	mov    0x18(%rbx),%rdi
  7bcb81:	shl    $0x3,%rax
  7bcb85:	lea    (%rax,%rax,2),%rsi
  7bcb89:	mov    $0x4,%edx
  7bcb8e:	call   *0x2fd6ec(%rip)        # aba280 <_DYNAMIC+0x240>
  7bcb94:	mov    0x28(%rbx),%rax
  7bcb98:	test   %rax,%rax
  7bcb9b:	je     7bcbb4 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc4sync8ArcInnerNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryEEB1j_+0x44>
  7bcb9d:	mov    0x30(%rbx),%rdi
  7bcba1:	shl    $0x3,%rax
  7bcba5:	lea    (%rax,%rax,2),%rsi
  7bcba9:	mov    $0x4,%edx
  7bcbae:	call   *0x2fd6cc(%rip)        # aba280 <_DYNAMIC+0x240>
  7bcbb4:	mov    0x40(%rbx),%rax
  7bcbb8:	test   %rax,%rax
  7bcbbb:	jle    7bcbd5 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc4sync8ArcInnerNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryEEB1j_+0x65>
  7bcbbd:	mov    0x48(%rbx),%rdi
  7bcbc1:	shl    $0x2,%rax
  7bcbc5:	lea    (%rax,%rax,2),%rsi
  7bcbc9:	mov    $0x4,%edx
  7bcbce:	pop    %rbx
  7bcbcf:	jmp    *0x2fd6ab(%rip)        # aba280 <_DYNAMIC+0x240>
  7bcbd5:	pop    %rbx
  7bcbd6:	ret

<gpui_canvas::text::layout::TextGeometry>::intervals::{closure#1} bytes=791 frame=56

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007c98c0 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_>:
  7c98c0:	push   %rbp
  7c98c1:	push   %r15
  7c98c3:	push   %r14
  7c98c5:	push   %r13
  7c98c7:	push   %r12
  7c98c9:	push   %rbx
  7c98ca:	push   %rax
  7c98cb:	mov    (%rdx),%r9
  7c98ce:	mov    0x8(%rdx),%rcx
  7c98d2:	mov    0x10(%rdx),%r10
  7c98d6:	mov    0x18(%rdx),%rax
  7c98da:	shl    $0x2,%rcx
  7c98de:	lea    (%rcx,%rcx,2),%rcx
  7c98e2:	xor    %ebx,%ebx
  7c98e4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  7c98f0:	cmp    %rbx,%rcx
  7c98f3:	je     7c9a64 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x1a4>
  7c98f9:	movzbl 0x8(%r9,%rbx,1),%r11d
  7c98ff:	add    $0xc,%rbx
  7c9903:	test   $0x2,%r11b
  7c9907:	je     7c98f0 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x30>
  7c9909:	shl    $0x2,%rax
  7c990d:	lea    (%rax,%rax,2),%rax
  7c9911:	xor    %ecx,%ecx
  7c9913:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  7c9920:	cmp    %rcx,%rax
  7c9923:	je     7c9a64 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x1a4>
  7c9929:	lea    0xc(%rcx),%r14
  7c992d:	testb  $0x1,0x8(%r10,%rcx,1)
  7c9933:	mov    %r14,%rcx
  7c9936:	je     7c9920 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x60>
  7c9938:	mov    -0xc(%r9,%rbx,1),%edx
  7c993d:	mov    0x20(%rsi),%r15
  7c9941:	mov    0x28(%rsi),%rcx
  7c9945:	mov    %rcx,%rax
  7c9948:	test   %rcx,%rcx
  7c994b:	je     7c9999 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0xd9>
  7c994d:	xor    %r8d,%r8d
  7c9950:	cmp    $0x1,%rcx
  7c9954:	je     7c9981 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0xc1>
  7c9956:	mov    %rcx,%rax
  7c9959:	nopl   0x0(%rax)
  7c9960:	mov    %r8,%r12
  7c9963:	mov    %rax,%r13
  7c9966:	shr    $1,%r13
  7c9969:	add    %r13,%r8
  7c996c:	lea    (%r8,%r8,2),%rbp
  7c9970:	cmp    %edx,(%r15,%rbp,8)
  7c9974:	cmova  %r12,%r8
  7c9978:	sub    %r13,%rax
  7c997b:	cmp    $0x1,%rax
  7c997f:	ja     7c9960 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0xa0>
  7c9981:	lea    (%r8,%r8,2),%r12
  7c9985:	xor    %eax,%eax
  7c9987:	cmp    %edx,(%r15,%r12,8)
  7c998b:	setbe  %al
  7c998e:	add    %r8,%rax
  7c9991:	cmp    $0x1,%rax
  7c9995:	adc    $0xffffffffffffffff,%rax
  7c9999:	cmp    %rcx,%rax
  7c999c:	jae    7c9bb1 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x2f1>
  7c99a2:	lea    (%rax,%rax,2),%r12
  7c99a6:	mov    %rax,%r8
  7c99a9:	test   %rax,%rax
  7c99ac:	je     7c9a23 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x163>
  7c99ae:	mov    %rax,%r8
  7c99b1:	test   %edx,%edx
  7c99b3:	je     7c9a23 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x163>
  7c99b5:	mov    %rax,%r8
  7c99b8:	and    $0x1,%r11b
  7c99bc:	je     7c9a23 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x163>
  7c99be:	lea    (%r15,%r12,8),%r11
  7c99c2:	mov    %rax,%r8
  7c99c5:	cmp    %edx,-0x14(%r11)
  7c99c9:	jne    7c9a23 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x163>
  7c99cb:	xor    %r8d,%r8d
  7c99ce:	mov    %rcx,%r11
  7c99d1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  7c99e0:	mov    %r11,%r13
  7c99e3:	shr    $1,%r13
  7c99e6:	lea    (%r8,%r13,1),%rbp
  7c99ea:	lea    0x0(,%rbp,2),%r12
  7c99f2:	add    %rbp,%r12
  7c99f5:	cmp    %edx,0x4(%r15,%r12,8)
  7c99fa:	cmovb  %rbp,%r8
  7c99fe:	sub    %r13,%r11
  7c9a01:	cmp    $0x1,%r11
  7c9a05:	ja     7c99e0 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x120>
  7c9a07:	lea    (%r8,%r8,2),%r11
  7c9a0b:	cmp    %edx,0x4(%r15,%r11,8)
  7c9a10:	adc    $0x0,%r8
  7c9a14:	lea    -0x1(%rcx),%r11
  7c9a18:	cmp    %r8,%r11
  7c9a1b:	cmovb  %r11,%r8
  7c9a1f:	lea    (%rax,%rax,2),%r12
  7c9a23:	cmp    %rcx,%r8
  7c9a26:	jae    7c9bc4 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x304>
  7c9a2c:	mov    -0xc(%r10,%r14,1),%ecx
  7c9a31:	mov    0x4(%r15,%r12,8),%r11d
  7c9a36:	lea    (%r8,%r8,2),%r8
  7c9a3a:	lea    (%r15,%r8,8),%r8
  7c9a3e:	movss  -0x8(%r9,%rbx,1),%xmm1
  7c9a45:	movss  -0x8(%r10,%r14,1),%xmm2
  7c9a4c:	cmp    %r11d,%ecx
  7c9a4f:	ja     7c9a6d <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x1ad>
  7c9a51:	ucomiss %xmm2,%xmm1
  7c9a54:	jne    7c9a58 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x198>
  7c9a56:	jnp    7c9a6d <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x1ad>
  7c9a58:	ucomiss %xmm1,%xmm2
  7c9a5b:	setbe  %sil
  7c9a5f:	jmp    7c9b1a <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x25a>
  7c9a64:	movb   $0x2,0x4(%rdi)
  7c9a68:	jmp    7c9b89 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x2c9>
  7c9a6d:	mov    0x8(%rsi),%r9
  7c9a71:	mov    0x10(%rsi),%rsi
  7c9a75:	mov    %rsi,%r10
  7c9a78:	test   %rsi,%rsi
  7c9a7b:	je     7c9ac3 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x203>
  7c9a7d:	xor    %r10d,%r10d
  7c9a80:	cmp    $0x1,%rsi
  7c9a84:	je     7c9ab3 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x1f3>
  7c9a86:	mov    %rsi,%rbx
  7c9a89:	nopl   0x0(%rax)
  7c9a90:	mov    %rbx,%r14
  7c9a93:	shr    $1,%r14
  7c9a96:	lea    (%r14,%r10,1),%r15
  7c9a9a:	lea    (%r15,%r15,2),%r12
  7c9a9e:	mov    0x10(%r9,%r12,8),%r12d
  7c9aa3:	cmp    %r12,%rax
  7c9aa6:	cmova  %r15,%r10
  7c9aaa:	sub    %r14,%rbx
  7c9aad:	cmp    $0x1,%rbx
  7c9ab1:	ja     7c9a90 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x1d0>
  7c9ab3:	lea    (%r10,%r10,2),%rbx
  7c9ab7:	mov    0x10(%r9,%rbx,8),%ebx
  7c9abc:	cmp    %rax,%rbx
  7c9abf:	adc    $0x0,%r10
  7c9ac3:	shl    $0x3,%r10
  7c9ac7:	lea    (%r10,%r10,2),%r10
  7c9acb:	lea    (%r9,%r10,1),%rbx
  7c9acf:	shl    $0x3,%rsi
  7c9ad3:	lea    (%rsi,%rsi,2),%rsi
  7c9ad7:	nopw   0x0(%rax,%rax,1)
  7c9ae0:	cmp    %r10,%rsi
  7c9ae3:	je     7c9b98 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x2d8>
  7c9ae9:	mov    %rbx,%r14
  7c9aec:	mov    0x10(%rbx),%ebx
  7c9aef:	cmp    %rbx,%rax
  7c9af2:	jne    7c9b98 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x2d8>
  7c9af8:	lea    0x18(%r14),%rbx
  7c9afc:	add    $0x18,%r10
  7c9b00:	cmp    %edx,(%r14)
  7c9b03:	ja     7c9ae0 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x220>
  7c9b05:	cmp    0x4(%r14),%edx
  7c9b09:	ja     7c9ae0 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x220>
  7c9b0b:	movzbl -0x3(%r9,%r10,1),%esi
  7c9b11:	cmp    %r11d,%ecx
  7c9b14:	ja     7c9ba3 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x2e3>
  7c9b1a:	movaps %xmm1,%xmm0
  7c9b1d:	minss  %xmm2,%xmm0
  7c9b21:	movaps %xmm0,%xmm3
  7c9b24:	cmpunordss %xmm0,%xmm3
  7c9b29:	movaps %xmm3,%xmm4
  7c9b2c:	andnps %xmm0,%xmm4
  7c9b2f:	andps  %xmm1,%xmm3
  7c9b32:	orps   %xmm4,%xmm3
  7c9b35:	movaps %xmm2,%xmm0
  7c9b38:	subss  %xmm1,%xmm0
  7c9b3c:	andps  -0x706663(%rip),%xmm0        # c34e0 <GCC_except_table0+0x10d8>
  7c9b43:	cmp    %r11d,%ecx
  7c9b46:	movss  0x8(%r8),%xmm4
  7c9b4c:	movss  0xc(%r8),%xmm5
  7c9b52:	mov    %edx,(%rdi)
  7c9b54:	movb   $0x1,0x4(%rdi)
  7c9b58:	mov    %ecx,0x8(%rdi)
  7c9b5b:	movb   $0x0,0xc(%rdi)
  7c9b5f:	movss  %xmm3,0x10(%rdi)
  7c9b64:	movss  %xmm4,0x14(%rdi)
  7c9b69:	movss  %xmm0,0x18(%rdi)
  7c9b6e:	movss  %xmm5,0x1c(%rdi)
  7c9b73:	mov    %rax,0x20(%rdi)
  7c9b77:	movss  %xmm1,0x28(%rdi)
  7c9b7c:	movss  %xmm2,0x2c(%rdi)
  7c9b81:	seta   0x30(%rdi)
  7c9b85:	mov    %sil,0x31(%rdi)
  7c9b89:	add    $0x8,%rsp
  7c9b8d:	pop    %rbx
  7c9b8e:	pop    %r12
  7c9b90:	pop    %r13
  7c9b92:	pop    %r14
  7c9b94:	pop    %r15
  7c9b96:	pop    %rbp
  7c9b97:	ret
  7c9b98:	xor    %esi,%esi
  7c9b9a:	cmp    %r11d,%ecx
  7c9b9d:	jbe    7c9b1a <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x25a>
  7c9ba3:	movaps %xmm1,%xmm3
  7c9ba6:	test   %sil,%sil
  7c9ba9:	je     7c9b43 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x283>
  7c9bab:	subss  %xmm0,%xmm3
  7c9baf:	jmp    7c9b43 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_+0x283>
  7c9bb1:	lea    0x2d41b0(%rip),%rdx        # a9dd68 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0xf00>
  7c9bb8:	mov    %rax,%rdi
  7c9bbb:	mov    %rcx,%rsi
  7c9bbe:	call   *0x2f06ec(%rip)        # aba2b0 <_DYNAMIC+0x270>
  7c9bc4:	lea    0x2d41b5(%rip),%rdx        # a9dd80 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0xf18>
  7c9bcb:	mov    %r8,%rdi
  7c9bce:	mov    %rcx,%rsi
  7c9bd1:	call   *0x2f06d9(%rip)        # aba2b0 <_DYNAMIC+0x270>

<gpui_canvas::text::layout::TextGeometry>::grapheme_at bytes=850 frame=376

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007d59c0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at>:
  7d59c0:	push   %rbp
  7d59c1:	push   %r15
  7d59c3:	push   %r14
  7d59c5:	push   %r13
  7d59c7:	push   %r12
  7d59c9:	push   %rbx
  7d59ca:	sub    $0x148,%rsp
  7d59d1:	mov    %rdi,%rbx
  7d59d4:	movd   %xmm1,%eax
  7d59d8:	movd   %xmm0,0x4(%rsp)
  7d59de:	movd   %xmm0,%ecx
  7d59e2:	and    $0x7fffffff,%ecx
  7d59e8:	cmp    $0x7f800000,%ecx
  7d59ee:	setge  %cl
  7d59f1:	and    $0x7fffffff,%eax
  7d59f6:	cmp    $0x7f800000,%eax
  7d59fb:	setge  %al
  7d59fe:	or     %cl,%al
  7d5a00:	cmp    $0x1,%al
  7d5a02:	jne    7d5a0d <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x4d>
  7d5a04:	movb   $0x2,0x4(%rbx)
  7d5a08:	jmp    7d5cdd <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x31d>
  7d5a0d:	mov    0x20(%rsi),%rdx
  7d5a11:	mov    0x28(%rsi),%rax
  7d5a15:	mov    %rax,%r14
  7d5a18:	test   %rax,%rax
  7d5a1b:	je     7d5a6e <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0xae>
  7d5a1d:	xor    %ecx,%ecx
  7d5a1f:	cmp    $0x1,%rax
  7d5a23:	je     7d5a53 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x93>
  7d5a25:	mov    %rax,%rdi
  7d5a28:	nopl   0x0(%rax,%rax,1)
  7d5a30:	mov    %rcx,%r8
  7d5a33:	mov    %rdi,%r9
  7d5a36:	shr    $1,%r9
  7d5a39:	add    %r9,%rcx
  7d5a3c:	lea    (%rcx,%rcx,2),%r10
  7d5a40:	ucomiss 0x8(%rdx,%r10,8),%xmm1
  7d5a46:	cmovb  %r8,%rcx
  7d5a4a:	sub    %r9,%rdi
  7d5a4d:	cmp    $0x1,%rdi
  7d5a51:	ja     7d5a30 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x70>
  7d5a53:	lea    (%rcx,%rcx,2),%rdi
  7d5a57:	xor    %r14d,%r14d
  7d5a5a:	ucomiss 0x8(%rdx,%rdi,8),%xmm1
  7d5a5f:	setae  %r14b
  7d5a63:	add    %rcx,%r14
  7d5a66:	cmp    $0x1,%r14
  7d5a6a:	adc    $0xffffffffffffffff,%r14
  7d5a6e:	mov    %r14,0x8(%rsp)
  7d5a73:	xor    %ecx,%ecx
  7d5a75:	cmpq   $0xffffffffffffffff,0x30(%rsi)
  7d5a7a:	mov    0x40(%rsi),%r8
  7d5a7e:	cmovne %r8,%rcx
  7d5a82:	mov    $0x4,%edi
  7d5a87:	cmovne 0x38(%rsi),%rdi
  7d5a8c:	cmp    %rax,%r14
  7d5a8f:	jae    7d5cff <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x33f>
  7d5a95:	lea    (%r14,%r14,2),%rax
  7d5a99:	mov    (%rdx,%rax,8),%edx
  7d5a9c:	test   %edx,%edx
  7d5a9e:	je     7d5add <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x11d>
  7d5aa0:	mov    %rcx,%rax
  7d5aa3:	test   %rcx,%rcx
  7d5aa6:	je     7d5adf <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x11f>
  7d5aa8:	xor    %eax,%eax
  7d5aaa:	cmp    $0x1,%rcx
  7d5aae:	je     7d5acf <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x10f>
  7d5ab0:	mov    %r8,%r9
  7d5ab3:	shr    $1,%r9
  7d5ab6:	lea    (%r9,%rax,1),%r10
  7d5aba:	lea    (%r10,%r10,2),%r11
  7d5abe:	cmp    %edx,(%rdi,%r11,4)
  7d5ac2:	cmovb  %r10,%rax
  7d5ac6:	sub    %r9,%r8
  7d5ac9:	cmp    $0x1,%r8
  7d5acd:	ja     7d5ab0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0xf0>
  7d5acf:	lea    (%rax,%rax,2),%r8
  7d5ad3:	cmp    %edx,(%rdi,%r8,4)
  7d5ad7:	adc    $0x0,%rax
  7d5adb:	jmp    7d5adf <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x11f>
  7d5add:	xor    %eax,%eax
  7d5adf:	movss  %xmm1,(%rsp)
  7d5ae4:	sub    %rax,%rcx
  7d5ae7:	lea    (%rax,%rax,2),%rax
  7d5aeb:	lea    (%rdi,%rax,4),%rax
  7d5aef:	movss  0x4c(%rsi),%xmm0
  7d5af4:	mulss  -0x7135e4(%rip),%xmm0        # c2518 <GCC_except_table0+0x110>
  7d5afc:	xorps  %xmm1,%xmm1
  7d5aff:	movups %xmm1,0x38(%rsp)
  7d5b04:	mov    %rax,0x10(%rsp)
  7d5b09:	mov    %rcx,0x18(%rsp)
  7d5b0e:	mov    %rax,0x20(%rsp)
  7d5b13:	mov    %rcx,0x28(%rsp)
  7d5b18:	movq   $0x1,0x30(%rsp)
  7d5b21:	mov    %rsi,0x48(%rsp)
  7d5b26:	movss  %xmm0,0x50(%rsp)
  7d5b2c:	movb   $0x0,0x68(%rsp)
  7d5b31:	mov    %rsi,0x58(%rsp)
  7d5b36:	lea    0x8(%rsp),%rax
  7d5b3b:	mov    %rax,0x60(%rsp)
  7d5b40:	lea    0xf0(%rsp),%rdi
  7d5b48:	lea    0x10(%rsp),%rsi
  7d5b4d:	call   7e82d0 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextB1u_>
  7d5b52:	cmpq   $0x0,0xf0(%rsp)
  7d5b5b:	je     7d5cd8 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x318>
  7d5b61:	lea    0x110(%rsp),%r12
  7d5b69:	lea    0xf0(%rsp),%r13
  7d5b71:	lea    0x10(%rsp),%rbp
  7d5b76:	jmp    7d5b9a <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x1da>
  7d5b78:	nopl   0x0(%rax,%rax,1)
  7d5b80:	mov    %r13,%rdi
  7d5b83:	mov    %rbp,%rsi
  7d5b86:	call   7e82d0 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextB1u_>
  7d5b8b:	cmpq   $0x0,0xf0(%rsp)
  7d5b94:	je     7d5cd8 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x318>
  7d5b9a:	mov    0x48(%rsp),%rsi
  7d5b9f:	movss  0x50(%rsp),%xmm0
  7d5ba5:	mov    %r12,%rdi
  7d5ba8:	mov    %r13,%rdx
  7d5bab:	call   7c98c0 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_>
  7d5bb0:	cmpb   $0x2,0x114(%rsp)
  7d5bb8:	je     7d5b80 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x1c0>
  7d5bba:	mov    0x140(%rsp),%rax
  7d5bc2:	mov    %rax,0xe0(%rsp)
  7d5bca:	movups 0x110(%rsp),%xmm0
  7d5bd2:	movups 0x120(%rsp),%xmm1
  7d5bda:	movups 0x130(%rsp),%xmm2
  7d5be2:	movaps %xmm2,0xd0(%rsp)
  7d5bea:	movaps %xmm1,0xc0(%rsp)
  7d5bf2:	movaps %xmm0,0xb0(%rsp)
  7d5bfa:	mov    0x58(%rsp),%rax
  7d5bff:	mov    0x60(%rsp),%rcx
  7d5c04:	mov    (%rcx),%rdi
  7d5c07:	mov    0x28(%rax),%rsi
  7d5c0b:	cmp    %rsi,%rdi
  7d5c0e:	jae    7d5cf2 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x332>
  7d5c14:	mov    0xb0(%rsp),%r15d
  7d5c1c:	mov    0x20(%rax),%rax
  7d5c20:	lea    (%rdi,%rdi,2),%rcx
  7d5c24:	cmp    0x4(%rax,%rcx,8),%r15d
  7d5c29:	ja     7d5cd8 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x318>
  7d5c2f:	cmp    %r14,0xd0(%rsp)
  7d5c37:	jne    7d5b80 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x1c0>
  7d5c3d:	lea    0xc0(%rsp),%rdi
  7d5c45:	movss  0x4(%rsp),%xmm0
  7d5c4b:	movss  (%rsp),%xmm1
  7d5c50:	call   *0x2e4a82(%rip)        # aba6d8 <_DYNAMIC+0x698>
  7d5c56:	test   %al,%al
  7d5c58:	je     7d5b80 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x1c0>
  7d5c5e:	movzbl 0xb4(%rsp),%eax
  7d5c66:	cmp    $0x2,%al
  7d5c68:	je     7d5b80 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x1c0>
  7d5c6e:	lea    0x115(%rsp),%rdx
  7d5c76:	mov    0x2f(%rdx),%ecx
  7d5c79:	mov    %ecx,0x9f(%rsp)
  7d5c80:	movups (%rdx),%xmm0
  7d5c83:	movups 0x10(%rdx),%xmm1
  7d5c87:	movups 0x20(%rdx),%xmm2
  7d5c8b:	movaps %xmm2,0x90(%rsp)
  7d5c93:	movaps %xmm1,0x80(%rsp)
  7d5c9b:	movaps %xmm0,0x70(%rsp)
  7d5ca0:	cmp    $0xff,%al
  7d5ca2:	je     7d5b80 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x1c0>
  7d5ca8:	mov    0x9f(%rsp),%ecx
  7d5caf:	mov    %ecx,0x34(%rbx)
  7d5cb2:	movaps 0x70(%rsp),%xmm0
  7d5cb7:	movaps 0x80(%rsp),%xmm1
  7d5cbf:	movaps 0x90(%rsp),%xmm2
  7d5cc7:	movups %xmm2,0x25(%rbx)
  7d5ccb:	movups %xmm1,0x15(%rbx)
  7d5ccf:	movups %xmm0,0x5(%rbx)
  7d5cd3:	mov    %r15d,(%rbx)
  7d5cd6:	jmp    7d5cda <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11grapheme_at+0x31a>
  7d5cd8:	mov    $0x2,%al
  7d5cda:	mov    %al,0x4(%rbx)
  7d5cdd:	mov    %rbx,%rax
  7d5ce0:	add    $0x148,%rsp
  7d5ce7:	pop    %rbx
  7d5ce8:	pop    %r12
  7d5cea:	pop    %r13
  7d5cec:	pop    %r14
  7d5cee:	pop    %r15
  7d5cf0:	pop    %rbp
  7d5cf1:	ret
  7d5cf2:	lea    0x2c7fdf(%rip),%rdx        # a9dcd8 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0xe70>
  7d5cf9:	call   *0x2e45b1(%rip)        # aba2b0 <_DYNAMIC+0x270>
  7d5cff:	lea    0x2c890a(%rip),%rdx        # a9e610 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0x17a8>
  7d5d06:	mov    %r14,%rdi
  7d5d09:	mov    %rax,%rsi
  7d5d0c:	call   *0x2e459e(%rip)        # aba2b0 <_DYNAMIC+0x270>

<gpui_canvas::text::layout::TextGeometry>::move_visual bytes=1691 frame=328

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007d5d20 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual>:
  7d5d20:	push   %rbp
  7d5d21:	push   %r15
  7d5d23:	push   %r14
  7d5d25:	push   %r13
  7d5d27:	push   %r12
  7d5d29:	push   %rbx
  7d5d2a:	sub    $0x118,%rsp
  7d5d31:	mov    %ecx,%r15d
  7d5d34:	mov    %edx,%r14d
  7d5d37:	mov    %esi,%ebp
  7d5d39:	mov    %rdi,%rbx
  7d5d3c:	lea    0x48(%rsp),%rdi
  7d5d41:	mov    %rbx,%rsi
  7d5d44:	mov    %ebp,%edx
  7d5d46:	mov    %r14d,%ecx
  7d5d49:	call   *0x2e4e99(%rip)        # ababe8 <_DYNAMIC+0xba8>
  7d5d4f:	cmpl   $0x1,0x48(%rsp)
  7d5d54:	jne    7d5dcb <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0xab>
  7d5d56:	test   %ebp,%ebp
  7d5d58:	setne  %cl
  7d5d5b:	mov    %r14d,%edx
  7d5d5e:	not    %dl
  7d5d60:	mov    0x20(%rbx),%rax
  7d5d64:	mov    0x28(%rbx),%r11
  7d5d68:	mov    %r11,%rdi
  7d5d6b:	test   %cl,%dl
  7d5d6d:	jne    7d5dd2 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0xb2>
  7d5d6f:	test   %r11,%r11
  7d5d72:	je     7d5e27 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x107>
  7d5d78:	xor    %ecx,%ecx
  7d5d7a:	cmp    $0x1,%r11
  7d5d7e:	je     7d5db1 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x91>
  7d5d80:	mov    %r11,%rdx
  7d5d83:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  7d5d90:	mov    %rcx,%rsi
  7d5d93:	mov    %rdx,%rdi
  7d5d96:	shr    $1,%rdi
  7d5d99:	add    %rdi,%rcx
  7d5d9c:	lea    (%rcx,%rcx,2),%r8
  7d5da0:	cmp    %ebp,(%rax,%r8,8)
  7d5da4:	cmova  %rsi,%rcx
  7d5da8:	sub    %rdi,%rdx
  7d5dab:	cmp    $0x1,%rdx
  7d5daf:	ja     7d5d90 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x70>
  7d5db1:	lea    (%rcx,%rcx,2),%rdx
  7d5db5:	xor    %edi,%edi
  7d5db7:	cmp    %ebp,(%rax,%rdx,8)
  7d5dba:	setbe  %dil
  7d5dbe:	add    %rcx,%rdi
  7d5dc1:	cmp    $0x1,%rdi
  7d5dc5:	adc    $0xffffffffffffffff,%rdi
  7d5dc9:	jmp    7d5e27 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x107>
  7d5dcb:	mov    $0x2,%dl
  7d5dcd:	jmp    7d638a <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x66a>
  7d5dd2:	test   %r11,%r11
  7d5dd5:	je     7d5e1c <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0xfc>
  7d5dd7:	xor    %edi,%edi
  7d5dd9:	cmp    $0x1,%r11
  7d5ddd:	je     7d5e10 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0xf0>
  7d5ddf:	mov    %r11,%rcx
  7d5de2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  7d5df0:	mov    %rcx,%rdx
  7d5df3:	shr    $1,%rdx
  7d5df6:	lea    (%rdx,%rdi,1),%rsi
  7d5dfa:	lea    (%rsi,%rsi,2),%r8
  7d5dfe:	cmp    %ebp,0x4(%rax,%r8,8)
  7d5e03:	cmovb  %rsi,%rdi
  7d5e07:	sub    %rdx,%rcx
  7d5e0a:	cmp    $0x1,%rcx
  7d5e0e:	ja     7d5df0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0xd0>
  7d5e10:	lea    (%rdi,%rdi,2),%rcx
  7d5e14:	cmp    %ebp,0x4(%rax,%rcx,8)
  7d5e18:	adc    $0x0,%rdi
  7d5e1c:	lea    -0x1(%r11),%rcx
  7d5e20:	cmp    %rdi,%rcx
  7d5e23:	cmovb  %rcx,%rdi
  7d5e27:	movss  0x4c(%rsp),%xmm0
  7d5e2d:	movss  %xmm0,0x18(%rsp)
  7d5e33:	mov    %rdi,0x38(%rsp)
  7d5e38:	xor    %ecx,%ecx
  7d5e3a:	cmpq   $0xffffffffffffffff,0x30(%rbx)
  7d5e3f:	mov    0x40(%rbx),%rsi
  7d5e43:	cmovne %rsi,%rcx
  7d5e47:	mov    $0x4,%edx
  7d5e4c:	cmovne 0x38(%rbx),%rdx
  7d5e51:	cmp    %r11,%rdi
  7d5e54:	jae    7d63ab <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x68b>
  7d5e5a:	lea    (%rdi,%rdi,2),%rdi
  7d5e5e:	mov    (%rax,%rdi,8),%edi
  7d5e61:	test   %edi,%edi
  7d5e63:	mov    %r15d,0x20(%rsp)
  7d5e68:	je     7d5eac <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x18c>
  7d5e6a:	mov    %rcx,%rax
  7d5e6d:	test   %rcx,%rcx
  7d5e70:	je     7d5eae <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x18e>
  7d5e72:	xor    %eax,%eax
  7d5e74:	cmp    $0x1,%rcx
  7d5e78:	je     7d5e9f <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x17f>
  7d5e7a:	nopw   0x0(%rax,%rax,1)
  7d5e80:	mov    %rsi,%r8
  7d5e83:	shr    $1,%r8
  7d5e86:	lea    (%r8,%rax,1),%r9
  7d5e8a:	lea    (%r9,%r9,2),%r10
  7d5e8e:	cmp    %edi,(%rdx,%r10,4)
  7d5e92:	cmovb  %r9,%rax
  7d5e96:	sub    %r8,%rsi
  7d5e99:	cmp    $0x1,%rsi
  7d5e9d:	ja     7d5e80 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x160>
  7d5e9f:	lea    (%rax,%rax,2),%rsi
  7d5ea3:	cmp    %edi,(%rdx,%rsi,4)
  7d5ea6:	adc    $0x0,%rax
  7d5eaa:	jmp    7d5eae <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x18e>
  7d5eac:	xor    %eax,%eax
  7d5eae:	sub    %rax,%rcx
  7d5eb1:	lea    (%rax,%rax,2),%rax
  7d5eb5:	lea    (%rdx,%rax,4),%rax
  7d5eb9:	movss  0x4c(%rbx),%xmm0
  7d5ebe:	mulss  -0x7139ae(%rip),%xmm0        # c2518 <GCC_except_table0+0x110>
  7d5ec6:	xorps  %xmm1,%xmm1
  7d5ec9:	movups %xmm1,0x78(%rsp)
  7d5ece:	lea    0x38(%rsp),%rdx
  7d5ed3:	mov    %rdx,0x48(%rsp)
  7d5ed8:	lea    0x50(%rsp),%rsi
  7d5edd:	mov    %rax,0x50(%rsp)
  7d5ee2:	mov    %rcx,0x58(%rsp)
  7d5ee7:	mov    %rax,0x60(%rsp)
  7d5eec:	mov    %rcx,0x68(%rsp)
  7d5ef1:	movq   $0x1,0x70(%rsp)
  7d5efa:	mov    %rbx,0x88(%rsp)
  7d5f02:	movss  %xmm0,0x90(%rsp)
  7d5f0b:	mov    %rbx,0x98(%rsp)
  7d5f13:	mov    %rdx,0xa0(%rsp)
  7d5f1b:	movb   $0x0,0xa8(%rsp)
  7d5f23:	movss  -0x71397b(%rip),%xmm0        # c25b0 <GCC_except_table0+0x1a8>
  7d5f2b:	movss  %xmm0,0x1c(%rsp)
  7d5f31:	mov    $0x2,%al
  7d5f33:	mov    %eax,0x24(%rsp)
  7d5f37:	lea    0xc0(%rsp),%rdi
  7d5f3f:	mov    %rbx,0x30(%rsp)
  7d5f44:	mov    %ebp,0x14(%rsp)
  7d5f48:	mov    %r14d,0x10(%rsp)
  7d5f4d:	mov    %r11,0x28(%rsp)
  7d5f52:	call   7e82d0 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextB1u_>
  7d5f57:	cmpq   $0x0,0xc0(%rsp)
  7d5f60:	je     7d62eb <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x5cb>
  7d5f66:	mov    0x88(%rsp),%rax
  7d5f6e:	mov    %rax,0xb8(%rsp)
  7d5f76:	movss  0x90(%rsp),%xmm0
  7d5f7f:	movss  %xmm0,0x44(%rsp)
  7d5f85:	mov    0x50(%rsp),%r14
  7d5f8a:	mov    0x58(%rsp),%r13
  7d5f8f:	mov    0x70(%rsp),%r12
  7d5f94:	mov    0x60(%rsp),%rbp
  7d5f99:	mov    0x98(%rsp),%r15
  7d5fa1:	mov    0xa0(%rsp),%rax
  7d5fa9:	mov    %rax,0xb0(%rsp)
  7d5fb1:	mov    0x68(%rsp),%rbx
  7d5fb6:	cs nopw 0x0(%rax,%rax,1)
  7d5fc0:	lea    0xe0(%rsp),%rdi
  7d5fc8:	mov    0xb8(%rsp),%rsi
  7d5fd0:	movss  0x44(%rsp),%xmm0
  7d5fd6:	lea    0xc0(%rsp),%rdx
  7d5fde:	call   7c98c0 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_>
  7d5fe3:	movzbl 0xe4(%rsp),%eax
  7d5feb:	cmp    $0x2,%al
  7d5fed:	je     7d603d <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x31d>
  7d5fef:	mov    0xb0(%rsp),%rcx
  7d5ff7:	mov    (%rcx),%rdi
  7d5ffa:	mov    0x28(%r15),%rsi
  7d5ffe:	cmp    %rsi,%rdi
  7d6001:	jae    7d639e <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x67e>
  7d6007:	mov    0xe0(%rsp),%ecx
  7d600e:	mov    0x20(%r15),%rdx
  7d6012:	lea    (%rdi,%rdi,2),%rsi
  7d6016:	cmp    0x4(%rdx,%rsi,8),%ecx
  7d601a:	ja     7d62eb <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x5cb>
  7d6020:	mov    0x100(%rsp),%rdx
  7d6028:	cmp    0x38(%rsp),%rdx
  7d602d:	jne    7d603d <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x31d>
  7d602f:	testb  $0x1,0x110(%rsp)
  7d6037:	je     7d620d <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x4ed>
  7d603d:	mov    %r13,%rax
  7d6040:	cmp    $0x1,%r13
  7d6044:	je     7d6074 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x354>
  7d6046:	test   %r13,%r13
  7d6049:	je     7d62eb <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x5cb>
  7d604f:	mov    (%r14),%ecx
  7d6052:	lea    0xc(%r14),%rdx
  7d6056:	lea    0x1(%r13),%rsi
  7d605a:	mov    $0x1,%eax
  7d605f:	nop
  7d6060:	cmp    (%rdx),%ecx
  7d6062:	jne    7d6074 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x354>
  7d6064:	inc    %rax
  7d6067:	add    $0xc,%rdx
  7d606b:	dec    %rsi
  7d606e:	cmp    $0x2,%rsi
  7d6072:	ja     7d6060 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x340>
  7d6074:	sub    %rax,%r13
  7d6077:	jb     7d6368 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x648>
  7d607d:	lea    (%rax,%rax,2),%rcx
  7d6081:	lea    (%r14,%rcx,4),%rcx
  7d6085:	mov    %rcx,0x50(%rsp)
  7d608a:	mov    %r13,0x58(%rsp)
  7d608f:	test   %r12,%r12
  7d6092:	jne    7d6139 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x419>
  7d6098:	mov    %rbx,%rdx
  7d609b:	cmp    $0x1,%rbx
  7d609f:	je     7d60d4 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x3b4>
  7d60a1:	test   %rbx,%rbx
  7d60a4:	je     7d62eb <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x5cb>
  7d60aa:	mov    0x0(%rbp),%esi
  7d60ad:	lea    0xc(%rbp),%rdi
  7d60b1:	lea    0x1(%rbx),%r8
  7d60b5:	mov    $0x1,%edx
  7d60ba:	nopw   0x0(%rax,%rax,1)
  7d60c0:	cmp    (%rdi),%esi
  7d60c2:	jne    7d60d4 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x3b4>
  7d60c4:	inc    %rdx
  7d60c7:	add    $0xc,%rdi
  7d60cb:	dec    %r8
  7d60ce:	cmp    $0x2,%r8
  7d60d2:	ja     7d60c0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x3a0>
  7d60d4:	sub    %rdx,%rbx
  7d60d7:	jb     7d6368 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x648>
  7d60dd:	lea    (%rdx,%rdx,2),%rsi
  7d60e1:	lea    0x0(,%rsi,4),%rsi
  7d60e9:	add    %rbp,%rsi
  7d60ec:	mov    %rsi,0x60(%rsp)
  7d60f1:	mov    %rbx,0x68(%rsp)
  7d60f6:	test   %rbp,%rbp
  7d60f9:	je     7d62eb <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x5cb>
  7d60ff:	mov    %r14,0xc0(%rsp)
  7d6107:	mov    %rax,0xc8(%rsp)
  7d610f:	mov    %rbp,0xd0(%rsp)
  7d6117:	mov    %rdx,0xd8(%rsp)
  7d611f:	mov    %rsi,%rbp
  7d6122:	mov    $0x0,%r12d
  7d6128:	test   %r14,%r14
  7d612b:	mov    %rcx,%r14
  7d612e:	jne    7d5fc0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x2a0>
  7d6134:	jmp    7d62eb <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x5cb>
  7d6139:	movq   $0x0,0x70(%rsp)
  7d6142:	mov    %rbp,%rdi
  7d6145:	mov    %rbx,%rsi
  7d6148:	mov    %rbx,%r8
  7d614b:	cmp    $0x1,%rbx
  7d614f:	je     7d6185 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x465>
  7d6151:	test   %rsi,%rsi
  7d6154:	je     7d62eb <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x5cb>
  7d615a:	mov    (%rdi),%edx
  7d615c:	lea    0xc(%rdi),%r9
  7d6160:	lea    0x1(%rsi),%r10
  7d6164:	mov    $0x1,%r8d
  7d616a:	nopw   0x0(%rax,%rax,1)
  7d6170:	cmp    (%r9),%edx
  7d6173:	jne    7d6185 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x465>
  7d6175:	inc    %r8
  7d6178:	add    $0xc,%r9
  7d617c:	dec    %r10
  7d617f:	cmp    $0x2,%r10
  7d6183:	ja     7d6170 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x450>
  7d6185:	mov    %rsi,%rbx
  7d6188:	sub    %r8,%rbx
  7d618b:	jb     7d6368 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x648>
  7d6191:	lea    (%r8,%r8,2),%r10
  7d6195:	lea    (%rdi,%r10,4),%rbp
  7d6199:	dec    %r12
  7d619c:	jne    7d6142 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x422>
  7d619e:	mov    %rbp,0x60(%rsp)
  7d61a3:	mov    %rbx,0x68(%rsp)
  7d61a8:	mov    %rbx,%rdx
  7d61ab:	cmp    $0x1,%rbx
  7d61af:	je     7d61e6 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x4c6>
  7d61b1:	test   %rbx,%rbx
  7d61b4:	je     7d62eb <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x5cb>
  7d61ba:	mov    0x0(%rbp),%r9d
  7d61be:	lea    (%rdi,%r10,4),%rdi
  7d61c2:	add    $0xc,%rdi
  7d61c6:	sub    %r8,%rsi
  7d61c9:	inc    %rsi
  7d61cc:	mov    $0x1,%edx
  7d61d1:	cmp    (%rdi),%r9d
  7d61d4:	jne    7d61e6 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x4c6>
  7d61d6:	inc    %rdx
  7d61d9:	add    $0xc,%rdi
  7d61dd:	dec    %rsi
  7d61e0:	cmp    $0x2,%rsi
  7d61e4:	ja     7d61d1 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x4b1>
  7d61e6:	sub    %rdx,%rbx
  7d61e9:	jb     7d6368 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x648>
  7d61ef:	lea    (%rdx,%rdx,2),%rsi
  7d61f3:	lea    0x0(,%rsi,4),%rsi
  7d61fb:	add    %rbp,%rsi
  7d61fe:	mov    %rsi,0x60(%rsp)
  7d6203:	mov    %rbx,0x68(%rsp)
  7d6208:	jmp    7d60ff <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x3df>
  7d620d:	mov    0x108(%rsp),%rdx
  7d6215:	movd   %edx,%xmm0
  7d6219:	shr    $0x20,%rdx
  7d621d:	movd   %edx,%xmm1
  7d6221:	mov    0x20(%rsp),%esi
  7d6225:	test   %sil,%sil
  7d6228:	je     7d624d <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x52d>
  7d622a:	movaps %xmm0,%xmm3
  7d622d:	maxss  %xmm1,%xmm3
  7d6231:	movaps %xmm3,%xmm2
  7d6234:	cmpunordss %xmm3,%xmm2
  7d6239:	movaps %xmm2,%xmm4
  7d623c:	andnps %xmm3,%xmm4
  7d623f:	andps  %xmm0,%xmm2
  7d6242:	orps   %xmm4,%xmm2
  7d6245:	subss  0x18(%rsp),%xmm2
  7d624b:	jmp    7d6273 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x553>
  7d624d:	movdqa %xmm0,%xmm2
  7d6251:	minss  %xmm1,%xmm2
  7d6255:	movaps %xmm2,%xmm3
  7d6258:	cmpunordss %xmm2,%xmm3
  7d625d:	movaps %xmm3,%xmm4
  7d6260:	andnps %xmm2,%xmm4
  7d6263:	andps  %xmm0,%xmm3
  7d6266:	orps   %xmm4,%xmm3
  7d6269:	movss  0x18(%rsp),%xmm2
  7d626f:	subss  %xmm3,%xmm2
  7d6273:	mov    0x30(%rsp),%rbx
  7d6278:	mov    0x14(%rsp),%ebp
  7d627c:	mov    0x10(%rsp),%r14d
  7d6281:	mov    0x28(%rsp),%r11
  7d6286:	mov    0xc(%rsp),%edx
  7d628a:	xorps  %xmm3,%xmm3
  7d628d:	ucomiss %xmm3,%xmm2
  7d6290:	jbe    7d62ca <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x5aa>
  7d6292:	movss  0x1c(%rsp),%xmm3
  7d6298:	ucomiss %xmm2,%xmm3
  7d629b:	jbe    7d62ca <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x5aa>
  7d629d:	ucomiss %xmm0,%xmm1
  7d62a0:	setbe  %dl
  7d62a3:	xor    %sil,%dl
  7d62a6:	cmovne 0xe8(%rsp),%ecx
  7d62ae:	movzbl 0xec(%rsp),%edx
  7d62b6:	movzbl %al,%eax
  7d62b9:	cmovne %edx,%eax
  7d62bc:	and    $0x1,%al
  7d62be:	mov    %eax,0x24(%rsp)
  7d62c2:	movss  %xmm2,0x1c(%rsp)
  7d62c8:	mov    %ecx,%edx
  7d62ca:	mov    %edx,0xc(%rsp)
  7d62ce:	cmpb   $0x0,0xa8(%rsp)
  7d62d6:	lea    0x50(%rsp),%rsi
  7d62db:	lea    0xc0(%rsp),%rdi
  7d62e3:	je     7d5f52 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x232>
  7d62e9:	jmp    7d62fe <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x5de>
  7d62eb:	mov    0x30(%rsp),%rbx
  7d62f0:	mov    0x14(%rsp),%ebp
  7d62f4:	mov    0x10(%rsp),%r14d
  7d62f9:	mov    0x28(%rsp),%r11
  7d62fe:	mov    0x24(%rsp),%edx
  7d6302:	cmp    $0x2,%dl
  7d6305:	jne    7d6362 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x642>
  7d6307:	mov    0x38(%rsp),%rsi
  7d630c:	cmpb   $0x0,0x20(%rsp)
  7d6311:	je     7d6332 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x612>
  7d6313:	cmp    $0xffffffffffffffff,%rsi
  7d6317:	je     7d6381 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x661>
  7d6319:	inc    %rsi
  7d631c:	xor    %eax,%eax
  7d631e:	cmp    %r11,%rsi
  7d6321:	setb   %al
  7d6324:	test   $0x1,%al
  7d6326:	je     7d6387 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x667>
  7d6328:	movss  -0x713d54(%rip),%xmm0        # c25dc <GCC_except_table0+0x1d4>
  7d6330:	jmp    7d6356 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x636>
  7d6332:	test   %rsi,%rsi
  7d6335:	je     7d6348 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x628>
  7d6337:	dec    %rsi
  7d633a:	xor    %eax,%eax
  7d633c:	cmp    %r11,%rsi
  7d633f:	setb   %al
  7d6342:	test   $0x1,%al
  7d6344:	jne    7d634e <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x62e>
  7d6346:	jmp    7d6387 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x667>
  7d6348:	xor    %eax,%eax
  7d634a:	test   $0x1,%al
  7d634c:	je     7d6387 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x667>
  7d634e:	movss  -0x713dba(%rip),%xmm0        # c259c <GCC_except_table0+0x194>
  7d6356:	mov    %rbx,%rdi
  7d6359:	call   7d6480 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line>
  7d635e:	mov    %eax,0xc(%rsp)
  7d6362:	mov    0xc(%rsp),%ebp
  7d6366:	jmp    7d638a <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x66a>
  7d6368:	lea    -0x4c4a08(%rip),%rdi        # 311967 <_RNvNtCsghYClfd3M9V_11gpui_canvas4text13PRIMARY_BYTES+0x1f463f>
  7d636f:	lea    0x2c84fa(%rip),%rdx        # a9e870 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0x1a08>
  7d6376:	mov    $0x13,%esi
  7d637b:	call   *0x2e3f37(%rip)        # aba2b8 <_DYNAMIC+0x278>
  7d6381:	xor    %eax,%eax
  7d6383:	test   $0x1,%al
  7d6385:	jne    7d6328 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual+0x608>
  7d6387:	mov    %r14d,%edx
  7d638a:	mov    %ebp,%eax
  7d638c:	add    $0x118,%rsp
  7d6393:	pop    %rbx
  7d6394:	pop    %r12
  7d6396:	pop    %r13
  7d6398:	pop    %r14
  7d639a:	pop    %r15
  7d639c:	pop    %rbp
  7d639d:	ret
  7d639e:	lea    0x2c794b(%rip),%rdx        # a9dcf0 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0xe88>
  7d63a5:	call   *0x2e3f05(%rip)        # aba2b0 <_DYNAMIC+0x270>
  7d63ab:	lea    0x2c825e(%rip),%rdx        # a9e610 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0x17a8>
  7d63b2:	mov    %r11,%rsi
  7d63b5:	call   *0x2e3ef5(%rip)        # aba2b0 <_DYNAMIC+0x270>

<gpui_canvas::text::layout::TextGeometry>::next_visual bytes=10 frame=0

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007d63c0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11next_visual>:
  7d63c0:	mov    $0x1,%ecx
  7d63c5:	jmp    7d5d20 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual>

<gpui_canvas::text::layout::TextGeometry>::position_at bytes=151 frame=8

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007d63d0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11position_at>:
  7d63d0:	movd   %xmm1,%eax
  7d63d4:	movd   %xmm0,%ecx
  7d63d8:	and    $0x7fffffff,%ecx
  7d63de:	cmp    $0x7f800000,%ecx
  7d63e4:	setge  %cl
  7d63e7:	and    $0x7fffffff,%eax
  7d63ec:	cmp    $0x7f800000,%eax
  7d63f1:	setge  %al
  7d63f4:	or     %cl,%al
  7d63f6:	je     7d63fb <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11position_at+0x2b>
  7d63f8:	mov    $0x2,%dl
  7d63fa:	ret
  7d63fb:	push   %rax
  7d63fc:	mov    0x28(%rdi),%rsi
  7d6400:	test   %rsi,%rsi
  7d6403:	je     7d645d <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11position_at+0x8d>
  7d6405:	mov    0x20(%rdi),%rax
  7d6409:	xor    %ecx,%ecx
  7d640b:	cmp    $0x1,%rsi
  7d640f:	je     7d6443 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11position_at+0x73>
  7d6411:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  7d6420:	mov    %rcx,%rdx
  7d6423:	mov    %rsi,%r8
  7d6426:	shr    $1,%r8
  7d6429:	add    %r8,%rcx
  7d642c:	lea    (%rcx,%rcx,2),%r9
  7d6430:	ucomiss 0x8(%rax,%r9,8),%xmm1
  7d6436:	cmovb  %rdx,%rcx
  7d643a:	sub    %r8,%rsi
  7d643d:	cmp    $0x1,%rsi
  7d6441:	ja     7d6420 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11position_at+0x50>
  7d6443:	lea    (%rcx,%rcx,2),%rdx
  7d6447:	xor    %esi,%esi
  7d6449:	ucomiss 0x8(%rax,%rdx,8),%xmm1
  7d644e:	setae  %sil
  7d6452:	add    %rcx,%rsi
  7d6455:	cmp    $0x1,%rsi
  7d6459:	adc    $0xffffffffffffffff,%rsi
  7d645d:	call   7d6480 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line>
  7d6462:	add    $0x8,%rsp
  7d6466:	ret

<gpui_canvas::text::layout::TextGeometry>::previous_visual bytes=7 frame=0

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007d6470 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry15previous_visual>:
  7d6470:	xor    %ecx,%ecx
  7d6472:	jmp    7d5d20 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry11move_visual>

<gpui_canvas::text::layout::TextGeometry>::position_on_line bytes=2185 frame=360

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007d6480 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line>:
  7d6480:	push   %rbp
  7d6481:	push   %r15
  7d6483:	push   %r14
  7d6485:	push   %r13
  7d6487:	push   %r12
  7d6489:	push   %rbx
  7d648a:	sub    $0x138,%rsp
  7d6491:	mov    %rsi,0x28(%rsp)
  7d6496:	cmpq   $0xffffffffffffffff,0x30(%rdi)
  7d649b:	je     7d6528 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0xa8>
  7d64a1:	mov    0x28(%rdi),%rax
  7d64a5:	cmp    %rax,%rsi
  7d64a8:	jae    7d6ce9 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x869>
  7d64ae:	mov    %rax,0xe0(%rsp)
  7d64b6:	mov    0x38(%rdi),%rax
  7d64ba:	mov    0x40(%rdi),%r8
  7d64be:	mov    0x20(%rdi),%rdx
  7d64c2:	lea    (%rsi,%rsi,2),%rcx
  7d64c6:	mov    %rdx,0xd8(%rsp)
  7d64ce:	mov    (%rdx,%rcx,8),%ecx
  7d64d1:	test   %ecx,%ecx
  7d64d3:	mov    %r8,0x38(%rsp)
  7d64d8:	je     7d652f <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0xaf>
  7d64da:	mov    %r8,%r13
  7d64dd:	test   %r8,%r8
  7d64e0:	je     7d6532 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0xb2>
  7d64e2:	xor    %r13d,%r13d
  7d64e5:	cmp    $0x1,%r8
  7d64e9:	je     7d650f <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x8f>
  7d64eb:	mov    %r8,%rdx
  7d64ee:	xchg   %ax,%ax
  7d64f0:	mov    %rdx,%rsi
  7d64f3:	shr    $1,%rsi
  7d64f6:	lea    (%rsi,%r13,1),%r8
  7d64fa:	lea    (%r8,%r8,2),%r9
  7d64fe:	cmp    %ecx,(%rax,%r9,4)
  7d6502:	cmovb  %r8,%r13
  7d6506:	sub    %rsi,%rdx
  7d6509:	cmp    $0x1,%rdx
  7d650d:	ja     7d64f0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x70>
  7d650f:	lea    0x0(,%r13,2),%rdx
  7d6517:	add    %r13,%rdx
  7d651a:	cmp    %ecx,(%rax,%rdx,4)
  7d651d:	adc    $0x0,%r13
  7d6521:	mov    0x38(%rsp),%r8
  7d6526:	jmp    7d6532 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0xb2>
  7d6528:	mov    $0x2,%dl
  7d652a:	jmp    7d6a1b <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x59b>
  7d652f:	xor    %r13d,%r13d
  7d6532:	movss  %xmm0,0x20(%rsp)
  7d6538:	sub    %r13,%r8
  7d653b:	lea    0x0(,%r13,2),%rcx
  7d6543:	add    %r13,%rcx
  7d6546:	movss  0x4c(%rdi),%xmm0
  7d654b:	mulss  -0x71403b(%rip),%xmm0        # c2518 <GCC_except_table0+0x110>
  7d6553:	lea    (%rax,%rcx,4),%rcx
  7d6557:	xorps  %xmm1,%xmm1
  7d655a:	movups %xmm1,0x90(%rsp)
  7d6562:	lea    0x28(%rsp),%rax
  7d6567:	mov    %rax,0x60(%rsp)
  7d656c:	lea    0x68(%rsp),%rsi
  7d6571:	mov    %rcx,0x68(%rsp)
  7d6576:	mov    %r8,0x70(%rsp)
  7d657b:	mov    %rcx,0xd0(%rsp)
  7d6583:	mov    %rcx,0x78(%rsp)
  7d6588:	mov    %r8,0xc8(%rsp)
  7d6590:	mov    %r8,0x80(%rsp)
  7d6598:	movq   $0x1,0x88(%rsp)
  7d65a4:	mov    %rdi,0xa0(%rsp)
  7d65ac:	movss  %xmm0,0xa8(%rsp)
  7d65b5:	mov    %rdi,0xb0(%rsp)
  7d65bd:	mov    %rax,0xb8(%rsp)
  7d65c5:	movb   $0x0,0xc0(%rsp)
  7d65cd:	mov    $0x2,%cl
  7d65cf:	lea    0x40(%rsp),%rdi
  7d65d4:	mov    $0x2,%dl
  7d65d6:	mov    %cl,0xf(%rsp)
  7d65da:	mov    %edx,0x24(%rsp)
  7d65de:	call   7e82d0 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextB1u_>
  7d65e3:	cmpq   $0x0,0x40(%rsp)
  7d65e9:	je     7d69a6 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x526>
  7d65ef:	mov    0xa0(%rsp),%rax
  7d65f7:	mov    %rax,0xf8(%rsp)
  7d65ff:	movss  0xa8(%rsp),%xmm0
  7d6608:	movss  %xmm0,0x34(%rsp)
  7d660e:	mov    0x68(%rsp),%r12
  7d6613:	mov    0x70(%rsp),%rbx
  7d6618:	mov    0x88(%rsp),%rbp
  7d6620:	mov    0x78(%rsp),%r15
  7d6625:	mov    0xb0(%rsp),%rax
  7d662d:	mov    %rax,0xf0(%rsp)
  7d6635:	mov    0xb8(%rsp),%rax
  7d663d:	mov    %rax,0xe8(%rsp)
  7d6645:	mov    0x80(%rsp),%r14
  7d664d:	nopl   (%rax)
  7d6650:	lea    0x100(%rsp),%rdi
  7d6658:	mov    0xf8(%rsp),%rsi
  7d6660:	movss  0x34(%rsp),%xmm0
  7d6666:	lea    0x40(%rsp),%rdx
  7d666b:	call   7c98c0 <_RNCNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB8_12TextGeometry9intervalss_0Bc_>
  7d6670:	movzbl 0x104(%rsp),%ecx
  7d6678:	cmp    $0x2,%cl
  7d667b:	je     7d66c9 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x249>
  7d667d:	mov    0xe8(%rsp),%rax
  7d6685:	mov    (%rax),%rdi
  7d6688:	mov    0xf0(%rsp),%rax
  7d6690:	mov    0x28(%rax),%rsi
  7d6694:	cmp    %rsi,%rdi
  7d6697:	jae    7d6cdc <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x85c>
  7d669d:	mov    0x100(%rsp),%esi
  7d66a4:	mov    0x20(%rax),%rax
  7d66a8:	lea    (%rdi,%rdi,2),%rdx
  7d66ac:	cmp    0x4(%rax,%rdx,8),%esi
  7d66b0:	ja     7d69a6 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x526>
  7d66b6:	mov    0x120(%rsp),%rax
  7d66be:	cmp    0x28(%rsp),%rax
  7d66c3:	je     7d688b <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x40b>
  7d66c9:	mov    %rbx,%rax
  7d66cc:	cmp    $0x1,%rbx
  7d66d0:	je     7d6704 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x284>
  7d66d2:	test   %rbx,%rbx
  7d66d5:	je     7d69a6 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x526>
  7d66db:	mov    (%r12),%ecx
  7d66df:	lea    0xc(%r12),%rdx
  7d66e4:	lea    0x1(%rbx),%rsi
  7d66e8:	mov    $0x1,%eax
  7d66ed:	nopl   (%rax)
  7d66f0:	cmp    (%rdx),%ecx
  7d66f2:	jne    7d6704 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x284>
  7d66f4:	inc    %rax
  7d66f7:	add    $0xc,%rdx
  7d66fb:	dec    %rsi
  7d66fe:	cmp    $0x2,%rsi
  7d6702:	ja     7d66f0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x270>
  7d6704:	sub    %rax,%rbx
  7d6707:	jb     7d6c89 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x809>
  7d670d:	lea    (%rax,%rax,2),%rcx
  7d6711:	lea    (%r12,%rcx,4),%rcx
  7d6715:	mov    %rcx,0x68(%rsp)
  7d671a:	mov    %rbx,0x70(%rsp)
  7d671f:	test   %rbp,%rbp
  7d6722:	jne    7d67b8 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x338>
  7d6728:	mov    %r14,%rdx
  7d672b:	cmp    $0x1,%r14
  7d672f:	je     7d6764 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x2e4>
  7d6731:	test   %r14,%r14
  7d6734:	je     7d69a6 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x526>
  7d673a:	mov    (%r15),%esi
  7d673d:	lea    0xc(%r15),%rdi
  7d6741:	lea    0x1(%r14),%r8
  7d6745:	mov    $0x1,%edx
  7d674a:	nopw   0x0(%rax,%rax,1)
  7d6750:	cmp    (%rdi),%esi
  7d6752:	jne    7d6764 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x2e4>
  7d6754:	inc    %rdx
  7d6757:	add    $0xc,%rdi
  7d675b:	dec    %r8
  7d675e:	cmp    $0x2,%r8
  7d6762:	ja     7d6750 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x2d0>
  7d6764:	sub    %rdx,%r14
  7d6767:	jb     7d6c89 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x809>
  7d676d:	lea    (%rdx,%rdx,2),%rsi
  7d6771:	lea    (%r15,%rsi,4),%rsi
  7d6775:	mov    %rsi,0x78(%rsp)
  7d677a:	mov    %r14,0x80(%rsp)
  7d6782:	test   %r15,%r15
  7d6785:	je     7d69a6 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x526>
  7d678b:	mov    %r12,0x40(%rsp)
  7d6790:	mov    %rax,0x48(%rsp)
  7d6795:	mov    %r15,0x50(%rsp)
  7d679a:	mov    %rdx,0x58(%rsp)
  7d679f:	mov    %rsi,%r15
  7d67a2:	mov    $0x0,%ebp
  7d67a7:	test   %r12,%r12
  7d67aa:	mov    %rcx,%r12
  7d67ad:	jne    7d6650 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x1d0>
  7d67b3:	jmp    7d69a6 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x526>
  7d67b8:	movq   $0x0,0x88(%rsp)
  7d67c4:	mov    %r15,%rdi
  7d67c7:	mov    %r14,%rsi
  7d67ca:	mov    %r14,%r8
  7d67cd:	cmp    $0x1,%r14
  7d67d1:	je     7d6805 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x385>
  7d67d3:	test   %rsi,%rsi
  7d67d6:	je     7d69a6 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x526>
  7d67dc:	mov    (%rdi),%edx
  7d67de:	lea    0xc(%rdi),%r9
  7d67e2:	lea    0x1(%rsi),%r10
  7d67e6:	mov    $0x1,%r8d
  7d67ec:	nopl   0x0(%rax)
  7d67f0:	cmp    (%r9),%edx
  7d67f3:	jne    7d6805 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x385>
  7d67f5:	inc    %r8
  7d67f8:	add    $0xc,%r9
  7d67fc:	dec    %r10
  7d67ff:	cmp    $0x2,%r10
  7d6803:	ja     7d67f0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x370>
  7d6805:	mov    %rsi,%r14
  7d6808:	sub    %r8,%r14
  7d680b:	jb     7d6c89 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x809>
  7d6811:	lea    (%r8,%r8,2),%r10
  7d6815:	lea    (%rdi,%r10,4),%r15
  7d6819:	dec    %rbp
  7d681c:	jne    7d67c4 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x344>
  7d681e:	mov    %r15,0x78(%rsp)
  7d6823:	mov    %r14,0x80(%rsp)
  7d682b:	mov    %r14,%rdx
  7d682e:	cmp    $0x1,%r14
  7d6832:	je     7d6868 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x3e8>
  7d6834:	test   %r14,%r14
  7d6837:	je     7d69a6 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x526>
  7d683d:	mov    (%r15),%r9d
  7d6840:	lea    (%rdi,%r10,4),%rdi
  7d6844:	add    $0xc,%rdi
  7d6848:	sub    %r8,%rsi
  7d684b:	inc    %rsi
  7d684e:	mov    $0x1,%edx
  7d6853:	cmp    (%rdi),%r9d
  7d6856:	jne    7d6868 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x3e8>
  7d6858:	inc    %rdx
  7d685b:	add    $0xc,%rdi
  7d685f:	dec    %rsi
  7d6862:	cmp    $0x2,%rsi
  7d6866:	ja     7d6853 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x3d3>
  7d6868:	sub    %rdx,%r14
  7d686b:	jb     7d6c89 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x809>
  7d6871:	lea    (%rdx,%rdx,2),%rsi
  7d6875:	lea    (%r15,%rsi,4),%rsi
  7d6879:	mov    %rsi,0x78(%rsp)
  7d687e:	mov    %r14,0x80(%rsp)
  7d6886:	jmp    7d678b <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x30b>
  7d688b:	movss  0x128(%rsp),%xmm1
  7d6894:	testb  $0x1,0x130(%rsp)
  7d689c:	je     7d68a8 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x428>
  7d689e:	mov    %esi,%eax
  7d68a0:	mov    %ecx,%r9d
  7d68a3:	movaps %xmm1,%xmm0
  7d68a6:	jmp    7d691c <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x49c>
  7d68a8:	mov    0x108(%rsp),%eax
  7d68af:	movzbl 0x10c(%rsp),%edx
  7d68b7:	movss  0x12c(%rsp),%xmm0
  7d68c0:	and    $0x1,%dl
  7d68c3:	movaps %xmm1,%xmm3
  7d68c6:	minss  %xmm0,%xmm3
  7d68ca:	movaps %xmm3,%xmm2
  7d68cd:	cmpunordss %xmm3,%xmm2
  7d68d2:	movaps %xmm2,%xmm4
  7d68d5:	andnps %xmm3,%xmm4
  7d68d8:	andps  %xmm1,%xmm2
  7d68db:	orps   %xmm4,%xmm2
  7d68de:	movaps %xmm1,%xmm3
  7d68e1:	maxss  %xmm0,%xmm3
  7d68e5:	ucomiss %xmm1,%xmm0
  7d68e8:	mov    %esi,%edi
  7d68ea:	cmovbe %eax,%edi
  7d68ed:	movaps %xmm3,%xmm0
  7d68f0:	cmpunordss %xmm3,%xmm0
  7d68f5:	movzbl %cl,%r8d
  7d68f9:	movzbl %dl,%r9d
  7d68fd:	mov    %r8d,%ecx
  7d6900:	cmovbe %r9d,%ecx
  7d6904:	movaps %xmm0,%xmm4
  7d6907:	cmovbe %esi,%eax
  7d690a:	andnps %xmm3,%xmm4
  7d690d:	cmovbe %r8d,%r9d
  7d6911:	andps  %xmm1,%xmm0
  7d6914:	orps   %xmm4,%xmm0
  7d6917:	movaps %xmm2,%xmm1
  7d691a:	mov    %edi,%esi
  7d691c:	mov    0x24(%rsp),%edx
  7d6920:	mov    0x1c(%rsp),%edi
  7d6924:	movss  0x20(%rsp),%xmm2
  7d692a:	ucomiss %xmm2,%xmm1
  7d692d:	jbe    7d695a <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x4da>
  7d692f:	cmp    $0x2,%dl
  7d6932:	je     7d693f <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x4bf>
  7d6934:	movss  0x14(%rsp),%xmm0
  7d693a:	ucomiss %xmm1,%xmm0
  7d693d:	jbe    7d694b <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x4cb>
  7d693f:	movss  %xmm1,0x14(%rsp)
  7d6945:	mov    %esi,0x18(%rsp)
  7d6949:	mov    %ecx,%edx
  7d694b:	movss  0x10(%rsp),%xmm0
  7d6951:	mov    %edi,%eax
  7d6953:	movzbl 0xf(%rsp),%ecx
  7d6958:	jmp    7d697c <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x4fc>
  7d695a:	ucomiss %xmm0,%xmm2
  7d695d:	jbe    7d6cab <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x82b>
  7d6963:	movzbl 0xf(%rsp),%ecx
  7d6968:	cmp    $0x2,%cl
  7d696b:	je     7d697f <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x4ff>
  7d696d:	ucomiss 0x10(%rsp),%xmm0
  7d6972:	ja     7d697f <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x4ff>
  7d6974:	movss  0x10(%rsp),%xmm0
  7d697a:	mov    %edi,%eax
  7d697c:	mov    %ecx,%r9d
  7d697f:	lea    0x68(%rsp),%rsi
  7d6984:	lea    0x40(%rsp),%rdi
  7d6989:	cmpb   $0x0,0xc0(%rsp)
  7d6991:	mov    %r9d,%ecx
  7d6994:	mov    %eax,0x1c(%rsp)
  7d6998:	movss  %xmm0,0x10(%rsp)
  7d699e:	je     7d65d6 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x156>
  7d69a4:	jmp    7d69bc <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x53c>
  7d69a6:	movss  0x10(%rsp),%xmm0
  7d69ac:	mov    0x1c(%rsp),%eax
  7d69b0:	movzbl 0xf(%rsp),%ecx
  7d69b5:	mov    %ecx,%r9d
  7d69b8:	mov    0x24(%rsp),%edx
  7d69bc:	cmp    $0x2,%r9b
  7d69c0:	jne    7d69d6 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x556>
  7d69c2:	cmp    $0x2,%dl
  7d69c5:	mov    0x18(%rsp),%esi
  7d69c9:	jne    7d6a1b <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x59b>
  7d69cb:	mov    $0x2,%dl
  7d69cd:	cmp    %r13,0x38(%rsp)
  7d69d2:	jne    7d6a2f <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x5af>
  7d69d4:	jmp    7d6a1b <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x59b>
  7d69d6:	cmp    $0x2,%dl
  7d69d9:	jne    7d69e2 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x562>
  7d69db:	mov    %r9d,%edx
  7d69de:	mov    %eax,%esi
  7d69e0:	jmp    7d6a1b <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x59b>
  7d69e2:	cvtss2sd %xmm0,%xmm0
  7d69e6:	movss  0x14(%rsp),%xmm1
  7d69ec:	cvtss2sd %xmm1,%xmm1
  7d69f0:	addsd  %xmm0,%xmm1
  7d69f4:	mulsd  -0x712c2c(%rip),%xmm1        # c3dd0 <GCC_except_table0+0x19c8>
  7d69fc:	movss  0x20(%rsp),%xmm0
  7d6a02:	cvtss2sd %xmm0,%xmm0
  7d6a06:	ucomisd %xmm1,%xmm0
  7d6a0a:	mov    0x18(%rsp),%esi
  7d6a0e:	cmovbe %eax,%esi
  7d6a11:	movzbl %dl,%eax
  7d6a14:	movzbl %r9b,%edx
  7d6a18:	cmova  %eax,%edx
  7d6a1b:	mov    %esi,%eax
  7d6a1d:	add    $0x138,%rsp
  7d6a24:	pop    %rbx
  7d6a25:	pop    %r12
  7d6a27:	pop    %r13
  7d6a29:	pop    %r14
  7d6a2b:	pop    %r15
  7d6a2d:	pop    %rbp
  7d6a2e:	ret
  7d6a2f:	mov    0x28(%rsp),%rdi
  7d6a34:	mov    0xe0(%rsp),%rsi
  7d6a3c:	cmp    %rsi,%rdi
  7d6a3f:	jae    7d6cfc <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x87c>
  7d6a45:	mov    0xc8(%rsp),%rax
  7d6a4d:	lea    (%rax,%rax,2),%rax
  7d6a51:	mov    0xd0(%rsp),%r12
  7d6a59:	lea    (%r12,%rax,4),%rax
  7d6a5d:	lea    (%rdi,%rdi,2),%rcx
  7d6a61:	mov    0xd8(%rsp),%r14
  7d6a69:	mov    0x4(%r14,%rcx,8),%ecx
  7d6a6e:	lea    -0x1(%rsi),%r15
  7d6a72:	jmp    7d6aa0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x620>
  7d6a74:	xor    %ebx,%ebx
  7d6a76:	lea    (%rbx,%rbx,2),%r8
  7d6a7a:	cmp    %r13d,0x4(%r14,%r8,8)
  7d6a7f:	adc    $0x0,%rbx
  7d6a83:	cmp    %rbx,%r15
  7d6a86:	cmovb  %r15,%rbx
  7d6a8a:	cmp    %rdi,%rbx
  7d6a8d:	je     7d6c7f <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x7ff>
  7d6a93:	add    $0xc,%r12
  7d6a97:	cmp    %rax,%r12
  7d6a9a:	je     7d69d4 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x554>
  7d6aa0:	mov    (%r12),%r13d
  7d6aa4:	cmp    %ecx,%r13d
  7d6aa7:	ja     7d6c6d <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x7ed>
  7d6aad:	movzbl 0x8(%r12),%ebp
  7d6ab3:	test   %r13d,%r13d
  7d6ab6:	je     7d6ae0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x660>
  7d6ab8:	test   $0x2,%bpl
  7d6abc:	je     7d6b54 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x6d4>
  7d6ac2:	mov    %rsi,%r9
  7d6ac5:	test   %rsi,%rsi
  7d6ac8:	je     7d6b4b <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x6cb>
  7d6ace:	cmp    $0x1,%rsi
  7d6ad2:	jne    7d6b08 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x688>
  7d6ad4:	xor    %r8d,%r8d
  7d6ad7:	jmp    7d6b31 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x6b1>
  7d6ad9:	nopl   0x0(%rax)
  7d6ae0:	test   $0x2,%bpl
  7d6ae4:	je     7d6bf4 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x774>
  7d6aea:	mov    %rsi,%r9
  7d6aed:	test   %rsi,%rsi
  7d6af0:	je     7d6beb <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x76b>
  7d6af6:	cmp    $0x1,%rsi
  7d6afa:	jne    7d6ba5 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x725>
  7d6b00:	xor    %r8d,%r8d
  7d6b03:	jmp    7d6bd0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x750>
  7d6b08:	mov    %rsi,%r9
  7d6b0b:	xor    %r8d,%r8d
  7d6b0e:	xchg   %ax,%ax
  7d6b10:	mov    %r8,%r10
  7d6b13:	mov    %r9,%r11
  7d6b16:	shr    $1,%r11
  7d6b19:	add    %r11,%r8
  7d6b1c:	lea    (%r8,%r8,2),%rbx
  7d6b20:	cmp    %r13d,(%r14,%rbx,8)
  7d6b24:	cmova  %r10,%r8
  7d6b28:	sub    %r11,%r9
  7d6b2b:	cmp    $0x1,%r9
  7d6b2f:	ja     7d6b10 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x690>
  7d6b31:	lea    (%r8,%r8,2),%r10
  7d6b35:	xor    %r9d,%r9d
  7d6b38:	cmp    %r13d,(%r14,%r10,8)
  7d6b3c:	setbe  %r9b
  7d6b40:	add    %r8,%r9
  7d6b43:	cmp    $0x1,%r9
  7d6b47:	adc    $0xffffffffffffffff,%r9
  7d6b4b:	cmp    %rdi,%r9
  7d6b4e:	je     7d6c75 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x7f5>
  7d6b54:	test   $0x1,%bpl
  7d6b58:	je     7d6a93 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x613>
  7d6b5e:	mov    %rsi,%rbx
  7d6b61:	test   %rsi,%rsi
  7d6b64:	je     7d6a8a <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x60a>
  7d6b6a:	cmp    $0x1,%rsi
  7d6b6e:	je     7d6a74 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x5f4>
  7d6b74:	mov    %rsi,%r8
  7d6b77:	xor    %ebx,%ebx
  7d6b79:	nopl   0x0(%rax)
  7d6b80:	mov    %r8,%r9
  7d6b83:	shr    $1,%r9
  7d6b86:	lea    (%r9,%rbx,1),%r10
  7d6b8a:	lea    (%r10,%r10,2),%r11
  7d6b8e:	cmp    %r13d,0x4(%r14,%r11,8)
  7d6b93:	cmovb  %r10,%rbx
  7d6b97:	sub    %r9,%r8
  7d6b9a:	cmp    $0x1,%r8
  7d6b9e:	ja     7d6b80 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x700>
  7d6ba0:	jmp    7d6a76 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x5f6>
  7d6ba5:	mov    %rsi,%r9
  7d6ba8:	xor    %r8d,%r8d
  7d6bab:	nopl   0x0(%rax,%rax,1)
  7d6bb0:	mov    %r9,%r10
  7d6bb3:	shr    $1,%r10
  7d6bb6:	lea    (%r10,%r8,1),%r11
  7d6bba:	lea    (%r11,%r11,2),%rbx
  7d6bbe:	cmpl   $0x0,(%r14,%rbx,8)
  7d6bc3:	cmove  %r11,%r8
  7d6bc7:	sub    %r10,%r9
  7d6bca:	cmp    $0x1,%r9
  7d6bce:	ja     7d6bb0 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x730>
  7d6bd0:	lea    (%r8,%r8,2),%r10
  7d6bd4:	xor    %r9d,%r9d
  7d6bd7:	cmpl   $0x0,(%r14,%r10,8)
  7d6bdc:	sete   %r9b
  7d6be0:	add    %r8,%r9
  7d6be3:	cmp    $0x1,%r9
  7d6be7:	adc    $0xffffffffffffffff,%r9
  7d6beb:	cmp    %rdi,%r9
  7d6bee:	je     7d6ca2 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x822>
  7d6bf4:	test   $0x1,%bpl
  7d6bf8:	je     7d6a93 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x613>
  7d6bfe:	mov    %rsi,%r8
  7d6c01:	test   %rsi,%rsi
  7d6c04:	je     7d6c5b <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x7db>
  7d6c06:	cmp    $0x1,%rsi
  7d6c0a:	jne    7d6c10 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x790>
  7d6c0c:	xor    %ebx,%ebx
  7d6c0e:	jmp    7d6c40 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x7c0>
  7d6c10:	mov    %rsi,%r8
  7d6c13:	xor    %ebx,%ebx
  7d6c15:	data16 cs nopw 0x0(%rax,%rax,1)
  7d6c20:	mov    %r8,%r9
  7d6c23:	shr    $1,%r9
  7d6c26:	lea    (%r9,%rbx,1),%r10
  7d6c2a:	lea    (%r10,%r10,2),%r11
  7d6c2e:	cmpl   $0x0,(%r14,%r11,8)
  7d6c33:	cmove  %r10,%rbx
  7d6c37:	sub    %r9,%r8
  7d6c3a:	cmp    $0x1,%r8
  7d6c3e:	ja     7d6c20 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x7a0>
  7d6c40:	lea    (%rbx,%rbx,2),%r9
  7d6c44:	xor    %r8d,%r8d
  7d6c47:	cmpl   $0x0,(%r14,%r9,8)
  7d6c4c:	sete   %r8b
  7d6c50:	add    %rbx,%r8
  7d6c53:	cmp    $0x1,%r8
  7d6c57:	adc    $0xffffffffffffffff,%r8
  7d6c5b:	cmp    %rdi,%r8
  7d6c5e:	jne    7d6a93 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x613>
  7d6c64:	xor    %edx,%edx
  7d6c66:	xor    %esi,%esi
  7d6c68:	jmp    7d6a1b <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x59b>
  7d6c6d:	mov    %r13d,%esi
  7d6c70:	jmp    7d6a1b <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x59b>
  7d6c75:	mov    $0x1,%dl
  7d6c77:	mov    %r13d,%esi
  7d6c7a:	jmp    7d6a1b <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x59b>
  7d6c7f:	xor    %edx,%edx
  7d6c81:	mov    %r13d,%esi
  7d6c84:	jmp    7d6a1b <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x59b>
  7d6c89:	lea    -0x4c5329(%rip),%rdi        # 311967 <_RNvNtCsghYClfd3M9V_11gpui_canvas4text13PRIMARY_BYTES+0x1f463f>
  7d6c90:	lea    0x2c7bd9(%rip),%rdx        # a9e870 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0x1a08>
  7d6c97:	mov    $0x13,%esi
  7d6c9c:	call   *0x2e3616(%rip)        # aba2b8 <_DYNAMIC+0x278>
  7d6ca2:	xor    %esi,%esi
  7d6ca4:	mov    $0x1,%dl
  7d6ca6:	jmp    7d6a1b <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x59b>
  7d6cab:	cvtss2sd %xmm1,%xmm1
  7d6caf:	cvtss2sd %xmm0,%xmm0
  7d6cb3:	addsd  %xmm1,%xmm0
  7d6cb7:	mulsd  -0x712eef(%rip),%xmm0        # c3dd0 <GCC_except_table0+0x19c8>
  7d6cbf:	movss  0x20(%rsp),%xmm1
  7d6cc5:	cvtss2sd %xmm1,%xmm1
  7d6cc9:	ucomisd %xmm0,%xmm1
  7d6ccd:	cmova  %eax,%esi
  7d6cd0:	movzbl %r9b,%eax
  7d6cd4:	movzbl %cl,%edx
  7d6cd7:	jmp    7d6a18 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry16position_on_line+0x598>
  7d6cdc:	lea    0x2c7025(%rip),%rdx        # a9dd08 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0xea0>
  7d6ce3:	call   *0x2e35c7(%rip)        # aba2b0 <_DYNAMIC+0x270>
  7d6ce9:	lea    0x2c7920(%rip),%rdx        # a9e610 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0x17a8>
  7d6cf0:	mov    %rsi,%rdi
  7d6cf3:	mov    %rax,%rsi
  7d6cf6:	call   *0x2e35b4(%rip)        # aba2b0 <_DYNAMIC+0x270>
  7d6cfc:	lea    0x2c6f45(%rip),%rdx        # a9dc48 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0xde0>
  7d6d03:	call   *0x2e35a7(%rip)        # aba2b0 <_DYNAMIC+0x270>

<gpui_canvas::text::layout::TextGeometry>::graphemes bytes=78 frame=0

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007d6d10 <_RNvMs0_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB7_12TextGeometry9graphemes>:
  7d6d10:	mov    %rdi,%rax
  7d6d13:	xor    %ecx,%ecx
  7d6d15:	cmpq   $0xffffffffffffffff,0x30(%rsi)
  7d6d1a:	cmovne 0x40(%rsi),%rcx
  7d6d1f:	mov    $0x4,%edx
  7d6d24:	cmovne 0x38(%rsi),%rdx
  7d6d29:	movss  0x4c(%rsi),%xmm0
  7d6d2e:	mulss  -0x71481e(%rip),%xmm0        # c2518 <GCC_except_table0+0x110>
  7d6d36:	xorps  %xmm1,%xmm1
  7d6d39:	movups %xmm1,0x28(%rdi)
  7d6d3d:	mov    %rdx,(%rdi)
  7d6d40:	mov    %rcx,0x8(%rdi)
  7d6d44:	mov    %rdx,0x10(%rdi)
  7d6d48:	mov    %rcx,0x18(%rdi)
  7d6d4c:	movq   $0x1,0x20(%rdi)
  7d6d54:	mov    %rsi,0x38(%rdi)
  7d6d58:	movss  %xmm0,0x40(%rdi)
  7d6d5d:	ret

<alloc::raw_vec::RawVec<gpui_canvas::text::layout::Run>>::grow_one bytes=100 frame=40

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007d91d0 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout3RunE8grow_oneBR_>:
  7d91d0:	push   %r14
  7d91d2:	push   %rbx
  7d91d3:	sub    $0x18,%rsp
  7d91d7:	mov    %rdi,%rbx
  7d91da:	mov    (%rdi),%rsi
  7d91dd:	lea    (%rsi,%rsi,1),%rax
  7d91e1:	cmp    $0x5,%rax
  7d91e5:	mov    $0x4,%r14d
  7d91eb:	cmovae %rax,%r14
  7d91ef:	mov    0x8(%rdi),%rdx
  7d91f3:	mov    %rsp,%rdi
  7d91f6:	mov    $0x4,%r8d
  7d91fc:	mov    $0x18,%r9d
  7d9202:	mov    %r14,%rcx
  7d9205:	call   7d9910 <_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsghYClfd3M9V_11gpui_canvas>
  7d920a:	cmpl   $0x1,(%rsp)
  7d920e:	je     7d9224 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout3RunE8grow_oneBR_+0x54>
  7d9210:	mov    0x8(%rsp),%rax
  7d9215:	mov    %rax,0x8(%rbx)
  7d9219:	mov    %r14,(%rbx)
  7d921c:	add    $0x18,%rsp
  7d9220:	pop    %rbx
  7d9221:	pop    %r14
  7d9223:	ret
  7d9224:	mov    0x8(%rsp),%rdi
  7d9229:	mov    0x10(%rsp),%rsi
  7d922e:	call   *0x2e10fc(%rip)        # aba330 <_DYNAMIC+0x2f0>

<alloc::raw_vec::RawVec<gpui_canvas::text::layout::Stop>>::grow_one bytes=100 frame=40

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007d9240 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopE8grow_oneBR_>:
  7d9240:	push   %r14
  7d9242:	push   %rbx
  7d9243:	sub    $0x18,%rsp
  7d9247:	mov    %rdi,%rbx
  7d924a:	mov    (%rdi),%rsi
  7d924d:	lea    (%rsi,%rsi,1),%rax
  7d9251:	cmp    $0x5,%rax
  7d9255:	mov    $0x4,%r14d
  7d925b:	cmovae %rax,%r14
  7d925f:	mov    0x8(%rdi),%rdx
  7d9263:	mov    %rsp,%rdi
  7d9266:	mov    $0x4,%r8d
  7d926c:	mov    $0xc,%r9d
  7d9272:	mov    %r14,%rcx
  7d9275:	call   7d9910 <_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsghYClfd3M9V_11gpui_canvas>
  7d927a:	cmpl   $0x1,(%rsp)
  7d927e:	je     7d9294 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopE8grow_oneBR_+0x54>
  7d9280:	mov    0x8(%rsp),%rax
  7d9285:	mov    %rax,0x8(%rbx)
  7d9289:	mov    %r14,(%rbx)
  7d928c:	add    $0x18,%rsp
  7d9290:	pop    %rbx
  7d9291:	pop    %r14
  7d9293:	ret
  7d9294:	mov    0x8(%rsp),%rdi
  7d9299:	mov    0x10(%rsp),%rsi
  7d929e:	call   *0x2e108c(%rip)        # aba330 <_DYNAMIC+0x2f0>

<gpui_canvas::text::layout::TextGeometry>::caret_bounds bytes=461 frame=24

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007d9610 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds>:
  7d9610:	push   %r14
  7d9612:	push   %rbx
  7d9613:	push   %rax
  7d9614:	cmpq   $0xffffffffffffffff,0x30(%rsi)
  7d9619:	je     7d971a <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x10a>
  7d961f:	mov    0x38(%rsi),%r8
  7d9623:	mov    0x40(%rsi),%rax
  7d9627:	mov    %rax,%r9
  7d962a:	test   %rax,%rax
  7d962d:	je     7d966b <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x5b>
  7d962f:	xor    %r9d,%r9d
  7d9632:	cmp    $0x1,%rax
  7d9636:	je     7d965f <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x4f>
  7d9638:	mov    %rax,%r10
  7d963b:	nopl   0x0(%rax,%rax,1)
  7d9640:	mov    %r10,%r11
  7d9643:	shr    $1,%r11
  7d9646:	lea    (%r11,%r9,1),%rbx
  7d964a:	lea    (%rbx,%rbx,2),%r14
  7d964e:	cmp    %edx,(%r8,%r14,4)
  7d9652:	cmovb  %rbx,%r9
  7d9656:	sub    %r11,%r10
  7d9659:	cmp    $0x1,%r10
  7d965d:	ja     7d9640 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x30>
  7d965f:	lea    (%r9,%r9,2),%r10
  7d9663:	cmp    %edx,(%r8,%r10,4)
  7d9667:	adc    $0x0,%r9
  7d966b:	inc    %cl
  7d966d:	shl    $0x2,%r9
  7d9671:	lea    (%r9,%r9,2),%r9
  7d9675:	lea    (%r8,%r9,1),%r10
  7d9679:	shl    $0x2,%rax
  7d967d:	lea    (%rax,%rax,2),%rax
  7d9681:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  7d9690:	xor    %r11d,%r11d
  7d9693:	cmp    %r9,%rax
  7d9696:	je     7d97bf <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x1af>
  7d969c:	cmp    %edx,(%r10)
  7d969f:	jne    7d97bf <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x1af>
  7d96a5:	movzbl 0x8(%r10),%r11d
  7d96aa:	add    $0xc,%r10
  7d96ae:	add    $0xc,%r9
  7d96b2:	test   %cl,%r11b
  7d96b5:	je     7d9690 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x80>
  7d96b7:	mov    0x20(%rsi),%rcx
  7d96bb:	mov    0x28(%rsi),%rsi
  7d96bf:	test   $0x1,%r11b
  7d96c3:	je     7d9722 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x112>
  7d96c5:	test   %edx,%edx
  7d96c7:	je     7d9722 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x112>
  7d96c9:	mov    %rsi,%rax
  7d96cc:	test   %rsi,%rsi
  7d96cf:	je     7d970d <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0xfd>
  7d96d1:	xor    %eax,%eax
  7d96d3:	cmp    $0x1,%rsi
  7d96d7:	je     7d9700 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0xf0>
  7d96d9:	mov    %rsi,%r10
  7d96dc:	nopl   0x0(%rax)
  7d96e0:	mov    %r10,%r11
  7d96e3:	shr    $1,%r11
  7d96e6:	lea    (%r11,%rax,1),%rbx
  7d96ea:	lea    (%rbx,%rbx,2),%r14
  7d96ee:	cmp    %edx,0x4(%rcx,%r14,8)
  7d96f3:	cmovb  %rbx,%rax
  7d96f7:	sub    %r11,%r10
  7d96fa:	cmp    $0x1,%r10
  7d96fe:	ja     7d96e0 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0xd0>
  7d9700:	lea    (%rax,%rax,2),%r10
  7d9704:	cmp    %edx,0x4(%rcx,%r10,8)
  7d9709:	adc    $0x0,%rax
  7d970d:	lea    -0x1(%rsi),%rdx
  7d9711:	cmp    %rax,%rdx
  7d9714:	cmovb  %rdx,%rax
  7d9718:	jmp    7d9779 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x169>
  7d971a:	xor    %r11d,%r11d
  7d971d:	jmp    7d97bf <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x1af>
  7d9722:	mov    %rsi,%rax
  7d9725:	test   %rsi,%rsi
  7d9728:	je     7d9779 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x169>
  7d972a:	xor    %r10d,%r10d
  7d972d:	cmp    $0x1,%rsi
  7d9731:	je     7d9761 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x151>
  7d9733:	mov    %rsi,%rax
  7d9736:	cs nopw 0x0(%rax,%rax,1)
  7d9740:	mov    %r10,%r11
  7d9743:	mov    %rax,%rbx
  7d9746:	shr    $1,%rbx
  7d9749:	add    %rbx,%r10
  7d974c:	lea    (%r10,%r10,2),%r14
  7d9750:	cmp    %edx,(%rcx,%r14,8)
  7d9754:	cmova  %r11,%r10
  7d9758:	sub    %rbx,%rax
  7d975b:	cmp    $0x1,%rax
  7d975f:	ja     7d9740 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x130>
  7d9761:	lea    (%r10,%r10,2),%r11
  7d9765:	xor    %eax,%eax
  7d9767:	cmp    %edx,(%rcx,%r11,8)
  7d976b:	setbe  %al
  7d976e:	add    %r10,%rax
  7d9771:	cmp    $0x1,%rax
  7d9775:	adc    $0xffffffffffffffff,%rax
  7d9779:	cmp    %rsi,%rax
  7d977c:	jae    7d97cd <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry12caret_bounds+0x1bd>
  7d977e:	lea    (%rax,%rax,2),%rax
  7d9782:	movss  -0x8(%r8,%r9,1),%xmm0
  7d9789:	movss  -0x717309(%rip),%xmm1        # c2488 <GCC_except_table0+0x80>
  7d9791:	addss  %xmm0,%xmm1
  7d9795:	subss  %xmm0,%xmm1
  7d9799:	movss  0x8(%rcx,%rax,8),%xmm2
  7d979f:	movss  0xc(%rcx,%rax,8),%xmm3
  7d97a5:	movss  %xmm0,0x4(%rdi)
  7d97aa:	movss  %xmm2,0x8(%rdi)
  7d97af:	movss  %xmm1,0xc(%rdi)
  7d97b4:	movss  %xmm3,0x10(%rdi)
  7d97b9:	mov    $0x1,%r11d
  7d97bf:	mov    %r11d,(%rdi)
  7d97c2:	mov    %rdi,%rax
  7d97c5:	add    $0x8,%rsp
  7d97c9:	pop    %rbx
  7d97ca:	pop    %r14
  7d97cc:	ret
  7d97cd:	lea    0x2c4a7c(%rip),%rdx        # a9e250 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0x13e8>
  7d97d4:	mov    %rax,%rdi
  7d97d7:	call   *0x2e0ad3(%rip)        # aba2b0 <_DYNAMIC+0x270>

<gpui_canvas::text::layout::TextGeometry>::validates_selection bytes=290 frame=8

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007d97e0 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection>:
  7d97e0:	cmpq   $0xffffffffffffffff,0x30(%rdi)
  7d97e5:	je     7d98ff <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0x11f>
  7d97eb:	push   %rbx
  7d97ec:	mov    (%rsi),%r8d
  7d97ef:	movzbl 0x4(%rsi),%r9d
  7d97f4:	mov    0x38(%rdi),%rax
  7d97f8:	mov    0x40(%rdi),%rcx
  7d97fc:	mov    %rcx,%rdx
  7d97ff:	test   %rcx,%rcx
  7d9802:	je     7d983b <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0x5b>
  7d9804:	xor    %edx,%edx
  7d9806:	cmp    $0x1,%rcx
  7d980a:	je     7d982f <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0x4f>
  7d980c:	mov    %rcx,%rdi
  7d980f:	nop
  7d9810:	mov    %rdi,%r10
  7d9813:	shr    $1,%r10
  7d9816:	lea    (%r10,%rdx,1),%r11
  7d981a:	lea    (%r11,%r11,2),%rbx
  7d981e:	cmp    %r8d,(%rax,%rbx,4)
  7d9822:	cmovb  %r11,%rdx
  7d9826:	sub    %r10,%rdi
  7d9829:	cmp    $0x1,%rdi
  7d982d:	ja     7d9810 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0x30>
  7d982f:	lea    (%rdx,%rdx,2),%rdi
  7d9833:	cmp    %r8d,(%rax,%rdi,4)
  7d9837:	adc    $0x0,%rdx
  7d983b:	inc    %r9b
  7d983e:	shl    $0x2,%rdx
  7d9842:	lea    (%rdx,%rdx,2),%r11
  7d9846:	lea    (%rax,%r11,1),%rdi
  7d984a:	lea    0x0(,%rcx,4),%rdx
  7d9852:	lea    (%rdx,%rdx,2),%rdx
  7d9856:	mov    %rdx,%r10
  7d9859:	sub    %r11,%r10
  7d985c:	nopl   0x0(%rax)
  7d9860:	test   %r10,%r10
  7d9863:	je     7d98fb <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0x11b>
  7d9869:	cmp    %r8d,(%rdi)
  7d986c:	jne    7d98fb <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0x11b>
  7d9872:	add    $0xfffffffffffffff4,%r10
  7d9876:	test   %r9b,0x8(%rdi)
  7d987a:	lea    0xc(%rdi),%rdi
  7d987e:	je     7d9860 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0x80>
  7d9880:	mov    0x8(%rsi),%edi
  7d9883:	movzbl 0xc(%rsi),%esi
  7d9887:	test   %rcx,%rcx
  7d988a:	je     7d98cd <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0xed>
  7d988c:	xor    %r8d,%r8d
  7d988f:	cmp    $0x1,%rcx
  7d9893:	je     7d98bf <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0xdf>
  7d9895:	data16 cs nopw 0x0(%rax,%rax,1)
  7d98a0:	mov    %rcx,%r9
  7d98a3:	shr    $1,%r9
  7d98a6:	lea    (%r9,%r8,1),%r10
  7d98aa:	lea    (%r10,%r10,2),%r11
  7d98ae:	cmp    %edi,(%rax,%r11,4)
  7d98b2:	cmovb  %r10,%r8
  7d98b6:	sub    %r9,%rcx
  7d98b9:	cmp    $0x1,%rcx
  7d98bd:	ja     7d98a0 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0xc0>
  7d98bf:	lea    (%r8,%r8,2),%rcx
  7d98c3:	cmp    %edi,(%rax,%rcx,4)
  7d98c6:	adc    $0x0,%r8
  7d98ca:	mov    %r8,%rcx
  7d98cd:	inc    %sil
  7d98d0:	shl    $0x2,%rcx
  7d98d4:	lea    (%rcx,%rcx,2),%rcx
  7d98d8:	add    %rcx,%rax
  7d98db:	sub    %rcx,%rdx
  7d98de:	xchg   %ax,%ax
  7d98e0:	test   %rdx,%rdx
  7d98e3:	je     7d98fb <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0x11b>
  7d98e5:	cmp    %edi,(%rax)
  7d98e7:	jne    7d98fb <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0x11b>
  7d98e9:	add    $0xfffffffffffffff4,%rdx
  7d98ed:	test   %sil,0x8(%rax)
  7d98f1:	lea    0xc(%rax),%rax
  7d98f5:	je     7d98e0 <_RNvMs3_NtNtCsghYClfd3M9V_11gpui_canvas4text6layoutNtB5_12TextGeometry19validates_selection+0x100>
  7d98f7:	mov    $0x1,%al
  7d98f9:	pop    %rbx
  7d98fa:	ret
  7d98fb:	xor    %eax,%eax
  7d98fd:	pop    %rbx
  7d98fe:	ret
  7d98ff:	xor    %eax,%eax
  7d9901:	ret

<gpui_canvas::text::layout::TextGeometry>::source_line bytes=183 frame=0

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007dd110 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry11source_line>:
  7dd110:	not    %dl
  7dd112:	test   %esi,%esi
  7dd114:	setne  %r8b
  7dd118:	mov    0x20(%rdi),%rcx
  7dd11c:	mov    0x28(%rdi),%rax
  7dd120:	test   %r8b,%dl
  7dd123:	jne    7dd179 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry11source_line+0x69>
  7dd125:	test   %rax,%rax
  7dd128:	je     7dd1c6 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry11source_line+0xb6>
  7dd12e:	xor    %edx,%edx
  7dd130:	cmp    $0x1,%rax
  7dd134:	je     7dd161 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry11source_line+0x51>
  7dd136:	cs nopw 0x0(%rax,%rax,1)
  7dd140:	mov    %rdx,%rdi
  7dd143:	mov    %rax,%r8
  7dd146:	shr    $1,%r8
  7dd149:	add    %r8,%rdx
  7dd14c:	lea    (%rdx,%rdx,2),%r9
  7dd150:	cmp    %esi,(%rcx,%r9,8)
  7dd154:	cmova  %rdi,%rdx
  7dd158:	sub    %r8,%rax
  7dd15b:	cmp    $0x1,%rax
  7dd15f:	ja     7dd140 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry11source_line+0x30>
  7dd161:	lea    (%rdx,%rdx,2),%rdi
  7dd165:	xor    %eax,%eax
  7dd167:	cmp    %esi,(%rcx,%rdi,8)
  7dd16a:	setbe  %al
  7dd16d:	add    %rdx,%rax
  7dd170:	cmp    $0x1,%rax
  7dd174:	adc    $0xffffffffffffffff,%rax
  7dd178:	ret
  7dd179:	mov    %rax,%rdx
  7dd17c:	test   %rax,%rax
  7dd17f:	je     7dd1bc <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry11source_line+0xac>
  7dd181:	xor    %edx,%edx
  7dd183:	cmp    $0x1,%rax
  7dd187:	je     7dd1b0 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry11source_line+0xa0>
  7dd189:	mov    %rax,%rdi
  7dd18c:	nopl   0x0(%rax)
  7dd190:	mov    %rdi,%r8
  7dd193:	shr    $1,%r8
  7dd196:	lea    (%r8,%rdx,1),%r9
  7dd19a:	lea    (%r9,%r9,2),%r10
  7dd19e:	cmp    %esi,0x4(%rcx,%r10,8)
  7dd1a3:	cmovb  %r9,%rdx
  7dd1a7:	sub    %r8,%rdi
  7dd1aa:	cmp    $0x1,%rdi
  7dd1ae:	ja     7dd190 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry11source_line+0x80>
  7dd1b0:	lea    (%rdx,%rdx,2),%rdi
  7dd1b4:	cmp    %esi,0x4(%rcx,%rdi,8)
  7dd1b8:	adc    $0x0,%rdx
  7dd1bc:	dec    %rax
  7dd1bf:	cmp    %rdx,%rax
  7dd1c2:	cmovae %rdx,%rax
  7dd1c6:	ret

<gpui_canvas::text::layout::TextGeometry>::stops bytes=213 frame=8

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007dd1d0 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry5stops>:
  7dd1d0:	push   %rbx
  7dd1d1:	mov    %edx,%eax
  7dd1d3:	xor    %edx,%edx
  7dd1d5:	cmpq   $0xffffffffffffffff,0x30(%rdi)
  7dd1da:	mov    0x40(%rdi),%r8
  7dd1de:	cmovne %r8,%rdx
  7dd1e2:	mov    $0x4,%ecx
  7dd1e7:	cmovne 0x38(%rdi),%rcx
  7dd1ec:	test   %esi,%esi
  7dd1ee:	je     7dd23c <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry5stops+0x6c>
  7dd1f0:	test   %rdx,%rdx
  7dd1f3:	je     7dd28f <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry5stops+0xbf>
  7dd1f9:	xor    %edi,%edi
  7dd1fb:	cmp    $0x1,%rdx
  7dd1ff:	je     7dd22e <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry5stops+0x5e>
  7dd201:	mov    %r8,%r9
  7dd204:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  7dd210:	mov    %r9,%r10
  7dd213:	shr    $1,%r10
  7dd216:	lea    (%r10,%rdi,1),%r11
  7dd21a:	lea    (%r11,%r11,2),%rbx
  7dd21e:	cmp    %esi,(%rcx,%rbx,4)
  7dd221:	cmovb  %r11,%rdi
  7dd225:	sub    %r10,%r9
  7dd228:	cmp    $0x1,%r9
  7dd22c:	ja     7dd210 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry5stops+0x40>
  7dd22e:	lea    (%rdi,%rdi,2),%r9
  7dd232:	cmp    %esi,(%rcx,%r9,4)
  7dd236:	adc    $0x0,%rdi
  7dd23a:	jmp    7dd248 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry5stops+0x78>
  7dd23c:	xor    %edi,%edi
  7dd23e:	mov    $0x0,%esi
  7dd243:	test   %rdx,%rdx
  7dd246:	je     7dd295 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry5stops+0xc5>
  7dd248:	xor    %esi,%esi
  7dd24a:	cmp    $0x1,%rdx
  7dd24e:	je     7dd271 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry5stops+0xa1>
  7dd250:	mov    %rsi,%r9
  7dd253:	mov    %r8,%r10
  7dd256:	shr    $1,%r10
  7dd259:	add    %r10,%rsi
  7dd25c:	lea    (%rsi,%rsi,2),%r11
  7dd260:	cmp    %eax,(%rcx,%r11,4)
  7dd264:	cmova  %r9,%rsi
  7dd268:	sub    %r10,%r8
  7dd26b:	cmp    $0x1,%r8
  7dd26f:	ja     7dd250 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry5stops+0x80>
  7dd271:	lea    (%rsi,%rsi,2),%r8
  7dd275:	cmp    (%rcx,%r8,4),%eax
  7dd279:	sbb    $0xffffffffffffffff,%rsi
  7dd27d:	cmp    %rdi,%rsi
  7dd280:	jae    7dd295 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry5stops+0xc5>
  7dd282:	lea    0x2c136f(%rip),%rcx        # a9e5f8 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0x1790>
  7dd289:	call   *0x2dd041(%rip)        # aba2d0 <_DYNAMIC+0x290>
  7dd28f:	mov    %rdx,%rsi
  7dd292:	mov    %rdx,%rdi
  7dd295:	sub    %rdi,%rsi
  7dd298:	lea    (%rdi,%rdi,2),%rax
  7dd29c:	lea    (%rcx,%rax,4),%rax
  7dd2a0:	mov    %rsi,%rdx
  7dd2a3:	pop    %rbx
  7dd2a4:	ret

<gpui_canvas::text::layout::TextGeometry>::intervals bytes=43 frame=0

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007dd2b0 <_RNvMs_NtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout11interactionNtB6_12TextGeometry9intervals>:
  7dd2b0:	mov    %rdi,%rax
  7dd2b3:	xorps  %xmm1,%xmm1
  7dd2b6:	movups %xmm1,0x28(%rdi)
  7dd2ba:	mov    %rdx,(%rdi)
  7dd2bd:	mov    %rcx,0x8(%rdi)
  7dd2c1:	mov    %rdx,0x10(%rdi)
  7dd2c5:	mov    %rcx,0x18(%rdi)
  7dd2c9:	movq   $0x1,0x20(%rdi)
  7dd2d1:	mov    %rsi,0x38(%rdi)
  7dd2d5:	movss  %xmm0,0x40(%rdi)
  7dd2da:	ret

<alloc::sync::Arc<gpui_canvas::text::layout::TextGeometry>>::drop_slow bytes=135 frame=8

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007e2860 <_RNvMsn_NtCscdodAO9FK5_5alloc4syncINtB5_3ArcNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryE9drop_slowBL_>:
  7e2860:	push   %rbx
  7e2861:	mov    (%rdi),%rbx
  7e2864:	mov    0x10(%rbx),%rax
  7e2868:	test   %rax,%rax
  7e286b:	je     7e2884 <_RNvMsn_NtCscdodAO9FK5_5alloc4syncINtB5_3ArcNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryE9drop_slowBL_+0x24>
  7e286d:	mov    0x18(%rbx),%rdi
  7e2871:	shl    $0x3,%rax
  7e2875:	lea    (%rax,%rax,2),%rsi
  7e2879:	mov    $0x4,%edx
  7e287e:	call   *0x2d79fc(%rip)        # aba280 <_DYNAMIC+0x240>
  7e2884:	mov    0x28(%rbx),%rax
  7e2888:	test   %rax,%rax
  7e288b:	je     7e28a4 <_RNvMsn_NtCscdodAO9FK5_5alloc4syncINtB5_3ArcNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryE9drop_slowBL_+0x44>
  7e288d:	mov    0x30(%rbx),%rdi
  7e2891:	shl    $0x3,%rax
  7e2895:	lea    (%rax,%rax,2),%rsi
  7e2899:	mov    $0x4,%edx
  7e289e:	call   *0x2d79dc(%rip)        # aba280 <_DYNAMIC+0x240>
  7e28a4:	mov    0x40(%rbx),%rax
  7e28a8:	test   %rax,%rax
  7e28ab:	jle    7e28c4 <_RNvMsn_NtCscdodAO9FK5_5alloc4syncINtB5_3ArcNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryE9drop_slowBL_+0x64>
  7e28ad:	mov    0x48(%rbx),%rdi
  7e28b1:	shl    $0x2,%rax
  7e28b5:	lea    (%rax,%rax,2),%rsi
  7e28b9:	mov    $0x4,%edx
  7e28be:	call   *0x2d79bc(%rip)        # aba280 <_DYNAMIC+0x240>
  7e28c4:	cmp    $0xffffffffffffffff,%rbx
  7e28c8:	je     7e28e5 <_RNvMsn_NtCscdodAO9FK5_5alloc4syncINtB5_3ArcNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryE9drop_slowBL_+0x85>
  7e28ca:	lock decq 0x8(%rbx)
  7e28cf:	jne    7e28e5 <_RNvMsn_NtCscdodAO9FK5_5alloc4syncINtB5_3ArcNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout12TextGeometryE9drop_slowBL_+0x85>
  7e28d1:	mov    $0x60,%esi
  7e28d6:	mov    $0x8,%edx
  7e28db:	mov    %rbx,%rdi
  7e28de:	pop    %rbx
  7e28df:	jmp    *0x2d799b(%rip)        # aba280 <_DYNAMIC+0x240>
  7e28e5:	pop    %rbx
  7e28e6:	ret

<core::iter::adapters::zip::Zip<core::slice::iter::ChunkBy<gpui_canvas::text::layout::Stop, <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#0}>, core::iter::adapters::skip::Skip<core::slice::iter::ChunkBy<gpui_canvas::text::layout::Stop, <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#0}>>> as core::iter::traits::iterator::Iterator>::next bytes=289 frame=24

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007e82d0 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextB1u_>:
  7e82d0:	push   %r15
  7e82d2:	push   %r14
  7e82d4:	push   %rbx
  7e82d5:	mov    0x8(%rsi),%rax
  7e82d9:	test   %rax,%rax
  7e82dc:	je     7e83e4 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextB1u_+0x114>
  7e82e2:	mov    (%rsi),%rbx
  7e82e5:	mov    $0x1,%r14d
  7e82eb:	cmp    $0x1,%rax
  7e82ef:	je     7e8314 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextB1u_+0x44>
  7e82f1:	mov    (%rbx),%ecx
  7e82f3:	lea    0xc(%rbx),%rdx
  7e82f7:	lea    0x1(%rax),%r8
  7e82fb:	nopl   0x0(%rax,%rax,1)
  7e8300:	cmp    (%rdx),%ecx
  7e8302:	jne    7e8314 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextB1u_+0x44>
  7e8304:	inc    %r14
  7e8307:	add    $0xc,%rdx
  7e830b:	dec    %r8
  7e830e:	cmp    $0x2,%r8
  7e8312:	ja     7e8300 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextB1u_+0x30>
  7e8314:	sub    %r14,%rax
  7e8317:	jb     7e83ad <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextB1u_+0xdd>
  7e831d:	lea    (%r14,%r14,2),%rcx
  7e8321:	lea    (%rbx,%rcx,4),%rcx
  7e8325:	mov    %rcx,(%rsi)
  7e8328:	mov    %rax,0x8(%rsi)
  7e832c:	lea    0x10(%rsi),%rax
  7e8330:	mov    0x20(%rsi),%rcx
  7e8334:	test   %rcx,%rcx
  7e8337:	jne    7e83c6 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextB1u_+0xf6>
  7e833d:	mov    0x18(%rsi),%rcx
  7e8341:	test   %rcx,%rcx
  7e8344:	je     7e8391 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextB1u_+0xc1>
  7e8346:	mov    (%rax),%rax
  7e8349:	mov    $0x1,%edx
  7e834e:	cmp    $0x1,%rcx
  7e8352:	je     7e8375 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextB1u_+0xa5>
  7e8354:	mov    (%rax),%r8d
  7e8357:	lea    0xc(%rax),%r9
  7e835b:	lea    0x1(%rcx),%r10
  7e835f:	nop
  7e8360:	cmp    (%r9),%r8d
  7e8363:	jne    7e8375 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextB1u_+0xa5>
  7e8365:	inc    %rdx
  7e8368:	add    $0xc,%r9
  7e836c:	dec    %r10
  7e836f:	cmp    $0x2,%r10
  7e8373:	ja     7e8360 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextB1u_+0x90>
  7e8375:	sub    %rdx,%rcx
  7e8378:	jb     7e83ad <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextB1u_+0xdd>
  7e837a:	lea    (%rdx,%rdx,2),%r8
  7e837e:	lea    (%rax,%r8,4),%r8
  7e8382:	mov    %r8,0x10(%rsi)
  7e8386:	mov    %rcx,0x18(%rsi)
  7e838a:	test   %rax,%rax
  7e838d:	jne    7e8398 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextB1u_+0xc8>
  7e838f:	jmp    7e83e4 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextB1u_+0x114>
  7e8391:	xor    %eax,%eax
  7e8393:	test   %rax,%rax
  7e8396:	je     7e83e4 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextB1u_+0x114>
  7e8398:	mov    %rbx,(%rdi)
  7e839b:	mov    %r14,0x8(%rdi)
  7e839f:	mov    %rax,0x10(%rdi)
  7e83a3:	mov    %rdx,0x18(%rdi)
  7e83a7:	pop    %rbx
  7e83a8:	pop    %r14
  7e83aa:	pop    %r15
  7e83ac:	ret
  7e83ad:	lea    -0x4d6a4d(%rip),%rdi        # 311967 <_RNvNtCsghYClfd3M9V_11gpui_canvas4text13PRIMARY_BYTES+0x1f463f>
  7e83b4:	lea    0x2b64b5(%rip),%rdx        # a9e870 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0x1a08>
  7e83bb:	mov    $0x13,%esi
  7e83c0:	call   *0x2d1ef2(%rip)        # aba2b8 <_DYNAMIC+0x278>
  7e83c6:	movq   $0x0,0x20(%rsi)
  7e83ce:	mov    %rdi,%r15
  7e83d1:	mov    %rax,%rdi
  7e83d4:	mov    %rcx,%rsi
  7e83d7:	call   7e8d00 <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthBR_>
  7e83dc:	mov    %r15,%rdi
  7e83df:	test   %rax,%rax
  7e83e2:	jne    7e8398 <_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zipINtB4_3ZipINtNtNtBa_5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtB1q_11interactionNtB1q_12TextGeometry9intervals0EINtNtB6_4skip4SkipBV_EENtNtNtB8_6traits8iterator8Iterator4nextB1u_+0xc8>
  7e83e4:	movq   $0x0,(%rdi)
  7e83eb:	pop    %rbx
  7e83ec:	pop    %r14
  7e83ee:	pop    %r15
  7e83f0:	ret

<core::slice::iter::ChunkBy<gpui_canvas::text::layout::Stop, <gpui_canvas::text::layout::TextGeometry>::intervals::{closure#0}> as core::iter::traits::iterator::Iterator>::nth bytes=232 frame=8

/tmp/gpui-text-selection-foundation-evidence/matched-release-codegen-final/baseline-codegen-canonical-text-public-control:     file format elf64-x86-64


Disassembly of section .text:

00000000007e8d00 <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthBR_>:
  7e8d00:	push   %rax
  7e8d01:	mov    (%rdi),%rax
  7e8d04:	mov    0x8(%rdi),%r8
  7e8d08:	nopl   0x0(%rax,%rax,1)
  7e8d10:	mov    %r8,%rcx
  7e8d13:	mov    %rax,%r9
  7e8d16:	mov    %r8,%r10
  7e8d19:	cmp    $0x1,%r8
  7e8d1d:	je     7e8d54 <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthBR_+0x54>
  7e8d1f:	test   %rcx,%rcx
  7e8d22:	je     7e8dcb <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthBR_+0xcb>
  7e8d28:	mov    (%r9),%eax
  7e8d2b:	lea    0xc(%r9),%rdx
  7e8d2f:	lea    0x1(%rcx),%r8
  7e8d33:	mov    $0x1,%r10d
  7e8d39:	nopl   0x0(%rax)
  7e8d40:	cmp    (%rdx),%eax
  7e8d42:	jne    7e8d54 <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthBR_+0x54>
  7e8d44:	inc    %r10
  7e8d47:	add    $0xc,%rdx
  7e8d4b:	dec    %r8
  7e8d4e:	cmp    $0x2,%r8
  7e8d52:	ja     7e8d40 <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthBR_+0x40>
  7e8d54:	mov    %rcx,%r8
  7e8d57:	sub    %r10,%r8
  7e8d5a:	jb     7e8dcf <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthBR_+0xcf>
  7e8d5c:	lea    (%r10,%r10,2),%r11
  7e8d60:	lea    (%r9,%r11,4),%rax
  7e8d64:	mov    %rax,(%rdi)
  7e8d67:	mov    %r8,0x8(%rdi)
  7e8d6b:	dec    %rsi
  7e8d6e:	jne    7e8d10 <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthBR_+0x10>
  7e8d70:	test   %r8,%r8
  7e8d73:	je     7e8dcb <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthBR_+0xcb>
  7e8d75:	mov    %r8,%rdx
  7e8d78:	cmp    $0x1,%r8
  7e8d7c:	je     7e8db5 <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthBR_+0xb5>
  7e8d7e:	mov    (%rax),%esi
  7e8d80:	lea    (%r9,%r11,4),%r9
  7e8d84:	add    $0xc,%r9
  7e8d88:	sub    %r10,%rcx
  7e8d8b:	inc    %rcx
  7e8d8e:	mov    $0x1,%edx
  7e8d93:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  7e8da0:	cmp    (%r9),%esi
  7e8da3:	jne    7e8db5 <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthBR_+0xb5>
  7e8da5:	inc    %rdx
  7e8da8:	add    $0xc,%r9
  7e8dac:	dec    %rcx
  7e8daf:	cmp    $0x2,%rcx
  7e8db3:	ja     7e8da0 <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthBR_+0xa0>
  7e8db5:	sub    %rdx,%r8
  7e8db8:	jb     7e8dcf <_RNvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7ChunkByNtNtNtCsghYClfd3M9V_11gpui_canvas4text6layout4StopNCNvMs_NtBN_11interactionNtBN_12TextGeometry9intervals0ENtNtNtNtB9_4iter6traits8iterator8Iterator3nthBR_+0xcf>
  7e8dba:	lea    (%rdx,%rdx,2),%rcx
  7e8dbe:	lea    (%rax,%rcx,4),%rcx
  7e8dc2:	mov    %rcx,(%rdi)
  7e8dc5:	mov    %r8,0x8(%rdi)
  7e8dc9:	pop    %rcx
  7e8dca:	ret
  7e8dcb:	xor    %eax,%eax
  7e8dcd:	pop    %rcx
  7e8dce:	ret
  7e8dcf:	lea    -0x4d746f(%rip),%rdi        # 311967 <_RNvNtCsghYClfd3M9V_11gpui_canvas4text13PRIMARY_BYTES+0x1f463f>
  7e8dd6:	lea    0x2b5a93(%rip),%rdx        # a9e870 <_RNvNtCslbxve4rcJus_4gpui8property9WRAP_DECL+0x1a08>
  7e8ddd:	mov    $0x13,%esi
  7e8de2:	call   *0x2d14d0(%rip)        # aba2b8 <_DYNAMIC+0x278>
