from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile
import tomllib

root = Path('/root/gpui-ce3')
pin = '4f9378d457a310517432aba95db3f4edbdf80408'
review_pin = 'd483cd70a216cc576809a8be39228f59088175c7'
git = ['git', '-c', f'safe.directory={root}', '-C', str(root)]
assert subprocess.check_output(git + ['rev-parse', 'HEAD'], text=True).strip() == pin
assert not subprocess.check_output(git + ['status', '--porcelain'], text=True).strip()
sha = lambda data: hashlib.sha256(data).hexdigest()
read_json = lambda path: json.loads(Path(path).read_text())
out = Path('/tmp/gpui-remote-adoption-capsule-root')
out.mkdir()
raw = out / 'raw'
raw.mkdir()

def copy_file(source, name):
    destination = raw / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)

gates = {}
for name in ['build', 'execute', 'strict', 'hummingbird']:
    directory = Path(f'/tmp/gpui-remote-main-{name}-root')
    result = read_json(directory / 'result.json')
    assert result['exit'] == 0 and result['guards_match'] and result['source'] == pin
    assert read_json(directory / 'before.json') == read_json(directory / 'after.json')
    gates[name] = result
    for path in directory.iterdir():
        if path.is_file():
            copy_file(path, f'main-{name}/{path.name}')

build_inputs = read_json('/tmp/gpui-remote-main-build-root/before.json')
review = read_json('/tmp/gpui-remote-composed-d483cd7-manifest.json')
differences = [name for name, digest in review['input_hashes'].items()
               if build_inputs[name] != digest]
assert differences == ['reactivity/crates/ownership-lab/tests/native_question_mailbox.rs']
expected_test = subprocess.check_output(git + ['show', pin + ':' + differences[0]])
assert expected_test == subprocess.check_output(git + ['show', '7410240e39d6130a4447ba3445f50c17cfb59298:' + differences[0]])

lock_path = 'reactivity/ports/hummingbird/Cargo.lock'
before_lock = tomllib.loads(subprocess.check_output(git + ['show', '0843c81cdc6b5cc58497d63f8157b24c1b87dca0:' + lock_path], text=True))
after_lock = tomllib.loads((root / lock_path).read_text())
gpui_package = next(package for package in before_lock['package'] if package['name'] == 'gpui')
gpui_package['dependencies'].append('parking_lot')
gpui_package['dependencies'].sort()
assert before_lock == after_lock

executables = Path('/tmp/gpui-remote-main-executables-root')
execution = read_json(executables / 'result.json')
assert execution['all_exit_zero'] and execution['passed'] == 244 and execution['failed'] == 0
external = []
for path in sorted(executables.rglob('*')):
    if not path.is_file():
        continue
    if path.name == 'test':
        identity = read_json(path.parent / 'binary.json')
        assert sha(path.read_bytes()) == identity['sha256'] and not identity['fresh']
        external.append(identity)
    else:
        copy_file(path, 'main-executables/' + str(path.relative_to(executables)))

mac = Path('/tmp/gpui-remote-mac-sol-20261024')
receipt = read_json(mac / 'capsule-receipt.json')
log_receipt = receipt['capsules']['logs']
assert sha((mac / 'logs-capsule.tar.gz').read_bytes()) == log_receipt['sha256']
with tarfile.open(mac / 'logs-capsule.tar.gz') as archive:
    members = {member.name: sha(archive.extractfile(member).read()) for member in archive if member.isfile()}
assert members == log_receipt['members_sha256']
native = read_json(mac / 'qualification-summary.json')
assert native['candidate'] == review_pin and native['native']['passed'] == 719
assert native['native']['all_exits_zero'] and native['native']['source_and_binary_hashes_match']
for name in ['logs-capsule.tar.gz', 'capsule-receipt.json', 'qualification-summary.json', 'report.md', 'process-completion.json']:
    copy_file(mac / name, 'mac/' + name)
for source, name in [
    ('/tmp/gpui-remote-main-adoption-root.json', 'adoption.json'),
    ('/tmp/gpui-remote-main-core-lines-root.json', 'core-lines.json'),
    ('/tmp/gpui-remote-composed-d483cd7-manifest.json', 'review-manifest.json'),
    ('/tmp/gpui-remote-parking-sol-manifest.json', 'original-linux-manifest.json'),
    ('/tmp/gpui-remote-parking-sol-dependency-charge.json', 'dependency-charge.json'),
    ('/tmp/gpui-run-frozen-gate-root.py', 'helpers/frozen-gate.py'),
    ('/tmp/gpui-run-cargo-test-artifacts-root.py', 'helpers/execute-artifacts.py'),
    (__file__, 'helpers/seal.py'),
]:
    copy_file(source, name)

core = read_json(raw / 'core-lines.json')
assert core['core_non_test_code_lines'] == 34899
members = {str(path.relative_to(raw)): sha(path.read_bytes())
           for path in sorted(raw.rglob('*')) if path.is_file()}
archive_path = out / 'logs.tar.gz'
with tarfile.open(archive_path, 'w:gz') as archive:
    for name in members:
        archive.add(raw / name, arcname=name, recursive=False)
with tarfile.open(archive_path) as archive:
    assert {member.name: sha(archive.extractfile(member).read())
            for member in archive if member.isfile()} == members
report = {
    'adopted_source': pin,
    'native_review_source': review_pin,
    'composition': {
        'review_build_inputs': len(review['input_hashes']),
        'main_build_and_port_inputs': len(build_inputs),
        'only_review_input_difference': differences,
        'difference_scope': 'Previously qualified test-only Clippy style correction; shipping inputs byte-identical.',
        'standalone_lock_change': 'Only the GPUI parking_lot dependency edge; no package/version/source/checksum changes.',
    },
    'main_gates': gates,
    'main_execution': execution,
    'main_external_linux_executables': external,
    'mac_qualification': native,
    'core_lines': {'before': 34902, 'after': 34899, 'delta': -3, 'library_build_scripts': 18, 'exclusions': core['excluded']},
    'costs': native['costs'],
    'log_archive': {'file': 'logs.tar.gz', 'bytes': archive_path.stat().st_size, 'sha256': sha(archive_path.read_bytes()), 'members_sha256': members},
    'limits': native['limits'] + [
        'Default dependency source charge is separate from seven-library core and native release size.',
        'The full Linux default suite is the original byte-identical Remote candidate; Main reran the 244 affected cases and strict checks.',
        'Main Hummingbird gate checks all default targets; it is not a whole-player port or native playback qualification.',
        'Five actual Main Linux executables remain frozen externally at their recorded local paths; the complete 76-artifact native capsule remains on the Mac.',
    ],
}
(out / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'archive': str(archive_path), 'bytes': archive_path.stat().st_size,
                  'sha256': report['log_archive']['sha256'], 'members': len(members),
                  'main_passed': execution['passed'], 'native_passed': native['native']['passed']}))
