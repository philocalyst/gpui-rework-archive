The Remote parking-lot change is implemented and qualified at `d483cd70a216cc576809a8be39228f59088175c7`, directly on `c210a5e8342cb38940c697e65aa209c1d9f56edf`. The clean review worktree is `/tmp/gpui-remote-composed-review-sol-20261024`. Main was not edited. Its four changed files are byte-identical to the original independently qualified Remote candidate `094cf928636a2c6ee2b55595f442d7c73a137e30`.

`Shared` now holds the existing `State<VecDeque<T>>` behind `AssertUnwindSafe<parking_lot::Mutex<_>>`; all queue operations retain their original lock boundaries. The private wrapper preserves std-mutex unwind auto-traits, including public `Remote<Cell<u8>>` and `Inbox<Cell<u8>>` certificates. No callback or payload destructor runs under the lock. Checked producer overflow panics before state assignment and leaves the queue usable. There is no new unsafe, queue algorithm, capacity relaxation, public API, or broader Sync bound. Capacity zero, ZST capacity, exact frozen prefix, FIFO, failed-send ownership, close/drop, reentrant destructors and panic cases retain their established tests. The obsolete poisoning recovery helper is deleted. No allocation assertion was changed.

Actual Darwin native GPUI qualification passed **719 tests, zero failures, 12 ignored, across all 70 test executables**. All executables and the changed GPUI library were rebuilt after an explicit dev-profile package clean; Cargo JSON records `fresh: false`. Each actual Mach-O was moved out of the target, frozen and hashed before execution. The job took SH host leases for builds and EX leases for execution, used four jobs with incremental/debug disabled, enforced a 20 GiB free-space floor, and bounded/reaped subprocess groups. All 2,062 guarded source inputs for each of the candidate, c210 baseline and test-only baseline match after qualification; every actual executable hash matches. The Reader first-poll test also passed with zero allocations, a 32-byte wrapper and 16-byte Completion. The gate ran the ordinary nonignored native GPUI suite; it did not execute doctests or reinterpret ignored tests.

The matched std-mutex ledger is `249c969f17149a7a8753614b78addd0556d861eb`, a test-only child of c210. Both unchanged allocation assertions reproduced their original failures, with exactly one allocation versus zero expected: `remote::tests::preallocated_frozen_prefix_has_no_per_message_allocations` and public `preallocated_transport_and_idle_turns_do_not_allocate`. Their actual failed executables, stdout and stderr are preserved. Both pass in the candidate's full native suite.

| Actual native measurement | std mutex | parking_lot |
| --- | ---: | ---: |
| Mutex<State<u64>> | 72 B | 64 B |
| Shared<u64> | 112 B | 104 B |
| Remote / Inbox / lane | 8 / 24 / 40 B | 8 / 24 / 40 B |
| Capacity 0 cold allocation | 1 / 128 B | 1 / 120 B |
| Capacity 1 cold allocation | 2 / 136 B | 2 / 128 B |
| Capacity 8 cold allocation | 2 / 192 B | 2 / 184 B |
| First send, each capacity | 1 / 64 B | 0 / 0 B |
| Untouched first stage, each capacity | 1 / 64 B | 0 / 0 B |
| Untouched first close, each capacity | 1 / 64 B | 0 / 0 B |
| Stage/pop after first send | 0 / 0 B | 0 / 0 B |

These are unbound, uncontended measurements at capacities 0, 1 and 8. Attached OS wake posting remains a separate allocation boundary. Linux's corresponding first-use ledger was already zero and remains zero; its Shared/Mutex sizes remain 64 B. There is no universal or contended allocation claim.

The existing native `empty` example was built in matched release profiles against c210 and the candidate, with identical feature sets, fixture/support-file hashes, flags and pinned toolchain. Both changed libraries and examples were fresh; both actual release Mach-Os were frozen before another profile clean. The examples were inspected and never launched. Whole file size is **15,927,056 → 15,927,136 B (+80)**. `__TEXT,__text` is **6,162,224 → 6,162,288 B (+64)**. `__TEXT`, `__DATA_CONST`, `__DATA` and `__LINKEDIT` segment sizes are unchanged. The example does not exercise Remote, so this is the requested shipping example size check, not a Remote workload or speed claim. Absolute source roots and crate identities differ and are recorded in Cargo JSON.

The optimized public Remote probe was independently compiled against each actual release build. Its ARM Mach-O object `.text` is **5,440 → 5,068 B (-372)** and whole object **21,648 → 20,616 B (-1,032)**. Actual symbol ranges and assembly are retained:

| Public operation | Code bytes before → after | Own stack frame before → after |
| --- | ---: | ---: |
| try_send | 384 → 352 | 64 → 48 |
| clone | 268 → 228 | 48 → 32 |
| bounded | 304 → 308 | 176 → 176 |
| receiver drop | 300 → 260 | 80 → 96 |

The Remote lock-bearing leaf functions replace std's pthread-lock calls and global panic-count reads with byte CAS fast paths plus parking_lot slow calls. Native Wake and its unrelated std synchronization remain present. These are function frames and instruction footprints, not total call-chain stack or CPU timing. No CPU speedup, display latency or VoiceOver claim is made.

First-party shipping core is **34,902 → 34,899 non-test/non-comment lines**; `remote.rs` is **474 → 471**. Native adds **zero dependency packages**, because parking_lot 0.12.5 is already in the GPU graph. Default adds **five runtime packages** and a conservative **7,470 dependency source lines**: parking_lot, parking_lot_core, lock_api, scopeguard and cfg-if. No versions were upgraded. The prior Linux optimized public driver over debug-built dependencies grew **67,897 text / 4,176 data / 1,712 bss bytes**; that material default-profile cost is separate from the native release result. Dependency source accounting and per-file hashes are in `/tmp/gpui-remote-parking-sol-dependency-charge.json`.

The original 094 candidate passed Linux default execution/doc gates (677 passed, 10 ignored, 72 harnesses), strict all-target Clippy, Linux X11 native metadata, and Windows MSVC default/native all-target metadata checks. Windows results are compile checks. These gates precede composition with Root's c210 Reader correction; the Remote files are byte-identical. All original source guards, actual baseline/candidate Linux executables and the original frozen source archives remain preserved. Composed-source evidence is `/tmp/gpui-remote-composed-d483cd7-manifest.json`; local original gates and their limits are `/tmp/gpui-remote-parking-sol-manifest.json`.

The first auxiliary release assembly command failed because this pinned nightly's thin rlib contains only a metadata stub. Its command, stderr and original failed status are retained. Resuming against Cargo's full `.rmeta` succeeded without source changes or overwriting the release executable. Raw final `status.json` intentionally retains the original error field alongside `state: complete` and the explicit recovered-failure flag; `qualification-summary.json` separates that recovered harness failure from the passing product gates.

The complete capsule is on Mac at `/Users/mileswirht/gpui-reactivity-20261024-root/remote-d483cd70-sol/complete-capsule.tar.gz`: **677,114,639 B**, SHA-256 **64ff130fd9354232574c5f1c51c98b684e01a184ef3c5fd100b1dfc60a9d1eb3**. It contains all guarded source files for all three exact variants, Cargo JSON/commands/raw logs, all 70 candidate and two std-control test Mach-Os, both release example Mach-Os, both optimized probe objects and assembly: 76 actual Mach-O files/objects in total. This is a guarded-source and actual-artifact capsule; registry source/toolchain bytes are outside the closure, with lockfile checksums and pinned toolchain identity recorded. It is preserved remotely to avoid transferring 677 MB through 24 KiB RPC chunks.

The full member/hash receipt is local at `/tmp/gpui-remote-mac-sol-20261024/capsule-receipt.json` (SHA-256 `b789358e27529224cf29562a8552f7a8f6d448ddf6452710b38b0c33c494be5b`). The local verified logs capsule `/tmp/gpui-remote-mac-sol-20261024/logs-capsule.tar.gz` is **488,931 B**, SHA-256 **0da5bfee75405ab6357c2f12cb4d792f4e4fe1e6e54c74ac183ec81d258b8ec2**. Its 382 extracted members are verified in `/tmp/gpui-remote-mac-sol-20261024/extracted`. Raw actual source manifests, binary hashes, Cargo artifacts and logs are inspectable there. Machine-readable costs and scope are in `/tmp/gpui-remote-mac-sol-20261024/qualification-summary.json`. All owned Mac build, execution and pack processes finished; no Main, Root stager, existing failure evidence, permission state or unrelated process was changed.
