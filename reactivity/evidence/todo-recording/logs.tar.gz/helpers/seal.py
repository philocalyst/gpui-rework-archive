from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile

root = Path('/root/gpui-ce3')
git = ['git', '-c', f'safe.directory={root}', '-C', str(root)]
pin = '5222d7cfb790ecee1a74e8fef297ed6afb9f04d2'
sha = lambda path: hashlib.file_digest(Path(path).open('rb'), 'sha256').hexdigest()
load = lambda path: json.loads(Path(path).read_text())
out = Path('/tmp/gpui-heavy-recording-capsule-root')
raw = out / 'raw'
raw.mkdir(parents=True)

def copy(source, name):
    destination = raw / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)

gates = {}
for name in ['build', 'execute', 'strict']:
    directory = Path(f'/tmp/gpui-heavy-recording-main-{name}-root')
    result = load(directory / 'result.json')
    assert result['exit'] == 0 and result['guards_match'] and result['source'] == pin
    assert load(directory / 'before.json') == load(directory / 'after.json')
    gates[name] = result
    for path in directory.iterdir():
        if path.is_file():
            copy(path, f'main-{name}/{path.name}')

for directory_name in ['gpui-heavy-recording-build-root', 'gpui-heavy-recording-full-model-strict-root', 'gpui-heavy-recording-full-model-strict-corrected-root']:
    directory = Path('/tmp') / directory_name
    for path in directory.iterdir():
        if path.is_file():
            copy(path, f'attempts/{directory_name}/{path.name}')

external = []
for label in ['full-model', 'final', 'main']:
    directory = Path(f'/tmp/gpui-heavy-recording-{label}-executables-root')
    identity = load(directory / 'binary.json')
    assert sha(directory / 'todo_recording_cost') == identity['sha256']
    assert not identity['cargo']['fresh'] and identity['cargo']['profile']['opt_level'] == '3'
    assert all(row['validated'] and row['exit'] == 0 for row in load(directory / 'result.json')['results'])
    external.append({'path': str(directory / 'todo_recording_cost'), **identity})
    for path in directory.iterdir():
        if path.is_file() and path.name != 'todo_recording_cost':
            copy(path, f'executables-{label}/{path.name}')

remote = Path('/tmp/gpui-heavy-recording-mothership-results-root')
measured = load(remote / 'result.json')
assert measured['complete'] and measured['all_file_hashes_match'] and measured['cpu_affinity'] == [0]
for row in measured['results']:
    local_path = Path(f'/tmp/gpui-heavy-recording-full-model-executables-root/rows-{row["rows"]}.stdout')
    states = [json.loads(line.split(',', 1)[1]) for line in local_path.read_text().splitlines() if line.startswith('TODO_RECORDING_STATE,')]
    assert row['states'] == states and row['full_model_validated'] and row['binary_hash_matches']
for path in remote.iterdir():
    if path.is_file():
        copy(path, 'mothership/' + path.name)
for name in ['manifest.json', 'run.py', 'binary.json', 'command.json', 'build-result.json', 'source-guard.json']:
    copy(Path('/tmp/gpui-heavy-recording-mothership-stage-root') / name, 'mothership-stage/' + name)

example = 'reactivity/crates/gpui/examples/todo_recording_cost.rs'
assert (root / example).read_bytes() == subprocess.check_output(git + ['show', 'fe4e535c403cae935723adf6005e7345e6bb0cf8:' + example])
copy(root / example, 'todo_recording_cost.rs')
copy('/tmp/gpui-run-frozen-gate-root.py', 'helpers/frozen-gate.py')
copy('/tmp/gpui-run-heavy-recording-v2-root.py', 'helpers/run.py')
copy(__file__, 'helpers/seal.py')
members = {str(path.relative_to(raw)): sha(path) for path in sorted(raw.rglob('*')) if path.is_file()}
archive_path = out / 'logs.tar.gz'
with tarfile.open(archive_path, 'w:gz') as archive:
    for name in members:
        archive.add(raw / name, arcname=name, recursive=False)
with tarfile.open(archive_path) as archive:
    assert {member.name: hashlib.sha256(archive.extractfile(member).read()).hexdigest() for member in archive if member.isfile()} == members
report = {
    'adopted_source': pin,
    'fixture_review_source': 'fe4e535c403cae935723adf6005e7345e6bb0cf8',
    'fixture_bytes_identical': True,
    'main_gates': gates,
    'main_results': load('/tmp/gpui-heavy-recording-main-executables-root/result.json'),
    'actual_frozen_local_executables': external,
    'mothership': {'directory': '/home/miles/gpui-ce3-compute-20261024/evidence/heavy-recording-root-e509', 'source': measured['source'], 'rows': [row['rows'] for row in measured['results']], 'all_states_identical_to_local': True, 'cpu_affinity': measured['cpu_affinity'], 'loader': measured['loader'], 'loader_sha256': measured['loader_sha256']},
    'shipping_library_code_added': 0,
    'log_archive': {'file': 'logs.tar.gz', 'bytes': archive_path.stat().st_size, 'sha256': sha(archive_path), 'members_sha256': members},
    'limits': [
        'Single-process per-size recording diagnostics, not a registered repeated native benchmark.',
        'Recording excludes OS window creation, framebuffer rasterization, GPU and scanout.',
        'Mothership runs the unchanged e509 ELF using its explicit compatible glibc2.44 loader; it is not a native build on that host.',
        'Per-edit allocation counters charge requested calling-thread bytes, not allocator usable size or process RSS.',
        'Main IME adds eight retained bytes to this fixture mount versus the pre-IME baseline, with unchanged allocation count.',
        'Native strict work/latency gates and the historical five-framework failures remain unchanged.',
    ],
}
(out / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'archive': str(archive_path), 'bytes': archive_path.stat().st_size, 'sha256': report['log_archive']['sha256'], 'members': len(members)}))
