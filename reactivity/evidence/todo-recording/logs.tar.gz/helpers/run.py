from pathlib import Path
import argparse
import hashlib
import json
import shutil
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument('--build', type=Path, required=True)
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
build, out = args.build, args.out
assert json.loads((build / 'result.json').read_text())['exit'] == 0
rows = [json.loads(line) for line in (build / 'stdout.log').read_text().splitlines()]
artifact, = [row for row in rows if row.get('reason') == 'compiler-artifact'
             and row.get('executable') and row['target']['name'] == 'todo_recording_cost']
assert not artifact['fresh'] and artifact['profile']['opt_level'] == '3'
out.mkdir()
binary = out / 'todo_recording_cost'
shutil.copy2(artifact['executable'], binary)
binary.chmod(0o555)
digest = hashlib.sha256(binary.read_bytes()).hexdigest()
(out / 'binary.json').write_text(json.dumps({'sha256': digest, 'bytes': binary.stat().st_size,
                                           'cargo': artifact}, indent=2) + '\n')
results = []
for count in [0, 1_000, 10_000]:
    with (out / f'rows-{count}.stdout').open('w') as stdout, (out / f'rows-{count}.stderr').open('w') as stderr:
        result = subprocess.run([str(binary), str(count)], stdout=stdout, stderr=stderr, timeout=180)
    assert hashlib.sha256(binary.read_bytes()).hexdigest() == digest
    output = (out / f'rows-{count}.stdout').read_text()
    record = {'rows': count, 'exit': result.returncode,
              'validated': f'TODO_RECORDING_VALIDATED,rows={count + 1},operations=8' in output,
              'artifact_hash_matches': True}
    results.append(record)
    (out / 'result.json').write_text(json.dumps({'binary_sha256': digest, 'results': results,
                                               'scope': 'Single local recording diagnostics; no native performance inference.'}, indent=2) + '\n')
    print(json.dumps(record), flush=True)
    assert result.returncode == 0 and record['validated'], record
