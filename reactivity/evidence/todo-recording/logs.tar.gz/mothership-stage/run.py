"""Run one sealed ordinary recording fixture under the shared compute lock."""
from pathlib import Path
import datetime
import fcntl
import hashlib
import json
import os
import shutil
import signal
import subprocess
import time

root = Path(__file__).resolve().parent
manifest = json.loads((root / 'manifest.json').read_text())
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
for name, expected in manifest['files'].items():
    assert digest(root / name) == expected, name
loader = Path('/nix/store/pqyiidz5mi73wv5f91d48s9plcqyj5bz-glibc-2.44-57/lib/ld-linux-x86-64.so.2')
library = f'{loader.parent}:/nix/store/8lahnh9pn3lrrnhax5nk7ibvjcbjmnkm-gcc-15.2.0-lib/lib'
output = root / 'run-1'
output.mkdir()
summary = {
    'source': manifest['source'],
    'scope': 'Exclusive-host CPU recording diagnostic; no native rendering, peer, GPU or scanout claim.',
    'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'loader': str(loader),
    'loader_sha256': digest(loader),
    'library_path': library,
    'uname': list(os.uname()),
    'results': [],
}

def save():
    (output / 'result.json').write_text(json.dumps(summary, indent=2) + '\n')

def stop(signum, _):
    raise KeyboardInterrupt(signum)

for signum in [signal.SIGTERM, signal.SIGINT]:
    signal.signal(signum, stop)

save()
with Path('/home/miles/gpui-ce3-compute-20261024/host.lock').open('a') as lease:
    fcntl.flock(lease, fcntl.LOCK_EX)
    assert shutil.disk_usage(root).free >= 8 * 1024**3
    affinity = sorted(os.sched_getaffinity(0))
    os.sched_setaffinity(0, {affinity[0]})
    summary['cpu_affinity'] = sorted(os.sched_getaffinity(0))
    summary['cpuinfo'] = Path('/proc/cpuinfo').read_text()
    summary['locked_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
    environment = {**os.environ, 'LD_LIBRARY_PATH': library}
    listing = subprocess.run([str(loader), '--library-path', library, '--list', str(root / 'todo_recording_cost')], capture_output=True, text=True, env=environment, timeout=20)
    (output / 'loader-list.stdout').write_text(listing.stdout)
    (output / 'loader-list.stderr').write_text(listing.stderr)
    assert listing.returncode == 0
    for rows in [0, 1000, 10000]:
        command = [str(loader), '--library-path', library, str(root / 'todo_recording_cost'), str(rows)]
        started = time.monotonic_ns()
        with (output / f'rows-{rows}.stdout').open('wb') as stdout, (output / f'rows-{rows}.stderr').open('wb') as stderr:
            child = subprocess.Popen(command, stdout=stdout, stderr=stderr, env=environment, start_new_session=True)
            reaped = False
            try:
                while True:
                    pid, status, usage = os.wait4(child.pid, os.WNOHANG)
                    if pid:
                        child.returncode = os.waitstatus_to_exitcode(status)
                        reaped = True
                        break
                    if time.monotonic_ns() - started > 180_000_000_000:
                        raise TimeoutError(f'rows={rows}')
                    time.sleep(0.05)
            finally:
                if not reaped:
                    os.killpg(child.pid, signal.SIGTERM)
                    try:
                        child.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        os.killpg(child.pid, signal.SIGKILL)
                        child.wait()
        text = (output / f'rows-{rows}.stdout').read_text()
        costs = [json.loads(line.split(',', 1)[1]) for line in text.splitlines() if line.startswith('TODO_RECORDING_COST,')]
        states = [json.loads(line.split(',', 1)[1]) for line in text.splitlines() if line.startswith('TODO_RECORDING_STATE,')]
        result = {
            'rows': rows,
            'argv': command,
            'exit': child.returncode,
            'wall_ns': time.monotonic_ns() - started,
            'user_cpu_s': usage.ru_utime,
            'system_cpu_s': usage.ru_stime,
            'max_rss_kib': usage.ru_maxrss,
            'voluntary_context_switches': usage.ru_nvcsw,
            'involuntary_context_switches': usage.ru_nivcsw,
            'full_model_validated': f'TODO_RECORDING_VALIDATED,rows={rows + 1},operations=8' in text,
            'costs': costs,
            'states': states,
            'binary_hash_matches': digest(root / 'todo_recording_cost') == manifest['files']['todo_recording_cost'],
        }
        summary['results'].append(result)
        save()
        assert result['exit'] == 0 and result['full_model_validated'] and result['binary_hash_matches']
        assert len(states) == 9 and all(cost['success'] for cost in costs)
        print(json.dumps({key: result[key] for key in ['rows', 'exit', 'full_model_validated', 'wall_ns', 'max_rss_kib']}), flush=True)
    summary['all_file_hashes_match'] = all(digest(root / name) == expected for name, expected in manifest['files'].items())
    summary['completed_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    summary['complete'] = True
    save()
    assert summary['all_file_hashes_match']
