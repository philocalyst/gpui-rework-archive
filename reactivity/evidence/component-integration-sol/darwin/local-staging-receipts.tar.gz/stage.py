from pathlib import Path
import base64, hashlib, json, subprocess
local = Path('/tmp/gpui-component-review-mac-7a-sol')
remote = '/Users/mileswirht/gpui-reactivity-20261024-root/component-7a2f9325-sol'
payload = (local/'capsule.tar.gz').read_bytes()
digest = hashlib.sha256(payload).hexdigest()
def call(argv, name):
    result = subprocess.run(['rex','--timeout','30s','-C','mac','do','mac.exec','--args',json.dumps({'argv':argv}),'--json'], capture_output=True, text=True, timeout=45)
    (local/(name+'.json')).write_text(result.stdout)
    assert result.returncode == 0, (name,result.stderr)
    value = json.loads(result.stdout)
    assert value.get('ok') and value.get('code') == 0, (name,value)
    return value['stdout']
setup = 'from pathlib import Path;import shutil;p=Path('+repr(remote)+');assert shutil.disk_usage(p.parent).free>20*1024**3;p.mkdir();(p/"capsule.tar.gz.part").touch(exist_ok=False);print(p)'
print(call(['/usr/bin/python3','-c',setup],'setup'),flush=True)
for offset in range(0,len(payload),24576):
    block=payload[offset:offset+24576]
    code='from pathlib import Path;import base64,hashlib;p=Path('+repr(remote+'/capsule.tar.gz.part')+');assert p.stat().st_size=='+str(offset)+';b=base64.b64decode('+repr(base64.b64encode(block).decode())+');assert hashlib.sha256(b).hexdigest()=='+repr(hashlib.sha256(block).hexdigest())+';f=p.open("ab");f.write(b);f.close();print(p.stat().st_size)'
    call(['/usr/bin/python3','-c',code],'chunk-'+str(offset))
extract = '''from pathlib import Path
import hashlib,json,shutil,tarfile
p=Path(REMOTE);top=p.parent
capsule=p/'capsule.tar.gz.part'
assert hashlib.sha256(capsule.read_bytes()).hexdigest()==DIGEST
capsule.rename(p/'capsule.tar.gz')
unpack=p/'incoming';unpack.mkdir()
with tarfile.open(p/'capsule.tar.gz') as tar:
    for member in tar:
        assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
        target=unpack/member.name;target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(tar.extractfile(member).read());target.chmod(member.mode)
before=json.loads((unpack/'before.json').read_text());after=json.loads((unpack/'after.json').read_text());delta=json.loads((unpack/'delta.json').read_text())
base=top/'source'
assert json.loads((base/'source-manifest.json').read_text())==before
for name,h in before.items():assert hashlib.sha256((base/name).read_bytes()).hexdigest()==h,name
source=p/'source';shutil.copytree(base,source)
for name in delta['deleted']:(source/name).unlink()
for name in delta['added']+delta['changed']:
    old=unpack/'overlay'/name;target=source/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(old,target);target.chmod(old.stat().st_mode&0o777)
for name,h in after.items():assert hashlib.sha256((source/name).read_bytes()).hexdigest()==h,name
(source/'source-manifest.json').write_text(json.dumps(after,indent=2)+'\\n')
(source/'source-pin.json').write_text(json.dumps(dict(source=PIN,files=len(after)))+'\\n')
(source/'source-pin.txt').write_text(PIN+'\\n')
print(json.dumps(dict(source=PIN,files=len(after),all_hashes_match=True,capsule_sha256=DIGEST,free_bytes=shutil.disk_usage(p).free)))
'''.replace('REMOTE',repr(remote)).replace('DIGEST',repr(digest)).replace('PIN',repr('7a2f9325440bc4325f423863a443df0ca2f39743'))
print(call(['/usr/bin/python3','-c',extract],'extract'),flush=True)
job=(local/'job.py').read_text()
launch='from pathlib import Path;import subprocess;p=Path('+repr(remote)+');q=p/"job.py";q.write_text('+repr(job)+');log=(p/"launcher.log").open("w");child=subprocess.Popen(["/usr/bin/python3",str(q)],stdout=log,stderr=log,start_new_session=True);print(child.pid)'
print('job PID',call(['/usr/bin/python3','-c',launch],'launch'),flush=True)
