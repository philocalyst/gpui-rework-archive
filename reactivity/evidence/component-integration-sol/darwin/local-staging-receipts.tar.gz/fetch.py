from pathlib import Path
import base64,hashlib,json,subprocess,tarfile
local=Path('/tmp/gpui-component-review-mac-7a-sol')
remote='/Users/mileswirht/gpui-reactivity-20261024-root/component-7a2f9325-sol'
def call(argv,name):
 r=subprocess.run(['rex','--timeout','30s','-C','mac','do','mac.exec','--args',json.dumps({'argv':argv}),'--json'],capture_output=True,text=True,timeout=45)
 (local/(name+'.json')).write_text(r.stdout)
 assert r.returncode==0,(name,r.stderr)
 result=json.loads(r.stdout);assert result.get('ok') and result.get('code')==0,(name,result)
 return result['stdout']
code='''from pathlib import Path
import hashlib,json,tarfile,shutil
p=Path(REMOTE);out=p/'qualification';r=json.loads((out/'status.json').read_text());assert r['state']=='complete'
records=r['binaries']+r['application'];assert len(records)==75
manifest=json.loads((p/'source/source-manifest.json').read_text())
for n,h in manifest.items():assert hashlib.sha256((p/'source'/n).read_bytes()).hexdigest()==h,n
external=[]
for item in records:
 q=out/item['file'];assert hashlib.sha256(q.read_bytes()).hexdigest()==item['sha256'];external.append(dict(path=str(q),bytes=q.stat().st_size,sha256=item['sha256'],name=item['name']))
(out/'external-machos.json').write_text(json.dumps(external,indent=2))
archive=p/'frozen-machos.tar.gz'
assert shutil.disk_usage(p).free>20*1024**3
with tarfile.open(archive,'w:gz',compresslevel=1) as tar:
 for item in external:tar.add(item['path'],arcname=Path(item['path']).name)
record=dict(path=str(archive),bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),members=len(external))
(out/'frozen-archive.json').write_text(json.dumps(record,indent=2))
metadata=p/'metadata.tar.gz';binary_names={x['file'] for x in records}
with tarfile.open(metadata,'w:gz') as tar:
 for q in sorted(out.iterdir()):
  if q.is_file() and q.name not in binary_names:tar.add(q,arcname='qualification/'+q.name)
 for name in ['job.py','launcher.log','source/source-manifest.json','source/source-pin.json','incoming/before.json','incoming/after.json','incoming/delta.json']:tar.add(p/name,arcname=name)
print(json.dumps(dict(path=str(metadata),bytes=metadata.stat().st_size,sha256=hashlib.sha256(metadata.read_bytes()).hexdigest(),external_machos=record)))
'''.replace('REMOTE',repr(remote))
receipt=json.loads(call(['/usr/bin/python3','-c',code],'archive-metadata'))
(local/'metadata-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
path=local/'metadata.tar.gz'
assert not path.exists()
with path.open('wb') as file:
 for offset in range(0,receipt['bytes'],24576):
  script='from pathlib import Path;import base64;p=Path('+repr(receipt['path'])+');f=p.open("rb");f.seek('+str(offset)+');print(base64.b64encode(f.read(24576)).decode())'
  block=base64.b64decode(call(['/usr/bin/python3','-c',script],'fetch-'+str(offset)).strip());file.write(block)
assert hashlib.sha256(path.read_bytes()).hexdigest()==receipt['sha256']
extracted=local/'collected';extracted.mkdir()
with tarfile.open(path) as tar:
 for member in tar:
  assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
  q=extracted/member.name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(tar.extractfile(member).read())
print(json.dumps(receipt))
