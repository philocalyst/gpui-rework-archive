from pathlib import Path
import base64,hashlib,json,subprocess,tarfile
local=Path('/tmp/gpui-component-review-mac-7a-sol')
receipt=json.loads((local/'metadata-receipt.json').read_text())
path=local/'metadata.tar.gz'
assert not path.exists()
with path.open('wb') as file:
 for offset in range(0,receipt['bytes'],24576):
  script='from pathlib import Path;import base64;p=Path('+repr(receipt['path'])+');f=p.open("rb");f.seek('+str(offset)+');print(base64.b64encode(f.read(24576)).decode())'
  r=subprocess.run(['rex','--timeout','30s','-C','mac','do','mac.exec','--args',json.dumps({'argv':['/usr/bin/python3','-c',script]}),'--json'],capture_output=True,text=True,timeout=45)
  (local/('fetch-'+str(offset)+'.json')).write_text(r.stdout)
  assert r.returncode==0,(offset,r.stderr)
  result=json.loads(r.stdout);assert result.get('ok') and result.get('code')==0,(offset,result)
  file.write(base64.b64decode(result['stdout'].strip()))
assert hashlib.sha256(path.read_bytes()).hexdigest()==receipt['sha256']
extracted=local/'collected';extracted.mkdir()
with tarfile.open(path) as tar:
 for member in tar:
  assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
  q=extracted/member.name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(tar.extractfile(member).read())
print(json.dumps(receipt))
