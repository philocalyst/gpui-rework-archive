from pathlib import Path
import sys,json
root=Path('/root/gpui-component-review-sol-20261024')
sys.path.insert(0,str(root/'reactivity/tools'))
import core_lines
helper=Path('/tmp/gpui-inventory-sol-target/release/inventory-rust')
tokei=Path('/nix/store/4m90mv0fyihsdrnidw8gkgmx6zvd5vqm-tokei-15.0.0/bin/tokei')
a=core_lines.count('HEAD',False,helper,tokei)
core_lines.LIBRARIES=('component',)
b=core_lines.count('HEAD',False,helper,tokei)
r={'core':a,'component':b}
Path('/tmp/gpui-component-review-inventory.json').write_text(json.dumps(r,indent=2)+'\n')
print(a['core_non_test_code_lines'],b['core_non_test_code_lines'])
