
/tmp/gpui-shared-gpu-controls/baseline/owned:     file format elf64-x86-64


Disassembly of section .text:

0000000000845e90 <<gpui_gpu::renderer::Renderer>::redraw>:
  845e90:	48 89 f8             	mov    %rdi,%rax
  845e93:	48 83 be 48 03 00 00 	cmpq   $0x0,0x348(%rsi)
  845e9a:	00 
  845e9b:	0f 84 00 01 00 00    	je     845fa1 <<gpui_gpu::renderer::Renderer>::redraw+0x111>
  845ea1:	8b 8e 50 03 00 00    	mov    0x350(%rsi),%ecx
  845ea7:	8b be 54 03 00 00    	mov    0x354(%rsi),%edi
  845ead:	81 e1 ff ff ff 7f    	and    $0x7fffffff,%ecx
  845eb3:	48 c1 e7 20          	shl    $0x20,%rdi
  845eb7:	48 09 cf             	or     %rcx,%rdi
  845eba:	b9 03 00 00 00       	mov    $0x3,%ecx
  845ebf:	48 39 7a 20          	cmp    %rdi,0x20(%rdx)
  845ec3:	0f 85 e8 00 00 00    	jne    845fb1 <<gpui_gpu::renderer::Renderer>::redraw+0x121>
  845ec9:	8b 7a 38             	mov    0x38(%rdx),%edi
  845ecc:	3b be 58 03 00 00    	cmp    0x358(%rsi),%edi
  845ed2:	0f 85 d9 00 00 00    	jne    845fb1 <<gpui_gpu::renderer::Renderer>::redraw+0x121>
  845ed8:	83 ff 4c             	cmp    $0x4c,%edi
  845edb:	75 23                	jne    845f00 <<gpui_gpu::renderer::Renderer>::redraw+0x70>
  845edd:	f3 0f 7e 42 3c       	movq   0x3c(%rdx),%xmm0
  845ee2:	f3 0f 7e 8e 5c 03 00 	movq   0x35c(%rsi),%xmm1
  845ee9:	00 
  845eea:	66 0f 76 c8          	pcmpeqd %xmm0,%xmm1
  845eee:	66 0f 70 c1 50       	pshufd $0x50,%xmm1,%xmm0
  845ef3:	66 0f 50 f8          	movmskpd %xmm0,%edi
  845ef7:	83 ff 03             	cmp    $0x3,%edi
  845efa:	0f 85 b1 00 00 00    	jne    845fb1 <<gpui_gpu::renderer::Renderer>::redraw+0x121>
  845f00:	41 56                	push   %r14
  845f02:	53                   	push   %rbx
  845f03:	50                   	push   %rax
  845f04:	48 89 c3             	mov    %rax,%rbx
  845f07:	48 8d 86 48 03 00 00 	lea    0x348(%rsi),%rax
  845f0e:	48 89 f7             	mov    %rsi,%rdi
  845f11:	49 89 f6             	mov    %rsi,%r14
  845f14:	48 89 d6             	mov    %rdx,%rsi
  845f17:	48 89 c2             	mov    %rax,%rdx
  845f1a:	e8 e1 24 00 00       	call   848400 <<gpui_gpu::renderer::Renderer>::submit>
  845f1f:	48 89 c1             	mov    %rax,%rcx
  845f22:	49 8b 96 60 01 00 00 	mov    0x160(%r14),%rdx
  845f29:	49 8b 86 40 03 00 00 	mov    0x340(%r14),%rax
  845f30:	48 ff c2             	inc    %rdx
  845f33:	48 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%rsi
  845f3a:	48 0f 45 f2          	cmovne %rdx,%rsi
  845f3e:	49 89 b6 60 01 00 00 	mov    %rsi,0x160(%r14)
  845f45:	41 c6 86 20 02 00 00 	movb   $0x1,0x220(%r14)
  845f4c:	01 
  845f4d:	49 c7 86 b8 01 00 00 	movq   $0x0,0x1b8(%r14)
  845f54:	00 00 00 00 
  845f58:	49 c7 86 e0 01 00 00 	movq   $0x0,0x1e0(%r14)
  845f5f:	00 00 00 00 
  845f63:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
  845f67:	66 41 0f 11 86 68 01 	movupd %xmm0,0x168(%r14)
  845f6e:	00 00 
  845f70:	49 c7 86 78 01 00 00 	movq   $0x0,0x178(%r14)
  845f77:	00 00 00 00 
  845f7b:	48 85 c0             	test   %rax,%rax
  845f7e:	74 08                	je     845f88 <<gpui_gpu::renderer::Renderer>::redraw+0xf8>
  845f80:	48 c7 40 60 00 00 00 	movq   $0x0,0x60(%rax)
  845f87:	00 
  845f88:	48 89 d8             	mov    %rbx,%rax
  845f8b:	48 c7 43 08 01 00 00 	movq   $0x1,0x8(%rbx)
  845f92:	00 
  845f93:	ba 10 00 00 00       	mov    $0x10,%edx
  845f98:	48 83 c4 08          	add    $0x8,%rsp
  845f9c:	5b                   	pop    %rbx
  845f9d:	41 5e                	pop    %r14
  845f9f:	eb 07                	jmp    845fa8 <<gpui_gpu::renderer::Renderer>::redraw+0x118>
  845fa1:	ba 08 00 00 00       	mov    $0x8,%edx
  845fa6:	31 c9                	xor    %ecx,%ecx
  845fa8:	48 89 0c 10          	mov    %rcx,(%rax,%rdx,1)
  845fac:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
  845fb1:	89 08                	mov    %ecx,(%rax)
  845fb3:	c3                   	ret
