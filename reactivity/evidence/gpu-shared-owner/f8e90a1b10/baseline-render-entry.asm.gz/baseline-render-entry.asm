
/tmp/gpui-shared-gpu-controls/baseline/owned:     file format elf64-x86-64


Disassembly of section .text:

0000000000845fc0 <<gpui_gpu::renderer::Renderer>::render>:
  845fc0:	55                   	push   %rbp
  845fc1:	41 57                	push   %r15
  845fc3:	41 56                	push   %r14
  845fc5:	41 55                	push   %r13
  845fc7:	41 54                	push   %r12
  845fc9:	53                   	push   %rbx
  845fca:	48 81 ec 58 05 00 00 	sub    $0x558,%rsp
  845fd1:	48 8d 9e 48 03 00 00 	lea    0x348(%rsi),%rbx
  845fd8:	48 8b 86 48 03 00 00 	mov    0x348(%rsi),%rax
  845fdf:	48 85 c0             	test   %rax,%rax
  845fe2:	74 27                	je     84600b <<gpui_gpu::renderer::Renderer>::render+0x4b>
  845fe4:	f0 48 ff 08          	lock decq (%rax)
  845fe8:	75 21                	jne    84600b <<gpui_gpu::renderer::Renderer>::render+0x4b>
  845fea:	49 89 fe             	mov    %rdi,%r14
  845fed:	48 89 df             	mov    %rbx,%rdi
  845ff0:	49 89 f4             	mov    %rsi,%r12
  845ff3:	49 89 cd             	mov    %rcx,%r13
  845ff6:	49 89 d7             	mov    %rdx,%r15
  845ff9:	ff 15 f9 8b 67 00    	call   *0x678bf9(%rip)        # ebebf8 <_DYNAMIC+0x4a0>
  845fff:	4c 89 fa             	mov    %r15,%rdx
  846002:	4c 89 e9             	mov    %r13,%rcx
  846005:	4c 89 e6             	mov    %r12,%rsi
  846008:	4c 89 f7             	mov    %r14,%rdi
  84600b:	48 c7 86 48 03 00 00 	movq   $0x0,0x348(%rsi)
  846012:	00 00 00 00 
  846016:	44 8b 2a             	mov    (%rdx),%r13d
  846019:	44 8b 42 08          	mov    0x8(%rdx),%r8d
  84601d:	0f b6 42 0d          	movzbl 0xd(%rdx),%eax
  846021:	45 85 c0             	test   %r8d,%r8d
  846024:	41 0f 98 c1          	sets   %r9b
  846028:	41 81 e0 ff ff ff 7f 	and    $0x7fffffff,%r8d
  84602f:	45 8d 90 00 00 80 ff 	lea    -0x800000(%r8),%r10d
  846036:	41 81 fa 00 00 00 7f 	cmp    $0x7f000000,%r10d
  84603d:	41 0f 92 c2          	setb   %r10b
  846041:	45 20 ca             	and    %r9b,%r10b
  846044:	45 8d 58 ff          	lea    -0x1(%r8),%r11d
  846048:	41 81 fb ff ff 7f 00 	cmp    $0x7fffff,%r11d
  84604f:	41 0f 92 c3          	setb   %r11b
  846053:	45 20 cb             	and    %r9b,%r11b
  846056:	45 85 c0             	test   %r8d,%r8d
  846059:	41 0f 94 c1          	sete   %r9b
  84605d:	41 81 f8 00 00 80 7f 	cmp    $0x7f800000,%r8d
  846064:	40 0f 94 c5          	sete   %bpl
  846068:	44 08 cd             	or     %r9b,%bpl
  84606b:	41 81 f8 01 00 80 7f 	cmp    $0x7f800001,%r8d
  846072:	41 0f 9d c0          	setge  %r8b
  846076:	41 08 e8             	or     %bpl,%r8b
  846079:	45 08 d8             	or     %r11b,%r8b
  84607c:	45 85 ed             	test   %r13d,%r13d
  84607f:	41 0f 95 c1          	setne  %r9b
  846083:	41 20 c1             	and    %al,%r9b
  846086:	45 08 d1             	or     %r10b,%r9b
  846089:	45 08 c1             	or     %r8b,%r9b
  84608c:	41 f6 c1 01          	test   $0x1,%r9b
  846090:	74 1b                	je     8460ad <<gpui_gpu::renderer::Renderer>::render+0xed>
  846092:	c7 07 03 00 00 00    	movl   $0x3,(%rdi)
  846098:	48 89 f8             	mov    %rdi,%rax
  84609b:	48 81 c4 58 05 00 00 	add    $0x558,%rsp
