
/tmp/gpui-shared-gpu-controls/f8e90a1b10/owned:     file format elf64-x86-64


Disassembly of section .text:

0000000000846750 <<gpui_gpu::renderer::RendererState>::redraw>:
  846750:	48 89 f8             	mov    %rdi,%rax
  846753:	4c 8b 86 20 03 00 00 	mov    0x320(%rsi),%r8
  84675a:	bf 04 00 00 00       	mov    $0x4,%edi
  84675f:	4c 3b 42 20          	cmp    0x20(%rdx),%r8
  846763:	0f 85 1e 01 00 00    	jne    846887 <<gpui_gpu::renderer::RendererState>::redraw+0x137>
  846769:	48 83 be 30 03 00 00 	cmpq   $0x0,0x330(%rsi)
  846770:	00 
  846771:	0f 84 00 01 00 00    	je     846877 <<gpui_gpu::renderer::RendererState>::redraw+0x127>
  846777:	8b be 38 03 00 00    	mov    0x338(%rsi),%edi
  84677d:	44 8b 86 3c 03 00 00 	mov    0x33c(%rsi),%r8d
  846784:	81 e7 ff ff ff 7f    	and    $0x7fffffff,%edi
  84678a:	49 c1 e0 20          	shl    $0x20,%r8
  84678e:	49 09 f8             	or     %rdi,%r8
  846791:	bf 03 00 00 00       	mov    $0x3,%edi
  846796:	4c 39 41 20          	cmp    %r8,0x20(%rcx)
  84679a:	0f 85 e7 00 00 00    	jne    846887 <<gpui_gpu::renderer::RendererState>::redraw+0x137>
  8467a0:	44 8b 41 38          	mov    0x38(%rcx),%r8d
  8467a4:	44 3b 42 28          	cmp    0x28(%rdx),%r8d
  8467a8:	0f 85 d9 00 00 00    	jne    846887 <<gpui_gpu::renderer::RendererState>::redraw+0x137>
  8467ae:	41 83 f8 4c          	cmp    $0x4c,%r8d
  8467b2:	75 22                	jne    8467d6 <<gpui_gpu::renderer::RendererState>::redraw+0x86>
  8467b4:	f3 0f 7e 41 3c       	movq   0x3c(%rcx),%xmm0
  8467b9:	f3 0f 7e 4a 2c       	movq   0x2c(%rdx),%xmm1
  8467be:	66 0f 76 c8          	pcmpeqd %xmm0,%xmm1
  8467c2:	66 0f 70 c1 50       	pshufd $0x50,%xmm1,%xmm0
  8467c7:	66 44 0f 50 c0       	movmskpd %xmm0,%r8d
  8467cc:	41 83 f8 03          	cmp    $0x3,%r8d
  8467d0:	0f 85 b1 00 00 00    	jne    846887 <<gpui_gpu::renderer::RendererState>::redraw+0x137>
  8467d6:	41 56                	push   %r14
  8467d8:	53                   	push   %rbx
  8467d9:	50                   	push   %rax
  8467da:	48 89 c3             	mov    %rax,%rbx
  8467dd:	48 8d 86 30 03 00 00 	lea    0x330(%rsi),%rax
  8467e4:	48 89 d7             	mov    %rdx,%rdi
  8467e7:	49 89 f6             	mov    %rsi,%r14
  8467ea:	48 89 ce             	mov    %rcx,%rsi
  8467ed:	48 89 c2             	mov    %rax,%rdx
  8467f0:	e8 3b f1 ff ff       	call   845930 <<gpui_gpu::renderer::GpuContext>::submit>
  8467f5:	48 89 c1             	mov    %rax,%rcx
  8467f8:	49 8b 96 60 01 00 00 	mov    0x160(%r14),%rdx
  8467ff:	49 8b 86 28 03 00 00 	mov    0x328(%r14),%rax
  846806:	48 ff c2             	inc    %rdx
  846809:	48 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%rsi
  846810:	48 0f 45 f2          	cmovne %rdx,%rsi
  846814:	49 89 b6 60 01 00 00 	mov    %rsi,0x160(%r14)
  84681b:	41 c6 86 20 02 00 00 	movb   $0x1,0x220(%r14)
  846822:	01 
  846823:	49 c7 86 b8 01 00 00 	movq   $0x0,0x1b8(%r14)
  84682a:	00 00 00 00 
  84682e:	49 c7 86 e0 01 00 00 	movq   $0x0,0x1e0(%r14)
  846835:	00 00 00 00 
  846839:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
  84683d:	66 41 0f 11 86 68 01 	movupd %xmm0,0x168(%r14)
  846844:	00 00 
  846846:	49 c7 86 78 01 00 00 	movq   $0x0,0x178(%r14)
  84684d:	00 00 00 00 
  846851:	48 85 c0             	test   %rax,%rax
  846854:	74 08                	je     84685e <<gpui_gpu::renderer::RendererState>::redraw+0x10e>
