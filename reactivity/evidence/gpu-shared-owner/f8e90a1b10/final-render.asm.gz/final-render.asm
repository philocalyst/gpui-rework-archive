
/tmp/gpui-shared-gpu-controls/f8e90a1b10/owned:     file format elf64-x86-64


Disassembly of section .text:

0000000000846890 <<gpui_gpu::renderer::RendererState>::render>:
  846890:	55                   	push   %rbp
  846891:	41 57                	push   %r15
  846893:	41 56                	push   %r14
  846895:	41 55                	push   %r13
  846897:	41 54                	push   %r12
  846899:	53                   	push   %rbx
  84689a:	48 81 ec 68 05 00 00 	sub    $0x568,%rsp
  8468a1:	48 8b 86 20 03 00 00 	mov    0x320(%rsi),%rax
  8468a8:	48 3b 42 20          	cmp    0x20(%rdx),%rax
  8468ac:	0f 85 ce 00 00 00    	jne    846980 <<gpui_gpu::renderer::RendererState>::render+0xf0>
  8468b2:	48 8d 9e 30 03 00 00 	lea    0x330(%rsi),%rbx
  8468b9:	48 8b 86 30 03 00 00 	mov    0x330(%rsi),%rax
  8468c0:	48 85 c0             	test   %rax,%rax
  8468c3:	74 2d                	je     8468f2 <<gpui_gpu::renderer::RendererState>::render+0x62>
  8468c5:	f0 48 ff 08          	lock decq (%rax)
  8468c9:	75 27                	jne    8468f2 <<gpui_gpu::renderer::RendererState>::render+0x62>
  8468cb:	49 89 fe             	mov    %rdi,%r14
  8468ce:	48 89 df             	mov    %rbx,%rdi
  8468d1:	49 89 f4             	mov    %rsi,%r12
  8468d4:	4d 89 c5             	mov    %r8,%r13
  8468d7:	49 89 d7             	mov    %rdx,%r15
  8468da:	48 89 cd             	mov    %rcx,%rbp
  8468dd:	ff 15 05 88 67 00    	call   *0x678805(%rip)        # ebf0e8 <_DYNAMIC+0x488>
  8468e3:	48 89 e9             	mov    %rbp,%rcx
  8468e6:	4c 89 fa             	mov    %r15,%rdx
  8468e9:	4d 89 e8             	mov    %r13,%r8
  8468ec:	4c 89 e6             	mov    %r12,%rsi
  8468ef:	4c 89 f7             	mov    %r14,%rdi
  8468f2:	48 c7 86 30 03 00 00 	movq   $0x0,0x330(%rsi)
  8468f9:	00 00 00 00 
  8468fd:	44 8b 29             	mov    (%rcx),%r13d
  846900:	44 8b 49 08          	mov    0x8(%rcx),%r9d
  846904:	0f b6 41 0d          	movzbl 0xd(%rcx),%eax
  846908:	45 85 c9             	test   %r9d,%r9d
  84690b:	41 0f 98 c2          	sets   %r10b
  84690f:	41 81 e1 ff ff ff 7f 	and    $0x7fffffff,%r9d
  846916:	45 8d 99 00 00 80 ff 	lea    -0x800000(%r9),%r11d
  84691d:	41 81 fb 00 00 00 7f 	cmp    $0x7f000000,%r11d
  846924:	41 0f 92 c3          	setb   %r11b
  846928:	45 20 d3             	and    %r10b,%r11b
  84692b:	41 8d 69 ff          	lea    -0x1(%r9),%ebp
  84692f:	81 fd ff ff 7f 00    	cmp    $0x7fffff,%ebp
  846935:	40 0f 92 c5          	setb   %bpl
  846939:	44 20 d5             	and    %r10b,%bpl
  84693c:	45 85 c9             	test   %r9d,%r9d
  84693f:	41 0f 94 c2          	sete   %r10b
  846943:	41 81 f9 00 00 80 7f 	cmp    $0x7f800000,%r9d
  84694a:	41 0f 94 c6          	sete   %r14b
  84694e:	45 08 d6             	or     %r10b,%r14b
  846951:	41 81 f9 01 00 80 7f 	cmp    $0x7f800001,%r9d
  846958:	41 0f 9d c1          	setge  %r9b
  84695c:	45 08 f1             	or     %r14b,%r9b
  84695f:	41 08 e9             	or     %bpl,%r9b
  846962:	45 85 ed             	test   %r13d,%r13d
  846965:	41 0f 95 c2          	setne  %r10b
  846969:	41 20 c2             	and    %al,%r10b
  84696c:	45 08 da             	or     %r11b,%r10b
  84696f:	45 08 ca             	or     %r9b,%r10b
  846972:	41 f6 c2 01          	test   $0x1,%r10b
  846976:	74 23                	je     84699b <<gpui_gpu::renderer::RendererState>::render+0x10b>
  846978:	c7 07 03 00 00 00    	movl   $0x3,(%rdi)
  84697e:	eb 06                	jmp    846986 <<gpui_gpu::renderer::RendererState>::render+0xf6>
  846980:	c7 07 04 00 00 00    	movl   $0x4,(%rdi)
  846986:	48 89 f8             	mov    %rdi,%rax
  846989:	48 81 c4 68 05 00 00 	add    $0x568,%rsp
  846990:	5b                   	pop    %rbx
  846991:	41 5c                	pop    %r12
  846993:	41 5d                	pop    %r13
  846995:	41 5e                	pop    %r14
  846997:	41 5f                	pop    %r15
  846999:	5d                   	pop    %rbp
  84699a:	c3                   	ret
  84699b:	66 0f 6e 51 04       	movd   0x4(%rcx),%xmm2
  8469a0:	44 0f b6 61 0c       	movzbl 0xc(%rcx),%r12d
  8469a5:	41 f6 c5 01          	test   $0x1,%r13b
  8469a9:	74 75                	je     846a20 <<gpui_gpu::renderer::RendererState>::render+0x190>
  8469ab:	66 41 0f 7e d1       	movd   %xmm2,%r9d
  8469b0:	45 85 c9             	test   %r9d,%r9d
  8469b3:	41 0f 98 c2          	sets   %r10b
  8469b7:	41 81 e1 ff ff ff 7f 	and    $0x7fffffff,%r9d
  8469be:	45 8d 99 00 00 80 ff 	lea    -0x800000(%r9),%r11d
  8469c5:	41 81 fb 00 00 00 7f 	cmp    $0x7f000000,%r11d
  8469cc:	41 0f 92 c3          	setb   %r11b
  8469d0:	45 20 d3             	and    %r10b,%r11b
  8469d3:	41 8d 69 ff          	lea    -0x1(%r9),%ebp
  8469d7:	81 fd ff ff 7f 00    	cmp    $0x7fffff,%ebp
  8469dd:	40 0f 92 c5          	setb   %bpl
  8469e1:	44 20 d5             	and    %r10b,%bpl
  8469e4:	45 85 c9             	test   %r9d,%r9d
  8469e7:	41 0f 94 c2          	sete   %r10b
  8469eb:	41 81 f9 00 00 80 7f 	cmp    $0x7f800000,%r9d
  8469f2:	41 0f 94 c6          	sete   %r14b
  8469f6:	45 08 d6             	or     %r10b,%r14b
  8469f9:	41 81 f9 01 00 80 7f 	cmp    $0x7f800001,%r9d
  846a00:	41 0f 9d c1          	setge  %r9b
  846a04:	45 08 f1             	or     %r14b,%r9b
  846a07:	41 08 e9             	or     %bpl,%r9b
  846a0a:	45 08 d9             	or     %r11b,%r9b
  846a0d:	0f 85 65 ff ff ff    	jne    846978 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846a13:	0f 2e 15 26 a2 88 ff 	ucomiss -0x775dda(%rip),%xmm2        # d0c40 <anon.630a3fff68f6bca64b568be97512ab45.57.llvm.826976926275214120+0x24>
  846a1a:	0f 87 58 ff ff ff    	ja     846978 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846a20:	44 8b 71 28          	mov    0x28(%rcx),%r14d
  846a24:	45 39 70 20          	cmp    %r14d,0x20(%r8)
  846a28:	0f 85 4a ff ff ff    	jne    846978 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846a2e:	44 8b 79 2c          	mov    0x2c(%rcx),%r15d
  846a32:	45 39 78 24          	cmp    %r15d,0x24(%r8)
  846a36:	0f 85 3c ff ff ff    	jne    846978 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846a3c:	41 8b 68 38          	mov    0x38(%r8),%ebp
  846a40:	3b 6a 28             	cmp    0x28(%rdx),%ebp
  846a43:	0f 85 2f ff ff ff    	jne    846978 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846a49:	83 fd 4c             	cmp    $0x4c,%ebp
  846a4c:	75 23                	jne    846a71 <<gpui_gpu::renderer::RendererState>::render+0x1e1>
  846a4e:	f3 41 0f 7e 40 3c    	movq   0x3c(%r8),%xmm0
  846a54:	f3 0f 7e 4a 2c       	movq   0x2c(%rdx),%xmm1
  846a59:	66 0f 76 c8          	pcmpeqd %xmm0,%xmm1
  846a5d:	66 0f 70 c1 50       	pshufd $0x50,%xmm1,%xmm0
  846a62:	66 44 0f 50 c8       	movmskpd %xmm0,%r9d
  846a67:	41 83 f9 03          	cmp    $0x3,%r9d
  846a6b:	0f 85 07 ff ff ff    	jne    846978 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846a71:	41 81 ff 00 40 00 00 	cmp    $0x4000,%r15d
  846a78:	77 34                	ja     846aae <<gpui_gpu::renderer::RendererState>::render+0x21e>
  846a7a:	41 81 fe 00 40 00 00 	cmp    $0x4000,%r14d
  846a81:	77 2b                	ja     846aae <<gpui_gpu::renderer::RendererState>::render+0x21e>
  846a83:	4d 89 f9             	mov    %r15,%r9
  846a86:	4d 0f af ce          	imul   %r14,%r9
  846a8a:	49 81 c1 ff ff ff fe 	add    $0xfffffffffeffffff,%r9
  846a91:	49 81 f9 00 00 00 ff 	cmp    $0xffffffffff000000,%r9
  846a98:	72 14                	jb     846aae <<gpui_gpu::renderer::RendererState>::render+0x21e>
  846a9a:	4c 8b 59 10          	mov    0x10(%rcx),%r11
  846a9e:	4d 8b 93 80 00 00 00 	mov    0x80(%r11),%r10
  846aa5:	49 81 fa 00 00 01 00 	cmp    $0x10000,%r10
  846aac:	76 0b                	jbe    846ab9 <<gpui_gpu::renderer::RendererState>::render+0x229>
  846aae:	c7 07 06 00 00 00    	movl   $0x6,(%rdi)
  846ab4:	e9 cd fe ff ff       	jmp    846986 <<gpui_gpu::renderer::RendererState>::render+0xf6>
  846ab9:	66 0f 6e 41 18       	movd   0x18(%rcx),%xmm0
  846abe:	66 41 0f 7e c1       	movd   %xmm0,%r9d
  846ac3:	41 81 e1 ff ff ff 7f 	and    $0x7fffffff,%r9d
  846aca:	41 81 f9 ff ff 7f 7f 	cmp    $0x7f7fffff,%r9d
  846ad1:	0f 8f a1 fe ff ff    	jg     846978 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846ad7:	66 0f db 05 f1 d2 88 	pand   -0x772d0f(%rip),%xmm0        # d3dd0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x490>
  846ade:	ff 
  846adf:	0f 2e 05 b2 a3 88 ff 	ucomiss -0x775c4e(%rip),%xmm0        # d0e98 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x28>
  846ae6:	0f 87 8c fe ff ff    	ja     846978 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846aec:	66 0f 6e 41 1c       	movd   0x1c(%rcx),%xmm0
  846af1:	66 41 0f 7e c1       	movd   %xmm0,%r9d
  846af6:	41 81 e1 ff ff ff 7f 	and    $0x7fffffff,%r9d
  846afd:	41 81 f9 ff ff 7f 7f 	cmp    $0x7f7fffff,%r9d
  846b04:	0f 8f 6e fe ff ff    	jg     846978 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846b0a:	66 0f db 05 be d2 88 	pand   -0x772d42(%rip),%xmm0        # d3dd0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x490>
  846b11:	ff 
  846b12:	0f 2e 05 7f a3 88 ff 	ucomiss -0x775c81(%rip),%xmm0        # d0e98 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x28>
  846b19:	0f 87 59 fe ff ff    	ja     846978 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846b1f:	66 0f 6e 41 20       	movd   0x20(%rcx),%xmm0
  846b24:	66 41 0f 7e c1       	movd   %xmm0,%r9d
  846b29:	41 81 e1 ff ff ff 7f 	and    $0x7fffffff,%r9d
  846b30:	41 81 f9 ff ff 7f 7f 	cmp    $0x7f7fffff,%r9d
  846b37:	0f 8f 3b fe ff ff    	jg     846978 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846b3d:	66 0f db 05 8b d2 88 	pand   -0x772d75(%rip),%xmm0        # d3dd0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x490>
  846b44:	ff 
  846b45:	0f 2e 05 4c a3 88 ff 	ucomiss -0x775cb4(%rip),%xmm0        # d0e98 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x28>
  846b4c:	0f 87 26 fe ff ff    	ja     846978 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846b52:	66 0f 6e 41 24       	movd   0x24(%rcx),%xmm0
  846b57:	66 41 0f 7e c1       	movd   %xmm0,%r9d
  846b5c:	41 81 e1 ff ff ff 7f 	and    $0x7fffffff,%r9d
  846b63:	41 81 f9 ff ff 7f 7f 	cmp    $0x7f7fffff,%r9d
  846b6a:	0f 8f 08 fe ff ff    	jg     846978 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846b70:	66 0f 6f 0d 58 d2 88 	movdqa -0x772da8(%rip),%xmm1        # d3dd0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x490>
  846b77:	ff 
  846b78:	66 0f db c8          	pand   %xmm0,%xmm1
  846b7c:	0f 2e 0d 15 a3 88 ff 	ucomiss -0x775ceb(%rip),%xmm1        # d0e98 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x28>
  846b83:	0f 87 ef fd ff ff    	ja     846978 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846b89:	0f 57 c9             	xorps  %xmm1,%xmm1
  846b8c:	0f 2e c1             	ucomiss %xmm1,%xmm0
  846b8f:	0f 82 e3 fd ff ff    	jb     846978 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846b95:	f3 0f 10 0d 77 9f 88 	movss  -0x776089(%rip),%xmm1        # d0b14 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x10>
  846b9c:	ff 
  846b9d:	0f 2e c8             	ucomiss %xmm0,%xmm1
  846ba0:	0f 82 d2 fd ff ff    	jb     846978 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846ba6:	44 0f b7 49 30       	movzwl 0x30(%rcx),%r9d
  846bab:	66 44 89 4c 24 10    	mov    %r9w,0x10(%rsp)
  846bb1:	44 0f b7 49 32       	movzwl 0x32(%rcx),%r9d
  846bb6:	66 44 89 4c 24 18    	mov    %r9w,0x18(%rsp)
  846bbc:	83 fd 28             	cmp    $0x28,%ebp
  846bbf:	75 09                	jne    846bca <<gpui_gpu::renderer::RendererState>::render+0x33a>
  846bc1:	a8 01                	test   $0x1,%al
  846bc3:	75 20                	jne    846be5 <<gpui_gpu::renderer::RendererState>::render+0x355>
  846bc5:	e9 ae fd ff ff       	jmp    846978 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846bca:	a8 01                	test   $0x1,%al
  846bcc:	0f 85 a6 fd ff ff    	jne    846978 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846bd2:	0f 2e 05 3b 9f 88 ff 	ucomiss -0x7760c5(%rip),%xmm0        # d0b14 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x10>
  846bd9:	0f 85 99 fd ff ff    	jne    846978 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846bdf:	0f 8a 93 fd ff ff    	jp     846978 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846be5:	4c 89 9c 24 b8 00 00 	mov    %r11,0xb8(%rsp)
  846bec:	00 
  846bed:	4c 89 94 24 b0 00 00 	mov    %r10,0xb0(%rsp)
  846bf4:	00 
  846bf5:	f3 0f 11 8c 24 ec 00 	movss  %xmm1,0xec(%rsp)
  846bfc:	00 00 
  846bfe:	66 0f 7e 94 24 5c 01 	movd   %xmm2,0x15c(%rsp)
  846c05:	00 00 
  846c07:	48 89 94 24 50 01 00 	mov    %rdx,0x150(%rsp)
  846c0e:	00 
  846c0f:	4c 89 84 24 00 04 00 	mov    %r8,0x400(%rsp)
  846c16:	00 
  846c17:	48 89 7c 24 40       	mov    %rdi,0x40(%rsp)
  846c1c:	49 8d 46 0f          	lea    0xf(%r14),%rax
  846c20:	48 c1 e8 04          	shr    $0x4,%rax
  846c24:	41 8d 57 0f          	lea    0xf(%r15),%edx
  846c28:	c1 ea 04             	shr    $0x4,%edx
  846c2b:	48 8d 7e 18          	lea    0x18(%rsi),%rdi
  846c2f:	48 c7 46 28 00 00 00 	movq   $0x0,0x28(%rsi)
  846c36:	00 
  846c37:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  846c3c:	0f af d0             	imul   %eax,%edx
  846c3f:	48 89 bc 24 98 00 00 	mov    %rdi,0x98(%rsp)
  846c46:	00 
  846c47:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
  846c4c:	48 89 54 24 48       	mov    %rdx,0x48(%rsp)
  846c51:	48 89 d6             	mov    %rdx,%rsi
  846c54:	31 d2                	xor    %edx,%edx
  846c56:	48 89 8c 24 90 00 00 	mov    %rcx,0x90(%rsp)
  846c5d:	00 
  846c5e:	e8 9d 43 00 00       	call   84b000 <<alloc::vec::Vec<[u32; 2]>>::resize>
  846c63:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  846c68:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
  846c6f:	00 
  846c70:	48 8b bc 24 90 00 00 	mov    0x90(%rsp),%rdi
  846c77:	00 
  846c78:	ff 15 e2 87 67 00    	call   *0x6787e2(%rip)        # ebf460 <_DYNAMIC+0x800>
  846c7e:	48 89 d1             	mov    %rdx,%rcx
  846c81:	48 29 c1             	sub    %rax,%rcx
  846c84:	48 81 f9 00 00 30 00 	cmp    $0x300000,%rcx
  846c8b:	76 10                	jbe    846c9d <<gpui_gpu::renderer::RendererState>::render+0x40d>
  846c8d:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  846c92:	c7 07 06 00 00 00    	movl   $0x6,(%rdi)
  846c98:	e9 e9 fc ff ff       	jmp    846986 <<gpui_gpu::renderer::RendererState>::render+0xf6>
  846c9d:	48 89 ce             	mov    %rcx,%rsi
  846ca0:	48 c1 e9 03          	shr    $0x3,%rcx
  846ca4:	48 bf ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rdi
  846cab:	aa aa aa 
  846cae:	48 0f af f9          	imul   %rcx,%rdi
  846cb2:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
  846cb7:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
  846cbe:	00 
  846cbf:	48 89 94 24 b0 03 00 	mov    %rdx,0x3b0(%rsp)
  846cc6:	00 
  846cc7:	48 39 c2             	cmp    %rax,%rdx
  846cca:	74 2f                	je     846cfb <<gpui_gpu::renderer::RendererState>::render+0x46b>
  846ccc:	b8 ab aa aa aa       	mov    $0xaaaaaaab,%eax
  846cd1:	48 0f af f0          	imul   %rax,%rsi
  846cd5:	48 c1 ee 2a          	shr    $0x2a,%rsi
  846cd9:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  846cde:	89 c8                	mov    %ecx,%eax
  846ce0:	83 e0 3f             	and    $0x3f,%eax
  846ce3:	48 01 ce             	add    %rcx,%rsi
  846ce6:	48 83 f8 01          	cmp    $0x1,%rax
  846cea:	48 83 de ff          	sbb    $0xffffffffffffffff,%rsi
  846cee:	48 ff c6             	inc    %rsi
  846cf1:	48 89 b4 24 e0 00 00 	mov    %rsi,0xe0(%rsp)
  846cf8:	00 
  846cf9:	eb 0c                	jmp    846d07 <<gpui_gpu::renderer::RendererState>::render+0x477>
  846cfb:	48 c7 84 24 e0 00 00 	movq   $0x0,0xe0(%rsp)
  846d02:	00 00 00 00 00 
  846d07:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  846d0e:	00 
  846d0f:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
  846d16:	48 03 88 b0 00 00 00 	add    0xb0(%rax),%rcx
  846d1d:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
  846d24:	00 
  846d25:	0f b7 44 24 10       	movzwl 0x10(%rsp),%eax
  846d2a:	66 89 84 24 80 01 00 	mov    %ax,0x180(%rsp)
  846d31:	00 
  846d32:	0f b7 44 24 18       	movzwl 0x18(%rsp),%eax
  846d37:	66 89 84 24 82 01 00 	mov    %ax,0x182(%rsp)
  846d3e:	00 
  846d3f:	48 c7 84 24 68 01 00 	movq   $0x0,0x168(%rsp)
  846d46:	00 00 00 00 00 
  846d4b:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
  846d52:	00 
  846d53:	48 89 84 24 70 01 00 	mov    %rax,0x170(%rsp)
  846d5a:	00 
  846d5b:	48 89 8c 24 48 01 00 	mov    %rcx,0x148(%rsp)
  846d62:	00 
  846d63:	48 89 8c 24 78 01 00 	mov    %rcx,0x178(%rsp)
  846d6a:	00 
  846d6b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  846d70:	0f b6 90 41 03 00 00 	movzbl 0x341(%rax),%edx
  846d77:	48 8d bc 24 48 04 00 	lea    0x448(%rsp),%rdi
  846d7e:	00 
  846d7f:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
  846d86:	00 
  846d87:	e8 b4 e1 ff ff       	call   844f40 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>>
  846d8c:	8b 84 24 48 04 00 00 	mov    0x448(%rsp),%eax
  846d93:	83 f8 ff             	cmp    $0xffffffff,%eax
  846d96:	74 2e                	je     846dc6 <<gpui_gpu::renderer::RendererState>::render+0x536>
  846d98:	8b 8c 24 4c 04 00 00 	mov    0x44c(%rsp),%ecx
  846d9f:	48 8b 94 24 50 04 00 	mov    0x450(%rsp),%rdx
  846da6:	00 
  846da7:	0f 10 84 24 58 04 00 	movups 0x458(%rsp),%xmm0
  846dae:	00 
  846daf:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  846db4:	0f 11 47 10          	movups %xmm0,0x10(%rdi)
  846db8:	89 07                	mov    %eax,(%rdi)
  846dba:	89 4f 04             	mov    %ecx,0x4(%rdi)
  846dbd:	48 89 57 08          	mov    %rdx,0x8(%rdi)
  846dc1:	e9 c0 fb ff ff       	jmp    846986 <<gpui_gpu::renderer::RendererState>::render+0xf6>
  846dc6:	48 8b 94 24 50 04 00 	mov    0x450(%rsp),%rdx
  846dcd:	00 
  846dce:	48 03 94 24 e0 00 00 	add    0xe0(%rsp),%rdx
  846dd5:	00 
  846dd6:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  846ddb:	48 8b 77 10          	mov    0x10(%rdi),%rsi
  846ddf:	b9 04 00 00 00       	mov    $0x4,%ecx
  846de4:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  846dea:	e8 d1 55 00 00       	call   84c3c0 <<alloc::raw_vec::RawVecInner>::try_reserve_exact>
  846def:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  846df3:	0f 85 94 fe ff ff    	jne    846c8d <<gpui_gpu::renderer::RendererState>::render+0x3fd>
  846df9:	0f b7 44 24 10       	movzwl 0x10(%rsp),%eax
  846dfe:	89 44 24 10          	mov    %eax,0x10(%rsp)
  846e02:	0f b7 44 24 18       	movzwl 0x18(%rsp),%eax
  846e07:	89 44 24 78          	mov    %eax,0x78(%rsp)
  846e0b:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  846e10:	48 8b b4 24 90 00 00 	mov    0x90(%rsp),%rsi
  846e17:	00 
  846e18:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
  846e1d:	e8 fe 74 00 00       	call   84e320 <gpui_gpu::renderer::slots::write_prefix>
  846e22:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  846e27:	48 8d 78 48          	lea    0x48(%rax),%rdi
  846e2b:	48 c7 40 58 00 00 00 	movq   $0x0,0x58(%rax)
  846e32:	00 
  846e33:	48 89 bc 24 08 04 00 	mov    %rdi,0x408(%rsp)
  846e3a:	00 
  846e3b:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
  846e40:	31 d2                	xor    %edx,%edx
  846e42:	e8 d9 42 00 00       	call   84b120 <<alloc::vec::Vec<u32>>::resize>
  846e47:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  846e4c:	48 c7 40 70 00 00 00 	movq   $0x0,0x70(%rax)
  846e53:	00 
  846e54:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
  846e59:	75 0f                	jne    846e6a <<gpui_gpu::renderer::RendererState>::render+0x5da>
  846e5b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  846e60:	48 8d 78 60          	lea    0x60(%rax),%rdi
  846e64:	ff 15 fe 85 67 00    	call   *0x6785fe(%rip)        # ebf468 <_DYNAMIC+0x808>
  846e6a:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  846e6f:	48 8b 48 68          	mov    0x68(%rax),%rcx
  846e73:	0f 57 c0             	xorps  %xmm0,%xmm0
  846e76:	0f 11 41 10          	movups %xmm0,0x10(%rcx)
  846e7a:	0f 11 01             	movups %xmm0,(%rcx)
  846e7d:	48 c7 40 70 01 00 00 	movq   $0x1,0x70(%rax)
  846e84:	00 
  846e85:	48 8d b8 f0 02 00 00 	lea    0x2f0(%rax),%rdi
  846e8c:	e8 3f 6e 00 00       	call   84dcd0 <<hashbrown::raw::RawTable<([u32; 8], u32)>>::clear>
  846e91:	8b 4c 24 78          	mov    0x78(%rsp),%ecx
  846e95:	c1 e1 10             	shl    $0x10,%ecx
  846e98:	03 4c 24 10          	add    0x10(%rsp),%ecx
  846e9c:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  846ea3:	00 
  846ea4:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
  846eab:	00 
  846eac:	48 c7 84 24 f0 02 00 	movq   $0x0,0x2f0(%rsp)
  846eb3:	00 00 00 00 00 
  846eb8:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
  846ebf:	00 
  846ec0:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
  846ec7:	00 
  846ec8:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  846ecf:	00 
  846ed0:	48 89 84 24 00 03 00 	mov    %rax,0x300(%rsp)
  846ed7:	00 
  846ed8:	89 4c 24 78          	mov    %ecx,0x78(%rsp)
  846edc:	89 8c 24 08 03 00 00 	mov    %ecx,0x308(%rsp)
  846ee3:	48 8d bc 24 58 02 00 	lea    0x258(%rsp),%rdi
  846eea:	00 
  846eeb:	48 8d b4 24 e8 02 00 	lea    0x2e8(%rsp),%rsi
  846ef2:	00 
  846ef3:	ff 15 77 85 67 00    	call   *0x678577(%rip)        # ebf470 <_DYNAMIC+0x810>
  846ef9:	48 8b 84 24 58 02 00 	mov    0x258(%rsp),%rax
  846f00:	00 
  846f01:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  846f06:	48 85 c0             	test   %rax,%rax
  846f09:	0f 84 31 0d 00 00    	je     847c40 <<gpui_gpu::renderer::RendererState>::render+0x13b0>
  846f0f:	48 c7 84 24 d8 00 00 	movq   $0x0,0xd8(%rsp)
  846f16:	00 00 00 00 00 
  846f1b:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  846f22:	00 00 
  846f24:	48 c7 44 24 48 00 00 	movq   $0x0,0x48(%rsp)
  846f2b:	00 00 
  846f2d:	48 c7 84 24 38 01 00 	movq   $0x0,0x138(%rsp)
  846f34:	00 00 00 00 00 
  846f39:	48 c7 84 24 40 01 00 	movq   $0x0,0x140(%rsp)
  846f40:	00 00 00 00 00 
  846f45:	48 8b 8c 24 60 02 00 	mov    0x260(%rsp),%rcx
  846f4c:	00 
  846f4d:	48 8b 94 24 68 02 00 	mov    0x268(%rsp),%rdx
  846f54:	00 
  846f55:	48 89 94 24 a0 00 00 	mov    %rdx,0xa0(%rsp)
  846f5c:	00 
  846f5d:	48 8d bc 24 70 02 00 	lea    0x270(%rsp),%rdi
  846f64:	00 
  846f65:	0f 10 07             	movups (%rdi),%xmm0
  846f68:	0f 10 4f 10          	movups 0x10(%rdi),%xmm1
  846f6c:	0f 10 57 20          	movups 0x20(%rdi),%xmm2
  846f70:	0f 29 94 24 30 03 00 	movaps %xmm2,0x330(%rsp)
  846f77:	00 
  846f78:	0f 29 8c 24 20 03 00 	movaps %xmm1,0x320(%rsp)
  846f7f:	00 
  846f80:	0f 29 84 24 10 03 00 	movaps %xmm0,0x310(%rsp)
  846f87:	00 
  846f88:	4c 8d 84 24 a0 02 00 	lea    0x2a0(%rsp),%r8
  846f8f:	00 
  846f90:	41 0f 10 00          	movups (%r8),%xmm0
  846f94:	0f 29 84 24 10 05 00 	movaps %xmm0,0x510(%rsp)
  846f9b:	00 
  846f9c:	0f 10 47 40          	movups 0x40(%rdi),%xmm0
  846fa0:	0f 29 84 24 30 04 00 	movaps %xmm0,0x430(%rsp)
  846fa7:	00 
  846fa8:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  846fad:	0f b6 b0 41 03 00 00 	movzbl 0x341(%rax),%esi
  846fb4:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  846fb9:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
  846fc0:	00 
  846fc1:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  846fc6:	48 89 8c 24 68 01 00 	mov    %rcx,0x168(%rsp)
  846fcd:	00 
  846fce:	48 89 94 24 70 01 00 	mov    %rdx,0x170(%rsp)
  846fd5:	00 
  846fd6:	0f 10 07             	movups (%rdi),%xmm0
  846fd9:	0f 10 4f 10          	movups 0x10(%rdi),%xmm1
  846fdd:	0f 10 57 20          	movups 0x20(%rdi),%xmm2
  846fe1:	48 8d 84 24 78 01 00 	lea    0x178(%rsp),%rax
  846fe8:	00 
  846fe9:	0f 11 50 20          	movups %xmm2,0x20(%rax)
  846fed:	0f 11 48 10          	movups %xmm1,0x10(%rax)
  846ff1:	0f 11 00             	movups %xmm0,(%rax)
  846ff4:	41 0f 10 00          	movups (%r8),%xmm0
  846ff8:	0f 11 40 30          	movups %xmm0,0x30(%rax)
  846ffc:	0f 10 47 40          	movups 0x40(%rdi),%xmm0
  847000:	0f 11 40 40          	movups %xmm0,0x40(%rax)
  847004:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  84700b:	00 
  84700c:	e8 4f 2d 00 00       	call   849d60 <gpui_gpu::renderer::compact_group>
  847011:	88 44 24 60          	mov    %al,0x60(%rsp)
  847015:	48 8d b4 24 70 02 00 	lea    0x270(%rsp),%rsi
  84701c:	00 
  84701d:	0f 10 06             	movups (%rsi),%xmm0
  847020:	0f 10 4e 10          	movups 0x10(%rsi),%xmm1
  847024:	0f 10 56 20          	movups 0x20(%rsi),%xmm2
  847028:	0f 29 84 24 20 05 00 	movaps %xmm0,0x520(%rsp)
  84702f:	00 
  847030:	0f 29 8c 24 30 05 00 	movaps %xmm1,0x530(%rsp)
  847037:	00 
  847038:	0f 29 94 24 40 05 00 	movaps %xmm2,0x540(%rsp)
  84703f:	00 
  847040:	48 8d 94 24 a0 02 00 	lea    0x2a0(%rsp),%rdx
  847047:	00 
  847048:	0f 10 02             	movups (%rdx),%xmm0
  84704b:	0f 29 84 24 50 05 00 	movaps %xmm0,0x550(%rsp)
  847052:	00 
  847053:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  847058:	e8 b3 ea ff ff       	call   845b10 <<gpui_gpu::renderer::RendererState>::correction>
  84705d:	89 44 24 7c          	mov    %eax,0x7c(%rsp)
  847061:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  847068:	00 
  847069:	48 8d 04 85 00 00 00 	lea    0x0(,%rax,4),%rax
  847070:	00 
  847071:	48 89 84 24 e0 03 00 	mov    %rax,0x3e0(%rsp)
  847078:	00 
  847079:	80 7c 24 60 00       	cmpb   $0x0,0x60(%rsp)
  84707e:	0f 84 d5 01 00 00    	je     847259 <<gpui_gpu::renderer::RendererState>::render+0x9c9>
  847084:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
  847089:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  847090:	00 
  847091:	48 8d 04 81          	lea    (%rcx,%rax,4),%rax
  847095:	48 89 8c 24 10 04 00 	mov    %rcx,0x410(%rsp)
  84709c:	00 
  84709d:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
  8470a4:	00 
  8470a5:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  8470aa:	48 89 84 24 20 04 00 	mov    %rax,0x420(%rsp)
  8470b1:	00 
  8470b2:	48 c7 84 24 28 04 00 	movq   $0x0,0x428(%rsp)
  8470b9:	00 00 00 00 00 
  8470be:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
  8470c5:	00 
  8470c6:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
  8470cd:	00 
  8470ce:	e8 1d 33 00 00       	call   84a3f0 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  8470d3:	80 bc 24 48 03 00 00 	cmpb   $0xff,0x348(%rsp)
  8470da:	ff 
  8470db:	0f 84 b1 06 00 00    	je     847792 <<gpui_gpu::renderer::RendererState>::render+0xf02>
  8470e1:	0f 57 c0             	xorps  %xmm0,%xmm0
  8470e4:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
  8470eb:	00 
  8470ec:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
  8470f1:	48 8b 94 24 40 03 00 	mov    0x340(%rsp),%rdx
  8470f8:	00 
  8470f9:	48 03 54 24 48       	add    0x48(%rsp),%rdx
  8470fe:	48 8d b4 24 48 03 00 	lea    0x348(%rsp),%rsi
  847105:	00 
  847106:	0f 10 46 38          	movups 0x38(%rsi),%xmm0
  84710a:	48 8d 8c 24 78 01 00 	lea    0x178(%rsp),%rcx
  847111:	00 
  847112:	0f 11 41 20          	movups %xmm0,0x20(%rcx)
  847116:	0f 10 46 48          	movups 0x48(%rsi),%xmm0
  84711a:	0f 11 41 70          	movups %xmm0,0x70(%rcx)
  84711e:	48 8b 46 30          	mov    0x30(%rsi),%rax
  847122:	48 89 84 24 90 01 00 	mov    %rax,0x190(%rsp)
  847129:	00 
  84712a:	0f 10 06             	movups (%rsi),%xmm0
  84712d:	0f 10 4e 10          	movups 0x10(%rsi),%xmm1
  847131:	0f 10 56 20          	movups 0x20(%rsi),%xmm2
  847135:	0f 29 94 24 80 01 00 	movaps %xmm2,0x180(%rsp)
  84713c:	00 
  84713d:	0f 29 8c 24 70 01 00 	movaps %xmm1,0x170(%rsp)
  847144:	00 
  847145:	0f 29 84 24 60 01 00 	movaps %xmm0,0x160(%rsp)
  84714c:	00 
  84714d:	48 8d 84 24 70 02 00 	lea    0x270(%rsp),%rax
  847154:	00 
  847155:	0f 10 40 40          	movups 0x40(%rax),%xmm0
  847159:	0f 11 81 80 00 00 00 	movups %xmm0,0x80(%rcx)
  847160:	0f 10 00             	movups (%rax),%xmm0
  847163:	0f 10 48 10          	movups 0x10(%rax),%xmm1
  847167:	0f 10 50 20          	movups 0x20(%rax),%xmm2
  84716b:	0f 11 51 50          	movups %xmm2,0x50(%rcx)
  84716f:	0f 11 49 40          	movups %xmm1,0x40(%rcx)
  847173:	0f 11 41 30          	movups %xmm0,0x30(%rcx)
  847177:	48 8d 84 24 a0 02 00 	lea    0x2a0(%rsp),%rax
  84717e:	00 
  84717f:	0f 10 00             	movups (%rax),%xmm0
  847182:	0f 11 41 60          	movups %xmm0,0x60(%rcx)
  847186:	48 8d bc 24 00 01 00 	lea    0x100(%rsp),%rdi
  84718d:	00 
  84718e:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
  847195:	00 
  847196:	44 89 f1             	mov    %r14d,%ecx
  847199:	45 89 f8             	mov    %r15d,%r8d
  84719c:	e8 0f 2c 00 00       	call   849db0 <gpui_gpu::renderer::validate_draw>
  8471a1:	8b 8c 24 00 01 00 00 	mov    0x100(%rsp),%ecx
  8471a8:	48 8b 84 24 04 01 00 	mov    0x104(%rsp),%rax
  8471af:	00 
  8471b0:	83 f9 ff             	cmp    $0xffffffff,%ecx
  8471b3:	0f 85 3f 0b 00 00    	jne    847cf8 <<gpui_gpu::renderer::RendererState>::render+0x1468>
  8471b9:	89 c1                	mov    %eax,%ecx
  8471bb:	48 c1 e8 20          	shr    $0x20,%rax
  8471bf:	66 0f 6e c1          	movd   %ecx,%xmm0
  8471c3:	0f 28 94 24 c0 00 00 	movaps 0xc0(%rsp),%xmm2
  8471ca:	00 
  8471cb:	0f 28 ca             	movaps %xmm2,%xmm1
  8471ce:	f3 0f 5f c8          	maxss  %xmm0,%xmm1
  8471d2:	0f 28 d9             	movaps %xmm1,%xmm3
  8471d5:	f3 0f c2 d9 03       	cmpunordss %xmm1,%xmm3
  8471da:	0f 28 c3             	movaps %xmm3,%xmm0
  8471dd:	0f 55 c1             	andnps %xmm1,%xmm0
  8471e0:	0f 54 da             	andps  %xmm2,%xmm3
  8471e3:	0f 56 d8             	orps   %xmm0,%xmm3
  8471e6:	0f 29 5c 24 60       	movaps %xmm3,0x60(%rsp)
  8471eb:	66 0f 6e c0          	movd   %eax,%xmm0
  8471ef:	0f 28 54 24 50       	movaps 0x50(%rsp),%xmm2
  8471f4:	0f 28 ca             	movaps %xmm2,%xmm1
  8471f7:	f3 0f 5f c8          	maxss  %xmm0,%xmm1
  8471fb:	0f 28 d9             	movaps %xmm1,%xmm3
  8471fe:	f3 0f c2 d9 03       	cmpunordss %xmm1,%xmm3
  847203:	0f 28 c3             	movaps %xmm3,%xmm0
  847206:	0f 55 c1             	andnps %xmm1,%xmm0
  847209:	0f 54 da             	andps  %xmm2,%xmm3
  84720c:	0f 56 d8             	orps   %xmm0,%xmm3
  84720f:	0f 29 9c 24 80 00 00 	movaps %xmm3,0x80(%rsp)
  847216:	00 
  847217:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
  84721e:	00 
  84721f:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
  847226:	00 
  847227:	e8 c4 31 00 00       	call   84a3f0 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  84722c:	80 bc 24 48 03 00 00 	cmpb   $0xff,0x348(%rsp)
  847233:	ff 
  847234:	0f 28 44 24 60       	movaps 0x60(%rsp),%xmm0
  847239:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
  847240:	00 
  847241:	0f 28 84 24 80 00 00 	movaps 0x80(%rsp),%xmm0
  847248:	00 
  847249:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
  84724e:	0f 85 9d fe ff ff    	jne    8470f1 <<gpui_gpu::renderer::RendererState>::render+0x861>
  847254:	e9 49 05 00 00       	jmp    8477a2 <<gpui_gpu::renderer::RendererState>::render+0xf12>
  847259:	48 83 bc 24 a0 00 00 	cmpq   $0x0,0xa0(%rsp)
  847260:	00 00 
  847262:	0f 84 82 09 00 00    	je     847bea <<gpui_gpu::renderer::RendererState>::render+0x135a>
  847268:	8b 44 24 7c          	mov    0x7c(%rsp),%eax
  84726c:	0d 00 00 00 80       	or     $0x80000000,%eax
  847271:	89 84 24 58 01 00 00 	mov    %eax,0x158(%rsp)
  847278:	48 c7 84 24 80 00 00 	movq   $0x0,0x80(%rsp)
  84727f:	00 00 00 00 00 
  847284:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  847289:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
  847290:	00 
  847291:	8b 14 08             	mov    (%rax,%rcx,1),%edx
  847294:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  84729b:	00 
  84729c:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  8472a1:	e8 ea dd ff ff       	call   845090 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  8472a6:	0f b6 bc 24 60 01 00 	movzbl 0x160(%rsp),%edi
  8472ad:	00 
  8472ae:	48 8d 94 24 61 01 00 	lea    0x161(%rsp),%rdx
  8472b5:	00 
  8472b6:	8b 02                	mov    (%rdx),%eax
  8472b8:	8b 4a 03             	mov    0x3(%rdx),%ecx
  8472bb:	48 8d b4 24 80 04 00 	lea    0x480(%rsp),%rsi
  8472c2:	00 
  8472c3:	89 4e cc             	mov    %ecx,-0x34(%rsi)
  8472c6:	89 46 c9             	mov    %eax,-0x37(%rsi)
  8472c9:	48 8b 8c 24 68 01 00 	mov    0x168(%rsp),%rcx
  8472d0:	00 
  8472d1:	48 8b 42 2f          	mov    0x2f(%rdx),%rax
  8472d5:	48 89 46 f8          	mov    %rax,-0x8(%rsi)
  8472d9:	0f 10 42 0f          	movups 0xf(%rdx),%xmm0
  8472dd:	0f 10 4a 1f          	movups 0x1f(%rdx),%xmm1
  8472e1:	0f 11 4e e8          	movups %xmm1,-0x18(%rsi)
  8472e5:	0f 11 46 d8          	movups %xmm0,-0x28(%rsi)
  8472e9:	48 8d 84 24 78 01 00 	lea    0x178(%rsp),%rax
  8472f0:	00 
  8472f1:	0f 10 40 20          	movups 0x20(%rax),%xmm0
  8472f5:	0f 11 06             	movups %xmm0,(%rsi)
  8472f8:	0f 10 40 30          	movups 0x30(%rax),%xmm0
  8472fc:	0f 11 46 50          	movups %xmm0,0x50(%rsi)
  847300:	48 8d 84 24 70 02 00 	lea    0x270(%rsp),%rax
  847307:	00 
  847308:	0f 10 40 40          	movups 0x40(%rax),%xmm0
  84730c:	0f 11 46 60          	movups %xmm0,0x60(%rsi)
  847310:	0f 10 00             	movups (%rax),%xmm0
  847313:	0f 10 48 10          	movups 0x10(%rax),%xmm1
  847317:	0f 10 50 20          	movups 0x20(%rax),%xmm2
  84731b:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
  84731f:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
  847323:	0f 11 46 10          	movups %xmm0,0x10(%rsi)
  847327:	48 8d 84 24 a0 02 00 	lea    0x2a0(%rsp),%rax
  84732e:	00 
  84732f:	0f 10 00             	movups (%rax),%xmm0
  847332:	0f 11 46 40          	movups %xmm0,0x40(%rsi)
  847336:	40 88 7c 24 50       	mov    %dil,0x50(%rsp)
  84733b:	40 88 bc 24 48 04 00 	mov    %dil,0x448(%rsp)
  847342:	00 
  847343:	48 89 8c 24 c0 00 00 	mov    %rcx,0xc0(%rsp)
  84734a:	00 
  84734b:	48 89 8c 24 50 04 00 	mov    %rcx,0x450(%rsp)
  847352:	00 
  847353:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  84735a:	00 
  84735b:	48 8d b4 24 48 04 00 	lea    0x448(%rsp),%rsi
  847362:	00 
  847363:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
  847368:	44 89 f1             	mov    %r14d,%ecx
  84736b:	45 89 f8             	mov    %r15d,%r8d
  84736e:	e8 3d 2a 00 00       	call   849db0 <gpui_gpu::renderer::validate_draw>
  847373:	8b 84 24 60 01 00 00 	mov    0x160(%rsp),%eax
  84737a:	48 8b 8c 24 64 01 00 	mov    0x164(%rsp),%rcx
  847381:	00 
  847382:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
  847387:	83 f8 ff             	cmp    $0xffffffff,%eax
  84738a:	0f 85 fe 09 00 00    	jne    847d8e <<gpui_gpu::renderer::RendererState>::render+0x14fe>
  847390:	0f b6 44 24 50       	movzbl 0x50(%rsp),%eax
  847395:	3c 02                	cmp    $0x2,%al
  847397:	0f 94 44 24 2f       	sete   0x2f(%rsp)
  84739c:	48 83 bc 24 c0 00 00 	cmpq   $0x0,0xc0(%rsp)
  8473a3:	00 00 
  8473a5:	0f 95 44 24 2e       	setne  0x2e(%rsp)
  8473aa:	0f 10 84 24 80 04 00 	movups 0x480(%rsp),%xmm0
  8473b1:	00 
  8473b2:	0f 29 84 24 d0 02 00 	movaps %xmm0,0x2d0(%rsp)
  8473b9:	00 
  8473ba:	3c 03                	cmp    $0x3,%al
  8473bc:	0f 85 8c 00 00 00    	jne    84744e <<gpui_gpu::renderer::RendererState>::render+0xbbe>
  8473c2:	f3 0f 10 84 24 4c 04 	movss  0x44c(%rsp),%xmm0
  8473c9:	00 00 
  8473cb:	0f 57 c9             	xorps  %xmm1,%xmm1
  8473ce:	0f 2e c1             	ucomiss %xmm1,%xmm0
  8473d1:	75 02                	jne    8473d5 <<gpui_gpu::renderer::RendererState>::render+0xb45>
  8473d3:	7b 79                	jnp    84744e <<gpui_gpu::renderer::RendererState>::render+0xbbe>
  8473d5:	0f 28 ac 24 d0 02 00 	movaps 0x2d0(%rsp),%xmm5
  8473dc:	00 
  8473dd:	0f 28 cd             	movaps %xmm5,%xmm1
  8473e0:	66 0f 15 cd          	unpckhpd %xmm5,%xmm1
  8473e4:	f3 0f 10 25 10 99 88 	movss  -0x7766f0(%rip),%xmm4        # d0cfc <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x14>
  8473eb:	ff 
  8473ec:	f3 0f 59 cc          	mulss  %xmm4,%xmm1
  8473f0:	0f 28 d0             	movaps %xmm0,%xmm2
  8473f3:	f3 0f 5d d1          	minss  %xmm1,%xmm2
  8473f7:	0f 28 ca             	movaps %xmm2,%xmm1
  8473fa:	f3 0f c2 ca 03       	cmpunordss %xmm2,%xmm1
  8473ff:	0f 28 d9             	movaps %xmm1,%xmm3
  847402:	0f 55 da             	andnps %xmm2,%xmm3
  847405:	0f 54 c8             	andps  %xmm0,%xmm1
  847408:	0f 56 cb             	orps   %xmm3,%xmm1
  84740b:	0f 28 c5             	movaps %xmm5,%xmm0
  84740e:	0f c6 c5 ff          	shufps $0xff,%xmm5,%xmm0
  847412:	f3 0f 59 c4          	mulss  %xmm4,%xmm0
  847416:	0f 28 d1             	movaps %xmm1,%xmm2
  847419:	f3 0f 5d d0          	minss  %xmm0,%xmm2
  84741d:	0f 28 c2             	movaps %xmm2,%xmm0
  847420:	f3 0f c2 c2 03       	cmpunordss %xmm2,%xmm0
  847425:	0f 54 c8             	andps  %xmm0,%xmm1
  847428:	0f 55 c2             	andnps %xmm2,%xmm0
  84742b:	0f 56 c1             	orps   %xmm1,%xmm0
  84742e:	66 0f 7e c0          	movd   %xmm0,%eax
  847432:	89 44 24 50          	mov    %eax,0x50(%rsp)
  847436:	25 00 00 80 ff       	and    $0xff800000,%eax
  84743b:	b9 00 00 00 7f       	mov    $0x7f000000,%ecx
  847440:	29 c1                	sub    %eax,%ecx
  847442:	89 8c 24 c0 00 00 00 	mov    %ecx,0xc0(%rsp)
  847449:	0f 57 c0             	xorps  %xmm0,%xmm0
  84744c:	eb 22                	jmp    847470 <<gpui_gpu::renderer::RendererState>::render+0xbe0>
  84744e:	8b 84 24 e0 04 00 00 	mov    0x4e0(%rsp),%eax
  847455:	89 44 24 50          	mov    %eax,0x50(%rsp)
  847459:	8b 84 24 e4 04 00 00 	mov    0x4e4(%rsp),%eax
  847460:	89 84 24 c0 00 00 00 	mov    %eax,0xc0(%rsp)
  847467:	f2 0f 10 84 24 e8 04 	movsd  0x4e8(%rsp),%xmm0
  84746e:	00 00 
  847470:	0f 29 84 24 20 01 00 	movaps %xmm0,0x120(%rsp)
  847477:	00 
  847478:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  84747d:	8b 48 10             	mov    0x10(%rax),%ecx
  847480:	b8 00 00 00 80       	mov    $0x80000000,%eax
  847485:	09 c1                	or     %eax,%ecx
  847487:	89 8c 24 a0 03 00 00 	mov    %ecx,0x3a0(%rsp)
  84748e:	0f 10 84 24 90 04 00 	movups 0x490(%rsp),%xmm0
  847495:	00 
  847496:	0f 29 84 24 d0 03 00 	movaps %xmm0,0x3d0(%rsp)
  84749d:	00 
  84749e:	0f 10 84 24 98 04 00 	movups 0x498(%rsp),%xmm0
  8474a5:	00 
  8474a6:	0f 29 84 24 00 05 00 	movaps %xmm0,0x500(%rsp)
  8474ad:	00 
  8474ae:	f2 0f 10 84 24 a0 04 	movsd  0x4a0(%rsp),%xmm0
  8474b5:	00 00 
  8474b7:	0f 29 84 24 c0 03 00 	movaps %xmm0,0x3c0(%rsp)
  8474be:	00 
  8474bf:	f2 0f 10 84 24 a8 04 	movsd  0x4a8(%rsp),%xmm0
  8474c6:	00 00 
  8474c8:	0f 29 84 24 f0 04 00 	movaps %xmm0,0x4f0(%rsp)
  8474cf:	00 
  8474d0:	f2 0f 10 84 24 b0 04 	movsd  0x4b0(%rsp),%xmm0
  8474d7:	00 00 
  8474d9:	f2 0f 11 84 24 f8 03 	movsd  %xmm0,0x3f8(%rsp)
  8474e0:	00 00 
  8474e2:	f2 0f 10 84 24 b8 04 	movsd  0x4b8(%rsp),%xmm0
  8474e9:	00 00 
  8474eb:	f2 0f 11 84 24 f0 03 	movsd  %xmm0,0x3f0(%rsp)
  8474f2:	00 00 
  8474f4:	0f 10 84 24 c0 04 00 	movups 0x4c0(%rsp),%xmm0
  8474fb:	00 
  8474fc:	0f 29 84 24 c0 02 00 	movaps %xmm0,0x2c0(%rsp)
  847503:	00 
  847504:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  847509:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
  847510:	00 
  847511:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  847516:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
  84751d:	00 
  84751e:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  847525:	00 
  847526:	48 89 84 24 70 01 00 	mov    %rax,0x170(%rsp)
  84752d:	00 
  84752e:	0f 28 84 24 10 03 00 	movaps 0x310(%rsp),%xmm0
  847535:	00 
  847536:	0f 28 8c 24 20 03 00 	movaps 0x320(%rsp),%xmm1
  84753d:	00 
  84753e:	0f 28 94 24 30 03 00 	movaps 0x330(%rsp),%xmm2
  847545:	00 
  847546:	48 8d 84 24 78 01 00 	lea    0x178(%rsp),%rax
  84754d:	00 
  84754e:	0f 11 50 20          	movups %xmm2,0x20(%rax)
  847552:	0f 11 48 10          	movups %xmm1,0x10(%rax)
  847556:	0f 11 00             	movups %xmm0,(%rax)
  847559:	0f 28 84 24 10 05 00 	movaps 0x510(%rsp),%xmm0
  847560:	00 
  847561:	0f 11 40 30          	movups %xmm0,0x30(%rax)
  847565:	0f 28 84 24 30 04 00 	movaps 0x430(%rsp),%xmm0
  84756c:	00 
  84756d:	0f 11 40 40          	movups %xmm0,0x40(%rax)
  847571:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  847578:	00 
  847579:	ff 15 f9 7e 67 00    	call   *0x677ef9(%rip)        # ebf478 <_DYNAMIC+0x818>
  84757f:	8b 4c 24 7c          	mov    0x7c(%rsp),%ecx
  847583:	89 8c 24 f0 00 00 00 	mov    %ecx,0xf0(%rsp)
  84758a:	85 c0                	test   %eax,%eax
  84758c:	74 34                	je     8475c2 <<gpui_gpu::renderer::RendererState>::render+0xd32>
  84758e:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  847593:	89 c6                	mov    %eax,%esi
  847595:	e8 46 6d 00 00       	call   84e2e0 <gpui_gpu::renderer::slots::color_word>
  84759a:	89 44 24 50          	mov    %eax,0x50(%rsp)
  84759e:	0f 57 c0             	xorps  %xmm0,%xmm0
  8475a1:	0f 29 84 24 20 01 00 	movaps %xmm0,0x120(%rsp)
  8475a8:	00 
  8475a9:	c7 84 24 c0 00 00 00 	movl   $0x0,0xc0(%rsp)
  8475b0:	00 00 00 00 
  8475b4:	8b 84 24 58 01 00 00 	mov    0x158(%rsp),%eax
  8475bb:	89 84 24 f0 00 00 00 	mov    %eax,0xf0(%rsp)
  8475c2:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  8475c7:	48 c1 e8 20          	shr    $0x20,%rax
  8475cb:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
  8475d2:	00 
  8475d3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  8475d8:	48 8b 08             	mov    (%rax),%rcx
  8475db:	48 8b 70 10          	mov    0x10(%rax),%rsi
  8475df:	48 29 f1             	sub    %rsi,%rcx
  8475e2:	48 83 f9 05          	cmp    $0x5,%rcx
  8475e6:	0f 86 7e 01 00 00    	jbe    84776a <<gpui_gpu::renderer::RendererState>::render+0xeda>
  8475ec:	f2 0f 10 84 24 f0 03 	movsd  0x3f0(%rsp),%xmm0
  8475f3:	00 00 
  8475f5:	f2 0f 5a c0          	cvtsd2ss %xmm0,%xmm0
  8475f9:	f2 0f 10 8c 24 f8 03 	movsd  0x3f8(%rsp),%xmm1
  847600:	00 00 
  847602:	f2 0f 5a c9          	cvtsd2ss %xmm1,%xmm1
  847606:	66 0f 28 94 24 00 05 	movapd 0x500(%rsp),%xmm2
  84760d:	00 00 
  84760f:	66 0f 14 94 24 f0 04 	unpcklpd 0x4f0(%rsp),%xmm2
  847616:	00 00 
  847618:	66 0f 5a d2          	cvtpd2ps %xmm2,%xmm2
  84761c:	66 0f 28 9c 24 d0 03 	movapd 0x3d0(%rsp),%xmm3
  847623:	00 00 
  847625:	66 0f 14 9c 24 c0 03 	unpcklpd 0x3c0(%rsp),%xmm3
  84762c:	00 00 
  84762e:	66 0f 5a db          	cvtpd2ps %xmm3,%xmm3
  847632:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  847637:	48 8b 50 08          	mov    0x8(%rax),%rdx
  84763b:	48 c1 e6 04          	shl    $0x4,%rsi
  84763f:	0f 28 a4 24 d0 02 00 	movaps 0x2d0(%rsp),%xmm4
  847646:	00 
  847647:	0f 11 24 32          	movups %xmm4,(%rdx,%rsi,1)
  84764b:	66 0f 13 5c 32 10    	movlpd %xmm3,0x10(%rdx,%rsi,1)
  847651:	f3 0f 11 4c 32 18    	movss  %xmm1,0x18(%rdx,%rsi,1)
  847657:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  84765c:	89 4c 32 1c          	mov    %ecx,0x1c(%rdx,%rsi,1)
  847660:	66 0f 13 54 32 20    	movlpd %xmm2,0x20(%rdx,%rsi,1)
  847666:	f3 0f 11 44 32 28    	movss  %xmm0,0x28(%rdx,%rsi,1)
  84766c:	48 8b bc 24 e8 03 00 	mov    0x3e8(%rsp),%rdi
  847673:	00 
  847674:	89 7c 32 2c          	mov    %edi,0x2c(%rdx,%rsi,1)
  847678:	0f 28 84 24 c0 02 00 	movaps 0x2c0(%rsp),%xmm0
  84767f:	00 
  847680:	0f 11 44 32 30       	movups %xmm0,0x30(%rdx,%rsi,1)
  847685:	8b 7c 24 50          	mov    0x50(%rsp),%edi
  847689:	89 7c 32 40          	mov    %edi,0x40(%rdx,%rsi,1)
  84768d:	8b bc 24 c0 00 00 00 	mov    0xc0(%rsp),%edi
  847694:	89 7c 32 44          	mov    %edi,0x44(%rdx,%rsi,1)
  847698:	0f 28 84 24 20 01 00 	movaps 0x120(%rsp),%xmm0
  84769f:	00 
  8476a0:	0f 13 44 32 48       	movlps %xmm0,0x48(%rdx,%rsi,1)
  8476a5:	48 c7 44 32 50 00 00 	movq   $0x0,0x50(%rdx,%rsi,1)
  8476ac:	00 00 
  8476ae:	c7 44 32 58 00 00 00 	movl   $0x0,0x58(%rdx,%rsi,1)
  8476b5:	00 
  8476b6:	8b bc 24 f0 00 00 00 	mov    0xf0(%rsp),%edi
  8476bd:	89 7c 32 5c          	mov    %edi,0x5c(%rdx,%rsi,1)
  8476c1:	48 83 40 10 06       	addq   $0x6,0x10(%rax)
  8476c6:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  8476cd:	00 
  8476ce:	48 89 c6             	mov    %rax,%rsi
  8476d1:	48 8d 94 24 48 04 00 	lea    0x448(%rsp),%rdx
  8476d8:	00 
  8476d9:	44 8b 84 24 a0 03 00 	mov    0x3a0(%rsp),%r8d
  8476e0:	00 
  8476e1:	4c 8b 4c 24 48       	mov    0x48(%rsp),%r9
  8476e6:	ff b4 24 d8 00 00 00 	push   0xd8(%rsp)
  8476ed:	41 57                	push   %r15
  8476ef:	41 56                	push   %r14
  8476f1:	ff 74 24 50          	push   0x50(%rsp)
  8476f5:	e8 06 16 00 00       	call   848d00 <<gpui_gpu::renderer::RendererState>::bin_draw>
  8476fa:	48 83 c4 20          	add    $0x20,%rsp
  8476fe:	8b 84 24 60 01 00 00 	mov    0x160(%rsp),%eax
  847705:	83 f8 ff             	cmp    $0xffffffff,%eax
  847708:	0f 85 48 06 00 00    	jne    847d56 <<gpui_gpu::renderer::RendererState>::render+0x14c6>
  84770e:	0f b6 4c 24 2f       	movzbl 0x2f(%rsp),%ecx
  847713:	22 4c 24 2e          	and    0x2e(%rsp),%cl
  847717:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  84771c:	08 c8                	or     %cl,%al
  84771e:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  847723:	48 8b 84 24 68 01 00 	mov    0x168(%rsp),%rax
  84772a:	00 
  84772b:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
  847732:	00 
  847733:	48 ff 44 24 48       	incq   0x48(%rsp)
  847738:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
  84773f:	00 
  847740:	48 83 c2 04          	add    $0x4,%rdx
  847744:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  84774b:	00 
  84774c:	48 8d 04 85 00 00 00 	lea    0x0(,%rax,4),%rax
  847753:	00 
  847754:	48 89 94 24 80 00 00 	mov    %rdx,0x80(%rsp)
  84775b:	00 
  84775c:	48 39 d0             	cmp    %rdx,%rax
  84775f:	0f 85 1f fb ff ff    	jne    847284 <<gpui_gpu::renderer::RendererState>::render+0x9f4>
  847765:	e9 74 04 00 00       	jmp    847bde <<gpui_gpu::renderer::RendererState>::render+0x134e>
  84776a:	ba 06 00 00 00       	mov    $0x6,%edx
  84776f:	b9 04 00 00 00       	mov    $0x4,%ecx
  847774:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  84777a:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  84777f:	e8 ac 4b 00 00       	call   84c330 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  847784:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  847789:	48 8b 70 10          	mov    0x10(%rax),%rsi
  84778d:	e9 5a fe ff ff       	jmp    8475ec <<gpui_gpu::renderer::RendererState>::render+0xd5c>
  847792:	0f 57 c0             	xorps  %xmm0,%xmm0
  847795:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
  84779c:	00 
  84779d:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
  8477a2:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  8477a7:	8b 40 10             	mov    0x10(%rax),%eax
  8477aa:	89 84 24 20 01 00 00 	mov    %eax,0x120(%rsp)
  8477b1:	0f 10 8c 24 70 02 00 	movups 0x270(%rsp),%xmm1
  8477b8:	00 
  8477b9:	0f 10 94 24 78 02 00 	movups 0x278(%rsp),%xmm2
  8477c0:	00 
  8477c1:	f2 0f 10 84 24 90 02 	movsd  0x290(%rsp),%xmm0
  8477c8:	00 00 
  8477ca:	f2 0f 11 84 24 f0 00 	movsd  %xmm0,0xf0(%rsp)
  8477d1:	00 00 
  8477d3:	f2 0f 10 84 24 98 02 	movsd  0x298(%rsp),%xmm0
  8477da:	00 00 
  8477dc:	f2 0f 11 84 24 d0 02 	movsd  %xmm0,0x2d0(%rsp)
  8477e3:	00 00 
  8477e5:	0f 10 84 24 a0 02 00 	movups 0x2a0(%rsp),%xmm0
  8477ec:	00 
  8477ed:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
  8477f4:	00 
  8477f5:	0f 16 8c 24 80 02 00 	movhps 0x280(%rsp),%xmm1
  8477fc:	00 
  8477fd:	0f 29 8c 24 a0 03 00 	movaps %xmm1,0x3a0(%rsp)
  847804:	00 
  847805:	0f 10 84 24 b0 02 00 	movups 0x2b0(%rsp),%xmm0
  84780c:	00 
  84780d:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
  847812:	0f 16 94 24 88 02 00 	movhps 0x288(%rsp),%xmm2
  847819:	00 
  84781a:	0f 29 94 24 c0 02 00 	movaps %xmm2,0x2c0(%rsp)
  847821:	00 
  847822:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  847827:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
  84782e:	00 
  84782f:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  847834:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
  84783b:	00 
  84783c:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  847843:	00 
  847844:	48 89 84 24 70 01 00 	mov    %rax,0x170(%rsp)
  84784b:	00 
  84784c:	48 8d 84 24 70 02 00 	lea    0x270(%rsp),%rax
  847853:	00 
  847854:	0f 10 00             	movups (%rax),%xmm0
  847857:	0f 10 48 10          	movups 0x10(%rax),%xmm1
  84785b:	0f 10 50 20          	movups 0x20(%rax),%xmm2
  84785f:	48 8d 94 24 78 01 00 	lea    0x178(%rsp),%rdx
  847866:	00 
  847867:	0f 11 52 20          	movups %xmm2,0x20(%rdx)
  84786b:	0f 11 4a 10          	movups %xmm1,0x10(%rdx)
  84786f:	0f 11 02             	movups %xmm0,(%rdx)
  847872:	48 8d 8c 24 a0 02 00 	lea    0x2a0(%rsp),%rcx
  847879:	00 
  84787a:	0f 10 01             	movups (%rcx),%xmm0
  84787d:	0f 11 42 30          	movups %xmm0,0x30(%rdx)
  847881:	f3 0f 6f 40 40       	movdqu 0x40(%rax),%xmm0
  847886:	f3 0f 7f 42 40       	movdqu %xmm0,0x40(%rdx)
  84788b:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  847892:	00 
  847893:	ff 15 df 7b 67 00    	call   *0x677bdf(%rip)        # ebf478 <_DYNAMIC+0x818>
  847899:	85 c0                	test   %eax,%eax
  84789b:	74 1e                	je     8478bb <<gpui_gpu::renderer::RendererState>::render+0x102b>
  84789d:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  8478a2:	89 c6                	mov    %eax,%esi
  8478a4:	e8 37 6a 00 00       	call   84e2e0 <gpui_gpu::renderer::slots::color_word>
  8478a9:	81 4c 24 7c 00 00 00 	orl    $0x80000000,0x7c(%rsp)
  8478b0:	80 
  8478b1:	66 0f 6e c0          	movd   %eax,%xmm0
  8478b5:	66 0f 7f 44 24 50    	movdqa %xmm0,0x50(%rsp)
  8478bb:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  8478c0:	48 8b 08             	mov    (%rax),%rcx
  8478c3:	48 8b 70 10          	mov    0x10(%rax),%rsi
  8478c7:	48 29 f1             	sub    %rsi,%rcx
  8478ca:	48 83 f9 04          	cmp    $0x4,%rcx
  8478ce:	0f 86 44 03 00 00    	jbe    847c18 <<gpui_gpu::renderer::RendererState>::render+0x1388>
  8478d4:	66 0f 5a 84 24 a0 03 	cvtpd2ps 0x3a0(%rsp),%xmm0
  8478db:	00 00 
  8478dd:	66 0f 5a 8c 24 c0 02 	cvtpd2ps 0x2c0(%rsp),%xmm1
  8478e4:	00 00 
  8478e6:	f2 0f 10 94 24 f0 00 	movsd  0xf0(%rsp),%xmm2
  8478ed:	00 00 
  8478ef:	f2 0f 5a d2          	cvtsd2ss %xmm2,%xmm2
  8478f3:	f2 0f 10 9c 24 d0 02 	movsd  0x2d0(%rsp),%xmm3
  8478fa:	00 00 
  8478fc:	f2 0f 5a db          	cvtsd2ss %xmm3,%xmm3
  847900:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  847905:	48 8b 48 08          	mov    0x8(%rax),%rcx
  847909:	48 c1 e6 04          	shl    $0x4,%rsi
  84790d:	66 0f 13 04 31       	movlpd %xmm0,(%rcx,%rsi,1)
  847912:	f3 0f 11 54 31 08    	movss  %xmm2,0x8(%rcx,%rsi,1)
  847918:	0f 28 44 24 60       	movaps 0x60(%rsp),%xmm0
  84791d:	f3 0f 11 44 31 0c    	movss  %xmm0,0xc(%rcx,%rsi,1)
  847923:	66 0f 13 4c 31 10    	movlpd %xmm1,0x10(%rcx,%rsi,1)
  847929:	f3 0f 11 5c 31 18    	movss  %xmm3,0x18(%rcx,%rsi,1)
  84792f:	0f 28 84 24 80 00 00 	movaps 0x80(%rsp),%xmm0
  847936:	00 
  847937:	f3 0f 11 44 31 1c    	movss  %xmm0,0x1c(%rcx,%rsi,1)
  84793d:	0f 28 84 24 c0 00 00 	movaps 0xc0(%rsp),%xmm0
  847944:	00 
  847945:	0f 11 44 31 20       	movups %xmm0,0x20(%rcx,%rsi,1)
  84794a:	0f 28 44 24 50       	movaps 0x50(%rsp),%xmm0
  84794f:	0f 11 44 31 30       	movups %xmm0,0x30(%rcx,%rsi,1)
  847954:	8b 54 24 7c          	mov    0x7c(%rsp),%edx
  847958:	89 54 31 40          	mov    %edx,0x40(%rcx,%rsi,1)
  84795c:	48 c7 44 31 44 00 00 	movq   $0x0,0x44(%rcx,%rsi,1)
  847963:	00 00 
  847965:	c7 44 31 4c 00 00 00 	movl   $0x0,0x4c(%rcx,%rsi,1)
  84796c:	00 
  84796d:	48 83 40 10 05       	addq   $0x5,0x10(%rax)
  847972:	48 ff 84 24 38 01 00 	incq   0x138(%rsp)
  847979:	00 
  84797a:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  847981:	00 
  847982:	48 01 84 24 40 01 00 	add    %rax,0x140(%rsp)
  847989:	00 
  84798a:	48 85 c0             	test   %rax,%rax
  84798d:	0f 84 57 02 00 00    	je     847bea <<gpui_gpu::renderer::RendererState>::render+0x135a>
  847993:	66 0f 6f 44 24 60    	movdqa 0x60(%rsp),%xmm0
  847999:	66 0f 7e c1          	movd   %xmm0,%ecx
  84799d:	66 0f 6f 84 24 80 00 	movdqa 0x80(%rsp),%xmm0
  8479a4:	00 00 
  8479a6:	66 0f 7e c0          	movd   %xmm0,%eax
  8479aa:	48 c1 e0 20          	shl    $0x20,%rax
  8479ae:	48 09 c1             	or     %rax,%rcx
  8479b1:	48 89 8c 24 f0 00 00 	mov    %rcx,0xf0(%rsp)
  8479b8:	00 
  8479b9:	48 c7 44 24 60 00 00 	movq   $0x0,0x60(%rsp)
  8479c0:	00 00 
  8479c2:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  8479c7:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  8479cc:	8b 14 08             	mov    (%rax,%rcx,1),%edx
  8479cf:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
  8479d6:	00 
  8479d7:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  8479dc:	e8 af d6 ff ff       	call   845090 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  8479e1:	0f b6 bc 24 40 03 00 	movzbl 0x340(%rsp),%edi
  8479e8:	00 
  8479e9:	48 8d b4 24 48 03 00 	lea    0x348(%rsp),%rsi
  8479f0:	00 
  8479f1:	8b 46 f9             	mov    -0x7(%rsi),%eax
  8479f4:	8b 4e fc             	mov    -0x4(%rsi),%ecx
  8479f7:	48 8d 94 24 61 01 00 	lea    0x161(%rsp),%rdx
  8479fe:	00 
  8479ff:	89 4a 03             	mov    %ecx,0x3(%rdx)
  847a02:	89 02                	mov    %eax,(%rdx)
  847a04:	48 8b 8c 24 48 03 00 	mov    0x348(%rsp),%rcx
  847a0b:	00 
  847a0c:	48 8b 46 28          	mov    0x28(%rsi),%rax
  847a10:	48 89 42 2f          	mov    %rax,0x2f(%rdx)
  847a14:	0f 10 46 08          	movups 0x8(%rsi),%xmm0
  847a18:	0f 10 4e 18          	movups 0x18(%rsi),%xmm1
  847a1c:	0f 11 4a 1f          	movups %xmm1,0x1f(%rdx)
  847a20:	0f 11 42 0f          	movups %xmm0,0xf(%rdx)
  847a24:	0f 10 8c 24 78 03 00 	movups 0x378(%rsp),%xmm1
  847a2b:	00 
  847a2c:	48 8d 84 24 88 03 00 	lea    0x388(%rsp),%rax
  847a33:	00 
  847a34:	0f 10 00             	movups (%rax),%xmm0
  847a37:	48 8d 84 24 78 01 00 	lea    0x178(%rsp),%rax
  847a3e:	00 
  847a3f:	0f 11 40 70          	movups %xmm0,0x70(%rax)
  847a43:	0f 28 84 24 30 04 00 	movaps 0x430(%rsp),%xmm0
  847a4a:	00 
  847a4b:	0f 11 80 80 00 00 00 	movups %xmm0,0x80(%rax)
  847a52:	0f 29 8c 24 a0 00 00 	movaps %xmm1,0xa0(%rsp)
  847a59:	00 
  847a5a:	0f 11 8c 24 98 01 00 	movups %xmm1,0x198(%rsp)
  847a61:	00 
  847a62:	0f 28 84 24 20 05 00 	movaps 0x520(%rsp),%xmm0
  847a69:	00 
  847a6a:	0f 28 8c 24 30 05 00 	movaps 0x530(%rsp),%xmm1
  847a71:	00 
  847a72:	66 0f 28 94 24 40 05 	movapd 0x540(%rsp),%xmm2
  847a79:	00 00 
  847a7b:	66 0f 11 50 50       	movupd %xmm2,0x50(%rax)
  847a80:	0f 11 48 40          	movups %xmm1,0x40(%rax)
  847a84:	0f 11 40 30          	movups %xmm0,0x30(%rax)
  847a88:	0f 28 84 24 50 05 00 	movaps 0x550(%rsp),%xmm0
  847a8f:	00 
  847a90:	0f 11 40 60          	movups %xmm0,0x60(%rax)
  847a94:	40 88 7c 24 50       	mov    %dil,0x50(%rsp)
  847a99:	40 88 bc 24 60 01 00 	mov    %dil,0x160(%rsp)
  847aa0:	00 
  847aa1:	48 89 8c 24 c0 00 00 	mov    %rcx,0xc0(%rsp)
  847aa8:	00 
  847aa9:	48 89 8c 24 68 01 00 	mov    %rcx,0x168(%rsp)
  847ab0:	00 
  847ab1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  847ab6:	48 8b 08             	mov    (%rax),%rcx
  847ab9:	48 8b 40 10          	mov    0x10(%rax),%rax
  847abd:	48 29 c1             	sub    %rax,%rcx
  847ac0:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  847ac7:	00 
  847ac8:	48 83 f9 01          	cmp    $0x1,%rcx
  847acc:	0f 86 dc 00 00 00    	jbe    847bae <<gpui_gpu::renderer::RendererState>::render+0x131e>
  847ad2:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  847ad7:	48 8b 4e 08          	mov    0x8(%rsi),%rcx
  847adb:	48 c1 e0 04          	shl    $0x4,%rax
  847adf:	0f 28 84 24 a0 00 00 	movaps 0xa0(%rsp),%xmm0
  847ae6:	00 
  847ae7:	0f 11 04 01          	movups %xmm0,(%rcx,%rax,1)
  847aeb:	48 c7 44 01 10 00 00 	movq   $0x0,0x10(%rcx,%rax,1)
  847af2:	00 00 
  847af4:	c7 44 01 18 00 00 00 	movl   $0x0,0x18(%rcx,%rax,1)
  847afb:	00 
  847afc:	8b 94 24 20 01 00 00 	mov    0x120(%rsp),%edx
  847b03:	89 54 01 1c          	mov    %edx,0x1c(%rcx,%rax,1)
  847b07:	48 83 46 10 02       	addq   $0x2,0x10(%rsi)
  847b0c:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
  847b13:	00 
  847b14:	48 8d 94 24 60 01 00 	lea    0x160(%rsp),%rdx
  847b1b:	00 
  847b1c:	48 8b 8c 24 f0 00 00 	mov    0xf0(%rsp),%rcx
  847b23:	00 
  847b24:	4c 8b 84 24 80 00 00 	mov    0x80(%rsp),%r8
  847b2b:	00 
  847b2c:	4c 8b 4c 24 48       	mov    0x48(%rsp),%r9
  847b31:	ff b4 24 d8 00 00 00 	push   0xd8(%rsp)
  847b38:	41 57                	push   %r15
  847b3a:	41 56                	push   %r14
  847b3c:	ff 74 24 50          	push   0x50(%rsp)
  847b40:	e8 bb 11 00 00       	call   848d00 <<gpui_gpu::renderer::RendererState>::bin_draw>
  847b45:	48 83 c4 20          	add    $0x20,%rsp
  847b49:	8b 84 24 40 03 00 00 	mov    0x340(%rsp),%eax
  847b50:	83 f8 ff             	cmp    $0xffffffff,%eax
  847b53:	0f 85 19 02 00 00    	jne    847d72 <<gpui_gpu::renderer::RendererState>::render+0x14e2>
  847b59:	80 7c 24 50 02       	cmpb   $0x2,0x50(%rsp)
  847b5e:	0f 94 c0             	sete   %al
  847b61:	48 83 bc 24 c0 00 00 	cmpq   $0x0,0xc0(%rsp)
  847b68:	00 00 
  847b6a:	0f 95 c1             	setne  %cl
  847b6d:	20 c1                	and    %al,%cl
  847b6f:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  847b74:	08 c8                	or     %cl,%al
  847b76:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  847b7b:	48 8b 84 24 48 03 00 	mov    0x348(%rsp),%rax
  847b82:	00 
  847b83:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
  847b8a:	00 
  847b8b:	48 ff 44 24 48       	incq   0x48(%rsp)
  847b90:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  847b95:	48 83 c1 04          	add    $0x4,%rcx
  847b99:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
  847b9e:	48 39 8c 24 e0 03 00 	cmp    %rcx,0x3e0(%rsp)
  847ba5:	00 
  847ba6:	0f 85 16 fe ff ff    	jne    8479c2 <<gpui_gpu::renderer::RendererState>::render+0x1132>
  847bac:	eb 30                	jmp    847bde <<gpui_gpu::renderer::RendererState>::render+0x134e>
  847bae:	ba 02 00 00 00       	mov    $0x2,%edx
  847bb3:	b9 04 00 00 00       	mov    $0x4,%ecx
  847bb8:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  847bbe:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  847bc3:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
  847bca:	00 
  847bcb:	e8 60 47 00 00       	call   84c330 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  847bd0:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  847bd5:	48 8b 40 10          	mov    0x10(%rax),%rax
  847bd9:	e9 f4 fe ff ff       	jmp    847ad2 <<gpui_gpu::renderer::RendererState>::render+0x1242>
  847bde:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  847be3:	24 01                	and    $0x1,%al
  847be5:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  847bea:	48 8d bc 24 58 02 00 	lea    0x258(%rsp),%rdi
  847bf1:	00 
  847bf2:	48 8d b4 24 e8 02 00 	lea    0x2e8(%rsp),%rsi
  847bf9:	00 
  847bfa:	ff 15 70 78 67 00    	call   *0x677870(%rip)        # ebf470 <_DYNAMIC+0x810>
  847c00:	48 8b 84 24 58 02 00 	mov    0x258(%rsp),%rax
  847c07:	00 
  847c08:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  847c0d:	48 85 c0             	test   %rax,%rax
  847c10:	0f 85 2f f3 ff ff    	jne    846f45 <<gpui_gpu::renderer::RendererState>::render+0x6b5>
  847c16:	eb 5e                	jmp    847c76 <<gpui_gpu::renderer::RendererState>::render+0x13e6>
  847c18:	ba 05 00 00 00       	mov    $0x5,%edx
  847c1d:	b9 04 00 00 00       	mov    $0x4,%ecx
  847c22:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  847c28:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  847c2d:	e8 fe 46 00 00       	call   84c330 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  847c32:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  847c37:	48 8b 70 10          	mov    0x10(%rax),%rsi
  847c3b:	e9 94 fc ff ff       	jmp    8478d4 <<gpui_gpu::renderer::RendererState>::render+0x1044>
  847c40:	48 c7 84 24 40 01 00 	movq   $0x0,0x140(%rsp)
  847c47:	00 00 00 00 00 
  847c4c:	48 c7 84 24 38 01 00 	movq   $0x0,0x138(%rsp)
  847c53:	00 00 00 00 00 
  847c58:	48 c7 44 24 48 00 00 	movq   $0x0,0x48(%rsp)
  847c5f:	00 00 
  847c61:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  847c68:	00 00 
  847c6a:	48 c7 84 24 d8 00 00 	movq   $0x0,0xd8(%rsp)
  847c71:	00 00 00 00 00 
  847c76:	48 8b b4 24 50 01 00 	mov    0x150(%rsp),%rsi
  847c7d:	00 
  847c7e:	48 8d 56 08          	lea    0x8(%rsi),%rdx
  847c82:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  847c87:	48 8d 88 50 02 00 00 	lea    0x250(%rax),%rcx
  847c8e:	4c 8d 80 28 03 00 00 	lea    0x328(%rax),%r8
  847c95:	4c 8b 48 10          	mov    0x10(%rax),%r9
  847c99:	48 83 ec 08          	sub    $0x8,%rsp
  847c9d:	48 8d bc 24 68 01 00 	lea    0x168(%rsp),%rdi
  847ca4:	00 
  847ca5:	48 89 94 24 d8 03 00 	mov    %rdx,0x3d8(%rsp)
  847cac:	00 
  847cad:	48 89 8c 24 c8 02 00 	mov    %rcx,0x2c8(%rsp)
  847cb4:	00 
  847cb5:	4c 89 84 24 d8 02 00 	mov    %r8,0x2d8(%rsp)
  847cbc:	00 
  847cbd:	ff b4 24 98 00 00 00 	push   0x98(%rsp)
  847cc4:	e8 a7 35 00 00       	call   84b270 <gpui_gpu::renderer::images::prepare>
  847cc9:	48 83 c4 10          	add    $0x10,%rsp
  847ccd:	83 bc 24 60 01 00 00 	cmpl   $0xffffffff,0x160(%rsp)
  847cd4:	ff 
  847cd5:	74 47                	je     847d1e <<gpui_gpu::renderer::RendererState>::render+0x148e>
  847cd7:	0f 10 84 24 60 01 00 	movups 0x160(%rsp),%xmm0
  847cde:	00 
  847cdf:	0f 10 8c 24 70 01 00 	movups 0x170(%rsp),%xmm1
  847ce6:	00 
  847ce7:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  847cec:	0f 11 4f 10          	movups %xmm1,0x10(%rdi)
  847cf0:	0f 11 07             	movups %xmm0,(%rdi)
  847cf3:	e9 8e ec ff ff       	jmp    846986 <<gpui_gpu::renderer::RendererState>::render+0xf6>
  847cf8:	8b 94 24 1c 01 00 00 	mov    0x11c(%rsp),%edx
  847cff:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  847d04:	89 57 1c             	mov    %edx,0x1c(%rdi)
  847d07:	0f 10 84 24 0c 01 00 	movups 0x10c(%rsp),%xmm0
  847d0e:	00 
  847d0f:	0f 11 47 0c          	movups %xmm0,0xc(%rdi)
  847d13:	89 0f                	mov    %ecx,(%rdi)
  847d15:	48 89 47 04          	mov    %rax,0x4(%rdi)
  847d19:	e9 68 ec ff ff       	jmp    846986 <<gpui_gpu::renderer::RendererState>::render+0xf6>
  847d1e:	44 0f b6 44 24 10    	movzbl 0x10(%rsp),%r8d
  847d24:	41 83 e0 01          	and    $0x1,%r8d
  847d28:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  847d2f:	00 
  847d30:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  847d35:	48 8b 94 24 50 01 00 	mov    0x150(%rsp),%rdx
  847d3c:	00 
  847d3d:	48 8b 8c 24 b8 00 00 	mov    0xb8(%rsp),%rcx
  847d44:	00 
  847d45:	e8 a6 e1 ff ff       	call   845ef0 <<gpui_gpu::renderer::RendererState>::prepare_atlas>
  847d4a:	8b 84 24 60 01 00 00 	mov    0x160(%rsp),%eax
  847d51:	83 f8 ff             	cmp    $0xffffffff,%eax
  847d54:	74 63                	je     847db9 <<gpui_gpu::renderer::RendererState>::render+0x1529>
  847d56:	8b 8c 24 64 01 00 00 	mov    0x164(%rsp),%ecx
  847d5d:	48 8b 94 24 68 01 00 	mov    0x168(%rsp),%rdx
  847d64:	00 
  847d65:	0f 10 84 24 70 01 00 	movups 0x170(%rsp),%xmm0
  847d6c:	00 
  847d6d:	e9 3d f0 ff ff       	jmp    846daf <<gpui_gpu::renderer::RendererState>::render+0x51f>
  847d72:	8b 8c 24 44 03 00 00 	mov    0x344(%rsp),%ecx
  847d79:	48 8b 94 24 48 03 00 	mov    0x348(%rsp),%rdx
  847d80:	00 
  847d81:	0f 10 84 24 50 03 00 	movups 0x350(%rsp),%xmm0
  847d88:	00 
  847d89:	e9 21 f0 ff ff       	jmp    846daf <<gpui_gpu::renderer::RendererState>::render+0x51f>
  847d8e:	8b 8c 24 7c 01 00 00 	mov    0x17c(%rsp),%ecx
  847d95:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  847d9a:	89 4f 1c             	mov    %ecx,0x1c(%rdi)
  847d9d:	0f 10 84 24 6c 01 00 	movups 0x16c(%rsp),%xmm0
  847da4:	00 
  847da5:	0f 11 47 0c          	movups %xmm0,0xc(%rdi)
  847da9:	89 07                	mov    %eax,(%rdi)
  847dab:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  847db0:	48 89 47 04          	mov    %rax,0x4(%rdi)
  847db4:	e9 cd eb ff ff       	jmp    846986 <<gpui_gpu::renderer::RendererState>::render+0xf6>
  847db9:	48 8b 84 24 68 01 00 	mov    0x168(%rsp),%rax
  847dc0:	00 
  847dc1:	48 89 84 24 c0 03 00 	mov    %rax,0x3c0(%rsp)
  847dc8:	00 
  847dc9:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  847dd0:	00 
  847dd1:	48 89 84 24 40 03 00 	mov    %rax,0x340(%rsp)
  847dd8:	00 
  847dd9:	48 c7 84 24 48 03 00 	movq   $0x0,0x348(%rsp)
  847de0:	00 00 00 00 00 
  847de5:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
  847dec:	00 
  847ded:	48 89 84 24 50 03 00 	mov    %rax,0x350(%rsp)
  847df4:	00 
  847df5:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  847dfc:	00 
  847dfd:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
  847e04:	00 
  847e05:	8b 44 24 78          	mov    0x78(%rsp),%eax
  847e09:	89 84 24 60 03 00 00 	mov    %eax,0x360(%rsp)
  847e10:	48 8d bc 24 58 02 00 	lea    0x258(%rsp),%rdi
  847e17:	00 
  847e18:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
  847e1f:	00 
  847e20:	ff 15 4a 76 67 00    	call   *0x67764a(%rip)        # ebf470 <_DYNAMIC+0x810>
  847e26:	48 8b 84 24 58 02 00 	mov    0x258(%rsp),%rax
  847e2d:	00 
  847e2e:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  847e35:	00 
  847e36:	48 85 c0             	test   %rax,%rax
  847e39:	0f 84 d7 03 00 00    	je     848216 <<gpui_gpu::renderer::RendererState>::render+0x1986>
  847e3f:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  847e44:	48 05 20 01 00 00    	add    $0x120,%rax
  847e4a:	48 89 84 24 a0 03 00 	mov    %rax,0x3a0(%rsp)
  847e51:	00 
  847e52:	eb 3c                	jmp    847e90 <<gpui_gpu::renderer::RendererState>::render+0x1600>
  847e54:	48 8d bc 24 58 02 00 	lea    0x258(%rsp),%rdi
  847e5b:	00 
  847e5c:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
  847e63:	00 
  847e64:	ff 15 06 76 67 00    	call   *0x677606(%rip)        # ebf470 <_DYNAMIC+0x810>
  847e6a:	48 8b 84 24 58 02 00 	mov    0x258(%rsp),%rax
  847e71:	00 
  847e72:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  847e77:	48 89 8c 24 e0 00 00 	mov    %rcx,0xe0(%rsp)
  847e7e:	00 
  847e7f:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  847e86:	00 
  847e87:	48 85 c0             	test   %rax,%rax
  847e8a:	0f 84 86 03 00 00    	je     848216 <<gpui_gpu::renderer::RendererState>::render+0x1986>
  847e90:	48 8b 94 24 60 02 00 	mov    0x260(%rsp),%rdx
  847e97:	00 
  847e98:	48 8b bc 24 68 02 00 	mov    0x268(%rsp),%rdi
  847e9f:	00 
  847ea0:	48 89 bc 24 80 00 00 	mov    %rdi,0x80(%rsp)
  847ea7:	00 
  847ea8:	48 8d 84 24 70 02 00 	lea    0x270(%rsp),%rax
  847eaf:	00 
  847eb0:	0f 10 40 40          	movups 0x40(%rax),%xmm0
  847eb4:	48 8d 8c 24 78 01 00 	lea    0x178(%rsp),%rcx
  847ebb:	00 
  847ebc:	0f 11 41 40          	movups %xmm0,0x40(%rcx)
  847ec0:	0f 10 00             	movups (%rax),%xmm0
  847ec3:	0f 10 48 10          	movups 0x10(%rax),%xmm1
  847ec7:	0f 10 50 20          	movups 0x20(%rax),%xmm2
  847ecb:	0f 10 58 30          	movups 0x30(%rax),%xmm3
  847ecf:	0f 11 59 30          	movups %xmm3,0x30(%rcx)
  847ed3:	0f 11 51 20          	movups %xmm2,0x20(%rcx)
  847ed7:	0f 11 49 10          	movups %xmm1,0x10(%rcx)
  847edb:	0f 11 01             	movups %xmm0,(%rcx)
  847ede:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  847ee3:	0f b6 b0 41 03 00 00 	movzbl 0x341(%rax),%esi
  847eea:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  847ef1:	00 
  847ef2:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
  847ef9:	00 
  847efa:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
  847eff:	48 89 94 24 68 01 00 	mov    %rdx,0x168(%rsp)
  847f06:	00 
  847f07:	48 89 bc 24 70 01 00 	mov    %rdi,0x170(%rsp)
  847f0e:	00 
  847f0f:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  847f16:	00 
  847f17:	e8 44 1e 00 00       	call   849d60 <gpui_gpu::renderer::compact_group>
  847f1c:	48 8b 8c 24 e0 00 00 	mov    0xe0(%rsp),%rcx
  847f23:	00 
  847f24:	48 8d 51 05          	lea    0x5(%rcx),%rdx
  847f28:	84 c0                	test   %al,%al
  847f2a:	48 0f 44 d1          	cmove  %rcx,%rdx
  847f2e:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
  847f33:	48 83 bc 24 80 00 00 	cmpq   $0x0,0x80(%rsp)
  847f3a:	00 00 
  847f3c:	0f 84 12 ff ff ff    	je     847e54 <<gpui_gpu::renderer::RendererState>::render+0x15c4>
  847f42:	48 c1 a4 24 80 00 00 	shlq   $0x2,0x80(%rsp)
  847f49:	00 02 
  847f4b:	34 01                	xor    $0x1,%al
  847f4d:	0f b6 c8             	movzbl %al,%ecx
  847f50:	c1 e1 02             	shl    $0x2,%ecx
  847f53:	48 8d 41 01          	lea    0x1(%rcx),%rax
  847f57:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  847f5e:	00 
  847f5f:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  847f64:	4c 8d 04 08          	lea    (%rax,%rcx,1),%r8
  847f68:	49 ff c0             	inc    %r8
  847f6b:	48 83 c9 02          	or     $0x2,%rcx
  847f6f:	49 c1 e0 04          	shl    $0x4,%r8
  847f73:	48 89 8c 24 e0 00 00 	mov    %rcx,0xe0(%rsp)
  847f7a:	00 
  847f7b:	c1 e1 04             	shl    $0x4,%ecx
  847f7e:	48 89 8c 24 20 01 00 	mov    %rcx,0x120(%rsp)
  847f85:	00 
  847f86:	31 c9                	xor    %ecx,%ecx
  847f88:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
  847f8d:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  847f92:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
  847f97:	8b 14 08             	mov    (%rax,%rcx,1),%edx
  847f9a:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  847fa1:	00 
  847fa2:	48 8b b4 24 a0 00 00 	mov    0xa0(%rsp),%rsi
  847fa9:	00 
  847faa:	e8 e1 d0 ff ff       	call   845090 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  847faf:	0f b6 8c 24 60 01 00 	movzbl 0x160(%rsp),%ecx
  847fb6:	00 
  847fb7:	0f b6 84 24 61 01 00 	movzbl 0x161(%rsp),%eax
  847fbe:	00 
  847fbf:	f3 0f 10 a4 24 64 01 	movss  0x164(%rsp),%xmm4
  847fc6:	00 00 
  847fc8:	48 8d b4 24 68 01 00 	lea    0x168(%rsp),%rsi
  847fcf:	00 
  847fd0:	48 8b 56 10          	mov    0x10(%rsi),%rdx
  847fd4:	48 89 94 24 20 03 00 	mov    %rdx,0x320(%rsp)
  847fdb:	00 
  847fdc:	0f 10 06             	movups (%rsi),%xmm0
  847fdf:	0f 29 84 24 10 03 00 	movaps %xmm0,0x310(%rsp)
  847fe6:	00 
  847fe7:	83 f9 01             	cmp    $0x1,%ecx
  847fea:	0f 84 8f 00 00 00    	je     84807f <<gpui_gpu::renderer::RendererState>::render+0x17ef>
  847ff0:	0f 29 a4 24 f0 00 00 	movaps %xmm4,0xf0(%rsp)
  847ff7:	00 
  847ff8:	48 8b b4 24 80 01 00 	mov    0x180(%rsp),%rsi
  847fff:	00 
  848000:	8b 94 24 88 01 00 00 	mov    0x188(%rsp),%edx
  848007:	89 54 24 60          	mov    %edx,0x60(%rsp)
  84800b:	8b 94 24 8c 01 00 00 	mov    0x18c(%rsp),%edx
  848012:	89 54 24 20          	mov    %edx,0x20(%rsp)
  848016:	83 f9 03             	cmp    $0x3,%ecx
  848019:	0f 85 e5 00 00 00    	jne    848104 <<gpui_gpu::renderer::RendererState>::render+0x1874>
  84801f:	48 8b 8c 24 d0 02 00 	mov    0x2d0(%rsp),%rcx
  848026:	00 
  848027:	48 8b 39             	mov    (%rcx),%rdi
  84802a:	48 85 ff             	test   %rdi,%rdi
  84802d:	0f 84 4b 0c 00 00    	je     848c7e <<gpui_gpu::renderer::RendererState>::render+0x23ee>
  848033:	0f b6 d0             	movzbl %al,%edx
  848036:	e8 c5 2e 00 00       	call   84af00 <<gpui_gpu::renderer::images::Images>::metadata>
  84803b:	89 c1                	mov    %eax,%ecx
  84803d:	48 c1 e8 20          	shr    $0x20,%rax
  848041:	89 c2                	mov    %eax,%edx
  848043:	83 ca 10             	or     $0x10,%edx
  848046:	0f 57 c0             	xorps  %xmm0,%xmm0
  848049:	0f 28 8c 24 f0 00 00 	movaps 0xf0(%rsp),%xmm1
  848050:	00 
  848051:	0f 2e c8             	ucomiss %xmm0,%xmm1
  848054:	0f 45 c2             	cmovne %edx,%eax
  848057:	0f 4a c2             	cmovp  %edx,%eax
  84805a:	8b 54 24 20          	mov    0x20(%rsp),%edx
  84805e:	c1 e2 10             	shl    $0x10,%edx
  848061:	0b 54 24 60          	or     0x60(%rsp),%edx
  848065:	89 8c 24 00 01 00 00 	mov    %ecx,0x100(%rsp)
  84806c:	89 84 24 04 01 00 00 	mov    %eax,0x104(%rsp)
  848073:	89 94 24 08 01 00 00 	mov    %edx,0x108(%rsp)
  84807a:	e9 22 01 00 00       	jmp    8481a1 <<gpui_gpu::renderer::RendererState>::render+0x1911>
  84807f:	f3 0f 10 84 24 a0 01 	movss  0x1a0(%rsp),%xmm0
  848086:	00 00 
  848088:	f3 0f 10 1d 6c 8c 88 	movss  -0x777394(%rip),%xmm3        # d0cfc <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x14>
  84808f:	ff 
  848090:	f3 0f 59 c3          	mulss  %xmm3,%xmm0
  848094:	0f 28 cc             	movaps %xmm4,%xmm1
  848097:	f3 0f 5d c8          	minss  %xmm0,%xmm1
  84809b:	0f 28 c1             	movaps %xmm1,%xmm0
  84809e:	f3 0f c2 c1 03       	cmpunordss %xmm1,%xmm0
  8480a3:	0f 28 d0             	movaps %xmm0,%xmm2
  8480a6:	0f 55 d1             	andnps %xmm1,%xmm2
  8480a9:	0f 54 c4             	andps  %xmm4,%xmm0
  8480ac:	0f 56 c2             	orps   %xmm2,%xmm0
  8480af:	f3 0f 10 8c 24 a4 01 	movss  0x1a4(%rsp),%xmm1
  8480b6:	00 00 
  8480b8:	f3 0f 59 cb          	mulss  %xmm3,%xmm1
  8480bc:	0f 28 d0             	movaps %xmm0,%xmm2
  8480bf:	f3 0f 5d d1          	minss  %xmm1,%xmm2
  8480c3:	0f 28 ca             	movaps %xmm2,%xmm1
  8480c6:	f3 0f c2 ca 03       	cmpunordss %xmm2,%xmm1
  8480cb:	0f 54 c1             	andps  %xmm1,%xmm0
  8480ce:	0f 55 ca             	andnps %xmm2,%xmm1
  8480d1:	0f 56 c8             	orps   %xmm0,%xmm1
  8480d4:	66 0f 7e c8          	movd   %xmm1,%eax
  8480d8:	25 00 00 80 ff       	and    $0xff800000,%eax
  8480dd:	b9 00 00 00 7f       	mov    $0x7f000000,%ecx
  8480e2:	29 c1                	sub    %eax,%ecx
  8480e4:	c7 84 24 00 01 00 00 	movl   $0x40000000,0x100(%rsp)
  8480eb:	00 00 00 40 
  8480ef:	f3 0f 11 8c 24 04 01 	movss  %xmm1,0x104(%rsp)
  8480f6:	00 00 
  8480f8:	89 8c 24 08 01 00 00 	mov    %ecx,0x108(%rsp)
  8480ff:	e9 9d 00 00 00       	jmp    8481a1 <<gpui_gpu::renderer::RendererState>::render+0x1911>
  848104:	80 f9 02             	cmp    $0x2,%cl
  848107:	75 50                	jne    848159 <<gpui_gpu::renderer::RendererState>::render+0x18c9>
  848109:	48 8b 84 24 90 01 00 	mov    0x190(%rsp),%rax
  848110:	00 
  848111:	48 8b 8c 24 20 03 00 	mov    0x320(%rsp),%rcx
  848118:	00 
  848119:	48 89 8c 24 70 01 00 	mov    %rcx,0x170(%rsp)
  848120:	00 
  848121:	0f 28 84 24 10 03 00 	movaps 0x310(%rsp),%xmm0
  848128:	00 
  848129:	0f 29 84 24 60 01 00 	movaps %xmm0,0x160(%rsp)
  848130:	00 
  848131:	48 89 b4 24 78 01 00 	mov    %rsi,0x178(%rsp)
  848138:	00 
  848139:	8b 4c 24 60          	mov    0x60(%rsp),%ecx
  84813d:	89 8c 24 80 01 00 00 	mov    %ecx,0x180(%rsp)
  848144:	8b 4c 24 20          	mov    0x20(%rsp),%ecx
  848148:	89 8c 24 84 01 00 00 	mov    %ecx,0x184(%rsp)
  84814f:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
  848156:	00 
  848157:	eb 0c                	jmp    848165 <<gpui_gpu::renderer::RendererState>::render+0x18d5>
  848159:	48 c7 84 24 60 01 00 	movq   $0x0,0x160(%rsp)
  848160:	00 00 00 00 00 
  848165:	c7 84 24 f0 02 00 00 	movl   $0x0,0x2f0(%rsp)
  84816c:	00 00 00 00 
  848170:	48 c7 84 24 e8 02 00 	movq   $0x0,0x2e8(%rsp)
  848177:	00 00 00 00 00 
  84817c:	48 8d bc 24 00 01 00 	lea    0x100(%rsp),%rdi
  848183:	00 
  848184:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
  84818b:	00 
  84818c:	48 8d 94 24 e8 02 00 	lea    0x2e8(%rsp),%rdx
  848193:	00 
  848194:	48 8b 8c 24 a0 03 00 	mov    0x3a0(%rsp),%rcx
  84819b:	00 
  84819c:	e8 6f bc ff ff       	call   843e10 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>>
  8481a1:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  8481a6:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
  8481ad:	00 
  8481ae:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
  8481b2:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  8481b7:	48 8b 70 10          	mov    0x10(%rax),%rsi
  8481bb:	48 39 f7             	cmp    %rsi,%rdi
  8481be:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
  8481c3:	0f 83 c2 0a 00 00    	jae    848c8b <<gpui_gpu::renderer::RendererState>::render+0x23fb>
  8481c9:	48 8b 40 08          	mov    0x8(%rax),%rax
  8481cd:	8b 8c 24 08 01 00 00 	mov    0x108(%rsp),%ecx
  8481d4:	42 89 4c 00 08       	mov    %ecx,0x8(%rax,%r8,1)
  8481d9:	48 8b 8c 24 00 01 00 	mov    0x100(%rsp),%rcx
  8481e0:	00 
  8481e1:	4a 89 0c 00          	mov    %rcx,(%rax,%r8,1)
  8481e5:	48 03 94 24 e0 00 00 	add    0xe0(%rsp),%rdx
  8481ec:	00 
  8481ed:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
  8481f2:	4c 03 84 24 20 01 00 	add    0x120(%rsp),%r8
  8481f9:	00 
  8481fa:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  8481ff:	48 83 c1 04          	add    $0x4,%rcx
  848203:	48 39 8c 24 80 00 00 	cmp    %rcx,0x80(%rsp)
  84820a:	00 
  84820b:	0f 85 77 fd ff ff    	jne    847f88 <<gpui_gpu::renderer::RendererState>::render+0x16f8>
  848211:	e9 3e fc ff ff       	jmp    847e54 <<gpui_gpu::renderer::RendererState>::render+0x15c4>
  848216:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  84821b:	48 8b 40 28          	mov    0x28(%rax),%rax
  84821f:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
  848226:	00 00 
  848228:	48 85 c0             	test   %rax,%rax
  84822b:	74 6b                	je     848298 <<gpui_gpu::renderer::RendererState>::render+0x1a08>
  84822d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  848232:	48 8b 49 20          	mov    0x20(%rcx),%rcx
  848236:	48 c1 e0 03          	shl    $0x3,%rax
  84823a:	31 ff                	xor    %edi,%edi
  84823c:	eb 1c                	jmp    84825a <<gpui_gpu::renderer::RendererState>::render+0x19ca>
  84823e:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
  848243:	01 f2                	add    %esi,%edx
  848245:	89 14 f9             	mov    %edx,(%rcx,%rdi,8)
  848248:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
  84824d:	89 54 f9 04          	mov    %edx,0x4(%rcx,%rdi,8)
  848251:	48 ff c7             	inc    %rdi
  848254:	48 83 c0 f8          	add    $0xfffffffffffffff8,%rax
  848258:	74 32                	je     84828c <<gpui_gpu::renderer::RendererState>::render+0x19fc>
  84825a:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  84825f:	48 8b 72 58          	mov    0x58(%rdx),%rsi
  848263:	48 39 f7             	cmp    %rsi,%rdi
  848266:	0f 83 2c 0a 00 00    	jae    848c98 <<gpui_gpu::renderer::RendererState>::render+0x2408>
  84826c:	8b 74 f9 04          	mov    0x4(%rcx,%rdi,8),%esi
  848270:	83 fe 01             	cmp    $0x1,%esi
  848273:	75 c9                	jne    84823e <<gpui_gpu::renderer::RendererState>::render+0x19ae>
  848275:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  84827a:	4c 8b 42 50          	mov    0x50(%rdx),%r8
  84827e:	ba 00 00 00 80       	mov    $0x80000000,%edx
  848283:	41 83 3c b8 00       	cmpl   $0x0,(%r8,%rdi,4)
  848288:	75 c3                	jne    84824d <<gpui_gpu::renderer::RendererState>::render+0x19bd>
  84828a:	eb b2                	jmp    84823e <<gpui_gpu::renderer::RendererState>::render+0x19ae>
  84828c:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  848291:	89 c0                	mov    %eax,%eax
  848293:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  848298:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  84829d:	48 8d 78 30          	lea    0x30(%rax),%rdi
  8482a1:	48 c7 40 40 00 00 00 	movq   $0x0,0x40(%rax)
  8482a8:	00 
  8482a9:	48 89 bc 24 a0 00 00 	mov    %rdi,0xa0(%rsp)
  8482b0:	00 
  8482b1:	48 8b 74 24 50       	mov    0x50(%rsp),%rsi
  8482b6:	31 d2                	xor    %edx,%edx
  8482b8:	e8 63 2e 00 00       	call   84b120 <<alloc::vec::Vec<u32>>::resize>
  8482bd:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  8482c2:	48 8b 40 10          	mov    0x10(%rax),%rax
  8482c6:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  8482cb:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  8482d0:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  8482d7:	00 
  8482d8:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  8482df:	00 
  8482e0:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
  8482e7:	00 
  8482e8:	48 c7 84 24 f0 02 00 	movq   $0x0,0x2f0(%rsp)
  8482ef:	00 00 00 00 00 
  8482f4:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
  8482fb:	00 
  8482fc:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
  848303:	00 
  848304:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  84830b:	00 
  84830c:	48 89 84 24 00 03 00 	mov    %rax,0x300(%rsp)
  848313:	00 
  848314:	8b 44 24 78          	mov    0x78(%rsp),%eax
  848318:	89 84 24 08 03 00 00 	mov    %eax,0x308(%rsp)
  84831f:	eb 1a                	jmp    84833b <<gpui_gpu::renderer::RendererState>::render+0x1aab>
  848321:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
  848326:	48 8d 41 fb          	lea    -0x5(%rcx),%rax
  84832a:	80 bc 24 b0 00 00 00 	cmpb   $0x0,0xb0(%rsp)
  848331:	00 
  848332:	48 0f 45 c8          	cmovne %rax,%rcx
  848336:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  84833b:	48 8d bc 24 58 02 00 	lea    0x258(%rsp),%rdi
  848342:	00 
  848343:	48 8d b4 24 e8 02 00 	lea    0x2e8(%rsp),%rsi
  84834a:	00 
  84834b:	ff 15 2f 71 67 00    	call   *0x67712f(%rip)        # ebf480 <_DYNAMIC+0x820>
  848351:	48 8b 84 24 58 02 00 	mov    0x258(%rsp),%rax
  848358:	00 
  848359:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  84835e:	48 85 c0             	test   %rax,%rax
  848361:	0f 84 55 02 00 00    	je     8485bc <<gpui_gpu::renderer::RendererState>::render+0x1d2c>
  848367:	48 8b 8c 24 60 02 00 	mov    0x260(%rsp),%rcx
  84836e:	00 
  84836f:	48 8b 94 24 68 02 00 	mov    0x268(%rsp),%rdx
  848376:	00 
  848377:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
  84837c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  848381:	0f b6 b0 41 03 00 00 	movzbl 0x341(%rax),%esi
  848388:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  84838d:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
  848394:	00 
  848395:	48 89 8c 24 80 00 00 	mov    %rcx,0x80(%rsp)
  84839c:	00 
  84839d:	48 89 8c 24 68 01 00 	mov    %rcx,0x168(%rsp)
  8483a4:	00 
  8483a5:	48 89 94 24 70 01 00 	mov    %rdx,0x170(%rsp)
  8483ac:	00 
  8483ad:	48 8d 84 24 70 02 00 	lea    0x270(%rsp),%rax
  8483b4:	00 
  8483b5:	0f 10 00             	movups (%rax),%xmm0
  8483b8:	0f 10 48 10          	movups 0x10(%rax),%xmm1
  8483bc:	f3 0f 6f 50 20       	movdqu 0x20(%rax),%xmm2
  8483c1:	48 8d 94 24 78 01 00 	lea    0x178(%rsp),%rdx
  8483c8:	00 
  8483c9:	f3 0f 7f 52 20       	movdqu %xmm2,0x20(%rdx)
  8483ce:	0f 11 4a 10          	movups %xmm1,0x10(%rdx)
  8483d2:	0f 11 02             	movups %xmm0,(%rdx)
  8483d5:	48 8d 8c 24 a0 02 00 	lea    0x2a0(%rsp),%rcx
  8483dc:	00 
  8483dd:	0f 10 01             	movups (%rcx),%xmm0
  8483e0:	0f 11 42 30          	movups %xmm0,0x30(%rdx)
  8483e4:	0f 10 40 40          	movups 0x40(%rax),%xmm0
  8483e8:	0f 11 42 40          	movups %xmm0,0x40(%rdx)
  8483ec:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  8483f3:	00 
  8483f4:	e8 67 19 00 00       	call   849d60 <gpui_gpu::renderer::compact_group>
  8483f9:	88 84 24 b0 00 00 00 	mov    %al,0xb0(%rsp)
  848400:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  848405:	48 85 c0             	test   %rax,%rax
  848408:	0f 84 13 ff ff ff    	je     848321 <<gpui_gpu::renderer::RendererState>::render+0x1a91>
  84840e:	48 89 c1             	mov    %rax,%rcx
  848411:	48 c1 e1 02          	shl    $0x2,%rcx
  848415:	0f b6 84 24 b0 00 00 	movzbl 0xb0(%rsp),%eax
  84841c:	00 
  84841d:	8d 14 85 00 00 00 00 	lea    0x0(,%rax,4),%edx
  848424:	48 83 ca fa          	or     $0xfffffffffffffffa,%rdx
  848428:	31 f6                	xor    %esi,%esi
  84842a:	84 c0                	test   %al,%al
  84842c:	40 0f 94 c6          	sete   %sil
  848430:	c1 e6 1f             	shl    $0x1f,%esi
  848433:	89 b4 24 b8 00 00 00 	mov    %esi,0xb8(%rsp)
  84843a:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
  84843f:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  848444:	01 d0                	add    %edx,%eax
  848446:	89 44 24 10          	mov    %eax,0x10(%rsp)
  84844a:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
  84844f:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  848456:	00 
  848457:	8b 54 08 fc          	mov    -0x4(%rax,%rcx,1),%edx
  84845b:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
  848462:	00 
  848463:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
  848468:	e8 23 cc ff ff       	call   845090 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  84846d:	48 ff 8c 24 00 01 00 	decq   0x100(%rsp)
  848474:	00 
  848475:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  84847a:	48 01 44 24 20       	add    %rax,0x20(%rsp)
  84847f:	8b 84 24 b8 00 00 00 	mov    0xb8(%rsp),%eax
  848486:	0b 44 24 10          	or     0x10(%rsp),%eax
  84848a:	89 84 24 10 04 00 00 	mov    %eax,0x410(%rsp)
  848491:	48 8d 84 24 70 02 00 	lea    0x270(%rsp),%rax
  848498:	00 
  848499:	0f 10 00             	movups (%rax),%xmm0
  84849c:	0f 10 48 10          	movups 0x10(%rax),%xmm1
  8484a0:	0f 10 50 20          	movups 0x20(%rax),%xmm2
  8484a4:	48 8d 94 24 78 01 00 	lea    0x178(%rsp),%rdx
  8484ab:	00 
  8484ac:	0f 11 52 50          	movups %xmm2,0x50(%rdx)
  8484b0:	0f 11 4a 40          	movups %xmm1,0x40(%rdx)
  8484b4:	0f 11 42 30          	movups %xmm0,0x30(%rdx)
  8484b8:	48 8d 8c 24 a0 02 00 	lea    0x2a0(%rsp),%rcx
  8484bf:	00 
  8484c0:	0f 10 01             	movups (%rcx),%xmm0
  8484c3:	0f 11 42 60          	movups %xmm0,0x60(%rdx)
  8484c7:	0f 10 40 40          	movups 0x40(%rax),%xmm0
  8484cb:	0f 11 82 80 00 00 00 	movups %xmm0,0x80(%rdx)
  8484d2:	48 8d 84 24 78 03 00 	lea    0x378(%rsp),%rax
  8484d9:	00 
  8484da:	0f 10 00             	movups (%rax),%xmm0
  8484dd:	0f 11 42 20          	movups %xmm0,0x20(%rdx)
  8484e1:	48 8d 84 24 88 03 00 	lea    0x388(%rsp),%rax
  8484e8:	00 
  8484e9:	0f 10 00             	movups (%rax),%xmm0
  8484ec:	0f 11 42 70          	movups %xmm0,0x70(%rdx)
  8484f0:	48 8b 84 24 70 03 00 	mov    0x370(%rsp),%rax
  8484f7:	00 
  8484f8:	48 89 84 24 90 01 00 	mov    %rax,0x190(%rsp)
  8484ff:	00 
  848500:	0f 10 84 24 40 03 00 	movups 0x340(%rsp),%xmm0
  848507:	00 
  848508:	0f 10 8c 24 50 03 00 	movups 0x350(%rsp),%xmm1
  84850f:	00 
  848510:	f3 0f 6f 94 24 60 03 	movdqu 0x360(%rsp),%xmm2
  848517:	00 00 
  848519:	66 0f 7f 94 24 80 01 	movdqa %xmm2,0x180(%rsp)
  848520:	00 00 
  848522:	0f 29 8c 24 70 01 00 	movaps %xmm1,0x170(%rsp)
  848529:	00 
  84852a:	0f 29 84 24 60 01 00 	movaps %xmm0,0x160(%rsp)
  848531:	00 
  848532:	48 8b 84 24 98 00 00 	mov    0x98(%rsp),%rax
  848539:	00 
  84853a:	48 89 84 24 10 03 00 	mov    %rax,0x310(%rsp)
  848541:	00 
  848542:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  848549:	00 
  84854a:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
  848551:	00 
  848552:	48 8b 84 24 08 04 00 	mov    0x408(%rsp),%rax
  848559:	00 
  84855a:	48 89 84 24 20 03 00 	mov    %rax,0x320(%rsp)
  848561:	00 
  848562:	48 8d 84 24 00 01 00 	lea    0x100(%rsp),%rax
  848569:	00 
  84856a:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
  848571:	00 
  848572:	48 8d 84 24 10 04 00 	lea    0x410(%rsp),%rax
  848579:	00 
  84857a:	48 89 84 24 30 03 00 	mov    %rax,0x330(%rsp)
  848581:	00 
  848582:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  848589:	00 
  84858a:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  84858f:	48 8d 94 24 10 03 00 	lea    0x310(%rsp),%rdx
  848596:	00 
  848597:	e8 34 c7 ff ff       	call   844cd0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>>
  84859c:	8b 44 24 10          	mov    0x10(%rsp),%eax
  8485a0:	03 44 24 30          	add    0x30(%rsp),%eax
  8485a4:	89 44 24 10          	mov    %eax,0x10(%rsp)
  8485a8:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
  8485ad:	48 83 c1 fc          	add    $0xfffffffffffffffc,%rcx
  8485b1:	0f 85 93 fe ff ff    	jne    84844a <<gpui_gpu::renderer::RendererState>::render+0x1bba>
  8485b7:	e9 65 fd ff ff       	jmp    848321 <<gpui_gpu::renderer::RendererState>::render+0x1a91>
  8485bc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  8485c1:	48 8b 78 28          	mov    0x28(%rax),%rdi
  8485c5:	48 c7 84 24 98 00 00 	movq   $0x0,0x98(%rsp)
  8485cc:	00 00 00 00 00 
  8485d1:	48 85 ff             	test   %rdi,%rdi
  8485d4:	0f 84 ca 00 00 00    	je     8486a4 <<gpui_gpu::renderer::RendererState>::render+0x1e14>
  8485da:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  8485df:	4c 8b 40 20          	mov    0x20(%rax),%r8
  8485e3:	48 c1 e7 03          	shl    $0x3,%rdi
  8485e7:	83 7c 24 38 00       	cmpl   $0x0,0x38(%rsp)
  8485ec:	0f 84 46 06 00 00    	je     848c38 <<gpui_gpu::renderer::RendererState>::render+0x23a8>
  8485f2:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
  8485f9:	00 00 
  8485fb:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
  848602:	00 00 
  848604:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  84860b:	00 00 
  84860d:	45 31 c9             	xor    %r9d,%r9d
  848610:	31 c9                	xor    %ecx,%ecx
  848612:	eb 23                	jmp    848637 <<gpui_gpu::renderer::RendererState>::render+0x1da7>
  848614:	48 ff 44 24 10       	incq   0x10(%rsp)
  848619:	49 ff c1             	inc    %r9
  84861c:	4c 3b 4c 24 38       	cmp    0x38(%rsp),%r9
  848621:	b8 00 00 00 00       	mov    $0x0,%eax
  848626:	4c 0f 44 c8          	cmove  %rax,%r9
  84862a:	48 ff c1             	inc    %rcx
  84862d:	48 83 c7 f8          	add    $0xfffffffffffffff8,%rdi
  848631:	0f 84 88 00 00 00    	je     8486bf <<gpui_gpu::renderer::RendererState>::render+0x1e2f>
  848637:	45 8b 54 c8 04       	mov    0x4(%r8,%rcx,8),%r10d
  84863c:	44 89 d0             	mov    %r10d,%eax
  84863f:	f7 d8                	neg    %eax
  848641:	70 d1                	jo     848614 <<gpui_gpu::renderer::RendererState>::render+0x1d84>
  848643:	45 2b 14 c8          	sub    (%r8,%rcx,8),%r10d
  848647:	74 d0                	je     848619 <<gpui_gpu::renderer::RendererState>::render+0x1d89>
  848649:	48 89 c8             	mov    %rcx,%rax
  84864c:	48 c1 e8 20          	shr    $0x20,%rax
  848650:	74 0f                	je     848661 <<gpui_gpu::renderer::RendererState>::render+0x1dd1>
  848652:	48 89 c8             	mov    %rcx,%rax
  848655:	31 d2                	xor    %edx,%edx
  848657:	48 f7 74 24 38       	divq   0x38(%rsp)
  84865c:	4c 89 ca             	mov    %r9,%rdx
  84865f:	eb 08                	jmp    848669 <<gpui_gpu::renderer::RendererState>::render+0x1dd9>
  848661:	89 c8                	mov    %ecx,%eax
  848663:	31 d2                	xor    %edx,%edx
  848665:	f7 74 24 38          	divl   0x38(%rsp)
  848669:	c1 e2 04             	shl    $0x4,%edx
  84866c:	c1 e0 04             	shl    $0x4,%eax
  84866f:	44 8d 5a 10          	lea    0x10(%rdx),%r11d
  848673:	45 39 de             	cmp    %r11d,%r14d
  848676:	45 0f 42 de          	cmovb  %r14d,%r11d
  84867a:	8d 70 10             	lea    0x10(%rax),%esi
  84867d:	41 39 f7             	cmp    %esi,%r15d
  848680:	41 0f 42 f7          	cmovb  %r15d,%esi
  848684:	41 29 d3             	sub    %edx,%r11d
  848687:	29 c6                	sub    %eax,%esi
  848689:	41 0f af f3          	imul   %r11d,%esi
  84868d:	48 c1 e6 04          	shl    $0x4,%rsi
  848691:	48 01 74 24 18       	add    %rsi,0x18(%rsp)
  848696:	4c 0f af d6          	imul   %rsi,%r10
  84869a:	4c 01 54 24 30       	add    %r10,0x30(%rsp)
  84869f:	e9 75 ff ff ff       	jmp    848619 <<gpui_gpu::renderer::RendererState>::render+0x1d89>
  8486a4:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  8486ab:	00 00 
  8486ad:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
  8486b4:	00 00 
  8486b6:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
  8486bd:	00 00 
  8486bf:	41 f6 c5 01          	test   $0x1,%r13b
  8486c3:	74 53                	je     848718 <<gpui_gpu::renderer::RendererState>::render+0x1e88>
  8486c5:	66 0f 6e 84 24 5c 01 	movd   0x15c(%rsp),%xmm0
  8486cc:	00 00 
  8486ce:	66 0f 7e c0          	movd   %xmm0,%eax
  8486d2:	85 c0                	test   %eax,%eax
  8486d4:	0f 99 c1             	setns  %cl
  8486d7:	89 c2                	mov    %eax,%edx
  8486d9:	81 e2 ff ff ff 7f    	and    $0x7fffffff,%edx
  8486df:	81 c2 00 00 80 ff    	add    $0xff800000,%edx
  8486e5:	81 fa 00 00 00 7f    	cmp    $0x7f000000,%edx
  8486eb:	0f 92 c2             	setb   %dl
  8486ee:	20 ca                	and    %cl,%dl
  8486f0:	ff c8                	dec    %eax
  8486f2:	3d ff ff 7f 00       	cmp    $0x7fffff,%eax
  8486f7:	0f 92 c0             	setb   %al
  8486fa:	08 d0                	or     %dl,%al
  8486fc:	b8 02 00 00 00       	mov    $0x2,%eax
  848701:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
  848708:	00 
  848709:	66 0f 7e 84 24 ec 00 	movd   %xmm0,0xec(%rsp)
  848710:	00 00 
  848712:	0f 84 16 05 00 00    	je     848c2e <<gpui_gpu::renderer::RendererState>::render+0x239e>
  848718:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
  84871f:	00 
  848720:	48 83 c1 18          	add    $0x18,%rcx
  848724:	31 d2                	xor    %edx,%edx
  848726:	48 8b 84 24 b0 03 00 	mov    0x3b0(%rsp),%rax
  84872d:	00 
  84872e:	48 3b 84 24 b8 03 00 	cmp    0x3b8(%rsp),%rax
  848735:	00 
  848736:	0f 95 c2             	setne  %dl
  848739:	31 c0                	xor    %eax,%eax
  84873b:	83 fd 28             	cmp    $0x28,%ebp
  84873e:	0f 94 c0             	sete   %al
  848741:	41 83 e4 01          	and    $0x1,%r12d
  848745:	41 8d 04 84          	lea    (%r12,%rax,4),%eax
  848749:	8d 04 d0             	lea    (%rax,%rdx,8),%eax
  84874c:	0b 84 24 98 00 00 00 	or     0x98(%rsp),%eax
  848753:	0f 10 01             	movups (%rcx),%xmm0
  848756:	0f 11 84 24 68 02 00 	movups %xmm0,0x268(%rsp)
  84875d:	00 
  84875e:	44 89 b4 24 58 02 00 	mov    %r14d,0x258(%rsp)
  848765:	00 
  848766:	44 89 bc 24 5c 02 00 	mov    %r15d,0x25c(%rsp)
  84876d:	00 
  84876e:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
  848773:	89 8c 24 60 02 00 00 	mov    %ecx,0x260(%rsp)
  84877a:	89 84 24 64 02 00 00 	mov    %eax,0x264(%rsp)
  848781:	f3 0f 10 84 24 ec 00 	movss  0xec(%rsp),%xmm0
  848788:	00 00 
  84878a:	f3 0f 11 84 24 78 02 	movss  %xmm0,0x278(%rsp)
  848791:	00 00 
  848793:	48 c7 84 24 7c 02 00 	movq   $0x0,0x27c(%rsp)
  84879a:	00 00 00 00 00 
  84879f:	c7 84 24 84 02 00 00 	movl   $0x0,0x284(%rsp)
  8487a6:	00 00 00 00 
  8487aa:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
  8487af:	49 8d b5 28 02 00 00 	lea    0x228(%r13),%rsi
  8487b6:	48 89 74 24 38       	mov    %rsi,0x38(%rsp)
  8487bb:	48 8d 8c 24 58 02 00 	lea    0x258(%rsp),%rcx
  8487c2:	00 
  8487c3:	41 b8 30 00 00 00    	mov    $0x30,%r8d
  8487c9:	48 8b ac 24 d0 03 00 	mov    0x3d0(%rsp),%rbp
  8487d0:	00 
  8487d1:	48 89 ef             	mov    %rbp,%rdi
  8487d4:	31 d2                	xor    %edx,%edx
  8487d6:	ff 15 ac 6c 67 00    	call   *0x676cac(%rip)        # ebf488 <_DYNAMIC+0x828>
  8487dc:	49 8b 4d 08          	mov    0x8(%r13),%rcx
  8487e0:	4d 8b 45 10          	mov    0x10(%r13),%r8
  8487e4:	49 c1 e0 04          	shl    $0x4,%r8
  8487e8:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
  8487ef:	00 
  8487f0:	4c 8b a4 24 50 01 00 	mov    0x150(%rsp),%r12
  8487f7:	00 
  8487f8:	4c 89 e6             	mov    %r12,%rsi
  8487fb:	48 89 ea             	mov    %rbp,%rdx
  8487fe:	e8 cd ca ff ff       	call   8452d0 <<gpui_gpu::renderer::Buffer>::write>
  848803:	49 8d bd 78 02 00 00 	lea    0x278(%r13),%rdi
  84880a:	48 89 bc 24 98 00 00 	mov    %rdi,0x98(%rsp)
  848811:	00 
  848812:	49 8b 4d 20          	mov    0x20(%r13),%rcx
  848816:	4d 8b 45 28          	mov    0x28(%r13),%r8
  84881a:	49 c1 e0 03          	shl    $0x3,%r8
  84881e:	4c 89 e6             	mov    %r12,%rsi
  848821:	48 89 ea             	mov    %rbp,%rdx
  848824:	e8 a7 ca ff ff       	call   8452d0 <<gpui_gpu::renderer::Buffer>::write>
  848829:	49 8d bd a0 02 00 00 	lea    0x2a0(%r13),%rdi
  848830:	48 89 bc 24 90 00 00 	mov    %rdi,0x90(%rsp)
  848837:	00 
  848838:	49 8b 4d 38          	mov    0x38(%r13),%rcx
  84883c:	4d 8b 45 40          	mov    0x40(%r13),%r8
  848840:	49 c1 e0 02          	shl    $0x2,%r8
  848844:	4c 89 e6             	mov    %r12,%rsi
  848847:	48 89 ea             	mov    %rbp,%rdx
  84884a:	e8 81 ca ff ff       	call   8452d0 <<gpui_gpu::renderer::Buffer>::write>
  84884f:	49 8d bd c8 02 00 00 	lea    0x2c8(%r13),%rdi
  848856:	48 89 7c 24 20       	mov    %rdi,0x20(%rsp)
  84885b:	49 8b 4d 68          	mov    0x68(%r13),%rcx
  84885f:	4d 8b 45 70          	mov    0x70(%r13),%r8
  848863:	49 c1 e0 05          	shl    $0x5,%r8
  848867:	4c 89 e6             	mov    %r12,%rsi
  84886a:	48 89 ea             	mov    %rbp,%rdx
  84886d:	e8 5e ca ff ff       	call   8452d0 <<gpui_gpu::renderer::Buffer>::write>
  848872:	49 8d 44 24 18       	lea    0x18(%r12),%rax
  848877:	49 8d 8d c8 00 00 00 	lea    0xc8(%r13),%rcx
  84887e:	48 c7 84 24 60 01 00 	movq   $0x0,0x160(%rsp)
  848885:	00 00 00 00 00 
  84888a:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
  84888f:	48 89 94 24 68 01 00 	mov    %rdx,0x168(%rsp)
  848896:	00 
  848897:	48 c7 84 24 88 01 00 	movq   $0x0,0x188(%rsp)
  84889e:	00 00 00 00 00 
  8488a3:	0f 57 c0             	xorps  %xmm0,%xmm0
  8488a6:	0f 11 84 24 70 01 00 	movups %xmm0,0x170(%rsp)
  8488ad:	00 
  8488ae:	c7 84 24 80 01 00 00 	movl   $0x0,0x180(%rsp)
  8488b5:	00 00 00 00 
  8488b9:	48 8b 94 24 c0 02 00 	mov    0x2c0(%rsp),%rdx
  8488c0:	00 
  8488c1:	48 89 94 24 90 01 00 	mov    %rdx,0x190(%rsp)
  8488c8:	00 
  8488c9:	0f 11 84 24 98 01 00 	movups %xmm0,0x198(%rsp)
  8488d0:	00 
  8488d1:	c7 84 24 a8 01 00 00 	movl   $0x1,0x1a8(%rsp)
  8488d8:	01 00 00 00 
  8488dc:	48 c7 84 24 b0 01 00 	movq   $0x0,0x1b0(%rsp)
  8488e3:	00 00 00 00 00 
  8488e8:	48 8b 94 24 98 00 00 	mov    0x98(%rsp),%rdx
  8488ef:	00 
  8488f0:	48 89 94 24 b8 01 00 	mov    %rdx,0x1b8(%rsp)
  8488f7:	00 
  8488f8:	0f 11 84 24 c0 01 00 	movups %xmm0,0x1c0(%rsp)
  8488ff:	00 
  848900:	c7 84 24 d0 01 00 00 	movl   $0x2,0x1d0(%rsp)
  848907:	02 00 00 00 
  84890b:	48 c7 84 24 d8 01 00 	movq   $0x0,0x1d8(%rsp)
  848912:	00 00 00 00 00 
  848917:	48 8b 94 24 90 00 00 	mov    0x90(%rsp),%rdx
  84891e:	00 
  84891f:	48 89 94 24 e0 01 00 	mov    %rdx,0x1e0(%rsp)
  848926:	00 
  848927:	0f 11 84 24 e8 01 00 	movups %xmm0,0x1e8(%rsp)
  84892e:	00 
  84892f:	c7 84 24 f8 01 00 00 	movl   $0x3,0x1f8(%rsp)
  848936:	03 00 00 00 
  84893a:	48 c7 84 24 00 02 00 	movq   $0x4,0x200(%rsp)
  848941:	00 04 00 00 00 
  848946:	48 89 8c 24 08 02 00 	mov    %rcx,0x208(%rsp)
  84894d:	00 
  84894e:	c7 84 24 20 02 00 00 	movl   $0x4,0x220(%rsp)
  848955:	04 00 00 00 
  848959:	48 c7 84 24 28 02 00 	movq   $0x0,0x228(%rsp)
  848960:	00 00 00 00 00 
  848965:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
  84896a:	48 89 8c 24 30 02 00 	mov    %rcx,0x230(%rsp)
  848971:	00 
  848972:	0f 11 84 24 38 02 00 	movups %xmm0,0x238(%rsp)
  848979:	00 
  84897a:	c7 84 24 48 02 00 00 	movl   $0x5,0x248(%rsp)
  848981:	05 00 00 00 
  848985:	48 8d 0d 2c 88 89 ff 	lea    -0x7677d4(%rip),%rcx        # e11b8 <anon.3ceedfc47844159f5932a07258a01292.0.llvm.14111504948212592604+0x2e3c>
  84898c:	48 89 8c 24 58 03 00 	mov    %rcx,0x358(%rsp)
  848993:	00 
  848994:	48 c7 84 24 60 03 00 	movq   $0xa,0x360(%rsp)
  84899b:	00 0a 00 00 00 
  8489a0:	48 89 84 24 40 03 00 	mov    %rax,0x340(%rsp)
  8489a7:	00 
  8489a8:	48 8d 84 24 60 01 00 	lea    0x160(%rsp),%rax
  8489af:	00 
  8489b0:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
  8489b7:	00 
  8489b8:	48 c7 84 24 50 03 00 	movq   $0x6,0x350(%rsp)
  8489bf:	00 06 00 00 00 
  8489c4:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
  8489cb:	00 
  8489cc:	4c 89 e7             	mov    %r12,%rdi
  8489cf:	ff 15 bb 6a 67 00    	call   *0x676abb(%rip)        # ebf490 <_DYNAMIC+0x830>
  8489d5:	49 89 c5             	mov    %rax,%r13
  8489d8:	48 89 84 24 10 03 00 	mov    %rax,0x310(%rsp)
  8489df:	00 
  8489e0:	48 8d 94 24 10 03 00 	lea    0x310(%rsp),%rdx
  8489e7:	00 
  8489e8:	4c 89 e7             	mov    %r12,%rdi
  8489eb:	48 8b b4 24 00 04 00 	mov    0x400(%rsp),%rsi
  8489f2:	00 
  8489f3:	e8 38 cf ff ff       	call   845930 <<gpui_gpu::renderer::GpuContext>::submit>
  8489f8:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  8489fd:	31 ed                	xor    %ebp,%ebp
  8489ff:	48 8b 84 24 b0 03 00 	mov    0x3b0(%rsp),%rax
  848a06:	00 
  848a07:	48 3b 84 24 b8 03 00 	cmp    0x3b8(%rsp),%rax
  848a0e:	00 
  848a0f:	40 0f 95 c5          	setne  %bpl
  848a13:	c1 e5 1f             	shl    $0x1f,%ebp
  848a16:	44 09 f5             	or     %r14d,%ebp
  848a19:	49 c1 e7 20          	shl    $0x20,%r15
  848a1d:	4c 09 fd             	or     %r15,%rbp
  848a20:	48 8b 03             	mov    (%rbx),%rax
  848a23:	48 85 c0             	test   %rax,%rax
  848a26:	74 0f                	je     848a37 <<gpui_gpu::renderer::RendererState>::render+0x21a7>
  848a28:	f0 48 ff 08          	lock decq (%rax)
  848a2c:	75 09                	jne    848a37 <<gpui_gpu::renderer::RendererState>::render+0x21a7>
  848a2e:	48 89 df             	mov    %rbx,%rdi
  848a31:	ff 15 b1 66 67 00    	call   *0x6766b1(%rip)        # ebf0e8 <_DYNAMIC+0x488>
  848a37:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  848a3c:	4c 89 a8 30 03 00 00 	mov    %r13,0x330(%rax)
  848a43:	48 89 a8 38 03 00 00 	mov    %rbp,0x338(%rax)
  848a4a:	4c 8b 40 10          	mov    0x10(%rax),%r8
  848a4e:	48 8b 70 28          	mov    0x28(%rax),%rsi
  848a52:	48 8b 48 70          	mov    0x70(%rax),%rcx
  848a56:	48 89 8c 24 98 00 00 	mov    %rcx,0x98(%rsp)
  848a5d:	00 
  848a5e:	49 c1 e0 04          	shl    $0x4,%r8
  848a62:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
  848a67:	49 8d 3c 90          	lea    (%r8,%rdx,4),%rdi
  848a6b:	48 8d 34 f7          	lea    (%rdi,%rsi,8),%rsi
  848a6f:	48 89 cf             	mov    %rcx,%rdi
  848a72:	48 c1 e7 05          	shl    $0x5,%rdi
  848a76:	48 8d 0c 37          	lea    (%rdi,%rsi,1),%rcx
  848a7a:	48 83 c1 30          	add    $0x30,%rcx
  848a7e:	48 89 8c 24 90 00 00 	mov    %rcx,0x90(%rsp)
  848a85:	00 
  848a86:	48 8b b8 70 02 00 00 	mov    0x270(%rax),%rdi
  848a8d:	48 03 b8 48 02 00 00 	add    0x248(%rax),%rdi
  848a94:	48 03 b8 98 02 00 00 	add    0x298(%rax),%rdi
  848a9b:	48 03 b8 c0 02 00 00 	add    0x2c0(%rax),%rdi
  848aa2:	48 03 b8 e8 02 00 00 	add    0x2e8(%rax),%rdi
  848aa9:	48 8b b0 00 03 00 00 	mov    0x300(%rax),%rsi
  848ab0:	48 03 b0 08 03 00 00 	add    0x308(%rax),%rsi
  848ab7:	44 8b 88 50 01 00 00 	mov    0x150(%rax),%r9d
  848abe:	4d 0f af c9          	imul   %r9,%r9
  848ac2:	4c 8b 9c 24 d8 00 00 	mov    0xd8(%rsp),%r11
  848ac9:	00 
  848aca:	4c 89 d9             	mov    %r11,%rcx
  848acd:	48 29 d1             	sub    %rdx,%rcx
  848ad0:	4c 8b 54 24 48       	mov    0x48(%rsp),%r10
  848ad5:	4d 89 d4             	mov    %r10,%r12
  848ad8:	48 8b ac 24 40 01 00 	mov    0x140(%rsp),%rbp
  848adf:	00 
  848ae0:	49 29 ec             	sub    %rbp,%r12
  848ae3:	48 8b 98 60 01 00 00 	mov    0x160(%rax),%rbx
  848aea:	48 ff c3             	inc    %rbx
  848aed:	49 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%r14
  848af4:	4c 0f 45 f3          	cmovne %rbx,%r14
  848af8:	48 8b 18             	mov    (%rax),%rbx
  848afb:	48 c1 e3 04          	shl    $0x4,%rbx
  848aff:	4c 8b 78 48          	mov    0x48(%rax),%r15
  848b03:	4c 03 78 30          	add    0x30(%rax),%r15
  848b07:	4c 8b 68 18          	mov    0x18(%rax),%r13
  848b0b:	4a 8d 1c eb          	lea    (%rbx,%r13,8),%rbx
  848b0f:	4a 8d 1c bb          	lea    (%rbx,%r15,4),%rbx
  848b13:	4c 8b 78 60          	mov    0x60(%rax),%r15
  848b17:	49 c1 e7 05          	shl    $0x5,%r15
  848b1b:	49 01 df             	add    %rbx,%r15
  848b1e:	48 8b 98 38 01 00 00 	mov    0x138(%rax),%rbx
  848b25:	4c 8b a8 30 01 00 00 	mov    0x130(%rax),%r13
  848b2c:	4c 89 b0 60 01 00 00 	mov    %r14,0x160(%rax)
  848b33:	4c 89 90 68 01 00 00 	mov    %r10,0x168(%rax)
  848b3a:	4f 8d 34 1b          	lea    (%r11,%r11,1),%r14
  848b3e:	4c 89 b0 70 01 00 00 	mov    %r14,0x170(%rax)
  848b45:	48 c7 80 78 01 00 00 	movq   $0x1,0x178(%rax)
  848b4c:	01 00 00 00 
  848b50:	4c 89 90 80 01 00 00 	mov    %r10,0x180(%rax)
  848b57:	48 89 90 88 01 00 00 	mov    %rdx,0x188(%rax)
  848b5e:	4c 89 98 90 01 00 00 	mov    %r11,0x190(%rax)
  848b65:	48 89 88 98 01 00 00 	mov    %rcx,0x198(%rax)
  848b6c:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  848b71:	48 89 88 a0 01 00 00 	mov    %rcx,0x1a0(%rax)
  848b78:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
  848b7d:	48 89 88 a8 01 00 00 	mov    %rcx,0x1a8(%rax)
  848b84:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  848b89:	48 89 88 b0 01 00 00 	mov    %rcx,0x1b0(%rax)
  848b90:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
  848b97:	00 
  848b98:	48 89 88 b8 01 00 00 	mov    %rcx,0x1b8(%rax)
  848b9f:	4c 89 80 c0 01 00 00 	mov    %r8,0x1c0(%rax)
  848ba6:	48 8b 94 24 38 01 00 	mov    0x138(%rsp),%rdx
  848bad:	00 
  848bae:	48 89 90 c8 01 00 00 	mov    %rdx,0x1c8(%rax)
  848bb5:	48 89 a8 d0 01 00 00 	mov    %rbp,0x1d0(%rax)
  848bbc:	4c 89 a0 d8 01 00 00 	mov    %r12,0x1d8(%rax)
  848bc3:	48 8b 8c 24 c0 03 00 	mov    0x3c0(%rsp),%rcx
  848bca:	00 
  848bcb:	48 89 88 e0 01 00 00 	mov    %rcx,0x1e0(%rax)
  848bd2:	48 89 b8 e8 01 00 00 	mov    %rdi,0x1e8(%rax)
  848bd9:	4c 89 88 f0 01 00 00 	mov    %r9,0x1f0(%rax)
  848be0:	49 01 dd             	add    %rbx,%r13
  848be3:	48 89 98 f8 01 00 00 	mov    %rbx,0x1f8(%rax)
  848bea:	4c 89 a8 00 02 00 00 	mov    %r13,0x200(%rax)
  848bf1:	4c 89 b8 08 02 00 00 	mov    %r15,0x208(%rax)
  848bf8:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
  848bff:	00 
  848c00:	48 89 88 10 02 00 00 	mov    %rcx,0x210(%rax)
  848c07:	48 89 b0 18 02 00 00 	mov    %rsi,0x218(%rax)
  848c0e:	c6 80 20 02 00 00 00 	movb   $0x0,0x220(%rax)
  848c15:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  848c1a:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  848c1f:	48 89 47 08          	mov    %rax,0x8(%rdi)
  848c23:	c7 07 ff ff ff ff    	movl   $0xffffffff,(%rdi)
  848c29:	e9 58 dd ff ff       	jmp    846986 <<gpui_gpu::renderer::RendererState>::render+0xf6>
  848c2e:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  848c33:	e9 40 dd ff ff       	jmp    846978 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  848c38:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
  848c3f:	00 00 
  848c41:	31 c0                	xor    %eax,%eax
  848c43:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  848c4a:	00 00 
  848c4c:	eb 12                	jmp    848c60 <<gpui_gpu::renderer::RendererState>::render+0x23d0>
  848c4e:	48 ff 44 24 10       	incq   0x10(%rsp)
  848c53:	48 83 c0 08          	add    $0x8,%rax
  848c57:	48 39 c7             	cmp    %rax,%rdi
  848c5a:	0f 84 56 fa ff ff    	je     8486b6 <<gpui_gpu::renderer::RendererState>::render+0x1e26>
  848c60:	41 8b 4c 00 04       	mov    0x4(%r8,%rax,1),%ecx
  848c65:	89 ca                	mov    %ecx,%edx
  848c67:	f7 da                	neg    %edx
  848c69:	70 e3                	jo     848c4e <<gpui_gpu::renderer::RendererState>::render+0x23be>
  848c6b:	41 39 0c 00          	cmp    %ecx,(%r8,%rax,1)
  848c6f:	74 e2                	je     848c53 <<gpui_gpu::renderer::RendererState>::render+0x23c3>
  848c71:	48 8d 3d 70 44 62 00 	lea    0x624470(%rip),%rdi        # e6d0e8 <anon.73008a35a96df0a2856fb218eeb1f96e.29.llvm.10068165481344284278+0x10>
  848c78:	ff 15 1a 68 67 00    	call   *0x67681a(%rip)        # ebf498 <_DYNAMIC+0x838>
  848c7e:	48 8d 3d cb 42 62 00 	lea    0x6242cb(%rip),%rdi        # e6cf50 <anon.59d2062463a56a48178a879f804ca345.3.llvm.17286516331901804694+0x2b0>
  848c85:	ff 15 3d 63 67 00    	call   *0x67633d(%rip)        # ebefc8 <_DYNAMIC+0x368>
  848c8b:	48 8d 15 d6 42 62 00 	lea    0x6242d6(%rip),%rdx        # e6cf68 <anon.59d2062463a56a48178a879f804ca345.3.llvm.17286516331901804694+0x2c8>
  848c92:	ff 15 a8 64 67 00    	call   *0x6764a8(%rip)        # ebf140 <_DYNAMIC+0x4e0>
  848c98:	48 8d 15 99 42 62 00 	lea    0x624299(%rip),%rdx        # e6cf38 <anon.59d2062463a56a48178a879f804ca345.3.llvm.17286516331901804694+0x298>
  848c9f:	ff 15 9b 64 67 00    	call   *0x67649b(%rip)        # ebf140 <_DYNAMIC+0x4e0>
  848ca5:	49 89 c6             	mov    %rax,%r14
  848ca8:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  848cad:	4c 89 a8 30 03 00 00 	mov    %r13,0x330(%rax)
  848cb4:	48 89 a8 38 03 00 00 	mov    %rbp,0x338(%rax)
  848cbb:	4c 89 f7             	mov    %r14,%rdi
  848cbe:	e8 1d f0 61 00       	call   e67ce0 <_Unwind_Resume@plt>
  848cc3:	49 89 c6             	mov    %rax,%r14
  848cc6:	f0 49 ff 4d 00       	lock decq 0x0(%r13)
  848ccb:	75 20                	jne    848ced <<gpui_gpu::renderer::RendererState>::render+0x245d>
  848ccd:	48 8d bc 24 10 03 00 	lea    0x310(%rsp),%rdi
  848cd4:	00 
  848cd5:	ff 15 0d 64 67 00    	call   *0x67640d(%rip)        # ebf0e8 <_DYNAMIC+0x488>
  848cdb:	eb 10                	jmp    848ced <<gpui_gpu::renderer::RendererState>::render+0x245d>
  848cdd:	ff 15 e5 61 67 00    	call   *0x6761e5(%rip)        # ebeec8 <_DYNAMIC+0x268>
  848ce3:	49 89 c6             	mov    %rax,%r14
  848ce6:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
  848ced:	4c 89 f7             	mov    %r14,%rdi
  848cf0:	e8 eb ef 61 00       	call   e67ce0 <_Unwind_Resume@plt>
