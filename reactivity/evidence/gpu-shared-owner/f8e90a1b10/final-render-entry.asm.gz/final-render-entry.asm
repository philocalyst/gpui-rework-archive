
/tmp/gpui-shared-gpu-controls/f8e90a1b10/owned:     file format elf64-x86-64


Disassembly of section .text:

0000000000846890 <<gpui_gpu::renderer::RendererState>::render>:
  846890:	55                   	push   %rbp
  846891:	41 57                	push   %r15
  846893:	41 56                	push   %r14
  846895:	41 55                	push   %r13
  846897:	41 54                	push   %r12
  846899:	53                   	push   %rbx
  84689a:	48 81 ec 68 05 00 00 	sub    $0x568,%rsp
  8468a1:	48 8b 86 20 03 00 00 	mov    0x320(%rsi),%rax
  8468a8:	48 3b 42 20          	cmp    0x20(%rdx),%rax
  8468ac:	0f 85 ce 00 00 00    	jne    846980 <<gpui_gpu::renderer::RendererState>::render+0xf0>
  8468b2:	48 8d 9e 30 03 00 00 	lea    0x330(%rsi),%rbx
  8468b9:	48 8b 86 30 03 00 00 	mov    0x330(%rsi),%rax
  8468c0:	48 85 c0             	test   %rax,%rax
  8468c3:	74 2d                	je     8468f2 <<gpui_gpu::renderer::RendererState>::render+0x62>
  8468c5:	f0 48 ff 08          	lock decq (%rax)
  8468c9:	75 27                	jne    8468f2 <<gpui_gpu::renderer::RendererState>::render+0x62>
  8468cb:	49 89 fe             	mov    %rdi,%r14
  8468ce:	48 89 df             	mov    %rbx,%rdi
  8468d1:	49 89 f4             	mov    %rsi,%r12
  8468d4:	4d 89 c5             	mov    %r8,%r13
  8468d7:	49 89 d7             	mov    %rdx,%r15
  8468da:	48 89 cd             	mov    %rcx,%rbp
  8468dd:	ff 15 05 88 67 00    	call   *0x678805(%rip)        # ebf0e8 <_DYNAMIC+0x488>
  8468e3:	48 89 e9             	mov    %rbp,%rcx
  8468e6:	4c 89 fa             	mov    %r15,%rdx
  8468e9:	4d 89 e8             	mov    %r13,%r8
  8468ec:	4c 89 e6             	mov    %r12,%rsi
  8468ef:	4c 89 f7             	mov    %r14,%rdi
  8468f2:	48 c7 86 30 03 00 00 	movq   $0x0,0x330(%rsi)
  8468f9:	00 00 00 00 
  8468fd:	44 8b 29             	mov    (%rcx),%r13d
  846900:	44 8b 49 08          	mov    0x8(%rcx),%r9d
  846904:	0f b6 41 0d          	movzbl 0xd(%rcx),%eax
  846908:	45 85 c9             	test   %r9d,%r9d
  84690b:	41 0f 98 c2          	sets   %r10b
  84690f:	41 81 e1 ff ff ff 7f 	and    $0x7fffffff,%r9d
  846916:	45 8d 99 00 00 80 ff 	lea    -0x800000(%r9),%r11d
  84691d:	41 81 fb 00 00 00 7f 	cmp    $0x7f000000,%r11d
  846924:	41 0f 92 c3          	setb   %r11b
  846928:	45 20 d3             	and    %r10b,%r11b
  84692b:	41 8d 69 ff          	lea    -0x1(%r9),%ebp
  84692f:	81 fd ff ff 7f 00    	cmp    $0x7fffff,%ebp
  846935:	40 0f 92 c5          	setb   %bpl
  846939:	44 20 d5             	and    %r10b,%bpl
  84693c:	45 85 c9             	test   %r9d,%r9d
  84693f:	41 0f 94 c2          	sete   %r10b
  846943:	41 81 f9 00 00 80 7f 	cmp    $0x7f800000,%r9d
  84694a:	41 0f 94 c6          	sete   %r14b
  84694e:	45 08 d6             	or     %r10b,%r14b
  846951:	41 81 f9 01 00 80 7f 	cmp    $0x7f800001,%r9d
  846958:	41 0f 9d c1          	setge  %r9b
  84695c:	45 08 f1             	or     %r14b,%r9b
  84695f:	41 08 e9             	or     %bpl,%r9b
  846962:	45 85 ed             	test   %r13d,%r13d
  846965:	41 0f 95 c2          	setne  %r10b
  846969:	41 20 c2             	and    %al,%r10b
  84696c:	45 08 da             	or     %r11b,%r10b
  84696f:	45 08 ca             	or     %r9b,%r10b
