
/tmp/gpui-shared-gpu-controls/baseline/owned:     file format elf64-x86-64


Disassembly of section .text:

0000000000845fc0 <<gpui_gpu::renderer::Renderer>::render>:
  845fc0:	55                   	push   %rbp
  845fc1:	41 57                	push   %r15
  845fc3:	41 56                	push   %r14
  845fc5:	41 55                	push   %r13
  845fc7:	41 54                	push   %r12
  845fc9:	53                   	push   %rbx
  845fca:	48 81 ec 58 05 00 00 	sub    $0x558,%rsp
  845fd1:	48 8d 9e 48 03 00 00 	lea    0x348(%rsi),%rbx
  845fd8:	48 8b 86 48 03 00 00 	mov    0x348(%rsi),%rax
  845fdf:	48 85 c0             	test   %rax,%rax
  845fe2:	74 27                	je     84600b <<gpui_gpu::renderer::Renderer>::render+0x4b>
  845fe4:	f0 48 ff 08          	lock decq (%rax)
  845fe8:	75 21                	jne    84600b <<gpui_gpu::renderer::Renderer>::render+0x4b>
  845fea:	49 89 fe             	mov    %rdi,%r14
  845fed:	48 89 df             	mov    %rbx,%rdi
  845ff0:	49 89 f4             	mov    %rsi,%r12
  845ff3:	49 89 cd             	mov    %rcx,%r13
  845ff6:	49 89 d7             	mov    %rdx,%r15
  845ff9:	ff 15 f9 8b 67 00    	call   *0x678bf9(%rip)        # ebebf8 <_DYNAMIC+0x4a0>
  845fff:	4c 89 fa             	mov    %r15,%rdx
  846002:	4c 89 e9             	mov    %r13,%rcx
  846005:	4c 89 e6             	mov    %r12,%rsi
  846008:	4c 89 f7             	mov    %r14,%rdi
  84600b:	48 c7 86 48 03 00 00 	movq   $0x0,0x348(%rsi)
  846012:	00 00 00 00 
  846016:	44 8b 2a             	mov    (%rdx),%r13d
  846019:	44 8b 42 08          	mov    0x8(%rdx),%r8d
  84601d:	0f b6 42 0d          	movzbl 0xd(%rdx),%eax
  846021:	45 85 c0             	test   %r8d,%r8d
  846024:	41 0f 98 c1          	sets   %r9b
  846028:	41 81 e0 ff ff ff 7f 	and    $0x7fffffff,%r8d
  84602f:	45 8d 90 00 00 80 ff 	lea    -0x800000(%r8),%r10d
  846036:	41 81 fa 00 00 00 7f 	cmp    $0x7f000000,%r10d
  84603d:	41 0f 92 c2          	setb   %r10b
  846041:	45 20 ca             	and    %r9b,%r10b
  846044:	45 8d 58 ff          	lea    -0x1(%r8),%r11d
  846048:	41 81 fb ff ff 7f 00 	cmp    $0x7fffff,%r11d
  84604f:	41 0f 92 c3          	setb   %r11b
  846053:	45 20 cb             	and    %r9b,%r11b
  846056:	45 85 c0             	test   %r8d,%r8d
  846059:	41 0f 94 c1          	sete   %r9b
  84605d:	41 81 f8 00 00 80 7f 	cmp    $0x7f800000,%r8d
  846064:	40 0f 94 c5          	sete   %bpl
  846068:	44 08 cd             	or     %r9b,%bpl
  84606b:	41 81 f8 01 00 80 7f 	cmp    $0x7f800001,%r8d
  846072:	41 0f 9d c0          	setge  %r8b
  846076:	41 08 e8             	or     %bpl,%r8b
  846079:	45 08 d8             	or     %r11b,%r8b
  84607c:	45 85 ed             	test   %r13d,%r13d
  84607f:	41 0f 95 c1          	setne  %r9b
  846083:	41 20 c1             	and    %al,%r9b
  846086:	45 08 d1             	or     %r10b,%r9b
  846089:	45 08 c1             	or     %r8b,%r9b
  84608c:	41 f6 c1 01          	test   $0x1,%r9b
  846090:	74 1b                	je     8460ad <<gpui_gpu::renderer::Renderer>::render+0xed>
  846092:	c7 07 03 00 00 00    	movl   $0x3,(%rdi)
  846098:	48 89 f8             	mov    %rdi,%rax
  84609b:	48 81 c4 58 05 00 00 	add    $0x558,%rsp
  8460a2:	5b                   	pop    %rbx
  8460a3:	41 5c                	pop    %r12
  8460a5:	41 5d                	pop    %r13
  8460a7:	41 5e                	pop    %r14
  8460a9:	41 5f                	pop    %r15
  8460ab:	5d                   	pop    %rbp
  8460ac:	c3                   	ret
  8460ad:	66 0f 6e 52 04       	movd   0x4(%rdx),%xmm2
  8460b2:	44 0f b6 62 0c       	movzbl 0xc(%rdx),%r12d
  8460b7:	41 f6 c5 01          	test   $0x1,%r13b
  8460bb:	74 76                	je     846133 <<gpui_gpu::renderer::Renderer>::render+0x173>
  8460bd:	66 41 0f 7e d0       	movd   %xmm2,%r8d
  8460c2:	45 85 c0             	test   %r8d,%r8d
  8460c5:	41 0f 98 c1          	sets   %r9b
  8460c9:	41 81 e0 ff ff ff 7f 	and    $0x7fffffff,%r8d
  8460d0:	45 8d 90 00 00 80 ff 	lea    -0x800000(%r8),%r10d
  8460d7:	41 81 fa 00 00 00 7f 	cmp    $0x7f000000,%r10d
  8460de:	41 0f 92 c2          	setb   %r10b
  8460e2:	45 20 ca             	and    %r9b,%r10b
  8460e5:	45 8d 58 ff          	lea    -0x1(%r8),%r11d
  8460e9:	41 81 fb ff ff 7f 00 	cmp    $0x7fffff,%r11d
  8460f0:	41 0f 92 c3          	setb   %r11b
  8460f4:	45 20 cb             	and    %r9b,%r11b
  8460f7:	45 85 c0             	test   %r8d,%r8d
  8460fa:	41 0f 94 c1          	sete   %r9b
  8460fe:	41 81 f8 00 00 80 7f 	cmp    $0x7f800000,%r8d
  846105:	40 0f 94 c5          	sete   %bpl
  846109:	44 08 cd             	or     %r9b,%bpl
  84610c:	41 81 f8 01 00 80 7f 	cmp    $0x7f800001,%r8d
  846113:	41 0f 9d c0          	setge  %r8b
  846117:	41 08 e8             	or     %bpl,%r8b
  84611a:	45 08 d8             	or     %r11b,%r8b
  84611d:	45 08 d0             	or     %r10b,%r8b
  846120:	0f 85 6c ff ff ff    	jne    846092 <<gpui_gpu::renderer::Renderer>::render+0xd2>
  846126:	0f 2e 15 b3 a9 88 ff 	ucomiss -0x77564d(%rip),%xmm2        # d0ae0 <anon.630a3fff68f6bca64b568be97512ab45.57.llvm.826976926275214120+0x24>
  84612d:	0f 87 5f ff ff ff    	ja     846092 <<gpui_gpu::renderer::Renderer>::render+0xd2>
  846133:	44 8b 72 28          	mov    0x28(%rdx),%r14d
  846137:	44 39 71 20          	cmp    %r14d,0x20(%rcx)
  84613b:	0f 85 51 ff ff ff    	jne    846092 <<gpui_gpu::renderer::Renderer>::render+0xd2>
  846141:	44 8b 7a 2c          	mov    0x2c(%rdx),%r15d
  846145:	44 39 79 24          	cmp    %r15d,0x24(%rcx)
  846149:	0f 85 43 ff ff ff    	jne    846092 <<gpui_gpu::renderer::Renderer>::render+0xd2>
  84614f:	8b 69 38             	mov    0x38(%rcx),%ebp
  846152:	3b ae 58 03 00 00    	cmp    0x358(%rsi),%ebp
  846158:	0f 85 34 ff ff ff    	jne    846092 <<gpui_gpu::renderer::Renderer>::render+0xd2>
  84615e:	83 fd 4c             	cmp    $0x4c,%ebp
  846161:	75 25                	jne    846188 <<gpui_gpu::renderer::Renderer>::render+0x1c8>
  846163:	f3 0f 7e 41 3c       	movq   0x3c(%rcx),%xmm0
  846168:	f3 0f 7e 8e 5c 03 00 	movq   0x35c(%rsi),%xmm1
  84616f:	00 
  846170:	66 0f 76 c8          	pcmpeqd %xmm0,%xmm1
  846174:	66 0f 70 c1 50       	pshufd $0x50,%xmm1,%xmm0
  846179:	66 44 0f 50 c0       	movmskpd %xmm0,%r8d
  84617e:	41 83 f8 03          	cmp    $0x3,%r8d
  846182:	0f 85 0a ff ff ff    	jne    846092 <<gpui_gpu::renderer::Renderer>::render+0xd2>
  846188:	41 81 ff 00 40 00 00 	cmp    $0x4000,%r15d
  84618f:	77 34                	ja     8461c5 <<gpui_gpu::renderer::Renderer>::render+0x205>
  846191:	41 81 fe 00 40 00 00 	cmp    $0x4000,%r14d
  846198:	77 2b                	ja     8461c5 <<gpui_gpu::renderer::Renderer>::render+0x205>
  84619a:	4d 89 f8             	mov    %r15,%r8
  84619d:	4d 0f af c6          	imul   %r14,%r8
  8461a1:	49 81 c0 ff ff ff fe 	add    $0xfffffffffeffffff,%r8
  8461a8:	49 81 f8 00 00 00 ff 	cmp    $0xffffffffff000000,%r8
  8461af:	72 14                	jb     8461c5 <<gpui_gpu::renderer::Renderer>::render+0x205>
  8461b1:	4c 8b 52 10          	mov    0x10(%rdx),%r10
  8461b5:	4d 8b 8a 80 00 00 00 	mov    0x80(%r10),%r9
  8461bc:	49 81 f9 00 00 01 00 	cmp    $0x10000,%r9
  8461c3:	76 0b                	jbe    8461d0 <<gpui_gpu::renderer::Renderer>::render+0x210>
  8461c5:	c7 07 05 00 00 00    	movl   $0x5,(%rdi)
  8461cb:	e9 c8 fe ff ff       	jmp    846098 <<gpui_gpu::renderer::Renderer>::render+0xd8>
  8461d0:	66 0f 6e 42 18       	movd   0x18(%rdx),%xmm0
  8461d5:	66 41 0f 7e c0       	movd   %xmm0,%r8d
  8461da:	41 81 e0 ff ff ff 7f 	and    $0x7fffffff,%r8d
  8461e1:	41 81 f8 ff ff 7f 7f 	cmp    $0x7f7fffff,%r8d
  8461e8:	0f 8f a4 fe ff ff    	jg     846092 <<gpui_gpu::renderer::Renderer>::render+0xd2>
  8461ee:	66 0f db 05 7a da 88 	pand   -0x772586(%rip),%xmm0        # d3c70 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x490>
  8461f5:	ff 
  8461f6:	0f 2e 05 3b ab 88 ff 	ucomiss -0x7754c5(%rip),%xmm0        # d0d38 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x28>
  8461fd:	0f 87 8f fe ff ff    	ja     846092 <<gpui_gpu::renderer::Renderer>::render+0xd2>
  846203:	66 0f 6e 42 1c       	movd   0x1c(%rdx),%xmm0
  846208:	66 41 0f 7e c0       	movd   %xmm0,%r8d
  84620d:	41 81 e0 ff ff ff 7f 	and    $0x7fffffff,%r8d
  846214:	41 81 f8 ff ff 7f 7f 	cmp    $0x7f7fffff,%r8d
  84621b:	0f 8f 71 fe ff ff    	jg     846092 <<gpui_gpu::renderer::Renderer>::render+0xd2>
  846221:	66 0f db 05 47 da 88 	pand   -0x7725b9(%rip),%xmm0        # d3c70 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x490>
  846228:	ff 
  846229:	0f 2e 05 08 ab 88 ff 	ucomiss -0x7754f8(%rip),%xmm0        # d0d38 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x28>
  846230:	0f 87 5c fe ff ff    	ja     846092 <<gpui_gpu::renderer::Renderer>::render+0xd2>
  846236:	66 0f 6e 42 20       	movd   0x20(%rdx),%xmm0
  84623b:	66 41 0f 7e c0       	movd   %xmm0,%r8d
  846240:	41 81 e0 ff ff ff 7f 	and    $0x7fffffff,%r8d
  846247:	41 81 f8 ff ff 7f 7f 	cmp    $0x7f7fffff,%r8d
  84624e:	0f 8f 3e fe ff ff    	jg     846092 <<gpui_gpu::renderer::Renderer>::render+0xd2>
  846254:	66 0f db 05 14 da 88 	pand   -0x7725ec(%rip),%xmm0        # d3c70 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x490>
  84625b:	ff 
  84625c:	0f 2e 05 d5 aa 88 ff 	ucomiss -0x77552b(%rip),%xmm0        # d0d38 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x28>
  846263:	0f 87 29 fe ff ff    	ja     846092 <<gpui_gpu::renderer::Renderer>::render+0xd2>
  846269:	66 0f 6e 42 24       	movd   0x24(%rdx),%xmm0
  84626e:	66 41 0f 7e c0       	movd   %xmm0,%r8d
  846273:	41 81 e0 ff ff ff 7f 	and    $0x7fffffff,%r8d
  84627a:	41 81 f8 ff ff 7f 7f 	cmp    $0x7f7fffff,%r8d
  846281:	0f 8f 0b fe ff ff    	jg     846092 <<gpui_gpu::renderer::Renderer>::render+0xd2>
  846287:	66 0f 6f 0d e1 d9 88 	movdqa -0x77261f(%rip),%xmm1        # d3c70 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x490>
  84628e:	ff 
  84628f:	66 0f db c8          	pand   %xmm0,%xmm1
  846293:	0f 2e 0d 9e aa 88 ff 	ucomiss -0x775562(%rip),%xmm1        # d0d38 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x28>
  84629a:	0f 87 f2 fd ff ff    	ja     846092 <<gpui_gpu::renderer::Renderer>::render+0xd2>
  8462a0:	0f 57 c9             	xorps  %xmm1,%xmm1
  8462a3:	0f 2e c1             	ucomiss %xmm1,%xmm0
  8462a6:	0f 82 e6 fd ff ff    	jb     846092 <<gpui_gpu::renderer::Renderer>::render+0xd2>
  8462ac:	f3 0f 10 0d 00 a7 88 	movss  -0x775900(%rip),%xmm1        # d09b4 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x10>
  8462b3:	ff 
  8462b4:	0f 2e c8             	ucomiss %xmm0,%xmm1
  8462b7:	0f 82 d5 fd ff ff    	jb     846092 <<gpui_gpu::renderer::Renderer>::render+0xd2>
  8462bd:	44 0f b7 42 30       	movzwl 0x30(%rdx),%r8d
  8462c2:	44 0f b7 5a 32       	movzwl 0x32(%rdx),%r11d
  8462c7:	83 fd 28             	cmp    $0x28,%ebp
  8462ca:	75 0a                	jne    8462d6 <<gpui_gpu::renderer::Renderer>::render+0x316>
  8462cc:	a8 01                	test   $0x1,%al
  8462ce:	0f 84 be fd ff ff    	je     846092 <<gpui_gpu::renderer::Renderer>::render+0xd2>
  8462d4:	eb 1b                	jmp    8462f1 <<gpui_gpu::renderer::Renderer>::render+0x331>
  8462d6:	a8 01                	test   $0x1,%al
  8462d8:	0f 85 b4 fd ff ff    	jne    846092 <<gpui_gpu::renderer::Renderer>::render+0xd2>
  8462de:	0f 2e 05 cf a6 88 ff 	ucomiss -0x775931(%rip),%xmm0        # d09b4 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x10>
  8462e5:	0f 85 a7 fd ff ff    	jne    846092 <<gpui_gpu::renderer::Renderer>::render+0xd2>
  8462eb:	0f 8a a1 fd ff ff    	jp     846092 <<gpui_gpu::renderer::Renderer>::render+0xd2>
  8462f1:	66 44 89 5c 24 18    	mov    %r11w,0x18(%rsp)
  8462f7:	66 44 89 44 24 10    	mov    %r8w,0x10(%rsp)
  8462fd:	4c 89 54 24 68       	mov    %r10,0x68(%rsp)
  846302:	4c 89 8c 24 c8 00 00 	mov    %r9,0xc8(%rsp)
  846309:	00 
  84630a:	f3 0f 11 8c 24 ec 00 	movss  %xmm1,0xec(%rsp)
  846311:	00 00 
  846313:	66 0f 7e 94 24 4c 01 	movd   %xmm2,0x14c(%rsp)
  84631a:	00 00 
  84631c:	48 89 8c 24 00 04 00 	mov    %rcx,0x400(%rsp)
  846323:	00 
  846324:	48 89 7c 24 48       	mov    %rdi,0x48(%rsp)
  846329:	49 8d 46 0f          	lea    0xf(%r14),%rax
  84632d:	48 c1 e8 04          	shr    $0x4,%rax
  846331:	41 8d 4f 0f          	lea    0xf(%r15),%ecx
  846335:	c1 e9 04             	shr    $0x4,%ecx
  846338:	48 8d 7e 18          	lea    0x18(%rsi),%rdi
  84633c:	48 c7 46 28 00 00 00 	movq   $0x0,0x28(%rsi)
  846343:	00 
  846344:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  846349:	0f af c8             	imul   %eax,%ecx
  84634c:	48 89 bc 24 d8 00 00 	mov    %rdi,0xd8(%rsp)
  846353:	00 
  846354:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
  846359:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  84635e:	48 89 ce             	mov    %rcx,%rsi
  846361:	48 89 94 24 d0 00 00 	mov    %rdx,0xd0(%rsp)
  846368:	00 
  846369:	31 d2                	xor    %edx,%edx
  84636b:	e8 60 53 00 00       	call   84b6d0 <<alloc::vec::Vec<[u32; 2]>>::resize>
  846370:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  846375:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
  84637c:	00 
  84637d:	48 8b bc 24 d0 00 00 	mov    0xd0(%rsp),%rdi
  846384:	00 
  846385:	ff 15 d5 8b 67 00    	call   *0x678bd5(%rip)        # ebef60 <_DYNAMIC+0x808>
  84638b:	48 89 d6             	mov    %rdx,%rsi
  84638e:	48 29 c6             	sub    %rax,%rsi
  846391:	48 81 fe 00 00 30 00 	cmp    $0x300000,%rsi
  846398:	76 10                	jbe    8463aa <<gpui_gpu::renderer::Renderer>::render+0x3ea>
  84639a:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
  84639f:	c7 07 05 00 00 00    	movl   $0x5,(%rdi)
  8463a5:	e9 ee fc ff ff       	jmp    846098 <<gpui_gpu::renderer::Renderer>::render+0xd8>
  8463aa:	48 89 f1             	mov    %rsi,%rcx
  8463ad:	48 c1 e9 03          	shr    $0x3,%rcx
  8463b1:	48 bf ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rdi
  8463b8:	aa aa aa 
  8463bb:	48 0f af f9          	imul   %rcx,%rdi
  8463bf:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
  8463c6:	00 
  8463c7:	48 89 94 24 a0 03 00 	mov    %rdx,0x3a0(%rsp)
  8463ce:	00 
  8463cf:	48 39 c2             	cmp    %rax,%rdx
  8463d2:	48 89 bc 24 e0 00 00 	mov    %rdi,0xe0(%rsp)
  8463d9:	00 
  8463da:	74 2a                	je     846406 <<gpui_gpu::renderer::Renderer>::render+0x446>
  8463dc:	b8 ab aa aa aa       	mov    $0xaaaaaaab,%eax
  8463e1:	48 0f af f0          	imul   %rax,%rsi
  8463e5:	48 c1 ee 2a          	shr    $0x2a,%rsi
  8463e9:	89 f8                	mov    %edi,%eax
  8463eb:	83 e0 3f             	and    $0x3f,%eax
  8463ee:	48 01 fe             	add    %rdi,%rsi
  8463f1:	48 83 f8 01          	cmp    $0x1,%rax
  8463f5:	48 83 de ff          	sbb    $0xffffffffffffffff,%rsi
  8463f9:	48 ff c6             	inc    %rsi
  8463fc:	48 89 b4 24 c0 00 00 	mov    %rsi,0xc0(%rsp)
  846403:	00 
  846404:	eb 0c                	jmp    846412 <<gpui_gpu::renderer::Renderer>::render+0x452>
  846406:	48 c7 84 24 c0 00 00 	movq   $0x0,0xc0(%rsp)
  84640d:	00 00 00 00 00 
  846412:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  846417:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
  84641e:	48 03 88 b0 00 00 00 	add    0xb0(%rax),%rcx
  846425:	48 89 84 24 50 01 00 	mov    %rax,0x150(%rsp)
  84642c:	00 
  84642d:	0f b7 44 24 10       	movzwl 0x10(%rsp),%eax
  846432:	66 89 84 24 70 01 00 	mov    %ax,0x170(%rsp)
  846439:	00 
  84643a:	0f b7 44 24 18       	movzwl 0x18(%rsp),%eax
  84643f:	66 89 84 24 72 01 00 	mov    %ax,0x172(%rsp)
  846446:	00 
  846447:	48 c7 84 24 58 01 00 	movq   $0x0,0x158(%rsp)
  84644e:	00 00 00 00 00 
  846453:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  84645a:	00 
  84645b:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
  846462:	00 
  846463:	48 89 8c 24 40 01 00 	mov    %rcx,0x140(%rsp)
  84646a:	00 
  84646b:	48 89 8c 24 68 01 00 	mov    %rcx,0x168(%rsp)
  846472:	00 
  846473:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  846478:	0f b6 90 65 03 00 00 	movzbl 0x365(%rax),%edx
  84647f:	48 8d bc 24 48 04 00 	lea    0x448(%rsp),%rdi
  846486:	00 
  846487:	48 8d b4 24 50 01 00 	lea    0x150(%rsp),%rsi
  84648e:	00 
  84648f:	e8 1c e9 ff ff       	call   844db0 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::Renderer>::render_observed<<gpui_gpu::renderer::Renderer>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>>
  846494:	8b 84 24 48 04 00 00 	mov    0x448(%rsp),%eax
  84649b:	83 f8 ff             	cmp    $0xffffffff,%eax
  84649e:	74 2e                	je     8464ce <<gpui_gpu::renderer::Renderer>::render+0x50e>
  8464a0:	8b 8c 24 4c 04 00 00 	mov    0x44c(%rsp),%ecx
  8464a7:	48 8b 94 24 50 04 00 	mov    0x450(%rsp),%rdx
  8464ae:	00 
  8464af:	0f 10 84 24 58 04 00 	movups 0x458(%rsp),%xmm0
  8464b6:	00 
  8464b7:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
  8464bc:	0f 11 47 10          	movups %xmm0,0x10(%rdi)
  8464c0:	89 07                	mov    %eax,(%rdi)
  8464c2:	89 4f 04             	mov    %ecx,0x4(%rdi)
  8464c5:	48 89 57 08          	mov    %rdx,0x8(%rdi)
  8464c9:	e9 ca fb ff ff       	jmp    846098 <<gpui_gpu::renderer::Renderer>::render+0xd8>
  8464ce:	48 8b 94 24 50 04 00 	mov    0x450(%rsp),%rdx
  8464d5:	00 
  8464d6:	48 03 94 24 c0 00 00 	add    0xc0(%rsp),%rdx
  8464dd:	00 
  8464de:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  8464e3:	48 8b 77 10          	mov    0x10(%rdi),%rsi
  8464e7:	b9 04 00 00 00       	mov    $0x4,%ecx
  8464ec:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  8464f2:	e8 d9 6b 00 00       	call   84d0d0 <<alloc::raw_vec::RawVecInner>::try_reserve_exact>
  8464f7:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  8464fb:	0f 85 99 fe ff ff    	jne    84639a <<gpui_gpu::renderer::Renderer>::render+0x3da>
  846501:	0f b7 44 24 10       	movzwl 0x10(%rsp),%eax
  846506:	89 44 24 10          	mov    %eax,0x10(%rsp)
  84650a:	0f b7 44 24 18       	movzwl 0x18(%rsp),%eax
  84650f:	89 44 24 78          	mov    %eax,0x78(%rsp)
  846513:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  846518:	48 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%rsi
  84651f:	00 
  846520:	48 8b 94 24 e0 00 00 	mov    0xe0(%rsp),%rdx
  846527:	00 
  846528:	e8 73 6e 00 00       	call   84d3a0 <gpui_gpu::renderer::slots::write_prefix>
  84652d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  846532:	48 8d 78 48          	lea    0x48(%rax),%rdi
  846536:	48 c7 40 58 00 00 00 	movq   $0x0,0x58(%rax)
  84653d:	00 
  84653e:	48 89 bc 24 08 04 00 	mov    %rdi,0x408(%rsp)
  846545:	00 
  846546:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  84654b:	31 d2                	xor    %edx,%edx
  84654d:	e8 9e 52 00 00       	call   84b7f0 <<alloc::vec::Vec<u32>>::resize>
  846552:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  846557:	48 c7 40 70 00 00 00 	movq   $0x0,0x70(%rax)
  84655e:	00 
  84655f:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
  846564:	75 0f                	jne    846575 <<gpui_gpu::renderer::Renderer>::render+0x5b5>
  846566:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  84656b:	48 8d 78 60          	lea    0x60(%rax),%rdi
  84656f:	ff 15 f3 89 67 00    	call   *0x6789f3(%rip)        # ebef68 <_DYNAMIC+0x810>
  846575:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  84657a:	48 8b 48 68          	mov    0x68(%rax),%rcx
  84657e:	0f 57 c0             	xorps  %xmm0,%xmm0
  846581:	0f 11 41 10          	movups %xmm0,0x10(%rcx)
  846585:	0f 11 01             	movups %xmm0,(%rcx)
  846588:	48 c7 40 70 01 00 00 	movq   $0x1,0x70(%rax)
  84658f:	00 
  846590:	48 8d b8 10 03 00 00 	lea    0x310(%rax),%rdi
  846597:	e8 84 4b 00 00       	call   84b120 <<hashbrown::raw::RawTable<([u32; 8], u32)>>::clear>
  84659c:	8b 4c 24 78          	mov    0x78(%rsp),%ecx
  8465a0:	c1 e1 10             	shl    $0x10,%ecx
  8465a3:	03 4c 24 10          	add    0x10(%rsp),%ecx
  8465a7:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  8465ac:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
  8465b3:	00 
  8465b4:	48 c7 84 24 e0 02 00 	movq   $0x0,0x2e0(%rsp)
  8465bb:	00 00 00 00 00 
  8465c0:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  8465c7:	00 
  8465c8:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
  8465cf:	00 
  8465d0:	48 8b 84 24 40 01 00 	mov    0x140(%rsp),%rax
  8465d7:	00 
  8465d8:	48 89 84 24 f0 02 00 	mov    %rax,0x2f0(%rsp)
  8465df:	00 
  8465e0:	89 4c 24 78          	mov    %ecx,0x78(%rsp)
  8465e4:	89 8c 24 f8 02 00 00 	mov    %ecx,0x2f8(%rsp)
  8465eb:	48 8d bc 24 48 02 00 	lea    0x248(%rsp),%rdi
  8465f2:	00 
  8465f3:	48 8d b4 24 d8 02 00 	lea    0x2d8(%rsp),%rsi
  8465fa:	00 
  8465fb:	ff 15 6f 89 67 00    	call   *0x67896f(%rip)        # ebef70 <_DYNAMIC+0x818>
  846601:	48 8b 84 24 48 02 00 	mov    0x248(%rsp),%rax
  846608:	00 
  846609:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  84660e:	48 85 c0             	test   %rax,%rax
  846611:	0f 84 3a 0d 00 00    	je     847351 <<gpui_gpu::renderer::Renderer>::render+0x1391>
  846617:	48 c7 84 24 b8 00 00 	movq   $0x0,0xb8(%rsp)
  84661e:	00 00 00 00 00 
  846623:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  84662a:	00 00 
  84662c:	48 c7 44 24 70 00 00 	movq   $0x0,0x70(%rsp)
  846633:	00 00 
  846635:	48 c7 84 24 30 01 00 	movq   $0x0,0x130(%rsp)
  84663c:	00 00 00 00 00 
  846641:	48 c7 84 24 38 01 00 	movq   $0x0,0x138(%rsp)
  846648:	00 00 00 00 00 
  84664d:	48 8b 8c 24 50 02 00 	mov    0x250(%rsp),%rcx
  846654:	00 
  846655:	48 8b 94 24 58 02 00 	mov    0x258(%rsp),%rdx
  84665c:	00 
  84665d:	48 89 94 24 a0 00 00 	mov    %rdx,0xa0(%rsp)
  846664:	00 
  846665:	48 8d bc 24 60 02 00 	lea    0x260(%rsp),%rdi
  84666c:	00 
  84666d:	0f 10 07             	movups (%rdi),%xmm0
  846670:	0f 10 4f 10          	movups 0x10(%rdi),%xmm1
  846674:	0f 10 57 20          	movups 0x20(%rdi),%xmm2
  846678:	0f 29 94 24 20 03 00 	movaps %xmm2,0x320(%rsp)
  84667f:	00 
  846680:	0f 29 8c 24 10 03 00 	movaps %xmm1,0x310(%rsp)
  846687:	00 
  846688:	0f 29 84 24 00 03 00 	movaps %xmm0,0x300(%rsp)
  84668f:	00 
  846690:	4c 8d 84 24 90 02 00 	lea    0x290(%rsp),%r8
  846697:	00 
  846698:	41 0f 10 00          	movups (%r8),%xmm0
  84669c:	0f 29 84 24 00 05 00 	movaps %xmm0,0x500(%rsp)
  8466a3:	00 
  8466a4:	0f 10 47 40          	movups 0x40(%rdi),%xmm0
  8466a8:	0f 29 84 24 30 04 00 	movaps %xmm0,0x430(%rsp)
  8466af:	00 
  8466b0:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  8466b5:	0f b6 b0 65 03 00 00 	movzbl 0x365(%rax),%esi
  8466bc:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  8466c1:	48 89 84 24 50 01 00 	mov    %rax,0x150(%rsp)
  8466c8:	00 
  8466c9:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  8466ce:	48 89 8c 24 58 01 00 	mov    %rcx,0x158(%rsp)
  8466d5:	00 
  8466d6:	48 89 94 24 60 01 00 	mov    %rdx,0x160(%rsp)
  8466dd:	00 
  8466de:	0f 10 07             	movups (%rdi),%xmm0
  8466e1:	0f 10 4f 10          	movups 0x10(%rdi),%xmm1
  8466e5:	0f 10 57 20          	movups 0x20(%rdi),%xmm2
  8466e9:	48 8d 84 24 68 01 00 	lea    0x168(%rsp),%rax
  8466f0:	00 
  8466f1:	0f 11 50 20          	movups %xmm2,0x20(%rax)
  8466f5:	0f 11 48 10          	movups %xmm1,0x10(%rax)
  8466f9:	0f 11 00             	movups %xmm0,(%rax)
  8466fc:	41 0f 10 00          	movups (%r8),%xmm0
  846700:	0f 11 40 30          	movups %xmm0,0x30(%rax)
  846704:	0f 10 47 40          	movups 0x40(%rdi),%xmm0
  846708:	0f 11 40 40          	movups %xmm0,0x40(%rax)
  84670c:	48 8d bc 24 50 01 00 	lea    0x150(%rsp),%rdi
  846713:	00 
  846714:	e8 27 2f 00 00       	call   849640 <gpui_gpu::renderer::compact_group>
  846719:	88 44 24 30          	mov    %al,0x30(%rsp)
  84671d:	48 8d b4 24 60 02 00 	lea    0x260(%rsp),%rsi
  846724:	00 
  846725:	0f 10 06             	movups (%rsi),%xmm0
  846728:	0f 10 4e 10          	movups 0x10(%rsi),%xmm1
  84672c:	0f 10 56 20          	movups 0x20(%rsi),%xmm2
  846730:	0f 29 84 24 10 05 00 	movaps %xmm0,0x510(%rsp)
  846737:	00 
  846738:	0f 29 8c 24 20 05 00 	movaps %xmm1,0x520(%rsp)
  84673f:	00 
  846740:	0f 29 94 24 30 05 00 	movaps %xmm2,0x530(%rsp)
  846747:	00 
  846748:	48 8d 94 24 90 02 00 	lea    0x290(%rsp),%rdx
  84674f:	00 
  846750:	0f 10 02             	movups (%rdx),%xmm0
  846753:	0f 29 84 24 40 05 00 	movaps %xmm0,0x540(%rsp)
  84675a:	00 
  84675b:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  846760:	e8 8b f0 ff ff       	call   8457f0 <<gpui_gpu::renderer::Renderer>::correction>
  846765:	89 44 24 7c          	mov    %eax,0x7c(%rsp)
  846769:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  846770:	00 
  846771:	48 8d 04 85 00 00 00 	lea    0x0(,%rax,4),%rax
  846778:	00 
  846779:	48 89 84 24 e0 03 00 	mov    %rax,0x3e0(%rsp)
  846780:	00 
  846781:	80 7c 24 30 00       	cmpb   $0x0,0x30(%rsp)
  846786:	0f 84 d5 01 00 00    	je     846961 <<gpui_gpu::renderer::Renderer>::render+0x9a1>
  84678c:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
  846791:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  846798:	00 
  846799:	48 8d 04 81          	lea    (%rcx,%rax,4),%rax
  84679d:	48 89 8c 24 10 04 00 	mov    %rcx,0x410(%rsp)
  8467a4:	00 
  8467a5:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
  8467ac:	00 
  8467ad:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  8467b2:	48 89 84 24 20 04 00 	mov    %rax,0x420(%rsp)
  8467b9:	00 
  8467ba:	48 c7 84 24 28 04 00 	movq   $0x0,0x428(%rsp)
  8467c1:	00 00 00 00 00 
  8467c6:	48 8d bc 24 30 03 00 	lea    0x330(%rsp),%rdi
  8467cd:	00 
  8467ce:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
  8467d5:	00 
  8467d6:	e8 f5 34 00 00       	call   849cd0 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  8467db:	80 bc 24 38 03 00 00 	cmpb   $0xff,0x338(%rsp)
  8467e2:	ff 
  8467e3:	0f 84 b4 06 00 00    	je     846e9d <<gpui_gpu::renderer::Renderer>::render+0xedd>
  8467e9:	0f 57 c0             	xorps  %xmm0,%xmm0
  8467ec:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
  8467f1:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
  8467f8:	00 
  8467f9:	48 8b 94 24 30 03 00 	mov    0x330(%rsp),%rdx
  846800:	00 
  846801:	48 03 54 24 70       	add    0x70(%rsp),%rdx
  846806:	48 8d b4 24 38 03 00 	lea    0x338(%rsp),%rsi
  84680d:	00 
  84680e:	0f 10 46 38          	movups 0x38(%rsi),%xmm0
  846812:	48 8d 8c 24 68 01 00 	lea    0x168(%rsp),%rcx
  846819:	00 
  84681a:	0f 11 41 20          	movups %xmm0,0x20(%rcx)
  84681e:	0f 10 46 48          	movups 0x48(%rsi),%xmm0
  846822:	0f 11 41 70          	movups %xmm0,0x70(%rcx)
  846826:	48 8b 46 30          	mov    0x30(%rsi),%rax
  84682a:	48 89 84 24 80 01 00 	mov    %rax,0x180(%rsp)
  846831:	00 
  846832:	0f 10 06             	movups (%rsi),%xmm0
  846835:	0f 10 4e 10          	movups 0x10(%rsi),%xmm1
  846839:	0f 10 56 20          	movups 0x20(%rsi),%xmm2
  84683d:	0f 29 94 24 70 01 00 	movaps %xmm2,0x170(%rsp)
  846844:	00 
  846845:	0f 29 8c 24 60 01 00 	movaps %xmm1,0x160(%rsp)
  84684c:	00 
  84684d:	0f 29 84 24 50 01 00 	movaps %xmm0,0x150(%rsp)
  846854:	00 
  846855:	48 8d 84 24 60 02 00 	lea    0x260(%rsp),%rax
  84685c:	00 
  84685d:	0f 10 40 40          	movups 0x40(%rax),%xmm0
  846861:	0f 11 81 80 00 00 00 	movups %xmm0,0x80(%rcx)
  846868:	0f 10 00             	movups (%rax),%xmm0
  84686b:	0f 10 48 10          	movups 0x10(%rax),%xmm1
  84686f:	0f 10 50 20          	movups 0x20(%rax),%xmm2
  846873:	0f 11 51 50          	movups %xmm2,0x50(%rcx)
  846877:	0f 11 49 40          	movups %xmm1,0x40(%rcx)
  84687b:	0f 11 41 30          	movups %xmm0,0x30(%rcx)
  84687f:	48 8d 84 24 90 02 00 	lea    0x290(%rsp),%rax
  846886:	00 
  846887:	0f 10 00             	movups (%rax),%xmm0
  84688a:	0f 11 41 60          	movups %xmm0,0x60(%rcx)
  84688e:	48 8d bc 24 00 01 00 	lea    0x100(%rsp),%rdi
  846895:	00 
  846896:	48 8d b4 24 50 01 00 	lea    0x150(%rsp),%rsi
  84689d:	00 
  84689e:	44 89 f1             	mov    %r14d,%ecx
  8468a1:	45 89 f8             	mov    %r15d,%r8d
  8468a4:	e8 e7 2d 00 00       	call   849690 <gpui_gpu::renderer::validate_draw>
  8468a9:	8b 8c 24 00 01 00 00 	mov    0x100(%rsp),%ecx
  8468b0:	48 8b 84 24 04 01 00 	mov    0x104(%rsp),%rax
  8468b7:	00 
  8468b8:	83 f9 ff             	cmp    $0xffffffff,%ecx
  8468bb:	0f 85 52 0b 00 00    	jne    847413 <<gpui_gpu::renderer::Renderer>::render+0x1453>
  8468c1:	89 c1                	mov    %eax,%ecx
  8468c3:	48 c1 e8 20          	shr    $0x20,%rax
  8468c7:	66 0f 6e c1          	movd   %ecx,%xmm0
  8468cb:	0f 28 54 24 50       	movaps 0x50(%rsp),%xmm2
  8468d0:	0f 28 ca             	movaps %xmm2,%xmm1
  8468d3:	f3 0f 5f c8          	maxss  %xmm0,%xmm1
  8468d7:	0f 28 d9             	movaps %xmm1,%xmm3
  8468da:	f3 0f c2 d9 03       	cmpunordss %xmm1,%xmm3
  8468df:	0f 28 c3             	movaps %xmm3,%xmm0
  8468e2:	0f 55 c1             	andnps %xmm1,%xmm0
  8468e5:	0f 54 da             	andps  %xmm2,%xmm3
  8468e8:	0f 56 d8             	orps   %xmm0,%xmm3
  8468eb:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
  8468f0:	66 0f 6e c0          	movd   %eax,%xmm0
  8468f4:	0f 28 94 24 80 00 00 	movaps 0x80(%rsp),%xmm2
  8468fb:	00 
  8468fc:	0f 28 ca             	movaps %xmm2,%xmm1
  8468ff:	f3 0f 5f c8          	maxss  %xmm0,%xmm1
  846903:	0f 28 d9             	movaps %xmm1,%xmm3
  846906:	f3 0f c2 d9 03       	cmpunordss %xmm1,%xmm3
  84690b:	0f 28 c3             	movaps %xmm3,%xmm0
  84690e:	0f 55 c1             	andnps %xmm1,%xmm0
  846911:	0f 54 da             	andps  %xmm2,%xmm3
  846914:	0f 56 d8             	orps   %xmm0,%xmm3
  846917:	0f 29 9c 24 90 00 00 	movaps %xmm3,0x90(%rsp)
  84691e:	00 
  84691f:	48 8d bc 24 30 03 00 	lea    0x330(%rsp),%rdi
  846926:	00 
  846927:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
  84692e:	00 
  84692f:	e8 9c 33 00 00       	call   849cd0 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  846934:	80 bc 24 38 03 00 00 	cmpb   $0xff,0x338(%rsp)
  84693b:	ff 
  84693c:	0f 28 44 24 30       	movaps 0x30(%rsp),%xmm0
  846941:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
  846946:	0f 28 84 24 90 00 00 	movaps 0x90(%rsp),%xmm0
  84694d:	00 
  84694e:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
  846955:	00 
  846956:	0f 85 9d fe ff ff    	jne    8467f9 <<gpui_gpu::renderer::Renderer>::render+0x839>
  84695c:	e9 4c 05 00 00       	jmp    846ead <<gpui_gpu::renderer::Renderer>::render+0xeed>
  846961:	48 83 bc 24 a0 00 00 	cmpq   $0x0,0xa0(%rsp)
  846968:	00 00 
  84696a:	0f 84 8b 09 00 00    	je     8472fb <<gpui_gpu::renderer::Renderer>::render+0x133b>
  846970:	8b 44 24 7c          	mov    0x7c(%rsp),%eax
  846974:	0d 00 00 00 80       	or     $0x80000000,%eax
  846979:	89 84 24 48 01 00 00 	mov    %eax,0x148(%rsp)
  846980:	48 c7 84 24 90 00 00 	movq   $0x0,0x90(%rsp)
  846987:	00 00 00 00 00 
  84698c:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  846991:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
  846998:	00 
  846999:	8b 14 08             	mov    (%rax,%rcx,1),%edx
  84699c:	48 8d bc 24 50 01 00 	lea    0x150(%rsp),%rdi
  8469a3:	00 
  8469a4:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  8469a9:	e8 52 e5 ff ff       	call   844f00 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  8469ae:	0f b6 bc 24 50 01 00 	movzbl 0x150(%rsp),%edi
  8469b5:	00 
  8469b6:	48 8d 94 24 51 01 00 	lea    0x151(%rsp),%rdx
  8469bd:	00 
  8469be:	8b 02                	mov    (%rdx),%eax
  8469c0:	8b 4a 03             	mov    0x3(%rdx),%ecx
  8469c3:	48 8d b4 24 80 04 00 	lea    0x480(%rsp),%rsi
  8469ca:	00 
  8469cb:	89 4e cc             	mov    %ecx,-0x34(%rsi)
  8469ce:	89 46 c9             	mov    %eax,-0x37(%rsi)
  8469d1:	48 8b 8c 24 58 01 00 	mov    0x158(%rsp),%rcx
  8469d8:	00 
  8469d9:	48 8b 42 2f          	mov    0x2f(%rdx),%rax
  8469dd:	48 89 46 f8          	mov    %rax,-0x8(%rsi)
  8469e1:	0f 10 42 0f          	movups 0xf(%rdx),%xmm0
  8469e5:	0f 10 4a 1f          	movups 0x1f(%rdx),%xmm1
  8469e9:	0f 11 4e e8          	movups %xmm1,-0x18(%rsi)
  8469ed:	0f 11 46 d8          	movups %xmm0,-0x28(%rsi)
  8469f1:	48 8d 84 24 68 01 00 	lea    0x168(%rsp),%rax
  8469f8:	00 
  8469f9:	0f 10 40 20          	movups 0x20(%rax),%xmm0
  8469fd:	0f 11 06             	movups %xmm0,(%rsi)
  846a00:	0f 10 40 30          	movups 0x30(%rax),%xmm0
  846a04:	0f 11 46 50          	movups %xmm0,0x50(%rsi)
  846a08:	48 8d 84 24 60 02 00 	lea    0x260(%rsp),%rax
  846a0f:	00 
  846a10:	0f 10 40 40          	movups 0x40(%rax),%xmm0
  846a14:	0f 11 46 60          	movups %xmm0,0x60(%rsi)
  846a18:	0f 10 00             	movups (%rax),%xmm0
  846a1b:	0f 10 48 10          	movups 0x10(%rax),%xmm1
  846a1f:	0f 10 50 20          	movups 0x20(%rax),%xmm2
  846a23:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
  846a27:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
  846a2b:	0f 11 46 10          	movups %xmm0,0x10(%rsi)
  846a2f:	48 8d 84 24 90 02 00 	lea    0x290(%rsp),%rax
  846a36:	00 
  846a37:	0f 10 00             	movups (%rax),%xmm0
  846a3a:	0f 11 46 40          	movups %xmm0,0x40(%rsi)
  846a3e:	40 88 bc 24 80 00 00 	mov    %dil,0x80(%rsp)
  846a45:	00 
  846a46:	40 88 bc 24 48 04 00 	mov    %dil,0x448(%rsp)
  846a4d:	00 
  846a4e:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
  846a53:	48 89 8c 24 50 04 00 	mov    %rcx,0x450(%rsp)
  846a5a:	00 
  846a5b:	48 8d bc 24 50 01 00 	lea    0x150(%rsp),%rdi
  846a62:	00 
  846a63:	48 8d b4 24 48 04 00 	lea    0x448(%rsp),%rsi
  846a6a:	00 
  846a6b:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
  846a70:	44 89 f1             	mov    %r14d,%ecx
  846a73:	45 89 f8             	mov    %r15d,%r8d
  846a76:	e8 15 2c 00 00       	call   849690 <gpui_gpu::renderer::validate_draw>
  846a7b:	8b 84 24 50 01 00 00 	mov    0x150(%rsp),%eax
  846a82:	48 8b 8c 24 54 01 00 	mov    0x154(%rsp),%rcx
  846a89:	00 
  846a8a:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
  846a8f:	83 f8 ff             	cmp    $0xffffffff,%eax
  846a92:	0f 85 04 0a 00 00    	jne    84749c <<gpui_gpu::renderer::Renderer>::render+0x14dc>
  846a98:	0f b6 84 24 80 00 00 	movzbl 0x80(%rsp),%eax
  846a9f:	00 
  846aa0:	3c 02                	cmp    $0x2,%al
  846aa2:	0f 94 44 24 2f       	sete   0x2f(%rsp)
  846aa7:	48 83 7c 24 50 00    	cmpq   $0x0,0x50(%rsp)
  846aad:	0f 95 44 24 2e       	setne  0x2e(%rsp)
  846ab2:	0f 10 84 24 80 04 00 	movups 0x480(%rsp),%xmm0
  846ab9:	00 
  846aba:	0f 29 84 24 c0 02 00 	movaps %xmm0,0x2c0(%rsp)
  846ac1:	00 
  846ac2:	3c 03                	cmp    $0x3,%al
  846ac4:	0f 85 8c 00 00 00    	jne    846b56 <<gpui_gpu::renderer::Renderer>::render+0xb96>
  846aca:	f3 0f 10 84 24 4c 04 	movss  0x44c(%rsp),%xmm0
  846ad1:	00 00 
  846ad3:	0f 57 c9             	xorps  %xmm1,%xmm1
  846ad6:	0f 2e c1             	ucomiss %xmm1,%xmm0
  846ad9:	75 02                	jne    846add <<gpui_gpu::renderer::Renderer>::render+0xb1d>
  846adb:	7b 79                	jnp    846b56 <<gpui_gpu::renderer::Renderer>::render+0xb96>
  846add:	0f 28 ac 24 c0 02 00 	movaps 0x2c0(%rsp),%xmm5
  846ae4:	00 
  846ae5:	0f 28 cd             	movaps %xmm5,%xmm1
  846ae8:	66 0f 15 cd          	unpckhpd %xmm5,%xmm1
  846aec:	f3 0f 10 25 a8 a0 88 	movss  -0x775f58(%rip),%xmm4        # d0b9c <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x14>
  846af3:	ff 
  846af4:	f3 0f 59 cc          	mulss  %xmm4,%xmm1
  846af8:	0f 28 d0             	movaps %xmm0,%xmm2
  846afb:	f3 0f 5d d1          	minss  %xmm1,%xmm2
  846aff:	0f 28 ca             	movaps %xmm2,%xmm1
  846b02:	f3 0f c2 ca 03       	cmpunordss %xmm2,%xmm1
  846b07:	0f 28 d9             	movaps %xmm1,%xmm3
  846b0a:	0f 55 da             	andnps %xmm2,%xmm3
  846b0d:	0f 54 c8             	andps  %xmm0,%xmm1
  846b10:	0f 56 cb             	orps   %xmm3,%xmm1
  846b13:	0f 28 c5             	movaps %xmm5,%xmm0
  846b16:	0f c6 c5 ff          	shufps $0xff,%xmm5,%xmm0
  846b1a:	f3 0f 59 c4          	mulss  %xmm4,%xmm0
  846b1e:	0f 28 d1             	movaps %xmm1,%xmm2
  846b21:	f3 0f 5d d0          	minss  %xmm0,%xmm2
  846b25:	0f 28 c2             	movaps %xmm2,%xmm0
  846b28:	f3 0f c2 c2 03       	cmpunordss %xmm2,%xmm0
  846b2d:	0f 54 c8             	andps  %xmm0,%xmm1
  846b30:	0f 55 c2             	andnps %xmm2,%xmm0
  846b33:	0f 56 c1             	orps   %xmm1,%xmm0
  846b36:	66 0f 7e c0          	movd   %xmm0,%eax
  846b3a:	89 84 24 80 00 00 00 	mov    %eax,0x80(%rsp)
  846b41:	25 00 00 80 ff       	and    $0xff800000,%eax
  846b46:	b9 00 00 00 7f       	mov    $0x7f000000,%ecx
  846b4b:	29 c1                	sub    %eax,%ecx
  846b4d:	89 4c 24 50          	mov    %ecx,0x50(%rsp)
  846b51:	0f 57 c0             	xorps  %xmm0,%xmm0
  846b54:	eb 22                	jmp    846b78 <<gpui_gpu::renderer::Renderer>::render+0xbb8>
  846b56:	8b 84 24 e0 04 00 00 	mov    0x4e0(%rsp),%eax
  846b5d:	89 84 24 80 00 00 00 	mov    %eax,0x80(%rsp)
  846b64:	8b 84 24 e4 04 00 00 	mov    0x4e4(%rsp),%eax
  846b6b:	89 44 24 50          	mov    %eax,0x50(%rsp)
  846b6f:	f2 0f 10 84 24 e8 04 	movsd  0x4e8(%rsp),%xmm0
  846b76:	00 00 
  846b78:	0f 29 84 24 20 01 00 	movaps %xmm0,0x120(%rsp)
  846b7f:	00 
  846b80:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  846b85:	8b 48 10             	mov    0x10(%rax),%ecx
  846b88:	b8 00 00 00 80       	mov    $0x80000000,%eax
  846b8d:	09 c1                	or     %eax,%ecx
  846b8f:	89 8c 24 90 03 00 00 	mov    %ecx,0x390(%rsp)
  846b96:	0f 10 84 24 90 04 00 	movups 0x490(%rsp),%xmm0
  846b9d:	00 
  846b9e:	0f 29 84 24 d0 03 00 	movaps %xmm0,0x3d0(%rsp)
  846ba5:	00 
  846ba6:	0f 10 84 24 98 04 00 	movups 0x498(%rsp),%xmm0
  846bad:	00 
  846bae:	0f 29 84 24 b0 03 00 	movaps %xmm0,0x3b0(%rsp)
  846bb5:	00 
  846bb6:	f2 0f 10 84 24 a0 04 	movsd  0x4a0(%rsp),%xmm0
  846bbd:	00 00 
  846bbf:	0f 29 84 24 c0 03 00 	movaps %xmm0,0x3c0(%rsp)
  846bc6:	00 
  846bc7:	f2 0f 10 84 24 a8 04 	movsd  0x4a8(%rsp),%xmm0
  846bce:	00 00 
  846bd0:	0f 29 84 24 f0 04 00 	movaps %xmm0,0x4f0(%rsp)
  846bd7:	00 
  846bd8:	f2 0f 10 84 24 b0 04 	movsd  0x4b0(%rsp),%xmm0
  846bdf:	00 00 
  846be1:	f2 0f 11 84 24 f8 03 	movsd  %xmm0,0x3f8(%rsp)
  846be8:	00 00 
  846bea:	f2 0f 10 84 24 b8 04 	movsd  0x4b8(%rsp),%xmm0
  846bf1:	00 00 
  846bf3:	f2 0f 11 84 24 f0 03 	movsd  %xmm0,0x3f0(%rsp)
  846bfa:	00 00 
  846bfc:	0f 10 84 24 c0 04 00 	movups 0x4c0(%rsp),%xmm0
  846c03:	00 
  846c04:	0f 29 84 24 b0 02 00 	movaps %xmm0,0x2b0(%rsp)
  846c0b:	00 
  846c0c:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  846c11:	48 89 84 24 50 01 00 	mov    %rax,0x150(%rsp)
  846c18:	00 
  846c19:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  846c1e:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
  846c25:	00 
  846c26:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  846c2d:	00 
  846c2e:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
  846c35:	00 
  846c36:	0f 28 84 24 00 03 00 	movaps 0x300(%rsp),%xmm0
  846c3d:	00 
  846c3e:	0f 28 8c 24 10 03 00 	movaps 0x310(%rsp),%xmm1
  846c45:	00 
  846c46:	0f 28 94 24 20 03 00 	movaps 0x320(%rsp),%xmm2
  846c4d:	00 
  846c4e:	48 8d 84 24 68 01 00 	lea    0x168(%rsp),%rax
  846c55:	00 
  846c56:	0f 11 50 20          	movups %xmm2,0x20(%rax)
  846c5a:	0f 11 48 10          	movups %xmm1,0x10(%rax)
  846c5e:	0f 11 00             	movups %xmm0,(%rax)
  846c61:	0f 28 84 24 00 05 00 	movaps 0x500(%rsp),%xmm0
  846c68:	00 
  846c69:	0f 11 40 30          	movups %xmm0,0x30(%rax)
  846c6d:	0f 28 84 24 30 04 00 	movaps 0x430(%rsp),%xmm0
  846c74:	00 
  846c75:	0f 11 40 40          	movups %xmm0,0x40(%rax)
  846c79:	48 8d bc 24 50 01 00 	lea    0x150(%rsp),%rdi
  846c80:	00 
  846c81:	ff 15 f1 82 67 00    	call   *0x6782f1(%rip)        # ebef78 <_DYNAMIC+0x820>
  846c87:	8b 4c 24 7c          	mov    0x7c(%rsp),%ecx
  846c8b:	89 8c 24 f0 00 00 00 	mov    %ecx,0xf0(%rsp)
  846c92:	85 c0                	test   %eax,%eax
  846c94:	74 37                	je     846ccd <<gpui_gpu::renderer::Renderer>::render+0xd0d>
  846c96:	48 8b bc 24 e0 00 00 	mov    0xe0(%rsp),%rdi
  846c9d:	00 
  846c9e:	89 c6                	mov    %eax,%esi
  846ca0:	e8 bb 66 00 00       	call   84d360 <gpui_gpu::renderer::slots::color_word>
  846ca5:	89 84 24 80 00 00 00 	mov    %eax,0x80(%rsp)
  846cac:	0f 57 c0             	xorps  %xmm0,%xmm0
  846caf:	0f 29 84 24 20 01 00 	movaps %xmm0,0x120(%rsp)
  846cb6:	00 
  846cb7:	c7 44 24 50 00 00 00 	movl   $0x0,0x50(%rsp)
  846cbe:	00 
  846cbf:	8b 84 24 48 01 00 00 	mov    0x148(%rsp),%eax
  846cc6:	89 84 24 f0 00 00 00 	mov    %eax,0xf0(%rsp)
  846ccd:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  846cd2:	48 c1 e8 20          	shr    $0x20,%rax
  846cd6:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
  846cdd:	00 
  846cde:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  846ce3:	48 8b 08             	mov    (%rax),%rcx
  846ce6:	48 8b 70 10          	mov    0x10(%rax),%rsi
  846cea:	48 29 f1             	sub    %rsi,%rcx
  846ced:	48 83 f9 05          	cmp    $0x5,%rcx
  846cf1:	0f 86 7e 01 00 00    	jbe    846e75 <<gpui_gpu::renderer::Renderer>::render+0xeb5>
  846cf7:	f2 0f 10 84 24 f0 03 	movsd  0x3f0(%rsp),%xmm0
  846cfe:	00 00 
  846d00:	f2 0f 5a c0          	cvtsd2ss %xmm0,%xmm0
  846d04:	f2 0f 10 8c 24 f8 03 	movsd  0x3f8(%rsp),%xmm1
  846d0b:	00 00 
  846d0d:	f2 0f 5a c9          	cvtsd2ss %xmm1,%xmm1
  846d11:	66 0f 28 94 24 b0 03 	movapd 0x3b0(%rsp),%xmm2
  846d18:	00 00 
  846d1a:	66 0f 14 94 24 f0 04 	unpcklpd 0x4f0(%rsp),%xmm2
  846d21:	00 00 
  846d23:	66 0f 5a d2          	cvtpd2ps %xmm2,%xmm2
  846d27:	66 0f 28 9c 24 d0 03 	movapd 0x3d0(%rsp),%xmm3
  846d2e:	00 00 
  846d30:	66 0f 14 9c 24 c0 03 	unpcklpd 0x3c0(%rsp),%xmm3
  846d37:	00 00 
  846d39:	66 0f 5a db          	cvtpd2ps %xmm3,%xmm3
  846d3d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  846d42:	48 8b 50 08          	mov    0x8(%rax),%rdx
  846d46:	48 c1 e6 04          	shl    $0x4,%rsi
  846d4a:	0f 28 a4 24 c0 02 00 	movaps 0x2c0(%rsp),%xmm4
  846d51:	00 
  846d52:	0f 11 24 32          	movups %xmm4,(%rdx,%rsi,1)
  846d56:	66 0f 13 5c 32 10    	movlpd %xmm3,0x10(%rdx,%rsi,1)
  846d5c:	f3 0f 11 4c 32 18    	movss  %xmm1,0x18(%rdx,%rsi,1)
  846d62:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  846d67:	89 4c 32 1c          	mov    %ecx,0x1c(%rdx,%rsi,1)
  846d6b:	66 0f 13 54 32 20    	movlpd %xmm2,0x20(%rdx,%rsi,1)
  846d71:	f3 0f 11 44 32 28    	movss  %xmm0,0x28(%rdx,%rsi,1)
  846d77:	48 8b bc 24 e8 03 00 	mov    0x3e8(%rsp),%rdi
  846d7e:	00 
  846d7f:	89 7c 32 2c          	mov    %edi,0x2c(%rdx,%rsi,1)
  846d83:	0f 28 84 24 b0 02 00 	movaps 0x2b0(%rsp),%xmm0
  846d8a:	00 
  846d8b:	0f 11 44 32 30       	movups %xmm0,0x30(%rdx,%rsi,1)
  846d90:	8b bc 24 80 00 00 00 	mov    0x80(%rsp),%edi
  846d97:	89 7c 32 40          	mov    %edi,0x40(%rdx,%rsi,1)
  846d9b:	8b 7c 24 50          	mov    0x50(%rsp),%edi
  846d9f:	89 7c 32 44          	mov    %edi,0x44(%rdx,%rsi,1)
  846da3:	0f 28 84 24 20 01 00 	movaps 0x120(%rsp),%xmm0
  846daa:	00 
  846dab:	0f 13 44 32 48       	movlps %xmm0,0x48(%rdx,%rsi,1)
  846db0:	48 c7 44 32 50 00 00 	movq   $0x0,0x50(%rdx,%rsi,1)
  846db7:	00 00 
  846db9:	c7 44 32 58 00 00 00 	movl   $0x0,0x58(%rdx,%rsi,1)
  846dc0:	00 
  846dc1:	8b bc 24 f0 00 00 00 	mov    0xf0(%rsp),%edi
  846dc8:	89 7c 32 5c          	mov    %edi,0x5c(%rdx,%rsi,1)
  846dcc:	48 83 40 10 06       	addq   $0x6,0x10(%rax)
  846dd1:	48 8d bc 24 50 01 00 	lea    0x150(%rsp),%rdi
  846dd8:	00 
  846dd9:	48 89 c6             	mov    %rax,%rsi
  846ddc:	48 8d 94 24 48 04 00 	lea    0x448(%rsp),%rdx
  846de3:	00 
  846de4:	44 8b 84 24 90 03 00 	mov    0x390(%rsp),%r8d
  846deb:	00 
  846dec:	4c 8b 4c 24 70       	mov    0x70(%rsp),%r9
  846df1:	ff b4 24 b8 00 00 00 	push   0xb8(%rsp)
  846df8:	41 57                	push   %r15
  846dfa:	41 56                	push   %r14
  846dfc:	ff 74 24 78          	push   0x78(%rsp)
  846e00:	e8 db 17 00 00       	call   8485e0 <<gpui_gpu::renderer::Renderer>::bin_draw>
  846e05:	48 83 c4 20          	add    $0x20,%rsp
  846e09:	8b 84 24 50 01 00 00 	mov    0x150(%rsp),%eax
  846e10:	83 f8 ff             	cmp    $0xffffffff,%eax
  846e13:	0f 85 4b 06 00 00    	jne    847464 <<gpui_gpu::renderer::Renderer>::render+0x14a4>
  846e19:	0f b6 4c 24 2f       	movzbl 0x2f(%rsp),%ecx
  846e1e:	22 4c 24 2e          	and    0x2e(%rsp),%cl
  846e22:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  846e27:	08 c8                	or     %cl,%al
  846e29:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  846e2e:	48 8b 84 24 58 01 00 	mov    0x158(%rsp),%rax
  846e35:	00 
  846e36:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
  846e3d:	00 
  846e3e:	48 ff 44 24 70       	incq   0x70(%rsp)
  846e43:	48 8b 94 24 90 00 00 	mov    0x90(%rsp),%rdx
  846e4a:	00 
  846e4b:	48 83 c2 04          	add    $0x4,%rdx
  846e4f:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  846e56:	00 
  846e57:	48 8d 04 85 00 00 00 	lea    0x0(,%rax,4),%rax
  846e5e:	00 
  846e5f:	48 89 94 24 90 00 00 	mov    %rdx,0x90(%rsp)
  846e66:	00 
  846e67:	48 39 d0             	cmp    %rdx,%rax
  846e6a:	0f 85 1c fb ff ff    	jne    84698c <<gpui_gpu::renderer::Renderer>::render+0x9cc>
  846e70:	e9 7a 04 00 00       	jmp    8472ef <<gpui_gpu::renderer::Renderer>::render+0x132f>
  846e75:	ba 06 00 00 00       	mov    $0x6,%edx
  846e7a:	b9 04 00 00 00       	mov    $0x4,%ecx
  846e7f:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  846e85:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  846e8a:	e8 b1 61 00 00       	call   84d040 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  846e8f:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  846e94:	48 8b 70 10          	mov    0x10(%rax),%rsi
  846e98:	e9 5a fe ff ff       	jmp    846cf7 <<gpui_gpu::renderer::Renderer>::render+0xd37>
  846e9d:	0f 57 c0             	xorps  %xmm0,%xmm0
  846ea0:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
  846ea7:	00 
  846ea8:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
  846ead:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  846eb2:	8b 40 10             	mov    0x10(%rax),%eax
  846eb5:	89 84 24 20 01 00 00 	mov    %eax,0x120(%rsp)
  846ebc:	0f 10 8c 24 60 02 00 	movups 0x260(%rsp),%xmm1
  846ec3:	00 
  846ec4:	0f 10 94 24 68 02 00 	movups 0x268(%rsp),%xmm2
  846ecb:	00 
  846ecc:	f2 0f 10 84 24 80 02 	movsd  0x280(%rsp),%xmm0
  846ed3:	00 00 
  846ed5:	f2 0f 11 84 24 f0 00 	movsd  %xmm0,0xf0(%rsp)
  846edc:	00 00 
  846ede:	f2 0f 10 84 24 88 02 	movsd  0x288(%rsp),%xmm0
  846ee5:	00 00 
  846ee7:	f2 0f 11 84 24 c0 02 	movsd  %xmm0,0x2c0(%rsp)
  846eee:	00 00 
  846ef0:	0f 10 84 24 90 02 00 	movups 0x290(%rsp),%xmm0
  846ef7:	00 
  846ef8:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
  846efd:	0f 16 8c 24 70 02 00 	movhps 0x270(%rsp),%xmm1
  846f04:	00 
  846f05:	0f 29 8c 24 90 03 00 	movaps %xmm1,0x390(%rsp)
  846f0c:	00 
  846f0d:	0f 10 84 24 a0 02 00 	movups 0x2a0(%rsp),%xmm0
  846f14:	00 
  846f15:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
  846f1c:	00 
  846f1d:	0f 16 94 24 78 02 00 	movhps 0x278(%rsp),%xmm2
  846f24:	00 
  846f25:	0f 29 94 24 b0 02 00 	movaps %xmm2,0x2b0(%rsp)
  846f2c:	00 
  846f2d:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  846f32:	48 89 84 24 50 01 00 	mov    %rax,0x150(%rsp)
  846f39:	00 
  846f3a:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  846f3f:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
  846f46:	00 
  846f47:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  846f4e:	00 
  846f4f:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
  846f56:	00 
  846f57:	48 8d 84 24 60 02 00 	lea    0x260(%rsp),%rax
  846f5e:	00 
  846f5f:	0f 10 00             	movups (%rax),%xmm0
  846f62:	0f 10 48 10          	movups 0x10(%rax),%xmm1
  846f66:	0f 10 50 20          	movups 0x20(%rax),%xmm2
  846f6a:	48 8d 94 24 68 01 00 	lea    0x168(%rsp),%rdx
  846f71:	00 
  846f72:	0f 11 52 20          	movups %xmm2,0x20(%rdx)
  846f76:	0f 11 4a 10          	movups %xmm1,0x10(%rdx)
  846f7a:	0f 11 02             	movups %xmm0,(%rdx)
  846f7d:	48 8d 8c 24 90 02 00 	lea    0x290(%rsp),%rcx
  846f84:	00 
  846f85:	0f 10 01             	movups (%rcx),%xmm0
  846f88:	0f 11 42 30          	movups %xmm0,0x30(%rdx)
  846f8c:	f3 0f 6f 40 40       	movdqu 0x40(%rax),%xmm0
  846f91:	f3 0f 7f 42 40       	movdqu %xmm0,0x40(%rdx)
  846f96:	48 8d bc 24 50 01 00 	lea    0x150(%rsp),%rdi
  846f9d:	00 
  846f9e:	ff 15 d4 7f 67 00    	call   *0x677fd4(%rip)        # ebef78 <_DYNAMIC+0x820>
  846fa4:	85 c0                	test   %eax,%eax
  846fa6:	74 24                	je     846fcc <<gpui_gpu::renderer::Renderer>::render+0x100c>
  846fa8:	48 8b bc 24 e0 00 00 	mov    0xe0(%rsp),%rdi
  846faf:	00 
  846fb0:	89 c6                	mov    %eax,%esi
  846fb2:	e8 a9 63 00 00       	call   84d360 <gpui_gpu::renderer::slots::color_word>
  846fb7:	81 4c 24 7c 00 00 00 	orl    $0x80000000,0x7c(%rsp)
  846fbe:	80 
  846fbf:	66 0f 6e c0          	movd   %eax,%xmm0
  846fc3:	66 0f 7f 84 24 80 00 	movdqa %xmm0,0x80(%rsp)
  846fca:	00 00 
  846fcc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  846fd1:	48 8b 08             	mov    (%rax),%rcx
  846fd4:	48 8b 70 10          	mov    0x10(%rax),%rsi
  846fd8:	48 29 f1             	sub    %rsi,%rcx
  846fdb:	48 83 f9 04          	cmp    $0x4,%rcx
  846fdf:	0f 86 44 03 00 00    	jbe    847329 <<gpui_gpu::renderer::Renderer>::render+0x1369>
  846fe5:	66 0f 5a 84 24 90 03 	cvtpd2ps 0x390(%rsp),%xmm0
  846fec:	00 00 
  846fee:	66 0f 5a 8c 24 b0 02 	cvtpd2ps 0x2b0(%rsp),%xmm1
  846ff5:	00 00 
  846ff7:	f2 0f 10 94 24 f0 00 	movsd  0xf0(%rsp),%xmm2
  846ffe:	00 00 
  847000:	f2 0f 5a d2          	cvtsd2ss %xmm2,%xmm2
  847004:	f2 0f 10 9c 24 c0 02 	movsd  0x2c0(%rsp),%xmm3
  84700b:	00 00 
  84700d:	f2 0f 5a db          	cvtsd2ss %xmm3,%xmm3
  847011:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  847016:	48 8b 48 08          	mov    0x8(%rax),%rcx
  84701a:	48 c1 e6 04          	shl    $0x4,%rsi
  84701e:	66 0f 13 04 31       	movlpd %xmm0,(%rcx,%rsi,1)
  847023:	f3 0f 11 54 31 08    	movss  %xmm2,0x8(%rcx,%rsi,1)
  847029:	0f 28 44 24 30       	movaps 0x30(%rsp),%xmm0
  84702e:	f3 0f 11 44 31 0c    	movss  %xmm0,0xc(%rcx,%rsi,1)
  847034:	66 0f 13 4c 31 10    	movlpd %xmm1,0x10(%rcx,%rsi,1)
  84703a:	f3 0f 11 5c 31 18    	movss  %xmm3,0x18(%rcx,%rsi,1)
  847040:	0f 28 84 24 90 00 00 	movaps 0x90(%rsp),%xmm0
  847047:	00 
  847048:	f3 0f 11 44 31 1c    	movss  %xmm0,0x1c(%rcx,%rsi,1)
  84704e:	0f 28 44 24 50       	movaps 0x50(%rsp),%xmm0
  847053:	0f 11 44 31 20       	movups %xmm0,0x20(%rcx,%rsi,1)
  847058:	0f 28 84 24 80 00 00 	movaps 0x80(%rsp),%xmm0
  84705f:	00 
  847060:	0f 11 44 31 30       	movups %xmm0,0x30(%rcx,%rsi,1)
  847065:	8b 54 24 7c          	mov    0x7c(%rsp),%edx
  847069:	89 54 31 40          	mov    %edx,0x40(%rcx,%rsi,1)
  84706d:	48 c7 44 31 44 00 00 	movq   $0x0,0x44(%rcx,%rsi,1)
  847074:	00 00 
  847076:	c7 44 31 4c 00 00 00 	movl   $0x0,0x4c(%rcx,%rsi,1)
  84707d:	00 
  84707e:	48 83 40 10 05       	addq   $0x5,0x10(%rax)
  847083:	48 ff 84 24 30 01 00 	incq   0x130(%rsp)
  84708a:	00 
  84708b:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  847092:	00 
  847093:	48 01 84 24 38 01 00 	add    %rax,0x138(%rsp)
  84709a:	00 
  84709b:	48 85 c0             	test   %rax,%rax
  84709e:	0f 84 57 02 00 00    	je     8472fb <<gpui_gpu::renderer::Renderer>::render+0x133b>
  8470a4:	66 0f 6f 44 24 30    	movdqa 0x30(%rsp),%xmm0
  8470aa:	66 0f 7e c1          	movd   %xmm0,%ecx
  8470ae:	66 0f 6f 84 24 90 00 	movdqa 0x90(%rsp),%xmm0
  8470b5:	00 00 
  8470b7:	66 0f 7e c0          	movd   %xmm0,%eax
  8470bb:	48 c1 e0 20          	shl    $0x20,%rax
  8470bf:	48 09 c1             	or     %rax,%rcx
  8470c2:	48 89 8c 24 f0 00 00 	mov    %rcx,0xf0(%rsp)
  8470c9:	00 
  8470ca:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
  8470d1:	00 00 
  8470d3:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  8470d8:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  8470dd:	8b 14 08             	mov    (%rax,%rcx,1),%edx
  8470e0:	48 8d bc 24 30 03 00 	lea    0x330(%rsp),%rdi
  8470e7:	00 
  8470e8:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  8470ed:	e8 0e de ff ff       	call   844f00 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  8470f2:	0f b6 bc 24 30 03 00 	movzbl 0x330(%rsp),%edi
  8470f9:	00 
  8470fa:	48 8d b4 24 38 03 00 	lea    0x338(%rsp),%rsi
  847101:	00 
  847102:	8b 46 f9             	mov    -0x7(%rsi),%eax
  847105:	8b 4e fc             	mov    -0x4(%rsi),%ecx
  847108:	48 8d 94 24 51 01 00 	lea    0x151(%rsp),%rdx
  84710f:	00 
  847110:	89 4a 03             	mov    %ecx,0x3(%rdx)
  847113:	89 02                	mov    %eax,(%rdx)
  847115:	48 8b 8c 24 38 03 00 	mov    0x338(%rsp),%rcx
  84711c:	00 
  84711d:	48 8b 46 28          	mov    0x28(%rsi),%rax
  847121:	48 89 42 2f          	mov    %rax,0x2f(%rdx)
  847125:	0f 10 46 08          	movups 0x8(%rsi),%xmm0
  847129:	0f 10 4e 18          	movups 0x18(%rsi),%xmm1
  84712d:	0f 11 4a 1f          	movups %xmm1,0x1f(%rdx)
  847131:	0f 11 42 0f          	movups %xmm0,0xf(%rdx)
  847135:	0f 10 8c 24 68 03 00 	movups 0x368(%rsp),%xmm1
  84713c:	00 
  84713d:	48 8d 84 24 78 03 00 	lea    0x378(%rsp),%rax
  847144:	00 
  847145:	0f 10 00             	movups (%rax),%xmm0
  847148:	48 8d 84 24 68 01 00 	lea    0x168(%rsp),%rax
  84714f:	00 
  847150:	0f 11 40 70          	movups %xmm0,0x70(%rax)
  847154:	0f 28 84 24 30 04 00 	movaps 0x430(%rsp),%xmm0
  84715b:	00 
  84715c:	0f 11 80 80 00 00 00 	movups %xmm0,0x80(%rax)
  847163:	0f 29 8c 24 a0 00 00 	movaps %xmm1,0xa0(%rsp)
  84716a:	00 
  84716b:	0f 11 8c 24 88 01 00 	movups %xmm1,0x188(%rsp)
  847172:	00 
  847173:	0f 28 84 24 10 05 00 	movaps 0x510(%rsp),%xmm0
  84717a:	00 
  84717b:	0f 28 8c 24 20 05 00 	movaps 0x520(%rsp),%xmm1
  847182:	00 
  847183:	66 0f 28 94 24 30 05 	movapd 0x530(%rsp),%xmm2
  84718a:	00 00 
  84718c:	66 0f 11 50 50       	movupd %xmm2,0x50(%rax)
  847191:	0f 11 48 40          	movups %xmm1,0x40(%rax)
  847195:	0f 11 40 30          	movups %xmm0,0x30(%rax)
  847199:	0f 28 84 24 40 05 00 	movaps 0x540(%rsp),%xmm0
  8471a0:	00 
  8471a1:	0f 11 40 60          	movups %xmm0,0x60(%rax)
  8471a5:	40 88 bc 24 80 00 00 	mov    %dil,0x80(%rsp)
  8471ac:	00 
  8471ad:	40 88 bc 24 50 01 00 	mov    %dil,0x150(%rsp)
  8471b4:	00 
  8471b5:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
  8471ba:	48 89 8c 24 58 01 00 	mov    %rcx,0x158(%rsp)
  8471c1:	00 
  8471c2:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  8471c7:	48 8b 08             	mov    (%rax),%rcx
  8471ca:	48 8b 40 10          	mov    0x10(%rax),%rax
  8471ce:	48 29 c1             	sub    %rax,%rcx
  8471d1:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
  8471d8:	00 
  8471d9:	48 83 f9 01          	cmp    $0x1,%rcx
  8471dd:	0f 86 dc 00 00 00    	jbe    8472bf <<gpui_gpu::renderer::Renderer>::render+0x12ff>
  8471e3:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  8471e8:	48 8b 4e 08          	mov    0x8(%rsi),%rcx
  8471ec:	48 c1 e0 04          	shl    $0x4,%rax
  8471f0:	0f 28 84 24 a0 00 00 	movaps 0xa0(%rsp),%xmm0
  8471f7:	00 
  8471f8:	0f 11 04 01          	movups %xmm0,(%rcx,%rax,1)
  8471fc:	48 c7 44 01 10 00 00 	movq   $0x0,0x10(%rcx,%rax,1)
  847203:	00 00 
  847205:	c7 44 01 18 00 00 00 	movl   $0x0,0x18(%rcx,%rax,1)
  84720c:	00 
  84720d:	8b 94 24 20 01 00 00 	mov    0x120(%rsp),%edx
  847214:	89 54 01 1c          	mov    %edx,0x1c(%rcx,%rax,1)
  847218:	48 83 46 10 02       	addq   $0x2,0x10(%rsi)
  84721d:	48 8d bc 24 30 03 00 	lea    0x330(%rsp),%rdi
  847224:	00 
  847225:	48 8d 94 24 50 01 00 	lea    0x150(%rsp),%rdx
  84722c:	00 
  84722d:	48 8b 8c 24 f0 00 00 	mov    0xf0(%rsp),%rcx
  847234:	00 
  847235:	4c 8b 84 24 90 00 00 	mov    0x90(%rsp),%r8
  84723c:	00 
  84723d:	4c 8b 4c 24 70       	mov    0x70(%rsp),%r9
  847242:	ff b4 24 b8 00 00 00 	push   0xb8(%rsp)
  847249:	41 57                	push   %r15
  84724b:	41 56                	push   %r14
  84724d:	ff 74 24 78          	push   0x78(%rsp)
  847251:	e8 8a 13 00 00       	call   8485e0 <<gpui_gpu::renderer::Renderer>::bin_draw>
  847256:	48 83 c4 20          	add    $0x20,%rsp
  84725a:	8b 84 24 30 03 00 00 	mov    0x330(%rsp),%eax
  847261:	83 f8 ff             	cmp    $0xffffffff,%eax
  847264:	0f 85 16 02 00 00    	jne    847480 <<gpui_gpu::renderer::Renderer>::render+0x14c0>
  84726a:	80 bc 24 80 00 00 00 	cmpb   $0x2,0x80(%rsp)
  847271:	02 
  847272:	0f 94 c0             	sete   %al
  847275:	48 83 7c 24 50 00    	cmpq   $0x0,0x50(%rsp)
  84727b:	0f 95 c1             	setne  %cl
  84727e:	20 c1                	and    %al,%cl
  847280:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  847285:	08 c8                	or     %cl,%al
  847287:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  84728c:	48 8b 84 24 38 03 00 	mov    0x338(%rsp),%rax
  847293:	00 
  847294:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
  84729b:	00 
  84729c:	48 ff 44 24 70       	incq   0x70(%rsp)
  8472a1:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  8472a6:	48 83 c1 04          	add    $0x4,%rcx
  8472aa:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
  8472af:	48 39 8c 24 e0 03 00 	cmp    %rcx,0x3e0(%rsp)
  8472b6:	00 
  8472b7:	0f 85 16 fe ff ff    	jne    8470d3 <<gpui_gpu::renderer::Renderer>::render+0x1113>
  8472bd:	eb 30                	jmp    8472ef <<gpui_gpu::renderer::Renderer>::render+0x132f>
  8472bf:	ba 02 00 00 00       	mov    $0x2,%edx
  8472c4:	b9 04 00 00 00       	mov    $0x4,%ecx
  8472c9:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  8472cf:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  8472d4:	48 8b b4 24 90 00 00 	mov    0x90(%rsp),%rsi
  8472db:	00 
  8472dc:	e8 5f 5d 00 00       	call   84d040 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  8472e1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  8472e6:	48 8b 40 10          	mov    0x10(%rax),%rax
  8472ea:	e9 f4 fe ff ff       	jmp    8471e3 <<gpui_gpu::renderer::Renderer>::render+0x1223>
  8472ef:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  8472f4:	24 01                	and    $0x1,%al
  8472f6:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  8472fb:	48 8d bc 24 48 02 00 	lea    0x248(%rsp),%rdi
  847302:	00 
  847303:	48 8d b4 24 d8 02 00 	lea    0x2d8(%rsp),%rsi
  84730a:	00 
  84730b:	ff 15 5f 7c 67 00    	call   *0x677c5f(%rip)        # ebef70 <_DYNAMIC+0x818>
  847311:	48 8b 84 24 48 02 00 	mov    0x248(%rsp),%rax
  847318:	00 
  847319:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  84731e:	48 85 c0             	test   %rax,%rax
  847321:	0f 85 26 f3 ff ff    	jne    84664d <<gpui_gpu::renderer::Renderer>::render+0x68d>
  847327:	eb 5e                	jmp    847387 <<gpui_gpu::renderer::Renderer>::render+0x13c7>
  847329:	ba 05 00 00 00       	mov    $0x5,%edx
  84732e:	b9 04 00 00 00       	mov    $0x4,%ecx
  847333:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  847339:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  84733e:	e8 fd 5c 00 00       	call   84d040 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  847343:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  847348:	48 8b 70 10          	mov    0x10(%rax),%rsi
  84734c:	e9 94 fc ff ff       	jmp    846fe5 <<gpui_gpu::renderer::Renderer>::render+0x1025>
  847351:	48 c7 84 24 38 01 00 	movq   $0x0,0x138(%rsp)
  847358:	00 00 00 00 00 
  84735d:	48 c7 84 24 30 01 00 	movq   $0x0,0x130(%rsp)
  847364:	00 00 00 00 00 
  847369:	48 c7 44 24 70 00 00 	movq   $0x0,0x70(%rsp)
  847370:	00 00 
  847372:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  847379:	00 00 
  84737b:	48 c7 84 24 b8 00 00 	movq   $0x0,0xb8(%rsp)
  847382:	00 00 00 00 00 
  847387:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  84738c:	48 8d b0 28 02 00 00 	lea    0x228(%rax),%rsi
  847393:	48 8d 90 30 02 00 00 	lea    0x230(%rax),%rdx
  84739a:	48 8d 88 70 02 00 00 	lea    0x270(%rax),%rcx
  8473a1:	4c 8d 80 40 03 00 00 	lea    0x340(%rax),%r8
  8473a8:	4c 8b 48 10          	mov    0x10(%rax),%r9
  8473ac:	48 83 ec 08          	sub    $0x8,%rsp
  8473b0:	48 8d bc 24 58 01 00 	lea    0x158(%rsp),%rdi
  8473b7:	00 
  8473b8:	48 89 b4 24 d8 03 00 	mov    %rsi,0x3d8(%rsp)
  8473bf:	00 
  8473c0:	48 89 94 24 c8 03 00 	mov    %rdx,0x3c8(%rsp)
  8473c7:	00 
  8473c8:	48 89 8c 24 b8 02 00 	mov    %rcx,0x2b8(%rsp)
  8473cf:	00 
  8473d0:	4c 89 84 24 c8 02 00 	mov    %r8,0x2c8(%rsp)
  8473d7:	00 
  8473d8:	ff b4 24 d8 00 00 00 	push   0xd8(%rsp)
  8473df:	e8 5c 45 00 00       	call   84b940 <gpui_gpu::renderer::images::prepare>
  8473e4:	48 83 c4 10          	add    $0x10,%rsp
  8473e8:	83 bc 24 50 01 00 00 	cmpl   $0xffffffff,0x150(%rsp)
  8473ef:	ff 
  8473f0:	74 47                	je     847439 <<gpui_gpu::renderer::Renderer>::render+0x1479>
  8473f2:	0f 10 84 24 50 01 00 	movups 0x150(%rsp),%xmm0
  8473f9:	00 
  8473fa:	0f 10 8c 24 60 01 00 	movups 0x160(%rsp),%xmm1
  847401:	00 
  847402:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
  847407:	0f 11 4f 10          	movups %xmm1,0x10(%rdi)
  84740b:	0f 11 07             	movups %xmm0,(%rdi)
  84740e:	e9 85 ec ff ff       	jmp    846098 <<gpui_gpu::renderer::Renderer>::render+0xd8>
  847413:	8b 94 24 1c 01 00 00 	mov    0x11c(%rsp),%edx
  84741a:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
  84741f:	89 57 1c             	mov    %edx,0x1c(%rdi)
  847422:	0f 10 84 24 0c 01 00 	movups 0x10c(%rsp),%xmm0
  847429:	00 
  84742a:	0f 11 47 0c          	movups %xmm0,0xc(%rdi)
  84742e:	89 0f                	mov    %ecx,(%rdi)
  847430:	48 89 47 04          	mov    %rax,0x4(%rdi)
  847434:	e9 5f ec ff ff       	jmp    846098 <<gpui_gpu::renderer::Renderer>::render+0xd8>
  847439:	0f b6 4c 24 10       	movzbl 0x10(%rsp),%ecx
  84743e:	83 e1 01             	and    $0x1,%ecx
  847441:	48 8d bc 24 50 01 00 	lea    0x150(%rsp),%rdi
  847448:	00 
  847449:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  84744e:	48 8b 54 24 68       	mov    0x68(%rsp),%rdx
  847453:	e8 78 e7 ff ff       	call   845bd0 <<gpui_gpu::renderer::Renderer>::prepare_atlas>
  847458:	8b 84 24 50 01 00 00 	mov    0x150(%rsp),%eax
  84745f:	83 f8 ff             	cmp    $0xffffffff,%eax
  847462:	74 63                	je     8474c7 <<gpui_gpu::renderer::Renderer>::render+0x1507>
  847464:	8b 8c 24 54 01 00 00 	mov    0x154(%rsp),%ecx
  84746b:	48 8b 94 24 58 01 00 	mov    0x158(%rsp),%rdx
  847472:	00 
  847473:	0f 10 84 24 60 01 00 	movups 0x160(%rsp),%xmm0
  84747a:	00 
  84747b:	e9 37 f0 ff ff       	jmp    8464b7 <<gpui_gpu::renderer::Renderer>::render+0x4f7>
  847480:	8b 8c 24 34 03 00 00 	mov    0x334(%rsp),%ecx
  847487:	48 8b 94 24 38 03 00 	mov    0x338(%rsp),%rdx
  84748e:	00 
  84748f:	0f 10 84 24 40 03 00 	movups 0x340(%rsp),%xmm0
  847496:	00 
  847497:	e9 1b f0 ff ff       	jmp    8464b7 <<gpui_gpu::renderer::Renderer>::render+0x4f7>
  84749c:	8b 8c 24 6c 01 00 00 	mov    0x16c(%rsp),%ecx
  8474a3:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
  8474a8:	89 4f 1c             	mov    %ecx,0x1c(%rdi)
  8474ab:	0f 10 84 24 5c 01 00 	movups 0x15c(%rsp),%xmm0
  8474b2:	00 
  8474b3:	0f 11 47 0c          	movups %xmm0,0xc(%rdi)
  8474b7:	89 07                	mov    %eax,(%rdi)
  8474b9:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  8474be:	48 89 47 04          	mov    %rax,0x4(%rdi)
  8474c2:	e9 d1 eb ff ff       	jmp    846098 <<gpui_gpu::renderer::Renderer>::render+0xd8>
  8474c7:	48 8b 84 24 58 01 00 	mov    0x158(%rsp),%rax
  8474ce:	00 
  8474cf:	48 89 84 24 b0 03 00 	mov    %rax,0x3b0(%rsp)
  8474d6:	00 
  8474d7:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  8474dc:	48 89 84 24 30 03 00 	mov    %rax,0x330(%rsp)
  8474e3:	00 
  8474e4:	48 c7 84 24 38 03 00 	movq   $0x0,0x338(%rsp)
  8474eb:	00 00 00 00 00 
  8474f0:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  8474f7:	00 
  8474f8:	48 89 84 24 40 03 00 	mov    %rax,0x340(%rsp)
  8474ff:	00 
  847500:	48 8b 84 24 40 01 00 	mov    0x140(%rsp),%rax
  847507:	00 
  847508:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
  84750f:	00 
  847510:	8b 44 24 78          	mov    0x78(%rsp),%eax
  847514:	89 84 24 50 03 00 00 	mov    %eax,0x350(%rsp)
  84751b:	48 8d bc 24 48 02 00 	lea    0x248(%rsp),%rdi
  847522:	00 
  847523:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
  84752a:	00 
  84752b:	ff 15 3f 7a 67 00    	call   *0x677a3f(%rip)        # ebef70 <_DYNAMIC+0x818>
  847531:	48 8b 84 24 48 02 00 	mov    0x248(%rsp),%rax
  847538:	00 
  847539:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
  847540:	00 
  847541:	48 85 c0             	test   %rax,%rax
  847544:	0f 84 cf 03 00 00    	je     847919 <<gpui_gpu::renderer::Renderer>::render+0x1959>
  84754a:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  84754f:	48 05 20 01 00 00    	add    $0x120,%rax
  847555:	48 89 84 24 90 03 00 	mov    %rax,0x390(%rsp)
  84755c:	00 
  84755d:	eb 3c                	jmp    84759b <<gpui_gpu::renderer::Renderer>::render+0x15db>
  84755f:	48 8d bc 24 48 02 00 	lea    0x248(%rsp),%rdi
  847566:	00 
  847567:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
  84756e:	00 
  84756f:	ff 15 fb 79 67 00    	call   *0x6779fb(%rip)        # ebef70 <_DYNAMIC+0x818>
  847575:	48 8b 84 24 48 02 00 	mov    0x248(%rsp),%rax
  84757c:	00 
  84757d:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  847582:	48 89 8c 24 c0 00 00 	mov    %rcx,0xc0(%rsp)
  847589:	00 
  84758a:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
  847591:	00 
  847592:	48 85 c0             	test   %rax,%rax
  847595:	0f 84 7e 03 00 00    	je     847919 <<gpui_gpu::renderer::Renderer>::render+0x1959>
  84759b:	48 8b 94 24 50 02 00 	mov    0x250(%rsp),%rdx
  8475a2:	00 
  8475a3:	48 8b bc 24 58 02 00 	mov    0x258(%rsp),%rdi
  8475aa:	00 
  8475ab:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
  8475b0:	48 8d 84 24 60 02 00 	lea    0x260(%rsp),%rax
  8475b7:	00 
  8475b8:	0f 10 40 40          	movups 0x40(%rax),%xmm0
  8475bc:	48 8d 8c 24 68 01 00 	lea    0x168(%rsp),%rcx
  8475c3:	00 
  8475c4:	0f 11 41 40          	movups %xmm0,0x40(%rcx)
  8475c8:	0f 10 00             	movups (%rax),%xmm0
  8475cb:	0f 10 48 10          	movups 0x10(%rax),%xmm1
  8475cf:	0f 10 50 20          	movups 0x20(%rax),%xmm2
  8475d3:	0f 10 58 30          	movups 0x30(%rax),%xmm3
  8475d7:	0f 11 59 30          	movups %xmm3,0x30(%rcx)
  8475db:	0f 11 51 20          	movups %xmm2,0x20(%rcx)
  8475df:	0f 11 49 10          	movups %xmm1,0x10(%rcx)
  8475e3:	0f 11 01             	movups %xmm0,(%rcx)
  8475e6:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  8475eb:	0f b6 b0 65 03 00 00 	movzbl 0x365(%rax),%esi
  8475f2:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  8475f9:	00 
  8475fa:	48 89 84 24 50 01 00 	mov    %rax,0x150(%rsp)
  847601:	00 
  847602:	48 89 94 24 a0 00 00 	mov    %rdx,0xa0(%rsp)
  847609:	00 
  84760a:	48 89 94 24 58 01 00 	mov    %rdx,0x158(%rsp)
  847611:	00 
  847612:	48 89 bc 24 60 01 00 	mov    %rdi,0x160(%rsp)
  847619:	00 
  84761a:	48 8d bc 24 50 01 00 	lea    0x150(%rsp),%rdi
  847621:	00 
  847622:	e8 19 20 00 00       	call   849640 <gpui_gpu::renderer::compact_group>
  847627:	48 8b 8c 24 c0 00 00 	mov    0xc0(%rsp),%rcx
  84762e:	00 
  84762f:	48 8d 51 05          	lea    0x5(%rcx),%rdx
  847633:	84 c0                	test   %al,%al
  847635:	48 0f 44 d1          	cmove  %rcx,%rdx
  847639:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
  84763e:	48 83 7c 24 30 00    	cmpq   $0x0,0x30(%rsp)
  847644:	0f 84 15 ff ff ff    	je     84755f <<gpui_gpu::renderer::Renderer>::render+0x159f>
  84764a:	48 c1 64 24 30 02    	shlq   $0x2,0x30(%rsp)
  847650:	34 01                	xor    $0x1,%al
  847652:	0f b6 c8             	movzbl %al,%ecx
  847655:	c1 e1 02             	shl    $0x2,%ecx
  847658:	48 8d 41 01          	lea    0x1(%rcx),%rax
  84765c:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  847663:	00 
  847664:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  847669:	4c 8d 04 08          	lea    (%rax,%rcx,1),%r8
  84766d:	49 ff c0             	inc    %r8
  847670:	48 83 c9 02          	or     $0x2,%rcx
  847674:	49 c1 e0 04          	shl    $0x4,%r8
  847678:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
  84767d:	c1 e1 04             	shl    $0x4,%ecx
  847680:	48 89 8c 24 c0 00 00 	mov    %rcx,0xc0(%rsp)
  847687:	00 
  847688:	31 c9                	xor    %ecx,%ecx
  84768a:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
  84768f:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  847696:	00 
  847697:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  84769c:	8b 14 08             	mov    (%rax,%rcx,1),%edx
  84769f:	48 8d bc 24 50 01 00 	lea    0x150(%rsp),%rdi
  8476a6:	00 
  8476a7:	48 8b b4 24 90 00 00 	mov    0x90(%rsp),%rsi
  8476ae:	00 
  8476af:	e8 4c d8 ff ff       	call   844f00 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  8476b4:	0f b6 8c 24 50 01 00 	movzbl 0x150(%rsp),%ecx
  8476bb:	00 
  8476bc:	0f b6 84 24 51 01 00 	movzbl 0x151(%rsp),%eax
  8476c3:	00 
  8476c4:	f3 0f 10 a4 24 54 01 	movss  0x154(%rsp),%xmm4
  8476cb:	00 00 
  8476cd:	48 8d b4 24 58 01 00 	lea    0x158(%rsp),%rsi
  8476d4:	00 
  8476d5:	48 8b 56 10          	mov    0x10(%rsi),%rdx
  8476d9:	48 89 94 24 10 03 00 	mov    %rdx,0x310(%rsp)
  8476e0:	00 
  8476e1:	0f 10 06             	movups (%rsi),%xmm0
  8476e4:	0f 29 84 24 00 03 00 	movaps %xmm0,0x300(%rsp)
  8476eb:	00 
  8476ec:	83 f9 01             	cmp    $0x1,%ecx
  8476ef:	0f 84 9b 00 00 00    	je     847790 <<gpui_gpu::renderer::Renderer>::render+0x17d0>
  8476f5:	48 8b b4 24 70 01 00 	mov    0x170(%rsp),%rsi
  8476fc:	00 
  8476fd:	8b bc 24 78 01 00 00 	mov    0x178(%rsp),%edi
  847704:	8b 94 24 7c 01 00 00 	mov    0x17c(%rsp),%edx
  84770b:	83 f9 03             	cmp    $0x3,%ecx
  84770e:	0f 85 01 01 00 00    	jne    847815 <<gpui_gpu::renderer::Renderer>::render+0x1855>
  847714:	89 bc 24 e0 00 00 00 	mov    %edi,0xe0(%rsp)
  84771b:	0f 29 a4 24 f0 00 00 	movaps %xmm4,0xf0(%rsp)
  847722:	00 
  847723:	89 94 24 20 01 00 00 	mov    %edx,0x120(%rsp)
  84772a:	48 8b 8c 24 c0 02 00 	mov    0x2c0(%rsp),%rcx
  847731:	00 
  847732:	48 8b 39             	mov    (%rcx),%rdi
  847735:	48 85 ff             	test   %rdi,%rdi
  847738:	0f 84 3c 0c 00 00    	je     84837a <<gpui_gpu::renderer::Renderer>::render+0x23ba>
  84773e:	0f b6 d0             	movzbl %al,%edx
  847741:	e8 8a 3e 00 00       	call   84b5d0 <<gpui_gpu::renderer::images::Images>::metadata>
  847746:	89 c1                	mov    %eax,%ecx
  847748:	48 c1 e8 20          	shr    $0x20,%rax
  84774c:	89 c2                	mov    %eax,%edx
  84774e:	83 ca 10             	or     $0x10,%edx
  847751:	0f 57 c0             	xorps  %xmm0,%xmm0
  847754:	0f 28 8c 24 f0 00 00 	movaps 0xf0(%rsp),%xmm1
  84775b:	00 
  84775c:	0f 2e c8             	ucomiss %xmm0,%xmm1
  84775f:	0f 45 c2             	cmovne %edx,%eax
  847762:	0f 4a c2             	cmovp  %edx,%eax
  847765:	8b 94 24 20 01 00 00 	mov    0x120(%rsp),%edx
  84776c:	c1 e2 10             	shl    $0x10,%edx
  84776f:	0b 94 24 e0 00 00 00 	or     0xe0(%rsp),%edx
  847776:	89 8c 24 00 01 00 00 	mov    %ecx,0x100(%rsp)
  84777d:	89 84 24 04 01 00 00 	mov    %eax,0x104(%rsp)
  847784:	89 94 24 08 01 00 00 	mov    %edx,0x108(%rsp)
  84778b:	e9 1a 01 00 00       	jmp    8478aa <<gpui_gpu::renderer::Renderer>::render+0x18ea>
  847790:	f3 0f 10 84 24 90 01 	movss  0x190(%rsp),%xmm0
  847797:	00 00 
  847799:	f3 0f 10 1d fb 93 88 	movss  -0x776c05(%rip),%xmm3        # d0b9c <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x14>
  8477a0:	ff 
  8477a1:	f3 0f 59 c3          	mulss  %xmm3,%xmm0
  8477a5:	0f 28 cc             	movaps %xmm4,%xmm1
  8477a8:	f3 0f 5d c8          	minss  %xmm0,%xmm1
  8477ac:	0f 28 c1             	movaps %xmm1,%xmm0
  8477af:	f3 0f c2 c1 03       	cmpunordss %xmm1,%xmm0
  8477b4:	0f 28 d0             	movaps %xmm0,%xmm2
  8477b7:	0f 55 d1             	andnps %xmm1,%xmm2
  8477ba:	0f 54 c4             	andps  %xmm4,%xmm0
  8477bd:	0f 56 c2             	orps   %xmm2,%xmm0
  8477c0:	f3 0f 10 8c 24 94 01 	movss  0x194(%rsp),%xmm1
  8477c7:	00 00 
  8477c9:	f3 0f 59 cb          	mulss  %xmm3,%xmm1
  8477cd:	0f 28 d0             	movaps %xmm0,%xmm2
  8477d0:	f3 0f 5d d1          	minss  %xmm1,%xmm2
  8477d4:	0f 28 ca             	movaps %xmm2,%xmm1
  8477d7:	f3 0f c2 ca 03       	cmpunordss %xmm2,%xmm1
  8477dc:	0f 54 c1             	andps  %xmm1,%xmm0
  8477df:	0f 55 ca             	andnps %xmm2,%xmm1
  8477e2:	0f 56 c8             	orps   %xmm0,%xmm1
  8477e5:	66 0f 7e c8          	movd   %xmm1,%eax
  8477e9:	25 00 00 80 ff       	and    $0xff800000,%eax
  8477ee:	b9 00 00 00 7f       	mov    $0x7f000000,%ecx
  8477f3:	29 c1                	sub    %eax,%ecx
  8477f5:	c7 84 24 00 01 00 00 	movl   $0x40000000,0x100(%rsp)
  8477fc:	00 00 00 40 
  847800:	f3 0f 11 8c 24 04 01 	movss  %xmm1,0x104(%rsp)
  847807:	00 00 
  847809:	89 8c 24 08 01 00 00 	mov    %ecx,0x108(%rsp)
  847810:	e9 95 00 00 00       	jmp    8478aa <<gpui_gpu::renderer::Renderer>::render+0x18ea>
  847815:	80 f9 02             	cmp    $0x2,%cl
  847818:	75 48                	jne    847862 <<gpui_gpu::renderer::Renderer>::render+0x18a2>
  84781a:	48 8b 84 24 80 01 00 	mov    0x180(%rsp),%rax
  847821:	00 
  847822:	48 8b 8c 24 10 03 00 	mov    0x310(%rsp),%rcx
  847829:	00 
  84782a:	48 89 8c 24 60 01 00 	mov    %rcx,0x160(%rsp)
  847831:	00 
  847832:	0f 28 84 24 00 03 00 	movaps 0x300(%rsp),%xmm0
  847839:	00 
  84783a:	0f 29 84 24 50 01 00 	movaps %xmm0,0x150(%rsp)
  847841:	00 
  847842:	48 89 b4 24 68 01 00 	mov    %rsi,0x168(%rsp)
  847849:	00 
  84784a:	89 bc 24 70 01 00 00 	mov    %edi,0x170(%rsp)
  847851:	89 94 24 74 01 00 00 	mov    %edx,0x174(%rsp)
  847858:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
  84785f:	00 
  847860:	eb 0c                	jmp    84786e <<gpui_gpu::renderer::Renderer>::render+0x18ae>
  847862:	48 c7 84 24 50 01 00 	movq   $0x0,0x150(%rsp)
  847869:	00 00 00 00 00 
  84786e:	c7 84 24 e0 02 00 00 	movl   $0x0,0x2e0(%rsp)
  847875:	00 00 00 00 
  847879:	48 c7 84 24 d8 02 00 	movq   $0x0,0x2d8(%rsp)
  847880:	00 00 00 00 00 
  847885:	48 8d bc 24 00 01 00 	lea    0x100(%rsp),%rdi
  84788c:	00 
  84788d:	48 8d b4 24 50 01 00 	lea    0x150(%rsp),%rsi
  847894:	00 
  847895:	48 8d 94 24 d8 02 00 	lea    0x2d8(%rsp),%rdx
  84789c:	00 
  84789d:	48 8b 8c 24 90 03 00 	mov    0x390(%rsp),%rcx
  8478a4:	00 
  8478a5:	e8 46 c4 ff ff       	call   843cf0 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::Renderer>::render_observed<<gpui_gpu::renderer::Renderer>::render::{closure#0}>::{closure#4}>>
  8478aa:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  8478af:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  8478b6:	00 
  8478b7:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
  8478bb:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  8478c0:	48 8b 70 10          	mov    0x10(%rax),%rsi
  8478c4:	48 39 f7             	cmp    %rsi,%rdi
  8478c7:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
  8478cc:	0f 83 b5 0a 00 00    	jae    848387 <<gpui_gpu::renderer::Renderer>::render+0x23c7>
  8478d2:	48 8b 40 08          	mov    0x8(%rax),%rax
  8478d6:	8b 8c 24 08 01 00 00 	mov    0x108(%rsp),%ecx
  8478dd:	42 89 4c 00 08       	mov    %ecx,0x8(%rax,%r8,1)
  8478e2:	48 8b 8c 24 00 01 00 	mov    0x100(%rsp),%rcx
  8478e9:	00 
  8478ea:	4a 89 0c 00          	mov    %rcx,(%rax,%r8,1)
  8478ee:	48 03 54 24 50       	add    0x50(%rsp),%rdx
  8478f3:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
  8478f8:	4c 03 84 24 c0 00 00 	add    0xc0(%rsp),%r8
  8478ff:	00 
  847900:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
  847905:	48 83 c1 04          	add    $0x4,%rcx
  847909:	48 39 4c 24 30       	cmp    %rcx,0x30(%rsp)
  84790e:	0f 85 76 fd ff ff    	jne    84768a <<gpui_gpu::renderer::Renderer>::render+0x16ca>
  847914:	e9 46 fc ff ff       	jmp    84755f <<gpui_gpu::renderer::Renderer>::render+0x159f>
  847919:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  84791e:	48 8b 40 28          	mov    0x28(%rax),%rax
  847922:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
  847929:	00 00 
  84792b:	48 85 c0             	test   %rax,%rax
  84792e:	74 6b                	je     84799b <<gpui_gpu::renderer::Renderer>::render+0x19db>
  847930:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  847935:	48 8b 49 20          	mov    0x20(%rcx),%rcx
  847939:	48 c1 e0 03          	shl    $0x3,%rax
  84793d:	31 ff                	xor    %edi,%edi
  84793f:	eb 1c                	jmp    84795d <<gpui_gpu::renderer::Renderer>::render+0x199d>
  847941:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
  847946:	01 f2                	add    %esi,%edx
  847948:	89 14 f9             	mov    %edx,(%rcx,%rdi,8)
  84794b:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
  847950:	89 54 f9 04          	mov    %edx,0x4(%rcx,%rdi,8)
  847954:	48 ff c7             	inc    %rdi
  847957:	48 83 c0 f8          	add    $0xfffffffffffffff8,%rax
  84795b:	74 32                	je     84798f <<gpui_gpu::renderer::Renderer>::render+0x19cf>
  84795d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  847962:	48 8b 72 58          	mov    0x58(%rdx),%rsi
  847966:	48 39 f7             	cmp    %rsi,%rdi
  847969:	0f 83 25 0a 00 00    	jae    848394 <<gpui_gpu::renderer::Renderer>::render+0x23d4>
  84796f:	8b 74 f9 04          	mov    0x4(%rcx,%rdi,8),%esi
  847973:	83 fe 01             	cmp    $0x1,%esi
  847976:	75 c9                	jne    847941 <<gpui_gpu::renderer::Renderer>::render+0x1981>
  847978:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  84797d:	4c 8b 42 50          	mov    0x50(%rdx),%r8
  847981:	ba 00 00 00 80       	mov    $0x80000000,%edx
  847986:	41 83 3c b8 00       	cmpl   $0x0,(%r8,%rdi,4)
  84798b:	75 c3                	jne    847950 <<gpui_gpu::renderer::Renderer>::render+0x1990>
  84798d:	eb b2                	jmp    847941 <<gpui_gpu::renderer::Renderer>::render+0x1981>
  84798f:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  847994:	89 c0                	mov    %eax,%eax
  847996:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  84799b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  8479a0:	48 8d 78 30          	lea    0x30(%rax),%rdi
  8479a4:	48 c7 40 40 00 00 00 	movq   $0x0,0x40(%rax)
  8479ab:	00 
  8479ac:	48 89 bc 24 a0 00 00 	mov    %rdi,0xa0(%rsp)
  8479b3:	00 
  8479b4:	48 8b 74 24 50       	mov    0x50(%rsp),%rsi
  8479b9:	31 d2                	xor    %edx,%edx
  8479bb:	e8 30 3e 00 00       	call   84b7f0 <<alloc::vec::Vec<u32>>::resize>
  8479c0:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  8479c5:	48 8b 40 10          	mov    0x10(%rax),%rax
  8479c9:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  8479ce:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  8479d3:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  8479da:	00 
  8479db:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  8479e0:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
  8479e7:	00 
  8479e8:	48 c7 84 24 e0 02 00 	movq   $0x0,0x2e0(%rsp)
  8479ef:	00 00 00 00 00 
  8479f4:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  8479fb:	00 
  8479fc:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
  847a03:	00 
  847a04:	48 8b 84 24 40 01 00 	mov    0x140(%rsp),%rax
  847a0b:	00 
  847a0c:	48 89 84 24 f0 02 00 	mov    %rax,0x2f0(%rsp)
  847a13:	00 
  847a14:	8b 44 24 78          	mov    0x78(%rsp),%eax
  847a18:	89 84 24 f8 02 00 00 	mov    %eax,0x2f8(%rsp)
  847a1f:	eb 1a                	jmp    847a3b <<gpui_gpu::renderer::Renderer>::render+0x1a7b>
  847a21:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  847a26:	48 8d 41 fb          	lea    -0x5(%rcx),%rax
  847a2a:	80 bc 24 80 00 00 00 	cmpb   $0x0,0x80(%rsp)
  847a31:	00 
  847a32:	48 0f 45 c8          	cmovne %rax,%rcx
  847a36:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
  847a3b:	48 8d bc 24 48 02 00 	lea    0x248(%rsp),%rdi
  847a42:	00 
  847a43:	48 8d b4 24 d8 02 00 	lea    0x2d8(%rsp),%rsi
  847a4a:	00 
  847a4b:	ff 15 2f 75 67 00    	call   *0x67752f(%rip)        # ebef80 <_DYNAMIC+0x828>
  847a51:	48 8b 84 24 48 02 00 	mov    0x248(%rsp),%rax
  847a58:	00 
  847a59:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
  847a5e:	48 85 c0             	test   %rax,%rax
  847a61:	0f 84 55 02 00 00    	je     847cbc <<gpui_gpu::renderer::Renderer>::render+0x1cfc>
  847a67:	48 8b 8c 24 50 02 00 	mov    0x250(%rsp),%rcx
  847a6e:	00 
  847a6f:	48 8b 94 24 58 02 00 	mov    0x258(%rsp),%rdx
  847a76:	00 
  847a77:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
  847a7c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  847a81:	0f b6 b0 65 03 00 00 	movzbl 0x365(%rax),%esi
  847a88:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  847a8d:	48 89 84 24 50 01 00 	mov    %rax,0x150(%rsp)
  847a94:	00 
  847a95:	48 89 8c 24 c8 00 00 	mov    %rcx,0xc8(%rsp)
  847a9c:	00 
  847a9d:	48 89 8c 24 58 01 00 	mov    %rcx,0x158(%rsp)
  847aa4:	00 
  847aa5:	48 89 94 24 60 01 00 	mov    %rdx,0x160(%rsp)
  847aac:	00 
  847aad:	48 8d 84 24 60 02 00 	lea    0x260(%rsp),%rax
  847ab4:	00 
  847ab5:	0f 10 00             	movups (%rax),%xmm0
  847ab8:	0f 10 48 10          	movups 0x10(%rax),%xmm1
  847abc:	f3 0f 6f 50 20       	movdqu 0x20(%rax),%xmm2
  847ac1:	48 8d 94 24 68 01 00 	lea    0x168(%rsp),%rdx
  847ac8:	00 
  847ac9:	f3 0f 7f 52 20       	movdqu %xmm2,0x20(%rdx)
  847ace:	0f 11 4a 10          	movups %xmm1,0x10(%rdx)
  847ad2:	0f 11 02             	movups %xmm0,(%rdx)
  847ad5:	48 8d 8c 24 90 02 00 	lea    0x290(%rsp),%rcx
  847adc:	00 
  847add:	0f 10 01             	movups (%rcx),%xmm0
  847ae0:	0f 11 42 30          	movups %xmm0,0x30(%rdx)
  847ae4:	0f 10 40 40          	movups 0x40(%rax),%xmm0
  847ae8:	0f 11 42 40          	movups %xmm0,0x40(%rdx)
  847aec:	48 8d bc 24 50 01 00 	lea    0x150(%rsp),%rdi
  847af3:	00 
  847af4:	e8 47 1b 00 00       	call   849640 <gpui_gpu::renderer::compact_group>
  847af9:	88 84 24 80 00 00 00 	mov    %al,0x80(%rsp)
  847b00:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  847b05:	48 85 c0             	test   %rax,%rax
  847b08:	0f 84 13 ff ff ff    	je     847a21 <<gpui_gpu::renderer::Renderer>::render+0x1a61>
  847b0e:	48 89 c1             	mov    %rax,%rcx
  847b11:	48 c1 e1 02          	shl    $0x2,%rcx
  847b15:	0f b6 84 24 80 00 00 	movzbl 0x80(%rsp),%eax
  847b1c:	00 
  847b1d:	8d 14 85 00 00 00 00 	lea    0x0(,%rax,4),%edx
  847b24:	48 83 ca fa          	or     $0xfffffffffffffffa,%rdx
  847b28:	31 f6                	xor    %esi,%esi
  847b2a:	84 c0                	test   %al,%al
  847b2c:	40 0f 94 c6          	sete   %sil
  847b30:	c1 e6 1f             	shl    $0x1f,%esi
  847b33:	89 b4 24 90 00 00 00 	mov    %esi,0x90(%rsp)
  847b3a:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
  847b3f:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  847b44:	01 d0                	add    %edx,%eax
  847b46:	89 44 24 10          	mov    %eax,0x10(%rsp)
  847b4a:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
  847b4f:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  847b56:	00 
  847b57:	8b 54 08 fc          	mov    -0x4(%rax,%rcx,1),%edx
  847b5b:	48 8d bc 24 30 03 00 	lea    0x330(%rsp),%rdi
  847b62:	00 
  847b63:	48 8b 74 24 68       	mov    0x68(%rsp),%rsi
  847b68:	e8 93 d3 ff ff       	call   844f00 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  847b6d:	48 ff 8c 24 00 01 00 	decq   0x100(%rsp)
  847b74:	00 
  847b75:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  847b7a:	48 01 44 24 30       	add    %rax,0x30(%rsp)
  847b7f:	8b 84 24 90 00 00 00 	mov    0x90(%rsp),%eax
  847b86:	0b 44 24 10          	or     0x10(%rsp),%eax
  847b8a:	89 84 24 10 04 00 00 	mov    %eax,0x410(%rsp)
  847b91:	48 8d 84 24 60 02 00 	lea    0x260(%rsp),%rax
  847b98:	00 
  847b99:	0f 10 00             	movups (%rax),%xmm0
  847b9c:	0f 10 48 10          	movups 0x10(%rax),%xmm1
  847ba0:	0f 10 50 20          	movups 0x20(%rax),%xmm2
  847ba4:	48 8d 94 24 68 01 00 	lea    0x168(%rsp),%rdx
  847bab:	00 
  847bac:	0f 11 52 50          	movups %xmm2,0x50(%rdx)
  847bb0:	0f 11 4a 40          	movups %xmm1,0x40(%rdx)
  847bb4:	0f 11 42 30          	movups %xmm0,0x30(%rdx)
  847bb8:	48 8d 8c 24 90 02 00 	lea    0x290(%rsp),%rcx
  847bbf:	00 
  847bc0:	0f 10 01             	movups (%rcx),%xmm0
  847bc3:	0f 11 42 60          	movups %xmm0,0x60(%rdx)
  847bc7:	0f 10 40 40          	movups 0x40(%rax),%xmm0
  847bcb:	0f 11 82 80 00 00 00 	movups %xmm0,0x80(%rdx)
  847bd2:	48 8d 84 24 68 03 00 	lea    0x368(%rsp),%rax
  847bd9:	00 
  847bda:	0f 10 00             	movups (%rax),%xmm0
  847bdd:	0f 11 42 20          	movups %xmm0,0x20(%rdx)
  847be1:	48 8d 84 24 78 03 00 	lea    0x378(%rsp),%rax
  847be8:	00 
  847be9:	0f 10 00             	movups (%rax),%xmm0
  847bec:	0f 11 42 70          	movups %xmm0,0x70(%rdx)
  847bf0:	48 8b 84 24 60 03 00 	mov    0x360(%rsp),%rax
  847bf7:	00 
  847bf8:	48 89 84 24 80 01 00 	mov    %rax,0x180(%rsp)
  847bff:	00 
  847c00:	0f 10 84 24 30 03 00 	movups 0x330(%rsp),%xmm0
  847c07:	00 
  847c08:	0f 10 8c 24 40 03 00 	movups 0x340(%rsp),%xmm1
  847c0f:	00 
  847c10:	f3 0f 6f 94 24 50 03 	movdqu 0x350(%rsp),%xmm2
  847c17:	00 00 
  847c19:	66 0f 7f 94 24 70 01 	movdqa %xmm2,0x170(%rsp)
  847c20:	00 00 
  847c22:	0f 29 8c 24 60 01 00 	movaps %xmm1,0x160(%rsp)
  847c29:	00 
  847c2a:	0f 29 84 24 50 01 00 	movaps %xmm0,0x150(%rsp)
  847c31:	00 
  847c32:	48 8b 84 24 d8 00 00 	mov    0xd8(%rsp),%rax
  847c39:	00 
  847c3a:	48 89 84 24 00 03 00 	mov    %rax,0x300(%rsp)
  847c41:	00 
  847c42:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  847c49:	00 
  847c4a:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
  847c51:	00 
  847c52:	48 8b 84 24 08 04 00 	mov    0x408(%rsp),%rax
  847c59:	00 
  847c5a:	48 89 84 24 10 03 00 	mov    %rax,0x310(%rsp)
  847c61:	00 
  847c62:	48 8d 84 24 00 01 00 	lea    0x100(%rsp),%rax
  847c69:	00 
  847c6a:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
  847c71:	00 
  847c72:	48 8d 84 24 10 04 00 	lea    0x410(%rsp),%rax
  847c79:	00 
  847c7a:	48 89 84 24 20 03 00 	mov    %rax,0x320(%rsp)
  847c81:	00 
  847c82:	48 8d bc 24 50 01 00 	lea    0x150(%rsp),%rdi
  847c89:	00 
  847c8a:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
  847c8f:	48 8d 94 24 00 03 00 	lea    0x300(%rsp),%rdx
  847c96:	00 
  847c97:	e8 a4 ce ff ff       	call   844b40 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::Renderer>::render_observed<<gpui_gpu::renderer::Renderer>::render::{closure#0}>::{closure#5}>>
  847c9c:	8b 44 24 10          	mov    0x10(%rsp),%eax
  847ca0:	03 44 24 20          	add    0x20(%rsp),%eax
  847ca4:	89 44 24 10          	mov    %eax,0x10(%rsp)
  847ca8:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
  847cad:	48 83 c1 fc          	add    $0xfffffffffffffffc,%rcx
  847cb1:	0f 85 93 fe ff ff    	jne    847b4a <<gpui_gpu::renderer::Renderer>::render+0x1b8a>
  847cb7:	e9 65 fd ff ff       	jmp    847a21 <<gpui_gpu::renderer::Renderer>::render+0x1a61>
  847cbc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  847cc1:	48 8b 78 28          	mov    0x28(%rax),%rdi
  847cc5:	48 c7 84 24 d8 00 00 	movq   $0x0,0xd8(%rsp)
  847ccc:	00 00 00 00 00 
  847cd1:	48 85 ff             	test   %rdi,%rdi
  847cd4:	0f 84 ca 00 00 00    	je     847da4 <<gpui_gpu::renderer::Renderer>::render+0x1de4>
  847cda:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  847cdf:	4c 8b 40 20          	mov    0x20(%rax),%r8
  847ce3:	48 c1 e7 03          	shl    $0x3,%rdi
  847ce7:	83 7c 24 60 00       	cmpl   $0x0,0x60(%rsp)
  847cec:	0f 84 42 06 00 00    	je     848334 <<gpui_gpu::renderer::Renderer>::render+0x2374>
  847cf2:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
  847cf9:	00 00 
  847cfb:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
  847d02:	00 00 
  847d04:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  847d0b:	00 00 
  847d0d:	45 31 c9             	xor    %r9d,%r9d
  847d10:	31 c9                	xor    %ecx,%ecx
  847d12:	eb 23                	jmp    847d37 <<gpui_gpu::renderer::Renderer>::render+0x1d77>
  847d14:	48 ff 44 24 10       	incq   0x10(%rsp)
  847d19:	49 ff c1             	inc    %r9
  847d1c:	4c 3b 4c 24 60       	cmp    0x60(%rsp),%r9
  847d21:	b8 00 00 00 00       	mov    $0x0,%eax
  847d26:	4c 0f 44 c8          	cmove  %rax,%r9
  847d2a:	48 ff c1             	inc    %rcx
  847d2d:	48 83 c7 f8          	add    $0xfffffffffffffff8,%rdi
  847d31:	0f 84 88 00 00 00    	je     847dbf <<gpui_gpu::renderer::Renderer>::render+0x1dff>
  847d37:	45 8b 54 c8 04       	mov    0x4(%r8,%rcx,8),%r10d
  847d3c:	44 89 d0             	mov    %r10d,%eax
  847d3f:	f7 d8                	neg    %eax
  847d41:	70 d1                	jo     847d14 <<gpui_gpu::renderer::Renderer>::render+0x1d54>
  847d43:	45 2b 14 c8          	sub    (%r8,%rcx,8),%r10d
  847d47:	74 d0                	je     847d19 <<gpui_gpu::renderer::Renderer>::render+0x1d59>
  847d49:	48 89 c8             	mov    %rcx,%rax
  847d4c:	48 c1 e8 20          	shr    $0x20,%rax
  847d50:	74 0f                	je     847d61 <<gpui_gpu::renderer::Renderer>::render+0x1da1>
  847d52:	48 89 c8             	mov    %rcx,%rax
  847d55:	31 d2                	xor    %edx,%edx
  847d57:	48 f7 74 24 60       	divq   0x60(%rsp)
  847d5c:	4c 89 ca             	mov    %r9,%rdx
  847d5f:	eb 08                	jmp    847d69 <<gpui_gpu::renderer::Renderer>::render+0x1da9>
  847d61:	89 c8                	mov    %ecx,%eax
  847d63:	31 d2                	xor    %edx,%edx
  847d65:	f7 74 24 60          	divl   0x60(%rsp)
  847d69:	c1 e2 04             	shl    $0x4,%edx
  847d6c:	c1 e0 04             	shl    $0x4,%eax
  847d6f:	44 8d 5a 10          	lea    0x10(%rdx),%r11d
  847d73:	45 39 de             	cmp    %r11d,%r14d
  847d76:	45 0f 42 de          	cmovb  %r14d,%r11d
  847d7a:	8d 70 10             	lea    0x10(%rax),%esi
  847d7d:	41 39 f7             	cmp    %esi,%r15d
  847d80:	41 0f 42 f7          	cmovb  %r15d,%esi
  847d84:	41 29 d3             	sub    %edx,%r11d
  847d87:	29 c6                	sub    %eax,%esi
  847d89:	41 0f af f3          	imul   %r11d,%esi
  847d8d:	48 c1 e6 04          	shl    $0x4,%rsi
  847d91:	48 01 74 24 18       	add    %rsi,0x18(%rsp)
  847d96:	4c 0f af d6          	imul   %rsi,%r10
  847d9a:	4c 01 54 24 20       	add    %r10,0x20(%rsp)
  847d9f:	e9 75 ff ff ff       	jmp    847d19 <<gpui_gpu::renderer::Renderer>::render+0x1d59>
  847da4:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  847dab:	00 00 
  847dad:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
  847db4:	00 00 
  847db6:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
  847dbd:	00 00 
  847dbf:	41 f6 c5 01          	test   $0x1,%r13b
  847dc3:	74 53                	je     847e18 <<gpui_gpu::renderer::Renderer>::render+0x1e58>
  847dc5:	66 0f 6e 84 24 4c 01 	movd   0x14c(%rsp),%xmm0
  847dcc:	00 00 
  847dce:	66 0f 7e c0          	movd   %xmm0,%eax
  847dd2:	85 c0                	test   %eax,%eax
  847dd4:	0f 99 c1             	setns  %cl
  847dd7:	89 c2                	mov    %eax,%edx
  847dd9:	81 e2 ff ff ff 7f    	and    $0x7fffffff,%edx
  847ddf:	81 c2 00 00 80 ff    	add    $0xff800000,%edx
  847de5:	81 fa 00 00 00 7f    	cmp    $0x7f000000,%edx
  847deb:	0f 92 c2             	setb   %dl
  847dee:	20 ca                	and    %cl,%dl
  847df0:	ff c8                	dec    %eax
  847df2:	3d ff ff 7f 00       	cmp    $0x7fffff,%eax
  847df7:	0f 92 c0             	setb   %al
  847dfa:	08 d0                	or     %dl,%al
  847dfc:	b8 02 00 00 00       	mov    $0x2,%eax
  847e01:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
  847e08:	00 
  847e09:	66 0f 7e 84 24 ec 00 	movd   %xmm0,0xec(%rsp)
  847e10:	00 00 
  847e12:	0f 84 12 05 00 00    	je     84832a <<gpui_gpu::renderer::Renderer>::render+0x236a>
  847e18:	48 8b 8c 24 d0 00 00 	mov    0xd0(%rsp),%rcx
  847e1f:	00 
  847e20:	48 83 c1 18          	add    $0x18,%rcx
  847e24:	31 d2                	xor    %edx,%edx
  847e26:	48 8b 84 24 a0 03 00 	mov    0x3a0(%rsp),%rax
  847e2d:	00 
  847e2e:	48 3b 84 24 a8 03 00 	cmp    0x3a8(%rsp),%rax
  847e35:	00 
  847e36:	0f 95 c2             	setne  %dl
  847e39:	31 c0                	xor    %eax,%eax
  847e3b:	83 fd 28             	cmp    $0x28,%ebp
  847e3e:	0f 94 c0             	sete   %al
  847e41:	41 83 e4 01          	and    $0x1,%r12d
  847e45:	41 8d 04 84          	lea    (%r12,%rax,4),%eax
  847e49:	8d 04 d0             	lea    (%rax,%rdx,8),%eax
  847e4c:	0b 84 24 d8 00 00 00 	or     0xd8(%rsp),%eax
  847e53:	0f 10 01             	movups (%rcx),%xmm0
  847e56:	0f 11 84 24 58 02 00 	movups %xmm0,0x258(%rsp)
  847e5d:	00 
  847e5e:	44 89 b4 24 48 02 00 	mov    %r14d,0x248(%rsp)
  847e65:	00 
  847e66:	44 89 bc 24 4c 02 00 	mov    %r15d,0x24c(%rsp)
  847e6d:	00 
  847e6e:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  847e73:	89 8c 24 50 02 00 00 	mov    %ecx,0x250(%rsp)
  847e7a:	89 84 24 54 02 00 00 	mov    %eax,0x254(%rsp)
  847e81:	f3 0f 10 84 24 ec 00 	movss  0xec(%rsp),%xmm0
  847e88:	00 00 
  847e8a:	f3 0f 11 84 24 68 02 	movss  %xmm0,0x268(%rsp)
  847e91:	00 00 
  847e93:	48 c7 84 24 6c 02 00 	movq   $0x0,0x26c(%rsp)
  847e9a:	00 00 00 00 00 
  847e9f:	c7 84 24 74 02 00 00 	movl   $0x0,0x274(%rsp)
  847ea6:	00 00 00 00 
  847eaa:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
  847eaf:	49 8d b4 24 48 02 00 	lea    0x248(%r12),%rsi
  847eb6:	00 
  847eb7:	48 8d 8c 24 48 02 00 	lea    0x248(%rsp),%rcx
  847ebe:	00 
  847ebf:	41 b8 30 00 00 00    	mov    $0x30,%r8d
  847ec5:	48 8b ac 24 c0 03 00 	mov    0x3c0(%rsp),%rbp
  847ecc:	00 
  847ecd:	48 89 ef             	mov    %rbp,%rdi
  847ed0:	31 d2                	xor    %edx,%edx
  847ed2:	ff 15 b0 70 67 00    	call   *0x6770b0(%rip)        # ebef88 <_DYNAMIC+0x830>
  847ed8:	49 8b 4c 24 08       	mov    0x8(%r12),%rcx
  847edd:	4d 8b 44 24 10       	mov    0x10(%r12),%r8
  847ee2:	49 c1 e0 04          	shl    $0x4,%r8
  847ee6:	48 8b bc 24 b0 02 00 	mov    0x2b0(%rsp),%rdi
  847eed:	00 
  847eee:	4c 8b ac 24 d0 03 00 	mov    0x3d0(%rsp),%r13
  847ef5:	00 
  847ef6:	4c 89 ee             	mov    %r13,%rsi
  847ef9:	48 89 ea             	mov    %rbp,%rdx
  847efc:	e8 8f d2 ff ff       	call   845190 <<gpui_gpu::renderer::Buffer>::write>
  847f01:	49 8d bc 24 98 02 00 	lea    0x298(%r12),%rdi
  847f08:	00 
  847f09:	49 8b 4c 24 20       	mov    0x20(%r12),%rcx
  847f0e:	4d 8b 44 24 28       	mov    0x28(%r12),%r8
  847f13:	49 c1 e0 03          	shl    $0x3,%r8
  847f17:	4c 89 ee             	mov    %r13,%rsi
  847f1a:	48 89 ea             	mov    %rbp,%rdx
  847f1d:	e8 6e d2 ff ff       	call   845190 <<gpui_gpu::renderer::Buffer>::write>
  847f22:	49 8d bc 24 c0 02 00 	lea    0x2c0(%r12),%rdi
  847f29:	00 
  847f2a:	49 8b 4c 24 38       	mov    0x38(%r12),%rcx
  847f2f:	4d 8b 44 24 40       	mov    0x40(%r12),%r8
  847f34:	49 c1 e0 02          	shl    $0x2,%r8
  847f38:	4c 89 ee             	mov    %r13,%rsi
  847f3b:	48 89 ea             	mov    %rbp,%rdx
  847f3e:	e8 4d d2 ff ff       	call   845190 <<gpui_gpu::renderer::Buffer>::write>
  847f43:	49 8d bc 24 e8 02 00 	lea    0x2e8(%r12),%rdi
  847f4a:	00 
  847f4b:	49 8b 4c 24 68       	mov    0x68(%r12),%rcx
  847f50:	4d 8b 44 24 70       	mov    0x70(%r12),%r8
  847f55:	49 c1 e0 05          	shl    $0x5,%r8
  847f59:	4c 89 ee             	mov    %r13,%rsi
  847f5c:	48 89 ea             	mov    %rbp,%rdx
  847f5f:	e8 2c d2 ff ff       	call   845190 <<gpui_gpu::renderer::Buffer>::write>
  847f64:	49 8d 84 24 40 02 00 	lea    0x240(%r12),%rax
  847f6b:	00 
  847f6c:	49 8d 8c 24 c8 00 00 	lea    0xc8(%r12),%rcx
  847f73:	00 
  847f74:	48 c7 84 24 50 01 00 	movq   $0x0,0x150(%rsp)
  847f7b:	00 00 00 00 00 
  847f80:	49 8d 94 24 48 02 00 	lea    0x248(%r12),%rdx
  847f87:	00 
  847f88:	48 89 94 24 58 01 00 	mov    %rdx,0x158(%rsp)
  847f8f:	00 
  847f90:	48 c7 84 24 78 01 00 	movq   $0x0,0x178(%rsp)
  847f97:	00 00 00 00 00 
  847f9c:	0f 57 c0             	xorps  %xmm0,%xmm0
  847f9f:	0f 11 84 24 60 01 00 	movups %xmm0,0x160(%rsp)
  847fa6:	00 
  847fa7:	c7 84 24 70 01 00 00 	movl   $0x0,0x170(%rsp)
  847fae:	00 00 00 00 
  847fb2:	48 8b 94 24 b0 02 00 	mov    0x2b0(%rsp),%rdx
  847fb9:	00 
  847fba:	48 89 94 24 80 01 00 	mov    %rdx,0x180(%rsp)
  847fc1:	00 
  847fc2:	0f 11 84 24 88 01 00 	movups %xmm0,0x188(%rsp)
  847fc9:	00 
  847fca:	c7 84 24 98 01 00 00 	movl   $0x1,0x198(%rsp)
  847fd1:	01 00 00 00 
  847fd5:	48 c7 84 24 a0 01 00 	movq   $0x0,0x1a0(%rsp)
  847fdc:	00 00 00 00 00 
  847fe1:	49 8d 94 24 98 02 00 	lea    0x298(%r12),%rdx
  847fe8:	00 
  847fe9:	48 89 94 24 a8 01 00 	mov    %rdx,0x1a8(%rsp)
  847ff0:	00 
  847ff1:	0f 11 84 24 b0 01 00 	movups %xmm0,0x1b0(%rsp)
  847ff8:	00 
  847ff9:	c7 84 24 c0 01 00 00 	movl   $0x2,0x1c0(%rsp)
  848000:	02 00 00 00 
  848004:	48 c7 84 24 c8 01 00 	movq   $0x0,0x1c8(%rsp)
  84800b:	00 00 00 00 00 
  848010:	49 8d 94 24 c0 02 00 	lea    0x2c0(%r12),%rdx
  848017:	00 
  848018:	48 89 94 24 d0 01 00 	mov    %rdx,0x1d0(%rsp)
  84801f:	00 
  848020:	0f 11 84 24 d8 01 00 	movups %xmm0,0x1d8(%rsp)
  848027:	00 
  848028:	c7 84 24 e8 01 00 00 	movl   $0x3,0x1e8(%rsp)
  84802f:	03 00 00 00 
  848033:	48 c7 84 24 f0 01 00 	movq   $0x4,0x1f0(%rsp)
  84803a:	00 04 00 00 00 
  84803f:	48 89 8c 24 f8 01 00 	mov    %rcx,0x1f8(%rsp)
  848046:	00 
  848047:	c7 84 24 10 02 00 00 	movl   $0x4,0x210(%rsp)
  84804e:	04 00 00 00 
  848052:	48 c7 84 24 18 02 00 	movq   $0x0,0x218(%rsp)
  848059:	00 00 00 00 00 
  84805e:	49 8d 8c 24 e8 02 00 	lea    0x2e8(%r12),%rcx
  848065:	00 
  848066:	48 89 8c 24 20 02 00 	mov    %rcx,0x220(%rsp)
  84806d:	00 
  84806e:	0f 11 84 24 28 02 00 	movups %xmm0,0x228(%rsp)
  848075:	00 
  848076:	c7 84 24 38 02 00 00 	movl   $0x5,0x238(%rsp)
  84807d:	05 00 00 00 
  848081:	48 8d 0d b0 8f 89 ff 	lea    -0x767050(%rip),%rcx        # e1038 <anon.3ceedfc47844159f5932a07258a01292.0.llvm.14111504948212592604+0x2e3c>
  848088:	48 89 8c 24 48 03 00 	mov    %rcx,0x348(%rsp)
  84808f:	00 
  848090:	48 c7 84 24 50 03 00 	movq   $0xa,0x350(%rsp)
  848097:	00 0a 00 00 00 
  84809c:	48 89 84 24 30 03 00 	mov    %rax,0x330(%rsp)
  8480a3:	00 
  8480a4:	48 8d 84 24 50 01 00 	lea    0x150(%rsp),%rax
  8480ab:	00 
  8480ac:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
  8480b3:	00 
  8480b4:	48 c7 84 24 40 03 00 	movq   $0x6,0x340(%rsp)
  8480bb:	00 06 00 00 00 
  8480c0:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
  8480c7:	00 
  8480c8:	4c 89 ef             	mov    %r13,%rdi
  8480cb:	ff 15 bf 6e 67 00    	call   *0x676ebf(%rip)        # ebef90 <_DYNAMIC+0x838>
  8480d1:	49 89 c5             	mov    %rax,%r13
  8480d4:	48 89 84 24 00 03 00 	mov    %rax,0x300(%rsp)
  8480db:	00 
  8480dc:	48 8d 94 24 00 03 00 	lea    0x300(%rsp),%rdx
  8480e3:	00 
  8480e4:	4c 89 e7             	mov    %r12,%rdi
  8480e7:	48 8b b4 24 00 04 00 	mov    0x400(%rsp),%rsi
  8480ee:	00 
  8480ef:	e8 0c 03 00 00       	call   848400 <<gpui_gpu::renderer::Renderer>::submit>
  8480f4:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  8480f9:	31 ed                	xor    %ebp,%ebp
  8480fb:	48 8b 84 24 a0 03 00 	mov    0x3a0(%rsp),%rax
  848102:	00 
  848103:	48 3b 84 24 a8 03 00 	cmp    0x3a8(%rsp),%rax
  84810a:	00 
  84810b:	40 0f 95 c5          	setne  %bpl
  84810f:	c1 e5 1f             	shl    $0x1f,%ebp
  848112:	44 09 f5             	or     %r14d,%ebp
  848115:	49 c1 e7 20          	shl    $0x20,%r15
  848119:	4c 09 fd             	or     %r15,%rbp
  84811c:	48 8b 03             	mov    (%rbx),%rax
  84811f:	48 85 c0             	test   %rax,%rax
  848122:	74 0f                	je     848133 <<gpui_gpu::renderer::Renderer>::render+0x2173>
  848124:	f0 48 ff 08          	lock decq (%rax)
  848128:	75 09                	jne    848133 <<gpui_gpu::renderer::Renderer>::render+0x2173>
  84812a:	48 89 df             	mov    %rbx,%rdi
  84812d:	ff 15 c5 6a 67 00    	call   *0x676ac5(%rip)        # ebebf8 <_DYNAMIC+0x4a0>
  848133:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  848138:	4c 89 a8 48 03 00 00 	mov    %r13,0x348(%rax)
  84813f:	48 89 a8 50 03 00 00 	mov    %rbp,0x350(%rax)
  848146:	4c 8b 40 10          	mov    0x10(%rax),%r8
  84814a:	48 8b 70 28          	mov    0x28(%rax),%rsi
  84814e:	48 8b 48 70          	mov    0x70(%rax),%rcx
  848152:	48 89 8c 24 d8 00 00 	mov    %rcx,0xd8(%rsp)
  848159:	00 
  84815a:	49 c1 e0 04          	shl    $0x4,%r8
  84815e:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
  848163:	49 8d 3c 90          	lea    (%r8,%rdx,4),%rdi
  848167:	48 8d 34 f7          	lea    (%rdi,%rsi,8),%rsi
  84816b:	48 89 cf             	mov    %rcx,%rdi
  84816e:	48 c1 e7 05          	shl    $0x5,%rdi
  848172:	48 8d 0c 37          	lea    (%rdi,%rsi,1),%rcx
  848176:	48 83 c1 30          	add    $0x30,%rcx
  84817a:	48 89 8c 24 d0 00 00 	mov    %rcx,0xd0(%rsp)
  848181:	00 
  848182:	48 8b b8 90 02 00 00 	mov    0x290(%rax),%rdi
  848189:	48 03 b8 68 02 00 00 	add    0x268(%rax),%rdi
  848190:	48 03 b8 b8 02 00 00 	add    0x2b8(%rax),%rdi
  848197:	48 03 b8 e0 02 00 00 	add    0x2e0(%rax),%rdi
  84819e:	48 03 b8 08 03 00 00 	add    0x308(%rax),%rdi
  8481a5:	48 8b b0 20 03 00 00 	mov    0x320(%rax),%rsi
  8481ac:	48 03 b0 28 03 00 00 	add    0x328(%rax),%rsi
  8481b3:	44 8b 88 50 01 00 00 	mov    0x150(%rax),%r9d
  8481ba:	4d 0f af c9          	imul   %r9,%r9
  8481be:	4c 8b 9c 24 b8 00 00 	mov    0xb8(%rsp),%r11
  8481c5:	00 
  8481c6:	4c 89 d9             	mov    %r11,%rcx
  8481c9:	48 29 d1             	sub    %rdx,%rcx
  8481cc:	4c 8b 54 24 70       	mov    0x70(%rsp),%r10
  8481d1:	4d 89 d4             	mov    %r10,%r12
  8481d4:	48 8b ac 24 38 01 00 	mov    0x138(%rsp),%rbp
  8481db:	00 
  8481dc:	49 29 ec             	sub    %rbp,%r12
  8481df:	48 8b 98 60 01 00 00 	mov    0x160(%rax),%rbx
  8481e6:	48 ff c3             	inc    %rbx
  8481e9:	49 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%r14
  8481f0:	4c 0f 45 f3          	cmovne %rbx,%r14
  8481f4:	48 8b 18             	mov    (%rax),%rbx
  8481f7:	48 c1 e3 04          	shl    $0x4,%rbx
  8481fb:	4c 8b 78 48          	mov    0x48(%rax),%r15
  8481ff:	4c 03 78 30          	add    0x30(%rax),%r15
  848203:	4c 8b 68 18          	mov    0x18(%rax),%r13
  848207:	4a 8d 1c eb          	lea    (%rbx,%r13,8),%rbx
  84820b:	4a 8d 1c bb          	lea    (%rbx,%r15,4),%rbx
  84820f:	4c 8b 78 60          	mov    0x60(%rax),%r15
  848213:	49 c1 e7 05          	shl    $0x5,%r15
  848217:	49 01 df             	add    %rbx,%r15
  84821a:	48 8b 98 38 01 00 00 	mov    0x138(%rax),%rbx
  848221:	4c 8b a8 30 01 00 00 	mov    0x130(%rax),%r13
  848228:	4c 89 b0 60 01 00 00 	mov    %r14,0x160(%rax)
  84822f:	4c 89 90 68 01 00 00 	mov    %r10,0x168(%rax)
  848236:	4f 8d 34 1b          	lea    (%r11,%r11,1),%r14
  84823a:	4c 89 b0 70 01 00 00 	mov    %r14,0x170(%rax)
  848241:	48 c7 80 78 01 00 00 	movq   $0x1,0x178(%rax)
  848248:	01 00 00 00 
  84824c:	4c 89 90 80 01 00 00 	mov    %r10,0x180(%rax)
  848253:	48 89 90 88 01 00 00 	mov    %rdx,0x188(%rax)
  84825a:	4c 89 98 90 01 00 00 	mov    %r11,0x190(%rax)
  848261:	48 89 88 98 01 00 00 	mov    %rcx,0x198(%rax)
  848268:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  84826d:	48 89 88 a0 01 00 00 	mov    %rcx,0x1a0(%rax)
  848274:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
  848279:	48 89 88 a8 01 00 00 	mov    %rcx,0x1a8(%rax)
  848280:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
  848285:	48 89 88 b0 01 00 00 	mov    %rcx,0x1b0(%rax)
  84828c:	48 8b 8c 24 d0 00 00 	mov    0xd0(%rsp),%rcx
  848293:	00 
  848294:	48 89 88 b8 01 00 00 	mov    %rcx,0x1b8(%rax)
  84829b:	4c 89 80 c0 01 00 00 	mov    %r8,0x1c0(%rax)
  8482a2:	48 8b 94 24 30 01 00 	mov    0x130(%rsp),%rdx
  8482a9:	00 
  8482aa:	48 89 90 c8 01 00 00 	mov    %rdx,0x1c8(%rax)
  8482b1:	48 89 a8 d0 01 00 00 	mov    %rbp,0x1d0(%rax)
  8482b8:	4c 89 a0 d8 01 00 00 	mov    %r12,0x1d8(%rax)
  8482bf:	48 8b 8c 24 b0 03 00 	mov    0x3b0(%rsp),%rcx
  8482c6:	00 
  8482c7:	48 89 88 e0 01 00 00 	mov    %rcx,0x1e0(%rax)
  8482ce:	48 89 b8 e8 01 00 00 	mov    %rdi,0x1e8(%rax)
  8482d5:	4c 89 88 f0 01 00 00 	mov    %r9,0x1f0(%rax)
  8482dc:	49 01 dd             	add    %rbx,%r13
  8482df:	48 89 98 f8 01 00 00 	mov    %rbx,0x1f8(%rax)
  8482e6:	4c 89 a8 00 02 00 00 	mov    %r13,0x200(%rax)
  8482ed:	4c 89 b8 08 02 00 00 	mov    %r15,0x208(%rax)
  8482f4:	48 8b 8c 24 d8 00 00 	mov    0xd8(%rsp),%rcx
  8482fb:	00 
  8482fc:	48 89 88 10 02 00 00 	mov    %rcx,0x210(%rax)
  848303:	48 89 b0 18 02 00 00 	mov    %rsi,0x218(%rax)
  84830a:	c6 80 20 02 00 00 00 	movb   $0x0,0x220(%rax)
  848311:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
  848316:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  84831b:	48 89 47 08          	mov    %rax,0x8(%rdi)
  84831f:	c7 07 ff ff ff ff    	movl   $0xffffffff,(%rdi)
  848325:	e9 6e dd ff ff       	jmp    846098 <<gpui_gpu::renderer::Renderer>::render+0xd8>
  84832a:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
  84832f:	e9 5e dd ff ff       	jmp    846092 <<gpui_gpu::renderer::Renderer>::render+0xd2>
  848334:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
  84833b:	00 00 
  84833d:	31 c0                	xor    %eax,%eax
  84833f:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  848346:	00 00 
  848348:	eb 12                	jmp    84835c <<gpui_gpu::renderer::Renderer>::render+0x239c>
  84834a:	48 ff 44 24 10       	incq   0x10(%rsp)
  84834f:	48 83 c0 08          	add    $0x8,%rax
  848353:	48 39 c7             	cmp    %rax,%rdi
  848356:	0f 84 5a fa ff ff    	je     847db6 <<gpui_gpu::renderer::Renderer>::render+0x1df6>
  84835c:	41 8b 4c 00 04       	mov    0x4(%r8,%rax,1),%ecx
  848361:	89 ca                	mov    %ecx,%edx
  848363:	f7 da                	neg    %edx
  848365:	70 e3                	jo     84834a <<gpui_gpu::renderer::Renderer>::render+0x238a>
  848367:	41 39 0c 00          	cmp    %ecx,(%r8,%rax,1)
  84836b:	74 e2                	je     84834f <<gpui_gpu::renderer::Renderer>::render+0x238f>
  84836d:	48 8d 3d 6c 48 62 00 	lea    0x62486c(%rip),%rdi        # e6cbe0 <anon.a4ca57330ad1a976cc33af1b39cd7163.29.llvm.8592613435371681628+0x10>
  848374:	ff 15 1e 6c 67 00    	call   *0x676c1e(%rip)        # ebef98 <_DYNAMIC+0x840>
  84837a:	48 8d 3d c7 46 62 00 	lea    0x6246c7(%rip),%rdi        # e6ca48 <anon.59d2062463a56a48178a879f804ca345.3.llvm.17286516331901804694+0x2b0>
  848381:	ff 15 49 67 67 00    	call   *0x676749(%rip)        # ebead0 <_DYNAMIC+0x378>
  848387:	48 8d 15 d2 46 62 00 	lea    0x6246d2(%rip),%rdx        # e6ca60 <anon.59d2062463a56a48178a879f804ca345.3.llvm.17286516331901804694+0x2c8>
  84838e:	ff 15 b4 68 67 00    	call   *0x6768b4(%rip)        # ebec48 <_DYNAMIC+0x4f0>
  848394:	48 8d 15 95 46 62 00 	lea    0x624695(%rip),%rdx        # e6ca30 <anon.59d2062463a56a48178a879f804ca345.3.llvm.17286516331901804694+0x298>
  84839b:	ff 15 a7 68 67 00    	call   *0x6768a7(%rip)        # ebec48 <_DYNAMIC+0x4f0>
  8483a1:	49 89 c6             	mov    %rax,%r14
  8483a4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  8483a9:	4c 89 a8 48 03 00 00 	mov    %r13,0x348(%rax)
  8483b0:	48 89 a8 50 03 00 00 	mov    %rbp,0x350(%rax)
  8483b7:	4c 89 f7             	mov    %r14,%rdi
  8483ba:	e8 61 f4 61 00       	call   e67820 <_Unwind_Resume@plt>
  8483bf:	49 89 c6             	mov    %rax,%r14
  8483c2:	f0 49 ff 4d 00       	lock decq 0x0(%r13)
  8483c7:	75 20                	jne    8483e9 <<gpui_gpu::renderer::Renderer>::render+0x2429>
  8483c9:	48 8d bc 24 00 03 00 	lea    0x300(%rsp),%rdi
  8483d0:	00 
  8483d1:	ff 15 21 68 67 00    	call   *0x676821(%rip)        # ebebf8 <_DYNAMIC+0x4a0>
  8483d7:	eb 10                	jmp    8483e9 <<gpui_gpu::renderer::Renderer>::render+0x2429>
  8483d9:	ff 15 f1 65 67 00    	call   *0x6765f1(%rip)        # ebe9d0 <_DYNAMIC+0x278>
  8483df:	49 89 c6             	mov    %rax,%r14
  8483e2:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
  8483e9:	4c 89 f7             	mov    %r14,%rdi
  8483ec:	e8 2f f4 61 00       	call   e67820 <_Unwind_Resume@plt>
