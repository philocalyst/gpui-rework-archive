
/tmp/gpui-shared-gpu-controls/1b200d66cfc28a76e4c61b3d154a26055ae908a0/owned:     file format elf64-x86-64


Disassembly of section .text:

0000000000846990 <<gpui_gpu::renderer::RendererState>::render>:
  846990:	55                   	push   %rbp
  846991:	41 57                	push   %r15
  846993:	41 56                	push   %r14
  846995:	41 55                	push   %r13
  846997:	41 54                	push   %r12
  846999:	53                   	push   %rbx
  84699a:	48 81 ec 68 05 00 00 	sub    $0x568,%rsp
  8469a1:	48 8b 86 20 03 00 00 	mov    0x320(%rsi),%rax
  8469a8:	48 3b 42 20          	cmp    0x20(%rdx),%rax
  8469ac:	0f 85 ce 00 00 00    	jne    846a80 <<gpui_gpu::renderer::RendererState>::render+0xf0>
  8469b2:	48 8d 9e 30 03 00 00 	lea    0x330(%rsi),%rbx
  8469b9:	48 8b 86 30 03 00 00 	mov    0x330(%rsi),%rax
  8469c0:	48 85 c0             	test   %rax,%rax
  8469c3:	74 2d                	je     8469f2 <<gpui_gpu::renderer::RendererState>::render+0x62>
  8469c5:	f0 48 ff 08          	lock decq (%rax)
  8469c9:	75 27                	jne    8469f2 <<gpui_gpu::renderer::RendererState>::render+0x62>
  8469cb:	49 89 fe             	mov    %rdi,%r14
  8469ce:	48 89 df             	mov    %rbx,%rdi
  8469d1:	49 89 f4             	mov    %rsi,%r12
  8469d4:	4d 89 c5             	mov    %r8,%r13
  8469d7:	49 89 d7             	mov    %rdx,%r15
  8469da:	48 89 cd             	mov    %rcx,%rbp
  8469dd:	ff 15 cd 87 67 00    	call   *0x6787cd(%rip)        # ebf1b0 <_DYNAMIC+0x488>
  8469e3:	48 89 e9             	mov    %rbp,%rcx
  8469e6:	4c 89 fa             	mov    %r15,%rdx
  8469e9:	4d 89 e8             	mov    %r13,%r8
  8469ec:	4c 89 e6             	mov    %r12,%rsi
  8469ef:	4c 89 f7             	mov    %r14,%rdi
  8469f2:	48 c7 86 30 03 00 00 	movq   $0x0,0x330(%rsi)
  8469f9:	00 00 00 00 
  8469fd:	44 8b 29             	mov    (%rcx),%r13d
  846a00:	44 8b 49 08          	mov    0x8(%rcx),%r9d
  846a04:	0f b6 41 0d          	movzbl 0xd(%rcx),%eax
  846a08:	45 85 c9             	test   %r9d,%r9d
  846a0b:	41 0f 98 c2          	sets   %r10b
  846a0f:	41 81 e1 ff ff ff 7f 	and    $0x7fffffff,%r9d
  846a16:	45 8d 99 00 00 80 ff 	lea    -0x800000(%r9),%r11d
  846a1d:	41 81 fb 00 00 00 7f 	cmp    $0x7f000000,%r11d
  846a24:	41 0f 92 c3          	setb   %r11b
  846a28:	45 20 d3             	and    %r10b,%r11b
  846a2b:	41 8d 69 ff          	lea    -0x1(%r9),%ebp
  846a2f:	81 fd ff ff 7f 00    	cmp    $0x7fffff,%ebp
  846a35:	40 0f 92 c5          	setb   %bpl
  846a39:	44 20 d5             	and    %r10b,%bpl
  846a3c:	45 85 c9             	test   %r9d,%r9d
  846a3f:	41 0f 94 c2          	sete   %r10b
  846a43:	41 81 f9 00 00 80 7f 	cmp    $0x7f800000,%r9d
  846a4a:	41 0f 94 c6          	sete   %r14b
  846a4e:	45 08 d6             	or     %r10b,%r14b
  846a51:	41 81 f9 01 00 80 7f 	cmp    $0x7f800001,%r9d
  846a58:	41 0f 9d c1          	setge  %r9b
  846a5c:	45 08 f1             	or     %r14b,%r9b
  846a5f:	41 08 e9             	or     %bpl,%r9b
  846a62:	45 85 ed             	test   %r13d,%r13d
  846a65:	41 0f 95 c2          	setne  %r10b
  846a69:	41 20 c2             	and    %al,%r10b
  846a6c:	45 08 da             	or     %r11b,%r10b
  846a6f:	45 08 ca             	or     %r9b,%r10b
  846a72:	41 f6 c2 01          	test   $0x1,%r10b
  846a76:	74 23                	je     846a9b <<gpui_gpu::renderer::RendererState>::render+0x10b>
  846a78:	c7 07 03 00 00 00    	movl   $0x3,(%rdi)
  846a7e:	eb 06                	jmp    846a86 <<gpui_gpu::renderer::RendererState>::render+0xf6>
  846a80:	c7 07 04 00 00 00    	movl   $0x4,(%rdi)
  846a86:	48 89 f8             	mov    %rdi,%rax
  846a89:	48 81 c4 68 05 00 00 	add    $0x568,%rsp
  846a90:	5b                   	pop    %rbx
  846a91:	41 5c                	pop    %r12
  846a93:	41 5d                	pop    %r13
  846a95:	41 5e                	pop    %r14
  846a97:	41 5f                	pop    %r15
  846a99:	5d                   	pop    %rbp
  846a9a:	c3                   	ret
  846a9b:	66 0f 6e 51 04       	movd   0x4(%rcx),%xmm2
  846aa0:	44 0f b6 61 0c       	movzbl 0xc(%rcx),%r12d
  846aa5:	41 f6 c5 01          	test   $0x1,%r13b
  846aa9:	74 75                	je     846b20 <<gpui_gpu::renderer::RendererState>::render+0x190>
  846aab:	66 41 0f 7e d1       	movd   %xmm2,%r9d
  846ab0:	45 85 c9             	test   %r9d,%r9d
  846ab3:	41 0f 98 c2          	sets   %r10b
  846ab7:	41 81 e1 ff ff ff 7f 	and    $0x7fffffff,%r9d
  846abe:	45 8d 99 00 00 80 ff 	lea    -0x800000(%r9),%r11d
  846ac5:	41 81 fb 00 00 00 7f 	cmp    $0x7f000000,%r11d
  846acc:	41 0f 92 c3          	setb   %r11b
  846ad0:	45 20 d3             	and    %r10b,%r11b
  846ad3:	41 8d 69 ff          	lea    -0x1(%r9),%ebp
  846ad7:	81 fd ff ff 7f 00    	cmp    $0x7fffff,%ebp
  846add:	40 0f 92 c5          	setb   %bpl
  846ae1:	44 20 d5             	and    %r10b,%bpl
  846ae4:	45 85 c9             	test   %r9d,%r9d
  846ae7:	41 0f 94 c2          	sete   %r10b
  846aeb:	41 81 f9 00 00 80 7f 	cmp    $0x7f800000,%r9d
  846af2:	41 0f 94 c6          	sete   %r14b
  846af6:	45 08 d6             	or     %r10b,%r14b
  846af9:	41 81 f9 01 00 80 7f 	cmp    $0x7f800001,%r9d
  846b00:	41 0f 9d c1          	setge  %r9b
  846b04:	45 08 f1             	or     %r14b,%r9b
  846b07:	41 08 e9             	or     %bpl,%r9b
  846b0a:	45 08 d9             	or     %r11b,%r9b
  846b0d:	0f 85 65 ff ff ff    	jne    846a78 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846b13:	0f 2e 15 26 a1 88 ff 	ucomiss -0x775eda(%rip),%xmm2        # d0c40 <anon.630a3fff68f6bca64b568be97512ab45.57.llvm.826976926275214120+0x24>
  846b1a:	0f 87 58 ff ff ff    	ja     846a78 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846b20:	44 8b 71 28          	mov    0x28(%rcx),%r14d
  846b24:	45 39 70 20          	cmp    %r14d,0x20(%r8)
  846b28:	0f 85 4a ff ff ff    	jne    846a78 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846b2e:	44 8b 79 2c          	mov    0x2c(%rcx),%r15d
  846b32:	45 39 78 24          	cmp    %r15d,0x24(%r8)
  846b36:	0f 85 3c ff ff ff    	jne    846a78 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846b3c:	41 8b 68 38          	mov    0x38(%r8),%ebp
  846b40:	3b 6a 28             	cmp    0x28(%rdx),%ebp
  846b43:	0f 85 2f ff ff ff    	jne    846a78 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846b49:	83 fd 4c             	cmp    $0x4c,%ebp
  846b4c:	75 23                	jne    846b71 <<gpui_gpu::renderer::RendererState>::render+0x1e1>
  846b4e:	f3 41 0f 7e 40 3c    	movq   0x3c(%r8),%xmm0
  846b54:	f3 0f 7e 4a 2c       	movq   0x2c(%rdx),%xmm1
  846b59:	66 0f 76 c8          	pcmpeqd %xmm0,%xmm1
  846b5d:	66 0f 70 c1 50       	pshufd $0x50,%xmm1,%xmm0
  846b62:	66 44 0f 50 c8       	movmskpd %xmm0,%r9d
  846b67:	41 83 f9 03          	cmp    $0x3,%r9d
  846b6b:	0f 85 07 ff ff ff    	jne    846a78 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846b71:	41 81 ff 00 40 00 00 	cmp    $0x4000,%r15d
  846b78:	77 34                	ja     846bae <<gpui_gpu::renderer::RendererState>::render+0x21e>
  846b7a:	41 81 fe 00 40 00 00 	cmp    $0x4000,%r14d
  846b81:	77 2b                	ja     846bae <<gpui_gpu::renderer::RendererState>::render+0x21e>
  846b83:	4d 89 f9             	mov    %r15,%r9
  846b86:	4d 0f af ce          	imul   %r14,%r9
  846b8a:	49 81 c1 ff ff ff fe 	add    $0xfffffffffeffffff,%r9
  846b91:	49 81 f9 00 00 00 ff 	cmp    $0xffffffffff000000,%r9
  846b98:	72 14                	jb     846bae <<gpui_gpu::renderer::RendererState>::render+0x21e>
  846b9a:	4c 8b 59 10          	mov    0x10(%rcx),%r11
  846b9e:	4d 8b 93 80 00 00 00 	mov    0x80(%r11),%r10
  846ba5:	49 81 fa 00 00 01 00 	cmp    $0x10000,%r10
  846bac:	76 0b                	jbe    846bb9 <<gpui_gpu::renderer::RendererState>::render+0x229>
  846bae:	c7 07 06 00 00 00    	movl   $0x6,(%rdi)
  846bb4:	e9 cd fe ff ff       	jmp    846a86 <<gpui_gpu::renderer::RendererState>::render+0xf6>
  846bb9:	66 0f 6e 41 18       	movd   0x18(%rcx),%xmm0
  846bbe:	66 41 0f 7e c1       	movd   %xmm0,%r9d
  846bc3:	41 81 e1 ff ff ff 7f 	and    $0x7fffffff,%r9d
  846bca:	41 81 f9 ff ff 7f 7f 	cmp    $0x7f7fffff,%r9d
  846bd1:	0f 8f a1 fe ff ff    	jg     846a78 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846bd7:	66 0f db 05 f1 d1 88 	pand   -0x772e0f(%rip),%xmm0        # d3dd0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x490>
  846bde:	ff 
  846bdf:	0f 2e 05 b2 a2 88 ff 	ucomiss -0x775d4e(%rip),%xmm0        # d0e98 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x28>
  846be6:	0f 87 8c fe ff ff    	ja     846a78 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846bec:	66 0f 6e 41 1c       	movd   0x1c(%rcx),%xmm0
  846bf1:	66 41 0f 7e c1       	movd   %xmm0,%r9d
  846bf6:	41 81 e1 ff ff ff 7f 	and    $0x7fffffff,%r9d
  846bfd:	41 81 f9 ff ff 7f 7f 	cmp    $0x7f7fffff,%r9d
  846c04:	0f 8f 6e fe ff ff    	jg     846a78 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846c0a:	66 0f db 05 be d1 88 	pand   -0x772e42(%rip),%xmm0        # d3dd0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x490>
  846c11:	ff 
  846c12:	0f 2e 05 7f a2 88 ff 	ucomiss -0x775d81(%rip),%xmm0        # d0e98 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x28>
  846c19:	0f 87 59 fe ff ff    	ja     846a78 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846c1f:	66 0f 6e 41 20       	movd   0x20(%rcx),%xmm0
  846c24:	66 41 0f 7e c1       	movd   %xmm0,%r9d
  846c29:	41 81 e1 ff ff ff 7f 	and    $0x7fffffff,%r9d
  846c30:	41 81 f9 ff ff 7f 7f 	cmp    $0x7f7fffff,%r9d
  846c37:	0f 8f 3b fe ff ff    	jg     846a78 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846c3d:	66 0f db 05 8b d1 88 	pand   -0x772e75(%rip),%xmm0        # d3dd0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x490>
  846c44:	ff 
  846c45:	0f 2e 05 4c a2 88 ff 	ucomiss -0x775db4(%rip),%xmm0        # d0e98 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x28>
  846c4c:	0f 87 26 fe ff ff    	ja     846a78 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846c52:	66 0f 6e 41 24       	movd   0x24(%rcx),%xmm0
  846c57:	66 41 0f 7e c1       	movd   %xmm0,%r9d
  846c5c:	41 81 e1 ff ff ff 7f 	and    $0x7fffffff,%r9d
  846c63:	41 81 f9 ff ff 7f 7f 	cmp    $0x7f7fffff,%r9d
  846c6a:	0f 8f 08 fe ff ff    	jg     846a78 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846c70:	66 0f 6f 0d 58 d1 88 	movdqa -0x772ea8(%rip),%xmm1        # d3dd0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x490>
  846c77:	ff 
  846c78:	66 0f db c8          	pand   %xmm0,%xmm1
  846c7c:	0f 2e 0d 15 a2 88 ff 	ucomiss -0x775deb(%rip),%xmm1        # d0e98 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x28>
  846c83:	0f 87 ef fd ff ff    	ja     846a78 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846c89:	0f 57 c9             	xorps  %xmm1,%xmm1
  846c8c:	0f 2e c1             	ucomiss %xmm1,%xmm0
  846c8f:	0f 82 e3 fd ff ff    	jb     846a78 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846c95:	f3 0f 10 0d 77 9e 88 	movss  -0x776189(%rip),%xmm1        # d0b14 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x10>
  846c9c:	ff 
  846c9d:	0f 2e c8             	ucomiss %xmm0,%xmm1
  846ca0:	0f 82 d2 fd ff ff    	jb     846a78 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846ca6:	44 0f b7 49 30       	movzwl 0x30(%rcx),%r9d
  846cab:	66 44 89 4c 24 10    	mov    %r9w,0x10(%rsp)
  846cb1:	44 0f b7 49 32       	movzwl 0x32(%rcx),%r9d
  846cb6:	66 44 89 4c 24 18    	mov    %r9w,0x18(%rsp)
  846cbc:	83 fd 28             	cmp    $0x28,%ebp
  846cbf:	75 09                	jne    846cca <<gpui_gpu::renderer::RendererState>::render+0x33a>
  846cc1:	a8 01                	test   $0x1,%al
  846cc3:	75 20                	jne    846ce5 <<gpui_gpu::renderer::RendererState>::render+0x355>
  846cc5:	e9 ae fd ff ff       	jmp    846a78 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846cca:	a8 01                	test   $0x1,%al
  846ccc:	0f 85 a6 fd ff ff    	jne    846a78 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846cd2:	0f 2e 05 3b 9e 88 ff 	ucomiss -0x7761c5(%rip),%xmm0        # d0b14 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x10>
  846cd9:	0f 85 99 fd ff ff    	jne    846a78 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846cdf:	0f 8a 93 fd ff ff    	jp     846a78 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846ce5:	4c 89 9c 24 b8 00 00 	mov    %r11,0xb8(%rsp)
  846cec:	00 
  846ced:	4c 89 94 24 b0 00 00 	mov    %r10,0xb0(%rsp)
  846cf4:	00 
  846cf5:	f3 0f 11 8c 24 ec 00 	movss  %xmm1,0xec(%rsp)
  846cfc:	00 00 
  846cfe:	66 0f 7e 94 24 5c 01 	movd   %xmm2,0x15c(%rsp)
  846d05:	00 00 
  846d07:	48 89 94 24 50 01 00 	mov    %rdx,0x150(%rsp)
  846d0e:	00 
  846d0f:	4c 89 84 24 00 04 00 	mov    %r8,0x400(%rsp)
  846d16:	00 
  846d17:	48 89 7c 24 40       	mov    %rdi,0x40(%rsp)
  846d1c:	49 8d 46 0f          	lea    0xf(%r14),%rax
  846d20:	48 c1 e8 04          	shr    $0x4,%rax
  846d24:	41 8d 57 0f          	lea    0xf(%r15),%edx
  846d28:	c1 ea 04             	shr    $0x4,%edx
  846d2b:	48 8d 7e 18          	lea    0x18(%rsi),%rdi
  846d2f:	48 c7 46 28 00 00 00 	movq   $0x0,0x28(%rsi)
  846d36:	00 
  846d37:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  846d3c:	0f af d0             	imul   %eax,%edx
  846d3f:	48 89 bc 24 98 00 00 	mov    %rdi,0x98(%rsp)
  846d46:	00 
  846d47:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
  846d4c:	48 89 54 24 48       	mov    %rdx,0x48(%rsp)
  846d51:	48 89 d6             	mov    %rdx,%rsi
  846d54:	31 d2                	xor    %edx,%edx
  846d56:	48 89 8c 24 90 00 00 	mov    %rcx,0x90(%rsp)
  846d5d:	00 
  846d5e:	e8 9d 43 00 00       	call   84b100 <<alloc::vec::Vec<[u32; 2]>>::resize>
  846d63:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  846d68:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
  846d6f:	00 
  846d70:	48 8b bc 24 90 00 00 	mov    0x90(%rsp),%rdi
  846d77:	00 
  846d78:	ff 15 b2 87 67 00    	call   *0x6787b2(%rip)        # ebf530 <_DYNAMIC+0x808>
  846d7e:	48 89 d1             	mov    %rdx,%rcx
  846d81:	48 29 c1             	sub    %rax,%rcx
  846d84:	48 81 f9 00 00 30 00 	cmp    $0x300000,%rcx
  846d8b:	76 10                	jbe    846d9d <<gpui_gpu::renderer::RendererState>::render+0x40d>
  846d8d:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  846d92:	c7 07 06 00 00 00    	movl   $0x6,(%rdi)
  846d98:	e9 e9 fc ff ff       	jmp    846a86 <<gpui_gpu::renderer::RendererState>::render+0xf6>
  846d9d:	48 89 ce             	mov    %rcx,%rsi
  846da0:	48 c1 e9 03          	shr    $0x3,%rcx
  846da4:	48 bf ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rdi
  846dab:	aa aa aa 
  846dae:	48 0f af f9          	imul   %rcx,%rdi
  846db2:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
  846db7:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
  846dbe:	00 
  846dbf:	48 89 94 24 b0 03 00 	mov    %rdx,0x3b0(%rsp)
  846dc6:	00 
  846dc7:	48 39 c2             	cmp    %rax,%rdx
  846dca:	74 2f                	je     846dfb <<gpui_gpu::renderer::RendererState>::render+0x46b>
  846dcc:	b8 ab aa aa aa       	mov    $0xaaaaaaab,%eax
  846dd1:	48 0f af f0          	imul   %rax,%rsi
  846dd5:	48 c1 ee 2a          	shr    $0x2a,%rsi
  846dd9:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  846dde:	89 c8                	mov    %ecx,%eax
  846de0:	83 e0 3f             	and    $0x3f,%eax
  846de3:	48 01 ce             	add    %rcx,%rsi
  846de6:	48 83 f8 01          	cmp    $0x1,%rax
  846dea:	48 83 de ff          	sbb    $0xffffffffffffffff,%rsi
  846dee:	48 ff c6             	inc    %rsi
  846df1:	48 89 b4 24 e0 00 00 	mov    %rsi,0xe0(%rsp)
  846df8:	00 
  846df9:	eb 0c                	jmp    846e07 <<gpui_gpu::renderer::RendererState>::render+0x477>
  846dfb:	48 c7 84 24 e0 00 00 	movq   $0x0,0xe0(%rsp)
  846e02:	00 00 00 00 00 
  846e07:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  846e0e:	00 
  846e0f:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
  846e16:	48 03 88 b0 00 00 00 	add    0xb0(%rax),%rcx
  846e1d:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
  846e24:	00 
  846e25:	0f b7 44 24 10       	movzwl 0x10(%rsp),%eax
  846e2a:	66 89 84 24 80 01 00 	mov    %ax,0x180(%rsp)
  846e31:	00 
  846e32:	0f b7 44 24 18       	movzwl 0x18(%rsp),%eax
  846e37:	66 89 84 24 82 01 00 	mov    %ax,0x182(%rsp)
  846e3e:	00 
  846e3f:	48 c7 84 24 68 01 00 	movq   $0x0,0x168(%rsp)
  846e46:	00 00 00 00 00 
  846e4b:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
  846e52:	00 
  846e53:	48 89 84 24 70 01 00 	mov    %rax,0x170(%rsp)
  846e5a:	00 
  846e5b:	48 89 8c 24 48 01 00 	mov    %rcx,0x148(%rsp)
  846e62:	00 
  846e63:	48 89 8c 24 78 01 00 	mov    %rcx,0x178(%rsp)
  846e6a:	00 
  846e6b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  846e70:	0f b6 90 41 03 00 00 	movzbl 0x341(%rax),%edx
  846e77:	48 8d bc 24 48 04 00 	lea    0x448(%rsp),%rdi
  846e7e:	00 
  846e7f:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
  846e86:	00 
  846e87:	e8 74 e1 ff ff       	call   845000 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>>
  846e8c:	8b 84 24 48 04 00 00 	mov    0x448(%rsp),%eax
  846e93:	83 f8 ff             	cmp    $0xffffffff,%eax
  846e96:	74 2e                	je     846ec6 <<gpui_gpu::renderer::RendererState>::render+0x536>
  846e98:	8b 8c 24 4c 04 00 00 	mov    0x44c(%rsp),%ecx
  846e9f:	48 8b 94 24 50 04 00 	mov    0x450(%rsp),%rdx
  846ea6:	00 
  846ea7:	0f 10 84 24 58 04 00 	movups 0x458(%rsp),%xmm0
  846eae:	00 
  846eaf:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  846eb4:	0f 11 47 10          	movups %xmm0,0x10(%rdi)
  846eb8:	89 07                	mov    %eax,(%rdi)
  846eba:	89 4f 04             	mov    %ecx,0x4(%rdi)
  846ebd:	48 89 57 08          	mov    %rdx,0x8(%rdi)
  846ec1:	e9 c0 fb ff ff       	jmp    846a86 <<gpui_gpu::renderer::RendererState>::render+0xf6>
  846ec6:	48 8b 94 24 50 04 00 	mov    0x450(%rsp),%rdx
  846ecd:	00 
  846ece:	48 03 94 24 e0 00 00 	add    0xe0(%rsp),%rdx
  846ed5:	00 
  846ed6:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  846edb:	48 8b 77 10          	mov    0x10(%rdi),%rsi
  846edf:	b9 04 00 00 00       	mov    $0x4,%ecx
  846ee4:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  846eea:	e8 d1 55 00 00       	call   84c4c0 <<alloc::raw_vec::RawVecInner>::try_reserve_exact>
  846eef:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  846ef3:	0f 85 94 fe ff ff    	jne    846d8d <<gpui_gpu::renderer::RendererState>::render+0x3fd>
  846ef9:	0f b7 44 24 10       	movzwl 0x10(%rsp),%eax
  846efe:	89 44 24 10          	mov    %eax,0x10(%rsp)
  846f02:	0f b7 44 24 18       	movzwl 0x18(%rsp),%eax
  846f07:	89 44 24 78          	mov    %eax,0x78(%rsp)
  846f0b:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  846f10:	48 8b b4 24 90 00 00 	mov    0x90(%rsp),%rsi
  846f17:	00 
  846f18:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
  846f1d:	e8 fe 74 00 00       	call   84e420 <gpui_gpu::renderer::slots::write_prefix>
  846f22:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  846f27:	48 8d 78 48          	lea    0x48(%rax),%rdi
  846f2b:	48 c7 40 58 00 00 00 	movq   $0x0,0x58(%rax)
  846f32:	00 
  846f33:	48 89 bc 24 08 04 00 	mov    %rdi,0x408(%rsp)
  846f3a:	00 
  846f3b:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
  846f40:	31 d2                	xor    %edx,%edx
  846f42:	e8 d9 42 00 00       	call   84b220 <<alloc::vec::Vec<u32>>::resize>
  846f47:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  846f4c:	48 c7 40 70 00 00 00 	movq   $0x0,0x70(%rax)
  846f53:	00 
  846f54:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
  846f59:	75 0f                	jne    846f6a <<gpui_gpu::renderer::RendererState>::render+0x5da>
  846f5b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  846f60:	48 8d 78 60          	lea    0x60(%rax),%rdi
  846f64:	ff 15 ce 85 67 00    	call   *0x6785ce(%rip)        # ebf538 <_DYNAMIC+0x810>
  846f6a:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  846f6f:	48 8b 48 68          	mov    0x68(%rax),%rcx
  846f73:	0f 57 c0             	xorps  %xmm0,%xmm0
  846f76:	0f 11 41 10          	movups %xmm0,0x10(%rcx)
  846f7a:	0f 11 01             	movups %xmm0,(%rcx)
  846f7d:	48 c7 40 70 01 00 00 	movq   $0x1,0x70(%rax)
  846f84:	00 
  846f85:	48 8d b8 f0 02 00 00 	lea    0x2f0(%rax),%rdi
  846f8c:	e8 3f 6e 00 00       	call   84ddd0 <<hashbrown::raw::RawTable<([u32; 8], u32)>>::clear>
  846f91:	8b 4c 24 78          	mov    0x78(%rsp),%ecx
  846f95:	c1 e1 10             	shl    $0x10,%ecx
  846f98:	03 4c 24 10          	add    0x10(%rsp),%ecx
  846f9c:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  846fa3:	00 
  846fa4:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
  846fab:	00 
  846fac:	48 c7 84 24 f0 02 00 	movq   $0x0,0x2f0(%rsp)
  846fb3:	00 00 00 00 00 
  846fb8:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
  846fbf:	00 
  846fc0:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
  846fc7:	00 
  846fc8:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  846fcf:	00 
  846fd0:	48 89 84 24 00 03 00 	mov    %rax,0x300(%rsp)
  846fd7:	00 
  846fd8:	89 4c 24 78          	mov    %ecx,0x78(%rsp)
  846fdc:	89 8c 24 08 03 00 00 	mov    %ecx,0x308(%rsp)
  846fe3:	48 8d bc 24 58 02 00 	lea    0x258(%rsp),%rdi
  846fea:	00 
  846feb:	48 8d b4 24 e8 02 00 	lea    0x2e8(%rsp),%rsi
  846ff2:	00 
  846ff3:	ff 15 47 85 67 00    	call   *0x678547(%rip)        # ebf540 <_DYNAMIC+0x818>
  846ff9:	48 8b 84 24 58 02 00 	mov    0x258(%rsp),%rax
  847000:	00 
  847001:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  847006:	48 85 c0             	test   %rax,%rax
  847009:	0f 84 31 0d 00 00    	je     847d40 <<gpui_gpu::renderer::RendererState>::render+0x13b0>
  84700f:	48 c7 84 24 d8 00 00 	movq   $0x0,0xd8(%rsp)
  847016:	00 00 00 00 00 
  84701b:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  847022:	00 00 
  847024:	48 c7 44 24 48 00 00 	movq   $0x0,0x48(%rsp)
  84702b:	00 00 
  84702d:	48 c7 84 24 38 01 00 	movq   $0x0,0x138(%rsp)
  847034:	00 00 00 00 00 
  847039:	48 c7 84 24 40 01 00 	movq   $0x0,0x140(%rsp)
  847040:	00 00 00 00 00 
  847045:	48 8b 8c 24 60 02 00 	mov    0x260(%rsp),%rcx
  84704c:	00 
  84704d:	48 8b 94 24 68 02 00 	mov    0x268(%rsp),%rdx
  847054:	00 
  847055:	48 89 94 24 a0 00 00 	mov    %rdx,0xa0(%rsp)
  84705c:	00 
  84705d:	48 8d bc 24 70 02 00 	lea    0x270(%rsp),%rdi
  847064:	00 
  847065:	0f 10 07             	movups (%rdi),%xmm0
  847068:	0f 10 4f 10          	movups 0x10(%rdi),%xmm1
  84706c:	0f 10 57 20          	movups 0x20(%rdi),%xmm2
  847070:	0f 29 94 24 30 03 00 	movaps %xmm2,0x330(%rsp)
  847077:	00 
  847078:	0f 29 8c 24 20 03 00 	movaps %xmm1,0x320(%rsp)
  84707f:	00 
  847080:	0f 29 84 24 10 03 00 	movaps %xmm0,0x310(%rsp)
  847087:	00 
  847088:	4c 8d 84 24 a0 02 00 	lea    0x2a0(%rsp),%r8
  84708f:	00 
  847090:	41 0f 10 00          	movups (%r8),%xmm0
  847094:	0f 29 84 24 10 05 00 	movaps %xmm0,0x510(%rsp)
  84709b:	00 
  84709c:	0f 10 47 40          	movups 0x40(%rdi),%xmm0
  8470a0:	0f 29 84 24 30 04 00 	movaps %xmm0,0x430(%rsp)
  8470a7:	00 
  8470a8:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  8470ad:	0f b6 b0 41 03 00 00 	movzbl 0x341(%rax),%esi
  8470b4:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  8470b9:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
  8470c0:	00 
  8470c1:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  8470c6:	48 89 8c 24 68 01 00 	mov    %rcx,0x168(%rsp)
  8470cd:	00 
  8470ce:	48 89 94 24 70 01 00 	mov    %rdx,0x170(%rsp)
  8470d5:	00 
  8470d6:	0f 10 07             	movups (%rdi),%xmm0
  8470d9:	0f 10 4f 10          	movups 0x10(%rdi),%xmm1
  8470dd:	0f 10 57 20          	movups 0x20(%rdi),%xmm2
  8470e1:	48 8d 84 24 78 01 00 	lea    0x178(%rsp),%rax
  8470e8:	00 
  8470e9:	0f 11 50 20          	movups %xmm2,0x20(%rax)
  8470ed:	0f 11 48 10          	movups %xmm1,0x10(%rax)
  8470f1:	0f 11 00             	movups %xmm0,(%rax)
  8470f4:	41 0f 10 00          	movups (%r8),%xmm0
  8470f8:	0f 11 40 30          	movups %xmm0,0x30(%rax)
  8470fc:	0f 10 47 40          	movups 0x40(%rdi),%xmm0
  847100:	0f 11 40 40          	movups %xmm0,0x40(%rax)
  847104:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  84710b:	00 
  84710c:	e8 4f 2d 00 00       	call   849e60 <gpui_gpu::renderer::compact_group>
  847111:	88 44 24 60          	mov    %al,0x60(%rsp)
  847115:	48 8d b4 24 70 02 00 	lea    0x270(%rsp),%rsi
  84711c:	00 
  84711d:	0f 10 06             	movups (%rsi),%xmm0
  847120:	0f 10 4e 10          	movups 0x10(%rsi),%xmm1
  847124:	0f 10 56 20          	movups 0x20(%rsi),%xmm2
  847128:	0f 29 84 24 20 05 00 	movaps %xmm0,0x520(%rsp)
  84712f:	00 
  847130:	0f 29 8c 24 30 05 00 	movaps %xmm1,0x530(%rsp)
  847137:	00 
  847138:	0f 29 94 24 40 05 00 	movaps %xmm2,0x540(%rsp)
  84713f:	00 
  847140:	48 8d 94 24 a0 02 00 	lea    0x2a0(%rsp),%rdx
  847147:	00 
  847148:	0f 10 02             	movups (%rdx),%xmm0
  84714b:	0f 29 84 24 50 05 00 	movaps %xmm0,0x550(%rsp)
  847152:	00 
  847153:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  847158:	e8 b3 ea ff ff       	call   845c10 <<gpui_gpu::renderer::RendererState>::correction>
  84715d:	89 44 24 7c          	mov    %eax,0x7c(%rsp)
  847161:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  847168:	00 
  847169:	48 8d 04 85 00 00 00 	lea    0x0(,%rax,4),%rax
  847170:	00 
  847171:	48 89 84 24 e0 03 00 	mov    %rax,0x3e0(%rsp)
  847178:	00 
  847179:	80 7c 24 60 00       	cmpb   $0x0,0x60(%rsp)
  84717e:	0f 84 d5 01 00 00    	je     847359 <<gpui_gpu::renderer::RendererState>::render+0x9c9>
  847184:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
  847189:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  847190:	00 
  847191:	48 8d 04 81          	lea    (%rcx,%rax,4),%rax
  847195:	48 89 8c 24 10 04 00 	mov    %rcx,0x410(%rsp)
  84719c:	00 
  84719d:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
  8471a4:	00 
  8471a5:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  8471aa:	48 89 84 24 20 04 00 	mov    %rax,0x420(%rsp)
  8471b1:	00 
  8471b2:	48 c7 84 24 28 04 00 	movq   $0x0,0x428(%rsp)
  8471b9:	00 00 00 00 00 
  8471be:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
  8471c5:	00 
  8471c6:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
  8471cd:	00 
  8471ce:	e8 1d 33 00 00       	call   84a4f0 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  8471d3:	80 bc 24 48 03 00 00 	cmpb   $0xff,0x348(%rsp)
  8471da:	ff 
  8471db:	0f 84 b1 06 00 00    	je     847892 <<gpui_gpu::renderer::RendererState>::render+0xf02>
  8471e1:	0f 57 c0             	xorps  %xmm0,%xmm0
  8471e4:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
  8471eb:	00 
  8471ec:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
  8471f1:	48 8b 94 24 40 03 00 	mov    0x340(%rsp),%rdx
  8471f8:	00 
  8471f9:	48 03 54 24 48       	add    0x48(%rsp),%rdx
  8471fe:	48 8d b4 24 48 03 00 	lea    0x348(%rsp),%rsi
  847205:	00 
  847206:	0f 10 46 38          	movups 0x38(%rsi),%xmm0
  84720a:	48 8d 8c 24 78 01 00 	lea    0x178(%rsp),%rcx
  847211:	00 
  847212:	0f 11 41 20          	movups %xmm0,0x20(%rcx)
  847216:	0f 10 46 48          	movups 0x48(%rsi),%xmm0
  84721a:	0f 11 41 70          	movups %xmm0,0x70(%rcx)
  84721e:	48 8b 46 30          	mov    0x30(%rsi),%rax
  847222:	48 89 84 24 90 01 00 	mov    %rax,0x190(%rsp)
  847229:	00 
  84722a:	0f 10 06             	movups (%rsi),%xmm0
  84722d:	0f 10 4e 10          	movups 0x10(%rsi),%xmm1
  847231:	0f 10 56 20          	movups 0x20(%rsi),%xmm2
  847235:	0f 29 94 24 80 01 00 	movaps %xmm2,0x180(%rsp)
  84723c:	00 
  84723d:	0f 29 8c 24 70 01 00 	movaps %xmm1,0x170(%rsp)
  847244:	00 
  847245:	0f 29 84 24 60 01 00 	movaps %xmm0,0x160(%rsp)
  84724c:	00 
  84724d:	48 8d 84 24 70 02 00 	lea    0x270(%rsp),%rax
  847254:	00 
  847255:	0f 10 40 40          	movups 0x40(%rax),%xmm0
  847259:	0f 11 81 80 00 00 00 	movups %xmm0,0x80(%rcx)
  847260:	0f 10 00             	movups (%rax),%xmm0
  847263:	0f 10 48 10          	movups 0x10(%rax),%xmm1
  847267:	0f 10 50 20          	movups 0x20(%rax),%xmm2
  84726b:	0f 11 51 50          	movups %xmm2,0x50(%rcx)
  84726f:	0f 11 49 40          	movups %xmm1,0x40(%rcx)
  847273:	0f 11 41 30          	movups %xmm0,0x30(%rcx)
  847277:	48 8d 84 24 a0 02 00 	lea    0x2a0(%rsp),%rax
  84727e:	00 
  84727f:	0f 10 00             	movups (%rax),%xmm0
  847282:	0f 11 41 60          	movups %xmm0,0x60(%rcx)
  847286:	48 8d bc 24 00 01 00 	lea    0x100(%rsp),%rdi
  84728d:	00 
  84728e:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
  847295:	00 
  847296:	44 89 f1             	mov    %r14d,%ecx
  847299:	45 89 f8             	mov    %r15d,%r8d
  84729c:	e8 0f 2c 00 00       	call   849eb0 <gpui_gpu::renderer::validate_draw>
  8472a1:	8b 8c 24 00 01 00 00 	mov    0x100(%rsp),%ecx
  8472a8:	48 8b 84 24 04 01 00 	mov    0x104(%rsp),%rax
  8472af:	00 
  8472b0:	83 f9 ff             	cmp    $0xffffffff,%ecx
  8472b3:	0f 85 3f 0b 00 00    	jne    847df8 <<gpui_gpu::renderer::RendererState>::render+0x1468>
  8472b9:	89 c1                	mov    %eax,%ecx
  8472bb:	48 c1 e8 20          	shr    $0x20,%rax
  8472bf:	66 0f 6e c1          	movd   %ecx,%xmm0
  8472c3:	0f 28 94 24 c0 00 00 	movaps 0xc0(%rsp),%xmm2
  8472ca:	00 
  8472cb:	0f 28 ca             	movaps %xmm2,%xmm1
  8472ce:	f3 0f 5f c8          	maxss  %xmm0,%xmm1
  8472d2:	0f 28 d9             	movaps %xmm1,%xmm3
  8472d5:	f3 0f c2 d9 03       	cmpunordss %xmm1,%xmm3
  8472da:	0f 28 c3             	movaps %xmm3,%xmm0
  8472dd:	0f 55 c1             	andnps %xmm1,%xmm0
  8472e0:	0f 54 da             	andps  %xmm2,%xmm3
  8472e3:	0f 56 d8             	orps   %xmm0,%xmm3
  8472e6:	0f 29 5c 24 60       	movaps %xmm3,0x60(%rsp)
  8472eb:	66 0f 6e c0          	movd   %eax,%xmm0
  8472ef:	0f 28 54 24 50       	movaps 0x50(%rsp),%xmm2
  8472f4:	0f 28 ca             	movaps %xmm2,%xmm1
  8472f7:	f3 0f 5f c8          	maxss  %xmm0,%xmm1
  8472fb:	0f 28 d9             	movaps %xmm1,%xmm3
  8472fe:	f3 0f c2 d9 03       	cmpunordss %xmm1,%xmm3
  847303:	0f 28 c3             	movaps %xmm3,%xmm0
  847306:	0f 55 c1             	andnps %xmm1,%xmm0
  847309:	0f 54 da             	andps  %xmm2,%xmm3
  84730c:	0f 56 d8             	orps   %xmm0,%xmm3
  84730f:	0f 29 9c 24 80 00 00 	movaps %xmm3,0x80(%rsp)
  847316:	00 
  847317:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
  84731e:	00 
  84731f:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
  847326:	00 
  847327:	e8 c4 31 00 00       	call   84a4f0 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  84732c:	80 bc 24 48 03 00 00 	cmpb   $0xff,0x348(%rsp)
  847333:	ff 
  847334:	0f 28 44 24 60       	movaps 0x60(%rsp),%xmm0
  847339:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
  847340:	00 
  847341:	0f 28 84 24 80 00 00 	movaps 0x80(%rsp),%xmm0
  847348:	00 
  847349:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
  84734e:	0f 85 9d fe ff ff    	jne    8471f1 <<gpui_gpu::renderer::RendererState>::render+0x861>
  847354:	e9 49 05 00 00       	jmp    8478a2 <<gpui_gpu::renderer::RendererState>::render+0xf12>
  847359:	48 83 bc 24 a0 00 00 	cmpq   $0x0,0xa0(%rsp)
  847360:	00 00 
  847362:	0f 84 82 09 00 00    	je     847cea <<gpui_gpu::renderer::RendererState>::render+0x135a>
  847368:	8b 44 24 7c          	mov    0x7c(%rsp),%eax
  84736c:	0d 00 00 00 80       	or     $0x80000000,%eax
  847371:	89 84 24 58 01 00 00 	mov    %eax,0x158(%rsp)
  847378:	48 c7 84 24 80 00 00 	movq   $0x0,0x80(%rsp)
  84737f:	00 00 00 00 00 
  847384:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  847389:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
  847390:	00 
  847391:	8b 14 08             	mov    (%rax,%rcx,1),%edx
  847394:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  84739b:	00 
  84739c:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  8473a1:	e8 aa dd ff ff       	call   845150 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  8473a6:	0f b6 bc 24 60 01 00 	movzbl 0x160(%rsp),%edi
  8473ad:	00 
  8473ae:	48 8d 94 24 61 01 00 	lea    0x161(%rsp),%rdx
  8473b5:	00 
  8473b6:	8b 02                	mov    (%rdx),%eax
  8473b8:	8b 4a 03             	mov    0x3(%rdx),%ecx
  8473bb:	48 8d b4 24 80 04 00 	lea    0x480(%rsp),%rsi
  8473c2:	00 
  8473c3:	89 4e cc             	mov    %ecx,-0x34(%rsi)
  8473c6:	89 46 c9             	mov    %eax,-0x37(%rsi)
  8473c9:	48 8b 8c 24 68 01 00 	mov    0x168(%rsp),%rcx
  8473d0:	00 
  8473d1:	48 8b 42 2f          	mov    0x2f(%rdx),%rax
  8473d5:	48 89 46 f8          	mov    %rax,-0x8(%rsi)
  8473d9:	0f 10 42 0f          	movups 0xf(%rdx),%xmm0
  8473dd:	0f 10 4a 1f          	movups 0x1f(%rdx),%xmm1
  8473e1:	0f 11 4e e8          	movups %xmm1,-0x18(%rsi)
  8473e5:	0f 11 46 d8          	movups %xmm0,-0x28(%rsi)
  8473e9:	48 8d 84 24 78 01 00 	lea    0x178(%rsp),%rax
  8473f0:	00 
  8473f1:	0f 10 40 20          	movups 0x20(%rax),%xmm0
  8473f5:	0f 11 06             	movups %xmm0,(%rsi)
  8473f8:	0f 10 40 30          	movups 0x30(%rax),%xmm0
  8473fc:	0f 11 46 50          	movups %xmm0,0x50(%rsi)
  847400:	48 8d 84 24 70 02 00 	lea    0x270(%rsp),%rax
  847407:	00 
  847408:	0f 10 40 40          	movups 0x40(%rax),%xmm0
  84740c:	0f 11 46 60          	movups %xmm0,0x60(%rsi)
  847410:	0f 10 00             	movups (%rax),%xmm0
  847413:	0f 10 48 10          	movups 0x10(%rax),%xmm1
  847417:	0f 10 50 20          	movups 0x20(%rax),%xmm2
  84741b:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
  84741f:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
  847423:	0f 11 46 10          	movups %xmm0,0x10(%rsi)
  847427:	48 8d 84 24 a0 02 00 	lea    0x2a0(%rsp),%rax
  84742e:	00 
  84742f:	0f 10 00             	movups (%rax),%xmm0
  847432:	0f 11 46 40          	movups %xmm0,0x40(%rsi)
  847436:	40 88 7c 24 50       	mov    %dil,0x50(%rsp)
  84743b:	40 88 bc 24 48 04 00 	mov    %dil,0x448(%rsp)
  847442:	00 
  847443:	48 89 8c 24 c0 00 00 	mov    %rcx,0xc0(%rsp)
  84744a:	00 
  84744b:	48 89 8c 24 50 04 00 	mov    %rcx,0x450(%rsp)
  847452:	00 
  847453:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  84745a:	00 
  84745b:	48 8d b4 24 48 04 00 	lea    0x448(%rsp),%rsi
  847462:	00 
  847463:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
  847468:	44 89 f1             	mov    %r14d,%ecx
  84746b:	45 89 f8             	mov    %r15d,%r8d
  84746e:	e8 3d 2a 00 00       	call   849eb0 <gpui_gpu::renderer::validate_draw>
  847473:	8b 84 24 60 01 00 00 	mov    0x160(%rsp),%eax
  84747a:	48 8b 8c 24 64 01 00 	mov    0x164(%rsp),%rcx
  847481:	00 
  847482:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
  847487:	83 f8 ff             	cmp    $0xffffffff,%eax
  84748a:	0f 85 fe 09 00 00    	jne    847e8e <<gpui_gpu::renderer::RendererState>::render+0x14fe>
  847490:	0f b6 44 24 50       	movzbl 0x50(%rsp),%eax
  847495:	3c 02                	cmp    $0x2,%al
  847497:	0f 94 44 24 2f       	sete   0x2f(%rsp)
  84749c:	48 83 bc 24 c0 00 00 	cmpq   $0x0,0xc0(%rsp)
  8474a3:	00 00 
  8474a5:	0f 95 44 24 2e       	setne  0x2e(%rsp)
  8474aa:	0f 10 84 24 80 04 00 	movups 0x480(%rsp),%xmm0
  8474b1:	00 
  8474b2:	0f 29 84 24 d0 02 00 	movaps %xmm0,0x2d0(%rsp)
  8474b9:	00 
  8474ba:	3c 03                	cmp    $0x3,%al
  8474bc:	0f 85 8c 00 00 00    	jne    84754e <<gpui_gpu::renderer::RendererState>::render+0xbbe>
  8474c2:	f3 0f 10 84 24 4c 04 	movss  0x44c(%rsp),%xmm0
  8474c9:	00 00 
  8474cb:	0f 57 c9             	xorps  %xmm1,%xmm1
  8474ce:	0f 2e c1             	ucomiss %xmm1,%xmm0
  8474d1:	75 02                	jne    8474d5 <<gpui_gpu::renderer::RendererState>::render+0xb45>
  8474d3:	7b 79                	jnp    84754e <<gpui_gpu::renderer::RendererState>::render+0xbbe>
  8474d5:	0f 28 ac 24 d0 02 00 	movaps 0x2d0(%rsp),%xmm5
  8474dc:	00 
  8474dd:	0f 28 cd             	movaps %xmm5,%xmm1
  8474e0:	66 0f 15 cd          	unpckhpd %xmm5,%xmm1
  8474e4:	f3 0f 10 25 10 98 88 	movss  -0x7767f0(%rip),%xmm4        # d0cfc <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x14>
  8474eb:	ff 
  8474ec:	f3 0f 59 cc          	mulss  %xmm4,%xmm1
  8474f0:	0f 28 d0             	movaps %xmm0,%xmm2
  8474f3:	f3 0f 5d d1          	minss  %xmm1,%xmm2
  8474f7:	0f 28 ca             	movaps %xmm2,%xmm1
  8474fa:	f3 0f c2 ca 03       	cmpunordss %xmm2,%xmm1
  8474ff:	0f 28 d9             	movaps %xmm1,%xmm3
  847502:	0f 55 da             	andnps %xmm2,%xmm3
  847505:	0f 54 c8             	andps  %xmm0,%xmm1
  847508:	0f 56 cb             	orps   %xmm3,%xmm1
  84750b:	0f 28 c5             	movaps %xmm5,%xmm0
  84750e:	0f c6 c5 ff          	shufps $0xff,%xmm5,%xmm0
  847512:	f3 0f 59 c4          	mulss  %xmm4,%xmm0
  847516:	0f 28 d1             	movaps %xmm1,%xmm2
  847519:	f3 0f 5d d0          	minss  %xmm0,%xmm2
  84751d:	0f 28 c2             	movaps %xmm2,%xmm0
  847520:	f3 0f c2 c2 03       	cmpunordss %xmm2,%xmm0
  847525:	0f 54 c8             	andps  %xmm0,%xmm1
  847528:	0f 55 c2             	andnps %xmm2,%xmm0
  84752b:	0f 56 c1             	orps   %xmm1,%xmm0
  84752e:	66 0f 7e c0          	movd   %xmm0,%eax
  847532:	89 44 24 50          	mov    %eax,0x50(%rsp)
  847536:	25 00 00 80 ff       	and    $0xff800000,%eax
  84753b:	b9 00 00 00 7f       	mov    $0x7f000000,%ecx
  847540:	29 c1                	sub    %eax,%ecx
  847542:	89 8c 24 c0 00 00 00 	mov    %ecx,0xc0(%rsp)
  847549:	0f 57 c0             	xorps  %xmm0,%xmm0
  84754c:	eb 22                	jmp    847570 <<gpui_gpu::renderer::RendererState>::render+0xbe0>
  84754e:	8b 84 24 e0 04 00 00 	mov    0x4e0(%rsp),%eax
  847555:	89 44 24 50          	mov    %eax,0x50(%rsp)
  847559:	8b 84 24 e4 04 00 00 	mov    0x4e4(%rsp),%eax
  847560:	89 84 24 c0 00 00 00 	mov    %eax,0xc0(%rsp)
  847567:	f2 0f 10 84 24 e8 04 	movsd  0x4e8(%rsp),%xmm0
  84756e:	00 00 
  847570:	0f 29 84 24 20 01 00 	movaps %xmm0,0x120(%rsp)
  847577:	00 
  847578:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  84757d:	8b 48 10             	mov    0x10(%rax),%ecx
  847580:	b8 00 00 00 80       	mov    $0x80000000,%eax
  847585:	09 c1                	or     %eax,%ecx
  847587:	89 8c 24 a0 03 00 00 	mov    %ecx,0x3a0(%rsp)
  84758e:	0f 10 84 24 90 04 00 	movups 0x490(%rsp),%xmm0
  847595:	00 
  847596:	0f 29 84 24 d0 03 00 	movaps %xmm0,0x3d0(%rsp)
  84759d:	00 
  84759e:	0f 10 84 24 98 04 00 	movups 0x498(%rsp),%xmm0
  8475a5:	00 
  8475a6:	0f 29 84 24 00 05 00 	movaps %xmm0,0x500(%rsp)
  8475ad:	00 
  8475ae:	f2 0f 10 84 24 a0 04 	movsd  0x4a0(%rsp),%xmm0
  8475b5:	00 00 
  8475b7:	0f 29 84 24 c0 03 00 	movaps %xmm0,0x3c0(%rsp)
  8475be:	00 
  8475bf:	f2 0f 10 84 24 a8 04 	movsd  0x4a8(%rsp),%xmm0
  8475c6:	00 00 
  8475c8:	0f 29 84 24 f0 04 00 	movaps %xmm0,0x4f0(%rsp)
  8475cf:	00 
  8475d0:	f2 0f 10 84 24 b0 04 	movsd  0x4b0(%rsp),%xmm0
  8475d7:	00 00 
  8475d9:	f2 0f 11 84 24 f8 03 	movsd  %xmm0,0x3f8(%rsp)
  8475e0:	00 00 
  8475e2:	f2 0f 10 84 24 b8 04 	movsd  0x4b8(%rsp),%xmm0
  8475e9:	00 00 
  8475eb:	f2 0f 11 84 24 f0 03 	movsd  %xmm0,0x3f0(%rsp)
  8475f2:	00 00 
  8475f4:	0f 10 84 24 c0 04 00 	movups 0x4c0(%rsp),%xmm0
  8475fb:	00 
  8475fc:	0f 29 84 24 c0 02 00 	movaps %xmm0,0x2c0(%rsp)
  847603:	00 
  847604:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  847609:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
  847610:	00 
  847611:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  847616:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
  84761d:	00 
  84761e:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  847625:	00 
  847626:	48 89 84 24 70 01 00 	mov    %rax,0x170(%rsp)
  84762d:	00 
  84762e:	0f 28 84 24 10 03 00 	movaps 0x310(%rsp),%xmm0
  847635:	00 
  847636:	0f 28 8c 24 20 03 00 	movaps 0x320(%rsp),%xmm1
  84763d:	00 
  84763e:	0f 28 94 24 30 03 00 	movaps 0x330(%rsp),%xmm2
  847645:	00 
  847646:	48 8d 84 24 78 01 00 	lea    0x178(%rsp),%rax
  84764d:	00 
  84764e:	0f 11 50 20          	movups %xmm2,0x20(%rax)
  847652:	0f 11 48 10          	movups %xmm1,0x10(%rax)
  847656:	0f 11 00             	movups %xmm0,(%rax)
  847659:	0f 28 84 24 10 05 00 	movaps 0x510(%rsp),%xmm0
  847660:	00 
  847661:	0f 11 40 30          	movups %xmm0,0x30(%rax)
  847665:	0f 28 84 24 30 04 00 	movaps 0x430(%rsp),%xmm0
  84766c:	00 
  84766d:	0f 11 40 40          	movups %xmm0,0x40(%rax)
  847671:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  847678:	00 
  847679:	ff 15 c9 7e 67 00    	call   *0x677ec9(%rip)        # ebf548 <_DYNAMIC+0x820>
  84767f:	8b 4c 24 7c          	mov    0x7c(%rsp),%ecx
  847683:	89 8c 24 f0 00 00 00 	mov    %ecx,0xf0(%rsp)
  84768a:	85 c0                	test   %eax,%eax
  84768c:	74 34                	je     8476c2 <<gpui_gpu::renderer::RendererState>::render+0xd32>
  84768e:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  847693:	89 c6                	mov    %eax,%esi
  847695:	e8 46 6d 00 00       	call   84e3e0 <gpui_gpu::renderer::slots::color_word>
  84769a:	89 44 24 50          	mov    %eax,0x50(%rsp)
  84769e:	0f 57 c0             	xorps  %xmm0,%xmm0
  8476a1:	0f 29 84 24 20 01 00 	movaps %xmm0,0x120(%rsp)
  8476a8:	00 
  8476a9:	c7 84 24 c0 00 00 00 	movl   $0x0,0xc0(%rsp)
  8476b0:	00 00 00 00 
  8476b4:	8b 84 24 58 01 00 00 	mov    0x158(%rsp),%eax
  8476bb:	89 84 24 f0 00 00 00 	mov    %eax,0xf0(%rsp)
  8476c2:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  8476c7:	48 c1 e8 20          	shr    $0x20,%rax
  8476cb:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
  8476d2:	00 
  8476d3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  8476d8:	48 8b 08             	mov    (%rax),%rcx
  8476db:	48 8b 70 10          	mov    0x10(%rax),%rsi
  8476df:	48 29 f1             	sub    %rsi,%rcx
  8476e2:	48 83 f9 05          	cmp    $0x5,%rcx
  8476e6:	0f 86 7e 01 00 00    	jbe    84786a <<gpui_gpu::renderer::RendererState>::render+0xeda>
  8476ec:	f2 0f 10 84 24 f0 03 	movsd  0x3f0(%rsp),%xmm0
  8476f3:	00 00 
  8476f5:	f2 0f 5a c0          	cvtsd2ss %xmm0,%xmm0
  8476f9:	f2 0f 10 8c 24 f8 03 	movsd  0x3f8(%rsp),%xmm1
  847700:	00 00 
  847702:	f2 0f 5a c9          	cvtsd2ss %xmm1,%xmm1
  847706:	66 0f 28 94 24 00 05 	movapd 0x500(%rsp),%xmm2
  84770d:	00 00 
  84770f:	66 0f 14 94 24 f0 04 	unpcklpd 0x4f0(%rsp),%xmm2
  847716:	00 00 
  847718:	66 0f 5a d2          	cvtpd2ps %xmm2,%xmm2
  84771c:	66 0f 28 9c 24 d0 03 	movapd 0x3d0(%rsp),%xmm3
  847723:	00 00 
  847725:	66 0f 14 9c 24 c0 03 	unpcklpd 0x3c0(%rsp),%xmm3
  84772c:	00 00 
  84772e:	66 0f 5a db          	cvtpd2ps %xmm3,%xmm3
  847732:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  847737:	48 8b 50 08          	mov    0x8(%rax),%rdx
  84773b:	48 c1 e6 04          	shl    $0x4,%rsi
  84773f:	0f 28 a4 24 d0 02 00 	movaps 0x2d0(%rsp),%xmm4
  847746:	00 
  847747:	0f 11 24 32          	movups %xmm4,(%rdx,%rsi,1)
  84774b:	66 0f 13 5c 32 10    	movlpd %xmm3,0x10(%rdx,%rsi,1)
  847751:	f3 0f 11 4c 32 18    	movss  %xmm1,0x18(%rdx,%rsi,1)
  847757:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  84775c:	89 4c 32 1c          	mov    %ecx,0x1c(%rdx,%rsi,1)
  847760:	66 0f 13 54 32 20    	movlpd %xmm2,0x20(%rdx,%rsi,1)
  847766:	f3 0f 11 44 32 28    	movss  %xmm0,0x28(%rdx,%rsi,1)
  84776c:	48 8b bc 24 e8 03 00 	mov    0x3e8(%rsp),%rdi
  847773:	00 
  847774:	89 7c 32 2c          	mov    %edi,0x2c(%rdx,%rsi,1)
  847778:	0f 28 84 24 c0 02 00 	movaps 0x2c0(%rsp),%xmm0
  84777f:	00 
  847780:	0f 11 44 32 30       	movups %xmm0,0x30(%rdx,%rsi,1)
  847785:	8b 7c 24 50          	mov    0x50(%rsp),%edi
  847789:	89 7c 32 40          	mov    %edi,0x40(%rdx,%rsi,1)
  84778d:	8b bc 24 c0 00 00 00 	mov    0xc0(%rsp),%edi
  847794:	89 7c 32 44          	mov    %edi,0x44(%rdx,%rsi,1)
  847798:	0f 28 84 24 20 01 00 	movaps 0x120(%rsp),%xmm0
  84779f:	00 
  8477a0:	0f 13 44 32 48       	movlps %xmm0,0x48(%rdx,%rsi,1)
  8477a5:	48 c7 44 32 50 00 00 	movq   $0x0,0x50(%rdx,%rsi,1)
  8477ac:	00 00 
  8477ae:	c7 44 32 58 00 00 00 	movl   $0x0,0x58(%rdx,%rsi,1)
  8477b5:	00 
  8477b6:	8b bc 24 f0 00 00 00 	mov    0xf0(%rsp),%edi
  8477bd:	89 7c 32 5c          	mov    %edi,0x5c(%rdx,%rsi,1)
  8477c1:	48 83 40 10 06       	addq   $0x6,0x10(%rax)
  8477c6:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  8477cd:	00 
  8477ce:	48 89 c6             	mov    %rax,%rsi
  8477d1:	48 8d 94 24 48 04 00 	lea    0x448(%rsp),%rdx
  8477d8:	00 
  8477d9:	44 8b 84 24 a0 03 00 	mov    0x3a0(%rsp),%r8d
  8477e0:	00 
  8477e1:	4c 8b 4c 24 48       	mov    0x48(%rsp),%r9
  8477e6:	ff b4 24 d8 00 00 00 	push   0xd8(%rsp)
  8477ed:	41 57                	push   %r15
  8477ef:	41 56                	push   %r14
  8477f1:	ff 74 24 50          	push   0x50(%rsp)
  8477f5:	e8 06 16 00 00       	call   848e00 <<gpui_gpu::renderer::RendererState>::bin_draw>
  8477fa:	48 83 c4 20          	add    $0x20,%rsp
  8477fe:	8b 84 24 60 01 00 00 	mov    0x160(%rsp),%eax
  847805:	83 f8 ff             	cmp    $0xffffffff,%eax
  847808:	0f 85 48 06 00 00    	jne    847e56 <<gpui_gpu::renderer::RendererState>::render+0x14c6>
  84780e:	0f b6 4c 24 2f       	movzbl 0x2f(%rsp),%ecx
  847813:	22 4c 24 2e          	and    0x2e(%rsp),%cl
  847817:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  84781c:	08 c8                	or     %cl,%al
  84781e:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  847823:	48 8b 84 24 68 01 00 	mov    0x168(%rsp),%rax
  84782a:	00 
  84782b:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
  847832:	00 
  847833:	48 ff 44 24 48       	incq   0x48(%rsp)
  847838:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
  84783f:	00 
  847840:	48 83 c2 04          	add    $0x4,%rdx
  847844:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  84784b:	00 
  84784c:	48 8d 04 85 00 00 00 	lea    0x0(,%rax,4),%rax
  847853:	00 
  847854:	48 89 94 24 80 00 00 	mov    %rdx,0x80(%rsp)
  84785b:	00 
  84785c:	48 39 d0             	cmp    %rdx,%rax
  84785f:	0f 85 1f fb ff ff    	jne    847384 <<gpui_gpu::renderer::RendererState>::render+0x9f4>
  847865:	e9 74 04 00 00       	jmp    847cde <<gpui_gpu::renderer::RendererState>::render+0x134e>
  84786a:	ba 06 00 00 00       	mov    $0x6,%edx
  84786f:	b9 04 00 00 00       	mov    $0x4,%ecx
  847874:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  84787a:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  84787f:	e8 ac 4b 00 00       	call   84c430 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  847884:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  847889:	48 8b 70 10          	mov    0x10(%rax),%rsi
  84788d:	e9 5a fe ff ff       	jmp    8476ec <<gpui_gpu::renderer::RendererState>::render+0xd5c>
  847892:	0f 57 c0             	xorps  %xmm0,%xmm0
  847895:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
  84789c:	00 
  84789d:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
  8478a2:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  8478a7:	8b 40 10             	mov    0x10(%rax),%eax
  8478aa:	89 84 24 20 01 00 00 	mov    %eax,0x120(%rsp)
  8478b1:	0f 10 8c 24 70 02 00 	movups 0x270(%rsp),%xmm1
  8478b8:	00 
  8478b9:	0f 10 94 24 78 02 00 	movups 0x278(%rsp),%xmm2
  8478c0:	00 
  8478c1:	f2 0f 10 84 24 90 02 	movsd  0x290(%rsp),%xmm0
  8478c8:	00 00 
  8478ca:	f2 0f 11 84 24 f0 00 	movsd  %xmm0,0xf0(%rsp)
  8478d1:	00 00 
  8478d3:	f2 0f 10 84 24 98 02 	movsd  0x298(%rsp),%xmm0
  8478da:	00 00 
  8478dc:	f2 0f 11 84 24 d0 02 	movsd  %xmm0,0x2d0(%rsp)
  8478e3:	00 00 
  8478e5:	0f 10 84 24 a0 02 00 	movups 0x2a0(%rsp),%xmm0
  8478ec:	00 
  8478ed:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
  8478f4:	00 
  8478f5:	0f 16 8c 24 80 02 00 	movhps 0x280(%rsp),%xmm1
  8478fc:	00 
  8478fd:	0f 29 8c 24 a0 03 00 	movaps %xmm1,0x3a0(%rsp)
  847904:	00 
  847905:	0f 10 84 24 b0 02 00 	movups 0x2b0(%rsp),%xmm0
  84790c:	00 
  84790d:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
  847912:	0f 16 94 24 88 02 00 	movhps 0x288(%rsp),%xmm2
  847919:	00 
  84791a:	0f 29 94 24 c0 02 00 	movaps %xmm2,0x2c0(%rsp)
  847921:	00 
  847922:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  847927:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
  84792e:	00 
  84792f:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  847934:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
  84793b:	00 
  84793c:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  847943:	00 
  847944:	48 89 84 24 70 01 00 	mov    %rax,0x170(%rsp)
  84794b:	00 
  84794c:	48 8d 84 24 70 02 00 	lea    0x270(%rsp),%rax
  847953:	00 
  847954:	0f 10 00             	movups (%rax),%xmm0
  847957:	0f 10 48 10          	movups 0x10(%rax),%xmm1
  84795b:	0f 10 50 20          	movups 0x20(%rax),%xmm2
  84795f:	48 8d 94 24 78 01 00 	lea    0x178(%rsp),%rdx
  847966:	00 
  847967:	0f 11 52 20          	movups %xmm2,0x20(%rdx)
  84796b:	0f 11 4a 10          	movups %xmm1,0x10(%rdx)
  84796f:	0f 11 02             	movups %xmm0,(%rdx)
  847972:	48 8d 8c 24 a0 02 00 	lea    0x2a0(%rsp),%rcx
  847979:	00 
  84797a:	0f 10 01             	movups (%rcx),%xmm0
  84797d:	0f 11 42 30          	movups %xmm0,0x30(%rdx)
  847981:	f3 0f 6f 40 40       	movdqu 0x40(%rax),%xmm0
  847986:	f3 0f 7f 42 40       	movdqu %xmm0,0x40(%rdx)
  84798b:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  847992:	00 
  847993:	ff 15 af 7b 67 00    	call   *0x677baf(%rip)        # ebf548 <_DYNAMIC+0x820>
  847999:	85 c0                	test   %eax,%eax
  84799b:	74 1e                	je     8479bb <<gpui_gpu::renderer::RendererState>::render+0x102b>
  84799d:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  8479a2:	89 c6                	mov    %eax,%esi
  8479a4:	e8 37 6a 00 00       	call   84e3e0 <gpui_gpu::renderer::slots::color_word>
  8479a9:	81 4c 24 7c 00 00 00 	orl    $0x80000000,0x7c(%rsp)
  8479b0:	80 
  8479b1:	66 0f 6e c0          	movd   %eax,%xmm0
  8479b5:	66 0f 7f 44 24 50    	movdqa %xmm0,0x50(%rsp)
  8479bb:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  8479c0:	48 8b 08             	mov    (%rax),%rcx
  8479c3:	48 8b 70 10          	mov    0x10(%rax),%rsi
  8479c7:	48 29 f1             	sub    %rsi,%rcx
  8479ca:	48 83 f9 04          	cmp    $0x4,%rcx
  8479ce:	0f 86 44 03 00 00    	jbe    847d18 <<gpui_gpu::renderer::RendererState>::render+0x1388>
  8479d4:	66 0f 5a 84 24 a0 03 	cvtpd2ps 0x3a0(%rsp),%xmm0
  8479db:	00 00 
  8479dd:	66 0f 5a 8c 24 c0 02 	cvtpd2ps 0x2c0(%rsp),%xmm1
  8479e4:	00 00 
  8479e6:	f2 0f 10 94 24 f0 00 	movsd  0xf0(%rsp),%xmm2
  8479ed:	00 00 
  8479ef:	f2 0f 5a d2          	cvtsd2ss %xmm2,%xmm2
  8479f3:	f2 0f 10 9c 24 d0 02 	movsd  0x2d0(%rsp),%xmm3
  8479fa:	00 00 
  8479fc:	f2 0f 5a db          	cvtsd2ss %xmm3,%xmm3
  847a00:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  847a05:	48 8b 48 08          	mov    0x8(%rax),%rcx
  847a09:	48 c1 e6 04          	shl    $0x4,%rsi
  847a0d:	66 0f 13 04 31       	movlpd %xmm0,(%rcx,%rsi,1)
  847a12:	f3 0f 11 54 31 08    	movss  %xmm2,0x8(%rcx,%rsi,1)
  847a18:	0f 28 44 24 60       	movaps 0x60(%rsp),%xmm0
  847a1d:	f3 0f 11 44 31 0c    	movss  %xmm0,0xc(%rcx,%rsi,1)
  847a23:	66 0f 13 4c 31 10    	movlpd %xmm1,0x10(%rcx,%rsi,1)
  847a29:	f3 0f 11 5c 31 18    	movss  %xmm3,0x18(%rcx,%rsi,1)
  847a2f:	0f 28 84 24 80 00 00 	movaps 0x80(%rsp),%xmm0
  847a36:	00 
  847a37:	f3 0f 11 44 31 1c    	movss  %xmm0,0x1c(%rcx,%rsi,1)
  847a3d:	0f 28 84 24 c0 00 00 	movaps 0xc0(%rsp),%xmm0
  847a44:	00 
  847a45:	0f 11 44 31 20       	movups %xmm0,0x20(%rcx,%rsi,1)
  847a4a:	0f 28 44 24 50       	movaps 0x50(%rsp),%xmm0
  847a4f:	0f 11 44 31 30       	movups %xmm0,0x30(%rcx,%rsi,1)
  847a54:	8b 54 24 7c          	mov    0x7c(%rsp),%edx
  847a58:	89 54 31 40          	mov    %edx,0x40(%rcx,%rsi,1)
  847a5c:	48 c7 44 31 44 00 00 	movq   $0x0,0x44(%rcx,%rsi,1)
  847a63:	00 00 
  847a65:	c7 44 31 4c 00 00 00 	movl   $0x0,0x4c(%rcx,%rsi,1)
  847a6c:	00 
  847a6d:	48 83 40 10 05       	addq   $0x5,0x10(%rax)
  847a72:	48 ff 84 24 38 01 00 	incq   0x138(%rsp)
  847a79:	00 
  847a7a:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  847a81:	00 
  847a82:	48 01 84 24 40 01 00 	add    %rax,0x140(%rsp)
  847a89:	00 
  847a8a:	48 85 c0             	test   %rax,%rax
  847a8d:	0f 84 57 02 00 00    	je     847cea <<gpui_gpu::renderer::RendererState>::render+0x135a>
  847a93:	66 0f 6f 44 24 60    	movdqa 0x60(%rsp),%xmm0
  847a99:	66 0f 7e c1          	movd   %xmm0,%ecx
  847a9d:	66 0f 6f 84 24 80 00 	movdqa 0x80(%rsp),%xmm0
  847aa4:	00 00 
  847aa6:	66 0f 7e c0          	movd   %xmm0,%eax
  847aaa:	48 c1 e0 20          	shl    $0x20,%rax
  847aae:	48 09 c1             	or     %rax,%rcx
  847ab1:	48 89 8c 24 f0 00 00 	mov    %rcx,0xf0(%rsp)
  847ab8:	00 
  847ab9:	48 c7 44 24 60 00 00 	movq   $0x0,0x60(%rsp)
  847ac0:	00 00 
  847ac2:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  847ac7:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  847acc:	8b 14 08             	mov    (%rax,%rcx,1),%edx
  847acf:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
  847ad6:	00 
  847ad7:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  847adc:	e8 6f d6 ff ff       	call   845150 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  847ae1:	0f b6 bc 24 40 03 00 	movzbl 0x340(%rsp),%edi
  847ae8:	00 
  847ae9:	48 8d b4 24 48 03 00 	lea    0x348(%rsp),%rsi
  847af0:	00 
  847af1:	8b 46 f9             	mov    -0x7(%rsi),%eax
  847af4:	8b 4e fc             	mov    -0x4(%rsi),%ecx
  847af7:	48 8d 94 24 61 01 00 	lea    0x161(%rsp),%rdx
  847afe:	00 
  847aff:	89 4a 03             	mov    %ecx,0x3(%rdx)
  847b02:	89 02                	mov    %eax,(%rdx)
  847b04:	48 8b 8c 24 48 03 00 	mov    0x348(%rsp),%rcx
  847b0b:	00 
  847b0c:	48 8b 46 28          	mov    0x28(%rsi),%rax
  847b10:	48 89 42 2f          	mov    %rax,0x2f(%rdx)
  847b14:	0f 10 46 08          	movups 0x8(%rsi),%xmm0
  847b18:	0f 10 4e 18          	movups 0x18(%rsi),%xmm1
  847b1c:	0f 11 4a 1f          	movups %xmm1,0x1f(%rdx)
  847b20:	0f 11 42 0f          	movups %xmm0,0xf(%rdx)
  847b24:	0f 10 8c 24 78 03 00 	movups 0x378(%rsp),%xmm1
  847b2b:	00 
  847b2c:	48 8d 84 24 88 03 00 	lea    0x388(%rsp),%rax
  847b33:	00 
  847b34:	0f 10 00             	movups (%rax),%xmm0
  847b37:	48 8d 84 24 78 01 00 	lea    0x178(%rsp),%rax
  847b3e:	00 
  847b3f:	0f 11 40 70          	movups %xmm0,0x70(%rax)
  847b43:	0f 28 84 24 30 04 00 	movaps 0x430(%rsp),%xmm0
  847b4a:	00 
  847b4b:	0f 11 80 80 00 00 00 	movups %xmm0,0x80(%rax)
  847b52:	0f 29 8c 24 a0 00 00 	movaps %xmm1,0xa0(%rsp)
  847b59:	00 
  847b5a:	0f 11 8c 24 98 01 00 	movups %xmm1,0x198(%rsp)
  847b61:	00 
  847b62:	0f 28 84 24 20 05 00 	movaps 0x520(%rsp),%xmm0
  847b69:	00 
  847b6a:	0f 28 8c 24 30 05 00 	movaps 0x530(%rsp),%xmm1
  847b71:	00 
  847b72:	66 0f 28 94 24 40 05 	movapd 0x540(%rsp),%xmm2
  847b79:	00 00 
  847b7b:	66 0f 11 50 50       	movupd %xmm2,0x50(%rax)
  847b80:	0f 11 48 40          	movups %xmm1,0x40(%rax)
  847b84:	0f 11 40 30          	movups %xmm0,0x30(%rax)
  847b88:	0f 28 84 24 50 05 00 	movaps 0x550(%rsp),%xmm0
  847b8f:	00 
  847b90:	0f 11 40 60          	movups %xmm0,0x60(%rax)
  847b94:	40 88 7c 24 50       	mov    %dil,0x50(%rsp)
  847b99:	40 88 bc 24 60 01 00 	mov    %dil,0x160(%rsp)
  847ba0:	00 
  847ba1:	48 89 8c 24 c0 00 00 	mov    %rcx,0xc0(%rsp)
  847ba8:	00 
  847ba9:	48 89 8c 24 68 01 00 	mov    %rcx,0x168(%rsp)
  847bb0:	00 
  847bb1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  847bb6:	48 8b 08             	mov    (%rax),%rcx
  847bb9:	48 8b 40 10          	mov    0x10(%rax),%rax
  847bbd:	48 29 c1             	sub    %rax,%rcx
  847bc0:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  847bc7:	00 
  847bc8:	48 83 f9 01          	cmp    $0x1,%rcx
  847bcc:	0f 86 dc 00 00 00    	jbe    847cae <<gpui_gpu::renderer::RendererState>::render+0x131e>
  847bd2:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  847bd7:	48 8b 4e 08          	mov    0x8(%rsi),%rcx
  847bdb:	48 c1 e0 04          	shl    $0x4,%rax
  847bdf:	0f 28 84 24 a0 00 00 	movaps 0xa0(%rsp),%xmm0
  847be6:	00 
  847be7:	0f 11 04 01          	movups %xmm0,(%rcx,%rax,1)
  847beb:	48 c7 44 01 10 00 00 	movq   $0x0,0x10(%rcx,%rax,1)
  847bf2:	00 00 
  847bf4:	c7 44 01 18 00 00 00 	movl   $0x0,0x18(%rcx,%rax,1)
  847bfb:	00 
  847bfc:	8b 94 24 20 01 00 00 	mov    0x120(%rsp),%edx
  847c03:	89 54 01 1c          	mov    %edx,0x1c(%rcx,%rax,1)
  847c07:	48 83 46 10 02       	addq   $0x2,0x10(%rsi)
  847c0c:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
  847c13:	00 
  847c14:	48 8d 94 24 60 01 00 	lea    0x160(%rsp),%rdx
  847c1b:	00 
  847c1c:	48 8b 8c 24 f0 00 00 	mov    0xf0(%rsp),%rcx
  847c23:	00 
  847c24:	4c 8b 84 24 80 00 00 	mov    0x80(%rsp),%r8
  847c2b:	00 
  847c2c:	4c 8b 4c 24 48       	mov    0x48(%rsp),%r9
  847c31:	ff b4 24 d8 00 00 00 	push   0xd8(%rsp)
  847c38:	41 57                	push   %r15
  847c3a:	41 56                	push   %r14
  847c3c:	ff 74 24 50          	push   0x50(%rsp)
  847c40:	e8 bb 11 00 00       	call   848e00 <<gpui_gpu::renderer::RendererState>::bin_draw>
  847c45:	48 83 c4 20          	add    $0x20,%rsp
  847c49:	8b 84 24 40 03 00 00 	mov    0x340(%rsp),%eax
  847c50:	83 f8 ff             	cmp    $0xffffffff,%eax
  847c53:	0f 85 19 02 00 00    	jne    847e72 <<gpui_gpu::renderer::RendererState>::render+0x14e2>
  847c59:	80 7c 24 50 02       	cmpb   $0x2,0x50(%rsp)
  847c5e:	0f 94 c0             	sete   %al
  847c61:	48 83 bc 24 c0 00 00 	cmpq   $0x0,0xc0(%rsp)
  847c68:	00 00 
  847c6a:	0f 95 c1             	setne  %cl
  847c6d:	20 c1                	and    %al,%cl
  847c6f:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  847c74:	08 c8                	or     %cl,%al
  847c76:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  847c7b:	48 8b 84 24 48 03 00 	mov    0x348(%rsp),%rax
  847c82:	00 
  847c83:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
  847c8a:	00 
  847c8b:	48 ff 44 24 48       	incq   0x48(%rsp)
  847c90:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  847c95:	48 83 c1 04          	add    $0x4,%rcx
  847c99:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
  847c9e:	48 39 8c 24 e0 03 00 	cmp    %rcx,0x3e0(%rsp)
  847ca5:	00 
  847ca6:	0f 85 16 fe ff ff    	jne    847ac2 <<gpui_gpu::renderer::RendererState>::render+0x1132>
  847cac:	eb 30                	jmp    847cde <<gpui_gpu::renderer::RendererState>::render+0x134e>
  847cae:	ba 02 00 00 00       	mov    $0x2,%edx
  847cb3:	b9 04 00 00 00       	mov    $0x4,%ecx
  847cb8:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  847cbe:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  847cc3:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
  847cca:	00 
  847ccb:	e8 60 47 00 00       	call   84c430 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  847cd0:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  847cd5:	48 8b 40 10          	mov    0x10(%rax),%rax
  847cd9:	e9 f4 fe ff ff       	jmp    847bd2 <<gpui_gpu::renderer::RendererState>::render+0x1242>
  847cde:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  847ce3:	24 01                	and    $0x1,%al
  847ce5:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  847cea:	48 8d bc 24 58 02 00 	lea    0x258(%rsp),%rdi
  847cf1:	00 
  847cf2:	48 8d b4 24 e8 02 00 	lea    0x2e8(%rsp),%rsi
  847cf9:	00 
  847cfa:	ff 15 40 78 67 00    	call   *0x677840(%rip)        # ebf540 <_DYNAMIC+0x818>
  847d00:	48 8b 84 24 58 02 00 	mov    0x258(%rsp),%rax
  847d07:	00 
  847d08:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  847d0d:	48 85 c0             	test   %rax,%rax
  847d10:	0f 85 2f f3 ff ff    	jne    847045 <<gpui_gpu::renderer::RendererState>::render+0x6b5>
  847d16:	eb 5e                	jmp    847d76 <<gpui_gpu::renderer::RendererState>::render+0x13e6>
  847d18:	ba 05 00 00 00       	mov    $0x5,%edx
  847d1d:	b9 04 00 00 00       	mov    $0x4,%ecx
  847d22:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  847d28:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  847d2d:	e8 fe 46 00 00       	call   84c430 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  847d32:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  847d37:	48 8b 70 10          	mov    0x10(%rax),%rsi
  847d3b:	e9 94 fc ff ff       	jmp    8479d4 <<gpui_gpu::renderer::RendererState>::render+0x1044>
  847d40:	48 c7 84 24 40 01 00 	movq   $0x0,0x140(%rsp)
  847d47:	00 00 00 00 00 
  847d4c:	48 c7 84 24 38 01 00 	movq   $0x0,0x138(%rsp)
  847d53:	00 00 00 00 00 
  847d58:	48 c7 44 24 48 00 00 	movq   $0x0,0x48(%rsp)
  847d5f:	00 00 
  847d61:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  847d68:	00 00 
  847d6a:	48 c7 84 24 d8 00 00 	movq   $0x0,0xd8(%rsp)
  847d71:	00 00 00 00 00 
  847d76:	48 8b b4 24 50 01 00 	mov    0x150(%rsp),%rsi
  847d7d:	00 
  847d7e:	48 8d 56 08          	lea    0x8(%rsi),%rdx
  847d82:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  847d87:	48 8d 88 50 02 00 00 	lea    0x250(%rax),%rcx
  847d8e:	4c 8d 80 28 03 00 00 	lea    0x328(%rax),%r8
  847d95:	4c 8b 48 10          	mov    0x10(%rax),%r9
  847d99:	48 83 ec 08          	sub    $0x8,%rsp
  847d9d:	48 8d bc 24 68 01 00 	lea    0x168(%rsp),%rdi
  847da4:	00 
  847da5:	48 89 94 24 d8 03 00 	mov    %rdx,0x3d8(%rsp)
  847dac:	00 
  847dad:	48 89 8c 24 c8 02 00 	mov    %rcx,0x2c8(%rsp)
  847db4:	00 
  847db5:	4c 89 84 24 d8 02 00 	mov    %r8,0x2d8(%rsp)
  847dbc:	00 
  847dbd:	ff b4 24 98 00 00 00 	push   0x98(%rsp)
  847dc4:	e8 a7 35 00 00       	call   84b370 <gpui_gpu::renderer::images::prepare>
  847dc9:	48 83 c4 10          	add    $0x10,%rsp
  847dcd:	83 bc 24 60 01 00 00 	cmpl   $0xffffffff,0x160(%rsp)
  847dd4:	ff 
  847dd5:	74 47                	je     847e1e <<gpui_gpu::renderer::RendererState>::render+0x148e>
  847dd7:	0f 10 84 24 60 01 00 	movups 0x160(%rsp),%xmm0
  847dde:	00 
  847ddf:	0f 10 8c 24 70 01 00 	movups 0x170(%rsp),%xmm1
  847de6:	00 
  847de7:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  847dec:	0f 11 4f 10          	movups %xmm1,0x10(%rdi)
  847df0:	0f 11 07             	movups %xmm0,(%rdi)
  847df3:	e9 8e ec ff ff       	jmp    846a86 <<gpui_gpu::renderer::RendererState>::render+0xf6>
  847df8:	8b 94 24 1c 01 00 00 	mov    0x11c(%rsp),%edx
  847dff:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  847e04:	89 57 1c             	mov    %edx,0x1c(%rdi)
  847e07:	0f 10 84 24 0c 01 00 	movups 0x10c(%rsp),%xmm0
  847e0e:	00 
  847e0f:	0f 11 47 0c          	movups %xmm0,0xc(%rdi)
  847e13:	89 0f                	mov    %ecx,(%rdi)
  847e15:	48 89 47 04          	mov    %rax,0x4(%rdi)
  847e19:	e9 68 ec ff ff       	jmp    846a86 <<gpui_gpu::renderer::RendererState>::render+0xf6>
  847e1e:	44 0f b6 44 24 10    	movzbl 0x10(%rsp),%r8d
  847e24:	41 83 e0 01          	and    $0x1,%r8d
  847e28:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  847e2f:	00 
  847e30:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  847e35:	48 8b 94 24 50 01 00 	mov    0x150(%rsp),%rdx
  847e3c:	00 
  847e3d:	48 8b 8c 24 b8 00 00 	mov    0xb8(%rsp),%rcx
  847e44:	00 
  847e45:	e8 a6 e1 ff ff       	call   845ff0 <<gpui_gpu::renderer::RendererState>::prepare_atlas>
  847e4a:	8b 84 24 60 01 00 00 	mov    0x160(%rsp),%eax
  847e51:	83 f8 ff             	cmp    $0xffffffff,%eax
  847e54:	74 63                	je     847eb9 <<gpui_gpu::renderer::RendererState>::render+0x1529>
  847e56:	8b 8c 24 64 01 00 00 	mov    0x164(%rsp),%ecx
  847e5d:	48 8b 94 24 68 01 00 	mov    0x168(%rsp),%rdx
  847e64:	00 
  847e65:	0f 10 84 24 70 01 00 	movups 0x170(%rsp),%xmm0
  847e6c:	00 
  847e6d:	e9 3d f0 ff ff       	jmp    846eaf <<gpui_gpu::renderer::RendererState>::render+0x51f>
  847e72:	8b 8c 24 44 03 00 00 	mov    0x344(%rsp),%ecx
  847e79:	48 8b 94 24 48 03 00 	mov    0x348(%rsp),%rdx
  847e80:	00 
  847e81:	0f 10 84 24 50 03 00 	movups 0x350(%rsp),%xmm0
  847e88:	00 
  847e89:	e9 21 f0 ff ff       	jmp    846eaf <<gpui_gpu::renderer::RendererState>::render+0x51f>
  847e8e:	8b 8c 24 7c 01 00 00 	mov    0x17c(%rsp),%ecx
  847e95:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  847e9a:	89 4f 1c             	mov    %ecx,0x1c(%rdi)
  847e9d:	0f 10 84 24 6c 01 00 	movups 0x16c(%rsp),%xmm0
  847ea4:	00 
  847ea5:	0f 11 47 0c          	movups %xmm0,0xc(%rdi)
  847ea9:	89 07                	mov    %eax,(%rdi)
  847eab:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  847eb0:	48 89 47 04          	mov    %rax,0x4(%rdi)
  847eb4:	e9 cd eb ff ff       	jmp    846a86 <<gpui_gpu::renderer::RendererState>::render+0xf6>
  847eb9:	48 8b 84 24 68 01 00 	mov    0x168(%rsp),%rax
  847ec0:	00 
  847ec1:	48 89 84 24 c0 03 00 	mov    %rax,0x3c0(%rsp)
  847ec8:	00 
  847ec9:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  847ed0:	00 
  847ed1:	48 89 84 24 40 03 00 	mov    %rax,0x340(%rsp)
  847ed8:	00 
  847ed9:	48 c7 84 24 48 03 00 	movq   $0x0,0x348(%rsp)
  847ee0:	00 00 00 00 00 
  847ee5:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
  847eec:	00 
  847eed:	48 89 84 24 50 03 00 	mov    %rax,0x350(%rsp)
  847ef4:	00 
  847ef5:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  847efc:	00 
  847efd:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
  847f04:	00 
  847f05:	8b 44 24 78          	mov    0x78(%rsp),%eax
  847f09:	89 84 24 60 03 00 00 	mov    %eax,0x360(%rsp)
  847f10:	48 8d bc 24 58 02 00 	lea    0x258(%rsp),%rdi
  847f17:	00 
  847f18:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
  847f1f:	00 
  847f20:	ff 15 1a 76 67 00    	call   *0x67761a(%rip)        # ebf540 <_DYNAMIC+0x818>
  847f26:	48 8b 84 24 58 02 00 	mov    0x258(%rsp),%rax
  847f2d:	00 
  847f2e:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  847f35:	00 
  847f36:	48 85 c0             	test   %rax,%rax
  847f39:	0f 84 d7 03 00 00    	je     848316 <<gpui_gpu::renderer::RendererState>::render+0x1986>
  847f3f:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  847f44:	48 05 20 01 00 00    	add    $0x120,%rax
  847f4a:	48 89 84 24 a0 03 00 	mov    %rax,0x3a0(%rsp)
  847f51:	00 
  847f52:	eb 3c                	jmp    847f90 <<gpui_gpu::renderer::RendererState>::render+0x1600>
  847f54:	48 8d bc 24 58 02 00 	lea    0x258(%rsp),%rdi
  847f5b:	00 
  847f5c:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
  847f63:	00 
  847f64:	ff 15 d6 75 67 00    	call   *0x6775d6(%rip)        # ebf540 <_DYNAMIC+0x818>
  847f6a:	48 8b 84 24 58 02 00 	mov    0x258(%rsp),%rax
  847f71:	00 
  847f72:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  847f77:	48 89 8c 24 e0 00 00 	mov    %rcx,0xe0(%rsp)
  847f7e:	00 
  847f7f:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  847f86:	00 
  847f87:	48 85 c0             	test   %rax,%rax
  847f8a:	0f 84 86 03 00 00    	je     848316 <<gpui_gpu::renderer::RendererState>::render+0x1986>
  847f90:	48 8b 94 24 60 02 00 	mov    0x260(%rsp),%rdx
  847f97:	00 
  847f98:	48 8b bc 24 68 02 00 	mov    0x268(%rsp),%rdi
  847f9f:	00 
  847fa0:	48 89 bc 24 80 00 00 	mov    %rdi,0x80(%rsp)
  847fa7:	00 
  847fa8:	48 8d 84 24 70 02 00 	lea    0x270(%rsp),%rax
  847faf:	00 
  847fb0:	0f 10 40 40          	movups 0x40(%rax),%xmm0
  847fb4:	48 8d 8c 24 78 01 00 	lea    0x178(%rsp),%rcx
  847fbb:	00 
  847fbc:	0f 11 41 40          	movups %xmm0,0x40(%rcx)
  847fc0:	0f 10 00             	movups (%rax),%xmm0
  847fc3:	0f 10 48 10          	movups 0x10(%rax),%xmm1
  847fc7:	0f 10 50 20          	movups 0x20(%rax),%xmm2
  847fcb:	0f 10 58 30          	movups 0x30(%rax),%xmm3
  847fcf:	0f 11 59 30          	movups %xmm3,0x30(%rcx)
  847fd3:	0f 11 51 20          	movups %xmm2,0x20(%rcx)
  847fd7:	0f 11 49 10          	movups %xmm1,0x10(%rcx)
  847fdb:	0f 11 01             	movups %xmm0,(%rcx)
  847fde:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  847fe3:	0f b6 b0 41 03 00 00 	movzbl 0x341(%rax),%esi
  847fea:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  847ff1:	00 
  847ff2:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
  847ff9:	00 
  847ffa:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
  847fff:	48 89 94 24 68 01 00 	mov    %rdx,0x168(%rsp)
  848006:	00 
  848007:	48 89 bc 24 70 01 00 	mov    %rdi,0x170(%rsp)
  84800e:	00 
  84800f:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  848016:	00 
  848017:	e8 44 1e 00 00       	call   849e60 <gpui_gpu::renderer::compact_group>
  84801c:	48 8b 8c 24 e0 00 00 	mov    0xe0(%rsp),%rcx
  848023:	00 
  848024:	48 8d 51 05          	lea    0x5(%rcx),%rdx
  848028:	84 c0                	test   %al,%al
  84802a:	48 0f 44 d1          	cmove  %rcx,%rdx
  84802e:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
  848033:	48 83 bc 24 80 00 00 	cmpq   $0x0,0x80(%rsp)
  84803a:	00 00 
  84803c:	0f 84 12 ff ff ff    	je     847f54 <<gpui_gpu::renderer::RendererState>::render+0x15c4>
  848042:	48 c1 a4 24 80 00 00 	shlq   $0x2,0x80(%rsp)
  848049:	00 02 
  84804b:	34 01                	xor    $0x1,%al
  84804d:	0f b6 c8             	movzbl %al,%ecx
  848050:	c1 e1 02             	shl    $0x2,%ecx
  848053:	48 8d 41 01          	lea    0x1(%rcx),%rax
  848057:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  84805e:	00 
  84805f:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  848064:	4c 8d 04 08          	lea    (%rax,%rcx,1),%r8
  848068:	49 ff c0             	inc    %r8
  84806b:	48 83 c9 02          	or     $0x2,%rcx
  84806f:	49 c1 e0 04          	shl    $0x4,%r8
  848073:	48 89 8c 24 e0 00 00 	mov    %rcx,0xe0(%rsp)
  84807a:	00 
  84807b:	c1 e1 04             	shl    $0x4,%ecx
  84807e:	48 89 8c 24 20 01 00 	mov    %rcx,0x120(%rsp)
  848085:	00 
  848086:	31 c9                	xor    %ecx,%ecx
  848088:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
  84808d:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  848092:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
  848097:	8b 14 08             	mov    (%rax,%rcx,1),%edx
  84809a:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  8480a1:	00 
  8480a2:	48 8b b4 24 a0 00 00 	mov    0xa0(%rsp),%rsi
  8480a9:	00 
  8480aa:	e8 a1 d0 ff ff       	call   845150 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  8480af:	0f b6 8c 24 60 01 00 	movzbl 0x160(%rsp),%ecx
  8480b6:	00 
  8480b7:	0f b6 84 24 61 01 00 	movzbl 0x161(%rsp),%eax
  8480be:	00 
  8480bf:	f3 0f 10 a4 24 64 01 	movss  0x164(%rsp),%xmm4
  8480c6:	00 00 
  8480c8:	48 8d b4 24 68 01 00 	lea    0x168(%rsp),%rsi
  8480cf:	00 
  8480d0:	48 8b 56 10          	mov    0x10(%rsi),%rdx
  8480d4:	48 89 94 24 20 03 00 	mov    %rdx,0x320(%rsp)
  8480db:	00 
  8480dc:	0f 10 06             	movups (%rsi),%xmm0
  8480df:	0f 29 84 24 10 03 00 	movaps %xmm0,0x310(%rsp)
  8480e6:	00 
  8480e7:	83 f9 01             	cmp    $0x1,%ecx
  8480ea:	0f 84 8f 00 00 00    	je     84817f <<gpui_gpu::renderer::RendererState>::render+0x17ef>
  8480f0:	0f 29 a4 24 f0 00 00 	movaps %xmm4,0xf0(%rsp)
  8480f7:	00 
  8480f8:	48 8b b4 24 80 01 00 	mov    0x180(%rsp),%rsi
  8480ff:	00 
  848100:	8b 94 24 88 01 00 00 	mov    0x188(%rsp),%edx
  848107:	89 54 24 60          	mov    %edx,0x60(%rsp)
  84810b:	8b 94 24 8c 01 00 00 	mov    0x18c(%rsp),%edx
  848112:	89 54 24 20          	mov    %edx,0x20(%rsp)
  848116:	83 f9 03             	cmp    $0x3,%ecx
  848119:	0f 85 e5 00 00 00    	jne    848204 <<gpui_gpu::renderer::RendererState>::render+0x1874>
  84811f:	48 8b 8c 24 d0 02 00 	mov    0x2d0(%rsp),%rcx
  848126:	00 
  848127:	48 8b 39             	mov    (%rcx),%rdi
  84812a:	48 85 ff             	test   %rdi,%rdi
  84812d:	0f 84 4b 0c 00 00    	je     848d7e <<gpui_gpu::renderer::RendererState>::render+0x23ee>
  848133:	0f b6 d0             	movzbl %al,%edx
  848136:	e8 c5 2e 00 00       	call   84b000 <<gpui_gpu::renderer::images::Images>::metadata>
  84813b:	89 c1                	mov    %eax,%ecx
  84813d:	48 c1 e8 20          	shr    $0x20,%rax
  848141:	89 c2                	mov    %eax,%edx
  848143:	83 ca 10             	or     $0x10,%edx
  848146:	0f 57 c0             	xorps  %xmm0,%xmm0
  848149:	0f 28 8c 24 f0 00 00 	movaps 0xf0(%rsp),%xmm1
  848150:	00 
  848151:	0f 2e c8             	ucomiss %xmm0,%xmm1
  848154:	0f 45 c2             	cmovne %edx,%eax
  848157:	0f 4a c2             	cmovp  %edx,%eax
  84815a:	8b 54 24 20          	mov    0x20(%rsp),%edx
  84815e:	c1 e2 10             	shl    $0x10,%edx
  848161:	0b 54 24 60          	or     0x60(%rsp),%edx
  848165:	89 8c 24 00 01 00 00 	mov    %ecx,0x100(%rsp)
  84816c:	89 84 24 04 01 00 00 	mov    %eax,0x104(%rsp)
  848173:	89 94 24 08 01 00 00 	mov    %edx,0x108(%rsp)
  84817a:	e9 22 01 00 00       	jmp    8482a1 <<gpui_gpu::renderer::RendererState>::render+0x1911>
  84817f:	f3 0f 10 84 24 a0 01 	movss  0x1a0(%rsp),%xmm0
  848186:	00 00 
  848188:	f3 0f 10 1d 6c 8b 88 	movss  -0x777494(%rip),%xmm3        # d0cfc <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x14>
  84818f:	ff 
  848190:	f3 0f 59 c3          	mulss  %xmm3,%xmm0
  848194:	0f 28 cc             	movaps %xmm4,%xmm1
  848197:	f3 0f 5d c8          	minss  %xmm0,%xmm1
  84819b:	0f 28 c1             	movaps %xmm1,%xmm0
  84819e:	f3 0f c2 c1 03       	cmpunordss %xmm1,%xmm0
  8481a3:	0f 28 d0             	movaps %xmm0,%xmm2
  8481a6:	0f 55 d1             	andnps %xmm1,%xmm2
  8481a9:	0f 54 c4             	andps  %xmm4,%xmm0
  8481ac:	0f 56 c2             	orps   %xmm2,%xmm0
  8481af:	f3 0f 10 8c 24 a4 01 	movss  0x1a4(%rsp),%xmm1
  8481b6:	00 00 
  8481b8:	f3 0f 59 cb          	mulss  %xmm3,%xmm1
  8481bc:	0f 28 d0             	movaps %xmm0,%xmm2
  8481bf:	f3 0f 5d d1          	minss  %xmm1,%xmm2
  8481c3:	0f 28 ca             	movaps %xmm2,%xmm1
  8481c6:	f3 0f c2 ca 03       	cmpunordss %xmm2,%xmm1
  8481cb:	0f 54 c1             	andps  %xmm1,%xmm0
  8481ce:	0f 55 ca             	andnps %xmm2,%xmm1
  8481d1:	0f 56 c8             	orps   %xmm0,%xmm1
  8481d4:	66 0f 7e c8          	movd   %xmm1,%eax
  8481d8:	25 00 00 80 ff       	and    $0xff800000,%eax
  8481dd:	b9 00 00 00 7f       	mov    $0x7f000000,%ecx
  8481e2:	29 c1                	sub    %eax,%ecx
  8481e4:	c7 84 24 00 01 00 00 	movl   $0x40000000,0x100(%rsp)
  8481eb:	00 00 00 40 
  8481ef:	f3 0f 11 8c 24 04 01 	movss  %xmm1,0x104(%rsp)
  8481f6:	00 00 
  8481f8:	89 8c 24 08 01 00 00 	mov    %ecx,0x108(%rsp)
  8481ff:	e9 9d 00 00 00       	jmp    8482a1 <<gpui_gpu::renderer::RendererState>::render+0x1911>
  848204:	80 f9 02             	cmp    $0x2,%cl
  848207:	75 50                	jne    848259 <<gpui_gpu::renderer::RendererState>::render+0x18c9>
  848209:	48 8b 84 24 90 01 00 	mov    0x190(%rsp),%rax
  848210:	00 
  848211:	48 8b 8c 24 20 03 00 	mov    0x320(%rsp),%rcx
  848218:	00 
  848219:	48 89 8c 24 70 01 00 	mov    %rcx,0x170(%rsp)
  848220:	00 
  848221:	0f 28 84 24 10 03 00 	movaps 0x310(%rsp),%xmm0
  848228:	00 
  848229:	0f 29 84 24 60 01 00 	movaps %xmm0,0x160(%rsp)
  848230:	00 
  848231:	48 89 b4 24 78 01 00 	mov    %rsi,0x178(%rsp)
  848238:	00 
  848239:	8b 4c 24 60          	mov    0x60(%rsp),%ecx
  84823d:	89 8c 24 80 01 00 00 	mov    %ecx,0x180(%rsp)
  848244:	8b 4c 24 20          	mov    0x20(%rsp),%ecx
  848248:	89 8c 24 84 01 00 00 	mov    %ecx,0x184(%rsp)
  84824f:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
  848256:	00 
  848257:	eb 0c                	jmp    848265 <<gpui_gpu::renderer::RendererState>::render+0x18d5>
  848259:	48 c7 84 24 60 01 00 	movq   $0x0,0x160(%rsp)
  848260:	00 00 00 00 00 
  848265:	c7 84 24 f0 02 00 00 	movl   $0x0,0x2f0(%rsp)
  84826c:	00 00 00 00 
  848270:	48 c7 84 24 e8 02 00 	movq   $0x0,0x2e8(%rsp)
  848277:	00 00 00 00 00 
  84827c:	48 8d bc 24 00 01 00 	lea    0x100(%rsp),%rdi
  848283:	00 
  848284:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
  84828b:	00 
  84828c:	48 8d 94 24 e8 02 00 	lea    0x2e8(%rsp),%rdx
  848293:	00 
  848294:	48 8b 8c 24 a0 03 00 	mov    0x3a0(%rsp),%rcx
  84829b:	00 
  84829c:	e8 2f bc ff ff       	call   843ed0 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>>
  8482a1:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  8482a6:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
  8482ad:	00 
  8482ae:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
  8482b2:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  8482b7:	48 8b 70 10          	mov    0x10(%rax),%rsi
  8482bb:	48 39 f7             	cmp    %rsi,%rdi
  8482be:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
  8482c3:	0f 83 c2 0a 00 00    	jae    848d8b <<gpui_gpu::renderer::RendererState>::render+0x23fb>
  8482c9:	48 8b 40 08          	mov    0x8(%rax),%rax
  8482cd:	8b 8c 24 08 01 00 00 	mov    0x108(%rsp),%ecx
  8482d4:	42 89 4c 00 08       	mov    %ecx,0x8(%rax,%r8,1)
  8482d9:	48 8b 8c 24 00 01 00 	mov    0x100(%rsp),%rcx
  8482e0:	00 
  8482e1:	4a 89 0c 00          	mov    %rcx,(%rax,%r8,1)
  8482e5:	48 03 94 24 e0 00 00 	add    0xe0(%rsp),%rdx
  8482ec:	00 
  8482ed:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
  8482f2:	4c 03 84 24 20 01 00 	add    0x120(%rsp),%r8
  8482f9:	00 
  8482fa:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  8482ff:	48 83 c1 04          	add    $0x4,%rcx
  848303:	48 39 8c 24 80 00 00 	cmp    %rcx,0x80(%rsp)
  84830a:	00 
  84830b:	0f 85 77 fd ff ff    	jne    848088 <<gpui_gpu::renderer::RendererState>::render+0x16f8>
  848311:	e9 3e fc ff ff       	jmp    847f54 <<gpui_gpu::renderer::RendererState>::render+0x15c4>
  848316:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  84831b:	48 8b 40 28          	mov    0x28(%rax),%rax
  84831f:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
  848326:	00 00 
  848328:	48 85 c0             	test   %rax,%rax
  84832b:	74 6b                	je     848398 <<gpui_gpu::renderer::RendererState>::render+0x1a08>
  84832d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  848332:	48 8b 49 20          	mov    0x20(%rcx),%rcx
  848336:	48 c1 e0 03          	shl    $0x3,%rax
  84833a:	31 ff                	xor    %edi,%edi
  84833c:	eb 1c                	jmp    84835a <<gpui_gpu::renderer::RendererState>::render+0x19ca>
  84833e:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
  848343:	01 f2                	add    %esi,%edx
  848345:	89 14 f9             	mov    %edx,(%rcx,%rdi,8)
  848348:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
  84834d:	89 54 f9 04          	mov    %edx,0x4(%rcx,%rdi,8)
  848351:	48 ff c7             	inc    %rdi
  848354:	48 83 c0 f8          	add    $0xfffffffffffffff8,%rax
  848358:	74 32                	je     84838c <<gpui_gpu::renderer::RendererState>::render+0x19fc>
  84835a:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  84835f:	48 8b 72 58          	mov    0x58(%rdx),%rsi
  848363:	48 39 f7             	cmp    %rsi,%rdi
  848366:	0f 83 2c 0a 00 00    	jae    848d98 <<gpui_gpu::renderer::RendererState>::render+0x2408>
  84836c:	8b 74 f9 04          	mov    0x4(%rcx,%rdi,8),%esi
  848370:	83 fe 01             	cmp    $0x1,%esi
  848373:	75 c9                	jne    84833e <<gpui_gpu::renderer::RendererState>::render+0x19ae>
  848375:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  84837a:	4c 8b 42 50          	mov    0x50(%rdx),%r8
  84837e:	ba 00 00 00 80       	mov    $0x80000000,%edx
  848383:	41 83 3c b8 00       	cmpl   $0x0,(%r8,%rdi,4)
  848388:	75 c3                	jne    84834d <<gpui_gpu::renderer::RendererState>::render+0x19bd>
  84838a:	eb b2                	jmp    84833e <<gpui_gpu::renderer::RendererState>::render+0x19ae>
  84838c:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  848391:	89 c0                	mov    %eax,%eax
  848393:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  848398:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  84839d:	48 8d 78 30          	lea    0x30(%rax),%rdi
  8483a1:	48 c7 40 40 00 00 00 	movq   $0x0,0x40(%rax)
  8483a8:	00 
  8483a9:	48 89 bc 24 a0 00 00 	mov    %rdi,0xa0(%rsp)
  8483b0:	00 
  8483b1:	48 8b 74 24 50       	mov    0x50(%rsp),%rsi
  8483b6:	31 d2                	xor    %edx,%edx
  8483b8:	e8 63 2e 00 00       	call   84b220 <<alloc::vec::Vec<u32>>::resize>
  8483bd:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  8483c2:	48 8b 40 10          	mov    0x10(%rax),%rax
  8483c6:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  8483cb:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  8483d0:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  8483d7:	00 
  8483d8:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  8483df:	00 
  8483e0:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
  8483e7:	00 
  8483e8:	48 c7 84 24 f0 02 00 	movq   $0x0,0x2f0(%rsp)
  8483ef:	00 00 00 00 00 
  8483f4:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
  8483fb:	00 
  8483fc:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
  848403:	00 
  848404:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  84840b:	00 
  84840c:	48 89 84 24 00 03 00 	mov    %rax,0x300(%rsp)
  848413:	00 
  848414:	8b 44 24 78          	mov    0x78(%rsp),%eax
  848418:	89 84 24 08 03 00 00 	mov    %eax,0x308(%rsp)
  84841f:	eb 1a                	jmp    84843b <<gpui_gpu::renderer::RendererState>::render+0x1aab>
  848421:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
  848426:	48 8d 41 fb          	lea    -0x5(%rcx),%rax
  84842a:	80 bc 24 b0 00 00 00 	cmpb   $0x0,0xb0(%rsp)
  848431:	00 
  848432:	48 0f 45 c8          	cmovne %rax,%rcx
  848436:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  84843b:	48 8d bc 24 58 02 00 	lea    0x258(%rsp),%rdi
  848442:	00 
  848443:	48 8d b4 24 e8 02 00 	lea    0x2e8(%rsp),%rsi
  84844a:	00 
  84844b:	ff 15 ff 70 67 00    	call   *0x6770ff(%rip)        # ebf550 <_DYNAMIC+0x828>
  848451:	48 8b 84 24 58 02 00 	mov    0x258(%rsp),%rax
  848458:	00 
  848459:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  84845e:	48 85 c0             	test   %rax,%rax
  848461:	0f 84 55 02 00 00    	je     8486bc <<gpui_gpu::renderer::RendererState>::render+0x1d2c>
  848467:	48 8b 8c 24 60 02 00 	mov    0x260(%rsp),%rcx
  84846e:	00 
  84846f:	48 8b 94 24 68 02 00 	mov    0x268(%rsp),%rdx
  848476:	00 
  848477:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
  84847c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  848481:	0f b6 b0 41 03 00 00 	movzbl 0x341(%rax),%esi
  848488:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  84848d:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
  848494:	00 
  848495:	48 89 8c 24 80 00 00 	mov    %rcx,0x80(%rsp)
  84849c:	00 
  84849d:	48 89 8c 24 68 01 00 	mov    %rcx,0x168(%rsp)
  8484a4:	00 
  8484a5:	48 89 94 24 70 01 00 	mov    %rdx,0x170(%rsp)
  8484ac:	00 
  8484ad:	48 8d 84 24 70 02 00 	lea    0x270(%rsp),%rax
  8484b4:	00 
  8484b5:	0f 10 00             	movups (%rax),%xmm0
  8484b8:	0f 10 48 10          	movups 0x10(%rax),%xmm1
  8484bc:	f3 0f 6f 50 20       	movdqu 0x20(%rax),%xmm2
  8484c1:	48 8d 94 24 78 01 00 	lea    0x178(%rsp),%rdx
  8484c8:	00 
  8484c9:	f3 0f 7f 52 20       	movdqu %xmm2,0x20(%rdx)
  8484ce:	0f 11 4a 10          	movups %xmm1,0x10(%rdx)
  8484d2:	0f 11 02             	movups %xmm0,(%rdx)
  8484d5:	48 8d 8c 24 a0 02 00 	lea    0x2a0(%rsp),%rcx
  8484dc:	00 
  8484dd:	0f 10 01             	movups (%rcx),%xmm0
  8484e0:	0f 11 42 30          	movups %xmm0,0x30(%rdx)
  8484e4:	0f 10 40 40          	movups 0x40(%rax),%xmm0
  8484e8:	0f 11 42 40          	movups %xmm0,0x40(%rdx)
  8484ec:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  8484f3:	00 
  8484f4:	e8 67 19 00 00       	call   849e60 <gpui_gpu::renderer::compact_group>
  8484f9:	88 84 24 b0 00 00 00 	mov    %al,0xb0(%rsp)
  848500:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  848505:	48 85 c0             	test   %rax,%rax
  848508:	0f 84 13 ff ff ff    	je     848421 <<gpui_gpu::renderer::RendererState>::render+0x1a91>
  84850e:	48 89 c1             	mov    %rax,%rcx
  848511:	48 c1 e1 02          	shl    $0x2,%rcx
  848515:	0f b6 84 24 b0 00 00 	movzbl 0xb0(%rsp),%eax
  84851c:	00 
  84851d:	8d 14 85 00 00 00 00 	lea    0x0(,%rax,4),%edx
  848524:	48 83 ca fa          	or     $0xfffffffffffffffa,%rdx
  848528:	31 f6                	xor    %esi,%esi
  84852a:	84 c0                	test   %al,%al
  84852c:	40 0f 94 c6          	sete   %sil
  848530:	c1 e6 1f             	shl    $0x1f,%esi
  848533:	89 b4 24 b8 00 00 00 	mov    %esi,0xb8(%rsp)
  84853a:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
  84853f:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  848544:	01 d0                	add    %edx,%eax
  848546:	89 44 24 10          	mov    %eax,0x10(%rsp)
  84854a:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
  84854f:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  848556:	00 
  848557:	8b 54 08 fc          	mov    -0x4(%rax,%rcx,1),%edx
  84855b:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
  848562:	00 
  848563:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
  848568:	e8 e3 cb ff ff       	call   845150 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  84856d:	48 ff 8c 24 00 01 00 	decq   0x100(%rsp)
  848574:	00 
  848575:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  84857a:	48 01 44 24 20       	add    %rax,0x20(%rsp)
  84857f:	8b 84 24 b8 00 00 00 	mov    0xb8(%rsp),%eax
  848586:	0b 44 24 10          	or     0x10(%rsp),%eax
  84858a:	89 84 24 10 04 00 00 	mov    %eax,0x410(%rsp)
  848591:	48 8d 84 24 70 02 00 	lea    0x270(%rsp),%rax
  848598:	00 
  848599:	0f 10 00             	movups (%rax),%xmm0
  84859c:	0f 10 48 10          	movups 0x10(%rax),%xmm1
  8485a0:	0f 10 50 20          	movups 0x20(%rax),%xmm2
  8485a4:	48 8d 94 24 78 01 00 	lea    0x178(%rsp),%rdx
  8485ab:	00 
  8485ac:	0f 11 52 50          	movups %xmm2,0x50(%rdx)
  8485b0:	0f 11 4a 40          	movups %xmm1,0x40(%rdx)
  8485b4:	0f 11 42 30          	movups %xmm0,0x30(%rdx)
  8485b8:	48 8d 8c 24 a0 02 00 	lea    0x2a0(%rsp),%rcx
  8485bf:	00 
  8485c0:	0f 10 01             	movups (%rcx),%xmm0
  8485c3:	0f 11 42 60          	movups %xmm0,0x60(%rdx)
  8485c7:	0f 10 40 40          	movups 0x40(%rax),%xmm0
  8485cb:	0f 11 82 80 00 00 00 	movups %xmm0,0x80(%rdx)
  8485d2:	48 8d 84 24 78 03 00 	lea    0x378(%rsp),%rax
  8485d9:	00 
  8485da:	0f 10 00             	movups (%rax),%xmm0
  8485dd:	0f 11 42 20          	movups %xmm0,0x20(%rdx)
  8485e1:	48 8d 84 24 88 03 00 	lea    0x388(%rsp),%rax
  8485e8:	00 
  8485e9:	0f 10 00             	movups (%rax),%xmm0
  8485ec:	0f 11 42 70          	movups %xmm0,0x70(%rdx)
  8485f0:	48 8b 84 24 70 03 00 	mov    0x370(%rsp),%rax
  8485f7:	00 
  8485f8:	48 89 84 24 90 01 00 	mov    %rax,0x190(%rsp)
  8485ff:	00 
  848600:	0f 10 84 24 40 03 00 	movups 0x340(%rsp),%xmm0
  848607:	00 
  848608:	0f 10 8c 24 50 03 00 	movups 0x350(%rsp),%xmm1
  84860f:	00 
  848610:	f3 0f 6f 94 24 60 03 	movdqu 0x360(%rsp),%xmm2
  848617:	00 00 
  848619:	66 0f 7f 94 24 80 01 	movdqa %xmm2,0x180(%rsp)
  848620:	00 00 
  848622:	0f 29 8c 24 70 01 00 	movaps %xmm1,0x170(%rsp)
  848629:	00 
  84862a:	0f 29 84 24 60 01 00 	movaps %xmm0,0x160(%rsp)
  848631:	00 
  848632:	48 8b 84 24 98 00 00 	mov    0x98(%rsp),%rax
  848639:	00 
  84863a:	48 89 84 24 10 03 00 	mov    %rax,0x310(%rsp)
  848641:	00 
  848642:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  848649:	00 
  84864a:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
  848651:	00 
  848652:	48 8b 84 24 08 04 00 	mov    0x408(%rsp),%rax
  848659:	00 
  84865a:	48 89 84 24 20 03 00 	mov    %rax,0x320(%rsp)
  848661:	00 
  848662:	48 8d 84 24 00 01 00 	lea    0x100(%rsp),%rax
  848669:	00 
  84866a:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
  848671:	00 
  848672:	48 8d 84 24 10 04 00 	lea    0x410(%rsp),%rax
  848679:	00 
  84867a:	48 89 84 24 30 03 00 	mov    %rax,0x330(%rsp)
  848681:	00 
  848682:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  848689:	00 
  84868a:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  84868f:	48 8d 94 24 10 03 00 	lea    0x310(%rsp),%rdx
  848696:	00 
  848697:	e8 f4 c6 ff ff       	call   844d90 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>>
  84869c:	8b 44 24 10          	mov    0x10(%rsp),%eax
  8486a0:	03 44 24 30          	add    0x30(%rsp),%eax
  8486a4:	89 44 24 10          	mov    %eax,0x10(%rsp)
  8486a8:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
  8486ad:	48 83 c1 fc          	add    $0xfffffffffffffffc,%rcx
  8486b1:	0f 85 93 fe ff ff    	jne    84854a <<gpui_gpu::renderer::RendererState>::render+0x1bba>
  8486b7:	e9 65 fd ff ff       	jmp    848421 <<gpui_gpu::renderer::RendererState>::render+0x1a91>
  8486bc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  8486c1:	48 8b 78 28          	mov    0x28(%rax),%rdi
  8486c5:	48 c7 84 24 98 00 00 	movq   $0x0,0x98(%rsp)
  8486cc:	00 00 00 00 00 
  8486d1:	48 85 ff             	test   %rdi,%rdi
  8486d4:	0f 84 ca 00 00 00    	je     8487a4 <<gpui_gpu::renderer::RendererState>::render+0x1e14>
  8486da:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  8486df:	4c 8b 40 20          	mov    0x20(%rax),%r8
  8486e3:	48 c1 e7 03          	shl    $0x3,%rdi
  8486e7:	83 7c 24 38 00       	cmpl   $0x0,0x38(%rsp)
  8486ec:	0f 84 46 06 00 00    	je     848d38 <<gpui_gpu::renderer::RendererState>::render+0x23a8>
  8486f2:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
  8486f9:	00 00 
  8486fb:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
  848702:	00 00 
  848704:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  84870b:	00 00 
  84870d:	45 31 c9             	xor    %r9d,%r9d
  848710:	31 c9                	xor    %ecx,%ecx
  848712:	eb 23                	jmp    848737 <<gpui_gpu::renderer::RendererState>::render+0x1da7>
  848714:	48 ff 44 24 10       	incq   0x10(%rsp)
  848719:	49 ff c1             	inc    %r9
  84871c:	4c 3b 4c 24 38       	cmp    0x38(%rsp),%r9
  848721:	b8 00 00 00 00       	mov    $0x0,%eax
  848726:	4c 0f 44 c8          	cmove  %rax,%r9
  84872a:	48 ff c1             	inc    %rcx
  84872d:	48 83 c7 f8          	add    $0xfffffffffffffff8,%rdi
  848731:	0f 84 88 00 00 00    	je     8487bf <<gpui_gpu::renderer::RendererState>::render+0x1e2f>
  848737:	45 8b 54 c8 04       	mov    0x4(%r8,%rcx,8),%r10d
  84873c:	44 89 d0             	mov    %r10d,%eax
  84873f:	f7 d8                	neg    %eax
  848741:	70 d1                	jo     848714 <<gpui_gpu::renderer::RendererState>::render+0x1d84>
  848743:	45 2b 14 c8          	sub    (%r8,%rcx,8),%r10d
  848747:	74 d0                	je     848719 <<gpui_gpu::renderer::RendererState>::render+0x1d89>
  848749:	48 89 c8             	mov    %rcx,%rax
  84874c:	48 c1 e8 20          	shr    $0x20,%rax
  848750:	74 0f                	je     848761 <<gpui_gpu::renderer::RendererState>::render+0x1dd1>
  848752:	48 89 c8             	mov    %rcx,%rax
  848755:	31 d2                	xor    %edx,%edx
  848757:	48 f7 74 24 38       	divq   0x38(%rsp)
  84875c:	4c 89 ca             	mov    %r9,%rdx
  84875f:	eb 08                	jmp    848769 <<gpui_gpu::renderer::RendererState>::render+0x1dd9>
  848761:	89 c8                	mov    %ecx,%eax
  848763:	31 d2                	xor    %edx,%edx
  848765:	f7 74 24 38          	divl   0x38(%rsp)
  848769:	c1 e2 04             	shl    $0x4,%edx
  84876c:	c1 e0 04             	shl    $0x4,%eax
  84876f:	44 8d 5a 10          	lea    0x10(%rdx),%r11d
  848773:	45 39 de             	cmp    %r11d,%r14d
  848776:	45 0f 42 de          	cmovb  %r14d,%r11d
  84877a:	8d 70 10             	lea    0x10(%rax),%esi
  84877d:	41 39 f7             	cmp    %esi,%r15d
  848780:	41 0f 42 f7          	cmovb  %r15d,%esi
  848784:	41 29 d3             	sub    %edx,%r11d
  848787:	29 c6                	sub    %eax,%esi
  848789:	41 0f af f3          	imul   %r11d,%esi
  84878d:	48 c1 e6 04          	shl    $0x4,%rsi
  848791:	48 01 74 24 18       	add    %rsi,0x18(%rsp)
  848796:	4c 0f af d6          	imul   %rsi,%r10
  84879a:	4c 01 54 24 30       	add    %r10,0x30(%rsp)
  84879f:	e9 75 ff ff ff       	jmp    848719 <<gpui_gpu::renderer::RendererState>::render+0x1d89>
  8487a4:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  8487ab:	00 00 
  8487ad:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
  8487b4:	00 00 
  8487b6:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
  8487bd:	00 00 
  8487bf:	41 f6 c5 01          	test   $0x1,%r13b
  8487c3:	74 53                	je     848818 <<gpui_gpu::renderer::RendererState>::render+0x1e88>
  8487c5:	66 0f 6e 84 24 5c 01 	movd   0x15c(%rsp),%xmm0
  8487cc:	00 00 
  8487ce:	66 0f 7e c0          	movd   %xmm0,%eax
  8487d2:	85 c0                	test   %eax,%eax
  8487d4:	0f 99 c1             	setns  %cl
  8487d7:	89 c2                	mov    %eax,%edx
  8487d9:	81 e2 ff ff ff 7f    	and    $0x7fffffff,%edx
  8487df:	81 c2 00 00 80 ff    	add    $0xff800000,%edx
  8487e5:	81 fa 00 00 00 7f    	cmp    $0x7f000000,%edx
  8487eb:	0f 92 c2             	setb   %dl
  8487ee:	20 ca                	and    %cl,%dl
  8487f0:	ff c8                	dec    %eax
  8487f2:	3d ff ff 7f 00       	cmp    $0x7fffff,%eax
  8487f7:	0f 92 c0             	setb   %al
  8487fa:	08 d0                	or     %dl,%al
  8487fc:	b8 02 00 00 00       	mov    $0x2,%eax
  848801:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
  848808:	00 
  848809:	66 0f 7e 84 24 ec 00 	movd   %xmm0,0xec(%rsp)
  848810:	00 00 
  848812:	0f 84 16 05 00 00    	je     848d2e <<gpui_gpu::renderer::RendererState>::render+0x239e>
  848818:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
  84881f:	00 
  848820:	48 83 c1 18          	add    $0x18,%rcx
  848824:	31 d2                	xor    %edx,%edx
  848826:	48 8b 84 24 b0 03 00 	mov    0x3b0(%rsp),%rax
  84882d:	00 
  84882e:	48 3b 84 24 b8 03 00 	cmp    0x3b8(%rsp),%rax
  848835:	00 
  848836:	0f 95 c2             	setne  %dl
  848839:	31 c0                	xor    %eax,%eax
  84883b:	83 fd 28             	cmp    $0x28,%ebp
  84883e:	0f 94 c0             	sete   %al
  848841:	41 83 e4 01          	and    $0x1,%r12d
  848845:	41 8d 04 84          	lea    (%r12,%rax,4),%eax
  848849:	8d 04 d0             	lea    (%rax,%rdx,8),%eax
  84884c:	0b 84 24 98 00 00 00 	or     0x98(%rsp),%eax
  848853:	0f 10 01             	movups (%rcx),%xmm0
  848856:	0f 11 84 24 68 02 00 	movups %xmm0,0x268(%rsp)
  84885d:	00 
  84885e:	44 89 b4 24 58 02 00 	mov    %r14d,0x258(%rsp)
  848865:	00 
  848866:	44 89 bc 24 5c 02 00 	mov    %r15d,0x25c(%rsp)
  84886d:	00 
  84886e:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
  848873:	89 8c 24 60 02 00 00 	mov    %ecx,0x260(%rsp)
  84887a:	89 84 24 64 02 00 00 	mov    %eax,0x264(%rsp)
  848881:	f3 0f 10 84 24 ec 00 	movss  0xec(%rsp),%xmm0
  848888:	00 00 
  84888a:	f3 0f 11 84 24 78 02 	movss  %xmm0,0x278(%rsp)
  848891:	00 00 
  848893:	48 c7 84 24 7c 02 00 	movq   $0x0,0x27c(%rsp)
  84889a:	00 00 00 00 00 
  84889f:	c7 84 24 84 02 00 00 	movl   $0x0,0x284(%rsp)
  8488a6:	00 00 00 00 
  8488aa:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
  8488af:	49 8d b5 28 02 00 00 	lea    0x228(%r13),%rsi
  8488b6:	48 89 74 24 38       	mov    %rsi,0x38(%rsp)
  8488bb:	48 8d 8c 24 58 02 00 	lea    0x258(%rsp),%rcx
  8488c2:	00 
  8488c3:	41 b8 30 00 00 00    	mov    $0x30,%r8d
  8488c9:	48 8b ac 24 d0 03 00 	mov    0x3d0(%rsp),%rbp
  8488d0:	00 
  8488d1:	48 89 ef             	mov    %rbp,%rdi
  8488d4:	31 d2                	xor    %edx,%edx
  8488d6:	ff 15 7c 6c 67 00    	call   *0x676c7c(%rip)        # ebf558 <_DYNAMIC+0x830>
  8488dc:	49 8b 4d 08          	mov    0x8(%r13),%rcx
  8488e0:	4d 8b 45 10          	mov    0x10(%r13),%r8
  8488e4:	49 c1 e0 04          	shl    $0x4,%r8
  8488e8:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
  8488ef:	00 
  8488f0:	4c 8b a4 24 50 01 00 	mov    0x150(%rsp),%r12
  8488f7:	00 
  8488f8:	4c 89 e6             	mov    %r12,%rsi
  8488fb:	48 89 ea             	mov    %rbp,%rdx
  8488fe:	e8 8d ca ff ff       	call   845390 <<gpui_gpu::renderer::Buffer>::write>
  848903:	49 8d bd 78 02 00 00 	lea    0x278(%r13),%rdi
  84890a:	48 89 bc 24 98 00 00 	mov    %rdi,0x98(%rsp)
  848911:	00 
  848912:	49 8b 4d 20          	mov    0x20(%r13),%rcx
  848916:	4d 8b 45 28          	mov    0x28(%r13),%r8
  84891a:	49 c1 e0 03          	shl    $0x3,%r8
  84891e:	4c 89 e6             	mov    %r12,%rsi
  848921:	48 89 ea             	mov    %rbp,%rdx
  848924:	e8 67 ca ff ff       	call   845390 <<gpui_gpu::renderer::Buffer>::write>
  848929:	49 8d bd a0 02 00 00 	lea    0x2a0(%r13),%rdi
  848930:	48 89 bc 24 90 00 00 	mov    %rdi,0x90(%rsp)
  848937:	00 
  848938:	49 8b 4d 38          	mov    0x38(%r13),%rcx
  84893c:	4d 8b 45 40          	mov    0x40(%r13),%r8
  848940:	49 c1 e0 02          	shl    $0x2,%r8
  848944:	4c 89 e6             	mov    %r12,%rsi
  848947:	48 89 ea             	mov    %rbp,%rdx
  84894a:	e8 41 ca ff ff       	call   845390 <<gpui_gpu::renderer::Buffer>::write>
  84894f:	49 8d bd c8 02 00 00 	lea    0x2c8(%r13),%rdi
  848956:	48 89 7c 24 20       	mov    %rdi,0x20(%rsp)
  84895b:	49 8b 4d 68          	mov    0x68(%r13),%rcx
  84895f:	4d 8b 45 70          	mov    0x70(%r13),%r8
  848963:	49 c1 e0 05          	shl    $0x5,%r8
  848967:	4c 89 e6             	mov    %r12,%rsi
  84896a:	48 89 ea             	mov    %rbp,%rdx
  84896d:	e8 1e ca ff ff       	call   845390 <<gpui_gpu::renderer::Buffer>::write>
  848972:	49 8d 44 24 18       	lea    0x18(%r12),%rax
  848977:	49 8d 8d c8 00 00 00 	lea    0xc8(%r13),%rcx
  84897e:	48 c7 84 24 60 01 00 	movq   $0x0,0x160(%rsp)
  848985:	00 00 00 00 00 
  84898a:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
  84898f:	48 89 94 24 68 01 00 	mov    %rdx,0x168(%rsp)
  848996:	00 
  848997:	48 c7 84 24 88 01 00 	movq   $0x0,0x188(%rsp)
  84899e:	00 00 00 00 00 
  8489a3:	0f 57 c0             	xorps  %xmm0,%xmm0
  8489a6:	0f 11 84 24 70 01 00 	movups %xmm0,0x170(%rsp)
  8489ad:	00 
  8489ae:	c7 84 24 80 01 00 00 	movl   $0x0,0x180(%rsp)
  8489b5:	00 00 00 00 
  8489b9:	48 8b 94 24 c0 02 00 	mov    0x2c0(%rsp),%rdx
  8489c0:	00 
  8489c1:	48 89 94 24 90 01 00 	mov    %rdx,0x190(%rsp)
  8489c8:	00 
  8489c9:	0f 11 84 24 98 01 00 	movups %xmm0,0x198(%rsp)
  8489d0:	00 
  8489d1:	c7 84 24 a8 01 00 00 	movl   $0x1,0x1a8(%rsp)
  8489d8:	01 00 00 00 
  8489dc:	48 c7 84 24 b0 01 00 	movq   $0x0,0x1b0(%rsp)
  8489e3:	00 00 00 00 00 
  8489e8:	48 8b 94 24 98 00 00 	mov    0x98(%rsp),%rdx
  8489ef:	00 
  8489f0:	48 89 94 24 b8 01 00 	mov    %rdx,0x1b8(%rsp)
  8489f7:	00 
  8489f8:	0f 11 84 24 c0 01 00 	movups %xmm0,0x1c0(%rsp)
  8489ff:	00 
  848a00:	c7 84 24 d0 01 00 00 	movl   $0x2,0x1d0(%rsp)
  848a07:	02 00 00 00 
  848a0b:	48 c7 84 24 d8 01 00 	movq   $0x0,0x1d8(%rsp)
  848a12:	00 00 00 00 00 
  848a17:	48 8b 94 24 90 00 00 	mov    0x90(%rsp),%rdx
  848a1e:	00 
  848a1f:	48 89 94 24 e0 01 00 	mov    %rdx,0x1e0(%rsp)
  848a26:	00 
  848a27:	0f 11 84 24 e8 01 00 	movups %xmm0,0x1e8(%rsp)
  848a2e:	00 
  848a2f:	c7 84 24 f8 01 00 00 	movl   $0x3,0x1f8(%rsp)
  848a36:	03 00 00 00 
  848a3a:	48 c7 84 24 00 02 00 	movq   $0x4,0x200(%rsp)
  848a41:	00 04 00 00 00 
  848a46:	48 89 8c 24 08 02 00 	mov    %rcx,0x208(%rsp)
  848a4d:	00 
  848a4e:	c7 84 24 20 02 00 00 	movl   $0x4,0x220(%rsp)
  848a55:	04 00 00 00 
  848a59:	48 c7 84 24 28 02 00 	movq   $0x0,0x228(%rsp)
  848a60:	00 00 00 00 00 
  848a65:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
  848a6a:	48 89 8c 24 30 02 00 	mov    %rcx,0x230(%rsp)
  848a71:	00 
  848a72:	0f 11 84 24 38 02 00 	movups %xmm0,0x238(%rsp)
  848a79:	00 
  848a7a:	c7 84 24 48 02 00 00 	movl   $0x5,0x248(%rsp)
  848a81:	05 00 00 00 
  848a85:	48 8d 0d 0c 87 89 ff 	lea    -0x7678f4(%rip),%rcx        # e1198 <anon.3ceedfc47844159f5932a07258a01292.0.llvm.14111504948212592604+0x2e3c>
  848a8c:	48 89 8c 24 58 03 00 	mov    %rcx,0x358(%rsp)
  848a93:	00 
  848a94:	48 c7 84 24 60 03 00 	movq   $0xa,0x360(%rsp)
  848a9b:	00 0a 00 00 00 
  848aa0:	48 89 84 24 40 03 00 	mov    %rax,0x340(%rsp)
  848aa7:	00 
  848aa8:	48 8d 84 24 60 01 00 	lea    0x160(%rsp),%rax
  848aaf:	00 
  848ab0:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
  848ab7:	00 
  848ab8:	48 c7 84 24 50 03 00 	movq   $0x6,0x350(%rsp)
  848abf:	00 06 00 00 00 
  848ac4:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
  848acb:	00 
  848acc:	4c 89 e7             	mov    %r12,%rdi
  848acf:	ff 15 8b 6a 67 00    	call   *0x676a8b(%rip)        # ebf560 <_DYNAMIC+0x838>
  848ad5:	49 89 c5             	mov    %rax,%r13
  848ad8:	48 89 84 24 10 03 00 	mov    %rax,0x310(%rsp)
  848adf:	00 
  848ae0:	48 8d 94 24 10 03 00 	lea    0x310(%rsp),%rdx
  848ae7:	00 
  848ae8:	4c 89 e7             	mov    %r12,%rdi
  848aeb:	48 8b b4 24 00 04 00 	mov    0x400(%rsp),%rsi
  848af2:	00 
  848af3:	e8 38 cf ff ff       	call   845a30 <<gpui_gpu::renderer::GpuContext>::submit>
  848af8:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  848afd:	31 ed                	xor    %ebp,%ebp
  848aff:	48 8b 84 24 b0 03 00 	mov    0x3b0(%rsp),%rax
  848b06:	00 
  848b07:	48 3b 84 24 b8 03 00 	cmp    0x3b8(%rsp),%rax
  848b0e:	00 
  848b0f:	40 0f 95 c5          	setne  %bpl
  848b13:	c1 e5 1f             	shl    $0x1f,%ebp
  848b16:	44 09 f5             	or     %r14d,%ebp
  848b19:	49 c1 e7 20          	shl    $0x20,%r15
  848b1d:	4c 09 fd             	or     %r15,%rbp
  848b20:	48 8b 03             	mov    (%rbx),%rax
  848b23:	48 85 c0             	test   %rax,%rax
  848b26:	74 0f                	je     848b37 <<gpui_gpu::renderer::RendererState>::render+0x21a7>
  848b28:	f0 48 ff 08          	lock decq (%rax)
  848b2c:	75 09                	jne    848b37 <<gpui_gpu::renderer::RendererState>::render+0x21a7>
  848b2e:	48 89 df             	mov    %rbx,%rdi
  848b31:	ff 15 79 66 67 00    	call   *0x676679(%rip)        # ebf1b0 <_DYNAMIC+0x488>
  848b37:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  848b3c:	4c 89 a8 30 03 00 00 	mov    %r13,0x330(%rax)
  848b43:	48 89 a8 38 03 00 00 	mov    %rbp,0x338(%rax)
  848b4a:	4c 8b 40 10          	mov    0x10(%rax),%r8
  848b4e:	48 8b 70 28          	mov    0x28(%rax),%rsi
  848b52:	48 8b 48 70          	mov    0x70(%rax),%rcx
  848b56:	48 89 8c 24 98 00 00 	mov    %rcx,0x98(%rsp)
  848b5d:	00 
  848b5e:	49 c1 e0 04          	shl    $0x4,%r8
  848b62:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
  848b67:	49 8d 3c 90          	lea    (%r8,%rdx,4),%rdi
  848b6b:	48 8d 34 f7          	lea    (%rdi,%rsi,8),%rsi
  848b6f:	48 89 cf             	mov    %rcx,%rdi
  848b72:	48 c1 e7 05          	shl    $0x5,%rdi
  848b76:	48 8d 0c 37          	lea    (%rdi,%rsi,1),%rcx
  848b7a:	48 83 c1 30          	add    $0x30,%rcx
  848b7e:	48 89 8c 24 90 00 00 	mov    %rcx,0x90(%rsp)
  848b85:	00 
  848b86:	48 8b b8 70 02 00 00 	mov    0x270(%rax),%rdi
  848b8d:	48 03 b8 48 02 00 00 	add    0x248(%rax),%rdi
  848b94:	48 03 b8 98 02 00 00 	add    0x298(%rax),%rdi
  848b9b:	48 03 b8 c0 02 00 00 	add    0x2c0(%rax),%rdi
  848ba2:	48 03 b8 e8 02 00 00 	add    0x2e8(%rax),%rdi
  848ba9:	48 8b b0 00 03 00 00 	mov    0x300(%rax),%rsi
  848bb0:	48 03 b0 08 03 00 00 	add    0x308(%rax),%rsi
  848bb7:	44 8b 88 50 01 00 00 	mov    0x150(%rax),%r9d
  848bbe:	4d 0f af c9          	imul   %r9,%r9
  848bc2:	4c 8b 9c 24 d8 00 00 	mov    0xd8(%rsp),%r11
  848bc9:	00 
  848bca:	4c 89 d9             	mov    %r11,%rcx
  848bcd:	48 29 d1             	sub    %rdx,%rcx
  848bd0:	4c 8b 54 24 48       	mov    0x48(%rsp),%r10
  848bd5:	4d 89 d4             	mov    %r10,%r12
  848bd8:	48 8b ac 24 40 01 00 	mov    0x140(%rsp),%rbp
  848bdf:	00 
  848be0:	49 29 ec             	sub    %rbp,%r12
  848be3:	48 8b 98 60 01 00 00 	mov    0x160(%rax),%rbx
  848bea:	48 ff c3             	inc    %rbx
  848bed:	49 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%r14
  848bf4:	4c 0f 45 f3          	cmovne %rbx,%r14
  848bf8:	48 8b 18             	mov    (%rax),%rbx
  848bfb:	48 c1 e3 04          	shl    $0x4,%rbx
  848bff:	4c 8b 78 48          	mov    0x48(%rax),%r15
  848c03:	4c 03 78 30          	add    0x30(%rax),%r15
  848c07:	4c 8b 68 18          	mov    0x18(%rax),%r13
  848c0b:	4a 8d 1c eb          	lea    (%rbx,%r13,8),%rbx
  848c0f:	4a 8d 1c bb          	lea    (%rbx,%r15,4),%rbx
  848c13:	4c 8b 78 60          	mov    0x60(%rax),%r15
  848c17:	49 c1 e7 05          	shl    $0x5,%r15
  848c1b:	49 01 df             	add    %rbx,%r15
  848c1e:	48 8b 98 38 01 00 00 	mov    0x138(%rax),%rbx
  848c25:	4c 8b a8 30 01 00 00 	mov    0x130(%rax),%r13
  848c2c:	4c 89 b0 60 01 00 00 	mov    %r14,0x160(%rax)
  848c33:	4c 89 90 68 01 00 00 	mov    %r10,0x168(%rax)
  848c3a:	4f 8d 34 1b          	lea    (%r11,%r11,1),%r14
  848c3e:	4c 89 b0 70 01 00 00 	mov    %r14,0x170(%rax)
  848c45:	48 c7 80 78 01 00 00 	movq   $0x1,0x178(%rax)
  848c4c:	01 00 00 00 
  848c50:	4c 89 90 80 01 00 00 	mov    %r10,0x180(%rax)
  848c57:	48 89 90 88 01 00 00 	mov    %rdx,0x188(%rax)
  848c5e:	4c 89 98 90 01 00 00 	mov    %r11,0x190(%rax)
  848c65:	48 89 88 98 01 00 00 	mov    %rcx,0x198(%rax)
  848c6c:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  848c71:	48 89 88 a0 01 00 00 	mov    %rcx,0x1a0(%rax)
  848c78:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
  848c7d:	48 89 88 a8 01 00 00 	mov    %rcx,0x1a8(%rax)
  848c84:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  848c89:	48 89 88 b0 01 00 00 	mov    %rcx,0x1b0(%rax)
  848c90:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
  848c97:	00 
  848c98:	48 89 88 b8 01 00 00 	mov    %rcx,0x1b8(%rax)
  848c9f:	4c 89 80 c0 01 00 00 	mov    %r8,0x1c0(%rax)
  848ca6:	48 8b 94 24 38 01 00 	mov    0x138(%rsp),%rdx
  848cad:	00 
  848cae:	48 89 90 c8 01 00 00 	mov    %rdx,0x1c8(%rax)
  848cb5:	48 89 a8 d0 01 00 00 	mov    %rbp,0x1d0(%rax)
  848cbc:	4c 89 a0 d8 01 00 00 	mov    %r12,0x1d8(%rax)
  848cc3:	48 8b 8c 24 c0 03 00 	mov    0x3c0(%rsp),%rcx
  848cca:	00 
  848ccb:	48 89 88 e0 01 00 00 	mov    %rcx,0x1e0(%rax)
  848cd2:	48 89 b8 e8 01 00 00 	mov    %rdi,0x1e8(%rax)
  848cd9:	4c 89 88 f0 01 00 00 	mov    %r9,0x1f0(%rax)
  848ce0:	49 01 dd             	add    %rbx,%r13
  848ce3:	48 89 98 f8 01 00 00 	mov    %rbx,0x1f8(%rax)
  848cea:	4c 89 a8 00 02 00 00 	mov    %r13,0x200(%rax)
  848cf1:	4c 89 b8 08 02 00 00 	mov    %r15,0x208(%rax)
  848cf8:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
  848cff:	00 
  848d00:	48 89 88 10 02 00 00 	mov    %rcx,0x210(%rax)
  848d07:	48 89 b0 18 02 00 00 	mov    %rsi,0x218(%rax)
  848d0e:	c6 80 20 02 00 00 00 	movb   $0x0,0x220(%rax)
  848d15:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  848d1a:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  848d1f:	48 89 47 08          	mov    %rax,0x8(%rdi)
  848d23:	c7 07 ff ff ff ff    	movl   $0xffffffff,(%rdi)
  848d29:	e9 58 dd ff ff       	jmp    846a86 <<gpui_gpu::renderer::RendererState>::render+0xf6>
  848d2e:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  848d33:	e9 40 dd ff ff       	jmp    846a78 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  848d38:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
  848d3f:	00 00 
  848d41:	31 c0                	xor    %eax,%eax
  848d43:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  848d4a:	00 00 
  848d4c:	eb 12                	jmp    848d60 <<gpui_gpu::renderer::RendererState>::render+0x23d0>
  848d4e:	48 ff 44 24 10       	incq   0x10(%rsp)
  848d53:	48 83 c0 08          	add    $0x8,%rax
  848d57:	48 39 c7             	cmp    %rax,%rdi
  848d5a:	0f 84 56 fa ff ff    	je     8487b6 <<gpui_gpu::renderer::RendererState>::render+0x1e26>
  848d60:	41 8b 4c 00 04       	mov    0x4(%r8,%rax,1),%ecx
  848d65:	89 ca                	mov    %ecx,%edx
  848d67:	f7 da                	neg    %edx
  848d69:	70 e3                	jo     848d4e <<gpui_gpu::renderer::RendererState>::render+0x23be>
  848d6b:	41 39 0c 00          	cmp    %ecx,(%r8,%rax,1)
  848d6f:	74 e2                	je     848d53 <<gpui_gpu::renderer::RendererState>::render+0x23c3>
  848d71:	48 8d 3d 38 44 62 00 	lea    0x624438(%rip),%rdi        # e6d1b0 <anon.75e553ac0202822fbf34f8ff8d529288.29.llvm.12483203287430309740+0x10>
  848d78:	ff 15 ea 67 67 00    	call   *0x6767ea(%rip)        # ebf568 <_DYNAMIC+0x840>
  848d7e:	48 8d 3d 93 42 62 00 	lea    0x624293(%rip),%rdi        # e6d018 <anon.59d2062463a56a48178a879f804ca345.3.llvm.17286516331901804694+0x2b0>
  848d85:	ff 15 05 63 67 00    	call   *0x676305(%rip)        # ebf090 <_DYNAMIC+0x368>
  848d8b:	48 8d 15 9e 42 62 00 	lea    0x62429e(%rip),%rdx        # e6d030 <anon.59d2062463a56a48178a879f804ca345.3.llvm.17286516331901804694+0x2c8>
  848d92:	ff 15 70 64 67 00    	call   *0x676470(%rip)        # ebf208 <_DYNAMIC+0x4e0>
  848d98:	48 8d 15 61 42 62 00 	lea    0x624261(%rip),%rdx        # e6d000 <anon.59d2062463a56a48178a879f804ca345.3.llvm.17286516331901804694+0x298>
  848d9f:	ff 15 63 64 67 00    	call   *0x676463(%rip)        # ebf208 <_DYNAMIC+0x4e0>
  848da5:	49 89 c6             	mov    %rax,%r14
  848da8:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  848dad:	4c 89 a8 30 03 00 00 	mov    %r13,0x330(%rax)
  848db4:	48 89 a8 38 03 00 00 	mov    %rbp,0x338(%rax)
  848dbb:	4c 89 f7             	mov    %r14,%rdi
  848dbe:	e8 1d f0 61 00       	call   e67de0 <_Unwind_Resume@plt>
  848dc3:	49 89 c6             	mov    %rax,%r14
  848dc6:	f0 49 ff 4d 00       	lock decq 0x0(%r13)
  848dcb:	75 20                	jne    848ded <<gpui_gpu::renderer::RendererState>::render+0x245d>
  848dcd:	48 8d bc 24 10 03 00 	lea    0x310(%rsp),%rdi
  848dd4:	00 
  848dd5:	ff 15 d5 63 67 00    	call   *0x6763d5(%rip)        # ebf1b0 <_DYNAMIC+0x488>
  848ddb:	eb 10                	jmp    848ded <<gpui_gpu::renderer::RendererState>::render+0x245d>
  848ddd:	ff 15 ad 61 67 00    	call   *0x6761ad(%rip)        # ebef90 <_DYNAMIC+0x268>
  848de3:	49 89 c6             	mov    %rax,%r14
  848de6:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
  848ded:	4c 89 f7             	mov    %r14,%rdi
  848df0:	e8 eb ef 61 00       	call   e67de0 <_Unwind_Resume@plt>
