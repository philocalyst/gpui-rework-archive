
/tmp/gpui-shared-gpu-controls/1b200d66cfc28a76e4c61b3d154a26055ae908a0/owned:     file format elf64-x86-64


Disassembly of section .text:

0000000000846990 <<gpui_gpu::renderer::RendererState>::render>:
  846990:	55                   	push   %rbp
  846991:	41 57                	push   %r15
  846993:	41 56                	push   %r14
  846995:	41 55                	push   %r13
  846997:	41 54                	push   %r12
  846999:	53                   	push   %rbx
  84699a:	48 81 ec 68 05 00 00 	sub    $0x568,%rsp
  8469a1:	48 8b 86 20 03 00 00 	mov    0x320(%rsi),%rax
  8469a8:	48 3b 42 20          	cmp    0x20(%rdx),%rax
  8469ac:	0f 85 ce 00 00 00    	jne    846a80 <<gpui_gpu::renderer::RendererState>::render+0xf0>
  8469b2:	48 8d 9e 30 03 00 00 	lea    0x330(%rsi),%rbx
  8469b9:	48 8b 86 30 03 00 00 	mov    0x330(%rsi),%rax
  8469c0:	48 85 c0             	test   %rax,%rax
  8469c3:	74 2d                	je     8469f2 <<gpui_gpu::renderer::RendererState>::render+0x62>
  8469c5:	f0 48 ff 08          	lock decq (%rax)
  8469c9:	75 27                	jne    8469f2 <<gpui_gpu::renderer::RendererState>::render+0x62>
  8469cb:	49 89 fe             	mov    %rdi,%r14
  8469ce:	48 89 df             	mov    %rbx,%rdi
  8469d1:	49 89 f4             	mov    %rsi,%r12
  8469d4:	4d 89 c5             	mov    %r8,%r13
  8469d7:	49 89 d7             	mov    %rdx,%r15
  8469da:	48 89 cd             	mov    %rcx,%rbp
  8469dd:	ff 15 cd 87 67 00    	call   *0x6787cd(%rip)        # ebf1b0 <_DYNAMIC+0x488>
  8469e3:	48 89 e9             	mov    %rbp,%rcx
  8469e6:	4c 89 fa             	mov    %r15,%rdx
  8469e9:	4d 89 e8             	mov    %r13,%r8
  8469ec:	4c 89 e6             	mov    %r12,%rsi
  8469ef:	4c 89 f7             	mov    %r14,%rdi
  8469f2:	48 c7 86 30 03 00 00 	movq   $0x0,0x330(%rsi)
  8469f9:	00 00 00 00 
  8469fd:	44 8b 29             	mov    (%rcx),%r13d
  846a00:	44 8b 49 08          	mov    0x8(%rcx),%r9d
  846a04:	0f b6 41 0d          	movzbl 0xd(%rcx),%eax
  846a08:	45 85 c9             	test   %r9d,%r9d
  846a0b:	41 0f 98 c2          	sets   %r10b
  846a0f:	41 81 e1 ff ff ff 7f 	and    $0x7fffffff,%r9d
  846a16:	45 8d 99 00 00 80 ff 	lea    -0x800000(%r9),%r11d
  846a1d:	41 81 fb 00 00 00 7f 	cmp    $0x7f000000,%r11d
  846a24:	41 0f 92 c3          	setb   %r11b
  846a28:	45 20 d3             	and    %r10b,%r11b
  846a2b:	41 8d 69 ff          	lea    -0x1(%r9),%ebp
  846a2f:	81 fd ff ff 7f 00    	cmp    $0x7fffff,%ebp
  846a35:	40 0f 92 c5          	setb   %bpl
  846a39:	44 20 d5             	and    %r10b,%bpl
  846a3c:	45 85 c9             	test   %r9d,%r9d
  846a3f:	41 0f 94 c2          	sete   %r10b
  846a43:	41 81 f9 00 00 80 7f 	cmp    $0x7f800000,%r9d
  846a4a:	41 0f 94 c6          	sete   %r14b
  846a4e:	45 08 d6             	or     %r10b,%r14b
  846a51:	41 81 f9 01 00 80 7f 	cmp    $0x7f800001,%r9d
  846a58:	41 0f 9d c1          	setge  %r9b
  846a5c:	45 08 f1             	or     %r14b,%r9b
  846a5f:	41 08 e9             	or     %bpl,%r9b
  846a62:	45 85 ed             	test   %r13d,%r13d
  846a65:	41 0f 95 c2          	setne  %r10b
  846a69:	41 20 c2             	and    %al,%r10b
  846a6c:	45 08 da             	or     %r11b,%r10b
  846a6f:	45 08 ca             	or     %r9b,%r10b
