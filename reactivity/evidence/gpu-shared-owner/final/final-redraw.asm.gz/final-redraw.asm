
/tmp/gpui-shared-gpu-controls/1b200d66cfc28a76e4c61b3d154a26055ae908a0/owned:     file format elf64-x86-64


Disassembly of section .text:

0000000000846850 <<gpui_gpu::renderer::RendererState>::redraw>:
  846850:	48 89 f8             	mov    %rdi,%rax
  846853:	4c 8b 86 20 03 00 00 	mov    0x320(%rsi),%r8
  84685a:	bf 04 00 00 00       	mov    $0x4,%edi
  84685f:	4c 3b 42 20          	cmp    0x20(%rdx),%r8
  846863:	0f 85 1e 01 00 00    	jne    846987 <<gpui_gpu::renderer::RendererState>::redraw+0x137>
  846869:	48 83 be 30 03 00 00 	cmpq   $0x0,0x330(%rsi)
  846870:	00 
  846871:	0f 84 00 01 00 00    	je     846977 <<gpui_gpu::renderer::RendererState>::redraw+0x127>
  846877:	8b be 38 03 00 00    	mov    0x338(%rsi),%edi
  84687d:	44 8b 86 3c 03 00 00 	mov    0x33c(%rsi),%r8d
  846884:	81 e7 ff ff ff 7f    	and    $0x7fffffff,%edi
  84688a:	49 c1 e0 20          	shl    $0x20,%r8
  84688e:	49 09 f8             	or     %rdi,%r8
  846891:	bf 03 00 00 00       	mov    $0x3,%edi
  846896:	4c 39 41 20          	cmp    %r8,0x20(%rcx)
  84689a:	0f 85 e7 00 00 00    	jne    846987 <<gpui_gpu::renderer::RendererState>::redraw+0x137>
  8468a0:	44 8b 41 38          	mov    0x38(%rcx),%r8d
  8468a4:	44 3b 42 28          	cmp    0x28(%rdx),%r8d
  8468a8:	0f 85 d9 00 00 00    	jne    846987 <<gpui_gpu::renderer::RendererState>::redraw+0x137>
  8468ae:	41 83 f8 4c          	cmp    $0x4c,%r8d
  8468b2:	75 22                	jne    8468d6 <<gpui_gpu::renderer::RendererState>::redraw+0x86>
  8468b4:	f3 0f 7e 41 3c       	movq   0x3c(%rcx),%xmm0
  8468b9:	f3 0f 7e 4a 2c       	movq   0x2c(%rdx),%xmm1
  8468be:	66 0f 76 c8          	pcmpeqd %xmm0,%xmm1
  8468c2:	66 0f 70 c1 50       	pshufd $0x50,%xmm1,%xmm0
  8468c7:	66 44 0f 50 c0       	movmskpd %xmm0,%r8d
  8468cc:	41 83 f8 03          	cmp    $0x3,%r8d
  8468d0:	0f 85 b1 00 00 00    	jne    846987 <<gpui_gpu::renderer::RendererState>::redraw+0x137>
  8468d6:	41 56                	push   %r14
  8468d8:	53                   	push   %rbx
  8468d9:	50                   	push   %rax
  8468da:	48 89 c3             	mov    %rax,%rbx
  8468dd:	48 8d 86 30 03 00 00 	lea    0x330(%rsi),%rax
  8468e4:	48 89 d7             	mov    %rdx,%rdi
  8468e7:	49 89 f6             	mov    %rsi,%r14
  8468ea:	48 89 ce             	mov    %rcx,%rsi
  8468ed:	48 89 c2             	mov    %rax,%rdx
  8468f0:	e8 3b f1 ff ff       	call   845a30 <<gpui_gpu::renderer::GpuContext>::submit>
  8468f5:	48 89 c1             	mov    %rax,%rcx
  8468f8:	49 8b 96 60 01 00 00 	mov    0x160(%r14),%rdx
  8468ff:	49 8b 86 28 03 00 00 	mov    0x328(%r14),%rax
  846906:	48 ff c2             	inc    %rdx
  846909:	48 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%rsi
  846910:	48 0f 45 f2          	cmovne %rdx,%rsi
  846914:	49 89 b6 60 01 00 00 	mov    %rsi,0x160(%r14)
  84691b:	41 c6 86 20 02 00 00 	movb   $0x1,0x220(%r14)
  846922:	01 
  846923:	49 c7 86 b8 01 00 00 	movq   $0x0,0x1b8(%r14)
  84692a:	00 00 00 00 
  84692e:	49 c7 86 e0 01 00 00 	movq   $0x0,0x1e0(%r14)
  846935:	00 00 00 00 
  846939:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
  84693d:	66 41 0f 11 86 68 01 	movupd %xmm0,0x168(%r14)
  846944:	00 00 
  846946:	49 c7 86 78 01 00 00 	movq   $0x0,0x178(%r14)
  84694d:	00 00 00 00 
  846951:	48 85 c0             	test   %rax,%rax
  846954:	74 08                	je     84695e <<gpui_gpu::renderer::RendererState>::redraw+0x10e>
  846956:	48 c7 40 60 00 00 00 	movq   $0x0,0x60(%rax)
  84695d:	00 
  84695e:	48 89 d8             	mov    %rbx,%rax
  846961:	48 c7 43 08 01 00 00 	movq   $0x1,0x8(%rbx)
  846968:	00 
  846969:	ba 10 00 00 00       	mov    $0x10,%edx
  84696e:	48 83 c4 08          	add    $0x8,%rsp
  846972:	5b                   	pop    %rbx
  846973:	41 5e                	pop    %r14
  846975:	eb 07                	jmp    84697e <<gpui_gpu::renderer::RendererState>::redraw+0x12e>
  846977:	ba 08 00 00 00       	mov    $0x8,%edx
  84697c:	31 c9                	xor    %ecx,%ecx
  84697e:	48 89 0c 10          	mov    %rcx,(%rax,%rdx,1)
  846982:	bf ff ff ff ff       	mov    $0xffffffff,%edi
  846987:	89 38                	mov    %edi,(%rax)
  846989:	c3                   	ret
