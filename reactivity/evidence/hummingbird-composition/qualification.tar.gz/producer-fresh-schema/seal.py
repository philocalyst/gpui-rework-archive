from pathlib import Path
import subprocess,json,hashlib,re
out=Path(__file__).parent;root=Path.cwd();base='64162234a00b1a0ecb32535e020566f1b59568e8';pin=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();prefix='reactivity/ports/hummingbird/'
assert not subprocess.check_output(['git','status','--porcelain'],text=True)
def sha(data):return hashlib.sha256(data).hexdigest()
paths=subprocess.check_output(['git','diff','--name-only',base,pin],text=True).splitlines()
with (out/'fresh-schema-final.patch').open('wb') as f:subprocess.run(['git','diff','--binary',base,pin,'--',prefix],stdout=f,check=True)
for name,ref in [('baseline', 'f77446dddecbebc756132e03eb185eae108782e2'),('fresh-before-admission','6b4b572146e38f24cc7d33030cd9df7036be042b'),('negative','45d5c3182406f930d9876528fc2e8655ac8b098e'),('final',pin)]:
 available=set(subprocess.check_output(['git','ls-tree','-r','--name-only',ref,'--',prefix],text=True).splitlines())
 for p in paths:
  if p in available:
   q=out/'source-snapshots'/name/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(subprocess.check_output(['git','show',ref+':'+p]))
 metadata=json.loads(Path(prefix+'FRESH-SCHEMA.json').read_text())
 migrations={p:sha(Path(prefix+p).read_bytes()) for p in metadata['ordered_migrations']}
 assert migrations==metadata['ordered_migrations']
 assert all(subprocess.check_output(['git','show',base+':'+prefix+p])==Path(prefix+p).read_bytes() for p in migrations)
ledger=json.loads((out/'first-final-ledger.json').read_text());bill=json.loads((out/'source-bill.json').read_text());default=json.loads((out/'default-summary.json').read_text())
production=[p for p in paths if p.startswith(prefix+'src/') or p.endswith('fresh.sql') or p.endswith('Cargo.toml')]
tested=json.loads((out/'final-source-before.json').read_text())['paths'];assert all(tested[p]==sha(Path(p).read_bytes()) for p in production)
license_paths=[p for p in subprocess.check_output(['git','ls-files',prefix],text=True).splitlines() if 'LICENSE' in Path(p).name or Path(p).name=='UPSTREAM.json']
report={'base':base,'final':pin,'production_pin':'2bcb96a82026ce37fceb1a600eea292194441896','patch':{'path':str(out/'fresh-schema-final.patch'),'sha256':sha((out/'fresh-schema-final.patch').read_bytes())},'source_paths':{p:sha(Path(p).read_bytes()) for p in paths},'core_vendor_delta':bill['core_path_delta'],'tested_production_equal':True,'lockfile_equal':subprocess.check_output(['git','show',base+':'+prefix+'Cargo.lock'])==Path(prefix+'Cargo.lock').read_bytes(),'migration_count':len(migrations),'migrations_unchanged':True,'license_provenance':{p:sha(Path(p).read_bytes()) for p in license_paths},'default':default,'strict_default_exit':int((out/'strict-default.exit').read_text()),'format_exit':int((out/'final-format.exit').read_text()),'gates':ledger['gates'],'syscalls':ledger['syscalls'],'source_bill':{'base_rust':bill['baseline']['non_test_rust_lines'],'final_rust':bill['final']['non_test_rust_lines'],'separate':{p:{'physical':d['physical_lines'],'bytes':d['bytes'],'code':d['tokei']['Total']['code']} for p,d in bill['separate'].items()}},'negative':json.loads((out/'admission-negative.json').read_text()),'scope':'Application SQLite startup/work deletion and ownership admission only. Normal disk durability unchanged. No native/foreign/hardware/latency/RSS/allocator/whole-code claims. Existing original641 default/native120s indexing timeouts and strict101 remain failed in Root evidence. Earlier Files/DSP adverse history unchanged.'}
(out/'final-ledger.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'pin':pin,'patch':report['patch'],'paths':len(paths),'default':default['totals'],'strict':report['strict_default_exit'],'format':report['format_exit'],'migration_count':len(migrations),'source_bill':report['source_bill']},indent=2))
