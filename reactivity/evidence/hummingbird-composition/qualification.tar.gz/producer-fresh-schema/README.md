# Fresh library schema / atomic admission qualification

Final source `db72fb087d24bc4366394e5a8bc3589419f0a622` in `/root/gpui-hummingbird-fresh-schema-sol`, based exactly on `64162234a00b1a0ecb32535e020566f1b59568e8`. Tested Rust/SQL production is byte-identical to `2bcb96a82026ce37fceb1a600eea292194441896`; the final commit changes documentation/offline generator metadata only. The tree is clean. Root alone adopts.

Patch: `fresh-schema-final.patch`, SHA256 `a4e8e4eab504e08dbaeff309617ea9baa1650044fe74e4210c987741d1aadbd2`. `final-ledger.json` is the machine report; source snapshots, all raw logs/traces, commands, binaries and negative source are retained separately. No source from Root's frozen integration tree was changed.

## Deleted work / preserved contract

Fresh creation directly executes the final canonical pinned schema. The 39 untouched upstream migrations are an independent test oracle, no longer embedded or replayed in production. One IMMEDIATE transaction covers ownership admission, final DDL, original seed expressions and marker, validation and commit. Existing schema1 reopens without DDL or seeding. Future versions require an explicit upgrade policy; this is not an upstream read-write migration API. The existing upstream read-only path is unchanged. The worker's three acquisition tables remain at its existing admission boundary, now one ordinary transaction instead of three autocommits. No pragma, journal, synchronous or fsync relaxation; no new worker, queue, retained mirror, allocation cache, build dependency or runtime second database.

The offline generator serializes SQLite's stored final object SQL, preserving relative trigger creation order. It retains the original Liked Songs INSERT/default clock expressions and later position UPDATE, never an oracle timestamp. SQLite owns its internal tables/autoincrement sequence. Generator output is checked byte-for-byte. Pinned original migration bytes and upstream license/provenance remain unchanged.

Unmarked admission rejects any user schema object, with exact `sqlite_*` internal-name matching; a marker must be a table. This is the existing worker-controlled ownership protocol, not protection against an external writer forging the ownership table. Worker source publication scope is unchanged.

## Qualification

Full default suite: 70 passed, 0 failed, 2 explicitly ignored syscall controls. Strict all-target default Clippy on genuine nightly and the tracked root policy: exit 0. Scoped port rustfmt: exit 0. No global formatting or core/vendor changes.

Independent bundled-SQLite oracle compares complete sqlite_schema SQL, columns/generated/defaults, foreign keys, indexes/autoindexes, trigger order, real fixture data, seed clock semantics, acquisition schema, SQLite-owned autoincrement state/behavior, foreign-key integrity, late creation failure rollback/retry, no-write reopen, concurrent public creators and unknown/future database rejection. The original unchanged seven-case indexing module passed its original 120-second outer TERM/5-second-kill bound on its first final-source run; full suite includes it too. This does not relabel either original Root default/native indexing timeout as a pass.

The old public view-only, fake marker view and `sqlitexyz` schedules all failed with admission on frozen test-only pin `45d5c3182406f930d9876528fc2e8655ac8b098e` over production6b. Exact test source, ELF hash and exit101 are in `admission-negative.json`; fixed tests pass. The genuine-nightly `fetch_update` deprecation is corrected narrowly to `try_update`. Original Root strict101 logs remain original failures.

## Untimed syscall controls

All controls use the same physical runtime executable and fresh database path per capture, fixed watchdog, strace without timing fields, normal durability, no retries. Constructor logs assert foreign_keys=1, synchronous=2, journal=delete, original seed and marker. Baseline constructor production is exact641. The additional source-admission baseline is the new fresh schema with old three-autocommit acquisition setup, isolating that second change. It uses public Database→Worker construction and ordinary finish. Counts include complete process startup, not just one function.

| Scope | Old fsync | New fsync | Old pwrite64 | New pwrite64 | Old/new closed DB bytes |
|---|---:|---:|---:|---:|---:|
| Public fresh constructor | 392 | 4 | 1010 | 44 | 172032/172032 |
| Public constructor→Worker admission | 16 | 8 | 90 | 70 | 204800/204800 |

All captures exit0. Full individual syscall categories/traces and command/binary hashes are saved. Operational test elapsed output is retained, but no speed, native latency, allocator/RSS or codegen claim is made. Baseline/candidate test feature graphs differ by test-only rusqlite hooks APIs; the feature adds no package/version and no hooks are installed in these public syscall probes. Production dependency and lockfile are unchanged; do not treat these debug test artifacts as matched production machine-code bills.

## Source/resource charge and limits

Syn/Tokei non-test port Rust: 8085→7936. This excludes migrations.rs only because its sole import is now cfg(test), not because its bytes disappeared from the repository. Separate shipped fresh SQL: 213 code/290 physical lines/8749 bytes. Offline generator: 78 code/88 physical/4290 bytes. Provenance JSON: 191 lines/8287 bytes. Tests and metadata remain fully charged separately in physical patch/source snapshots. Core/vendor path delta is empty. No retained application type changes; no measured heap/assembly claim.

No additional native/foreign-target/hardware campaign was run for this app-only successor. Root's original three Registry clients remain separate controls over641; Root can run composition qualification on this narrow patch. All earlier Files limitations, path-owner adverse live-allocation/header costs, RIFF metadata lifetime, DSP rate caps, unresolved old tail controls, unfavorable constructor cohort, CPAL pause/fade and EOF polling findings remain unchanged. This does not add artwork/settings/platform media/watchers or claim full Hummingbird parity.
