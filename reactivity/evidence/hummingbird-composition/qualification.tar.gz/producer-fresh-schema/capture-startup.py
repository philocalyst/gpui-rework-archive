from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys
out=Path(__file__).parent;mode=sys.argv[1];assert mode in ['baseline','candidate']
source=out/(mode+'-startup');runtime=out/'startup-control';database=out/'startup.sqlite'
assert not database.exists();assert not (out/(mode+'-startup.trace')).exists()
shutil.copy2(source,runtime);sha=hashlib.sha256(source.read_bytes()).hexdigest()
command=['timeout','--signal=TERM','--kill-after=5s','120s','strace','-f','-o',str(out/(mode+'-startup.trace')),'-e','trace=fsync,fdatasync,pwrite64,ftruncate,openat,close,fcntl,unlink',str(runtime),'--exact','public_fresh_library_syscall_control','--ignored','--nocapture']
(out/(mode+'-startup.command.json')).write_text(json.dumps({'command':command,'env':{'GPUI_SCHEMA_PROBE_PATH':str(database)},'sha256':sha,'scope':'Untimed syscall counts on original/candidate public persistent constructor, same physical runtime and DB path. Normal SQLite durability and original120s bound; failures/timeouts preserved, no retry.'},indent=2)+'\n')
env=dict(os.environ,GPUI_SCHEMA_PROBE_PATH=str(database))
with (out/(mode+'-startup.log')).open('w') as log:code=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
assert hashlib.sha256(runtime.read_bytes()).hexdigest()==sha
(out/(mode+'-startup.exit')).write_text(str(code)+'\n')
if database.exists():database.rename(out/(mode+'-startup.sqlite'))
raise SystemExit(code)
