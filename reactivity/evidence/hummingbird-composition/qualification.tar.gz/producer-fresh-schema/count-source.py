from pathlib import Path
import sys,json,tempfile,subprocess,hashlib
sys.path.insert(0,str(Path('reactivity/tools').resolve()))
import inventory,core_lines
out=Path(__file__).parent
helper=Path('/tmp/gpui-inventory-sol-target/release/inventory-rust')
tokei=Path('/nix/store/4m90mv0fyihsdrnidw8gkgmx6zvd5vqm-tokei-15.0.0/bin/tokei')
prefix='reactivity/ports/hummingbird/'
def count(ref):
 paths=subprocess.check_output(['git','ls-tree','-r','--name-only',ref,'--',prefix+'src'],text=True).splitlines()
 sources=[(p,subprocess.check_output(['git','show',ref+':'+p]),'Rust') for p in paths if p.endswith('.rs')]
 analyses=inventory.rust_analysis(sources,helper)
 tests=inventory.resolve_modules(analyses,sources,explicit_roots={prefix+'src/lib.rs',prefix+'src/main.rs'})
 with tempfile.TemporaryDirectory(prefix='fresh-schema-lines-') as temp:
  staging=Path(temp)
  for p,data,lang in sources:
   if p in tests:continue
   q=staging/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(core_lines.without_tests(data.decode(),analyses[p]['test_ranges']))
  raw=json.loads(subprocess.check_output([str(tokei),'--no-ignore','--files','--output','json',str(staging)],text=True))
  reports={str(Path(r['name']).relative_to(staging)):r['stats']['code'] for lang,s in raw.items() if lang!='Total' for r in s['reports']}
 return {'ref':ref,'non_test_rust_lines':sum(reports.values()),'files':reports,'test_only_modules':sorted(tests)}
base='64162234a00b1a0ecb32535e020566f1b59568e8';head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
result={'baseline':count(base),'final':count(head),'separate':{},'core_path_delta':subprocess.check_output(['git','diff','--name-only',base,head,'--','reactivity/crates','reactivity/vendor'],text=True).splitlines()}
for p in ['schema/fresh.sql','tools/generate-fresh-schema.py','FRESH-SCHEMA.json']:
 path=Path(prefix+p);raw=json.loads(subprocess.check_output([str(tokei),'--no-ignore','--files','--output','json',str(path)],text=True));result['separate'][p]={'physical_lines':len(path.read_text().splitlines()),'bytes':path.stat().st_size,'tokei':raw}
result['counter_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();result['helper_sha256']=hashlib.sha256(helper.read_bytes()).hexdigest();result['tokei_sha256']=hashlib.sha256(tokei.read_bytes()).hexdigest()
(out/'source-bill.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'baseline_rust':result['baseline']['non_test_rust_lines'],'final_rust':result['final']['non_test_rust_lines'],'core_delta':result['core_path_delta'],'separate':{p:{k:v for k,v in d.items() if k!='tokei'} for p,d in result['separate'].items()}},indent=2))
