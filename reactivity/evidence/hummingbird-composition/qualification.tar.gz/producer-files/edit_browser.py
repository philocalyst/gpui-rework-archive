from pathlib import Path
root=Path('/root/gpui-hummingbird-files-sol/reactivity/ports/hummingbird/src')
p=root/'browser.rs';s=p.read_text();s=s.replace('use triomphe::Arc;','use triomphe::Arc;\nuse std::path::PathBuf;')
s=s.replace('#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]\npub enum Route', '#[derive(Clone, Debug, Default, PartialEq, Eq)]\npub enum Route')
s=s.replace('    Tracks,\n    Albums,','    Tracks,\n    Files,\n    Directory(PathBuf),\n    Albums,',1)
s=s.replace("pub fn label(self) -> &'static str", "pub fn label(&self) -> &'static str")
s=s.replace('            Self::Tracks => "Tracks",','            Self::Tracks => "Tracks",\n            Self::Files => "Files",\n            Self::Directory(_) => "Directory",',1)
s=s.replace('pub fn current(&self) -> Route {\n        self.history[self.cursor]\n','pub fn current(&self) -> &Route {\n        &self.history[self.cursor]\n')
s=s.replace('self.domain.checked_add(2)', 'self.domain.checked_add(4)')
s=s.replace('self.navigation.current() == input.route', 'self.navigation.current() == &input.route')
s=s.replace('button("Tracks").on_click(Self::NAV.update(|nav| nav.navigate(Route::Tracks))),','button("Tracks").on_click(Self::NAV.update(|nav| nav.navigate(Route::Tracks))),\n                button("Files").on_click(Self::NAV.update(|nav| nav.navigate(Route::Files))),')
s=s.replace('Route::Albums | Route::Artists | Route::Playlists\n', 'Route::Albums | Route::Artists | Route::Playlists | Route::Files | Route::Directory(_)\n')
s=s.replace('                    Route::Artists => "Artist name order",','                    Route::Artists => "Artist name order",\n                    Route::Files | Route::Directory(_) => "File name order",')
s=s.replace('match (self.route, self.sort)', 'match (&self.route, self.sort)')
s=s.replace('route: navigation.current(),', 'route: navigation.current().clone(),')
s=s.replace('    Track(i64),\n', '    Track(i64),\n    File(usize),\n',1)
a=s.index('#[derive(Clone, Debug, PartialEq, Eq)]\npub struct PlayRequest');b=s.index('#[derive(Debug)]\npub struct PreparedListing',a)
s=s[:a]+'''#[derive(Clone, Debug)]
pub enum Listing {
    Sql(Arc<Input>),
    Files(Arc<crate::files::FileListing>),
}
impl Listing {
    pub fn input(&self) -> &Arc<Input> {
        match self {
            Self::Sql(input) => input,
            Self::Files(files) => &files.input,
        }
    }
}
impl PartialEq for Listing {
    fn eq(&self, other: &Self) -> bool {
        match (self, other) {
            (Self::Sql(a), Self::Sql(b)) => a == b,
            (Self::Files(a), Self::Files(b)) => Arc::ptr_eq(a, b),
            _ => false,
        }
    }
}
impl Eq for Listing {}
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct PlayRequest {
    pub listing: Listing,
    pub start: Option<RowKey>,
    pub sequence: u64,
}
impl PlayRequest {
    pub fn input(&self) -> &Arc<Input> { self.listing.input() }
    pub fn stamp(&self) -> PlayStamp {
        PlayStamp { input: self.input().clone(), start: self.start, sequence: self.sequence }
    }
}
/// Completed actions retain authority, never the filesystem listing's paths.
#[derive(Debug)]
pub struct PlayStamp {
    pub input: Arc<Input>,
    pub start: Option<RowKey>,
    pub sequence: u64,
}
'''+s[b:]
s=s.replace('    pub route: Route,\n    pub id: i64,', '    pub kind: CollectionKind,\n    pub id: i64,')
s=s.replace('#[derive(Debug)]\npub struct CollectionRow', '''#[derive(Clone, Copy, Debug)]
pub enum CollectionKind { Album, Artist, Playlist }
impl CollectionKind {
    pub fn route(self, id: i64) -> Route {
        match self { Self::Album => Route::Album(id), Self::Artist => Route::Artist(id), Self::Playlist => Route::Playlist(id) }
    }
}
#[derive(Debug)]
pub struct CollectionRow''')
s=s.replace('pub struct Page {\n', 'pub struct LibraryPage {\n')
s=s.replace('impl Page {\n', 'impl LibraryPage {\n',1)
s=s.replace('            RowKey::PlaylistItem { item, .. } => item,','            RowKey::PlaylistItem { item, .. } => item,\n            RowKey::File(_) => unreachable!("SQL track identity"),')
s=s.replace('let route = item.route;', 'let route = item.kind.route(item.id);')
s=s.replace('model.open_collection(&input, route)', 'model.open_collection(&input, route.clone())')
s=s.replace('assert_eq!(navigation.current(), Route::Tracks);','assert_eq!(navigation.current(), &Route::Tracks);')
pos=s.index('impl ItemSource for TrackRows')
s=s[:pos]+'''pub enum Page {
    Library(LibraryPage),
    Files(Arc<crate::files::FileListing>),
}
impl Page {
    pub fn input(&self) -> &Arc<Input> {
        match self { Self::Library(page) => page.input(), Self::Files(page) => &page.input }
    }
    pub fn library(&self) -> Option<&LibraryPage> {
        match self { Self::Library(page) => Some(page), Self::Files(_) => None }
    }
    pub fn ids(&self) -> impl Iterator<Item = i64> + '_ {
        self.library().into_iter().flat_map(LibraryPage::ids)
    }
    pub fn track_list(&self) -> ListId {
        match self { Self::Library(page) => page.track_list(), Self::Files(page) => page.list() }
    }
}
'''+s[pos:]
p.write_text(s)
p=root/'collection_query.rs';s=p.read_text().replace('CollectionRow, Collections, Input, Page, PlayRequest, PreparedListing, Route, TrackRows,','CollectionKind, CollectionRow, Collections, Input, LibraryPage, Page, PlayRequest, PreparedListing, Route, TrackRows,')
s=s.replace('match input.route {', 'match &input.route {').replace('if let Route::Artist(id) = input.route {', 'if let Route::Artist(id) = &input.route {').replace('values.push(id.into());','values.push((*id).into());')
s=s.replace('tracks().from_album(id)', 'tracks().from_album(*id)').replace('tracks().from_artist(id)', 'tracks().from_artist(*id)')
s=s.replace('''                        route: match kind {
                            0 => Route::Album(id),
                            1 => Route::Artist(id),
                            _ => Route::Playlist(id),
                        },''','''                        kind: match kind {
                            0 => CollectionKind::Album,
                            1 => CollectionKind::Artist,
                            _ => CollectionKind::Playlist,
                        },''')
s=s.replace('Ok(Some(Page {\n', 'Ok(Some(Page::Library(LibraryPage {\n').replace('''            collections,
        }))''','''            collections,
        })))''')
s=s.replace('request.input.clone()', 'request.input().clone()')
s=s.replace('''    let _snapshot = database.connection().unchecked_transaction()?;
    let rows = read_tracks''','''    if let crate::browser::Listing::Files(files) = &request.listing {
        return files.prepare(request.start);
    }
    let _snapshot = database.connection().unchecked_transaction()?;
    let rows = read_tracks''')
p.write_text(s)
p=root/'worker.rs';s=p.read_text().replace('request.input.version', 'request.input().version')
s=s.replace('let mut searcher = Searcher::default();', 'let mut searcher = Searcher::default();\n                let mut file_domain = 3_u64;',1)
s=s.replace('''                                crate::collection_query::page(
                                    &database,''','''                                if matches!(input.route, crate::browser::Route::Files | crate::browser::Route::Directory(_)) {
                                    let Some(next) = file_domain.checked_add(4).filter(|n| *n < u64::MAX) else {
                                        return Some(Err(SourceError::IndexExhausted));
                                    };
                                    file_domain = next;
                                    return crate::files::page(&database, &mut searcher, input, file_domain, || cancellation.is_cancelled());
                                }
                                crate::collection_query::page(
                                    &database,''')
p.write_text(s)
p=root/'lib.rs';s=p.read_text().replace('pub mod indexing;', 'pub mod indexing;\npub mod files;');p.write_text(s)
