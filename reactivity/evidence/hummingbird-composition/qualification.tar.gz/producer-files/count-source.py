import hashlib,json,pathlib,subprocess,sys,tempfile
root=pathlib.Path('/root/gpui-hummingbird-files-sol');sys.path.insert(0,str(root/'reactivity/tools'))
import inventory,core_lines
helper=pathlib.Path('/tmp/gpui-inventory-sol-target/release/inventory-rust')
tokei=pathlib.Path('/nix/store/4m90mv0fyihsdrnidw8gkgmx6zvd5vqm-tokei-15.0.0/bin/tokei')
def count(ref,prefix):
 paths=subprocess.check_output(['git','ls-tree','-r','--name-only',ref,'--',prefix],cwd=root,text=True).splitlines()
 sources=[(p,subprocess.check_output(['git','show',ref+':'+p],cwd=root),'Rust') for p in paths if p.endswith('.rs')]
 a=inventory.rust_analysis(sources,helper);tests=inventory.resolve_modules(a,sources);entries={}
 with tempfile.TemporaryDirectory(prefix='gpui-files-lines-') as d:
  stage=pathlib.Path(d)
  for p,data,lang in sources:
   entries[p]={'sha256':hashlib.sha256(data).hexdigest(),'test_only':p in tests,'unclassified':a[p].get('unclassified',[]),'lines':0}
   if p in tests:continue
   dest=stage/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(core_lines.without_tests(data.decode(),a[p]['test_ranges']))
  result=json.loads(subprocess.check_output([str(tokei),'--no-ignore','--files','--output','json',str(stage)],text=True))
  for lang,summary in result.items():
   if lang=='Total':continue
   for r in summary['reports']:entries[pathlib.Path(r['name']).relative_to(stage).as_posix()]['lines']=r['stats']['code']
 return {'ref':ref,'prefix':prefix,'files':entries,'non_test_code_lines':sum(x['lines'] for x in entries.values()),'scope':'Syn removes test syntax; Tokei own source reports exclude comments/blanks/doc examples; unknown feature syntax remains charged.'}
out=pathlib.Path(__file__).parent
final=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
record={'baseline':count('282b1c09b9d0a49fc52df3a890d67381c8747f6d','reactivity/ports/hummingbird/src'),'candidate':count(final,'reactivity/ports/hummingbird/src'),'vendor':count(final,'reactivity/vendor/symphonia-format-riff/src'),'helper_sha256':hashlib.sha256(helper.read_bytes()).hexdigest(),'tokei_sha256':hashlib.sha256(tokei.read_bytes()).hexdigest()}
record['delta']=record['candidate']['non_test_code_lines']-record['baseline']['non_test_code_lines'];(out/'source-lines.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:(v['non_test_code_lines'] if isinstance(v,dict) else v) for k,v in record.items()}))
