# Files application handoff

Source is clean at `1df152ea25758bdd83885b1a1e2a5dd427bb541b` in `/root/gpui-hummingbird-files-sol`,
exact base `282b1c09b9d0a49fc52df3a890d67381c8747f6d`. Apply **only** `files-final.patch`,
SHA-256 `74d93b332e14b76aa2977d9f05146e8fdb149412b2749fc60d0395c45a2e6911`. `final-source-export.json` gives all
38 source paths/hashes. Production, clients, manifests and RIFF
match native-qualified `5fda6e4f09af19f02125824f619560c48f9b9a9b`;
`1585008fca3e831938fa558af52696612263f381` adds the exact non-UTF8 test;
remaining commits change documentation only. Core/library/vendor text-layout
and lint policy paths are unchanged from the base. No Main writes or whole
ancestry import. Root's newer lockfile removals must survive: apply hunks rather
than overwrite the old full lockfile. Current Root library composition is a
separate source requiring its own app gates.

`closure.json`, `compiler-inputs.json`, the full source guards, original commands,
logs and normal Cargo artifacts are the qualification ledger. Default passed
63 cases; native passed
135 with
one original ignored. Strict default/native both passed. Original default,
original collections and Files actual Registry clients passed on the frozen
normal release ELF; no replacement dispatcher, hardware or timing claim.
The non-UTF8 default run completed unchanged after saved ext4 journal waits.
No retry, fsync pragma, fixture reduction, watchdog change or weakened assertion.

`resource-summary.json` shows the feature cost and every prefix-owner tradeoff;
`constructor-cost-ledger.json` preserves all four original cold/warm cohorts.
The original282 control freshly reproduces its frozen counts and binary hash.
`directory-cost-ledger.json` retains every sample and semantic digest for the full
real fixture; `cost-real-input` preserves its bytes and `files-cost-input.json`
its original absolute-path hashes. The raw initial byte difference comes from
frozen argv0 path lengths, so application requested work is shown from initial.
All raw counters remain. Peaks are cumulative, not isolated per-phase bounds.
Header figures overlap their owners. C/SQLite/OS/device/allocator internals/RSS
are excluded. No whole-player memory ceiling or universal resource claim.

Prefix ownership reduces representative bytes/total requests but adds a listing
header and one retained/peak allocation. Empty-root and directory-only old-sheet
retirement caveats remain explicit. `owner-code-bill.json` charges every allocated
section of both normal linked callers and path rlibs; full assembly/symbol/frame
outputs preserve aliases and unfavorable/new/removed functions.
`owner-frame-summary.json` charges both adverse shared CFA increases. CFA is not
a whole call-stack bound. No linked native binary or speed improvement is claimed.

First-party application source is 8085
non-test code lines versus 6571 at base;
shipping first-party core adds zero paths/lines. The complete licensed upstream
RIFF package has 1957 non-test source lines,
charged separately. Only the documented two-line WAVE metadata ownership change
adapts upstream code. Complete MPL license, archive/source provenance and exact
patch are preserved. The corrected reader intentionally retains INFO metadata
until reader retirement; arbitrary tagged-media retention is not bounded by the
constructor/untagged directory fixture. No duplicate application RIFF parser.
Default metadata dependency/ordinary compile work is a feature cost, not a cold
compile benchmark. No common normal-control dependency version drift occurred.

The initial conservative pre-sample cost interruption, corrected audit, initial
API/type/strict failures and actual WAV INFO/NUL failures remain separate. The
original f83 negative ELF is preserved. The 26e6 NUL-failure ELF was overwritten
before capture: only its exact source and actual output are claimed. Existing
negative source pins are not rewritten. No processing timing repair/rerun hides
old baseline panics or the adverse constructor cohort. `full-port-gaps.json` and
shipping FILES/AUDIO/PORT documents keep every remaining feature, admission,
CPAL pause, backend EOF/control polling and startup lifetime limitation explicit.

All finite child processes exited, selected production source is restored clean,
and no further feature/build/test/native work is scheduled. Root reviews/adopts.
