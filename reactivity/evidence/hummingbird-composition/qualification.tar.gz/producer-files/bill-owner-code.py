import pathlib,struct,subprocess,json,hashlib,re,collections,bisect
out=pathlib.Path(__file__).parent
def sections(data):
    if data[:4]!=b'\x7fELF': return None
    wide=data[4]==2;order='<' if data[5]==1 else '>'
    shoff=struct.unpack_from(order+('Q' if wide else 'I'),data,40 if wide else 32)[0]
    stride,count,strings=struct.unpack_from(order+'HHH',data,58 if wide else 46)
    fmt=order+('IIQQQQIIQQ' if wide else 'IIIIIIIIII')
    def sec(i):return struct.unpack_from(fmt,data,shoff+i*stride)
    first=sec(0)
    if count==0:count=first[5]
    if strings==0xffff:strings=first[6]
    names=sec(strings);names=data[names[4]:names[4]+names[5]]
    result=[]
    for i in range(1,count):
        s=sec(i);end=names.find(b'\0',s[0]);name=names[s[0]:end].decode('utf8')
        result.append((name,s[5],s[2]))
    return result


def bill(path):
 data=path.read_bytes();values=[];members=[]
 if path.suffix=='.rlib':
  for member in subprocess.check_output(['ar','t',str(path)],text=True).splitlines():
   payload=subprocess.check_output(['ar','p',str(path),member]);s=sections(payload)
   members.append({'member':member,'bytes':len(payload),'elf':s is not None})
   if s is not None:values.extend(s)
 else:values=sections(data);assert values is not None
 allocated=collections.Counter()
 for name,size,flags in values:
  if flags&2:allocated[name]+=size
 categories={c:sum(size for name,size in allocated.items()if name==c or name.startswith(c+'.'))for c in ['.text','.rodata','.data','.bss','.eh_frame','.gcc_except_table']}
 return {'sha256':hashlib.sha256(data).hexdigest(),'file_bytes':len(data),'allocated_section_bytes':sum(allocated.values()),'categories':categories,'allocated_sections':dict(sorted(allocated.items())),'archive_members':members}

def frames(folder,target):
 fdes=[];current=None
 for line in (folder/(target+'.objdump.txt')).read_text().splitlines():
  match=re.search(r'FDE cie=.* pc=([0-9a-f]+)\.\.([0-9a-f]+)',line)
  if match:current={'start':int(match[1],16),'end':int(match[2],16),'cfa_rows':[]};fdes.append(current)
  elif ' CIE' in line:current=None
  elif current is not None:
   row=re.match(r'^([0-9a-f]{16})\s+(\S+)',line)
   if row:current['cfa_rows'].append({'address':int(row[1],16),'cfa':row[2]})
 fdes.sort(key=lambda x:x['start']);starts=[x['start']for x in fdes];rows=[];aliases=collections.defaultdict(list)
 for line in (folder/(target+'.nm.txt')).read_text().splitlines():
  m=re.match(r'^([0-9a-f]+)\s+([0-9a-f]+)\s+(\w)\s+(.+)$',line)
  if not m:continue
  address,size,kind,name=int(m[1],16),int(m[2],16),m[3],m[4]
  if kind not in 'tTwW' or not any(s in name for s in ['hummingbird_gpui_port::files::','hummingbird_gpui_port::app::','hummingbird_gpui_port::worker::','FileRows','FileListing']):continue
  i=bisect.bisect_right(starts,address)-1;fde=fdes[i]if i>=0 and fdes[i]['start']<=address<fdes[i]['end']else None
  forms=sorted({x['cfa']for x in fde['cfa_rows']})if fde else []
  offsets=[int(m[1])for form in forms if(m:=re.fullmatch(r'rsp\+(\d+)',form))]
  rows.append({'name':name,'address':address,'symbol_bytes':size,'max_observed_rsp_cfa_offset':max(offsets)if offsets else None,'cfa_forms':forms,'fde':fde});aliases[address,size].append(name)
 return {'scope':'All emitted Files/app/worker aliases in this linked ordinary release caller. DWARF CFA observations include save/return slots and are not full call-stack/dynamic-stack bounds. Missing rows are unknown, not zero. No alias byte sums.','symbols':rows,'alias_groups':[{'address':a,'symbol_bytes':s,'names':n}for(a,s),n in aliases.items()if len(n)>1]}

data={};frame_data={}
for mode in ['absolute','prefix']:
 folder=out/('cost-'+mode+'-artifacts');manifest=json.loads((folder/'artifacts.json').read_text());data[mode]={};frame_data[mode]={}
 for target,entry in manifest.items():
  path=folder/target if target in ['constructor','files']else pathlib.Path(entry['file'])
  assert hashlib.sha256(path.read_bytes()).hexdigest()==entry['sha256'];data[mode][target]=bill(path)
 for target in ['constructor','files']:frame_data[mode][target]=frames(folder,target)
comparison={}
for target in data['absolute']:
 a,b=data['absolute'][target],data['prefix'][target]
 comparison[target]={'absolute':a,'prefix':b,'delta':{k:b[k]-a[k]for k in ['file_bytes','allocated_section_bytes']},'category_delta':{k:b['categories'][k]-a['categories'][k]for k in a['categories']}}
frame_comparison={}
for target in ['constructor','files']:
 a={r['name']:r for r in frame_data['absolute'][target]['symbols']};b={r['name']:r for r in frame_data['prefix'][target]['symbols']}
 frame_comparison[target]={'shared_changes':[{'name':name,'absolute_symbol_bytes':a[name]['symbol_bytes'],'prefix_symbol_bytes':b[name]['symbol_bytes'],'absolute_cfa':a[name]['max_observed_rsp_cfa_offset'],'prefix_cfa':b[name]['max_observed_rsp_cfa_offset']}for name in sorted(a.keys()&b.keys())if(a[name]['symbol_bytes'],a[name]['max_observed_rsp_cfa_offset'])!=(b[name]['symbol_bytes'],b[name]['max_observed_rsp_cfa_offset'])],'absolute_only':[a[n]for n in sorted(a.keys()-b.keys())],'prefix_only':[b[n]for n in sorted(b.keys()-a.keys())]}
(out/'owner-code-bill.json').write_text(json.dumps({'scope':'Matched same physical application/caller source/build path, locked normal cpal-output release graph. Whole archive object allocated sections include unused code, not mapped pages/RSS. Executable and archive reports separate, not additive. Metadata/file bytes separately charged. No speed claim.','targets':comparison},indent=2)+'\n')
(out/'owner-frame-bill.json').write_text(json.dumps({'variants':frame_data,'comparison':frame_comparison},indent=2)+'\n')
print(json.dumps({k:{'delta':v['delta'],'category_delta':v['category_delta']}for k,v in comparison.items()},indent=2))
