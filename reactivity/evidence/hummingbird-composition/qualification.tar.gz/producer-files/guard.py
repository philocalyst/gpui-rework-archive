import pathlib,json,hashlib,subprocess,sys
root=pathlib.Path('/root/gpui-hummingbird-files-sol');out=pathlib.Path(__file__).parent
paths=set(json.loads(pathlib.Path('/tmp/gpui-hummingbird-one-engine-evidence-sol/final-source.json').read_text()))
port=root/'reactivity/ports/hummingbird'
for directory in ['src','tests','examples','migrations','assets/audio']:
 paths.update(str(f.relative_to(root)) for f in (port/directory).rglob('*') if f.is_file() and '__pycache__' not in f.parts)
paths.update(['reactivity/ports/hummingbird/Cargo.toml','reactivity/ports/hummingbird/Cargo.lock','reactivity/ports/hummingbird/native-service.py','reactivity/ports/hummingbird/native-files.py','clippy.toml','.cargo/config.toml'])
paths.update(str(f.relative_to(root)) for f in (root/'reactivity/vendor/symphonia-format-riff').rglob('*') if f.is_file())
actual={path:hashlib.file_digest((root/path).open('rb'),'sha256').hexdigest() for path in sorted(paths)}
manifest=out/(sys.argv[2]+'-source.json')
if sys.argv[1]=='freeze':
 assert not manifest.exists();manifest.write_text(json.dumps(actual,indent=2)+'\n')
else:assert actual==json.loads(manifest.read_text())
assert not subprocess.check_output(['git','-C',str(root),'status','--porcelain'],text=True)
print(json.dumps({'head':subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip(),'paths':len(actual),'matched':True}))
