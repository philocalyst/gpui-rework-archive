#!/usr/bin/env bash
source /tmp/gpui-hummingbird-files-env-sol.sh
set -u
root=/root/gpui-hummingbird-files-sol
capture=/tmp/gpui-hummingbird-files-evidence-sol
export CLIPPY_CONF_DIR=$root
cd "$root"
run_gate() {
    local name=$1
    shift
    test ! -e "$capture/$name.command" || exit 90
    printf '%q ' "$@" > "$capture/$name.command"
    printf '\n' >> "$capture/$name.command"
    "$@" > "$capture/$name.jsonl" 2> "$capture/$name.log"
    local code=$?
    printf '%s\n' "$code" > "$capture/$name.exit"
    if [ "$code" -ne 0 ]; then exit "$code"; fi
}
run_gate whole-default cargo test --offline --locked --manifest-path reactivity/ports/hummingbird/Cargo.toml --message-format=json
run_gate strict-default cargo clippy --offline --locked --manifest-path reactivity/ports/hummingbird/Cargo.toml --all-targets --message-format=json -- -D warnings
run_gate whole-native cargo test --offline --locked --manifest-path reactivity/ports/hummingbird/Cargo.toml --features native --message-format=json
run_gate strict-native cargo clippy --offline --locked --manifest-path reactivity/ports/hummingbird/Cargo.toml --all-targets --features native --message-format=json -- -D warnings
run_gate native-release cargo build --release --offline --locked --manifest-path reactivity/ports/hummingbird/Cargo.toml --features native --example native_service --message-format=json
