from pathlib import Path
root=Path('/root/gpui-hummingbird-files-sol/reactivity/ports/hummingbird/src')
p=root/'worker.rs';s=p.read_text();a=s.index('''                    let Some(command) = command else {''');b=s.index('''                    match command {''',a)
progress=s[a:b]
progress=progress.replace('''                    let Some(command) = command else {
                        let active = scan.as_mut().expect("scan progress turn");''','''                    if let Some(active) = scan.as_mut() {''')
progress=progress.replace('''                            Err(error) => (version, Err(error)),''','''                            Err(error) => {
                                if indexing::clear(&database).is_err() { break; }
                                (version, Err(error))
                            },''')
progress=progress.replace('''                    };
''','''                    }
''',1) if False else progress
# Last semicolon belonged to let-else; ordinary if has no trailing semicolon.
assert progress.endswith('''                    };
''')
progress=progress[:-len('''                    };
''')]+'''                    }
'''
s=s[:a]+'''                    if let Some(command) = command {
'''+s[b:]
end=s.index('''                        Command::Stop => break,
                    }
                }
''',a)
s=s[:end]+s[end:].replace('''                        Command::Stop => break,
                    }
                }
''','''                        Command::Stop => break,
                    }
                    }
'''+progress+'''                }
''',1)
a=s.index('''                                if scan.take().is_some() {''');b=s.index('''                                match command {''',a)
s=s[:a]+'''                                if cancel_scan(&mut scan, &database, &updates, version).is_err() { break; }
'''+s[b:]
s=s.replace('''                                            Err(error) => Err(error),''','''                                            Err(error) => {
                                                if indexing::clear(&database).is_err() { break; }
                                                Err(error)
                                            },''',1)
s=s.replace('''                            if scan.take().is_some() && indexing::clear(&database).is_err() {
                                break;
                            }''','''                            if cancel_scan(&mut scan, &database, &updates, version).is_err() {
                                break;
                            }''')
pos=s.index('fn next_revision(')
s=s[:pos]+'''/// Interruption resolves the accepted task on the existing bounded lane. If
/// terminal delivery fails, the caller closes the producer and native owners
/// observe that close instead of retaining an impossible Pending task.
fn cancel_scan(
    scan: &mut Option<indexing::Scan>,
    database: &Database,
    updates: &Remote<LibraryEvent>,
    version: Version,
) -> Result<(), SourceError> {
    if let Some(active) = scan.take() {
        indexing::clear(database)?;
        updates.try_send(LibraryEvent::Indexed {
            request: active.request,
            version,
            result: Ok(indexing::Outcome::Canceled),
        }).map_err(|_| SourceError::NotificationsUnavailable)?;
    }
    Ok(())
}
'''+s[pos:];p.write_text(s)
p=root/'files.rs';s=p.read_text().replace('use nucleo_matcher::pattern', 'use rusqlite::OptionalExtension;\nuse nucleo_matcher::pattern')
s=s.replace('''pub(crate) fn prepare(&self, start: Option<RowKey>)''','''pub(crate) fn prepare(&self, database: &Database, start: Option<RowKey>)''')
s=s.replace('''        let mut tracks = Vec::with_capacity(self.recording_count());''','''        let _snapshot = database.connection().unchecked_transaction()?;
        let mut metadata = database.connection().prepare("SELECT id,album_id,title FROM track WHERE location=?")?;
        let mut tracks = Vec::with_capacity(self.recording_count());''')
s=s.replace('''            tracks.push(TrackRef::new(Track {
                path: entry.path.clone(),
                title: entry.label().into_owned(),
                track_id: None,
                album_id: None,''','''            let indexed = entry.path.to_str().map(|location| {
                metadata.query_row([location], |row| Ok((row.get::<_,i64>(0)?, row.get::<_,Option<i64>>(1)?, row.get::<_,String>(2)?))).optional()
            }).transpose()?.flatten();
            let (track_id, album_id, title) = indexed.map_or_else(
                || (None, None, entry.label().into_owned()),
                |(id, album, title)| (Some(id), album, title),
            );
            tracks.push(TrackRef::new(Track {
                path: entry.path.clone(),
                title,
                track_id,
                album_id,''')
p.write_text(s)
p=root/'collection_query.rs';s=p.read_text().replace('return files.prepare(request.start);','return files.prepare(database, request.start);');p.write_text(s)
p=root/'app.rs';s=p.read_text().replace('.name("Library files").w(900)', '.name("Library files").w(650)').replace('.w(900)', '.w(650)');p.write_text(s)
