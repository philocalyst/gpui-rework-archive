//! Diagnostic all-Rust-thread requested-allocation ledger, no time measurement.
//! System/C/OS allocations and allocator internals are outside this scope.
use gpui::{LaneSet, Win, WindowOptions};
use hummingbird_gpui_port::{app::{Library,connect},browser::Route,database::Database,indexing::Command,transcript::settle,worker::Worker};
use std::{alloc::{GlobalAlloc,Layout,System},path::PathBuf,sync::atomic::{AtomicI64,AtomicU64,Ordering},time::{Duration,Instant}};
struct Counting;
static REQUESTS:AtomicU64=AtomicU64::new(0);
static BYTES:AtomicU64=AtomicU64::new(0);
static LIVE_COUNT:AtomicI64=AtomicI64::new(0);
static LIVE_BYTES:AtomicI64=AtomicI64::new(0);
static PEAK_COUNT:AtomicI64=AtomicI64::new(0);
static PEAK_BYTES:AtomicI64=AtomicI64::new(0);
unsafe impl GlobalAlloc for Counting {
    unsafe fn alloc(&self,layout:Layout)->*mut u8 {
        let pointer=unsafe{System.alloc(layout)};
        if !pointer.is_null() {
            REQUESTS.fetch_add(1,Ordering::SeqCst);BYTES.fetch_add(layout.size() as u64,Ordering::SeqCst);
            let count=LIVE_COUNT.fetch_add(1,Ordering::SeqCst)+1;
            let bytes=LIVE_BYTES.fetch_add(layout.size() as i64,Ordering::SeqCst)+layout.size() as i64;
            PEAK_COUNT.fetch_max(count,Ordering::SeqCst);PEAK_BYTES.fetch_max(bytes,Ordering::SeqCst);
        }
        pointer
    }
    unsafe fn dealloc(&self,pointer:*mut u8,layout:Layout) {
        LIVE_COUNT.fetch_sub(1,Ordering::SeqCst);LIVE_BYTES.fetch_sub(layout.size() as i64,Ordering::SeqCst);
        unsafe{System.dealloc(pointer,layout)};
    }
    // Keep default realloc/alloc_zeroed semantics: realloc accounts for a
    // separate requested allocation and old retirement, as allocation-counter.
}
#[global_allocator]
static ALLOCATOR:Counting=Counting;
#[derive(Clone,Copy,Debug)]
struct Counts{requests:u64,requested:u64,live_count:i64,live_bytes:i64,peak_count:i64,peak_bytes:i64}
fn snapshot()->Counts {
    Counts{requests:REQUESTS.load(Ordering::SeqCst),requested:BYTES.load(Ordering::SeqCst),live_count:LIVE_COUNT.load(Ordering::SeqCst),live_bytes:LIVE_BYTES.load(Ordering::SeqCst),peak_count:PEAK_COUNT.load(Ordering::SeqCst),peak_bytes:PEAK_BYTES.load(Ordering::SeqCst)}
}
fn acquire<L:LaneSet<Library>>(win:&mut Win<Library,L>,worker:&Worker) {
    let deadline=Instant::now()+Duration::from_secs(15);
    while win.with_model(Library::indexing_request).unwrap().is_some(){
        assert!(Instant::now()<deadline,"acquisition terminal missing");
        worker.checkpoint().unwrap().recv_timeout(Duration::from_secs(10)).unwrap();win.deliver_ready(32).unwrap();std::thread::yield_now();
    }
    settle(win,worker).unwrap();
}
fn main() {
    let root=PathBuf::from(std::env::args().nth(1).expect("fixed real fixture directory"));
    println!("START"); // Initialize stdout before any reported application phase.
    let initial=snapshot();
    let database=Database::fixture().unwrap();
    let (worker,inbox)=Worker::new(database).unwrap();let(model,questions)=connect(worker.handle()).unwrap();
    let mut win=Win::with_questions(model,questions,WindowOptions{size:[720,1100],..Default::default()}).unwrap().with_inbox_status(inbox,Library::receive).unwrap();
    settle(&mut win,&worker).unwrap();let mounted=snapshot();
    win.update(|model|model.request_index(Command::AddRoot(root.clone()))).unwrap();acquire(&mut win,&worker);
    win.update(|model|model.navigate(Route::Files)).unwrap();settle(&mut win,&worker).unwrap();let roots=snapshot();
    win.activate(win.button(&format!("Open {}",root.display()))).unwrap();settle(&mut win,&worker).unwrap();let directory=snapshot();
    let reader=win.with_model(|model|model.results).unwrap();let entries=win.with_ready(reader,|page|match page{hummingbird_gpui_port::browser::Page::Files(files)=>files.entries.len(),_=>panic!("Files page")}).unwrap().unwrap();
    assert_eq!(entries,256,"full fixed fixture must remain intact");
    let semantic=win.inspect().unwrap().to_json().unwrap();
    println!("SEMANTIC {semantic}");drop(semantic);
    win.update(|model|model.navigate(Route::Tracks)).unwrap();settle(&mut win,&worker).unwrap();let away=snapshot();
    drop(win);worker.finish().unwrap();let closed=snapshot();
    println!("HEADERS Library={} FileListing={} Entry={} Page={} Event={} Request={} Report={} Outcome={} Error={} Input={}",size_of::<Library>(),size_of::<hummingbird_gpui_port::files::FileListing>(),size_of::<hummingbird_gpui_port::files::Entry>(),size_of::<hummingbird_gpui_port::browser::Page>(),size_of::<hummingbird_gpui_port::worker::LibraryEvent>(),size_of::<hummingbird_gpui_port::indexing::Request>(),size_of::<hummingbird_gpui_port::indexing::Report>(),size_of::<hummingbird_gpui_port::indexing::Outcome>(),size_of::<hummingbird_gpui_port::search::SourceError>(),size_of::<hummingbird_gpui_port::browser::Input>());
    for(name,count)in[("initial",initial),("mounted",mounted),("roots",roots),("directory",directory),("away",away),("closed",closed)]{
        println!("PHASE {name} requests={} requested={} live_count={} live_bytes={} peak_count={} peak_bytes={}",count.requests,count.requested,count.live_count,count.live_bytes,count.peak_count,count.peak_bytes);
    }
    println!("ENTRIES {entries}");
}
