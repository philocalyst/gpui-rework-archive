import bisect,collections,hashlib,json,pathlib,re,struct,subprocess
out=pathlib.Path(__file__).parent

def constructor(path):
 rows=[]
 for line in path.read_text().splitlines():
  if not line.startswith('COHORT '):continue
  head,tail=line.split(' spawn=',1);row={'cohort':int(head.split()[1]),'headers':{k:int(v)for k,v in re.findall(r'(\w+)=(\d+)',head)}}
  for phase,body in re.findall(r'(spawn|connected|mounted)=AllocationInfo \{([^}]+)\}','spawn='+tail):row[phase]={k:int(v)for k,v in re.findall(r'(\w+): (-?\d+)',body)}
  assert len(row)==5;rows.append(row)
 assert len(rows)==4
 return rows

def directory(path):
 text=path.read_text();phases={}
 for name,body in re.findall(r'^PHASE (\w+) (.+)$',text,re.M):phases[name]={k:int(v)for k,v in re.findall(r'(\w+)=(-?\d+)',body)}
 assert set(phases)=={'initial','mounted','roots','directory','away','closed'}
 semantic=[x.removeprefix('SEMANTIC ')for x in text.splitlines()if x.startswith('SEMANTIC ')];assert len(semantic)==1
 json.loads(semantic[0]);headers=[x for x in text.splitlines()if x.startswith('HEADERS ')];assert len(headers)==1
 count=int(re.search(r'^ENTRIES (\d+)$',text,re.M)[1]);assert count==256
 return {'phases':phases,'headers':{k:int(v)for k,v in re.findall(r'(\w+)=(\d+)',headers[0])},'entries':count,'semantic_sha256':hashlib.sha256(semantic[0].encode()).hexdigest(),'deltas_from_initial':{name:{k:v-phases['initial'][k]for k,v in values.items()}for name,values in phases.items()}}

def delta(a,b):return {k:b[k]-a[k]for k in a}
base=constructor(out/'cost-browser282-constructor-runtime.log');absolute=constructor(out/'cost-absolute-constructor.log');prefix=constructor(out/'cost-prefix-constructor.log')
old=json.loads(pathlib.Path('/tmp/gpui-hummingbird-one-engine-evidence-sol/final-constructor-ledger.json').read_text())['candidate']
record={'scope':'Original calling-thread Rust constructor cohorts; header fields overlap. Phase peaks cannot be summed. Worker/C/SQLite/OS/device/RSS and allocator internal work excluded. Fresh original282 frozen control; new prefix/absolute same physical source+caller path and lock/flags. No timings.','browser282':base,'browser282_matches_original_frozen_counters':base==old,'absolute':absolute,'prefix':prefix,'prefix_minus_absolute':[{'cohort':b['cohort'],**{section:delta(a[section],b[section])for section in ['headers','spawn','connected','mounted']}}for a,b in zip(absolute,prefix)],'feature_prefix_minus_browser282':[{'cohort':b['cohort'],**{section:delta(a[section],b[section])for section in ['headers','spawn','connected','mounted']}}for a,b in zip(base,prefix)]}
(out/'constructor-cost-ledger.json').write_text(json.dumps(record,indent=2)+'\n')
samples={mode:[directory(out/f'cost-{mode}-files-{i}.log')for i in range(3)]for mode in ['absolute','prefix']}
semantics={r['semantic_sha256']for group in samples.values()for r in group};assert len(semantics)==1
report={'scope':'All Rust-thread requested allocations for fixed full real directory fixture/public UI and real worker; C/SQLite/OS/device/RSS and allocator internals excluded. Every sample kept. Cumulative snapshots/peaks are not phase-specific peaks. Semantic inspect/print after directory sample contributes to later cumulative samples. Public settle/checkpoint iterations may change total diagnostic requests. No timing.','samples':samples,'all_semantics_equal':True,'ranges':{mode:{phase:{key:{'min':min(row['phases'][phase][key]for row in group),'max':max(row['phases'][phase][key]for row in group)}for key in group[0]['phases'][phase]}for phase in group[0]['phases']}for mode,group in samples.items()},'headers':{mode:group[0]['headers']for mode,group in samples.items()},'header_delta':delta(samples['absolute'][0]['headers'],samples['prefix'][0]['headers'])}
fixtures=json.loads((out/'files-cost-input.json').read_text())['entries'];actual={name:hashlib.sha256(pathlib.Path(name).read_bytes()).hexdigest()for name in fixtures};assert actual==fixtures
report['real_fixture_guard']={'matched':True,'files':len(fixtures)}
(out/'directory-cost-ledger.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'constructor_equal_original':record['browser282_matches_original_frozen_counters'],'prefix_minus_absolute':record['prefix_minus_absolute'],'feature_deltas':record['feature_prefix_minus_browser282'],'directory_header_delta':report['header_delta'],'directory_semantics_equal':True},indent=2))
