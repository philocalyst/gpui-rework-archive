# Real library roots, indexing and Files

Base is the exact frozen 282b1c09 application/core tree. Only a new isolated
checkout may change. Current OneEngine readers, source, ELF and adverse evidence
stay untouched. No successor builds while the current compiler list is active.
No timing, hardware, complete metadata/provider or full application parity claim.

Persistent new-library SQLite owns roots and the index. Existing upstream
libraries keep their explicit read-only open path. Adding a root and browsing
Files never start a scan or playback. Explicit Scan/Rescan and Cancel reuse the
existing bounded command/result lanes and the existing worker. Between discovery
or metadata units it processes commands; idle blocks on recv. Cancellation takes
effect when processed, before another work unit/final apply; a currently blocking
filesystem/media operation or SQLite apply is not preempted. No second worker,
queue, polling tick, backend, source mirror or implicit continuation is added.

Index metadata is staged in private SQLite TEMP tables, not in an unbounded
Rust vector or the public track tables. Ordinary pure SQL questions therefore
keep reading committed library data while the scanner works. Cancel discards
staging. Final transactional apply preserves IDs at unchanged paths, then commits
before publishing Version and before any completion/checkpoint acknowledgement.
Metadata replacements/deletions advance generation as well as revision, revoking
old named and listing prepared leases. Add-only imports can preserve generation.
Source authority still precedes Audio authority for the existing application
queue transaction. No query/progress/scan completion grants playback permission.

The initial metadata scope is the existing Symphonia WAV/FLAC/MP3 formats:
title, artists, album, track/disc number and container duration. Reuse the existing
dependency rather than introduce another provider/executor. Its activation in
default indexing is a feature cost and must be charged. Artwork, watchers,
platform media, complete settings/metadata providers remain absent. Non-UTF8
filesystem paths retain PathBuf identity for browsing/playback; the existing
UTF8 SQLite location schema must reject/report unsupported indexing rather than
silently replace bytes. Symlink traversal, overlapping roots, missing roots and
explicit destructive removal need visible, deterministic semantics.

Files uses the same existing Question and bounded navigation history. A canonical
immutable file listing is shared once for owned playback continuation: exact
paths/order, not a second filesystem query or filename/hash identity, authorize
Play-all/from-here. A fresh checked list domain for each Files answer prevents
ordinal row keys from rebinding old presented rows. SQL recording/playlist
occurrence IDs remain exact. Reuse the existing listing preparation/result/state
and Receipt conditional queue commit rather than add a parallel playback lane.
Source/route/query/request/selection/Receipt changes and close reject stale work.

Fixtures and gates retain the original four cold/warm constructor cohorts,
original public SQL/collection/queue/service tests and Registry clients/watchdogs.
Add persistent restart, tagged real WAV/FLAC/MP3, Unicode/same-label paths,
overlap/symlink/missing/malformed paths, cancellation and source replacement,
metadata update/deletion with buffered old named/listing Prepared, exact queue
occurrence/clone Stop/Pause/Seek, Files exact ordered playback and normal native
WM close. Track identity for external renames must not be claimed without proof;
no hash collision or lossy-label shortcut. All failures/source/binary guards and
unfavorable resource/code/feature costs remain separate from passing controls.
Application/source/core counts are separate; shipping core stays byte-identical.
