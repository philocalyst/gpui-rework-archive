import hashlib,json,pathlib,shutil,subprocess,tomllib,collections
root=pathlib.Path('/root/gpui-hummingbird-files-sol');out=pathlib.Path(__file__).parent;fixture=out/'cost-fixture';source=root/'reactivity/ports/hummingbird/src/files.rs'
py='/nix/store/9r02ykx9y35lf4gk6gc30gnag1y8ncp7-python3-3.13.15/bin/python3'
fixed='/tmp/gpui-hummingbird-files-allocation-input/Καφέ-long-directory-prefix-for-exact-owned-path-and-unicode-fixture'
selected=source.read_bytes();absolute=(out/'absolute-files-e543.rs').read_bytes();manifest=json.loads((out/'final-default-source.json').read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def guard(mode):
 actual={p:sha(root/p) for p in manifest}
 expected=manifest.copy()
 if mode=='absolute':expected['reactivity/ports/hummingbird/src/files.rs']=hashlib.sha256(absolute).hexdigest()
 assert actual==expected,mode+' source guard'
 return actual
def run(name,command,timeout=None):
 assert not (out/(name+'.command.json')).exists()
 (out/(name+'.command.json')).write_text(json.dumps(command,indent=2)+'\n')
 with (out/(name+'.log')).open('w') as log:
  try:code=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=timeout).returncode
  except subprocess.TimeoutExpired:code=124
 (out/(name+'.exit')).write_text(str(code)+'\n')
 assert code==0,(name,code)
def freeze(mode):
 folder=out/('cost-'+mode+'-artifacts');folder.mkdir()
 artifacts=[]
 for line in (out/('cost-'+mode+'-build.log')).read_text().splitlines():
  try:v=json.loads(line)
  except json.JSONDecodeError:continue
  if v.get('reason')=='compiler-artifact':artifacts.append(v)
 saved={}
 for v in artifacts:
  target=v['target']['name']
  if v.get('executable') and target in ['constructor','files']:
   src=pathlib.Path(v['executable']);dest=folder/target;shutil.copy2(src,dest);saved[target]={'sha256':sha(dest),'cargo':v}
  if target in ['hummingbird_gpui_port','gpui','gpui_reactivity_core','gpui_canvas','gpui_reactivity_state'] and 'lib' in v['target']['kind']:
   libs=[pathlib.Path(p) for p in v['filenames'] if p.endswith('.rlib')];assert len(libs)==1
   dest=folder/libs[0].name;shutil.copy2(libs[0],dest);saved[target]={'sha256':sha(dest),'file':str(dest),'cargo':v}
 assert 'constructor' in saved and 'files' in saved and 'hummingbird_gpui_port' in saved
 (folder/'artifacts.json').write_text(json.dumps(saved,indent=2)+'\n')
 for target in ['constructor','files']:
  for tool,args in [('readelf',['-SW']),('nm',['-S','-C','--defined-only']),('objdump',['--dwarf=frames-interp'])]:
   with (folder/(target+'.'+tool+'.txt')).open('w') as log:subprocess.run([tool,*args,str(folder/target)],stdout=log,stderr=subprocess.STDOUT,check=True)
 lib=pathlib.Path(saved['hummingbird_gpui_port']['file'])
 for suffix,args in [('symbols',['nm','-S','-C','--defined-only']),('assembly',['objdump','-drC']),('frames',['objdump','--dwarf=frames-interp']),('sections',['readelf','-SW'])]:
  with (folder/('hummingbird.'+suffix+'.txt')).open('w') as log:subprocess.run([*args,str(lib)],stdout=log,stderr=subprocess.STDOUT,check=True)
 return folder
assert int((out/'final-strict-default.exit').read_text())==0
assert int((out/'final-strict-native.exit').read_text())==0
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)
guard('prefix')
try:
 run('cost-lock-minimal',['cargo','metadata','--offline','--format-version','1','--manifest-path',str(fixture/'Cargo.toml')])
 def version_sets(path):
  result=collections.defaultdict(set)
  for package in tomllib.loads(path.read_text())['package']:result[package['name']].add(package['version'])
  return {name:sorted(versions) for name,versions in result.items()}
 original_lock=pathlib.Path('/tmp/gpui-hummingbird-one-engine-evidence-sol/normal/Cargo.lock')
 original_versions=version_sets(original_lock);actual_versions=version_sets(fixture/'Cargo.lock')
 changes={name:{'original':original_versions[name],'actual':actual_versions[name]} for name in original_versions.keys()&actual_versions.keys() if original_versions[name]!=actual_versions[name]}
 ledger={'original_lock_sha256':sha(original_lock),'actual_lock_sha256':sha(fixture/'Cargo.lock'),'changed_common_version_sets':changes,'same_common_versions':not changes,'added_names':sorted(actual_versions.keys()-original_versions.keys()),'removed_names':sorted(original_versions.keys()-actual_versions.keys()),'scope':'Normal cpal-output caller dependency graph; native port graph is a different workspace. Same physical prefix/absolute source and lockfile.'}
 (out/'cost-lock-ledger.json').write_text(json.dumps(ledger,indent=2)+'\n')
 assert not changes
 fixed_sources={str(path.relative_to(fixture)):sha(path) for path in fixture.rglob('*') if path.is_file()}
 (out/'cost-fixture-final.json').write_text(json.dumps(fixed_sources,indent=2)+'\n')
 for mode,content in [('prefix',selected),('absolute',absolute)]:
  source.write_bytes(content);before=guard(mode)
  (out/('cost-'+mode+'-source-before.json')).write_text(json.dumps(before,indent=2)+'\n')
  run('cost-'+mode+'-build',['cargo','build','--release','--offline','--locked','--manifest-path',str(fixture/'Cargo.toml'),'--bins','--message-format=json'])
  folder=freeze(mode)
  run('cost-'+mode+'-constructor',[str(folder/'constructor')],60)
  for repeat in range(3):run('cost-'+mode+'-files-'+str(repeat),[str(folder/'files'),fixed],60)
  assert guard(mode)==before
  assert {str(path.relative_to(fixture)):sha(path) for path in fixture.rglob('*') if path.is_file()}==fixed_sources
  (out/('cost-'+mode+'-source-after.json')).write_text(json.dumps(guard(mode),indent=2)+'\n')
 old=pathlib.Path('/tmp/gpui-hummingbird-one-engine-evidence-sol/final-constructor-artifacts/authority-constructor-bill')
 dest=out/'cost-browser282-constructor';shutil.copy2(old,dest)
 (out/'cost-browser282-control.json').write_text(json.dumps({'source':'282b1c09b9d0a49fc52df3a890d67381c8747f6d','binary_sha256':sha(dest),'source_binary':str(old),'scope':'Fresh run of frozen original four-cohort constructor ELF, same original fixture/flags/features/calling-thread counter. Different compilation source/package path from the new Files fixture; full feature code-size is reference scope, while absolute/prefix comparison is matched same physical path.'},indent=2)+'\n')
 run('cost-browser282-constructor-runtime',[str(dest)],60)
finally:
 source.write_bytes(selected)
 (out/'cost-source-restored.json').write_text(json.dumps(guard('prefix'),indent=2)+'\n')
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)
print('DONE owner cost: all normal builds/captures exited and selected source restored',flush=True)
