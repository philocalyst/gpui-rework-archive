import hashlib,json,pathlib,shutil,subprocess
out=pathlib.Path(__file__).parent
root=pathlib.Path('/root/gpui-hummingbird-files-sol')
py='/nix/store/9r02ykx9y35lf4gk6gc30gnag1y8ncp7-python3-3.13.15/bin/python3'
assert int((out/'native-release.exit').read_text())==0
assert not (out/'native-artifacts').exists()
artifacts=[]
for line in (out/'native-release.jsonl').read_text().splitlines():
 try:item=json.loads(line)
 except json.JSONDecodeError:continue
 if item.get('reason')=='compiler-artifact' and item.get('target',{}).get('name')=='native_service' and item.get('executable'):artifacts.append(item)
assert len(artifacts)==1
frozen=out/'native-artifacts';frozen.mkdir();binary=frozen/'native_service';shutil.copy2(artifacts[0]['executable'],binary)
sha=hashlib.sha256(binary.read_bytes()).hexdigest()
(frozen/'artifact.json').write_text(json.dumps({'cargo':artifacts[0],'sha256':sha},indent=2)+'\n')
records=[]
for name,script,extra in [('default','native-service.py',[]),('collections','native-service.py',['--collections']),('files','native-files.py',[])]:
 capture=out/('native-client-'+name)
 assert not capture.exists()
 command=['timeout','--signal=TERM','--kill-after=5s','180s','dbus-run-session','--',py,str(root/'reactivity/ports/hummingbird'/script),str(binary),str(capture),*extra]
 (out/('native-client-'+name+'.command.json')).write_text(json.dumps({'command':command,'binary_sha256':sha},indent=2)+'\n')
 subprocess.run([py,str(out/'guard.py'),'verify','native'],check=True,stdout=(out/('native-client-'+name+'-source-before.json')).open('w'))
 with (out/('native-client-'+name+'.log')).open('w') as log:code=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
 (out/('native-client-'+name+'.exit')).write_text(str(code)+'\n')
 subprocess.run([py,str(out/'guard.py'),'verify','native'],check=True,stdout=(out/('native-client-'+name+'-source-after.json')).open('w'))
 assert hashlib.sha256(binary.read_bytes()).hexdigest()==sha
 result=json.loads((capture/'result.json').read_text()) if (capture/'result.json').exists() else None
 records.append({'name':name,'exit':code,'result':result,'binary_sha256':sha})
 (out/'native-clients-summary.json').write_text(json.dumps({'pin':'5fda6e4f09af19f02125824f619560c48f9b9a9b','clients':records,'all_completed':len(records)==3},indent=2)+'\n')
print('DONE native clients; subprocess.run reaped all direct children; each client owns descendant teardown',flush=True)
raise SystemExit(0 if all(r['exit']==0 for r in records) else 1)
