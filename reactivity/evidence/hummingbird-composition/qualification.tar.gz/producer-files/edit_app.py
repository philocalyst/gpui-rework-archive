from pathlib import Path
p=Path('/root/gpui-hummingbird-files-sol/reactivity/ports/hummingbird/src/app.rs');s=p.read_text();s=s.replace('Browser, Input, Page, PlayRequest, Route, RowKey','Browser, Input, Listing, Page, PlayRequest, PlayStamp, Route, RowKey')
s=s.replace('''    ListingPlayed {
        request: PlayRequest,''','''    ListingPlayed {
        request: PlayStamp,''').replace('''    ListingFailed {
        request: PlayRequest,''','''    ListingFailed {
        request: PlayStamp,''')
s=s.replace('''    browser: Browser,
''','''    browser: Browser,
    roots: crate::files::Roots,
    indexing: Option<crate::indexing::Request>,
''',1)
s=s.replace('''    pub fn browser(&self) -> &Browser {''','''    pub const ROOTS: Component<Self, crate::files::Roots> = Component::new(
        FieldId::new(7), "library roots", |m| &m.roots, |m| &mut m.roots,
    );
    pub fn indexing_request(&self) -> Option<crate::indexing::Request> { self.indexing }
    pub fn request_index(&mut self, command: crate::indexing::Command) {
        let Some(sequence) = self.issued.checked_add(1) else {
            self.notice = "Library request space exhausted".into();
            return;
        };
        self.issued = sequence;
        let request = crate::indexing::Request { version: *self.version, sequence };
        let notice = if matches!(command, crate::indexing::Command::Cancel) {
            "Canceling indexing after the current file"
        } else { "Library acquisition pending" };
        match self.worker.index(request, command) {
            Ok(()) => { self.indexing = Some(request); self.notice = notice.into(); }
            Err(error) => self.notice = crate::worker::QueueError(error).to_string(),
        }
    }
    pub fn edit_root(&mut self, input: &Input, id: i64, delete_recordings: bool) {
        if self.browser.matches(input, *self.version) {
            self.request_index(crate::indexing::Command::RemoveRoot { id, delete_recordings });
        }
    }
    pub fn browser(&self) -> &Browser {''')
s=s.replace('''    fn current_listing(&self, request: &PlayRequest, edits: [u32; 3]) -> bool {
        let id = request.start.map(|key| match key {
            RowKey::Track(id) | RowKey::PlaylistItem { track: id, .. } => id,
        });
        self.selected.sequence == request.sequence
            && self.selected.id == id
            && self.selected.generation == request.input.version.generation
            && self.browser.revisions() == edits
            && self.browser.matches(&request.input, *self.version)
    }''','''    fn current_listing(&self, input: &Input, start: Option<RowKey>, sequence: u64, edits: [u32; 3]) -> bool {
        let id = start.and_then(|key| match key {
            RowKey::Track(id) | RowKey::PlaylistItem { track: id, .. } => Some(id),
            RowKey::File(_) => None,
        });
        self.selected.sequence == sequence
            && self.selected.id == id
            && self.selected.generation == input.version.generation
            && self.browser.revisions() == edits
            && self.browser.matches(input, *self.version)
    }''')
s=s.replace('''    pub fn play_listing(&mut self, input: triomphe::Arc<Input>, start: Option<RowKey>) {
        if !self.browser.matches(&input, *self.version) {''','''    pub fn play_listing(&mut self, input: triomphe::Arc<Input>, start: Option<RowKey>) {
        self.play_context(Listing::Sql(input), start);
    }
    pub fn play_files(&mut self, files: triomphe::Arc<crate::files::FileListing>, start: Option<RowKey>) {
        self.play_context(Listing::Files(files), start);
    }
    fn play_context(&mut self, listing: Listing, start: Option<RowKey>) {
        if !self.browser.matches(listing.input(), *self.version) {''')
s=s.replace('''        let request = PlayRequest {
            input,
            start,''','''        let request = PlayRequest {
            listing,
            start,''')
s=s.replace('''            id: start.map(|key| match key {
                RowKey::Track(id) | RowKey::PlaylistItem { track: id, .. } => id,
            }),''','''            id: start.and_then(|key| match key {
                RowKey::Track(id) | RowKey::PlaylistItem { track: id, .. } => Some(id),
                RowKey::File(_) => None,
            }),''')
s=s.replace('request.input.version', 'request.input().version')
s=s.replace('self.current_listing(request, *edits)', 'self.current_listing(request.input(), request.start, request.sequence, *edits)')
# Terminal statuses retain the small authority stamp, not a FileListing.
s=s.replace('''            self.preparation = Preparation::ListingFailed {
                request,
''','''            self.preparation = Preparation::ListingFailed {
                request: request.stamp(),
''')
s=s.replace('''                            Preparation::ListingFailed {
                                request,
''','''                            Preparation::ListingFailed {
                                request: request.stamp(),
''')
s=s.replace('''                        self.preparation = Preparation::ListingFailed {
                            request,
''','''                        self.preparation = Preparation::ListingFailed {
                            request: request.stamp(),
''')
s=s.replace('''                                self.preparation = Preparation::ListingFailed {
                                    request,
''','''                                self.preparation = Preparation::ListingFailed {
                                    request: request.stamp(),
''')
s=s.replace('Preparation::ListingPlayed { request, edits }\n                            }', 'Preparation::ListingPlayed { request: request.stamp(), edits }\n                            }')
s=s.replace('''            self.notice = "Library worker closed".into();''','''            self.indexing = None;
            self.notice = "Library worker closed".into();''')
s=s.replace('''        match event {
            LibraryEvent::ListingPrepared''','''        match event {
            LibraryEvent::Indexed { request, version, result } => {
                // Publication is worker-owned. A request owns only its status;
                // Version must advance even when a newer task replaced it.
                if result.is_ok() && version.revision > self.version.revision {
                    let replacement = version.generation != self.version.generation;
                    *self.version = version;
                    self.browser.source_changed();
                    if replacement {
                        *self.selected = Selection { sequence: self.issued, generation: version.generation, ..Selection::default() };
                        self.preparation = Preparation::Canceled;
                    }
                }
                if self.indexing != Some(request) { return; }
                self.indexing = None;
                self.notice = match result {
                    Ok(crate::indexing::Outcome::RootsChanged) => "Library roots updated".into(),
                    Ok(crate::indexing::Outcome::Canceled) => "Indexing canceled; committed recordings kept".into(),
                    Ok(crate::indexing::Outcome::Indexed(report)) => format!("Indexed {}; unchanged {}; removed {}; failed {}{}", report.indexed, report.unchanged, report.removed, report.failed, report.first_error.map_or(String::new(), |error| format!(": {error}"))),
                    Err(error) => format!("Library acquisition failed: {error}"),
                };
            }
            LibraryEvent::ListingPrepared''')
s=s.replace('''            browser: Browser::new(),
''','''            browser: Browser::new(),
            roots: crate::files::Roots::new(),
            indexing: None,
''',1)
s=s.replace('''.direct_component(Self::BROWSER)
''','''.direct_component(Self::BROWSER)
            .direct_component(Self::ROOTS)
''')
s=s.replace('''            Self::BROWSER.view(self),
            self.results''','''            Self::BROWSER.view(self),
            Self::ROOTS.view(self),
            row((
                button("Add library root").on_click(|model: &mut Library| model.request_index(crate::indexing::Command::AddRoot(model.roots.path().into()))),
                button("Index library roots").on_click(|model: &mut Library| model.request_index(crate::indexing::Command::Scan)),
                button("Cancel indexing").on_click(|model: &mut Library| model.request_index(crate::indexing::Command::Cancel)),
            )).gap(8),
            self.results''')
a=s.index('''                .project(|page| {''');b=s.index('''                .loading(||''',a)
old=s[a:b]
old=old.replace('''                .project(|page| {''','''                .project(|page| match page {
                    Page::Files(files) => {
                        #[cfg(feature = "audio")]
                        let play = if files.recording_count() != 0 {
                            let listing = files.0.clone();
                            button("Play all files").on_click(move |model: &mut Library| model.play_files(listing.clone(), None))
                        } else { text("") };
                        #[cfg(not(feature = "audio"))]
                        let play = text("Audio output is not attached");
                        column((
                            text(match &files.input.route {
                                Route::Directory(path) => path.to_string_lossy().into_owned(),
                                _ => "Library roots".into(),
                            }),
                            text(format!("{} entries; {} recordings", files.entries.len(), files.recording_count())),
                            play,
                            uniform_list(files.list(), files, 32).name("Library files").w(900).h(160),
                        )).gap(6)
                    }
                    Page::Library(page) => {''')
old=old.replace('''                })
''','''                    }
                })
''')
s=s[:a]+old+s[b:];p.write_text(s)
p=Path('/root/gpui-hummingbird-files-sol/reactivity/ports/hummingbird/src/browser.rs');s=p.read_text().replace('''pub struct PlayStamp {
    pub input: Arc<Input>,
    pub start: Option<RowKey>,
    pub sequence: u64,
}
''','''pub struct PlayStamp {
    pub input: Arc<Input>,
    pub start: Option<RowKey>,
    pub sequence: u64,
}
impl PlayStamp {
    pub fn input(&self) -> &Arc<Input> { &self.input }
}
''');p.write_text(s)
