cargo clippy --offline --locked --manifest-path reactivity/ports/hummingbird/Cargo.toml --all-targets --message-format=json -- -D warnings 
