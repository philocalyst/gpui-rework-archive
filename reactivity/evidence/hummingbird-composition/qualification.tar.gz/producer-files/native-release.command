cargo build --release --offline --locked --manifest-path reactivity/ports/hummingbird/Cargo.toml --features native --example native_service --message-format=json 
